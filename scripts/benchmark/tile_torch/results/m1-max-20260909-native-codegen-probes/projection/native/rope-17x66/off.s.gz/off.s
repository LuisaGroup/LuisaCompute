
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/rope-17x66/off/object/tile_xir_w8_38069_1788936547028639_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0x130
       4:      	stp	d15, d14, [sp, #0xe0]
       8:      	stp	d13, d12, [sp, #0xf0]
       c:      	stp	d11, d10, [sp, #0x100]
      10:      	stp	d9, d8, [sp, #0x110]
      14:      	stp	x28, x27, [sp, #0x120]
      18:      	ldr	x10, [x0]
      1c:      	ldr	x11, [x0, #0x10]
      20:      	ldr	x9, [x0, #0x20]
      24:      	ldr	x8, [x0, #0x30]
      28:      	ldr	w12, [x1]
      2c:      	ldr	w13, [x1, #0x24]
      30:      	add	w12, w13, w12, lsl #5
      34:      	lsr	w12, w12, #3
      38:      	dup.2s	v0, w12
      3c:      	ushll.2d	v18, v0, #0x0
      40:      	subs	x12, x10, x8
      44:      	lsr	x12, x12, #3
      48:      	mov	w14, #0x230             ; =560
      4c:      	ccmp	x12, x14, #0x0, hs
      50:      	cset	w12, hi
      54:      	subs	x13, x8, x10
      58:      	lsr	x13, x13, #3
      5c:      	ccmp	x13, x14, #0x0, hs
      60:      	csinc	w15, w12, wzr, ls
      64:      	subs	x12, x11, x8
      68:      	lsr	x12, x12, #3
      6c:      	ccmp	x12, x14, #0x0, hs
      70:      	cset	w12, hi
      74:      	subs	x13, x8, x11
      78:      	mov	w16, #0x8c3             ; =2243
      7c:      	ccmp	x13, x16, #0x0, hs
      80:      	csinc	w13, w12, wzr, ls
      84:      	subs	x12, x9, x8
      88:      	lsr	x12, x12, #3
      8c:      	ccmp	x12, x14, #0x0, hs
      90:      	cset	w12, hi
      94:      	subs	x14, x8, x9
      98:      	ccmp	x14, x16, #0x0, hs
      9c:      	csinc	w14, w12, wzr, ls
      a0:      	fmov	x12, d18
      a4:      	add	x12, x12, x12, lsl #5
      a8:      	lsl	x12, x12, #3
      ac:      	add	x16, x10, x12
      b0:      	ldp	q20, q1, [x16]
      b4:      	cmp	w14, #0x1
      b8:      	ccmp	w15, #0x0, #0x4, eq
      bc:      	b.eq	0x2ac <ltmp0+0x2ac>
      c0:      	tbz	w13, #0x0, 0x2ac <ltmp0+0x2ac>
      c4:      	add	x14, x12, #0x84
      c8:      	add	x13, x10, x14
      cc:      	ldp	q0, q2, [x13]
      d0:      	fmov	x13, d18
      d4:      	add	x13, x13, x13, lsl #5
      d8:      	lsl	x13, x13, #2
      dc:      	add	x15, x11, x13
      e0:      	ldp	q3, q5, [x15]
      e4:      	add	x15, x9, x13
      e8:      	ldp	q6, q7, [x15]
      ec:      	fmul.4s	v16, v1, v5
      f0:      	fmul.4s	v17, v20, v3
      f4:      	fmul.4s	v18, v2, v7
      f8:      	fmul.4s	v19, v0, v6
      fc:      	fsub.4s	v17, v17, v19
     100:      	fsub.4s	v16, v16, v18
     104:      	add	x15, x8, x12
     108:      	stp	q17, q16, [x15]
     10c:      	fmul.4s	v1, v1, v7
     110:      	fmul.4s	v4, v20, v6
     114:      	fmul.4s	v2, v2, v5
     118:      	fmul.4s	v0, v0, v3
     11c:      	fadd.4s	v0, v0, v4
     120:      	fadd.4s	v1, v2, v1
     124:      	add	x14, x8, x14
     128:      	stp	q0, q1, [x14]
     12c:      	add	x14, x12, #0x20
     130:      	add	x15, x10, x14
     134:      	ldp	q0, q1, [x15]
     138:      	add	x15, x12, #0xa4
     13c:      	add	x16, x10, x15
     140:      	ldp	q2, q3, [x16]
     144:      	add	x16, x13, #0x20
     148:      	add	x17, x11, x16
     14c:      	ldp	q4, q5, [x17]
     150:      	add	x16, x9, x16
     154:      	ldp	q6, q7, [x16]
     158:      	fmul.4s	v16, v1, v5
     15c:      	fmul.4s	v17, v0, v4
     160:      	fmul.4s	v18, v3, v7
     164:      	fmul.4s	v19, v2, v6
     168:      	fsub.4s	v17, v17, v19
     16c:      	fsub.4s	v16, v16, v18
     170:      	add	x14, x8, x14
     174:      	stp	q17, q16, [x14]
     178:      	fmul.4s	v1, v1, v7
     17c:      	fmul.4s	v0, v0, v6
     180:      	fmul.4s	v3, v3, v5
     184:      	fmul.4s	v2, v2, v4
     188:      	fadd.4s	v0, v2, v0
     18c:      	fadd.4s	v1, v3, v1
     190:      	add	x14, x8, x15
     194:      	stp	q0, q1, [x14]
     198:      	add	x14, x12, #0x40
     19c:      	add	x15, x10, x14
     1a0:      	ldp	q0, q1, [x15]
     1a4:      	add	x15, x12, #0xc4
     1a8:      	add	x16, x10, x15
     1ac:      	ldp	q2, q3, [x16]
     1b0:      	add	x16, x13, #0x40
     1b4:      	add	x17, x11, x16
     1b8:      	ldp	q4, q5, [x17]
     1bc:      	add	x16, x9, x16
     1c0:      	ldp	q6, q7, [x16]
     1c4:      	fmul.4s	v16, v1, v5
     1c8:      	fmul.4s	v17, v0, v4
     1cc:      	fmul.4s	v18, v3, v7
     1d0:      	fmul.4s	v19, v2, v6
     1d4:      	fsub.4s	v17, v17, v19
     1d8:      	fsub.4s	v16, v16, v18
     1dc:      	add	x14, x8, x14
     1e0:      	stp	q17, q16, [x14]
     1e4:      	fmul.4s	v1, v1, v7
     1e8:      	fmul.4s	v0, v0, v6
     1ec:      	fmul.4s	v3, v3, v5
     1f0:      	fmul.4s	v2, v2, v4
     1f4:      	fadd.4s	v0, v2, v0
     1f8:      	fadd.4s	v1, v3, v1
     1fc:      	add	x14, x8, x15
     200:      	stp	q0, q1, [x14]
     204:      	add	x14, x12, #0x60
     208:      	add	x15, x10, x14
     20c:      	ldp	q1, q0, [x15]
     210:      	add	x15, x12, #0xe4
     214:      	add	x16, x10, x15
     218:      	ldp	q3, q2, [x16]
     21c:      	add	x16, x13, #0x60
     220:      	add	x17, x11, x16
     224:      	ldp	q5, q4, [x17]
     228:      	add	x16, x9, x16
     22c:      	ldp	q7, q6, [x16]
     230:      	fmul.4s	v16, v1, v5
     234:      	fmul.4s	v17, v0, v4
     238:      	fmul.4s	v18, v3, v7
     23c:      	fmul.4s	v19, v2, v6
     240:      	fsub.4s	v17, v17, v19
     244:      	fsub.4s	v16, v16, v18
     248:      	add	x14, x8, x14
     24c:      	stp	q16, q17, [x14]
     250:      	fmul.4s	v1, v1, v7
     254:      	fmul.4s	v0, v0, v6
     258:      	fmul.4s	v3, v3, v5
     25c:      	fmul.4s	v2, v2, v4
     260:      	fadd.4s	v0, v2, v0
     264:      	fadd.4s	v1, v3, v1
     268:      	add	x14, x8, x15
     26c:      	stp	q1, q0, [x14]
     270:      	add	x14, x12, #0x80
     274:      	ldr	s0, [x10, x14]
     278:      	add	x1, x12, #0x104
     27c:      	ldr	s1, [x10, x1]
     280:      	add	x10, x13, #0x80
     284:      	ldr	s2, [x11, x10]
     288:      	ldr	s3, [x9, x10]
     28c:      	fmul.4s	v4, v0, v2
     290:      	fmul.4s	v5, v1, v3
     294:      	fsub.4s	v4, v4, v5
     298:      	str	s4, [x8, x14]
     29c:      	fmul.4s	v0, v0, v3
     2a0:      	fmul.4s	v1, v1, v2
     2a4:      	fadd.4s	v0, v1, v0
     2a8:      	b	0x4dc <ltmp0+0x4dc>
     2ac:      	add	x0, x12, #0x20
     2b0:      	add	x13, x10, x0
     2b4:      	ldp	q6, q16, [x13]
     2b8:      	add	x17, x12, #0x40
     2bc:      	add	x13, x10, x17
     2c0:      	ldp	q4, q7, [x13]
     2c4:      	stp	q7, q4, [sp, #0x80]
     2c8:      	add	x16, x12, #0x60
     2cc:      	add	x1, x10, x16
     2d0:      	add	x15, x12, #0x84
     2d4:      	add	x13, x10, x15
     2d8:      	ldp	q17, q23, [x13]
     2dc:      	add	x14, x12, #0xa4
     2e0:      	add	x13, x10, x14
     2e4:      	ldp	q30, q31, [x13]
     2e8:      	stp	q30, q6, [sp, #0x40]
     2ec:      	stp	q16, q31, [sp, #0x20]
     2f0:      	add	x13, x12, #0xc4
     2f4:      	add	x2, x10, x13
     2f8:      	ldp	q19, q21, [x2]
     2fc:      	stp	q21, q19, [sp, #0xa0]
     300:      	fmov	x2, d18
     304:      	add	x2, x2, x2, lsl #5
     308:      	lsl	x3, x2, #2
     30c:      	add	x2, x11, x3
     310:      	ldp	q24, q25, [x2]
     314:      	add	x2, x3, #0x20
     318:      	add	x4, x11, x2
     31c:      	ldp	q18, q12, [x4]
     320:      	stp	q12, q18, [sp, #0x60]
     324:      	add	x4, x3, #0x40
     328:      	add	x5, x11, x4
     32c:      	ldp	q8, q9, [x5]
     330:      	stp	q9, q8, [sp, #0xc0]
     334:      	add	x5, x9, x3
     338:      	ldp	q10, q11, [x5]
     33c:      	add	x2, x9, x2
     340:      	ldp	q27, q29, [x2]
     344:      	add	x2, x9, x4
     348:      	fmul.4s	v0, v1, v25
     34c:      	fmul.4s	v2, v20, v24
     350:      	fmul.4s	v3, v23, v11
     354:      	ldp	q26, q28, [x2]
     358:      	fmul.4s	v5, v17, v10
     35c:      	fsub.4s	v2, v2, v5
     360:      	str	q2, [sp, #0x10]
     364:      	fsub.4s	v22, v0, v3
     368:      	fmul.4s	v0, v16, v12
     36c:      	fmul.4s	v2, v6, v18
     370:      	fmul.4s	v3, v31, v29
     374:      	fmul.4s	v6, v30, v27
     378:      	fsub.4s	v2, v2, v6
     37c:      	str	q2, [sp]
     380:      	fsub.4s	v18, v0, v3
     384:      	fmul.4s	v0, v7, v9
     388:      	fmul.4s	v2, v4, v8
     38c:      	fmul.4s	v3, v21, v28
     390:      	fmul.4s	v30, v19, v26
     394:      	fsub.4s	v16, v2, v30
     398:      	fsub.4s	v7, v0, v3
     39c:      	ldp	q30, q31, [x1]
     3a0:      	add	x2, x12, #0xe4
     3a4:      	add	x1, x10, x2
     3a8:      	add	x4, x3, #0x60
     3ac:      	add	x5, x11, x4
     3b0:      	add	x4, x9, x4
     3b4:      	ldp	q8, q9, [x5]
     3b8:      	fmul.4s	v2, v30, v8
     3bc:      	ldp	q12, q13, [x1]
     3c0:      	ldp	q0, q3, [x4]
     3c4:      	fmul.4s	v14, v12, v0
     3c8:      	fsub.4s	v6, v2, v14
     3cc:      	fmul.4s	v2, v31, v9
     3d0:      	fmul.4s	v14, v13, v3
     3d4:      	fsub.4s	v5, v2, v14
     3d8:      	add	x4, x12, #0x80
     3dc:      	add	x1, x12, #0x104
     3e0:      	add	x3, x3, #0x80
     3e4:      	ldr	s14, [x10, x4]
     3e8:      	ldr	s15, [x11, x3]
     3ec:      	fmul.4s	v4, v14, v15
     3f0:      	ldr	s2, [x10, x1]
     3f4:      	ldr	s21, [x9, x3]
     3f8:      	fmul.4s	v19, v2, v21
     3fc:      	fsub.4s	v4, v4, v19
     400:      	fmul.4s	v1, v1, v11
     404:      	fmul.4s	v19, v20, v10
     408:      	fmul.4s	v20, v23, v25
     40c:      	fmul.4s	v24, v17, v24
     410:      	add	x9, x8, x12
     414:      	ldr	q17, [sp, #0x10]
     418:      	stp	q17, q22, [x9]
     41c:      	fadd.4s	v17, v24, v19
     420:      	fadd.4s	v1, v20, v1
     424:      	ldp	q19, q22, [sp, #0x20]
     428:      	fmul.4s	v19, v19, v29
     42c:      	add	x9, x8, x0
     430:      	str	q18, [x9, #0x10]
     434:      	ldr	q18, [sp]
     438:      	str	q18, [x9]
     43c:      	ldp	q18, q20, [sp, #0x50]
     440:      	fmul.4s	v18, v18, v27
     444:      	fmul.4s	v20, v22, v20
     448:      	ldr	q22, [sp, #0x70]
     44c:      	ldr	q23, [sp, #0x40]
     450:      	fmul.4s	v22, v23, v22
     454:      	add	x9, x8, x17
     458:      	stp	q16, q7, [x9]
     45c:      	fadd.4s	v7, v22, v18
     460:      	fadd.4s	v16, v20, v19
     464:      	ldr	q18, [sp, #0x80]
     468:      	fmul.4s	v18, v18, v28
     46c:      	add	x9, x8, x16
     470:      	stp	q6, q5, [x9]
     474:      	ldp	q5, q6, [sp, #0x90]
     478:      	fmul.4s	v5, v5, v26
     47c:      	str	s4, [x8, x4]
     480:      	ldp	q19, q4, [sp, #0xb0]
     484:      	fmul.4s	v4, v6, v4
     488:      	ldr	q6, [sp, #0xd0]
     48c:      	fmul.4s	v6, v19, v6
     490:      	fadd.4s	v5, v6, v5
     494:      	add	x9, x8, x15
     498:      	stp	q17, q1, [x9]
     49c:      	fadd.4s	v1, v4, v18
     4a0:      	fmul.4s	v3, v31, v3
     4a4:      	fmul.4s	v0, v30, v0
     4a8:      	add	x9, x8, x14
     4ac:      	stp	q7, q16, [x9]
     4b0:      	fmul.4s	v4, v13, v9
     4b4:      	fmul.4s	v6, v12, v8
     4b8:      	fadd.4s	v6, v6, v0
     4bc:      	add	x9, x8, x13
     4c0:      	stp	q5, q1, [x9]
     4c4:      	fadd.4s	v1, v4, v3
     4c8:      	fmul.4s	v0, v14, v21
     4cc:      	fmul.4s	v2, v2, v15
     4d0:      	fadd.4s	v0, v2, v0
     4d4:      	add	x9, x8, x2
     4d8:      	stp	q6, q1, [x9]
     4dc:      	str	s0, [x8, x1]
     4e0:      	ldp	x28, x27, [sp, #0x120]
     4e4:      	ldp	d9, d8, [sp, #0x110]
     4e8:      	ldp	d11, d10, [sp, #0x100]
     4ec:      	ldp	d13, d12, [sp, #0xf0]
     4f0:      	ldp	d15, d14, [sp, #0xe0]
     4f4:      	add	sp, sp, #0x130
     4f8:      	ret

00000000000004fc <_llm_rows.packet_batch.blocks>:
     4fc:      	cbz	w3, 0x391c <_llm_rows.packet_batch.blocks+0x3420>
     500:      	stp	d15, d14, [sp, #-0xa0]!
     504:      	stp	d13, d12, [sp, #0x10]
     508:      	stp	d11, d10, [sp, #0x20]
     50c:      	stp	d9, d8, [sp, #0x30]
     510:      	stp	x28, x27, [sp, #0x40]
     514:      	stp	x26, x25, [sp, #0x50]
     518:      	stp	x24, x23, [sp, #0x60]
     51c:      	stp	x22, x21, [sp, #0x70]
     520:      	stp	x20, x19, [sp, #0x80]
     524:      	stp	x29, x30, [sp, #0x90]
     528:      	sub	sp, sp, #0x8c0
     52c:      	mov	x19, x3
     530:      	mov	x20, x2
     534:      	mov	x21, x0
     538:      	ldp	w27, w22, [x2, #0x2c]
     53c:      	ldp	w24, w28, [x2]
     540:      	ldp	w23, w25, [x2, #0x8]
     544:      	adrp	x8, 0x0 <ltmp0>
     548:      	ldr	q0, [x8]
     54c:      	str	q0, [sp, #0x2a0]
     550:      	adrp	x8, 0x0 <ltmp0>
     554:      	ldr	q0, [x8]
     558:      	str	q0, [sp, #0x290]
     55c:      	adrp	x8, 0x0 <ltmp0>
     560:      	ldr	q0, [x8]
     564:      	str	q0, [sp, #0x270]
     568:      	adrp	x8, 0x0 <ltmp0>
     56c:      	ldr	q0, [x8]
     570:      	str	q0, [sp, #0x260]
     574:      	adrp	x8, 0x0 <ltmp0>
     578:      	ldr	q0, [x8]
     57c:      	str	q0, [sp, #0x250]
     580:      	adrp	x8, 0x0 <ltmp0>
     584:      	ldr	q0, [x8]
     588:      	str	q0, [sp, #0x240]
     58c:      	adrp	x8, 0x0 <ltmp0>
     590:      	ldr	q0, [x8]
     594:      	str	q0, [sp, #0x230]
     598:      	mov	w8, #0x40               ; =64
     59c:      	fmov	d0, x8
     5a0:      	str	q0, [sp, #0x20]
     5a4:      	movi.2s	v10, #0x42
     5a8:      	mov	w8, #0x60               ; =96
     5ac:      	movi.2s	v11, #0x21
     5b0:      	fmov	d0, x8
     5b4:      	str	q0, [sp, #0x10]
     5b8:      	str	w22, [sp, #0x2bc]
     5bc:      	b	0x638 <_llm_rows.packet_batch.blocks+0x13c>
     5c0:      	mov	x0, x21
     5c4:      	mov	x1, x20
     5c8:      	bl	0x5c8 <_llm_rows.packet_batch.blocks+0xcc>
     5cc:      	mov	w8, #0x8                ; =8
     5d0:      	str	w8, [x20, #0x24]
     5d4:      	mov	x0, x21
     5d8:      	mov	x1, x20
     5dc:      	bl	0x5dc <_llm_rows.packet_batch.blocks+0xe0>
     5e0:      	mov	w8, #0x10               ; =16
     5e4:      	str	w8, [x20, #0x24]
     5e8:      	mov	x0, x21
     5ec:      	mov	x1, x20
     5f0:      	bl	0x5f0 <_llm_rows.packet_batch.blocks+0xf4>
     5f4:      	mov	w8, #0x18               ; =24
     5f8:      	str	w8, [x20, #0x24]
     5fc:      	mov	x0, x21
     600:      	mov	x1, x20
     604:      	bl	0x604 <_llm_rows.packet_batch.blocks+0x108>
     608:      	add	w8, w24, #0x1
     60c:      	cmp	w8, w27
     610:      	cset	w8, eq
     614:      	csinc	w24, wzr, w24, eq
     618:      	cinc	w9, w28, eq
     61c:      	cmp	w9, w22
     620:      	cset	w10, eq
     624:      	ands	w8, w8, w10
     628:      	csel	w28, wzr, w9, ne
     62c:      	add	w23, w23, w8
     630:      	subs	w19, w19, #0x1
     634:      	b.eq	0x38f0 <_llm_rows.packet_batch.blocks+0x33f4>
     638:      	ubfiz	x8, x24, #5, #32
     63c:      	cmp	x8, x25
     640:      	csel	x9, x8, xzr, ls
     644:      	subs	x10, x25, x9
     648:      	cmp	x10, #0x20
     64c:      	mov	w11, #0x20              ; =32
     650:      	csel	x10, x10, x11, lo
     654:      	cmp	x25, x9
     658:      	stp	w24, w28, [x20]
     65c:      	str	w23, [x20, #0x8]
     660:      	str	wzr, [x20, #0x24]
     664:      	ccmp	x8, x25, #0x2, hi
     668:      	csel	x26, x10, xzr, ls
     66c:      	cmp	x26, #0x20
     670:      	b.hs	0x5c0 <_llm_rows.packet_batch.blocks+0xc4>
     674:      	lsr	x22, x26, #3
     678:      	cmp	x26, #0x8
     67c:      	b.lo	0x6c8 <_llm_rows.packet_batch.blocks+0x1cc>
     680:      	str	wzr, [x20, #0x24]
     684:      	mov	x0, x21
     688:      	mov	x1, x20
     68c:      	bl	0x68c <_llm_rows.packet_batch.blocks+0x190>
     690:      	cmp	x22, #0x1
     694:      	b.eq	0x6c8 <_llm_rows.packet_batch.blocks+0x1cc>
     698:      	mov	w8, #0x8                ; =8
     69c:      	str	w8, [x20, #0x24]
     6a0:      	mov	x0, x21
     6a4:      	mov	x1, x20
     6a8:      	bl	0x6a8 <_llm_rows.packet_batch.blocks+0x1ac>
     6ac:      	cmp	x22, #0x2
     6b0:      	b.eq	0x6c8 <_llm_rows.packet_batch.blocks+0x1cc>
     6b4:      	mov	w8, #0x10               ; =16
     6b8:      	str	w8, [x20, #0x24]
     6bc:      	mov	x0, x21
     6c0:      	mov	x1, x20
     6c4:      	bl	0x6c4 <_llm_rows.packet_batch.blocks+0x1c8>
     6c8:      	and	w8, w26, #0x7
     6cc:      	cbz	w8, 0x38e0 <_llm_rows.packet_batch.blocks+0x33e4>
     6d0:      	dup.4s	v0, w8
     6d4:      	ldp	q2, q1, [sp, #0x290]
     6d8:      	cmhi.4s	v16, v0, v2
     6dc:      	cmhi.4s	v0, v0, v1
     6e0:      	uzp1.8h	v1, v0, v16
     6e4:      	umaxv.8h	h2, v1
     6e8:      	fmov	w8, s2
     6ec:      	tbz	w8, #0x0, 0x38e0 <_llm_rows.packet_batch.blocks+0x33e4>
     6f0:      	ldr	x11, [x21]
     6f4:      	ldr	x10, [x21, #0x10]
     6f8:      	ldr	x9, [x21, #0x20]
     6fc:      	ldr	x8, [x21, #0x30]
     700:      	sshll.2d	v2, v0, #0x0
     704:      	sshll.2d	v3, v16, #0x0
     708:      	sshll2.2d	v28, v0, #0x0
     70c:      	sshll2.2d	v5, v16, #0x0
     710:      	ldp	q4, q6, [sp, #0x260]
     714:      	mov.16b	v12, v5
     718:      	and.16b	v8, v5, v6
     71c:      	and.16b	v9, v28, v4
     720:      	ldr	q4, [sp, #0x250]
     724:      	and.16b	v31, v3, v4
     728:      	ldr	q3, [sp, #0x240]
     72c:      	and.16b	v7, v2, v3
     730:      	ubfiz	w12, w24, #2, #27
     734:      	orr	w12, w12, w22
     738:      	dup.4s	v2, w12
     73c:      	and.16b	v3, v0, v2
     740:      	and.16b	v2, v16, v2
     744:      	ushll2.2d	v4, v2, #0x0
     748:      	ushll2.2d	v5, v3, #0x0
     74c:      	ushll.2d	v2, v2, #0x0
     750:      	ushll.2d	v3, v3, #0x0
     754:      	subs	x12, x11, x8
     758:      	lsr	x12, x12, #3
     75c:      	mov	w15, #0x230             ; =560
     760:      	ccmp	x12, x15, #0x0, hs
     764:      	cset	w12, hi
     768:      	subs	x13, x8, x11
     76c:      	lsr	x13, x13, #3
     770:      	ccmp	x13, x15, #0x0, hs
     774:      	csinc	w12, w12, wzr, ls
     778:      	subs	x13, x10, x8
     77c:      	lsr	x13, x13, #3
     780:      	ccmp	x13, x15, #0x0, hs
     784:      	cset	w13, hi
     788:      	subs	x14, x8, x10
     78c:      	mov	w16, #0x8c3             ; =2243
     790:      	ccmp	x14, x16, #0x0, hs
     794:      	csinc	w13, w13, wzr, ls
     798:      	subs	x14, x9, x8
     79c:      	lsr	x14, x14, #3
     7a0:      	ccmp	x14, x15, #0x0, hs
     7a4:      	cset	w14, hi
     7a8:      	subs	x15, x8, x9
     7ac:      	ccmp	x15, x16, #0x0, hs
     7b0:      	csinc	w14, w14, wzr, ls
     7b4:      	xtn.2s	v30, v3
     7b8:      	xtn.2s	v25, v5
     7bc:      	xtn.2s	v27, v2
     7c0:      	xtn.2s	v26, v4
     7c4:      	cmp	w14, #0x1
     7c8:      	b.ne	0x1de0 <_llm_rows.packet_batch.blocks+0x18e4>
     7cc:      	cbz	w12, 0x1de0 <_llm_rows.packet_batch.blocks+0x18e4>
     7d0:      	cbz	w13, 0x1de0 <_llm_rows.packet_batch.blocks+0x18e4>
     7d4:      	ldr	q2, [sp, #0x230]
     7d8:      	and.16b	v1, v1, v2
     7dc:      	addv.8h	h17, v1
     7e0:      	fmov	w14, s17
     7e4:      	mov.16b	v1, v7
     7e8:      	umlal.2d	v1, v30, v10
     7ec:      	fmov	x12, d1
     7f0:      	lsl	x13, x12, #2
     7f4:      	add	x12, x11, x13
     7f8:      	movi.2d	v2, #0000000000000000
     7fc:      	movi.2d	v1, #0000000000000000
     800:      	tbz	w14, #0x0, 0x844 <_llm_rows.packet_batch.blocks+0x348>
     804:      	ldr	s2, [x12]
     808:      	and	w14, w14, #0xff
     80c:      	tbnz	w14, #0x1, 0x84c <_llm_rows.packet_batch.blocks+0x350>
     810:      	tbz	w14, #0x2, 0x858 <_llm_rows.packet_batch.blocks+0x35c>
     814:      	add	x15, x12, #0x8
     818:      	ld1.s	{ v2 }[2], [x15]
     81c:      	tbnz	w14, #0x3, 0x85c <_llm_rows.packet_batch.blocks+0x360>
     820:      	tbz	w14, #0x4, 0x868 <_llm_rows.packet_batch.blocks+0x36c>
     824:      	add	x15, x12, #0x10
     828:      	ld1.s	{ v1 }[0], [x15]
     82c:      	tbnz	w14, #0x5, 0x86c <_llm_rows.packet_batch.blocks+0x370>
     830:      	tbz	w14, #0x6, 0x878 <_llm_rows.packet_batch.blocks+0x37c>
     834:      	add	x15, x12, #0x18
     838:      	ld1.s	{ v1 }[2], [x15]
     83c:      	tbnz	w14, #0x7, 0x87c <_llm_rows.packet_batch.blocks+0x380>
     840:      	b	0x884 <_llm_rows.packet_batch.blocks+0x388>
     844:      	and	w14, w14, #0xff
     848:      	tbz	w14, #0x1, 0x810 <_llm_rows.packet_batch.blocks+0x314>
     84c:      	add	x15, x12, #0x4
     850:      	ld1.s	{ v2 }[1], [x15]
     854:      	tbnz	w14, #0x2, 0x814 <_llm_rows.packet_batch.blocks+0x318>
     858:      	tbz	w14, #0x3, 0x820 <_llm_rows.packet_batch.blocks+0x324>
     85c:      	add	x15, x12, #0xc
     860:      	ld1.s	{ v2 }[3], [x15]
     864:      	tbnz	w14, #0x4, 0x824 <_llm_rows.packet_batch.blocks+0x328>
     868:      	tbz	w14, #0x5, 0x830 <_llm_rows.packet_batch.blocks+0x334>
     86c:      	add	x15, x12, #0x14
     870:      	ld1.s	{ v1 }[1], [x15]
     874:      	tbnz	w14, #0x6, 0x834 <_llm_rows.packet_batch.blocks+0x338>
     878:      	tbz	w14, #0x7, 0x884 <_llm_rows.packet_batch.blocks+0x388>
     87c:      	add	x12, x12, #0x1c
     880:      	ld1.s	{ v1 }[3], [x12]
     884:      	umull.2d	v16, v30, v10
     888:      	fmov	w16, s17
     88c:      	fmov	x12, d16
     890:      	lsl	x12, x12, #2
     894:      	add	x14, x12, #0x84
     898:      	add	x15, x11, x14
     89c:      	movi.2d	v4, #0000000000000000
     8a0:      	movi.2d	v3, #0000000000000000
     8a4:      	tbz	w16, #0x0, 0x8e8 <_llm_rows.packet_batch.blocks+0x3ec>
     8a8:      	ldr	s4, [x15]
     8ac:      	and	w16, w16, #0xff
     8b0:      	tbnz	w16, #0x1, 0x8f0 <_llm_rows.packet_batch.blocks+0x3f4>
     8b4:      	tbz	w16, #0x2, 0x8fc <_llm_rows.packet_batch.blocks+0x400>
     8b8:      	add	x17, x15, #0x8
     8bc:      	ld1.s	{ v4 }[2], [x17]
     8c0:      	tbnz	w16, #0x3, 0x900 <_llm_rows.packet_batch.blocks+0x404>
     8c4:      	tbz	w16, #0x4, 0x90c <_llm_rows.packet_batch.blocks+0x410>
     8c8:      	add	x17, x15, #0x10
     8cc:      	ld1.s	{ v3 }[0], [x17]
     8d0:      	tbnz	w16, #0x5, 0x910 <_llm_rows.packet_batch.blocks+0x414>
     8d4:      	tbz	w16, #0x6, 0x91c <_llm_rows.packet_batch.blocks+0x420>
     8d8:      	add	x17, x15, #0x18
     8dc:      	ld1.s	{ v3 }[2], [x17]
     8e0:      	tbnz	w16, #0x7, 0x920 <_llm_rows.packet_batch.blocks+0x424>
     8e4:      	b	0x928 <_llm_rows.packet_batch.blocks+0x42c>
     8e8:      	and	w16, w16, #0xff
     8ec:      	tbz	w16, #0x1, 0x8b4 <_llm_rows.packet_batch.blocks+0x3b8>
     8f0:      	add	x17, x15, #0x4
     8f4:      	ld1.s	{ v4 }[1], [x17]
     8f8:      	tbnz	w16, #0x2, 0x8b8 <_llm_rows.packet_batch.blocks+0x3bc>
     8fc:      	tbz	w16, #0x3, 0x8c4 <_llm_rows.packet_batch.blocks+0x3c8>
     900:      	add	x17, x15, #0xc
     904:      	ld1.s	{ v4 }[3], [x17]
     908:      	tbnz	w16, #0x4, 0x8c8 <_llm_rows.packet_batch.blocks+0x3cc>
     90c:      	tbz	w16, #0x5, 0x8d4 <_llm_rows.packet_batch.blocks+0x3d8>
     910:      	add	x17, x15, #0x14
     914:      	ld1.s	{ v3 }[1], [x17]
     918:      	tbnz	w16, #0x6, 0x8d8 <_llm_rows.packet_batch.blocks+0x3dc>
     91c:      	tbz	w16, #0x7, 0x928 <_llm_rows.packet_batch.blocks+0x42c>
     920:      	add	x15, x15, #0x1c
     924:      	ld1.s	{ v3 }[3], [x15]
     928:      	fmov	w17, s17
     92c:      	mov.16b	v5, v7
     930:      	umlal.2d	v5, v30, v11
     934:      	fmov	x15, d5
     938:      	lsl	x15, x15, #2
     93c:      	add	x16, x10, x15
     940:      	movi.2d	v6, #0000000000000000
     944:      	movi.2d	v5, #0000000000000000
     948:      	tbz	w17, #0x0, 0xa94 <_llm_rows.packet_batch.blocks+0x598>
     94c:      	ldr	s6, [x16]
     950:      	and	w17, w17, #0xff
     954:      	tbnz	w17, #0x1, 0xa9c <_llm_rows.packet_batch.blocks+0x5a0>
     958:      	tbz	w17, #0x2, 0xaa8 <_llm_rows.packet_batch.blocks+0x5ac>
     95c:      	add	x0, x16, #0x8
     960:      	ld1.s	{ v6 }[2], [x0]
     964:      	tbnz	w17, #0x3, 0xaac <_llm_rows.packet_batch.blocks+0x5b0>
     968:      	tbz	w17, #0x4, 0xab8 <_llm_rows.packet_batch.blocks+0x5bc>
     96c:      	add	x0, x16, #0x10
     970:      	ld1.s	{ v5 }[0], [x0]
     974:      	tbnz	w17, #0x5, 0xabc <_llm_rows.packet_batch.blocks+0x5c0>
     978:      	tbz	w17, #0x6, 0xac8 <_llm_rows.packet_batch.blocks+0x5cc>
     97c:      	add	x0, x16, #0x18
     980:      	ld1.s	{ v5 }[2], [x0]
     984:      	tbnz	w17, #0x7, 0xacc <_llm_rows.packet_batch.blocks+0x5d0>
     988:      	fmov	w16, s17
     98c:      	add	x15, x9, x15
     990:      	movi.2d	v19, #0000000000000000
     994:      	movi.2d	v18, #0000000000000000
     998:      	tbz	w16, #0x0, 0xae8 <_llm_rows.packet_batch.blocks+0x5ec>
     99c:      	ldr	s19, [x15]
     9a0:      	and	w16, w16, #0xff
     9a4:      	tbnz	w16, #0x1, 0xaf0 <_llm_rows.packet_batch.blocks+0x5f4>
     9a8:      	tbz	w16, #0x2, 0xafc <_llm_rows.packet_batch.blocks+0x600>
     9ac:      	add	x17, x15, #0x8
     9b0:      	ld1.s	{ v19 }[2], [x17]
     9b4:      	tbnz	w16, #0x3, 0xb00 <_llm_rows.packet_batch.blocks+0x604>
     9b8:      	tbz	w16, #0x4, 0xb0c <_llm_rows.packet_batch.blocks+0x610>
     9bc:      	add	x17, x15, #0x10
     9c0:      	ld1.s	{ v18 }[0], [x17]
     9c4:      	tbnz	w16, #0x5, 0xb10 <_llm_rows.packet_batch.blocks+0x614>
     9c8:      	tbz	w16, #0x6, 0xb1c <_llm_rows.packet_batch.blocks+0x620>
     9cc:      	add	x17, x15, #0x18
     9d0:      	ld1.s	{ v18 }[2], [x17]
     9d4:      	tbnz	w16, #0x7, 0xb20 <_llm_rows.packet_batch.blocks+0x624>
     9d8:      	fmov	w15, s17
     9dc:      	fmul.4s	v20, v2, v6
     9e0:      	fmul.4s	v21, v4, v19
     9e4:      	fsub.4s	v20, v20, v21
     9e8:      	add	x13, x8, x13
     9ec:      	tbz	w15, #0x0, 0xb40 <_llm_rows.packet_batch.blocks+0x644>
     9f0:      	str	s20, [x13]
     9f4:      	and	w15, w15, #0xff
     9f8:      	tbnz	w15, #0x1, 0xb48 <_llm_rows.packet_batch.blocks+0x64c>
     9fc:      	tbz	w15, #0x2, 0xb54 <_llm_rows.packet_batch.blocks+0x658>
     a00:      	add	x16, x13, #0x8
     a04:      	st1.s	{ v20 }[2], [x16]
     a08:      	tbnz	w15, #0x3, 0xb58 <_llm_rows.packet_batch.blocks+0x65c>
     a0c:      	fmul.4s	v20, v1, v5
     a10:      	fmul.4s	v21, v3, v18
     a14:      	fsub.4s	v20, v20, v21
     a18:      	tbz	w15, #0x4, 0xb70 <_llm_rows.packet_batch.blocks+0x674>
     a1c:      	str	s20, [x13, #0x10]
     a20:      	tbnz	w15, #0x5, 0xb74 <_llm_rows.packet_batch.blocks+0x678>
     a24:      	tbz	w15, #0x6, 0xb80 <_llm_rows.packet_batch.blocks+0x684>
     a28:      	add	x16, x13, #0x18
     a2c:      	st1.s	{ v20 }[2], [x16]
     a30:      	tbnz	w15, #0x7, 0xb84 <_llm_rows.packet_batch.blocks+0x688>
     a34:      	fmov	w15, s17
     a38:      	fmul.4s	v2, v2, v19
     a3c:      	fmul.4s	v4, v4, v6
     a40:      	fadd.4s	v2, v4, v2
     a44:      	add	x13, x8, x14
     a48:      	tbz	w15, #0x0, 0xba4 <_llm_rows.packet_batch.blocks+0x6a8>
     a4c:      	str	s2, [x13]
     a50:      	and	w14, w15, #0xff
     a54:      	tbnz	w14, #0x1, 0xbac <_llm_rows.packet_batch.blocks+0x6b0>
     a58:      	tbz	w14, #0x2, 0xbb8 <_llm_rows.packet_batch.blocks+0x6bc>
     a5c:      	add	x15, x13, #0x8
     a60:      	st1.s	{ v2 }[2], [x15]
     a64:      	tbnz	w14, #0x3, 0xbbc <_llm_rows.packet_batch.blocks+0x6c0>
     a68:      	fmul.4s	v1, v1, v18
     a6c:      	fmul.4s	v2, v3, v5
     a70:      	fadd.4s	v1, v2, v1
     a74:      	tbz	w14, #0x4, 0xbd4 <_llm_rows.packet_batch.blocks+0x6d8>
     a78:      	str	s1, [x13, #0x10]
     a7c:      	tbnz	w14, #0x5, 0xbd8 <_llm_rows.packet_batch.blocks+0x6dc>
     a80:      	tbz	w14, #0x6, 0xbe4 <_llm_rows.packet_batch.blocks+0x6e8>
     a84:      	add	x15, x13, #0x18
     a88:      	st1.s	{ v1 }[2], [x15]
     a8c:      	tbnz	w14, #0x7, 0xbe8 <_llm_rows.packet_batch.blocks+0x6ec>
     a90:      	b	0xbf0 <_llm_rows.packet_batch.blocks+0x6f4>
     a94:      	and	w17, w17, #0xff
     a98:      	tbz	w17, #0x1, 0x958 <_llm_rows.packet_batch.blocks+0x45c>
     a9c:      	add	x0, x16, #0x4
     aa0:      	ld1.s	{ v6 }[1], [x0]
     aa4:      	tbnz	w17, #0x2, 0x95c <_llm_rows.packet_batch.blocks+0x460>
     aa8:      	tbz	w17, #0x3, 0x968 <_llm_rows.packet_batch.blocks+0x46c>
     aac:      	add	x0, x16, #0xc
     ab0:      	ld1.s	{ v6 }[3], [x0]
     ab4:      	tbnz	w17, #0x4, 0x96c <_llm_rows.packet_batch.blocks+0x470>
     ab8:      	tbz	w17, #0x5, 0x978 <_llm_rows.packet_batch.blocks+0x47c>
     abc:      	add	x0, x16, #0x14
     ac0:      	ld1.s	{ v5 }[1], [x0]
     ac4:      	tbnz	w17, #0x6, 0x97c <_llm_rows.packet_batch.blocks+0x480>
     ac8:      	tbz	w17, #0x7, 0x988 <_llm_rows.packet_batch.blocks+0x48c>
     acc:      	add	x16, x16, #0x1c
     ad0:      	ld1.s	{ v5 }[3], [x16]
     ad4:      	fmov	w16, s17
     ad8:      	add	x15, x9, x15
     adc:      	movi.2d	v19, #0000000000000000
     ae0:      	movi.2d	v18, #0000000000000000
     ae4:      	tbnz	w16, #0x0, 0x99c <_llm_rows.packet_batch.blocks+0x4a0>
     ae8:      	and	w16, w16, #0xff
     aec:      	tbz	w16, #0x1, 0x9a8 <_llm_rows.packet_batch.blocks+0x4ac>
     af0:      	add	x17, x15, #0x4
     af4:      	ld1.s	{ v19 }[1], [x17]
     af8:      	tbnz	w16, #0x2, 0x9ac <_llm_rows.packet_batch.blocks+0x4b0>
     afc:      	tbz	w16, #0x3, 0x9b8 <_llm_rows.packet_batch.blocks+0x4bc>
     b00:      	add	x17, x15, #0xc
     b04:      	ld1.s	{ v19 }[3], [x17]
     b08:      	tbnz	w16, #0x4, 0x9bc <_llm_rows.packet_batch.blocks+0x4c0>
     b0c:      	tbz	w16, #0x5, 0x9c8 <_llm_rows.packet_batch.blocks+0x4cc>
     b10:      	add	x17, x15, #0x14
     b14:      	ld1.s	{ v18 }[1], [x17]
     b18:      	tbnz	w16, #0x6, 0x9cc <_llm_rows.packet_batch.blocks+0x4d0>
     b1c:      	tbz	w16, #0x7, 0x9d8 <_llm_rows.packet_batch.blocks+0x4dc>
     b20:      	add	x15, x15, #0x1c
     b24:      	ld1.s	{ v18 }[3], [x15]
     b28:      	fmov	w15, s17
     b2c:      	fmul.4s	v20, v2, v6
     b30:      	fmul.4s	v21, v4, v19
     b34:      	fsub.4s	v20, v20, v21
     b38:      	add	x13, x8, x13
     b3c:      	tbnz	w15, #0x0, 0x9f0 <_llm_rows.packet_batch.blocks+0x4f4>
     b40:      	and	w15, w15, #0xff
     b44:      	tbz	w15, #0x1, 0x9fc <_llm_rows.packet_batch.blocks+0x500>
     b48:      	add	x16, x13, #0x4
     b4c:      	st1.s	{ v20 }[1], [x16]
     b50:      	tbnz	w15, #0x2, 0xa00 <_llm_rows.packet_batch.blocks+0x504>
     b54:      	tbz	w15, #0x3, 0xa0c <_llm_rows.packet_batch.blocks+0x510>
     b58:      	add	x16, x13, #0xc
     b5c:      	st1.s	{ v20 }[3], [x16]
     b60:      	fmul.4s	v20, v1, v5
     b64:      	fmul.4s	v21, v3, v18
     b68:      	fsub.4s	v20, v20, v21
     b6c:      	tbnz	w15, #0x4, 0xa1c <_llm_rows.packet_batch.blocks+0x520>
     b70:      	tbz	w15, #0x5, 0xa24 <_llm_rows.packet_batch.blocks+0x528>
     b74:      	add	x16, x13, #0x14
     b78:      	st1.s	{ v20 }[1], [x16]
     b7c:      	tbnz	w15, #0x6, 0xa28 <_llm_rows.packet_batch.blocks+0x52c>
     b80:      	tbz	w15, #0x7, 0xa34 <_llm_rows.packet_batch.blocks+0x538>
     b84:      	add	x13, x13, #0x1c
     b88:      	st1.s	{ v20 }[3], [x13]
     b8c:      	fmov	w15, s17
     b90:      	fmul.4s	v2, v2, v19
     b94:      	fmul.4s	v4, v4, v6
     b98:      	fadd.4s	v2, v4, v2
     b9c:      	add	x13, x8, x14
     ba0:      	tbnz	w15, #0x0, 0xa4c <_llm_rows.packet_batch.blocks+0x550>
     ba4:      	and	w14, w15, #0xff
     ba8:      	tbz	w14, #0x1, 0xa58 <_llm_rows.packet_batch.blocks+0x55c>
     bac:      	add	x15, x13, #0x4
     bb0:      	st1.s	{ v2 }[1], [x15]
     bb4:      	tbnz	w14, #0x2, 0xa5c <_llm_rows.packet_batch.blocks+0x560>
     bb8:      	tbz	w14, #0x3, 0xa68 <_llm_rows.packet_batch.blocks+0x56c>
     bbc:      	add	x15, x13, #0xc
     bc0:      	st1.s	{ v2 }[3], [x15]
     bc4:      	fmul.4s	v1, v1, v18
     bc8:      	fmul.4s	v2, v3, v5
     bcc:      	fadd.4s	v1, v2, v1
     bd0:      	tbnz	w14, #0x4, 0xa78 <_llm_rows.packet_batch.blocks+0x57c>
     bd4:      	tbz	w14, #0x5, 0xa80 <_llm_rows.packet_batch.blocks+0x584>
     bd8:      	add	x15, x13, #0x14
     bdc:      	st1.s	{ v1 }[1], [x15]
     be0:      	tbnz	w14, #0x6, 0xa84 <_llm_rows.packet_batch.blocks+0x588>
     be4:      	tbz	w14, #0x7, 0xbf0 <_llm_rows.packet_batch.blocks+0x6f4>
     be8:      	add	x13, x13, #0x1c
     bec:      	st1.s	{ v1 }[3], [x13]
     bf0:      	fmov	w15, s17
     bf4:      	mov	w13, #0x8               ; =8
     bf8:      	dup.2d	v1, x13
     bfc:      	orr.16b	v5, v7, v1
     c00:      	add.2d	v1, v16, v5
     c04:      	fmov	x13, d1
     c08:      	lsl	x13, x13, #2
     c0c:      	add	x14, x11, x13
     c10:      	movi.2d	v2, #0000000000000000
     c14:      	movi.2d	v1, #0000000000000000
     c18:      	tbz	w15, #0x0, 0xcb0 <_llm_rows.packet_batch.blocks+0x7b4>
     c1c:      	ldr	s2, [x14]
     c20:      	and	w15, w15, #0xff
     c24:      	tbnz	w15, #0x1, 0xcb8 <_llm_rows.packet_batch.blocks+0x7bc>
     c28:      	tbz	w15, #0x2, 0xcc4 <_llm_rows.packet_batch.blocks+0x7c8>
     c2c:      	add	x16, x14, #0x8
     c30:      	ld1.s	{ v2 }[2], [x16]
     c34:      	tbnz	w15, #0x3, 0xcc8 <_llm_rows.packet_batch.blocks+0x7cc>
     c38:      	tbz	w15, #0x4, 0xcd4 <_llm_rows.packet_batch.blocks+0x7d8>
     c3c:      	add	x16, x14, #0x10
     c40:      	ld1.s	{ v1 }[0], [x16]
     c44:      	tbnz	w15, #0x5, 0xcd8 <_llm_rows.packet_batch.blocks+0x7dc>
     c48:      	tbz	w15, #0x6, 0xce4 <_llm_rows.packet_batch.blocks+0x7e8>
     c4c:      	add	x16, x14, #0x18
     c50:      	ld1.s	{ v1 }[2], [x16]
     c54:      	tbnz	w15, #0x7, 0xce8 <_llm_rows.packet_batch.blocks+0x7ec>
     c58:      	fmov	w16, s17
     c5c:      	add	x14, x12, #0xa4
     c60:      	add	x15, x11, x14
     c64:      	movi.2d	v4, #0000000000000000
     c68:      	movi.2d	v3, #0000000000000000
     c6c:      	tbz	w16, #0x0, 0xd08 <_llm_rows.packet_batch.blocks+0x80c>
     c70:      	ldr	s4, [x15]
     c74:      	and	w16, w16, #0xff
     c78:      	tbnz	w16, #0x1, 0xd10 <_llm_rows.packet_batch.blocks+0x814>
     c7c:      	tbz	w16, #0x2, 0xd1c <_llm_rows.packet_batch.blocks+0x820>
     c80:      	add	x17, x15, #0x8
     c84:      	ld1.s	{ v4 }[2], [x17]
     c88:      	tbnz	w16, #0x3, 0xd20 <_llm_rows.packet_batch.blocks+0x824>
     c8c:      	tbz	w16, #0x4, 0xd2c <_llm_rows.packet_batch.blocks+0x830>
     c90:      	add	x17, x15, #0x10
     c94:      	ld1.s	{ v3 }[0], [x17]
     c98:      	tbnz	w16, #0x5, 0xd30 <_llm_rows.packet_batch.blocks+0x834>
     c9c:      	tbz	w16, #0x6, 0xd3c <_llm_rows.packet_batch.blocks+0x840>
     ca0:      	add	x17, x15, #0x18
     ca4:      	ld1.s	{ v3 }[2], [x17]
     ca8:      	tbnz	w16, #0x7, 0xd40 <_llm_rows.packet_batch.blocks+0x844>
     cac:      	b	0xd48 <_llm_rows.packet_batch.blocks+0x84c>
     cb0:      	and	w15, w15, #0xff
     cb4:      	tbz	w15, #0x1, 0xc28 <_llm_rows.packet_batch.blocks+0x72c>
     cb8:      	add	x16, x14, #0x4
     cbc:      	ld1.s	{ v2 }[1], [x16]
     cc0:      	tbnz	w15, #0x2, 0xc2c <_llm_rows.packet_batch.blocks+0x730>
     cc4:      	tbz	w15, #0x3, 0xc38 <_llm_rows.packet_batch.blocks+0x73c>
     cc8:      	add	x16, x14, #0xc
     ccc:      	ld1.s	{ v2 }[3], [x16]
     cd0:      	tbnz	w15, #0x4, 0xc3c <_llm_rows.packet_batch.blocks+0x740>
     cd4:      	tbz	w15, #0x5, 0xc48 <_llm_rows.packet_batch.blocks+0x74c>
     cd8:      	add	x16, x14, #0x14
     cdc:      	ld1.s	{ v1 }[1], [x16]
     ce0:      	tbnz	w15, #0x6, 0xc4c <_llm_rows.packet_batch.blocks+0x750>
     ce4:      	tbz	w15, #0x7, 0xc58 <_llm_rows.packet_batch.blocks+0x75c>
     ce8:      	add	x14, x14, #0x1c
     cec:      	ld1.s	{ v1 }[3], [x14]
     cf0:      	fmov	w16, s17
     cf4:      	add	x14, x12, #0xa4
     cf8:      	add	x15, x11, x14
     cfc:      	movi.2d	v4, #0000000000000000
     d00:      	movi.2d	v3, #0000000000000000
     d04:      	tbnz	w16, #0x0, 0xc70 <_llm_rows.packet_batch.blocks+0x774>
     d08:      	and	w16, w16, #0xff
     d0c:      	tbz	w16, #0x1, 0xc7c <_llm_rows.packet_batch.blocks+0x780>
     d10:      	add	x17, x15, #0x4
     d14:      	ld1.s	{ v4 }[1], [x17]
     d18:      	tbnz	w16, #0x2, 0xc80 <_llm_rows.packet_batch.blocks+0x784>
     d1c:      	tbz	w16, #0x3, 0xc8c <_llm_rows.packet_batch.blocks+0x790>
     d20:      	add	x17, x15, #0xc
     d24:      	ld1.s	{ v4 }[3], [x17]
     d28:      	tbnz	w16, #0x4, 0xc90 <_llm_rows.packet_batch.blocks+0x794>
     d2c:      	tbz	w16, #0x5, 0xc9c <_llm_rows.packet_batch.blocks+0x7a0>
     d30:      	add	x17, x15, #0x14
     d34:      	ld1.s	{ v3 }[1], [x17]
     d38:      	tbnz	w16, #0x6, 0xca0 <_llm_rows.packet_batch.blocks+0x7a4>
     d3c:      	tbz	w16, #0x7, 0xd48 <_llm_rows.packet_batch.blocks+0x84c>
     d40:      	add	x15, x15, #0x1c
     d44:      	ld1.s	{ v3 }[3], [x15]
     d48:      	umull.2d	v18, v30, v11
     d4c:      	fmov	w17, s17
     d50:      	add.2d	v5, v18, v5
     d54:      	fmov	x15, d5
     d58:      	lsl	x15, x15, #2
     d5c:      	add	x16, x10, x15
     d60:      	movi.2d	v6, #0000000000000000
     d64:      	movi.2d	v5, #0000000000000000
     d68:      	tbz	w17, #0x0, 0xeb4 <_llm_rows.packet_batch.blocks+0x9b8>
     d6c:      	ldr	s6, [x16]
     d70:      	and	w17, w17, #0xff
     d74:      	tbnz	w17, #0x1, 0xebc <_llm_rows.packet_batch.blocks+0x9c0>
     d78:      	tbz	w17, #0x2, 0xec8 <_llm_rows.packet_batch.blocks+0x9cc>
     d7c:      	add	x0, x16, #0x8
     d80:      	ld1.s	{ v6 }[2], [x0]
     d84:      	tbnz	w17, #0x3, 0xecc <_llm_rows.packet_batch.blocks+0x9d0>
     d88:      	tbz	w17, #0x4, 0xed8 <_llm_rows.packet_batch.blocks+0x9dc>
     d8c:      	add	x0, x16, #0x10
     d90:      	ld1.s	{ v5 }[0], [x0]
     d94:      	tbnz	w17, #0x5, 0xedc <_llm_rows.packet_batch.blocks+0x9e0>
     d98:      	tbz	w17, #0x6, 0xee8 <_llm_rows.packet_batch.blocks+0x9ec>
     d9c:      	add	x0, x16, #0x18
     da0:      	ld1.s	{ v5 }[2], [x0]
     da4:      	tbnz	w17, #0x7, 0xeec <_llm_rows.packet_batch.blocks+0x9f0>
     da8:      	fmov	w16, s17
     dac:      	add	x15, x9, x15
     db0:      	movi.2d	v20, #0000000000000000
     db4:      	movi.2d	v19, #0000000000000000
     db8:      	tbz	w16, #0x0, 0xf08 <_llm_rows.packet_batch.blocks+0xa0c>
     dbc:      	ldr	s20, [x15]
     dc0:      	and	w16, w16, #0xff
     dc4:      	tbnz	w16, #0x1, 0xf10 <_llm_rows.packet_batch.blocks+0xa14>
     dc8:      	tbz	w16, #0x2, 0xf1c <_llm_rows.packet_batch.blocks+0xa20>
     dcc:      	add	x17, x15, #0x8
     dd0:      	ld1.s	{ v20 }[2], [x17]
     dd4:      	tbnz	w16, #0x3, 0xf20 <_llm_rows.packet_batch.blocks+0xa24>
     dd8:      	tbz	w16, #0x4, 0xf2c <_llm_rows.packet_batch.blocks+0xa30>
     ddc:      	add	x17, x15, #0x10
     de0:      	ld1.s	{ v19 }[0], [x17]
     de4:      	tbnz	w16, #0x5, 0xf30 <_llm_rows.packet_batch.blocks+0xa34>
     de8:      	tbz	w16, #0x6, 0xf3c <_llm_rows.packet_batch.blocks+0xa40>
     dec:      	add	x17, x15, #0x18
     df0:      	ld1.s	{ v19 }[2], [x17]
     df4:      	tbnz	w16, #0x7, 0xf40 <_llm_rows.packet_batch.blocks+0xa44>
     df8:      	fmov	w15, s17
     dfc:      	fmul.4s	v21, v2, v6
     e00:      	fmul.4s	v22, v4, v20
     e04:      	fsub.4s	v21, v21, v22
     e08:      	add	x13, x8, x13
     e0c:      	tbz	w15, #0x0, 0xf60 <_llm_rows.packet_batch.blocks+0xa64>
     e10:      	str	s21, [x13]
     e14:      	and	w15, w15, #0xff
     e18:      	tbnz	w15, #0x1, 0xf68 <_llm_rows.packet_batch.blocks+0xa6c>
     e1c:      	tbz	w15, #0x2, 0xf74 <_llm_rows.packet_batch.blocks+0xa78>
     e20:      	add	x16, x13, #0x8
     e24:      	st1.s	{ v21 }[2], [x16]
     e28:      	tbnz	w15, #0x3, 0xf78 <_llm_rows.packet_batch.blocks+0xa7c>
     e2c:      	fmul.4s	v21, v1, v5
     e30:      	fmul.4s	v22, v3, v19
     e34:      	fsub.4s	v21, v21, v22
     e38:      	tbz	w15, #0x4, 0xf90 <_llm_rows.packet_batch.blocks+0xa94>
     e3c:      	str	s21, [x13, #0x10]
     e40:      	tbnz	w15, #0x5, 0xf94 <_llm_rows.packet_batch.blocks+0xa98>
     e44:      	tbz	w15, #0x6, 0xfa0 <_llm_rows.packet_batch.blocks+0xaa4>
     e48:      	add	x16, x13, #0x18
     e4c:      	st1.s	{ v21 }[2], [x16]
     e50:      	tbnz	w15, #0x7, 0xfa4 <_llm_rows.packet_batch.blocks+0xaa8>
     e54:      	fmov	w15, s17
     e58:      	fmul.4s	v2, v2, v20
     e5c:      	fmul.4s	v4, v4, v6
     e60:      	fadd.4s	v2, v4, v2
     e64:      	add	x13, x8, x14
     e68:      	tbz	w15, #0x0, 0xfc4 <_llm_rows.packet_batch.blocks+0xac8>
     e6c:      	str	s2, [x13]
     e70:      	and	w14, w15, #0xff
     e74:      	tbnz	w14, #0x1, 0xfcc <_llm_rows.packet_batch.blocks+0xad0>
     e78:      	tbz	w14, #0x2, 0xfd8 <_llm_rows.packet_batch.blocks+0xadc>
     e7c:      	add	x15, x13, #0x8
     e80:      	st1.s	{ v2 }[2], [x15]
     e84:      	tbnz	w14, #0x3, 0xfdc <_llm_rows.packet_batch.blocks+0xae0>
     e88:      	fmul.4s	v1, v1, v19
     e8c:      	fmul.4s	v2, v3, v5
     e90:      	fadd.4s	v1, v2, v1
     e94:      	tbz	w14, #0x4, 0xff4 <_llm_rows.packet_batch.blocks+0xaf8>
     e98:      	str	s1, [x13, #0x10]
     e9c:      	tbnz	w14, #0x5, 0xff8 <_llm_rows.packet_batch.blocks+0xafc>
     ea0:      	tbz	w14, #0x6, 0x1004 <_llm_rows.packet_batch.blocks+0xb08>
     ea4:      	add	x15, x13, #0x18
     ea8:      	st1.s	{ v1 }[2], [x15]
     eac:      	tbnz	w14, #0x7, 0x1008 <_llm_rows.packet_batch.blocks+0xb0c>
     eb0:      	b	0x1010 <_llm_rows.packet_batch.blocks+0xb14>
     eb4:      	and	w17, w17, #0xff
     eb8:      	tbz	w17, #0x1, 0xd78 <_llm_rows.packet_batch.blocks+0x87c>
     ebc:      	add	x0, x16, #0x4
     ec0:      	ld1.s	{ v6 }[1], [x0]
     ec4:      	tbnz	w17, #0x2, 0xd7c <_llm_rows.packet_batch.blocks+0x880>
     ec8:      	tbz	w17, #0x3, 0xd88 <_llm_rows.packet_batch.blocks+0x88c>
     ecc:      	add	x0, x16, #0xc
     ed0:      	ld1.s	{ v6 }[3], [x0]
     ed4:      	tbnz	w17, #0x4, 0xd8c <_llm_rows.packet_batch.blocks+0x890>
     ed8:      	tbz	w17, #0x5, 0xd98 <_llm_rows.packet_batch.blocks+0x89c>
     edc:      	add	x0, x16, #0x14
     ee0:      	ld1.s	{ v5 }[1], [x0]
     ee4:      	tbnz	w17, #0x6, 0xd9c <_llm_rows.packet_batch.blocks+0x8a0>
     ee8:      	tbz	w17, #0x7, 0xda8 <_llm_rows.packet_batch.blocks+0x8ac>
     eec:      	add	x16, x16, #0x1c
     ef0:      	ld1.s	{ v5 }[3], [x16]
     ef4:      	fmov	w16, s17
     ef8:      	add	x15, x9, x15
     efc:      	movi.2d	v20, #0000000000000000
     f00:      	movi.2d	v19, #0000000000000000
     f04:      	tbnz	w16, #0x0, 0xdbc <_llm_rows.packet_batch.blocks+0x8c0>
     f08:      	and	w16, w16, #0xff
     f0c:      	tbz	w16, #0x1, 0xdc8 <_llm_rows.packet_batch.blocks+0x8cc>
     f10:      	add	x17, x15, #0x4
     f14:      	ld1.s	{ v20 }[1], [x17]
     f18:      	tbnz	w16, #0x2, 0xdcc <_llm_rows.packet_batch.blocks+0x8d0>
     f1c:      	tbz	w16, #0x3, 0xdd8 <_llm_rows.packet_batch.blocks+0x8dc>
     f20:      	add	x17, x15, #0xc
     f24:      	ld1.s	{ v20 }[3], [x17]
     f28:      	tbnz	w16, #0x4, 0xddc <_llm_rows.packet_batch.blocks+0x8e0>
     f2c:      	tbz	w16, #0x5, 0xde8 <_llm_rows.packet_batch.blocks+0x8ec>
     f30:      	add	x17, x15, #0x14
     f34:      	ld1.s	{ v19 }[1], [x17]
     f38:      	tbnz	w16, #0x6, 0xdec <_llm_rows.packet_batch.blocks+0x8f0>
     f3c:      	tbz	w16, #0x7, 0xdf8 <_llm_rows.packet_batch.blocks+0x8fc>
     f40:      	add	x15, x15, #0x1c
     f44:      	ld1.s	{ v19 }[3], [x15]
     f48:      	fmov	w15, s17
     f4c:      	fmul.4s	v21, v2, v6
     f50:      	fmul.4s	v22, v4, v20
     f54:      	fsub.4s	v21, v21, v22
     f58:      	add	x13, x8, x13
     f5c:      	tbnz	w15, #0x0, 0xe10 <_llm_rows.packet_batch.blocks+0x914>
     f60:      	and	w15, w15, #0xff
     f64:      	tbz	w15, #0x1, 0xe1c <_llm_rows.packet_batch.blocks+0x920>
     f68:      	add	x16, x13, #0x4
     f6c:      	st1.s	{ v21 }[1], [x16]
     f70:      	tbnz	w15, #0x2, 0xe20 <_llm_rows.packet_batch.blocks+0x924>
     f74:      	tbz	w15, #0x3, 0xe2c <_llm_rows.packet_batch.blocks+0x930>
     f78:      	add	x16, x13, #0xc
     f7c:      	st1.s	{ v21 }[3], [x16]
     f80:      	fmul.4s	v21, v1, v5
     f84:      	fmul.4s	v22, v3, v19
     f88:      	fsub.4s	v21, v21, v22
     f8c:      	tbnz	w15, #0x4, 0xe3c <_llm_rows.packet_batch.blocks+0x940>
     f90:      	tbz	w15, #0x5, 0xe44 <_llm_rows.packet_batch.blocks+0x948>
     f94:      	add	x16, x13, #0x14
     f98:      	st1.s	{ v21 }[1], [x16]
     f9c:      	tbnz	w15, #0x6, 0xe48 <_llm_rows.packet_batch.blocks+0x94c>
     fa0:      	tbz	w15, #0x7, 0xe54 <_llm_rows.packet_batch.blocks+0x958>
     fa4:      	add	x13, x13, #0x1c
     fa8:      	st1.s	{ v21 }[3], [x13]
     fac:      	fmov	w15, s17
     fb0:      	fmul.4s	v2, v2, v20
     fb4:      	fmul.4s	v4, v4, v6
     fb8:      	fadd.4s	v2, v4, v2
     fbc:      	add	x13, x8, x14
     fc0:      	tbnz	w15, #0x0, 0xe6c <_llm_rows.packet_batch.blocks+0x970>
     fc4:      	and	w14, w15, #0xff
     fc8:      	tbz	w14, #0x1, 0xe78 <_llm_rows.packet_batch.blocks+0x97c>
     fcc:      	add	x15, x13, #0x4
     fd0:      	st1.s	{ v2 }[1], [x15]
     fd4:      	tbnz	w14, #0x2, 0xe7c <_llm_rows.packet_batch.blocks+0x980>
     fd8:      	tbz	w14, #0x3, 0xe88 <_llm_rows.packet_batch.blocks+0x98c>
     fdc:      	add	x15, x13, #0xc
     fe0:      	st1.s	{ v2 }[3], [x15]
     fe4:      	fmul.4s	v1, v1, v19
     fe8:      	fmul.4s	v2, v3, v5
     fec:      	fadd.4s	v1, v2, v1
     ff0:      	tbnz	w14, #0x4, 0xe98 <_llm_rows.packet_batch.blocks+0x99c>
     ff4:      	tbz	w14, #0x5, 0xea0 <_llm_rows.packet_batch.blocks+0x9a4>
     ff8:      	add	x15, x13, #0x14
     ffc:      	st1.s	{ v1 }[1], [x15]
    1000:      	tbnz	w14, #0x6, 0xea4 <_llm_rows.packet_batch.blocks+0x9a8>
    1004:      	tbz	w14, #0x7, 0x1010 <_llm_rows.packet_batch.blocks+0xb14>
    1008:      	add	x13, x13, #0x1c
    100c:      	st1.s	{ v1 }[3], [x13]
    1010:      	fmov	w15, s17
    1014:      	mov	w13, #0x10              ; =16
    1018:      	dup.2d	v1, x13
    101c:      	orr.16b	v5, v7, v1
    1020:      	add.2d	v1, v16, v5
    1024:      	fmov	x13, d1
    1028:      	lsl	x13, x13, #2
    102c:      	add	x14, x11, x13
    1030:      	movi.2d	v2, #0000000000000000
    1034:      	movi.2d	v1, #0000000000000000
    1038:      	tbz	w15, #0x0, 0x10d0 <_llm_rows.packet_batch.blocks+0xbd4>
    103c:      	ldr	s2, [x14]
    1040:      	and	w15, w15, #0xff
    1044:      	tbnz	w15, #0x1, 0x10d8 <_llm_rows.packet_batch.blocks+0xbdc>
    1048:      	tbz	w15, #0x2, 0x10e4 <_llm_rows.packet_batch.blocks+0xbe8>
    104c:      	add	x16, x14, #0x8
    1050:      	ld1.s	{ v2 }[2], [x16]
    1054:      	tbnz	w15, #0x3, 0x10e8 <_llm_rows.packet_batch.blocks+0xbec>
    1058:      	tbz	w15, #0x4, 0x10f4 <_llm_rows.packet_batch.blocks+0xbf8>
    105c:      	add	x16, x14, #0x10
    1060:      	ld1.s	{ v1 }[0], [x16]
    1064:      	tbnz	w15, #0x5, 0x10f8 <_llm_rows.packet_batch.blocks+0xbfc>
    1068:      	tbz	w15, #0x6, 0x1104 <_llm_rows.packet_batch.blocks+0xc08>
    106c:      	add	x16, x14, #0x18
    1070:      	ld1.s	{ v1 }[2], [x16]
    1074:      	tbnz	w15, #0x7, 0x1108 <_llm_rows.packet_batch.blocks+0xc0c>
    1078:      	fmov	w16, s17
    107c:      	add	x14, x12, #0xc4
    1080:      	add	x15, x11, x14
    1084:      	movi.2d	v4, #0000000000000000
    1088:      	movi.2d	v3, #0000000000000000
    108c:      	tbz	w16, #0x0, 0x1128 <_llm_rows.packet_batch.blocks+0xc2c>
    1090:      	ldr	s4, [x15]
    1094:      	and	w16, w16, #0xff
    1098:      	tbnz	w16, #0x1, 0x1130 <_llm_rows.packet_batch.blocks+0xc34>
    109c:      	tbz	w16, #0x2, 0x113c <_llm_rows.packet_batch.blocks+0xc40>
    10a0:      	add	x17, x15, #0x8
    10a4:      	ld1.s	{ v4 }[2], [x17]
    10a8:      	tbnz	w16, #0x3, 0x1140 <_llm_rows.packet_batch.blocks+0xc44>
    10ac:      	tbz	w16, #0x4, 0x114c <_llm_rows.packet_batch.blocks+0xc50>
    10b0:      	add	x17, x15, #0x10
    10b4:      	ld1.s	{ v3 }[0], [x17]
    10b8:      	tbnz	w16, #0x5, 0x1150 <_llm_rows.packet_batch.blocks+0xc54>
    10bc:      	tbz	w16, #0x6, 0x115c <_llm_rows.packet_batch.blocks+0xc60>
    10c0:      	add	x17, x15, #0x18
    10c4:      	ld1.s	{ v3 }[2], [x17]
    10c8:      	tbnz	w16, #0x7, 0x1160 <_llm_rows.packet_batch.blocks+0xc64>
    10cc:      	b	0x1168 <_llm_rows.packet_batch.blocks+0xc6c>
    10d0:      	and	w15, w15, #0xff
    10d4:      	tbz	w15, #0x1, 0x1048 <_llm_rows.packet_batch.blocks+0xb4c>
    10d8:      	add	x16, x14, #0x4
    10dc:      	ld1.s	{ v2 }[1], [x16]
    10e0:      	tbnz	w15, #0x2, 0x104c <_llm_rows.packet_batch.blocks+0xb50>
    10e4:      	tbz	w15, #0x3, 0x1058 <_llm_rows.packet_batch.blocks+0xb5c>
    10e8:      	add	x16, x14, #0xc
    10ec:      	ld1.s	{ v2 }[3], [x16]
    10f0:      	tbnz	w15, #0x4, 0x105c <_llm_rows.packet_batch.blocks+0xb60>
    10f4:      	tbz	w15, #0x5, 0x1068 <_llm_rows.packet_batch.blocks+0xb6c>
    10f8:      	add	x16, x14, #0x14
    10fc:      	ld1.s	{ v1 }[1], [x16]
    1100:      	tbnz	w15, #0x6, 0x106c <_llm_rows.packet_batch.blocks+0xb70>
    1104:      	tbz	w15, #0x7, 0x1078 <_llm_rows.packet_batch.blocks+0xb7c>
    1108:      	add	x14, x14, #0x1c
    110c:      	ld1.s	{ v1 }[3], [x14]
    1110:      	fmov	w16, s17
    1114:      	add	x14, x12, #0xc4
    1118:      	add	x15, x11, x14
    111c:      	movi.2d	v4, #0000000000000000
    1120:      	movi.2d	v3, #0000000000000000
    1124:      	tbnz	w16, #0x0, 0x1090 <_llm_rows.packet_batch.blocks+0xb94>
    1128:      	and	w16, w16, #0xff
    112c:      	tbz	w16, #0x1, 0x109c <_llm_rows.packet_batch.blocks+0xba0>
    1130:      	add	x17, x15, #0x4
    1134:      	ld1.s	{ v4 }[1], [x17]
    1138:      	tbnz	w16, #0x2, 0x10a0 <_llm_rows.packet_batch.blocks+0xba4>
    113c:      	tbz	w16, #0x3, 0x10ac <_llm_rows.packet_batch.blocks+0xbb0>
    1140:      	add	x17, x15, #0xc
    1144:      	ld1.s	{ v4 }[3], [x17]
    1148:      	tbnz	w16, #0x4, 0x10b0 <_llm_rows.packet_batch.blocks+0xbb4>
    114c:      	tbz	w16, #0x5, 0x10bc <_llm_rows.packet_batch.blocks+0xbc0>
    1150:      	add	x17, x15, #0x14
    1154:      	ld1.s	{ v3 }[1], [x17]
    1158:      	tbnz	w16, #0x6, 0x10c0 <_llm_rows.packet_batch.blocks+0xbc4>
    115c:      	tbz	w16, #0x7, 0x1168 <_llm_rows.packet_batch.blocks+0xc6c>
    1160:      	add	x15, x15, #0x1c
    1164:      	ld1.s	{ v3 }[3], [x15]
    1168:      	fmov	w17, s17
    116c:      	add.2d	v5, v18, v5
    1170:      	fmov	x15, d5
    1174:      	lsl	x15, x15, #2
    1178:      	add	x16, x10, x15
    117c:      	movi.2d	v6, #0000000000000000
    1180:      	movi.2d	v5, #0000000000000000
    1184:      	tbz	w17, #0x0, 0x12d0 <_llm_rows.packet_batch.blocks+0xdd4>
    1188:      	ldr	s6, [x16]
    118c:      	and	w17, w17, #0xff
    1190:      	tbnz	w17, #0x1, 0x12d8 <_llm_rows.packet_batch.blocks+0xddc>
    1194:      	tbz	w17, #0x2, 0x12e4 <_llm_rows.packet_batch.blocks+0xde8>
    1198:      	add	x0, x16, #0x8
    119c:      	ld1.s	{ v6 }[2], [x0]
    11a0:      	tbnz	w17, #0x3, 0x12e8 <_llm_rows.packet_batch.blocks+0xdec>
    11a4:      	tbz	w17, #0x4, 0x12f4 <_llm_rows.packet_batch.blocks+0xdf8>
    11a8:      	add	x0, x16, #0x10
    11ac:      	ld1.s	{ v5 }[0], [x0]
    11b0:      	tbnz	w17, #0x5, 0x12f8 <_llm_rows.packet_batch.blocks+0xdfc>
    11b4:      	tbz	w17, #0x6, 0x1304 <_llm_rows.packet_batch.blocks+0xe08>
    11b8:      	add	x0, x16, #0x18
    11bc:      	ld1.s	{ v5 }[2], [x0]
    11c0:      	tbnz	w17, #0x7, 0x1308 <_llm_rows.packet_batch.blocks+0xe0c>
    11c4:      	fmov	w16, s17
    11c8:      	add	x15, x9, x15
    11cc:      	movi.2d	v20, #0000000000000000
    11d0:      	movi.2d	v19, #0000000000000000
    11d4:      	tbz	w16, #0x0, 0x1324 <_llm_rows.packet_batch.blocks+0xe28>
    11d8:      	ldr	s20, [x15]
    11dc:      	and	w16, w16, #0xff
    11e0:      	tbnz	w16, #0x1, 0x132c <_llm_rows.packet_batch.blocks+0xe30>
    11e4:      	tbz	w16, #0x2, 0x1338 <_llm_rows.packet_batch.blocks+0xe3c>
    11e8:      	add	x17, x15, #0x8
    11ec:      	ld1.s	{ v20 }[2], [x17]
    11f0:      	tbnz	w16, #0x3, 0x133c <_llm_rows.packet_batch.blocks+0xe40>
    11f4:      	tbz	w16, #0x4, 0x1348 <_llm_rows.packet_batch.blocks+0xe4c>
    11f8:      	add	x17, x15, #0x10
    11fc:      	ld1.s	{ v19 }[0], [x17]
    1200:      	tbnz	w16, #0x5, 0x134c <_llm_rows.packet_batch.blocks+0xe50>
    1204:      	tbz	w16, #0x6, 0x1358 <_llm_rows.packet_batch.blocks+0xe5c>
    1208:      	add	x17, x15, #0x18
    120c:      	ld1.s	{ v19 }[2], [x17]
    1210:      	tbnz	w16, #0x7, 0x135c <_llm_rows.packet_batch.blocks+0xe60>
    1214:      	fmov	w15, s17
    1218:      	fmul.4s	v21, v2, v6
    121c:      	fmul.4s	v22, v4, v20
    1220:      	fsub.4s	v21, v21, v22
    1224:      	add	x13, x8, x13
    1228:      	tbz	w15, #0x0, 0x137c <_llm_rows.packet_batch.blocks+0xe80>
    122c:      	str	s21, [x13]
    1230:      	and	w15, w15, #0xff
    1234:      	tbnz	w15, #0x1, 0x1384 <_llm_rows.packet_batch.blocks+0xe88>
    1238:      	tbz	w15, #0x2, 0x1390 <_llm_rows.packet_batch.blocks+0xe94>
    123c:      	add	x16, x13, #0x8
    1240:      	st1.s	{ v21 }[2], [x16]
    1244:      	tbnz	w15, #0x3, 0x1394 <_llm_rows.packet_batch.blocks+0xe98>
    1248:      	fmul.4s	v21, v1, v5
    124c:      	fmul.4s	v22, v3, v19
    1250:      	fsub.4s	v21, v21, v22
    1254:      	tbz	w15, #0x4, 0x13ac <_llm_rows.packet_batch.blocks+0xeb0>
    1258:      	str	s21, [x13, #0x10]
    125c:      	tbnz	w15, #0x5, 0x13b0 <_llm_rows.packet_batch.blocks+0xeb4>
    1260:      	tbz	w15, #0x6, 0x13bc <_llm_rows.packet_batch.blocks+0xec0>
    1264:      	add	x16, x13, #0x18
    1268:      	st1.s	{ v21 }[2], [x16]
    126c:      	tbnz	w15, #0x7, 0x13c0 <_llm_rows.packet_batch.blocks+0xec4>
    1270:      	fmov	w15, s17
    1274:      	fmul.4s	v2, v2, v20
    1278:      	fmul.4s	v4, v4, v6
    127c:      	fadd.4s	v2, v4, v2
    1280:      	add	x13, x8, x14
    1284:      	tbz	w15, #0x0, 0x13e0 <_llm_rows.packet_batch.blocks+0xee4>
    1288:      	str	s2, [x13]
    128c:      	and	w14, w15, #0xff
    1290:      	tbnz	w14, #0x1, 0x13e8 <_llm_rows.packet_batch.blocks+0xeec>
    1294:      	tbz	w14, #0x2, 0x13f4 <_llm_rows.packet_batch.blocks+0xef8>
    1298:      	add	x15, x13, #0x8
    129c:      	st1.s	{ v2 }[2], [x15]
    12a0:      	tbnz	w14, #0x3, 0x13f8 <_llm_rows.packet_batch.blocks+0xefc>
    12a4:      	fmul.4s	v1, v1, v19
    12a8:      	fmul.4s	v2, v3, v5
    12ac:      	fadd.4s	v1, v2, v1
    12b0:      	tbz	w14, #0x4, 0x1410 <_llm_rows.packet_batch.blocks+0xf14>
    12b4:      	str	s1, [x13, #0x10]
    12b8:      	tbnz	w14, #0x5, 0x1414 <_llm_rows.packet_batch.blocks+0xf18>
    12bc:      	tbz	w14, #0x6, 0x1420 <_llm_rows.packet_batch.blocks+0xf24>
    12c0:      	add	x15, x13, #0x18
    12c4:      	st1.s	{ v1 }[2], [x15]
    12c8:      	tbnz	w14, #0x7, 0x1424 <_llm_rows.packet_batch.blocks+0xf28>
    12cc:      	b	0x142c <_llm_rows.packet_batch.blocks+0xf30>
    12d0:      	and	w17, w17, #0xff
    12d4:      	tbz	w17, #0x1, 0x1194 <_llm_rows.packet_batch.blocks+0xc98>
    12d8:      	add	x0, x16, #0x4
    12dc:      	ld1.s	{ v6 }[1], [x0]
    12e0:      	tbnz	w17, #0x2, 0x1198 <_llm_rows.packet_batch.blocks+0xc9c>
    12e4:      	tbz	w17, #0x3, 0x11a4 <_llm_rows.packet_batch.blocks+0xca8>
    12e8:      	add	x0, x16, #0xc
    12ec:      	ld1.s	{ v6 }[3], [x0]
    12f0:      	tbnz	w17, #0x4, 0x11a8 <_llm_rows.packet_batch.blocks+0xcac>
    12f4:      	tbz	w17, #0x5, 0x11b4 <_llm_rows.packet_batch.blocks+0xcb8>
    12f8:      	add	x0, x16, #0x14
    12fc:      	ld1.s	{ v5 }[1], [x0]
    1300:      	tbnz	w17, #0x6, 0x11b8 <_llm_rows.packet_batch.blocks+0xcbc>
    1304:      	tbz	w17, #0x7, 0x11c4 <_llm_rows.packet_batch.blocks+0xcc8>
    1308:      	add	x16, x16, #0x1c
    130c:      	ld1.s	{ v5 }[3], [x16]
    1310:      	fmov	w16, s17
    1314:      	add	x15, x9, x15
    1318:      	movi.2d	v20, #0000000000000000
    131c:      	movi.2d	v19, #0000000000000000
    1320:      	tbnz	w16, #0x0, 0x11d8 <_llm_rows.packet_batch.blocks+0xcdc>
    1324:      	and	w16, w16, #0xff
    1328:      	tbz	w16, #0x1, 0x11e4 <_llm_rows.packet_batch.blocks+0xce8>
    132c:      	add	x17, x15, #0x4
    1330:      	ld1.s	{ v20 }[1], [x17]
    1334:      	tbnz	w16, #0x2, 0x11e8 <_llm_rows.packet_batch.blocks+0xcec>
    1338:      	tbz	w16, #0x3, 0x11f4 <_llm_rows.packet_batch.blocks+0xcf8>
    133c:      	add	x17, x15, #0xc
    1340:      	ld1.s	{ v20 }[3], [x17]
    1344:      	tbnz	w16, #0x4, 0x11f8 <_llm_rows.packet_batch.blocks+0xcfc>
    1348:      	tbz	w16, #0x5, 0x1204 <_llm_rows.packet_batch.blocks+0xd08>
    134c:      	add	x17, x15, #0x14
    1350:      	ld1.s	{ v19 }[1], [x17]
    1354:      	tbnz	w16, #0x6, 0x1208 <_llm_rows.packet_batch.blocks+0xd0c>
    1358:      	tbz	w16, #0x7, 0x1214 <_llm_rows.packet_batch.blocks+0xd18>
    135c:      	add	x15, x15, #0x1c
    1360:      	ld1.s	{ v19 }[3], [x15]
    1364:      	fmov	w15, s17
    1368:      	fmul.4s	v21, v2, v6
    136c:      	fmul.4s	v22, v4, v20
    1370:      	fsub.4s	v21, v21, v22
    1374:      	add	x13, x8, x13
    1378:      	tbnz	w15, #0x0, 0x122c <_llm_rows.packet_batch.blocks+0xd30>
    137c:      	and	w15, w15, #0xff
    1380:      	tbz	w15, #0x1, 0x1238 <_llm_rows.packet_batch.blocks+0xd3c>
    1384:      	add	x16, x13, #0x4
    1388:      	st1.s	{ v21 }[1], [x16]
    138c:      	tbnz	w15, #0x2, 0x123c <_llm_rows.packet_batch.blocks+0xd40>
    1390:      	tbz	w15, #0x3, 0x1248 <_llm_rows.packet_batch.blocks+0xd4c>
    1394:      	add	x16, x13, #0xc
    1398:      	st1.s	{ v21 }[3], [x16]
    139c:      	fmul.4s	v21, v1, v5
    13a0:      	fmul.4s	v22, v3, v19
    13a4:      	fsub.4s	v21, v21, v22
    13a8:      	tbnz	w15, #0x4, 0x1258 <_llm_rows.packet_batch.blocks+0xd5c>
    13ac:      	tbz	w15, #0x5, 0x1260 <_llm_rows.packet_batch.blocks+0xd64>
    13b0:      	add	x16, x13, #0x14
    13b4:      	st1.s	{ v21 }[1], [x16]
    13b8:      	tbnz	w15, #0x6, 0x1264 <_llm_rows.packet_batch.blocks+0xd68>
    13bc:      	tbz	w15, #0x7, 0x1270 <_llm_rows.packet_batch.blocks+0xd74>
    13c0:      	add	x13, x13, #0x1c
    13c4:      	st1.s	{ v21 }[3], [x13]
    13c8:      	fmov	w15, s17
    13cc:      	fmul.4s	v2, v2, v20
    13d0:      	fmul.4s	v4, v4, v6
    13d4:      	fadd.4s	v2, v4, v2
    13d8:      	add	x13, x8, x14
    13dc:      	tbnz	w15, #0x0, 0x1288 <_llm_rows.packet_batch.blocks+0xd8c>
    13e0:      	and	w14, w15, #0xff
    13e4:      	tbz	w14, #0x1, 0x1294 <_llm_rows.packet_batch.blocks+0xd98>
    13e8:      	add	x15, x13, #0x4
    13ec:      	st1.s	{ v2 }[1], [x15]
    13f0:      	tbnz	w14, #0x2, 0x1298 <_llm_rows.packet_batch.blocks+0xd9c>
    13f4:      	tbz	w14, #0x3, 0x12a4 <_llm_rows.packet_batch.blocks+0xda8>
    13f8:      	add	x15, x13, #0xc
    13fc:      	st1.s	{ v2 }[3], [x15]
    1400:      	fmul.4s	v1, v1, v19
    1404:      	fmul.4s	v2, v3, v5
    1408:      	fadd.4s	v1, v2, v1
    140c:      	tbnz	w14, #0x4, 0x12b4 <_llm_rows.packet_batch.blocks+0xdb8>
    1410:      	tbz	w14, #0x5, 0x12bc <_llm_rows.packet_batch.blocks+0xdc0>
    1414:      	add	x15, x13, #0x14
    1418:      	st1.s	{ v1 }[1], [x15]
    141c:      	tbnz	w14, #0x6, 0x12c0 <_llm_rows.packet_batch.blocks+0xdc4>
    1420:      	tbz	w14, #0x7, 0x142c <_llm_rows.packet_batch.blocks+0xf30>
    1424:      	add	x13, x13, #0x1c
    1428:      	st1.s	{ v1 }[3], [x13]
    142c:      	fmov	w15, s17
    1430:      	mov	w13, #0x18              ; =24
    1434:      	dup.2d	v1, x13
    1438:      	orr.16b	v5, v7, v1
    143c:      	add.2d	v1, v16, v5
    1440:      	fmov	x13, d1
    1444:      	lsl	x13, x13, #2
    1448:      	add	x14, x11, x13
    144c:      	movi.2d	v2, #0000000000000000
    1450:      	movi.2d	v1, #0000000000000000
    1454:      	tbz	w15, #0x0, 0x14ec <_llm_rows.packet_batch.blocks+0xff0>
    1458:      	ldr	s2, [x14]
    145c:      	and	w15, w15, #0xff
    1460:      	tbnz	w15, #0x1, 0x14f4 <_llm_rows.packet_batch.blocks+0xff8>
    1464:      	tbz	w15, #0x2, 0x1500 <_llm_rows.packet_batch.blocks+0x1004>
    1468:      	add	x16, x14, #0x8
    146c:      	ld1.s	{ v2 }[2], [x16]
    1470:      	tbnz	w15, #0x3, 0x1504 <_llm_rows.packet_batch.blocks+0x1008>
    1474:      	tbz	w15, #0x4, 0x1510 <_llm_rows.packet_batch.blocks+0x1014>
    1478:      	add	x16, x14, #0x10
    147c:      	ld1.s	{ v1 }[0], [x16]
    1480:      	tbnz	w15, #0x5, 0x1514 <_llm_rows.packet_batch.blocks+0x1018>
    1484:      	tbz	w15, #0x6, 0x1520 <_llm_rows.packet_batch.blocks+0x1024>
    1488:      	add	x16, x14, #0x18
    148c:      	ld1.s	{ v1 }[2], [x16]
    1490:      	tbnz	w15, #0x7, 0x1524 <_llm_rows.packet_batch.blocks+0x1028>
    1494:      	fmov	w15, s17
    1498:      	add	x12, x12, #0xe4
    149c:      	add	x14, x11, x12
    14a0:      	movi.2d	v4, #0000000000000000
    14a4:      	movi.2d	v3, #0000000000000000
    14a8:      	tbz	w15, #0x0, 0x1544 <_llm_rows.packet_batch.blocks+0x1048>
    14ac:      	ldr	s4, [x14]
    14b0:      	and	w15, w15, #0xff
    14b4:      	tbnz	w15, #0x1, 0x154c <_llm_rows.packet_batch.blocks+0x1050>
    14b8:      	tbz	w15, #0x2, 0x1558 <_llm_rows.packet_batch.blocks+0x105c>
    14bc:      	add	x16, x14, #0x8
    14c0:      	ld1.s	{ v4 }[2], [x16]
    14c4:      	tbnz	w15, #0x3, 0x155c <_llm_rows.packet_batch.blocks+0x1060>
    14c8:      	tbz	w15, #0x4, 0x1568 <_llm_rows.packet_batch.blocks+0x106c>
    14cc:      	add	x16, x14, #0x10
    14d0:      	ld1.s	{ v3 }[0], [x16]
    14d4:      	tbnz	w15, #0x5, 0x156c <_llm_rows.packet_batch.blocks+0x1070>
    14d8:      	tbz	w15, #0x6, 0x1578 <_llm_rows.packet_batch.blocks+0x107c>
    14dc:      	add	x16, x14, #0x18
    14e0:      	ld1.s	{ v3 }[2], [x16]
    14e4:      	tbnz	w15, #0x7, 0x157c <_llm_rows.packet_batch.blocks+0x1080>
    14e8:      	b	0x1584 <_llm_rows.packet_batch.blocks+0x1088>
    14ec:      	and	w15, w15, #0xff
    14f0:      	tbz	w15, #0x1, 0x1464 <_llm_rows.packet_batch.blocks+0xf68>
    14f4:      	add	x16, x14, #0x4
    14f8:      	ld1.s	{ v2 }[1], [x16]
    14fc:      	tbnz	w15, #0x2, 0x1468 <_llm_rows.packet_batch.blocks+0xf6c>
    1500:      	tbz	w15, #0x3, 0x1474 <_llm_rows.packet_batch.blocks+0xf78>
    1504:      	add	x16, x14, #0xc
    1508:      	ld1.s	{ v2 }[3], [x16]
    150c:      	tbnz	w15, #0x4, 0x1478 <_llm_rows.packet_batch.blocks+0xf7c>
    1510:      	tbz	w15, #0x5, 0x1484 <_llm_rows.packet_batch.blocks+0xf88>
    1514:      	add	x16, x14, #0x14
    1518:      	ld1.s	{ v1 }[1], [x16]
    151c:      	tbnz	w15, #0x6, 0x1488 <_llm_rows.packet_batch.blocks+0xf8c>
    1520:      	tbz	w15, #0x7, 0x1494 <_llm_rows.packet_batch.blocks+0xf98>
    1524:      	add	x14, x14, #0x1c
    1528:      	ld1.s	{ v1 }[3], [x14]
    152c:      	fmov	w15, s17
    1530:      	add	x12, x12, #0xe4
    1534:      	add	x14, x11, x12
    1538:      	movi.2d	v4, #0000000000000000
    153c:      	movi.2d	v3, #0000000000000000
    1540:      	tbnz	w15, #0x0, 0x14ac <_llm_rows.packet_batch.blocks+0xfb0>
    1544:      	and	w15, w15, #0xff
    1548:      	tbz	w15, #0x1, 0x14b8 <_llm_rows.packet_batch.blocks+0xfbc>
    154c:      	add	x16, x14, #0x4
    1550:      	ld1.s	{ v4 }[1], [x16]
    1554:      	tbnz	w15, #0x2, 0x14bc <_llm_rows.packet_batch.blocks+0xfc0>
    1558:      	tbz	w15, #0x3, 0x14c8 <_llm_rows.packet_batch.blocks+0xfcc>
    155c:      	add	x16, x14, #0xc
    1560:      	ld1.s	{ v4 }[3], [x16]
    1564:      	tbnz	w15, #0x4, 0x14cc <_llm_rows.packet_batch.blocks+0xfd0>
    1568:      	tbz	w15, #0x5, 0x14d8 <_llm_rows.packet_batch.blocks+0xfdc>
    156c:      	add	x16, x14, #0x14
    1570:      	ld1.s	{ v3 }[1], [x16]
    1574:      	tbnz	w15, #0x6, 0x14dc <_llm_rows.packet_batch.blocks+0xfe0>
    1578:      	tbz	w15, #0x7, 0x1584 <_llm_rows.packet_batch.blocks+0x1088>
    157c:      	add	x14, x14, #0x1c
    1580:      	ld1.s	{ v3 }[3], [x14]
    1584:      	fmov	w16, s17
    1588:      	add.2d	v5, v18, v5
    158c:      	fmov	x14, d5
    1590:      	lsl	x14, x14, #2
    1594:      	add	x15, x10, x14
    1598:      	movi.2d	v6, #0000000000000000
    159c:      	movi.2d	v5, #0000000000000000
    15a0:      	tbz	w16, #0x0, 0x16ec <_llm_rows.packet_batch.blocks+0x11f0>
    15a4:      	ldr	s6, [x15]
    15a8:      	and	w16, w16, #0xff
    15ac:      	tbnz	w16, #0x1, 0x16f4 <_llm_rows.packet_batch.blocks+0x11f8>
    15b0:      	tbz	w16, #0x2, 0x1700 <_llm_rows.packet_batch.blocks+0x1204>
    15b4:      	add	x17, x15, #0x8
    15b8:      	ld1.s	{ v6 }[2], [x17]
    15bc:      	tbnz	w16, #0x3, 0x1704 <_llm_rows.packet_batch.blocks+0x1208>
    15c0:      	tbz	w16, #0x4, 0x1710 <_llm_rows.packet_batch.blocks+0x1214>
    15c4:      	add	x17, x15, #0x10
    15c8:      	ld1.s	{ v5 }[0], [x17]
    15cc:      	tbnz	w16, #0x5, 0x1714 <_llm_rows.packet_batch.blocks+0x1218>
    15d0:      	tbz	w16, #0x6, 0x1720 <_llm_rows.packet_batch.blocks+0x1224>
    15d4:      	add	x17, x15, #0x18
    15d8:      	ld1.s	{ v5 }[2], [x17]
    15dc:      	tbnz	w16, #0x7, 0x1724 <_llm_rows.packet_batch.blocks+0x1228>
    15e0:      	fmov	w15, s17
    15e4:      	add	x14, x9, x14
    15e8:      	movi.2d	v20, #0000000000000000
    15ec:      	movi.2d	v19, #0000000000000000
    15f0:      	tbz	w15, #0x0, 0x1740 <_llm_rows.packet_batch.blocks+0x1244>
    15f4:      	ldr	s20, [x14]
    15f8:      	and	w15, w15, #0xff
    15fc:      	tbnz	w15, #0x1, 0x1748 <_llm_rows.packet_batch.blocks+0x124c>
    1600:      	tbz	w15, #0x2, 0x1754 <_llm_rows.packet_batch.blocks+0x1258>
    1604:      	add	x16, x14, #0x8
    1608:      	ld1.s	{ v20 }[2], [x16]
    160c:      	tbnz	w15, #0x3, 0x1758 <_llm_rows.packet_batch.blocks+0x125c>
    1610:      	tbz	w15, #0x4, 0x1764 <_llm_rows.packet_batch.blocks+0x1268>
    1614:      	add	x16, x14, #0x10
    1618:      	ld1.s	{ v19 }[0], [x16]
    161c:      	tbnz	w15, #0x5, 0x1768 <_llm_rows.packet_batch.blocks+0x126c>
    1620:      	tbz	w15, #0x6, 0x1774 <_llm_rows.packet_batch.blocks+0x1278>
    1624:      	add	x16, x14, #0x18
    1628:      	ld1.s	{ v19 }[2], [x16]
    162c:      	tbnz	w15, #0x7, 0x1778 <_llm_rows.packet_batch.blocks+0x127c>
    1630:      	fmov	w14, s17
    1634:      	fmul.4s	v21, v2, v6
    1638:      	fmul.4s	v22, v4, v20
    163c:      	fsub.4s	v21, v21, v22
    1640:      	add	x13, x8, x13
    1644:      	tbz	w14, #0x0, 0x1798 <_llm_rows.packet_batch.blocks+0x129c>
    1648:      	str	s21, [x13]
    164c:      	and	w14, w14, #0xff
    1650:      	tbnz	w14, #0x1, 0x17a0 <_llm_rows.packet_batch.blocks+0x12a4>
    1654:      	tbz	w14, #0x2, 0x17ac <_llm_rows.packet_batch.blocks+0x12b0>
    1658:      	add	x15, x13, #0x8
    165c:      	st1.s	{ v21 }[2], [x15]
    1660:      	tbnz	w14, #0x3, 0x17b0 <_llm_rows.packet_batch.blocks+0x12b4>
    1664:      	fmul.4s	v21, v1, v5
    1668:      	fmul.4s	v22, v3, v19
    166c:      	fsub.4s	v21, v21, v22
    1670:      	tbz	w14, #0x4, 0x17c8 <_llm_rows.packet_batch.blocks+0x12cc>
    1674:      	str	s21, [x13, #0x10]
    1678:      	tbnz	w14, #0x5, 0x17cc <_llm_rows.packet_batch.blocks+0x12d0>
    167c:      	tbz	w14, #0x6, 0x17d8 <_llm_rows.packet_batch.blocks+0x12dc>
    1680:      	add	x15, x13, #0x18
    1684:      	st1.s	{ v21 }[2], [x15]
    1688:      	tbnz	w14, #0x7, 0x17dc <_llm_rows.packet_batch.blocks+0x12e0>
    168c:      	fmov	w13, s17
    1690:      	fmul.4s	v2, v2, v20
    1694:      	fmul.4s	v4, v4, v6
    1698:      	fadd.4s	v2, v4, v2
    169c:      	add	x12, x8, x12
    16a0:      	tbz	w13, #0x0, 0x17fc <_llm_rows.packet_batch.blocks+0x1300>
    16a4:      	str	s2, [x12]
    16a8:      	and	w13, w13, #0xff
    16ac:      	tbnz	w13, #0x1, 0x1804 <_llm_rows.packet_batch.blocks+0x1308>
    16b0:      	tbz	w13, #0x2, 0x1810 <_llm_rows.packet_batch.blocks+0x1314>
    16b4:      	add	x14, x12, #0x8
    16b8:      	st1.s	{ v2 }[2], [x14]
    16bc:      	tbnz	w13, #0x3, 0x1814 <_llm_rows.packet_batch.blocks+0x1318>
    16c0:      	fmul.4s	v1, v1, v19
    16c4:      	fmul.4s	v2, v3, v5
    16c8:      	fadd.4s	v1, v2, v1
    16cc:      	tbz	w13, #0x4, 0x182c <_llm_rows.packet_batch.blocks+0x1330>
    16d0:      	str	s1, [x12, #0x10]
    16d4:      	tbnz	w13, #0x5, 0x1830 <_llm_rows.packet_batch.blocks+0x1334>
    16d8:      	tbz	w13, #0x6, 0x183c <_llm_rows.packet_batch.blocks+0x1340>
    16dc:      	add	x14, x12, #0x18
    16e0:      	st1.s	{ v1 }[2], [x14]
    16e4:      	tbnz	w13, #0x7, 0x1840 <_llm_rows.packet_batch.blocks+0x1344>
    16e8:      	b	0x1848 <_llm_rows.packet_batch.blocks+0x134c>
    16ec:      	and	w16, w16, #0xff
    16f0:      	tbz	w16, #0x1, 0x15b0 <_llm_rows.packet_batch.blocks+0x10b4>
    16f4:      	add	x17, x15, #0x4
    16f8:      	ld1.s	{ v6 }[1], [x17]
    16fc:      	tbnz	w16, #0x2, 0x15b4 <_llm_rows.packet_batch.blocks+0x10b8>
    1700:      	tbz	w16, #0x3, 0x15c0 <_llm_rows.packet_batch.blocks+0x10c4>
    1704:      	add	x17, x15, #0xc
    1708:      	ld1.s	{ v6 }[3], [x17]
    170c:      	tbnz	w16, #0x4, 0x15c4 <_llm_rows.packet_batch.blocks+0x10c8>
    1710:      	tbz	w16, #0x5, 0x15d0 <_llm_rows.packet_batch.blocks+0x10d4>
    1714:      	add	x17, x15, #0x14
    1718:      	ld1.s	{ v5 }[1], [x17]
    171c:      	tbnz	w16, #0x6, 0x15d4 <_llm_rows.packet_batch.blocks+0x10d8>
    1720:      	tbz	w16, #0x7, 0x15e0 <_llm_rows.packet_batch.blocks+0x10e4>
    1724:      	add	x15, x15, #0x1c
    1728:      	ld1.s	{ v5 }[3], [x15]
    172c:      	fmov	w15, s17
    1730:      	add	x14, x9, x14
    1734:      	movi.2d	v20, #0000000000000000
    1738:      	movi.2d	v19, #0000000000000000
    173c:      	tbnz	w15, #0x0, 0x15f4 <_llm_rows.packet_batch.blocks+0x10f8>
    1740:      	and	w15, w15, #0xff
    1744:      	tbz	w15, #0x1, 0x1600 <_llm_rows.packet_batch.blocks+0x1104>
    1748:      	add	x16, x14, #0x4
    174c:      	ld1.s	{ v20 }[1], [x16]
    1750:      	tbnz	w15, #0x2, 0x1604 <_llm_rows.packet_batch.blocks+0x1108>
    1754:      	tbz	w15, #0x3, 0x1610 <_llm_rows.packet_batch.blocks+0x1114>
    1758:      	add	x16, x14, #0xc
    175c:      	ld1.s	{ v20 }[3], [x16]
    1760:      	tbnz	w15, #0x4, 0x1614 <_llm_rows.packet_batch.blocks+0x1118>
    1764:      	tbz	w15, #0x5, 0x1620 <_llm_rows.packet_batch.blocks+0x1124>
    1768:      	add	x16, x14, #0x14
    176c:      	ld1.s	{ v19 }[1], [x16]
    1770:      	tbnz	w15, #0x6, 0x1624 <_llm_rows.packet_batch.blocks+0x1128>
    1774:      	tbz	w15, #0x7, 0x1630 <_llm_rows.packet_batch.blocks+0x1134>
    1778:      	add	x14, x14, #0x1c
    177c:      	ld1.s	{ v19 }[3], [x14]
    1780:      	fmov	w14, s17
    1784:      	fmul.4s	v21, v2, v6
    1788:      	fmul.4s	v22, v4, v20
    178c:      	fsub.4s	v21, v21, v22
    1790:      	add	x13, x8, x13
    1794:      	tbnz	w14, #0x0, 0x1648 <_llm_rows.packet_batch.blocks+0x114c>
    1798:      	and	w14, w14, #0xff
    179c:      	tbz	w14, #0x1, 0x1654 <_llm_rows.packet_batch.blocks+0x1158>
    17a0:      	add	x15, x13, #0x4
    17a4:      	st1.s	{ v21 }[1], [x15]
    17a8:      	tbnz	w14, #0x2, 0x1658 <_llm_rows.packet_batch.blocks+0x115c>
    17ac:      	tbz	w14, #0x3, 0x1664 <_llm_rows.packet_batch.blocks+0x1168>
    17b0:      	add	x15, x13, #0xc
    17b4:      	st1.s	{ v21 }[3], [x15]
    17b8:      	fmul.4s	v21, v1, v5
    17bc:      	fmul.4s	v22, v3, v19
    17c0:      	fsub.4s	v21, v21, v22
    17c4:      	tbnz	w14, #0x4, 0x1674 <_llm_rows.packet_batch.blocks+0x1178>
    17c8:      	tbz	w14, #0x5, 0x167c <_llm_rows.packet_batch.blocks+0x1180>
    17cc:      	add	x15, x13, #0x14
    17d0:      	st1.s	{ v21 }[1], [x15]
    17d4:      	tbnz	w14, #0x6, 0x1680 <_llm_rows.packet_batch.blocks+0x1184>
    17d8:      	tbz	w14, #0x7, 0x168c <_llm_rows.packet_batch.blocks+0x1190>
    17dc:      	add	x13, x13, #0x1c
    17e0:      	st1.s	{ v21 }[3], [x13]
    17e4:      	fmov	w13, s17
    17e8:      	fmul.4s	v2, v2, v20
    17ec:      	fmul.4s	v4, v4, v6
    17f0:      	fadd.4s	v2, v4, v2
    17f4:      	add	x12, x8, x12
    17f8:      	tbnz	w13, #0x0, 0x16a4 <_llm_rows.packet_batch.blocks+0x11a8>
    17fc:      	and	w13, w13, #0xff
    1800:      	tbz	w13, #0x1, 0x16b0 <_llm_rows.packet_batch.blocks+0x11b4>
    1804:      	add	x14, x12, #0x4
    1808:      	st1.s	{ v2 }[1], [x14]
    180c:      	tbnz	w13, #0x2, 0x16b4 <_llm_rows.packet_batch.blocks+0x11b8>
    1810:      	tbz	w13, #0x3, 0x16c0 <_llm_rows.packet_batch.blocks+0x11c4>
    1814:      	add	x14, x12, #0xc
    1818:      	st1.s	{ v2 }[3], [x14]
    181c:      	fmul.4s	v1, v1, v19
    1820:      	fmul.4s	v2, v3, v5
    1824:      	fadd.4s	v1, v2, v1
    1828:      	tbnz	w13, #0x4, 0x16d0 <_llm_rows.packet_batch.blocks+0x11d4>
    182c:      	tbz	w13, #0x5, 0x16d8 <_llm_rows.packet_batch.blocks+0x11dc>
    1830:      	add	x14, x12, #0x14
    1834:      	st1.s	{ v1 }[1], [x14]
    1838:      	tbnz	w13, #0x6, 0x16dc <_llm_rows.packet_batch.blocks+0x11e0>
    183c:      	tbz	w13, #0x7, 0x1848 <_llm_rows.packet_batch.blocks+0x134c>
    1840:      	add	x12, x12, #0x1c
    1844:      	st1.s	{ v1 }[3], [x12]
    1848:      	xtn.4h	v0, v0
    184c:      	uzp1.8b	v0, v0, v0
    1850:      	movi.2d	v22, #0000000000000000
    1854:      	mov.b	v22[0], v0[0]
    1858:      	adrp	x12, 0x1000 <_llm_rows.packet_batch.blocks+0xb04>
    185c:      	ldr	d21, [x12]
    1860:      	and.8b	v1, v22, v21
    1864:      	addv.8b	b1, v1
    1868:      	fmov	w13, s1
    186c:      	umaxv.8b	b1, v22
    1870:      	fmov	w15, s1
    1874:      	rbit	w12, w13
    1878:      	clz	w12, w12
    187c:      	tst	w15, #0x1
    1880:      	csel	w12, w12, wzr, ne
    1884:      	mov	w14, #0x20              ; =32
    1888:      	dup.2d	v24, x14
    188c:      	orr.16b	v23, v7, v24
    1890:      	add.2d	v2, v16, v23
    1894:      	movi.2d	v1, #0000000000000000
    1898:      	mov.b	v1[0], v0[0]
    189c:      	ushll.2d	v0, v1, #0x0
    18a0:      	shl.2d	v0, v0, #0x3f
    18a4:      	cmlt.2d	v0, v0, #0
    18a8:      	and.16b	v0, v0, v2
    18ac:      	movi.2d	v1, #0000000000000000
    18b0:      	stp	q1, q1, [sp, #0x3e0]
    18b4:      	stp	q0, q1, [sp, #0x3c0]
    18b8:      	and	x14, x12, #0x7
    18bc:      	add	x16, sp, #0x3c0
    18c0:      	ldr	x14, [x16, x14, lsl #3]
    18c4:      	sub	x14, x14, x12
    18c8:      	add	x14, x11, x14, lsl #2
    18cc:      	movi.2d	v0, #0000000000000000
    18d0:      	tbz	w15, #0x0, 0x1910 <_llm_rows.packet_batch.blocks+0x1414>
    18d4:      	ldr	s1, [x14]
    18d8:      	tbnz	w13, #0x1, 0x1914 <_llm_rows.packet_batch.blocks+0x1418>
    18dc:      	tbz	w13, #0x2, 0x1920 <_llm_rows.packet_batch.blocks+0x1424>
    18e0:      	add	x15, x14, #0x8
    18e4:      	ld1.s	{ v1 }[2], [x15]
    18e8:      	tbnz	w13, #0x3, 0x1924 <_llm_rows.packet_batch.blocks+0x1428>
    18ec:      	tbz	w13, #0x4, 0x1930 <_llm_rows.packet_batch.blocks+0x1434>
    18f0:      	add	x15, x14, #0x10
    18f4:      	ld1.s	{ v0 }[0], [x15]
    18f8:      	tbnz	w13, #0x5, 0x1934 <_llm_rows.packet_batch.blocks+0x1438>
    18fc:      	tbz	w13, #0x6, 0x1940 <_llm_rows.packet_batch.blocks+0x1444>
    1900:      	add	x15, x14, #0x18
    1904:      	ld1.s	{ v0 }[2], [x15]
    1908:      	tbnz	w13, #0x7, 0x1944 <_llm_rows.packet_batch.blocks+0x1448>
    190c:      	b	0x194c <_llm_rows.packet_batch.blocks+0x1450>
    1910:      	tbz	w13, #0x1, 0x18dc <_llm_rows.packet_batch.blocks+0x13e0>
    1914:      	add	x15, x14, #0x4
    1918:      	ld1.s	{ v1 }[1], [x15]
    191c:      	tbnz	w13, #0x2, 0x18e0 <_llm_rows.packet_batch.blocks+0x13e4>
    1920:      	tbz	w13, #0x3, 0x18ec <_llm_rows.packet_batch.blocks+0x13f0>
    1924:      	add	x15, x14, #0xc
    1928:      	ld1.s	{ v1 }[3], [x15]
    192c:      	tbnz	w13, #0x4, 0x18f0 <_llm_rows.packet_batch.blocks+0x13f4>
    1930:      	tbz	w13, #0x5, 0x18fc <_llm_rows.packet_batch.blocks+0x1400>
    1934:      	add	x15, x14, #0x14
    1938:      	ld1.s	{ v0 }[1], [x15]
    193c:      	tbnz	w13, #0x6, 0x1900 <_llm_rows.packet_batch.blocks+0x1404>
    1940:      	tbz	w13, #0x7, 0x194c <_llm_rows.packet_batch.blocks+0x1450>
    1944:      	add	x13, x14, #0x1c
    1948:      	ld1.s	{ v0 }[3], [x13]
    194c:      	fmov	d30, d25
    1950:      	umull.2d	v17, v25, v10
    1954:      	fmov	d29, d27
    1958:      	umull.2d	v20, v27, v10
    195c:      	fmov	d28, d26
    1960:      	umull.2d	v19, v26, v10
    1964:      	add.2d	v6, v7, v16
    1968:      	add.2d	v5, v9, v17
    196c:      	add.2d	v4, v31, v20
    1970:      	add.2d	v3, v8, v19
    1974:      	mov	w13, #0x41              ; =65
    1978:      	dup.2d	v7, x13
    197c:      	add.2d	v3, v3, v7
    1980:      	add.2d	v4, v4, v7
    1984:      	add.2d	v5, v5, v7
    1988:      	mov	b16, v22[0]
    198c:      	mov.b	v16[4], v22[1]
    1990:      	add.2d	v6, v6, v7
    1994:      	ushll.2d	v7, v16, #0x0
    1998:      	shl.2d	v7, v7, #0x3f
    199c:      	cmlt.2d	v7, v7, #0
    19a0:      	and.16b	v7, v7, v6
    19a4:      	mov	b16, v22[2]
    19a8:      	mov.b	v16[4], v22[3]
    19ac:      	ushll.2d	v16, v16, #0x0
    19b0:      	shl.2d	v16, v16, #0x3f
    19b4:      	cmlt.2d	v16, v16, #0
    19b8:      	and.16b	v25, v16, v5
    19bc:      	mov	b16, v22[4]
    19c0:      	mov.b	v16[4], v22[5]
    19c4:      	ushll.2d	v16, v16, #0x0
    19c8:      	shl.2d	v16, v16, #0x3f
    19cc:      	cmlt.2d	v16, v16, #0
    19d0:      	and.16b	v26, v16, v4
    19d4:      	mov	b16, v22[6]
    19d8:      	mov.b	v16[4], v22[7]
    19dc:      	ushll.2d	v16, v16, #0x0
    19e0:      	shl.2d	v16, v16, #0x3f
    19e4:      	cmlt.2d	v16, v16, #0
    19e8:      	and.16b	v27, v16, v3
    19ec:      	shl.8b	v16, v22, #0x7
    19f0:      	cmlt.8b	v16, v16, #0
    19f4:      	and.8b	v16, v16, v21
    19f8:      	addv.8b	b16, v16
    19fc:      	fmov	w13, s16
    1a00:      	stp	q26, q27, [sp, #0x3a0]
    1a04:      	stp	q7, q25, [sp, #0x380]
    1a08:      	and	x14, x12, #0x7
    1a0c:      	add	x15, sp, #0x380
    1a10:      	ldr	x14, [x15, x14, lsl #3]
    1a14:      	sub	x14, x14, x12
    1a18:      	add	x11, x11, x14, lsl #2
    1a1c:      	movi.2d	v21, #0000000000000000
    1a20:      	movi.2d	v7, #0000000000000000
    1a24:      	tbz	w13, #0x0, 0x1a68 <_llm_rows.packet_batch.blocks+0x156c>
    1a28:      	ldr	s21, [x11]
    1a2c:      	tbnz	w13, #0x1, 0x1a6c <_llm_rows.packet_batch.blocks+0x1570>
    1a30:      	fmov	d25, d28
    1a34:      	tbz	w13, #0x2, 0x1a7c <_llm_rows.packet_batch.blocks+0x1580>
    1a38:      	add	x14, x11, #0x8
    1a3c:      	ld1.s	{ v21 }[2], [x14]
    1a40:      	tbnz	w13, #0x3, 0x1a80 <_llm_rows.packet_batch.blocks+0x1584>
    1a44:      	tbz	w13, #0x4, 0x1a8c <_llm_rows.packet_batch.blocks+0x1590>
    1a48:      	add	x14, x11, #0x10
    1a4c:      	ld1.s	{ v7 }[0], [x14]
    1a50:      	tbnz	w13, #0x5, 0x1a90 <_llm_rows.packet_batch.blocks+0x1594>
    1a54:      	tbz	w13, #0x6, 0x1a9c <_llm_rows.packet_batch.blocks+0x15a0>
    1a58:      	add	x14, x11, #0x18
    1a5c:      	ld1.s	{ v7 }[2], [x14]
    1a60:      	tbnz	w13, #0x7, 0x1aa0 <_llm_rows.packet_batch.blocks+0x15a4>
    1a64:      	b	0x1aa8 <_llm_rows.packet_batch.blocks+0x15ac>
    1a68:      	tbz	w13, #0x1, 0x1a30 <_llm_rows.packet_batch.blocks+0x1534>
    1a6c:      	add	x14, x11, #0x4
    1a70:      	ld1.s	{ v21 }[1], [x14]
    1a74:      	fmov	d25, d28
    1a78:      	tbnz	w13, #0x2, 0x1a38 <_llm_rows.packet_batch.blocks+0x153c>
    1a7c:      	tbz	w13, #0x3, 0x1a44 <_llm_rows.packet_batch.blocks+0x1548>
    1a80:      	add	x14, x11, #0xc
    1a84:      	ld1.s	{ v21 }[3], [x14]
    1a88:      	tbnz	w13, #0x4, 0x1a48 <_llm_rows.packet_batch.blocks+0x154c>
    1a8c:      	tbz	w13, #0x5, 0x1a54 <_llm_rows.packet_batch.blocks+0x1558>
    1a90:      	add	x14, x11, #0x14
    1a94:      	ld1.s	{ v7 }[1], [x14]
    1a98:      	tbnz	w13, #0x6, 0x1a58 <_llm_rows.packet_batch.blocks+0x155c>
    1a9c:      	tbz	w13, #0x7, 0x1aa8 <_llm_rows.packet_batch.blocks+0x15ac>
    1aa0:      	add	x11, x11, #0x1c
    1aa4:      	ld1.s	{ v7 }[3], [x11]
    1aa8:      	umull.2d	v27, v30, v11
    1aac:      	umull.2d	v28, v29, v11
    1ab0:      	umull.2d	v29, v25, v11
    1ab4:      	orr.16b	v25, v8, v24
    1ab8:      	orr.16b	v26, v9, v24
    1abc:      	orr.16b	v24, v31, v24
    1ac0:      	add.2d	v29, v29, v25
    1ac4:      	add.2d	v28, v28, v24
    1ac8:      	add.2d	v27, v27, v26
    1acc:      	add.2d	v18, v18, v23
    1ad0:      	mov	b23, v22[0]
    1ad4:      	mov.b	v23[4], v22[1]
    1ad8:      	ushll.2d	v23, v23, #0x0
    1adc:      	shl.2d	v23, v23, #0x3f
    1ae0:      	cmlt.2d	v23, v23, #0
    1ae4:      	and.16b	v18, v23, v18
    1ae8:      	mov	b23, v22[2]
    1aec:      	mov.b	v23[4], v22[3]
    1af0:      	ushll.2d	v23, v23, #0x0
    1af4:      	shl.2d	v23, v23, #0x3f
    1af8:      	cmlt.2d	v23, v23, #0
    1afc:      	and.16b	v23, v23, v27
    1b00:      	mov	b27, v22[4]
    1b04:      	mov.b	v27[4], v22[5]
    1b08:      	ushll.2d	v27, v27, #0x0
    1b0c:      	shl.2d	v27, v27, #0x3f
    1b10:      	cmlt.2d	v27, v27, #0
    1b14:      	mov	b30, v22[6]
    1b18:      	mov.b	v30[4], v22[7]
    1b1c:      	and.16b	v22, v27, v28
    1b20:      	ushll.2d	v27, v30, #0x0
    1b24:      	shl.2d	v27, v27, #0x3f
    1b28:      	cmlt.2d	v27, v27, #0
    1b2c:      	and.16b	v27, v27, v29
    1b30:      	stp	q22, q27, [sp, #0x360]
    1b34:      	stp	q18, q23, [sp, #0x340]
    1b38:      	and	x11, x12, #0x7
    1b3c:      	add	x13, sp, #0x340
    1b40:      	ldr	x11, [x13, x11, lsl #3]
    1b44:      	fmov	w13, s16
    1b48:      	sub	x11, x11, x12
    1b4c:      	lsl	x11, x11, #2
    1b50:      	add	x10, x10, x11
    1b54:      	movi.2d	v22, #0000000000000000
    1b58:      	movi.2d	v18, #0000000000000000
    1b5c:      	tbz	w13, #0x0, 0x1be8 <_llm_rows.packet_batch.blocks+0x16ec>
    1b60:      	ldr	s22, [x10]
    1b64:      	tbnz	w13, #0x1, 0x1bec <_llm_rows.packet_batch.blocks+0x16f0>
    1b68:      	tbz	w13, #0x2, 0x1bf8 <_llm_rows.packet_batch.blocks+0x16fc>
    1b6c:      	add	x14, x10, #0x8
    1b70:      	ld1.s	{ v22 }[2], [x14]
    1b74:      	tbnz	w13, #0x3, 0x1bfc <_llm_rows.packet_batch.blocks+0x1700>
    1b78:      	tbz	w13, #0x4, 0x1c08 <_llm_rows.packet_batch.blocks+0x170c>
    1b7c:      	add	x14, x10, #0x10
    1b80:      	ld1.s	{ v18 }[0], [x14]
    1b84:      	tbnz	w13, #0x5, 0x1c0c <_llm_rows.packet_batch.blocks+0x1710>
    1b88:      	tbz	w13, #0x6, 0x1c18 <_llm_rows.packet_batch.blocks+0x171c>
    1b8c:      	add	x14, x10, #0x18
    1b90:      	ld1.s	{ v18 }[2], [x14]
    1b94:      	tbnz	w13, #0x7, 0x1c1c <_llm_rows.packet_batch.blocks+0x1720>
    1b98:      	add	x9, x9, x11
    1b9c:      	fmov	w10, s16
    1ba0:      	movi.2d	v27, #0000000000000000
    1ba4:      	movi.2d	v23, #0000000000000000
    1ba8:      	tbz	w10, #0x0, 0x1c38 <_llm_rows.packet_batch.blocks+0x173c>
    1bac:      	ldr	s27, [x9]
    1bb0:      	tbnz	w10, #0x1, 0x1c3c <_llm_rows.packet_batch.blocks+0x1740>
    1bb4:      	tbz	w10, #0x2, 0x1c48 <_llm_rows.packet_batch.blocks+0x174c>
    1bb8:      	add	x11, x9, #0x8
    1bbc:      	ld1.s	{ v27 }[2], [x11]
    1bc0:      	tbnz	w10, #0x3, 0x1c4c <_llm_rows.packet_batch.blocks+0x1750>
    1bc4:      	tbz	w10, #0x4, 0x1c58 <_llm_rows.packet_batch.blocks+0x175c>
    1bc8:      	add	x11, x9, #0x10
    1bcc:      	ld1.s	{ v23 }[0], [x11]
    1bd0:      	tbnz	w10, #0x5, 0x1c5c <_llm_rows.packet_batch.blocks+0x1760>
    1bd4:      	tbz	w10, #0x6, 0x1c68 <_llm_rows.packet_batch.blocks+0x176c>
    1bd8:      	add	x11, x9, #0x18
    1bdc:      	ld1.s	{ v23 }[2], [x11]
    1be0:      	tbnz	w10, #0x7, 0x1c6c <_llm_rows.packet_batch.blocks+0x1770>
    1be4:      	b	0x1c74 <_llm_rows.packet_batch.blocks+0x1778>
    1be8:      	tbz	w13, #0x1, 0x1b68 <_llm_rows.packet_batch.blocks+0x166c>
    1bec:      	add	x14, x10, #0x4
    1bf0:      	ld1.s	{ v22 }[1], [x14]
    1bf4:      	tbnz	w13, #0x2, 0x1b6c <_llm_rows.packet_batch.blocks+0x1670>
    1bf8:      	tbz	w13, #0x3, 0x1b78 <_llm_rows.packet_batch.blocks+0x167c>
    1bfc:      	add	x14, x10, #0xc
    1c00:      	ld1.s	{ v22 }[3], [x14]
    1c04:      	tbnz	w13, #0x4, 0x1b7c <_llm_rows.packet_batch.blocks+0x1680>
    1c08:      	tbz	w13, #0x5, 0x1b88 <_llm_rows.packet_batch.blocks+0x168c>
    1c0c:      	add	x14, x10, #0x14
    1c10:      	ld1.s	{ v18 }[1], [x14]
    1c14:      	tbnz	w13, #0x6, 0x1b8c <_llm_rows.packet_batch.blocks+0x1690>
    1c18:      	tbz	w13, #0x7, 0x1b98 <_llm_rows.packet_batch.blocks+0x169c>
    1c1c:      	add	x10, x10, #0x1c
    1c20:      	ld1.s	{ v18 }[3], [x10]
    1c24:      	add	x9, x9, x11
    1c28:      	fmov	w10, s16
    1c2c:      	movi.2d	v27, #0000000000000000
    1c30:      	movi.2d	v23, #0000000000000000
    1c34:      	tbnz	w10, #0x0, 0x1bac <_llm_rows.packet_batch.blocks+0x16b0>
    1c38:      	tbz	w10, #0x1, 0x1bb4 <_llm_rows.packet_batch.blocks+0x16b8>
    1c3c:      	add	x11, x9, #0x4
    1c40:      	ld1.s	{ v27 }[1], [x11]
    1c44:      	tbnz	w10, #0x2, 0x1bb8 <_llm_rows.packet_batch.blocks+0x16bc>
    1c48:      	tbz	w10, #0x3, 0x1bc4 <_llm_rows.packet_batch.blocks+0x16c8>
    1c4c:      	add	x11, x9, #0xc
    1c50:      	ld1.s	{ v27 }[3], [x11]
    1c54:      	tbnz	w10, #0x4, 0x1bc8 <_llm_rows.packet_batch.blocks+0x16cc>
    1c58:      	tbz	w10, #0x5, 0x1bd4 <_llm_rows.packet_batch.blocks+0x16d8>
    1c5c:      	add	x11, x9, #0x14
    1c60:      	ld1.s	{ v23 }[1], [x11]
    1c64:      	tbnz	w10, #0x6, 0x1bd8 <_llm_rows.packet_batch.blocks+0x16dc>
    1c68:      	tbz	w10, #0x7, 0x1c74 <_llm_rows.packet_batch.blocks+0x1778>
    1c6c:      	add	x9, x9, #0x1c
    1c70:      	ld1.s	{ v23 }[3], [x9]
    1c74:      	add.2d	v20, v20, v24
    1c78:      	add.2d	v24, v17, v26
    1c7c:      	add.2d	v19, v19, v25
    1c80:      	fmul.4s	v17, v1, v22
    1c84:      	fmul.4s	v25, v21, v27
    1c88:      	fsub.4s	v17, v17, v25
    1c8c:      	stp	q2, q24, [sp, #0x300]
    1c90:      	stp	q20, q19, [sp, #0x320]
    1c94:      	and	x9, x12, #0x7
    1c98:      	add	x10, sp, #0x300
    1c9c:      	ldr	x9, [x10, x9, lsl #3]
    1ca0:      	sub	x9, x9, x12
    1ca4:      	add	x9, x8, x9, lsl #2
    1ca8:      	fmov	w10, s16
    1cac:      	tbz	w10, #0x0, 0x1cf4 <_llm_rows.packet_batch.blocks+0x17f8>
    1cb0:      	str	s17, [x9]
    1cb4:      	tbnz	w10, #0x1, 0x1cf8 <_llm_rows.packet_batch.blocks+0x17fc>
    1cb8:      	tbz	w10, #0x2, 0x1d04 <_llm_rows.packet_batch.blocks+0x1808>
    1cbc:      	add	x11, x9, #0x8
    1cc0:      	st1.s	{ v17 }[2], [x11]
    1cc4:      	tbnz	w10, #0x3, 0x1d08 <_llm_rows.packet_batch.blocks+0x180c>
    1cc8:      	fmul.4s	v2, v0, v18
    1ccc:      	fmul.4s	v17, v7, v23
    1cd0:      	fsub.4s	v2, v2, v17
    1cd4:      	tbz	w10, #0x4, 0x1d20 <_llm_rows.packet_batch.blocks+0x1824>
    1cd8:      	str	s2, [x9, #0x10]
    1cdc:      	tbnz	w10, #0x5, 0x1d24 <_llm_rows.packet_batch.blocks+0x1828>
    1ce0:      	tbz	w10, #0x6, 0x1d30 <_llm_rows.packet_batch.blocks+0x1834>
    1ce4:      	add	x11, x9, #0x18
    1ce8:      	st1.s	{ v2 }[2], [x11]
    1cec:      	tbnz	w10, #0x7, 0x1d34 <_llm_rows.packet_batch.blocks+0x1838>
    1cf0:      	b	0x1d3c <_llm_rows.packet_batch.blocks+0x1840>
    1cf4:      	tbz	w10, #0x1, 0x1cb8 <_llm_rows.packet_batch.blocks+0x17bc>
    1cf8:      	add	x11, x9, #0x4
    1cfc:      	st1.s	{ v17 }[1], [x11]
    1d00:      	tbnz	w10, #0x2, 0x1cbc <_llm_rows.packet_batch.blocks+0x17c0>
    1d04:      	tbz	w10, #0x3, 0x1cc8 <_llm_rows.packet_batch.blocks+0x17cc>
    1d08:      	add	x11, x9, #0xc
    1d0c:      	st1.s	{ v17 }[3], [x11]
    1d10:      	fmul.4s	v2, v0, v18
    1d14:      	fmul.4s	v17, v7, v23
    1d18:      	fsub.4s	v2, v2, v17
    1d1c:      	tbnz	w10, #0x4, 0x1cd8 <_llm_rows.packet_batch.blocks+0x17dc>
    1d20:      	tbz	w10, #0x5, 0x1ce0 <_llm_rows.packet_batch.blocks+0x17e4>
    1d24:      	add	x11, x9, #0x14
    1d28:      	st1.s	{ v2 }[1], [x11]
    1d2c:      	tbnz	w10, #0x6, 0x1ce4 <_llm_rows.packet_batch.blocks+0x17e8>
    1d30:      	tbz	w10, #0x7, 0x1d3c <_llm_rows.packet_batch.blocks+0x1840>
    1d34:      	add	x9, x9, #0x1c
    1d38:      	st1.s	{ v2 }[3], [x9]
    1d3c:      	fmul.4s	v1, v1, v27
    1d40:      	fmul.4s	v2, v21, v22
    1d44:      	fadd.4s	v1, v2, v1
    1d48:      	stp	q6, q5, [sp, #0x2c0]
    1d4c:      	stp	q4, q3, [sp, #0x2e0]
    1d50:      	and	x9, x12, #0x7
    1d54:      	add	x10, sp, #0x2c0
    1d58:      	ldr	x9, [x10, x9, lsl #3]
    1d5c:      	sub	x9, x9, x12
    1d60:      	add	x8, x8, x9, lsl #2
    1d64:      	fmov	w9, s16
    1d68:      	tbz	w9, #0x0, 0x1db0 <_llm_rows.packet_batch.blocks+0x18b4>
    1d6c:      	str	s1, [x8]
    1d70:      	tbnz	w9, #0x1, 0x1db4 <_llm_rows.packet_batch.blocks+0x18b8>
    1d74:      	tbz	w9, #0x2, 0x1dc0 <_llm_rows.packet_batch.blocks+0x18c4>
    1d78:      	add	x10, x8, #0x8
    1d7c:      	st1.s	{ v1 }[2], [x10]
    1d80:      	tbnz	w9, #0x3, 0x1dc4 <_llm_rows.packet_batch.blocks+0x18c8>
    1d84:      	fmul.4s	v0, v0, v23
    1d88:      	fmul.4s	v1, v7, v18
    1d8c:      	fadd.4s	v0, v1, v0
    1d90:      	tbz	w9, #0x4, 0x38c4 <_llm_rows.packet_batch.blocks+0x33c8>
    1d94:      	str	s0, [x8, #0x10]
    1d98:      	tbnz	w9, #0x5, 0x38c8 <_llm_rows.packet_batch.blocks+0x33cc>
    1d9c:      	tbz	w9, #0x6, 0x38d4 <_llm_rows.packet_batch.blocks+0x33d8>
    1da0:      	add	x10, x8, #0x18
    1da4:      	st1.s	{ v0 }[2], [x10]
    1da8:      	tbnz	w9, #0x7, 0x38d8 <_llm_rows.packet_batch.blocks+0x33dc>
    1dac:      	b	0x38e0 <_llm_rows.packet_batch.blocks+0x33e4>
    1db0:      	tbz	w9, #0x1, 0x1d74 <_llm_rows.packet_batch.blocks+0x1878>
    1db4:      	add	x10, x8, #0x4
    1db8:      	st1.s	{ v1 }[1], [x10]
    1dbc:      	tbnz	w9, #0x2, 0x1d78 <_llm_rows.packet_batch.blocks+0x187c>
    1dc0:      	tbz	w9, #0x3, 0x1d84 <_llm_rows.packet_batch.blocks+0x1888>
    1dc4:      	add	x10, x8, #0xc
    1dc8:      	st1.s	{ v1 }[3], [x10]
    1dcc:      	fmul.4s	v0, v0, v23
    1dd0:      	fmul.4s	v1, v7, v18
    1dd4:      	fadd.4s	v0, v1, v0
    1dd8:      	tbz	w9, #0x4, 0x38c4 <_llm_rows.packet_batch.blocks+0x33c8>
    1ddc:      	b	0x1d94 <_llm_rows.packet_batch.blocks+0x1898>
    1de0:      	ldr	q2, [sp, #0x230]
    1de4:      	and.16b	v1, v1, v2
    1de8:      	addv.8h	h17, v1
    1dec:      	fmov	w13, s17
    1df0:      	mov.16b	v21, v7
    1df4:      	umlal.2d	v21, v30, v10
    1df8:      	fmov	x12, d21
    1dfc:      	add	x12, x11, x12, lsl #2
    1e00:      	movi.2d	v1, #0000000000000000
    1e04:      	movi.2d	v3, #0000000000000000
    1e08:      	tbz	w13, #0x0, 0x1e5c <_llm_rows.packet_batch.blocks+0x1960>
    1e0c:      	ldr	s1, [x12]
    1e10:      	and	w13, w13, #0xff
    1e14:      	add	x1, sp, #0x820
    1e18:      	add	x2, sp, #0x780
    1e1c:      	add	x3, sp, #0x6e0
    1e20:      	add	x4, sp, #0x640
    1e24:      	tbnz	w13, #0x1, 0x1e74 <_llm_rows.packet_batch.blocks+0x1978>
    1e28:      	tbz	w13, #0x2, 0x1e80 <_llm_rows.packet_batch.blocks+0x1984>
    1e2c:      	add	x14, x12, #0x8
    1e30:      	ld1.s	{ v1 }[2], [x14]
    1e34:      	tbnz	w13, #0x3, 0x1e84 <_llm_rows.packet_batch.blocks+0x1988>
    1e38:      	tbz	w13, #0x4, 0x1e90 <_llm_rows.packet_batch.blocks+0x1994>
    1e3c:      	add	x14, x12, #0x10
    1e40:      	ld1.s	{ v3 }[0], [x14]
    1e44:      	tbnz	w13, #0x5, 0x1e94 <_llm_rows.packet_batch.blocks+0x1998>
    1e48:      	tbz	w13, #0x6, 0x1ea0 <_llm_rows.packet_batch.blocks+0x19a4>
    1e4c:      	add	x14, x12, #0x18
    1e50:      	ld1.s	{ v3 }[2], [x14]
    1e54:      	tbnz	w13, #0x7, 0x1ea4 <_llm_rows.packet_batch.blocks+0x19a8>
    1e58:      	b	0x1eac <_llm_rows.packet_batch.blocks+0x19b0>
    1e5c:      	and	w13, w13, #0xff
    1e60:      	add	x1, sp, #0x820
    1e64:      	add	x2, sp, #0x780
    1e68:      	add	x3, sp, #0x6e0
    1e6c:      	add	x4, sp, #0x640
    1e70:      	tbz	w13, #0x1, 0x1e28 <_llm_rows.packet_batch.blocks+0x192c>
    1e74:      	add	x14, x12, #0x4
    1e78:      	ld1.s	{ v1 }[1], [x14]
    1e7c:      	tbnz	w13, #0x2, 0x1e2c <_llm_rows.packet_batch.blocks+0x1930>
    1e80:      	tbz	w13, #0x3, 0x1e38 <_llm_rows.packet_batch.blocks+0x193c>
    1e84:      	add	x14, x12, #0xc
    1e88:      	ld1.s	{ v1 }[3], [x14]
    1e8c:      	tbnz	w13, #0x4, 0x1e3c <_llm_rows.packet_batch.blocks+0x1940>
    1e90:      	tbz	w13, #0x5, 0x1e48 <_llm_rows.packet_batch.blocks+0x194c>
    1e94:      	add	x14, x12, #0x14
    1e98:      	ld1.s	{ v3 }[1], [x14]
    1e9c:      	tbnz	w13, #0x6, 0x1e4c <_llm_rows.packet_batch.blocks+0x1950>
    1ea0:      	tbz	w13, #0x7, 0x1eac <_llm_rows.packet_batch.blocks+0x19b0>
    1ea4:      	add	x12, x12, #0x1c
    1ea8:      	ld1.s	{ v3 }[3], [x12]
    1eac:      	umull.2d	v2, v30, v10
    1eb0:      	fmov	w13, s17
    1eb4:      	str	q1, [sp, #0x820]
    1eb8:      	str	q3, [sp, #0x830]
    1ebc:      	mov	w12, #0x8               ; =8
    1ec0:      	dup.2d	v3, x12
    1ec4:      	add.2d	v1, v2, v7
    1ec8:      	add.2d	v3, v1, v3
    1ecc:      	str	q3, [sp, #0x280]
    1ed0:      	fmov	x12, d3
    1ed4:      	add	x12, x11, x12, lsl #2
    1ed8:      	movi.2d	v3, #0000000000000000
    1edc:      	movi.2d	v4, #0000000000000000
    1ee0:      	tbz	w13, #0x0, 0x1f24 <_llm_rows.packet_batch.blocks+0x1a28>
    1ee4:      	ldr	s3, [x12]
    1ee8:      	and	w13, w13, #0xff
    1eec:      	tbnz	w13, #0x1, 0x1f2c <_llm_rows.packet_batch.blocks+0x1a30>
    1ef0:      	tbz	w13, #0x2, 0x1f38 <_llm_rows.packet_batch.blocks+0x1a3c>
    1ef4:      	add	x14, x12, #0x8
    1ef8:      	ld1.s	{ v3 }[2], [x14]
    1efc:      	tbnz	w13, #0x3, 0x1f3c <_llm_rows.packet_batch.blocks+0x1a40>
    1f00:      	tbz	w13, #0x4, 0x1f48 <_llm_rows.packet_batch.blocks+0x1a4c>
    1f04:      	add	x14, x12, #0x10
    1f08:      	ld1.s	{ v4 }[0], [x14]
    1f0c:      	tbnz	w13, #0x5, 0x1f4c <_llm_rows.packet_batch.blocks+0x1a50>
    1f10:      	tbz	w13, #0x6, 0x1f58 <_llm_rows.packet_batch.blocks+0x1a5c>
    1f14:      	add	x14, x12, #0x18
    1f18:      	ld1.s	{ v4 }[2], [x14]
    1f1c:      	tbnz	w13, #0x7, 0x1f5c <_llm_rows.packet_batch.blocks+0x1a60>
    1f20:      	b	0x1f64 <_llm_rows.packet_batch.blocks+0x1a68>
    1f24:      	and	w13, w13, #0xff
    1f28:      	tbz	w13, #0x1, 0x1ef0 <_llm_rows.packet_batch.blocks+0x19f4>
    1f2c:      	add	x14, x12, #0x4
    1f30:      	ld1.s	{ v3 }[1], [x14]
    1f34:      	tbnz	w13, #0x2, 0x1ef4 <_llm_rows.packet_batch.blocks+0x19f8>
    1f38:      	tbz	w13, #0x3, 0x1f00 <_llm_rows.packet_batch.blocks+0x1a04>
    1f3c:      	add	x14, x12, #0xc
    1f40:      	ld1.s	{ v3 }[3], [x14]
    1f44:      	tbnz	w13, #0x4, 0x1f04 <_llm_rows.packet_batch.blocks+0x1a08>
    1f48:      	tbz	w13, #0x5, 0x1f10 <_llm_rows.packet_batch.blocks+0x1a14>
    1f4c:      	add	x14, x12, #0x14
    1f50:      	ld1.s	{ v4 }[1], [x14]
    1f54:      	tbnz	w13, #0x6, 0x1f14 <_llm_rows.packet_batch.blocks+0x1a18>
    1f58:      	tbz	w13, #0x7, 0x1f64 <_llm_rows.packet_batch.blocks+0x1a68>
    1f5c:      	add	x12, x12, #0x1c
    1f60:      	ld1.s	{ v4 }[3], [x12]
    1f64:      	fmov	w13, s17
    1f68:      	mov	w12, #0x10              ; =16
    1f6c:      	dup.2d	v5, x12
    1f70:      	str	q3, [sp, #0x840]
    1f74:      	str	q4, [sp, #0x850]
    1f78:      	add.2d	v3, v1, v5
    1f7c:      	str	q3, [sp, #0x220]
    1f80:      	fmov	x12, d3
    1f84:      	add	x12, x11, x12, lsl #2
    1f88:      	movi.2d	v3, #0000000000000000
    1f8c:      	movi.2d	v4, #0000000000000000
    1f90:      	tbz	w13, #0x0, 0x1fd4 <_llm_rows.packet_batch.blocks+0x1ad8>
    1f94:      	ldr	s3, [x12]
    1f98:      	and	w13, w13, #0xff
    1f9c:      	tbnz	w13, #0x1, 0x1fdc <_llm_rows.packet_batch.blocks+0x1ae0>
    1fa0:      	tbz	w13, #0x2, 0x1fe8 <_llm_rows.packet_batch.blocks+0x1aec>
    1fa4:      	add	x14, x12, #0x8
    1fa8:      	ld1.s	{ v3 }[2], [x14]
    1fac:      	tbnz	w13, #0x3, 0x1fec <_llm_rows.packet_batch.blocks+0x1af0>
    1fb0:      	tbz	w13, #0x4, 0x1ff8 <_llm_rows.packet_batch.blocks+0x1afc>
    1fb4:      	add	x14, x12, #0x10
    1fb8:      	ld1.s	{ v4 }[0], [x14]
    1fbc:      	tbnz	w13, #0x5, 0x1ffc <_llm_rows.packet_batch.blocks+0x1b00>
    1fc0:      	tbz	w13, #0x6, 0x2008 <_llm_rows.packet_batch.blocks+0x1b0c>
    1fc4:      	add	x14, x12, #0x18
    1fc8:      	ld1.s	{ v4 }[2], [x14]
    1fcc:      	tbnz	w13, #0x7, 0x200c <_llm_rows.packet_batch.blocks+0x1b10>
    1fd0:      	b	0x2014 <_llm_rows.packet_batch.blocks+0x1b18>
    1fd4:      	and	w13, w13, #0xff
    1fd8:      	tbz	w13, #0x1, 0x1fa0 <_llm_rows.packet_batch.blocks+0x1aa4>
    1fdc:      	add	x14, x12, #0x4
    1fe0:      	ld1.s	{ v3 }[1], [x14]
    1fe4:      	tbnz	w13, #0x2, 0x1fa4 <_llm_rows.packet_batch.blocks+0x1aa8>
    1fe8:      	tbz	w13, #0x3, 0x1fb0 <_llm_rows.packet_batch.blocks+0x1ab4>
    1fec:      	add	x14, x12, #0xc
    1ff0:      	ld1.s	{ v3 }[3], [x14]
    1ff4:      	tbnz	w13, #0x4, 0x1fb4 <_llm_rows.packet_batch.blocks+0x1ab8>
    1ff8:      	tbz	w13, #0x5, 0x1fc0 <_llm_rows.packet_batch.blocks+0x1ac4>
    1ffc:      	add	x14, x12, #0x14
    2000:      	ld1.s	{ v4 }[1], [x14]
    2004:      	tbnz	w13, #0x6, 0x1fc4 <_llm_rows.packet_batch.blocks+0x1ac8>
    2008:      	tbz	w13, #0x7, 0x2014 <_llm_rows.packet_batch.blocks+0x1b18>
    200c:      	add	x12, x12, #0x1c
    2010:      	ld1.s	{ v4 }[3], [x12]
    2014:      	fmov	w13, s17
    2018:      	mov	w12, #0x18              ; =24
    201c:      	dup.2d	v5, x12
    2020:      	str	q3, [sp, #0x860]
    2024:      	str	q4, [sp, #0x870]
    2028:      	add.2d	v1, v1, v5
    202c:      	str	q1, [sp, #0x210]
    2030:      	fmov	x12, d1
    2034:      	add	x12, x11, x12, lsl #2
    2038:      	movi.2d	v1, #0000000000000000
    203c:      	movi.2d	v3, #0000000000000000
    2040:      	tbz	w13, #0x0, 0x2084 <_llm_rows.packet_batch.blocks+0x1b88>
    2044:      	ldr	s1, [x12]
    2048:      	and	w13, w13, #0xff
    204c:      	tbnz	w13, #0x1, 0x208c <_llm_rows.packet_batch.blocks+0x1b90>
    2050:      	tbz	w13, #0x2, 0x2098 <_llm_rows.packet_batch.blocks+0x1b9c>
    2054:      	add	x14, x12, #0x8
    2058:      	ld1.s	{ v1 }[2], [x14]
    205c:      	tbnz	w13, #0x3, 0x209c <_llm_rows.packet_batch.blocks+0x1ba0>
    2060:      	tbz	w13, #0x4, 0x20a8 <_llm_rows.packet_batch.blocks+0x1bac>
    2064:      	add	x14, x12, #0x10
    2068:      	ld1.s	{ v3 }[0], [x14]
    206c:      	tbnz	w13, #0x5, 0x20ac <_llm_rows.packet_batch.blocks+0x1bb0>
    2070:      	tbz	w13, #0x6, 0x20b8 <_llm_rows.packet_batch.blocks+0x1bbc>
    2074:      	add	x14, x12, #0x18
    2078:      	ld1.s	{ v3 }[2], [x14]
    207c:      	tbnz	w13, #0x7, 0x20bc <_llm_rows.packet_batch.blocks+0x1bc0>
    2080:      	b	0x20c4 <_llm_rows.packet_batch.blocks+0x1bc8>
    2084:      	and	w13, w13, #0xff
    2088:      	tbz	w13, #0x1, 0x2050 <_llm_rows.packet_batch.blocks+0x1b54>
    208c:      	add	x14, x12, #0x4
    2090:      	ld1.s	{ v1 }[1], [x14]
    2094:      	tbnz	w13, #0x2, 0x2054 <_llm_rows.packet_batch.blocks+0x1b58>
    2098:      	tbz	w13, #0x3, 0x2060 <_llm_rows.packet_batch.blocks+0x1b64>
    209c:      	add	x14, x12, #0xc
    20a0:      	ld1.s	{ v1 }[3], [x14]
    20a4:      	tbnz	w13, #0x4, 0x2064 <_llm_rows.packet_batch.blocks+0x1b68>
    20a8:      	tbz	w13, #0x5, 0x2070 <_llm_rows.packet_batch.blocks+0x1b74>
    20ac:      	add	x14, x12, #0x14
    20b0:      	ld1.s	{ v3 }[1], [x14]
    20b4:      	tbnz	w13, #0x6, 0x2074 <_llm_rows.packet_batch.blocks+0x1b78>
    20b8:      	tbz	w13, #0x7, 0x20c4 <_llm_rows.packet_batch.blocks+0x1bc8>
    20bc:      	add	x12, x12, #0x1c
    20c0:      	ld1.s	{ v3 }[3], [x12]
    20c4:      	xtn.4h	v4, v0
    20c8:      	uzp1.8b	v4, v4, v0
    20cc:      	str	q1, [sp, #0x880]
    20d0:      	str	q3, [sp, #0x890]
    20d4:      	movi.2d	v20, #0000000000000000
    20d8:      	mov.b	v20[0], v4[0]
    20dc:      	adrp	x12, 0x2000 <_llm_rows.packet_batch.blocks+0x1b04>
    20e0:      	ldr	d14, [x12]
    20e4:      	and.8b	v1, v20, v14
    20e8:      	addv.8b	b1, v1
    20ec:      	fmov	w13, s1
    20f0:      	umaxv.8b	b1, v20
    20f4:      	fmov	w15, s1
    20f8:      	rbit	w12, w13
    20fc:      	clz	w12, w12
    2100:      	tst	w15, #0x1
    2104:      	csel	w12, w12, wzr, ne
    2108:      	mov	w14, #0x20              ; =32
    210c:      	dup.2d	v1, x14
    2110:      	orr.16b	v3, v7, v1
    2114:      	str	q3, [sp, #0x200]
    2118:      	add.2d	v3, v2, v3
    211c:      	movi.2d	v5, #0000000000000000
    2120:      	mov.b	v5[0], v4[0]
    2124:      	ushll.2d	v4, v5, #0x0
    2128:      	shl.2d	v4, v4, #0x3f
    212c:      	cmlt.2d	v4, v4, #0
    2130:      	and.16b	v3, v4, v3
    2134:      	movi.2d	v4, #0000000000000000
    2138:      	str	q4, [sp, #0x620]
    213c:      	str	q4, [sp, #0x610]
    2140:      	str	q4, [sp, #0x600]
    2144:      	str	q3, [sp, #0x5f0]
    2148:      	and	x14, x12, #0x7
    214c:      	add	x16, sp, #0x5f0
    2150:      	ldr	x14, [x16, x14, lsl #3]
    2154:      	sub	x14, x14, x12
    2158:      	add	x14, x11, x14, lsl #2
    215c:      	movi.2d	v3, #0000000000000000
    2160:      	tbz	w15, #0x0, 0x21a0 <_llm_rows.packet_batch.blocks+0x1ca4>
    2164:      	ldr	s3, [x14]
    2168:      	tbnz	w13, #0x1, 0x21a4 <_llm_rows.packet_batch.blocks+0x1ca8>
    216c:      	tbz	w13, #0x2, 0x21b0 <_llm_rows.packet_batch.blocks+0x1cb4>
    2170:      	add	x15, x14, #0x8
    2174:      	ld1.s	{ v3 }[2], [x15]
    2178:      	tbnz	w13, #0x3, 0x21b4 <_llm_rows.packet_batch.blocks+0x1cb8>
    217c:      	tbz	w13, #0x4, 0x21c0 <_llm_rows.packet_batch.blocks+0x1cc4>
    2180:      	add	x15, x14, #0x10
    2184:      	ld1.s	{ v4 }[0], [x15]
    2188:      	tbnz	w13, #0x5, 0x21c4 <_llm_rows.packet_batch.blocks+0x1cc8>
    218c:      	tbz	w13, #0x6, 0x21d0 <_llm_rows.packet_batch.blocks+0x1cd4>
    2190:      	add	x15, x14, #0x18
    2194:      	ld1.s	{ v4 }[2], [x15]
    2198:      	tbnz	w13, #0x7, 0x21d4 <_llm_rows.packet_batch.blocks+0x1cd8>
    219c:      	b	0x21dc <_llm_rows.packet_batch.blocks+0x1ce0>
    21a0:      	tbz	w13, #0x1, 0x216c <_llm_rows.packet_batch.blocks+0x1c70>
    21a4:      	add	x15, x14, #0x4
    21a8:      	ld1.s	{ v3 }[1], [x15]
    21ac:      	tbnz	w13, #0x2, 0x2170 <_llm_rows.packet_batch.blocks+0x1c74>
    21b0:      	tbz	w13, #0x3, 0x217c <_llm_rows.packet_batch.blocks+0x1c80>
    21b4:      	add	x15, x14, #0xc
    21b8:      	ld1.s	{ v3 }[3], [x15]
    21bc:      	tbnz	w13, #0x4, 0x2180 <_llm_rows.packet_batch.blocks+0x1c84>
    21c0:      	tbz	w13, #0x5, 0x218c <_llm_rows.packet_batch.blocks+0x1c90>
    21c4:      	add	x15, x14, #0x14
    21c8:      	ld1.s	{ v4 }[1], [x15]
    21cc:      	tbnz	w13, #0x6, 0x2190 <_llm_rows.packet_batch.blocks+0x1c94>
    21d0:      	tbz	w13, #0x7, 0x21dc <_llm_rows.packet_batch.blocks+0x1ce0>
    21d4:      	add	x14, x14, #0x1c
    21d8:      	ld1.s	{ v4 }[3], [x14]
    21dc:      	sshll.2d	v15, v0, #0x0
    21e0:      	and.16b	v18, v15, v2
    21e4:      	fmov	w17, s17
    21e8:      	adrp	x14, 0x2000 <_llm_rows.packet_batch.blocks+0x1b04>
    21ec:      	ldr	q2, [x14]
    21f0:      	adrp	x14, 0x2000 <_llm_rows.packet_batch.blocks+0x1b04>
    21f4:      	ldr	q5, [x14]
    21f8:      	str	q2, [sp, #0x5d0]
    21fc:      	str	q5, [sp, #0x5c0]
    2200:      	adrp	x14, 0x2000 <_llm_rows.packet_batch.blocks+0x1b04>
    2204:      	ldr	q2, [x14]
    2208:      	adrp	x14, 0x2000 <_llm_rows.packet_batch.blocks+0x1b04>
    220c:      	ldr	q5, [x14]
    2210:      	str	q2, [sp, #0x5b0]
    2214:      	str	q5, [sp, #0x5a0]
    2218:      	and	x14, x12, #0x7
    221c:      	add	x15, sp, #0x5a0
    2220:      	ldr	x15, [x15, x14, lsl #3]
    2224:      	lsl	x14, x12, #2
    2228:      	sub	x15, x15, x14
    222c:      	tst	w13, #0xff
    2230:      	csel	x15, xzr, x15, eq
    2234:      	add	x16, x1, x15
    2238:      	ldp	q2, q5, [x16]
    223c:      	zip2.8b	v6, v20, v0
    2240:      	ushll.4s	v6, v6, #0x0
    2244:      	shl.4s	v6, v6, #0x1f
    2248:      	cmlt.4s	v6, v6, #0
    224c:      	bif.16b	v4, v5, v6
    2250:      	zip1.8b	v5, v20, v0
    2254:      	ushll.4s	v5, v5, #0x0
    2258:      	shl.4s	v5, v5, #0x1f
    225c:      	cmlt.4s	v5, v5, #0
    2260:      	bit.16b	v2, v3, v5
    2264:      	stp	q2, q4, [x16]
    2268:      	mov	w16, #0x21              ; =33
    226c:      	dup.2d	v2, x16
    2270:      	add.2d	v4, v7, v18
    2274:      	add.2d	v2, v4, v2
    2278:      	str	q2, [sp, #0x1f0]
    227c:      	fmov	x16, d2
    2280:      	add	x16, x11, x16, lsl #2
    2284:      	movi.2d	v3, #0000000000000000
    2288:      	movi.2d	v5, #0000000000000000
    228c:      	tbz	w17, #0x0, 0x22d0 <_llm_rows.packet_batch.blocks+0x1dd4>
    2290:      	ldr	s3, [x16]
    2294:      	and	w17, w17, #0xff
    2298:      	tbnz	w17, #0x1, 0x22d8 <_llm_rows.packet_batch.blocks+0x1ddc>
    229c:      	tbz	w17, #0x2, 0x22e4 <_llm_rows.packet_batch.blocks+0x1de8>
    22a0:      	add	x0, x16, #0x8
    22a4:      	ld1.s	{ v3 }[2], [x0]
    22a8:      	tbnz	w17, #0x3, 0x22e8 <_llm_rows.packet_batch.blocks+0x1dec>
    22ac:      	tbz	w17, #0x4, 0x22f4 <_llm_rows.packet_batch.blocks+0x1df8>
    22b0:      	add	x0, x16, #0x10
    22b4:      	ld1.s	{ v5 }[0], [x0]
    22b8:      	tbnz	w17, #0x5, 0x22f8 <_llm_rows.packet_batch.blocks+0x1dfc>
    22bc:      	tbz	w17, #0x6, 0x2304 <_llm_rows.packet_batch.blocks+0x1e08>
    22c0:      	add	x0, x16, #0x18
    22c4:      	ld1.s	{ v5 }[2], [x0]
    22c8:      	tbnz	w17, #0x7, 0x2308 <_llm_rows.packet_batch.blocks+0x1e0c>
    22cc:      	b	0x2310 <_llm_rows.packet_batch.blocks+0x1e14>
    22d0:      	and	w17, w17, #0xff
    22d4:      	tbz	w17, #0x1, 0x229c <_llm_rows.packet_batch.blocks+0x1da0>
    22d8:      	add	x0, x16, #0x4
    22dc:      	ld1.s	{ v3 }[1], [x0]
    22e0:      	tbnz	w17, #0x2, 0x22a0 <_llm_rows.packet_batch.blocks+0x1da4>
    22e4:      	tbz	w17, #0x3, 0x22ac <_llm_rows.packet_batch.blocks+0x1db0>
    22e8:      	add	x0, x16, #0xc
    22ec:      	ld1.s	{ v3 }[3], [x0]
    22f0:      	tbnz	w17, #0x4, 0x22b0 <_llm_rows.packet_batch.blocks+0x1db4>
    22f4:      	tbz	w17, #0x5, 0x22bc <_llm_rows.packet_batch.blocks+0x1dc0>
    22f8:      	add	x0, x16, #0x14
    22fc:      	ld1.s	{ v5 }[1], [x0]
    2300:      	tbnz	w17, #0x6, 0x22c0 <_llm_rows.packet_batch.blocks+0x1dc4>
    2304:      	tbz	w17, #0x7, 0x2310 <_llm_rows.packet_batch.blocks+0x1e14>
    2308:      	add	x16, x16, #0x1c
    230c:      	ld1.s	{ v5 }[3], [x16]
    2310:      	sshll.2d	v6, v0, #0x0
    2314:      	adrp	x16, 0x2000 <_llm_rows.packet_batch.blocks+0x1b04>
    2318:      	ldr	q2, [x16]
    231c:      	str	q6, [sp, #0x150]
    2320:      	and.16b	v2, v6, v2
    2324:      	fmov	w17, s17
    2328:      	str	q3, [sp, #0x780]
    232c:      	str	q5, [sp, #0x790]
    2330:      	mov	w16, #0x21              ; =33
    2334:      	dup.2d	v3, x16
    2338:      	add.2d	v5, v18, v3
    233c:      	add.2d	v3, v5, v2
    2340:      	stp	q3, q18, [sp, #0x1d0]
    2344:      	fmov	x16, d3
    2348:      	add	x16, x11, x16, lsl #2
    234c:      	movi.2d	v6, #0000000000000000
    2350:      	movi.2d	v18, #0000000000000000
    2354:      	tbz	w17, #0x0, 0x2398 <_llm_rows.packet_batch.blocks+0x1e9c>
    2358:      	ldr	s6, [x16]
    235c:      	and	w17, w17, #0xff
    2360:      	tbnz	w17, #0x1, 0x23a0 <_llm_rows.packet_batch.blocks+0x1ea4>
    2364:      	tbz	w17, #0x2, 0x23ac <_llm_rows.packet_batch.blocks+0x1eb0>
    2368:      	add	x0, x16, #0x8
    236c:      	ld1.s	{ v6 }[2], [x0]
    2370:      	tbnz	w17, #0x3, 0x23b0 <_llm_rows.packet_batch.blocks+0x1eb4>
    2374:      	tbz	w17, #0x4, 0x23bc <_llm_rows.packet_batch.blocks+0x1ec0>
    2378:      	add	x0, x16, #0x10
    237c:      	ld1.s	{ v18 }[0], [x0]
    2380:      	tbnz	w17, #0x5, 0x23c0 <_llm_rows.packet_batch.blocks+0x1ec4>
    2384:      	tbz	w17, #0x6, 0x23cc <_llm_rows.packet_batch.blocks+0x1ed0>
    2388:      	add	x0, x16, #0x18
    238c:      	ld1.s	{ v18 }[2], [x0]
    2390:      	tbnz	w17, #0x7, 0x23d0 <_llm_rows.packet_batch.blocks+0x1ed4>
    2394:      	b	0x23d8 <_llm_rows.packet_batch.blocks+0x1edc>
    2398:      	and	w17, w17, #0xff
    239c:      	tbz	w17, #0x1, 0x2364 <_llm_rows.packet_batch.blocks+0x1e68>
    23a0:      	add	x0, x16, #0x4
    23a4:      	ld1.s	{ v6 }[1], [x0]
    23a8:      	tbnz	w17, #0x2, 0x2368 <_llm_rows.packet_batch.blocks+0x1e6c>
    23ac:      	tbz	w17, #0x3, 0x2374 <_llm_rows.packet_batch.blocks+0x1e78>
    23b0:      	add	x0, x16, #0xc
    23b4:      	ld1.s	{ v6 }[3], [x0]
    23b8:      	tbnz	w17, #0x4, 0x2378 <_llm_rows.packet_batch.blocks+0x1e7c>
    23bc:      	tbz	w17, #0x5, 0x2384 <_llm_rows.packet_batch.blocks+0x1e88>
    23c0:      	add	x0, x16, #0x14
    23c4:      	ld1.s	{ v18 }[1], [x0]
    23c8:      	tbnz	w17, #0x6, 0x2388 <_llm_rows.packet_batch.blocks+0x1e8c>
    23cc:      	tbz	w17, #0x7, 0x23d8 <_llm_rows.packet_batch.blocks+0x1edc>
    23d0:      	add	x16, x16, #0x1c
    23d4:      	ld1.s	{ v18 }[3], [x16]
    23d8:      	sshll.2d	v13, v0, #0x0
    23dc:      	adrp	x16, 0x2000 <_llm_rows.packet_batch.blocks+0x1b04>
    23e0:      	ldr	q3, [x16]
    23e4:      	and.16b	v3, v13, v3
    23e8:      	fmov	w17, s17
    23ec:      	str	q6, [sp, #0x7a0]
    23f0:      	str	q18, [sp, #0x7b0]
    23f4:      	add.2d	v6, v5, v3
    23f8:      	str	q6, [sp, #0x1c0]
    23fc:      	fmov	x16, d6
    2400:      	add	x16, x11, x16, lsl #2
    2404:      	movi.2d	v6, #0000000000000000
    2408:      	movi.2d	v18, #0000000000000000
    240c:      	tbz	w17, #0x0, 0x2450 <_llm_rows.packet_batch.blocks+0x1f54>
    2410:      	ldr	s6, [x16]
    2414:      	and	w17, w17, #0xff
    2418:      	tbnz	w17, #0x1, 0x2458 <_llm_rows.packet_batch.blocks+0x1f5c>
    241c:      	tbz	w17, #0x2, 0x2464 <_llm_rows.packet_batch.blocks+0x1f68>
    2420:      	add	x0, x16, #0x8
    2424:      	ld1.s	{ v6 }[2], [x0]
    2428:      	tbnz	w17, #0x3, 0x2468 <_llm_rows.packet_batch.blocks+0x1f6c>
    242c:      	tbz	w17, #0x4, 0x2474 <_llm_rows.packet_batch.blocks+0x1f78>
    2430:      	add	x0, x16, #0x10
    2434:      	ld1.s	{ v18 }[0], [x0]
    2438:      	tbnz	w17, #0x5, 0x2478 <_llm_rows.packet_batch.blocks+0x1f7c>
    243c:      	tbz	w17, #0x6, 0x2484 <_llm_rows.packet_batch.blocks+0x1f88>
    2440:      	add	x0, x16, #0x18
    2444:      	ld1.s	{ v18 }[2], [x0]
    2448:      	tbnz	w17, #0x7, 0x2488 <_llm_rows.packet_batch.blocks+0x1f8c>
    244c:      	b	0x2490 <_llm_rows.packet_batch.blocks+0x1f94>
    2450:      	and	w17, w17, #0xff
    2454:      	tbz	w17, #0x1, 0x241c <_llm_rows.packet_batch.blocks+0x1f20>
    2458:      	add	x0, x16, #0x4
    245c:      	ld1.s	{ v6 }[1], [x0]
    2460:      	tbnz	w17, #0x2, 0x2420 <_llm_rows.packet_batch.blocks+0x1f24>
    2464:      	tbz	w17, #0x3, 0x242c <_llm_rows.packet_batch.blocks+0x1f30>
    2468:      	add	x0, x16, #0xc
    246c:      	ld1.s	{ v6 }[3], [x0]
    2470:      	tbnz	w17, #0x4, 0x2430 <_llm_rows.packet_batch.blocks+0x1f34>
    2474:      	tbz	w17, #0x5, 0x243c <_llm_rows.packet_batch.blocks+0x1f40>
    2478:      	add	x0, x16, #0x14
    247c:      	ld1.s	{ v18 }[1], [x0]
    2480:      	tbnz	w17, #0x6, 0x2440 <_llm_rows.packet_batch.blocks+0x1f44>
    2484:      	tbz	w17, #0x7, 0x2490 <_llm_rows.packet_batch.blocks+0x1f94>
    2488:      	add	x16, x16, #0x1c
    248c:      	ld1.s	{ v18 }[3], [x16]
    2490:      	sshll.2d	v22, v0, #0x0
    2494:      	adrp	x16, 0x2000 <_llm_rows.packet_batch.blocks+0x1b04>
    2498:      	ldr	q19, [x16]
    249c:      	and.16b	v29, v22, v19
    24a0:      	fmov	w17, s17
    24a4:      	str	q6, [sp, #0x7c0]
    24a8:      	str	q18, [sp, #0x7d0]
    24ac:      	add.2d	v5, v5, v29
    24b0:      	str	q5, [sp, #0x1b0]
    24b4:      	fmov	x16, d5
    24b8:      	add	x16, x11, x16, lsl #2
    24bc:      	movi.2d	v5, #0000000000000000
    24c0:      	movi.2d	v6, #0000000000000000
    24c4:      	tbz	w17, #0x0, 0x2510 <_llm_rows.packet_batch.blocks+0x2014>
    24c8:      	ldr	s5, [x16]
    24cc:      	and	w17, w17, #0xff
    24d0:      	tbnz	w17, #0x1, 0x2518 <_llm_rows.packet_batch.blocks+0x201c>
    24d4:      	tbz	w17, #0x2, 0x2524 <_llm_rows.packet_batch.blocks+0x2028>
    24d8:      	add	x0, x16, #0x8
    24dc:      	ld1.s	{ v5 }[2], [x0]
    24e0:      	tbnz	w17, #0x3, 0x2528 <_llm_rows.packet_batch.blocks+0x202c>
    24e4:      	tbz	w17, #0x4, 0x2534 <_llm_rows.packet_batch.blocks+0x2038>
    24e8:      	add	x0, x16, #0x10
    24ec:      	ld1.s	{ v6 }[0], [x0]
    24f0:      	tbnz	w17, #0x5, 0x2538 <_llm_rows.packet_batch.blocks+0x203c>
    24f4:      	tbz	w17, #0x6, 0x2544 <_llm_rows.packet_batch.blocks+0x2048>
    24f8:      	add	x0, x16, #0x18
    24fc:      	ld1.s	{ v6 }[2], [x0]
    2500:      	mov.16b	v24, v31
    2504:      	fmov	d31, d25
    2508:      	tbnz	w17, #0x7, 0x2550 <_llm_rows.packet_batch.blocks+0x2054>
    250c:      	b	0x2558 <_llm_rows.packet_batch.blocks+0x205c>
    2510:      	and	w17, w17, #0xff
    2514:      	tbz	w17, #0x1, 0x24d4 <_llm_rows.packet_batch.blocks+0x1fd8>
    2518:      	add	x0, x16, #0x4
    251c:      	ld1.s	{ v5 }[1], [x0]
    2520:      	tbnz	w17, #0x2, 0x24d8 <_llm_rows.packet_batch.blocks+0x1fdc>
    2524:      	tbz	w17, #0x3, 0x24e4 <_llm_rows.packet_batch.blocks+0x1fe8>
    2528:      	add	x0, x16, #0xc
    252c:      	ld1.s	{ v5 }[3], [x0]
    2530:      	tbnz	w17, #0x4, 0x24e8 <_llm_rows.packet_batch.blocks+0x1fec>
    2534:      	tbz	w17, #0x5, 0x24f4 <_llm_rows.packet_batch.blocks+0x1ff8>
    2538:      	add	x0, x16, #0x14
    253c:      	ld1.s	{ v6 }[1], [x0]
    2540:      	tbnz	w17, #0x6, 0x24f8 <_llm_rows.packet_batch.blocks+0x1ffc>
    2544:      	mov.16b	v24, v31
    2548:      	fmov	d31, d25
    254c:      	tbz	w17, #0x7, 0x2558 <_llm_rows.packet_batch.blocks+0x205c>
    2550:      	add	x16, x16, #0x1c
    2554:      	ld1.s	{ v6 }[3], [x16]
    2558:      	sshll.2d	v25, v16, #0x0
    255c:      	umull.2d	v18, v26, v10
    2560:      	umull.2d	v19, v27, v10
    2564:      	umull.2d	v23, v31, v10
    2568:      	and.16b	v23, v28, v23
    256c:      	str	q25, [sp, #0x160]
    2570:      	and.16b	v25, v25, v19
    2574:      	mov.16b	v10, v12
    2578:      	and.16b	v12, v12, v18
    257c:      	ldr	q18, [sp, #0x7e0]
    2580:      	ldr	q19, [sp, #0x7f0]
    2584:      	bif.16b	v6, v19, v16
    2588:      	bif.16b	v5, v18, v0
    258c:      	str	q5, [sp, #0x7e0]
    2590:      	str	q6, [sp, #0x7f0]
    2594:      	stp	q25, q23, [sp, #0x130]
    2598:      	add.2d	v5, v9, v23
    259c:      	add.2d	v6, v24, v25
    25a0:      	add.2d	v18, v8, v12
    25a4:      	mov	w16, #0x41              ; =65
    25a8:      	dup.2d	v19, x16
    25ac:      	add.2d	v23, v18, v19
    25b0:      	add.2d	v18, v6, v19
    25b4:      	add.2d	v6, v5, v19
    25b8:      	mov	b5, v20[0]
    25bc:      	mov.b	v5[4], v20[1]
    25c0:      	add.2d	v19, v4, v19
    25c4:      	ushll.2d	v4, v5, #0x0
    25c8:      	shl.2d	v4, v4, #0x3f
    25cc:      	cmlt.2d	v4, v4, #0
    25d0:      	stp	q19, q6, [sp, #0x170]
    25d4:      	and.16b	v4, v4, v19
    25d8:      	mov	b5, v20[2]
    25dc:      	mov.b	v5[4], v20[3]
    25e0:      	ushll.2d	v5, v5, #0x0
    25e4:      	shl.2d	v5, v5, #0x3f
    25e8:      	cmlt.2d	v5, v5, #0
    25ec:      	and.16b	v5, v5, v6
    25f0:      	mov	b6, v20[4]
    25f4:      	mov.b	v6[4], v20[5]
    25f8:      	ushll.2d	v6, v6, #0x0
    25fc:      	shl.2d	v6, v6, #0x3f
    2600:      	cmlt.2d	v6, v6, #0
    2604:      	stp	q18, q23, [sp, #0x190]
    2608:      	and.16b	v6, v6, v18
    260c:      	mov	b18, v20[6]
    2610:      	mov.b	v18[4], v20[7]
    2614:      	ushll.2d	v18, v18, #0x0
    2618:      	shl.2d	v18, v18, #0x3f
    261c:      	cmlt.2d	v18, v18, #0
    2620:      	and.16b	v18, v18, v23
    2624:      	shl.8b	v19, v20, #0x7
    2628:      	cmlt.8b	v19, v19, #0
    262c:      	and.8b	v19, v19, v14
    2630:      	addv.8b	b14, v19
    2634:      	fmov	w16, s14
    2638:      	str	q18, [sp, #0x580]
    263c:      	str	q6, [sp, #0x570]
    2640:      	str	q5, [sp, #0x560]
    2644:      	str	q4, [sp, #0x550]
    2648:      	and	x17, x12, #0x7
    264c:      	add	x0, sp, #0x550
    2650:      	ldr	x17, [x0, x17, lsl #3]
    2654:      	sub	x17, x17, x12
    2658:      	add	x11, x11, x17, lsl #2
    265c:      	movi.2d	v5, #0000000000000000
    2660:      	movi.2d	v6, #0000000000000000
    2664:      	tbz	w16, #0x0, 0x26a8 <_llm_rows.packet_batch.blocks+0x21ac>
    2668:      	ldr	s5, [x11]
    266c:      	tbnz	w16, #0x1, 0x26ac <_llm_rows.packet_batch.blocks+0x21b0>
    2670:      	fmov	d25, d31
    2674:      	tbz	w16, #0x2, 0x26bc <_llm_rows.packet_batch.blocks+0x21c0>
    2678:      	add	x17, x11, #0x8
    267c:      	ld1.s	{ v5 }[2], [x17]
    2680:      	tbnz	w16, #0x3, 0x26c0 <_llm_rows.packet_batch.blocks+0x21c4>
    2684:      	tbz	w16, #0x4, 0x26cc <_llm_rows.packet_batch.blocks+0x21d0>
    2688:      	add	x17, x11, #0x10
    268c:      	ld1.s	{ v6 }[0], [x17]
    2690:      	tbnz	w16, #0x5, 0x26d0 <_llm_rows.packet_batch.blocks+0x21d4>
    2694:      	tbz	w16, #0x6, 0x26dc <_llm_rows.packet_batch.blocks+0x21e0>
    2698:      	add	x17, x11, #0x18
    269c:      	ld1.s	{ v6 }[2], [x17]
    26a0:      	tbnz	w16, #0x7, 0x26e0 <_llm_rows.packet_batch.blocks+0x21e4>
    26a4:      	b	0x26e8 <_llm_rows.packet_batch.blocks+0x21ec>
    26a8:      	tbz	w16, #0x1, 0x2670 <_llm_rows.packet_batch.blocks+0x2174>
    26ac:      	add	x17, x11, #0x4
    26b0:      	ld1.s	{ v5 }[1], [x17]
    26b4:      	fmov	d25, d31
    26b8:      	tbnz	w16, #0x2, 0x2678 <_llm_rows.packet_batch.blocks+0x217c>
    26bc:      	tbz	w16, #0x3, 0x2684 <_llm_rows.packet_batch.blocks+0x2188>
    26c0:      	add	x17, x11, #0xc
    26c4:      	ld1.s	{ v5 }[3], [x17]
    26c8:      	tbnz	w16, #0x4, 0x2688 <_llm_rows.packet_batch.blocks+0x218c>
    26cc:      	tbz	w16, #0x5, 0x2694 <_llm_rows.packet_batch.blocks+0x2198>
    26d0:      	add	x17, x11, #0x14
    26d4:      	ld1.s	{ v6 }[1], [x17]
    26d8:      	tbnz	w16, #0x6, 0x2698 <_llm_rows.packet_batch.blocks+0x219c>
    26dc:      	tbz	w16, #0x7, 0x26e8 <_llm_rows.packet_batch.blocks+0x21ec>
    26e0:      	add	x11, x11, #0x1c
    26e4:      	ld1.s	{ v6 }[3], [x11]
    26e8:      	fmov	w16, s17
    26ec:      	sshll.2d	v4, v0, #0x0
    26f0:      	add	x11, x2, x15
    26f4:      	ldp	q18, q19, [x11]
    26f8:      	zip2.8b	v23, v20, v0
    26fc:      	ushll.4s	v23, v23, #0x0
    2700:      	shl.4s	v23, v23, #0x1f
    2704:      	cmlt.4s	v23, v23, #0
    2708:      	bif.16b	v6, v19, v23
    270c:      	zip1.8b	v19, v20, v0
    2710:      	ushll.4s	v19, v19, #0x0
    2714:      	shl.4s	v19, v19, #0x1f
    2718:      	cmlt.4s	v19, v19, #0
    271c:      	bif.16b	v5, v18, v19
    2720:      	stp	q5, q6, [x11]
    2724:      	umull.2d	v5, v30, v11
    2728:      	and.16b	v31, v4, v5
    272c:      	add.2d	v6, v31, v7
    2730:      	fmov	x11, d6
    2734:      	add	x11, x10, x11, lsl #2
    2738:      	movi.2d	v5, #0000000000000000
    273c:      	movi.2d	v7, #0000000000000000
    2740:      	tbz	w16, #0x0, 0x2784 <_llm_rows.packet_batch.blocks+0x2288>
    2744:      	ldr	s5, [x11]
    2748:      	and	w16, w16, #0xff
    274c:      	tbnz	w16, #0x1, 0x278c <_llm_rows.packet_batch.blocks+0x2290>
    2750:      	tbz	w16, #0x2, 0x2798 <_llm_rows.packet_batch.blocks+0x229c>
    2754:      	add	x17, x11, #0x8
    2758:      	ld1.s	{ v5 }[2], [x17]
    275c:      	tbnz	w16, #0x3, 0x279c <_llm_rows.packet_batch.blocks+0x22a0>
    2760:      	tbz	w16, #0x4, 0x27a8 <_llm_rows.packet_batch.blocks+0x22ac>
    2764:      	add	x17, x11, #0x10
    2768:      	ld1.s	{ v7 }[0], [x17]
    276c:      	tbnz	w16, #0x5, 0x27ac <_llm_rows.packet_batch.blocks+0x22b0>
    2770:      	tbz	w16, #0x6, 0x27b8 <_llm_rows.packet_batch.blocks+0x22bc>
    2774:      	add	x17, x11, #0x18
    2778:      	ld1.s	{ v7 }[2], [x17]
    277c:      	tbnz	w16, #0x7, 0x27bc <_llm_rows.packet_batch.blocks+0x22c0>
    2780:      	b	0x27c4 <_llm_rows.packet_batch.blocks+0x22c8>
    2784:      	and	w16, w16, #0xff
    2788:      	tbz	w16, #0x1, 0x2750 <_llm_rows.packet_batch.blocks+0x2254>
    278c:      	add	x17, x11, #0x4
    2790:      	ld1.s	{ v5 }[1], [x17]
    2794:      	tbnz	w16, #0x2, 0x2754 <_llm_rows.packet_batch.blocks+0x2258>
    2798:      	tbz	w16, #0x3, 0x2760 <_llm_rows.packet_batch.blocks+0x2264>
    279c:      	add	x17, x11, #0xc
    27a0:      	ld1.s	{ v5 }[3], [x17]
    27a4:      	tbnz	w16, #0x4, 0x2764 <_llm_rows.packet_batch.blocks+0x2268>
    27a8:      	tbz	w16, #0x5, 0x2770 <_llm_rows.packet_batch.blocks+0x2274>
    27ac:      	add	x17, x11, #0x14
    27b0:      	ld1.s	{ v7 }[1], [x17]
    27b4:      	tbnz	w16, #0x6, 0x2774 <_llm_rows.packet_batch.blocks+0x2278>
    27b8:      	tbz	w16, #0x7, 0x27c4 <_llm_rows.packet_batch.blocks+0x22c8>
    27bc:      	add	x11, x11, #0x1c
    27c0:      	ld1.s	{ v7 }[3], [x11]
    27c4:      	fmov	w16, s17
    27c8:      	ldr	q18, [sp, #0x6e0]
    27cc:      	ldr	q19, [sp, #0x6f0]
    27d0:      	bif.16b	v7, v19, v16
    27d4:      	bif.16b	v5, v18, v0
    27d8:      	str	q5, [sp, #0x6e0]
    27dc:      	str	q7, [sp, #0x6f0]
    27e0:      	add.2d	v5, v31, v2
    27e4:      	fmov	x11, d5
    27e8:      	add	x11, x10, x11, lsl #2
    27ec:      	movi.2d	v2, #0000000000000000
    27f0:      	movi.2d	v7, #0000000000000000
    27f4:      	tbz	w16, #0x0, 0x2838 <_llm_rows.packet_batch.blocks+0x233c>
    27f8:      	ldr	s2, [x11]
    27fc:      	and	w16, w16, #0xff
    2800:      	tbnz	w16, #0x1, 0x2840 <_llm_rows.packet_batch.blocks+0x2344>
    2804:      	tbz	w16, #0x2, 0x284c <_llm_rows.packet_batch.blocks+0x2350>
    2808:      	add	x17, x11, #0x8
    280c:      	ld1.s	{ v2 }[2], [x17]
    2810:      	tbnz	w16, #0x3, 0x2850 <_llm_rows.packet_batch.blocks+0x2354>
    2814:      	tbz	w16, #0x4, 0x285c <_llm_rows.packet_batch.blocks+0x2360>
    2818:      	add	x17, x11, #0x10
    281c:      	ld1.s	{ v7 }[0], [x17]
    2820:      	tbnz	w16, #0x5, 0x2860 <_llm_rows.packet_batch.blocks+0x2364>
    2824:      	tbz	w16, #0x6, 0x286c <_llm_rows.packet_batch.blocks+0x2370>
    2828:      	add	x17, x11, #0x18
    282c:      	ld1.s	{ v7 }[2], [x17]
    2830:      	tbnz	w16, #0x7, 0x2870 <_llm_rows.packet_batch.blocks+0x2374>
    2834:      	b	0x2878 <_llm_rows.packet_batch.blocks+0x237c>
    2838:      	and	w16, w16, #0xff
    283c:      	tbz	w16, #0x1, 0x2804 <_llm_rows.packet_batch.blocks+0x2308>
    2840:      	add	x17, x11, #0x4
    2844:      	ld1.s	{ v2 }[1], [x17]
    2848:      	tbnz	w16, #0x2, 0x2808 <_llm_rows.packet_batch.blocks+0x230c>
    284c:      	tbz	w16, #0x3, 0x2814 <_llm_rows.packet_batch.blocks+0x2318>
    2850:      	add	x17, x11, #0xc
    2854:      	ld1.s	{ v2 }[3], [x17]
    2858:      	tbnz	w16, #0x4, 0x2818 <_llm_rows.packet_batch.blocks+0x231c>
    285c:      	tbz	w16, #0x5, 0x2824 <_llm_rows.packet_batch.blocks+0x2328>
    2860:      	add	x17, x11, #0x14
    2864:      	ld1.s	{ v7 }[1], [x17]
    2868:      	tbnz	w16, #0x6, 0x2828 <_llm_rows.packet_batch.blocks+0x232c>
    286c:      	tbz	w16, #0x7, 0x2878 <_llm_rows.packet_batch.blocks+0x237c>
    2870:      	add	x11, x11, #0x1c
    2874:      	ld1.s	{ v7 }[3], [x11]
    2878:      	fmov	w16, s17
    287c:      	ldr	q18, [sp, #0x700]
    2880:      	ldr	q19, [sp, #0x710]
    2884:      	bif.16b	v7, v19, v16
    2888:      	bif.16b	v2, v18, v0
    288c:      	str	q2, [sp, #0x700]
    2890:      	str	q7, [sp, #0x710]
    2894:      	add.2d	v30, v31, v3
    2898:      	fmov	x11, d30
    289c:      	add	x11, x10, x11, lsl #2
    28a0:      	movi.2d	v2, #0000000000000000
    28a4:      	movi.2d	v3, #0000000000000000
    28a8:      	tbz	w16, #0x0, 0x28ec <_llm_rows.packet_batch.blocks+0x23f0>
    28ac:      	ldr	s2, [x11]
    28b0:      	and	w16, w16, #0xff
    28b4:      	tbnz	w16, #0x1, 0x28f4 <_llm_rows.packet_batch.blocks+0x23f8>
    28b8:      	tbz	w16, #0x2, 0x2900 <_llm_rows.packet_batch.blocks+0x2404>
    28bc:      	add	x17, x11, #0x8
    28c0:      	ld1.s	{ v2 }[2], [x17]
    28c4:      	tbnz	w16, #0x3, 0x2904 <_llm_rows.packet_batch.blocks+0x2408>
    28c8:      	tbz	w16, #0x4, 0x2910 <_llm_rows.packet_batch.blocks+0x2414>
    28cc:      	add	x17, x11, #0x10
    28d0:      	ld1.s	{ v3 }[0], [x17]
    28d4:      	tbnz	w16, #0x5, 0x2914 <_llm_rows.packet_batch.blocks+0x2418>
    28d8:      	tbz	w16, #0x6, 0x2920 <_llm_rows.packet_batch.blocks+0x2424>
    28dc:      	add	x17, x11, #0x18
    28e0:      	ld1.s	{ v3 }[2], [x17]
    28e4:      	tbnz	w16, #0x7, 0x2924 <_llm_rows.packet_batch.blocks+0x2428>
    28e8:      	b	0x292c <_llm_rows.packet_batch.blocks+0x2430>
    28ec:      	and	w16, w16, #0xff
    28f0:      	tbz	w16, #0x1, 0x28b8 <_llm_rows.packet_batch.blocks+0x23bc>
    28f4:      	add	x17, x11, #0x4
    28f8:      	ld1.s	{ v2 }[1], [x17]
    28fc:      	tbnz	w16, #0x2, 0x28bc <_llm_rows.packet_batch.blocks+0x23c0>
    2900:      	tbz	w16, #0x3, 0x28c8 <_llm_rows.packet_batch.blocks+0x23cc>
    2904:      	add	x17, x11, #0xc
    2908:      	ld1.s	{ v2 }[3], [x17]
    290c:      	tbnz	w16, #0x4, 0x28cc <_llm_rows.packet_batch.blocks+0x23d0>
    2910:      	tbz	w16, #0x5, 0x28d8 <_llm_rows.packet_batch.blocks+0x23dc>
    2914:      	add	x17, x11, #0x14
    2918:      	ld1.s	{ v3 }[1], [x17]
    291c:      	tbnz	w16, #0x6, 0x28dc <_llm_rows.packet_batch.blocks+0x23e0>
    2920:      	tbz	w16, #0x7, 0x292c <_llm_rows.packet_batch.blocks+0x2430>
    2924:      	add	x11, x11, #0x1c
    2928:      	ld1.s	{ v3 }[3], [x11]
    292c:      	fmov	w16, s17
    2930:      	ldr	q7, [sp, #0x720]
    2934:      	ldr	q18, [sp, #0x730]
    2938:      	bif.16b	v3, v18, v16
    293c:      	bif.16b	v2, v7, v0
    2940:      	str	q2, [sp, #0x720]
    2944:      	str	q3, [sp, #0x730]
    2948:      	add.2d	v7, v31, v29
    294c:      	fmov	x11, d7
    2950:      	add	x11, x10, x11, lsl #2
    2954:      	movi.2d	v2, #0000000000000000
    2958:      	movi.2d	v3, #0000000000000000
    295c:      	tbz	w16, #0x0, 0x29a0 <_llm_rows.packet_batch.blocks+0x24a4>
    2960:      	ldr	s2, [x11]
    2964:      	and	w16, w16, #0xff
    2968:      	tbnz	w16, #0x1, 0x29a8 <_llm_rows.packet_batch.blocks+0x24ac>
    296c:      	tbz	w16, #0x2, 0x29b4 <_llm_rows.packet_batch.blocks+0x24b8>
    2970:      	add	x17, x11, #0x8
    2974:      	ld1.s	{ v2 }[2], [x17]
    2978:      	tbnz	w16, #0x3, 0x29b8 <_llm_rows.packet_batch.blocks+0x24bc>
    297c:      	tbz	w16, #0x4, 0x29c4 <_llm_rows.packet_batch.blocks+0x24c8>
    2980:      	add	x17, x11, #0x10
    2984:      	ld1.s	{ v3 }[0], [x17]
    2988:      	tbnz	w16, #0x5, 0x29c8 <_llm_rows.packet_batch.blocks+0x24cc>
    298c:      	tbz	w16, #0x6, 0x29d4 <_llm_rows.packet_batch.blocks+0x24d8>
    2990:      	add	x17, x11, #0x18
    2994:      	ld1.s	{ v3 }[2], [x17]
    2998:      	tbnz	w16, #0x7, 0x29d8 <_llm_rows.packet_batch.blocks+0x24dc>
    299c:      	b	0x29e0 <_llm_rows.packet_batch.blocks+0x24e4>
    29a0:      	and	w16, w16, #0xff
    29a4:      	tbz	w16, #0x1, 0x296c <_llm_rows.packet_batch.blocks+0x2470>
    29a8:      	add	x17, x11, #0x4
    29ac:      	ld1.s	{ v2 }[1], [x17]
    29b0:      	tbnz	w16, #0x2, 0x2970 <_llm_rows.packet_batch.blocks+0x2474>
    29b4:      	tbz	w16, #0x3, 0x297c <_llm_rows.packet_batch.blocks+0x2480>
    29b8:      	add	x17, x11, #0xc
    29bc:      	ld1.s	{ v2 }[3], [x17]
    29c0:      	tbnz	w16, #0x4, 0x2980 <_llm_rows.packet_batch.blocks+0x2484>
    29c4:      	tbz	w16, #0x5, 0x298c <_llm_rows.packet_batch.blocks+0x2490>
    29c8:      	add	x17, x11, #0x14
    29cc:      	ld1.s	{ v3 }[1], [x17]
    29d0:      	tbnz	w16, #0x6, 0x2990 <_llm_rows.packet_batch.blocks+0x2494>
    29d4:      	tbz	w16, #0x7, 0x29e0 <_llm_rows.packet_batch.blocks+0x24e4>
    29d8:      	add	x11, x11, #0x1c
    29dc:      	ld1.s	{ v3 }[3], [x11]
    29e0:      	orr.16b	v29, v24, v1
    29e4:      	orr.16b	v9, v9, v1
    29e8:      	orr.16b	v1, v8, v1
    29ec:      	sshll.2d	v18, v16, #0x0
    29f0:      	umull.2d	v19, v25, v11
    29f4:      	umull.2d	v23, v27, v11
    29f8:      	umull.2d	v24, v26, v11
    29fc:      	mov.16b	v11, v29
    2a00:      	and.16b	v24, v10, v24
    2a04:      	and.16b	v18, v18, v23
    2a08:      	and.16b	v19, v28, v19
    2a0c:      	ldr	q23, [sp, #0x740]
    2a10:      	ldr	q25, [sp, #0x750]
    2a14:      	bif.16b	v3, v25, v16
    2a18:      	bif.16b	v2, v23, v0
    2a1c:      	str	q2, [sp, #0x740]
    2a20:      	str	q3, [sp, #0x750]
    2a24:      	add.2d	v2, v24, v1
    2a28:      	add.2d	v3, v18, v29
    2a2c:      	add.2d	v18, v19, v9
    2a30:      	ldr	q25, [sp, #0x200]
    2a34:      	add.2d	v19, v31, v25
    2a38:      	mov	b23, v20[0]
    2a3c:      	mov.b	v23[4], v20[1]
    2a40:      	ushll.2d	v23, v23, #0x0
    2a44:      	shl.2d	v23, v23, #0x3f
    2a48:      	cmlt.2d	v23, v23, #0
    2a4c:      	and.16b	v19, v23, v19
    2a50:      	mov	b23, v20[2]
    2a54:      	mov.b	v23[4], v20[3]
    2a58:      	ushll.2d	v23, v23, #0x0
    2a5c:      	shl.2d	v23, v23, #0x3f
    2a60:      	cmlt.2d	v23, v23, #0
    2a64:      	and.16b	v18, v23, v18
    2a68:      	mov	b23, v20[4]
    2a6c:      	mov.b	v23[4], v20[5]
    2a70:      	ushll.2d	v23, v23, #0x0
    2a74:      	shl.2d	v23, v23, #0x3f
    2a78:      	cmlt.2d	v23, v23, #0
    2a7c:      	mov	b24, v20[6]
    2a80:      	mov.b	v24[4], v20[7]
    2a84:      	and.16b	v3, v23, v3
    2a88:      	ushll.2d	v23, v24, #0x0
    2a8c:      	shl.2d	v23, v23, #0x3f
    2a90:      	cmlt.2d	v23, v23, #0
    2a94:      	and.16b	v2, v23, v2
    2a98:      	str	q2, [sp, #0x530]
    2a9c:      	str	q3, [sp, #0x520]
    2aa0:      	str	q18, [sp, #0x510]
    2aa4:      	str	q19, [sp, #0x500]
    2aa8:      	and	x11, x12, #0x7
    2aac:      	add	x16, sp, #0x500
    2ab0:      	ldr	x11, [x16, x11, lsl #3]
    2ab4:      	fmov	w16, s14
    2ab8:      	sub	x11, x11, x12
    2abc:      	lsl	x11, x11, #2
    2ac0:      	add	x10, x10, x11
    2ac4:      	movi.2d	v2, #0000000000000000
    2ac8:      	movi.2d	v3, #0000000000000000
    2acc:      	tbz	w16, #0x0, 0x2b0c <_llm_rows.packet_batch.blocks+0x2610>
    2ad0:      	ldr	s2, [x10]
    2ad4:      	tbnz	w16, #0x1, 0x2b10 <_llm_rows.packet_batch.blocks+0x2614>
    2ad8:      	tbz	w16, #0x2, 0x2b1c <_llm_rows.packet_batch.blocks+0x2620>
    2adc:      	add	x17, x10, #0x8
    2ae0:      	ld1.s	{ v2 }[2], [x17]
    2ae4:      	tbnz	w16, #0x3, 0x2b20 <_llm_rows.packet_batch.blocks+0x2624>
    2ae8:      	tbz	w16, #0x4, 0x2b2c <_llm_rows.packet_batch.blocks+0x2630>
    2aec:      	add	x17, x10, #0x10
    2af0:      	ld1.s	{ v3 }[0], [x17]
    2af4:      	tbnz	w16, #0x5, 0x2b30 <_llm_rows.packet_batch.blocks+0x2634>
    2af8:      	tbz	w16, #0x6, 0x2b3c <_llm_rows.packet_batch.blocks+0x2640>
    2afc:      	add	x17, x10, #0x18
    2b00:      	ld1.s	{ v3 }[2], [x17]
    2b04:      	tbnz	w16, #0x7, 0x2b40 <_llm_rows.packet_batch.blocks+0x2644>
    2b08:      	b	0x2b48 <_llm_rows.packet_batch.blocks+0x264c>
    2b0c:      	tbz	w16, #0x1, 0x2ad8 <_llm_rows.packet_batch.blocks+0x25dc>
    2b10:      	add	x17, x10, #0x4
    2b14:      	ld1.s	{ v2 }[1], [x17]
    2b18:      	tbnz	w16, #0x2, 0x2adc <_llm_rows.packet_batch.blocks+0x25e0>
    2b1c:      	tbz	w16, #0x3, 0x2ae8 <_llm_rows.packet_batch.blocks+0x25ec>
    2b20:      	add	x17, x10, #0xc
    2b24:      	ld1.s	{ v2 }[3], [x17]
    2b28:      	tbnz	w16, #0x4, 0x2aec <_llm_rows.packet_batch.blocks+0x25f0>
    2b2c:      	tbz	w16, #0x5, 0x2af8 <_llm_rows.packet_batch.blocks+0x25fc>
    2b30:      	add	x17, x10, #0x14
    2b34:      	ld1.s	{ v3 }[1], [x17]
    2b38:      	tbnz	w16, #0x6, 0x2afc <_llm_rows.packet_batch.blocks+0x2600>
    2b3c:      	tbz	w16, #0x7, 0x2b48 <_llm_rows.packet_batch.blocks+0x264c>
    2b40:      	add	x10, x10, #0x1c
    2b44:      	ld1.s	{ v3 }[3], [x10]
    2b48:      	and.16b	v4, v4, v6
    2b4c:      	fmov	w16, s17
    2b50:      	add	x10, x3, x15
    2b54:      	ldp	q6, q18, [x10]
    2b58:      	zip2.8b	v19, v20, v0
    2b5c:      	ushll.4s	v19, v19, #0x0
    2b60:      	shl.4s	v19, v19, #0x1f
    2b64:      	cmlt.4s	v19, v19, #0
    2b68:      	bif.16b	v3, v18, v19
    2b6c:      	zip1.8b	v18, v20, v0
    2b70:      	ushll.4s	v18, v18, #0x0
    2b74:      	shl.4s	v18, v18, #0x1f
    2b78:      	cmlt.4s	v18, v18, #0
    2b7c:      	bif.16b	v2, v6, v18
    2b80:      	stp	q2, q3, [x10]
    2b84:      	fmov	x10, d4
    2b88:      	add	x10, x9, x10, lsl #2
    2b8c:      	movi.2d	v2, #0000000000000000
    2b90:      	movi.2d	v3, #0000000000000000
    2b94:      	tbz	w16, #0x0, 0x2bd8 <_llm_rows.packet_batch.blocks+0x26dc>
    2b98:      	ldr	s2, [x10]
    2b9c:      	and	w16, w16, #0xff
    2ba0:      	tbnz	w16, #0x1, 0x2be0 <_llm_rows.packet_batch.blocks+0x26e4>
    2ba4:      	tbz	w16, #0x2, 0x2bec <_llm_rows.packet_batch.blocks+0x26f0>
    2ba8:      	add	x17, x10, #0x8
    2bac:      	ld1.s	{ v2 }[2], [x17]
    2bb0:      	tbnz	w16, #0x3, 0x2bf0 <_llm_rows.packet_batch.blocks+0x26f4>
    2bb4:      	tbz	w16, #0x4, 0x2bfc <_llm_rows.packet_batch.blocks+0x2700>
    2bb8:      	add	x17, x10, #0x10
    2bbc:      	ld1.s	{ v3 }[0], [x17]
    2bc0:      	tbnz	w16, #0x5, 0x2c00 <_llm_rows.packet_batch.blocks+0x2704>
    2bc4:      	tbz	w16, #0x6, 0x2c0c <_llm_rows.packet_batch.blocks+0x2710>
    2bc8:      	add	x17, x10, #0x18
    2bcc:      	ld1.s	{ v3 }[2], [x17]
    2bd0:      	tbnz	w16, #0x7, 0x2c10 <_llm_rows.packet_batch.blocks+0x2714>
    2bd4:      	b	0x2c18 <_llm_rows.packet_batch.blocks+0x271c>
    2bd8:      	and	w16, w16, #0xff
    2bdc:      	tbz	w16, #0x1, 0x2ba4 <_llm_rows.packet_batch.blocks+0x26a8>
    2be0:      	add	x17, x10, #0x4
    2be4:      	ld1.s	{ v2 }[1], [x17]
    2be8:      	tbnz	w16, #0x2, 0x2ba8 <_llm_rows.packet_batch.blocks+0x26ac>
    2bec:      	tbz	w16, #0x3, 0x2bb4 <_llm_rows.packet_batch.blocks+0x26b8>
    2bf0:      	add	x17, x10, #0xc
    2bf4:      	ld1.s	{ v2 }[3], [x17]
    2bf8:      	tbnz	w16, #0x4, 0x2bb8 <_llm_rows.packet_batch.blocks+0x26bc>
    2bfc:      	tbz	w16, #0x5, 0x2bc4 <_llm_rows.packet_batch.blocks+0x26c8>
    2c00:      	add	x17, x10, #0x14
    2c04:      	ld1.s	{ v3 }[1], [x17]
    2c08:      	tbnz	w16, #0x6, 0x2bc8 <_llm_rows.packet_batch.blocks+0x26cc>
    2c0c:      	tbz	w16, #0x7, 0x2c18 <_llm_rows.packet_batch.blocks+0x271c>
    2c10:      	add	x10, x10, #0x1c
    2c14:      	ld1.s	{ v3 }[3], [x10]
    2c18:      	sshll.2d	v4, v0, #0x0
    2c1c:      	and.16b	v4, v4, v5
    2c20:      	fmov	w16, s17
    2c24:      	ldr	q5, [sp, #0x640]
    2c28:      	ldr	q6, [sp, #0x650]
    2c2c:      	bif.16b	v3, v6, v16
    2c30:      	bif.16b	v2, v5, v0
    2c34:      	str	q2, [sp, #0x640]
    2c38:      	str	q3, [sp, #0x650]
    2c3c:      	fmov	x10, d4
    2c40:      	add	x10, x9, x10, lsl #2
    2c44:      	movi.2d	v2, #0000000000000000
    2c48:      	movi.2d	v3, #0000000000000000
    2c4c:      	tbz	w16, #0x0, 0x2c90 <_llm_rows.packet_batch.blocks+0x2794>
    2c50:      	ldr	s2, [x10]
    2c54:      	and	w16, w16, #0xff
    2c58:      	tbnz	w16, #0x1, 0x2c98 <_llm_rows.packet_batch.blocks+0x279c>
    2c5c:      	tbz	w16, #0x2, 0x2ca4 <_llm_rows.packet_batch.blocks+0x27a8>
    2c60:      	add	x17, x10, #0x8
    2c64:      	ld1.s	{ v2 }[2], [x17]
    2c68:      	tbnz	w16, #0x3, 0x2ca8 <_llm_rows.packet_batch.blocks+0x27ac>
    2c6c:      	tbz	w16, #0x4, 0x2cb4 <_llm_rows.packet_batch.blocks+0x27b8>
    2c70:      	add	x17, x10, #0x10
    2c74:      	ld1.s	{ v3 }[0], [x17]
    2c78:      	tbnz	w16, #0x5, 0x2cb8 <_llm_rows.packet_batch.blocks+0x27bc>
    2c7c:      	tbz	w16, #0x6, 0x2cc4 <_llm_rows.packet_batch.blocks+0x27c8>
    2c80:      	add	x17, x10, #0x18
    2c84:      	ld1.s	{ v3 }[2], [x17]
    2c88:      	tbnz	w16, #0x7, 0x2cc8 <_llm_rows.packet_batch.blocks+0x27cc>
    2c8c:      	b	0x2cd0 <_llm_rows.packet_batch.blocks+0x27d4>
    2c90:      	and	w16, w16, #0xff
    2c94:      	tbz	w16, #0x1, 0x2c5c <_llm_rows.packet_batch.blocks+0x2760>
    2c98:      	add	x17, x10, #0x4
    2c9c:      	ld1.s	{ v2 }[1], [x17]
    2ca0:      	tbnz	w16, #0x2, 0x2c60 <_llm_rows.packet_batch.blocks+0x2764>
    2ca4:      	tbz	w16, #0x3, 0x2c6c <_llm_rows.packet_batch.blocks+0x2770>
    2ca8:      	add	x17, x10, #0xc
    2cac:      	ld1.s	{ v2 }[3], [x17]
    2cb0:      	tbnz	w16, #0x4, 0x2c70 <_llm_rows.packet_batch.blocks+0x2774>
    2cb4:      	tbz	w16, #0x5, 0x2c7c <_llm_rows.packet_batch.blocks+0x2780>
    2cb8:      	add	x17, x10, #0x14
    2cbc:      	ld1.s	{ v3 }[1], [x17]
    2cc0:      	tbnz	w16, #0x6, 0x2c80 <_llm_rows.packet_batch.blocks+0x2784>
    2cc4:      	tbz	w16, #0x7, 0x2cd0 <_llm_rows.packet_batch.blocks+0x27d4>
    2cc8:      	add	x10, x10, #0x1c
    2ccc:      	ld1.s	{ v3 }[3], [x10]
    2cd0:      	sshll.2d	v4, v0, #0x0
    2cd4:      	and.16b	v4, v4, v30
    2cd8:      	fmov	w16, s17
    2cdc:      	ldr	q5, [sp, #0x660]
    2ce0:      	ldr	q6, [sp, #0x670]
    2ce4:      	bif.16b	v3, v6, v16
    2ce8:      	bif.16b	v2, v5, v0
    2cec:      	str	q2, [sp, #0x660]
    2cf0:      	str	q3, [sp, #0x670]
    2cf4:      	fmov	x10, d4
    2cf8:      	add	x10, x9, x10, lsl #2
    2cfc:      	movi.2d	v2, #0000000000000000
    2d00:      	movi.2d	v3, #0000000000000000
    2d04:      	tbz	w16, #0x0, 0x2d48 <_llm_rows.packet_batch.blocks+0x284c>
    2d08:      	ldr	s2, [x10]
    2d0c:      	and	w16, w16, #0xff
    2d10:      	tbnz	w16, #0x1, 0x2d50 <_llm_rows.packet_batch.blocks+0x2854>
    2d14:      	tbz	w16, #0x2, 0x2d5c <_llm_rows.packet_batch.blocks+0x2860>
    2d18:      	add	x17, x10, #0x8
    2d1c:      	ld1.s	{ v2 }[2], [x17]
    2d20:      	tbnz	w16, #0x3, 0x2d60 <_llm_rows.packet_batch.blocks+0x2864>
    2d24:      	tbz	w16, #0x4, 0x2d6c <_llm_rows.packet_batch.blocks+0x2870>
    2d28:      	add	x17, x10, #0x10
    2d2c:      	ld1.s	{ v3 }[0], [x17]
    2d30:      	tbnz	w16, #0x5, 0x2d70 <_llm_rows.packet_batch.blocks+0x2874>
    2d34:      	tbz	w16, #0x6, 0x2d7c <_llm_rows.packet_batch.blocks+0x2880>
    2d38:      	add	x17, x10, #0x18
    2d3c:      	ld1.s	{ v3 }[2], [x17]
    2d40:      	tbnz	w16, #0x7, 0x2d80 <_llm_rows.packet_batch.blocks+0x2884>
    2d44:      	b	0x2d88 <_llm_rows.packet_batch.blocks+0x288c>
    2d48:      	and	w16, w16, #0xff
    2d4c:      	tbz	w16, #0x1, 0x2d14 <_llm_rows.packet_batch.blocks+0x2818>
    2d50:      	add	x17, x10, #0x4
    2d54:      	ld1.s	{ v2 }[1], [x17]
    2d58:      	tbnz	w16, #0x2, 0x2d18 <_llm_rows.packet_batch.blocks+0x281c>
    2d5c:      	tbz	w16, #0x3, 0x2d24 <_llm_rows.packet_batch.blocks+0x2828>
    2d60:      	add	x17, x10, #0xc
    2d64:      	ld1.s	{ v2 }[3], [x17]
    2d68:      	tbnz	w16, #0x4, 0x2d28 <_llm_rows.packet_batch.blocks+0x282c>
    2d6c:      	tbz	w16, #0x5, 0x2d34 <_llm_rows.packet_batch.blocks+0x2838>
    2d70:      	add	x17, x10, #0x14
    2d74:      	ld1.s	{ v3 }[1], [x17]
    2d78:      	tbnz	w16, #0x6, 0x2d38 <_llm_rows.packet_batch.blocks+0x283c>
    2d7c:      	tbz	w16, #0x7, 0x2d88 <_llm_rows.packet_batch.blocks+0x288c>
    2d80:      	add	x10, x10, #0x1c
    2d84:      	ld1.s	{ v3 }[3], [x10]
    2d88:      	sshll.2d	v4, v0, #0x0
    2d8c:      	and.16b	v4, v4, v7
    2d90:      	fmov	w16, s17
    2d94:      	ldr	q5, [sp, #0x680]
    2d98:      	ldr	q6, [sp, #0x690]
    2d9c:      	bif.16b	v3, v6, v16
    2da0:      	bif.16b	v2, v5, v0
    2da4:      	str	q2, [sp, #0x680]
    2da8:      	str	q3, [sp, #0x690]
    2dac:      	fmov	x10, d4
    2db0:      	add	x10, x9, x10, lsl #2
    2db4:      	movi.2d	v2, #0000000000000000
    2db8:      	movi.2d	v3, #0000000000000000
    2dbc:      	tbz	w16, #0x0, 0x2e00 <_llm_rows.packet_batch.blocks+0x2904>
    2dc0:      	ldr	s2, [x10]
    2dc4:      	and	w16, w16, #0xff
    2dc8:      	tbnz	w16, #0x1, 0x2e08 <_llm_rows.packet_batch.blocks+0x290c>
    2dcc:      	tbz	w16, #0x2, 0x2e14 <_llm_rows.packet_batch.blocks+0x2918>
    2dd0:      	add	x17, x10, #0x8
    2dd4:      	ld1.s	{ v2 }[2], [x17]
    2dd8:      	tbnz	w16, #0x3, 0x2e18 <_llm_rows.packet_batch.blocks+0x291c>
    2ddc:      	tbz	w16, #0x4, 0x2e24 <_llm_rows.packet_batch.blocks+0x2928>
    2de0:      	add	x17, x10, #0x10
    2de4:      	ld1.s	{ v3 }[0], [x17]
    2de8:      	tbnz	w16, #0x5, 0x2e28 <_llm_rows.packet_batch.blocks+0x292c>
    2dec:      	tbz	w16, #0x6, 0x2e34 <_llm_rows.packet_batch.blocks+0x2938>
    2df0:      	add	x17, x10, #0x18
    2df4:      	ld1.s	{ v3 }[2], [x17]
    2df8:      	tbnz	w16, #0x7, 0x2e38 <_llm_rows.packet_batch.blocks+0x293c>
    2dfc:      	b	0x2e40 <_llm_rows.packet_batch.blocks+0x2944>
    2e00:      	and	w16, w16, #0xff
    2e04:      	tbz	w16, #0x1, 0x2dcc <_llm_rows.packet_batch.blocks+0x28d0>
    2e08:      	add	x17, x10, #0x4
    2e0c:      	ld1.s	{ v2 }[1], [x17]
    2e10:      	tbnz	w16, #0x2, 0x2dd0 <_llm_rows.packet_batch.blocks+0x28d4>
    2e14:      	tbz	w16, #0x3, 0x2ddc <_llm_rows.packet_batch.blocks+0x28e0>
    2e18:      	add	x17, x10, #0xc
    2e1c:      	ld1.s	{ v2 }[3], [x17]
    2e20:      	tbnz	w16, #0x4, 0x2de0 <_llm_rows.packet_batch.blocks+0x28e4>
    2e24:      	tbz	w16, #0x5, 0x2dec <_llm_rows.packet_batch.blocks+0x28f0>
    2e28:      	add	x17, x10, #0x14
    2e2c:      	ld1.s	{ v3 }[1], [x17]
    2e30:      	tbnz	w16, #0x6, 0x2df0 <_llm_rows.packet_batch.blocks+0x28f4>
    2e34:      	tbz	w16, #0x7, 0x2e40 <_llm_rows.packet_batch.blocks+0x2944>
    2e38:      	add	x10, x10, #0x1c
    2e3c:      	ld1.s	{ v3 }[3], [x10]
    2e40:      	ldr	q4, [sp, #0x6a0]
    2e44:      	ldr	q5, [sp, #0x6b0]
    2e48:      	bif.16b	v3, v5, v16
    2e4c:      	bif.16b	v2, v4, v0
    2e50:      	str	q2, [sp, #0x6a0]
    2e54:      	str	q3, [sp, #0x6b0]
    2e58:      	add	x9, x9, x11
    2e5c:      	fmov	w10, s14
    2e60:      	movi.2d	v2, #0000000000000000
    2e64:      	movi.2d	v3, #0000000000000000
    2e68:      	tbz	w10, #0x0, 0x2ea8 <_llm_rows.packet_batch.blocks+0x29ac>
    2e6c:      	ldr	s2, [x9]
    2e70:      	tbnz	w10, #0x1, 0x2eac <_llm_rows.packet_batch.blocks+0x29b0>
    2e74:      	tbz	w10, #0x2, 0x2eb8 <_llm_rows.packet_batch.blocks+0x29bc>
    2e78:      	add	x11, x9, #0x8
    2e7c:      	ld1.s	{ v2 }[2], [x11]
    2e80:      	tbnz	w10, #0x3, 0x2ebc <_llm_rows.packet_batch.blocks+0x29c0>
    2e84:      	tbz	w10, #0x4, 0x2ec8 <_llm_rows.packet_batch.blocks+0x29cc>
    2e88:      	add	x11, x9, #0x10
    2e8c:      	ld1.s	{ v3 }[0], [x11]
    2e90:      	tbnz	w10, #0x5, 0x2ecc <_llm_rows.packet_batch.blocks+0x29d0>
    2e94:      	tbz	w10, #0x6, 0x2ed8 <_llm_rows.packet_batch.blocks+0x29dc>
    2e98:      	add	x11, x9, #0x18
    2e9c:      	ld1.s	{ v3 }[2], [x11]
    2ea0:      	tbnz	w10, #0x7, 0x2edc <_llm_rows.packet_batch.blocks+0x29e0>
    2ea4:      	b	0x2ee4 <_llm_rows.packet_batch.blocks+0x29e8>
    2ea8:      	tbz	w10, #0x1, 0x2e74 <_llm_rows.packet_batch.blocks+0x2978>
    2eac:      	add	x11, x9, #0x4
    2eb0:      	ld1.s	{ v2 }[1], [x11]
    2eb4:      	tbnz	w10, #0x2, 0x2e78 <_llm_rows.packet_batch.blocks+0x297c>
    2eb8:      	tbz	w10, #0x3, 0x2e84 <_llm_rows.packet_batch.blocks+0x2988>
    2ebc:      	add	x11, x9, #0xc
    2ec0:      	ld1.s	{ v2 }[3], [x11]
    2ec4:      	tbnz	w10, #0x4, 0x2e88 <_llm_rows.packet_batch.blocks+0x298c>
    2ec8:      	tbz	w10, #0x5, 0x2e94 <_llm_rows.packet_batch.blocks+0x2998>
    2ecc:      	add	x11, x9, #0x14
    2ed0:      	ld1.s	{ v3 }[1], [x11]
    2ed4:      	tbnz	w10, #0x6, 0x2e98 <_llm_rows.packet_batch.blocks+0x299c>
    2ed8:      	tbz	w10, #0x7, 0x2ee4 <_llm_rows.packet_batch.blocks+0x29e8>
    2edc:      	add	x9, x9, #0x1c
    2ee0:      	ld1.s	{ v3 }[3], [x9]
    2ee4:      	adrp	x9, 0x2000 <_llm_rows.packet_batch.blocks+0x1b04>
    2ee8:      	ldr	q4, [x9]
    2eec:      	and.16b	v4, v15, v4
    2ef0:      	and.16b	v5, v15, v21
    2ef4:      	fmov	w10, s17
    2ef8:      	add	x9, x4, x15
    2efc:      	ldp	q6, q7, [x9]
    2f00:      	zip2.8b	v18, v20, v0
    2f04:      	ushll.4s	v18, v18, #0x0
    2f08:      	shl.4s	v18, v18, #0x1f
    2f0c:      	cmlt.4s	v18, v18, #0
    2f10:      	bif.16b	v3, v7, v18
    2f14:      	zip1.8b	v7, v20, v0
    2f18:      	ushll.4s	v7, v7, #0x0
    2f1c:      	shl.4s	v7, v7, #0x1f
    2f20:      	cmlt.4s	v7, v7, #0
    2f24:      	bif.16b	v2, v6, v7
    2f28:      	stp	q2, q3, [x9]
    2f2c:      	fmov	x9, d4
    2f30:      	add	x11, x1, x9
    2f34:      	ldp	q2, q6, [x11]
    2f38:      	add	x11, x3, x9
    2f3c:      	ldp	q3, q7, [x11]
    2f40:      	str	q2, [sp, #0xa0]
    2f44:      	str	q3, [sp, #0x80]
    2f48:      	fmul.4s	v2, v2, v3
    2f4c:      	add	x11, x2, x9
    2f50:      	ldp	q3, q18, [x11]
    2f54:      	add	x9, x4, x9
    2f58:      	ldp	q21, q19, [x9]
    2f5c:      	stp	q21, q3, [sp, #0x60]
    2f60:      	fmul.4s	v3, v3, v21
    2f64:      	fsub.4s	v2, v2, v3
    2f68:      	and.16b	v2, v0, v2
    2f6c:      	fmov	x9, d5
    2f70:      	add	x9, x8, x9, lsl #2
    2f74:      	tbz	w10, #0x0, 0x2fcc <_llm_rows.packet_batch.blocks+0x2ad0>
    2f78:      	str	s2, [x9]
    2f7c:      	and	w10, w10, #0xff
    2f80:      	tbnz	w10, #0x1, 0x2fd4 <_llm_rows.packet_batch.blocks+0x2ad8>
    2f84:      	tbz	w10, #0x2, 0x2fe0 <_llm_rows.packet_batch.blocks+0x2ae4>
    2f88:      	add	x11, x9, #0x8
    2f8c:      	st1.s	{ v2 }[2], [x11]
    2f90:      	tbnz	w10, #0x3, 0x2fe4 <_llm_rows.packet_batch.blocks+0x2ae8>
    2f94:      	fmul.4s	v2, v6, v7
    2f98:      	fmul.4s	v3, v18, v19
    2f9c:      	fsub.4s	v2, v2, v3
    2fa0:      	and.16b	v2, v16, v2
    2fa4:      	tbz	w10, #0x4, 0x3000 <_llm_rows.packet_batch.blocks+0x2b04>
    2fa8:      	str	s2, [x9, #0x10]
    2fac:      	tbnz	w10, #0x5, 0x3004 <_llm_rows.packet_batch.blocks+0x2b08>
    2fb0:      	tbz	w10, #0x6, 0x3010 <_llm_rows.packet_batch.blocks+0x2b14>
    2fb4:      	add	x11, x9, #0x18
    2fb8:      	st1.s	{ v2 }[2], [x11]
    2fbc:      	stp	q19, q18, [sp, #0x100]
    2fc0:      	mov.16b	v23, v28
    2fc4:      	tbnz	w10, #0x7, 0x301c <_llm_rows.packet_batch.blocks+0x2b20>
    2fc8:      	b	0x3024 <_llm_rows.packet_batch.blocks+0x2b28>
    2fcc:      	and	w10, w10, #0xff
    2fd0:      	tbz	w10, #0x1, 0x2f84 <_llm_rows.packet_batch.blocks+0x2a88>
    2fd4:      	add	x11, x9, #0x4
    2fd8:      	st1.s	{ v2 }[1], [x11]
    2fdc:      	tbnz	w10, #0x2, 0x2f88 <_llm_rows.packet_batch.blocks+0x2a8c>
    2fe0:      	tbz	w10, #0x3, 0x2f94 <_llm_rows.packet_batch.blocks+0x2a98>
    2fe4:      	add	x11, x9, #0xc
    2fe8:      	st1.s	{ v2 }[3], [x11]
    2fec:      	fmul.4s	v2, v6, v7
    2ff0:      	fmul.4s	v3, v18, v19
    2ff4:      	fsub.4s	v2, v2, v3
    2ff8:      	and.16b	v2, v16, v2
    2ffc:      	tbnz	w10, #0x4, 0x2fa8 <_llm_rows.packet_batch.blocks+0x2aac>
    3000:      	tbz	w10, #0x5, 0x2fb0 <_llm_rows.packet_batch.blocks+0x2ab4>
    3004:      	add	x11, x9, #0x14
    3008:      	st1.s	{ v2 }[1], [x11]
    300c:      	tbnz	w10, #0x6, 0x2fb4 <_llm_rows.packet_batch.blocks+0x2ab8>
    3010:      	stp	q19, q18, [sp, #0x100]
    3014:      	mov.16b	v23, v28
    3018:      	tbz	w10, #0x7, 0x3024 <_llm_rows.packet_batch.blocks+0x2b28>
    301c:      	add	x9, x9, #0x1c
    3020:      	st1.s	{ v2 }[3], [x9]
    3024:      	ldr	q2, [sp, #0x280]
    3028:      	ldr	q3, [sp, #0x150]
    302c:      	and.16b	v3, v3, v2
    3030:      	mov	w9, #0x20               ; =32
    3034:      	fmov	d2, x9
    3038:      	and.16b	v2, v13, v2
    303c:      	fmov	w10, s17
    3040:      	fmov	x9, d2
    3044:      	add	x11, x1, x9
    3048:      	ldp	q2, q21, [x11]
    304c:      	add	x11, x3, x9
    3050:      	ldp	q5, q26, [x11]
    3054:      	stp	q5, q2, [sp, #0x40]
    3058:      	fmul.4s	v2, v2, v5
    305c:      	add	x11, x2, x9
    3060:      	ldp	q18, q27, [x11]
    3064:      	add	x9, x4, x9
    3068:      	ldp	q19, q29, [x9]
    306c:      	fmul.4s	v5, v18, v19
    3070:      	fsub.4s	v2, v2, v5
    3074:      	and.16b	v2, v0, v2
    3078:      	fmov	x9, d3
    307c:      	add	x9, x8, x9, lsl #2
    3080:      	tbz	w10, #0x0, 0x30e0 <_llm_rows.packet_batch.blocks+0x2be4>
    3084:      	str	s2, [x9]
    3088:      	and	w10, w10, #0xff
    308c:      	tbnz	w10, #0x1, 0x30e8 <_llm_rows.packet_batch.blocks+0x2bec>
    3090:      	tbz	w10, #0x2, 0x30f4 <_llm_rows.packet_batch.blocks+0x2bf8>
    3094:      	add	x11, x9, #0x8
    3098:      	st1.s	{ v2 }[2], [x11]
    309c:      	tbnz	w10, #0x3, 0x30f8 <_llm_rows.packet_batch.blocks+0x2bfc>
    30a0:      	fmul.4s	v2, v21, v26
    30a4:      	fmul.4s	v3, v27, v29
    30a8:      	fsub.4s	v2, v2, v3
    30ac:      	and.16b	v2, v16, v2
    30b0:      	tbz	w10, #0x4, 0x3114 <_llm_rows.packet_batch.blocks+0x2c18>
    30b4:      	str	s2, [x9, #0x10]
    30b8:      	tbnz	w10, #0x5, 0x3118 <_llm_rows.packet_batch.blocks+0x2c1c>
    30bc:      	tbz	w10, #0x6, 0x3124 <_llm_rows.packet_batch.blocks+0x2c28>
    30c0:      	add	x11, x9, #0x18
    30c4:      	st1.s	{ v2 }[2], [x11]
    30c8:      	str	q21, [sp, #0xf0]
    30cc:      	str	q7, [sp, #0x120]
    30d0:      	str	q6, [sp, #0x150]
    30d4:      	str	d14, [sp, #0x280]
    30d8:      	tbnz	w10, #0x7, 0x3138 <_llm_rows.packet_batch.blocks+0x2c3c>
    30dc:      	b	0x3140 <_llm_rows.packet_batch.blocks+0x2c44>
    30e0:      	and	w10, w10, #0xff
    30e4:      	tbz	w10, #0x1, 0x3090 <_llm_rows.packet_batch.blocks+0x2b94>
    30e8:      	add	x11, x9, #0x4
    30ec:      	st1.s	{ v2 }[1], [x11]
    30f0:      	tbnz	w10, #0x2, 0x3094 <_llm_rows.packet_batch.blocks+0x2b98>
    30f4:      	tbz	w10, #0x3, 0x30a0 <_llm_rows.packet_batch.blocks+0x2ba4>
    30f8:      	add	x11, x9, #0xc
    30fc:      	st1.s	{ v2 }[3], [x11]
    3100:      	fmul.4s	v2, v21, v26
    3104:      	fmul.4s	v3, v27, v29
    3108:      	fsub.4s	v2, v2, v3
    310c:      	and.16b	v2, v16, v2
    3110:      	tbnz	w10, #0x4, 0x30b4 <_llm_rows.packet_batch.blocks+0x2bb8>
    3114:      	tbz	w10, #0x5, 0x30bc <_llm_rows.packet_batch.blocks+0x2bc0>
    3118:      	add	x11, x9, #0x14
    311c:      	st1.s	{ v2 }[1], [x11]
    3120:      	tbnz	w10, #0x6, 0x30c0 <_llm_rows.packet_batch.blocks+0x2bc4>
    3124:      	str	q21, [sp, #0xf0]
    3128:      	str	q7, [sp, #0x120]
    312c:      	str	q6, [sp, #0x150]
    3130:      	str	d14, [sp, #0x280]
    3134:      	tbz	w10, #0x7, 0x3140 <_llm_rows.packet_batch.blocks+0x2c44>
    3138:      	add	x9, x9, #0x1c
    313c:      	st1.s	{ v2 }[3], [x9]
    3140:      	ldr	q2, [sp, #0x220]
    3144:      	and.16b	v7, v13, v2
    3148:      	ldr	q2, [sp, #0x20]
    314c:      	and.16b	v2, v22, v2
    3150:      	fmov	w10, s17
    3154:      	fmov	x9, d2
    3158:      	add	x11, x1, x9
    315c:      	ldp	q2, q30, [x11]
    3160:      	add	x11, x3, x9
    3164:      	ldp	q3, q31, [x11]
    3168:      	str	q3, [sp, #0x30]
    316c:      	fmul.4s	v6, v2, v3
    3170:      	add	x11, x2, x9
    3174:      	ldp	q3, q8, [x11]
    3178:      	add	x9, x4, x9
    317c:      	ldp	q5, q24, [x9]
    3180:      	fmul.4s	v21, v3, v5
    3184:      	fsub.4s	v6, v6, v21
    3188:      	and.16b	v6, v0, v6
    318c:      	fmov	x9, d7
    3190:      	add	x9, x8, x9, lsl #2
    3194:      	tbz	w10, #0x0, 0x31f4 <_llm_rows.packet_batch.blocks+0x2cf8>
    3198:      	str	s6, [x9]
    319c:      	and	w10, w10, #0xff
    31a0:      	tbnz	w10, #0x1, 0x31fc <_llm_rows.packet_batch.blocks+0x2d00>
    31a4:      	tbz	w10, #0x2, 0x3208 <_llm_rows.packet_batch.blocks+0x2d0c>
    31a8:      	add	x11, x9, #0x8
    31ac:      	st1.s	{ v6 }[2], [x11]
    31b0:      	tbnz	w10, #0x3, 0x320c <_llm_rows.packet_batch.blocks+0x2d10>
    31b4:      	fmul.4s	v6, v30, v31
    31b8:      	fmul.4s	v7, v8, v24
    31bc:      	fsub.4s	v6, v6, v7
    31c0:      	and.16b	v6, v16, v6
    31c4:      	tbz	w10, #0x4, 0x3228 <_llm_rows.packet_batch.blocks+0x2d2c>
    31c8:      	str	s6, [x9, #0x10]
    31cc:      	tbnz	w10, #0x5, 0x322c <_llm_rows.packet_batch.blocks+0x2d30>
    31d0:      	tbz	w10, #0x6, 0x3238 <_llm_rows.packet_batch.blocks+0x2d3c>
    31d4:      	add	x11, x9, #0x18
    31d8:      	st1.s	{ v6 }[2], [x11]
    31dc:      	str	q8, [sp, #0x90]
    31e0:      	stp	q31, q30, [sp, #0xb0]
    31e4:      	stp	q29, q27, [sp, #0xd0]
    31e8:      	str	q26, [sp, #0x220]
    31ec:      	tbnz	w10, #0x7, 0x324c <_llm_rows.packet_batch.blocks+0x2d50>
    31f0:      	b	0x3254 <_llm_rows.packet_batch.blocks+0x2d58>
    31f4:      	and	w10, w10, #0xff
    31f8:      	tbz	w10, #0x1, 0x31a4 <_llm_rows.packet_batch.blocks+0x2ca8>
    31fc:      	add	x11, x9, #0x4
    3200:      	st1.s	{ v6 }[1], [x11]
    3204:      	tbnz	w10, #0x2, 0x31a8 <_llm_rows.packet_batch.blocks+0x2cac>
    3208:      	tbz	w10, #0x3, 0x31b4 <_llm_rows.packet_batch.blocks+0x2cb8>
    320c:      	add	x11, x9, #0xc
    3210:      	st1.s	{ v6 }[3], [x11]
    3214:      	fmul.4s	v6, v30, v31
    3218:      	fmul.4s	v7, v8, v24
    321c:      	fsub.4s	v6, v6, v7
    3220:      	and.16b	v6, v16, v6
    3224:      	tbnz	w10, #0x4, 0x31c8 <_llm_rows.packet_batch.blocks+0x2ccc>
    3228:      	tbz	w10, #0x5, 0x31d0 <_llm_rows.packet_batch.blocks+0x2cd4>
    322c:      	add	x11, x9, #0x14
    3230:      	st1.s	{ v6 }[1], [x11]
    3234:      	tbnz	w10, #0x6, 0x31d4 <_llm_rows.packet_batch.blocks+0x2cd8>
    3238:      	str	q8, [sp, #0x90]
    323c:      	stp	q31, q30, [sp, #0xb0]
    3240:      	stp	q29, q27, [sp, #0xd0]
    3244:      	str	q26, [sp, #0x220]
    3248:      	tbz	w10, #0x7, 0x3254 <_llm_rows.packet_batch.blocks+0x2d58>
    324c:      	add	x9, x9, #0x1c
    3250:      	st1.s	{ v6 }[3], [x9]
    3254:      	ldr	q6, [sp, #0x210]
    3258:      	and.16b	v21, v22, v6
    325c:      	sshll.2d	v6, v0, #0x0
    3260:      	ldr	q7, [sp, #0x10]
    3264:      	and.16b	v6, v6, v7
    3268:      	mov.16b	v22, v0
    326c:      	mov.16b	v0, v17
    3270:      	fmov	w10, s17
    3274:      	fmov	x9, d6
    3278:      	add	x11, x1, x9
    327c:      	ldp	q7, q26, [x11]
    3280:      	add	x11, x3, x9
    3284:      	ldp	q29, q28, [x11]
    3288:      	fmul.4s	v6, v7, v29
    328c:      	add	x11, x2, x9
    3290:      	ldp	q30, q27, [x11]
    3294:      	add	x9, x4, x9
    3298:      	ldp	q31, q17, [x9]
    329c:      	fmul.4s	v8, v30, v31
    32a0:      	fsub.4s	v6, v6, v8
    32a4:      	mov.16b	v14, v22
    32a8:      	and.16b	v6, v22, v6
    32ac:      	fmov	x9, d21
    32b0:      	add	x9, x8, x9, lsl #2
    32b4:      	tbz	w10, #0x0, 0x3304 <_llm_rows.packet_batch.blocks+0x2e08>
    32b8:      	str	s6, [x9]
    32bc:      	and	w10, w10, #0xff
    32c0:      	tbnz	w10, #0x1, 0x330c <_llm_rows.packet_batch.blocks+0x2e10>
    32c4:      	tbz	w10, #0x2, 0x3318 <_llm_rows.packet_batch.blocks+0x2e1c>
    32c8:      	add	x11, x9, #0x8
    32cc:      	st1.s	{ v6 }[2], [x11]
    32d0:      	tbnz	w10, #0x3, 0x331c <_llm_rows.packet_batch.blocks+0x2e20>
    32d4:      	fmul.4s	v6, v26, v28
    32d8:      	fmul.4s	v21, v27, v17
    32dc:      	fsub.4s	v6, v6, v21
    32e0:      	and.16b	v6, v16, v6
    32e4:      	tbz	w10, #0x4, 0x3338 <_llm_rows.packet_batch.blocks+0x2e3c>
    32e8:      	str	s6, [x9, #0x10]
    32ec:      	tbnz	w10, #0x5, 0x333c <_llm_rows.packet_batch.blocks+0x2e40>
    32f0:      	tbz	w10, #0x6, 0x3348 <_llm_rows.packet_batch.blocks+0x2e4c>
    32f4:      	add	x11, x9, #0x18
    32f8:      	st1.s	{ v6 }[2], [x11]
    32fc:      	tbnz	w10, #0x7, 0x334c <_llm_rows.packet_batch.blocks+0x2e50>
    3300:      	b	0x3354 <_llm_rows.packet_batch.blocks+0x2e58>
    3304:      	and	w10, w10, #0xff
    3308:      	tbz	w10, #0x1, 0x32c4 <_llm_rows.packet_batch.blocks+0x2dc8>
    330c:      	add	x11, x9, #0x4
    3310:      	st1.s	{ v6 }[1], [x11]
    3314:      	tbnz	w10, #0x2, 0x32c8 <_llm_rows.packet_batch.blocks+0x2dcc>
    3318:      	tbz	w10, #0x3, 0x32d4 <_llm_rows.packet_batch.blocks+0x2dd8>
    331c:      	add	x11, x9, #0xc
    3320:      	st1.s	{ v6 }[3], [x11]
    3324:      	fmul.4s	v6, v26, v28
    3328:      	fmul.4s	v21, v27, v17
    332c:      	fsub.4s	v6, v6, v21
    3330:      	and.16b	v6, v16, v6
    3334:      	tbnz	w10, #0x4, 0x32e8 <_llm_rows.packet_batch.blocks+0x2dec>
    3338:      	tbz	w10, #0x5, 0x32f0 <_llm_rows.packet_batch.blocks+0x2df4>
    333c:      	add	x11, x9, #0x14
    3340:      	st1.s	{ v6 }[1], [x11]
    3344:      	tbnz	w10, #0x6, 0x32f4 <_llm_rows.packet_batch.blocks+0x2df8>
    3348:      	tbz	w10, #0x7, 0x3354 <_llm_rows.packet_batch.blocks+0x2e58>
    334c:      	add	x9, x9, #0x1c
    3350:      	st1.s	{ v6 }[3], [x9]
    3354:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x2b04>
    3358:      	ldr	q6, [x9]
    335c:      	and.16b	v6, v10, v6
    3360:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x2b04>
    3364:      	ldr	q21, [x9]
    3368:      	and.16b	v21, v23, v21
    336c:      	adrp	x9, 0x3000 <_llm_rows.packet_batch.blocks+0x2b04>
    3370:      	ldr	q8, [x9]
    3374:      	ldr	q22, [sp, #0x160]
    3378:      	and.16b	v8, v22, v8
    337c:      	add.2d	v12, v12, v1
    3380:      	ldr	q1, [sp, #0x130]
    3384:      	add.2d	v13, v1, v11
    3388:      	ldr	q1, [sp, #0x140]
    338c:      	add.2d	v22, v1, v9
    3390:      	ldr	q1, [sp, #0x1e0]
    3394:      	add.2d	v23, v1, v25
    3398:      	str	q4, [sp, #0x4b0]
    339c:      	str	q21, [sp, #0x4c0]
    33a0:      	str	q8, [sp, #0x4d0]
    33a4:      	str	q6, [sp, #0x4e0]
    33a8:      	ubfiz	x10, x12, #3, #3
    33ac:      	add	x9, sp, #0x4b0
    33b0:      	ldr	x9, [x9, x10]
    33b4:      	orr	x9, x9, #0x80
    33b8:      	sub	x9, x9, x14
    33bc:      	tst	w13, #0xff
    33c0:      	csel	x9, xzr, x9, eq
    33c4:      	add	x11, x1, x9
    33c8:      	ldp	q8, q1, [x11]
    33cc:      	add	x11, x3, x9
    33d0:      	ldp	q9, q4, [x11]
    33d4:      	fmul.4s	v11, v8, v9
    33d8:      	add	x11, x2, x9
    33dc:      	ldp	q10, q6, [x11]
    33e0:      	add	x9, x4, x9
    33e4:      	ldp	q15, q21, [x9]
    33e8:      	fmul.4s	v25, v10, v15
    33ec:      	fsub.4s	v25, v11, v25
    33f0:      	zip1.8b	v11, v20, v0
    33f4:      	ushll.4s	v11, v11, #0x0
    33f8:      	shl.4s	v11, v11, #0x1f
    33fc:      	cmlt.4s	v11, v11, #0
    3400:      	and.16b	v11, v11, v25
    3404:      	ldr	d25, [sp, #0x280]
    3408:      	fmov	w9, s25
    340c:      	str	q23, [sp, #0x470]
    3410:      	str	q22, [sp, #0x480]
    3414:      	str	q13, [sp, #0x490]
    3418:      	str	q12, [sp, #0x4a0]
    341c:      	add	x11, sp, #0x470
    3420:      	ldr	x10, [x11, x10]
    3424:      	sub	x10, x10, x12
    3428:      	add	x10, x8, x10, lsl #2
    342c:      	tbz	w9, #0x0, 0x3450 <_llm_rows.packet_batch.blocks+0x2f54>
    3430:      	str	s11, [x10]
    3434:      	tbnz	w9, #0x1, 0x3454 <_llm_rows.packet_batch.blocks+0x2f58>
    3438:      	mov.16b	v12, v24
    343c:      	tbz	w9, #0x2, 0x3464 <_llm_rows.packet_batch.blocks+0x2f68>
    3440:      	add	x11, x10, #0x8
    3444:      	st1.s	{ v11 }[2], [x11]
    3448:      	tbnz	w9, #0x3, 0x3468 <_llm_rows.packet_batch.blocks+0x2f6c>
    344c:      	b	0x3470 <_llm_rows.packet_batch.blocks+0x2f74>
    3450:      	tbz	w9, #0x1, 0x3438 <_llm_rows.packet_batch.blocks+0x2f3c>
    3454:      	add	x11, x10, #0x4
    3458:      	st1.s	{ v11 }[1], [x11]
    345c:      	mov.16b	v12, v24
    3460:      	tbnz	w9, #0x2, 0x3440 <_llm_rows.packet_batch.blocks+0x2f44>
    3464:      	tbz	w9, #0x3, 0x3470 <_llm_rows.packet_batch.blocks+0x2f74>
    3468:      	add	x11, x10, #0xc
    346c:      	st1.s	{ v11 }[3], [x11]
    3470:      	fmul.4s	v22, v1, v4
    3474:      	fmul.4s	v23, v6, v21
    3478:      	fsub.4s	v22, v22, v23
    347c:      	zip2.8b	v23, v20, v0
    3480:      	ushll.4s	v23, v23, #0x0
    3484:      	shl.4s	v23, v23, #0x1f
    3488:      	cmlt.4s	v23, v23, #0
    348c:      	and.16b	v11, v23, v22
    3490:      	tbz	w9, #0x4, 0x34b0 <_llm_rows.packet_batch.blocks+0x2fb4>
    3494:      	str	s11, [x10, #0x10]
    3498:      	tbnz	w9, #0x5, 0x34b4 <_llm_rows.packet_batch.blocks+0x2fb8>
    349c:      	tbz	w9, #0x6, 0x34c0 <_llm_rows.packet_batch.blocks+0x2fc4>
    34a0:      	add	x11, x10, #0x18
    34a4:      	st1.s	{ v11 }[2], [x11]
    34a8:      	tbnz	w9, #0x7, 0x34c4 <_llm_rows.packet_batch.blocks+0x2fc8>
    34ac:      	b	0x34cc <_llm_rows.packet_batch.blocks+0x2fd0>
    34b0:      	tbz	w9, #0x5, 0x349c <_llm_rows.packet_batch.blocks+0x2fa0>
    34b4:      	add	x11, x10, #0x14
    34b8:      	st1.s	{ v11 }[1], [x11]
    34bc:      	tbnz	w9, #0x6, 0x34a0 <_llm_rows.packet_batch.blocks+0x2fa4>
    34c0:      	tbz	w9, #0x7, 0x34cc <_llm_rows.packet_batch.blocks+0x2fd0>
    34c4:      	add	x9, x10, #0x1c
    34c8:      	st1.s	{ v11 }[3], [x9]
    34cc:      	mov.16b	v11, v14
    34d0:      	sshll.2d	v22, v11, #0x0
    34d4:      	ldr	q23, [sp, #0x1f0]
    34d8:      	and.16b	v22, v22, v23
    34dc:      	fmov	w10, s0
    34e0:      	ldr	q23, [sp, #0xa0]
    34e4:      	ldr	q24, [sp, #0x60]
    34e8:      	fmul.4s	v23, v23, v24
    34ec:      	ldp	q24, q25, [sp, #0x70]
    34f0:      	fmul.4s	v25, v25, v24
    34f4:      	fadd.4s	v23, v25, v23
    34f8:      	and.16b	v25, v14, v23
    34fc:      	fmov	x9, d22
    3500:      	add	x9, x8, x9, lsl #2
    3504:      	tbz	w10, #0x0, 0x352c <_llm_rows.packet_batch.blocks+0x3030>
    3508:      	str	s25, [x9]
    350c:      	and	w10, w10, #0xff
    3510:      	movi.2s	v11, #0x21
    3514:      	tbnz	w10, #0x1, 0x3538 <_llm_rows.packet_batch.blocks+0x303c>
    3518:      	tbz	w10, #0x2, 0x3544 <_llm_rows.packet_batch.blocks+0x3048>
    351c:      	add	x11, x9, #0x8
    3520:      	st1.s	{ v25 }[2], [x11]
    3524:      	tbnz	w10, #0x3, 0x3548 <_llm_rows.packet_batch.blocks+0x304c>
    3528:      	b	0x3550 <_llm_rows.packet_batch.blocks+0x3054>
    352c:      	and	w10, w10, #0xff
    3530:      	movi.2s	v11, #0x21
    3534:      	tbz	w10, #0x1, 0x3518 <_llm_rows.packet_batch.blocks+0x301c>
    3538:      	add	x11, x9, #0x4
    353c:      	st1.s	{ v25 }[1], [x11]
    3540:      	tbnz	w10, #0x2, 0x351c <_llm_rows.packet_batch.blocks+0x3020>
    3544:      	tbz	w10, #0x3, 0x3550 <_llm_rows.packet_batch.blocks+0x3054>
    3548:      	add	x11, x9, #0xc
    354c:      	st1.s	{ v25 }[3], [x11]
    3550:      	ldr	q22, [sp, #0x150]
    3554:      	ldp	q23, q25, [sp, #0x100]
    3558:      	fmul.4s	v22, v22, v23
    355c:      	ldr	q23, [sp, #0x120]
    3560:      	fmul.4s	v23, v23, v25
    3564:      	fadd.4s	v22, v23, v22
    3568:      	and.16b	v25, v16, v22
    356c:      	tbz	w10, #0x4, 0x358c <_llm_rows.packet_batch.blocks+0x3090>
    3570:      	str	s25, [x9, #0x10]
    3574:      	tbnz	w10, #0x5, 0x3590 <_llm_rows.packet_batch.blocks+0x3094>
    3578:      	tbz	w10, #0x6, 0x359c <_llm_rows.packet_batch.blocks+0x30a0>
    357c:      	add	x11, x9, #0x18
    3580:      	st1.s	{ v25 }[2], [x11]
    3584:      	tbnz	w10, #0x7, 0x35a0 <_llm_rows.packet_batch.blocks+0x30a4>
    3588:      	b	0x35a8 <_llm_rows.packet_batch.blocks+0x30ac>
    358c:      	tbz	w10, #0x5, 0x3578 <_llm_rows.packet_batch.blocks+0x307c>
    3590:      	add	x11, x9, #0x14
    3594:      	st1.s	{ v25 }[1], [x11]
    3598:      	tbnz	w10, #0x6, 0x357c <_llm_rows.packet_batch.blocks+0x3080>
    359c:      	tbz	w10, #0x7, 0x35a8 <_llm_rows.packet_batch.blocks+0x30ac>
    35a0:      	add	x9, x9, #0x1c
    35a4:      	st1.s	{ v25 }[3], [x9]
    35a8:      	mov.16b	v24, v14
    35ac:      	sshll.2d	v22, v24, #0x0
    35b0:      	ldr	q23, [sp, #0x1d0]
    35b4:      	and.16b	v22, v22, v23
    35b8:      	fmov	w10, s0
    35bc:      	ldp	q23, q25, [sp, #0x40]
    35c0:      	fmul.4s	v19, v25, v19
    35c4:      	fmul.4s	v18, v23, v18
    35c8:      	fadd.4s	v18, v18, v19
    35cc:      	and.16b	v18, v14, v18
    35d0:      	fmov	x9, d22
    35d4:      	add	x9, x8, x9, lsl #2
    35d8:      	tbz	w10, #0x0, 0x35fc <_llm_rows.packet_batch.blocks+0x3100>
    35dc:      	str	s18, [x9]
    35e0:      	and	w10, w10, #0xff
    35e4:      	tbnz	w10, #0x1, 0x3604 <_llm_rows.packet_batch.blocks+0x3108>
    35e8:      	tbz	w10, #0x2, 0x3610 <_llm_rows.packet_batch.blocks+0x3114>
    35ec:      	add	x11, x9, #0x8
    35f0:      	st1.s	{ v18 }[2], [x11]
    35f4:      	tbnz	w10, #0x3, 0x3614 <_llm_rows.packet_batch.blocks+0x3118>
    35f8:      	b	0x361c <_llm_rows.packet_batch.blocks+0x3120>
    35fc:      	and	w10, w10, #0xff
    3600:      	tbz	w10, #0x1, 0x35e8 <_llm_rows.packet_batch.blocks+0x30ec>
    3604:      	add	x11, x9, #0x4
    3608:      	st1.s	{ v18 }[1], [x11]
    360c:      	tbnz	w10, #0x2, 0x35ec <_llm_rows.packet_batch.blocks+0x30f0>
    3610:      	tbz	w10, #0x3, 0x361c <_llm_rows.packet_batch.blocks+0x3120>
    3614:      	add	x11, x9, #0xc
    3618:      	st1.s	{ v18 }[3], [x11]
    361c:      	ldp	q22, q18, [sp, #0xe0]
    3620:      	ldr	q19, [sp, #0xd0]
    3624:      	fmul.4s	v18, v18, v19
    3628:      	ldr	q19, [sp, #0x220]
    362c:      	fmul.4s	v19, v19, v22
    3630:      	fadd.4s	v18, v19, v18
    3634:      	and.16b	v18, v16, v18
    3638:      	tbz	w10, #0x4, 0x3658 <_llm_rows.packet_batch.blocks+0x315c>
    363c:      	str	s18, [x9, #0x10]
    3640:      	tbnz	w10, #0x5, 0x365c <_llm_rows.packet_batch.blocks+0x3160>
    3644:      	tbz	w10, #0x6, 0x3668 <_llm_rows.packet_batch.blocks+0x316c>
    3648:      	add	x11, x9, #0x18
    364c:      	st1.s	{ v18 }[2], [x11]
    3650:      	tbnz	w10, #0x7, 0x366c <_llm_rows.packet_batch.blocks+0x3170>
    3654:      	b	0x3674 <_llm_rows.packet_batch.blocks+0x3178>
    3658:      	tbz	w10, #0x5, 0x3644 <_llm_rows.packet_batch.blocks+0x3148>
    365c:      	add	x11, x9, #0x14
    3660:      	st1.s	{ v18 }[1], [x11]
    3664:      	tbnz	w10, #0x6, 0x3648 <_llm_rows.packet_batch.blocks+0x314c>
    3668:      	tbz	w10, #0x7, 0x3674 <_llm_rows.packet_batch.blocks+0x3178>
    366c:      	add	x9, x9, #0x1c
    3670:      	st1.s	{ v18 }[3], [x9]
    3674:      	mov.16b	v22, v14
    3678:      	sshll.2d	v18, v22, #0x0
    367c:      	ldr	q19, [sp, #0x1c0]
    3680:      	and.16b	v18, v18, v19
    3684:      	fmov	w10, s0
    3688:      	fmul.4s	v2, v2, v5
    368c:      	ldr	q5, [sp, #0x30]
    3690:      	fmul.4s	v3, v5, v3
    3694:      	fadd.4s	v2, v3, v2
    3698:      	and.16b	v2, v14, v2
    369c:      	fmov	x9, d18
    36a0:      	add	x9, x8, x9, lsl #2
    36a4:      	tbz	w10, #0x0, 0x36cc <_llm_rows.packet_batch.blocks+0x31d0>
    36a8:      	str	s2, [x9]
    36ac:      	and	w10, w10, #0xff
    36b0:      	ldr	d18, [sp, #0x280]
    36b4:      	tbnz	w10, #0x1, 0x36d8 <_llm_rows.packet_batch.blocks+0x31dc>
    36b8:      	tbz	w10, #0x2, 0x36e4 <_llm_rows.packet_batch.blocks+0x31e8>
    36bc:      	add	x11, x9, #0x8
    36c0:      	st1.s	{ v2 }[2], [x11]
    36c4:      	tbnz	w10, #0x3, 0x36e8 <_llm_rows.packet_batch.blocks+0x31ec>
    36c8:      	b	0x36f0 <_llm_rows.packet_batch.blocks+0x31f4>
    36cc:      	and	w10, w10, #0xff
    36d0:      	ldr	d18, [sp, #0x280]
    36d4:      	tbz	w10, #0x1, 0x36b8 <_llm_rows.packet_batch.blocks+0x31bc>
    36d8:      	add	x11, x9, #0x4
    36dc:      	st1.s	{ v2 }[1], [x11]
    36e0:      	tbnz	w10, #0x2, 0x36bc <_llm_rows.packet_batch.blocks+0x31c0>
    36e4:      	tbz	w10, #0x3, 0x36f0 <_llm_rows.packet_batch.blocks+0x31f4>
    36e8:      	add	x11, x9, #0xc
    36ec:      	st1.s	{ v2 }[3], [x11]
    36f0:      	ldp	q3, q2, [sp, #0xb0]
    36f4:      	fmul.4s	v2, v2, v12
    36f8:      	ldr	q5, [sp, #0x90]
    36fc:      	fmul.4s	v3, v3, v5
    3700:      	fadd.4s	v2, v3, v2
    3704:      	and.16b	v2, v16, v2
    3708:      	tbz	w10, #0x4, 0x3728 <_llm_rows.packet_batch.blocks+0x322c>
    370c:      	str	s2, [x9, #0x10]
    3710:      	tbnz	w10, #0x5, 0x372c <_llm_rows.packet_batch.blocks+0x3230>
    3714:      	tbz	w10, #0x6, 0x3738 <_llm_rows.packet_batch.blocks+0x323c>
    3718:      	add	x11, x9, #0x18
    371c:      	st1.s	{ v2 }[2], [x11]
    3720:      	tbnz	w10, #0x7, 0x373c <_llm_rows.packet_batch.blocks+0x3240>
    3724:      	b	0x3744 <_llm_rows.packet_batch.blocks+0x3248>
    3728:      	tbz	w10, #0x5, 0x3714 <_llm_rows.packet_batch.blocks+0x3218>
    372c:      	add	x11, x9, #0x14
    3730:      	st1.s	{ v2 }[1], [x11]
    3734:      	tbnz	w10, #0x6, 0x3718 <_llm_rows.packet_batch.blocks+0x321c>
    3738:      	tbz	w10, #0x7, 0x3744 <_llm_rows.packet_batch.blocks+0x3248>
    373c:      	add	x9, x9, #0x1c
    3740:      	st1.s	{ v2 }[3], [x9]
    3744:      	sshll.2d	v2, v14, #0x0
    3748:      	ldr	q3, [sp, #0x1b0]
    374c:      	and.16b	v2, v2, v3
    3750:      	fmov	w10, s0
    3754:      	fmul.4s	v3, v7, v31
    3758:      	fmul.4s	v5, v29, v30
    375c:      	fadd.4s	v3, v5, v3
    3760:      	and.16b	v0, v14, v3
    3764:      	fmov	x9, d2
    3768:      	add	x9, x8, x9, lsl #2
    376c:      	tbz	w10, #0x0, 0x37bc <_llm_rows.packet_batch.blocks+0x32c0>
    3770:      	str	s0, [x9]
    3774:      	and	w10, w10, #0xff
    3778:      	tbnz	w10, #0x1, 0x37c4 <_llm_rows.packet_batch.blocks+0x32c8>
    377c:      	tbz	w10, #0x2, 0x37d0 <_llm_rows.packet_batch.blocks+0x32d4>
    3780:      	add	x11, x9, #0x8
    3784:      	st1.s	{ v0 }[2], [x11]
    3788:      	tbnz	w10, #0x3, 0x37d4 <_llm_rows.packet_batch.blocks+0x32d8>
    378c:      	fmul.4s	v0, v26, v17
    3790:      	fmul.4s	v2, v28, v27
    3794:      	fadd.4s	v0, v2, v0
    3798:      	and.16b	v0, v16, v0
    379c:      	tbz	w10, #0x4, 0x37f0 <_llm_rows.packet_batch.blocks+0x32f4>
    37a0:      	str	s0, [x9, #0x10]
    37a4:      	tbnz	w10, #0x5, 0x37f4 <_llm_rows.packet_batch.blocks+0x32f8>
    37a8:      	tbz	w10, #0x6, 0x3800 <_llm_rows.packet_batch.blocks+0x3304>
    37ac:      	add	x11, x9, #0x18
    37b0:      	st1.s	{ v0 }[2], [x11]
    37b4:      	tbnz	w10, #0x7, 0x3804 <_llm_rows.packet_batch.blocks+0x3308>
    37b8:      	b	0x380c <_llm_rows.packet_batch.blocks+0x3310>
    37bc:      	and	w10, w10, #0xff
    37c0:      	tbz	w10, #0x1, 0x377c <_llm_rows.packet_batch.blocks+0x3280>
    37c4:      	add	x11, x9, #0x4
    37c8:      	st1.s	{ v0 }[1], [x11]
    37cc:      	tbnz	w10, #0x2, 0x3780 <_llm_rows.packet_batch.blocks+0x3284>
    37d0:      	tbz	w10, #0x3, 0x378c <_llm_rows.packet_batch.blocks+0x3290>
    37d4:      	add	x11, x9, #0xc
    37d8:      	st1.s	{ v0 }[3], [x11]
    37dc:      	fmul.4s	v0, v26, v17
    37e0:      	fmul.4s	v2, v28, v27
    37e4:      	fadd.4s	v0, v2, v0
    37e8:      	and.16b	v0, v16, v0
    37ec:      	tbnz	w10, #0x4, 0x37a0 <_llm_rows.packet_batch.blocks+0x32a4>
    37f0:      	tbz	w10, #0x5, 0x37a8 <_llm_rows.packet_batch.blocks+0x32ac>
    37f4:      	add	x11, x9, #0x14
    37f8:      	st1.s	{ v0 }[1], [x11]
    37fc:      	tbnz	w10, #0x6, 0x37ac <_llm_rows.packet_batch.blocks+0x32b0>
    3800:      	tbz	w10, #0x7, 0x380c <_llm_rows.packet_batch.blocks+0x3310>
    3804:      	add	x9, x9, #0x1c
    3808:      	st1.s	{ v0 }[3], [x9]
    380c:      	fmul.4s	v0, v8, v15
    3810:      	fmul.4s	v2, v9, v10
    3814:      	fadd.4s	v0, v2, v0
    3818:      	zip1.8b	v2, v20, v0
    381c:      	ushll.4s	v2, v2, #0x0
    3820:      	shl.4s	v2, v2, #0x1f
    3824:      	cmlt.4s	v2, v2, #0
    3828:      	and.16b	v0, v2, v0
    382c:      	fmov	w9, s18
    3830:      	ldp	q3, q2, [sp, #0x170]
    3834:      	str	q3, [sp, #0x420]
    3838:      	str	q2, [sp, #0x430]
    383c:      	ldp	q3, q2, [sp, #0x190]
    3840:      	str	q3, [sp, #0x440]
    3844:      	str	q2, [sp, #0x450]
    3848:      	and	x10, x12, #0x7
    384c:      	add	x11, sp, #0x420
    3850:      	ldr	x10, [x11, x10, lsl #3]
    3854:      	sub	x10, x10, x12
    3858:      	add	x8, x8, x10, lsl #2
    385c:      	tbz	w9, #0x0, 0x3880 <_llm_rows.packet_batch.blocks+0x3384>
    3860:      	str	s0, [x8]
    3864:      	movi.2s	v10, #0x42
    3868:      	tbnz	w9, #0x1, 0x3888 <_llm_rows.packet_batch.blocks+0x338c>
    386c:      	tbz	w9, #0x2, 0x3894 <_llm_rows.packet_batch.blocks+0x3398>
    3870:      	add	x10, x8, #0x8
    3874:      	st1.s	{ v0 }[2], [x10]
    3878:      	tbnz	w9, #0x3, 0x3898 <_llm_rows.packet_batch.blocks+0x339c>
    387c:      	b	0x38a0 <_llm_rows.packet_batch.blocks+0x33a4>
    3880:      	movi.2s	v10, #0x42
    3884:      	tbz	w9, #0x1, 0x386c <_llm_rows.packet_batch.blocks+0x3370>
    3888:      	add	x10, x8, #0x4
    388c:      	st1.s	{ v0 }[1], [x10]
    3890:      	tbnz	w9, #0x2, 0x3870 <_llm_rows.packet_batch.blocks+0x3374>
    3894:      	tbz	w9, #0x3, 0x38a0 <_llm_rows.packet_batch.blocks+0x33a4>
    3898:      	add	x10, x8, #0xc
    389c:      	st1.s	{ v0 }[3], [x10]
    38a0:      	fmul.4s	v0, v1, v21
    38a4:      	fmul.4s	v1, v4, v6
    38a8:      	fadd.4s	v0, v1, v0
    38ac:      	zip2.8b	v1, v20, v0
    38b0:      	ushll.4s	v1, v1, #0x0
    38b4:      	shl.4s	v1, v1, #0x1f
    38b8:      	cmlt.4s	v1, v1, #0
    38bc:      	and.16b	v0, v1, v0
    38c0:      	tbnz	w9, #0x4, 0x1d94 <_llm_rows.packet_batch.blocks+0x1898>
    38c4:      	tbz	w9, #0x5, 0x1d9c <_llm_rows.packet_batch.blocks+0x18a0>
    38c8:      	add	x10, x8, #0x14
    38cc:      	st1.s	{ v0 }[1], [x10]
    38d0:      	tbnz	w9, #0x6, 0x1da0 <_llm_rows.packet_batch.blocks+0x18a4>
    38d4:      	tbz	w9, #0x7, 0x38e0 <_llm_rows.packet_batch.blocks+0x33e4>
    38d8:      	add	x8, x8, #0x1c
    38dc:      	st1.s	{ v0 }[3], [x8]
    38e0:      	mov	w8, #0x18               ; =24
    38e4:      	str	w8, [x20, #0x24]
    38e8:      	ldr	w22, [sp, #0x2bc]
    38ec:      	b	0x608 <_llm_rows.packet_batch.blocks+0x10c>
    38f0:      	add	sp, sp, #0x8c0
    38f4:      	ldp	x29, x30, [sp, #0x90]
    38f8:      	ldp	x20, x19, [sp, #0x80]
    38fc:      	ldp	x22, x21, [sp, #0x70]
    3900:      	ldp	x24, x23, [sp, #0x60]
    3904:      	ldp	x26, x25, [sp, #0x50]
    3908:      	ldp	x28, x27, [sp, #0x40]
    390c:      	ldp	d9, d8, [sp, #0x30]
    3910:      	ldp	d11, d10, [sp, #0x20]
    3914:      	ldp	d13, d12, [sp, #0x10]
    3918:      	ldp	d15, d14, [sp], #0xa0
    391c:      	ret

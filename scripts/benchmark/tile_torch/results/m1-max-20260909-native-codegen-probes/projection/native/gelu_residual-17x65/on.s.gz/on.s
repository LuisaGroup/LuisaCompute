
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/gelu_residual-17x65/on/object/tile_xir_w8_38033_1788936543941205_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x50]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	sub	sp, sp, #0x370
      18:      	ldr	x12, [x0]
      1c:      	ldr	x10, [x0, #0x10]
      20:      	ldr	x8, [x0, #0x30]
      24:      	ldr	w9, [x1]
      28:      	ldr	w11, [x1, #0x24]
      2c:      	add	w9, w11, w9, lsl #5
      30:      	lsr	w9, w9, #3
      34:      	subs	x11, x12, x8
      38:      	lsr	x11, x11, #2
      3c:      	mov	w13, #0x450             ; =1104
      40:      	ccmp	x11, x13, #0x0, hs
      44:      	cset	w11, hi
      48:      	subs	x14, x8, x12
      4c:      	lsr	x14, x14, #2
      50:      	ccmp	x14, x13, #0x0, hs
      54:      	csinc	w14, w11, wzr, ls
      58:      	subs	x11, x10, x8
      5c:      	lsr	x11, x11, #2
      60:      	ccmp	x11, x13, #0x0, hs
      64:      	cset	w11, hi
      68:      	subs	x15, x8, x10
      6c:      	lsr	x15, x15, #2
      70:      	ccmp	x15, x13, #0x0, hs
      74:      	csinc	w13, w11, wzr, ls
      78:      	mov	w11, #0x104             ; =260
      7c:      	umull	x11, w9, w11
      80:      	cmp	w14, #0x1
      84:      	ccmp	w13, #0x0, #0x4, eq
      88:      	b.ne	0x810 <ltmp0+0x810>
      8c:      	mov	x13, #0x0               ; =0
      90:      	add	x9, x12, x11
      94:      	ldp	q0, q1, [x9, #0xc0]
      98:      	stp	q0, q1, [sp, #0x310]
      9c:      	ldp	q0, q1, [x9, #0xe0]
      a0:      	stp	q0, q1, [sp, #0x330]
      a4:      	ldp	q0, q1, [x9, #0x80]
      a8:      	stp	q0, q1, [sp, #0x2d0]
      ac:      	ldp	q0, q1, [x9, #0xa0]
      b0:      	stp	q0, q1, [sp, #0x2f0]
      b4:      	ldp	q0, q1, [x9, #0x40]
      b8:      	stp	q0, q1, [sp, #0x290]
      bc:      	ldp	q0, q1, [x9, #0x60]
      c0:      	stp	q0, q1, [sp, #0x2b0]
      c4:      	ldp	q0, q1, [x9]
      c8:      	stp	q0, q1, [sp, #0x250]
      cc:      	ldp	q0, q1, [x9, #0x20]
      d0:      	stp	q0, q1, [sp, #0x270]
      d4:      	add	x9, x11, #0x100
      d8:      	ldr	s0, [x12, x9]
      dc:      	str	q0, [sp, #0x10]
      e0:      	str	q0, [sp, #0x350]
      e4:      	add	x12, x10, x11
      e8:      	ldp	q0, q1, [x12, #0xc0]
      ec:      	stp	q0, q1, [sp, #0x1f0]
      f0:      	ldp	q0, q1, [x12, #0xe0]
      f4:      	stp	q0, q1, [sp, #0x210]
      f8:      	ldp	q0, q1, [x12, #0x80]
      fc:      	stp	q0, q1, [sp, #0x1b0]
     100:      	ldp	q0, q1, [x12, #0xa0]
     104:      	stp	q0, q1, [sp, #0x1d0]
     108:      	ldp	q0, q1, [x12, #0x40]
     10c:      	stp	q0, q1, [sp, #0x170]
     110:      	ldp	q0, q1, [x12, #0x60]
     114:      	stp	q0, q1, [sp, #0x190]
     118:      	ldp	q3, q4, [x12]
     11c:      	ldp	q0, q1, [x12, #0x20]
     120:      	ldr	s2, [x10, x9]
     124:      	add	x10, x8, x11
     128:      	add	x11, sp, #0x250
     12c:      	mov	w12, #0x2713            ; =10003
     130:      	movk	w12, #0x3d37, lsl #16
     134:      	dup.4s	v6, w12
     138:      	mov	w12, #0x422a            ; =16938
     13c:      	movk	w12, #0x3f4c, lsl #16
     140:      	dup.4s	v5, w12
     144:      	stp	q5, q6, [sp, #0x100]
     148:      	fmov.4s	v19, #1.00000000
     14c:      	mov	w12, #0x9231            ; =37425
     150:      	movk	w12, #0x2f30, lsl #16
     154:      	dup.4s	v6, w12
     158:      	mov	w12, #0x322b            ; =12843
     15c:      	movk	w12, #0x32d7, lsl #16
     160:      	dup.4s	v5, w12
     164:      	stp	q5, q6, [sp, #0xe0]
     168:      	mov	w12, #0xef1d            ; =61213
     16c:      	movk	w12, #0x3638, lsl #16
     170:      	dup.4s	v6, w12
     174:      	mov	w12, #0xd01             ; =3329
     178:      	movk	w12, #0x3950, lsl #16
     17c:      	dup.4s	v5, w12
     180:      	stp	q5, q6, [sp, #0xc0]
     184:      	mov	w12, #0x8889            ; =34953
     188:      	movk	w12, #0x3c08, lsl #16
     18c:      	dup.4s	v6, w12
     190:      	mov	w12, #0xaaab            ; =43691
     194:      	movk	w12, #0x3e2a, lsl #16
     198:      	dup.4s	v22, w12
     19c:      	mov	w12, #0x76c7            ; =30407
     1a0:      	movk	w12, #0x310f, lsl #16
     1a4:      	dup.4s	v5, w12
     1a8:      	stp	q5, q6, [sp, #0xa0]
     1ac:      	mov	w12, #0xf27e            ; =62078
     1b0:      	movk	w12, #0x3493, lsl #16
     1b4:      	dup.4s	v6, w12
     1b8:      	mov	w12, #0xd01             ; =3329
     1bc:      	movk	w12, #0x37d0, lsl #16
     1c0:      	dup.4s	v5, w12
     1c4:      	stp	q5, q6, [sp, #0x80]
     1c8:      	mov	w12, #0xb61             ; =2913
     1cc:      	movk	w12, #0x3ab6, lsl #16
     1d0:      	dup.4s	v6, w12
     1d4:      	mov	w12, #0xaaab            ; =43691
     1d8:      	movk	w12, #0x3d2a, lsl #16
     1dc:      	dup.4s	v5, w12
     1e0:      	stp	q5, q6, [sp, #0x60]
     1e4:      	mov	w12, #-0x3d300000       ; =-1026555904
     1e8:      	dup.4s	v6, w12
     1ec:      	mov	w12, #0x42c80000        ; =1120403456
     1f0:      	dup.4s	v27, w12
     1f4:      	fmov.4s	v5, #9.00000000
     1f8:      	str	q5, [sp, #0x120]
     1fc:      	mov	w12, #0xaa3b            ; =43579
     200:      	movk	w12, #0x3fb8, lsl #16
     204:      	dup.4s	v5, w12
     208:      	stp	q5, q6, [sp, #0x40]
     20c:      	mov	w12, #0x7200            ; =29184
     210:      	movk	w12, #0xbf31, lsl #16
     214:      	dup.4s	v5, w12
     218:      	str	q5, [sp, #0x30]
     21c:      	mov	w12, #0xbe8e            ; =48782
     220:      	movk	w12, #0xb5bf, lsl #16
     224:      	dup.4s	v8, w12
     228:      	mov	w12, #0x2bda            ; =11226
     22c:      	movk	w12, #0x3950, lsl #16
     230:      	dup.4s	v9, w12
     234:      	mov	w12, #0x96c9            ; =38601
     238:      	movk	w12, #0x3ab6, lsl #16
     23c:      	dup.4s	v10, w12
     240:      	mov	w12, #0x88a6            ; =34982
     244:      	movk	w12, #0x3c08, lsl #16
     248:      	dup.4s	v11, w12
     24c:      	mov	w12, #0xaa7a            ; =43642
     250:      	movk	w12, #0x3d2a, lsl #16
     254:      	stp	q3, q4, [sp, #0x130]
     258:      	mvni.4s	v3, #0x7f, msl #16
     25c:      	fneg.4s	v13, v3
     260:      	stp	q0, q1, [sp, #0x150]
     264:      	mvni.4s	v0, #0x3f, msl #16
     268:      	dup.4s	v14, w12
     26c:      	fneg.4s	v15, v0
     270:      	add	x12, sp, #0x130
     274:      	str	q2, [sp, #0x20]
     278:      	str	q2, [sp, #0x230]
     27c:      	add	x14, x11, x13
     280:      	ldp	q29, q30, [x14]
     284:      	ldp	q2, q1, [sp, #0x100]
     288:      	fmul.4s	v0, v29, v1
     28c:      	fmul.4s	v1, v30, v1
     290:      	fmul.4s	v1, v30, v1
     294:      	fmul.4s	v0, v29, v0
     298:      	fmul.4s	v0, v29, v0
     29c:      	fmul.4s	v1, v30, v1
     2a0:      	fadd.4s	v1, v30, v1
     2a4:      	fadd.4s	v0, v29, v0
     2a8:      	fmul.4s	v0, v0, v2
     2ac:      	fmul.4s	v12, v1, v2
     2b0:      	fabs.4s	v4, v12
     2b4:      	fabs.4s	v3, v0
     2b8:      	fmul.4s	v18, v0, v0
     2bc:      	ldp	q5, q2, [sp, #0xe0]
     2c0:      	mov.16b	v1, v5
     2c4:      	fmul.4s	v21, v12, v12
     2c8:      	fmla.4s	v1, v18, v2
     2cc:      	fmla.4s	v5, v21, v2
     2d0:      	ldr	q7, [sp, #0xd0]
     2d4:      	mov.16b	v6, v7
     2d8:      	fmla.4s	v6, v18, v1
     2dc:      	fmla.4s	v7, v21, v5
     2e0:      	ldr	q1, [sp, #0xc0]
     2e4:      	mov.16b	v5, v1
     2e8:      	fmla.4s	v5, v18, v6
     2ec:      	mov.16b	v6, v1
     2f0:      	ldp	q2, q1, [sp, #0xa0]
     2f4:      	mov.16b	v16, v1
     2f8:      	fmla.4s	v6, v21, v7
     2fc:      	mov.16b	v7, v1
     300:      	mov.16b	v20, v22
     304:      	mov.16b	v17, v22
     308:      	mov.16b	v1, v19
     30c:      	mov.16b	v26, v19
     310:      	fmla.4s	v16, v18, v5
     314:      	ldr	q23, [sp, #0x90]
     318:      	mov.16b	v5, v23
     31c:      	fmla.4s	v5, v21, v2
     320:      	fmla.4s	v23, v18, v2
     324:      	ldr	q2, [sp, #0x80]
     328:      	mov.16b	v24, v2
     32c:      	fmla.4s	v7, v21, v6
     330:      	fmla.4s	v24, v21, v5
     334:      	mov.16b	v5, v2
     338:      	fmla.4s	v5, v18, v23
     33c:      	ldp	q23, q2, [sp, #0x60]
     340:      	mov.16b	v6, v2
     344:      	fmla.4s	v6, v21, v24
     348:      	fmla.4s	v20, v18, v16
     34c:      	mov.16b	v16, v2
     350:      	fmla.4s	v16, v18, v5
     354:      	mov.16b	v5, v23
     358:      	fmla.4s	v5, v21, v6
     35c:      	fmla.4s	v17, v21, v7
     360:      	fmla.4s	v23, v18, v16
     364:      	movi.4s	v24, #0x3f, lsl #24
     368:      	fmla.4s	v24, v21, v5
     36c:      	movi.4s	v25, #0x3f, lsl #24
     370:      	mov.16b	v7, v19
     374:      	fmla.4s	v26, v21, v17
     378:      	mov.16b	v2, v19
     37c:      	ldr	q6, [sp, #0x120]
     380:      	fcmge.4s	v5, v6, v3
     384:      	fcmge.4s	v6, v6, v4
     388:      	and.16b	v16, v6, v4
     38c:      	and.16b	v17, v5, v3
     390:      	fmla.4s	v7, v21, v24
     394:      	ldr	q24, [sp, #0x50]
     398:      	fcmge.4s	v21, v17, v24
     39c:      	fcmge.4s	v24, v16, v24
     3a0:      	fcmge.4s	v28, v27, v16
     3a4:      	and.16b	v24, v24, v28
     3a8:      	fcmge.4s	v28, v27, v17
     3ac:      	fmla.4s	v25, v18, v23
     3b0:      	and.16b	v21, v21, v28
     3b4:      	and.16b	v21, v21, v17
     3b8:      	and.16b	v23, v24, v16
     3bc:      	ldr	q28, [sp, #0x40]
     3c0:      	fmul.4s	v24, v23, v28
     3c4:      	fmul.4s	v28, v21, v28
     3c8:      	fmla.4s	v1, v18, v20
     3cc:      	movi.4s	v31, #0x4b, lsl #24
     3d0:      	fadd.4s	v20, v28, v31
     3d4:      	fadd.4s	v24, v24, v31
     3d8:      	movi.4s	v28, #0xcb, lsl #24
     3dc:      	fadd.4s	v24, v24, v28
     3e0:      	fadd.4s	v20, v20, v28
     3e4:      	fcvtzs.4s	v20, v20
     3e8:      	fmla.4s	v2, v18, v25
     3ec:      	fcvtzs.4s	v24, v24
     3f0:      	scvtf.4s	v18, v24
     3f4:      	scvtf.4s	v25, v20
     3f8:      	ldr	q31, [sp, #0x30]
     3fc:      	fmul.4s	v28, v18, v31
     400:      	fadd.4s	v23, v23, v28
     404:      	fmul.4s	v28, v25, v31
     408:      	fadd.4s	v21, v21, v28
     40c:      	fmul.4s	v18, v18, v8
     410:      	fmul.4s	v25, v25, v8
     414:      	fadd.4s	v21, v21, v25
     418:      	fadd.4s	v23, v23, v18
     41c:      	fmul.4s	v18, v23, v9
     420:      	fmul.4s	v25, v21, v9
     424:      	fadd.4s	v25, v25, v10
     428:      	fadd.4s	v18, v18, v10
     42c:      	fmul.4s	v18, v23, v18
     430:      	fmul.4s	v25, v21, v25
     434:      	fmul.4s	v1, v3, v1
     438:      	fadd.4s	v25, v25, v11
     43c:      	fadd.4s	v18, v18, v11
     440:      	fmul.4s	v28, v23, v18
     444:      	fmul.4s	v18, v21, v25
     448:      	fadd.4s	v25, v18, v14
     44c:      	fdiv.4s	v18, v1, v2
     450:      	fadd.4s	v1, v28, v14
     454:      	fmul.4s	v1, v23, v1
     458:      	fmul.4s	v2, v21, v25
     45c:      	fadd.4s	v2, v2, v22
     460:      	fadd.4s	v1, v1, v22
     464:      	fmul.4s	v1, v23, v1
     468:      	fmul.4s	v2, v21, v2
     46c:      	movi.4s	v28, #0x3f, lsl #24
     470:      	fadd.4s	v2, v2, v28
     474:      	fadd.4s	v1, v1, v28
     478:      	fmul.4s	v25, v23, v23
     47c:      	fmul.4s	v1, v25, v1
     480:      	fmul.4s	v25, v21, v21
     484:      	fmul.4s	v2, v25, v2
     488:      	fadd.4s	v2, v21, v2
     48c:      	fadd.4s	v1, v23, v1
     490:      	fadd.4s	v1, v1, v19
     494:      	movi.2d	v21, #0xffffffffffffffff
     498:      	add.4s	v20, v20, v21
     49c:      	fadd.4s	v2, v2, v19
     4a0:      	add.4s	v21, v24, v21
     4a4:      	sshr.4s	v23, v21, #0x1
     4a8:      	sshr.4s	v24, v20, #0x1
     4ac:      	shl.4s	v25, v24, #0x17
     4b0:      	add.4s	v25, v25, v19
     4b4:      	fmul.4s	v2, v2, v25
     4b8:      	shl.4s	v25, v23, #0x17
     4bc:      	add.4s	v25, v25, v19
     4c0:      	fmul.4s	v1, v1, v25
     4c4:      	sub.4s	v20, v20, v24
     4c8:      	sub.4s	v21, v21, v23
     4cc:      	shl.4s	v21, v21, #0x17
     4d0:      	add.4s	v21, v21, v19
     4d4:      	fmul.4s	v1, v1, v21
     4d8:      	shl.4s	v20, v20, #0x17
     4dc:      	add.4s	v20, v20, v19
     4e0:      	fmul.4s	v2, v2, v20
     4e4:      	fmul.4s	v20, v4, v26
     4e8:      	fcmgt.4s	v16, v16, v27
     4ec:      	fcmgt.4s	v17, v17, v27
     4f0:      	bit.16b	v2, v13, v17
     4f4:      	bsl.16b	v16, v13, v1
     4f8:      	fmov.4s	v1, #0.25000000
     4fc:      	fdiv.4s	v7, v20, v7
     500:      	fdiv.4s	v17, v1, v16
     504:      	fsub.4s	v20, v16, v17
     508:      	fadd.4s	v16, v16, v17
     50c:      	fdiv.4s	v16, v20, v16
     510:      	bsl.16b	v6, v16, v19
     514:      	fcmge.4s	v4, v19, v4
     518:      	bsl.16b	v4, v7, v6
     51c:      	fdiv.4s	v6, v1, v2
     520:      	fsub.4s	v7, v2, v6
     524:      	fadd.4s	v2, v2, v6
     528:      	fdiv.4s	v2, v7, v2
     52c:      	bif.16b	v2, v19, v5
     530:      	fcmge.4s	v3, v19, v3
     534:      	bit.16b	v2, v18, v3
     538:      	mvni.4s	v3, #0x80, lsl #24
     53c:      	bif.16b	v2, v0, v3
     540:      	fcmeq.4s	v0, v0, v0
     544:      	fadd.4s	v2, v2, v19
     548:      	bsl.16b	v0, v2, v15
     54c:      	mov.16b	v2, v3
     550:      	bsl.16b	v2, v4, v12
     554:      	fcmeq.4s	v3, v12, v12
     558:      	fadd.4s	v2, v2, v19
     55c:      	bif.16b	v2, v15, v3
     560:      	fmul.4s	v3, v30, v28
     564:      	fmul.4s	v2, v3, v2
     568:      	fmul.4s	v3, v29, v28
     56c:      	fmul.4s	v0, v3, v0
     570:      	add	x14, x12, x13
     574:      	ldp	q4, q3, [x14]
     578:      	fadd.4s	v0, v4, v0
     57c:      	fadd.4s	v2, v3, v2
     580:      	add	x14, x10, x13
     584:      	stp	q0, q2, [x14]
     588:      	add	x13, x13, #0x20
     58c:      	cmp	x13, #0x100
     590:      	b.ne	0x27c <ltmp0+0x27c>
     594:      	movi.2d	v3, #0000000000000000
     598:      	ldr	q4, [sp, #0x10]
     59c:      	mov.s	v3[0], v4[0]
     5a0:      	movi.2d	v0, #0000000000000000
     5a4:      	mov	w10, #0x2713            ; =10003
     5a8:      	movk	w10, #0x3d37, lsl #16
     5ac:      	fmov	s2, w10
     5b0:      	fmul.4s	v2, v3, v2
     5b4:      	fmul.4s	v2, v4, v2
     5b8:      	fmul.4s	v2, v4, v2
     5bc:      	fadd.4s	v2, v4, v2
     5c0:      	mov	w10, #0x422a            ; =16938
     5c4:      	movk	w10, #0x3f4c, lsl #16
     5c8:      	fmov	s4, w10
     5cc:      	fmul.4s	v2, v2, v4
     5d0:      	mov.s	v0[0], v2[0]
     5d4:      	fabs.4s	v4, v0
     5d8:      	fmul.4s	v5, v0, v0
     5dc:      	mov	w10, #0x9231            ; =37425
     5e0:      	movk	w10, #0x2f30, lsl #16
     5e4:      	dup.4s	v2, w10
     5e8:      	mov	w10, #0x322b            ; =12843
     5ec:      	movk	w10, #0x32d7, lsl #16
     5f0:      	dup.4s	v6, w10
     5f4:      	mov	w10, #0xef1d            ; =61213
     5f8:      	movk	w10, #0x3638, lsl #16
     5fc:      	dup.4s	v7, w10
     600:      	fmla.4s	v6, v5, v2
     604:      	fmla.4s	v7, v5, v6
     608:      	mov	w10, #0xd01             ; =3329
     60c:      	movk	w10, #0x3950, lsl #16
     610:      	dup.4s	v2, w10
     614:      	fmla.4s	v2, v5, v7
     618:      	mov	w10, #0x8889            ; =34953
     61c:      	movk	w10, #0x3c08, lsl #16
     620:      	dup.4s	v17, w10
     624:      	mov	w10, #0xaaab            ; =43691
     628:      	movk	w10, #0x3e2a, lsl #16
     62c:      	dup.4s	v18, w10
     630:      	fmla.4s	v17, v5, v2
     634:      	ldr	q2, [sp, #0x120]
     638:      	fcmge.4s	v6, v2, v4
     63c:      	and.16b	v7, v6, v4
     640:      	mov	w10, #-0x3d300000       ; =-1026555904
     644:      	dup.4s	v2, w10
     648:      	fcmge.4s	v2, v7, v2
     64c:      	mov	w10, #0x42c80000        ; =1120403456
     650:      	dup.4s	v16, w10
     654:      	fcmge.4s	v20, v16, v7
     658:      	and.16b	v2, v2, v20
     65c:      	and.16b	v2, v2, v7
     660:      	mov	w10, #0xaa3b            ; =43579
     664:      	movk	w10, #0x3fb8, lsl #16
     668:      	dup.4s	v20, w10
     66c:      	fmul.4s	v20, v2, v20
     670:      	movi.4s	v21, #0x4b, lsl #24
     674:      	fadd.4s	v20, v20, v21
     678:      	movi.4s	v21, #0xcb, lsl #24
     67c:      	fadd.4s	v20, v20, v21
     680:      	fcvtzs.4s	v20, v20
     684:      	scvtf.4s	v21, v20
     688:      	mov	w10, #0x7200            ; =29184
     68c:      	movk	w10, #0xbf31, lsl #16
     690:      	dup.4s	v22, w10
     694:      	fmul.4s	v22, v21, v22
     698:      	mov	w10, #0xbe8e            ; =48782
     69c:      	movk	w10, #0xb5bf, lsl #16
     6a0:      	dup.4s	v23, w10
     6a4:      	fadd.4s	v2, v2, v22
     6a8:      	fmul.4s	v21, v21, v23
     6ac:      	fadd.4s	v2, v2, v21
     6b0:      	mov	w10, #0x2bda            ; =11226
     6b4:      	movk	w10, #0x3950, lsl #16
     6b8:      	dup.4s	v21, w10
     6bc:      	fmul.4s	v21, v2, v21
     6c0:      	mov	w10, #0x96c9            ; =38601
     6c4:      	movk	w10, #0x3ab6, lsl #16
     6c8:      	dup.4s	v22, w10
     6cc:      	fadd.4s	v21, v21, v22
     6d0:      	fmul.4s	v21, v2, v21
     6d4:      	mov	w10, #0x88a6            ; =34982
     6d8:      	movk	w10, #0x3c08, lsl #16
     6dc:      	dup.4s	v22, w10
     6e0:      	fadd.4s	v21, v21, v22
     6e4:      	fmul.4s	v21, v2, v21
     6e8:      	mov	w10, #0xaa7a            ; =43642
     6ec:      	movk	w10, #0x3d2a, lsl #16
     6f0:      	dup.4s	v22, w10
     6f4:      	fadd.4s	v21, v21, v22
     6f8:      	fmul.4s	v21, v2, v21
     6fc:      	fadd.4s	v21, v21, v18
     700:      	fmla.4s	v18, v5, v17
     704:      	mov.16b	v17, v19
     708:      	fmla.4s	v17, v5, v18
     70c:      	mov	w10, #0x76c7            ; =30407
     710:      	movk	w10, #0x310f, lsl #16
     714:      	dup.4s	v18, w10
     718:      	mov	w10, #0xf27e            ; =62078
     71c:      	movk	w10, #0x3493, lsl #16
     720:      	dup.4s	v22, w10
     724:      	mov	w10, #0xd01             ; =3329
     728:      	movk	w10, #0x37d0, lsl #16
     72c:      	dup.4s	v23, w10
     730:      	fmla.4s	v22, v5, v18
     734:      	fmla.4s	v23, v5, v22
     738:      	mov	w10, #0xb61             ; =2913
     73c:      	movk	w10, #0x3ab6, lsl #16
     740:      	dup.4s	v18, w10
     744:      	fmla.4s	v18, v5, v23
     748:      	mov	w10, #0xaaab            ; =43691
     74c:      	movk	w10, #0x3d2a, lsl #16
     750:      	dup.4s	v22, w10
     754:      	fmla.4s	v22, v5, v18
     758:      	movi.4s	v18, #0x3f, lsl #24
     75c:      	fmla.4s	v18, v5, v22
     760:      	mov.16b	v22, v19
     764:      	fmla.4s	v22, v5, v18
     768:      	movi.4s	v5, #0x3f, lsl #24
     76c:      	fmul.4s	v3, v3, v5
     770:      	fcmge.4s	v18, v19, v4
     774:      	fmul.4s	v4, v4, v17
     778:      	fdiv.4s	v4, v4, v22
     77c:      	fmul.4s	v17, v2, v21
     780:      	fadd.4s	v5, v17, v5
     784:      	fmul.4s	v17, v2, v2
     788:      	fmul.4s	v5, v17, v5
     78c:      	fadd.4s	v2, v2, v5
     790:      	fadd.4s	v2, v2, v19
     794:      	movi.2d	v5, #0xffffffffffffffff
     798:      	add.4s	v5, v20, v5
     79c:      	sshr.4s	v17, v5, #0x1
     7a0:      	shl.4s	v20, v17, #0x17
     7a4:      	add.4s	v20, v20, v19
     7a8:      	fmul.4s	v2, v2, v20
     7ac:      	sub.4s	v5, v5, v17
     7b0:      	shl.4s	v5, v5, #0x17
     7b4:      	add.4s	v5, v5, v19
     7b8:      	fmul.4s	v2, v2, v5
     7bc:      	fcmgt.4s	v5, v7, v16
     7c0:      	mvni.4s	v7, #0x7f, msl #16
     7c4:      	fneg.4s	v7, v7
     7c8:      	bit.16b	v2, v7, v5
     7cc:      	fdiv.4s	v1, v1, v2
     7d0:      	fsub.4s	v5, v2, v1
     7d4:      	fadd.4s	v1, v2, v1
     7d8:      	fdiv.4s	v1, v5, v1
     7dc:      	bif.16b	v1, v19, v6
     7e0:      	bit.16b	v1, v4, v18
     7e4:      	mvni.4s	v2, #0x80, lsl #24
     7e8:      	bif.16b	v1, v0, v2
     7ec:      	fcmeq.4s	v0, v0, v0
     7f0:      	fadd.4s	v1, v1, v19
     7f4:      	mvni.4s	v2, #0x3f, msl #16
     7f8:      	fneg.4s	v2, v2
     7fc:      	bsl.16b	v0, v1, v2
     800:      	fmul.4s	v0, v3, v0
     804:      	ldr	q1, [sp, #0x20]
     808:      	fadd.4s	v0, v0, v1
     80c:      	b	0xef4 <ltmp0+0xef4>
     810:      	mov	x9, #0x0                ; =0
     814:      	mov	w13, #0x2713            ; =10003
     818:      	movk	w13, #0x3d37, lsl #16
     81c:      	dup.4s	v1, w13
     820:      	mov	w13, #0x422a            ; =16938
     824:      	movk	w13, #0x3f4c, lsl #16
     828:      	dup.4s	v0, w13
     82c:      	stp	q0, q1, [sp, #0xf0]
     830:      	mov	w13, #0x9231            ; =37425
     834:      	movk	w13, #0x2f30, lsl #16
     838:      	dup.4s	v1, w13
     83c:      	mov	w13, #0x322b            ; =12843
     840:      	movk	w13, #0x32d7, lsl #16
     844:      	dup.4s	v0, w13
     848:      	stp	q0, q1, [sp, #0xd0]
     84c:      	mov	w13, #0xef1d            ; =61213
     850:      	movk	w13, #0x3638, lsl #16
     854:      	dup.4s	v1, w13
     858:      	mov	w13, #0xd01             ; =3329
     85c:      	movk	w13, #0x3950, lsl #16
     860:      	dup.4s	v0, w13
     864:      	stp	q0, q1, [sp, #0xb0]
     868:      	mov	w13, #0x8889            ; =34953
     86c:      	movk	w13, #0x3c08, lsl #16
     870:      	dup.4s	v1, w13
     874:      	mov	w13, #0xaaab            ; =43691
     878:      	movk	w13, #0x3e2a, lsl #16
     87c:      	dup.4s	v21, w13
     880:      	mov	w13, #0x76c7            ; =30407
     884:      	movk	w13, #0x310f, lsl #16
     888:      	dup.4s	v0, w13
     88c:      	stp	q0, q1, [sp, #0x90]
     890:      	mov	w13, #0xf27e            ; =62078
     894:      	movk	w13, #0x3493, lsl #16
     898:      	dup.4s	v1, w13
     89c:      	mov	w13, #0xd01             ; =3329
     8a0:      	movk	w13, #0x37d0, lsl #16
     8a4:      	dup.4s	v0, w13
     8a8:      	stp	q0, q1, [sp, #0x70]
     8ac:      	mov	w13, #0xb61             ; =2913
     8b0:      	movk	w13, #0x3ab6, lsl #16
     8b4:      	dup.4s	v1, w13
     8b8:      	mov	w13, #0xaaab            ; =43691
     8bc:      	movk	w13, #0x3d2a, lsl #16
     8c0:      	dup.4s	v0, w13
     8c4:      	stp	q0, q1, [sp, #0x50]
     8c8:      	mov	w13, #-0x3d300000       ; =-1026555904
     8cc:      	dup.4s	v1, w13
     8d0:      	mov	w13, #0x42c80000        ; =1120403456
     8d4:      	dup.4s	v25, w13
     8d8:      	mov	w13, #0xaa3b            ; =43579
     8dc:      	movk	w13, #0x3fb8, lsl #16
     8e0:      	dup.4s	v0, w13
     8e4:      	stp	q0, q1, [sp, #0x30]
     8e8:      	mov	w13, #0x7200            ; =29184
     8ec:      	movk	w13, #0xbf31, lsl #16
     8f0:      	dup.4s	v1, w13
     8f4:      	mov	w13, #0xbe8e            ; =48782
     8f8:      	movk	w13, #0xb5bf, lsl #16
     8fc:      	dup.4s	v0, w13
     900:      	stp	q0, q1, [sp, #0x10]
     904:      	mov	w13, #0x2bda            ; =11226
     908:      	movk	w13, #0x3950, lsl #16
     90c:      	dup.4s	v0, w13
     910:      	str	q0, [sp]
     914:      	mov	w13, #0x96c9            ; =38601
     918:      	movk	w13, #0x3ab6, lsl #16
     91c:      	dup.4s	v30, w13
     920:      	mov	w13, #0x88a6            ; =34982
     924:      	movk	w13, #0x3c08, lsl #16
     928:      	dup.4s	v31, w13
     92c:      	mov	w13, #0xaa7a            ; =43642
     930:      	movk	w13, #0x3d2a, lsl #16
     934:      	dup.4s	v8, w13
     938:      	add	x13, x8, x11
     93c:      	add	x14, x10, x11
     940:      	add	x15, x12, x11
     944:      	movi.4s	v9, #0x3f, lsl #24
     948:      	fmov.4s	v0, #1.00000000
     94c:      	fmov.4s	v2, #9.00000000
     950:      	mvni.4s	v1, #0x7f, msl #16
     954:      	fneg.4s	v13, v1
     958:      	fmov.4s	v1, #0.25000000
     95c:      	stp	q2, q1, [sp, #0x110]
     960:      	mvni.4s	v1, #0x3f, msl #16
     964:      	fneg.4s	v15, v1
     968:      	add	x16, x15, x9
     96c:      	ldp	q10, q11, [x16]
     970:      	ldp	q3, q2, [sp, #0xf0]
     974:      	fmul.4s	v1, v10, v2
     978:      	fmul.4s	v2, v11, v2
     97c:      	fmul.4s	v2, v11, v2
     980:      	fmul.4s	v1, v10, v1
     984:      	fmul.4s	v1, v10, v1
     988:      	fmul.4s	v2, v11, v2
     98c:      	fadd.4s	v2, v11, v2
     990:      	fadd.4s	v1, v10, v1
     994:      	fmul.4s	v14, v1, v3
     998:      	fmul.4s	v12, v2, v3
     99c:      	fabs.4s	v2, v12
     9a0:      	fabs.4s	v1, v14
     9a4:      	fmul.4s	v16, v14, v14
     9a8:      	fmul.4s	v19, v12, v12
     9ac:      	ldp	q4, q5, [sp, #0xd0]
     9b0:      	mov.16b	v3, v4
     9b4:      	fmla.4s	v3, v16, v5
     9b8:      	fmla.4s	v4, v19, v5
     9bc:      	ldr	q6, [sp, #0xc0]
     9c0:      	mov.16b	v5, v6
     9c4:      	fmla.4s	v5, v16, v3
     9c8:      	mov.16b	v3, v6
     9cc:      	fmla.4s	v3, v19, v4
     9d0:      	ldp	q7, q6, [sp, #0xa0]
     9d4:      	mov.16b	v4, v6
     9d8:      	fmla.4s	v4, v16, v5
     9dc:      	mov.16b	v5, v6
     9e0:      	fmla.4s	v5, v19, v3
     9e4:      	mov.16b	v6, v7
     9e8:      	mov.16b	v18, v21
     9ec:      	mov.16b	v20, v21
     9f0:      	mov.16b	v3, v0
     9f4:      	fmla.4s	v6, v16, v4
     9f8:      	ldp	q17, q22, [sp, #0x80]
     9fc:      	mov.16b	v4, v17
     a00:      	fmla.4s	v4, v19, v22
     a04:      	fmla.4s	v17, v16, v22
     a08:      	ldr	q23, [sp, #0x70]
     a0c:      	mov.16b	v22, v23
     a10:      	fmla.4s	v7, v19, v5
     a14:      	fmla.4s	v22, v19, v4
     a18:      	mov.16b	v4, v23
     a1c:      	fmla.4s	v4, v16, v17
     a20:      	ldr	q17, [sp, #0x60]
     a24:      	mov.16b	v5, v17
     a28:      	fmla.4s	v5, v19, v22
     a2c:      	fmla.4s	v18, v16, v6
     a30:      	mov.16b	v6, v17
     a34:      	fmla.4s	v6, v16, v4
     a38:      	ldp	q27, q22, [sp, #0x40]
     a3c:      	mov.16b	v17, v22
     a40:      	fmla.4s	v17, v19, v5
     a44:      	fmla.4s	v20, v19, v7
     a48:      	fmla.4s	v22, v16, v6
     a4c:      	movi.4s	v23, #0x3f, lsl #24
     a50:      	movi.4s	v24, #0x3f, lsl #24
     a54:      	mov.16b	v6, v0
     a58:      	ldr	q5, [sp, #0x110]
     a5c:      	fcmge.4s	v4, v5, v1
     a60:      	fmla.4s	v23, v19, v17
     a64:      	fcmge.4s	v5, v5, v2
     a68:      	and.16b	v7, v5, v2
     a6c:      	and.16b	v17, v4, v1
     a70:      	fcmge.4s	v26, v17, v27
     a74:      	fcmge.4s	v27, v7, v27
     a78:      	fcmge.4s	v28, v25, v7
     a7c:      	and.16b	v27, v27, v28
     a80:      	fcmge.4s	v28, v25, v17
     a84:      	and.16b	v26, v26, v28
     a88:      	and.16b	v26, v26, v17
     a8c:      	and.16b	v27, v27, v7
     a90:      	fmla.4s	v3, v19, v20
     a94:      	ldr	q28, [sp, #0x30]
     a98:      	fmul.4s	v20, v27, v28
     a9c:      	fmul.4s	v28, v26, v28
     aa0:      	movi.4s	v29, #0x4b, lsl #24
     aa4:      	fadd.4s	v28, v28, v29
     aa8:      	fadd.4s	v20, v20, v29
     aac:      	movi.4s	v29, #0xcb, lsl #24
     ab0:      	fadd.4s	v20, v20, v29
     ab4:      	fmla.4s	v6, v19, v23
     ab8:      	fadd.4s	v19, v28, v29
     abc:      	fcvtzs.4s	v19, v19
     ac0:      	fcvtzs.4s	v20, v20
     ac4:      	scvtf.4s	v23, v20
     ac8:      	scvtf.4s	v28, v19
     acc:      	fmla.4s	v24, v16, v22
     ad0:      	ldr	q29, [sp, #0x20]
     ad4:      	fmul.4s	v22, v23, v29
     ad8:      	fadd.4s	v22, v27, v22
     adc:      	fmul.4s	v27, v28, v29
     ae0:      	fadd.4s	v26, v26, v27
     ae4:      	mov.16b	v27, v0
     ae8:      	fmla.4s	v27, v16, v18
     aec:      	ldr	q29, [sp, #0x10]
     af0:      	fmul.4s	v18, v28, v29
     af4:      	fadd.4s	v18, v26, v18
     af8:      	fmul.4s	v23, v23, v29
     afc:      	fadd.4s	v22, v22, v23
     b00:      	mov.16b	v23, v0
     b04:      	fmla.4s	v23, v16, v24
     b08:      	ldr	q24, [sp]
     b0c:      	fmul.4s	v16, v22, v24
     b10:      	fmul.4s	v24, v18, v24
     b14:      	fadd.4s	v24, v24, v30
     b18:      	fadd.4s	v16, v16, v30
     b1c:      	fmul.4s	v16, v22, v16
     b20:      	fmul.4s	v26, v1, v27
     b24:      	fmul.4s	v24, v18, v24
     b28:      	fadd.4s	v24, v24, v31
     b2c:      	fadd.4s	v16, v16, v31
     b30:      	fmul.4s	v16, v22, v16
     b34:      	fmul.4s	v24, v18, v24
     b38:      	fadd.4s	v24, v24, v8
     b3c:      	fadd.4s	v16, v16, v8
     b40:      	fmul.4s	v16, v22, v16
     b44:      	fmul.4s	v24, v18, v24
     b48:      	fadd.4s	v24, v24, v21
     b4c:      	fadd.4s	v27, v16, v21
     b50:      	fdiv.4s	v16, v26, v23
     b54:      	fmul.4s	v23, v22, v27
     b58:      	fmul.4s	v24, v18, v24
     b5c:      	fadd.4s	v24, v24, v9
     b60:      	fadd.4s	v23, v23, v9
     b64:      	fmul.4s	v26, v22, v22
     b68:      	fmul.4s	v23, v26, v23
     b6c:      	fmul.4s	v26, v18, v18
     b70:      	fmul.4s	v24, v26, v24
     b74:      	fadd.4s	v18, v18, v24
     b78:      	fadd.4s	v22, v22, v23
     b7c:      	movi.2d	v26, #0xffffffffffffffff
     b80:      	add.4s	v19, v19, v26
     b84:      	fadd.4s	v18, v18, v0
     b88:      	sshr.4s	v23, v19, #0x1
     b8c:      	shl.4s	v24, v23, #0x17
     b90:      	add.4s	v24, v24, v0
     b94:      	fmul.4s	v18, v18, v24
     b98:      	add.4s	v20, v20, v26
     b9c:      	fadd.4s	v22, v22, v0
     ba0:      	sub.4s	v19, v19, v23
     ba4:      	sshr.4s	v23, v20, #0x1
     ba8:      	sub.4s	v20, v20, v23
     bac:      	shl.4s	v23, v23, #0x17
     bb0:      	add.4s	v23, v23, v0
     bb4:      	fmul.4s	v22, v22, v23
     bb8:      	shl.4s	v20, v20, #0x17
     bbc:      	add.4s	v20, v20, v0
     bc0:      	fmul.4s	v20, v22, v20
     bc4:      	shl.4s	v19, v19, #0x17
     bc8:      	add.4s	v19, v19, v0
     bcc:      	fmul.4s	v18, v18, v19
     bd0:      	fcmgt.4s	v17, v17, v25
     bd4:      	bsl.16b	v17, v13, v18
     bd8:      	fmul.4s	v3, v2, v3
     bdc:      	fcmgt.4s	v7, v7, v25
     be0:      	bsl.16b	v7, v13, v20
     be4:      	fdiv.4s	v3, v3, v6
     be8:      	ldr	q19, [sp, #0x120]
     bec:      	fdiv.4s	v6, v19, v7
     bf0:      	fsub.4s	v18, v7, v6
     bf4:      	fadd.4s	v6, v7, v6
     bf8:      	fdiv.4s	v6, v18, v6
     bfc:      	bsl.16b	v5, v6, v0
     c00:      	fcmge.4s	v2, v0, v2
     c04:      	bsl.16b	v2, v3, v5
     c08:      	fdiv.4s	v3, v19, v17
     c0c:      	fsub.4s	v5, v17, v3
     c10:      	fadd.4s	v3, v17, v3
     c14:      	fdiv.4s	v3, v5, v3
     c18:      	bif.16b	v3, v0, v4
     c1c:      	fcmge.4s	v1, v0, v1
     c20:      	bsl.16b	v1, v16, v3
     c24:      	mvni.4s	v4, #0x80, lsl #24
     c28:      	bif.16b	v1, v14, v4
     c2c:      	fcmeq.4s	v3, v14, v14
     c30:      	fadd.4s	v1, v1, v0
     c34:      	bif.16b	v1, v15, v3
     c38:      	bif.16b	v2, v12, v4
     c3c:      	fcmeq.4s	v3, v12, v12
     c40:      	fadd.4s	v2, v2, v0
     c44:      	bif.16b	v2, v15, v3
     c48:      	fmul.4s	v3, v11, v9
     c4c:      	fmul.4s	v2, v3, v2
     c50:      	fmul.4s	v3, v10, v9
     c54:      	fmul.4s	v1, v3, v1
     c58:      	add	x16, x14, x9
     c5c:      	ldp	q4, q3, [x16]
     c60:      	fadd.4s	v1, v4, v1
     c64:      	fadd.4s	v2, v3, v2
     c68:      	add	x16, x13, x9
     c6c:      	stp	q1, q2, [x16]
     c70:      	add	x9, x9, #0x20
     c74:      	cmp	x9, #0x100
     c78:      	b.ne	0x968 <ltmp0+0x968>
     c7c:      	add	x9, x11, #0x100
     c80:      	ldr	s2, [x12, x9]
     c84:      	movi.2d	v1, #0000000000000000
     c88:      	mov	w11, #0x2713            ; =10003
     c8c:      	movk	w11, #0x3d37, lsl #16
     c90:      	fmov	s3, w11
     c94:      	fmul.4s	v3, v2, v3
     c98:      	fmul.4s	v3, v2, v3
     c9c:      	fmul.4s	v3, v2, v3
     ca0:      	fadd.4s	v3, v2, v3
     ca4:      	mov	w11, #0x422a            ; =16938
     ca8:      	movk	w11, #0x3f4c, lsl #16
     cac:      	fmov	s4, w11
     cb0:      	fmul.4s	v3, v3, v4
     cb4:      	mov.s	v1[0], v3[0]
     cb8:      	fabs.4s	v3, v1
     cbc:      	mov	w11, #0x9231            ; =37425
     cc0:      	movk	w11, #0x2f30, lsl #16
     cc4:      	dup.4s	v5, w11
     cc8:      	mov	w11, #0x322b            ; =12843
     ccc:      	movk	w11, #0x32d7, lsl #16
     cd0:      	dup.4s	v6, w11
     cd4:      	fmul.4s	v4, v1, v1
     cd8:      	fmla.4s	v6, v4, v5
     cdc:      	mov	w11, #0xef1d            ; =61213
     ce0:      	movk	w11, #0x3638, lsl #16
     ce4:      	dup.4s	v5, w11
     ce8:      	fmla.4s	v5, v4, v6
     cec:      	mov	w11, #0xd01             ; =3329
     cf0:      	movk	w11, #0x3950, lsl #16
     cf4:      	dup.4s	v6, w11
     cf8:      	mov	w11, #0x8889            ; =34953
     cfc:      	movk	w11, #0x3c08, lsl #16
     d00:      	dup.4s	v16, w11
     d04:      	fmla.4s	v6, v4, v5
     d08:      	fmla.4s	v16, v4, v6
     d0c:      	mov	w11, #0xaaab            ; =43691
     d10:      	movk	w11, #0x3e2a, lsl #16
     d14:      	dup.4s	v17, w11
     d18:      	ldr	q5, [sp, #0x110]
     d1c:      	fcmge.4s	v5, v5, v3
     d20:      	and.16b	v6, v5, v3
     d24:      	mov	w11, #-0x3d300000       ; =-1026555904
     d28:      	dup.4s	v7, w11
     d2c:      	fcmge.4s	v18, v6, v7
     d30:      	mov	w11, #0x42c80000        ; =1120403456
     d34:      	dup.4s	v7, w11
     d38:      	fcmge.4s	v19, v7, v6
     d3c:      	and.16b	v18, v18, v19
     d40:      	and.16b	v18, v18, v6
     d44:      	mov	w11, #0xaa3b            ; =43579
     d48:      	movk	w11, #0x3fb8, lsl #16
     d4c:      	dup.4s	v19, w11
     d50:      	fmul.4s	v19, v18, v19
     d54:      	movi.4s	v20, #0x4b, lsl #24
     d58:      	fadd.4s	v19, v19, v20
     d5c:      	movi.4s	v20, #0xcb, lsl #24
     d60:      	fadd.4s	v19, v19, v20
     d64:      	fcvtzs.4s	v19, v19
     d68:      	scvtf.4s	v20, v19
     d6c:      	mov	w11, #0x7200            ; =29184
     d70:      	movk	w11, #0xbf31, lsl #16
     d74:      	dup.4s	v21, w11
     d78:      	fmul.4s	v21, v20, v21
     d7c:      	fadd.4s	v18, v18, v21
     d80:      	mov	w11, #0xbe8e            ; =48782
     d84:      	movk	w11, #0xb5bf, lsl #16
     d88:      	dup.4s	v21, w11
     d8c:      	fmul.4s	v20, v20, v21
     d90:      	fadd.4s	v18, v18, v20
     d94:      	mov	w11, #0x2bda            ; =11226
     d98:      	movk	w11, #0x3950, lsl #16
     d9c:      	dup.4s	v20, w11
     da0:      	fmul.4s	v20, v18, v20
     da4:      	mov	w11, #0x96c9            ; =38601
     da8:      	movk	w11, #0x3ab6, lsl #16
     dac:      	dup.4s	v21, w11
     db0:      	fadd.4s	v20, v20, v21
     db4:      	mov	w11, #0x88a6            ; =34982
     db8:      	movk	w11, #0x3c08, lsl #16
     dbc:      	dup.4s	v21, w11
     dc0:      	fmul.4s	v20, v18, v20
     dc4:      	fadd.4s	v20, v20, v21
     dc8:      	fmul.4s	v20, v18, v20
     dcc:      	mov	w11, #0xaa7a            ; =43642
     dd0:      	movk	w11, #0x3d2a, lsl #16
     dd4:      	dup.4s	v21, w11
     dd8:      	fadd.4s	v20, v20, v21
     ddc:      	fmul.4s	v20, v18, v20
     de0:      	fadd.4s	v20, v20, v17
     de4:      	fmla.4s	v17, v4, v16
     de8:      	mov.16b	v16, v0
     dec:      	mov	w11, #0x76c7            ; =30407
     df0:      	movk	w11, #0x310f, lsl #16
     df4:      	dup.4s	v21, w11
     df8:      	mov	w11, #0xf27e            ; =62078
     dfc:      	movk	w11, #0x3493, lsl #16
     e00:      	dup.4s	v22, w11
     e04:      	fmla.4s	v16, v4, v17
     e08:      	fmla.4s	v22, v4, v21
     e0c:      	mov	w11, #0xd01             ; =3329
     e10:      	movk	w11, #0x37d0, lsl #16
     e14:      	dup.4s	v17, w11
     e18:      	fmla.4s	v17, v4, v22
     e1c:      	mov	w11, #0xb61             ; =2913
     e20:      	movk	w11, #0x3ab6, lsl #16
     e24:      	dup.4s	v21, w11
     e28:      	mov	w11, #0xaaab            ; =43691
     e2c:      	movk	w11, #0x3d2a, lsl #16
     e30:      	dup.4s	v22, w11
     e34:      	fmla.4s	v21, v4, v17
     e38:      	fmla.4s	v22, v4, v21
     e3c:      	movi.4s	v17, #0x3f, lsl #24
     e40:      	fmla.4s	v17, v4, v22
     e44:      	mov.16b	v21, v0
     e48:      	fmla.4s	v21, v4, v17
     e4c:      	movi.4s	v4, #0x3f, lsl #24
     e50:      	fmul.4s	v2, v2, v4
     e54:      	fcmge.4s	v17, v0, v3
     e58:      	fmul.4s	v3, v3, v16
     e5c:      	fdiv.4s	v3, v3, v21
     e60:      	fmul.4s	v16, v18, v20
     e64:      	fadd.4s	v4, v16, v4
     e68:      	fmul.4s	v16, v18, v18
     e6c:      	fmul.4s	v4, v16, v4
     e70:      	fadd.4s	v4, v18, v4
     e74:      	fadd.4s	v4, v4, v0
     e78:      	movi.2d	v16, #0xffffffffffffffff
     e7c:      	add.4s	v16, v19, v16
     e80:      	sshr.4s	v18, v16, #0x1
     e84:      	shl.4s	v19, v18, #0x17
     e88:      	add.4s	v19, v19, v0
     e8c:      	fmul.4s	v4, v4, v19
     e90:      	sub.4s	v16, v16, v18
     e94:      	shl.4s	v16, v16, #0x17
     e98:      	add.4s	v16, v16, v0
     e9c:      	fmul.4s	v4, v4, v16
     ea0:      	fcmgt.4s	v6, v6, v7
     ea4:      	mvni.4s	v7, #0x7f, msl #16
     ea8:      	fneg.4s	v7, v7
     eac:      	bit.16b	v4, v7, v6
     eb0:      	ldr	q6, [sp, #0x120]
     eb4:      	fdiv.4s	v6, v6, v4
     eb8:      	fsub.4s	v7, v4, v6
     ebc:      	fadd.4s	v4, v4, v6
     ec0:      	fdiv.4s	v4, v7, v4
     ec4:      	bif.16b	v4, v0, v5
     ec8:      	bif.16b	v3, v4, v17
     ecc:      	mvni.4s	v4, #0x80, lsl #24
     ed0:      	bif.16b	v3, v1, v4
     ed4:      	fcmeq.4s	v1, v1, v1
     ed8:      	fadd.4s	v0, v3, v0
     edc:      	mvni.4s	v3, #0x3f, msl #16
     ee0:      	fneg.4s	v3, v3
     ee4:      	bif.16b	v0, v3, v1
     ee8:      	fmul.4s	v0, v2, v0
     eec:      	ldr	s1, [x10, x9]
     ef0:      	fadd.4s	v0, v1, v0
     ef4:      	str	s0, [x8, x9]
     ef8:      	add	sp, sp, #0x370
     efc:      	ldp	x28, x27, [sp, #0x40]
     f00:      	ldp	d9, d8, [sp, #0x30]
     f04:      	ldp	d11, d10, [sp, #0x20]
     f08:      	ldp	d13, d12, [sp, #0x10]
     f0c:      	ldp	d15, d14, [sp], #0x50
     f10:      	ret

0000000000000f14 <_llm_rows.packet_batch.blocks>:
     f14:      	stp	d15, d14, [sp, #-0xa0]!
     f18:      	stp	d13, d12, [sp, #0x10]
     f1c:      	stp	d11, d10, [sp, #0x20]
     f20:      	stp	d9, d8, [sp, #0x30]
     f24:      	stp	x28, x27, [sp, #0x40]
     f28:      	stp	x26, x25, [sp, #0x50]
     f2c:      	stp	x24, x23, [sp, #0x60]
     f30:      	stp	x22, x21, [sp, #0x70]
     f34:      	stp	x20, x19, [sp, #0x80]
     f38:      	stp	x29, x30, [sp, #0x90]
     f3c:      	sub	sp, sp, #0x5f0
     f40:      	str	x0, [sp, #0x118]
     f44:      	cbz	w3, 0x2a9c <_llm_rows.packet_batch.blocks+0x1b88>
     f48:      	mov	x19, x3
     f4c:      	mov	x20, x2
     f50:      	mov	w22, #0x0               ; =0
     f54:      	ldp	w9, w8, [x2, #0x2c]
     f58:      	str	w9, [sp, #0x114]
     f5c:      	str	w8, [sp, #0x110]
     f60:      	adrp	x8, 0x0 <ltmp0>
     f64:      	ldr	q0, [x8]
     f68:      	str	q0, [sp, #0xd0]
     f6c:      	adrp	x8, 0x0 <ltmp0>
     f70:      	ldr	q0, [x8]
     f74:      	str	q0, [sp, #0xc0]
     f78:      	adrp	x8, 0x0 <ltmp0>
     f7c:      	ldr	q0, [x8]
     f80:      	str	q0, [sp, #0xb0]
     f84:      	adrp	x8, 0x0 <ltmp0>
     f88:      	ldr	q0, [x8]
     f8c:      	str	q0, [sp, #0xa0]
     f90:      	adrp	x8, 0x0 <ltmp0>
     f94:      	ldr	q0, [x8]
     f98:      	str	q0, [sp, #0x90]
     f9c:      	adrp	x8, 0x0 <ltmp0>
     fa0:      	ldr	q0, [x8]
     fa4:      	str	q0, [sp, #0x80]
     fa8:      	adrp	x8, 0x0 <ltmp0>
     fac:      	ldr	q0, [x8]
     fb0:      	str	q0, [sp, #0x120]
     fb4:      	movi.4s	v21, #0x3f, lsl #24
     fb8:      	mvni.4s	v0, #0x7f, msl #16
     fbc:      	fneg.4s	v1, v0
     fc0:      	mvni.4s	v0, #0x3f, msl #16
     fc4:      	fneg.4s	v0, v0
     fc8:      	stp	q0, q1, [sp, #0x170]
     fcc:      	ldp	w24, w27, [x2]
     fd0:      	add	x23, sp, #0x4d0
     fd4:      	ldp	w28, w25, [x2, #0x8]
     fd8:      	add	x26, sp, #0x3b0
     fdc:      	str	w3, [sp, #0xfc]
     fe0:      	b	0x102c <_llm_rows.packet_batch.blocks+0x118>
     fe4:      	mov	w8, #0x18               ; =24
     fe8:      	str	w8, [x20, #0x24]
     fec:      	ldr	w19, [sp, #0xfc]
     ff0:      	add	w8, w24, #0x1
     ff4:      	ldr	w9, [sp, #0x114]
     ff8:      	cmp	w8, w9
     ffc:      	cset	w8, eq
    1000:      	csinc	w24, wzr, w24, eq
    1004:      	cinc	w9, w27, eq
    1008:      	ldr	w10, [sp, #0x110]
    100c:      	cmp	w9, w10
    1010:      	cset	w10, eq
    1014:      	ands	w8, w8, w10
    1018:      	csel	w27, wzr, w9, ne
    101c:      	add	w28, w28, w8
    1020:      	add	w22, w22, #0x1
    1024:      	cmp	w22, w19
    1028:      	b.eq	0x2a9c <_llm_rows.packet_batch.blocks+0x1b88>
    102c:      	ubfiz	x8, x24, #5, #32
    1030:      	cmp	x8, x25
    1034:      	csel	x9, x8, xzr, ls
    1038:      	subs	x10, x25, x9
    103c:      	cmp	x10, #0x20
    1040:      	mov	w11, #0x20              ; =32
    1044:      	csel	x10, x10, x11, lo
    1048:      	cmp	x25, x9
    104c:      	stp	w24, w27, [x20]
    1050:      	str	w28, [x20, #0x8]
    1054:      	str	wzr, [x20, #0x24]
    1058:      	ccmp	x8, x25, #0x2, hi
    105c:      	csel	x21, x10, xzr, ls
    1060:      	cmp	x21, #0x20
    1064:      	b.lo	0x10bc <_llm_rows.packet_batch.blocks+0x1a8>
    1068:      	ldr	x21, [sp, #0x118]
    106c:      	mov	x0, x21
    1070:      	mov	x1, x20
    1074:      	bl	0x1074 <_llm_rows.packet_batch.blocks+0x160>
    1078:      	mov	w8, #0x8                ; =8
    107c:      	str	w8, [x20, #0x24]
    1080:      	mov	x0, x21
    1084:      	mov	x1, x20
    1088:      	bl	0x1088 <_llm_rows.packet_batch.blocks+0x174>
    108c:      	mov	w8, #0x10               ; =16
    1090:      	str	w8, [x20, #0x24]
    1094:      	mov	x0, x21
    1098:      	mov	x1, x20
    109c:      	bl	0x109c <_llm_rows.packet_batch.blocks+0x188>
    10a0:      	mov	w8, #0x18               ; =24
    10a4:      	str	w8, [x20, #0x24]
    10a8:      	mov	x0, x21
    10ac:      	mov	x1, x20
    10b0:      	bl	0x10b0 <_llm_rows.packet_batch.blocks+0x19c>
    10b4:      	movi.4s	v21, #0x3f, lsl #24
    10b8:      	b	0xff0 <_llm_rows.packet_batch.blocks+0xdc>
    10bc:      	lsr	x19, x21, #3
    10c0:      	cmp	x21, #0x8
    10c4:      	b.lo	0x111c <_llm_rows.packet_batch.blocks+0x208>
    10c8:      	str	wzr, [x20, #0x24]
    10cc:      	ldr	x0, [sp, #0x118]
    10d0:      	mov	x1, x20
    10d4:      	bl	0x10d4 <_llm_rows.packet_batch.blocks+0x1c0>
    10d8:      	movi.4s	v21, #0x3f, lsl #24
    10dc:      	cmp	x19, #0x1
    10e0:      	b.eq	0x111c <_llm_rows.packet_batch.blocks+0x208>
    10e4:      	mov	w8, #0x8                ; =8
    10e8:      	str	w8, [x20, #0x24]
    10ec:      	ldr	x0, [sp, #0x118]
    10f0:      	mov	x1, x20
    10f4:      	bl	0x10f4 <_llm_rows.packet_batch.blocks+0x1e0>
    10f8:      	movi.4s	v21, #0x3f, lsl #24
    10fc:      	cmp	x19, #0x2
    1100:      	b.eq	0x111c <_llm_rows.packet_batch.blocks+0x208>
    1104:      	mov	w8, #0x10               ; =16
    1108:      	str	w8, [x20, #0x24]
    110c:      	ldr	x0, [sp, #0x118]
    1110:      	mov	x1, x20
    1114:      	bl	0x1114 <_llm_rows.packet_batch.blocks+0x200>
    1118:      	movi.4s	v21, #0x3f, lsl #24
    111c:      	and	w8, w21, #0x7
    1120:      	cbz	w8, 0xfe4 <_llm_rows.packet_batch.blocks+0xd0>
    1124:      	dup.4s	v0, w8
    1128:      	ldp	q2, q1, [sp, #0xc0]
    112c:      	cmhi.4s	v10, v0, v2
    1130:      	cmhi.4s	v11, v0, v1
    1134:      	uzp1.8h	v2, v11, v10
    1138:      	umaxv.8h	h0, v2
    113c:      	fmov	w8, s0
    1140:      	tbz	w8, #0x0, 0xfe4 <_llm_rows.packet_batch.blocks+0xd0>
    1144:      	ldr	x8, [sp, #0x118]
    1148:      	ldr	x11, [x8]
    114c:      	ldr	x9, [x8, #0x10]
    1150:      	ldr	x8, [x8, #0x30]
    1154:      	xtn.4h	v0, v11
    1158:      	str	d0, [sp, #0x100]
    115c:      	uzp1.8b	v0, v0, v0
    1160:      	sshll.2d	v1, v11, #0x0
    1164:      	sshll.2d	v3, v10, #0x0
    1168:      	sshll2.2d	v14, v11, #0x0
    116c:      	sshll2.2d	v13, v10, #0x0
    1170:      	ldp	q4, q5, [sp, #0xa0]
    1174:      	and.16b	v29, v13, v5
    1178:      	and.16b	v5, v14, v4
    117c:      	ldr	q4, [sp, #0x90]
    1180:      	and.16b	v3, v3, v4
    1184:      	stp	q5, q3, [sp, #0x150]
    1188:      	ldr	q3, [sp, #0x80]
    118c:      	and.16b	v16, v1, v3
    1190:      	ubfiz	w10, w24, #2, #27
    1194:      	orr	w12, w10, w19
    1198:      	dup.4s	v1, w12
    119c:      	and.16b	v6, v11, v1
    11a0:      	and.16b	v1, v10, v1
    11a4:      	ushll2.2d	v5, v1, #0x0
    11a8:      	ushll2.2d	v4, v6, #0x0
    11ac:      	subs	x10, x11, x8
    11b0:      	lsr	x10, x10, #2
    11b4:      	mov	w15, #0x450             ; =1104
    11b8:      	ccmp	x10, x15, #0x0, hs
    11bc:      	cset	w10, hi
    11c0:      	subs	x13, x8, x11
    11c4:      	lsr	x13, x13, #2
    11c8:      	ccmp	x13, x15, #0x0, hs
    11cc:      	mov	w13, #0x2713            ; =10003
    11d0:      	movk	w13, #0x3d37, lsl #16
    11d4:      	dup.4s	v7, w13
    11d8:      	csinc	w14, w10, wzr, ls
    11dc:      	subs	x10, x9, x8
    11e0:      	mov	w13, #0x422a            ; =16938
    11e4:      	movk	w13, #0x3f4c, lsl #16
    11e8:      	dup.4s	v3, w13
    11ec:      	stp	q7, q3, [sp, #0x190]
    11f0:      	mov	w13, #0x9231            ; =37425
    11f4:      	movk	w13, #0x2f30, lsl #16
    11f8:      	dup.4s	v7, w13
    11fc:      	lsr	x10, x10, #2
    1200:      	ccmp	x10, x15, #0x0, hs
    1204:      	mov	w10, #0x322b            ; =12843
    1208:      	movk	w10, #0x32d7, lsl #16
    120c:      	dup.4s	v3, w10
    1210:      	stp	q7, q3, [sp, #0x1b0]
    1214:      	mov	w10, #0xef1d            ; =61213
    1218:      	movk	w10, #0x3638, lsl #16
    121c:      	dup.4s	v7, w10
    1220:      	cset	w10, hi
    1224:      	subs	x13, x8, x9
    1228:      	mov	w16, #0xd01             ; =3329
    122c:      	movk	w16, #0x3950, lsl #16
    1230:      	dup.4s	v3, w16
    1234:      	stp	q7, q3, [sp, #0x1d0]
    1238:      	mov	w16, #0x8889            ; =34953
    123c:      	movk	w16, #0x3c08, lsl #16
    1240:      	dup.4s	v3, w16
    1244:      	str	q3, [sp, #0x200]
    1248:      	lsr	x13, x13, #2
    124c:      	ccmp	x13, x15, #0x0, hs
    1250:      	umov.b	w13, v0[0]
    1254:      	mov	w15, #0xaaab            ; =43691
    1258:      	movk	w15, #0x3e2a, lsl #16
    125c:      	dup.4s	v3, w15
    1260:      	ushll.2d	v7, v1, #0x0
    1264:      	ushll.2d	v6, v6, #0x0
    1268:      	csinc	w10, w10, wzr, ls
    126c:      	mov	w15, #0x104             ; =260
    1270:      	umull	x12, w12, w15
    1274:      	tst	w13, #0x1
    1278:      	csel	x12, x12, xzr, ne
    127c:      	mov	w15, #0x76c7            ; =30407
    1280:      	movk	w15, #0x310f, lsl #16
    1284:      	dup.4s	v0, w15
    1288:      	str	q0, [sp, #0x1f0]
    128c:      	mov	w15, #0xf27e            ; =62078
    1290:      	movk	w15, #0x3493, lsl #16
    1294:      	dup.4s	v0, w15
    1298:      	str	q0, [sp, #0x210]
    129c:      	mov	w15, #0xd01             ; =3329
    12a0:      	movk	w15, #0x37d0, lsl #16
    12a4:      	dup.4s	v0, w15
    12a8:      	str	q0, [sp, #0x220]
    12ac:      	fmov.4s	v0, #1.00000000
    12b0:      	mov	w15, #0xb61             ; =2913
    12b4:      	movk	w15, #0x3ab6, lsl #16
    12b8:      	dup.4s	v1, w15
    12bc:      	str	q1, [sp, #0x230]
    12c0:      	mov	w15, #0xaaab            ; =43691
    12c4:      	movk	w15, #0x3d2a, lsl #16
    12c8:      	dup.4s	v23, w15
    12cc:      	fmov.4s	v28, #9.00000000
    12d0:      	mov	w15, #-0x3d300000       ; =-1026555904
    12d4:      	dup.4s	v30, w15
    12d8:      	mov	w15, #0x42c80000        ; =1120403456
    12dc:      	dup.4s	v1, w15
    12e0:      	mov	w15, #0xaa3b            ; =43579
    12e4:      	movk	w15, #0x3fb8, lsl #16
    12e8:      	dup.4s	v27, w15
    12ec:      	mov	w15, #0x7200            ; =29184
    12f0:      	movk	w15, #0xbf31, lsl #16
    12f4:      	dup.4s	v9, w15
    12f8:      	mov	w15, #0xbe8e            ; =48782
    12fc:      	movk	w15, #0xb5bf, lsl #16
    1300:      	dup.4s	v24, w15
    1304:      	mov	w15, #0x2bda            ; =11226
    1308:      	movk	w15, #0x3950, lsl #16
    130c:      	dup.4s	v22, w15
    1310:      	xtn.2s	v17, v6
    1314:      	xtn.2s	v5, v5
    1318:      	str	d5, [sp, #0x140]
    131c:      	xtn.2s	v5, v7
    1320:      	str	d5, [sp, #0x130]
    1324:      	xtn.2s	v4, v4
    1328:      	str	d4, [sp, #0xe0]
    132c:      	mov	w15, #0x96c9            ; =38601
    1330:      	movk	w15, #0x3ab6, lsl #16
    1334:      	dup.4s	v20, w15
    1338:      	mov	w15, #0x88a6            ; =34982
    133c:      	movk	w15, #0x3c08, lsl #16
    1340:      	dup.4s	v25, w15
    1344:      	mov	w15, #0xaa7a            ; =43642
    1348:      	movk	w15, #0x3d2a, lsl #16
    134c:      	dup.4s	v26, w15
    1350:      	fmov.4s	v31, #0.25000000
    1354:      	cmp	w14, #0x1
    1358:      	b.ne	0x1850 <_llm_rows.packet_batch.blocks+0x93c>
    135c:      	cbz	w10, 0x1850 <_llm_rows.packet_batch.blocks+0x93c>
    1360:      	str	d17, [sp, #0x60]
    1364:      	str	q16, [sp, #0x70]
    1368:      	mov	x10, #0x0               ; =0
    136c:      	add	x13, x8, x12
    1370:      	add	x14, x9, x12
    1374:      	add	x12, x11, x12
    1378:      	ldr	q4, [sp, #0x120]
    137c:      	and.16b	v2, v2, v4
    1380:      	addv.8h	h15, v2
    1384:      	fmov	w15, s15
    1388:      	b	0x1398 <_llm_rows.packet_batch.blocks+0x484>
    138c:      	add	x10, x10, #0x20
    1390:      	cmp	x10, #0x100
    1394:      	b.eq	0x2504 <_llm_rows.packet_batch.blocks+0x15f0>
    1398:      	add	x16, x12, x10
    139c:      	movi.2d	v14, #0000000000000000
    13a0:      	movi.2d	v13, #0000000000000000
    13a4:      	tbz	w15, #0x0, 0x1438 <_llm_rows.packet_batch.blocks+0x524>
    13a8:      	ldr	s14, [x16]
    13ac:      	and	w17, w15, #0xff
    13b0:      	tbnz	w17, #0x1, 0x1440 <_llm_rows.packet_batch.blocks+0x52c>
    13b4:      	tbz	w17, #0x2, 0x144c <_llm_rows.packet_batch.blocks+0x538>
    13b8:      	add	x0, x16, #0x8
    13bc:      	ld1.s	{ v14 }[2], [x0]
    13c0:      	tbnz	w17, #0x3, 0x1450 <_llm_rows.packet_batch.blocks+0x53c>
    13c4:      	tbz	w17, #0x4, 0x145c <_llm_rows.packet_batch.blocks+0x548>
    13c8:      	add	x0, x16, #0x10
    13cc:      	ld1.s	{ v13 }[0], [x0]
    13d0:      	tbnz	w17, #0x5, 0x1460 <_llm_rows.packet_batch.blocks+0x54c>
    13d4:      	tbz	w17, #0x6, 0x146c <_llm_rows.packet_batch.blocks+0x558>
    13d8:      	add	x0, x16, #0x18
    13dc:      	ld1.s	{ v13 }[2], [x0]
    13e0:      	tbnz	w17, #0x7, 0x1470 <_llm_rows.packet_batch.blocks+0x55c>
    13e4:      	fmov	w17, s15
    13e8:      	add	x16, x14, x10
    13ec:      	movi.2d	v2, #0000000000000000
    13f0:      	movi.2d	v12, #0000000000000000
    13f4:      	tbz	w17, #0x0, 0x148c <_llm_rows.packet_batch.blocks+0x578>
    13f8:      	ldr	s2, [x16]
    13fc:      	and	w17, w17, #0xff
    1400:      	tbnz	w17, #0x1, 0x1494 <_llm_rows.packet_batch.blocks+0x580>
    1404:      	tbz	w17, #0x2, 0x14a0 <_llm_rows.packet_batch.blocks+0x58c>
    1408:      	add	x0, x16, #0x8
    140c:      	ld1.s	{ v2 }[2], [x0]
    1410:      	tbnz	w17, #0x3, 0x14a4 <_llm_rows.packet_batch.blocks+0x590>
    1414:      	tbz	w17, #0x4, 0x14b0 <_llm_rows.packet_batch.blocks+0x59c>
    1418:      	add	x0, x16, #0x10
    141c:      	ld1.s	{ v12 }[0], [x0]
    1420:      	tbnz	w17, #0x5, 0x14b4 <_llm_rows.packet_batch.blocks+0x5a0>
    1424:      	tbz	w17, #0x6, 0x14c0 <_llm_rows.packet_batch.blocks+0x5ac>
    1428:      	add	x0, x16, #0x18
    142c:      	ld1.s	{ v12 }[2], [x0]
    1430:      	tbnz	w17, #0x7, 0x14c4 <_llm_rows.packet_batch.blocks+0x5b0>
    1434:      	b	0x14cc <_llm_rows.packet_batch.blocks+0x5b8>
    1438:      	and	w17, w15, #0xff
    143c:      	tbz	w17, #0x1, 0x13b4 <_llm_rows.packet_batch.blocks+0x4a0>
    1440:      	add	x0, x16, #0x4
    1444:      	ld1.s	{ v14 }[1], [x0]
    1448:      	tbnz	w17, #0x2, 0x13b8 <_llm_rows.packet_batch.blocks+0x4a4>
    144c:      	tbz	w17, #0x3, 0x13c4 <_llm_rows.packet_batch.blocks+0x4b0>
    1450:      	add	x0, x16, #0xc
    1454:      	ld1.s	{ v14 }[3], [x0]
    1458:      	tbnz	w17, #0x4, 0x13c8 <_llm_rows.packet_batch.blocks+0x4b4>
    145c:      	tbz	w17, #0x5, 0x13d4 <_llm_rows.packet_batch.blocks+0x4c0>
    1460:      	add	x0, x16, #0x14
    1464:      	ld1.s	{ v13 }[1], [x0]
    1468:      	tbnz	w17, #0x6, 0x13d8 <_llm_rows.packet_batch.blocks+0x4c4>
    146c:      	tbz	w17, #0x7, 0x13e4 <_llm_rows.packet_batch.blocks+0x4d0>
    1470:      	add	x16, x16, #0x1c
    1474:      	ld1.s	{ v13 }[3], [x16]
    1478:      	fmov	w17, s15
    147c:      	add	x16, x14, x10
    1480:      	movi.2d	v2, #0000000000000000
    1484:      	movi.2d	v12, #0000000000000000
    1488:      	tbnz	w17, #0x0, 0x13f8 <_llm_rows.packet_batch.blocks+0x4e4>
    148c:      	and	w17, w17, #0xff
    1490:      	tbz	w17, #0x1, 0x1404 <_llm_rows.packet_batch.blocks+0x4f0>
    1494:      	add	x0, x16, #0x4
    1498:      	ld1.s	{ v2 }[1], [x0]
    149c:      	tbnz	w17, #0x2, 0x1408 <_llm_rows.packet_batch.blocks+0x4f4>
    14a0:      	tbz	w17, #0x3, 0x1414 <_llm_rows.packet_batch.blocks+0x500>
    14a4:      	add	x0, x16, #0xc
    14a8:      	ld1.s	{ v2 }[3], [x0]
    14ac:      	tbnz	w17, #0x4, 0x1418 <_llm_rows.packet_batch.blocks+0x504>
    14b0:      	tbz	w17, #0x5, 0x1424 <_llm_rows.packet_batch.blocks+0x510>
    14b4:      	add	x0, x16, #0x14
    14b8:      	ld1.s	{ v12 }[1], [x0]
    14bc:      	tbnz	w17, #0x6, 0x1428 <_llm_rows.packet_batch.blocks+0x514>
    14c0:      	tbz	w17, #0x7, 0x14cc <_llm_rows.packet_batch.blocks+0x5b8>
    14c4:      	add	x16, x16, #0x1c
    14c8:      	ld1.s	{ v12 }[3], [x16]
    14cc:      	ldp	q4, q5, [sp, #0x190]
    14d0:      	fmul.4s	v4, v14, v4
    14d4:      	fmul.4s	v4, v14, v4
    14d8:      	fmul.4s	v4, v14, v4
    14dc:      	fadd.4s	v4, v14, v4
    14e0:      	fmul.4s	v4, v4, v5
    14e4:      	and.16b	v4, v11, v4
    14e8:      	fabs.4s	v5, v4
    14ec:      	fmul.4s	v6, v4, v4
    14f0:      	ldp	q16, q7, [sp, #0x1b0]
    14f4:      	fmla.4s	v7, v6, v16
    14f8:      	ldr	q16, [sp, #0x1d0]
    14fc:      	fmla.4s	v16, v6, v7
    1500:      	ldp	q7, q17, [sp, #0x1e0]
    1504:      	fmla.4s	v7, v6, v16
    1508:      	ldr	q16, [sp, #0x200]
    150c:      	fmla.4s	v16, v6, v7
    1510:      	mov.16b	v7, v3
    1514:      	fmla.4s	v7, v6, v16
    1518:      	mov.16b	v16, v0
    151c:      	fmla.4s	v16, v6, v7
    1520:      	fmul.4s	v7, v5, v16
    1524:      	ldr	q16, [sp, #0x210]
    1528:      	fmla.4s	v16, v6, v17
    152c:      	ldr	q17, [sp, #0x220]
    1530:      	fmla.4s	v17, v6, v16
    1534:      	ldr	q16, [sp, #0x230]
    1538:      	fmla.4s	v16, v6, v17
    153c:      	mov.16b	v17, v23
    1540:      	fmla.4s	v17, v6, v16
    1544:      	movi.4s	v16, #0x3f, lsl #24
    1548:      	fmla.4s	v16, v6, v17
    154c:      	mov.16b	v17, v0
    1550:      	fmla.4s	v17, v6, v16
    1554:      	fdiv.4s	v6, v7, v17
    1558:      	fcmge.4s	v7, v28, v5
    155c:      	and.16b	v16, v7, v5
    1560:      	fcmge.4s	v17, v16, v30
    1564:      	fcmge.4s	v18, v1, v16
    1568:      	and.16b	v17, v17, v18
    156c:      	and.16b	v17, v17, v16
    1570:      	fmul.4s	v18, v17, v27
    1574:      	movi.4s	v19, #0x4b, lsl #24
    1578:      	fadd.4s	v18, v18, v19
    157c:      	movi.4s	v19, #0xcb, lsl #24
    1580:      	fadd.4s	v18, v18, v19
    1584:      	fcvtzs.4s	v18, v18
    1588:      	scvtf.4s	v8, v18
    158c:      	fmul.4s	v19, v8, v9
    1590:      	fadd.4s	v17, v17, v19
    1594:      	fmul.4s	v19, v8, v24
    1598:      	fadd.4s	v17, v17, v19
    159c:      	fmul.4s	v19, v17, v22
    15a0:      	fadd.4s	v19, v19, v20
    15a4:      	fmul.4s	v19, v17, v19
    15a8:      	fadd.4s	v19, v19, v25
    15ac:      	fmul.4s	v19, v17, v19
    15b0:      	fadd.4s	v19, v19, v26
    15b4:      	fmul.4s	v19, v17, v19
    15b8:      	fadd.4s	v19, v19, v3
    15bc:      	fmul.4s	v19, v17, v19
    15c0:      	fadd.4s	v19, v19, v21
    15c4:      	fmul.4s	v8, v17, v17
    15c8:      	fmul.4s	v19, v8, v19
    15cc:      	fadd.4s	v17, v17, v19
    15d0:      	fadd.4s	v17, v17, v0
    15d4:      	movi.2d	v19, #0xffffffffffffffff
    15d8:      	add.4s	v18, v18, v19
    15dc:      	sshr.4s	v19, v18, #0x1
    15e0:      	shl.4s	v8, v19, #0x17
    15e4:      	add.4s	v8, v8, v0
    15e8:      	fmul.4s	v17, v17, v8
    15ec:      	sub.4s	v18, v18, v19
    15f0:      	shl.4s	v18, v18, #0x17
    15f4:      	add.4s	v18, v18, v0
    15f8:      	fmul.4s	v17, v17, v18
    15fc:      	fcmgt.4s	v16, v16, v1
    1600:      	ldr	q18, [sp, #0x180]
    1604:      	bsl.16b	v16, v18, v17
    1608:      	fdiv.4s	v17, v31, v16
    160c:      	fsub.4s	v18, v16, v17
    1610:      	fadd.4s	v16, v16, v17
    1614:      	fdiv.4s	v16, v18, v16
    1618:      	bsl.16b	v7, v16, v0
    161c:      	fcmge.4s	v5, v0, v5
    1620:      	bsl.16b	v5, v6, v7
    1624:      	mvni.4s	v6, #0x80, lsl #24
    1628:      	bif.16b	v5, v4, v6
    162c:      	fcmeq.4s	v4, v4, v4
    1630:      	fadd.4s	v5, v5, v0
    1634:      	ldr	q6, [sp, #0x170]
    1638:      	bsl.16b	v4, v5, v6
    163c:      	fmul.4s	v5, v14, v21
    1640:      	fmul.4s	v4, v5, v4
    1644:      	fadd.4s	v2, v2, v4
    1648:      	fmov	w17, s15
    164c:      	add	x16, x13, x10
    1650:      	tbz	w17, #0x0, 0x1674 <_llm_rows.packet_batch.blocks+0x760>
    1654:      	str	s2, [x16]
    1658:      	and	w17, w17, #0xff
    165c:      	tbnz	w17, #0x1, 0x167c <_llm_rows.packet_batch.blocks+0x768>
    1660:      	tbz	w17, #0x2, 0x1688 <_llm_rows.packet_batch.blocks+0x774>
    1664:      	add	x0, x16, #0x8
    1668:      	st1.s	{ v2 }[2], [x0]
    166c:      	tbnz	w17, #0x3, 0x168c <_llm_rows.packet_batch.blocks+0x778>
    1670:      	b	0x1694 <_llm_rows.packet_batch.blocks+0x780>
    1674:      	and	w17, w17, #0xff
    1678:      	tbz	w17, #0x1, 0x1660 <_llm_rows.packet_batch.blocks+0x74c>
    167c:      	add	x0, x16, #0x4
    1680:      	st1.s	{ v2 }[1], [x0]
    1684:      	tbnz	w17, #0x2, 0x1664 <_llm_rows.packet_batch.blocks+0x750>
    1688:      	tbz	w17, #0x3, 0x1694 <_llm_rows.packet_batch.blocks+0x780>
    168c:      	add	x0, x16, #0xc
    1690:      	st1.s	{ v2 }[3], [x0]
    1694:      	ldp	q2, q4, [sp, #0x190]
    1698:      	fmul.4s	v2, v13, v2
    169c:      	fmul.4s	v2, v13, v2
    16a0:      	fmul.4s	v2, v13, v2
    16a4:      	fadd.4s	v2, v13, v2
    16a8:      	fmul.4s	v2, v2, v4
    16ac:      	and.16b	v2, v10, v2
    16b0:      	fabs.4s	v4, v2
    16b4:      	fmul.4s	v5, v2, v2
    16b8:      	ldp	q7, q6, [sp, #0x1b0]
    16bc:      	fmla.4s	v6, v5, v7
    16c0:      	ldr	q7, [sp, #0x1d0]
    16c4:      	fmla.4s	v7, v5, v6
    16c8:      	ldp	q6, q16, [sp, #0x1e0]
    16cc:      	fmla.4s	v6, v5, v7
    16d0:      	ldr	q7, [sp, #0x200]
    16d4:      	fmla.4s	v7, v5, v6
    16d8:      	mov.16b	v6, v3
    16dc:      	fmla.4s	v6, v5, v7
    16e0:      	mov.16b	v7, v0
    16e4:      	fmla.4s	v7, v5, v6
    16e8:      	fmul.4s	v6, v4, v7
    16ec:      	ldr	q7, [sp, #0x210]
    16f0:      	fmla.4s	v7, v5, v16
    16f4:      	ldr	q16, [sp, #0x220]
    16f8:      	fmla.4s	v16, v5, v7
    16fc:      	ldr	q7, [sp, #0x230]
    1700:      	fmla.4s	v7, v5, v16
    1704:      	mov.16b	v16, v23
    1708:      	fmla.4s	v16, v5, v7
    170c:      	movi.4s	v7, #0x3f, lsl #24
    1710:      	fmla.4s	v7, v5, v16
    1714:      	mov.16b	v16, v0
    1718:      	fmla.4s	v16, v5, v7
    171c:      	fdiv.4s	v5, v6, v16
    1720:      	fcmge.4s	v6, v28, v4
    1724:      	and.16b	v7, v6, v4
    1728:      	fcmge.4s	v16, v7, v30
    172c:      	fcmge.4s	v17, v1, v7
    1730:      	and.16b	v16, v16, v17
    1734:      	and.16b	v16, v16, v7
    1738:      	fmul.4s	v17, v16, v27
    173c:      	movi.4s	v18, #0x4b, lsl #24
    1740:      	fadd.4s	v17, v17, v18
    1744:      	movi.4s	v18, #0xcb, lsl #24
    1748:      	fadd.4s	v17, v17, v18
    174c:      	fcvtzs.4s	v17, v17
    1750:      	scvtf.4s	v18, v17
    1754:      	fmul.4s	v19, v18, v9
    1758:      	fadd.4s	v16, v16, v19
    175c:      	fmul.4s	v18, v18, v24
    1760:      	fadd.4s	v16, v16, v18
    1764:      	fmul.4s	v18, v16, v22
    1768:      	fadd.4s	v18, v18, v20
    176c:      	fmul.4s	v18, v16, v18
    1770:      	fadd.4s	v18, v18, v25
    1774:      	fmul.4s	v18, v16, v18
    1778:      	fadd.4s	v18, v18, v26
    177c:      	fmul.4s	v18, v16, v18
    1780:      	fadd.4s	v18, v18, v3
    1784:      	fmul.4s	v18, v16, v18
    1788:      	fadd.4s	v18, v18, v21
    178c:      	fmul.4s	v19, v16, v16
    1790:      	fmul.4s	v18, v19, v18
    1794:      	fadd.4s	v16, v16, v18
    1798:      	fadd.4s	v16, v16, v0
    179c:      	movi.2d	v18, #0xffffffffffffffff
    17a0:      	add.4s	v17, v17, v18
    17a4:      	sshr.4s	v18, v17, #0x1
    17a8:      	shl.4s	v19, v18, #0x17
    17ac:      	add.4s	v19, v19, v0
    17b0:      	fmul.4s	v16, v16, v19
    17b4:      	sub.4s	v17, v17, v18
    17b8:      	shl.4s	v17, v17, #0x17
    17bc:      	add.4s	v17, v17, v0
    17c0:      	fmul.4s	v16, v16, v17
    17c4:      	fcmgt.4s	v7, v7, v1
    17c8:      	ldr	q17, [sp, #0x180]
    17cc:      	bsl.16b	v7, v17, v16
    17d0:      	fdiv.4s	v16, v31, v7
    17d4:      	fsub.4s	v17, v7, v16
    17d8:      	fadd.4s	v7, v7, v16
    17dc:      	fdiv.4s	v7, v17, v7
    17e0:      	bsl.16b	v6, v7, v0
    17e4:      	fcmge.4s	v4, v0, v4
    17e8:      	bsl.16b	v4, v5, v6
    17ec:      	mvni.4s	v5, #0x80, lsl #24
    17f0:      	bif.16b	v4, v2, v5
    17f4:      	fcmeq.4s	v2, v2, v2
    17f8:      	fadd.4s	v4, v4, v0
    17fc:      	ldr	q5, [sp, #0x170]
    1800:      	bsl.16b	v2, v4, v5
    1804:      	fmul.4s	v4, v13, v21
    1808:      	fmul.4s	v2, v4, v2
    180c:      	fadd.4s	v2, v12, v2
    1810:      	tbz	w17, #0x4, 0x1830 <_llm_rows.packet_batch.blocks+0x91c>
    1814:      	str	s2, [x16, #0x10]
    1818:      	tbnz	w17, #0x5, 0x1834 <_llm_rows.packet_batch.blocks+0x920>
    181c:      	tbz	w17, #0x6, 0x1840 <_llm_rows.packet_batch.blocks+0x92c>
    1820:      	add	x0, x16, #0x18
    1824:      	st1.s	{ v2 }[2], [x0]
    1828:      	tbz	w17, #0x7, 0x138c <_llm_rows.packet_batch.blocks+0x478>
    182c:      	b	0x1844 <_llm_rows.packet_batch.blocks+0x930>
    1830:      	tbz	w17, #0x5, 0x181c <_llm_rows.packet_batch.blocks+0x908>
    1834:      	add	x0, x16, #0x14
    1838:      	st1.s	{ v2 }[1], [x0]
    183c:      	tbnz	w17, #0x6, 0x1820 <_llm_rows.packet_batch.blocks+0x90c>
    1840:      	tbz	w17, #0x7, 0x138c <_llm_rows.packet_batch.blocks+0x478>
    1844:      	add	x16, x16, #0x1c
    1848:      	st1.s	{ v2 }[3], [x16]
    184c:      	b	0x138c <_llm_rows.packet_batch.blocks+0x478>
    1850:      	mov	x10, #0x0               ; =0
    1854:      	add	x14, x11, x12
    1858:      	b	0x187c <_llm_rows.packet_batch.blocks+0x968>
    185c:      	add	x15, x23, x10
    1860:      	ldp	q6, q7, [x15]
    1864:      	bif.16b	v5, v7, v10
    1868:      	bif.16b	v4, v6, v11
    186c:      	stp	q4, q5, [x15]
    1870:      	add	x10, x10, #0x20
    1874:      	cmp	x10, #0x100
    1878:      	b.eq	0x1920 <_llm_rows.packet_batch.blocks+0xa0c>
    187c:      	ldr	q4, [sp, #0x120]
    1880:      	and.16b	v4, v2, v4
    1884:      	addv.8h	h15, v4
    1888:      	fmov	w16, s15
    188c:      	add	x15, x14, x10
    1890:      	movi.2d	v4, #0000000000000000
    1894:      	movi.2d	v5, #0000000000000000
    1898:      	tbz	w16, #0x0, 0x18dc <_llm_rows.packet_batch.blocks+0x9c8>
    189c:      	ldr	s4, [x15]
    18a0:      	and	w16, w16, #0xff
    18a4:      	tbnz	w16, #0x1, 0x18e4 <_llm_rows.packet_batch.blocks+0x9d0>
    18a8:      	tbz	w16, #0x2, 0x18f0 <_llm_rows.packet_batch.blocks+0x9dc>
    18ac:      	add	x17, x15, #0x8
    18b0:      	ld1.s	{ v4 }[2], [x17]
    18b4:      	tbnz	w16, #0x3, 0x18f4 <_llm_rows.packet_batch.blocks+0x9e0>
    18b8:      	tbz	w16, #0x4, 0x1900 <_llm_rows.packet_batch.blocks+0x9ec>
    18bc:      	add	x17, x15, #0x10
    18c0:      	ld1.s	{ v5 }[0], [x17]
    18c4:      	tbnz	w16, #0x5, 0x1904 <_llm_rows.packet_batch.blocks+0x9f0>
    18c8:      	tbz	w16, #0x6, 0x1910 <_llm_rows.packet_batch.blocks+0x9fc>
    18cc:      	add	x17, x15, #0x18
    18d0:      	ld1.s	{ v5 }[2], [x17]
    18d4:      	tbz	w16, #0x7, 0x185c <_llm_rows.packet_batch.blocks+0x948>
    18d8:      	b	0x1914 <_llm_rows.packet_batch.blocks+0xa00>
    18dc:      	and	w16, w16, #0xff
    18e0:      	tbz	w16, #0x1, 0x18a8 <_llm_rows.packet_batch.blocks+0x994>
    18e4:      	add	x17, x15, #0x4
    18e8:      	ld1.s	{ v4 }[1], [x17]
    18ec:      	tbnz	w16, #0x2, 0x18ac <_llm_rows.packet_batch.blocks+0x998>
    18f0:      	tbz	w16, #0x3, 0x18b8 <_llm_rows.packet_batch.blocks+0x9a4>
    18f4:      	add	x17, x15, #0xc
    18f8:      	ld1.s	{ v4 }[3], [x17]
    18fc:      	tbnz	w16, #0x4, 0x18bc <_llm_rows.packet_batch.blocks+0x9a8>
    1900:      	tbz	w16, #0x5, 0x18c8 <_llm_rows.packet_batch.blocks+0x9b4>
    1904:      	add	x17, x15, #0x14
    1908:      	ld1.s	{ v5 }[1], [x17]
    190c:      	tbnz	w16, #0x6, 0x18cc <_llm_rows.packet_batch.blocks+0x9b8>
    1910:      	tbz	w16, #0x7, 0x185c <_llm_rows.packet_batch.blocks+0x948>
    1914:      	add	x15, x15, #0x1c
    1918:      	ld1.s	{ v5 }[3], [x15]
    191c:      	b	0x185c <_llm_rows.packet_batch.blocks+0x948>
    1920:      	ldr	d2, [sp, #0x100]
    1924:      	uzp1.8b	v4, v2, v0
    1928:      	movi.2d	v5, #0000000000000000
    192c:      	mov.b	v5[0], v4[0]
    1930:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0xec>
    1934:      	ldr	d12, [x10]
    1938:      	and.8b	v2, v5, v12
    193c:      	addv.8b	b2, v2
    1940:      	fmov	w15, s2
    1944:      	str	q5, [sp, #0x100]
    1948:      	umaxv.8b	b2, v5
    194c:      	fmov	w16, s2
    1950:      	rbit	w10, w15
    1954:      	clz	w10, w10
    1958:      	tst	w16, #0x1
    195c:      	csel	w10, w10, wzr, ne
    1960:      	mov	w14, #0x40              ; =64
    1964:      	dup.2d	v2, x14
    1968:      	movi.2s	v5, #0x41
    196c:      	umlal.2d	v16, v17, v5
    1970:      	movi.2d	v5, #0000000000000000
    1974:      	mov.b	v5[0], v4[0]
    1978:      	add.2d	v6, v16, v2
    197c:      	ushll.2d	v4, v5, #0x0
    1980:      	shl.2d	v4, v4, #0x3f
    1984:      	cmlt.2d	v4, v4, #0
    1988:      	str	q6, [sp, #0x70]
    198c:      	and.16b	v4, v4, v6
    1990:      	movi.2d	v5, #0000000000000000
    1994:      	stp	q5, q5, [sp, #0x380]
    1998:      	stp	q4, q5, [sp, #0x360]
    199c:      	and	x14, x10, #0x7
    19a0:      	add	x17, sp, #0x360
    19a4:      	ldr	x14, [x17, x14, lsl #3]
    19a8:      	sub	x14, x14, x10
    19ac:      	lsl	x14, x14, #2
    19b0:      	add	x11, x11, x14
    19b4:      	movi.2d	v8, #0000000000000000
    19b8:      	movi.2d	v19, #0000000000000000
    19bc:      	tbz	w16, #0x0, 0x19fc <_llm_rows.packet_batch.blocks+0xae8>
    19c0:      	ldr	s8, [x11]
    19c4:      	tbnz	w15, #0x1, 0x1a00 <_llm_rows.packet_batch.blocks+0xaec>
    19c8:      	tbz	w15, #0x2, 0x1a0c <_llm_rows.packet_batch.blocks+0xaf8>
    19cc:      	add	x16, x11, #0x8
    19d0:      	ld1.s	{ v8 }[2], [x16]
    19d4:      	tbnz	w15, #0x3, 0x1a10 <_llm_rows.packet_batch.blocks+0xafc>
    19d8:      	tbz	w15, #0x4, 0x1a1c <_llm_rows.packet_batch.blocks+0xb08>
    19dc:      	add	x16, x11, #0x10
    19e0:      	ld1.s	{ v19 }[0], [x16]
    19e4:      	tbnz	w15, #0x5, 0x1a20 <_llm_rows.packet_batch.blocks+0xb0c>
    19e8:      	tbz	w15, #0x6, 0x1a2c <_llm_rows.packet_batch.blocks+0xb18>
    19ec:      	add	x16, x11, #0x18
    19f0:      	ld1.s	{ v19 }[2], [x16]
    19f4:      	tbnz	w15, #0x7, 0x1a30 <_llm_rows.packet_batch.blocks+0xb1c>
    19f8:      	b	0x1a38 <_llm_rows.packet_batch.blocks+0xb24>
    19fc:      	tbz	w15, #0x1, 0x19c8 <_llm_rows.packet_batch.blocks+0xab4>
    1a00:      	add	x16, x11, #0x4
    1a04:      	ld1.s	{ v8 }[1], [x16]
    1a08:      	tbnz	w15, #0x2, 0x19cc <_llm_rows.packet_batch.blocks+0xab8>
    1a0c:      	tbz	w15, #0x3, 0x19d8 <_llm_rows.packet_batch.blocks+0xac4>
    1a10:      	add	x16, x11, #0xc
    1a14:      	ld1.s	{ v8 }[3], [x16]
    1a18:      	tbnz	w15, #0x4, 0x19dc <_llm_rows.packet_batch.blocks+0xac8>
    1a1c:      	tbz	w15, #0x5, 0x19e8 <_llm_rows.packet_batch.blocks+0xad4>
    1a20:      	add	x16, x11, #0x14
    1a24:      	ld1.s	{ v19 }[1], [x16]
    1a28:      	tbnz	w15, #0x6, 0x19ec <_llm_rows.packet_batch.blocks+0xad8>
    1a2c:      	tbz	w15, #0x7, 0x1a38 <_llm_rows.packet_batch.blocks+0xb24>
    1a30:      	add	x11, x11, #0x1c
    1a34:      	ld1.s	{ v19 }[3], [x11]
    1a38:      	mov	x17, #0x0               ; =0
    1a3c:      	movi.2s	v4, #0x41
    1a40:      	ldr	q5, [sp, #0x150]
    1a44:      	ldr	d6, [sp, #0xe0]
    1a48:      	umlal.2d	v5, v6, v4
    1a4c:      	add.2d	v7, v5, v2
    1a50:      	ldr	q5, [sp, #0x160]
    1a54:      	ldr	d6, [sp, #0x130]
    1a58:      	umlal.2d	v5, v6, v4
    1a5c:      	add.2d	v5, v5, v2
    1a60:      	stp	q5, q7, [sp, #0x40]
    1a64:      	ldr	d5, [sp, #0x140]
    1a68:      	umlal.2d	v29, v5, v4
    1a6c:      	add.2d	v2, v29, v2
    1a70:      	str	q2, [sp, #0x30]
    1a74:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xec>
    1a78:      	ldr	q2, [x11]
    1a7c:      	mov	w11, #0x100             ; =256
    1a80:      	dup.2d	v4, x11
    1a84:      	sshll.2d	v5, v11, #0x0
    1a88:      	bif.16b	v2, v4, v5
    1a8c:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xec>
    1a90:      	ldr	q5, [x11]
    1a94:      	sshll.2d	v6, v10, #0x0
    1a98:      	bif.16b	v5, v4, v6
    1a9c:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xec>
    1aa0:      	ldr	q6, [x11]
    1aa4:      	bif.16b	v6, v4, v14
    1aa8:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xec>
    1aac:      	ldr	q7, [x11]
    1ab0:      	bit.16b	v4, v7, v13
    1ab4:      	stp	q5, q4, [sp, #0x340]
    1ab8:      	stp	q2, q6, [sp, #0x320]
    1abc:      	and	x11, x10, #0x7
    1ac0:      	add	x16, sp, #0x320
    1ac4:      	ldr	x11, [x16, x11, lsl #3]
    1ac8:      	sub	x11, x11, x10, lsl #2
    1acc:      	tst	w15, #0xff
    1ad0:      	csel	x15, xzr, x11, eq
    1ad4:      	add	x11, x23, x15
    1ad8:      	ldp	q2, q4, [x11]
    1adc:      	ldr	q6, [sp, #0x100]
    1ae0:      	zip2.8b	v5, v6, v0
    1ae4:      	ushll.4s	v5, v5, #0x0
    1ae8:      	shl.4s	v5, v5, #0x1f
    1aec:      	cmlt.4s	v5, v5, #0
    1af0:      	bit.16b	v4, v19, v5
    1af4:      	zip1.8b	v5, v6, v0
    1af8:      	ushll.4s	v5, v5, #0x0
    1afc:      	shl.4s	v5, v5, #0x1f
    1b00:      	cmlt.4s	v5, v5, #0
    1b04:      	bit.16b	v2, v8, v5
    1b08:      	stp	q2, q4, [x11]
    1b0c:      	add	x16, x9, x12
    1b10:      	ushll2.2d	v2, v10, #0x0
    1b14:      	mov	w11, #0x1               ; =1
    1b18:      	dup.2d	v4, x11
    1b1c:      	and.16b	v5, v2, v4
    1b20:      	ushll2.2d	v2, v11, #0x0
    1b24:      	and.16b	v2, v2, v4
    1b28:      	stp	q2, q5, [sp, #0x150]
    1b2c:      	ushll.2d	v2, v10, #0x0
    1b30:      	and.16b	v5, v2, v4
    1b34:      	ushll.2d	v2, v11, #0x0
    1b38:      	and.16b	v2, v2, v4
    1b3c:      	stp	q2, q5, [sp, #0x130]
    1b40:      	movi.2d	v2, #0000000000000000
    1b44:      	and	x11, x13, #0x1
    1b48:      	movi.2d	v4, #0000000000000000
    1b4c:      	movi.2d	v5, #0000000000000000
    1b50:      	movi.2d	v6, #0000000000000000
    1b54:      	b	0x1b9c <_llm_rows.packet_batch.blocks+0xc88>
    1b58:      	add	x13, x26, x13
    1b5c:      	ldp	q17, q18, [x13]
    1b60:      	bif.16b	v16, v18, v10
    1b64:      	bif.16b	v7, v17, v11
    1b68:      	stp	q7, q16, [x13]
    1b6c:      	ldr	q7, [sp, #0x130]
    1b70:      	add.2d	v7, v2, v7
    1b74:      	ldp	q16, q17, [sp, #0x140]
    1b78:      	add.2d	v4, v4, v17
    1b7c:      	add.2d	v5, v5, v16
    1b80:      	ldr	q16, [sp, #0x160]
    1b84:      	add.2d	v6, v6, v16
    1b88:      	fmov	x13, d2
    1b8c:      	add	x17, x13, x11
    1b90:      	mov.16b	v2, v7
    1b94:      	cmp	x17, #0x8
    1b98:      	b.ge	0x1c38 <_llm_rows.packet_batch.blocks+0xd24>
    1b9c:      	fmov	w0, s15
    1ba0:      	lsl	x13, x17, #5
    1ba4:      	add	x17, x16, x13
    1ba8:      	movi.2d	v7, #0000000000000000
    1bac:      	movi.2d	v16, #0000000000000000
    1bb0:      	tbz	w0, #0x0, 0x1bf4 <_llm_rows.packet_batch.blocks+0xce0>
    1bb4:      	ldr	s7, [x17]
    1bb8:      	and	w0, w0, #0xff
    1bbc:      	tbnz	w0, #0x1, 0x1bfc <_llm_rows.packet_batch.blocks+0xce8>
    1bc0:      	tbz	w0, #0x2, 0x1c08 <_llm_rows.packet_batch.blocks+0xcf4>
    1bc4:      	add	x1, x17, #0x8
    1bc8:      	ld1.s	{ v7 }[2], [x1]
    1bcc:      	tbnz	w0, #0x3, 0x1c0c <_llm_rows.packet_batch.blocks+0xcf8>
    1bd0:      	tbz	w0, #0x4, 0x1c18 <_llm_rows.packet_batch.blocks+0xd04>
    1bd4:      	add	x1, x17, #0x10
    1bd8:      	ld1.s	{ v16 }[0], [x1]
    1bdc:      	tbnz	w0, #0x5, 0x1c1c <_llm_rows.packet_batch.blocks+0xd08>
    1be0:      	tbz	w0, #0x6, 0x1c28 <_llm_rows.packet_batch.blocks+0xd14>
    1be4:      	add	x1, x17, #0x18
    1be8:      	ld1.s	{ v16 }[2], [x1]
    1bec:      	tbz	w0, #0x7, 0x1b58 <_llm_rows.packet_batch.blocks+0xc44>
    1bf0:      	b	0x1c2c <_llm_rows.packet_batch.blocks+0xd18>
    1bf4:      	and	w0, w0, #0xff
    1bf8:      	tbz	w0, #0x1, 0x1bc0 <_llm_rows.packet_batch.blocks+0xcac>
    1bfc:      	add	x1, x17, #0x4
    1c00:      	ld1.s	{ v7 }[1], [x1]
    1c04:      	tbnz	w0, #0x2, 0x1bc4 <_llm_rows.packet_batch.blocks+0xcb0>
    1c08:      	tbz	w0, #0x3, 0x1bd0 <_llm_rows.packet_batch.blocks+0xcbc>
    1c0c:      	add	x1, x17, #0xc
    1c10:      	ld1.s	{ v7 }[3], [x1]
    1c14:      	tbnz	w0, #0x4, 0x1bd4 <_llm_rows.packet_batch.blocks+0xcc0>
    1c18:      	tbz	w0, #0x5, 0x1be0 <_llm_rows.packet_batch.blocks+0xccc>
    1c1c:      	add	x1, x17, #0x14
    1c20:      	ld1.s	{ v16 }[1], [x1]
    1c24:      	tbnz	w0, #0x6, 0x1be4 <_llm_rows.packet_batch.blocks+0xcd0>
    1c28:      	tbz	w0, #0x7, 0x1b58 <_llm_rows.packet_batch.blocks+0xc44>
    1c2c:      	add	x17, x17, #0x1c
    1c30:      	ld1.s	{ v16 }[3], [x17]
    1c34:      	b	0x1b58 <_llm_rows.packet_batch.blocks+0xc44>
    1c38:      	add	x9, x9, x14
    1c3c:      	ldr	q2, [sp, #0x100]
    1c40:      	shl.8b	v2, v2, #0x7
    1c44:      	cmlt.8b	v2, v2, #0
    1c48:      	and.8b	v2, v2, v12
    1c4c:      	addv.8b	b2, v2
    1c50:      	str	d2, [sp, #0x8]
    1c54:      	fmov	w13, s2
    1c58:      	movi.2d	v16, #0000000000000000
    1c5c:      	movi.2d	v7, #0000000000000000
    1c60:      	tbz	w13, #0x0, 0x2118 <_llm_rows.packet_batch.blocks+0x1204>
    1c64:      	ldr	s16, [x9]
    1c68:      	tbnz	w13, #0x1, 0x211c <_llm_rows.packet_batch.blocks+0x1208>
    1c6c:      	tbz	w13, #0x2, 0x2128 <_llm_rows.packet_batch.blocks+0x1214>
    1c70:      	add	x14, x9, #0x8
    1c74:      	ld1.s	{ v16 }[2], [x14]
    1c78:      	tbnz	w13, #0x3, 0x212c <_llm_rows.packet_batch.blocks+0x1218>
    1c7c:      	tbz	w13, #0x4, 0x2138 <_llm_rows.packet_batch.blocks+0x1224>
    1c80:      	add	x14, x9, #0x10
    1c84:      	ld1.s	{ v7 }[0], [x14]
    1c88:      	tbnz	w13, #0x5, 0x213c <_llm_rows.packet_batch.blocks+0x1228>
    1c8c:      	tbz	w13, #0x6, 0x1c98 <_llm_rows.packet_batch.blocks+0xd84>
    1c90:      	add	x14, x9, #0x18
    1c94:      	ld1.s	{ v7 }[2], [x14]
    1c98:      	str	q8, [sp, #0x60]
    1c9c:      	str	q19, [sp, #0xe0]
    1ca0:      	mov.16b	v12, v23
    1ca4:      	mov.16b	v13, v28
    1ca8:      	mov.16b	v29, v20
    1cac:      	mov.16b	v14, v26
    1cb0:      	mov.16b	v26, v22
    1cb4:      	tbz	w13, #0x7, 0x1cc0 <_llm_rows.packet_batch.blocks+0xdac>
    1cb8:      	add	x9, x9, #0x1c
    1cbc:      	ld1.s	{ v7 }[3], [x9]
    1cc0:      	mov	x13, #0x0               ; =0
    1cc4:      	add	x9, x26, x15
    1cc8:      	ldp	q2, q4, [x9]
    1ccc:      	ldr	q6, [sp, #0x100]
    1cd0:      	zip2.8b	v5, v6, v0
    1cd4:      	ushll.4s	v5, v5, #0x0
    1cd8:      	shl.4s	v5, v5, #0x1f
    1cdc:      	cmlt.4s	v5, v5, #0
    1ce0:      	stp	q16, q7, [sp, #0x10]
    1ce4:      	bit.16b	v4, v7, v5
    1ce8:      	zip1.8b	v5, v6, v0
    1cec:      	ushll.4s	v5, v5, #0x0
    1cf0:      	shl.4s	v5, v5, #0x1f
    1cf4:      	cmlt.4s	v5, v5, #0
    1cf8:      	bit.16b	v2, v16, v5
    1cfc:      	stp	q2, q4, [x9]
    1d00:      	add	x9, x8, x12
    1d04:      	movi.2d	v2, #0000000000000000
    1d08:      	movi.2d	v4, #0000000000000000
    1d0c:      	movi.2d	v5, #0000000000000000
    1d10:      	movi.2d	v6, #0000000000000000
    1d14:      	b	0x1d48 <_llm_rows.packet_batch.blocks+0xe34>
    1d18:      	ldr	q7, [sp, #0x130]
    1d1c:      	add.2d	v7, v2, v7
    1d20:      	ldp	q16, q17, [sp, #0x140]
    1d24:      	add.2d	v4, v4, v17
    1d28:      	add.2d	v5, v5, v16
    1d2c:      	ldr	q16, [sp, #0x160]
    1d30:      	add.2d	v6, v6, v16
    1d34:      	fmov	x12, d2
    1d38:      	add	x13, x12, x11
    1d3c:      	mov.16b	v2, v7
    1d40:      	cmp	x13, #0x8
    1d44:      	b.ge	0x214c <_llm_rows.packet_batch.blocks+0x1238>
    1d48:      	lsl	x12, x13, #5
    1d4c:      	add	x13, x23, x12
    1d50:      	ldr	q7, [x13]
    1d54:      	and.16b	v7, v11, v7
    1d58:      	ldp	q16, q17, [sp, #0x190]
    1d5c:      	fmul.4s	v16, v7, v16
    1d60:      	fmul.4s	v16, v7, v16
    1d64:      	fmul.4s	v16, v7, v16
    1d68:      	fadd.4s	v16, v7, v16
    1d6c:      	fmul.4s	v16, v16, v17
    1d70:      	and.16b	v16, v11, v16
    1d74:      	fabs.4s	v17, v16
    1d78:      	fmul.4s	v18, v16, v16
    1d7c:      	ldp	q20, q19, [sp, #0x1b0]
    1d80:      	fmla.4s	v19, v18, v20
    1d84:      	ldr	q28, [sp, #0x1d0]
    1d88:      	fmla.4s	v28, v18, v19
    1d8c:      	ldp	q19, q20, [sp, #0x1e0]
    1d90:      	fmla.4s	v19, v18, v28
    1d94:      	ldr	q28, [sp, #0x200]
    1d98:      	fmla.4s	v28, v18, v19
    1d9c:      	mov.16b	v19, v3
    1da0:      	fmla.4s	v19, v18, v28
    1da4:      	mov.16b	v28, v0
    1da8:      	fmla.4s	v28, v18, v19
    1dac:      	fmul.4s	v19, v17, v28
    1db0:      	ldp	q28, q23, [sp, #0x210]
    1db4:      	fmla.4s	v28, v18, v20
    1db8:      	fmla.4s	v23, v18, v28
    1dbc:      	ldr	q28, [sp, #0x230]
    1dc0:      	fmla.4s	v28, v18, v23
    1dc4:      	mov.16b	v23, v12
    1dc8:      	fmla.4s	v23, v18, v28
    1dcc:      	movi.4s	v28, #0x3f, lsl #24
    1dd0:      	fmla.4s	v28, v18, v23
    1dd4:      	mov.16b	v23, v0
    1dd8:      	fmla.4s	v23, v18, v28
    1ddc:      	fdiv.4s	v18, v19, v23
    1de0:      	fcmge.4s	v19, v13, v17
    1de4:      	and.16b	v23, v19, v17
    1de8:      	mov.16b	v8, v30
    1dec:      	fcmge.4s	v28, v23, v30
    1df0:      	fcmge.4s	v30, v1, v23
    1df4:      	and.16b	v28, v28, v30
    1df8:      	and.16b	v28, v28, v23
    1dfc:      	fmul.4s	v30, v28, v27
    1e00:      	mov.16b	v22, v31
    1e04:      	movi.4s	v31, #0x4b, lsl #24
    1e08:      	fadd.4s	v30, v30, v31
    1e0c:      	movi.4s	v31, #0xcb, lsl #24
    1e10:      	fadd.4s	v30, v30, v31
    1e14:      	fcvtzs.4s	v30, v30
    1e18:      	scvtf.4s	v31, v30
    1e1c:      	mov.16b	v20, v9
    1e20:      	fmul.4s	v9, v31, v9
    1e24:      	fadd.4s	v28, v28, v9
    1e28:      	fmul.4s	v31, v31, v24
    1e2c:      	fadd.4s	v28, v28, v31
    1e30:      	fmul.4s	v31, v28, v26
    1e34:      	fadd.4s	v31, v31, v29
    1e38:      	fmul.4s	v31, v28, v31
    1e3c:      	fadd.4s	v31, v31, v25
    1e40:      	fmul.4s	v31, v28, v31
    1e44:      	fadd.4s	v31, v31, v14
    1e48:      	fmul.4s	v31, v28, v31
    1e4c:      	fadd.4s	v31, v31, v3
    1e50:      	fmul.4s	v31, v28, v31
    1e54:      	fadd.4s	v31, v31, v21
    1e58:      	fmul.4s	v9, v28, v28
    1e5c:      	fmul.4s	v31, v9, v31
    1e60:      	fadd.4s	v28, v28, v31
    1e64:      	fadd.4s	v28, v28, v0
    1e68:      	movi.2d	v31, #0xffffffffffffffff
    1e6c:      	add.4s	v30, v30, v31
    1e70:      	sshr.4s	v31, v30, #0x1
    1e74:      	shl.4s	v9, v31, #0x17
    1e78:      	add.4s	v9, v9, v0
    1e7c:      	fmul.4s	v28, v28, v9
    1e80:      	sub.4s	v30, v30, v31
    1e84:      	shl.4s	v30, v30, #0x17
    1e88:      	add.4s	v30, v30, v0
    1e8c:      	fmul.4s	v28, v28, v30
    1e90:      	fcmgt.4s	v23, v23, v1
    1e94:      	ldr	q30, [sp, #0x180]
    1e98:      	bsl.16b	v23, v30, v28
    1e9c:      	fdiv.4s	v28, v22, v23
    1ea0:      	fsub.4s	v30, v23, v28
    1ea4:      	fadd.4s	v23, v23, v28
    1ea8:      	fdiv.4s	v23, v30, v23
    1eac:      	bsl.16b	v19, v23, v0
    1eb0:      	fcmge.4s	v17, v0, v17
    1eb4:      	bsl.16b	v17, v18, v19
    1eb8:      	mvni.4s	v18, #0x80, lsl #24
    1ebc:      	bif.16b	v17, v16, v18
    1ec0:      	fcmeq.4s	v16, v16, v16
    1ec4:      	fadd.4s	v17, v17, v0
    1ec8:      	ldr	q18, [sp, #0x170]
    1ecc:      	bif.16b	v17, v18, v16
    1ed0:      	ldr	q16, [x13, #0x10]
    1ed4:      	fmul.4s	v7, v7, v21
    1ed8:      	fmul.4s	v7, v7, v17
    1edc:      	add	x13, x26, x12
    1ee0:      	ldr	q17, [x13]
    1ee4:      	and.16b	v17, v11, v17
    1ee8:      	fadd.4s	v17, v17, v7
    1eec:      	ldr	q7, [x13, #0x10]
    1ef0:      	fmov	w13, s15
    1ef4:      	add	x12, x9, x12
    1ef8:      	tbz	w13, #0x0, 0x1f1c <_llm_rows.packet_batch.blocks+0x1008>
    1efc:      	str	s17, [x12]
    1f00:      	and	w13, w13, #0xff
    1f04:      	tbnz	w13, #0x1, 0x1f24 <_llm_rows.packet_batch.blocks+0x1010>
    1f08:      	tbz	w13, #0x2, 0x1f30 <_llm_rows.packet_batch.blocks+0x101c>
    1f0c:      	add	x14, x12, #0x8
    1f10:      	st1.s	{ v17 }[2], [x14]
    1f14:      	tbnz	w13, #0x3, 0x1f34 <_llm_rows.packet_batch.blocks+0x1020>
    1f18:      	b	0x1f3c <_llm_rows.packet_batch.blocks+0x1028>
    1f1c:      	and	w13, w13, #0xff
    1f20:      	tbz	w13, #0x1, 0x1f08 <_llm_rows.packet_batch.blocks+0xff4>
    1f24:      	add	x14, x12, #0x4
    1f28:      	st1.s	{ v17 }[1], [x14]
    1f2c:      	tbnz	w13, #0x2, 0x1f0c <_llm_rows.packet_batch.blocks+0xff8>
    1f30:      	tbz	w13, #0x3, 0x1f3c <_llm_rows.packet_batch.blocks+0x1028>
    1f34:      	add	x14, x12, #0xc
    1f38:      	st1.s	{ v17 }[3], [x14]
    1f3c:      	and.16b	v16, v10, v16
    1f40:      	ldp	q17, q18, [sp, #0x190]
    1f44:      	fmul.4s	v17, v16, v17
    1f48:      	fmul.4s	v17, v16, v17
    1f4c:      	fmul.4s	v17, v16, v17
    1f50:      	fadd.4s	v17, v16, v17
    1f54:      	fmul.4s	v17, v17, v18
    1f58:      	and.16b	v17, v10, v17
    1f5c:      	fabs.4s	v18, v17
    1f60:      	fmul.4s	v19, v17, v17
    1f64:      	ldp	q21, q23, [sp, #0x1b0]
    1f68:      	fmla.4s	v23, v19, v21
    1f6c:      	ldr	q28, [sp, #0x1d0]
    1f70:      	fmla.4s	v28, v19, v23
    1f74:      	ldp	q23, q21, [sp, #0x1e0]
    1f78:      	fmla.4s	v23, v19, v28
    1f7c:      	ldr	q28, [sp, #0x200]
    1f80:      	fmla.4s	v28, v19, v23
    1f84:      	mov.16b	v23, v3
    1f88:      	fmla.4s	v23, v19, v28
    1f8c:      	mov.16b	v28, v0
    1f90:      	fmla.4s	v28, v19, v23
    1f94:      	fmul.4s	v23, v18, v28
    1f98:      	ldp	q28, q30, [sp, #0x210]
    1f9c:      	fmla.4s	v28, v19, v21
    1fa0:      	fmla.4s	v30, v19, v28
    1fa4:      	ldr	q28, [sp, #0x230]
    1fa8:      	fmla.4s	v28, v19, v30
    1fac:      	mov.16b	v30, v12
    1fb0:      	fmla.4s	v30, v19, v28
    1fb4:      	movi.4s	v28, #0x3f, lsl #24
    1fb8:      	fmla.4s	v28, v19, v30
    1fbc:      	mov.16b	v30, v0
    1fc0:      	fmla.4s	v30, v19, v28
    1fc4:      	fdiv.4s	v19, v23, v30
    1fc8:      	fcmge.4s	v23, v13, v18
    1fcc:      	and.16b	v28, v23, v18
    1fd0:      	fcmge.4s	v30, v28, v8
    1fd4:      	fcmge.4s	v31, v1, v28
    1fd8:      	and.16b	v30, v30, v31
    1fdc:      	and.16b	v30, v30, v28
    1fe0:      	fmul.4s	v31, v30, v27
    1fe4:      	movi.4s	v21, #0x4b, lsl #24
    1fe8:      	fadd.4s	v31, v31, v21
    1fec:      	movi.4s	v21, #0xcb, lsl #24
    1ff0:      	fadd.4s	v31, v31, v21
    1ff4:      	fcvtzs.4s	v31, v31
    1ff8:      	scvtf.4s	v9, v31
    1ffc:      	fmul.4s	v21, v9, v20
    2000:      	fadd.4s	v21, v30, v21
    2004:      	fmul.4s	v30, v9, v24
    2008:      	fadd.4s	v21, v21, v30
    200c:      	fmul.4s	v30, v21, v26
    2010:      	fadd.4s	v30, v30, v29
    2014:      	fmul.4s	v30, v21, v30
    2018:      	fadd.4s	v30, v30, v25
    201c:      	fmul.4s	v30, v21, v30
    2020:      	fadd.4s	v30, v30, v14
    2024:      	fmul.4s	v30, v21, v30
    2028:      	fadd.4s	v30, v30, v3
    202c:      	fmul.4s	v30, v21, v30
    2030:      	movi.4s	v9, #0x3f, lsl #24
    2034:      	fadd.4s	v30, v30, v9
    2038:      	fmul.4s	v9, v21, v21
    203c:      	fmul.4s	v30, v9, v30
    2040:      	fadd.4s	v21, v21, v30
    2044:      	fadd.4s	v21, v21, v0
    2048:      	movi.2d	v30, #0xffffffffffffffff
    204c:      	add.4s	v30, v31, v30
    2050:      	sshr.4s	v31, v30, #0x1
    2054:      	shl.4s	v9, v31, #0x17
    2058:      	add.4s	v9, v9, v0
    205c:      	fmul.4s	v21, v21, v9
    2060:      	sub.4s	v30, v30, v31
    2064:      	shl.4s	v30, v30, #0x17
    2068:      	add.4s	v30, v30, v0
    206c:      	fmul.4s	v21, v21, v30
    2070:      	fcmgt.4s	v28, v28, v1
    2074:      	ldr	q30, [sp, #0x180]
    2078:      	bit.16b	v21, v30, v28
    207c:      	mov.16b	v31, v22
    2080:      	fdiv.4s	v28, v22, v21
    2084:      	fsub.4s	v30, v21, v28
    2088:      	fadd.4s	v21, v21, v28
    208c:      	fdiv.4s	v21, v30, v21
    2090:      	bif.16b	v21, v0, v23
    2094:      	fcmge.4s	v18, v0, v18
    2098:      	bsl.16b	v18, v19, v21
    209c:      	movi.4s	v21, #0x3f, lsl #24
    20a0:      	mvni.4s	v19, #0x80, lsl #24
    20a4:      	bif.16b	v18, v17, v19
    20a8:      	fcmeq.4s	v17, v17, v17
    20ac:      	fadd.4s	v18, v18, v0
    20b0:      	ldr	q19, [sp, #0x170]
    20b4:      	bsl.16b	v17, v18, v19
    20b8:      	fmul.4s	v16, v16, v21
    20bc:      	fmul.4s	v16, v16, v17
    20c0:      	and.16b	v7, v10, v7
    20c4:      	fadd.4s	v7, v7, v16
    20c8:      	tbz	w13, #0x4, 0x20f0 <_llm_rows.packet_batch.blocks+0x11dc>
    20cc:      	str	s7, [x12, #0x10]
    20d0:      	tbnz	w13, #0x5, 0x20f4 <_llm_rows.packet_batch.blocks+0x11e0>
    20d4:      	mov.16b	v9, v20
    20d8:      	mov.16b	v30, v8
    20dc:      	tbz	w13, #0x6, 0x2108 <_llm_rows.packet_batch.blocks+0x11f4>
    20e0:      	add	x14, x12, #0x18
    20e4:      	st1.s	{ v7 }[2], [x14]
    20e8:      	tbz	w13, #0x7, 0x1d18 <_llm_rows.packet_batch.blocks+0xe04>
    20ec:      	b	0x210c <_llm_rows.packet_batch.blocks+0x11f8>
    20f0:      	tbz	w13, #0x5, 0x20d4 <_llm_rows.packet_batch.blocks+0x11c0>
    20f4:      	add	x14, x12, #0x14
    20f8:      	st1.s	{ v7 }[1], [x14]
    20fc:      	mov.16b	v9, v20
    2100:      	mov.16b	v30, v8
    2104:      	tbnz	w13, #0x6, 0x20e0 <_llm_rows.packet_batch.blocks+0x11cc>
    2108:      	tbz	w13, #0x7, 0x1d18 <_llm_rows.packet_batch.blocks+0xe04>
    210c:      	add	x12, x12, #0x1c
    2110:      	st1.s	{ v7 }[3], [x12]
    2114:      	b	0x1d18 <_llm_rows.packet_batch.blocks+0xe04>
    2118:      	tbz	w13, #0x1, 0x1c6c <_llm_rows.packet_batch.blocks+0xd58>
    211c:      	add	x14, x9, #0x4
    2120:      	ld1.s	{ v16 }[1], [x14]
    2124:      	tbnz	w13, #0x2, 0x1c70 <_llm_rows.packet_batch.blocks+0xd5c>
    2128:      	tbz	w13, #0x3, 0x1c7c <_llm_rows.packet_batch.blocks+0xd68>
    212c:      	add	x14, x9, #0xc
    2130:      	ld1.s	{ v16 }[3], [x14]
    2134:      	tbnz	w13, #0x4, 0x1c80 <_llm_rows.packet_batch.blocks+0xd6c>
    2138:      	tbz	w13, #0x5, 0x1c8c <_llm_rows.packet_batch.blocks+0xd78>
    213c:      	add	x14, x9, #0x14
    2140:      	ld1.s	{ v7 }[1], [x14]
    2144:      	tbnz	w13, #0x6, 0x1c90 <_llm_rows.packet_batch.blocks+0xd7c>
    2148:      	b	0x1c98 <_llm_rows.packet_batch.blocks+0xd84>
    214c:      	ldp	q2, q4, [sp, #0x190]
    2150:      	ldr	q20, [sp, #0x60]
    2154:      	fmul.4s	v2, v20, v2
    2158:      	fmul.4s	v2, v20, v2
    215c:      	fmul.4s	v2, v20, v2
    2160:      	fadd.4s	v2, v20, v2
    2164:      	fmul.4s	v2, v2, v4
    2168:      	ldr	q4, [sp, #0x100]
    216c:      	zip1.8b	v4, v4, v0
    2170:      	ushll.4s	v4, v4, #0x0
    2174:      	shl.4s	v4, v4, #0x1f
    2178:      	cmlt.4s	v4, v4, #0
    217c:      	and.16b	v2, v4, v2
    2180:      	fabs.4s	v4, v2
    2184:      	fmul.4s	v5, v2, v2
    2188:      	ldp	q7, q6, [sp, #0x1b0]
    218c:      	fmla.4s	v6, v5, v7
    2190:      	ldr	q7, [sp, #0x1d0]
    2194:      	fmla.4s	v7, v5, v6
    2198:      	ldp	q6, q16, [sp, #0x1e0]
    219c:      	fmla.4s	v6, v5, v7
    21a0:      	ldr	q7, [sp, #0x200]
    21a4:      	fmla.4s	v7, v5, v6
    21a8:      	mov.16b	v6, v3
    21ac:      	fmla.4s	v6, v5, v7
    21b0:      	mov.16b	v7, v0
    21b4:      	fmla.4s	v7, v5, v6
    21b8:      	fmul.4s	v6, v4, v7
    21bc:      	ldr	q7, [sp, #0x210]
    21c0:      	fmla.4s	v7, v5, v16
    21c4:      	ldr	q16, [sp, #0x220]
    21c8:      	fmla.4s	v16, v5, v7
    21cc:      	ldr	q7, [sp, #0x230]
    21d0:      	fmla.4s	v7, v5, v16
    21d4:      	mov.16b	v16, v12
    21d8:      	fmla.4s	v16, v5, v7
    21dc:      	movi.4s	v7, #0x3f, lsl #24
    21e0:      	fmla.4s	v7, v5, v16
    21e4:      	mov.16b	v16, v0
    21e8:      	fmla.4s	v16, v5, v7
    21ec:      	fdiv.4s	v5, v6, v16
    21f0:      	fcmge.4s	v6, v13, v4
    21f4:      	and.16b	v7, v6, v4
    21f8:      	fcmge.4s	v16, v7, v30
    21fc:      	fcmge.4s	v17, v1, v7
    2200:      	and.16b	v16, v16, v17
    2204:      	and.16b	v16, v16, v7
    2208:      	fmul.4s	v17, v16, v27
    220c:      	movi.4s	v18, #0x4b, lsl #24
    2210:      	fadd.4s	v17, v17, v18
    2214:      	movi.4s	v18, #0xcb, lsl #24
    2218:      	fadd.4s	v17, v17, v18
    221c:      	fcvtzs.4s	v17, v17
    2220:      	scvtf.4s	v18, v17
    2224:      	fmul.4s	v19, v18, v9
    2228:      	fadd.4s	v16, v16, v19
    222c:      	fmul.4s	v18, v18, v24
    2230:      	fadd.4s	v16, v16, v18
    2234:      	fmul.4s	v18, v16, v26
    2238:      	fadd.4s	v18, v18, v29
    223c:      	fmul.4s	v18, v16, v18
    2240:      	fadd.4s	v18, v18, v25
    2244:      	fmul.4s	v18, v16, v18
    2248:      	fadd.4s	v18, v18, v14
    224c:      	fmul.4s	v18, v16, v18
    2250:      	fadd.4s	v18, v18, v3
    2254:      	fmul.4s	v18, v16, v18
    2258:      	fadd.4s	v18, v18, v21
    225c:      	fmul.4s	v19, v16, v16
    2260:      	fmul.4s	v18, v19, v18
    2264:      	fadd.4s	v16, v16, v18
    2268:      	fadd.4s	v16, v16, v0
    226c:      	movi.2d	v18, #0xffffffffffffffff
    2270:      	add.4s	v17, v17, v18
    2274:      	sshr.4s	v18, v17, #0x1
    2278:      	shl.4s	v19, v18, #0x17
    227c:      	add.4s	v19, v19, v0
    2280:      	fmul.4s	v16, v16, v19
    2284:      	sub.4s	v17, v17, v18
    2288:      	shl.4s	v17, v17, #0x17
    228c:      	add.4s	v17, v17, v0
    2290:      	fmul.4s	v16, v16, v17
    2294:      	fcmgt.4s	v7, v7, v1
    2298:      	ldr	q17, [sp, #0x180]
    229c:      	bsl.16b	v7, v17, v16
    22a0:      	fdiv.4s	v16, v31, v7
    22a4:      	fsub.4s	v17, v7, v16
    22a8:      	fadd.4s	v7, v7, v16
    22ac:      	fdiv.4s	v7, v17, v7
    22b0:      	bsl.16b	v6, v7, v0
    22b4:      	fcmge.4s	v4, v0, v4
    22b8:      	bsl.16b	v4, v5, v6
    22bc:      	ldr	d5, [sp, #0x8]
    22c0:      	fmov	w9, s5
    22c4:      	mvni.4s	v5, #0x80, lsl #24
    22c8:      	bif.16b	v4, v2, v5
    22cc:      	fcmeq.4s	v2, v2, v2
    22d0:      	fadd.4s	v4, v4, v0
    22d4:      	ldr	q5, [sp, #0x170]
    22d8:      	bsl.16b	v2, v4, v5
    22dc:      	fmul.4s	v4, v20, v21
    22e0:      	fmul.4s	v2, v4, v2
    22e4:      	ldr	q4, [sp, #0x10]
    22e8:      	fadd.4s	v2, v2, v4
    22ec:      	ldr	q5, [sp, #0x70]
    22f0:      	ldp	q7, q6, [sp, #0x40]
    22f4:      	stp	q5, q6, [sp, #0x2d0]
    22f8:      	ldr	q4, [sp, #0x30]
    22fc:      	stp	q7, q4, [sp, #0x2f0]
    2300:      	and	x11, x10, #0x7
    2304:      	add	x12, sp, #0x2d0
    2308:      	ldr	x11, [x12, x11, lsl #3]
    230c:      	sub	x10, x11, x10
    2310:      	add	x8, x8, x10, lsl #2
    2314:      	tbz	w9, #0x0, 0x2334 <_llm_rows.packet_batch.blocks+0x1420>
    2318:      	str	s2, [x8]
    231c:      	tbnz	w9, #0x1, 0x2338 <_llm_rows.packet_batch.blocks+0x1424>
    2320:      	tbz	w9, #0x2, 0x2344 <_llm_rows.packet_batch.blocks+0x1430>
    2324:      	add	x10, x8, #0x8
    2328:      	st1.s	{ v2 }[2], [x10]
    232c:      	tbnz	w9, #0x3, 0x2348 <_llm_rows.packet_batch.blocks+0x1434>
    2330:      	b	0x2350 <_llm_rows.packet_batch.blocks+0x143c>
    2334:      	tbz	w9, #0x1, 0x2320 <_llm_rows.packet_batch.blocks+0x140c>
    2338:      	add	x10, x8, #0x4
    233c:      	st1.s	{ v2 }[1], [x10]
    2340:      	tbnz	w9, #0x2, 0x2324 <_llm_rows.packet_batch.blocks+0x1410>
    2344:      	tbz	w9, #0x3, 0x2350 <_llm_rows.packet_batch.blocks+0x143c>
    2348:      	add	x10, x8, #0xc
    234c:      	st1.s	{ v2 }[3], [x10]
    2350:      	ldp	q2, q4, [sp, #0x190]
    2354:      	ldr	q20, [sp, #0xe0]
    2358:      	fmul.4s	v2, v20, v2
    235c:      	fmul.4s	v2, v20, v2
    2360:      	fmul.4s	v2, v20, v2
    2364:      	fadd.4s	v2, v20, v2
    2368:      	fmul.4s	v2, v2, v4
    236c:      	ldr	q4, [sp, #0x100]
    2370:      	zip2.8b	v4, v4, v0
    2374:      	ushll.4s	v4, v4, #0x0
    2378:      	shl.4s	v4, v4, #0x1f
    237c:      	cmlt.4s	v4, v4, #0
    2380:      	and.16b	v2, v4, v2
    2384:      	fmul.4s	v4, v2, v2
    2388:      	ldp	q6, q5, [sp, #0x1b0]
    238c:      	fmla.4s	v5, v4, v6
    2390:      	ldr	q6, [sp, #0x1d0]
    2394:      	fmla.4s	v6, v4, v5
    2398:      	ldp	q5, q7, [sp, #0x1e0]
    239c:      	fmla.4s	v5, v4, v6
    23a0:      	ldr	q6, [sp, #0x200]
    23a4:      	fmla.4s	v6, v4, v5
    23a8:      	mov.16b	v5, v3
    23ac:      	fmla.4s	v5, v4, v6
    23b0:      	mov.16b	v6, v0
    23b4:      	fmla.4s	v6, v4, v5
    23b8:      	ldr	q5, [sp, #0x210]
    23bc:      	fmla.4s	v5, v4, v7
    23c0:      	ldr	q7, [sp, #0x220]
    23c4:      	fmla.4s	v7, v4, v5
    23c8:      	ldr	q5, [sp, #0x230]
    23cc:      	fmla.4s	v5, v4, v7
    23d0:      	fmla.4s	v12, v4, v5
    23d4:      	movi.4s	v5, #0x3f, lsl #24
    23d8:      	fmla.4s	v5, v4, v12
    23dc:      	mov.16b	v7, v0
    23e0:      	fmla.4s	v7, v4, v5
    23e4:      	fabs.4s	v4, v2
    23e8:      	fmul.4s	v5, v4, v6
    23ec:      	fdiv.4s	v5, v5, v7
    23f0:      	fcmge.4s	v6, v13, v4
    23f4:      	and.16b	v7, v6, v4
    23f8:      	fcmge.4s	v16, v7, v30
    23fc:      	fcmge.4s	v17, v1, v7
    2400:      	and.16b	v16, v16, v17
    2404:      	and.16b	v16, v16, v7
    2408:      	fmul.4s	v17, v16, v27
    240c:      	movi.4s	v18, #0x4b, lsl #24
    2410:      	fadd.4s	v17, v17, v18
    2414:      	movi.4s	v18, #0xcb, lsl #24
    2418:      	fadd.4s	v17, v17, v18
    241c:      	fcvtzs.4s	v17, v17
    2420:      	scvtf.4s	v18, v17
    2424:      	fmul.4s	v19, v18, v9
    2428:      	fadd.4s	v16, v16, v19
    242c:      	fmul.4s	v18, v18, v24
    2430:      	fadd.4s	v16, v16, v18
    2434:      	fmul.4s	v18, v16, v26
    2438:      	fadd.4s	v18, v18, v29
    243c:      	fmul.4s	v18, v16, v18
    2440:      	fadd.4s	v18, v18, v25
    2444:      	fmul.4s	v18, v16, v18
    2448:      	fadd.4s	v18, v18, v14
    244c:      	fmul.4s	v18, v16, v18
    2450:      	fadd.4s	v3, v18, v3
    2454:      	fmul.4s	v3, v16, v3
    2458:      	fadd.4s	v3, v3, v21
    245c:      	fmul.4s	v18, v16, v16
    2460:      	fmul.4s	v3, v18, v3
    2464:      	fadd.4s	v3, v16, v3
    2468:      	fadd.4s	v3, v3, v0
    246c:      	movi.2d	v16, #0xffffffffffffffff
    2470:      	add.4s	v16, v17, v16
    2474:      	sshr.4s	v17, v16, #0x1
    2478:      	shl.4s	v18, v17, #0x17
    247c:      	add.4s	v18, v18, v0
    2480:      	fmul.4s	v3, v3, v18
    2484:      	sub.4s	v16, v16, v17
    2488:      	shl.4s	v16, v16, #0x17
    248c:      	add.4s	v16, v16, v0
    2490:      	fmul.4s	v3, v3, v16
    2494:      	fcmgt.4s	v1, v7, v1
    2498:      	ldr	q7, [sp, #0x180]
    249c:      	bsl.16b	v1, v7, v3
    24a0:      	fdiv.4s	v3, v31, v1
    24a4:      	fsub.4s	v7, v1, v3
    24a8:      	fadd.4s	v1, v1, v3
    24ac:      	fdiv.4s	v1, v7, v1
    24b0:      	bif.16b	v1, v0, v6
    24b4:      	fcmge.4s	v3, v0, v4
    24b8:      	bit.16b	v1, v5, v3
    24bc:      	mvni.4s	v3, #0x80, lsl #24
    24c0:      	bif.16b	v1, v2, v3
    24c4:      	fadd.4s	v0, v1, v0
    24c8:      	fcmeq.4s	v1, v2, v2
    24cc:      	ldr	q2, [sp, #0x170]
    24d0:      	bif.16b	v0, v2, v1
    24d4:      	fmul.4s	v1, v20, v21
    24d8:      	fmul.4s	v0, v1, v0
    24dc:      	ldr	q1, [sp, #0x20]
    24e0:      	fadd.4s	v0, v0, v1
    24e4:      	tbz	w9, #0x4, 0x2a7c <_llm_rows.packet_batch.blocks+0x1b68>
    24e8:      	str	s0, [x8, #0x10]
    24ec:      	tbnz	w9, #0x5, 0x2a80 <_llm_rows.packet_batch.blocks+0x1b6c>
    24f0:      	tbz	w9, #0x6, 0x2a8c <_llm_rows.packet_batch.blocks+0x1b78>
    24f4:      	add	x10, x8, #0x18
    24f8:      	st1.s	{ v0 }[2], [x10]
    24fc:      	tbnz	w9, #0x7, 0x2a90 <_llm_rows.packet_batch.blocks+0x1b7c>
    2500:      	b	0xfe4 <_llm_rows.packet_batch.blocks+0xd0>
    2504:      	ldr	d2, [sp, #0x100]
    2508:      	uzp1.8b	v4, v2, v0
    250c:      	movi.2d	v10, #0000000000000000
    2510:      	mov.b	v10[0], v4[0]
    2514:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x10ec>
    2518:      	ldr	d2, [x10]
    251c:      	and.8b	v5, v10, v2
    2520:      	addv.8b	b5, v5
    2524:      	fmov	w12, s5
    2528:      	umaxv.8b	b5, v10
    252c:      	fmov	w14, s5
    2530:      	rbit	w10, w12
    2534:      	clz	w10, w10
    2538:      	tst	w14, #0x1
    253c:      	csel	w10, w10, wzr, ne
    2540:      	mov	w13, #0x40              ; =64
    2544:      	dup.2d	v12, x13
    2548:      	movi.2s	v5, #0x41
    254c:      	ldr	q6, [sp, #0x70]
    2550:      	ldr	d7, [sp, #0x60]
    2554:      	umlal.2d	v6, v7, v5
    2558:      	movi.2d	v5, #0000000000000000
    255c:      	mov.b	v5[0], v4[0]
    2560:      	add.2d	v6, v6, v12
    2564:      	ushll.2d	v4, v5, #0x0
    2568:      	shl.2d	v4, v4, #0x3f
    256c:      	cmlt.2d	v4, v4, #0
    2570:      	str	q6, [sp, #0x100]
    2574:      	and.16b	v4, v4, v6
    2578:      	movi.2d	v5, #0000000000000000
    257c:      	stp	q5, q5, [sp, #0x2a0]
    2580:      	stp	q4, q5, [sp, #0x280]
    2584:      	and	x13, x10, #0x7
    2588:      	add	x15, sp, #0x280
    258c:      	ldr	x13, [x15, x13, lsl #3]
    2590:      	sub	x13, x13, x10
    2594:      	lsl	x13, x13, #2
    2598:      	add	x11, x11, x13
    259c:      	movi.2d	v14, #0000000000000000
    25a0:      	movi.2d	v8, #0000000000000000
    25a4:      	tbz	w14, #0x0, 0x25e4 <_llm_rows.packet_batch.blocks+0x16d0>
    25a8:      	ldr	s14, [x11]
    25ac:      	tbnz	w12, #0x1, 0x25e8 <_llm_rows.packet_batch.blocks+0x16d4>
    25b0:      	tbz	w12, #0x2, 0x25f4 <_llm_rows.packet_batch.blocks+0x16e0>
    25b4:      	add	x14, x11, #0x8
    25b8:      	ld1.s	{ v14 }[2], [x14]
    25bc:      	tbnz	w12, #0x3, 0x25f8 <_llm_rows.packet_batch.blocks+0x16e4>
    25c0:      	tbz	w12, #0x4, 0x2604 <_llm_rows.packet_batch.blocks+0x16f0>
    25c4:      	add	x14, x11, #0x10
    25c8:      	ld1.s	{ v8 }[0], [x14]
    25cc:      	tbnz	w12, #0x5, 0x2608 <_llm_rows.packet_batch.blocks+0x16f4>
    25d0:      	tbz	w12, #0x6, 0x2614 <_llm_rows.packet_batch.blocks+0x1700>
    25d4:      	add	x14, x11, #0x18
    25d8:      	ld1.s	{ v8 }[2], [x14]
    25dc:      	tbnz	w12, #0x7, 0x2618 <_llm_rows.packet_batch.blocks+0x1704>
    25e0:      	b	0x2620 <_llm_rows.packet_batch.blocks+0x170c>
    25e4:      	tbz	w12, #0x1, 0x25b0 <_llm_rows.packet_batch.blocks+0x169c>
    25e8:      	add	x14, x11, #0x4
    25ec:      	ld1.s	{ v14 }[1], [x14]
    25f0:      	tbnz	w12, #0x2, 0x25b4 <_llm_rows.packet_batch.blocks+0x16a0>
    25f4:      	tbz	w12, #0x3, 0x25c0 <_llm_rows.packet_batch.blocks+0x16ac>
    25f8:      	add	x14, x11, #0xc
    25fc:      	ld1.s	{ v14 }[3], [x14]
    2600:      	tbnz	w12, #0x4, 0x25c4 <_llm_rows.packet_batch.blocks+0x16b0>
    2604:      	tbz	w12, #0x5, 0x25d0 <_llm_rows.packet_batch.blocks+0x16bc>
    2608:      	add	x14, x11, #0x14
    260c:      	ld1.s	{ v8 }[1], [x14]
    2610:      	tbnz	w12, #0x6, 0x25d4 <_llm_rows.packet_batch.blocks+0x16c0>
    2614:      	tbz	w12, #0x7, 0x2620 <_llm_rows.packet_batch.blocks+0x170c>
    2618:      	add	x11, x11, #0x1c
    261c:      	ld1.s	{ v8 }[3], [x11]
    2620:      	shl.8b	v4, v10, #0x7
    2624:      	cmlt.8b	v4, v4, #0
    2628:      	and.8b	v2, v4, v2
    262c:      	addv.8b	b2, v2
    2630:      	str	d2, [sp, #0x70]
    2634:      	fmov	w11, s2
    2638:      	add	x9, x9, x13
    263c:      	movi.2d	v4, #0000000000000000
    2640:      	movi.2d	v13, #0000000000000000
    2644:      	tbz	w11, #0x0, 0x28a0 <_llm_rows.packet_batch.blocks+0x198c>
    2648:      	ldr	s4, [x9]
    264c:      	tbnz	w11, #0x1, 0x28a4 <_llm_rows.packet_batch.blocks+0x1990>
    2650:      	tbz	w11, #0x2, 0x28b0 <_llm_rows.packet_batch.blocks+0x199c>
    2654:      	add	x12, x9, #0x8
    2658:      	ld1.s	{ v4 }[2], [x12]
    265c:      	tbnz	w11, #0x3, 0x28b4 <_llm_rows.packet_batch.blocks+0x19a0>
    2660:      	tbz	w11, #0x4, 0x28c0 <_llm_rows.packet_batch.blocks+0x19ac>
    2664:      	add	x12, x9, #0x10
    2668:      	ld1.s	{ v13 }[0], [x12]
    266c:      	tbnz	w11, #0x5, 0x28c4 <_llm_rows.packet_batch.blocks+0x19b0>
    2670:      	tbz	w11, #0x6, 0x267c <_llm_rows.packet_batch.blocks+0x1768>
    2674:      	add	x12, x9, #0x18
    2678:      	ld1.s	{ v13 }[2], [x12]
    267c:      	movi.2s	v5, #0x41
    2680:      	ldr	q2, [sp, #0x150]
    2684:      	ldr	d6, [sp, #0xe0]
    2688:      	umlal.2d	v2, v6, v5
    268c:      	str	q2, [sp, #0x150]
    2690:      	ldr	q2, [sp, #0x160]
    2694:      	ldr	d6, [sp, #0x130]
    2698:      	umlal.2d	v2, v6, v5
    269c:      	str	q2, [sp, #0x160]
    26a0:      	ldr	d2, [sp, #0x140]
    26a4:      	umlal.2d	v29, v2, v5
    26a8:      	mov.16b	v2, v29
    26ac:      	tbz	w11, #0x7, 0x26b8 <_llm_rows.packet_batch.blocks+0x17a4>
    26b0:      	add	x9, x9, #0x1c
    26b4:      	ld1.s	{ v13 }[3], [x9]
    26b8:      	ldp	q5, q6, [sp, #0x190]
    26bc:      	fmul.4s	v5, v14, v5
    26c0:      	fmul.4s	v5, v14, v5
    26c4:      	fmul.4s	v5, v14, v5
    26c8:      	fadd.4s	v5, v14, v5
    26cc:      	fmul.4s	v5, v5, v6
    26d0:      	zip1.8b	v6, v10, v0
    26d4:      	ushll.4s	v6, v6, #0x0
    26d8:      	shl.4s	v6, v6, #0x1f
    26dc:      	cmlt.4s	v6, v6, #0
    26e0:      	and.16b	v5, v6, v5
    26e4:      	fabs.4s	v6, v5
    26e8:      	fmul.4s	v7, v5, v5
    26ec:      	ldp	q17, q16, [sp, #0x1b0]
    26f0:      	fmla.4s	v16, v7, v17
    26f4:      	ldr	q17, [sp, #0x1d0]
    26f8:      	fmla.4s	v17, v7, v16
    26fc:      	ldp	q16, q18, [sp, #0x1e0]
    2700:      	fmla.4s	v16, v7, v17
    2704:      	ldr	q17, [sp, #0x200]
    2708:      	fmla.4s	v17, v7, v16
    270c:      	mov.16b	v16, v3
    2710:      	fmla.4s	v16, v7, v17
    2714:      	mov.16b	v17, v0
    2718:      	fmla.4s	v17, v7, v16
    271c:      	fmul.4s	v16, v6, v17
    2720:      	ldr	q17, [sp, #0x210]
    2724:      	fmla.4s	v17, v7, v18
    2728:      	ldr	q18, [sp, #0x220]
    272c:      	fmla.4s	v18, v7, v17
    2730:      	ldr	q17, [sp, #0x230]
    2734:      	fmla.4s	v17, v7, v18
    2738:      	mov.16b	v29, v23
    273c:      	mov.16b	v18, v23
    2740:      	fmla.4s	v18, v7, v17
    2744:      	movi.4s	v17, #0x3f, lsl #24
    2748:      	fmla.4s	v17, v7, v18
    274c:      	mov.16b	v18, v0
    2750:      	fmla.4s	v18, v7, v17
    2754:      	fdiv.4s	v7, v16, v18
    2758:      	fcmge.4s	v16, v28, v6
    275c:      	and.16b	v17, v16, v6
    2760:      	fcmge.4s	v18, v17, v30
    2764:      	fcmge.4s	v19, v1, v17
    2768:      	and.16b	v18, v18, v19
    276c:      	and.16b	v18, v18, v17
    2770:      	fmul.4s	v19, v18, v27
    2774:      	movi.4s	v23, #0x4b, lsl #24
    2778:      	fadd.4s	v19, v19, v23
    277c:      	movi.4s	v23, #0xcb, lsl #24
    2780:      	fadd.4s	v19, v19, v23
    2784:      	fcvtzs.4s	v19, v19
    2788:      	scvtf.4s	v15, v19
    278c:      	fmul.4s	v11, v15, v9
    2790:      	fadd.4s	v18, v18, v11
    2794:      	fmul.4s	v11, v15, v24
    2798:      	fadd.4s	v18, v18, v11
    279c:      	fmul.4s	v11, v18, v22
    27a0:      	fadd.4s	v11, v11, v20
    27a4:      	fmul.4s	v11, v18, v11
    27a8:      	fadd.4s	v11, v11, v25
    27ac:      	fmul.4s	v11, v18, v11
    27b0:      	fadd.4s	v11, v11, v26
    27b4:      	fmul.4s	v11, v18, v11
    27b8:      	fadd.4s	v11, v11, v3
    27bc:      	fmul.4s	v11, v18, v11
    27c0:      	fadd.4s	v11, v11, v21
    27c4:      	fmul.4s	v15, v18, v18
    27c8:      	fmul.4s	v11, v15, v11
    27cc:      	fadd.4s	v18, v18, v11
    27d0:      	fadd.4s	v18, v18, v0
    27d4:      	movi.2d	v23, #0xffffffffffffffff
    27d8:      	add.4s	v19, v19, v23
    27dc:      	sshr.4s	v11, v19, #0x1
    27e0:      	shl.4s	v15, v11, #0x17
    27e4:      	add.4s	v15, v15, v0
    27e8:      	fmul.4s	v18, v18, v15
    27ec:      	sub.4s	v19, v19, v11
    27f0:      	shl.4s	v19, v19, #0x17
    27f4:      	add.4s	v19, v19, v0
    27f8:      	fmul.4s	v18, v18, v19
    27fc:      	fcmgt.4s	v17, v17, v1
    2800:      	ldr	q19, [sp, #0x180]
    2804:      	bsl.16b	v17, v19, v18
    2808:      	fdiv.4s	v18, v31, v17
    280c:      	fsub.4s	v19, v17, v18
    2810:      	fadd.4s	v17, v17, v18
    2814:      	fdiv.4s	v17, v19, v17
    2818:      	bsl.16b	v16, v17, v0
    281c:      	fcmge.4s	v6, v0, v6
    2820:      	bsl.16b	v6, v7, v16
    2824:      	ldp	q7, q16, [sp, #0x150]
    2828:      	add.2d	v7, v7, v12
    282c:      	add.2d	v16, v16, v12
    2830:      	add.2d	v17, v2, v12
    2834:      	mvni.4s	v18, #0x80, lsl #24
    2838:      	bif.16b	v6, v5, v18
    283c:      	fcmeq.4s	v5, v5, v5
    2840:      	fadd.4s	v6, v6, v0
    2844:      	ldr	q18, [sp, #0x170]
    2848:      	bsl.16b	v5, v6, v18
    284c:      	fmul.4s	v6, v14, v21
    2850:      	fmul.4s	v5, v6, v5
    2854:      	fadd.4s	v4, v4, v5
    2858:      	ldr	q2, [sp, #0x100]
    285c:      	stp	q2, q7, [sp, #0x240]
    2860:      	stp	q16, q17, [sp, #0x260]
    2864:      	ldr	d2, [sp, #0x70]
    2868:      	fmov	w9, s2
    286c:      	and	x11, x10, #0x7
    2870:      	add	x12, sp, #0x240
    2874:      	ldr	x11, [x12, x11, lsl #3]
    2878:      	sub	x10, x11, x10
    287c:      	add	x8, x8, x10, lsl #2
    2880:      	tbz	w9, #0x0, 0x28d4 <_llm_rows.packet_batch.blocks+0x19c0>
    2884:      	str	s4, [x8]
    2888:      	tbnz	w9, #0x1, 0x28d8 <_llm_rows.packet_batch.blocks+0x19c4>
    288c:      	tbz	w9, #0x2, 0x28e4 <_llm_rows.packet_batch.blocks+0x19d0>
    2890:      	add	x10, x8, #0x8
    2894:      	st1.s	{ v4 }[2], [x10]
    2898:      	tbnz	w9, #0x3, 0x28e8 <_llm_rows.packet_batch.blocks+0x19d4>
    289c:      	b	0x28f0 <_llm_rows.packet_batch.blocks+0x19dc>
    28a0:      	tbz	w11, #0x1, 0x2650 <_llm_rows.packet_batch.blocks+0x173c>
    28a4:      	add	x12, x9, #0x4
    28a8:      	ld1.s	{ v4 }[1], [x12]
    28ac:      	tbnz	w11, #0x2, 0x2654 <_llm_rows.packet_batch.blocks+0x1740>
    28b0:      	tbz	w11, #0x3, 0x2660 <_llm_rows.packet_batch.blocks+0x174c>
    28b4:      	add	x12, x9, #0xc
    28b8:      	ld1.s	{ v4 }[3], [x12]
    28bc:      	tbnz	w11, #0x4, 0x2664 <_llm_rows.packet_batch.blocks+0x1750>
    28c0:      	tbz	w11, #0x5, 0x2670 <_llm_rows.packet_batch.blocks+0x175c>
    28c4:      	add	x12, x9, #0x14
    28c8:      	ld1.s	{ v13 }[1], [x12]
    28cc:      	tbnz	w11, #0x6, 0x2674 <_llm_rows.packet_batch.blocks+0x1760>
    28d0:      	b	0x267c <_llm_rows.packet_batch.blocks+0x1768>
    28d4:      	tbz	w9, #0x1, 0x288c <_llm_rows.packet_batch.blocks+0x1978>
    28d8:      	add	x10, x8, #0x4
    28dc:      	st1.s	{ v4 }[1], [x10]
    28e0:      	tbnz	w9, #0x2, 0x2890 <_llm_rows.packet_batch.blocks+0x197c>
    28e4:      	tbz	w9, #0x3, 0x28f0 <_llm_rows.packet_batch.blocks+0x19dc>
    28e8:      	add	x10, x8, #0xc
    28ec:      	st1.s	{ v4 }[3], [x10]
    28f0:      	ldp	q2, q4, [sp, #0x190]
    28f4:      	fmul.4s	v2, v8, v2
    28f8:      	fmul.4s	v2, v8, v2
    28fc:      	fmul.4s	v2, v8, v2
    2900:      	fadd.4s	v2, v8, v2
    2904:      	fmul.4s	v2, v2, v4
    2908:      	zip2.8b	v4, v10, v0
    290c:      	ushll.4s	v4, v4, #0x0
    2910:      	shl.4s	v4, v4, #0x1f
    2914:      	cmlt.4s	v4, v4, #0
    2918:      	and.16b	v2, v4, v2
    291c:      	fmul.4s	v4, v2, v2
    2920:      	ldp	q6, q5, [sp, #0x1b0]
    2924:      	fmla.4s	v5, v4, v6
    2928:      	ldr	q6, [sp, #0x1d0]
    292c:      	fmla.4s	v6, v4, v5
    2930:      	ldp	q5, q7, [sp, #0x1e0]
    2934:      	fmla.4s	v5, v4, v6
    2938:      	ldr	q6, [sp, #0x200]
    293c:      	fmla.4s	v6, v4, v5
    2940:      	mov.16b	v5, v3
    2944:      	fmla.4s	v5, v4, v6
    2948:      	mov.16b	v6, v0
    294c:      	fmla.4s	v6, v4, v5
    2950:      	ldr	q5, [sp, #0x210]
    2954:      	fmla.4s	v5, v4, v7
    2958:      	ldr	q7, [sp, #0x220]
    295c:      	fmla.4s	v7, v4, v5
    2960:      	ldr	q5, [sp, #0x230]
    2964:      	fmla.4s	v5, v4, v7
    2968:      	fmla.4s	v29, v4, v5
    296c:      	movi.4s	v5, #0x3f, lsl #24
    2970:      	fmla.4s	v5, v4, v29
    2974:      	mov.16b	v7, v0
    2978:      	fmla.4s	v7, v4, v5
    297c:      	fabs.4s	v4, v2
    2980:      	fmul.4s	v5, v4, v6
    2984:      	fdiv.4s	v5, v5, v7
    2988:      	fcmge.4s	v6, v28, v4
    298c:      	and.16b	v7, v6, v4
    2990:      	fcmge.4s	v16, v7, v30
    2994:      	fcmge.4s	v17, v1, v7
    2998:      	and.16b	v16, v16, v17
    299c:      	and.16b	v16, v16, v7
    29a0:      	fmul.4s	v17, v16, v27
    29a4:      	movi.4s	v18, #0x4b, lsl #24
    29a8:      	fadd.4s	v17, v17, v18
    29ac:      	movi.4s	v18, #0xcb, lsl #24
    29b0:      	fadd.4s	v17, v17, v18
    29b4:      	fcvtzs.4s	v17, v17
    29b8:      	scvtf.4s	v18, v17
    29bc:      	fmul.4s	v19, v18, v9
    29c0:      	fadd.4s	v16, v16, v19
    29c4:      	fmul.4s	v18, v18, v24
    29c8:      	fadd.4s	v16, v16, v18
    29cc:      	fmul.4s	v18, v16, v22
    29d0:      	fadd.4s	v18, v18, v20
    29d4:      	fmul.4s	v18, v16, v18
    29d8:      	fadd.4s	v18, v18, v25
    29dc:      	fmul.4s	v18, v16, v18
    29e0:      	fadd.4s	v18, v18, v26
    29e4:      	fmul.4s	v18, v16, v18
    29e8:      	fadd.4s	v3, v18, v3
    29ec:      	fmul.4s	v3, v16, v3
    29f0:      	fadd.4s	v3, v3, v21
    29f4:      	fmul.4s	v18, v16, v16
    29f8:      	fmul.4s	v3, v18, v3
    29fc:      	fadd.4s	v3, v16, v3
    2a00:      	fadd.4s	v3, v3, v0
    2a04:      	movi.2d	v16, #0xffffffffffffffff
    2a08:      	add.4s	v16, v17, v16
    2a0c:      	sshr.4s	v17, v16, #0x1
    2a10:      	shl.4s	v18, v17, #0x17
    2a14:      	add.4s	v18, v18, v0
    2a18:      	fmul.4s	v3, v3, v18
    2a1c:      	sub.4s	v16, v16, v17
    2a20:      	shl.4s	v16, v16, #0x17
    2a24:      	add.4s	v16, v16, v0
    2a28:      	fmul.4s	v3, v3, v16
    2a2c:      	fcmgt.4s	v1, v7, v1
    2a30:      	ldr	q7, [sp, #0x180]
    2a34:      	bsl.16b	v1, v7, v3
    2a38:      	fdiv.4s	v3, v31, v1
    2a3c:      	fsub.4s	v7, v1, v3
    2a40:      	fadd.4s	v1, v1, v3
    2a44:      	fdiv.4s	v1, v7, v1
    2a48:      	bif.16b	v1, v0, v6
    2a4c:      	fcmge.4s	v3, v0, v4
    2a50:      	bit.16b	v1, v5, v3
    2a54:      	mvni.4s	v3, #0x80, lsl #24
    2a58:      	bif.16b	v1, v2, v3
    2a5c:      	fadd.4s	v0, v1, v0
    2a60:      	fcmeq.4s	v1, v2, v2
    2a64:      	ldr	q2, [sp, #0x170]
    2a68:      	bif.16b	v0, v2, v1
    2a6c:      	fmul.4s	v1, v8, v21
    2a70:      	fmul.4s	v0, v1, v0
    2a74:      	fadd.4s	v0, v13, v0
    2a78:      	tbnz	w9, #0x4, 0x24e8 <_llm_rows.packet_batch.blocks+0x15d4>
    2a7c:      	tbz	w9, #0x5, 0x24f0 <_llm_rows.packet_batch.blocks+0x15dc>
    2a80:      	add	x10, x8, #0x14
    2a84:      	st1.s	{ v0 }[1], [x10]
    2a88:      	tbnz	w9, #0x6, 0x24f4 <_llm_rows.packet_batch.blocks+0x15e0>
    2a8c:      	tbz	w9, #0x7, 0xfe4 <_llm_rows.packet_batch.blocks+0xd0>
    2a90:      	add	x8, x8, #0x1c
    2a94:      	st1.s	{ v0 }[3], [x8]
    2a98:      	b	0xfe4 <_llm_rows.packet_batch.blocks+0xd0>
    2a9c:      	add	sp, sp, #0x5f0
    2aa0:      	ldp	x29, x30, [sp, #0x90]
    2aa4:      	ldp	x20, x19, [sp, #0x80]
    2aa8:      	ldp	x22, x21, [sp, #0x70]
    2aac:      	ldp	x24, x23, [sp, #0x60]
    2ab0:      	ldp	x26, x25, [sp, #0x50]
    2ab4:      	ldp	x28, x27, [sp, #0x40]
    2ab8:      	ldp	d9, d8, [sp, #0x30]
    2abc:      	ldp	d11, d10, [sp, #0x20]
    2ac0:      	ldp	d13, d12, [sp, #0x10]
    2ac4:      	ldp	d15, d14, [sp], #0xa0
    2ac8:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/rope-1024x4098/off/object/tile_xir_w8_38099_1788936548860189_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x28, x27, [sp, #-0x60]!
       4:      	stp	x26, x25, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	stp	x29, x30, [sp, #0x50]
      18:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      1c:      	sub	sp, sp, #0xc0
      20:      	ldr	x23, [x0]
      24:      	ldr	x22, [x0, #0x10]
      28:      	ldr	x21, [x0, #0x20]
      2c:      	ldr	x20, [x0, #0x30]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w8, w8, #3
      40:      	dup.2s	v0, w8
      44:      	ushll.2d	v0, v0, #0x0
      48:      	subs	x8, x23, x20
      4c:      	lsr	x8, x8, #13
      50:      	mov	w9, #0x800              ; =2048
      54:      	ccmp	x8, x9, #0x0, hs
      58:      	cset	w8, hi
      5c:      	subs	x10, x20, x23
      60:      	lsr	x10, x10, #13
      64:      	ccmp	x10, x9, #0x0, hs
      68:      	csinc	w10, w8, wzr, ls
      6c:      	subs	x8, x22, x20
      70:      	lsr	x8, x8, #13
      74:      	ccmp	x8, x9, #0x0, hs
      78:      	cset	w8, hi
      7c:      	mov	w11, #0x1fff            ; =8191
      80:      	movk	w11, #0x100, lsl #16
      84:      	sub	x11, x11, #0x801, lsl #12 ; =0x801000
      88:      	subs	x12, x20, x22
      8c:      	ccmp	x12, x11, #0x0, hs
      90:      	csinc	w8, w8, wzr, ls
      94:      	subs	x12, x21, x20
      98:      	lsr	x12, x12, #13
      9c:      	ccmp	x12, x9, #0x0, hs
      a0:      	cset	w9, hi
      a4:      	subs	x12, x20, x21
      a8:      	ccmp	x12, x11, #0x0, hs
      ac:      	csinc	w9, w9, wzr, ls
      b0:      	cmp	w9, #0x1
      b4:      	ccmp	w10, #0x0, #0x4, eq
      b8:      	b.eq	0x1bc <ltmp0+0x1bc>
      bc:      	tbz	w8, #0x0, 0x1bc <ltmp0+0x1bc>
      c0:      	mov	x9, #0x0                ; =0
      c4:      	mov	w8, #0x1002             ; =4098
      c8:      	dup.2s	v1, w8
      cc:      	xtn.2s	v2, v0
      d0:      	umull.2d	v1, v2, v1
      d4:      	fmov	x11, d1
      d8:      	fmov	x8, d0
      dc:      	add	x10, x8, x8, lsl #11
      e0:      	mov	w12, #0x2004            ; =8196
      e4:      	add	x12, x12, x11, lsl #2
      e8:      	add	x11, x23, x12
      ec:      	add	x12, x20, x12
      f0:      	fmov	d2, x9
      f4:      	add.2d	v2, v2, v1
      f8:      	fmov	x13, d2
      fc:      	lsl	x13, x13, #2
     100:      	add	x14, x23, x13
     104:      	ldp	q2, q3, [x14]
     108:      	ldp	q4, q5, [x11], #0x20
     10c:      	add	x14, x9, x10
     110:      	lsl	x14, x14, #2
     114:      	add	x15, x22, x14
     118:      	ldp	q6, q7, [x15]
     11c:      	add	x14, x21, x14
     120:      	ldp	q16, q17, [x14]
     124:      	fmul.4s	v18, v3, v7
     128:      	fmul.4s	v19, v2, v6
     12c:      	fmul.4s	v20, v5, v17
     130:      	fmul.4s	v21, v4, v16
     134:      	fsub.4s	v19, v19, v21
     138:      	fsub.4s	v18, v18, v20
     13c:      	add	x13, x20, x13
     140:      	stp	q19, q18, [x13]
     144:      	fmul.4s	v3, v3, v17
     148:      	fmul.4s	v2, v2, v16
     14c:      	fmul.4s	v5, v5, v7
     150:      	fmul.4s	v4, v4, v6
     154:      	fadd.4s	v2, v4, v2
     158:      	fadd.4s	v3, v5, v3
     15c:      	stp	q2, q3, [x12], #0x20
     160:      	add	x9, x9, #0x8
     164:      	cmp	x9, #0x800
     168:      	b.ne	0xf0 <ltmp0+0xf0>
     16c:      	fmov	x9, d0
     170:      	add	x9, x9, x9, lsl #11
     174:      	lsl	x9, x9, #3
     178:      	add	x10, x9, #0x2, lsl #12  ; =0x2000
     17c:      	ldr	s0, [x23, x10]
     180:      	mov	w11, #0x4004            ; =16388
     184:      	add	x19, x9, x11
     188:      	ldr	s1, [x23, x19]
     18c:      	mov	w9, #0x2004             ; =8196
     190:      	umull	x8, w8, w9
     194:      	add	x8, x8, #0x2, lsl #12   ; =0x2000
     198:      	ldr	s2, [x22, x8]
     19c:      	ldr	s3, [x21, x8]
     1a0:      	fmul.4s	v4, v0, v2
     1a4:      	fmul.4s	v5, v1, v3
     1a8:      	fsub.4s	v4, v4, v5
     1ac:      	str	s4, [x20, x10]
     1b0:      	fmul.4s	v0, v0, v3
     1b4:      	fmul.4s	v1, v1, v2
     1b8:      	b	0x36c <ltmp0+0x36c>
     1bc:      	fmov	x8, d0
     1c0:      	add	x28, x8, x8, lsl #11
     1c4:      	lsl	x24, x28, #3
     1c8:      	add	x19, x23, x24
     1cc:      	add	x26, sp, #0x6, lsl #12  ; =0x6000
     1d0:      	add	x26, x26, #0xa0
     1d4:      	add	x0, sp, #0x6, lsl #12   ; =0x6000
     1d8:      	add	x0, x0, #0xa0
     1dc:      	mov	x1, x19
     1e0:      	mov	w2, #0x2000             ; =8192
     1e4:      	bl	0x1e4 <ltmp0+0x1e4>
     1e8:      	add	x8, x24, #0x2, lsl #12  ; =0x2000
     1ec:      	str	x8, [sp, #0x8]
     1f0:      	ldr	s0, [x23, x8]
     1f4:      	str	q0, [sp, #0x30]
     1f8:      	str	q0, [sp, #0x80a0]
     1fc:      	mov	w8, #0x2004             ; =8196
     200:      	add	x27, sp, #0x4, lsl #12  ; =0x4000
     204:      	add	x27, x27, #0x80
     208:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     20c:      	add	x0, x0, #0x80
     210:      	add	x1, x19, x8
     214:      	mov	w2, #0x2000             ; =8192
     218:      	bl	0x218 <ltmp0+0x218>
     21c:      	mov	w8, #0x4004             ; =16388
     220:      	add	x19, x24, x8
     224:      	ldr	s0, [x23, x19]
     228:      	str	q0, [sp, #0x20]
     22c:      	str	q0, [sp, #0x6080]
     230:      	lsl	x28, x28, #2
     234:      	add	x23, sp, #0x2, lsl #12  ; =0x2000
     238:      	add	x23, x23, #0x60
     23c:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     240:      	add	x0, x0, #0x60
     244:      	add	x1, x22, x28
     248:      	mov	w2, #0x2000             ; =8192
     24c:      	bl	0x24c <ltmp0+0x24c>
     250:      	add	x25, x28, #0x2, lsl #12 ; =0x2000
     254:      	ldr	s0, [x22, x25]
     258:      	str	q0, [sp, #0x10]
     25c:      	str	q0, [sp, #0x4060]
     260:      	add	x22, sp, #0x40
     264:      	add	x0, sp, #0x40
     268:      	add	x1, x21, x28
     26c:      	mov	w2, #0x2000             ; =8192
     270:      	bl	0x270 <ltmp0+0x270>
     274:      	mov	x8, #0x0                ; =0
     278:      	ldr	s0, [x21, x25]
     27c:      	str	q0, [sp, #0x2040]
     280:      	add	x9, x20, x24
     284:      	add	x10, x26, x8
     288:      	ldp	q1, q2, [x10]
     28c:      	add	x10, x23, x8
     290:      	ldp	q3, q4, [x10]
     294:      	fmul.4s	v2, v2, v4
     298:      	fmul.4s	v1, v1, v3
     29c:      	add	x10, x27, x8
     2a0:      	ldp	q3, q4, [x10]
     2a4:      	add	x10, x22, x8
     2a8:      	ldp	q5, q6, [x10]
     2ac:      	fmul.4s	v4, v4, v6
     2b0:      	fmul.4s	v3, v3, v5
     2b4:      	fsub.4s	v1, v1, v3
     2b8:      	fsub.4s	v2, v2, v4
     2bc:      	add	x10, x9, x8
     2c0:      	stp	q1, q2, [x10]
     2c4:      	add	x8, x8, #0x20
     2c8:      	cmp	x8, #0x2, lsl #12       ; =0x2000
     2cc:      	b.ne	0x284 <ltmp0+0x284>
     2d0:      	mov	x8, #0x0                ; =0
     2d4:      	ldp	q16, q7, [sp, #0x20]
     2d8:      	ldr	q17, [sp, #0x10]
     2dc:      	fmul.4s	v1, v7, v17
     2e0:      	fmul.4s	v2, v16, v0
     2e4:      	fsub.4s	v1, v1, v2
     2e8:      	ldr	x9, [sp, #0x8]
     2ec:      	str	s1, [x20, x9]
     2f0:      	mov	w9, #0x2004             ; =8196
     2f4:      	add	x10, x20, x24
     2f8:      	add	x9, x10, x9
     2fc:      	add	x10, sp, #0x6, lsl #12  ; =0x6000
     300:      	add	x10, x10, #0xa0
     304:      	add	x11, sp, #0x40
     308:      	add	x12, sp, #0x4, lsl #12  ; =0x4000
     30c:      	add	x12, x12, #0x80
     310:      	add	x13, sp, #0x2, lsl #12  ; =0x2000
     314:      	add	x13, x13, #0x60
     318:      	add	x14, x10, x8
     31c:      	ldp	q1, q2, [x14]
     320:      	add	x14, x11, x8
     324:      	ldp	q3, q4, [x14]
     328:      	fmul.4s	v2, v2, v4
     32c:      	fmul.4s	v1, v1, v3
     330:      	add	x14, x12, x8
     334:      	ldp	q3, q4, [x14]
     338:      	add	x14, x13, x8
     33c:      	ldp	q5, q6, [x14]
     340:      	fmul.4s	v4, v4, v6
     344:      	fmul.4s	v3, v3, v5
     348:      	fadd.4s	v1, v1, v3
     34c:      	fadd.4s	v2, v2, v4
     350:      	add	x14, x9, x8
     354:      	stp	q1, q2, [x14]
     358:      	add	x8, x8, #0x20
     35c:      	cmp	x8, #0x2, lsl #12       ; =0x2000
     360:      	b.ne	0x318 <ltmp0+0x318>
     364:      	fmul.4s	v0, v7, v0
     368:      	fmul.4s	v1, v16, v17
     36c:      	fadd.4s	v0, v1, v0
     370:      	str	s0, [x20, x19]
     374:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
     378:      	add	sp, sp, #0xc0
     37c:      	ldp	x29, x30, [sp, #0x50]
     380:      	ldp	x20, x19, [sp, #0x40]
     384:      	ldp	x22, x21, [sp, #0x30]
     388:      	ldp	x24, x23, [sp, #0x20]
     38c:      	ldp	x26, x25, [sp, #0x10]
     390:      	ldp	x28, x27, [sp], #0x60
     394:      	ret

0000000000000398 <_llm_rows.packet_batch.blocks>:
     398:      	stp	d15, d14, [sp, #-0xa0]!
     39c:      	stp	d13, d12, [sp, #0x10]
     3a0:      	stp	d11, d10, [sp, #0x20]
     3a4:      	stp	d9, d8, [sp, #0x30]
     3a8:      	stp	x28, x27, [sp, #0x40]
     3ac:      	stp	x26, x25, [sp, #0x50]
     3b0:      	stp	x24, x23, [sp, #0x60]
     3b4:      	stp	x22, x21, [sp, #0x70]
     3b8:      	stp	x20, x19, [sp, #0x80]
     3bc:      	stp	x29, x30, [sp, #0x90]
     3c0:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
     3c4:      	sub	sp, sp, #0x4e0
     3c8:      	str	x0, [sp, #0x138]
     3cc:      	cbz	w3, 0x1de4 <_llm_rows.packet_batch.blocks+0x1a4c>
     3d0:      	mov	x28, x3
     3d4:      	mov	x20, x2
     3d8:      	mov	w22, #0x0               ; =0
     3dc:      	ldp	w9, w8, [x2, #0x2c]
     3e0:      	str	w9, [sp, #0x11c]
     3e4:      	str	w8, [sp, #0x118]
     3e8:      	mov	w8, #0x1002             ; =4098
     3ec:      	ldp	w25, w23, [x2]
     3f0:      	ldp	w24, w9, [x2, #0x8]
     3f4:      	str	x9, [sp, #0x110]
     3f8:      	adrp	x9, 0x0 <ltmp0>
     3fc:      	ldr	q0, [x9]
     400:      	str	q0, [sp, #0xf0]
     404:      	adrp	x9, 0x0 <ltmp0>
     408:      	ldr	q0, [x9]
     40c:      	str	q0, [sp, #0xe0]
     410:      	adrp	x9, 0x0 <ltmp0>
     414:      	ldr	q0, [x9]
     418:      	str	q0, [sp, #0xb0]
     41c:      	adrp	x9, 0x0 <ltmp0>
     420:      	ldr	q0, [x9]
     424:      	str	q0, [sp, #0xa0]
     428:      	adrp	x9, 0x0 <ltmp0>
     42c:      	ldr	q0, [x9]
     430:      	str	q0, [sp, #0x90]
     434:      	adrp	x9, 0x0 <ltmp0>
     438:      	ldr	q0, [x9]
     43c:      	str	q0, [sp, #0x80]
     440:      	dup.2s	v10, w8
     444:      	adrp	x8, 0x0 <ltmp0>
     448:      	ldr	q15, [x8]
     44c:      	add	x27, sp, #0x4, lsl #12  ; =0x4000
     450:      	add	x27, x27, #0x4a0
     454:      	add	x19, sp, #0x2, lsl #12  ; =0x2000
     458:      	add	x19, x19, #0x480
     45c:      	add	x21, sp, #0x460
     460:      	str	q15, [sp, #0x120]
     464:      	str	w3, [sp, #0x10c]
     468:      	str	d10, [sp, #0x8]
     46c:      	b	0x4b8 <_llm_rows.packet_batch.blocks+0x120>
     470:      	mov	w8, #0x18               ; =24
     474:      	str	w8, [x20, #0x24]
     478:      	ldr	w28, [sp, #0x10c]
     47c:      	add	w8, w25, #0x1
     480:      	ldr	w9, [sp, #0x11c]
     484:      	cmp	w8, w9
     488:      	cset	w8, eq
     48c:      	csinc	w25, wzr, w25, eq
     490:      	cinc	w9, w23, eq
     494:      	ldr	w10, [sp, #0x118]
     498:      	cmp	w9, w10
     49c:      	cset	w10, eq
     4a0:      	ands	w8, w8, w10
     4a4:      	csel	w23, wzr, w9, ne
     4a8:      	add	w24, w24, w8
     4ac:      	add	w22, w22, #0x1
     4b0:      	cmp	w22, w28
     4b4:      	b.eq	0x1de4 <_llm_rows.packet_batch.blocks+0x1a4c>
     4b8:      	ubfiz	x8, x25, #5, #32
     4bc:      	ldr	x12, [sp, #0x110]
     4c0:      	cmp	x8, x12
     4c4:      	csel	x9, x8, xzr, ls
     4c8:      	subs	x10, x12, x9
     4cc:      	cmp	x10, #0x20
     4d0:      	mov	w11, #0x20              ; =32
     4d4:      	csel	x10, x10, x11, lo
     4d8:      	cmp	x12, x9
     4dc:      	stp	w25, w23, [x20]
     4e0:      	str	w24, [x20, #0x8]
     4e4:      	str	wzr, [x20, #0x24]
     4e8:      	ccmp	x8, x12, #0x2, hi
     4ec:      	csel	x26, x10, xzr, ls
     4f0:      	cmp	x26, #0x20
     4f4:      	b.lo	0x54c <_llm_rows.packet_batch.blocks+0x1b4>
     4f8:      	ldr	x26, [sp, #0x138]
     4fc:      	mov	x0, x26
     500:      	mov	x1, x20
     504:      	bl	0x504 <_llm_rows.packet_batch.blocks+0x16c>
     508:      	mov	w8, #0x8                ; =8
     50c:      	str	w8, [x20, #0x24]
     510:      	mov	x0, x26
     514:      	mov	x1, x20
     518:      	bl	0x518 <_llm_rows.packet_batch.blocks+0x180>
     51c:      	mov	w8, #0x10               ; =16
     520:      	str	w8, [x20, #0x24]
     524:      	mov	x0, x26
     528:      	mov	x1, x20
     52c:      	bl	0x52c <_llm_rows.packet_batch.blocks+0x194>
     530:      	mov	w8, #0x18               ; =24
     534:      	str	w8, [x20, #0x24]
     538:      	mov	x0, x26
     53c:      	mov	x1, x20
     540:      	bl	0x540 <_llm_rows.packet_batch.blocks+0x1a8>
     544:      	ldr	q15, [sp, #0x120]
     548:      	b	0x47c <_llm_rows.packet_batch.blocks+0xe4>
     54c:      	lsr	x28, x26, #3
     550:      	cmp	x26, #0x8
     554:      	b.lo	0x5ac <_llm_rows.packet_batch.blocks+0x214>
     558:      	str	wzr, [x20, #0x24]
     55c:      	ldr	x0, [sp, #0x138]
     560:      	mov	x1, x20
     564:      	bl	0x564 <_llm_rows.packet_batch.blocks+0x1cc>
     568:      	ldr	q15, [sp, #0x120]
     56c:      	cmp	x28, #0x1
     570:      	b.eq	0x5ac <_llm_rows.packet_batch.blocks+0x214>
     574:      	mov	w8, #0x8                ; =8
     578:      	str	w8, [x20, #0x24]
     57c:      	ldr	x0, [sp, #0x138]
     580:      	mov	x1, x20
     584:      	bl	0x584 <_llm_rows.packet_batch.blocks+0x1ec>
     588:      	ldr	q15, [sp, #0x120]
     58c:      	cmp	x28, #0x2
     590:      	b.eq	0x5ac <_llm_rows.packet_batch.blocks+0x214>
     594:      	mov	w8, #0x10               ; =16
     598:      	str	w8, [x20, #0x24]
     59c:      	ldr	x0, [sp, #0x138]
     5a0:      	mov	x1, x20
     5a4:      	bl	0x5a4 <_llm_rows.packet_batch.blocks+0x20c>
     5a8:      	ldr	q15, [sp, #0x120]
     5ac:      	and	w8, w26, #0x7
     5b0:      	cbz	w8, 0x470 <_llm_rows.packet_batch.blocks+0xd8>
     5b4:      	dup.4s	v0, w8
     5b8:      	ldp	q2, q1, [sp, #0xe0]
     5bc:      	cmhi.4s	v6, v0, v2
     5c0:      	cmhi.4s	v0, v0, v1
     5c4:      	uzp1.8h	v22, v0, v6
     5c8:      	umaxv.8h	h1, v22
     5cc:      	fmov	w8, s1
     5d0:      	tbz	w8, #0x0, 0x470 <_llm_rows.packet_batch.blocks+0xd8>
     5d4:      	ldr	x8, [sp, #0x138]
     5d8:      	ldr	x11, [x8]
     5dc:      	ldr	x10, [x8, #0x10]
     5e0:      	ldr	x9, [x8, #0x20]
     5e4:      	ldr	x8, [x8, #0x30]
     5e8:      	sshll.2d	v1, v0, #0x0
     5ec:      	sshll.2d	v2, v6, #0x0
     5f0:      	sshll2.2d	v23, v0, #0x0
     5f4:      	sshll2.2d	v21, v6, #0x0
     5f8:      	ldp	q3, q4, [sp, #0xa0]
     5fc:      	and.16b	v16, v21, v4
     600:      	and.16b	v13, v23, v3
     604:      	ldr	q3, [sp, #0x90]
     608:      	and.16b	v17, v2, v3
     60c:      	ldr	q2, [sp, #0x80]
     610:      	and.16b	v20, v1, v2
     614:      	ubfiz	w12, w25, #2, #27
     618:      	orr	w12, w12, w28
     61c:      	dup.4s	v1, w12
     620:      	and.16b	v2, v0, v1
     624:      	and.16b	v1, v6, v1
     628:      	ushll2.2d	v5, v1, #0x0
     62c:      	ushll2.2d	v4, v2, #0x0
     630:      	ushll.2d	v1, v1, #0x0
     634:      	ushll.2d	v3, v2, #0x0
     638:      	subs	x12, x11, x8
     63c:      	mov	w16, #0x1fff            ; =8191
     640:      	movk	w16, #0x100, lsl #16
     644:      	ccmp	x12, x16, #0x0, hs
     648:      	cset	w12, hi
     64c:      	subs	x13, x8, x11
     650:      	ccmp	x13, x16, #0x0, hs
     654:      	csinc	w12, w12, wzr, ls
     658:      	subs	x13, x10, x8
     65c:      	ccmp	x13, x16, #0x0, hs
     660:      	cset	w13, hi
     664:      	sub	x14, x16, #0x801, lsl #12 ; =0x801000
     668:      	subs	x15, x8, x10
     66c:      	ccmp	x15, x14, #0x0, hs
     670:      	csinc	w13, w13, wzr, ls
     674:      	subs	x15, x9, x8
     678:      	ccmp	x15, x16, #0x0, hs
     67c:      	cset	w15, hi
     680:      	subs	x16, x8, x9
     684:      	ccmp	x16, x14, #0x0, hs
     688:      	csinc	w14, w15, wzr, ls
     68c:      	xtn.2s	v11, v4
     690:      	xtn.2s	v4, v1
     694:      	xtn.2s	v5, v5
     698:      	xtn.2s	v12, v3
     69c:      	mov	w15, #0x801             ; =2049
     6a0:      	dup.2s	v2, w15
     6a4:      	cmp	w14, #0x1
     6a8:      	b.ne	0x1078 <_llm_rows.packet_batch.blocks+0xce0>
     6ac:      	cbz	w12, 0x1078 <_llm_rows.packet_batch.blocks+0xce0>
     6b0:      	tbz	w13, #0x0, 0x1078 <_llm_rows.packet_batch.blocks+0xce0>
     6b4:      	mov	x12, #0x0               ; =0
     6b8:      	umull.2d	v6, v11, v10
     6bc:      	umull.2d	v19, v4, v10
     6c0:      	umull.2d	v7, v5, v10
     6c4:      	umull.2d	v21, v12, v10
     6c8:      	fmov	x13, d21
     6cc:      	add	x13, x13, #0x801
     6d0:      	fmov	x14, d3
     6d4:      	add	x14, x14, x14, lsl #11
     6d8:      	and.16b	v3, v22, v15
     6dc:      	addv.8h	h22, v3
     6e0:      	fmov	w15, s22
     6e4:      	b	0x6f4 <_llm_rows.packet_batch.blocks+0x35c>
     6e8:      	add	x12, x12, #0x8
     6ec:      	cmp	x12, #0x800
     6f0:      	b.eq	0xafc <_llm_rows.packet_batch.blocks+0x764>
     6f4:      	dup.2d	v3, x12
     6f8:      	orr.16b	v25, v3, v20
     6fc:      	add.2d	v3, v25, v21
     700:      	fmov	x16, d3
     704:      	lsl	x16, x16, #2
     708:      	add	x17, x11, x16
     70c:      	movi.2d	v24, #0000000000000000
     710:      	movi.2d	v23, #0000000000000000
     714:      	tbz	w15, #0x0, 0x758 <_llm_rows.packet_batch.blocks+0x3c0>
     718:      	ldr	s24, [x17]
     71c:      	and	w0, w15, #0xff
     720:      	tbnz	w0, #0x1, 0x760 <_llm_rows.packet_batch.blocks+0x3c8>
     724:      	tbz	w0, #0x2, 0x76c <_llm_rows.packet_batch.blocks+0x3d4>
     728:      	add	x1, x17, #0x8
     72c:      	ld1.s	{ v24 }[2], [x1]
     730:      	tbnz	w0, #0x3, 0x770 <_llm_rows.packet_batch.blocks+0x3d8>
     734:      	tbz	w0, #0x4, 0x77c <_llm_rows.packet_batch.blocks+0x3e4>
     738:      	add	x1, x17, #0x10
     73c:      	ld1.s	{ v23 }[0], [x1]
     740:      	tbnz	w0, #0x5, 0x780 <_llm_rows.packet_batch.blocks+0x3e8>
     744:      	tbz	w0, #0x6, 0x78c <_llm_rows.packet_batch.blocks+0x3f4>
     748:      	add	x1, x17, #0x18
     74c:      	ld1.s	{ v23 }[2], [x1]
     750:      	tbnz	w0, #0x7, 0x790 <_llm_rows.packet_batch.blocks+0x3f8>
     754:      	b	0x798 <_llm_rows.packet_batch.blocks+0x400>
     758:      	and	w0, w15, #0xff
     75c:      	tbz	w0, #0x1, 0x724 <_llm_rows.packet_batch.blocks+0x38c>
     760:      	add	x1, x17, #0x4
     764:      	ld1.s	{ v24 }[1], [x1]
     768:      	tbnz	w0, #0x2, 0x728 <_llm_rows.packet_batch.blocks+0x390>
     76c:      	tbz	w0, #0x3, 0x734 <_llm_rows.packet_batch.blocks+0x39c>
     770:      	add	x1, x17, #0xc
     774:      	ld1.s	{ v24 }[3], [x1]
     778:      	tbnz	w0, #0x4, 0x738 <_llm_rows.packet_batch.blocks+0x3a0>
     77c:      	tbz	w0, #0x5, 0x744 <_llm_rows.packet_batch.blocks+0x3ac>
     780:      	add	x1, x17, #0x14
     784:      	ld1.s	{ v23 }[1], [x1]
     788:      	tbnz	w0, #0x6, 0x748 <_llm_rows.packet_batch.blocks+0x3b0>
     78c:      	tbz	w0, #0x7, 0x798 <_llm_rows.packet_batch.blocks+0x400>
     790:      	add	x17, x17, #0x1c
     794:      	ld1.s	{ v23 }[3], [x17]
     798:      	fmov	w2, s22
     79c:      	fmov	x0, d25
     7a0:      	add	x17, x13, x0
     7a4:      	lsl	x17, x17, #2
     7a8:      	add	x1, x11, x17
     7ac:      	movi.2d	v26, #0000000000000000
     7b0:      	movi.2d	v25, #0000000000000000
     7b4:      	tbz	w2, #0x0, 0x7f8 <_llm_rows.packet_batch.blocks+0x460>
     7b8:      	ldr	s26, [x1]
     7bc:      	and	w2, w2, #0xff
     7c0:      	tbnz	w2, #0x1, 0x800 <_llm_rows.packet_batch.blocks+0x468>
     7c4:      	tbz	w2, #0x2, 0x80c <_llm_rows.packet_batch.blocks+0x474>
     7c8:      	add	x3, x1, #0x8
     7cc:      	ld1.s	{ v26 }[2], [x3]
     7d0:      	tbnz	w2, #0x3, 0x810 <_llm_rows.packet_batch.blocks+0x478>
     7d4:      	tbz	w2, #0x4, 0x81c <_llm_rows.packet_batch.blocks+0x484>
     7d8:      	add	x3, x1, #0x10
     7dc:      	ld1.s	{ v25 }[0], [x3]
     7e0:      	tbnz	w2, #0x5, 0x820 <_llm_rows.packet_batch.blocks+0x488>
     7e4:      	tbz	w2, #0x6, 0x82c <_llm_rows.packet_batch.blocks+0x494>
     7e8:      	add	x3, x1, #0x18
     7ec:      	ld1.s	{ v25 }[2], [x3]
     7f0:      	tbnz	w2, #0x7, 0x830 <_llm_rows.packet_batch.blocks+0x498>
     7f4:      	b	0x838 <_llm_rows.packet_batch.blocks+0x4a0>
     7f8:      	and	w2, w2, #0xff
     7fc:      	tbz	w2, #0x1, 0x7c4 <_llm_rows.packet_batch.blocks+0x42c>
     800:      	add	x3, x1, #0x4
     804:      	ld1.s	{ v26 }[1], [x3]
     808:      	tbnz	w2, #0x2, 0x7c8 <_llm_rows.packet_batch.blocks+0x430>
     80c:      	tbz	w2, #0x3, 0x7d4 <_llm_rows.packet_batch.blocks+0x43c>
     810:      	add	x3, x1, #0xc
     814:      	ld1.s	{ v26 }[3], [x3]
     818:      	tbnz	w2, #0x4, 0x7d8 <_llm_rows.packet_batch.blocks+0x440>
     81c:      	tbz	w2, #0x5, 0x7e4 <_llm_rows.packet_batch.blocks+0x44c>
     820:      	add	x3, x1, #0x14
     824:      	ld1.s	{ v25 }[1], [x3]
     828:      	tbnz	w2, #0x6, 0x7e8 <_llm_rows.packet_batch.blocks+0x450>
     82c:      	tbz	w2, #0x7, 0x838 <_llm_rows.packet_batch.blocks+0x4a0>
     830:      	add	x1, x1, #0x1c
     834:      	ld1.s	{ v25 }[3], [x1]
     838:      	fmov	w2, s22
     83c:      	add	x0, x0, x14
     840:      	lsl	x0, x0, #2
     844:      	add	x1, x10, x0
     848:      	movi.2d	v28, #0000000000000000
     84c:      	movi.2d	v27, #0000000000000000
     850:      	tbz	w2, #0x0, 0x99c <_llm_rows.packet_batch.blocks+0x604>
     854:      	ldr	s28, [x1]
     858:      	and	w2, w2, #0xff
     85c:      	tbnz	w2, #0x1, 0x9a4 <_llm_rows.packet_batch.blocks+0x60c>
     860:      	tbz	w2, #0x2, 0x9b0 <_llm_rows.packet_batch.blocks+0x618>
     864:      	add	x3, x1, #0x8
     868:      	ld1.s	{ v28 }[2], [x3]
     86c:      	tbnz	w2, #0x3, 0x9b4 <_llm_rows.packet_batch.blocks+0x61c>
     870:      	tbz	w2, #0x4, 0x9c0 <_llm_rows.packet_batch.blocks+0x628>
     874:      	add	x3, x1, #0x10
     878:      	ld1.s	{ v27 }[0], [x3]
     87c:      	tbnz	w2, #0x5, 0x9c4 <_llm_rows.packet_batch.blocks+0x62c>
     880:      	tbz	w2, #0x6, 0x9d0 <_llm_rows.packet_batch.blocks+0x638>
     884:      	add	x3, x1, #0x18
     888:      	ld1.s	{ v27 }[2], [x3]
     88c:      	tbnz	w2, #0x7, 0x9d4 <_llm_rows.packet_batch.blocks+0x63c>
     890:      	fmov	w1, s22
     894:      	add	x0, x9, x0
     898:      	movi.2d	v30, #0000000000000000
     89c:      	movi.2d	v29, #0000000000000000
     8a0:      	tbz	w1, #0x0, 0x9f0 <_llm_rows.packet_batch.blocks+0x658>
     8a4:      	ldr	s30, [x0]
     8a8:      	and	w1, w1, #0xff
     8ac:      	tbnz	w1, #0x1, 0x9f8 <_llm_rows.packet_batch.blocks+0x660>
     8b0:      	tbz	w1, #0x2, 0xa04 <_llm_rows.packet_batch.blocks+0x66c>
     8b4:      	add	x2, x0, #0x8
     8b8:      	ld1.s	{ v30 }[2], [x2]
     8bc:      	tbnz	w1, #0x3, 0xa08 <_llm_rows.packet_batch.blocks+0x670>
     8c0:      	tbz	w1, #0x4, 0xa14 <_llm_rows.packet_batch.blocks+0x67c>
     8c4:      	add	x2, x0, #0x10
     8c8:      	ld1.s	{ v29 }[0], [x2]
     8cc:      	tbnz	w1, #0x5, 0xa18 <_llm_rows.packet_batch.blocks+0x680>
     8d0:      	tbz	w1, #0x6, 0xa24 <_llm_rows.packet_batch.blocks+0x68c>
     8d4:      	add	x2, x0, #0x18
     8d8:      	ld1.s	{ v29 }[2], [x2]
     8dc:      	tbnz	w1, #0x7, 0xa28 <_llm_rows.packet_batch.blocks+0x690>
     8e0:      	fmov	w0, s22
     8e4:      	fmul.4s	v3, v24, v28
     8e8:      	fmul.4s	v31, v26, v30
     8ec:      	fsub.4s	v3, v3, v31
     8f0:      	add	x16, x8, x16
     8f4:      	tbz	w0, #0x0, 0xa48 <_llm_rows.packet_batch.blocks+0x6b0>
     8f8:      	str	s3, [x16]
     8fc:      	and	w0, w0, #0xff
     900:      	tbnz	w0, #0x1, 0xa50 <_llm_rows.packet_batch.blocks+0x6b8>
     904:      	tbz	w0, #0x2, 0xa5c <_llm_rows.packet_batch.blocks+0x6c4>
     908:      	add	x1, x16, #0x8
     90c:      	st1.s	{ v3 }[2], [x1]
     910:      	tbnz	w0, #0x3, 0xa60 <_llm_rows.packet_batch.blocks+0x6c8>
     914:      	fmul.4s	v3, v23, v27
     918:      	fmul.4s	v31, v25, v29
     91c:      	fsub.4s	v3, v3, v31
     920:      	tbz	w0, #0x4, 0xa78 <_llm_rows.packet_batch.blocks+0x6e0>
     924:      	str	s3, [x16, #0x10]
     928:      	tbnz	w0, #0x5, 0xa7c <_llm_rows.packet_batch.blocks+0x6e4>
     92c:      	tbz	w0, #0x6, 0xa88 <_llm_rows.packet_batch.blocks+0x6f0>
     930:      	add	x1, x16, #0x18
     934:      	st1.s	{ v3 }[2], [x1]
     938:      	tbnz	w0, #0x7, 0xa8c <_llm_rows.packet_batch.blocks+0x6f4>
     93c:      	fmov	w0, s22
     940:      	fmul.4s	v3, v24, v30
     944:      	fmul.4s	v24, v26, v28
     948:      	fadd.4s	v3, v24, v3
     94c:      	add	x16, x8, x17
     950:      	tbz	w0, #0x0, 0xaac <_llm_rows.packet_batch.blocks+0x714>
     954:      	str	s3, [x16]
     958:      	and	w17, w0, #0xff
     95c:      	tbnz	w17, #0x1, 0xab4 <_llm_rows.packet_batch.blocks+0x71c>
     960:      	tbz	w17, #0x2, 0xac0 <_llm_rows.packet_batch.blocks+0x728>
     964:      	add	x0, x16, #0x8
     968:      	st1.s	{ v3 }[2], [x0]
     96c:      	tbnz	w17, #0x3, 0xac4 <_llm_rows.packet_batch.blocks+0x72c>
     970:      	fmul.4s	v3, v23, v29
     974:      	fmul.4s	v23, v25, v27
     978:      	fadd.4s	v3, v23, v3
     97c:      	tbz	w17, #0x4, 0xadc <_llm_rows.packet_batch.blocks+0x744>
     980:      	str	s3, [x16, #0x10]
     984:      	tbnz	w17, #0x5, 0xae0 <_llm_rows.packet_batch.blocks+0x748>
     988:      	tbz	w17, #0x6, 0xaec <_llm_rows.packet_batch.blocks+0x754>
     98c:      	add	x0, x16, #0x18
     990:      	st1.s	{ v3 }[2], [x0]
     994:      	tbz	w17, #0x7, 0x6e8 <_llm_rows.packet_batch.blocks+0x350>
     998:      	b	0xaf0 <_llm_rows.packet_batch.blocks+0x758>
     99c:      	and	w2, w2, #0xff
     9a0:      	tbz	w2, #0x1, 0x860 <_llm_rows.packet_batch.blocks+0x4c8>
     9a4:      	add	x3, x1, #0x4
     9a8:      	ld1.s	{ v28 }[1], [x3]
     9ac:      	tbnz	w2, #0x2, 0x864 <_llm_rows.packet_batch.blocks+0x4cc>
     9b0:      	tbz	w2, #0x3, 0x870 <_llm_rows.packet_batch.blocks+0x4d8>
     9b4:      	add	x3, x1, #0xc
     9b8:      	ld1.s	{ v28 }[3], [x3]
     9bc:      	tbnz	w2, #0x4, 0x874 <_llm_rows.packet_batch.blocks+0x4dc>
     9c0:      	tbz	w2, #0x5, 0x880 <_llm_rows.packet_batch.blocks+0x4e8>
     9c4:      	add	x3, x1, #0x14
     9c8:      	ld1.s	{ v27 }[1], [x3]
     9cc:      	tbnz	w2, #0x6, 0x884 <_llm_rows.packet_batch.blocks+0x4ec>
     9d0:      	tbz	w2, #0x7, 0x890 <_llm_rows.packet_batch.blocks+0x4f8>
     9d4:      	add	x1, x1, #0x1c
     9d8:      	ld1.s	{ v27 }[3], [x1]
     9dc:      	fmov	w1, s22
     9e0:      	add	x0, x9, x0
     9e4:      	movi.2d	v30, #0000000000000000
     9e8:      	movi.2d	v29, #0000000000000000
     9ec:      	tbnz	w1, #0x0, 0x8a4 <_llm_rows.packet_batch.blocks+0x50c>
     9f0:      	and	w1, w1, #0xff
     9f4:      	tbz	w1, #0x1, 0x8b0 <_llm_rows.packet_batch.blocks+0x518>
     9f8:      	add	x2, x0, #0x4
     9fc:      	ld1.s	{ v30 }[1], [x2]
     a00:      	tbnz	w1, #0x2, 0x8b4 <_llm_rows.packet_batch.blocks+0x51c>
     a04:      	tbz	w1, #0x3, 0x8c0 <_llm_rows.packet_batch.blocks+0x528>
     a08:      	add	x2, x0, #0xc
     a0c:      	ld1.s	{ v30 }[3], [x2]
     a10:      	tbnz	w1, #0x4, 0x8c4 <_llm_rows.packet_batch.blocks+0x52c>
     a14:      	tbz	w1, #0x5, 0x8d0 <_llm_rows.packet_batch.blocks+0x538>
     a18:      	add	x2, x0, #0x14
     a1c:      	ld1.s	{ v29 }[1], [x2]
     a20:      	tbnz	w1, #0x6, 0x8d4 <_llm_rows.packet_batch.blocks+0x53c>
     a24:      	tbz	w1, #0x7, 0x8e0 <_llm_rows.packet_batch.blocks+0x548>
     a28:      	add	x0, x0, #0x1c
     a2c:      	ld1.s	{ v29 }[3], [x0]
     a30:      	fmov	w0, s22
     a34:      	fmul.4s	v3, v24, v28
     a38:      	fmul.4s	v31, v26, v30
     a3c:      	fsub.4s	v3, v3, v31
     a40:      	add	x16, x8, x16
     a44:      	tbnz	w0, #0x0, 0x8f8 <_llm_rows.packet_batch.blocks+0x560>
     a48:      	and	w0, w0, #0xff
     a4c:      	tbz	w0, #0x1, 0x904 <_llm_rows.packet_batch.blocks+0x56c>
     a50:      	add	x1, x16, #0x4
     a54:      	st1.s	{ v3 }[1], [x1]
     a58:      	tbnz	w0, #0x2, 0x908 <_llm_rows.packet_batch.blocks+0x570>
     a5c:      	tbz	w0, #0x3, 0x914 <_llm_rows.packet_batch.blocks+0x57c>
     a60:      	add	x1, x16, #0xc
     a64:      	st1.s	{ v3 }[3], [x1]
     a68:      	fmul.4s	v3, v23, v27
     a6c:      	fmul.4s	v31, v25, v29
     a70:      	fsub.4s	v3, v3, v31
     a74:      	tbnz	w0, #0x4, 0x924 <_llm_rows.packet_batch.blocks+0x58c>
     a78:      	tbz	w0, #0x5, 0x92c <_llm_rows.packet_batch.blocks+0x594>
     a7c:      	add	x1, x16, #0x14
     a80:      	st1.s	{ v3 }[1], [x1]
     a84:      	tbnz	w0, #0x6, 0x930 <_llm_rows.packet_batch.blocks+0x598>
     a88:      	tbz	w0, #0x7, 0x93c <_llm_rows.packet_batch.blocks+0x5a4>
     a8c:      	add	x16, x16, #0x1c
     a90:      	st1.s	{ v3 }[3], [x16]
     a94:      	fmov	w0, s22
     a98:      	fmul.4s	v3, v24, v30
     a9c:      	fmul.4s	v24, v26, v28
     aa0:      	fadd.4s	v3, v24, v3
     aa4:      	add	x16, x8, x17
     aa8:      	tbnz	w0, #0x0, 0x954 <_llm_rows.packet_batch.blocks+0x5bc>
     aac:      	and	w17, w0, #0xff
     ab0:      	tbz	w17, #0x1, 0x960 <_llm_rows.packet_batch.blocks+0x5c8>
     ab4:      	add	x0, x16, #0x4
     ab8:      	st1.s	{ v3 }[1], [x0]
     abc:      	tbnz	w17, #0x2, 0x964 <_llm_rows.packet_batch.blocks+0x5cc>
     ac0:      	tbz	w17, #0x3, 0x970 <_llm_rows.packet_batch.blocks+0x5d8>
     ac4:      	add	x0, x16, #0xc
     ac8:      	st1.s	{ v3 }[3], [x0]
     acc:      	fmul.4s	v3, v23, v29
     ad0:      	fmul.4s	v23, v25, v27
     ad4:      	fadd.4s	v3, v23, v3
     ad8:      	tbnz	w17, #0x4, 0x980 <_llm_rows.packet_batch.blocks+0x5e8>
     adc:      	tbz	w17, #0x5, 0x988 <_llm_rows.packet_batch.blocks+0x5f0>
     ae0:      	add	x0, x16, #0x14
     ae4:      	st1.s	{ v3 }[1], [x0]
     ae8:      	tbnz	w17, #0x6, 0x98c <_llm_rows.packet_batch.blocks+0x5f4>
     aec:      	tbz	w17, #0x7, 0x6e8 <_llm_rows.packet_batch.blocks+0x350>
     af0:      	add	x16, x16, #0x1c
     af4:      	st1.s	{ v3 }[3], [x16]
     af8:      	b	0x6e8 <_llm_rows.packet_batch.blocks+0x350>
     afc:      	xtn.4h	v0, v0
     b00:      	uzp1.8b	v0, v0, v0
     b04:      	movi.2d	v29, #0000000000000000
     b08:      	mov.b	v29[0], v0[0]
     b0c:      	adrp	x12, 0x0 <ltmp0>
     b10:      	ldr	d26, [x12]
     b14:      	and.8b	v3, v29, v26
     b18:      	addv.8b	b3, v3
     b1c:      	fmov	w13, s3
     b20:      	umaxv.8b	b3, v29
     b24:      	fmov	w15, s3
     b28:      	rbit	w12, w13
     b2c:      	clz	w12, w12
     b30:      	tst	w15, #0x1
     b34:      	csel	w12, w12, wzr, ne
     b38:      	mov	w14, #0x800             ; =2048
     b3c:      	dup.2d	v31, x14
     b40:      	orr.16b	v30, v20, v31
     b44:      	add.2d	v23, v21, v30
     b48:      	movi.2d	v3, #0000000000000000
     b4c:      	mov.b	v3[0], v0[0]
     b50:      	ushll.2d	v0, v3, #0x0
     b54:      	shl.2d	v0, v0, #0x3f
     b58:      	cmlt.2d	v0, v0, #0
     b5c:      	and.16b	v0, v0, v23
     b60:      	movi.2d	v3, #0000000000000000
     b64:      	stp	q3, q3, [sp, #0x260]
     b68:      	stp	q0, q3, [sp, #0x240]
     b6c:      	and	x14, x12, #0x7
     b70:      	add	x16, sp, #0x240
     b74:      	ldr	x14, [x16, x14, lsl #3]
     b78:      	sub	x14, x14, x12
     b7c:      	add	x14, x11, x14, lsl #2
     b80:      	movi.2d	v22, #0000000000000000
     b84:      	movi.2d	v0, #0000000000000000
     b88:      	tbz	w15, #0x0, 0xbc8 <_llm_rows.packet_batch.blocks+0x830>
     b8c:      	ldr	s22, [x14]
     b90:      	tbnz	w13, #0x1, 0xbcc <_llm_rows.packet_batch.blocks+0x834>
     b94:      	tbz	w13, #0x2, 0xbd8 <_llm_rows.packet_batch.blocks+0x840>
     b98:      	add	x15, x14, #0x8
     b9c:      	ld1.s	{ v22 }[2], [x15]
     ba0:      	tbnz	w13, #0x3, 0xbdc <_llm_rows.packet_batch.blocks+0x844>
     ba4:      	tbz	w13, #0x4, 0xbe8 <_llm_rows.packet_batch.blocks+0x850>
     ba8:      	add	x15, x14, #0x10
     bac:      	ld1.s	{ v0 }[0], [x15]
     bb0:      	tbnz	w13, #0x5, 0xbec <_llm_rows.packet_batch.blocks+0x854>
     bb4:      	tbz	w13, #0x6, 0xbf8 <_llm_rows.packet_batch.blocks+0x860>
     bb8:      	add	x15, x14, #0x18
     bbc:      	ld1.s	{ v0 }[2], [x15]
     bc0:      	tbnz	w13, #0x7, 0xbfc <_llm_rows.packet_batch.blocks+0x864>
     bc4:      	b	0xc04 <_llm_rows.packet_batch.blocks+0x86c>
     bc8:      	tbz	w13, #0x1, 0xb94 <_llm_rows.packet_batch.blocks+0x7fc>
     bcc:      	add	x15, x14, #0x4
     bd0:      	ld1.s	{ v22 }[1], [x15]
     bd4:      	tbnz	w13, #0x2, 0xb98 <_llm_rows.packet_batch.blocks+0x800>
     bd8:      	tbz	w13, #0x3, 0xba4 <_llm_rows.packet_batch.blocks+0x80c>
     bdc:      	add	x15, x14, #0xc
     be0:      	ld1.s	{ v22 }[3], [x15]
     be4:      	tbnz	w13, #0x4, 0xba8 <_llm_rows.packet_batch.blocks+0x810>
     be8:      	tbz	w13, #0x5, 0xbb4 <_llm_rows.packet_batch.blocks+0x81c>
     bec:      	add	x15, x14, #0x14
     bf0:      	ld1.s	{ v0 }[1], [x15]
     bf4:      	tbnz	w13, #0x6, 0xbb8 <_llm_rows.packet_batch.blocks+0x820>
     bf8:      	tbz	w13, #0x7, 0xc04 <_llm_rows.packet_batch.blocks+0x86c>
     bfc:      	add	x13, x14, #0x1c
     c00:      	ld1.s	{ v0 }[3], [x13]
     c04:      	add.2d	v3, v20, v21
     c08:      	add.2d	v24, v13, v6
     c0c:      	add.2d	v21, v17, v19
     c10:      	add.2d	v20, v16, v7
     c14:      	mov	w13, #0x1001            ; =4097
     c18:      	dup.2d	v25, x13
     c1c:      	add.2d	v20, v20, v25
     c20:      	add.2d	v21, v21, v25
     c24:      	add.2d	v24, v24, v25
     c28:      	mov	b27, v29[0]
     c2c:      	mov.b	v27[4], v29[1]
     c30:      	add.2d	v25, v3, v25
     c34:      	ushll.2d	v3, v27, #0x0
     c38:      	shl.2d	v3, v3, #0x3f
     c3c:      	cmlt.2d	v3, v3, #0
     c40:      	and.16b	v3, v3, v25
     c44:      	mov	b27, v29[2]
     c48:      	mov.b	v27[4], v29[3]
     c4c:      	ushll.2d	v27, v27, #0x0
     c50:      	shl.2d	v27, v27, #0x3f
     c54:      	cmlt.2d	v27, v27, #0
     c58:      	and.16b	v28, v27, v24
     c5c:      	mov	b27, v29[4]
     c60:      	mov.b	v27[4], v29[5]
     c64:      	ushll.2d	v27, v27, #0x0
     c68:      	shl.2d	v27, v27, #0x3f
     c6c:      	cmlt.2d	v27, v27, #0
     c70:      	and.16b	v8, v27, v21
     c74:      	mov	b27, v29[6]
     c78:      	mov.b	v27[4], v29[7]
     c7c:      	ushll.2d	v27, v27, #0x0
     c80:      	shl.2d	v27, v27, #0x3f
     c84:      	cmlt.2d	v27, v27, #0
     c88:      	and.16b	v9, v27, v20
     c8c:      	shl.8b	v27, v29, #0x7
     c90:      	cmlt.8b	v27, v27, #0
     c94:      	and.8b	v26, v27, v26
     c98:      	addv.8b	b27, v26
     c9c:      	fmov	w13, s27
     ca0:      	stp	q8, q9, [sp, #0x220]
     ca4:      	stp	q3, q28, [sp, #0x200]
     ca8:      	and	x14, x12, #0x7
     cac:      	add	x15, sp, #0x200
     cb0:      	ldr	x14, [x15, x14, lsl #3]
     cb4:      	sub	x14, x14, x12
     cb8:      	add	x11, x11, x14, lsl #2
     cbc:      	movi.2d	v28, #0000000000000000
     cc0:      	movi.2d	v26, #0000000000000000
     cc4:      	tbz	w13, #0x0, 0xd04 <_llm_rows.packet_batch.blocks+0x96c>
     cc8:      	ldr	s28, [x11]
     ccc:      	tbnz	w13, #0x1, 0xd08 <_llm_rows.packet_batch.blocks+0x970>
     cd0:      	tbz	w13, #0x2, 0xd14 <_llm_rows.packet_batch.blocks+0x97c>
     cd4:      	add	x14, x11, #0x8
     cd8:      	ld1.s	{ v28 }[2], [x14]
     cdc:      	tbnz	w13, #0x3, 0xd18 <_llm_rows.packet_batch.blocks+0x980>
     ce0:      	tbz	w13, #0x4, 0xd24 <_llm_rows.packet_batch.blocks+0x98c>
     ce4:      	add	x14, x11, #0x10
     ce8:      	ld1.s	{ v26 }[0], [x14]
     cec:      	tbnz	w13, #0x5, 0xd28 <_llm_rows.packet_batch.blocks+0x990>
     cf0:      	tbz	w13, #0x6, 0xd34 <_llm_rows.packet_batch.blocks+0x99c>
     cf4:      	add	x14, x11, #0x18
     cf8:      	ld1.s	{ v26 }[2], [x14]
     cfc:      	tbnz	w13, #0x7, 0xd38 <_llm_rows.packet_batch.blocks+0x9a0>
     d00:      	b	0xd40 <_llm_rows.packet_batch.blocks+0x9a8>
     d04:      	tbz	w13, #0x1, 0xcd0 <_llm_rows.packet_batch.blocks+0x938>
     d08:      	add	x14, x11, #0x4
     d0c:      	ld1.s	{ v28 }[1], [x14]
     d10:      	tbnz	w13, #0x2, 0xcd4 <_llm_rows.packet_batch.blocks+0x93c>
     d14:      	tbz	w13, #0x3, 0xce0 <_llm_rows.packet_batch.blocks+0x948>
     d18:      	add	x14, x11, #0xc
     d1c:      	ld1.s	{ v28 }[3], [x14]
     d20:      	tbnz	w13, #0x4, 0xce4 <_llm_rows.packet_batch.blocks+0x94c>
     d24:      	tbz	w13, #0x5, 0xcf0 <_llm_rows.packet_batch.blocks+0x958>
     d28:      	add	x14, x11, #0x14
     d2c:      	ld1.s	{ v26 }[1], [x14]
     d30:      	tbnz	w13, #0x6, 0xcf4 <_llm_rows.packet_batch.blocks+0x95c>
     d34:      	tbz	w13, #0x7, 0xd40 <_llm_rows.packet_batch.blocks+0x9a8>
     d38:      	add	x11, x11, #0x1c
     d3c:      	ld1.s	{ v26 }[3], [x11]
     d40:      	orr.16b	v16, v16, v31
     d44:      	orr.16b	v18, v13, v31
     d48:      	orr.16b	v17, v17, v31
     d4c:      	mov.16b	v3, v16
     d50:      	umlal.2d	v3, v5, v2
     d54:      	mov.16b	v5, v17
     d58:      	umlal.2d	v5, v4, v2
     d5c:      	mov.16b	v4, v18
     d60:      	umlal.2d	v4, v11, v2
     d64:      	umlal.2d	v30, v12, v2
     d68:      	mov	b1, v29[0]
     d6c:      	mov.b	v1[4], v29[1]
     d70:      	ushll.2d	v1, v1, #0x0
     d74:      	shl.2d	v1, v1, #0x3f
     d78:      	cmlt.2d	v1, v1, #0
     d7c:      	and.16b	v1, v1, v30
     d80:      	mov	b2, v29[2]
     d84:      	mov.b	v2[4], v29[3]
     d88:      	ushll.2d	v2, v2, #0x0
     d8c:      	shl.2d	v2, v2, #0x3f
     d90:      	cmlt.2d	v2, v2, #0
     d94:      	and.16b	v2, v2, v4
     d98:      	mov	b4, v29[4]
     d9c:      	mov.b	v4[4], v29[5]
     da0:      	ushll.2d	v4, v4, #0x0
     da4:      	shl.2d	v4, v4, #0x3f
     da8:      	cmlt.2d	v4, v4, #0
     dac:      	mov	b30, v29[6]
     db0:      	mov.b	v30[4], v29[7]
     db4:      	and.16b	v4, v4, v5
     db8:      	ushll.2d	v5, v30, #0x0
     dbc:      	shl.2d	v5, v5, #0x3f
     dc0:      	cmlt.2d	v5, v5, #0
     dc4:      	and.16b	v3, v5, v3
     dc8:      	stp	q4, q3, [sp, #0x1e0]
     dcc:      	stp	q1, q2, [sp, #0x1c0]
     dd0:      	and	x11, x12, #0x7
     dd4:      	add	x13, sp, #0x1c0
     dd8:      	ldr	x11, [x13, x11, lsl #3]
     ddc:      	fmov	w13, s27
     de0:      	sub	x11, x11, x12
     de4:      	lsl	x11, x11, #2
     de8:      	add	x10, x10, x11
     dec:      	movi.2d	v2, #0000000000000000
     df0:      	movi.2d	v1, #0000000000000000
     df4:      	tbz	w13, #0x0, 0xe80 <_llm_rows.packet_batch.blocks+0xae8>
     df8:      	ldr	s2, [x10]
     dfc:      	tbnz	w13, #0x1, 0xe84 <_llm_rows.packet_batch.blocks+0xaec>
     e00:      	tbz	w13, #0x2, 0xe90 <_llm_rows.packet_batch.blocks+0xaf8>
     e04:      	add	x14, x10, #0x8
     e08:      	ld1.s	{ v2 }[2], [x14]
     e0c:      	tbnz	w13, #0x3, 0xe94 <_llm_rows.packet_batch.blocks+0xafc>
     e10:      	tbz	w13, #0x4, 0xea0 <_llm_rows.packet_batch.blocks+0xb08>
     e14:      	add	x14, x10, #0x10
     e18:      	ld1.s	{ v1 }[0], [x14]
     e1c:      	tbnz	w13, #0x5, 0xea4 <_llm_rows.packet_batch.blocks+0xb0c>
     e20:      	tbz	w13, #0x6, 0xeb0 <_llm_rows.packet_batch.blocks+0xb18>
     e24:      	add	x14, x10, #0x18
     e28:      	ld1.s	{ v1 }[2], [x14]
     e2c:      	tbnz	w13, #0x7, 0xeb4 <_llm_rows.packet_batch.blocks+0xb1c>
     e30:      	add	x9, x9, x11
     e34:      	fmov	w10, s27
     e38:      	movi.2d	v4, #0000000000000000
     e3c:      	movi.2d	v3, #0000000000000000
     e40:      	tbz	w10, #0x0, 0xed0 <_llm_rows.packet_batch.blocks+0xb38>
     e44:      	ldr	s4, [x9]
     e48:      	tbnz	w10, #0x1, 0xed4 <_llm_rows.packet_batch.blocks+0xb3c>
     e4c:      	tbz	w10, #0x2, 0xee0 <_llm_rows.packet_batch.blocks+0xb48>
     e50:      	add	x11, x9, #0x8
     e54:      	ld1.s	{ v4 }[2], [x11]
     e58:      	tbnz	w10, #0x3, 0xee4 <_llm_rows.packet_batch.blocks+0xb4c>
     e5c:      	tbz	w10, #0x4, 0xef0 <_llm_rows.packet_batch.blocks+0xb58>
     e60:      	add	x11, x9, #0x10
     e64:      	ld1.s	{ v3 }[0], [x11]
     e68:      	tbnz	w10, #0x5, 0xef4 <_llm_rows.packet_batch.blocks+0xb5c>
     e6c:      	tbz	w10, #0x6, 0xf00 <_llm_rows.packet_batch.blocks+0xb68>
     e70:      	add	x11, x9, #0x18
     e74:      	ld1.s	{ v3 }[2], [x11]
     e78:      	tbnz	w10, #0x7, 0xf04 <_llm_rows.packet_batch.blocks+0xb6c>
     e7c:      	b	0xf0c <_llm_rows.packet_batch.blocks+0xb74>
     e80:      	tbz	w13, #0x1, 0xe00 <_llm_rows.packet_batch.blocks+0xa68>
     e84:      	add	x14, x10, #0x4
     e88:      	ld1.s	{ v2 }[1], [x14]
     e8c:      	tbnz	w13, #0x2, 0xe04 <_llm_rows.packet_batch.blocks+0xa6c>
     e90:      	tbz	w13, #0x3, 0xe10 <_llm_rows.packet_batch.blocks+0xa78>
     e94:      	add	x14, x10, #0xc
     e98:      	ld1.s	{ v2 }[3], [x14]
     e9c:      	tbnz	w13, #0x4, 0xe14 <_llm_rows.packet_batch.blocks+0xa7c>
     ea0:      	tbz	w13, #0x5, 0xe20 <_llm_rows.packet_batch.blocks+0xa88>
     ea4:      	add	x14, x10, #0x14
     ea8:      	ld1.s	{ v1 }[1], [x14]
     eac:      	tbnz	w13, #0x6, 0xe24 <_llm_rows.packet_batch.blocks+0xa8c>
     eb0:      	tbz	w13, #0x7, 0xe30 <_llm_rows.packet_batch.blocks+0xa98>
     eb4:      	add	x10, x10, #0x1c
     eb8:      	ld1.s	{ v1 }[3], [x10]
     ebc:      	add	x9, x9, x11
     ec0:      	fmov	w10, s27
     ec4:      	movi.2d	v4, #0000000000000000
     ec8:      	movi.2d	v3, #0000000000000000
     ecc:      	tbnz	w10, #0x0, 0xe44 <_llm_rows.packet_batch.blocks+0xaac>
     ed0:      	tbz	w10, #0x1, 0xe4c <_llm_rows.packet_batch.blocks+0xab4>
     ed4:      	add	x11, x9, #0x4
     ed8:      	ld1.s	{ v4 }[1], [x11]
     edc:      	tbnz	w10, #0x2, 0xe50 <_llm_rows.packet_batch.blocks+0xab8>
     ee0:      	tbz	w10, #0x3, 0xe5c <_llm_rows.packet_batch.blocks+0xac4>
     ee4:      	add	x11, x9, #0xc
     ee8:      	ld1.s	{ v4 }[3], [x11]
     eec:      	tbnz	w10, #0x4, 0xe60 <_llm_rows.packet_batch.blocks+0xac8>
     ef0:      	tbz	w10, #0x5, 0xe6c <_llm_rows.packet_batch.blocks+0xad4>
     ef4:      	add	x11, x9, #0x14
     ef8:      	ld1.s	{ v3 }[1], [x11]
     efc:      	tbnz	w10, #0x6, 0xe70 <_llm_rows.packet_batch.blocks+0xad8>
     f00:      	tbz	w10, #0x7, 0xf0c <_llm_rows.packet_batch.blocks+0xb74>
     f04:      	add	x9, x9, #0x1c
     f08:      	ld1.s	{ v3 }[3], [x9]
     f0c:      	add.2d	v17, v19, v17
     f10:      	add.2d	v6, v6, v18
     f14:      	add.2d	v7, v7, v16
     f18:      	fmul.4s	v5, v22, v2
     f1c:      	fmul.4s	v16, v28, v4
     f20:      	fsub.4s	v5, v5, v16
     f24:      	stp	q23, q6, [sp, #0x180]
     f28:      	stp	q17, q7, [sp, #0x1a0]
     f2c:      	and	x9, x12, #0x7
     f30:      	add	x10, sp, #0x180
     f34:      	ldr	x9, [x10, x9, lsl #3]
     f38:      	sub	x9, x9, x12
     f3c:      	add	x9, x8, x9, lsl #2
     f40:      	fmov	w10, s27
     f44:      	tbz	w10, #0x0, 0xf8c <_llm_rows.packet_batch.blocks+0xbf4>
     f48:      	str	s5, [x9]
     f4c:      	tbnz	w10, #0x1, 0xf90 <_llm_rows.packet_batch.blocks+0xbf8>
     f50:      	tbz	w10, #0x2, 0xf9c <_llm_rows.packet_batch.blocks+0xc04>
     f54:      	add	x11, x9, #0x8
     f58:      	st1.s	{ v5 }[2], [x11]
     f5c:      	tbnz	w10, #0x3, 0xfa0 <_llm_rows.packet_batch.blocks+0xc08>
     f60:      	fmul.4s	v5, v0, v1
     f64:      	fmul.4s	v6, v26, v3
     f68:      	fsub.4s	v5, v5, v6
     f6c:      	tbz	w10, #0x4, 0xfb8 <_llm_rows.packet_batch.blocks+0xc20>
     f70:      	str	s5, [x9, #0x10]
     f74:      	tbnz	w10, #0x5, 0xfbc <_llm_rows.packet_batch.blocks+0xc24>
     f78:      	tbz	w10, #0x6, 0xfc8 <_llm_rows.packet_batch.blocks+0xc30>
     f7c:      	add	x11, x9, #0x18
     f80:      	st1.s	{ v5 }[2], [x11]
     f84:      	tbnz	w10, #0x7, 0xfcc <_llm_rows.packet_batch.blocks+0xc34>
     f88:      	b	0xfd4 <_llm_rows.packet_batch.blocks+0xc3c>
     f8c:      	tbz	w10, #0x1, 0xf50 <_llm_rows.packet_batch.blocks+0xbb8>
     f90:      	add	x11, x9, #0x4
     f94:      	st1.s	{ v5 }[1], [x11]
     f98:      	tbnz	w10, #0x2, 0xf54 <_llm_rows.packet_batch.blocks+0xbbc>
     f9c:      	tbz	w10, #0x3, 0xf60 <_llm_rows.packet_batch.blocks+0xbc8>
     fa0:      	add	x11, x9, #0xc
     fa4:      	st1.s	{ v5 }[3], [x11]
     fa8:      	fmul.4s	v5, v0, v1
     fac:      	fmul.4s	v6, v26, v3
     fb0:      	fsub.4s	v5, v5, v6
     fb4:      	tbnz	w10, #0x4, 0xf70 <_llm_rows.packet_batch.blocks+0xbd8>
     fb8:      	tbz	w10, #0x5, 0xf78 <_llm_rows.packet_batch.blocks+0xbe0>
     fbc:      	add	x11, x9, #0x14
     fc0:      	st1.s	{ v5 }[1], [x11]
     fc4:      	tbnz	w10, #0x6, 0xf7c <_llm_rows.packet_batch.blocks+0xbe4>
     fc8:      	tbz	w10, #0x7, 0xfd4 <_llm_rows.packet_batch.blocks+0xc3c>
     fcc:      	add	x9, x9, #0x1c
     fd0:      	st1.s	{ v5 }[3], [x9]
     fd4:      	fmul.4s	v4, v22, v4
     fd8:      	fmul.4s	v2, v28, v2
     fdc:      	fadd.4s	v2, v2, v4
     fe0:      	stp	q25, q24, [sp, #0x140]
     fe4:      	stp	q21, q20, [sp, #0x160]
     fe8:      	and	x9, x12, #0x7
     fec:      	add	x10, sp, #0x140
     ff0:      	ldr	x9, [x10, x9, lsl #3]
     ff4:      	sub	x9, x9, x12
     ff8:      	add	x8, x8, x9, lsl #2
     ffc:      	fmov	w9, s27
    1000:      	tbz	w9, #0x0, 0x1048 <_llm_rows.packet_batch.blocks+0xcb0>
    1004:      	str	s2, [x8]
    1008:      	tbnz	w9, #0x1, 0x104c <_llm_rows.packet_batch.blocks+0xcb4>
    100c:      	tbz	w9, #0x2, 0x1058 <_llm_rows.packet_batch.blocks+0xcc0>
    1010:      	add	x10, x8, #0x8
    1014:      	st1.s	{ v2 }[2], [x10]
    1018:      	tbnz	w9, #0x3, 0x105c <_llm_rows.packet_batch.blocks+0xcc4>
    101c:      	fmul.4s	v0, v0, v3
    1020:      	fmul.4s	v1, v26, v1
    1024:      	fadd.4s	v0, v1, v0
    1028:      	tbz	w9, #0x4, 0x1dc4 <_llm_rows.packet_batch.blocks+0x1a2c>
    102c:      	str	s0, [x8, #0x10]
    1030:      	tbnz	w9, #0x5, 0x1dc8 <_llm_rows.packet_batch.blocks+0x1a30>
    1034:      	tbz	w9, #0x6, 0x1dd4 <_llm_rows.packet_batch.blocks+0x1a3c>
    1038:      	add	x10, x8, #0x18
    103c:      	st1.s	{ v0 }[2], [x10]
    1040:      	tbnz	w9, #0x7, 0x1dd8 <_llm_rows.packet_batch.blocks+0x1a40>
    1044:      	b	0x470 <_llm_rows.packet_batch.blocks+0xd8>
    1048:      	tbz	w9, #0x1, 0x100c <_llm_rows.packet_batch.blocks+0xc74>
    104c:      	add	x10, x8, #0x4
    1050:      	st1.s	{ v2 }[1], [x10]
    1054:      	tbnz	w9, #0x2, 0x1010 <_llm_rows.packet_batch.blocks+0xc78>
    1058:      	tbz	w9, #0x3, 0x101c <_llm_rows.packet_batch.blocks+0xc84>
    105c:      	add	x10, x8, #0xc
    1060:      	st1.s	{ v2 }[3], [x10]
    1064:      	fmul.4s	v0, v0, v3
    1068:      	fmul.4s	v1, v26, v1
    106c:      	fadd.4s	v0, v1, v0
    1070:      	tbz	w9, #0x4, 0x1dc4 <_llm_rows.packet_batch.blocks+0x1a2c>
    1074:      	b	0x102c <_llm_rows.packet_batch.blocks+0xc94>
    1078:      	mov	x12, #0x0               ; =0
    107c:      	fmov	x15, d3
    1080:      	mov	w13, #0x4008            ; =16392
    1084:      	umaddl	x13, w15, w13, x11
    1088:      	add	x3, sp, #0x6, lsl #12   ; =0x6000
    108c:      	add	x3, x3, #0x4c0
    1090:      	mov	w4, #0x2004             ; =8196
    1094:      	b	0x10b8 <_llm_rows.packet_batch.blocks+0xd20>
    1098:      	add	x14, x3, x12
    109c:      	ldp	q24, q25, [x14]
    10a0:      	bif.16b	v3, v25, v6
    10a4:      	bif.16b	v19, v24, v0
    10a8:      	stp	q19, q3, [x14]
    10ac:      	add	x12, x12, #0x20
    10b0:      	cmp	x12, #0x2, lsl #12      ; =0x2000
    10b4:      	b.eq	0x1158 <_llm_rows.packet_batch.blocks+0xdc0>
    10b8:      	and.16b	v3, v22, v15
    10bc:      	addv.8h	h7, v3
    10c0:      	fmov	w16, s7
    10c4:      	add	x14, x13, x12
    10c8:      	movi.2d	v19, #0000000000000000
    10cc:      	movi.2d	v3, #0000000000000000
    10d0:      	tbz	w16, #0x0, 0x1114 <_llm_rows.packet_batch.blocks+0xd7c>
    10d4:      	ldr	s19, [x14]
    10d8:      	and	w16, w16, #0xff
    10dc:      	tbnz	w16, #0x1, 0x111c <_llm_rows.packet_batch.blocks+0xd84>
    10e0:      	tbz	w16, #0x2, 0x1128 <_llm_rows.packet_batch.blocks+0xd90>
    10e4:      	add	x17, x14, #0x8
    10e8:      	ld1.s	{ v19 }[2], [x17]
    10ec:      	tbnz	w16, #0x3, 0x112c <_llm_rows.packet_batch.blocks+0xd94>
    10f0:      	tbz	w16, #0x4, 0x1138 <_llm_rows.packet_batch.blocks+0xda0>
    10f4:      	add	x17, x14, #0x10
    10f8:      	ld1.s	{ v3 }[0], [x17]
    10fc:      	tbnz	w16, #0x5, 0x113c <_llm_rows.packet_batch.blocks+0xda4>
    1100:      	tbz	w16, #0x6, 0x1148 <_llm_rows.packet_batch.blocks+0xdb0>
    1104:      	add	x17, x14, #0x18
    1108:      	ld1.s	{ v3 }[2], [x17]
    110c:      	tbz	w16, #0x7, 0x1098 <_llm_rows.packet_batch.blocks+0xd00>
    1110:      	b	0x114c <_llm_rows.packet_batch.blocks+0xdb4>
    1114:      	and	w16, w16, #0xff
    1118:      	tbz	w16, #0x1, 0x10e0 <_llm_rows.packet_batch.blocks+0xd48>
    111c:      	add	x17, x14, #0x4
    1120:      	ld1.s	{ v19 }[1], [x17]
    1124:      	tbnz	w16, #0x2, 0x10e4 <_llm_rows.packet_batch.blocks+0xd4c>
    1128:      	tbz	w16, #0x3, 0x10f0 <_llm_rows.packet_batch.blocks+0xd58>
    112c:      	add	x17, x14, #0xc
    1130:      	ld1.s	{ v19 }[3], [x17]
    1134:      	tbnz	w16, #0x4, 0x10f4 <_llm_rows.packet_batch.blocks+0xd5c>
    1138:      	tbz	w16, #0x5, 0x1100 <_llm_rows.packet_batch.blocks+0xd68>
    113c:      	add	x17, x14, #0x14
    1140:      	ld1.s	{ v3 }[1], [x17]
    1144:      	tbnz	w16, #0x6, 0x1104 <_llm_rows.packet_batch.blocks+0xd6c>
    1148:      	tbz	w16, #0x7, 0x1098 <_llm_rows.packet_batch.blocks+0xd00>
    114c:      	add	x14, x14, #0x1c
    1150:      	ld1.s	{ v3 }[3], [x14]
    1154:      	b	0x1098 <_llm_rows.packet_batch.blocks+0xd00>
    1158:      	stp	d4, d11, [sp, #0xd0]
    115c:      	xtn.4h	v3, v0
    1160:      	uzp1.8b	v3, v3, v0
    1164:      	movi.2d	v19, #0000000000000000
    1168:      	mov.b	v19[0], v3[0]
    116c:      	adrp	x12, 0x1000 <_llm_rows.packet_batch.blocks+0xc68>
    1170:      	ldr	d31, [x12]
    1174:      	and.8b	v22, v19, v31
    1178:      	addv.8b	b22, v22
    117c:      	fmov	w13, s22
    1180:      	umaxv.8b	b22, v19
    1184:      	fmov	w16, s22
    1188:      	rbit	w12, w13
    118c:      	clz	w12, w12
    1190:      	tst	w16, #0x1
    1194:      	csel	w12, w12, wzr, ne
    1198:      	mov	w14, #0x800             ; =2048
    119c:      	dup.2d	v26, x14
    11a0:      	orr.16b	v11, v20, v26
    11a4:      	mov.16b	v1, v11
    11a8:      	umlal.2d	v1, v12, v10
    11ac:      	movi.2d	v24, #0000000000000000
    11b0:      	mov.b	v24[0], v3[0]
    11b4:      	ushll.2d	v3, v24, #0x0
    11b8:      	shl.2d	v3, v3, #0x3f
    11bc:      	cmlt.2d	v3, v3, #0
    11c0:      	str	q1, [sp, #0x60]
    11c4:      	and.16b	v3, v3, v1
    11c8:      	movi.2d	v4, #0000000000000000
    11cc:      	str	q4, [sp, #0x440]
    11d0:      	str	q4, [sp, #0x430]
    11d4:      	str	q4, [sp, #0x420]
    11d8:      	str	q3, [sp, #0x410]
    11dc:      	and	x14, x12, #0x7
    11e0:      	add	x17, sp, #0x410
    11e4:      	ldr	x14, [x17, x14, lsl #3]
    11e8:      	sub	x14, x14, x12
    11ec:      	add	x14, x11, x14, lsl #2
    11f0:      	movi.2d	v24, #0000000000000000
    11f4:      	movi.2d	v25, #0000000000000000
    11f8:      	tbz	w16, #0x0, 0x123c <_llm_rows.packet_batch.blocks+0xea4>
    11fc:      	ldr	s24, [x14]
    1200:      	tbnz	w13, #0x1, 0x1240 <_llm_rows.packet_batch.blocks+0xea8>
    1204:      	tbz	w13, #0x2, 0x124c <_llm_rows.packet_batch.blocks+0xeb4>
    1208:      	add	x16, x14, #0x8
    120c:      	ld1.s	{ v24 }[2], [x16]
    1210:      	tbnz	w13, #0x3, 0x1250 <_llm_rows.packet_batch.blocks+0xeb8>
    1214:      	tbz	w13, #0x4, 0x125c <_llm_rows.packet_batch.blocks+0xec4>
    1218:      	add	x16, x14, #0x10
    121c:      	ld1.s	{ v25 }[0], [x16]
    1220:      	tbnz	w13, #0x5, 0x1260 <_llm_rows.packet_batch.blocks+0xec8>
    1224:      	tbz	w13, #0x6, 0x126c <_llm_rows.packet_batch.blocks+0xed4>
    1228:      	add	x16, x14, #0x18
    122c:      	ld1.s	{ v25 }[2], [x16]
    1230:      	fmov	d22, d5
    1234:      	tbnz	w13, #0x7, 0x1274 <_llm_rows.packet_batch.blocks+0xedc>
    1238:      	b	0x127c <_llm_rows.packet_batch.blocks+0xee4>
    123c:      	tbz	w13, #0x1, 0x1204 <_llm_rows.packet_batch.blocks+0xe6c>
    1240:      	add	x16, x14, #0x4
    1244:      	ld1.s	{ v24 }[1], [x16]
    1248:      	tbnz	w13, #0x2, 0x1208 <_llm_rows.packet_batch.blocks+0xe70>
    124c:      	tbz	w13, #0x3, 0x1214 <_llm_rows.packet_batch.blocks+0xe7c>
    1250:      	add	x16, x14, #0xc
    1254:      	ld1.s	{ v24 }[3], [x16]
    1258:      	tbnz	w13, #0x4, 0x1218 <_llm_rows.packet_batch.blocks+0xe80>
    125c:      	tbz	w13, #0x5, 0x1224 <_llm_rows.packet_batch.blocks+0xe8c>
    1260:      	add	x16, x14, #0x14
    1264:      	ld1.s	{ v25 }[1], [x16]
    1268:      	tbnz	w13, #0x6, 0x1228 <_llm_rows.packet_batch.blocks+0xe90>
    126c:      	fmov	d22, d5
    1270:      	tbz	w13, #0x7, 0x127c <_llm_rows.packet_batch.blocks+0xee4>
    1274:      	add	x14, x14, #0x1c
    1278:      	ld1.s	{ v25 }[3], [x14]
    127c:      	mov	x17, #0x0               ; =0
    1280:      	mov.16b	v18, v16
    1284:      	orr.16b	v1, v16, v26
    1288:      	mov.16b	v16, v13
    128c:      	orr.16b	v14, v13, v26
    1290:      	mov.16b	v13, v17
    1294:      	orr.16b	v17, v17, v26
    1298:      	umull.2d	v9, v12, v10
    129c:      	fmov	d3, d10
    12a0:      	ldp	d5, d4, [sp, #0xd0]
    12a4:      	umull.2d	v10, v4, v10
    12a8:      	umull.2d	v15, v5, v3
    12ac:      	umull.2d	v28, v22, v3
    12b0:      	mov.16b	v27, v17
    12b4:      	umlal.2d	v27, v5, v3
    12b8:      	mov.16b	v5, v14
    12bc:      	umlal.2d	v5, v4, v3
    12c0:      	stp	q5, q27, [sp, #0x40]
    12c4:      	mov.16b	v4, v1
    12c8:      	umlal.2d	v4, v22, v3
    12cc:      	str	q4, [sp, #0x30]
    12d0:      	adrp	x14, 0x1000 <_llm_rows.packet_batch.blocks+0xc68>
    12d4:      	ldr	q3, [x14]
    12d8:      	mov	w14, #0x2000            ; =8192
    12dc:      	dup.2d	v26, x14
    12e0:      	sshll.2d	v27, v0, #0x0
    12e4:      	bif.16b	v3, v26, v27
    12e8:      	adrp	x14, 0x1000 <_llm_rows.packet_batch.blocks+0xc68>
    12ec:      	ldr	q27, [x14]
    12f0:      	sshll.2d	v29, v6, #0x0
    12f4:      	bif.16b	v27, v26, v29
    12f8:      	adrp	x14, 0x1000 <_llm_rows.packet_batch.blocks+0xc68>
    12fc:      	ldr	q29, [x14]
    1300:      	bsl.16b	v23, v29, v26
    1304:      	adrp	x14, 0x1000 <_llm_rows.packet_batch.blocks+0xc68>
    1308:      	ldr	q29, [x14]
    130c:      	bsl.16b	v21, v29, v26
    1310:      	stp	q27, q21, [sp, #0x3f0]
    1314:      	stp	q3, q23, [sp, #0x3d0]
    1318:      	and	x14, x12, #0x7
    131c:      	add	x16, sp, #0x3d0
    1320:      	ldr	x14, [x16, x14, lsl #3]
    1324:      	sub	x14, x14, x12, lsl #2
    1328:      	tst	w13, #0xff
    132c:      	csel	x13, xzr, x14, eq
    1330:      	add	x14, x3, x13
    1334:      	ldp	q3, q21, [x14]
    1338:      	zip2.8b	v23, v19, v0
    133c:      	ushll.4s	v23, v23, #0x0
    1340:      	shl.4s	v23, v23, #0x1f
    1344:      	cmlt.4s	v23, v23, #0
    1348:      	mov.16b	v4, v23
    134c:      	bsl.16b	v4, v25, v21
    1350:      	zip1.8b	v21, v19, v0
    1354:      	ushll.4s	v21, v21, #0x0
    1358:      	shl.4s	v21, v21, #0x1f
    135c:      	cmlt.4s	v21, v21, #0
    1360:      	bit.16b	v3, v24, v21
    1364:      	str	q3, [sp, #0xc0]
    1368:      	stp	q3, q4, [x14]
    136c:      	str	q4, [sp, #0x70]
    1370:      	fmov	x14, d9
    1374:      	ushll2.2d	v3, v6, #0x0
    1378:      	mov	w16, #0x1               ; =1
    137c:      	dup.2d	v21, x16
    1380:      	and.16b	v24, v3, v21
    1384:      	ushll2.2d	v3, v0, #0x0
    1388:      	and.16b	v25, v3, v21
    138c:      	ushll.2d	v3, v6, #0x0
    1390:      	and.16b	v26, v3, v21
    1394:      	ushll.2d	v3, v0, #0x0
    1398:      	and.16b	v27, v3, v21
    139c:      	lsl	x14, x14, #2
    13a0:      	add	x16, x11, x4
    13a4:      	add	x16, x16, x14
    13a8:      	movi.2d	v21, #0000000000000000
    13ac:      	movi.2d	v23, #0000000000000000
    13b0:      	movi.2d	v29, #0000000000000000
    13b4:      	movi.2d	v30, #0000000000000000
    13b8:      	b	0x13ec <_llm_rows.packet_batch.blocks+0x1054>
    13bc:      	add	x17, x27, x17
    13c0:      	ldp	q4, q5, [x17]
    13c4:      	bit.16b	v5, v8, v6
    13c8:      	bif.16b	v3, v4, v0
    13cc:      	stp	q3, q5, [x17]
    13d0:      	add.2d	v23, v23, v25
    13d4:      	add.2d	v29, v29, v26
    13d8:      	add.2d	v30, v30, v24
    13dc:      	add.2d	v21, v21, v27
    13e0:      	fmov	x17, d21
    13e4:      	cmp	x17, #0x100
    13e8:      	b.ge	0x1488 <_llm_rows.packet_batch.blocks+0x10f0>
    13ec:      	fmov	w1, s7
    13f0:      	lsl	x17, x17, #5
    13f4:      	add	x0, x16, x17
    13f8:      	movi.2d	v3, #0000000000000000
    13fc:      	movi.2d	v8, #0000000000000000
    1400:      	tbz	w1, #0x0, 0x1444 <_llm_rows.packet_batch.blocks+0x10ac>
    1404:      	ldr	s3, [x0]
    1408:      	and	w1, w1, #0xff
    140c:      	tbnz	w1, #0x1, 0x144c <_llm_rows.packet_batch.blocks+0x10b4>
    1410:      	tbz	w1, #0x2, 0x1458 <_llm_rows.packet_batch.blocks+0x10c0>
    1414:      	add	x2, x0, #0x8
    1418:      	ld1.s	{ v3 }[2], [x2]
    141c:      	tbnz	w1, #0x3, 0x145c <_llm_rows.packet_batch.blocks+0x10c4>
    1420:      	tbz	w1, #0x4, 0x1468 <_llm_rows.packet_batch.blocks+0x10d0>
    1424:      	add	x2, x0, #0x10
    1428:      	ld1.s	{ v8 }[0], [x2]
    142c:      	tbnz	w1, #0x5, 0x146c <_llm_rows.packet_batch.blocks+0x10d4>
    1430:      	tbz	w1, #0x6, 0x1478 <_llm_rows.packet_batch.blocks+0x10e0>
    1434:      	add	x2, x0, #0x18
    1438:      	ld1.s	{ v8 }[2], [x2]
    143c:      	tbz	w1, #0x7, 0x13bc <_llm_rows.packet_batch.blocks+0x1024>
    1440:      	b	0x147c <_llm_rows.packet_batch.blocks+0x10e4>
    1444:      	and	w1, w1, #0xff
    1448:      	tbz	w1, #0x1, 0x1410 <_llm_rows.packet_batch.blocks+0x1078>
    144c:      	add	x2, x0, #0x4
    1450:      	ld1.s	{ v3 }[1], [x2]
    1454:      	tbnz	w1, #0x2, 0x1414 <_llm_rows.packet_batch.blocks+0x107c>
    1458:      	tbz	w1, #0x3, 0x1420 <_llm_rows.packet_batch.blocks+0x1088>
    145c:      	add	x2, x0, #0xc
    1460:      	ld1.s	{ v3 }[3], [x2]
    1464:      	tbnz	w1, #0x4, 0x1424 <_llm_rows.packet_batch.blocks+0x108c>
    1468:      	tbz	w1, #0x5, 0x1430 <_llm_rows.packet_batch.blocks+0x1098>
    146c:      	add	x2, x0, #0x14
    1470:      	ld1.s	{ v8 }[1], [x2]
    1474:      	tbnz	w1, #0x6, 0x1434 <_llm_rows.packet_batch.blocks+0x109c>
    1478:      	tbz	w1, #0x7, 0x13bc <_llm_rows.packet_batch.blocks+0x1024>
    147c:      	add	x0, x0, #0x1c
    1480:      	ld1.s	{ v8 }[3], [x0]
    1484:      	b	0x13bc <_llm_rows.packet_batch.blocks+0x1024>
    1488:      	add.2d	v3, v20, v9
    148c:      	add.2d	v4, v16, v10
    1490:      	add.2d	v5, v13, v15
    1494:      	add.2d	v16, v18, v28
    1498:      	mov	w16, #0x1001            ; =4097
    149c:      	dup.2d	v20, x16
    14a0:      	add.2d	v18, v16, v20
    14a4:      	add.2d	v21, v5, v20
    14a8:      	add.2d	v16, v4, v20
    14ac:      	mov	b4, v19[0]
    14b0:      	mov.b	v4[4], v19[1]
    14b4:      	add.2d	v20, v3, v20
    14b8:      	ushll.2d	v3, v4, #0x0
    14bc:      	shl.2d	v3, v3, #0x3f
    14c0:      	cmlt.2d	v3, v3, #0
    14c4:      	and.16b	v3, v3, v20
    14c8:      	mov	b4, v19[2]
    14cc:      	mov.b	v4[4], v19[3]
    14d0:      	ushll.2d	v4, v4, #0x0
    14d4:      	shl.2d	v4, v4, #0x3f
    14d8:      	cmlt.2d	v4, v4, #0
    14dc:      	and.16b	v4, v4, v16
    14e0:      	mov	b5, v19[4]
    14e4:      	mov.b	v5[4], v19[5]
    14e8:      	ushll.2d	v5, v5, #0x0
    14ec:      	shl.2d	v5, v5, #0x3f
    14f0:      	cmlt.2d	v5, v5, #0
    14f4:      	stp	q21, q18, [sp, #0x10]
    14f8:      	and.16b	v5, v5, v21
    14fc:      	mov	b21, v19[6]
    1500:      	mov.b	v21[4], v19[7]
    1504:      	ushll.2d	v21, v21, #0x0
    1508:      	shl.2d	v21, v21, #0x3f
    150c:      	cmlt.2d	v21, v21, #0
    1510:      	and.16b	v21, v21, v18
    1514:      	shl.8b	v23, v19, #0x7
    1518:      	cmlt.8b	v23, v23, #0
    151c:      	and.8b	v23, v23, v31
    1520:      	addv.8b	b31, v23
    1524:      	fmov	w16, s31
    1528:      	stp	q5, q21, [sp, #0x3a0]
    152c:      	stp	q3, q4, [sp, #0x380]
    1530:      	and	x17, x12, #0x7
    1534:      	add	x0, sp, #0x380
    1538:      	ldr	x17, [x0, x17, lsl #3]
    153c:      	sub	x17, x17, x12
    1540:      	add	x11, x11, x17, lsl #2
    1544:      	movi.2d	v21, #0000000000000000
    1548:      	movi.2d	v3, #0000000000000000
    154c:      	tbz	w16, #0x0, 0x1590 <_llm_rows.packet_batch.blocks+0x11f8>
    1550:      	ldr	s21, [x11]
    1554:      	ldr	q15, [sp, #0x120]
    1558:      	tbnz	w16, #0x1, 0x1598 <_llm_rows.packet_batch.blocks+0x1200>
    155c:      	tbz	w16, #0x2, 0x15a4 <_llm_rows.packet_batch.blocks+0x120c>
    1560:      	add	x17, x11, #0x8
    1564:      	ld1.s	{ v21 }[2], [x17]
    1568:      	tbnz	w16, #0x3, 0x15a8 <_llm_rows.packet_batch.blocks+0x1210>
    156c:      	tbz	w16, #0x4, 0x15b4 <_llm_rows.packet_batch.blocks+0x121c>
    1570:      	add	x17, x11, #0x10
    1574:      	ld1.s	{ v3 }[0], [x17]
    1578:      	tbnz	w16, #0x5, 0x15b8 <_llm_rows.packet_batch.blocks+0x1220>
    157c:      	tbz	w16, #0x6, 0x15c4 <_llm_rows.packet_batch.blocks+0x122c>
    1580:      	add	x17, x11, #0x18
    1584:      	ld1.s	{ v3 }[2], [x17]
    1588:      	tbnz	w16, #0x7, 0x15c8 <_llm_rows.packet_batch.blocks+0x1230>
    158c:      	b	0x15d0 <_llm_rows.packet_batch.blocks+0x1238>
    1590:      	ldr	q15, [sp, #0x120]
    1594:      	tbz	w16, #0x1, 0x155c <_llm_rows.packet_batch.blocks+0x11c4>
    1598:      	add	x17, x11, #0x4
    159c:      	ld1.s	{ v21 }[1], [x17]
    15a0:      	tbnz	w16, #0x2, 0x1560 <_llm_rows.packet_batch.blocks+0x11c8>
    15a4:      	tbz	w16, #0x3, 0x156c <_llm_rows.packet_batch.blocks+0x11d4>
    15a8:      	add	x17, x11, #0xc
    15ac:      	ld1.s	{ v21 }[3], [x17]
    15b0:      	tbnz	w16, #0x4, 0x1570 <_llm_rows.packet_batch.blocks+0x11d8>
    15b4:      	tbz	w16, #0x5, 0x157c <_llm_rows.packet_batch.blocks+0x11e4>
    15b8:      	add	x17, x11, #0x14
    15bc:      	ld1.s	{ v3 }[1], [x17]
    15c0:      	tbnz	w16, #0x6, 0x1580 <_llm_rows.packet_batch.blocks+0x11e8>
    15c4:      	tbz	w16, #0x7, 0x15d0 <_llm_rows.packet_batch.blocks+0x1238>
    15c8:      	add	x11, x11, #0x1c
    15cc:      	ld1.s	{ v3 }[3], [x11]
    15d0:      	mov	x16, #0x0               ; =0
    15d4:      	add	x11, x27, x13
    15d8:      	ldp	q4, q5, [x11]
    15dc:      	zip2.8b	v23, v19, v0
    15e0:      	ushll.4s	v23, v23, #0x0
    15e4:      	shl.4s	v23, v23, #0x1f
    15e8:      	cmlt.4s	v23, v23, #0
    15ec:      	mov.16b	v9, v23
    15f0:      	bsl.16b	v9, v3, v5
    15f4:      	zip1.8b	v3, v19, v0
    15f8:      	ushll.4s	v3, v3, #0x0
    15fc:      	shl.4s	v3, v3, #0x1f
    1600:      	cmlt.4s	v3, v3, #0
    1604:      	mov.16b	v10, v3
    1608:      	bsl.16b	v10, v21, v4
    160c:      	stp	q10, q9, [x11]
    1610:      	umaddl	x11, w15, w4, x10
    1614:      	movi.2d	v28, #0000000000000000
    1618:      	movi.2d	v21, #0000000000000000
    161c:      	movi.2d	v23, #0000000000000000
    1620:      	movi.2d	v29, #0000000000000000
    1624:      	b	0x1658 <_llm_rows.packet_batch.blocks+0x12c0>
    1628:      	add	x15, x19, x15
    162c:      	ldp	q4, q5, [x15]
    1630:      	bit.16b	v5, v30, v6
    1634:      	bif.16b	v3, v4, v0
    1638:      	stp	q3, q5, [x15]
    163c:      	add.2d	v21, v21, v25
    1640:      	add.2d	v23, v23, v26
    1644:      	add.2d	v29, v29, v24
    1648:      	add.2d	v28, v28, v27
    164c:      	fmov	x16, d28
    1650:      	cmp	x16, #0x100
    1654:      	b.ge	0x16f4 <_llm_rows.packet_batch.blocks+0x135c>
    1658:      	fmov	w17, s7
    165c:      	lsl	x15, x16, #5
    1660:      	add	x16, x11, x15
    1664:      	movi.2d	v3, #0000000000000000
    1668:      	movi.2d	v30, #0000000000000000
    166c:      	tbz	w17, #0x0, 0x16b0 <_llm_rows.packet_batch.blocks+0x1318>
    1670:      	ldr	s3, [x16]
    1674:      	and	w17, w17, #0xff
    1678:      	tbnz	w17, #0x1, 0x16b8 <_llm_rows.packet_batch.blocks+0x1320>
    167c:      	tbz	w17, #0x2, 0x16c4 <_llm_rows.packet_batch.blocks+0x132c>
    1680:      	add	x0, x16, #0x8
    1684:      	ld1.s	{ v3 }[2], [x0]
    1688:      	tbnz	w17, #0x3, 0x16c8 <_llm_rows.packet_batch.blocks+0x1330>
    168c:      	tbz	w17, #0x4, 0x16d4 <_llm_rows.packet_batch.blocks+0x133c>
    1690:      	add	x0, x16, #0x10
    1694:      	ld1.s	{ v30 }[0], [x0]
    1698:      	tbnz	w17, #0x5, 0x16d8 <_llm_rows.packet_batch.blocks+0x1340>
    169c:      	tbz	w17, #0x6, 0x16e4 <_llm_rows.packet_batch.blocks+0x134c>
    16a0:      	add	x0, x16, #0x18
    16a4:      	ld1.s	{ v30 }[2], [x0]
    16a8:      	tbz	w17, #0x7, 0x1628 <_llm_rows.packet_batch.blocks+0x1290>
    16ac:      	b	0x16e8 <_llm_rows.packet_batch.blocks+0x1350>
    16b0:      	and	w17, w17, #0xff
    16b4:      	tbz	w17, #0x1, 0x167c <_llm_rows.packet_batch.blocks+0x12e4>
    16b8:      	add	x0, x16, #0x4
    16bc:      	ld1.s	{ v3 }[1], [x0]
    16c0:      	tbnz	w17, #0x2, 0x1680 <_llm_rows.packet_batch.blocks+0x12e8>
    16c4:      	tbz	w17, #0x3, 0x168c <_llm_rows.packet_batch.blocks+0x12f4>
    16c8:      	add	x0, x16, #0xc
    16cc:      	ld1.s	{ v3 }[3], [x0]
    16d0:      	tbnz	w17, #0x4, 0x1690 <_llm_rows.packet_batch.blocks+0x12f8>
    16d4:      	tbz	w17, #0x5, 0x169c <_llm_rows.packet_batch.blocks+0x1304>
    16d8:      	add	x0, x16, #0x14
    16dc:      	ld1.s	{ v30 }[1], [x0]
    16e0:      	tbnz	w17, #0x6, 0x16a0 <_llm_rows.packet_batch.blocks+0x1308>
    16e4:      	tbz	w17, #0x7, 0x1628 <_llm_rows.packet_batch.blocks+0x1290>
    16e8:      	add	x16, x16, #0x1c
    16ec:      	ld1.s	{ v30 }[3], [x16]
    16f0:      	b	0x1628 <_llm_rows.packet_batch.blocks+0x1290>
    16f4:      	umlal.2d	v1, v22, v2
    16f8:      	ldp	d4, d3, [sp, #0xd0]
    16fc:      	umlal.2d	v17, v4, v2
    1700:      	umlal.2d	v14, v3, v2
    1704:      	umlal.2d	v11, v12, v2
    1708:      	mov	b3, v19[0]
    170c:      	mov.b	v3[4], v19[1]
    1710:      	ushll.2d	v3, v3, #0x0
    1714:      	shl.2d	v3, v3, #0x3f
    1718:      	cmlt.2d	v3, v3, #0
    171c:      	and.16b	v3, v3, v11
    1720:      	mov	b4, v19[2]
    1724:      	mov.b	v4[4], v19[3]
    1728:      	ushll.2d	v4, v4, #0x0
    172c:      	shl.2d	v4, v4, #0x3f
    1730:      	cmlt.2d	v4, v4, #0
    1734:      	and.16b	v4, v4, v14
    1738:      	mov	b5, v19[4]
    173c:      	mov.b	v5[4], v19[5]
    1740:      	ushll.2d	v5, v5, #0x0
    1744:      	shl.2d	v5, v5, #0x3f
    1748:      	cmlt.2d	v5, v5, #0
    174c:      	mov	b21, v19[6]
    1750:      	mov.b	v21[4], v19[7]
    1754:      	and.16b	v5, v5, v17
    1758:      	ushll.2d	v21, v21, #0x0
    175c:      	shl.2d	v21, v21, #0x3f
    1760:      	cmlt.2d	v21, v21, #0
    1764:      	and.16b	v21, v21, v1
    1768:      	stp	q5, q21, [sp, #0x350]
    176c:      	stp	q3, q4, [sp, #0x330]
    1770:      	and	x11, x12, #0x7
    1774:      	add	x15, sp, #0x330
    1778:      	ldr	x11, [x15, x11, lsl #3]
    177c:      	fmov	w15, s31
    1780:      	sub	x11, x11, x12
    1784:      	lsl	x11, x11, #2
    1788:      	add	x10, x10, x11
    178c:      	movi.2d	v3, #0000000000000000
    1790:      	movi.2d	v4, #0000000000000000
    1794:      	tbz	w15, #0x0, 0x17d8 <_llm_rows.packet_batch.blocks+0x1440>
    1798:      	ldr	s3, [x10]
    179c:      	ldr	q17, [sp, #0x70]
    17a0:      	tbnz	w15, #0x1, 0x17e0 <_llm_rows.packet_batch.blocks+0x1448>
    17a4:      	tbz	w15, #0x2, 0x17ec <_llm_rows.packet_batch.blocks+0x1454>
    17a8:      	add	x16, x10, #0x8
    17ac:      	ld1.s	{ v3 }[2], [x16]
    17b0:      	tbnz	w15, #0x3, 0x17f0 <_llm_rows.packet_batch.blocks+0x1458>
    17b4:      	tbz	w15, #0x4, 0x17fc <_llm_rows.packet_batch.blocks+0x1464>
    17b8:      	add	x16, x10, #0x10
    17bc:      	ld1.s	{ v4 }[0], [x16]
    17c0:      	tbnz	w15, #0x5, 0x1800 <_llm_rows.packet_batch.blocks+0x1468>
    17c4:      	tbz	w15, #0x6, 0x180c <_llm_rows.packet_batch.blocks+0x1474>
    17c8:      	add	x16, x10, #0x18
    17cc:      	ld1.s	{ v4 }[2], [x16]
    17d0:      	tbnz	w15, #0x7, 0x1810 <_llm_rows.packet_batch.blocks+0x1478>
    17d4:      	b	0x1818 <_llm_rows.packet_batch.blocks+0x1480>
    17d8:      	ldr	q17, [sp, #0x70]
    17dc:      	tbz	w15, #0x1, 0x17a4 <_llm_rows.packet_batch.blocks+0x140c>
    17e0:      	add	x16, x10, #0x4
    17e4:      	ld1.s	{ v3 }[1], [x16]
    17e8:      	tbnz	w15, #0x2, 0x17a8 <_llm_rows.packet_batch.blocks+0x1410>
    17ec:      	tbz	w15, #0x3, 0x17b4 <_llm_rows.packet_batch.blocks+0x141c>
    17f0:      	add	x16, x10, #0xc
    17f4:      	ld1.s	{ v3 }[3], [x16]
    17f8:      	tbnz	w15, #0x4, 0x17b8 <_llm_rows.packet_batch.blocks+0x1420>
    17fc:      	tbz	w15, #0x5, 0x17c4 <_llm_rows.packet_batch.blocks+0x142c>
    1800:      	add	x16, x10, #0x14
    1804:      	ld1.s	{ v4 }[1], [x16]
    1808:      	tbnz	w15, #0x6, 0x17c8 <_llm_rows.packet_batch.blocks+0x1430>
    180c:      	tbz	w15, #0x7, 0x1818 <_llm_rows.packet_batch.blocks+0x1480>
    1810:      	add	x10, x10, #0x1c
    1814:      	ld1.s	{ v4 }[3], [x10]
    1818:      	mov	x15, #0x0               ; =0
    181c:      	umull.2d	v5, v12, v2
    1820:      	add	x10, x19, x13
    1824:      	ldp	q2, q1, [x10]
    1828:      	zip2.8b	v21, v19, v0
    182c:      	ushll.4s	v21, v21, #0x0
    1830:      	shl.4s	v21, v21, #0x1f
    1834:      	cmlt.4s	v21, v21, #0
    1838:      	bit.16b	v1, v4, v21
    183c:      	zip1.8b	v4, v19, v0
    1840:      	ushll.4s	v4, v4, #0x0
    1844:      	shl.4s	v4, v4, #0x1f
    1848:      	cmlt.4s	v4, v4, #0
    184c:      	bit.16b	v2, v3, v4
    1850:      	stp	q2, q1, [x10]
    1854:      	fmov	x10, d5
    1858:      	add	x10, x9, x10, lsl #2
    185c:      	movi.2d	v3, #0000000000000000
    1860:      	movi.2d	v4, #0000000000000000
    1864:      	movi.2d	v5, #0000000000000000
    1868:      	movi.2d	v21, #0000000000000000
    186c:      	b	0x18a0 <_llm_rows.packet_batch.blocks+0x1508>
    1870:      	add	x15, x21, x15
    1874:      	ldp	q29, q30, [x15]
    1878:      	bif.16b	v28, v30, v6
    187c:      	bif.16b	v23, v29, v0
    1880:      	stp	q23, q28, [x15]
    1884:      	add.2d	v4, v4, v25
    1888:      	add.2d	v5, v5, v26
    188c:      	add.2d	v21, v21, v24
    1890:      	add.2d	v3, v3, v27
    1894:      	fmov	x15, d3
    1898:      	cmp	x15, #0x100
    189c:      	b.ge	0x193c <_llm_rows.packet_batch.blocks+0x15a4>
    18a0:      	fmov	w17, s7
    18a4:      	lsl	x15, x15, #5
    18a8:      	add	x16, x10, x15
    18ac:      	movi.2d	v23, #0000000000000000
    18b0:      	movi.2d	v28, #0000000000000000
    18b4:      	tbz	w17, #0x0, 0x18f8 <_llm_rows.packet_batch.blocks+0x1560>
    18b8:      	ldr	s23, [x16]
    18bc:      	and	w17, w17, #0xff
    18c0:      	tbnz	w17, #0x1, 0x1900 <_llm_rows.packet_batch.blocks+0x1568>
    18c4:      	tbz	w17, #0x2, 0x190c <_llm_rows.packet_batch.blocks+0x1574>
    18c8:      	add	x0, x16, #0x8
    18cc:      	ld1.s	{ v23 }[2], [x0]
    18d0:      	tbnz	w17, #0x3, 0x1910 <_llm_rows.packet_batch.blocks+0x1578>
    18d4:      	tbz	w17, #0x4, 0x191c <_llm_rows.packet_batch.blocks+0x1584>
    18d8:      	add	x0, x16, #0x10
    18dc:      	ld1.s	{ v28 }[0], [x0]
    18e0:      	tbnz	w17, #0x5, 0x1920 <_llm_rows.packet_batch.blocks+0x1588>
    18e4:      	tbz	w17, #0x6, 0x192c <_llm_rows.packet_batch.blocks+0x1594>
    18e8:      	add	x0, x16, #0x18
    18ec:      	ld1.s	{ v28 }[2], [x0]
    18f0:      	tbz	w17, #0x7, 0x1870 <_llm_rows.packet_batch.blocks+0x14d8>
    18f4:      	b	0x1930 <_llm_rows.packet_batch.blocks+0x1598>
    18f8:      	and	w17, w17, #0xff
    18fc:      	tbz	w17, #0x1, 0x18c4 <_llm_rows.packet_batch.blocks+0x152c>
    1900:      	add	x0, x16, #0x4
    1904:      	ld1.s	{ v23 }[1], [x0]
    1908:      	tbnz	w17, #0x2, 0x18c8 <_llm_rows.packet_batch.blocks+0x1530>
    190c:      	tbz	w17, #0x3, 0x18d4 <_llm_rows.packet_batch.blocks+0x153c>
    1910:      	add	x0, x16, #0xc
    1914:      	ld1.s	{ v23 }[3], [x0]
    1918:      	tbnz	w17, #0x4, 0x18d8 <_llm_rows.packet_batch.blocks+0x1540>
    191c:      	tbz	w17, #0x5, 0x18e4 <_llm_rows.packet_batch.blocks+0x154c>
    1920:      	add	x0, x16, #0x14
    1924:      	ld1.s	{ v28 }[1], [x0]
    1928:      	tbnz	w17, #0x6, 0x18e8 <_llm_rows.packet_batch.blocks+0x1550>
    192c:      	tbz	w17, #0x7, 0x1870 <_llm_rows.packet_batch.blocks+0x14d8>
    1930:      	add	x16, x16, #0x1c
    1934:      	ld1.s	{ v28 }[3], [x16]
    1938:      	b	0x1870 <_llm_rows.packet_batch.blocks+0x14d8>
    193c:      	add	x9, x9, x11
    1940:      	fmov	w10, s31
    1944:      	movi.2d	v4, #0000000000000000
    1948:      	movi.2d	v3, #0000000000000000
    194c:      	tbz	w10, #0x0, 0x198c <_llm_rows.packet_batch.blocks+0x15f4>
    1950:      	ldr	s4, [x9]
    1954:      	tbnz	w10, #0x1, 0x1990 <_llm_rows.packet_batch.blocks+0x15f8>
    1958:      	tbz	w10, #0x2, 0x199c <_llm_rows.packet_batch.blocks+0x1604>
    195c:      	add	x11, x9, #0x8
    1960:      	ld1.s	{ v4 }[2], [x11]
    1964:      	tbnz	w10, #0x3, 0x19a0 <_llm_rows.packet_batch.blocks+0x1608>
    1968:      	tbz	w10, #0x4, 0x19ac <_llm_rows.packet_batch.blocks+0x1614>
    196c:      	add	x11, x9, #0x10
    1970:      	ld1.s	{ v3 }[0], [x11]
    1974:      	tbnz	w10, #0x5, 0x19b0 <_llm_rows.packet_batch.blocks+0x1618>
    1978:      	tbz	w10, #0x6, 0x19bc <_llm_rows.packet_batch.blocks+0x1624>
    197c:      	add	x11, x9, #0x18
    1980:      	ld1.s	{ v3 }[2], [x11]
    1984:      	tbnz	w10, #0x7, 0x19c0 <_llm_rows.packet_batch.blocks+0x1628>
    1988:      	b	0x19c8 <_llm_rows.packet_batch.blocks+0x1630>
    198c:      	tbz	w10, #0x1, 0x1958 <_llm_rows.packet_batch.blocks+0x15c0>
    1990:      	add	x11, x9, #0x4
    1994:      	ld1.s	{ v4 }[1], [x11]
    1998:      	tbnz	w10, #0x2, 0x195c <_llm_rows.packet_batch.blocks+0x15c4>
    199c:      	tbz	w10, #0x3, 0x1968 <_llm_rows.packet_batch.blocks+0x15d0>
    19a0:      	add	x11, x9, #0xc
    19a4:      	ld1.s	{ v4 }[3], [x11]
    19a8:      	tbnz	w10, #0x4, 0x196c <_llm_rows.packet_batch.blocks+0x15d4>
    19ac:      	tbz	w10, #0x5, 0x1978 <_llm_rows.packet_batch.blocks+0x15e0>
    19b0:      	add	x11, x9, #0x14
    19b4:      	ld1.s	{ v3 }[1], [x11]
    19b8:      	tbnz	w10, #0x6, 0x197c <_llm_rows.packet_batch.blocks+0x15e4>
    19bc:      	tbz	w10, #0x7, 0x19c8 <_llm_rows.packet_batch.blocks+0x1630>
    19c0:      	add	x9, x9, #0x1c
    19c4:      	ld1.s	{ v3 }[3], [x9]
    19c8:      	mov	x10, #0x0               ; =0
    19cc:      	add	x9, x21, x13
    19d0:      	ldp	q5, q21, [x9]
    19d4:      	zip2.8b	v23, v19, v0
    19d8:      	ushll.4s	v23, v23, #0x0
    19dc:      	shl.4s	v23, v23, #0x1f
    19e0:      	cmlt.4s	v23, v23, #0
    19e4:      	bif.16b	v3, v21, v23
    19e8:      	zip1.8b	v21, v19, v0
    19ec:      	ushll.4s	v21, v21, #0x0
    19f0:      	shl.4s	v21, v21, #0x1f
    19f4:      	cmlt.4s	v21, v21, #0
    19f8:      	bif.16b	v4, v5, v21
    19fc:      	stp	q4, q3, [x9]
    1a00:      	add	x9, x8, x14
    1a04:      	movi.2d	v5, #0000000000000000
    1a08:      	movi.2d	v21, #0000000000000000
    1a0c:      	movi.2d	v23, #0000000000000000
    1a10:      	movi.2d	v28, #0000000000000000
    1a14:      	b	0x1a34 <_llm_rows.packet_batch.blocks+0x169c>
    1a18:      	add.2d	v21, v21, v25
    1a1c:      	add.2d	v23, v23, v26
    1a20:      	add.2d	v28, v28, v24
    1a24:      	add.2d	v5, v5, v27
    1a28:      	fmov	x10, d5
    1a2c:      	cmp	x10, #0x100
    1a30:      	b.ge	0x1b14 <_llm_rows.packet_batch.blocks+0x177c>
    1a34:      	fmov	w11, s7
    1a38:      	lsl	x10, x10, #5
    1a3c:      	add	x13, x3, x10
    1a40:      	ldp	q8, q29, [x13]
    1a44:      	add	x13, x19, x10
    1a48:      	ldp	q11, q30, [x13]
    1a4c:      	fmul.4s	v12, v8, v11
    1a50:      	add	x13, x27, x10
    1a54:      	ldp	q13, q8, [x13]
    1a58:      	add	x13, x21, x10
    1a5c:      	ldp	q14, q11, [x13]
    1a60:      	fmul.4s	v13, v13, v14
    1a64:      	fsub.4s	v12, v12, v13
    1a68:      	and.16b	v12, v0, v12
    1a6c:      	add	x10, x9, x10
    1a70:      	tbz	w11, #0x0, 0x1ac0 <_llm_rows.packet_batch.blocks+0x1728>
    1a74:      	str	s12, [x10]
    1a78:      	and	w11, w11, #0xff
    1a7c:      	tbnz	w11, #0x1, 0x1ac8 <_llm_rows.packet_batch.blocks+0x1730>
    1a80:      	tbz	w11, #0x2, 0x1ad4 <_llm_rows.packet_batch.blocks+0x173c>
    1a84:      	add	x13, x10, #0x8
    1a88:      	st1.s	{ v12 }[2], [x13]
    1a8c:      	tbnz	w11, #0x3, 0x1ad8 <_llm_rows.packet_batch.blocks+0x1740>
    1a90:      	fmul.4s	v29, v29, v30
    1a94:      	fmul.4s	v30, v8, v11
    1a98:      	fsub.4s	v29, v29, v30
    1a9c:      	and.16b	v29, v6, v29
    1aa0:      	tbz	w11, #0x4, 0x1af4 <_llm_rows.packet_batch.blocks+0x175c>
    1aa4:      	str	s29, [x10, #0x10]
    1aa8:      	tbnz	w11, #0x5, 0x1af8 <_llm_rows.packet_batch.blocks+0x1760>
    1aac:      	tbz	w11, #0x6, 0x1b04 <_llm_rows.packet_batch.blocks+0x176c>
    1ab0:      	add	x13, x10, #0x18
    1ab4:      	st1.s	{ v29 }[2], [x13]
    1ab8:      	tbz	w11, #0x7, 0x1a18 <_llm_rows.packet_batch.blocks+0x1680>
    1abc:      	b	0x1b08 <_llm_rows.packet_batch.blocks+0x1770>
    1ac0:      	and	w11, w11, #0xff
    1ac4:      	tbz	w11, #0x1, 0x1a80 <_llm_rows.packet_batch.blocks+0x16e8>
    1ac8:      	add	x13, x10, #0x4
    1acc:      	st1.s	{ v12 }[1], [x13]
    1ad0:      	tbnz	w11, #0x2, 0x1a84 <_llm_rows.packet_batch.blocks+0x16ec>
    1ad4:      	tbz	w11, #0x3, 0x1a90 <_llm_rows.packet_batch.blocks+0x16f8>
    1ad8:      	add	x13, x10, #0xc
    1adc:      	st1.s	{ v12 }[3], [x13]
    1ae0:      	fmul.4s	v29, v29, v30
    1ae4:      	fmul.4s	v30, v8, v11
    1ae8:      	fsub.4s	v29, v29, v30
    1aec:      	and.16b	v29, v6, v29
    1af0:      	tbnz	w11, #0x4, 0x1aa4 <_llm_rows.packet_batch.blocks+0x170c>
    1af4:      	tbz	w11, #0x5, 0x1aac <_llm_rows.packet_batch.blocks+0x1714>
    1af8:      	add	x13, x10, #0x14
    1afc:      	st1.s	{ v29 }[1], [x13]
    1b00:      	tbnz	w11, #0x6, 0x1ab0 <_llm_rows.packet_batch.blocks+0x1718>
    1b04:      	tbz	w11, #0x7, 0x1a18 <_llm_rows.packet_batch.blocks+0x1680>
    1b08:      	add	x10, x10, #0x1c
    1b0c:      	st1.s	{ v29 }[3], [x10]
    1b10:      	b	0x1a18 <_llm_rows.packet_batch.blocks+0x1680>
    1b14:      	ldr	q5, [sp, #0xc0]
    1b18:      	fmul.4s	v5, v5, v2
    1b1c:      	fmul.4s	v21, v10, v4
    1b20:      	fsub.4s	v5, v5, v21
    1b24:      	zip1.8b	v21, v19, v0
    1b28:      	ushll.4s	v21, v21, #0x0
    1b2c:      	shl.4s	v21, v21, #0x1f
    1b30:      	cmlt.4s	v21, v21, #0
    1b34:      	and.16b	v5, v21, v5
    1b38:      	fmov	w10, s31
    1b3c:      	ldr	q21, [sp, #0x60]
    1b40:      	ldp	q22, q23, [sp, #0x40]
    1b44:      	stp	q21, q22, [sp, #0x2e0]
    1b48:      	ldr	q18, [sp, #0x30]
    1b4c:      	stp	q23, q18, [sp, #0x300]
    1b50:      	and	x11, x12, #0x7
    1b54:      	add	x13, sp, #0x2e0
    1b58:      	ldr	x11, [x13, x11, lsl #3]
    1b5c:      	sub	x11, x11, x12
    1b60:      	add	x11, x8, x11, lsl #2
    1b64:      	tbz	w10, #0x0, 0x1b84 <_llm_rows.packet_batch.blocks+0x17ec>
    1b68:      	str	s5, [x11]
    1b6c:      	tbnz	w10, #0x1, 0x1b88 <_llm_rows.packet_batch.blocks+0x17f0>
    1b70:      	tbz	w10, #0x2, 0x1b94 <_llm_rows.packet_batch.blocks+0x17fc>
    1b74:      	add	x13, x11, #0x8
    1b78:      	st1.s	{ v5 }[2], [x13]
    1b7c:      	tbnz	w10, #0x3, 0x1b98 <_llm_rows.packet_batch.blocks+0x1800>
    1b80:      	b	0x1ba0 <_llm_rows.packet_batch.blocks+0x1808>
    1b84:      	tbz	w10, #0x1, 0x1b70 <_llm_rows.packet_batch.blocks+0x17d8>
    1b88:      	add	x13, x11, #0x4
    1b8c:      	st1.s	{ v5 }[1], [x13]
    1b90:      	tbnz	w10, #0x2, 0x1b74 <_llm_rows.packet_batch.blocks+0x17dc>
    1b94:      	tbz	w10, #0x3, 0x1ba0 <_llm_rows.packet_batch.blocks+0x1808>
    1b98:      	add	x13, x11, #0xc
    1b9c:      	st1.s	{ v5 }[3], [x13]
    1ba0:      	fmul.4s	v5, v17, v1
    1ba4:      	fmul.4s	v21, v9, v3
    1ba8:      	fsub.4s	v5, v5, v21
    1bac:      	zip2.8b	v21, v19, v0
    1bb0:      	ushll.4s	v21, v21, #0x0
    1bb4:      	shl.4s	v21, v21, #0x1f
    1bb8:      	cmlt.4s	v21, v21, #0
    1bbc:      	and.16b	v5, v21, v5
    1bc0:      	tbz	w10, #0x4, 0x1be0 <_llm_rows.packet_batch.blocks+0x1848>
    1bc4:      	str	s5, [x11, #0x10]
    1bc8:      	tbnz	w10, #0x5, 0x1be4 <_llm_rows.packet_batch.blocks+0x184c>
    1bcc:      	tbz	w10, #0x6, 0x1bf0 <_llm_rows.packet_batch.blocks+0x1858>
    1bd0:      	add	x13, x11, #0x18
    1bd4:      	st1.s	{ v5 }[2], [x13]
    1bd8:      	tbnz	w10, #0x7, 0x1bf4 <_llm_rows.packet_batch.blocks+0x185c>
    1bdc:      	b	0x1bfc <_llm_rows.packet_batch.blocks+0x1864>
    1be0:      	tbz	w10, #0x5, 0x1bcc <_llm_rows.packet_batch.blocks+0x1834>
    1be4:      	add	x13, x11, #0x14
    1be8:      	st1.s	{ v5 }[1], [x13]
    1bec:      	tbnz	w10, #0x6, 0x1bd0 <_llm_rows.packet_batch.blocks+0x1838>
    1bf0:      	tbz	w10, #0x7, 0x1bfc <_llm_rows.packet_batch.blocks+0x1864>
    1bf4:      	add	x10, x11, #0x1c
    1bf8:      	st1.s	{ v5 }[3], [x10]
    1bfc:      	mov	x10, #0x0               ; =0
    1c00:      	add	x9, x9, x4
    1c04:      	movi.2d	v5, #0000000000000000
    1c08:      	movi.2d	v21, #0000000000000000
    1c0c:      	movi.2d	v22, #0000000000000000
    1c10:      	movi.2d	v23, #0000000000000000
    1c14:      	b	0x1c34 <_llm_rows.packet_batch.blocks+0x189c>
    1c18:      	add.2d	v21, v21, v25
    1c1c:      	add.2d	v22, v22, v26
    1c20:      	add.2d	v23, v23, v24
    1c24:      	add.2d	v5, v5, v27
    1c28:      	fmov	x10, d5
    1c2c:      	cmp	x10, #0x100
    1c30:      	b.ge	0x1d14 <_llm_rows.packet_batch.blocks+0x197c>
    1c34:      	fmov	w11, s7
    1c38:      	lsl	x10, x10, #5
    1c3c:      	add	x13, x3, x10
    1c40:      	ldp	q30, q28, [x13]
    1c44:      	add	x13, x21, x10
    1c48:      	ldp	q8, q29, [x13]
    1c4c:      	fmul.4s	v11, v30, v8
    1c50:      	add	x13, x27, x10
    1c54:      	ldp	q12, q30, [x13]
    1c58:      	add	x13, x19, x10
    1c5c:      	ldp	q13, q8, [x13]
    1c60:      	fmul.4s	v12, v12, v13
    1c64:      	fadd.4s	v11, v11, v12
    1c68:      	and.16b	v11, v0, v11
    1c6c:      	add	x10, x9, x10
    1c70:      	tbz	w11, #0x0, 0x1cc0 <_llm_rows.packet_batch.blocks+0x1928>
    1c74:      	str	s11, [x10]
    1c78:      	and	w11, w11, #0xff
    1c7c:      	tbnz	w11, #0x1, 0x1cc8 <_llm_rows.packet_batch.blocks+0x1930>
    1c80:      	tbz	w11, #0x2, 0x1cd4 <_llm_rows.packet_batch.blocks+0x193c>
    1c84:      	add	x13, x10, #0x8
    1c88:      	st1.s	{ v11 }[2], [x13]
    1c8c:      	tbnz	w11, #0x3, 0x1cd8 <_llm_rows.packet_batch.blocks+0x1940>
    1c90:      	fmul.4s	v28, v28, v29
    1c94:      	fmul.4s	v29, v30, v8
    1c98:      	fadd.4s	v28, v28, v29
    1c9c:      	and.16b	v28, v6, v28
    1ca0:      	tbz	w11, #0x4, 0x1cf4 <_llm_rows.packet_batch.blocks+0x195c>
    1ca4:      	str	s28, [x10, #0x10]
    1ca8:      	tbnz	w11, #0x5, 0x1cf8 <_llm_rows.packet_batch.blocks+0x1960>
    1cac:      	tbz	w11, #0x6, 0x1d04 <_llm_rows.packet_batch.blocks+0x196c>
    1cb0:      	add	x13, x10, #0x18
    1cb4:      	st1.s	{ v28 }[2], [x13]
    1cb8:      	tbz	w11, #0x7, 0x1c18 <_llm_rows.packet_batch.blocks+0x1880>
    1cbc:      	b	0x1d08 <_llm_rows.packet_batch.blocks+0x1970>
    1cc0:      	and	w11, w11, #0xff
    1cc4:      	tbz	w11, #0x1, 0x1c80 <_llm_rows.packet_batch.blocks+0x18e8>
    1cc8:      	add	x13, x10, #0x4
    1ccc:      	st1.s	{ v11 }[1], [x13]
    1cd0:      	tbnz	w11, #0x2, 0x1c84 <_llm_rows.packet_batch.blocks+0x18ec>
    1cd4:      	tbz	w11, #0x3, 0x1c90 <_llm_rows.packet_batch.blocks+0x18f8>
    1cd8:      	add	x13, x10, #0xc
    1cdc:      	st1.s	{ v11 }[3], [x13]
    1ce0:      	fmul.4s	v28, v28, v29
    1ce4:      	fmul.4s	v29, v30, v8
    1ce8:      	fadd.4s	v28, v28, v29
    1cec:      	and.16b	v28, v6, v28
    1cf0:      	tbnz	w11, #0x4, 0x1ca4 <_llm_rows.packet_batch.blocks+0x190c>
    1cf4:      	tbz	w11, #0x5, 0x1cac <_llm_rows.packet_batch.blocks+0x1914>
    1cf8:      	add	x13, x10, #0x14
    1cfc:      	st1.s	{ v28 }[1], [x13]
    1d00:      	tbnz	w11, #0x6, 0x1cb0 <_llm_rows.packet_batch.blocks+0x1918>
    1d04:      	tbz	w11, #0x7, 0x1c18 <_llm_rows.packet_batch.blocks+0x1880>
    1d08:      	add	x10, x10, #0x1c
    1d0c:      	st1.s	{ v28 }[3], [x10]
    1d10:      	b	0x1c18 <_llm_rows.packet_batch.blocks+0x1880>
    1d14:      	ldr	q0, [sp, #0xc0]
    1d18:      	fmul.4s	v0, v0, v4
    1d1c:      	fmul.4s	v2, v10, v2
    1d20:      	fadd.4s	v0, v2, v0
    1d24:      	zip1.8b	v2, v19, v0
    1d28:      	ushll.4s	v2, v2, #0x0
    1d2c:      	shl.4s	v2, v2, #0x1f
    1d30:      	cmlt.4s	v2, v2, #0
    1d34:      	and.16b	v0, v2, v0
    1d38:      	fmov	w9, s31
    1d3c:      	stp	q20, q16, [sp, #0x290]
    1d40:      	ldp	q4, q2, [sp, #0x10]
    1d44:      	stp	q4, q2, [sp, #0x2b0]
    1d48:      	and	x10, x12, #0x7
    1d4c:      	add	x11, sp, #0x290
    1d50:      	ldr	x10, [x11, x10, lsl #3]
    1d54:      	sub	x10, x10, x12
    1d58:      	add	x8, x8, x10, lsl #2
    1d5c:      	tbz	w9, #0x0, 0x1d80 <_llm_rows.packet_batch.blocks+0x19e8>
    1d60:      	str	s0, [x8]
    1d64:      	ldr	d10, [sp, #0x8]
    1d68:      	tbnz	w9, #0x1, 0x1d88 <_llm_rows.packet_batch.blocks+0x19f0>
    1d6c:      	tbz	w9, #0x2, 0x1d94 <_llm_rows.packet_batch.blocks+0x19fc>
    1d70:      	add	x10, x8, #0x8
    1d74:      	st1.s	{ v0 }[2], [x10]
    1d78:      	tbnz	w9, #0x3, 0x1d98 <_llm_rows.packet_batch.blocks+0x1a00>
    1d7c:      	b	0x1da0 <_llm_rows.packet_batch.blocks+0x1a08>
    1d80:      	ldr	d10, [sp, #0x8]
    1d84:      	tbz	w9, #0x1, 0x1d6c <_llm_rows.packet_batch.blocks+0x19d4>
    1d88:      	add	x10, x8, #0x4
    1d8c:      	st1.s	{ v0 }[1], [x10]
    1d90:      	tbnz	w9, #0x2, 0x1d70 <_llm_rows.packet_batch.blocks+0x19d8>
    1d94:      	tbz	w9, #0x3, 0x1da0 <_llm_rows.packet_batch.blocks+0x1a08>
    1d98:      	add	x10, x8, #0xc
    1d9c:      	st1.s	{ v0 }[3], [x10]
    1da0:      	fmul.4s	v0, v17, v3
    1da4:      	fmul.4s	v1, v9, v1
    1da8:      	fadd.4s	v0, v1, v0
    1dac:      	zip2.8b	v1, v19, v0
    1db0:      	ushll.4s	v1, v1, #0x0
    1db4:      	shl.4s	v1, v1, #0x1f
    1db8:      	cmlt.4s	v1, v1, #0
    1dbc:      	and.16b	v0, v1, v0
    1dc0:      	tbnz	w9, #0x4, 0x102c <_llm_rows.packet_batch.blocks+0xc94>
    1dc4:      	tbz	w9, #0x5, 0x1034 <_llm_rows.packet_batch.blocks+0xc9c>
    1dc8:      	add	x10, x8, #0x14
    1dcc:      	st1.s	{ v0 }[1], [x10]
    1dd0:      	tbnz	w9, #0x6, 0x1038 <_llm_rows.packet_batch.blocks+0xca0>
    1dd4:      	tbz	w9, #0x7, 0x470 <_llm_rows.packet_batch.blocks+0xd8>
    1dd8:      	add	x8, x8, #0x1c
    1ddc:      	st1.s	{ v0 }[3], [x8]
    1de0:      	b	0x470 <_llm_rows.packet_batch.blocks+0xd8>
    1de4:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    1de8:      	add	sp, sp, #0x4e0
    1dec:      	ldp	x29, x30, [sp, #0x90]
    1df0:      	ldp	x20, x19, [sp, #0x80]
    1df4:      	ldp	x22, x21, [sp, #0x70]
    1df8:      	ldp	x24, x23, [sp, #0x60]
    1dfc:      	ldp	x26, x25, [sp, #0x50]
    1e00:      	ldp	x28, x27, [sp, #0x40]
    1e04:      	ldp	d9, d8, [sp, #0x30]
    1e08:      	ldp	d11, d10, [sp, #0x20]
    1e0c:      	ldp	d13, d12, [sp, #0x10]
    1e10:      	ldp	d15, d14, [sp], #0xa0
    1e14:      	ret

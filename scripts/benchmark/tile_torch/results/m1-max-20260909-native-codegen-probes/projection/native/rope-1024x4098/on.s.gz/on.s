
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/rope-1024x4098/on/object/tile_xir_w8_38104_1788936549333922_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x28, x27, [sp, #-0x60]!
       4:      	stp	x26, x25, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	stp	x29, x30, [sp, #0x50]
      18:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      1c:      	sub	sp, sp, #0xc0
      20:      	ldr	x23, [x0]
      24:      	ldr	x22, [x0, #0x10]
      28:      	ldr	x21, [x0, #0x20]
      2c:      	ldr	x20, [x0, #0x30]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w8, w8, #3
      40:      	subs	x9, x23, x20
      44:      	lsr	x9, x9, #13
      48:      	mov	w10, #0x800             ; =2048
      4c:      	ccmp	x9, x10, #0x0, hs
      50:      	cset	w9, hi
      54:      	subs	x11, x20, x23
      58:      	lsr	x11, x11, #13
      5c:      	ccmp	x11, x10, #0x0, hs
      60:      	csinc	w11, w9, wzr, ls
      64:      	subs	x9, x22, x20
      68:      	lsr	x9, x9, #13
      6c:      	ccmp	x9, x10, #0x0, hs
      70:      	cset	w9, hi
      74:      	mov	w12, #0x1fff            ; =8191
      78:      	movk	w12, #0x100, lsl #16
      7c:      	sub	x12, x12, #0x801, lsl #12 ; =0x801000
      80:      	subs	x13, x20, x22
      84:      	ccmp	x13, x12, #0x0, hs
      88:      	csinc	w9, w9, wzr, ls
      8c:      	subs	x13, x21, x20
      90:      	lsr	x13, x13, #13
      94:      	ccmp	x13, x10, #0x0, hs
      98:      	cset	w10, hi
      9c:      	subs	x13, x20, x21
      a0:      	ccmp	x13, x12, #0x0, hs
      a4:      	csinc	w10, w10, wzr, ls
      a8:      	cmp	w10, #0x1
      ac:      	ccmp	w11, #0x0, #0x4, eq
      b0:      	b.eq	0x198 <ltmp0+0x198>
      b4:      	tbz	w9, #0x0, 0x198 <ltmp0+0x198>
      b8:      	mov	x10, #0x0               ; =0
      bc:      	add	x9, x8, x8, lsl #11
      c0:      	lsl	x12, x9, #2
      c4:      	add	x11, x22, x12
      c8:      	add	x12, x21, x12
      cc:      	lsl	x9, x9, #3
      d0:      	add	x13, x23, x9
      d4:      	add	x14, x20, x9
      d8:      	mov	w15, #0x2004            ; =8196
      dc:      	add	x16, x9, x15
      e0:      	add	x15, x23, x16
      e4:      	add	x16, x20, x16
      e8:      	add	x17, x13, x10
      ec:      	ldp	q1, q0, [x17]
      f0:      	add	x17, x15, x10
      f4:      	ldp	q3, q2, [x17]
      f8:      	add	x17, x11, x10
      fc:      	ldp	q5, q4, [x17]
     100:      	add	x17, x12, x10
     104:      	ldp	q7, q6, [x17]
     108:      	fmul.4s	v16, v1, v5
     10c:      	fmul.4s	v17, v0, v4
     110:      	fmul.4s	v18, v3, v7
     114:      	fmul.4s	v19, v2, v6
     118:      	fsub.4s	v17, v17, v19
     11c:      	fsub.4s	v16, v16, v18
     120:      	add	x17, x14, x10
     124:      	stp	q16, q17, [x17]
     128:      	fmul.4s	v1, v1, v7
     12c:      	fmul.4s	v0, v0, v6
     130:      	fmul.4s	v3, v3, v5
     134:      	fmul.4s	v2, v2, v4
     138:      	fadd.4s	v0, v2, v0
     13c:      	fadd.4s	v1, v3, v1
     140:      	add	x17, x16, x10
     144:      	stp	q1, q0, [x17]
     148:      	add	x10, x10, #0x20
     14c:      	cmp	x10, #0x2, lsl #12      ; =0x2000
     150:      	b.ne	0xe8 <ltmp0+0xe8>
     154:      	add	x10, x9, #0x2, lsl #12  ; =0x2000
     158:      	ldr	s0, [x23, x10]
     15c:      	mov	w11, #0x4004            ; =16388
     160:      	add	x19, x9, x11
     164:      	ldr	s1, [x23, x19]
     168:      	mov	w9, #0x2004             ; =8196
     16c:      	umull	x8, w8, w9
     170:      	add	x8, x8, #0x2, lsl #12   ; =0x2000
     174:      	ldr	s2, [x22, x8]
     178:      	ldr	s3, [x21, x8]
     17c:      	fmul.4s	v4, v0, v2
     180:      	fmul.4s	v5, v1, v3
     184:      	fsub.4s	v4, v4, v5
     188:      	str	s4, [x20, x10]
     18c:      	fmul.4s	v0, v0, v3
     190:      	fmul.4s	v1, v1, v2
     194:      	b	0x340 <ltmp0+0x340>
     198:      	add	x27, x8, x8, lsl #11
     19c:      	lsl	x28, x27, #3
     1a0:      	add	x19, x23, x28
     1a4:      	add	x25, sp, #0x6, lsl #12  ; =0x6000
     1a8:      	add	x25, x25, #0xa0
     1ac:      	add	x0, sp, #0x6, lsl #12   ; =0x6000
     1b0:      	add	x0, x0, #0xa0
     1b4:      	mov	x1, x19
     1b8:      	mov	w2, #0x2000             ; =8192
     1bc:      	bl	0x1bc <ltmp0+0x1bc>
     1c0:      	add	x8, x28, #0x2, lsl #12  ; =0x2000
     1c4:      	str	x8, [sp, #0x8]
     1c8:      	ldr	s0, [x23, x8]
     1cc:      	str	q0, [sp, #0x30]
     1d0:      	str	q0, [sp, #0x80a0]
     1d4:      	mov	w8, #0x2004             ; =8196
     1d8:      	add	x26, sp, #0x4, lsl #12  ; =0x4000
     1dc:      	add	x26, x26, #0x80
     1e0:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     1e4:      	add	x0, x0, #0x80
     1e8:      	add	x1, x19, x8
     1ec:      	mov	w2, #0x2000             ; =8192
     1f0:      	bl	0x1f0 <ltmp0+0x1f0>
     1f4:      	mov	w8, #0x4004             ; =16388
     1f8:      	add	x19, x28, x8
     1fc:      	ldr	s0, [x23, x19]
     200:      	str	q0, [sp, #0x20]
     204:      	str	q0, [sp, #0x6080]
     208:      	lsl	x27, x27, #2
     20c:      	add	x23, sp, #0x2, lsl #12  ; =0x2000
     210:      	add	x23, x23, #0x60
     214:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     218:      	add	x0, x0, #0x60
     21c:      	add	x1, x22, x27
     220:      	mov	w2, #0x2000             ; =8192
     224:      	bl	0x224 <ltmp0+0x224>
     228:      	add	x24, x27, #0x2, lsl #12 ; =0x2000
     22c:      	ldr	s0, [x22, x24]
     230:      	str	q0, [sp, #0x10]
     234:      	str	q0, [sp, #0x4060]
     238:      	add	x22, sp, #0x40
     23c:      	add	x0, sp, #0x40
     240:      	add	x1, x21, x27
     244:      	mov	w2, #0x2000             ; =8192
     248:      	bl	0x248 <ltmp0+0x248>
     24c:      	mov	x8, #0x0                ; =0
     250:      	ldr	s0, [x21, x24]
     254:      	str	q0, [sp, #0x2040]
     258:      	add	x9, x20, x28
     25c:      	add	x10, x25, x8
     260:      	ldp	q1, q2, [x10]
     264:      	add	x10, x23, x8
     268:      	ldp	q3, q4, [x10]
     26c:      	fmul.4s	v2, v2, v4
     270:      	fmul.4s	v1, v1, v3
     274:      	add	x10, x26, x8
     278:      	ldp	q3, q4, [x10]
     27c:      	add	x10, x22, x8
     280:      	ldp	q5, q6, [x10]
     284:      	fmul.4s	v4, v4, v6
     288:      	fmul.4s	v3, v3, v5
     28c:      	fsub.4s	v1, v1, v3
     290:      	fsub.4s	v2, v2, v4
     294:      	add	x10, x9, x8
     298:      	stp	q1, q2, [x10]
     29c:      	add	x8, x8, #0x20
     2a0:      	cmp	x8, #0x2, lsl #12       ; =0x2000
     2a4:      	b.ne	0x25c <ltmp0+0x25c>
     2a8:      	mov	x8, #0x0                ; =0
     2ac:      	ldp	q16, q7, [sp, #0x20]
     2b0:      	ldr	q17, [sp, #0x10]
     2b4:      	fmul.4s	v1, v7, v17
     2b8:      	fmul.4s	v2, v16, v0
     2bc:      	fsub.4s	v1, v1, v2
     2c0:      	ldr	x10, [sp, #0x8]
     2c4:      	str	s1, [x20, x10]
     2c8:      	mov	w10, #0x2004            ; =8196
     2cc:      	add	x9, x9, x10
     2d0:      	add	x10, sp, #0x6, lsl #12  ; =0x6000
     2d4:      	add	x10, x10, #0xa0
     2d8:      	add	x11, sp, #0x40
     2dc:      	add	x12, sp, #0x4, lsl #12  ; =0x4000
     2e0:      	add	x12, x12, #0x80
     2e4:      	add	x13, sp, #0x2, lsl #12  ; =0x2000
     2e8:      	add	x13, x13, #0x60
     2ec:      	add	x14, x10, x8
     2f0:      	ldp	q1, q2, [x14]
     2f4:      	add	x14, x11, x8
     2f8:      	ldp	q3, q4, [x14]
     2fc:      	fmul.4s	v2, v2, v4
     300:      	fmul.4s	v1, v1, v3
     304:      	add	x14, x12, x8
     308:      	ldp	q3, q4, [x14]
     30c:      	add	x14, x13, x8
     310:      	ldp	q5, q6, [x14]
     314:      	fmul.4s	v4, v4, v6
     318:      	fmul.4s	v3, v3, v5
     31c:      	fadd.4s	v1, v1, v3
     320:      	fadd.4s	v2, v2, v4
     324:      	add	x14, x9, x8
     328:      	stp	q1, q2, [x14]
     32c:      	add	x8, x8, #0x20
     330:      	cmp	x8, #0x2, lsl #12       ; =0x2000
     334:      	b.ne	0x2ec <ltmp0+0x2ec>
     338:      	fmul.4s	v0, v7, v0
     33c:      	fmul.4s	v1, v16, v17
     340:      	fadd.4s	v0, v1, v0
     344:      	str	s0, [x20, x19]
     348:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
     34c:      	add	sp, sp, #0xc0
     350:      	ldp	x29, x30, [sp, #0x50]
     354:      	ldp	x20, x19, [sp, #0x40]
     358:      	ldp	x22, x21, [sp, #0x30]
     35c:      	ldp	x24, x23, [sp, #0x20]
     360:      	ldp	x26, x25, [sp, #0x10]
     364:      	ldp	x28, x27, [sp], #0x60
     368:      	ret

000000000000036c <_llm_rows.packet_batch.blocks>:
     36c:      	stp	d15, d14, [sp, #-0xa0]!
     370:      	stp	d13, d12, [sp, #0x10]
     374:      	stp	d11, d10, [sp, #0x20]
     378:      	stp	d9, d8, [sp, #0x30]
     37c:      	stp	x28, x27, [sp, #0x40]
     380:      	stp	x26, x25, [sp, #0x50]
     384:      	stp	x24, x23, [sp, #0x60]
     388:      	stp	x22, x21, [sp, #0x70]
     38c:      	stp	x20, x19, [sp, #0x80]
     390:      	stp	x29, x30, [sp, #0x90]
     394:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
     398:      	sub	sp, sp, #0x4d0
     39c:      	str	x0, [sp, #0x128]
     3a0:      	cbz	w3, 0x1e08 <_llm_rows.packet_batch.blocks+0x1a9c>
     3a4:      	mov	x28, x3
     3a8:      	mov	x20, x2
     3ac:      	mov	w22, #0x0               ; =0
     3b0:      	ldp	w9, w8, [x2, #0x2c]
     3b4:      	str	w9, [sp, #0x10c]
     3b8:      	str	w8, [sp, #0x108]
     3bc:      	mov	w8, #0x1002             ; =4098
     3c0:      	ldp	w25, w23, [x2]
     3c4:      	ldp	w24, w9, [x2, #0x8]
     3c8:      	str	x9, [sp, #0x100]
     3cc:      	adrp	x9, 0x0 <ltmp0>
     3d0:      	ldr	q0, [x9]
     3d4:      	str	q0, [sp, #0xe0]
     3d8:      	adrp	x9, 0x0 <ltmp0>
     3dc:      	ldr	q0, [x9]
     3e0:      	str	q0, [sp, #0xd0]
     3e4:      	adrp	x9, 0x0 <ltmp0>
     3e8:      	ldr	q0, [x9]
     3ec:      	str	q0, [sp, #0xa0]
     3f0:      	adrp	x9, 0x0 <ltmp0>
     3f4:      	ldr	q0, [x9]
     3f8:      	str	q0, [sp, #0x90]
     3fc:      	adrp	x9, 0x0 <ltmp0>
     400:      	ldr	q0, [x9]
     404:      	str	q0, [sp, #0x80]
     408:      	adrp	x9, 0x0 <ltmp0>
     40c:      	ldr	q0, [x9]
     410:      	str	q0, [sp, #0x70]
     414:      	dup.2s	v0, w8
     418:      	str	d0, [sp, #0xc8]
     41c:      	adrp	x8, 0x0 <ltmp0>
     420:      	ldr	q10, [x8]
     424:      	add	x27, sp, #0x4, lsl #12  ; =0x4000
     428:      	add	x27, x27, #0x490
     42c:      	add	x19, sp, #0x2, lsl #12  ; =0x2000
     430:      	add	x19, x19, #0x470
     434:      	add	x21, sp, #0x450
     438:      	str	q10, [sp, #0x110]
     43c:      	str	w3, [sp, #0xfc]
     440:      	b	0x48c <_llm_rows.packet_batch.blocks+0x120>
     444:      	mov	w8, #0x18               ; =24
     448:      	str	w8, [x20, #0x24]
     44c:      	ldr	w28, [sp, #0xfc]
     450:      	add	w8, w25, #0x1
     454:      	ldr	w9, [sp, #0x10c]
     458:      	cmp	w8, w9
     45c:      	cset	w8, eq
     460:      	csinc	w25, wzr, w25, eq
     464:      	cinc	w9, w23, eq
     468:      	ldr	w10, [sp, #0x108]
     46c:      	cmp	w9, w10
     470:      	cset	w10, eq
     474:      	ands	w8, w8, w10
     478:      	csel	w23, wzr, w9, ne
     47c:      	add	w24, w24, w8
     480:      	add	w22, w22, #0x1
     484:      	cmp	w22, w28
     488:      	b.eq	0x1e08 <_llm_rows.packet_batch.blocks+0x1a9c>
     48c:      	ubfiz	x8, x25, #5, #32
     490:      	ldr	x12, [sp, #0x100]
     494:      	cmp	x8, x12
     498:      	csel	x9, x8, xzr, ls
     49c:      	subs	x10, x12, x9
     4a0:      	cmp	x10, #0x20
     4a4:      	mov	w11, #0x20              ; =32
     4a8:      	csel	x10, x10, x11, lo
     4ac:      	cmp	x12, x9
     4b0:      	stp	w25, w23, [x20]
     4b4:      	str	w24, [x20, #0x8]
     4b8:      	str	wzr, [x20, #0x24]
     4bc:      	ccmp	x8, x12, #0x2, hi
     4c0:      	csel	x26, x10, xzr, ls
     4c4:      	cmp	x26, #0x20
     4c8:      	b.lo	0x520 <_llm_rows.packet_batch.blocks+0x1b4>
     4cc:      	ldr	x26, [sp, #0x128]
     4d0:      	mov	x0, x26
     4d4:      	mov	x1, x20
     4d8:      	bl	0x4d8 <_llm_rows.packet_batch.blocks+0x16c>
     4dc:      	mov	w8, #0x8                ; =8
     4e0:      	str	w8, [x20, #0x24]
     4e4:      	mov	x0, x26
     4e8:      	mov	x1, x20
     4ec:      	bl	0x4ec <_llm_rows.packet_batch.blocks+0x180>
     4f0:      	mov	w8, #0x10               ; =16
     4f4:      	str	w8, [x20, #0x24]
     4f8:      	mov	x0, x26
     4fc:      	mov	x1, x20
     500:      	bl	0x500 <_llm_rows.packet_batch.blocks+0x194>
     504:      	mov	w8, #0x18               ; =24
     508:      	str	w8, [x20, #0x24]
     50c:      	mov	x0, x26
     510:      	mov	x1, x20
     514:      	bl	0x514 <_llm_rows.packet_batch.blocks+0x1a8>
     518:      	ldr	q10, [sp, #0x110]
     51c:      	b	0x450 <_llm_rows.packet_batch.blocks+0xe4>
     520:      	lsr	x28, x26, #3
     524:      	cmp	x26, #0x8
     528:      	b.lo	0x580 <_llm_rows.packet_batch.blocks+0x214>
     52c:      	str	wzr, [x20, #0x24]
     530:      	ldr	x0, [sp, #0x128]
     534:      	mov	x1, x20
     538:      	bl	0x538 <_llm_rows.packet_batch.blocks+0x1cc>
     53c:      	ldr	q10, [sp, #0x110]
     540:      	cmp	x28, #0x1
     544:      	b.eq	0x580 <_llm_rows.packet_batch.blocks+0x214>
     548:      	mov	w8, #0x8                ; =8
     54c:      	str	w8, [x20, #0x24]
     550:      	ldr	x0, [sp, #0x128]
     554:      	mov	x1, x20
     558:      	bl	0x558 <_llm_rows.packet_batch.blocks+0x1ec>
     55c:      	ldr	q10, [sp, #0x110]
     560:      	cmp	x28, #0x2
     564:      	b.eq	0x580 <_llm_rows.packet_batch.blocks+0x214>
     568:      	mov	w8, #0x10               ; =16
     56c:      	str	w8, [x20, #0x24]
     570:      	ldr	x0, [sp, #0x128]
     574:      	mov	x1, x20
     578:      	bl	0x578 <_llm_rows.packet_batch.blocks+0x20c>
     57c:      	ldr	q10, [sp, #0x110]
     580:      	and	w8, w26, #0x7
     584:      	cbz	w8, 0x444 <_llm_rows.packet_batch.blocks+0xd8>
     588:      	dup.4s	v1, w8
     58c:      	ldp	q2, q0, [sp, #0xd0]
     590:      	cmhi.4s	v6, v1, v2
     594:      	cmhi.4s	v0, v1, v0
     598:      	uzp1.8h	v22, v0, v6
     59c:      	umaxv.8h	h2, v22
     5a0:      	fmov	w8, s2
     5a4:      	tbz	w8, #0x0, 0x444 <_llm_rows.packet_batch.blocks+0xd8>
     5a8:      	ldr	x8, [sp, #0x128]
     5ac:      	ldr	x12, [x8]
     5b0:      	ldr	x10, [x8, #0x10]
     5b4:      	ldr	x9, [x8, #0x20]
     5b8:      	ldr	x8, [x8, #0x30]
     5bc:      	sshll.2d	v2, v0, #0x0
     5c0:      	sshll.2d	v3, v6, #0x0
     5c4:      	sshll2.2d	v23, v0, #0x0
     5c8:      	sshll2.2d	v21, v6, #0x0
     5cc:      	ldp	q4, q5, [sp, #0x90]
     5d0:      	and.16b	v16, v21, v5
     5d4:      	and.16b	v18, v23, v4
     5d8:      	ldr	q4, [sp, #0x80]
     5dc:      	and.16b	v17, v3, v4
     5e0:      	ldr	q3, [sp, #0x70]
     5e4:      	and.16b	v20, v2, v3
     5e8:      	ubfiz	w11, w25, #2, #27
     5ec:      	orr	w15, w11, w28
     5f0:      	dup.4s	v2, w15
     5f4:      	and.16b	v3, v0, v2
     5f8:      	and.16b	v2, v6, v2
     5fc:      	ushll2.2d	v5, v2, #0x0
     600:      	ushll2.2d	v4, v3, #0x0
     604:      	ushll.2d	v2, v2, #0x0
     608:      	ushll.2d	v3, v3, #0x0
     60c:      	subs	x11, x12, x8
     610:      	mov	w17, #0x1fff            ; =8191
     614:      	movk	w17, #0x100, lsl #16
     618:      	ccmp	x11, x17, #0x0, hs
     61c:      	cset	w11, hi
     620:      	subs	x13, x8, x12
     624:      	ccmp	x13, x17, #0x0, hs
     628:      	csinc	w11, w11, wzr, ls
     62c:      	subs	x13, x10, x8
     630:      	ccmp	x13, x17, #0x0, hs
     634:      	cset	w13, hi
     638:      	sub	x14, x17, #0x801, lsl #12 ; =0x801000
     63c:      	subs	x16, x8, x10
     640:      	ccmp	x16, x14, #0x0, hs
     644:      	csinc	w13, w13, wzr, ls
     648:      	subs	x16, x9, x8
     64c:      	ccmp	x16, x17, #0x0, hs
     650:      	cset	w16, hi
     654:      	subs	x17, x8, x9
     658:      	ccmp	x17, x14, #0x0, hs
     65c:      	csinc	w14, w16, wzr, ls
     660:      	xtn.2s	v15, v3
     664:      	xtn.2s	v8, v4
     668:      	xtn.2s	v4, v2
     66c:      	xtn.2s	v5, v5
     670:      	mov	w16, #0x801             ; =2049
     674:      	dup.2s	v2, w16
     678:      	cmp	w14, #0x1
     67c:      	b.ne	0x1074 <_llm_rows.packet_batch.blocks+0xd08>
     680:      	cbz	w11, 0x1074 <_llm_rows.packet_batch.blocks+0xd08>
     684:      	tbz	w13, #0x0, 0x1074 <_llm_rows.packet_batch.blocks+0xd08>
     688:      	mov	x11, #0x0               ; =0
     68c:      	ldr	d3, [sp, #0xc8]
     690:      	umull.2d	v21, v15, v3
     694:      	umull.2d	v6, v8, v3
     698:      	umull.2d	v19, v4, v3
     69c:      	umull.2d	v7, v5, v3
     6a0:      	fmov	w13, s1
     6a4:      	cmp	w13, #0x0
     6a8:      	cset	w13, ne
     6ac:      	add	x15, x15, x15, lsl #11
     6b0:      	lsl	x14, x15, #1
     6b4:      	add	x16, x14, #0x801
     6b8:      	mov	w17, #0x801             ; =2049
     6bc:      	csel	x17, x16, x17, ne
     6c0:      	csel	x15, x15, xzr, ne
     6c4:      	lsl	x16, x15, #2
     6c8:      	add	x15, x9, x16
     6cc:      	add	x16, x10, x16
     6d0:      	lsl	x0, x17, #2
     6d4:      	add	x17, x8, x0
     6d8:      	add	x0, x12, x0
     6dc:      	and.16b	v1, v22, v10
     6e0:      	addv.8h	h22, v1
     6e4:      	fmov	w1, s22
     6e8:      	b	0x708 <_llm_rows.packet_batch.blocks+0x39c>
     6ec:      	add	x11, x11, #0x8
     6f0:      	add	x15, x15, #0x20
     6f4:      	add	x16, x16, #0x20
     6f8:      	add	x17, x17, #0x20
     6fc:      	add	x0, x0, #0x20
     700:      	cmp	x11, #0x800
     704:      	b.eq	0xaf8 <_llm_rows.packet_batch.blocks+0x78c>
     708:      	cmp	w13, #0x0
     70c:      	csel	x2, x14, xzr, ne
     710:      	add	x2, x2, x11
     714:      	lsl	x2, x2, #2
     718:      	add	x3, x12, x2
     71c:      	movi.2d	v24, #0000000000000000
     720:      	movi.2d	v23, #0000000000000000
     724:      	tbz	w1, #0x0, 0x900 <_llm_rows.packet_batch.blocks+0x594>
     728:      	ldr	s24, [x3]
     72c:      	and	w4, w1, #0xff
     730:      	tbnz	w4, #0x1, 0x908 <_llm_rows.packet_batch.blocks+0x59c>
     734:      	tbz	w4, #0x2, 0x914 <_llm_rows.packet_batch.blocks+0x5a8>
     738:      	add	x5, x3, #0x8
     73c:      	ld1.s	{ v24 }[2], [x5]
     740:      	tbnz	w4, #0x3, 0x918 <_llm_rows.packet_batch.blocks+0x5ac>
     744:      	tbz	w4, #0x4, 0x924 <_llm_rows.packet_batch.blocks+0x5b8>
     748:      	add	x5, x3, #0x10
     74c:      	ld1.s	{ v23 }[0], [x5]
     750:      	tbnz	w4, #0x5, 0x928 <_llm_rows.packet_batch.blocks+0x5bc>
     754:      	tbz	w4, #0x6, 0x934 <_llm_rows.packet_batch.blocks+0x5c8>
     758:      	add	x5, x3, #0x18
     75c:      	ld1.s	{ v23 }[2], [x5]
     760:      	tbnz	w4, #0x7, 0x938 <_llm_rows.packet_batch.blocks+0x5cc>
     764:      	fmov	w3, s22
     768:      	movi.2d	v26, #0000000000000000
     76c:      	movi.2d	v25, #0000000000000000
     770:      	tbz	w3, #0x0, 0x950 <_llm_rows.packet_batch.blocks+0x5e4>
     774:      	ldr	s26, [x0]
     778:      	and	w3, w3, #0xff
     77c:      	tbnz	w3, #0x1, 0x958 <_llm_rows.packet_batch.blocks+0x5ec>
     780:      	tbz	w3, #0x2, 0x964 <_llm_rows.packet_batch.blocks+0x5f8>
     784:      	add	x4, x0, #0x8
     788:      	ld1.s	{ v26 }[2], [x4]
     78c:      	tbnz	w3, #0x3, 0x968 <_llm_rows.packet_batch.blocks+0x5fc>
     790:      	tbz	w3, #0x4, 0x974 <_llm_rows.packet_batch.blocks+0x608>
     794:      	add	x4, x0, #0x10
     798:      	ld1.s	{ v25 }[0], [x4]
     79c:      	tbnz	w3, #0x5, 0x978 <_llm_rows.packet_batch.blocks+0x60c>
     7a0:      	tbz	w3, #0x6, 0x984 <_llm_rows.packet_batch.blocks+0x618>
     7a4:      	add	x4, x0, #0x18
     7a8:      	ld1.s	{ v25 }[2], [x4]
     7ac:      	tbnz	w3, #0x7, 0x988 <_llm_rows.packet_batch.blocks+0x61c>
     7b0:      	fmov	w3, s22
     7b4:      	movi.2d	v28, #0000000000000000
     7b8:      	movi.2d	v27, #0000000000000000
     7bc:      	tbz	w3, #0x0, 0x9a0 <_llm_rows.packet_batch.blocks+0x634>
     7c0:      	ldr	s28, [x16]
     7c4:      	and	w3, w3, #0xff
     7c8:      	tbnz	w3, #0x1, 0x9a8 <_llm_rows.packet_batch.blocks+0x63c>
     7cc:      	tbz	w3, #0x2, 0x9b4 <_llm_rows.packet_batch.blocks+0x648>
     7d0:      	add	x4, x16, #0x8
     7d4:      	ld1.s	{ v28 }[2], [x4]
     7d8:      	tbnz	w3, #0x3, 0x9b8 <_llm_rows.packet_batch.blocks+0x64c>
     7dc:      	tbz	w3, #0x4, 0x9c4 <_llm_rows.packet_batch.blocks+0x658>
     7e0:      	add	x4, x16, #0x10
     7e4:      	ld1.s	{ v27 }[0], [x4]
     7e8:      	tbnz	w3, #0x5, 0x9c8 <_llm_rows.packet_batch.blocks+0x65c>
     7ec:      	tbz	w3, #0x6, 0x9d4 <_llm_rows.packet_batch.blocks+0x668>
     7f0:      	add	x4, x16, #0x18
     7f4:      	ld1.s	{ v27 }[2], [x4]
     7f8:      	tbnz	w3, #0x7, 0x9d8 <_llm_rows.packet_batch.blocks+0x66c>
     7fc:      	fmov	w3, s22
     800:      	movi.2d	v30, #0000000000000000
     804:      	movi.2d	v29, #0000000000000000
     808:      	tbz	w3, #0x0, 0x9f0 <_llm_rows.packet_batch.blocks+0x684>
     80c:      	ldr	s30, [x15]
     810:      	and	w3, w3, #0xff
     814:      	tbnz	w3, #0x1, 0x9f8 <_llm_rows.packet_batch.blocks+0x68c>
     818:      	tbz	w3, #0x2, 0xa04 <_llm_rows.packet_batch.blocks+0x698>
     81c:      	add	x4, x15, #0x8
     820:      	ld1.s	{ v30 }[2], [x4]
     824:      	tbnz	w3, #0x3, 0xa08 <_llm_rows.packet_batch.blocks+0x69c>
     828:      	tbz	w3, #0x4, 0xa14 <_llm_rows.packet_batch.blocks+0x6a8>
     82c:      	add	x4, x15, #0x10
     830:      	ld1.s	{ v29 }[0], [x4]
     834:      	tbnz	w3, #0x5, 0xa18 <_llm_rows.packet_batch.blocks+0x6ac>
     838:      	tbz	w3, #0x6, 0xa24 <_llm_rows.packet_batch.blocks+0x6b8>
     83c:      	add	x4, x15, #0x18
     840:      	ld1.s	{ v29 }[2], [x4]
     844:      	tbnz	w3, #0x7, 0xa28 <_llm_rows.packet_batch.blocks+0x6bc>
     848:      	fmov	w3, s22
     84c:      	fmul.4s	v1, v24, v28
     850:      	fmul.4s	v3, v26, v30
     854:      	fsub.4s	v1, v1, v3
     858:      	add	x2, x8, x2
     85c:      	tbz	w3, #0x0, 0xa48 <_llm_rows.packet_batch.blocks+0x6dc>
     860:      	str	s1, [x2]
     864:      	and	w3, w3, #0xff
     868:      	tbnz	w3, #0x1, 0xa50 <_llm_rows.packet_batch.blocks+0x6e4>
     86c:      	tbz	w3, #0x2, 0xa5c <_llm_rows.packet_batch.blocks+0x6f0>
     870:      	add	x4, x2, #0x8
     874:      	st1.s	{ v1 }[2], [x4]
     878:      	tbnz	w3, #0x3, 0xa60 <_llm_rows.packet_batch.blocks+0x6f4>
     87c:      	fmul.4s	v1, v23, v27
     880:      	fmul.4s	v3, v25, v29
     884:      	fsub.4s	v1, v1, v3
     888:      	tbz	w3, #0x4, 0xa78 <_llm_rows.packet_batch.blocks+0x70c>
     88c:      	str	s1, [x2, #0x10]
     890:      	tbnz	w3, #0x5, 0xa7c <_llm_rows.packet_batch.blocks+0x710>
     894:      	tbz	w3, #0x6, 0xa88 <_llm_rows.packet_batch.blocks+0x71c>
     898:      	add	x4, x2, #0x18
     89c:      	st1.s	{ v1 }[2], [x4]
     8a0:      	tbnz	w3, #0x7, 0xa8c <_llm_rows.packet_batch.blocks+0x720>
     8a4:      	fmov	w2, s22
     8a8:      	fmul.4s	v1, v24, v30
     8ac:      	fmul.4s	v3, v26, v28
     8b0:      	fadd.4s	v1, v3, v1
     8b4:      	tbz	w2, #0x0, 0xaa8 <_llm_rows.packet_batch.blocks+0x73c>
     8b8:      	str	s1, [x17]
     8bc:      	and	w2, w2, #0xff
     8c0:      	tbnz	w2, #0x1, 0xab0 <_llm_rows.packet_batch.blocks+0x744>
     8c4:      	tbz	w2, #0x2, 0xabc <_llm_rows.packet_batch.blocks+0x750>
     8c8:      	add	x3, x17, #0x8
     8cc:      	st1.s	{ v1 }[2], [x3]
     8d0:      	tbnz	w2, #0x3, 0xac0 <_llm_rows.packet_batch.blocks+0x754>
     8d4:      	fmul.4s	v1, v23, v29
     8d8:      	fmul.4s	v3, v25, v27
     8dc:      	fadd.4s	v1, v3, v1
     8e0:      	tbz	w2, #0x4, 0xad8 <_llm_rows.packet_batch.blocks+0x76c>
     8e4:      	str	s1, [x17, #0x10]
     8e8:      	tbnz	w2, #0x5, 0xadc <_llm_rows.packet_batch.blocks+0x770>
     8ec:      	tbz	w2, #0x6, 0xae8 <_llm_rows.packet_batch.blocks+0x77c>
     8f0:      	add	x3, x17, #0x18
     8f4:      	st1.s	{ v1 }[2], [x3]
     8f8:      	tbz	w2, #0x7, 0x6ec <_llm_rows.packet_batch.blocks+0x380>
     8fc:      	b	0xaec <_llm_rows.packet_batch.blocks+0x780>
     900:      	and	w4, w1, #0xff
     904:      	tbz	w4, #0x1, 0x734 <_llm_rows.packet_batch.blocks+0x3c8>
     908:      	add	x5, x3, #0x4
     90c:      	ld1.s	{ v24 }[1], [x5]
     910:      	tbnz	w4, #0x2, 0x738 <_llm_rows.packet_batch.blocks+0x3cc>
     914:      	tbz	w4, #0x3, 0x744 <_llm_rows.packet_batch.blocks+0x3d8>
     918:      	add	x5, x3, #0xc
     91c:      	ld1.s	{ v24 }[3], [x5]
     920:      	tbnz	w4, #0x4, 0x748 <_llm_rows.packet_batch.blocks+0x3dc>
     924:      	tbz	w4, #0x5, 0x754 <_llm_rows.packet_batch.blocks+0x3e8>
     928:      	add	x5, x3, #0x14
     92c:      	ld1.s	{ v23 }[1], [x5]
     930:      	tbnz	w4, #0x6, 0x758 <_llm_rows.packet_batch.blocks+0x3ec>
     934:      	tbz	w4, #0x7, 0x764 <_llm_rows.packet_batch.blocks+0x3f8>
     938:      	add	x3, x3, #0x1c
     93c:      	ld1.s	{ v23 }[3], [x3]
     940:      	fmov	w3, s22
     944:      	movi.2d	v26, #0000000000000000
     948:      	movi.2d	v25, #0000000000000000
     94c:      	tbnz	w3, #0x0, 0x774 <_llm_rows.packet_batch.blocks+0x408>
     950:      	and	w3, w3, #0xff
     954:      	tbz	w3, #0x1, 0x780 <_llm_rows.packet_batch.blocks+0x414>
     958:      	add	x4, x0, #0x4
     95c:      	ld1.s	{ v26 }[1], [x4]
     960:      	tbnz	w3, #0x2, 0x784 <_llm_rows.packet_batch.blocks+0x418>
     964:      	tbz	w3, #0x3, 0x790 <_llm_rows.packet_batch.blocks+0x424>
     968:      	add	x4, x0, #0xc
     96c:      	ld1.s	{ v26 }[3], [x4]
     970:      	tbnz	w3, #0x4, 0x794 <_llm_rows.packet_batch.blocks+0x428>
     974:      	tbz	w3, #0x5, 0x7a0 <_llm_rows.packet_batch.blocks+0x434>
     978:      	add	x4, x0, #0x14
     97c:      	ld1.s	{ v25 }[1], [x4]
     980:      	tbnz	w3, #0x6, 0x7a4 <_llm_rows.packet_batch.blocks+0x438>
     984:      	tbz	w3, #0x7, 0x7b0 <_llm_rows.packet_batch.blocks+0x444>
     988:      	add	x3, x0, #0x1c
     98c:      	ld1.s	{ v25 }[3], [x3]
     990:      	fmov	w3, s22
     994:      	movi.2d	v28, #0000000000000000
     998:      	movi.2d	v27, #0000000000000000
     99c:      	tbnz	w3, #0x0, 0x7c0 <_llm_rows.packet_batch.blocks+0x454>
     9a0:      	and	w3, w3, #0xff
     9a4:      	tbz	w3, #0x1, 0x7cc <_llm_rows.packet_batch.blocks+0x460>
     9a8:      	add	x4, x16, #0x4
     9ac:      	ld1.s	{ v28 }[1], [x4]
     9b0:      	tbnz	w3, #0x2, 0x7d0 <_llm_rows.packet_batch.blocks+0x464>
     9b4:      	tbz	w3, #0x3, 0x7dc <_llm_rows.packet_batch.blocks+0x470>
     9b8:      	add	x4, x16, #0xc
     9bc:      	ld1.s	{ v28 }[3], [x4]
     9c0:      	tbnz	w3, #0x4, 0x7e0 <_llm_rows.packet_batch.blocks+0x474>
     9c4:      	tbz	w3, #0x5, 0x7ec <_llm_rows.packet_batch.blocks+0x480>
     9c8:      	add	x4, x16, #0x14
     9cc:      	ld1.s	{ v27 }[1], [x4]
     9d0:      	tbnz	w3, #0x6, 0x7f0 <_llm_rows.packet_batch.blocks+0x484>
     9d4:      	tbz	w3, #0x7, 0x7fc <_llm_rows.packet_batch.blocks+0x490>
     9d8:      	add	x3, x16, #0x1c
     9dc:      	ld1.s	{ v27 }[3], [x3]
     9e0:      	fmov	w3, s22
     9e4:      	movi.2d	v30, #0000000000000000
     9e8:      	movi.2d	v29, #0000000000000000
     9ec:      	tbnz	w3, #0x0, 0x80c <_llm_rows.packet_batch.blocks+0x4a0>
     9f0:      	and	w3, w3, #0xff
     9f4:      	tbz	w3, #0x1, 0x818 <_llm_rows.packet_batch.blocks+0x4ac>
     9f8:      	add	x4, x15, #0x4
     9fc:      	ld1.s	{ v30 }[1], [x4]
     a00:      	tbnz	w3, #0x2, 0x81c <_llm_rows.packet_batch.blocks+0x4b0>
     a04:      	tbz	w3, #0x3, 0x828 <_llm_rows.packet_batch.blocks+0x4bc>
     a08:      	add	x4, x15, #0xc
     a0c:      	ld1.s	{ v30 }[3], [x4]
     a10:      	tbnz	w3, #0x4, 0x82c <_llm_rows.packet_batch.blocks+0x4c0>
     a14:      	tbz	w3, #0x5, 0x838 <_llm_rows.packet_batch.blocks+0x4cc>
     a18:      	add	x4, x15, #0x14
     a1c:      	ld1.s	{ v29 }[1], [x4]
     a20:      	tbnz	w3, #0x6, 0x83c <_llm_rows.packet_batch.blocks+0x4d0>
     a24:      	tbz	w3, #0x7, 0x848 <_llm_rows.packet_batch.blocks+0x4dc>
     a28:      	add	x3, x15, #0x1c
     a2c:      	ld1.s	{ v29 }[3], [x3]
     a30:      	fmov	w3, s22
     a34:      	fmul.4s	v1, v24, v28
     a38:      	fmul.4s	v3, v26, v30
     a3c:      	fsub.4s	v1, v1, v3
     a40:      	add	x2, x8, x2
     a44:      	tbnz	w3, #0x0, 0x860 <_llm_rows.packet_batch.blocks+0x4f4>
     a48:      	and	w3, w3, #0xff
     a4c:      	tbz	w3, #0x1, 0x86c <_llm_rows.packet_batch.blocks+0x500>
     a50:      	add	x4, x2, #0x4
     a54:      	st1.s	{ v1 }[1], [x4]
     a58:      	tbnz	w3, #0x2, 0x870 <_llm_rows.packet_batch.blocks+0x504>
     a5c:      	tbz	w3, #0x3, 0x87c <_llm_rows.packet_batch.blocks+0x510>
     a60:      	add	x4, x2, #0xc
     a64:      	st1.s	{ v1 }[3], [x4]
     a68:      	fmul.4s	v1, v23, v27
     a6c:      	fmul.4s	v3, v25, v29
     a70:      	fsub.4s	v1, v1, v3
     a74:      	tbnz	w3, #0x4, 0x88c <_llm_rows.packet_batch.blocks+0x520>
     a78:      	tbz	w3, #0x5, 0x894 <_llm_rows.packet_batch.blocks+0x528>
     a7c:      	add	x4, x2, #0x14
     a80:      	st1.s	{ v1 }[1], [x4]
     a84:      	tbnz	w3, #0x6, 0x898 <_llm_rows.packet_batch.blocks+0x52c>
     a88:      	tbz	w3, #0x7, 0x8a4 <_llm_rows.packet_batch.blocks+0x538>
     a8c:      	add	x2, x2, #0x1c
     a90:      	st1.s	{ v1 }[3], [x2]
     a94:      	fmov	w2, s22
     a98:      	fmul.4s	v1, v24, v30
     a9c:      	fmul.4s	v3, v26, v28
     aa0:      	fadd.4s	v1, v3, v1
     aa4:      	tbnz	w2, #0x0, 0x8b8 <_llm_rows.packet_batch.blocks+0x54c>
     aa8:      	and	w2, w2, #0xff
     aac:      	tbz	w2, #0x1, 0x8c4 <_llm_rows.packet_batch.blocks+0x558>
     ab0:      	add	x3, x17, #0x4
     ab4:      	st1.s	{ v1 }[1], [x3]
     ab8:      	tbnz	w2, #0x2, 0x8c8 <_llm_rows.packet_batch.blocks+0x55c>
     abc:      	tbz	w2, #0x3, 0x8d4 <_llm_rows.packet_batch.blocks+0x568>
     ac0:      	add	x3, x17, #0xc
     ac4:      	st1.s	{ v1 }[3], [x3]
     ac8:      	fmul.4s	v1, v23, v29
     acc:      	fmul.4s	v3, v25, v27
     ad0:      	fadd.4s	v1, v3, v1
     ad4:      	tbnz	w2, #0x4, 0x8e4 <_llm_rows.packet_batch.blocks+0x578>
     ad8:      	tbz	w2, #0x5, 0x8ec <_llm_rows.packet_batch.blocks+0x580>
     adc:      	add	x3, x17, #0x14
     ae0:      	st1.s	{ v1 }[1], [x3]
     ae4:      	tbnz	w2, #0x6, 0x8f0 <_llm_rows.packet_batch.blocks+0x584>
     ae8:      	tbz	w2, #0x7, 0x6ec <_llm_rows.packet_batch.blocks+0x380>
     aec:      	add	x2, x17, #0x1c
     af0:      	st1.s	{ v1 }[3], [x2]
     af4:      	b	0x6ec <_llm_rows.packet_batch.blocks+0x380>
     af8:      	xtn.4h	v0, v0
     afc:      	uzp1.8b	v0, v0, v0
     b00:      	movi.2d	v29, #0000000000000000
     b04:      	mov.b	v29[0], v0[0]
     b08:      	adrp	x11, 0x0 <ltmp0>
     b0c:      	ldr	d26, [x11]
     b10:      	and.8b	v1, v29, v26
     b14:      	addv.8b	b1, v1
     b18:      	fmov	w13, s1
     b1c:      	umaxv.8b	b1, v29
     b20:      	fmov	w15, s1
     b24:      	rbit	w11, w13
     b28:      	clz	w11, w11
     b2c:      	tst	w15, #0x1
     b30:      	csel	w11, w11, wzr, ne
     b34:      	mov	w14, #0x800             ; =2048
     b38:      	dup.2d	v31, x14
     b3c:      	orr.16b	v30, v20, v31
     b40:      	add.2d	v23, v21, v30
     b44:      	movi.2d	v1, #0000000000000000
     b48:      	mov.b	v1[0], v0[0]
     b4c:      	ushll.2d	v0, v1, #0x0
     b50:      	shl.2d	v0, v0, #0x3f
     b54:      	cmlt.2d	v0, v0, #0
     b58:      	and.16b	v0, v0, v23
     b5c:      	movi.2d	v1, #0000000000000000
     b60:      	stp	q1, q1, [sp, #0x250]
     b64:      	stp	q0, q1, [sp, #0x230]
     b68:      	and	x14, x11, #0x7
     b6c:      	add	x16, sp, #0x230
     b70:      	ldr	x14, [x16, x14, lsl #3]
     b74:      	sub	x14, x14, x11
     b78:      	add	x14, x12, x14, lsl #2
     b7c:      	movi.2d	v22, #0000000000000000
     b80:      	movi.2d	v0, #0000000000000000
     b84:      	tbz	w15, #0x0, 0xbc4 <_llm_rows.packet_batch.blocks+0x858>
     b88:      	ldr	s22, [x14]
     b8c:      	tbnz	w13, #0x1, 0xbc8 <_llm_rows.packet_batch.blocks+0x85c>
     b90:      	tbz	w13, #0x2, 0xbd4 <_llm_rows.packet_batch.blocks+0x868>
     b94:      	add	x15, x14, #0x8
     b98:      	ld1.s	{ v22 }[2], [x15]
     b9c:      	tbnz	w13, #0x3, 0xbd8 <_llm_rows.packet_batch.blocks+0x86c>
     ba0:      	tbz	w13, #0x4, 0xbe4 <_llm_rows.packet_batch.blocks+0x878>
     ba4:      	add	x15, x14, #0x10
     ba8:      	ld1.s	{ v0 }[0], [x15]
     bac:      	tbnz	w13, #0x5, 0xbe8 <_llm_rows.packet_batch.blocks+0x87c>
     bb0:      	tbz	w13, #0x6, 0xbf4 <_llm_rows.packet_batch.blocks+0x888>
     bb4:      	add	x15, x14, #0x18
     bb8:      	ld1.s	{ v0 }[2], [x15]
     bbc:      	tbnz	w13, #0x7, 0xbf8 <_llm_rows.packet_batch.blocks+0x88c>
     bc0:      	b	0xc00 <_llm_rows.packet_batch.blocks+0x894>
     bc4:      	tbz	w13, #0x1, 0xb90 <_llm_rows.packet_batch.blocks+0x824>
     bc8:      	add	x15, x14, #0x4
     bcc:      	ld1.s	{ v22 }[1], [x15]
     bd0:      	tbnz	w13, #0x2, 0xb94 <_llm_rows.packet_batch.blocks+0x828>
     bd4:      	tbz	w13, #0x3, 0xba0 <_llm_rows.packet_batch.blocks+0x834>
     bd8:      	add	x15, x14, #0xc
     bdc:      	ld1.s	{ v22 }[3], [x15]
     be0:      	tbnz	w13, #0x4, 0xba4 <_llm_rows.packet_batch.blocks+0x838>
     be4:      	tbz	w13, #0x5, 0xbb0 <_llm_rows.packet_batch.blocks+0x844>
     be8:      	add	x15, x14, #0x14
     bec:      	ld1.s	{ v0 }[1], [x15]
     bf0:      	tbnz	w13, #0x6, 0xbb4 <_llm_rows.packet_batch.blocks+0x848>
     bf4:      	tbz	w13, #0x7, 0xc00 <_llm_rows.packet_batch.blocks+0x894>
     bf8:      	add	x13, x14, #0x1c
     bfc:      	ld1.s	{ v0 }[3], [x13]
     c00:      	add.2d	v1, v20, v21
     c04:      	add.2d	v3, v18, v6
     c08:      	add.2d	v21, v17, v19
     c0c:      	add.2d	v20, v16, v7
     c10:      	mov	w13, #0x1001            ; =4097
     c14:      	dup.2d	v25, x13
     c18:      	add.2d	v20, v20, v25
     c1c:      	add.2d	v21, v21, v25
     c20:      	add.2d	v24, v3, v25
     c24:      	mov	b3, v29[0]
     c28:      	mov.b	v3[4], v29[1]
     c2c:      	add.2d	v25, v1, v25
     c30:      	ushll.2d	v1, v3, #0x0
     c34:      	shl.2d	v1, v1, #0x3f
     c38:      	cmlt.2d	v1, v1, #0
     c3c:      	and.16b	v1, v1, v25
     c40:      	mov	b3, v29[2]
     c44:      	mov.b	v3[4], v29[3]
     c48:      	ushll.2d	v3, v3, #0x0
     c4c:      	shl.2d	v3, v3, #0x3f
     c50:      	cmlt.2d	v3, v3, #0
     c54:      	and.16b	v3, v3, v24
     c58:      	mov	b27, v29[4]
     c5c:      	mov.b	v27[4], v29[5]
     c60:      	ushll.2d	v27, v27, #0x0
     c64:      	shl.2d	v27, v27, #0x3f
     c68:      	cmlt.2d	v27, v27, #0
     c6c:      	and.16b	v28, v27, v21
     c70:      	mov	b27, v29[6]
     c74:      	mov.b	v27[4], v29[7]
     c78:      	ushll.2d	v27, v27, #0x0
     c7c:      	shl.2d	v27, v27, #0x3f
     c80:      	cmlt.2d	v27, v27, #0
     c84:      	and.16b	v9, v27, v20
     c88:      	shl.8b	v27, v29, #0x7
     c8c:      	cmlt.8b	v27, v27, #0
     c90:      	and.8b	v26, v27, v26
     c94:      	addv.8b	b27, v26
     c98:      	fmov	w13, s27
     c9c:      	stp	q28, q9, [sp, #0x210]
     ca0:      	stp	q1, q3, [sp, #0x1f0]
     ca4:      	and	x14, x11, #0x7
     ca8:      	add	x15, sp, #0x1f0
     cac:      	ldr	x14, [x15, x14, lsl #3]
     cb0:      	sub	x14, x14, x11
     cb4:      	add	x12, x12, x14, lsl #2
     cb8:      	movi.2d	v28, #0000000000000000
     cbc:      	movi.2d	v26, #0000000000000000
     cc0:      	tbz	w13, #0x0, 0xd00 <_llm_rows.packet_batch.blocks+0x994>
     cc4:      	ldr	s28, [x12]
     cc8:      	tbnz	w13, #0x1, 0xd04 <_llm_rows.packet_batch.blocks+0x998>
     ccc:      	tbz	w13, #0x2, 0xd10 <_llm_rows.packet_batch.blocks+0x9a4>
     cd0:      	add	x14, x12, #0x8
     cd4:      	ld1.s	{ v28 }[2], [x14]
     cd8:      	tbnz	w13, #0x3, 0xd14 <_llm_rows.packet_batch.blocks+0x9a8>
     cdc:      	tbz	w13, #0x4, 0xd20 <_llm_rows.packet_batch.blocks+0x9b4>
     ce0:      	add	x14, x12, #0x10
     ce4:      	ld1.s	{ v26 }[0], [x14]
     ce8:      	tbnz	w13, #0x5, 0xd24 <_llm_rows.packet_batch.blocks+0x9b8>
     cec:      	tbz	w13, #0x6, 0xd30 <_llm_rows.packet_batch.blocks+0x9c4>
     cf0:      	add	x14, x12, #0x18
     cf4:      	ld1.s	{ v26 }[2], [x14]
     cf8:      	tbnz	w13, #0x7, 0xd34 <_llm_rows.packet_batch.blocks+0x9c8>
     cfc:      	b	0xd3c <_llm_rows.packet_batch.blocks+0x9d0>
     d00:      	tbz	w13, #0x1, 0xccc <_llm_rows.packet_batch.blocks+0x960>
     d04:      	add	x14, x12, #0x4
     d08:      	ld1.s	{ v28 }[1], [x14]
     d0c:      	tbnz	w13, #0x2, 0xcd0 <_llm_rows.packet_batch.blocks+0x964>
     d10:      	tbz	w13, #0x3, 0xcdc <_llm_rows.packet_batch.blocks+0x970>
     d14:      	add	x14, x12, #0xc
     d18:      	ld1.s	{ v28 }[3], [x14]
     d1c:      	tbnz	w13, #0x4, 0xce0 <_llm_rows.packet_batch.blocks+0x974>
     d20:      	tbz	w13, #0x5, 0xcec <_llm_rows.packet_batch.blocks+0x980>
     d24:      	add	x14, x12, #0x14
     d28:      	ld1.s	{ v26 }[1], [x14]
     d2c:      	tbnz	w13, #0x6, 0xcf0 <_llm_rows.packet_batch.blocks+0x984>
     d30:      	tbz	w13, #0x7, 0xd3c <_llm_rows.packet_batch.blocks+0x9d0>
     d34:      	add	x12, x12, #0x1c
     d38:      	ld1.s	{ v26 }[3], [x12]
     d3c:      	orr.16b	v16, v16, v31
     d40:      	orr.16b	v18, v18, v31
     d44:      	orr.16b	v17, v17, v31
     d48:      	mov.16b	v1, v16
     d4c:      	umlal.2d	v1, v5, v2
     d50:      	mov.16b	v3, v17
     d54:      	umlal.2d	v3, v4, v2
     d58:      	mov.16b	v4, v18
     d5c:      	umlal.2d	v4, v8, v2
     d60:      	umlal.2d	v30, v15, v2
     d64:      	mov	b2, v29[0]
     d68:      	mov.b	v2[4], v29[1]
     d6c:      	ushll.2d	v2, v2, #0x0
     d70:      	shl.2d	v2, v2, #0x3f
     d74:      	cmlt.2d	v2, v2, #0
     d78:      	and.16b	v2, v2, v30
     d7c:      	mov	b5, v29[2]
     d80:      	mov.b	v5[4], v29[3]
     d84:      	ushll.2d	v5, v5, #0x0
     d88:      	shl.2d	v5, v5, #0x3f
     d8c:      	cmlt.2d	v5, v5, #0
     d90:      	and.16b	v4, v5, v4
     d94:      	mov	b5, v29[4]
     d98:      	mov.b	v5[4], v29[5]
     d9c:      	ushll.2d	v5, v5, #0x0
     da0:      	shl.2d	v5, v5, #0x3f
     da4:      	cmlt.2d	v5, v5, #0
     da8:      	mov	b30, v29[6]
     dac:      	mov.b	v30[4], v29[7]
     db0:      	and.16b	v3, v5, v3
     db4:      	ushll.2d	v5, v30, #0x0
     db8:      	shl.2d	v5, v5, #0x3f
     dbc:      	cmlt.2d	v5, v5, #0
     dc0:      	and.16b	v1, v5, v1
     dc4:      	stp	q3, q1, [sp, #0x1d0]
     dc8:      	stp	q2, q4, [sp, #0x1b0]
     dcc:      	and	x12, x11, #0x7
     dd0:      	add	x13, sp, #0x1b0
     dd4:      	ldr	x12, [x13, x12, lsl #3]
     dd8:      	fmov	w13, s27
     ddc:      	sub	x12, x12, x11
     de0:      	lsl	x12, x12, #2
     de4:      	add	x10, x10, x12
     de8:      	movi.2d	v2, #0000000000000000
     dec:      	movi.2d	v1, #0000000000000000
     df0:      	tbz	w13, #0x0, 0xe7c <_llm_rows.packet_batch.blocks+0xb10>
     df4:      	ldr	s2, [x10]
     df8:      	tbnz	w13, #0x1, 0xe80 <_llm_rows.packet_batch.blocks+0xb14>
     dfc:      	tbz	w13, #0x2, 0xe8c <_llm_rows.packet_batch.blocks+0xb20>
     e00:      	add	x14, x10, #0x8
     e04:      	ld1.s	{ v2 }[2], [x14]
     e08:      	tbnz	w13, #0x3, 0xe90 <_llm_rows.packet_batch.blocks+0xb24>
     e0c:      	tbz	w13, #0x4, 0xe9c <_llm_rows.packet_batch.blocks+0xb30>
     e10:      	add	x14, x10, #0x10
     e14:      	ld1.s	{ v1 }[0], [x14]
     e18:      	tbnz	w13, #0x5, 0xea0 <_llm_rows.packet_batch.blocks+0xb34>
     e1c:      	tbz	w13, #0x6, 0xeac <_llm_rows.packet_batch.blocks+0xb40>
     e20:      	add	x14, x10, #0x18
     e24:      	ld1.s	{ v1 }[2], [x14]
     e28:      	tbnz	w13, #0x7, 0xeb0 <_llm_rows.packet_batch.blocks+0xb44>
     e2c:      	add	x9, x9, x12
     e30:      	fmov	w10, s27
     e34:      	movi.2d	v4, #0000000000000000
     e38:      	movi.2d	v3, #0000000000000000
     e3c:      	tbz	w10, #0x0, 0xecc <_llm_rows.packet_batch.blocks+0xb60>
     e40:      	ldr	s4, [x9]
     e44:      	tbnz	w10, #0x1, 0xed0 <_llm_rows.packet_batch.blocks+0xb64>
     e48:      	tbz	w10, #0x2, 0xedc <_llm_rows.packet_batch.blocks+0xb70>
     e4c:      	add	x12, x9, #0x8
     e50:      	ld1.s	{ v4 }[2], [x12]
     e54:      	tbnz	w10, #0x3, 0xee0 <_llm_rows.packet_batch.blocks+0xb74>
     e58:      	tbz	w10, #0x4, 0xeec <_llm_rows.packet_batch.blocks+0xb80>
     e5c:      	add	x12, x9, #0x10
     e60:      	ld1.s	{ v3 }[0], [x12]
     e64:      	tbnz	w10, #0x5, 0xef0 <_llm_rows.packet_batch.blocks+0xb84>
     e68:      	tbz	w10, #0x6, 0xefc <_llm_rows.packet_batch.blocks+0xb90>
     e6c:      	add	x12, x9, #0x18
     e70:      	ld1.s	{ v3 }[2], [x12]
     e74:      	tbnz	w10, #0x7, 0xf00 <_llm_rows.packet_batch.blocks+0xb94>
     e78:      	b	0xf08 <_llm_rows.packet_batch.blocks+0xb9c>
     e7c:      	tbz	w13, #0x1, 0xdfc <_llm_rows.packet_batch.blocks+0xa90>
     e80:      	add	x14, x10, #0x4
     e84:      	ld1.s	{ v2 }[1], [x14]
     e88:      	tbnz	w13, #0x2, 0xe00 <_llm_rows.packet_batch.blocks+0xa94>
     e8c:      	tbz	w13, #0x3, 0xe0c <_llm_rows.packet_batch.blocks+0xaa0>
     e90:      	add	x14, x10, #0xc
     e94:      	ld1.s	{ v2 }[3], [x14]
     e98:      	tbnz	w13, #0x4, 0xe10 <_llm_rows.packet_batch.blocks+0xaa4>
     e9c:      	tbz	w13, #0x5, 0xe1c <_llm_rows.packet_batch.blocks+0xab0>
     ea0:      	add	x14, x10, #0x14
     ea4:      	ld1.s	{ v1 }[1], [x14]
     ea8:      	tbnz	w13, #0x6, 0xe20 <_llm_rows.packet_batch.blocks+0xab4>
     eac:      	tbz	w13, #0x7, 0xe2c <_llm_rows.packet_batch.blocks+0xac0>
     eb0:      	add	x10, x10, #0x1c
     eb4:      	ld1.s	{ v1 }[3], [x10]
     eb8:      	add	x9, x9, x12
     ebc:      	fmov	w10, s27
     ec0:      	movi.2d	v4, #0000000000000000
     ec4:      	movi.2d	v3, #0000000000000000
     ec8:      	tbnz	w10, #0x0, 0xe40 <_llm_rows.packet_batch.blocks+0xad4>
     ecc:      	tbz	w10, #0x1, 0xe48 <_llm_rows.packet_batch.blocks+0xadc>
     ed0:      	add	x12, x9, #0x4
     ed4:      	ld1.s	{ v4 }[1], [x12]
     ed8:      	tbnz	w10, #0x2, 0xe4c <_llm_rows.packet_batch.blocks+0xae0>
     edc:      	tbz	w10, #0x3, 0xe58 <_llm_rows.packet_batch.blocks+0xaec>
     ee0:      	add	x12, x9, #0xc
     ee4:      	ld1.s	{ v4 }[3], [x12]
     ee8:      	tbnz	w10, #0x4, 0xe5c <_llm_rows.packet_batch.blocks+0xaf0>
     eec:      	tbz	w10, #0x5, 0xe68 <_llm_rows.packet_batch.blocks+0xafc>
     ef0:      	add	x12, x9, #0x14
     ef4:      	ld1.s	{ v3 }[1], [x12]
     ef8:      	tbnz	w10, #0x6, 0xe6c <_llm_rows.packet_batch.blocks+0xb00>
     efc:      	tbz	w10, #0x7, 0xf08 <_llm_rows.packet_batch.blocks+0xb9c>
     f00:      	add	x9, x9, #0x1c
     f04:      	ld1.s	{ v3 }[3], [x9]
     f08:      	add.2d	v17, v19, v17
     f0c:      	add.2d	v6, v6, v18
     f10:      	add.2d	v7, v7, v16
     f14:      	fmul.4s	v5, v22, v2
     f18:      	fmul.4s	v16, v28, v4
     f1c:      	fsub.4s	v5, v5, v16
     f20:      	stp	q23, q6, [sp, #0x170]
     f24:      	stp	q17, q7, [sp, #0x190]
     f28:      	and	x9, x11, #0x7
     f2c:      	add	x10, sp, #0x170
     f30:      	ldr	x9, [x10, x9, lsl #3]
     f34:      	sub	x9, x9, x11
     f38:      	add	x9, x8, x9, lsl #2
     f3c:      	fmov	w10, s27
     f40:      	tbz	w10, #0x0, 0xf88 <_llm_rows.packet_batch.blocks+0xc1c>
     f44:      	str	s5, [x9]
     f48:      	tbnz	w10, #0x1, 0xf8c <_llm_rows.packet_batch.blocks+0xc20>
     f4c:      	tbz	w10, #0x2, 0xf98 <_llm_rows.packet_batch.blocks+0xc2c>
     f50:      	add	x12, x9, #0x8
     f54:      	st1.s	{ v5 }[2], [x12]
     f58:      	tbnz	w10, #0x3, 0xf9c <_llm_rows.packet_batch.blocks+0xc30>
     f5c:      	fmul.4s	v5, v0, v1
     f60:      	fmul.4s	v6, v26, v3
     f64:      	fsub.4s	v5, v5, v6
     f68:      	tbz	w10, #0x4, 0xfb4 <_llm_rows.packet_batch.blocks+0xc48>
     f6c:      	str	s5, [x9, #0x10]
     f70:      	tbnz	w10, #0x5, 0xfb8 <_llm_rows.packet_batch.blocks+0xc4c>
     f74:      	tbz	w10, #0x6, 0xfc4 <_llm_rows.packet_batch.blocks+0xc58>
     f78:      	add	x12, x9, #0x18
     f7c:      	st1.s	{ v5 }[2], [x12]
     f80:      	tbnz	w10, #0x7, 0xfc8 <_llm_rows.packet_batch.blocks+0xc5c>
     f84:      	b	0xfd0 <_llm_rows.packet_batch.blocks+0xc64>
     f88:      	tbz	w10, #0x1, 0xf4c <_llm_rows.packet_batch.blocks+0xbe0>
     f8c:      	add	x12, x9, #0x4
     f90:      	st1.s	{ v5 }[1], [x12]
     f94:      	tbnz	w10, #0x2, 0xf50 <_llm_rows.packet_batch.blocks+0xbe4>
     f98:      	tbz	w10, #0x3, 0xf5c <_llm_rows.packet_batch.blocks+0xbf0>
     f9c:      	add	x12, x9, #0xc
     fa0:      	st1.s	{ v5 }[3], [x12]
     fa4:      	fmul.4s	v5, v0, v1
     fa8:      	fmul.4s	v6, v26, v3
     fac:      	fsub.4s	v5, v5, v6
     fb0:      	tbnz	w10, #0x4, 0xf6c <_llm_rows.packet_batch.blocks+0xc00>
     fb4:      	tbz	w10, #0x5, 0xf74 <_llm_rows.packet_batch.blocks+0xc08>
     fb8:      	add	x12, x9, #0x14
     fbc:      	st1.s	{ v5 }[1], [x12]
     fc0:      	tbnz	w10, #0x6, 0xf78 <_llm_rows.packet_batch.blocks+0xc0c>
     fc4:      	tbz	w10, #0x7, 0xfd0 <_llm_rows.packet_batch.blocks+0xc64>
     fc8:      	add	x9, x9, #0x1c
     fcc:      	st1.s	{ v5 }[3], [x9]
     fd0:      	fmul.4s	v4, v22, v4
     fd4:      	fmul.4s	v2, v28, v2
     fd8:      	fadd.4s	v2, v2, v4
     fdc:      	stp	q25, q24, [sp, #0x130]
     fe0:      	stp	q21, q20, [sp, #0x150]
     fe4:      	and	x9, x11, #0x7
     fe8:      	add	x10, sp, #0x130
     fec:      	ldr	x9, [x10, x9, lsl #3]
     ff0:      	sub	x9, x9, x11
     ff4:      	add	x8, x8, x9, lsl #2
     ff8:      	fmov	w9, s27
     ffc:      	tbz	w9, #0x0, 0x1044 <_llm_rows.packet_batch.blocks+0xcd8>
    1000:      	str	s2, [x8]
    1004:      	tbnz	w9, #0x1, 0x1048 <_llm_rows.packet_batch.blocks+0xcdc>
    1008:      	tbz	w9, #0x2, 0x1054 <_llm_rows.packet_batch.blocks+0xce8>
    100c:      	add	x10, x8, #0x8
    1010:      	st1.s	{ v2 }[2], [x10]
    1014:      	tbnz	w9, #0x3, 0x1058 <_llm_rows.packet_batch.blocks+0xcec>
    1018:      	fmul.4s	v0, v0, v3
    101c:      	fmul.4s	v1, v26, v1
    1020:      	fadd.4s	v0, v1, v0
    1024:      	tbz	w9, #0x4, 0x1de8 <_llm_rows.packet_batch.blocks+0x1a7c>
    1028:      	str	s0, [x8, #0x10]
    102c:      	tbnz	w9, #0x5, 0x1dec <_llm_rows.packet_batch.blocks+0x1a80>
    1030:      	tbz	w9, #0x6, 0x1df8 <_llm_rows.packet_batch.blocks+0x1a8c>
    1034:      	add	x10, x8, #0x18
    1038:      	st1.s	{ v0 }[2], [x10]
    103c:      	tbnz	w9, #0x7, 0x1dfc <_llm_rows.packet_batch.blocks+0x1a90>
    1040:      	b	0x444 <_llm_rows.packet_batch.blocks+0xd8>
    1044:      	tbz	w9, #0x1, 0x1008 <_llm_rows.packet_batch.blocks+0xc9c>
    1048:      	add	x10, x8, #0x4
    104c:      	st1.s	{ v2 }[1], [x10]
    1050:      	tbnz	w9, #0x2, 0x100c <_llm_rows.packet_batch.blocks+0xca0>
    1054:      	tbz	w9, #0x3, 0x1018 <_llm_rows.packet_batch.blocks+0xcac>
    1058:      	add	x10, x8, #0xc
    105c:      	st1.s	{ v2 }[3], [x10]
    1060:      	fmul.4s	v0, v0, v3
    1064:      	fmul.4s	v1, v26, v1
    1068:      	fadd.4s	v0, v1, v0
    106c:      	tbz	w9, #0x4, 0x1de8 <_llm_rows.packet_batch.blocks+0x1a7c>
    1070:      	b	0x1028 <_llm_rows.packet_batch.blocks+0xcbc>
    1074:      	mov	x13, #0x0               ; =0
    1078:      	fmov	w11, s1
    107c:      	cmp	w11, #0x0
    1080:      	cset	w11, ne
    1084:      	csel	x16, x15, xzr, ne
    1088:      	mov	w14, #0x4008            ; =16392
    108c:      	umaddl	x14, w16, w14, x12
    1090:      	add	x5, sp, #0x6, lsl #12   ; =0x6000
    1094:      	add	x5, x5, #0x4b0
    1098:      	mov	w6, #0x2004             ; =8196
    109c:      	b	0x10c0 <_llm_rows.packet_batch.blocks+0xd54>
    10a0:      	add	x17, x5, x13
    10a4:      	ldp	q3, q24, [x17]
    10a8:      	bif.16b	v1, v24, v6
    10ac:      	bit.16b	v3, v19, v0
    10b0:      	stp	q3, q1, [x17]
    10b4:      	add	x13, x13, #0x20
    10b8:      	cmp	x13, #0x2, lsl #12      ; =0x2000
    10bc:      	b.eq	0x1160 <_llm_rows.packet_batch.blocks+0xdf4>
    10c0:      	and.16b	v1, v22, v10
    10c4:      	addv.8h	h7, v1
    10c8:      	fmov	w0, s7
    10cc:      	add	x17, x14, x13
    10d0:      	movi.2d	v19, #0000000000000000
    10d4:      	movi.2d	v1, #0000000000000000
    10d8:      	tbz	w0, #0x0, 0x111c <_llm_rows.packet_batch.blocks+0xdb0>
    10dc:      	ldr	s19, [x17]
    10e0:      	and	w0, w0, #0xff
    10e4:      	tbnz	w0, #0x1, 0x1124 <_llm_rows.packet_batch.blocks+0xdb8>
    10e8:      	tbz	w0, #0x2, 0x1130 <_llm_rows.packet_batch.blocks+0xdc4>
    10ec:      	add	x1, x17, #0x8
    10f0:      	ld1.s	{ v19 }[2], [x1]
    10f4:      	tbnz	w0, #0x3, 0x1134 <_llm_rows.packet_batch.blocks+0xdc8>
    10f8:      	tbz	w0, #0x4, 0x1140 <_llm_rows.packet_batch.blocks+0xdd4>
    10fc:      	add	x1, x17, #0x10
    1100:      	ld1.s	{ v1 }[0], [x1]
    1104:      	tbnz	w0, #0x5, 0x1144 <_llm_rows.packet_batch.blocks+0xdd8>
    1108:      	tbz	w0, #0x6, 0x1150 <_llm_rows.packet_batch.blocks+0xde4>
    110c:      	add	x1, x17, #0x18
    1110:      	ld1.s	{ v1 }[2], [x1]
    1114:      	tbz	w0, #0x7, 0x10a0 <_llm_rows.packet_batch.blocks+0xd34>
    1118:      	b	0x1154 <_llm_rows.packet_batch.blocks+0xde8>
    111c:      	and	w0, w0, #0xff
    1120:      	tbz	w0, #0x1, 0x10e8 <_llm_rows.packet_batch.blocks+0xd7c>
    1124:      	add	x1, x17, #0x4
    1128:      	ld1.s	{ v19 }[1], [x1]
    112c:      	tbnz	w0, #0x2, 0x10ec <_llm_rows.packet_batch.blocks+0xd80>
    1130:      	tbz	w0, #0x3, 0x10f8 <_llm_rows.packet_batch.blocks+0xd8c>
    1134:      	add	x1, x17, #0xc
    1138:      	ld1.s	{ v19 }[3], [x1]
    113c:      	tbnz	w0, #0x4, 0x10fc <_llm_rows.packet_batch.blocks+0xd90>
    1140:      	tbz	w0, #0x5, 0x1108 <_llm_rows.packet_batch.blocks+0xd9c>
    1144:      	add	x1, x17, #0x14
    1148:      	ld1.s	{ v1 }[1], [x1]
    114c:      	tbnz	w0, #0x6, 0x110c <_llm_rows.packet_batch.blocks+0xda0>
    1150:      	tbz	w0, #0x7, 0x10a0 <_llm_rows.packet_batch.blocks+0xd34>
    1154:      	add	x17, x17, #0x1c
    1158:      	ld1.s	{ v1 }[3], [x17]
    115c:      	b	0x10a0 <_llm_rows.packet_batch.blocks+0xd34>
    1160:      	xtn.4h	v1, v0
    1164:      	uzp1.8b	v1, v1, v0
    1168:      	movi.2d	v19, #0000000000000000
    116c:      	mov.b	v19[0], v1[0]
    1170:      	adrp	x13, 0x1000 <_llm_rows.packet_batch.blocks+0xc94>
    1174:      	ldr	d31, [x13]
    1178:      	and.8b	v3, v19, v31
    117c:      	addv.8b	b3, v3
    1180:      	fmov	w14, s3
    1184:      	umaxv.8b	b3, v19
    1188:      	fmov	w0, s3
    118c:      	rbit	w13, w14
    1190:      	clz	w13, w13
    1194:      	tst	w0, #0x1
    1198:      	csel	w13, w13, wzr, ne
    119c:      	mov	w17, #0x800             ; =2048
    11a0:      	dup.2d	v26, x17
    11a4:      	orr.16b	v11, v20, v26
    11a8:      	mov.16b	v22, v11
    11ac:      	ldr	d3, [sp, #0xc8]
    11b0:      	umlal.2d	v22, v15, v3
    11b4:      	movi.2d	v3, #0000000000000000
    11b8:      	mov.b	v3[0], v1[0]
    11bc:      	ushll.2d	v1, v3, #0x0
    11c0:      	shl.2d	v1, v1, #0x3f
    11c4:      	cmlt.2d	v1, v1, #0
    11c8:      	str	q22, [sp, #0x40]
    11cc:      	and.16b	v1, v1, v22
    11d0:      	movi.2d	v3, #0000000000000000
    11d4:      	str	q3, [sp, #0x430]
    11d8:      	str	q3, [sp, #0x420]
    11dc:      	str	q3, [sp, #0x410]
    11e0:      	str	q1, [sp, #0x400]
    11e4:      	and	x17, x13, #0x7
    11e8:      	add	x1, sp, #0x400
    11ec:      	ldr	x17, [x1, x17, lsl #3]
    11f0:      	sub	x17, x17, x13
    11f4:      	add	x17, x12, x17, lsl #2
    11f8:      	movi.2d	v24, #0000000000000000
    11fc:      	movi.2d	v25, #0000000000000000
    1200:      	tbz	w0, #0x0, 0x1244 <_llm_rows.packet_batch.blocks+0xed8>
    1204:      	ldr	s24, [x17]
    1208:      	tbnz	w14, #0x1, 0x1248 <_llm_rows.packet_batch.blocks+0xedc>
    120c:      	tbz	w14, #0x2, 0x1254 <_llm_rows.packet_batch.blocks+0xee8>
    1210:      	add	x0, x17, #0x8
    1214:      	ld1.s	{ v24 }[2], [x0]
    1218:      	tbnz	w14, #0x3, 0x1258 <_llm_rows.packet_batch.blocks+0xeec>
    121c:      	tbz	w14, #0x4, 0x1264 <_llm_rows.packet_batch.blocks+0xef8>
    1220:      	add	x0, x17, #0x10
    1224:      	ld1.s	{ v25 }[0], [x0]
    1228:      	tbnz	w14, #0x5, 0x1268 <_llm_rows.packet_batch.blocks+0xefc>
    122c:      	tbz	w14, #0x6, 0x1274 <_llm_rows.packet_batch.blocks+0xf08>
    1230:      	add	x0, x17, #0x18
    1234:      	ld1.s	{ v25 }[2], [x0]
    1238:      	fmov	d22, d8
    123c:      	tbnz	w14, #0x7, 0x127c <_llm_rows.packet_batch.blocks+0xf10>
    1240:      	b	0x1284 <_llm_rows.packet_batch.blocks+0xf18>
    1244:      	tbz	w14, #0x1, 0x120c <_llm_rows.packet_batch.blocks+0xea0>
    1248:      	add	x0, x17, #0x4
    124c:      	ld1.s	{ v24 }[1], [x0]
    1250:      	tbnz	w14, #0x2, 0x1210 <_llm_rows.packet_batch.blocks+0xea4>
    1254:      	tbz	w14, #0x3, 0x121c <_llm_rows.packet_batch.blocks+0xeb0>
    1258:      	add	x0, x17, #0xc
    125c:      	ld1.s	{ v24 }[3], [x0]
    1260:      	tbnz	w14, #0x4, 0x1220 <_llm_rows.packet_batch.blocks+0xeb4>
    1264:      	tbz	w14, #0x5, 0x122c <_llm_rows.packet_batch.blocks+0xec0>
    1268:      	add	x0, x17, #0x14
    126c:      	ld1.s	{ v25 }[1], [x0]
    1270:      	tbnz	w14, #0x6, 0x1230 <_llm_rows.packet_batch.blocks+0xec4>
    1274:      	fmov	d22, d8
    1278:      	tbz	w14, #0x7, 0x1284 <_llm_rows.packet_batch.blocks+0xf18>
    127c:      	add	x17, x17, #0x1c
    1280:      	ld1.s	{ v25 }[3], [x17]
    1284:      	mov	x1, #0x0                ; =0
    1288:      	orr.16b	v12, v16, v26
    128c:      	orr.16b	v14, v18, v26
    1290:      	orr.16b	v13, v17, v26
    1294:      	fmov	d8, d15
    1298:      	ldr	d1, [sp, #0xc8]
    129c:      	umull.2d	v9, v15, v1
    12a0:      	umull.2d	v10, v22, v1
    12a4:      	umull.2d	v15, v4, v1
    12a8:      	umull.2d	v28, v5, v1
    12ac:      	mov.16b	v26, v13
    12b0:      	stp	d5, d4, [sp, #0x60]
    12b4:      	umlal.2d	v26, v4, v1
    12b8:      	mov.16b	v4, v14
    12bc:      	umlal.2d	v4, v22, v1
    12c0:      	stp	q4, q26, [sp, #0x20]
    12c4:      	mov.16b	v3, v12
    12c8:      	umlal.2d	v3, v5, v1
    12cc:      	str	q3, [sp, #0x10]
    12d0:      	adrp	x17, 0x1000 <_llm_rows.packet_batch.blocks+0xc94>
    12d4:      	ldr	q1, [x17]
    12d8:      	mov	w17, #0x2000            ; =8192
    12dc:      	dup.2d	v3, x17
    12e0:      	sshll.2d	v26, v0, #0x0
    12e4:      	bif.16b	v1, v3, v26
    12e8:      	adrp	x17, 0x1000 <_llm_rows.packet_batch.blocks+0xc94>
    12ec:      	ldr	q26, [x17]
    12f0:      	sshll.2d	v27, v6, #0x0
    12f4:      	bif.16b	v26, v3, v27
    12f8:      	adrp	x17, 0x1000 <_llm_rows.packet_batch.blocks+0xc94>
    12fc:      	ldr	q27, [x17]
    1300:      	bsl.16b	v23, v27, v3
    1304:      	adrp	x17, 0x1000 <_llm_rows.packet_batch.blocks+0xc94>
    1308:      	ldr	q27, [x17]
    130c:      	bit.16b	v3, v27, v21
    1310:      	stp	q26, q3, [sp, #0x3e0]
    1314:      	stp	q1, q23, [sp, #0x3c0]
    1318:      	and	x17, x13, #0x7
    131c:      	add	x0, sp, #0x3c0
    1320:      	ldr	x17, [x0, x17, lsl #3]
    1324:      	sub	x17, x17, x13, lsl #2
    1328:      	tst	w14, #0xff
    132c:      	csel	x14, xzr, x17, eq
    1330:      	add	x17, x5, x14
    1334:      	ldp	q1, q3, [x17]
    1338:      	zip2.8b	v21, v19, v0
    133c:      	ushll.4s	v21, v21, #0x0
    1340:      	shl.4s	v21, v21, #0x1f
    1344:      	cmlt.4s	v21, v21, #0
    1348:      	mov.16b	v4, v21
    134c:      	bsl.16b	v4, v25, v3
    1350:      	zip1.8b	v3, v19, v0
    1354:      	ushll.4s	v3, v3, #0x0
    1358:      	shl.4s	v3, v3, #0x1f
    135c:      	cmlt.4s	v3, v3, #0
    1360:      	bit.16b	v1, v24, v3
    1364:      	str	q1, [sp, #0xb0]
    1368:      	stp	q1, q4, [x17]
    136c:      	str	q4, [sp, #0x50]
    1370:      	mov	w17, #0x1               ; =1
    1374:      	dup.2d	v1, x17
    1378:      	ushll2.2d	v3, v6, #0x0
    137c:      	and.16b	v24, v3, v1
    1380:      	ushll2.2d	v3, v0, #0x0
    1384:      	and.16b	v25, v3, v1
    1388:      	ushll.2d	v3, v6, #0x0
    138c:      	and.16b	v26, v3, v1
    1390:      	ushll.2d	v3, v0, #0x0
    1394:      	and.16b	v27, v3, v1
    1398:      	add	x17, x15, x15, lsl #11
    139c:      	lsl	x15, x17, #3
    13a0:      	cmp	w11, #0x0
    13a4:      	csel	x15, x15, xzr, ne
    13a8:      	add	x0, x12, x15
    13ac:      	add	x0, x0, x6
    13b0:      	movi.2d	v23, #0000000000000000
    13b4:      	movi.2d	v21, #0000000000000000
    13b8:      	movi.2d	v29, #0000000000000000
    13bc:      	movi.2d	v30, #0000000000000000
    13c0:      	b	0x13fc <_llm_rows.packet_batch.blocks+0x1090>
    13c4:      	add	x1, x27, x1
    13c8:      	ldp	q4, q5, [x1]
    13cc:      	bif.16b	v3, v5, v6
    13d0:      	bif.16b	v1, v4, v0
    13d4:      	stp	q1, q3, [x1]
    13d8:      	add.2d	v1, v23, v27
    13dc:      	add.2d	v21, v21, v25
    13e0:      	add.2d	v29, v29, v26
    13e4:      	add.2d	v30, v30, v24
    13e8:      	fmov	x1, d23
    13ec:      	add	x1, x1, x11
    13f0:      	mov.16b	v23, v1
    13f4:      	cmp	x1, #0x100
    13f8:      	b.ge	0x1498 <_llm_rows.packet_batch.blocks+0x112c>
    13fc:      	fmov	w3, s7
    1400:      	lsl	x1, x1, #5
    1404:      	add	x2, x0, x1
    1408:      	movi.2d	v1, #0000000000000000
    140c:      	movi.2d	v3, #0000000000000000
    1410:      	tbz	w3, #0x0, 0x1454 <_llm_rows.packet_batch.blocks+0x10e8>
    1414:      	ldr	s1, [x2]
    1418:      	and	w3, w3, #0xff
    141c:      	tbnz	w3, #0x1, 0x145c <_llm_rows.packet_batch.blocks+0x10f0>
    1420:      	tbz	w3, #0x2, 0x1468 <_llm_rows.packet_batch.blocks+0x10fc>
    1424:      	add	x4, x2, #0x8
    1428:      	ld1.s	{ v1 }[2], [x4]
    142c:      	tbnz	w3, #0x3, 0x146c <_llm_rows.packet_batch.blocks+0x1100>
    1430:      	tbz	w3, #0x4, 0x1478 <_llm_rows.packet_batch.blocks+0x110c>
    1434:      	add	x4, x2, #0x10
    1438:      	ld1.s	{ v3 }[0], [x4]
    143c:      	tbnz	w3, #0x5, 0x147c <_llm_rows.packet_batch.blocks+0x1110>
    1440:      	tbz	w3, #0x6, 0x1488 <_llm_rows.packet_batch.blocks+0x111c>
    1444:      	add	x4, x2, #0x18
    1448:      	ld1.s	{ v3 }[2], [x4]
    144c:      	tbz	w3, #0x7, 0x13c4 <_llm_rows.packet_batch.blocks+0x1058>
    1450:      	b	0x148c <_llm_rows.packet_batch.blocks+0x1120>
    1454:      	and	w3, w3, #0xff
    1458:      	tbz	w3, #0x1, 0x1420 <_llm_rows.packet_batch.blocks+0x10b4>
    145c:      	add	x4, x2, #0x4
    1460:      	ld1.s	{ v1 }[1], [x4]
    1464:      	tbnz	w3, #0x2, 0x1424 <_llm_rows.packet_batch.blocks+0x10b8>
    1468:      	tbz	w3, #0x3, 0x1430 <_llm_rows.packet_batch.blocks+0x10c4>
    146c:      	add	x4, x2, #0xc
    1470:      	ld1.s	{ v1 }[3], [x4]
    1474:      	tbnz	w3, #0x4, 0x1434 <_llm_rows.packet_batch.blocks+0x10c8>
    1478:      	tbz	w3, #0x5, 0x1440 <_llm_rows.packet_batch.blocks+0x10d4>
    147c:      	add	x4, x2, #0x14
    1480:      	ld1.s	{ v3 }[1], [x4]
    1484:      	tbnz	w3, #0x6, 0x1444 <_llm_rows.packet_batch.blocks+0x10d8>
    1488:      	tbz	w3, #0x7, 0x13c4 <_llm_rows.packet_batch.blocks+0x1058>
    148c:      	add	x2, x2, #0x1c
    1490:      	ld1.s	{ v3 }[3], [x2]
    1494:      	b	0x13c4 <_llm_rows.packet_batch.blocks+0x1058>
    1498:      	add.2d	v1, v20, v9
    149c:      	add.2d	v3, v18, v10
    14a0:      	add.2d	v4, v17, v15
    14a4:      	add.2d	v5, v16, v28
    14a8:      	mov	w0, #0x1001             ; =4097
    14ac:      	dup.2d	v20, x0
    14b0:      	add.2d	v16, v5, v20
    14b4:      	add.2d	v17, v4, v20
    14b8:      	add.2d	v18, v3, v20
    14bc:      	mov	b3, v19[0]
    14c0:      	mov.b	v3[4], v19[1]
    14c4:      	add.2d	v20, v1, v20
    14c8:      	ushll.2d	v1, v3, #0x0
    14cc:      	shl.2d	v1, v1, #0x3f
    14d0:      	cmlt.2d	v1, v1, #0
    14d4:      	and.16b	v1, v1, v20
    14d8:      	mov	b3, v19[2]
    14dc:      	mov.b	v3[4], v19[3]
    14e0:      	ushll.2d	v3, v3, #0x0
    14e4:      	shl.2d	v3, v3, #0x3f
    14e8:      	cmlt.2d	v3, v3, #0
    14ec:      	and.16b	v3, v3, v18
    14f0:      	mov	b4, v19[4]
    14f4:      	mov.b	v4[4], v19[5]
    14f8:      	ushll.2d	v4, v4, #0x0
    14fc:      	shl.2d	v4, v4, #0x3f
    1500:      	cmlt.2d	v4, v4, #0
    1504:      	and.16b	v4, v4, v17
    1508:      	mov	b5, v19[6]
    150c:      	mov.b	v5[4], v19[7]
    1510:      	ushll.2d	v5, v5, #0x0
    1514:      	shl.2d	v5, v5, #0x3f
    1518:      	cmlt.2d	v5, v5, #0
    151c:      	and.16b	v5, v5, v16
    1520:      	shl.8b	v21, v19, #0x7
    1524:      	cmlt.8b	v21, v21, #0
    1528:      	and.8b	v21, v21, v31
    152c:      	addv.8b	b31, v21
    1530:      	fmov	w0, s31
    1534:      	stp	q4, q5, [sp, #0x390]
    1538:      	stp	q1, q3, [sp, #0x370]
    153c:      	and	x1, x13, #0x7
    1540:      	add	x2, sp, #0x370
    1544:      	ldr	x1, [x2, x1, lsl #3]
    1548:      	sub	x1, x1, x13
    154c:      	add	x12, x12, x1, lsl #2
    1550:      	movi.2d	v21, #0000000000000000
    1554:      	movi.2d	v1, #0000000000000000
    1558:      	tbz	w0, #0x0, 0x1598 <_llm_rows.packet_batch.blocks+0x122c>
    155c:      	ldr	s21, [x12]
    1560:      	tbnz	w0, #0x1, 0x159c <_llm_rows.packet_batch.blocks+0x1230>
    1564:      	tbz	w0, #0x2, 0x15a8 <_llm_rows.packet_batch.blocks+0x123c>
    1568:      	add	x1, x12, #0x8
    156c:      	ld1.s	{ v21 }[2], [x1]
    1570:      	tbnz	w0, #0x3, 0x15ac <_llm_rows.packet_batch.blocks+0x1240>
    1574:      	tbz	w0, #0x4, 0x15b8 <_llm_rows.packet_batch.blocks+0x124c>
    1578:      	add	x1, x12, #0x10
    157c:      	ld1.s	{ v1 }[0], [x1]
    1580:      	tbnz	w0, #0x5, 0x15bc <_llm_rows.packet_batch.blocks+0x1250>
    1584:      	tbz	w0, #0x6, 0x15c8 <_llm_rows.packet_batch.blocks+0x125c>
    1588:      	add	x1, x12, #0x18
    158c:      	ld1.s	{ v1 }[2], [x1]
    1590:      	tbnz	w0, #0x7, 0x15cc <_llm_rows.packet_batch.blocks+0x1260>
    1594:      	b	0x15d4 <_llm_rows.packet_batch.blocks+0x1268>
    1598:      	tbz	w0, #0x1, 0x1564 <_llm_rows.packet_batch.blocks+0x11f8>
    159c:      	add	x1, x12, #0x4
    15a0:      	ld1.s	{ v21 }[1], [x1]
    15a4:      	tbnz	w0, #0x2, 0x1568 <_llm_rows.packet_batch.blocks+0x11fc>
    15a8:      	tbz	w0, #0x3, 0x1574 <_llm_rows.packet_batch.blocks+0x1208>
    15ac:      	add	x1, x12, #0xc
    15b0:      	ld1.s	{ v21 }[3], [x1]
    15b4:      	tbnz	w0, #0x4, 0x1578 <_llm_rows.packet_batch.blocks+0x120c>
    15b8:      	tbz	w0, #0x5, 0x1584 <_llm_rows.packet_batch.blocks+0x1218>
    15bc:      	add	x1, x12, #0x14
    15c0:      	ld1.s	{ v1 }[1], [x1]
    15c4:      	tbnz	w0, #0x6, 0x1588 <_llm_rows.packet_batch.blocks+0x121c>
    15c8:      	tbz	w0, #0x7, 0x15d4 <_llm_rows.packet_batch.blocks+0x1268>
    15cc:      	add	x12, x12, #0x1c
    15d0:      	ld1.s	{ v1 }[3], [x12]
    15d4:      	mov	x0, #0x0                ; =0
    15d8:      	add	x12, x27, x14
    15dc:      	ldp	q3, q4, [x12]
    15e0:      	zip2.8b	v5, v19, v0
    15e4:      	ushll.4s	v5, v5, #0x0
    15e8:      	shl.4s	v5, v5, #0x1f
    15ec:      	cmlt.4s	v5, v5, #0
    15f0:      	mov.16b	v9, v5
    15f4:      	bsl.16b	v9, v1, v4
    15f8:      	zip1.8b	v1, v19, v0
    15fc:      	ushll.4s	v1, v1, #0x0
    1600:      	shl.4s	v1, v1, #0x1f
    1604:      	cmlt.4s	v1, v1, #0
    1608:      	mov.16b	v10, v1
    160c:      	bsl.16b	v10, v21, v3
    1610:      	stp	q10, q9, [x12]
    1614:      	umaddl	x12, w16, w6, x10
    1618:      	movi.2d	v21, #0000000000000000
    161c:      	movi.2d	v23, #0000000000000000
    1620:      	movi.2d	v28, #0000000000000000
    1624:      	movi.2d	v29, #0000000000000000
    1628:      	b	0x1664 <_llm_rows.packet_batch.blocks+0x12f8>
    162c:      	add	x16, x19, x16
    1630:      	ldp	q4, q5, [x16]
    1634:      	bif.16b	v3, v5, v6
    1638:      	bif.16b	v1, v4, v0
    163c:      	stp	q1, q3, [x16]
    1640:      	add.2d	v1, v21, v27
    1644:      	add.2d	v23, v23, v25
    1648:      	add.2d	v28, v28, v26
    164c:      	add.2d	v29, v29, v24
    1650:      	fmov	x16, d21
    1654:      	add	x0, x16, x11
    1658:      	mov.16b	v21, v1
    165c:      	cmp	x0, #0x100
    1660:      	b.ge	0x1700 <_llm_rows.packet_batch.blocks+0x1394>
    1664:      	fmov	w1, s7
    1668:      	lsl	x16, x0, #5
    166c:      	add	x0, x12, x16
    1670:      	movi.2d	v1, #0000000000000000
    1674:      	movi.2d	v3, #0000000000000000
    1678:      	tbz	w1, #0x0, 0x16bc <_llm_rows.packet_batch.blocks+0x1350>
    167c:      	ldr	s1, [x0]
    1680:      	and	w1, w1, #0xff
    1684:      	tbnz	w1, #0x1, 0x16c4 <_llm_rows.packet_batch.blocks+0x1358>
    1688:      	tbz	w1, #0x2, 0x16d0 <_llm_rows.packet_batch.blocks+0x1364>
    168c:      	add	x2, x0, #0x8
    1690:      	ld1.s	{ v1 }[2], [x2]
    1694:      	tbnz	w1, #0x3, 0x16d4 <_llm_rows.packet_batch.blocks+0x1368>
    1698:      	tbz	w1, #0x4, 0x16e0 <_llm_rows.packet_batch.blocks+0x1374>
    169c:      	add	x2, x0, #0x10
    16a0:      	ld1.s	{ v3 }[0], [x2]
    16a4:      	tbnz	w1, #0x5, 0x16e4 <_llm_rows.packet_batch.blocks+0x1378>
    16a8:      	tbz	w1, #0x6, 0x16f0 <_llm_rows.packet_batch.blocks+0x1384>
    16ac:      	add	x2, x0, #0x18
    16b0:      	ld1.s	{ v3 }[2], [x2]
    16b4:      	tbz	w1, #0x7, 0x162c <_llm_rows.packet_batch.blocks+0x12c0>
    16b8:      	b	0x16f4 <_llm_rows.packet_batch.blocks+0x1388>
    16bc:      	and	w1, w1, #0xff
    16c0:      	tbz	w1, #0x1, 0x1688 <_llm_rows.packet_batch.blocks+0x131c>
    16c4:      	add	x2, x0, #0x4
    16c8:      	ld1.s	{ v1 }[1], [x2]
    16cc:      	tbnz	w1, #0x2, 0x168c <_llm_rows.packet_batch.blocks+0x1320>
    16d0:      	tbz	w1, #0x3, 0x1698 <_llm_rows.packet_batch.blocks+0x132c>
    16d4:      	add	x2, x0, #0xc
    16d8:      	ld1.s	{ v1 }[3], [x2]
    16dc:      	tbnz	w1, #0x4, 0x169c <_llm_rows.packet_batch.blocks+0x1330>
    16e0:      	tbz	w1, #0x5, 0x16a8 <_llm_rows.packet_batch.blocks+0x133c>
    16e4:      	add	x2, x0, #0x14
    16e8:      	ld1.s	{ v3 }[1], [x2]
    16ec:      	tbnz	w1, #0x6, 0x16ac <_llm_rows.packet_batch.blocks+0x1340>
    16f0:      	tbz	w1, #0x7, 0x162c <_llm_rows.packet_batch.blocks+0x12c0>
    16f4:      	add	x0, x0, #0x1c
    16f8:      	ld1.s	{ v3 }[3], [x0]
    16fc:      	b	0x162c <_llm_rows.packet_batch.blocks+0x12c0>
    1700:      	ldp	d3, d1, [sp, #0x60]
    1704:      	umlal.2d	v12, v3, v2
    1708:      	umlal.2d	v13, v1, v2
    170c:      	umlal.2d	v14, v22, v2
    1710:      	umlal.2d	v11, v8, v2
    1714:      	mov	b1, v19[0]
    1718:      	mov.b	v1[4], v19[1]
    171c:      	ushll.2d	v1, v1, #0x0
    1720:      	shl.2d	v1, v1, #0x3f
    1724:      	cmlt.2d	v1, v1, #0
    1728:      	and.16b	v1, v1, v11
    172c:      	mov	b2, v19[2]
    1730:      	mov.b	v2[4], v19[3]
    1734:      	ushll.2d	v2, v2, #0x0
    1738:      	shl.2d	v2, v2, #0x3f
    173c:      	cmlt.2d	v2, v2, #0
    1740:      	and.16b	v2, v2, v14
    1744:      	mov	b3, v19[4]
    1748:      	mov.b	v3[4], v19[5]
    174c:      	ushll.2d	v3, v3, #0x0
    1750:      	shl.2d	v3, v3, #0x3f
    1754:      	cmlt.2d	v3, v3, #0
    1758:      	mov	b4, v19[6]
    175c:      	mov.b	v4[4], v19[7]
    1760:      	and.16b	v3, v3, v13
    1764:      	ushll.2d	v4, v4, #0x0
    1768:      	shl.2d	v4, v4, #0x3f
    176c:      	cmlt.2d	v4, v4, #0
    1770:      	and.16b	v4, v4, v12
    1774:      	stp	q3, q4, [sp, #0x340]
    1778:      	stp	q1, q2, [sp, #0x320]
    177c:      	and	x12, x13, #0x7
    1780:      	add	x16, sp, #0x320
    1784:      	ldr	x12, [x16, x12, lsl #3]
    1788:      	fmov	w16, s31
    178c:      	sub	x12, x12, x13
    1790:      	lsl	x12, x12, #2
    1794:      	add	x10, x10, x12
    1798:      	movi.2d	v2, #0000000000000000
    179c:      	movi.2d	v1, #0000000000000000
    17a0:      	tbz	w16, #0x0, 0x17e4 <_llm_rows.packet_batch.blocks+0x1478>
    17a4:      	ldr	s2, [x10]
    17a8:      	ldr	q8, [sp, #0x50]
    17ac:      	tbnz	w16, #0x1, 0x17ec <_llm_rows.packet_batch.blocks+0x1480>
    17b0:      	tbz	w16, #0x2, 0x17f8 <_llm_rows.packet_batch.blocks+0x148c>
    17b4:      	add	x0, x10, #0x8
    17b8:      	ld1.s	{ v2 }[2], [x0]
    17bc:      	tbnz	w16, #0x3, 0x17fc <_llm_rows.packet_batch.blocks+0x1490>
    17c0:      	tbz	w16, #0x4, 0x1808 <_llm_rows.packet_batch.blocks+0x149c>
    17c4:      	add	x0, x10, #0x10
    17c8:      	ld1.s	{ v1 }[0], [x0]
    17cc:      	tbnz	w16, #0x5, 0x180c <_llm_rows.packet_batch.blocks+0x14a0>
    17d0:      	tbz	w16, #0x6, 0x1818 <_llm_rows.packet_batch.blocks+0x14ac>
    17d4:      	add	x0, x10, #0x18
    17d8:      	ld1.s	{ v1 }[2], [x0]
    17dc:      	tbnz	w16, #0x7, 0x181c <_llm_rows.packet_batch.blocks+0x14b0>
    17e0:      	b	0x1824 <_llm_rows.packet_batch.blocks+0x14b8>
    17e4:      	ldr	q8, [sp, #0x50]
    17e8:      	tbz	w16, #0x1, 0x17b0 <_llm_rows.packet_batch.blocks+0x1444>
    17ec:      	add	x0, x10, #0x4
    17f0:      	ld1.s	{ v2 }[1], [x0]
    17f4:      	tbnz	w16, #0x2, 0x17b4 <_llm_rows.packet_batch.blocks+0x1448>
    17f8:      	tbz	w16, #0x3, 0x17c0 <_llm_rows.packet_batch.blocks+0x1454>
    17fc:      	add	x0, x10, #0xc
    1800:      	ld1.s	{ v2 }[3], [x0]
    1804:      	tbnz	w16, #0x4, 0x17c4 <_llm_rows.packet_batch.blocks+0x1458>
    1808:      	tbz	w16, #0x5, 0x17d0 <_llm_rows.packet_batch.blocks+0x1464>
    180c:      	add	x0, x10, #0x14
    1810:      	ld1.s	{ v1 }[1], [x0]
    1814:      	tbnz	w16, #0x6, 0x17d4 <_llm_rows.packet_batch.blocks+0x1468>
    1818:      	tbz	w16, #0x7, 0x1824 <_llm_rows.packet_batch.blocks+0x14b8>
    181c:      	add	x10, x10, #0x1c
    1820:      	ld1.s	{ v1 }[3], [x10]
    1824:      	mov	x16, #0x0               ; =0
    1828:      	add	x10, x19, x14
    182c:      	ldp	q3, q4, [x10]
    1830:      	zip2.8b	v5, v19, v0
    1834:      	ushll.4s	v5, v5, #0x0
    1838:      	shl.4s	v5, v5, #0x1f
    183c:      	cmlt.4s	v5, v5, #0
    1840:      	bif.16b	v1, v4, v5
    1844:      	zip1.8b	v4, v19, v0
    1848:      	ushll.4s	v4, v4, #0x0
    184c:      	shl.4s	v4, v4, #0x1f
    1850:      	cmlt.4s	v4, v4, #0
    1854:      	bif.16b	v2, v3, v4
    1858:      	stp	q2, q1, [x10]
    185c:      	lsl	x10, x17, #2
    1860:      	cmp	w11, #0x0
    1864:      	csel	x10, x10, xzr, ne
    1868:      	add	x10, x9, x10
    186c:      	movi.2d	v3, #0000000000000000
    1870:      	movi.2d	v4, #0000000000000000
    1874:      	movi.2d	v5, #0000000000000000
    1878:      	movi.2d	v21, #0000000000000000
    187c:      	b	0x18b8 <_llm_rows.packet_batch.blocks+0x154c>
    1880:      	add	x16, x21, x16
    1884:      	ldp	q29, q30, [x16]
    1888:      	bif.16b	v28, v30, v6
    188c:      	bif.16b	v23, v29, v0
    1890:      	stp	q23, q28, [x16]
    1894:      	add.2d	v23, v3, v27
    1898:      	add.2d	v4, v4, v25
    189c:      	add.2d	v5, v5, v26
    18a0:      	add.2d	v21, v21, v24
    18a4:      	fmov	x16, d3
    18a8:      	add	x16, x16, x11
    18ac:      	mov.16b	v3, v23
    18b0:      	cmp	x16, #0x100
    18b4:      	b.ge	0x1954 <_llm_rows.packet_batch.blocks+0x15e8>
    18b8:      	fmov	w0, s7
    18bc:      	lsl	x16, x16, #5
    18c0:      	add	x17, x10, x16
    18c4:      	movi.2d	v23, #0000000000000000
    18c8:      	movi.2d	v28, #0000000000000000
    18cc:      	tbz	w0, #0x0, 0x1910 <_llm_rows.packet_batch.blocks+0x15a4>
    18d0:      	ldr	s23, [x17]
    18d4:      	and	w0, w0, #0xff
    18d8:      	tbnz	w0, #0x1, 0x1918 <_llm_rows.packet_batch.blocks+0x15ac>
    18dc:      	tbz	w0, #0x2, 0x1924 <_llm_rows.packet_batch.blocks+0x15b8>
    18e0:      	add	x1, x17, #0x8
    18e4:      	ld1.s	{ v23 }[2], [x1]
    18e8:      	tbnz	w0, #0x3, 0x1928 <_llm_rows.packet_batch.blocks+0x15bc>
    18ec:      	tbz	w0, #0x4, 0x1934 <_llm_rows.packet_batch.blocks+0x15c8>
    18f0:      	add	x1, x17, #0x10
    18f4:      	ld1.s	{ v28 }[0], [x1]
    18f8:      	tbnz	w0, #0x5, 0x1938 <_llm_rows.packet_batch.blocks+0x15cc>
    18fc:      	tbz	w0, #0x6, 0x1944 <_llm_rows.packet_batch.blocks+0x15d8>
    1900:      	add	x1, x17, #0x18
    1904:      	ld1.s	{ v28 }[2], [x1]
    1908:      	tbz	w0, #0x7, 0x1880 <_llm_rows.packet_batch.blocks+0x1514>
    190c:      	b	0x1948 <_llm_rows.packet_batch.blocks+0x15dc>
    1910:      	and	w0, w0, #0xff
    1914:      	tbz	w0, #0x1, 0x18dc <_llm_rows.packet_batch.blocks+0x1570>
    1918:      	add	x1, x17, #0x4
    191c:      	ld1.s	{ v23 }[1], [x1]
    1920:      	tbnz	w0, #0x2, 0x18e0 <_llm_rows.packet_batch.blocks+0x1574>
    1924:      	tbz	w0, #0x3, 0x18ec <_llm_rows.packet_batch.blocks+0x1580>
    1928:      	add	x1, x17, #0xc
    192c:      	ld1.s	{ v23 }[3], [x1]
    1930:      	tbnz	w0, #0x4, 0x18f0 <_llm_rows.packet_batch.blocks+0x1584>
    1934:      	tbz	w0, #0x5, 0x18fc <_llm_rows.packet_batch.blocks+0x1590>
    1938:      	add	x1, x17, #0x14
    193c:      	ld1.s	{ v28 }[1], [x1]
    1940:      	tbnz	w0, #0x6, 0x1900 <_llm_rows.packet_batch.blocks+0x1594>
    1944:      	tbz	w0, #0x7, 0x1880 <_llm_rows.packet_batch.blocks+0x1514>
    1948:      	add	x17, x17, #0x1c
    194c:      	ld1.s	{ v28 }[3], [x17]
    1950:      	b	0x1880 <_llm_rows.packet_batch.blocks+0x1514>
    1954:      	add	x9, x9, x12
    1958:      	fmov	w10, s31
    195c:      	movi.2d	v4, #0000000000000000
    1960:      	movi.2d	v3, #0000000000000000
    1964:      	tbz	w10, #0x0, 0x19a4 <_llm_rows.packet_batch.blocks+0x1638>
    1968:      	ldr	s4, [x9]
    196c:      	tbnz	w10, #0x1, 0x19a8 <_llm_rows.packet_batch.blocks+0x163c>
    1970:      	tbz	w10, #0x2, 0x19b4 <_llm_rows.packet_batch.blocks+0x1648>
    1974:      	add	x12, x9, #0x8
    1978:      	ld1.s	{ v4 }[2], [x12]
    197c:      	tbnz	w10, #0x3, 0x19b8 <_llm_rows.packet_batch.blocks+0x164c>
    1980:      	tbz	w10, #0x4, 0x19c4 <_llm_rows.packet_batch.blocks+0x1658>
    1984:      	add	x12, x9, #0x10
    1988:      	ld1.s	{ v3 }[0], [x12]
    198c:      	tbnz	w10, #0x5, 0x19c8 <_llm_rows.packet_batch.blocks+0x165c>
    1990:      	tbz	w10, #0x6, 0x19d4 <_llm_rows.packet_batch.blocks+0x1668>
    1994:      	add	x12, x9, #0x18
    1998:      	ld1.s	{ v3 }[2], [x12]
    199c:      	tbnz	w10, #0x7, 0x19d8 <_llm_rows.packet_batch.blocks+0x166c>
    19a0:      	b	0x19e0 <_llm_rows.packet_batch.blocks+0x1674>
    19a4:      	tbz	w10, #0x1, 0x1970 <_llm_rows.packet_batch.blocks+0x1604>
    19a8:      	add	x12, x9, #0x4
    19ac:      	ld1.s	{ v4 }[1], [x12]
    19b0:      	tbnz	w10, #0x2, 0x1974 <_llm_rows.packet_batch.blocks+0x1608>
    19b4:      	tbz	w10, #0x3, 0x1980 <_llm_rows.packet_batch.blocks+0x1614>
    19b8:      	add	x12, x9, #0xc
    19bc:      	ld1.s	{ v4 }[3], [x12]
    19c0:      	tbnz	w10, #0x4, 0x1984 <_llm_rows.packet_batch.blocks+0x1618>
    19c4:      	tbz	w10, #0x5, 0x1990 <_llm_rows.packet_batch.blocks+0x1624>
    19c8:      	add	x12, x9, #0x14
    19cc:      	ld1.s	{ v3 }[1], [x12]
    19d0:      	tbnz	w10, #0x6, 0x1994 <_llm_rows.packet_batch.blocks+0x1628>
    19d4:      	tbz	w10, #0x7, 0x19e0 <_llm_rows.packet_batch.blocks+0x1674>
    19d8:      	add	x9, x9, #0x1c
    19dc:      	ld1.s	{ v3 }[3], [x9]
    19e0:      	mov	x10, #0x0               ; =0
    19e4:      	add	x9, x21, x14
    19e8:      	ldp	q5, q21, [x9]
    19ec:      	zip2.8b	v23, v19, v0
    19f0:      	ushll.4s	v23, v23, #0x0
    19f4:      	shl.4s	v23, v23, #0x1f
    19f8:      	cmlt.4s	v23, v23, #0
    19fc:      	bif.16b	v3, v21, v23
    1a00:      	zip1.8b	v21, v19, v0
    1a04:      	ushll.4s	v21, v21, #0x0
    1a08:      	shl.4s	v21, v21, #0x1f
    1a0c:      	cmlt.4s	v21, v21, #0
    1a10:      	bif.16b	v4, v5, v21
    1a14:      	stp	q4, q3, [x9]
    1a18:      	add	x9, x8, x15
    1a1c:      	movi.2d	v5, #0000000000000000
    1a20:      	movi.2d	v21, #0000000000000000
    1a24:      	movi.2d	v23, #0000000000000000
    1a28:      	movi.2d	v28, #0000000000000000
    1a2c:      	b	0x1a54 <_llm_rows.packet_batch.blocks+0x16e8>
    1a30:      	add.2d	v29, v5, v27
    1a34:      	add.2d	v21, v21, v25
    1a38:      	add.2d	v23, v23, v26
    1a3c:      	add.2d	v28, v28, v24
    1a40:      	fmov	x10, d5
    1a44:      	add	x10, x10, x11
    1a48:      	mov.16b	v5, v29
    1a4c:      	cmp	x10, #0x100
    1a50:      	b.ge	0x1b34 <_llm_rows.packet_batch.blocks+0x17c8>
    1a54:      	fmov	w12, s7
    1a58:      	lsl	x10, x10, #5
    1a5c:      	add	x14, x5, x10
    1a60:      	ldp	q11, q29, [x14]
    1a64:      	add	x14, x19, x10
    1a68:      	ldp	q12, q30, [x14]
    1a6c:      	fmul.4s	v13, v11, v12
    1a70:      	add	x14, x27, x10
    1a74:      	ldp	q14, q11, [x14]
    1a78:      	add	x14, x21, x10
    1a7c:      	ldp	q15, q12, [x14]
    1a80:      	fmul.4s	v14, v14, v15
    1a84:      	fsub.4s	v13, v13, v14
    1a88:      	and.16b	v13, v0, v13
    1a8c:      	add	x10, x9, x10
    1a90:      	tbz	w12, #0x0, 0x1ae0 <_llm_rows.packet_batch.blocks+0x1774>
    1a94:      	str	s13, [x10]
    1a98:      	and	w12, w12, #0xff
    1a9c:      	tbnz	w12, #0x1, 0x1ae8 <_llm_rows.packet_batch.blocks+0x177c>
    1aa0:      	tbz	w12, #0x2, 0x1af4 <_llm_rows.packet_batch.blocks+0x1788>
    1aa4:      	add	x14, x10, #0x8
    1aa8:      	st1.s	{ v13 }[2], [x14]
    1aac:      	tbnz	w12, #0x3, 0x1af8 <_llm_rows.packet_batch.blocks+0x178c>
    1ab0:      	fmul.4s	v29, v29, v30
    1ab4:      	fmul.4s	v30, v11, v12
    1ab8:      	fsub.4s	v29, v29, v30
    1abc:      	and.16b	v29, v6, v29
    1ac0:      	tbz	w12, #0x4, 0x1b14 <_llm_rows.packet_batch.blocks+0x17a8>
    1ac4:      	str	s29, [x10, #0x10]
    1ac8:      	tbnz	w12, #0x5, 0x1b18 <_llm_rows.packet_batch.blocks+0x17ac>
    1acc:      	tbz	w12, #0x6, 0x1b24 <_llm_rows.packet_batch.blocks+0x17b8>
    1ad0:      	add	x14, x10, #0x18
    1ad4:      	st1.s	{ v29 }[2], [x14]
    1ad8:      	tbz	w12, #0x7, 0x1a30 <_llm_rows.packet_batch.blocks+0x16c4>
    1adc:      	b	0x1b28 <_llm_rows.packet_batch.blocks+0x17bc>
    1ae0:      	and	w12, w12, #0xff
    1ae4:      	tbz	w12, #0x1, 0x1aa0 <_llm_rows.packet_batch.blocks+0x1734>
    1ae8:      	add	x14, x10, #0x4
    1aec:      	st1.s	{ v13 }[1], [x14]
    1af0:      	tbnz	w12, #0x2, 0x1aa4 <_llm_rows.packet_batch.blocks+0x1738>
    1af4:      	tbz	w12, #0x3, 0x1ab0 <_llm_rows.packet_batch.blocks+0x1744>
    1af8:      	add	x14, x10, #0xc
    1afc:      	st1.s	{ v13 }[3], [x14]
    1b00:      	fmul.4s	v29, v29, v30
    1b04:      	fmul.4s	v30, v11, v12
    1b08:      	fsub.4s	v29, v29, v30
    1b0c:      	and.16b	v29, v6, v29
    1b10:      	tbnz	w12, #0x4, 0x1ac4 <_llm_rows.packet_batch.blocks+0x1758>
    1b14:      	tbz	w12, #0x5, 0x1acc <_llm_rows.packet_batch.blocks+0x1760>
    1b18:      	add	x14, x10, #0x14
    1b1c:      	st1.s	{ v29 }[1], [x14]
    1b20:      	tbnz	w12, #0x6, 0x1ad0 <_llm_rows.packet_batch.blocks+0x1764>
    1b24:      	tbz	w12, #0x7, 0x1a30 <_llm_rows.packet_batch.blocks+0x16c4>
    1b28:      	add	x10, x10, #0x1c
    1b2c:      	st1.s	{ v29 }[3], [x10]
    1b30:      	b	0x1a30 <_llm_rows.packet_batch.blocks+0x16c4>
    1b34:      	ldr	q5, [sp, #0xb0]
    1b38:      	fmul.4s	v5, v5, v2
    1b3c:      	fmul.4s	v21, v10, v4
    1b40:      	fsub.4s	v5, v5, v21
    1b44:      	zip1.8b	v21, v19, v0
    1b48:      	ushll.4s	v21, v21, #0x0
    1b4c:      	shl.4s	v21, v21, #0x1f
    1b50:      	cmlt.4s	v21, v21, #0
    1b54:      	and.16b	v5, v21, v5
    1b58:      	fmov	w10, s31
    1b5c:      	ldr	q22, [sp, #0x40]
    1b60:      	ldp	q23, q28, [sp, #0x20]
    1b64:      	stp	q22, q23, [sp, #0x2d0]
    1b68:      	ldr	q21, [sp, #0x10]
    1b6c:      	stp	q28, q21, [sp, #0x2f0]
    1b70:      	and	x12, x13, #0x7
    1b74:      	add	x14, sp, #0x2d0
    1b78:      	ldr	x12, [x14, x12, lsl #3]
    1b7c:      	sub	x12, x12, x13
    1b80:      	add	x12, x8, x12, lsl #2
    1b84:      	tbz	w10, #0x0, 0x1ba4 <_llm_rows.packet_batch.blocks+0x1838>
    1b88:      	str	s5, [x12]
    1b8c:      	tbnz	w10, #0x1, 0x1ba8 <_llm_rows.packet_batch.blocks+0x183c>
    1b90:      	tbz	w10, #0x2, 0x1bb4 <_llm_rows.packet_batch.blocks+0x1848>
    1b94:      	add	x14, x12, #0x8
    1b98:      	st1.s	{ v5 }[2], [x14]
    1b9c:      	tbnz	w10, #0x3, 0x1bb8 <_llm_rows.packet_batch.blocks+0x184c>
    1ba0:      	b	0x1bc0 <_llm_rows.packet_batch.blocks+0x1854>
    1ba4:      	tbz	w10, #0x1, 0x1b90 <_llm_rows.packet_batch.blocks+0x1824>
    1ba8:      	add	x14, x12, #0x4
    1bac:      	st1.s	{ v5 }[1], [x14]
    1bb0:      	tbnz	w10, #0x2, 0x1b94 <_llm_rows.packet_batch.blocks+0x1828>
    1bb4:      	tbz	w10, #0x3, 0x1bc0 <_llm_rows.packet_batch.blocks+0x1854>
    1bb8:      	add	x14, x12, #0xc
    1bbc:      	st1.s	{ v5 }[3], [x14]
    1bc0:      	fmul.4s	v5, v8, v1
    1bc4:      	fmul.4s	v21, v9, v3
    1bc8:      	fsub.4s	v5, v5, v21
    1bcc:      	zip2.8b	v21, v19, v0
    1bd0:      	ushll.4s	v21, v21, #0x0
    1bd4:      	shl.4s	v21, v21, #0x1f
    1bd8:      	cmlt.4s	v21, v21, #0
    1bdc:      	and.16b	v5, v21, v5
    1be0:      	tbz	w10, #0x4, 0x1c00 <_llm_rows.packet_batch.blocks+0x1894>
    1be4:      	str	s5, [x12, #0x10]
    1be8:      	tbnz	w10, #0x5, 0x1c04 <_llm_rows.packet_batch.blocks+0x1898>
    1bec:      	tbz	w10, #0x6, 0x1c10 <_llm_rows.packet_batch.blocks+0x18a4>
    1bf0:      	add	x14, x12, #0x18
    1bf4:      	st1.s	{ v5 }[2], [x14]
    1bf8:      	tbnz	w10, #0x7, 0x1c14 <_llm_rows.packet_batch.blocks+0x18a8>
    1bfc:      	b	0x1c1c <_llm_rows.packet_batch.blocks+0x18b0>
    1c00:      	tbz	w10, #0x5, 0x1bec <_llm_rows.packet_batch.blocks+0x1880>
    1c04:      	add	x14, x12, #0x14
    1c08:      	st1.s	{ v5 }[1], [x14]
    1c0c:      	tbnz	w10, #0x6, 0x1bf0 <_llm_rows.packet_batch.blocks+0x1884>
    1c10:      	tbz	w10, #0x7, 0x1c1c <_llm_rows.packet_batch.blocks+0x18b0>
    1c14:      	add	x10, x12, #0x1c
    1c18:      	st1.s	{ v5 }[3], [x10]
    1c1c:      	mov	x10, #0x0               ; =0
    1c20:      	add	x9, x9, x6
    1c24:      	movi.2d	v5, #0000000000000000
    1c28:      	movi.2d	v21, #0000000000000000
    1c2c:      	movi.2d	v22, #0000000000000000
    1c30:      	movi.2d	v23, #0000000000000000
    1c34:      	b	0x1c5c <_llm_rows.packet_batch.blocks+0x18f0>
    1c38:      	add.2d	v28, v5, v27
    1c3c:      	add.2d	v21, v21, v25
    1c40:      	add.2d	v22, v22, v26
    1c44:      	add.2d	v23, v23, v24
    1c48:      	fmov	x10, d5
    1c4c:      	add	x10, x10, x11
    1c50:      	mov.16b	v5, v28
    1c54:      	cmp	x10, #0x100
    1c58:      	b.ge	0x1d3c <_llm_rows.packet_batch.blocks+0x19d0>
    1c5c:      	fmov	w12, s7
    1c60:      	lsl	x10, x10, #5
    1c64:      	add	x14, x5, x10
    1c68:      	ldp	q30, q28, [x14]
    1c6c:      	add	x14, x21, x10
    1c70:      	ldp	q11, q29, [x14]
    1c74:      	fmul.4s	v12, v30, v11
    1c78:      	add	x14, x27, x10
    1c7c:      	ldp	q13, q30, [x14]
    1c80:      	add	x14, x19, x10
    1c84:      	ldp	q14, q11, [x14]
    1c88:      	fmul.4s	v13, v13, v14
    1c8c:      	fadd.4s	v12, v12, v13
    1c90:      	and.16b	v12, v0, v12
    1c94:      	add	x10, x9, x10
    1c98:      	tbz	w12, #0x0, 0x1ce8 <_llm_rows.packet_batch.blocks+0x197c>
    1c9c:      	str	s12, [x10]
    1ca0:      	and	w12, w12, #0xff
    1ca4:      	tbnz	w12, #0x1, 0x1cf0 <_llm_rows.packet_batch.blocks+0x1984>
    1ca8:      	tbz	w12, #0x2, 0x1cfc <_llm_rows.packet_batch.blocks+0x1990>
    1cac:      	add	x14, x10, #0x8
    1cb0:      	st1.s	{ v12 }[2], [x14]
    1cb4:      	tbnz	w12, #0x3, 0x1d00 <_llm_rows.packet_batch.blocks+0x1994>
    1cb8:      	fmul.4s	v28, v28, v29
    1cbc:      	fmul.4s	v29, v30, v11
    1cc0:      	fadd.4s	v28, v28, v29
    1cc4:      	and.16b	v28, v6, v28
    1cc8:      	tbz	w12, #0x4, 0x1d1c <_llm_rows.packet_batch.blocks+0x19b0>
    1ccc:      	str	s28, [x10, #0x10]
    1cd0:      	tbnz	w12, #0x5, 0x1d20 <_llm_rows.packet_batch.blocks+0x19b4>
    1cd4:      	tbz	w12, #0x6, 0x1d2c <_llm_rows.packet_batch.blocks+0x19c0>
    1cd8:      	add	x14, x10, #0x18
    1cdc:      	st1.s	{ v28 }[2], [x14]
    1ce0:      	tbz	w12, #0x7, 0x1c38 <_llm_rows.packet_batch.blocks+0x18cc>
    1ce4:      	b	0x1d30 <_llm_rows.packet_batch.blocks+0x19c4>
    1ce8:      	and	w12, w12, #0xff
    1cec:      	tbz	w12, #0x1, 0x1ca8 <_llm_rows.packet_batch.blocks+0x193c>
    1cf0:      	add	x14, x10, #0x4
    1cf4:      	st1.s	{ v12 }[1], [x14]
    1cf8:      	tbnz	w12, #0x2, 0x1cac <_llm_rows.packet_batch.blocks+0x1940>
    1cfc:      	tbz	w12, #0x3, 0x1cb8 <_llm_rows.packet_batch.blocks+0x194c>
    1d00:      	add	x14, x10, #0xc
    1d04:      	st1.s	{ v12 }[3], [x14]
    1d08:      	fmul.4s	v28, v28, v29
    1d0c:      	fmul.4s	v29, v30, v11
    1d10:      	fadd.4s	v28, v28, v29
    1d14:      	and.16b	v28, v6, v28
    1d18:      	tbnz	w12, #0x4, 0x1ccc <_llm_rows.packet_batch.blocks+0x1960>
    1d1c:      	tbz	w12, #0x5, 0x1cd4 <_llm_rows.packet_batch.blocks+0x1968>
    1d20:      	add	x14, x10, #0x14
    1d24:      	st1.s	{ v28 }[1], [x14]
    1d28:      	tbnz	w12, #0x6, 0x1cd8 <_llm_rows.packet_batch.blocks+0x196c>
    1d2c:      	tbz	w12, #0x7, 0x1c38 <_llm_rows.packet_batch.blocks+0x18cc>
    1d30:      	add	x10, x10, #0x1c
    1d34:      	st1.s	{ v28 }[3], [x10]
    1d38:      	b	0x1c38 <_llm_rows.packet_batch.blocks+0x18cc>
    1d3c:      	ldr	q0, [sp, #0xb0]
    1d40:      	fmul.4s	v0, v0, v4
    1d44:      	fmul.4s	v2, v10, v2
    1d48:      	fadd.4s	v0, v2, v0
    1d4c:      	zip1.8b	v2, v19, v0
    1d50:      	ushll.4s	v2, v2, #0x0
    1d54:      	shl.4s	v2, v2, #0x1f
    1d58:      	cmlt.4s	v2, v2, #0
    1d5c:      	and.16b	v0, v2, v0
    1d60:      	fmov	w9, s31
    1d64:      	stp	q20, q18, [sp, #0x280]
    1d68:      	stp	q17, q16, [sp, #0x2a0]
    1d6c:      	and	x10, x13, #0x7
    1d70:      	add	x11, sp, #0x280
    1d74:      	ldr	x10, [x11, x10, lsl #3]
    1d78:      	sub	x10, x10, x13
    1d7c:      	add	x8, x8, x10, lsl #2
    1d80:      	tbz	w9, #0x0, 0x1da4 <_llm_rows.packet_batch.blocks+0x1a38>
    1d84:      	str	s0, [x8]
    1d88:      	ldr	q10, [sp, #0x110]
    1d8c:      	tbnz	w9, #0x1, 0x1dac <_llm_rows.packet_batch.blocks+0x1a40>
    1d90:      	tbz	w9, #0x2, 0x1db8 <_llm_rows.packet_batch.blocks+0x1a4c>
    1d94:      	add	x10, x8, #0x8
    1d98:      	st1.s	{ v0 }[2], [x10]
    1d9c:      	tbnz	w9, #0x3, 0x1dbc <_llm_rows.packet_batch.blocks+0x1a50>
    1da0:      	b	0x1dc4 <_llm_rows.packet_batch.blocks+0x1a58>
    1da4:      	ldr	q10, [sp, #0x110]
    1da8:      	tbz	w9, #0x1, 0x1d90 <_llm_rows.packet_batch.blocks+0x1a24>
    1dac:      	add	x10, x8, #0x4
    1db0:      	st1.s	{ v0 }[1], [x10]
    1db4:      	tbnz	w9, #0x2, 0x1d94 <_llm_rows.packet_batch.blocks+0x1a28>
    1db8:      	tbz	w9, #0x3, 0x1dc4 <_llm_rows.packet_batch.blocks+0x1a58>
    1dbc:      	add	x10, x8, #0xc
    1dc0:      	st1.s	{ v0 }[3], [x10]
    1dc4:      	fmul.4s	v0, v8, v3
    1dc8:      	fmul.4s	v1, v9, v1
    1dcc:      	fadd.4s	v0, v1, v0
    1dd0:      	zip2.8b	v1, v19, v0
    1dd4:      	ushll.4s	v1, v1, #0x0
    1dd8:      	shl.4s	v1, v1, #0x1f
    1ddc:      	cmlt.4s	v1, v1, #0
    1de0:      	and.16b	v0, v1, v0
    1de4:      	tbnz	w9, #0x4, 0x1028 <_llm_rows.packet_batch.blocks+0xcbc>
    1de8:      	tbz	w9, #0x5, 0x1030 <_llm_rows.packet_batch.blocks+0xcc4>
    1dec:      	add	x10, x8, #0x14
    1df0:      	st1.s	{ v0 }[1], [x10]
    1df4:      	tbnz	w9, #0x6, 0x1034 <_llm_rows.packet_batch.blocks+0xcc8>
    1df8:      	tbz	w9, #0x7, 0x444 <_llm_rows.packet_batch.blocks+0xd8>
    1dfc:      	add	x8, x8, #0x1c
    1e00:      	st1.s	{ v0 }[3], [x8]
    1e04:      	b	0x444 <_llm_rows.packet_batch.blocks+0xd8>
    1e08:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    1e0c:      	add	sp, sp, #0x4d0
    1e10:      	ldp	x29, x30, [sp, #0x90]
    1e14:      	ldp	x20, x19, [sp, #0x80]
    1e18:      	ldp	x22, x21, [sp, #0x70]
    1e1c:      	ldp	x24, x23, [sp, #0x60]
    1e20:      	ldp	x26, x25, [sp, #0x50]
    1e24:      	ldp	x28, x27, [sp, #0x40]
    1e28:      	ldp	d9, d8, [sp, #0x30]
    1e2c:      	ldp	d11, d10, [sp, #0x20]
    1e30:      	ldp	d13, d12, [sp, #0x10]
    1e34:      	ldp	d15, d14, [sp], #0xa0
    1e38:      	ret

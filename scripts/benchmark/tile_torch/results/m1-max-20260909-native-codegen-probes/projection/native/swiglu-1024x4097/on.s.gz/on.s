
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/swiglu-1024x4097/on/object/tile_xir_w8_38023_1788936543134131_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d11, d10, [sp, #-0x70]!
       4:      	stp	d9, d8, [sp, #0x10]
       8:      	stp	x28, x27, [sp, #0x20]
       c:      	stp	x24, x23, [sp, #0x30]
      10:      	stp	x22, x21, [sp, #0x40]
      14:      	stp	x20, x19, [sp, #0x50]
      18:      	stp	x29, x30, [sp, #0x60]
      1c:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      20:      	sub	sp, sp, #0x50
      24:      	ldr	x23, [x0]
      28:      	ldr	x21, [x0, #0x10]
      2c:      	ldr	x19, [x0, #0x30]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w8, w8, #3
      40:      	subs	x9, x23, x19
      44:      	mov	w10, #0xfff             ; =4095
      48:      	movk	w10, #0x100, lsl #16
      4c:      	ccmp	x9, x10, #0x0, hs
      50:      	cset	w9, hi
      54:      	subs	x11, x19, x23
      58:      	ccmp	x11, x10, #0x0, hs
      5c:      	csinc	w9, w9, wzr, ls
      60:      	subs	x11, x21, x19
      64:      	ccmp	x11, x10, #0x0, hs
      68:      	cset	w11, hi
      6c:      	subs	x12, x19, x21
      70:      	ccmp	x12, x10, #0x0, hs
      74:      	csinc	w10, w11, wzr, ls
      78:      	mov	w11, #0x4004            ; =16388
      7c:      	umull	x22, w8, w11
      80:      	cmp	w9, #0x1
      84:      	ccmp	w10, #0x0, #0x4, eq
      88:      	b.ne	0x460 <ltmp0+0x460>
      8c:      	add	x24, sp, #0x4, lsl #12  ; =0x4000
      90:      	add	x24, x24, #0x30
      94:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
      98:      	add	x0, x0, #0x30
      9c:      	add	x1, x23, x22
      a0:      	mov	w2, #0x4000             ; =16384
      a4:      	bl	0xa4 <ltmp0+0xa4>
      a8:      	add	x20, x22, #0x4, lsl #12 ; =0x4000
      ac:      	ldr	s0, [x23, x20]
      b0:      	str	q0, [sp]
      b4:      	str	q0, [sp, #0x8030]
      b8:      	add	x23, sp, #0x10
      bc:      	add	x0, sp, #0x10
      c0:      	add	x1, x21, x22
      c4:      	mov	w2, #0x4000             ; =16384
      c8:      	bl	0xc8 <ltmp0+0xc8>
      cc:      	mov	x8, #0x0                ; =0
      d0:      	ldr	s0, [x21, x20]
      d4:      	mov	w9, #0x42d00000         ; =1120927744
      d8:      	dup.4s	v2, w9
      dc:      	mov	w9, #-0x3d380000        ; =-1027080192
      e0:      	dup.4s	v3, w9
      e4:      	mov	w9, #0xaa3b             ; =43579
      e8:      	movk	w9, #0x3fb8, lsl #16
      ec:      	dup.4s	v4, w9
      f0:      	mov	w9, #0x7200             ; =29184
      f4:      	movk	w9, #0xbf31, lsl #16
      f8:      	dup.4s	v5, w9
      fc:      	mov	w9, #0xbe8e             ; =48782
     100:      	movk	w9, #0xb5bf, lsl #16
     104:      	dup.4s	v6, w9
     108:      	mov	w9, #0x2bda             ; =11226
     10c:      	movk	w9, #0x3950, lsl #16
     110:      	dup.4s	v7, w9
     114:      	mov	w9, #0x96c9             ; =38601
     118:      	movk	w9, #0x3ab6, lsl #16
     11c:      	dup.4s	v16, w9
     120:      	mov	w9, #0x88a6             ; =34982
     124:      	movk	w9, #0x3c08, lsl #16
     128:      	dup.4s	v17, w9
     12c:      	mov	w9, #0xaa7a             ; =43642
     130:      	movk	w9, #0x3d2a, lsl #16
     134:      	dup.4s	v18, w9
     138:      	mov	w9, #0xaaab             ; =43691
     13c:      	movk	w9, #0x3e2a, lsl #16
     140:      	dup.4s	v19, w9
     144:      	str	q0, [sp, #0x4010]
     148:      	add	x9, x19, x22
     14c:      	movi.4s	v20, #0x4b, lsl #24
     150:      	mvni.4s	v21, #0x80, lsl #24
     154:      	movi.4s	v22, #0x3f, lsl #24
     158:      	fmov.4s	v1, #1.00000000
     15c:      	mvni.4s	v23, #0x7f, msl #16
     160:      	fneg.4s	v23, v23
     164:      	mvni.4s	v24, #0x3f, msl #16
     168:      	fneg.4s	v24, v24
     16c:      	add	x10, x24, x8
     170:      	ldp	q25, q26, [x10]
     174:      	fneg.4s	v27, v26
     178:      	fneg.4s	v28, v25
     17c:      	fcmge.4s	v29, v2, v25
     180:      	fcmge.4s	v30, v2, v26
     184:      	fcmge.4s	v31, v25, v3
     188:      	fcmge.4s	v8, v26, v3
     18c:      	and.16b	v30, v30, v8
     190:      	and.16b	v29, v29, v31
     194:      	and.16b	v28, v29, v28
     198:      	and.16b	v27, v30, v27
     19c:      	fmul.4s	v29, v27, v4
     1a0:      	fmul.4s	v30, v28, v4
     1a4:      	mov.16b	v31, v21
     1a8:      	bsl.16b	v31, v20, v30
     1ac:      	mov.16b	v8, v21
     1b0:      	bsl.16b	v8, v20, v29
     1b4:      	fadd.4s	v29, v29, v8
     1b8:      	fadd.4s	v30, v30, v31
     1bc:      	fsub.4s	v30, v30, v31
     1c0:      	fsub.4s	v29, v29, v8
     1c4:      	fcvtzs.4s	v29, v29
     1c8:      	fcvtzs.4s	v30, v30
     1cc:      	scvtf.4s	v31, v30
     1d0:      	scvtf.4s	v8, v29
     1d4:      	fmul.4s	v9, v8, v5
     1d8:      	fmul.4s	v10, v31, v5
     1dc:      	fadd.4s	v28, v28, v10
     1e0:      	fadd.4s	v27, v27, v9
     1e4:      	fmul.4s	v31, v31, v6
     1e8:      	fmul.4s	v8, v8, v6
     1ec:      	fadd.4s	v27, v27, v8
     1f0:      	fadd.4s	v28, v28, v31
     1f4:      	fmul.4s	v31, v28, v7
     1f8:      	fmul.4s	v8, v27, v7
     1fc:      	fadd.4s	v8, v8, v16
     200:      	fadd.4s	v31, v31, v16
     204:      	fmul.4s	v31, v28, v31
     208:      	fmul.4s	v8, v27, v8
     20c:      	fadd.4s	v8, v8, v17
     210:      	fadd.4s	v31, v31, v17
     214:      	fmul.4s	v31, v28, v31
     218:      	fmul.4s	v8, v27, v8
     21c:      	fadd.4s	v8, v8, v18
     220:      	fadd.4s	v31, v31, v18
     224:      	fmul.4s	v31, v28, v31
     228:      	fmul.4s	v8, v27, v8
     22c:      	fadd.4s	v8, v8, v19
     230:      	fadd.4s	v31, v31, v19
     234:      	fmul.4s	v31, v28, v31
     238:      	fmul.4s	v8, v27, v8
     23c:      	fadd.4s	v8, v8, v22
     240:      	fadd.4s	v31, v31, v22
     244:      	fmul.4s	v9, v27, v27
     248:      	fmul.4s	v10, v28, v28
     24c:      	fmul.4s	v31, v10, v31
     250:      	fmul.4s	v8, v9, v8
     254:      	fadd.4s	v27, v27, v8
     258:      	fadd.4s	v28, v28, v31
     25c:      	sshr.4s	v31, v30, #0x1
     260:      	fadd.4s	v28, v28, v1
     264:      	sshr.4s	v8, v29, #0x1
     268:      	shl.4s	v9, v8, #0x17
     26c:      	shl.4s	v10, v31, #0x17
     270:      	add.4s	v10, v10, v1
     274:      	add.4s	v9, v9, v1
     278:      	fadd.4s	v27, v27, v1
     27c:      	fmul.4s	v27, v27, v9
     280:      	sub.4s	v29, v29, v8
     284:      	sub.4s	v30, v30, v31
     288:      	shl.4s	v30, v30, #0x17
     28c:      	shl.4s	v29, v29, #0x17
     290:      	fmul.4s	v28, v28, v10
     294:      	add.4s	v29, v29, v1
     298:      	add.4s	v30, v30, v1
     29c:      	fmul.4s	v28, v28, v30
     2a0:      	fmul.4s	v27, v27, v29
     2a4:      	fcmgt.4s	v29, v26, v2
     2a8:      	fcmgt.4s	v30, v25, v2
     2ac:      	fcmgt.4s	v31, v3, v25
     2b0:      	fcmgt.4s	v8, v3, v26
     2b4:      	fcmeq.4s	v9, v26, v26
     2b8:      	fadd.4s	v27, v27, v1
     2bc:      	fadd.4s	v28, v28, v1
     2c0:      	fcmeq.4s	v10, v25, v25
     2c4:      	bit.16b	v28, v1, v30
     2c8:      	bit.16b	v27, v1, v29
     2cc:      	bit.16b	v27, v23, v8
     2d0:      	bit.16b	v28, v23, v31
     2d4:      	bif.16b	v28, v24, v10
     2d8:      	bif.16b	v27, v24, v9
     2dc:      	fdiv.4s	v26, v26, v27
     2e0:      	fdiv.4s	v25, v25, v28
     2e4:      	add	x10, x23, x8
     2e8:      	ldp	q28, q27, [x10]
     2ec:      	fmul.4s	v25, v28, v25
     2f0:      	fmul.4s	v26, v27, v26
     2f4:      	add	x10, x9, x8
     2f8:      	stp	q25, q26, [x10]
     2fc:      	add	x8, x8, #0x20
     300:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     304:      	b.ne	0x16c <ltmp0+0x16c>
     308:      	movi.2d	v3, #0000000000000000
     30c:      	movi.2d	v2, #0000000000000000
     310:      	ldr	q4, [sp]
     314:      	mov.s	v2[0], v4[0]
     318:      	fneg.4s	v4, v2
     31c:      	mov.s	v3[0], v4[0]
     320:      	mov	w8, #-0x3d300000        ; =-1026555904
     324:      	dup.4s	v4, w8
     328:      	fcmge.4s	v5, v3, v4
     32c:      	mov	w8, #0x42c80000         ; =1120403456
     330:      	dup.4s	v6, w8
     334:      	fcmge.4s	v7, v6, v3
     338:      	and.16b	v5, v5, v7
     33c:      	and.16b	v5, v5, v3
     340:      	mov	w8, #0xaa3b             ; =43579
     344:      	movk	w8, #0x3fb8, lsl #16
     348:      	dup.4s	v7, w8
     34c:      	fmul.4s	v7, v5, v7
     350:      	movi.4s	v16, #0x4b, lsl #24
     354:      	mvni.4s	v17, #0x80, lsl #24
     358:      	bif.16b	v16, v7, v17
     35c:      	fadd.4s	v7, v7, v16
     360:      	fsub.4s	v7, v7, v16
     364:      	fcvtzs.4s	v7, v7
     368:      	scvtf.4s	v16, v7
     36c:      	mov	w8, #0x7200             ; =29184
     370:      	movk	w8, #0xbf31, lsl #16
     374:      	dup.4s	v17, w8
     378:      	fmul.4s	v17, v16, v17
     37c:      	mov	w8, #0xbe8e             ; =48782
     380:      	movk	w8, #0xb5bf, lsl #16
     384:      	dup.4s	v18, w8
     388:      	fadd.4s	v5, v5, v17
     38c:      	fmul.4s	v16, v16, v18
     390:      	fadd.4s	v5, v5, v16
     394:      	mov	w8, #0x2bda             ; =11226
     398:      	movk	w8, #0x3950, lsl #16
     39c:      	dup.4s	v16, w8
     3a0:      	fmul.4s	v16, v5, v16
     3a4:      	mov	w8, #0x96c9             ; =38601
     3a8:      	movk	w8, #0x3ab6, lsl #16
     3ac:      	dup.4s	v17, w8
     3b0:      	fadd.4s	v16, v16, v17
     3b4:      	fmul.4s	v16, v5, v16
     3b8:      	mov	w8, #0x88a6             ; =34982
     3bc:      	movk	w8, #0x3c08, lsl #16
     3c0:      	dup.4s	v17, w8
     3c4:      	fadd.4s	v16, v16, v17
     3c8:      	fmul.4s	v16, v5, v16
     3cc:      	mov	w8, #0xaa7a             ; =43642
     3d0:      	movk	w8, #0x3d2a, lsl #16
     3d4:      	dup.4s	v17, w8
     3d8:      	fadd.4s	v16, v16, v17
     3dc:      	mov	w8, #0xaaab             ; =43691
     3e0:      	movk	w8, #0x3e2a, lsl #16
     3e4:      	dup.4s	v17, w8
     3e8:      	fmul.4s	v16, v5, v16
     3ec:      	fadd.4s	v16, v16, v17
     3f0:      	fmul.4s	v16, v5, v16
     3f4:      	movi.4s	v17, #0x3f, lsl #24
     3f8:      	fadd.4s	v16, v16, v17
     3fc:      	fmul.4s	v17, v5, v5
     400:      	fmul.4s	v16, v17, v16
     404:      	fadd.4s	v5, v5, v16
     408:      	fadd.4s	v5, v5, v1
     40c:      	sshr.4s	v16, v7, #0x1
     410:      	shl.4s	v17, v16, #0x17
     414:      	add.4s	v17, v17, v1
     418:      	fmul.4s	v5, v5, v17
     41c:      	sub.4s	v7, v7, v16
     420:      	shl.4s	v7, v7, #0x17
     424:      	add.4s	v7, v7, v1
     428:      	fmul.4s	v5, v5, v7
     42c:      	fcmgt.4s	v4, v4, v3
     430:      	fcmgt.4s	v6, v3, v6
     434:      	fcmeq.4s	v3, v3, v3
     438:      	fadd.4s	v5, v5, v1
     43c:      	bif.16b	v1, v5, v4
     440:      	mvni.4s	v4, #0x7f, msl #16
     444:      	fneg.4s	v4, v4
     448:      	bit.16b	v1, v4, v6
     44c:      	mvni.4s	v4, #0x3f, msl #16
     450:      	fneg.4s	v4, v4
     454:      	bif.16b	v1, v4, v3
     458:      	fdiv.4s	v1, v2, v1
     45c:      	b	0x7f0 <ltmp0+0x7f0>
     460:      	mov	x8, #0x0                ; =0
     464:      	add	x9, x19, x22
     468:      	add	x10, x21, x22
     46c:      	mov	w11, #0x42d00000        ; =1120927744
     470:      	dup.4s	v1, w11
     474:      	mov	w11, #-0x3d380000       ; =-1027080192
     478:      	dup.4s	v2, w11
     47c:      	mov	w11, #0xaa3b            ; =43579
     480:      	movk	w11, #0x3fb8, lsl #16
     484:      	dup.4s	v3, w11
     488:      	mov	w11, #0x7200            ; =29184
     48c:      	movk	w11, #0xbf31, lsl #16
     490:      	dup.4s	v4, w11
     494:      	mov	w11, #0xbe8e            ; =48782
     498:      	movk	w11, #0xb5bf, lsl #16
     49c:      	dup.4s	v5, w11
     4a0:      	mov	w11, #0x2bda            ; =11226
     4a4:      	movk	w11, #0x3950, lsl #16
     4a8:      	dup.4s	v6, w11
     4ac:      	mov	w11, #0x96c9            ; =38601
     4b0:      	movk	w11, #0x3ab6, lsl #16
     4b4:      	dup.4s	v7, w11
     4b8:      	mov	w11, #0x88a6            ; =34982
     4bc:      	movk	w11, #0x3c08, lsl #16
     4c0:      	dup.4s	v16, w11
     4c4:      	mov	w11, #0xaa7a            ; =43642
     4c8:      	movk	w11, #0x3d2a, lsl #16
     4cc:      	dup.4s	v17, w11
     4d0:      	mov	w11, #0xaaab            ; =43691
     4d4:      	movk	w11, #0x3e2a, lsl #16
     4d8:      	dup.4s	v18, w11
     4dc:      	add	x11, x23, x22
     4e0:      	movi.4s	v19, #0x4b, lsl #24
     4e4:      	mvni.4s	v20, #0x80, lsl #24
     4e8:      	movi.4s	v21, #0x3f, lsl #24
     4ec:      	fmov.4s	v0, #1.00000000
     4f0:      	mvni.4s	v22, #0x7f, msl #16
     4f4:      	fneg.4s	v22, v22
     4f8:      	mvni.4s	v23, #0x3f, msl #16
     4fc:      	fneg.4s	v23, v23
     500:      	add	x12, x11, x8
     504:      	ldp	q24, q25, [x12]
     508:      	fneg.4s	v26, v25
     50c:      	fneg.4s	v27, v24
     510:      	fcmge.4s	v28, v1, v24
     514:      	fcmge.4s	v29, v1, v25
     518:      	fcmge.4s	v30, v24, v2
     51c:      	fcmge.4s	v31, v25, v2
     520:      	and.16b	v29, v29, v31
     524:      	and.16b	v28, v28, v30
     528:      	and.16b	v27, v28, v27
     52c:      	and.16b	v26, v29, v26
     530:      	fmul.4s	v28, v26, v3
     534:      	fmul.4s	v29, v27, v3
     538:      	mov.16b	v30, v20
     53c:      	bsl.16b	v30, v19, v29
     540:      	mov.16b	v31, v20
     544:      	bsl.16b	v31, v19, v28
     548:      	fadd.4s	v28, v28, v31
     54c:      	fadd.4s	v29, v29, v30
     550:      	fsub.4s	v29, v29, v30
     554:      	fsub.4s	v28, v28, v31
     558:      	fcvtzs.4s	v28, v28
     55c:      	fcvtzs.4s	v29, v29
     560:      	scvtf.4s	v30, v29
     564:      	scvtf.4s	v31, v28
     568:      	fmul.4s	v8, v31, v4
     56c:      	fmul.4s	v9, v30, v4
     570:      	fadd.4s	v27, v27, v9
     574:      	fadd.4s	v26, v26, v8
     578:      	fmul.4s	v30, v30, v5
     57c:      	fmul.4s	v31, v31, v5
     580:      	fadd.4s	v26, v26, v31
     584:      	fadd.4s	v27, v27, v30
     588:      	fmul.4s	v30, v27, v6
     58c:      	fmul.4s	v31, v26, v6
     590:      	fadd.4s	v31, v31, v7
     594:      	fadd.4s	v30, v30, v7
     598:      	fmul.4s	v30, v27, v30
     59c:      	fmul.4s	v31, v26, v31
     5a0:      	fadd.4s	v31, v31, v16
     5a4:      	fadd.4s	v30, v30, v16
     5a8:      	fmul.4s	v30, v27, v30
     5ac:      	fmul.4s	v31, v26, v31
     5b0:      	fadd.4s	v31, v31, v17
     5b4:      	fadd.4s	v30, v30, v17
     5b8:      	fmul.4s	v30, v27, v30
     5bc:      	fmul.4s	v31, v26, v31
     5c0:      	fadd.4s	v31, v31, v18
     5c4:      	fadd.4s	v30, v30, v18
     5c8:      	fmul.4s	v30, v27, v30
     5cc:      	fmul.4s	v31, v26, v31
     5d0:      	fadd.4s	v31, v31, v21
     5d4:      	fadd.4s	v30, v30, v21
     5d8:      	fmul.4s	v8, v26, v26
     5dc:      	fmul.4s	v9, v27, v27
     5e0:      	fmul.4s	v30, v9, v30
     5e4:      	fmul.4s	v31, v8, v31
     5e8:      	fadd.4s	v26, v26, v31
     5ec:      	fadd.4s	v27, v27, v30
     5f0:      	sshr.4s	v30, v29, #0x1
     5f4:      	fadd.4s	v27, v27, v0
     5f8:      	sshr.4s	v31, v28, #0x1
     5fc:      	shl.4s	v8, v31, #0x17
     600:      	shl.4s	v9, v30, #0x17
     604:      	add.4s	v9, v9, v0
     608:      	add.4s	v8, v8, v0
     60c:      	fadd.4s	v26, v26, v0
     610:      	fmul.4s	v26, v26, v8
     614:      	sub.4s	v28, v28, v31
     618:      	sub.4s	v29, v29, v30
     61c:      	shl.4s	v29, v29, #0x17
     620:      	shl.4s	v28, v28, #0x17
     624:      	fmul.4s	v27, v27, v9
     628:      	add.4s	v28, v28, v0
     62c:      	add.4s	v29, v29, v0
     630:      	fmul.4s	v27, v27, v29
     634:      	fmul.4s	v26, v26, v28
     638:      	fcmgt.4s	v28, v25, v1
     63c:      	fcmgt.4s	v29, v24, v1
     640:      	fcmgt.4s	v30, v2, v24
     644:      	fcmgt.4s	v31, v2, v25
     648:      	fcmeq.4s	v8, v25, v25
     64c:      	fadd.4s	v26, v26, v0
     650:      	fadd.4s	v27, v27, v0
     654:      	fcmeq.4s	v9, v24, v24
     658:      	bit.16b	v27, v0, v29
     65c:      	bit.16b	v26, v0, v28
     660:      	bit.16b	v26, v22, v31
     664:      	bit.16b	v27, v22, v30
     668:      	bif.16b	v27, v23, v9
     66c:      	bif.16b	v26, v23, v8
     670:      	fdiv.4s	v25, v25, v26
     674:      	fdiv.4s	v24, v24, v27
     678:      	add	x12, x10, x8
     67c:      	ldp	q27, q26, [x12]
     680:      	fmul.4s	v24, v27, v24
     684:      	fmul.4s	v25, v26, v25
     688:      	add	x12, x9, x8
     68c:      	stp	q24, q25, [x12]
     690:      	add	x8, x8, #0x20
     694:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     698:      	b.ne	0x500 <ltmp0+0x500>
     69c:      	add	x20, x22, #0x4, lsl #12 ; =0x4000
     6a0:      	ldr	s1, [x23, x20]
     6a4:      	movi.2d	v2, #0000000000000000
     6a8:      	fneg.4s	v3, v1
     6ac:      	mov.s	v2[0], v3[0]
     6b0:      	mov	w8, #-0x3d300000        ; =-1026555904
     6b4:      	dup.4s	v3, w8
     6b8:      	mov	w8, #0x42c80000         ; =1120403456
     6bc:      	dup.4s	v4, w8
     6c0:      	fcmge.4s	v5, v2, v3
     6c4:      	fcmge.4s	v6, v4, v2
     6c8:      	and.16b	v5, v5, v6
     6cc:      	mov	w8, #0xaa3b             ; =43579
     6d0:      	movk	w8, #0x3fb8, lsl #16
     6d4:      	dup.4s	v6, w8
     6d8:      	and.16b	v5, v5, v2
     6dc:      	fmul.4s	v6, v5, v6
     6e0:      	movi.4s	v7, #0x4b, lsl #24
     6e4:      	mvni.4s	v16, #0x80, lsl #24
     6e8:      	bif.16b	v7, v6, v16
     6ec:      	fadd.4s	v6, v6, v7
     6f0:      	fsub.4s	v6, v6, v7
     6f4:      	fcvtzs.4s	v6, v6
     6f8:      	scvtf.4s	v7, v6
     6fc:      	mov	w8, #0x7200             ; =29184
     700:      	movk	w8, #0xbf31, lsl #16
     704:      	dup.4s	v16, w8
     708:      	fmul.4s	v16, v7, v16
     70c:      	fadd.4s	v5, v5, v16
     710:      	mov	w8, #0xbe8e             ; =48782
     714:      	movk	w8, #0xb5bf, lsl #16
     718:      	dup.4s	v16, w8
     71c:      	fmul.4s	v7, v7, v16
     720:      	fadd.4s	v5, v5, v7
     724:      	mov	w8, #0x2bda             ; =11226
     728:      	movk	w8, #0x3950, lsl #16
     72c:      	dup.4s	v7, w8
     730:      	fmul.4s	v7, v5, v7
     734:      	mov	w8, #0x96c9             ; =38601
     738:      	movk	w8, #0x3ab6, lsl #16
     73c:      	dup.4s	v16, w8
     740:      	fadd.4s	v7, v7, v16
     744:      	mov	w8, #0x88a6             ; =34982
     748:      	movk	w8, #0x3c08, lsl #16
     74c:      	dup.4s	v16, w8
     750:      	fmul.4s	v7, v5, v7
     754:      	fadd.4s	v7, v7, v16
     758:      	fmul.4s	v7, v5, v7
     75c:      	mov	w8, #0xaa7a             ; =43642
     760:      	movk	w8, #0x3d2a, lsl #16
     764:      	dup.4s	v16, w8
     768:      	fadd.4s	v7, v7, v16
     76c:      	fmul.4s	v7, v5, v7
     770:      	mov	w8, #0xaaab             ; =43691
     774:      	movk	w8, #0x3e2a, lsl #16
     778:      	dup.4s	v16, w8
     77c:      	fadd.4s	v7, v7, v16
     780:      	fmul.4s	v7, v5, v7
     784:      	movi.4s	v16, #0x3f, lsl #24
     788:      	fadd.4s	v7, v7, v16
     78c:      	fmul.4s	v16, v5, v5
     790:      	fmul.4s	v7, v16, v7
     794:      	fadd.4s	v5, v5, v7
     798:      	fadd.4s	v5, v5, v0
     79c:      	sshr.4s	v7, v6, #0x1
     7a0:      	shl.4s	v16, v7, #0x17
     7a4:      	add.4s	v16, v16, v0
     7a8:      	fmul.4s	v5, v5, v16
     7ac:      	sub.4s	v6, v6, v7
     7b0:      	shl.4s	v6, v6, #0x17
     7b4:      	add.4s	v6, v6, v0
     7b8:      	fmul.4s	v5, v5, v6
     7bc:      	fcmgt.4s	v3, v3, v2
     7c0:      	fcmgt.4s	v4, v2, v4
     7c4:      	fcmeq.4s	v2, v2, v2
     7c8:      	fadd.4s	v5, v5, v0
     7cc:      	bif.16b	v0, v5, v3
     7d0:      	mvni.4s	v3, #0x7f, msl #16
     7d4:      	fneg.4s	v3, v3
     7d8:      	bit.16b	v0, v3, v4
     7dc:      	mvni.4s	v3, #0x3f, msl #16
     7e0:      	fneg.4s	v3, v3
     7e4:      	bif.16b	v0, v3, v2
     7e8:      	fdiv.4s	v0, v1, v0
     7ec:      	ldr	s1, [x21, x20]
     7f0:      	fmul.4s	v0, v1, v0
     7f4:      	str	s0, [x19, x20]
     7f8:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
     7fc:      	add	sp, sp, #0x50
     800:      	ldp	x29, x30, [sp, #0x60]
     804:      	ldp	x20, x19, [sp, #0x50]
     808:      	ldp	x22, x21, [sp, #0x40]
     80c:      	ldp	x24, x23, [sp, #0x30]
     810:      	ldp	x28, x27, [sp, #0x20]
     814:      	ldp	d9, d8, [sp, #0x10]
     818:      	ldp	d11, d10, [sp], #0x70
     81c:      	ret

0000000000000820 <_llm_rows.packet_batch.blocks>:
     820:      	stp	d15, d14, [sp, #-0xa0]!
     824:      	stp	d13, d12, [sp, #0x10]
     828:      	stp	d11, d10, [sp, #0x20]
     82c:      	stp	d9, d8, [sp, #0x30]
     830:      	stp	x28, x27, [sp, #0x40]
     834:      	stp	x26, x25, [sp, #0x50]
     838:      	stp	x24, x23, [sp, #0x60]
     83c:      	stp	x22, x21, [sp, #0x70]
     840:      	stp	x20, x19, [sp, #0x80]
     844:      	stp	x29, x30, [sp, #0x90]
     848:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
     84c:      	sub	sp, sp, #0x2d0
     850:      	str	x0, [sp, #0xe8]
     854:      	cbz	w3, 0x1c84 <_llm_rows.packet_batch.blocks+0x1464>
     858:      	mov	x19, x3
     85c:      	mov	x20, x2
     860:      	mov	w22, #0x0               ; =0
     864:      	ldp	w9, w8, [x2, #0x2c]
     868:      	stp	w8, w9, [sp, #0xe0]
     86c:      	ldp	w27, w25, [x2]
     870:      	adrp	x8, 0x0 <ltmp0>
     874:      	ldr	q0, [x8]
     878:      	str	q0, [sp, #0xb0]
     87c:      	adrp	x8, 0x0 <ltmp0>
     880:      	ldr	q0, [x8]
     884:      	str	q0, [sp, #0xa0]
     888:      	adrp	x8, 0x0 <ltmp0>
     88c:      	ldr	q0, [x8]
     890:      	str	q0, [sp, #0x90]
     894:      	adrp	x8, 0x0 <ltmp0>
     898:      	ldr	q0, [x8]
     89c:      	str	q0, [sp, #0x80]
     8a0:      	adrp	x8, 0x0 <ltmp0>
     8a4:      	ldr	q0, [x8]
     8a8:      	str	q0, [sp, #0x70]
     8ac:      	adrp	x8, 0x0 <ltmp0>
     8b0:      	ldr	q0, [x8]
     8b4:      	str	q0, [sp, #0x60]
     8b8:      	adrp	x8, 0x0 <ltmp0>
     8bc:      	ldr	q1, [x8]
     8c0:      	mvni.4s	v0, #0x7f, msl #16
     8c4:      	fneg.4s	v0, v0
     8c8:      	str	q0, [sp, #0x110]
     8cc:      	mvni.4s	v0, #0x3f, msl #16
     8d0:      	fneg.4s	v0, v0
     8d4:      	stp	q1, q0, [sp, #0xf0]
     8d8:      	add	x26, sp, #0x4, lsl #12  ; =0x4000
     8dc:      	add	x26, x26, #0x2b0
     8e0:      	ldp	w28, w23, [x2, #0x8]
     8e4:      	add	x24, sp, #0x290
     8e8:      	str	w3, [sp, #0xdc]
     8ec:      	b	0x934 <_llm_rows.packet_batch.blocks+0x114>
     8f0:      	mov	w8, #0x18               ; =24
     8f4:      	str	w8, [x20, #0x24]
     8f8:      	ldr	w19, [sp, #0xdc]
     8fc:      	add	w8, w27, #0x1
     900:      	ldp	w10, w9, [sp, #0xe0]
     904:      	cmp	w8, w9
     908:      	cset	w8, eq
     90c:      	csinc	w27, wzr, w27, eq
     910:      	cinc	w9, w25, eq
     914:      	cmp	w9, w10
     918:      	cset	w10, eq
     91c:      	ands	w8, w8, w10
     920:      	csel	w25, wzr, w9, ne
     924:      	add	w28, w28, w8
     928:      	add	w22, w22, #0x1
     92c:      	cmp	w22, w19
     930:      	b.eq	0x1c84 <_llm_rows.packet_batch.blocks+0x1464>
     934:      	ubfiz	x8, x27, #5, #32
     938:      	cmp	x8, x23
     93c:      	csel	x9, x8, xzr, ls
     940:      	subs	x10, x23, x9
     944:      	cmp	x10, #0x20
     948:      	mov	w11, #0x20              ; =32
     94c:      	csel	x10, x10, x11, lo
     950:      	cmp	x23, x9
     954:      	stp	w27, w25, [x20]
     958:      	str	w28, [x20, #0x8]
     95c:      	str	wzr, [x20, #0x24]
     960:      	ccmp	x8, x23, #0x2, hi
     964:      	csel	x21, x10, xzr, ls
     968:      	cmp	x21, #0x20
     96c:      	b.lo	0x9c0 <_llm_rows.packet_batch.blocks+0x1a0>
     970:      	ldr	x21, [sp, #0xe8]
     974:      	mov	x0, x21
     978:      	mov	x1, x20
     97c:      	bl	0x97c <_llm_rows.packet_batch.blocks+0x15c>
     980:      	mov	w8, #0x8                ; =8
     984:      	str	w8, [x20, #0x24]
     988:      	mov	x0, x21
     98c:      	mov	x1, x20
     990:      	bl	0x990 <_llm_rows.packet_batch.blocks+0x170>
     994:      	mov	w8, #0x10               ; =16
     998:      	str	w8, [x20, #0x24]
     99c:      	mov	x0, x21
     9a0:      	mov	x1, x20
     9a4:      	bl	0x9a4 <_llm_rows.packet_batch.blocks+0x184>
     9a8:      	mov	w8, #0x18               ; =24
     9ac:      	str	w8, [x20, #0x24]
     9b0:      	mov	x0, x21
     9b4:      	mov	x1, x20
     9b8:      	bl	0x9b8 <_llm_rows.packet_batch.blocks+0x198>
     9bc:      	b	0x8fc <_llm_rows.packet_batch.blocks+0xdc>
     9c0:      	lsr	x19, x21, #3
     9c4:      	cmp	x21, #0x8
     9c8:      	b.lo	0xa14 <_llm_rows.packet_batch.blocks+0x1f4>
     9cc:      	str	wzr, [x20, #0x24]
     9d0:      	ldr	x0, [sp, #0xe8]
     9d4:      	mov	x1, x20
     9d8:      	bl	0x9d8 <_llm_rows.packet_batch.blocks+0x1b8>
     9dc:      	cmp	x19, #0x1
     9e0:      	b.eq	0xa14 <_llm_rows.packet_batch.blocks+0x1f4>
     9e4:      	mov	w8, #0x8                ; =8
     9e8:      	str	w8, [x20, #0x24]
     9ec:      	ldr	x0, [sp, #0xe8]
     9f0:      	mov	x1, x20
     9f4:      	bl	0x9f4 <_llm_rows.packet_batch.blocks+0x1d4>
     9f8:      	cmp	x19, #0x2
     9fc:      	b.eq	0xa14 <_llm_rows.packet_batch.blocks+0x1f4>
     a00:      	mov	w8, #0x10               ; =16
     a04:      	str	w8, [x20, #0x24]
     a08:      	ldr	x0, [sp, #0xe8]
     a0c:      	mov	x1, x20
     a10:      	bl	0xa10 <_llm_rows.packet_batch.blocks+0x1f0>
     a14:      	and	w8, w21, #0x7
     a18:      	cbz	w8, 0x8f0 <_llm_rows.packet_batch.blocks+0xd0>
     a1c:      	dup.4s	v0, w8
     a20:      	ldp	q2, q1, [sp, #0xa0]
     a24:      	cmhi.4s	v19, v0, v2
     a28:      	cmhi.4s	v20, v0, v1
     a2c:      	uzp1.8h	v8, v20, v19
     a30:      	umaxv.8h	h0, v8
     a34:      	fmov	w8, s0
     a38:      	tbz	w8, #0x0, 0x8f0 <_llm_rows.packet_batch.blocks+0xd0>
     a3c:      	ldr	x8, [sp, #0xe8]
     a40:      	ldr	x11, [x8]
     a44:      	ldr	x9, [x8, #0x10]
     a48:      	ldr	x8, [x8, #0x30]
     a4c:      	xtn.4h	v30, v20
     a50:      	uzp1.8b	v0, v30, v0
     a54:      	sshll.2d	v1, v20, #0x0
     a58:      	sshll.2d	v2, v19, #0x0
     a5c:      	sshll2.2d	v10, v20, #0x0
     a60:      	sshll2.2d	v9, v19, #0x0
     a64:      	ldp	q3, q4, [sp, #0x80]
     a68:      	and.16b	v21, v9, v4
     a6c:      	and.16b	v23, v10, v3
     a70:      	ldr	q3, [sp, #0x70]
     a74:      	and.16b	v22, v2, v3
     a78:      	ldr	q2, [sp, #0x60]
     a7c:      	and.16b	v29, v1, v2
     a80:      	ubfiz	w10, w27, #2, #27
     a84:      	orr	w12, w10, w19
     a88:      	dup.4s	v1, w12
     a8c:      	and.16b	v2, v20, v1
     a90:      	and.16b	v1, v19, v1
     a94:      	ushll2.2d	v24, v1, #0x0
     a98:      	ushll2.2d	v27, v2, #0x0
     a9c:      	ushll.2d	v25, v1, #0x0
     aa0:      	ushll.2d	v26, v2, #0x0
     aa4:      	subs	x10, x11, x8
     aa8:      	mov	w15, #0xfff             ; =4095
     aac:      	movk	w15, #0x100, lsl #16
     ab0:      	ccmp	x10, x15, #0x0, hs
     ab4:      	cset	w10, hi
     ab8:      	subs	x13, x8, x11
     abc:      	ccmp	x13, x15, #0x0, hs
     ac0:      	csinc	w14, w10, wzr, ls
     ac4:      	subs	x10, x9, x8
     ac8:      	ccmp	x10, x15, #0x0, hs
     acc:      	cset	w10, hi
     ad0:      	subs	x13, x8, x9
     ad4:      	ccmp	x13, x15, #0x0, hs
     ad8:      	csinc	w10, w10, wzr, ls
     adc:      	umov.b	w13, v0[0]
     ae0:      	mov	w15, #0x4004            ; =16388
     ae4:      	umull	x12, w12, w15
     ae8:      	tst	w13, #0x1
     aec:      	csel	x12, x12, xzr, ne
     af0:      	mov	w15, #-0x3d300000       ; =-1026555904
     af4:      	dup.4s	v1, w15
     af8:      	mov	w15, #0x42c80000        ; =1120403456
     afc:      	dup.4s	v0, w15
     b00:      	mov	w15, #0xaa3b            ; =43579
     b04:      	movk	w15, #0x3fb8, lsl #16
     b08:      	dup.4s	v18, w15
     b0c:      	mov	w15, #0x7200            ; =29184
     b10:      	movk	w15, #0xbf31, lsl #16
     b14:      	dup.4s	v17, w15
     b18:      	mov	w15, #0xbe8e            ; =48782
     b1c:      	movk	w15, #0xb5bf, lsl #16
     b20:      	dup.4s	v16, w15
     b24:      	mov	w15, #0x2bda            ; =11226
     b28:      	movk	w15, #0x3950, lsl #16
     b2c:      	dup.4s	v7, w15
     b30:      	mov	w15, #0x96c9            ; =38601
     b34:      	movk	w15, #0x3ab6, lsl #16
     b38:      	dup.4s	v6, w15
     b3c:      	mov	w15, #0x88a6            ; =34982
     b40:      	movk	w15, #0x3c08, lsl #16
     b44:      	dup.4s	v5, w15
     b48:      	mov	w15, #0xaa7a            ; =43642
     b4c:      	movk	w15, #0x3d2a, lsl #16
     b50:      	dup.4s	v4, w15
     b54:      	mov	w15, #0xaaab            ; =43691
     b58:      	movk	w15, #0x3e2a, lsl #16
     b5c:      	dup.4s	v3, w15
     b60:      	fmov.4s	v2, #1.00000000
     b64:      	xtn.2s	v31, v26
     b68:      	xtn.2s	v24, v24
     b6c:      	str	d24, [sp, #0xc0]
     b70:      	xtn.2s	v26, v25
     b74:      	mov	w15, #0x1001            ; =4097
     b78:      	dup.2s	v25, w15
     b7c:      	xtn.2s	v27, v27
     b80:      	cmp	w14, #0x1
     b84:      	b.ne	0xf1c <_llm_rows.packet_batch.blocks+0x6fc>
     b88:      	cbz	w10, 0xf1c <_llm_rows.packet_batch.blocks+0x6fc>
     b8c:      	mov	x10, #0x0               ; =0
     b90:      	add	x13, x8, x12
     b94:      	add	x14, x9, x12
     b98:      	add	x12, x11, x12
     b9c:      	ldr	q24, [sp, #0xf0]
     ba0:      	and.16b	v28, v8, v24
     ba4:      	addv.8h	h28, v28
     ba8:      	fmov	w15, s28
     bac:      	b	0xbbc <_llm_rows.packet_batch.blocks+0x39c>
     bb0:      	add	x10, x10, #0x20
     bb4:      	cmp	x10, #0x4, lsl #12      ; =0x4000
     bb8:      	b.eq	0x1888 <_llm_rows.packet_batch.blocks+0x1068>
     bbc:      	add	x16, x12, x10
     bc0:      	movi.2d	v9, #0000000000000000
     bc4:      	movi.2d	v8, #0000000000000000
     bc8:      	tbz	w15, #0x0, 0xc5c <_llm_rows.packet_batch.blocks+0x43c>
     bcc:      	ldr	s9, [x16]
     bd0:      	and	w17, w15, #0xff
     bd4:      	tbnz	w17, #0x1, 0xc64 <_llm_rows.packet_batch.blocks+0x444>
     bd8:      	tbz	w17, #0x2, 0xc70 <_llm_rows.packet_batch.blocks+0x450>
     bdc:      	add	x0, x16, #0x8
     be0:      	ld1.s	{ v9 }[2], [x0]
     be4:      	tbnz	w17, #0x3, 0xc74 <_llm_rows.packet_batch.blocks+0x454>
     be8:      	tbz	w17, #0x4, 0xc80 <_llm_rows.packet_batch.blocks+0x460>
     bec:      	add	x0, x16, #0x10
     bf0:      	ld1.s	{ v8 }[0], [x0]
     bf4:      	tbnz	w17, #0x5, 0xc84 <_llm_rows.packet_batch.blocks+0x464>
     bf8:      	tbz	w17, #0x6, 0xc90 <_llm_rows.packet_batch.blocks+0x470>
     bfc:      	add	x0, x16, #0x18
     c00:      	ld1.s	{ v8 }[2], [x0]
     c04:      	tbnz	w17, #0x7, 0xc94 <_llm_rows.packet_batch.blocks+0x474>
     c08:      	fmov	w17, s28
     c0c:      	add	x16, x14, x10
     c10:      	movi.2d	v11, #0000000000000000
     c14:      	movi.2d	v10, #0000000000000000
     c18:      	tbz	w17, #0x0, 0xcb0 <_llm_rows.packet_batch.blocks+0x490>
     c1c:      	ldr	s11, [x16]
     c20:      	and	w17, w17, #0xff
     c24:      	tbnz	w17, #0x1, 0xcb8 <_llm_rows.packet_batch.blocks+0x498>
     c28:      	tbz	w17, #0x2, 0xcc4 <_llm_rows.packet_batch.blocks+0x4a4>
     c2c:      	add	x0, x16, #0x8
     c30:      	ld1.s	{ v11 }[2], [x0]
     c34:      	tbnz	w17, #0x3, 0xcc8 <_llm_rows.packet_batch.blocks+0x4a8>
     c38:      	tbz	w17, #0x4, 0xcd4 <_llm_rows.packet_batch.blocks+0x4b4>
     c3c:      	add	x0, x16, #0x10
     c40:      	ld1.s	{ v10 }[0], [x0]
     c44:      	tbnz	w17, #0x5, 0xcd8 <_llm_rows.packet_batch.blocks+0x4b8>
     c48:      	tbz	w17, #0x6, 0xce4 <_llm_rows.packet_batch.blocks+0x4c4>
     c4c:      	add	x0, x16, #0x18
     c50:      	ld1.s	{ v10 }[2], [x0]
     c54:      	tbnz	w17, #0x7, 0xce8 <_llm_rows.packet_batch.blocks+0x4c8>
     c58:      	b	0xcf0 <_llm_rows.packet_batch.blocks+0x4d0>
     c5c:      	and	w17, w15, #0xff
     c60:      	tbz	w17, #0x1, 0xbd8 <_llm_rows.packet_batch.blocks+0x3b8>
     c64:      	add	x0, x16, #0x4
     c68:      	ld1.s	{ v9 }[1], [x0]
     c6c:      	tbnz	w17, #0x2, 0xbdc <_llm_rows.packet_batch.blocks+0x3bc>
     c70:      	tbz	w17, #0x3, 0xbe8 <_llm_rows.packet_batch.blocks+0x3c8>
     c74:      	add	x0, x16, #0xc
     c78:      	ld1.s	{ v9 }[3], [x0]
     c7c:      	tbnz	w17, #0x4, 0xbec <_llm_rows.packet_batch.blocks+0x3cc>
     c80:      	tbz	w17, #0x5, 0xbf8 <_llm_rows.packet_batch.blocks+0x3d8>
     c84:      	add	x0, x16, #0x14
     c88:      	ld1.s	{ v8 }[1], [x0]
     c8c:      	tbnz	w17, #0x6, 0xbfc <_llm_rows.packet_batch.blocks+0x3dc>
     c90:      	tbz	w17, #0x7, 0xc08 <_llm_rows.packet_batch.blocks+0x3e8>
     c94:      	add	x16, x16, #0x1c
     c98:      	ld1.s	{ v8 }[3], [x16]
     c9c:      	fmov	w17, s28
     ca0:      	add	x16, x14, x10
     ca4:      	movi.2d	v11, #0000000000000000
     ca8:      	movi.2d	v10, #0000000000000000
     cac:      	tbnz	w17, #0x0, 0xc1c <_llm_rows.packet_batch.blocks+0x3fc>
     cb0:      	and	w17, w17, #0xff
     cb4:      	tbz	w17, #0x1, 0xc28 <_llm_rows.packet_batch.blocks+0x408>
     cb8:      	add	x0, x16, #0x4
     cbc:      	ld1.s	{ v11 }[1], [x0]
     cc0:      	tbnz	w17, #0x2, 0xc2c <_llm_rows.packet_batch.blocks+0x40c>
     cc4:      	tbz	w17, #0x3, 0xc38 <_llm_rows.packet_batch.blocks+0x418>
     cc8:      	add	x0, x16, #0xc
     ccc:      	ld1.s	{ v11 }[3], [x0]
     cd0:      	tbnz	w17, #0x4, 0xc3c <_llm_rows.packet_batch.blocks+0x41c>
     cd4:      	tbz	w17, #0x5, 0xc48 <_llm_rows.packet_batch.blocks+0x428>
     cd8:      	add	x0, x16, #0x14
     cdc:      	ld1.s	{ v10 }[1], [x0]
     ce0:      	tbnz	w17, #0x6, 0xc4c <_llm_rows.packet_batch.blocks+0x42c>
     ce4:      	tbz	w17, #0x7, 0xcf0 <_llm_rows.packet_batch.blocks+0x4d0>
     ce8:      	add	x16, x16, #0x1c
     cec:      	ld1.s	{ v10 }[3], [x16]
     cf0:      	fneg.4s	v12, v9
     cf4:      	and.16b	v12, v20, v12
     cf8:      	fcmge.4s	v13, v12, v1
     cfc:      	fcmge.4s	v14, v0, v12
     d00:      	and.16b	v13, v13, v14
     d04:      	and.16b	v13, v13, v12
     d08:      	fmul.4s	v14, v13, v18
     d0c:      	movi.4s	v24, #0x4b, lsl #24
     d10:      	mvni.4s	v15, #0x80, lsl #24
     d14:      	bsl.16b	v15, v24, v14
     d18:      	fadd.4s	v14, v14, v15
     d1c:      	fsub.4s	v14, v14, v15
     d20:      	fcvtzs.4s	v14, v14
     d24:      	scvtf.4s	v15, v14
     d28:      	fmul.4s	v24, v15, v17
     d2c:      	fadd.4s	v24, v13, v24
     d30:      	fmul.4s	v13, v15, v16
     d34:      	fadd.4s	v24, v24, v13
     d38:      	fmul.4s	v13, v24, v7
     d3c:      	fadd.4s	v13, v13, v6
     d40:      	fmul.4s	v13, v24, v13
     d44:      	fadd.4s	v13, v13, v5
     d48:      	fmul.4s	v13, v24, v13
     d4c:      	fadd.4s	v13, v13, v4
     d50:      	fmul.4s	v13, v24, v13
     d54:      	fadd.4s	v13, v13, v3
     d58:      	fmul.4s	v13, v24, v13
     d5c:      	movi.4s	v15, #0x3f, lsl #24
     d60:      	fadd.4s	v13, v13, v15
     d64:      	fmul.4s	v15, v24, v24
     d68:      	fmul.4s	v13, v15, v13
     d6c:      	fadd.4s	v24, v24, v13
     d70:      	fadd.4s	v24, v24, v2
     d74:      	sshr.4s	v13, v14, #0x1
     d78:      	shl.4s	v15, v13, #0x17
     d7c:      	add.4s	v15, v15, v2
     d80:      	fmul.4s	v24, v24, v15
     d84:      	sub.4s	v13, v14, v13
     d88:      	shl.4s	v13, v13, #0x17
     d8c:      	add.4s	v13, v13, v2
     d90:      	fmul.4s	v24, v24, v13
     d94:      	fcmgt.4s	v13, v1, v12
     d98:      	fcmgt.4s	v14, v12, v0
     d9c:      	fcmeq.4s	v12, v12, v12
     da0:      	fadd.4s	v24, v24, v2
     da4:      	bit.16b	v24, v2, v13
     da8:      	ldr	q13, [sp, #0x110]
     dac:      	bit.16b	v24, v13, v14
     db0:      	ldr	q13, [sp, #0x100]
     db4:      	bif.16b	v24, v13, v12
     db8:      	fdiv.4s	v24, v9, v24
     dbc:      	fmov	w17, s28
     dc0:      	fmul.4s	v9, v11, v24
     dc4:      	add	x16, x13, x10
     dc8:      	tbz	w17, #0x0, 0xdec <_llm_rows.packet_batch.blocks+0x5cc>
     dcc:      	str	s9, [x16]
     dd0:      	and	w17, w17, #0xff
     dd4:      	tbnz	w17, #0x1, 0xdf4 <_llm_rows.packet_batch.blocks+0x5d4>
     dd8:      	tbz	w17, #0x2, 0xe00 <_llm_rows.packet_batch.blocks+0x5e0>
     ddc:      	add	x0, x16, #0x8
     de0:      	st1.s	{ v9 }[2], [x0]
     de4:      	tbnz	w17, #0x3, 0xe04 <_llm_rows.packet_batch.blocks+0x5e4>
     de8:      	b	0xe0c <_llm_rows.packet_batch.blocks+0x5ec>
     dec:      	and	w17, w17, #0xff
     df0:      	tbz	w17, #0x1, 0xdd8 <_llm_rows.packet_batch.blocks+0x5b8>
     df4:      	add	x0, x16, #0x4
     df8:      	st1.s	{ v9 }[1], [x0]
     dfc:      	tbnz	w17, #0x2, 0xddc <_llm_rows.packet_batch.blocks+0x5bc>
     e00:      	tbz	w17, #0x3, 0xe0c <_llm_rows.packet_batch.blocks+0x5ec>
     e04:      	add	x0, x16, #0xc
     e08:      	st1.s	{ v9 }[3], [x0]
     e0c:      	fneg.4s	v24, v8
     e10:      	and.16b	v24, v19, v24
     e14:      	fcmge.4s	v9, v24, v1
     e18:      	fcmge.4s	v11, v0, v24
     e1c:      	and.16b	v9, v9, v11
     e20:      	and.16b	v9, v9, v24
     e24:      	fmul.4s	v11, v9, v18
     e28:      	movi.4s	v12, #0x4b, lsl #24
     e2c:      	mvni.4s	v13, #0x80, lsl #24
     e30:      	bif.16b	v12, v11, v13
     e34:      	fadd.4s	v11, v11, v12
     e38:      	fsub.4s	v11, v11, v12
     e3c:      	fcvtzs.4s	v11, v11
     e40:      	scvtf.4s	v12, v11
     e44:      	fmul.4s	v13, v12, v17
     e48:      	fadd.4s	v9, v9, v13
     e4c:      	fmul.4s	v12, v12, v16
     e50:      	fadd.4s	v9, v9, v12
     e54:      	fmul.4s	v12, v9, v7
     e58:      	fadd.4s	v12, v12, v6
     e5c:      	fmul.4s	v12, v9, v12
     e60:      	fadd.4s	v12, v12, v5
     e64:      	fmul.4s	v12, v9, v12
     e68:      	fadd.4s	v12, v12, v4
     e6c:      	fmul.4s	v12, v9, v12
     e70:      	fadd.4s	v12, v12, v3
     e74:      	fmul.4s	v12, v9, v12
     e78:      	movi.4s	v13, #0x3f, lsl #24
     e7c:      	fadd.4s	v12, v12, v13
     e80:      	fmul.4s	v13, v9, v9
     e84:      	fmul.4s	v12, v13, v12
     e88:      	fadd.4s	v9, v9, v12
     e8c:      	fadd.4s	v9, v9, v2
     e90:      	sshr.4s	v12, v11, #0x1
     e94:      	shl.4s	v13, v12, #0x17
     e98:      	add.4s	v13, v13, v2
     e9c:      	fmul.4s	v9, v9, v13
     ea0:      	sub.4s	v11, v11, v12
     ea4:      	shl.4s	v11, v11, #0x17
     ea8:      	add.4s	v11, v11, v2
     eac:      	fmul.4s	v9, v9, v11
     eb0:      	fcmgt.4s	v11, v1, v24
     eb4:      	fcmgt.4s	v12, v24, v0
     eb8:      	fcmeq.4s	v24, v24, v24
     ebc:      	fadd.4s	v9, v9, v2
     ec0:      	bit.16b	v9, v2, v11
     ec4:      	ldr	q11, [sp, #0x110]
     ec8:      	bit.16b	v9, v11, v12
     ecc:      	ldr	q11, [sp, #0x100]
     ed0:      	bsl.16b	v24, v9, v11
     ed4:      	fdiv.4s	v24, v8, v24
     ed8:      	fmul.4s	v8, v10, v24
     edc:      	tbz	w17, #0x4, 0xefc <_llm_rows.packet_batch.blocks+0x6dc>
     ee0:      	str	s8, [x16, #0x10]
     ee4:      	tbnz	w17, #0x5, 0xf00 <_llm_rows.packet_batch.blocks+0x6e0>
     ee8:      	tbz	w17, #0x6, 0xf0c <_llm_rows.packet_batch.blocks+0x6ec>
     eec:      	add	x0, x16, #0x18
     ef0:      	st1.s	{ v8 }[2], [x0]
     ef4:      	tbz	w17, #0x7, 0xbb0 <_llm_rows.packet_batch.blocks+0x390>
     ef8:      	b	0xf10 <_llm_rows.packet_batch.blocks+0x6f0>
     efc:      	tbz	w17, #0x5, 0xee8 <_llm_rows.packet_batch.blocks+0x6c8>
     f00:      	add	x0, x16, #0x14
     f04:      	st1.s	{ v8 }[1], [x0]
     f08:      	tbnz	w17, #0x6, 0xeec <_llm_rows.packet_batch.blocks+0x6cc>
     f0c:      	tbz	w17, #0x7, 0xbb0 <_llm_rows.packet_batch.blocks+0x390>
     f10:      	add	x16, x16, #0x1c
     f14:      	st1.s	{ v8 }[3], [x16]
     f18:      	b	0xbb0 <_llm_rows.packet_batch.blocks+0x390>
     f1c:      	mov	x10, #0x0               ; =0
     f20:      	add	x14, x11, x12
     f24:      	b	0xf48 <_llm_rows.packet_batch.blocks+0x728>
     f28:      	add	x15, x26, x10
     f2c:      	ldp	q24, q13, [x15]
     f30:      	bif.16b	v12, v13, v19
     f34:      	bit.16b	v24, v11, v20
     f38:      	stp	q24, q12, [x15]
     f3c:      	add	x10, x10, #0x20
     f40:      	cmp	x10, #0x4, lsl #12      ; =0x4000
     f44:      	b.eq	0xfec <_llm_rows.packet_batch.blocks+0x7cc>
     f48:      	ldr	q24, [sp, #0xf0]
     f4c:      	and.16b	v24, v8, v24
     f50:      	addv.8h	h28, v24
     f54:      	fmov	w16, s28
     f58:      	add	x15, x14, x10
     f5c:      	movi.2d	v11, #0000000000000000
     f60:      	movi.2d	v12, #0000000000000000
     f64:      	tbz	w16, #0x0, 0xfa8 <_llm_rows.packet_batch.blocks+0x788>
     f68:      	ldr	s11, [x15]
     f6c:      	and	w16, w16, #0xff
     f70:      	tbnz	w16, #0x1, 0xfb0 <_llm_rows.packet_batch.blocks+0x790>
     f74:      	tbz	w16, #0x2, 0xfbc <_llm_rows.packet_batch.blocks+0x79c>
     f78:      	add	x17, x15, #0x8
     f7c:      	ld1.s	{ v11 }[2], [x17]
     f80:      	tbnz	w16, #0x3, 0xfc0 <_llm_rows.packet_batch.blocks+0x7a0>
     f84:      	tbz	w16, #0x4, 0xfcc <_llm_rows.packet_batch.blocks+0x7ac>
     f88:      	add	x17, x15, #0x10
     f8c:      	ld1.s	{ v12 }[0], [x17]
     f90:      	tbnz	w16, #0x5, 0xfd0 <_llm_rows.packet_batch.blocks+0x7b0>
     f94:      	tbz	w16, #0x6, 0xfdc <_llm_rows.packet_batch.blocks+0x7bc>
     f98:      	add	x17, x15, #0x18
     f9c:      	ld1.s	{ v12 }[2], [x17]
     fa0:      	tbz	w16, #0x7, 0xf28 <_llm_rows.packet_batch.blocks+0x708>
     fa4:      	b	0xfe0 <_llm_rows.packet_batch.blocks+0x7c0>
     fa8:      	and	w16, w16, #0xff
     fac:      	tbz	w16, #0x1, 0xf74 <_llm_rows.packet_batch.blocks+0x754>
     fb0:      	add	x17, x15, #0x4
     fb4:      	ld1.s	{ v11 }[1], [x17]
     fb8:      	tbnz	w16, #0x2, 0xf78 <_llm_rows.packet_batch.blocks+0x758>
     fbc:      	tbz	w16, #0x3, 0xf84 <_llm_rows.packet_batch.blocks+0x764>
     fc0:      	add	x17, x15, #0xc
     fc4:      	ld1.s	{ v11 }[3], [x17]
     fc8:      	tbnz	w16, #0x4, 0xf88 <_llm_rows.packet_batch.blocks+0x768>
     fcc:      	tbz	w16, #0x5, 0xf94 <_llm_rows.packet_batch.blocks+0x774>
     fd0:      	add	x17, x15, #0x14
     fd4:      	ld1.s	{ v12 }[1], [x17]
     fd8:      	tbnz	w16, #0x6, 0xf98 <_llm_rows.packet_batch.blocks+0x778>
     fdc:      	tbz	w16, #0x7, 0xf28 <_llm_rows.packet_batch.blocks+0x708>
     fe0:      	add	x15, x15, #0x1c
     fe4:      	ld1.s	{ v12 }[3], [x15]
     fe8:      	b	0xf28 <_llm_rows.packet_batch.blocks+0x708>
     fec:      	uzp1.8b	v24, v30, v0
     ff0:      	movi.2d	v30, #0000000000000000
     ff4:      	mov.b	v30[0], v24[0]
     ff8:      	adrp	x10, 0x0 <ltmp0>
     ffc:      	ldr	d11, [x10]
    1000:      	and.8b	v8, v30, v11
    1004:      	addv.8b	b8, v8
    1008:      	fmov	w15, s8
    100c:      	umaxv.8b	b8, v30
    1010:      	fmov	w16, s8
    1014:      	rbit	w10, w15
    1018:      	clz	w10, w10
    101c:      	tst	w16, #0x1
    1020:      	csel	w10, w10, wzr, ne
    1024:      	mov	w14, #0x1000            ; =4096
    1028:      	dup.2d	v12, x14
    102c:      	umlal.2d	v29, v31, v25
    1030:      	movi.2d	v8, #0000000000000000
    1034:      	mov.b	v8[0], v24[0]
    1038:      	add.2d	v29, v29, v12
    103c:      	ushll.2d	v24, v8, #0x0
    1040:      	shl.2d	v24, v24, #0x3f
    1044:      	cmlt.2d	v24, v24, #0
    1048:      	str	q29, [sp, #0x50]
    104c:      	and.16b	v24, v24, v29
    1050:      	movi.2d	v29, #0000000000000000
    1054:      	stp	q29, q29, [sp, #0x260]
    1058:      	stp	q24, q29, [sp, #0x240]
    105c:      	and	x14, x10, #0x7
    1060:      	add	x17, sp, #0x240
    1064:      	ldr	x14, [x17, x14, lsl #3]
    1068:      	sub	x14, x14, x10
    106c:      	lsl	x14, x14, #2
    1070:      	add	x11, x11, x14
    1074:      	movi.2d	v31, #0000000000000000
    1078:      	tbz	w16, #0x0, 0x10b8 <_llm_rows.packet_batch.blocks+0x898>
    107c:      	ldr	s31, [x11]
    1080:      	tbnz	w15, #0x1, 0x10bc <_llm_rows.packet_batch.blocks+0x89c>
    1084:      	tbz	w15, #0x2, 0x10c8 <_llm_rows.packet_batch.blocks+0x8a8>
    1088:      	add	x16, x11, #0x8
    108c:      	ld1.s	{ v31 }[2], [x16]
    1090:      	tbnz	w15, #0x3, 0x10cc <_llm_rows.packet_batch.blocks+0x8ac>
    1094:      	tbz	w15, #0x4, 0x10d8 <_llm_rows.packet_batch.blocks+0x8b8>
    1098:      	add	x16, x11, #0x10
    109c:      	ld1.s	{ v29 }[0], [x16]
    10a0:      	tbnz	w15, #0x5, 0x10dc <_llm_rows.packet_batch.blocks+0x8bc>
    10a4:      	tbz	w15, #0x6, 0x10e8 <_llm_rows.packet_batch.blocks+0x8c8>
    10a8:      	add	x16, x11, #0x18
    10ac:      	ld1.s	{ v29 }[2], [x16]
    10b0:      	tbnz	w15, #0x7, 0x10ec <_llm_rows.packet_batch.blocks+0x8cc>
    10b4:      	b	0x10f4 <_llm_rows.packet_batch.blocks+0x8d4>
    10b8:      	tbz	w15, #0x1, 0x1084 <_llm_rows.packet_batch.blocks+0x864>
    10bc:      	add	x16, x11, #0x4
    10c0:      	ld1.s	{ v31 }[1], [x16]
    10c4:      	tbnz	w15, #0x2, 0x1088 <_llm_rows.packet_batch.blocks+0x868>
    10c8:      	tbz	w15, #0x3, 0x1094 <_llm_rows.packet_batch.blocks+0x874>
    10cc:      	add	x16, x11, #0xc
    10d0:      	ld1.s	{ v31 }[3], [x16]
    10d4:      	tbnz	w15, #0x4, 0x1098 <_llm_rows.packet_batch.blocks+0x878>
    10d8:      	tbz	w15, #0x5, 0x10a4 <_llm_rows.packet_batch.blocks+0x884>
    10dc:      	add	x16, x11, #0x14
    10e0:      	ld1.s	{ v29 }[1], [x16]
    10e4:      	tbnz	w15, #0x6, 0x10a8 <_llm_rows.packet_batch.blocks+0x888>
    10e8:      	tbz	w15, #0x7, 0x10f4 <_llm_rows.packet_batch.blocks+0x8d4>
    10ec:      	add	x11, x11, #0x1c
    10f0:      	ld1.s	{ v29 }[3], [x11]
    10f4:      	mov	x17, #0x0               ; =0
    10f8:      	umlal.2d	v23, v27, v25
    10fc:      	add.2d	v23, v23, v12
    1100:      	umlal.2d	v22, v26, v25
    1104:      	add.2d	v22, v22, v12
    1108:      	stp	q22, q23, [sp, #0x20]
    110c:      	ldr	d22, [sp, #0xc0]
    1110:      	umlal.2d	v21, v22, v25
    1114:      	add.2d	v21, v21, v12
    1118:      	str	q21, [sp, #0x10]
    111c:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7e0>
    1120:      	ldr	q21, [x11]
    1124:      	mov	w11, #0x4000            ; =16384
    1128:      	dup.2d	v22, x11
    112c:      	sshll.2d	v23, v20, #0x0
    1130:      	bif.16b	v21, v22, v23
    1134:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7e0>
    1138:      	ldr	q23, [x11]
    113c:      	sshll.2d	v24, v19, #0x0
    1140:      	bif.16b	v23, v22, v24
    1144:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7e0>
    1148:      	ldr	q24, [x11]
    114c:      	bif.16b	v24, v22, v10
    1150:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7e0>
    1154:      	ldr	q25, [x11]
    1158:      	bit.16b	v22, v25, v9
    115c:      	stp	q23, q22, [sp, #0x220]
    1160:      	stp	q21, q24, [sp, #0x200]
    1164:      	and	x11, x10, #0x7
    1168:      	add	x16, sp, #0x200
    116c:      	ldr	x11, [x16, x11, lsl #3]
    1170:      	sub	x11, x11, x10, lsl #2
    1174:      	tst	w15, #0xff
    1178:      	csel	x15, xzr, x11, eq
    117c:      	add	x11, x26, x15
    1180:      	ldp	q21, q22, [x11]
    1184:      	zip2.8b	v23, v30, v0
    1188:      	ushll.4s	v23, v23, #0x0
    118c:      	shl.4s	v23, v23, #0x1f
    1190:      	cmlt.4s	v23, v23, #0
    1194:      	str	q29, [sp, #0xc0]
    1198:      	bit.16b	v22, v29, v23
    119c:      	zip1.8b	v23, v30, v0
    11a0:      	ushll.4s	v23, v23, #0x0
    11a4:      	shl.4s	v23, v23, #0x1f
    11a8:      	cmlt.4s	v23, v23, #0
    11ac:      	str	q31, [sp, #0x40]
    11b0:      	bit.16b	v21, v31, v23
    11b4:      	stp	q21, q22, [x11]
    11b8:      	add	x16, x9, x12
    11bc:      	ushll2.2d	v21, v19, #0x0
    11c0:      	mov	w11, #0x1               ; =1
    11c4:      	dup.2d	v22, x11
    11c8:      	and.16b	v24, v21, v22
    11cc:      	ushll2.2d	v21, v20, #0x0
    11d0:      	and.16b	v25, v21, v22
    11d4:      	ushll.2d	v21, v19, #0x0
    11d8:      	and.16b	v26, v21, v22
    11dc:      	ushll.2d	v21, v20, #0x0
    11e0:      	and.16b	v27, v21, v22
    11e4:      	movi.2d	v9, #0000000000000000
    11e8:      	and	x11, x13, #0x1
    11ec:      	movi.2d	v10, #0000000000000000
    11f0:      	movi.2d	v12, #0000000000000000
    11f4:      	movi.2d	v13, #0000000000000000
    11f8:      	b	0x1234 <_llm_rows.packet_batch.blocks+0xa14>
    11fc:      	add	x13, x24, x13
    1200:      	ldp	q21, q22, [x13]
    1204:      	bit.16b	v22, v15, v19
    1208:      	bit.16b	v21, v14, v20
    120c:      	stp	q21, q22, [x13]
    1210:      	add.2d	v21, v9, v27
    1214:      	add.2d	v10, v10, v25
    1218:      	add.2d	v12, v12, v26
    121c:      	add.2d	v13, v13, v24
    1220:      	fmov	x13, d9
    1224:      	add	x17, x13, x11
    1228:      	mov.16b	v9, v21
    122c:      	cmp	x17, #0x200
    1230:      	b.ge	0x12d0 <_llm_rows.packet_batch.blocks+0xab0>
    1234:      	fmov	w0, s28
    1238:      	lsl	x13, x17, #5
    123c:      	add	x17, x16, x13
    1240:      	movi.2d	v14, #0000000000000000
    1244:      	movi.2d	v15, #0000000000000000
    1248:      	tbz	w0, #0x0, 0x128c <_llm_rows.packet_batch.blocks+0xa6c>
    124c:      	ldr	s14, [x17]
    1250:      	and	w0, w0, #0xff
    1254:      	tbnz	w0, #0x1, 0x1294 <_llm_rows.packet_batch.blocks+0xa74>
    1258:      	tbz	w0, #0x2, 0x12a0 <_llm_rows.packet_batch.blocks+0xa80>
    125c:      	add	x1, x17, #0x8
    1260:      	ld1.s	{ v14 }[2], [x1]
    1264:      	tbnz	w0, #0x3, 0x12a4 <_llm_rows.packet_batch.blocks+0xa84>
    1268:      	tbz	w0, #0x4, 0x12b0 <_llm_rows.packet_batch.blocks+0xa90>
    126c:      	add	x1, x17, #0x10
    1270:      	ld1.s	{ v15 }[0], [x1]
    1274:      	tbnz	w0, #0x5, 0x12b4 <_llm_rows.packet_batch.blocks+0xa94>
    1278:      	tbz	w0, #0x6, 0x12c0 <_llm_rows.packet_batch.blocks+0xaa0>
    127c:      	add	x1, x17, #0x18
    1280:      	ld1.s	{ v15 }[2], [x1]
    1284:      	tbz	w0, #0x7, 0x11fc <_llm_rows.packet_batch.blocks+0x9dc>
    1288:      	b	0x12c4 <_llm_rows.packet_batch.blocks+0xaa4>
    128c:      	and	w0, w0, #0xff
    1290:      	tbz	w0, #0x1, 0x1258 <_llm_rows.packet_batch.blocks+0xa38>
    1294:      	add	x1, x17, #0x4
    1298:      	ld1.s	{ v14 }[1], [x1]
    129c:      	tbnz	w0, #0x2, 0x125c <_llm_rows.packet_batch.blocks+0xa3c>
    12a0:      	tbz	w0, #0x3, 0x1268 <_llm_rows.packet_batch.blocks+0xa48>
    12a4:      	add	x1, x17, #0xc
    12a8:      	ld1.s	{ v14 }[3], [x1]
    12ac:      	tbnz	w0, #0x4, 0x126c <_llm_rows.packet_batch.blocks+0xa4c>
    12b0:      	tbz	w0, #0x5, 0x1278 <_llm_rows.packet_batch.blocks+0xa58>
    12b4:      	add	x1, x17, #0x14
    12b8:      	ld1.s	{ v15 }[1], [x1]
    12bc:      	tbnz	w0, #0x6, 0x127c <_llm_rows.packet_batch.blocks+0xa5c>
    12c0:      	tbz	w0, #0x7, 0x11fc <_llm_rows.packet_batch.blocks+0x9dc>
    12c4:      	add	x17, x17, #0x1c
    12c8:      	ld1.s	{ v15 }[3], [x17]
    12cc:      	b	0x11fc <_llm_rows.packet_batch.blocks+0x9dc>
    12d0:      	add	x9, x9, x14
    12d4:      	shl.8b	v21, v30, #0x7
    12d8:      	cmlt.8b	v21, v21, #0
    12dc:      	and.8b	v21, v21, v11
    12e0:      	addv.8b	b21, v21
    12e4:      	str	d21, [sp, #0x8]
    12e8:      	fmov	w13, s21
    12ec:      	movi.2d	v10, #0000000000000000
    12f0:      	movi.2d	v9, #0000000000000000
    12f4:      	tbz	w13, #0x0, 0x1334 <_llm_rows.packet_batch.blocks+0xb14>
    12f8:      	ldr	s10, [x9]
    12fc:      	tbnz	w13, #0x1, 0x1338 <_llm_rows.packet_batch.blocks+0xb18>
    1300:      	tbz	w13, #0x2, 0x1344 <_llm_rows.packet_batch.blocks+0xb24>
    1304:      	add	x14, x9, #0x8
    1308:      	ld1.s	{ v10 }[2], [x14]
    130c:      	tbnz	w13, #0x3, 0x1348 <_llm_rows.packet_batch.blocks+0xb28>
    1310:      	tbz	w13, #0x4, 0x1354 <_llm_rows.packet_batch.blocks+0xb34>
    1314:      	add	x14, x9, #0x10
    1318:      	ld1.s	{ v9 }[0], [x14]
    131c:      	tbnz	w13, #0x5, 0x1358 <_llm_rows.packet_batch.blocks+0xb38>
    1320:      	tbz	w13, #0x6, 0x1364 <_llm_rows.packet_batch.blocks+0xb44>
    1324:      	add	x14, x9, #0x18
    1328:      	ld1.s	{ v9 }[2], [x14]
    132c:      	tbnz	w13, #0x7, 0x1368 <_llm_rows.packet_batch.blocks+0xb48>
    1330:      	b	0x1370 <_llm_rows.packet_batch.blocks+0xb50>
    1334:      	tbz	w13, #0x1, 0x1300 <_llm_rows.packet_batch.blocks+0xae0>
    1338:      	add	x14, x9, #0x4
    133c:      	ld1.s	{ v10 }[1], [x14]
    1340:      	tbnz	w13, #0x2, 0x1304 <_llm_rows.packet_batch.blocks+0xae4>
    1344:      	tbz	w13, #0x3, 0x1310 <_llm_rows.packet_batch.blocks+0xaf0>
    1348:      	add	x14, x9, #0xc
    134c:      	ld1.s	{ v10 }[3], [x14]
    1350:      	tbnz	w13, #0x4, 0x1314 <_llm_rows.packet_batch.blocks+0xaf4>
    1354:      	tbz	w13, #0x5, 0x1320 <_llm_rows.packet_batch.blocks+0xb00>
    1358:      	add	x14, x9, #0x14
    135c:      	ld1.s	{ v9 }[1], [x14]
    1360:      	tbnz	w13, #0x6, 0x1324 <_llm_rows.packet_batch.blocks+0xb04>
    1364:      	tbz	w13, #0x7, 0x1370 <_llm_rows.packet_batch.blocks+0xb50>
    1368:      	add	x9, x9, #0x1c
    136c:      	ld1.s	{ v9 }[3], [x9]
    1370:      	mov	x14, #0x0               ; =0
    1374:      	add	x9, x24, x15
    1378:      	ldp	q21, q22, [x9]
    137c:      	zip2.8b	v23, v30, v0
    1380:      	ushll.4s	v23, v23, #0x0
    1384:      	shl.4s	v23, v23, #0x1f
    1388:      	cmlt.4s	v23, v23, #0
    138c:      	bit.16b	v22, v9, v23
    1390:      	zip1.8b	v23, v30, v0
    1394:      	ushll.4s	v23, v23, #0x0
    1398:      	shl.4s	v23, v23, #0x1f
    139c:      	cmlt.4s	v23, v23, #0
    13a0:      	bit.16b	v21, v10, v23
    13a4:      	stp	q21, q22, [x9]
    13a8:      	add	x9, x8, x12
    13ac:      	movi.2d	v12, #0000000000000000
    13b0:      	movi.2d	v13, #0000000000000000
    13b4:      	movi.2d	v14, #0000000000000000
    13b8:      	movi.2d	v15, #0000000000000000
    13bc:      	b	0x13e4 <_llm_rows.packet_batch.blocks+0xbc4>
    13c0:      	add.2d	v21, v12, v27
    13c4:      	add.2d	v13, v13, v25
    13c8:      	add.2d	v14, v14, v26
    13cc:      	add.2d	v15, v15, v24
    13d0:      	fmov	x12, d12
    13d4:      	add	x14, x12, x11
    13d8:      	mov.16b	v12, v21
    13dc:      	cmp	x14, #0x200
    13e0:      	b.ge	0x1634 <_llm_rows.packet_batch.blocks+0xe14>
    13e4:      	fmov	w13, s28
    13e8:      	lsl	x12, x14, #5
    13ec:      	add	x14, x26, x12
    13f0:      	ldp	q21, q23, [x14]
    13f4:      	and.16b	v21, v20, v21
    13f8:      	fneg.4s	v22, v21
    13fc:      	and.16b	v22, v20, v22
    1400:      	fcmge.4s	v31, v22, v1
    1404:      	fcmge.4s	v11, v0, v22
    1408:      	and.16b	v31, v31, v11
    140c:      	and.16b	v31, v31, v22
    1410:      	fmul.4s	v11, v31, v18
    1414:      	movi.4s	v29, #0x4b, lsl #24
    1418:      	mvni.4s	v8, #0x80, lsl #24
    141c:      	bsl.16b	v8, v29, v11
    1420:      	fadd.4s	v11, v11, v8
    1424:      	fsub.4s	v8, v11, v8
    1428:      	fcvtzs.4s	v8, v8
    142c:      	scvtf.4s	v11, v8
    1430:      	fmul.4s	v29, v11, v17
    1434:      	fadd.4s	v29, v31, v29
    1438:      	fmul.4s	v31, v11, v16
    143c:      	fadd.4s	v29, v29, v31
    1440:      	fmul.4s	v31, v29, v7
    1444:      	fadd.4s	v31, v31, v6
    1448:      	fmul.4s	v31, v29, v31
    144c:      	fadd.4s	v31, v31, v5
    1450:      	fmul.4s	v31, v29, v31
    1454:      	fadd.4s	v31, v31, v4
    1458:      	fmul.4s	v31, v29, v31
    145c:      	fadd.4s	v31, v31, v3
    1460:      	fmul.4s	v31, v29, v31
    1464:      	movi.4s	v11, #0x3f, lsl #24
    1468:      	fadd.4s	v31, v31, v11
    146c:      	fmul.4s	v11, v29, v29
    1470:      	fmul.4s	v31, v11, v31
    1474:      	fadd.4s	v29, v29, v31
    1478:      	fadd.4s	v29, v29, v2
    147c:      	sshr.4s	v31, v8, #0x1
    1480:      	shl.4s	v11, v31, #0x17
    1484:      	add.4s	v11, v11, v2
    1488:      	fmul.4s	v29, v29, v11
    148c:      	sub.4s	v31, v8, v31
    1490:      	shl.4s	v31, v31, #0x17
    1494:      	add.4s	v31, v31, v2
    1498:      	fmul.4s	v29, v29, v31
    149c:      	fcmgt.4s	v31, v1, v22
    14a0:      	fcmgt.4s	v8, v22, v0
    14a4:      	fcmeq.4s	v22, v22, v22
    14a8:      	fadd.4s	v29, v29, v2
    14ac:      	bit.16b	v29, v2, v31
    14b0:      	ldr	q31, [sp, #0x110]
    14b4:      	bit.16b	v29, v31, v8
    14b8:      	ldr	q31, [sp, #0x100]
    14bc:      	bsl.16b	v22, v29, v31
    14c0:      	fdiv.4s	v21, v21, v22
    14c4:      	add	x14, x24, x12
    14c8:      	ldp	q29, q22, [x14]
    14cc:      	and.16b	v29, v20, v29
    14d0:      	fmul.4s	v21, v29, v21
    14d4:      	add	x12, x9, x12
    14d8:      	tbz	w13, #0x0, 0x14fc <_llm_rows.packet_batch.blocks+0xcdc>
    14dc:      	str	s21, [x12]
    14e0:      	and	w13, w13, #0xff
    14e4:      	tbnz	w13, #0x1, 0x1504 <_llm_rows.packet_batch.blocks+0xce4>
    14e8:      	tbz	w13, #0x2, 0x1510 <_llm_rows.packet_batch.blocks+0xcf0>
    14ec:      	add	x14, x12, #0x8
    14f0:      	st1.s	{ v21 }[2], [x14]
    14f4:      	tbnz	w13, #0x3, 0x1514 <_llm_rows.packet_batch.blocks+0xcf4>
    14f8:      	b	0x151c <_llm_rows.packet_batch.blocks+0xcfc>
    14fc:      	and	w13, w13, #0xff
    1500:      	tbz	w13, #0x1, 0x14e8 <_llm_rows.packet_batch.blocks+0xcc8>
    1504:      	add	x14, x12, #0x4
    1508:      	st1.s	{ v21 }[1], [x14]
    150c:      	tbnz	w13, #0x2, 0x14ec <_llm_rows.packet_batch.blocks+0xccc>
    1510:      	tbz	w13, #0x3, 0x151c <_llm_rows.packet_batch.blocks+0xcfc>
    1514:      	add	x14, x12, #0xc
    1518:      	st1.s	{ v21 }[3], [x14]
    151c:      	and.16b	v21, v19, v23
    1520:      	fneg.4s	v23, v21
    1524:      	and.16b	v23, v19, v23
    1528:      	fcmge.4s	v29, v23, v1
    152c:      	fcmge.4s	v31, v0, v23
    1530:      	and.16b	v29, v29, v31
    1534:      	and.16b	v29, v29, v23
    1538:      	fmul.4s	v31, v29, v18
    153c:      	movi.4s	v8, #0x4b, lsl #24
    1540:      	mvni.4s	v11, #0x80, lsl #24
    1544:      	bif.16b	v8, v31, v11
    1548:      	fadd.4s	v31, v31, v8
    154c:      	fsub.4s	v31, v31, v8
    1550:      	fcvtzs.4s	v31, v31
    1554:      	scvtf.4s	v8, v31
    1558:      	fmul.4s	v11, v8, v17
    155c:      	fadd.4s	v29, v29, v11
    1560:      	fmul.4s	v8, v8, v16
    1564:      	fadd.4s	v29, v29, v8
    1568:      	fmul.4s	v8, v29, v7
    156c:      	fadd.4s	v8, v8, v6
    1570:      	fmul.4s	v8, v29, v8
    1574:      	fadd.4s	v8, v8, v5
    1578:      	fmul.4s	v8, v29, v8
    157c:      	fadd.4s	v8, v8, v4
    1580:      	fmul.4s	v8, v29, v8
    1584:      	fadd.4s	v8, v8, v3
    1588:      	fmul.4s	v8, v29, v8
    158c:      	movi.4s	v11, #0x3f, lsl #24
    1590:      	fadd.4s	v8, v8, v11
    1594:      	fmul.4s	v11, v29, v29
    1598:      	fmul.4s	v8, v11, v8
    159c:      	fadd.4s	v29, v29, v8
    15a0:      	fadd.4s	v29, v29, v2
    15a4:      	sshr.4s	v8, v31, #0x1
    15a8:      	shl.4s	v11, v8, #0x17
    15ac:      	add.4s	v11, v11, v2
    15b0:      	fmul.4s	v29, v29, v11
    15b4:      	sub.4s	v31, v31, v8
    15b8:      	shl.4s	v31, v31, #0x17
    15bc:      	add.4s	v31, v31, v2
    15c0:      	fmul.4s	v29, v29, v31
    15c4:      	fcmgt.4s	v31, v1, v23
    15c8:      	fcmgt.4s	v8, v23, v0
    15cc:      	fcmeq.4s	v23, v23, v23
    15d0:      	fadd.4s	v29, v29, v2
    15d4:      	bit.16b	v29, v2, v31
    15d8:      	ldr	q31, [sp, #0x110]
    15dc:      	bit.16b	v29, v31, v8
    15e0:      	ldr	q31, [sp, #0x100]
    15e4:      	bsl.16b	v23, v29, v31
    15e8:      	fdiv.4s	v21, v21, v23
    15ec:      	and.16b	v22, v19, v22
    15f0:      	fmul.4s	v21, v22, v21
    15f4:      	tbz	w13, #0x4, 0x1614 <_llm_rows.packet_batch.blocks+0xdf4>
    15f8:      	str	s21, [x12, #0x10]
    15fc:      	tbnz	w13, #0x5, 0x1618 <_llm_rows.packet_batch.blocks+0xdf8>
    1600:      	tbz	w13, #0x6, 0x1624 <_llm_rows.packet_batch.blocks+0xe04>
    1604:      	add	x14, x12, #0x18
    1608:      	st1.s	{ v21 }[2], [x14]
    160c:      	tbz	w13, #0x7, 0x13c0 <_llm_rows.packet_batch.blocks+0xba0>
    1610:      	b	0x1628 <_llm_rows.packet_batch.blocks+0xe08>
    1614:      	tbz	w13, #0x5, 0x1600 <_llm_rows.packet_batch.blocks+0xde0>
    1618:      	add	x14, x12, #0x14
    161c:      	st1.s	{ v21 }[1], [x14]
    1620:      	tbnz	w13, #0x6, 0x1604 <_llm_rows.packet_batch.blocks+0xde4>
    1624:      	tbz	w13, #0x7, 0x13c0 <_llm_rows.packet_batch.blocks+0xba0>
    1628:      	add	x12, x12, #0x1c
    162c:      	st1.s	{ v21 }[3], [x12]
    1630:      	b	0x13c0 <_llm_rows.packet_batch.blocks+0xba0>
    1634:      	ldr	q24, [sp, #0x40]
    1638:      	fneg.4s	v19, v24
    163c:      	ldr	d20, [sp, #0x8]
    1640:      	fmov	w9, s20
    1644:      	zip1.8b	v20, v30, v0
    1648:      	ushll.4s	v20, v20, #0x0
    164c:      	shl.4s	v20, v20, #0x1f
    1650:      	cmlt.4s	v20, v20, #0
    1654:      	and.16b	v19, v20, v19
    1658:      	fcmge.4s	v20, v19, v1
    165c:      	fcmge.4s	v21, v0, v19
    1660:      	and.16b	v20, v20, v21
    1664:      	and.16b	v20, v20, v19
    1668:      	fmul.4s	v21, v20, v18
    166c:      	movi.4s	v22, #0x4b, lsl #24
    1670:      	mvni.4s	v23, #0x80, lsl #24
    1674:      	bif.16b	v22, v21, v23
    1678:      	fadd.4s	v21, v21, v22
    167c:      	fsub.4s	v21, v21, v22
    1680:      	fcvtzs.4s	v21, v21
    1684:      	scvtf.4s	v22, v21
    1688:      	fmul.4s	v23, v22, v17
    168c:      	fadd.4s	v20, v20, v23
    1690:      	fmul.4s	v22, v22, v16
    1694:      	fadd.4s	v20, v20, v22
    1698:      	fmul.4s	v22, v20, v7
    169c:      	fadd.4s	v22, v22, v6
    16a0:      	fmul.4s	v22, v20, v22
    16a4:      	fadd.4s	v22, v22, v5
    16a8:      	fmul.4s	v22, v20, v22
    16ac:      	fadd.4s	v22, v22, v4
    16b0:      	fmul.4s	v22, v20, v22
    16b4:      	fadd.4s	v22, v22, v3
    16b8:      	fmul.4s	v22, v20, v22
    16bc:      	movi.4s	v23, #0x3f, lsl #24
    16c0:      	fadd.4s	v22, v22, v23
    16c4:      	fmul.4s	v23, v20, v20
    16c8:      	fmul.4s	v22, v23, v22
    16cc:      	fadd.4s	v20, v20, v22
    16d0:      	fadd.4s	v20, v20, v2
    16d4:      	sshr.4s	v22, v21, #0x1
    16d8:      	shl.4s	v23, v22, #0x17
    16dc:      	add.4s	v23, v23, v2
    16e0:      	fmul.4s	v20, v20, v23
    16e4:      	sub.4s	v21, v21, v22
    16e8:      	shl.4s	v21, v21, #0x17
    16ec:      	add.4s	v21, v21, v2
    16f0:      	fmul.4s	v20, v20, v21
    16f4:      	fcmgt.4s	v21, v1, v19
    16f8:      	fcmgt.4s	v22, v19, v0
    16fc:      	fcmeq.4s	v19, v19, v19
    1700:      	fadd.4s	v20, v20, v2
    1704:      	bit.16b	v20, v2, v21
    1708:      	ldp	q21, q23, [sp, #0x100]
    170c:      	bit.16b	v20, v23, v22
    1710:      	bsl.16b	v19, v20, v21
    1714:      	fdiv.4s	v19, v24, v19
    1718:      	fmul.4s	v19, v19, v10
    171c:      	ldr	q21, [sp, #0x50]
    1720:      	ldp	q23, q22, [sp, #0x20]
    1724:      	stp	q21, q22, [sp, #0x1b0]
    1728:      	ldr	q20, [sp, #0x10]
    172c:      	stp	q23, q20, [sp, #0x1d0]
    1730:      	and	x11, x10, #0x7
    1734:      	add	x12, sp, #0x1b0
    1738:      	ldr	x11, [x12, x11, lsl #3]
    173c:      	sub	x10, x11, x10
    1740:      	add	x8, x8, x10, lsl #2
    1744:      	tbz	w9, #0x0, 0x1768 <_llm_rows.packet_batch.blocks+0xf48>
    1748:      	str	s19, [x8]
    174c:      	ldr	q23, [sp, #0xc0]
    1750:      	tbnz	w9, #0x1, 0x1770 <_llm_rows.packet_batch.blocks+0xf50>
    1754:      	tbz	w9, #0x2, 0x177c <_llm_rows.packet_batch.blocks+0xf5c>
    1758:      	add	x10, x8, #0x8
    175c:      	st1.s	{ v19 }[2], [x10]
    1760:      	tbnz	w9, #0x3, 0x1780 <_llm_rows.packet_batch.blocks+0xf60>
    1764:      	b	0x1788 <_llm_rows.packet_batch.blocks+0xf68>
    1768:      	ldr	q23, [sp, #0xc0]
    176c:      	tbz	w9, #0x1, 0x1754 <_llm_rows.packet_batch.blocks+0xf34>
    1770:      	add	x10, x8, #0x4
    1774:      	st1.s	{ v19 }[1], [x10]
    1778:      	tbnz	w9, #0x2, 0x1758 <_llm_rows.packet_batch.blocks+0xf38>
    177c:      	tbz	w9, #0x3, 0x1788 <_llm_rows.packet_batch.blocks+0xf68>
    1780:      	add	x10, x8, #0xc
    1784:      	st1.s	{ v19 }[3], [x10]
    1788:      	fneg.4s	v19, v23
    178c:      	zip2.8b	v20, v30, v0
    1790:      	ushll.4s	v20, v20, #0x0
    1794:      	shl.4s	v20, v20, #0x1f
    1798:      	cmlt.4s	v20, v20, #0
    179c:      	and.16b	v19, v20, v19
    17a0:      	fcmge.4s	v20, v19, v1
    17a4:      	fcmge.4s	v21, v0, v19
    17a8:      	and.16b	v20, v20, v21
    17ac:      	and.16b	v20, v20, v19
    17b0:      	fmul.4s	v18, v20, v18
    17b4:      	movi.4s	v21, #0x4b, lsl #24
    17b8:      	mvni.4s	v22, #0x80, lsl #24
    17bc:      	bif.16b	v21, v18, v22
    17c0:      	fadd.4s	v18, v18, v21
    17c4:      	fsub.4s	v18, v18, v21
    17c8:      	fcvtzs.4s	v18, v18
    17cc:      	scvtf.4s	v21, v18
    17d0:      	fmul.4s	v17, v21, v17
    17d4:      	fadd.4s	v17, v20, v17
    17d8:      	fmul.4s	v16, v21, v16
    17dc:      	fadd.4s	v16, v17, v16
    17e0:      	fmul.4s	v7, v16, v7
    17e4:      	fadd.4s	v6, v7, v6
    17e8:      	fmul.4s	v6, v16, v6
    17ec:      	fadd.4s	v5, v6, v5
    17f0:      	fmul.4s	v5, v16, v5
    17f4:      	fadd.4s	v4, v5, v4
    17f8:      	fmul.4s	v4, v16, v4
    17fc:      	fadd.4s	v3, v4, v3
    1800:      	fmul.4s	v3, v16, v3
    1804:      	movi.4s	v4, #0x3f, lsl #24
    1808:      	fadd.4s	v3, v3, v4
    180c:      	fmul.4s	v4, v16, v16
    1810:      	fmul.4s	v3, v4, v3
    1814:      	fadd.4s	v3, v16, v3
    1818:      	fadd.4s	v3, v3, v2
    181c:      	sshr.4s	v4, v18, #0x1
    1820:      	shl.4s	v5, v4, #0x17
    1824:      	add.4s	v5, v5, v2
    1828:      	fmul.4s	v3, v3, v5
    182c:      	sub.4s	v4, v18, v4
    1830:      	shl.4s	v4, v4, #0x17
    1834:      	add.4s	v4, v4, v2
    1838:      	fmul.4s	v3, v3, v4
    183c:      	fcmgt.4s	v1, v1, v19
    1840:      	fcmgt.4s	v0, v19, v0
    1844:      	fcmeq.4s	v4, v19, v19
    1848:      	fadd.4s	v3, v3, v2
    184c:      	bsl.16b	v1, v2, v3
    1850:      	ldr	q2, [sp, #0x110]
    1854:      	bsl.16b	v0, v2, v1
    1858:      	ldr	q1, [sp, #0x100]
    185c:      	bif.16b	v0, v1, v4
    1860:      	fdiv.4s	v0, v23, v0
    1864:      	fmul.4s	v0, v0, v9
    1868:      	tbz	w9, #0x4, 0x1c64 <_llm_rows.packet_batch.blocks+0x1444>
    186c:      	str	s0, [x8, #0x10]
    1870:      	tbnz	w9, #0x5, 0x1c68 <_llm_rows.packet_batch.blocks+0x1448>
    1874:      	tbz	w9, #0x6, 0x1c74 <_llm_rows.packet_batch.blocks+0x1454>
    1878:      	add	x10, x8, #0x18
    187c:      	st1.s	{ v0 }[2], [x10]
    1880:      	tbnz	w9, #0x7, 0x1c78 <_llm_rows.packet_batch.blocks+0x1458>
    1884:      	b	0x8f0 <_llm_rows.packet_batch.blocks+0xd0>
    1888:      	uzp1.8b	v19, v30, v0
    188c:      	movi.2d	v20, #0000000000000000
    1890:      	mov.b	v20[0], v19[0]
    1894:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x7e0>
    1898:      	ldr	d8, [x10]
    189c:      	and.8b	v24, v20, v8
    18a0:      	addv.8b	b24, v24
    18a4:      	fmov	w12, s24
    18a8:      	umaxv.8b	b24, v20
    18ac:      	fmov	w14, s24
    18b0:      	rbit	w10, w12
    18b4:      	clz	w10, w10
    18b8:      	tst	w14, #0x1
    18bc:      	csel	w10, w10, wzr, ne
    18c0:      	mov	w13, #0x1000            ; =4096
    18c4:      	dup.2d	v30, x13
    18c8:      	umlal.2d	v29, v31, v25
    18cc:      	movi.2d	v24, #0000000000000000
    18d0:      	mov.b	v24[0], v19[0]
    18d4:      	add.2d	v28, v29, v30
    18d8:      	ushll.2d	v19, v24, #0x0
    18dc:      	shl.2d	v19, v19, #0x3f
    18e0:      	cmlt.2d	v19, v19, #0
    18e4:      	and.16b	v19, v19, v28
    18e8:      	movi.2d	v24, #0000000000000000
    18ec:      	stp	q24, q24, [sp, #0x180]
    18f0:      	stp	q19, q24, [sp, #0x160]
    18f4:      	and	x13, x10, #0x7
    18f8:      	add	x15, sp, #0x160
    18fc:      	ldr	x13, [x15, x13, lsl #3]
    1900:      	sub	x13, x13, x10
    1904:      	lsl	x13, x13, #2
    1908:      	add	x11, x11, x13
    190c:      	movi.2d	v29, #0000000000000000
    1910:      	movi.2d	v19, #0000000000000000
    1914:      	tbz	w14, #0x0, 0x1954 <_llm_rows.packet_batch.blocks+0x1134>
    1918:      	ldr	s29, [x11]
    191c:      	tbnz	w12, #0x1, 0x1958 <_llm_rows.packet_batch.blocks+0x1138>
    1920:      	tbz	w12, #0x2, 0x1964 <_llm_rows.packet_batch.blocks+0x1144>
    1924:      	add	x14, x11, #0x8
    1928:      	ld1.s	{ v29 }[2], [x14]
    192c:      	tbnz	w12, #0x3, 0x1968 <_llm_rows.packet_batch.blocks+0x1148>
    1930:      	tbz	w12, #0x4, 0x1974 <_llm_rows.packet_batch.blocks+0x1154>
    1934:      	add	x14, x11, #0x10
    1938:      	ld1.s	{ v19 }[0], [x14]
    193c:      	tbnz	w12, #0x5, 0x1978 <_llm_rows.packet_batch.blocks+0x1158>
    1940:      	tbz	w12, #0x6, 0x1984 <_llm_rows.packet_batch.blocks+0x1164>
    1944:      	add	x14, x11, #0x18
    1948:      	ld1.s	{ v19 }[2], [x14]
    194c:      	tbnz	w12, #0x7, 0x1988 <_llm_rows.packet_batch.blocks+0x1168>
    1950:      	b	0x1990 <_llm_rows.packet_batch.blocks+0x1170>
    1954:      	tbz	w12, #0x1, 0x1920 <_llm_rows.packet_batch.blocks+0x1100>
    1958:      	add	x14, x11, #0x4
    195c:      	ld1.s	{ v29 }[1], [x14]
    1960:      	tbnz	w12, #0x2, 0x1924 <_llm_rows.packet_batch.blocks+0x1104>
    1964:      	tbz	w12, #0x3, 0x1930 <_llm_rows.packet_batch.blocks+0x1110>
    1968:      	add	x14, x11, #0xc
    196c:      	ld1.s	{ v29 }[3], [x14]
    1970:      	tbnz	w12, #0x4, 0x1934 <_llm_rows.packet_batch.blocks+0x1114>
    1974:      	tbz	w12, #0x5, 0x1940 <_llm_rows.packet_batch.blocks+0x1120>
    1978:      	add	x14, x11, #0x14
    197c:      	ld1.s	{ v19 }[1], [x14]
    1980:      	tbnz	w12, #0x6, 0x1944 <_llm_rows.packet_batch.blocks+0x1124>
    1984:      	tbz	w12, #0x7, 0x1990 <_llm_rows.packet_batch.blocks+0x1170>
    1988:      	add	x11, x11, #0x1c
    198c:      	ld1.s	{ v19 }[3], [x11]
    1990:      	shl.8b	v24, v20, #0x7
    1994:      	cmlt.8b	v24, v24, #0
    1998:      	and.8b	v24, v24, v8
    199c:      	addv.8b	b8, v24
    19a0:      	fmov	w11, s8
    19a4:      	add	x9, x9, x13
    19a8:      	movi.2d	v9, #0000000000000000
    19ac:      	movi.2d	v31, #0000000000000000
    19b0:      	tbz	w11, #0x0, 0x19f0 <_llm_rows.packet_batch.blocks+0x11d0>
    19b4:      	ldr	s9, [x9]
    19b8:      	tbnz	w11, #0x1, 0x19f4 <_llm_rows.packet_batch.blocks+0x11d4>
    19bc:      	tbz	w11, #0x2, 0x1a00 <_llm_rows.packet_batch.blocks+0x11e0>
    19c0:      	add	x12, x9, #0x8
    19c4:      	ld1.s	{ v9 }[2], [x12]
    19c8:      	tbnz	w11, #0x3, 0x1a04 <_llm_rows.packet_batch.blocks+0x11e4>
    19cc:      	tbz	w11, #0x4, 0x1a10 <_llm_rows.packet_batch.blocks+0x11f0>
    19d0:      	add	x12, x9, #0x10
    19d4:      	ld1.s	{ v31 }[0], [x12]
    19d8:      	tbnz	w11, #0x5, 0x1a14 <_llm_rows.packet_batch.blocks+0x11f4>
    19dc:      	tbz	w11, #0x6, 0x1a20 <_llm_rows.packet_batch.blocks+0x1200>
    19e0:      	add	x12, x9, #0x18
    19e4:      	ld1.s	{ v31 }[2], [x12]
    19e8:      	tbnz	w11, #0x7, 0x1a24 <_llm_rows.packet_batch.blocks+0x1204>
    19ec:      	b	0x1a2c <_llm_rows.packet_batch.blocks+0x120c>
    19f0:      	tbz	w11, #0x1, 0x19bc <_llm_rows.packet_batch.blocks+0x119c>
    19f4:      	add	x12, x9, #0x4
    19f8:      	ld1.s	{ v9 }[1], [x12]
    19fc:      	tbnz	w11, #0x2, 0x19c0 <_llm_rows.packet_batch.blocks+0x11a0>
    1a00:      	tbz	w11, #0x3, 0x19cc <_llm_rows.packet_batch.blocks+0x11ac>
    1a04:      	add	x12, x9, #0xc
    1a08:      	ld1.s	{ v9 }[3], [x12]
    1a0c:      	tbnz	w11, #0x4, 0x19d0 <_llm_rows.packet_batch.blocks+0x11b0>
    1a10:      	tbz	w11, #0x5, 0x19dc <_llm_rows.packet_batch.blocks+0x11bc>
    1a14:      	add	x12, x9, #0x14
    1a18:      	ld1.s	{ v31 }[1], [x12]
    1a1c:      	tbnz	w11, #0x6, 0x19e0 <_llm_rows.packet_batch.blocks+0x11c0>
    1a20:      	tbz	w11, #0x7, 0x1a2c <_llm_rows.packet_batch.blocks+0x120c>
    1a24:      	add	x9, x9, #0x1c
    1a28:      	ld1.s	{ v31 }[3], [x9]
    1a2c:      	umlal.2d	v23, v27, v25
    1a30:      	add.2d	v23, v23, v30
    1a34:      	umlal.2d	v22, v26, v25
    1a38:      	add.2d	v22, v22, v30
    1a3c:      	ldr	d24, [sp, #0xc0]
    1a40:      	umlal.2d	v21, v24, v25
    1a44:      	add.2d	v24, v21, v30
    1a48:      	fneg.4s	v21, v29
    1a4c:      	zip1.8b	v25, v20, v0
    1a50:      	ushll.4s	v25, v25, #0x0
    1a54:      	shl.4s	v25, v25, #0x1f
    1a58:      	cmlt.4s	v25, v25, #0
    1a5c:      	and.16b	v21, v25, v21
    1a60:      	fcmge.4s	v25, v21, v1
    1a64:      	fcmge.4s	v26, v0, v21
    1a68:      	and.16b	v25, v25, v26
    1a6c:      	and.16b	v25, v25, v21
    1a70:      	fmul.4s	v26, v25, v18
    1a74:      	movi.4s	v27, #0x4b, lsl #24
    1a78:      	mvni.4s	v30, #0x80, lsl #24
    1a7c:      	bif.16b	v27, v26, v30
    1a80:      	fadd.4s	v26, v26, v27
    1a84:      	fsub.4s	v26, v26, v27
    1a88:      	fcvtzs.4s	v26, v26
    1a8c:      	scvtf.4s	v27, v26
    1a90:      	fmul.4s	v30, v27, v17
    1a94:      	fadd.4s	v25, v25, v30
    1a98:      	fmul.4s	v27, v27, v16
    1a9c:      	fadd.4s	v25, v25, v27
    1aa0:      	fmul.4s	v27, v25, v7
    1aa4:      	fadd.4s	v27, v27, v6
    1aa8:      	fmul.4s	v27, v25, v27
    1aac:      	fadd.4s	v27, v27, v5
    1ab0:      	fmul.4s	v27, v25, v27
    1ab4:      	fadd.4s	v27, v27, v4
    1ab8:      	fmul.4s	v27, v25, v27
    1abc:      	fadd.4s	v27, v27, v3
    1ac0:      	fmul.4s	v27, v25, v27
    1ac4:      	movi.4s	v30, #0x3f, lsl #24
    1ac8:      	fadd.4s	v27, v27, v30
    1acc:      	fmul.4s	v30, v25, v25
    1ad0:      	fmul.4s	v27, v30, v27
    1ad4:      	fadd.4s	v25, v25, v27
    1ad8:      	fadd.4s	v25, v25, v2
    1adc:      	sshr.4s	v27, v26, #0x1
    1ae0:      	shl.4s	v30, v27, #0x17
    1ae4:      	add.4s	v30, v30, v2
    1ae8:      	fmul.4s	v25, v25, v30
    1aec:      	sub.4s	v26, v26, v27
    1af0:      	shl.4s	v26, v26, #0x17
    1af4:      	add.4s	v26, v26, v2
    1af8:      	fmul.4s	v25, v25, v26
    1afc:      	fcmgt.4s	v26, v1, v21
    1b00:      	fcmgt.4s	v27, v21, v0
    1b04:      	fcmeq.4s	v21, v21, v21
    1b08:      	fadd.4s	v25, v25, v2
    1b0c:      	bit.16b	v25, v2, v26
    1b10:      	ldp	q26, q30, [sp, #0x100]
    1b14:      	bit.16b	v25, v30, v27
    1b18:      	bsl.16b	v21, v25, v26
    1b1c:      	fdiv.4s	v21, v29, v21
    1b20:      	fmul.4s	v21, v9, v21
    1b24:      	stp	q28, q23, [sp, #0x120]
    1b28:      	stp	q22, q24, [sp, #0x140]
    1b2c:      	and	x9, x10, #0x7
    1b30:      	add	x11, sp, #0x120
    1b34:      	ldr	x9, [x11, x9, lsl #3]
    1b38:      	sub	x9, x9, x10
    1b3c:      	add	x8, x8, x9, lsl #2
    1b40:      	fmov	w9, s8
    1b44:      	tbz	w9, #0x0, 0x1b64 <_llm_rows.packet_batch.blocks+0x1344>
    1b48:      	str	s21, [x8]
    1b4c:      	tbnz	w9, #0x1, 0x1b68 <_llm_rows.packet_batch.blocks+0x1348>
    1b50:      	tbz	w9, #0x2, 0x1b74 <_llm_rows.packet_batch.blocks+0x1354>
    1b54:      	add	x10, x8, #0x8
    1b58:      	st1.s	{ v21 }[2], [x10]
    1b5c:      	tbnz	w9, #0x3, 0x1b78 <_llm_rows.packet_batch.blocks+0x1358>
    1b60:      	b	0x1b80 <_llm_rows.packet_batch.blocks+0x1360>
    1b64:      	tbz	w9, #0x1, 0x1b50 <_llm_rows.packet_batch.blocks+0x1330>
    1b68:      	add	x10, x8, #0x4
    1b6c:      	st1.s	{ v21 }[1], [x10]
    1b70:      	tbnz	w9, #0x2, 0x1b54 <_llm_rows.packet_batch.blocks+0x1334>
    1b74:      	tbz	w9, #0x3, 0x1b80 <_llm_rows.packet_batch.blocks+0x1360>
    1b78:      	add	x10, x8, #0xc
    1b7c:      	st1.s	{ v21 }[3], [x10]
    1b80:      	fneg.4s	v21, v19
    1b84:      	zip2.8b	v20, v20, v0
    1b88:      	ushll.4s	v20, v20, #0x0
    1b8c:      	shl.4s	v20, v20, #0x1f
    1b90:      	cmlt.4s	v20, v20, #0
    1b94:      	and.16b	v20, v20, v21
    1b98:      	fcmge.4s	v21, v20, v1
    1b9c:      	fcmge.4s	v22, v0, v20
    1ba0:      	and.16b	v21, v21, v22
    1ba4:      	and.16b	v21, v21, v20
    1ba8:      	fmul.4s	v18, v21, v18
    1bac:      	movi.4s	v22, #0x4b, lsl #24
    1bb0:      	mvni.4s	v23, #0x80, lsl #24
    1bb4:      	bif.16b	v22, v18, v23
    1bb8:      	fadd.4s	v18, v18, v22
    1bbc:      	fsub.4s	v18, v18, v22
    1bc0:      	fcvtzs.4s	v18, v18
    1bc4:      	scvtf.4s	v22, v18
    1bc8:      	fmul.4s	v17, v22, v17
    1bcc:      	fadd.4s	v17, v21, v17
    1bd0:      	fmul.4s	v16, v22, v16
    1bd4:      	fadd.4s	v16, v17, v16
    1bd8:      	fmul.4s	v7, v16, v7
    1bdc:      	fadd.4s	v6, v7, v6
    1be0:      	fmul.4s	v6, v16, v6
    1be4:      	fadd.4s	v5, v6, v5
    1be8:      	fmul.4s	v5, v16, v5
    1bec:      	fadd.4s	v4, v5, v4
    1bf0:      	fmul.4s	v4, v16, v4
    1bf4:      	fadd.4s	v3, v4, v3
    1bf8:      	fmul.4s	v3, v16, v3
    1bfc:      	movi.4s	v4, #0x3f, lsl #24
    1c00:      	fadd.4s	v3, v3, v4
    1c04:      	fmul.4s	v4, v16, v16
    1c08:      	fmul.4s	v3, v4, v3
    1c0c:      	fadd.4s	v3, v16, v3
    1c10:      	fadd.4s	v3, v3, v2
    1c14:      	sshr.4s	v4, v18, #0x1
    1c18:      	shl.4s	v5, v4, #0x17
    1c1c:      	add.4s	v5, v5, v2
    1c20:      	fmul.4s	v3, v3, v5
    1c24:      	sub.4s	v4, v18, v4
    1c28:      	shl.4s	v4, v4, #0x17
    1c2c:      	add.4s	v4, v4, v2
    1c30:      	fmul.4s	v3, v3, v4
    1c34:      	fcmgt.4s	v1, v1, v20
    1c38:      	fcmgt.4s	v0, v20, v0
    1c3c:      	fcmeq.4s	v4, v20, v20
    1c40:      	fadd.4s	v3, v3, v2
    1c44:      	bsl.16b	v1, v2, v3
    1c48:      	ldr	q2, [sp, #0x110]
    1c4c:      	bsl.16b	v0, v2, v1
    1c50:      	ldr	q1, [sp, #0x100]
    1c54:      	bif.16b	v0, v1, v4
    1c58:      	fdiv.4s	v0, v19, v0
    1c5c:      	fmul.4s	v0, v31, v0
    1c60:      	tbnz	w9, #0x4, 0x186c <_llm_rows.packet_batch.blocks+0x104c>
    1c64:      	tbz	w9, #0x5, 0x1874 <_llm_rows.packet_batch.blocks+0x1054>
    1c68:      	add	x10, x8, #0x14
    1c6c:      	st1.s	{ v0 }[1], [x10]
    1c70:      	tbnz	w9, #0x6, 0x1878 <_llm_rows.packet_batch.blocks+0x1058>
    1c74:      	tbz	w9, #0x7, 0x8f0 <_llm_rows.packet_batch.blocks+0xd0>
    1c78:      	add	x8, x8, #0x1c
    1c7c:      	st1.s	{ v0 }[3], [x8]
    1c80:      	b	0x8f0 <_llm_rows.packet_batch.blocks+0xd0>
    1c84:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    1c88:      	add	sp, sp, #0x2d0
    1c8c:      	ldp	x29, x30, [sp, #0x90]
    1c90:      	ldp	x20, x19, [sp, #0x80]
    1c94:      	ldp	x22, x21, [sp, #0x70]
    1c98:      	ldp	x24, x23, [sp, #0x60]
    1c9c:      	ldp	x26, x25, [sp, #0x50]
    1ca0:      	ldp	x28, x27, [sp, #0x40]
    1ca4:      	ldp	d9, d8, [sp, #0x30]
    1ca8:      	ldp	d11, d10, [sp, #0x20]
    1cac:      	ldp	d13, d12, [sp, #0x10]
    1cb0:      	ldp	d15, d14, [sp], #0xa0
    1cb4:      	ret

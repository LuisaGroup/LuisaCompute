
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/rmsnorm-257x1538/on/object/tile_xir_w8_37873_1788936533967589_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      2c:      	sub	sp, sp, #0x380
      30:      	str	x0, [sp, #0x10]
      34:      	cbz	w3, 0x1704 <ltmp0+0x1704>
      38:      	mov	w25, #0x0               ; =0
      3c:      	ldp	w9, w8, [x2, #0x2c]
      40:      	stp	w8, w9, [sp, #0x2c]
      44:      	add	x19, sp, #0x1, lsl #12  ; =0x1000
      48:      	add	x19, x19, #0xb60
      4c:      	add	x24, sp, #0x340
      50:      	ldp	w8, w9, [x2]
      54:      	ldp	w10, w11, [x2, #0x8]
      58:      	str	x2, [sp, #0x8]
      5c:      	str	x11, [sp, #0x20]
      60:      	movi	d8, #0000000000000000
      64:      	str	w3, [sp, #0x34]
      68:      	b	0xac <ltmp0+0xac>
      6c:      	ldr	w25, [sp, #0x4c]
      70:      	add	w8, w26, #0x1
      74:      	ldp	w11, w9, [sp, #0x2c]
      78:      	cmp	w8, w9
      7c:      	cset	w9, eq
      80:      	csinc	w8, wzr, w26, eq
      84:      	ldp	w13, w12, [sp, #0x38]
      88:      	cinc	w10, w13, eq
      8c:      	cmp	w10, w11
      90:      	cset	w11, eq
      94:      	ands	w11, w9, w11
      98:      	csel	w9, wzr, w10, ne
      9c:      	add	w10, w12, w11
      a0:      	add	w25, w25, #0x1
      a4:      	cmp	w25, w27
      a8:      	b.eq	0x16f0 <ltmp0+0x16f0>
      ac:      	str	w10, [sp, #0x3c]
      b0:      	mov	x13, x9
      b4:      	mov	x14, x8
      b8:      	ubfiz	x8, x8, #5, #32
      bc:      	ldr	x12, [sp, #0x20]
      c0:      	cmp	x8, x12
      c4:      	csel	x9, x8, xzr, ls
      c8:      	subs	x10, x12, x9
      cc:      	cmp	x10, #0x20
      d0:      	mov	w11, #0x20              ; =32
      d4:      	csel	x10, x10, x11, lo
      d8:      	cmp	x12, x9
      dc:      	ccmp	x8, x12, #0x2, hi
      e0:      	csel	x9, x10, xzr, ls
      e4:      	cmp	x9, #0x20
      e8:      	str	x14, [sp, #0x40]
      ec:      	str	w25, [sp, #0x4c]
      f0:      	str	w13, [sp, #0x38]
      f4:      	b.lo	0x8ec <ltmp0+0x8ec>
      f8:      	ldr	x8, [sp, #0x10]
      fc:      	ldr	x27, [x8]
     100:      	ldr	x22, [x8, #0x10]
     104:      	ldr	x28, [x8, #0x30]
     108:      	ubfiz	w20, w14, #2, #27
     10c:      	mov	w21, #0x1808            ; =6152
     110:      	umull	x23, w20, w21
     114:      	umaddl	x1, w20, w21, x27
     118:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     11c:      	add	x0, x0, #0xb60
     120:      	mov	w2, #0x1800             ; =6144
     124:      	bl	0x124 <ltmp0+0x124>
     128:      	mov	x8, #0x0                ; =0
     12c:      	mov	w9, #0x1800             ; =6144
     130:      	umaddl	x21, w20, w21, x9
     134:      	add	x9, x27, x21
     138:      	ldr	s0, [x9], #0x4
     13c:      	ld1.s	{ v0 }[1], [x9]
     140:      	str	q0, [sp, #0xe0]
     144:      	str	q0, [sp, #0x3360]
     148:      	ldr	q0, [sp, #0x1b60]
     14c:      	ldr	q1, [sp, #0x1b70]
     150:      	fmul.4s	v2, v1, v1
     154:      	fmul.4s	v3, v0, v0
     158:      	ldr	q0, [sp, #0x1b80]
     15c:      	ldr	q1, [sp, #0x1b90]
     160:      	fmul.4s	v5, v1, v1
     164:      	fmul.4s	v4, v0, v0
     168:      	ldr	q0, [sp, #0x1ba0]
     16c:      	ldr	q1, [sp, #0x1bb0]
     170:      	fmul.4s	v6, v1, v1
     174:      	fmul.4s	v7, v0, v0
     178:      	ldr	q0, [sp, #0x1bc0]
     17c:      	ldr	q1, [sp, #0x1bd0]
     180:      	fmul.4s	v17, v1, v1
     184:      	fmul.4s	v16, v0, v0
     188:      	add	x9, x19, x8, lsl #5
     18c:      	ldp	q1, q0, [x9, #0x80]
     190:      	fmul.4s	v1, v1, v1
     194:      	fmul.4s	v0, v0, v0
     198:      	fadd.4s	v2, v2, v0
     19c:      	fadd.4s	v3, v3, v1
     1a0:      	ldp	q1, q0, [x9, #0xa0]
     1a4:      	fmul.4s	v1, v1, v1
     1a8:      	fmul.4s	v0, v0, v0
     1ac:      	fadd.4s	v5, v5, v0
     1b0:      	fadd.4s	v4, v4, v1
     1b4:      	ldp	q1, q0, [x9, #0xc0]
     1b8:      	fmul.4s	v1, v1, v1
     1bc:      	fmul.4s	v0, v0, v0
     1c0:      	fadd.4s	v6, v6, v0
     1c4:      	fadd.4s	v7, v7, v1
     1c8:      	ldp	q1, q0, [x9, #0xe0]
     1cc:      	fmul.4s	v1, v1, v1
     1d0:      	fmul.4s	v0, v0, v0
     1d4:      	fadd.4s	v17, v17, v0
     1d8:      	fadd.4s	v16, v16, v1
     1dc:      	add	x8, x8, #0x4
     1e0:      	cmp	x8, #0xbc
     1e4:      	b.lo	0x188 <ltmp0+0x188>
     1e8:      	add	x0, sp, #0x340
     1ec:      	mov	x1, x22
     1f0:      	mov	w2, #0x1800             ; =6144
     1f4:      	stp	q5, q2, [sp, #0x70]
     1f8:      	str	q3, [sp, #0x60]
     1fc:      	stp	q7, q4, [sp, #0x90]
     200:      	stp	q6, q16, [sp, #0xc0]
     204:      	str	q17, [sp, #0xb0]
     208:      	bl	0x208 <ltmp0+0x208>
     20c:      	mov	x8, #0x0                ; =0
     210:      	ldr	q7, [sp, #0xe0]
     214:      	fmul.4s	v0, v7, v7
     218:      	ldp	q1, q2, [sp, #0x60]
     21c:      	fadd.4s	v0, v0, v1
     220:      	mov.d	v0[1], v1[1]
     224:      	ldr	q1, [sp, #0x80]
     228:      	fadd.4s	v1, v2, v1
     22c:      	ldp	q2, q3, [sp, #0x90]
     230:      	fadd.4s	v0, v3, v0
     234:      	fadd.4s	v0, v2, v0
     238:      	ldp	q2, q3, [sp, #0xb0]
     23c:      	fadd.4s	v1, v3, v1
     240:      	fadd.4s	v1, v2, v1
     244:      	ldr	q2, [sp, #0xd0]
     248:      	fadd.4s	v0, v2, v0
     24c:      	rev64.4s	v2, v0
     250:      	rev64.4s	v3, v1
     254:      	fadd.4s	v1, v1, v3
     258:      	fadd.4s	v0, v0, v2
     25c:      	dup.4s	v2, v0[2]
     260:      	dup.4s	v3, v1[2]
     264:      	fadd.4s	v1, v1, v3
     268:      	fadd.4s	v0, v0, v2
     26c:      	fadd.4s	v0, v0, v1
     270:      	fadd	s0, s0, s8
     274:      	mov	w9, #0x4000             ; =16384
     278:      	movk	w9, #0x44c0, lsl #16
     27c:      	fmov	s1, w9
     280:      	fdiv	s1, s0, s1
     284:      	mov	w9, #0x1804             ; =6148
     288:      	add	x9, x22, x9
     28c:      	ldr	s0, [x22, #0x1800]
     290:      	ld1.s	{ v0 }[1], [x9]
     294:      	mov	w9, #0x1800             ; =6144
     298:      	add	x25, x22, x9
     29c:      	str	q0, [sp, #0x1b40]
     2a0:      	mov	w9, #0xc5ac             ; =50604
     2a4:      	movk	w9, #0x3727, lsl #16
     2a8:      	fmov	s2, w9
     2ac:      	fadd	s1, s1, s2
     2b0:      	fsqrt	s1, s1
     2b4:      	dup.4s	v2, v1[0]
     2b8:      	add	x9, x28, x23
     2bc:      	lsl	x10, x8, #5
     2c0:      	add	x11, x19, x10
     2c4:      	ldp	q3, q4, [x11]
     2c8:      	fdiv.4s	v4, v4, v2
     2cc:      	fdiv.4s	v3, v3, v2
     2d0:      	add	x11, x24, x10
     2d4:      	ldp	q6, q5, [x11]
     2d8:      	fmul.4s	v3, v3, v6
     2dc:      	fmul.4s	v4, v4, v5
     2e0:      	add	x10, x9, x10
     2e4:      	stp	q3, q4, [x10]
     2e8:      	add	x8, x8, #0x1
     2ec:      	cmp	x8, #0xc0
     2f0:      	b.ne	0x2bc <ltmp0+0x2bc>
     2f4:      	dup.2s	v1, v1[0]
     2f8:      	fdiv.2s	v1, v7, v1
     2fc:      	fmul.2s	v0, v1, v0
     300:      	str	d0, [x28, x21]
     304:      	orr	w21, w20, #0x1
     308:      	mov	w26, #0x1808            ; =6152
     30c:      	umull	x23, w21, w26
     310:      	umaddl	x1, w21, w26, x27
     314:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     318:      	add	x0, x0, #0xb60
     31c:      	mov	w2, #0x1800             ; =6144
     320:      	bl	0x320 <ltmp0+0x320>
     324:      	mov	x8, #0x0                ; =0
     328:      	mov	w9, #0x1800             ; =6144
     32c:      	umaddl	x21, w21, w26, x9
     330:      	add	x9, x27, x21
     334:      	ldr	s0, [x9], #0x4
     338:      	ld1.s	{ v0 }[1], [x9]
     33c:      	str	q0, [sp, #0xe0]
     340:      	str	q0, [sp, #0x3360]
     344:      	ldr	q0, [sp, #0x1b60]
     348:      	ldr	q1, [sp, #0x1b70]
     34c:      	fmul.4s	v2, v1, v1
     350:      	fmul.4s	v17, v0, v0
     354:      	ldr	q0, [sp, #0x1b80]
     358:      	ldr	q1, [sp, #0x1b90]
     35c:      	fmul.4s	v4, v1, v1
     360:      	fmul.4s	v3, v0, v0
     364:      	ldr	q0, [sp, #0x1ba0]
     368:      	ldr	q1, [sp, #0x1bb0]
     36c:      	fmul.4s	v5, v1, v1
     370:      	fmul.4s	v6, v0, v0
     374:      	ldr	q0, [sp, #0x1bc0]
     378:      	ldr	q1, [sp, #0x1bd0]
     37c:      	fmul.4s	v16, v1, v1
     380:      	fmul.4s	v7, v0, v0
     384:      	add	x9, x19, x8, lsl #5
     388:      	ldp	q1, q0, [x9, #0x80]
     38c:      	fmul.4s	v1, v1, v1
     390:      	fmul.4s	v0, v0, v0
     394:      	fadd.4s	v2, v2, v0
     398:      	fadd.4s	v17, v17, v1
     39c:      	ldp	q1, q0, [x9, #0xa0]
     3a0:      	fmul.4s	v1, v1, v1
     3a4:      	fmul.4s	v0, v0, v0
     3a8:      	fadd.4s	v4, v4, v0
     3ac:      	fadd.4s	v3, v3, v1
     3b0:      	ldp	q1, q0, [x9, #0xc0]
     3b4:      	fmul.4s	v1, v1, v1
     3b8:      	fmul.4s	v0, v0, v0
     3bc:      	fadd.4s	v5, v5, v0
     3c0:      	fadd.4s	v6, v6, v1
     3c4:      	ldp	q1, q0, [x9, #0xe0]
     3c8:      	fmul.4s	v1, v1, v1
     3cc:      	fmul.4s	v0, v0, v0
     3d0:      	fadd.4s	v16, v16, v0
     3d4:      	fadd.4s	v7, v7, v1
     3d8:      	add	x8, x8, #0x4
     3dc:      	cmp	x8, #0xbc
     3e0:      	b.lo	0x384 <ltmp0+0x384>
     3e4:      	add	x0, sp, #0x340
     3e8:      	mov	x1, x22
     3ec:      	mov	w2, #0x1800             ; =6144
     3f0:      	stp	q4, q2, [sp, #0x70]
     3f4:      	stp	q6, q3, [sp, #0x90]
     3f8:      	stp	q5, q7, [sp, #0xc0]
     3fc:      	str	q16, [sp, #0xb0]
     400:      	str	q17, [sp, #0x60]
     404:      	bl	0x404 <ltmp0+0x404>
     408:      	mov	x8, #0x0                ; =0
     40c:      	ldr	q7, [sp, #0xe0]
     410:      	fmul.4s	v0, v7, v7
     414:      	ldp	q2, q3, [sp, #0x60]
     418:      	fadd.4s	v1, v0, v2
     41c:      	mov.d	v1[1], v2[1]
     420:      	mov	w9, #0x1804             ; =6148
     424:      	add	x9, x22, x9
     428:      	ldr	s0, [x25]
     42c:      	ld1.s	{ v0 }[1], [x9]
     430:      	ldr	q2, [sp, #0x80]
     434:      	fadd.4s	v2, v3, v2
     438:      	ldp	q3, q4, [sp, #0x90]
     43c:      	fadd.4s	v1, v4, v1
     440:      	fadd.4s	v1, v3, v1
     444:      	ldp	q3, q4, [sp, #0xb0]
     448:      	fadd.4s	v2, v4, v2
     44c:      	fadd.4s	v2, v3, v2
     450:      	ldr	q3, [sp, #0xd0]
     454:      	fadd.4s	v1, v3, v1
     458:      	rev64.4s	v3, v1
     45c:      	rev64.4s	v4, v2
     460:      	fadd.4s	v2, v2, v4
     464:      	fadd.4s	v1, v1, v3
     468:      	dup.4s	v3, v1[2]
     46c:      	dup.4s	v4, v2[2]
     470:      	fadd.4s	v2, v2, v4
     474:      	fadd.4s	v1, v1, v3
     478:      	fadd.4s	v1, v1, v2
     47c:      	fadd	s1, s1, s8
     480:      	mov	w9, #0x4000             ; =16384
     484:      	movk	w9, #0x44c0, lsl #16
     488:      	fmov	s2, w9
     48c:      	fdiv	s1, s1, s2
     490:      	str	q0, [sp, #0x1b40]
     494:      	mov	w9, #0xc5ac             ; =50604
     498:      	movk	w9, #0x3727, lsl #16
     49c:      	fmov	s2, w9
     4a0:      	fadd	s1, s1, s2
     4a4:      	fsqrt	s1, s1
     4a8:      	dup.4s	v2, v1[0]
     4ac:      	add	x9, x28, x23
     4b0:      	lsl	x10, x8, #5
     4b4:      	add	x11, x19, x10
     4b8:      	ldp	q3, q4, [x11]
     4bc:      	fdiv.4s	v4, v4, v2
     4c0:      	fdiv.4s	v3, v3, v2
     4c4:      	add	x11, x24, x10
     4c8:      	ldp	q6, q5, [x11]
     4cc:      	fmul.4s	v3, v3, v6
     4d0:      	fmul.4s	v4, v4, v5
     4d4:      	add	x10, x9, x10
     4d8:      	stp	q3, q4, [x10]
     4dc:      	add	x8, x8, #0x1
     4e0:      	cmp	x8, #0xc0
     4e4:      	b.ne	0x4b0 <ltmp0+0x4b0>
     4e8:      	dup.2s	v1, v1[0]
     4ec:      	fdiv.2s	v1, v7, v1
     4f0:      	fmul.2s	v0, v1, v0
     4f4:      	str	d0, [x28, x21]
     4f8:      	orr	w21, w20, #0x2
     4fc:      	mov	w26, #0x1808            ; =6152
     500:      	umull	x23, w21, w26
     504:      	umaddl	x1, w21, w26, x27
     508:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     50c:      	add	x0, x0, #0xb60
     510:      	mov	w2, #0x1800             ; =6144
     514:      	bl	0x514 <ltmp0+0x514>
     518:      	mov	x8, #0x0                ; =0
     51c:      	mov	w9, #0x1800             ; =6144
     520:      	umaddl	x21, w21, w26, x9
     524:      	add	x9, x27, x21
     528:      	ldr	s0, [x9], #0x4
     52c:      	ld1.s	{ v0 }[1], [x9]
     530:      	str	q0, [sp, #0xe0]
     534:      	str	q0, [sp, #0x3360]
     538:      	ldr	q0, [sp, #0x1b60]
     53c:      	ldr	q1, [sp, #0x1b70]
     540:      	fmul.4s	v2, v1, v1
     544:      	fmul.4s	v17, v0, v0
     548:      	ldr	q0, [sp, #0x1b80]
     54c:      	ldr	q1, [sp, #0x1b90]
     550:      	fmul.4s	v4, v1, v1
     554:      	fmul.4s	v3, v0, v0
     558:      	ldr	q0, [sp, #0x1ba0]
     55c:      	ldr	q1, [sp, #0x1bb0]
     560:      	fmul.4s	v5, v1, v1
     564:      	fmul.4s	v6, v0, v0
     568:      	ldr	q0, [sp, #0x1bc0]
     56c:      	ldr	q1, [sp, #0x1bd0]
     570:      	fmul.4s	v16, v1, v1
     574:      	fmul.4s	v7, v0, v0
     578:      	add	x9, x19, x8, lsl #5
     57c:      	ldp	q1, q0, [x9, #0x80]
     580:      	fmul.4s	v1, v1, v1
     584:      	fmul.4s	v0, v0, v0
     588:      	fadd.4s	v2, v2, v0
     58c:      	fadd.4s	v17, v17, v1
     590:      	ldp	q1, q0, [x9, #0xa0]
     594:      	fmul.4s	v1, v1, v1
     598:      	fmul.4s	v0, v0, v0
     59c:      	fadd.4s	v4, v4, v0
     5a0:      	fadd.4s	v3, v3, v1
     5a4:      	ldp	q1, q0, [x9, #0xc0]
     5a8:      	fmul.4s	v1, v1, v1
     5ac:      	fmul.4s	v0, v0, v0
     5b0:      	fadd.4s	v5, v5, v0
     5b4:      	fadd.4s	v6, v6, v1
     5b8:      	ldp	q1, q0, [x9, #0xe0]
     5bc:      	fmul.4s	v1, v1, v1
     5c0:      	fmul.4s	v0, v0, v0
     5c4:      	fadd.4s	v16, v16, v0
     5c8:      	fadd.4s	v7, v7, v1
     5cc:      	add	x8, x8, #0x4
     5d0:      	cmp	x8, #0xbc
     5d4:      	b.lo	0x578 <ltmp0+0x578>
     5d8:      	add	x0, sp, #0x340
     5dc:      	mov	x1, x22
     5e0:      	mov	w2, #0x1800             ; =6144
     5e4:      	stp	q4, q2, [sp, #0x70]
     5e8:      	stp	q6, q3, [sp, #0x90]
     5ec:      	stp	q5, q7, [sp, #0xc0]
     5f0:      	str	q16, [sp, #0xb0]
     5f4:      	str	q17, [sp, #0x60]
     5f8:      	bl	0x5f8 <ltmp0+0x5f8>
     5fc:      	mov	x8, #0x0                ; =0
     600:      	ldr	q7, [sp, #0xe0]
     604:      	fmul.4s	v0, v7, v7
     608:      	ldp	q2, q3, [sp, #0x60]
     60c:      	fadd.4s	v1, v0, v2
     610:      	mov.d	v1[1], v2[1]
     614:      	mov	w9, #0x1804             ; =6148
     618:      	add	x9, x22, x9
     61c:      	ldr	s0, [x25]
     620:      	ld1.s	{ v0 }[1], [x9]
     624:      	ldr	q2, [sp, #0x80]
     628:      	fadd.4s	v2, v3, v2
     62c:      	ldp	q3, q4, [sp, #0x90]
     630:      	fadd.4s	v1, v4, v1
     634:      	fadd.4s	v1, v3, v1
     638:      	ldp	q3, q4, [sp, #0xb0]
     63c:      	fadd.4s	v2, v4, v2
     640:      	fadd.4s	v2, v3, v2
     644:      	ldr	q3, [sp, #0xd0]
     648:      	fadd.4s	v1, v3, v1
     64c:      	rev64.4s	v3, v1
     650:      	rev64.4s	v4, v2
     654:      	fadd.4s	v2, v2, v4
     658:      	fadd.4s	v1, v1, v3
     65c:      	dup.4s	v3, v1[2]
     660:      	dup.4s	v4, v2[2]
     664:      	fadd.4s	v2, v2, v4
     668:      	fadd.4s	v1, v1, v3
     66c:      	fadd.4s	v1, v1, v2
     670:      	fadd	s1, s1, s8
     674:      	mov	w9, #0x4000             ; =16384
     678:      	movk	w9, #0x44c0, lsl #16
     67c:      	fmov	s2, w9
     680:      	fdiv	s1, s1, s2
     684:      	str	q0, [sp, #0x1b40]
     688:      	mov	w9, #0xc5ac             ; =50604
     68c:      	movk	w9, #0x3727, lsl #16
     690:      	fmov	s2, w9
     694:      	fadd	s1, s1, s2
     698:      	fsqrt	s1, s1
     69c:      	dup.4s	v2, v1[0]
     6a0:      	add	x9, x28, x23
     6a4:      	ldr	x26, [sp, #0x40]
     6a8:      	lsl	x10, x8, #5
     6ac:      	add	x11, x19, x10
     6b0:      	ldp	q3, q4, [x11]
     6b4:      	fdiv.4s	v4, v4, v2
     6b8:      	fdiv.4s	v3, v3, v2
     6bc:      	add	x11, x24, x10
     6c0:      	ldp	q6, q5, [x11]
     6c4:      	fmul.4s	v3, v3, v6
     6c8:      	fmul.4s	v4, v4, v5
     6cc:      	add	x10, x9, x10
     6d0:      	stp	q3, q4, [x10]
     6d4:      	add	x8, x8, #0x1
     6d8:      	cmp	x8, #0xc0
     6dc:      	b.ne	0x6a8 <ltmp0+0x6a8>
     6e0:      	dup.2s	v1, v1[0]
     6e4:      	fdiv.2s	v1, v7, v1
     6e8:      	fmul.2s	v0, v1, v0
     6ec:      	str	d0, [x28, x21]
     6f0:      	orr	w20, w20, #0x3
     6f4:      	mov	w23, #0x1808            ; =6152
     6f8:      	umull	x21, w20, w23
     6fc:      	umaddl	x1, w20, w23, x27
     700:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     704:      	add	x0, x0, #0xb60
     708:      	mov	w2, #0x1800             ; =6144
     70c:      	bl	0x70c <ltmp0+0x70c>
     710:      	mov	x8, #0x0                ; =0
     714:      	mov	w9, #0x1800             ; =6144
     718:      	umaddl	x20, w20, w23, x9
     71c:      	add	x9, x27, x20
     720:      	ldr	s0, [x9], #0x4
     724:      	ld1.s	{ v0 }[1], [x9]
     728:      	str	q0, [sp, #0xe0]
     72c:      	str	q0, [sp, #0x3360]
     730:      	ldr	q0, [sp, #0x1b60]
     734:      	ldr	q1, [sp, #0x1b70]
     738:      	fmul.4s	v2, v1, v1
     73c:      	fmul.4s	v17, v0, v0
     740:      	ldr	q0, [sp, #0x1b80]
     744:      	ldr	q1, [sp, #0x1b90]
     748:      	fmul.4s	v4, v1, v1
     74c:      	fmul.4s	v3, v0, v0
     750:      	ldr	q0, [sp, #0x1ba0]
     754:      	ldr	q1, [sp, #0x1bb0]
     758:      	fmul.4s	v5, v1, v1
     75c:      	fmul.4s	v6, v0, v0
     760:      	ldr	q0, [sp, #0x1bc0]
     764:      	ldr	q1, [sp, #0x1bd0]
     768:      	fmul.4s	v16, v1, v1
     76c:      	fmul.4s	v7, v0, v0
     770:      	add	x9, x19, x8, lsl #5
     774:      	ldp	q1, q0, [x9, #0x80]
     778:      	fmul.4s	v1, v1, v1
     77c:      	fmul.4s	v0, v0, v0
     780:      	fadd.4s	v2, v2, v0
     784:      	fadd.4s	v17, v17, v1
     788:      	ldp	q1, q0, [x9, #0xa0]
     78c:      	fmul.4s	v1, v1, v1
     790:      	fmul.4s	v0, v0, v0
     794:      	fadd.4s	v4, v4, v0
     798:      	fadd.4s	v3, v3, v1
     79c:      	ldp	q1, q0, [x9, #0xc0]
     7a0:      	fmul.4s	v1, v1, v1
     7a4:      	fmul.4s	v0, v0, v0
     7a8:      	fadd.4s	v5, v5, v0
     7ac:      	fadd.4s	v6, v6, v1
     7b0:      	ldp	q1, q0, [x9, #0xe0]
     7b4:      	fmul.4s	v1, v1, v1
     7b8:      	fmul.4s	v0, v0, v0
     7bc:      	fadd.4s	v16, v16, v0
     7c0:      	fadd.4s	v7, v7, v1
     7c4:      	add	x8, x8, #0x4
     7c8:      	cmp	x8, #0xbc
     7cc:      	b.lo	0x770 <ltmp0+0x770>
     7d0:      	add	x0, sp, #0x340
     7d4:      	mov	x1, x22
     7d8:      	mov	w2, #0x1800             ; =6144
     7dc:      	stp	q4, q2, [sp, #0x70]
     7e0:      	stp	q6, q3, [sp, #0x90]
     7e4:      	stp	q5, q7, [sp, #0xc0]
     7e8:      	str	q16, [sp, #0xb0]
     7ec:      	str	q17, [sp, #0x60]
     7f0:      	bl	0x7f0 <ltmp0+0x7f0>
     7f4:      	mov	x8, #0x0                ; =0
     7f8:      	ldr	q7, [sp, #0xe0]
     7fc:      	fmul.4s	v0, v7, v7
     800:      	ldp	q2, q3, [sp, #0x60]
     804:      	fadd.4s	v1, v0, v2
     808:      	mov.d	v1[1], v2[1]
     80c:      	ldr	s0, [x25]
     810:      	ldr	q2, [sp, #0x80]
     814:      	fadd.4s	v2, v3, v2
     818:      	ldp	q3, q4, [sp, #0x90]
     81c:      	fadd.4s	v1, v4, v1
     820:      	fadd.4s	v1, v3, v1
     824:      	ldp	q3, q4, [sp, #0xb0]
     828:      	fadd.4s	v2, v4, v2
     82c:      	fadd.4s	v2, v3, v2
     830:      	ldr	q3, [sp, #0xd0]
     834:      	fadd.4s	v1, v3, v1
     838:      	rev64.4s	v3, v1
     83c:      	rev64.4s	v4, v2
     840:      	fadd.4s	v2, v2, v4
     844:      	fadd.4s	v1, v1, v3
     848:      	dup.4s	v3, v1[2]
     84c:      	dup.4s	v4, v2[2]
     850:      	fadd.4s	v2, v2, v4
     854:      	fadd.4s	v1, v1, v3
     858:      	fadd.4s	v1, v1, v2
     85c:      	fadd	s1, s1, s8
     860:      	mov	w9, #0x4000             ; =16384
     864:      	movk	w9, #0x44c0, lsl #16
     868:      	fmov	s2, w9
     86c:      	fdiv	s1, s1, s2
     870:      	mov	w9, #0x1804             ; =6148
     874:      	add	x9, x22, x9
     878:      	ld1.s	{ v0 }[1], [x9]
     87c:      	str	q0, [sp, #0x1b40]
     880:      	mov	w9, #0xc5ac             ; =50604
     884:      	movk	w9, #0x3727, lsl #16
     888:      	fmov	s2, w9
     88c:      	fadd	s1, s1, s2
     890:      	fsqrt	s1, s1
     894:      	dup.4s	v2, v1[0]
     898:      	add	x9, x28, x21
     89c:      	ldr	w27, [sp, #0x34]
     8a0:      	lsl	x10, x8, #5
     8a4:      	add	x11, x19, x10
     8a8:      	ldp	q3, q4, [x11]
     8ac:      	fdiv.4s	v4, v4, v2
     8b0:      	fdiv.4s	v3, v3, v2
     8b4:      	add	x11, x24, x10
     8b8:      	ldp	q6, q5, [x11]
     8bc:      	fmul.4s	v3, v3, v6
     8c0:      	fmul.4s	v4, v4, v5
     8c4:      	add	x10, x9, x10
     8c8:      	stp	q3, q4, [x10]
     8cc:      	add	x8, x8, #0x1
     8d0:      	cmp	x8, #0xc0
     8d4:      	b.ne	0x8a0 <ltmp0+0x8a0>
     8d8:      	dup.2s	v1, v1[0]
     8dc:      	fdiv.2s	v1, v7, v1
     8e0:      	fmul.2s	v0, v1, v0
     8e4:      	str	d0, [x28, x20]
     8e8:      	b	0x6c <ltmp0+0x6c>
     8ec:      	lsr	x8, x9, #3
     8f0:      	str	x8, [sp, #0x58]
     8f4:      	str	x9, [sp, #0x18]
     8f8:      	cmp	x9, #0x8
     8fc:      	mov	w9, #0x1808             ; =6152
     900:      	b.lo	0xb44 <ltmp0+0xb44>
     904:      	mov	x27, #0x0               ; =0
     908:      	ldr	x8, [sp, #0x10]
     90c:      	ldr	x28, [x8]
     910:      	ldr	x22, [x8, #0x10]
     914:      	ldr	x21, [x8, #0x30]
     918:      	mov	w8, #0x1800             ; =6144
     91c:      	add	x8, x22, x8
     920:      	str	x8, [sp, #0x50]
     924:      	ldr	x8, [sp, #0x40]
     928:      	lsl	w25, w8, #2
     92c:      	and	x8, x8, #0x7ffffff
     930:      	mov	w10, #0x6020            ; =24608
     934:      	umaddl	x26, w8, w10, x21
     938:      	add	w8, w27, w25
     93c:      	and	x20, x8, #0x1fffffff
     940:      	umaddl	x1, w20, w9, x28
     944:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     948:      	add	x0, x0, #0xb60
     94c:      	mov	w2, #0x1800             ; =6144
     950:      	mov	w23, #0x1808            ; =6152
     954:      	bl	0x954 <ltmp0+0x954>
     958:      	mov	x8, #0x0                ; =0
     95c:      	mov	w9, #0x1800             ; =6144
     960:      	umaddl	x20, w20, w23, x9
     964:      	add	x9, x28, x20
     968:      	ldr	s0, [x9], #0x4
     96c:      	ld1.s	{ v0 }[1], [x9]
     970:      	str	q0, [sp, #0xe0]
     974:      	str	q0, [sp, #0x3360]
     978:      	ldr	q0, [sp, #0x1b60]
     97c:      	ldr	q1, [sp, #0x1b70]
     980:      	fmul.4s	v2, v1, v1
     984:      	fmul.4s	v17, v0, v0
     988:      	ldr	q0, [sp, #0x1b80]
     98c:      	ldr	q1, [sp, #0x1b90]
     990:      	fmul.4s	v4, v1, v1
     994:      	fmul.4s	v3, v0, v0
     998:      	ldr	q0, [sp, #0x1ba0]
     99c:      	ldr	q1, [sp, #0x1bb0]
     9a0:      	fmul.4s	v5, v1, v1
     9a4:      	fmul.4s	v6, v0, v0
     9a8:      	ldr	q0, [sp, #0x1bc0]
     9ac:      	ldr	q1, [sp, #0x1bd0]
     9b0:      	fmul.4s	v16, v1, v1
     9b4:      	fmul.4s	v7, v0, v0
     9b8:      	add	x9, x19, x8, lsl #5
     9bc:      	ldp	q1, q0, [x9, #0x80]
     9c0:      	fmul.4s	v1, v1, v1
     9c4:      	fmul.4s	v0, v0, v0
     9c8:      	fadd.4s	v2, v2, v0
     9cc:      	fadd.4s	v17, v17, v1
     9d0:      	ldp	q1, q0, [x9, #0xa0]
     9d4:      	fmul.4s	v1, v1, v1
     9d8:      	fmul.4s	v0, v0, v0
     9dc:      	fadd.4s	v4, v4, v0
     9e0:      	fadd.4s	v3, v3, v1
     9e4:      	ldp	q1, q0, [x9, #0xc0]
     9e8:      	fmul.4s	v1, v1, v1
     9ec:      	fmul.4s	v0, v0, v0
     9f0:      	fadd.4s	v5, v5, v0
     9f4:      	fadd.4s	v6, v6, v1
     9f8:      	ldp	q1, q0, [x9, #0xe0]
     9fc:      	fmul.4s	v1, v1, v1
     a00:      	fmul.4s	v0, v0, v0
     a04:      	fadd.4s	v16, v16, v0
     a08:      	fadd.4s	v7, v7, v1
     a0c:      	add	x8, x8, #0x4
     a10:      	cmp	x8, #0xbc
     a14:      	b.lo	0x9b8 <ltmp0+0x9b8>
     a18:      	add	x0, sp, #0x340
     a1c:      	mov	x1, x22
     a20:      	mov	w2, #0x1800             ; =6144
     a24:      	stp	q4, q2, [sp, #0x70]
     a28:      	stp	q6, q3, [sp, #0x90]
     a2c:      	stp	q5, q7, [sp, #0xc0]
     a30:      	str	q16, [sp, #0xb0]
     a34:      	str	q17, [sp, #0x60]
     a38:      	bl	0xa38 <ltmp0+0xa38>
     a3c:      	mov	x8, #0x0                ; =0
     a40:      	ldr	q7, [sp, #0xe0]
     a44:      	fmul.4s	v0, v7, v7
     a48:      	ldp	q2, q3, [sp, #0x60]
     a4c:      	fadd.4s	v1, v0, v2
     a50:      	mov.d	v1[1], v2[1]
     a54:      	mov	w9, #0x1804             ; =6148
     a58:      	add	x9, x22, x9
     a5c:      	ldr	x10, [sp, #0x50]
     a60:      	ldr	s0, [x10]
     a64:      	ld1.s	{ v0 }[1], [x9]
     a68:      	ldr	q2, [sp, #0x80]
     a6c:      	fadd.4s	v2, v3, v2
     a70:      	ldp	q3, q4, [sp, #0x90]
     a74:      	fadd.4s	v1, v4, v1
     a78:      	fadd.4s	v1, v3, v1
     a7c:      	ldp	q3, q4, [sp, #0xb0]
     a80:      	fadd.4s	v2, v4, v2
     a84:      	fadd.4s	v2, v3, v2
     a88:      	ldr	q3, [sp, #0xd0]
     a8c:      	fadd.4s	v1, v3, v1
     a90:      	rev64.4s	v3, v1
     a94:      	rev64.4s	v4, v2
     a98:      	fadd.4s	v2, v2, v4
     a9c:      	fadd.4s	v1, v1, v3
     aa0:      	dup.4s	v3, v1[2]
     aa4:      	dup.4s	v4, v2[2]
     aa8:      	fadd.4s	v2, v2, v4
     aac:      	fadd.4s	v1, v1, v3
     ab0:      	fadd.4s	v1, v1, v2
     ab4:      	fadd	s1, s1, s8
     ab8:      	mov	w9, #0x4000             ; =16384
     abc:      	movk	w9, #0x44c0, lsl #16
     ac0:      	fmov	s2, w9
     ac4:      	fdiv	s1, s1, s2
     ac8:      	str	q0, [sp, #0x1b40]
     acc:      	mov	w9, #0xc5ac             ; =50604
     ad0:      	movk	w9, #0x3727, lsl #16
     ad4:      	fmov	s2, w9
     ad8:      	fadd	s1, s1, s2
     adc:      	fsqrt	s1, s1
     ae0:      	dup.4s	v2, v1[0]
     ae4:      	lsl	x9, x8, #5
     ae8:      	add	x10, x19, x9
     aec:      	ldp	q3, q4, [x10]
     af0:      	fdiv.4s	v4, v4, v2
     af4:      	fdiv.4s	v3, v3, v2
     af8:      	add	x10, x24, x9
     afc:      	ldp	q6, q5, [x10]
     b00:      	fmul.4s	v3, v3, v6
     b04:      	fmul.4s	v4, v4, v5
     b08:      	add	x9, x26, x9
     b0c:      	stp	q3, q4, [x9]
     b10:      	add	x8, x8, #0x1
     b14:      	cmp	x8, #0xc0
     b18:      	b.ne	0xae4 <ltmp0+0xae4>
     b1c:      	dup.2s	v1, v1[0]
     b20:      	fdiv.2s	v1, v7, v1
     b24:      	fmul.2s	v0, v1, v0
     b28:      	str	d0, [x21, x20]
     b2c:      	add	x27, x27, #0x1
     b30:      	mov	w9, #0x1808             ; =6152
     b34:      	add	x26, x26, x9
     b38:      	ldr	x8, [sp, #0x58]
     b3c:      	cmp	x27, x8
     b40:      	b.ne	0x938 <ltmp0+0x938>
     b44:      	mov	w15, #0x1808            ; =6152
     b48:      	ldr	x8, [sp, #0x18]
     b4c:      	and	w8, w8, #0x7
     b50:      	ldr	w27, [sp, #0x34]
     b54:      	ldr	w25, [sp, #0x4c]
     b58:      	ldr	x26, [sp, #0x40]
     b5c:      	cbz	w8, 0x70 <ltmp0+0x70>
     b60:      	dup.4s	v1, w8
     b64:      	adrp	x8, 0x0 <ltmp0>
     b68:      	ldr	q2, [x8]
     b6c:      	adrp	x8, 0x0 <ltmp0>
     b70:      	ldr	q0, [x8]
     b74:      	cmhi.4s	v0, v1, v0
     b78:      	cmhi.4s	v1, v1, v2
     b7c:      	uzp1.8h	v3, v1, v0
     b80:      	umaxv.8h	h2, v3
     b84:      	fmov	w8, s2
     b88:      	mov	w20, #0x4               ; =4
     b8c:      	tbz	w8, #0x0, 0x6c <ltmp0+0x6c>
     b90:      	mov	x10, #0x0               ; =0
     b94:      	ldr	x8, [sp, #0x10]
     b98:      	ldr	x14, [x8]
     b9c:      	ldr	x11, [x8, #0x10]
     ba0:      	ldr	x8, [x8, #0x30]
     ba4:      	adrp	x9, 0x0 <ltmp0>
     ba8:      	ldr	q2, [x9]
     bac:      	and.16b	v2, v3, v2
     bb0:      	addv.8h	h2, v2
     bb4:      	fmov	w9, s2
     bb8:      	and	w12, w9, #0xff
     bbc:      	xtn.4h	v4, v1
     bc0:      	uzp1.8b	v4, v4, v0
     bc4:      	ubfiz	w9, w26, #2, #27
     bc8:      	ldr	x13, [sp, #0x58]
     bcc:      	orr	w9, w9, w13
     bd0:      	dup.4s	v5, w9
     bd4:      	and.16b	v6, v1, v5
     bd8:      	and.16b	v5, v0, v5
     bdc:      	ushll2.2d	v19, v5, #0x0
     be0:      	ushll2.2d	v20, v6, #0x0
     be4:      	ushll.2d	v21, v5, #0x0
     be8:      	ushll.2d	v5, v6, #0x0
     bec:      	umov.b	w13, v4[0]
     bf0:      	umull	x9, w9, w15
     bf4:      	tst	w13, #0x1
     bf8:      	csel	x9, x9, xzr, ne
     bfc:      	add	x15, x14, x9
     c00:      	b	0xc24 <ltmp0+0xc24>
     c04:      	add	x16, x19, x10, lsl #5
     c08:      	ldp	q7, q16, [x16]
     c0c:      	bif.16b	v6, v16, v0
     c10:      	bif.16b	v4, v7, v1
     c14:      	stp	q4, q6, [x16]
     c18:      	add	x10, x10, #0x1
     c1c:      	cmp	x10, #0xc0
     c20:      	b.eq	0xcbc <ltmp0+0xcbc>
     c24:      	fmov	w17, s2
     c28:      	add	x16, x15, x10, lsl #5
     c2c:      	movi.2d	v4, #0000000000000000
     c30:      	movi.2d	v6, #0000000000000000
     c34:      	tbnz	w17, #0x0, 0xc5c <ltmp0+0xc5c>
     c38:      	and	w17, w17, #0xff
     c3c:      	tbnz	w17, #0x1, 0xc68 <ltmp0+0xc68>
     c40:      	tbnz	w17, #0x2, 0xc74 <ltmp0+0xc74>
     c44:      	tbnz	w17, #0x3, 0xc80 <ltmp0+0xc80>
     c48:      	tbnz	w17, #0x4, 0xc8c <ltmp0+0xc8c>
     c4c:      	tbnz	w17, #0x5, 0xc98 <ltmp0+0xc98>
     c50:      	tbnz	w17, #0x6, 0xca4 <ltmp0+0xca4>
     c54:      	tbz	w17, #0x7, 0xc04 <ltmp0+0xc04>
     c58:      	b	0xcb0 <ltmp0+0xcb0>
     c5c:      	ldr	s4, [x16]
     c60:      	and	w17, w17, #0xff
     c64:      	tbz	w17, #0x1, 0xc40 <ltmp0+0xc40>
     c68:      	add	x0, x16, #0x4
     c6c:      	ld1.s	{ v4 }[1], [x0]
     c70:      	tbz	w17, #0x2, 0xc44 <ltmp0+0xc44>
     c74:      	add	x0, x16, #0x8
     c78:      	ld1.s	{ v4 }[2], [x0]
     c7c:      	tbz	w17, #0x3, 0xc48 <ltmp0+0xc48>
     c80:      	add	x0, x16, #0xc
     c84:      	ld1.s	{ v4 }[3], [x0]
     c88:      	tbz	w17, #0x4, 0xc4c <ltmp0+0xc4c>
     c8c:      	add	x0, x16, #0x10
     c90:      	ld1.s	{ v6 }[0], [x0]
     c94:      	tbz	w17, #0x5, 0xc50 <ltmp0+0xc50>
     c98:      	add	x0, x16, #0x14
     c9c:      	ld1.s	{ v6 }[1], [x0]
     ca0:      	tbz	w17, #0x6, 0xc54 <ltmp0+0xc54>
     ca4:      	add	x0, x16, #0x18
     ca8:      	ld1.s	{ v6 }[2], [x0]
     cac:      	tbz	w17, #0x7, 0xc04 <ltmp0+0xc04>
     cb0:      	add	x16, x16, #0x1c
     cb4:      	ld1.s	{ v6 }[3], [x16]
     cb8:      	b	0xc04 <ltmp0+0xc04>
     cbc:      	xtn.8b	v23, v3
     cc0:      	sshll.2d	v7, v1, #0x0
     cc4:      	movi	d3, #0x0000000000ffff
     cc8:      	and.8b	v6, v23, v3
     ccc:      	adrp	x10, 0x0 <ltmp0>
     cd0:      	ldr	d3, [x10]
     cd4:      	and.8b	v3, v23, v3
     cd8:      	addv.8b	b3, v3
     cdc:      	fmov	w15, s3
     ce0:      	umaxv.8b	b3, v6
     ce4:      	fmov	w10, s3
     ce8:      	rbit	w16, w15
     cec:      	clz	w16, w16
     cf0:      	tst	w10, #0x1
     cf4:      	csel	w10, w16, wzr, ne
     cf8:      	mov	w16, #0x600             ; =1536
     cfc:      	dup.2d	v17, x16
     d00:      	adrp	x16, 0x0 <ltmp0>
     d04:      	ldr	q3, [x16]
     d08:      	str	q3, [sp, #0x80]
     d0c:      	mov.16b	v4, v7
     d10:      	bsl.16b	v4, v3, v17
     d14:      	xtn.2s	v3, v5
     d18:      	mov	w16, #0x602             ; =1538
     d1c:      	dup.2s	v24, w16
     d20:      	umlal.2d	v4, v3, v24
     d24:      	mov	b3, v6[0]
     d28:      	mov.b	v3[4], v6[1]
     d2c:      	ushll.2d	v3, v3, #0x0
     d30:      	shl.2d	v3, v3, #0x3f
     d34:      	cmlt.2d	v3, v3, #0
     d38:      	str	q4, [sp, #0xd0]
     d3c:      	and.16b	v3, v3, v4
     d40:      	movi.2d	v4, #0000000000000000
     d44:      	stp	q4, q4, [sp, #0x310]
     d48:      	stp	q3, q4, [sp, #0x2f0]
     d4c:      	and	x16, x10, #0x7
     d50:      	add	x17, sp, #0x2f0
     d54:      	ldr	x16, [x17, x16, lsl #3]
     d58:      	sub	x16, x16, x10
     d5c:      	add	x14, x14, x16, lsl #2
     d60:      	movi.2d	v3, #0000000000000000
     d64:      	tbnz	w15, #0x0, 0x15e8 <ltmp0+0x15e8>
     d68:      	tbnz	w15, #0x1, 0x15f0 <ltmp0+0x15f0>
     d6c:      	tbnz	w15, #0x2, 0x15fc <ltmp0+0x15fc>
     d70:      	tbnz	w15, #0x3, 0x1608 <ltmp0+0x1608>
     d74:      	tbnz	w15, #0x4, 0x1614 <ltmp0+0x1614>
     d78:      	tbnz	w15, #0x5, 0x1620 <ltmp0+0x1620>
     d7c:      	tbnz	w15, #0x6, 0x162c <ltmp0+0x162c>
     d80:      	tbz	w15, #0x7, 0xd8c <ltmp0+0xd8c>
     d84:      	add	x14, x14, #0x1c
     d88:      	ld1.s	{ v3 }[3], [x14]
     d8c:      	sshll.2d	v16, v0, #0x0
     d90:      	sshll2.2d	v22, v1, #0x0
     d94:      	sshll2.2d	v13, v0, #0x0
     d98:      	adrp	x14, 0x0 <ltmp0>
     d9c:      	ldr	q18, [x14]
     da0:      	and.16b	v18, v13, v18
     da4:      	adrp	x14, 0x0 <ltmp0>
     da8:      	ldr	q25, [x14]
     dac:      	and.16b	v25, v22, v25
     db0:      	adrp	x14, 0x0 <ltmp0>
     db4:      	ldr	q26, [x14]
     db8:      	and.16b	v26, v16, v26
     dbc:      	adrp	x14, 0x0 <ltmp0>
     dc0:      	ldr	q27, [x14]
     dc4:      	and.16b	v27, v7, v27
     dc8:      	adrp	x14, 0x0 <ltmp0>
     dcc:      	ldr	q7, [x14]
     dd0:      	mov.16b	v5, v16
     dd4:      	bsl.16b	v5, v7, v17
     dd8:      	adrp	x14, 0x0 <ltmp0>
     ddc:      	ldr	q16, [x14]
     de0:      	mov.16b	v7, v22
     de4:      	bsl.16b	v7, v16, v17
     de8:      	adrp	x14, 0x0 <ltmp0>
     dec:      	ldr	q28, [x14]
     df0:      	mov.16b	v16, v13
     df4:      	bsl.16b	v16, v28, v17
     df8:      	xtn.2s	v21, v21
     dfc:      	xtn.2s	v20, v20
     e00:      	xtn.2s	v19, v19
     e04:      	umlal.2d	v16, v19, v24
     e08:      	umlal.2d	v7, v20, v24
     e0c:      	stp	q16, q7, [sp, #0x90]
     e10:      	umlal.2d	v5, v21, v24
     e14:      	str	q5, [sp, #0xb0]
     e18:      	sshll.2d	v24, v1, #0x0
     e1c:      	sshll.2d	v21, v0, #0x0
     e20:      	stp	q27, q25, [sp, #0x2b0]
     e24:      	stp	q26, q18, [sp, #0x2d0]
     e28:      	and	x14, x10, #0x7
     e2c:      	add	x16, sp, #0x2b0
     e30:      	ldr	x14, [x16, x14, lsl #3]
     e34:      	orr	x14, x14, #0x1800
     e38:      	sub	x14, x14, x10, lsl #2
     e3c:      	tst	w15, #0xff
     e40:      	csel	x14, xzr, x14, eq
     e44:      	add	x15, x19, x14
     e48:      	ldp	q18, q19, [x15]
     e4c:      	zip2.8b	v20, v6, v0
     e50:      	ushll.4s	v20, v20, #0x0
     e54:      	shl.4s	v20, v20, #0x1f
     e58:      	cmlt.4s	v20, v20, #0
     e5c:      	str	q3, [sp, #0xe0]
     e60:      	bit.16b	v19, v3, v20
     e64:      	zip1.8b	v20, v6, v0
     e68:      	ushll.4s	v20, v20, #0x0
     e6c:      	shl.4s	v20, v20, #0x1f
     e70:      	cmlt.4s	v20, v20, #0
     e74:      	str	q4, [sp, #0xc0]
     e78:      	bit.16b	v18, v4, v20
     e7c:      	stp	q18, q19, [x15]
     e80:      	dup.2d	v18, x20
     e84:      	and.16b	v19, v13, v18
     e88:      	and.16b	v20, v22, v18
     e8c:      	and.16b	v21, v21, v18
     e90:      	and.16b	v18, v24, v18
     e94:      	tst	w13, #0x1
     e98:      	csel	x15, x20, xzr, ne
     e9c:      	ldr	q24, [sp, #0x1bd0]
     ea0:      	ldr	q25, [sp, #0x1bc0]
     ea4:      	fmul.4s	v26, v25, v25
     ea8:      	fmul.4s	v24, v24, v24
     eac:      	and.16b	v25, v0, v24
     eb0:      	and.16b	v24, v1, v26
     eb4:      	ldr	q26, [sp, #0x1bb0]
     eb8:      	ldr	q27, [sp, #0x1ba0]
     ebc:      	fmul.4s	v27, v27, v27
     ec0:      	fmul.4s	v26, v26, v26
     ec4:      	and.16b	v26, v0, v26
     ec8:      	and.16b	v27, v1, v27
     ecc:      	ldr	q28, [sp, #0x1b90]
     ed0:      	ldr	q29, [sp, #0x1b80]
     ed4:      	fmul.4s	v30, v29, v29
     ed8:      	fmul.4s	v28, v28, v28
     edc:      	and.16b	v29, v0, v28
     ee0:      	and.16b	v28, v1, v30
     ee4:      	ldr	q30, [sp, #0x1b70]
     ee8:      	ldr	q31, [sp, #0x1b60]
     eec:      	fmul.4s	v31, v31, v31
     ef0:      	fmul.4s	v30, v30, v30
     ef4:      	and.16b	v30, v0, v30
     ef8:      	and.16b	v31, v1, v31
     efc:      	sshll.2d	v9, v1, #0x0
     f00:      	sshll.2d	v10, v0, #0x0
     f04:      	add	x15, x19, x15, lsl #5
     f08:      	ldp	q12, q11, [x15]
     f0c:      	and.16b	v12, v1, v12
     f10:      	and.16b	v11, v0, v11
     f14:      	fmul.4s	v11, v11, v11
     f18:      	fmul.4s	v12, v12, v12
     f1c:      	fadd.4s	v12, v31, v12
     f20:      	fadd.4s	v11, v30, v11
     f24:      	ldp	q15, q14, [x15, #0x20]
     f28:      	and.16b	v15, v1, v15
     f2c:      	and.16b	v14, v0, v14
     f30:      	fmul.4s	v14, v14, v14
     f34:      	fmul.4s	v15, v15, v15
     f38:      	fadd.4s	v15, v28, v15
     f3c:      	fadd.4s	v14, v29, v14
     f40:      	ldp	q16, q7, [x15, #0x40]
     f44:      	and.16b	v16, v1, v16
     f48:      	and.16b	v7, v0, v7
     f4c:      	fmul.4s	v7, v7, v7
     f50:      	fmul.4s	v16, v16, v16
     f54:      	fadd.4s	v16, v27, v16
     f58:      	fadd.4s	v7, v26, v7
     f5c:      	ldp	q4, q17, [x15, #0x60]
     f60:      	and.16b	v4, v1, v4
     f64:      	and.16b	v17, v0, v17
     f68:      	fmul.4s	v17, v17, v17
     f6c:      	fmul.4s	v4, v4, v4
     f70:      	fadd.4s	v4, v24, v4
     f74:      	fadd.4s	v17, v25, v17
     f78:      	dup.2d	v5, x20
     f7c:      	and.16b	v3, v13, v5
     f80:      	add.2d	v19, v19, v3
     f84:      	and.16b	v3, v22, v5
     f88:      	add.2d	v20, v20, v3
     f8c:      	and.16b	v3, v10, v5
     f90:      	add.2d	v21, v21, v3
     f94:      	and.16b	v3, v9, v5
     f98:      	add.2d	v3, v18, v3
     f9c:      	bit.16b	v30, v11, v0
     fa0:      	bit.16b	v31, v12, v1
     fa4:      	bit.16b	v29, v14, v0
     fa8:      	bit.16b	v28, v15, v1
     fac:      	bit.16b	v26, v7, v0
     fb0:      	bit.16b	v27, v16, v1
     fb4:      	bit.16b	v25, v17, v0
     fb8:      	bit.16b	v24, v4, v1
     fbc:      	fmov	x15, d18
     fc0:      	add	x17, x15, #0x4
     fc4:      	ands	w16, w13, #0x1
     fc8:      	csel	x15, x17, x15, ne
     fcc:      	mov.16b	v18, v3
     fd0:      	cmp	x15, #0xc0
     fd4:      	b.lt	0xefc <ltmp0+0xefc>
     fd8:      	mov	x17, #0x0               ; =0
     fdc:      	ushll2.2d	v3, v0, #0x0
     fe0:      	mov	w15, #0x1               ; =1
     fe4:      	dup.2d	v4, x15
     fe8:      	and.16b	v19, v3, v4
     fec:      	ushll2.2d	v3, v1, #0x0
     ff0:      	and.16b	v20, v3, v4
     ff4:      	ushll.2d	v3, v0, #0x0
     ff8:      	and.16b	v21, v3, v4
     ffc:      	ushll.2d	v3, v1, #0x0
    1000:      	and.16b	v22, v3, v4
    1004:      	movi.2d	v13, #0000000000000000
    1008:      	and	x15, x13, #0x1
    100c:      	movi.2d	v14, #0000000000000000
    1010:      	movi.2d	v15, #0000000000000000
    1014:      	movi.2d	v9, #0000000000000000
    1018:      	b	0x1054 <ltmp0+0x1054>
    101c:      	add	x17, x24, x17
    1020:      	ldp	q3, q4, [x17]
    1024:      	bit.16b	v4, v18, v0
    1028:      	bit.16b	v3, v10, v1
    102c:      	stp	q3, q4, [x17]
    1030:      	add.2d	v3, v13, v22
    1034:      	add.2d	v14, v14, v20
    1038:      	add.2d	v15, v15, v21
    103c:      	add.2d	v9, v9, v19
    1040:      	fmov	x17, d13
    1044:      	add	x17, x17, x15
    1048:      	mov.16b	v13, v3
    104c:      	cmp	x17, #0xc0
    1050:      	b.ge	0x10f0 <ltmp0+0x10f0>
    1054:      	fmov	w1, s2
    1058:      	lsl	x17, x17, #5
    105c:      	add	x0, x11, x17
    1060:      	movi.2d	v10, #0000000000000000
    1064:      	movi.2d	v18, #0000000000000000
    1068:      	tbnz	w1, #0x0, 0x1090 <ltmp0+0x1090>
    106c:      	and	w1, w1, #0xff
    1070:      	tbnz	w1, #0x1, 0x109c <ltmp0+0x109c>
    1074:      	tbnz	w1, #0x2, 0x10a8 <ltmp0+0x10a8>
    1078:      	tbnz	w1, #0x3, 0x10b4 <ltmp0+0x10b4>
    107c:      	tbnz	w1, #0x4, 0x10c0 <ltmp0+0x10c0>
    1080:      	tbnz	w1, #0x5, 0x10cc <ltmp0+0x10cc>
    1084:      	tbnz	w1, #0x6, 0x10d8 <ltmp0+0x10d8>
    1088:      	tbz	w1, #0x7, 0x101c <ltmp0+0x101c>
    108c:      	b	0x10e4 <ltmp0+0x10e4>
    1090:      	ldr	s10, [x0]
    1094:      	and	w1, w1, #0xff
    1098:      	tbz	w1, #0x1, 0x1074 <ltmp0+0x1074>
    109c:      	add	x2, x0, #0x4
    10a0:      	ld1.s	{ v10 }[1], [x2]
    10a4:      	tbz	w1, #0x2, 0x1078 <ltmp0+0x1078>
    10a8:      	add	x2, x0, #0x8
    10ac:      	ld1.s	{ v10 }[2], [x2]
    10b0:      	tbz	w1, #0x3, 0x107c <ltmp0+0x107c>
    10b4:      	add	x2, x0, #0xc
    10b8:      	ld1.s	{ v10 }[3], [x2]
    10bc:      	tbz	w1, #0x4, 0x1080 <ltmp0+0x1080>
    10c0:      	add	x2, x0, #0x10
    10c4:      	ld1.s	{ v18 }[0], [x2]
    10c8:      	tbz	w1, #0x5, 0x1084 <ltmp0+0x1084>
    10cc:      	add	x2, x0, #0x14
    10d0:      	ld1.s	{ v18 }[1], [x2]
    10d4:      	tbz	w1, #0x6, 0x1088 <ltmp0+0x1088>
    10d8:      	add	x2, x0, #0x18
    10dc:      	ld1.s	{ v18 }[2], [x2]
    10e0:      	tbz	w1, #0x7, 0x101c <ltmp0+0x101c>
    10e4:      	add	x0, x0, #0x1c
    10e8:      	ld1.s	{ v18 }[3], [x0]
    10ec:      	b	0x101c <ltmp0+0x101c>
    10f0:      	movi	d3, #0xffffffffffff0000
    10f4:      	and.8b	v3, v23, v3
    10f8:      	ldr	q9, [sp, #0xe0]
    10fc:      	fmul.4s	v4, v9, v9
    1100:      	ldr	q10, [sp, #0xc0]
    1104:      	fmul.4s	v5, v10, v10
    1108:      	fadd.4s	v5, v5, v31
    110c:      	fadd.4s	v4, v4, v30
    1110:      	zip2.8b	v7, v6, v0
    1114:      	ushll.4s	v7, v7, #0x0
    1118:      	shl.4s	v7, v7, #0x1f
    111c:      	cmlt.4s	v7, v7, #0
    1120:      	and.16b	v4, v7, v4
    1124:      	zip1.8b	v7, v6, v0
    1128:      	ushll.4s	v7, v7, #0x0
    112c:      	shl.4s	v7, v7, #0x1f
    1130:      	cmlt.4s	v7, v7, #0
    1134:      	and.16b	v5, v7, v5
    1138:      	zip1.8b	v7, v3, v0
    113c:      	ushll.4s	v7, v7, #0x0
    1140:      	shl.4s	v7, v7, #0x1f
    1144:      	cmlt.4s	v7, v7, #0
    1148:      	bit.16b	v5, v12, v7
    114c:      	zip2.8b	v3, v3, v0
    1150:      	ushll.4s	v3, v3, #0x0
    1154:      	shl.4s	v3, v3, #0x1f
    1158:      	cmlt.4s	v3, v3, #0
    115c:      	bsl.16b	v3, v11, v4
    1160:      	fadd.4s	v3, v29, v3
    1164:      	fadd.4s	v4, v28, v5
    1168:      	fadd.4s	v4, v27, v4
    116c:      	fadd.4s	v3, v26, v3
    1170:      	fadd.4s	v25, v25, v3
    1174:      	fadd.4s	v18, v24, v4
    1178:      	umov.b	w17, v23[1]
    117c:      	mov	s3, v18[1]
    1180:      	tst	w16, w17
    1184:      	fcsel	s24, s3, s8, ne
    1188:      	mvn	w0, w17
    118c:      	add	x1, sp, #0x280
    1190:      	bfi	x1, x0, #2, #1
    1194:      	add	x2, sp, #0x138
    1198:      	bfxil	x2, x0, #0, #1
    119c:      	str	d23, [sp, #0x138]
    11a0:      	ldrb	w0, [x2]
    11a4:      	and	w0, w17, w0
    11a8:      	stp	q18, q25, [sp, #0x280]
    11ac:      	ldr	s3, [x1]
    11b0:      	tst	w0, #0x1
    11b4:      	fcsel	s26, s3, s8, ne
    11b8:      	umov.b	w0, v23[2]
    11bc:      	ands	w1, w0, #0x1
    11c0:      	mov	w2, #0x3                ; =3
    11c4:      	csinc	w2, w2, wzr, ne
    11c8:      	add	x23, sp, #0x138
    11cc:      	orr	x3, x23, x2
    11d0:      	ldrb	w3, [x3]
    11d4:      	add	x4, sp, #0x260
    11d8:      	orr	x2, x4, x2, lsl #2
    11dc:      	stp	q18, q25, [sp, #0x260]
    11e0:      	ldr	s3, [x2]
    11e4:      	tst	w1, w3
    11e8:      	fcsel	s27, s3, s8, ne
    11ec:      	umov.b	w1, v23[3]
    11f0:      	ands	w2, w1, #0x1
    11f4:      	mov	w3, #0x1                ; =1
    11f8:      	cinc	w3, w3, ne
    11fc:      	add	x4, sp, #0x138
    1200:      	bfxil	x4, x3, #0, #3
    1204:      	ldrb	w4, [x4]
    1208:      	add	x5, sp, #0x240
    120c:      	orr	x3, x5, x3, lsl #2
    1210:      	stp	q18, q25, [sp, #0x240]
    1214:      	ldr	s3, [x3]
    1218:      	tst	w2, w4
    121c:      	umov.b	w2, v23[4]
    1220:      	fcsel	s3, s3, s8, ne
    1224:      	ands	w5, w2, #0x1
    1228:      	mov	w3, #0x5                ; =5
    122c:      	csinc	w3, w3, wzr, ne
    1230:      	orr	x4, x23, x3
    1234:      	ldrb	w4, [x4]
    1238:      	stp	q18, q25, [sp, #0x220]
    123c:      	add	x6, sp, #0x220
    1240:      	ldr	s4, [x6, w3, uxtw #2]
    1244:      	mov	w3, #0x2                ; =2
    1248:      	mov	w22, #0x6               ; =6
    124c:      	csel	w7, w22, w3, ne
    1250:      	umov.b	w3, v23[5]
    1254:      	tst	w5, w4
    1258:      	fcsel	s28, s4, s8, ne
    125c:      	ands	w6, w3, #0x1
    1260:      	csinc	w4, w20, wzr, ne
    1264:      	orr	x20, x23, x4
    1268:      	ldrb	w20, [x20]
    126c:      	stp	q18, q25, [sp, #0x200]
    1270:      	add	x21, sp, #0x200
    1274:      	ldr	s4, [x21, w4, uxtw #2]
    1278:      	umov.b	w4, v23[6]
    127c:      	tst	w6, w20
    1280:      	fcsel	s4, s4, s8, ne
    1284:      	ands	w20, w4, #0x1
    1288:      	mov	w6, #0x7                ; =7
    128c:      	csinc	w6, w6, wzr, ne
    1290:      	orr	x21, x23, x6
    1294:      	ldrb	w21, [x21]
    1298:      	stp	q18, q25, [sp, #0x1e0]
    129c:      	add	x25, sp, #0x1e0
    12a0:      	ldr	s5, [x25, w6, uxtw #2]
    12a4:      	umov.b	w6, v23[7]
    12a8:      	tst	w20, w21
    12ac:      	fcsel	s5, s5, s8, ne
    12b0:      	ands	w20, w6, #0x1
    12b4:      	csinc	w21, w22, wzr, ne
    12b8:      	orr	x22, x23, x21
    12bc:      	ldrb	w22, [x22]
    12c0:      	tst	w20, w22
    12c4:      	stp	q18, q25, [sp, #0x1c0]
    12c8:      	add	x20, sp, #0x1c0
    12cc:      	ldr	s7, [x20, w21, uxtw #2]
    12d0:      	fcsel	s7, s7, s8, ne
    12d4:      	mov.s	v24[1], v26[0]
    12d8:      	mov.s	v24[2], v27[0]
    12dc:      	mov.s	v24[3], v3[0]
    12e0:      	mov.s	v28[1], v4[0]
    12e4:      	mov.s	v28[2], v5[0]
    12e8:      	mov.s	v28[3], v7[0]
    12ec:      	fadd.4s	v3, v18, v24
    12f0:      	mov	s4, v3[2]
    12f4:      	tst	w16, w0
    12f8:      	fcsel	s4, s4, s8, ne
    12fc:      	orr	x20, x23, x7
    1300:      	ldrb	w20, [x20]
    1304:      	tst	w5, w20
    1308:      	fadd.4s	v5, v25, v28
    130c:      	stp	q3, q5, [sp, #0x1a0]
    1310:      	add	x5, sp, #0x1a0
    1314:      	ldr	s7, [x5, w7, uxtw #2]
    1318:      	fcsel	s7, s7, s8, ne
    131c:      	tst	w16, w2
    1320:      	fadd.4s	v5, v5, v7
    1324:      	fcsel	s5, s5, s8, ne
    1328:      	ands	w13, w13, #0x1
    132c:      	fadd.4s	v3, v3, v4
    1330:      	fadd	s3, s3, s5
    1334:      	fcsel	s4, s3, s8, ne
    1338:      	tst	w13, w17
    133c:      	fcsel	s5, s3, s8, ne
    1340:      	tst	w13, w0
    1344:      	fcsel	s7, s3, s8, ne
    1348:      	tst	w1, #0x1
    134c:      	fcsel	s16, s4, s8, ne
    1350:      	tst	w13, w2
    1354:      	fcsel	s3, s3, s8, ne
    1358:      	tst	w3, #0x1
    135c:      	fcsel	s17, s4, s8, ne
    1360:      	tst	w4, #0x1
    1364:      	fcsel	s18, s4, s8, ne
    1368:      	tst	w6, #0x1
    136c:      	sshll.2d	v23, v1, #0x0
    1370:      	adrp	x13, 0x1000 <ltmp0+0x1000>
    1374:      	ldr	d24, [x13]
    1378:      	shl.8b	v25, v6, #0x7
    137c:      	cmlt.8b	v25, v25, #0
    1380:      	fcsel	s26, s4, s8, ne
    1384:      	mov.s	v3[1], v17[0]
    1388:      	mov.s	v3[2], v18[0]
    138c:      	mov.s	v3[3], v26[0]
    1390:      	mov.s	v4[1], v5[0]
    1394:      	mov.s	v4[2], v7[0]
    1398:      	and.8b	v5, v25, v24
    139c:      	mov.s	v4[3], v16[0]
    13a0:      	rbit	w12, w12
    13a4:      	clz	w12, w12
    13a8:      	stp	q4, q3, [sp, #0x180]
    13ac:      	and	x12, x12, #0x7
    13b0:      	add	x13, sp, #0x180
    13b4:      	ldr	s25, [x13, x12, lsl #2]
    13b8:      	ldr	q3, [sp, #0x80]
    13bc:      	and.16b	v3, v23, v3
    13c0:      	movi.2d	v4, #0000000000000000
    13c4:      	stp	q4, q4, [sp, #0x160]
    13c8:      	stp	q3, q4, [sp, #0x140]
    13cc:      	and	x12, x10, #0x7
    13d0:      	add	x13, sp, #0x140
    13d4:      	ldr	x12, [x13, x12, lsl #3]
    13d8:      	addv.8b	b23, v5
    13dc:      	sub	x12, x12, x10
    13e0:      	add	x11, x11, x12, lsl #2
    13e4:      	fmov	w12, s23
    13e8:      	movi.2d	v24, #0000000000000000
    13ec:      	movi.2d	v18, #0000000000000000
    13f0:      	tbnz	w12, #0x0, 0x163c <ltmp0+0x163c>
    13f4:      	tbnz	w12, #0x1, 0x1644 <ltmp0+0x1644>
    13f8:      	tbnz	w12, #0x2, 0x1650 <ltmp0+0x1650>
    13fc:      	tbnz	w12, #0x3, 0x165c <ltmp0+0x165c>
    1400:      	tbnz	w12, #0x4, 0x1668 <ltmp0+0x1668>
    1404:      	tbnz	w12, #0x5, 0x1674 <ltmp0+0x1674>
    1408:      	tbnz	w12, #0x6, 0x1680 <ltmp0+0x1680>
    140c:      	tbz	w12, #0x7, 0x1418 <ltmp0+0x1418>
    1410:      	add	x11, x11, #0x1c
    1414:      	ld1.s	{ v18 }[3], [x11]
    1418:      	mov	x11, #0x0               ; =0
    141c:      	fadd	s3, s25, s8
    1420:      	mov	w12, #0x4000            ; =16384
    1424:      	movk	w12, #0x44c0, lsl #16
    1428:      	fmov	s4, w12
    142c:      	fdiv	s3, s3, s4
    1430:      	add	x12, x24, x14
    1434:      	ldp	q4, q5, [x12]
    1438:      	zip2.8b	v7, v6, v0
    143c:      	ushll.4s	v7, v7, #0x0
    1440:      	shl.4s	v7, v7, #0x1f
    1444:      	cmlt.4s	v7, v7, #0
    1448:      	bit.16b	v5, v18, v7
    144c:      	zip1.8b	v6, v6, v0
    1450:      	ushll.4s	v6, v6, #0x0
    1454:      	shl.4s	v6, v6, #0x1f
    1458:      	cmlt.4s	v6, v6, #0
    145c:      	bit.16b	v4, v24, v6
    1460:      	mov	w13, #0xc5ac            ; =50604
    1464:      	movk	w13, #0x3727, lsl #16
    1468:      	fmov	s6, w13
    146c:      	fadd	s3, s3, s6
    1470:      	fsqrt	s3, s3
    1474:      	dup.4s	v6, v3[0]
    1478:      	stp	q4, q5, [x12]
    147c:      	add	x9, x8, x9
    1480:      	movi.2d	v25, #0000000000000000
    1484:      	movi.2d	v26, #0000000000000000
    1488:      	movi.2d	v27, #0000000000000000
    148c:      	movi.2d	v28, #0000000000000000
    1490:      	b	0x14b8 <ltmp0+0x14b8>
    1494:      	add.2d	v3, v25, v22
    1498:      	add.2d	v26, v26, v20
    149c:      	add.2d	v27, v27, v21
    14a0:      	add.2d	v28, v28, v19
    14a4:      	fmov	x11, d25
    14a8:      	add	x11, x11, x15
    14ac:      	mov.16b	v25, v3
    14b0:      	cmp	x11, #0xc0
    14b4:      	b.ge	0x1588 <ltmp0+0x1588>
    14b8:      	fmov	w12, s2
    14bc:      	lsl	x11, x11, #5
    14c0:      	add	x13, x19, x11
    14c4:      	ldp	q3, q29, [x13]
    14c8:      	and.16b	v3, v1, v3
    14cc:      	fdiv.4s	v3, v3, v6
    14d0:      	add	x13, x24, x11
    14d4:      	ldp	q4, q30, [x13]
    14d8:      	and.16b	v4, v1, v4
    14dc:      	fmul.4s	v31, v3, v4
    14e0:      	add	x11, x9, x11
    14e4:      	tbnz	w12, #0x0, 0x151c <ltmp0+0x151c>
    14e8:      	and	w12, w12, #0xff
    14ec:      	tbnz	w12, #0x1, 0x1528 <ltmp0+0x1528>
    14f0:      	tbnz	w12, #0x2, 0x1534 <ltmp0+0x1534>
    14f4:      	tbnz	w12, #0x3, 0x1540 <ltmp0+0x1540>
    14f8:      	and.16b	v3, v0, v29
    14fc:      	fdiv.4s	v3, v3, v6
    1500:      	and.16b	v4, v0, v30
    1504:      	fmul.4s	v29, v3, v4
    1508:      	tbnz	w12, #0x4, 0x155c <ltmp0+0x155c>
    150c:      	tbnz	w12, #0x5, 0x1564 <ltmp0+0x1564>
    1510:      	tbnz	w12, #0x6, 0x1570 <ltmp0+0x1570>
    1514:      	tbz	w12, #0x7, 0x1494 <ltmp0+0x1494>
    1518:      	b	0x157c <ltmp0+0x157c>
    151c:      	str	s31, [x11]
    1520:      	and	w12, w12, #0xff
    1524:      	tbz	w12, #0x1, 0x14f0 <ltmp0+0x14f0>
    1528:      	add	x13, x11, #0x4
    152c:      	st1.s	{ v31 }[1], [x13]
    1530:      	tbz	w12, #0x2, 0x14f4 <ltmp0+0x14f4>
    1534:      	add	x13, x11, #0x8
    1538:      	st1.s	{ v31 }[2], [x13]
    153c:      	tbz	w12, #0x3, 0x14f8 <ltmp0+0x14f8>
    1540:      	add	x13, x11, #0xc
    1544:      	st1.s	{ v31 }[3], [x13]
    1548:      	and.16b	v3, v0, v29
    154c:      	fdiv.4s	v3, v3, v6
    1550:      	and.16b	v4, v0, v30
    1554:      	fmul.4s	v29, v3, v4
    1558:      	tbz	w12, #0x4, 0x150c <ltmp0+0x150c>
    155c:      	str	s29, [x11, #0x10]
    1560:      	tbz	w12, #0x5, 0x1510 <ltmp0+0x1510>
    1564:      	add	x13, x11, #0x14
    1568:      	st1.s	{ v29 }[1], [x13]
    156c:      	tbz	w12, #0x6, 0x1514 <ltmp0+0x1514>
    1570:      	add	x13, x11, #0x18
    1574:      	st1.s	{ v29 }[2], [x13]
    1578:      	tbz	w12, #0x7, 0x1494 <ltmp0+0x1494>
    157c:      	add	x11, x11, #0x1c
    1580:      	st1.s	{ v29 }[3], [x11]
    1584:      	b	0x1494 <ltmp0+0x1494>
    1588:      	fdiv.4s	v0, v10, v6
    158c:      	fmul.4s	v0, v0, v24
    1590:      	ldr	q2, [sp, #0xd0]
    1594:      	ldp	q3, q4, [sp, #0xa0]
    1598:      	stp	q2, q3, [sp, #0xf0]
    159c:      	ldr	q1, [sp, #0x90]
    15a0:      	stp	q4, q1, [sp, #0x110]
    15a4:      	and	x9, x10, #0x7
    15a8:      	add	x11, sp, #0xf0
    15ac:      	ldr	x9, [x11, x9, lsl #3]
    15b0:      	sub	x9, x9, x10
    15b4:      	add	x8, x8, x9, lsl #2
    15b8:      	fmov	w9, s23
    15bc:      	tbnz	w9, #0x0, 0x1690 <ltmp0+0x1690>
    15c0:      	tbnz	w9, #0x1, 0x1698 <ltmp0+0x1698>
    15c4:      	tbnz	w9, #0x2, 0x16a4 <ltmp0+0x16a4>
    15c8:      	tbnz	w9, #0x3, 0x16b0 <ltmp0+0x16b0>
    15cc:      	fdiv.4s	v0, v9, v6
    15d0:      	fmul.4s	v0, v0, v18
    15d4:      	tbnz	w9, #0x4, 0x16c4 <ltmp0+0x16c4>
    15d8:      	tbnz	w9, #0x5, 0x16cc <ltmp0+0x16cc>
    15dc:      	tbnz	w9, #0x6, 0x16d8 <ltmp0+0x16d8>
    15e0:      	tbz	w9, #0x7, 0x6c <ltmp0+0x6c>
    15e4:      	b	0x16e4 <ltmp0+0x16e4>
    15e8:      	ldr	s4, [x14]
    15ec:      	tbz	w15, #0x1, 0xd6c <ltmp0+0xd6c>
    15f0:      	add	x16, x14, #0x4
    15f4:      	ld1.s	{ v4 }[1], [x16]
    15f8:      	tbz	w15, #0x2, 0xd70 <ltmp0+0xd70>
    15fc:      	add	x16, x14, #0x8
    1600:      	ld1.s	{ v4 }[2], [x16]
    1604:      	tbz	w15, #0x3, 0xd74 <ltmp0+0xd74>
    1608:      	add	x16, x14, #0xc
    160c:      	ld1.s	{ v4 }[3], [x16]
    1610:      	tbz	w15, #0x4, 0xd78 <ltmp0+0xd78>
    1614:      	add	x16, x14, #0x10
    1618:      	ld1.s	{ v3 }[0], [x16]
    161c:      	tbz	w15, #0x5, 0xd7c <ltmp0+0xd7c>
    1620:      	add	x16, x14, #0x14
    1624:      	ld1.s	{ v3 }[1], [x16]
    1628:      	tbz	w15, #0x6, 0xd80 <ltmp0+0xd80>
    162c:      	add	x16, x14, #0x18
    1630:      	ld1.s	{ v3 }[2], [x16]
    1634:      	tbnz	w15, #0x7, 0xd84 <ltmp0+0xd84>
    1638:      	b	0xd8c <ltmp0+0xd8c>
    163c:      	ldr	s24, [x11]
    1640:      	tbz	w12, #0x1, 0x13f8 <ltmp0+0x13f8>
    1644:      	add	x13, x11, #0x4
    1648:      	ld1.s	{ v24 }[1], [x13]
    164c:      	tbz	w12, #0x2, 0x13fc <ltmp0+0x13fc>
    1650:      	add	x13, x11, #0x8
    1654:      	ld1.s	{ v24 }[2], [x13]
    1658:      	tbz	w12, #0x3, 0x1400 <ltmp0+0x1400>
    165c:      	add	x13, x11, #0xc
    1660:      	ld1.s	{ v24 }[3], [x13]
    1664:      	tbz	w12, #0x4, 0x1404 <ltmp0+0x1404>
    1668:      	add	x13, x11, #0x10
    166c:      	ld1.s	{ v18 }[0], [x13]
    1670:      	tbz	w12, #0x5, 0x1408 <ltmp0+0x1408>
    1674:      	add	x13, x11, #0x14
    1678:      	ld1.s	{ v18 }[1], [x13]
    167c:      	tbz	w12, #0x6, 0x140c <ltmp0+0x140c>
    1680:      	add	x13, x11, #0x18
    1684:      	ld1.s	{ v18 }[2], [x13]
    1688:      	tbnz	w12, #0x7, 0x1410 <ltmp0+0x1410>
    168c:      	b	0x1418 <ltmp0+0x1418>
    1690:      	str	s0, [x8]
    1694:      	tbz	w9, #0x1, 0x15c4 <ltmp0+0x15c4>
    1698:      	add	x10, x8, #0x4
    169c:      	st1.s	{ v0 }[1], [x10]
    16a0:      	tbz	w9, #0x2, 0x15c8 <ltmp0+0x15c8>
    16a4:      	add	x10, x8, #0x8
    16a8:      	st1.s	{ v0 }[2], [x10]
    16ac:      	tbz	w9, #0x3, 0x15cc <ltmp0+0x15cc>
    16b0:      	add	x10, x8, #0xc
    16b4:      	st1.s	{ v0 }[3], [x10]
    16b8:      	fdiv.4s	v0, v9, v6
    16bc:      	fmul.4s	v0, v0, v18
    16c0:      	tbz	w9, #0x4, 0x15d8 <ltmp0+0x15d8>
    16c4:      	str	s0, [x8, #0x10]
    16c8:      	tbz	w9, #0x5, 0x15dc <ltmp0+0x15dc>
    16cc:      	add	x10, x8, #0x14
    16d0:      	st1.s	{ v0 }[1], [x10]
    16d4:      	tbz	w9, #0x6, 0x15e0 <ltmp0+0x15e0>
    16d8:      	add	x10, x8, #0x18
    16dc:      	st1.s	{ v0 }[2], [x10]
    16e0:      	tbz	w9, #0x7, 0x6c <ltmp0+0x6c>
    16e4:      	add	x8, x8, #0x1c
    16e8:      	st1.s	{ v0 }[3], [x8]
    16ec:      	b	0x6c <ltmp0+0x6c>
    16f0:      	ldr	x9, [sp, #0x8]
    16f4:      	stp	w26, w13, [x9]
    16f8:      	str	w12, [x9, #0x8]
    16fc:      	mov	w8, #0x18               ; =24
    1700:      	str	w8, [x9, #0x24]
    1704:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    1708:      	add	sp, sp, #0x380
    170c:      	ldp	x29, x30, [sp, #0x90]
    1710:      	ldp	x20, x19, [sp, #0x80]
    1714:      	ldp	x22, x21, [sp, #0x70]
    1718:      	ldp	x24, x23, [sp, #0x60]
    171c:      	ldp	x26, x25, [sp, #0x50]
    1720:      	ldp	x28, x27, [sp, #0x40]
    1724:      	ldp	d9, d8, [sp, #0x30]
    1728:      	ldp	d11, d10, [sp, #0x20]
    172c:      	ldp	d13, d12, [sp, #0x10]
    1730:      	ldp	d15, d14, [sp], #0xa0
    1734:      	ret

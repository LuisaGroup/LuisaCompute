
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/rmsnorm-257x1538/off/object/tile_xir_w8_37868_1788936533705587_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      2c:      	sub	sp, sp, #0x410
      30:      	str	x0, [sp, #0x48]
      34:      	cbz	w3, 0x17dc <ltmp0+0x17dc>
      38:      	mov	w25, #0x0               ; =0
      3c:      	ldp	w9, w8, [x2, #0x2c]
      40:      	stp	w8, w9, [sp, #0x6c]
      44:      	add	x19, sp, #0x1, lsl #12  ; =0x1000
      48:      	add	x19, x19, #0xbf0
      4c:      	add	x24, sp, #0x3d0
      50:      	ldp	w8, w9, [x2]
      54:      	ldp	w10, w11, [x2, #0x8]
      58:      	str	x2, [sp, #0x8]
      5c:      	str	x11, [sp, #0x60]
      60:      	movi	d8, #0000000000000000
      64:      	str	w3, [sp, #0x74]
      68:      	b	0xac <ltmp0+0xac>
      6c:      	ldr	w25, [sp, #0x8c]
      70:      	add	w8, w7, #0x1
      74:      	ldp	w11, w9, [sp, #0x6c]
      78:      	cmp	w8, w9
      7c:      	cset	w9, eq
      80:      	csinc	w8, wzr, w7, eq
      84:      	ldp	w13, w12, [sp, #0x78]
      88:      	cinc	w10, w13, eq
      8c:      	cmp	w10, w11
      90:      	cset	w11, eq
      94:      	ands	w11, w9, w11
      98:      	csel	w9, wzr, w10, ne
      9c:      	add	w10, w12, w11
      a0:      	add	w25, w25, #0x1
      a4:      	cmp	w25, w3
      a8:      	b.eq	0x17c8 <ltmp0+0x17c8>
      ac:      	str	w10, [sp, #0x7c]
      b0:      	mov	x13, x9
      b4:      	mov	x14, x8
      b8:      	ubfiz	x8, x8, #5, #32
      bc:      	ldr	x12, [sp, #0x60]
      c0:      	cmp	x8, x12
      c4:      	csel	x9, x8, xzr, ls
      c8:      	subs	x10, x12, x9
      cc:      	cmp	x10, #0x20
      d0:      	mov	w11, #0x20              ; =32
      d4:      	csel	x10, x10, x11, lo
      d8:      	cmp	x12, x9
      dc:      	ccmp	x8, x12, #0x2, hi
      e0:      	csel	x9, x10, xzr, ls
      e4:      	cmp	x9, #0x20
      e8:      	str	w25, [sp, #0x8c]
      ec:      	str	w13, [sp, #0x78]
      f0:      	str	x14, [sp, #0x80]
      f4:      	b.lo	0x8f0 <ltmp0+0x8f0>
      f8:      	ldr	x8, [sp, #0x48]
      fc:      	ldr	x27, [x8]
     100:      	ldr	x22, [x8, #0x10]
     104:      	ldr	x28, [x8, #0x30]
     108:      	ubfiz	w20, w14, #2, #27
     10c:      	mov	w21, #0x1808            ; =6152
     110:      	umull	x23, w20, w21
     114:      	umaddl	x1, w20, w21, x27
     118:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     11c:      	add	x0, x0, #0xbf0
     120:      	mov	w2, #0x1800             ; =6144
     124:      	bl	0x124 <ltmp0+0x124>
     128:      	mov	x8, #0x0                ; =0
     12c:      	mov	w9, #0x1800             ; =6144
     130:      	umaddl	x21, w20, w21, x9
     134:      	add	x9, x27, x21
     138:      	ldr	s0, [x9], #0x4
     13c:      	ld1.s	{ v0 }[1], [x9]
     140:      	str	q0, [sp, #0x130]
     144:      	str	q0, [sp, #0x33f0]
     148:      	ldr	q0, [sp, #0x1bf0]
     14c:      	ldr	q1, [sp, #0x1c00]
     150:      	fmul.4s	v2, v1, v1
     154:      	fmul.4s	v3, v0, v0
     158:      	ldr	q0, [sp, #0x1c10]
     15c:      	ldr	q1, [sp, #0x1c20]
     160:      	fmul.4s	v5, v1, v1
     164:      	fmul.4s	v4, v0, v0
     168:      	ldr	q0, [sp, #0x1c30]
     16c:      	ldr	q1, [sp, #0x1c40]
     170:      	fmul.4s	v6, v1, v1
     174:      	fmul.4s	v7, v0, v0
     178:      	ldr	q0, [sp, #0x1c50]
     17c:      	ldr	q1, [sp, #0x1c60]
     180:      	fmul.4s	v17, v1, v1
     184:      	fmul.4s	v16, v0, v0
     188:      	add	x9, x19, x8, lsl #5
     18c:      	ldp	q1, q0, [x9, #0x80]
     190:      	fmul.4s	v1, v1, v1
     194:      	fmul.4s	v0, v0, v0
     198:      	fadd.4s	v2, v2, v0
     19c:      	fadd.4s	v3, v3, v1
     1a0:      	ldp	q1, q0, [x9, #0xa0]
     1a4:      	fmul.4s	v1, v1, v1
     1a8:      	fmul.4s	v0, v0, v0
     1ac:      	fadd.4s	v5, v5, v0
     1b0:      	fadd.4s	v4, v4, v1
     1b4:      	ldp	q1, q0, [x9, #0xc0]
     1b8:      	fmul.4s	v1, v1, v1
     1bc:      	fmul.4s	v0, v0, v0
     1c0:      	fadd.4s	v6, v6, v0
     1c4:      	fadd.4s	v7, v7, v1
     1c8:      	ldp	q1, q0, [x9, #0xe0]
     1cc:      	fmul.4s	v1, v1, v1
     1d0:      	fmul.4s	v0, v0, v0
     1d4:      	fadd.4s	v17, v17, v0
     1d8:      	fadd.4s	v16, v16, v1
     1dc:      	add	x8, x8, #0x4
     1e0:      	cmp	x8, #0xbc
     1e4:      	b.lo	0x188 <ltmp0+0x188>
     1e8:      	add	x0, sp, #0x3d0
     1ec:      	mov	x1, x22
     1f0:      	mov	w2, #0x1800             ; =6144
     1f4:      	stp	q5, q2, [sp, #0xc0]
     1f8:      	str	q3, [sp, #0xb0]
     1fc:      	stp	q7, q4, [sp, #0xe0]
     200:      	stp	q6, q16, [sp, #0x110]
     204:      	str	q17, [sp, #0x100]
     208:      	bl	0x208 <ltmp0+0x208>
     20c:      	mov	x8, #0x0                ; =0
     210:      	ldr	q7, [sp, #0x130]
     214:      	fmul.4s	v0, v7, v7
     218:      	ldp	q1, q2, [sp, #0xb0]
     21c:      	fadd.4s	v0, v0, v1
     220:      	mov.d	v0[1], v1[1]
     224:      	ldr	q1, [sp, #0xd0]
     228:      	fadd.4s	v1, v2, v1
     22c:      	ldp	q2, q3, [sp, #0xe0]
     230:      	fadd.4s	v0, v3, v0
     234:      	fadd.4s	v0, v2, v0
     238:      	ldp	q2, q3, [sp, #0x100]
     23c:      	fadd.4s	v1, v3, v1
     240:      	fadd.4s	v1, v2, v1
     244:      	ldr	q2, [sp, #0x120]
     248:      	fadd.4s	v0, v2, v0
     24c:      	rev64.4s	v2, v0
     250:      	rev64.4s	v3, v1
     254:      	fadd.4s	v1, v1, v3
     258:      	fadd.4s	v0, v0, v2
     25c:      	dup.4s	v2, v0[2]
     260:      	dup.4s	v3, v1[2]
     264:      	fadd.4s	v1, v1, v3
     268:      	fadd.4s	v0, v0, v2
     26c:      	fadd.4s	v0, v0, v1
     270:      	fadd	s0, s0, s8
     274:      	mov	w9, #0x4000             ; =16384
     278:      	movk	w9, #0x44c0, lsl #16
     27c:      	fmov	s1, w9
     280:      	fdiv	s1, s0, s1
     284:      	mov	w9, #0x1804             ; =6148
     288:      	add	x9, x22, x9
     28c:      	ldr	s0, [x22, #0x1800]
     290:      	ld1.s	{ v0 }[1], [x9]
     294:      	mov	w9, #0x1800             ; =6144
     298:      	add	x25, x22, x9
     29c:      	str	q0, [sp, #0x1bd0]
     2a0:      	mov	w9, #0xc5ac             ; =50604
     2a4:      	movk	w9, #0x3727, lsl #16
     2a8:      	fmov	s2, w9
     2ac:      	fadd	s1, s1, s2
     2b0:      	fsqrt	s1, s1
     2b4:      	dup.4s	v2, v1[0]
     2b8:      	add	x9, x28, x23
     2bc:      	lsl	x10, x8, #5
     2c0:      	add	x11, x19, x10
     2c4:      	ldp	q3, q4, [x11]
     2c8:      	fdiv.4s	v4, v4, v2
     2cc:      	fdiv.4s	v3, v3, v2
     2d0:      	add	x11, x24, x10
     2d4:      	ldp	q6, q5, [x11]
     2d8:      	fmul.4s	v3, v3, v6
     2dc:      	fmul.4s	v4, v4, v5
     2e0:      	add	x10, x9, x10
     2e4:      	stp	q3, q4, [x10]
     2e8:      	add	x8, x8, #0x1
     2ec:      	cmp	x8, #0xc0
     2f0:      	b.ne	0x2bc <ltmp0+0x2bc>
     2f4:      	dup.2s	v1, v1[0]
     2f8:      	fdiv.2s	v1, v7, v1
     2fc:      	fmul.2s	v0, v1, v0
     300:      	str	d0, [x28, x21]
     304:      	orr	w21, w20, #0x1
     308:      	mov	w26, #0x1808            ; =6152
     30c:      	umull	x23, w21, w26
     310:      	umaddl	x1, w21, w26, x27
     314:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     318:      	add	x0, x0, #0xbf0
     31c:      	mov	w2, #0x1800             ; =6144
     320:      	bl	0x320 <ltmp0+0x320>
     324:      	mov	x8, #0x0                ; =0
     328:      	mov	w9, #0x1800             ; =6144
     32c:      	umaddl	x21, w21, w26, x9
     330:      	add	x9, x27, x21
     334:      	ldr	s0, [x9], #0x4
     338:      	ld1.s	{ v0 }[1], [x9]
     33c:      	str	q0, [sp, #0x130]
     340:      	str	q0, [sp, #0x33f0]
     344:      	ldr	q0, [sp, #0x1bf0]
     348:      	ldr	q1, [sp, #0x1c00]
     34c:      	fmul.4s	v2, v1, v1
     350:      	fmul.4s	v17, v0, v0
     354:      	ldr	q0, [sp, #0x1c10]
     358:      	ldr	q1, [sp, #0x1c20]
     35c:      	fmul.4s	v4, v1, v1
     360:      	fmul.4s	v3, v0, v0
     364:      	ldr	q0, [sp, #0x1c30]
     368:      	ldr	q1, [sp, #0x1c40]
     36c:      	fmul.4s	v5, v1, v1
     370:      	fmul.4s	v6, v0, v0
     374:      	ldr	q0, [sp, #0x1c50]
     378:      	ldr	q1, [sp, #0x1c60]
     37c:      	fmul.4s	v16, v1, v1
     380:      	fmul.4s	v7, v0, v0
     384:      	add	x9, x19, x8, lsl #5
     388:      	ldp	q1, q0, [x9, #0x80]
     38c:      	fmul.4s	v1, v1, v1
     390:      	fmul.4s	v0, v0, v0
     394:      	fadd.4s	v2, v2, v0
     398:      	fadd.4s	v17, v17, v1
     39c:      	ldp	q1, q0, [x9, #0xa0]
     3a0:      	fmul.4s	v1, v1, v1
     3a4:      	fmul.4s	v0, v0, v0
     3a8:      	fadd.4s	v4, v4, v0
     3ac:      	fadd.4s	v3, v3, v1
     3b0:      	ldp	q1, q0, [x9, #0xc0]
     3b4:      	fmul.4s	v1, v1, v1
     3b8:      	fmul.4s	v0, v0, v0
     3bc:      	fadd.4s	v5, v5, v0
     3c0:      	fadd.4s	v6, v6, v1
     3c4:      	ldp	q1, q0, [x9, #0xe0]
     3c8:      	fmul.4s	v1, v1, v1
     3cc:      	fmul.4s	v0, v0, v0
     3d0:      	fadd.4s	v16, v16, v0
     3d4:      	fadd.4s	v7, v7, v1
     3d8:      	add	x8, x8, #0x4
     3dc:      	cmp	x8, #0xbc
     3e0:      	b.lo	0x384 <ltmp0+0x384>
     3e4:      	add	x0, sp, #0x3d0
     3e8:      	mov	x1, x22
     3ec:      	mov	w2, #0x1800             ; =6144
     3f0:      	stp	q4, q2, [sp, #0xc0]
     3f4:      	stp	q6, q3, [sp, #0xe0]
     3f8:      	stp	q5, q7, [sp, #0x110]
     3fc:      	str	q16, [sp, #0x100]
     400:      	str	q17, [sp, #0xb0]
     404:      	bl	0x404 <ltmp0+0x404>
     408:      	mov	x8, #0x0                ; =0
     40c:      	ldr	q7, [sp, #0x130]
     410:      	fmul.4s	v0, v7, v7
     414:      	ldp	q2, q3, [sp, #0xb0]
     418:      	fadd.4s	v1, v0, v2
     41c:      	mov.d	v1[1], v2[1]
     420:      	mov	w9, #0x1804             ; =6148
     424:      	add	x9, x22, x9
     428:      	ldr	s0, [x25]
     42c:      	ld1.s	{ v0 }[1], [x9]
     430:      	ldr	q2, [sp, #0xd0]
     434:      	fadd.4s	v2, v3, v2
     438:      	ldp	q3, q4, [sp, #0xe0]
     43c:      	fadd.4s	v1, v4, v1
     440:      	fadd.4s	v1, v3, v1
     444:      	ldp	q3, q4, [sp, #0x100]
     448:      	fadd.4s	v2, v4, v2
     44c:      	fadd.4s	v2, v3, v2
     450:      	ldr	q3, [sp, #0x120]
     454:      	fadd.4s	v1, v3, v1
     458:      	rev64.4s	v3, v1
     45c:      	rev64.4s	v4, v2
     460:      	fadd.4s	v2, v2, v4
     464:      	fadd.4s	v1, v1, v3
     468:      	dup.4s	v3, v1[2]
     46c:      	dup.4s	v4, v2[2]
     470:      	fadd.4s	v2, v2, v4
     474:      	fadd.4s	v1, v1, v3
     478:      	fadd.4s	v1, v1, v2
     47c:      	fadd	s1, s1, s8
     480:      	mov	w9, #0x4000             ; =16384
     484:      	movk	w9, #0x44c0, lsl #16
     488:      	fmov	s2, w9
     48c:      	fdiv	s1, s1, s2
     490:      	str	q0, [sp, #0x1bd0]
     494:      	mov	w9, #0xc5ac             ; =50604
     498:      	movk	w9, #0x3727, lsl #16
     49c:      	fmov	s2, w9
     4a0:      	fadd	s1, s1, s2
     4a4:      	fsqrt	s1, s1
     4a8:      	dup.4s	v2, v1[0]
     4ac:      	add	x9, x28, x23
     4b0:      	lsl	x10, x8, #5
     4b4:      	add	x11, x19, x10
     4b8:      	ldp	q3, q4, [x11]
     4bc:      	fdiv.4s	v4, v4, v2
     4c0:      	fdiv.4s	v3, v3, v2
     4c4:      	add	x11, x24, x10
     4c8:      	ldp	q6, q5, [x11]
     4cc:      	fmul.4s	v3, v3, v6
     4d0:      	fmul.4s	v4, v4, v5
     4d4:      	add	x10, x9, x10
     4d8:      	stp	q3, q4, [x10]
     4dc:      	add	x8, x8, #0x1
     4e0:      	cmp	x8, #0xc0
     4e4:      	b.ne	0x4b0 <ltmp0+0x4b0>
     4e8:      	dup.2s	v1, v1[0]
     4ec:      	fdiv.2s	v1, v7, v1
     4f0:      	fmul.2s	v0, v1, v0
     4f4:      	str	d0, [x28, x21]
     4f8:      	orr	w21, w20, #0x2
     4fc:      	mov	w26, #0x1808            ; =6152
     500:      	umull	x23, w21, w26
     504:      	umaddl	x1, w21, w26, x27
     508:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     50c:      	add	x0, x0, #0xbf0
     510:      	mov	w2, #0x1800             ; =6144
     514:      	bl	0x514 <ltmp0+0x514>
     518:      	mov	x8, #0x0                ; =0
     51c:      	mov	w9, #0x1800             ; =6144
     520:      	umaddl	x21, w21, w26, x9
     524:      	add	x9, x27, x21
     528:      	ldr	s0, [x9], #0x4
     52c:      	ld1.s	{ v0 }[1], [x9]
     530:      	str	q0, [sp, #0x130]
     534:      	str	q0, [sp, #0x33f0]
     538:      	ldr	q0, [sp, #0x1bf0]
     53c:      	ldr	q1, [sp, #0x1c00]
     540:      	fmul.4s	v2, v1, v1
     544:      	fmul.4s	v17, v0, v0
     548:      	ldr	q0, [sp, #0x1c10]
     54c:      	ldr	q1, [sp, #0x1c20]
     550:      	fmul.4s	v4, v1, v1
     554:      	fmul.4s	v3, v0, v0
     558:      	ldr	q0, [sp, #0x1c30]
     55c:      	ldr	q1, [sp, #0x1c40]
     560:      	fmul.4s	v5, v1, v1
     564:      	fmul.4s	v6, v0, v0
     568:      	ldr	q0, [sp, #0x1c50]
     56c:      	ldr	q1, [sp, #0x1c60]
     570:      	fmul.4s	v16, v1, v1
     574:      	fmul.4s	v7, v0, v0
     578:      	add	x9, x19, x8, lsl #5
     57c:      	ldp	q1, q0, [x9, #0x80]
     580:      	fmul.4s	v1, v1, v1
     584:      	fmul.4s	v0, v0, v0
     588:      	fadd.4s	v2, v2, v0
     58c:      	fadd.4s	v17, v17, v1
     590:      	ldp	q1, q0, [x9, #0xa0]
     594:      	fmul.4s	v1, v1, v1
     598:      	fmul.4s	v0, v0, v0
     59c:      	fadd.4s	v4, v4, v0
     5a0:      	fadd.4s	v3, v3, v1
     5a4:      	ldp	q1, q0, [x9, #0xc0]
     5a8:      	fmul.4s	v1, v1, v1
     5ac:      	fmul.4s	v0, v0, v0
     5b0:      	fadd.4s	v5, v5, v0
     5b4:      	fadd.4s	v6, v6, v1
     5b8:      	ldp	q1, q0, [x9, #0xe0]
     5bc:      	fmul.4s	v1, v1, v1
     5c0:      	fmul.4s	v0, v0, v0
     5c4:      	fadd.4s	v16, v16, v0
     5c8:      	fadd.4s	v7, v7, v1
     5cc:      	add	x8, x8, #0x4
     5d0:      	cmp	x8, #0xbc
     5d4:      	b.lo	0x578 <ltmp0+0x578>
     5d8:      	add	x0, sp, #0x3d0
     5dc:      	mov	x1, x22
     5e0:      	mov	w2, #0x1800             ; =6144
     5e4:      	stp	q4, q2, [sp, #0xc0]
     5e8:      	stp	q6, q3, [sp, #0xe0]
     5ec:      	stp	q5, q7, [sp, #0x110]
     5f0:      	str	q16, [sp, #0x100]
     5f4:      	str	q17, [sp, #0xb0]
     5f8:      	bl	0x5f8 <ltmp0+0x5f8>
     5fc:      	mov	x8, #0x0                ; =0
     600:      	ldr	q7, [sp, #0x130]
     604:      	fmul.4s	v0, v7, v7
     608:      	ldp	q2, q3, [sp, #0xb0]
     60c:      	fadd.4s	v1, v0, v2
     610:      	mov.d	v1[1], v2[1]
     614:      	mov	w9, #0x1804             ; =6148
     618:      	add	x9, x22, x9
     61c:      	ldr	s0, [x25]
     620:      	ld1.s	{ v0 }[1], [x9]
     624:      	ldr	q2, [sp, #0xd0]
     628:      	fadd.4s	v2, v3, v2
     62c:      	ldp	q3, q4, [sp, #0xe0]
     630:      	fadd.4s	v1, v4, v1
     634:      	fadd.4s	v1, v3, v1
     638:      	ldp	q3, q4, [sp, #0x100]
     63c:      	fadd.4s	v2, v4, v2
     640:      	fadd.4s	v2, v3, v2
     644:      	ldr	q3, [sp, #0x120]
     648:      	fadd.4s	v1, v3, v1
     64c:      	rev64.4s	v3, v1
     650:      	rev64.4s	v4, v2
     654:      	fadd.4s	v2, v2, v4
     658:      	fadd.4s	v1, v1, v3
     65c:      	dup.4s	v3, v1[2]
     660:      	dup.4s	v4, v2[2]
     664:      	fadd.4s	v2, v2, v4
     668:      	fadd.4s	v1, v1, v3
     66c:      	fadd.4s	v1, v1, v2
     670:      	fadd	s1, s1, s8
     674:      	mov	w9, #0x4000             ; =16384
     678:      	movk	w9, #0x44c0, lsl #16
     67c:      	fmov	s2, w9
     680:      	fdiv	s1, s1, s2
     684:      	str	q0, [sp, #0x1bd0]
     688:      	mov	w9, #0xc5ac             ; =50604
     68c:      	movk	w9, #0x3727, lsl #16
     690:      	fmov	s2, w9
     694:      	fadd	s1, s1, s2
     698:      	fsqrt	s1, s1
     69c:      	dup.4s	v2, v1[0]
     6a0:      	add	x9, x28, x23
     6a4:      	lsl	x10, x8, #5
     6a8:      	add	x11, x19, x10
     6ac:      	ldp	q3, q4, [x11]
     6b0:      	fdiv.4s	v4, v4, v2
     6b4:      	fdiv.4s	v3, v3, v2
     6b8:      	add	x11, x24, x10
     6bc:      	ldp	q6, q5, [x11]
     6c0:      	fmul.4s	v3, v3, v6
     6c4:      	fmul.4s	v4, v4, v5
     6c8:      	add	x10, x9, x10
     6cc:      	stp	q3, q4, [x10]
     6d0:      	add	x8, x8, #0x1
     6d4:      	cmp	x8, #0xc0
     6d8:      	b.ne	0x6a4 <ltmp0+0x6a4>
     6dc:      	dup.2s	v1, v1[0]
     6e0:      	fdiv.2s	v1, v7, v1
     6e4:      	fmul.2s	v0, v1, v0
     6e8:      	str	d0, [x28, x21]
     6ec:      	orr	w20, w20, #0x3
     6f0:      	mov	w23, #0x1808            ; =6152
     6f4:      	umull	x21, w20, w23
     6f8:      	umaddl	x1, w20, w23, x27
     6fc:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     700:      	add	x0, x0, #0xbf0
     704:      	mov	w2, #0x1800             ; =6144
     708:      	bl	0x708 <ltmp0+0x708>
     70c:      	mov	x8, #0x0                ; =0
     710:      	mov	w9, #0x1800             ; =6144
     714:      	umaddl	x20, w20, w23, x9
     718:      	add	x9, x27, x20
     71c:      	ldr	s0, [x9], #0x4
     720:      	ld1.s	{ v0 }[1], [x9]
     724:      	str	q0, [sp, #0x130]
     728:      	str	q0, [sp, #0x33f0]
     72c:      	ldr	q0, [sp, #0x1bf0]
     730:      	ldr	q1, [sp, #0x1c00]
     734:      	fmul.4s	v2, v1, v1
     738:      	fmul.4s	v17, v0, v0
     73c:      	ldr	q0, [sp, #0x1c10]
     740:      	ldr	q1, [sp, #0x1c20]
     744:      	fmul.4s	v4, v1, v1
     748:      	fmul.4s	v3, v0, v0
     74c:      	ldr	q0, [sp, #0x1c30]
     750:      	ldr	q1, [sp, #0x1c40]
     754:      	fmul.4s	v5, v1, v1
     758:      	fmul.4s	v6, v0, v0
     75c:      	ldr	q0, [sp, #0x1c50]
     760:      	ldr	q1, [sp, #0x1c60]
     764:      	fmul.4s	v16, v1, v1
     768:      	fmul.4s	v7, v0, v0
     76c:      	add	x9, x19, x8, lsl #5
     770:      	ldp	q1, q0, [x9, #0x80]
     774:      	fmul.4s	v1, v1, v1
     778:      	fmul.4s	v0, v0, v0
     77c:      	fadd.4s	v2, v2, v0
     780:      	fadd.4s	v17, v17, v1
     784:      	ldp	q1, q0, [x9, #0xa0]
     788:      	fmul.4s	v1, v1, v1
     78c:      	fmul.4s	v0, v0, v0
     790:      	fadd.4s	v4, v4, v0
     794:      	fadd.4s	v3, v3, v1
     798:      	ldp	q1, q0, [x9, #0xc0]
     79c:      	fmul.4s	v1, v1, v1
     7a0:      	fmul.4s	v0, v0, v0
     7a4:      	fadd.4s	v5, v5, v0
     7a8:      	fadd.4s	v6, v6, v1
     7ac:      	ldp	q1, q0, [x9, #0xe0]
     7b0:      	fmul.4s	v1, v1, v1
     7b4:      	fmul.4s	v0, v0, v0
     7b8:      	fadd.4s	v16, v16, v0
     7bc:      	fadd.4s	v7, v7, v1
     7c0:      	add	x8, x8, #0x4
     7c4:      	cmp	x8, #0xbc
     7c8:      	b.lo	0x76c <ltmp0+0x76c>
     7cc:      	add	x0, sp, #0x3d0
     7d0:      	mov	x1, x22
     7d4:      	mov	w2, #0x1800             ; =6144
     7d8:      	stp	q4, q2, [sp, #0xc0]
     7dc:      	stp	q6, q3, [sp, #0xe0]
     7e0:      	stp	q5, q7, [sp, #0x110]
     7e4:      	str	q16, [sp, #0x100]
     7e8:      	str	q17, [sp, #0xb0]
     7ec:      	bl	0x7ec <ltmp0+0x7ec>
     7f0:      	mov	x8, #0x0                ; =0
     7f4:      	ldr	q7, [sp, #0x130]
     7f8:      	fmul.4s	v0, v7, v7
     7fc:      	ldp	q2, q3, [sp, #0xb0]
     800:      	fadd.4s	v1, v0, v2
     804:      	mov.d	v1[1], v2[1]
     808:      	ldr	s0, [x25]
     80c:      	ldr	q2, [sp, #0xd0]
     810:      	fadd.4s	v2, v3, v2
     814:      	ldp	q3, q4, [sp, #0xe0]
     818:      	fadd.4s	v1, v4, v1
     81c:      	fadd.4s	v1, v3, v1
     820:      	ldp	q3, q4, [sp, #0x100]
     824:      	fadd.4s	v2, v4, v2
     828:      	fadd.4s	v2, v3, v2
     82c:      	ldr	q3, [sp, #0x120]
     830:      	fadd.4s	v1, v3, v1
     834:      	rev64.4s	v3, v1
     838:      	rev64.4s	v4, v2
     83c:      	fadd.4s	v2, v2, v4
     840:      	fadd.4s	v1, v1, v3
     844:      	dup.4s	v3, v1[2]
     848:      	dup.4s	v4, v2[2]
     84c:      	fadd.4s	v2, v2, v4
     850:      	fadd.4s	v1, v1, v3
     854:      	fadd.4s	v1, v1, v2
     858:      	fadd	s1, s1, s8
     85c:      	mov	w9, #0x4000             ; =16384
     860:      	movk	w9, #0x44c0, lsl #16
     864:      	fmov	s2, w9
     868:      	fdiv	s1, s1, s2
     86c:      	mov	w9, #0x1804             ; =6148
     870:      	add	x9, x22, x9
     874:      	ld1.s	{ v0 }[1], [x9]
     878:      	str	q0, [sp, #0x1bd0]
     87c:      	mov	w9, #0xc5ac             ; =50604
     880:      	movk	w9, #0x3727, lsl #16
     884:      	fmov	s2, w9
     888:      	fadd	s1, s1, s2
     88c:      	fsqrt	s1, s1
     890:      	dup.4s	v2, v1[0]
     894:      	add	x9, x28, x21
     898:      	lsl	x10, x8, #5
     89c:      	add	x11, x19, x10
     8a0:      	ldp	q3, q4, [x11]
     8a4:      	fdiv.4s	v4, v4, v2
     8a8:      	fdiv.4s	v3, v3, v2
     8ac:      	add	x11, x24, x10
     8b0:      	ldp	q6, q5, [x11]
     8b4:      	fmul.4s	v3, v3, v6
     8b8:      	fmul.4s	v4, v4, v5
     8bc:      	add	x10, x9, x10
     8c0:      	stp	q3, q4, [x10]
     8c4:      	add	x8, x8, #0x1
     8c8:      	cmp	x8, #0xc0
     8cc:      	b.ne	0x898 <ltmp0+0x898>
     8d0:      	dup.2s	v1, v1[0]
     8d4:      	fdiv.2s	v1, v7, v1
     8d8:      	fmul.2s	v0, v1, v0
     8dc:      	str	d0, [x28, x20]
     8e0:      	ldr	w25, [sp, #0x8c]
     8e4:      	ldr	x7, [sp, #0x80]
     8e8:      	ldr	w3, [sp, #0x74]
     8ec:      	b	0x70 <ltmp0+0x70>
     8f0:      	lsr	x8, x9, #3
     8f4:      	str	x8, [sp, #0xa0]
     8f8:      	str	x9, [sp, #0x50]
     8fc:      	cmp	x9, #0x8
     900:      	mov	w9, #0x1808             ; =6152
     904:      	b.lo	0xb48 <ltmp0+0xb48>
     908:      	mov	x27, #0x0               ; =0
     90c:      	ldr	x8, [sp, #0x48]
     910:      	ldr	x28, [x8]
     914:      	ldr	x22, [x8, #0x10]
     918:      	ldr	x21, [x8, #0x30]
     91c:      	mov	w8, #0x1800             ; =6144
     920:      	add	x8, x22, x8
     924:      	str	x8, [sp, #0x90]
     928:      	ldr	x8, [sp, #0x80]
     92c:      	lsl	w25, w8, #2
     930:      	and	x8, x8, #0x7ffffff
     934:      	mov	w10, #0x6020            ; =24608
     938:      	umaddl	x26, w8, w10, x21
     93c:      	add	w8, w27, w25
     940:      	and	x20, x8, #0x1fffffff
     944:      	umaddl	x1, w20, w9, x28
     948:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     94c:      	add	x0, x0, #0xbf0
     950:      	mov	w2, #0x1800             ; =6144
     954:      	mov	w23, #0x1808            ; =6152
     958:      	bl	0x958 <ltmp0+0x958>
     95c:      	mov	x8, #0x0                ; =0
     960:      	mov	w9, #0x1800             ; =6144
     964:      	umaddl	x20, w20, w23, x9
     968:      	add	x9, x28, x20
     96c:      	ldr	s0, [x9], #0x4
     970:      	ld1.s	{ v0 }[1], [x9]
     974:      	str	q0, [sp, #0x130]
     978:      	str	q0, [sp, #0x33f0]
     97c:      	ldr	q0, [sp, #0x1bf0]
     980:      	ldr	q1, [sp, #0x1c00]
     984:      	fmul.4s	v2, v1, v1
     988:      	fmul.4s	v17, v0, v0
     98c:      	ldr	q0, [sp, #0x1c10]
     990:      	ldr	q1, [sp, #0x1c20]
     994:      	fmul.4s	v4, v1, v1
     998:      	fmul.4s	v3, v0, v0
     99c:      	ldr	q0, [sp, #0x1c30]
     9a0:      	ldr	q1, [sp, #0x1c40]
     9a4:      	fmul.4s	v5, v1, v1
     9a8:      	fmul.4s	v6, v0, v0
     9ac:      	ldr	q0, [sp, #0x1c50]
     9b0:      	ldr	q1, [sp, #0x1c60]
     9b4:      	fmul.4s	v16, v1, v1
     9b8:      	fmul.4s	v7, v0, v0
     9bc:      	add	x9, x19, x8, lsl #5
     9c0:      	ldp	q1, q0, [x9, #0x80]
     9c4:      	fmul.4s	v1, v1, v1
     9c8:      	fmul.4s	v0, v0, v0
     9cc:      	fadd.4s	v2, v2, v0
     9d0:      	fadd.4s	v17, v17, v1
     9d4:      	ldp	q1, q0, [x9, #0xa0]
     9d8:      	fmul.4s	v1, v1, v1
     9dc:      	fmul.4s	v0, v0, v0
     9e0:      	fadd.4s	v4, v4, v0
     9e4:      	fadd.4s	v3, v3, v1
     9e8:      	ldp	q1, q0, [x9, #0xc0]
     9ec:      	fmul.4s	v1, v1, v1
     9f0:      	fmul.4s	v0, v0, v0
     9f4:      	fadd.4s	v5, v5, v0
     9f8:      	fadd.4s	v6, v6, v1
     9fc:      	ldp	q1, q0, [x9, #0xe0]
     a00:      	fmul.4s	v1, v1, v1
     a04:      	fmul.4s	v0, v0, v0
     a08:      	fadd.4s	v16, v16, v0
     a0c:      	fadd.4s	v7, v7, v1
     a10:      	add	x8, x8, #0x4
     a14:      	cmp	x8, #0xbc
     a18:      	b.lo	0x9bc <ltmp0+0x9bc>
     a1c:      	add	x0, sp, #0x3d0
     a20:      	mov	x1, x22
     a24:      	mov	w2, #0x1800             ; =6144
     a28:      	stp	q4, q2, [sp, #0xc0]
     a2c:      	stp	q6, q3, [sp, #0xe0]
     a30:      	stp	q5, q7, [sp, #0x110]
     a34:      	str	q16, [sp, #0x100]
     a38:      	str	q17, [sp, #0xb0]
     a3c:      	bl	0xa3c <ltmp0+0xa3c>
     a40:      	mov	x8, #0x0                ; =0
     a44:      	ldr	q7, [sp, #0x130]
     a48:      	fmul.4s	v0, v7, v7
     a4c:      	ldp	q2, q3, [sp, #0xb0]
     a50:      	fadd.4s	v1, v0, v2
     a54:      	mov.d	v1[1], v2[1]
     a58:      	mov	w9, #0x1804             ; =6148
     a5c:      	add	x9, x22, x9
     a60:      	ldr	x10, [sp, #0x90]
     a64:      	ldr	s0, [x10]
     a68:      	ld1.s	{ v0 }[1], [x9]
     a6c:      	ldr	q2, [sp, #0xd0]
     a70:      	fadd.4s	v2, v3, v2
     a74:      	ldp	q3, q4, [sp, #0xe0]
     a78:      	fadd.4s	v1, v4, v1
     a7c:      	fadd.4s	v1, v3, v1
     a80:      	ldp	q3, q4, [sp, #0x100]
     a84:      	fadd.4s	v2, v4, v2
     a88:      	fadd.4s	v2, v3, v2
     a8c:      	ldr	q3, [sp, #0x120]
     a90:      	fadd.4s	v1, v3, v1
     a94:      	rev64.4s	v3, v1
     a98:      	rev64.4s	v4, v2
     a9c:      	fadd.4s	v2, v2, v4
     aa0:      	fadd.4s	v1, v1, v3
     aa4:      	dup.4s	v3, v1[2]
     aa8:      	dup.4s	v4, v2[2]
     aac:      	fadd.4s	v2, v2, v4
     ab0:      	fadd.4s	v1, v1, v3
     ab4:      	fadd.4s	v1, v1, v2
     ab8:      	fadd	s1, s1, s8
     abc:      	mov	w9, #0x4000             ; =16384
     ac0:      	movk	w9, #0x44c0, lsl #16
     ac4:      	fmov	s2, w9
     ac8:      	fdiv	s1, s1, s2
     acc:      	str	q0, [sp, #0x1bd0]
     ad0:      	mov	w9, #0xc5ac             ; =50604
     ad4:      	movk	w9, #0x3727, lsl #16
     ad8:      	fmov	s2, w9
     adc:      	fadd	s1, s1, s2
     ae0:      	fsqrt	s1, s1
     ae4:      	dup.4s	v2, v1[0]
     ae8:      	lsl	x9, x8, #5
     aec:      	add	x10, x19, x9
     af0:      	ldp	q3, q4, [x10]
     af4:      	fdiv.4s	v4, v4, v2
     af8:      	fdiv.4s	v3, v3, v2
     afc:      	add	x10, x24, x9
     b00:      	ldp	q6, q5, [x10]
     b04:      	fmul.4s	v3, v3, v6
     b08:      	fmul.4s	v4, v4, v5
     b0c:      	add	x9, x26, x9
     b10:      	stp	q3, q4, [x9]
     b14:      	add	x8, x8, #0x1
     b18:      	cmp	x8, #0xc0
     b1c:      	b.ne	0xae8 <ltmp0+0xae8>
     b20:      	dup.2s	v1, v1[0]
     b24:      	fdiv.2s	v1, v7, v1
     b28:      	fmul.2s	v0, v1, v0
     b2c:      	str	d0, [x21, x20]
     b30:      	add	x27, x27, #0x1
     b34:      	mov	w9, #0x1808             ; =6152
     b38:      	add	x26, x26, x9
     b3c:      	ldr	x8, [sp, #0xa0]
     b40:      	cmp	x27, x8
     b44:      	b.ne	0x93c <ltmp0+0x93c>
     b48:      	mov	w14, #0x1808            ; =6152
     b4c:      	ldr	x8, [sp, #0x50]
     b50:      	and	w8, w8, #0x7
     b54:      	ldr	w3, [sp, #0x74]
     b58:      	ldr	w25, [sp, #0x8c]
     b5c:      	ldr	x7, [sp, #0x80]
     b60:      	cbz	w8, 0x70 <ltmp0+0x70>
     b64:      	dup.4s	v1, w8
     b68:      	adrp	x8, 0x0 <ltmp0>
     b6c:      	ldr	q2, [x8]
     b70:      	adrp	x8, 0x0 <ltmp0>
     b74:      	ldr	q0, [x8]
     b78:      	cmhi.4s	v0, v1, v0
     b7c:      	cmhi.4s	v1, v1, v2
     b80:      	uzp1.8h	v3, v1, v0
     b84:      	umaxv.8h	h2, v3
     b88:      	fmov	w8, s2
     b8c:      	mov	w17, #0x4               ; =4
     b90:      	tbz	w8, #0x0, 0x6c <ltmp0+0x6c>
     b94:      	mov	x9, #0x0                ; =0
     b98:      	ldr	x8, [sp, #0x48]
     b9c:      	ldr	x12, [x8]
     ba0:      	ldr	x10, [x8, #0x10]
     ba4:      	ldr	x8, [x8, #0x30]
     ba8:      	adrp	x11, 0x0 <ltmp0>
     bac:      	ldr	q2, [x11]
     bb0:      	and.16b	v2, v3, v2
     bb4:      	addv.8h	h2, v2
     bb8:      	ubfiz	w11, w7, #2, #27
     bbc:      	ldr	x13, [sp, #0xa0]
     bc0:      	orr	w13, w11, w13
     bc4:      	fmov	w11, s2
     bc8:      	and	w11, w11, #0xff
     bcc:      	dup.4s	v4, w13
     bd0:      	and.16b	v5, v1, v4
     bd4:      	and.16b	v4, v0, v4
     bd8:      	ushll2.2d	v7, v4, #0x0
     bdc:      	ushll2.2d	v16, v5, #0x0
     be0:      	ushll.2d	v17, v4, #0x0
     be4:      	ushll.2d	v4, v5, #0x0
     be8:      	fmov	x13, d4
     bec:      	umaddl	x13, w13, w14, x12
     bf0:      	b	0xc14 <ltmp0+0xc14>
     bf4:      	add	x14, x19, x9, lsl #5
     bf8:      	ldp	q18, q19, [x14]
     bfc:      	bif.16b	v6, v19, v0
     c00:      	bif.16b	v5, v18, v1
     c04:      	stp	q5, q6, [x14]
     c08:      	add	x9, x9, #0x1
     c0c:      	cmp	x9, #0xc0
     c10:      	b.eq	0xcac <ltmp0+0xcac>
     c14:      	fmov	w15, s2
     c18:      	add	x14, x13, x9, lsl #5
     c1c:      	movi.2d	v5, #0000000000000000
     c20:      	movi.2d	v6, #0000000000000000
     c24:      	tbnz	w15, #0x0, 0xc4c <ltmp0+0xc4c>
     c28:      	and	w15, w15, #0xff
     c2c:      	tbnz	w15, #0x1, 0xc58 <ltmp0+0xc58>
     c30:      	tbnz	w15, #0x2, 0xc64 <ltmp0+0xc64>
     c34:      	tbnz	w15, #0x3, 0xc70 <ltmp0+0xc70>
     c38:      	tbnz	w15, #0x4, 0xc7c <ltmp0+0xc7c>
     c3c:      	tbnz	w15, #0x5, 0xc88 <ltmp0+0xc88>
     c40:      	tbnz	w15, #0x6, 0xc94 <ltmp0+0xc94>
     c44:      	tbz	w15, #0x7, 0xbf4 <ltmp0+0xbf4>
     c48:      	b	0xca0 <ltmp0+0xca0>
     c4c:      	ldr	s5, [x14]
     c50:      	and	w15, w15, #0xff
     c54:      	tbz	w15, #0x1, 0xc30 <ltmp0+0xc30>
     c58:      	add	x16, x14, #0x4
     c5c:      	ld1.s	{ v5 }[1], [x16]
     c60:      	tbz	w15, #0x2, 0xc34 <ltmp0+0xc34>
     c64:      	add	x16, x14, #0x8
     c68:      	ld1.s	{ v5 }[2], [x16]
     c6c:      	tbz	w15, #0x3, 0xc38 <ltmp0+0xc38>
     c70:      	add	x16, x14, #0xc
     c74:      	ld1.s	{ v5 }[3], [x16]
     c78:      	tbz	w15, #0x4, 0xc3c <ltmp0+0xc3c>
     c7c:      	add	x16, x14, #0x10
     c80:      	ld1.s	{ v6 }[0], [x16]
     c84:      	tbz	w15, #0x5, 0xc40 <ltmp0+0xc40>
     c88:      	add	x16, x14, #0x14
     c8c:      	ld1.s	{ v6 }[1], [x16]
     c90:      	tbz	w15, #0x6, 0xc44 <ltmp0+0xc44>
     c94:      	add	x16, x14, #0x18
     c98:      	ld1.s	{ v6 }[2], [x16]
     c9c:      	tbz	w15, #0x7, 0xbf4 <ltmp0+0xbf4>
     ca0:      	add	x14, x14, #0x1c
     ca4:      	ld1.s	{ v6 }[3], [x14]
     ca8:      	b	0xbf4 <ltmp0+0xbf4>
     cac:      	xtn.8b	v24, v3
     cb0:      	sshll.2d	v18, v1, #0x0
     cb4:      	adrp	x9, 0x0 <ltmp0>
     cb8:      	ldr	q3, [x9]
     cbc:      	and.16b	v5, v18, v3
     cc0:      	movi	d3, #0x0000000000ffff
     cc4:      	and.8b	v6, v24, v3
     cc8:      	adrp	x9, 0x0 <ltmp0>
     ccc:      	ldr	d3, [x9]
     cd0:      	and.8b	v3, v24, v3
     cd4:      	addv.8b	b3, v3
     cd8:      	fmov	w13, s3
     cdc:      	umaxv.8b	b3, v6
     ce0:      	fmov	w9, s3
     ce4:      	rbit	w14, w13
     ce8:      	clz	w14, w14
     cec:      	tst	w9, #0x1
     cf0:      	csel	w9, w14, wzr, ne
     cf4:      	mov	w14, #0x600             ; =1536
     cf8:      	dup.2d	v22, x14
     cfc:      	str	q5, [sp, #0x50]
     d00:      	orr.16b	v3, v5, v22
     d04:      	mov	w14, #0x602             ; =1538
     d08:      	dup.2s	v19, w14
     d0c:      	xtn.2s	v23, v4
     d10:      	str	q3, [sp, #0xc0]
     d14:      	mov.16b	v4, v3
     d18:      	umlal.2d	v4, v23, v19
     d1c:      	mov	b3, v6[0]
     d20:      	mov.b	v3[4], v6[1]
     d24:      	ushll.2d	v3, v3, #0x0
     d28:      	shl.2d	v3, v3, #0x3f
     d2c:      	cmlt.2d	v3, v3, #0
     d30:      	str	q4, [sp, #0x120]
     d34:      	and.16b	v3, v3, v4
     d38:      	movi.2d	v4, #0000000000000000
     d3c:      	stp	q4, q4, [sp, #0x3a0]
     d40:      	stp	q3, q4, [sp, #0x380]
     d44:      	and	x14, x9, #0x7
     d48:      	add	x15, sp, #0x380
     d4c:      	ldr	x14, [x15, x14, lsl #3]
     d50:      	sub	x14, x14, x9
     d54:      	add	x12, x12, x14, lsl #2
     d58:      	movi.2d	v5, #0000000000000000
     d5c:      	movi.2d	v3, #0000000000000000
     d60:      	tbnz	w13, #0x0, 0x16c0 <ltmp0+0x16c0>
     d64:      	tbnz	w13, #0x1, 0x16c8 <ltmp0+0x16c8>
     d68:      	tbnz	w13, #0x2, 0x16d4 <ltmp0+0x16d4>
     d6c:      	tbnz	w13, #0x3, 0x16e0 <ltmp0+0x16e0>
     d70:      	tbnz	w13, #0x4, 0x16ec <ltmp0+0x16ec>
     d74:      	tbnz	w13, #0x5, 0x16f8 <ltmp0+0x16f8>
     d78:      	tbnz	w13, #0x6, 0x1704 <ltmp0+0x1704>
     d7c:      	tbz	w13, #0x7, 0xd88 <ltmp0+0xd88>
     d80:      	add	x12, x12, #0x1c
     d84:      	ld1.s	{ v3 }[3], [x12]
     d88:      	sshll.2d	v4, v0, #0x0
     d8c:      	sshll2.2d	v20, v1, #0x0
     d90:      	sshll2.2d	v21, v0, #0x0
     d94:      	adrp	x12, 0x0 <ltmp0>
     d98:      	ldr	q25, [x12]
     d9c:      	and.16b	v30, v21, v25
     da0:      	adrp	x12, 0x0 <ltmp0>
     da4:      	ldr	q25, [x12]
     da8:      	and.16b	v29, v20, v25
     dac:      	adrp	x12, 0x0 <ltmp0>
     db0:      	ldr	q25, [x12]
     db4:      	and.16b	v28, v4, v25
     db8:      	adrp	x12, 0x0 <ltmp0>
     dbc:      	ldr	q25, [x12]
     dc0:      	and.16b	v25, v21, v25
     dc4:      	adrp	x12, 0x0 <ltmp0>
     dc8:      	ldr	q26, [x12]
     dcc:      	and.16b	v26, v20, v26
     dd0:      	adrp	x12, 0x0 <ltmp0>
     dd4:      	ldr	q27, [x12]
     dd8:      	and.16b	v27, v4, v27
     ddc:      	adrp	x12, 0x0 <ltmp0>
     de0:      	ldr	q4, [x12]
     de4:      	and.16b	v4, v18, v4
     de8:      	stp	q28, q29, [sp, #0x10]
     dec:      	orr.16b	v28, v28, v22
     df0:      	orr.16b	v29, v29, v22
     df4:      	str	q30, [sp, #0x30]
     df8:      	orr.16b	v22, v30, v22
     dfc:      	umull.2d	v30, v23, v19
     e00:      	xtn.2s	v16, v16
     e04:      	xtn.2s	v17, v17
     e08:      	xtn.2s	v7, v7
     e0c:      	stp	q28, q22, [sp, #0xa0]
     e10:      	mov.16b	v18, v22
     e14:      	umlal.2d	v18, v7, v19
     e18:      	str	q29, [sp, #0x90]
     e1c:      	mov.16b	v7, v29
     e20:      	umlal.2d	v7, v16, v19
     e24:      	stp	q7, q18, [sp, #0xf0]
     e28:      	mov.16b	v7, v28
     e2c:      	umlal.2d	v7, v17, v19
     e30:      	stp	q30, q7, [sp, #0xd0]
     e34:      	sshll.2d	v7, v1, #0x0
     e38:      	sshll.2d	v18, v0, #0x0
     e3c:      	stp	q4, q26, [sp, #0x340]
     e40:      	stp	q27, q25, [sp, #0x360]
     e44:      	and	x12, x9, #0x7
     e48:      	add	x14, sp, #0x340
     e4c:      	ldr	x12, [x14, x12, lsl #3]
     e50:      	orr	x12, x12, #0x1800
     e54:      	sub	x12, x12, x9, lsl #2
     e58:      	tst	w13, #0xff
     e5c:      	csel	x12, xzr, x12, eq
     e60:      	add	x13, x19, x12
     e64:      	ldp	q16, q17, [x13]
     e68:      	zip2.8b	v19, v6, v0
     e6c:      	ushll.4s	v19, v19, #0x0
     e70:      	shl.4s	v19, v19, #0x1f
     e74:      	cmlt.4s	v19, v19, #0
     e78:      	str	q3, [sp, #0x130]
     e7c:      	bit.16b	v17, v3, v19
     e80:      	zip1.8b	v19, v6, v0
     e84:      	ushll.4s	v19, v19, #0x0
     e88:      	shl.4s	v19, v19, #0x1f
     e8c:      	cmlt.4s	v19, v19, #0
     e90:      	str	q5, [sp, #0x110]
     e94:      	bit.16b	v16, v5, v19
     e98:      	stp	q16, q17, [x13]
     e9c:      	dup.2d	v19, x17
     ea0:      	and.16b	v16, v21, v19
     ea4:      	and.16b	v17, v20, v19
     ea8:      	and.16b	v22, v18, v19
     eac:      	and.16b	v23, v7, v19
     eb0:      	fmov	x13, d23
     eb4:      	ldr	q7, [sp, #0x1c60]
     eb8:      	ldr	q18, [sp, #0x1c50]
     ebc:      	fmul.4s	v18, v18, v18
     ec0:      	fmul.4s	v7, v7, v7
     ec4:      	and.16b	v11, v0, v7
     ec8:      	and.16b	v12, v1, v18
     ecc:      	ldr	q7, [sp, #0x1c40]
     ed0:      	ldr	q18, [sp, #0x1c30]
     ed4:      	fmul.4s	v18, v18, v18
     ed8:      	fmul.4s	v7, v7, v7
     edc:      	and.16b	v14, v0, v7
     ee0:      	and.16b	v13, v1, v18
     ee4:      	ldr	q7, [sp, #0x1c20]
     ee8:      	ldr	q18, [sp, #0x1c10]
     eec:      	fmul.4s	v18, v18, v18
     ef0:      	fmul.4s	v7, v7, v7
     ef4:      	and.16b	v15, v0, v7
     ef8:      	and.16b	v9, v1, v18
     efc:      	fmov	x14, d4
     f00:      	add	x14, x19, x14
     f04:      	ldp	q7, q4, [x14]
     f08:      	fmul.4s	v7, v7, v7
     f0c:      	fmul.4s	v4, v4, v4
     f10:      	and.16b	v18, v0, v4
     f14:      	and.16b	v10, v1, v7
     f18:      	sshll.2d	v4, v1, #0x0
     f1c:      	sshll.2d	v25, v0, #0x0
     f20:      	add	x13, x19, x13, lsl #5
     f24:      	ldp	q19, q7, [x13]
     f28:      	and.16b	v19, v1, v19
     f2c:      	and.16b	v7, v0, v7
     f30:      	fmul.4s	v7, v7, v7
     f34:      	fmul.4s	v19, v19, v19
     f38:      	fadd.4s	v19, v10, v19
     f3c:      	fadd.4s	v7, v18, v7
     f40:      	ldp	q27, q26, [x13, #0x20]
     f44:      	and.16b	v27, v1, v27
     f48:      	and.16b	v26, v0, v26
     f4c:      	fmul.4s	v26, v26, v26
     f50:      	fmul.4s	v27, v27, v27
     f54:      	fadd.4s	v27, v9, v27
     f58:      	fadd.4s	v26, v15, v26
     f5c:      	ldp	q5, q28, [x13, #0x40]
     f60:      	and.16b	v5, v1, v5
     f64:      	and.16b	v28, v0, v28
     f68:      	fmul.4s	v28, v28, v28
     f6c:      	fmul.4s	v5, v5, v5
     f70:      	fadd.4s	v5, v13, v5
     f74:      	fadd.4s	v28, v14, v28
     f78:      	ldp	q30, q29, [x13, #0x60]
     f7c:      	and.16b	v30, v1, v30
     f80:      	and.16b	v29, v0, v29
     f84:      	fmul.4s	v29, v29, v29
     f88:      	fmul.4s	v30, v30, v30
     f8c:      	fadd.4s	v30, v12, v30
     f90:      	fadd.4s	v29, v11, v29
     f94:      	dup.2d	v31, x17
     f98:      	and.16b	v3, v21, v31
     f9c:      	add.2d	v16, v16, v3
     fa0:      	and.16b	v3, v20, v31
     fa4:      	add.2d	v17, v17, v3
     fa8:      	and.16b	v3, v25, v31
     fac:      	add.2d	v22, v22, v3
     fb0:      	and.16b	v3, v4, v31
     fb4:      	add.2d	v23, v23, v3
     fb8:      	bit.16b	v18, v7, v0
     fbc:      	bit.16b	v10, v19, v1
     fc0:      	bit.16b	v15, v26, v0
     fc4:      	bit.16b	v9, v27, v1
     fc8:      	bit.16b	v14, v28, v0
     fcc:      	bit.16b	v13, v5, v1
     fd0:      	bit.16b	v11, v29, v0
     fd4:      	bit.16b	v12, v30, v1
     fd8:      	fmov	x13, d23
     fdc:      	cmp	x13, #0xc0
     fe0:      	b.lt	0xf18 <ltmp0+0xf18>
     fe4:      	mov	x13, #0x0               ; =0
     fe8:      	mov	w14, #0x1               ; =1
     fec:      	dup.2d	v3, x14
     ff0:      	ushll2.2d	v4, v0, #0x0
     ff4:      	and.16b	v20, v4, v3
     ff8:      	ushll2.2d	v4, v1, #0x0
     ffc:      	and.16b	v21, v4, v3
    1000:      	ushll.2d	v4, v0, #0x0
    1004:      	and.16b	v22, v4, v3
    1008:      	ushll.2d	v4, v1, #0x0
    100c:      	and.16b	v23, v4, v3
    1010:      	movi.2d	v16, #0000000000000000
    1014:      	movi.2d	v17, #0000000000000000
    1018:      	movi.2d	v25, #0000000000000000
    101c:      	movi.2d	v26, #0000000000000000
    1020:      	ldr	q29, [sp, #0x130]
    1024:      	ldr	q30, [sp, #0x110]
    1028:      	b	0x105c <ltmp0+0x105c>
    102c:      	add	x13, x24, x13
    1030:      	ldp	q3, q5, [x13]
    1034:      	bif.16b	v4, v5, v0
    1038:      	bit.16b	v3, v27, v1
    103c:      	stp	q3, q4, [x13]
    1040:      	add.2d	v17, v17, v21
    1044:      	add.2d	v25, v25, v22
    1048:      	add.2d	v26, v26, v20
    104c:      	add.2d	v16, v16, v23
    1050:      	fmov	x13, d16
    1054:      	cmp	x13, #0xc0
    1058:      	b.ge	0x10f8 <ltmp0+0x10f8>
    105c:      	fmov	w15, s2
    1060:      	lsl	x13, x13, #5
    1064:      	add	x14, x10, x13
    1068:      	movi.2d	v27, #0000000000000000
    106c:      	movi.2d	v4, #0000000000000000
    1070:      	tbnz	w15, #0x0, 0x1098 <ltmp0+0x1098>
    1074:      	and	w15, w15, #0xff
    1078:      	tbnz	w15, #0x1, 0x10a4 <ltmp0+0x10a4>
    107c:      	tbnz	w15, #0x2, 0x10b0 <ltmp0+0x10b0>
    1080:      	tbnz	w15, #0x3, 0x10bc <ltmp0+0x10bc>
    1084:      	tbnz	w15, #0x4, 0x10c8 <ltmp0+0x10c8>
    1088:      	tbnz	w15, #0x5, 0x10d4 <ltmp0+0x10d4>
    108c:      	tbnz	w15, #0x6, 0x10e0 <ltmp0+0x10e0>
    1090:      	tbz	w15, #0x7, 0x102c <ltmp0+0x102c>
    1094:      	b	0x10ec <ltmp0+0x10ec>
    1098:      	ldr	s27, [x14]
    109c:      	and	w15, w15, #0xff
    10a0:      	tbz	w15, #0x1, 0x107c <ltmp0+0x107c>
    10a4:      	add	x16, x14, #0x4
    10a8:      	ld1.s	{ v27 }[1], [x16]
    10ac:      	tbz	w15, #0x2, 0x1080 <ltmp0+0x1080>
    10b0:      	add	x16, x14, #0x8
    10b4:      	ld1.s	{ v27 }[2], [x16]
    10b8:      	tbz	w15, #0x3, 0x1084 <ltmp0+0x1084>
    10bc:      	add	x16, x14, #0xc
    10c0:      	ld1.s	{ v27 }[3], [x16]
    10c4:      	tbz	w15, #0x4, 0x1088 <ltmp0+0x1088>
    10c8:      	add	x16, x14, #0x10
    10cc:      	ld1.s	{ v4 }[0], [x16]
    10d0:      	tbz	w15, #0x5, 0x108c <ltmp0+0x108c>
    10d4:      	add	x16, x14, #0x14
    10d8:      	ld1.s	{ v4 }[1], [x16]
    10dc:      	tbz	w15, #0x6, 0x1090 <ltmp0+0x1090>
    10e0:      	add	x16, x14, #0x18
    10e4:      	ld1.s	{ v4 }[2], [x16]
    10e8:      	tbz	w15, #0x7, 0x102c <ltmp0+0x102c>
    10ec:      	add	x14, x14, #0x1c
    10f0:      	ld1.s	{ v4 }[3], [x14]
    10f4:      	b	0x102c <ltmp0+0x102c>
    10f8:      	movi	d3, #0xffffffffffff0000
    10fc:      	and.8b	v3, v24, v3
    1100:      	fmul.4s	v4, v30, v30
    1104:      	fmul.4s	v5, v29, v29
    1108:      	fadd.4s	v5, v5, v18
    110c:      	fadd.4s	v4, v4, v10
    1110:      	zip1.8b	v16, v6, v0
    1114:      	ushll.4s	v16, v16, #0x0
    1118:      	shl.4s	v16, v16, #0x1f
    111c:      	cmlt.4s	v16, v16, #0
    1120:      	and.16b	v4, v16, v4
    1124:      	zip2.8b	v16, v6, v0
    1128:      	ushll.4s	v16, v16, #0x0
    112c:      	shl.4s	v16, v16, #0x1f
    1130:      	cmlt.4s	v16, v16, #0
    1134:      	and.16b	v5, v16, v5
    1138:      	zip2.8b	v16, v3, v0
    113c:      	ushll.4s	v16, v16, #0x0
    1140:      	shl.4s	v16, v16, #0x1f
    1144:      	cmlt.4s	v16, v16, #0
    1148:      	bit.16b	v5, v7, v16
    114c:      	zip1.8b	v3, v3, v0
    1150:      	ushll.4s	v3, v3, #0x0
    1154:      	shl.4s	v3, v3, #0x1f
    1158:      	cmlt.4s	v3, v3, #0
    115c:      	bsl.16b	v3, v19, v4
    1160:      	fadd.4s	v3, v9, v3
    1164:      	fadd.4s	v4, v15, v5
    1168:      	fadd.4s	v4, v14, v4
    116c:      	fadd.4s	v3, v13, v3
    1170:      	fadd.4s	v18, v12, v3
    1174:      	fadd.4s	v19, v11, v4
    1178:      	ldr	q3, [sp, #0x50]
    117c:      	ldp	q4, q5, [sp, #0x10]
    1180:      	uzp1.4s	v7, v3, v5
    1184:      	ldr	q3, [sp, #0x30]
    1188:      	uzp1.4s	v28, v4, v3
    118c:      	movi.4s	v4, #0x1
    1190:      	eor.16b	v3, v7, v4
    1194:      	mov.s	w14, v3[1]
    1198:      	mov.s	w17, v3[2]
    119c:      	eor.16b	v25, v28, v4
    11a0:      	mov.s	w0, v3[3]
    11a4:      	fmov	w13, s3
    11a8:      	add	x15, sp, #0x188
    11ac:      	bfxil	x15, x13, #0, #3
    11b0:      	str	d24, [sp, #0x188]
    11b4:      	ldrb	w16, [x15]
    11b8:      	and	x15, x13, #0x7
    11bc:      	umov.b	w13, v24[0]
    11c0:      	stp	q18, q19, [sp, #0x290]
    11c4:      	add	x1, sp, #0x290
    11c8:      	ldr	s3, [x1, x15, lsl #2]
    11cc:      	ands	w15, w13, #0x1
    11d0:      	tst	w15, w16
    11d4:      	fcsel	s16, s3, s8, ne
    11d8:      	add	x16, sp, #0x188
    11dc:      	bfxil	x16, x14, #0, #3
    11e0:      	ldrb	w16, [x16]
    11e4:      	and	x1, x14, #0x7
    11e8:      	umov.b	w14, v24[1]
    11ec:      	stp	q18, q19, [sp, #0x270]
    11f0:      	add	x2, sp, #0x270
    11f4:      	ldr	s3, [x2, x1, lsl #2]
    11f8:      	ands	w1, w14, #0x1
    11fc:      	tst	w1, w16
    1200:      	fcsel	s17, s3, s8, ne
    1204:      	add	x16, sp, #0x188
    1208:      	bfxil	x16, x17, #0, #3
    120c:      	ldrb	w1, [x16]
    1210:      	umov.b	w16, v24[2]
    1214:      	and	x17, x17, #0x7
    1218:      	stp	q18, q19, [sp, #0x250]
    121c:      	add	x2, sp, #0x250
    1220:      	ldr	s3, [x2, x17, lsl #2]
    1224:      	ands	w17, w16, #0x1
    1228:      	tst	w17, w1
    122c:      	fcsel	s4, s3, s8, ne
    1230:      	add	x17, sp, #0x188
    1234:      	bfxil	x17, x0, #0, #3
    1238:      	ldrb	w1, [x17]
    123c:      	and	x0, x0, #0x7
    1240:      	umov.b	w17, v24[3]
    1244:      	stp	q18, q19, [sp, #0x230]
    1248:      	add	x2, sp, #0x230
    124c:      	ldr	s3, [x2, x0, lsl #2]
    1250:      	ands	w0, w17, #0x1
    1254:      	tst	w0, w1
    1258:      	mov.s	w1, v25[1]
    125c:      	mov.s	w2, v25[2]
    1260:      	fcsel	s26, s3, s8, ne
    1264:      	mov.s	w4, v25[3]
    1268:      	fmov	w0, s25
    126c:      	and	x20, x0, #0x7
    1270:      	add	x5, sp, #0x188
    1274:      	bfxil	x5, x0, #0, #3
    1278:      	ldrb	w5, [x5]
    127c:      	umov.b	w0, v24[4]
    1280:      	and	w5, w0, w5
    1284:      	stp	q18, q19, [sp, #0x310]
    1288:      	add	x6, sp, #0x310
    128c:      	ldr	s3, [x6, x20, lsl #2]
    1290:      	tst	w5, #0x1
    1294:      	fcsel	s3, s3, s8, ne
    1298:      	add	x5, sp, #0x188
    129c:      	bfxil	x5, x1, #0, #3
    12a0:      	ldrb	w20, [x5]
    12a4:      	and	x5, x1, #0x7
    12a8:      	umov.b	w1, v24[5]
    12ac:      	stp	q18, q19, [sp, #0x2f0]
    12b0:      	add	x6, sp, #0x2f0
    12b4:      	ldr	s5, [x6, x5, lsl #2]
    12b8:      	ands	w5, w1, #0x1
    12bc:      	tst	w5, w20
    12c0:      	fcsel	s5, s5, s8, ne
    12c4:      	add	x5, sp, #0x188
    12c8:      	bfxil	x5, x2, #0, #3
    12cc:      	ldrb	w20, [x5]
    12d0:      	and	x5, x2, #0x7
    12d4:      	umov.b	w2, v24[6]
    12d8:      	stp	q18, q19, [sp, #0x2d0]
    12dc:      	add	x6, sp, #0x2d0
    12e0:      	ldr	s25, [x6, x5, lsl #2]
    12e4:      	ands	w5, w2, #0x1
    12e8:      	tst	w5, w20
    12ec:      	fcsel	s25, s25, s8, ne
    12f0:      	add	x5, sp, #0x188
    12f4:      	bfxil	x5, x4, #0, #3
    12f8:      	ldrb	w5, [x5]
    12fc:      	umov.b	w20, v24[7]
    1300:      	and	x4, x4, #0x7
    1304:      	stp	q18, q19, [sp, #0x2b0]
    1308:      	add	x6, sp, #0x2b0
    130c:      	ldr	s24, [x6, x4, lsl #2]
    1310:      	ands	w4, w20, #0x1
    1314:      	tst	w4, w5
    1318:      	fcsel	s24, s24, s8, ne
    131c:      	mov.s	v3[1], v5[0]
    1320:      	mov.s	v3[2], v25[0]
    1324:      	mov.s	v3[3], v24[0]
    1328:      	mov.s	v16[1], v17[0]
    132c:      	mov.s	v16[2], v4[0]
    1330:      	mov.s	v16[3], v26[0]
    1334:      	fadd.4s	v4, v18, v16
    1338:      	fadd.4s	v3, v19, v3
    133c:      	movi.4s	v16, #0x2
    1340:      	eor.16b	v5, v28, v16
    1344:      	eor.16b	v7, v7, v16
    1348:      	fmov	w4, s7
    134c:      	add	x5, sp, #0x188
    1350:      	bfxil	x5, x4, #0, #3
    1354:      	ldrb	w5, [x5]
    1358:      	and	x4, x4, #0x7
    135c:      	stp	q4, q3, [sp, #0x210]
    1360:      	add	x6, sp, #0x210
    1364:      	ldr	s7, [x6, x4, lsl #2]
    1368:      	tst	w15, w5
    136c:      	fcsel	s7, s7, s8, ne
    1370:      	fmov	w4, s5
    1374:      	and	x5, x4, #0x7
    1378:      	add	x6, sp, #0x188
    137c:      	bfxil	x6, x4, #0, #3
    1380:      	ldrb	w4, [x6]
    1384:      	and	w4, w0, w4
    1388:      	stp	q4, q3, [sp, #0x1f0]
    138c:      	add	x6, sp, #0x1f0
    1390:      	ldr	s5, [x6, x5, lsl #2]
    1394:      	tst	w4, #0x1
    1398:      	fcsel	s5, s5, s8, ne
    139c:      	fadd.4s	v3, v3, v5
    13a0:      	tst	w15, w0
    13a4:      	fcsel	s3, s3, s8, ne
    13a8:      	ands	w13, w13, #0x1
    13ac:      	fadd.4s	v4, v4, v7
    13b0:      	fadd	s3, s4, s3
    13b4:      	fcsel	s4, s3, s8, ne
    13b8:      	tst	w14, #0x1
    13bc:      	fcsel	s5, s4, s8, ne
    13c0:      	tst	w16, #0x1
    13c4:      	fcsel	s7, s4, s8, ne
    13c8:      	tst	w17, #0x1
    13cc:      	fcsel	s16, s4, s8, ne
    13d0:      	tst	w13, w0
    13d4:      	fcsel	s3, s3, s8, ne
    13d8:      	tst	w1, #0x1
    13dc:      	fcsel	s17, s4, s8, ne
    13e0:      	tst	w2, #0x1
    13e4:      	fcsel	s18, s4, s8, ne
    13e8:      	tst	w20, #0x1
    13ec:      	adrp	x13, 0x1000 <ltmp0+0x1000>
    13f0:      	ldr	d19, [x13]
    13f4:      	shl.8b	v24, v6, #0x7
    13f8:      	cmlt.8b	v24, v24, #0
    13fc:      	and.8b	v19, v24, v19
    1400:      	addv.8b	b24, v19
    1404:      	fmov	w13, s24
    1408:      	fcsel	s19, s4, s8, ne
    140c:      	mov.s	v4[1], v5[0]
    1410:      	mov.s	v4[2], v7[0]
    1414:      	mov.s	v4[3], v16[0]
    1418:      	mov.s	v3[1], v17[0]
    141c:      	mov.s	v3[2], v18[0]
    1420:      	mov.s	v3[3], v19[0]
    1424:      	rbit	w11, w11
    1428:      	clz	w11, w11
    142c:      	stp	q4, q3, [sp, #0x1d0]
    1430:      	and	x11, x11, #0x7
    1434:      	add	x14, sp, #0x1d0
    1438:      	ldr	s19, [x14, x11, lsl #2]
    143c:      	mov	b3, v6[0]
    1440:      	mov.b	v3[4], v6[1]
    1444:      	ushll.2d	v3, v3, #0x0
    1448:      	shl.2d	v3, v3, #0x3f
    144c:      	cmlt.2d	v3, v3, #0
    1450:      	mov	b4, v6[2]
    1454:      	mov.b	v4[4], v6[3]
    1458:      	ldp	q16, q5, [sp, #0xb0]
    145c:      	and.16b	v3, v3, v5
    1460:      	ushll.2d	v4, v4, #0x0
    1464:      	shl.2d	v4, v4, #0x3f
    1468:      	cmlt.2d	v4, v4, #0
    146c:      	ldp	q5, q7, [sp, #0x90]
    1470:      	and.16b	v4, v4, v5
    1474:      	mov	b5, v6[4]
    1478:      	mov.b	v5[4], v6[5]
    147c:      	ushll.2d	v5, v5, #0x0
    1480:      	shl.2d	v5, v5, #0x3f
    1484:      	cmlt.2d	v5, v5, #0
    1488:      	and.16b	v5, v5, v7
    148c:      	mov	b7, v6[6]
    1490:      	mov.b	v7[4], v6[7]
    1494:      	ushll.2d	v7, v7, #0x0
    1498:      	shl.2d	v7, v7, #0x3f
    149c:      	cmlt.2d	v7, v7, #0
    14a0:      	and.16b	v7, v7, v16
    14a4:      	stp	q5, q7, [sp, #0x1b0]
    14a8:      	stp	q3, q4, [sp, #0x190]
    14ac:      	and	x11, x9, #0x7
    14b0:      	add	x14, sp, #0x190
    14b4:      	ldr	x11, [x14, x11, lsl #3]
    14b8:      	sub	x11, x11, x9
    14bc:      	add	x10, x10, x11, lsl #2
    14c0:      	movi.2d	v7, #0000000000000000
    14c4:      	movi.2d	v18, #0000000000000000
    14c8:      	tbnz	w13, #0x0, 0x1714 <ltmp0+0x1714>
    14cc:      	tbnz	w13, #0x1, 0x171c <ltmp0+0x171c>
    14d0:      	tbnz	w13, #0x2, 0x1728 <ltmp0+0x1728>
    14d4:      	tbnz	w13, #0x3, 0x1734 <ltmp0+0x1734>
    14d8:      	tbnz	w13, #0x4, 0x1740 <ltmp0+0x1740>
    14dc:      	tbnz	w13, #0x5, 0x174c <ltmp0+0x174c>
    14e0:      	tbnz	w13, #0x6, 0x1758 <ltmp0+0x1758>
    14e4:      	tbz	w13, #0x7, 0x14f0 <ltmp0+0x14f0>
    14e8:      	add	x10, x10, #0x1c
    14ec:      	ld1.s	{ v18 }[3], [x10]
    14f0:      	mov	x11, #0x0               ; =0
    14f4:      	fadd	s3, s19, s8
    14f8:      	mov	w10, #0x4000            ; =16384
    14fc:      	movk	w10, #0x44c0, lsl #16
    1500:      	fmov	s4, w10
    1504:      	fdiv	s3, s3, s4
    1508:      	add	x10, x24, x12
    150c:      	ldp	q4, q5, [x10]
    1510:      	zip2.8b	v16, v6, v0
    1514:      	ushll.4s	v16, v16, #0x0
    1518:      	shl.4s	v16, v16, #0x1f
    151c:      	cmlt.4s	v16, v16, #0
    1520:      	bit.16b	v5, v18, v16
    1524:      	zip1.8b	v6, v6, v0
    1528:      	ushll.4s	v6, v6, #0x0
    152c:      	shl.4s	v6, v6, #0x1f
    1530:      	cmlt.4s	v6, v6, #0
    1534:      	bit.16b	v4, v7, v6
    1538:      	stp	q4, q5, [x10]
    153c:      	mov	w10, #0xc5ac            ; =50604
    1540:      	movk	w10, #0x3727, lsl #16
    1544:      	fmov	s4, w10
    1548:      	fadd	s3, s3, s4
    154c:      	fsqrt	s3, s3
    1550:      	dup.4s	v6, v3[0]
    1554:      	ldr	q3, [sp, #0xd0]
    1558:      	fmov	x10, d3
    155c:      	add	x10, x8, x10, lsl #2
    1560:      	movi.2d	v4, #0000000000000000
    1564:      	movi.2d	v16, #0000000000000000
    1568:      	movi.2d	v17, #0000000000000000
    156c:      	movi.2d	v19, #0000000000000000
    1570:      	b	0x1590 <ltmp0+0x1590>
    1574:      	add.2d	v16, v16, v21
    1578:      	add.2d	v17, v17, v22
    157c:      	add.2d	v19, v19, v20
    1580:      	add.2d	v4, v4, v23
    1584:      	fmov	x11, d4
    1588:      	cmp	x11, #0xc0
    158c:      	b.ge	0x1660 <ltmp0+0x1660>
    1590:      	fmov	w12, s2
    1594:      	lsl	x11, x11, #5
    1598:      	add	x13, x19, x11
    159c:      	ldp	q3, q25, [x13]
    15a0:      	and.16b	v3, v1, v3
    15a4:      	fdiv.4s	v3, v3, v6
    15a8:      	add	x13, x24, x11
    15ac:      	ldp	q5, q26, [x13]
    15b0:      	and.16b	v5, v1, v5
    15b4:      	fmul.4s	v27, v3, v5
    15b8:      	add	x11, x10, x11
    15bc:      	tbnz	w12, #0x0, 0x15f4 <ltmp0+0x15f4>
    15c0:      	and	w12, w12, #0xff
    15c4:      	tbnz	w12, #0x1, 0x1600 <ltmp0+0x1600>
    15c8:      	tbnz	w12, #0x2, 0x160c <ltmp0+0x160c>
    15cc:      	tbnz	w12, #0x3, 0x1618 <ltmp0+0x1618>
    15d0:      	and.16b	v3, v0, v25
    15d4:      	fdiv.4s	v3, v3, v6
    15d8:      	and.16b	v5, v0, v26
    15dc:      	fmul.4s	v25, v3, v5
    15e0:      	tbnz	w12, #0x4, 0x1634 <ltmp0+0x1634>
    15e4:      	tbnz	w12, #0x5, 0x163c <ltmp0+0x163c>
    15e8:      	tbnz	w12, #0x6, 0x1648 <ltmp0+0x1648>
    15ec:      	tbz	w12, #0x7, 0x1574 <ltmp0+0x1574>
    15f0:      	b	0x1654 <ltmp0+0x1654>
    15f4:      	str	s27, [x11]
    15f8:      	and	w12, w12, #0xff
    15fc:      	tbz	w12, #0x1, 0x15c8 <ltmp0+0x15c8>
    1600:      	add	x13, x11, #0x4
    1604:      	st1.s	{ v27 }[1], [x13]
    1608:      	tbz	w12, #0x2, 0x15cc <ltmp0+0x15cc>
    160c:      	add	x13, x11, #0x8
    1610:      	st1.s	{ v27 }[2], [x13]
    1614:      	tbz	w12, #0x3, 0x15d0 <ltmp0+0x15d0>
    1618:      	add	x13, x11, #0xc
    161c:      	st1.s	{ v27 }[3], [x13]
    1620:      	and.16b	v3, v0, v25
    1624:      	fdiv.4s	v3, v3, v6
    1628:      	and.16b	v5, v0, v26
    162c:      	fmul.4s	v25, v3, v5
    1630:      	tbz	w12, #0x4, 0x15e4 <ltmp0+0x15e4>
    1634:      	str	s25, [x11, #0x10]
    1638:      	tbz	w12, #0x5, 0x15e8 <ltmp0+0x15e8>
    163c:      	add	x13, x11, #0x14
    1640:      	st1.s	{ v25 }[1], [x13]
    1644:      	tbz	w12, #0x6, 0x15ec <ltmp0+0x15ec>
    1648:      	add	x13, x11, #0x18
    164c:      	st1.s	{ v25 }[2], [x13]
    1650:      	tbz	w12, #0x7, 0x1574 <ltmp0+0x1574>
    1654:      	add	x11, x11, #0x1c
    1658:      	st1.s	{ v25 }[3], [x11]
    165c:      	b	0x1574 <ltmp0+0x1574>
    1660:      	fdiv.4s	v0, v30, v6
    1664:      	fmul.4s	v0, v0, v7
    1668:      	ldr	q2, [sp, #0x120]
    166c:      	ldp	q4, q3, [sp, #0xe0]
    1670:      	stp	q2, q3, [sp, #0x140]
    1674:      	ldr	q1, [sp, #0x100]
    1678:      	stp	q4, q1, [sp, #0x160]
    167c:      	and	x10, x9, #0x7
    1680:      	add	x11, sp, #0x140
    1684:      	ldr	x10, [x11, x10, lsl #3]
    1688:      	sub	x9, x10, x9
    168c:      	add	x8, x8, x9, lsl #2
    1690:      	fmov	w9, s24
    1694:      	tbnz	w9, #0x0, 0x1768 <ltmp0+0x1768>
    1698:      	tbnz	w9, #0x1, 0x1770 <ltmp0+0x1770>
    169c:      	tbnz	w9, #0x2, 0x177c <ltmp0+0x177c>
    16a0:      	tbnz	w9, #0x3, 0x1788 <ltmp0+0x1788>
    16a4:      	fdiv.4s	v0, v29, v6
    16a8:      	fmul.4s	v0, v0, v18
    16ac:      	tbnz	w9, #0x4, 0x179c <ltmp0+0x179c>
    16b0:      	tbnz	w9, #0x5, 0x17a4 <ltmp0+0x17a4>
    16b4:      	tbnz	w9, #0x6, 0x17b0 <ltmp0+0x17b0>
    16b8:      	tbz	w9, #0x7, 0x6c <ltmp0+0x6c>
    16bc:      	b	0x17bc <ltmp0+0x17bc>
    16c0:      	ldr	s5, [x12]
    16c4:      	tbz	w13, #0x1, 0xd68 <ltmp0+0xd68>
    16c8:      	add	x14, x12, #0x4
    16cc:      	ld1.s	{ v5 }[1], [x14]
    16d0:      	tbz	w13, #0x2, 0xd6c <ltmp0+0xd6c>
    16d4:      	add	x14, x12, #0x8
    16d8:      	ld1.s	{ v5 }[2], [x14]
    16dc:      	tbz	w13, #0x3, 0xd70 <ltmp0+0xd70>
    16e0:      	add	x14, x12, #0xc
    16e4:      	ld1.s	{ v5 }[3], [x14]
    16e8:      	tbz	w13, #0x4, 0xd74 <ltmp0+0xd74>
    16ec:      	add	x14, x12, #0x10
    16f0:      	ld1.s	{ v3 }[0], [x14]
    16f4:      	tbz	w13, #0x5, 0xd78 <ltmp0+0xd78>
    16f8:      	add	x14, x12, #0x14
    16fc:      	ld1.s	{ v3 }[1], [x14]
    1700:      	tbz	w13, #0x6, 0xd7c <ltmp0+0xd7c>
    1704:      	add	x14, x12, #0x18
    1708:      	ld1.s	{ v3 }[2], [x14]
    170c:      	tbnz	w13, #0x7, 0xd80 <ltmp0+0xd80>
    1710:      	b	0xd88 <ltmp0+0xd88>
    1714:      	ldr	s7, [x10]
    1718:      	tbz	w13, #0x1, 0x14d0 <ltmp0+0x14d0>
    171c:      	add	x11, x10, #0x4
    1720:      	ld1.s	{ v7 }[1], [x11]
    1724:      	tbz	w13, #0x2, 0x14d4 <ltmp0+0x14d4>
    1728:      	add	x11, x10, #0x8
    172c:      	ld1.s	{ v7 }[2], [x11]
    1730:      	tbz	w13, #0x3, 0x14d8 <ltmp0+0x14d8>
    1734:      	add	x11, x10, #0xc
    1738:      	ld1.s	{ v7 }[3], [x11]
    173c:      	tbz	w13, #0x4, 0x14dc <ltmp0+0x14dc>
    1740:      	add	x11, x10, #0x10
    1744:      	ld1.s	{ v18 }[0], [x11]
    1748:      	tbz	w13, #0x5, 0x14e0 <ltmp0+0x14e0>
    174c:      	add	x11, x10, #0x14
    1750:      	ld1.s	{ v18 }[1], [x11]
    1754:      	tbz	w13, #0x6, 0x14e4 <ltmp0+0x14e4>
    1758:      	add	x11, x10, #0x18
    175c:      	ld1.s	{ v18 }[2], [x11]
    1760:      	tbnz	w13, #0x7, 0x14e8 <ltmp0+0x14e8>
    1764:      	b	0x14f0 <ltmp0+0x14f0>
    1768:      	str	s0, [x8]
    176c:      	tbz	w9, #0x1, 0x169c <ltmp0+0x169c>
    1770:      	add	x10, x8, #0x4
    1774:      	st1.s	{ v0 }[1], [x10]
    1778:      	tbz	w9, #0x2, 0x16a0 <ltmp0+0x16a0>
    177c:      	add	x10, x8, #0x8
    1780:      	st1.s	{ v0 }[2], [x10]
    1784:      	tbz	w9, #0x3, 0x16a4 <ltmp0+0x16a4>
    1788:      	add	x10, x8, #0xc
    178c:      	st1.s	{ v0 }[3], [x10]
    1790:      	fdiv.4s	v0, v29, v6
    1794:      	fmul.4s	v0, v0, v18
    1798:      	tbz	w9, #0x4, 0x16b0 <ltmp0+0x16b0>
    179c:      	str	s0, [x8, #0x10]
    17a0:      	tbz	w9, #0x5, 0x16b4 <ltmp0+0x16b4>
    17a4:      	add	x10, x8, #0x14
    17a8:      	st1.s	{ v0 }[1], [x10]
    17ac:      	tbz	w9, #0x6, 0x16b8 <ltmp0+0x16b8>
    17b0:      	add	x10, x8, #0x18
    17b4:      	st1.s	{ v0 }[2], [x10]
    17b8:      	tbz	w9, #0x7, 0x6c <ltmp0+0x6c>
    17bc:      	add	x8, x8, #0x1c
    17c0:      	st1.s	{ v0 }[3], [x8]
    17c4:      	b	0x6c <ltmp0+0x6c>
    17c8:      	ldr	x9, [sp, #0x8]
    17cc:      	stp	w7, w13, [x9]
    17d0:      	str	w12, [x9, #0x8]
    17d4:      	mov	w8, #0x18               ; =24
    17d8:      	str	w8, [x9, #0x24]
    17dc:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    17e0:      	add	sp, sp, #0x410
    17e4:      	ldp	x29, x30, [sp, #0x90]
    17e8:      	ldp	x20, x19, [sp, #0x80]
    17ec:      	ldp	x22, x21, [sp, #0x70]
    17f0:      	ldp	x24, x23, [sp, #0x60]
    17f4:      	ldp	x26, x25, [sp, #0x50]
    17f8:      	ldp	x28, x27, [sp, #0x40]
    17fc:      	ldp	d9, d8, [sp, #0x30]
    1800:      	ldp	d11, d10, [sp, #0x20]
    1804:      	ldp	d13, d12, [sp, #0x10]
    1808:      	ldp	d15, d14, [sp], #0xa0
    180c:      	ret

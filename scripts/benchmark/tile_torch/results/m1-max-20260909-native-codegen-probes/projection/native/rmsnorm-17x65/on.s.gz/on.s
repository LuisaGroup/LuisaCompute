
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/rmsnorm-17x65/on/object/tile_xir_w8_37853_1788936533007540_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x168c <ltmp0+0x168c>
       4:      	stp	d15, d14, [sp, #-0xa0]!
       8:      	stp	d13, d12, [sp, #0x10]
       c:      	stp	d11, d10, [sp, #0x20]
      10:      	stp	d9, d8, [sp, #0x30]
      14:      	stp	x28, x27, [sp, #0x40]
      18:      	stp	x26, x25, [sp, #0x50]
      1c:      	stp	x24, x23, [sp, #0x60]
      20:      	stp	x22, x21, [sp, #0x70]
      24:      	stp	x20, x19, [sp, #0x80]
      28:      	stp	x29, x30, [sp, #0x90]
      2c:      	sub	sp, sp, #0x560
      30:      	mov	w8, #0x0                ; =0
      34:      	mov	w19, #0x20              ; =32
      38:      	mov	w10, #0x104             ; =260
      3c:      	mov	w11, #0x42820000        ; =1115815936
      40:      	ldp	w23, w24, [x2, #0x2c]
      44:      	mov	w14, #0xc5ac            ; =50604
      48:      	movk	w14, #0x3727, lsl #16
      4c:      	mov	w28, #0x1               ; =1
      50:      	ldp	w9, w12, [x2]
      54:      	add	x6, sp, #0x440
      58:      	ldp	w13, w7, [x2, #0x8]
      5c:      	str	x2, [sp, #0x10]
      60:      	movi	d15, #0000000000000000
      64:      	mov	w17, #0x4               ; =4
      68:      	add	x1, sp, #0x320
      6c:      	str	x0, [sp, #0x20]
      70:      	stp	w24, w23, [sp, #0x18]
      74:      	b	0x834 <ltmp0+0x834>
      78:      	ldr	x20, [x0]
      7c:      	ldr	x4, [x0, #0x10]
      80:      	ldr	x16, [x0, #0x30]
      84:      	ubfiz	w9, w26, #2, #27
      88:      	umull	x12, w9, w10
      8c:      	umaddl	x13, w9, w10, x20
      90:      	ldp	q28, q26, [x13]
      94:      	ldp	q25, q24, [x13, #0x20]
      98:      	ldp	q23, q22, [x13, #0x40]
      9c:      	ldp	q21, q5, [x13, #0x60]
      a0:      	ldp	q20, q19, [x13, #0x80]
      a4:      	ldp	q17, q18, [x13, #0xa0]
      a8:      	ldp	q16, q7, [x13, #0xc0]
      ac:      	ldp	q27, q6, [x13, #0xe0]
      b0:      	add	x5, x12, #0x100
      b4:      	ldr	s29, [x20, x5]
      b8:      	ldp	q9, q8, [x4]
      bc:      	ldp	q31, q30, [x4, #0x20]
      c0:      	ldp	q0, q1, [x4, #0x40]
      c4:      	stp	q0, q1, [sp, #0xa0]
      c8:      	fmul.4s	v3, v28, v28
      cc:      	fmul.4s	v4, v26, v26
      d0:      	fmul.4s	v10, v24, v24
      d4:      	fmul.4s	v11, v25, v25
      d8:      	fmul.4s	v12, v23, v23
      dc:      	fmul.4s	v13, v22, v22
      e0:      	fmul.4s	v14, v5, v5
      e4:      	fmul.4s	v15, v21, v21
      e8:      	fmul.4s	v0, v27, v27
      ec:      	fadd.4s	v0, v15, v0
      f0:      	fmul.4s	v15, v6, v6
      f4:      	fadd.4s	v14, v14, v15
      f8:      	fmul.4s	v15, v7, v7
      fc:      	fadd.4s	v13, v13, v15
     100:      	fmul.4s	v15, v16, v16
     104:      	fadd.4s	v12, v12, v15
     108:      	fmul.4s	v15, v17, v17
     10c:      	fadd.4s	v11, v11, v15
     110:      	fmul.4s	v15, v18, v18
     114:      	fadd.4s	v10, v10, v15
     118:      	fmul.4s	v15, v20, v20
     11c:      	fadd.4s	v3, v3, v15
     120:      	fmul.4s	v15, v29, v29
     124:      	fadd.4s	v15, v3, v15
     128:      	mov.s	v3[0], v15[0]
     12c:      	fmul.4s	v15, v19, v19
     130:      	fadd.4s	v4, v4, v15
     134:      	fadd.4s	v4, v10, v4
     138:      	ldp	q15, q10, [x4, #0x60]
     13c:      	fadd.4s	v3, v11, v3
     140:      	fadd.4s	v3, v12, v3
     144:      	fadd.4s	v4, v13, v4
     148:      	fadd.4s	v4, v14, v4
     14c:      	fadd.4s	v0, v0, v3
     150:      	rev64.4s	v3, v0
     154:      	rev64.4s	v11, v4
     158:      	fadd.4s	v4, v4, v11
     15c:      	fadd.4s	v0, v0, v3
     160:      	dup.4s	v3, v0[2]
     164:      	dup.4s	v11, v4[2]
     168:      	ldp	q13, q12, [x4, #0x80]
     16c:      	fadd.4s	v4, v4, v11
     170:      	fadd.4s	v0, v0, v3
     174:      	fadd.4s	v0, v0, v4
     178:      	movi	d1, #0000000000000000
     17c:      	fadd	s0, s0, s1
     180:      	fmov	s1, w11
     184:      	str	s1, [sp, #0xcc]
     188:      	fdiv	s0, s0, s1
     18c:      	fmov	s1, w14
     190:      	str	s1, [sp, #0xc8]
     194:      	fadd	s0, s0, s1
     198:      	fsqrt	s0, s0
     19c:      	dup.4s	v11, v0[0]
     1a0:      	fdiv.4s	v28, v28, v11
     1a4:      	fmul.4s	v28, v9, v28
     1a8:      	ldp	q14, q9, [x4, #0xa0]
     1ac:      	umaddl	x9, w9, w10, x16
     1b0:      	fdiv.4s	v26, v26, v11
     1b4:      	fmul.4s	v26, v8, v26
     1b8:      	ldp	q1, q8, [x4, #0xc0]
     1bc:      	ldp	q2, q3, [x4, #0xe0]
     1c0:      	ldr	s4, [x4, #0x100]
     1c4:      	stp	q28, q26, [x9]
     1c8:      	fdiv.4s	v25, v25, v11
     1cc:      	fmul.4s	v25, v31, v25
     1d0:      	fdiv.4s	v24, v24, v11
     1d4:      	fmul.4s	v24, v30, v24
     1d8:      	stp	q25, q24, [x9, #0x20]
     1dc:      	fdiv.4s	v22, v22, v11
     1e0:      	fdiv.4s	v23, v23, v11
     1e4:      	ldp	q25, q24, [sp, #0xa0]
     1e8:      	fmul.4s	v23, v25, v23
     1ec:      	fmul.4s	v22, v24, v22
     1f0:      	stp	q23, q22, [x9, #0x40]
     1f4:      	fdiv.4s	v5, v5, v11
     1f8:      	fdiv.4s	v21, v21, v11
     1fc:      	fmul.4s	v21, v15, v21
     200:      	fmul.4s	v5, v10, v5
     204:      	stp	q21, q5, [x9, #0x60]
     208:      	fdiv.4s	v5, v19, v11
     20c:      	fdiv.4s	v19, v20, v11
     210:      	fmul.4s	v19, v13, v19
     214:      	fmul.4s	v5, v12, v5
     218:      	stp	q19, q5, [x9, #0x80]
     21c:      	fdiv.4s	v5, v18, v11
     220:      	fdiv.4s	v17, v17, v11
     224:      	fmul.4s	v17, v14, v17
     228:      	fmul.4s	v5, v9, v5
     22c:      	stp	q17, q5, [x9, #0xa0]
     230:      	fdiv.4s	v5, v7, v11
     234:      	fdiv.4s	v7, v16, v11
     238:      	fmul.4s	v1, v1, v7
     23c:      	fmul.4s	v5, v8, v5
     240:      	stp	q1, q5, [x9, #0xc0]
     244:      	fdiv.4s	v1, v6, v11
     248:      	fdiv.4s	v5, v27, v11
     24c:      	fmul.4s	v2, v2, v5
     250:      	fmul.4s	v1, v3, v1
     254:      	stp	q2, q1, [x9, #0xe0]
     258:      	fdiv.4s	v0, v29, v0
     25c:      	fmul.4s	v0, v4, v0
     260:      	str	s0, [x16, x5]
     264:      	mov	w9, #0x1                ; =1
     268:      	bfi	w9, w26, #2, #27
     26c:      	umull	x12, w9, w10
     270:      	umaddl	x13, w9, w10, x20
     274:      	ldp	q27, q26, [x13]
     278:      	ldp	q25, q24, [x13, #0x20]
     27c:      	ldp	q23, q22, [x13, #0x40]
     280:      	ldp	q21, q5, [x13, #0x60]
     284:      	ldp	q20, q19, [x13, #0x80]
     288:      	ldp	q17, q18, [x13, #0xa0]
     28c:      	ldp	q16, q28, [x13, #0xc0]
     290:      	ldp	q2, q29, [x13, #0xe0]
     294:      	add	x5, x12, #0x100
     298:      	ldr	s1, [x20, x5]
     29c:      	ldp	q31, q30, [x4]
     2a0:      	ldp	q0, q3, [x4, #0x20]
     2a4:      	stp	q3, q2, [sp, #0xa0]
     2a8:      	stp	q0, q1, [sp, #0x80]
     2ac:      	fmul.4s	v0, v27, v27
     2b0:      	fmul.4s	v3, v26, v26
     2b4:      	fmul.4s	v4, v24, v24
     2b8:      	fmul.4s	v8, v25, v25
     2bc:      	fmul.4s	v9, v23, v23
     2c0:      	fmul.4s	v10, v22, v22
     2c4:      	fmul.4s	v11, v5, v5
     2c8:      	fmul.4s	v12, v21, v21
     2cc:      	fmul.4s	v13, v2, v2
     2d0:      	fadd.4s	v12, v12, v13
     2d4:      	fmul.4s	v13, v29, v29
     2d8:      	fadd.4s	v11, v11, v13
     2dc:      	fmul.4s	v13, v28, v28
     2e0:      	fadd.4s	v10, v10, v13
     2e4:      	fmul.4s	v13, v16, v16
     2e8:      	fadd.4s	v9, v9, v13
     2ec:      	fmul.4s	v13, v17, v17
     2f0:      	fadd.4s	v8, v8, v13
     2f4:      	fmul.4s	v13, v18, v18
     2f8:      	fadd.4s	v4, v4, v13
     2fc:      	fmul.4s	v13, v20, v20
     300:      	fadd.4s	v0, v0, v13
     304:      	fmul.4s	v13, v1, v1
     308:      	fadd.4s	v13, v0, v13
     30c:      	mov.s	v0[0], v13[0]
     310:      	fmul.4s	v13, v19, v19
     314:      	fadd.4s	v3, v3, v13
     318:      	fadd.4s	v3, v4, v3
     31c:      	ldp	q13, q4, [x4, #0x40]
     320:      	fadd.4s	v0, v8, v0
     324:      	fadd.4s	v0, v9, v0
     328:      	ldp	q9, q8, [x4, #0x60]
     32c:      	fadd.4s	v3, v10, v3
     330:      	fadd.4s	v3, v11, v3
     334:      	fadd.4s	v0, v12, v0
     338:      	rev64.4s	v10, v0
     33c:      	rev64.4s	v11, v3
     340:      	fadd.4s	v3, v3, v11
     344:      	fadd.4s	v0, v0, v10
     348:      	dup.4s	v10, v3[2]
     34c:      	ldp	q12, q11, [x4, #0x80]
     350:      	fadd.4s	v3, v3, v10
     354:      	dup.4s	v10, v0[2]
     358:      	fadd.4s	v0, v0, v10
     35c:      	fadd.4s	v0, v0, v3
     360:      	movi	d1, #0000000000000000
     364:      	fadd	s0, s0, s1
     368:      	ldp	s7, s6, [sp, #0xc8]
     36c:      	fdiv	s0, s0, s6
     370:      	fadd	s0, s0, s7
     374:      	fsqrt	s0, s0
     378:      	dup.4s	v3, v0[0]
     37c:      	fdiv.4s	v27, v27, v3
     380:      	fmul.4s	v27, v31, v27
     384:      	ldp	q10, q31, [x4, #0xa0]
     388:      	umaddl	x9, w9, w10, x16
     38c:      	fdiv.4s	v26, v26, v3
     390:      	fmul.4s	v26, v30, v26
     394:      	ldp	q14, q30, [x4, #0xc0]
     398:      	ldp	q1, q15, [x4, #0xe0]
     39c:      	ldr	s2, [x4, #0x100]
     3a0:      	stp	q27, q26, [x9]
     3a4:      	fdiv.4s	v25, v25, v3
     3a8:      	ldr	q26, [sp, #0x80]
     3ac:      	fmul.4s	v25, v26, v25
     3b0:      	fdiv.4s	v24, v24, v3
     3b4:      	ldr	q26, [sp, #0xa0]
     3b8:      	fmul.4s	v24, v26, v24
     3bc:      	stp	q25, q24, [x9, #0x20]
     3c0:      	fdiv.4s	v22, v22, v3
     3c4:      	fdiv.4s	v23, v23, v3
     3c8:      	fmul.4s	v23, v13, v23
     3cc:      	fmul.4s	v4, v4, v22
     3d0:      	stp	q23, q4, [x9, #0x40]
     3d4:      	fdiv.4s	v4, v5, v3
     3d8:      	fdiv.4s	v5, v21, v3
     3dc:      	fmul.4s	v5, v9, v5
     3e0:      	fmul.4s	v4, v8, v4
     3e4:      	stp	q5, q4, [x9, #0x60]
     3e8:      	fdiv.4s	v4, v19, v3
     3ec:      	fdiv.4s	v5, v20, v3
     3f0:      	fmul.4s	v5, v12, v5
     3f4:      	fmul.4s	v4, v11, v4
     3f8:      	stp	q5, q4, [x9, #0x80]
     3fc:      	fdiv.4s	v4, v18, v3
     400:      	fdiv.4s	v5, v17, v3
     404:      	fmul.4s	v5, v10, v5
     408:      	fmul.4s	v4, v31, v4
     40c:      	stp	q5, q4, [x9, #0xa0]
     410:      	fdiv.4s	v4, v28, v3
     414:      	fdiv.4s	v5, v16, v3
     418:      	fmul.4s	v5, v14, v5
     41c:      	fmul.4s	v4, v30, v4
     420:      	stp	q5, q4, [x9, #0xc0]
     424:      	fdiv.4s	v4, v29, v3
     428:      	ldr	q5, [sp, #0xb0]
     42c:      	fdiv.4s	v3, v5, v3
     430:      	fmul.4s	v1, v1, v3
     434:      	fmul.4s	v3, v15, v4
     438:      	stp	q1, q3, [x9, #0xe0]
     43c:      	ldr	q1, [sp, #0x90]
     440:      	fdiv.4s	v0, v1, v0
     444:      	fmul.4s	v0, v2, v0
     448:      	str	s0, [x16, x5]
     44c:      	mov	w9, #0x2                ; =2
     450:      	bfi	w9, w26, #2, #27
     454:      	umull	x12, w9, w10
     458:      	umaddl	x13, w9, w10, x20
     45c:      	ldp	q27, q26, [x13]
     460:      	ldp	q25, q24, [x13, #0x20]
     464:      	ldp	q23, q22, [x13, #0x40]
     468:      	ldp	q21, q5, [x13, #0x60]
     46c:      	ldp	q20, q19, [x13, #0x80]
     470:      	ldp	q17, q18, [x13, #0xa0]
     474:      	ldp	q16, q28, [x13, #0xc0]
     478:      	ldp	q2, q29, [x13, #0xe0]
     47c:      	add	x5, x12, #0x100
     480:      	ldr	s1, [x20, x5]
     484:      	ldp	q31, q30, [x4]
     488:      	ldp	q0, q3, [x4, #0x20]
     48c:      	stp	q3, q2, [sp, #0xa0]
     490:      	stp	q0, q1, [sp, #0x80]
     494:      	fmul.4s	v0, v27, v27
     498:      	fmul.4s	v3, v26, v26
     49c:      	fmul.4s	v4, v24, v24
     4a0:      	fmul.4s	v8, v25, v25
     4a4:      	fmul.4s	v9, v23, v23
     4a8:      	fmul.4s	v10, v22, v22
     4ac:      	fmul.4s	v11, v5, v5
     4b0:      	fmul.4s	v12, v21, v21
     4b4:      	fmul.4s	v13, v2, v2
     4b8:      	fadd.4s	v12, v12, v13
     4bc:      	fmul.4s	v13, v29, v29
     4c0:      	fadd.4s	v11, v11, v13
     4c4:      	fmul.4s	v13, v28, v28
     4c8:      	fadd.4s	v10, v10, v13
     4cc:      	fmul.4s	v13, v16, v16
     4d0:      	fadd.4s	v9, v9, v13
     4d4:      	fmul.4s	v13, v17, v17
     4d8:      	fadd.4s	v8, v8, v13
     4dc:      	fmul.4s	v13, v18, v18
     4e0:      	fadd.4s	v4, v4, v13
     4e4:      	fmul.4s	v13, v20, v20
     4e8:      	fadd.4s	v0, v0, v13
     4ec:      	fmul.4s	v13, v1, v1
     4f0:      	fadd.4s	v13, v0, v13
     4f4:      	mov.s	v0[0], v13[0]
     4f8:      	fmul.4s	v13, v19, v19
     4fc:      	fadd.4s	v3, v3, v13
     500:      	fadd.4s	v3, v4, v3
     504:      	ldp	q13, q4, [x4, #0x40]
     508:      	fadd.4s	v0, v8, v0
     50c:      	fadd.4s	v0, v9, v0
     510:      	ldp	q9, q8, [x4, #0x60]
     514:      	fadd.4s	v3, v10, v3
     518:      	fadd.4s	v3, v11, v3
     51c:      	fadd.4s	v0, v12, v0
     520:      	rev64.4s	v10, v0
     524:      	rev64.4s	v11, v3
     528:      	fadd.4s	v3, v3, v11
     52c:      	fadd.4s	v0, v0, v10
     530:      	dup.4s	v10, v3[2]
     534:      	ldp	q12, q11, [x4, #0x80]
     538:      	fadd.4s	v3, v3, v10
     53c:      	dup.4s	v10, v0[2]
     540:      	fadd.4s	v0, v0, v10
     544:      	fadd.4s	v0, v0, v3
     548:      	movi	d1, #0000000000000000
     54c:      	fadd	s0, s0, s1
     550:      	fdiv	s0, s0, s6
     554:      	fadd	s0, s0, s7
     558:      	fsqrt	s0, s0
     55c:      	dup.4s	v3, v0[0]
     560:      	fdiv.4s	v27, v27, v3
     564:      	fmul.4s	v27, v31, v27
     568:      	ldp	q10, q31, [x4, #0xa0]
     56c:      	umaddl	x9, w9, w10, x16
     570:      	fdiv.4s	v26, v26, v3
     574:      	fmul.4s	v26, v30, v26
     578:      	ldp	q14, q30, [x4, #0xc0]
     57c:      	ldp	q1, q15, [x4, #0xe0]
     580:      	ldr	s2, [x4, #0x100]
     584:      	stp	q27, q26, [x9]
     588:      	fdiv.4s	v25, v25, v3
     58c:      	ldr	q6, [sp, #0x80]
     590:      	fmul.4s	v25, v6, v25
     594:      	fdiv.4s	v24, v24, v3
     598:      	ldr	q6, [sp, #0xa0]
     59c:      	fmul.4s	v24, v6, v24
     5a0:      	stp	q25, q24, [x9, #0x20]
     5a4:      	fdiv.4s	v22, v22, v3
     5a8:      	fdiv.4s	v23, v23, v3
     5ac:      	fmul.4s	v23, v13, v23
     5b0:      	fmul.4s	v4, v4, v22
     5b4:      	stp	q23, q4, [x9, #0x40]
     5b8:      	fdiv.4s	v4, v5, v3
     5bc:      	fdiv.4s	v5, v21, v3
     5c0:      	fmul.4s	v5, v9, v5
     5c4:      	fmul.4s	v4, v8, v4
     5c8:      	stp	q5, q4, [x9, #0x60]
     5cc:      	fdiv.4s	v4, v19, v3
     5d0:      	fdiv.4s	v5, v20, v3
     5d4:      	fmul.4s	v5, v12, v5
     5d8:      	fmul.4s	v4, v11, v4
     5dc:      	stp	q5, q4, [x9, #0x80]
     5e0:      	fdiv.4s	v4, v18, v3
     5e4:      	fdiv.4s	v5, v17, v3
     5e8:      	fmul.4s	v5, v10, v5
     5ec:      	fmul.4s	v4, v31, v4
     5f0:      	stp	q5, q4, [x9, #0xa0]
     5f4:      	fdiv.4s	v4, v28, v3
     5f8:      	fdiv.4s	v5, v16, v3
     5fc:      	fmul.4s	v5, v14, v5
     600:      	fmul.4s	v4, v30, v4
     604:      	stp	q5, q4, [x9, #0xc0]
     608:      	fdiv.4s	v4, v29, v3
     60c:      	ldr	q5, [sp, #0xb0]
     610:      	fdiv.4s	v3, v5, v3
     614:      	fmul.4s	v1, v1, v3
     618:      	fmul.4s	v3, v15, v4
     61c:      	movi	d15, #0000000000000000
     620:      	stp	q1, q3, [x9, #0xe0]
     624:      	ldr	q1, [sp, #0x90]
     628:      	fdiv.4s	v0, v1, v0
     62c:      	fmul.4s	v0, v2, v0
     630:      	str	s0, [x16, x5]
     634:      	mov	w15, #0x3               ; =3
     638:      	bfi	w15, w26, #2, #27
     63c:      	umull	x9, w15, w10
     640:      	umaddl	x12, w15, w10, x20
     644:      	ldp	q27, q26, [x12]
     648:      	ldp	q24, q25, [x12, #0x20]
     64c:      	ldp	q23, q22, [x12, #0x40]
     650:      	ldp	q1, q21, [x12, #0x60]
     654:      	ldp	q20, q19, [x12, #0x80]
     658:      	ldp	q18, q17, [x12, #0xa0]
     65c:      	ldp	q16, q7, [x12, #0xc0]
     660:      	ldp	q5, q6, [x12, #0xe0]
     664:      	add	x5, x9, #0x100
     668:      	ldr	s2, [x20, x5]
     66c:      	ldp	q29, q28, [x4]
     670:      	fmul.4s	v0, v27, v27
     674:      	fmul.4s	v3, v26, v26
     678:      	fmul.4s	v4, v25, v25
     67c:      	fmul.4s	v30, v24, v24
     680:      	fmul.4s	v31, v23, v23
     684:      	fmul.4s	v8, v22, v22
     688:      	fmul.4s	v9, v21, v21
     68c:      	fmul.4s	v10, v1, v1
     690:      	fmul.4s	v11, v6, v6
     694:      	fmul.4s	v12, v5, v5
     698:      	fadd.4s	v10, v10, v12
     69c:      	fadd.4s	v9, v9, v11
     6a0:      	fmul.4s	v11, v16, v16
     6a4:      	fmul.4s	v12, v7, v7
     6a8:      	fadd.4s	v8, v8, v12
     6ac:      	fadd.4s	v31, v31, v11
     6b0:      	fmul.4s	v11, v17, v17
     6b4:      	fmul.4s	v12, v18, v18
     6b8:      	fadd.4s	v30, v30, v12
     6bc:      	fadd.4s	v4, v4, v11
     6c0:      	fmul.4s	v11, v20, v20
     6c4:      	fmul.4s	v12, v19, v19
     6c8:      	fadd.4s	v3, v3, v12
     6cc:      	fadd.4s	v0, v0, v11
     6d0:      	fmul.4s	v11, v2, v2
     6d4:      	fadd.4s	v11, v0, v11
     6d8:      	mov.s	v0[0], v11[0]
     6dc:      	ldp	q12, q11, [x4, #0x20]
     6e0:      	fadd.4s	v3, v4, v3
     6e4:      	fadd.4s	v0, v30, v0
     6e8:      	ldp	q13, q30, [x4, #0x40]
     6ec:      	fadd.4s	v0, v31, v0
     6f0:      	fadd.4s	v3, v8, v3
     6f4:      	fadd.4s	v3, v9, v3
     6f8:      	fadd.4s	v0, v10, v0
     6fc:      	rev64.4s	v4, v0
     700:      	rev64.4s	v31, v3
     704:      	fadd.4s	v3, v3, v31
     708:      	fadd.4s	v0, v0, v4
     70c:      	dup.4s	v4, v0[2]
     710:      	dup.4s	v31, v3[2]
     714:      	ldp	q9, q8, [x4, #0x60]
     718:      	fadd.4s	v3, v3, v31
     71c:      	fadd.4s	v0, v0, v4
     720:      	ldp	q10, q31, [x4, #0x80]
     724:      	fadd.4s	v0, v0, v3
     728:      	fadd	s0, s0, s15
     72c:      	ldp	s3, s4, [sp, #0xc8]
     730:      	fdiv	s0, s0, s4
     734:      	fadd	s0, s0, s3
     738:      	fsqrt	s3, s0
     73c:      	dup.4s	v4, v3[0]
     740:      	ldp	q14, q0, [x4, #0xa0]
     744:      	fdiv.4s	v26, v26, v4
     748:      	fdiv.4s	v27, v27, v4
     74c:      	fmul.4s	v27, v29, v27
     750:      	fmul.4s	v26, v28, v26
     754:      	ldp	q29, q28, [x4, #0xc0]
     758:      	fdiv.4s	v25, v25, v4
     75c:      	fdiv.4s	v24, v24, v4
     760:      	fmul.4s	v24, v12, v24
     764:      	fmul.4s	v25, v11, v25
     768:      	ldp	q12, q11, [x4, #0xe0]
     76c:      	fdiv.4s	v23, v23, v4
     770:      	fmul.4s	v23, v13, v23
     774:      	ldr	s13, [x4, #0x100]
     778:      	umaddl	x9, w15, w10, x16
     77c:      	stp	q27, q26, [x9]
     780:      	fdiv.4s	v22, v22, v4
     784:      	fmul.4s	v22, v30, v22
     788:      	fdiv.4s	v1, v1, v4
     78c:      	fmul.4s	v1, v9, v1
     790:      	stp	q24, q25, [x9, #0x20]
     794:      	fdiv.4s	v21, v21, v4
     798:      	fmul.4s	v21, v8, v21
     79c:      	stp	q23, q22, [x9, #0x40]
     7a0:      	fdiv.4s	v20, v20, v4
     7a4:      	fmul.4s	v20, v10, v20
     7a8:      	stp	q1, q21, [x9, #0x60]
     7ac:      	fdiv.4s	v1, v19, v4
     7b0:      	fmul.4s	v1, v31, v1
     7b4:      	stp	q20, q1, [x9, #0x80]
     7b8:      	fdiv.4s	v1, v18, v4
     7bc:      	fmul.4s	v1, v14, v1
     7c0:      	fdiv.4s	v17, v17, v4
     7c4:      	fmul.4s	v0, v0, v17
     7c8:      	stp	q1, q0, [x9, #0xa0]
     7cc:      	fdiv.4s	v0, v16, v4
     7d0:      	fmul.4s	v0, v29, v0
     7d4:      	fdiv.4s	v1, v7, v4
     7d8:      	fmul.4s	v1, v28, v1
     7dc:      	stp	q0, q1, [x9, #0xc0]
     7e0:      	fdiv.4s	v0, v6, v4
     7e4:      	fdiv.4s	v1, v5, v4
     7e8:      	fmul.4s	v1, v12, v1
     7ec:      	fmul.4s	v0, v11, v0
     7f0:      	stp	q1, q0, [x9, #0xe0]
     7f4:      	fdiv.4s	v0, v2, v3
     7f8:      	fmul.4s	v0, v13, v0
     7fc:      	str	s0, [x16, x5]
     800:      	add	w9, w26, #0x1
     804:      	cmp	w9, w23
     808:      	cset	w12, eq
     80c:      	csinc	w9, wzr, w26, eq
     810:      	cinc	w13, w30, eq
     814:      	cmp	w13, w24
     818:      	cset	w15, eq
     81c:      	ands	w15, w12, w15
     820:      	csel	w12, wzr, w13, ne
     824:      	add	w13, w25, w15
     828:      	add	w8, w8, #0x1
     82c:      	cmp	w8, w3
     830:      	b.eq	0x164c <ltmp0+0x164c>
     834:      	mov	x25, x13
     838:      	mov	x30, x12
     83c:      	mov	x26, x9
     840:      	ubfiz	x9, x9, #5, #32
     844:      	cmp	x9, x7
     848:      	csel	x12, x9, xzr, ls
     84c:      	subs	x13, x7, x12
     850:      	cmp	x13, #0x20
     854:      	csel	x13, x13, x19, lo
     858:      	cmp	x7, x12
     85c:      	ccmp	x9, x7, #0x2, hi
     860:      	csel	x16, x13, xzr, ls
     864:      	cmp	x16, #0x20
     868:      	b.hs	0x78 <ltmp0+0x78>
     86c:      	lsr	x4, x16, #3
     870:      	cmp	x16, #0x8
     874:      	b.lo	0xa70 <ltmp0+0xa70>
     878:      	ldr	x9, [x0]
     87c:      	ldr	x5, [x0, #0x10]
     880:      	ldr	x12, [x0, #0x30]
     884:      	add	x20, x5, #0x100
     888:      	and	x13, x26, #0x7ffffff
     88c:      	add	x13, x13, x13, lsl #6
     890:      	lsl	x13, x13, #4
     894:      	add	x9, x9, x13
     898:      	add	x21, x9, #0x80
     89c:      	add	x9, x12, x13
     8a0:      	add	x22, x9, #0x80
     8a4:      	mov	x27, x4
     8a8:      	ldp	q25, q24, [x21, #-0x80]
     8ac:      	ldp	q23, q22, [x21, #-0x60]
     8b0:      	ldp	q21, q20, [x21, #-0x40]
     8b4:      	ldp	q1, q19, [x21, #-0x20]
     8b8:      	ldp	q18, q17, [x21]
     8bc:      	ldp	q16, q7, [x21, #0x20]
     8c0:      	ldp	q6, q5, [x21, #0x40]
     8c4:      	ldp	q3, q4, [x21, #0x60]
     8c8:      	ldr	s2, [x21, #0x80]
     8cc:      	ldp	q29, q28, [x5]
     8d0:      	ldp	q27, q26, [x5, #0x20]
     8d4:      	fmul.4s	v0, v25, v25
     8d8:      	fmul.4s	v30, v24, v24
     8dc:      	fmul.4s	v31, v22, v22
     8e0:      	fmul.4s	v8, v23, v23
     8e4:      	fmul.4s	v9, v21, v21
     8e8:      	fmul.4s	v10, v20, v20
     8ec:      	fmul.4s	v11, v19, v19
     8f0:      	fmul.4s	v12, v1, v1
     8f4:      	fmul.4s	v13, v3, v3
     8f8:      	fadd.4s	v12, v12, v13
     8fc:      	fmul.4s	v13, v6, v6
     900:      	fmul.4s	v14, v5, v5
     904:      	fadd.4s	v10, v10, v14
     908:      	fadd.4s	v9, v9, v13
     90c:      	fmul.4s	v13, v7, v7
     910:      	fmul.4s	v14, v16, v16
     914:      	fadd.4s	v8, v8, v14
     918:      	fadd.4s	v31, v31, v13
     91c:      	fmul.4s	v13, v18, v18
     920:      	fmul.4s	v14, v17, v17
     924:      	fadd.4s	v30, v30, v14
     928:      	fadd.4s	v0, v0, v13
     92c:      	fmul.4s	v13, v2, v2
     930:      	fmul.4s	v14, v4, v4
     934:      	fadd.4s	v13, v0, v13
     938:      	mov.s	v0[0], v13[0]
     93c:      	fadd.4s	v30, v31, v30
     940:      	fadd.4s	v0, v8, v0
     944:      	fadd.4s	v31, v11, v14
     948:      	fadd.4s	v0, v9, v0
     94c:      	fadd.4s	v30, v10, v30
     950:      	fadd.4s	v30, v31, v30
     954:      	fadd.4s	v0, v12, v0
     958:      	ldp	q9, q8, [x5, #0x40]
     95c:      	rev64.4s	v31, v0
     960:      	rev64.4s	v10, v30
     964:      	fadd.4s	v30, v30, v10
     968:      	fadd.4s	v0, v0, v31
     96c:      	dup.4s	v31, v0[2]
     970:      	dup.4s	v10, v30[2]
     974:      	fadd.4s	v30, v30, v10
     978:      	fadd.4s	v0, v0, v31
     97c:      	ldp	q11, q10, [x5, #0x60]
     980:      	fadd.4s	v0, v0, v30
     984:      	fadd	s0, s0, s15
     988:      	fmov	s30, w11
     98c:      	fdiv	s0, s0, s30
     990:      	ldp	q13, q12, [x5, #0x80]
     994:      	fmov	s30, w14
     998:      	fadd	s0, s0, s30
     99c:      	fsqrt	s30, s0
     9a0:      	dup.4s	v31, v30[0]
     9a4:      	ldp	q14, q0, [x5, #0xa0]
     9a8:      	fdiv.4s	v25, v25, v31
     9ac:      	fmul.4s	v25, v29, v25
     9b0:      	fdiv.4s	v24, v24, v31
     9b4:      	fmul.4s	v24, v28, v24
     9b8:      	ldp	q28, q29, [x5, #0xc0]
     9bc:      	fdiv.4s	v23, v23, v31
     9c0:      	fmul.4s	v23, v27, v23
     9c4:      	fdiv.4s	v22, v22, v31
     9c8:      	fmul.4s	v22, v26, v22
     9cc:      	ldp	q26, q27, [x5, #0xe0]
     9d0:      	fdiv.4s	v21, v21, v31
     9d4:      	fmul.4s	v21, v9, v21
     9d8:      	ldr	s9, [x20]
     9dc:      	stp	q25, q24, [x22, #-0x80]
     9e0:      	fdiv.4s	v20, v20, v31
     9e4:      	fmul.4s	v20, v8, v20
     9e8:      	fdiv.4s	v1, v1, v31
     9ec:      	fmul.4s	v1, v11, v1
     9f0:      	stp	q23, q22, [x22, #-0x60]
     9f4:      	fdiv.4s	v19, v19, v31
     9f8:      	fmul.4s	v19, v10, v19
     9fc:      	fdiv.4s	v18, v18, v31
     a00:      	fmul.4s	v18, v13, v18
     a04:      	stp	q21, q20, [x22, #-0x40]
     a08:      	stp	q1, q19, [x22, #-0x20]
     a0c:      	fdiv.4s	v1, v17, v31
     a10:      	fmul.4s	v1, v12, v1
     a14:      	stp	q18, q1, [x22]
     a18:      	fdiv.4s	v1, v16, v31
     a1c:      	fmul.4s	v1, v14, v1
     a20:      	fdiv.4s	v7, v7, v31
     a24:      	fmul.4s	v0, v0, v7
     a28:      	stp	q1, q0, [x22, #0x20]
     a2c:      	fdiv.4s	v0, v6, v31
     a30:      	fmul.4s	v0, v28, v0
     a34:      	fdiv.4s	v1, v5, v31
     a38:      	fmul.4s	v1, v29, v1
     a3c:      	stp	q0, q1, [x22, #0x40]
     a40:      	fdiv.4s	v0, v4, v31
     a44:      	fdiv.4s	v1, v3, v31
     a48:      	fmul.4s	v1, v26, v1
     a4c:      	fmul.4s	v0, v27, v0
     a50:      	stp	q1, q0, [x22, #0x60]
     a54:      	fdiv.4s	v0, v2, v30
     a58:      	fmul.4s	v0, v9, v0
     a5c:      	str	s0, [x22, #0x80]
     a60:      	add	x21, x21, #0x104
     a64:      	add	x22, x22, #0x104
     a68:      	subs	x27, x27, #0x1
     a6c:      	b.ne	0x8a8 <ltmp0+0x8a8>
     a70:      	and	w9, w16, #0x7
     a74:      	cbz	w9, 0x800 <ltmp0+0x800>
     a78:      	dup.4s	v0, w9
     a7c:      	adrp	x9, 0x0 <ltmp0>
     a80:      	ldr	q1, [x9]
     a84:      	adrp	x9, 0x0 <ltmp0>
     a88:      	ldr	q2, [x9]
     a8c:      	cmhi.4s	v3, v0, v2
     a90:      	cmhi.4s	v4, v0, v1
     a94:      	uzp1.8h	v1, v4, v3
     a98:      	umaxv.8h	h0, v1
     a9c:      	fmov	w9, s0
     aa0:      	tbz	w9, #0x0, 0x800 <ltmp0+0x800>
     aa4:      	mov	x22, #0x0               ; =0
     aa8:      	ldr	x5, [x0]
     aac:      	ldr	x16, [x0, #0x10]
     ab0:      	ldr	x9, [x0, #0x30]
     ab4:      	str	x9, [sp, #0xb0]
     ab8:      	adrp	x9, 0x0 <ltmp0>
     abc:      	ldr	q0, [x9]
     ac0:      	str	q1, [sp, #0x30]
     ac4:      	and.16b	v0, v1, v0
     ac8:      	addv.8h	h5, v0
     acc:      	fmov	w9, s5
     ad0:      	and	w9, w9, #0xff
     ad4:      	str	w9, [sp, #0x80]
     ad8:      	xtn.4h	v7, v4
     adc:      	uzp1.8b	v0, v7, v0
     ae0:      	ubfiz	w9, w26, #2, #27
     ae4:      	orr	w9, w9, w4
     ae8:      	dup.4s	v1, w9
     aec:      	and.16b	v2, v4, v1
     af0:      	and.16b	v1, v3, v1
     af4:      	ushll2.2d	v23, v1, #0x0
     af8:      	ushll2.2d	v24, v2, #0x0
     afc:      	ushll.2d	v25, v1, #0x0
     b00:      	ushll.2d	v6, v2, #0x0
     b04:      	umov.b	w21, v0[0]
     b08:      	umull	x9, w9, w10
     b0c:      	tst	w21, #0x1
     b10:      	csel	x9, x9, xzr, ne
     b14:      	str	x9, [sp, #0xa0]
     b18:      	add	x15, x5, x9
     b1c:      	b	0xb40 <ltmp0+0xb40>
     b20:      	add	x9, x6, x22
     b24:      	ldp	q0, q16, [x9]
     b28:      	bif.16b	v1, v16, v3
     b2c:      	bit.16b	v0, v2, v4
     b30:      	stp	q0, q1, [x9]
     b34:      	add	x22, x22, #0x20
     b38:      	cmp	x22, #0x100
     b3c:      	b.eq	0xbd8 <ltmp0+0xbd8>
     b40:      	fmov	w12, s5
     b44:      	add	x9, x15, x22
     b48:      	movi.2d	v2, #0000000000000000
     b4c:      	movi.2d	v1, #0000000000000000
     b50:      	tbnz	w12, #0x0, 0xb78 <ltmp0+0xb78>
     b54:      	and	w2, w12, #0xff
     b58:      	tbnz	w2, #0x1, 0xb84 <ltmp0+0xb84>
     b5c:      	tbnz	w2, #0x2, 0xb90 <ltmp0+0xb90>
     b60:      	tbnz	w2, #0x3, 0xb9c <ltmp0+0xb9c>
     b64:      	tbnz	w2, #0x4, 0xba8 <ltmp0+0xba8>
     b68:      	tbnz	w2, #0x5, 0xbb4 <ltmp0+0xbb4>
     b6c:      	tbnz	w2, #0x6, 0xbc0 <ltmp0+0xbc0>
     b70:      	tbz	w2, #0x7, 0xb20 <ltmp0+0xb20>
     b74:      	b	0xbcc <ltmp0+0xbcc>
     b78:      	ldr	s2, [x9]
     b7c:      	and	w2, w12, #0xff
     b80:      	tbz	w2, #0x1, 0xb5c <ltmp0+0xb5c>
     b84:      	add	x12, x9, #0x4
     b88:      	ld1.s	{ v2 }[1], [x12]
     b8c:      	tbz	w2, #0x2, 0xb60 <ltmp0+0xb60>
     b90:      	add	x12, x9, #0x8
     b94:      	ld1.s	{ v2 }[2], [x12]
     b98:      	tbz	w2, #0x3, 0xb64 <ltmp0+0xb64>
     b9c:      	add	x12, x9, #0xc
     ba0:      	ld1.s	{ v2 }[3], [x12]
     ba4:      	tbz	w2, #0x4, 0xb68 <ltmp0+0xb68>
     ba8:      	add	x12, x9, #0x10
     bac:      	ld1.s	{ v1 }[0], [x12]
     bb0:      	tbz	w2, #0x5, 0xb6c <ltmp0+0xb6c>
     bb4:      	add	x12, x9, #0x14
     bb8:      	ld1.s	{ v1 }[1], [x12]
     bbc:      	tbz	w2, #0x6, 0xb70 <ltmp0+0xb70>
     bc0:      	add	x12, x9, #0x18
     bc4:      	ld1.s	{ v1 }[2], [x12]
     bc8:      	tbz	w2, #0x7, 0xb20 <ltmp0+0xb20>
     bcc:      	add	x9, x9, #0x1c
     bd0:      	ld1.s	{ v1 }[3], [x9]
     bd4:      	b	0xb20 <ltmp0+0xb20>
     bd8:      	str	w30, [sp, #0xc8]
     bdc:      	uzp1.8b	v0, v7, v0
     be0:      	sshll.2d	v18, v4, #0x0
     be4:      	movi.2d	v17, #0000000000000000
     be8:      	mov.b	v17[0], v0[0]
     bec:      	adrp	x9, 0x0 <ltmp0>
     bf0:      	ldr	d1, [x9]
     bf4:      	str	d1, [sp, #0x48]
     bf8:      	and.8b	v1, v17, v1
     bfc:      	addv.8b	b1, v1
     c00:      	fmov	w4, s1
     c04:      	umaxv.8b	b1, v17
     c08:      	fmov	w12, s1
     c0c:      	rbit	w9, w4
     c10:      	clz	w9, w9
     c14:      	tst	w12, #0x1
     c18:      	csel	w30, w9, wzr, ne
     c1c:      	adrp	x9, 0x0 <ltmp0>
     c20:      	ldr	q1, [x9]
     c24:      	mov	w9, #0x40               ; =64
     c28:      	dup.2d	v20, x9
     c2c:      	mov.16b	v7, v18
     c30:      	bsl.16b	v7, v1, v20
     c34:      	xtn.2s	v1, v6
     c38:      	movi.2s	v2, #0x41
     c3c:      	umlal.2d	v7, v1, v2
     c40:      	movi.2d	v1, #0000000000000000
     c44:      	mov.b	v1[0], v0[0]
     c48:      	ushll.2d	v0, v1, #0x0
     c4c:      	shl.2d	v0, v0, #0x3f
     c50:      	cmlt.2d	v0, v0, #0
     c54:      	str	q7, [sp, #0x90]
     c58:      	and.16b	v0, v0, v7
     c5c:      	movi.2d	v1, #0000000000000000
     c60:      	stp	q1, q1, [sp, #0x2f0]
     c64:      	stp	q0, q1, [sp, #0x2d0]
     c68:      	and	x9, x30, #0x7
     c6c:      	add	x13, sp, #0x2d0
     c70:      	ldr	x9, [x13, x9, lsl #3]
     c74:      	sub	x9, x9, x30
     c78:      	add	x9, x5, x9, lsl #2
     c7c:      	movi.2d	v16, #0000000000000000
     c80:      	movi.2d	v6, #0000000000000000
     c84:      	tbnz	w12, #0x0, 0x1524 <ltmp0+0x1524>
     c88:      	tbnz	w4, #0x1, 0x152c <ltmp0+0x152c>
     c8c:      	tbnz	w4, #0x2, 0x1538 <ltmp0+0x1538>
     c90:      	tbnz	w4, #0x3, 0x1544 <ltmp0+0x1544>
     c94:      	tbnz	w4, #0x4, 0x1550 <ltmp0+0x1550>
     c98:      	tbnz	w4, #0x5, 0x155c <ltmp0+0x155c>
     c9c:      	tbnz	w4, #0x6, 0x1568 <ltmp0+0x1568>
     ca0:      	tbz	w4, #0x7, 0xcac <ltmp0+0xcac>
     ca4:      	add	x9, x9, #0x1c
     ca8:      	ld1.s	{ v6 }[3], [x9]
     cac:      	sshll.2d	v0, v3, #0x0
     cb0:      	sshll2.2d	v26, v4, #0x0
     cb4:      	sshll2.2d	v13, v3, #0x0
     cb8:      	adrp	x9, 0x0 <ltmp0>
     cbc:      	ldr	q1, [x9]
     cc0:      	and.16b	v1, v13, v1
     cc4:      	adrp	x9, 0x0 <ltmp0>
     cc8:      	ldr	q2, [x9]
     ccc:      	and.16b	v2, v26, v2
     cd0:      	adrp	x9, 0x0 <ltmp0>
     cd4:      	ldr	q19, [x9]
     cd8:      	and.16b	v21, v0, v19
     cdc:      	adrp	x9, 0x0 <ltmp0>
     ce0:      	ldr	q19, [x9]
     ce4:      	and.16b	v27, v18, v19
     ce8:      	adrp	x9, 0x0 <ltmp0>
     cec:      	ldr	q18, [x9]
     cf0:      	bif.16b	v18, v20, v0
     cf4:      	adrp	x9, 0x0 <ltmp0>
     cf8:      	ldr	q0, [x9]
     cfc:      	mov.16b	v19, v26
     d00:      	bsl.16b	v19, v0, v20
     d04:      	adrp	x9, 0x0 <ltmp0>
     d08:      	ldr	q0, [x9]
     d0c:      	bit.16b	v20, v0, v13
     d10:      	xtn.2s	v0, v25
     d14:      	xtn.2s	v24, v24
     d18:      	xtn.2s	v23, v23
     d1c:      	movi.2s	v7, #0x41
     d20:      	umlal.2d	v20, v23, v7
     d24:      	umlal.2d	v19, v24, v7
     d28:      	stp	q20, q19, [sp, #0x50]
     d2c:      	umlal.2d	v18, v0, v7
     d30:      	str	q18, [sp, #0x70]
     d34:      	sshll.2d	v0, v4, #0x0
     d38:      	sshll.2d	v24, v3, #0x0
     d3c:      	stp	q27, q2, [sp, #0x290]
     d40:      	stp	q21, q1, [sp, #0x2b0]
     d44:      	and	x9, x30, #0x7
     d48:      	add	x12, sp, #0x290
     d4c:      	ldr	x9, [x12, x9, lsl #3]
     d50:      	orr	x9, x9, #0x100
     d54:      	sub	x9, x9, x30, lsl #2
     d58:      	tst	w4, #0xff
     d5c:      	csel	x9, xzr, x9, eq
     d60:      	str	x9, [sp, #0x28]
     d64:      	add	x9, x6, x9
     d68:      	ldp	q1, q2, [x9]
     d6c:      	zip2.8b	v21, v17, v0
     d70:      	ushll.4s	v21, v21, #0x0
     d74:      	shl.4s	v21, v21, #0x1f
     d78:      	cmlt.4s	v21, v21, #0
     d7c:      	bit.16b	v2, v6, v21
     d80:      	zip1.8b	v21, v17, v0
     d84:      	ushll.4s	v21, v21, #0x0
     d88:      	shl.4s	v21, v21, #0x1f
     d8c:      	cmlt.4s	v21, v21, #0
     d90:      	bit.16b	v1, v16, v21
     d94:      	stp	q1, q2, [x9]
     d98:      	dup.2d	v1, x17
     d9c:      	and.16b	v2, v13, v1
     da0:      	and.16b	v23, v26, v1
     da4:      	and.16b	v24, v24, v1
     da8:      	and.16b	v1, v0, v1
     dac:      	tst	w21, #0x1
     db0:      	csel	x9, x17, xzr, ne
     db4:      	ldr	q0, [sp, #0x4b0]
     db8:      	ldr	q21, [sp, #0x4a0]
     dbc:      	fmul.4s	v21, v21, v21
     dc0:      	fmul.4s	v0, v0, v0
     dc4:      	and.16b	v28, v3, v0
     dc8:      	and.16b	v27, v4, v21
     dcc:      	ldr	q0, [sp, #0x490]
     dd0:      	ldr	q21, [sp, #0x480]
     dd4:      	fmul.4s	v21, v21, v21
     dd8:      	fmul.4s	v0, v0, v0
     ddc:      	and.16b	v29, v3, v0
     de0:      	and.16b	v30, v4, v21
     de4:      	ldr	q0, [sp, #0x470]
     de8:      	ldr	q21, [sp, #0x460]
     dec:      	fmul.4s	v21, v21, v21
     df0:      	fmul.4s	v0, v0, v0
     df4:      	and.16b	v8, v3, v0
     df8:      	and.16b	v31, v4, v21
     dfc:      	ldr	q0, [sp, #0x450]
     e00:      	ldr	q21, [sp, #0x440]
     e04:      	fmul.4s	v21, v21, v21
     e08:      	fmul.4s	v0, v0, v0
     e0c:      	and.16b	v9, v3, v0
     e10:      	and.16b	v10, v4, v21
     e14:      	sshll.2d	v0, v4, #0x0
     e18:      	sshll.2d	v21, v3, #0x0
     e1c:      	add	x9, x6, x9, lsl #5
     e20:      	ldp	q11, q25, [x9]
     e24:      	and.16b	v11, v4, v11
     e28:      	and.16b	v25, v3, v25
     e2c:      	fmul.4s	v25, v25, v25
     e30:      	fmul.4s	v11, v11, v11
     e34:      	fadd.4s	v12, v10, v11
     e38:      	fadd.4s	v11, v9, v25
     e3c:      	ldp	q14, q25, [x9, #0x20]
     e40:      	and.16b	v14, v4, v14
     e44:      	and.16b	v25, v3, v25
     e48:      	fmul.4s	v25, v25, v25
     e4c:      	fmul.4s	v14, v14, v14
     e50:      	fadd.4s	v14, v31, v14
     e54:      	fadd.4s	v25, v8, v25
     e58:      	ldp	q18, q15, [x9, #0x40]
     e5c:      	and.16b	v18, v4, v18
     e60:      	and.16b	v15, v3, v15
     e64:      	fmul.4s	v15, v15, v15
     e68:      	fmul.4s	v18, v18, v18
     e6c:      	fadd.4s	v18, v30, v18
     e70:      	fadd.4s	v15, v29, v15
     e74:      	ldp	q20, q19, [x9, #0x60]
     e78:      	and.16b	v20, v4, v20
     e7c:      	and.16b	v19, v3, v19
     e80:      	fmul.4s	v19, v19, v19
     e84:      	fmul.4s	v20, v20, v20
     e88:      	fadd.4s	v20, v27, v20
     e8c:      	fadd.4s	v19, v28, v19
     e90:      	dup.2d	v7, x17
     e94:      	and.16b	v22, v13, v7
     e98:      	add.2d	v2, v2, v22
     e9c:      	and.16b	v22, v26, v7
     ea0:      	add.2d	v23, v23, v22
     ea4:      	and.16b	v21, v21, v7
     ea8:      	add.2d	v24, v24, v21
     eac:      	and.16b	v0, v0, v7
     eb0:      	add.2d	v0, v1, v0
     eb4:      	bit.16b	v9, v11, v3
     eb8:      	bit.16b	v10, v12, v4
     ebc:      	bit.16b	v8, v25, v3
     ec0:      	bit.16b	v31, v14, v4
     ec4:      	bit.16b	v29, v15, v3
     ec8:      	bit.16b	v30, v18, v4
     ecc:      	bit.16b	v28, v19, v3
     ed0:      	bit.16b	v27, v20, v4
     ed4:      	fmov	x9, d1
     ed8:      	add	x12, x9, #0x4
     edc:      	ands	w5, w21, #0x1
     ee0:      	csel	x9, x12, x9, ne
     ee4:      	mov.16b	v1, v0
     ee8:      	cmp	x9, #0x8
     eec:      	b.lt	0xe14 <ltmp0+0xe14>
     ef0:      	mov	x9, #0x0                ; =0
     ef4:      	ushll2.2d	v0, v3, #0x0
     ef8:      	dup.2d	v1, x28
     efc:      	and.16b	v23, v0, v1
     f00:      	ushll2.2d	v0, v4, #0x0
     f04:      	and.16b	v24, v0, v1
     f08:      	ushll.2d	v0, v3, #0x0
     f0c:      	and.16b	v25, v0, v1
     f10:      	ushll.2d	v0, v4, #0x0
     f14:      	and.16b	v26, v0, v1
     f18:      	movi.2d	v13, #0000000000000000
     f1c:      	and	x4, x21, #0x1
     f20:      	movi.2d	v14, #0000000000000000
     f24:      	movi.2d	v15, #0000000000000000
     f28:      	movi.2d	v2, #0000000000000000
     f2c:      	b	0xf68 <ltmp0+0xf68>
     f30:      	add	x9, x1, x15
     f34:      	ldp	q0, q7, [x9]
     f38:      	bit.16b	v7, v21, v3
     f3c:      	bit.16b	v0, v1, v4
     f40:      	stp	q0, q7, [x9]
     f44:      	add.2d	v0, v13, v26
     f48:      	add.2d	v14, v14, v24
     f4c:      	add.2d	v15, v15, v25
     f50:      	add.2d	v2, v2, v23
     f54:      	fmov	x9, d13
     f58:      	add	x9, x9, x4
     f5c:      	mov.16b	v13, v0
     f60:      	cmp	x9, #0x8
     f64:      	b.ge	0x1004 <ltmp0+0x1004>
     f68:      	fmov	w12, s5
     f6c:      	lsl	x15, x9, #5
     f70:      	add	x9, x16, x15
     f74:      	movi.2d	v1, #0000000000000000
     f78:      	movi.2d	v21, #0000000000000000
     f7c:      	tbnz	w12, #0x0, 0xfa4 <ltmp0+0xfa4>
     f80:      	and	w2, w12, #0xff
     f84:      	tbnz	w2, #0x1, 0xfb0 <ltmp0+0xfb0>
     f88:      	tbnz	w2, #0x2, 0xfbc <ltmp0+0xfbc>
     f8c:      	tbnz	w2, #0x3, 0xfc8 <ltmp0+0xfc8>
     f90:      	tbnz	w2, #0x4, 0xfd4 <ltmp0+0xfd4>
     f94:      	tbnz	w2, #0x5, 0xfe0 <ltmp0+0xfe0>
     f98:      	tbnz	w2, #0x6, 0xfec <ltmp0+0xfec>
     f9c:      	tbz	w2, #0x7, 0xf30 <ltmp0+0xf30>
     fa0:      	b	0xff8 <ltmp0+0xff8>
     fa4:      	ldr	s1, [x9]
     fa8:      	and	w2, w12, #0xff
     fac:      	tbz	w2, #0x1, 0xf88 <ltmp0+0xf88>
     fb0:      	add	x12, x9, #0x4
     fb4:      	ld1.s	{ v1 }[1], [x12]
     fb8:      	tbz	w2, #0x2, 0xf8c <ltmp0+0xf8c>
     fbc:      	add	x12, x9, #0x8
     fc0:      	ld1.s	{ v1 }[2], [x12]
     fc4:      	tbz	w2, #0x3, 0xf90 <ltmp0+0xf90>
     fc8:      	add	x12, x9, #0xc
     fcc:      	ld1.s	{ v1 }[3], [x12]
     fd0:      	tbz	w2, #0x4, 0xf94 <ltmp0+0xf94>
     fd4:      	add	x12, x9, #0x10
     fd8:      	ld1.s	{ v21 }[0], [x12]
     fdc:      	tbz	w2, #0x5, 0xf98 <ltmp0+0xf98>
     fe0:      	add	x12, x9, #0x14
     fe4:      	ld1.s	{ v21 }[1], [x12]
     fe8:      	tbz	w2, #0x6, 0xf9c <ltmp0+0xf9c>
     fec:      	add	x12, x9, #0x18
     ff0:      	ld1.s	{ v21 }[2], [x12]
     ff4:      	tbz	w2, #0x7, 0xf30 <ltmp0+0xf30>
     ff8:      	add	x9, x9, #0x1c
     ffc:      	ld1.s	{ v21 }[3], [x9]
    1000:      	b	0xf30 <ltmp0+0xf30>
    1004:      	str	w25, [sp, #0xcc]
    1008:      	mov	x23, x3
    100c:      	ldr	q0, [sp, #0x30]
    1010:      	xtn.8b	v22, v0
    1014:      	fmul.4s	v0, v6, v6
    1018:      	fmul.4s	v1, v16, v16
    101c:      	fadd.4s	v1, v1, v10
    1020:      	fadd.4s	v0, v0, v9
    1024:      	zip2.8b	v2, v17, v0
    1028:      	ushll.4s	v2, v2, #0x0
    102c:      	shl.4s	v2, v2, #0x1f
    1030:      	cmlt.4s	v2, v2, #0
    1034:      	and.16b	v0, v2, v0
    1038:      	zip1.8b	v2, v17, v0
    103c:      	ushll.4s	v2, v2, #0x0
    1040:      	shl.4s	v2, v2, #0x1f
    1044:      	cmlt.4s	v2, v2, #0
    1048:      	movi.2d	v7, #0000000000000000
    104c:      	mov.b	v7[2], v22[1]
    1050:      	mov.b	v7[4], v22[2]
    1054:      	mov.b	v7[6], v22[3]
    1058:      	and.16b	v1, v2, v1
    105c:      	ushll.4s	v2, v7, #0x0
    1060:      	shl.4s	v2, v2, #0x1f
    1064:      	cmlt.4s	v2, v2, #0
    1068:      	bit.16b	v1, v12, v2
    106c:      	zip2.8b	v2, v22, v0
    1070:      	ushll.4s	v2, v2, #0x0
    1074:      	shl.4s	v2, v2, #0x1f
    1078:      	cmlt.4s	v2, v2, #0
    107c:      	bit.16b	v0, v11, v2
    1080:      	fadd.4s	v0, v8, v0
    1084:      	fadd.4s	v1, v31, v1
    1088:      	fadd.4s	v1, v30, v1
    108c:      	fadd.4s	v0, v29, v0
    1090:      	fadd.4s	v2, v28, v0
    1094:      	fadd.4s	v1, v27, v1
    1098:      	umov.b	w15, v22[1]
    109c:      	mov	s0, v1[1]
    10a0:      	tst	w5, w15
    10a4:      	movi	d15, #0000000000000000
    10a8:      	fcsel	s21, s0, s15, ne
    10ac:      	mvn	w9, w15
    10b0:      	add	x12, sp, #0x260
    10b4:      	bfi	x12, x9, #2, #1
    10b8:      	add	x13, sp, #0x118
    10bc:      	bfxil	x13, x9, #0, #1
    10c0:      	str	d22, [sp, #0x118]
    10c4:      	ldrb	w9, [x13]
    10c8:      	and	w9, w15, w9
    10cc:      	stp	q1, q2, [sp, #0x260]
    10d0:      	ldr	s0, [x12]
    10d4:      	tst	w9, #0x1
    10d8:      	fcsel	s27, s0, s15, ne
    10dc:      	umov.b	w24, v22[2]
    10e0:      	ands	w9, w24, #0x1
    10e4:      	mov	w12, #0x3               ; =3
    10e8:      	csinc	w12, w12, wzr, ne
    10ec:      	add	x0, sp, #0x118
    10f0:      	orr	x13, x0, x12
    10f4:      	ldrb	w13, [x13]
    10f8:      	add	x2, sp, #0x240
    10fc:      	orr	x12, x2, x12, lsl #2
    1100:      	stp	q1, q2, [sp, #0x240]
    1104:      	ldr	s0, [x12]
    1108:      	tst	w9, w13
    110c:      	fcsel	s28, s0, s15, ne
    1110:      	umov.b	w9, v22[3]
    1114:      	ands	w12, w9, #0x1
    1118:      	cinc	w13, w28, ne
    111c:      	add	x2, sp, #0x118
    1120:      	bfxil	x2, x13, #0, #3
    1124:      	ldrb	w2, [x2]
    1128:      	add	x3, sp, #0x220
    112c:      	orr	x13, x3, x13, lsl #2
    1130:      	stp	q1, q2, [sp, #0x220]
    1134:      	ldr	s0, [x13]
    1138:      	tst	w12, w2
    113c:      	umov.b	w2, v22[4]
    1140:      	fcsel	s0, s0, s15, ne
    1144:      	ands	w12, w2, #0x1
    1148:      	mov	w13, #0x5               ; =5
    114c:      	csinc	w13, w13, wzr, ne
    1150:      	orr	x19, x0, x13
    1154:      	ldrb	w20, [x19]
    1158:      	stp	q1, q2, [sp, #0x200]
    115c:      	add	x3, sp, #0x200
    1160:      	ldr	s7, [x3, w13, uxtw #2]
    1164:      	mov	w13, #0x2               ; =2
    1168:      	mov	w22, #0x6               ; =6
    116c:      	csel	w27, w22, w13, ne
    1170:      	umov.b	w19, v22[5]
    1174:      	tst	w12, w20
    1178:      	fcsel	s29, s7, s15, ne
    117c:      	ands	w13, w19, #0x1
    1180:      	csinc	w20, w17, wzr, ne
    1184:      	orr	x28, x0, x20
    1188:      	ldrb	w28, [x28]
    118c:      	stp	q1, q2, [sp, #0x1e0]
    1190:      	add	x3, sp, #0x1e0
    1194:      	ldr	s7, [x3, w20, uxtw #2]
    1198:      	umov.b	w20, v22[6]
    119c:      	tst	w13, w28
    11a0:      	fcsel	s7, s7, s15, ne
    11a4:      	ands	w28, w20, #0x1
    11a8:      	mov	w13, #0x7               ; =7
    11ac:      	csinc	w13, w13, wzr, ne
    11b0:      	orr	x3, x0, x13
    11b4:      	ldrb	w3, [x3]
    11b8:      	stp	q1, q2, [sp, #0x1c0]
    11bc:      	add	x25, sp, #0x1c0
    11c0:      	ldr	s18, [x25, w13, uxtw #2]
    11c4:      	umov.b	w13, v22[7]
    11c8:      	tst	w28, w3
    11cc:      	fcsel	s18, s18, s15, ne
    11d0:      	ands	w3, w13, #0x1
    11d4:      	csinc	w28, w22, wzr, ne
    11d8:      	orr	x22, x0, x28
    11dc:      	ldrb	w22, [x22]
    11e0:      	tst	w3, w22
    11e4:      	stp	q1, q2, [sp, #0x1a0]
    11e8:      	add	x3, sp, #0x1a0
    11ec:      	ldr	s19, [x3, w28, uxtw #2]
    11f0:      	fcsel	s19, s19, s15, ne
    11f4:      	mov.s	v21[1], v27[0]
    11f8:      	mov.s	v21[2], v28[0]
    11fc:      	mov.s	v21[3], v0[0]
    1200:      	mov.s	v29[1], v7[0]
    1204:      	mov.s	v29[2], v18[0]
    1208:      	mov.s	v29[3], v19[0]
    120c:      	fadd.4s	v0, v1, v21
    1210:      	mov	s1, v0[2]
    1214:      	tst	w5, w24
    1218:      	fcsel	s1, s1, s15, ne
    121c:      	orr	x3, x0, x27
    1220:      	ldrb	w3, [x3]
    1224:      	tst	w12, w3
    1228:      	fadd.4s	v2, v2, v29
    122c:      	stp	q0, q2, [sp, #0x180]
    1230:      	add	x12, sp, #0x180
    1234:      	ldr	s7, [x12, w27, uxtw #2]
    1238:      	fcsel	s7, s7, s15, ne
    123c:      	tst	w5, w2
    1240:      	fadd.4s	v2, v2, v7
    1244:      	fcsel	s2, s2, s15, ne
    1248:      	ands	w12, w21, #0x1
    124c:      	fadd.4s	v0, v0, v1
    1250:      	fadd	s0, s0, s2
    1254:      	fcsel	s1, s0, s15, ne
    1258:      	tst	w12, w15
    125c:      	fcsel	s2, s0, s15, ne
    1260:      	tst	w12, w24
    1264:      	fcsel	s7, s0, s15, ne
    1268:      	tst	w9, #0x1
    126c:      	fcsel	s18, s1, s15, ne
    1270:      	tst	w12, w2
    1274:      	fcsel	s0, s0, s15, ne
    1278:      	tst	w19, #0x1
    127c:      	fcsel	s19, s1, s15, ne
    1280:      	tst	w20, #0x1
    1284:      	fcsel	s20, s1, s15, ne
    1288:      	tst	w13, #0x1
    128c:      	sshll.2d	v21, v4, #0x0
    1290:      	shl.8b	v22, v17, #0x7
    1294:      	cmlt.8b	v22, v22, #0
    1298:      	ldr	d27, [sp, #0x48]
    129c:      	and.8b	v22, v22, v27
    12a0:      	fcsel	s27, s1, s15, ne
    12a4:      	mov.s	v0[1], v19[0]
    12a8:      	mov.s	v0[2], v20[0]
    12ac:      	mov.s	v0[3], v27[0]
    12b0:      	mov.s	v1[1], v2[0]
    12b4:      	mov.s	v1[2], v7[0]
    12b8:      	mov.s	v1[3], v18[0]
    12bc:      	ldr	w9, [sp, #0x80]
    12c0:      	rbit	w9, w9
    12c4:      	clz	w9, w9
    12c8:      	stp	q1, q0, [sp, #0x160]
    12cc:      	and	x9, x9, #0x7
    12d0:      	add	x12, sp, #0x160
    12d4:      	ldr	s2, [x12, x9, lsl #2]
    12d8:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    12dc:      	ldr	q0, [x9]
    12e0:      	and.16b	v0, v21, v0
    12e4:      	movi.2d	v1, #0000000000000000
    12e8:      	stp	q1, q1, [sp, #0x140]
    12ec:      	stp	q0, q1, [sp, #0x120]
    12f0:      	and	x9, x30, #0x7
    12f4:      	add	x12, sp, #0x120
    12f8:      	ldr	x9, [x12, x9, lsl #3]
    12fc:      	addv.8b	b22, v22
    1300:      	sub	x9, x9, x30
    1304:      	add	x9, x16, x9, lsl #2
    1308:      	fmov	w15, s22
    130c:      	movi.2d	v27, #0000000000000000
    1310:      	movi.2d	v21, #0000000000000000
    1314:      	tbnz	w15, #0x0, 0x1578 <ltmp0+0x1578>
    1318:      	ldr	x16, [sp, #0xb0]
    131c:      	tbnz	w15, #0x1, 0x1584 <ltmp0+0x1584>
    1320:      	mov	x3, x23
    1324:      	mov	w19, #0x20              ; =32
    1328:      	ldp	w24, w23, [sp, #0x18]
    132c:      	mov	w28, #0x1               ; =1
    1330:      	ldr	w25, [sp, #0xcc]
    1334:      	tbnz	w15, #0x2, 0x15a4 <ltmp0+0x15a4>
    1338:      	ldr	x0, [sp, #0x20]
    133c:      	tbnz	w15, #0x3, 0x15b4 <ltmp0+0x15b4>
    1340:      	tbnz	w15, #0x4, 0x15c0 <ltmp0+0x15c0>
    1344:      	tbnz	w15, #0x5, 0x15cc <ltmp0+0x15cc>
    1348:      	tbnz	w15, #0x6, 0x15d8 <ltmp0+0x15d8>
    134c:      	tbz	w15, #0x7, 0x1358 <ltmp0+0x1358>
    1350:      	add	x9, x9, #0x1c
    1354:      	ld1.s	{ v21 }[3], [x9]
    1358:      	mov	x12, #0x0               ; =0
    135c:      	fadd	s0, s2, s15
    1360:      	fmov	s1, w11
    1364:      	fdiv	s0, s0, s1
    1368:      	ldr	x9, [sp, #0x28]
    136c:      	add	x9, x1, x9
    1370:      	ldp	q1, q2, [x9]
    1374:      	zip2.8b	v7, v17, v0
    1378:      	ushll.4s	v7, v7, #0x0
    137c:      	shl.4s	v7, v7, #0x1f
    1380:      	cmlt.4s	v7, v7, #0
    1384:      	bsl.16b	v7, v21, v2
    1388:      	zip1.8b	v2, v17, v0
    138c:      	ushll.4s	v2, v2, #0x0
    1390:      	shl.4s	v2, v2, #0x1f
    1394:      	cmlt.4s	v2, v2, #0
    1398:      	bit.16b	v1, v27, v2
    139c:      	fmov	s2, w14
    13a0:      	fadd	s0, s0, s2
    13a4:      	fsqrt	s0, s0
    13a8:      	dup.4s	v2, v0[0]
    13ac:      	stp	q1, q7, [x9]
    13b0:      	ldr	x9, [sp, #0xa0]
    13b4:      	add	x9, x16, x9
    13b8:      	movi.2d	v1, #0000000000000000
    13bc:      	movi.2d	v17, #0000000000000000
    13c0:      	movi.2d	v28, #0000000000000000
    13c4:      	movi.2d	v29, #0000000000000000
    13c8:      	b	0x13f0 <ltmp0+0x13f0>
    13cc:      	add.2d	v0, v1, v26
    13d0:      	add.2d	v17, v17, v24
    13d4:      	add.2d	v28, v28, v25
    13d8:      	add.2d	v29, v29, v23
    13dc:      	fmov	x12, d1
    13e0:      	add	x12, x12, x4
    13e4:      	mov.16b	v1, v0
    13e8:      	cmp	x12, #0x8
    13ec:      	b.ge	0x14c0 <ltmp0+0x14c0>
    13f0:      	fmov	w13, s5
    13f4:      	lsl	x12, x12, #5
    13f8:      	add	x15, x6, x12
    13fc:      	ldp	q0, q30, [x15]
    1400:      	and.16b	v0, v4, v0
    1404:      	fdiv.4s	v0, v0, v2
    1408:      	add	x15, x1, x12
    140c:      	ldp	q7, q31, [x15]
    1410:      	and.16b	v7, v4, v7
    1414:      	fmul.4s	v8, v0, v7
    1418:      	add	x12, x9, x12
    141c:      	tbnz	w13, #0x0, 0x1454 <ltmp0+0x1454>
    1420:      	and	w13, w13, #0xff
    1424:      	tbnz	w13, #0x1, 0x1460 <ltmp0+0x1460>
    1428:      	tbnz	w13, #0x2, 0x146c <ltmp0+0x146c>
    142c:      	tbnz	w13, #0x3, 0x1478 <ltmp0+0x1478>
    1430:      	and.16b	v0, v3, v30
    1434:      	fdiv.4s	v0, v0, v2
    1438:      	and.16b	v7, v3, v31
    143c:      	fmul.4s	v30, v0, v7
    1440:      	tbnz	w13, #0x4, 0x1494 <ltmp0+0x1494>
    1444:      	tbnz	w13, #0x5, 0x149c <ltmp0+0x149c>
    1448:      	tbnz	w13, #0x6, 0x14a8 <ltmp0+0x14a8>
    144c:      	tbz	w13, #0x7, 0x13cc <ltmp0+0x13cc>
    1450:      	b	0x14b4 <ltmp0+0x14b4>
    1454:      	str	s8, [x12]
    1458:      	and	w13, w13, #0xff
    145c:      	tbz	w13, #0x1, 0x1428 <ltmp0+0x1428>
    1460:      	add	x15, x12, #0x4
    1464:      	st1.s	{ v8 }[1], [x15]
    1468:      	tbz	w13, #0x2, 0x142c <ltmp0+0x142c>
    146c:      	add	x15, x12, #0x8
    1470:      	st1.s	{ v8 }[2], [x15]
    1474:      	tbz	w13, #0x3, 0x1430 <ltmp0+0x1430>
    1478:      	add	x15, x12, #0xc
    147c:      	st1.s	{ v8 }[3], [x15]
    1480:      	and.16b	v0, v3, v30
    1484:      	fdiv.4s	v0, v0, v2
    1488:      	and.16b	v7, v3, v31
    148c:      	fmul.4s	v30, v0, v7
    1490:      	tbz	w13, #0x4, 0x1444 <ltmp0+0x1444>
    1494:      	str	s30, [x12, #0x10]
    1498:      	tbz	w13, #0x5, 0x1448 <ltmp0+0x1448>
    149c:      	add	x15, x12, #0x14
    14a0:      	st1.s	{ v30 }[1], [x15]
    14a4:      	tbz	w13, #0x6, 0x144c <ltmp0+0x144c>
    14a8:      	add	x15, x12, #0x18
    14ac:      	st1.s	{ v30 }[2], [x15]
    14b0:      	tbz	w13, #0x7, 0x13cc <ltmp0+0x13cc>
    14b4:      	add	x12, x12, #0x1c
    14b8:      	st1.s	{ v30 }[3], [x12]
    14bc:      	b	0x13cc <ltmp0+0x13cc>
    14c0:      	fdiv.4s	v0, v16, v2
    14c4:      	fmul.4s	v1, v0, v27
    14c8:      	ldr	q3, [sp, #0x90]
    14cc:      	ldp	q4, q5, [sp, #0x60]
    14d0:      	stp	q3, q4, [sp, #0xd0]
    14d4:      	ldr	q0, [sp, #0x50]
    14d8:      	stp	q5, q0, [sp, #0xf0]
    14dc:      	and	x9, x30, #0x7
    14e0:      	add	x12, sp, #0xd0
    14e4:      	ldr	x9, [x12, x9, lsl #3]
    14e8:      	sub	x9, x9, x30
    14ec:      	add	x9, x16, x9, lsl #2
    14f0:      	fmov	w12, s22
    14f4:      	tbnz	w12, #0x0, 0x15e8 <ltmp0+0x15e8>
    14f8:      	ldr	w30, [sp, #0xc8]
    14fc:      	tbnz	w12, #0x1, 0x15f4 <ltmp0+0x15f4>
    1500:      	tbnz	w12, #0x2, 0x1600 <ltmp0+0x1600>
    1504:      	tbnz	w12, #0x3, 0x160c <ltmp0+0x160c>
    1508:      	fdiv.4s	v0, v6, v2
    150c:      	fmul.4s	v1, v0, v21
    1510:      	tbnz	w12, #0x4, 0x1620 <ltmp0+0x1620>
    1514:      	tbnz	w12, #0x5, 0x1628 <ltmp0+0x1628>
    1518:      	tbnz	w12, #0x6, 0x1634 <ltmp0+0x1634>
    151c:      	tbz	w12, #0x7, 0x800 <ltmp0+0x800>
    1520:      	b	0x1640 <ltmp0+0x1640>
    1524:      	ldr	s16, [x9]
    1528:      	tbz	w4, #0x1, 0xc8c <ltmp0+0xc8c>
    152c:      	add	x12, x9, #0x4
    1530:      	ld1.s	{ v16 }[1], [x12]
    1534:      	tbz	w4, #0x2, 0xc90 <ltmp0+0xc90>
    1538:      	add	x12, x9, #0x8
    153c:      	ld1.s	{ v16 }[2], [x12]
    1540:      	tbz	w4, #0x3, 0xc94 <ltmp0+0xc94>
    1544:      	add	x12, x9, #0xc
    1548:      	ld1.s	{ v16 }[3], [x12]
    154c:      	tbz	w4, #0x4, 0xc98 <ltmp0+0xc98>
    1550:      	add	x12, x9, #0x10
    1554:      	ld1.s	{ v6 }[0], [x12]
    1558:      	tbz	w4, #0x5, 0xc9c <ltmp0+0xc9c>
    155c:      	add	x12, x9, #0x14
    1560:      	ld1.s	{ v6 }[1], [x12]
    1564:      	tbz	w4, #0x6, 0xca0 <ltmp0+0xca0>
    1568:      	add	x12, x9, #0x18
    156c:      	ld1.s	{ v6 }[2], [x12]
    1570:      	tbnz	w4, #0x7, 0xca4 <ltmp0+0xca4>
    1574:      	b	0xcac <ltmp0+0xcac>
    1578:      	ldr	s27, [x9]
    157c:      	ldr	x16, [sp, #0xb0]
    1580:      	tbz	w15, #0x1, 0x1320 <ltmp0+0x1320>
    1584:      	add	x12, x9, #0x4
    1588:      	ld1.s	{ v27 }[1], [x12]
    158c:      	mov	x3, x23
    1590:      	mov	w19, #0x20              ; =32
    1594:      	ldp	w24, w23, [sp, #0x18]
    1598:      	mov	w28, #0x1               ; =1
    159c:      	ldr	w25, [sp, #0xcc]
    15a0:      	tbz	w15, #0x2, 0x1338 <ltmp0+0x1338>
    15a4:      	add	x12, x9, #0x8
    15a8:      	ld1.s	{ v27 }[2], [x12]
    15ac:      	ldr	x0, [sp, #0x20]
    15b0:      	tbz	w15, #0x3, 0x1340 <ltmp0+0x1340>
    15b4:      	add	x12, x9, #0xc
    15b8:      	ld1.s	{ v27 }[3], [x12]
    15bc:      	tbz	w15, #0x4, 0x1344 <ltmp0+0x1344>
    15c0:      	add	x12, x9, #0x10
    15c4:      	ld1.s	{ v21 }[0], [x12]
    15c8:      	tbz	w15, #0x5, 0x1348 <ltmp0+0x1348>
    15cc:      	add	x12, x9, #0x14
    15d0:      	ld1.s	{ v21 }[1], [x12]
    15d4:      	tbz	w15, #0x6, 0x134c <ltmp0+0x134c>
    15d8:      	add	x12, x9, #0x18
    15dc:      	ld1.s	{ v21 }[2], [x12]
    15e0:      	tbnz	w15, #0x7, 0x1350 <ltmp0+0x1350>
    15e4:      	b	0x1358 <ltmp0+0x1358>
    15e8:      	str	s1, [x9]
    15ec:      	ldr	w30, [sp, #0xc8]
    15f0:      	tbz	w12, #0x1, 0x1500 <ltmp0+0x1500>
    15f4:      	add	x13, x9, #0x4
    15f8:      	st1.s	{ v1 }[1], [x13]
    15fc:      	tbz	w12, #0x2, 0x1504 <ltmp0+0x1504>
    1600:      	add	x13, x9, #0x8
    1604:      	st1.s	{ v1 }[2], [x13]
    1608:      	tbz	w12, #0x3, 0x1508 <ltmp0+0x1508>
    160c:      	add	x13, x9, #0xc
    1610:      	st1.s	{ v1 }[3], [x13]
    1614:      	fdiv.4s	v0, v6, v2
    1618:      	fmul.4s	v1, v0, v21
    161c:      	tbz	w12, #0x4, 0x1514 <ltmp0+0x1514>
    1620:      	str	s1, [x9, #0x10]
    1624:      	tbz	w12, #0x5, 0x1518 <ltmp0+0x1518>
    1628:      	add	x13, x9, #0x14
    162c:      	st1.s	{ v1 }[1], [x13]
    1630:      	tbz	w12, #0x6, 0x151c <ltmp0+0x151c>
    1634:      	add	x13, x9, #0x18
    1638:      	st1.s	{ v1 }[2], [x13]
    163c:      	tbz	w12, #0x7, 0x800 <ltmp0+0x800>
    1640:      	add	x9, x9, #0x1c
    1644:      	st1.s	{ v1 }[3], [x9]
    1648:      	b	0x800 <ltmp0+0x800>
    164c:      	ldr	x9, [sp, #0x10]
    1650:      	stp	w26, w30, [x9]
    1654:      	str	w25, [x9, #0x8]
    1658:      	mov	w8, #0x18               ; =24
    165c:      	str	w8, [x9, #0x24]
    1660:      	add	sp, sp, #0x560
    1664:      	ldp	x29, x30, [sp, #0x90]
    1668:      	ldp	x20, x19, [sp, #0x80]
    166c:      	ldp	x22, x21, [sp, #0x70]
    1670:      	ldp	x24, x23, [sp, #0x60]
    1674:      	ldp	x26, x25, [sp, #0x50]
    1678:      	ldp	x28, x27, [sp, #0x40]
    167c:      	ldp	d9, d8, [sp, #0x30]
    1680:      	ldp	d11, d10, [sp, #0x20]
    1684:      	ldp	d13, d12, [sp, #0x10]
    1688:      	ldp	d15, d14, [sp], #0xa0
    168c:      	ret

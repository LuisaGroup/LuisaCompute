
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/rmsnorm-17x65/off/object/tile_xir_w8_37826_1788936532736827_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x174c <ltmp0+0x174c>
       4:      	stp	d15, d14, [sp, #-0xa0]!
       8:      	stp	d13, d12, [sp, #0x10]
       c:      	stp	d11, d10, [sp, #0x20]
      10:      	stp	d9, d8, [sp, #0x30]
      14:      	stp	x28, x27, [sp, #0x40]
      18:      	stp	x26, x25, [sp, #0x50]
      1c:      	stp	x24, x23, [sp, #0x60]
      20:      	stp	x22, x21, [sp, #0x70]
      24:      	stp	x20, x19, [sp, #0x80]
      28:      	stp	x29, x30, [sp, #0x90]
      2c:      	sub	sp, sp, #0x600
      30:      	mov	w8, #0x0                ; =0
      34:      	mov	w26, #0x20              ; =32
      38:      	mov	w10, #0x104             ; =260
      3c:      	mov	w11, #0x42820000        ; =1115815936
      40:      	ldp	w27, w28, [x2, #0x2c]
      44:      	mov	w14, #0xc5ac            ; =50604
      48:      	movk	w14, #0x3727, lsl #16
      4c:      	ldp	w9, w17, [x2]
      50:      	add	x4, sp, #0x4e0
      54:      	ldp	w1, w7, [x2, #0x8]
      58:      	str	x2, [sp, #0x10]
      5c:      	movi	d15, #0000000000000000
      60:      	mov	w30, #0x4               ; =4
      64:      	add	x15, sp, #0x3c0
      68:      	str	w3, [sp, #0x1c]
      6c:      	b	0x83c <ltmp0+0x83c>
      70:      	ldr	x21, [x0]
      74:      	ldr	x20, [x0, #0x10]
      78:      	ldr	x19, [x0, #0x30]
      7c:      	ubfiz	w23, w6, #2, #27
      80:      	umull	x9, w23, w10
      84:      	umaddl	x17, w23, w10, x21
      88:      	ldp	q28, q26, [x17]
      8c:      	ldp	q25, q24, [x17, #0x20]
      90:      	ldp	q23, q22, [x17, #0x40]
      94:      	ldp	q20, q21, [x17, #0x60]
      98:      	ldp	q19, q18, [x17, #0x80]
      9c:      	ldp	q16, q17, [x17, #0xa0]
      a0:      	ldp	q7, q27, [x17, #0xc0]
      a4:      	ldp	q30, q29, [x17, #0xe0]
      a8:      	add	x22, x9, #0x100
      ac:      	ldr	s31, [x21, x22]
      b0:      	ldp	q9, q8, [x20]
      b4:      	ldp	q0, q1, [x20, #0x20]
      b8:      	stp	q0, q1, [sp, #0xd0]
      bc:      	ldp	q0, q1, [x20, #0x40]
      c0:      	stp	q0, q1, [sp, #0xf0]
      c4:      	fmul.4s	v5, v28, v28
      c8:      	fmul.4s	v6, v26, v26
      cc:      	fmul.4s	v10, v24, v24
      d0:      	fmul.4s	v11, v25, v25
      d4:      	fmul.4s	v12, v23, v23
      d8:      	fmul.4s	v13, v22, v22
      dc:      	fmul.4s	v14, v21, v21
      e0:      	fmul.4s	v15, v20, v20
      e4:      	fmul.4s	v0, v30, v30
      e8:      	fadd.4s	v0, v15, v0
      ec:      	fmul.4s	v15, v29, v29
      f0:      	fadd.4s	v14, v14, v15
      f4:      	fmul.4s	v15, v27, v27
      f8:      	fadd.4s	v13, v13, v15
      fc:      	fmul.4s	v15, v7, v7
     100:      	fadd.4s	v12, v12, v15
     104:      	fmul.4s	v15, v16, v16
     108:      	fadd.4s	v11, v11, v15
     10c:      	fmul.4s	v15, v17, v17
     110:      	fadd.4s	v10, v10, v15
     114:      	fmul.4s	v15, v19, v19
     118:      	fadd.4s	v5, v5, v15
     11c:      	fmul.4s	v15, v31, v31
     120:      	fadd.4s	v15, v5, v15
     124:      	mov.s	v5[0], v15[0]
     128:      	fmul.4s	v15, v18, v18
     12c:      	fadd.4s	v6, v6, v15
     130:      	fadd.4s	v6, v10, v6
     134:      	ldp	q15, q10, [x20, #0x60]
     138:      	fadd.4s	v5, v11, v5
     13c:      	fadd.4s	v5, v12, v5
     140:      	fadd.4s	v6, v13, v6
     144:      	fadd.4s	v6, v14, v6
     148:      	fadd.4s	v0, v0, v5
     14c:      	rev64.4s	v5, v0
     150:      	rev64.4s	v11, v6
     154:      	fadd.4s	v6, v6, v11
     158:      	fadd.4s	v0, v0, v5
     15c:      	dup.4s	v5, v0[2]
     160:      	dup.4s	v11, v6[2]
     164:      	ldp	q13, q12, [x20, #0x80]
     168:      	fadd.4s	v6, v6, v11
     16c:      	fadd.4s	v0, v0, v5
     170:      	fadd.4s	v0, v0, v6
     174:      	movi	d1, #0000000000000000
     178:      	fadd	s0, s0, s1
     17c:      	fmov	s1, w11
     180:      	str	s1, [sp, #0x128]
     184:      	fdiv	s0, s0, s1
     188:      	fmov	s1, w14
     18c:      	str	s1, [sp, #0x110]
     190:      	fadd	s0, s0, s1
     194:      	fsqrt	s0, s0
     198:      	dup.4s	v11, v0[0]
     19c:      	fdiv.4s	v28, v28, v11
     1a0:      	fmul.4s	v28, v9, v28
     1a4:      	ldp	q14, q9, [x20, #0xa0]
     1a8:      	umaddl	x9, w23, w10, x19
     1ac:      	fdiv.4s	v26, v26, v11
     1b0:      	fmul.4s	v26, v8, v26
     1b4:      	ldp	q1, q8, [x20, #0xc0]
     1b8:      	ldp	q2, q3, [x20, #0xe0]
     1bc:      	ldr	s4, [x20, #0x100]
     1c0:      	stp	q28, q26, [x9]
     1c4:      	fdiv.4s	v25, v25, v11
     1c8:      	ldp	q6, q5, [sp, #0xd0]
     1cc:      	fmul.4s	v25, v6, v25
     1d0:      	fdiv.4s	v24, v24, v11
     1d4:      	fmul.4s	v24, v5, v24
     1d8:      	stp	q25, q24, [x9, #0x20]
     1dc:      	fdiv.4s	v22, v22, v11
     1e0:      	fdiv.4s	v23, v23, v11
     1e4:      	ldp	q6, q5, [sp, #0xf0]
     1e8:      	fmul.4s	v23, v6, v23
     1ec:      	fmul.4s	v22, v5, v22
     1f0:      	stp	q23, q22, [x9, #0x40]
     1f4:      	fdiv.4s	v21, v21, v11
     1f8:      	fdiv.4s	v20, v20, v11
     1fc:      	fmul.4s	v20, v15, v20
     200:      	fmul.4s	v21, v10, v21
     204:      	stp	q20, q21, [x9, #0x60]
     208:      	fdiv.4s	v18, v18, v11
     20c:      	fdiv.4s	v19, v19, v11
     210:      	fmul.4s	v19, v13, v19
     214:      	fmul.4s	v18, v12, v18
     218:      	stp	q19, q18, [x9, #0x80]
     21c:      	fdiv.4s	v17, v17, v11
     220:      	fdiv.4s	v16, v16, v11
     224:      	fmul.4s	v16, v14, v16
     228:      	fmul.4s	v17, v9, v17
     22c:      	stp	q16, q17, [x9, #0xa0]
     230:      	fdiv.4s	v16, v27, v11
     234:      	fdiv.4s	v7, v7, v11
     238:      	fmul.4s	v1, v1, v7
     23c:      	fmul.4s	v7, v8, v16
     240:      	stp	q1, q7, [x9, #0xc0]
     244:      	fdiv.4s	v1, v29, v11
     248:      	fdiv.4s	v7, v30, v11
     24c:      	fmul.4s	v2, v2, v7
     250:      	fmul.4s	v1, v3, v1
     254:      	stp	q2, q1, [x9, #0xe0]
     258:      	fdiv.4s	v0, v31, v0
     25c:      	fmul.4s	v0, v4, v0
     260:      	str	s0, [x19, x22]
     264:      	mov	w23, #0x1               ; =1
     268:      	bfi	w23, w6, #2, #27
     26c:      	umull	x9, w23, w10
     270:      	umaddl	x17, w23, w10, x21
     274:      	ldp	q27, q26, [x17]
     278:      	ldp	q25, q24, [x17, #0x20]
     27c:      	ldp	q23, q22, [x17, #0x40]
     280:      	ldp	q20, q21, [x17, #0x60]
     284:      	ldp	q19, q18, [x17, #0x80]
     288:      	ldp	q16, q17, [x17, #0xa0]
     28c:      	ldp	q7, q5, [x17, #0xc0]
     290:      	ldp	q2, q6, [x17, #0xe0]
     294:      	add	x22, x9, #0x100
     298:      	ldr	s1, [x21, x22]
     29c:      	ldp	q31, q30, [x20]
     2a0:      	ldp	q0, q3, [x20, #0x20]
     2a4:      	stp	q3, q2, [sp, #0xf0]
     2a8:      	stp	q0, q1, [sp, #0xd0]
     2ac:      	fmul.4s	v0, v27, v27
     2b0:      	fmul.4s	v8, v26, v26
     2b4:      	fmul.4s	v9, v24, v24
     2b8:      	fmul.4s	v10, v25, v25
     2bc:      	fmul.4s	v11, v23, v23
     2c0:      	fmul.4s	v12, v22, v22
     2c4:      	fmul.4s	v13, v21, v21
     2c8:      	fmul.4s	v14, v20, v20
     2cc:      	fmul.4s	v15, v2, v2
     2d0:      	fadd.4s	v14, v14, v15
     2d4:      	fmul.4s	v15, v6, v6
     2d8:      	fadd.4s	v13, v13, v15
     2dc:      	fmul.4s	v15, v5, v5
     2e0:      	fadd.4s	v12, v12, v15
     2e4:      	fmul.4s	v15, v7, v7
     2e8:      	fadd.4s	v11, v11, v15
     2ec:      	fmul.4s	v15, v16, v16
     2f0:      	fadd.4s	v10, v10, v15
     2f4:      	fmul.4s	v15, v17, v17
     2f8:      	fadd.4s	v9, v9, v15
     2fc:      	fmul.4s	v15, v19, v19
     300:      	fadd.4s	v0, v0, v15
     304:      	fmul.4s	v15, v1, v1
     308:      	fadd.4s	v15, v0, v15
     30c:      	mov.s	v0[0], v15[0]
     310:      	fmul.4s	v15, v18, v18
     314:      	fadd.4s	v8, v8, v15
     318:      	fadd.4s	v8, v9, v8
     31c:      	ldp	q15, q9, [x20, #0x40]
     320:      	fadd.4s	v0, v10, v0
     324:      	fadd.4s	v0, v11, v0
     328:      	ldp	q11, q10, [x20, #0x60]
     32c:      	fadd.4s	v8, v12, v8
     330:      	fadd.4s	v8, v13, v8
     334:      	fadd.4s	v0, v14, v0
     338:      	rev64.4s	v12, v0
     33c:      	rev64.4s	v13, v8
     340:      	fadd.4s	v8, v8, v13
     344:      	fadd.4s	v0, v0, v12
     348:      	dup.4s	v12, v8[2]
     34c:      	ldp	q14, q13, [x20, #0x80]
     350:      	fadd.4s	v8, v8, v12
     354:      	dup.4s	v12, v0[2]
     358:      	fadd.4s	v0, v0, v12
     35c:      	fadd.4s	v0, v0, v8
     360:      	movi	d1, #0000000000000000
     364:      	fadd	s0, s0, s1
     368:      	ldr	s28, [sp, #0x128]
     36c:      	fdiv	s0, s0, s28
     370:      	ldr	s29, [sp, #0x110]
     374:      	fadd	s0, s0, s29
     378:      	fsqrt	s0, s0
     37c:      	dup.4s	v8, v0[0]
     380:      	fdiv.4s	v27, v27, v8
     384:      	fmul.4s	v27, v31, v27
     388:      	ldp	q12, q31, [x20, #0xa0]
     38c:      	umaddl	x9, w23, w10, x19
     390:      	fdiv.4s	v26, v26, v8
     394:      	fmul.4s	v26, v30, v26
     398:      	ldp	q1, q30, [x20, #0xc0]
     39c:      	ldp	q2, q3, [x20, #0xe0]
     3a0:      	ldr	s4, [x20, #0x100]
     3a4:      	stp	q27, q26, [x9]
     3a8:      	fdiv.4s	v25, v25, v8
     3ac:      	ldr	q26, [sp, #0xd0]
     3b0:      	fmul.4s	v25, v26, v25
     3b4:      	fdiv.4s	v24, v24, v8
     3b8:      	ldr	q26, [sp, #0xf0]
     3bc:      	fmul.4s	v24, v26, v24
     3c0:      	stp	q25, q24, [x9, #0x20]
     3c4:      	fdiv.4s	v22, v22, v8
     3c8:      	fdiv.4s	v23, v23, v8
     3cc:      	fmul.4s	v23, v15, v23
     3d0:      	fmul.4s	v22, v9, v22
     3d4:      	stp	q23, q22, [x9, #0x40]
     3d8:      	fdiv.4s	v21, v21, v8
     3dc:      	fdiv.4s	v20, v20, v8
     3e0:      	fmul.4s	v20, v11, v20
     3e4:      	fmul.4s	v21, v10, v21
     3e8:      	stp	q20, q21, [x9, #0x60]
     3ec:      	fdiv.4s	v18, v18, v8
     3f0:      	fdiv.4s	v19, v19, v8
     3f4:      	fmul.4s	v19, v14, v19
     3f8:      	fmul.4s	v18, v13, v18
     3fc:      	stp	q19, q18, [x9, #0x80]
     400:      	fdiv.4s	v17, v17, v8
     404:      	fdiv.4s	v16, v16, v8
     408:      	fmul.4s	v16, v12, v16
     40c:      	fmul.4s	v17, v31, v17
     410:      	stp	q16, q17, [x9, #0xa0]
     414:      	fdiv.4s	v5, v5, v8
     418:      	fdiv.4s	v7, v7, v8
     41c:      	fmul.4s	v1, v1, v7
     420:      	fmul.4s	v5, v30, v5
     424:      	stp	q1, q5, [x9, #0xc0]
     428:      	fdiv.4s	v1, v6, v8
     42c:      	ldr	q5, [sp, #0x100]
     430:      	fdiv.4s	v5, v5, v8
     434:      	fmul.4s	v2, v2, v5
     438:      	fmul.4s	v1, v3, v1
     43c:      	stp	q2, q1, [x9, #0xe0]
     440:      	ldr	q1, [sp, #0xe0]
     444:      	fdiv.4s	v0, v1, v0
     448:      	fmul.4s	v0, v4, v0
     44c:      	str	s0, [x19, x22]
     450:      	mov	w23, #0x2               ; =2
     454:      	bfi	w23, w6, #2, #27
     458:      	umull	x9, w23, w10
     45c:      	umaddl	x17, w23, w10, x21
     460:      	ldp	q27, q26, [x17]
     464:      	ldp	q25, q24, [x17, #0x20]
     468:      	ldp	q23, q22, [x17, #0x40]
     46c:      	ldp	q20, q21, [x17, #0x60]
     470:      	ldp	q19, q18, [x17, #0x80]
     474:      	ldp	q16, q17, [x17, #0xa0]
     478:      	ldp	q7, q4, [x17, #0xc0]
     47c:      	ldp	q2, q3, [x17, #0xe0]
     480:      	add	x22, x9, #0x100
     484:      	ldr	s1, [x21, x22]
     488:      	ldp	q31, q30, [x20]
     48c:      	ldp	q0, q5, [x20, #0x20]
     490:      	stp	q5, q2, [sp, #0xf0]
     494:      	stp	q0, q1, [sp, #0xd0]
     498:      	fmul.4s	v0, v27, v27
     49c:      	fmul.4s	v5, v26, v26
     4a0:      	fmul.4s	v6, v24, v24
     4a4:      	fmul.4s	v8, v25, v25
     4a8:      	fmul.4s	v9, v23, v23
     4ac:      	fmul.4s	v10, v22, v22
     4b0:      	fmul.4s	v11, v21, v21
     4b4:      	fmul.4s	v12, v20, v20
     4b8:      	fmul.4s	v13, v2, v2
     4bc:      	fadd.4s	v12, v12, v13
     4c0:      	fmul.4s	v13, v3, v3
     4c4:      	fadd.4s	v11, v11, v13
     4c8:      	fmul.4s	v13, v4, v4
     4cc:      	fadd.4s	v10, v10, v13
     4d0:      	fmul.4s	v13, v7, v7
     4d4:      	fadd.4s	v9, v9, v13
     4d8:      	fmul.4s	v13, v16, v16
     4dc:      	fadd.4s	v8, v8, v13
     4e0:      	fmul.4s	v13, v17, v17
     4e4:      	fadd.4s	v6, v6, v13
     4e8:      	fmul.4s	v13, v19, v19
     4ec:      	fadd.4s	v0, v0, v13
     4f0:      	fmul.4s	v13, v1, v1
     4f4:      	fadd.4s	v13, v0, v13
     4f8:      	mov.s	v0[0], v13[0]
     4fc:      	fmul.4s	v13, v18, v18
     500:      	fadd.4s	v5, v5, v13
     504:      	fadd.4s	v5, v6, v5
     508:      	ldp	q13, q6, [x20, #0x40]
     50c:      	fadd.4s	v0, v8, v0
     510:      	fadd.4s	v0, v9, v0
     514:      	ldp	q9, q8, [x20, #0x60]
     518:      	fadd.4s	v5, v10, v5
     51c:      	fadd.4s	v5, v11, v5
     520:      	fadd.4s	v0, v12, v0
     524:      	rev64.4s	v10, v0
     528:      	rev64.4s	v11, v5
     52c:      	fadd.4s	v5, v5, v11
     530:      	fadd.4s	v0, v0, v10
     534:      	dup.4s	v10, v5[2]
     538:      	ldp	q12, q11, [x20, #0x80]
     53c:      	fadd.4s	v5, v5, v10
     540:      	dup.4s	v10, v0[2]
     544:      	fadd.4s	v0, v0, v10
     548:      	fadd.4s	v0, v0, v5
     54c:      	movi	d1, #0000000000000000
     550:      	fadd	s0, s0, s1
     554:      	fdiv	s0, s0, s28
     558:      	fadd	s0, s0, s29
     55c:      	fsqrt	s0, s0
     560:      	dup.4s	v5, v0[0]
     564:      	fdiv.4s	v27, v27, v5
     568:      	fmul.4s	v27, v31, v27
     56c:      	ldp	q10, q31, [x20, #0xa0]
     570:      	umaddl	x9, w23, w10, x19
     574:      	fdiv.4s	v26, v26, v5
     578:      	fmul.4s	v26, v30, v26
     57c:      	ldp	q14, q30, [x20, #0xc0]
     580:      	ldp	q1, q15, [x20, #0xe0]
     584:      	ldr	s2, [x20, #0x100]
     588:      	stp	q27, q26, [x9]
     58c:      	fdiv.4s	v25, v25, v5
     590:      	ldr	q26, [sp, #0xd0]
     594:      	fmul.4s	v25, v26, v25
     598:      	fdiv.4s	v24, v24, v5
     59c:      	ldr	q26, [sp, #0xf0]
     5a0:      	fmul.4s	v24, v26, v24
     5a4:      	stp	q25, q24, [x9, #0x20]
     5a8:      	fdiv.4s	v22, v22, v5
     5ac:      	fdiv.4s	v23, v23, v5
     5b0:      	fmul.4s	v23, v13, v23
     5b4:      	fmul.4s	v6, v6, v22
     5b8:      	stp	q23, q6, [x9, #0x40]
     5bc:      	fdiv.4s	v6, v21, v5
     5c0:      	fdiv.4s	v20, v20, v5
     5c4:      	fmul.4s	v20, v9, v20
     5c8:      	fmul.4s	v6, v8, v6
     5cc:      	stp	q20, q6, [x9, #0x60]
     5d0:      	fdiv.4s	v6, v18, v5
     5d4:      	fdiv.4s	v18, v19, v5
     5d8:      	fmul.4s	v18, v12, v18
     5dc:      	fmul.4s	v6, v11, v6
     5e0:      	stp	q18, q6, [x9, #0x80]
     5e4:      	fdiv.4s	v6, v17, v5
     5e8:      	fdiv.4s	v16, v16, v5
     5ec:      	fmul.4s	v16, v10, v16
     5f0:      	fmul.4s	v6, v31, v6
     5f4:      	stp	q16, q6, [x9, #0xa0]
     5f8:      	fdiv.4s	v4, v4, v5
     5fc:      	fdiv.4s	v6, v7, v5
     600:      	fmul.4s	v6, v14, v6
     604:      	fmul.4s	v4, v30, v4
     608:      	stp	q6, q4, [x9, #0xc0]
     60c:      	fdiv.4s	v3, v3, v5
     610:      	ldr	q4, [sp, #0x100]
     614:      	fdiv.4s	v4, v4, v5
     618:      	fmul.4s	v1, v1, v4
     61c:      	fmul.4s	v3, v15, v3
     620:      	movi	d15, #0000000000000000
     624:      	stp	q1, q3, [x9, #0xe0]
     628:      	ldr	q1, [sp, #0xe0]
     62c:      	fdiv.4s	v0, v1, v0
     630:      	fmul.4s	v0, v2, v0
     634:      	str	s0, [x19, x22]
     638:      	mov	w23, #0x3               ; =3
     63c:      	bfi	w23, w6, #2, #27
     640:      	umull	x9, w23, w10
     644:      	umaddl	x17, w23, w10, x21
     648:      	ldp	q27, q26, [x17]
     64c:      	ldp	q24, q25, [x17, #0x20]
     650:      	ldp	q23, q22, [x17, #0x40]
     654:      	ldp	q21, q20, [x17, #0x60]
     658:      	ldp	q19, q18, [x17, #0x80]
     65c:      	ldp	q17, q16, [x17, #0xa0]
     660:      	ldp	q7, q4, [x17, #0xc0]
     664:      	ldp	q2, q3, [x17, #0xe0]
     668:      	add	x22, x9, #0x100
     66c:      	ldr	s1, [x21, x22]
     670:      	ldp	q29, q28, [x20]
     674:      	fmul.4s	v0, v27, v27
     678:      	fmul.4s	v5, v26, v26
     67c:      	fmul.4s	v6, v25, v25
     680:      	fmul.4s	v30, v24, v24
     684:      	fmul.4s	v31, v23, v23
     688:      	fmul.4s	v8, v22, v22
     68c:      	fmul.4s	v9, v20, v20
     690:      	fmul.4s	v10, v21, v21
     694:      	fmul.4s	v11, v3, v3
     698:      	fmul.4s	v12, v2, v2
     69c:      	fadd.4s	v10, v10, v12
     6a0:      	fadd.4s	v9, v9, v11
     6a4:      	fmul.4s	v11, v7, v7
     6a8:      	fmul.4s	v12, v4, v4
     6ac:      	fadd.4s	v8, v8, v12
     6b0:      	fadd.4s	v31, v31, v11
     6b4:      	fmul.4s	v11, v16, v16
     6b8:      	fmul.4s	v12, v17, v17
     6bc:      	fadd.4s	v30, v30, v12
     6c0:      	fadd.4s	v6, v6, v11
     6c4:      	fmul.4s	v11, v19, v19
     6c8:      	fmul.4s	v12, v18, v18
     6cc:      	fadd.4s	v5, v5, v12
     6d0:      	fadd.4s	v0, v0, v11
     6d4:      	fmul.4s	v11, v1, v1
     6d8:      	fadd.4s	v11, v0, v11
     6dc:      	mov.s	v0[0], v11[0]
     6e0:      	ldp	q12, q11, [x20, #0x20]
     6e4:      	fadd.4s	v5, v6, v5
     6e8:      	fadd.4s	v0, v30, v0
     6ec:      	ldp	q13, q30, [x20, #0x40]
     6f0:      	fadd.4s	v0, v31, v0
     6f4:      	fadd.4s	v5, v8, v5
     6f8:      	fadd.4s	v5, v9, v5
     6fc:      	fadd.4s	v0, v10, v0
     700:      	rev64.4s	v6, v0
     704:      	rev64.4s	v31, v5
     708:      	fadd.4s	v5, v5, v31
     70c:      	fadd.4s	v0, v0, v6
     710:      	dup.4s	v6, v0[2]
     714:      	dup.4s	v31, v5[2]
     718:      	ldp	q9, q8, [x20, #0x60]
     71c:      	fadd.4s	v5, v5, v31
     720:      	fadd.4s	v0, v0, v6
     724:      	ldp	q10, q31, [x20, #0x80]
     728:      	fadd.4s	v0, v0, v5
     72c:      	fadd	s0, s0, s15
     730:      	ldr	s5, [sp, #0x128]
     734:      	fdiv	s0, s0, s5
     738:      	ldr	s5, [sp, #0x110]
     73c:      	fadd	s0, s0, s5
     740:      	fsqrt	s5, s0
     744:      	dup.4s	v6, v5[0]
     748:      	ldp	q14, q0, [x20, #0xa0]
     74c:      	fdiv.4s	v26, v26, v6
     750:      	fdiv.4s	v27, v27, v6
     754:      	fmul.4s	v27, v29, v27
     758:      	fmul.4s	v26, v28, v26
     75c:      	ldp	q29, q28, [x20, #0xc0]
     760:      	fdiv.4s	v25, v25, v6
     764:      	fdiv.4s	v24, v24, v6
     768:      	fmul.4s	v24, v12, v24
     76c:      	fmul.4s	v25, v11, v25
     770:      	ldp	q12, q11, [x20, #0xe0]
     774:      	fdiv.4s	v23, v23, v6
     778:      	fmul.4s	v23, v13, v23
     77c:      	ldr	s13, [x20, #0x100]
     780:      	umaddl	x9, w23, w10, x19
     784:      	stp	q27, q26, [x9]
     788:      	fdiv.4s	v22, v22, v6
     78c:      	fmul.4s	v22, v30, v22
     790:      	fdiv.4s	v21, v21, v6
     794:      	fmul.4s	v21, v9, v21
     798:      	stp	q24, q25, [x9, #0x20]
     79c:      	fdiv.4s	v20, v20, v6
     7a0:      	fmul.4s	v20, v8, v20
     7a4:      	stp	q23, q22, [x9, #0x40]
     7a8:      	fdiv.4s	v19, v19, v6
     7ac:      	fmul.4s	v19, v10, v19
     7b0:      	stp	q21, q20, [x9, #0x60]
     7b4:      	fdiv.4s	v18, v18, v6
     7b8:      	fmul.4s	v18, v31, v18
     7bc:      	stp	q19, q18, [x9, #0x80]
     7c0:      	fdiv.4s	v17, v17, v6
     7c4:      	fmul.4s	v17, v14, v17
     7c8:      	fdiv.4s	v16, v16, v6
     7cc:      	fmul.4s	v0, v0, v16
     7d0:      	stp	q17, q0, [x9, #0xa0]
     7d4:      	fdiv.4s	v0, v7, v6
     7d8:      	fmul.4s	v0, v29, v0
     7dc:      	fdiv.4s	v4, v4, v6
     7e0:      	fmul.4s	v4, v28, v4
     7e4:      	stp	q0, q4, [x9, #0xc0]
     7e8:      	fdiv.4s	v0, v3, v6
     7ec:      	fdiv.4s	v2, v2, v6
     7f0:      	fmul.4s	v2, v12, v2
     7f4:      	fmul.4s	v0, v11, v0
     7f8:      	stp	q2, q0, [x9, #0xe0]
     7fc:      	fdiv.4s	v0, v1, v5
     800:      	fmul.4s	v0, v13, v0
     804:      	str	s0, [x19, x22]
     808:      	add	w9, w6, #0x1
     80c:      	cmp	w9, w27
     810:      	cset	w12, eq
     814:      	csinc	w9, wzr, w6, eq
     818:      	cinc	w13, w5, eq
     81c:      	cmp	w13, w28
     820:      	cset	w17, eq
     824:      	ands	w12, w12, w17
     828:      	csel	w17, wzr, w13, ne
     82c:      	add	w1, w16, w12
     830:      	add	w8, w8, #0x1
     834:      	cmp	w8, w3
     838:      	b.eq	0x170c <ltmp0+0x170c>
     83c:      	mov	x16, x1
     840:      	mov	x5, x17
     844:      	mov	x6, x9
     848:      	ubfiz	x9, x9, #5, #32
     84c:      	cmp	x9, x7
     850:      	csel	x17, x9, xzr, ls
     854:      	subs	x1, x7, x17
     858:      	cmp	x1, #0x20
     85c:      	csel	x1, x1, x26, lo
     860:      	cmp	x7, x17
     864:      	ccmp	x9, x7, #0x2, hi
     868:      	csel	x19, x1, xzr, ls
     86c:      	cmp	x19, #0x20
     870:      	b.hs	0x70 <ltmp0+0x70>
     874:      	lsr	x25, x19, #3
     878:      	cmp	x19, #0x8
     87c:      	b.lo	0xa78 <ltmp0+0xa78>
     880:      	ldr	x9, [x0]
     884:      	ldr	x21, [x0, #0x10]
     888:      	ldr	x17, [x0, #0x30]
     88c:      	add	x22, x21, #0x100
     890:      	and	x1, x6, #0x7ffffff
     894:      	add	x1, x1, x1, lsl #6
     898:      	lsl	x1, x1, #4
     89c:      	add	x9, x9, x1
     8a0:      	add	x23, x9, #0x80
     8a4:      	add	x9, x17, x1
     8a8:      	add	x24, x9, #0x80
     8ac:      	mov	x20, x25
     8b0:      	ldp	q25, q24, [x23, #-0x80]
     8b4:      	ldp	q23, q22, [x23, #-0x60]
     8b8:      	ldp	q21, q20, [x23, #-0x40]
     8bc:      	ldp	q19, q18, [x23, #-0x20]
     8c0:      	ldp	q17, q16, [x23]
     8c4:      	ldp	q7, q6, [x23, #0x20]
     8c8:      	ldp	q5, q4, [x23, #0x40]
     8cc:      	ldp	q2, q3, [x23, #0x60]
     8d0:      	ldr	s1, [x23, #0x80]
     8d4:      	ldp	q29, q28, [x21]
     8d8:      	ldp	q27, q26, [x21, #0x20]
     8dc:      	fmul.4s	v0, v25, v25
     8e0:      	fmul.4s	v30, v24, v24
     8e4:      	fmul.4s	v31, v22, v22
     8e8:      	fmul.4s	v8, v23, v23
     8ec:      	fmul.4s	v9, v21, v21
     8f0:      	fmul.4s	v10, v20, v20
     8f4:      	fmul.4s	v11, v18, v18
     8f8:      	fmul.4s	v12, v19, v19
     8fc:      	fmul.4s	v13, v2, v2
     900:      	fadd.4s	v12, v12, v13
     904:      	fmul.4s	v13, v5, v5
     908:      	fmul.4s	v14, v4, v4
     90c:      	fadd.4s	v10, v10, v14
     910:      	fadd.4s	v9, v9, v13
     914:      	fmul.4s	v13, v6, v6
     918:      	fmul.4s	v14, v7, v7
     91c:      	fadd.4s	v8, v8, v14
     920:      	fadd.4s	v31, v31, v13
     924:      	fmul.4s	v13, v17, v17
     928:      	fmul.4s	v14, v16, v16
     92c:      	fadd.4s	v30, v30, v14
     930:      	fadd.4s	v0, v0, v13
     934:      	fmul.4s	v13, v1, v1
     938:      	fmul.4s	v14, v3, v3
     93c:      	fadd.4s	v13, v0, v13
     940:      	mov.s	v0[0], v13[0]
     944:      	fadd.4s	v30, v31, v30
     948:      	fadd.4s	v0, v8, v0
     94c:      	fadd.4s	v31, v11, v14
     950:      	fadd.4s	v0, v9, v0
     954:      	fadd.4s	v30, v10, v30
     958:      	fadd.4s	v30, v31, v30
     95c:      	fadd.4s	v0, v12, v0
     960:      	ldp	q9, q8, [x21, #0x40]
     964:      	rev64.4s	v31, v0
     968:      	rev64.4s	v10, v30
     96c:      	fadd.4s	v30, v30, v10
     970:      	fadd.4s	v0, v0, v31
     974:      	dup.4s	v31, v0[2]
     978:      	dup.4s	v10, v30[2]
     97c:      	fadd.4s	v30, v30, v10
     980:      	fadd.4s	v0, v0, v31
     984:      	ldp	q11, q10, [x21, #0x60]
     988:      	fadd.4s	v0, v0, v30
     98c:      	fadd	s0, s0, s15
     990:      	fmov	s30, w11
     994:      	fdiv	s0, s0, s30
     998:      	ldp	q13, q12, [x21, #0x80]
     99c:      	fmov	s30, w14
     9a0:      	fadd	s0, s0, s30
     9a4:      	fsqrt	s30, s0
     9a8:      	dup.4s	v31, v30[0]
     9ac:      	ldp	q14, q0, [x21, #0xa0]
     9b0:      	fdiv.4s	v25, v25, v31
     9b4:      	fmul.4s	v25, v29, v25
     9b8:      	fdiv.4s	v24, v24, v31
     9bc:      	fmul.4s	v24, v28, v24
     9c0:      	ldp	q28, q29, [x21, #0xc0]
     9c4:      	fdiv.4s	v23, v23, v31
     9c8:      	fmul.4s	v23, v27, v23
     9cc:      	fdiv.4s	v22, v22, v31
     9d0:      	fmul.4s	v22, v26, v22
     9d4:      	ldp	q26, q27, [x21, #0xe0]
     9d8:      	fdiv.4s	v21, v21, v31
     9dc:      	fmul.4s	v21, v9, v21
     9e0:      	ldr	s9, [x22]
     9e4:      	stp	q25, q24, [x24, #-0x80]
     9e8:      	fdiv.4s	v20, v20, v31
     9ec:      	fmul.4s	v20, v8, v20
     9f0:      	fdiv.4s	v19, v19, v31
     9f4:      	fmul.4s	v19, v11, v19
     9f8:      	stp	q23, q22, [x24, #-0x60]
     9fc:      	fdiv.4s	v18, v18, v31
     a00:      	fmul.4s	v18, v10, v18
     a04:      	fdiv.4s	v17, v17, v31
     a08:      	fmul.4s	v17, v13, v17
     a0c:      	stp	q21, q20, [x24, #-0x40]
     a10:      	stp	q19, q18, [x24, #-0x20]
     a14:      	fdiv.4s	v16, v16, v31
     a18:      	fmul.4s	v16, v12, v16
     a1c:      	stp	q17, q16, [x24]
     a20:      	fdiv.4s	v7, v7, v31
     a24:      	fmul.4s	v7, v14, v7
     a28:      	fdiv.4s	v6, v6, v31
     a2c:      	fmul.4s	v0, v0, v6
     a30:      	stp	q7, q0, [x24, #0x20]
     a34:      	fdiv.4s	v0, v5, v31
     a38:      	fmul.4s	v0, v28, v0
     a3c:      	fdiv.4s	v4, v4, v31
     a40:      	fmul.4s	v4, v29, v4
     a44:      	stp	q0, q4, [x24, #0x40]
     a48:      	fdiv.4s	v0, v3, v31
     a4c:      	fdiv.4s	v2, v2, v31
     a50:      	fmul.4s	v2, v26, v2
     a54:      	fmul.4s	v0, v27, v0
     a58:      	stp	q2, q0, [x24, #0x60]
     a5c:      	fdiv.4s	v0, v1, v30
     a60:      	fmul.4s	v0, v9, v0
     a64:      	str	s0, [x24, #0x80]
     a68:      	add	x23, x23, #0x104
     a6c:      	add	x24, x24, #0x104
     a70:      	subs	x20, x20, #0x1
     a74:      	b.ne	0x8b0 <ltmp0+0x8b0>
     a78:      	and	w9, w19, #0x7
     a7c:      	cbz	w9, 0x808 <ltmp0+0x808>
     a80:      	dup.4s	v0, w9
     a84:      	adrp	x9, 0x0 <ltmp0>
     a88:      	ldr	q1, [x9]
     a8c:      	adrp	x9, 0x0 <ltmp0>
     a90:      	ldr	q2, [x9]
     a94:      	cmhi.4s	v5, v0, v2
     a98:      	cmhi.4s	v6, v0, v1
     a9c:      	uzp1.8h	v31, v6, v5
     aa0:      	umaxv.8h	h0, v31
     aa4:      	fmov	w9, s0
     aa8:      	tbz	w9, #0x0, 0x808 <ltmp0+0x808>
     aac:      	mov	x20, #0x0               ; =0
     ab0:      	ldr	x23, [x0]
     ab4:      	ldr	x21, [x0, #0x10]
     ab8:      	ldr	x13, [x0, #0x30]
     abc:      	adrp	x9, 0x0 <ltmp0>
     ac0:      	ldr	q0, [x9]
     ac4:      	and.16b	v0, v31, v0
     ac8:      	addv.8h	h7, v0
     acc:      	ubfiz	w9, w6, #2, #27
     ad0:      	orr	w9, w9, w25
     ad4:      	fmov	w17, s7
     ad8:      	and	w12, w17, #0xff
     adc:      	str	w12, [sp, #0xf0]
     ae0:      	dup.4s	v0, w9
     ae4:      	and.16b	v1, v6, v0
     ae8:      	and.16b	v0, v5, v0
     aec:      	ushll2.2d	v20, v0, #0x0
     af0:      	ushll2.2d	v21, v1, #0x0
     af4:      	ushll.2d	v22, v0, #0x0
     af8:      	ushll.2d	v2, v1, #0x0
     afc:      	fmov	x9, d2
     b00:      	umaddl	x24, w9, w10, x23
     b04:      	b	0xb28 <ltmp0+0xb28>
     b08:      	add	x9, x4, x20
     b0c:      	ldp	q0, q4, [x9]
     b10:      	bif.16b	v3, v4, v5
     b14:      	bit.16b	v0, v1, v6
     b18:      	stp	q0, q3, [x9]
     b1c:      	add	x20, x20, #0x20
     b20:      	cmp	x20, #0x100
     b24:      	b.eq	0xbc0 <ltmp0+0xbc0>
     b28:      	fmov	w9, s7
     b2c:      	add	x25, x24, x20
     b30:      	movi.2d	v1, #0000000000000000
     b34:      	movi.2d	v3, #0000000000000000
     b38:      	tbnz	w9, #0x0, 0xb60 <ltmp0+0xb60>
     b3c:      	and	w17, w9, #0xff
     b40:      	tbnz	w17, #0x1, 0xb6c <ltmp0+0xb6c>
     b44:      	tbnz	w17, #0x2, 0xb78 <ltmp0+0xb78>
     b48:      	tbnz	w17, #0x3, 0xb84 <ltmp0+0xb84>
     b4c:      	tbnz	w17, #0x4, 0xb90 <ltmp0+0xb90>
     b50:      	tbnz	w17, #0x5, 0xb9c <ltmp0+0xb9c>
     b54:      	tbnz	w17, #0x6, 0xba8 <ltmp0+0xba8>
     b58:      	tbz	w17, #0x7, 0xb08 <ltmp0+0xb08>
     b5c:      	b	0xbb4 <ltmp0+0xbb4>
     b60:      	ldr	s1, [x25]
     b64:      	and	w17, w9, #0xff
     b68:      	tbz	w17, #0x1, 0xb44 <ltmp0+0xb44>
     b6c:      	add	x9, x25, #0x4
     b70:      	ld1.s	{ v1 }[1], [x9]
     b74:      	tbz	w17, #0x2, 0xb48 <ltmp0+0xb48>
     b78:      	add	x9, x25, #0x8
     b7c:      	ld1.s	{ v1 }[2], [x9]
     b80:      	tbz	w17, #0x3, 0xb4c <ltmp0+0xb4c>
     b84:      	add	x9, x25, #0xc
     b88:      	ld1.s	{ v1 }[3], [x9]
     b8c:      	tbz	w17, #0x4, 0xb50 <ltmp0+0xb50>
     b90:      	add	x9, x25, #0x10
     b94:      	ld1.s	{ v3 }[0], [x9]
     b98:      	tbz	w17, #0x5, 0xb54 <ltmp0+0xb54>
     b9c:      	add	x9, x25, #0x14
     ba0:      	ld1.s	{ v3 }[1], [x9]
     ba4:      	tbz	w17, #0x6, 0xb58 <ltmp0+0xb58>
     ba8:      	add	x9, x25, #0x18
     bac:      	ld1.s	{ v3 }[2], [x9]
     bb0:      	tbz	w17, #0x7, 0xb08 <ltmp0+0xb08>
     bb4:      	add	x9, x25, #0x1c
     bb8:      	ld1.s	{ v3 }[3], [x9]
     bbc:      	b	0xb08 <ltmp0+0xb08>
     bc0:      	xtn.4h	v0, v6
     bc4:      	uzp1.8b	v0, v0, v0
     bc8:      	sshll.2d	v1, v6, #0x0
     bcc:      	adrp	x9, 0x0 <ltmp0>
     bd0:      	ldr	q3, [x9]
     bd4:      	and.16b	v4, v1, v3
     bd8:      	movi.2d	v19, #0000000000000000
     bdc:      	mov.b	v19[0], v0[0]
     be0:      	adrp	x9, 0x0 <ltmp0>
     be4:      	ldr	d3, [x9]
     be8:      	str	d3, [sp, #0x98]
     bec:      	and.8b	v3, v19, v3
     bf0:      	addv.8b	b3, v3
     bf4:      	fmov	w24, s3
     bf8:      	umaxv.8b	b3, v19
     bfc:      	fmov	w9, s3
     c00:      	rbit	w17, w24
     c04:      	clz	w17, w17
     c08:      	tst	w9, #0x1
     c0c:      	csel	w20, w17, wzr, ne
     c10:      	mov	w12, #0x40              ; =64
     c14:      	dup.2d	v3, x12
     c18:      	str	q4, [sp, #0x50]
     c1c:      	orr.16b	v16, v4, v3
     c20:      	xtn.2s	v2, v2
     c24:      	str	q16, [sp, #0xa0]
     c28:      	movi.2s	v4, #0x41
     c2c:      	umlal.2d	v16, v2, v4
     c30:      	movi.2d	v4, #0000000000000000
     c34:      	mov.b	v4[0], v0[0]
     c38:      	ushll.2d	v0, v4, #0x0
     c3c:      	shl.2d	v0, v0, #0x3f
     c40:      	cmlt.2d	v0, v0, #0
     c44:      	str	q16, [sp, #0x110]
     c48:      	and.16b	v0, v0, v16
     c4c:      	movi.2d	v4, #0000000000000000
     c50:      	stp	q4, q4, [sp, #0x390]
     c54:      	stp	q0, q4, [sp, #0x370]
     c58:      	and	x17, x20, #0x7
     c5c:      	add	x12, sp, #0x370
     c60:      	ldr	x17, [x12, x17, lsl #3]
     c64:      	sub	x17, x17, x20
     c68:      	add	x23, x23, x17, lsl #2
     c6c:      	movi.2d	v24, #0000000000000000
     c70:      	movi.2d	v16, #0000000000000000
     c74:      	tbnz	w9, #0x0, 0x15f4 <ltmp0+0x15f4>
     c78:      	tbnz	w24, #0x1, 0x15fc <ltmp0+0x15fc>
     c7c:      	tbnz	w24, #0x2, 0x1608 <ltmp0+0x1608>
     c80:      	tbnz	w24, #0x3, 0x1614 <ltmp0+0x1614>
     c84:      	tbnz	w24, #0x4, 0x1620 <ltmp0+0x1620>
     c88:      	tbnz	w24, #0x5, 0x162c <ltmp0+0x162c>
     c8c:      	tbnz	w24, #0x6, 0x1638 <ltmp0+0x1638>
     c90:      	tbz	w24, #0x7, 0xc9c <ltmp0+0xc9c>
     c94:      	add	x9, x23, #0x1c
     c98:      	ld1.s	{ v16 }[3], [x9]
     c9c:      	sshll.2d	v0, v5, #0x0
     ca0:      	sshll2.2d	v26, v6, #0x0
     ca4:      	sshll2.2d	v27, v5, #0x0
     ca8:      	adrp	x9, 0x0 <ltmp0>
     cac:      	ldr	q4, [x9]
     cb0:      	and.16b	v18, v27, v4
     cb4:      	adrp	x9, 0x0 <ltmp0>
     cb8:      	ldr	q4, [x9]
     cbc:      	and.16b	v25, v26, v4
     cc0:      	adrp	x9, 0x0 <ltmp0>
     cc4:      	ldr	q4, [x9]
     cc8:      	and.16b	v28, v0, v4
     ccc:      	adrp	x9, 0x0 <ltmp0>
     cd0:      	ldr	q4, [x9]
     cd4:      	and.16b	v4, v27, v4
     cd8:      	adrp	x9, 0x0 <ltmp0>
     cdc:      	ldr	q17, [x9]
     ce0:      	and.16b	v23, v26, v17
     ce4:      	adrp	x9, 0x0 <ltmp0>
     ce8:      	ldr	q17, [x9]
     cec:      	and.16b	v0, v0, v17
     cf0:      	adrp	x9, 0x0 <ltmp0>
     cf4:      	ldr	q17, [x9]
     cf8:      	and.16b	v17, v1, v17
     cfc:      	stp	q28, q25, [sp, #0x20]
     d00:      	orr.16b	v28, v28, v3
     d04:      	orr.16b	v29, v25, v3
     d08:      	str	q18, [sp, #0x40]
     d0c:      	orr.16b	v25, v18, v3
     d10:      	movi.2s	v18, #0x41
     d14:      	umull.2d	v1, v2, v18
     d18:      	str	q1, [sp, #0xb0]
     d1c:      	xtn.2s	v1, v21
     d20:      	xtn.2s	v2, v22
     d24:      	xtn.2s	v3, v20
     d28:      	stp	q28, q25, [sp, #0x70]
     d2c:      	mov.16b	v20, v25
     d30:      	umlal.2d	v20, v3, v18
     d34:      	str	q29, [sp, #0x60]
     d38:      	mov.16b	v3, v29
     d3c:      	umlal.2d	v3, v1, v18
     d40:      	stp	q3, q20, [sp, #0xd0]
     d44:      	mov.16b	v1, v28
     d48:      	umlal.2d	v1, v2, v18
     d4c:      	str	q1, [sp, #0xc0]
     d50:      	sshll.2d	v1, v6, #0x0
     d54:      	sshll.2d	v2, v5, #0x0
     d58:      	stp	q17, q23, [sp, #0x330]
     d5c:      	stp	q0, q4, [sp, #0x350]
     d60:      	and	x9, x20, #0x7
     d64:      	add	x12, sp, #0x330
     d68:      	ldr	x9, [x12, x9, lsl #3]
     d6c:      	orr	x9, x9, #0x100
     d70:      	sub	x9, x9, x20, lsl #2
     d74:      	tst	w24, #0xff
     d78:      	csel	x3, xzr, x9, eq
     d7c:      	add	x9, x4, x3
     d80:      	ldp	q0, q3, [x9]
     d84:      	zip2.8b	v4, v19, v0
     d88:      	ushll.4s	v4, v4, #0x0
     d8c:      	shl.4s	v4, v4, #0x1f
     d90:      	cmlt.4s	v4, v4, #0
     d94:      	bit.16b	v3, v16, v4
     d98:      	zip1.8b	v4, v19, v0
     d9c:      	ushll.4s	v4, v4, #0x0
     da0:      	shl.4s	v4, v4, #0x1f
     da4:      	cmlt.4s	v4, v4, #0
     da8:      	str	q24, [sp, #0x100]
     dac:      	bit.16b	v0, v24, v4
     db0:      	stp	q0, q3, [x9]
     db4:      	dup.2d	v0, x30
     db8:      	and.16b	v21, v27, v0
     dbc:      	and.16b	v22, v26, v0
     dc0:      	and.16b	v28, v2, v0
     dc4:      	and.16b	v29, v1, v0
     dc8:      	fmov	x9, d29
     dcc:      	ldr	q0, [sp, #0x550]
     dd0:      	ldr	q1, [sp, #0x540]
     dd4:      	fmul.4s	v1, v1, v1
     dd8:      	fmul.4s	v0, v0, v0
     ddc:      	and.16b	v14, v5, v0
     de0:      	and.16b	v15, v6, v1
     de4:      	ldr	q0, [sp, #0x530]
     de8:      	ldr	q1, [sp, #0x520]
     dec:      	fmul.4s	v1, v1, v1
     df0:      	fmul.4s	v0, v0, v0
     df4:      	and.16b	v4, v5, v0
     df8:      	and.16b	v3, v6, v1
     dfc:      	ldr	q0, [sp, #0x510]
     e00:      	ldr	q1, [sp, #0x500]
     e04:      	fmul.4s	v2, v1, v1
     e08:      	fmul.4s	v0, v0, v0
     e0c:      	and.16b	v1, v5, v0
     e10:      	and.16b	v2, v6, v2
     e14:      	fmov	x17, d17
     e18:      	add	x17, x4, x17
     e1c:      	ldp	q17, q0, [x17]
     e20:      	fmul.4s	v17, v17, v17
     e24:      	fmul.4s	v0, v0, v0
     e28:      	and.16b	v24, v5, v0
     e2c:      	and.16b	v23, v6, v17
     e30:      	sshll.2d	v0, v6, #0x0
     e34:      	sshll.2d	v17, v5, #0x0
     e38:      	add	x9, x4, x9, lsl #5
     e3c:      	ldp	q25, q20, [x9]
     e40:      	and.16b	v25, v6, v25
     e44:      	and.16b	v20, v5, v20
     e48:      	fmul.4s	v20, v20, v20
     e4c:      	fmul.4s	v25, v25, v25
     e50:      	fadd.4s	v25, v23, v25
     e54:      	fadd.4s	v20, v24, v20
     e58:      	ldp	q8, q30, [x9, #0x20]
     e5c:      	and.16b	v8, v6, v8
     e60:      	and.16b	v30, v5, v30
     e64:      	fmul.4s	v30, v30, v30
     e68:      	fmul.4s	v8, v8, v8
     e6c:      	fadd.4s	v8, v2, v8
     e70:      	fadd.4s	v30, v1, v30
     e74:      	ldp	q10, q9, [x9, #0x40]
     e78:      	and.16b	v10, v6, v10
     e7c:      	and.16b	v9, v5, v9
     e80:      	fmul.4s	v9, v9, v9
     e84:      	fmul.4s	v10, v10, v10
     e88:      	fadd.4s	v10, v3, v10
     e8c:      	fadd.4s	v9, v4, v9
     e90:      	ldp	q11, q18, [x9, #0x60]
     e94:      	and.16b	v11, v6, v11
     e98:      	and.16b	v18, v5, v18
     e9c:      	fmul.4s	v18, v18, v18
     ea0:      	fmul.4s	v11, v11, v11
     ea4:      	fadd.4s	v11, v15, v11
     ea8:      	fadd.4s	v18, v14, v18
     eac:      	dup.2d	v12, x30
     eb0:      	and.16b	v13, v27, v12
     eb4:      	add.2d	v21, v21, v13
     eb8:      	and.16b	v13, v26, v12
     ebc:      	add.2d	v22, v22, v13
     ec0:      	and.16b	v17, v17, v12
     ec4:      	add.2d	v28, v28, v17
     ec8:      	and.16b	v0, v0, v12
     ecc:      	add.2d	v29, v29, v0
     ed0:      	bit.16b	v24, v20, v5
     ed4:      	bit.16b	v23, v25, v6
     ed8:      	bit.16b	v1, v30, v5
     edc:      	bit.16b	v2, v8, v6
     ee0:      	bit.16b	v4, v9, v5
     ee4:      	bit.16b	v3, v10, v6
     ee8:      	bit.16b	v14, v18, v5
     eec:      	bit.16b	v15, v11, v6
     ef0:      	fmov	x9, d29
     ef4:      	cmp	x9, #0x8
     ef8:      	b.lt	0xe30 <ltmp0+0xe30>
     efc:      	str	x13, [sp, #0x128]
     f00:      	mov	x9, #0x0                ; =0
     f04:      	mov	w12, #0x1               ; =1
     f08:      	dup.2d	v0, x12
     f0c:      	ushll2.2d	v17, v5, #0x0
     f10:      	and.16b	v26, v17, v0
     f14:      	ushll2.2d	v17, v6, #0x0
     f18:      	and.16b	v27, v17, v0
     f1c:      	ushll.2d	v17, v5, #0x0
     f20:      	and.16b	v28, v17, v0
     f24:      	ushll.2d	v17, v6, #0x0
     f28:      	and.16b	v29, v17, v0
     f2c:      	movi.2d	v21, #0000000000000000
     f30:      	movi.2d	v22, #0000000000000000
     f34:      	movi.2d	v30, #0000000000000000
     f38:      	movi.2d	v8, #0000000000000000
     f3c:      	b	0xf70 <ltmp0+0xf70>
     f40:      	add	x9, x15, x24
     f44:      	ldp	q0, q18, [x9]
     f48:      	bif.16b	v17, v18, v5
     f4c:      	bit.16b	v0, v9, v6
     f50:      	stp	q0, q17, [x9]
     f54:      	add.2d	v22, v22, v27
     f58:      	add.2d	v30, v30, v28
     f5c:      	add.2d	v8, v8, v26
     f60:      	add.2d	v21, v21, v29
     f64:      	fmov	x9, d21
     f68:      	cmp	x9, #0x8
     f6c:      	b.ge	0x100c <ltmp0+0x100c>
     f70:      	fmov	w17, s7
     f74:      	lsl	x24, x9, #5
     f78:      	add	x25, x21, x24
     f7c:      	movi.2d	v9, #0000000000000000
     f80:      	movi.2d	v17, #0000000000000000
     f84:      	tbnz	w17, #0x0, 0xfac <ltmp0+0xfac>
     f88:      	and	w17, w17, #0xff
     f8c:      	tbnz	w17, #0x1, 0xfb8 <ltmp0+0xfb8>
     f90:      	tbnz	w17, #0x2, 0xfc4 <ltmp0+0xfc4>
     f94:      	tbnz	w17, #0x3, 0xfd0 <ltmp0+0xfd0>
     f98:      	tbnz	w17, #0x4, 0xfdc <ltmp0+0xfdc>
     f9c:      	tbnz	w17, #0x5, 0xfe8 <ltmp0+0xfe8>
     fa0:      	tbnz	w17, #0x6, 0xff4 <ltmp0+0xff4>
     fa4:      	tbz	w17, #0x7, 0xf40 <ltmp0+0xf40>
     fa8:      	b	0x1000 <ltmp0+0x1000>
     fac:      	ldr	s9, [x25]
     fb0:      	and	w17, w17, #0xff
     fb4:      	tbz	w17, #0x1, 0xf90 <ltmp0+0xf90>
     fb8:      	add	x9, x25, #0x4
     fbc:      	ld1.s	{ v9 }[1], [x9]
     fc0:      	tbz	w17, #0x2, 0xf94 <ltmp0+0xf94>
     fc4:      	add	x9, x25, #0x8
     fc8:      	ld1.s	{ v9 }[2], [x9]
     fcc:      	tbz	w17, #0x3, 0xf98 <ltmp0+0xf98>
     fd0:      	add	x9, x25, #0xc
     fd4:      	ld1.s	{ v9 }[3], [x9]
     fd8:      	tbz	w17, #0x4, 0xf9c <ltmp0+0xf9c>
     fdc:      	add	x9, x25, #0x10
     fe0:      	ld1.s	{ v17 }[0], [x9]
     fe4:      	tbz	w17, #0x5, 0xfa0 <ltmp0+0xfa0>
     fe8:      	add	x9, x25, #0x14
     fec:      	ld1.s	{ v17 }[1], [x9]
     ff0:      	tbz	w17, #0x6, 0xfa4 <ltmp0+0xfa4>
     ff4:      	add	x9, x25, #0x18
     ff8:      	ld1.s	{ v17 }[2], [x9]
     ffc:      	tbz	w17, #0x7, 0xf40 <ltmp0+0xf40>
    1000:      	add	x9, x25, #0x1c
    1004:      	ld1.s	{ v17 }[3], [x9]
    1008:      	b	0xf40 <ltmp0+0xf40>
    100c:      	mov	x23, x28
    1010:      	mov	x19, x27
    1014:      	xtn.8b	v31, v31
    1018:      	ldr	q30, [sp, #0x100]
    101c:      	fmul.4s	v0, v30, v30
    1020:      	fmul.4s	v17, v16, v16
    1024:      	fadd.4s	v17, v17, v24
    1028:      	fadd.4s	v0, v0, v23
    102c:      	zip1.8b	v18, v19, v0
    1030:      	ushll.4s	v18, v18, #0x0
    1034:      	shl.4s	v18, v18, #0x1f
    1038:      	cmlt.4s	v18, v18, #0
    103c:      	and.16b	v0, v18, v0
    1040:      	zip2.8b	v18, v19, v0
    1044:      	ushll.4s	v18, v18, #0x0
    1048:      	shl.4s	v18, v18, #0x1f
    104c:      	cmlt.4s	v18, v18, #0
    1050:      	and.16b	v17, v18, v17
    1054:      	zip2.8b	v18, v31, v0
    1058:      	ushll.4s	v18, v18, #0x0
    105c:      	shl.4s	v18, v18, #0x1f
    1060:      	cmlt.4s	v18, v18, #0
    1064:      	movi.2d	v21, #0000000000000000
    1068:      	mov.b	v21[2], v31[1]
    106c:      	mov.b	v21[4], v31[2]
    1070:      	mov.b	v21[6], v31[3]
    1074:      	bit.16b	v17, v20, v18
    1078:      	ushll.4s	v18, v21, #0x0
    107c:      	shl.4s	v18, v18, #0x1f
    1080:      	cmlt.4s	v18, v18, #0
    1084:      	bit.16b	v0, v25, v18
    1088:      	fadd.4s	v0, v2, v0
    108c:      	fadd.4s	v1, v1, v17
    1090:      	fadd.4s	v1, v4, v1
    1094:      	fadd.4s	v0, v3, v0
    1098:      	fadd.4s	v2, v15, v0
    109c:      	fadd.4s	v3, v14, v1
    10a0:      	ldp	q0, q4, [sp, #0x40]
    10a4:      	ldr	q1, [sp, #0x30]
    10a8:      	uzp1.4s	v1, v4, v1
    10ac:      	ldr	q4, [sp, #0x20]
    10b0:      	uzp1.4s	v4, v4, v0
    10b4:      	movi.4s	v17, #0x1
    10b8:      	eor.16b	v0, v1, v17
    10bc:      	mov.s	w9, v0[1]
    10c0:      	mov.s	w17, v0[2]
    10c4:      	eor.16b	v22, v4, v17
    10c8:      	mov.s	w1, v0[3]
    10cc:      	fmov	w2, s0
    10d0:      	add	x24, sp, #0x178
    10d4:      	bfxil	x24, x2, #0, #3
    10d8:      	str	d31, [sp, #0x178]
    10dc:      	ldrb	w25, [x24]
    10e0:      	and	x2, x2, #0x7
    10e4:      	umov.b	w24, v31[0]
    10e8:      	stp	q2, q3, [sp, #0x280]
    10ec:      	add	x12, sp, #0x280
    10f0:      	ldr	s0, [x12, x2, lsl #2]
    10f4:      	ands	w26, w24, #0x1
    10f8:      	tst	w26, w25
    10fc:      	movi	d15, #0000000000000000
    1100:      	fcsel	s20, s0, s15, ne
    1104:      	add	x2, sp, #0x178
    1108:      	bfxil	x2, x9, #0, #3
    110c:      	ldrb	w2, [x2]
    1110:      	and	x9, x9, #0x7
    1114:      	umov.b	w25, v31[1]
    1118:      	stp	q2, q3, [sp, #0x260]
    111c:      	add	x12, sp, #0x260
    1120:      	ldr	s0, [x12, x9, lsl #2]
    1124:      	ands	w9, w25, #0x1
    1128:      	tst	w9, w2
    112c:      	fcsel	s21, s0, s15, ne
    1130:      	add	x9, sp, #0x178
    1134:      	bfxil	x9, x17, #0, #3
    1138:      	ldrb	w9, [x9]
    113c:      	umov.b	w27, v31[2]
    1140:      	and	x17, x17, #0x7
    1144:      	stp	q2, q3, [sp, #0x240]
    1148:      	add	x12, sp, #0x240
    114c:      	ldr	s0, [x12, x17, lsl #2]
    1150:      	ands	w17, w27, #0x1
    1154:      	tst	w17, w9
    1158:      	fcsel	s17, s0, s15, ne
    115c:      	add	x9, sp, #0x178
    1160:      	bfxil	x9, x1, #0, #3
    1164:      	ldrb	w9, [x9]
    1168:      	and	x17, x1, #0x7
    116c:      	umov.b	w28, v31[3]
    1170:      	stp	q2, q3, [sp, #0x220]
    1174:      	add	x12, sp, #0x220
    1178:      	ldr	s0, [x12, x17, lsl #2]
    117c:      	ands	w17, w28, #0x1
    1180:      	tst	w17, w9
    1184:      	mov.s	w9, v22[1]
    1188:      	mov.s	w2, v22[2]
    118c:      	fcsel	s23, s0, s15, ne
    1190:      	mov.s	w22, v22[3]
    1194:      	fmov	w17, s22
    1198:      	and	x1, x17, #0x7
    119c:      	add	x12, sp, #0x178
    11a0:      	bfxil	x12, x17, #0, #3
    11a4:      	ldrb	w12, [x12]
    11a8:      	umov.b	w17, v31[4]
    11ac:      	and	w12, w17, w12
    11b0:      	stp	q2, q3, [sp, #0x300]
    11b4:      	add	x13, sp, #0x300
    11b8:      	ldr	s0, [x13, x1, lsl #2]
    11bc:      	tst	w12, #0x1
    11c0:      	fcsel	s0, s0, s15, ne
    11c4:      	add	x12, sp, #0x178
    11c8:      	bfxil	x12, x9, #0, #3
    11cc:      	ldrb	w12, [x12]
    11d0:      	and	x9, x9, #0x7
    11d4:      	umov.b	w1, v31[5]
    11d8:      	stp	q2, q3, [sp, #0x2e0]
    11dc:      	add	x13, sp, #0x2e0
    11e0:      	ldr	s18, [x13, x9, lsl #2]
    11e4:      	ands	w9, w1, #0x1
    11e8:      	tst	w9, w12
    11ec:      	fcsel	s18, s18, s15, ne
    11f0:      	add	x9, sp, #0x178
    11f4:      	bfxil	x9, x2, #0, #3
    11f8:      	ldrb	w12, [x9]
    11fc:      	and	x2, x2, #0x7
    1200:      	umov.b	w9, v31[6]
    1204:      	stp	q2, q3, [sp, #0x2c0]
    1208:      	add	x13, sp, #0x2c0
    120c:      	ldr	s22, [x13, x2, lsl #2]
    1210:      	ands	w2, w9, #0x1
    1214:      	tst	w2, w12
    1218:      	fcsel	s22, s22, s15, ne
    121c:      	add	x12, sp, #0x178
    1220:      	bfxil	x12, x22, #0, #3
    1224:      	ldrb	w12, [x12]
    1228:      	umov.b	w2, v31[7]
    122c:      	and	x22, x22, #0x7
    1230:      	stp	q2, q3, [sp, #0x2a0]
    1234:      	add	x13, sp, #0x2a0
    1238:      	ldr	s24, [x13, x22, lsl #2]
    123c:      	ands	w22, w2, #0x1
    1240:      	tst	w22, w12
    1244:      	fcsel	s24, s24, s15, ne
    1248:      	mov.s	v0[1], v18[0]
    124c:      	mov.s	v0[2], v22[0]
    1250:      	mov.s	v0[3], v24[0]
    1254:      	mov.s	v20[1], v21[0]
    1258:      	mov.s	v20[2], v17[0]
    125c:      	mov.s	v20[3], v23[0]
    1260:      	fadd.4s	v2, v2, v20
    1264:      	fadd.4s	v0, v3, v0
    1268:      	movi.4s	v17, #0x2
    126c:      	eor.16b	v3, v4, v17
    1270:      	eor.16b	v1, v1, v17
    1274:      	fmov	w12, s1
    1278:      	add	x22, sp, #0x178
    127c:      	bfxil	x22, x12, #0, #3
    1280:      	ldrb	w22, [x22]
    1284:      	and	x12, x12, #0x7
    1288:      	stp	q2, q0, [sp, #0x200]
    128c:      	add	x13, sp, #0x200
    1290:      	ldr	s1, [x13, x12, lsl #2]
    1294:      	tst	w26, w22
    1298:      	fcsel	s1, s1, s15, ne
    129c:      	fmov	w12, s3
    12a0:      	and	x22, x12, #0x7
    12a4:      	add	x13, sp, #0x178
    12a8:      	bfxil	x13, x12, #0, #3
    12ac:      	ldrb	w12, [x13]
    12b0:      	and	w12, w17, w12
    12b4:      	stp	q2, q0, [sp, #0x1e0]
    12b8:      	add	x13, sp, #0x1e0
    12bc:      	ldr	s3, [x13, x22, lsl #2]
    12c0:      	tst	w12, #0x1
    12c4:      	fcsel	s3, s3, s15, ne
    12c8:      	fadd.4s	v0, v0, v3
    12cc:      	tst	w26, w17
    12d0:      	fcsel	s0, s0, s15, ne
    12d4:      	ands	w12, w24, #0x1
    12d8:      	fadd.4s	v1, v2, v1
    12dc:      	fadd	s0, s1, s0
    12e0:      	fcsel	s1, s0, s15, ne
    12e4:      	tst	w25, #0x1
    12e8:      	fcsel	s2, s1, s15, ne
    12ec:      	tst	w27, #0x1
    12f0:      	fcsel	s3, s1, s15, ne
    12f4:      	tst	w28, #0x1
    12f8:      	fcsel	s4, s1, s15, ne
    12fc:      	tst	w12, w17
    1300:      	fcsel	s0, s0, s15, ne
    1304:      	tst	w1, #0x1
    1308:      	fcsel	s17, s1, s15, ne
    130c:      	tst	w9, #0x1
    1310:      	fcsel	s18, s1, s15, ne
    1314:      	tst	w2, #0x1
    1318:      	shl.8b	v20, v19, #0x7
    131c:      	cmlt.8b	v20, v20, #0
    1320:      	ldr	d21, [sp, #0x98]
    1324:      	and.8b	v20, v20, v21
    1328:      	addv.8b	b25, v20
    132c:      	fmov	w24, s25
    1330:      	fcsel	s20, s1, s15, ne
    1334:      	mov.s	v1[1], v2[0]
    1338:      	mov.s	v1[2], v3[0]
    133c:      	mov.s	v1[3], v4[0]
    1340:      	mov.s	v0[1], v17[0]
    1344:      	mov.s	v0[2], v18[0]
    1348:      	mov.s	v0[3], v20[0]
    134c:      	ldr	w9, [sp, #0xf0]
    1350:      	rbit	w9, w9
    1354:      	clz	w9, w9
    1358:      	stp	q1, q0, [sp, #0x1c0]
    135c:      	and	x9, x9, #0x7
    1360:      	add	x12, sp, #0x1c0
    1364:      	ldr	s3, [x12, x9, lsl #2]
    1368:      	mov	b0, v19[0]
    136c:      	mov.b	v0[4], v19[1]
    1370:      	ushll.2d	v0, v0, #0x0
    1374:      	shl.2d	v0, v0, #0x3f
    1378:      	cmlt.2d	v0, v0, #0
    137c:      	mov	b1, v19[2]
    1380:      	mov.b	v1[4], v19[3]
    1384:      	ldr	q2, [sp, #0xa0]
    1388:      	and.16b	v0, v0, v2
    138c:      	ushll.2d	v1, v1, #0x0
    1390:      	shl.2d	v1, v1, #0x3f
    1394:      	cmlt.2d	v1, v1, #0
    1398:      	ldp	q2, q4, [sp, #0x60]
    139c:      	and.16b	v1, v1, v2
    13a0:      	mov	b2, v19[4]
    13a4:      	mov.b	v2[4], v19[5]
    13a8:      	ushll.2d	v2, v2, #0x0
    13ac:      	shl.2d	v2, v2, #0x3f
    13b0:      	cmlt.2d	v2, v2, #0
    13b4:      	and.16b	v2, v2, v4
    13b8:      	mov	b4, v19[6]
    13bc:      	mov.b	v4[4], v19[7]
    13c0:      	ushll.2d	v4, v4, #0x0
    13c4:      	shl.2d	v4, v4, #0x3f
    13c8:      	cmlt.2d	v4, v4, #0
    13cc:      	ldr	q17, [sp, #0x80]
    13d0:      	and.16b	v4, v4, v17
    13d4:      	stp	q2, q4, [sp, #0x1a0]
    13d8:      	stp	q0, q1, [sp, #0x180]
    13dc:      	and	x9, x20, #0x7
    13e0:      	add	x12, sp, #0x180
    13e4:      	ldr	x9, [x12, x9, lsl #3]
    13e8:      	sub	x9, x9, x20
    13ec:      	add	x21, x21, x9, lsl #2
    13f0:      	movi.2d	v2, #0000000000000000
    13f4:      	movi.2d	v1, #0000000000000000
    13f8:      	tbnz	w24, #0x0, 0x1648 <ltmp0+0x1648>
    13fc:      	ldr	x13, [sp, #0x128]
    1400:      	tbnz	w24, #0x1, 0x1654 <ltmp0+0x1654>
    1404:      	mov	w26, #0x20              ; =32
    1408:      	mov	x27, x19
    140c:      	mov	x28, x23
    1410:      	tbnz	w24, #0x2, 0x166c <ltmp0+0x166c>
    1414:      	tbnz	w24, #0x3, 0x1678 <ltmp0+0x1678>
    1418:      	tbnz	w24, #0x4, 0x1684 <ltmp0+0x1684>
    141c:      	tbnz	w24, #0x5, 0x1690 <ltmp0+0x1690>
    1420:      	tbnz	w24, #0x6, 0x169c <ltmp0+0x169c>
    1424:      	tbz	w24, #0x7, 0x1430 <ltmp0+0x1430>
    1428:      	add	x9, x21, #0x1c
    142c:      	ld1.s	{ v1 }[3], [x9]
    1430:      	mov	x9, #0x0                ; =0
    1434:      	fadd	s0, s3, s15
    1438:      	fmov	s3, w11
    143c:      	fdiv	s0, s0, s3
    1440:      	add	x12, x15, x3
    1444:      	ldp	q3, q4, [x12]
    1448:      	zip2.8b	v17, v19, v0
    144c:      	ushll.4s	v17, v17, #0x0
    1450:      	shl.4s	v17, v17, #0x1f
    1454:      	cmlt.4s	v17, v17, #0
    1458:      	bit.16b	v4, v1, v17
    145c:      	zip1.8b	v17, v19, v0
    1460:      	ushll.4s	v17, v17, #0x0
    1464:      	shl.4s	v17, v17, #0x1f
    1468:      	cmlt.4s	v17, v17, #0
    146c:      	bit.16b	v3, v2, v17
    1470:      	stp	q3, q4, [x12]
    1474:      	fmov	s3, w14
    1478:      	fadd	s0, s0, s3
    147c:      	fsqrt	s0, s0
    1480:      	dup.4s	v3, v0[0]
    1484:      	ldr	q0, [sp, #0xb0]
    1488:      	fmov	x12, d0
    148c:      	add	x17, x13, x12, lsl #2
    1490:      	movi.2d	v4, #0000000000000000
    1494:      	movi.2d	v17, #0000000000000000
    1498:      	movi.2d	v19, #0000000000000000
    149c:      	movi.2d	v20, #0000000000000000
    14a0:      	ldr	w3, [sp, #0x1c]
    14a4:      	b	0x14c4 <ltmp0+0x14c4>
    14a8:      	add.2d	v17, v17, v27
    14ac:      	add.2d	v19, v19, v28
    14b0:      	add.2d	v20, v20, v26
    14b4:      	add.2d	v4, v4, v29
    14b8:      	fmov	x9, d4
    14bc:      	cmp	x9, #0x8
    14c0:      	b.ge	0x1594 <ltmp0+0x1594>
    14c4:      	fmov	w1, s7
    14c8:      	lsl	x9, x9, #5
    14cc:      	add	x12, x4, x9
    14d0:      	ldp	q0, q21, [x12]
    14d4:      	and.16b	v0, v6, v0
    14d8:      	fdiv.4s	v0, v0, v3
    14dc:      	add	x12, x15, x9
    14e0:      	ldp	q18, q22, [x12]
    14e4:      	and.16b	v18, v6, v18
    14e8:      	fmul.4s	v23, v0, v18
    14ec:      	add	x9, x17, x9
    14f0:      	tbnz	w1, #0x0, 0x1528 <ltmp0+0x1528>
    14f4:      	and	w1, w1, #0xff
    14f8:      	tbnz	w1, #0x1, 0x1534 <ltmp0+0x1534>
    14fc:      	tbnz	w1, #0x2, 0x1540 <ltmp0+0x1540>
    1500:      	tbnz	w1, #0x3, 0x154c <ltmp0+0x154c>
    1504:      	and.16b	v0, v5, v21
    1508:      	fdiv.4s	v0, v0, v3
    150c:      	and.16b	v18, v5, v22
    1510:      	fmul.4s	v21, v0, v18
    1514:      	tbnz	w1, #0x4, 0x1568 <ltmp0+0x1568>
    1518:      	tbnz	w1, #0x5, 0x1570 <ltmp0+0x1570>
    151c:      	tbnz	w1, #0x6, 0x157c <ltmp0+0x157c>
    1520:      	tbz	w1, #0x7, 0x14a8 <ltmp0+0x14a8>
    1524:      	b	0x1588 <ltmp0+0x1588>
    1528:      	str	s23, [x9]
    152c:      	and	w1, w1, #0xff
    1530:      	tbz	w1, #0x1, 0x14fc <ltmp0+0x14fc>
    1534:      	add	x12, x9, #0x4
    1538:      	st1.s	{ v23 }[1], [x12]
    153c:      	tbz	w1, #0x2, 0x1500 <ltmp0+0x1500>
    1540:      	add	x12, x9, #0x8
    1544:      	st1.s	{ v23 }[2], [x12]
    1548:      	tbz	w1, #0x3, 0x1504 <ltmp0+0x1504>
    154c:      	add	x12, x9, #0xc
    1550:      	st1.s	{ v23 }[3], [x12]
    1554:      	and.16b	v0, v5, v21
    1558:      	fdiv.4s	v0, v0, v3
    155c:      	and.16b	v18, v5, v22
    1560:      	fmul.4s	v21, v0, v18
    1564:      	tbz	w1, #0x4, 0x1518 <ltmp0+0x1518>
    1568:      	str	s21, [x9, #0x10]
    156c:      	tbz	w1, #0x5, 0x151c <ltmp0+0x151c>
    1570:      	add	x12, x9, #0x14
    1574:      	st1.s	{ v21 }[1], [x12]
    1578:      	tbz	w1, #0x6, 0x1520 <ltmp0+0x1520>
    157c:      	add	x12, x9, #0x18
    1580:      	st1.s	{ v21 }[2], [x12]
    1584:      	tbz	w1, #0x7, 0x14a8 <ltmp0+0x14a8>
    1588:      	add	x9, x9, #0x1c
    158c:      	st1.s	{ v21 }[3], [x9]
    1590:      	b	0x14a8 <ltmp0+0x14a8>
    1594:      	fdiv.4s	v0, v30, v3
    1598:      	fmul.4s	v2, v0, v2
    159c:      	ldr	q4, [sp, #0x110]
    15a0:      	ldp	q6, q5, [sp, #0xc0]
    15a4:      	stp	q4, q5, [sp, #0x130]
    15a8:      	ldr	q0, [sp, #0xe0]
    15ac:      	stp	q6, q0, [sp, #0x150]
    15b0:      	and	x9, x20, #0x7
    15b4:      	add	x12, sp, #0x130
    15b8:      	ldr	x9, [x12, x9, lsl #3]
    15bc:      	sub	x9, x9, x20
    15c0:      	add	x9, x13, x9, lsl #2
    15c4:      	fmov	w17, s25
    15c8:      	tbnz	w17, #0x0, 0x16ac <ltmp0+0x16ac>
    15cc:      	tbnz	w17, #0x1, 0x16b4 <ltmp0+0x16b4>
    15d0:      	tbnz	w17, #0x2, 0x16c0 <ltmp0+0x16c0>
    15d4:      	tbnz	w17, #0x3, 0x16cc <ltmp0+0x16cc>
    15d8:      	fdiv.4s	v0, v16, v3
    15dc:      	fmul.4s	v1, v0, v1
    15e0:      	tbnz	w17, #0x4, 0x16e0 <ltmp0+0x16e0>
    15e4:      	tbnz	w17, #0x5, 0x16e8 <ltmp0+0x16e8>
    15e8:      	tbnz	w17, #0x6, 0x16f4 <ltmp0+0x16f4>
    15ec:      	tbz	w17, #0x7, 0x808 <ltmp0+0x808>
    15f0:      	b	0x1700 <ltmp0+0x1700>
    15f4:      	ldr	s24, [x23]
    15f8:      	tbz	w24, #0x1, 0xc7c <ltmp0+0xc7c>
    15fc:      	add	x9, x23, #0x4
    1600:      	ld1.s	{ v24 }[1], [x9]
    1604:      	tbz	w24, #0x2, 0xc80 <ltmp0+0xc80>
    1608:      	add	x9, x23, #0x8
    160c:      	ld1.s	{ v24 }[2], [x9]
    1610:      	tbz	w24, #0x3, 0xc84 <ltmp0+0xc84>
    1614:      	add	x9, x23, #0xc
    1618:      	ld1.s	{ v24 }[3], [x9]
    161c:      	tbz	w24, #0x4, 0xc88 <ltmp0+0xc88>
    1620:      	add	x9, x23, #0x10
    1624:      	ld1.s	{ v16 }[0], [x9]
    1628:      	tbz	w24, #0x5, 0xc8c <ltmp0+0xc8c>
    162c:      	add	x9, x23, #0x14
    1630:      	ld1.s	{ v16 }[1], [x9]
    1634:      	tbz	w24, #0x6, 0xc90 <ltmp0+0xc90>
    1638:      	add	x9, x23, #0x18
    163c:      	ld1.s	{ v16 }[2], [x9]
    1640:      	tbnz	w24, #0x7, 0xc94 <ltmp0+0xc94>
    1644:      	b	0xc9c <ltmp0+0xc9c>
    1648:      	ldr	s2, [x21]
    164c:      	ldr	x13, [sp, #0x128]
    1650:      	tbz	w24, #0x1, 0x1404 <ltmp0+0x1404>
    1654:      	add	x9, x21, #0x4
    1658:      	ld1.s	{ v2 }[1], [x9]
    165c:      	mov	w26, #0x20              ; =32
    1660:      	mov	x27, x19
    1664:      	mov	x28, x23
    1668:      	tbz	w24, #0x2, 0x1414 <ltmp0+0x1414>
    166c:      	add	x9, x21, #0x8
    1670:      	ld1.s	{ v2 }[2], [x9]
    1674:      	tbz	w24, #0x3, 0x1418 <ltmp0+0x1418>
    1678:      	add	x9, x21, #0xc
    167c:      	ld1.s	{ v2 }[3], [x9]
    1680:      	tbz	w24, #0x4, 0x141c <ltmp0+0x141c>
    1684:      	add	x9, x21, #0x10
    1688:      	ld1.s	{ v1 }[0], [x9]
    168c:      	tbz	w24, #0x5, 0x1420 <ltmp0+0x1420>
    1690:      	add	x9, x21, #0x14
    1694:      	ld1.s	{ v1 }[1], [x9]
    1698:      	tbz	w24, #0x6, 0x1424 <ltmp0+0x1424>
    169c:      	add	x9, x21, #0x18
    16a0:      	ld1.s	{ v1 }[2], [x9]
    16a4:      	tbnz	w24, #0x7, 0x1428 <ltmp0+0x1428>
    16a8:      	b	0x1430 <ltmp0+0x1430>
    16ac:      	str	s2, [x9]
    16b0:      	tbz	w17, #0x1, 0x15d0 <ltmp0+0x15d0>
    16b4:      	add	x12, x9, #0x4
    16b8:      	st1.s	{ v2 }[1], [x12]
    16bc:      	tbz	w17, #0x2, 0x15d4 <ltmp0+0x15d4>
    16c0:      	add	x12, x9, #0x8
    16c4:      	st1.s	{ v2 }[2], [x12]
    16c8:      	tbz	w17, #0x3, 0x15d8 <ltmp0+0x15d8>
    16cc:      	add	x12, x9, #0xc
    16d0:      	st1.s	{ v2 }[3], [x12]
    16d4:      	fdiv.4s	v0, v16, v3
    16d8:      	fmul.4s	v1, v0, v1
    16dc:      	tbz	w17, #0x4, 0x15e4 <ltmp0+0x15e4>
    16e0:      	str	s1, [x9, #0x10]
    16e4:      	tbz	w17, #0x5, 0x15e8 <ltmp0+0x15e8>
    16e8:      	add	x12, x9, #0x14
    16ec:      	st1.s	{ v1 }[1], [x12]
    16f0:      	tbz	w17, #0x6, 0x15ec <ltmp0+0x15ec>
    16f4:      	add	x12, x9, #0x18
    16f8:      	st1.s	{ v1 }[2], [x12]
    16fc:      	tbz	w17, #0x7, 0x808 <ltmp0+0x808>
    1700:      	add	x9, x9, #0x1c
    1704:      	st1.s	{ v1 }[3], [x9]
    1708:      	b	0x808 <ltmp0+0x808>
    170c:      	ldr	x9, [sp, #0x10]
    1710:      	stp	w6, w5, [x9]
    1714:      	str	w16, [x9, #0x8]
    1718:      	mov	w8, #0x18               ; =24
    171c:      	str	w8, [x9, #0x24]
    1720:      	add	sp, sp, #0x600
    1724:      	ldp	x29, x30, [sp, #0x90]
    1728:      	ldp	x20, x19, [sp, #0x80]
    172c:      	ldp	x22, x21, [sp, #0x70]
    1730:      	ldp	x24, x23, [sp, #0x60]
    1734:      	ldp	x26, x25, [sp, #0x50]
    1738:      	ldp	x28, x27, [sp, #0x40]
    173c:      	ldp	d9, d8, [sp, #0x30]
    1740:      	ldp	d11, d10, [sp, #0x20]
    1744:      	ldp	d13, d12, [sp, #0x10]
    1748:      	ldp	d15, d14, [sp], #0xa0
    174c:      	ret

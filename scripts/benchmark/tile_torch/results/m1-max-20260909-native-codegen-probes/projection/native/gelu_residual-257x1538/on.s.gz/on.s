
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/gelu_residual-257x1538/on/object/tile_xir_w8_38053_1788936545059977_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x90]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x24, x23, [sp, #0x50]
      18:      	stp	x22, x21, [sp, #0x60]
      1c:      	stp	x20, x19, [sp, #0x70]
      20:      	stp	x29, x30, [sp, #0x80]
      24:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      28:      	sub	sp, sp, #0x170
      2c:      	ldr	x22, [x0]
      30:      	ldr	x21, [x0, #0x10]
      34:      	ldr	x19, [x0, #0x30]
      38:      	ldr	w8, [x1]
      3c:      	ldr	w9, [x1, #0x24]
      40:      	add	w8, w9, w8, lsl #5
      44:      	lsr	w8, w8, #3
      48:      	subs	x9, x22, x19
      4c:      	mov	w10, #0x2007            ; =8199
      50:      	movk	w10, #0x18, lsl #16
      54:      	ccmp	x9, x10, #0x0, hs
      58:      	cset	w9, hi
      5c:      	subs	x11, x19, x22
      60:      	ccmp	x11, x10, #0x0, hs
      64:      	csinc	w9, w9, wzr, ls
      68:      	subs	x11, x21, x19
      6c:      	ccmp	x11, x10, #0x0, hs
      70:      	cset	w11, hi
      74:      	subs	x12, x19, x21
      78:      	ccmp	x12, x10, #0x0, hs
      7c:      	csinc	w10, w11, wzr, ls
      80:      	mov	w11, #0x1808            ; =6152
      84:      	umull	x23, w8, w11
      88:      	cmp	w9, #0x1
      8c:      	ccmp	w10, #0x0, #0x4, eq
      90:      	b.ne	0x7cc <ltmp0+0x7cc>
      94:      	mov	w20, #0x1800            ; =6144
      98:      	add	x24, sp, #0x1, lsl #12  ; =0x1000
      9c:      	add	x24, x24, #0x950
      a0:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
      a4:      	add	x0, x0, #0x950
      a8:      	add	x1, x22, x23
      ac:      	mov	w2, #0x1800             ; =6144
      b0:      	bl	0xb0 <ltmp0+0xb0>
      b4:      	add	x20, x23, x20
      b8:      	add	x8, x22, x20
      bc:      	add	x9, x8, #0x4
      c0:      	ldr	s0, [x8]
      c4:      	ld1.s	{ v0 }[1], [x9]
      c8:      	str	q0, [sp, #0x10]
      cc:      	str	q0, [sp, #0x3150]
      d0:      	add	x22, sp, #0x130
      d4:      	add	x0, sp, #0x130
      d8:      	add	x1, x21, x23
      dc:      	mov	w2, #0x1800             ; =6144
      e0:      	bl	0xe0 <ltmp0+0xe0>
      e4:      	mov	x8, #0x0                ; =0
      e8:      	add	x9, x21, x20
      ec:      	ldr	s0, [x9], #0x4
      f0:      	ld1.s	{ v0 }[1], [x9]
      f4:      	str	q0, [sp, #0x20]
      f8:      	str	q0, [sp, #0x1930]
      fc:      	add	x9, x19, x23
     100:      	mov	w10, #0x2713            ; =10003
     104:      	movk	w10, #0x3d37, lsl #16
     108:      	dup.4s	v1, w10
     10c:      	mov	w10, #0x422a            ; =16938
     110:      	movk	w10, #0x3f4c, lsl #16
     114:      	dup.4s	v0, w10
     118:      	stp	q0, q1, [sp, #0x100]
     11c:      	fmov.4s	v18, #1.00000000
     120:      	mov	w10, #0x9231            ; =37425
     124:      	movk	w10, #0x2f30, lsl #16
     128:      	dup.4s	v1, w10
     12c:      	mov	w10, #0x322b            ; =12843
     130:      	movk	w10, #0x32d7, lsl #16
     134:      	dup.4s	v0, w10
     138:      	stp	q0, q1, [sp, #0xe0]
     13c:      	mov	w10, #0xef1d            ; =61213
     140:      	movk	w10, #0x3638, lsl #16
     144:      	dup.4s	v1, w10
     148:      	mov	w10, #0xd01             ; =3329
     14c:      	movk	w10, #0x3950, lsl #16
     150:      	dup.4s	v0, w10
     154:      	stp	q0, q1, [sp, #0xc0]
     158:      	mov	w10, #0x8889            ; =34953
     15c:      	movk	w10, #0x3c08, lsl #16
     160:      	dup.4s	v1, w10
     164:      	mov	w10, #0xaaab            ; =43691
     168:      	movk	w10, #0x3e2a, lsl #16
     16c:      	dup.4s	v21, w10
     170:      	mov	w10, #0x76c7            ; =30407
     174:      	movk	w10, #0x310f, lsl #16
     178:      	dup.4s	v0, w10
     17c:      	stp	q0, q1, [sp, #0xa0]
     180:      	mov	w10, #0xf27e            ; =62078
     184:      	movk	w10, #0x3493, lsl #16
     188:      	dup.4s	v1, w10
     18c:      	mov	w10, #0xd01             ; =3329
     190:      	movk	w10, #0x37d0, lsl #16
     194:      	dup.4s	v0, w10
     198:      	stp	q0, q1, [sp, #0x80]
     19c:      	mov	w10, #0xb61             ; =2913
     1a0:      	movk	w10, #0x3ab6, lsl #16
     1a4:      	dup.4s	v1, w10
     1a8:      	mov	w10, #0xaaab            ; =43691
     1ac:      	movk	w10, #0x3d2a, lsl #16
     1b0:      	dup.4s	v0, w10
     1b4:      	stp	q0, q1, [sp, #0x60]
     1b8:      	mov	w10, #-0x3d300000       ; =-1026555904
     1bc:      	dup.4s	v1, w10
     1c0:      	mov	w10, #0x42c80000        ; =1120403456
     1c4:      	dup.4s	v26, w10
     1c8:      	fmov.4s	v0, #9.00000000
     1cc:      	str	q0, [sp, #0x120]
     1d0:      	mov	w10, #0xaa3b            ; =43579
     1d4:      	movk	w10, #0x3fb8, lsl #16
     1d8:      	dup.4s	v0, w10
     1dc:      	stp	q0, q1, [sp, #0x40]
     1e0:      	mov	w10, #0x7200            ; =29184
     1e4:      	movk	w10, #0xbf31, lsl #16
     1e8:      	dup.4s	v0, w10
     1ec:      	str	q0, [sp, #0x30]
     1f0:      	mov	w10, #0xbe8e            ; =48782
     1f4:      	movk	w10, #0xb5bf, lsl #16
     1f8:      	dup.4s	v31, w10
     1fc:      	mov	w10, #0x2bda            ; =11226
     200:      	movk	w10, #0x3950, lsl #16
     204:      	dup.4s	v8, w10
     208:      	mov	w10, #0x96c9            ; =38601
     20c:      	movk	w10, #0x3ab6, lsl #16
     210:      	dup.4s	v9, w10
     214:      	mov	w10, #0x88a6            ; =34982
     218:      	movk	w10, #0x3c08, lsl #16
     21c:      	dup.4s	v10, w10
     220:      	mov	w10, #0xaa7a            ; =43642
     224:      	movk	w10, #0x3d2a, lsl #16
     228:      	dup.4s	v11, w10
     22c:      	mvni.4s	v1, #0x7f, msl #16
     230:      	fneg.4s	v13, v1
     234:      	mvni.4s	v1, #0x3f, msl #16
     238:      	fneg.4s	v15, v1
     23c:      	lsl	x10, x8, #5
     240:      	add	x11, x24, x10
     244:      	ldp	q28, q29, [x11]
     248:      	ldp	q0, q3, [sp, #0x100]
     24c:      	fmul.4s	v1, v28, v3
     250:      	fmul.4s	v2, v29, v3
     254:      	fmul.4s	v2, v29, v2
     258:      	fmul.4s	v1, v28, v1
     25c:      	fmul.4s	v1, v28, v1
     260:      	fmul.4s	v2, v29, v2
     264:      	fadd.4s	v2, v29, v2
     268:      	fadd.4s	v1, v28, v1
     26c:      	fmul.4s	v14, v1, v0
     270:      	fmul.4s	v12, v2, v0
     274:      	fabs.4s	v3, v12
     278:      	fabs.4s	v2, v14
     27c:      	fmul.4s	v17, v14, v14
     280:      	ldp	q4, q0, [sp, #0xe0]
     284:      	mov.16b	v1, v4
     288:      	fmul.4s	v20, v12, v12
     28c:      	fmla.4s	v1, v17, v0
     290:      	fmla.4s	v4, v20, v0
     294:      	ldp	q0, q6, [sp, #0xc0]
     298:      	mov.16b	v5, v6
     29c:      	fmla.4s	v5, v17, v1
     2a0:      	fmla.4s	v6, v20, v4
     2a4:      	mov.16b	v4, v0
     2a8:      	fmla.4s	v4, v17, v5
     2ac:      	mov.16b	v5, v0
     2b0:      	ldr	q0, [sp, #0xb0]
     2b4:      	mov.16b	v7, v0
     2b8:      	fmla.4s	v5, v20, v6
     2bc:      	mov.16b	v6, v0
     2c0:      	mov.16b	v19, v21
     2c4:      	mov.16b	v16, v21
     2c8:      	mov.16b	v1, v18
     2cc:      	mov.16b	v25, v18
     2d0:      	fmla.4s	v7, v17, v4
     2d4:      	ldp	q22, q0, [sp, #0x90]
     2d8:      	mov.16b	v4, v22
     2dc:      	fmla.4s	v4, v20, v0
     2e0:      	fmla.4s	v22, v17, v0
     2e4:      	ldr	q0, [sp, #0x80]
     2e8:      	mov.16b	v23, v0
     2ec:      	fmla.4s	v6, v20, v5
     2f0:      	fmla.4s	v23, v20, v4
     2f4:      	mov.16b	v4, v0
     2f8:      	fmla.4s	v4, v17, v22
     2fc:      	ldp	q22, q0, [sp, #0x60]
     300:      	mov.16b	v5, v0
     304:      	fmla.4s	v5, v20, v23
     308:      	fmla.4s	v19, v17, v7
     30c:      	mov.16b	v7, v0
     310:      	fmla.4s	v7, v17, v4
     314:      	mov.16b	v4, v22
     318:      	fmla.4s	v4, v20, v5
     31c:      	fmla.4s	v16, v20, v6
     320:      	fmla.4s	v22, v17, v7
     324:      	movi.4s	v23, #0x3f, lsl #24
     328:      	fmla.4s	v23, v20, v4
     32c:      	movi.4s	v24, #0x3f, lsl #24
     330:      	mov.16b	v6, v18
     334:      	fmla.4s	v25, v20, v16
     338:      	mov.16b	v0, v18
     33c:      	ldr	q5, [sp, #0x120]
     340:      	fcmge.4s	v4, v5, v2
     344:      	fcmge.4s	v5, v5, v3
     348:      	and.16b	v7, v5, v3
     34c:      	and.16b	v16, v4, v2
     350:      	fmla.4s	v6, v20, v23
     354:      	ldr	q23, [sp, #0x50]
     358:      	fcmge.4s	v20, v16, v23
     35c:      	fcmge.4s	v23, v7, v23
     360:      	fcmge.4s	v27, v26, v7
     364:      	and.16b	v23, v23, v27
     368:      	fcmge.4s	v27, v26, v16
     36c:      	fmla.4s	v24, v17, v22
     370:      	and.16b	v20, v20, v27
     374:      	and.16b	v20, v20, v16
     378:      	and.16b	v22, v23, v7
     37c:      	ldr	q27, [sp, #0x40]
     380:      	fmul.4s	v23, v22, v27
     384:      	fmul.4s	v27, v20, v27
     388:      	fmla.4s	v1, v17, v19
     38c:      	movi.4s	v30, #0x4b, lsl #24
     390:      	fadd.4s	v19, v27, v30
     394:      	fadd.4s	v23, v23, v30
     398:      	movi.4s	v27, #0xcb, lsl #24
     39c:      	fadd.4s	v23, v23, v27
     3a0:      	fadd.4s	v19, v19, v27
     3a4:      	fcvtzs.4s	v19, v19
     3a8:      	fmla.4s	v0, v17, v24
     3ac:      	fcvtzs.4s	v23, v23
     3b0:      	scvtf.4s	v17, v23
     3b4:      	scvtf.4s	v24, v19
     3b8:      	ldr	q30, [sp, #0x30]
     3bc:      	fmul.4s	v27, v17, v30
     3c0:      	fadd.4s	v22, v22, v27
     3c4:      	fmul.4s	v27, v24, v30
     3c8:      	fadd.4s	v20, v20, v27
     3cc:      	fmul.4s	v17, v17, v31
     3d0:      	fmul.4s	v24, v24, v31
     3d4:      	fadd.4s	v20, v20, v24
     3d8:      	fadd.4s	v22, v22, v17
     3dc:      	fmul.4s	v17, v22, v8
     3e0:      	fmul.4s	v24, v20, v8
     3e4:      	fadd.4s	v24, v24, v9
     3e8:      	fadd.4s	v17, v17, v9
     3ec:      	fmul.4s	v17, v22, v17
     3f0:      	fmul.4s	v24, v20, v24
     3f4:      	fmul.4s	v1, v2, v1
     3f8:      	fadd.4s	v24, v24, v10
     3fc:      	fadd.4s	v17, v17, v10
     400:      	fmul.4s	v27, v22, v17
     404:      	fmul.4s	v17, v20, v24
     408:      	fadd.4s	v24, v17, v11
     40c:      	fdiv.4s	v17, v1, v0
     410:      	fadd.4s	v0, v27, v11
     414:      	fmul.4s	v0, v22, v0
     418:      	fmul.4s	v1, v20, v24
     41c:      	fadd.4s	v1, v1, v21
     420:      	fadd.4s	v0, v0, v21
     424:      	fmul.4s	v0, v22, v0
     428:      	fmul.4s	v1, v20, v1
     42c:      	movi.4s	v27, #0x3f, lsl #24
     430:      	fadd.4s	v1, v1, v27
     434:      	fadd.4s	v0, v0, v27
     438:      	fmul.4s	v24, v22, v22
     43c:      	fmul.4s	v0, v24, v0
     440:      	fmul.4s	v24, v20, v20
     444:      	fmul.4s	v1, v24, v1
     448:      	fadd.4s	v1, v20, v1
     44c:      	fadd.4s	v0, v22, v0
     450:      	fadd.4s	v0, v0, v18
     454:      	movi.2d	v20, #0xffffffffffffffff
     458:      	add.4s	v19, v19, v20
     45c:      	fadd.4s	v1, v1, v18
     460:      	add.4s	v20, v23, v20
     464:      	sshr.4s	v22, v20, #0x1
     468:      	sshr.4s	v23, v19, #0x1
     46c:      	shl.4s	v24, v23, #0x17
     470:      	add.4s	v24, v24, v18
     474:      	fmul.4s	v1, v1, v24
     478:      	shl.4s	v24, v22, #0x17
     47c:      	add.4s	v24, v24, v18
     480:      	fmul.4s	v0, v0, v24
     484:      	sub.4s	v19, v19, v23
     488:      	sub.4s	v20, v20, v22
     48c:      	shl.4s	v20, v20, #0x17
     490:      	add.4s	v20, v20, v18
     494:      	fmul.4s	v0, v0, v20
     498:      	shl.4s	v19, v19, #0x17
     49c:      	add.4s	v19, v19, v18
     4a0:      	fmul.4s	v1, v1, v19
     4a4:      	fmul.4s	v19, v3, v25
     4a8:      	fcmgt.4s	v7, v7, v26
     4ac:      	fcmgt.4s	v16, v16, v26
     4b0:      	bsl.16b	v16, v13, v1
     4b4:      	bit.16b	v0, v13, v7
     4b8:      	fmov.4s	v1, #0.25000000
     4bc:      	fdiv.4s	v6, v19, v6
     4c0:      	fdiv.4s	v7, v1, v0
     4c4:      	fsub.4s	v19, v0, v7
     4c8:      	fadd.4s	v0, v0, v7
     4cc:      	fdiv.4s	v0, v19, v0
     4d0:      	bif.16b	v0, v18, v5
     4d4:      	fcmge.4s	v3, v18, v3
     4d8:      	bit.16b	v0, v6, v3
     4dc:      	fdiv.4s	v3, v1, v16
     4e0:      	fsub.4s	v5, v16, v3
     4e4:      	fadd.4s	v3, v16, v3
     4e8:      	fdiv.4s	v3, v5, v3
     4ec:      	bif.16b	v3, v18, v4
     4f0:      	fcmge.4s	v2, v18, v2
     4f4:      	bsl.16b	v2, v17, v3
     4f8:      	mvni.4s	v4, #0x80, lsl #24
     4fc:      	bif.16b	v2, v14, v4
     500:      	fcmeq.4s	v3, v14, v14
     504:      	fadd.4s	v2, v2, v18
     508:      	bif.16b	v2, v15, v3
     50c:      	bif.16b	v0, v12, v4
     510:      	fcmeq.4s	v3, v12, v12
     514:      	fadd.4s	v0, v0, v18
     518:      	bif.16b	v0, v15, v3
     51c:      	fmul.4s	v3, v29, v27
     520:      	fmul.4s	v0, v3, v0
     524:      	fmul.4s	v3, v28, v27
     528:      	fmul.4s	v2, v3, v2
     52c:      	add	x11, x22, x10
     530:      	ldp	q4, q3, [x11]
     534:      	fadd.4s	v2, v4, v2
     538:      	fadd.4s	v0, v3, v0
     53c:      	add	x10, x9, x10
     540:      	stp	q2, q0, [x10]
     544:      	add	x8, x8, #0x1
     548:      	cmp	x8, #0xc0
     54c:      	b.ne	0x23c <ltmp0+0x23c>
     550:      	movi.2d	v2, #0000000000000000
     554:      	movi.2d	v3, #0000000000000000
     558:      	ldr	q4, [sp, #0x10]
     55c:      	mov.d	v3[0], v4[0]
     560:      	mov	w8, #0x2713             ; =10003
     564:      	movk	w8, #0x3d37, lsl #16
     568:      	dup.4s	v0, w8
     56c:      	fmul.4s	v0, v3, v0
     570:      	fmul.4s	v0, v4, v0
     574:      	fmul.4s	v0, v4, v0
     578:      	fadd.4s	v0, v4, v0
     57c:      	mov	w8, #0x422a             ; =16938
     580:      	movk	w8, #0x3f4c, lsl #16
     584:      	dup.4s	v4, w8
     588:      	fmul.4s	v0, v0, v4
     58c:      	mov.d	v2[0], v0[0]
     590:      	fabs.4s	v4, v2
     594:      	fmul.4s	v5, v2, v2
     598:      	mov	w8, #0x9231             ; =37425
     59c:      	movk	w8, #0x2f30, lsl #16
     5a0:      	dup.4s	v0, w8
     5a4:      	mov	w8, #0x322b             ; =12843
     5a8:      	movk	w8, #0x32d7, lsl #16
     5ac:      	dup.4s	v6, w8
     5b0:      	mov	w8, #0xef1d             ; =61213
     5b4:      	movk	w8, #0x3638, lsl #16
     5b8:      	dup.4s	v7, w8
     5bc:      	fmla.4s	v6, v5, v0
     5c0:      	fmla.4s	v7, v5, v6
     5c4:      	mov	w8, #0xd01              ; =3329
     5c8:      	movk	w8, #0x3950, lsl #16
     5cc:      	dup.4s	v6, w8
     5d0:      	fmla.4s	v6, v5, v7
     5d4:      	mov	w8, #0x8889             ; =34953
     5d8:      	movk	w8, #0x3c08, lsl #16
     5dc:      	dup.4s	v17, w8
     5e0:      	mov	w8, #0xaaab             ; =43691
     5e4:      	movk	w8, #0x3e2a, lsl #16
     5e8:      	dup.4s	v0, w8
     5ec:      	fmla.4s	v17, v5, v6
     5f0:      	ldr	q6, [sp, #0x120]
     5f4:      	fcmge.4s	v6, v6, v4
     5f8:      	and.16b	v7, v6, v4
     5fc:      	mov	w8, #-0x3d300000        ; =-1026555904
     600:      	dup.4s	v16, w8
     604:      	fcmge.4s	v19, v7, v16
     608:      	mov	w8, #0x42c80000         ; =1120403456
     60c:      	dup.4s	v16, w8
     610:      	fcmge.4s	v20, v16, v7
     614:      	and.16b	v19, v19, v20
     618:      	and.16b	v19, v19, v7
     61c:      	mov	w8, #0xaa3b             ; =43579
     620:      	movk	w8, #0x3fb8, lsl #16
     624:      	dup.4s	v20, w8
     628:      	fmul.4s	v20, v19, v20
     62c:      	movi.4s	v21, #0x4b, lsl #24
     630:      	fadd.4s	v20, v20, v21
     634:      	movi.4s	v21, #0xcb, lsl #24
     638:      	fadd.4s	v20, v20, v21
     63c:      	fcvtzs.4s	v20, v20
     640:      	scvtf.4s	v21, v20
     644:      	mov	w8, #0x7200             ; =29184
     648:      	movk	w8, #0xbf31, lsl #16
     64c:      	dup.4s	v22, w8
     650:      	fmul.4s	v22, v21, v22
     654:      	mov	w8, #0xbe8e             ; =48782
     658:      	movk	w8, #0xb5bf, lsl #16
     65c:      	dup.4s	v23, w8
     660:      	fadd.4s	v19, v19, v22
     664:      	fmul.4s	v21, v21, v23
     668:      	fadd.4s	v19, v19, v21
     66c:      	mov	w8, #0x2bda             ; =11226
     670:      	movk	w8, #0x3950, lsl #16
     674:      	dup.4s	v21, w8
     678:      	fmul.4s	v21, v19, v21
     67c:      	mov	w8, #0x96c9             ; =38601
     680:      	movk	w8, #0x3ab6, lsl #16
     684:      	dup.4s	v22, w8
     688:      	fadd.4s	v21, v21, v22
     68c:      	fmul.4s	v21, v19, v21
     690:      	mov	w8, #0x88a6             ; =34982
     694:      	movk	w8, #0x3c08, lsl #16
     698:      	dup.4s	v22, w8
     69c:      	fadd.4s	v21, v21, v22
     6a0:      	fmul.4s	v21, v19, v21
     6a4:      	mov	w8, #0xaa7a             ; =43642
     6a8:      	movk	w8, #0x3d2a, lsl #16
     6ac:      	dup.4s	v22, w8
     6b0:      	fadd.4s	v21, v21, v22
     6b4:      	fmul.4s	v21, v19, v21
     6b8:      	fadd.4s	v21, v21, v0
     6bc:      	fmla.4s	v0, v5, v17
     6c0:      	mov.16b	v17, v18
     6c4:      	fmla.4s	v17, v5, v0
     6c8:      	mov	w8, #0x76c7             ; =30407
     6cc:      	movk	w8, #0x310f, lsl #16
     6d0:      	dup.4s	v0, w8
     6d4:      	mov	w8, #0xf27e             ; =62078
     6d8:      	movk	w8, #0x3493, lsl #16
     6dc:      	dup.4s	v22, w8
     6e0:      	mov	w8, #0xd01              ; =3329
     6e4:      	movk	w8, #0x37d0, lsl #16
     6e8:      	dup.4s	v23, w8
     6ec:      	fmla.4s	v22, v5, v0
     6f0:      	fmla.4s	v23, v5, v22
     6f4:      	mov	w8, #0xb61              ; =2913
     6f8:      	movk	w8, #0x3ab6, lsl #16
     6fc:      	dup.4s	v0, w8
     700:      	fmla.4s	v0, v5, v23
     704:      	mov	w8, #0xaaab             ; =43691
     708:      	movk	w8, #0x3d2a, lsl #16
     70c:      	dup.4s	v22, w8
     710:      	fmla.4s	v22, v5, v0
     714:      	movi.4s	v0, #0x3f, lsl #24
     718:      	fmla.4s	v0, v5, v22
     71c:      	mov.16b	v22, v18
     720:      	fmla.4s	v22, v5, v0
     724:      	movi.4s	v0, #0x3f, lsl #24
     728:      	fmul.4s	v3, v3, v0
     72c:      	fcmge.4s	v5, v18, v4
     730:      	fmul.4s	v4, v4, v17
     734:      	fdiv.4s	v4, v4, v22
     738:      	fmul.4s	v17, v19, v21
     73c:      	fadd.4s	v0, v17, v0
     740:      	fmul.4s	v17, v19, v19
     744:      	fmul.4s	v0, v17, v0
     748:      	fadd.4s	v0, v19, v0
     74c:      	fadd.4s	v0, v0, v18
     750:      	movi.2d	v17, #0xffffffffffffffff
     754:      	add.4s	v17, v20, v17
     758:      	sshr.4s	v19, v17, #0x1
     75c:      	shl.4s	v20, v19, #0x17
     760:      	add.4s	v20, v20, v18
     764:      	fmul.4s	v0, v0, v20
     768:      	sub.4s	v17, v17, v19
     76c:      	shl.4s	v17, v17, #0x17
     770:      	add.4s	v17, v17, v18
     774:      	fmul.4s	v0, v0, v17
     778:      	fcmgt.4s	v7, v7, v16
     77c:      	mvni.4s	v16, #0x7f, msl #16
     780:      	fneg.4s	v16, v16
     784:      	bit.16b	v0, v16, v7
     788:      	fdiv.4s	v1, v1, v0
     78c:      	fsub.4s	v7, v0, v1
     790:      	fadd.4s	v0, v0, v1
     794:      	fdiv.4s	v0, v7, v0
     798:      	bif.16b	v0, v18, v6
     79c:      	bit.16b	v0, v4, v5
     7a0:      	mvni.4s	v1, #0x80, lsl #24
     7a4:      	bif.16b	v0, v2, v1
     7a8:      	fcmeq.4s	v1, v2, v2
     7ac:      	fadd.4s	v0, v0, v18
     7b0:      	mvni.4s	v2, #0x3f, msl #16
     7b4:      	fneg.4s	v2, v2
     7b8:      	bif.16b	v0, v2, v1
     7bc:      	fmul.4s	v0, v3, v0
     7c0:      	ldr	q1, [sp, #0x20]
     7c4:      	fadd.4s	v0, v0, v1
     7c8:      	b	0xed0 <ltmp0+0xed0>
     7cc:      	mov	x8, #0x0                ; =0
     7d0:      	mov	w9, #0x2713             ; =10003
     7d4:      	movk	w9, #0x3d37, lsl #16
     7d8:      	dup.4s	v1, w9
     7dc:      	mov	w9, #0x422a             ; =16938
     7e0:      	movk	w9, #0x3f4c, lsl #16
     7e4:      	dup.4s	v0, w9
     7e8:      	stp	q0, q1, [sp, #0xf0]
     7ec:      	mov	w9, #0x9231             ; =37425
     7f0:      	movk	w9, #0x2f30, lsl #16
     7f4:      	dup.4s	v1, w9
     7f8:      	mov	w9, #0x322b             ; =12843
     7fc:      	movk	w9, #0x32d7, lsl #16
     800:      	dup.4s	v0, w9
     804:      	stp	q0, q1, [sp, #0xd0]
     808:      	mov	w9, #0xef1d             ; =61213
     80c:      	movk	w9, #0x3638, lsl #16
     810:      	dup.4s	v1, w9
     814:      	mov	w9, #0xd01              ; =3329
     818:      	movk	w9, #0x3950, lsl #16
     81c:      	dup.4s	v0, w9
     820:      	stp	q0, q1, [sp, #0xb0]
     824:      	mov	w9, #0x8889             ; =34953
     828:      	movk	w9, #0x3c08, lsl #16
     82c:      	dup.4s	v1, w9
     830:      	mov	w9, #0xaaab             ; =43691
     834:      	movk	w9, #0x3e2a, lsl #16
     838:      	dup.4s	v21, w9
     83c:      	mov	w9, #0x76c7             ; =30407
     840:      	movk	w9, #0x310f, lsl #16
     844:      	dup.4s	v0, w9
     848:      	stp	q0, q1, [sp, #0x90]
     84c:      	mov	w9, #0xf27e             ; =62078
     850:      	movk	w9, #0x3493, lsl #16
     854:      	dup.4s	v1, w9
     858:      	mov	w9, #0xd01              ; =3329
     85c:      	movk	w9, #0x37d0, lsl #16
     860:      	dup.4s	v0, w9
     864:      	stp	q0, q1, [sp, #0x70]
     868:      	mov	w9, #0xb61              ; =2913
     86c:      	movk	w9, #0x3ab6, lsl #16
     870:      	dup.4s	v1, w9
     874:      	mov	w9, #0xaaab             ; =43691
     878:      	movk	w9, #0x3d2a, lsl #16
     87c:      	dup.4s	v0, w9
     880:      	stp	q0, q1, [sp, #0x50]
     884:      	mov	w9, #-0x3d300000        ; =-1026555904
     888:      	dup.4s	v1, w9
     88c:      	mov	w9, #0x42c80000         ; =1120403456
     890:      	dup.4s	v25, w9
     894:      	mov	w9, #0xaa3b             ; =43579
     898:      	movk	w9, #0x3fb8, lsl #16
     89c:      	dup.4s	v0, w9
     8a0:      	stp	q0, q1, [sp, #0x30]
     8a4:      	mov	w9, #0x7200             ; =29184
     8a8:      	movk	w9, #0xbf31, lsl #16
     8ac:      	dup.4s	v1, w9
     8b0:      	mov	w9, #0xbe8e             ; =48782
     8b4:      	movk	w9, #0xb5bf, lsl #16
     8b8:      	dup.4s	v0, w9
     8bc:      	stp	q0, q1, [sp, #0x10]
     8c0:      	mov	w9, #0x2bda             ; =11226
     8c4:      	movk	w9, #0x3950, lsl #16
     8c8:      	dup.4s	v0, w9
     8cc:      	str	q0, [sp]
     8d0:      	mov	w9, #0x96c9             ; =38601
     8d4:      	movk	w9, #0x3ab6, lsl #16
     8d8:      	dup.4s	v30, w9
     8dc:      	mov	w9, #0x88a6             ; =34982
     8e0:      	movk	w9, #0x3c08, lsl #16
     8e4:      	dup.4s	v31, w9
     8e8:      	mov	w9, #0xaa7a             ; =43642
     8ec:      	movk	w9, #0x3d2a, lsl #16
     8f0:      	dup.4s	v8, w9
     8f4:      	add	x9, x19, x23
     8f8:      	add	x10, x21, x23
     8fc:      	add	x11, x22, x23
     900:      	movi.4s	v9, #0x3f, lsl #24
     904:      	fmov.4s	v0, #1.00000000
     908:      	fmov.4s	v2, #9.00000000
     90c:      	mvni.4s	v1, #0x7f, msl #16
     910:      	fneg.4s	v13, v1
     914:      	fmov.4s	v1, #0.25000000
     918:      	stp	q2, q1, [sp, #0x110]
     91c:      	mvni.4s	v1, #0x3f, msl #16
     920:      	fneg.4s	v15, v1
     924:      	lsl	x12, x8, #5
     928:      	add	x13, x11, x12
     92c:      	ldp	q10, q11, [x13]
     930:      	ldp	q3, q2, [sp, #0xf0]
     934:      	fmul.4s	v1, v10, v2
     938:      	fmul.4s	v2, v11, v2
     93c:      	fmul.4s	v2, v11, v2
     940:      	fmul.4s	v1, v10, v1
     944:      	fmul.4s	v1, v10, v1
     948:      	fmul.4s	v2, v11, v2
     94c:      	fadd.4s	v2, v11, v2
     950:      	fadd.4s	v1, v10, v1
     954:      	fmul.4s	v14, v1, v3
     958:      	fmul.4s	v12, v2, v3
     95c:      	fabs.4s	v2, v12
     960:      	fabs.4s	v1, v14
     964:      	fmul.4s	v16, v14, v14
     968:      	fmul.4s	v19, v12, v12
     96c:      	ldp	q4, q5, [sp, #0xd0]
     970:      	mov.16b	v3, v4
     974:      	fmla.4s	v3, v16, v5
     978:      	fmla.4s	v4, v19, v5
     97c:      	ldr	q6, [sp, #0xc0]
     980:      	mov.16b	v5, v6
     984:      	fmla.4s	v5, v16, v3
     988:      	mov.16b	v3, v6
     98c:      	fmla.4s	v3, v19, v4
     990:      	ldp	q7, q6, [sp, #0xa0]
     994:      	mov.16b	v4, v6
     998:      	fmla.4s	v4, v16, v5
     99c:      	mov.16b	v5, v6
     9a0:      	fmla.4s	v5, v19, v3
     9a4:      	mov.16b	v6, v7
     9a8:      	mov.16b	v18, v21
     9ac:      	mov.16b	v20, v21
     9b0:      	mov.16b	v3, v0
     9b4:      	fmla.4s	v6, v16, v4
     9b8:      	ldp	q17, q22, [sp, #0x80]
     9bc:      	mov.16b	v4, v17
     9c0:      	fmla.4s	v4, v19, v22
     9c4:      	fmla.4s	v17, v16, v22
     9c8:      	ldr	q23, [sp, #0x70]
     9cc:      	mov.16b	v22, v23
     9d0:      	fmla.4s	v7, v19, v5
     9d4:      	fmla.4s	v22, v19, v4
     9d8:      	mov.16b	v4, v23
     9dc:      	fmla.4s	v4, v16, v17
     9e0:      	ldr	q17, [sp, #0x60]
     9e4:      	mov.16b	v5, v17
     9e8:      	fmla.4s	v5, v19, v22
     9ec:      	fmla.4s	v18, v16, v6
     9f0:      	mov.16b	v6, v17
     9f4:      	fmla.4s	v6, v16, v4
     9f8:      	ldp	q27, q22, [sp, #0x40]
     9fc:      	mov.16b	v17, v22
     a00:      	fmla.4s	v17, v19, v5
     a04:      	fmla.4s	v20, v19, v7
     a08:      	fmla.4s	v22, v16, v6
     a0c:      	movi.4s	v23, #0x3f, lsl #24
     a10:      	movi.4s	v24, #0x3f, lsl #24
     a14:      	mov.16b	v6, v0
     a18:      	ldr	q5, [sp, #0x110]
     a1c:      	fcmge.4s	v4, v5, v1
     a20:      	fmla.4s	v23, v19, v17
     a24:      	fcmge.4s	v5, v5, v2
     a28:      	and.16b	v7, v5, v2
     a2c:      	and.16b	v17, v4, v1
     a30:      	fcmge.4s	v26, v17, v27
     a34:      	fcmge.4s	v27, v7, v27
     a38:      	fcmge.4s	v28, v25, v7
     a3c:      	and.16b	v27, v27, v28
     a40:      	fcmge.4s	v28, v25, v17
     a44:      	and.16b	v26, v26, v28
     a48:      	and.16b	v26, v26, v17
     a4c:      	and.16b	v27, v27, v7
     a50:      	fmla.4s	v3, v19, v20
     a54:      	ldr	q28, [sp, #0x30]
     a58:      	fmul.4s	v20, v27, v28
     a5c:      	fmul.4s	v28, v26, v28
     a60:      	movi.4s	v29, #0x4b, lsl #24
     a64:      	fadd.4s	v28, v28, v29
     a68:      	fadd.4s	v20, v20, v29
     a6c:      	movi.4s	v29, #0xcb, lsl #24
     a70:      	fadd.4s	v20, v20, v29
     a74:      	fmla.4s	v6, v19, v23
     a78:      	fadd.4s	v19, v28, v29
     a7c:      	fcvtzs.4s	v19, v19
     a80:      	fcvtzs.4s	v20, v20
     a84:      	scvtf.4s	v23, v20
     a88:      	scvtf.4s	v28, v19
     a8c:      	fmla.4s	v24, v16, v22
     a90:      	ldr	q29, [sp, #0x20]
     a94:      	fmul.4s	v22, v23, v29
     a98:      	fadd.4s	v22, v27, v22
     a9c:      	fmul.4s	v27, v28, v29
     aa0:      	fadd.4s	v26, v26, v27
     aa4:      	mov.16b	v27, v0
     aa8:      	fmla.4s	v27, v16, v18
     aac:      	ldr	q29, [sp, #0x10]
     ab0:      	fmul.4s	v18, v28, v29
     ab4:      	fadd.4s	v18, v26, v18
     ab8:      	fmul.4s	v23, v23, v29
     abc:      	fadd.4s	v22, v22, v23
     ac0:      	mov.16b	v23, v0
     ac4:      	fmla.4s	v23, v16, v24
     ac8:      	ldr	q24, [sp]
     acc:      	fmul.4s	v16, v22, v24
     ad0:      	fmul.4s	v24, v18, v24
     ad4:      	fadd.4s	v24, v24, v30
     ad8:      	fadd.4s	v16, v16, v30
     adc:      	fmul.4s	v16, v22, v16
     ae0:      	fmul.4s	v26, v1, v27
     ae4:      	fmul.4s	v24, v18, v24
     ae8:      	fadd.4s	v24, v24, v31
     aec:      	fadd.4s	v16, v16, v31
     af0:      	fmul.4s	v16, v22, v16
     af4:      	fmul.4s	v24, v18, v24
     af8:      	fadd.4s	v24, v24, v8
     afc:      	fadd.4s	v16, v16, v8
     b00:      	fmul.4s	v16, v22, v16
     b04:      	fmul.4s	v24, v18, v24
     b08:      	fadd.4s	v24, v24, v21
     b0c:      	fadd.4s	v27, v16, v21
     b10:      	fdiv.4s	v16, v26, v23
     b14:      	fmul.4s	v23, v22, v27
     b18:      	fmul.4s	v24, v18, v24
     b1c:      	fadd.4s	v24, v24, v9
     b20:      	fadd.4s	v23, v23, v9
     b24:      	fmul.4s	v26, v22, v22
     b28:      	fmul.4s	v23, v26, v23
     b2c:      	fmul.4s	v26, v18, v18
     b30:      	fmul.4s	v24, v26, v24
     b34:      	fadd.4s	v18, v18, v24
     b38:      	fadd.4s	v22, v22, v23
     b3c:      	movi.2d	v26, #0xffffffffffffffff
     b40:      	add.4s	v19, v19, v26
     b44:      	fadd.4s	v18, v18, v0
     b48:      	sshr.4s	v23, v19, #0x1
     b4c:      	shl.4s	v24, v23, #0x17
     b50:      	add.4s	v24, v24, v0
     b54:      	fmul.4s	v18, v18, v24
     b58:      	add.4s	v20, v20, v26
     b5c:      	fadd.4s	v22, v22, v0
     b60:      	sub.4s	v19, v19, v23
     b64:      	sshr.4s	v23, v20, #0x1
     b68:      	sub.4s	v20, v20, v23
     b6c:      	shl.4s	v23, v23, #0x17
     b70:      	add.4s	v23, v23, v0
     b74:      	fmul.4s	v22, v22, v23
     b78:      	shl.4s	v20, v20, #0x17
     b7c:      	add.4s	v20, v20, v0
     b80:      	fmul.4s	v20, v22, v20
     b84:      	shl.4s	v19, v19, #0x17
     b88:      	add.4s	v19, v19, v0
     b8c:      	fmul.4s	v18, v18, v19
     b90:      	fcmgt.4s	v17, v17, v25
     b94:      	bsl.16b	v17, v13, v18
     b98:      	fmul.4s	v3, v2, v3
     b9c:      	fcmgt.4s	v7, v7, v25
     ba0:      	bsl.16b	v7, v13, v20
     ba4:      	fdiv.4s	v3, v3, v6
     ba8:      	ldr	q19, [sp, #0x120]
     bac:      	fdiv.4s	v6, v19, v7
     bb0:      	fsub.4s	v18, v7, v6
     bb4:      	fadd.4s	v6, v7, v6
     bb8:      	fdiv.4s	v6, v18, v6
     bbc:      	bsl.16b	v5, v6, v0
     bc0:      	fcmge.4s	v2, v0, v2
     bc4:      	bsl.16b	v2, v3, v5
     bc8:      	fdiv.4s	v3, v19, v17
     bcc:      	fsub.4s	v5, v17, v3
     bd0:      	fadd.4s	v3, v17, v3
     bd4:      	fdiv.4s	v3, v5, v3
     bd8:      	bif.16b	v3, v0, v4
     bdc:      	fcmge.4s	v1, v0, v1
     be0:      	bsl.16b	v1, v16, v3
     be4:      	mvni.4s	v4, #0x80, lsl #24
     be8:      	bif.16b	v1, v14, v4
     bec:      	fcmeq.4s	v3, v14, v14
     bf0:      	fadd.4s	v1, v1, v0
     bf4:      	bif.16b	v1, v15, v3
     bf8:      	bif.16b	v2, v12, v4
     bfc:      	fcmeq.4s	v3, v12, v12
     c00:      	fadd.4s	v2, v2, v0
     c04:      	bif.16b	v2, v15, v3
     c08:      	fmul.4s	v3, v11, v9
     c0c:      	fmul.4s	v2, v3, v2
     c10:      	fmul.4s	v3, v10, v9
     c14:      	fmul.4s	v1, v3, v1
     c18:      	add	x13, x10, x12
     c1c:      	ldp	q4, q3, [x13]
     c20:      	fadd.4s	v1, v4, v1
     c24:      	fadd.4s	v2, v3, v2
     c28:      	add	x12, x9, x12
     c2c:      	stp	q1, q2, [x12]
     c30:      	add	x8, x8, #0x1
     c34:      	cmp	x8, #0xc0
     c38:      	b.ne	0x924 <ltmp0+0x924>
     c3c:      	mov	w8, #0x1800             ; =6144
     c40:      	add	x20, x23, x8
     c44:      	add	x8, x22, x20
     c48:      	movi.2d	v2, #0000000000000000
     c4c:      	ld1.s	{ v2 }[0], [x8], #4
     c50:      	ld1.s	{ v2 }[1], [x8]
     c54:      	movi.2d	v1, #0000000000000000
     c58:      	mov	w8, #0x2713             ; =10003
     c5c:      	movk	w8, #0x3d37, lsl #16
     c60:      	dup.4s	v3, w8
     c64:      	fmul.4s	v3, v2, v3
     c68:      	fmul.4s	v3, v2, v3
     c6c:      	fmul.4s	v3, v2, v3
     c70:      	fadd.4s	v3, v2, v3
     c74:      	mov	w8, #0x422a             ; =16938
     c78:      	movk	w8, #0x3f4c, lsl #16
     c7c:      	dup.4s	v4, w8
     c80:      	fmul.4s	v3, v3, v4
     c84:      	mov.d	v1[0], v3[0]
     c88:      	fabs.4s	v3, v1
     c8c:      	mov	w8, #0x9231             ; =37425
     c90:      	movk	w8, #0x2f30, lsl #16
     c94:      	dup.4s	v5, w8
     c98:      	fmul.4s	v4, v1, v1
     c9c:      	mov	w8, #0x322b             ; =12843
     ca0:      	movk	w8, #0x32d7, lsl #16
     ca4:      	dup.4s	v6, w8
     ca8:      	fmla.4s	v6, v4, v5
     cac:      	mov	w8, #0xef1d             ; =61213
     cb0:      	movk	w8, #0x3638, lsl #16
     cb4:      	dup.4s	v5, w8
     cb8:      	fmla.4s	v5, v4, v6
     cbc:      	mov	w8, #0xd01              ; =3329
     cc0:      	movk	w8, #0x3950, lsl #16
     cc4:      	dup.4s	v6, w8
     cc8:      	fmla.4s	v6, v4, v5
     ccc:      	mov	w8, #0x8889             ; =34953
     cd0:      	movk	w8, #0x3c08, lsl #16
     cd4:      	dup.4s	v16, w8
     cd8:      	fmla.4s	v16, v4, v6
     cdc:      	mov	w8, #0xaaab             ; =43691
     ce0:      	movk	w8, #0x3e2a, lsl #16
     ce4:      	dup.4s	v17, w8
     ce8:      	ldr	q5, [sp, #0x110]
     cec:      	fcmge.4s	v5, v5, v3
     cf0:      	mov	w8, #-0x3d300000        ; =-1026555904
     cf4:      	dup.4s	v7, w8
     cf8:      	and.16b	v6, v5, v3
     cfc:      	fcmge.4s	v18, v6, v7
     d00:      	mov	w8, #0x42c80000         ; =1120403456
     d04:      	dup.4s	v7, w8
     d08:      	fcmge.4s	v19, v7, v6
     d0c:      	and.16b	v18, v18, v19
     d10:      	and.16b	v18, v18, v6
     d14:      	mov	w8, #0xaa3b             ; =43579
     d18:      	movk	w8, #0x3fb8, lsl #16
     d1c:      	dup.4s	v19, w8
     d20:      	fmul.4s	v19, v18, v19
     d24:      	movi.4s	v20, #0x4b, lsl #24
     d28:      	fadd.4s	v19, v19, v20
     d2c:      	movi.4s	v20, #0xcb, lsl #24
     d30:      	fadd.4s	v19, v19, v20
     d34:      	fcvtzs.4s	v19, v19
     d38:      	scvtf.4s	v20, v19
     d3c:      	mov	w8, #0x7200             ; =29184
     d40:      	movk	w8, #0xbf31, lsl #16
     d44:      	dup.4s	v21, w8
     d48:      	fmul.4s	v21, v20, v21
     d4c:      	fadd.4s	v18, v18, v21
     d50:      	mov	w8, #0xbe8e             ; =48782
     d54:      	movk	w8, #0xb5bf, lsl #16
     d58:      	dup.4s	v21, w8
     d5c:      	fmul.4s	v20, v20, v21
     d60:      	mov	w8, #0x2bda             ; =11226
     d64:      	movk	w8, #0x3950, lsl #16
     d68:      	dup.4s	v21, w8
     d6c:      	fadd.4s	v18, v18, v20
     d70:      	fmul.4s	v20, v18, v21
     d74:      	mov	w8, #0x96c9             ; =38601
     d78:      	movk	w8, #0x3ab6, lsl #16
     d7c:      	dup.4s	v21, w8
     d80:      	fadd.4s	v20, v20, v21
     d84:      	fmul.4s	v20, v18, v20
     d88:      	mov	w8, #0x88a6             ; =34982
     d8c:      	movk	w8, #0x3c08, lsl #16
     d90:      	dup.4s	v21, w8
     d94:      	fadd.4s	v20, v20, v21
     d98:      	fmul.4s	v20, v18, v20
     d9c:      	mov	w8, #0xaa7a             ; =43642
     da0:      	movk	w8, #0x3d2a, lsl #16
     da4:      	dup.4s	v21, w8
     da8:      	fadd.4s	v20, v20, v21
     dac:      	fmul.4s	v20, v18, v20
     db0:      	fadd.4s	v20, v20, v17
     db4:      	fmla.4s	v17, v4, v16
     db8:      	mov.16b	v16, v0
     dbc:      	mov	w8, #0x76c7             ; =30407
     dc0:      	movk	w8, #0x310f, lsl #16
     dc4:      	dup.4s	v21, w8
     dc8:      	fmla.4s	v16, v4, v17
     dcc:      	mov	w8, #0xf27e             ; =62078
     dd0:      	movk	w8, #0x3493, lsl #16
     dd4:      	dup.4s	v17, w8
     dd8:      	fmla.4s	v17, v4, v21
     ddc:      	mov	w8, #0xd01              ; =3329
     de0:      	movk	w8, #0x37d0, lsl #16
     de4:      	dup.4s	v21, w8
     de8:      	fmla.4s	v21, v4, v17
     dec:      	mov	w8, #0xb61              ; =2913
     df0:      	movk	w8, #0x3ab6, lsl #16
     df4:      	dup.4s	v17, w8
     df8:      	fmla.4s	v17, v4, v21
     dfc:      	mov	w8, #0xaaab             ; =43691
     e00:      	movk	w8, #0x3d2a, lsl #16
     e04:      	dup.4s	v21, w8
     e08:      	fmla.4s	v21, v4, v17
     e0c:      	movi.4s	v17, #0x3f, lsl #24
     e10:      	fmla.4s	v17, v4, v21
     e14:      	mov.16b	v21, v0
     e18:      	fmla.4s	v21, v4, v17
     e1c:      	movi.4s	v4, #0x3f, lsl #24
     e20:      	fmul.4s	v2, v2, v4
     e24:      	fcmge.4s	v17, v0, v3
     e28:      	fmul.4s	v3, v3, v16
     e2c:      	fdiv.4s	v3, v3, v21
     e30:      	fmul.4s	v16, v18, v20
     e34:      	fadd.4s	v4, v16, v4
     e38:      	fmul.4s	v16, v18, v18
     e3c:      	fmul.4s	v4, v16, v4
     e40:      	fadd.4s	v4, v18, v4
     e44:      	fadd.4s	v4, v4, v0
     e48:      	movi.2d	v16, #0xffffffffffffffff
     e4c:      	add.4s	v16, v19, v16
     e50:      	sshr.4s	v18, v16, #0x1
     e54:      	shl.4s	v19, v18, #0x17
     e58:      	add.4s	v19, v19, v0
     e5c:      	fmul.4s	v4, v4, v19
     e60:      	sub.4s	v16, v16, v18
     e64:      	shl.4s	v16, v16, #0x17
     e68:      	add.4s	v16, v16, v0
     e6c:      	fmul.4s	v4, v4, v16
     e70:      	fcmgt.4s	v6, v6, v7
     e74:      	mvni.4s	v7, #0x7f, msl #16
     e78:      	fneg.4s	v7, v7
     e7c:      	bit.16b	v4, v7, v6
     e80:      	ldr	q6, [sp, #0x120]
     e84:      	fdiv.4s	v6, v6, v4
     e88:      	fsub.4s	v7, v4, v6
     e8c:      	fadd.4s	v4, v4, v6
     e90:      	fdiv.4s	v4, v7, v4
     e94:      	bif.16b	v4, v0, v5
     e98:      	bif.16b	v3, v4, v17
     e9c:      	mvni.4s	v4, #0x80, lsl #24
     ea0:      	bif.16b	v3, v1, v4
     ea4:      	fcmeq.4s	v1, v1, v1
     ea8:      	fadd.4s	v0, v3, v0
     eac:      	mvni.4s	v3, #0x3f, msl #16
     eb0:      	fneg.4s	v3, v3
     eb4:      	bif.16b	v0, v3, v1
     eb8:      	fmul.4s	v0, v2, v0
     ebc:      	add	x8, x21, x20
     ec0:      	add	x9, x8, #0x4
     ec4:      	ldr	s1, [x8]
     ec8:      	ld1.s	{ v1 }[1], [x9]
     ecc:      	fadd.4s	v0, v1, v0
     ed0:      	str	d0, [x19, x20]
     ed4:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
     ed8:      	add	sp, sp, #0x170
     edc:      	ldp	x29, x30, [sp, #0x80]
     ee0:      	ldp	x20, x19, [sp, #0x70]
     ee4:      	ldp	x22, x21, [sp, #0x60]
     ee8:      	ldp	x24, x23, [sp, #0x50]
     eec:      	ldp	x28, x27, [sp, #0x40]
     ef0:      	ldp	d9, d8, [sp, #0x30]
     ef4:      	ldp	d11, d10, [sp, #0x20]
     ef8:      	ldp	d13, d12, [sp, #0x10]
     efc:      	ldp	d15, d14, [sp], #0x90
     f00:      	ret

0000000000000f04 <_llm_rows.packet_batch.blocks>:
     f04:      	stp	d15, d14, [sp, #-0xa0]!
     f08:      	stp	d13, d12, [sp, #0x10]
     f0c:      	stp	d11, d10, [sp, #0x20]
     f10:      	stp	d9, d8, [sp, #0x30]
     f14:      	stp	x28, x27, [sp, #0x40]
     f18:      	stp	x26, x25, [sp, #0x50]
     f1c:      	stp	x24, x23, [sp, #0x60]
     f20:      	stp	x22, x21, [sp, #0x70]
     f24:      	stp	x20, x19, [sp, #0x80]
     f28:      	stp	x29, x30, [sp, #0x90]
     f2c:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
     f30:      	sub	sp, sp, #0x3f0
     f34:      	str	x0, [sp, #0x118]
     f38:      	cbz	w3, 0x2aac <_llm_rows.packet_batch.blocks+0x1ba8>
     f3c:      	mov	x19, x3
     f40:      	mov	x20, x2
     f44:      	mov	w22, #0x0               ; =0
     f48:      	adrp	x8, 0x0 <ltmp0>
     f4c:      	ldr	q0, [x8]
     f50:      	str	q0, [sp, #0x90]
     f54:      	adrp	x8, 0x0 <ltmp0>
     f58:      	ldr	q0, [x8]
     f5c:      	str	q0, [sp, #0x80]
     f60:      	adrp	x8, 0x0 <ltmp0>
     f64:      	ldr	q0, [x8]
     f68:      	str	q0, [sp, #0x70]
     f6c:      	adrp	x8, 0x0 <ltmp0>
     f70:      	ldr	q0, [x8]
     f74:      	str	q0, [sp, #0x60]
     f78:      	adrp	x8, 0x0 <ltmp0>
     f7c:      	ldr	q0, [x8]
     f80:      	str	q0, [sp, #0x50]
     f84:      	adrp	x8, 0x0 <ltmp0>
     f88:      	ldr	q0, [x8]
     f8c:      	str	q0, [sp, #0x40]
     f90:      	adrp	x8, 0x0 <ltmp0>
     f94:      	ldr	q0, [x8]
     f98:      	str	q0, [sp, #0x120]
     f9c:      	movi.4s	v21, #0x3f, lsl #24
     fa0:      	mvni.4s	v0, #0x7f, msl #16
     fa4:      	fneg.4s	v1, v0
     fa8:      	mvni.4s	v0, #0x3f, msl #16
     fac:      	fneg.4s	v0, v0
     fb0:      	stp	q0, q1, [sp, #0x170]
     fb4:      	ldp	w9, w8, [x2, #0x2c]
     fb8:      	str	w9, [sp, #0x114]
     fbc:      	str	w8, [sp, #0x110]
     fc0:      	ldp	w25, w23, [x2]
     fc4:      	add	x24, sp, #0x1, lsl #12  ; =0x1000
     fc8:      	add	x24, x24, #0xbd0
     fcc:      	ldp	w27, w28, [x2, #0x8]
     fd0:      	add	x26, sp, #0x3b0
     fd4:      	str	w3, [sp, #0x10c]
     fd8:      	b	0x1024 <_llm_rows.packet_batch.blocks+0x120>
     fdc:      	mov	w8, #0x18               ; =24
     fe0:      	str	w8, [x20, #0x24]
     fe4:      	ldr	w19, [sp, #0x10c]
     fe8:      	add	w8, w25, #0x1
     fec:      	ldr	w9, [sp, #0x114]
     ff0:      	cmp	w8, w9
     ff4:      	cset	w8, eq
     ff8:      	csinc	w25, wzr, w25, eq
     ffc:      	cinc	w9, w23, eq
    1000:      	ldr	w10, [sp, #0x110]
    1004:      	cmp	w9, w10
    1008:      	cset	w10, eq
    100c:      	ands	w8, w8, w10
    1010:      	csel	w23, wzr, w9, ne
    1014:      	add	w27, w27, w8
    1018:      	add	w22, w22, #0x1
    101c:      	cmp	w22, w19
    1020:      	b.eq	0x2aac <_llm_rows.packet_batch.blocks+0x1ba8>
    1024:      	ubfiz	x8, x25, #5, #32
    1028:      	cmp	x8, x28
    102c:      	csel	x9, x8, xzr, ls
    1030:      	subs	x10, x28, x9
    1034:      	cmp	x10, #0x20
    1038:      	mov	w11, #0x20              ; =32
    103c:      	csel	x10, x10, x11, lo
    1040:      	cmp	x28, x9
    1044:      	stp	w25, w23, [x20]
    1048:      	str	w27, [x20, #0x8]
    104c:      	str	wzr, [x20, #0x24]
    1050:      	ccmp	x8, x28, #0x2, hi
    1054:      	csel	x21, x10, xzr, ls
    1058:      	cmp	x21, #0x20
    105c:      	b.lo	0x10b4 <_llm_rows.packet_batch.blocks+0x1b0>
    1060:      	ldr	x21, [sp, #0x118]
    1064:      	mov	x0, x21
    1068:      	mov	x1, x20
    106c:      	bl	0x106c <_llm_rows.packet_batch.blocks+0x168>
    1070:      	mov	w8, #0x8                ; =8
    1074:      	str	w8, [x20, #0x24]
    1078:      	mov	x0, x21
    107c:      	mov	x1, x20
    1080:      	bl	0x1080 <_llm_rows.packet_batch.blocks+0x17c>
    1084:      	mov	w8, #0x10               ; =16
    1088:      	str	w8, [x20, #0x24]
    108c:      	mov	x0, x21
    1090:      	mov	x1, x20
    1094:      	bl	0x1094 <_llm_rows.packet_batch.blocks+0x190>
    1098:      	mov	w8, #0x18               ; =24
    109c:      	str	w8, [x20, #0x24]
    10a0:      	mov	x0, x21
    10a4:      	mov	x1, x20
    10a8:      	bl	0x10a8 <_llm_rows.packet_batch.blocks+0x1a4>
    10ac:      	movi.4s	v21, #0x3f, lsl #24
    10b0:      	b	0xfe8 <_llm_rows.packet_batch.blocks+0xe4>
    10b4:      	lsr	x19, x21, #3
    10b8:      	cmp	x21, #0x8
    10bc:      	b.lo	0x1114 <_llm_rows.packet_batch.blocks+0x210>
    10c0:      	str	wzr, [x20, #0x24]
    10c4:      	ldr	x0, [sp, #0x118]
    10c8:      	mov	x1, x20
    10cc:      	bl	0x10cc <_llm_rows.packet_batch.blocks+0x1c8>
    10d0:      	movi.4s	v21, #0x3f, lsl #24
    10d4:      	cmp	x19, #0x1
    10d8:      	b.eq	0x1114 <_llm_rows.packet_batch.blocks+0x210>
    10dc:      	mov	w8, #0x8                ; =8
    10e0:      	str	w8, [x20, #0x24]
    10e4:      	ldr	x0, [sp, #0x118]
    10e8:      	mov	x1, x20
    10ec:      	bl	0x10ec <_llm_rows.packet_batch.blocks+0x1e8>
    10f0:      	movi.4s	v21, #0x3f, lsl #24
    10f4:      	cmp	x19, #0x2
    10f8:      	b.eq	0x1114 <_llm_rows.packet_batch.blocks+0x210>
    10fc:      	mov	w8, #0x10               ; =16
    1100:      	str	w8, [x20, #0x24]
    1104:      	ldr	x0, [sp, #0x118]
    1108:      	mov	x1, x20
    110c:      	bl	0x110c <_llm_rows.packet_batch.blocks+0x208>
    1110:      	movi.4s	v21, #0x3f, lsl #24
    1114:      	and	w8, w21, #0x7
    1118:      	cbz	w8, 0xfdc <_llm_rows.packet_batch.blocks+0xd8>
    111c:      	dup.4s	v0, w8
    1120:      	ldp	q2, q1, [sp, #0x80]
    1124:      	cmhi.4s	v10, v0, v2
    1128:      	cmhi.4s	v11, v0, v1
    112c:      	uzp1.8h	v0, v11, v10
    1130:      	mov.16b	v26, v0
    1134:      	umaxv.8h	h0, v0
    1138:      	fmov	w8, s0
    113c:      	tbz	w8, #0x0, 0xfdc <_llm_rows.packet_batch.blocks+0xd8>
    1140:      	ldr	x8, [sp, #0x118]
    1144:      	ldr	x11, [x8]
    1148:      	ldr	x9, [x8, #0x10]
    114c:      	xtn.4h	v0, v11
    1150:      	uzp1.8b	v0, v0, v0
    1154:      	ldr	x8, [x8, #0x30]
    1158:      	sshll.2d	v1, v11, #0x0
    115c:      	sshll.2d	v2, v10, #0x0
    1160:      	sshll2.2d	v15, v11, #0x0
    1164:      	sshll2.2d	v14, v10, #0x0
    1168:      	ldp	q3, q5, [sp, #0x60]
    116c:      	and.16b	v4, v14, v5
    1170:      	and.16b	v5, v15, v3
    1174:      	ldp	q3, q6, [sp, #0x40]
    1178:      	and.16b	v2, v2, v6
    117c:      	stp	q5, q2, [sp, #0x140]
    1180:      	ubfiz	w10, w25, #2, #27
    1184:      	orr	w12, w10, w19
    1188:      	dup.4s	v2, w12
    118c:      	and.16b	v1, v1, v3
    1190:      	stp	q4, q1, [sp, #0xb0]
    1194:      	and.16b	v1, v11, v2
    1198:      	and.16b	v5, v10, v2
    119c:      	ushll2.2d	v4, v5, #0x0
    11a0:      	ushll2.2d	v2, v1, #0x0
    11a4:      	subs	x10, x11, x8
    11a8:      	mov	w15, #0x2007            ; =8199
    11ac:      	movk	w15, #0x18, lsl #16
    11b0:      	ccmp	x10, x15, #0x0, hs
    11b4:      	cset	w10, hi
    11b8:      	mov	w13, #0x2713            ; =10003
    11bc:      	movk	w13, #0x3d37, lsl #16
    11c0:      	dup.4s	v6, w13
    11c4:      	mov	w13, #0x422a            ; =16938
    11c8:      	movk	w13, #0x3f4c, lsl #16
    11cc:      	dup.4s	v3, w13
    11d0:      	stp	q6, q3, [sp, #0x190]
    11d4:      	subs	x13, x8, x11
    11d8:      	ccmp	x13, x15, #0x0, hs
    11dc:      	mov	w13, #0x9231            ; =37425
    11e0:      	movk	w13, #0x2f30, lsl #16
    11e4:      	dup.4s	v6, w13
    11e8:      	mov	w13, #0x322b            ; =12843
    11ec:      	movk	w13, #0x32d7, lsl #16
    11f0:      	dup.4s	v3, w13
    11f4:      	stp	q6, q3, [sp, #0x1b0]
    11f8:      	csinc	w14, w10, wzr, ls
    11fc:      	subs	x10, x9, x8
    1200:      	mov	w13, #0xef1d            ; =61213
    1204:      	movk	w13, #0x3638, lsl #16
    1208:      	dup.4s	v6, w13
    120c:      	mov	w13, #0xd01             ; =3329
    1210:      	movk	w13, #0x3950, lsl #16
    1214:      	dup.4s	v3, w13
    1218:      	stp	q6, q3, [sp, #0x1d0]
    121c:      	ccmp	x10, x15, #0x0, hs
    1220:      	cset	w10, hi
    1224:      	mov	w13, #0x8889            ; =34953
    1228:      	movk	w13, #0x3c08, lsl #16
    122c:      	dup.4s	v3, w13
    1230:      	str	q3, [sp, #0x1f0]
    1234:      	mov	w13, #0xaaab            ; =43691
    1238:      	movk	w13, #0x3e2a, lsl #16
    123c:      	dup.4s	v3, w13
    1240:      	subs	x13, x8, x9
    1244:      	ccmp	x13, x15, #0x0, hs
    1248:      	umov.b	w13, v0[0]
    124c:      	mov	w15, #0x76c7            ; =30407
    1250:      	movk	w15, #0x310f, lsl #16
    1254:      	dup.4s	v7, w15
    1258:      	ushll.2d	v5, v5, #0x0
    125c:      	ushll.2d	v6, v1, #0x0
    1260:      	csinc	w10, w10, wzr, ls
    1264:      	mov	w15, #0x1808            ; =6152
    1268:      	umull	x12, w12, w15
    126c:      	tst	w13, #0x1
    1270:      	csel	x12, x12, xzr, ne
    1274:      	mov	w15, #0xf27e            ; =62078
    1278:      	movk	w15, #0x3493, lsl #16
    127c:      	dup.4s	v0, w15
    1280:      	stp	q0, q7, [sp, #0x200]
    1284:      	mov	w15, #0xd01             ; =3329
    1288:      	movk	w15, #0x37d0, lsl #16
    128c:      	dup.4s	v23, w15
    1290:      	mov	w15, #0xb61             ; =2913
    1294:      	movk	w15, #0x3ab6, lsl #16
    1298:      	dup.4s	v7, w15
    129c:      	fmov.4s	v0, #1.00000000
    12a0:      	mov	w15, #0xaaab            ; =43691
    12a4:      	movk	w15, #0x3d2a, lsl #16
    12a8:      	dup.4s	v1, w15
    12ac:      	stp	q7, q1, [sp, #0x220]
    12b0:      	fmov.4s	v20, #9.00000000
    12b4:      	mov	w15, #-0x3d300000       ; =-1026555904
    12b8:      	dup.4s	v30, w15
    12bc:      	mov	w15, #0x42c80000        ; =1120403456
    12c0:      	dup.4s	v1, w15
    12c4:      	mov	w15, #0xaa3b            ; =43579
    12c8:      	movk	w15, #0x3fb8, lsl #16
    12cc:      	dup.4s	v29, w15
    12d0:      	mov	w15, #0x7200            ; =29184
    12d4:      	movk	w15, #0xbf31, lsl #16
    12d8:      	dup.4s	v9, w15
    12dc:      	mov	w15, #0xbe8e            ; =48782
    12e0:      	movk	w15, #0xb5bf, lsl #16
    12e4:      	dup.4s	v28, w15
    12e8:      	mov	w15, #0x2bda            ; =11226
    12ec:      	movk	w15, #0x3950, lsl #16
    12f0:      	dup.4s	v24, w15
    12f4:      	mov	w15, #0x96c9            ; =38601
    12f8:      	movk	w15, #0x3ab6, lsl #16
    12fc:      	dup.4s	v22, w15
    1300:      	xtn.2s	v6, v6
    1304:      	str	d6, [sp, #0xa0]
    1308:      	xtn.2s	v4, v4
    130c:      	str	d4, [sp, #0xf0]
    1310:      	xtn.2s	v4, v5
    1314:      	str	d4, [sp, #0xe0]
    1318:      	xtn.2s	v2, v2
    131c:      	str	d2, [sp, #0xd0]
    1320:      	mov	w15, #0x88a6            ; =34982
    1324:      	movk	w15, #0x3c08, lsl #16
    1328:      	dup.4s	v27, w15
    132c:      	mov	w15, #0xaa7a            ; =43642
    1330:      	movk	w15, #0x3d2a, lsl #16
    1334:      	dup.4s	v25, w15
    1338:      	fmov.4s	v31, #0.25000000
    133c:      	mov	w15, #0x602             ; =1538
    1340:      	dup.2s	v2, w15
    1344:      	str	d2, [sp, #0x130]
    1348:      	cmp	w14, #0x1
    134c:      	str	q23, [sp, #0x160]
    1350:      	b.ne	0x1840 <_llm_rows.packet_batch.blocks+0x93c>
    1354:      	cbz	w10, 0x1840 <_llm_rows.packet_batch.blocks+0x93c>
    1358:      	mov	x10, #0x0               ; =0
    135c:      	add	x13, x8, x12
    1360:      	add	x14, x9, x12
    1364:      	add	x12, x11, x12
    1368:      	ldr	q2, [sp, #0x120]
    136c:      	and.16b	v2, v26, v2
    1370:      	addv.8h	h12, v2
    1374:      	fmov	w15, s12
    1378:      	b	0x1388 <_llm_rows.packet_batch.blocks+0x484>
    137c:      	add	x10, x10, #0x1
    1380:      	cmp	x10, #0xc0
    1384:      	b.eq	0x250c <_llm_rows.packet_batch.blocks+0x1608>
    1388:      	add	x16, x12, x10, lsl #5
    138c:      	movi.2d	v15, #0000000000000000
    1390:      	movi.2d	v14, #0000000000000000
    1394:      	tbz	w15, #0x0, 0x1428 <_llm_rows.packet_batch.blocks+0x524>
    1398:      	ldr	s15, [x16]
    139c:      	and	w17, w15, #0xff
    13a0:      	tbnz	w17, #0x1, 0x1430 <_llm_rows.packet_batch.blocks+0x52c>
    13a4:      	tbz	w17, #0x2, 0x143c <_llm_rows.packet_batch.blocks+0x538>
    13a8:      	add	x0, x16, #0x8
    13ac:      	ld1.s	{ v15 }[2], [x0]
    13b0:      	tbnz	w17, #0x3, 0x1440 <_llm_rows.packet_batch.blocks+0x53c>
    13b4:      	tbz	w17, #0x4, 0x144c <_llm_rows.packet_batch.blocks+0x548>
    13b8:      	add	x0, x16, #0x10
    13bc:      	ld1.s	{ v14 }[0], [x0]
    13c0:      	tbnz	w17, #0x5, 0x1450 <_llm_rows.packet_batch.blocks+0x54c>
    13c4:      	tbz	w17, #0x6, 0x145c <_llm_rows.packet_batch.blocks+0x558>
    13c8:      	add	x0, x16, #0x18
    13cc:      	ld1.s	{ v14 }[2], [x0]
    13d0:      	tbnz	w17, #0x7, 0x1460 <_llm_rows.packet_batch.blocks+0x55c>
    13d4:      	fmov	w17, s12
    13d8:      	add	x16, x14, x10, lsl #5
    13dc:      	movi.2d	v2, #0000000000000000
    13e0:      	movi.2d	v8, #0000000000000000
    13e4:      	tbz	w17, #0x0, 0x147c <_llm_rows.packet_batch.blocks+0x578>
    13e8:      	ldr	s2, [x16]
    13ec:      	and	w17, w17, #0xff
    13f0:      	tbnz	w17, #0x1, 0x1484 <_llm_rows.packet_batch.blocks+0x580>
    13f4:      	tbz	w17, #0x2, 0x1490 <_llm_rows.packet_batch.blocks+0x58c>
    13f8:      	add	x0, x16, #0x8
    13fc:      	ld1.s	{ v2 }[2], [x0]
    1400:      	tbnz	w17, #0x3, 0x1494 <_llm_rows.packet_batch.blocks+0x590>
    1404:      	tbz	w17, #0x4, 0x14a0 <_llm_rows.packet_batch.blocks+0x59c>
    1408:      	add	x0, x16, #0x10
    140c:      	ld1.s	{ v8 }[0], [x0]
    1410:      	tbnz	w17, #0x5, 0x14a4 <_llm_rows.packet_batch.blocks+0x5a0>
    1414:      	tbz	w17, #0x6, 0x14b0 <_llm_rows.packet_batch.blocks+0x5ac>
    1418:      	add	x0, x16, #0x18
    141c:      	ld1.s	{ v8 }[2], [x0]
    1420:      	tbnz	w17, #0x7, 0x14b4 <_llm_rows.packet_batch.blocks+0x5b0>
    1424:      	b	0x14bc <_llm_rows.packet_batch.blocks+0x5b8>
    1428:      	and	w17, w15, #0xff
    142c:      	tbz	w17, #0x1, 0x13a4 <_llm_rows.packet_batch.blocks+0x4a0>
    1430:      	add	x0, x16, #0x4
    1434:      	ld1.s	{ v15 }[1], [x0]
    1438:      	tbnz	w17, #0x2, 0x13a8 <_llm_rows.packet_batch.blocks+0x4a4>
    143c:      	tbz	w17, #0x3, 0x13b4 <_llm_rows.packet_batch.blocks+0x4b0>
    1440:      	add	x0, x16, #0xc
    1444:      	ld1.s	{ v15 }[3], [x0]
    1448:      	tbnz	w17, #0x4, 0x13b8 <_llm_rows.packet_batch.blocks+0x4b4>
    144c:      	tbz	w17, #0x5, 0x13c4 <_llm_rows.packet_batch.blocks+0x4c0>
    1450:      	add	x0, x16, #0x14
    1454:      	ld1.s	{ v14 }[1], [x0]
    1458:      	tbnz	w17, #0x6, 0x13c8 <_llm_rows.packet_batch.blocks+0x4c4>
    145c:      	tbz	w17, #0x7, 0x13d4 <_llm_rows.packet_batch.blocks+0x4d0>
    1460:      	add	x16, x16, #0x1c
    1464:      	ld1.s	{ v14 }[3], [x16]
    1468:      	fmov	w17, s12
    146c:      	add	x16, x14, x10, lsl #5
    1470:      	movi.2d	v2, #0000000000000000
    1474:      	movi.2d	v8, #0000000000000000
    1478:      	tbnz	w17, #0x0, 0x13e8 <_llm_rows.packet_batch.blocks+0x4e4>
    147c:      	and	w17, w17, #0xff
    1480:      	tbz	w17, #0x1, 0x13f4 <_llm_rows.packet_batch.blocks+0x4f0>
    1484:      	add	x0, x16, #0x4
    1488:      	ld1.s	{ v2 }[1], [x0]
    148c:      	tbnz	w17, #0x2, 0x13f8 <_llm_rows.packet_batch.blocks+0x4f4>
    1490:      	tbz	w17, #0x3, 0x1404 <_llm_rows.packet_batch.blocks+0x500>
    1494:      	add	x0, x16, #0xc
    1498:      	ld1.s	{ v2 }[3], [x0]
    149c:      	tbnz	w17, #0x4, 0x1408 <_llm_rows.packet_batch.blocks+0x504>
    14a0:      	tbz	w17, #0x5, 0x1414 <_llm_rows.packet_batch.blocks+0x510>
    14a4:      	add	x0, x16, #0x14
    14a8:      	ld1.s	{ v8 }[1], [x0]
    14ac:      	tbnz	w17, #0x6, 0x1418 <_llm_rows.packet_batch.blocks+0x514>
    14b0:      	tbz	w17, #0x7, 0x14bc <_llm_rows.packet_batch.blocks+0x5b8>
    14b4:      	add	x16, x16, #0x1c
    14b8:      	ld1.s	{ v8 }[3], [x16]
    14bc:      	ldp	q4, q5, [sp, #0x190]
    14c0:      	fmul.4s	v4, v15, v4
    14c4:      	fmul.4s	v4, v15, v4
    14c8:      	fmul.4s	v4, v15, v4
    14cc:      	fadd.4s	v4, v15, v4
    14d0:      	fmul.4s	v4, v4, v5
    14d4:      	and.16b	v4, v11, v4
    14d8:      	fabs.4s	v5, v4
    14dc:      	fmul.4s	v6, v4, v4
    14e0:      	ldp	q16, q7, [sp, #0x1b0]
    14e4:      	fmla.4s	v7, v6, v16
    14e8:      	ldr	q16, [sp, #0x1d0]
    14ec:      	fmla.4s	v16, v6, v7
    14f0:      	ldr	q7, [sp, #0x1e0]
    14f4:      	fmla.4s	v7, v6, v16
    14f8:      	ldr	q16, [sp, #0x1f0]
    14fc:      	fmla.4s	v16, v6, v7
    1500:      	mov.16b	v7, v3
    1504:      	fmla.4s	v7, v6, v16
    1508:      	mov.16b	v16, v0
    150c:      	fmla.4s	v16, v6, v7
    1510:      	fmul.4s	v7, v5, v16
    1514:      	ldp	q16, q17, [sp, #0x200]
    1518:      	fmla.4s	v16, v6, v17
    151c:      	mov.16b	v17, v23
    1520:      	fmla.4s	v17, v6, v16
    1524:      	ldr	q16, [sp, #0x220]
    1528:      	fmla.4s	v16, v6, v17
    152c:      	ldr	q17, [sp, #0x230]
    1530:      	fmla.4s	v17, v6, v16
    1534:      	movi.4s	v16, #0x3f, lsl #24
    1538:      	fmla.4s	v16, v6, v17
    153c:      	mov.16b	v17, v0
    1540:      	fmla.4s	v17, v6, v16
    1544:      	fdiv.4s	v6, v7, v17
    1548:      	fcmge.4s	v7, v20, v5
    154c:      	and.16b	v16, v7, v5
    1550:      	fcmge.4s	v17, v16, v30
    1554:      	fcmge.4s	v18, v1, v16
    1558:      	and.16b	v17, v17, v18
    155c:      	and.16b	v17, v17, v16
    1560:      	fmul.4s	v18, v17, v29
    1564:      	movi.4s	v19, #0x4b, lsl #24
    1568:      	fadd.4s	v18, v18, v19
    156c:      	movi.4s	v19, #0xcb, lsl #24
    1570:      	fadd.4s	v18, v18, v19
    1574:      	fcvtzs.4s	v18, v18
    1578:      	scvtf.4s	v13, v18
    157c:      	fmul.4s	v19, v13, v9
    1580:      	fadd.4s	v17, v17, v19
    1584:      	fmul.4s	v19, v13, v28
    1588:      	fadd.4s	v17, v17, v19
    158c:      	fmul.4s	v19, v17, v24
    1590:      	fadd.4s	v19, v19, v22
    1594:      	fmul.4s	v19, v17, v19
    1598:      	fadd.4s	v19, v19, v27
    159c:      	fmul.4s	v19, v17, v19
    15a0:      	fadd.4s	v19, v19, v25
    15a4:      	fmul.4s	v19, v17, v19
    15a8:      	fadd.4s	v19, v19, v3
    15ac:      	fmul.4s	v19, v17, v19
    15b0:      	fadd.4s	v19, v19, v21
    15b4:      	fmul.4s	v13, v17, v17
    15b8:      	fmul.4s	v19, v13, v19
    15bc:      	fadd.4s	v17, v17, v19
    15c0:      	fadd.4s	v17, v17, v0
    15c4:      	movi.2d	v19, #0xffffffffffffffff
    15c8:      	add.4s	v18, v18, v19
    15cc:      	sshr.4s	v19, v18, #0x1
    15d0:      	shl.4s	v13, v19, #0x17
    15d4:      	add.4s	v13, v13, v0
    15d8:      	fmul.4s	v17, v17, v13
    15dc:      	sub.4s	v18, v18, v19
    15e0:      	shl.4s	v18, v18, #0x17
    15e4:      	add.4s	v18, v18, v0
    15e8:      	fmul.4s	v17, v17, v18
    15ec:      	fcmgt.4s	v16, v16, v1
    15f0:      	ldr	q18, [sp, #0x180]
    15f4:      	bsl.16b	v16, v18, v17
    15f8:      	fdiv.4s	v17, v31, v16
    15fc:      	fsub.4s	v18, v16, v17
    1600:      	fadd.4s	v16, v16, v17
    1604:      	fdiv.4s	v16, v18, v16
    1608:      	bsl.16b	v7, v16, v0
    160c:      	fcmge.4s	v5, v0, v5
    1610:      	bsl.16b	v5, v6, v7
    1614:      	mvni.4s	v6, #0x80, lsl #24
    1618:      	bif.16b	v5, v4, v6
    161c:      	fcmeq.4s	v4, v4, v4
    1620:      	fadd.4s	v5, v5, v0
    1624:      	ldr	q6, [sp, #0x170]
    1628:      	bsl.16b	v4, v5, v6
    162c:      	fmul.4s	v5, v15, v21
    1630:      	fmul.4s	v4, v5, v4
    1634:      	fadd.4s	v2, v2, v4
    1638:      	fmov	w17, s12
    163c:      	add	x16, x13, x10, lsl #5
    1640:      	tbz	w17, #0x0, 0x1664 <_llm_rows.packet_batch.blocks+0x760>
    1644:      	str	s2, [x16]
    1648:      	and	w17, w17, #0xff
    164c:      	tbnz	w17, #0x1, 0x166c <_llm_rows.packet_batch.blocks+0x768>
    1650:      	tbz	w17, #0x2, 0x1678 <_llm_rows.packet_batch.blocks+0x774>
    1654:      	add	x0, x16, #0x8
    1658:      	st1.s	{ v2 }[2], [x0]
    165c:      	tbnz	w17, #0x3, 0x167c <_llm_rows.packet_batch.blocks+0x778>
    1660:      	b	0x1684 <_llm_rows.packet_batch.blocks+0x780>
    1664:      	and	w17, w17, #0xff
    1668:      	tbz	w17, #0x1, 0x1650 <_llm_rows.packet_batch.blocks+0x74c>
    166c:      	add	x0, x16, #0x4
    1670:      	st1.s	{ v2 }[1], [x0]
    1674:      	tbnz	w17, #0x2, 0x1654 <_llm_rows.packet_batch.blocks+0x750>
    1678:      	tbz	w17, #0x3, 0x1684 <_llm_rows.packet_batch.blocks+0x780>
    167c:      	add	x0, x16, #0xc
    1680:      	st1.s	{ v2 }[3], [x0]
    1684:      	ldp	q2, q4, [sp, #0x190]
    1688:      	fmul.4s	v2, v14, v2
    168c:      	fmul.4s	v2, v14, v2
    1690:      	fmul.4s	v2, v14, v2
    1694:      	fadd.4s	v2, v14, v2
    1698:      	fmul.4s	v2, v2, v4
    169c:      	and.16b	v2, v10, v2
    16a0:      	fabs.4s	v4, v2
    16a4:      	fmul.4s	v5, v2, v2
    16a8:      	ldp	q7, q6, [sp, #0x1b0]
    16ac:      	fmla.4s	v6, v5, v7
    16b0:      	ldr	q7, [sp, #0x1d0]
    16b4:      	fmla.4s	v7, v5, v6
    16b8:      	ldr	q6, [sp, #0x1e0]
    16bc:      	fmla.4s	v6, v5, v7
    16c0:      	ldr	q7, [sp, #0x1f0]
    16c4:      	fmla.4s	v7, v5, v6
    16c8:      	mov.16b	v6, v3
    16cc:      	fmla.4s	v6, v5, v7
    16d0:      	mov.16b	v7, v0
    16d4:      	fmla.4s	v7, v5, v6
    16d8:      	fmul.4s	v6, v4, v7
    16dc:      	ldp	q7, q16, [sp, #0x200]
    16e0:      	fmla.4s	v7, v5, v16
    16e4:      	mov.16b	v16, v23
    16e8:      	fmla.4s	v16, v5, v7
    16ec:      	ldr	q7, [sp, #0x220]
    16f0:      	fmla.4s	v7, v5, v16
    16f4:      	ldr	q16, [sp, #0x230]
    16f8:      	fmla.4s	v16, v5, v7
    16fc:      	movi.4s	v7, #0x3f, lsl #24
    1700:      	fmla.4s	v7, v5, v16
    1704:      	mov.16b	v16, v0
    1708:      	fmla.4s	v16, v5, v7
    170c:      	fdiv.4s	v5, v6, v16
    1710:      	fcmge.4s	v6, v20, v4
    1714:      	and.16b	v7, v6, v4
    1718:      	fcmge.4s	v16, v7, v30
    171c:      	fcmge.4s	v17, v1, v7
    1720:      	and.16b	v16, v16, v17
    1724:      	and.16b	v16, v16, v7
    1728:      	fmul.4s	v17, v16, v29
    172c:      	movi.4s	v18, #0x4b, lsl #24
    1730:      	fadd.4s	v17, v17, v18
    1734:      	movi.4s	v18, #0xcb, lsl #24
    1738:      	fadd.4s	v17, v17, v18
    173c:      	fcvtzs.4s	v17, v17
    1740:      	scvtf.4s	v18, v17
    1744:      	fmul.4s	v19, v18, v9
    1748:      	fadd.4s	v16, v16, v19
    174c:      	fmul.4s	v18, v18, v28
    1750:      	fadd.4s	v16, v16, v18
    1754:      	fmul.4s	v18, v16, v24
    1758:      	fadd.4s	v18, v18, v22
    175c:      	fmul.4s	v18, v16, v18
    1760:      	fadd.4s	v18, v18, v27
    1764:      	fmul.4s	v18, v16, v18
    1768:      	fadd.4s	v18, v18, v25
    176c:      	fmul.4s	v18, v16, v18
    1770:      	fadd.4s	v18, v18, v3
    1774:      	fmul.4s	v18, v16, v18
    1778:      	fadd.4s	v18, v18, v21
    177c:      	fmul.4s	v19, v16, v16
    1780:      	fmul.4s	v18, v19, v18
    1784:      	fadd.4s	v16, v16, v18
    1788:      	fadd.4s	v16, v16, v0
    178c:      	movi.2d	v18, #0xffffffffffffffff
    1790:      	add.4s	v17, v17, v18
    1794:      	sshr.4s	v18, v17, #0x1
    1798:      	shl.4s	v19, v18, #0x17
    179c:      	add.4s	v19, v19, v0
    17a0:      	fmul.4s	v16, v16, v19
    17a4:      	sub.4s	v17, v17, v18
    17a8:      	shl.4s	v17, v17, #0x17
    17ac:      	add.4s	v17, v17, v0
    17b0:      	fmul.4s	v16, v16, v17
    17b4:      	fcmgt.4s	v7, v7, v1
    17b8:      	ldr	q17, [sp, #0x180]
    17bc:      	bsl.16b	v7, v17, v16
    17c0:      	fdiv.4s	v16, v31, v7
    17c4:      	fsub.4s	v17, v7, v16
    17c8:      	fadd.4s	v7, v7, v16
    17cc:      	fdiv.4s	v7, v17, v7
    17d0:      	bsl.16b	v6, v7, v0
    17d4:      	fcmge.4s	v4, v0, v4
    17d8:      	bsl.16b	v4, v5, v6
    17dc:      	mvni.4s	v5, #0x80, lsl #24
    17e0:      	bif.16b	v4, v2, v5
    17e4:      	fcmeq.4s	v2, v2, v2
    17e8:      	fadd.4s	v4, v4, v0
    17ec:      	ldr	q5, [sp, #0x170]
    17f0:      	bsl.16b	v2, v4, v5
    17f4:      	fmul.4s	v4, v14, v21
    17f8:      	fmul.4s	v2, v4, v2
    17fc:      	fadd.4s	v2, v8, v2
    1800:      	tbz	w17, #0x4, 0x1820 <_llm_rows.packet_batch.blocks+0x91c>
    1804:      	str	s2, [x16, #0x10]
    1808:      	tbnz	w17, #0x5, 0x1824 <_llm_rows.packet_batch.blocks+0x920>
    180c:      	tbz	w17, #0x6, 0x1830 <_llm_rows.packet_batch.blocks+0x92c>
    1810:      	add	x0, x16, #0x18
    1814:      	st1.s	{ v2 }[2], [x0]
    1818:      	tbz	w17, #0x7, 0x137c <_llm_rows.packet_batch.blocks+0x478>
    181c:      	b	0x1834 <_llm_rows.packet_batch.blocks+0x930>
    1820:      	tbz	w17, #0x5, 0x180c <_llm_rows.packet_batch.blocks+0x908>
    1824:      	add	x0, x16, #0x14
    1828:      	st1.s	{ v2 }[1], [x0]
    182c:      	tbnz	w17, #0x6, 0x1810 <_llm_rows.packet_batch.blocks+0x90c>
    1830:      	tbz	w17, #0x7, 0x137c <_llm_rows.packet_batch.blocks+0x478>
    1834:      	add	x16, x16, #0x1c
    1838:      	st1.s	{ v2 }[3], [x16]
    183c:      	b	0x137c <_llm_rows.packet_batch.blocks+0x478>
    1840:      	mov	x10, #0x0               ; =0
    1844:      	add	x14, x11, x12
    1848:      	b	0x186c <_llm_rows.packet_batch.blocks+0x968>
    184c:      	add	x15, x24, x10, lsl #5
    1850:      	ldp	q5, q6, [x15]
    1854:      	bif.16b	v4, v6, v10
    1858:      	bif.16b	v2, v5, v11
    185c:      	stp	q2, q4, [x15]
    1860:      	add	x10, x10, #0x1
    1864:      	cmp	x10, #0xc0
    1868:      	b.eq	0x1910 <_llm_rows.packet_batch.blocks+0xa0c>
    186c:      	ldr	q2, [sp, #0x120]
    1870:      	and.16b	v2, v26, v2
    1874:      	addv.8h	h12, v2
    1878:      	fmov	w16, s12
    187c:      	add	x15, x14, x10, lsl #5
    1880:      	movi.2d	v2, #0000000000000000
    1884:      	movi.2d	v4, #0000000000000000
    1888:      	tbz	w16, #0x0, 0x18cc <_llm_rows.packet_batch.blocks+0x9c8>
    188c:      	ldr	s2, [x15]
    1890:      	and	w16, w16, #0xff
    1894:      	tbnz	w16, #0x1, 0x18d4 <_llm_rows.packet_batch.blocks+0x9d0>
    1898:      	tbz	w16, #0x2, 0x18e0 <_llm_rows.packet_batch.blocks+0x9dc>
    189c:      	add	x17, x15, #0x8
    18a0:      	ld1.s	{ v2 }[2], [x17]
    18a4:      	tbnz	w16, #0x3, 0x18e4 <_llm_rows.packet_batch.blocks+0x9e0>
    18a8:      	tbz	w16, #0x4, 0x18f0 <_llm_rows.packet_batch.blocks+0x9ec>
    18ac:      	add	x17, x15, #0x10
    18b0:      	ld1.s	{ v4 }[0], [x17]
    18b4:      	tbnz	w16, #0x5, 0x18f4 <_llm_rows.packet_batch.blocks+0x9f0>
    18b8:      	tbz	w16, #0x6, 0x1900 <_llm_rows.packet_batch.blocks+0x9fc>
    18bc:      	add	x17, x15, #0x18
    18c0:      	ld1.s	{ v4 }[2], [x17]
    18c4:      	tbz	w16, #0x7, 0x184c <_llm_rows.packet_batch.blocks+0x948>
    18c8:      	b	0x1904 <_llm_rows.packet_batch.blocks+0xa00>
    18cc:      	and	w16, w16, #0xff
    18d0:      	tbz	w16, #0x1, 0x1898 <_llm_rows.packet_batch.blocks+0x994>
    18d4:      	add	x17, x15, #0x4
    18d8:      	ld1.s	{ v2 }[1], [x17]
    18dc:      	tbnz	w16, #0x2, 0x189c <_llm_rows.packet_batch.blocks+0x998>
    18e0:      	tbz	w16, #0x3, 0x18a8 <_llm_rows.packet_batch.blocks+0x9a4>
    18e4:      	add	x17, x15, #0xc
    18e8:      	ld1.s	{ v2 }[3], [x17]
    18ec:      	tbnz	w16, #0x4, 0x18ac <_llm_rows.packet_batch.blocks+0x9a8>
    18f0:      	tbz	w16, #0x5, 0x18b8 <_llm_rows.packet_batch.blocks+0x9b4>
    18f4:      	add	x17, x15, #0x14
    18f8:      	ld1.s	{ v4 }[1], [x17]
    18fc:      	tbnz	w16, #0x6, 0x18bc <_llm_rows.packet_batch.blocks+0x9b8>
    1900:      	tbz	w16, #0x7, 0x184c <_llm_rows.packet_batch.blocks+0x948>
    1904:      	add	x15, x15, #0x1c
    1908:      	ld1.s	{ v4 }[3], [x15]
    190c:      	b	0x184c <_llm_rows.packet_batch.blocks+0x948>
    1910:      	xtn.8b	v2, v26
    1914:      	movi	d4, #0x0000000000ffff
    1918:      	and.8b	v8, v2, v4
    191c:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0xfc>
    1920:      	ldr	d4, [x10]
    1924:      	and.8b	v2, v2, v4
    1928:      	addv.8b	b2, v2
    192c:      	fmov	w15, s2
    1930:      	umaxv.8b	b2, v8
    1934:      	fmov	w10, s2
    1938:      	rbit	w14, w15
    193c:      	clz	w14, w14
    1940:      	tst	w10, #0x1
    1944:      	csel	w10, w14, wzr, ne
    1948:      	mov	w14, #0x600             ; =1536
    194c:      	dup.2d	v2, x14
    1950:      	ldr	d4, [sp, #0x130]
    1954:      	ldr	q5, [sp, #0xc0]
    1958:      	ldr	d6, [sp, #0xa0]
    195c:      	umlal.2d	v5, v6, v4
    1960:      	mov	b4, v8[0]
    1964:      	mov.b	v4[4], v8[1]
    1968:      	add.2d	v5, v5, v2
    196c:      	ushll.2d	v4, v4, #0x0
    1970:      	shl.2d	v4, v4, #0x3f
    1974:      	cmlt.2d	v4, v4, #0
    1978:      	str	q5, [sp, #0xa0]
    197c:      	and.16b	v4, v4, v5
    1980:      	movi.2d	v5, #0000000000000000
    1984:      	stp	q5, q5, [sp, #0x380]
    1988:      	stp	q4, q5, [sp, #0x360]
    198c:      	and	x14, x10, #0x7
    1990:      	add	x16, sp, #0x360
    1994:      	ldr	x14, [x16, x14, lsl #3]
    1998:      	sub	x14, x14, x10
    199c:      	lsl	x14, x14, #2
    19a0:      	add	x11, x11, x14
    19a4:      	movi.2d	v13, #0000000000000000
    19a8:      	movi.2d	v19, #0000000000000000
    19ac:      	tbz	w15, #0x0, 0x19ec <_llm_rows.packet_batch.blocks+0xae8>
    19b0:      	ldr	s13, [x11]
    19b4:      	tbnz	w15, #0x1, 0x19f0 <_llm_rows.packet_batch.blocks+0xaec>
    19b8:      	tbz	w15, #0x2, 0x19fc <_llm_rows.packet_batch.blocks+0xaf8>
    19bc:      	add	x16, x11, #0x8
    19c0:      	ld1.s	{ v13 }[2], [x16]
    19c4:      	tbnz	w15, #0x3, 0x1a00 <_llm_rows.packet_batch.blocks+0xafc>
    19c8:      	tbz	w15, #0x4, 0x1a0c <_llm_rows.packet_batch.blocks+0xb08>
    19cc:      	add	x16, x11, #0x10
    19d0:      	ld1.s	{ v19 }[0], [x16]
    19d4:      	tbnz	w15, #0x5, 0x1a10 <_llm_rows.packet_batch.blocks+0xb0c>
    19d8:      	tbz	w15, #0x6, 0x1a1c <_llm_rows.packet_batch.blocks+0xb18>
    19dc:      	add	x16, x11, #0x18
    19e0:      	ld1.s	{ v19 }[2], [x16]
    19e4:      	tbnz	w15, #0x7, 0x1a20 <_llm_rows.packet_batch.blocks+0xb1c>
    19e8:      	b	0x1a28 <_llm_rows.packet_batch.blocks+0xb24>
    19ec:      	tbz	w15, #0x1, 0x19b8 <_llm_rows.packet_batch.blocks+0xab4>
    19f0:      	add	x16, x11, #0x4
    19f4:      	ld1.s	{ v13 }[1], [x16]
    19f8:      	tbnz	w15, #0x2, 0x19bc <_llm_rows.packet_batch.blocks+0xab8>
    19fc:      	tbz	w15, #0x3, 0x19c8 <_llm_rows.packet_batch.blocks+0xac4>
    1a00:      	add	x16, x11, #0xc
    1a04:      	ld1.s	{ v13 }[3], [x16]
    1a08:      	tbnz	w15, #0x4, 0x19cc <_llm_rows.packet_batch.blocks+0xac8>
    1a0c:      	tbz	w15, #0x5, 0x19d8 <_llm_rows.packet_batch.blocks+0xad4>
    1a10:      	add	x16, x11, #0x14
    1a14:      	ld1.s	{ v19 }[1], [x16]
    1a18:      	tbnz	w15, #0x6, 0x19dc <_llm_rows.packet_batch.blocks+0xad8>
    1a1c:      	tbz	w15, #0x7, 0x1a28 <_llm_rows.packet_batch.blocks+0xb24>
    1a20:      	add	x11, x11, #0x1c
    1a24:      	ld1.s	{ v19 }[3], [x11]
    1a28:      	mov	x17, #0x0               ; =0
    1a2c:      	ldr	q4, [sp, #0x140]
    1a30:      	ldr	d6, [sp, #0x130]
    1a34:      	ldr	d5, [sp, #0xd0]
    1a38:      	umlal.2d	v4, v5, v6
    1a3c:      	add.2d	v4, v4, v2
    1a40:      	str	q4, [sp, #0xd0]
    1a44:      	ldr	q4, [sp, #0x150]
    1a48:      	ldr	d5, [sp, #0xe0]
    1a4c:      	umlal.2d	v4, v5, v6
    1a50:      	add.2d	v4, v4, v2
    1a54:      	str	q4, [sp, #0x30]
    1a58:      	ldr	d4, [sp, #0xf0]
    1a5c:      	ldr	q5, [sp, #0xb0]
    1a60:      	umlal.2d	v5, v4, v6
    1a64:      	add.2d	v2, v5, v2
    1a68:      	str	q2, [sp, #0xb0]
    1a6c:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xfc>
    1a70:      	ldr	q2, [x11]
    1a74:      	mov	w11, #0x1800            ; =6144
    1a78:      	dup.2d	v4, x11
    1a7c:      	sshll.2d	v5, v11, #0x0
    1a80:      	bif.16b	v2, v4, v5
    1a84:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xfc>
    1a88:      	ldr	q5, [x11]
    1a8c:      	sshll.2d	v6, v10, #0x0
    1a90:      	bif.16b	v5, v4, v6
    1a94:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xfc>
    1a98:      	ldr	q6, [x11]
    1a9c:      	bif.16b	v6, v4, v15
    1aa0:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xfc>
    1aa4:      	ldr	q7, [x11]
    1aa8:      	bit.16b	v4, v7, v14
    1aac:      	stp	q5, q4, [sp, #0x340]
    1ab0:      	stp	q2, q6, [sp, #0x320]
    1ab4:      	and	x11, x10, #0x7
    1ab8:      	add	x16, sp, #0x320
    1abc:      	ldr	x11, [x16, x11, lsl #3]
    1ac0:      	sub	x11, x11, x10, lsl #2
    1ac4:      	tst	w15, #0xff
    1ac8:      	csel	x15, xzr, x11, eq
    1acc:      	add	x11, x24, x15
    1ad0:      	ldp	q2, q4, [x11]
    1ad4:      	zip2.8b	v5, v8, v0
    1ad8:      	ushll.4s	v5, v5, #0x0
    1adc:      	shl.4s	v5, v5, #0x1f
    1ae0:      	cmlt.4s	v5, v5, #0
    1ae4:      	bit.16b	v4, v19, v5
    1ae8:      	zip1.8b	v5, v8, v0
    1aec:      	ushll.4s	v5, v5, #0x0
    1af0:      	shl.4s	v5, v5, #0x1f
    1af4:      	cmlt.4s	v5, v5, #0
    1af8:      	bit.16b	v2, v13, v5
    1afc:      	stp	q2, q4, [x11]
    1b00:      	add	x16, x9, x12
    1b04:      	ushll2.2d	v2, v10, #0x0
    1b08:      	mov	w11, #0x1               ; =1
    1b0c:      	dup.2d	v4, x11
    1b10:      	and.16b	v5, v2, v4
    1b14:      	ushll2.2d	v2, v11, #0x0
    1b18:      	and.16b	v2, v2, v4
    1b1c:      	stp	q2, q5, [sp, #0x140]
    1b20:      	ushll.2d	v2, v10, #0x0
    1b24:      	and.16b	v2, v2, v4
    1b28:      	str	q2, [sp, #0x130]
    1b2c:      	ushll.2d	v2, v11, #0x0
    1b30:      	and.16b	v14, v2, v4
    1b34:      	movi.2d	v2, #0000000000000000
    1b38:      	and	x11, x13, #0x1
    1b3c:      	movi.2d	v4, #0000000000000000
    1b40:      	movi.2d	v5, #0000000000000000
    1b44:      	movi.2d	v6, #0000000000000000
    1b48:      	b	0x1b8c <_llm_rows.packet_batch.blocks+0xc88>
    1b4c:      	add	x13, x26, x13
    1b50:      	ldp	q17, q18, [x13]
    1b54:      	bif.16b	v16, v18, v10
    1b58:      	bif.16b	v7, v17, v11
    1b5c:      	stp	q7, q16, [x13]
    1b60:      	add.2d	v7, v2, v14
    1b64:      	ldp	q16, q17, [sp, #0x130]
    1b68:      	add.2d	v4, v4, v17
    1b6c:      	add.2d	v5, v5, v16
    1b70:      	ldr	q16, [sp, #0x150]
    1b74:      	add.2d	v6, v6, v16
    1b78:      	fmov	x13, d2
    1b7c:      	add	x17, x13, x11
    1b80:      	mov.16b	v2, v7
    1b84:      	cmp	x17, #0xc0
    1b88:      	b.ge	0x1c28 <_llm_rows.packet_batch.blocks+0xd24>
    1b8c:      	fmov	w0, s12
    1b90:      	lsl	x13, x17, #5
    1b94:      	add	x17, x16, x13
    1b98:      	movi.2d	v7, #0000000000000000
    1b9c:      	movi.2d	v16, #0000000000000000
    1ba0:      	tbz	w0, #0x0, 0x1be4 <_llm_rows.packet_batch.blocks+0xce0>
    1ba4:      	ldr	s7, [x17]
    1ba8:      	and	w0, w0, #0xff
    1bac:      	tbnz	w0, #0x1, 0x1bec <_llm_rows.packet_batch.blocks+0xce8>
    1bb0:      	tbz	w0, #0x2, 0x1bf8 <_llm_rows.packet_batch.blocks+0xcf4>
    1bb4:      	add	x1, x17, #0x8
    1bb8:      	ld1.s	{ v7 }[2], [x1]
    1bbc:      	tbnz	w0, #0x3, 0x1bfc <_llm_rows.packet_batch.blocks+0xcf8>
    1bc0:      	tbz	w0, #0x4, 0x1c08 <_llm_rows.packet_batch.blocks+0xd04>
    1bc4:      	add	x1, x17, #0x10
    1bc8:      	ld1.s	{ v16 }[0], [x1]
    1bcc:      	tbnz	w0, #0x5, 0x1c0c <_llm_rows.packet_batch.blocks+0xd08>
    1bd0:      	tbz	w0, #0x6, 0x1c18 <_llm_rows.packet_batch.blocks+0xd14>
    1bd4:      	add	x1, x17, #0x18
    1bd8:      	ld1.s	{ v16 }[2], [x1]
    1bdc:      	tbz	w0, #0x7, 0x1b4c <_llm_rows.packet_batch.blocks+0xc48>
    1be0:      	b	0x1c1c <_llm_rows.packet_batch.blocks+0xd18>
    1be4:      	and	w0, w0, #0xff
    1be8:      	tbz	w0, #0x1, 0x1bb0 <_llm_rows.packet_batch.blocks+0xcac>
    1bec:      	add	x1, x17, #0x4
    1bf0:      	ld1.s	{ v7 }[1], [x1]
    1bf4:      	tbnz	w0, #0x2, 0x1bb4 <_llm_rows.packet_batch.blocks+0xcb0>
    1bf8:      	tbz	w0, #0x3, 0x1bc0 <_llm_rows.packet_batch.blocks+0xcbc>
    1bfc:      	add	x1, x17, #0xc
    1c00:      	ld1.s	{ v7 }[3], [x1]
    1c04:      	tbnz	w0, #0x4, 0x1bc4 <_llm_rows.packet_batch.blocks+0xcc0>
    1c08:      	tbz	w0, #0x5, 0x1bd0 <_llm_rows.packet_batch.blocks+0xccc>
    1c0c:      	add	x1, x17, #0x14
    1c10:      	ld1.s	{ v16 }[1], [x1]
    1c14:      	tbnz	w0, #0x6, 0x1bd4 <_llm_rows.packet_batch.blocks+0xcd0>
    1c18:      	tbz	w0, #0x7, 0x1b4c <_llm_rows.packet_batch.blocks+0xc48>
    1c1c:      	add	x17, x17, #0x1c
    1c20:      	ld1.s	{ v16 }[3], [x17]
    1c24:      	b	0x1b4c <_llm_rows.packet_batch.blocks+0xc48>
    1c28:      	add	x9, x9, x14
    1c2c:      	adrp	x13, 0x1000 <_llm_rows.packet_batch.blocks+0xfc>
    1c30:      	ldr	d2, [x13]
    1c34:      	shl.8b	v4, v8, #0x7
    1c38:      	cmlt.8b	v4, v4, #0
    1c3c:      	and.8b	v2, v4, v2
    1c40:      	addv.8b	b2, v2
    1c44:      	str	d2, [sp, #0x8]
    1c48:      	fmov	w13, s2
    1c4c:      	movi.2d	v7, #0000000000000000
    1c50:      	movi.2d	v6, #0000000000000000
    1c54:      	tbz	w13, #0x0, 0x211c <_llm_rows.packet_batch.blocks+0x1218>
    1c58:      	ldr	s7, [x9]
    1c5c:      	tbnz	w13, #0x1, 0x2120 <_llm_rows.packet_batch.blocks+0x121c>
    1c60:      	tbz	w13, #0x2, 0x212c <_llm_rows.packet_batch.blocks+0x1228>
    1c64:      	add	x14, x9, #0x8
    1c68:      	ld1.s	{ v7 }[2], [x14]
    1c6c:      	tbnz	w13, #0x3, 0x2130 <_llm_rows.packet_batch.blocks+0x122c>
    1c70:      	tbz	w13, #0x4, 0x213c <_llm_rows.packet_batch.blocks+0x1238>
    1c74:      	add	x14, x9, #0x10
    1c78:      	ld1.s	{ v6 }[0], [x14]
    1c7c:      	tbnz	w13, #0x5, 0x2140 <_llm_rows.packet_batch.blocks+0x123c>
    1c80:      	tbz	w13, #0x6, 0x1c8c <_llm_rows.packet_batch.blocks+0xd88>
    1c84:      	add	x14, x9, #0x18
    1c88:      	ld1.s	{ v6 }[2], [x14]
    1c8c:      	str	q13, [sp, #0xe0]
    1c90:      	mov.16b	v26, v25
    1c94:      	str	q19, [sp, #0xc0]
    1c98:      	mov.16b	v15, v27
    1c9c:      	mov.16b	v27, v28
    1ca0:      	mov.16b	v25, v22
    1ca4:      	tbz	w13, #0x7, 0x1cb0 <_llm_rows.packet_batch.blocks+0xdac>
    1ca8:      	add	x9, x9, #0x1c
    1cac:      	ld1.s	{ v6 }[3], [x9]
    1cb0:      	mov	x13, #0x0               ; =0
    1cb4:      	add	x9, x26, x15
    1cb8:      	ldp	q2, q4, [x9]
    1cbc:      	zip2.8b	v5, v8, v0
    1cc0:      	ushll.4s	v5, v5, #0x0
    1cc4:      	shl.4s	v5, v5, #0x1f
    1cc8:      	cmlt.4s	v5, v5, #0
    1ccc:      	stp	q7, q6, [sp, #0x10]
    1cd0:      	bit.16b	v4, v6, v5
    1cd4:      	str	q8, [sp, #0xf0]
    1cd8:      	zip1.8b	v5, v8, v0
    1cdc:      	ushll.4s	v5, v5, #0x0
    1ce0:      	shl.4s	v5, v5, #0x1f
    1ce4:      	cmlt.4s	v5, v5, #0
    1ce8:      	bit.16b	v2, v7, v5
    1cec:      	stp	q2, q4, [x9]
    1cf0:      	add	x9, x8, x12
    1cf4:      	movi.2d	v2, #0000000000000000
    1cf8:      	movi.2d	v4, #0000000000000000
    1cfc:      	movi.2d	v5, #0000000000000000
    1d00:      	movi.2d	v6, #0000000000000000
    1d04:      	b	0x1d34 <_llm_rows.packet_batch.blocks+0xe30>
    1d08:      	add.2d	v7, v2, v14
    1d0c:      	ldp	q16, q17, [sp, #0x130]
    1d10:      	add.2d	v4, v4, v17
    1d14:      	add.2d	v5, v5, v16
    1d18:      	ldr	q16, [sp, #0x150]
    1d1c:      	add.2d	v6, v6, v16
    1d20:      	fmov	x12, d2
    1d24:      	add	x13, x12, x11
    1d28:      	mov.16b	v2, v7
    1d2c:      	cmp	x13, #0xc0
    1d30:      	b.ge	0x2150 <_llm_rows.packet_batch.blocks+0x124c>
    1d34:      	lsl	x12, x13, #5
    1d38:      	add	x13, x24, x12
    1d3c:      	ldr	q7, [x13]
    1d40:      	and.16b	v7, v11, v7
    1d44:      	ldp	q16, q17, [sp, #0x190]
    1d48:      	fmul.4s	v16, v7, v16
    1d4c:      	fmul.4s	v16, v7, v16
    1d50:      	fmul.4s	v16, v7, v16
    1d54:      	fadd.4s	v16, v7, v16
    1d58:      	fmul.4s	v16, v16, v17
    1d5c:      	and.16b	v16, v11, v16
    1d60:      	fabs.4s	v17, v16
    1d64:      	fmul.4s	v18, v16, v16
    1d68:      	ldp	q22, q19, [sp, #0x1b0]
    1d6c:      	fmla.4s	v19, v18, v22
    1d70:      	ldr	q28, [sp, #0x1d0]
    1d74:      	fmla.4s	v28, v18, v19
    1d78:      	ldr	q19, [sp, #0x1e0]
    1d7c:      	fmla.4s	v19, v18, v28
    1d80:      	ldr	q28, [sp, #0x1f0]
    1d84:      	fmla.4s	v28, v18, v19
    1d88:      	mov.16b	v19, v3
    1d8c:      	fmla.4s	v19, v18, v28
    1d90:      	mov.16b	v28, v0
    1d94:      	fmla.4s	v28, v18, v19
    1d98:      	fmul.4s	v19, v17, v28
    1d9c:      	ldp	q28, q22, [sp, #0x200]
    1da0:      	fmla.4s	v28, v18, v22
    1da4:      	fmla.4s	v23, v18, v28
    1da8:      	ldr	q28, [sp, #0x220]
    1dac:      	fmla.4s	v28, v18, v23
    1db0:      	ldr	q23, [sp, #0x230]
    1db4:      	fmla.4s	v23, v18, v28
    1db8:      	movi.4s	v28, #0x3f, lsl #24
    1dbc:      	fmla.4s	v28, v18, v23
    1dc0:      	mov.16b	v23, v0
    1dc4:      	fmla.4s	v23, v18, v28
    1dc8:      	fdiv.4s	v18, v19, v23
    1dcc:      	fcmge.4s	v19, v20, v17
    1dd0:      	and.16b	v23, v19, v17
    1dd4:      	mov.16b	v8, v30
    1dd8:      	fcmge.4s	v28, v23, v30
    1ddc:      	fcmge.4s	v30, v1, v23
    1de0:      	and.16b	v28, v28, v30
    1de4:      	and.16b	v28, v28, v23
    1de8:      	mov.16b	v13, v29
    1dec:      	fmul.4s	v30, v28, v29
    1df0:      	mov.16b	v22, v31
    1df4:      	movi.4s	v31, #0x4b, lsl #24
    1df8:      	fadd.4s	v30, v30, v31
    1dfc:      	movi.4s	v31, #0xcb, lsl #24
    1e00:      	fadd.4s	v30, v30, v31
    1e04:      	fcvtzs.4s	v30, v30
    1e08:      	scvtf.4s	v31, v30
    1e0c:      	mov.16b	v29, v9
    1e10:      	fmul.4s	v9, v31, v9
    1e14:      	fadd.4s	v28, v28, v9
    1e18:      	fmul.4s	v31, v31, v27
    1e1c:      	fadd.4s	v28, v28, v31
    1e20:      	fmul.4s	v31, v28, v24
    1e24:      	fadd.4s	v31, v31, v25
    1e28:      	fmul.4s	v31, v28, v31
    1e2c:      	fadd.4s	v31, v31, v15
    1e30:      	fmul.4s	v31, v28, v31
    1e34:      	fadd.4s	v31, v31, v26
    1e38:      	fmul.4s	v31, v28, v31
    1e3c:      	fadd.4s	v31, v31, v3
    1e40:      	fmul.4s	v31, v28, v31
    1e44:      	fadd.4s	v31, v31, v21
    1e48:      	fmul.4s	v9, v28, v28
    1e4c:      	fmul.4s	v31, v9, v31
    1e50:      	fadd.4s	v28, v28, v31
    1e54:      	fadd.4s	v28, v28, v0
    1e58:      	movi.2d	v31, #0xffffffffffffffff
    1e5c:      	add.4s	v30, v30, v31
    1e60:      	sshr.4s	v31, v30, #0x1
    1e64:      	shl.4s	v9, v31, #0x17
    1e68:      	add.4s	v9, v9, v0
    1e6c:      	fmul.4s	v28, v28, v9
    1e70:      	sub.4s	v30, v30, v31
    1e74:      	shl.4s	v30, v30, #0x17
    1e78:      	add.4s	v30, v30, v0
    1e7c:      	fmul.4s	v28, v28, v30
    1e80:      	fcmgt.4s	v23, v23, v1
    1e84:      	ldr	q30, [sp, #0x180]
    1e88:      	bsl.16b	v23, v30, v28
    1e8c:      	fdiv.4s	v28, v22, v23
    1e90:      	fsub.4s	v30, v23, v28
    1e94:      	fadd.4s	v23, v23, v28
    1e98:      	fdiv.4s	v23, v30, v23
    1e9c:      	bsl.16b	v19, v23, v0
    1ea0:      	fcmge.4s	v17, v0, v17
    1ea4:      	bsl.16b	v17, v18, v19
    1ea8:      	mvni.4s	v18, #0x80, lsl #24
    1eac:      	bif.16b	v17, v16, v18
    1eb0:      	fcmeq.4s	v16, v16, v16
    1eb4:      	fadd.4s	v17, v17, v0
    1eb8:      	ldr	q18, [sp, #0x170]
    1ebc:      	bif.16b	v17, v18, v16
    1ec0:      	ldr	q16, [x13, #0x10]
    1ec4:      	fmul.4s	v7, v7, v21
    1ec8:      	fmul.4s	v7, v7, v17
    1ecc:      	add	x13, x26, x12
    1ed0:      	ldr	q17, [x13]
    1ed4:      	and.16b	v17, v11, v17
    1ed8:      	fadd.4s	v17, v17, v7
    1edc:      	ldr	q7, [x13, #0x10]
    1ee0:      	fmov	w13, s12
    1ee4:      	add	x12, x9, x12
    1ee8:      	tbz	w13, #0x0, 0x1f0c <_llm_rows.packet_batch.blocks+0x1008>
    1eec:      	str	s17, [x12]
    1ef0:      	and	w13, w13, #0xff
    1ef4:      	tbnz	w13, #0x1, 0x1f14 <_llm_rows.packet_batch.blocks+0x1010>
    1ef8:      	tbz	w13, #0x2, 0x1f20 <_llm_rows.packet_batch.blocks+0x101c>
    1efc:      	add	x14, x12, #0x8
    1f00:      	st1.s	{ v17 }[2], [x14]
    1f04:      	tbnz	w13, #0x3, 0x1f24 <_llm_rows.packet_batch.blocks+0x1020>
    1f08:      	b	0x1f2c <_llm_rows.packet_batch.blocks+0x1028>
    1f0c:      	and	w13, w13, #0xff
    1f10:      	tbz	w13, #0x1, 0x1ef8 <_llm_rows.packet_batch.blocks+0xff4>
    1f14:      	add	x14, x12, #0x4
    1f18:      	st1.s	{ v17 }[1], [x14]
    1f1c:      	tbnz	w13, #0x2, 0x1efc <_llm_rows.packet_batch.blocks+0xff8>
    1f20:      	tbz	w13, #0x3, 0x1f2c <_llm_rows.packet_batch.blocks+0x1028>
    1f24:      	add	x14, x12, #0xc
    1f28:      	st1.s	{ v17 }[3], [x14]
    1f2c:      	and.16b	v16, v10, v16
    1f30:      	ldp	q17, q18, [sp, #0x190]
    1f34:      	fmul.4s	v17, v16, v17
    1f38:      	fmul.4s	v17, v16, v17
    1f3c:      	fmul.4s	v17, v16, v17
    1f40:      	fadd.4s	v17, v16, v17
    1f44:      	fmul.4s	v17, v17, v18
    1f48:      	and.16b	v17, v10, v17
    1f4c:      	fabs.4s	v18, v17
    1f50:      	fmul.4s	v19, v17, v17
    1f54:      	ldp	q21, q23, [sp, #0x1b0]
    1f58:      	fmla.4s	v23, v19, v21
    1f5c:      	ldr	q28, [sp, #0x1d0]
    1f60:      	fmla.4s	v28, v19, v23
    1f64:      	ldr	q23, [sp, #0x1e0]
    1f68:      	fmla.4s	v23, v19, v28
    1f6c:      	ldr	q28, [sp, #0x1f0]
    1f70:      	fmla.4s	v28, v19, v23
    1f74:      	mov.16b	v23, v3
    1f78:      	fmla.4s	v23, v19, v28
    1f7c:      	mov.16b	v28, v0
    1f80:      	fmla.4s	v28, v19, v23
    1f84:      	fmul.4s	v23, v18, v28
    1f88:      	ldp	q28, q21, [sp, #0x200]
    1f8c:      	fmla.4s	v28, v19, v21
    1f90:      	ldr	q30, [sp, #0x160]
    1f94:      	fmla.4s	v30, v19, v28
    1f98:      	ldr	q28, [sp, #0x220]
    1f9c:      	fmla.4s	v28, v19, v30
    1fa0:      	ldr	q30, [sp, #0x230]
    1fa4:      	fmla.4s	v30, v19, v28
    1fa8:      	movi.4s	v28, #0x3f, lsl #24
    1fac:      	fmla.4s	v28, v19, v30
    1fb0:      	mov.16b	v30, v0
    1fb4:      	fmla.4s	v30, v19, v28
    1fb8:      	fdiv.4s	v19, v23, v30
    1fbc:      	fcmge.4s	v23, v20, v18
    1fc0:      	and.16b	v28, v23, v18
    1fc4:      	fcmge.4s	v30, v28, v8
    1fc8:      	fcmge.4s	v31, v1, v28
    1fcc:      	and.16b	v30, v30, v31
    1fd0:      	and.16b	v30, v30, v28
    1fd4:      	fmul.4s	v31, v30, v13
    1fd8:      	movi.4s	v21, #0x4b, lsl #24
    1fdc:      	fadd.4s	v31, v31, v21
    1fe0:      	movi.4s	v21, #0xcb, lsl #24
    1fe4:      	fadd.4s	v31, v31, v21
    1fe8:      	fcvtzs.4s	v31, v31
    1fec:      	scvtf.4s	v9, v31
    1ff0:      	fmul.4s	v21, v9, v29
    1ff4:      	fadd.4s	v21, v30, v21
    1ff8:      	fmul.4s	v30, v9, v27
    1ffc:      	fadd.4s	v21, v21, v30
    2000:      	fmul.4s	v30, v21, v24
    2004:      	fadd.4s	v30, v30, v25
    2008:      	fmul.4s	v30, v21, v30
    200c:      	fadd.4s	v30, v30, v15
    2010:      	fmul.4s	v30, v21, v30
    2014:      	fadd.4s	v30, v30, v26
    2018:      	fmul.4s	v30, v21, v30
    201c:      	fadd.4s	v30, v30, v3
    2020:      	fmul.4s	v30, v21, v30
    2024:      	movi.4s	v9, #0x3f, lsl #24
    2028:      	fadd.4s	v30, v30, v9
    202c:      	fmul.4s	v9, v21, v21
    2030:      	fmul.4s	v30, v9, v30
    2034:      	fadd.4s	v21, v21, v30
    2038:      	fadd.4s	v21, v21, v0
    203c:      	movi.2d	v30, #0xffffffffffffffff
    2040:      	add.4s	v30, v31, v30
    2044:      	sshr.4s	v31, v30, #0x1
    2048:      	shl.4s	v9, v31, #0x17
    204c:      	add.4s	v9, v9, v0
    2050:      	fmul.4s	v21, v21, v9
    2054:      	sub.4s	v30, v30, v31
    2058:      	shl.4s	v30, v30, #0x17
    205c:      	add.4s	v30, v30, v0
    2060:      	fmul.4s	v21, v21, v30
    2064:      	fcmgt.4s	v28, v28, v1
    2068:      	ldr	q30, [sp, #0x180]
    206c:      	bit.16b	v21, v30, v28
    2070:      	mov.16b	v31, v22
    2074:      	fdiv.4s	v28, v22, v21
    2078:      	fsub.4s	v30, v21, v28
    207c:      	fadd.4s	v21, v21, v28
    2080:      	fdiv.4s	v21, v30, v21
    2084:      	bif.16b	v21, v0, v23
    2088:      	fcmge.4s	v18, v0, v18
    208c:      	bsl.16b	v18, v19, v21
    2090:      	movi.4s	v21, #0x3f, lsl #24
    2094:      	mvni.4s	v19, #0x80, lsl #24
    2098:      	bif.16b	v18, v17, v19
    209c:      	fcmeq.4s	v17, v17, v17
    20a0:      	fadd.4s	v18, v18, v0
    20a4:      	ldr	q19, [sp, #0x170]
    20a8:      	bsl.16b	v17, v18, v19
    20ac:      	fmul.4s	v16, v16, v21
    20b0:      	fmul.4s	v16, v16, v17
    20b4:      	and.16b	v7, v10, v7
    20b8:      	fadd.4s	v7, v7, v16
    20bc:      	tbz	w13, #0x4, 0x20ec <_llm_rows.packet_batch.blocks+0x11e8>
    20c0:      	str	s7, [x12, #0x10]
    20c4:      	tbnz	w13, #0x5, 0x20f0 <_llm_rows.packet_batch.blocks+0x11ec>
    20c8:      	mov.16b	v9, v29
    20cc:      	mov.16b	v30, v8
    20d0:      	ldr	q23, [sp, #0x160]
    20d4:      	tbz	w13, #0x6, 0x2108 <_llm_rows.packet_batch.blocks+0x1204>
    20d8:      	add	x14, x12, #0x18
    20dc:      	st1.s	{ v7 }[2], [x14]
    20e0:      	mov.16b	v29, v13
    20e4:      	tbz	w13, #0x7, 0x1d08 <_llm_rows.packet_batch.blocks+0xe04>
    20e8:      	b	0x2110 <_llm_rows.packet_batch.blocks+0x120c>
    20ec:      	tbz	w13, #0x5, 0x20c8 <_llm_rows.packet_batch.blocks+0x11c4>
    20f0:      	add	x14, x12, #0x14
    20f4:      	st1.s	{ v7 }[1], [x14]
    20f8:      	mov.16b	v9, v29
    20fc:      	mov.16b	v30, v8
    2100:      	ldr	q23, [sp, #0x160]
    2104:      	tbnz	w13, #0x6, 0x20d8 <_llm_rows.packet_batch.blocks+0x11d4>
    2108:      	mov.16b	v29, v13
    210c:      	tbz	w13, #0x7, 0x1d08 <_llm_rows.packet_batch.blocks+0xe04>
    2110:      	add	x12, x12, #0x1c
    2114:      	st1.s	{ v7 }[3], [x12]
    2118:      	b	0x1d08 <_llm_rows.packet_batch.blocks+0xe04>
    211c:      	tbz	w13, #0x1, 0x1c60 <_llm_rows.packet_batch.blocks+0xd5c>
    2120:      	add	x14, x9, #0x4
    2124:      	ld1.s	{ v7 }[1], [x14]
    2128:      	tbnz	w13, #0x2, 0x1c64 <_llm_rows.packet_batch.blocks+0xd60>
    212c:      	tbz	w13, #0x3, 0x1c70 <_llm_rows.packet_batch.blocks+0xd6c>
    2130:      	add	x14, x9, #0xc
    2134:      	ld1.s	{ v7 }[3], [x14]
    2138:      	tbnz	w13, #0x4, 0x1c74 <_llm_rows.packet_batch.blocks+0xd70>
    213c:      	tbz	w13, #0x5, 0x1c80 <_llm_rows.packet_batch.blocks+0xd7c>
    2140:      	add	x14, x9, #0x14
    2144:      	ld1.s	{ v6 }[1], [x14]
    2148:      	tbnz	w13, #0x6, 0x1c84 <_llm_rows.packet_batch.blocks+0xd80>
    214c:      	b	0x1c8c <_llm_rows.packet_batch.blocks+0xd88>
    2150:      	ldp	q2, q4, [sp, #0x190]
    2154:      	ldp	q8, q28, [sp, #0xe0]
    2158:      	fmul.4s	v2, v8, v2
    215c:      	fmul.4s	v2, v8, v2
    2160:      	fmul.4s	v2, v8, v2
    2164:      	fadd.4s	v2, v8, v2
    2168:      	fmul.4s	v2, v2, v4
    216c:      	zip1.8b	v4, v28, v0
    2170:      	ushll.4s	v4, v4, #0x0
    2174:      	shl.4s	v4, v4, #0x1f
    2178:      	cmlt.4s	v4, v4, #0
    217c:      	and.16b	v2, v4, v2
    2180:      	fabs.4s	v4, v2
    2184:      	fmul.4s	v5, v2, v2
    2188:      	ldp	q7, q6, [sp, #0x1b0]
    218c:      	fmla.4s	v6, v5, v7
    2190:      	ldr	q7, [sp, #0x1d0]
    2194:      	fmla.4s	v7, v5, v6
    2198:      	ldr	q6, [sp, #0x1e0]
    219c:      	fmla.4s	v6, v5, v7
    21a0:      	ldr	q7, [sp, #0x1f0]
    21a4:      	fmla.4s	v7, v5, v6
    21a8:      	mov.16b	v6, v3
    21ac:      	fmla.4s	v6, v5, v7
    21b0:      	mov.16b	v7, v0
    21b4:      	fmla.4s	v7, v5, v6
    21b8:      	fmul.4s	v6, v4, v7
    21bc:      	ldp	q7, q16, [sp, #0x200]
    21c0:      	fmla.4s	v7, v5, v16
    21c4:      	fmla.4s	v23, v5, v7
    21c8:      	ldp	q7, q16, [sp, #0x220]
    21cc:      	fmla.4s	v7, v5, v23
    21d0:      	fmla.4s	v16, v5, v7
    21d4:      	movi.4s	v7, #0x3f, lsl #24
    21d8:      	fmla.4s	v7, v5, v16
    21dc:      	mov.16b	v16, v0
    21e0:      	fmla.4s	v16, v5, v7
    21e4:      	fdiv.4s	v5, v6, v16
    21e8:      	fcmge.4s	v6, v20, v4
    21ec:      	and.16b	v7, v6, v4
    21f0:      	fcmge.4s	v16, v7, v30
    21f4:      	fcmge.4s	v17, v1, v7
    21f8:      	and.16b	v16, v16, v17
    21fc:      	and.16b	v16, v16, v7
    2200:      	fmul.4s	v17, v16, v29
    2204:      	movi.4s	v18, #0x4b, lsl #24
    2208:      	fadd.4s	v17, v17, v18
    220c:      	movi.4s	v18, #0xcb, lsl #24
    2210:      	fadd.4s	v17, v17, v18
    2214:      	fcvtzs.4s	v17, v17
    2218:      	scvtf.4s	v18, v17
    221c:      	fmul.4s	v19, v18, v9
    2220:      	fadd.4s	v16, v16, v19
    2224:      	fmul.4s	v18, v18, v27
    2228:      	fadd.4s	v16, v16, v18
    222c:      	mov.16b	v22, v24
    2230:      	fmul.4s	v18, v16, v24
    2234:      	mov.16b	v24, v25
    2238:      	fadd.4s	v18, v18, v25
    223c:      	fmul.4s	v18, v16, v18
    2240:      	fadd.4s	v18, v18, v15
    2244:      	fmul.4s	v18, v16, v18
    2248:      	fadd.4s	v18, v18, v26
    224c:      	fmul.4s	v18, v16, v18
    2250:      	fadd.4s	v18, v18, v3
    2254:      	fmul.4s	v18, v16, v18
    2258:      	fadd.4s	v18, v18, v21
    225c:      	fmul.4s	v19, v16, v16
    2260:      	fmul.4s	v18, v19, v18
    2264:      	fadd.4s	v16, v16, v18
    2268:      	fadd.4s	v16, v16, v0
    226c:      	movi.2d	v18, #0xffffffffffffffff
    2270:      	add.4s	v17, v17, v18
    2274:      	sshr.4s	v18, v17, #0x1
    2278:      	shl.4s	v19, v18, #0x17
    227c:      	add.4s	v19, v19, v0
    2280:      	fmul.4s	v16, v16, v19
    2284:      	sub.4s	v17, v17, v18
    2288:      	shl.4s	v17, v17, #0x17
    228c:      	add.4s	v17, v17, v0
    2290:      	fmul.4s	v16, v16, v17
    2294:      	fcmgt.4s	v7, v7, v1
    2298:      	ldr	q17, [sp, #0x180]
    229c:      	bsl.16b	v7, v17, v16
    22a0:      	fdiv.4s	v16, v31, v7
    22a4:      	fsub.4s	v17, v7, v16
    22a8:      	fadd.4s	v7, v7, v16
    22ac:      	fdiv.4s	v7, v17, v7
    22b0:      	bsl.16b	v6, v7, v0
    22b4:      	fcmge.4s	v4, v0, v4
    22b8:      	bsl.16b	v4, v5, v6
    22bc:      	ldr	d5, [sp, #0x8]
    22c0:      	fmov	w9, s5
    22c4:      	mvni.4s	v5, #0x80, lsl #24
    22c8:      	bif.16b	v4, v2, v5
    22cc:      	fcmeq.4s	v2, v2, v2
    22d0:      	fadd.4s	v4, v4, v0
    22d4:      	ldr	q5, [sp, #0x170]
    22d8:      	bsl.16b	v2, v4, v5
    22dc:      	fmul.4s	v4, v8, v21
    22e0:      	fmul.4s	v2, v4, v2
    22e4:      	ldr	q4, [sp, #0x10]
    22e8:      	fadd.4s	v2, v2, v4
    22ec:      	ldr	q5, [sp, #0xa0]
    22f0:      	ldr	q4, [sp, #0xd0]
    22f4:      	stp	q5, q4, [sp, #0x2d0]
    22f8:      	ldr	q5, [sp, #0x30]
    22fc:      	ldr	q4, [sp, #0xb0]
    2300:      	stp	q5, q4, [sp, #0x2f0]
    2304:      	and	x11, x10, #0x7
    2308:      	add	x12, sp, #0x2d0
    230c:      	ldr	x11, [x12, x11, lsl #3]
    2310:      	sub	x10, x11, x10
    2314:      	add	x8, x8, x10, lsl #2
    2318:      	tbz	w9, #0x0, 0x233c <_llm_rows.packet_batch.blocks+0x1438>
    231c:      	str	s2, [x8]
    2320:      	ldr	q25, [sp, #0xc0]
    2324:      	tbnz	w9, #0x1, 0x2344 <_llm_rows.packet_batch.blocks+0x1440>
    2328:      	tbz	w9, #0x2, 0x2350 <_llm_rows.packet_batch.blocks+0x144c>
    232c:      	add	x10, x8, #0x8
    2330:      	st1.s	{ v2 }[2], [x10]
    2334:      	tbnz	w9, #0x3, 0x2354 <_llm_rows.packet_batch.blocks+0x1450>
    2338:      	b	0x235c <_llm_rows.packet_batch.blocks+0x1458>
    233c:      	ldr	q25, [sp, #0xc0]
    2340:      	tbz	w9, #0x1, 0x2328 <_llm_rows.packet_batch.blocks+0x1424>
    2344:      	add	x10, x8, #0x4
    2348:      	st1.s	{ v2 }[1], [x10]
    234c:      	tbnz	w9, #0x2, 0x232c <_llm_rows.packet_batch.blocks+0x1428>
    2350:      	tbz	w9, #0x3, 0x235c <_llm_rows.packet_batch.blocks+0x1458>
    2354:      	add	x10, x8, #0xc
    2358:      	st1.s	{ v2 }[3], [x10]
    235c:      	ldp	q2, q4, [sp, #0x190]
    2360:      	fmul.4s	v2, v25, v2
    2364:      	fmul.4s	v2, v25, v2
    2368:      	fmul.4s	v2, v25, v2
    236c:      	fadd.4s	v2, v25, v2
    2370:      	fmul.4s	v2, v2, v4
    2374:      	zip2.8b	v4, v28, v0
    2378:      	ushll.4s	v4, v4, #0x0
    237c:      	shl.4s	v4, v4, #0x1f
    2380:      	cmlt.4s	v4, v4, #0
    2384:      	and.16b	v2, v4, v2
    2388:      	fmul.4s	v4, v2, v2
    238c:      	ldp	q6, q5, [sp, #0x1b0]
    2390:      	fmla.4s	v5, v4, v6
    2394:      	ldr	q6, [sp, #0x1d0]
    2398:      	fmla.4s	v6, v4, v5
    239c:      	ldr	q5, [sp, #0x1e0]
    23a0:      	fmla.4s	v5, v4, v6
    23a4:      	ldp	q6, q16, [sp, #0x1f0]
    23a8:      	fmla.4s	v6, v4, v5
    23ac:      	mov.16b	v5, v3
    23b0:      	fmla.4s	v5, v4, v6
    23b4:      	mov.16b	v6, v0
    23b8:      	fmla.4s	v6, v4, v5
    23bc:      	ldr	q5, [sp, #0x210]
    23c0:      	fmla.4s	v16, v4, v5
    23c4:      	ldr	q7, [sp, #0x160]
    23c8:      	fmla.4s	v7, v4, v16
    23cc:      	ldr	q5, [sp, #0x220]
    23d0:      	fmla.4s	v5, v4, v7
    23d4:      	ldr	q7, [sp, #0x230]
    23d8:      	fmla.4s	v7, v4, v5
    23dc:      	movi.4s	v5, #0x3f, lsl #24
    23e0:      	fmla.4s	v5, v4, v7
    23e4:      	mov.16b	v7, v0
    23e8:      	fmla.4s	v7, v4, v5
    23ec:      	fabs.4s	v4, v2
    23f0:      	fmul.4s	v5, v4, v6
    23f4:      	fdiv.4s	v5, v5, v7
    23f8:      	fcmge.4s	v6, v20, v4
    23fc:      	and.16b	v7, v6, v4
    2400:      	fcmge.4s	v16, v7, v30
    2404:      	fcmge.4s	v17, v1, v7
    2408:      	and.16b	v16, v16, v17
    240c:      	and.16b	v16, v16, v7
    2410:      	fmul.4s	v17, v16, v29
    2414:      	movi.4s	v18, #0x4b, lsl #24
    2418:      	fadd.4s	v17, v17, v18
    241c:      	movi.4s	v18, #0xcb, lsl #24
    2420:      	fadd.4s	v17, v17, v18
    2424:      	fcvtzs.4s	v17, v17
    2428:      	scvtf.4s	v18, v17
    242c:      	fmul.4s	v19, v18, v9
    2430:      	fadd.4s	v16, v16, v19
    2434:      	fmul.4s	v18, v18, v27
    2438:      	fadd.4s	v16, v16, v18
    243c:      	fmul.4s	v18, v16, v22
    2440:      	fadd.4s	v18, v18, v24
    2444:      	fmul.4s	v18, v16, v18
    2448:      	fadd.4s	v18, v18, v15
    244c:      	fmul.4s	v18, v16, v18
    2450:      	fadd.4s	v18, v18, v26
    2454:      	fmul.4s	v18, v16, v18
    2458:      	fadd.4s	v3, v18, v3
    245c:      	fmul.4s	v3, v16, v3
    2460:      	fadd.4s	v3, v3, v21
    2464:      	fmul.4s	v18, v16, v16
    2468:      	fmul.4s	v3, v18, v3
    246c:      	fadd.4s	v3, v16, v3
    2470:      	fadd.4s	v3, v3, v0
    2474:      	movi.2d	v16, #0xffffffffffffffff
    2478:      	add.4s	v16, v17, v16
    247c:      	sshr.4s	v17, v16, #0x1
    2480:      	shl.4s	v18, v17, #0x17
    2484:      	add.4s	v18, v18, v0
    2488:      	fmul.4s	v3, v3, v18
    248c:      	sub.4s	v16, v16, v17
    2490:      	shl.4s	v16, v16, #0x17
    2494:      	add.4s	v16, v16, v0
    2498:      	fmul.4s	v3, v3, v16
    249c:      	fcmgt.4s	v1, v7, v1
    24a0:      	ldr	q7, [sp, #0x180]
    24a4:      	bsl.16b	v1, v7, v3
    24a8:      	fdiv.4s	v3, v31, v1
    24ac:      	fsub.4s	v7, v1, v3
    24b0:      	fadd.4s	v1, v1, v3
    24b4:      	fdiv.4s	v1, v7, v1
    24b8:      	bif.16b	v1, v0, v6
    24bc:      	fcmge.4s	v3, v0, v4
    24c0:      	bit.16b	v1, v5, v3
    24c4:      	mvni.4s	v3, #0x80, lsl #24
    24c8:      	bif.16b	v1, v2, v3
    24cc:      	fadd.4s	v0, v1, v0
    24d0:      	fcmeq.4s	v1, v2, v2
    24d4:      	ldr	q2, [sp, #0x170]
    24d8:      	bif.16b	v0, v2, v1
    24dc:      	fmul.4s	v1, v25, v21
    24e0:      	fmul.4s	v0, v1, v0
    24e4:      	ldr	q1, [sp, #0x20]
    24e8:      	fadd.4s	v0, v0, v1
    24ec:      	tbz	w9, #0x4, 0x2a8c <_llm_rows.packet_batch.blocks+0x1b88>
    24f0:      	str	s0, [x8, #0x10]
    24f4:      	tbnz	w9, #0x5, 0x2a90 <_llm_rows.packet_batch.blocks+0x1b8c>
    24f8:      	tbz	w9, #0x6, 0x2a9c <_llm_rows.packet_batch.blocks+0x1b98>
    24fc:      	add	x10, x8, #0x18
    2500:      	st1.s	{ v0 }[2], [x10]
    2504:      	tbnz	w9, #0x7, 0x2aa0 <_llm_rows.packet_batch.blocks+0x1b9c>
    2508:      	b	0xfdc <_llm_rows.packet_batch.blocks+0xd8>
    250c:      	xtn.8b	v2, v26
    2510:      	movi	d4, #0x0000000000ffff
    2514:      	and.8b	v10, v2, v4
    2518:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x10fc>
    251c:      	ldr	d4, [x10]
    2520:      	and.8b	v2, v2, v4
    2524:      	addv.8b	b2, v2
    2528:      	fmov	w12, s2
    252c:      	umaxv.8b	b2, v10
    2530:      	fmov	w10, s2
    2534:      	rbit	w13, w12
    2538:      	clz	w13, w13
    253c:      	tst	w10, #0x1
    2540:      	csel	w10, w13, wzr, ne
    2544:      	mov	w13, #0x600             ; =1536
    2548:      	dup.2d	v11, x13
    254c:      	ldr	d2, [sp, #0x130]
    2550:      	ldr	q4, [sp, #0xc0]
    2554:      	ldr	d5, [sp, #0xa0]
    2558:      	umlal.2d	v4, v5, v2
    255c:      	mov	b2, v10[0]
    2560:      	mov.b	v2[4], v10[1]
    2564:      	add.2d	v4, v4, v11
    2568:      	ushll.2d	v2, v2, #0x0
    256c:      	shl.2d	v2, v2, #0x3f
    2570:      	cmlt.2d	v2, v2, #0
    2574:      	str	q4, [sp, #0xc0]
    2578:      	and.16b	v2, v2, v4
    257c:      	movi.2d	v4, #0000000000000000
    2580:      	stp	q4, q4, [sp, #0x2a0]
    2584:      	stp	q2, q4, [sp, #0x280]
    2588:      	and	x13, x10, #0x7
    258c:      	add	x14, sp, #0x280
    2590:      	ldr	x13, [x14, x13, lsl #3]
    2594:      	sub	x13, x13, x10
    2598:      	lsl	x13, x13, #2
    259c:      	add	x11, x11, x13
    25a0:      	movi.2d	v14, #0000000000000000
    25a4:      	movi.2d	v8, #0000000000000000
    25a8:      	tbz	w12, #0x0, 0x25e8 <_llm_rows.packet_batch.blocks+0x16e4>
    25ac:      	ldr	s14, [x11]
    25b0:      	tbnz	w12, #0x1, 0x25ec <_llm_rows.packet_batch.blocks+0x16e8>
    25b4:      	tbz	w12, #0x2, 0x25f8 <_llm_rows.packet_batch.blocks+0x16f4>
    25b8:      	add	x14, x11, #0x8
    25bc:      	ld1.s	{ v14 }[2], [x14]
    25c0:      	tbnz	w12, #0x3, 0x25fc <_llm_rows.packet_batch.blocks+0x16f8>
    25c4:      	tbz	w12, #0x4, 0x2608 <_llm_rows.packet_batch.blocks+0x1704>
    25c8:      	add	x14, x11, #0x10
    25cc:      	ld1.s	{ v8 }[0], [x14]
    25d0:      	tbnz	w12, #0x5, 0x260c <_llm_rows.packet_batch.blocks+0x1708>
    25d4:      	tbz	w12, #0x6, 0x2618 <_llm_rows.packet_batch.blocks+0x1714>
    25d8:      	add	x14, x11, #0x18
    25dc:      	ld1.s	{ v8 }[2], [x14]
    25e0:      	tbnz	w12, #0x7, 0x261c <_llm_rows.packet_batch.blocks+0x1718>
    25e4:      	b	0x2624 <_llm_rows.packet_batch.blocks+0x1720>
    25e8:      	tbz	w12, #0x1, 0x25b4 <_llm_rows.packet_batch.blocks+0x16b0>
    25ec:      	add	x14, x11, #0x4
    25f0:      	ld1.s	{ v14 }[1], [x14]
    25f4:      	tbnz	w12, #0x2, 0x25b8 <_llm_rows.packet_batch.blocks+0x16b4>
    25f8:      	tbz	w12, #0x3, 0x25c4 <_llm_rows.packet_batch.blocks+0x16c0>
    25fc:      	add	x14, x11, #0xc
    2600:      	ld1.s	{ v14 }[3], [x14]
    2604:      	tbnz	w12, #0x4, 0x25c8 <_llm_rows.packet_batch.blocks+0x16c4>
    2608:      	tbz	w12, #0x5, 0x25d4 <_llm_rows.packet_batch.blocks+0x16d0>
    260c:      	add	x14, x11, #0x14
    2610:      	ld1.s	{ v8 }[1], [x14]
    2614:      	tbnz	w12, #0x6, 0x25d8 <_llm_rows.packet_batch.blocks+0x16d4>
    2618:      	tbz	w12, #0x7, 0x2624 <_llm_rows.packet_batch.blocks+0x1720>
    261c:      	add	x11, x11, #0x1c
    2620:      	ld1.s	{ v8 }[3], [x11]
    2624:      	adrp	x11, 0x2000 <_llm_rows.packet_batch.blocks+0x10fc>
    2628:      	ldr	d2, [x11]
    262c:      	shl.8b	v4, v10, #0x7
    2630:      	cmlt.8b	v4, v4, #0
    2634:      	and.8b	v2, v4, v2
    2638:      	addv.8b	b2, v2
    263c:      	str	d2, [sp, #0xa0]
    2640:      	fmov	w11, s2
    2644:      	add	x9, x9, x13
    2648:      	movi.2d	v4, #0000000000000000
    264c:      	movi.2d	v13, #0000000000000000
    2650:      	tbz	w11, #0x0, 0x28ac <_llm_rows.packet_batch.blocks+0x19a8>
    2654:      	ldr	s4, [x9]
    2658:      	tbnz	w11, #0x1, 0x28b0 <_llm_rows.packet_batch.blocks+0x19ac>
    265c:      	tbz	w11, #0x2, 0x28bc <_llm_rows.packet_batch.blocks+0x19b8>
    2660:      	add	x12, x9, #0x8
    2664:      	ld1.s	{ v4 }[2], [x12]
    2668:      	tbnz	w11, #0x3, 0x28c0 <_llm_rows.packet_batch.blocks+0x19bc>
    266c:      	tbz	w11, #0x4, 0x28cc <_llm_rows.packet_batch.blocks+0x19c8>
    2670:      	add	x12, x9, #0x10
    2674:      	ld1.s	{ v13 }[0], [x12]
    2678:      	tbnz	w11, #0x5, 0x28d0 <_llm_rows.packet_batch.blocks+0x19cc>
    267c:      	tbz	w11, #0x6, 0x2688 <_llm_rows.packet_batch.blocks+0x1784>
    2680:      	add	x12, x9, #0x18
    2684:      	ld1.s	{ v13 }[2], [x12]
    2688:      	ldr	q2, [sp, #0x140]
    268c:      	ldr	d6, [sp, #0x130]
    2690:      	ldr	d5, [sp, #0xd0]
    2694:      	umlal.2d	v2, v5, v6
    2698:      	str	q2, [sp, #0x140]
    269c:      	ldr	q2, [sp, #0x150]
    26a0:      	ldr	d5, [sp, #0xe0]
    26a4:      	umlal.2d	v2, v5, v6
    26a8:      	str	q2, [sp, #0x150]
    26ac:      	ldr	d2, [sp, #0xf0]
    26b0:      	ldr	q5, [sp, #0xb0]
    26b4:      	umlal.2d	v5, v2, v6
    26b8:      	mov.16b	v2, v5
    26bc:      	tbz	w11, #0x7, 0x26c8 <_llm_rows.packet_batch.blocks+0x17c4>
    26c0:      	add	x9, x9, #0x1c
    26c4:      	ld1.s	{ v13 }[3], [x9]
    26c8:      	ldp	q5, q6, [sp, #0x190]
    26cc:      	fmul.4s	v5, v14, v5
    26d0:      	fmul.4s	v5, v14, v5
    26d4:      	fmul.4s	v5, v14, v5
    26d8:      	fadd.4s	v5, v14, v5
    26dc:      	fmul.4s	v5, v5, v6
    26e0:      	zip1.8b	v6, v10, v0
    26e4:      	ushll.4s	v6, v6, #0x0
    26e8:      	shl.4s	v6, v6, #0x1f
    26ec:      	cmlt.4s	v6, v6, #0
    26f0:      	and.16b	v5, v6, v5
    26f4:      	fabs.4s	v6, v5
    26f8:      	fmul.4s	v7, v5, v5
    26fc:      	ldp	q17, q16, [sp, #0x1b0]
    2700:      	fmla.4s	v16, v7, v17
    2704:      	ldr	q17, [sp, #0x1d0]
    2708:      	fmla.4s	v17, v7, v16
    270c:      	ldr	q16, [sp, #0x1e0]
    2710:      	fmla.4s	v16, v7, v17
    2714:      	ldr	q17, [sp, #0x1f0]
    2718:      	fmla.4s	v17, v7, v16
    271c:      	mov.16b	v16, v3
    2720:      	fmla.4s	v16, v7, v17
    2724:      	mov.16b	v17, v0
    2728:      	fmla.4s	v17, v7, v16
    272c:      	fmul.4s	v16, v6, v17
    2730:      	ldp	q17, q18, [sp, #0x200]
    2734:      	fmla.4s	v17, v7, v18
    2738:      	fmla.4s	v23, v7, v17
    273c:      	ldp	q17, q18, [sp, #0x220]
    2740:      	fmla.4s	v17, v7, v23
    2744:      	fmla.4s	v18, v7, v17
    2748:      	movi.4s	v17, #0x3f, lsl #24
    274c:      	fmla.4s	v17, v7, v18
    2750:      	mov.16b	v18, v0
    2754:      	fmla.4s	v18, v7, v17
    2758:      	fdiv.4s	v7, v16, v18
    275c:      	mov.16b	v26, v20
    2760:      	fcmge.4s	v16, v20, v6
    2764:      	and.16b	v17, v16, v6
    2768:      	fcmge.4s	v18, v17, v30
    276c:      	fcmge.4s	v19, v1, v17
    2770:      	and.16b	v18, v18, v19
    2774:      	and.16b	v18, v18, v17
    2778:      	fmul.4s	v19, v18, v29
    277c:      	movi.4s	v23, #0x4b, lsl #24
    2780:      	fadd.4s	v19, v19, v23
    2784:      	movi.4s	v23, #0xcb, lsl #24
    2788:      	fadd.4s	v19, v19, v23
    278c:      	fcvtzs.4s	v19, v19
    2790:      	scvtf.4s	v15, v19
    2794:      	fmul.4s	v12, v15, v9
    2798:      	fadd.4s	v18, v18, v12
    279c:      	fmul.4s	v12, v15, v28
    27a0:      	fadd.4s	v18, v18, v12
    27a4:      	fmul.4s	v12, v18, v24
    27a8:      	fadd.4s	v12, v12, v22
    27ac:      	fmul.4s	v12, v18, v12
    27b0:      	fadd.4s	v12, v12, v27
    27b4:      	fmul.4s	v12, v18, v12
    27b8:      	fadd.4s	v12, v12, v25
    27bc:      	fmul.4s	v12, v18, v12
    27c0:      	fadd.4s	v12, v12, v3
    27c4:      	fmul.4s	v12, v18, v12
    27c8:      	fadd.4s	v12, v12, v21
    27cc:      	fmul.4s	v15, v18, v18
    27d0:      	fmul.4s	v12, v15, v12
    27d4:      	fadd.4s	v18, v18, v12
    27d8:      	fadd.4s	v18, v18, v0
    27dc:      	movi.2d	v23, #0xffffffffffffffff
    27e0:      	add.4s	v19, v19, v23
    27e4:      	sshr.4s	v12, v19, #0x1
    27e8:      	shl.4s	v15, v12, #0x17
    27ec:      	add.4s	v15, v15, v0
    27f0:      	fmul.4s	v18, v18, v15
    27f4:      	sub.4s	v19, v19, v12
    27f8:      	shl.4s	v19, v19, #0x17
    27fc:      	add.4s	v19, v19, v0
    2800:      	fmul.4s	v18, v18, v19
    2804:      	fcmgt.4s	v17, v17, v1
    2808:      	ldr	q19, [sp, #0x180]
    280c:      	bsl.16b	v17, v19, v18
    2810:      	fdiv.4s	v18, v31, v17
    2814:      	fsub.4s	v19, v17, v18
    2818:      	fadd.4s	v17, v17, v18
    281c:      	fdiv.4s	v17, v19, v17
    2820:      	bsl.16b	v16, v17, v0
    2824:      	fcmge.4s	v6, v0, v6
    2828:      	bsl.16b	v6, v7, v16
    282c:      	ldp	q7, q16, [sp, #0x140]
    2830:      	add.2d	v7, v7, v11
    2834:      	add.2d	v16, v16, v11
    2838:      	add.2d	v17, v2, v11
    283c:      	mvni.4s	v18, #0x80, lsl #24
    2840:      	bif.16b	v6, v5, v18
    2844:      	fcmeq.4s	v5, v5, v5
    2848:      	fadd.4s	v6, v6, v0
    284c:      	ldr	q18, [sp, #0x170]
    2850:      	bsl.16b	v5, v6, v18
    2854:      	fmul.4s	v6, v14, v21
    2858:      	fmul.4s	v5, v6, v5
    285c:      	fadd.4s	v4, v4, v5
    2860:      	ldr	q2, [sp, #0xc0]
    2864:      	stp	q2, q7, [sp, #0x240]
    2868:      	stp	q16, q17, [sp, #0x260]
    286c:      	ldr	d2, [sp, #0xa0]
    2870:      	fmov	w9, s2
    2874:      	and	x11, x10, #0x7
    2878:      	add	x12, sp, #0x240
    287c:      	ldr	x11, [x12, x11, lsl #3]
    2880:      	sub	x10, x11, x10
    2884:      	add	x8, x8, x10, lsl #2
    2888:      	tbz	w9, #0x0, 0x28e0 <_llm_rows.packet_batch.blocks+0x19dc>
    288c:      	str	s4, [x8]
    2890:      	tbnz	w9, #0x1, 0x28e4 <_llm_rows.packet_batch.blocks+0x19e0>
    2894:      	ldr	q7, [sp, #0x160]
    2898:      	tbz	w9, #0x2, 0x28f4 <_llm_rows.packet_batch.blocks+0x19f0>
    289c:      	add	x10, x8, #0x8
    28a0:      	st1.s	{ v4 }[2], [x10]
    28a4:      	tbnz	w9, #0x3, 0x28f8 <_llm_rows.packet_batch.blocks+0x19f4>
    28a8:      	b	0x2900 <_llm_rows.packet_batch.blocks+0x19fc>
    28ac:      	tbz	w11, #0x1, 0x265c <_llm_rows.packet_batch.blocks+0x1758>
    28b0:      	add	x12, x9, #0x4
    28b4:      	ld1.s	{ v4 }[1], [x12]
    28b8:      	tbnz	w11, #0x2, 0x2660 <_llm_rows.packet_batch.blocks+0x175c>
    28bc:      	tbz	w11, #0x3, 0x266c <_llm_rows.packet_batch.blocks+0x1768>
    28c0:      	add	x12, x9, #0xc
    28c4:      	ld1.s	{ v4 }[3], [x12]
    28c8:      	tbnz	w11, #0x4, 0x2670 <_llm_rows.packet_batch.blocks+0x176c>
    28cc:      	tbz	w11, #0x5, 0x267c <_llm_rows.packet_batch.blocks+0x1778>
    28d0:      	add	x12, x9, #0x14
    28d4:      	ld1.s	{ v13 }[1], [x12]
    28d8:      	tbnz	w11, #0x6, 0x2680 <_llm_rows.packet_batch.blocks+0x177c>
    28dc:      	b	0x2688 <_llm_rows.packet_batch.blocks+0x1784>
    28e0:      	tbz	w9, #0x1, 0x2894 <_llm_rows.packet_batch.blocks+0x1990>
    28e4:      	add	x10, x8, #0x4
    28e8:      	st1.s	{ v4 }[1], [x10]
    28ec:      	ldr	q7, [sp, #0x160]
    28f0:      	tbnz	w9, #0x2, 0x289c <_llm_rows.packet_batch.blocks+0x1998>
    28f4:      	tbz	w9, #0x3, 0x2900 <_llm_rows.packet_batch.blocks+0x19fc>
    28f8:      	add	x10, x8, #0xc
    28fc:      	st1.s	{ v4 }[3], [x10]
    2900:      	ldp	q2, q4, [sp, #0x190]
    2904:      	fmul.4s	v2, v8, v2
    2908:      	fmul.4s	v2, v8, v2
    290c:      	fmul.4s	v2, v8, v2
    2910:      	fadd.4s	v2, v8, v2
    2914:      	fmul.4s	v2, v2, v4
    2918:      	zip2.8b	v4, v10, v0
    291c:      	ushll.4s	v4, v4, #0x0
    2920:      	shl.4s	v4, v4, #0x1f
    2924:      	cmlt.4s	v4, v4, #0
    2928:      	and.16b	v2, v4, v2
    292c:      	fmul.4s	v4, v2, v2
    2930:      	ldp	q6, q5, [sp, #0x1b0]
    2934:      	fmla.4s	v5, v4, v6
    2938:      	ldr	q6, [sp, #0x1d0]
    293c:      	fmla.4s	v6, v4, v5
    2940:      	ldr	q5, [sp, #0x1e0]
    2944:      	fmla.4s	v5, v4, v6
    2948:      	ldp	q6, q16, [sp, #0x1f0]
    294c:      	fmla.4s	v6, v4, v5
    2950:      	mov.16b	v5, v3
    2954:      	fmla.4s	v5, v4, v6
    2958:      	mov.16b	v6, v0
    295c:      	fmla.4s	v6, v4, v5
    2960:      	ldr	q5, [sp, #0x210]
    2964:      	fmla.4s	v16, v4, v5
    2968:      	fmla.4s	v7, v4, v16
    296c:      	ldr	q5, [sp, #0x220]
    2970:      	fmla.4s	v5, v4, v7
    2974:      	ldr	q7, [sp, #0x230]
    2978:      	fmla.4s	v7, v4, v5
    297c:      	movi.4s	v5, #0x3f, lsl #24
    2980:      	fmla.4s	v5, v4, v7
    2984:      	mov.16b	v7, v0
    2988:      	fmla.4s	v7, v4, v5
    298c:      	fabs.4s	v4, v2
    2990:      	fmul.4s	v5, v4, v6
    2994:      	fdiv.4s	v5, v5, v7
    2998:      	fcmge.4s	v6, v26, v4
    299c:      	and.16b	v7, v6, v4
    29a0:      	fcmge.4s	v16, v7, v30
    29a4:      	fcmge.4s	v17, v1, v7
    29a8:      	and.16b	v16, v16, v17
    29ac:      	and.16b	v16, v16, v7
    29b0:      	fmul.4s	v17, v16, v29
    29b4:      	movi.4s	v18, #0x4b, lsl #24
    29b8:      	fadd.4s	v17, v17, v18
    29bc:      	movi.4s	v18, #0xcb, lsl #24
    29c0:      	fadd.4s	v17, v17, v18
    29c4:      	fcvtzs.4s	v17, v17
    29c8:      	scvtf.4s	v18, v17
    29cc:      	fmul.4s	v19, v18, v9
    29d0:      	fadd.4s	v16, v16, v19
    29d4:      	fmul.4s	v18, v18, v28
    29d8:      	fadd.4s	v16, v16, v18
    29dc:      	fmul.4s	v18, v16, v24
    29e0:      	fadd.4s	v18, v18, v22
    29e4:      	fmul.4s	v18, v16, v18
    29e8:      	fadd.4s	v18, v18, v27
    29ec:      	fmul.4s	v18, v16, v18
    29f0:      	fadd.4s	v18, v18, v25
    29f4:      	fmul.4s	v18, v16, v18
    29f8:      	fadd.4s	v3, v18, v3
    29fc:      	fmul.4s	v3, v16, v3
    2a00:      	fadd.4s	v3, v3, v21
    2a04:      	fmul.4s	v18, v16, v16
    2a08:      	fmul.4s	v3, v18, v3
    2a0c:      	fadd.4s	v3, v16, v3
    2a10:      	fadd.4s	v3, v3, v0
    2a14:      	movi.2d	v16, #0xffffffffffffffff
    2a18:      	add.4s	v16, v17, v16
    2a1c:      	sshr.4s	v17, v16, #0x1
    2a20:      	shl.4s	v18, v17, #0x17
    2a24:      	add.4s	v18, v18, v0
    2a28:      	fmul.4s	v3, v3, v18
    2a2c:      	sub.4s	v16, v16, v17
    2a30:      	shl.4s	v16, v16, #0x17
    2a34:      	add.4s	v16, v16, v0
    2a38:      	fmul.4s	v3, v3, v16
    2a3c:      	fcmgt.4s	v1, v7, v1
    2a40:      	ldr	q7, [sp, #0x180]
    2a44:      	bsl.16b	v1, v7, v3
    2a48:      	fdiv.4s	v3, v31, v1
    2a4c:      	fsub.4s	v7, v1, v3
    2a50:      	fadd.4s	v1, v1, v3
    2a54:      	fdiv.4s	v1, v7, v1
    2a58:      	bif.16b	v1, v0, v6
    2a5c:      	fcmge.4s	v3, v0, v4
    2a60:      	bit.16b	v1, v5, v3
    2a64:      	mvni.4s	v3, #0x80, lsl #24
    2a68:      	bif.16b	v1, v2, v3
    2a6c:      	fadd.4s	v0, v1, v0
    2a70:      	fcmeq.4s	v1, v2, v2
    2a74:      	ldr	q2, [sp, #0x170]
    2a78:      	bif.16b	v0, v2, v1
    2a7c:      	fmul.4s	v1, v8, v21
    2a80:      	fmul.4s	v0, v1, v0
    2a84:      	fadd.4s	v0, v13, v0
    2a88:      	tbnz	w9, #0x4, 0x24f0 <_llm_rows.packet_batch.blocks+0x15ec>
    2a8c:      	tbz	w9, #0x5, 0x24f8 <_llm_rows.packet_batch.blocks+0x15f4>
    2a90:      	add	x10, x8, #0x14
    2a94:      	st1.s	{ v0 }[1], [x10]
    2a98:      	tbnz	w9, #0x6, 0x24fc <_llm_rows.packet_batch.blocks+0x15f8>
    2a9c:      	tbz	w9, #0x7, 0xfdc <_llm_rows.packet_batch.blocks+0xd8>
    2aa0:      	add	x8, x8, #0x1c
    2aa4:      	st1.s	{ v0 }[3], [x8]
    2aa8:      	b	0xfdc <_llm_rows.packet_batch.blocks+0xd8>
    2aac:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    2ab0:      	add	sp, sp, #0x3f0
    2ab4:      	ldp	x29, x30, [sp, #0x90]
    2ab8:      	ldp	x20, x19, [sp, #0x80]
    2abc:      	ldp	x22, x21, [sp, #0x70]
    2ac0:      	ldp	x24, x23, [sp, #0x60]
    2ac4:      	ldp	x26, x25, [sp, #0x50]
    2ac8:      	ldp	x28, x27, [sp, #0x40]
    2acc:      	ldp	d9, d8, [sp, #0x30]
    2ad0:      	ldp	d11, d10, [sp, #0x20]
    2ad4:      	ldp	d13, d12, [sp, #0x10]
    2ad8:      	ldp	d15, d14, [sp], #0xa0
    2adc:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/gelu_residual-257x1538/off/object/tile_xir_w8_38048_1788936544733999_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x90]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x26, x25, [sp, #0x40]
      14:      	stp	x24, x23, [sp, #0x50]
      18:      	stp	x22, x21, [sp, #0x60]
      1c:      	stp	x20, x19, [sp, #0x70]
      20:      	stp	x29, x30, [sp, #0x80]
      24:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      28:      	sub	sp, sp, #0x160
      2c:      	ldr	x22, [x0]
      30:      	ldr	x21, [x0, #0x10]
      34:      	ldr	x19, [x0, #0x30]
      38:      	ldr	w8, [x1]
      3c:      	ldr	w9, [x1, #0x24]
      40:      	add	w8, w9, w8, lsl #5
      44:      	lsr	w8, w8, #3
      48:      	dup.2s	v0, w8
      4c:      	ushll.2d	v0, v0, #0x0
      50:      	subs	x8, x22, x19
      54:      	mov	w9, #0x2007             ; =8199
      58:      	movk	w9, #0x18, lsl #16
      5c:      	ccmp	x8, x9, #0x0, hs
      60:      	cset	w8, hi
      64:      	subs	x10, x19, x22
      68:      	ccmp	x10, x9, #0x0, hs
      6c:      	csinc	w10, w8, wzr, ls
      70:      	subs	x8, x21, x19
      74:      	ccmp	x8, x9, #0x0, hs
      78:      	cset	w8, hi
      7c:      	subs	x11, x19, x21
      80:      	ccmp	x11, x9, #0x0, hs
      84:      	csinc	w9, w8, wzr, ls
      88:      	fmov	x8, d0
      8c:      	mov	w11, #0x1808            ; =6152
      90:      	umull	x8, w8, w11
      94:      	cmp	w10, #0x1
      98:      	ccmp	w9, #0x0, #0x4, eq
      9c:      	b.ne	0x7e8 <ltmp0+0x7e8>
      a0:      	mov	w20, #0x1800            ; =6144
      a4:      	add	x23, sp, #0x1, lsl #12  ; =0x1000
      a8:      	add	x23, x23, #0x940
      ac:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
      b0:      	add	x0, x0, #0x940
      b4:      	add	x1, x22, x8
      b8:      	mov	w2, #0x1800             ; =6144
      bc:      	str	q0, [sp, #0x110]
      c0:      	bl	0xc0 <ltmp0+0xc0>
      c4:      	ldr	q0, [sp, #0x110]
      c8:      	fmov	x24, d0
      cc:      	mov	w25, #0x1808            ; =6152
      d0:      	umaddl	x20, w24, w25, x20
      d4:      	add	x8, x22, x20
      d8:      	add	x9, x8, #0x4
      dc:      	ldr	s0, [x8]
      e0:      	ld1.s	{ v0 }[1], [x9]
      e4:      	str	q0, [sp]
      e8:      	str	q0, [sp, #0x3140]
      ec:      	umaddl	x1, w24, w25, x21
      f0:      	add	x22, sp, #0x120
      f4:      	add	x0, sp, #0x120
      f8:      	mov	w2, #0x1800             ; =6144
      fc:      	bl	0xfc <ltmp0+0xfc>
     100:      	mov	x8, #0x0                ; =0
     104:      	add	x9, x21, x20
     108:      	ldr	s0, [x9], #0x4
     10c:      	ld1.s	{ v0 }[1], [x9]
     110:      	str	q0, [sp, #0x10]
     114:      	str	q0, [sp, #0x1920]
     118:      	umaddl	x9, w24, w25, x19
     11c:      	mov	w10, #0x2713            ; =10003
     120:      	movk	w10, #0x3d37, lsl #16
     124:      	dup.4s	v1, w10
     128:      	mov	w10, #0x422a            ; =16938
     12c:      	movk	w10, #0x3f4c, lsl #16
     130:      	dup.4s	v0, w10
     134:      	stp	q0, q1, [sp, #0xf0]
     138:      	fmov.4s	v18, #1.00000000
     13c:      	mov	w10, #0x9231            ; =37425
     140:      	movk	w10, #0x2f30, lsl #16
     144:      	dup.4s	v1, w10
     148:      	mov	w10, #0x322b            ; =12843
     14c:      	movk	w10, #0x32d7, lsl #16
     150:      	dup.4s	v0, w10
     154:      	stp	q0, q1, [sp, #0xd0]
     158:      	mov	w10, #0xef1d            ; =61213
     15c:      	movk	w10, #0x3638, lsl #16
     160:      	dup.4s	v1, w10
     164:      	mov	w10, #0xd01             ; =3329
     168:      	movk	w10, #0x3950, lsl #16
     16c:      	dup.4s	v0, w10
     170:      	stp	q0, q1, [sp, #0xb0]
     174:      	mov	w10, #0x8889            ; =34953
     178:      	movk	w10, #0x3c08, lsl #16
     17c:      	dup.4s	v1, w10
     180:      	mov	w10, #0xaaab            ; =43691
     184:      	movk	w10, #0x3e2a, lsl #16
     188:      	dup.4s	v21, w10
     18c:      	mov	w10, #0x76c7            ; =30407
     190:      	movk	w10, #0x310f, lsl #16
     194:      	dup.4s	v0, w10
     198:      	stp	q0, q1, [sp, #0x90]
     19c:      	mov	w10, #0xf27e            ; =62078
     1a0:      	movk	w10, #0x3493, lsl #16
     1a4:      	dup.4s	v1, w10
     1a8:      	mov	w10, #0xd01             ; =3329
     1ac:      	movk	w10, #0x37d0, lsl #16
     1b0:      	dup.4s	v0, w10
     1b4:      	stp	q0, q1, [sp, #0x70]
     1b8:      	mov	w10, #0xb61             ; =2913
     1bc:      	movk	w10, #0x3ab6, lsl #16
     1c0:      	dup.4s	v1, w10
     1c4:      	mov	w10, #0xaaab            ; =43691
     1c8:      	movk	w10, #0x3d2a, lsl #16
     1cc:      	dup.4s	v0, w10
     1d0:      	stp	q0, q1, [sp, #0x50]
     1d4:      	mov	w10, #-0x3d300000       ; =-1026555904
     1d8:      	dup.4s	v1, w10
     1dc:      	mov	w10, #0x42c80000        ; =1120403456
     1e0:      	dup.4s	v26, w10
     1e4:      	fmov.4s	v0, #9.00000000
     1e8:      	str	q0, [sp, #0x110]
     1ec:      	mov	w10, #0xaa3b            ; =43579
     1f0:      	movk	w10, #0x3fb8, lsl #16
     1f4:      	dup.4s	v0, w10
     1f8:      	stp	q0, q1, [sp, #0x30]
     1fc:      	mov	w10, #0x7200            ; =29184
     200:      	movk	w10, #0xbf31, lsl #16
     204:      	dup.4s	v0, w10
     208:      	str	q0, [sp, #0x20]
     20c:      	mov	w10, #0xbe8e            ; =48782
     210:      	movk	w10, #0xb5bf, lsl #16
     214:      	dup.4s	v31, w10
     218:      	mov	w10, #0x2bda            ; =11226
     21c:      	movk	w10, #0x3950, lsl #16
     220:      	dup.4s	v8, w10
     224:      	mov	w10, #0x96c9            ; =38601
     228:      	movk	w10, #0x3ab6, lsl #16
     22c:      	dup.4s	v9, w10
     230:      	mov	w10, #0x88a6            ; =34982
     234:      	movk	w10, #0x3c08, lsl #16
     238:      	dup.4s	v10, w10
     23c:      	mov	w10, #0xaa7a            ; =43642
     240:      	movk	w10, #0x3d2a, lsl #16
     244:      	dup.4s	v11, w10
     248:      	mvni.4s	v1, #0x7f, msl #16
     24c:      	fneg.4s	v13, v1
     250:      	mvni.4s	v1, #0x3f, msl #16
     254:      	fneg.4s	v15, v1
     258:      	lsl	x10, x8, #5
     25c:      	add	x11, x23, x10
     260:      	ldp	q28, q29, [x11]
     264:      	ldp	q0, q3, [sp, #0xf0]
     268:      	fmul.4s	v1, v28, v3
     26c:      	fmul.4s	v2, v29, v3
     270:      	fmul.4s	v2, v29, v2
     274:      	fmul.4s	v1, v28, v1
     278:      	fmul.4s	v1, v28, v1
     27c:      	fmul.4s	v2, v29, v2
     280:      	fadd.4s	v2, v29, v2
     284:      	fadd.4s	v1, v28, v1
     288:      	fmul.4s	v14, v1, v0
     28c:      	fmul.4s	v12, v2, v0
     290:      	fabs.4s	v3, v12
     294:      	fabs.4s	v2, v14
     298:      	fmul.4s	v17, v14, v14
     29c:      	ldp	q4, q0, [sp, #0xd0]
     2a0:      	mov.16b	v1, v4
     2a4:      	fmul.4s	v20, v12, v12
     2a8:      	fmla.4s	v1, v17, v0
     2ac:      	fmla.4s	v4, v20, v0
     2b0:      	ldp	q0, q6, [sp, #0xb0]
     2b4:      	mov.16b	v5, v6
     2b8:      	fmla.4s	v5, v17, v1
     2bc:      	fmla.4s	v6, v20, v4
     2c0:      	mov.16b	v4, v0
     2c4:      	fmla.4s	v4, v17, v5
     2c8:      	mov.16b	v5, v0
     2cc:      	ldr	q0, [sp, #0xa0]
     2d0:      	mov.16b	v7, v0
     2d4:      	fmla.4s	v5, v20, v6
     2d8:      	mov.16b	v6, v0
     2dc:      	mov.16b	v19, v21
     2e0:      	mov.16b	v16, v21
     2e4:      	mov.16b	v1, v18
     2e8:      	mov.16b	v25, v18
     2ec:      	fmla.4s	v7, v17, v4
     2f0:      	ldp	q22, q0, [sp, #0x80]
     2f4:      	mov.16b	v4, v22
     2f8:      	fmla.4s	v4, v20, v0
     2fc:      	fmla.4s	v22, v17, v0
     300:      	ldr	q0, [sp, #0x70]
     304:      	mov.16b	v23, v0
     308:      	fmla.4s	v6, v20, v5
     30c:      	fmla.4s	v23, v20, v4
     310:      	mov.16b	v4, v0
     314:      	fmla.4s	v4, v17, v22
     318:      	ldp	q22, q0, [sp, #0x50]
     31c:      	mov.16b	v5, v0
     320:      	fmla.4s	v5, v20, v23
     324:      	fmla.4s	v19, v17, v7
     328:      	mov.16b	v7, v0
     32c:      	fmla.4s	v7, v17, v4
     330:      	mov.16b	v4, v22
     334:      	fmla.4s	v4, v20, v5
     338:      	fmla.4s	v16, v20, v6
     33c:      	fmla.4s	v22, v17, v7
     340:      	movi.4s	v23, #0x3f, lsl #24
     344:      	fmla.4s	v23, v20, v4
     348:      	movi.4s	v24, #0x3f, lsl #24
     34c:      	mov.16b	v6, v18
     350:      	fmla.4s	v25, v20, v16
     354:      	mov.16b	v0, v18
     358:      	ldr	q5, [sp, #0x110]
     35c:      	fcmge.4s	v4, v5, v2
     360:      	fcmge.4s	v5, v5, v3
     364:      	and.16b	v7, v5, v3
     368:      	and.16b	v16, v4, v2
     36c:      	fmla.4s	v6, v20, v23
     370:      	ldr	q23, [sp, #0x40]
     374:      	fcmge.4s	v20, v16, v23
     378:      	fcmge.4s	v23, v7, v23
     37c:      	fcmge.4s	v27, v26, v7
     380:      	and.16b	v23, v23, v27
     384:      	fcmge.4s	v27, v26, v16
     388:      	fmla.4s	v24, v17, v22
     38c:      	and.16b	v20, v20, v27
     390:      	and.16b	v20, v20, v16
     394:      	and.16b	v22, v23, v7
     398:      	ldr	q27, [sp, #0x30]
     39c:      	fmul.4s	v23, v22, v27
     3a0:      	fmul.4s	v27, v20, v27
     3a4:      	fmla.4s	v1, v17, v19
     3a8:      	movi.4s	v30, #0x4b, lsl #24
     3ac:      	fadd.4s	v19, v27, v30
     3b0:      	fadd.4s	v23, v23, v30
     3b4:      	movi.4s	v27, #0xcb, lsl #24
     3b8:      	fadd.4s	v23, v23, v27
     3bc:      	fadd.4s	v19, v19, v27
     3c0:      	fcvtzs.4s	v19, v19
     3c4:      	fmla.4s	v0, v17, v24
     3c8:      	fcvtzs.4s	v23, v23
     3cc:      	scvtf.4s	v17, v23
     3d0:      	scvtf.4s	v24, v19
     3d4:      	ldr	q30, [sp, #0x20]
     3d8:      	fmul.4s	v27, v17, v30
     3dc:      	fadd.4s	v22, v22, v27
     3e0:      	fmul.4s	v27, v24, v30
     3e4:      	fadd.4s	v20, v20, v27
     3e8:      	fmul.4s	v17, v17, v31
     3ec:      	fmul.4s	v24, v24, v31
     3f0:      	fadd.4s	v20, v20, v24
     3f4:      	fadd.4s	v22, v22, v17
     3f8:      	fmul.4s	v17, v22, v8
     3fc:      	fmul.4s	v24, v20, v8
     400:      	fadd.4s	v24, v24, v9
     404:      	fadd.4s	v17, v17, v9
     408:      	fmul.4s	v17, v22, v17
     40c:      	fmul.4s	v24, v20, v24
     410:      	fmul.4s	v1, v2, v1
     414:      	fadd.4s	v24, v24, v10
     418:      	fadd.4s	v17, v17, v10
     41c:      	fmul.4s	v27, v22, v17
     420:      	fmul.4s	v17, v20, v24
     424:      	fadd.4s	v24, v17, v11
     428:      	fdiv.4s	v17, v1, v0
     42c:      	fadd.4s	v0, v27, v11
     430:      	fmul.4s	v0, v22, v0
     434:      	fmul.4s	v1, v20, v24
     438:      	fadd.4s	v1, v1, v21
     43c:      	fadd.4s	v0, v0, v21
     440:      	fmul.4s	v0, v22, v0
     444:      	fmul.4s	v1, v20, v1
     448:      	movi.4s	v27, #0x3f, lsl #24
     44c:      	fadd.4s	v1, v1, v27
     450:      	fadd.4s	v0, v0, v27
     454:      	fmul.4s	v24, v22, v22
     458:      	fmul.4s	v0, v24, v0
     45c:      	fmul.4s	v24, v20, v20
     460:      	fmul.4s	v1, v24, v1
     464:      	fadd.4s	v1, v20, v1
     468:      	fadd.4s	v0, v22, v0
     46c:      	fadd.4s	v0, v0, v18
     470:      	movi.2d	v20, #0xffffffffffffffff
     474:      	add.4s	v19, v19, v20
     478:      	fadd.4s	v1, v1, v18
     47c:      	add.4s	v20, v23, v20
     480:      	sshr.4s	v22, v20, #0x1
     484:      	sshr.4s	v23, v19, #0x1
     488:      	shl.4s	v24, v23, #0x17
     48c:      	add.4s	v24, v24, v18
     490:      	fmul.4s	v1, v1, v24
     494:      	shl.4s	v24, v22, #0x17
     498:      	add.4s	v24, v24, v18
     49c:      	fmul.4s	v0, v0, v24
     4a0:      	sub.4s	v19, v19, v23
     4a4:      	sub.4s	v20, v20, v22
     4a8:      	shl.4s	v20, v20, #0x17
     4ac:      	add.4s	v20, v20, v18
     4b0:      	fmul.4s	v0, v0, v20
     4b4:      	shl.4s	v19, v19, #0x17
     4b8:      	add.4s	v19, v19, v18
     4bc:      	fmul.4s	v1, v1, v19
     4c0:      	fmul.4s	v19, v3, v25
     4c4:      	fcmgt.4s	v7, v7, v26
     4c8:      	fcmgt.4s	v16, v16, v26
     4cc:      	bsl.16b	v16, v13, v1
     4d0:      	bit.16b	v0, v13, v7
     4d4:      	fmov.4s	v1, #0.25000000
     4d8:      	fdiv.4s	v6, v19, v6
     4dc:      	fdiv.4s	v7, v1, v0
     4e0:      	fsub.4s	v19, v0, v7
     4e4:      	fadd.4s	v0, v0, v7
     4e8:      	fdiv.4s	v0, v19, v0
     4ec:      	bif.16b	v0, v18, v5
     4f0:      	fcmge.4s	v3, v18, v3
     4f4:      	bit.16b	v0, v6, v3
     4f8:      	fdiv.4s	v3, v1, v16
     4fc:      	fsub.4s	v5, v16, v3
     500:      	fadd.4s	v3, v16, v3
     504:      	fdiv.4s	v3, v5, v3
     508:      	bif.16b	v3, v18, v4
     50c:      	fcmge.4s	v2, v18, v2
     510:      	bsl.16b	v2, v17, v3
     514:      	mvni.4s	v4, #0x80, lsl #24
     518:      	bif.16b	v2, v14, v4
     51c:      	fcmeq.4s	v3, v14, v14
     520:      	fadd.4s	v2, v2, v18
     524:      	bif.16b	v2, v15, v3
     528:      	bif.16b	v0, v12, v4
     52c:      	fcmeq.4s	v3, v12, v12
     530:      	fadd.4s	v0, v0, v18
     534:      	bif.16b	v0, v15, v3
     538:      	fmul.4s	v3, v29, v27
     53c:      	fmul.4s	v0, v3, v0
     540:      	fmul.4s	v3, v28, v27
     544:      	fmul.4s	v2, v3, v2
     548:      	add	x11, x22, x10
     54c:      	ldp	q4, q3, [x11]
     550:      	fadd.4s	v2, v4, v2
     554:      	fadd.4s	v0, v3, v0
     558:      	add	x10, x9, x10
     55c:      	stp	q2, q0, [x10]
     560:      	add	x8, x8, #0x1
     564:      	cmp	x8, #0xc0
     568:      	b.ne	0x258 <ltmp0+0x258>
     56c:      	movi.2d	v2, #0000000000000000
     570:      	movi.2d	v3, #0000000000000000
     574:      	ldr	q4, [sp]
     578:      	mov.d	v3[0], v4[0]
     57c:      	mov	w8, #0x2713             ; =10003
     580:      	movk	w8, #0x3d37, lsl #16
     584:      	dup.4s	v0, w8
     588:      	fmul.4s	v0, v3, v0
     58c:      	fmul.4s	v0, v4, v0
     590:      	fmul.4s	v0, v4, v0
     594:      	fadd.4s	v0, v4, v0
     598:      	mov	w8, #0x422a             ; =16938
     59c:      	movk	w8, #0x3f4c, lsl #16
     5a0:      	dup.4s	v4, w8
     5a4:      	fmul.4s	v0, v0, v4
     5a8:      	mov.d	v2[0], v0[0]
     5ac:      	fabs.4s	v4, v2
     5b0:      	fmul.4s	v5, v2, v2
     5b4:      	mov	w8, #0x9231             ; =37425
     5b8:      	movk	w8, #0x2f30, lsl #16
     5bc:      	dup.4s	v0, w8
     5c0:      	mov	w8, #0x322b             ; =12843
     5c4:      	movk	w8, #0x32d7, lsl #16
     5c8:      	dup.4s	v6, w8
     5cc:      	mov	w8, #0xef1d             ; =61213
     5d0:      	movk	w8, #0x3638, lsl #16
     5d4:      	dup.4s	v7, w8
     5d8:      	fmla.4s	v6, v5, v0
     5dc:      	fmla.4s	v7, v5, v6
     5e0:      	mov	w8, #0xd01              ; =3329
     5e4:      	movk	w8, #0x3950, lsl #16
     5e8:      	dup.4s	v6, w8
     5ec:      	fmla.4s	v6, v5, v7
     5f0:      	mov	w8, #0x8889             ; =34953
     5f4:      	movk	w8, #0x3c08, lsl #16
     5f8:      	dup.4s	v17, w8
     5fc:      	mov	w8, #0xaaab             ; =43691
     600:      	movk	w8, #0x3e2a, lsl #16
     604:      	dup.4s	v0, w8
     608:      	fmla.4s	v17, v5, v6
     60c:      	ldr	q6, [sp, #0x110]
     610:      	fcmge.4s	v6, v6, v4
     614:      	and.16b	v7, v6, v4
     618:      	mov	w8, #-0x3d300000        ; =-1026555904
     61c:      	dup.4s	v16, w8
     620:      	fcmge.4s	v19, v7, v16
     624:      	mov	w8, #0x42c80000         ; =1120403456
     628:      	dup.4s	v16, w8
     62c:      	fcmge.4s	v20, v16, v7
     630:      	and.16b	v19, v19, v20
     634:      	and.16b	v19, v19, v7
     638:      	mov	w8, #0xaa3b             ; =43579
     63c:      	movk	w8, #0x3fb8, lsl #16
     640:      	dup.4s	v20, w8
     644:      	fmul.4s	v20, v19, v20
     648:      	movi.4s	v21, #0x4b, lsl #24
     64c:      	fadd.4s	v20, v20, v21
     650:      	movi.4s	v21, #0xcb, lsl #24
     654:      	fadd.4s	v20, v20, v21
     658:      	fcvtzs.4s	v20, v20
     65c:      	scvtf.4s	v21, v20
     660:      	mov	w8, #0x7200             ; =29184
     664:      	movk	w8, #0xbf31, lsl #16
     668:      	dup.4s	v22, w8
     66c:      	fmul.4s	v22, v21, v22
     670:      	mov	w8, #0xbe8e             ; =48782
     674:      	movk	w8, #0xb5bf, lsl #16
     678:      	dup.4s	v23, w8
     67c:      	fadd.4s	v19, v19, v22
     680:      	fmul.4s	v21, v21, v23
     684:      	fadd.4s	v19, v19, v21
     688:      	mov	w8, #0x2bda             ; =11226
     68c:      	movk	w8, #0x3950, lsl #16
     690:      	dup.4s	v21, w8
     694:      	fmul.4s	v21, v19, v21
     698:      	mov	w8, #0x96c9             ; =38601
     69c:      	movk	w8, #0x3ab6, lsl #16
     6a0:      	dup.4s	v22, w8
     6a4:      	fadd.4s	v21, v21, v22
     6a8:      	fmul.4s	v21, v19, v21
     6ac:      	mov	w8, #0x88a6             ; =34982
     6b0:      	movk	w8, #0x3c08, lsl #16
     6b4:      	dup.4s	v22, w8
     6b8:      	fadd.4s	v21, v21, v22
     6bc:      	fmul.4s	v21, v19, v21
     6c0:      	mov	w8, #0xaa7a             ; =43642
     6c4:      	movk	w8, #0x3d2a, lsl #16
     6c8:      	dup.4s	v22, w8
     6cc:      	fadd.4s	v21, v21, v22
     6d0:      	fmul.4s	v21, v19, v21
     6d4:      	fadd.4s	v21, v21, v0
     6d8:      	fmla.4s	v0, v5, v17
     6dc:      	mov.16b	v17, v18
     6e0:      	fmla.4s	v17, v5, v0
     6e4:      	mov	w8, #0x76c7             ; =30407
     6e8:      	movk	w8, #0x310f, lsl #16
     6ec:      	dup.4s	v0, w8
     6f0:      	mov	w8, #0xf27e             ; =62078
     6f4:      	movk	w8, #0x3493, lsl #16
     6f8:      	dup.4s	v22, w8
     6fc:      	mov	w8, #0xd01              ; =3329
     700:      	movk	w8, #0x37d0, lsl #16
     704:      	dup.4s	v23, w8
     708:      	fmla.4s	v22, v5, v0
     70c:      	fmla.4s	v23, v5, v22
     710:      	mov	w8, #0xb61              ; =2913
     714:      	movk	w8, #0x3ab6, lsl #16
     718:      	dup.4s	v0, w8
     71c:      	fmla.4s	v0, v5, v23
     720:      	mov	w8, #0xaaab             ; =43691
     724:      	movk	w8, #0x3d2a, lsl #16
     728:      	dup.4s	v22, w8
     72c:      	fmla.4s	v22, v5, v0
     730:      	movi.4s	v0, #0x3f, lsl #24
     734:      	fmla.4s	v0, v5, v22
     738:      	mov.16b	v22, v18
     73c:      	fmla.4s	v22, v5, v0
     740:      	movi.4s	v0, #0x3f, lsl #24
     744:      	fmul.4s	v3, v3, v0
     748:      	fcmge.4s	v5, v18, v4
     74c:      	fmul.4s	v4, v4, v17
     750:      	fdiv.4s	v4, v4, v22
     754:      	fmul.4s	v17, v19, v21
     758:      	fadd.4s	v0, v17, v0
     75c:      	fmul.4s	v17, v19, v19
     760:      	fmul.4s	v0, v17, v0
     764:      	fadd.4s	v0, v19, v0
     768:      	fadd.4s	v0, v0, v18
     76c:      	movi.2d	v17, #0xffffffffffffffff
     770:      	add.4s	v17, v20, v17
     774:      	sshr.4s	v19, v17, #0x1
     778:      	shl.4s	v20, v19, #0x17
     77c:      	add.4s	v20, v20, v18
     780:      	fmul.4s	v0, v0, v20
     784:      	sub.4s	v17, v17, v19
     788:      	shl.4s	v17, v17, #0x17
     78c:      	add.4s	v17, v17, v18
     790:      	fmul.4s	v0, v0, v17
     794:      	fcmgt.4s	v7, v7, v16
     798:      	mvni.4s	v16, #0x7f, msl #16
     79c:      	fneg.4s	v16, v16
     7a0:      	bit.16b	v0, v16, v7
     7a4:      	fdiv.4s	v1, v1, v0
     7a8:      	fsub.4s	v7, v0, v1
     7ac:      	fadd.4s	v0, v0, v1
     7b0:      	fdiv.4s	v0, v7, v0
     7b4:      	bif.16b	v0, v18, v6
     7b8:      	bit.16b	v0, v4, v5
     7bc:      	mvni.4s	v1, #0x80, lsl #24
     7c0:      	bif.16b	v0, v2, v1
     7c4:      	fcmeq.4s	v1, v2, v2
     7c8:      	fadd.4s	v0, v0, v18
     7cc:      	mvni.4s	v2, #0x3f, msl #16
     7d0:      	fneg.4s	v2, v2
     7d4:      	bif.16b	v0, v2, v1
     7d8:      	fmul.4s	v0, v3, v0
     7dc:      	ldr	q1, [sp, #0x10]
     7e0:      	fadd.4s	v0, v0, v1
     7e4:      	b	0xee0 <ltmp0+0xee0>
     7e8:      	mov	x9, #0x0                ; =0
     7ec:      	add	x10, x19, x8
     7f0:      	add	x11, x21, x8
     7f4:      	mov	w12, #0x2713            ; =10003
     7f8:      	movk	w12, #0x3d37, lsl #16
     7fc:      	dup.4s	v1, w12
     800:      	mov	w12, #0x422a            ; =16938
     804:      	movk	w12, #0x3f4c, lsl #16
     808:      	dup.4s	v0, w12
     80c:      	stp	q0, q1, [sp, #0xf0]
     810:      	mov	w12, #0x9231            ; =37425
     814:      	movk	w12, #0x2f30, lsl #16
     818:      	dup.4s	v1, w12
     81c:      	mov	w12, #0x322b            ; =12843
     820:      	movk	w12, #0x32d7, lsl #16
     824:      	dup.4s	v0, w12
     828:      	stp	q0, q1, [sp, #0xd0]
     82c:      	mov	w12, #0xef1d            ; =61213
     830:      	movk	w12, #0x3638, lsl #16
     834:      	dup.4s	v1, w12
     838:      	mov	w12, #0xd01             ; =3329
     83c:      	movk	w12, #0x3950, lsl #16
     840:      	dup.4s	v0, w12
     844:      	stp	q0, q1, [sp, #0xb0]
     848:      	mov	w12, #0x8889            ; =34953
     84c:      	movk	w12, #0x3c08, lsl #16
     850:      	dup.4s	v1, w12
     854:      	mov	w12, #0xaaab            ; =43691
     858:      	movk	w12, #0x3e2a, lsl #16
     85c:      	dup.4s	v20, w12
     860:      	mov	w12, #0x76c7            ; =30407
     864:      	movk	w12, #0x310f, lsl #16
     868:      	dup.4s	v0, w12
     86c:      	stp	q0, q1, [sp, #0x90]
     870:      	mov	w12, #0xf27e            ; =62078
     874:      	movk	w12, #0x3493, lsl #16
     878:      	dup.4s	v1, w12
     87c:      	mov	w12, #0xd01             ; =3329
     880:      	movk	w12, #0x37d0, lsl #16
     884:      	dup.4s	v0, w12
     888:      	stp	q0, q1, [sp, #0x70]
     88c:      	mov	w12, #0xb61             ; =2913
     890:      	movk	w12, #0x3ab6, lsl #16
     894:      	dup.4s	v1, w12
     898:      	mov	w12, #0xaaab            ; =43691
     89c:      	movk	w12, #0x3d2a, lsl #16
     8a0:      	dup.4s	v0, w12
     8a4:      	stp	q0, q1, [sp, #0x50]
     8a8:      	mov	w12, #-0x3d300000       ; =-1026555904
     8ac:      	dup.4s	v1, w12
     8b0:      	mov	w12, #0x42c80000        ; =1120403456
     8b4:      	dup.4s	v24, w12
     8b8:      	mov	w12, #0xaa3b            ; =43579
     8bc:      	movk	w12, #0x3fb8, lsl #16
     8c0:      	dup.4s	v0, w12
     8c4:      	stp	q0, q1, [sp, #0x30]
     8c8:      	mov	w12, #0x7200            ; =29184
     8cc:      	movk	w12, #0xbf31, lsl #16
     8d0:      	dup.4s	v1, w12
     8d4:      	mov	w12, #0xbe8e            ; =48782
     8d8:      	movk	w12, #0xb5bf, lsl #16
     8dc:      	dup.4s	v0, w12
     8e0:      	stp	q0, q1, [sp, #0x10]
     8e4:      	mov	w12, #0x2bda            ; =11226
     8e8:      	movk	w12, #0x3950, lsl #16
     8ec:      	dup.4s	v28, w12
     8f0:      	mov	w12, #0x96c9            ; =38601
     8f4:      	movk	w12, #0x3ab6, lsl #16
     8f8:      	dup.4s	v29, w12
     8fc:      	mov	w12, #0x88a6            ; =34982
     900:      	movk	w12, #0x3c08, lsl #16
     904:      	dup.4s	v30, w12
     908:      	mov	w12, #0xaa7a            ; =43642
     90c:      	movk	w12, #0x3d2a, lsl #16
     910:      	dup.4s	v31, w12
     914:      	add	x12, x22, x8
     918:      	movi.4s	v8, #0x3f, lsl #24
     91c:      	fmov.4s	v18, #1.00000000
     920:      	fmov.4s	v0, #9.00000000
     924:      	str	q0, [sp, #0x110]
     928:      	mvni.4s	v0, #0x7f, msl #16
     92c:      	fneg.4s	v12, v0
     930:      	mvni.4s	v0, #0x3f, msl #16
     934:      	fneg.4s	v14, v0
     938:      	lsl	x13, x9, #5
     93c:      	add	x14, x12, x13
     940:      	ldp	q9, q10, [x14]
     944:      	ldp	q2, q1, [sp, #0xf0]
     948:      	fmul.4s	v0, v9, v1
     94c:      	fmul.4s	v1, v10, v1
     950:      	fmul.4s	v1, v10, v1
     954:      	fmul.4s	v0, v9, v0
     958:      	fmul.4s	v0, v9, v0
     95c:      	fmul.4s	v1, v10, v1
     960:      	fadd.4s	v1, v10, v1
     964:      	fadd.4s	v0, v9, v0
     968:      	fmul.4s	v13, v0, v2
     96c:      	fmul.4s	v11, v1, v2
     970:      	fabs.4s	v2, v11
     974:      	fabs.4s	v1, v13
     978:      	fmul.4s	v16, v13, v13
     97c:      	ldp	q3, q4, [sp, #0xd0]
     980:      	mov.16b	v0, v3
     984:      	fmul.4s	v19, v11, v11
     988:      	fmla.4s	v0, v16, v4
     98c:      	fmla.4s	v3, v19, v4
     990:      	ldr	q5, [sp, #0xc0]
     994:      	mov.16b	v4, v5
     998:      	fmla.4s	v4, v16, v0
     99c:      	fmla.4s	v5, v19, v3
     9a0:      	ldr	q0, [sp, #0xb0]
     9a4:      	mov.16b	v3, v0
     9a8:      	fmla.4s	v3, v16, v4
     9ac:      	mov.16b	v4, v0
     9b0:      	ldp	q22, q0, [sp, #0x90]
     9b4:      	mov.16b	v6, v0
     9b8:      	fmla.4s	v4, v19, v5
     9bc:      	mov.16b	v5, v0
     9c0:      	mov.16b	v17, v20
     9c4:      	mov.16b	v7, v20
     9c8:      	mov.16b	v0, v18
     9cc:      	mov.16b	v25, v18
     9d0:      	fmla.4s	v6, v16, v3
     9d4:      	ldp	q23, q21, [sp, #0x70]
     9d8:      	mov.16b	v3, v21
     9dc:      	fmla.4s	v3, v19, v22
     9e0:      	fmla.4s	v21, v16, v22
     9e4:      	mov.16b	v22, v23
     9e8:      	fmla.4s	v5, v19, v4
     9ec:      	fmla.4s	v22, v19, v3
     9f0:      	mov.16b	v3, v23
     9f4:      	fmla.4s	v3, v16, v21
     9f8:      	ldr	q21, [sp, #0x60]
     9fc:      	mov.16b	v4, v21
     a00:      	fmla.4s	v4, v19, v22
     a04:      	fmla.4s	v17, v16, v6
     a08:      	mov.16b	v6, v21
     a0c:      	fmla.4s	v6, v16, v3
     a10:      	ldr	q21, [sp, #0x50]
     a14:      	mov.16b	v3, v21
     a18:      	fmla.4s	v3, v19, v4
     a1c:      	fmla.4s	v7, v19, v5
     a20:      	fmla.4s	v21, v16, v6
     a24:      	movi.4s	v22, #0x3f, lsl #24
     a28:      	fmla.4s	v22, v19, v3
     a2c:      	movi.4s	v23, #0x3f, lsl #24
     a30:      	mov.16b	v5, v18
     a34:      	fmla.4s	v25, v19, v7
     a38:      	mov.16b	v15, v18
     a3c:      	ldr	q4, [sp, #0x110]
     a40:      	fcmge.4s	v3, v4, v1
     a44:      	fcmge.4s	v4, v4, v2
     a48:      	and.16b	v6, v4, v2
     a4c:      	and.16b	v7, v3, v1
     a50:      	fmla.4s	v5, v19, v22
     a54:      	ldr	q22, [sp, #0x40]
     a58:      	fcmge.4s	v19, v7, v22
     a5c:      	fcmge.4s	v22, v6, v22
     a60:      	fcmge.4s	v26, v24, v6
     a64:      	and.16b	v22, v22, v26
     a68:      	fcmge.4s	v26, v24, v7
     a6c:      	fmla.4s	v23, v16, v21
     a70:      	and.16b	v19, v19, v26
     a74:      	and.16b	v19, v19, v7
     a78:      	and.16b	v21, v22, v6
     a7c:      	ldr	q26, [sp, #0x30]
     a80:      	fmul.4s	v22, v21, v26
     a84:      	fmul.4s	v26, v19, v26
     a88:      	fmla.4s	v0, v16, v17
     a8c:      	movi.4s	v27, #0x4b, lsl #24
     a90:      	fadd.4s	v17, v26, v27
     a94:      	fadd.4s	v22, v22, v27
     a98:      	movi.4s	v26, #0xcb, lsl #24
     a9c:      	fadd.4s	v22, v22, v26
     aa0:      	fadd.4s	v17, v17, v26
     aa4:      	fcvtzs.4s	v17, v17
     aa8:      	fmla.4s	v15, v16, v23
     aac:      	fcvtzs.4s	v22, v22
     ab0:      	scvtf.4s	v16, v22
     ab4:      	scvtf.4s	v23, v17
     ab8:      	ldr	q27, [sp, #0x20]
     abc:      	fmul.4s	v26, v16, v27
     ac0:      	fadd.4s	v21, v21, v26
     ac4:      	fmul.4s	v26, v23, v27
     ac8:      	fadd.4s	v19, v19, v26
     acc:      	ldr	q26, [sp, #0x10]
     ad0:      	fmul.4s	v16, v16, v26
     ad4:      	fmul.4s	v23, v23, v26
     ad8:      	fadd.4s	v19, v19, v23
     adc:      	fadd.4s	v21, v21, v16
     ae0:      	fmul.4s	v16, v21, v28
     ae4:      	fmul.4s	v23, v19, v28
     ae8:      	fadd.4s	v23, v23, v29
     aec:      	fadd.4s	v16, v16, v29
     af0:      	fmul.4s	v16, v21, v16
     af4:      	fmul.4s	v23, v19, v23
     af8:      	fmul.4s	v0, v1, v0
     afc:      	fadd.4s	v23, v23, v30
     b00:      	fadd.4s	v16, v16, v30
     b04:      	fmul.4s	v26, v21, v16
     b08:      	fmul.4s	v16, v19, v23
     b0c:      	fadd.4s	v23, v16, v31
     b10:      	fdiv.4s	v16, v0, v15
     b14:      	fadd.4s	v0, v26, v31
     b18:      	fmul.4s	v0, v21, v0
     b1c:      	fmul.4s	v23, v19, v23
     b20:      	fadd.4s	v23, v23, v20
     b24:      	fadd.4s	v0, v0, v20
     b28:      	fmul.4s	v0, v21, v0
     b2c:      	fmul.4s	v23, v19, v23
     b30:      	fadd.4s	v23, v23, v8
     b34:      	fadd.4s	v0, v0, v8
     b38:      	fmul.4s	v26, v21, v21
     b3c:      	fmul.4s	v0, v26, v0
     b40:      	fmul.4s	v26, v19, v19
     b44:      	fmul.4s	v23, v26, v23
     b48:      	fadd.4s	v19, v19, v23
     b4c:      	fadd.4s	v0, v21, v0
     b50:      	fadd.4s	v0, v0, v18
     b54:      	movi.2d	v21, #0xffffffffffffffff
     b58:      	add.4s	v17, v17, v21
     b5c:      	fadd.4s	v19, v19, v18
     b60:      	add.4s	v21, v22, v21
     b64:      	sshr.4s	v22, v21, #0x1
     b68:      	sshr.4s	v23, v17, #0x1
     b6c:      	shl.4s	v26, v23, #0x17
     b70:      	add.4s	v26, v26, v18
     b74:      	fmul.4s	v19, v19, v26
     b78:      	shl.4s	v26, v22, #0x17
     b7c:      	add.4s	v26, v26, v18
     b80:      	fmul.4s	v0, v0, v26
     b84:      	sub.4s	v17, v17, v23
     b88:      	sub.4s	v21, v21, v22
     b8c:      	shl.4s	v21, v21, #0x17
     b90:      	add.4s	v21, v21, v18
     b94:      	fmul.4s	v0, v0, v21
     b98:      	shl.4s	v17, v17, #0x17
     b9c:      	add.4s	v17, v17, v18
     ba0:      	fmul.4s	v17, v19, v17
     ba4:      	fmul.4s	v19, v2, v25
     ba8:      	fcmgt.4s	v6, v6, v24
     bac:      	fcmgt.4s	v7, v7, v24
     bb0:      	bsl.16b	v7, v12, v17
     bb4:      	bsl.16b	v6, v12, v0
     bb8:      	fmov.4s	v0, #0.25000000
     bbc:      	fdiv.4s	v5, v19, v5
     bc0:      	fdiv.4s	v17, v0, v6
     bc4:      	fsub.4s	v19, v6, v17
     bc8:      	fadd.4s	v6, v6, v17
     bcc:      	fdiv.4s	v6, v19, v6
     bd0:      	bsl.16b	v4, v6, v18
     bd4:      	fcmge.4s	v2, v18, v2
     bd8:      	bsl.16b	v2, v5, v4
     bdc:      	fdiv.4s	v4, v0, v7
     be0:      	fsub.4s	v5, v7, v4
     be4:      	fadd.4s	v4, v7, v4
     be8:      	fdiv.4s	v4, v5, v4
     bec:      	bsl.16b	v3, v4, v18
     bf0:      	fcmge.4s	v1, v18, v1
     bf4:      	bsl.16b	v1, v16, v3
     bf8:      	mvni.4s	v4, #0x80, lsl #24
     bfc:      	bif.16b	v1, v13, v4
     c00:      	fcmeq.4s	v3, v13, v13
     c04:      	fadd.4s	v1, v1, v18
     c08:      	bif.16b	v1, v14, v3
     c0c:      	bif.16b	v2, v11, v4
     c10:      	fcmeq.4s	v3, v11, v11
     c14:      	fadd.4s	v2, v2, v18
     c18:      	bif.16b	v2, v14, v3
     c1c:      	fmul.4s	v3, v10, v8
     c20:      	fmul.4s	v2, v3, v2
     c24:      	fmul.4s	v3, v9, v8
     c28:      	fmul.4s	v1, v3, v1
     c2c:      	add	x14, x11, x13
     c30:      	ldp	q4, q3, [x14]
     c34:      	fadd.4s	v1, v4, v1
     c38:      	fadd.4s	v2, v3, v2
     c3c:      	add	x13, x10, x13
     c40:      	stp	q1, q2, [x13]
     c44:      	add	x9, x9, #0x1
     c48:      	cmp	x9, #0xc0
     c4c:      	b.ne	0x938 <ltmp0+0x938>
     c50:      	mov	w9, #0x1800             ; =6144
     c54:      	add	x20, x8, x9
     c58:      	add	x8, x22, x20
     c5c:      	movi.2d	v2, #0000000000000000
     c60:      	ld1.s	{ v2 }[0], [x8], #4
     c64:      	ld1.s	{ v2 }[1], [x8]
     c68:      	movi.2d	v1, #0000000000000000
     c6c:      	mov	w8, #0x2713             ; =10003
     c70:      	movk	w8, #0x3d37, lsl #16
     c74:      	dup.4s	v3, w8
     c78:      	fmul.4s	v3, v2, v3
     c7c:      	fmul.4s	v3, v2, v3
     c80:      	fmul.4s	v3, v2, v3
     c84:      	fadd.4s	v3, v2, v3
     c88:      	mov	w8, #0x422a             ; =16938
     c8c:      	movk	w8, #0x3f4c, lsl #16
     c90:      	dup.4s	v4, w8
     c94:      	fmul.4s	v3, v3, v4
     c98:      	mov.d	v1[0], v3[0]
     c9c:      	fabs.4s	v3, v1
     ca0:      	mov	w8, #0x9231             ; =37425
     ca4:      	movk	w8, #0x2f30, lsl #16
     ca8:      	dup.4s	v5, w8
     cac:      	fmul.4s	v4, v1, v1
     cb0:      	mov	w8, #0x322b             ; =12843
     cb4:      	movk	w8, #0x32d7, lsl #16
     cb8:      	dup.4s	v6, w8
     cbc:      	fmla.4s	v6, v4, v5
     cc0:      	mov	w8, #0xef1d             ; =61213
     cc4:      	movk	w8, #0x3638, lsl #16
     cc8:      	dup.4s	v5, w8
     ccc:      	fmla.4s	v5, v4, v6
     cd0:      	mov	w8, #0xd01              ; =3329
     cd4:      	movk	w8, #0x3950, lsl #16
     cd8:      	dup.4s	v6, w8
     cdc:      	fmla.4s	v6, v4, v5
     ce0:      	mov	w8, #0x8889             ; =34953
     ce4:      	movk	w8, #0x3c08, lsl #16
     ce8:      	dup.4s	v16, w8
     cec:      	fmla.4s	v16, v4, v6
     cf0:      	mov	w8, #0xaaab             ; =43691
     cf4:      	movk	w8, #0x3e2a, lsl #16
     cf8:      	dup.4s	v17, w8
     cfc:      	ldr	q5, [sp, #0x110]
     d00:      	fcmge.4s	v5, v5, v3
     d04:      	mov	w8, #-0x3d300000        ; =-1026555904
     d08:      	dup.4s	v7, w8
     d0c:      	and.16b	v6, v5, v3
     d10:      	fcmge.4s	v19, v6, v7
     d14:      	mov	w8, #0x42c80000         ; =1120403456
     d18:      	dup.4s	v7, w8
     d1c:      	fcmge.4s	v20, v7, v6
     d20:      	and.16b	v19, v19, v20
     d24:      	and.16b	v19, v19, v6
     d28:      	mov	w8, #0xaa3b             ; =43579
     d2c:      	movk	w8, #0x3fb8, lsl #16
     d30:      	dup.4s	v20, w8
     d34:      	fmul.4s	v20, v19, v20
     d38:      	movi.4s	v21, #0x4b, lsl #24
     d3c:      	fadd.4s	v20, v20, v21
     d40:      	movi.4s	v21, #0xcb, lsl #24
     d44:      	fadd.4s	v20, v20, v21
     d48:      	fcvtzs.4s	v20, v20
     d4c:      	scvtf.4s	v21, v20
     d50:      	mov	w8, #0x7200             ; =29184
     d54:      	movk	w8, #0xbf31, lsl #16
     d58:      	dup.4s	v22, w8
     d5c:      	fmul.4s	v22, v21, v22
     d60:      	fadd.4s	v19, v19, v22
     d64:      	mov	w8, #0xbe8e             ; =48782
     d68:      	movk	w8, #0xb5bf, lsl #16
     d6c:      	dup.4s	v22, w8
     d70:      	fmul.4s	v21, v21, v22
     d74:      	mov	w8, #0x2bda             ; =11226
     d78:      	movk	w8, #0x3950, lsl #16
     d7c:      	dup.4s	v22, w8
     d80:      	fadd.4s	v19, v19, v21
     d84:      	fmul.4s	v21, v19, v22
     d88:      	mov	w8, #0x96c9             ; =38601
     d8c:      	movk	w8, #0x3ab6, lsl #16
     d90:      	dup.4s	v22, w8
     d94:      	fadd.4s	v21, v21, v22
     d98:      	fmul.4s	v21, v19, v21
     d9c:      	mov	w8, #0x88a6             ; =34982
     da0:      	movk	w8, #0x3c08, lsl #16
     da4:      	dup.4s	v22, w8
     da8:      	fadd.4s	v21, v21, v22
     dac:      	fmul.4s	v21, v19, v21
     db0:      	mov	w8, #0xaa7a             ; =43642
     db4:      	movk	w8, #0x3d2a, lsl #16
     db8:      	dup.4s	v22, w8
     dbc:      	fadd.4s	v21, v21, v22
     dc0:      	fmul.4s	v21, v19, v21
     dc4:      	fadd.4s	v21, v21, v17
     dc8:      	fmla.4s	v17, v4, v16
     dcc:      	mov.16b	v16, v18
     dd0:      	mov	w8, #0x76c7             ; =30407
     dd4:      	movk	w8, #0x310f, lsl #16
     dd8:      	dup.4s	v22, w8
     ddc:      	fmla.4s	v16, v4, v17
     de0:      	mov	w8, #0xf27e             ; =62078
     de4:      	movk	w8, #0x3493, lsl #16
     de8:      	dup.4s	v17, w8
     dec:      	fmla.4s	v17, v4, v22
     df0:      	mov	w8, #0xd01              ; =3329
     df4:      	movk	w8, #0x37d0, lsl #16
     df8:      	dup.4s	v22, w8
     dfc:      	fmla.4s	v22, v4, v17
     e00:      	mov	w8, #0xb61              ; =2913
     e04:      	movk	w8, #0x3ab6, lsl #16
     e08:      	dup.4s	v17, w8
     e0c:      	fmla.4s	v17, v4, v22
     e10:      	mov	w8, #0xaaab             ; =43691
     e14:      	movk	w8, #0x3d2a, lsl #16
     e18:      	dup.4s	v22, w8
     e1c:      	fmla.4s	v22, v4, v17
     e20:      	movi.4s	v17, #0x3f, lsl #24
     e24:      	fmla.4s	v17, v4, v22
     e28:      	mov.16b	v22, v18
     e2c:      	fmla.4s	v22, v4, v17
     e30:      	movi.4s	v4, #0x3f, lsl #24
     e34:      	fmul.4s	v2, v2, v4
     e38:      	fcmge.4s	v17, v18, v3
     e3c:      	fmul.4s	v3, v3, v16
     e40:      	fdiv.4s	v3, v3, v22
     e44:      	fmul.4s	v16, v19, v21
     e48:      	fadd.4s	v4, v16, v4
     e4c:      	fmul.4s	v16, v19, v19
     e50:      	fmul.4s	v4, v16, v4
     e54:      	fadd.4s	v4, v19, v4
     e58:      	fadd.4s	v4, v4, v18
     e5c:      	movi.2d	v16, #0xffffffffffffffff
     e60:      	add.4s	v16, v20, v16
     e64:      	sshr.4s	v19, v16, #0x1
     e68:      	shl.4s	v20, v19, #0x17
     e6c:      	add.4s	v20, v20, v18
     e70:      	fmul.4s	v4, v4, v20
     e74:      	sub.4s	v16, v16, v19
     e78:      	shl.4s	v16, v16, #0x17
     e7c:      	add.4s	v16, v16, v18
     e80:      	fmul.4s	v4, v4, v16
     e84:      	fcmgt.4s	v6, v6, v7
     e88:      	mvni.4s	v7, #0x7f, msl #16
     e8c:      	fneg.4s	v7, v7
     e90:      	bit.16b	v4, v7, v6
     e94:      	fdiv.4s	v0, v0, v4
     e98:      	fsub.4s	v6, v4, v0
     e9c:      	fadd.4s	v0, v4, v0
     ea0:      	fdiv.4s	v0, v6, v0
     ea4:      	bif.16b	v0, v18, v5
     ea8:      	bit.16b	v0, v3, v17
     eac:      	mvni.4s	v3, #0x80, lsl #24
     eb0:      	bif.16b	v0, v1, v3
     eb4:      	fcmeq.4s	v1, v1, v1
     eb8:      	fadd.4s	v0, v0, v18
     ebc:      	mvni.4s	v3, #0x3f, msl #16
     ec0:      	fneg.4s	v3, v3
     ec4:      	bif.16b	v0, v3, v1
     ec8:      	fmul.4s	v0, v2, v0
     ecc:      	add	x8, x21, x20
     ed0:      	add	x9, x8, #0x4
     ed4:      	ldr	s1, [x8]
     ed8:      	ld1.s	{ v1 }[1], [x9]
     edc:      	fadd.4s	v0, v1, v0
     ee0:      	str	d0, [x19, x20]
     ee4:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
     ee8:      	add	sp, sp, #0x160
     eec:      	ldp	x29, x30, [sp, #0x80]
     ef0:      	ldp	x20, x19, [sp, #0x70]
     ef4:      	ldp	x22, x21, [sp, #0x60]
     ef8:      	ldp	x24, x23, [sp, #0x50]
     efc:      	ldp	x26, x25, [sp, #0x40]
     f00:      	ldp	d9, d8, [sp, #0x30]
     f04:      	ldp	d11, d10, [sp, #0x20]
     f08:      	ldp	d13, d12, [sp, #0x10]
     f0c:      	ldp	d15, d14, [sp], #0x90
     f10:      	ret

0000000000000f14 <_llm_rows.packet_batch.blocks>:
     f14:      	stp	d15, d14, [sp, #-0xa0]!
     f18:      	stp	d13, d12, [sp, #0x10]
     f1c:      	stp	d11, d10, [sp, #0x20]
     f20:      	stp	d9, d8, [sp, #0x30]
     f24:      	stp	x28, x27, [sp, #0x40]
     f28:      	stp	x26, x25, [sp, #0x50]
     f2c:      	stp	x24, x23, [sp, #0x60]
     f30:      	stp	x22, x21, [sp, #0x70]
     f34:      	stp	x20, x19, [sp, #0x80]
     f38:      	stp	x29, x30, [sp, #0x90]
     f3c:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
     f40:      	sub	sp, sp, #0x420
     f44:      	str	x0, [sp, #0x118]
     f48:      	cbz	w3, 0x2bac <_llm_rows.packet_batch.blocks+0x1c98>
     f4c:      	mov	x19, x3
     f50:      	mov	x20, x2
     f54:      	mov	w22, #0x0               ; =0
     f58:      	adrp	x8, 0x0 <ltmp0>
     f5c:      	ldr	q0, [x8]
     f60:      	str	q0, [sp, #0xe0]
     f64:      	adrp	x8, 0x0 <ltmp0>
     f68:      	ldr	q0, [x8]
     f6c:      	str	q0, [sp, #0xd0]
     f70:      	adrp	x8, 0x0 <ltmp0>
     f74:      	ldr	q0, [x8]
     f78:      	str	q0, [sp, #0xb0]
     f7c:      	adrp	x8, 0x0 <ltmp0>
     f80:      	ldr	q0, [x8]
     f84:      	str	q0, [sp, #0xa0]
     f88:      	adrp	x8, 0x0 <ltmp0>
     f8c:      	ldr	q0, [x8]
     f90:      	str	q0, [sp, #0x90]
     f94:      	adrp	x8, 0x0 <ltmp0>
     f98:      	ldr	q0, [x8]
     f9c:      	str	q0, [sp, #0x80]
     fa0:      	adrp	x8, 0x0 <ltmp0>
     fa4:      	ldr	q0, [x8]
     fa8:      	str	q0, [sp, #0x130]
     fac:      	mvni.4s	v0, #0x7f, msl #16
     fb0:      	fneg.4s	v1, v0
     fb4:      	mvni.4s	v0, #0x3f, msl #16
     fb8:      	fneg.4s	v0, v0
     fbc:      	stp	q0, q1, [sp, #0x190]
     fc0:      	ldp	w9, w8, [x2, #0x2c]
     fc4:      	str	w9, [sp, #0x114]
     fc8:      	str	w8, [sp, #0x110]
     fcc:      	ldp	w25, w23, [x2]
     fd0:      	add	x24, sp, #0x1, lsl #12  ; =0x1000
     fd4:      	add	x24, x24, #0xc00
     fd8:      	ldp	w27, w28, [x2, #0x8]
     fdc:      	add	x26, sp, #0x3e0
     fe0:      	str	w3, [sp, #0xfc]
     fe4:      	b	0x1030 <_llm_rows.packet_batch.blocks+0x11c>
     fe8:      	mov	w8, #0x18               ; =24
     fec:      	str	w8, [x20, #0x24]
     ff0:      	ldr	w19, [sp, #0xfc]
     ff4:      	add	w8, w25, #0x1
     ff8:      	ldr	w9, [sp, #0x114]
     ffc:      	cmp	w8, w9
    1000:      	cset	w8, eq
    1004:      	csinc	w25, wzr, w25, eq
    1008:      	cinc	w9, w23, eq
    100c:      	ldr	w10, [sp, #0x110]
    1010:      	cmp	w9, w10
    1014:      	cset	w10, eq
    1018:      	ands	w8, w8, w10
    101c:      	csel	w23, wzr, w9, ne
    1020:      	add	w27, w27, w8
    1024:      	add	w22, w22, #0x1
    1028:      	cmp	w22, w19
    102c:      	b.eq	0x2bac <_llm_rows.packet_batch.blocks+0x1c98>
    1030:      	ubfiz	x8, x25, #5, #32
    1034:      	cmp	x8, x28
    1038:      	csel	x9, x8, xzr, ls
    103c:      	subs	x10, x28, x9
    1040:      	cmp	x10, #0x20
    1044:      	mov	w11, #0x20              ; =32
    1048:      	csel	x10, x10, x11, lo
    104c:      	cmp	x28, x9
    1050:      	stp	w25, w23, [x20]
    1054:      	str	w27, [x20, #0x8]
    1058:      	str	wzr, [x20, #0x24]
    105c:      	ccmp	x8, x28, #0x2, hi
    1060:      	csel	x21, x10, xzr, ls
    1064:      	cmp	x21, #0x20
    1068:      	b.lo	0x10bc <_llm_rows.packet_batch.blocks+0x1a8>
    106c:      	ldr	x21, [sp, #0x118]
    1070:      	mov	x0, x21
    1074:      	mov	x1, x20
    1078:      	bl	0x1078 <_llm_rows.packet_batch.blocks+0x164>
    107c:      	mov	w8, #0x8                ; =8
    1080:      	str	w8, [x20, #0x24]
    1084:      	mov	x0, x21
    1088:      	mov	x1, x20
    108c:      	bl	0x108c <_llm_rows.packet_batch.blocks+0x178>
    1090:      	mov	w8, #0x10               ; =16
    1094:      	str	w8, [x20, #0x24]
    1098:      	mov	x0, x21
    109c:      	mov	x1, x20
    10a0:      	bl	0x10a0 <_llm_rows.packet_batch.blocks+0x18c>
    10a4:      	mov	w8, #0x18               ; =24
    10a8:      	str	w8, [x20, #0x24]
    10ac:      	mov	x0, x21
    10b0:      	mov	x1, x20
    10b4:      	bl	0x10b4 <_llm_rows.packet_batch.blocks+0x1a0>
    10b8:      	b	0xff4 <_llm_rows.packet_batch.blocks+0xe0>
    10bc:      	lsr	x19, x21, #3
    10c0:      	cmp	x21, #0x8
    10c4:      	b.lo	0x1110 <_llm_rows.packet_batch.blocks+0x1fc>
    10c8:      	str	wzr, [x20, #0x24]
    10cc:      	ldr	x0, [sp, #0x118]
    10d0:      	mov	x1, x20
    10d4:      	bl	0x10d4 <_llm_rows.packet_batch.blocks+0x1c0>
    10d8:      	cmp	x19, #0x1
    10dc:      	b.eq	0x1110 <_llm_rows.packet_batch.blocks+0x1fc>
    10e0:      	mov	w8, #0x8                ; =8
    10e4:      	str	w8, [x20, #0x24]
    10e8:      	ldr	x0, [sp, #0x118]
    10ec:      	mov	x1, x20
    10f0:      	bl	0x10f0 <_llm_rows.packet_batch.blocks+0x1dc>
    10f4:      	cmp	x19, #0x2
    10f8:      	b.eq	0x1110 <_llm_rows.packet_batch.blocks+0x1fc>
    10fc:      	mov	w8, #0x10               ; =16
    1100:      	str	w8, [x20, #0x24]
    1104:      	ldr	x0, [sp, #0x118]
    1108:      	mov	x1, x20
    110c:      	bl	0x110c <_llm_rows.packet_batch.blocks+0x1f8>
    1110:      	and	w8, w21, #0x7
    1114:      	cbz	w8, 0xfe8 <_llm_rows.packet_batch.blocks+0xd4>
    1118:      	dup.4s	v0, w8
    111c:      	ldp	q2, q1, [sp, #0xd0]
    1120:      	cmhi.4s	v19, v0, v2
    1124:      	cmhi.4s	v11, v0, v1
    1128:      	uzp1.8h	v0, v11, v19
    112c:      	mov.16b	v23, v0
    1130:      	umaxv.8h	h0, v0
    1134:      	fmov	w8, s0
    1138:      	tbz	w8, #0x0, 0xfe8 <_llm_rows.packet_batch.blocks+0xd4>
    113c:      	ldr	x8, [sp, #0x118]
    1140:      	ldr	x11, [x8]
    1144:      	ldr	x9, [x8, #0x10]
    1148:      	ldr	x8, [x8, #0x30]
    114c:      	sshll.2d	v0, v11, #0x0
    1150:      	sshll.2d	v1, v19, #0x0
    1154:      	sshll2.2d	v15, v11, #0x0
    1158:      	sshll2.2d	v6, v19, #0x0
    115c:      	ldp	q2, q3, [sp, #0xa0]
    1160:      	and.16b	v18, v6, v3
    1164:      	and.16b	v16, v15, v2
    1168:      	ldr	q2, [sp, #0x90]
    116c:      	and.16b	v7, v1, v2
    1170:      	ldr	q1, [sp, #0x80]
    1174:      	and.16b	v0, v0, v1
    1178:      	str	q0, [sp, #0x100]
    117c:      	ubfiz	w10, w25, #2, #27
    1180:      	orr	w10, w10, w19
    1184:      	dup.4s	v0, w10
    1188:      	and.16b	v1, v11, v0
    118c:      	and.16b	v0, v19, v0
    1190:      	ushll2.2d	v4, v0, #0x0
    1194:      	ushll2.2d	v3, v1, #0x0
    1198:      	ushll.2d	v5, v0, #0x0
    119c:      	ushll.2d	v0, v1, #0x0
    11a0:      	mov	w10, #0x2713            ; =10003
    11a4:      	movk	w10, #0x3d37, lsl #16
    11a8:      	dup.4s	v2, w10
    11ac:      	subs	x10, x11, x8
    11b0:      	mov	w14, #0x2007            ; =8199
    11b4:      	movk	w14, #0x18, lsl #16
    11b8:      	ccmp	x10, x14, #0x0, hs
    11bc:      	mov	w10, #0x422a            ; =16938
    11c0:      	movk	w10, #0x3f4c, lsl #16
    11c4:      	dup.4s	v1, w10
    11c8:      	stp	q2, q1, [sp, #0x1c0]
    11cc:      	mov	w10, #0x9231            ; =37425
    11d0:      	movk	w10, #0x2f30, lsl #16
    11d4:      	dup.4s	v1, w10
    11d8:      	str	q1, [sp, #0x200]
    11dc:      	cset	w10, hi
    11e0:      	subs	x12, x8, x11
    11e4:      	mov	w13, #0x322b            ; =12843
    11e8:      	movk	w13, #0x32d7, lsl #16
    11ec:      	dup.4s	v1, w13
    11f0:      	str	q1, [sp, #0x220]
    11f4:      	mov	w13, #0xef1d            ; =61213
    11f8:      	movk	w13, #0x3638, lsl #16
    11fc:      	dup.4s	v2, w13
    1200:      	ccmp	x12, x14, #0x0, hs
    1204:      	csinc	w12, w10, wzr, ls
    1208:      	mov	w10, #0xd01             ; =3329
    120c:      	movk	w10, #0x3950, lsl #16
    1210:      	dup.4s	v10, w10
    1214:      	mov	w10, #0x8889            ; =34953
    1218:      	movk	w10, #0x3c08, lsl #16
    121c:      	dup.4s	v22, w10
    1220:      	subs	x10, x9, x8
    1224:      	ccmp	x10, x14, #0x0, hs
    1228:      	mov	w10, #0xaaab            ; =43691
    122c:      	movk	w10, #0x3e2a, lsl #16
    1230:      	dup.4s	v1, w10
    1234:      	stp	q2, q1, [sp, #0x240]
    1238:      	mov	w10, #0x76c7            ; =30407
    123c:      	movk	w10, #0x310f, lsl #16
    1240:      	dup.4s	v29, w10
    1244:      	cset	w10, hi
    1248:      	subs	x13, x8, x9
    124c:      	ccmp	x13, x14, #0x0, hs
    1250:      	csinc	w10, w10, wzr, ls
    1254:      	xtn.2s	v12, v0
    1258:      	fmov	x13, d0
    125c:      	mov	w14, #0x1808            ; =6152
    1260:      	umull	x14, w13, w14
    1264:      	fmov.4s	v0, #1.00000000
    1268:      	mov	w13, #0xf27e            ; =62078
    126c:      	movk	w13, #0x3493, lsl #16
    1270:      	dup.4s	v2, w13
    1274:      	mov	w13, #0xd01             ; =3329
    1278:      	movk	w13, #0x37d0, lsl #16
    127c:      	dup.4s	v1, w13
    1280:      	stp	q2, q1, [sp, #0x1e0]
    1284:      	mov	w13, #0xb61             ; =2913
    1288:      	movk	w13, #0x3ab6, lsl #16
    128c:      	dup.4s	v1, w13
    1290:      	str	q1, [sp, #0x210]
    1294:      	mov	w13, #0xaaab            ; =43691
    1298:      	movk	w13, #0x3d2a, lsl #16
    129c:      	dup.4s	v1, w13
    12a0:      	str	q1, [sp, #0x230]
    12a4:      	mov	w13, #-0x3d300000       ; =-1026555904
    12a8:      	dup.4s	v28, w13
    12ac:      	mov	w13, #0x42c80000        ; =1120403456
    12b0:      	dup.4s	v1, w13
    12b4:      	str	q1, [sp, #0x260]
    12b8:      	mov	w13, #0xaa3b            ; =43579
    12bc:      	movk	w13, #0x3fb8, lsl #16
    12c0:      	dup.4s	v30, w13
    12c4:      	mov	w13, #0x7200            ; =29184
    12c8:      	movk	w13, #0xbf31, lsl #16
    12cc:      	dup.4s	v9, w13
    12d0:      	mov	w13, #0xbe8e            ; =48782
    12d4:      	movk	w13, #0xb5bf, lsl #16
    12d8:      	dup.4s	v27, w13
    12dc:      	mov	w13, #0x2bda            ; =11226
    12e0:      	movk	w13, #0x3950, lsl #16
    12e4:      	dup.4s	v26, w13
    12e8:      	mov	w13, #0x96c9            ; =38601
    12ec:      	movk	w13, #0x3ab6, lsl #16
    12f0:      	dup.4s	v20, w13
    12f4:      	fmov.4s	v24, #9.00000000
    12f8:      	xtn.2s	v1, v4
    12fc:      	xtn.2s	v17, v5
    1300:      	xtn.2s	v8, v3
    1304:      	mov	w13, #0x88a6            ; =34982
    1308:      	movk	w13, #0x3c08, lsl #16
    130c:      	dup.4s	v25, w13
    1310:      	mov	w13, #0xaa7a            ; =43642
    1314:      	movk	w13, #0x3d2a, lsl #16
    1318:      	dup.4s	v2, w13
    131c:      	str	q2, [sp, #0x1b0]
    1320:      	fmov.4s	v31, #0.25000000
    1324:      	mov	w13, #0x602             ; =1538
    1328:      	dup.2s	v21, w13
    132c:      	cmp	w12, #0x1
    1330:      	stp	q19, q10, [sp, #0x170]
    1334:      	b.ne	0x1860 <_llm_rows.packet_batch.blocks+0x94c>
    1338:      	cbz	w10, 0x1860 <_llm_rows.packet_batch.blocks+0x94c>
    133c:      	str	d12, [sp, #0x20]
    1340:      	str	d8, [sp, #0x30]
    1344:      	str	d21, [sp, #0x40]
    1348:      	str	d17, [sp, #0x50]
    134c:      	str	d1, [sp, #0x60]
    1350:      	str	q16, [sp, #0x70]
    1354:      	str	q7, [sp, #0xc0]
    1358:      	str	q18, [sp, #0x120]
    135c:      	mov	x10, #0x0               ; =0
    1360:      	add	x12, x8, x14
    1364:      	add	x13, x9, x14
    1368:      	add	x14, x11, x14
    136c:      	ldr	q3, [sp, #0x130]
    1370:      	and.16b	v3, v23, v3
    1374:      	addv.8h	h12, v3
    1378:      	fmov	w15, s12
    137c:      	movi.4s	v2, #0x3f, lsl #24
    1380:      	b	0x1390 <_llm_rows.packet_batch.blocks+0x47c>
    1384:      	add	x10, x10, #0x1
    1388:      	cmp	x10, #0xc0
    138c:      	b.eq	0x25d4 <_llm_rows.packet_batch.blocks+0x16c0>
    1390:      	add	x16, x14, x10, lsl #5
    1394:      	movi.2d	v15, #0000000000000000
    1398:      	movi.2d	v14, #0000000000000000
    139c:      	tbz	w15, #0x0, 0x1430 <_llm_rows.packet_batch.blocks+0x51c>
    13a0:      	ldr	s15, [x16]
    13a4:      	and	w17, w15, #0xff
    13a8:      	tbnz	w17, #0x1, 0x1438 <_llm_rows.packet_batch.blocks+0x524>
    13ac:      	tbz	w17, #0x2, 0x1444 <_llm_rows.packet_batch.blocks+0x530>
    13b0:      	add	x0, x16, #0x8
    13b4:      	ld1.s	{ v15 }[2], [x0]
    13b8:      	tbnz	w17, #0x3, 0x1448 <_llm_rows.packet_batch.blocks+0x534>
    13bc:      	tbz	w17, #0x4, 0x1454 <_llm_rows.packet_batch.blocks+0x540>
    13c0:      	add	x0, x16, #0x10
    13c4:      	ld1.s	{ v14 }[0], [x0]
    13c8:      	tbnz	w17, #0x5, 0x1458 <_llm_rows.packet_batch.blocks+0x544>
    13cc:      	tbz	w17, #0x6, 0x1464 <_llm_rows.packet_batch.blocks+0x550>
    13d0:      	add	x0, x16, #0x18
    13d4:      	ld1.s	{ v14 }[2], [x0]
    13d8:      	tbnz	w17, #0x7, 0x1468 <_llm_rows.packet_batch.blocks+0x554>
    13dc:      	fmov	w17, s12
    13e0:      	add	x16, x13, x10, lsl #5
    13e4:      	movi.2d	v3, #0000000000000000
    13e8:      	movi.2d	v8, #0000000000000000
    13ec:      	tbz	w17, #0x0, 0x1484 <_llm_rows.packet_batch.blocks+0x570>
    13f0:      	ldr	s3, [x16]
    13f4:      	and	w17, w17, #0xff
    13f8:      	tbnz	w17, #0x1, 0x148c <_llm_rows.packet_batch.blocks+0x578>
    13fc:      	tbz	w17, #0x2, 0x1498 <_llm_rows.packet_batch.blocks+0x584>
    1400:      	add	x0, x16, #0x8
    1404:      	ld1.s	{ v3 }[2], [x0]
    1408:      	tbnz	w17, #0x3, 0x149c <_llm_rows.packet_batch.blocks+0x588>
    140c:      	tbz	w17, #0x4, 0x14a8 <_llm_rows.packet_batch.blocks+0x594>
    1410:      	add	x0, x16, #0x10
    1414:      	ld1.s	{ v8 }[0], [x0]
    1418:      	tbnz	w17, #0x5, 0x14ac <_llm_rows.packet_batch.blocks+0x598>
    141c:      	tbz	w17, #0x6, 0x14b8 <_llm_rows.packet_batch.blocks+0x5a4>
    1420:      	add	x0, x16, #0x18
    1424:      	ld1.s	{ v8 }[2], [x0]
    1428:      	tbnz	w17, #0x7, 0x14bc <_llm_rows.packet_batch.blocks+0x5a8>
    142c:      	b	0x14c4 <_llm_rows.packet_batch.blocks+0x5b0>
    1430:      	and	w17, w15, #0xff
    1434:      	tbz	w17, #0x1, 0x13ac <_llm_rows.packet_batch.blocks+0x498>
    1438:      	add	x0, x16, #0x4
    143c:      	ld1.s	{ v15 }[1], [x0]
    1440:      	tbnz	w17, #0x2, 0x13b0 <_llm_rows.packet_batch.blocks+0x49c>
    1444:      	tbz	w17, #0x3, 0x13bc <_llm_rows.packet_batch.blocks+0x4a8>
    1448:      	add	x0, x16, #0xc
    144c:      	ld1.s	{ v15 }[3], [x0]
    1450:      	tbnz	w17, #0x4, 0x13c0 <_llm_rows.packet_batch.blocks+0x4ac>
    1454:      	tbz	w17, #0x5, 0x13cc <_llm_rows.packet_batch.blocks+0x4b8>
    1458:      	add	x0, x16, #0x14
    145c:      	ld1.s	{ v14 }[1], [x0]
    1460:      	tbnz	w17, #0x6, 0x13d0 <_llm_rows.packet_batch.blocks+0x4bc>
    1464:      	tbz	w17, #0x7, 0x13dc <_llm_rows.packet_batch.blocks+0x4c8>
    1468:      	add	x16, x16, #0x1c
    146c:      	ld1.s	{ v14 }[3], [x16]
    1470:      	fmov	w17, s12
    1474:      	add	x16, x13, x10, lsl #5
    1478:      	movi.2d	v3, #0000000000000000
    147c:      	movi.2d	v8, #0000000000000000
    1480:      	tbnz	w17, #0x0, 0x13f0 <_llm_rows.packet_batch.blocks+0x4dc>
    1484:      	and	w17, w17, #0xff
    1488:      	tbz	w17, #0x1, 0x13fc <_llm_rows.packet_batch.blocks+0x4e8>
    148c:      	add	x0, x16, #0x4
    1490:      	ld1.s	{ v3 }[1], [x0]
    1494:      	tbnz	w17, #0x2, 0x1400 <_llm_rows.packet_batch.blocks+0x4ec>
    1498:      	tbz	w17, #0x3, 0x140c <_llm_rows.packet_batch.blocks+0x4f8>
    149c:      	add	x0, x16, #0xc
    14a0:      	ld1.s	{ v3 }[3], [x0]
    14a4:      	tbnz	w17, #0x4, 0x1410 <_llm_rows.packet_batch.blocks+0x4fc>
    14a8:      	tbz	w17, #0x5, 0x141c <_llm_rows.packet_batch.blocks+0x508>
    14ac:      	add	x0, x16, #0x14
    14b0:      	ld1.s	{ v8 }[1], [x0]
    14b4:      	tbnz	w17, #0x6, 0x1420 <_llm_rows.packet_batch.blocks+0x50c>
    14b8:      	tbz	w17, #0x7, 0x14c4 <_llm_rows.packet_batch.blocks+0x5b0>
    14bc:      	add	x16, x16, #0x1c
    14c0:      	ld1.s	{ v8 }[3], [x16]
    14c4:      	ldp	q5, q1, [sp, #0x1c0]
    14c8:      	fmul.4s	v4, v15, v5
    14cc:      	fmul.4s	v4, v15, v4
    14d0:      	fmul.4s	v4, v15, v4
    14d4:      	fadd.4s	v4, v15, v4
    14d8:      	fmul.4s	v4, v4, v1
    14dc:      	and.16b	v4, v11, v4
    14e0:      	fabs.4s	v5, v4
    14e4:      	fmul.4s	v6, v4, v4
    14e8:      	ldr	q7, [sp, #0x220]
    14ec:      	ldp	q17, q1, [sp, #0x1f0]
    14f0:      	fmla.4s	v7, v6, v1
    14f4:      	ldp	q16, q21, [sp, #0x240]
    14f8:      	fmla.4s	v16, v6, v7
    14fc:      	mov.16b	v7, v10
    1500:      	fmla.4s	v7, v6, v16
    1504:      	mov.16b	v16, v22
    1508:      	fmla.4s	v16, v6, v7
    150c:      	mov.16b	v7, v21
    1510:      	fmla.4s	v7, v6, v16
    1514:      	mov.16b	v16, v0
    1518:      	fmla.4s	v16, v6, v7
    151c:      	fmul.4s	v7, v5, v16
    1520:      	ldr	q16, [sp, #0x1e0]
    1524:      	fmla.4s	v16, v6, v29
    1528:      	fmla.4s	v17, v6, v16
    152c:      	ldr	q16, [sp, #0x210]
    1530:      	fmla.4s	v16, v6, v17
    1534:      	ldr	q17, [sp, #0x230]
    1538:      	fmla.4s	v17, v6, v16
    153c:      	movi.4s	v16, #0x3f, lsl #24
    1540:      	fmla.4s	v16, v6, v17
    1544:      	mov.16b	v17, v0
    1548:      	fmla.4s	v17, v6, v16
    154c:      	fdiv.4s	v6, v7, v17
    1550:      	fcmge.4s	v7, v24, v5
    1554:      	and.16b	v16, v7, v5
    1558:      	fcmge.4s	v17, v16, v28
    155c:      	ldr	q1, [sp, #0x260]
    1560:      	fcmge.4s	v18, v1, v16
    1564:      	and.16b	v17, v17, v18
    1568:      	and.16b	v17, v17, v16
    156c:      	fmul.4s	v18, v17, v30
    1570:      	movi.4s	v19, #0x4b, lsl #24
    1574:      	fadd.4s	v18, v18, v19
    1578:      	movi.4s	v19, #0xcb, lsl #24
    157c:      	fadd.4s	v18, v18, v19
    1580:      	fcvtzs.4s	v18, v18
    1584:      	scvtf.4s	v13, v18
    1588:      	fmul.4s	v19, v13, v9
    158c:      	fadd.4s	v17, v17, v19
    1590:      	fmul.4s	v19, v13, v27
    1594:      	fadd.4s	v17, v17, v19
    1598:      	fmul.4s	v19, v17, v26
    159c:      	fadd.4s	v19, v19, v20
    15a0:      	fmul.4s	v19, v17, v19
    15a4:      	fadd.4s	v19, v19, v25
    15a8:      	fmul.4s	v19, v17, v19
    15ac:      	ldr	q13, [sp, #0x1b0]
    15b0:      	fadd.4s	v19, v19, v13
    15b4:      	fmul.4s	v19, v17, v19
    15b8:      	fadd.4s	v19, v19, v21
    15bc:      	fmul.4s	v19, v17, v19
    15c0:      	fadd.4s	v19, v19, v2
    15c4:      	fmul.4s	v13, v17, v17
    15c8:      	fmul.4s	v19, v13, v19
    15cc:      	fadd.4s	v17, v17, v19
    15d0:      	fadd.4s	v17, v17, v0
    15d4:      	movi.2d	v19, #0xffffffffffffffff
    15d8:      	add.4s	v18, v18, v19
    15dc:      	sshr.4s	v19, v18, #0x1
    15e0:      	shl.4s	v13, v19, #0x17
    15e4:      	add.4s	v13, v13, v0
    15e8:      	fmul.4s	v17, v17, v13
    15ec:      	sub.4s	v18, v18, v19
    15f0:      	shl.4s	v18, v18, #0x17
    15f4:      	add.4s	v18, v18, v0
    15f8:      	fmul.4s	v17, v17, v18
    15fc:      	fcmgt.4s	v16, v16, v1
    1600:      	ldr	q18, [sp, #0x1a0]
    1604:      	bsl.16b	v16, v18, v17
    1608:      	fdiv.4s	v17, v31, v16
    160c:      	fsub.4s	v18, v16, v17
    1610:      	fadd.4s	v16, v16, v17
    1614:      	fdiv.4s	v16, v18, v16
    1618:      	bsl.16b	v7, v16, v0
    161c:      	fcmge.4s	v5, v0, v5
    1620:      	bsl.16b	v5, v6, v7
    1624:      	mvni.4s	v6, #0x80, lsl #24
    1628:      	bif.16b	v5, v4, v6
    162c:      	fcmeq.4s	v4, v4, v4
    1630:      	fadd.4s	v5, v5, v0
    1634:      	ldr	q6, [sp, #0x190]
    1638:      	bsl.16b	v4, v5, v6
    163c:      	fmul.4s	v5, v15, v2
    1640:      	fmul.4s	v4, v5, v4
    1644:      	fadd.4s	v3, v3, v4
    1648:      	fmov	w17, s12
    164c:      	add	x16, x12, x10, lsl #5
    1650:      	tbz	w17, #0x0, 0x1678 <_llm_rows.packet_batch.blocks+0x764>
    1654:      	str	s3, [x16]
    1658:      	and	w17, w17, #0xff
    165c:      	ldr	q4, [sp, #0x170]
    1660:      	tbnz	w17, #0x1, 0x1684 <_llm_rows.packet_batch.blocks+0x770>
    1664:      	tbz	w17, #0x2, 0x1690 <_llm_rows.packet_batch.blocks+0x77c>
    1668:      	add	x0, x16, #0x8
    166c:      	st1.s	{ v3 }[2], [x0]
    1670:      	tbnz	w17, #0x3, 0x1694 <_llm_rows.packet_batch.blocks+0x780>
    1674:      	b	0x169c <_llm_rows.packet_batch.blocks+0x788>
    1678:      	and	w17, w17, #0xff
    167c:      	ldr	q4, [sp, #0x170]
    1680:      	tbz	w17, #0x1, 0x1664 <_llm_rows.packet_batch.blocks+0x750>
    1684:      	add	x0, x16, #0x4
    1688:      	st1.s	{ v3 }[1], [x0]
    168c:      	tbnz	w17, #0x2, 0x1668 <_llm_rows.packet_batch.blocks+0x754>
    1690:      	tbz	w17, #0x3, 0x169c <_llm_rows.packet_batch.blocks+0x788>
    1694:      	add	x0, x16, #0xc
    1698:      	st1.s	{ v3 }[3], [x0]
    169c:      	ldp	q5, q1, [sp, #0x1c0]
    16a0:      	fmul.4s	v3, v14, v5
    16a4:      	fmul.4s	v3, v14, v3
    16a8:      	fmul.4s	v3, v14, v3
    16ac:      	fadd.4s	v3, v14, v3
    16b0:      	fmul.4s	v3, v3, v1
    16b4:      	and.16b	v3, v4, v3
    16b8:      	fabs.4s	v4, v3
    16bc:      	fmul.4s	v5, v3, v3
    16c0:      	ldr	q6, [sp, #0x220]
    16c4:      	ldp	q16, q1, [sp, #0x1f0]
    16c8:      	fmla.4s	v6, v5, v1
    16cc:      	ldp	q7, q21, [sp, #0x240]
    16d0:      	fmla.4s	v7, v5, v6
    16d4:      	mov.16b	v6, v10
    16d8:      	fmla.4s	v6, v5, v7
    16dc:      	mov.16b	v7, v22
    16e0:      	fmla.4s	v7, v5, v6
    16e4:      	mov.16b	v6, v21
    16e8:      	fmla.4s	v6, v5, v7
    16ec:      	mov.16b	v7, v0
    16f0:      	fmla.4s	v7, v5, v6
    16f4:      	fmul.4s	v6, v4, v7
    16f8:      	ldr	q7, [sp, #0x1e0]
    16fc:      	fmla.4s	v7, v5, v29
    1700:      	fmla.4s	v16, v5, v7
    1704:      	ldr	q7, [sp, #0x210]
    1708:      	fmla.4s	v7, v5, v16
    170c:      	ldr	q16, [sp, #0x230]
    1710:      	fmla.4s	v16, v5, v7
    1714:      	movi.4s	v7, #0x3f, lsl #24
    1718:      	fmla.4s	v7, v5, v16
    171c:      	mov.16b	v16, v0
    1720:      	fmla.4s	v16, v5, v7
    1724:      	fdiv.4s	v5, v6, v16
    1728:      	fcmge.4s	v6, v24, v4
    172c:      	and.16b	v7, v6, v4
    1730:      	fcmge.4s	v16, v7, v28
    1734:      	ldr	q1, [sp, #0x260]
    1738:      	fcmge.4s	v17, v1, v7
    173c:      	and.16b	v16, v16, v17
    1740:      	and.16b	v16, v16, v7
    1744:      	fmul.4s	v17, v16, v30
    1748:      	movi.4s	v18, #0x4b, lsl #24
    174c:      	fadd.4s	v17, v17, v18
    1750:      	movi.4s	v18, #0xcb, lsl #24
    1754:      	fadd.4s	v17, v17, v18
    1758:      	fcvtzs.4s	v17, v17
    175c:      	scvtf.4s	v18, v17
    1760:      	fmul.4s	v19, v18, v9
    1764:      	fadd.4s	v16, v16, v19
    1768:      	fmul.4s	v18, v18, v27
    176c:      	fadd.4s	v16, v16, v18
    1770:      	fmul.4s	v18, v16, v26
    1774:      	fadd.4s	v18, v18, v20
    1778:      	fmul.4s	v18, v16, v18
    177c:      	fadd.4s	v18, v18, v25
    1780:      	fmul.4s	v18, v16, v18
    1784:      	ldr	q19, [sp, #0x1b0]
    1788:      	fadd.4s	v18, v18, v19
    178c:      	fmul.4s	v18, v16, v18
    1790:      	fadd.4s	v18, v18, v21
    1794:      	fmul.4s	v18, v16, v18
    1798:      	fadd.4s	v18, v18, v2
    179c:      	fmul.4s	v19, v16, v16
    17a0:      	fmul.4s	v18, v19, v18
    17a4:      	fadd.4s	v16, v16, v18
    17a8:      	fadd.4s	v16, v16, v0
    17ac:      	movi.2d	v18, #0xffffffffffffffff
    17b0:      	add.4s	v17, v17, v18
    17b4:      	sshr.4s	v18, v17, #0x1
    17b8:      	shl.4s	v19, v18, #0x17
    17bc:      	add.4s	v19, v19, v0
    17c0:      	fmul.4s	v16, v16, v19
    17c4:      	sub.4s	v17, v17, v18
    17c8:      	shl.4s	v17, v17, #0x17
    17cc:      	add.4s	v17, v17, v0
    17d0:      	fmul.4s	v16, v16, v17
    17d4:      	fcmgt.4s	v7, v7, v1
    17d8:      	ldr	q17, [sp, #0x1a0]
    17dc:      	bsl.16b	v7, v17, v16
    17e0:      	fdiv.4s	v16, v31, v7
    17e4:      	fsub.4s	v17, v7, v16
    17e8:      	fadd.4s	v7, v7, v16
    17ec:      	fdiv.4s	v7, v17, v7
    17f0:      	bsl.16b	v6, v7, v0
    17f4:      	fcmge.4s	v4, v0, v4
    17f8:      	bsl.16b	v4, v5, v6
    17fc:      	mvni.4s	v5, #0x80, lsl #24
    1800:      	bif.16b	v4, v3, v5
    1804:      	fcmeq.4s	v3, v3, v3
    1808:      	fadd.4s	v4, v4, v0
    180c:      	ldr	q5, [sp, #0x190]
    1810:      	bsl.16b	v3, v4, v5
    1814:      	fmul.4s	v4, v14, v2
    1818:      	fmul.4s	v3, v4, v3
    181c:      	fadd.4s	v3, v8, v3
    1820:      	tbz	w17, #0x4, 0x1840 <_llm_rows.packet_batch.blocks+0x92c>
    1824:      	str	s3, [x16, #0x10]
    1828:      	tbnz	w17, #0x5, 0x1844 <_llm_rows.packet_batch.blocks+0x930>
    182c:      	tbz	w17, #0x6, 0x1850 <_llm_rows.packet_batch.blocks+0x93c>
    1830:      	add	x0, x16, #0x18
    1834:      	st1.s	{ v3 }[2], [x0]
    1838:      	tbz	w17, #0x7, 0x1384 <_llm_rows.packet_batch.blocks+0x470>
    183c:      	b	0x1854 <_llm_rows.packet_batch.blocks+0x940>
    1840:      	tbz	w17, #0x5, 0x182c <_llm_rows.packet_batch.blocks+0x918>
    1844:      	add	x0, x16, #0x14
    1848:      	st1.s	{ v3 }[1], [x0]
    184c:      	tbnz	w17, #0x6, 0x1830 <_llm_rows.packet_batch.blocks+0x91c>
    1850:      	tbz	w17, #0x7, 0x1384 <_llm_rows.packet_batch.blocks+0x470>
    1854:      	add	x16, x16, #0x1c
    1858:      	st1.s	{ v3 }[3], [x16]
    185c:      	b	0x1384 <_llm_rows.packet_batch.blocks+0x470>
    1860:      	str	q6, [sp, #0x30]
    1864:      	mov	x10, #0x0               ; =0
    1868:      	add	x12, x11, x14
    186c:      	movi.4s	v2, #0x3f, lsl #24
    1870:      	b	0x1894 <_llm_rows.packet_batch.blocks+0x980>
    1874:      	add	x13, x24, x10, lsl #5
    1878:      	ldp	q5, q6, [x13]
    187c:      	bif.16b	v4, v6, v19
    1880:      	bif.16b	v3, v5, v11
    1884:      	stp	q3, q4, [x13]
    1888:      	add	x10, x10, #0x1
    188c:      	cmp	x10, #0xc0
    1890:      	b.eq	0x1938 <_llm_rows.packet_batch.blocks+0xa24>
    1894:      	ldr	q3, [sp, #0x130]
    1898:      	and.16b	v3, v23, v3
    189c:      	addv.8h	h13, v3
    18a0:      	fmov	w14, s13
    18a4:      	add	x13, x12, x10, lsl #5
    18a8:      	movi.2d	v3, #0000000000000000
    18ac:      	movi.2d	v4, #0000000000000000
    18b0:      	tbz	w14, #0x0, 0x18f4 <_llm_rows.packet_batch.blocks+0x9e0>
    18b4:      	ldr	s3, [x13]
    18b8:      	and	w14, w14, #0xff
    18bc:      	tbnz	w14, #0x1, 0x18fc <_llm_rows.packet_batch.blocks+0x9e8>
    18c0:      	tbz	w14, #0x2, 0x1908 <_llm_rows.packet_batch.blocks+0x9f4>
    18c4:      	add	x15, x13, #0x8
    18c8:      	ld1.s	{ v3 }[2], [x15]
    18cc:      	tbnz	w14, #0x3, 0x190c <_llm_rows.packet_batch.blocks+0x9f8>
    18d0:      	tbz	w14, #0x4, 0x1918 <_llm_rows.packet_batch.blocks+0xa04>
    18d4:      	add	x15, x13, #0x10
    18d8:      	ld1.s	{ v4 }[0], [x15]
    18dc:      	tbnz	w14, #0x5, 0x191c <_llm_rows.packet_batch.blocks+0xa08>
    18e0:      	tbz	w14, #0x6, 0x1928 <_llm_rows.packet_batch.blocks+0xa14>
    18e4:      	add	x15, x13, #0x18
    18e8:      	ld1.s	{ v4 }[2], [x15]
    18ec:      	tbz	w14, #0x7, 0x1874 <_llm_rows.packet_batch.blocks+0x960>
    18f0:      	b	0x192c <_llm_rows.packet_batch.blocks+0xa18>
    18f4:      	and	w14, w14, #0xff
    18f8:      	tbz	w14, #0x1, 0x18c0 <_llm_rows.packet_batch.blocks+0x9ac>
    18fc:      	add	x15, x13, #0x4
    1900:      	ld1.s	{ v3 }[1], [x15]
    1904:      	tbnz	w14, #0x2, 0x18c4 <_llm_rows.packet_batch.blocks+0x9b0>
    1908:      	tbz	w14, #0x3, 0x18d0 <_llm_rows.packet_batch.blocks+0x9bc>
    190c:      	add	x15, x13, #0xc
    1910:      	ld1.s	{ v3 }[3], [x15]
    1914:      	tbnz	w14, #0x4, 0x18d4 <_llm_rows.packet_batch.blocks+0x9c0>
    1918:      	tbz	w14, #0x5, 0x18e0 <_llm_rows.packet_batch.blocks+0x9cc>
    191c:      	add	x15, x13, #0x14
    1920:      	ld1.s	{ v4 }[1], [x15]
    1924:      	tbnz	w14, #0x6, 0x18e4 <_llm_rows.packet_batch.blocks+0x9d0>
    1928:      	tbz	w14, #0x7, 0x1874 <_llm_rows.packet_batch.blocks+0x960>
    192c:      	add	x13, x13, #0x1c
    1930:      	ld1.s	{ v4 }[3], [x13]
    1934:      	b	0x1874 <_llm_rows.packet_batch.blocks+0x960>
    1938:      	xtn.8b	v3, v23
    193c:      	movi	d4, #0x0000000000ffff
    1940:      	and.8b	v5, v3, v4
    1944:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0xec>
    1948:      	ldr	d4, [x10]
    194c:      	and.8b	v3, v3, v4
    1950:      	addv.8b	b3, v3
    1954:      	fmov	w13, s3
    1958:      	umaxv.8b	b3, v5
    195c:      	fmov	w10, s3
    1960:      	rbit	w12, w13
    1964:      	clz	w12, w12
    1968:      	tst	w10, #0x1
    196c:      	csel	w10, w12, wzr, ne
    1970:      	mov	w12, #0x600             ; =1536
    1974:      	dup.2d	v3, x12
    1978:      	fmov	d6, d12
    197c:      	ldr	q14, [sp, #0x100]
    1980:      	umlal.2d	v14, v12, v21
    1984:      	mov	b4, v5[0]
    1988:      	str	q5, [sp, #0x100]
    198c:      	mov.b	v4[4], v5[1]
    1990:      	add.2d	v5, v14, v3
    1994:      	ushll.2d	v4, v4, #0x0
    1998:      	shl.2d	v4, v4, #0x3f
    199c:      	cmlt.2d	v4, v4, #0
    19a0:      	str	q5, [sp, #0x60]
    19a4:      	and.16b	v4, v4, v5
    19a8:      	movi.2d	v5, #0000000000000000
    19ac:      	stp	q5, q5, [sp, #0x3b0]
    19b0:      	stp	q4, q5, [sp, #0x390]
    19b4:      	and	x12, x10, #0x7
    19b8:      	add	x14, sp, #0x390
    19bc:      	ldr	x12, [x14, x12, lsl #3]
    19c0:      	sub	x12, x12, x10
    19c4:      	lsl	x12, x12, #2
    19c8:      	add	x11, x11, x12
    19cc:      	movi.2d	v4, #0000000000000000
    19d0:      	movi.2d	v12, #0000000000000000
    19d4:      	tbz	w13, #0x0, 0x1a18 <_llm_rows.packet_batch.blocks+0xb04>
    19d8:      	ldr	s4, [x11]
    19dc:      	tbnz	w13, #0x1, 0x1a1c <_llm_rows.packet_batch.blocks+0xb08>
    19e0:      	tbz	w13, #0x2, 0x1a28 <_llm_rows.packet_batch.blocks+0xb14>
    19e4:      	add	x14, x11, #0x8
    19e8:      	ld1.s	{ v4 }[2], [x14]
    19ec:      	tbnz	w13, #0x3, 0x1a2c <_llm_rows.packet_batch.blocks+0xb18>
    19f0:      	tbz	w13, #0x4, 0x1a38 <_llm_rows.packet_batch.blocks+0xb24>
    19f4:      	add	x14, x11, #0x10
    19f8:      	ld1.s	{ v12 }[0], [x14]
    19fc:      	tbnz	w13, #0x5, 0x1a3c <_llm_rows.packet_batch.blocks+0xb28>
    1a00:      	tbz	w13, #0x6, 0x1a48 <_llm_rows.packet_batch.blocks+0xb34>
    1a04:      	add	x14, x11, #0x18
    1a08:      	ld1.s	{ v12 }[2], [x14]
    1a0c:      	str	q4, [sp, #0xc0]
    1a10:      	tbnz	w13, #0x7, 0x1a50 <_llm_rows.packet_batch.blocks+0xb3c>
    1a14:      	b	0x1a58 <_llm_rows.packet_batch.blocks+0xb44>
    1a18:      	tbz	w13, #0x1, 0x19e0 <_llm_rows.packet_batch.blocks+0xacc>
    1a1c:      	add	x14, x11, #0x4
    1a20:      	ld1.s	{ v4 }[1], [x14]
    1a24:      	tbnz	w13, #0x2, 0x19e4 <_llm_rows.packet_batch.blocks+0xad0>
    1a28:      	tbz	w13, #0x3, 0x19f0 <_llm_rows.packet_batch.blocks+0xadc>
    1a2c:      	add	x14, x11, #0xc
    1a30:      	ld1.s	{ v4 }[3], [x14]
    1a34:      	tbnz	w13, #0x4, 0x19f4 <_llm_rows.packet_batch.blocks+0xae0>
    1a38:      	tbz	w13, #0x5, 0x1a00 <_llm_rows.packet_batch.blocks+0xaec>
    1a3c:      	add	x14, x11, #0x14
    1a40:      	ld1.s	{ v12 }[1], [x14]
    1a44:      	tbnz	w13, #0x6, 0x1a04 <_llm_rows.packet_batch.blocks+0xaf0>
    1a48:      	str	q4, [sp, #0xc0]
    1a4c:      	tbz	w13, #0x7, 0x1a58 <_llm_rows.packet_batch.blocks+0xb44>
    1a50:      	add	x11, x11, #0x1c
    1a54:      	ld1.s	{ v12 }[3], [x11]
    1a58:      	mov	x15, #0x0               ; =0
    1a5c:      	umull.2d	v4, v6, v21
    1a60:      	umlal.2d	v16, v8, v21
    1a64:      	add.2d	v6, v16, v3
    1a68:      	umlal.2d	v7, v17, v21
    1a6c:      	add.2d	v5, v7, v3
    1a70:      	stp	q5, q6, [sp, #0x40]
    1a74:      	umlal.2d	v18, v1, v21
    1a78:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xec>
    1a7c:      	ldr	q5, [x11]
    1a80:      	mov	w11, #0x1800            ; =6144
    1a84:      	dup.2d	v6, x11
    1a88:      	sshll.2d	v7, v11, #0x0
    1a8c:      	bif.16b	v5, v6, v7
    1a90:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xec>
    1a94:      	ldr	q7, [x11]
    1a98:      	sshll.2d	v16, v19, #0x0
    1a9c:      	bif.16b	v7, v6, v16
    1aa0:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xec>
    1aa4:      	ldr	q16, [x11]
    1aa8:      	bif.16b	v16, v6, v15
    1aac:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xec>
    1ab0:      	ldr	q17, [x11]
    1ab4:      	ldr	q1, [sp, #0x30]
    1ab8:      	bit.16b	v6, v17, v1
    1abc:      	stp	q7, q6, [sp, #0x370]
    1ac0:      	stp	q5, q16, [sp, #0x350]
    1ac4:      	and	x11, x10, #0x7
    1ac8:      	add	x14, sp, #0x350
    1acc:      	ldr	x11, [x14, x11, lsl #3]
    1ad0:      	add.2d	v1, v18, v3
    1ad4:      	str	q1, [sp, #0x30]
    1ad8:      	sub	x11, x11, x10, lsl #2
    1adc:      	tst	w13, #0xff
    1ae0:      	csel	x11, xzr, x11, eq
    1ae4:      	add	x13, x24, x11
    1ae8:      	ldp	q3, q5, [x13]
    1aec:      	ldr	q1, [sp, #0x100]
    1af0:      	zip2.8b	v6, v1, v0
    1af4:      	ushll.4s	v6, v6, #0x0
    1af8:      	shl.4s	v6, v6, #0x1f
    1afc:      	cmlt.4s	v6, v6, #0
    1b00:      	bit.16b	v5, v12, v6
    1b04:      	zip1.8b	v6, v1, v0
    1b08:      	ushll.4s	v6, v6, #0x0
    1b0c:      	shl.4s	v6, v6, #0x1f
    1b10:      	cmlt.4s	v6, v6, #0
    1b14:      	ldr	q1, [sp, #0xc0]
    1b18:      	bit.16b	v3, v1, v6
    1b1c:      	stp	q3, q5, [x13]
    1b20:      	fmov	x13, d4
    1b24:      	lsl	x13, x13, #2
    1b28:      	mov	w14, #0x1               ; =1
    1b2c:      	dup.2d	v3, x14
    1b30:      	add	x14, x9, x13
    1b34:      	ushll2.2d	v4, v19, #0x0
    1b38:      	and.16b	v21, v4, v3
    1b3c:      	ushll2.2d	v4, v11, #0x0
    1b40:      	and.16b	v23, v4, v3
    1b44:      	ushll.2d	v4, v19, #0x0
    1b48:      	and.16b	v8, v4, v3
    1b4c:      	ushll.2d	v4, v11, #0x0
    1b50:      	and.16b	v14, v4, v3
    1b54:      	movi.2d	v3, #0000000000000000
    1b58:      	movi.2d	v4, #0000000000000000
    1b5c:      	movi.2d	v5, #0000000000000000
    1b60:      	movi.2d	v6, #0000000000000000
    1b64:      	b	0x1b98 <_llm_rows.packet_batch.blocks+0xc84>
    1b68:      	add	x15, x26, x15
    1b6c:      	ldp	q17, q18, [x15]
    1b70:      	bif.16b	v16, v18, v19
    1b74:      	bif.16b	v7, v17, v11
    1b78:      	stp	q7, q16, [x15]
    1b7c:      	add.2d	v4, v4, v23
    1b80:      	add.2d	v5, v5, v8
    1b84:      	add.2d	v6, v6, v21
    1b88:      	add.2d	v3, v3, v14
    1b8c:      	fmov	x15, d3
    1b90:      	cmp	x15, #0xc0
    1b94:      	b.ge	0x1c34 <_llm_rows.packet_batch.blocks+0xd20>
    1b98:      	fmov	w17, s13
    1b9c:      	lsl	x15, x15, #5
    1ba0:      	add	x16, x14, x15
    1ba4:      	movi.2d	v7, #0000000000000000
    1ba8:      	movi.2d	v16, #0000000000000000
    1bac:      	tbz	w17, #0x0, 0x1bf0 <_llm_rows.packet_batch.blocks+0xcdc>
    1bb0:      	ldr	s7, [x16]
    1bb4:      	and	w17, w17, #0xff
    1bb8:      	tbnz	w17, #0x1, 0x1bf8 <_llm_rows.packet_batch.blocks+0xce4>
    1bbc:      	tbz	w17, #0x2, 0x1c04 <_llm_rows.packet_batch.blocks+0xcf0>
    1bc0:      	add	x0, x16, #0x8
    1bc4:      	ld1.s	{ v7 }[2], [x0]
    1bc8:      	tbnz	w17, #0x3, 0x1c08 <_llm_rows.packet_batch.blocks+0xcf4>
    1bcc:      	tbz	w17, #0x4, 0x1c14 <_llm_rows.packet_batch.blocks+0xd00>
    1bd0:      	add	x0, x16, #0x10
    1bd4:      	ld1.s	{ v16 }[0], [x0]
    1bd8:      	tbnz	w17, #0x5, 0x1c18 <_llm_rows.packet_batch.blocks+0xd04>
    1bdc:      	tbz	w17, #0x6, 0x1c24 <_llm_rows.packet_batch.blocks+0xd10>
    1be0:      	add	x0, x16, #0x18
    1be4:      	ld1.s	{ v16 }[2], [x0]
    1be8:      	tbz	w17, #0x7, 0x1b68 <_llm_rows.packet_batch.blocks+0xc54>
    1bec:      	b	0x1c28 <_llm_rows.packet_batch.blocks+0xd14>
    1bf0:      	and	w17, w17, #0xff
    1bf4:      	tbz	w17, #0x1, 0x1bbc <_llm_rows.packet_batch.blocks+0xca8>
    1bf8:      	add	x0, x16, #0x4
    1bfc:      	ld1.s	{ v7 }[1], [x0]
    1c00:      	tbnz	w17, #0x2, 0x1bc0 <_llm_rows.packet_batch.blocks+0xcac>
    1c04:      	tbz	w17, #0x3, 0x1bcc <_llm_rows.packet_batch.blocks+0xcb8>
    1c08:      	add	x0, x16, #0xc
    1c0c:      	ld1.s	{ v7 }[3], [x0]
    1c10:      	tbnz	w17, #0x4, 0x1bd0 <_llm_rows.packet_batch.blocks+0xcbc>
    1c14:      	tbz	w17, #0x5, 0x1bdc <_llm_rows.packet_batch.blocks+0xcc8>
    1c18:      	add	x0, x16, #0x14
    1c1c:      	ld1.s	{ v16 }[1], [x0]
    1c20:      	tbnz	w17, #0x6, 0x1be0 <_llm_rows.packet_batch.blocks+0xccc>
    1c24:      	tbz	w17, #0x7, 0x1b68 <_llm_rows.packet_batch.blocks+0xc54>
    1c28:      	add	x16, x16, #0x1c
    1c2c:      	ld1.s	{ v16 }[3], [x16]
    1c30:      	b	0x1b68 <_llm_rows.packet_batch.blocks+0xc54>
    1c34:      	add	x9, x9, x12
    1c38:      	adrp	x12, 0x1000 <_llm_rows.packet_batch.blocks+0xec>
    1c3c:      	ldr	d3, [x12]
    1c40:      	ldr	q1, [sp, #0x100]
    1c44:      	shl.8b	v4, v1, #0x7
    1c48:      	cmlt.8b	v4, v4, #0
    1c4c:      	and.8b	v3, v4, v3
    1c50:      	addv.8b	b1, v3
    1c54:      	str	d1, [sp, #0x8]
    1c58:      	fmov	w12, s1
    1c5c:      	movi.2d	v16, #0000000000000000
    1c60:      	movi.2d	v7, #0000000000000000
    1c64:      	tbz	w12, #0x0, 0x1cb8 <_llm_rows.packet_batch.blocks+0xda4>
    1c68:      	ldr	s16, [x9]
    1c6c:      	tbnz	w12, #0x1, 0x1cbc <_llm_rows.packet_batch.blocks+0xda8>
    1c70:      	tbz	w12, #0x2, 0x1cc8 <_llm_rows.packet_batch.blocks+0xdb4>
    1c74:      	add	x14, x9, #0x8
    1c78:      	ld1.s	{ v16 }[2], [x14]
    1c7c:      	tbnz	w12, #0x3, 0x1ccc <_llm_rows.packet_batch.blocks+0xdb8>
    1c80:      	tbz	w12, #0x4, 0x1cd8 <_llm_rows.packet_batch.blocks+0xdc4>
    1c84:      	add	x14, x9, #0x10
    1c88:      	ld1.s	{ v7 }[0], [x14]
    1c8c:      	tbnz	w12, #0x5, 0x1cdc <_llm_rows.packet_batch.blocks+0xdc8>
    1c90:      	tbz	w12, #0x6, 0x1ce8 <_llm_rows.packet_batch.blocks+0xdd4>
    1c94:      	add	x14, x9, #0x18
    1c98:      	ld1.s	{ v7 }[2], [x14]
    1c9c:      	str	q12, [sp, #0x70]
    1ca0:      	str	q13, [sp, #0x120]
    1ca4:      	stp	q20, q25, [sp, #0x150]
    1ca8:      	str	q26, [sp, #0x140]
    1cac:      	mov.16b	v26, v24
    1cb0:      	tbnz	w12, #0x7, 0x1d00 <_llm_rows.packet_batch.blocks+0xdec>
    1cb4:      	b	0x1d08 <_llm_rows.packet_batch.blocks+0xdf4>
    1cb8:      	tbz	w12, #0x1, 0x1c70 <_llm_rows.packet_batch.blocks+0xd5c>
    1cbc:      	add	x14, x9, #0x4
    1cc0:      	ld1.s	{ v16 }[1], [x14]
    1cc4:      	tbnz	w12, #0x2, 0x1c74 <_llm_rows.packet_batch.blocks+0xd60>
    1cc8:      	tbz	w12, #0x3, 0x1c80 <_llm_rows.packet_batch.blocks+0xd6c>
    1ccc:      	add	x14, x9, #0xc
    1cd0:      	ld1.s	{ v16 }[3], [x14]
    1cd4:      	tbnz	w12, #0x4, 0x1c84 <_llm_rows.packet_batch.blocks+0xd70>
    1cd8:      	tbz	w12, #0x5, 0x1c90 <_llm_rows.packet_batch.blocks+0xd7c>
    1cdc:      	add	x14, x9, #0x14
    1ce0:      	ld1.s	{ v7 }[1], [x14]
    1ce4:      	tbnz	w12, #0x6, 0x1c94 <_llm_rows.packet_batch.blocks+0xd80>
    1ce8:      	str	q12, [sp, #0x70]
    1cec:      	str	q13, [sp, #0x120]
    1cf0:      	stp	q20, q25, [sp, #0x150]
    1cf4:      	str	q26, [sp, #0x140]
    1cf8:      	mov.16b	v26, v24
    1cfc:      	tbz	w12, #0x7, 0x1d08 <_llm_rows.packet_batch.blocks+0xdf4>
    1d00:      	add	x9, x9, #0x1c
    1d04:      	ld1.s	{ v7 }[3], [x9]
    1d08:      	mov	x12, #0x0               ; =0
    1d0c:      	add	x9, x26, x11
    1d10:      	ldp	q3, q4, [x9]
    1d14:      	ldr	q6, [sp, #0x100]
    1d18:      	zip2.8b	v5, v6, v0
    1d1c:      	ushll.4s	v5, v5, #0x0
    1d20:      	shl.4s	v5, v5, #0x1f
    1d24:      	cmlt.4s	v5, v5, #0
    1d28:      	stp	q16, q7, [sp, #0x10]
    1d2c:      	bit.16b	v4, v7, v5
    1d30:      	zip1.8b	v5, v6, v0
    1d34:      	ushll.4s	v5, v5, #0x0
    1d38:      	shl.4s	v5, v5, #0x1f
    1d3c:      	cmlt.4s	v5, v5, #0
    1d40:      	bit.16b	v3, v16, v5
    1d44:      	stp	q3, q4, [x9]
    1d48:      	add	x9, x8, x13
    1d4c:      	movi.2d	v3, #0000000000000000
    1d50:      	movi.2d	v4, #0000000000000000
    1d54:      	movi.2d	v5, #0000000000000000
    1d58:      	movi.2d	v6, #0000000000000000
    1d5c:      	b	0x1d7c <_llm_rows.packet_batch.blocks+0xe68>
    1d60:      	add.2d	v4, v4, v23
    1d64:      	add.2d	v5, v5, v8
    1d68:      	add.2d	v6, v6, v21
    1d6c:      	add.2d	v3, v3, v14
    1d70:      	fmov	x12, d3
    1d74:      	cmp	x12, #0xc0
    1d78:      	b.ge	0x21f4 <_llm_rows.packet_batch.blocks+0x12e0>
    1d7c:      	mov.16b	v20, v14
    1d80:      	mov.16b	v25, v8
    1d84:      	mov.16b	v1, v23
    1d88:      	mov.16b	v14, v21
    1d8c:      	lsl	x11, x12, #5
    1d90:      	add	x12, x24, x11
    1d94:      	ldr	q7, [x12]
    1d98:      	and.16b	v7, v11, v7
    1d9c:      	ldp	q16, q17, [sp, #0x1c0]
    1da0:      	fmul.4s	v16, v7, v16
    1da4:      	fmul.4s	v16, v7, v16
    1da8:      	fmul.4s	v16, v7, v16
    1dac:      	fadd.4s	v16, v7, v16
    1db0:      	fmul.4s	v16, v16, v17
    1db4:      	and.16b	v16, v11, v16
    1db8:      	fabs.4s	v17, v16
    1dbc:      	fmul.4s	v18, v16, v16
    1dc0:      	ldr	q19, [sp, #0x220]
    1dc4:      	ldr	q21, [sp, #0x200]
    1dc8:      	fmla.4s	v19, v18, v21
    1dcc:      	ldr	q24, [sp, #0x240]
    1dd0:      	fmla.4s	v24, v18, v19
    1dd4:      	mov.16b	v19, v10
    1dd8:      	fmla.4s	v19, v18, v24
    1ddc:      	mov.16b	v24, v22
    1de0:      	fmla.4s	v24, v18, v19
    1de4:      	ldr	q10, [sp, #0x250]
    1de8:      	mov.16b	v19, v10
    1dec:      	fmla.4s	v19, v18, v24
    1df0:      	mov.16b	v24, v0
    1df4:      	fmla.4s	v24, v18, v19
    1df8:      	fmul.4s	v19, v17, v24
    1dfc:      	ldr	q24, [sp, #0x1e0]
    1e00:      	mov.16b	v15, v29
    1e04:      	fmla.4s	v24, v18, v29
    1e08:      	ldr	q29, [sp, #0x1f0]
    1e0c:      	fmla.4s	v29, v18, v24
    1e10:      	ldr	q24, [sp, #0x210]
    1e14:      	fmla.4s	v24, v18, v29
    1e18:      	ldr	q29, [sp, #0x230]
    1e1c:      	fmla.4s	v29, v18, v24
    1e20:      	movi.4s	v24, #0x3f, lsl #24
    1e24:      	fmla.4s	v24, v18, v29
    1e28:      	mov.16b	v29, v0
    1e2c:      	fmla.4s	v29, v18, v24
    1e30:      	fdiv.4s	v18, v19, v29
    1e34:      	fcmge.4s	v19, v26, v17
    1e38:      	and.16b	v24, v19, v17
    1e3c:      	mov.16b	v8, v28
    1e40:      	fcmge.4s	v29, v24, v28
    1e44:      	ldr	q21, [sp, #0x260]
    1e48:      	fcmge.4s	v28, v21, v24
    1e4c:      	and.16b	v28, v29, v28
    1e50:      	and.16b	v28, v28, v24
    1e54:      	mov.16b	v13, v30
    1e58:      	fmul.4s	v29, v28, v30
    1e5c:      	mov.16b	v23, v31
    1e60:      	movi.4s	v31, #0x4b, lsl #24
    1e64:      	fadd.4s	v29, v29, v31
    1e68:      	movi.4s	v31, #0xcb, lsl #24
    1e6c:      	fadd.4s	v29, v29, v31
    1e70:      	fcvtzs.4s	v29, v29
    1e74:      	scvtf.4s	v31, v29
    1e78:      	mov.16b	v30, v9
    1e7c:      	fmul.4s	v9, v31, v9
    1e80:      	fadd.4s	v28, v28, v9
    1e84:      	fmul.4s	v31, v31, v27
    1e88:      	fadd.4s	v28, v28, v31
    1e8c:      	ldp	q31, q9, [sp, #0x140]
    1e90:      	fmul.4s	v31, v28, v31
    1e94:      	fadd.4s	v31, v31, v9
    1e98:      	fmul.4s	v31, v28, v31
    1e9c:      	ldr	q9, [sp, #0x160]
    1ea0:      	fadd.4s	v31, v31, v9
    1ea4:      	fmul.4s	v31, v28, v31
    1ea8:      	ldr	q9, [sp, #0x1b0]
    1eac:      	fadd.4s	v31, v31, v9
    1eb0:      	fmul.4s	v31, v28, v31
    1eb4:      	fadd.4s	v31, v31, v10
    1eb8:      	fmul.4s	v31, v28, v31
    1ebc:      	fadd.4s	v31, v31, v2
    1ec0:      	fmul.4s	v9, v28, v28
    1ec4:      	fmul.4s	v31, v9, v31
    1ec8:      	fadd.4s	v28, v28, v31
    1ecc:      	fadd.4s	v28, v28, v0
    1ed0:      	movi.2d	v31, #0xffffffffffffffff
    1ed4:      	add.4s	v29, v29, v31
    1ed8:      	sshr.4s	v31, v29, #0x1
    1edc:      	shl.4s	v9, v31, #0x17
    1ee0:      	add.4s	v9, v9, v0
    1ee4:      	fmul.4s	v28, v28, v9
    1ee8:      	sub.4s	v29, v29, v31
    1eec:      	shl.4s	v29, v29, #0x17
    1ef0:      	add.4s	v29, v29, v0
    1ef4:      	fmul.4s	v28, v28, v29
    1ef8:      	fcmgt.4s	v24, v24, v21
    1efc:      	ldr	q29, [sp, #0x1a0]
    1f00:      	bsl.16b	v24, v29, v28
    1f04:      	fdiv.4s	v28, v23, v24
    1f08:      	fsub.4s	v29, v24, v28
    1f0c:      	fadd.4s	v24, v24, v28
    1f10:      	fdiv.4s	v24, v29, v24
    1f14:      	bsl.16b	v19, v24, v0
    1f18:      	fcmge.4s	v17, v0, v17
    1f1c:      	bsl.16b	v17, v18, v19
    1f20:      	mvni.4s	v18, #0x80, lsl #24
    1f24:      	bif.16b	v17, v16, v18
    1f28:      	fcmeq.4s	v16, v16, v16
    1f2c:      	fadd.4s	v17, v17, v0
    1f30:      	ldr	q18, [sp, #0x190]
    1f34:      	bif.16b	v17, v18, v16
    1f38:      	ldr	q16, [x12, #0x10]
    1f3c:      	fmul.4s	v7, v7, v2
    1f40:      	fmul.4s	v7, v7, v17
    1f44:      	add	x12, x26, x11
    1f48:      	ldr	q17, [x12]
    1f4c:      	and.16b	v17, v11, v17
    1f50:      	fadd.4s	v17, v17, v7
    1f54:      	ldr	q7, [x12, #0x10]
    1f58:      	ldr	q2, [sp, #0x120]
    1f5c:      	fmov	w12, s2
    1f60:      	add	x11, x9, x11
    1f64:      	tbz	w12, #0x0, 0x1f94 <_llm_rows.packet_batch.blocks+0x1080>
    1f68:      	str	s17, [x11]
    1f6c:      	and	w12, w12, #0xff
    1f70:      	tbnz	w12, #0x1, 0x1f9c <_llm_rows.packet_batch.blocks+0x1088>
    1f74:      	mov.16b	v21, v15
    1f78:      	ldr	q2, [sp, #0x180]
    1f7c:      	tbz	w12, #0x2, 0x1fb0 <_llm_rows.packet_batch.blocks+0x109c>
    1f80:      	add	x13, x11, #0x8
    1f84:      	st1.s	{ v17 }[2], [x13]
    1f88:      	mov.16b	v12, v11
    1f8c:      	tbnz	w12, #0x3, 0x1fb8 <_llm_rows.packet_batch.blocks+0x10a4>
    1f90:      	b	0x1fc0 <_llm_rows.packet_batch.blocks+0x10ac>
    1f94:      	and	w12, w12, #0xff
    1f98:      	tbz	w12, #0x1, 0x1f74 <_llm_rows.packet_batch.blocks+0x1060>
    1f9c:      	add	x13, x11, #0x4
    1fa0:      	st1.s	{ v17 }[1], [x13]
    1fa4:      	mov.16b	v21, v15
    1fa8:      	ldr	q2, [sp, #0x180]
    1fac:      	tbnz	w12, #0x2, 0x1f80 <_llm_rows.packet_batch.blocks+0x106c>
    1fb0:      	mov.16b	v12, v11
    1fb4:      	tbz	w12, #0x3, 0x1fc0 <_llm_rows.packet_batch.blocks+0x10ac>
    1fb8:      	add	x13, x11, #0xc
    1fbc:      	st1.s	{ v17 }[3], [x13]
    1fc0:      	ldr	q11, [sp, #0x170]
    1fc4:      	and.16b	v16, v11, v16
    1fc8:      	ldp	q17, q18, [sp, #0x1c0]
    1fcc:      	fmul.4s	v17, v16, v17
    1fd0:      	fmul.4s	v17, v16, v17
    1fd4:      	fmul.4s	v17, v16, v17
    1fd8:      	fadd.4s	v17, v16, v17
    1fdc:      	fmul.4s	v17, v17, v18
    1fe0:      	and.16b	v17, v11, v17
    1fe4:      	fabs.4s	v18, v17
    1fe8:      	fmul.4s	v19, v17, v17
    1fec:      	ldr	q24, [sp, #0x220]
    1ff0:      	ldp	q29, q28, [sp, #0x1f0]
    1ff4:      	fmla.4s	v24, v19, v28
    1ff8:      	ldp	q28, q10, [sp, #0x240]
    1ffc:      	fmla.4s	v28, v19, v24
    2000:      	mov.16b	v24, v2
    2004:      	fmla.4s	v24, v19, v28
    2008:      	mov.16b	v28, v22
    200c:      	fmla.4s	v28, v19, v24
    2010:      	mov.16b	v24, v10
    2014:      	fmla.4s	v24, v19, v28
    2018:      	mov.16b	v28, v0
    201c:      	fmla.4s	v28, v19, v24
    2020:      	fmul.4s	v24, v18, v28
    2024:      	ldr	q28, [sp, #0x1e0]
    2028:      	fmla.4s	v28, v19, v21
    202c:      	fmla.4s	v29, v19, v28
    2030:      	ldr	q28, [sp, #0x210]
    2034:      	fmla.4s	v28, v19, v29
    2038:      	ldr	q29, [sp, #0x230]
    203c:      	fmla.4s	v29, v19, v28
    2040:      	movi.4s	v28, #0x3f, lsl #24
    2044:      	fmla.4s	v28, v19, v29
    2048:      	mov.16b	v29, v0
    204c:      	fmla.4s	v29, v19, v28
    2050:      	fdiv.4s	v19, v24, v29
    2054:      	fcmge.4s	v24, v26, v18
    2058:      	and.16b	v28, v24, v18
    205c:      	fcmge.4s	v29, v28, v8
    2060:      	ldr	q2, [sp, #0x260]
    2064:      	fcmge.4s	v31, v2, v28
    2068:      	and.16b	v29, v29, v31
    206c:      	and.16b	v29, v29, v28
    2070:      	fmul.4s	v31, v29, v13
    2074:      	movi.4s	v21, #0x4b, lsl #24
    2078:      	fadd.4s	v31, v31, v21
    207c:      	movi.4s	v21, #0xcb, lsl #24
    2080:      	fadd.4s	v31, v31, v21
    2084:      	fcvtzs.4s	v31, v31
    2088:      	scvtf.4s	v9, v31
    208c:      	fmul.4s	v21, v9, v30
    2090:      	fadd.4s	v21, v29, v21
    2094:      	fmul.4s	v29, v9, v27
    2098:      	fadd.4s	v21, v21, v29
    209c:      	ldp	q29, q9, [sp, #0x140]
    20a0:      	fmul.4s	v29, v21, v29
    20a4:      	fadd.4s	v29, v29, v9
    20a8:      	fmul.4s	v29, v21, v29
    20ac:      	ldr	q9, [sp, #0x160]
    20b0:      	fadd.4s	v29, v29, v9
    20b4:      	fmul.4s	v29, v21, v29
    20b8:      	ldr	q9, [sp, #0x1b0]
    20bc:      	fadd.4s	v29, v29, v9
    20c0:      	fmul.4s	v29, v21, v29
    20c4:      	fadd.4s	v29, v29, v10
    20c8:      	fmul.4s	v29, v21, v29
    20cc:      	movi.4s	v9, #0x3f, lsl #24
    20d0:      	fadd.4s	v29, v29, v9
    20d4:      	fmul.4s	v9, v21, v21
    20d8:      	fmul.4s	v29, v9, v29
    20dc:      	fadd.4s	v21, v21, v29
    20e0:      	fadd.4s	v21, v21, v0
    20e4:      	movi.2d	v29, #0xffffffffffffffff
    20e8:      	add.4s	v29, v31, v29
    20ec:      	sshr.4s	v31, v29, #0x1
    20f0:      	shl.4s	v9, v31, #0x17
    20f4:      	add.4s	v9, v9, v0
    20f8:      	fmul.4s	v21, v21, v9
    20fc:      	sub.4s	v29, v29, v31
    2100:      	shl.4s	v29, v29, #0x17
    2104:      	add.4s	v29, v29, v0
    2108:      	fmul.4s	v21, v21, v29
    210c:      	fcmgt.4s	v28, v28, v2
    2110:      	ldr	q29, [sp, #0x1a0]
    2114:      	bit.16b	v21, v29, v28
    2118:      	mov.16b	v31, v23
    211c:      	fdiv.4s	v28, v23, v21
    2120:      	fsub.4s	v29, v21, v28
    2124:      	fadd.4s	v21, v21, v28
    2128:      	fdiv.4s	v21, v29, v21
    212c:      	bif.16b	v21, v0, v24
    2130:      	fcmge.4s	v18, v0, v18
    2134:      	bsl.16b	v18, v19, v21
    2138:      	movi.4s	v2, #0x3f, lsl #24
    213c:      	mvni.4s	v19, #0x80, lsl #24
    2140:      	bif.16b	v18, v17, v19
    2144:      	fcmeq.4s	v17, v17, v17
    2148:      	fadd.4s	v18, v18, v0
    214c:      	ldr	q19, [sp, #0x190]
    2150:      	bsl.16b	v17, v18, v19
    2154:      	fmul.4s	v16, v16, v2
    2158:      	fmul.4s	v16, v16, v17
    215c:      	and.16b	v7, v11, v7
    2160:      	fadd.4s	v7, v7, v16
    2164:      	tbz	w12, #0x4, 0x21ac <_llm_rows.packet_batch.blocks+0x1298>
    2168:      	str	s7, [x11, #0x10]
    216c:      	mov.16b	v11, v12
    2170:      	mov.16b	v21, v14
    2174:      	mov.16b	v23, v1
    2178:      	tbnz	w12, #0x5, 0x21bc <_llm_rows.packet_batch.blocks+0x12a8>
    217c:      	mov.16b	v9, v30
    2180:      	mov.16b	v28, v8
    2184:      	mov.16b	v29, v15
    2188:      	ldr	q10, [sp, #0x180]
    218c:      	mov.16b	v14, v20
    2190:      	tbz	w12, #0x6, 0x21dc <_llm_rows.packet_batch.blocks+0x12c8>
    2194:      	add	x13, x11, #0x18
    2198:      	st1.s	{ v7 }[2], [x13]
    219c:      	mov.16b	v30, v13
    21a0:      	mov.16b	v8, v25
    21a4:      	tbz	w12, #0x7, 0x1d60 <_llm_rows.packet_batch.blocks+0xe4c>
    21a8:      	b	0x21e8 <_llm_rows.packet_batch.blocks+0x12d4>
    21ac:      	mov.16b	v11, v12
    21b0:      	mov.16b	v21, v14
    21b4:      	mov.16b	v23, v1
    21b8:      	tbz	w12, #0x5, 0x217c <_llm_rows.packet_batch.blocks+0x1268>
    21bc:      	add	x13, x11, #0x14
    21c0:      	st1.s	{ v7 }[1], [x13]
    21c4:      	mov.16b	v9, v30
    21c8:      	mov.16b	v28, v8
    21cc:      	mov.16b	v29, v15
    21d0:      	ldr	q10, [sp, #0x180]
    21d4:      	mov.16b	v14, v20
    21d8:      	tbnz	w12, #0x6, 0x2194 <_llm_rows.packet_batch.blocks+0x1280>
    21dc:      	mov.16b	v30, v13
    21e0:      	mov.16b	v8, v25
    21e4:      	tbz	w12, #0x7, 0x1d60 <_llm_rows.packet_batch.blocks+0xe4c>
    21e8:      	add	x11, x11, #0x1c
    21ec:      	st1.s	{ v7 }[3], [x11]
    21f0:      	b	0x1d60 <_llm_rows.packet_batch.blocks+0xe4c>
    21f4:      	ldp	q1, q2, [sp, #0x1c0]
    21f8:      	ldr	q8, [sp, #0xc0]
    21fc:      	fmul.4s	v3, v8, v1
    2200:      	fmul.4s	v3, v8, v3
    2204:      	fmul.4s	v3, v8, v3
    2208:      	fadd.4s	v3, v8, v3
    220c:      	fmul.4s	v3, v3, v2
    2210:      	ldr	q2, [sp, #0x100]
    2214:      	zip1.8b	v4, v2, v0
    2218:      	ushll.4s	v4, v4, #0x0
    221c:      	shl.4s	v4, v4, #0x1f
    2220:      	cmlt.4s	v4, v4, #0
    2224:      	and.16b	v3, v4, v3
    2228:      	fabs.4s	v4, v3
    222c:      	fmul.4s	v5, v3, v3
    2230:      	ldr	q6, [sp, #0x220]
    2234:      	ldp	q16, q2, [sp, #0x1f0]
    2238:      	fmla.4s	v6, v5, v2
    223c:      	ldp	q7, q24, [sp, #0x240]
    2240:      	fmla.4s	v7, v5, v6
    2244:      	mov.16b	v6, v10
    2248:      	fmla.4s	v6, v5, v7
    224c:      	mov.16b	v7, v22
    2250:      	fmla.4s	v7, v5, v6
    2254:      	mov.16b	v6, v24
    2258:      	fmla.4s	v6, v5, v7
    225c:      	mov.16b	v7, v0
    2260:      	fmla.4s	v7, v5, v6
    2264:      	fmul.4s	v6, v4, v7
    2268:      	ldr	q7, [sp, #0x1e0]
    226c:      	fmla.4s	v7, v5, v29
    2270:      	fmla.4s	v16, v5, v7
    2274:      	ldr	q7, [sp, #0x210]
    2278:      	fmla.4s	v7, v5, v16
    227c:      	ldr	q16, [sp, #0x230]
    2280:      	fmla.4s	v16, v5, v7
    2284:      	movi.4s	v7, #0x3f, lsl #24
    2288:      	fmla.4s	v7, v5, v16
    228c:      	mov.16b	v16, v0
    2290:      	fmla.4s	v16, v5, v7
    2294:      	fdiv.4s	v5, v6, v16
    2298:      	mov.16b	v1, v26
    229c:      	fcmge.4s	v6, v26, v4
    22a0:      	and.16b	v7, v6, v4
    22a4:      	fcmge.4s	v16, v7, v28
    22a8:      	movi.4s	v21, #0x3f, lsl #24
    22ac:      	ldr	q2, [sp, #0x260]
    22b0:      	fcmge.4s	v17, v2, v7
    22b4:      	and.16b	v16, v16, v17
    22b8:      	and.16b	v16, v16, v7
    22bc:      	fmul.4s	v17, v16, v30
    22c0:      	movi.4s	v18, #0x4b, lsl #24
    22c4:      	fadd.4s	v17, v17, v18
    22c8:      	movi.4s	v18, #0xcb, lsl #24
    22cc:      	fadd.4s	v17, v17, v18
    22d0:      	fcvtzs.4s	v17, v17
    22d4:      	scvtf.4s	v18, v17
    22d8:      	fmul.4s	v19, v18, v9
    22dc:      	fadd.4s	v16, v16, v19
    22e0:      	fmul.4s	v18, v18, v27
    22e4:      	fadd.4s	v16, v16, v18
    22e8:      	ldp	q25, q23, [sp, #0x140]
    22ec:      	fmul.4s	v18, v16, v25
    22f0:      	fadd.4s	v18, v18, v23
    22f4:      	fmul.4s	v18, v16, v18
    22f8:      	ldr	q26, [sp, #0x160]
    22fc:      	fadd.4s	v18, v18, v26
    2300:      	fmul.4s	v18, v16, v18
    2304:      	ldr	q20, [sp, #0x1b0]
    2308:      	fadd.4s	v18, v18, v20
    230c:      	fmul.4s	v18, v16, v18
    2310:      	fadd.4s	v18, v18, v24
    2314:      	fmul.4s	v18, v16, v18
    2318:      	fadd.4s	v18, v18, v21
    231c:      	fmul.4s	v19, v16, v16
    2320:      	fmul.4s	v18, v19, v18
    2324:      	fadd.4s	v16, v16, v18
    2328:      	fadd.4s	v16, v16, v0
    232c:      	movi.2d	v18, #0xffffffffffffffff
    2330:      	add.4s	v17, v17, v18
    2334:      	sshr.4s	v18, v17, #0x1
    2338:      	shl.4s	v19, v18, #0x17
    233c:      	add.4s	v19, v19, v0
    2340:      	fmul.4s	v16, v16, v19
    2344:      	sub.4s	v17, v17, v18
    2348:      	shl.4s	v17, v17, #0x17
    234c:      	add.4s	v17, v17, v0
    2350:      	fmul.4s	v16, v16, v17
    2354:      	fcmgt.4s	v7, v7, v2
    2358:      	movi.4s	v2, #0x3f, lsl #24
    235c:      	ldr	q17, [sp, #0x1a0]
    2360:      	bsl.16b	v7, v17, v16
    2364:      	fdiv.4s	v16, v31, v7
    2368:      	fsub.4s	v17, v7, v16
    236c:      	fadd.4s	v7, v7, v16
    2370:      	fdiv.4s	v7, v17, v7
    2374:      	bsl.16b	v6, v7, v0
    2378:      	fcmge.4s	v4, v0, v4
    237c:      	bsl.16b	v4, v5, v6
    2380:      	ldr	d5, [sp, #0x8]
    2384:      	fmov	w9, s5
    2388:      	mvni.4s	v5, #0x80, lsl #24
    238c:      	bif.16b	v4, v3, v5
    2390:      	fcmeq.4s	v3, v3, v3
    2394:      	fadd.4s	v4, v4, v0
    2398:      	ldr	q5, [sp, #0x190]
    239c:      	bsl.16b	v3, v4, v5
    23a0:      	fmul.4s	v4, v8, v2
    23a4:      	fmul.4s	v3, v4, v3
    23a8:      	ldr	q2, [sp, #0x10]
    23ac:      	fadd.4s	v3, v3, v2
    23b0:      	ldp	q2, q4, [sp, #0x50]
    23b4:      	stp	q4, q2, [sp, #0x300]
    23b8:      	ldp	q2, q4, [sp, #0x30]
    23bc:      	stp	q4, q2, [sp, #0x320]
    23c0:      	and	x11, x10, #0x7
    23c4:      	add	x12, sp, #0x300
    23c8:      	ldr	x11, [x12, x11, lsl #3]
    23cc:      	sub	x10, x11, x10
    23d0:      	add	x8, x8, x10, lsl #2
    23d4:      	tbz	w9, #0x0, 0x23f8 <_llm_rows.packet_batch.blocks+0x14e4>
    23d8:      	str	s3, [x8]
    23dc:      	ldr	q21, [sp, #0x70]
    23e0:      	tbnz	w9, #0x1, 0x2400 <_llm_rows.packet_batch.blocks+0x14ec>
    23e4:      	tbz	w9, #0x2, 0x240c <_llm_rows.packet_batch.blocks+0x14f8>
    23e8:      	add	x10, x8, #0x8
    23ec:      	st1.s	{ v3 }[2], [x10]
    23f0:      	tbnz	w9, #0x3, 0x2410 <_llm_rows.packet_batch.blocks+0x14fc>
    23f4:      	b	0x2418 <_llm_rows.packet_batch.blocks+0x1504>
    23f8:      	ldr	q21, [sp, #0x70]
    23fc:      	tbz	w9, #0x1, 0x23e4 <_llm_rows.packet_batch.blocks+0x14d0>
    2400:      	add	x10, x8, #0x4
    2404:      	st1.s	{ v3 }[1], [x10]
    2408:      	tbnz	w9, #0x2, 0x23e8 <_llm_rows.packet_batch.blocks+0x14d4>
    240c:      	tbz	w9, #0x3, 0x2418 <_llm_rows.packet_batch.blocks+0x1504>
    2410:      	add	x10, x8, #0xc
    2414:      	st1.s	{ v3 }[3], [x10]
    2418:      	ldp	q4, q2, [sp, #0x1c0]
    241c:      	fmul.4s	v3, v21, v4
    2420:      	fmul.4s	v3, v21, v3
    2424:      	fmul.4s	v3, v21, v3
    2428:      	fadd.4s	v3, v21, v3
    242c:      	fmul.4s	v3, v3, v2
    2430:      	ldr	q2, [sp, #0x100]
    2434:      	zip2.8b	v4, v2, v0
    2438:      	ushll.4s	v4, v4, #0x0
    243c:      	shl.4s	v4, v4, #0x1f
    2440:      	cmlt.4s	v4, v4, #0
    2444:      	and.16b	v3, v4, v3
    2448:      	fmul.4s	v4, v3, v3
    244c:      	ldr	q5, [sp, #0x220]
    2450:      	ldp	q7, q2, [sp, #0x1f0]
    2454:      	fmla.4s	v5, v4, v2
    2458:      	ldr	q2, [sp, #0x240]
    245c:      	fmla.4s	v2, v4, v5
    2460:      	fmla.4s	v10, v4, v2
    2464:      	fmla.4s	v22, v4, v10
    2468:      	ldr	q2, [sp, #0x250]
    246c:      	mov.16b	v5, v2
    2470:      	fmla.4s	v5, v4, v22
    2474:      	mov.16b	v6, v0
    2478:      	fmla.4s	v6, v4, v5
    247c:      	ldr	q5, [sp, #0x1e0]
    2480:      	fmla.4s	v5, v4, v29
    2484:      	fmla.4s	v7, v4, v5
    2488:      	ldr	q5, [sp, #0x210]
    248c:      	fmla.4s	v5, v4, v7
    2490:      	ldr	q7, [sp, #0x230]
    2494:      	fmla.4s	v7, v4, v5
    2498:      	movi.4s	v5, #0x3f, lsl #24
    249c:      	fmla.4s	v5, v4, v7
    24a0:      	mov.16b	v7, v0
    24a4:      	fmla.4s	v7, v4, v5
    24a8:      	fabs.4s	v4, v3
    24ac:      	fmul.4s	v5, v4, v6
    24b0:      	fdiv.4s	v5, v5, v7
    24b4:      	fcmge.4s	v6, v1, v4
    24b8:      	and.16b	v7, v6, v4
    24bc:      	fcmge.4s	v16, v7, v28
    24c0:      	ldr	q1, [sp, #0x260]
    24c4:      	fcmge.4s	v17, v1, v7
    24c8:      	and.16b	v16, v16, v17
    24cc:      	and.16b	v16, v16, v7
    24d0:      	fmul.4s	v17, v16, v30
    24d4:      	movi.4s	v18, #0x4b, lsl #24
    24d8:      	fadd.4s	v17, v17, v18
    24dc:      	movi.4s	v18, #0xcb, lsl #24
    24e0:      	fadd.4s	v17, v17, v18
    24e4:      	fcvtzs.4s	v17, v17
    24e8:      	scvtf.4s	v18, v17
    24ec:      	fmul.4s	v19, v18, v9
    24f0:      	fadd.4s	v16, v16, v19
    24f4:      	fmul.4s	v18, v18, v27
    24f8:      	fadd.4s	v16, v16, v18
    24fc:      	fmul.4s	v18, v16, v25
    2500:      	fadd.4s	v18, v18, v23
    2504:      	fmul.4s	v18, v16, v18
    2508:      	fadd.4s	v18, v18, v26
    250c:      	fmul.4s	v18, v16, v18
    2510:      	fadd.4s	v18, v18, v20
    2514:      	fmul.4s	v18, v16, v18
    2518:      	fadd.4s	v2, v18, v2
    251c:      	fmul.4s	v2, v16, v2
    2520:      	movi.4s	v18, #0x3f, lsl #24
    2524:      	fadd.4s	v2, v2, v18
    2528:      	fmul.4s	v18, v16, v16
    252c:      	fmul.4s	v2, v18, v2
    2530:      	fadd.4s	v2, v16, v2
    2534:      	fadd.4s	v2, v2, v0
    2538:      	movi.2d	v16, #0xffffffffffffffff
    253c:      	add.4s	v16, v17, v16
    2540:      	sshr.4s	v17, v16, #0x1
    2544:      	shl.4s	v18, v17, #0x17
    2548:      	add.4s	v18, v18, v0
    254c:      	fmul.4s	v2, v2, v18
    2550:      	sub.4s	v16, v16, v17
    2554:      	shl.4s	v16, v16, #0x17
    2558:      	add.4s	v16, v16, v0
    255c:      	fmul.4s	v2, v2, v16
    2560:      	fcmgt.4s	v1, v7, v1
    2564:      	ldr	q7, [sp, #0x1a0]
    2568:      	bsl.16b	v1, v7, v2
    256c:      	fdiv.4s	v2, v31, v1
    2570:      	fsub.4s	v7, v1, v2
    2574:      	fadd.4s	v1, v1, v2
    2578:      	fdiv.4s	v1, v7, v1
    257c:      	bif.16b	v1, v0, v6
    2580:      	fcmge.4s	v2, v0, v4
    2584:      	bit.16b	v1, v5, v2
    2588:      	mvni.4s	v2, #0x80, lsl #24
    258c:      	bif.16b	v1, v3, v2
    2590:      	fadd.4s	v0, v1, v0
    2594:      	fcmeq.4s	v1, v3, v3
    2598:      	ldr	q2, [sp, #0x190]
    259c:      	bif.16b	v0, v2, v1
    25a0:      	movi.4s	v1, #0x3f, lsl #24
    25a4:      	fmul.4s	v1, v21, v1
    25a8:      	fmul.4s	v0, v1, v0
    25ac:      	ldr	q1, [sp, #0x20]
    25b0:      	fadd.4s	v0, v0, v1
    25b4:      	tbz	w9, #0x4, 0x2b8c <_llm_rows.packet_batch.blocks+0x1c78>
    25b8:      	str	s0, [x8, #0x10]
    25bc:      	tbnz	w9, #0x5, 0x2b90 <_llm_rows.packet_batch.blocks+0x1c7c>
    25c0:      	tbz	w9, #0x6, 0x2b9c <_llm_rows.packet_batch.blocks+0x1c88>
    25c4:      	add	x10, x8, #0x18
    25c8:      	st1.s	{ v0 }[2], [x10]
    25cc:      	tbnz	w9, #0x7, 0x2ba0 <_llm_rows.packet_batch.blocks+0x1c8c>
    25d0:      	b	0xfe8 <_llm_rows.packet_batch.blocks+0xd4>
    25d4:      	xtn.8b	v3, v23
    25d8:      	movi	d4, #0x0000000000ffff
    25dc:      	and.8b	v19, v3, v4
    25e0:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x10ec>
    25e4:      	ldr	d4, [x10]
    25e8:      	and.8b	v3, v3, v4
    25ec:      	addv.8b	b3, v3
    25f0:      	fmov	w12, s3
    25f4:      	umaxv.8b	b3, v19
    25f8:      	fmov	w10, s3
    25fc:      	rbit	w13, w12
    2600:      	clz	w13, w13
    2604:      	tst	w10, #0x1
    2608:      	csel	w10, w13, wzr, ne
    260c:      	mov	w13, #0x600             ; =1536
    2610:      	dup.2d	v5, x13
    2614:      	ldr	d17, [sp, #0x40]
    2618:      	ldr	d1, [sp, #0x20]
    261c:      	ldr	q4, [sp, #0x100]
    2620:      	umlal.2d	v4, v1, v17
    2624:      	mov	b3, v19[0]
    2628:      	mov.b	v3[4], v19[1]
    262c:      	str	q5, [sp, #0x100]
    2630:      	add.2d	v1, v4, v5
    2634:      	ushll.2d	v3, v3, #0x0
    2638:      	shl.2d	v3, v3, #0x3f
    263c:      	cmlt.2d	v3, v3, #0
    2640:      	str	q1, [sp, #0x20]
    2644:      	and.16b	v3, v3, v1
    2648:      	movi.2d	v4, #0000000000000000
    264c:      	stp	q4, q4, [sp, #0x2d0]
    2650:      	stp	q3, q4, [sp, #0x2b0]
    2654:      	and	x13, x10, #0x7
    2658:      	add	x14, sp, #0x2b0
    265c:      	ldr	x13, [x14, x13, lsl #3]
    2660:      	sub	x13, x13, x10
    2664:      	lsl	x13, x13, #2
    2668:      	add	x11, x11, x13
    266c:      	movi.2d	v14, #0000000000000000
    2670:      	movi.2d	v8, #0000000000000000
    2674:      	tbz	w12, #0x0, 0x267c <_llm_rows.packet_batch.blocks+0x1768>
    2678:      	ldr	s14, [x11]
    267c:      	ldr	q11, [sp, #0x120]
    2680:      	ldr	q10, [sp, #0xc0]
    2684:      	ldr	q6, [sp, #0x70]
    2688:      	ldr	d7, [sp, #0x60]
    268c:      	ldr	d16, [sp, #0x50]
    2690:      	ldr	d18, [sp, #0x30]
    2694:      	tbz	w12, #0x1, 0x274c <_llm_rows.packet_batch.blocks+0x1838>
    2698:      	add	x14, x11, #0x4
    269c:      	ld1.s	{ v14 }[1], [x14]
    26a0:      	tbnz	w12, #0x2, 0x2750 <_llm_rows.packet_batch.blocks+0x183c>
    26a4:      	tbz	w12, #0x3, 0x275c <_llm_rows.packet_batch.blocks+0x1848>
    26a8:      	add	x14, x11, #0xc
    26ac:      	ld1.s	{ v14 }[3], [x14]
    26b0:      	tbnz	w12, #0x4, 0x2760 <_llm_rows.packet_batch.blocks+0x184c>
    26b4:      	tbz	w12, #0x5, 0x276c <_llm_rows.packet_batch.blocks+0x1858>
    26b8:      	add	x14, x11, #0x14
    26bc:      	ld1.s	{ v8 }[1], [x14]
    26c0:      	tbnz	w12, #0x6, 0x2770 <_llm_rows.packet_batch.blocks+0x185c>
    26c4:      	tbz	w12, #0x7, 0x26d0 <_llm_rows.packet_batch.blocks+0x17bc>
    26c8:      	add	x11, x11, #0x1c
    26cc:      	ld1.s	{ v8 }[3], [x11]
    26d0:      	adrp	x11, 0x2000 <_llm_rows.packet_batch.blocks+0x10ec>
    26d4:      	ldr	d3, [x11]
    26d8:      	shl.8b	v4, v19, #0x7
    26dc:      	cmlt.8b	v4, v4, #0
    26e0:      	and.8b	v3, v4, v3
    26e4:      	addv.8b	b3, v3
    26e8:      	str	d3, [sp, #0x10]
    26ec:      	fmov	w11, s3
    26f0:      	add	x9, x9, x13
    26f4:      	movi.2d	v4, #0000000000000000
    26f8:      	movi.2d	v13, #0000000000000000
    26fc:      	tbz	w11, #0x0, 0x2780 <_llm_rows.packet_batch.blocks+0x186c>
    2700:      	ldr	s4, [x9]
    2704:      	tbnz	w11, #0x1, 0x2784 <_llm_rows.packet_batch.blocks+0x1870>
    2708:      	tbz	w11, #0x2, 0x2790 <_llm_rows.packet_batch.blocks+0x187c>
    270c:      	add	x12, x9, #0x8
    2710:      	ld1.s	{ v4 }[2], [x12]
    2714:      	tbnz	w11, #0x3, 0x2794 <_llm_rows.packet_batch.blocks+0x1880>
    2718:      	tbz	w11, #0x4, 0x27a0 <_llm_rows.packet_batch.blocks+0x188c>
    271c:      	add	x12, x9, #0x10
    2720:      	ld1.s	{ v13 }[0], [x12]
    2724:      	tbnz	w11, #0x5, 0x27a4 <_llm_rows.packet_batch.blocks+0x1890>
    2728:      	tbz	w11, #0x6, 0x27b0 <_llm_rows.packet_batch.blocks+0x189c>
    272c:      	add	x12, x9, #0x18
    2730:      	ld1.s	{ v13 }[2], [x12]
    2734:      	umlal.2d	v6, v18, v17
    2738:      	umlal.2d	v10, v16, v17
    273c:      	umlal.2d	v11, v7, v17
    2740:      	mov.16b	v3, v6
    2744:      	tbnz	w11, #0x7, 0x27c4 <_llm_rows.packet_batch.blocks+0x18b0>
    2748:      	b	0x27cc <_llm_rows.packet_batch.blocks+0x18b8>
    274c:      	tbz	w12, #0x2, 0x26a4 <_llm_rows.packet_batch.blocks+0x1790>
    2750:      	add	x14, x11, #0x8
    2754:      	ld1.s	{ v14 }[2], [x14]
    2758:      	tbnz	w12, #0x3, 0x26a8 <_llm_rows.packet_batch.blocks+0x1794>
    275c:      	tbz	w12, #0x4, 0x26b4 <_llm_rows.packet_batch.blocks+0x17a0>
    2760:      	add	x14, x11, #0x10
    2764:      	ld1.s	{ v8 }[0], [x14]
    2768:      	tbnz	w12, #0x5, 0x26b8 <_llm_rows.packet_batch.blocks+0x17a4>
    276c:      	tbz	w12, #0x6, 0x26c4 <_llm_rows.packet_batch.blocks+0x17b0>
    2770:      	add	x14, x11, #0x18
    2774:      	ld1.s	{ v8 }[2], [x14]
    2778:      	tbnz	w12, #0x7, 0x26c8 <_llm_rows.packet_batch.blocks+0x17b4>
    277c:      	b	0x26d0 <_llm_rows.packet_batch.blocks+0x17bc>
    2780:      	tbz	w11, #0x1, 0x2708 <_llm_rows.packet_batch.blocks+0x17f4>
    2784:      	add	x12, x9, #0x4
    2788:      	ld1.s	{ v4 }[1], [x12]
    278c:      	tbnz	w11, #0x2, 0x270c <_llm_rows.packet_batch.blocks+0x17f8>
    2790:      	tbz	w11, #0x3, 0x2718 <_llm_rows.packet_batch.blocks+0x1804>
    2794:      	add	x12, x9, #0xc
    2798:      	ld1.s	{ v4 }[3], [x12]
    279c:      	tbnz	w11, #0x4, 0x271c <_llm_rows.packet_batch.blocks+0x1808>
    27a0:      	tbz	w11, #0x5, 0x2728 <_llm_rows.packet_batch.blocks+0x1814>
    27a4:      	add	x12, x9, #0x14
    27a8:      	ld1.s	{ v13 }[1], [x12]
    27ac:      	tbnz	w11, #0x6, 0x272c <_llm_rows.packet_batch.blocks+0x1818>
    27b0:      	umlal.2d	v6, v18, v17
    27b4:      	umlal.2d	v10, v16, v17
    27b8:      	umlal.2d	v11, v7, v17
    27bc:      	mov.16b	v3, v6
    27c0:      	tbz	w11, #0x7, 0x27cc <_llm_rows.packet_batch.blocks+0x18b8>
    27c4:      	add	x9, x9, #0x1c
    27c8:      	ld1.s	{ v13 }[3], [x9]
    27cc:      	ldp	q6, q1, [sp, #0x1c0]
    27d0:      	fmul.4s	v5, v14, v6
    27d4:      	fmul.4s	v5, v14, v5
    27d8:      	fmul.4s	v5, v14, v5
    27dc:      	fadd.4s	v5, v14, v5
    27e0:      	fmul.4s	v5, v5, v1
    27e4:      	str	q19, [sp, #0x120]
    27e8:      	zip1.8b	v6, v19, v0
    27ec:      	ushll.4s	v6, v6, #0x0
    27f0:      	shl.4s	v6, v6, #0x1f
    27f4:      	cmlt.4s	v6, v6, #0
    27f8:      	and.16b	v5, v6, v5
    27fc:      	fabs.4s	v6, v5
    2800:      	fmul.4s	v7, v5, v5
    2804:      	ldr	q16, [sp, #0x220]
    2808:      	ldp	q18, q1, [sp, #0x1f0]
    280c:      	fmla.4s	v16, v7, v1
    2810:      	ldp	q17, q21, [sp, #0x240]
    2814:      	fmla.4s	v17, v7, v16
    2818:      	ldr	q16, [sp, #0x180]
    281c:      	fmla.4s	v16, v7, v17
    2820:      	str	q22, [sp, #0x170]
    2824:      	fmla.4s	v22, v7, v16
    2828:      	mov.16b	v16, v21
    282c:      	fmla.4s	v16, v7, v22
    2830:      	mov.16b	v17, v0
    2834:      	fmla.4s	v17, v7, v16
    2838:      	fmul.4s	v16, v6, v17
    283c:      	ldr	q17, [sp, #0x1e0]
    2840:      	fmla.4s	v17, v7, v29
    2844:      	fmla.4s	v18, v7, v17
    2848:      	ldr	q17, [sp, #0x210]
    284c:      	fmla.4s	v17, v7, v18
    2850:      	ldr	q18, [sp, #0x230]
    2854:      	fmla.4s	v18, v7, v17
    2858:      	movi.4s	v17, #0x3f, lsl #24
    285c:      	fmla.4s	v17, v7, v18
    2860:      	mov.16b	v18, v0
    2864:      	fmla.4s	v18, v7, v17
    2868:      	fdiv.4s	v7, v16, v18
    286c:      	mov.16b	v1, v24
    2870:      	fcmge.4s	v16, v24, v6
    2874:      	and.16b	v17, v16, v6
    2878:      	fcmge.4s	v18, v17, v28
    287c:      	ldr	q22, [sp, #0x260]
    2880:      	fcmge.4s	v19, v22, v17
    2884:      	and.16b	v18, v18, v19
    2888:      	and.16b	v18, v18, v17
    288c:      	fmul.4s	v19, v18, v30
    2890:      	movi.4s	v24, #0x4b, lsl #24
    2894:      	fadd.4s	v19, v19, v24
    2898:      	movi.4s	v24, #0xcb, lsl #24
    289c:      	fadd.4s	v19, v19, v24
    28a0:      	fcvtzs.4s	v19, v19
    28a4:      	scvtf.4s	v15, v19
    28a8:      	fmul.4s	v12, v15, v9
    28ac:      	fadd.4s	v18, v18, v12
    28b0:      	fmul.4s	v12, v15, v27
    28b4:      	fadd.4s	v18, v18, v12
    28b8:      	fmul.4s	v12, v18, v26
    28bc:      	fadd.4s	v12, v12, v20
    28c0:      	fmul.4s	v12, v18, v12
    28c4:      	fadd.4s	v12, v12, v25
    28c8:      	fmul.4s	v12, v18, v12
    28cc:      	ldr	q23, [sp, #0x1b0]
    28d0:      	fadd.4s	v12, v12, v23
    28d4:      	fmul.4s	v12, v18, v12
    28d8:      	fadd.4s	v12, v12, v21
    28dc:      	fmul.4s	v12, v18, v12
    28e0:      	fadd.4s	v12, v12, v2
    28e4:      	fmul.4s	v15, v18, v18
    28e8:      	fmul.4s	v12, v15, v12
    28ec:      	fadd.4s	v18, v18, v12
    28f0:      	fadd.4s	v18, v18, v0
    28f4:      	movi.2d	v24, #0xffffffffffffffff
    28f8:      	add.4s	v19, v19, v24
    28fc:      	sshr.4s	v12, v19, #0x1
    2900:      	shl.4s	v15, v12, #0x17
    2904:      	add.4s	v15, v15, v0
    2908:      	fmul.4s	v18, v18, v15
    290c:      	sub.4s	v19, v19, v12
    2910:      	shl.4s	v19, v19, #0x17
    2914:      	add.4s	v19, v19, v0
    2918:      	fmul.4s	v18, v18, v19
    291c:      	fcmgt.4s	v17, v17, v22
    2920:      	ldr	q19, [sp, #0x1a0]
    2924:      	bsl.16b	v17, v19, v18
    2928:      	fdiv.4s	v18, v31, v17
    292c:      	fsub.4s	v19, v17, v18
    2930:      	fadd.4s	v17, v17, v18
    2934:      	fdiv.4s	v17, v19, v17
    2938:      	bsl.16b	v16, v17, v0
    293c:      	fcmge.4s	v6, v0, v6
    2940:      	bsl.16b	v6, v7, v16
    2944:      	ldr	q17, [sp, #0x100]
    2948:      	add.2d	v7, v3, v17
    294c:      	add.2d	v16, v10, v17
    2950:      	add.2d	v17, v11, v17
    2954:      	mvni.4s	v18, #0x80, lsl #24
    2958:      	bif.16b	v6, v5, v18
    295c:      	fcmeq.4s	v5, v5, v5
    2960:      	fadd.4s	v6, v6, v0
    2964:      	ldr	q18, [sp, #0x190]
    2968:      	bsl.16b	v5, v6, v18
    296c:      	fmul.4s	v6, v14, v2
    2970:      	fmul.4s	v5, v6, v5
    2974:      	fadd.4s	v4, v4, v5
    2978:      	ldr	q2, [sp, #0x20]
    297c:      	stp	q2, q7, [sp, #0x270]
    2980:      	stp	q16, q17, [sp, #0x290]
    2984:      	ldr	d2, [sp, #0x10]
    2988:      	fmov	w9, s2
    298c:      	and	x11, x10, #0x7
    2990:      	add	x12, sp, #0x270
    2994:      	ldr	x11, [x12, x11, lsl #3]
    2998:      	sub	x10, x11, x10
    299c:      	add	x8, x8, x10, lsl #2
    29a0:      	tbz	w9, #0x0, 0x29c8 <_llm_rows.packet_batch.blocks+0x1ab4>
    29a4:      	str	s4, [x8]
    29a8:      	tbnz	w9, #0x1, 0x29cc <_llm_rows.packet_batch.blocks+0x1ab8>
    29ac:      	ldr	q6, [sp, #0x170]
    29b0:      	ldr	q5, [sp, #0x120]
    29b4:      	tbz	w9, #0x2, 0x29e0 <_llm_rows.packet_batch.blocks+0x1acc>
    29b8:      	add	x10, x8, #0x8
    29bc:      	st1.s	{ v4 }[2], [x10]
    29c0:      	tbnz	w9, #0x3, 0x29e4 <_llm_rows.packet_batch.blocks+0x1ad0>
    29c4:      	b	0x29ec <_llm_rows.packet_batch.blocks+0x1ad8>
    29c8:      	tbz	w9, #0x1, 0x29ac <_llm_rows.packet_batch.blocks+0x1a98>
    29cc:      	add	x10, x8, #0x4
    29d0:      	st1.s	{ v4 }[1], [x10]
    29d4:      	ldr	q6, [sp, #0x170]
    29d8:      	ldr	q5, [sp, #0x120]
    29dc:      	tbnz	w9, #0x2, 0x29b8 <_llm_rows.packet_batch.blocks+0x1aa4>
    29e0:      	tbz	w9, #0x3, 0x29ec <_llm_rows.packet_batch.blocks+0x1ad8>
    29e4:      	add	x10, x8, #0xc
    29e8:      	st1.s	{ v4 }[3], [x10]
    29ec:      	ldp	q4, q2, [sp, #0x1c0]
    29f0:      	fmul.4s	v3, v8, v4
    29f4:      	fmul.4s	v3, v8, v3
    29f8:      	fmul.4s	v3, v8, v3
    29fc:      	fadd.4s	v3, v8, v3
    2a00:      	fmul.4s	v3, v3, v2
    2a04:      	zip2.8b	v4, v5, v0
    2a08:      	ushll.4s	v4, v4, #0x0
    2a0c:      	shl.4s	v4, v4, #0x1f
    2a10:      	cmlt.4s	v4, v4, #0
    2a14:      	and.16b	v3, v4, v3
    2a18:      	fmul.4s	v4, v3, v3
    2a1c:      	ldr	q2, [sp, #0x220]
    2a20:      	ldp	q7, q5, [sp, #0x1f0]
    2a24:      	fmla.4s	v2, v4, v5
    2a28:      	ldr	q5, [sp, #0x240]
    2a2c:      	fmla.4s	v5, v4, v2
    2a30:      	ldr	q2, [sp, #0x180]
    2a34:      	fmla.4s	v2, v4, v5
    2a38:      	fmla.4s	v6, v4, v2
    2a3c:      	ldr	q2, [sp, #0x250]
    2a40:      	mov.16b	v5, v2
    2a44:      	fmla.4s	v5, v4, v6
    2a48:      	mov.16b	v6, v0
    2a4c:      	fmla.4s	v6, v4, v5
    2a50:      	ldr	q5, [sp, #0x1e0]
    2a54:      	fmla.4s	v5, v4, v29
    2a58:      	fmla.4s	v7, v4, v5
    2a5c:      	ldr	q5, [sp, #0x210]
    2a60:      	fmla.4s	v5, v4, v7
    2a64:      	ldr	q7, [sp, #0x230]
    2a68:      	fmla.4s	v7, v4, v5
    2a6c:      	movi.4s	v5, #0x3f, lsl #24
    2a70:      	fmla.4s	v5, v4, v7
    2a74:      	mov.16b	v7, v0
    2a78:      	fmla.4s	v7, v4, v5
    2a7c:      	fabs.4s	v4, v3
    2a80:      	fmul.4s	v5, v4, v6
    2a84:      	fdiv.4s	v5, v5, v7
    2a88:      	fcmge.4s	v6, v1, v4
    2a8c:      	and.16b	v7, v6, v4
    2a90:      	fcmge.4s	v16, v7, v28
    2a94:      	ldr	q1, [sp, #0x260]
    2a98:      	fcmge.4s	v17, v1, v7
    2a9c:      	and.16b	v16, v16, v17
    2aa0:      	and.16b	v16, v16, v7
    2aa4:      	fmul.4s	v17, v16, v30
    2aa8:      	movi.4s	v18, #0x4b, lsl #24
    2aac:      	fadd.4s	v17, v17, v18
    2ab0:      	movi.4s	v18, #0xcb, lsl #24
    2ab4:      	fadd.4s	v17, v17, v18
    2ab8:      	fcvtzs.4s	v17, v17
    2abc:      	scvtf.4s	v18, v17
    2ac0:      	fmul.4s	v19, v18, v9
    2ac4:      	fadd.4s	v16, v16, v19
    2ac8:      	fmul.4s	v18, v18, v27
    2acc:      	fadd.4s	v16, v16, v18
    2ad0:      	fmul.4s	v18, v16, v26
    2ad4:      	fadd.4s	v18, v18, v20
    2ad8:      	fmul.4s	v18, v16, v18
    2adc:      	fadd.4s	v18, v18, v25
    2ae0:      	fmul.4s	v18, v16, v18
    2ae4:      	ldr	q19, [sp, #0x1b0]
    2ae8:      	fadd.4s	v18, v18, v19
    2aec:      	fmul.4s	v18, v16, v18
    2af0:      	fadd.4s	v2, v18, v2
    2af4:      	fmul.4s	v2, v16, v2
    2af8:      	movi.4s	v18, #0x3f, lsl #24
    2afc:      	fadd.4s	v2, v2, v18
    2b00:      	fmul.4s	v18, v16, v16
    2b04:      	fmul.4s	v2, v18, v2
    2b08:      	fadd.4s	v2, v16, v2
    2b0c:      	fadd.4s	v2, v2, v0
    2b10:      	movi.2d	v16, #0xffffffffffffffff
    2b14:      	add.4s	v16, v17, v16
    2b18:      	sshr.4s	v17, v16, #0x1
    2b1c:      	shl.4s	v18, v17, #0x17
    2b20:      	add.4s	v18, v18, v0
    2b24:      	fmul.4s	v2, v2, v18
    2b28:      	sub.4s	v16, v16, v17
    2b2c:      	shl.4s	v16, v16, #0x17
    2b30:      	add.4s	v16, v16, v0
    2b34:      	fmul.4s	v2, v2, v16
    2b38:      	fcmgt.4s	v1, v7, v1
    2b3c:      	ldr	q7, [sp, #0x1a0]
    2b40:      	bsl.16b	v1, v7, v2
    2b44:      	fdiv.4s	v2, v31, v1
    2b48:      	fsub.4s	v7, v1, v2
    2b4c:      	fadd.4s	v1, v1, v2
    2b50:      	fdiv.4s	v1, v7, v1
    2b54:      	bif.16b	v1, v0, v6
    2b58:      	fcmge.4s	v2, v0, v4
    2b5c:      	bit.16b	v1, v5, v2
    2b60:      	mvni.4s	v2, #0x80, lsl #24
    2b64:      	bif.16b	v1, v3, v2
    2b68:      	fadd.4s	v0, v1, v0
    2b6c:      	fcmeq.4s	v1, v3, v3
    2b70:      	ldr	q2, [sp, #0x190]
    2b74:      	bif.16b	v0, v2, v1
    2b78:      	movi.4s	v1, #0x3f, lsl #24
    2b7c:      	fmul.4s	v1, v8, v1
    2b80:      	fmul.4s	v0, v1, v0
    2b84:      	fadd.4s	v0, v13, v0
    2b88:      	tbnz	w9, #0x4, 0x25b8 <_llm_rows.packet_batch.blocks+0x16a4>
    2b8c:      	tbz	w9, #0x5, 0x25c0 <_llm_rows.packet_batch.blocks+0x16ac>
    2b90:      	add	x10, x8, #0x14
    2b94:      	st1.s	{ v0 }[1], [x10]
    2b98:      	tbnz	w9, #0x6, 0x25c4 <_llm_rows.packet_batch.blocks+0x16b0>
    2b9c:      	tbz	w9, #0x7, 0xfe8 <_llm_rows.packet_batch.blocks+0xd4>
    2ba0:      	add	x8, x8, #0x1c
    2ba4:      	st1.s	{ v0 }[3], [x8]
    2ba8:      	b	0xfe8 <_llm_rows.packet_batch.blocks+0xd4>
    2bac:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    2bb0:      	add	sp, sp, #0x420
    2bb4:      	ldp	x29, x30, [sp, #0x90]
    2bb8:      	ldp	x20, x19, [sp, #0x80]
    2bbc:      	ldp	x22, x21, [sp, #0x70]
    2bc0:      	ldp	x24, x23, [sp, #0x60]
    2bc4:      	ldp	x26, x25, [sp, #0x50]
    2bc8:      	ldp	x28, x27, [sp, #0x40]
    2bcc:      	ldp	d9, d8, [sp, #0x30]
    2bd0:      	ldp	d11, d10, [sp, #0x20]
    2bd4:      	ldp	d13, d12, [sp, #0x10]
    2bd8:      	ldp	d15, d14, [sp], #0xa0
    2bdc:      	ret

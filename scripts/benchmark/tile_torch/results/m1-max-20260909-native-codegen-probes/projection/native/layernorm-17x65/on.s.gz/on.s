
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/layernorm-17x65/on/object/tile_xir_w8_37895_1788936535344320_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x50]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	sub	sp, sp, #0x260
      18:      	ldr	x9, [x0]
      1c:      	ldr	x12, [x0, #0x10]
      20:      	ldr	x10, [x0, #0x20]
      24:      	ldr	w8, [x1]
      28:      	ldr	w11, [x1, #0x24]
      2c:      	add	w8, w11, w8, lsl #5
      30:      	lsr	w8, w8, #3
      34:      	mov	w13, #0x104             ; =260
      38:      	umull	x11, w8, w13
      3c:      	umaddl	x8, w8, w13, x9
      40:      	ldp	q6, q7, [x8]
      44:      	ldp	q17, q16, [x8, #0x20]
      48:      	ldp	q18, q20, [x8, #0x40]
      4c:      	ldp	q29, q28, [x8, #0x60]
      50:      	ldp	q30, q31, [x8, #0x80]
      54:      	ldp	q5, q4, [x8, #0xa0]
      58:      	ldp	q2, q3, [x8, #0xc0]
      5c:      	ldp	q1, q0, [x8, #0xe0]
      60:      	add	x8, x11, #0x100
      64:      	ldr	s27, [x9, x8]
      68:      	fadd.4s	v19, v29, v1
      6c:      	fadd.4s	v21, v28, v0
      70:      	fadd.4s	v22, v20, v3
      74:      	fadd.4s	v23, v18, v2
      78:      	fadd.4s	v24, v17, v5
      7c:      	fadd.4s	v25, v16, v4
      80:      	fadd.4s	v26, v7, v31
      84:      	fadd.4s	v8, v6, v30
      88:      	fadd.4s	v9, v27, v8
      8c:      	mov.s	v8[0], v9[0]
      90:      	fadd.4s	v25, v25, v26
      94:      	fadd.4s	v24, v24, v8
      98:      	fadd.4s	v23, v23, v24
      9c:      	fadd.4s	v22, v22, v25
      a0:      	fadd.4s	v21, v21, v22
      a4:      	fadd.4s	v19, v19, v23
      a8:      	rev64.4s	v22, v19
      ac:      	rev64.4s	v23, v21
      b0:      	fadd.4s	v21, v21, v23
      b4:      	fadd.4s	v19, v19, v22
      b8:      	dup.4s	v22, v19[2]
      bc:      	dup.4s	v23, v21[2]
      c0:      	ldr	x9, [x0, #0x30]
      c4:      	fadd.4s	v21, v21, v23
      c8:      	fadd.4s	v19, v19, v22
      cc:      	fadd.4s	v21, v19, v21
      d0:      	movi	d19, #0000000000000000
      d4:      	fadd	s22, s21, s19
      d8:      	mov	w13, #0x42820000        ; =1115815936
      dc:      	fmov	s21, w13
      e0:      	fdiv	s8, s22, s21
      e4:      	dup.4s	v9, v8[0]
      e8:      	fsub.4s	v25, v6, v9
      ec:      	fsub.4s	v26, v7, v9
      f0:      	stp	q25, q26, [sp, #0x140]
      f4:      	fsub.4s	v23, v17, v9
      f8:      	fsub.4s	v24, v16, v9
      fc:      	stp	q23, q24, [sp, #0x160]
     100:      	fsub.4s	v22, v18, v9
     104:      	fsub.4s	v20, v20, v9
     108:      	stp	q22, q20, [sp, #0x180]
     10c:      	fsub.4s	v18, v29, v9
     110:      	fsub.4s	v17, v28, v9
     114:      	stp	q18, q17, [sp, #0x1a0]
     118:      	fsub.4s	v16, v30, v9
     11c:      	fsub.4s	v7, v31, v9
     120:      	stp	q16, q7, [sp, #0x1c0]
     124:      	fsub.4s	v6, v5, v9
     128:      	fsub.4s	v5, v4, v9
     12c:      	stp	q6, q5, [sp, #0x1e0]
     130:      	fsub.4s	v4, v2, v9
     134:      	fsub.4s	v3, v3, v9
     138:      	stp	q4, q3, [sp, #0x200]
     13c:      	fsub.4s	v1, v1, v9
     140:      	fsub.4s	v2, v0, v9
     144:      	stp	q1, q2, [sp, #0x220]
     148:      	fsub.4s	v15, v27, v8
     14c:      	str	q15, [sp, #0x240]
     150:      	ldp	q27, q28, [x12, #0xc0]
     154:      	stp	q27, q28, [sp, #0xe0]
     158:      	ldp	q27, q28, [x12, #0xe0]
     15c:      	stp	q27, q28, [sp, #0x100]
     160:      	ldp	q27, q28, [x12, #0x80]
     164:      	stp	q27, q28, [sp, #0xa0]
     168:      	ldp	q27, q28, [x12, #0xa0]
     16c:      	stp	q27, q28, [sp, #0xc0]
     170:      	ldp	q27, q28, [x12, #0x40]
     174:      	stp	q27, q28, [sp, #0x60]
     178:      	ldp	q27, q28, [x12, #0x60]
     17c:      	stp	q27, q28, [sp, #0x80]
     180:      	ldp	q27, q28, [x12]
     184:      	stp	q27, q28, [sp, #0x20]
     188:      	ldp	q27, q28, [x12, #0x20]
     18c:      	stp	q27, q28, [sp, #0x40]
     190:      	fmul.4s	v27, v25, v25
     194:      	fmul.4s	v28, v26, v26
     198:      	fmul.4s	v29, v24, v24
     19c:      	fmul.4s	v30, v23, v23
     1a0:      	fmul.4s	v31, v22, v22
     1a4:      	fmul.4s	v8, v20, v20
     1a8:      	fmul.4s	v9, v17, v17
     1ac:      	fmul.4s	v10, v18, v18
     1b0:      	fmul.4s	v11, v2, v2
     1b4:      	fmul.4s	v12, v1, v1
     1b8:      	fadd.4s	v10, v10, v12
     1bc:      	fadd.4s	v9, v9, v11
     1c0:      	fmul.4s	v11, v4, v4
     1c4:      	fmul.4s	v12, v3, v3
     1c8:      	fadd.4s	v8, v8, v12
     1cc:      	fadd.4s	v31, v31, v11
     1d0:      	fmul.4s	v11, v5, v5
     1d4:      	fmul.4s	v12, v6, v6
     1d8:      	fadd.4s	v30, v30, v12
     1dc:      	fadd.4s	v29, v29, v11
     1e0:      	fmul.4s	v11, v16, v16
     1e4:      	fmul.4s	v12, v7, v7
     1e8:      	fadd.4s	v28, v28, v12
     1ec:      	fadd.4s	v27, v27, v11
     1f0:      	fmul.4s	v11, v15, v15
     1f4:      	fadd.4s	v11, v11, v27
     1f8:      	mov.s	v27[0], v11[0]
     1fc:      	fadd.4s	v28, v29, v28
     200:      	fadd.4s	v27, v30, v27
     204:      	fadd.4s	v27, v31, v27
     208:      	fadd.4s	v28, v8, v28
     20c:      	fadd.4s	v28, v9, v28
     210:      	fadd.4s	v27, v10, v27
     214:      	rev64.4s	v29, v27
     218:      	rev64.4s	v30, v28
     21c:      	fadd.4s	v28, v28, v30
     220:      	fadd.4s	v27, v27, v29
     224:      	dup.4s	v29, v27[2]
     228:      	dup.4s	v30, v28[2]
     22c:      	fadd.4s	v28, v28, v30
     230:      	fadd.4s	v27, v27, v29
     234:      	fadd.4s	v27, v27, v28
     238:      	fadd	s19, s27, s19
     23c:      	fdiv	s21, s19, s21
     240:      	ldr	s19, [x12, #0x100]
     244:      	str	q19, [sp, #0x120]
     248:      	mov	w12, #0xc5ac            ; =50604
     24c:      	movk	w12, #0x3727, lsl #16
     250:      	fmov	s27, w12
     254:      	fadd	s21, s21, s27
     258:      	fsqrt	s21, s21
     25c:      	sub	x12, x10, x9
     260:      	lsr	x13, x12, #2
     264:      	subs	x12, x9, x10
     268:      	mov	w14, #0x103             ; =259
     26c:      	ccmp	x12, x14, #0x0, hs
     270:      	cset	w12, hi
     274:      	cmp	x13, #0x450
     278:      	ccmp	x10, x9, #0x0, hi
     27c:      	b.hs	0x3d8 <ltmp0+0x3d8>
     280:      	tbnz	w12, #0x0, 0x3d8 <ltmp0+0x3d8>
     284:      	ldp	q31, q11, [x10]
     288:      	ldp	q12, q13, [x10, #0x20]
     28c:      	ldp	q29, q28, [x10, #0x40]
     290:      	ldp	q9, q10, [x10, #0x60]
     294:      	ldr	q0, [x10, #0x80]
     298:      	str	q0, [sp, #0x10]
     29c:      	ldr	q0, [x10, #0x90]
     2a0:      	str	q0, [sp]
     2a4:      	dup.4s	v27, v21[0]
     2a8:      	fdiv.4s	v26, v26, v27
     2ac:      	fdiv.4s	v25, v25, v27
     2b0:      	ldp	q8, q30, [sp, #0x20]
     2b4:      	fmul.4s	v25, v25, v8
     2b8:      	fmul.4s	v26, v26, v30
     2bc:      	ldp	q30, q8, [x10, #0xa0]
     2c0:      	fadd.4s	v11, v26, v11
     2c4:      	fadd.4s	v25, v25, v31
     2c8:      	fdiv.4s	v24, v24, v27
     2cc:      	fdiv.4s	v23, v23, v27
     2d0:      	ldp	q31, q26, [sp, #0x40]
     2d4:      	fmul.4s	v0, v23, v31
     2d8:      	fmul.4s	v23, v24, v26
     2dc:      	ldp	q26, q31, [x10, #0xc0]
     2e0:      	add	x11, x9, x11
     2e4:      	fadd.4s	v14, v23, v13
     2e8:      	ldp	q24, q13, [x10, #0xe0]
     2ec:      	ldr	s23, [x10, #0x100]
     2f0:      	stp	q25, q11, [x11]
     2f4:      	fadd.4s	v0, v0, v12
     2f8:      	fdiv.4s	v22, v22, v27
     2fc:      	ldr	q25, [sp, #0x60]
     300:      	fmul.4s	v22, v22, v25
     304:      	ldr	q25, [sp, #0x70]
     308:      	fdiv.4s	v20, v20, v27
     30c:      	fmul.4s	v20, v20, v25
     310:      	fadd.4s	v20, v20, v28
     314:      	fadd.4s	v22, v22, v29
     318:      	stp	q0, q14, [x11, #0x20]
     31c:      	stp	q22, q20, [x11, #0x40]
     320:      	fdiv.4s	v0, v18, v27
     324:      	ldp	q20, q18, [sp, #0x80]
     328:      	fmul.4s	v0, v0, v20
     32c:      	fdiv.4s	v17, v17, v27
     330:      	fmul.4s	v17, v17, v18
     334:      	fadd.4s	v17, v17, v10
     338:      	fadd.4s	v0, v0, v9
     33c:      	fdiv.4s	v16, v16, v27
     340:      	ldp	q20, q18, [sp, #0xa0]
     344:      	fmul.4s	v16, v16, v20
     348:      	fdiv.4s	v7, v7, v27
     34c:      	fmul.4s	v7, v7, v18
     350:      	ldr	q18, [sp]
     354:      	fadd.4s	v7, v7, v18
     358:      	stp	q0, q17, [x11, #0x60]
     35c:      	ldr	q0, [sp, #0x10]
     360:      	fadd.4s	v0, v16, v0
     364:      	fdiv.4s	v6, v6, v27
     368:      	ldp	q17, q16, [sp, #0xc0]
     36c:      	fmul.4s	v6, v6, v17
     370:      	fdiv.4s	v5, v5, v27
     374:      	fmul.4s	v5, v5, v16
     378:      	fadd.4s	v5, v5, v8
     37c:      	stp	q0, q7, [x11, #0x80]
     380:      	fadd.4s	v0, v6, v30
     384:      	fdiv.4s	v4, v4, v27
     388:      	ldp	q7, q6, [sp, #0xe0]
     38c:      	fmul.4s	v4, v4, v7
     390:      	fdiv.4s	v3, v3, v27
     394:      	fmul.4s	v3, v3, v6
     398:      	fadd.4s	v3, v3, v31
     39c:      	stp	q0, q5, [x11, #0xa0]
     3a0:      	fadd.4s	v0, v4, v26
     3a4:      	fdiv.4s	v2, v2, v27
     3a8:      	fdiv.4s	v1, v1, v27
     3ac:      	ldp	q5, q4, [sp, #0x100]
     3b0:      	fmul.4s	v1, v1, v5
     3b4:      	fmul.4s	v2, v2, v4
     3b8:      	fadd.4s	v2, v2, v13
     3bc:      	stp	q0, q3, [x11, #0xc0]
     3c0:      	fadd.4s	v1, v1, v24
     3c4:      	fdiv.4s	v0, v15, v21
     3c8:      	fmul.4s	v0, v0, v19
     3cc:      	fadd.4s	v0, v0, v23
     3d0:      	stp	q1, q2, [x11, #0xe0]
     3d4:      	b	0x444 <ltmp0+0x444>
     3d8:      	mov	x12, #0x0               ; =0
     3dc:      	dup.4s	v1, v21[0]
     3e0:      	add	x11, x9, x11
     3e4:      	add	x13, sp, #0x140
     3e8:      	add	x14, sp, #0x20
     3ec:      	lsl	x15, x12, #5
     3f0:      	add	x16, x13, x15
     3f4:      	ldp	q2, q0, [x16]
     3f8:      	fdiv.4s	v2, v2, v1
     3fc:      	fdiv.4s	v0, v0, v1
     400:      	add	x16, x14, x15
     404:      	ldp	q3, q4, [x16]
     408:      	fmul.4s	v0, v0, v4
     40c:      	fmul.4s	v2, v2, v3
     410:      	add	x16, x10, x15
     414:      	ldp	q4, q3, [x16]
     418:      	fadd.4s	v2, v2, v4
     41c:      	fadd.4s	v0, v0, v3
     420:      	add	x15, x11, x15
     424:      	stp	q2, q0, [x15]
     428:      	add	x12, x12, #0x1
     42c:      	cmp	x12, #0x8
     430:      	b.lt	0x3ec <ltmp0+0x3ec>
     434:      	fdiv.4s	v0, v15, v21
     438:      	fmul.4s	v0, v0, v19
     43c:      	ldr	s1, [x10, #0x100]
     440:      	fadd.4s	v0, v0, v1
     444:      	str	s0, [x9, x8]
     448:      	add	sp, sp, #0x260
     44c:      	ldp	x28, x27, [sp, #0x40]
     450:      	ldp	d9, d8, [sp, #0x30]
     454:      	ldp	d11, d10, [sp, #0x20]
     458:      	ldp	d13, d12, [sp, #0x10]
     45c:      	ldp	d15, d14, [sp], #0x50
     460:      	ret

0000000000000464 <_llm_rows.packet_batch.blocks>:
     464:      	stp	d15, d14, [sp, #-0xa0]!
     468:      	stp	d13, d12, [sp, #0x10]
     46c:      	stp	d11, d10, [sp, #0x20]
     470:      	stp	d9, d8, [sp, #0x30]
     474:      	stp	x28, x27, [sp, #0x40]
     478:      	stp	x26, x25, [sp, #0x50]
     47c:      	stp	x24, x23, [sp, #0x60]
     480:      	stp	x22, x21, [sp, #0x70]
     484:      	stp	x20, x19, [sp, #0x80]
     488:      	stp	x29, x30, [sp, #0x90]
     48c:      	sub	sp, sp, #0xa80
     490:      	str	x0, [sp, #0x1a8]
     494:      	cbz	w3, 0x1c70 <_llm_rows.packet_batch.blocks+0x180c>
     498:      	mov	x26, x3
     49c:      	mov	x20, x2
     4a0:      	mov	w22, #0x0               ; =0
     4a4:      	ldp	w9, w8, [x2, #0x2c]
     4a8:      	str	w9, [sp, #0x1a4]
     4ac:      	str	w8, [sp, #0x1a0]
     4b0:      	add	x25, sp, #0x960
     4b4:      	ldp	w24, w12, [x2]
     4b8:      	ldp	w28, w8, [x2, #0x8]
     4bc:      	str	x8, [sp, #0x198]
     4c0:      	adrp	x8, 0x0 <ltmp0>
     4c4:      	ldr	q0, [x8]
     4c8:      	str	q0, [sp, #0x10]
     4cc:      	adrp	x8, 0x0 <ltmp0>
     4d0:      	ldr	q0, [x8]
     4d4:      	str	q0, [sp, #0x30]
     4d8:      	adrp	x8, 0x0 <ltmp0>
     4dc:      	ldr	q0, [x8]
     4e0:      	str	q0, [sp, #0x20]
     4e4:      	movi.2s	v9, #0x41
     4e8:      	mov	w27, #0x4               ; =4
     4ec:      	add	x19, sp, #0x840
     4f0:      	str	w3, [sp, #0x17c]
     4f4:      	b	0x540 <_llm_rows.packet_batch.blocks+0xdc>
     4f8:      	mov	w8, #0x18               ; =24
     4fc:      	str	w8, [x20, #0x24]
     500:      	ldr	w26, [sp, #0x17c]
     504:      	add	w8, w24, #0x1
     508:      	ldr	w9, [sp, #0x1a4]
     50c:      	cmp	w8, w9
     510:      	cset	w8, eq
     514:      	csinc	w24, wzr, w24, eq
     518:      	cinc	w9, w12, eq
     51c:      	ldr	w10, [sp, #0x1a0]
     520:      	cmp	w9, w10
     524:      	cset	w10, eq
     528:      	ands	w8, w8, w10
     52c:      	csel	w12, wzr, w9, ne
     530:      	add	w28, w28, w8
     534:      	add	w22, w22, #0x1
     538:      	cmp	w22, w26
     53c:      	b.eq	0x1c70 <_llm_rows.packet_batch.blocks+0x180c>
     540:      	ubfiz	x8, x24, #5, #32
     544:      	ldr	x13, [sp, #0x198]
     548:      	cmp	x8, x13
     54c:      	csel	x9, x8, xzr, ls
     550:      	subs	x10, x13, x9
     554:      	cmp	x10, #0x20
     558:      	mov	w11, #0x20              ; =32
     55c:      	csel	x10, x10, x11, lo
     560:      	cmp	x13, x9
     564:      	stp	w24, w12, [x20]
     568:      	str	w28, [x20, #0x8]
     56c:      	str	wzr, [x20, #0x24]
     570:      	ccmp	x8, x13, #0x2, hi
     574:      	csel	x23, x10, xzr, ls
     578:      	cmp	x23, #0x20
     57c:      	b.lo	0x5d8 <_llm_rows.packet_batch.blocks+0x174>
     580:      	ldr	x23, [sp, #0x1a8]
     584:      	mov	x0, x23
     588:      	mov	x1, x20
     58c:      	mov	x21, x12
     590:      	bl	0x590 <_llm_rows.packet_batch.blocks+0x12c>
     594:      	mov	w8, #0x8                ; =8
     598:      	str	w8, [x20, #0x24]
     59c:      	mov	x0, x23
     5a0:      	mov	x1, x20
     5a4:      	bl	0x5a4 <_llm_rows.packet_batch.blocks+0x140>
     5a8:      	mov	w8, #0x10               ; =16
     5ac:      	str	w8, [x20, #0x24]
     5b0:      	mov	x0, x23
     5b4:      	mov	x1, x20
     5b8:      	bl	0x5b8 <_llm_rows.packet_batch.blocks+0x154>
     5bc:      	mov	w8, #0x18               ; =24
     5c0:      	str	w8, [x20, #0x24]
     5c4:      	mov	x0, x23
     5c8:      	mov	x1, x20
     5cc:      	bl	0x5cc <_llm_rows.packet_batch.blocks+0x168>
     5d0:      	mov	x12, x21
     5d4:      	b	0x504 <_llm_rows.packet_batch.blocks+0xa0>
     5d8:      	lsr	x26, x23, #3
     5dc:      	cmp	x23, #0x8
     5e0:      	b.lo	0x63c <_llm_rows.packet_batch.blocks+0x1d8>
     5e4:      	str	wzr, [x20, #0x24]
     5e8:      	ldr	x0, [sp, #0x1a8]
     5ec:      	mov	x1, x20
     5f0:      	mov	x21, x12
     5f4:      	bl	0x5f4 <_llm_rows.packet_batch.blocks+0x190>
     5f8:      	mov	x12, x21
     5fc:      	cmp	x26, #0x1
     600:      	b.eq	0x63c <_llm_rows.packet_batch.blocks+0x1d8>
     604:      	mov	w8, #0x8                ; =8
     608:      	str	w8, [x20, #0x24]
     60c:      	ldr	x0, [sp, #0x1a8]
     610:      	mov	x1, x20
     614:      	bl	0x614 <_llm_rows.packet_batch.blocks+0x1b0>
     618:      	mov	x12, x21
     61c:      	cmp	x26, #0x2
     620:      	b.eq	0x63c <_llm_rows.packet_batch.blocks+0x1d8>
     624:      	mov	w8, #0x10               ; =16
     628:      	str	w8, [x20, #0x24]
     62c:      	ldr	x0, [sp, #0x1a8]
     630:      	mov	x1, x20
     634:      	bl	0x634 <_llm_rows.packet_batch.blocks+0x1d0>
     638:      	mov	x12, x21
     63c:      	and	w8, w23, #0x7
     640:      	cbz	w8, 0x4f8 <_llm_rows.packet_batch.blocks+0x94>
     644:      	dup.4s	v1, w8
     648:      	ldp	q0, q2, [sp, #0x20]
     64c:      	cmhi.4s	v0, v1, v0
     650:      	cmhi.4s	v1, v1, v2
     654:      	uzp1.8h	v3, v1, v0
     658:      	umaxv.8h	h2, v3
     65c:      	fmov	w8, s2
     660:      	tbz	w8, #0x0, 0x4f8 <_llm_rows.packet_batch.blocks+0x94>
     664:      	str	w12, [sp, #0x178]
     668:      	mov	x12, #0x0               ; =0
     66c:      	ldr	x8, [sp, #0x1a8]
     670:      	ldr	x9, [x8]
     674:      	ldr	x14, [x8, #0x10]
     678:      	ldr	x11, [x8, #0x20]
     67c:      	ldr	x8, [x8, #0x30]
     680:      	ldr	q2, [sp, #0x10]
     684:      	str	q3, [sp, #0xd0]
     688:      	and.16b	v2, v3, v2
     68c:      	addv.8h	h16, v2
     690:      	fmov	w10, s16
     694:      	and	w13, w10, #0xff
     698:      	xtn.4h	v3, v1
     69c:      	uzp1.8b	v4, v3, v0
     6a0:      	ubfiz	w10, w24, #2, #27
     6a4:      	orr	w10, w10, w26
     6a8:      	dup.4s	v5, w10
     6ac:      	and.16b	v6, v1, v5
     6b0:      	and.16b	v5, v0, v5
     6b4:      	ushll2.2d	v17, v5, #0x0
     6b8:      	ushll2.2d	v18, v6, #0x0
     6bc:      	ushll.2d	v19, v5, #0x0
     6c0:      	umov.b	w15, v4[0]
     6c4:      	ushll.2d	v4, v6, #0x0
     6c8:      	mov	w16, #0x104             ; =260
     6cc:      	umull	x10, w10, w16
     6d0:      	tst	w15, #0x1
     6d4:      	csel	x3, x10, xzr, ne
     6d8:      	add	x16, x9, x3
     6dc:      	fmov	w17, s16
     6e0:      	b	0x704 <_llm_rows.packet_batch.blocks+0x2a0>
     6e4:      	add	x0, x25, x12
     6e8:      	ldp	q7, q20, [x0]
     6ec:      	bif.16b	v6, v20, v0
     6f0:      	bif.16b	v5, v7, v1
     6f4:      	stp	q5, q6, [x0]
     6f8:      	add	x12, x12, #0x20
     6fc:      	cmp	x12, #0x100
     700:      	b.eq	0x798 <_llm_rows.packet_batch.blocks+0x334>
     704:      	add	x0, x16, x12
     708:      	movi.2d	v5, #0000000000000000
     70c:      	movi.2d	v6, #0000000000000000
     710:      	tbnz	w17, #0x0, 0x738 <_llm_rows.packet_batch.blocks+0x2d4>
     714:      	and	w1, w17, #0xff
     718:      	tbnz	w1, #0x1, 0x744 <_llm_rows.packet_batch.blocks+0x2e0>
     71c:      	tbnz	w1, #0x2, 0x750 <_llm_rows.packet_batch.blocks+0x2ec>
     720:      	tbnz	w1, #0x3, 0x75c <_llm_rows.packet_batch.blocks+0x2f8>
     724:      	tbnz	w1, #0x4, 0x768 <_llm_rows.packet_batch.blocks+0x304>
     728:      	tbnz	w1, #0x5, 0x774 <_llm_rows.packet_batch.blocks+0x310>
     72c:      	tbnz	w1, #0x6, 0x780 <_llm_rows.packet_batch.blocks+0x31c>
     730:      	tbz	w1, #0x7, 0x6e4 <_llm_rows.packet_batch.blocks+0x280>
     734:      	b	0x78c <_llm_rows.packet_batch.blocks+0x328>
     738:      	ldr	s5, [x0]
     73c:      	and	w1, w17, #0xff
     740:      	tbz	w1, #0x1, 0x71c <_llm_rows.packet_batch.blocks+0x2b8>
     744:      	add	x2, x0, #0x4
     748:      	ld1.s	{ v5 }[1], [x2]
     74c:      	tbz	w1, #0x2, 0x720 <_llm_rows.packet_batch.blocks+0x2bc>
     750:      	add	x2, x0, #0x8
     754:      	ld1.s	{ v5 }[2], [x2]
     758:      	tbz	w1, #0x3, 0x724 <_llm_rows.packet_batch.blocks+0x2c0>
     75c:      	add	x2, x0, #0xc
     760:      	ld1.s	{ v5 }[3], [x2]
     764:      	tbz	w1, #0x4, 0x728 <_llm_rows.packet_batch.blocks+0x2c4>
     768:      	add	x2, x0, #0x10
     76c:      	ld1.s	{ v6 }[0], [x2]
     770:      	tbz	w1, #0x5, 0x72c <_llm_rows.packet_batch.blocks+0x2c8>
     774:      	add	x2, x0, #0x14
     778:      	ld1.s	{ v6 }[1], [x2]
     77c:      	tbz	w1, #0x6, 0x730 <_llm_rows.packet_batch.blocks+0x2cc>
     780:      	add	x2, x0, #0x18
     784:      	ld1.s	{ v6 }[2], [x2]
     788:      	tbz	w1, #0x7, 0x6e4 <_llm_rows.packet_batch.blocks+0x280>
     78c:      	add	x0, x0, #0x1c
     790:      	ld1.s	{ v6 }[3], [x0]
     794:      	b	0x6e4 <_llm_rows.packet_batch.blocks+0x280>
     798:      	uzp1.8b	v20, v3, v0
     79c:      	sshll.2d	v5, v1, #0x0
     7a0:      	movi.2d	v7, #0000000000000000
     7a4:      	mov.b	v7[0], v20[0]
     7a8:      	adrp	x10, 0x0 <ltmp0>
     7ac:      	ldr	d2, [x10]
     7b0:      	str	d2, [sp, #0xe8]
     7b4:      	and.8b	v3, v7, v2
     7b8:      	addv.8b	b3, v3
     7bc:      	fmov	w12, s3
     7c0:      	umaxv.8b	b3, v7
     7c4:      	fmov	w16, s3
     7c8:      	rbit	w17, w12
     7cc:      	clz	w17, w17
     7d0:      	tst	w16, #0x1
     7d4:      	csel	w0, w17, wzr, ne
     7d8:      	adrp	x10, 0x0 <ltmp0>
     7dc:      	ldr	q3, [x10]
     7e0:      	mov	w10, #0x40              ; =64
     7e4:      	dup.2d	v6, x10
     7e8:      	mov.16b	v2, v5
     7ec:      	bsl.16b	v2, v3, v6
     7f0:      	xtn.2s	v4, v4
     7f4:      	umlal.2d	v2, v4, v9
     7f8:      	movi.2d	v4, #0000000000000000
     7fc:      	mov.b	v4[0], v20[0]
     800:      	ushll.2d	v4, v4, #0x0
     804:      	shl.2d	v4, v4, #0x3f
     808:      	cmlt.2d	v4, v4, #0
     80c:      	str	q2, [sp, #0x140]
     810:      	and.16b	v4, v4, v2
     814:      	movi.2d	v2, #0000000000000000
     818:      	str	q2, [sp, #0x5e0]
     81c:      	str	q2, [sp, #0x5d0]
     820:      	str	q2, [sp, #0x5c0]
     824:      	str	q4, [sp, #0x5b0]
     828:      	and	x17, x0, #0x7
     82c:      	add	x10, sp, #0x5b0
     830:      	ldr	x17, [x10, x17, lsl #3]
     834:      	sub	x17, x17, x0
     838:      	add	x9, x9, x17, lsl #2
     83c:      	movi.2d	v22, #0000000000000000
     840:      	movi.2d	v24, #0000000000000000
     844:      	tbnz	w16, #0x0, 0x18b4 <_llm_rows.packet_batch.blocks+0x1450>
     848:      	tbnz	w12, #0x1, 0x18bc <_llm_rows.packet_batch.blocks+0x1458>
     84c:      	tbnz	w12, #0x2, 0x18c8 <_llm_rows.packet_batch.blocks+0x1464>
     850:      	tbnz	w12, #0x3, 0x18d4 <_llm_rows.packet_batch.blocks+0x1470>
     854:      	tbnz	w12, #0x4, 0x18e0 <_llm_rows.packet_batch.blocks+0x147c>
     858:      	tbnz	w12, #0x5, 0x18ec <_llm_rows.packet_batch.blocks+0x1488>
     85c:      	tbnz	w12, #0x6, 0x18f8 <_llm_rows.packet_batch.blocks+0x1494>
     860:      	str	q16, [sp, #0x160]
     864:      	tbz	w12, #0x7, 0x870 <_llm_rows.packet_batch.blocks+0x40c>
     868:      	add	x9, x9, #0x1c
     86c:      	ld1.s	{ v24 }[3], [x9]
     870:      	str	x3, [sp, #0x138]
     874:      	str	x8, [sp, #0x170]
     878:      	sshll.2d	v4, v0, #0x0
     87c:      	sshll2.2d	v20, v1, #0x0
     880:      	sshll2.2d	v21, v0, #0x0
     884:      	adrp	x9, 0x0 <ltmp0>
     888:      	ldr	q23, [x9]
     88c:      	and.16b	v23, v21, v23
     890:      	adrp	x9, 0x0 <ltmp0>
     894:      	ldr	q26, [x9]
     898:      	and.16b	v26, v20, v26
     89c:      	adrp	x9, 0x0 <ltmp0>
     8a0:      	ldr	q27, [x9]
     8a4:      	and.16b	v27, v4, v27
     8a8:      	adrp	x9, 0x0 <ltmp0>
     8ac:      	ldr	q28, [x9]
     8b0:      	and.16b	v5, v5, v28
     8b4:      	adrp	x9, 0x0 <ltmp0>
     8b8:      	ldr	q28, [x9]
     8bc:      	mov.16b	v2, v4
     8c0:      	bsl.16b	v2, v28, v6
     8c4:      	adrp	x9, 0x0 <ltmp0>
     8c8:      	ldr	q4, [x9]
     8cc:      	mov.16b	v3, v20
     8d0:      	bsl.16b	v3, v4, v6
     8d4:      	adrp	x9, 0x0 <ltmp0>
     8d8:      	ldr	q4, [x9]
     8dc:      	bit.16b	v6, v4, v21
     8e0:      	xtn.2s	v4, v19
     8e4:      	xtn.2s	v18, v18
     8e8:      	xtn.2s	v17, v17
     8ec:      	umlal.2d	v6, v17, v9
     8f0:      	umlal.2d	v3, v18, v9
     8f4:      	stp	q6, q3, [sp, #0x100]
     8f8:      	umlal.2d	v2, v4, v9
     8fc:      	str	q2, [sp, #0x120]
     900:      	sshll.2d	v4, v1, #0x0
     904:      	sshll.2d	v17, v0, #0x0
     908:      	str	q5, [sp, #0x570]
     90c:      	str	q26, [sp, #0x580]
     910:      	str	q27, [sp, #0x590]
     914:      	str	q23, [sp, #0x5a0]
     918:      	and	x9, x0, #0x7
     91c:      	add	x10, sp, #0x570
     920:      	ldr	x9, [x10, x9, lsl #3]
     924:      	orr	x9, x9, #0x100
     928:      	str	x0, [sp, #0x158]
     92c:      	sub	x9, x9, x0, lsl #2
     930:      	tst	w12, #0xff
     934:      	csel	x21, xzr, x9, eq
     938:      	add	x9, x25, x21
     93c:      	ldp	q5, q18, [x9]
     940:      	zip2.8b	v19, v7, v0
     944:      	ushll.4s	v19, v19, #0x0
     948:      	shl.4s	v19, v19, #0x1f
     94c:      	cmlt.4s	v19, v19, #0
     950:      	str	q24, [sp, #0xb0]
     954:      	bit.16b	v18, v24, v19
     958:      	str	q7, [sp, #0x180]
     95c:      	zip1.8b	v19, v7, v0
     960:      	ushll.4s	v19, v19, #0x0
     964:      	shl.4s	v19, v19, #0x1f
     968:      	cmlt.4s	v19, v19, #0
     96c:      	str	q22, [sp, #0xf0]
     970:      	bit.16b	v5, v22, v19
     974:      	stp	q5, q18, [x9]
     978:      	dup.2d	v5, x27
     97c:      	and.16b	v26, v21, v5
     980:      	and.16b	v27, v20, v5
     984:      	and.16b	v28, v17, v5
     988:      	and.16b	v29, v4, v5
     98c:      	tst	w15, #0x1
     990:      	csel	x5, x27, xzr, ne
     994:      	ldr	q4, [sp, #0x9c0]
     998:      	ldr	q5, [sp, #0x9d0]
     99c:      	and.16b	v5, v0, v5
     9a0:      	and.16b	v4, v1, v4
     9a4:      	ldr	q18, [sp, #0x9a0]
     9a8:      	ldr	q17, [sp, #0x9b0]
     9ac:      	and.16b	v17, v0, v17
     9b0:      	and.16b	v18, v1, v18
     9b4:      	ldr	q19, [sp, #0x980]
     9b8:      	ldr	q23, [sp, #0x990]
     9bc:      	and.16b	v30, v0, v23
     9c0:      	and.16b	v19, v1, v19
     9c4:      	ldr	q23, [sp, #0x960]
     9c8:      	ldr	q31, [sp, #0x970]
     9cc:      	and.16b	v31, v0, v31
     9d0:      	mov	x9, x5
     9d4:      	and.16b	v8, v1, v23
     9d8:      	mov.16b	v14, v29
     9dc:      	mov.16b	v23, v27
     9e0:      	mov.16b	v12, v28
     9e4:      	mov.16b	v13, v26
     9e8:      	sshll.2d	v15, v1, #0x0
     9ec:      	sshll.2d	v6, v0, #0x0
     9f0:      	add	x9, x25, x9, lsl #5
     9f4:      	ldp	q11, q10, [x9]
     9f8:      	fadd.4s	v11, v8, v11
     9fc:      	fadd.4s	v10, v31, v10
     a00:      	ldp	q22, q3, [x9, #0x20]
     a04:      	fadd.4s	v22, v19, v22
     a08:      	fadd.4s	v3, v30, v3
     a0c:      	ldp	q16, q9, [x9, #0x40]
     a10:      	fadd.4s	v16, v18, v16
     a14:      	fadd.4s	v9, v17, v9
     a18:      	ldp	q24, q7, [x9, #0x60]
     a1c:      	fadd.4s	v24, v4, v24
     a20:      	fadd.4s	v7, v5, v7
     a24:      	dup.2d	v25, x27
     a28:      	and.16b	v2, v21, v25
     a2c:      	add.2d	v13, v13, v2
     a30:      	and.16b	v2, v20, v25
     a34:      	add.2d	v23, v23, v2
     a38:      	and.16b	v2, v6, v25
     a3c:      	add.2d	v12, v12, v2
     a40:      	and.16b	v2, v15, v25
     a44:      	add.2d	v2, v14, v2
     a48:      	bit.16b	v31, v10, v0
     a4c:      	bit.16b	v8, v11, v1
     a50:      	bit.16b	v30, v3, v0
     a54:      	bit.16b	v19, v22, v1
     a58:      	bit.16b	v17, v9, v0
     a5c:      	bit.16b	v18, v16, v1
     a60:      	bit.16b	v5, v7, v0
     a64:      	bit.16b	v4, v24, v1
     a68:      	fmov	x9, d14
     a6c:      	add	x12, x9, #0x4
     a70:      	tst	w15, #0x1
     a74:      	csel	x9, x12, x9, ne
     a78:      	mov.16b	v14, v2
     a7c:      	cmp	x9, #0x8
     a80:      	b.lt	0x9e8 <_llm_rows.packet_batch.blocks+0x584>
     a84:      	mov	x6, #0x0                ; =0
     a88:      	ldr	q2, [sp, #0xd0]
     a8c:      	xtn.8b	v24, v2
     a90:      	ldr	q25, [sp, #0xf0]
     a94:      	fadd.4s	v2, v25, v8
     a98:      	ldr	q9, [sp, #0xb0]
     a9c:      	fadd.4s	v3, v9, v31
     aa0:      	ldr	q23, [sp, #0x180]
     aa4:      	zip2.8b	v6, v23, v0
     aa8:      	ushll.4s	v6, v6, #0x0
     aac:      	shl.4s	v6, v6, #0x1f
     ab0:      	cmlt.4s	v6, v6, #0
     ab4:      	and.16b	v3, v6, v3
     ab8:      	zip1.8b	v6, v23, v0
     abc:      	ushll.4s	v6, v6, #0x0
     ac0:      	shl.4s	v6, v6, #0x1f
     ac4:      	cmlt.4s	v6, v6, #0
     ac8:      	and.16b	v2, v6, v2
     acc:      	movi.2d	v6, #0000000000000000
     ad0:      	mov.b	v6[2], v24[1]
     ad4:      	mov.b	v6[4], v24[2]
     ad8:      	mov.b	v6[6], v24[3]
     adc:      	ushll.4s	v6, v6, #0x0
     ae0:      	shl.4s	v6, v6, #0x1f
     ae4:      	cmlt.4s	v6, v6, #0
     ae8:      	bit.16b	v2, v11, v6
     aec:      	zip2.8b	v6, v24, v0
     af0:      	ushll.4s	v6, v6, #0x0
     af4:      	shl.4s	v6, v6, #0x1f
     af8:      	cmlt.4s	v6, v6, #0
     afc:      	bit.16b	v3, v10, v6
     b00:      	fadd.4s	v3, v30, v3
     b04:      	fadd.4s	v2, v19, v2
     b08:      	fadd.4s	v2, v18, v2
     b0c:      	fadd.4s	v3, v17, v3
     b10:      	fadd.4s	v5, v5, v3
     b14:      	umov.b	w8, v24[1]
     b18:      	fadd.4s	v4, v4, v2
     b1c:      	and	w23, w15, w8
     b20:      	mov	s2, v4[1]
     b24:      	tst	w23, #0x1
     b28:      	movi	d22, #0000000000000000
     b2c:      	fcsel	s16, s2, s22, ne
     b30:      	mvn	w9, w8
     b34:      	add	x12, sp, #0x550
     b38:      	bfi	x12, x9, #2, #1
     b3c:      	add	x16, sp, #0x448
     b40:      	bfxil	x16, x9, #0, #1
     b44:      	str	d24, [sp, #0x448]
     b48:      	ldrb	w9, [x16]
     b4c:      	str	w8, [sp, #0xc8]
     b50:      	and	w9, w8, w9
     b54:      	str	q5, [sp, #0x560]
     b58:      	str	q4, [sp, #0x550]
     b5c:      	ldr	s2, [x12]
     b60:      	tst	w9, #0x1
     b64:      	fcsel	s17, s2, s22, ne
     b68:      	umov.b	w12, v24[2]
     b6c:      	ands	w9, w12, #0x1
     b70:      	mov	w10, #0x3               ; =3
     b74:      	csinc	w16, w10, wzr, ne
     b78:      	add	x10, sp, #0x448
     b7c:      	orr	x17, x10, x16
     b80:      	ldrb	w17, [x17]
     b84:      	add	x0, sp, #0x530
     b88:      	orr	x16, x0, x16, lsl #2
     b8c:      	str	q5, [sp, #0x540]
     b90:      	str	q4, [sp, #0x530]
     b94:      	ldr	s2, [x16]
     b98:      	tst	w9, w17
     b9c:      	fcsel	s18, s2, s22, ne
     ba0:      	umov.b	w26, v24[3]
     ba4:      	ands	w9, w26, #0x1
     ba8:      	mov	w2, #0x1                ; =1
     bac:      	cinc	w16, w2, ne
     bb0:      	add	x17, sp, #0x448
     bb4:      	bfxil	x17, x16, #0, #3
     bb8:      	ldrb	w17, [x17]
     bbc:      	add	x0, sp, #0x510
     bc0:      	orr	x16, x0, x16, lsl #2
     bc4:      	str	q5, [sp, #0x520]
     bc8:      	str	q4, [sp, #0x510]
     bcc:      	ldr	s2, [x16]
     bd0:      	tst	w9, w17
     bd4:      	fcsel	s2, s2, s22, ne
     bd8:      	umov.b	w30, v24[4]
     bdc:      	ands	w16, w30, #0x1
     be0:      	mov	w9, #0x5                ; =5
     be4:      	csinc	w9, w9, wzr, ne
     be8:      	orr	x17, x10, x9
     bec:      	ldrb	w0, [x17]
     bf0:      	str	q5, [sp, #0x500]
     bf4:      	str	q4, [sp, #0x4f0]
     bf8:      	add	x17, sp, #0x4f0
     bfc:      	ldr	s3, [x17, w9, uxtw #2]
     c00:      	mov	w9, #0x2                ; =2
     c04:      	mov	w7, #0x6                ; =6
     c08:      	csel	w17, w7, w9, ne
     c0c:      	tst	w16, w0
     c10:      	umov.b	w9, v24[5]
     c14:      	fcsel	s3, s3, s22, ne
     c18:      	ands	w0, w9, #0x1
     c1c:      	csinc	w1, w27, wzr, ne
     c20:      	orr	x3, x10, x1
     c24:      	ldrb	w3, [x3]
     c28:      	str	q5, [sp, #0x4e0]
     c2c:      	str	q4, [sp, #0x4d0]
     c30:      	add	x8, sp, #0x4d0
     c34:      	ldr	s6, [x8, w1, uxtw #2]
     c38:      	tst	w0, w3
     c3c:      	umov.b	w3, v24[6]
     c40:      	fcsel	s6, s6, s22, ne
     c44:      	ands	w0, w3, #0x1
     c48:      	mov	w8, #0x7                ; =7
     c4c:      	csinc	w1, w8, wzr, ne
     c50:      	orr	x4, x10, x1
     c54:      	ldrb	w4, [x4]
     c58:      	str	q5, [sp, #0x4c0]
     c5c:      	str	q4, [sp, #0x4b0]
     c60:      	add	x8, sp, #0x4b0
     c64:      	ldr	s7, [x8, w1, uxtw #2]
     c68:      	tst	w0, w4
     c6c:      	umov.b	w4, v24[7]
     c70:      	fcsel	s7, s7, s22, ne
     c74:      	ands	w0, w4, #0x1
     c78:      	csinc	w1, w7, wzr, ne
     c7c:      	orr	x7, x10, x1
     c80:      	ldrb	w7, [x7]
     c84:      	str	q5, [sp, #0x4a0]
     c88:      	str	q4, [sp, #0x490]
     c8c:      	add	x8, sp, #0x490
     c90:      	ldr	s19, [x8, w1, uxtw #2]
     c94:      	tst	w0, w7
     c98:      	fcsel	s19, s19, s22, ne
     c9c:      	mov.s	v16[1], v17[0]
     ca0:      	mov.s	v16[2], v18[0]
     ca4:      	mov.s	v16[3], v2[0]
     ca8:      	mov.s	v3[1], v6[0]
     cac:      	mov.s	v3[2], v7[0]
     cb0:      	mov.s	v3[3], v19[0]
     cb4:      	fadd.4s	v2, v5, v3
     cb8:      	fadd.4s	v3, v4, v16
     cbc:      	and	w1, w15, w12
     cc0:      	mov	s4, v3[2]
     cc4:      	tst	w1, #0x1
     cc8:      	fcsel	s4, s4, s22, ne
     ccc:      	orr	x0, x10, x17
     cd0:      	ldrb	w0, [x0]
     cd4:      	str	q2, [sp, #0x480]
     cd8:      	str	q3, [sp, #0x470]
     cdc:      	add	x8, sp, #0x470
     ce0:      	ldr	s5, [x8, w17, uxtw #2]
     ce4:      	tst	w16, w0
     ce8:      	fcsel	s5, s5, s22, ne
     cec:      	fadd.4s	v2, v2, v5
     cf0:      	str	w30, [sp, #0x7c]
     cf4:      	and	w8, w15, w30
     cf8:      	tst	w8, #0x1
     cfc:      	fcsel	s2, s2, s22, ne
     d00:      	tst	w23, #0x1
     d04:      	fadd.4s	v3, v3, v4
     d08:      	fadd	s2, s3, s2
     d0c:      	fcsel	s3, s2, s22, ne
     d10:      	stp	w8, w1, [sp, #0xcc]
     d14:      	tst	w1, #0x1
     d18:      	fcsel	s4, s2, s22, ne
     d1c:      	tst	w8, #0x1
     d20:      	str	q24, [sp, #0x80]
     d24:      	mov.b	v24[0], wzr
     d28:      	str	q24, [sp, #0x60]
     d2c:      	fcsel	s5, s2, s22, ne
     d30:      	tst	w15, #0x1
     d34:      	and	w8, w26, w15
     d38:      	fcsel	s6, s2, s22, ne
     d3c:      	str	w8, [sp, #0x9c]
     d40:      	tst	w8, #0x1
     d44:      	fcsel	s7, s2, s22, ne
     d48:      	and	w8, w9, w15
     d4c:      	str	w8, [sp, #0x98]
     d50:      	tst	w8, #0x1
     d54:      	fcsel	s16, s2, s22, ne
     d58:      	and	w8, w3, w15
     d5c:      	str	w8, [sp, #0x94]
     d60:      	tst	w8, #0x1
     d64:      	fcsel	s17, s2, s22, ne
     d68:      	and	w8, w4, w15
     d6c:      	str	w8, [sp, #0xac]
     d70:      	tst	w8, #0x1
     d74:      	mov.s	v6[1], v3[0]
     d78:      	mov.s	v6[2], v4[0]
     d7c:      	mov.s	v6[3], v7[0]
     d80:      	mov.s	v5[1], v16[0]
     d84:      	mov.s	v5[2], v17[0]
     d88:      	fcsel	s2, s2, s22, ne
     d8c:      	mov.s	v5[3], v2[0]
     d90:      	rbit	w13, w13
     d94:      	clz	w8, w13
     d98:      	str	q5, [sp, #0x460]
     d9c:      	str	q6, [sp, #0x450]
     da0:      	str	x8, [sp, #0xa0]
     da4:      	and	x13, x8, #0x7
     da8:      	add	x8, sp, #0x450
     dac:      	ldr	s2, [x8, x13, lsl #2]
     db0:      	fadd	s2, s2, s22
     db4:      	mov	w8, #0x42820000         ; =1115815936
     db8:      	fmov	s3, w8
     dbc:      	fdiv	s2, s2, s3
     dc0:      	dup.4s	v4, v2[0]
     dc4:      	ushll2.2d	v2, v0, #0x0
     dc8:      	dup.2d	v3, x2
     dcc:      	and.16b	v16, v2, v3
     dd0:      	ushll2.2d	v2, v1, #0x0
     dd4:      	and.16b	v17, v2, v3
     dd8:      	ushll.2d	v2, v0, #0x0
     ddc:      	and.16b	v18, v2, v3
     de0:      	ushll.2d	v2, v1, #0x0
     de4:      	and.16b	v19, v2, v3
     de8:      	movi.2d	v5, #0000000000000000
     dec:      	and	x13, x15, #0x1
     df0:      	movi.2d	v31, #0000000000000000
     df4:      	movi.2d	v8, #0000000000000000
     df8:      	movi.2d	v10, #0000000000000000
     dfc:      	lsl	x16, x6, #5
     e00:      	add	x17, x25, x16
     e04:      	ldp	q3, q2, [x17]
     e08:      	fsub.4s	v3, v3, v4
     e0c:      	fsub.4s	v2, v2, v4
     e10:      	add	x16, x19, x16
     e14:      	ldp	q6, q7, [x16]
     e18:      	bif.16b	v2, v7, v0
     e1c:      	bif.16b	v3, v6, v1
     e20:      	stp	q3, q2, [x16]
     e24:      	add.2d	v2, v5, v19
     e28:      	add.2d	v31, v31, v17
     e2c:      	add.2d	v8, v8, v18
     e30:      	add.2d	v10, v10, v16
     e34:      	fmov	x16, d5
     e38:      	add	x6, x16, x13
     e3c:      	mov.16b	v5, v2
     e40:      	cmp	x6, #0x8
     e44:      	b.lt	0xdfc <_llm_rows.packet_batch.blocks+0x998>
     e48:      	fsub.4s	v5, v25, v4
     e4c:      	fsub.4s	v6, v9, v4
     e50:      	add	x16, x19, x21
     e54:      	ldp	q2, q3, [x16]
     e58:      	zip2.8b	v4, v23, v0
     e5c:      	ushll.4s	v4, v4, #0x0
     e60:      	shl.4s	v4, v4, #0x1f
     e64:      	cmlt.4s	v4, v4, #0
     e68:      	stp	q6, q5, [sp, #0x40]
     e6c:      	bit.16b	v3, v6, v4
     e70:      	zip1.8b	v4, v23, v0
     e74:      	ushll.4s	v4, v4, #0x0
     e78:      	shl.4s	v4, v4, #0x1f
     e7c:      	cmlt.4s	v4, v4, #0
     e80:      	bit.16b	v2, v5, v4
     e84:      	stp	q2, q3, [x16]
     e88:      	ldr	q2, [sp, #0x8b0]
     e8c:      	ldr	q3, [sp, #0x8a0]
     e90:      	fmul.4s	v3, v3, v3
     e94:      	fmul.4s	v2, v2, v2
     e98:      	and.16b	v24, v0, v2
     e9c:      	and.16b	v25, v1, v3
     ea0:      	ldr	q2, [sp, #0x890]
     ea4:      	ldr	q3, [sp, #0x880]
     ea8:      	fmul.4s	v3, v3, v3
     eac:      	fmul.4s	v2, v2, v2
     eb0:      	and.16b	v12, v0, v2
     eb4:      	and.16b	v11, v1, v3
     eb8:      	ldr	q2, [sp, #0x870]
     ebc:      	ldr	q3, [sp, #0x860]
     ec0:      	fmul.4s	v3, v3, v3
     ec4:      	fmul.4s	v2, v2, v2
     ec8:      	and.16b	v13, v0, v2
     ecc:      	and.16b	v14, v1, v3
     ed0:      	ldr	q2, [sp, #0x850]
     ed4:      	ldr	q3, [sp, #0x840]
     ed8:      	fmul.4s	v3, v3, v3
     edc:      	fmul.4s	v2, v2, v2
     ee0:      	and.16b	v8, v0, v2
     ee4:      	and.16b	v15, v1, v3
     ee8:      	add	x8, sp, #0x720
     eec:      	sshll.2d	v2, v1, #0x0
     ef0:      	sshll.2d	v3, v0, #0x0
     ef4:      	add	x16, x19, x5, lsl #5
     ef8:      	ldp	q5, q4, [x16]
     efc:      	and.16b	v5, v1, v5
     f00:      	and.16b	v4, v0, v4
     f04:      	fmul.4s	v6, v4, v4
     f08:      	fmul.4s	v4, v5, v5
     f0c:      	fadd.4s	v4, v15, v4
     f10:      	fadd.4s	v5, v8, v6
     f14:      	ldp	q7, q6, [x16, #0x20]
     f18:      	and.16b	v7, v1, v7
     f1c:      	and.16b	v6, v0, v6
     f20:      	fmul.4s	v6, v6, v6
     f24:      	fmul.4s	v7, v7, v7
     f28:      	fadd.4s	v7, v14, v7
     f2c:      	fadd.4s	v6, v13, v6
     f30:      	ldp	q9, q22, [x16, #0x40]
     f34:      	and.16b	v9, v1, v9
     f38:      	and.16b	v22, v0, v22
     f3c:      	fmul.4s	v22, v22, v22
     f40:      	fmul.4s	v9, v9, v9
     f44:      	fadd.4s	v9, v11, v9
     f48:      	fadd.4s	v22, v12, v22
     f4c:      	ldp	q10, q31, [x16, #0x60]
     f50:      	and.16b	v10, v1, v10
     f54:      	and.16b	v31, v0, v31
     f58:      	fmul.4s	v31, v31, v31
     f5c:      	fmul.4s	v10, v10, v10
     f60:      	fadd.4s	v10, v25, v10
     f64:      	fadd.4s	v31, v24, v31
     f68:      	dup.2d	v30, x27
     f6c:      	and.16b	v23, v21, v30
     f70:      	add.2d	v26, v26, v23
     f74:      	and.16b	v23, v20, v30
     f78:      	add.2d	v27, v27, v23
     f7c:      	and.16b	v3, v3, v30
     f80:      	add.2d	v28, v28, v3
     f84:      	and.16b	v2, v2, v30
     f88:      	add.2d	v2, v29, v2
     f8c:      	bit.16b	v8, v5, v0
     f90:      	bit.16b	v15, v4, v1
     f94:      	bit.16b	v13, v6, v0
     f98:      	bit.16b	v14, v7, v1
     f9c:      	bit.16b	v12, v22, v0
     fa0:      	bit.16b	v11, v9, v1
     fa4:      	bit.16b	v24, v31, v0
     fa8:      	bit.16b	v25, v10, v1
     fac:      	fmov	x16, d29
     fb0:      	add	x17, x16, #0x4
     fb4:      	tst	w15, #0x1
     fb8:      	csel	x5, x17, x16, ne
     fbc:      	mov.16b	v29, v2
     fc0:      	cmp	x5, #0x8
     fc4:      	b.lt	0xeec <_llm_rows.packet_batch.blocks+0xa88>
     fc8:      	mov	x16, #0x0               ; =0
     fcc:      	movi.2d	v20, #0000000000000000
     fd0:      	movi.2d	v21, #0000000000000000
     fd4:      	movi.2d	v26, #0000000000000000
     fd8:      	movi.2d	v27, #0000000000000000
     fdc:      	movi.2s	v9, #0x41
     fe0:      	ldr	q10, [sp, #0x160]
     fe4:      	b	0x1020 <_llm_rows.packet_batch.blocks+0xbbc>
     fe8:      	add	x16, x8, x16
     fec:      	ldp	q2, q3, [x16]
     ff0:      	bit.16b	v3, v29, v0
     ff4:      	bit.16b	v2, v28, v1
     ff8:      	stp	q2, q3, [x16]
     ffc:      	add.2d	v2, v20, v19
    1000:      	add.2d	v21, v21, v17
    1004:      	add.2d	v26, v26, v18
    1008:      	add.2d	v27, v27, v16
    100c:      	fmov	x16, d20
    1010:      	add	x16, x16, x13
    1014:      	mov.16b	v20, v2
    1018:      	cmp	x16, #0x8
    101c:      	b.ge	0x10bc <_llm_rows.packet_batch.blocks+0xc58>
    1020:      	fmov	w17, s10
    1024:      	lsl	x16, x16, #5
    1028:      	add	x0, x14, x16
    102c:      	movi.2d	v28, #0000000000000000
    1030:      	movi.2d	v29, #0000000000000000
    1034:      	tbnz	w17, #0x0, 0x105c <_llm_rows.packet_batch.blocks+0xbf8>
    1038:      	and	w17, w17, #0xff
    103c:      	tbnz	w17, #0x1, 0x1068 <_llm_rows.packet_batch.blocks+0xc04>
    1040:      	tbnz	w17, #0x2, 0x1074 <_llm_rows.packet_batch.blocks+0xc10>
    1044:      	tbnz	w17, #0x3, 0x1080 <_llm_rows.packet_batch.blocks+0xc1c>
    1048:      	tbnz	w17, #0x4, 0x108c <_llm_rows.packet_batch.blocks+0xc28>
    104c:      	tbnz	w17, #0x5, 0x1098 <_llm_rows.packet_batch.blocks+0xc34>
    1050:      	tbnz	w17, #0x6, 0x10a4 <_llm_rows.packet_batch.blocks+0xc40>
    1054:      	tbz	w17, #0x7, 0xfe8 <_llm_rows.packet_batch.blocks+0xb84>
    1058:      	b	0x10b0 <_llm_rows.packet_batch.blocks+0xc4c>
    105c:      	ldr	s28, [x0]
    1060:      	and	w17, w17, #0xff
    1064:      	tbz	w17, #0x1, 0x1040 <_llm_rows.packet_batch.blocks+0xbdc>
    1068:      	add	x1, x0, #0x4
    106c:      	ld1.s	{ v28 }[1], [x1]
    1070:      	tbz	w17, #0x2, 0x1044 <_llm_rows.packet_batch.blocks+0xbe0>
    1074:      	add	x1, x0, #0x8
    1078:      	ld1.s	{ v28 }[2], [x1]
    107c:      	tbz	w17, #0x3, 0x1048 <_llm_rows.packet_batch.blocks+0xbe4>
    1080:      	add	x1, x0, #0xc
    1084:      	ld1.s	{ v28 }[3], [x1]
    1088:      	tbz	w17, #0x4, 0x104c <_llm_rows.packet_batch.blocks+0xbe8>
    108c:      	add	x1, x0, #0x10
    1090:      	ld1.s	{ v29 }[0], [x1]
    1094:      	tbz	w17, #0x5, 0x1050 <_llm_rows.packet_batch.blocks+0xbec>
    1098:      	add	x1, x0, #0x14
    109c:      	ld1.s	{ v29 }[1], [x1]
    10a0:      	tbz	w17, #0x6, 0x1054 <_llm_rows.packet_batch.blocks+0xbf0>
    10a4:      	add	x1, x0, #0x18
    10a8:      	ld1.s	{ v29 }[2], [x1]
    10ac:      	tbz	w17, #0x7, 0xfe8 <_llm_rows.packet_batch.blocks+0xb84>
    10b0:      	add	x17, x0, #0x1c
    10b4:      	ld1.s	{ v29 }[3], [x17]
    10b8:      	b	0xfe8 <_llm_rows.packet_batch.blocks+0xb84>
    10bc:      	str	w22, [sp, #0xb0]
    10c0:      	str	x21, [sp, #0xf0]
    10c4:      	ldr	q30, [sp, #0x180]
    10c8:      	zip2.8b	v2, v30, v0
    10cc:      	ushll.4s	v2, v2, #0x0
    10d0:      	shl.4s	v2, v2, #0x1f
    10d4:      	cmlt.4s	v2, v2, #0
    10d8:      	ldp	q3, q6, [sp, #0x40]
    10dc:      	and.16b	v20, v2, v3
    10e0:      	zip1.8b	v3, v30, v0
    10e4:      	ushll.4s	v3, v3, #0x0
    10e8:      	shl.4s	v3, v3, #0x1f
    10ec:      	cmlt.4s	v3, v3, #0
    10f0:      	and.16b	v21, v3, v6
    10f4:      	fmul.4s	v6, v21, v21
    10f8:      	fmul.4s	v7, v20, v20
    10fc:      	fadd.4s	v7, v7, v8
    1100:      	fadd.4s	v6, v6, v15
    1104:      	and.16b	v3, v3, v6
    1108:      	and.16b	v2, v2, v7
    110c:      	ldr	q7, [sp, #0x60]
    1110:      	zip2.8b	v6, v7, v0
    1114:      	ushll.4s	v6, v6, #0x0
    1118:      	shl.4s	v6, v6, #0x1f
    111c:      	cmlt.4s	v6, v6, #0
    1120:      	bit.16b	v2, v5, v6
    1124:      	zip1.8b	v5, v7, v0
    1128:      	ushll.4s	v5, v5, #0x0
    112c:      	shl.4s	v5, v5, #0x1f
    1130:      	cmlt.4s	v5, v5, #0
    1134:      	bit.16b	v3, v4, v5
    1138:      	fadd.4s	v3, v14, v3
    113c:      	fadd.4s	v2, v13, v2
    1140:      	fadd.4s	v2, v12, v2
    1144:      	fadd.4s	v3, v11, v3
    1148:      	fadd.4s	v4, v25, v3
    114c:      	fadd.4s	v5, v24, v2
    1150:      	add	x16, sp, #0x1f8
    1154:      	bfxil	x16, x15, #0, #1
    1158:      	ldr	q2, [sp, #0x80]
    115c:      	str	d2, [sp, #0x1f8]
    1160:      	ldrb	w16, [x16]
    1164:      	add	x17, sp, #0x420
    1168:      	bfi	x17, x15, #2, #1
    116c:      	str	q5, [sp, #0x430]
    1170:      	str	q4, [sp, #0x420]
    1174:      	ldr	s2, [x17]
    1178:      	ands	w6, w15, #0x1
    117c:      	mov	w10, #0x2               ; =2
    1180:      	csel	w17, w10, wzr, ne
    1184:      	csel	w5, w27, wzr, ne
    1188:      	tst	w6, w16
    118c:      	movi	d27, #0000000000000000
    1190:      	fcsel	s23, s2, s27, ne
    1194:      	tst	w23, #0x1
    1198:      	fcsel	s25, s4, s27, ne
    119c:      	ands	w12, w12, #0x1
    11a0:      	mov	w8, #0x3                ; =3
    11a4:      	csel	w16, w8, wzr, ne
    11a8:      	mov	w30, #0x4               ; =4
    11ac:      	add	x27, sp, #0x1f8
    11b0:      	orr	x0, x27, x16
    11b4:      	ldrb	w0, [x0]
    11b8:      	add	x8, sp, #0x400
    11bc:      	orr	x16, x8, x16, lsl #2
    11c0:      	str	q5, [sp, #0x410]
    11c4:      	str	q4, [sp, #0x400]
    11c8:      	ldr	s2, [x16]
    11cc:      	tst	w12, w0
    11d0:      	fcsel	s24, s2, s27, ne
    11d4:      	ands	w16, w26, #0x1
    11d8:      	csel	w12, w10, wzr, ne
    11dc:      	orr	x0, x27, x12
    11e0:      	ldrb	w0, [x0]
    11e4:      	lsr	x12, x12, #1
    11e8:      	add	x1, sp, #0x3e0
    11ec:      	bfi	x1, x12, #3, #1
    11f0:      	stp	q4, q5, [sp, #0x3e0]
    11f4:      	ldr	s2, [x1]
    11f8:      	tst	w16, w0
    11fc:      	fcsel	s26, s2, s27, ne
    1200:      	ands	w12, w4, #0x1
    1204:      	mov	w8, #0x6                ; =6
    1208:      	str	w23, [sp, #0x80]
    120c:      	csel	w23, w8, wzr, ne
    1210:      	mov	w10, #0x5               ; =5
    1214:      	csel	w4, w10, wzr, ne
    1218:      	ands	w7, w3, #0x1
    121c:      	mov	w2, #0x7                ; =7
    1220:      	mov	x22, x26
    1224:      	csel	w26, w2, wzr, ne
    1228:      	csel	w3, w30, wzr, ne
    122c:      	ands	w0, w9, #0x1
    1230:      	csel	w1, w30, wzr, ne
    1234:      	csel	w9, w2, wzr, ne
    1238:      	ldr	w2, [sp, #0x7c]
    123c:      	ands	w30, w2, #0x1
    1240:      	csel	w2, w10, wzr, ne
    1244:      	orr	x10, x27, x2
    1248:      	ldrb	w10, [x10]
    124c:      	stp	q4, q5, [sp, #0x3c0]
    1250:      	add	x21, sp, #0x3c0
    1254:      	ldr	s2, [x21, w2, uxtw #2]
    1258:      	orr	x2, x27, x1
    125c:      	ldrb	w2, [x2]
    1260:      	stp	q4, q5, [sp, #0x3a0]
    1264:      	add	x21, sp, #0x3a0
    1268:      	ldr	s3, [x21, w1, uxtw #2]
    126c:      	csel	w1, w8, wzr, ne
    1270:      	tst	w30, w10
    1274:      	fcsel	s2, s2, s27, ne
    1278:      	tst	w0, w2
    127c:      	orr	x10, x27, x26
    1280:      	ldrb	w10, [x10]
    1284:      	stp	q4, q5, [sp, #0x380]
    1288:      	add	x8, sp, #0x380
    128c:      	ldr	s6, [x8, w26, uxtw #2]
    1290:      	fcsel	s3, s3, s27, ne
    1294:      	tst	w7, w10
    1298:      	orr	x10, x27, x23
    129c:      	ldrb	w10, [x10]
    12a0:      	stp	q4, q5, [sp, #0x360]
    12a4:      	add	x8, sp, #0x360
    12a8:      	ldr	s7, [x8, w23, uxtw #2]
    12ac:      	fcsel	s6, s6, s27, ne
    12b0:      	tst	w12, w10
    12b4:      	fcsel	s7, s7, s27, ne
    12b8:      	mov.s	v2[1], v3[0]
    12bc:      	mov.s	v2[2], v6[0]
    12c0:      	mov.s	v2[3], v7[0]
    12c4:      	mov.s	v23[1], v25[0]
    12c8:      	lsr	x10, x17, #1
    12cc:      	add	x2, sp, #0x340
    12d0:      	bfi	x2, x10, #3, #1
    12d4:      	mov.s	v23[2], v24[0]
    12d8:      	mov.s	v23[3], v26[0]
    12dc:      	fadd.4s	v4, v4, v23
    12e0:      	fadd.4s	v5, v5, v2
    12e4:      	orr	x10, x27, x17
    12e8:      	ldrb	w10, [x10]
    12ec:      	stp	q4, q5, [sp, #0x340]
    12f0:      	ldr	s2, [x2]
    12f4:      	tst	w6, w10
    12f8:      	fcsel	s23, s2, s27, ne
    12fc:      	ldr	w8, [sp, #0xc8]
    1300:      	ands	w10, w8, #0x1
    1304:      	mov	w8, #0x3                ; =3
    1308:      	csel	w17, w8, wzr, ne
    130c:      	orr	x2, x27, x17
    1310:      	ldrb	w2, [x2]
    1314:      	tst	w10, w2
    1318:      	add	x8, sp, #0x280
    131c:      	orr	x10, x8, x17, lsl #2
    1320:      	stp	q4, q5, [sp, #0x280]
    1324:      	ldr	s2, [x10]
    1328:      	add	x10, sp, #0x1f8
    132c:      	bfxil	x10, x22, #0, #1
    1330:      	ldrb	w10, [x10]
    1334:      	fcsel	s2, s2, s27, ne
    1338:      	ldr	w17, [sp, #0xd0]
    133c:      	tst	w17, #0x1
    1340:      	fcsel	s3, s4, s27, ne
    1344:      	tst	w16, w10
    1348:      	add	x10, sp, #0x320
    134c:      	bfi	x10, x22, #2, #1
    1350:      	stp	q4, q5, [sp, #0x320]
    1354:      	ldr	s6, [x10]
    1358:      	orr	x10, x27, x1
    135c:      	ldrb	w10, [x10]
    1360:      	stp	q4, q5, [sp, #0x300]
    1364:      	add	x8, sp, #0x300
    1368:      	ldr	s7, [x8, w1, uxtw #2]
    136c:      	fcsel	s6, s6, s27, ne
    1370:      	tst	w30, w10
    1374:      	fcsel	s7, s7, s27, ne
    1378:      	orr	x10, x27, x9
    137c:      	ldrb	w10, [x10]
    1380:      	tst	w0, w10
    1384:      	stp	q4, q5, [sp, #0x2e0]
    1388:      	add	x8, sp, #0x2e0
    138c:      	ldr	s22, [x8, w9, uxtw #2]
    1390:      	fcsel	s22, s22, s27, ne
    1394:      	orr	x9, x27, x3
    1398:      	ldrb	w9, [x9]
    139c:      	tst	w7, w9
    13a0:      	stp	q4, q5, [sp, #0x2c0]
    13a4:      	add	x8, sp, #0x2c0
    13a8:      	ldr	s24, [x8, w3, uxtw #2]
    13ac:      	orr	x9, x27, x4
    13b0:      	ldrb	w9, [x9]
    13b4:      	stp	q4, q5, [sp, #0x2a0]
    13b8:      	add	x8, sp, #0x2a0
    13bc:      	ldr	s25, [x8, w4, uxtw #2]
    13c0:      	fcsel	s24, s24, s27, ne
    13c4:      	tst	w12, w9
    13c8:      	fcsel	s25, s25, s27, ne
    13cc:      	mov.s	v23[1], v2[0]
    13d0:      	mov.s	v23[2], v3[0]
    13d4:      	mov.s	v23[3], v6[0]
    13d8:      	mov.s	v7[1], v22[0]
    13dc:      	orr	x9, x27, x5
    13e0:      	ldrb	w9, [x9]
    13e4:      	tst	w6, w9
    13e8:      	mov.s	v7[2], v24[0]
    13ec:      	mov.s	v7[3], v25[0]
    13f0:      	fadd.4s	v2, v4, v23
    13f4:      	fadd.4s	v3, v5, v7
    13f8:      	stp	q2, q3, [sp, #0x260]
    13fc:      	add	x8, sp, #0x260
    1400:      	ldr	s3, [x8, w5, uxtw #2]
    1404:      	fcsel	s3, s3, s27, ne
    1408:      	tst	w15, #0x1
    140c:      	fadd	s2, s2, s3
    1410:      	fcsel	s3, s2, s27, ne
    1414:      	ldr	w8, [sp, #0x80]
    1418:      	tst	w8, #0x1
    141c:      	fcsel	s4, s2, s27, ne
    1420:      	tst	w17, #0x1
    1424:      	fcsel	s5, s2, s27, ne
    1428:      	ldr	w8, [sp, #0x9c]
    142c:      	tst	w8, #0x1
    1430:      	fcsel	s6, s2, s27, ne
    1434:      	ldr	w8, [sp, #0xcc]
    1438:      	tst	w8, #0x1
    143c:      	fcsel	s7, s2, s27, ne
    1440:      	ldp	w8, w9, [sp, #0x94]
    1444:      	tst	w9, #0x1
    1448:      	fcsel	s23, s2, s27, ne
    144c:      	tst	w8, #0x1
    1450:      	sshll.2d	v24, v1, #0x0
    1454:      	shl.8b	v22, v30, #0x7
    1458:      	cmlt.8b	v22, v22, #0
    145c:      	ldr	d25, [sp, #0xe8]
    1460:      	and.8b	v22, v22, v25
    1464:      	addv.8b	b22, v22
    1468:      	fcsel	s25, s2, s27, ne
    146c:      	ldr	w8, [sp, #0xac]
    1470:      	tst	w8, #0x1
    1474:      	movi	d26, #0000000000000000
    1478:      	fcsel	s2, s2, s27, ne
    147c:      	mov.s	v3[1], v4[0]
    1480:      	mov.s	v3[2], v5[0]
    1484:      	mov.s	v3[3], v6[0]
    1488:      	mov.s	v7[1], v23[0]
    148c:      	mov.s	v7[2], v25[0]
    1490:      	mov.s	v7[3], v2[0]
    1494:      	stp	q3, q7, [sp, #0x240]
    1498:      	ldr	x8, [sp, #0xa0]
    149c:      	and	x9, x8, #0x7
    14a0:      	add	x8, sp, #0x240
    14a4:      	ldr	s4, [x8, x9, lsl #2]
    14a8:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0xb9c>
    14ac:      	ldr	q2, [x8]
    14b0:      	and.16b	v2, v24, v2
    14b4:      	movi.2d	v3, #0000000000000000
    14b8:      	stp	q3, q3, [sp, #0x220]
    14bc:      	stp	q2, q3, [sp, #0x200]
    14c0:      	ldr	x2, [sp, #0x158]
    14c4:      	and	x9, x2, #0x7
    14c8:      	add	x8, sp, #0x200
    14cc:      	ldr	x9, [x8, x9, lsl #3]
    14d0:      	fmov	w12, s22
    14d4:      	sub	x9, x9, x2
    14d8:      	lsl	x9, x9, #2
    14dc:      	add	x14, x14, x9
    14e0:      	movi.2d	v23, #0000000000000000
    14e4:      	movi.2d	v24, #0000000000000000
    14e8:      	tbnz	w12, #0x0, 0x190c <_llm_rows.packet_batch.blocks+0x14a8>
    14ec:      	add	x16, sp, #0x600
    14f0:      	ldr	x1, [sp, #0x170]
    14f4:      	ldr	x3, [sp, #0x138]
    14f8:      	tbnz	w12, #0x1, 0x1920 <_llm_rows.packet_batch.blocks+0x14bc>
    14fc:      	mov	w27, #0x4               ; =4
    1500:      	ldr	x17, [sp, #0xf0]
    1504:      	ldr	w22, [sp, #0xb0]
    1508:      	tbnz	w12, #0x2, 0x1938 <_llm_rows.packet_batch.blocks+0x14d4>
    150c:      	tbnz	w12, #0x3, 0x1944 <_llm_rows.packet_batch.blocks+0x14e0>
    1510:      	tbnz	w12, #0x4, 0x1950 <_llm_rows.packet_batch.blocks+0x14ec>
    1514:      	tbnz	w12, #0x5, 0x195c <_llm_rows.packet_batch.blocks+0x14f8>
    1518:      	tbnz	w12, #0x6, 0x1968 <_llm_rows.packet_batch.blocks+0x1504>
    151c:      	tbz	w12, #0x7, 0x1528 <_llm_rows.packet_batch.blocks+0x10c4>
    1520:      	add	x10, x14, #0x1c
    1524:      	ld1.s	{ v24 }[3], [x10]
    1528:      	fadd	s2, s4, s26
    152c:      	mov	w8, #0x42820000         ; =1115815936
    1530:      	fmov	s3, w8
    1534:      	fdiv	s2, s2, s3
    1538:      	add	x8, sp, #0x720
    153c:      	add	x10, x8, x17
    1540:      	ldp	q3, q4, [x10]
    1544:      	zip2.8b	v5, v30, v0
    1548:      	ushll.4s	v5, v5, #0x0
    154c:      	shl.4s	v5, v5, #0x1f
    1550:      	cmlt.4s	v5, v5, #0
    1554:      	bit.16b	v4, v24, v5
    1558:      	zip1.8b	v5, v30, v0
    155c:      	ushll.4s	v5, v5, #0x0
    1560:      	shl.4s	v5, v5, #0x1f
    1564:      	cmlt.4s	v5, v5, #0
    1568:      	bit.16b	v3, v23, v5
    156c:      	stp	q3, q4, [x10]
    1570:      	mov	w10, #0xc5ac            ; =50604
    1574:      	movk	w10, #0x3727, lsl #16
    1578:      	fmov	s3, w10
    157c:      	fadd	s2, s2, s3
    1580:      	fsqrt	s25, s2
    1584:      	sub	x10, x11, x1
    1588:      	lsr	x10, x10, #2
    158c:      	subs	x12, x1, x11
    1590:      	mov	w14, #0x103             ; =259
    1594:      	ccmp	x12, x14, #0x0, hs
    1598:      	cset	w12, hi
    159c:      	cmp	x10, #0x450
    15a0:      	ccmp	x11, x1, #0x0, hi
    15a4:      	b.hs	0x1698 <_llm_rows.packet_batch.blocks+0x1234>
    15a8:      	tbnz	w12, #0x0, 0x1698 <_llm_rows.packet_batch.blocks+0x1234>
    15ac:      	mov	x12, #0x0               ; =0
    15b0:      	movi.2d	v4, #0000000000000000
    15b4:      	movi.2d	v5, #0000000000000000
    15b8:      	movi.2d	v26, #0000000000000000
    15bc:      	movi.2d	v27, #0000000000000000
    15c0:      	b	0x15fc <_llm_rows.packet_batch.blocks+0x1198>
    15c4:      	add	x10, x16, x12
    15c8:      	ldp	q2, q3, [x10]
    15cc:      	bit.16b	v3, v29, v0
    15d0:      	bit.16b	v2, v28, v1
    15d4:      	stp	q2, q3, [x10]
    15d8:      	add.2d	v2, v4, v19
    15dc:      	add.2d	v5, v5, v17
    15e0:      	add.2d	v26, v26, v18
    15e4:      	add.2d	v27, v27, v16
    15e8:      	fmov	x10, d4
    15ec:      	add	x12, x10, x13
    15f0:      	mov.16b	v4, v2
    15f4:      	cmp	x12, #0x8
    15f8:      	b.ge	0x1978 <_llm_rows.packet_batch.blocks+0x1514>
    15fc:      	fmov	w15, s10
    1600:      	lsl	x12, x12, #5
    1604:      	add	x14, x11, x12
    1608:      	movi.2d	v28, #0000000000000000
    160c:      	movi.2d	v29, #0000000000000000
    1610:      	tbnz	w15, #0x0, 0x1638 <_llm_rows.packet_batch.blocks+0x11d4>
    1614:      	and	w15, w15, #0xff
    1618:      	tbnz	w15, #0x1, 0x1644 <_llm_rows.packet_batch.blocks+0x11e0>
    161c:      	tbnz	w15, #0x2, 0x1650 <_llm_rows.packet_batch.blocks+0x11ec>
    1620:      	tbnz	w15, #0x3, 0x165c <_llm_rows.packet_batch.blocks+0x11f8>
    1624:      	tbnz	w15, #0x4, 0x1668 <_llm_rows.packet_batch.blocks+0x1204>
    1628:      	tbnz	w15, #0x5, 0x1674 <_llm_rows.packet_batch.blocks+0x1210>
    162c:      	tbnz	w15, #0x6, 0x1680 <_llm_rows.packet_batch.blocks+0x121c>
    1630:      	tbz	w15, #0x7, 0x15c4 <_llm_rows.packet_batch.blocks+0x1160>
    1634:      	b	0x168c <_llm_rows.packet_batch.blocks+0x1228>
    1638:      	ldr	s28, [x14]
    163c:      	and	w15, w15, #0xff
    1640:      	tbz	w15, #0x1, 0x161c <_llm_rows.packet_batch.blocks+0x11b8>
    1644:      	add	x10, x14, #0x4
    1648:      	ld1.s	{ v28 }[1], [x10]
    164c:      	tbz	w15, #0x2, 0x1620 <_llm_rows.packet_batch.blocks+0x11bc>
    1650:      	add	x10, x14, #0x8
    1654:      	ld1.s	{ v28 }[2], [x10]
    1658:      	tbz	w15, #0x3, 0x1624 <_llm_rows.packet_batch.blocks+0x11c0>
    165c:      	add	x10, x14, #0xc
    1660:      	ld1.s	{ v28 }[3], [x10]
    1664:      	tbz	w15, #0x4, 0x1628 <_llm_rows.packet_batch.blocks+0x11c4>
    1668:      	add	x10, x14, #0x10
    166c:      	ld1.s	{ v29 }[0], [x10]
    1670:      	tbz	w15, #0x5, 0x162c <_llm_rows.packet_batch.blocks+0x11c8>
    1674:      	add	x10, x14, #0x14
    1678:      	ld1.s	{ v29 }[1], [x10]
    167c:      	tbz	w15, #0x6, 0x1630 <_llm_rows.packet_batch.blocks+0x11cc>
    1680:      	add	x10, x14, #0x18
    1684:      	ld1.s	{ v29 }[2], [x10]
    1688:      	tbz	w15, #0x7, 0x15c4 <_llm_rows.packet_batch.blocks+0x1160>
    168c:      	add	x10, x14, #0x1c
    1690:      	ld1.s	{ v29 }[3], [x10]
    1694:      	b	0x15c4 <_llm_rows.packet_batch.blocks+0x1160>
    1698:      	mov	x14, #0x0               ; =0
    169c:      	dup.4s	v7, v25[0]
    16a0:      	movi.2d	v4, #0000000000000000
    16a4:      	movi.2d	v5, #0000000000000000
    16a8:      	movi.2d	v25, #0000000000000000
    16ac:      	movi.2d	v26, #0000000000000000
    16b0:      	b	0x16d0 <_llm_rows.packet_batch.blocks+0x126c>
    16b4:      	add.2d	v4, v4, v19
    16b8:      	add.2d	v5, v5, v17
    16bc:      	add.2d	v25, v25, v18
    16c0:      	add.2d	v26, v26, v16
    16c4:      	add	x14, x12, x13
    16c8:      	cmp	x14, #0x8
    16cc:      	b.ge	0x185c <_llm_rows.packet_batch.blocks+0x13f8>
    16d0:      	fmov	w17, s10
    16d4:      	fmov	x12, d4
    16d8:      	lsl	x15, x12, #5
    16dc:      	add	x16, x11, x15
    16e0:      	movi.2d	v28, #0000000000000000
    16e4:      	movi.2d	v27, #0000000000000000
    16e8:      	tbnz	w17, #0x0, 0x178c <_llm_rows.packet_batch.blocks+0x1328>
    16ec:      	and	w17, w17, #0xff
    16f0:      	tbnz	w17, #0x1, 0x1798 <_llm_rows.packet_batch.blocks+0x1334>
    16f4:      	tbnz	w17, #0x2, 0x17a4 <_llm_rows.packet_batch.blocks+0x1340>
    16f8:      	tbnz	w17, #0x3, 0x17b0 <_llm_rows.packet_batch.blocks+0x134c>
    16fc:      	tbnz	w17, #0x4, 0x17bc <_llm_rows.packet_batch.blocks+0x1358>
    1700:      	tbnz	w17, #0x5, 0x17c8 <_llm_rows.packet_batch.blocks+0x1364>
    1704:      	tbnz	w17, #0x6, 0x17d4 <_llm_rows.packet_batch.blocks+0x1370>
    1708:      	tbz	w17, #0x7, 0x1714 <_llm_rows.packet_batch.blocks+0x12b0>
    170c:      	add	x10, x16, #0x1c
    1710:      	ld1.s	{ v27 }[3], [x10]
    1714:      	lsl	x10, x14, #5
    1718:      	add	x16, x19, x10
    171c:      	ldr	q2, [x16]
    1720:      	and.16b	v2, v1, v2
    1724:      	fdiv.4s	v2, v2, v7
    1728:      	add	x17, x8, x10
    172c:      	ldr	q3, [x17]
    1730:      	and.16b	v3, v1, v3
    1734:      	fmul.4s	v2, v2, v3
    1738:      	fmov	w0, s10
    173c:      	fadd.4s	v28, v28, v2
    1740:      	add	x10, x1, x15
    1744:      	add	x14, x10, x3
    1748:      	tbnz	w0, #0x0, 0x17e4 <_llm_rows.packet_batch.blocks+0x1380>
    174c:      	and	w15, w0, #0xff
    1750:      	tbnz	w15, #0x1, 0x17f0 <_llm_rows.packet_batch.blocks+0x138c>
    1754:      	ldr	q30, [x16, #0x10]
    1758:      	ldr	q29, [x17, #0x10]
    175c:      	tbnz	w15, #0x2, 0x1804 <_llm_rows.packet_batch.blocks+0x13a0>
    1760:      	tbnz	w15, #0x3, 0x1810 <_llm_rows.packet_batch.blocks+0x13ac>
    1764:      	and.16b	v2, v0, v30
    1768:      	fdiv.4s	v2, v2, v7
    176c:      	and.16b	v3, v0, v29
    1770:      	fmul.4s	v2, v2, v3
    1774:      	fadd.4s	v27, v27, v2
    1778:      	tbnz	w15, #0x4, 0x1830 <_llm_rows.packet_batch.blocks+0x13cc>
    177c:      	tbnz	w15, #0x5, 0x1838 <_llm_rows.packet_batch.blocks+0x13d4>
    1780:      	tbnz	w15, #0x6, 0x1844 <_llm_rows.packet_batch.blocks+0x13e0>
    1784:      	tbz	w15, #0x7, 0x16b4 <_llm_rows.packet_batch.blocks+0x1250>
    1788:      	b	0x1850 <_llm_rows.packet_batch.blocks+0x13ec>
    178c:      	ldr	s28, [x16]
    1790:      	and	w17, w17, #0xff
    1794:      	tbz	w17, #0x1, 0x16f4 <_llm_rows.packet_batch.blocks+0x1290>
    1798:      	add	x10, x16, #0x4
    179c:      	ld1.s	{ v28 }[1], [x10]
    17a0:      	tbz	w17, #0x2, 0x16f8 <_llm_rows.packet_batch.blocks+0x1294>
    17a4:      	add	x10, x16, #0x8
    17a8:      	ld1.s	{ v28 }[2], [x10]
    17ac:      	tbz	w17, #0x3, 0x16fc <_llm_rows.packet_batch.blocks+0x1298>
    17b0:      	add	x10, x16, #0xc
    17b4:      	ld1.s	{ v28 }[3], [x10]
    17b8:      	tbz	w17, #0x4, 0x1700 <_llm_rows.packet_batch.blocks+0x129c>
    17bc:      	add	x10, x16, #0x10
    17c0:      	ld1.s	{ v27 }[0], [x10]
    17c4:      	tbz	w17, #0x5, 0x1704 <_llm_rows.packet_batch.blocks+0x12a0>
    17c8:      	add	x10, x16, #0x14
    17cc:      	ld1.s	{ v27 }[1], [x10]
    17d0:      	tbz	w17, #0x6, 0x1708 <_llm_rows.packet_batch.blocks+0x12a4>
    17d4:      	add	x10, x16, #0x18
    17d8:      	ld1.s	{ v27 }[2], [x10]
    17dc:      	tbnz	w17, #0x7, 0x170c <_llm_rows.packet_batch.blocks+0x12a8>
    17e0:      	b	0x1714 <_llm_rows.packet_batch.blocks+0x12b0>
    17e4:      	str	s28, [x14]
    17e8:      	and	w15, w0, #0xff
    17ec:      	tbz	w15, #0x1, 0x1754 <_llm_rows.packet_batch.blocks+0x12f0>
    17f0:      	add	x10, x14, #0x4
    17f4:      	st1.s	{ v28 }[1], [x10]
    17f8:      	ldr	q30, [x16, #0x10]
    17fc:      	ldr	q29, [x17, #0x10]
    1800:      	tbz	w15, #0x2, 0x1760 <_llm_rows.packet_batch.blocks+0x12fc>
    1804:      	add	x10, x14, #0x8
    1808:      	st1.s	{ v28 }[2], [x10]
    180c:      	tbz	w15, #0x3, 0x1764 <_llm_rows.packet_batch.blocks+0x1300>
    1810:      	add	x10, x14, #0xc
    1814:      	st1.s	{ v28 }[3], [x10]
    1818:      	and.16b	v2, v0, v30
    181c:      	fdiv.4s	v2, v2, v7
    1820:      	and.16b	v3, v0, v29
    1824:      	fmul.4s	v2, v2, v3
    1828:      	fadd.4s	v27, v27, v2
    182c:      	tbz	w15, #0x4, 0x177c <_llm_rows.packet_batch.blocks+0x1318>
    1830:      	str	s27, [x14, #0x10]
    1834:      	tbz	w15, #0x5, 0x1780 <_llm_rows.packet_batch.blocks+0x131c>
    1838:      	add	x10, x14, #0x14
    183c:      	st1.s	{ v27 }[1], [x10]
    1840:      	tbz	w15, #0x6, 0x1784 <_llm_rows.packet_batch.blocks+0x1320>
    1844:      	add	x10, x14, #0x18
    1848:      	st1.s	{ v27 }[2], [x10]
    184c:      	tbz	w15, #0x7, 0x16b4 <_llm_rows.packet_batch.blocks+0x1250>
    1850:      	add	x10, x14, #0x1c
    1854:      	st1.s	{ v27 }[3], [x10]
    1858:      	b	0x16b4 <_llm_rows.packet_batch.blocks+0x1250>
    185c:      	add	x9, x11, x9
    1860:      	fmov	w10, s22
    1864:      	movi.2d	v0, #0000000000000000
    1868:      	movi.2d	v1, #0000000000000000
    186c:      	tbnz	w10, #0x0, 0x1bc4 <_llm_rows.packet_batch.blocks+0x1760>
    1870:      	ldr	w12, [sp, #0x178]
    1874:      	tbnz	w10, #0x1, 0x1bd0 <_llm_rows.packet_batch.blocks+0x176c>
    1878:      	tbnz	w10, #0x2, 0x1bdc <_llm_rows.packet_batch.blocks+0x1778>
    187c:      	tbnz	w10, #0x3, 0x1be8 <_llm_rows.packet_batch.blocks+0x1784>
    1880:      	tbnz	w10, #0x4, 0x1bf4 <_llm_rows.packet_batch.blocks+0x1790>
    1884:      	tbnz	w10, #0x5, 0x1c00 <_llm_rows.packet_batch.blocks+0x179c>
    1888:      	tbnz	w10, #0x6, 0x1c0c <_llm_rows.packet_batch.blocks+0x17a8>
    188c:      	tbz	w10, #0x7, 0x1898 <_llm_rows.packet_batch.blocks+0x1434>
    1890:      	add	x9, x9, #0x1c
    1894:      	ld1.s	{ v1 }[3], [x9]
    1898:      	fdiv.4s	v2, v20, v7
    189c:      	fdiv.4s	v3, v21, v7
    18a0:      	fmul.4s	v3, v3, v23
    18a4:      	fmul.4s	v4, v2, v24
    18a8:      	fadd.4s	v2, v3, v0
    18ac:      	fadd.4s	v0, v4, v1
    18b0:      	b	0x1b1c <_llm_rows.packet_batch.blocks+0x16b8>
    18b4:      	ldr	s22, [x9]
    18b8:      	tbz	w12, #0x1, 0x84c <_llm_rows.packet_batch.blocks+0x3e8>
    18bc:      	add	x16, x9, #0x4
    18c0:      	ld1.s	{ v22 }[1], [x16]
    18c4:      	tbz	w12, #0x2, 0x850 <_llm_rows.packet_batch.blocks+0x3ec>
    18c8:      	add	x16, x9, #0x8
    18cc:      	ld1.s	{ v22 }[2], [x16]
    18d0:      	tbz	w12, #0x3, 0x854 <_llm_rows.packet_batch.blocks+0x3f0>
    18d4:      	add	x16, x9, #0xc
    18d8:      	ld1.s	{ v22 }[3], [x16]
    18dc:      	tbz	w12, #0x4, 0x858 <_llm_rows.packet_batch.blocks+0x3f4>
    18e0:      	add	x16, x9, #0x10
    18e4:      	ld1.s	{ v24 }[0], [x16]
    18e8:      	tbz	w12, #0x5, 0x85c <_llm_rows.packet_batch.blocks+0x3f8>
    18ec:      	add	x16, x9, #0x14
    18f0:      	ld1.s	{ v24 }[1], [x16]
    18f4:      	tbz	w12, #0x6, 0x860 <_llm_rows.packet_batch.blocks+0x3fc>
    18f8:      	add	x16, x9, #0x18
    18fc:      	ld1.s	{ v24 }[2], [x16]
    1900:      	str	q16, [sp, #0x160]
    1904:      	tbnz	w12, #0x7, 0x868 <_llm_rows.packet_batch.blocks+0x404>
    1908:      	b	0x870 <_llm_rows.packet_batch.blocks+0x40c>
    190c:      	ldr	s23, [x14]
    1910:      	add	x16, sp, #0x600
    1914:      	ldr	x1, [sp, #0x170]
    1918:      	ldr	x3, [sp, #0x138]
    191c:      	tbz	w12, #0x1, 0x14fc <_llm_rows.packet_batch.blocks+0x1098>
    1920:      	add	x10, x14, #0x4
    1924:      	ld1.s	{ v23 }[1], [x10]
    1928:      	mov	w27, #0x4               ; =4
    192c:      	ldr	x17, [sp, #0xf0]
    1930:      	ldr	w22, [sp, #0xb0]
    1934:      	tbz	w12, #0x2, 0x150c <_llm_rows.packet_batch.blocks+0x10a8>
    1938:      	add	x10, x14, #0x8
    193c:      	ld1.s	{ v23 }[2], [x10]
    1940:      	tbz	w12, #0x3, 0x1510 <_llm_rows.packet_batch.blocks+0x10ac>
    1944:      	add	x10, x14, #0xc
    1948:      	ld1.s	{ v23 }[3], [x10]
    194c:      	tbz	w12, #0x4, 0x1514 <_llm_rows.packet_batch.blocks+0x10b0>
    1950:      	add	x10, x14, #0x10
    1954:      	ld1.s	{ v24 }[0], [x10]
    1958:      	tbz	w12, #0x5, 0x1518 <_llm_rows.packet_batch.blocks+0x10b4>
    195c:      	add	x10, x14, #0x14
    1960:      	ld1.s	{ v24 }[1], [x10]
    1964:      	tbz	w12, #0x6, 0x151c <_llm_rows.packet_batch.blocks+0x10b8>
    1968:      	add	x10, x14, #0x18
    196c:      	ld1.s	{ v24 }[2], [x10]
    1970:      	tbnz	w12, #0x7, 0x1520 <_llm_rows.packet_batch.blocks+0x10bc>
    1974:      	b	0x1528 <_llm_rows.packet_batch.blocks+0x10c4>
    1978:      	add	x9, x11, x9
    197c:      	fmov	w11, s22
    1980:      	movi.2d	v4, #0000000000000000
    1984:      	movi.2d	v5, #0000000000000000
    1988:      	tbnz	w11, #0x0, 0x1c1c <_llm_rows.packet_batch.blocks+0x17b8>
    198c:      	tbnz	w11, #0x1, 0x1c24 <_llm_rows.packet_batch.blocks+0x17c0>
    1990:      	tbnz	w11, #0x2, 0x1c30 <_llm_rows.packet_batch.blocks+0x17cc>
    1994:      	tbnz	w11, #0x3, 0x1c3c <_llm_rows.packet_batch.blocks+0x17d8>
    1998:      	tbnz	w11, #0x4, 0x1c48 <_llm_rows.packet_batch.blocks+0x17e4>
    199c:      	tbnz	w11, #0x5, 0x1c54 <_llm_rows.packet_batch.blocks+0x17f0>
    19a0:      	tbnz	w11, #0x6, 0x1c60 <_llm_rows.packet_batch.blocks+0x17fc>
    19a4:      	tbz	w11, #0x7, 0x19b0 <_llm_rows.packet_batch.blocks+0x154c>
    19a8:      	add	x9, x9, #0x1c
    19ac:      	ld1.s	{ v5 }[3], [x9]
    19b0:      	mov	x11, #0x0               ; =0
    19b4:      	add	x9, x16, x17
    19b8:      	ldp	q2, q3, [x9]
    19bc:      	zip2.8b	v6, v30, v0
    19c0:      	ushll.4s	v6, v6, #0x0
    19c4:      	shl.4s	v6, v6, #0x1f
    19c8:      	cmlt.4s	v6, v6, #0
    19cc:      	bit.16b	v3, v5, v6
    19d0:      	zip1.8b	v6, v30, v0
    19d4:      	ushll.4s	v6, v6, #0x0
    19d8:      	shl.4s	v6, v6, #0x1f
    19dc:      	cmlt.4s	v6, v6, #0
    19e0:      	bit.16b	v2, v4, v6
    19e4:      	dup.4s	v7, v25[0]
    19e8:      	stp	q2, q3, [x9]
    19ec:      	add	x9, x1, x3
    19f0:      	movi.2d	v25, #0000000000000000
    19f4:      	movi.2d	v26, #0000000000000000
    19f8:      	movi.2d	v27, #0000000000000000
    19fc:      	movi.2d	v28, #0000000000000000
    1a00:      	b	0x1a28 <_llm_rows.packet_batch.blocks+0x15c4>
    1a04:      	add.2d	v2, v25, v19
    1a08:      	add.2d	v26, v26, v17
    1a0c:      	add.2d	v27, v27, v18
    1a10:      	add.2d	v28, v28, v16
    1a14:      	fmov	x10, d25
    1a18:      	add	x11, x10, x13
    1a1c:      	mov.16b	v25, v2
    1a20:      	cmp	x11, #0x8
    1a24:      	b.ge	0x1b00 <_llm_rows.packet_batch.blocks+0x169c>
    1a28:      	fmov	w12, s10
    1a2c:      	lsl	x10, x11, #5
    1a30:      	add	x11, x19, x10
    1a34:      	ldp	q2, q29, [x11]
    1a38:      	and.16b	v2, v1, v2
    1a3c:      	fdiv.4s	v2, v2, v7
    1a40:      	add	x11, x8, x10
    1a44:      	ldp	q3, q30, [x11]
    1a48:      	and.16b	v3, v1, v3
    1a4c:      	fmul.4s	v2, v2, v3
    1a50:      	add	x11, x16, x10
    1a54:      	ldp	q3, q31, [x11]
    1a58:      	and.16b	v3, v1, v3
    1a5c:      	fadd.4s	v8, v2, v3
    1a60:      	add	x10, x9, x10
    1a64:      	tbnz	w12, #0x0, 0x1aac <_llm_rows.packet_batch.blocks+0x1648>
    1a68:      	and	w11, w12, #0xff
    1a6c:      	tbnz	w11, #0x1, 0x1ab8 <_llm_rows.packet_batch.blocks+0x1654>
    1a70:      	tbnz	w11, #0x2, 0x1ac4 <_llm_rows.packet_batch.blocks+0x1660>
    1a74:      	tbz	w11, #0x3, 0x1a80 <_llm_rows.packet_batch.blocks+0x161c>
    1a78:      	add	x12, x10, #0xc
    1a7c:      	st1.s	{ v8 }[3], [x12]
    1a80:      	and.16b	v2, v0, v29
    1a84:      	fdiv.4s	v2, v2, v7
    1a88:      	and.16b	v3, v0, v30
    1a8c:      	fmul.4s	v2, v2, v3
    1a90:      	and.16b	v3, v0, v31
    1a94:      	fadd.4s	v29, v2, v3
    1a98:      	tbnz	w11, #0x4, 0x1ad4 <_llm_rows.packet_batch.blocks+0x1670>
    1a9c:      	tbnz	w11, #0x5, 0x1adc <_llm_rows.packet_batch.blocks+0x1678>
    1aa0:      	tbnz	w11, #0x6, 0x1ae8 <_llm_rows.packet_batch.blocks+0x1684>
    1aa4:      	tbz	w11, #0x7, 0x1a04 <_llm_rows.packet_batch.blocks+0x15a0>
    1aa8:      	b	0x1af4 <_llm_rows.packet_batch.blocks+0x1690>
    1aac:      	str	s8, [x10]
    1ab0:      	and	w11, w12, #0xff
    1ab4:      	tbz	w11, #0x1, 0x1a70 <_llm_rows.packet_batch.blocks+0x160c>
    1ab8:      	add	x12, x10, #0x4
    1abc:      	st1.s	{ v8 }[1], [x12]
    1ac0:      	tbz	w11, #0x2, 0x1a74 <_llm_rows.packet_batch.blocks+0x1610>
    1ac4:      	add	x12, x10, #0x8
    1ac8:      	st1.s	{ v8 }[2], [x12]
    1acc:      	tbnz	w11, #0x3, 0x1a78 <_llm_rows.packet_batch.blocks+0x1614>
    1ad0:      	b	0x1a80 <_llm_rows.packet_batch.blocks+0x161c>
    1ad4:      	str	s29, [x10, #0x10]
    1ad8:      	tbz	w11, #0x5, 0x1aa0 <_llm_rows.packet_batch.blocks+0x163c>
    1adc:      	add	x12, x10, #0x14
    1ae0:      	st1.s	{ v29 }[1], [x12]
    1ae4:      	tbz	w11, #0x6, 0x1aa4 <_llm_rows.packet_batch.blocks+0x1640>
    1ae8:      	add	x12, x10, #0x18
    1aec:      	st1.s	{ v29 }[2], [x12]
    1af0:      	tbz	w11, #0x7, 0x1a04 <_llm_rows.packet_batch.blocks+0x15a0>
    1af4:      	add	x10, x10, #0x1c
    1af8:      	st1.s	{ v29 }[3], [x10]
    1afc:      	b	0x1a04 <_llm_rows.packet_batch.blocks+0x15a0>
    1b00:      	fdiv.4s	v0, v21, v7
    1b04:      	fdiv.4s	v1, v20, v7
    1b08:      	fmul.4s	v1, v1, v24
    1b0c:      	fmul.4s	v0, v0, v23
    1b10:      	fadd.4s	v2, v0, v4
    1b14:      	fadd.4s	v0, v1, v5
    1b18:      	ldr	w12, [sp, #0x178]
    1b1c:      	ldr	q3, [sp, #0x140]
    1b20:      	ldp	q4, q5, [sp, #0x110]
    1b24:      	stp	q3, q4, [sp, #0x1b0]
    1b28:      	ldr	q1, [sp, #0x100]
    1b2c:      	stp	q5, q1, [sp, #0x1d0]
    1b30:      	and	x9, x2, #0x7
    1b34:      	add	x8, sp, #0x1b0
    1b38:      	ldr	x9, [x8, x9, lsl #3]
    1b3c:      	sub	x9, x9, x2
    1b40:      	add	x8, x1, x9, lsl #2
    1b44:      	fmov	w9, s22
    1b48:      	tbnz	w9, #0x0, 0x1b6c <_llm_rows.packet_batch.blocks+0x1708>
    1b4c:      	tbnz	w9, #0x1, 0x1b74 <_llm_rows.packet_batch.blocks+0x1710>
    1b50:      	tbnz	w9, #0x2, 0x1b80 <_llm_rows.packet_batch.blocks+0x171c>
    1b54:      	tbnz	w9, #0x3, 0x1b8c <_llm_rows.packet_batch.blocks+0x1728>
    1b58:      	tbnz	w9, #0x4, 0x1b98 <_llm_rows.packet_batch.blocks+0x1734>
    1b5c:      	tbnz	w9, #0x5, 0x1ba0 <_llm_rows.packet_batch.blocks+0x173c>
    1b60:      	tbnz	w9, #0x6, 0x1bac <_llm_rows.packet_batch.blocks+0x1748>
    1b64:      	tbz	w9, #0x7, 0x4f8 <_llm_rows.packet_batch.blocks+0x94>
    1b68:      	b	0x1bb8 <_llm_rows.packet_batch.blocks+0x1754>
    1b6c:      	str	s2, [x8]
    1b70:      	tbz	w9, #0x1, 0x1b50 <_llm_rows.packet_batch.blocks+0x16ec>
    1b74:      	add	x10, x8, #0x4
    1b78:      	st1.s	{ v2 }[1], [x10]
    1b7c:      	tbz	w9, #0x2, 0x1b54 <_llm_rows.packet_batch.blocks+0x16f0>
    1b80:      	add	x10, x8, #0x8
    1b84:      	st1.s	{ v2 }[2], [x10]
    1b88:      	tbz	w9, #0x3, 0x1b58 <_llm_rows.packet_batch.blocks+0x16f4>
    1b8c:      	add	x10, x8, #0xc
    1b90:      	st1.s	{ v2 }[3], [x10]
    1b94:      	tbz	w9, #0x4, 0x1b5c <_llm_rows.packet_batch.blocks+0x16f8>
    1b98:      	str	s0, [x8, #0x10]
    1b9c:      	tbz	w9, #0x5, 0x1b60 <_llm_rows.packet_batch.blocks+0x16fc>
    1ba0:      	add	x10, x8, #0x14
    1ba4:      	st1.s	{ v0 }[1], [x10]
    1ba8:      	tbz	w9, #0x6, 0x1b64 <_llm_rows.packet_batch.blocks+0x1700>
    1bac:      	add	x10, x8, #0x18
    1bb0:      	st1.s	{ v0 }[2], [x10]
    1bb4:      	tbz	w9, #0x7, 0x4f8 <_llm_rows.packet_batch.blocks+0x94>
    1bb8:      	add	x8, x8, #0x1c
    1bbc:      	st1.s	{ v0 }[3], [x8]
    1bc0:      	b	0x4f8 <_llm_rows.packet_batch.blocks+0x94>
    1bc4:      	ldr	s0, [x9]
    1bc8:      	ldr	w12, [sp, #0x178]
    1bcc:      	tbz	w10, #0x1, 0x1878 <_llm_rows.packet_batch.blocks+0x1414>
    1bd0:      	add	x11, x9, #0x4
    1bd4:      	ld1.s	{ v0 }[1], [x11]
    1bd8:      	tbz	w10, #0x2, 0x187c <_llm_rows.packet_batch.blocks+0x1418>
    1bdc:      	add	x11, x9, #0x8
    1be0:      	ld1.s	{ v0 }[2], [x11]
    1be4:      	tbz	w10, #0x3, 0x1880 <_llm_rows.packet_batch.blocks+0x141c>
    1be8:      	add	x11, x9, #0xc
    1bec:      	ld1.s	{ v0 }[3], [x11]
    1bf0:      	tbz	w10, #0x4, 0x1884 <_llm_rows.packet_batch.blocks+0x1420>
    1bf4:      	add	x11, x9, #0x10
    1bf8:      	ld1.s	{ v1 }[0], [x11]
    1bfc:      	tbz	w10, #0x5, 0x1888 <_llm_rows.packet_batch.blocks+0x1424>
    1c00:      	add	x11, x9, #0x14
    1c04:      	ld1.s	{ v1 }[1], [x11]
    1c08:      	tbz	w10, #0x6, 0x188c <_llm_rows.packet_batch.blocks+0x1428>
    1c0c:      	add	x11, x9, #0x18
    1c10:      	ld1.s	{ v1 }[2], [x11]
    1c14:      	tbnz	w10, #0x7, 0x1890 <_llm_rows.packet_batch.blocks+0x142c>
    1c18:      	b	0x1898 <_llm_rows.packet_batch.blocks+0x1434>
    1c1c:      	ldr	s4, [x9]
    1c20:      	tbz	w11, #0x1, 0x1990 <_llm_rows.packet_batch.blocks+0x152c>
    1c24:      	add	x10, x9, #0x4
    1c28:      	ld1.s	{ v4 }[1], [x10]
    1c2c:      	tbz	w11, #0x2, 0x1994 <_llm_rows.packet_batch.blocks+0x1530>
    1c30:      	add	x10, x9, #0x8
    1c34:      	ld1.s	{ v4 }[2], [x10]
    1c38:      	tbz	w11, #0x3, 0x1998 <_llm_rows.packet_batch.blocks+0x1534>
    1c3c:      	add	x10, x9, #0xc
    1c40:      	ld1.s	{ v4 }[3], [x10]
    1c44:      	tbz	w11, #0x4, 0x199c <_llm_rows.packet_batch.blocks+0x1538>
    1c48:      	add	x10, x9, #0x10
    1c4c:      	ld1.s	{ v5 }[0], [x10]
    1c50:      	tbz	w11, #0x5, 0x19a0 <_llm_rows.packet_batch.blocks+0x153c>
    1c54:      	add	x10, x9, #0x14
    1c58:      	ld1.s	{ v5 }[1], [x10]
    1c5c:      	tbz	w11, #0x6, 0x19a4 <_llm_rows.packet_batch.blocks+0x1540>
    1c60:      	add	x10, x9, #0x18
    1c64:      	ld1.s	{ v5 }[2], [x10]
    1c68:      	tbnz	w11, #0x7, 0x19a8 <_llm_rows.packet_batch.blocks+0x1544>
    1c6c:      	b	0x19b0 <_llm_rows.packet_batch.blocks+0x154c>
    1c70:      	add	sp, sp, #0xa80
    1c74:      	ldp	x29, x30, [sp, #0x90]
    1c78:      	ldp	x20, x19, [sp, #0x80]
    1c7c:      	ldp	x22, x21, [sp, #0x70]
    1c80:      	ldp	x24, x23, [sp, #0x60]
    1c84:      	ldp	x26, x25, [sp, #0x50]
    1c88:      	ldp	x28, x27, [sp, #0x40]
    1c8c:      	ldp	d9, d8, [sp, #0x30]
    1c90:      	ldp	d11, d10, [sp, #0x20]
    1c94:      	ldp	d13, d12, [sp, #0x10]
    1c98:      	ldp	d15, d14, [sp], #0xa0
    1c9c:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/rope-257x1538/on/object/tile_xir_w8_38094_1788936548463397_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x28, x27, [sp, #-0x60]!
       4:      	stp	x26, x25, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	stp	x29, x30, [sp, #0x50]
      18:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      1c:      	sub	sp, sp, #0xc0
      20:      	ldr	x24, [x0]
      24:      	ldr	x23, [x0, #0x10]
      28:      	ldr	x21, [x0, #0x20]
      2c:      	ldr	x20, [x0, #0x30]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w22, w8, #3
      40:      	subs	x8, x24, x20
      44:      	mov	w9, #0x2007             ; =8199
      48:      	movk	w9, #0x18, lsl #16
      4c:      	ccmp	x8, x9, #0x0, hs
      50:      	cset	w8, hi
      54:      	subs	x10, x20, x24
      58:      	ccmp	x10, x9, #0x0, hs
      5c:      	csinc	w10, w8, wzr, ls
      60:      	subs	x8, x23, x20
      64:      	ccmp	x8, x9, #0x0, hs
      68:      	cset	w8, hi
      6c:      	subs	x11, x20, x23
      70:      	mov	w12, #0x1003            ; =4099
      74:      	movk	w12, #0xc, lsl #16
      78:      	ccmp	x11, x12, #0x0, hs
      7c:      	csinc	w8, w8, wzr, ls
      80:      	subs	x11, x21, x20
      84:      	ccmp	x11, x9, #0x0, hs
      88:      	cset	w9, hi
      8c:      	subs	x11, x20, x21
      90:      	ccmp	x11, x12, #0x0, hs
      94:      	csinc	w9, w9, wzr, ls
      98:      	cmp	w9, #0x1
      9c:      	ccmp	w10, #0x0, #0x4, eq
      a0:      	b.eq	0x17c <ltmp0+0x17c>
      a4:      	tbz	w8, #0x0, 0x17c <ltmp0+0x17c>
      a8:      	mov	x8, #0x0                ; =0
      ac:      	mov	w10, #0xc04             ; =3076
      b0:      	umaddl	x9, w22, w10, x23
      b4:      	umaddl	x10, w22, w10, x21
      b8:      	mov	w12, #0x1808            ; =6152
      bc:      	umaddl	x11, w22, w12, x24
      c0:      	umaddl	x12, w22, w12, x20
      c4:      	add	x13, x11, x8
      c8:      	ldp	q1, q0, [x13]
      cc:      	add	x13, x13, #0xc04
      d0:      	ldp	q3, q2, [x13]
      d4:      	add	x13, x9, x8
      d8:      	ldp	q5, q4, [x13]
      dc:      	add	x13, x10, x8
      e0:      	ldp	q7, q6, [x13]
      e4:      	fmul.4s	v16, v1, v5
      e8:      	fmul.4s	v17, v0, v4
      ec:      	fmul.4s	v18, v3, v7
      f0:      	fmul.4s	v19, v2, v6
      f4:      	fsub.4s	v17, v17, v19
      f8:      	fsub.4s	v16, v16, v18
      fc:      	add	x13, x12, x8
     100:      	stp	q16, q17, [x13]
     104:      	fmul.4s	v1, v1, v7
     108:      	fmul.4s	v0, v0, v6
     10c:      	fmul.4s	v3, v3, v5
     110:      	fmul.4s	v2, v2, v4
     114:      	fadd.4s	v0, v2, v0
     118:      	fadd.4s	v1, v3, v1
     11c:      	add	x13, x13, #0xc04
     120:      	stp	q1, q0, [x13]
     124:      	add	x8, x8, #0x20
     128:      	cmp	x8, #0xc00
     12c:      	b.ne	0xc4 <ltmp0+0xc4>
     130:      	mov	w8, #0x1808             ; =6152
     134:      	umull	x9, w22, w8
     138:      	add	x9, x9, #0xc00
     13c:      	ldr	s0, [x24, x9]
     140:      	mov	w10, #0x1804            ; =6148
     144:      	umaddl	x19, w22, w8, x10
     148:      	ldr	s1, [x24, x19]
     14c:      	mov	w8, #0xc04              ; =3076
     150:      	umull	x8, w22, w8
     154:      	add	x8, x8, #0xc00
     158:      	ldr	s2, [x23, x8]
     15c:      	ldr	s3, [x21, x8]
     160:      	fmul.4s	v4, v0, v2
     164:      	fmul.4s	v5, v1, v3
     168:      	fsub.4s	v4, v4, v5
     16c:      	str	s4, [x20, x9]
     170:      	fmul.4s	v0, v0, v3
     174:      	fmul.4s	v1, v1, v2
     178:      	b	0x31c <ltmp0+0x31c>
     17c:      	mov	w8, #0x1808             ; =6152
     180:      	umull	x25, w22, w8
     184:      	umaddl	x19, w22, w8, x24
     188:      	mov	w28, #0x1808            ; =6152
     18c:      	add	x26, sp, #0x2, lsl #12  ; =0x2000
     190:      	add	x26, x26, #0x4a0
     194:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     198:      	add	x0, x0, #0x4a0
     19c:      	mov	x1, x19
     1a0:      	mov	w2, #0xc00              ; =3072
     1a4:      	bl	0x1a4 <ltmp0+0x1a4>
     1a8:      	add	x8, x25, #0xc00
     1ac:      	str	x8, [sp, #0x8]
     1b0:      	ldr	s0, [x24, x8]
     1b4:      	str	q0, [sp, #0x30]
     1b8:      	str	q0, [sp, #0x30a0]
     1bc:      	add	x27, sp, #0x1, lsl #12  ; =0x1000
     1c0:      	add	x27, x27, #0x880
     1c4:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     1c8:      	add	x0, x0, #0x880
     1cc:      	add	x1, x19, #0xc04
     1d0:      	mov	w2, #0xc00              ; =3072
     1d4:      	bl	0x1d4 <ltmp0+0x1d4>
     1d8:      	mov	w8, #0x1804             ; =6148
     1dc:      	umaddl	x19, w22, w28, x8
     1e0:      	ldr	s0, [x24, x19]
     1e4:      	str	q0, [sp, #0x20]
     1e8:      	str	q0, [sp, #0x2480]
     1ec:      	mov	w25, #0xc04             ; =3076
     1f0:      	umull	x28, w22, w25
     1f4:      	umaddl	x1, w22, w25, x23
     1f8:      	add	x24, sp, #0xc60
     1fc:      	add	x0, sp, #0xc60
     200:      	mov	w2, #0xc00              ; =3072
     204:      	bl	0x204 <ltmp0+0x204>
     208:      	add	x28, x28, #0xc00
     20c:      	ldr	s0, [x23, x28]
     210:      	str	q0, [sp, #0x10]
     214:      	str	q0, [sp, #0x1860]
     218:      	umaddl	x1, w22, w25, x21
     21c:      	add	x23, sp, #0x40
     220:      	add	x0, sp, #0x40
     224:      	mov	w2, #0xc00              ; =3072
     228:      	bl	0x228 <ltmp0+0x228>
     22c:      	mov	x8, #0x0                ; =0
     230:      	ldr	s0, [x21, x28]
     234:      	str	q0, [sp, #0xc40]
     238:      	mov	w9, #0x1808             ; =6152
     23c:      	umaddl	x9, w22, w9, x20
     240:      	add	x10, x26, x8
     244:      	ldp	q1, q2, [x10]
     248:      	add	x10, x24, x8
     24c:      	ldp	q3, q4, [x10]
     250:      	fmul.4s	v2, v2, v4
     254:      	fmul.4s	v1, v1, v3
     258:      	add	x10, x27, x8
     25c:      	ldp	q3, q4, [x10]
     260:      	add	x10, x23, x8
     264:      	ldp	q5, q6, [x10]
     268:      	fmul.4s	v4, v4, v6
     26c:      	fmul.4s	v3, v3, v5
     270:      	fsub.4s	v1, v1, v3
     274:      	fsub.4s	v2, v2, v4
     278:      	add	x10, x9, x8
     27c:      	stp	q1, q2, [x10]
     280:      	add	x8, x8, #0x20
     284:      	cmp	x8, #0xc00
     288:      	b.ne	0x240 <ltmp0+0x240>
     28c:      	mov	x8, #0x0                ; =0
     290:      	ldp	q16, q7, [sp, #0x20]
     294:      	ldr	q17, [sp, #0x10]
     298:      	fmul.4s	v1, v7, v17
     29c:      	fmul.4s	v2, v16, v0
     2a0:      	fsub.4s	v1, v1, v2
     2a4:      	ldr	x10, [sp, #0x8]
     2a8:      	str	s1, [x20, x10]
     2ac:      	add	x9, x9, #0xc04
     2b0:      	add	x10, sp, #0x2, lsl #12  ; =0x2000
     2b4:      	add	x10, x10, #0x4a0
     2b8:      	add	x11, sp, #0x40
     2bc:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
     2c0:      	add	x12, x12, #0x880
     2c4:      	add	x13, sp, #0xc60
     2c8:      	add	x14, x10, x8
     2cc:      	ldp	q1, q2, [x14]
     2d0:      	add	x14, x11, x8
     2d4:      	ldp	q3, q4, [x14]
     2d8:      	fmul.4s	v2, v2, v4
     2dc:      	fmul.4s	v1, v1, v3
     2e0:      	add	x14, x12, x8
     2e4:      	ldp	q3, q4, [x14]
     2e8:      	add	x14, x13, x8
     2ec:      	ldp	q5, q6, [x14]
     2f0:      	fmul.4s	v4, v4, v6
     2f4:      	fmul.4s	v3, v3, v5
     2f8:      	fadd.4s	v1, v1, v3
     2fc:      	fadd.4s	v2, v2, v4
     300:      	add	x14, x9, x8
     304:      	stp	q1, q2, [x14]
     308:      	add	x8, x8, #0x20
     30c:      	cmp	x8, #0xc00
     310:      	b.ne	0x2c8 <ltmp0+0x2c8>
     314:      	fmul.4s	v0, v7, v0
     318:      	fmul.4s	v1, v16, v17
     31c:      	fadd.4s	v0, v1, v0
     320:      	str	s0, [x20, x19]
     324:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
     328:      	add	sp, sp, #0xc0
     32c:      	ldp	x29, x30, [sp, #0x50]
     330:      	ldp	x20, x19, [sp, #0x40]
     334:      	ldp	x22, x21, [sp, #0x30]
     338:      	ldp	x24, x23, [sp, #0x20]
     33c:      	ldp	x26, x25, [sp, #0x10]
     340:      	ldp	x28, x27, [sp], #0x60
     344:      	ret

0000000000000348 <_llm_rows.packet_batch.blocks>:
     348:      	stp	d15, d14, [sp, #-0xa0]!
     34c:      	stp	d13, d12, [sp, #0x10]
     350:      	stp	d11, d10, [sp, #0x20]
     354:      	stp	d9, d8, [sp, #0x30]
     358:      	stp	x28, x27, [sp, #0x40]
     35c:      	stp	x26, x25, [sp, #0x50]
     360:      	stp	x24, x23, [sp, #0x60]
     364:      	stp	x22, x21, [sp, #0x70]
     368:      	stp	x20, x19, [sp, #0x80]
     36c:      	stp	x29, x30, [sp, #0x90]
     370:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
     374:      	sub	sp, sp, #0x4e0
     378:      	str	x0, [sp, #0x138]
     37c:      	cbz	w3, 0x1e14 <_llm_rows.packet_batch.blocks+0x1acc>
     380:      	mov	x24, x3
     384:      	mov	x20, x2
     388:      	mov	w22, #0x0               ; =0
     38c:      	ldp	w9, w8, [x2, #0x2c]
     390:      	str	w9, [sp, #0x11c]
     394:      	str	w8, [sp, #0x118]
     398:      	mov	w9, #0x602              ; =1538
     39c:      	ldp	w28, w23, [x2]
     3a0:      	ldp	w25, w8, [x2, #0x8]
     3a4:      	str	x8, [sp, #0x110]
     3a8:      	adrp	x8, 0x0 <ltmp0>
     3ac:      	ldr	q0, [x8]
     3b0:      	str	q0, [sp, #0xf0]
     3b4:      	adrp	x8, 0x0 <ltmp0>
     3b8:      	ldr	q0, [x8]
     3bc:      	str	q0, [sp, #0xe0]
     3c0:      	adrp	x8, 0x0 <ltmp0>
     3c4:      	ldr	q0, [x8]
     3c8:      	str	q0, [sp, #0xb0]
     3cc:      	adrp	x8, 0x0 <ltmp0>
     3d0:      	ldr	q0, [x8]
     3d4:      	str	q0, [sp, #0xa0]
     3d8:      	adrp	x8, 0x0 <ltmp0>
     3dc:      	ldr	q0, [x8]
     3e0:      	str	q0, [sp, #0x90]
     3e4:      	adrp	x8, 0x0 <ltmp0>
     3e8:      	ldr	q0, [x8]
     3ec:      	str	q0, [sp, #0x80]
     3f0:      	dup.2s	v12, w9
     3f4:      	adrp	x8, 0x0 <ltmp0>
     3f8:      	ldr	q10, [x8]
     3fc:      	add	x27, sp, #0x1, lsl #12  ; =0x1000
     400:      	add	x27, x27, #0xca0
     404:      	add	x19, sp, #0x1, lsl #12  ; =0x1000
     408:      	add	x19, x19, #0x80
     40c:      	add	x21, sp, #0x460
     410:      	str	q10, [sp, #0x120]
     414:      	str	w3, [sp, #0x10c]
     418:      	str	d12, [sp, #0x8]
     41c:      	b	0x468 <_llm_rows.packet_batch.blocks+0x120>
     420:      	mov	w8, #0x18               ; =24
     424:      	str	w8, [x20, #0x24]
     428:      	ldr	w24, [sp, #0x10c]
     42c:      	add	w8, w28, #0x1
     430:      	ldr	w9, [sp, #0x11c]
     434:      	cmp	w8, w9
     438:      	cset	w8, eq
     43c:      	csinc	w28, wzr, w28, eq
     440:      	cinc	w9, w23, eq
     444:      	ldr	w10, [sp, #0x118]
     448:      	cmp	w9, w10
     44c:      	cset	w10, eq
     450:      	ands	w8, w8, w10
     454:      	csel	w23, wzr, w9, ne
     458:      	add	w25, w25, w8
     45c:      	add	w22, w22, #0x1
     460:      	cmp	w22, w24
     464:      	b.eq	0x1e14 <_llm_rows.packet_batch.blocks+0x1acc>
     468:      	ubfiz	x8, x28, #5, #32
     46c:      	ldr	x12, [sp, #0x110]
     470:      	cmp	x8, x12
     474:      	csel	x9, x8, xzr, ls
     478:      	subs	x10, x12, x9
     47c:      	cmp	x10, #0x20
     480:      	mov	w11, #0x20              ; =32
     484:      	csel	x10, x10, x11, lo
     488:      	cmp	x12, x9
     48c:      	stp	w28, w23, [x20]
     490:      	str	w25, [x20, #0x8]
     494:      	str	wzr, [x20, #0x24]
     498:      	ccmp	x8, x12, #0x2, hi
     49c:      	csel	x26, x10, xzr, ls
     4a0:      	cmp	x26, #0x20
     4a4:      	b.lo	0x4fc <_llm_rows.packet_batch.blocks+0x1b4>
     4a8:      	ldr	x26, [sp, #0x138]
     4ac:      	mov	x0, x26
     4b0:      	mov	x1, x20
     4b4:      	bl	0x4b4 <_llm_rows.packet_batch.blocks+0x16c>
     4b8:      	mov	w8, #0x8                ; =8
     4bc:      	str	w8, [x20, #0x24]
     4c0:      	mov	x0, x26
     4c4:      	mov	x1, x20
     4c8:      	bl	0x4c8 <_llm_rows.packet_batch.blocks+0x180>
     4cc:      	mov	w8, #0x10               ; =16
     4d0:      	str	w8, [x20, #0x24]
     4d4:      	mov	x0, x26
     4d8:      	mov	x1, x20
     4dc:      	bl	0x4dc <_llm_rows.packet_batch.blocks+0x194>
     4e0:      	mov	w8, #0x18               ; =24
     4e4:      	str	w8, [x20, #0x24]
     4e8:      	mov	x0, x26
     4ec:      	mov	x1, x20
     4f0:      	bl	0x4f0 <_llm_rows.packet_batch.blocks+0x1a8>
     4f4:      	ldr	q10, [sp, #0x120]
     4f8:      	b	0x42c <_llm_rows.packet_batch.blocks+0xe4>
     4fc:      	lsr	x24, x26, #3
     500:      	cmp	x26, #0x8
     504:      	b.lo	0x55c <_llm_rows.packet_batch.blocks+0x214>
     508:      	str	wzr, [x20, #0x24]
     50c:      	ldr	x0, [sp, #0x138]
     510:      	mov	x1, x20
     514:      	bl	0x514 <_llm_rows.packet_batch.blocks+0x1cc>
     518:      	ldr	q10, [sp, #0x120]
     51c:      	cmp	x24, #0x1
     520:      	b.eq	0x55c <_llm_rows.packet_batch.blocks+0x214>
     524:      	mov	w8, #0x8                ; =8
     528:      	str	w8, [x20, #0x24]
     52c:      	ldr	x0, [sp, #0x138]
     530:      	mov	x1, x20
     534:      	bl	0x534 <_llm_rows.packet_batch.blocks+0x1ec>
     538:      	ldr	q10, [sp, #0x120]
     53c:      	cmp	x24, #0x2
     540:      	b.eq	0x55c <_llm_rows.packet_batch.blocks+0x214>
     544:      	mov	w8, #0x10               ; =16
     548:      	str	w8, [x20, #0x24]
     54c:      	ldr	x0, [sp, #0x138]
     550:      	mov	x1, x20
     554:      	bl	0x554 <_llm_rows.packet_batch.blocks+0x20c>
     558:      	ldr	q10, [sp, #0x120]
     55c:      	and	w8, w26, #0x7
     560:      	cbz	w8, 0x420 <_llm_rows.packet_batch.blocks+0xd8>
     564:      	dup.4s	v1, w8
     568:      	ldp	q2, q0, [sp, #0xe0]
     56c:      	cmhi.4s	v6, v1, v2
     570:      	cmhi.4s	v0, v1, v0
     574:      	uzp1.8h	v22, v0, v6
     578:      	umaxv.8h	h2, v22
     57c:      	fmov	w8, s2
     580:      	tbz	w8, #0x0, 0x420 <_llm_rows.packet_batch.blocks+0xd8>
     584:      	ldr	x8, [sp, #0x138]
     588:      	ldr	x12, [x8]
     58c:      	ldr	x10, [x8, #0x10]
     590:      	ldr	x9, [x8, #0x20]
     594:      	ldr	x8, [x8, #0x30]
     598:      	sshll.2d	v2, v0, #0x0
     59c:      	sshll.2d	v3, v6, #0x0
     5a0:      	sshll2.2d	v23, v0, #0x0
     5a4:      	sshll2.2d	v21, v6, #0x0
     5a8:      	ldp	q4, q5, [sp, #0xa0]
     5ac:      	and.16b	v16, v21, v5
     5b0:      	and.16b	v13, v23, v4
     5b4:      	ldr	q4, [sp, #0x90]
     5b8:      	and.16b	v8, v3, v4
     5bc:      	ldr	q3, [sp, #0x80]
     5c0:      	and.16b	v20, v2, v3
     5c4:      	ubfiz	w11, w28, #2, #27
     5c8:      	orr	w14, w11, w24
     5cc:      	dup.4s	v2, w14
     5d0:      	and.16b	v3, v0, v2
     5d4:      	and.16b	v2, v6, v2
     5d8:      	ushll2.2d	v5, v2, #0x0
     5dc:      	ushll2.2d	v4, v3, #0x0
     5e0:      	ushll.2d	v2, v2, #0x0
     5e4:      	ushll.2d	v3, v3, #0x0
     5e8:      	subs	x11, x12, x8
     5ec:      	mov	w16, #0x2007            ; =8199
     5f0:      	movk	w16, #0x18, lsl #16
     5f4:      	ccmp	x11, x16, #0x0, hs
     5f8:      	cset	w11, hi
     5fc:      	subs	x13, x8, x12
     600:      	ccmp	x13, x16, #0x0, hs
     604:      	csinc	w11, w11, wzr, ls
     608:      	subs	x13, x10, x8
     60c:      	ccmp	x13, x16, #0x0, hs
     610:      	cset	w13, hi
     614:      	subs	x15, x8, x10
     618:      	mov	w17, #0x1003            ; =4099
     61c:      	movk	w17, #0xc, lsl #16
     620:      	ccmp	x15, x17, #0x0, hs
     624:      	csinc	w13, w13, wzr, ls
     628:      	subs	x15, x9, x8
     62c:      	ccmp	x15, x16, #0x0, hs
     630:      	cset	w15, hi
     634:      	subs	x16, x8, x9
     638:      	ccmp	x16, x17, #0x0, hs
     63c:      	csinc	w15, w15, wzr, ls
     640:      	xtn.2s	v15, v3
     644:      	xtn.2s	v11, v4
     648:      	xtn.2s	v4, v2
     64c:      	xtn.2s	v5, v5
     650:      	mov	w16, #0x301             ; =769
     654:      	dup.2s	v2, w16
     658:      	cmp	w15, #0x1
     65c:      	b.ne	0x1054 <_llm_rows.packet_batch.blocks+0xd0c>
     660:      	cbz	w11, 0x1054 <_llm_rows.packet_batch.blocks+0xd0c>
     664:      	tbz	w13, #0x0, 0x1054 <_llm_rows.packet_batch.blocks+0xd0c>
     668:      	mov	x11, #0x0               ; =0
     66c:      	umull.2d	v21, v15, v12
     670:      	umull.2d	v6, v11, v12
     674:      	umull.2d	v19, v4, v12
     678:      	umull.2d	v7, v5, v12
     67c:      	fmov	w13, s1
     680:      	cmp	w13, #0x0
     684:      	cset	w13, ne
     688:      	mov	w15, #0x602             ; =1538
     68c:      	umull	x15, w14, w15
     690:      	add	x16, x15, #0x301
     694:      	mov	w0, #0x301              ; =769
     698:      	csel	x17, x16, x0, ne
     69c:      	umull	x14, w14, w0
     6a0:      	csel	x14, x14, xzr, ne
     6a4:      	lsl	x16, x14, #2
     6a8:      	add	x14, x9, x16
     6ac:      	add	x16, x10, x16
     6b0:      	lsl	x0, x17, #2
     6b4:      	add	x17, x8, x0
     6b8:      	add	x0, x12, x0
     6bc:      	and.16b	v1, v22, v10
     6c0:      	addv.8h	h22, v1
     6c4:      	fmov	w1, s22
     6c8:      	b	0x6e8 <_llm_rows.packet_batch.blocks+0x3a0>
     6cc:      	add	x11, x11, #0x8
     6d0:      	add	x14, x14, #0x20
     6d4:      	add	x16, x16, #0x20
     6d8:      	add	x17, x17, #0x20
     6dc:      	add	x0, x0, #0x20
     6e0:      	cmp	x11, #0x300
     6e4:      	b.eq	0xad8 <_llm_rows.packet_batch.blocks+0x790>
     6e8:      	cmp	w13, #0x0
     6ec:      	csel	x2, x15, xzr, ne
     6f0:      	add	x2, x2, x11
     6f4:      	lsl	x2, x2, #2
     6f8:      	add	x3, x12, x2
     6fc:      	movi.2d	v24, #0000000000000000
     700:      	movi.2d	v23, #0000000000000000
     704:      	tbz	w1, #0x0, 0x8e0 <_llm_rows.packet_batch.blocks+0x598>
     708:      	ldr	s24, [x3]
     70c:      	and	w4, w1, #0xff
     710:      	tbnz	w4, #0x1, 0x8e8 <_llm_rows.packet_batch.blocks+0x5a0>
     714:      	tbz	w4, #0x2, 0x8f4 <_llm_rows.packet_batch.blocks+0x5ac>
     718:      	add	x5, x3, #0x8
     71c:      	ld1.s	{ v24 }[2], [x5]
     720:      	tbnz	w4, #0x3, 0x8f8 <_llm_rows.packet_batch.blocks+0x5b0>
     724:      	tbz	w4, #0x4, 0x904 <_llm_rows.packet_batch.blocks+0x5bc>
     728:      	add	x5, x3, #0x10
     72c:      	ld1.s	{ v23 }[0], [x5]
     730:      	tbnz	w4, #0x5, 0x908 <_llm_rows.packet_batch.blocks+0x5c0>
     734:      	tbz	w4, #0x6, 0x914 <_llm_rows.packet_batch.blocks+0x5cc>
     738:      	add	x5, x3, #0x18
     73c:      	ld1.s	{ v23 }[2], [x5]
     740:      	tbnz	w4, #0x7, 0x918 <_llm_rows.packet_batch.blocks+0x5d0>
     744:      	fmov	w3, s22
     748:      	movi.2d	v26, #0000000000000000
     74c:      	movi.2d	v25, #0000000000000000
     750:      	tbz	w3, #0x0, 0x930 <_llm_rows.packet_batch.blocks+0x5e8>
     754:      	ldr	s26, [x0]
     758:      	and	w3, w3, #0xff
     75c:      	tbnz	w3, #0x1, 0x938 <_llm_rows.packet_batch.blocks+0x5f0>
     760:      	tbz	w3, #0x2, 0x944 <_llm_rows.packet_batch.blocks+0x5fc>
     764:      	add	x4, x0, #0x8
     768:      	ld1.s	{ v26 }[2], [x4]
     76c:      	tbnz	w3, #0x3, 0x948 <_llm_rows.packet_batch.blocks+0x600>
     770:      	tbz	w3, #0x4, 0x954 <_llm_rows.packet_batch.blocks+0x60c>
     774:      	add	x4, x0, #0x10
     778:      	ld1.s	{ v25 }[0], [x4]
     77c:      	tbnz	w3, #0x5, 0x958 <_llm_rows.packet_batch.blocks+0x610>
     780:      	tbz	w3, #0x6, 0x964 <_llm_rows.packet_batch.blocks+0x61c>
     784:      	add	x4, x0, #0x18
     788:      	ld1.s	{ v25 }[2], [x4]
     78c:      	tbnz	w3, #0x7, 0x968 <_llm_rows.packet_batch.blocks+0x620>
     790:      	fmov	w3, s22
     794:      	movi.2d	v28, #0000000000000000
     798:      	movi.2d	v27, #0000000000000000
     79c:      	tbz	w3, #0x0, 0x980 <_llm_rows.packet_batch.blocks+0x638>
     7a0:      	ldr	s28, [x16]
     7a4:      	and	w3, w3, #0xff
     7a8:      	tbnz	w3, #0x1, 0x988 <_llm_rows.packet_batch.blocks+0x640>
     7ac:      	tbz	w3, #0x2, 0x994 <_llm_rows.packet_batch.blocks+0x64c>
     7b0:      	add	x4, x16, #0x8
     7b4:      	ld1.s	{ v28 }[2], [x4]
     7b8:      	tbnz	w3, #0x3, 0x998 <_llm_rows.packet_batch.blocks+0x650>
     7bc:      	tbz	w3, #0x4, 0x9a4 <_llm_rows.packet_batch.blocks+0x65c>
     7c0:      	add	x4, x16, #0x10
     7c4:      	ld1.s	{ v27 }[0], [x4]
     7c8:      	tbnz	w3, #0x5, 0x9a8 <_llm_rows.packet_batch.blocks+0x660>
     7cc:      	tbz	w3, #0x6, 0x9b4 <_llm_rows.packet_batch.blocks+0x66c>
     7d0:      	add	x4, x16, #0x18
     7d4:      	ld1.s	{ v27 }[2], [x4]
     7d8:      	tbnz	w3, #0x7, 0x9b8 <_llm_rows.packet_batch.blocks+0x670>
     7dc:      	fmov	w3, s22
     7e0:      	movi.2d	v30, #0000000000000000
     7e4:      	movi.2d	v29, #0000000000000000
     7e8:      	tbz	w3, #0x0, 0x9d0 <_llm_rows.packet_batch.blocks+0x688>
     7ec:      	ldr	s30, [x14]
     7f0:      	and	w3, w3, #0xff
     7f4:      	tbnz	w3, #0x1, 0x9d8 <_llm_rows.packet_batch.blocks+0x690>
     7f8:      	tbz	w3, #0x2, 0x9e4 <_llm_rows.packet_batch.blocks+0x69c>
     7fc:      	add	x4, x14, #0x8
     800:      	ld1.s	{ v30 }[2], [x4]
     804:      	tbnz	w3, #0x3, 0x9e8 <_llm_rows.packet_batch.blocks+0x6a0>
     808:      	tbz	w3, #0x4, 0x9f4 <_llm_rows.packet_batch.blocks+0x6ac>
     80c:      	add	x4, x14, #0x10
     810:      	ld1.s	{ v29 }[0], [x4]
     814:      	tbnz	w3, #0x5, 0x9f8 <_llm_rows.packet_batch.blocks+0x6b0>
     818:      	tbz	w3, #0x6, 0xa04 <_llm_rows.packet_batch.blocks+0x6bc>
     81c:      	add	x4, x14, #0x18
     820:      	ld1.s	{ v29 }[2], [x4]
     824:      	tbnz	w3, #0x7, 0xa08 <_llm_rows.packet_batch.blocks+0x6c0>
     828:      	fmov	w3, s22
     82c:      	fmul.4s	v1, v24, v28
     830:      	fmul.4s	v3, v26, v30
     834:      	fsub.4s	v1, v1, v3
     838:      	add	x2, x8, x2
     83c:      	tbz	w3, #0x0, 0xa28 <_llm_rows.packet_batch.blocks+0x6e0>
     840:      	str	s1, [x2]
     844:      	and	w3, w3, #0xff
     848:      	tbnz	w3, #0x1, 0xa30 <_llm_rows.packet_batch.blocks+0x6e8>
     84c:      	tbz	w3, #0x2, 0xa3c <_llm_rows.packet_batch.blocks+0x6f4>
     850:      	add	x4, x2, #0x8
     854:      	st1.s	{ v1 }[2], [x4]
     858:      	tbnz	w3, #0x3, 0xa40 <_llm_rows.packet_batch.blocks+0x6f8>
     85c:      	fmul.4s	v1, v23, v27
     860:      	fmul.4s	v3, v25, v29
     864:      	fsub.4s	v1, v1, v3
     868:      	tbz	w3, #0x4, 0xa58 <_llm_rows.packet_batch.blocks+0x710>
     86c:      	str	s1, [x2, #0x10]
     870:      	tbnz	w3, #0x5, 0xa5c <_llm_rows.packet_batch.blocks+0x714>
     874:      	tbz	w3, #0x6, 0xa68 <_llm_rows.packet_batch.blocks+0x720>
     878:      	add	x4, x2, #0x18
     87c:      	st1.s	{ v1 }[2], [x4]
     880:      	tbnz	w3, #0x7, 0xa6c <_llm_rows.packet_batch.blocks+0x724>
     884:      	fmov	w2, s22
     888:      	fmul.4s	v1, v24, v30
     88c:      	fmul.4s	v3, v26, v28
     890:      	fadd.4s	v1, v3, v1
     894:      	tbz	w2, #0x0, 0xa88 <_llm_rows.packet_batch.blocks+0x740>
     898:      	str	s1, [x17]
     89c:      	and	w2, w2, #0xff
     8a0:      	tbnz	w2, #0x1, 0xa90 <_llm_rows.packet_batch.blocks+0x748>
     8a4:      	tbz	w2, #0x2, 0xa9c <_llm_rows.packet_batch.blocks+0x754>
     8a8:      	add	x3, x17, #0x8
     8ac:      	st1.s	{ v1 }[2], [x3]
     8b0:      	tbnz	w2, #0x3, 0xaa0 <_llm_rows.packet_batch.blocks+0x758>
     8b4:      	fmul.4s	v1, v23, v29
     8b8:      	fmul.4s	v3, v25, v27
     8bc:      	fadd.4s	v1, v3, v1
     8c0:      	tbz	w2, #0x4, 0xab8 <_llm_rows.packet_batch.blocks+0x770>
     8c4:      	str	s1, [x17, #0x10]
     8c8:      	tbnz	w2, #0x5, 0xabc <_llm_rows.packet_batch.blocks+0x774>
     8cc:      	tbz	w2, #0x6, 0xac8 <_llm_rows.packet_batch.blocks+0x780>
     8d0:      	add	x3, x17, #0x18
     8d4:      	st1.s	{ v1 }[2], [x3]
     8d8:      	tbz	w2, #0x7, 0x6cc <_llm_rows.packet_batch.blocks+0x384>
     8dc:      	b	0xacc <_llm_rows.packet_batch.blocks+0x784>
     8e0:      	and	w4, w1, #0xff
     8e4:      	tbz	w4, #0x1, 0x714 <_llm_rows.packet_batch.blocks+0x3cc>
     8e8:      	add	x5, x3, #0x4
     8ec:      	ld1.s	{ v24 }[1], [x5]
     8f0:      	tbnz	w4, #0x2, 0x718 <_llm_rows.packet_batch.blocks+0x3d0>
     8f4:      	tbz	w4, #0x3, 0x724 <_llm_rows.packet_batch.blocks+0x3dc>
     8f8:      	add	x5, x3, #0xc
     8fc:      	ld1.s	{ v24 }[3], [x5]
     900:      	tbnz	w4, #0x4, 0x728 <_llm_rows.packet_batch.blocks+0x3e0>
     904:      	tbz	w4, #0x5, 0x734 <_llm_rows.packet_batch.blocks+0x3ec>
     908:      	add	x5, x3, #0x14
     90c:      	ld1.s	{ v23 }[1], [x5]
     910:      	tbnz	w4, #0x6, 0x738 <_llm_rows.packet_batch.blocks+0x3f0>
     914:      	tbz	w4, #0x7, 0x744 <_llm_rows.packet_batch.blocks+0x3fc>
     918:      	add	x3, x3, #0x1c
     91c:      	ld1.s	{ v23 }[3], [x3]
     920:      	fmov	w3, s22
     924:      	movi.2d	v26, #0000000000000000
     928:      	movi.2d	v25, #0000000000000000
     92c:      	tbnz	w3, #0x0, 0x754 <_llm_rows.packet_batch.blocks+0x40c>
     930:      	and	w3, w3, #0xff
     934:      	tbz	w3, #0x1, 0x760 <_llm_rows.packet_batch.blocks+0x418>
     938:      	add	x4, x0, #0x4
     93c:      	ld1.s	{ v26 }[1], [x4]
     940:      	tbnz	w3, #0x2, 0x764 <_llm_rows.packet_batch.blocks+0x41c>
     944:      	tbz	w3, #0x3, 0x770 <_llm_rows.packet_batch.blocks+0x428>
     948:      	add	x4, x0, #0xc
     94c:      	ld1.s	{ v26 }[3], [x4]
     950:      	tbnz	w3, #0x4, 0x774 <_llm_rows.packet_batch.blocks+0x42c>
     954:      	tbz	w3, #0x5, 0x780 <_llm_rows.packet_batch.blocks+0x438>
     958:      	add	x4, x0, #0x14
     95c:      	ld1.s	{ v25 }[1], [x4]
     960:      	tbnz	w3, #0x6, 0x784 <_llm_rows.packet_batch.blocks+0x43c>
     964:      	tbz	w3, #0x7, 0x790 <_llm_rows.packet_batch.blocks+0x448>
     968:      	add	x3, x0, #0x1c
     96c:      	ld1.s	{ v25 }[3], [x3]
     970:      	fmov	w3, s22
     974:      	movi.2d	v28, #0000000000000000
     978:      	movi.2d	v27, #0000000000000000
     97c:      	tbnz	w3, #0x0, 0x7a0 <_llm_rows.packet_batch.blocks+0x458>
     980:      	and	w3, w3, #0xff
     984:      	tbz	w3, #0x1, 0x7ac <_llm_rows.packet_batch.blocks+0x464>
     988:      	add	x4, x16, #0x4
     98c:      	ld1.s	{ v28 }[1], [x4]
     990:      	tbnz	w3, #0x2, 0x7b0 <_llm_rows.packet_batch.blocks+0x468>
     994:      	tbz	w3, #0x3, 0x7bc <_llm_rows.packet_batch.blocks+0x474>
     998:      	add	x4, x16, #0xc
     99c:      	ld1.s	{ v28 }[3], [x4]
     9a0:      	tbnz	w3, #0x4, 0x7c0 <_llm_rows.packet_batch.blocks+0x478>
     9a4:      	tbz	w3, #0x5, 0x7cc <_llm_rows.packet_batch.blocks+0x484>
     9a8:      	add	x4, x16, #0x14
     9ac:      	ld1.s	{ v27 }[1], [x4]
     9b0:      	tbnz	w3, #0x6, 0x7d0 <_llm_rows.packet_batch.blocks+0x488>
     9b4:      	tbz	w3, #0x7, 0x7dc <_llm_rows.packet_batch.blocks+0x494>
     9b8:      	add	x3, x16, #0x1c
     9bc:      	ld1.s	{ v27 }[3], [x3]
     9c0:      	fmov	w3, s22
     9c4:      	movi.2d	v30, #0000000000000000
     9c8:      	movi.2d	v29, #0000000000000000
     9cc:      	tbnz	w3, #0x0, 0x7ec <_llm_rows.packet_batch.blocks+0x4a4>
     9d0:      	and	w3, w3, #0xff
     9d4:      	tbz	w3, #0x1, 0x7f8 <_llm_rows.packet_batch.blocks+0x4b0>
     9d8:      	add	x4, x14, #0x4
     9dc:      	ld1.s	{ v30 }[1], [x4]
     9e0:      	tbnz	w3, #0x2, 0x7fc <_llm_rows.packet_batch.blocks+0x4b4>
     9e4:      	tbz	w3, #0x3, 0x808 <_llm_rows.packet_batch.blocks+0x4c0>
     9e8:      	add	x4, x14, #0xc
     9ec:      	ld1.s	{ v30 }[3], [x4]
     9f0:      	tbnz	w3, #0x4, 0x80c <_llm_rows.packet_batch.blocks+0x4c4>
     9f4:      	tbz	w3, #0x5, 0x818 <_llm_rows.packet_batch.blocks+0x4d0>
     9f8:      	add	x4, x14, #0x14
     9fc:      	ld1.s	{ v29 }[1], [x4]
     a00:      	tbnz	w3, #0x6, 0x81c <_llm_rows.packet_batch.blocks+0x4d4>
     a04:      	tbz	w3, #0x7, 0x828 <_llm_rows.packet_batch.blocks+0x4e0>
     a08:      	add	x3, x14, #0x1c
     a0c:      	ld1.s	{ v29 }[3], [x3]
     a10:      	fmov	w3, s22
     a14:      	fmul.4s	v1, v24, v28
     a18:      	fmul.4s	v3, v26, v30
     a1c:      	fsub.4s	v1, v1, v3
     a20:      	add	x2, x8, x2
     a24:      	tbnz	w3, #0x0, 0x840 <_llm_rows.packet_batch.blocks+0x4f8>
     a28:      	and	w3, w3, #0xff
     a2c:      	tbz	w3, #0x1, 0x84c <_llm_rows.packet_batch.blocks+0x504>
     a30:      	add	x4, x2, #0x4
     a34:      	st1.s	{ v1 }[1], [x4]
     a38:      	tbnz	w3, #0x2, 0x850 <_llm_rows.packet_batch.blocks+0x508>
     a3c:      	tbz	w3, #0x3, 0x85c <_llm_rows.packet_batch.blocks+0x514>
     a40:      	add	x4, x2, #0xc
     a44:      	st1.s	{ v1 }[3], [x4]
     a48:      	fmul.4s	v1, v23, v27
     a4c:      	fmul.4s	v3, v25, v29
     a50:      	fsub.4s	v1, v1, v3
     a54:      	tbnz	w3, #0x4, 0x86c <_llm_rows.packet_batch.blocks+0x524>
     a58:      	tbz	w3, #0x5, 0x874 <_llm_rows.packet_batch.blocks+0x52c>
     a5c:      	add	x4, x2, #0x14
     a60:      	st1.s	{ v1 }[1], [x4]
     a64:      	tbnz	w3, #0x6, 0x878 <_llm_rows.packet_batch.blocks+0x530>
     a68:      	tbz	w3, #0x7, 0x884 <_llm_rows.packet_batch.blocks+0x53c>
     a6c:      	add	x2, x2, #0x1c
     a70:      	st1.s	{ v1 }[3], [x2]
     a74:      	fmov	w2, s22
     a78:      	fmul.4s	v1, v24, v30
     a7c:      	fmul.4s	v3, v26, v28
     a80:      	fadd.4s	v1, v3, v1
     a84:      	tbnz	w2, #0x0, 0x898 <_llm_rows.packet_batch.blocks+0x550>
     a88:      	and	w2, w2, #0xff
     a8c:      	tbz	w2, #0x1, 0x8a4 <_llm_rows.packet_batch.blocks+0x55c>
     a90:      	add	x3, x17, #0x4
     a94:      	st1.s	{ v1 }[1], [x3]
     a98:      	tbnz	w2, #0x2, 0x8a8 <_llm_rows.packet_batch.blocks+0x560>
     a9c:      	tbz	w2, #0x3, 0x8b4 <_llm_rows.packet_batch.blocks+0x56c>
     aa0:      	add	x3, x17, #0xc
     aa4:      	st1.s	{ v1 }[3], [x3]
     aa8:      	fmul.4s	v1, v23, v29
     aac:      	fmul.4s	v3, v25, v27
     ab0:      	fadd.4s	v1, v3, v1
     ab4:      	tbnz	w2, #0x4, 0x8c4 <_llm_rows.packet_batch.blocks+0x57c>
     ab8:      	tbz	w2, #0x5, 0x8cc <_llm_rows.packet_batch.blocks+0x584>
     abc:      	add	x3, x17, #0x14
     ac0:      	st1.s	{ v1 }[1], [x3]
     ac4:      	tbnz	w2, #0x6, 0x8d0 <_llm_rows.packet_batch.blocks+0x588>
     ac8:      	tbz	w2, #0x7, 0x6cc <_llm_rows.packet_batch.blocks+0x384>
     acc:      	add	x2, x17, #0x1c
     ad0:      	st1.s	{ v1 }[3], [x2]
     ad4:      	b	0x6cc <_llm_rows.packet_batch.blocks+0x384>
     ad8:      	xtn.4h	v0, v0
     adc:      	uzp1.8b	v0, v0, v0
     ae0:      	movi.2d	v29, #0000000000000000
     ae4:      	mov.b	v29[0], v0[0]
     ae8:      	adrp	x11, 0x0 <ltmp0>
     aec:      	ldr	d26, [x11]
     af0:      	and.8b	v1, v29, v26
     af4:      	addv.8b	b1, v1
     af8:      	fmov	w13, s1
     afc:      	umaxv.8b	b1, v29
     b00:      	fmov	w15, s1
     b04:      	rbit	w11, w13
     b08:      	clz	w11, w11
     b0c:      	tst	w15, #0x1
     b10:      	csel	w11, w11, wzr, ne
     b14:      	mov	w14, #0x300             ; =768
     b18:      	dup.2d	v31, x14
     b1c:      	orr.16b	v30, v20, v31
     b20:      	add.2d	v23, v21, v30
     b24:      	movi.2d	v1, #0000000000000000
     b28:      	mov.b	v1[0], v0[0]
     b2c:      	ushll.2d	v0, v1, #0x0
     b30:      	shl.2d	v0, v0, #0x3f
     b34:      	cmlt.2d	v0, v0, #0
     b38:      	and.16b	v0, v0, v23
     b3c:      	movi.2d	v1, #0000000000000000
     b40:      	stp	q1, q1, [sp, #0x260]
     b44:      	stp	q0, q1, [sp, #0x240]
     b48:      	and	x14, x11, #0x7
     b4c:      	add	x16, sp, #0x240
     b50:      	ldr	x14, [x16, x14, lsl #3]
     b54:      	sub	x14, x14, x11
     b58:      	add	x14, x12, x14, lsl #2
     b5c:      	movi.2d	v22, #0000000000000000
     b60:      	movi.2d	v0, #0000000000000000
     b64:      	tbz	w15, #0x0, 0xba4 <_llm_rows.packet_batch.blocks+0x85c>
     b68:      	ldr	s22, [x14]
     b6c:      	tbnz	w13, #0x1, 0xba8 <_llm_rows.packet_batch.blocks+0x860>
     b70:      	tbz	w13, #0x2, 0xbb4 <_llm_rows.packet_batch.blocks+0x86c>
     b74:      	add	x15, x14, #0x8
     b78:      	ld1.s	{ v22 }[2], [x15]
     b7c:      	tbnz	w13, #0x3, 0xbb8 <_llm_rows.packet_batch.blocks+0x870>
     b80:      	tbz	w13, #0x4, 0xbc4 <_llm_rows.packet_batch.blocks+0x87c>
     b84:      	add	x15, x14, #0x10
     b88:      	ld1.s	{ v0 }[0], [x15]
     b8c:      	tbnz	w13, #0x5, 0xbc8 <_llm_rows.packet_batch.blocks+0x880>
     b90:      	tbz	w13, #0x6, 0xbd4 <_llm_rows.packet_batch.blocks+0x88c>
     b94:      	add	x15, x14, #0x18
     b98:      	ld1.s	{ v0 }[2], [x15]
     b9c:      	tbnz	w13, #0x7, 0xbd8 <_llm_rows.packet_batch.blocks+0x890>
     ba0:      	b	0xbe0 <_llm_rows.packet_batch.blocks+0x898>
     ba4:      	tbz	w13, #0x1, 0xb70 <_llm_rows.packet_batch.blocks+0x828>
     ba8:      	add	x15, x14, #0x4
     bac:      	ld1.s	{ v22 }[1], [x15]
     bb0:      	tbnz	w13, #0x2, 0xb74 <_llm_rows.packet_batch.blocks+0x82c>
     bb4:      	tbz	w13, #0x3, 0xb80 <_llm_rows.packet_batch.blocks+0x838>
     bb8:      	add	x15, x14, #0xc
     bbc:      	ld1.s	{ v22 }[3], [x15]
     bc0:      	tbnz	w13, #0x4, 0xb84 <_llm_rows.packet_batch.blocks+0x83c>
     bc4:      	tbz	w13, #0x5, 0xb90 <_llm_rows.packet_batch.blocks+0x848>
     bc8:      	add	x15, x14, #0x14
     bcc:      	ld1.s	{ v0 }[1], [x15]
     bd0:      	tbnz	w13, #0x6, 0xb94 <_llm_rows.packet_batch.blocks+0x84c>
     bd4:      	tbz	w13, #0x7, 0xbe0 <_llm_rows.packet_batch.blocks+0x898>
     bd8:      	add	x13, x14, #0x1c
     bdc:      	ld1.s	{ v0 }[3], [x13]
     be0:      	add.2d	v1, v20, v21
     be4:      	add.2d	v3, v13, v6
     be8:      	add.2d	v21, v8, v19
     bec:      	add.2d	v20, v16, v7
     bf0:      	mov	w13, #0x601             ; =1537
     bf4:      	dup.2d	v25, x13
     bf8:      	add.2d	v20, v20, v25
     bfc:      	add.2d	v21, v21, v25
     c00:      	add.2d	v24, v3, v25
     c04:      	mov	b3, v29[0]
     c08:      	mov.b	v3[4], v29[1]
     c0c:      	add.2d	v25, v1, v25
     c10:      	ushll.2d	v1, v3, #0x0
     c14:      	shl.2d	v1, v1, #0x3f
     c18:      	cmlt.2d	v1, v1, #0
     c1c:      	and.16b	v1, v1, v25
     c20:      	mov	b3, v29[2]
     c24:      	mov.b	v3[4], v29[3]
     c28:      	ushll.2d	v3, v3, #0x0
     c2c:      	shl.2d	v3, v3, #0x3f
     c30:      	cmlt.2d	v3, v3, #0
     c34:      	and.16b	v3, v3, v24
     c38:      	mov	b27, v29[4]
     c3c:      	mov.b	v27[4], v29[5]
     c40:      	ushll.2d	v27, v27, #0x0
     c44:      	shl.2d	v27, v27, #0x3f
     c48:      	cmlt.2d	v27, v27, #0
     c4c:      	and.16b	v28, v27, v21
     c50:      	mov	b27, v29[6]
     c54:      	mov.b	v27[4], v29[7]
     c58:      	ushll.2d	v27, v27, #0x0
     c5c:      	shl.2d	v27, v27, #0x3f
     c60:      	cmlt.2d	v27, v27, #0
     c64:      	and.16b	v9, v27, v20
     c68:      	shl.8b	v27, v29, #0x7
     c6c:      	cmlt.8b	v27, v27, #0
     c70:      	and.8b	v26, v27, v26
     c74:      	addv.8b	b27, v26
     c78:      	fmov	w13, s27
     c7c:      	stp	q28, q9, [sp, #0x220]
     c80:      	stp	q1, q3, [sp, #0x200]
     c84:      	and	x14, x11, #0x7
     c88:      	add	x15, sp, #0x200
     c8c:      	ldr	x14, [x15, x14, lsl #3]
     c90:      	sub	x14, x14, x11
     c94:      	add	x12, x12, x14, lsl #2
     c98:      	movi.2d	v28, #0000000000000000
     c9c:      	movi.2d	v26, #0000000000000000
     ca0:      	tbz	w13, #0x0, 0xce0 <_llm_rows.packet_batch.blocks+0x998>
     ca4:      	ldr	s28, [x12]
     ca8:      	tbnz	w13, #0x1, 0xce4 <_llm_rows.packet_batch.blocks+0x99c>
     cac:      	tbz	w13, #0x2, 0xcf0 <_llm_rows.packet_batch.blocks+0x9a8>
     cb0:      	add	x14, x12, #0x8
     cb4:      	ld1.s	{ v28 }[2], [x14]
     cb8:      	tbnz	w13, #0x3, 0xcf4 <_llm_rows.packet_batch.blocks+0x9ac>
     cbc:      	tbz	w13, #0x4, 0xd00 <_llm_rows.packet_batch.blocks+0x9b8>
     cc0:      	add	x14, x12, #0x10
     cc4:      	ld1.s	{ v26 }[0], [x14]
     cc8:      	tbnz	w13, #0x5, 0xd04 <_llm_rows.packet_batch.blocks+0x9bc>
     ccc:      	tbz	w13, #0x6, 0xd10 <_llm_rows.packet_batch.blocks+0x9c8>
     cd0:      	add	x14, x12, #0x18
     cd4:      	ld1.s	{ v26 }[2], [x14]
     cd8:      	tbnz	w13, #0x7, 0xd14 <_llm_rows.packet_batch.blocks+0x9cc>
     cdc:      	b	0xd1c <_llm_rows.packet_batch.blocks+0x9d4>
     ce0:      	tbz	w13, #0x1, 0xcac <_llm_rows.packet_batch.blocks+0x964>
     ce4:      	add	x14, x12, #0x4
     ce8:      	ld1.s	{ v28 }[1], [x14]
     cec:      	tbnz	w13, #0x2, 0xcb0 <_llm_rows.packet_batch.blocks+0x968>
     cf0:      	tbz	w13, #0x3, 0xcbc <_llm_rows.packet_batch.blocks+0x974>
     cf4:      	add	x14, x12, #0xc
     cf8:      	ld1.s	{ v28 }[3], [x14]
     cfc:      	tbnz	w13, #0x4, 0xcc0 <_llm_rows.packet_batch.blocks+0x978>
     d00:      	tbz	w13, #0x5, 0xccc <_llm_rows.packet_batch.blocks+0x984>
     d04:      	add	x14, x12, #0x14
     d08:      	ld1.s	{ v26 }[1], [x14]
     d0c:      	tbnz	w13, #0x6, 0xcd0 <_llm_rows.packet_batch.blocks+0x988>
     d10:      	tbz	w13, #0x7, 0xd1c <_llm_rows.packet_batch.blocks+0x9d4>
     d14:      	add	x12, x12, #0x1c
     d18:      	ld1.s	{ v26 }[3], [x12]
     d1c:      	orr.16b	v16, v16, v31
     d20:      	orr.16b	v18, v13, v31
     d24:      	orr.16b	v17, v8, v31
     d28:      	mov.16b	v1, v16
     d2c:      	umlal.2d	v1, v5, v2
     d30:      	mov.16b	v3, v17
     d34:      	umlal.2d	v3, v4, v2
     d38:      	mov.16b	v4, v18
     d3c:      	umlal.2d	v4, v11, v2
     d40:      	umlal.2d	v30, v15, v2
     d44:      	mov	b2, v29[0]
     d48:      	mov.b	v2[4], v29[1]
     d4c:      	ushll.2d	v2, v2, #0x0
     d50:      	shl.2d	v2, v2, #0x3f
     d54:      	cmlt.2d	v2, v2, #0
     d58:      	and.16b	v2, v2, v30
     d5c:      	mov	b5, v29[2]
     d60:      	mov.b	v5[4], v29[3]
     d64:      	ushll.2d	v5, v5, #0x0
     d68:      	shl.2d	v5, v5, #0x3f
     d6c:      	cmlt.2d	v5, v5, #0
     d70:      	and.16b	v4, v5, v4
     d74:      	mov	b5, v29[4]
     d78:      	mov.b	v5[4], v29[5]
     d7c:      	ushll.2d	v5, v5, #0x0
     d80:      	shl.2d	v5, v5, #0x3f
     d84:      	cmlt.2d	v5, v5, #0
     d88:      	mov	b30, v29[6]
     d8c:      	mov.b	v30[4], v29[7]
     d90:      	and.16b	v3, v5, v3
     d94:      	ushll.2d	v5, v30, #0x0
     d98:      	shl.2d	v5, v5, #0x3f
     d9c:      	cmlt.2d	v5, v5, #0
     da0:      	and.16b	v1, v5, v1
     da4:      	stp	q3, q1, [sp, #0x1e0]
     da8:      	stp	q2, q4, [sp, #0x1c0]
     dac:      	and	x12, x11, #0x7
     db0:      	add	x13, sp, #0x1c0
     db4:      	ldr	x12, [x13, x12, lsl #3]
     db8:      	fmov	w13, s27
     dbc:      	sub	x12, x12, x11
     dc0:      	lsl	x12, x12, #2
     dc4:      	add	x10, x10, x12
     dc8:      	movi.2d	v2, #0000000000000000
     dcc:      	movi.2d	v1, #0000000000000000
     dd0:      	tbz	w13, #0x0, 0xe5c <_llm_rows.packet_batch.blocks+0xb14>
     dd4:      	ldr	s2, [x10]
     dd8:      	tbnz	w13, #0x1, 0xe60 <_llm_rows.packet_batch.blocks+0xb18>
     ddc:      	tbz	w13, #0x2, 0xe6c <_llm_rows.packet_batch.blocks+0xb24>
     de0:      	add	x14, x10, #0x8
     de4:      	ld1.s	{ v2 }[2], [x14]
     de8:      	tbnz	w13, #0x3, 0xe70 <_llm_rows.packet_batch.blocks+0xb28>
     dec:      	tbz	w13, #0x4, 0xe7c <_llm_rows.packet_batch.blocks+0xb34>
     df0:      	add	x14, x10, #0x10
     df4:      	ld1.s	{ v1 }[0], [x14]
     df8:      	tbnz	w13, #0x5, 0xe80 <_llm_rows.packet_batch.blocks+0xb38>
     dfc:      	tbz	w13, #0x6, 0xe8c <_llm_rows.packet_batch.blocks+0xb44>
     e00:      	add	x14, x10, #0x18
     e04:      	ld1.s	{ v1 }[2], [x14]
     e08:      	tbnz	w13, #0x7, 0xe90 <_llm_rows.packet_batch.blocks+0xb48>
     e0c:      	add	x9, x9, x12
     e10:      	fmov	w10, s27
     e14:      	movi.2d	v4, #0000000000000000
     e18:      	movi.2d	v3, #0000000000000000
     e1c:      	tbz	w10, #0x0, 0xeac <_llm_rows.packet_batch.blocks+0xb64>
     e20:      	ldr	s4, [x9]
     e24:      	tbnz	w10, #0x1, 0xeb0 <_llm_rows.packet_batch.blocks+0xb68>
     e28:      	tbz	w10, #0x2, 0xebc <_llm_rows.packet_batch.blocks+0xb74>
     e2c:      	add	x12, x9, #0x8
     e30:      	ld1.s	{ v4 }[2], [x12]
     e34:      	tbnz	w10, #0x3, 0xec0 <_llm_rows.packet_batch.blocks+0xb78>
     e38:      	tbz	w10, #0x4, 0xecc <_llm_rows.packet_batch.blocks+0xb84>
     e3c:      	add	x12, x9, #0x10
     e40:      	ld1.s	{ v3 }[0], [x12]
     e44:      	tbnz	w10, #0x5, 0xed0 <_llm_rows.packet_batch.blocks+0xb88>
     e48:      	tbz	w10, #0x6, 0xedc <_llm_rows.packet_batch.blocks+0xb94>
     e4c:      	add	x12, x9, #0x18
     e50:      	ld1.s	{ v3 }[2], [x12]
     e54:      	tbnz	w10, #0x7, 0xee0 <_llm_rows.packet_batch.blocks+0xb98>
     e58:      	b	0xee8 <_llm_rows.packet_batch.blocks+0xba0>
     e5c:      	tbz	w13, #0x1, 0xddc <_llm_rows.packet_batch.blocks+0xa94>
     e60:      	add	x14, x10, #0x4
     e64:      	ld1.s	{ v2 }[1], [x14]
     e68:      	tbnz	w13, #0x2, 0xde0 <_llm_rows.packet_batch.blocks+0xa98>
     e6c:      	tbz	w13, #0x3, 0xdec <_llm_rows.packet_batch.blocks+0xaa4>
     e70:      	add	x14, x10, #0xc
     e74:      	ld1.s	{ v2 }[3], [x14]
     e78:      	tbnz	w13, #0x4, 0xdf0 <_llm_rows.packet_batch.blocks+0xaa8>
     e7c:      	tbz	w13, #0x5, 0xdfc <_llm_rows.packet_batch.blocks+0xab4>
     e80:      	add	x14, x10, #0x14
     e84:      	ld1.s	{ v1 }[1], [x14]
     e88:      	tbnz	w13, #0x6, 0xe00 <_llm_rows.packet_batch.blocks+0xab8>
     e8c:      	tbz	w13, #0x7, 0xe0c <_llm_rows.packet_batch.blocks+0xac4>
     e90:      	add	x10, x10, #0x1c
     e94:      	ld1.s	{ v1 }[3], [x10]
     e98:      	add	x9, x9, x12
     e9c:      	fmov	w10, s27
     ea0:      	movi.2d	v4, #0000000000000000
     ea4:      	movi.2d	v3, #0000000000000000
     ea8:      	tbnz	w10, #0x0, 0xe20 <_llm_rows.packet_batch.blocks+0xad8>
     eac:      	tbz	w10, #0x1, 0xe28 <_llm_rows.packet_batch.blocks+0xae0>
     eb0:      	add	x12, x9, #0x4
     eb4:      	ld1.s	{ v4 }[1], [x12]
     eb8:      	tbnz	w10, #0x2, 0xe2c <_llm_rows.packet_batch.blocks+0xae4>
     ebc:      	tbz	w10, #0x3, 0xe38 <_llm_rows.packet_batch.blocks+0xaf0>
     ec0:      	add	x12, x9, #0xc
     ec4:      	ld1.s	{ v4 }[3], [x12]
     ec8:      	tbnz	w10, #0x4, 0xe3c <_llm_rows.packet_batch.blocks+0xaf4>
     ecc:      	tbz	w10, #0x5, 0xe48 <_llm_rows.packet_batch.blocks+0xb00>
     ed0:      	add	x12, x9, #0x14
     ed4:      	ld1.s	{ v3 }[1], [x12]
     ed8:      	tbnz	w10, #0x6, 0xe4c <_llm_rows.packet_batch.blocks+0xb04>
     edc:      	tbz	w10, #0x7, 0xee8 <_llm_rows.packet_batch.blocks+0xba0>
     ee0:      	add	x9, x9, #0x1c
     ee4:      	ld1.s	{ v3 }[3], [x9]
     ee8:      	add.2d	v17, v19, v17
     eec:      	add.2d	v6, v6, v18
     ef0:      	add.2d	v7, v7, v16
     ef4:      	fmul.4s	v5, v22, v2
     ef8:      	fmul.4s	v16, v28, v4
     efc:      	fsub.4s	v5, v5, v16
     f00:      	stp	q23, q6, [sp, #0x180]
     f04:      	stp	q17, q7, [sp, #0x1a0]
     f08:      	and	x9, x11, #0x7
     f0c:      	add	x10, sp, #0x180
     f10:      	ldr	x9, [x10, x9, lsl #3]
     f14:      	sub	x9, x9, x11
     f18:      	add	x9, x8, x9, lsl #2
     f1c:      	fmov	w10, s27
     f20:      	tbz	w10, #0x0, 0xf68 <_llm_rows.packet_batch.blocks+0xc20>
     f24:      	str	s5, [x9]
     f28:      	tbnz	w10, #0x1, 0xf6c <_llm_rows.packet_batch.blocks+0xc24>
     f2c:      	tbz	w10, #0x2, 0xf78 <_llm_rows.packet_batch.blocks+0xc30>
     f30:      	add	x12, x9, #0x8
     f34:      	st1.s	{ v5 }[2], [x12]
     f38:      	tbnz	w10, #0x3, 0xf7c <_llm_rows.packet_batch.blocks+0xc34>
     f3c:      	fmul.4s	v5, v0, v1
     f40:      	fmul.4s	v6, v26, v3
     f44:      	fsub.4s	v5, v5, v6
     f48:      	tbz	w10, #0x4, 0xf94 <_llm_rows.packet_batch.blocks+0xc4c>
     f4c:      	str	s5, [x9, #0x10]
     f50:      	tbnz	w10, #0x5, 0xf98 <_llm_rows.packet_batch.blocks+0xc50>
     f54:      	tbz	w10, #0x6, 0xfa4 <_llm_rows.packet_batch.blocks+0xc5c>
     f58:      	add	x12, x9, #0x18
     f5c:      	st1.s	{ v5 }[2], [x12]
     f60:      	tbnz	w10, #0x7, 0xfa8 <_llm_rows.packet_batch.blocks+0xc60>
     f64:      	b	0xfb0 <_llm_rows.packet_batch.blocks+0xc68>
     f68:      	tbz	w10, #0x1, 0xf2c <_llm_rows.packet_batch.blocks+0xbe4>
     f6c:      	add	x12, x9, #0x4
     f70:      	st1.s	{ v5 }[1], [x12]
     f74:      	tbnz	w10, #0x2, 0xf30 <_llm_rows.packet_batch.blocks+0xbe8>
     f78:      	tbz	w10, #0x3, 0xf3c <_llm_rows.packet_batch.blocks+0xbf4>
     f7c:      	add	x12, x9, #0xc
     f80:      	st1.s	{ v5 }[3], [x12]
     f84:      	fmul.4s	v5, v0, v1
     f88:      	fmul.4s	v6, v26, v3
     f8c:      	fsub.4s	v5, v5, v6
     f90:      	tbnz	w10, #0x4, 0xf4c <_llm_rows.packet_batch.blocks+0xc04>
     f94:      	tbz	w10, #0x5, 0xf54 <_llm_rows.packet_batch.blocks+0xc0c>
     f98:      	add	x12, x9, #0x14
     f9c:      	st1.s	{ v5 }[1], [x12]
     fa0:      	tbnz	w10, #0x6, 0xf58 <_llm_rows.packet_batch.blocks+0xc10>
     fa4:      	tbz	w10, #0x7, 0xfb0 <_llm_rows.packet_batch.blocks+0xc68>
     fa8:      	add	x9, x9, #0x1c
     fac:      	st1.s	{ v5 }[3], [x9]
     fb0:      	fmul.4s	v4, v22, v4
     fb4:      	fmul.4s	v2, v28, v2
     fb8:      	fadd.4s	v2, v2, v4
     fbc:      	stp	q25, q24, [sp, #0x140]
     fc0:      	stp	q21, q20, [sp, #0x160]
     fc4:      	and	x9, x11, #0x7
     fc8:      	add	x10, sp, #0x140
     fcc:      	ldr	x9, [x10, x9, lsl #3]
     fd0:      	sub	x9, x9, x11
     fd4:      	add	x8, x8, x9, lsl #2
     fd8:      	fmov	w9, s27
     fdc:      	tbz	w9, #0x0, 0x1024 <_llm_rows.packet_batch.blocks+0xcdc>
     fe0:      	str	s2, [x8]
     fe4:      	tbnz	w9, #0x1, 0x1028 <_llm_rows.packet_batch.blocks+0xce0>
     fe8:      	tbz	w9, #0x2, 0x1034 <_llm_rows.packet_batch.blocks+0xcec>
     fec:      	add	x10, x8, #0x8
     ff0:      	st1.s	{ v2 }[2], [x10]
     ff4:      	tbnz	w9, #0x3, 0x1038 <_llm_rows.packet_batch.blocks+0xcf0>
     ff8:      	fmul.4s	v0, v0, v3
     ffc:      	fmul.4s	v1, v26, v1
    1000:      	fadd.4s	v0, v1, v0
    1004:      	tbz	w9, #0x4, 0x1df4 <_llm_rows.packet_batch.blocks+0x1aac>
    1008:      	str	s0, [x8, #0x10]
    100c:      	tbnz	w9, #0x5, 0x1df8 <_llm_rows.packet_batch.blocks+0x1ab0>
    1010:      	tbz	w9, #0x6, 0x1e04 <_llm_rows.packet_batch.blocks+0x1abc>
    1014:      	add	x10, x8, #0x18
    1018:      	st1.s	{ v0 }[2], [x10]
    101c:      	tbnz	w9, #0x7, 0x1e08 <_llm_rows.packet_batch.blocks+0x1ac0>
    1020:      	b	0x420 <_llm_rows.packet_batch.blocks+0xd8>
    1024:      	tbz	w9, #0x1, 0xfe8 <_llm_rows.packet_batch.blocks+0xca0>
    1028:      	add	x10, x8, #0x4
    102c:      	st1.s	{ v2 }[1], [x10]
    1030:      	tbnz	w9, #0x2, 0xfec <_llm_rows.packet_batch.blocks+0xca4>
    1034:      	tbz	w9, #0x3, 0xff8 <_llm_rows.packet_batch.blocks+0xcb0>
    1038:      	add	x10, x8, #0xc
    103c:      	st1.s	{ v2 }[3], [x10]
    1040:      	fmul.4s	v0, v0, v3
    1044:      	fmul.4s	v1, v26, v1
    1048:      	fadd.4s	v0, v1, v0
    104c:      	tbz	w9, #0x4, 0x1df4 <_llm_rows.packet_batch.blocks+0x1aac>
    1050:      	b	0x1008 <_llm_rows.packet_batch.blocks+0xcc0>
    1054:      	mov	x13, #0x0               ; =0
    1058:      	fmov	w11, s1
    105c:      	cmp	w11, #0x0
    1060:      	cset	w11, ne
    1064:      	csel	x17, x14, xzr, ne
    1068:      	mov	w15, #0x1808            ; =6152
    106c:      	umaddl	x15, w17, w15, x12
    1070:      	add	x5, sp, #0x2, lsl #12   ; =0x2000
    1074:      	add	x5, x5, #0x8c0
    1078:      	b	0x109c <_llm_rows.packet_batch.blocks+0xd54>
    107c:      	add	x16, x5, x13
    1080:      	ldp	q3, q24, [x16]
    1084:      	bif.16b	v1, v24, v6
    1088:      	bit.16b	v3, v19, v0
    108c:      	stp	q3, q1, [x16]
    1090:      	add	x13, x13, #0x20
    1094:      	cmp	x13, #0xc00
    1098:      	b.eq	0x113c <_llm_rows.packet_batch.blocks+0xdf4>
    109c:      	and.16b	v1, v22, v10
    10a0:      	addv.8h	h7, v1
    10a4:      	fmov	w0, s7
    10a8:      	add	x16, x15, x13
    10ac:      	movi.2d	v19, #0000000000000000
    10b0:      	movi.2d	v1, #0000000000000000
    10b4:      	tbz	w0, #0x0, 0x10f8 <_llm_rows.packet_batch.blocks+0xdb0>
    10b8:      	ldr	s19, [x16]
    10bc:      	and	w0, w0, #0xff
    10c0:      	tbnz	w0, #0x1, 0x1100 <_llm_rows.packet_batch.blocks+0xdb8>
    10c4:      	tbz	w0, #0x2, 0x110c <_llm_rows.packet_batch.blocks+0xdc4>
    10c8:      	add	x1, x16, #0x8
    10cc:      	ld1.s	{ v19 }[2], [x1]
    10d0:      	tbnz	w0, #0x3, 0x1110 <_llm_rows.packet_batch.blocks+0xdc8>
    10d4:      	tbz	w0, #0x4, 0x111c <_llm_rows.packet_batch.blocks+0xdd4>
    10d8:      	add	x1, x16, #0x10
    10dc:      	ld1.s	{ v1 }[0], [x1]
    10e0:      	tbnz	w0, #0x5, 0x1120 <_llm_rows.packet_batch.blocks+0xdd8>
    10e4:      	tbz	w0, #0x6, 0x112c <_llm_rows.packet_batch.blocks+0xde4>
    10e8:      	add	x1, x16, #0x18
    10ec:      	ld1.s	{ v1 }[2], [x1]
    10f0:      	tbz	w0, #0x7, 0x107c <_llm_rows.packet_batch.blocks+0xd34>
    10f4:      	b	0x1130 <_llm_rows.packet_batch.blocks+0xde8>
    10f8:      	and	w0, w0, #0xff
    10fc:      	tbz	w0, #0x1, 0x10c4 <_llm_rows.packet_batch.blocks+0xd7c>
    1100:      	add	x1, x16, #0x4
    1104:      	ld1.s	{ v19 }[1], [x1]
    1108:      	tbnz	w0, #0x2, 0x10c8 <_llm_rows.packet_batch.blocks+0xd80>
    110c:      	tbz	w0, #0x3, 0x10d4 <_llm_rows.packet_batch.blocks+0xd8c>
    1110:      	add	x1, x16, #0xc
    1114:      	ld1.s	{ v19 }[3], [x1]
    1118:      	tbnz	w0, #0x4, 0x10d8 <_llm_rows.packet_batch.blocks+0xd90>
    111c:      	tbz	w0, #0x5, 0x10e4 <_llm_rows.packet_batch.blocks+0xd9c>
    1120:      	add	x1, x16, #0x14
    1124:      	ld1.s	{ v1 }[1], [x1]
    1128:      	tbnz	w0, #0x6, 0x10e8 <_llm_rows.packet_batch.blocks+0xda0>
    112c:      	tbz	w0, #0x7, 0x107c <_llm_rows.packet_batch.blocks+0xd34>
    1130:      	add	x16, x16, #0x1c
    1134:      	ld1.s	{ v1 }[3], [x16]
    1138:      	b	0x107c <_llm_rows.packet_batch.blocks+0xd34>
    113c:      	str	d11, [sp, #0xd8]
    1140:      	xtn.4h	v1, v0
    1144:      	uzp1.8b	v1, v1, v0
    1148:      	movi.2d	v19, #0000000000000000
    114c:      	mov.b	v19[0], v1[0]
    1150:      	adrp	x13, 0x1000 <_llm_rows.packet_batch.blocks+0xcb8>
    1154:      	ldr	d31, [x13]
    1158:      	and.8b	v3, v19, v31
    115c:      	addv.8b	b3, v3
    1160:      	fmov	w15, s3
    1164:      	umaxv.8b	b3, v19
    1168:      	fmov	w0, s3
    116c:      	rbit	w13, w15
    1170:      	clz	w13, w13
    1174:      	tst	w0, #0x1
    1178:      	csel	w13, w13, wzr, ne
    117c:      	mov	w16, #0x300             ; =768
    1180:      	dup.2d	v26, x16
    1184:      	orr.16b	v11, v20, v26
    1188:      	mov.16b	v17, v11
    118c:      	umlal.2d	v17, v15, v12
    1190:      	movi.2d	v3, #0000000000000000
    1194:      	mov.b	v3[0], v1[0]
    1198:      	ushll.2d	v1, v3, #0x0
    119c:      	shl.2d	v1, v1, #0x3f
    11a0:      	cmlt.2d	v1, v1, #0
    11a4:      	str	q17, [sp, #0x50]
    11a8:      	and.16b	v1, v1, v17
    11ac:      	movi.2d	v3, #0000000000000000
    11b0:      	str	q3, [sp, #0x440]
    11b4:      	str	q3, [sp, #0x430]
    11b8:      	str	q3, [sp, #0x420]
    11bc:      	str	q1, [sp, #0x410]
    11c0:      	and	x16, x13, #0x7
    11c4:      	add	x1, sp, #0x410
    11c8:      	ldr	x16, [x1, x16, lsl #3]
    11cc:      	sub	x16, x16, x13
    11d0:      	add	x16, x12, x16, lsl #2
    11d4:      	movi.2d	v24, #0000000000000000
    11d8:      	movi.2d	v25, #0000000000000000
    11dc:      	tbz	w0, #0x0, 0x1224 <_llm_rows.packet_batch.blocks+0xedc>
    11e0:      	ldr	s24, [x16]
    11e4:      	tbnz	w15, #0x1, 0x1228 <_llm_rows.packet_batch.blocks+0xee0>
    11e8:      	tbz	w15, #0x2, 0x1234 <_llm_rows.packet_batch.blocks+0xeec>
    11ec:      	add	x0, x16, #0x8
    11f0:      	ld1.s	{ v24 }[2], [x0]
    11f4:      	tbnz	w15, #0x3, 0x1238 <_llm_rows.packet_batch.blocks+0xef0>
    11f8:      	tbz	w15, #0x4, 0x1244 <_llm_rows.packet_batch.blocks+0xefc>
    11fc:      	add	x0, x16, #0x10
    1200:      	ld1.s	{ v25 }[0], [x0]
    1204:      	tbnz	w15, #0x5, 0x1248 <_llm_rows.packet_batch.blocks+0xf00>
    1208:      	tbz	w15, #0x6, 0x1254 <_llm_rows.packet_batch.blocks+0xf0c>
    120c:      	add	x0, x16, #0x18
    1210:      	ld1.s	{ v25 }[2], [x0]
    1214:      	fmov	d17, d5
    1218:      	fmov	d1, d12
    121c:      	tbnz	w15, #0x7, 0x1260 <_llm_rows.packet_batch.blocks+0xf18>
    1220:      	b	0x1268 <_llm_rows.packet_batch.blocks+0xf20>
    1224:      	tbz	w15, #0x1, 0x11e8 <_llm_rows.packet_batch.blocks+0xea0>
    1228:      	add	x0, x16, #0x4
    122c:      	ld1.s	{ v24 }[1], [x0]
    1230:      	tbnz	w15, #0x2, 0x11ec <_llm_rows.packet_batch.blocks+0xea4>
    1234:      	tbz	w15, #0x3, 0x11f8 <_llm_rows.packet_batch.blocks+0xeb0>
    1238:      	add	x0, x16, #0xc
    123c:      	ld1.s	{ v24 }[3], [x0]
    1240:      	tbnz	w15, #0x4, 0x11fc <_llm_rows.packet_batch.blocks+0xeb4>
    1244:      	tbz	w15, #0x5, 0x1208 <_llm_rows.packet_batch.blocks+0xec0>
    1248:      	add	x0, x16, #0x14
    124c:      	ld1.s	{ v25 }[1], [x0]
    1250:      	tbnz	w15, #0x6, 0x120c <_llm_rows.packet_batch.blocks+0xec4>
    1254:      	fmov	d17, d5
    1258:      	fmov	d1, d12
    125c:      	tbz	w15, #0x7, 0x1268 <_llm_rows.packet_batch.blocks+0xf20>
    1260:      	add	x16, x16, #0x1c
    1264:      	ld1.s	{ v25 }[3], [x16]
    1268:      	mov	x1, #0x0                ; =0
    126c:      	orr.16b	v12, v16, v26
    1270:      	mov.16b	v18, v13
    1274:      	orr.16b	v14, v13, v26
    1278:      	mov.16b	v13, v8
    127c:      	orr.16b	v22, v8, v26
    1280:      	fmov	d5, d15
    1284:      	fmov	d8, d1
    1288:      	umull.2d	v9, v15, v1
    128c:      	ldr	d1, [sp, #0xd8]
    1290:      	umull.2d	v10, v1, v8
    1294:      	umull.2d	v15, v4, v8
    1298:      	umull.2d	v28, v17, v8
    129c:      	mov.16b	v26, v22
    12a0:      	str	d4, [sp, #0x78]
    12a4:      	umlal.2d	v26, v4, v8
    12a8:      	mov.16b	v4, v14
    12ac:      	umlal.2d	v4, v1, v8
    12b0:      	stp	q4, q26, [sp, #0x30]
    12b4:      	mov.16b	v1, v12
    12b8:      	umlal.2d	v1, v17, v8
    12bc:      	str	q1, [sp, #0x20]
    12c0:      	mov	w16, #0xc00             ; =3072
    12c4:      	dup.2d	v1, x16
    12c8:      	adrp	x16, 0x1000 <_llm_rows.packet_batch.blocks+0xcb8>
    12cc:      	ldr	q3, [x16]
    12d0:      	sshll.2d	v26, v0, #0x0
    12d4:      	bif.16b	v3, v1, v26
    12d8:      	adrp	x16, 0x1000 <_llm_rows.packet_batch.blocks+0xcb8>
    12dc:      	ldr	q26, [x16]
    12e0:      	sshll.2d	v27, v6, #0x0
    12e4:      	bif.16b	v26, v1, v27
    12e8:      	adrp	x16, 0x1000 <_llm_rows.packet_batch.blocks+0xcb8>
    12ec:      	ldr	q27, [x16]
    12f0:      	bsl.16b	v23, v27, v1
    12f4:      	adrp	x16, 0x1000 <_llm_rows.packet_batch.blocks+0xcb8>
    12f8:      	ldr	q27, [x16]
    12fc:      	bit.16b	v1, v27, v21
    1300:      	stp	q26, q1, [sp, #0x3f0]
    1304:      	stp	q3, q23, [sp, #0x3d0]
    1308:      	and	x16, x13, #0x7
    130c:      	add	x0, sp, #0x3d0
    1310:      	ldr	x16, [x0, x16, lsl #3]
    1314:      	sub	x16, x16, x13, lsl #2
    1318:      	tst	w15, #0xff
    131c:      	csel	x15, xzr, x16, eq
    1320:      	add	x16, x5, x15
    1324:      	ldp	q1, q3, [x16]
    1328:      	zip2.8b	v21, v19, v0
    132c:      	ushll.4s	v21, v21, #0x0
    1330:      	shl.4s	v21, v21, #0x1f
    1334:      	cmlt.4s	v21, v21, #0
    1338:      	mov.16b	v4, v21
    133c:      	bsl.16b	v4, v25, v3
    1340:      	zip1.8b	v3, v19, v0
    1344:      	ushll.4s	v3, v3, #0x0
    1348:      	shl.4s	v3, v3, #0x1f
    134c:      	cmlt.4s	v3, v3, #0
    1350:      	bit.16b	v1, v24, v3
    1354:      	str	q1, [sp, #0xc0]
    1358:      	stp	q1, q4, [x16]
    135c:      	str	q4, [sp, #0x60]
    1360:      	ushll2.2d	v1, v6, #0x0
    1364:      	mov	w16, #0x1               ; =1
    1368:      	dup.2d	v3, x16
    136c:      	and.16b	v24, v1, v3
    1370:      	ushll2.2d	v1, v0, #0x0
    1374:      	and.16b	v25, v1, v3
    1378:      	ushll.2d	v1, v6, #0x0
    137c:      	and.16b	v26, v1, v3
    1380:      	ushll.2d	v1, v0, #0x0
    1384:      	and.16b	v27, v1, v3
    1388:      	mov	w16, #0x1808            ; =6152
    138c:      	umull	x16, w14, w16
    1390:      	cmp	w11, #0x0
    1394:      	csel	x16, x16, xzr, ne
    1398:      	add	x0, x12, x16
    139c:      	add	x0, x0, #0xc04
    13a0:      	movi.2d	v23, #0000000000000000
    13a4:      	movi.2d	v21, #0000000000000000
    13a8:      	movi.2d	v29, #0000000000000000
    13ac:      	movi.2d	v30, #0000000000000000
    13b0:      	b	0x13ec <_llm_rows.packet_batch.blocks+0x10a4>
    13b4:      	add	x1, x27, x1
    13b8:      	ldp	q4, q8, [x1]
    13bc:      	bif.16b	v3, v8, v6
    13c0:      	bif.16b	v1, v4, v0
    13c4:      	stp	q1, q3, [x1]
    13c8:      	add.2d	v1, v23, v27
    13cc:      	add.2d	v21, v21, v25
    13d0:      	add.2d	v29, v29, v26
    13d4:      	add.2d	v30, v30, v24
    13d8:      	fmov	x1, d23
    13dc:      	add	x1, x1, x11
    13e0:      	mov.16b	v23, v1
    13e4:      	cmp	x1, #0x60
    13e8:      	b.ge	0x1488 <_llm_rows.packet_batch.blocks+0x1140>
    13ec:      	fmov	w3, s7
    13f0:      	lsl	x1, x1, #5
    13f4:      	add	x2, x0, x1
    13f8:      	movi.2d	v1, #0000000000000000
    13fc:      	movi.2d	v3, #0000000000000000
    1400:      	tbz	w3, #0x0, 0x1444 <_llm_rows.packet_batch.blocks+0x10fc>
    1404:      	ldr	s1, [x2]
    1408:      	and	w3, w3, #0xff
    140c:      	tbnz	w3, #0x1, 0x144c <_llm_rows.packet_batch.blocks+0x1104>
    1410:      	tbz	w3, #0x2, 0x1458 <_llm_rows.packet_batch.blocks+0x1110>
    1414:      	add	x4, x2, #0x8
    1418:      	ld1.s	{ v1 }[2], [x4]
    141c:      	tbnz	w3, #0x3, 0x145c <_llm_rows.packet_batch.blocks+0x1114>
    1420:      	tbz	w3, #0x4, 0x1468 <_llm_rows.packet_batch.blocks+0x1120>
    1424:      	add	x4, x2, #0x10
    1428:      	ld1.s	{ v3 }[0], [x4]
    142c:      	tbnz	w3, #0x5, 0x146c <_llm_rows.packet_batch.blocks+0x1124>
    1430:      	tbz	w3, #0x6, 0x1478 <_llm_rows.packet_batch.blocks+0x1130>
    1434:      	add	x4, x2, #0x18
    1438:      	ld1.s	{ v3 }[2], [x4]
    143c:      	tbz	w3, #0x7, 0x13b4 <_llm_rows.packet_batch.blocks+0x106c>
    1440:      	b	0x147c <_llm_rows.packet_batch.blocks+0x1134>
    1444:      	and	w3, w3, #0xff
    1448:      	tbz	w3, #0x1, 0x1410 <_llm_rows.packet_batch.blocks+0x10c8>
    144c:      	add	x4, x2, #0x4
    1450:      	ld1.s	{ v1 }[1], [x4]
    1454:      	tbnz	w3, #0x2, 0x1414 <_llm_rows.packet_batch.blocks+0x10cc>
    1458:      	tbz	w3, #0x3, 0x1420 <_llm_rows.packet_batch.blocks+0x10d8>
    145c:      	add	x4, x2, #0xc
    1460:      	ld1.s	{ v1 }[3], [x4]
    1464:      	tbnz	w3, #0x4, 0x1424 <_llm_rows.packet_batch.blocks+0x10dc>
    1468:      	tbz	w3, #0x5, 0x1430 <_llm_rows.packet_batch.blocks+0x10e8>
    146c:      	add	x4, x2, #0x14
    1470:      	ld1.s	{ v3 }[1], [x4]
    1474:      	tbnz	w3, #0x6, 0x1434 <_llm_rows.packet_batch.blocks+0x10ec>
    1478:      	tbz	w3, #0x7, 0x13b4 <_llm_rows.packet_batch.blocks+0x106c>
    147c:      	add	x2, x2, #0x1c
    1480:      	ld1.s	{ v3 }[3], [x2]
    1484:      	b	0x13b4 <_llm_rows.packet_batch.blocks+0x106c>
    1488:      	add.2d	v1, v20, v9
    148c:      	add.2d	v3, v18, v10
    1490:      	add.2d	v4, v13, v15
    1494:      	add.2d	v16, v16, v28
    1498:      	mov	w0, #0x601              ; =1537
    149c:      	dup.2d	v20, x0
    14a0:      	add.2d	v18, v16, v20
    14a4:      	add.2d	v15, v4, v20
    14a8:      	add.2d	v16, v3, v20
    14ac:      	mov	b3, v19[0]
    14b0:      	mov.b	v3[4], v19[1]
    14b4:      	add.2d	v20, v1, v20
    14b8:      	ushll.2d	v1, v3, #0x0
    14bc:      	shl.2d	v1, v1, #0x3f
    14c0:      	cmlt.2d	v1, v1, #0
    14c4:      	and.16b	v1, v1, v20
    14c8:      	mov	b3, v19[2]
    14cc:      	mov.b	v3[4], v19[3]
    14d0:      	ushll.2d	v3, v3, #0x0
    14d4:      	shl.2d	v3, v3, #0x3f
    14d8:      	cmlt.2d	v3, v3, #0
    14dc:      	and.16b	v3, v3, v16
    14e0:      	mov	b4, v19[4]
    14e4:      	mov.b	v4[4], v19[5]
    14e8:      	ushll.2d	v4, v4, #0x0
    14ec:      	shl.2d	v4, v4, #0x3f
    14f0:      	cmlt.2d	v4, v4, #0
    14f4:      	and.16b	v4, v4, v15
    14f8:      	mov	b21, v19[6]
    14fc:      	mov.b	v21[4], v19[7]
    1500:      	ushll.2d	v21, v21, #0x0
    1504:      	shl.2d	v21, v21, #0x3f
    1508:      	cmlt.2d	v21, v21, #0
    150c:      	str	q18, [sp, #0x10]
    1510:      	and.16b	v21, v21, v18
    1514:      	shl.8b	v23, v19, #0x7
    1518:      	cmlt.8b	v23, v23, #0
    151c:      	and.8b	v23, v23, v31
    1520:      	addv.8b	b31, v23
    1524:      	fmov	w0, s31
    1528:      	stp	q4, q21, [sp, #0x3a0]
    152c:      	stp	q1, q3, [sp, #0x380]
    1530:      	and	x1, x13, #0x7
    1534:      	add	x2, sp, #0x380
    1538:      	ldr	x1, [x2, x1, lsl #3]
    153c:      	sub	x1, x1, x13
    1540:      	add	x12, x12, x1, lsl #2
    1544:      	movi.2d	v21, #0000000000000000
    1548:      	movi.2d	v1, #0000000000000000
    154c:      	tbz	w0, #0x0, 0x158c <_llm_rows.packet_batch.blocks+0x1244>
    1550:      	ldr	s21, [x12]
    1554:      	tbnz	w0, #0x1, 0x1590 <_llm_rows.packet_batch.blocks+0x1248>
    1558:      	tbz	w0, #0x2, 0x159c <_llm_rows.packet_batch.blocks+0x1254>
    155c:      	add	x1, x12, #0x8
    1560:      	ld1.s	{ v21 }[2], [x1]
    1564:      	tbnz	w0, #0x3, 0x15a0 <_llm_rows.packet_batch.blocks+0x1258>
    1568:      	tbz	w0, #0x4, 0x15ac <_llm_rows.packet_batch.blocks+0x1264>
    156c:      	add	x1, x12, #0x10
    1570:      	ld1.s	{ v1 }[0], [x1]
    1574:      	tbnz	w0, #0x5, 0x15b0 <_llm_rows.packet_batch.blocks+0x1268>
    1578:      	tbz	w0, #0x6, 0x15bc <_llm_rows.packet_batch.blocks+0x1274>
    157c:      	add	x1, x12, #0x18
    1580:      	ld1.s	{ v1 }[2], [x1]
    1584:      	tbnz	w0, #0x7, 0x15c0 <_llm_rows.packet_batch.blocks+0x1278>
    1588:      	b	0x15c8 <_llm_rows.packet_batch.blocks+0x1280>
    158c:      	tbz	w0, #0x1, 0x1558 <_llm_rows.packet_batch.blocks+0x1210>
    1590:      	add	x1, x12, #0x4
    1594:      	ld1.s	{ v21 }[1], [x1]
    1598:      	tbnz	w0, #0x2, 0x155c <_llm_rows.packet_batch.blocks+0x1214>
    159c:      	tbz	w0, #0x3, 0x1568 <_llm_rows.packet_batch.blocks+0x1220>
    15a0:      	add	x1, x12, #0xc
    15a4:      	ld1.s	{ v21 }[3], [x1]
    15a8:      	tbnz	w0, #0x4, 0x156c <_llm_rows.packet_batch.blocks+0x1224>
    15ac:      	tbz	w0, #0x5, 0x1578 <_llm_rows.packet_batch.blocks+0x1230>
    15b0:      	add	x1, x12, #0x14
    15b4:      	ld1.s	{ v1 }[1], [x1]
    15b8:      	tbnz	w0, #0x6, 0x157c <_llm_rows.packet_batch.blocks+0x1234>
    15bc:      	tbz	w0, #0x7, 0x15c8 <_llm_rows.packet_batch.blocks+0x1280>
    15c0:      	add	x12, x12, #0x1c
    15c4:      	ld1.s	{ v1 }[3], [x12]
    15c8:      	mov	x0, #0x0                ; =0
    15cc:      	add	x12, x27, x15
    15d0:      	ldp	q3, q4, [x12]
    15d4:      	zip2.8b	v23, v19, v0
    15d8:      	ushll.4s	v23, v23, #0x0
    15dc:      	shl.4s	v23, v23, #0x1f
    15e0:      	cmlt.4s	v23, v23, #0
    15e4:      	mov.16b	v9, v23
    15e8:      	bsl.16b	v9, v1, v4
    15ec:      	zip1.8b	v1, v19, v0
    15f0:      	ushll.4s	v1, v1, #0x0
    15f4:      	shl.4s	v1, v1, #0x1f
    15f8:      	cmlt.4s	v1, v1, #0
    15fc:      	mov.16b	v10, v1
    1600:      	bsl.16b	v10, v21, v3
    1604:      	stp	q10, q9, [x12]
    1608:      	mov	w12, #0xc04             ; =3076
    160c:      	umaddl	x12, w17, w12, x10
    1610:      	movi.2d	v21, #0000000000000000
    1614:      	movi.2d	v23, #0000000000000000
    1618:      	movi.2d	v28, #0000000000000000
    161c:      	movi.2d	v29, #0000000000000000
    1620:      	b	0x165c <_llm_rows.packet_batch.blocks+0x1314>
    1624:      	add	x17, x19, x17
    1628:      	ldp	q4, q30, [x17]
    162c:      	bif.16b	v3, v30, v6
    1630:      	bif.16b	v1, v4, v0
    1634:      	stp	q1, q3, [x17]
    1638:      	add.2d	v1, v21, v27
    163c:      	add.2d	v23, v23, v25
    1640:      	add.2d	v28, v28, v26
    1644:      	add.2d	v29, v29, v24
    1648:      	fmov	x17, d21
    164c:      	add	x0, x17, x11
    1650:      	mov.16b	v21, v1
    1654:      	cmp	x0, #0x60
    1658:      	b.ge	0x16f8 <_llm_rows.packet_batch.blocks+0x13b0>
    165c:      	fmov	w1, s7
    1660:      	lsl	x17, x0, #5
    1664:      	add	x0, x12, x17
    1668:      	movi.2d	v1, #0000000000000000
    166c:      	movi.2d	v3, #0000000000000000
    1670:      	tbz	w1, #0x0, 0x16b4 <_llm_rows.packet_batch.blocks+0x136c>
    1674:      	ldr	s1, [x0]
    1678:      	and	w1, w1, #0xff
    167c:      	tbnz	w1, #0x1, 0x16bc <_llm_rows.packet_batch.blocks+0x1374>
    1680:      	tbz	w1, #0x2, 0x16c8 <_llm_rows.packet_batch.blocks+0x1380>
    1684:      	add	x2, x0, #0x8
    1688:      	ld1.s	{ v1 }[2], [x2]
    168c:      	tbnz	w1, #0x3, 0x16cc <_llm_rows.packet_batch.blocks+0x1384>
    1690:      	tbz	w1, #0x4, 0x16d8 <_llm_rows.packet_batch.blocks+0x1390>
    1694:      	add	x2, x0, #0x10
    1698:      	ld1.s	{ v3 }[0], [x2]
    169c:      	tbnz	w1, #0x5, 0x16dc <_llm_rows.packet_batch.blocks+0x1394>
    16a0:      	tbz	w1, #0x6, 0x16e8 <_llm_rows.packet_batch.blocks+0x13a0>
    16a4:      	add	x2, x0, #0x18
    16a8:      	ld1.s	{ v3 }[2], [x2]
    16ac:      	tbz	w1, #0x7, 0x1624 <_llm_rows.packet_batch.blocks+0x12dc>
    16b0:      	b	0x16ec <_llm_rows.packet_batch.blocks+0x13a4>
    16b4:      	and	w1, w1, #0xff
    16b8:      	tbz	w1, #0x1, 0x1680 <_llm_rows.packet_batch.blocks+0x1338>
    16bc:      	add	x2, x0, #0x4
    16c0:      	ld1.s	{ v1 }[1], [x2]
    16c4:      	tbnz	w1, #0x2, 0x1684 <_llm_rows.packet_batch.blocks+0x133c>
    16c8:      	tbz	w1, #0x3, 0x1690 <_llm_rows.packet_batch.blocks+0x1348>
    16cc:      	add	x2, x0, #0xc
    16d0:      	ld1.s	{ v1 }[3], [x2]
    16d4:      	tbnz	w1, #0x4, 0x1694 <_llm_rows.packet_batch.blocks+0x134c>
    16d8:      	tbz	w1, #0x5, 0x16a0 <_llm_rows.packet_batch.blocks+0x1358>
    16dc:      	add	x2, x0, #0x14
    16e0:      	ld1.s	{ v3 }[1], [x2]
    16e4:      	tbnz	w1, #0x6, 0x16a4 <_llm_rows.packet_batch.blocks+0x135c>
    16e8:      	tbz	w1, #0x7, 0x1624 <_llm_rows.packet_batch.blocks+0x12dc>
    16ec:      	add	x0, x0, #0x1c
    16f0:      	ld1.s	{ v3 }[3], [x0]
    16f4:      	b	0x1624 <_llm_rows.packet_batch.blocks+0x12dc>
    16f8:      	umlal.2d	v12, v17, v2
    16fc:      	ldr	d1, [sp, #0x78]
    1700:      	umlal.2d	v22, v1, v2
    1704:      	ldr	d1, [sp, #0xd8]
    1708:      	umlal.2d	v14, v1, v2
    170c:      	umlal.2d	v11, v5, v2
    1710:      	mov	b1, v19[0]
    1714:      	mov.b	v1[4], v19[1]
    1718:      	ushll.2d	v1, v1, #0x0
    171c:      	shl.2d	v1, v1, #0x3f
    1720:      	cmlt.2d	v1, v1, #0
    1724:      	and.16b	v1, v1, v11
    1728:      	mov	b2, v19[2]
    172c:      	mov.b	v2[4], v19[3]
    1730:      	ushll.2d	v2, v2, #0x0
    1734:      	shl.2d	v2, v2, #0x3f
    1738:      	cmlt.2d	v2, v2, #0
    173c:      	and.16b	v2, v2, v14
    1740:      	mov	b3, v19[4]
    1744:      	mov.b	v3[4], v19[5]
    1748:      	ushll.2d	v3, v3, #0x0
    174c:      	shl.2d	v3, v3, #0x3f
    1750:      	cmlt.2d	v3, v3, #0
    1754:      	mov	b4, v19[6]
    1758:      	mov.b	v4[4], v19[7]
    175c:      	and.16b	v3, v3, v22
    1760:      	ushll.2d	v4, v4, #0x0
    1764:      	shl.2d	v4, v4, #0x3f
    1768:      	cmlt.2d	v4, v4, #0
    176c:      	and.16b	v4, v4, v12
    1770:      	stp	q3, q4, [sp, #0x350]
    1774:      	stp	q1, q2, [sp, #0x330]
    1778:      	and	x12, x13, #0x7
    177c:      	add	x17, sp, #0x330
    1780:      	ldr	x12, [x17, x12, lsl #3]
    1784:      	fmov	w17, s31
    1788:      	sub	x12, x12, x13
    178c:      	lsl	x12, x12, #2
    1790:      	add	x10, x10, x12
    1794:      	movi.2d	v2, #0000000000000000
    1798:      	movi.2d	v1, #0000000000000000
    179c:      	tbz	w17, #0x0, 0x17e0 <_llm_rows.packet_batch.blocks+0x1498>
    17a0:      	ldr	s2, [x10]
    17a4:      	ldr	q17, [sp, #0x60]
    17a8:      	tbnz	w17, #0x1, 0x17e8 <_llm_rows.packet_batch.blocks+0x14a0>
    17ac:      	tbz	w17, #0x2, 0x17f4 <_llm_rows.packet_batch.blocks+0x14ac>
    17b0:      	add	x0, x10, #0x8
    17b4:      	ld1.s	{ v2 }[2], [x0]
    17b8:      	tbnz	w17, #0x3, 0x17f8 <_llm_rows.packet_batch.blocks+0x14b0>
    17bc:      	tbz	w17, #0x4, 0x1804 <_llm_rows.packet_batch.blocks+0x14bc>
    17c0:      	add	x0, x10, #0x10
    17c4:      	ld1.s	{ v1 }[0], [x0]
    17c8:      	tbnz	w17, #0x5, 0x1808 <_llm_rows.packet_batch.blocks+0x14c0>
    17cc:      	tbz	w17, #0x6, 0x1814 <_llm_rows.packet_batch.blocks+0x14cc>
    17d0:      	add	x0, x10, #0x18
    17d4:      	ld1.s	{ v1 }[2], [x0]
    17d8:      	tbnz	w17, #0x7, 0x1818 <_llm_rows.packet_batch.blocks+0x14d0>
    17dc:      	b	0x1820 <_llm_rows.packet_batch.blocks+0x14d8>
    17e0:      	ldr	q17, [sp, #0x60]
    17e4:      	tbz	w17, #0x1, 0x17ac <_llm_rows.packet_batch.blocks+0x1464>
    17e8:      	add	x0, x10, #0x4
    17ec:      	ld1.s	{ v2 }[1], [x0]
    17f0:      	tbnz	w17, #0x2, 0x17b0 <_llm_rows.packet_batch.blocks+0x1468>
    17f4:      	tbz	w17, #0x3, 0x17bc <_llm_rows.packet_batch.blocks+0x1474>
    17f8:      	add	x0, x10, #0xc
    17fc:      	ld1.s	{ v2 }[3], [x0]
    1800:      	tbnz	w17, #0x4, 0x17c0 <_llm_rows.packet_batch.blocks+0x1478>
    1804:      	tbz	w17, #0x5, 0x17cc <_llm_rows.packet_batch.blocks+0x1484>
    1808:      	add	x0, x10, #0x14
    180c:      	ld1.s	{ v1 }[1], [x0]
    1810:      	tbnz	w17, #0x6, 0x17d0 <_llm_rows.packet_batch.blocks+0x1488>
    1814:      	tbz	w17, #0x7, 0x1820 <_llm_rows.packet_batch.blocks+0x14d8>
    1818:      	add	x10, x10, #0x1c
    181c:      	ld1.s	{ v1 }[3], [x10]
    1820:      	mov	x17, #0x0               ; =0
    1824:      	add	x10, x19, x15
    1828:      	ldp	q3, q4, [x10]
    182c:      	zip2.8b	v5, v19, v0
    1830:      	ushll.4s	v5, v5, #0x0
    1834:      	shl.4s	v5, v5, #0x1f
    1838:      	cmlt.4s	v5, v5, #0
    183c:      	bif.16b	v1, v4, v5
    1840:      	zip1.8b	v4, v19, v0
    1844:      	ushll.4s	v4, v4, #0x0
    1848:      	shl.4s	v4, v4, #0x1f
    184c:      	cmlt.4s	v4, v4, #0
    1850:      	bif.16b	v2, v3, v4
    1854:      	stp	q2, q1, [x10]
    1858:      	mov	w10, #0xc04             ; =3076
    185c:      	umull	x10, w14, w10
    1860:      	cmp	w11, #0x0
    1864:      	csel	x10, x10, xzr, ne
    1868:      	add	x10, x9, x10
    186c:      	movi.2d	v3, #0000000000000000
    1870:      	movi.2d	v4, #0000000000000000
    1874:      	movi.2d	v5, #0000000000000000
    1878:      	movi.2d	v21, #0000000000000000
    187c:      	b	0x18b8 <_llm_rows.packet_batch.blocks+0x1570>
    1880:      	add	x14, x21, x14
    1884:      	ldp	q29, q30, [x14]
    1888:      	bif.16b	v28, v30, v6
    188c:      	bif.16b	v23, v29, v0
    1890:      	stp	q23, q28, [x14]
    1894:      	add.2d	v23, v3, v27
    1898:      	add.2d	v4, v4, v25
    189c:      	add.2d	v5, v5, v26
    18a0:      	add.2d	v21, v21, v24
    18a4:      	fmov	x14, d3
    18a8:      	add	x17, x14, x11
    18ac:      	mov.16b	v3, v23
    18b0:      	cmp	x17, #0x60
    18b4:      	b.ge	0x1954 <_llm_rows.packet_batch.blocks+0x160c>
    18b8:      	fmov	w0, s7
    18bc:      	lsl	x14, x17, #5
    18c0:      	add	x17, x10, x14
    18c4:      	movi.2d	v23, #0000000000000000
    18c8:      	movi.2d	v28, #0000000000000000
    18cc:      	tbz	w0, #0x0, 0x1910 <_llm_rows.packet_batch.blocks+0x15c8>
    18d0:      	ldr	s23, [x17]
    18d4:      	and	w0, w0, #0xff
    18d8:      	tbnz	w0, #0x1, 0x1918 <_llm_rows.packet_batch.blocks+0x15d0>
    18dc:      	tbz	w0, #0x2, 0x1924 <_llm_rows.packet_batch.blocks+0x15dc>
    18e0:      	add	x1, x17, #0x8
    18e4:      	ld1.s	{ v23 }[2], [x1]
    18e8:      	tbnz	w0, #0x3, 0x1928 <_llm_rows.packet_batch.blocks+0x15e0>
    18ec:      	tbz	w0, #0x4, 0x1934 <_llm_rows.packet_batch.blocks+0x15ec>
    18f0:      	add	x1, x17, #0x10
    18f4:      	ld1.s	{ v28 }[0], [x1]
    18f8:      	tbnz	w0, #0x5, 0x1938 <_llm_rows.packet_batch.blocks+0x15f0>
    18fc:      	tbz	w0, #0x6, 0x1944 <_llm_rows.packet_batch.blocks+0x15fc>
    1900:      	add	x1, x17, #0x18
    1904:      	ld1.s	{ v28 }[2], [x1]
    1908:      	tbz	w0, #0x7, 0x1880 <_llm_rows.packet_batch.blocks+0x1538>
    190c:      	b	0x1948 <_llm_rows.packet_batch.blocks+0x1600>
    1910:      	and	w0, w0, #0xff
    1914:      	tbz	w0, #0x1, 0x18dc <_llm_rows.packet_batch.blocks+0x1594>
    1918:      	add	x1, x17, #0x4
    191c:      	ld1.s	{ v23 }[1], [x1]
    1920:      	tbnz	w0, #0x2, 0x18e0 <_llm_rows.packet_batch.blocks+0x1598>
    1924:      	tbz	w0, #0x3, 0x18ec <_llm_rows.packet_batch.blocks+0x15a4>
    1928:      	add	x1, x17, #0xc
    192c:      	ld1.s	{ v23 }[3], [x1]
    1930:      	tbnz	w0, #0x4, 0x18f0 <_llm_rows.packet_batch.blocks+0x15a8>
    1934:      	tbz	w0, #0x5, 0x18fc <_llm_rows.packet_batch.blocks+0x15b4>
    1938:      	add	x1, x17, #0x14
    193c:      	ld1.s	{ v28 }[1], [x1]
    1940:      	tbnz	w0, #0x6, 0x1900 <_llm_rows.packet_batch.blocks+0x15b8>
    1944:      	tbz	w0, #0x7, 0x1880 <_llm_rows.packet_batch.blocks+0x1538>
    1948:      	add	x17, x17, #0x1c
    194c:      	ld1.s	{ v28 }[3], [x17]
    1950:      	b	0x1880 <_llm_rows.packet_batch.blocks+0x1538>
    1954:      	add	x9, x9, x12
    1958:      	fmov	w10, s31
    195c:      	movi.2d	v4, #0000000000000000
    1960:      	movi.2d	v3, #0000000000000000
    1964:      	tbz	w10, #0x0, 0x19a4 <_llm_rows.packet_batch.blocks+0x165c>
    1968:      	ldr	s4, [x9]
    196c:      	tbnz	w10, #0x1, 0x19a8 <_llm_rows.packet_batch.blocks+0x1660>
    1970:      	tbz	w10, #0x2, 0x19b4 <_llm_rows.packet_batch.blocks+0x166c>
    1974:      	add	x12, x9, #0x8
    1978:      	ld1.s	{ v4 }[2], [x12]
    197c:      	tbnz	w10, #0x3, 0x19b8 <_llm_rows.packet_batch.blocks+0x1670>
    1980:      	tbz	w10, #0x4, 0x19c4 <_llm_rows.packet_batch.blocks+0x167c>
    1984:      	add	x12, x9, #0x10
    1988:      	ld1.s	{ v3 }[0], [x12]
    198c:      	tbnz	w10, #0x5, 0x19c8 <_llm_rows.packet_batch.blocks+0x1680>
    1990:      	tbz	w10, #0x6, 0x19d4 <_llm_rows.packet_batch.blocks+0x168c>
    1994:      	add	x12, x9, #0x18
    1998:      	ld1.s	{ v3 }[2], [x12]
    199c:      	tbnz	w10, #0x7, 0x19d8 <_llm_rows.packet_batch.blocks+0x1690>
    19a0:      	b	0x19e0 <_llm_rows.packet_batch.blocks+0x1698>
    19a4:      	tbz	w10, #0x1, 0x1970 <_llm_rows.packet_batch.blocks+0x1628>
    19a8:      	add	x12, x9, #0x4
    19ac:      	ld1.s	{ v4 }[1], [x12]
    19b0:      	tbnz	w10, #0x2, 0x1974 <_llm_rows.packet_batch.blocks+0x162c>
    19b4:      	tbz	w10, #0x3, 0x1980 <_llm_rows.packet_batch.blocks+0x1638>
    19b8:      	add	x12, x9, #0xc
    19bc:      	ld1.s	{ v4 }[3], [x12]
    19c0:      	tbnz	w10, #0x4, 0x1984 <_llm_rows.packet_batch.blocks+0x163c>
    19c4:      	tbz	w10, #0x5, 0x1990 <_llm_rows.packet_batch.blocks+0x1648>
    19c8:      	add	x12, x9, #0x14
    19cc:      	ld1.s	{ v3 }[1], [x12]
    19d0:      	tbnz	w10, #0x6, 0x1994 <_llm_rows.packet_batch.blocks+0x164c>
    19d4:      	tbz	w10, #0x7, 0x19e0 <_llm_rows.packet_batch.blocks+0x1698>
    19d8:      	add	x9, x9, #0x1c
    19dc:      	ld1.s	{ v3 }[3], [x9]
    19e0:      	mov	x10, #0x0               ; =0
    19e4:      	add	x9, x21, x15
    19e8:      	ldp	q5, q21, [x9]
    19ec:      	zip2.8b	v23, v19, v0
    19f0:      	ushll.4s	v23, v23, #0x0
    19f4:      	shl.4s	v23, v23, #0x1f
    19f8:      	cmlt.4s	v23, v23, #0
    19fc:      	bif.16b	v3, v21, v23
    1a00:      	zip1.8b	v21, v19, v0
    1a04:      	ushll.4s	v21, v21, #0x0
    1a08:      	shl.4s	v21, v21, #0x1f
    1a0c:      	cmlt.4s	v21, v21, #0
    1a10:      	bif.16b	v4, v5, v21
    1a14:      	stp	q4, q3, [x9]
    1a18:      	add	x9, x8, x16
    1a1c:      	movi.2d	v5, #0000000000000000
    1a20:      	movi.2d	v21, #0000000000000000
    1a24:      	movi.2d	v23, #0000000000000000
    1a28:      	movi.2d	v28, #0000000000000000
    1a2c:      	b	0x1a54 <_llm_rows.packet_batch.blocks+0x170c>
    1a30:      	add.2d	v29, v5, v27
    1a34:      	add.2d	v21, v21, v25
    1a38:      	add.2d	v23, v23, v26
    1a3c:      	add.2d	v28, v28, v24
    1a40:      	fmov	x10, d5
    1a44:      	add	x10, x10, x11
    1a48:      	mov.16b	v5, v29
    1a4c:      	cmp	x10, #0x60
    1a50:      	b.ge	0x1b34 <_llm_rows.packet_batch.blocks+0x17ec>
    1a54:      	fmov	w12, s7
    1a58:      	lsl	x10, x10, #5
    1a5c:      	add	x14, x5, x10
    1a60:      	ldp	q8, q29, [x14]
    1a64:      	add	x14, x19, x10
    1a68:      	ldp	q11, q30, [x14]
    1a6c:      	fmul.4s	v8, v8, v11
    1a70:      	add	x14, x27, x10
    1a74:      	ldp	q13, q11, [x14]
    1a78:      	add	x14, x21, x10
    1a7c:      	ldp	q14, q12, [x14]
    1a80:      	fmul.4s	v13, v13, v14
    1a84:      	fsub.4s	v8, v8, v13
    1a88:      	and.16b	v13, v0, v8
    1a8c:      	add	x10, x9, x10
    1a90:      	tbz	w12, #0x0, 0x1ae0 <_llm_rows.packet_batch.blocks+0x1798>
    1a94:      	str	s13, [x10]
    1a98:      	and	w12, w12, #0xff
    1a9c:      	tbnz	w12, #0x1, 0x1ae8 <_llm_rows.packet_batch.blocks+0x17a0>
    1aa0:      	tbz	w12, #0x2, 0x1af4 <_llm_rows.packet_batch.blocks+0x17ac>
    1aa4:      	add	x14, x10, #0x8
    1aa8:      	st1.s	{ v13 }[2], [x14]
    1aac:      	tbnz	w12, #0x3, 0x1af8 <_llm_rows.packet_batch.blocks+0x17b0>
    1ab0:      	fmul.4s	v29, v29, v30
    1ab4:      	fmul.4s	v30, v11, v12
    1ab8:      	fsub.4s	v29, v29, v30
    1abc:      	and.16b	v29, v6, v29
    1ac0:      	tbz	w12, #0x4, 0x1b14 <_llm_rows.packet_batch.blocks+0x17cc>
    1ac4:      	str	s29, [x10, #0x10]
    1ac8:      	tbnz	w12, #0x5, 0x1b18 <_llm_rows.packet_batch.blocks+0x17d0>
    1acc:      	tbz	w12, #0x6, 0x1b24 <_llm_rows.packet_batch.blocks+0x17dc>
    1ad0:      	add	x14, x10, #0x18
    1ad4:      	st1.s	{ v29 }[2], [x14]
    1ad8:      	tbz	w12, #0x7, 0x1a30 <_llm_rows.packet_batch.blocks+0x16e8>
    1adc:      	b	0x1b28 <_llm_rows.packet_batch.blocks+0x17e0>
    1ae0:      	and	w12, w12, #0xff
    1ae4:      	tbz	w12, #0x1, 0x1aa0 <_llm_rows.packet_batch.blocks+0x1758>
    1ae8:      	add	x14, x10, #0x4
    1aec:      	st1.s	{ v13 }[1], [x14]
    1af0:      	tbnz	w12, #0x2, 0x1aa4 <_llm_rows.packet_batch.blocks+0x175c>
    1af4:      	tbz	w12, #0x3, 0x1ab0 <_llm_rows.packet_batch.blocks+0x1768>
    1af8:      	add	x14, x10, #0xc
    1afc:      	st1.s	{ v13 }[3], [x14]
    1b00:      	fmul.4s	v29, v29, v30
    1b04:      	fmul.4s	v30, v11, v12
    1b08:      	fsub.4s	v29, v29, v30
    1b0c:      	and.16b	v29, v6, v29
    1b10:      	tbnz	w12, #0x4, 0x1ac4 <_llm_rows.packet_batch.blocks+0x177c>
    1b14:      	tbz	w12, #0x5, 0x1acc <_llm_rows.packet_batch.blocks+0x1784>
    1b18:      	add	x14, x10, #0x14
    1b1c:      	st1.s	{ v29 }[1], [x14]
    1b20:      	tbnz	w12, #0x6, 0x1ad0 <_llm_rows.packet_batch.blocks+0x1788>
    1b24:      	tbz	w12, #0x7, 0x1a30 <_llm_rows.packet_batch.blocks+0x16e8>
    1b28:      	add	x10, x10, #0x1c
    1b2c:      	st1.s	{ v29 }[3], [x10]
    1b30:      	b	0x1a30 <_llm_rows.packet_batch.blocks+0x16e8>
    1b34:      	ldr	q5, [sp, #0xc0]
    1b38:      	fmul.4s	v5, v5, v2
    1b3c:      	fmul.4s	v21, v10, v4
    1b40:      	fsub.4s	v5, v5, v21
    1b44:      	zip1.8b	v21, v19, v0
    1b48:      	ushll.4s	v21, v21, #0x0
    1b4c:      	shl.4s	v21, v21, #0x1f
    1b50:      	cmlt.4s	v21, v21, #0
    1b54:      	and.16b	v5, v21, v5
    1b58:      	fmov	w10, s31
    1b5c:      	ldr	q21, [sp, #0x50]
    1b60:      	ldp	q22, q23, [sp, #0x30]
    1b64:      	stp	q21, q22, [sp, #0x2e0]
    1b68:      	ldr	q18, [sp, #0x20]
    1b6c:      	stp	q23, q18, [sp, #0x300]
    1b70:      	and	x12, x13, #0x7
    1b74:      	add	x14, sp, #0x2e0
    1b78:      	ldr	x12, [x14, x12, lsl #3]
    1b7c:      	sub	x12, x12, x13
    1b80:      	add	x12, x8, x12, lsl #2
    1b84:      	tbz	w10, #0x0, 0x1ba4 <_llm_rows.packet_batch.blocks+0x185c>
    1b88:      	str	s5, [x12]
    1b8c:      	tbnz	w10, #0x1, 0x1ba8 <_llm_rows.packet_batch.blocks+0x1860>
    1b90:      	tbz	w10, #0x2, 0x1bb4 <_llm_rows.packet_batch.blocks+0x186c>
    1b94:      	add	x14, x12, #0x8
    1b98:      	st1.s	{ v5 }[2], [x14]
    1b9c:      	tbnz	w10, #0x3, 0x1bb8 <_llm_rows.packet_batch.blocks+0x1870>
    1ba0:      	b	0x1bc0 <_llm_rows.packet_batch.blocks+0x1878>
    1ba4:      	tbz	w10, #0x1, 0x1b90 <_llm_rows.packet_batch.blocks+0x1848>
    1ba8:      	add	x14, x12, #0x4
    1bac:      	st1.s	{ v5 }[1], [x14]
    1bb0:      	tbnz	w10, #0x2, 0x1b94 <_llm_rows.packet_batch.blocks+0x184c>
    1bb4:      	tbz	w10, #0x3, 0x1bc0 <_llm_rows.packet_batch.blocks+0x1878>
    1bb8:      	add	x14, x12, #0xc
    1bbc:      	st1.s	{ v5 }[3], [x14]
    1bc0:      	fmul.4s	v5, v17, v1
    1bc4:      	fmul.4s	v21, v9, v3
    1bc8:      	fsub.4s	v5, v5, v21
    1bcc:      	zip2.8b	v21, v19, v0
    1bd0:      	ushll.4s	v21, v21, #0x0
    1bd4:      	shl.4s	v21, v21, #0x1f
    1bd8:      	cmlt.4s	v21, v21, #0
    1bdc:      	and.16b	v5, v21, v5
    1be0:      	tbz	w10, #0x4, 0x1c00 <_llm_rows.packet_batch.blocks+0x18b8>
    1be4:      	str	s5, [x12, #0x10]
    1be8:      	tbnz	w10, #0x5, 0x1c04 <_llm_rows.packet_batch.blocks+0x18bc>
    1bec:      	tbz	w10, #0x6, 0x1c10 <_llm_rows.packet_batch.blocks+0x18c8>
    1bf0:      	add	x14, x12, #0x18
    1bf4:      	st1.s	{ v5 }[2], [x14]
    1bf8:      	tbnz	w10, #0x7, 0x1c14 <_llm_rows.packet_batch.blocks+0x18cc>
    1bfc:      	b	0x1c1c <_llm_rows.packet_batch.blocks+0x18d4>
    1c00:      	tbz	w10, #0x5, 0x1bec <_llm_rows.packet_batch.blocks+0x18a4>
    1c04:      	add	x14, x12, #0x14
    1c08:      	st1.s	{ v5 }[1], [x14]
    1c0c:      	tbnz	w10, #0x6, 0x1bf0 <_llm_rows.packet_batch.blocks+0x18a8>
    1c10:      	tbz	w10, #0x7, 0x1c1c <_llm_rows.packet_batch.blocks+0x18d4>
    1c14:      	add	x10, x12, #0x1c
    1c18:      	st1.s	{ v5 }[3], [x10]
    1c1c:      	mov	x10, #0x0               ; =0
    1c20:      	add	x9, x9, #0xc04
    1c24:      	movi.2d	v5, #0000000000000000
    1c28:      	movi.2d	v21, #0000000000000000
    1c2c:      	movi.2d	v22, #0000000000000000
    1c30:      	movi.2d	v23, #0000000000000000
    1c34:      	b	0x1c5c <_llm_rows.packet_batch.blocks+0x1914>
    1c38:      	add.2d	v28, v5, v27
    1c3c:      	add.2d	v21, v21, v25
    1c40:      	add.2d	v22, v22, v26
    1c44:      	add.2d	v23, v23, v24
    1c48:      	fmov	x10, d5
    1c4c:      	add	x10, x10, x11
    1c50:      	mov.16b	v5, v28
    1c54:      	cmp	x10, #0x60
    1c58:      	b.ge	0x1d3c <_llm_rows.packet_batch.blocks+0x19f4>
    1c5c:      	fmov	w12, s7
    1c60:      	lsl	x10, x10, #5
    1c64:      	add	x14, x5, x10
    1c68:      	ldp	q30, q28, [x14]
    1c6c:      	add	x14, x21, x10
    1c70:      	ldp	q8, q29, [x14]
    1c74:      	fmul.4s	v8, v30, v8
    1c78:      	add	x14, x27, x10
    1c7c:      	ldp	q12, q30, [x14]
    1c80:      	add	x14, x19, x10
    1c84:      	ldp	q13, q11, [x14]
    1c88:      	fmul.4s	v12, v12, v13
    1c8c:      	fadd.4s	v8, v8, v12
    1c90:      	and.16b	v12, v0, v8
    1c94:      	add	x10, x9, x10
    1c98:      	tbz	w12, #0x0, 0x1ce8 <_llm_rows.packet_batch.blocks+0x19a0>
    1c9c:      	str	s12, [x10]
    1ca0:      	and	w12, w12, #0xff
    1ca4:      	tbnz	w12, #0x1, 0x1cf0 <_llm_rows.packet_batch.blocks+0x19a8>
    1ca8:      	tbz	w12, #0x2, 0x1cfc <_llm_rows.packet_batch.blocks+0x19b4>
    1cac:      	add	x14, x10, #0x8
    1cb0:      	st1.s	{ v12 }[2], [x14]
    1cb4:      	tbnz	w12, #0x3, 0x1d00 <_llm_rows.packet_batch.blocks+0x19b8>
    1cb8:      	fmul.4s	v28, v28, v29
    1cbc:      	fmul.4s	v29, v30, v11
    1cc0:      	fadd.4s	v28, v28, v29
    1cc4:      	and.16b	v28, v6, v28
    1cc8:      	tbz	w12, #0x4, 0x1d1c <_llm_rows.packet_batch.blocks+0x19d4>
    1ccc:      	str	s28, [x10, #0x10]
    1cd0:      	tbnz	w12, #0x5, 0x1d20 <_llm_rows.packet_batch.blocks+0x19d8>
    1cd4:      	tbz	w12, #0x6, 0x1d2c <_llm_rows.packet_batch.blocks+0x19e4>
    1cd8:      	add	x14, x10, #0x18
    1cdc:      	st1.s	{ v28 }[2], [x14]
    1ce0:      	tbz	w12, #0x7, 0x1c38 <_llm_rows.packet_batch.blocks+0x18f0>
    1ce4:      	b	0x1d30 <_llm_rows.packet_batch.blocks+0x19e8>
    1ce8:      	and	w12, w12, #0xff
    1cec:      	tbz	w12, #0x1, 0x1ca8 <_llm_rows.packet_batch.blocks+0x1960>
    1cf0:      	add	x14, x10, #0x4
    1cf4:      	st1.s	{ v12 }[1], [x14]
    1cf8:      	tbnz	w12, #0x2, 0x1cac <_llm_rows.packet_batch.blocks+0x1964>
    1cfc:      	tbz	w12, #0x3, 0x1cb8 <_llm_rows.packet_batch.blocks+0x1970>
    1d00:      	add	x14, x10, #0xc
    1d04:      	st1.s	{ v12 }[3], [x14]
    1d08:      	fmul.4s	v28, v28, v29
    1d0c:      	fmul.4s	v29, v30, v11
    1d10:      	fadd.4s	v28, v28, v29
    1d14:      	and.16b	v28, v6, v28
    1d18:      	tbnz	w12, #0x4, 0x1ccc <_llm_rows.packet_batch.blocks+0x1984>
    1d1c:      	tbz	w12, #0x5, 0x1cd4 <_llm_rows.packet_batch.blocks+0x198c>
    1d20:      	add	x14, x10, #0x14
    1d24:      	st1.s	{ v28 }[1], [x14]
    1d28:      	tbnz	w12, #0x6, 0x1cd8 <_llm_rows.packet_batch.blocks+0x1990>
    1d2c:      	tbz	w12, #0x7, 0x1c38 <_llm_rows.packet_batch.blocks+0x18f0>
    1d30:      	add	x10, x10, #0x1c
    1d34:      	st1.s	{ v28 }[3], [x10]
    1d38:      	b	0x1c38 <_llm_rows.packet_batch.blocks+0x18f0>
    1d3c:      	ldr	q0, [sp, #0xc0]
    1d40:      	fmul.4s	v0, v0, v4
    1d44:      	fmul.4s	v2, v10, v2
    1d48:      	fadd.4s	v0, v2, v0
    1d4c:      	zip1.8b	v2, v19, v0
    1d50:      	ushll.4s	v2, v2, #0x0
    1d54:      	shl.4s	v2, v2, #0x1f
    1d58:      	cmlt.4s	v2, v2, #0
    1d5c:      	and.16b	v0, v2, v0
    1d60:      	fmov	w9, s31
    1d64:      	stp	q20, q16, [sp, #0x290]
    1d68:      	ldr	q2, [sp, #0x10]
    1d6c:      	stp	q15, q2, [sp, #0x2b0]
    1d70:      	and	x10, x13, #0x7
    1d74:      	add	x11, sp, #0x290
    1d78:      	ldr	x10, [x11, x10, lsl #3]
    1d7c:      	sub	x10, x10, x13
    1d80:      	add	x8, x8, x10, lsl #2
    1d84:      	tbz	w9, #0x0, 0x1dac <_llm_rows.packet_batch.blocks+0x1a64>
    1d88:      	str	s0, [x8]
    1d8c:      	ldr	d12, [sp, #0x8]
    1d90:      	ldr	q10, [sp, #0x120]
    1d94:      	tbnz	w9, #0x1, 0x1db8 <_llm_rows.packet_batch.blocks+0x1a70>
    1d98:      	tbz	w9, #0x2, 0x1dc4 <_llm_rows.packet_batch.blocks+0x1a7c>
    1d9c:      	add	x10, x8, #0x8
    1da0:      	st1.s	{ v0 }[2], [x10]
    1da4:      	tbnz	w9, #0x3, 0x1dc8 <_llm_rows.packet_batch.blocks+0x1a80>
    1da8:      	b	0x1dd0 <_llm_rows.packet_batch.blocks+0x1a88>
    1dac:      	ldr	d12, [sp, #0x8]
    1db0:      	ldr	q10, [sp, #0x120]
    1db4:      	tbz	w9, #0x1, 0x1d98 <_llm_rows.packet_batch.blocks+0x1a50>
    1db8:      	add	x10, x8, #0x4
    1dbc:      	st1.s	{ v0 }[1], [x10]
    1dc0:      	tbnz	w9, #0x2, 0x1d9c <_llm_rows.packet_batch.blocks+0x1a54>
    1dc4:      	tbz	w9, #0x3, 0x1dd0 <_llm_rows.packet_batch.blocks+0x1a88>
    1dc8:      	add	x10, x8, #0xc
    1dcc:      	st1.s	{ v0 }[3], [x10]
    1dd0:      	fmul.4s	v0, v17, v3
    1dd4:      	fmul.4s	v1, v9, v1
    1dd8:      	fadd.4s	v0, v1, v0
    1ddc:      	zip2.8b	v1, v19, v0
    1de0:      	ushll.4s	v1, v1, #0x0
    1de4:      	shl.4s	v1, v1, #0x1f
    1de8:      	cmlt.4s	v1, v1, #0
    1dec:      	and.16b	v0, v1, v0
    1df0:      	tbnz	w9, #0x4, 0x1008 <_llm_rows.packet_batch.blocks+0xcc0>
    1df4:      	tbz	w9, #0x5, 0x1010 <_llm_rows.packet_batch.blocks+0xcc8>
    1df8:      	add	x10, x8, #0x14
    1dfc:      	st1.s	{ v0 }[1], [x10]
    1e00:      	tbnz	w9, #0x6, 0x1014 <_llm_rows.packet_batch.blocks+0xccc>
    1e04:      	tbz	w9, #0x7, 0x420 <_llm_rows.packet_batch.blocks+0xd8>
    1e08:      	add	x8, x8, #0x1c
    1e0c:      	st1.s	{ v0 }[3], [x8]
    1e10:      	b	0x420 <_llm_rows.packet_batch.blocks+0xd8>
    1e14:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    1e18:      	add	sp, sp, #0x4e0
    1e1c:      	ldp	x29, x30, [sp, #0x90]
    1e20:      	ldp	x20, x19, [sp, #0x80]
    1e24:      	ldp	x22, x21, [sp, #0x70]
    1e28:      	ldp	x24, x23, [sp, #0x60]
    1e2c:      	ldp	x26, x25, [sp, #0x50]
    1e30:      	ldp	x28, x27, [sp, #0x40]
    1e34:      	ldp	d9, d8, [sp, #0x30]
    1e38:      	ldp	d11, d10, [sp, #0x20]
    1e3c:      	ldp	d13, d12, [sp, #0x10]
    1e40:      	ldp	d15, d14, [sp], #0xa0
    1e44:      	ret

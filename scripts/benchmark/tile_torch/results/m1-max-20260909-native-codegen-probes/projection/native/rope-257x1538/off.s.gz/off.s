
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/rope-257x1538/off/object/tile_xir_w8_38089_1788936548164039_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x28, x27, [sp, #-0x60]!
       4:      	stp	x26, x25, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	stp	x29, x30, [sp, #0x50]
      18:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      1c:      	sub	sp, sp, #0xd0
      20:      	ldr	x23, [x0]
      24:      	ldr	x22, [x0, #0x10]
      28:      	ldr	x21, [x0, #0x20]
      2c:      	ldr	w8, [x1]
      30:      	ldr	w9, [x1, #0x24]
      34:      	add	w8, w9, w8, lsl #5
      38:      	lsr	w8, w8, #3
      3c:      	dup.2s	v0, w8
      40:      	ldr	x20, [x0, #0x30]
      44:      	ushll.2d	v0, v0, #0x0
      48:      	subs	x8, x23, x20
      4c:      	mov	w9, #0x2007             ; =8199
      50:      	movk	w9, #0x18, lsl #16
      54:      	ccmp	x8, x9, #0x0, hs
      58:      	cset	w8, hi
      5c:      	subs	x10, x20, x23
      60:      	ccmp	x10, x9, #0x0, hs
      64:      	csinc	w10, w8, wzr, ls
      68:      	subs	x8, x22, x20
      6c:      	ccmp	x8, x9, #0x0, hs
      70:      	cset	w8, hi
      74:      	subs	x11, x20, x22
      78:      	mov	w12, #0x1003            ; =4099
      7c:      	movk	w12, #0xc, lsl #16
      80:      	ccmp	x11, x12, #0x0, hs
      84:      	csinc	w8, w8, wzr, ls
      88:      	subs	x11, x21, x20
      8c:      	ccmp	x11, x9, #0x0, hs
      90:      	cset	w9, hi
      94:      	subs	x11, x20, x21
      98:      	ccmp	x11, x12, #0x0, hs
      9c:      	csinc	w9, w9, wzr, ls
      a0:      	cmp	w9, #0x1
      a4:      	ccmp	w10, #0x0, #0x4, eq
      a8:      	b.eq	0x1b0 <ltmp0+0x1b0>
      ac:      	tbz	w8, #0x0, 0x1b0 <ltmp0+0x1b0>
      b0:      	mov	x9, #0x0                ; =0
      b4:      	mov	w8, #0x602              ; =1538
      b8:      	dup.2s	v1, w8
      bc:      	xtn.2s	v2, v0
      c0:      	umull.2d	v1, v2, v1
      c4:      	fmov	x11, d1
      c8:      	fmov	x8, d0
      cc:      	mov	w10, #0x301             ; =769
      d0:      	umull	x10, w8, w10
      d4:      	lsl	x11, x11, #2
      d8:      	add	x12, x11, #0xc04
      dc:      	add	x11, x23, x12
      e0:      	add	x12, x20, x12
      e4:      	fmov	d2, x9
      e8:      	add.2d	v2, v2, v1
      ec:      	fmov	x13, d2
      f0:      	lsl	x13, x13, #2
      f4:      	add	x14, x23, x13
      f8:      	ldp	q2, q3, [x14]
      fc:      	ldp	q4, q5, [x11], #0x20
     100:      	add	x14, x9, x10
     104:      	lsl	x14, x14, #2
     108:      	add	x15, x22, x14
     10c:      	ldp	q6, q7, [x15]
     110:      	add	x14, x21, x14
     114:      	ldp	q16, q17, [x14]
     118:      	fmul.4s	v18, v3, v7
     11c:      	fmul.4s	v19, v2, v6
     120:      	fmul.4s	v20, v5, v17
     124:      	fmul.4s	v21, v4, v16
     128:      	fsub.4s	v19, v19, v21
     12c:      	fsub.4s	v18, v18, v20
     130:      	add	x13, x20, x13
     134:      	stp	q19, q18, [x13]
     138:      	fmul.4s	v3, v3, v17
     13c:      	fmul.4s	v2, v2, v16
     140:      	fmul.4s	v5, v5, v7
     144:      	fmul.4s	v4, v4, v6
     148:      	fadd.4s	v2, v4, v2
     14c:      	fadd.4s	v3, v5, v3
     150:      	stp	q2, q3, [x12], #0x20
     154:      	add	x9, x9, #0x8
     158:      	cmp	x9, #0x300
     15c:      	b.ne	0xe4 <ltmp0+0xe4>
     160:      	fmov	x9, d0
     164:      	mov	w10, #0x1808            ; =6152
     168:      	umull	x11, w9, w10
     16c:      	add	x11, x11, #0xc00
     170:      	ldr	s0, [x23, x11]
     174:      	mov	w12, #0x1804            ; =6148
     178:      	umaddl	x19, w9, w10, x12
     17c:      	ldr	s1, [x23, x19]
     180:      	mov	w9, #0xc04              ; =3076
     184:      	umull	x8, w8, w9
     188:      	add	x8, x8, #0xc00
     18c:      	ldr	s2, [x22, x8]
     190:      	ldr	s3, [x21, x8]
     194:      	fmul.4s	v4, v0, v2
     198:      	fmul.4s	v5, v1, v3
     19c:      	fsub.4s	v4, v4, v5
     1a0:      	str	s4, [x20, x11]
     1a4:      	fmul.4s	v0, v0, v3
     1a8:      	fmul.4s	v1, v1, v2
     1ac:      	b	0x360 <ltmp0+0x360>
     1b0:      	fmov	x28, d0
     1b4:      	mov	w8, #0x1808             ; =6152
     1b8:      	umull	x24, w28, w8
     1bc:      	umaddl	x19, w28, w8, x23
     1c0:      	mov	w25, #0x1808            ; =6152
     1c4:      	add	x26, sp, #0x2, lsl #12  ; =0x2000
     1c8:      	add	x26, x26, #0x4b0
     1cc:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     1d0:      	add	x0, x0, #0x4b0
     1d4:      	mov	x1, x19
     1d8:      	mov	w2, #0xc00              ; =3072
     1dc:      	bl	0x1dc <ltmp0+0x1dc>
     1e0:      	str	x24, [sp, #0x28]
     1e4:      	add	x8, x24, #0xc00
     1e8:      	str	x8, [sp, #0x8]
     1ec:      	ldr	s0, [x23, x8]
     1f0:      	str	q0, [sp, #0x40]
     1f4:      	str	q0, [sp, #0x30b0]
     1f8:      	add	x27, sp, #0x1, lsl #12  ; =0x1000
     1fc:      	add	x27, x27, #0x890
     200:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     204:      	add	x0, x0, #0x890
     208:      	add	x1, x19, #0xc04
     20c:      	mov	w2, #0xc00              ; =3072
     210:      	bl	0x210 <ltmp0+0x210>
     214:      	mov	w8, #0x1804             ; =6148
     218:      	umaddl	x19, w28, w25, x8
     21c:      	ldr	s0, [x23, x19]
     220:      	str	q0, [sp, #0x30]
     224:      	str	q0, [sp, #0x2490]
     228:      	mov	w25, #0xc04             ; =3076
     22c:      	umull	x24, w28, w25
     230:      	umaddl	x1, w28, w25, x22
     234:      	add	x23, sp, #0xc70
     238:      	add	x0, sp, #0xc70
     23c:      	mov	w2, #0xc00              ; =3072
     240:      	bl	0x240 <ltmp0+0x240>
     244:      	add	x24, x24, #0xc00
     248:      	ldr	s0, [x22, x24]
     24c:      	str	q0, [sp, #0x10]
     250:      	str	q0, [sp, #0x1870]
     254:      	umaddl	x1, w28, w25, x21
     258:      	add	x22, sp, #0x50
     25c:      	add	x0, sp, #0x50
     260:      	mov	w2, #0xc00              ; =3072
     264:      	bl	0x264 <ltmp0+0x264>
     268:      	mov	x8, #0x0                ; =0
     26c:      	ldr	s0, [x21, x24]
     270:      	str	q0, [sp, #0xc50]
     274:      	mov	w9, #0x1808             ; =6152
     278:      	umaddl	x9, w28, w9, x20
     27c:      	add	x10, x26, x8
     280:      	ldp	q1, q2, [x10]
     284:      	add	x10, x23, x8
     288:      	ldp	q3, q4, [x10]
     28c:      	fmul.4s	v2, v2, v4
     290:      	fmul.4s	v1, v1, v3
     294:      	add	x10, x27, x8
     298:      	ldp	q3, q4, [x10]
     29c:      	add	x10, x22, x8
     2a0:      	ldp	q5, q6, [x10]
     2a4:      	fmul.4s	v4, v4, v6
     2a8:      	fmul.4s	v3, v3, v5
     2ac:      	fsub.4s	v1, v1, v3
     2b0:      	fsub.4s	v2, v2, v4
     2b4:      	add	x10, x9, x8
     2b8:      	stp	q1, q2, [x10]
     2bc:      	add	x8, x8, #0x20
     2c0:      	cmp	x8, #0xc00
     2c4:      	b.ne	0x27c <ltmp0+0x27c>
     2c8:      	mov	x8, #0x0                ; =0
     2cc:      	ldp	q16, q7, [sp, #0x30]
     2d0:      	ldr	q17, [sp, #0x10]
     2d4:      	fmul.4s	v1, v7, v17
     2d8:      	fmul.4s	v2, v16, v0
     2dc:      	fsub.4s	v1, v1, v2
     2e0:      	ldr	x9, [sp, #0x8]
     2e4:      	str	s1, [x20, x9]
     2e8:      	ldr	x9, [sp, #0x28]
     2ec:      	add	x9, x20, x9
     2f0:      	add	x9, x9, #0xc04
     2f4:      	add	x10, sp, #0x2, lsl #12  ; =0x2000
     2f8:      	add	x10, x10, #0x4b0
     2fc:      	add	x11, sp, #0x50
     300:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
     304:      	add	x12, x12, #0x890
     308:      	add	x13, sp, #0xc70
     30c:      	add	x14, x10, x8
     310:      	ldp	q1, q2, [x14]
     314:      	add	x14, x11, x8
     318:      	ldp	q3, q4, [x14]
     31c:      	fmul.4s	v2, v2, v4
     320:      	fmul.4s	v1, v1, v3
     324:      	add	x14, x12, x8
     328:      	ldp	q3, q4, [x14]
     32c:      	add	x14, x13, x8
     330:      	ldp	q5, q6, [x14]
     334:      	fmul.4s	v4, v4, v6
     338:      	fmul.4s	v3, v3, v5
     33c:      	fadd.4s	v1, v1, v3
     340:      	fadd.4s	v2, v2, v4
     344:      	add	x14, x9, x8
     348:      	stp	q1, q2, [x14]
     34c:      	add	x8, x8, #0x20
     350:      	cmp	x8, #0xc00
     354:      	b.ne	0x30c <ltmp0+0x30c>
     358:      	fmul.4s	v0, v7, v0
     35c:      	fmul.4s	v1, v16, v17
     360:      	fadd.4s	v0, v1, v0
     364:      	str	s0, [x20, x19]
     368:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
     36c:      	add	sp, sp, #0xd0
     370:      	ldp	x29, x30, [sp, #0x50]
     374:      	ldp	x20, x19, [sp, #0x40]
     378:      	ldp	x22, x21, [sp, #0x30]
     37c:      	ldp	x24, x23, [sp, #0x20]
     380:      	ldp	x26, x25, [sp, #0x10]
     384:      	ldp	x28, x27, [sp], #0x60
     388:      	ret

000000000000038c <_llm_rows.packet_batch.blocks>:
     38c:      	stp	d15, d14, [sp, #-0xa0]!
     390:      	stp	d13, d12, [sp, #0x10]
     394:      	stp	d11, d10, [sp, #0x20]
     398:      	stp	d9, d8, [sp, #0x30]
     39c:      	stp	x28, x27, [sp, #0x40]
     3a0:      	stp	x26, x25, [sp, #0x50]
     3a4:      	stp	x24, x23, [sp, #0x60]
     3a8:      	stp	x22, x21, [sp, #0x70]
     3ac:      	stp	x20, x19, [sp, #0x80]
     3b0:      	stp	x29, x30, [sp, #0x90]
     3b4:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
     3b8:      	sub	sp, sp, #0x4e0
     3bc:      	str	x0, [sp, #0x138]
     3c0:      	cbz	w3, 0x1de0 <_llm_rows.packet_batch.blocks+0x1a54>
     3c4:      	mov	x24, x3
     3c8:      	mov	x20, x2
     3cc:      	mov	w22, #0x0               ; =0
     3d0:      	ldp	w9, w8, [x2, #0x2c]
     3d4:      	str	w9, [sp, #0x11c]
     3d8:      	str	w8, [sp, #0x118]
     3dc:      	mov	w8, #0x602              ; =1538
     3e0:      	ldp	w28, w23, [x2]
     3e4:      	ldp	w25, w9, [x2, #0x8]
     3e8:      	str	x9, [sp, #0x110]
     3ec:      	adrp	x9, 0x0 <ltmp0>
     3f0:      	ldr	q0, [x9]
     3f4:      	str	q0, [sp, #0xf0]
     3f8:      	adrp	x9, 0x0 <ltmp0>
     3fc:      	ldr	q0, [x9]
     400:      	str	q0, [sp, #0xe0]
     404:      	adrp	x9, 0x0 <ltmp0>
     408:      	ldr	q0, [x9]
     40c:      	str	q0, [sp, #0xb0]
     410:      	adrp	x9, 0x0 <ltmp0>
     414:      	ldr	q0, [x9]
     418:      	str	q0, [sp, #0xa0]
     41c:      	adrp	x9, 0x0 <ltmp0>
     420:      	ldr	q0, [x9]
     424:      	str	q0, [sp, #0x90]
     428:      	adrp	x9, 0x0 <ltmp0>
     42c:      	ldr	q0, [x9]
     430:      	str	q0, [sp, #0x80]
     434:      	dup.2s	v10, w8
     438:      	adrp	x8, 0x0 <ltmp0>
     43c:      	ldr	q15, [x8]
     440:      	add	x27, sp, #0x1, lsl #12  ; =0x1000
     444:      	add	x27, x27, #0xca0
     448:      	add	x19, sp, #0x1, lsl #12  ; =0x1000
     44c:      	add	x19, x19, #0x80
     450:      	add	x21, sp, #0x460
     454:      	str	q15, [sp, #0x120]
     458:      	str	w3, [sp, #0x10c]
     45c:      	str	d10, [sp, #0x8]
     460:      	b	0x4ac <_llm_rows.packet_batch.blocks+0x120>
     464:      	mov	w8, #0x18               ; =24
     468:      	str	w8, [x20, #0x24]
     46c:      	ldr	w24, [sp, #0x10c]
     470:      	add	w8, w28, #0x1
     474:      	ldr	w9, [sp, #0x11c]
     478:      	cmp	w8, w9
     47c:      	cset	w8, eq
     480:      	csinc	w28, wzr, w28, eq
     484:      	cinc	w9, w23, eq
     488:      	ldr	w10, [sp, #0x118]
     48c:      	cmp	w9, w10
     490:      	cset	w10, eq
     494:      	ands	w8, w8, w10
     498:      	csel	w23, wzr, w9, ne
     49c:      	add	w25, w25, w8
     4a0:      	add	w22, w22, #0x1
     4a4:      	cmp	w22, w24
     4a8:      	b.eq	0x1de0 <_llm_rows.packet_batch.blocks+0x1a54>
     4ac:      	ubfiz	x8, x28, #5, #32
     4b0:      	ldr	x12, [sp, #0x110]
     4b4:      	cmp	x8, x12
     4b8:      	csel	x9, x8, xzr, ls
     4bc:      	subs	x10, x12, x9
     4c0:      	cmp	x10, #0x20
     4c4:      	mov	w11, #0x20              ; =32
     4c8:      	csel	x10, x10, x11, lo
     4cc:      	cmp	x12, x9
     4d0:      	stp	w28, w23, [x20]
     4d4:      	str	w25, [x20, #0x8]
     4d8:      	str	wzr, [x20, #0x24]
     4dc:      	ccmp	x8, x12, #0x2, hi
     4e0:      	csel	x26, x10, xzr, ls
     4e4:      	cmp	x26, #0x20
     4e8:      	b.lo	0x540 <_llm_rows.packet_batch.blocks+0x1b4>
     4ec:      	ldr	x26, [sp, #0x138]
     4f0:      	mov	x0, x26
     4f4:      	mov	x1, x20
     4f8:      	bl	0x4f8 <_llm_rows.packet_batch.blocks+0x16c>
     4fc:      	mov	w8, #0x8                ; =8
     500:      	str	w8, [x20, #0x24]
     504:      	mov	x0, x26
     508:      	mov	x1, x20
     50c:      	bl	0x50c <_llm_rows.packet_batch.blocks+0x180>
     510:      	mov	w8, #0x10               ; =16
     514:      	str	w8, [x20, #0x24]
     518:      	mov	x0, x26
     51c:      	mov	x1, x20
     520:      	bl	0x520 <_llm_rows.packet_batch.blocks+0x194>
     524:      	mov	w8, #0x18               ; =24
     528:      	str	w8, [x20, #0x24]
     52c:      	mov	x0, x26
     530:      	mov	x1, x20
     534:      	bl	0x534 <_llm_rows.packet_batch.blocks+0x1a8>
     538:      	ldr	q15, [sp, #0x120]
     53c:      	b	0x470 <_llm_rows.packet_batch.blocks+0xe4>
     540:      	lsr	x24, x26, #3
     544:      	cmp	x26, #0x8
     548:      	b.lo	0x5a0 <_llm_rows.packet_batch.blocks+0x214>
     54c:      	str	wzr, [x20, #0x24]
     550:      	ldr	x0, [sp, #0x138]
     554:      	mov	x1, x20
     558:      	bl	0x558 <_llm_rows.packet_batch.blocks+0x1cc>
     55c:      	ldr	q15, [sp, #0x120]
     560:      	cmp	x24, #0x1
     564:      	b.eq	0x5a0 <_llm_rows.packet_batch.blocks+0x214>
     568:      	mov	w8, #0x8                ; =8
     56c:      	str	w8, [x20, #0x24]
     570:      	ldr	x0, [sp, #0x138]
     574:      	mov	x1, x20
     578:      	bl	0x578 <_llm_rows.packet_batch.blocks+0x1ec>
     57c:      	ldr	q15, [sp, #0x120]
     580:      	cmp	x24, #0x2
     584:      	b.eq	0x5a0 <_llm_rows.packet_batch.blocks+0x214>
     588:      	mov	w8, #0x10               ; =16
     58c:      	str	w8, [x20, #0x24]
     590:      	ldr	x0, [sp, #0x138]
     594:      	mov	x1, x20
     598:      	bl	0x598 <_llm_rows.packet_batch.blocks+0x20c>
     59c:      	ldr	q15, [sp, #0x120]
     5a0:      	and	w8, w26, #0x7
     5a4:      	cbz	w8, 0x464 <_llm_rows.packet_batch.blocks+0xd8>
     5a8:      	dup.4s	v0, w8
     5ac:      	ldp	q2, q1, [sp, #0xe0]
     5b0:      	cmhi.4s	v6, v0, v2
     5b4:      	cmhi.4s	v0, v0, v1
     5b8:      	uzp1.8h	v22, v0, v6
     5bc:      	umaxv.8h	h1, v22
     5c0:      	fmov	w8, s1
     5c4:      	tbz	w8, #0x0, 0x464 <_llm_rows.packet_batch.blocks+0xd8>
     5c8:      	ldr	x8, [sp, #0x138]
     5cc:      	ldr	x11, [x8]
     5d0:      	ldr	x10, [x8, #0x10]
     5d4:      	ldr	x9, [x8, #0x20]
     5d8:      	ldr	x8, [x8, #0x30]
     5dc:      	sshll.2d	v1, v0, #0x0
     5e0:      	sshll.2d	v2, v6, #0x0
     5e4:      	sshll2.2d	v23, v0, #0x0
     5e8:      	sshll2.2d	v21, v6, #0x0
     5ec:      	ldp	q3, q4, [sp, #0xa0]
     5f0:      	and.16b	v16, v21, v4
     5f4:      	and.16b	v13, v23, v3
     5f8:      	ldr	q3, [sp, #0x90]
     5fc:      	and.16b	v17, v2, v3
     600:      	ldr	q2, [sp, #0x80]
     604:      	and.16b	v20, v1, v2
     608:      	ubfiz	w12, w28, #2, #27
     60c:      	orr	w12, w12, w24
     610:      	dup.4s	v1, w12
     614:      	and.16b	v2, v0, v1
     618:      	and.16b	v1, v6, v1
     61c:      	ushll2.2d	v5, v1, #0x0
     620:      	ushll2.2d	v4, v2, #0x0
     624:      	ushll.2d	v1, v1, #0x0
     628:      	ushll.2d	v3, v2, #0x0
     62c:      	subs	x12, x11, x8
     630:      	mov	w15, #0x2007            ; =8199
     634:      	movk	w15, #0x18, lsl #16
     638:      	ccmp	x12, x15, #0x0, hs
     63c:      	cset	w12, hi
     640:      	subs	x13, x8, x11
     644:      	ccmp	x13, x15, #0x0, hs
     648:      	csinc	w12, w12, wzr, ls
     64c:      	subs	x13, x10, x8
     650:      	ccmp	x13, x15, #0x0, hs
     654:      	cset	w13, hi
     658:      	subs	x14, x8, x10
     65c:      	mov	w16, #0x1003            ; =4099
     660:      	movk	w16, #0xc, lsl #16
     664:      	ccmp	x14, x16, #0x0, hs
     668:      	csinc	w13, w13, wzr, ls
     66c:      	subs	x14, x9, x8
     670:      	ccmp	x14, x15, #0x0, hs
     674:      	cset	w14, hi
     678:      	subs	x15, x8, x9
     67c:      	ccmp	x15, x16, #0x0, hs
     680:      	csinc	w14, w14, wzr, ls
     684:      	xtn.2s	v11, v4
     688:      	xtn.2s	v4, v1
     68c:      	xtn.2s	v5, v5
     690:      	xtn.2s	v12, v3
     694:      	mov	w15, #0x301             ; =769
     698:      	dup.2s	v2, w15
     69c:      	cmp	w14, #0x1
     6a0:      	b.ne	0x1074 <_llm_rows.packet_batch.blocks+0xce8>
     6a4:      	cbz	w12, 0x1074 <_llm_rows.packet_batch.blocks+0xce8>
     6a8:      	tbz	w13, #0x0, 0x1074 <_llm_rows.packet_batch.blocks+0xce8>
     6ac:      	mov	x12, #0x0               ; =0
     6b0:      	umull.2d	v6, v11, v10
     6b4:      	umull.2d	v19, v4, v10
     6b8:      	umull.2d	v7, v5, v10
     6bc:      	umull.2d	v21, v12, v10
     6c0:      	fmov	x13, d21
     6c4:      	add	x13, x13, #0x301
     6c8:      	fmov	x14, d3
     6cc:      	mov	w15, #0x301             ; =769
     6d0:      	umull	x14, w14, w15
     6d4:      	and.16b	v3, v22, v15
     6d8:      	addv.8h	h22, v3
     6dc:      	fmov	w15, s22
     6e0:      	b	0x6f0 <_llm_rows.packet_batch.blocks+0x364>
     6e4:      	add	x12, x12, #0x8
     6e8:      	cmp	x12, #0x300
     6ec:      	b.eq	0xaf8 <_llm_rows.packet_batch.blocks+0x76c>
     6f0:      	dup.2d	v3, x12
     6f4:      	orr.16b	v25, v3, v20
     6f8:      	add.2d	v3, v25, v21
     6fc:      	fmov	x16, d3
     700:      	lsl	x16, x16, #2
     704:      	add	x17, x11, x16
     708:      	movi.2d	v24, #0000000000000000
     70c:      	movi.2d	v23, #0000000000000000
     710:      	tbz	w15, #0x0, 0x754 <_llm_rows.packet_batch.blocks+0x3c8>
     714:      	ldr	s24, [x17]
     718:      	and	w0, w15, #0xff
     71c:      	tbnz	w0, #0x1, 0x75c <_llm_rows.packet_batch.blocks+0x3d0>
     720:      	tbz	w0, #0x2, 0x768 <_llm_rows.packet_batch.blocks+0x3dc>
     724:      	add	x1, x17, #0x8
     728:      	ld1.s	{ v24 }[2], [x1]
     72c:      	tbnz	w0, #0x3, 0x76c <_llm_rows.packet_batch.blocks+0x3e0>
     730:      	tbz	w0, #0x4, 0x778 <_llm_rows.packet_batch.blocks+0x3ec>
     734:      	add	x1, x17, #0x10
     738:      	ld1.s	{ v23 }[0], [x1]
     73c:      	tbnz	w0, #0x5, 0x77c <_llm_rows.packet_batch.blocks+0x3f0>
     740:      	tbz	w0, #0x6, 0x788 <_llm_rows.packet_batch.blocks+0x3fc>
     744:      	add	x1, x17, #0x18
     748:      	ld1.s	{ v23 }[2], [x1]
     74c:      	tbnz	w0, #0x7, 0x78c <_llm_rows.packet_batch.blocks+0x400>
     750:      	b	0x794 <_llm_rows.packet_batch.blocks+0x408>
     754:      	and	w0, w15, #0xff
     758:      	tbz	w0, #0x1, 0x720 <_llm_rows.packet_batch.blocks+0x394>
     75c:      	add	x1, x17, #0x4
     760:      	ld1.s	{ v24 }[1], [x1]
     764:      	tbnz	w0, #0x2, 0x724 <_llm_rows.packet_batch.blocks+0x398>
     768:      	tbz	w0, #0x3, 0x730 <_llm_rows.packet_batch.blocks+0x3a4>
     76c:      	add	x1, x17, #0xc
     770:      	ld1.s	{ v24 }[3], [x1]
     774:      	tbnz	w0, #0x4, 0x734 <_llm_rows.packet_batch.blocks+0x3a8>
     778:      	tbz	w0, #0x5, 0x740 <_llm_rows.packet_batch.blocks+0x3b4>
     77c:      	add	x1, x17, #0x14
     780:      	ld1.s	{ v23 }[1], [x1]
     784:      	tbnz	w0, #0x6, 0x744 <_llm_rows.packet_batch.blocks+0x3b8>
     788:      	tbz	w0, #0x7, 0x794 <_llm_rows.packet_batch.blocks+0x408>
     78c:      	add	x17, x17, #0x1c
     790:      	ld1.s	{ v23 }[3], [x17]
     794:      	fmov	w2, s22
     798:      	fmov	x0, d25
     79c:      	add	x17, x13, x0
     7a0:      	lsl	x17, x17, #2
     7a4:      	add	x1, x11, x17
     7a8:      	movi.2d	v26, #0000000000000000
     7ac:      	movi.2d	v25, #0000000000000000
     7b0:      	tbz	w2, #0x0, 0x7f4 <_llm_rows.packet_batch.blocks+0x468>
     7b4:      	ldr	s26, [x1]
     7b8:      	and	w2, w2, #0xff
     7bc:      	tbnz	w2, #0x1, 0x7fc <_llm_rows.packet_batch.blocks+0x470>
     7c0:      	tbz	w2, #0x2, 0x808 <_llm_rows.packet_batch.blocks+0x47c>
     7c4:      	add	x3, x1, #0x8
     7c8:      	ld1.s	{ v26 }[2], [x3]
     7cc:      	tbnz	w2, #0x3, 0x80c <_llm_rows.packet_batch.blocks+0x480>
     7d0:      	tbz	w2, #0x4, 0x818 <_llm_rows.packet_batch.blocks+0x48c>
     7d4:      	add	x3, x1, #0x10
     7d8:      	ld1.s	{ v25 }[0], [x3]
     7dc:      	tbnz	w2, #0x5, 0x81c <_llm_rows.packet_batch.blocks+0x490>
     7e0:      	tbz	w2, #0x6, 0x828 <_llm_rows.packet_batch.blocks+0x49c>
     7e4:      	add	x3, x1, #0x18
     7e8:      	ld1.s	{ v25 }[2], [x3]
     7ec:      	tbnz	w2, #0x7, 0x82c <_llm_rows.packet_batch.blocks+0x4a0>
     7f0:      	b	0x834 <_llm_rows.packet_batch.blocks+0x4a8>
     7f4:      	and	w2, w2, #0xff
     7f8:      	tbz	w2, #0x1, 0x7c0 <_llm_rows.packet_batch.blocks+0x434>
     7fc:      	add	x3, x1, #0x4
     800:      	ld1.s	{ v26 }[1], [x3]
     804:      	tbnz	w2, #0x2, 0x7c4 <_llm_rows.packet_batch.blocks+0x438>
     808:      	tbz	w2, #0x3, 0x7d0 <_llm_rows.packet_batch.blocks+0x444>
     80c:      	add	x3, x1, #0xc
     810:      	ld1.s	{ v26 }[3], [x3]
     814:      	tbnz	w2, #0x4, 0x7d4 <_llm_rows.packet_batch.blocks+0x448>
     818:      	tbz	w2, #0x5, 0x7e0 <_llm_rows.packet_batch.blocks+0x454>
     81c:      	add	x3, x1, #0x14
     820:      	ld1.s	{ v25 }[1], [x3]
     824:      	tbnz	w2, #0x6, 0x7e4 <_llm_rows.packet_batch.blocks+0x458>
     828:      	tbz	w2, #0x7, 0x834 <_llm_rows.packet_batch.blocks+0x4a8>
     82c:      	add	x1, x1, #0x1c
     830:      	ld1.s	{ v25 }[3], [x1]
     834:      	fmov	w2, s22
     838:      	add	x0, x0, x14
     83c:      	lsl	x0, x0, #2
     840:      	add	x1, x10, x0
     844:      	movi.2d	v28, #0000000000000000
     848:      	movi.2d	v27, #0000000000000000
     84c:      	tbz	w2, #0x0, 0x998 <_llm_rows.packet_batch.blocks+0x60c>
     850:      	ldr	s28, [x1]
     854:      	and	w2, w2, #0xff
     858:      	tbnz	w2, #0x1, 0x9a0 <_llm_rows.packet_batch.blocks+0x614>
     85c:      	tbz	w2, #0x2, 0x9ac <_llm_rows.packet_batch.blocks+0x620>
     860:      	add	x3, x1, #0x8
     864:      	ld1.s	{ v28 }[2], [x3]
     868:      	tbnz	w2, #0x3, 0x9b0 <_llm_rows.packet_batch.blocks+0x624>
     86c:      	tbz	w2, #0x4, 0x9bc <_llm_rows.packet_batch.blocks+0x630>
     870:      	add	x3, x1, #0x10
     874:      	ld1.s	{ v27 }[0], [x3]
     878:      	tbnz	w2, #0x5, 0x9c0 <_llm_rows.packet_batch.blocks+0x634>
     87c:      	tbz	w2, #0x6, 0x9cc <_llm_rows.packet_batch.blocks+0x640>
     880:      	add	x3, x1, #0x18
     884:      	ld1.s	{ v27 }[2], [x3]
     888:      	tbnz	w2, #0x7, 0x9d0 <_llm_rows.packet_batch.blocks+0x644>
     88c:      	fmov	w1, s22
     890:      	add	x0, x9, x0
     894:      	movi.2d	v30, #0000000000000000
     898:      	movi.2d	v29, #0000000000000000
     89c:      	tbz	w1, #0x0, 0x9ec <_llm_rows.packet_batch.blocks+0x660>
     8a0:      	ldr	s30, [x0]
     8a4:      	and	w1, w1, #0xff
     8a8:      	tbnz	w1, #0x1, 0x9f4 <_llm_rows.packet_batch.blocks+0x668>
     8ac:      	tbz	w1, #0x2, 0xa00 <_llm_rows.packet_batch.blocks+0x674>
     8b0:      	add	x2, x0, #0x8
     8b4:      	ld1.s	{ v30 }[2], [x2]
     8b8:      	tbnz	w1, #0x3, 0xa04 <_llm_rows.packet_batch.blocks+0x678>
     8bc:      	tbz	w1, #0x4, 0xa10 <_llm_rows.packet_batch.blocks+0x684>
     8c0:      	add	x2, x0, #0x10
     8c4:      	ld1.s	{ v29 }[0], [x2]
     8c8:      	tbnz	w1, #0x5, 0xa14 <_llm_rows.packet_batch.blocks+0x688>
     8cc:      	tbz	w1, #0x6, 0xa20 <_llm_rows.packet_batch.blocks+0x694>
     8d0:      	add	x2, x0, #0x18
     8d4:      	ld1.s	{ v29 }[2], [x2]
     8d8:      	tbnz	w1, #0x7, 0xa24 <_llm_rows.packet_batch.blocks+0x698>
     8dc:      	fmov	w0, s22
     8e0:      	fmul.4s	v3, v24, v28
     8e4:      	fmul.4s	v31, v26, v30
     8e8:      	fsub.4s	v3, v3, v31
     8ec:      	add	x16, x8, x16
     8f0:      	tbz	w0, #0x0, 0xa44 <_llm_rows.packet_batch.blocks+0x6b8>
     8f4:      	str	s3, [x16]
     8f8:      	and	w0, w0, #0xff
     8fc:      	tbnz	w0, #0x1, 0xa4c <_llm_rows.packet_batch.blocks+0x6c0>
     900:      	tbz	w0, #0x2, 0xa58 <_llm_rows.packet_batch.blocks+0x6cc>
     904:      	add	x1, x16, #0x8
     908:      	st1.s	{ v3 }[2], [x1]
     90c:      	tbnz	w0, #0x3, 0xa5c <_llm_rows.packet_batch.blocks+0x6d0>
     910:      	fmul.4s	v3, v23, v27
     914:      	fmul.4s	v31, v25, v29
     918:      	fsub.4s	v3, v3, v31
     91c:      	tbz	w0, #0x4, 0xa74 <_llm_rows.packet_batch.blocks+0x6e8>
     920:      	str	s3, [x16, #0x10]
     924:      	tbnz	w0, #0x5, 0xa78 <_llm_rows.packet_batch.blocks+0x6ec>
     928:      	tbz	w0, #0x6, 0xa84 <_llm_rows.packet_batch.blocks+0x6f8>
     92c:      	add	x1, x16, #0x18
     930:      	st1.s	{ v3 }[2], [x1]
     934:      	tbnz	w0, #0x7, 0xa88 <_llm_rows.packet_batch.blocks+0x6fc>
     938:      	fmov	w0, s22
     93c:      	fmul.4s	v3, v24, v30
     940:      	fmul.4s	v24, v26, v28
     944:      	fadd.4s	v3, v24, v3
     948:      	add	x16, x8, x17
     94c:      	tbz	w0, #0x0, 0xaa8 <_llm_rows.packet_batch.blocks+0x71c>
     950:      	str	s3, [x16]
     954:      	and	w17, w0, #0xff
     958:      	tbnz	w17, #0x1, 0xab0 <_llm_rows.packet_batch.blocks+0x724>
     95c:      	tbz	w17, #0x2, 0xabc <_llm_rows.packet_batch.blocks+0x730>
     960:      	add	x0, x16, #0x8
     964:      	st1.s	{ v3 }[2], [x0]
     968:      	tbnz	w17, #0x3, 0xac0 <_llm_rows.packet_batch.blocks+0x734>
     96c:      	fmul.4s	v3, v23, v29
     970:      	fmul.4s	v23, v25, v27
     974:      	fadd.4s	v3, v23, v3
     978:      	tbz	w17, #0x4, 0xad8 <_llm_rows.packet_batch.blocks+0x74c>
     97c:      	str	s3, [x16, #0x10]
     980:      	tbnz	w17, #0x5, 0xadc <_llm_rows.packet_batch.blocks+0x750>
     984:      	tbz	w17, #0x6, 0xae8 <_llm_rows.packet_batch.blocks+0x75c>
     988:      	add	x0, x16, #0x18
     98c:      	st1.s	{ v3 }[2], [x0]
     990:      	tbz	w17, #0x7, 0x6e4 <_llm_rows.packet_batch.blocks+0x358>
     994:      	b	0xaec <_llm_rows.packet_batch.blocks+0x760>
     998:      	and	w2, w2, #0xff
     99c:      	tbz	w2, #0x1, 0x85c <_llm_rows.packet_batch.blocks+0x4d0>
     9a0:      	add	x3, x1, #0x4
     9a4:      	ld1.s	{ v28 }[1], [x3]
     9a8:      	tbnz	w2, #0x2, 0x860 <_llm_rows.packet_batch.blocks+0x4d4>
     9ac:      	tbz	w2, #0x3, 0x86c <_llm_rows.packet_batch.blocks+0x4e0>
     9b0:      	add	x3, x1, #0xc
     9b4:      	ld1.s	{ v28 }[3], [x3]
     9b8:      	tbnz	w2, #0x4, 0x870 <_llm_rows.packet_batch.blocks+0x4e4>
     9bc:      	tbz	w2, #0x5, 0x87c <_llm_rows.packet_batch.blocks+0x4f0>
     9c0:      	add	x3, x1, #0x14
     9c4:      	ld1.s	{ v27 }[1], [x3]
     9c8:      	tbnz	w2, #0x6, 0x880 <_llm_rows.packet_batch.blocks+0x4f4>
     9cc:      	tbz	w2, #0x7, 0x88c <_llm_rows.packet_batch.blocks+0x500>
     9d0:      	add	x1, x1, #0x1c
     9d4:      	ld1.s	{ v27 }[3], [x1]
     9d8:      	fmov	w1, s22
     9dc:      	add	x0, x9, x0
     9e0:      	movi.2d	v30, #0000000000000000
     9e4:      	movi.2d	v29, #0000000000000000
     9e8:      	tbnz	w1, #0x0, 0x8a0 <_llm_rows.packet_batch.blocks+0x514>
     9ec:      	and	w1, w1, #0xff
     9f0:      	tbz	w1, #0x1, 0x8ac <_llm_rows.packet_batch.blocks+0x520>
     9f4:      	add	x2, x0, #0x4
     9f8:      	ld1.s	{ v30 }[1], [x2]
     9fc:      	tbnz	w1, #0x2, 0x8b0 <_llm_rows.packet_batch.blocks+0x524>
     a00:      	tbz	w1, #0x3, 0x8bc <_llm_rows.packet_batch.blocks+0x530>
     a04:      	add	x2, x0, #0xc
     a08:      	ld1.s	{ v30 }[3], [x2]
     a0c:      	tbnz	w1, #0x4, 0x8c0 <_llm_rows.packet_batch.blocks+0x534>
     a10:      	tbz	w1, #0x5, 0x8cc <_llm_rows.packet_batch.blocks+0x540>
     a14:      	add	x2, x0, #0x14
     a18:      	ld1.s	{ v29 }[1], [x2]
     a1c:      	tbnz	w1, #0x6, 0x8d0 <_llm_rows.packet_batch.blocks+0x544>
     a20:      	tbz	w1, #0x7, 0x8dc <_llm_rows.packet_batch.blocks+0x550>
     a24:      	add	x0, x0, #0x1c
     a28:      	ld1.s	{ v29 }[3], [x0]
     a2c:      	fmov	w0, s22
     a30:      	fmul.4s	v3, v24, v28
     a34:      	fmul.4s	v31, v26, v30
     a38:      	fsub.4s	v3, v3, v31
     a3c:      	add	x16, x8, x16
     a40:      	tbnz	w0, #0x0, 0x8f4 <_llm_rows.packet_batch.blocks+0x568>
     a44:      	and	w0, w0, #0xff
     a48:      	tbz	w0, #0x1, 0x900 <_llm_rows.packet_batch.blocks+0x574>
     a4c:      	add	x1, x16, #0x4
     a50:      	st1.s	{ v3 }[1], [x1]
     a54:      	tbnz	w0, #0x2, 0x904 <_llm_rows.packet_batch.blocks+0x578>
     a58:      	tbz	w0, #0x3, 0x910 <_llm_rows.packet_batch.blocks+0x584>
     a5c:      	add	x1, x16, #0xc
     a60:      	st1.s	{ v3 }[3], [x1]
     a64:      	fmul.4s	v3, v23, v27
     a68:      	fmul.4s	v31, v25, v29
     a6c:      	fsub.4s	v3, v3, v31
     a70:      	tbnz	w0, #0x4, 0x920 <_llm_rows.packet_batch.blocks+0x594>
     a74:      	tbz	w0, #0x5, 0x928 <_llm_rows.packet_batch.blocks+0x59c>
     a78:      	add	x1, x16, #0x14
     a7c:      	st1.s	{ v3 }[1], [x1]
     a80:      	tbnz	w0, #0x6, 0x92c <_llm_rows.packet_batch.blocks+0x5a0>
     a84:      	tbz	w0, #0x7, 0x938 <_llm_rows.packet_batch.blocks+0x5ac>
     a88:      	add	x16, x16, #0x1c
     a8c:      	st1.s	{ v3 }[3], [x16]
     a90:      	fmov	w0, s22
     a94:      	fmul.4s	v3, v24, v30
     a98:      	fmul.4s	v24, v26, v28
     a9c:      	fadd.4s	v3, v24, v3
     aa0:      	add	x16, x8, x17
     aa4:      	tbnz	w0, #0x0, 0x950 <_llm_rows.packet_batch.blocks+0x5c4>
     aa8:      	and	w17, w0, #0xff
     aac:      	tbz	w17, #0x1, 0x95c <_llm_rows.packet_batch.blocks+0x5d0>
     ab0:      	add	x0, x16, #0x4
     ab4:      	st1.s	{ v3 }[1], [x0]
     ab8:      	tbnz	w17, #0x2, 0x960 <_llm_rows.packet_batch.blocks+0x5d4>
     abc:      	tbz	w17, #0x3, 0x96c <_llm_rows.packet_batch.blocks+0x5e0>
     ac0:      	add	x0, x16, #0xc
     ac4:      	st1.s	{ v3 }[3], [x0]
     ac8:      	fmul.4s	v3, v23, v29
     acc:      	fmul.4s	v23, v25, v27
     ad0:      	fadd.4s	v3, v23, v3
     ad4:      	tbnz	w17, #0x4, 0x97c <_llm_rows.packet_batch.blocks+0x5f0>
     ad8:      	tbz	w17, #0x5, 0x984 <_llm_rows.packet_batch.blocks+0x5f8>
     adc:      	add	x0, x16, #0x14
     ae0:      	st1.s	{ v3 }[1], [x0]
     ae4:      	tbnz	w17, #0x6, 0x988 <_llm_rows.packet_batch.blocks+0x5fc>
     ae8:      	tbz	w17, #0x7, 0x6e4 <_llm_rows.packet_batch.blocks+0x358>
     aec:      	add	x16, x16, #0x1c
     af0:      	st1.s	{ v3 }[3], [x16]
     af4:      	b	0x6e4 <_llm_rows.packet_batch.blocks+0x358>
     af8:      	xtn.4h	v0, v0
     afc:      	uzp1.8b	v0, v0, v0
     b00:      	movi.2d	v29, #0000000000000000
     b04:      	mov.b	v29[0], v0[0]
     b08:      	adrp	x12, 0x0 <ltmp0>
     b0c:      	ldr	d26, [x12]
     b10:      	and.8b	v3, v29, v26
     b14:      	addv.8b	b3, v3
     b18:      	fmov	w13, s3
     b1c:      	umaxv.8b	b3, v29
     b20:      	fmov	w15, s3
     b24:      	rbit	w12, w13
     b28:      	clz	w12, w12
     b2c:      	tst	w15, #0x1
     b30:      	csel	w12, w12, wzr, ne
     b34:      	mov	w14, #0x300             ; =768
     b38:      	dup.2d	v31, x14
     b3c:      	orr.16b	v30, v20, v31
     b40:      	add.2d	v23, v21, v30
     b44:      	movi.2d	v3, #0000000000000000
     b48:      	mov.b	v3[0], v0[0]
     b4c:      	ushll.2d	v0, v3, #0x0
     b50:      	shl.2d	v0, v0, #0x3f
     b54:      	cmlt.2d	v0, v0, #0
     b58:      	and.16b	v0, v0, v23
     b5c:      	movi.2d	v3, #0000000000000000
     b60:      	stp	q3, q3, [sp, #0x260]
     b64:      	stp	q0, q3, [sp, #0x240]
     b68:      	and	x14, x12, #0x7
     b6c:      	add	x16, sp, #0x240
     b70:      	ldr	x14, [x16, x14, lsl #3]
     b74:      	sub	x14, x14, x12
     b78:      	add	x14, x11, x14, lsl #2
     b7c:      	movi.2d	v22, #0000000000000000
     b80:      	movi.2d	v0, #0000000000000000
     b84:      	tbz	w15, #0x0, 0xbc4 <_llm_rows.packet_batch.blocks+0x838>
     b88:      	ldr	s22, [x14]
     b8c:      	tbnz	w13, #0x1, 0xbc8 <_llm_rows.packet_batch.blocks+0x83c>
     b90:      	tbz	w13, #0x2, 0xbd4 <_llm_rows.packet_batch.blocks+0x848>
     b94:      	add	x15, x14, #0x8
     b98:      	ld1.s	{ v22 }[2], [x15]
     b9c:      	tbnz	w13, #0x3, 0xbd8 <_llm_rows.packet_batch.blocks+0x84c>
     ba0:      	tbz	w13, #0x4, 0xbe4 <_llm_rows.packet_batch.blocks+0x858>
     ba4:      	add	x15, x14, #0x10
     ba8:      	ld1.s	{ v0 }[0], [x15]
     bac:      	tbnz	w13, #0x5, 0xbe8 <_llm_rows.packet_batch.blocks+0x85c>
     bb0:      	tbz	w13, #0x6, 0xbf4 <_llm_rows.packet_batch.blocks+0x868>
     bb4:      	add	x15, x14, #0x18
     bb8:      	ld1.s	{ v0 }[2], [x15]
     bbc:      	tbnz	w13, #0x7, 0xbf8 <_llm_rows.packet_batch.blocks+0x86c>
     bc0:      	b	0xc00 <_llm_rows.packet_batch.blocks+0x874>
     bc4:      	tbz	w13, #0x1, 0xb90 <_llm_rows.packet_batch.blocks+0x804>
     bc8:      	add	x15, x14, #0x4
     bcc:      	ld1.s	{ v22 }[1], [x15]
     bd0:      	tbnz	w13, #0x2, 0xb94 <_llm_rows.packet_batch.blocks+0x808>
     bd4:      	tbz	w13, #0x3, 0xba0 <_llm_rows.packet_batch.blocks+0x814>
     bd8:      	add	x15, x14, #0xc
     bdc:      	ld1.s	{ v22 }[3], [x15]
     be0:      	tbnz	w13, #0x4, 0xba4 <_llm_rows.packet_batch.blocks+0x818>
     be4:      	tbz	w13, #0x5, 0xbb0 <_llm_rows.packet_batch.blocks+0x824>
     be8:      	add	x15, x14, #0x14
     bec:      	ld1.s	{ v0 }[1], [x15]
     bf0:      	tbnz	w13, #0x6, 0xbb4 <_llm_rows.packet_batch.blocks+0x828>
     bf4:      	tbz	w13, #0x7, 0xc00 <_llm_rows.packet_batch.blocks+0x874>
     bf8:      	add	x13, x14, #0x1c
     bfc:      	ld1.s	{ v0 }[3], [x13]
     c00:      	add.2d	v3, v20, v21
     c04:      	add.2d	v24, v13, v6
     c08:      	add.2d	v21, v17, v19
     c0c:      	add.2d	v20, v16, v7
     c10:      	mov	w13, #0x601             ; =1537
     c14:      	dup.2d	v25, x13
     c18:      	add.2d	v20, v20, v25
     c1c:      	add.2d	v21, v21, v25
     c20:      	add.2d	v24, v24, v25
     c24:      	mov	b27, v29[0]
     c28:      	mov.b	v27[4], v29[1]
     c2c:      	add.2d	v25, v3, v25
     c30:      	ushll.2d	v3, v27, #0x0
     c34:      	shl.2d	v3, v3, #0x3f
     c38:      	cmlt.2d	v3, v3, #0
     c3c:      	and.16b	v3, v3, v25
     c40:      	mov	b27, v29[2]
     c44:      	mov.b	v27[4], v29[3]
     c48:      	ushll.2d	v27, v27, #0x0
     c4c:      	shl.2d	v27, v27, #0x3f
     c50:      	cmlt.2d	v27, v27, #0
     c54:      	and.16b	v28, v27, v24
     c58:      	mov	b27, v29[4]
     c5c:      	mov.b	v27[4], v29[5]
     c60:      	ushll.2d	v27, v27, #0x0
     c64:      	shl.2d	v27, v27, #0x3f
     c68:      	cmlt.2d	v27, v27, #0
     c6c:      	and.16b	v8, v27, v21
     c70:      	mov	b27, v29[6]
     c74:      	mov.b	v27[4], v29[7]
     c78:      	ushll.2d	v27, v27, #0x0
     c7c:      	shl.2d	v27, v27, #0x3f
     c80:      	cmlt.2d	v27, v27, #0
     c84:      	and.16b	v9, v27, v20
     c88:      	shl.8b	v27, v29, #0x7
     c8c:      	cmlt.8b	v27, v27, #0
     c90:      	and.8b	v26, v27, v26
     c94:      	addv.8b	b27, v26
     c98:      	fmov	w13, s27
     c9c:      	stp	q8, q9, [sp, #0x220]
     ca0:      	stp	q3, q28, [sp, #0x200]
     ca4:      	and	x14, x12, #0x7
     ca8:      	add	x15, sp, #0x200
     cac:      	ldr	x14, [x15, x14, lsl #3]
     cb0:      	sub	x14, x14, x12
     cb4:      	add	x11, x11, x14, lsl #2
     cb8:      	movi.2d	v28, #0000000000000000
     cbc:      	movi.2d	v26, #0000000000000000
     cc0:      	tbz	w13, #0x0, 0xd00 <_llm_rows.packet_batch.blocks+0x974>
     cc4:      	ldr	s28, [x11]
     cc8:      	tbnz	w13, #0x1, 0xd04 <_llm_rows.packet_batch.blocks+0x978>
     ccc:      	tbz	w13, #0x2, 0xd10 <_llm_rows.packet_batch.blocks+0x984>
     cd0:      	add	x14, x11, #0x8
     cd4:      	ld1.s	{ v28 }[2], [x14]
     cd8:      	tbnz	w13, #0x3, 0xd14 <_llm_rows.packet_batch.blocks+0x988>
     cdc:      	tbz	w13, #0x4, 0xd20 <_llm_rows.packet_batch.blocks+0x994>
     ce0:      	add	x14, x11, #0x10
     ce4:      	ld1.s	{ v26 }[0], [x14]
     ce8:      	tbnz	w13, #0x5, 0xd24 <_llm_rows.packet_batch.blocks+0x998>
     cec:      	tbz	w13, #0x6, 0xd30 <_llm_rows.packet_batch.blocks+0x9a4>
     cf0:      	add	x14, x11, #0x18
     cf4:      	ld1.s	{ v26 }[2], [x14]
     cf8:      	tbnz	w13, #0x7, 0xd34 <_llm_rows.packet_batch.blocks+0x9a8>
     cfc:      	b	0xd3c <_llm_rows.packet_batch.blocks+0x9b0>
     d00:      	tbz	w13, #0x1, 0xccc <_llm_rows.packet_batch.blocks+0x940>
     d04:      	add	x14, x11, #0x4
     d08:      	ld1.s	{ v28 }[1], [x14]
     d0c:      	tbnz	w13, #0x2, 0xcd0 <_llm_rows.packet_batch.blocks+0x944>
     d10:      	tbz	w13, #0x3, 0xcdc <_llm_rows.packet_batch.blocks+0x950>
     d14:      	add	x14, x11, #0xc
     d18:      	ld1.s	{ v28 }[3], [x14]
     d1c:      	tbnz	w13, #0x4, 0xce0 <_llm_rows.packet_batch.blocks+0x954>
     d20:      	tbz	w13, #0x5, 0xcec <_llm_rows.packet_batch.blocks+0x960>
     d24:      	add	x14, x11, #0x14
     d28:      	ld1.s	{ v26 }[1], [x14]
     d2c:      	tbnz	w13, #0x6, 0xcf0 <_llm_rows.packet_batch.blocks+0x964>
     d30:      	tbz	w13, #0x7, 0xd3c <_llm_rows.packet_batch.blocks+0x9b0>
     d34:      	add	x11, x11, #0x1c
     d38:      	ld1.s	{ v26 }[3], [x11]
     d3c:      	orr.16b	v16, v16, v31
     d40:      	orr.16b	v18, v13, v31
     d44:      	orr.16b	v17, v17, v31
     d48:      	mov.16b	v3, v16
     d4c:      	umlal.2d	v3, v5, v2
     d50:      	mov.16b	v5, v17
     d54:      	umlal.2d	v5, v4, v2
     d58:      	mov.16b	v4, v18
     d5c:      	umlal.2d	v4, v11, v2
     d60:      	umlal.2d	v30, v12, v2
     d64:      	mov	b1, v29[0]
     d68:      	mov.b	v1[4], v29[1]
     d6c:      	ushll.2d	v1, v1, #0x0
     d70:      	shl.2d	v1, v1, #0x3f
     d74:      	cmlt.2d	v1, v1, #0
     d78:      	and.16b	v1, v1, v30
     d7c:      	mov	b2, v29[2]
     d80:      	mov.b	v2[4], v29[3]
     d84:      	ushll.2d	v2, v2, #0x0
     d88:      	shl.2d	v2, v2, #0x3f
     d8c:      	cmlt.2d	v2, v2, #0
     d90:      	and.16b	v2, v2, v4
     d94:      	mov	b4, v29[4]
     d98:      	mov.b	v4[4], v29[5]
     d9c:      	ushll.2d	v4, v4, #0x0
     da0:      	shl.2d	v4, v4, #0x3f
     da4:      	cmlt.2d	v4, v4, #0
     da8:      	mov	b30, v29[6]
     dac:      	mov.b	v30[4], v29[7]
     db0:      	and.16b	v4, v4, v5
     db4:      	ushll.2d	v5, v30, #0x0
     db8:      	shl.2d	v5, v5, #0x3f
     dbc:      	cmlt.2d	v5, v5, #0
     dc0:      	and.16b	v3, v5, v3
     dc4:      	stp	q4, q3, [sp, #0x1e0]
     dc8:      	stp	q1, q2, [sp, #0x1c0]
     dcc:      	and	x11, x12, #0x7
     dd0:      	add	x13, sp, #0x1c0
     dd4:      	ldr	x11, [x13, x11, lsl #3]
     dd8:      	fmov	w13, s27
     ddc:      	sub	x11, x11, x12
     de0:      	lsl	x11, x11, #2
     de4:      	add	x10, x10, x11
     de8:      	movi.2d	v2, #0000000000000000
     dec:      	movi.2d	v1, #0000000000000000
     df0:      	tbz	w13, #0x0, 0xe7c <_llm_rows.packet_batch.blocks+0xaf0>
     df4:      	ldr	s2, [x10]
     df8:      	tbnz	w13, #0x1, 0xe80 <_llm_rows.packet_batch.blocks+0xaf4>
     dfc:      	tbz	w13, #0x2, 0xe8c <_llm_rows.packet_batch.blocks+0xb00>
     e00:      	add	x14, x10, #0x8
     e04:      	ld1.s	{ v2 }[2], [x14]
     e08:      	tbnz	w13, #0x3, 0xe90 <_llm_rows.packet_batch.blocks+0xb04>
     e0c:      	tbz	w13, #0x4, 0xe9c <_llm_rows.packet_batch.blocks+0xb10>
     e10:      	add	x14, x10, #0x10
     e14:      	ld1.s	{ v1 }[0], [x14]
     e18:      	tbnz	w13, #0x5, 0xea0 <_llm_rows.packet_batch.blocks+0xb14>
     e1c:      	tbz	w13, #0x6, 0xeac <_llm_rows.packet_batch.blocks+0xb20>
     e20:      	add	x14, x10, #0x18
     e24:      	ld1.s	{ v1 }[2], [x14]
     e28:      	tbnz	w13, #0x7, 0xeb0 <_llm_rows.packet_batch.blocks+0xb24>
     e2c:      	add	x9, x9, x11
     e30:      	fmov	w10, s27
     e34:      	movi.2d	v4, #0000000000000000
     e38:      	movi.2d	v3, #0000000000000000
     e3c:      	tbz	w10, #0x0, 0xecc <_llm_rows.packet_batch.blocks+0xb40>
     e40:      	ldr	s4, [x9]
     e44:      	tbnz	w10, #0x1, 0xed0 <_llm_rows.packet_batch.blocks+0xb44>
     e48:      	tbz	w10, #0x2, 0xedc <_llm_rows.packet_batch.blocks+0xb50>
     e4c:      	add	x11, x9, #0x8
     e50:      	ld1.s	{ v4 }[2], [x11]
     e54:      	tbnz	w10, #0x3, 0xee0 <_llm_rows.packet_batch.blocks+0xb54>
     e58:      	tbz	w10, #0x4, 0xeec <_llm_rows.packet_batch.blocks+0xb60>
     e5c:      	add	x11, x9, #0x10
     e60:      	ld1.s	{ v3 }[0], [x11]
     e64:      	tbnz	w10, #0x5, 0xef0 <_llm_rows.packet_batch.blocks+0xb64>
     e68:      	tbz	w10, #0x6, 0xefc <_llm_rows.packet_batch.blocks+0xb70>
     e6c:      	add	x11, x9, #0x18
     e70:      	ld1.s	{ v3 }[2], [x11]
     e74:      	tbnz	w10, #0x7, 0xf00 <_llm_rows.packet_batch.blocks+0xb74>
     e78:      	b	0xf08 <_llm_rows.packet_batch.blocks+0xb7c>
     e7c:      	tbz	w13, #0x1, 0xdfc <_llm_rows.packet_batch.blocks+0xa70>
     e80:      	add	x14, x10, #0x4
     e84:      	ld1.s	{ v2 }[1], [x14]
     e88:      	tbnz	w13, #0x2, 0xe00 <_llm_rows.packet_batch.blocks+0xa74>
     e8c:      	tbz	w13, #0x3, 0xe0c <_llm_rows.packet_batch.blocks+0xa80>
     e90:      	add	x14, x10, #0xc
     e94:      	ld1.s	{ v2 }[3], [x14]
     e98:      	tbnz	w13, #0x4, 0xe10 <_llm_rows.packet_batch.blocks+0xa84>
     e9c:      	tbz	w13, #0x5, 0xe1c <_llm_rows.packet_batch.blocks+0xa90>
     ea0:      	add	x14, x10, #0x14
     ea4:      	ld1.s	{ v1 }[1], [x14]
     ea8:      	tbnz	w13, #0x6, 0xe20 <_llm_rows.packet_batch.blocks+0xa94>
     eac:      	tbz	w13, #0x7, 0xe2c <_llm_rows.packet_batch.blocks+0xaa0>
     eb0:      	add	x10, x10, #0x1c
     eb4:      	ld1.s	{ v1 }[3], [x10]
     eb8:      	add	x9, x9, x11
     ebc:      	fmov	w10, s27
     ec0:      	movi.2d	v4, #0000000000000000
     ec4:      	movi.2d	v3, #0000000000000000
     ec8:      	tbnz	w10, #0x0, 0xe40 <_llm_rows.packet_batch.blocks+0xab4>
     ecc:      	tbz	w10, #0x1, 0xe48 <_llm_rows.packet_batch.blocks+0xabc>
     ed0:      	add	x11, x9, #0x4
     ed4:      	ld1.s	{ v4 }[1], [x11]
     ed8:      	tbnz	w10, #0x2, 0xe4c <_llm_rows.packet_batch.blocks+0xac0>
     edc:      	tbz	w10, #0x3, 0xe58 <_llm_rows.packet_batch.blocks+0xacc>
     ee0:      	add	x11, x9, #0xc
     ee4:      	ld1.s	{ v4 }[3], [x11]
     ee8:      	tbnz	w10, #0x4, 0xe5c <_llm_rows.packet_batch.blocks+0xad0>
     eec:      	tbz	w10, #0x5, 0xe68 <_llm_rows.packet_batch.blocks+0xadc>
     ef0:      	add	x11, x9, #0x14
     ef4:      	ld1.s	{ v3 }[1], [x11]
     ef8:      	tbnz	w10, #0x6, 0xe6c <_llm_rows.packet_batch.blocks+0xae0>
     efc:      	tbz	w10, #0x7, 0xf08 <_llm_rows.packet_batch.blocks+0xb7c>
     f00:      	add	x9, x9, #0x1c
     f04:      	ld1.s	{ v3 }[3], [x9]
     f08:      	add.2d	v17, v19, v17
     f0c:      	add.2d	v6, v6, v18
     f10:      	add.2d	v7, v7, v16
     f14:      	fmul.4s	v5, v22, v2
     f18:      	fmul.4s	v16, v28, v4
     f1c:      	fsub.4s	v5, v5, v16
     f20:      	stp	q23, q6, [sp, #0x180]
     f24:      	stp	q17, q7, [sp, #0x1a0]
     f28:      	and	x9, x12, #0x7
     f2c:      	add	x10, sp, #0x180
     f30:      	ldr	x9, [x10, x9, lsl #3]
     f34:      	sub	x9, x9, x12
     f38:      	add	x9, x8, x9, lsl #2
     f3c:      	fmov	w10, s27
     f40:      	tbz	w10, #0x0, 0xf88 <_llm_rows.packet_batch.blocks+0xbfc>
     f44:      	str	s5, [x9]
     f48:      	tbnz	w10, #0x1, 0xf8c <_llm_rows.packet_batch.blocks+0xc00>
     f4c:      	tbz	w10, #0x2, 0xf98 <_llm_rows.packet_batch.blocks+0xc0c>
     f50:      	add	x11, x9, #0x8
     f54:      	st1.s	{ v5 }[2], [x11]
     f58:      	tbnz	w10, #0x3, 0xf9c <_llm_rows.packet_batch.blocks+0xc10>
     f5c:      	fmul.4s	v5, v0, v1
     f60:      	fmul.4s	v6, v26, v3
     f64:      	fsub.4s	v5, v5, v6
     f68:      	tbz	w10, #0x4, 0xfb4 <_llm_rows.packet_batch.blocks+0xc28>
     f6c:      	str	s5, [x9, #0x10]
     f70:      	tbnz	w10, #0x5, 0xfb8 <_llm_rows.packet_batch.blocks+0xc2c>
     f74:      	tbz	w10, #0x6, 0xfc4 <_llm_rows.packet_batch.blocks+0xc38>
     f78:      	add	x11, x9, #0x18
     f7c:      	st1.s	{ v5 }[2], [x11]
     f80:      	tbnz	w10, #0x7, 0xfc8 <_llm_rows.packet_batch.blocks+0xc3c>
     f84:      	b	0xfd0 <_llm_rows.packet_batch.blocks+0xc44>
     f88:      	tbz	w10, #0x1, 0xf4c <_llm_rows.packet_batch.blocks+0xbc0>
     f8c:      	add	x11, x9, #0x4
     f90:      	st1.s	{ v5 }[1], [x11]
     f94:      	tbnz	w10, #0x2, 0xf50 <_llm_rows.packet_batch.blocks+0xbc4>
     f98:      	tbz	w10, #0x3, 0xf5c <_llm_rows.packet_batch.blocks+0xbd0>
     f9c:      	add	x11, x9, #0xc
     fa0:      	st1.s	{ v5 }[3], [x11]
     fa4:      	fmul.4s	v5, v0, v1
     fa8:      	fmul.4s	v6, v26, v3
     fac:      	fsub.4s	v5, v5, v6
     fb0:      	tbnz	w10, #0x4, 0xf6c <_llm_rows.packet_batch.blocks+0xbe0>
     fb4:      	tbz	w10, #0x5, 0xf74 <_llm_rows.packet_batch.blocks+0xbe8>
     fb8:      	add	x11, x9, #0x14
     fbc:      	st1.s	{ v5 }[1], [x11]
     fc0:      	tbnz	w10, #0x6, 0xf78 <_llm_rows.packet_batch.blocks+0xbec>
     fc4:      	tbz	w10, #0x7, 0xfd0 <_llm_rows.packet_batch.blocks+0xc44>
     fc8:      	add	x9, x9, #0x1c
     fcc:      	st1.s	{ v5 }[3], [x9]
     fd0:      	fmul.4s	v4, v22, v4
     fd4:      	fmul.4s	v2, v28, v2
     fd8:      	fadd.4s	v2, v2, v4
     fdc:      	stp	q25, q24, [sp, #0x140]
     fe0:      	stp	q21, q20, [sp, #0x160]
     fe4:      	and	x9, x12, #0x7
     fe8:      	add	x10, sp, #0x140
     fec:      	ldr	x9, [x10, x9, lsl #3]
     ff0:      	sub	x9, x9, x12
     ff4:      	add	x8, x8, x9, lsl #2
     ff8:      	fmov	w9, s27
     ffc:      	tbz	w9, #0x0, 0x1044 <_llm_rows.packet_batch.blocks+0xcb8>
    1000:      	str	s2, [x8]
    1004:      	tbnz	w9, #0x1, 0x1048 <_llm_rows.packet_batch.blocks+0xcbc>
    1008:      	tbz	w9, #0x2, 0x1054 <_llm_rows.packet_batch.blocks+0xcc8>
    100c:      	add	x10, x8, #0x8
    1010:      	st1.s	{ v2 }[2], [x10]
    1014:      	tbnz	w9, #0x3, 0x1058 <_llm_rows.packet_batch.blocks+0xccc>
    1018:      	fmul.4s	v0, v0, v3
    101c:      	fmul.4s	v1, v26, v1
    1020:      	fadd.4s	v0, v1, v0
    1024:      	tbz	w9, #0x4, 0x1dc0 <_llm_rows.packet_batch.blocks+0x1a34>
    1028:      	str	s0, [x8, #0x10]
    102c:      	tbnz	w9, #0x5, 0x1dc4 <_llm_rows.packet_batch.blocks+0x1a38>
    1030:      	tbz	w9, #0x6, 0x1dd0 <_llm_rows.packet_batch.blocks+0x1a44>
    1034:      	add	x10, x8, #0x18
    1038:      	st1.s	{ v0 }[2], [x10]
    103c:      	tbnz	w9, #0x7, 0x1dd4 <_llm_rows.packet_batch.blocks+0x1a48>
    1040:      	b	0x464 <_llm_rows.packet_batch.blocks+0xd8>
    1044:      	tbz	w9, #0x1, 0x1008 <_llm_rows.packet_batch.blocks+0xc7c>
    1048:      	add	x10, x8, #0x4
    104c:      	st1.s	{ v2 }[1], [x10]
    1050:      	tbnz	w9, #0x2, 0x100c <_llm_rows.packet_batch.blocks+0xc80>
    1054:      	tbz	w9, #0x3, 0x1018 <_llm_rows.packet_batch.blocks+0xc8c>
    1058:      	add	x10, x8, #0xc
    105c:      	st1.s	{ v2 }[3], [x10]
    1060:      	fmul.4s	v0, v0, v3
    1064:      	fmul.4s	v1, v26, v1
    1068:      	fadd.4s	v0, v1, v0
    106c:      	tbz	w9, #0x4, 0x1dc0 <_llm_rows.packet_batch.blocks+0x1a34>
    1070:      	b	0x1028 <_llm_rows.packet_batch.blocks+0xc9c>
    1074:      	mov	x12, #0x0               ; =0
    1078:      	fmov	x15, d3
    107c:      	mov	w13, #0x1808            ; =6152
    1080:      	umaddl	x13, w15, w13, x11
    1084:      	add	x3, sp, #0x2, lsl #12   ; =0x2000
    1088:      	add	x3, x3, #0x8c0
    108c:      	b	0x10b0 <_llm_rows.packet_batch.blocks+0xd24>
    1090:      	add	x14, x3, x12
    1094:      	ldp	q24, q25, [x14]
    1098:      	bif.16b	v3, v25, v6
    109c:      	bif.16b	v19, v24, v0
    10a0:      	stp	q19, q3, [x14]
    10a4:      	add	x12, x12, #0x20
    10a8:      	cmp	x12, #0xc00
    10ac:      	b.eq	0x1150 <_llm_rows.packet_batch.blocks+0xdc4>
    10b0:      	and.16b	v3, v22, v15
    10b4:      	addv.8h	h7, v3
    10b8:      	fmov	w16, s7
    10bc:      	add	x14, x13, x12
    10c0:      	movi.2d	v19, #0000000000000000
    10c4:      	movi.2d	v3, #0000000000000000
    10c8:      	tbz	w16, #0x0, 0x110c <_llm_rows.packet_batch.blocks+0xd80>
    10cc:      	ldr	s19, [x14]
    10d0:      	and	w16, w16, #0xff
    10d4:      	tbnz	w16, #0x1, 0x1114 <_llm_rows.packet_batch.blocks+0xd88>
    10d8:      	tbz	w16, #0x2, 0x1120 <_llm_rows.packet_batch.blocks+0xd94>
    10dc:      	add	x17, x14, #0x8
    10e0:      	ld1.s	{ v19 }[2], [x17]
    10e4:      	tbnz	w16, #0x3, 0x1124 <_llm_rows.packet_batch.blocks+0xd98>
    10e8:      	tbz	w16, #0x4, 0x1130 <_llm_rows.packet_batch.blocks+0xda4>
    10ec:      	add	x17, x14, #0x10
    10f0:      	ld1.s	{ v3 }[0], [x17]
    10f4:      	tbnz	w16, #0x5, 0x1134 <_llm_rows.packet_batch.blocks+0xda8>
    10f8:      	tbz	w16, #0x6, 0x1140 <_llm_rows.packet_batch.blocks+0xdb4>
    10fc:      	add	x17, x14, #0x18
    1100:      	ld1.s	{ v3 }[2], [x17]
    1104:      	tbz	w16, #0x7, 0x1090 <_llm_rows.packet_batch.blocks+0xd04>
    1108:      	b	0x1144 <_llm_rows.packet_batch.blocks+0xdb8>
    110c:      	and	w16, w16, #0xff
    1110:      	tbz	w16, #0x1, 0x10d8 <_llm_rows.packet_batch.blocks+0xd4c>
    1114:      	add	x17, x14, #0x4
    1118:      	ld1.s	{ v19 }[1], [x17]
    111c:      	tbnz	w16, #0x2, 0x10dc <_llm_rows.packet_batch.blocks+0xd50>
    1120:      	tbz	w16, #0x3, 0x10e8 <_llm_rows.packet_batch.blocks+0xd5c>
    1124:      	add	x17, x14, #0xc
    1128:      	ld1.s	{ v19 }[3], [x17]
    112c:      	tbnz	w16, #0x4, 0x10ec <_llm_rows.packet_batch.blocks+0xd60>
    1130:      	tbz	w16, #0x5, 0x10f8 <_llm_rows.packet_batch.blocks+0xd6c>
    1134:      	add	x17, x14, #0x14
    1138:      	ld1.s	{ v3 }[1], [x17]
    113c:      	tbnz	w16, #0x6, 0x10fc <_llm_rows.packet_batch.blocks+0xd70>
    1140:      	tbz	w16, #0x7, 0x1090 <_llm_rows.packet_batch.blocks+0xd04>
    1144:      	add	x14, x14, #0x1c
    1148:      	ld1.s	{ v3 }[3], [x14]
    114c:      	b	0x1090 <_llm_rows.packet_batch.blocks+0xd04>
    1150:      	stp	d4, d11, [sp, #0xd0]
    1154:      	xtn.4h	v3, v0
    1158:      	uzp1.8b	v3, v3, v0
    115c:      	movi.2d	v19, #0000000000000000
    1160:      	mov.b	v19[0], v3[0]
    1164:      	adrp	x12, 0x1000 <_llm_rows.packet_batch.blocks+0xc74>
    1168:      	ldr	d31, [x12]
    116c:      	and.8b	v22, v19, v31
    1170:      	addv.8b	b22, v22
    1174:      	fmov	w13, s22
    1178:      	umaxv.8b	b22, v19
    117c:      	fmov	w16, s22
    1180:      	rbit	w12, w13
    1184:      	clz	w12, w12
    1188:      	tst	w16, #0x1
    118c:      	csel	w12, w12, wzr, ne
    1190:      	mov	w14, #0x300             ; =768
    1194:      	dup.2d	v26, x14
    1198:      	orr.16b	v11, v20, v26
    119c:      	mov.16b	v1, v11
    11a0:      	umlal.2d	v1, v12, v10
    11a4:      	movi.2d	v24, #0000000000000000
    11a8:      	mov.b	v24[0], v3[0]
    11ac:      	ushll.2d	v3, v24, #0x0
    11b0:      	shl.2d	v3, v3, #0x3f
    11b4:      	cmlt.2d	v3, v3, #0
    11b8:      	str	q1, [sp, #0x60]
    11bc:      	and.16b	v3, v3, v1
    11c0:      	movi.2d	v4, #0000000000000000
    11c4:      	str	q4, [sp, #0x440]
    11c8:      	str	q4, [sp, #0x430]
    11cc:      	str	q4, [sp, #0x420]
    11d0:      	str	q3, [sp, #0x410]
    11d4:      	and	x14, x12, #0x7
    11d8:      	add	x17, sp, #0x410
    11dc:      	ldr	x14, [x17, x14, lsl #3]
    11e0:      	sub	x14, x14, x12
    11e4:      	add	x14, x11, x14, lsl #2
    11e8:      	movi.2d	v24, #0000000000000000
    11ec:      	movi.2d	v25, #0000000000000000
    11f0:      	tbz	w16, #0x0, 0x1234 <_llm_rows.packet_batch.blocks+0xea8>
    11f4:      	ldr	s24, [x14]
    11f8:      	tbnz	w13, #0x1, 0x1238 <_llm_rows.packet_batch.blocks+0xeac>
    11fc:      	tbz	w13, #0x2, 0x1244 <_llm_rows.packet_batch.blocks+0xeb8>
    1200:      	add	x16, x14, #0x8
    1204:      	ld1.s	{ v24 }[2], [x16]
    1208:      	tbnz	w13, #0x3, 0x1248 <_llm_rows.packet_batch.blocks+0xebc>
    120c:      	tbz	w13, #0x4, 0x1254 <_llm_rows.packet_batch.blocks+0xec8>
    1210:      	add	x16, x14, #0x10
    1214:      	ld1.s	{ v25 }[0], [x16]
    1218:      	tbnz	w13, #0x5, 0x1258 <_llm_rows.packet_batch.blocks+0xecc>
    121c:      	tbz	w13, #0x6, 0x1264 <_llm_rows.packet_batch.blocks+0xed8>
    1220:      	add	x16, x14, #0x18
    1224:      	ld1.s	{ v25 }[2], [x16]
    1228:      	fmov	d22, d5
    122c:      	tbnz	w13, #0x7, 0x126c <_llm_rows.packet_batch.blocks+0xee0>
    1230:      	b	0x1274 <_llm_rows.packet_batch.blocks+0xee8>
    1234:      	tbz	w13, #0x1, 0x11fc <_llm_rows.packet_batch.blocks+0xe70>
    1238:      	add	x16, x14, #0x4
    123c:      	ld1.s	{ v24 }[1], [x16]
    1240:      	tbnz	w13, #0x2, 0x1200 <_llm_rows.packet_batch.blocks+0xe74>
    1244:      	tbz	w13, #0x3, 0x120c <_llm_rows.packet_batch.blocks+0xe80>
    1248:      	add	x16, x14, #0xc
    124c:      	ld1.s	{ v24 }[3], [x16]
    1250:      	tbnz	w13, #0x4, 0x1210 <_llm_rows.packet_batch.blocks+0xe84>
    1254:      	tbz	w13, #0x5, 0x121c <_llm_rows.packet_batch.blocks+0xe90>
    1258:      	add	x16, x14, #0x14
    125c:      	ld1.s	{ v25 }[1], [x16]
    1260:      	tbnz	w13, #0x6, 0x1220 <_llm_rows.packet_batch.blocks+0xe94>
    1264:      	fmov	d22, d5
    1268:      	tbz	w13, #0x7, 0x1274 <_llm_rows.packet_batch.blocks+0xee8>
    126c:      	add	x14, x14, #0x1c
    1270:      	ld1.s	{ v25 }[3], [x14]
    1274:      	mov	x17, #0x0               ; =0
    1278:      	mov.16b	v18, v16
    127c:      	orr.16b	v1, v16, v26
    1280:      	mov.16b	v16, v13
    1284:      	orr.16b	v14, v13, v26
    1288:      	mov.16b	v13, v17
    128c:      	orr.16b	v17, v17, v26
    1290:      	umull.2d	v9, v12, v10
    1294:      	fmov	d3, d10
    1298:      	ldp	d5, d4, [sp, #0xd0]
    129c:      	umull.2d	v10, v4, v10
    12a0:      	umull.2d	v15, v5, v3
    12a4:      	umull.2d	v28, v22, v3
    12a8:      	mov.16b	v27, v17
    12ac:      	umlal.2d	v27, v5, v3
    12b0:      	mov.16b	v5, v14
    12b4:      	umlal.2d	v5, v4, v3
    12b8:      	stp	q5, q27, [sp, #0x40]
    12bc:      	mov.16b	v4, v1
    12c0:      	umlal.2d	v4, v22, v3
    12c4:      	str	q4, [sp, #0x30]
    12c8:      	adrp	x14, 0x1000 <_llm_rows.packet_batch.blocks+0xc74>
    12cc:      	ldr	q3, [x14]
    12d0:      	mov	w14, #0xc00             ; =3072
    12d4:      	dup.2d	v26, x14
    12d8:      	sshll.2d	v27, v0, #0x0
    12dc:      	bif.16b	v3, v26, v27
    12e0:      	adrp	x14, 0x1000 <_llm_rows.packet_batch.blocks+0xc74>
    12e4:      	ldr	q27, [x14]
    12e8:      	sshll.2d	v29, v6, #0x0
    12ec:      	bif.16b	v27, v26, v29
    12f0:      	adrp	x14, 0x1000 <_llm_rows.packet_batch.blocks+0xc74>
    12f4:      	ldr	q29, [x14]
    12f8:      	bsl.16b	v23, v29, v26
    12fc:      	adrp	x14, 0x1000 <_llm_rows.packet_batch.blocks+0xc74>
    1300:      	ldr	q29, [x14]
    1304:      	bsl.16b	v21, v29, v26
    1308:      	stp	q27, q21, [sp, #0x3f0]
    130c:      	stp	q3, q23, [sp, #0x3d0]
    1310:      	and	x14, x12, #0x7
    1314:      	add	x16, sp, #0x3d0
    1318:      	ldr	x14, [x16, x14, lsl #3]
    131c:      	sub	x14, x14, x12, lsl #2
    1320:      	tst	w13, #0xff
    1324:      	csel	x13, xzr, x14, eq
    1328:      	add	x14, x3, x13
    132c:      	ldp	q3, q21, [x14]
    1330:      	zip2.8b	v23, v19, v0
    1334:      	ushll.4s	v23, v23, #0x0
    1338:      	shl.4s	v23, v23, #0x1f
    133c:      	cmlt.4s	v23, v23, #0
    1340:      	mov.16b	v4, v23
    1344:      	bsl.16b	v4, v25, v21
    1348:      	zip1.8b	v21, v19, v0
    134c:      	ushll.4s	v21, v21, #0x0
    1350:      	shl.4s	v21, v21, #0x1f
    1354:      	cmlt.4s	v21, v21, #0
    1358:      	bit.16b	v3, v24, v21
    135c:      	str	q3, [sp, #0xc0]
    1360:      	stp	q3, q4, [x14]
    1364:      	str	q4, [sp, #0x70]
    1368:      	fmov	x14, d9
    136c:      	ushll2.2d	v3, v6, #0x0
    1370:      	mov	w16, #0x1               ; =1
    1374:      	dup.2d	v21, x16
    1378:      	and.16b	v24, v3, v21
    137c:      	ushll2.2d	v3, v0, #0x0
    1380:      	and.16b	v25, v3, v21
    1384:      	ushll.2d	v3, v6, #0x0
    1388:      	and.16b	v26, v3, v21
    138c:      	ushll.2d	v3, v0, #0x0
    1390:      	and.16b	v27, v3, v21
    1394:      	lsl	x14, x14, #2
    1398:      	add	x16, x11, x14
    139c:      	add	x16, x16, #0xc04
    13a0:      	movi.2d	v21, #0000000000000000
    13a4:      	movi.2d	v23, #0000000000000000
    13a8:      	movi.2d	v29, #0000000000000000
    13ac:      	movi.2d	v30, #0000000000000000
    13b0:      	b	0x13e4 <_llm_rows.packet_batch.blocks+0x1058>
    13b4:      	add	x17, x27, x17
    13b8:      	ldp	q4, q5, [x17]
    13bc:      	bit.16b	v5, v8, v6
    13c0:      	bif.16b	v3, v4, v0
    13c4:      	stp	q3, q5, [x17]
    13c8:      	add.2d	v23, v23, v25
    13cc:      	add.2d	v29, v29, v26
    13d0:      	add.2d	v30, v30, v24
    13d4:      	add.2d	v21, v21, v27
    13d8:      	fmov	x17, d21
    13dc:      	cmp	x17, #0x60
    13e0:      	b.ge	0x1480 <_llm_rows.packet_batch.blocks+0x10f4>
    13e4:      	fmov	w1, s7
    13e8:      	lsl	x17, x17, #5
    13ec:      	add	x0, x16, x17
    13f0:      	movi.2d	v3, #0000000000000000
    13f4:      	movi.2d	v8, #0000000000000000
    13f8:      	tbz	w1, #0x0, 0x143c <_llm_rows.packet_batch.blocks+0x10b0>
    13fc:      	ldr	s3, [x0]
    1400:      	and	w1, w1, #0xff
    1404:      	tbnz	w1, #0x1, 0x1444 <_llm_rows.packet_batch.blocks+0x10b8>
    1408:      	tbz	w1, #0x2, 0x1450 <_llm_rows.packet_batch.blocks+0x10c4>
    140c:      	add	x2, x0, #0x8
    1410:      	ld1.s	{ v3 }[2], [x2]
    1414:      	tbnz	w1, #0x3, 0x1454 <_llm_rows.packet_batch.blocks+0x10c8>
    1418:      	tbz	w1, #0x4, 0x1460 <_llm_rows.packet_batch.blocks+0x10d4>
    141c:      	add	x2, x0, #0x10
    1420:      	ld1.s	{ v8 }[0], [x2]
    1424:      	tbnz	w1, #0x5, 0x1464 <_llm_rows.packet_batch.blocks+0x10d8>
    1428:      	tbz	w1, #0x6, 0x1470 <_llm_rows.packet_batch.blocks+0x10e4>
    142c:      	add	x2, x0, #0x18
    1430:      	ld1.s	{ v8 }[2], [x2]
    1434:      	tbz	w1, #0x7, 0x13b4 <_llm_rows.packet_batch.blocks+0x1028>
    1438:      	b	0x1474 <_llm_rows.packet_batch.blocks+0x10e8>
    143c:      	and	w1, w1, #0xff
    1440:      	tbz	w1, #0x1, 0x1408 <_llm_rows.packet_batch.blocks+0x107c>
    1444:      	add	x2, x0, #0x4
    1448:      	ld1.s	{ v3 }[1], [x2]
    144c:      	tbnz	w1, #0x2, 0x140c <_llm_rows.packet_batch.blocks+0x1080>
    1450:      	tbz	w1, #0x3, 0x1418 <_llm_rows.packet_batch.blocks+0x108c>
    1454:      	add	x2, x0, #0xc
    1458:      	ld1.s	{ v3 }[3], [x2]
    145c:      	tbnz	w1, #0x4, 0x141c <_llm_rows.packet_batch.blocks+0x1090>
    1460:      	tbz	w1, #0x5, 0x1428 <_llm_rows.packet_batch.blocks+0x109c>
    1464:      	add	x2, x0, #0x14
    1468:      	ld1.s	{ v8 }[1], [x2]
    146c:      	tbnz	w1, #0x6, 0x142c <_llm_rows.packet_batch.blocks+0x10a0>
    1470:      	tbz	w1, #0x7, 0x13b4 <_llm_rows.packet_batch.blocks+0x1028>
    1474:      	add	x0, x0, #0x1c
    1478:      	ld1.s	{ v8 }[3], [x0]
    147c:      	b	0x13b4 <_llm_rows.packet_batch.blocks+0x1028>
    1480:      	add.2d	v3, v20, v9
    1484:      	add.2d	v4, v16, v10
    1488:      	add.2d	v5, v13, v15
    148c:      	add.2d	v16, v18, v28
    1490:      	mov	w16, #0x601             ; =1537
    1494:      	dup.2d	v20, x16
    1498:      	add.2d	v18, v16, v20
    149c:      	add.2d	v21, v5, v20
    14a0:      	add.2d	v16, v4, v20
    14a4:      	mov	b4, v19[0]
    14a8:      	mov.b	v4[4], v19[1]
    14ac:      	add.2d	v20, v3, v20
    14b0:      	ushll.2d	v3, v4, #0x0
    14b4:      	shl.2d	v3, v3, #0x3f
    14b8:      	cmlt.2d	v3, v3, #0
    14bc:      	and.16b	v3, v3, v20
    14c0:      	mov	b4, v19[2]
    14c4:      	mov.b	v4[4], v19[3]
    14c8:      	ushll.2d	v4, v4, #0x0
    14cc:      	shl.2d	v4, v4, #0x3f
    14d0:      	cmlt.2d	v4, v4, #0
    14d4:      	and.16b	v4, v4, v16
    14d8:      	mov	b5, v19[4]
    14dc:      	mov.b	v5[4], v19[5]
    14e0:      	ushll.2d	v5, v5, #0x0
    14e4:      	shl.2d	v5, v5, #0x3f
    14e8:      	cmlt.2d	v5, v5, #0
    14ec:      	stp	q21, q18, [sp, #0x10]
    14f0:      	and.16b	v5, v5, v21
    14f4:      	mov	b21, v19[6]
    14f8:      	mov.b	v21[4], v19[7]
    14fc:      	ushll.2d	v21, v21, #0x0
    1500:      	shl.2d	v21, v21, #0x3f
    1504:      	cmlt.2d	v21, v21, #0
    1508:      	and.16b	v21, v21, v18
    150c:      	shl.8b	v23, v19, #0x7
    1510:      	cmlt.8b	v23, v23, #0
    1514:      	and.8b	v23, v23, v31
    1518:      	addv.8b	b31, v23
    151c:      	fmov	w16, s31
    1520:      	stp	q5, q21, [sp, #0x3a0]
    1524:      	stp	q3, q4, [sp, #0x380]
    1528:      	and	x17, x12, #0x7
    152c:      	add	x0, sp, #0x380
    1530:      	ldr	x17, [x0, x17, lsl #3]
    1534:      	sub	x17, x17, x12
    1538:      	add	x11, x11, x17, lsl #2
    153c:      	movi.2d	v21, #0000000000000000
    1540:      	movi.2d	v3, #0000000000000000
    1544:      	tbz	w16, #0x0, 0x1588 <_llm_rows.packet_batch.blocks+0x11fc>
    1548:      	ldr	s21, [x11]
    154c:      	ldr	q15, [sp, #0x120]
    1550:      	tbnz	w16, #0x1, 0x1590 <_llm_rows.packet_batch.blocks+0x1204>
    1554:      	tbz	w16, #0x2, 0x159c <_llm_rows.packet_batch.blocks+0x1210>
    1558:      	add	x17, x11, #0x8
    155c:      	ld1.s	{ v21 }[2], [x17]
    1560:      	tbnz	w16, #0x3, 0x15a0 <_llm_rows.packet_batch.blocks+0x1214>
    1564:      	tbz	w16, #0x4, 0x15ac <_llm_rows.packet_batch.blocks+0x1220>
    1568:      	add	x17, x11, #0x10
    156c:      	ld1.s	{ v3 }[0], [x17]
    1570:      	tbnz	w16, #0x5, 0x15b0 <_llm_rows.packet_batch.blocks+0x1224>
    1574:      	tbz	w16, #0x6, 0x15bc <_llm_rows.packet_batch.blocks+0x1230>
    1578:      	add	x17, x11, #0x18
    157c:      	ld1.s	{ v3 }[2], [x17]
    1580:      	tbnz	w16, #0x7, 0x15c0 <_llm_rows.packet_batch.blocks+0x1234>
    1584:      	b	0x15c8 <_llm_rows.packet_batch.blocks+0x123c>
    1588:      	ldr	q15, [sp, #0x120]
    158c:      	tbz	w16, #0x1, 0x1554 <_llm_rows.packet_batch.blocks+0x11c8>
    1590:      	add	x17, x11, #0x4
    1594:      	ld1.s	{ v21 }[1], [x17]
    1598:      	tbnz	w16, #0x2, 0x1558 <_llm_rows.packet_batch.blocks+0x11cc>
    159c:      	tbz	w16, #0x3, 0x1564 <_llm_rows.packet_batch.blocks+0x11d8>
    15a0:      	add	x17, x11, #0xc
    15a4:      	ld1.s	{ v21 }[3], [x17]
    15a8:      	tbnz	w16, #0x4, 0x1568 <_llm_rows.packet_batch.blocks+0x11dc>
    15ac:      	tbz	w16, #0x5, 0x1574 <_llm_rows.packet_batch.blocks+0x11e8>
    15b0:      	add	x17, x11, #0x14
    15b4:      	ld1.s	{ v3 }[1], [x17]
    15b8:      	tbnz	w16, #0x6, 0x1578 <_llm_rows.packet_batch.blocks+0x11ec>
    15bc:      	tbz	w16, #0x7, 0x15c8 <_llm_rows.packet_batch.blocks+0x123c>
    15c0:      	add	x11, x11, #0x1c
    15c4:      	ld1.s	{ v3 }[3], [x11]
    15c8:      	mov	x16, #0x0               ; =0
    15cc:      	add	x11, x27, x13
    15d0:      	ldp	q4, q5, [x11]
    15d4:      	zip2.8b	v23, v19, v0
    15d8:      	ushll.4s	v23, v23, #0x0
    15dc:      	shl.4s	v23, v23, #0x1f
    15e0:      	cmlt.4s	v23, v23, #0
    15e4:      	mov.16b	v9, v23
    15e8:      	bsl.16b	v9, v3, v5
    15ec:      	zip1.8b	v3, v19, v0
    15f0:      	ushll.4s	v3, v3, #0x0
    15f4:      	shl.4s	v3, v3, #0x1f
    15f8:      	cmlt.4s	v3, v3, #0
    15fc:      	mov.16b	v10, v3
    1600:      	bsl.16b	v10, v21, v4
    1604:      	stp	q10, q9, [x11]
    1608:      	mov	w11, #0xc04             ; =3076
    160c:      	umaddl	x11, w15, w11, x10
    1610:      	movi.2d	v28, #0000000000000000
    1614:      	movi.2d	v21, #0000000000000000
    1618:      	movi.2d	v23, #0000000000000000
    161c:      	movi.2d	v29, #0000000000000000
    1620:      	b	0x1654 <_llm_rows.packet_batch.blocks+0x12c8>
    1624:      	add	x15, x19, x15
    1628:      	ldp	q4, q5, [x15]
    162c:      	bit.16b	v5, v30, v6
    1630:      	bif.16b	v3, v4, v0
    1634:      	stp	q3, q5, [x15]
    1638:      	add.2d	v21, v21, v25
    163c:      	add.2d	v23, v23, v26
    1640:      	add.2d	v29, v29, v24
    1644:      	add.2d	v28, v28, v27
    1648:      	fmov	x16, d28
    164c:      	cmp	x16, #0x60
    1650:      	b.ge	0x16f0 <_llm_rows.packet_batch.blocks+0x1364>
    1654:      	fmov	w17, s7
    1658:      	lsl	x15, x16, #5
    165c:      	add	x16, x11, x15
    1660:      	movi.2d	v3, #0000000000000000
    1664:      	movi.2d	v30, #0000000000000000
    1668:      	tbz	w17, #0x0, 0x16ac <_llm_rows.packet_batch.blocks+0x1320>
    166c:      	ldr	s3, [x16]
    1670:      	and	w17, w17, #0xff
    1674:      	tbnz	w17, #0x1, 0x16b4 <_llm_rows.packet_batch.blocks+0x1328>
    1678:      	tbz	w17, #0x2, 0x16c0 <_llm_rows.packet_batch.blocks+0x1334>
    167c:      	add	x0, x16, #0x8
    1680:      	ld1.s	{ v3 }[2], [x0]
    1684:      	tbnz	w17, #0x3, 0x16c4 <_llm_rows.packet_batch.blocks+0x1338>
    1688:      	tbz	w17, #0x4, 0x16d0 <_llm_rows.packet_batch.blocks+0x1344>
    168c:      	add	x0, x16, #0x10
    1690:      	ld1.s	{ v30 }[0], [x0]
    1694:      	tbnz	w17, #0x5, 0x16d4 <_llm_rows.packet_batch.blocks+0x1348>
    1698:      	tbz	w17, #0x6, 0x16e0 <_llm_rows.packet_batch.blocks+0x1354>
    169c:      	add	x0, x16, #0x18
    16a0:      	ld1.s	{ v30 }[2], [x0]
    16a4:      	tbz	w17, #0x7, 0x1624 <_llm_rows.packet_batch.blocks+0x1298>
    16a8:      	b	0x16e4 <_llm_rows.packet_batch.blocks+0x1358>
    16ac:      	and	w17, w17, #0xff
    16b0:      	tbz	w17, #0x1, 0x1678 <_llm_rows.packet_batch.blocks+0x12ec>
    16b4:      	add	x0, x16, #0x4
    16b8:      	ld1.s	{ v3 }[1], [x0]
    16bc:      	tbnz	w17, #0x2, 0x167c <_llm_rows.packet_batch.blocks+0x12f0>
    16c0:      	tbz	w17, #0x3, 0x1688 <_llm_rows.packet_batch.blocks+0x12fc>
    16c4:      	add	x0, x16, #0xc
    16c8:      	ld1.s	{ v3 }[3], [x0]
    16cc:      	tbnz	w17, #0x4, 0x168c <_llm_rows.packet_batch.blocks+0x1300>
    16d0:      	tbz	w17, #0x5, 0x1698 <_llm_rows.packet_batch.blocks+0x130c>
    16d4:      	add	x0, x16, #0x14
    16d8:      	ld1.s	{ v30 }[1], [x0]
    16dc:      	tbnz	w17, #0x6, 0x169c <_llm_rows.packet_batch.blocks+0x1310>
    16e0:      	tbz	w17, #0x7, 0x1624 <_llm_rows.packet_batch.blocks+0x1298>
    16e4:      	add	x16, x16, #0x1c
    16e8:      	ld1.s	{ v30 }[3], [x16]
    16ec:      	b	0x1624 <_llm_rows.packet_batch.blocks+0x1298>
    16f0:      	umlal.2d	v1, v22, v2
    16f4:      	ldp	d4, d3, [sp, #0xd0]
    16f8:      	umlal.2d	v17, v4, v2
    16fc:      	umlal.2d	v14, v3, v2
    1700:      	umlal.2d	v11, v12, v2
    1704:      	mov	b3, v19[0]
    1708:      	mov.b	v3[4], v19[1]
    170c:      	ushll.2d	v3, v3, #0x0
    1710:      	shl.2d	v3, v3, #0x3f
    1714:      	cmlt.2d	v3, v3, #0
    1718:      	and.16b	v3, v3, v11
    171c:      	mov	b4, v19[2]
    1720:      	mov.b	v4[4], v19[3]
    1724:      	ushll.2d	v4, v4, #0x0
    1728:      	shl.2d	v4, v4, #0x3f
    172c:      	cmlt.2d	v4, v4, #0
    1730:      	and.16b	v4, v4, v14
    1734:      	mov	b5, v19[4]
    1738:      	mov.b	v5[4], v19[5]
    173c:      	ushll.2d	v5, v5, #0x0
    1740:      	shl.2d	v5, v5, #0x3f
    1744:      	cmlt.2d	v5, v5, #0
    1748:      	mov	b21, v19[6]
    174c:      	mov.b	v21[4], v19[7]
    1750:      	and.16b	v5, v5, v17
    1754:      	ushll.2d	v21, v21, #0x0
    1758:      	shl.2d	v21, v21, #0x3f
    175c:      	cmlt.2d	v21, v21, #0
    1760:      	and.16b	v21, v21, v1
    1764:      	stp	q5, q21, [sp, #0x350]
    1768:      	stp	q3, q4, [sp, #0x330]
    176c:      	and	x11, x12, #0x7
    1770:      	add	x15, sp, #0x330
    1774:      	ldr	x11, [x15, x11, lsl #3]
    1778:      	fmov	w15, s31
    177c:      	sub	x11, x11, x12
    1780:      	lsl	x11, x11, #2
    1784:      	add	x10, x10, x11
    1788:      	movi.2d	v3, #0000000000000000
    178c:      	movi.2d	v4, #0000000000000000
    1790:      	tbz	w15, #0x0, 0x17d4 <_llm_rows.packet_batch.blocks+0x1448>
    1794:      	ldr	s3, [x10]
    1798:      	ldr	q17, [sp, #0x70]
    179c:      	tbnz	w15, #0x1, 0x17dc <_llm_rows.packet_batch.blocks+0x1450>
    17a0:      	tbz	w15, #0x2, 0x17e8 <_llm_rows.packet_batch.blocks+0x145c>
    17a4:      	add	x16, x10, #0x8
    17a8:      	ld1.s	{ v3 }[2], [x16]
    17ac:      	tbnz	w15, #0x3, 0x17ec <_llm_rows.packet_batch.blocks+0x1460>
    17b0:      	tbz	w15, #0x4, 0x17f8 <_llm_rows.packet_batch.blocks+0x146c>
    17b4:      	add	x16, x10, #0x10
    17b8:      	ld1.s	{ v4 }[0], [x16]
    17bc:      	tbnz	w15, #0x5, 0x17fc <_llm_rows.packet_batch.blocks+0x1470>
    17c0:      	tbz	w15, #0x6, 0x1808 <_llm_rows.packet_batch.blocks+0x147c>
    17c4:      	add	x16, x10, #0x18
    17c8:      	ld1.s	{ v4 }[2], [x16]
    17cc:      	tbnz	w15, #0x7, 0x180c <_llm_rows.packet_batch.blocks+0x1480>
    17d0:      	b	0x1814 <_llm_rows.packet_batch.blocks+0x1488>
    17d4:      	ldr	q17, [sp, #0x70]
    17d8:      	tbz	w15, #0x1, 0x17a0 <_llm_rows.packet_batch.blocks+0x1414>
    17dc:      	add	x16, x10, #0x4
    17e0:      	ld1.s	{ v3 }[1], [x16]
    17e4:      	tbnz	w15, #0x2, 0x17a4 <_llm_rows.packet_batch.blocks+0x1418>
    17e8:      	tbz	w15, #0x3, 0x17b0 <_llm_rows.packet_batch.blocks+0x1424>
    17ec:      	add	x16, x10, #0xc
    17f0:      	ld1.s	{ v3 }[3], [x16]
    17f4:      	tbnz	w15, #0x4, 0x17b4 <_llm_rows.packet_batch.blocks+0x1428>
    17f8:      	tbz	w15, #0x5, 0x17c0 <_llm_rows.packet_batch.blocks+0x1434>
    17fc:      	add	x16, x10, #0x14
    1800:      	ld1.s	{ v4 }[1], [x16]
    1804:      	tbnz	w15, #0x6, 0x17c4 <_llm_rows.packet_batch.blocks+0x1438>
    1808:      	tbz	w15, #0x7, 0x1814 <_llm_rows.packet_batch.blocks+0x1488>
    180c:      	add	x10, x10, #0x1c
    1810:      	ld1.s	{ v4 }[3], [x10]
    1814:      	mov	x15, #0x0               ; =0
    1818:      	umull.2d	v5, v12, v2
    181c:      	add	x10, x19, x13
    1820:      	ldp	q2, q1, [x10]
    1824:      	zip2.8b	v21, v19, v0
    1828:      	ushll.4s	v21, v21, #0x0
    182c:      	shl.4s	v21, v21, #0x1f
    1830:      	cmlt.4s	v21, v21, #0
    1834:      	bit.16b	v1, v4, v21
    1838:      	zip1.8b	v4, v19, v0
    183c:      	ushll.4s	v4, v4, #0x0
    1840:      	shl.4s	v4, v4, #0x1f
    1844:      	cmlt.4s	v4, v4, #0
    1848:      	bit.16b	v2, v3, v4
    184c:      	stp	q2, q1, [x10]
    1850:      	fmov	x10, d5
    1854:      	add	x10, x9, x10, lsl #2
    1858:      	movi.2d	v3, #0000000000000000
    185c:      	movi.2d	v4, #0000000000000000
    1860:      	movi.2d	v5, #0000000000000000
    1864:      	movi.2d	v21, #0000000000000000
    1868:      	b	0x189c <_llm_rows.packet_batch.blocks+0x1510>
    186c:      	add	x15, x21, x15
    1870:      	ldp	q29, q30, [x15]
    1874:      	bif.16b	v28, v30, v6
    1878:      	bif.16b	v23, v29, v0
    187c:      	stp	q23, q28, [x15]
    1880:      	add.2d	v4, v4, v25
    1884:      	add.2d	v5, v5, v26
    1888:      	add.2d	v21, v21, v24
    188c:      	add.2d	v3, v3, v27
    1890:      	fmov	x15, d3
    1894:      	cmp	x15, #0x60
    1898:      	b.ge	0x1938 <_llm_rows.packet_batch.blocks+0x15ac>
    189c:      	fmov	w17, s7
    18a0:      	lsl	x15, x15, #5
    18a4:      	add	x16, x10, x15
    18a8:      	movi.2d	v23, #0000000000000000
    18ac:      	movi.2d	v28, #0000000000000000
    18b0:      	tbz	w17, #0x0, 0x18f4 <_llm_rows.packet_batch.blocks+0x1568>
    18b4:      	ldr	s23, [x16]
    18b8:      	and	w17, w17, #0xff
    18bc:      	tbnz	w17, #0x1, 0x18fc <_llm_rows.packet_batch.blocks+0x1570>
    18c0:      	tbz	w17, #0x2, 0x1908 <_llm_rows.packet_batch.blocks+0x157c>
    18c4:      	add	x0, x16, #0x8
    18c8:      	ld1.s	{ v23 }[2], [x0]
    18cc:      	tbnz	w17, #0x3, 0x190c <_llm_rows.packet_batch.blocks+0x1580>
    18d0:      	tbz	w17, #0x4, 0x1918 <_llm_rows.packet_batch.blocks+0x158c>
    18d4:      	add	x0, x16, #0x10
    18d8:      	ld1.s	{ v28 }[0], [x0]
    18dc:      	tbnz	w17, #0x5, 0x191c <_llm_rows.packet_batch.blocks+0x1590>
    18e0:      	tbz	w17, #0x6, 0x1928 <_llm_rows.packet_batch.blocks+0x159c>
    18e4:      	add	x0, x16, #0x18
    18e8:      	ld1.s	{ v28 }[2], [x0]
    18ec:      	tbz	w17, #0x7, 0x186c <_llm_rows.packet_batch.blocks+0x14e0>
    18f0:      	b	0x192c <_llm_rows.packet_batch.blocks+0x15a0>
    18f4:      	and	w17, w17, #0xff
    18f8:      	tbz	w17, #0x1, 0x18c0 <_llm_rows.packet_batch.blocks+0x1534>
    18fc:      	add	x0, x16, #0x4
    1900:      	ld1.s	{ v23 }[1], [x0]
    1904:      	tbnz	w17, #0x2, 0x18c4 <_llm_rows.packet_batch.blocks+0x1538>
    1908:      	tbz	w17, #0x3, 0x18d0 <_llm_rows.packet_batch.blocks+0x1544>
    190c:      	add	x0, x16, #0xc
    1910:      	ld1.s	{ v23 }[3], [x0]
    1914:      	tbnz	w17, #0x4, 0x18d4 <_llm_rows.packet_batch.blocks+0x1548>
    1918:      	tbz	w17, #0x5, 0x18e0 <_llm_rows.packet_batch.blocks+0x1554>
    191c:      	add	x0, x16, #0x14
    1920:      	ld1.s	{ v28 }[1], [x0]
    1924:      	tbnz	w17, #0x6, 0x18e4 <_llm_rows.packet_batch.blocks+0x1558>
    1928:      	tbz	w17, #0x7, 0x186c <_llm_rows.packet_batch.blocks+0x14e0>
    192c:      	add	x16, x16, #0x1c
    1930:      	ld1.s	{ v28 }[3], [x16]
    1934:      	b	0x186c <_llm_rows.packet_batch.blocks+0x14e0>
    1938:      	add	x9, x9, x11
    193c:      	fmov	w10, s31
    1940:      	movi.2d	v4, #0000000000000000
    1944:      	movi.2d	v3, #0000000000000000
    1948:      	tbz	w10, #0x0, 0x1988 <_llm_rows.packet_batch.blocks+0x15fc>
    194c:      	ldr	s4, [x9]
    1950:      	tbnz	w10, #0x1, 0x198c <_llm_rows.packet_batch.blocks+0x1600>
    1954:      	tbz	w10, #0x2, 0x1998 <_llm_rows.packet_batch.blocks+0x160c>
    1958:      	add	x11, x9, #0x8
    195c:      	ld1.s	{ v4 }[2], [x11]
    1960:      	tbnz	w10, #0x3, 0x199c <_llm_rows.packet_batch.blocks+0x1610>
    1964:      	tbz	w10, #0x4, 0x19a8 <_llm_rows.packet_batch.blocks+0x161c>
    1968:      	add	x11, x9, #0x10
    196c:      	ld1.s	{ v3 }[0], [x11]
    1970:      	tbnz	w10, #0x5, 0x19ac <_llm_rows.packet_batch.blocks+0x1620>
    1974:      	tbz	w10, #0x6, 0x19b8 <_llm_rows.packet_batch.blocks+0x162c>
    1978:      	add	x11, x9, #0x18
    197c:      	ld1.s	{ v3 }[2], [x11]
    1980:      	tbnz	w10, #0x7, 0x19bc <_llm_rows.packet_batch.blocks+0x1630>
    1984:      	b	0x19c4 <_llm_rows.packet_batch.blocks+0x1638>
    1988:      	tbz	w10, #0x1, 0x1954 <_llm_rows.packet_batch.blocks+0x15c8>
    198c:      	add	x11, x9, #0x4
    1990:      	ld1.s	{ v4 }[1], [x11]
    1994:      	tbnz	w10, #0x2, 0x1958 <_llm_rows.packet_batch.blocks+0x15cc>
    1998:      	tbz	w10, #0x3, 0x1964 <_llm_rows.packet_batch.blocks+0x15d8>
    199c:      	add	x11, x9, #0xc
    19a0:      	ld1.s	{ v4 }[3], [x11]
    19a4:      	tbnz	w10, #0x4, 0x1968 <_llm_rows.packet_batch.blocks+0x15dc>
    19a8:      	tbz	w10, #0x5, 0x1974 <_llm_rows.packet_batch.blocks+0x15e8>
    19ac:      	add	x11, x9, #0x14
    19b0:      	ld1.s	{ v3 }[1], [x11]
    19b4:      	tbnz	w10, #0x6, 0x1978 <_llm_rows.packet_batch.blocks+0x15ec>
    19b8:      	tbz	w10, #0x7, 0x19c4 <_llm_rows.packet_batch.blocks+0x1638>
    19bc:      	add	x9, x9, #0x1c
    19c0:      	ld1.s	{ v3 }[3], [x9]
    19c4:      	mov	x10, #0x0               ; =0
    19c8:      	add	x9, x21, x13
    19cc:      	ldp	q5, q21, [x9]
    19d0:      	zip2.8b	v23, v19, v0
    19d4:      	ushll.4s	v23, v23, #0x0
    19d8:      	shl.4s	v23, v23, #0x1f
    19dc:      	cmlt.4s	v23, v23, #0
    19e0:      	bif.16b	v3, v21, v23
    19e4:      	zip1.8b	v21, v19, v0
    19e8:      	ushll.4s	v21, v21, #0x0
    19ec:      	shl.4s	v21, v21, #0x1f
    19f0:      	cmlt.4s	v21, v21, #0
    19f4:      	bif.16b	v4, v5, v21
    19f8:      	stp	q4, q3, [x9]
    19fc:      	add	x9, x8, x14
    1a00:      	movi.2d	v5, #0000000000000000
    1a04:      	movi.2d	v21, #0000000000000000
    1a08:      	movi.2d	v23, #0000000000000000
    1a0c:      	movi.2d	v28, #0000000000000000
    1a10:      	b	0x1a30 <_llm_rows.packet_batch.blocks+0x16a4>
    1a14:      	add.2d	v21, v21, v25
    1a18:      	add.2d	v23, v23, v26
    1a1c:      	add.2d	v28, v28, v24
    1a20:      	add.2d	v5, v5, v27
    1a24:      	fmov	x10, d5
    1a28:      	cmp	x10, #0x60
    1a2c:      	b.ge	0x1b10 <_llm_rows.packet_batch.blocks+0x1784>
    1a30:      	fmov	w11, s7
    1a34:      	lsl	x10, x10, #5
    1a38:      	add	x13, x3, x10
    1a3c:      	ldp	q8, q29, [x13]
    1a40:      	add	x13, x19, x10
    1a44:      	ldp	q11, q30, [x13]
    1a48:      	fmul.4s	v12, v8, v11
    1a4c:      	add	x13, x27, x10
    1a50:      	ldp	q13, q8, [x13]
    1a54:      	add	x13, x21, x10
    1a58:      	ldp	q14, q11, [x13]
    1a5c:      	fmul.4s	v13, v13, v14
    1a60:      	fsub.4s	v12, v12, v13
    1a64:      	and.16b	v12, v0, v12
    1a68:      	add	x10, x9, x10
    1a6c:      	tbz	w11, #0x0, 0x1abc <_llm_rows.packet_batch.blocks+0x1730>
    1a70:      	str	s12, [x10]
    1a74:      	and	w11, w11, #0xff
    1a78:      	tbnz	w11, #0x1, 0x1ac4 <_llm_rows.packet_batch.blocks+0x1738>
    1a7c:      	tbz	w11, #0x2, 0x1ad0 <_llm_rows.packet_batch.blocks+0x1744>
    1a80:      	add	x13, x10, #0x8
    1a84:      	st1.s	{ v12 }[2], [x13]
    1a88:      	tbnz	w11, #0x3, 0x1ad4 <_llm_rows.packet_batch.blocks+0x1748>
    1a8c:      	fmul.4s	v29, v29, v30
    1a90:      	fmul.4s	v30, v8, v11
    1a94:      	fsub.4s	v29, v29, v30
    1a98:      	and.16b	v29, v6, v29
    1a9c:      	tbz	w11, #0x4, 0x1af0 <_llm_rows.packet_batch.blocks+0x1764>
    1aa0:      	str	s29, [x10, #0x10]
    1aa4:      	tbnz	w11, #0x5, 0x1af4 <_llm_rows.packet_batch.blocks+0x1768>
    1aa8:      	tbz	w11, #0x6, 0x1b00 <_llm_rows.packet_batch.blocks+0x1774>
    1aac:      	add	x13, x10, #0x18
    1ab0:      	st1.s	{ v29 }[2], [x13]
    1ab4:      	tbz	w11, #0x7, 0x1a14 <_llm_rows.packet_batch.blocks+0x1688>
    1ab8:      	b	0x1b04 <_llm_rows.packet_batch.blocks+0x1778>
    1abc:      	and	w11, w11, #0xff
    1ac0:      	tbz	w11, #0x1, 0x1a7c <_llm_rows.packet_batch.blocks+0x16f0>
    1ac4:      	add	x13, x10, #0x4
    1ac8:      	st1.s	{ v12 }[1], [x13]
    1acc:      	tbnz	w11, #0x2, 0x1a80 <_llm_rows.packet_batch.blocks+0x16f4>
    1ad0:      	tbz	w11, #0x3, 0x1a8c <_llm_rows.packet_batch.blocks+0x1700>
    1ad4:      	add	x13, x10, #0xc
    1ad8:      	st1.s	{ v12 }[3], [x13]
    1adc:      	fmul.4s	v29, v29, v30
    1ae0:      	fmul.4s	v30, v8, v11
    1ae4:      	fsub.4s	v29, v29, v30
    1ae8:      	and.16b	v29, v6, v29
    1aec:      	tbnz	w11, #0x4, 0x1aa0 <_llm_rows.packet_batch.blocks+0x1714>
    1af0:      	tbz	w11, #0x5, 0x1aa8 <_llm_rows.packet_batch.blocks+0x171c>
    1af4:      	add	x13, x10, #0x14
    1af8:      	st1.s	{ v29 }[1], [x13]
    1afc:      	tbnz	w11, #0x6, 0x1aac <_llm_rows.packet_batch.blocks+0x1720>
    1b00:      	tbz	w11, #0x7, 0x1a14 <_llm_rows.packet_batch.blocks+0x1688>
    1b04:      	add	x10, x10, #0x1c
    1b08:      	st1.s	{ v29 }[3], [x10]
    1b0c:      	b	0x1a14 <_llm_rows.packet_batch.blocks+0x1688>
    1b10:      	ldr	q5, [sp, #0xc0]
    1b14:      	fmul.4s	v5, v5, v2
    1b18:      	fmul.4s	v21, v10, v4
    1b1c:      	fsub.4s	v5, v5, v21
    1b20:      	zip1.8b	v21, v19, v0
    1b24:      	ushll.4s	v21, v21, #0x0
    1b28:      	shl.4s	v21, v21, #0x1f
    1b2c:      	cmlt.4s	v21, v21, #0
    1b30:      	and.16b	v5, v21, v5
    1b34:      	fmov	w10, s31
    1b38:      	ldr	q21, [sp, #0x60]
    1b3c:      	ldp	q22, q23, [sp, #0x40]
    1b40:      	stp	q21, q22, [sp, #0x2e0]
    1b44:      	ldr	q18, [sp, #0x30]
    1b48:      	stp	q23, q18, [sp, #0x300]
    1b4c:      	and	x11, x12, #0x7
    1b50:      	add	x13, sp, #0x2e0
    1b54:      	ldr	x11, [x13, x11, lsl #3]
    1b58:      	sub	x11, x11, x12
    1b5c:      	add	x11, x8, x11, lsl #2
    1b60:      	tbz	w10, #0x0, 0x1b80 <_llm_rows.packet_batch.blocks+0x17f4>
    1b64:      	str	s5, [x11]
    1b68:      	tbnz	w10, #0x1, 0x1b84 <_llm_rows.packet_batch.blocks+0x17f8>
    1b6c:      	tbz	w10, #0x2, 0x1b90 <_llm_rows.packet_batch.blocks+0x1804>
    1b70:      	add	x13, x11, #0x8
    1b74:      	st1.s	{ v5 }[2], [x13]
    1b78:      	tbnz	w10, #0x3, 0x1b94 <_llm_rows.packet_batch.blocks+0x1808>
    1b7c:      	b	0x1b9c <_llm_rows.packet_batch.blocks+0x1810>
    1b80:      	tbz	w10, #0x1, 0x1b6c <_llm_rows.packet_batch.blocks+0x17e0>
    1b84:      	add	x13, x11, #0x4
    1b88:      	st1.s	{ v5 }[1], [x13]
    1b8c:      	tbnz	w10, #0x2, 0x1b70 <_llm_rows.packet_batch.blocks+0x17e4>
    1b90:      	tbz	w10, #0x3, 0x1b9c <_llm_rows.packet_batch.blocks+0x1810>
    1b94:      	add	x13, x11, #0xc
    1b98:      	st1.s	{ v5 }[3], [x13]
    1b9c:      	fmul.4s	v5, v17, v1
    1ba0:      	fmul.4s	v21, v9, v3
    1ba4:      	fsub.4s	v5, v5, v21
    1ba8:      	zip2.8b	v21, v19, v0
    1bac:      	ushll.4s	v21, v21, #0x0
    1bb0:      	shl.4s	v21, v21, #0x1f
    1bb4:      	cmlt.4s	v21, v21, #0
    1bb8:      	and.16b	v5, v21, v5
    1bbc:      	tbz	w10, #0x4, 0x1bdc <_llm_rows.packet_batch.blocks+0x1850>
    1bc0:      	str	s5, [x11, #0x10]
    1bc4:      	tbnz	w10, #0x5, 0x1be0 <_llm_rows.packet_batch.blocks+0x1854>
    1bc8:      	tbz	w10, #0x6, 0x1bec <_llm_rows.packet_batch.blocks+0x1860>
    1bcc:      	add	x13, x11, #0x18
    1bd0:      	st1.s	{ v5 }[2], [x13]
    1bd4:      	tbnz	w10, #0x7, 0x1bf0 <_llm_rows.packet_batch.blocks+0x1864>
    1bd8:      	b	0x1bf8 <_llm_rows.packet_batch.blocks+0x186c>
    1bdc:      	tbz	w10, #0x5, 0x1bc8 <_llm_rows.packet_batch.blocks+0x183c>
    1be0:      	add	x13, x11, #0x14
    1be4:      	st1.s	{ v5 }[1], [x13]
    1be8:      	tbnz	w10, #0x6, 0x1bcc <_llm_rows.packet_batch.blocks+0x1840>
    1bec:      	tbz	w10, #0x7, 0x1bf8 <_llm_rows.packet_batch.blocks+0x186c>
    1bf0:      	add	x10, x11, #0x1c
    1bf4:      	st1.s	{ v5 }[3], [x10]
    1bf8:      	mov	x10, #0x0               ; =0
    1bfc:      	add	x9, x9, #0xc04
    1c00:      	movi.2d	v5, #0000000000000000
    1c04:      	movi.2d	v21, #0000000000000000
    1c08:      	movi.2d	v22, #0000000000000000
    1c0c:      	movi.2d	v23, #0000000000000000
    1c10:      	b	0x1c30 <_llm_rows.packet_batch.blocks+0x18a4>
    1c14:      	add.2d	v21, v21, v25
    1c18:      	add.2d	v22, v22, v26
    1c1c:      	add.2d	v23, v23, v24
    1c20:      	add.2d	v5, v5, v27
    1c24:      	fmov	x10, d5
    1c28:      	cmp	x10, #0x60
    1c2c:      	b.ge	0x1d10 <_llm_rows.packet_batch.blocks+0x1984>
    1c30:      	fmov	w11, s7
    1c34:      	lsl	x10, x10, #5
    1c38:      	add	x13, x3, x10
    1c3c:      	ldp	q30, q28, [x13]
    1c40:      	add	x13, x21, x10
    1c44:      	ldp	q8, q29, [x13]
    1c48:      	fmul.4s	v11, v30, v8
    1c4c:      	add	x13, x27, x10
    1c50:      	ldp	q12, q30, [x13]
    1c54:      	add	x13, x19, x10
    1c58:      	ldp	q13, q8, [x13]
    1c5c:      	fmul.4s	v12, v12, v13
    1c60:      	fadd.4s	v11, v11, v12
    1c64:      	and.16b	v11, v0, v11
    1c68:      	add	x10, x9, x10
    1c6c:      	tbz	w11, #0x0, 0x1cbc <_llm_rows.packet_batch.blocks+0x1930>
    1c70:      	str	s11, [x10]
    1c74:      	and	w11, w11, #0xff
    1c78:      	tbnz	w11, #0x1, 0x1cc4 <_llm_rows.packet_batch.blocks+0x1938>
    1c7c:      	tbz	w11, #0x2, 0x1cd0 <_llm_rows.packet_batch.blocks+0x1944>
    1c80:      	add	x13, x10, #0x8
    1c84:      	st1.s	{ v11 }[2], [x13]
    1c88:      	tbnz	w11, #0x3, 0x1cd4 <_llm_rows.packet_batch.blocks+0x1948>
    1c8c:      	fmul.4s	v28, v28, v29
    1c90:      	fmul.4s	v29, v30, v8
    1c94:      	fadd.4s	v28, v28, v29
    1c98:      	and.16b	v28, v6, v28
    1c9c:      	tbz	w11, #0x4, 0x1cf0 <_llm_rows.packet_batch.blocks+0x1964>
    1ca0:      	str	s28, [x10, #0x10]
    1ca4:      	tbnz	w11, #0x5, 0x1cf4 <_llm_rows.packet_batch.blocks+0x1968>
    1ca8:      	tbz	w11, #0x6, 0x1d00 <_llm_rows.packet_batch.blocks+0x1974>
    1cac:      	add	x13, x10, #0x18
    1cb0:      	st1.s	{ v28 }[2], [x13]
    1cb4:      	tbz	w11, #0x7, 0x1c14 <_llm_rows.packet_batch.blocks+0x1888>
    1cb8:      	b	0x1d04 <_llm_rows.packet_batch.blocks+0x1978>
    1cbc:      	and	w11, w11, #0xff
    1cc0:      	tbz	w11, #0x1, 0x1c7c <_llm_rows.packet_batch.blocks+0x18f0>
    1cc4:      	add	x13, x10, #0x4
    1cc8:      	st1.s	{ v11 }[1], [x13]
    1ccc:      	tbnz	w11, #0x2, 0x1c80 <_llm_rows.packet_batch.blocks+0x18f4>
    1cd0:      	tbz	w11, #0x3, 0x1c8c <_llm_rows.packet_batch.blocks+0x1900>
    1cd4:      	add	x13, x10, #0xc
    1cd8:      	st1.s	{ v11 }[3], [x13]
    1cdc:      	fmul.4s	v28, v28, v29
    1ce0:      	fmul.4s	v29, v30, v8
    1ce4:      	fadd.4s	v28, v28, v29
    1ce8:      	and.16b	v28, v6, v28
    1cec:      	tbnz	w11, #0x4, 0x1ca0 <_llm_rows.packet_batch.blocks+0x1914>
    1cf0:      	tbz	w11, #0x5, 0x1ca8 <_llm_rows.packet_batch.blocks+0x191c>
    1cf4:      	add	x13, x10, #0x14
    1cf8:      	st1.s	{ v28 }[1], [x13]
    1cfc:      	tbnz	w11, #0x6, 0x1cac <_llm_rows.packet_batch.blocks+0x1920>
    1d00:      	tbz	w11, #0x7, 0x1c14 <_llm_rows.packet_batch.blocks+0x1888>
    1d04:      	add	x10, x10, #0x1c
    1d08:      	st1.s	{ v28 }[3], [x10]
    1d0c:      	b	0x1c14 <_llm_rows.packet_batch.blocks+0x1888>
    1d10:      	ldr	q0, [sp, #0xc0]
    1d14:      	fmul.4s	v0, v0, v4
    1d18:      	fmul.4s	v2, v10, v2
    1d1c:      	fadd.4s	v0, v2, v0
    1d20:      	zip1.8b	v2, v19, v0
    1d24:      	ushll.4s	v2, v2, #0x0
    1d28:      	shl.4s	v2, v2, #0x1f
    1d2c:      	cmlt.4s	v2, v2, #0
    1d30:      	and.16b	v0, v2, v0
    1d34:      	fmov	w9, s31
    1d38:      	stp	q20, q16, [sp, #0x290]
    1d3c:      	ldp	q4, q2, [sp, #0x10]
    1d40:      	stp	q4, q2, [sp, #0x2b0]
    1d44:      	and	x10, x12, #0x7
    1d48:      	add	x11, sp, #0x290
    1d4c:      	ldr	x10, [x11, x10, lsl #3]
    1d50:      	sub	x10, x10, x12
    1d54:      	add	x8, x8, x10, lsl #2
    1d58:      	tbz	w9, #0x0, 0x1d7c <_llm_rows.packet_batch.blocks+0x19f0>
    1d5c:      	str	s0, [x8]
    1d60:      	ldr	d10, [sp, #0x8]
    1d64:      	tbnz	w9, #0x1, 0x1d84 <_llm_rows.packet_batch.blocks+0x19f8>
    1d68:      	tbz	w9, #0x2, 0x1d90 <_llm_rows.packet_batch.blocks+0x1a04>
    1d6c:      	add	x10, x8, #0x8
    1d70:      	st1.s	{ v0 }[2], [x10]
    1d74:      	tbnz	w9, #0x3, 0x1d94 <_llm_rows.packet_batch.blocks+0x1a08>
    1d78:      	b	0x1d9c <_llm_rows.packet_batch.blocks+0x1a10>
    1d7c:      	ldr	d10, [sp, #0x8]
    1d80:      	tbz	w9, #0x1, 0x1d68 <_llm_rows.packet_batch.blocks+0x19dc>
    1d84:      	add	x10, x8, #0x4
    1d88:      	st1.s	{ v0 }[1], [x10]
    1d8c:      	tbnz	w9, #0x2, 0x1d6c <_llm_rows.packet_batch.blocks+0x19e0>
    1d90:      	tbz	w9, #0x3, 0x1d9c <_llm_rows.packet_batch.blocks+0x1a10>
    1d94:      	add	x10, x8, #0xc
    1d98:      	st1.s	{ v0 }[3], [x10]
    1d9c:      	fmul.4s	v0, v17, v3
    1da0:      	fmul.4s	v1, v9, v1
    1da4:      	fadd.4s	v0, v1, v0
    1da8:      	zip2.8b	v1, v19, v0
    1dac:      	ushll.4s	v1, v1, #0x0
    1db0:      	shl.4s	v1, v1, #0x1f
    1db4:      	cmlt.4s	v1, v1, #0
    1db8:      	and.16b	v0, v1, v0
    1dbc:      	tbnz	w9, #0x4, 0x1028 <_llm_rows.packet_batch.blocks+0xc9c>
    1dc0:      	tbz	w9, #0x5, 0x1030 <_llm_rows.packet_batch.blocks+0xca4>
    1dc4:      	add	x10, x8, #0x14
    1dc8:      	st1.s	{ v0 }[1], [x10]
    1dcc:      	tbnz	w9, #0x6, 0x1034 <_llm_rows.packet_batch.blocks+0xca8>
    1dd0:      	tbz	w9, #0x7, 0x464 <_llm_rows.packet_batch.blocks+0xd8>
    1dd4:      	add	x8, x8, #0x1c
    1dd8:      	st1.s	{ v0 }[3], [x8]
    1ddc:      	b	0x464 <_llm_rows.packet_batch.blocks+0xd8>
    1de0:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    1de4:      	add	sp, sp, #0x4e0
    1de8:      	ldp	x29, x30, [sp, #0x90]
    1dec:      	ldp	x20, x19, [sp, #0x80]
    1df0:      	ldp	x22, x21, [sp, #0x70]
    1df4:      	ldp	x24, x23, [sp, #0x60]
    1df8:      	ldp	x26, x25, [sp, #0x50]
    1dfc:      	ldp	x28, x27, [sp, #0x40]
    1e00:      	ldp	d9, d8, [sp, #0x30]
    1e04:      	ldp	d11, d10, [sp, #0x20]
    1e08:      	ldp	d13, d12, [sp, #0x10]
    1e0c:      	ldp	d15, d14, [sp], #0xa0
    1e10:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/layernorm-1024x4097/on/object/tile_xir_w8_37927_1788936537199939_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	mov	x10, #0x0               ; =0
       4:      	ldr	x8, [x1, #0x88]
       8:      	ldr	x14, [x0]
       c:      	ldr	x13, [x0, #0x10]
      10:      	ldr	w9, [x1]
      14:      	ldr	w11, [x1, #0x24]
      18:      	add	w9, w11, w9, lsl #5
      1c:      	lsr	w9, w9, #3
      20:      	mov	w11, #0x4004            ; =16388
      24:      	umull	x12, w9, w11
      28:      	umaddl	x15, w9, w11, x14
      2c:      	ldr	x11, [x0, #0x20]
      30:      	ldr	x9, [x0, #0x30]
      34:      	add	x16, x15, x10
      38:      	ldp	q0, q1, [x16]
      3c:      	add	x16, x8, x10
      40:      	stp	q0, q1, [x16]
      44:      	add	x10, x10, #0x20
      48:      	cmp	x10, #0x4, lsl #12      ; =0x4000
      4c:      	b.ne	0x34 <ltmp0+0x34>
      50:      	add	x10, x12, #0x4, lsl #12 ; =0x4000
      54:      	add	x14, x14, x10
      58:      	ldr	q0, [x8, #0x4000]
      5c:      	ld1.s	{ v0 }[0], [x14]
      60:      	str	q0, [x8, #0x4000]
      64:      	ldp	q1, q2, [x8]
      68:      	ldp	q6, q7, [x8, #0x20]
      6c:      	ldp	q16, q3, [x8, #0x40]
      70:      	ldp	q4, q5, [x8, #0x60]
      74:      	add	x14, x8, #0xe0
      78:      	mov	w15, #0x4               ; =4
      7c:      	ldp	q17, q18, [x14, #-0x60]
      80:      	fadd.4s	v2, v2, v18
      84:      	fadd.4s	v1, v1, v17
      88:      	ldp	q17, q18, [x14, #-0x40]
      8c:      	fadd.4s	v7, v7, v18
      90:      	fadd.4s	v6, v6, v17
      94:      	ldp	q17, q18, [x14, #-0x20]
      98:      	fadd.4s	v3, v3, v18
      9c:      	fadd.4s	v16, v16, v17
      a0:      	ldp	q17, q18, [x14], #0x80
      a4:      	fadd.4s	v5, v5, v18
      a8:      	fadd.4s	v4, v4, v17
      ac:      	cmp	x15, #0x1fc
      b0:      	add	x15, x15, #0x4
      b4:      	b.lo	0x7c <ltmp0+0x7c>
      b8:      	mov	w14, #0x4020            ; =16416
      bc:      	add	x14, x8, x14
      c0:      	fadd.4s	v17, v0, v1
      c4:      	mov.s	v1[0], v17[0]
      c8:      	fadd.4s	v2, v7, v2
      cc:      	fadd.4s	v1, v6, v1
      d0:      	fadd.4s	v1, v16, v1
      d4:      	fadd.4s	v2, v3, v2
      d8:      	fadd.4s	v2, v5, v2
      dc:      	fadd.4s	v1, v4, v1
      e0:      	rev64.4s	v3, v1
      e4:      	rev64.4s	v4, v2
      e8:      	fadd.4s	v2, v2, v4
      ec:      	fadd.4s	v1, v1, v3
      f0:      	dup.4s	v3, v1[2]
      f4:      	dup.4s	v4, v2[2]
      f8:      	fadd.4s	v2, v2, v4
      fc:      	fadd.4s	v1, v1, v3
     100:      	fadd.4s	v1, v1, v2
     104:      	movi	d2, #0000000000000000
     108:      	fadd	s1, s1, s2
     10c:      	mov	w15, #0x800             ; =2048
     110:      	movk	w15, #0x4580, lsl #16
     114:      	fmov	s2, w15
     118:      	fdiv	s1, s1, s2
     11c:      	dup.4s	v2, v1[0]
     120:      	mov	w15, #0x200             ; =512
     124:      	mov	x16, x8
     128:      	ldp	q4, q3, [x16]
     12c:      	fsub.4s	v4, v4, v2
     130:      	fsub.4s	v3, v3, v2
     134:      	str	q3, [x16, #0x4030]
     138:      	str	q4, [x16, #0x4020]
     13c:      	add	x16, x16, #0x20
     140:      	subs	x15, x15, #0x1
     144:      	b.ne	0x128 <ltmp0+0x128>
     148:      	fsub.4s	v0, v0, v1
     14c:      	ldr	q1, [x8, #0x8020]
     150:      	mov.s	v1[0], v0[0]
     154:      	str	q1, [x8, #0x8020]
     158:      	ldr	q1, [x8, #0x4020]
     15c:      	ldr	q2, [x8, #0x4030]
     160:      	fmul.4s	v2, v2, v2
     164:      	fmul.4s	v1, v1, v1
     168:      	ldr	q3, [x8, #0x4040]
     16c:      	ldr	q4, [x8, #0x4050]
     170:      	fmul.4s	v4, v4, v4
     174:      	fmul.4s	v3, v3, v3
     178:      	ldr	q6, [x8, #0x4060]
     17c:      	ldr	q5, [x8, #0x4070]
     180:      	fmul.4s	v5, v5, v5
     184:      	fmul.4s	v6, v6, v6
     188:      	ldr	q7, [x8, #0x4080]
     18c:      	ldr	q16, [x8, #0x4090]
     190:      	fmul.4s	v16, v16, v16
     194:      	fmul.4s	v7, v7, v7
     198:      	mov	w15, #0x4100            ; =16640
     19c:      	add	x15, x8, x15
     1a0:      	mov	w16, #0x205             ; =517
     1a4:      	ldp	q18, q17, [x15, #-0x60]
     1a8:      	fmul.4s	v18, v18, v18
     1ac:      	fmul.4s	v17, v17, v17
     1b0:      	fadd.4s	v2, v2, v17
     1b4:      	fadd.4s	v1, v1, v18
     1b8:      	ldp	q18, q17, [x15, #-0x40]
     1bc:      	fmul.4s	v18, v18, v18
     1c0:      	fmul.4s	v17, v17, v17
     1c4:      	fadd.4s	v4, v4, v17
     1c8:      	fadd.4s	v3, v3, v18
     1cc:      	ldp	q18, q17, [x15, #-0x20]
     1d0:      	fmul.4s	v18, v18, v18
     1d4:      	fmul.4s	v17, v17, v17
     1d8:      	fadd.4s	v5, v5, v17
     1dc:      	fadd.4s	v6, v6, v18
     1e0:      	ldp	q18, q17, [x15], #0x80
     1e4:      	fmul.4s	v18, v18, v18
     1e8:      	fmul.4s	v17, v17, v17
     1ec:      	fadd.4s	v16, v16, v17
     1f0:      	fadd.4s	v7, v7, v18
     1f4:      	sub	x17, x16, #0x201
     1f8:      	add	x16, x16, #0x4
     1fc:      	cmp	x17, #0x1fc
     200:      	b.lo	0x1a4 <ltmp0+0x1a4>
     204:      	mov	x15, #0x0               ; =0
     208:      	mov	w16, #0x8040            ; =32832
     20c:      	add	x16, x8, x16
     210:      	add	x17, x13, x15
     214:      	ldp	q17, q18, [x17]
     218:      	add	x17, x16, x15
     21c:      	stp	q17, q18, [x17]
     220:      	add	x15, x15, #0x20
     224:      	cmp	x15, #0x4, lsl #12      ; =0x4000
     228:      	b.ne	0x210 <ltmp0+0x210>
     22c:      	fmul.4s	v0, v0, v0
     230:      	fadd.4s	v0, v0, v1
     234:      	mov.s	v1[0], v0[0]
     238:      	fadd.4s	v0, v4, v2
     23c:      	fadd.4s	v1, v3, v1
     240:      	fadd.4s	v1, v6, v1
     244:      	fadd.4s	v0, v5, v0
     248:      	fadd.4s	v0, v16, v0
     24c:      	fadd.4s	v1, v7, v1
     250:      	rev64.4s	v2, v1
     254:      	rev64.4s	v3, v0
     258:      	fadd.4s	v0, v0, v3
     25c:      	fadd.4s	v1, v1, v2
     260:      	dup.4s	v2, v1[2]
     264:      	dup.4s	v3, v0[2]
     268:      	fadd.4s	v0, v0, v3
     26c:      	fadd.4s	v1, v1, v2
     270:      	fadd.4s	v0, v1, v0
     274:      	movi	d1, #0000000000000000
     278:      	fadd	s0, s0, s1
     27c:      	mov	w15, #0x800             ; =2048
     280:      	movk	w15, #0x4580, lsl #16
     284:      	fmov	s1, w15
     288:      	fdiv	s0, s0, s1
     28c:      	mov	w15, #0x4000            ; =16384
     290:      	ldr	s1, [x13, x15]
     294:      	mov	w13, #0xc040            ; =49216
     298:      	str	s1, [x8, x13]
     29c:      	mov	w13, #0xc5ac            ; =50604
     2a0:      	movk	w13, #0x3727, lsl #16
     2a4:      	fmov	s1, w13
     2a8:      	fadd	s0, s0, s1
     2ac:      	fsqrt	s0, s0
     2b0:      	subs	x13, x9, x11
     2b4:      	mov	w15, #0x4003            ; =16387
     2b8:      	ccmp	x13, x15, #0x0, hs
     2bc:      	cset	w13, hi
     2c0:      	mov	w15, #0xfff             ; =4095
     2c4:      	movk	w15, #0x100, lsl #16
     2c8:      	sub	x16, x11, x9
     2cc:      	cmp	x16, x15
     2d0:      	ccmp	x11, x9, #0x0, hi
     2d4:      	b.hs	0x388 <ltmp0+0x388>
     2d8:      	tbnz	w13, #0x0, 0x388 <ltmp0+0x388>
     2dc:      	mov	x13, #0x0               ; =0
     2e0:      	mov	w14, #0xc060            ; =49248
     2e4:      	add	x14, x8, x14
     2e8:      	add	x15, x11, x13
     2ec:      	ldp	q1, q2, [x15]
     2f0:      	add	x15, x14, x13
     2f4:      	stp	q1, q2, [x15]
     2f8:      	add	x13, x13, #0x20
     2fc:      	cmp	x13, #0x4, lsl #12      ; =0x4000
     300:      	b.ne	0x2e8 <ltmp0+0x2e8>
     304:      	ldr	s1, [x11, x13]
     308:      	mov	w11, #0x60              ; =96
     30c:      	movk	w11, #0x1, lsl #16
     310:      	str	s1, [x8, x11]
     314:      	dup.4s	v1, v0[0]
     318:      	add	x11, x9, x12
     31c:      	mov	w12, #0x200             ; =512
     320:      	mov	x13, x8
     324:      	ldr	q2, [x13, #0x4030]
     328:      	ldr	q3, [x13, #0x4020]
     32c:      	fdiv.4s	v3, v3, v1
     330:      	fdiv.4s	v2, v2, v1
     334:      	ldr	q4, [x13, #0x8040]
     338:      	ldr	q5, [x13, #0x8050]
     33c:      	fmul.4s	v2, v2, v5
     340:      	fmul.4s	v3, v3, v4
     344:      	ldr	q4, [x13, #0xc070]
     348:      	ldr	q5, [x13, #0xc060]
     34c:      	fadd.4s	v3, v3, v5
     350:      	fadd.4s	v2, v2, v4
     354:      	stp	q3, q2, [x11], #0x20
     358:      	add	x13, x13, #0x20
     35c:      	subs	x12, x12, #0x1
     360:      	b.ne	0x324 <ltmp0+0x324>
     364:      	ldr	q1, [x8, #0x8020]
     368:      	fdiv.4s	v0, v1, v0
     36c:      	ldr	q1, [x8, #0xc040]
     370:      	fmul.4s	v0, v0, v1
     374:      	add	x11, x8, #0x10, lsl #12 ; =0x10000
     378:      	ldr	q1, [x11, #0x60]
     37c:      	fadd.4s	v0, v0, v1
     380:      	str	s0, [x9, x10]
     384:      	ret
     388:      	dup.4s	v1, v0[0]
     38c:      	add	x12, x9, x12
     390:      	mov	w15, #0x201             ; =513
     394:      	mov	x13, x11
     398:      	ldp	q3, q2, [x14]
     39c:      	fdiv.4s	v3, v3, v1
     3a0:      	fdiv.4s	v2, v2, v1
     3a4:      	ldr	q4, [x14, #0x4020]
     3a8:      	ldr	q5, [x14, #0x4030]
     3ac:      	fmul.4s	v2, v2, v5
     3b0:      	fmul.4s	v3, v3, v4
     3b4:      	ldp	q5, q4, [x13], #0x20
     3b8:      	fadd.4s	v3, v3, v5
     3bc:      	fadd.4s	v2, v2, v4
     3c0:      	sub	x16, x15, #0x200
     3c4:      	add	x15, x15, #0x1
     3c8:      	stp	q3, q2, [x12], #0x20
     3cc:      	add	x14, x14, #0x20
     3d0:      	cmp	x16, #0x200
     3d4:      	b.lt	0x398 <ltmp0+0x398>
     3d8:      	ldr	q1, [x8, #0x8020]
     3dc:      	fdiv.4s	v0, v1, v0
     3e0:      	ldr	q1, [x8, #0xc040]
     3e4:      	fmul.4s	v0, v0, v1
     3e8:      	mov	w8, #0x4000             ; =16384
     3ec:      	ldr	s1, [x11, x8]
     3f0:      	fadd.4s	v0, v0, v1
     3f4:      	str	s0, [x9, x10]
     3f8:      	ret

00000000000003fc <_llm_rows.packet_batch.blocks>:
     3fc:      	cbz	w3, 0x1ccc <_llm_rows.packet_batch.blocks+0x18d0>
     400:      	stp	d15, d14, [sp, #-0xa0]!
     404:      	stp	d13, d12, [sp, #0x10]
     408:      	stp	d11, d10, [sp, #0x20]
     40c:      	stp	d9, d8, [sp, #0x30]
     410:      	stp	x28, x27, [sp, #0x40]
     414:      	stp	x26, x25, [sp, #0x50]
     418:      	stp	x24, x23, [sp, #0x60]
     41c:      	stp	x22, x21, [sp, #0x70]
     420:      	stp	x20, x19, [sp, #0x80]
     424:      	stp	x29, x30, [sp, #0x90]
     428:      	sub	sp, sp, #0x600
     42c:      	mov	x27, x3
     430:      	mov	x20, x2
     434:      	mov	x28, x0
     438:      	mov	w22, #0x0               ; =0
     43c:      	mov	w19, #0x20              ; =32
     440:      	ldp	w9, w8, [x2, #0x2c]
     444:      	str	w9, [sp, #0x1ac]
     448:      	str	w8, [sp, #0x1a8]
     44c:      	ldp	w25, w26, [x2]
     450:      	ldp	w23, w8, [x2, #0x8]
     454:      	str	x8, [sp, #0x1a0]
     458:      	adrp	x8, 0x0 <ltmp0>
     45c:      	ldr	q0, [x8]
     460:      	str	q0, [sp, #0x10]
     464:      	adrp	x8, 0x0 <ltmp0>
     468:      	ldr	q0, [x8]
     46c:      	str	q0, [sp, #0x40]
     470:      	adrp	x8, 0x0 <ltmp0>
     474:      	ldr	q0, [x8]
     478:      	str	q0, [sp, #0x30]
     47c:      	mov	w24, #0x4               ; =4
     480:      	str	w3, [sp, #0x2c]
     484:      	str	x0, [sp, #0x20]
     488:      	b	0x4d4 <_llm_rows.packet_batch.blocks+0xd8>
     48c:      	mov	w8, #0x18               ; =24
     490:      	str	w8, [x20, #0x24]
     494:      	mov	w19, #0x20              ; =32
     498:      	add	w8, w25, #0x1
     49c:      	ldr	w9, [sp, #0x1ac]
     4a0:      	cmp	w8, w9
     4a4:      	cset	w8, eq
     4a8:      	csinc	w25, wzr, w25, eq
     4ac:      	cinc	w9, w26, eq
     4b0:      	ldr	w10, [sp, #0x1a8]
     4b4:      	cmp	w9, w10
     4b8:      	cset	w10, eq
     4bc:      	ands	w8, w8, w10
     4c0:      	csel	w26, wzr, w9, ne
     4c4:      	add	w23, w23, w8
     4c8:      	add	w22, w22, #0x1
     4cc:      	cmp	w22, w27
     4d0:      	b.eq	0x1ca0 <_llm_rows.packet_batch.blocks+0x18a4>
     4d4:      	ubfiz	x8, x25, #5, #32
     4d8:      	ldr	x11, [sp, #0x1a0]
     4dc:      	cmp	x8, x11
     4e0:      	csel	x9, x8, xzr, ls
     4e4:      	subs	x10, x11, x9
     4e8:      	cmp	x10, #0x20
     4ec:      	csel	x10, x10, x19, lo
     4f0:      	cmp	x11, x9
     4f4:      	stp	w25, w26, [x20]
     4f8:      	str	w23, [x20, #0x8]
     4fc:      	str	wzr, [x20, #0x24]
     500:      	ccmp	x8, x11, #0x2, hi
     504:      	csel	x21, x10, xzr, ls
     508:      	cmp	x21, #0x20
     50c:      	b.lo	0x55c <_llm_rows.packet_batch.blocks+0x160>
     510:      	mov	x0, x28
     514:      	mov	x1, x20
     518:      	bl	0x518 <_llm_rows.packet_batch.blocks+0x11c>
     51c:      	mov	w8, #0x8                ; =8
     520:      	str	w8, [x20, #0x24]
     524:      	mov	x0, x28
     528:      	mov	x1, x20
     52c:      	bl	0x52c <_llm_rows.packet_batch.blocks+0x130>
     530:      	mov	w8, #0x10               ; =16
     534:      	str	w8, [x20, #0x24]
     538:      	mov	x0, x28
     53c:      	mov	x1, x20
     540:      	bl	0x540 <_llm_rows.packet_batch.blocks+0x144>
     544:      	mov	w8, #0x18               ; =24
     548:      	str	w8, [x20, #0x24]
     54c:      	mov	x0, x28
     550:      	mov	x1, x20
     554:      	bl	0x554 <_llm_rows.packet_batch.blocks+0x158>
     558:      	b	0x498 <_llm_rows.packet_batch.blocks+0x9c>
     55c:      	lsr	x19, x21, #3
     560:      	cmp	x21, #0x8
     564:      	b.lo	0x5b0 <_llm_rows.packet_batch.blocks+0x1b4>
     568:      	str	wzr, [x20, #0x24]
     56c:      	mov	x0, x28
     570:      	mov	x1, x20
     574:      	bl	0x574 <_llm_rows.packet_batch.blocks+0x178>
     578:      	cmp	x19, #0x1
     57c:      	b.eq	0x5b0 <_llm_rows.packet_batch.blocks+0x1b4>
     580:      	mov	w8, #0x8                ; =8
     584:      	str	w8, [x20, #0x24]
     588:      	mov	x0, x28
     58c:      	mov	x1, x20
     590:      	bl	0x590 <_llm_rows.packet_batch.blocks+0x194>
     594:      	cmp	x19, #0x2
     598:      	b.eq	0x5b0 <_llm_rows.packet_batch.blocks+0x1b4>
     59c:      	mov	w8, #0x10               ; =16
     5a0:      	str	w8, [x20, #0x24]
     5a4:      	mov	x0, x28
     5a8:      	mov	x1, x20
     5ac:      	bl	0x5ac <_llm_rows.packet_batch.blocks+0x1b0>
     5b0:      	and	w8, w21, #0x7
     5b4:      	cbz	w8, 0x48c <_llm_rows.packet_batch.blocks+0x90>
     5b8:      	dup.4s	v1, w8
     5bc:      	ldp	q0, q2, [sp, #0x30]
     5c0:      	cmhi.4s	v0, v1, v0
     5c4:      	cmhi.4s	v1, v1, v2
     5c8:      	uzp1.8h	v3, v1, v0
     5cc:      	umaxv.8h	h2, v3
     5d0:      	fmov	w8, s2
     5d4:      	tbz	w8, #0x0, 0x48c <_llm_rows.packet_batch.blocks+0x90>
     5d8:      	mov	x15, #0x0               ; =0
     5dc:      	ldr	x1, [x20, #0x88]
     5e0:      	mov	w8, #0x4020             ; =16416
     5e4:      	add	x10, x1, x8
     5e8:      	mov	w8, #0x8040             ; =32832
     5ec:      	add	x9, x1, x8
     5f0:      	mov	w8, #0xc060             ; =49248
     5f4:      	add	x13, x1, x8
     5f8:      	ldr	x11, [x28]
     5fc:      	ldr	x17, [x28, #0x10]
     600:      	ldr	x14, [x28, #0x20]
     604:      	ldr	x8, [x28, #0x30]
     608:      	str	x8, [sp, #0x178]
     60c:      	ldr	q2, [sp, #0x10]
     610:      	str	q3, [sp, #0xf0]
     614:      	and.16b	v2, v3, v2
     618:      	addv.8h	h16, v2
     61c:      	fmov	w12, s16
     620:      	and	w8, w12, #0xff
     624:      	str	w8, [sp, #0x184]
     628:      	xtn.4h	v3, v1
     62c:      	uzp1.8b	v4, v3, v0
     630:      	ubfiz	w12, w25, #2, #27
     634:      	orr	w12, w12, w19
     638:      	dup.4s	v5, w12
     63c:      	and.16b	v6, v1, v5
     640:      	and.16b	v5, v0, v5
     644:      	ushll2.2d	v17, v5, #0x0
     648:      	ushll2.2d	v18, v6, #0x0
     64c:      	ushll.2d	v19, v5, #0x0
     650:      	umov.b	w0, v4[0]
     654:      	ushll.2d	v6, v6, #0x0
     658:      	mov	w8, #0x4004             ; =16388
     65c:      	umull	x12, w12, w8
     660:      	tst	w0, #0x1
     664:      	csel	x8, x12, xzr, ne
     668:      	str	x8, [sp, #0x148]
     66c:      	add	x2, x11, x8
     670:      	fmov	w3, s16
     674:      	b	0x698 <_llm_rows.packet_batch.blocks+0x29c>
     678:      	add	x4, x1, x15
     67c:      	ldp	q7, q20, [x4]
     680:      	bif.16b	v5, v20, v0
     684:      	bif.16b	v4, v7, v1
     688:      	stp	q4, q5, [x4]
     68c:      	add	x15, x15, #0x20
     690:      	cmp	x15, #0x4, lsl #12      ; =0x4000
     694:      	b.eq	0x72c <_llm_rows.packet_batch.blocks+0x330>
     698:      	add	x4, x2, x15
     69c:      	movi.2d	v4, #0000000000000000
     6a0:      	movi.2d	v5, #0000000000000000
     6a4:      	tbnz	w3, #0x0, 0x6cc <_llm_rows.packet_batch.blocks+0x2d0>
     6a8:      	and	w5, w3, #0xff
     6ac:      	tbnz	w5, #0x1, 0x6d8 <_llm_rows.packet_batch.blocks+0x2dc>
     6b0:      	tbnz	w5, #0x2, 0x6e4 <_llm_rows.packet_batch.blocks+0x2e8>
     6b4:      	tbnz	w5, #0x3, 0x6f0 <_llm_rows.packet_batch.blocks+0x2f4>
     6b8:      	tbnz	w5, #0x4, 0x6fc <_llm_rows.packet_batch.blocks+0x300>
     6bc:      	tbnz	w5, #0x5, 0x708 <_llm_rows.packet_batch.blocks+0x30c>
     6c0:      	tbnz	w5, #0x6, 0x714 <_llm_rows.packet_batch.blocks+0x318>
     6c4:      	tbz	w5, #0x7, 0x678 <_llm_rows.packet_batch.blocks+0x27c>
     6c8:      	b	0x720 <_llm_rows.packet_batch.blocks+0x324>
     6cc:      	ldr	s4, [x4]
     6d0:      	and	w5, w3, #0xff
     6d4:      	tbz	w5, #0x1, 0x6b0 <_llm_rows.packet_batch.blocks+0x2b4>
     6d8:      	add	x6, x4, #0x4
     6dc:      	ld1.s	{ v4 }[1], [x6]
     6e0:      	tbz	w5, #0x2, 0x6b4 <_llm_rows.packet_batch.blocks+0x2b8>
     6e4:      	add	x6, x4, #0x8
     6e8:      	ld1.s	{ v4 }[2], [x6]
     6ec:      	tbz	w5, #0x3, 0x6b8 <_llm_rows.packet_batch.blocks+0x2bc>
     6f0:      	add	x6, x4, #0xc
     6f4:      	ld1.s	{ v4 }[3], [x6]
     6f8:      	tbz	w5, #0x4, 0x6bc <_llm_rows.packet_batch.blocks+0x2c0>
     6fc:      	add	x6, x4, #0x10
     700:      	ld1.s	{ v5 }[0], [x6]
     704:      	tbz	w5, #0x5, 0x6c0 <_llm_rows.packet_batch.blocks+0x2c4>
     708:      	add	x6, x4, #0x14
     70c:      	ld1.s	{ v5 }[1], [x6]
     710:      	tbz	w5, #0x6, 0x6c4 <_llm_rows.packet_batch.blocks+0x2c8>
     714:      	add	x6, x4, #0x18
     718:      	ld1.s	{ v5 }[2], [x6]
     71c:      	tbz	w5, #0x7, 0x678 <_llm_rows.packet_batch.blocks+0x27c>
     720:      	add	x4, x4, #0x1c
     724:      	ld1.s	{ v5 }[3], [x4]
     728:      	b	0x678 <_llm_rows.packet_batch.blocks+0x27c>
     72c:      	uzp1.8b	v21, v3, v0
     730:      	sshll.2d	v5, v1, #0x0
     734:      	movi.2d	v4, #0000000000000000
     738:      	mov.b	v4[0], v21[0]
     73c:      	adrp	x8, 0x0 <ltmp0>
     740:      	ldr	d2, [x8]
     744:      	str	d2, [sp, #0x108]
     748:      	and.8b	v3, v4, v2
     74c:      	addv.8b	b3, v3
     750:      	fmov	w15, s3
     754:      	umaxv.8b	b3, v4
     758:      	fmov	w2, s3
     75c:      	rbit	w3, w15
     760:      	clz	w3, w3
     764:      	tst	w2, #0x1
     768:      	csel	w12, w3, wzr, ne
     76c:      	mov	w8, #0x1000             ; =4096
     770:      	dup.2d	v7, x8
     774:      	adrp	x8, 0x0 <ltmp0>
     778:      	ldr	q3, [x8]
     77c:      	mov.16b	v2, v5
     780:      	bsl.16b	v2, v3, v7
     784:      	xtn.2s	v22, v6
     788:      	mov	w8, #0x1001             ; =4097
     78c:      	dup.2s	v6, w8
     790:      	umlal.2d	v2, v22, v6
     794:      	movi.2d	v22, #0000000000000000
     798:      	mov.b	v22[0], v21[0]
     79c:      	ushll.2d	v21, v22, #0x0
     7a0:      	shl.2d	v21, v21, #0x3f
     7a4:      	cmlt.2d	v21, v21, #0
     7a8:      	str	q2, [sp, #0x150]
     7ac:      	and.16b	v21, v21, v2
     7b0:      	movi.2d	v2, #0000000000000000
     7b4:      	str	q2, [sp, #0x5e0]
     7b8:      	str	q2, [sp, #0x5d0]
     7bc:      	str	q2, [sp, #0x5c0]
     7c0:      	str	q21, [sp, #0x5b0]
     7c4:      	and	x3, x12, #0x7
     7c8:      	add	x8, sp, #0x5b0
     7cc:      	ldr	x3, [x8, x3, lsl #3]
     7d0:      	sub	x3, x3, x12
     7d4:      	add	x11, x11, x3, lsl #2
     7d8:      	movi.2d	v20, #0000000000000000
     7dc:      	movi.2d	v28, #0000000000000000
     7e0:      	tbnz	w2, #0x0, 0x1894 <_llm_rows.packet_batch.blocks+0x1498>
     7e4:      	tbnz	w15, #0x1, 0x189c <_llm_rows.packet_batch.blocks+0x14a0>
     7e8:      	tbnz	w15, #0x2, 0x18a8 <_llm_rows.packet_batch.blocks+0x14ac>
     7ec:      	tbnz	w15, #0x3, 0x18b4 <_llm_rows.packet_batch.blocks+0x14b8>
     7f0:      	tbnz	w15, #0x4, 0x18c0 <_llm_rows.packet_batch.blocks+0x14c4>
     7f4:      	tbnz	w15, #0x5, 0x18cc <_llm_rows.packet_batch.blocks+0x14d0>
     7f8:      	tbnz	w15, #0x6, 0x18d8 <_llm_rows.packet_batch.blocks+0x14dc>
     7fc:      	str	q16, [sp, #0x160]
     800:      	tbz	w15, #0x7, 0x80c <_llm_rows.packet_batch.blocks+0x410>
     804:      	add	x11, x11, #0x1c
     808:      	ld1.s	{ v28 }[3], [x11]
     80c:      	str	w22, [sp, #0xcc]
     810:      	sshll.2d	v21, v0, #0x0
     814:      	sshll2.2d	v22, v1, #0x0
     818:      	sshll2.2d	v23, v0, #0x0
     81c:      	adrp	x8, 0x0 <ltmp0>
     820:      	ldr	q24, [x8]
     824:      	and.16b	v24, v23, v24
     828:      	adrp	x8, 0x0 <ltmp0>
     82c:      	ldr	q25, [x8]
     830:      	and.16b	v25, v22, v25
     834:      	adrp	x8, 0x0 <ltmp0>
     838:      	ldr	q26, [x8]
     83c:      	and.16b	v26, v21, v26
     840:      	adrp	x8, 0x0 <ltmp0>
     844:      	ldr	q27, [x8]
     848:      	and.16b	v5, v5, v27
     84c:      	adrp	x8, 0x0 <ltmp0>
     850:      	ldr	q27, [x8]
     854:      	mov.16b	v2, v21
     858:      	bsl.16b	v2, v27, v7
     85c:      	adrp	x8, 0x0 <ltmp0>
     860:      	ldr	q21, [x8]
     864:      	mov.16b	v3, v22
     868:      	bsl.16b	v3, v21, v7
     86c:      	adrp	x8, 0x0 <ltmp0>
     870:      	ldr	q21, [x8]
     874:      	bit.16b	v7, v21, v23
     878:      	xtn.2s	v19, v19
     87c:      	xtn.2s	v18, v18
     880:      	xtn.2s	v17, v17
     884:      	umlal.2d	v7, v17, v6
     888:      	umlal.2d	v3, v18, v6
     88c:      	stp	q7, q3, [sp, #0x110]
     890:      	umlal.2d	v2, v19, v6
     894:      	str	q2, [sp, #0x130]
     898:      	sshll.2d	v6, v1, #0x0
     89c:      	sshll.2d	v17, v0, #0x0
     8a0:      	str	q5, [sp, #0x570]
     8a4:      	str	q25, [sp, #0x580]
     8a8:      	str	q26, [sp, #0x590]
     8ac:      	str	q24, [sp, #0x5a0]
     8b0:      	and	x11, x12, #0x7
     8b4:      	add	x8, sp, #0x570
     8b8:      	ldr	x11, [x8, x11, lsl #3]
     8bc:      	orr	x11, x11, #0x4000
     8c0:      	str	x12, [sp, #0x170]
     8c4:      	sub	x11, x11, x12, lsl #2
     8c8:      	tst	w15, #0xff
     8cc:      	csel	x8, xzr, x11, eq
     8d0:      	str	x8, [sp, #0x188]
     8d4:      	add	x11, x1, x8
     8d8:      	ldp	q5, q18, [x11]
     8dc:      	zip2.8b	v19, v4, v0
     8e0:      	ushll.4s	v19, v19, #0x0
     8e4:      	shl.4s	v19, v19, #0x1f
     8e8:      	cmlt.4s	v19, v19, #0
     8ec:      	stp	q28, q20, [sp, #0xd0]
     8f0:      	bit.16b	v18, v28, v19
     8f4:      	str	q4, [sp, #0x190]
     8f8:      	zip1.8b	v19, v4, v0
     8fc:      	ushll.4s	v19, v19, #0x0
     900:      	shl.4s	v19, v19, #0x1f
     904:      	cmlt.4s	v19, v19, #0
     908:      	bit.16b	v5, v20, v19
     90c:      	stp	q5, q18, [x11]
     910:      	dup.2d	v5, x24
     914:      	and.16b	v24, v23, v5
     918:      	and.16b	v25, v22, v5
     91c:      	and.16b	v26, v17, v5
     920:      	and.16b	v27, v6, v5
     924:      	tst	w0, #0x1
     928:      	csel	x15, x24, xzr, ne
     92c:      	ldp	q5, q6, [x1, #0x60]
     930:      	and.16b	v6, v0, v6
     934:      	and.16b	v5, v1, v5
     938:      	ldp	q18, q17, [x1, #0x40]
     93c:      	and.16b	v17, v0, v17
     940:      	and.16b	v18, v1, v18
     944:      	ldp	q19, q21, [x1, #0x20]
     948:      	and.16b	v30, v0, v21
     94c:      	and.16b	v19, v1, v19
     950:      	ldp	q21, q31, [x1]
     954:      	and.16b	v31, v0, v31
     958:      	mov	x11, x15
     95c:      	and.16b	v9, v1, v21
     960:      	mov.16b	v14, v27
     964:      	mov.16b	v21, v25
     968:      	mov.16b	v12, v26
     96c:      	mov.16b	v13, v24
     970:      	sshll.2d	v15, v1, #0x0
     974:      	sshll.2d	v7, v0, #0x0
     978:      	add	x11, x1, x11, lsl #5
     97c:      	ldp	q11, q10, [x11]
     980:      	fadd.4s	v11, v9, v11
     984:      	fadd.4s	v10, v31, v10
     988:      	ldp	q20, q3, [x11, #0x20]
     98c:      	fadd.4s	v20, v19, v20
     990:      	fadd.4s	v3, v30, v3
     994:      	ldp	q8, q4, [x11, #0x40]
     998:      	fadd.4s	v8, v18, v8
     99c:      	fadd.4s	v4, v17, v4
     9a0:      	ldp	q28, q16, [x11, #0x60]
     9a4:      	fadd.4s	v28, v5, v28
     9a8:      	fadd.4s	v16, v6, v16
     9ac:      	dup.2d	v29, x24
     9b0:      	and.16b	v2, v23, v29
     9b4:      	add.2d	v13, v13, v2
     9b8:      	and.16b	v2, v22, v29
     9bc:      	add.2d	v21, v21, v2
     9c0:      	and.16b	v2, v7, v29
     9c4:      	add.2d	v12, v12, v2
     9c8:      	and.16b	v2, v15, v29
     9cc:      	add.2d	v2, v14, v2
     9d0:      	bit.16b	v31, v10, v0
     9d4:      	bit.16b	v9, v11, v1
     9d8:      	bit.16b	v30, v3, v0
     9dc:      	bit.16b	v19, v20, v1
     9e0:      	bit.16b	v17, v4, v0
     9e4:      	bit.16b	v18, v8, v1
     9e8:      	bit.16b	v6, v16, v0
     9ec:      	bit.16b	v5, v28, v1
     9f0:      	fmov	x11, d14
     9f4:      	add	x2, x11, #0x4
     9f8:      	tst	w0, #0x1
     9fc:      	csel	x11, x2, x11, ne
     a00:      	mov.16b	v14, v2
     a04:      	cmp	x11, #0x200
     a08:      	b.lt	0x970 <_llm_rows.packet_batch.blocks+0x574>
     a0c:      	mov	x4, #0x0                ; =0
     a10:      	ldp	q2, q3, [sp, #0xe0]
     a14:      	xtn.8b	v28, v3
     a18:      	fadd.4s	v2, v2, v9
     a1c:      	ldr	q3, [sp, #0xd0]
     a20:      	fadd.4s	v3, v3, v31
     a24:      	ldr	q21, [sp, #0x190]
     a28:      	zip2.8b	v4, v21, v0
     a2c:      	ushll.4s	v4, v4, #0x0
     a30:      	shl.4s	v4, v4, #0x1f
     a34:      	cmlt.4s	v4, v4, #0
     a38:      	and.16b	v3, v4, v3
     a3c:      	zip1.8b	v4, v21, v0
     a40:      	ushll.4s	v4, v4, #0x0
     a44:      	shl.4s	v4, v4, #0x1f
     a48:      	cmlt.4s	v4, v4, #0
     a4c:      	and.16b	v2, v4, v2
     a50:      	movi.2d	v4, #0000000000000000
     a54:      	mov.b	v4[2], v28[1]
     a58:      	mov.b	v4[4], v28[2]
     a5c:      	mov.b	v4[6], v28[3]
     a60:      	ushll.4s	v4, v4, #0x0
     a64:      	shl.4s	v4, v4, #0x1f
     a68:      	cmlt.4s	v4, v4, #0
     a6c:      	bit.16b	v2, v11, v4
     a70:      	zip2.8b	v4, v28, v0
     a74:      	ushll.4s	v4, v4, #0x0
     a78:      	shl.4s	v4, v4, #0x1f
     a7c:      	cmlt.4s	v4, v4, #0
     a80:      	bit.16b	v3, v10, v4
     a84:      	fadd.4s	v3, v30, v3
     a88:      	fadd.4s	v2, v19, v2
     a8c:      	fadd.4s	v2, v18, v2
     a90:      	fadd.4s	v3, v17, v3
     a94:      	fadd.4s	v6, v6, v3
     a98:      	umov.b	w8, v28[1]
     a9c:      	fadd.4s	v5, v5, v2
     aa0:      	and	w30, w0, w8
     aa4:      	mov	s2, v5[1]
     aa8:      	tst	w30, #0x1
     aac:      	movi	d20, #0000000000000000
     ab0:      	fcsel	s16, s2, s20, ne
     ab4:      	mvn	w11, w8
     ab8:      	add	x2, sp, #0x550
     abc:      	bfi	x2, x11, #2, #1
     ac0:      	add	x3, sp, #0x448
     ac4:      	bfxil	x3, x11, #0, #1
     ac8:      	str	d28, [sp, #0x448]
     acc:      	ldrb	w11, [x3]
     ad0:      	str	w8, [sp, #0xd0]
     ad4:      	and	w11, w8, w11
     ad8:      	str	q6, [sp, #0x560]
     adc:      	str	q5, [sp, #0x550]
     ae0:      	ldr	s2, [x2]
     ae4:      	tst	w11, #0x1
     ae8:      	fcsel	s17, s2, s20, ne
     aec:      	umov.b	w7, v28[2]
     af0:      	ands	w11, w7, #0x1
     af4:      	mov	w8, #0x3                ; =3
     af8:      	csinc	w2, w8, wzr, ne
     afc:      	add	x8, sp, #0x448
     b00:      	orr	x3, x8, x2
     b04:      	ldrb	w3, [x3]
     b08:      	add	x12, sp, #0x530
     b0c:      	orr	x2, x12, x2, lsl #2
     b10:      	str	q6, [sp, #0x540]
     b14:      	str	q5, [sp, #0x530]
     b18:      	ldr	s2, [x2]
     b1c:      	tst	w11, w3
     b20:      	fcsel	s18, s2, s20, ne
     b24:      	umov.b	w22, v28[3]
     b28:      	ands	w11, w22, #0x1
     b2c:      	mov	w12, #0x1               ; =1
     b30:      	cinc	w2, w12, ne
     b34:      	add	x3, sp, #0x448
     b38:      	bfxil	x3, x2, #0, #3
     b3c:      	ldrb	w3, [x3]
     b40:      	add	x16, sp, #0x510
     b44:      	orr	x2, x16, x2, lsl #2
     b48:      	str	q6, [sp, #0x520]
     b4c:      	str	q5, [sp, #0x510]
     b50:      	ldr	s2, [x2]
     b54:      	tst	w11, w3
     b58:      	fcsel	s2, s2, s20, ne
     b5c:      	umov.b	w19, v28[4]
     b60:      	ands	w2, w19, #0x1
     b64:      	mov	w11, #0x5               ; =5
     b68:      	csinc	w11, w11, wzr, ne
     b6c:      	orr	x3, x8, x11
     b70:      	ldrb	w5, [x3]
     b74:      	str	q6, [sp, #0x500]
     b78:      	str	q5, [sp, #0x4f0]
     b7c:      	add	x16, sp, #0x4f0
     b80:      	ldr	s3, [x16, w11, uxtw #2]
     b84:      	mov	w11, #0x2               ; =2
     b88:      	mov	w16, #0x6               ; =6
     b8c:      	csel	w3, w16, w11, ne
     b90:      	tst	w2, w5
     b94:      	umov.b	w28, v28[5]
     b98:      	fcsel	s3, s3, s20, ne
     b9c:      	ands	w11, w28, #0x1
     ba0:      	csinc	w5, w24, wzr, ne
     ba4:      	orr	x21, x8, x5
     ba8:      	ldrb	w21, [x21]
     bac:      	str	q6, [sp, #0x4e0]
     bb0:      	str	q5, [sp, #0x4d0]
     bb4:      	add	x6, sp, #0x4d0
     bb8:      	ldr	s4, [x6, w5, uxtw #2]
     bbc:      	tst	w11, w21
     bc0:      	umov.b	w27, v28[6]
     bc4:      	fcsel	s4, s4, s20, ne
     bc8:      	ands	w11, w27, #0x1
     bcc:      	mov	w5, #0x7                ; =7
     bd0:      	csinc	w5, w5, wzr, ne
     bd4:      	orr	x21, x8, x5
     bd8:      	ldrb	w21, [x21]
     bdc:      	str	q6, [sp, #0x4c0]
     be0:      	str	q5, [sp, #0x4b0]
     be4:      	add	x6, sp, #0x4b0
     be8:      	ldr	s7, [x6, w5, uxtw #2]
     bec:      	tst	w11, w21
     bf0:      	umov.b	w11, v28[7]
     bf4:      	fcsel	s7, s7, s20, ne
     bf8:      	ands	w5, w11, #0x1
     bfc:      	csinc	w21, w16, wzr, ne
     c00:      	orr	x16, x8, x21
     c04:      	ldrb	w16, [x16]
     c08:      	str	q6, [sp, #0x4a0]
     c0c:      	str	q5, [sp, #0x490]
     c10:      	add	x6, sp, #0x490
     c14:      	ldr	s19, [x6, w21, uxtw #2]
     c18:      	tst	w5, w16
     c1c:      	fcsel	s19, s19, s20, ne
     c20:      	mov.s	v16[1], v17[0]
     c24:      	mov.s	v16[2], v18[0]
     c28:      	mov.s	v16[3], v2[0]
     c2c:      	mov.s	v3[1], v4[0]
     c30:      	mov.s	v3[2], v7[0]
     c34:      	mov.s	v3[3], v19[0]
     c38:      	fadd.4s	v2, v6, v3
     c3c:      	fadd.4s	v3, v5, v16
     c40:      	and	w6, w0, w7
     c44:      	mov	s4, v3[2]
     c48:      	tst	w6, #0x1
     c4c:      	fcsel	s4, s4, s20, ne
     c50:      	orr	x16, x8, x3
     c54:      	ldrb	w16, [x16]
     c58:      	str	q2, [sp, #0x480]
     c5c:      	str	q3, [sp, #0x470]
     c60:      	add	x8, sp, #0x470
     c64:      	ldr	s5, [x8, w3, uxtw #2]
     c68:      	tst	w2, w16
     c6c:      	fcsel	s5, s5, s20, ne
     c70:      	fadd.4s	v2, v2, v5
     c74:      	str	w19, [sp, #0x9c]
     c78:      	and	w8, w0, w19
     c7c:      	mov	x19, x28
     c80:      	tst	w8, #0x1
     c84:      	fcsel	s2, s2, s20, ne
     c88:      	mov	x5, x30
     c8c:      	tst	w30, #0x1
     c90:      	fadd.4s	v3, v3, v4
     c94:      	fadd	s2, s3, s2
     c98:      	fcsel	s3, s2, s20, ne
     c9c:      	str	w6, [sp, #0xf0]
     ca0:      	tst	w6, #0x1
     ca4:      	fcsel	s4, s2, s20, ne
     ca8:      	str	w8, [sp, #0xe0]
     cac:      	tst	w8, #0x1
     cb0:      	str	q28, [sp, #0xa0]
     cb4:      	mov.b	v28[0], wzr
     cb8:      	str	q28, [sp, #0x80]
     cbc:      	fcsel	s5, s2, s20, ne
     cc0:      	tst	w0, #0x1
     cc4:      	mov	x6, x22
     cc8:      	and	w8, w22, w0
     ccc:      	fcsel	s6, s2, s20, ne
     cd0:      	str	w8, [sp, #0xbc]
     cd4:      	tst	w8, #0x1
     cd8:      	fcsel	s7, s2, s20, ne
     cdc:      	and	w8, w28, w0
     ce0:      	str	w8, [sp, #0xb8]
     ce4:      	tst	w8, #0x1
     ce8:      	fcsel	s16, s2, s20, ne
     cec:      	and	w8, w27, w0
     cf0:      	str	w8, [sp, #0xb4]
     cf4:      	tst	w8, #0x1
     cf8:      	fcsel	s17, s2, s20, ne
     cfc:      	and	w8, w11, w0
     d00:      	str	w8, [sp, #0xc8]
     d04:      	tst	w8, #0x1
     d08:      	mov.s	v6[1], v3[0]
     d0c:      	mov.s	v6[2], v4[0]
     d10:      	mov.s	v6[3], v7[0]
     d14:      	mov.s	v5[1], v16[0]
     d18:      	mov.s	v5[2], v17[0]
     d1c:      	fcsel	s2, s2, s20, ne
     d20:      	mov.s	v5[3], v2[0]
     d24:      	ldr	w8, [sp, #0x184]
     d28:      	rbit	w16, w8
     d2c:      	clz	w8, w16
     d30:      	str	q5, [sp, #0x460]
     d34:      	str	q6, [sp, #0x450]
     d38:      	str	x8, [sp, #0xc0]
     d3c:      	and	x16, x8, #0x7
     d40:      	add	x8, sp, #0x450
     d44:      	ldr	s2, [x8, x16, lsl #2]
     d48:      	fadd	s2, s2, s20
     d4c:      	mov	w8, #0x800              ; =2048
     d50:      	movk	w8, #0x4580, lsl #16
     d54:      	fmov	s3, w8
     d58:      	fdiv	s2, s2, s3
     d5c:      	dup.4s	v5, v2[0]
     d60:      	ushll2.2d	v2, v0, #0x0
     d64:      	dup.2d	v3, x12
     d68:      	and.16b	v16, v2, v3
     d6c:      	ushll2.2d	v2, v1, #0x0
     d70:      	and.16b	v17, v2, v3
     d74:      	ushll.2d	v2, v0, #0x0
     d78:      	and.16b	v18, v2, v3
     d7c:      	ushll.2d	v2, v1, #0x0
     d80:      	and.16b	v19, v2, v3
     d84:      	movi.2d	v6, #0000000000000000
     d88:      	and	x16, x0, #0x1
     d8c:      	movi.2d	v29, #0000000000000000
     d90:      	movi.2d	v30, #0000000000000000
     d94:      	movi.2d	v31, #0000000000000000
     d98:      	lsl	x2, x4, #5
     d9c:      	add	x3, x1, x2
     da0:      	ldp	q3, q2, [x3]
     da4:      	fsub.4s	v3, v3, v5
     da8:      	fsub.4s	v2, v2, v5
     dac:      	add	x2, x10, x2
     db0:      	ldp	q4, q7, [x2]
     db4:      	bif.16b	v2, v7, v0
     db8:      	bif.16b	v3, v4, v1
     dbc:      	stp	q3, q2, [x2]
     dc0:      	add.2d	v2, v6, v19
     dc4:      	add.2d	v29, v29, v17
     dc8:      	add.2d	v30, v30, v18
     dcc:      	add.2d	v31, v31, v16
     dd0:      	fmov	x2, d6
     dd4:      	add	x4, x2, x16
     dd8:      	mov.16b	v6, v2
     ddc:      	cmp	x4, #0x200
     de0:      	b.lt	0xd98 <_llm_rows.packet_batch.blocks+0x99c>
     de4:      	ldr	x8, [sp, #0x188]
     de8:      	add	x2, x1, x8
     dec:      	ldp	q3, q2, [x2]
     df0:      	fsub.4s	v6, v3, v5
     df4:      	fsub.4s	v5, v2, v5
     df8:      	add	x2, x10, x8
     dfc:      	ldp	q2, q3, [x2]
     e00:      	zip2.8b	v4, v21, v0
     e04:      	ushll.4s	v4, v4, #0x0
     e08:      	shl.4s	v4, v4, #0x1f
     e0c:      	cmlt.4s	v4, v4, #0
     e10:      	stp	q5, q6, [sp, #0x60]
     e14:      	bit.16b	v3, v5, v4
     e18:      	zip1.8b	v4, v21, v0
     e1c:      	ushll.4s	v4, v4, #0x0
     e20:      	shl.4s	v4, v4, #0x1f
     e24:      	cmlt.4s	v4, v4, #0
     e28:      	bit.16b	v2, v6, v4
     e2c:      	stp	q2, q3, [x2]
     e30:      	ldr	q2, [x1, #0x4090]
     e34:      	ldr	q3, [x1, #0x4080]
     e38:      	fmul.4s	v3, v3, v3
     e3c:      	fmul.4s	v2, v2, v2
     e40:      	and.16b	v29, v0, v2
     e44:      	and.16b	v31, v1, v3
     e48:      	ldr	q2, [x1, #0x4070]
     e4c:      	ldr	q3, [x1, #0x4060]
     e50:      	fmul.4s	v3, v3, v3
     e54:      	fmul.4s	v2, v2, v2
     e58:      	and.16b	v11, v0, v2
     e5c:      	and.16b	v10, v1, v3
     e60:      	ldr	q2, [x1, #0x4050]
     e64:      	ldr	q3, [x1, #0x4040]
     e68:      	fmul.4s	v3, v3, v3
     e6c:      	fmul.4s	v2, v2, v2
     e70:      	and.16b	v12, v0, v2
     e74:      	and.16b	v13, v1, v3
     e78:      	ldr	q2, [x1, #0x4030]
     e7c:      	ldr	q3, [x1, #0x4020]
     e80:      	fmul.4s	v3, v3, v3
     e84:      	fmul.4s	v2, v2, v2
     e88:      	and.16b	v15, v0, v2
     e8c:      	and.16b	v14, v1, v3
     e90:      	sshll.2d	v2, v1, #0x0
     e94:      	sshll.2d	v3, v0, #0x0
     e98:      	add	x15, x10, x15, lsl #5
     e9c:      	ldp	q5, q4, [x15]
     ea0:      	and.16b	v5, v1, v5
     ea4:      	and.16b	v4, v0, v4
     ea8:      	fmul.4s	v4, v4, v4
     eac:      	fmul.4s	v5, v5, v5
     eb0:      	fadd.4s	v5, v14, v5
     eb4:      	fadd.4s	v6, v15, v4
     eb8:      	ldp	q7, q4, [x15, #0x20]
     ebc:      	and.16b	v7, v1, v7
     ec0:      	and.16b	v4, v0, v4
     ec4:      	fmul.4s	v4, v4, v4
     ec8:      	fmul.4s	v7, v7, v7
     ecc:      	fadd.4s	v7, v13, v7
     ed0:      	fadd.4s	v4, v12, v4
     ed4:      	ldp	q8, q20, [x15, #0x40]
     ed8:      	and.16b	v8, v1, v8
     edc:      	and.16b	v20, v0, v20
     ee0:      	fmul.4s	v20, v20, v20
     ee4:      	fmul.4s	v8, v8, v8
     ee8:      	fadd.4s	v8, v10, v8
     eec:      	fadd.4s	v20, v11, v20
     ef0:      	ldp	q9, q30, [x15, #0x60]
     ef4:      	and.16b	v9, v1, v9
     ef8:      	and.16b	v30, v0, v30
     efc:      	fmul.4s	v30, v30, v30
     f00:      	fmul.4s	v9, v9, v9
     f04:      	fadd.4s	v9, v31, v9
     f08:      	fadd.4s	v30, v29, v30
     f0c:      	dup.2d	v28, x24
     f10:      	and.16b	v21, v23, v28
     f14:      	add.2d	v24, v24, v21
     f18:      	and.16b	v21, v22, v28
     f1c:      	add.2d	v25, v25, v21
     f20:      	and.16b	v3, v3, v28
     f24:      	add.2d	v26, v26, v3
     f28:      	and.16b	v2, v2, v28
     f2c:      	add.2d	v2, v27, v2
     f30:      	bit.16b	v15, v6, v0
     f34:      	bit.16b	v14, v5, v1
     f38:      	bit.16b	v12, v4, v0
     f3c:      	bit.16b	v13, v7, v1
     f40:      	bit.16b	v11, v20, v0
     f44:      	bit.16b	v10, v8, v1
     f48:      	bit.16b	v29, v30, v0
     f4c:      	bit.16b	v31, v9, v1
     f50:      	fmov	x15, d27
     f54:      	add	x1, x15, #0x4
     f58:      	tst	w0, #0x1
     f5c:      	csel	x15, x1, x15, ne
     f60:      	mov.16b	v27, v2
     f64:      	cmp	x15, #0x200
     f68:      	b.lt	0xe90 <_llm_rows.packet_batch.blocks+0xa94>
     f6c:      	mov	x15, #0x0               ; =0
     f70:      	movi.2d	v22, #0000000000000000
     f74:      	movi.2d	v23, #0000000000000000
     f78:      	movi.2d	v24, #0000000000000000
     f7c:      	movi.2d	v25, #0000000000000000
     f80:      	ldr	q28, [sp, #0x160]
     f84:      	ldr	q30, [sp, #0x190]
     f88:      	b	0xfc4 <_llm_rows.packet_batch.blocks+0xbc8>
     f8c:      	add	x15, x9, x15
     f90:      	ldp	q2, q3, [x15]
     f94:      	bit.16b	v3, v27, v0
     f98:      	bit.16b	v2, v26, v1
     f9c:      	stp	q2, q3, [x15]
     fa0:      	add.2d	v2, v22, v19
     fa4:      	add.2d	v23, v23, v17
     fa8:      	add.2d	v24, v24, v18
     fac:      	add.2d	v25, v25, v16
     fb0:      	fmov	x15, d22
     fb4:      	add	x15, x15, x16
     fb8:      	mov.16b	v22, v2
     fbc:      	cmp	x15, #0x200
     fc0:      	b.ge	0x1060 <_llm_rows.packet_batch.blocks+0xc64>
     fc4:      	fmov	w2, s28
     fc8:      	lsl	x15, x15, #5
     fcc:      	add	x1, x17, x15
     fd0:      	movi.2d	v26, #0000000000000000
     fd4:      	movi.2d	v27, #0000000000000000
     fd8:      	tbnz	w2, #0x0, 0x1000 <_llm_rows.packet_batch.blocks+0xc04>
     fdc:      	and	w2, w2, #0xff
     fe0:      	tbnz	w2, #0x1, 0x100c <_llm_rows.packet_batch.blocks+0xc10>
     fe4:      	tbnz	w2, #0x2, 0x1018 <_llm_rows.packet_batch.blocks+0xc1c>
     fe8:      	tbnz	w2, #0x3, 0x1024 <_llm_rows.packet_batch.blocks+0xc28>
     fec:      	tbnz	w2, #0x4, 0x1030 <_llm_rows.packet_batch.blocks+0xc34>
     ff0:      	tbnz	w2, #0x5, 0x103c <_llm_rows.packet_batch.blocks+0xc40>
     ff4:      	tbnz	w2, #0x6, 0x1048 <_llm_rows.packet_batch.blocks+0xc4c>
     ff8:      	tbz	w2, #0x7, 0xf8c <_llm_rows.packet_batch.blocks+0xb90>
     ffc:      	b	0x1054 <_llm_rows.packet_batch.blocks+0xc58>
    1000:      	ldr	s26, [x1]
    1004:      	and	w2, w2, #0xff
    1008:      	tbz	w2, #0x1, 0xfe4 <_llm_rows.packet_batch.blocks+0xbe8>
    100c:      	add	x3, x1, #0x4
    1010:      	ld1.s	{ v26 }[1], [x3]
    1014:      	tbz	w2, #0x2, 0xfe8 <_llm_rows.packet_batch.blocks+0xbec>
    1018:      	add	x3, x1, #0x8
    101c:      	ld1.s	{ v26 }[2], [x3]
    1020:      	tbz	w2, #0x3, 0xfec <_llm_rows.packet_batch.blocks+0xbf0>
    1024:      	add	x3, x1, #0xc
    1028:      	ld1.s	{ v26 }[3], [x3]
    102c:      	tbz	w2, #0x4, 0xff0 <_llm_rows.packet_batch.blocks+0xbf4>
    1030:      	add	x3, x1, #0x10
    1034:      	ld1.s	{ v27 }[0], [x3]
    1038:      	tbz	w2, #0x5, 0xff4 <_llm_rows.packet_batch.blocks+0xbf8>
    103c:      	add	x3, x1, #0x14
    1040:      	ld1.s	{ v27 }[1], [x3]
    1044:      	tbz	w2, #0x6, 0xff8 <_llm_rows.packet_batch.blocks+0xbfc>
    1048:      	add	x3, x1, #0x18
    104c:      	ld1.s	{ v27 }[2], [x3]
    1050:      	tbz	w2, #0x7, 0xf8c <_llm_rows.packet_batch.blocks+0xb90>
    1054:      	add	x1, x1, #0x1c
    1058:      	ld1.s	{ v27 }[3], [x1]
    105c:      	b	0xf8c <_llm_rows.packet_batch.blocks+0xb90>
    1060:      	str	w26, [sp, #0x184]
    1064:      	zip2.8b	v2, v30, v0
    1068:      	ushll.4s	v2, v2, #0x0
    106c:      	shl.4s	v2, v2, #0x1f
    1070:      	cmlt.4s	v2, v2, #0
    1074:      	ldp	q3, q7, [sp, #0x60]
    1078:      	and.16b	v3, v2, v3
    107c:      	zip1.8b	v4, v30, v0
    1080:      	ushll.4s	v4, v4, #0x0
    1084:      	shl.4s	v4, v4, #0x1f
    1088:      	cmlt.4s	v4, v4, #0
    108c:      	and.16b	v7, v4, v7
    1090:      	fmul.4s	v7, v7, v7
    1094:      	fmul.4s	v3, v3, v3
    1098:      	fadd.4s	v3, v3, v15
    109c:      	fadd.4s	v7, v7, v14
    10a0:      	and.16b	v4, v4, v7
    10a4:      	and.16b	v2, v2, v3
    10a8:      	ldr	q7, [sp, #0x80]
    10ac:      	zip2.8b	v3, v7, v0
    10b0:      	ushll.4s	v3, v3, #0x0
    10b4:      	shl.4s	v3, v3, #0x1f
    10b8:      	cmlt.4s	v3, v3, #0
    10bc:      	bit.16b	v2, v6, v3
    10c0:      	zip1.8b	v3, v7, v0
    10c4:      	ushll.4s	v3, v3, #0x0
    10c8:      	shl.4s	v3, v3, #0x1f
    10cc:      	cmlt.4s	v3, v3, #0
    10d0:      	bsl.16b	v3, v5, v4
    10d4:      	fadd.4s	v3, v13, v3
    10d8:      	fadd.4s	v2, v12, v2
    10dc:      	fadd.4s	v2, v11, v2
    10e0:      	fadd.4s	v3, v10, v3
    10e4:      	fadd.4s	v5, v31, v3
    10e8:      	fadd.4s	v6, v29, v2
    10ec:      	add	x15, sp, #0x1f8
    10f0:      	bfxil	x15, x0, #0, #1
    10f4:      	ldr	q2, [sp, #0xa0]
    10f8:      	str	d2, [sp, #0x1f8]
    10fc:      	ldrb	w2, [x15]
    1100:      	add	x15, sp, #0x420
    1104:      	bfi	x15, x0, #2, #1
    1108:      	str	q6, [sp, #0x430]
    110c:      	str	q5, [sp, #0x420]
    1110:      	ldr	s2, [x15]
    1114:      	ands	w1, w0, #0x1
    1118:      	mov	w8, #0x2                ; =2
    111c:      	csel	w3, w8, wzr, ne
    1120:      	csel	w12, w24, wzr, ne
    1124:      	str	x12, [sp, #0xa0]
    1128:      	tst	w1, w2
    112c:      	movi	d25, #0000000000000000
    1130:      	fcsel	s21, s2, s25, ne
    1134:      	str	w5, [sp, #0x5c]
    1138:      	tst	w5, #0x1
    113c:      	fcsel	s23, s5, s25, ne
    1140:      	ands	w2, w7, #0x1
    1144:      	mov	w12, #0x3               ; =3
    1148:      	csel	w4, w12, wzr, ne
    114c:      	mov	w7, #0x4                ; =4
    1150:      	add	x24, sp, #0x1f8
    1154:      	orr	x5, x24, x4
    1158:      	ldrb	w5, [x5]
    115c:      	add	x12, sp, #0x400
    1160:      	orr	x4, x12, x4, lsl #2
    1164:      	str	q6, [sp, #0x410]
    1168:      	str	q5, [sp, #0x400]
    116c:      	ldr	s2, [x4]
    1170:      	tst	w2, w5
    1174:      	fcsel	s22, s2, s25, ne
    1178:      	mov	x22, x6
    117c:      	ands	w21, w22, #0x1
    1180:      	csel	w2, w8, wzr, ne
    1184:      	orr	x4, x24, x2
    1188:      	ldrb	w4, [x4]
    118c:      	lsr	x2, x2, #1
    1190:      	add	x5, sp, #0x3e0
    1194:      	bfi	x5, x2, #3, #1
    1198:      	stp	q5, q6, [sp, #0x3e0]
    119c:      	ldr	s2, [x5]
    11a0:      	tst	w21, w4
    11a4:      	fcsel	s24, s2, s25, ne
    11a8:      	ands	w11, w11, #0x1
    11ac:      	mov	w26, #0x6               ; =6
    11b0:      	csel	w28, w26, wzr, ne
    11b4:      	mov	w8, #0x5                ; =5
    11b8:      	csel	w4, w8, wzr, ne
    11bc:      	ands	w30, w27, #0x1
    11c0:      	mov	w12, #0x7               ; =7
    11c4:      	csel	w6, w12, wzr, ne
    11c8:      	csel	w27, w7, wzr, ne
    11cc:      	ands	w2, w19, #0x1
    11d0:      	csel	w5, w7, wzr, ne
    11d4:      	csel	w19, w12, wzr, ne
    11d8:      	ldr	w12, [sp, #0x9c]
    11dc:      	ands	w7, w12, #0x1
    11e0:      	csel	w12, w8, wzr, ne
    11e4:      	orr	x8, x24, x12
    11e8:      	ldrb	w8, [x8]
    11ec:      	stp	q5, q6, [sp, #0x3c0]
    11f0:      	add	x15, sp, #0x3c0
    11f4:      	ldr	s2, [x15, w12, uxtw #2]
    11f8:      	orr	x12, x24, x5
    11fc:      	ldrb	w12, [x12]
    1200:      	stp	q5, q6, [sp, #0x3a0]
    1204:      	add	x15, sp, #0x3a0
    1208:      	ldr	s3, [x15, w5, uxtw #2]
    120c:      	csel	w5, w26, wzr, ne
    1210:      	tst	w7, w8
    1214:      	fcsel	s2, s2, s25, ne
    1218:      	tst	w2, w12
    121c:      	orr	x8, x24, x6
    1220:      	ldrb	w8, [x8]
    1224:      	stp	q5, q6, [sp, #0x380]
    1228:      	add	x12, sp, #0x380
    122c:      	ldr	s4, [x12, w6, uxtw #2]
    1230:      	fcsel	s3, s3, s25, ne
    1234:      	tst	w30, w8
    1238:      	orr	x8, x24, x28
    123c:      	ldrb	w8, [x8]
    1240:      	stp	q5, q6, [sp, #0x360]
    1244:      	add	x12, sp, #0x360
    1248:      	ldr	s7, [x12, w28, uxtw #2]
    124c:      	fcsel	s4, s4, s25, ne
    1250:      	tst	w11, w8
    1254:      	fcsel	s7, s7, s25, ne
    1258:      	mov.s	v2[1], v3[0]
    125c:      	mov.s	v2[2], v4[0]
    1260:      	mov.s	v2[3], v7[0]
    1264:      	mov.s	v21[1], v23[0]
    1268:      	lsr	x8, x3, #1
    126c:      	add	x12, sp, #0x340
    1270:      	bfi	x12, x8, #3, #1
    1274:      	mov.s	v21[2], v22[0]
    1278:      	mov.s	v21[3], v24[0]
    127c:      	fadd.4s	v5, v5, v21
    1280:      	fadd.4s	v6, v6, v2
    1284:      	orr	x8, x24, x3
    1288:      	ldrb	w8, [x8]
    128c:      	stp	q5, q6, [sp, #0x340]
    1290:      	ldr	s2, [x12]
    1294:      	tst	w1, w8
    1298:      	fcsel	s21, s2, s25, ne
    129c:      	ldr	w8, [sp, #0xd0]
    12a0:      	ands	w8, w8, #0x1
    12a4:      	mov	w12, #0x3               ; =3
    12a8:      	csel	w12, w12, wzr, ne
    12ac:      	orr	x3, x24, x12
    12b0:      	ldrb	w3, [x3]
    12b4:      	tst	w8, w3
    12b8:      	add	x8, sp, #0x280
    12bc:      	orr	x8, x8, x12, lsl #2
    12c0:      	stp	q5, q6, [sp, #0x280]
    12c4:      	ldr	s2, [x8]
    12c8:      	add	x8, sp, #0x1f8
    12cc:      	bfxil	x8, x22, #0, #1
    12d0:      	ldrb	w8, [x8]
    12d4:      	fcsel	s2, s2, s25, ne
    12d8:      	ldr	w15, [sp, #0xf0]
    12dc:      	tst	w15, #0x1
    12e0:      	fcsel	s3, s5, s25, ne
    12e4:      	tst	w21, w8
    12e8:      	add	x8, sp, #0x320
    12ec:      	bfi	x8, x22, #2, #1
    12f0:      	stp	q5, q6, [sp, #0x320]
    12f4:      	ldr	s4, [x8]
    12f8:      	orr	x8, x24, x5
    12fc:      	ldrb	w8, [x8]
    1300:      	stp	q5, q6, [sp, #0x300]
    1304:      	add	x12, sp, #0x300
    1308:      	ldr	s7, [x12, w5, uxtw #2]
    130c:      	fcsel	s4, s4, s25, ne
    1310:      	tst	w7, w8
    1314:      	fcsel	s7, s7, s25, ne
    1318:      	orr	x8, x24, x19
    131c:      	ldrb	w8, [x8]
    1320:      	tst	w2, w8
    1324:      	stp	q5, q6, [sp, #0x2e0]
    1328:      	add	x8, sp, #0x2e0
    132c:      	ldr	s20, [x8, w19, uxtw #2]
    1330:      	fcsel	s20, s20, s25, ne
    1334:      	orr	x8, x24, x27
    1338:      	ldrb	w8, [x8]
    133c:      	tst	w30, w8
    1340:      	stp	q5, q6, [sp, #0x2c0]
    1344:      	add	x8, sp, #0x2c0
    1348:      	ldr	s22, [x8, w27, uxtw #2]
    134c:      	orr	x8, x24, x4
    1350:      	ldrb	w8, [x8]
    1354:      	stp	q5, q6, [sp, #0x2a0]
    1358:      	add	x12, sp, #0x2a0
    135c:      	ldr	s23, [x12, w4, uxtw #2]
    1360:      	fcsel	s22, s22, s25, ne
    1364:      	tst	w11, w8
    1368:      	fcsel	s23, s23, s25, ne
    136c:      	mov.s	v21[1], v2[0]
    1370:      	mov.s	v21[2], v3[0]
    1374:      	mov.s	v21[3], v4[0]
    1378:      	mov.s	v7[1], v20[0]
    137c:      	ldr	x11, [sp, #0xa0]
    1380:      	orr	x8, x24, x11
    1384:      	ldrb	w8, [x8]
    1388:      	tst	w1, w8
    138c:      	mov.s	v7[2], v22[0]
    1390:      	mov.s	v7[3], v23[0]
    1394:      	fadd.4s	v2, v5, v21
    1398:      	fadd.4s	v3, v6, v7
    139c:      	stp	q2, q3, [sp, #0x260]
    13a0:      	add	x8, sp, #0x260
    13a4:      	ldr	s3, [x8, w11, uxtw #2]
    13a8:      	fcsel	s3, s3, s25, ne
    13ac:      	tst	w0, #0x1
    13b0:      	fadd	s2, s2, s3
    13b4:      	fcsel	s3, s2, s25, ne
    13b8:      	ldr	w8, [sp, #0x5c]
    13bc:      	tst	w8, #0x1
    13c0:      	fcsel	s4, s2, s25, ne
    13c4:      	tst	w15, #0x1
    13c8:      	fcsel	s5, s2, s25, ne
    13cc:      	ldr	w8, [sp, #0xbc]
    13d0:      	tst	w8, #0x1
    13d4:      	fcsel	s6, s2, s25, ne
    13d8:      	ldr	w8, [sp, #0xe0]
    13dc:      	tst	w8, #0x1
    13e0:      	fcsel	s7, s2, s25, ne
    13e4:      	ldr	w8, [sp, #0xb8]
    13e8:      	tst	w8, #0x1
    13ec:      	fcsel	s21, s2, s25, ne
    13f0:      	ldr	w8, [sp, #0xb4]
    13f4:      	tst	w8, #0x1
    13f8:      	sshll.2d	v22, v1, #0x0
    13fc:      	shl.8b	v20, v30, #0x7
    1400:      	cmlt.8b	v20, v20, #0
    1404:      	ldr	d23, [sp, #0x108]
    1408:      	and.8b	v20, v20, v23
    140c:      	addv.8b	b20, v20
    1410:      	fcsel	s23, s2, s25, ne
    1414:      	ldr	w8, [sp, #0xc8]
    1418:      	tst	w8, #0x1
    141c:      	movi	d24, #0000000000000000
    1420:      	fcsel	s2, s2, s25, ne
    1424:      	mov.s	v3[1], v4[0]
    1428:      	mov.s	v3[2], v5[0]
    142c:      	mov.s	v3[3], v6[0]
    1430:      	mov.s	v7[1], v21[0]
    1434:      	mov.s	v7[2], v23[0]
    1438:      	mov.s	v7[3], v2[0]
    143c:      	stp	q3, q7, [sp, #0x240]
    1440:      	ldr	x8, [sp, #0xc0]
    1444:      	and	x8, x8, #0x7
    1448:      	add	x11, sp, #0x240
    144c:      	ldr	s5, [x11, x8, lsl #2]
    1450:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0xc04>
    1454:      	ldr	q2, [x8]
    1458:      	and.16b	v2, v22, v2
    145c:      	movi.2d	v3, #0000000000000000
    1460:      	stp	q3, q3, [sp, #0x220]
    1464:      	stp	q2, q3, [sp, #0x200]
    1468:      	ldr	x3, [sp, #0x170]
    146c:      	and	x8, x3, #0x7
    1470:      	add	x11, sp, #0x200
    1474:      	ldr	x8, [x11, x8, lsl #3]
    1478:      	fmov	w15, s20
    147c:      	sub	x8, x8, x3
    1480:      	lsl	x11, x8, #2
    1484:      	add	x17, x17, x11
    1488:      	movi.2d	v6, #0000000000000000
    148c:      	movi.2d	v21, #0000000000000000
    1490:      	tbnz	w15, #0x0, 0x18ec <_llm_rows.packet_batch.blocks+0x14f0>
    1494:      	ldr	w27, [sp, #0x2c]
    1498:      	ldr	x2, [sp, #0x178]
    149c:      	ldr	x4, [sp, #0x148]
    14a0:      	ldr	w22, [sp, #0xcc]
    14a4:      	tbnz	w15, #0x1, 0x1904 <_llm_rows.packet_batch.blocks+0x1508>
    14a8:      	ldr	x28, [sp, #0x20]
    14ac:      	ldr	w26, [sp, #0x184]
    14b0:      	mov	w24, #0x4               ; =4
    14b4:      	ldr	x5, [sp, #0x188]
    14b8:      	tbnz	w15, #0x2, 0x1920 <_llm_rows.packet_batch.blocks+0x1524>
    14bc:      	tbnz	w15, #0x3, 0x192c <_llm_rows.packet_batch.blocks+0x1530>
    14c0:      	tbnz	w15, #0x4, 0x1938 <_llm_rows.packet_batch.blocks+0x153c>
    14c4:      	tbnz	w15, #0x5, 0x1944 <_llm_rows.packet_batch.blocks+0x1548>
    14c8:      	tbnz	w15, #0x6, 0x1950 <_llm_rows.packet_batch.blocks+0x1554>
    14cc:      	tbz	w15, #0x7, 0x14d8 <_llm_rows.packet_batch.blocks+0x10dc>
    14d0:      	add	x8, x17, #0x1c
    14d4:      	ld1.s	{ v21 }[3], [x8]
    14d8:      	fadd	s2, s5, s24
    14dc:      	mov	w8, #0x800              ; =2048
    14e0:      	movk	w8, #0x4580, lsl #16
    14e4:      	fmov	s3, w8
    14e8:      	fdiv	s2, s2, s3
    14ec:      	add	x8, x9, x5
    14f0:      	ldp	q3, q4, [x8]
    14f4:      	zip2.8b	v5, v30, v0
    14f8:      	ushll.4s	v5, v5, #0x0
    14fc:      	shl.4s	v5, v5, #0x1f
    1500:      	cmlt.4s	v5, v5, #0
    1504:      	bit.16b	v4, v21, v5
    1508:      	zip1.8b	v5, v30, v0
    150c:      	ushll.4s	v5, v5, #0x0
    1510:      	shl.4s	v5, v5, #0x1f
    1514:      	cmlt.4s	v5, v5, #0
    1518:      	bit.16b	v3, v6, v5
    151c:      	stp	q3, q4, [x8]
    1520:      	mov	w8, #0xc5ac             ; =50604
    1524:      	movk	w8, #0x3727, lsl #16
    1528:      	fmov	s3, w8
    152c:      	fadd	s2, s2, s3
    1530:      	fsqrt	s21, s2
    1534:      	subs	x8, x2, x14
    1538:      	mov	w12, #0x4003            ; =16387
    153c:      	ccmp	x8, x12, #0x0, hs
    1540:      	cset	w15, hi
    1544:      	sub	x8, x14, x2
    1548:      	mov	w12, #0xfff             ; =4095
    154c:      	movk	w12, #0x100, lsl #16
    1550:      	cmp	x8, x12
    1554:      	ccmp	x14, x2, #0x0, hi
    1558:      	b.hs	0x164c <_llm_rows.packet_batch.blocks+0x1250>
    155c:      	tbnz	w15, #0x0, 0x164c <_llm_rows.packet_batch.blocks+0x1250>
    1560:      	mov	x15, #0x0               ; =0
    1564:      	movi.2d	v5, #0000000000000000
    1568:      	movi.2d	v6, #0000000000000000
    156c:      	movi.2d	v22, #0000000000000000
    1570:      	movi.2d	v23, #0000000000000000
    1574:      	b	0x15b0 <_llm_rows.packet_batch.blocks+0x11b4>
    1578:      	add	x8, x13, x15
    157c:      	ldp	q2, q3, [x8]
    1580:      	bit.16b	v3, v25, v0
    1584:      	bit.16b	v2, v24, v1
    1588:      	stp	q2, q3, [x8]
    158c:      	add.2d	v2, v5, v19
    1590:      	add.2d	v6, v6, v17
    1594:      	add.2d	v22, v22, v18
    1598:      	add.2d	v23, v23, v16
    159c:      	fmov	x8, d5
    15a0:      	add	x15, x8, x16
    15a4:      	mov.16b	v5, v2
    15a8:      	cmp	x15, #0x200
    15ac:      	b.ge	0x1960 <_llm_rows.packet_batch.blocks+0x1564>
    15b0:      	fmov	w0, s28
    15b4:      	lsl	x15, x15, #5
    15b8:      	add	x17, x14, x15
    15bc:      	movi.2d	v24, #0000000000000000
    15c0:      	movi.2d	v25, #0000000000000000
    15c4:      	tbnz	w0, #0x0, 0x15ec <_llm_rows.packet_batch.blocks+0x11f0>
    15c8:      	and	w0, w0, #0xff
    15cc:      	tbnz	w0, #0x1, 0x15f8 <_llm_rows.packet_batch.blocks+0x11fc>
    15d0:      	tbnz	w0, #0x2, 0x1604 <_llm_rows.packet_batch.blocks+0x1208>
    15d4:      	tbnz	w0, #0x3, 0x1610 <_llm_rows.packet_batch.blocks+0x1214>
    15d8:      	tbnz	w0, #0x4, 0x161c <_llm_rows.packet_batch.blocks+0x1220>
    15dc:      	tbnz	w0, #0x5, 0x1628 <_llm_rows.packet_batch.blocks+0x122c>
    15e0:      	tbnz	w0, #0x6, 0x1634 <_llm_rows.packet_batch.blocks+0x1238>
    15e4:      	tbz	w0, #0x7, 0x1578 <_llm_rows.packet_batch.blocks+0x117c>
    15e8:      	b	0x1640 <_llm_rows.packet_batch.blocks+0x1244>
    15ec:      	ldr	s24, [x17]
    15f0:      	and	w0, w0, #0xff
    15f4:      	tbz	w0, #0x1, 0x15d0 <_llm_rows.packet_batch.blocks+0x11d4>
    15f8:      	add	x8, x17, #0x4
    15fc:      	ld1.s	{ v24 }[1], [x8]
    1600:      	tbz	w0, #0x2, 0x15d4 <_llm_rows.packet_batch.blocks+0x11d8>
    1604:      	add	x8, x17, #0x8
    1608:      	ld1.s	{ v24 }[2], [x8]
    160c:      	tbz	w0, #0x3, 0x15d8 <_llm_rows.packet_batch.blocks+0x11dc>
    1610:      	add	x8, x17, #0xc
    1614:      	ld1.s	{ v24 }[3], [x8]
    1618:      	tbz	w0, #0x4, 0x15dc <_llm_rows.packet_batch.blocks+0x11e0>
    161c:      	add	x8, x17, #0x10
    1620:      	ld1.s	{ v25 }[0], [x8]
    1624:      	tbz	w0, #0x5, 0x15e0 <_llm_rows.packet_batch.blocks+0x11e4>
    1628:      	add	x8, x17, #0x14
    162c:      	ld1.s	{ v25 }[1], [x8]
    1630:      	tbz	w0, #0x6, 0x15e4 <_llm_rows.packet_batch.blocks+0x11e8>
    1634:      	add	x8, x17, #0x18
    1638:      	ld1.s	{ v25 }[2], [x8]
    163c:      	tbz	w0, #0x7, 0x1578 <_llm_rows.packet_batch.blocks+0x117c>
    1640:      	add	x8, x17, #0x1c
    1644:      	ld1.s	{ v25 }[3], [x8]
    1648:      	b	0x1578 <_llm_rows.packet_batch.blocks+0x117c>
    164c:      	mov	x15, #0x0               ; =0
    1650:      	dup.4s	v21, v21[0]
    1654:      	movi.2d	v5, #0000000000000000
    1658:      	movi.2d	v6, #0000000000000000
    165c:      	movi.2d	v22, #0000000000000000
    1660:      	movi.2d	v23, #0000000000000000
    1664:      	b	0x1684 <_llm_rows.packet_batch.blocks+0x1288>
    1668:      	add.2d	v5, v5, v19
    166c:      	add.2d	v6, v6, v17
    1670:      	add.2d	v22, v22, v18
    1674:      	add.2d	v23, v23, v16
    1678:      	add	x15, x13, x16
    167c:      	cmp	x15, #0x200
    1680:      	b.ge	0x1800 <_llm_rows.packet_batch.blocks+0x1404>
    1684:      	fmov	w1, s28
    1688:      	fmov	x13, d5
    168c:      	lsl	x17, x13, #5
    1690:      	add	x0, x14, x17
    1694:      	movi.2d	v25, #0000000000000000
    1698:      	movi.2d	v24, #0000000000000000
    169c:      	tbnz	w1, #0x0, 0x1738 <_llm_rows.packet_batch.blocks+0x133c>
    16a0:      	and	w1, w1, #0xff
    16a4:      	tbnz	w1, #0x1, 0x1744 <_llm_rows.packet_batch.blocks+0x1348>
    16a8:      	tbnz	w1, #0x2, 0x1750 <_llm_rows.packet_batch.blocks+0x1354>
    16ac:      	tbnz	w1, #0x3, 0x175c <_llm_rows.packet_batch.blocks+0x1360>
    16b0:      	tbnz	w1, #0x4, 0x1768 <_llm_rows.packet_batch.blocks+0x136c>
    16b4:      	tbnz	w1, #0x5, 0x1774 <_llm_rows.packet_batch.blocks+0x1378>
    16b8:      	tbnz	w1, #0x6, 0x1780 <_llm_rows.packet_batch.blocks+0x1384>
    16bc:      	tbz	w1, #0x7, 0x16c8 <_llm_rows.packet_batch.blocks+0x12cc>
    16c0:      	add	x8, x0, #0x1c
    16c4:      	ld1.s	{ v24 }[3], [x8]
    16c8:      	lsl	x8, x15, #5
    16cc:      	add	x12, x10, x8
    16d0:      	ldp	q2, q26, [x12]
    16d4:      	and.16b	v2, v1, v2
    16d8:      	fdiv.4s	v2, v2, v21
    16dc:      	add	x8, x9, x8
    16e0:      	ldp	q3, q27, [x8]
    16e4:      	and.16b	v3, v1, v3
    16e8:      	fmul.4s	v2, v2, v3
    16ec:      	fmov	w0, s28
    16f0:      	fadd.4s	v25, v25, v2
    16f4:      	add	x8, x2, x17
    16f8:      	add	x15, x8, x4
    16fc:      	tbnz	w0, #0x0, 0x1790 <_llm_rows.packet_batch.blocks+0x1394>
    1700:      	and	w17, w0, #0xff
    1704:      	tbnz	w17, #0x1, 0x179c <_llm_rows.packet_batch.blocks+0x13a0>
    1708:      	tbnz	w17, #0x2, 0x17a8 <_llm_rows.packet_batch.blocks+0x13ac>
    170c:      	tbnz	w17, #0x3, 0x17b4 <_llm_rows.packet_batch.blocks+0x13b8>
    1710:      	and.16b	v2, v0, v26
    1714:      	fdiv.4s	v2, v2, v21
    1718:      	and.16b	v3, v0, v27
    171c:      	fmul.4s	v2, v2, v3
    1720:      	fadd.4s	v24, v24, v2
    1724:      	tbnz	w17, #0x4, 0x17d4 <_llm_rows.packet_batch.blocks+0x13d8>
    1728:      	tbnz	w17, #0x5, 0x17dc <_llm_rows.packet_batch.blocks+0x13e0>
    172c:      	tbnz	w17, #0x6, 0x17e8 <_llm_rows.packet_batch.blocks+0x13ec>
    1730:      	tbz	w17, #0x7, 0x1668 <_llm_rows.packet_batch.blocks+0x126c>
    1734:      	b	0x17f4 <_llm_rows.packet_batch.blocks+0x13f8>
    1738:      	ldr	s25, [x0]
    173c:      	and	w1, w1, #0xff
    1740:      	tbz	w1, #0x1, 0x16a8 <_llm_rows.packet_batch.blocks+0x12ac>
    1744:      	add	x8, x0, #0x4
    1748:      	ld1.s	{ v25 }[1], [x8]
    174c:      	tbz	w1, #0x2, 0x16ac <_llm_rows.packet_batch.blocks+0x12b0>
    1750:      	add	x8, x0, #0x8
    1754:      	ld1.s	{ v25 }[2], [x8]
    1758:      	tbz	w1, #0x3, 0x16b0 <_llm_rows.packet_batch.blocks+0x12b4>
    175c:      	add	x8, x0, #0xc
    1760:      	ld1.s	{ v25 }[3], [x8]
    1764:      	tbz	w1, #0x4, 0x16b4 <_llm_rows.packet_batch.blocks+0x12b8>
    1768:      	add	x8, x0, #0x10
    176c:      	ld1.s	{ v24 }[0], [x8]
    1770:      	tbz	w1, #0x5, 0x16b8 <_llm_rows.packet_batch.blocks+0x12bc>
    1774:      	add	x8, x0, #0x14
    1778:      	ld1.s	{ v24 }[1], [x8]
    177c:      	tbz	w1, #0x6, 0x16bc <_llm_rows.packet_batch.blocks+0x12c0>
    1780:      	add	x8, x0, #0x18
    1784:      	ld1.s	{ v24 }[2], [x8]
    1788:      	tbnz	w1, #0x7, 0x16c0 <_llm_rows.packet_batch.blocks+0x12c4>
    178c:      	b	0x16c8 <_llm_rows.packet_batch.blocks+0x12cc>
    1790:      	str	s25, [x15]
    1794:      	and	w17, w0, #0xff
    1798:      	tbz	w17, #0x1, 0x1708 <_llm_rows.packet_batch.blocks+0x130c>
    179c:      	add	x8, x15, #0x4
    17a0:      	st1.s	{ v25 }[1], [x8]
    17a4:      	tbz	w17, #0x2, 0x170c <_llm_rows.packet_batch.blocks+0x1310>
    17a8:      	add	x8, x15, #0x8
    17ac:      	st1.s	{ v25 }[2], [x8]
    17b0:      	tbz	w17, #0x3, 0x1710 <_llm_rows.packet_batch.blocks+0x1314>
    17b4:      	add	x8, x15, #0xc
    17b8:      	st1.s	{ v25 }[3], [x8]
    17bc:      	and.16b	v2, v0, v26
    17c0:      	fdiv.4s	v2, v2, v21
    17c4:      	and.16b	v3, v0, v27
    17c8:      	fmul.4s	v2, v2, v3
    17cc:      	fadd.4s	v24, v24, v2
    17d0:      	tbz	w17, #0x4, 0x1728 <_llm_rows.packet_batch.blocks+0x132c>
    17d4:      	str	s24, [x15, #0x10]
    17d8:      	tbz	w17, #0x5, 0x172c <_llm_rows.packet_batch.blocks+0x1330>
    17dc:      	add	x8, x15, #0x14
    17e0:      	st1.s	{ v24 }[1], [x8]
    17e4:      	tbz	w17, #0x6, 0x1730 <_llm_rows.packet_batch.blocks+0x1334>
    17e8:      	add	x8, x15, #0x18
    17ec:      	st1.s	{ v24 }[2], [x8]
    17f0:      	tbz	w17, #0x7, 0x1668 <_llm_rows.packet_batch.blocks+0x126c>
    17f4:      	add	x8, x15, #0x1c
    17f8:      	st1.s	{ v24 }[3], [x8]
    17fc:      	b	0x1668 <_llm_rows.packet_batch.blocks+0x126c>
    1800:      	add	x8, x10, x5
    1804:      	ldp	q0, q6, [x8]
    1808:      	fmov	w10, s20
    180c:      	add	x8, x9, x5
    1810:      	ldp	q2, q1, [x8]
    1814:      	add	x9, x14, x11
    1818:      	movi.2d	v5, #0000000000000000
    181c:      	movi.2d	v16, #0000000000000000
    1820:      	tbnz	w10, #0x0, 0x1bf8 <_llm_rows.packet_batch.blocks+0x17fc>
    1824:      	tbnz	w10, #0x1, 0x1c00 <_llm_rows.packet_batch.blocks+0x1804>
    1828:      	tbnz	w10, #0x2, 0x1c0c <_llm_rows.packet_batch.blocks+0x1810>
    182c:      	tbnz	w10, #0x3, 0x1c18 <_llm_rows.packet_batch.blocks+0x181c>
    1830:      	tbnz	w10, #0x4, 0x1c24 <_llm_rows.packet_batch.blocks+0x1828>
    1834:      	tbnz	w10, #0x5, 0x1c30 <_llm_rows.packet_batch.blocks+0x1834>
    1838:      	tbnz	w10, #0x6, 0x1c3c <_llm_rows.packet_batch.blocks+0x1840>
    183c:      	tbz	w10, #0x7, 0x1848 <_llm_rows.packet_batch.blocks+0x144c>
    1840:      	add	x8, x9, #0x1c
    1844:      	ld1.s	{ v16 }[3], [x8]
    1848:      	zip2.8b	v3, v30, v0
    184c:      	ushll.4s	v3, v3, #0x0
    1850:      	shl.4s	v3, v3, #0x1f
    1854:      	cmlt.4s	v3, v3, #0
    1858:      	and.16b	v4, v3, v6
    185c:      	zip1.8b	v6, v30, v0
    1860:      	ushll.4s	v6, v6, #0x0
    1864:      	shl.4s	v6, v6, #0x1f
    1868:      	cmlt.4s	v6, v6, #0
    186c:      	and.16b	v0, v6, v0
    1870:      	fdiv.4s	v0, v0, v21
    1874:      	fdiv.4s	v4, v4, v21
    1878:      	and.16b	v2, v6, v2
    187c:      	and.16b	v1, v3, v1
    1880:      	fmul.4s	v3, v4, v1
    1884:      	fmul.4s	v0, v0, v2
    1888:      	fadd.4s	v1, v5, v0
    188c:      	fadd.4s	v0, v16, v3
    1890:      	b	0x1b50 <_llm_rows.packet_batch.blocks+0x1754>
    1894:      	ldr	s20, [x11]
    1898:      	tbz	w15, #0x1, 0x7e8 <_llm_rows.packet_batch.blocks+0x3ec>
    189c:      	add	x2, x11, #0x4
    18a0:      	ld1.s	{ v20 }[1], [x2]
    18a4:      	tbz	w15, #0x2, 0x7ec <_llm_rows.packet_batch.blocks+0x3f0>
    18a8:      	add	x2, x11, #0x8
    18ac:      	ld1.s	{ v20 }[2], [x2]
    18b0:      	tbz	w15, #0x3, 0x7f0 <_llm_rows.packet_batch.blocks+0x3f4>
    18b4:      	add	x2, x11, #0xc
    18b8:      	ld1.s	{ v20 }[3], [x2]
    18bc:      	tbz	w15, #0x4, 0x7f4 <_llm_rows.packet_batch.blocks+0x3f8>
    18c0:      	add	x2, x11, #0x10
    18c4:      	ld1.s	{ v28 }[0], [x2]
    18c8:      	tbz	w15, #0x5, 0x7f8 <_llm_rows.packet_batch.blocks+0x3fc>
    18cc:      	add	x2, x11, #0x14
    18d0:      	ld1.s	{ v28 }[1], [x2]
    18d4:      	tbz	w15, #0x6, 0x7fc <_llm_rows.packet_batch.blocks+0x400>
    18d8:      	add	x2, x11, #0x18
    18dc:      	ld1.s	{ v28 }[2], [x2]
    18e0:      	str	q16, [sp, #0x160]
    18e4:      	tbnz	w15, #0x7, 0x804 <_llm_rows.packet_batch.blocks+0x408>
    18e8:      	b	0x80c <_llm_rows.packet_batch.blocks+0x410>
    18ec:      	ldr	s6, [x17]
    18f0:      	ldr	w27, [sp, #0x2c]
    18f4:      	ldr	x2, [sp, #0x178]
    18f8:      	ldr	x4, [sp, #0x148]
    18fc:      	ldr	w22, [sp, #0xcc]
    1900:      	tbz	w15, #0x1, 0x14a8 <_llm_rows.packet_batch.blocks+0x10ac>
    1904:      	add	x8, x17, #0x4
    1908:      	ld1.s	{ v6 }[1], [x8]
    190c:      	ldr	x28, [sp, #0x20]
    1910:      	ldr	w26, [sp, #0x184]
    1914:      	mov	w24, #0x4               ; =4
    1918:      	ldr	x5, [sp, #0x188]
    191c:      	tbz	w15, #0x2, 0x14bc <_llm_rows.packet_batch.blocks+0x10c0>
    1920:      	add	x8, x17, #0x8
    1924:      	ld1.s	{ v6 }[2], [x8]
    1928:      	tbz	w15, #0x3, 0x14c0 <_llm_rows.packet_batch.blocks+0x10c4>
    192c:      	add	x8, x17, #0xc
    1930:      	ld1.s	{ v6 }[3], [x8]
    1934:      	tbz	w15, #0x4, 0x14c4 <_llm_rows.packet_batch.blocks+0x10c8>
    1938:      	add	x8, x17, #0x10
    193c:      	ld1.s	{ v21 }[0], [x8]
    1940:      	tbz	w15, #0x5, 0x14c8 <_llm_rows.packet_batch.blocks+0x10cc>
    1944:      	add	x8, x17, #0x14
    1948:      	ld1.s	{ v21 }[1], [x8]
    194c:      	tbz	w15, #0x6, 0x14cc <_llm_rows.packet_batch.blocks+0x10d0>
    1950:      	add	x8, x17, #0x18
    1954:      	ld1.s	{ v21 }[2], [x8]
    1958:      	tbnz	w15, #0x7, 0x14d0 <_llm_rows.packet_batch.blocks+0x10d4>
    195c:      	b	0x14d8 <_llm_rows.packet_batch.blocks+0x10dc>
    1960:      	add	x11, x14, x11
    1964:      	fmov	w14, s20
    1968:      	movi.2d	v5, #0000000000000000
    196c:      	movi.2d	v6, #0000000000000000
    1970:      	tbnz	w14, #0x0, 0x1c4c <_llm_rows.packet_batch.blocks+0x1850>
    1974:      	tbnz	w14, #0x1, 0x1c54 <_llm_rows.packet_batch.blocks+0x1858>
    1978:      	tbnz	w14, #0x2, 0x1c60 <_llm_rows.packet_batch.blocks+0x1864>
    197c:      	tbnz	w14, #0x3, 0x1c6c <_llm_rows.packet_batch.blocks+0x1870>
    1980:      	tbnz	w14, #0x4, 0x1c78 <_llm_rows.packet_batch.blocks+0x187c>
    1984:      	tbnz	w14, #0x5, 0x1c84 <_llm_rows.packet_batch.blocks+0x1888>
    1988:      	tbnz	w14, #0x6, 0x1c90 <_llm_rows.packet_batch.blocks+0x1894>
    198c:      	tbz	w14, #0x7, 0x1998 <_llm_rows.packet_batch.blocks+0x159c>
    1990:      	add	x8, x11, #0x1c
    1994:      	ld1.s	{ v6 }[3], [x8]
    1998:      	mov	x14, #0x0               ; =0
    199c:      	add	x8, x13, x5
    19a0:      	ldp	q2, q3, [x8]
    19a4:      	zip2.8b	v4, v30, v0
    19a8:      	ushll.4s	v4, v4, #0x0
    19ac:      	shl.4s	v4, v4, #0x1f
    19b0:      	cmlt.4s	v4, v4, #0
    19b4:      	bit.16b	v3, v6, v4
    19b8:      	zip1.8b	v4, v30, v0
    19bc:      	ushll.4s	v4, v4, #0x0
    19c0:      	shl.4s	v4, v4, #0x1f
    19c4:      	cmlt.4s	v4, v4, #0
    19c8:      	bit.16b	v2, v5, v4
    19cc:      	dup.4s	v5, v21[0]
    19d0:      	stp	q2, q3, [x8]
    19d4:      	add	x11, x2, x4
    19d8:      	movi.2d	v6, #0000000000000000
    19dc:      	movi.2d	v21, #0000000000000000
    19e0:      	movi.2d	v22, #0000000000000000
    19e4:      	movi.2d	v23, #0000000000000000
    19e8:      	b	0x1a10 <_llm_rows.packet_batch.blocks+0x1614>
    19ec:      	add.2d	v2, v6, v19
    19f0:      	add.2d	v21, v21, v17
    19f4:      	add.2d	v22, v22, v18
    19f8:      	add.2d	v23, v23, v16
    19fc:      	fmov	x8, d6
    1a00:      	add	x14, x8, x16
    1a04:      	mov.16b	v6, v2
    1a08:      	cmp	x14, #0x200
    1a0c:      	b.ge	0x1ae8 <_llm_rows.packet_batch.blocks+0x16ec>
    1a10:      	fmov	w15, s28
    1a14:      	lsl	x8, x14, #5
    1a18:      	add	x12, x10, x8
    1a1c:      	ldp	q2, q24, [x12]
    1a20:      	and.16b	v2, v1, v2
    1a24:      	fdiv.4s	v2, v2, v5
    1a28:      	add	x12, x9, x8
    1a2c:      	ldp	q3, q25, [x12]
    1a30:      	and.16b	v3, v1, v3
    1a34:      	fmul.4s	v2, v2, v3
    1a38:      	add	x12, x13, x8
    1a3c:      	ldp	q3, q26, [x12]
    1a40:      	and.16b	v3, v1, v3
    1a44:      	fadd.4s	v27, v2, v3
    1a48:      	add	x12, x11, x8
    1a4c:      	tbnz	w15, #0x0, 0x1a94 <_llm_rows.packet_batch.blocks+0x1698>
    1a50:      	and	w14, w15, #0xff
    1a54:      	tbnz	w14, #0x1, 0x1aa0 <_llm_rows.packet_batch.blocks+0x16a4>
    1a58:      	tbnz	w14, #0x2, 0x1aac <_llm_rows.packet_batch.blocks+0x16b0>
    1a5c:      	tbz	w14, #0x3, 0x1a68 <_llm_rows.packet_batch.blocks+0x166c>
    1a60:      	add	x8, x12, #0xc
    1a64:      	st1.s	{ v27 }[3], [x8]
    1a68:      	and.16b	v2, v0, v24
    1a6c:      	fdiv.4s	v2, v2, v5
    1a70:      	and.16b	v3, v0, v25
    1a74:      	fmul.4s	v2, v2, v3
    1a78:      	and.16b	v3, v0, v26
    1a7c:      	fadd.4s	v24, v2, v3
    1a80:      	tbnz	w14, #0x4, 0x1abc <_llm_rows.packet_batch.blocks+0x16c0>
    1a84:      	tbnz	w14, #0x5, 0x1ac4 <_llm_rows.packet_batch.blocks+0x16c8>
    1a88:      	tbnz	w14, #0x6, 0x1ad0 <_llm_rows.packet_batch.blocks+0x16d4>
    1a8c:      	tbz	w14, #0x7, 0x19ec <_llm_rows.packet_batch.blocks+0x15f0>
    1a90:      	b	0x1adc <_llm_rows.packet_batch.blocks+0x16e0>
    1a94:      	str	s27, [x12]
    1a98:      	and	w14, w15, #0xff
    1a9c:      	tbz	w14, #0x1, 0x1a58 <_llm_rows.packet_batch.blocks+0x165c>
    1aa0:      	add	x8, x12, #0x4
    1aa4:      	st1.s	{ v27 }[1], [x8]
    1aa8:      	tbz	w14, #0x2, 0x1a5c <_llm_rows.packet_batch.blocks+0x1660>
    1aac:      	add	x8, x12, #0x8
    1ab0:      	st1.s	{ v27 }[2], [x8]
    1ab4:      	tbnz	w14, #0x3, 0x1a60 <_llm_rows.packet_batch.blocks+0x1664>
    1ab8:      	b	0x1a68 <_llm_rows.packet_batch.blocks+0x166c>
    1abc:      	str	s24, [x12, #0x10]
    1ac0:      	tbz	w14, #0x5, 0x1a88 <_llm_rows.packet_batch.blocks+0x168c>
    1ac4:      	add	x8, x12, #0x14
    1ac8:      	st1.s	{ v24 }[1], [x8]
    1acc:      	tbz	w14, #0x6, 0x1a8c <_llm_rows.packet_batch.blocks+0x1690>
    1ad0:      	add	x8, x12, #0x18
    1ad4:      	st1.s	{ v24 }[2], [x8]
    1ad8:      	tbz	w14, #0x7, 0x19ec <_llm_rows.packet_batch.blocks+0x15f0>
    1adc:      	add	x8, x12, #0x1c
    1ae0:      	st1.s	{ v24 }[3], [x8]
    1ae4:      	b	0x19ec <_llm_rows.packet_batch.blocks+0x15f0>
    1ae8:      	add	x8, x10, x5
    1aec:      	ldp	q1, q0, [x8]
    1af0:      	zip1.8b	v2, v30, v0
    1af4:      	ushll.4s	v2, v2, #0x0
    1af8:      	shl.4s	v2, v2, #0x1f
    1afc:      	cmlt.4s	v2, v2, #0
    1b00:      	and.16b	v1, v2, v1
    1b04:      	zip2.8b	v3, v30, v0
    1b08:      	ushll.4s	v3, v3, #0x0
    1b0c:      	shl.4s	v3, v3, #0x1f
    1b10:      	cmlt.4s	v3, v3, #0
    1b14:      	and.16b	v0, v3, v0
    1b18:      	fdiv.4s	v0, v0, v5
    1b1c:      	fdiv.4s	v1, v1, v5
    1b20:      	add	x8, x9, x5
    1b24:      	ldp	q4, q5, [x8]
    1b28:      	and.16b	v5, v3, v5
    1b2c:      	and.16b	v4, v2, v4
    1b30:      	fmul.4s	v1, v1, v4
    1b34:      	fmul.4s	v0, v0, v5
    1b38:      	add	x8, x13, x5
    1b3c:      	ldp	q5, q4, [x8]
    1b40:      	and.16b	v2, v2, v5
    1b44:      	and.16b	v3, v3, v4
    1b48:      	fadd.4s	v0, v0, v3
    1b4c:      	fadd.4s	v1, v1, v2
    1b50:      	ldr	q3, [sp, #0x150]
    1b54:      	ldp	q4, q5, [sp, #0x120]
    1b58:      	stp	q3, q4, [sp, #0x1b0]
    1b5c:      	ldr	q2, [sp, #0x110]
    1b60:      	stp	q5, q2, [sp, #0x1d0]
    1b64:      	and	x9, x3, #0x7
    1b68:      	add	x8, sp, #0x1b0
    1b6c:      	ldr	x9, [x8, x9, lsl #3]
    1b70:      	sub	x9, x9, x3
    1b74:      	add	x8, x2, x9, lsl #2
    1b78:      	fmov	w9, s20
    1b7c:      	tbnz	w9, #0x0, 0x1ba0 <_llm_rows.packet_batch.blocks+0x17a4>
    1b80:      	tbnz	w9, #0x1, 0x1ba8 <_llm_rows.packet_batch.blocks+0x17ac>
    1b84:      	tbnz	w9, #0x2, 0x1bb4 <_llm_rows.packet_batch.blocks+0x17b8>
    1b88:      	tbnz	w9, #0x3, 0x1bc0 <_llm_rows.packet_batch.blocks+0x17c4>
    1b8c:      	tbnz	w9, #0x4, 0x1bcc <_llm_rows.packet_batch.blocks+0x17d0>
    1b90:      	tbnz	w9, #0x5, 0x1bd4 <_llm_rows.packet_batch.blocks+0x17d8>
    1b94:      	tbnz	w9, #0x6, 0x1be0 <_llm_rows.packet_batch.blocks+0x17e4>
    1b98:      	tbz	w9, #0x7, 0x48c <_llm_rows.packet_batch.blocks+0x90>
    1b9c:      	b	0x1bec <_llm_rows.packet_batch.blocks+0x17f0>
    1ba0:      	str	s1, [x8]
    1ba4:      	tbz	w9, #0x1, 0x1b84 <_llm_rows.packet_batch.blocks+0x1788>
    1ba8:      	add	x10, x8, #0x4
    1bac:      	st1.s	{ v1 }[1], [x10]
    1bb0:      	tbz	w9, #0x2, 0x1b88 <_llm_rows.packet_batch.blocks+0x178c>
    1bb4:      	add	x10, x8, #0x8
    1bb8:      	st1.s	{ v1 }[2], [x10]
    1bbc:      	tbz	w9, #0x3, 0x1b8c <_llm_rows.packet_batch.blocks+0x1790>
    1bc0:      	add	x10, x8, #0xc
    1bc4:      	st1.s	{ v1 }[3], [x10]
    1bc8:      	tbz	w9, #0x4, 0x1b90 <_llm_rows.packet_batch.blocks+0x1794>
    1bcc:      	str	s0, [x8, #0x10]
    1bd0:      	tbz	w9, #0x5, 0x1b94 <_llm_rows.packet_batch.blocks+0x1798>
    1bd4:      	add	x10, x8, #0x14
    1bd8:      	st1.s	{ v0 }[1], [x10]
    1bdc:      	tbz	w9, #0x6, 0x1b98 <_llm_rows.packet_batch.blocks+0x179c>
    1be0:      	add	x10, x8, #0x18
    1be4:      	st1.s	{ v0 }[2], [x10]
    1be8:      	tbz	w9, #0x7, 0x48c <_llm_rows.packet_batch.blocks+0x90>
    1bec:      	add	x8, x8, #0x1c
    1bf0:      	st1.s	{ v0 }[3], [x8]
    1bf4:      	b	0x48c <_llm_rows.packet_batch.blocks+0x90>
    1bf8:      	ldr	s5, [x9]
    1bfc:      	tbz	w10, #0x1, 0x1828 <_llm_rows.packet_batch.blocks+0x142c>
    1c00:      	add	x8, x9, #0x4
    1c04:      	ld1.s	{ v5 }[1], [x8]
    1c08:      	tbz	w10, #0x2, 0x182c <_llm_rows.packet_batch.blocks+0x1430>
    1c0c:      	add	x8, x9, #0x8
    1c10:      	ld1.s	{ v5 }[2], [x8]
    1c14:      	tbz	w10, #0x3, 0x1830 <_llm_rows.packet_batch.blocks+0x1434>
    1c18:      	add	x8, x9, #0xc
    1c1c:      	ld1.s	{ v5 }[3], [x8]
    1c20:      	tbz	w10, #0x4, 0x1834 <_llm_rows.packet_batch.blocks+0x1438>
    1c24:      	add	x8, x9, #0x10
    1c28:      	ld1.s	{ v16 }[0], [x8]
    1c2c:      	tbz	w10, #0x5, 0x1838 <_llm_rows.packet_batch.blocks+0x143c>
    1c30:      	add	x8, x9, #0x14
    1c34:      	ld1.s	{ v16 }[1], [x8]
    1c38:      	tbz	w10, #0x6, 0x183c <_llm_rows.packet_batch.blocks+0x1440>
    1c3c:      	add	x8, x9, #0x18
    1c40:      	ld1.s	{ v16 }[2], [x8]
    1c44:      	tbnz	w10, #0x7, 0x1840 <_llm_rows.packet_batch.blocks+0x1444>
    1c48:      	b	0x1848 <_llm_rows.packet_batch.blocks+0x144c>
    1c4c:      	ldr	s5, [x11]
    1c50:      	tbz	w14, #0x1, 0x1978 <_llm_rows.packet_batch.blocks+0x157c>
    1c54:      	add	x8, x11, #0x4
    1c58:      	ld1.s	{ v5 }[1], [x8]
    1c5c:      	tbz	w14, #0x2, 0x197c <_llm_rows.packet_batch.blocks+0x1580>
    1c60:      	add	x8, x11, #0x8
    1c64:      	ld1.s	{ v5 }[2], [x8]
    1c68:      	tbz	w14, #0x3, 0x1980 <_llm_rows.packet_batch.blocks+0x1584>
    1c6c:      	add	x8, x11, #0xc
    1c70:      	ld1.s	{ v5 }[3], [x8]
    1c74:      	tbz	w14, #0x4, 0x1984 <_llm_rows.packet_batch.blocks+0x1588>
    1c78:      	add	x8, x11, #0x10
    1c7c:      	ld1.s	{ v6 }[0], [x8]
    1c80:      	tbz	w14, #0x5, 0x1988 <_llm_rows.packet_batch.blocks+0x158c>
    1c84:      	add	x8, x11, #0x14
    1c88:      	ld1.s	{ v6 }[1], [x8]
    1c8c:      	tbz	w14, #0x6, 0x198c <_llm_rows.packet_batch.blocks+0x1590>
    1c90:      	add	x8, x11, #0x18
    1c94:      	ld1.s	{ v6 }[2], [x8]
    1c98:      	tbnz	w14, #0x7, 0x1990 <_llm_rows.packet_batch.blocks+0x1594>
    1c9c:      	b	0x1998 <_llm_rows.packet_batch.blocks+0x159c>
    1ca0:      	add	sp, sp, #0x600
    1ca4:      	ldp	x29, x30, [sp, #0x90]
    1ca8:      	ldp	x20, x19, [sp, #0x80]
    1cac:      	ldp	x22, x21, [sp, #0x70]
    1cb0:      	ldp	x24, x23, [sp, #0x60]
    1cb4:      	ldp	x26, x25, [sp, #0x50]
    1cb8:      	ldp	x28, x27, [sp, #0x40]
    1cbc:      	ldp	d9, d8, [sp, #0x30]
    1cc0:      	ldp	d11, d10, [sp, #0x20]
    1cc4:      	ldp	d13, d12, [sp, #0x10]
    1cc8:      	ldp	d15, d14, [sp], #0xa0
    1ccc:      	ret

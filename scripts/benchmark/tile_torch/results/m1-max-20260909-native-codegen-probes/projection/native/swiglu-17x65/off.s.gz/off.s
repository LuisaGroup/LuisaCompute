
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/swiglu-17x65/off/object/tile_xir_w8_37973_1788936540893416_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d11, d10, [sp, #-0x30]!
       4:      	stp	d9, d8, [sp, #0x10]
       8:      	stp	x28, x27, [sp, #0x20]
       c:      	sub	sp, sp, #0x240
      10:      	ldr	x12, [x0]
      14:      	ldr	x10, [x0, #0x10]
      18:      	ldr	w8, [x1]
      1c:      	ldr	w9, [x1, #0x24]
      20:      	add	w8, w9, w8, lsl #5
      24:      	lsr	w8, w8, #3
      28:      	dup.2s	v0, w8
      2c:      	ldr	x8, [x0, #0x30]
      30:      	ushll.2d	v0, v0, #0x0
      34:      	subs	x9, x12, x8
      38:      	lsr	x9, x9, #2
      3c:      	mov	w11, #0x450             ; =1104
      40:      	ccmp	x9, x11, #0x0, hs
      44:      	cset	w9, hi
      48:      	subs	x13, x8, x12
      4c:      	lsr	x13, x13, #2
      50:      	ccmp	x13, x11, #0x0, hs
      54:      	csinc	w13, w9, wzr, ls
      58:      	subs	x9, x10, x8
      5c:      	lsr	x9, x9, #2
      60:      	ccmp	x9, x11, #0x0, hs
      64:      	cset	w9, hi
      68:      	subs	x14, x8, x10
      6c:      	lsr	x14, x14, #2
      70:      	ccmp	x14, x11, #0x0, hs
      74:      	csinc	w11, w9, wzr, ls
      78:      	fmov	x9, d0
      7c:      	add	x9, x9, x9, lsl #6
      80:      	lsl	x9, x9, #2
      84:      	cmp	w13, #0x1
      88:      	ccmp	w11, #0x0, #0x4, eq
      8c:      	b.ne	0x4c8 <ltmp0+0x4c8>
      90:      	mov	x11, #0x0               ; =0
      94:      	add	x9, x12, x9
      98:      	ldp	q1, q2, [x9, #0xc0]
      9c:      	stp	q1, q2, [sp, #0x1e0]
      a0:      	ldp	q1, q2, [x9, #0xe0]
      a4:      	stp	q1, q2, [sp, #0x200]
      a8:      	ldp	q1, q2, [x9, #0x80]
      ac:      	stp	q1, q2, [sp, #0x1a0]
      b0:      	ldp	q1, q2, [x9, #0xa0]
      b4:      	stp	q1, q2, [sp, #0x1c0]
      b8:      	ldp	q1, q2, [x9, #0x40]
      bc:      	stp	q1, q2, [sp, #0x160]
      c0:      	ldp	q1, q2, [x9, #0x60]
      c4:      	stp	q1, q2, [sp, #0x180]
      c8:      	ldp	q1, q2, [x9]
      cc:      	stp	q1, q2, [sp, #0x120]
      d0:      	ldp	q1, q2, [x9, #0x20]
      d4:      	stp	q1, q2, [sp, #0x140]
      d8:      	fmov	x9, d0
      dc:      	add	x9, x9, x9, lsl #6
      e0:      	lsl	x13, x9, #2
      e4:      	add	x9, x13, #0x100
      e8:      	ldr	s1, [x12, x9]
      ec:      	str	q1, [sp, #0x220]
      f0:      	add	x12, x10, x13
      f4:      	ldp	q0, q2, [x12, #0xc0]
      f8:      	stp	q0, q2, [sp, #0xc0]
      fc:      	ldp	q0, q2, [x12, #0xe0]
     100:      	stp	q0, q2, [sp, #0xe0]
     104:      	ldp	q0, q2, [x12, #0x80]
     108:      	stp	q0, q2, [sp, #0x80]
     10c:      	ldp	q0, q2, [x12, #0xa0]
     110:      	stp	q0, q2, [sp, #0xa0]
     114:      	ldp	q0, q2, [x12, #0x40]
     118:      	stp	q0, q2, [sp, #0x40]
     11c:      	ldp	q0, q2, [x12, #0x60]
     120:      	stp	q0, q2, [sp, #0x60]
     124:      	ldp	q2, q22, [x12]
     128:      	ldp	q23, q24, [x12, #0x20]
     12c:      	ldr	s0, [x10, x9]
     130:      	add	x10, x8, x13
     134:      	mov	w12, #0x42d00000        ; =1120927744
     138:      	dup.4s	v3, w12
     13c:      	mov	w12, #-0x3d380000       ; =-1027080192
     140:      	dup.4s	v4, w12
     144:      	mov	w12, #0xaa3b            ; =43579
     148:      	movk	w12, #0x3fb8, lsl #16
     14c:      	dup.4s	v5, w12
     150:      	add	x12, sp, #0x120
     154:      	movi.4s	v6, #0x4b, lsl #24
     158:      	mvni.4s	v7, #0x80, lsl #24
     15c:      	mov	w13, #0x7200            ; =29184
     160:      	movk	w13, #0xbf31, lsl #16
     164:      	dup.4s	v16, w13
     168:      	mov	w13, #0xbe8e            ; =48782
     16c:      	movk	w13, #0xb5bf, lsl #16
     170:      	dup.4s	v17, w13
     174:      	mov	w13, #0x2bda            ; =11226
     178:      	movk	w13, #0x3950, lsl #16
     17c:      	dup.4s	v18, w13
     180:      	mov	w13, #0x96c9            ; =38601
     184:      	movk	w13, #0x3ab6, lsl #16
     188:      	dup.4s	v19, w13
     18c:      	mov	w13, #0x88a6            ; =34982
     190:      	movk	w13, #0x3c08, lsl #16
     194:      	dup.4s	v20, w13
     198:      	mov	w13, #0xaa7a            ; =43642
     19c:      	movk	w13, #0x3d2a, lsl #16
     1a0:      	dup.4s	v21, w13
     1a4:      	mov	w13, #0xaaab            ; =43691
     1a8:      	movk	w13, #0x3e2a, lsl #16
     1ac:      	stp	q2, q22, [sp]
     1b0:      	movi.4s	v22, #0x3f, lsl #24
     1b4:      	fmov.4s	v2, #1.00000000
     1b8:      	mvni.4s	v25, #0x7f, msl #16
     1bc:      	stp	q23, q24, [sp, #0x20]
     1c0:      	fneg.4s	v23, v25
     1c4:      	dup.4s	v24, w13
     1c8:      	mvni.4s	v25, #0x3f, msl #16
     1cc:      	fneg.4s	v25, v25
     1d0:      	mov	x13, sp
     1d4:      	str	q0, [sp, #0x100]
     1d8:      	add	x14, x12, x11
     1dc:      	ldp	q26, q27, [x14]
     1e0:      	fneg.4s	v28, v27
     1e4:      	fneg.4s	v29, v26
     1e8:      	fcmge.4s	v30, v3, v26
     1ec:      	fcmge.4s	v31, v3, v27
     1f0:      	fcmge.4s	v8, v26, v4
     1f4:      	fcmge.4s	v9, v27, v4
     1f8:      	and.16b	v31, v31, v9
     1fc:      	and.16b	v30, v30, v8
     200:      	and.16b	v29, v30, v29
     204:      	and.16b	v28, v31, v28
     208:      	fmul.4s	v30, v28, v5
     20c:      	fmul.4s	v31, v29, v5
     210:      	mov.16b	v8, v7
     214:      	bsl.16b	v8, v6, v31
     218:      	mov.16b	v9, v7
     21c:      	bsl.16b	v9, v6, v30
     220:      	fadd.4s	v30, v30, v9
     224:      	fadd.4s	v31, v31, v8
     228:      	fsub.4s	v31, v31, v8
     22c:      	fsub.4s	v30, v30, v9
     230:      	fcvtzs.4s	v30, v30
     234:      	fcvtzs.4s	v31, v31
     238:      	scvtf.4s	v8, v31
     23c:      	scvtf.4s	v9, v30
     240:      	fmul.4s	v10, v9, v16
     244:      	fmul.4s	v11, v8, v16
     248:      	fadd.4s	v29, v29, v11
     24c:      	fadd.4s	v28, v28, v10
     250:      	fmul.4s	v8, v8, v17
     254:      	fmul.4s	v9, v9, v17
     258:      	fadd.4s	v28, v28, v9
     25c:      	fadd.4s	v29, v29, v8
     260:      	fmul.4s	v8, v29, v18
     264:      	fmul.4s	v9, v28, v18
     268:      	fadd.4s	v9, v9, v19
     26c:      	fadd.4s	v8, v8, v19
     270:      	fmul.4s	v8, v29, v8
     274:      	fmul.4s	v9, v28, v9
     278:      	fadd.4s	v9, v9, v20
     27c:      	fadd.4s	v8, v8, v20
     280:      	fmul.4s	v8, v29, v8
     284:      	fmul.4s	v9, v28, v9
     288:      	fadd.4s	v9, v9, v21
     28c:      	fadd.4s	v8, v8, v21
     290:      	fmul.4s	v8, v29, v8
     294:      	fmul.4s	v9, v28, v9
     298:      	fadd.4s	v9, v9, v24
     29c:      	fadd.4s	v8, v8, v24
     2a0:      	fmul.4s	v8, v29, v8
     2a4:      	fmul.4s	v9, v28, v9
     2a8:      	fadd.4s	v9, v9, v22
     2ac:      	fadd.4s	v8, v8, v22
     2b0:      	fmul.4s	v10, v28, v28
     2b4:      	fmul.4s	v11, v29, v29
     2b8:      	fmul.4s	v8, v11, v8
     2bc:      	fmul.4s	v9, v10, v9
     2c0:      	fadd.4s	v28, v28, v9
     2c4:      	fadd.4s	v29, v29, v8
     2c8:      	sshr.4s	v8, v31, #0x1
     2cc:      	fadd.4s	v29, v29, v2
     2d0:      	sshr.4s	v9, v30, #0x1
     2d4:      	shl.4s	v10, v9, #0x17
     2d8:      	shl.4s	v11, v8, #0x17
     2dc:      	add.4s	v11, v11, v2
     2e0:      	add.4s	v10, v10, v2
     2e4:      	fadd.4s	v28, v28, v2
     2e8:      	fmul.4s	v28, v28, v10
     2ec:      	sub.4s	v30, v30, v9
     2f0:      	sub.4s	v31, v31, v8
     2f4:      	shl.4s	v31, v31, #0x17
     2f8:      	shl.4s	v30, v30, #0x17
     2fc:      	fmul.4s	v29, v29, v11
     300:      	add.4s	v30, v30, v2
     304:      	add.4s	v31, v31, v2
     308:      	fmul.4s	v29, v29, v31
     30c:      	fmul.4s	v28, v28, v30
     310:      	fcmgt.4s	v30, v27, v3
     314:      	fcmgt.4s	v31, v26, v3
     318:      	fcmgt.4s	v8, v4, v26
     31c:      	fcmgt.4s	v9, v4, v27
     320:      	fcmeq.4s	v10, v27, v27
     324:      	fadd.4s	v28, v28, v2
     328:      	fadd.4s	v29, v29, v2
     32c:      	fcmeq.4s	v11, v26, v26
     330:      	bit.16b	v29, v2, v31
     334:      	bit.16b	v28, v2, v30
     338:      	bit.16b	v28, v23, v9
     33c:      	bit.16b	v29, v23, v8
     340:      	bif.16b	v29, v25, v11
     344:      	bif.16b	v28, v25, v10
     348:      	fdiv.4s	v27, v27, v28
     34c:      	fdiv.4s	v26, v26, v29
     350:      	add	x14, x13, x11
     354:      	ldp	q29, q28, [x14]
     358:      	fmul.4s	v26, v29, v26
     35c:      	fmul.4s	v27, v28, v27
     360:      	add	x14, x10, x11
     364:      	stp	q26, q27, [x14]
     368:      	add	x11, x11, #0x20
     36c:      	cmp	x11, #0x100
     370:      	b.ne	0x1d8 <ltmp0+0x1d8>
     374:      	movi.2d	v4, #0000000000000000
     378:      	movi.2d	v3, #0000000000000000
     37c:      	mov.s	v3[0], v1[0]
     380:      	fneg.4s	v1, v3
     384:      	mov.s	v4[0], v1[0]
     388:      	mov	w10, #-0x3d300000       ; =-1026555904
     38c:      	dup.4s	v1, w10
     390:      	fcmge.4s	v5, v4, v1
     394:      	mov	w10, #0x42c80000        ; =1120403456
     398:      	dup.4s	v6, w10
     39c:      	fcmge.4s	v7, v6, v4
     3a0:      	and.16b	v5, v5, v7
     3a4:      	and.16b	v5, v5, v4
     3a8:      	mov	w10, #0xaa3b            ; =43579
     3ac:      	movk	w10, #0x3fb8, lsl #16
     3b0:      	dup.4s	v7, w10
     3b4:      	fmul.4s	v7, v5, v7
     3b8:      	movi.4s	v16, #0x4b, lsl #24
     3bc:      	mvni.4s	v17, #0x80, lsl #24
     3c0:      	bif.16b	v16, v7, v17
     3c4:      	fadd.4s	v7, v7, v16
     3c8:      	fsub.4s	v7, v7, v16
     3cc:      	fcvtzs.4s	v7, v7
     3d0:      	scvtf.4s	v16, v7
     3d4:      	mov	w10, #0x7200            ; =29184
     3d8:      	movk	w10, #0xbf31, lsl #16
     3dc:      	dup.4s	v17, w10
     3e0:      	fmul.4s	v17, v16, v17
     3e4:      	mov	w10, #0xbe8e            ; =48782
     3e8:      	movk	w10, #0xb5bf, lsl #16
     3ec:      	dup.4s	v18, w10
     3f0:      	fadd.4s	v5, v5, v17
     3f4:      	fmul.4s	v16, v16, v18
     3f8:      	fadd.4s	v5, v5, v16
     3fc:      	mov	w10, #0x2bda            ; =11226
     400:      	movk	w10, #0x3950, lsl #16
     404:      	dup.4s	v16, w10
     408:      	fmul.4s	v16, v5, v16
     40c:      	mov	w10, #0x96c9            ; =38601
     410:      	movk	w10, #0x3ab6, lsl #16
     414:      	dup.4s	v17, w10
     418:      	fadd.4s	v16, v16, v17
     41c:      	fmul.4s	v16, v5, v16
     420:      	mov	w10, #0x88a6            ; =34982
     424:      	movk	w10, #0x3c08, lsl #16
     428:      	dup.4s	v17, w10
     42c:      	fadd.4s	v16, v16, v17
     430:      	fmul.4s	v16, v5, v16
     434:      	mov	w10, #0xaa7a            ; =43642
     438:      	movk	w10, #0x3d2a, lsl #16
     43c:      	dup.4s	v17, w10
     440:      	fadd.4s	v16, v16, v17
     444:      	mov	w10, #0xaaab            ; =43691
     448:      	movk	w10, #0x3e2a, lsl #16
     44c:      	dup.4s	v17, w10
     450:      	fmul.4s	v16, v5, v16
     454:      	fadd.4s	v16, v16, v17
     458:      	fmul.4s	v16, v5, v16
     45c:      	movi.4s	v17, #0x3f, lsl #24
     460:      	fadd.4s	v16, v16, v17
     464:      	fmul.4s	v17, v5, v5
     468:      	fmul.4s	v16, v17, v16
     46c:      	fadd.4s	v5, v5, v16
     470:      	fadd.4s	v5, v5, v2
     474:      	sshr.4s	v16, v7, #0x1
     478:      	shl.4s	v17, v16, #0x17
     47c:      	add.4s	v17, v17, v2
     480:      	fmul.4s	v5, v5, v17
     484:      	sub.4s	v7, v7, v16
     488:      	shl.4s	v7, v7, #0x17
     48c:      	add.4s	v7, v7, v2
     490:      	fmul.4s	v5, v5, v7
     494:      	fcmgt.4s	v1, v1, v4
     498:      	fcmgt.4s	v6, v4, v6
     49c:      	fcmeq.4s	v4, v4, v4
     4a0:      	fadd.4s	v5, v5, v2
     4a4:      	bsl.16b	v1, v2, v5
     4a8:      	mvni.4s	v2, #0x7f, msl #16
     4ac:      	fneg.4s	v2, v2
     4b0:      	bit.16b	v1, v2, v6
     4b4:      	mvni.4s	v2, #0x3f, msl #16
     4b8:      	fneg.4s	v2, v2
     4bc:      	bif.16b	v1, v2, v4
     4c0:      	fdiv.4s	v1, v3, v1
     4c4:      	b	0x858 <ltmp0+0x858>
     4c8:      	mov	x11, #0x0               ; =0
     4cc:      	add	x13, x8, x9
     4d0:      	add	x14, x10, x9
     4d4:      	mov	w15, #0x42d00000        ; =1120927744
     4d8:      	dup.4s	v1, w15
     4dc:      	mov	w15, #-0x3d380000       ; =-1027080192
     4e0:      	dup.4s	v2, w15
     4e4:      	mov	w15, #0xaa3b            ; =43579
     4e8:      	movk	w15, #0x3fb8, lsl #16
     4ec:      	dup.4s	v3, w15
     4f0:      	mov	w15, #0x7200            ; =29184
     4f4:      	movk	w15, #0xbf31, lsl #16
     4f8:      	dup.4s	v4, w15
     4fc:      	mov	w15, #0xbe8e            ; =48782
     500:      	movk	w15, #0xb5bf, lsl #16
     504:      	dup.4s	v5, w15
     508:      	mov	w15, #0x2bda            ; =11226
     50c:      	movk	w15, #0x3950, lsl #16
     510:      	dup.4s	v6, w15
     514:      	mov	w15, #0x96c9            ; =38601
     518:      	movk	w15, #0x3ab6, lsl #16
     51c:      	dup.4s	v7, w15
     520:      	mov	w15, #0x88a6            ; =34982
     524:      	movk	w15, #0x3c08, lsl #16
     528:      	dup.4s	v16, w15
     52c:      	mov	w15, #0xaa7a            ; =43642
     530:      	movk	w15, #0x3d2a, lsl #16
     534:      	dup.4s	v17, w15
     538:      	mov	w15, #0xaaab            ; =43691
     53c:      	movk	w15, #0x3e2a, lsl #16
     540:      	dup.4s	v18, w15
     544:      	add	x15, x12, x9
     548:      	movi.4s	v19, #0x4b, lsl #24
     54c:      	mvni.4s	v20, #0x80, lsl #24
     550:      	movi.4s	v21, #0x3f, lsl #24
     554:      	fmov.4s	v0, #1.00000000
     558:      	mvni.4s	v22, #0x7f, msl #16
     55c:      	fneg.4s	v22, v22
     560:      	mvni.4s	v23, #0x3f, msl #16
     564:      	fneg.4s	v23, v23
     568:      	add	x16, x15, x11
     56c:      	ldp	q24, q25, [x16]
     570:      	fneg.4s	v26, v25
     574:      	fneg.4s	v27, v24
     578:      	fcmge.4s	v28, v1, v24
     57c:      	fcmge.4s	v29, v1, v25
     580:      	fcmge.4s	v30, v24, v2
     584:      	fcmge.4s	v31, v25, v2
     588:      	and.16b	v29, v29, v31
     58c:      	and.16b	v28, v28, v30
     590:      	and.16b	v27, v28, v27
     594:      	and.16b	v26, v29, v26
     598:      	fmul.4s	v28, v26, v3
     59c:      	fmul.4s	v29, v27, v3
     5a0:      	mov.16b	v30, v20
     5a4:      	bsl.16b	v30, v19, v29
     5a8:      	mov.16b	v31, v20
     5ac:      	bsl.16b	v31, v19, v28
     5b0:      	fadd.4s	v28, v28, v31
     5b4:      	fadd.4s	v29, v29, v30
     5b8:      	fsub.4s	v29, v29, v30
     5bc:      	fsub.4s	v28, v28, v31
     5c0:      	fcvtzs.4s	v28, v28
     5c4:      	fcvtzs.4s	v29, v29
     5c8:      	scvtf.4s	v30, v29
     5cc:      	scvtf.4s	v31, v28
     5d0:      	fmul.4s	v8, v31, v4
     5d4:      	fmul.4s	v9, v30, v4
     5d8:      	fadd.4s	v27, v27, v9
     5dc:      	fadd.4s	v26, v26, v8
     5e0:      	fmul.4s	v30, v30, v5
     5e4:      	fmul.4s	v31, v31, v5
     5e8:      	fadd.4s	v26, v26, v31
     5ec:      	fadd.4s	v27, v27, v30
     5f0:      	fmul.4s	v30, v27, v6
     5f4:      	fmul.4s	v31, v26, v6
     5f8:      	fadd.4s	v31, v31, v7
     5fc:      	fadd.4s	v30, v30, v7
     600:      	fmul.4s	v30, v27, v30
     604:      	fmul.4s	v31, v26, v31
     608:      	fadd.4s	v31, v31, v16
     60c:      	fadd.4s	v30, v30, v16
     610:      	fmul.4s	v30, v27, v30
     614:      	fmul.4s	v31, v26, v31
     618:      	fadd.4s	v31, v31, v17
     61c:      	fadd.4s	v30, v30, v17
     620:      	fmul.4s	v30, v27, v30
     624:      	fmul.4s	v31, v26, v31
     628:      	fadd.4s	v31, v31, v18
     62c:      	fadd.4s	v30, v30, v18
     630:      	fmul.4s	v30, v27, v30
     634:      	fmul.4s	v31, v26, v31
     638:      	fadd.4s	v31, v31, v21
     63c:      	fadd.4s	v30, v30, v21
     640:      	fmul.4s	v8, v26, v26
     644:      	fmul.4s	v9, v27, v27
     648:      	fmul.4s	v30, v9, v30
     64c:      	fmul.4s	v31, v8, v31
     650:      	fadd.4s	v26, v26, v31
     654:      	fadd.4s	v27, v27, v30
     658:      	sshr.4s	v30, v29, #0x1
     65c:      	fadd.4s	v27, v27, v0
     660:      	sshr.4s	v31, v28, #0x1
     664:      	shl.4s	v8, v31, #0x17
     668:      	shl.4s	v9, v30, #0x17
     66c:      	add.4s	v9, v9, v0
     670:      	add.4s	v8, v8, v0
     674:      	fadd.4s	v26, v26, v0
     678:      	fmul.4s	v26, v26, v8
     67c:      	sub.4s	v28, v28, v31
     680:      	sub.4s	v29, v29, v30
     684:      	shl.4s	v29, v29, #0x17
     688:      	shl.4s	v28, v28, #0x17
     68c:      	fmul.4s	v27, v27, v9
     690:      	add.4s	v28, v28, v0
     694:      	add.4s	v29, v29, v0
     698:      	fmul.4s	v27, v27, v29
     69c:      	fmul.4s	v26, v26, v28
     6a0:      	fcmgt.4s	v28, v25, v1
     6a4:      	fcmgt.4s	v29, v24, v1
     6a8:      	fcmgt.4s	v30, v2, v24
     6ac:      	fcmgt.4s	v31, v2, v25
     6b0:      	fcmeq.4s	v8, v25, v25
     6b4:      	fadd.4s	v26, v26, v0
     6b8:      	fadd.4s	v27, v27, v0
     6bc:      	fcmeq.4s	v9, v24, v24
     6c0:      	bit.16b	v27, v0, v29
     6c4:      	bit.16b	v26, v0, v28
     6c8:      	bit.16b	v26, v22, v31
     6cc:      	bit.16b	v27, v22, v30
     6d0:      	bif.16b	v27, v23, v9
     6d4:      	bif.16b	v26, v23, v8
     6d8:      	fdiv.4s	v25, v25, v26
     6dc:      	fdiv.4s	v24, v24, v27
     6e0:      	add	x16, x14, x11
     6e4:      	ldp	q27, q26, [x16]
     6e8:      	fmul.4s	v24, v27, v24
     6ec:      	fmul.4s	v25, v26, v25
     6f0:      	add	x16, x13, x11
     6f4:      	stp	q24, q25, [x16]
     6f8:      	add	x11, x11, #0x20
     6fc:      	cmp	x11, #0x100
     700:      	b.ne	0x568 <ltmp0+0x568>
     704:      	add	x9, x9, #0x100
     708:      	ldr	s1, [x12, x9]
     70c:      	movi.2d	v2, #0000000000000000
     710:      	fneg.4s	v3, v1
     714:      	mov.s	v2[0], v3[0]
     718:      	mov	w11, #-0x3d300000       ; =-1026555904
     71c:      	dup.4s	v3, w11
     720:      	mov	w11, #0x42c80000        ; =1120403456
     724:      	dup.4s	v4, w11
     728:      	fcmge.4s	v5, v2, v3
     72c:      	fcmge.4s	v6, v4, v2
     730:      	and.16b	v5, v5, v6
     734:      	mov	w11, #0xaa3b            ; =43579
     738:      	movk	w11, #0x3fb8, lsl #16
     73c:      	dup.4s	v6, w11
     740:      	and.16b	v5, v5, v2
     744:      	fmul.4s	v6, v5, v6
     748:      	movi.4s	v7, #0x4b, lsl #24
     74c:      	mvni.4s	v16, #0x80, lsl #24
     750:      	bif.16b	v7, v6, v16
     754:      	fadd.4s	v6, v6, v7
     758:      	fsub.4s	v6, v6, v7
     75c:      	fcvtzs.4s	v6, v6
     760:      	scvtf.4s	v7, v6
     764:      	mov	w11, #0x7200            ; =29184
     768:      	movk	w11, #0xbf31, lsl #16
     76c:      	dup.4s	v16, w11
     770:      	fmul.4s	v16, v7, v16
     774:      	fadd.4s	v5, v5, v16
     778:      	mov	w11, #0xbe8e            ; =48782
     77c:      	movk	w11, #0xb5bf, lsl #16
     780:      	dup.4s	v16, w11
     784:      	fmul.4s	v7, v7, v16
     788:      	fadd.4s	v5, v5, v7
     78c:      	mov	w11, #0x2bda            ; =11226
     790:      	movk	w11, #0x3950, lsl #16
     794:      	dup.4s	v7, w11
     798:      	fmul.4s	v7, v5, v7
     79c:      	mov	w11, #0x96c9            ; =38601
     7a0:      	movk	w11, #0x3ab6, lsl #16
     7a4:      	dup.4s	v16, w11
     7a8:      	fadd.4s	v7, v7, v16
     7ac:      	mov	w11, #0x88a6            ; =34982
     7b0:      	movk	w11, #0x3c08, lsl #16
     7b4:      	dup.4s	v16, w11
     7b8:      	fmul.4s	v7, v5, v7
     7bc:      	fadd.4s	v7, v7, v16
     7c0:      	fmul.4s	v7, v5, v7
     7c4:      	mov	w11, #0xaa7a            ; =43642
     7c8:      	movk	w11, #0x3d2a, lsl #16
     7cc:      	dup.4s	v16, w11
     7d0:      	fadd.4s	v7, v7, v16
     7d4:      	fmul.4s	v7, v5, v7
     7d8:      	mov	w11, #0xaaab            ; =43691
     7dc:      	movk	w11, #0x3e2a, lsl #16
     7e0:      	dup.4s	v16, w11
     7e4:      	fadd.4s	v7, v7, v16
     7e8:      	fmul.4s	v7, v5, v7
     7ec:      	movi.4s	v16, #0x3f, lsl #24
     7f0:      	fadd.4s	v7, v7, v16
     7f4:      	fmul.4s	v16, v5, v5
     7f8:      	fmul.4s	v7, v16, v7
     7fc:      	fadd.4s	v5, v5, v7
     800:      	fadd.4s	v5, v5, v0
     804:      	sshr.4s	v7, v6, #0x1
     808:      	shl.4s	v16, v7, #0x17
     80c:      	add.4s	v16, v16, v0
     810:      	fmul.4s	v5, v5, v16
     814:      	sub.4s	v6, v6, v7
     818:      	shl.4s	v6, v6, #0x17
     81c:      	add.4s	v6, v6, v0
     820:      	fmul.4s	v5, v5, v6
     824:      	fcmgt.4s	v3, v3, v2
     828:      	fcmgt.4s	v4, v2, v4
     82c:      	fcmeq.4s	v2, v2, v2
     830:      	fadd.4s	v5, v5, v0
     834:      	bif.16b	v0, v5, v3
     838:      	mvni.4s	v3, #0x7f, msl #16
     83c:      	fneg.4s	v3, v3
     840:      	bit.16b	v0, v3, v4
     844:      	mvni.4s	v3, #0x3f, msl #16
     848:      	fneg.4s	v3, v3
     84c:      	bif.16b	v0, v3, v2
     850:      	fdiv.4s	v0, v1, v0
     854:      	ldr	s1, [x10, x9]
     858:      	fmul.4s	v0, v1, v0
     85c:      	str	s0, [x8, x9]
     860:      	add	sp, sp, #0x240
     864:      	ldp	x28, x27, [sp, #0x20]
     868:      	ldp	d9, d8, [sp, #0x10]
     86c:      	ldp	d11, d10, [sp], #0x30
     870:      	ret

0000000000000874 <_llm_rows.packet_batch.blocks>:
     874:      	stp	d15, d14, [sp, #-0xa0]!
     878:      	stp	d13, d12, [sp, #0x10]
     87c:      	stp	d11, d10, [sp, #0x20]
     880:      	stp	d9, d8, [sp, #0x30]
     884:      	stp	x28, x27, [sp, #0x40]
     888:      	stp	x26, x25, [sp, #0x50]
     88c:      	stp	x24, x23, [sp, #0x60]
     890:      	stp	x22, x21, [sp, #0x70]
     894:      	stp	x20, x19, [sp, #0x80]
     898:      	stp	x29, x30, [sp, #0x90]
     89c:      	sub	sp, sp, #0x4d0
     8a0:      	str	x0, [sp, #0xf8]
     8a4:      	cbz	w3, 0x1cd8 <_llm_rows.packet_batch.blocks+0x1464>
     8a8:      	mov	x19, x3
     8ac:      	mov	x20, x2
     8b0:      	mov	w22, #0x0               ; =0
     8b4:      	ldp	w9, w8, [x2, #0x2c]
     8b8:      	stp	w8, w9, [sp, #0xd8]
     8bc:      	ldp	w26, w27, [x2]
     8c0:      	adrp	x8, 0x0 <ltmp0>
     8c4:      	ldr	q0, [x8]
     8c8:      	str	q0, [sp, #0xc0]
     8cc:      	adrp	x8, 0x0 <ltmp0>
     8d0:      	ldr	q0, [x8]
     8d4:      	str	q0, [sp, #0xb0]
     8d8:      	adrp	x8, 0x0 <ltmp0>
     8dc:      	ldr	q0, [x8]
     8e0:      	str	q0, [sp, #0xa0]
     8e4:      	adrp	x8, 0x0 <ltmp0>
     8e8:      	ldr	q0, [x8]
     8ec:      	str	q0, [sp, #0x90]
     8f0:      	adrp	x8, 0x0 <ltmp0>
     8f4:      	ldr	q0, [x8]
     8f8:      	str	q0, [sp, #0x80]
     8fc:      	adrp	x8, 0x0 <ltmp0>
     900:      	ldr	q0, [x8]
     904:      	str	q0, [sp, #0x70]
     908:      	adrp	x8, 0x0 <ltmp0>
     90c:      	ldr	q15, [x8]
     910:      	mvni.4s	v0, #0x7f, msl #16
     914:      	fneg.4s	v1, v0
     918:      	mvni.4s	v0, #0x3f, msl #16
     91c:      	fneg.4s	v0, v0
     920:      	stp	q0, q1, [sp, #0x100]
     924:      	add	x25, sp, #0x3b0
     928:      	ldp	w28, w23, [x2, #0x8]
     92c:      	add	x24, sp, #0x290
     930:      	str	q15, [sp, #0xe0]
     934:      	str	w3, [sp, #0xd4]
     938:      	b	0x980 <_llm_rows.packet_batch.blocks+0x10c>
     93c:      	mov	w8, #0x18               ; =24
     940:      	str	w8, [x20, #0x24]
     944:      	ldr	w19, [sp, #0xd4]
     948:      	add	w8, w26, #0x1
     94c:      	ldp	w10, w9, [sp, #0xd8]
     950:      	cmp	w8, w9
     954:      	cset	w8, eq
     958:      	csinc	w26, wzr, w26, eq
     95c:      	cinc	w9, w27, eq
     960:      	cmp	w9, w10
     964:      	cset	w10, eq
     968:      	ands	w8, w8, w10
     96c:      	csel	w27, wzr, w9, ne
     970:      	add	w28, w28, w8
     974:      	add	w22, w22, #0x1
     978:      	cmp	w22, w19
     97c:      	b.eq	0x1cd8 <_llm_rows.packet_batch.blocks+0x1464>
     980:      	ubfiz	x8, x26, #5, #32
     984:      	cmp	x8, x23
     988:      	csel	x9, x8, xzr, ls
     98c:      	subs	x10, x23, x9
     990:      	cmp	x10, #0x20
     994:      	mov	w11, #0x20              ; =32
     998:      	csel	x10, x10, x11, lo
     99c:      	cmp	x23, x9
     9a0:      	stp	w26, w27, [x20]
     9a4:      	str	w28, [x20, #0x8]
     9a8:      	str	wzr, [x20, #0x24]
     9ac:      	ccmp	x8, x23, #0x2, hi
     9b0:      	csel	x21, x10, xzr, ls
     9b4:      	cmp	x21, #0x20
     9b8:      	b.lo	0xa10 <_llm_rows.packet_batch.blocks+0x19c>
     9bc:      	ldr	x21, [sp, #0xf8]
     9c0:      	mov	x0, x21
     9c4:      	mov	x1, x20
     9c8:      	bl	0x9c8 <_llm_rows.packet_batch.blocks+0x154>
     9cc:      	mov	w8, #0x8                ; =8
     9d0:      	str	w8, [x20, #0x24]
     9d4:      	mov	x0, x21
     9d8:      	mov	x1, x20
     9dc:      	bl	0x9dc <_llm_rows.packet_batch.blocks+0x168>
     9e0:      	mov	w8, #0x10               ; =16
     9e4:      	str	w8, [x20, #0x24]
     9e8:      	mov	x0, x21
     9ec:      	mov	x1, x20
     9f0:      	bl	0x9f0 <_llm_rows.packet_batch.blocks+0x17c>
     9f4:      	mov	w8, #0x18               ; =24
     9f8:      	str	w8, [x20, #0x24]
     9fc:      	mov	x0, x21
     a00:      	mov	x1, x20
     a04:      	bl	0xa04 <_llm_rows.packet_batch.blocks+0x190>
     a08:      	ldr	q15, [sp, #0xe0]
     a0c:      	b	0x948 <_llm_rows.packet_batch.blocks+0xd4>
     a10:      	lsr	x19, x21, #3
     a14:      	cmp	x21, #0x8
     a18:      	b.lo	0xa70 <_llm_rows.packet_batch.blocks+0x1fc>
     a1c:      	str	wzr, [x20, #0x24]
     a20:      	ldr	x0, [sp, #0xf8]
     a24:      	mov	x1, x20
     a28:      	bl	0xa28 <_llm_rows.packet_batch.blocks+0x1b4>
     a2c:      	ldr	q15, [sp, #0xe0]
     a30:      	cmp	x19, #0x1
     a34:      	b.eq	0xa70 <_llm_rows.packet_batch.blocks+0x1fc>
     a38:      	mov	w8, #0x8                ; =8
     a3c:      	str	w8, [x20, #0x24]
     a40:      	ldr	x0, [sp, #0xf8]
     a44:      	mov	x1, x20
     a48:      	bl	0xa48 <_llm_rows.packet_batch.blocks+0x1d4>
     a4c:      	ldr	q15, [sp, #0xe0]
     a50:      	cmp	x19, #0x2
     a54:      	b.eq	0xa70 <_llm_rows.packet_batch.blocks+0x1fc>
     a58:      	mov	w8, #0x10               ; =16
     a5c:      	str	w8, [x20, #0x24]
     a60:      	ldr	x0, [sp, #0xf8]
     a64:      	mov	x1, x20
     a68:      	bl	0xa68 <_llm_rows.packet_batch.blocks+0x1f4>
     a6c:      	ldr	q15, [sp, #0xe0]
     a70:      	and	w8, w21, #0x7
     a74:      	cbz	w8, 0x93c <_llm_rows.packet_batch.blocks+0xc8>
     a78:      	dup.4s	v0, w8
     a7c:      	ldp	q2, q1, [sp, #0xb0]
     a80:      	cmhi.4s	v20, v0, v2
     a84:      	cmhi.4s	v19, v0, v1
     a88:      	uzp1.8h	v29, v19, v20
     a8c:      	umaxv.8h	h0, v29
     a90:      	fmov	w8, s0
     a94:      	tbz	w8, #0x0, 0x93c <_llm_rows.packet_batch.blocks+0xc8>
     a98:      	ldr	x8, [sp, #0xf8]
     a9c:      	ldr	x11, [x8]
     aa0:      	ldr	x9, [x8, #0x10]
     aa4:      	ldr	x8, [x8, #0x30]
     aa8:      	sshll.2d	v0, v19, #0x0
     aac:      	sshll.2d	v1, v20, #0x0
     ab0:      	sshll2.2d	v11, v19, #0x0
     ab4:      	sshll2.2d	v10, v20, #0x0
     ab8:      	ldp	q2, q3, [sp, #0x90]
     abc:      	and.16b	v21, v10, v3
     ac0:      	and.16b	v23, v11, v2
     ac4:      	ldr	q2, [sp, #0x80]
     ac8:      	and.16b	v22, v1, v2
     acc:      	ldr	q1, [sp, #0x70]
     ad0:      	and.16b	v28, v0, v1
     ad4:      	ubfiz	w10, w26, #2, #27
     ad8:      	orr	w10, w10, w19
     adc:      	dup.4s	v0, w10
     ae0:      	and.16b	v1, v19, v0
     ae4:      	and.16b	v0, v20, v0
     ae8:      	ushll2.2d	v24, v0, #0x0
     aec:      	ushll2.2d	v26, v1, #0x0
     af0:      	ushll.2d	v25, v0, #0x0
     af4:      	ushll.2d	v0, v1, #0x0
     af8:      	subs	x10, x11, x8
     afc:      	lsr	x10, x10, #2
     b00:      	mov	w14, #0x450             ; =1104
     b04:      	ccmp	x10, x14, #0x0, hs
     b08:      	cset	w10, hi
     b0c:      	subs	x12, x8, x11
     b10:      	lsr	x12, x12, #2
     b14:      	ccmp	x12, x14, #0x0, hs
     b18:      	csinc	w12, w10, wzr, ls
     b1c:      	subs	x10, x9, x8
     b20:      	lsr	x10, x10, #2
     b24:      	ccmp	x10, x14, #0x0, hs
     b28:      	cset	w10, hi
     b2c:      	subs	x13, x8, x9
     b30:      	lsr	x13, x13, #2
     b34:      	ccmp	x13, x14, #0x0, hs
     b38:      	csinc	w10, w10, wzr, ls
     b3c:      	xtn.2s	v30, v0
     b40:      	fmov	x13, d0
     b44:      	add	x13, x13, x13, lsl #6
     b48:      	mov	w14, #-0x3d300000       ; =-1026555904
     b4c:      	dup.4s	v1, w14
     b50:      	mov	w14, #0x42c80000        ; =1120403456
     b54:      	dup.4s	v0, w14
     b58:      	mov	w14, #0xaa3b            ; =43579
     b5c:      	movk	w14, #0x3fb8, lsl #16
     b60:      	dup.4s	v18, w14
     b64:      	mov	w14, #0x7200            ; =29184
     b68:      	movk	w14, #0xbf31, lsl #16
     b6c:      	dup.4s	v17, w14
     b70:      	mov	w14, #0xbe8e            ; =48782
     b74:      	movk	w14, #0xb5bf, lsl #16
     b78:      	dup.4s	v16, w14
     b7c:      	mov	w14, #0x2bda            ; =11226
     b80:      	movk	w14, #0x3950, lsl #16
     b84:      	dup.4s	v7, w14
     b88:      	mov	w14, #0x96c9            ; =38601
     b8c:      	movk	w14, #0x3ab6, lsl #16
     b90:      	dup.4s	v6, w14
     b94:      	mov	w14, #0x88a6            ; =34982
     b98:      	movk	w14, #0x3c08, lsl #16
     b9c:      	dup.4s	v5, w14
     ba0:      	mov	w14, #0xaa7a            ; =43642
     ba4:      	movk	w14, #0x3d2a, lsl #16
     ba8:      	dup.4s	v4, w14
     bac:      	mov	w14, #0xaaab            ; =43691
     bb0:      	movk	w14, #0x3e2a, lsl #16
     bb4:      	dup.4s	v3, w14
     bb8:      	lsl	x14, x13, #2
     bbc:      	fmov.4s	v2, #1.00000000
     bc0:      	xtn.2s	v24, v24
     bc4:      	xtn.2s	v25, v25
     bc8:      	xtn.2s	v26, v26
     bcc:      	cmp	w12, #0x1
     bd0:      	b.ne	0xf64 <_llm_rows.packet_batch.blocks+0x6f0>
     bd4:      	cbz	w10, 0xf64 <_llm_rows.packet_batch.blocks+0x6f0>
     bd8:      	mov	x10, #0x0               ; =0
     bdc:      	add	x12, x8, x14
     be0:      	add	x13, x9, x14
     be4:      	add	x14, x11, x14
     be8:      	and.16b	v27, v29, v15
     bec:      	addv.8h	h27, v27
     bf0:      	fmov	w15, s27
     bf4:      	b	0xc04 <_llm_rows.packet_batch.blocks+0x390>
     bf8:      	add	x10, x10, #0x20
     bfc:      	cmp	x10, #0x100
     c00:      	b.eq	0x18d4 <_llm_rows.packet_batch.blocks+0x1060>
     c04:      	add	x16, x14, x10
     c08:      	movi.2d	v31, #0000000000000000
     c0c:      	movi.2d	v29, #0000000000000000
     c10:      	tbz	w15, #0x0, 0xca4 <_llm_rows.packet_batch.blocks+0x430>
     c14:      	ldr	s31, [x16]
     c18:      	and	w17, w15, #0xff
     c1c:      	tbnz	w17, #0x1, 0xcac <_llm_rows.packet_batch.blocks+0x438>
     c20:      	tbz	w17, #0x2, 0xcb8 <_llm_rows.packet_batch.blocks+0x444>
     c24:      	add	x0, x16, #0x8
     c28:      	ld1.s	{ v31 }[2], [x0]
     c2c:      	tbnz	w17, #0x3, 0xcbc <_llm_rows.packet_batch.blocks+0x448>
     c30:      	tbz	w17, #0x4, 0xcc8 <_llm_rows.packet_batch.blocks+0x454>
     c34:      	add	x0, x16, #0x10
     c38:      	ld1.s	{ v29 }[0], [x0]
     c3c:      	tbnz	w17, #0x5, 0xccc <_llm_rows.packet_batch.blocks+0x458>
     c40:      	tbz	w17, #0x6, 0xcd8 <_llm_rows.packet_batch.blocks+0x464>
     c44:      	add	x0, x16, #0x18
     c48:      	ld1.s	{ v29 }[2], [x0]
     c4c:      	tbnz	w17, #0x7, 0xcdc <_llm_rows.packet_batch.blocks+0x468>
     c50:      	fmov	w17, s27
     c54:      	add	x16, x13, x10
     c58:      	movi.2d	v8, #0000000000000000
     c5c:      	movi.2d	v9, #0000000000000000
     c60:      	tbz	w17, #0x0, 0xcf8 <_llm_rows.packet_batch.blocks+0x484>
     c64:      	ldr	s8, [x16]
     c68:      	and	w17, w17, #0xff
     c6c:      	tbnz	w17, #0x1, 0xd00 <_llm_rows.packet_batch.blocks+0x48c>
     c70:      	tbz	w17, #0x2, 0xd0c <_llm_rows.packet_batch.blocks+0x498>
     c74:      	add	x0, x16, #0x8
     c78:      	ld1.s	{ v8 }[2], [x0]
     c7c:      	tbnz	w17, #0x3, 0xd10 <_llm_rows.packet_batch.blocks+0x49c>
     c80:      	tbz	w17, #0x4, 0xd1c <_llm_rows.packet_batch.blocks+0x4a8>
     c84:      	add	x0, x16, #0x10
     c88:      	ld1.s	{ v9 }[0], [x0]
     c8c:      	tbnz	w17, #0x5, 0xd20 <_llm_rows.packet_batch.blocks+0x4ac>
     c90:      	tbz	w17, #0x6, 0xd2c <_llm_rows.packet_batch.blocks+0x4b8>
     c94:      	add	x0, x16, #0x18
     c98:      	ld1.s	{ v9 }[2], [x0]
     c9c:      	tbnz	w17, #0x7, 0xd30 <_llm_rows.packet_batch.blocks+0x4bc>
     ca0:      	b	0xd38 <_llm_rows.packet_batch.blocks+0x4c4>
     ca4:      	and	w17, w15, #0xff
     ca8:      	tbz	w17, #0x1, 0xc20 <_llm_rows.packet_batch.blocks+0x3ac>
     cac:      	add	x0, x16, #0x4
     cb0:      	ld1.s	{ v31 }[1], [x0]
     cb4:      	tbnz	w17, #0x2, 0xc24 <_llm_rows.packet_batch.blocks+0x3b0>
     cb8:      	tbz	w17, #0x3, 0xc30 <_llm_rows.packet_batch.blocks+0x3bc>
     cbc:      	add	x0, x16, #0xc
     cc0:      	ld1.s	{ v31 }[3], [x0]
     cc4:      	tbnz	w17, #0x4, 0xc34 <_llm_rows.packet_batch.blocks+0x3c0>
     cc8:      	tbz	w17, #0x5, 0xc40 <_llm_rows.packet_batch.blocks+0x3cc>
     ccc:      	add	x0, x16, #0x14
     cd0:      	ld1.s	{ v29 }[1], [x0]
     cd4:      	tbnz	w17, #0x6, 0xc44 <_llm_rows.packet_batch.blocks+0x3d0>
     cd8:      	tbz	w17, #0x7, 0xc50 <_llm_rows.packet_batch.blocks+0x3dc>
     cdc:      	add	x16, x16, #0x1c
     ce0:      	ld1.s	{ v29 }[3], [x16]
     ce4:      	fmov	w17, s27
     ce8:      	add	x16, x13, x10
     cec:      	movi.2d	v8, #0000000000000000
     cf0:      	movi.2d	v9, #0000000000000000
     cf4:      	tbnz	w17, #0x0, 0xc64 <_llm_rows.packet_batch.blocks+0x3f0>
     cf8:      	and	w17, w17, #0xff
     cfc:      	tbz	w17, #0x1, 0xc70 <_llm_rows.packet_batch.blocks+0x3fc>
     d00:      	add	x0, x16, #0x4
     d04:      	ld1.s	{ v8 }[1], [x0]
     d08:      	tbnz	w17, #0x2, 0xc74 <_llm_rows.packet_batch.blocks+0x400>
     d0c:      	tbz	w17, #0x3, 0xc80 <_llm_rows.packet_batch.blocks+0x40c>
     d10:      	add	x0, x16, #0xc
     d14:      	ld1.s	{ v8 }[3], [x0]
     d18:      	tbnz	w17, #0x4, 0xc84 <_llm_rows.packet_batch.blocks+0x410>
     d1c:      	tbz	w17, #0x5, 0xc90 <_llm_rows.packet_batch.blocks+0x41c>
     d20:      	add	x0, x16, #0x14
     d24:      	ld1.s	{ v9 }[1], [x0]
     d28:      	tbnz	w17, #0x6, 0xc94 <_llm_rows.packet_batch.blocks+0x420>
     d2c:      	tbz	w17, #0x7, 0xd38 <_llm_rows.packet_batch.blocks+0x4c4>
     d30:      	add	x16, x16, #0x1c
     d34:      	ld1.s	{ v9 }[3], [x16]
     d38:      	fneg.4s	v10, v31
     d3c:      	and.16b	v10, v19, v10
     d40:      	fcmge.4s	v11, v10, v1
     d44:      	fcmge.4s	v12, v0, v10
     d48:      	and.16b	v11, v11, v12
     d4c:      	and.16b	v11, v11, v10
     d50:      	fmul.4s	v12, v11, v18
     d54:      	movi.4s	v13, #0x4b, lsl #24
     d58:      	mvni.4s	v14, #0x80, lsl #24
     d5c:      	bif.16b	v13, v12, v14
     d60:      	fadd.4s	v12, v12, v13
     d64:      	fsub.4s	v12, v12, v13
     d68:      	fcvtzs.4s	v12, v12
     d6c:      	scvtf.4s	v13, v12
     d70:      	fmul.4s	v14, v13, v17
     d74:      	fadd.4s	v11, v11, v14
     d78:      	fmul.4s	v13, v13, v16
     d7c:      	fadd.4s	v11, v11, v13
     d80:      	fmul.4s	v13, v11, v7
     d84:      	fadd.4s	v13, v13, v6
     d88:      	fmul.4s	v13, v11, v13
     d8c:      	fadd.4s	v13, v13, v5
     d90:      	fmul.4s	v13, v11, v13
     d94:      	fadd.4s	v13, v13, v4
     d98:      	fmul.4s	v13, v11, v13
     d9c:      	fadd.4s	v13, v13, v3
     da0:      	fmul.4s	v13, v11, v13
     da4:      	movi.4s	v14, #0x3f, lsl #24
     da8:      	fadd.4s	v13, v13, v14
     dac:      	fmul.4s	v14, v11, v11
     db0:      	fmul.4s	v13, v14, v13
     db4:      	fadd.4s	v11, v11, v13
     db8:      	fadd.4s	v11, v11, v2
     dbc:      	sshr.4s	v13, v12, #0x1
     dc0:      	shl.4s	v14, v13, #0x17
     dc4:      	add.4s	v14, v14, v2
     dc8:      	fmul.4s	v11, v11, v14
     dcc:      	sub.4s	v12, v12, v13
     dd0:      	shl.4s	v12, v12, #0x17
     dd4:      	add.4s	v12, v12, v2
     dd8:      	fmul.4s	v11, v11, v12
     ddc:      	fcmgt.4s	v12, v1, v10
     de0:      	fcmgt.4s	v13, v10, v0
     de4:      	fcmeq.4s	v10, v10, v10
     de8:      	fadd.4s	v11, v11, v2
     dec:      	bit.16b	v11, v2, v12
     df0:      	ldr	q12, [sp, #0x110]
     df4:      	bit.16b	v11, v12, v13
     df8:      	ldr	q12, [sp, #0x100]
     dfc:      	bsl.16b	v10, v11, v12
     e00:      	fdiv.4s	v31, v31, v10
     e04:      	fmov	w17, s27
     e08:      	fmul.4s	v31, v8, v31
     e0c:      	add	x16, x12, x10
     e10:      	tbz	w17, #0x0, 0xe34 <_llm_rows.packet_batch.blocks+0x5c0>
     e14:      	str	s31, [x16]
     e18:      	and	w17, w17, #0xff
     e1c:      	tbnz	w17, #0x1, 0xe3c <_llm_rows.packet_batch.blocks+0x5c8>
     e20:      	tbz	w17, #0x2, 0xe48 <_llm_rows.packet_batch.blocks+0x5d4>
     e24:      	add	x0, x16, #0x8
     e28:      	st1.s	{ v31 }[2], [x0]
     e2c:      	tbnz	w17, #0x3, 0xe4c <_llm_rows.packet_batch.blocks+0x5d8>
     e30:      	b	0xe54 <_llm_rows.packet_batch.blocks+0x5e0>
     e34:      	and	w17, w17, #0xff
     e38:      	tbz	w17, #0x1, 0xe20 <_llm_rows.packet_batch.blocks+0x5ac>
     e3c:      	add	x0, x16, #0x4
     e40:      	st1.s	{ v31 }[1], [x0]
     e44:      	tbnz	w17, #0x2, 0xe24 <_llm_rows.packet_batch.blocks+0x5b0>
     e48:      	tbz	w17, #0x3, 0xe54 <_llm_rows.packet_batch.blocks+0x5e0>
     e4c:      	add	x0, x16, #0xc
     e50:      	st1.s	{ v31 }[3], [x0]
     e54:      	fneg.4s	v31, v29
     e58:      	and.16b	v31, v20, v31
     e5c:      	fcmge.4s	v8, v31, v1
     e60:      	fcmge.4s	v10, v0, v31
     e64:      	and.16b	v8, v8, v10
     e68:      	and.16b	v8, v8, v31
     e6c:      	fmul.4s	v10, v8, v18
     e70:      	movi.4s	v11, #0x4b, lsl #24
     e74:      	mvni.4s	v12, #0x80, lsl #24
     e78:      	bif.16b	v11, v10, v12
     e7c:      	fadd.4s	v10, v10, v11
     e80:      	fsub.4s	v10, v10, v11
     e84:      	fcvtzs.4s	v10, v10
     e88:      	scvtf.4s	v11, v10
     e8c:      	fmul.4s	v12, v11, v17
     e90:      	fadd.4s	v8, v8, v12
     e94:      	fmul.4s	v11, v11, v16
     e98:      	fadd.4s	v8, v8, v11
     e9c:      	fmul.4s	v11, v8, v7
     ea0:      	fadd.4s	v11, v11, v6
     ea4:      	fmul.4s	v11, v8, v11
     ea8:      	fadd.4s	v11, v11, v5
     eac:      	fmul.4s	v11, v8, v11
     eb0:      	fadd.4s	v11, v11, v4
     eb4:      	fmul.4s	v11, v8, v11
     eb8:      	fadd.4s	v11, v11, v3
     ebc:      	fmul.4s	v11, v8, v11
     ec0:      	movi.4s	v12, #0x3f, lsl #24
     ec4:      	fadd.4s	v11, v11, v12
     ec8:      	fmul.4s	v12, v8, v8
     ecc:      	fmul.4s	v11, v12, v11
     ed0:      	fadd.4s	v8, v8, v11
     ed4:      	fadd.4s	v8, v8, v2
     ed8:      	sshr.4s	v11, v10, #0x1
     edc:      	shl.4s	v12, v11, #0x17
     ee0:      	add.4s	v12, v12, v2
     ee4:      	fmul.4s	v8, v8, v12
     ee8:      	sub.4s	v10, v10, v11
     eec:      	shl.4s	v10, v10, #0x17
     ef0:      	add.4s	v10, v10, v2
     ef4:      	fmul.4s	v8, v8, v10
     ef8:      	fcmgt.4s	v10, v1, v31
     efc:      	fcmgt.4s	v11, v31, v0
     f00:      	fcmeq.4s	v31, v31, v31
     f04:      	fadd.4s	v8, v8, v2
     f08:      	bit.16b	v8, v2, v10
     f0c:      	ldr	q10, [sp, #0x110]
     f10:      	bit.16b	v8, v10, v11
     f14:      	ldr	q10, [sp, #0x100]
     f18:      	bsl.16b	v31, v8, v10
     f1c:      	fdiv.4s	v29, v29, v31
     f20:      	fmul.4s	v29, v9, v29
     f24:      	tbz	w17, #0x4, 0xf44 <_llm_rows.packet_batch.blocks+0x6d0>
     f28:      	str	s29, [x16, #0x10]
     f2c:      	tbnz	w17, #0x5, 0xf48 <_llm_rows.packet_batch.blocks+0x6d4>
     f30:      	tbz	w17, #0x6, 0xf54 <_llm_rows.packet_batch.blocks+0x6e0>
     f34:      	add	x0, x16, #0x18
     f38:      	st1.s	{ v29 }[2], [x0]
     f3c:      	tbz	w17, #0x7, 0xbf8 <_llm_rows.packet_batch.blocks+0x384>
     f40:      	b	0xf58 <_llm_rows.packet_batch.blocks+0x6e4>
     f44:      	tbz	w17, #0x5, 0xf30 <_llm_rows.packet_batch.blocks+0x6bc>
     f48:      	add	x0, x16, #0x14
     f4c:      	st1.s	{ v29 }[1], [x0]
     f50:      	tbnz	w17, #0x6, 0xf34 <_llm_rows.packet_batch.blocks+0x6c0>
     f54:      	tbz	w17, #0x7, 0xbf8 <_llm_rows.packet_batch.blocks+0x384>
     f58:      	add	x16, x16, #0x1c
     f5c:      	st1.s	{ v29 }[3], [x16]
     f60:      	b	0xbf8 <_llm_rows.packet_batch.blocks+0x384>
     f64:      	mov	x10, #0x0               ; =0
     f68:      	add	x12, x11, x14
     f6c:      	b	0xf90 <_llm_rows.packet_batch.blocks+0x71c>
     f70:      	add	x13, x25, x10
     f74:      	ldp	q9, q12, [x13]
     f78:      	bif.16b	v8, v12, v20
     f7c:      	bif.16b	v31, v9, v19
     f80:      	stp	q31, q8, [x13]
     f84:      	add	x10, x10, #0x20
     f88:      	cmp	x10, #0x100
     f8c:      	b.eq	0x1030 <_llm_rows.packet_batch.blocks+0x7bc>
     f90:      	and.16b	v27, v29, v15
     f94:      	addv.8h	h27, v27
     f98:      	fmov	w14, s27
     f9c:      	add	x13, x12, x10
     fa0:      	movi.2d	v31, #0000000000000000
     fa4:      	movi.2d	v8, #0000000000000000
     fa8:      	tbz	w14, #0x0, 0xfec <_llm_rows.packet_batch.blocks+0x778>
     fac:      	ldr	s31, [x13]
     fb0:      	and	w14, w14, #0xff
     fb4:      	tbnz	w14, #0x1, 0xff4 <_llm_rows.packet_batch.blocks+0x780>
     fb8:      	tbz	w14, #0x2, 0x1000 <_llm_rows.packet_batch.blocks+0x78c>
     fbc:      	add	x15, x13, #0x8
     fc0:      	ld1.s	{ v31 }[2], [x15]
     fc4:      	tbnz	w14, #0x3, 0x1004 <_llm_rows.packet_batch.blocks+0x790>
     fc8:      	tbz	w14, #0x4, 0x1010 <_llm_rows.packet_batch.blocks+0x79c>
     fcc:      	add	x15, x13, #0x10
     fd0:      	ld1.s	{ v8 }[0], [x15]
     fd4:      	tbnz	w14, #0x5, 0x1014 <_llm_rows.packet_batch.blocks+0x7a0>
     fd8:      	tbz	w14, #0x6, 0x1020 <_llm_rows.packet_batch.blocks+0x7ac>
     fdc:      	add	x15, x13, #0x18
     fe0:      	ld1.s	{ v8 }[2], [x15]
     fe4:      	tbz	w14, #0x7, 0xf70 <_llm_rows.packet_batch.blocks+0x6fc>
     fe8:      	b	0x1024 <_llm_rows.packet_batch.blocks+0x7b0>
     fec:      	and	w14, w14, #0xff
     ff0:      	tbz	w14, #0x1, 0xfb8 <_llm_rows.packet_batch.blocks+0x744>
     ff4:      	add	x15, x13, #0x4
     ff8:      	ld1.s	{ v31 }[1], [x15]
     ffc:      	tbnz	w14, #0x2, 0xfbc <_llm_rows.packet_batch.blocks+0x748>
    1000:      	tbz	w14, #0x3, 0xfc8 <_llm_rows.packet_batch.blocks+0x754>
    1004:      	add	x15, x13, #0xc
    1008:      	ld1.s	{ v31 }[3], [x15]
    100c:      	tbnz	w14, #0x4, 0xfcc <_llm_rows.packet_batch.blocks+0x758>
    1010:      	tbz	w14, #0x5, 0xfd8 <_llm_rows.packet_batch.blocks+0x764>
    1014:      	add	x15, x13, #0x14
    1018:      	ld1.s	{ v8 }[1], [x15]
    101c:      	tbnz	w14, #0x6, 0xfdc <_llm_rows.packet_batch.blocks+0x768>
    1020:      	tbz	w14, #0x7, 0xf70 <_llm_rows.packet_batch.blocks+0x6fc>
    1024:      	add	x13, x13, #0x1c
    1028:      	ld1.s	{ v8 }[3], [x13]
    102c:      	b	0xf70 <_llm_rows.packet_batch.blocks+0x6fc>
    1030:      	xtn.4h	v29, v19
    1034:      	uzp1.8b	v31, v29, v0
    1038:      	movi.2d	v29, #0000000000000000
    103c:      	mov.b	v29[0], v31[0]
    1040:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x78c>
    1044:      	ldr	d12, [x10]
    1048:      	and.8b	v8, v29, v12
    104c:      	addv.8b	b8, v8
    1050:      	fmov	w13, s8
    1054:      	umaxv.8b	b8, v29
    1058:      	fmov	w14, s8
    105c:      	rbit	w10, w13
    1060:      	clz	w10, w10
    1064:      	tst	w14, #0x1
    1068:      	csel	w10, w10, wzr, ne
    106c:      	mov	w12, #0x40              ; =64
    1070:      	dup.2d	v8, x12
    1074:      	movi.2s	v9, #0x41
    1078:      	umlal.2d	v28, v30, v9
    107c:      	movi.2d	v9, #0000000000000000
    1080:      	mov.b	v9[0], v31[0]
    1084:      	add.2d	v31, v28, v8
    1088:      	ushll.2d	v28, v9, #0x0
    108c:      	shl.2d	v28, v28, #0x3f
    1090:      	cmlt.2d	v28, v28, #0
    1094:      	str	q31, [sp, #0x50]
    1098:      	and.16b	v28, v28, v31
    109c:      	movi.2d	v31, #0000000000000000
    10a0:      	stp	q31, q31, [sp, #0x260]
    10a4:      	stp	q28, q31, [sp, #0x240]
    10a8:      	and	x12, x10, #0x7
    10ac:      	add	x15, sp, #0x240
    10b0:      	ldr	x12, [x15, x12, lsl #3]
    10b4:      	sub	x12, x12, x10
    10b8:      	lsl	x12, x12, #2
    10bc:      	add	x11, x11, x12
    10c0:      	movi.2d	v9, #0000000000000000
    10c4:      	tbz	w14, #0x0, 0x1104 <_llm_rows.packet_batch.blocks+0x890>
    10c8:      	ldr	s9, [x11]
    10cc:      	tbnz	w13, #0x1, 0x1108 <_llm_rows.packet_batch.blocks+0x894>
    10d0:      	tbz	w13, #0x2, 0x1114 <_llm_rows.packet_batch.blocks+0x8a0>
    10d4:      	add	x14, x11, #0x8
    10d8:      	ld1.s	{ v9 }[2], [x14]
    10dc:      	tbnz	w13, #0x3, 0x1118 <_llm_rows.packet_batch.blocks+0x8a4>
    10e0:      	tbz	w13, #0x4, 0x1124 <_llm_rows.packet_batch.blocks+0x8b0>
    10e4:      	add	x14, x11, #0x10
    10e8:      	ld1.s	{ v31 }[0], [x14]
    10ec:      	tbnz	w13, #0x5, 0x1128 <_llm_rows.packet_batch.blocks+0x8b4>
    10f0:      	tbz	w13, #0x6, 0x1134 <_llm_rows.packet_batch.blocks+0x8c0>
    10f4:      	add	x14, x11, #0x18
    10f8:      	ld1.s	{ v31 }[2], [x14]
    10fc:      	tbnz	w13, #0x7, 0x1138 <_llm_rows.packet_batch.blocks+0x8c4>
    1100:      	b	0x1140 <_llm_rows.packet_batch.blocks+0x8cc>
    1104:      	tbz	w13, #0x1, 0x10d0 <_llm_rows.packet_batch.blocks+0x85c>
    1108:      	add	x14, x11, #0x4
    110c:      	ld1.s	{ v9 }[1], [x14]
    1110:      	tbnz	w13, #0x2, 0x10d4 <_llm_rows.packet_batch.blocks+0x860>
    1114:      	tbz	w13, #0x3, 0x10e0 <_llm_rows.packet_batch.blocks+0x86c>
    1118:      	add	x14, x11, #0xc
    111c:      	ld1.s	{ v9 }[3], [x14]
    1120:      	tbnz	w13, #0x4, 0x10e4 <_llm_rows.packet_batch.blocks+0x870>
    1124:      	tbz	w13, #0x5, 0x10f0 <_llm_rows.packet_batch.blocks+0x87c>
    1128:      	add	x14, x11, #0x14
    112c:      	ld1.s	{ v31 }[1], [x14]
    1130:      	tbnz	w13, #0x6, 0x10f4 <_llm_rows.packet_batch.blocks+0x880>
    1134:      	tbz	w13, #0x7, 0x1140 <_llm_rows.packet_batch.blocks+0x8cc>
    1138:      	add	x11, x11, #0x1c
    113c:      	ld1.s	{ v31 }[3], [x11]
    1140:      	mov	x15, #0x0               ; =0
    1144:      	movi.2s	v28, #0x41
    1148:      	umull.2d	v30, v30, v28
    114c:      	umlal.2d	v23, v26, v28
    1150:      	add.2d	v23, v23, v8
    1154:      	umlal.2d	v22, v25, v28
    1158:      	add.2d	v22, v22, v8
    115c:      	stp	q22, q23, [sp, #0x20]
    1160:      	umlal.2d	v21, v24, v28
    1164:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x78c>
    1168:      	ldr	q22, [x11]
    116c:      	mov	w11, #0x100             ; =256
    1170:      	dup.2d	v23, x11
    1174:      	sshll.2d	v24, v19, #0x0
    1178:      	bif.16b	v22, v23, v24
    117c:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x78c>
    1180:      	ldr	q24, [x11]
    1184:      	sshll.2d	v25, v20, #0x0
    1188:      	bif.16b	v24, v23, v25
    118c:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x78c>
    1190:      	ldr	q25, [x11]
    1194:      	bif.16b	v25, v23, v11
    1198:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x78c>
    119c:      	ldr	q26, [x11]
    11a0:      	bit.16b	v23, v26, v10
    11a4:      	stp	q24, q23, [sp, #0x220]
    11a8:      	stp	q22, q25, [sp, #0x200]
    11ac:      	and	x11, x10, #0x7
    11b0:      	add	x14, sp, #0x200
    11b4:      	ldr	x11, [x14, x11, lsl #3]
    11b8:      	add.2d	v21, v21, v8
    11bc:      	str	q21, [sp, #0x10]
    11c0:      	sub	x11, x11, x10, lsl #2
    11c4:      	tst	w13, #0xff
    11c8:      	csel	x11, xzr, x11, eq
    11cc:      	add	x13, x25, x11
    11d0:      	ldp	q21, q22, [x13]
    11d4:      	zip2.8b	v23, v29, v0
    11d8:      	ushll.4s	v23, v23, #0x0
    11dc:      	shl.4s	v23, v23, #0x1f
    11e0:      	cmlt.4s	v23, v23, #0
    11e4:      	str	q31, [sp, #0x60]
    11e8:      	bit.16b	v22, v31, v23
    11ec:      	zip1.8b	v23, v29, v0
    11f0:      	ushll.4s	v23, v23, #0x0
    11f4:      	shl.4s	v23, v23, #0x1f
    11f8:      	cmlt.4s	v23, v23, #0
    11fc:      	str	q9, [sp, #0x40]
    1200:      	bit.16b	v21, v9, v23
    1204:      	stp	q21, q22, [x13]
    1208:      	fmov	x13, d30
    120c:      	lsl	x13, x13, #2
    1210:      	mov	w14, #0x1               ; =1
    1214:      	dup.2d	v21, x14
    1218:      	add	x14, x9, x13
    121c:      	ushll2.2d	v22, v20, #0x0
    1220:      	and.16b	v24, v22, v21
    1224:      	ushll2.2d	v22, v19, #0x0
    1228:      	and.16b	v25, v22, v21
    122c:      	ushll.2d	v22, v20, #0x0
    1230:      	and.16b	v26, v22, v21
    1234:      	ushll.2d	v22, v19, #0x0
    1238:      	and.16b	v30, v22, v21
    123c:      	movi.2d	v8, #0000000000000000
    1240:      	movi.2d	v10, #0000000000000000
    1244:      	movi.2d	v11, #0000000000000000
    1248:      	movi.2d	v13, #0000000000000000
    124c:      	b	0x1280 <_llm_rows.packet_batch.blocks+0xa0c>
    1250:      	add	x15, x24, x15
    1254:      	ldp	q21, q22, [x15]
    1258:      	bit.16b	v22, v15, v20
    125c:      	bit.16b	v21, v14, v19
    1260:      	stp	q21, q22, [x15]
    1264:      	add.2d	v10, v10, v25
    1268:      	add.2d	v11, v11, v26
    126c:      	add.2d	v13, v13, v24
    1270:      	add.2d	v8, v8, v30
    1274:      	fmov	x15, d8
    1278:      	cmp	x15, #0x8
    127c:      	b.ge	0x131c <_llm_rows.packet_batch.blocks+0xaa8>
    1280:      	fmov	w17, s27
    1284:      	lsl	x15, x15, #5
    1288:      	add	x16, x14, x15
    128c:      	movi.2d	v14, #0000000000000000
    1290:      	movi.2d	v15, #0000000000000000
    1294:      	tbz	w17, #0x0, 0x12d8 <_llm_rows.packet_batch.blocks+0xa64>
    1298:      	ldr	s14, [x16]
    129c:      	and	w17, w17, #0xff
    12a0:      	tbnz	w17, #0x1, 0x12e0 <_llm_rows.packet_batch.blocks+0xa6c>
    12a4:      	tbz	w17, #0x2, 0x12ec <_llm_rows.packet_batch.blocks+0xa78>
    12a8:      	add	x0, x16, #0x8
    12ac:      	ld1.s	{ v14 }[2], [x0]
    12b0:      	tbnz	w17, #0x3, 0x12f0 <_llm_rows.packet_batch.blocks+0xa7c>
    12b4:      	tbz	w17, #0x4, 0x12fc <_llm_rows.packet_batch.blocks+0xa88>
    12b8:      	add	x0, x16, #0x10
    12bc:      	ld1.s	{ v15 }[0], [x0]
    12c0:      	tbnz	w17, #0x5, 0x1300 <_llm_rows.packet_batch.blocks+0xa8c>
    12c4:      	tbz	w17, #0x6, 0x130c <_llm_rows.packet_batch.blocks+0xa98>
    12c8:      	add	x0, x16, #0x18
    12cc:      	ld1.s	{ v15 }[2], [x0]
    12d0:      	tbz	w17, #0x7, 0x1250 <_llm_rows.packet_batch.blocks+0x9dc>
    12d4:      	b	0x1310 <_llm_rows.packet_batch.blocks+0xa9c>
    12d8:      	and	w17, w17, #0xff
    12dc:      	tbz	w17, #0x1, 0x12a4 <_llm_rows.packet_batch.blocks+0xa30>
    12e0:      	add	x0, x16, #0x4
    12e4:      	ld1.s	{ v14 }[1], [x0]
    12e8:      	tbnz	w17, #0x2, 0x12a8 <_llm_rows.packet_batch.blocks+0xa34>
    12ec:      	tbz	w17, #0x3, 0x12b4 <_llm_rows.packet_batch.blocks+0xa40>
    12f0:      	add	x0, x16, #0xc
    12f4:      	ld1.s	{ v14 }[3], [x0]
    12f8:      	tbnz	w17, #0x4, 0x12b8 <_llm_rows.packet_batch.blocks+0xa44>
    12fc:      	tbz	w17, #0x5, 0x12c4 <_llm_rows.packet_batch.blocks+0xa50>
    1300:      	add	x0, x16, #0x14
    1304:      	ld1.s	{ v15 }[1], [x0]
    1308:      	tbnz	w17, #0x6, 0x12c8 <_llm_rows.packet_batch.blocks+0xa54>
    130c:      	tbz	w17, #0x7, 0x1250 <_llm_rows.packet_batch.blocks+0x9dc>
    1310:      	add	x16, x16, #0x1c
    1314:      	ld1.s	{ v15 }[3], [x16]
    1318:      	b	0x1250 <_llm_rows.packet_batch.blocks+0x9dc>
    131c:      	add	x9, x9, x12
    1320:      	shl.8b	v21, v29, #0x7
    1324:      	cmlt.8b	v21, v21, #0
    1328:      	and.8b	v21, v21, v12
    132c:      	addv.8b	b21, v21
    1330:      	str	d21, [sp, #0x8]
    1334:      	fmov	w12, s21
    1338:      	movi.2d	v11, #0000000000000000
    133c:      	movi.2d	v10, #0000000000000000
    1340:      	tbz	w12, #0x0, 0x1380 <_llm_rows.packet_batch.blocks+0xb0c>
    1344:      	ldr	s11, [x9]
    1348:      	tbnz	w12, #0x1, 0x1384 <_llm_rows.packet_batch.blocks+0xb10>
    134c:      	tbz	w12, #0x2, 0x1390 <_llm_rows.packet_batch.blocks+0xb1c>
    1350:      	add	x14, x9, #0x8
    1354:      	ld1.s	{ v11 }[2], [x14]
    1358:      	tbnz	w12, #0x3, 0x1394 <_llm_rows.packet_batch.blocks+0xb20>
    135c:      	tbz	w12, #0x4, 0x13a0 <_llm_rows.packet_batch.blocks+0xb2c>
    1360:      	add	x14, x9, #0x10
    1364:      	ld1.s	{ v10 }[0], [x14]
    1368:      	tbnz	w12, #0x5, 0x13a4 <_llm_rows.packet_batch.blocks+0xb30>
    136c:      	tbz	w12, #0x6, 0x13b0 <_llm_rows.packet_batch.blocks+0xb3c>
    1370:      	add	x14, x9, #0x18
    1374:      	ld1.s	{ v10 }[2], [x14]
    1378:      	tbnz	w12, #0x7, 0x13b4 <_llm_rows.packet_batch.blocks+0xb40>
    137c:      	b	0x13bc <_llm_rows.packet_batch.blocks+0xb48>
    1380:      	tbz	w12, #0x1, 0x134c <_llm_rows.packet_batch.blocks+0xad8>
    1384:      	add	x14, x9, #0x4
    1388:      	ld1.s	{ v11 }[1], [x14]
    138c:      	tbnz	w12, #0x2, 0x1350 <_llm_rows.packet_batch.blocks+0xadc>
    1390:      	tbz	w12, #0x3, 0x135c <_llm_rows.packet_batch.blocks+0xae8>
    1394:      	add	x14, x9, #0xc
    1398:      	ld1.s	{ v11 }[3], [x14]
    139c:      	tbnz	w12, #0x4, 0x1360 <_llm_rows.packet_batch.blocks+0xaec>
    13a0:      	tbz	w12, #0x5, 0x136c <_llm_rows.packet_batch.blocks+0xaf8>
    13a4:      	add	x14, x9, #0x14
    13a8:      	ld1.s	{ v10 }[1], [x14]
    13ac:      	tbnz	w12, #0x6, 0x1370 <_llm_rows.packet_batch.blocks+0xafc>
    13b0:      	tbz	w12, #0x7, 0x13bc <_llm_rows.packet_batch.blocks+0xb48>
    13b4:      	add	x9, x9, #0x1c
    13b8:      	ld1.s	{ v10 }[3], [x9]
    13bc:      	mov	x14, #0x0               ; =0
    13c0:      	add	x9, x24, x11
    13c4:      	ldp	q21, q22, [x9]
    13c8:      	zip2.8b	v23, v29, v0
    13cc:      	ushll.4s	v23, v23, #0x0
    13d0:      	shl.4s	v23, v23, #0x1f
    13d4:      	cmlt.4s	v23, v23, #0
    13d8:      	bit.16b	v22, v10, v23
    13dc:      	zip1.8b	v23, v29, v0
    13e0:      	ushll.4s	v23, v23, #0x0
    13e4:      	shl.4s	v23, v23, #0x1f
    13e8:      	cmlt.4s	v23, v23, #0
    13ec:      	bit.16b	v21, v11, v23
    13f0:      	stp	q21, q22, [x9]
    13f4:      	add	x9, x8, x13
    13f8:      	movi.2d	v13, #0000000000000000
    13fc:      	movi.2d	v14, #0000000000000000
    1400:      	movi.2d	v15, #0000000000000000
    1404:      	movi.2d	v8, #0000000000000000
    1408:      	b	0x1428 <_llm_rows.packet_batch.blocks+0xbb4>
    140c:      	add.2d	v14, v14, v25
    1410:      	add.2d	v15, v15, v26
    1414:      	add.2d	v8, v8, v24
    1418:      	add.2d	v13, v13, v30
    141c:      	fmov	x14, d13
    1420:      	cmp	x14, #0x8
    1424:      	b.ge	0x1678 <_llm_rows.packet_batch.blocks+0xe04>
    1428:      	fmov	w12, s27
    142c:      	lsl	x11, x14, #5
    1430:      	add	x13, x25, x11
    1434:      	ldp	q21, q23, [x13]
    1438:      	and.16b	v21, v19, v21
    143c:      	fneg.4s	v22, v21
    1440:      	and.16b	v22, v19, v22
    1444:      	fcmge.4s	v31, v22, v1
    1448:      	fcmge.4s	v12, v0, v22
    144c:      	and.16b	v31, v31, v12
    1450:      	and.16b	v31, v31, v22
    1454:      	fmul.4s	v12, v31, v18
    1458:      	movi.4s	v28, #0x4b, lsl #24
    145c:      	mvni.4s	v9, #0x80, lsl #24
    1460:      	bsl.16b	v9, v28, v12
    1464:      	fadd.4s	v12, v12, v9
    1468:      	fsub.4s	v9, v12, v9
    146c:      	fcvtzs.4s	v9, v9
    1470:      	scvtf.4s	v12, v9
    1474:      	fmul.4s	v28, v12, v17
    1478:      	fadd.4s	v28, v31, v28
    147c:      	fmul.4s	v31, v12, v16
    1480:      	fadd.4s	v28, v28, v31
    1484:      	fmul.4s	v31, v28, v7
    1488:      	fadd.4s	v31, v31, v6
    148c:      	fmul.4s	v31, v28, v31
    1490:      	fadd.4s	v31, v31, v5
    1494:      	fmul.4s	v31, v28, v31
    1498:      	fadd.4s	v31, v31, v4
    149c:      	fmul.4s	v31, v28, v31
    14a0:      	fadd.4s	v31, v31, v3
    14a4:      	fmul.4s	v31, v28, v31
    14a8:      	movi.4s	v12, #0x3f, lsl #24
    14ac:      	fadd.4s	v31, v31, v12
    14b0:      	fmul.4s	v12, v28, v28
    14b4:      	fmul.4s	v31, v12, v31
    14b8:      	fadd.4s	v28, v28, v31
    14bc:      	fadd.4s	v28, v28, v2
    14c0:      	sshr.4s	v31, v9, #0x1
    14c4:      	shl.4s	v12, v31, #0x17
    14c8:      	add.4s	v12, v12, v2
    14cc:      	fmul.4s	v28, v28, v12
    14d0:      	sub.4s	v31, v9, v31
    14d4:      	shl.4s	v31, v31, #0x17
    14d8:      	add.4s	v31, v31, v2
    14dc:      	fmul.4s	v28, v28, v31
    14e0:      	fcmgt.4s	v31, v1, v22
    14e4:      	fcmgt.4s	v9, v22, v0
    14e8:      	fcmeq.4s	v22, v22, v22
    14ec:      	fadd.4s	v28, v28, v2
    14f0:      	bit.16b	v28, v2, v31
    14f4:      	ldr	q31, [sp, #0x110]
    14f8:      	bit.16b	v28, v31, v9
    14fc:      	ldr	q31, [sp, #0x100]
    1500:      	bsl.16b	v22, v28, v31
    1504:      	fdiv.4s	v21, v21, v22
    1508:      	add	x13, x24, x11
    150c:      	ldp	q28, q22, [x13]
    1510:      	and.16b	v28, v19, v28
    1514:      	fmul.4s	v21, v28, v21
    1518:      	add	x11, x9, x11
    151c:      	tbz	w12, #0x0, 0x1540 <_llm_rows.packet_batch.blocks+0xccc>
    1520:      	str	s21, [x11]
    1524:      	and	w12, w12, #0xff
    1528:      	tbnz	w12, #0x1, 0x1548 <_llm_rows.packet_batch.blocks+0xcd4>
    152c:      	tbz	w12, #0x2, 0x1554 <_llm_rows.packet_batch.blocks+0xce0>
    1530:      	add	x13, x11, #0x8
    1534:      	st1.s	{ v21 }[2], [x13]
    1538:      	tbnz	w12, #0x3, 0x1558 <_llm_rows.packet_batch.blocks+0xce4>
    153c:      	b	0x1560 <_llm_rows.packet_batch.blocks+0xcec>
    1540:      	and	w12, w12, #0xff
    1544:      	tbz	w12, #0x1, 0x152c <_llm_rows.packet_batch.blocks+0xcb8>
    1548:      	add	x13, x11, #0x4
    154c:      	st1.s	{ v21 }[1], [x13]
    1550:      	tbnz	w12, #0x2, 0x1530 <_llm_rows.packet_batch.blocks+0xcbc>
    1554:      	tbz	w12, #0x3, 0x1560 <_llm_rows.packet_batch.blocks+0xcec>
    1558:      	add	x13, x11, #0xc
    155c:      	st1.s	{ v21 }[3], [x13]
    1560:      	and.16b	v21, v20, v23
    1564:      	fneg.4s	v23, v21
    1568:      	and.16b	v23, v20, v23
    156c:      	fcmge.4s	v28, v23, v1
    1570:      	fcmge.4s	v31, v0, v23
    1574:      	and.16b	v28, v28, v31
    1578:      	and.16b	v28, v28, v23
    157c:      	fmul.4s	v31, v28, v18
    1580:      	movi.4s	v9, #0x4b, lsl #24
    1584:      	mvni.4s	v12, #0x80, lsl #24
    1588:      	bif.16b	v9, v31, v12
    158c:      	fadd.4s	v31, v31, v9
    1590:      	fsub.4s	v31, v31, v9
    1594:      	fcvtzs.4s	v31, v31
    1598:      	scvtf.4s	v9, v31
    159c:      	fmul.4s	v12, v9, v17
    15a0:      	fadd.4s	v28, v28, v12
    15a4:      	fmul.4s	v9, v9, v16
    15a8:      	fadd.4s	v28, v28, v9
    15ac:      	fmul.4s	v9, v28, v7
    15b0:      	fadd.4s	v9, v9, v6
    15b4:      	fmul.4s	v9, v28, v9
    15b8:      	fadd.4s	v9, v9, v5
    15bc:      	fmul.4s	v9, v28, v9
    15c0:      	fadd.4s	v9, v9, v4
    15c4:      	fmul.4s	v9, v28, v9
    15c8:      	fadd.4s	v9, v9, v3
    15cc:      	fmul.4s	v9, v28, v9
    15d0:      	movi.4s	v12, #0x3f, lsl #24
    15d4:      	fadd.4s	v9, v9, v12
    15d8:      	fmul.4s	v12, v28, v28
    15dc:      	fmul.4s	v9, v12, v9
    15e0:      	fadd.4s	v28, v28, v9
    15e4:      	fadd.4s	v28, v28, v2
    15e8:      	sshr.4s	v9, v31, #0x1
    15ec:      	shl.4s	v12, v9, #0x17
    15f0:      	add.4s	v12, v12, v2
    15f4:      	fmul.4s	v28, v28, v12
    15f8:      	sub.4s	v31, v31, v9
    15fc:      	shl.4s	v31, v31, #0x17
    1600:      	add.4s	v31, v31, v2
    1604:      	fmul.4s	v28, v28, v31
    1608:      	fcmgt.4s	v31, v1, v23
    160c:      	fcmgt.4s	v9, v23, v0
    1610:      	fcmeq.4s	v23, v23, v23
    1614:      	fadd.4s	v28, v28, v2
    1618:      	bit.16b	v28, v2, v31
    161c:      	ldr	q31, [sp, #0x110]
    1620:      	bit.16b	v28, v31, v9
    1624:      	ldr	q31, [sp, #0x100]
    1628:      	bsl.16b	v23, v28, v31
    162c:      	fdiv.4s	v21, v21, v23
    1630:      	and.16b	v22, v20, v22
    1634:      	fmul.4s	v21, v22, v21
    1638:      	tbz	w12, #0x4, 0x1658 <_llm_rows.packet_batch.blocks+0xde4>
    163c:      	str	s21, [x11, #0x10]
    1640:      	tbnz	w12, #0x5, 0x165c <_llm_rows.packet_batch.blocks+0xde8>
    1644:      	tbz	w12, #0x6, 0x1668 <_llm_rows.packet_batch.blocks+0xdf4>
    1648:      	add	x13, x11, #0x18
    164c:      	st1.s	{ v21 }[2], [x13]
    1650:      	tbz	w12, #0x7, 0x140c <_llm_rows.packet_batch.blocks+0xb98>
    1654:      	b	0x166c <_llm_rows.packet_batch.blocks+0xdf8>
    1658:      	tbz	w12, #0x5, 0x1644 <_llm_rows.packet_batch.blocks+0xdd0>
    165c:      	add	x13, x11, #0x14
    1660:      	st1.s	{ v21 }[1], [x13]
    1664:      	tbnz	w12, #0x6, 0x1648 <_llm_rows.packet_batch.blocks+0xdd4>
    1668:      	tbz	w12, #0x7, 0x140c <_llm_rows.packet_batch.blocks+0xb98>
    166c:      	add	x11, x11, #0x1c
    1670:      	st1.s	{ v21 }[3], [x11]
    1674:      	b	0x140c <_llm_rows.packet_batch.blocks+0xb98>
    1678:      	ldr	q24, [sp, #0x40]
    167c:      	fneg.4s	v19, v24
    1680:      	ldr	d20, [sp, #0x8]
    1684:      	fmov	w9, s20
    1688:      	zip1.8b	v20, v29, v0
    168c:      	ushll.4s	v20, v20, #0x0
    1690:      	shl.4s	v20, v20, #0x1f
    1694:      	cmlt.4s	v20, v20, #0
    1698:      	and.16b	v19, v20, v19
    169c:      	fcmge.4s	v20, v19, v1
    16a0:      	fcmge.4s	v21, v0, v19
    16a4:      	and.16b	v20, v20, v21
    16a8:      	and.16b	v20, v20, v19
    16ac:      	fmul.4s	v21, v20, v18
    16b0:      	movi.4s	v22, #0x4b, lsl #24
    16b4:      	mvni.4s	v23, #0x80, lsl #24
    16b8:      	bif.16b	v22, v21, v23
    16bc:      	fadd.4s	v21, v21, v22
    16c0:      	fsub.4s	v21, v21, v22
    16c4:      	fcvtzs.4s	v21, v21
    16c8:      	scvtf.4s	v22, v21
    16cc:      	fmul.4s	v23, v22, v17
    16d0:      	fadd.4s	v20, v20, v23
    16d4:      	fmul.4s	v22, v22, v16
    16d8:      	fadd.4s	v20, v20, v22
    16dc:      	fmul.4s	v22, v20, v7
    16e0:      	fadd.4s	v22, v22, v6
    16e4:      	fmul.4s	v22, v20, v22
    16e8:      	fadd.4s	v22, v22, v5
    16ec:      	fmul.4s	v22, v20, v22
    16f0:      	fadd.4s	v22, v22, v4
    16f4:      	fmul.4s	v22, v20, v22
    16f8:      	fadd.4s	v22, v22, v3
    16fc:      	fmul.4s	v22, v20, v22
    1700:      	movi.4s	v23, #0x3f, lsl #24
    1704:      	fadd.4s	v22, v22, v23
    1708:      	fmul.4s	v23, v20, v20
    170c:      	fmul.4s	v22, v23, v22
    1710:      	fadd.4s	v20, v20, v22
    1714:      	fadd.4s	v20, v20, v2
    1718:      	sshr.4s	v22, v21, #0x1
    171c:      	shl.4s	v23, v22, #0x17
    1720:      	add.4s	v23, v23, v2
    1724:      	fmul.4s	v20, v20, v23
    1728:      	sub.4s	v21, v21, v22
    172c:      	shl.4s	v21, v21, #0x17
    1730:      	add.4s	v21, v21, v2
    1734:      	fmul.4s	v20, v20, v21
    1738:      	fcmgt.4s	v21, v1, v19
    173c:      	fcmgt.4s	v22, v19, v0
    1740:      	fcmeq.4s	v19, v19, v19
    1744:      	fadd.4s	v20, v20, v2
    1748:      	bit.16b	v20, v2, v21
    174c:      	ldp	q21, q23, [sp, #0x100]
    1750:      	bit.16b	v20, v23, v22
    1754:      	bsl.16b	v19, v20, v21
    1758:      	fdiv.4s	v19, v24, v19
    175c:      	fmul.4s	v19, v19, v11
    1760:      	ldr	q21, [sp, #0x50]
    1764:      	ldp	q23, q22, [sp, #0x20]
    1768:      	stp	q21, q22, [sp, #0x1b0]
    176c:      	ldr	q20, [sp, #0x10]
    1770:      	stp	q23, q20, [sp, #0x1d0]
    1774:      	and	x11, x10, #0x7
    1778:      	add	x12, sp, #0x1b0
    177c:      	ldr	x11, [x12, x11, lsl #3]
    1780:      	sub	x10, x11, x10
    1784:      	add	x8, x8, x10, lsl #2
    1788:      	tbz	w9, #0x0, 0x17b0 <_llm_rows.packet_batch.blocks+0xf3c>
    178c:      	str	s19, [x8]
    1790:      	ldr	q15, [sp, #0xe0]
    1794:      	ldr	q23, [sp, #0x60]
    1798:      	tbnz	w9, #0x1, 0x17bc <_llm_rows.packet_batch.blocks+0xf48>
    179c:      	tbz	w9, #0x2, 0x17c8 <_llm_rows.packet_batch.blocks+0xf54>
    17a0:      	add	x10, x8, #0x8
    17a4:      	st1.s	{ v19 }[2], [x10]
    17a8:      	tbnz	w9, #0x3, 0x17cc <_llm_rows.packet_batch.blocks+0xf58>
    17ac:      	b	0x17d4 <_llm_rows.packet_batch.blocks+0xf60>
    17b0:      	ldr	q15, [sp, #0xe0]
    17b4:      	ldr	q23, [sp, #0x60]
    17b8:      	tbz	w9, #0x1, 0x179c <_llm_rows.packet_batch.blocks+0xf28>
    17bc:      	add	x10, x8, #0x4
    17c0:      	st1.s	{ v19 }[1], [x10]
    17c4:      	tbnz	w9, #0x2, 0x17a0 <_llm_rows.packet_batch.blocks+0xf2c>
    17c8:      	tbz	w9, #0x3, 0x17d4 <_llm_rows.packet_batch.blocks+0xf60>
    17cc:      	add	x10, x8, #0xc
    17d0:      	st1.s	{ v19 }[3], [x10]
    17d4:      	fneg.4s	v19, v23
    17d8:      	zip2.8b	v20, v29, v0
    17dc:      	ushll.4s	v20, v20, #0x0
    17e0:      	shl.4s	v20, v20, #0x1f
    17e4:      	cmlt.4s	v20, v20, #0
    17e8:      	and.16b	v19, v20, v19
    17ec:      	fcmge.4s	v20, v19, v1
    17f0:      	fcmge.4s	v21, v0, v19
    17f4:      	and.16b	v20, v20, v21
    17f8:      	and.16b	v20, v20, v19
    17fc:      	fmul.4s	v18, v20, v18
    1800:      	movi.4s	v21, #0x4b, lsl #24
    1804:      	mvni.4s	v22, #0x80, lsl #24
    1808:      	bif.16b	v21, v18, v22
    180c:      	fadd.4s	v18, v18, v21
    1810:      	fsub.4s	v18, v18, v21
    1814:      	fcvtzs.4s	v18, v18
    1818:      	scvtf.4s	v21, v18
    181c:      	fmul.4s	v17, v21, v17
    1820:      	fadd.4s	v17, v20, v17
    1824:      	fmul.4s	v16, v21, v16
    1828:      	fadd.4s	v16, v17, v16
    182c:      	fmul.4s	v7, v16, v7
    1830:      	fadd.4s	v6, v7, v6
    1834:      	fmul.4s	v6, v16, v6
    1838:      	fadd.4s	v5, v6, v5
    183c:      	fmul.4s	v5, v16, v5
    1840:      	fadd.4s	v4, v5, v4
    1844:      	fmul.4s	v4, v16, v4
    1848:      	fadd.4s	v3, v4, v3
    184c:      	fmul.4s	v3, v16, v3
    1850:      	movi.4s	v4, #0x3f, lsl #24
    1854:      	fadd.4s	v3, v3, v4
    1858:      	fmul.4s	v4, v16, v16
    185c:      	fmul.4s	v3, v4, v3
    1860:      	fadd.4s	v3, v16, v3
    1864:      	fadd.4s	v3, v3, v2
    1868:      	sshr.4s	v4, v18, #0x1
    186c:      	shl.4s	v5, v4, #0x17
    1870:      	add.4s	v5, v5, v2
    1874:      	fmul.4s	v3, v3, v5
    1878:      	sub.4s	v4, v18, v4
    187c:      	shl.4s	v4, v4, #0x17
    1880:      	add.4s	v4, v4, v2
    1884:      	fmul.4s	v3, v3, v4
    1888:      	fcmgt.4s	v1, v1, v19
    188c:      	fcmgt.4s	v0, v19, v0
    1890:      	fcmeq.4s	v4, v19, v19
    1894:      	fadd.4s	v3, v3, v2
    1898:      	bsl.16b	v1, v2, v3
    189c:      	ldr	q2, [sp, #0x110]
    18a0:      	bsl.16b	v0, v2, v1
    18a4:      	ldr	q1, [sp, #0x100]
    18a8:      	bif.16b	v0, v1, v4
    18ac:      	fdiv.4s	v0, v23, v0
    18b0:      	fmul.4s	v0, v0, v10
    18b4:      	tbz	w9, #0x4, 0x1cb8 <_llm_rows.packet_batch.blocks+0x1444>
    18b8:      	str	s0, [x8, #0x10]
    18bc:      	tbnz	w9, #0x5, 0x1cbc <_llm_rows.packet_batch.blocks+0x1448>
    18c0:      	tbz	w9, #0x6, 0x1cc8 <_llm_rows.packet_batch.blocks+0x1454>
    18c4:      	add	x10, x8, #0x18
    18c8:      	st1.s	{ v0 }[2], [x10]
    18cc:      	tbnz	w9, #0x7, 0x1ccc <_llm_rows.packet_batch.blocks+0x1458>
    18d0:      	b	0x93c <_llm_rows.packet_batch.blocks+0xc8>
    18d4:      	xtn.4h	v19, v19
    18d8:      	uzp1.8b	v19, v19, v0
    18dc:      	movi.2d	v20, #0000000000000000
    18e0:      	mov.b	v20[0], v19[0]
    18e4:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x78c>
    18e8:      	ldr	d31, [x10]
    18ec:      	and.8b	v27, v20, v31
    18f0:      	addv.8b	b27, v27
    18f4:      	fmov	w12, s27
    18f8:      	umaxv.8b	b27, v20
    18fc:      	fmov	w14, s27
    1900:      	rbit	w10, w12
    1904:      	clz	w10, w10
    1908:      	tst	w14, #0x1
    190c:      	csel	w10, w10, wzr, ne
    1910:      	mov	w13, #0x40              ; =64
    1914:      	dup.2d	v29, x13
    1918:      	movi.2s	v27, #0x41
    191c:      	umlal.2d	v28, v30, v27
    1920:      	movi.2d	v30, #0000000000000000
    1924:      	mov.b	v30[0], v19[0]
    1928:      	add.2d	v27, v28, v29
    192c:      	ushll.2d	v19, v30, #0x0
    1930:      	shl.2d	v19, v19, #0x3f
    1934:      	cmlt.2d	v19, v19, #0
    1938:      	and.16b	v19, v19, v27
    193c:      	movi.2d	v28, #0000000000000000
    1940:      	stp	q28, q28, [sp, #0x180]
    1944:      	stp	q19, q28, [sp, #0x160]
    1948:      	and	x13, x10, #0x7
    194c:      	add	x15, sp, #0x160
    1950:      	ldr	x13, [x15, x13, lsl #3]
    1954:      	sub	x13, x13, x10
    1958:      	lsl	x13, x13, #2
    195c:      	add	x11, x11, x13
    1960:      	movi.2d	v19, #0000000000000000
    1964:      	tbz	w14, #0x0, 0x19a4 <_llm_rows.packet_batch.blocks+0x1130>
    1968:      	ldr	s28, [x11]
    196c:      	tbnz	w12, #0x1, 0x19a8 <_llm_rows.packet_batch.blocks+0x1134>
    1970:      	tbz	w12, #0x2, 0x19b4 <_llm_rows.packet_batch.blocks+0x1140>
    1974:      	add	x14, x11, #0x8
    1978:      	ld1.s	{ v28 }[2], [x14]
    197c:      	tbnz	w12, #0x3, 0x19b8 <_llm_rows.packet_batch.blocks+0x1144>
    1980:      	tbz	w12, #0x4, 0x19c4 <_llm_rows.packet_batch.blocks+0x1150>
    1984:      	add	x14, x11, #0x10
    1988:      	ld1.s	{ v19 }[0], [x14]
    198c:      	tbnz	w12, #0x5, 0x19c8 <_llm_rows.packet_batch.blocks+0x1154>
    1990:      	tbz	w12, #0x6, 0x19d4 <_llm_rows.packet_batch.blocks+0x1160>
    1994:      	add	x14, x11, #0x18
    1998:      	ld1.s	{ v19 }[2], [x14]
    199c:      	tbnz	w12, #0x7, 0x19d8 <_llm_rows.packet_batch.blocks+0x1164>
    19a0:      	b	0x19e0 <_llm_rows.packet_batch.blocks+0x116c>
    19a4:      	tbz	w12, #0x1, 0x1970 <_llm_rows.packet_batch.blocks+0x10fc>
    19a8:      	add	x14, x11, #0x4
    19ac:      	ld1.s	{ v28 }[1], [x14]
    19b0:      	tbnz	w12, #0x2, 0x1974 <_llm_rows.packet_batch.blocks+0x1100>
    19b4:      	tbz	w12, #0x3, 0x1980 <_llm_rows.packet_batch.blocks+0x110c>
    19b8:      	add	x14, x11, #0xc
    19bc:      	ld1.s	{ v28 }[3], [x14]
    19c0:      	tbnz	w12, #0x4, 0x1984 <_llm_rows.packet_batch.blocks+0x1110>
    19c4:      	tbz	w12, #0x5, 0x1990 <_llm_rows.packet_batch.blocks+0x111c>
    19c8:      	add	x14, x11, #0x14
    19cc:      	ld1.s	{ v19 }[1], [x14]
    19d0:      	tbnz	w12, #0x6, 0x1994 <_llm_rows.packet_batch.blocks+0x1120>
    19d4:      	tbz	w12, #0x7, 0x19e0 <_llm_rows.packet_batch.blocks+0x116c>
    19d8:      	add	x11, x11, #0x1c
    19dc:      	ld1.s	{ v19 }[3], [x11]
    19e0:      	shl.8b	v30, v20, #0x7
    19e4:      	cmlt.8b	v30, v30, #0
    19e8:      	and.8b	v30, v30, v31
    19ec:      	addv.8b	b31, v30
    19f0:      	fmov	w11, s31
    19f4:      	add	x9, x9, x13
    19f8:      	movi.2d	v8, #0000000000000000
    19fc:      	movi.2d	v30, #0000000000000000
    1a00:      	tbz	w11, #0x0, 0x1a40 <_llm_rows.packet_batch.blocks+0x11cc>
    1a04:      	ldr	s8, [x9]
    1a08:      	tbnz	w11, #0x1, 0x1a44 <_llm_rows.packet_batch.blocks+0x11d0>
    1a0c:      	tbz	w11, #0x2, 0x1a50 <_llm_rows.packet_batch.blocks+0x11dc>
    1a10:      	add	x12, x9, #0x8
    1a14:      	ld1.s	{ v8 }[2], [x12]
    1a18:      	tbnz	w11, #0x3, 0x1a54 <_llm_rows.packet_batch.blocks+0x11e0>
    1a1c:      	tbz	w11, #0x4, 0x1a60 <_llm_rows.packet_batch.blocks+0x11ec>
    1a20:      	add	x12, x9, #0x10
    1a24:      	ld1.s	{ v30 }[0], [x12]
    1a28:      	tbnz	w11, #0x5, 0x1a64 <_llm_rows.packet_batch.blocks+0x11f0>
    1a2c:      	tbz	w11, #0x6, 0x1a70 <_llm_rows.packet_batch.blocks+0x11fc>
    1a30:      	add	x12, x9, #0x18
    1a34:      	ld1.s	{ v30 }[2], [x12]
    1a38:      	tbnz	w11, #0x7, 0x1a74 <_llm_rows.packet_batch.blocks+0x1200>
    1a3c:      	b	0x1a7c <_llm_rows.packet_batch.blocks+0x1208>
    1a40:      	tbz	w11, #0x1, 0x1a0c <_llm_rows.packet_batch.blocks+0x1198>
    1a44:      	add	x12, x9, #0x4
    1a48:      	ld1.s	{ v8 }[1], [x12]
    1a4c:      	tbnz	w11, #0x2, 0x1a10 <_llm_rows.packet_batch.blocks+0x119c>
    1a50:      	tbz	w11, #0x3, 0x1a1c <_llm_rows.packet_batch.blocks+0x11a8>
    1a54:      	add	x12, x9, #0xc
    1a58:      	ld1.s	{ v8 }[3], [x12]
    1a5c:      	tbnz	w11, #0x4, 0x1a20 <_llm_rows.packet_batch.blocks+0x11ac>
    1a60:      	tbz	w11, #0x5, 0x1a2c <_llm_rows.packet_batch.blocks+0x11b8>
    1a64:      	add	x12, x9, #0x14
    1a68:      	ld1.s	{ v30 }[1], [x12]
    1a6c:      	tbnz	w11, #0x6, 0x1a30 <_llm_rows.packet_batch.blocks+0x11bc>
    1a70:      	tbz	w11, #0x7, 0x1a7c <_llm_rows.packet_batch.blocks+0x1208>
    1a74:      	add	x9, x9, #0x1c
    1a78:      	ld1.s	{ v30 }[3], [x9]
    1a7c:      	movi.2s	v9, #0x41
    1a80:      	umlal.2d	v23, v26, v9
    1a84:      	add.2d	v23, v23, v29
    1a88:      	umlal.2d	v22, v25, v9
    1a8c:      	add.2d	v22, v22, v29
    1a90:      	umlal.2d	v21, v24, v9
    1a94:      	add.2d	v24, v21, v29
    1a98:      	fneg.4s	v21, v28
    1a9c:      	zip1.8b	v25, v20, v0
    1aa0:      	ushll.4s	v25, v25, #0x0
    1aa4:      	shl.4s	v25, v25, #0x1f
    1aa8:      	cmlt.4s	v25, v25, #0
    1aac:      	and.16b	v21, v25, v21
    1ab0:      	fcmge.4s	v25, v21, v1
    1ab4:      	fcmge.4s	v26, v0, v21
    1ab8:      	and.16b	v25, v25, v26
    1abc:      	and.16b	v25, v25, v21
    1ac0:      	fmul.4s	v26, v25, v18
    1ac4:      	movi.4s	v29, #0x4b, lsl #24
    1ac8:      	mvni.4s	v9, #0x80, lsl #24
    1acc:      	bif.16b	v29, v26, v9
    1ad0:      	fadd.4s	v26, v26, v29
    1ad4:      	fsub.4s	v26, v26, v29
    1ad8:      	fcvtzs.4s	v26, v26
    1adc:      	scvtf.4s	v29, v26
    1ae0:      	fmul.4s	v9, v29, v17
    1ae4:      	fadd.4s	v25, v25, v9
    1ae8:      	fmul.4s	v29, v29, v16
    1aec:      	fadd.4s	v25, v25, v29
    1af0:      	fmul.4s	v29, v25, v7
    1af4:      	fadd.4s	v29, v29, v6
    1af8:      	fmul.4s	v29, v25, v29
    1afc:      	fadd.4s	v29, v29, v5
    1b00:      	fmul.4s	v29, v25, v29
    1b04:      	fadd.4s	v29, v29, v4
    1b08:      	fmul.4s	v29, v25, v29
    1b0c:      	fadd.4s	v29, v29, v3
    1b10:      	fmul.4s	v29, v25, v29
    1b14:      	movi.4s	v9, #0x3f, lsl #24
    1b18:      	fadd.4s	v29, v29, v9
    1b1c:      	fmul.4s	v9, v25, v25
    1b20:      	fmul.4s	v29, v9, v29
    1b24:      	fadd.4s	v25, v25, v29
    1b28:      	fadd.4s	v25, v25, v2
    1b2c:      	sshr.4s	v29, v26, #0x1
    1b30:      	shl.4s	v9, v29, #0x17
    1b34:      	add.4s	v9, v9, v2
    1b38:      	fmul.4s	v25, v25, v9
    1b3c:      	sub.4s	v26, v26, v29
    1b40:      	shl.4s	v26, v26, #0x17
    1b44:      	add.4s	v26, v26, v2
    1b48:      	fmul.4s	v25, v25, v26
    1b4c:      	fcmgt.4s	v26, v1, v21
    1b50:      	fcmgt.4s	v29, v21, v0
    1b54:      	fcmeq.4s	v21, v21, v21
    1b58:      	fadd.4s	v25, v25, v2
    1b5c:      	bit.16b	v25, v2, v26
    1b60:      	ldr	q26, [sp, #0x110]
    1b64:      	bit.16b	v25, v26, v29
    1b68:      	ldr	q26, [sp, #0x100]
    1b6c:      	bsl.16b	v21, v25, v26
    1b70:      	fdiv.4s	v21, v28, v21
    1b74:      	fmul.4s	v21, v8, v21
    1b78:      	stp	q27, q23, [sp, #0x120]
    1b7c:      	stp	q22, q24, [sp, #0x140]
    1b80:      	and	x9, x10, #0x7
    1b84:      	add	x11, sp, #0x120
    1b88:      	ldr	x9, [x11, x9, lsl #3]
    1b8c:      	sub	x9, x9, x10
    1b90:      	add	x8, x8, x9, lsl #2
    1b94:      	fmov	w9, s31
    1b98:      	tbz	w9, #0x0, 0x1bb8 <_llm_rows.packet_batch.blocks+0x1344>
    1b9c:      	str	s21, [x8]
    1ba0:      	tbnz	w9, #0x1, 0x1bbc <_llm_rows.packet_batch.blocks+0x1348>
    1ba4:      	tbz	w9, #0x2, 0x1bc8 <_llm_rows.packet_batch.blocks+0x1354>
    1ba8:      	add	x10, x8, #0x8
    1bac:      	st1.s	{ v21 }[2], [x10]
    1bb0:      	tbnz	w9, #0x3, 0x1bcc <_llm_rows.packet_batch.blocks+0x1358>
    1bb4:      	b	0x1bd4 <_llm_rows.packet_batch.blocks+0x1360>
    1bb8:      	tbz	w9, #0x1, 0x1ba4 <_llm_rows.packet_batch.blocks+0x1330>
    1bbc:      	add	x10, x8, #0x4
    1bc0:      	st1.s	{ v21 }[1], [x10]
    1bc4:      	tbnz	w9, #0x2, 0x1ba8 <_llm_rows.packet_batch.blocks+0x1334>
    1bc8:      	tbz	w9, #0x3, 0x1bd4 <_llm_rows.packet_batch.blocks+0x1360>
    1bcc:      	add	x10, x8, #0xc
    1bd0:      	st1.s	{ v21 }[3], [x10]
    1bd4:      	fneg.4s	v21, v19
    1bd8:      	zip2.8b	v20, v20, v0
    1bdc:      	ushll.4s	v20, v20, #0x0
    1be0:      	shl.4s	v20, v20, #0x1f
    1be4:      	cmlt.4s	v20, v20, #0
    1be8:      	and.16b	v20, v20, v21
    1bec:      	fcmge.4s	v21, v20, v1
    1bf0:      	fcmge.4s	v22, v0, v20
    1bf4:      	and.16b	v21, v21, v22
    1bf8:      	and.16b	v21, v21, v20
    1bfc:      	fmul.4s	v18, v21, v18
    1c00:      	movi.4s	v22, #0x4b, lsl #24
    1c04:      	mvni.4s	v23, #0x80, lsl #24
    1c08:      	bif.16b	v22, v18, v23
    1c0c:      	fadd.4s	v18, v18, v22
    1c10:      	fsub.4s	v18, v18, v22
    1c14:      	fcvtzs.4s	v18, v18
    1c18:      	scvtf.4s	v22, v18
    1c1c:      	fmul.4s	v17, v22, v17
    1c20:      	fadd.4s	v17, v21, v17
    1c24:      	fmul.4s	v16, v22, v16
    1c28:      	fadd.4s	v16, v17, v16
    1c2c:      	fmul.4s	v7, v16, v7
    1c30:      	fadd.4s	v6, v7, v6
    1c34:      	fmul.4s	v6, v16, v6
    1c38:      	fadd.4s	v5, v6, v5
    1c3c:      	fmul.4s	v5, v16, v5
    1c40:      	fadd.4s	v4, v5, v4
    1c44:      	fmul.4s	v4, v16, v4
    1c48:      	fadd.4s	v3, v4, v3
    1c4c:      	fmul.4s	v3, v16, v3
    1c50:      	movi.4s	v4, #0x3f, lsl #24
    1c54:      	fadd.4s	v3, v3, v4
    1c58:      	fmul.4s	v4, v16, v16
    1c5c:      	fmul.4s	v3, v4, v3
    1c60:      	fadd.4s	v3, v16, v3
    1c64:      	fadd.4s	v3, v3, v2
    1c68:      	sshr.4s	v4, v18, #0x1
    1c6c:      	shl.4s	v5, v4, #0x17
    1c70:      	add.4s	v5, v5, v2
    1c74:      	fmul.4s	v3, v3, v5
    1c78:      	sub.4s	v4, v18, v4
    1c7c:      	shl.4s	v4, v4, #0x17
    1c80:      	add.4s	v4, v4, v2
    1c84:      	fmul.4s	v3, v3, v4
    1c88:      	fcmgt.4s	v1, v1, v20
    1c8c:      	fcmgt.4s	v0, v20, v0
    1c90:      	fcmeq.4s	v4, v20, v20
    1c94:      	fadd.4s	v3, v3, v2
    1c98:      	bsl.16b	v1, v2, v3
    1c9c:      	ldr	q2, [sp, #0x110]
    1ca0:      	bsl.16b	v0, v2, v1
    1ca4:      	ldr	q1, [sp, #0x100]
    1ca8:      	bif.16b	v0, v1, v4
    1cac:      	fdiv.4s	v0, v19, v0
    1cb0:      	fmul.4s	v0, v30, v0
    1cb4:      	tbnz	w9, #0x4, 0x18b8 <_llm_rows.packet_batch.blocks+0x1044>
    1cb8:      	tbz	w9, #0x5, 0x18c0 <_llm_rows.packet_batch.blocks+0x104c>
    1cbc:      	add	x10, x8, #0x14
    1cc0:      	st1.s	{ v0 }[1], [x10]
    1cc4:      	tbnz	w9, #0x6, 0x18c4 <_llm_rows.packet_batch.blocks+0x1050>
    1cc8:      	tbz	w9, #0x7, 0x93c <_llm_rows.packet_batch.blocks+0xc8>
    1ccc:      	add	x8, x8, #0x1c
    1cd0:      	st1.s	{ v0 }[3], [x8]
    1cd4:      	b	0x93c <_llm_rows.packet_batch.blocks+0xc8>
    1cd8:      	add	sp, sp, #0x4d0
    1cdc:      	ldp	x29, x30, [sp, #0x90]
    1ce0:      	ldp	x20, x19, [sp, #0x80]
    1ce4:      	ldp	x22, x21, [sp, #0x70]
    1ce8:      	ldp	x24, x23, [sp, #0x60]
    1cec:      	ldp	x26, x25, [sp, #0x50]
    1cf0:      	ldp	x28, x27, [sp, #0x40]
    1cf4:      	ldp	d9, d8, [sp, #0x30]
    1cf8:      	ldp	d11, d10, [sp, #0x20]
    1cfc:      	ldp	d13, d12, [sp, #0x10]
    1d00:      	ldp	d15, d14, [sp], #0xa0
    1d04:      	ret

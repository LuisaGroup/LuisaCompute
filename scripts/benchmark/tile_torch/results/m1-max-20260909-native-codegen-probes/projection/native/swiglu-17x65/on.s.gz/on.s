
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/swiglu-17x65/on/object/tile_xir_w8_37978_1788936541147468_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d11, d10, [sp, #-0x30]!
       4:      	stp	d9, d8, [sp, #0x10]
       8:      	stp	x28, x27, [sp, #0x20]
       c:      	sub	sp, sp, #0x240
      10:      	ldr	x13, [x0]
      14:      	ldr	x10, [x0, #0x10]
      18:      	ldr	x8, [x0, #0x30]
      1c:      	ldr	w9, [x1]
      20:      	ldr	w11, [x1, #0x24]
      24:      	add	w9, w11, w9, lsl #5
      28:      	lsr	w9, w9, #3
      2c:      	subs	x11, x13, x8
      30:      	lsr	x11, x11, #2
      34:      	mov	w12, #0x450             ; =1104
      38:      	ccmp	x11, x12, #0x0, hs
      3c:      	cset	w11, hi
      40:      	subs	x14, x8, x13
      44:      	lsr	x14, x14, #2
      48:      	ccmp	x14, x12, #0x0, hs
      4c:      	csinc	w14, w11, wzr, ls
      50:      	subs	x11, x10, x8
      54:      	lsr	x11, x11, #2
      58:      	ccmp	x11, x12, #0x0, hs
      5c:      	cset	w11, hi
      60:      	subs	x15, x8, x10
      64:      	lsr	x15, x15, #2
      68:      	ccmp	x15, x12, #0x0, hs
      6c:      	csinc	w12, w11, wzr, ls
      70:      	mov	w11, #0x104             ; =260
      74:      	umull	x11, w9, w11
      78:      	cmp	w14, #0x1
      7c:      	ccmp	w12, #0x0, #0x4, eq
      80:      	b.ne	0x4b0 <ltmp0+0x4b0>
      84:      	mov	x12, #0x0               ; =0
      88:      	add	x9, x13, x11
      8c:      	ldp	q0, q1, [x9, #0xc0]
      90:      	stp	q0, q1, [sp, #0x1e0]
      94:      	ldp	q0, q1, [x9, #0xe0]
      98:      	stp	q0, q1, [sp, #0x200]
      9c:      	ldp	q0, q1, [x9, #0x80]
      a0:      	stp	q0, q1, [sp, #0x1a0]
      a4:      	ldp	q0, q1, [x9, #0xa0]
      a8:      	stp	q0, q1, [sp, #0x1c0]
      ac:      	ldp	q0, q1, [x9, #0x40]
      b0:      	stp	q0, q1, [sp, #0x160]
      b4:      	ldp	q0, q1, [x9, #0x60]
      b8:      	stp	q0, q1, [sp, #0x180]
      bc:      	ldp	q0, q1, [x9]
      c0:      	stp	q0, q1, [sp, #0x120]
      c4:      	ldp	q0, q1, [x9, #0x20]
      c8:      	stp	q0, q1, [sp, #0x140]
      cc:      	add	x9, x11, #0x100
      d0:      	ldr	s1, [x13, x9]
      d4:      	str	q1, [sp, #0x220]
      d8:      	add	x13, x10, x11
      dc:      	ldp	q0, q2, [x13, #0xc0]
      e0:      	stp	q0, q2, [sp, #0xc0]
      e4:      	ldp	q0, q2, [x13, #0xe0]
      e8:      	stp	q0, q2, [sp, #0xe0]
      ec:      	ldp	q0, q2, [x13, #0x80]
      f0:      	stp	q0, q2, [sp, #0x80]
      f4:      	ldp	q0, q2, [x13, #0xa0]
      f8:      	stp	q0, q2, [sp, #0xa0]
      fc:      	ldp	q0, q2, [x13, #0x40]
     100:      	stp	q0, q2, [sp, #0x40]
     104:      	ldp	q0, q2, [x13, #0x60]
     108:      	stp	q0, q2, [sp, #0x60]
     10c:      	ldp	q2, q22, [x13]
     110:      	ldp	q23, q24, [x13, #0x20]
     114:      	ldr	s0, [x10, x9]
     118:      	add	x10, x8, x11
     11c:      	mov	w11, #0x42d00000        ; =1120927744
     120:      	dup.4s	v3, w11
     124:      	mov	w11, #-0x3d380000       ; =-1027080192
     128:      	dup.4s	v4, w11
     12c:      	mov	w11, #0xaa3b            ; =43579
     130:      	movk	w11, #0x3fb8, lsl #16
     134:      	dup.4s	v5, w11
     138:      	add	x11, sp, #0x120
     13c:      	movi.4s	v6, #0x4b, lsl #24
     140:      	mvni.4s	v7, #0x80, lsl #24
     144:      	mov	w13, #0x7200            ; =29184
     148:      	movk	w13, #0xbf31, lsl #16
     14c:      	dup.4s	v16, w13
     150:      	mov	w13, #0xbe8e            ; =48782
     154:      	movk	w13, #0xb5bf, lsl #16
     158:      	dup.4s	v17, w13
     15c:      	mov	w13, #0x2bda            ; =11226
     160:      	movk	w13, #0x3950, lsl #16
     164:      	dup.4s	v18, w13
     168:      	mov	w13, #0x96c9            ; =38601
     16c:      	movk	w13, #0x3ab6, lsl #16
     170:      	dup.4s	v19, w13
     174:      	mov	w13, #0x88a6            ; =34982
     178:      	movk	w13, #0x3c08, lsl #16
     17c:      	dup.4s	v20, w13
     180:      	mov	w13, #0xaa7a            ; =43642
     184:      	movk	w13, #0x3d2a, lsl #16
     188:      	dup.4s	v21, w13
     18c:      	mov	w13, #0xaaab            ; =43691
     190:      	movk	w13, #0x3e2a, lsl #16
     194:      	stp	q2, q22, [sp]
     198:      	movi.4s	v22, #0x3f, lsl #24
     19c:      	fmov.4s	v2, #1.00000000
     1a0:      	mvni.4s	v25, #0x7f, msl #16
     1a4:      	stp	q23, q24, [sp, #0x20]
     1a8:      	fneg.4s	v23, v25
     1ac:      	dup.4s	v24, w13
     1b0:      	mvni.4s	v25, #0x3f, msl #16
     1b4:      	fneg.4s	v25, v25
     1b8:      	mov	x13, sp
     1bc:      	str	q0, [sp, #0x100]
     1c0:      	add	x14, x11, x12
     1c4:      	ldp	q26, q27, [x14]
     1c8:      	fneg.4s	v28, v27
     1cc:      	fneg.4s	v29, v26
     1d0:      	fcmge.4s	v30, v3, v26
     1d4:      	fcmge.4s	v31, v3, v27
     1d8:      	fcmge.4s	v8, v26, v4
     1dc:      	fcmge.4s	v9, v27, v4
     1e0:      	and.16b	v31, v31, v9
     1e4:      	and.16b	v30, v30, v8
     1e8:      	and.16b	v29, v30, v29
     1ec:      	and.16b	v28, v31, v28
     1f0:      	fmul.4s	v30, v28, v5
     1f4:      	fmul.4s	v31, v29, v5
     1f8:      	mov.16b	v8, v7
     1fc:      	bsl.16b	v8, v6, v31
     200:      	mov.16b	v9, v7
     204:      	bsl.16b	v9, v6, v30
     208:      	fadd.4s	v30, v30, v9
     20c:      	fadd.4s	v31, v31, v8
     210:      	fsub.4s	v31, v31, v8
     214:      	fsub.4s	v30, v30, v9
     218:      	fcvtzs.4s	v30, v30
     21c:      	fcvtzs.4s	v31, v31
     220:      	scvtf.4s	v8, v31
     224:      	scvtf.4s	v9, v30
     228:      	fmul.4s	v10, v9, v16
     22c:      	fmul.4s	v11, v8, v16
     230:      	fadd.4s	v29, v29, v11
     234:      	fadd.4s	v28, v28, v10
     238:      	fmul.4s	v8, v8, v17
     23c:      	fmul.4s	v9, v9, v17
     240:      	fadd.4s	v28, v28, v9
     244:      	fadd.4s	v29, v29, v8
     248:      	fmul.4s	v8, v29, v18
     24c:      	fmul.4s	v9, v28, v18
     250:      	fadd.4s	v9, v9, v19
     254:      	fadd.4s	v8, v8, v19
     258:      	fmul.4s	v8, v29, v8
     25c:      	fmul.4s	v9, v28, v9
     260:      	fadd.4s	v9, v9, v20
     264:      	fadd.4s	v8, v8, v20
     268:      	fmul.4s	v8, v29, v8
     26c:      	fmul.4s	v9, v28, v9
     270:      	fadd.4s	v9, v9, v21
     274:      	fadd.4s	v8, v8, v21
     278:      	fmul.4s	v8, v29, v8
     27c:      	fmul.4s	v9, v28, v9
     280:      	fadd.4s	v9, v9, v24
     284:      	fadd.4s	v8, v8, v24
     288:      	fmul.4s	v8, v29, v8
     28c:      	fmul.4s	v9, v28, v9
     290:      	fadd.4s	v9, v9, v22
     294:      	fadd.4s	v8, v8, v22
     298:      	fmul.4s	v10, v28, v28
     29c:      	fmul.4s	v11, v29, v29
     2a0:      	fmul.4s	v8, v11, v8
     2a4:      	fmul.4s	v9, v10, v9
     2a8:      	fadd.4s	v28, v28, v9
     2ac:      	fadd.4s	v29, v29, v8
     2b0:      	sshr.4s	v8, v31, #0x1
     2b4:      	fadd.4s	v29, v29, v2
     2b8:      	sshr.4s	v9, v30, #0x1
     2bc:      	shl.4s	v10, v9, #0x17
     2c0:      	shl.4s	v11, v8, #0x17
     2c4:      	add.4s	v11, v11, v2
     2c8:      	add.4s	v10, v10, v2
     2cc:      	fadd.4s	v28, v28, v2
     2d0:      	fmul.4s	v28, v28, v10
     2d4:      	sub.4s	v30, v30, v9
     2d8:      	sub.4s	v31, v31, v8
     2dc:      	shl.4s	v31, v31, #0x17
     2e0:      	shl.4s	v30, v30, #0x17
     2e4:      	fmul.4s	v29, v29, v11
     2e8:      	add.4s	v30, v30, v2
     2ec:      	add.4s	v31, v31, v2
     2f0:      	fmul.4s	v29, v29, v31
     2f4:      	fmul.4s	v28, v28, v30
     2f8:      	fcmgt.4s	v30, v27, v3
     2fc:      	fcmgt.4s	v31, v26, v3
     300:      	fcmgt.4s	v8, v4, v26
     304:      	fcmgt.4s	v9, v4, v27
     308:      	fcmeq.4s	v10, v27, v27
     30c:      	fadd.4s	v28, v28, v2
     310:      	fadd.4s	v29, v29, v2
     314:      	fcmeq.4s	v11, v26, v26
     318:      	bit.16b	v29, v2, v31
     31c:      	bit.16b	v28, v2, v30
     320:      	bit.16b	v28, v23, v9
     324:      	bit.16b	v29, v23, v8
     328:      	bif.16b	v29, v25, v11
     32c:      	bif.16b	v28, v25, v10
     330:      	fdiv.4s	v27, v27, v28
     334:      	fdiv.4s	v26, v26, v29
     338:      	add	x14, x13, x12
     33c:      	ldp	q29, q28, [x14]
     340:      	fmul.4s	v26, v29, v26
     344:      	fmul.4s	v27, v28, v27
     348:      	add	x14, x10, x12
     34c:      	stp	q26, q27, [x14]
     350:      	add	x12, x12, #0x20
     354:      	cmp	x12, #0x100
     358:      	b.ne	0x1c0 <ltmp0+0x1c0>
     35c:      	movi.2d	v4, #0000000000000000
     360:      	movi.2d	v3, #0000000000000000
     364:      	mov.s	v3[0], v1[0]
     368:      	fneg.4s	v1, v3
     36c:      	mov.s	v4[0], v1[0]
     370:      	mov	w10, #-0x3d300000       ; =-1026555904
     374:      	dup.4s	v1, w10
     378:      	fcmge.4s	v5, v4, v1
     37c:      	mov	w10, #0x42c80000        ; =1120403456
     380:      	dup.4s	v6, w10
     384:      	fcmge.4s	v7, v6, v4
     388:      	and.16b	v5, v5, v7
     38c:      	and.16b	v5, v5, v4
     390:      	mov	w10, #0xaa3b            ; =43579
     394:      	movk	w10, #0x3fb8, lsl #16
     398:      	dup.4s	v7, w10
     39c:      	fmul.4s	v7, v5, v7
     3a0:      	movi.4s	v16, #0x4b, lsl #24
     3a4:      	mvni.4s	v17, #0x80, lsl #24
     3a8:      	bif.16b	v16, v7, v17
     3ac:      	fadd.4s	v7, v7, v16
     3b0:      	fsub.4s	v7, v7, v16
     3b4:      	fcvtzs.4s	v7, v7
     3b8:      	scvtf.4s	v16, v7
     3bc:      	mov	w10, #0x7200            ; =29184
     3c0:      	movk	w10, #0xbf31, lsl #16
     3c4:      	dup.4s	v17, w10
     3c8:      	fmul.4s	v17, v16, v17
     3cc:      	mov	w10, #0xbe8e            ; =48782
     3d0:      	movk	w10, #0xb5bf, lsl #16
     3d4:      	dup.4s	v18, w10
     3d8:      	fadd.4s	v5, v5, v17
     3dc:      	fmul.4s	v16, v16, v18
     3e0:      	fadd.4s	v5, v5, v16
     3e4:      	mov	w10, #0x2bda            ; =11226
     3e8:      	movk	w10, #0x3950, lsl #16
     3ec:      	dup.4s	v16, w10
     3f0:      	fmul.4s	v16, v5, v16
     3f4:      	mov	w10, #0x96c9            ; =38601
     3f8:      	movk	w10, #0x3ab6, lsl #16
     3fc:      	dup.4s	v17, w10
     400:      	fadd.4s	v16, v16, v17
     404:      	fmul.4s	v16, v5, v16
     408:      	mov	w10, #0x88a6            ; =34982
     40c:      	movk	w10, #0x3c08, lsl #16
     410:      	dup.4s	v17, w10
     414:      	fadd.4s	v16, v16, v17
     418:      	fmul.4s	v16, v5, v16
     41c:      	mov	w10, #0xaa7a            ; =43642
     420:      	movk	w10, #0x3d2a, lsl #16
     424:      	dup.4s	v17, w10
     428:      	fadd.4s	v16, v16, v17
     42c:      	mov	w10, #0xaaab            ; =43691
     430:      	movk	w10, #0x3e2a, lsl #16
     434:      	dup.4s	v17, w10
     438:      	fmul.4s	v16, v5, v16
     43c:      	fadd.4s	v16, v16, v17
     440:      	fmul.4s	v16, v5, v16
     444:      	movi.4s	v17, #0x3f, lsl #24
     448:      	fadd.4s	v16, v16, v17
     44c:      	fmul.4s	v17, v5, v5
     450:      	fmul.4s	v16, v17, v16
     454:      	fadd.4s	v5, v5, v16
     458:      	fadd.4s	v5, v5, v2
     45c:      	sshr.4s	v16, v7, #0x1
     460:      	shl.4s	v17, v16, #0x17
     464:      	add.4s	v17, v17, v2
     468:      	fmul.4s	v5, v5, v17
     46c:      	sub.4s	v7, v7, v16
     470:      	shl.4s	v7, v7, #0x17
     474:      	add.4s	v7, v7, v2
     478:      	fmul.4s	v5, v5, v7
     47c:      	fcmgt.4s	v1, v1, v4
     480:      	fcmgt.4s	v6, v4, v6
     484:      	fcmeq.4s	v4, v4, v4
     488:      	fadd.4s	v5, v5, v2
     48c:      	bsl.16b	v1, v2, v5
     490:      	mvni.4s	v2, #0x7f, msl #16
     494:      	fneg.4s	v2, v2
     498:      	bit.16b	v1, v2, v6
     49c:      	mvni.4s	v2, #0x3f, msl #16
     4a0:      	fneg.4s	v2, v2
     4a4:      	bif.16b	v1, v2, v4
     4a8:      	fdiv.4s	v1, v3, v1
     4ac:      	b	0x840 <ltmp0+0x840>
     4b0:      	mov	x9, #0x0                ; =0
     4b4:      	add	x12, x8, x11
     4b8:      	add	x14, x10, x11
     4bc:      	mov	w15, #0x42d00000        ; =1120927744
     4c0:      	dup.4s	v1, w15
     4c4:      	mov	w15, #-0x3d380000       ; =-1027080192
     4c8:      	dup.4s	v2, w15
     4cc:      	mov	w15, #0xaa3b            ; =43579
     4d0:      	movk	w15, #0x3fb8, lsl #16
     4d4:      	dup.4s	v3, w15
     4d8:      	mov	w15, #0x7200            ; =29184
     4dc:      	movk	w15, #0xbf31, lsl #16
     4e0:      	dup.4s	v4, w15
     4e4:      	mov	w15, #0xbe8e            ; =48782
     4e8:      	movk	w15, #0xb5bf, lsl #16
     4ec:      	dup.4s	v5, w15
     4f0:      	mov	w15, #0x2bda            ; =11226
     4f4:      	movk	w15, #0x3950, lsl #16
     4f8:      	dup.4s	v6, w15
     4fc:      	mov	w15, #0x96c9            ; =38601
     500:      	movk	w15, #0x3ab6, lsl #16
     504:      	dup.4s	v7, w15
     508:      	mov	w15, #0x88a6            ; =34982
     50c:      	movk	w15, #0x3c08, lsl #16
     510:      	dup.4s	v16, w15
     514:      	mov	w15, #0xaa7a            ; =43642
     518:      	movk	w15, #0x3d2a, lsl #16
     51c:      	dup.4s	v17, w15
     520:      	mov	w15, #0xaaab            ; =43691
     524:      	movk	w15, #0x3e2a, lsl #16
     528:      	dup.4s	v18, w15
     52c:      	add	x15, x13, x11
     530:      	movi.4s	v19, #0x4b, lsl #24
     534:      	mvni.4s	v20, #0x80, lsl #24
     538:      	movi.4s	v21, #0x3f, lsl #24
     53c:      	fmov.4s	v0, #1.00000000
     540:      	mvni.4s	v22, #0x7f, msl #16
     544:      	fneg.4s	v22, v22
     548:      	mvni.4s	v23, #0x3f, msl #16
     54c:      	fneg.4s	v23, v23
     550:      	add	x16, x15, x9
     554:      	ldp	q24, q25, [x16]
     558:      	fneg.4s	v26, v25
     55c:      	fneg.4s	v27, v24
     560:      	fcmge.4s	v28, v1, v24
     564:      	fcmge.4s	v29, v1, v25
     568:      	fcmge.4s	v30, v24, v2
     56c:      	fcmge.4s	v31, v25, v2
     570:      	and.16b	v29, v29, v31
     574:      	and.16b	v28, v28, v30
     578:      	and.16b	v27, v28, v27
     57c:      	and.16b	v26, v29, v26
     580:      	fmul.4s	v28, v26, v3
     584:      	fmul.4s	v29, v27, v3
     588:      	mov.16b	v30, v20
     58c:      	bsl.16b	v30, v19, v29
     590:      	mov.16b	v31, v20
     594:      	bsl.16b	v31, v19, v28
     598:      	fadd.4s	v28, v28, v31
     59c:      	fadd.4s	v29, v29, v30
     5a0:      	fsub.4s	v29, v29, v30
     5a4:      	fsub.4s	v28, v28, v31
     5a8:      	fcvtzs.4s	v28, v28
     5ac:      	fcvtzs.4s	v29, v29
     5b0:      	scvtf.4s	v30, v29
     5b4:      	scvtf.4s	v31, v28
     5b8:      	fmul.4s	v8, v31, v4
     5bc:      	fmul.4s	v9, v30, v4
     5c0:      	fadd.4s	v27, v27, v9
     5c4:      	fadd.4s	v26, v26, v8
     5c8:      	fmul.4s	v30, v30, v5
     5cc:      	fmul.4s	v31, v31, v5
     5d0:      	fadd.4s	v26, v26, v31
     5d4:      	fadd.4s	v27, v27, v30
     5d8:      	fmul.4s	v30, v27, v6
     5dc:      	fmul.4s	v31, v26, v6
     5e0:      	fadd.4s	v31, v31, v7
     5e4:      	fadd.4s	v30, v30, v7
     5e8:      	fmul.4s	v30, v27, v30
     5ec:      	fmul.4s	v31, v26, v31
     5f0:      	fadd.4s	v31, v31, v16
     5f4:      	fadd.4s	v30, v30, v16
     5f8:      	fmul.4s	v30, v27, v30
     5fc:      	fmul.4s	v31, v26, v31
     600:      	fadd.4s	v31, v31, v17
     604:      	fadd.4s	v30, v30, v17
     608:      	fmul.4s	v30, v27, v30
     60c:      	fmul.4s	v31, v26, v31
     610:      	fadd.4s	v31, v31, v18
     614:      	fadd.4s	v30, v30, v18
     618:      	fmul.4s	v30, v27, v30
     61c:      	fmul.4s	v31, v26, v31
     620:      	fadd.4s	v31, v31, v21
     624:      	fadd.4s	v30, v30, v21
     628:      	fmul.4s	v8, v26, v26
     62c:      	fmul.4s	v9, v27, v27
     630:      	fmul.4s	v30, v9, v30
     634:      	fmul.4s	v31, v8, v31
     638:      	fadd.4s	v26, v26, v31
     63c:      	fadd.4s	v27, v27, v30
     640:      	sshr.4s	v30, v29, #0x1
     644:      	fadd.4s	v27, v27, v0
     648:      	sshr.4s	v31, v28, #0x1
     64c:      	shl.4s	v8, v31, #0x17
     650:      	shl.4s	v9, v30, #0x17
     654:      	add.4s	v9, v9, v0
     658:      	add.4s	v8, v8, v0
     65c:      	fadd.4s	v26, v26, v0
     660:      	fmul.4s	v26, v26, v8
     664:      	sub.4s	v28, v28, v31
     668:      	sub.4s	v29, v29, v30
     66c:      	shl.4s	v29, v29, #0x17
     670:      	shl.4s	v28, v28, #0x17
     674:      	fmul.4s	v27, v27, v9
     678:      	add.4s	v28, v28, v0
     67c:      	add.4s	v29, v29, v0
     680:      	fmul.4s	v27, v27, v29
     684:      	fmul.4s	v26, v26, v28
     688:      	fcmgt.4s	v28, v25, v1
     68c:      	fcmgt.4s	v29, v24, v1
     690:      	fcmgt.4s	v30, v2, v24
     694:      	fcmgt.4s	v31, v2, v25
     698:      	fcmeq.4s	v8, v25, v25
     69c:      	fadd.4s	v26, v26, v0
     6a0:      	fadd.4s	v27, v27, v0
     6a4:      	fcmeq.4s	v9, v24, v24
     6a8:      	bit.16b	v27, v0, v29
     6ac:      	bit.16b	v26, v0, v28
     6b0:      	bit.16b	v26, v22, v31
     6b4:      	bit.16b	v27, v22, v30
     6b8:      	bif.16b	v27, v23, v9
     6bc:      	bif.16b	v26, v23, v8
     6c0:      	fdiv.4s	v25, v25, v26
     6c4:      	fdiv.4s	v24, v24, v27
     6c8:      	add	x16, x14, x9
     6cc:      	ldp	q27, q26, [x16]
     6d0:      	fmul.4s	v24, v27, v24
     6d4:      	fmul.4s	v25, v26, v25
     6d8:      	add	x16, x12, x9
     6dc:      	stp	q24, q25, [x16]
     6e0:      	add	x9, x9, #0x20
     6e4:      	cmp	x9, #0x100
     6e8:      	b.ne	0x550 <ltmp0+0x550>
     6ec:      	add	x9, x11, #0x100
     6f0:      	ldr	s1, [x13, x9]
     6f4:      	movi.2d	v2, #0000000000000000
     6f8:      	fneg.4s	v3, v1
     6fc:      	mov.s	v2[0], v3[0]
     700:      	mov	w11, #-0x3d300000       ; =-1026555904
     704:      	dup.4s	v3, w11
     708:      	mov	w11, #0x42c80000        ; =1120403456
     70c:      	dup.4s	v4, w11
     710:      	fcmge.4s	v5, v2, v3
     714:      	fcmge.4s	v6, v4, v2
     718:      	and.16b	v5, v5, v6
     71c:      	mov	w11, #0xaa3b            ; =43579
     720:      	movk	w11, #0x3fb8, lsl #16
     724:      	dup.4s	v6, w11
     728:      	and.16b	v5, v5, v2
     72c:      	fmul.4s	v6, v5, v6
     730:      	movi.4s	v7, #0x4b, lsl #24
     734:      	mvni.4s	v16, #0x80, lsl #24
     738:      	bif.16b	v7, v6, v16
     73c:      	fadd.4s	v6, v6, v7
     740:      	fsub.4s	v6, v6, v7
     744:      	fcvtzs.4s	v6, v6
     748:      	scvtf.4s	v7, v6
     74c:      	mov	w11, #0x7200            ; =29184
     750:      	movk	w11, #0xbf31, lsl #16
     754:      	dup.4s	v16, w11
     758:      	fmul.4s	v16, v7, v16
     75c:      	fadd.4s	v5, v5, v16
     760:      	mov	w11, #0xbe8e            ; =48782
     764:      	movk	w11, #0xb5bf, lsl #16
     768:      	dup.4s	v16, w11
     76c:      	fmul.4s	v7, v7, v16
     770:      	fadd.4s	v5, v5, v7
     774:      	mov	w11, #0x2bda            ; =11226
     778:      	movk	w11, #0x3950, lsl #16
     77c:      	dup.4s	v7, w11
     780:      	fmul.4s	v7, v5, v7
     784:      	mov	w11, #0x96c9            ; =38601
     788:      	movk	w11, #0x3ab6, lsl #16
     78c:      	dup.4s	v16, w11
     790:      	fadd.4s	v7, v7, v16
     794:      	mov	w11, #0x88a6            ; =34982
     798:      	movk	w11, #0x3c08, lsl #16
     79c:      	dup.4s	v16, w11
     7a0:      	fmul.4s	v7, v5, v7
     7a4:      	fadd.4s	v7, v7, v16
     7a8:      	fmul.4s	v7, v5, v7
     7ac:      	mov	w11, #0xaa7a            ; =43642
     7b0:      	movk	w11, #0x3d2a, lsl #16
     7b4:      	dup.4s	v16, w11
     7b8:      	fadd.4s	v7, v7, v16
     7bc:      	fmul.4s	v7, v5, v7
     7c0:      	mov	w11, #0xaaab            ; =43691
     7c4:      	movk	w11, #0x3e2a, lsl #16
     7c8:      	dup.4s	v16, w11
     7cc:      	fadd.4s	v7, v7, v16
     7d0:      	fmul.4s	v7, v5, v7
     7d4:      	movi.4s	v16, #0x3f, lsl #24
     7d8:      	fadd.4s	v7, v7, v16
     7dc:      	fmul.4s	v16, v5, v5
     7e0:      	fmul.4s	v7, v16, v7
     7e4:      	fadd.4s	v5, v5, v7
     7e8:      	fadd.4s	v5, v5, v0
     7ec:      	sshr.4s	v7, v6, #0x1
     7f0:      	shl.4s	v16, v7, #0x17
     7f4:      	add.4s	v16, v16, v0
     7f8:      	fmul.4s	v5, v5, v16
     7fc:      	sub.4s	v6, v6, v7
     800:      	shl.4s	v6, v6, #0x17
     804:      	add.4s	v6, v6, v0
     808:      	fmul.4s	v5, v5, v6
     80c:      	fcmgt.4s	v3, v3, v2
     810:      	fcmgt.4s	v4, v2, v4
     814:      	fcmeq.4s	v2, v2, v2
     818:      	fadd.4s	v5, v5, v0
     81c:      	bif.16b	v0, v5, v3
     820:      	mvni.4s	v3, #0x7f, msl #16
     824:      	fneg.4s	v3, v3
     828:      	bit.16b	v0, v3, v4
     82c:      	mvni.4s	v3, #0x3f, msl #16
     830:      	fneg.4s	v3, v3
     834:      	bif.16b	v0, v3, v2
     838:      	fdiv.4s	v0, v1, v0
     83c:      	ldr	s1, [x10, x9]
     840:      	fmul.4s	v0, v1, v0
     844:      	str	s0, [x8, x9]
     848:      	add	sp, sp, #0x240
     84c:      	ldp	x28, x27, [sp, #0x20]
     850:      	ldp	d9, d8, [sp, #0x10]
     854:      	ldp	d11, d10, [sp], #0x30
     858:      	ret

000000000000085c <_llm_rows.packet_batch.blocks>:
     85c:      	stp	d15, d14, [sp, #-0xa0]!
     860:      	stp	d13, d12, [sp, #0x10]
     864:      	stp	d11, d10, [sp, #0x20]
     868:      	stp	d9, d8, [sp, #0x30]
     86c:      	stp	x28, x27, [sp, #0x40]
     870:      	stp	x26, x25, [sp, #0x50]
     874:      	stp	x24, x23, [sp, #0x60]
     878:      	stp	x22, x21, [sp, #0x70]
     87c:      	stp	x20, x19, [sp, #0x80]
     880:      	stp	x29, x30, [sp, #0x90]
     884:      	sub	sp, sp, #0x4d0
     888:      	str	x0, [sp, #0xe8]
     88c:      	cbz	w3, 0x1cbc <_llm_rows.packet_batch.blocks+0x1460>
     890:      	mov	x19, x3
     894:      	mov	x20, x2
     898:      	mov	w22, #0x0               ; =0
     89c:      	ldp	w9, w8, [x2, #0x2c]
     8a0:      	stp	w8, w9, [sp, #0xe0]
     8a4:      	ldp	w26, w27, [x2]
     8a8:      	adrp	x8, 0x0 <ltmp0>
     8ac:      	ldr	q0, [x8]
     8b0:      	str	q0, [sp, #0xc0]
     8b4:      	adrp	x8, 0x0 <ltmp0>
     8b8:      	ldr	q0, [x8]
     8bc:      	str	q0, [sp, #0xb0]
     8c0:      	adrp	x8, 0x0 <ltmp0>
     8c4:      	ldr	q0, [x8]
     8c8:      	str	q0, [sp, #0xa0]
     8cc:      	adrp	x8, 0x0 <ltmp0>
     8d0:      	ldr	q0, [x8]
     8d4:      	str	q0, [sp, #0x90]
     8d8:      	adrp	x8, 0x0 <ltmp0>
     8dc:      	ldr	q0, [x8]
     8e0:      	str	q0, [sp, #0x80]
     8e4:      	adrp	x8, 0x0 <ltmp0>
     8e8:      	ldr	q0, [x8]
     8ec:      	str	q0, [sp, #0x70]
     8f0:      	adrp	x8, 0x0 <ltmp0>
     8f4:      	ldr	q1, [x8]
     8f8:      	mvni.4s	v0, #0x7f, msl #16
     8fc:      	fneg.4s	v0, v0
     900:      	str	q0, [sp, #0x110]
     904:      	mvni.4s	v0, #0x3f, msl #16
     908:      	fneg.4s	v0, v0
     90c:      	stp	q1, q0, [sp, #0xf0]
     910:      	add	x25, sp, #0x3b0
     914:      	ldp	w28, w23, [x2, #0x8]
     918:      	add	x24, sp, #0x290
     91c:      	str	w3, [sp, #0xdc]
     920:      	b	0x968 <_llm_rows.packet_batch.blocks+0x10c>
     924:      	mov	w8, #0x18               ; =24
     928:      	str	w8, [x20, #0x24]
     92c:      	ldr	w19, [sp, #0xdc]
     930:      	add	w8, w26, #0x1
     934:      	ldp	w10, w9, [sp, #0xe0]
     938:      	cmp	w8, w9
     93c:      	cset	w8, eq
     940:      	csinc	w26, wzr, w26, eq
     944:      	cinc	w9, w27, eq
     948:      	cmp	w9, w10
     94c:      	cset	w10, eq
     950:      	ands	w8, w8, w10
     954:      	csel	w27, wzr, w9, ne
     958:      	add	w28, w28, w8
     95c:      	add	w22, w22, #0x1
     960:      	cmp	w22, w19
     964:      	b.eq	0x1cbc <_llm_rows.packet_batch.blocks+0x1460>
     968:      	ubfiz	x8, x26, #5, #32
     96c:      	cmp	x8, x23
     970:      	csel	x9, x8, xzr, ls
     974:      	subs	x10, x23, x9
     978:      	cmp	x10, #0x20
     97c:      	mov	w11, #0x20              ; =32
     980:      	csel	x10, x10, x11, lo
     984:      	cmp	x23, x9
     988:      	stp	w26, w27, [x20]
     98c:      	str	w28, [x20, #0x8]
     990:      	str	wzr, [x20, #0x24]
     994:      	ccmp	x8, x23, #0x2, hi
     998:      	csel	x21, x10, xzr, ls
     99c:      	cmp	x21, #0x20
     9a0:      	b.lo	0x9f4 <_llm_rows.packet_batch.blocks+0x198>
     9a4:      	ldr	x21, [sp, #0xe8]
     9a8:      	mov	x0, x21
     9ac:      	mov	x1, x20
     9b0:      	bl	0x9b0 <_llm_rows.packet_batch.blocks+0x154>
     9b4:      	mov	w8, #0x8                ; =8
     9b8:      	str	w8, [x20, #0x24]
     9bc:      	mov	x0, x21
     9c0:      	mov	x1, x20
     9c4:      	bl	0x9c4 <_llm_rows.packet_batch.blocks+0x168>
     9c8:      	mov	w8, #0x10               ; =16
     9cc:      	str	w8, [x20, #0x24]
     9d0:      	mov	x0, x21
     9d4:      	mov	x1, x20
     9d8:      	bl	0x9d8 <_llm_rows.packet_batch.blocks+0x17c>
     9dc:      	mov	w8, #0x18               ; =24
     9e0:      	str	w8, [x20, #0x24]
     9e4:      	mov	x0, x21
     9e8:      	mov	x1, x20
     9ec:      	bl	0x9ec <_llm_rows.packet_batch.blocks+0x190>
     9f0:      	b	0x930 <_llm_rows.packet_batch.blocks+0xd4>
     9f4:      	lsr	x19, x21, #3
     9f8:      	cmp	x21, #0x8
     9fc:      	b.lo	0xa48 <_llm_rows.packet_batch.blocks+0x1ec>
     a00:      	str	wzr, [x20, #0x24]
     a04:      	ldr	x0, [sp, #0xe8]
     a08:      	mov	x1, x20
     a0c:      	bl	0xa0c <_llm_rows.packet_batch.blocks+0x1b0>
     a10:      	cmp	x19, #0x1
     a14:      	b.eq	0xa48 <_llm_rows.packet_batch.blocks+0x1ec>
     a18:      	mov	w8, #0x8                ; =8
     a1c:      	str	w8, [x20, #0x24]
     a20:      	ldr	x0, [sp, #0xe8]
     a24:      	mov	x1, x20
     a28:      	bl	0xa28 <_llm_rows.packet_batch.blocks+0x1cc>
     a2c:      	cmp	x19, #0x2
     a30:      	b.eq	0xa48 <_llm_rows.packet_batch.blocks+0x1ec>
     a34:      	mov	w8, #0x10               ; =16
     a38:      	str	w8, [x20, #0x24]
     a3c:      	ldr	x0, [sp, #0xe8]
     a40:      	mov	x1, x20
     a44:      	bl	0xa44 <_llm_rows.packet_batch.blocks+0x1e8>
     a48:      	and	w8, w21, #0x7
     a4c:      	cbz	w8, 0x924 <_llm_rows.packet_batch.blocks+0xc8>
     a50:      	dup.4s	v0, w8
     a54:      	ldp	q2, q1, [sp, #0xb0]
     a58:      	cmhi.4s	v19, v0, v2
     a5c:      	cmhi.4s	v20, v0, v1
     a60:      	uzp1.8h	v31, v20, v19
     a64:      	umaxv.8h	h0, v31
     a68:      	fmov	w8, s0
     a6c:      	tbz	w8, #0x0, 0x924 <_llm_rows.packet_batch.blocks+0xc8>
     a70:      	ldr	x8, [sp, #0xe8]
     a74:      	ldr	x11, [x8]
     a78:      	ldr	x9, [x8, #0x10]
     a7c:      	ldr	x8, [x8, #0x30]
     a80:      	xtn.4h	v29, v20
     a84:      	uzp1.8b	v0, v29, v0
     a88:      	sshll.2d	v1, v20, #0x0
     a8c:      	sshll.2d	v2, v19, #0x0
     a90:      	sshll2.2d	v10, v20, #0x0
     a94:      	sshll2.2d	v9, v19, #0x0
     a98:      	ldp	q3, q4, [sp, #0x90]
     a9c:      	and.16b	v21, v9, v4
     aa0:      	and.16b	v23, v10, v3
     aa4:      	ldp	q3, q4, [sp, #0x70]
     aa8:      	and.16b	v22, v2, v4
     aac:      	ubfiz	w10, w26, #2, #27
     ab0:      	orr	w12, w10, w19
     ab4:      	dup.4s	v2, w12
     ab8:      	and.16b	v28, v1, v3
     abc:      	and.16b	v1, v20, v2
     ac0:      	and.16b	v2, v19, v2
     ac4:      	ushll2.2d	v24, v2, #0x0
     ac8:      	ushll2.2d	v26, v1, #0x0
     acc:      	ushll.2d	v25, v2, #0x0
     ad0:      	ushll.2d	v27, v1, #0x0
     ad4:      	subs	x10, x11, x8
     ad8:      	lsr	x10, x10, #2
     adc:      	mov	w15, #0x450             ; =1104
     ae0:      	ccmp	x10, x15, #0x0, hs
     ae4:      	cset	w10, hi
     ae8:      	subs	x13, x8, x11
     aec:      	lsr	x13, x13, #2
     af0:      	ccmp	x13, x15, #0x0, hs
     af4:      	csinc	w14, w10, wzr, ls
     af8:      	subs	x10, x9, x8
     afc:      	lsr	x10, x10, #2
     b00:      	ccmp	x10, x15, #0x0, hs
     b04:      	cset	w10, hi
     b08:      	subs	x13, x8, x9
     b0c:      	lsr	x13, x13, #2
     b10:      	ccmp	x13, x15, #0x0, hs
     b14:      	umov.b	w13, v0[0]
     b18:      	csinc	w10, w10, wzr, ls
     b1c:      	mov	w15, #0x104             ; =260
     b20:      	umull	x12, w12, w15
     b24:      	tst	w13, #0x1
     b28:      	csel	x12, x12, xzr, ne
     b2c:      	mov	w15, #-0x3d300000       ; =-1026555904
     b30:      	dup.4s	v1, w15
     b34:      	mov	w15, #0x42c80000        ; =1120403456
     b38:      	dup.4s	v0, w15
     b3c:      	mov	w15, #0xaa3b            ; =43579
     b40:      	movk	w15, #0x3fb8, lsl #16
     b44:      	dup.4s	v18, w15
     b48:      	mov	w15, #0x7200            ; =29184
     b4c:      	movk	w15, #0xbf31, lsl #16
     b50:      	dup.4s	v17, w15
     b54:      	mov	w15, #0xbe8e            ; =48782
     b58:      	movk	w15, #0xb5bf, lsl #16
     b5c:      	dup.4s	v16, w15
     b60:      	mov	w15, #0x2bda            ; =11226
     b64:      	movk	w15, #0x3950, lsl #16
     b68:      	dup.4s	v7, w15
     b6c:      	mov	w15, #0x96c9            ; =38601
     b70:      	movk	w15, #0x3ab6, lsl #16
     b74:      	dup.4s	v6, w15
     b78:      	mov	w15, #0x88a6            ; =34982
     b7c:      	movk	w15, #0x3c08, lsl #16
     b80:      	dup.4s	v5, w15
     b84:      	mov	w15, #0xaa7a            ; =43642
     b88:      	movk	w15, #0x3d2a, lsl #16
     b8c:      	dup.4s	v4, w15
     b90:      	mov	w15, #0xaaab            ; =43691
     b94:      	movk	w15, #0x3e2a, lsl #16
     b98:      	dup.4s	v3, w15
     b9c:      	fmov.4s	v2, #1.00000000
     ba0:      	xtn.2s	v30, v27
     ba4:      	xtn.2s	v24, v24
     ba8:      	xtn.2s	v25, v25
     bac:      	xtn.2s	v26, v26
     bb0:      	cmp	w14, #0x1
     bb4:      	b.ne	0xf4c <_llm_rows.packet_batch.blocks+0x6f0>
     bb8:      	cbz	w10, 0xf4c <_llm_rows.packet_batch.blocks+0x6f0>
     bbc:      	mov	x10, #0x0               ; =0
     bc0:      	add	x13, x8, x12
     bc4:      	add	x14, x9, x12
     bc8:      	add	x12, x11, x12
     bcc:      	ldr	q27, [sp, #0xf0]
     bd0:      	and.16b	v27, v31, v27
     bd4:      	addv.8h	h27, v27
     bd8:      	fmov	w15, s27
     bdc:      	b	0xbec <_llm_rows.packet_batch.blocks+0x390>
     be0:      	add	x10, x10, #0x20
     be4:      	cmp	x10, #0x100
     be8:      	b.eq	0x18bc <_llm_rows.packet_batch.blocks+0x1060>
     bec:      	add	x16, x12, x10
     bf0:      	movi.2d	v9, #0000000000000000
     bf4:      	movi.2d	v31, #0000000000000000
     bf8:      	tbz	w15, #0x0, 0xc8c <_llm_rows.packet_batch.blocks+0x430>
     bfc:      	ldr	s9, [x16]
     c00:      	and	w17, w15, #0xff
     c04:      	tbnz	w17, #0x1, 0xc94 <_llm_rows.packet_batch.blocks+0x438>
     c08:      	tbz	w17, #0x2, 0xca0 <_llm_rows.packet_batch.blocks+0x444>
     c0c:      	add	x0, x16, #0x8
     c10:      	ld1.s	{ v9 }[2], [x0]
     c14:      	tbnz	w17, #0x3, 0xca4 <_llm_rows.packet_batch.blocks+0x448>
     c18:      	tbz	w17, #0x4, 0xcb0 <_llm_rows.packet_batch.blocks+0x454>
     c1c:      	add	x0, x16, #0x10
     c20:      	ld1.s	{ v31 }[0], [x0]
     c24:      	tbnz	w17, #0x5, 0xcb4 <_llm_rows.packet_batch.blocks+0x458>
     c28:      	tbz	w17, #0x6, 0xcc0 <_llm_rows.packet_batch.blocks+0x464>
     c2c:      	add	x0, x16, #0x18
     c30:      	ld1.s	{ v31 }[2], [x0]
     c34:      	tbnz	w17, #0x7, 0xcc4 <_llm_rows.packet_batch.blocks+0x468>
     c38:      	fmov	w17, s27
     c3c:      	add	x16, x14, x10
     c40:      	movi.2d	v8, #0000000000000000
     c44:      	movi.2d	v10, #0000000000000000
     c48:      	tbz	w17, #0x0, 0xce0 <_llm_rows.packet_batch.blocks+0x484>
     c4c:      	ldr	s8, [x16]
     c50:      	and	w17, w17, #0xff
     c54:      	tbnz	w17, #0x1, 0xce8 <_llm_rows.packet_batch.blocks+0x48c>
     c58:      	tbz	w17, #0x2, 0xcf4 <_llm_rows.packet_batch.blocks+0x498>
     c5c:      	add	x0, x16, #0x8
     c60:      	ld1.s	{ v8 }[2], [x0]
     c64:      	tbnz	w17, #0x3, 0xcf8 <_llm_rows.packet_batch.blocks+0x49c>
     c68:      	tbz	w17, #0x4, 0xd04 <_llm_rows.packet_batch.blocks+0x4a8>
     c6c:      	add	x0, x16, #0x10
     c70:      	ld1.s	{ v10 }[0], [x0]
     c74:      	tbnz	w17, #0x5, 0xd08 <_llm_rows.packet_batch.blocks+0x4ac>
     c78:      	tbz	w17, #0x6, 0xd14 <_llm_rows.packet_batch.blocks+0x4b8>
     c7c:      	add	x0, x16, #0x18
     c80:      	ld1.s	{ v10 }[2], [x0]
     c84:      	tbnz	w17, #0x7, 0xd18 <_llm_rows.packet_batch.blocks+0x4bc>
     c88:      	b	0xd20 <_llm_rows.packet_batch.blocks+0x4c4>
     c8c:      	and	w17, w15, #0xff
     c90:      	tbz	w17, #0x1, 0xc08 <_llm_rows.packet_batch.blocks+0x3ac>
     c94:      	add	x0, x16, #0x4
     c98:      	ld1.s	{ v9 }[1], [x0]
     c9c:      	tbnz	w17, #0x2, 0xc0c <_llm_rows.packet_batch.blocks+0x3b0>
     ca0:      	tbz	w17, #0x3, 0xc18 <_llm_rows.packet_batch.blocks+0x3bc>
     ca4:      	add	x0, x16, #0xc
     ca8:      	ld1.s	{ v9 }[3], [x0]
     cac:      	tbnz	w17, #0x4, 0xc1c <_llm_rows.packet_batch.blocks+0x3c0>
     cb0:      	tbz	w17, #0x5, 0xc28 <_llm_rows.packet_batch.blocks+0x3cc>
     cb4:      	add	x0, x16, #0x14
     cb8:      	ld1.s	{ v31 }[1], [x0]
     cbc:      	tbnz	w17, #0x6, 0xc2c <_llm_rows.packet_batch.blocks+0x3d0>
     cc0:      	tbz	w17, #0x7, 0xc38 <_llm_rows.packet_batch.blocks+0x3dc>
     cc4:      	add	x16, x16, #0x1c
     cc8:      	ld1.s	{ v31 }[3], [x16]
     ccc:      	fmov	w17, s27
     cd0:      	add	x16, x14, x10
     cd4:      	movi.2d	v8, #0000000000000000
     cd8:      	movi.2d	v10, #0000000000000000
     cdc:      	tbnz	w17, #0x0, 0xc4c <_llm_rows.packet_batch.blocks+0x3f0>
     ce0:      	and	w17, w17, #0xff
     ce4:      	tbz	w17, #0x1, 0xc58 <_llm_rows.packet_batch.blocks+0x3fc>
     ce8:      	add	x0, x16, #0x4
     cec:      	ld1.s	{ v8 }[1], [x0]
     cf0:      	tbnz	w17, #0x2, 0xc5c <_llm_rows.packet_batch.blocks+0x400>
     cf4:      	tbz	w17, #0x3, 0xc68 <_llm_rows.packet_batch.blocks+0x40c>
     cf8:      	add	x0, x16, #0xc
     cfc:      	ld1.s	{ v8 }[3], [x0]
     d00:      	tbnz	w17, #0x4, 0xc6c <_llm_rows.packet_batch.blocks+0x410>
     d04:      	tbz	w17, #0x5, 0xc78 <_llm_rows.packet_batch.blocks+0x41c>
     d08:      	add	x0, x16, #0x14
     d0c:      	ld1.s	{ v10 }[1], [x0]
     d10:      	tbnz	w17, #0x6, 0xc7c <_llm_rows.packet_batch.blocks+0x420>
     d14:      	tbz	w17, #0x7, 0xd20 <_llm_rows.packet_batch.blocks+0x4c4>
     d18:      	add	x16, x16, #0x1c
     d1c:      	ld1.s	{ v10 }[3], [x16]
     d20:      	fneg.4s	v11, v9
     d24:      	and.16b	v11, v20, v11
     d28:      	fcmge.4s	v12, v11, v1
     d2c:      	fcmge.4s	v13, v0, v11
     d30:      	and.16b	v12, v12, v13
     d34:      	and.16b	v12, v12, v11
     d38:      	fmul.4s	v13, v12, v18
     d3c:      	movi.4s	v14, #0x4b, lsl #24
     d40:      	mvni.4s	v15, #0x80, lsl #24
     d44:      	bif.16b	v14, v13, v15
     d48:      	fadd.4s	v13, v13, v14
     d4c:      	fsub.4s	v13, v13, v14
     d50:      	fcvtzs.4s	v13, v13
     d54:      	scvtf.4s	v14, v13
     d58:      	fmul.4s	v15, v14, v17
     d5c:      	fadd.4s	v12, v12, v15
     d60:      	fmul.4s	v14, v14, v16
     d64:      	fadd.4s	v12, v12, v14
     d68:      	fmul.4s	v14, v12, v7
     d6c:      	fadd.4s	v14, v14, v6
     d70:      	fmul.4s	v14, v12, v14
     d74:      	fadd.4s	v14, v14, v5
     d78:      	fmul.4s	v14, v12, v14
     d7c:      	fadd.4s	v14, v14, v4
     d80:      	fmul.4s	v14, v12, v14
     d84:      	fadd.4s	v14, v14, v3
     d88:      	fmul.4s	v14, v12, v14
     d8c:      	movi.4s	v15, #0x3f, lsl #24
     d90:      	fadd.4s	v14, v14, v15
     d94:      	fmul.4s	v15, v12, v12
     d98:      	fmul.4s	v14, v15, v14
     d9c:      	fadd.4s	v12, v12, v14
     da0:      	fadd.4s	v12, v12, v2
     da4:      	sshr.4s	v14, v13, #0x1
     da8:      	shl.4s	v15, v14, #0x17
     dac:      	add.4s	v15, v15, v2
     db0:      	fmul.4s	v12, v12, v15
     db4:      	sub.4s	v13, v13, v14
     db8:      	shl.4s	v13, v13, #0x17
     dbc:      	add.4s	v13, v13, v2
     dc0:      	fmul.4s	v12, v12, v13
     dc4:      	fcmgt.4s	v13, v1, v11
     dc8:      	fcmgt.4s	v14, v11, v0
     dcc:      	fcmeq.4s	v11, v11, v11
     dd0:      	fadd.4s	v12, v12, v2
     dd4:      	bit.16b	v12, v2, v13
     dd8:      	ldr	q13, [sp, #0x110]
     ddc:      	bit.16b	v12, v13, v14
     de0:      	ldr	q13, [sp, #0x100]
     de4:      	bsl.16b	v11, v12, v13
     de8:      	fdiv.4s	v9, v9, v11
     dec:      	fmov	w17, s27
     df0:      	fmul.4s	v8, v8, v9
     df4:      	add	x16, x13, x10
     df8:      	tbz	w17, #0x0, 0xe1c <_llm_rows.packet_batch.blocks+0x5c0>
     dfc:      	str	s8, [x16]
     e00:      	and	w17, w17, #0xff
     e04:      	tbnz	w17, #0x1, 0xe24 <_llm_rows.packet_batch.blocks+0x5c8>
     e08:      	tbz	w17, #0x2, 0xe30 <_llm_rows.packet_batch.blocks+0x5d4>
     e0c:      	add	x0, x16, #0x8
     e10:      	st1.s	{ v8 }[2], [x0]
     e14:      	tbnz	w17, #0x3, 0xe34 <_llm_rows.packet_batch.blocks+0x5d8>
     e18:      	b	0xe3c <_llm_rows.packet_batch.blocks+0x5e0>
     e1c:      	and	w17, w17, #0xff
     e20:      	tbz	w17, #0x1, 0xe08 <_llm_rows.packet_batch.blocks+0x5ac>
     e24:      	add	x0, x16, #0x4
     e28:      	st1.s	{ v8 }[1], [x0]
     e2c:      	tbnz	w17, #0x2, 0xe0c <_llm_rows.packet_batch.blocks+0x5b0>
     e30:      	tbz	w17, #0x3, 0xe3c <_llm_rows.packet_batch.blocks+0x5e0>
     e34:      	add	x0, x16, #0xc
     e38:      	st1.s	{ v8 }[3], [x0]
     e3c:      	fneg.4s	v8, v31
     e40:      	and.16b	v8, v19, v8
     e44:      	fcmge.4s	v9, v8, v1
     e48:      	fcmge.4s	v11, v0, v8
     e4c:      	and.16b	v9, v9, v11
     e50:      	and.16b	v9, v9, v8
     e54:      	fmul.4s	v11, v9, v18
     e58:      	movi.4s	v12, #0x4b, lsl #24
     e5c:      	mvni.4s	v13, #0x80, lsl #24
     e60:      	bif.16b	v12, v11, v13
     e64:      	fadd.4s	v11, v11, v12
     e68:      	fsub.4s	v11, v11, v12
     e6c:      	fcvtzs.4s	v11, v11
     e70:      	scvtf.4s	v12, v11
     e74:      	fmul.4s	v13, v12, v17
     e78:      	fadd.4s	v9, v9, v13
     e7c:      	fmul.4s	v12, v12, v16
     e80:      	fadd.4s	v9, v9, v12
     e84:      	fmul.4s	v12, v9, v7
     e88:      	fadd.4s	v12, v12, v6
     e8c:      	fmul.4s	v12, v9, v12
     e90:      	fadd.4s	v12, v12, v5
     e94:      	fmul.4s	v12, v9, v12
     e98:      	fadd.4s	v12, v12, v4
     e9c:      	fmul.4s	v12, v9, v12
     ea0:      	fadd.4s	v12, v12, v3
     ea4:      	fmul.4s	v12, v9, v12
     ea8:      	movi.4s	v13, #0x3f, lsl #24
     eac:      	fadd.4s	v12, v12, v13
     eb0:      	fmul.4s	v13, v9, v9
     eb4:      	fmul.4s	v12, v13, v12
     eb8:      	fadd.4s	v9, v9, v12
     ebc:      	fadd.4s	v9, v9, v2
     ec0:      	sshr.4s	v12, v11, #0x1
     ec4:      	shl.4s	v13, v12, #0x17
     ec8:      	add.4s	v13, v13, v2
     ecc:      	fmul.4s	v9, v9, v13
     ed0:      	sub.4s	v11, v11, v12
     ed4:      	shl.4s	v11, v11, #0x17
     ed8:      	add.4s	v11, v11, v2
     edc:      	fmul.4s	v9, v9, v11
     ee0:      	fcmgt.4s	v11, v1, v8
     ee4:      	fcmgt.4s	v12, v8, v0
     ee8:      	fcmeq.4s	v8, v8, v8
     eec:      	fadd.4s	v9, v9, v2
     ef0:      	bit.16b	v9, v2, v11
     ef4:      	ldr	q11, [sp, #0x110]
     ef8:      	bit.16b	v9, v11, v12
     efc:      	ldr	q11, [sp, #0x100]
     f00:      	bsl.16b	v8, v9, v11
     f04:      	fdiv.4s	v31, v31, v8
     f08:      	fmul.4s	v31, v10, v31
     f0c:      	tbz	w17, #0x4, 0xf2c <_llm_rows.packet_batch.blocks+0x6d0>
     f10:      	str	s31, [x16, #0x10]
     f14:      	tbnz	w17, #0x5, 0xf30 <_llm_rows.packet_batch.blocks+0x6d4>
     f18:      	tbz	w17, #0x6, 0xf3c <_llm_rows.packet_batch.blocks+0x6e0>
     f1c:      	add	x0, x16, #0x18
     f20:      	st1.s	{ v31 }[2], [x0]
     f24:      	tbz	w17, #0x7, 0xbe0 <_llm_rows.packet_batch.blocks+0x384>
     f28:      	b	0xf40 <_llm_rows.packet_batch.blocks+0x6e4>
     f2c:      	tbz	w17, #0x5, 0xf18 <_llm_rows.packet_batch.blocks+0x6bc>
     f30:      	add	x0, x16, #0x14
     f34:      	st1.s	{ v31 }[1], [x0]
     f38:      	tbnz	w17, #0x6, 0xf1c <_llm_rows.packet_batch.blocks+0x6c0>
     f3c:      	tbz	w17, #0x7, 0xbe0 <_llm_rows.packet_batch.blocks+0x384>
     f40:      	add	x16, x16, #0x1c
     f44:      	st1.s	{ v31 }[3], [x16]
     f48:      	b	0xbe0 <_llm_rows.packet_batch.blocks+0x384>
     f4c:      	mov	x10, #0x0               ; =0
     f50:      	add	x14, x11, x12
     f54:      	b	0xf78 <_llm_rows.packet_batch.blocks+0x71c>
     f58:      	add	x15, x25, x10
     f5c:      	ldp	q12, q13, [x15]
     f60:      	bif.16b	v11, v13, v19
     f64:      	bif.16b	v8, v12, v20
     f68:      	stp	q8, q11, [x15]
     f6c:      	add	x10, x10, #0x20
     f70:      	cmp	x10, #0x100
     f74:      	b.eq	0x101c <_llm_rows.packet_batch.blocks+0x7c0>
     f78:      	ldr	q27, [sp, #0xf0]
     f7c:      	and.16b	v27, v31, v27
     f80:      	addv.8h	h27, v27
     f84:      	fmov	w16, s27
     f88:      	add	x15, x14, x10
     f8c:      	movi.2d	v8, #0000000000000000
     f90:      	movi.2d	v11, #0000000000000000
     f94:      	tbz	w16, #0x0, 0xfd8 <_llm_rows.packet_batch.blocks+0x77c>
     f98:      	ldr	s8, [x15]
     f9c:      	and	w16, w16, #0xff
     fa0:      	tbnz	w16, #0x1, 0xfe0 <_llm_rows.packet_batch.blocks+0x784>
     fa4:      	tbz	w16, #0x2, 0xfec <_llm_rows.packet_batch.blocks+0x790>
     fa8:      	add	x17, x15, #0x8
     fac:      	ld1.s	{ v8 }[2], [x17]
     fb0:      	tbnz	w16, #0x3, 0xff0 <_llm_rows.packet_batch.blocks+0x794>
     fb4:      	tbz	w16, #0x4, 0xffc <_llm_rows.packet_batch.blocks+0x7a0>
     fb8:      	add	x17, x15, #0x10
     fbc:      	ld1.s	{ v11 }[0], [x17]
     fc0:      	tbnz	w16, #0x5, 0x1000 <_llm_rows.packet_batch.blocks+0x7a4>
     fc4:      	tbz	w16, #0x6, 0x100c <_llm_rows.packet_batch.blocks+0x7b0>
     fc8:      	add	x17, x15, #0x18
     fcc:      	ld1.s	{ v11 }[2], [x17]
     fd0:      	tbz	w16, #0x7, 0xf58 <_llm_rows.packet_batch.blocks+0x6fc>
     fd4:      	b	0x1010 <_llm_rows.packet_batch.blocks+0x7b4>
     fd8:      	and	w16, w16, #0xff
     fdc:      	tbz	w16, #0x1, 0xfa4 <_llm_rows.packet_batch.blocks+0x748>
     fe0:      	add	x17, x15, #0x4
     fe4:      	ld1.s	{ v8 }[1], [x17]
     fe8:      	tbnz	w16, #0x2, 0xfa8 <_llm_rows.packet_batch.blocks+0x74c>
     fec:      	tbz	w16, #0x3, 0xfb4 <_llm_rows.packet_batch.blocks+0x758>
     ff0:      	add	x17, x15, #0xc
     ff4:      	ld1.s	{ v8 }[3], [x17]
     ff8:      	tbnz	w16, #0x4, 0xfb8 <_llm_rows.packet_batch.blocks+0x75c>
     ffc:      	tbz	w16, #0x5, 0xfc4 <_llm_rows.packet_batch.blocks+0x768>
    1000:      	add	x17, x15, #0x14
    1004:      	ld1.s	{ v11 }[1], [x17]
    1008:      	tbnz	w16, #0x6, 0xfc8 <_llm_rows.packet_batch.blocks+0x76c>
    100c:      	tbz	w16, #0x7, 0xf58 <_llm_rows.packet_batch.blocks+0x6fc>
    1010:      	add	x15, x15, #0x1c
    1014:      	ld1.s	{ v11 }[3], [x15]
    1018:      	b	0xf58 <_llm_rows.packet_batch.blocks+0x6fc>
    101c:      	uzp1.8b	v31, v29, v0
    1020:      	movi.2d	v29, #0000000000000000
    1024:      	mov.b	v29[0], v31[0]
    1028:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x7a4>
    102c:      	ldr	d11, [x10]
    1030:      	and.8b	v8, v29, v11
    1034:      	addv.8b	b8, v8
    1038:      	fmov	w15, s8
    103c:      	umaxv.8b	b8, v29
    1040:      	fmov	w16, s8
    1044:      	rbit	w10, w15
    1048:      	clz	w10, w10
    104c:      	tst	w16, #0x1
    1050:      	csel	w10, w10, wzr, ne
    1054:      	mov	w14, #0x40              ; =64
    1058:      	dup.2d	v8, x14
    105c:      	movi.2s	v12, #0x41
    1060:      	umlal.2d	v28, v30, v12
    1064:      	movi.2d	v12, #0000000000000000
    1068:      	mov.b	v12[0], v31[0]
    106c:      	add.2d	v30, v28, v8
    1070:      	ushll.2d	v28, v12, #0x0
    1074:      	shl.2d	v28, v28, #0x3f
    1078:      	cmlt.2d	v28, v28, #0
    107c:      	str	q30, [sp, #0x50]
    1080:      	and.16b	v28, v28, v30
    1084:      	movi.2d	v30, #0000000000000000
    1088:      	stp	q30, q30, [sp, #0x260]
    108c:      	stp	q28, q30, [sp, #0x240]
    1090:      	and	x14, x10, #0x7
    1094:      	add	x17, sp, #0x240
    1098:      	ldr	x14, [x17, x14, lsl #3]
    109c:      	sub	x14, x14, x10
    10a0:      	lsl	x14, x14, #2
    10a4:      	add	x11, x11, x14
    10a8:      	movi.2d	v31, #0000000000000000
    10ac:      	tbz	w16, #0x0, 0x10ec <_llm_rows.packet_batch.blocks+0x890>
    10b0:      	ldr	s31, [x11]
    10b4:      	tbnz	w15, #0x1, 0x10f0 <_llm_rows.packet_batch.blocks+0x894>
    10b8:      	tbz	w15, #0x2, 0x10fc <_llm_rows.packet_batch.blocks+0x8a0>
    10bc:      	add	x16, x11, #0x8
    10c0:      	ld1.s	{ v31 }[2], [x16]
    10c4:      	tbnz	w15, #0x3, 0x1100 <_llm_rows.packet_batch.blocks+0x8a4>
    10c8:      	tbz	w15, #0x4, 0x110c <_llm_rows.packet_batch.blocks+0x8b0>
    10cc:      	add	x16, x11, #0x10
    10d0:      	ld1.s	{ v30 }[0], [x16]
    10d4:      	tbnz	w15, #0x5, 0x1110 <_llm_rows.packet_batch.blocks+0x8b4>
    10d8:      	tbz	w15, #0x6, 0x111c <_llm_rows.packet_batch.blocks+0x8c0>
    10dc:      	add	x16, x11, #0x18
    10e0:      	ld1.s	{ v30 }[2], [x16]
    10e4:      	tbnz	w15, #0x7, 0x1120 <_llm_rows.packet_batch.blocks+0x8c4>
    10e8:      	b	0x1128 <_llm_rows.packet_batch.blocks+0x8cc>
    10ec:      	tbz	w15, #0x1, 0x10b8 <_llm_rows.packet_batch.blocks+0x85c>
    10f0:      	add	x16, x11, #0x4
    10f4:      	ld1.s	{ v31 }[1], [x16]
    10f8:      	tbnz	w15, #0x2, 0x10bc <_llm_rows.packet_batch.blocks+0x860>
    10fc:      	tbz	w15, #0x3, 0x10c8 <_llm_rows.packet_batch.blocks+0x86c>
    1100:      	add	x16, x11, #0xc
    1104:      	ld1.s	{ v31 }[3], [x16]
    1108:      	tbnz	w15, #0x4, 0x10cc <_llm_rows.packet_batch.blocks+0x870>
    110c:      	tbz	w15, #0x5, 0x10d8 <_llm_rows.packet_batch.blocks+0x87c>
    1110:      	add	x16, x11, #0x14
    1114:      	ld1.s	{ v30 }[1], [x16]
    1118:      	tbnz	w15, #0x6, 0x10dc <_llm_rows.packet_batch.blocks+0x880>
    111c:      	tbz	w15, #0x7, 0x1128 <_llm_rows.packet_batch.blocks+0x8cc>
    1120:      	add	x11, x11, #0x1c
    1124:      	ld1.s	{ v30 }[3], [x11]
    1128:      	mov	x17, #0x0               ; =0
    112c:      	movi.2s	v28, #0x41
    1130:      	umlal.2d	v23, v26, v28
    1134:      	add.2d	v23, v23, v8
    1138:      	umlal.2d	v22, v25, v28
    113c:      	add.2d	v22, v22, v8
    1140:      	stp	q22, q23, [sp, #0x20]
    1144:      	umlal.2d	v21, v24, v28
    1148:      	add.2d	v21, v21, v8
    114c:      	str	q21, [sp, #0x10]
    1150:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7a4>
    1154:      	ldr	q21, [x11]
    1158:      	mov	w11, #0x100             ; =256
    115c:      	dup.2d	v22, x11
    1160:      	sshll.2d	v23, v20, #0x0
    1164:      	bif.16b	v21, v22, v23
    1168:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7a4>
    116c:      	ldr	q23, [x11]
    1170:      	sshll.2d	v24, v19, #0x0
    1174:      	bif.16b	v23, v22, v24
    1178:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7a4>
    117c:      	ldr	q24, [x11]
    1180:      	bif.16b	v24, v22, v10
    1184:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7a4>
    1188:      	ldr	q25, [x11]
    118c:      	bit.16b	v22, v25, v9
    1190:      	stp	q23, q22, [sp, #0x220]
    1194:      	stp	q21, q24, [sp, #0x200]
    1198:      	and	x11, x10, #0x7
    119c:      	add	x16, sp, #0x200
    11a0:      	ldr	x11, [x16, x11, lsl #3]
    11a4:      	sub	x11, x11, x10, lsl #2
    11a8:      	tst	w15, #0xff
    11ac:      	csel	x15, xzr, x11, eq
    11b0:      	add	x11, x25, x15
    11b4:      	ldp	q21, q22, [x11]
    11b8:      	zip2.8b	v23, v29, v0
    11bc:      	ushll.4s	v23, v23, #0x0
    11c0:      	shl.4s	v23, v23, #0x1f
    11c4:      	cmlt.4s	v23, v23, #0
    11c8:      	str	q30, [sp, #0x60]
    11cc:      	bit.16b	v22, v30, v23
    11d0:      	zip1.8b	v23, v29, v0
    11d4:      	ushll.4s	v23, v23, #0x0
    11d8:      	shl.4s	v23, v23, #0x1f
    11dc:      	cmlt.4s	v23, v23, #0
    11e0:      	str	q31, [sp, #0x40]
    11e4:      	bit.16b	v21, v31, v23
    11e8:      	stp	q21, q22, [x11]
    11ec:      	add	x16, x9, x12
    11f0:      	ushll2.2d	v21, v19, #0x0
    11f4:      	mov	w11, #0x1               ; =1
    11f8:      	dup.2d	v22, x11
    11fc:      	and.16b	v24, v21, v22
    1200:      	ushll2.2d	v21, v20, #0x0
    1204:      	and.16b	v25, v21, v22
    1208:      	ushll.2d	v21, v19, #0x0
    120c:      	and.16b	v26, v21, v22
    1210:      	ushll.2d	v21, v20, #0x0
    1214:      	and.16b	v9, v21, v22
    1218:      	movi.2d	v8, #0000000000000000
    121c:      	and	x11, x13, #0x1
    1220:      	movi.2d	v10, #0000000000000000
    1224:      	movi.2d	v12, #0000000000000000
    1228:      	movi.2d	v13, #0000000000000000
    122c:      	b	0x1268 <_llm_rows.packet_batch.blocks+0xa0c>
    1230:      	add	x13, x24, x13
    1234:      	ldp	q21, q22, [x13]
    1238:      	bit.16b	v22, v15, v19
    123c:      	bit.16b	v21, v14, v20
    1240:      	stp	q21, q22, [x13]
    1244:      	add.2d	v21, v8, v9
    1248:      	add.2d	v10, v10, v25
    124c:      	add.2d	v12, v12, v26
    1250:      	add.2d	v13, v13, v24
    1254:      	fmov	x13, d8
    1258:      	add	x17, x13, x11
    125c:      	mov.16b	v8, v21
    1260:      	cmp	x17, #0x8
    1264:      	b.ge	0x1304 <_llm_rows.packet_batch.blocks+0xaa8>
    1268:      	fmov	w0, s27
    126c:      	lsl	x13, x17, #5
    1270:      	add	x17, x16, x13
    1274:      	movi.2d	v14, #0000000000000000
    1278:      	movi.2d	v15, #0000000000000000
    127c:      	tbz	w0, #0x0, 0x12c0 <_llm_rows.packet_batch.blocks+0xa64>
    1280:      	ldr	s14, [x17]
    1284:      	and	w0, w0, #0xff
    1288:      	tbnz	w0, #0x1, 0x12c8 <_llm_rows.packet_batch.blocks+0xa6c>
    128c:      	tbz	w0, #0x2, 0x12d4 <_llm_rows.packet_batch.blocks+0xa78>
    1290:      	add	x1, x17, #0x8
    1294:      	ld1.s	{ v14 }[2], [x1]
    1298:      	tbnz	w0, #0x3, 0x12d8 <_llm_rows.packet_batch.blocks+0xa7c>
    129c:      	tbz	w0, #0x4, 0x12e4 <_llm_rows.packet_batch.blocks+0xa88>
    12a0:      	add	x1, x17, #0x10
    12a4:      	ld1.s	{ v15 }[0], [x1]
    12a8:      	tbnz	w0, #0x5, 0x12e8 <_llm_rows.packet_batch.blocks+0xa8c>
    12ac:      	tbz	w0, #0x6, 0x12f4 <_llm_rows.packet_batch.blocks+0xa98>
    12b0:      	add	x1, x17, #0x18
    12b4:      	ld1.s	{ v15 }[2], [x1]
    12b8:      	tbz	w0, #0x7, 0x1230 <_llm_rows.packet_batch.blocks+0x9d4>
    12bc:      	b	0x12f8 <_llm_rows.packet_batch.blocks+0xa9c>
    12c0:      	and	w0, w0, #0xff
    12c4:      	tbz	w0, #0x1, 0x128c <_llm_rows.packet_batch.blocks+0xa30>
    12c8:      	add	x1, x17, #0x4
    12cc:      	ld1.s	{ v14 }[1], [x1]
    12d0:      	tbnz	w0, #0x2, 0x1290 <_llm_rows.packet_batch.blocks+0xa34>
    12d4:      	tbz	w0, #0x3, 0x129c <_llm_rows.packet_batch.blocks+0xa40>
    12d8:      	add	x1, x17, #0xc
    12dc:      	ld1.s	{ v14 }[3], [x1]
    12e0:      	tbnz	w0, #0x4, 0x12a0 <_llm_rows.packet_batch.blocks+0xa44>
    12e4:      	tbz	w0, #0x5, 0x12ac <_llm_rows.packet_batch.blocks+0xa50>
    12e8:      	add	x1, x17, #0x14
    12ec:      	ld1.s	{ v15 }[1], [x1]
    12f0:      	tbnz	w0, #0x6, 0x12b0 <_llm_rows.packet_batch.blocks+0xa54>
    12f4:      	tbz	w0, #0x7, 0x1230 <_llm_rows.packet_batch.blocks+0x9d4>
    12f8:      	add	x17, x17, #0x1c
    12fc:      	ld1.s	{ v15 }[3], [x17]
    1300:      	b	0x1230 <_llm_rows.packet_batch.blocks+0x9d4>
    1304:      	add	x9, x9, x14
    1308:      	shl.8b	v21, v29, #0x7
    130c:      	cmlt.8b	v21, v21, #0
    1310:      	and.8b	v21, v21, v11
    1314:      	addv.8b	b21, v21
    1318:      	str	d21, [sp, #0x8]
    131c:      	fmov	w13, s21
    1320:      	movi.2d	v11, #0000000000000000
    1324:      	movi.2d	v10, #0000000000000000
    1328:      	tbz	w13, #0x0, 0x1368 <_llm_rows.packet_batch.blocks+0xb0c>
    132c:      	ldr	s11, [x9]
    1330:      	tbnz	w13, #0x1, 0x136c <_llm_rows.packet_batch.blocks+0xb10>
    1334:      	tbz	w13, #0x2, 0x1378 <_llm_rows.packet_batch.blocks+0xb1c>
    1338:      	add	x14, x9, #0x8
    133c:      	ld1.s	{ v11 }[2], [x14]
    1340:      	tbnz	w13, #0x3, 0x137c <_llm_rows.packet_batch.blocks+0xb20>
    1344:      	tbz	w13, #0x4, 0x1388 <_llm_rows.packet_batch.blocks+0xb2c>
    1348:      	add	x14, x9, #0x10
    134c:      	ld1.s	{ v10 }[0], [x14]
    1350:      	tbnz	w13, #0x5, 0x138c <_llm_rows.packet_batch.blocks+0xb30>
    1354:      	tbz	w13, #0x6, 0x1398 <_llm_rows.packet_batch.blocks+0xb3c>
    1358:      	add	x14, x9, #0x18
    135c:      	ld1.s	{ v10 }[2], [x14]
    1360:      	tbnz	w13, #0x7, 0x139c <_llm_rows.packet_batch.blocks+0xb40>
    1364:      	b	0x13a4 <_llm_rows.packet_batch.blocks+0xb48>
    1368:      	tbz	w13, #0x1, 0x1334 <_llm_rows.packet_batch.blocks+0xad8>
    136c:      	add	x14, x9, #0x4
    1370:      	ld1.s	{ v11 }[1], [x14]
    1374:      	tbnz	w13, #0x2, 0x1338 <_llm_rows.packet_batch.blocks+0xadc>
    1378:      	tbz	w13, #0x3, 0x1344 <_llm_rows.packet_batch.blocks+0xae8>
    137c:      	add	x14, x9, #0xc
    1380:      	ld1.s	{ v11 }[3], [x14]
    1384:      	tbnz	w13, #0x4, 0x1348 <_llm_rows.packet_batch.blocks+0xaec>
    1388:      	tbz	w13, #0x5, 0x1354 <_llm_rows.packet_batch.blocks+0xaf8>
    138c:      	add	x14, x9, #0x14
    1390:      	ld1.s	{ v10 }[1], [x14]
    1394:      	tbnz	w13, #0x6, 0x1358 <_llm_rows.packet_batch.blocks+0xafc>
    1398:      	tbz	w13, #0x7, 0x13a4 <_llm_rows.packet_batch.blocks+0xb48>
    139c:      	add	x9, x9, #0x1c
    13a0:      	ld1.s	{ v10 }[3], [x9]
    13a4:      	mov	x14, #0x0               ; =0
    13a8:      	add	x9, x24, x15
    13ac:      	ldp	q21, q22, [x9]
    13b0:      	zip2.8b	v23, v29, v0
    13b4:      	ushll.4s	v23, v23, #0x0
    13b8:      	shl.4s	v23, v23, #0x1f
    13bc:      	cmlt.4s	v23, v23, #0
    13c0:      	bit.16b	v22, v10, v23
    13c4:      	zip1.8b	v23, v29, v0
    13c8:      	ushll.4s	v23, v23, #0x0
    13cc:      	shl.4s	v23, v23, #0x1f
    13d0:      	cmlt.4s	v23, v23, #0
    13d4:      	bit.16b	v21, v11, v23
    13d8:      	stp	q21, q22, [x9]
    13dc:      	add	x9, x8, x12
    13e0:      	movi.2d	v13, #0000000000000000
    13e4:      	movi.2d	v14, #0000000000000000
    13e8:      	movi.2d	v15, #0000000000000000
    13ec:      	movi.2d	v8, #0000000000000000
    13f0:      	b	0x1418 <_llm_rows.packet_batch.blocks+0xbbc>
    13f4:      	add.2d	v21, v13, v9
    13f8:      	add.2d	v14, v14, v25
    13fc:      	add.2d	v15, v15, v26
    1400:      	add.2d	v8, v8, v24
    1404:      	fmov	x12, d13
    1408:      	add	x14, x12, x11
    140c:      	mov.16b	v13, v21
    1410:      	cmp	x14, #0x8
    1414:      	b.ge	0x1668 <_llm_rows.packet_batch.blocks+0xe0c>
    1418:      	fmov	w13, s27
    141c:      	lsl	x12, x14, #5
    1420:      	add	x14, x25, x12
    1424:      	ldp	q21, q23, [x14]
    1428:      	and.16b	v21, v20, v21
    142c:      	fneg.4s	v22, v21
    1430:      	and.16b	v22, v20, v22
    1434:      	fcmge.4s	v30, v22, v1
    1438:      	fcmge.4s	v12, v0, v22
    143c:      	and.16b	v30, v30, v12
    1440:      	and.16b	v30, v30, v22
    1444:      	fmul.4s	v12, v30, v18
    1448:      	movi.4s	v28, #0x4b, lsl #24
    144c:      	mvni.4s	v31, #0x80, lsl #24
    1450:      	bsl.16b	v31, v28, v12
    1454:      	fadd.4s	v12, v12, v31
    1458:      	fsub.4s	v31, v12, v31
    145c:      	fcvtzs.4s	v31, v31
    1460:      	scvtf.4s	v12, v31
    1464:      	fmul.4s	v28, v12, v17
    1468:      	fadd.4s	v28, v30, v28
    146c:      	fmul.4s	v30, v12, v16
    1470:      	fadd.4s	v28, v28, v30
    1474:      	fmul.4s	v30, v28, v7
    1478:      	fadd.4s	v30, v30, v6
    147c:      	fmul.4s	v30, v28, v30
    1480:      	fadd.4s	v30, v30, v5
    1484:      	fmul.4s	v30, v28, v30
    1488:      	fadd.4s	v30, v30, v4
    148c:      	fmul.4s	v30, v28, v30
    1490:      	fadd.4s	v30, v30, v3
    1494:      	fmul.4s	v30, v28, v30
    1498:      	movi.4s	v12, #0x3f, lsl #24
    149c:      	fadd.4s	v30, v30, v12
    14a0:      	fmul.4s	v12, v28, v28
    14a4:      	fmul.4s	v30, v12, v30
    14a8:      	fadd.4s	v28, v28, v30
    14ac:      	fadd.4s	v28, v28, v2
    14b0:      	sshr.4s	v30, v31, #0x1
    14b4:      	shl.4s	v12, v30, #0x17
    14b8:      	add.4s	v12, v12, v2
    14bc:      	fmul.4s	v28, v28, v12
    14c0:      	sub.4s	v30, v31, v30
    14c4:      	shl.4s	v30, v30, #0x17
    14c8:      	add.4s	v30, v30, v2
    14cc:      	fmul.4s	v28, v28, v30
    14d0:      	fcmgt.4s	v30, v1, v22
    14d4:      	fcmgt.4s	v31, v22, v0
    14d8:      	fcmeq.4s	v22, v22, v22
    14dc:      	fadd.4s	v28, v28, v2
    14e0:      	bit.16b	v28, v2, v30
    14e4:      	ldr	q30, [sp, #0x110]
    14e8:      	bit.16b	v28, v30, v31
    14ec:      	ldr	q30, [sp, #0x100]
    14f0:      	bsl.16b	v22, v28, v30
    14f4:      	fdiv.4s	v21, v21, v22
    14f8:      	add	x14, x24, x12
    14fc:      	ldp	q28, q22, [x14]
    1500:      	and.16b	v28, v20, v28
    1504:      	fmul.4s	v21, v28, v21
    1508:      	add	x12, x9, x12
    150c:      	tbz	w13, #0x0, 0x1530 <_llm_rows.packet_batch.blocks+0xcd4>
    1510:      	str	s21, [x12]
    1514:      	and	w13, w13, #0xff
    1518:      	tbnz	w13, #0x1, 0x1538 <_llm_rows.packet_batch.blocks+0xcdc>
    151c:      	tbz	w13, #0x2, 0x1544 <_llm_rows.packet_batch.blocks+0xce8>
    1520:      	add	x14, x12, #0x8
    1524:      	st1.s	{ v21 }[2], [x14]
    1528:      	tbnz	w13, #0x3, 0x1548 <_llm_rows.packet_batch.blocks+0xcec>
    152c:      	b	0x1550 <_llm_rows.packet_batch.blocks+0xcf4>
    1530:      	and	w13, w13, #0xff
    1534:      	tbz	w13, #0x1, 0x151c <_llm_rows.packet_batch.blocks+0xcc0>
    1538:      	add	x14, x12, #0x4
    153c:      	st1.s	{ v21 }[1], [x14]
    1540:      	tbnz	w13, #0x2, 0x1520 <_llm_rows.packet_batch.blocks+0xcc4>
    1544:      	tbz	w13, #0x3, 0x1550 <_llm_rows.packet_batch.blocks+0xcf4>
    1548:      	add	x14, x12, #0xc
    154c:      	st1.s	{ v21 }[3], [x14]
    1550:      	and.16b	v21, v19, v23
    1554:      	fneg.4s	v23, v21
    1558:      	and.16b	v23, v19, v23
    155c:      	fcmge.4s	v28, v23, v1
    1560:      	fcmge.4s	v30, v0, v23
    1564:      	and.16b	v28, v28, v30
    1568:      	and.16b	v28, v28, v23
    156c:      	fmul.4s	v30, v28, v18
    1570:      	movi.4s	v31, #0x4b, lsl #24
    1574:      	mvni.4s	v12, #0x80, lsl #24
    1578:      	bif.16b	v31, v30, v12
    157c:      	fadd.4s	v30, v30, v31
    1580:      	fsub.4s	v30, v30, v31
    1584:      	fcvtzs.4s	v30, v30
    1588:      	scvtf.4s	v31, v30
    158c:      	fmul.4s	v12, v31, v17
    1590:      	fadd.4s	v28, v28, v12
    1594:      	fmul.4s	v31, v31, v16
    1598:      	fadd.4s	v28, v28, v31
    159c:      	fmul.4s	v31, v28, v7
    15a0:      	fadd.4s	v31, v31, v6
    15a4:      	fmul.4s	v31, v28, v31
    15a8:      	fadd.4s	v31, v31, v5
    15ac:      	fmul.4s	v31, v28, v31
    15b0:      	fadd.4s	v31, v31, v4
    15b4:      	fmul.4s	v31, v28, v31
    15b8:      	fadd.4s	v31, v31, v3
    15bc:      	fmul.4s	v31, v28, v31
    15c0:      	movi.4s	v12, #0x3f, lsl #24
    15c4:      	fadd.4s	v31, v31, v12
    15c8:      	fmul.4s	v12, v28, v28
    15cc:      	fmul.4s	v31, v12, v31
    15d0:      	fadd.4s	v28, v28, v31
    15d4:      	fadd.4s	v28, v28, v2
    15d8:      	sshr.4s	v31, v30, #0x1
    15dc:      	shl.4s	v12, v31, #0x17
    15e0:      	add.4s	v12, v12, v2
    15e4:      	fmul.4s	v28, v28, v12
    15e8:      	sub.4s	v30, v30, v31
    15ec:      	shl.4s	v30, v30, #0x17
    15f0:      	add.4s	v30, v30, v2
    15f4:      	fmul.4s	v28, v28, v30
    15f8:      	fcmgt.4s	v30, v1, v23
    15fc:      	fcmgt.4s	v31, v23, v0
    1600:      	fcmeq.4s	v23, v23, v23
    1604:      	fadd.4s	v28, v28, v2
    1608:      	bit.16b	v28, v2, v30
    160c:      	ldr	q30, [sp, #0x110]
    1610:      	bit.16b	v28, v30, v31
    1614:      	ldr	q30, [sp, #0x100]
    1618:      	bsl.16b	v23, v28, v30
    161c:      	fdiv.4s	v21, v21, v23
    1620:      	and.16b	v22, v19, v22
    1624:      	fmul.4s	v21, v22, v21
    1628:      	tbz	w13, #0x4, 0x1648 <_llm_rows.packet_batch.blocks+0xdec>
    162c:      	str	s21, [x12, #0x10]
    1630:      	tbnz	w13, #0x5, 0x164c <_llm_rows.packet_batch.blocks+0xdf0>
    1634:      	tbz	w13, #0x6, 0x1658 <_llm_rows.packet_batch.blocks+0xdfc>
    1638:      	add	x14, x12, #0x18
    163c:      	st1.s	{ v21 }[2], [x14]
    1640:      	tbz	w13, #0x7, 0x13f4 <_llm_rows.packet_batch.blocks+0xb98>
    1644:      	b	0x165c <_llm_rows.packet_batch.blocks+0xe00>
    1648:      	tbz	w13, #0x5, 0x1634 <_llm_rows.packet_batch.blocks+0xdd8>
    164c:      	add	x14, x12, #0x14
    1650:      	st1.s	{ v21 }[1], [x14]
    1654:      	tbnz	w13, #0x6, 0x1638 <_llm_rows.packet_batch.blocks+0xddc>
    1658:      	tbz	w13, #0x7, 0x13f4 <_llm_rows.packet_batch.blocks+0xb98>
    165c:      	add	x12, x12, #0x1c
    1660:      	st1.s	{ v21 }[3], [x12]
    1664:      	b	0x13f4 <_llm_rows.packet_batch.blocks+0xb98>
    1668:      	ldr	q24, [sp, #0x40]
    166c:      	fneg.4s	v19, v24
    1670:      	ldr	d20, [sp, #0x8]
    1674:      	fmov	w9, s20
    1678:      	zip1.8b	v20, v29, v0
    167c:      	ushll.4s	v20, v20, #0x0
    1680:      	shl.4s	v20, v20, #0x1f
    1684:      	cmlt.4s	v20, v20, #0
    1688:      	and.16b	v19, v20, v19
    168c:      	fcmge.4s	v20, v19, v1
    1690:      	fcmge.4s	v21, v0, v19
    1694:      	and.16b	v20, v20, v21
    1698:      	and.16b	v20, v20, v19
    169c:      	fmul.4s	v21, v20, v18
    16a0:      	movi.4s	v22, #0x4b, lsl #24
    16a4:      	mvni.4s	v23, #0x80, lsl #24
    16a8:      	bif.16b	v22, v21, v23
    16ac:      	fadd.4s	v21, v21, v22
    16b0:      	fsub.4s	v21, v21, v22
    16b4:      	fcvtzs.4s	v21, v21
    16b8:      	scvtf.4s	v22, v21
    16bc:      	fmul.4s	v23, v22, v17
    16c0:      	fadd.4s	v20, v20, v23
    16c4:      	fmul.4s	v22, v22, v16
    16c8:      	fadd.4s	v20, v20, v22
    16cc:      	fmul.4s	v22, v20, v7
    16d0:      	fadd.4s	v22, v22, v6
    16d4:      	fmul.4s	v22, v20, v22
    16d8:      	fadd.4s	v22, v22, v5
    16dc:      	fmul.4s	v22, v20, v22
    16e0:      	fadd.4s	v22, v22, v4
    16e4:      	fmul.4s	v22, v20, v22
    16e8:      	fadd.4s	v22, v22, v3
    16ec:      	fmul.4s	v22, v20, v22
    16f0:      	movi.4s	v23, #0x3f, lsl #24
    16f4:      	fadd.4s	v22, v22, v23
    16f8:      	fmul.4s	v23, v20, v20
    16fc:      	fmul.4s	v22, v23, v22
    1700:      	fadd.4s	v20, v20, v22
    1704:      	fadd.4s	v20, v20, v2
    1708:      	sshr.4s	v22, v21, #0x1
    170c:      	shl.4s	v23, v22, #0x17
    1710:      	add.4s	v23, v23, v2
    1714:      	fmul.4s	v20, v20, v23
    1718:      	sub.4s	v21, v21, v22
    171c:      	shl.4s	v21, v21, #0x17
    1720:      	add.4s	v21, v21, v2
    1724:      	fmul.4s	v20, v20, v21
    1728:      	fcmgt.4s	v21, v1, v19
    172c:      	fcmgt.4s	v22, v19, v0
    1730:      	fcmeq.4s	v19, v19, v19
    1734:      	fadd.4s	v20, v20, v2
    1738:      	bit.16b	v20, v2, v21
    173c:      	ldp	q21, q23, [sp, #0x100]
    1740:      	bit.16b	v20, v23, v22
    1744:      	bsl.16b	v19, v20, v21
    1748:      	fdiv.4s	v19, v24, v19
    174c:      	fmul.4s	v19, v19, v11
    1750:      	ldr	q21, [sp, #0x50]
    1754:      	ldp	q23, q22, [sp, #0x20]
    1758:      	stp	q21, q22, [sp, #0x1b0]
    175c:      	ldr	q20, [sp, #0x10]
    1760:      	stp	q23, q20, [sp, #0x1d0]
    1764:      	and	x11, x10, #0x7
    1768:      	add	x12, sp, #0x1b0
    176c:      	ldr	x11, [x12, x11, lsl #3]
    1770:      	sub	x10, x11, x10
    1774:      	add	x8, x8, x10, lsl #2
    1778:      	tbz	w9, #0x0, 0x179c <_llm_rows.packet_batch.blocks+0xf40>
    177c:      	str	s19, [x8]
    1780:      	ldr	q23, [sp, #0x60]
    1784:      	tbnz	w9, #0x1, 0x17a4 <_llm_rows.packet_batch.blocks+0xf48>
    1788:      	tbz	w9, #0x2, 0x17b0 <_llm_rows.packet_batch.blocks+0xf54>
    178c:      	add	x10, x8, #0x8
    1790:      	st1.s	{ v19 }[2], [x10]
    1794:      	tbnz	w9, #0x3, 0x17b4 <_llm_rows.packet_batch.blocks+0xf58>
    1798:      	b	0x17bc <_llm_rows.packet_batch.blocks+0xf60>
    179c:      	ldr	q23, [sp, #0x60]
    17a0:      	tbz	w9, #0x1, 0x1788 <_llm_rows.packet_batch.blocks+0xf2c>
    17a4:      	add	x10, x8, #0x4
    17a8:      	st1.s	{ v19 }[1], [x10]
    17ac:      	tbnz	w9, #0x2, 0x178c <_llm_rows.packet_batch.blocks+0xf30>
    17b0:      	tbz	w9, #0x3, 0x17bc <_llm_rows.packet_batch.blocks+0xf60>
    17b4:      	add	x10, x8, #0xc
    17b8:      	st1.s	{ v19 }[3], [x10]
    17bc:      	fneg.4s	v19, v23
    17c0:      	zip2.8b	v20, v29, v0
    17c4:      	ushll.4s	v20, v20, #0x0
    17c8:      	shl.4s	v20, v20, #0x1f
    17cc:      	cmlt.4s	v20, v20, #0
    17d0:      	and.16b	v19, v20, v19
    17d4:      	fcmge.4s	v20, v19, v1
    17d8:      	fcmge.4s	v21, v0, v19
    17dc:      	and.16b	v20, v20, v21
    17e0:      	and.16b	v20, v20, v19
    17e4:      	fmul.4s	v18, v20, v18
    17e8:      	movi.4s	v21, #0x4b, lsl #24
    17ec:      	mvni.4s	v22, #0x80, lsl #24
    17f0:      	bif.16b	v21, v18, v22
    17f4:      	fadd.4s	v18, v18, v21
    17f8:      	fsub.4s	v18, v18, v21
    17fc:      	fcvtzs.4s	v18, v18
    1800:      	scvtf.4s	v21, v18
    1804:      	fmul.4s	v17, v21, v17
    1808:      	fadd.4s	v17, v20, v17
    180c:      	fmul.4s	v16, v21, v16
    1810:      	fadd.4s	v16, v17, v16
    1814:      	fmul.4s	v7, v16, v7
    1818:      	fadd.4s	v6, v7, v6
    181c:      	fmul.4s	v6, v16, v6
    1820:      	fadd.4s	v5, v6, v5
    1824:      	fmul.4s	v5, v16, v5
    1828:      	fadd.4s	v4, v5, v4
    182c:      	fmul.4s	v4, v16, v4
    1830:      	fadd.4s	v3, v4, v3
    1834:      	fmul.4s	v3, v16, v3
    1838:      	movi.4s	v4, #0x3f, lsl #24
    183c:      	fadd.4s	v3, v3, v4
    1840:      	fmul.4s	v4, v16, v16
    1844:      	fmul.4s	v3, v4, v3
    1848:      	fadd.4s	v3, v16, v3
    184c:      	fadd.4s	v3, v3, v2
    1850:      	sshr.4s	v4, v18, #0x1
    1854:      	shl.4s	v5, v4, #0x17
    1858:      	add.4s	v5, v5, v2
    185c:      	fmul.4s	v3, v3, v5
    1860:      	sub.4s	v4, v18, v4
    1864:      	shl.4s	v4, v4, #0x17
    1868:      	add.4s	v4, v4, v2
    186c:      	fmul.4s	v3, v3, v4
    1870:      	fcmgt.4s	v1, v1, v19
    1874:      	fcmgt.4s	v0, v19, v0
    1878:      	fcmeq.4s	v4, v19, v19
    187c:      	fadd.4s	v3, v3, v2
    1880:      	bsl.16b	v1, v2, v3
    1884:      	ldr	q2, [sp, #0x110]
    1888:      	bsl.16b	v0, v2, v1
    188c:      	ldr	q1, [sp, #0x100]
    1890:      	bif.16b	v0, v1, v4
    1894:      	fdiv.4s	v0, v23, v0
    1898:      	fmul.4s	v0, v0, v10
    189c:      	tbz	w9, #0x4, 0x1c9c <_llm_rows.packet_batch.blocks+0x1440>
    18a0:      	str	s0, [x8, #0x10]
    18a4:      	tbnz	w9, #0x5, 0x1ca0 <_llm_rows.packet_batch.blocks+0x1444>
    18a8:      	tbz	w9, #0x6, 0x1cac <_llm_rows.packet_batch.blocks+0x1450>
    18ac:      	add	x10, x8, #0x18
    18b0:      	st1.s	{ v0 }[2], [x10]
    18b4:      	tbnz	w9, #0x7, 0x1cb0 <_llm_rows.packet_batch.blocks+0x1454>
    18b8:      	b	0x924 <_llm_rows.packet_batch.blocks+0xc8>
    18bc:      	uzp1.8b	v19, v29, v0
    18c0:      	movi.2d	v20, #0000000000000000
    18c4:      	mov.b	v20[0], v19[0]
    18c8:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x7a4>
    18cc:      	ldr	d31, [x10]
    18d0:      	and.8b	v27, v20, v31
    18d4:      	addv.8b	b27, v27
    18d8:      	fmov	w12, s27
    18dc:      	umaxv.8b	b27, v20
    18e0:      	fmov	w14, s27
    18e4:      	rbit	w10, w12
    18e8:      	clz	w10, w10
    18ec:      	tst	w14, #0x1
    18f0:      	csel	w10, w10, wzr, ne
    18f4:      	mov	w13, #0x40              ; =64
    18f8:      	dup.2d	v29, x13
    18fc:      	movi.2s	v27, #0x41
    1900:      	umlal.2d	v28, v30, v27
    1904:      	movi.2d	v30, #0000000000000000
    1908:      	mov.b	v30[0], v19[0]
    190c:      	add.2d	v27, v28, v29
    1910:      	ushll.2d	v19, v30, #0x0
    1914:      	shl.2d	v19, v19, #0x3f
    1918:      	cmlt.2d	v19, v19, #0
    191c:      	and.16b	v19, v19, v27
    1920:      	movi.2d	v28, #0000000000000000
    1924:      	stp	q28, q28, [sp, #0x180]
    1928:      	stp	q19, q28, [sp, #0x160]
    192c:      	and	x13, x10, #0x7
    1930:      	add	x15, sp, #0x160
    1934:      	ldr	x13, [x15, x13, lsl #3]
    1938:      	sub	x13, x13, x10
    193c:      	lsl	x13, x13, #2
    1940:      	add	x11, x11, x13
    1944:      	movi.2d	v19, #0000000000000000
    1948:      	tbz	w14, #0x0, 0x1988 <_llm_rows.packet_batch.blocks+0x112c>
    194c:      	ldr	s28, [x11]
    1950:      	tbnz	w12, #0x1, 0x198c <_llm_rows.packet_batch.blocks+0x1130>
    1954:      	tbz	w12, #0x2, 0x1998 <_llm_rows.packet_batch.blocks+0x113c>
    1958:      	add	x14, x11, #0x8
    195c:      	ld1.s	{ v28 }[2], [x14]
    1960:      	tbnz	w12, #0x3, 0x199c <_llm_rows.packet_batch.blocks+0x1140>
    1964:      	tbz	w12, #0x4, 0x19a8 <_llm_rows.packet_batch.blocks+0x114c>
    1968:      	add	x14, x11, #0x10
    196c:      	ld1.s	{ v19 }[0], [x14]
    1970:      	tbnz	w12, #0x5, 0x19ac <_llm_rows.packet_batch.blocks+0x1150>
    1974:      	tbz	w12, #0x6, 0x19b8 <_llm_rows.packet_batch.blocks+0x115c>
    1978:      	add	x14, x11, #0x18
    197c:      	ld1.s	{ v19 }[2], [x14]
    1980:      	tbnz	w12, #0x7, 0x19bc <_llm_rows.packet_batch.blocks+0x1160>
    1984:      	b	0x19c4 <_llm_rows.packet_batch.blocks+0x1168>
    1988:      	tbz	w12, #0x1, 0x1954 <_llm_rows.packet_batch.blocks+0x10f8>
    198c:      	add	x14, x11, #0x4
    1990:      	ld1.s	{ v28 }[1], [x14]
    1994:      	tbnz	w12, #0x2, 0x1958 <_llm_rows.packet_batch.blocks+0x10fc>
    1998:      	tbz	w12, #0x3, 0x1964 <_llm_rows.packet_batch.blocks+0x1108>
    199c:      	add	x14, x11, #0xc
    19a0:      	ld1.s	{ v28 }[3], [x14]
    19a4:      	tbnz	w12, #0x4, 0x1968 <_llm_rows.packet_batch.blocks+0x110c>
    19a8:      	tbz	w12, #0x5, 0x1974 <_llm_rows.packet_batch.blocks+0x1118>
    19ac:      	add	x14, x11, #0x14
    19b0:      	ld1.s	{ v19 }[1], [x14]
    19b4:      	tbnz	w12, #0x6, 0x1978 <_llm_rows.packet_batch.blocks+0x111c>
    19b8:      	tbz	w12, #0x7, 0x19c4 <_llm_rows.packet_batch.blocks+0x1168>
    19bc:      	add	x11, x11, #0x1c
    19c0:      	ld1.s	{ v19 }[3], [x11]
    19c4:      	shl.8b	v30, v20, #0x7
    19c8:      	cmlt.8b	v30, v30, #0
    19cc:      	and.8b	v30, v30, v31
    19d0:      	addv.8b	b31, v30
    19d4:      	fmov	w11, s31
    19d8:      	add	x9, x9, x13
    19dc:      	movi.2d	v8, #0000000000000000
    19e0:      	movi.2d	v30, #0000000000000000
    19e4:      	tbz	w11, #0x0, 0x1a24 <_llm_rows.packet_batch.blocks+0x11c8>
    19e8:      	ldr	s8, [x9]
    19ec:      	tbnz	w11, #0x1, 0x1a28 <_llm_rows.packet_batch.blocks+0x11cc>
    19f0:      	tbz	w11, #0x2, 0x1a34 <_llm_rows.packet_batch.blocks+0x11d8>
    19f4:      	add	x12, x9, #0x8
    19f8:      	ld1.s	{ v8 }[2], [x12]
    19fc:      	tbnz	w11, #0x3, 0x1a38 <_llm_rows.packet_batch.blocks+0x11dc>
    1a00:      	tbz	w11, #0x4, 0x1a44 <_llm_rows.packet_batch.blocks+0x11e8>
    1a04:      	add	x12, x9, #0x10
    1a08:      	ld1.s	{ v30 }[0], [x12]
    1a0c:      	tbnz	w11, #0x5, 0x1a48 <_llm_rows.packet_batch.blocks+0x11ec>
    1a10:      	tbz	w11, #0x6, 0x1a54 <_llm_rows.packet_batch.blocks+0x11f8>
    1a14:      	add	x12, x9, #0x18
    1a18:      	ld1.s	{ v30 }[2], [x12]
    1a1c:      	tbnz	w11, #0x7, 0x1a58 <_llm_rows.packet_batch.blocks+0x11fc>
    1a20:      	b	0x1a60 <_llm_rows.packet_batch.blocks+0x1204>
    1a24:      	tbz	w11, #0x1, 0x19f0 <_llm_rows.packet_batch.blocks+0x1194>
    1a28:      	add	x12, x9, #0x4
    1a2c:      	ld1.s	{ v8 }[1], [x12]
    1a30:      	tbnz	w11, #0x2, 0x19f4 <_llm_rows.packet_batch.blocks+0x1198>
    1a34:      	tbz	w11, #0x3, 0x1a00 <_llm_rows.packet_batch.blocks+0x11a4>
    1a38:      	add	x12, x9, #0xc
    1a3c:      	ld1.s	{ v8 }[3], [x12]
    1a40:      	tbnz	w11, #0x4, 0x1a04 <_llm_rows.packet_batch.blocks+0x11a8>
    1a44:      	tbz	w11, #0x5, 0x1a10 <_llm_rows.packet_batch.blocks+0x11b4>
    1a48:      	add	x12, x9, #0x14
    1a4c:      	ld1.s	{ v30 }[1], [x12]
    1a50:      	tbnz	w11, #0x6, 0x1a14 <_llm_rows.packet_batch.blocks+0x11b8>
    1a54:      	tbz	w11, #0x7, 0x1a60 <_llm_rows.packet_batch.blocks+0x1204>
    1a58:      	add	x9, x9, #0x1c
    1a5c:      	ld1.s	{ v30 }[3], [x9]
    1a60:      	movi.2s	v9, #0x41
    1a64:      	umlal.2d	v23, v26, v9
    1a68:      	add.2d	v23, v23, v29
    1a6c:      	umlal.2d	v22, v25, v9
    1a70:      	add.2d	v22, v22, v29
    1a74:      	umlal.2d	v21, v24, v9
    1a78:      	add.2d	v24, v21, v29
    1a7c:      	fneg.4s	v21, v28
    1a80:      	zip1.8b	v25, v20, v0
    1a84:      	ushll.4s	v25, v25, #0x0
    1a88:      	shl.4s	v25, v25, #0x1f
    1a8c:      	cmlt.4s	v25, v25, #0
    1a90:      	and.16b	v21, v25, v21
    1a94:      	fcmge.4s	v25, v21, v1
    1a98:      	fcmge.4s	v26, v0, v21
    1a9c:      	and.16b	v25, v25, v26
    1aa0:      	and.16b	v25, v25, v21
    1aa4:      	fmul.4s	v26, v25, v18
    1aa8:      	movi.4s	v29, #0x4b, lsl #24
    1aac:      	mvni.4s	v9, #0x80, lsl #24
    1ab0:      	bif.16b	v29, v26, v9
    1ab4:      	fadd.4s	v26, v26, v29
    1ab8:      	fsub.4s	v26, v26, v29
    1abc:      	fcvtzs.4s	v26, v26
    1ac0:      	scvtf.4s	v29, v26
    1ac4:      	fmul.4s	v9, v29, v17
    1ac8:      	fadd.4s	v25, v25, v9
    1acc:      	fmul.4s	v29, v29, v16
    1ad0:      	fadd.4s	v25, v25, v29
    1ad4:      	fmul.4s	v29, v25, v7
    1ad8:      	fadd.4s	v29, v29, v6
    1adc:      	fmul.4s	v29, v25, v29
    1ae0:      	fadd.4s	v29, v29, v5
    1ae4:      	fmul.4s	v29, v25, v29
    1ae8:      	fadd.4s	v29, v29, v4
    1aec:      	fmul.4s	v29, v25, v29
    1af0:      	fadd.4s	v29, v29, v3
    1af4:      	fmul.4s	v29, v25, v29
    1af8:      	movi.4s	v9, #0x3f, lsl #24
    1afc:      	fadd.4s	v29, v29, v9
    1b00:      	fmul.4s	v9, v25, v25
    1b04:      	fmul.4s	v29, v9, v29
    1b08:      	fadd.4s	v25, v25, v29
    1b0c:      	fadd.4s	v25, v25, v2
    1b10:      	sshr.4s	v29, v26, #0x1
    1b14:      	shl.4s	v9, v29, #0x17
    1b18:      	add.4s	v9, v9, v2
    1b1c:      	fmul.4s	v25, v25, v9
    1b20:      	sub.4s	v26, v26, v29
    1b24:      	shl.4s	v26, v26, #0x17
    1b28:      	add.4s	v26, v26, v2
    1b2c:      	fmul.4s	v25, v25, v26
    1b30:      	fcmgt.4s	v26, v1, v21
    1b34:      	fcmgt.4s	v29, v21, v0
    1b38:      	fcmeq.4s	v21, v21, v21
    1b3c:      	fadd.4s	v25, v25, v2
    1b40:      	bit.16b	v25, v2, v26
    1b44:      	ldr	q26, [sp, #0x110]
    1b48:      	bit.16b	v25, v26, v29
    1b4c:      	ldr	q26, [sp, #0x100]
    1b50:      	bsl.16b	v21, v25, v26
    1b54:      	fdiv.4s	v21, v28, v21
    1b58:      	fmul.4s	v21, v8, v21
    1b5c:      	stp	q27, q23, [sp, #0x120]
    1b60:      	stp	q22, q24, [sp, #0x140]
    1b64:      	and	x9, x10, #0x7
    1b68:      	add	x11, sp, #0x120
    1b6c:      	ldr	x9, [x11, x9, lsl #3]
    1b70:      	sub	x9, x9, x10
    1b74:      	add	x8, x8, x9, lsl #2
    1b78:      	fmov	w9, s31
    1b7c:      	tbz	w9, #0x0, 0x1b9c <_llm_rows.packet_batch.blocks+0x1340>
    1b80:      	str	s21, [x8]
    1b84:      	tbnz	w9, #0x1, 0x1ba0 <_llm_rows.packet_batch.blocks+0x1344>
    1b88:      	tbz	w9, #0x2, 0x1bac <_llm_rows.packet_batch.blocks+0x1350>
    1b8c:      	add	x10, x8, #0x8
    1b90:      	st1.s	{ v21 }[2], [x10]
    1b94:      	tbnz	w9, #0x3, 0x1bb0 <_llm_rows.packet_batch.blocks+0x1354>
    1b98:      	b	0x1bb8 <_llm_rows.packet_batch.blocks+0x135c>
    1b9c:      	tbz	w9, #0x1, 0x1b88 <_llm_rows.packet_batch.blocks+0x132c>
    1ba0:      	add	x10, x8, #0x4
    1ba4:      	st1.s	{ v21 }[1], [x10]
    1ba8:      	tbnz	w9, #0x2, 0x1b8c <_llm_rows.packet_batch.blocks+0x1330>
    1bac:      	tbz	w9, #0x3, 0x1bb8 <_llm_rows.packet_batch.blocks+0x135c>
    1bb0:      	add	x10, x8, #0xc
    1bb4:      	st1.s	{ v21 }[3], [x10]
    1bb8:      	fneg.4s	v21, v19
    1bbc:      	zip2.8b	v20, v20, v0
    1bc0:      	ushll.4s	v20, v20, #0x0
    1bc4:      	shl.4s	v20, v20, #0x1f
    1bc8:      	cmlt.4s	v20, v20, #0
    1bcc:      	and.16b	v20, v20, v21
    1bd0:      	fcmge.4s	v21, v20, v1
    1bd4:      	fcmge.4s	v22, v0, v20
    1bd8:      	and.16b	v21, v21, v22
    1bdc:      	and.16b	v21, v21, v20
    1be0:      	fmul.4s	v18, v21, v18
    1be4:      	movi.4s	v22, #0x4b, lsl #24
    1be8:      	mvni.4s	v23, #0x80, lsl #24
    1bec:      	bif.16b	v22, v18, v23
    1bf0:      	fadd.4s	v18, v18, v22
    1bf4:      	fsub.4s	v18, v18, v22
    1bf8:      	fcvtzs.4s	v18, v18
    1bfc:      	scvtf.4s	v22, v18
    1c00:      	fmul.4s	v17, v22, v17
    1c04:      	fadd.4s	v17, v21, v17
    1c08:      	fmul.4s	v16, v22, v16
    1c0c:      	fadd.4s	v16, v17, v16
    1c10:      	fmul.4s	v7, v16, v7
    1c14:      	fadd.4s	v6, v7, v6
    1c18:      	fmul.4s	v6, v16, v6
    1c1c:      	fadd.4s	v5, v6, v5
    1c20:      	fmul.4s	v5, v16, v5
    1c24:      	fadd.4s	v4, v5, v4
    1c28:      	fmul.4s	v4, v16, v4
    1c2c:      	fadd.4s	v3, v4, v3
    1c30:      	fmul.4s	v3, v16, v3
    1c34:      	movi.4s	v4, #0x3f, lsl #24
    1c38:      	fadd.4s	v3, v3, v4
    1c3c:      	fmul.4s	v4, v16, v16
    1c40:      	fmul.4s	v3, v4, v3
    1c44:      	fadd.4s	v3, v16, v3
    1c48:      	fadd.4s	v3, v3, v2
    1c4c:      	sshr.4s	v4, v18, #0x1
    1c50:      	shl.4s	v5, v4, #0x17
    1c54:      	add.4s	v5, v5, v2
    1c58:      	fmul.4s	v3, v3, v5
    1c5c:      	sub.4s	v4, v18, v4
    1c60:      	shl.4s	v4, v4, #0x17
    1c64:      	add.4s	v4, v4, v2
    1c68:      	fmul.4s	v3, v3, v4
    1c6c:      	fcmgt.4s	v1, v1, v20
    1c70:      	fcmgt.4s	v0, v20, v0
    1c74:      	fcmeq.4s	v4, v20, v20
    1c78:      	fadd.4s	v3, v3, v2
    1c7c:      	bsl.16b	v1, v2, v3
    1c80:      	ldr	q2, [sp, #0x110]
    1c84:      	bsl.16b	v0, v2, v1
    1c88:      	ldr	q1, [sp, #0x100]
    1c8c:      	bif.16b	v0, v1, v4
    1c90:      	fdiv.4s	v0, v19, v0
    1c94:      	fmul.4s	v0, v30, v0
    1c98:      	tbnz	w9, #0x4, 0x18a0 <_llm_rows.packet_batch.blocks+0x1044>
    1c9c:      	tbz	w9, #0x5, 0x18a8 <_llm_rows.packet_batch.blocks+0x104c>
    1ca0:      	add	x10, x8, #0x14
    1ca4:      	st1.s	{ v0 }[1], [x10]
    1ca8:      	tbnz	w9, #0x6, 0x18ac <_llm_rows.packet_batch.blocks+0x1050>
    1cac:      	tbz	w9, #0x7, 0x924 <_llm_rows.packet_batch.blocks+0xc8>
    1cb0:      	add	x8, x8, #0x1c
    1cb4:      	st1.s	{ v0 }[3], [x8]
    1cb8:      	b	0x924 <_llm_rows.packet_batch.blocks+0xc8>
    1cbc:      	add	sp, sp, #0x4d0
    1cc0:      	ldp	x29, x30, [sp, #0x90]
    1cc4:      	ldp	x20, x19, [sp, #0x80]
    1cc8:      	ldp	x22, x21, [sp, #0x70]
    1ccc:      	ldp	x24, x23, [sp, #0x60]
    1cd0:      	ldp	x26, x25, [sp, #0x50]
    1cd4:      	ldp	x28, x27, [sp, #0x40]
    1cd8:      	ldp	d9, d8, [sp, #0x30]
    1cdc:      	ldp	d11, d10, [sp, #0x20]
    1ce0:      	ldp	d13, d12, [sp, #0x10]
    1ce4:      	ldp	d15, d14, [sp], #0xa0
    1ce8:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/swiglu-257x1538/on/object/tile_xir_w8_37999_1788936542130830_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d11, d10, [sp, #-0x70]!
       4:      	stp	d9, d8, [sp, #0x10]
       8:      	stp	x28, x27, [sp, #0x20]
       c:      	stp	x24, x23, [sp, #0x30]
      10:      	stp	x22, x21, [sp, #0x40]
      14:      	stp	x20, x19, [sp, #0x50]
      18:      	stp	x29, x30, [sp, #0x60]
      1c:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      20:      	sub	sp, sp, #0x50
      24:      	ldr	x23, [x0]
      28:      	ldr	x21, [x0, #0x10]
      2c:      	ldr	x19, [x0, #0x30]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w8, w8, #3
      40:      	subs	x9, x23, x19
      44:      	mov	w10, #0x2007            ; =8199
      48:      	movk	w10, #0x18, lsl #16
      4c:      	ccmp	x9, x10, #0x0, hs
      50:      	cset	w9, hi
      54:      	subs	x11, x19, x23
      58:      	ccmp	x11, x10, #0x0, hs
      5c:      	csinc	w9, w9, wzr, ls
      60:      	subs	x11, x21, x19
      64:      	ccmp	x11, x10, #0x0, hs
      68:      	cset	w11, hi
      6c:      	subs	x12, x19, x21
      70:      	ccmp	x12, x10, #0x0, hs
      74:      	csinc	w10, w11, wzr, ls
      78:      	mov	w11, #0x1808            ; =6152
      7c:      	umull	x22, w8, w11
      80:      	cmp	w9, #0x1
      84:      	ccmp	w10, #0x0, #0x4, eq
      88:      	b.ne	0x47c <ltmp0+0x47c>
      8c:      	mov	w20, #0x1800            ; =6144
      90:      	add	x24, sp, #0x1, lsl #12  ; =0x1000
      94:      	add	x24, x24, #0x830
      98:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
      9c:      	add	x0, x0, #0x830
      a0:      	add	x1, x23, x22
      a4:      	mov	w2, #0x1800             ; =6144
      a8:      	bl	0xa8 <ltmp0+0xa8>
      ac:      	add	x20, x22, x20
      b0:      	add	x8, x23, x20
      b4:      	add	x9, x8, #0x4
      b8:      	ldr	s0, [x8]
      bc:      	ld1.s	{ v0 }[1], [x9]
      c0:      	str	q0, [sp]
      c4:      	str	q0, [sp, #0x3030]
      c8:      	add	x23, sp, #0x10
      cc:      	add	x0, sp, #0x10
      d0:      	add	x1, x21, x22
      d4:      	mov	w2, #0x1800             ; =6144
      d8:      	bl	0xd8 <ltmp0+0xd8>
      dc:      	mov	x8, #0x0                ; =0
      e0:      	add	x9, x21, x20
      e4:      	ldr	s0, [x9], #0x4
      e8:      	ld1.s	{ v0 }[1], [x9]
      ec:      	str	q0, [sp, #0x1810]
      f0:      	mov	w9, #0x42d00000         ; =1120927744
      f4:      	dup.4s	v2, w9
      f8:      	mov	w9, #-0x3d380000        ; =-1027080192
      fc:      	dup.4s	v3, w9
     100:      	mov	w9, #0xaa3b             ; =43579
     104:      	movk	w9, #0x3fb8, lsl #16
     108:      	dup.4s	v4, w9
     10c:      	add	x9, x19, x22
     110:      	movi.4s	v5, #0x4b, lsl #24
     114:      	mvni.4s	v6, #0x80, lsl #24
     118:      	mov	w10, #0x7200            ; =29184
     11c:      	movk	w10, #0xbf31, lsl #16
     120:      	dup.4s	v7, w10
     124:      	mov	w10, #0xbe8e            ; =48782
     128:      	movk	w10, #0xb5bf, lsl #16
     12c:      	dup.4s	v16, w10
     130:      	mov	w10, #0x2bda            ; =11226
     134:      	movk	w10, #0x3950, lsl #16
     138:      	dup.4s	v17, w10
     13c:      	mov	w10, #0x96c9            ; =38601
     140:      	movk	w10, #0x3ab6, lsl #16
     144:      	dup.4s	v18, w10
     148:      	mov	w10, #0x88a6            ; =34982
     14c:      	movk	w10, #0x3c08, lsl #16
     150:      	dup.4s	v19, w10
     154:      	mov	w10, #0xaa7a            ; =43642
     158:      	movk	w10, #0x3d2a, lsl #16
     15c:      	dup.4s	v20, w10
     160:      	mov	w10, #0xaaab            ; =43691
     164:      	movk	w10, #0x3e2a, lsl #16
     168:      	dup.4s	v21, w10
     16c:      	movi.4s	v22, #0x3f, lsl #24
     170:      	fmov.4s	v1, #1.00000000
     174:      	mvni.4s	v23, #0x7f, msl #16
     178:      	fneg.4s	v23, v23
     17c:      	mvni.4s	v24, #0x3f, msl #16
     180:      	fneg.4s	v24, v24
     184:      	lsl	x10, x8, #5
     188:      	add	x11, x24, x10
     18c:      	ldp	q25, q26, [x11]
     190:      	fneg.4s	v27, v26
     194:      	fneg.4s	v28, v25
     198:      	fcmge.4s	v29, v2, v25
     19c:      	fcmge.4s	v30, v2, v26
     1a0:      	fcmge.4s	v31, v25, v3
     1a4:      	fcmge.4s	v8, v26, v3
     1a8:      	and.16b	v30, v30, v8
     1ac:      	and.16b	v29, v29, v31
     1b0:      	and.16b	v28, v29, v28
     1b4:      	and.16b	v27, v30, v27
     1b8:      	fmul.4s	v29, v27, v4
     1bc:      	fmul.4s	v30, v28, v4
     1c0:      	mov.16b	v31, v6
     1c4:      	bsl.16b	v31, v5, v30
     1c8:      	mov.16b	v8, v6
     1cc:      	bsl.16b	v8, v5, v29
     1d0:      	fadd.4s	v29, v29, v8
     1d4:      	fadd.4s	v30, v30, v31
     1d8:      	fsub.4s	v30, v30, v31
     1dc:      	fsub.4s	v29, v29, v8
     1e0:      	fcvtzs.4s	v29, v29
     1e4:      	fcvtzs.4s	v30, v30
     1e8:      	scvtf.4s	v31, v30
     1ec:      	scvtf.4s	v8, v29
     1f0:      	fmul.4s	v9, v8, v7
     1f4:      	fmul.4s	v10, v31, v7
     1f8:      	fadd.4s	v28, v28, v10
     1fc:      	fadd.4s	v27, v27, v9
     200:      	fmul.4s	v31, v31, v16
     204:      	fmul.4s	v8, v8, v16
     208:      	fadd.4s	v27, v27, v8
     20c:      	fadd.4s	v28, v28, v31
     210:      	fmul.4s	v31, v28, v17
     214:      	fmul.4s	v8, v27, v17
     218:      	fadd.4s	v8, v8, v18
     21c:      	fadd.4s	v31, v31, v18
     220:      	fmul.4s	v31, v28, v31
     224:      	fmul.4s	v8, v27, v8
     228:      	fadd.4s	v8, v8, v19
     22c:      	fadd.4s	v31, v31, v19
     230:      	fmul.4s	v31, v28, v31
     234:      	fmul.4s	v8, v27, v8
     238:      	fadd.4s	v8, v8, v20
     23c:      	fadd.4s	v31, v31, v20
     240:      	fmul.4s	v31, v28, v31
     244:      	fmul.4s	v8, v27, v8
     248:      	fadd.4s	v8, v8, v21
     24c:      	fadd.4s	v31, v31, v21
     250:      	fmul.4s	v31, v28, v31
     254:      	fmul.4s	v8, v27, v8
     258:      	fadd.4s	v8, v8, v22
     25c:      	fadd.4s	v31, v31, v22
     260:      	fmul.4s	v9, v27, v27
     264:      	fmul.4s	v10, v28, v28
     268:      	fmul.4s	v31, v10, v31
     26c:      	fmul.4s	v8, v9, v8
     270:      	fadd.4s	v27, v27, v8
     274:      	fadd.4s	v28, v28, v31
     278:      	sshr.4s	v31, v30, #0x1
     27c:      	fadd.4s	v28, v28, v1
     280:      	sshr.4s	v8, v29, #0x1
     284:      	shl.4s	v9, v8, #0x17
     288:      	shl.4s	v10, v31, #0x17
     28c:      	add.4s	v10, v10, v1
     290:      	add.4s	v9, v9, v1
     294:      	fadd.4s	v27, v27, v1
     298:      	fmul.4s	v27, v27, v9
     29c:      	sub.4s	v29, v29, v8
     2a0:      	sub.4s	v30, v30, v31
     2a4:      	shl.4s	v30, v30, #0x17
     2a8:      	shl.4s	v29, v29, #0x17
     2ac:      	fmul.4s	v28, v28, v10
     2b0:      	add.4s	v29, v29, v1
     2b4:      	add.4s	v30, v30, v1
     2b8:      	fmul.4s	v28, v28, v30
     2bc:      	fmul.4s	v27, v27, v29
     2c0:      	fcmgt.4s	v29, v26, v2
     2c4:      	fcmgt.4s	v30, v25, v2
     2c8:      	fcmgt.4s	v31, v3, v25
     2cc:      	fcmgt.4s	v8, v3, v26
     2d0:      	fcmeq.4s	v9, v26, v26
     2d4:      	fadd.4s	v27, v27, v1
     2d8:      	fadd.4s	v28, v28, v1
     2dc:      	fcmeq.4s	v10, v25, v25
     2e0:      	bit.16b	v28, v1, v30
     2e4:      	bit.16b	v27, v1, v29
     2e8:      	bit.16b	v27, v23, v8
     2ec:      	bit.16b	v28, v23, v31
     2f0:      	bif.16b	v28, v24, v10
     2f4:      	bif.16b	v27, v24, v9
     2f8:      	fdiv.4s	v26, v26, v27
     2fc:      	fdiv.4s	v25, v25, v28
     300:      	add	x11, x23, x10
     304:      	ldp	q28, q27, [x11]
     308:      	fmul.4s	v25, v28, v25
     30c:      	fmul.4s	v26, v27, v26
     310:      	add	x10, x9, x10
     314:      	stp	q25, q26, [x10]
     318:      	add	x8, x8, #0x1
     31c:      	cmp	x8, #0xc0
     320:      	b.ne	0x184 <ltmp0+0x184>
     324:      	movi.2d	v3, #0000000000000000
     328:      	movi.2d	v2, #0000000000000000
     32c:      	ldr	q4, [sp]
     330:      	mov.d	v2[0], v4[0]
     334:      	fneg.4s	v4, v2
     338:      	mov.d	v3[0], v4[0]
     33c:      	mov	w8, #-0x3d300000        ; =-1026555904
     340:      	dup.4s	v4, w8
     344:      	fcmge.4s	v5, v3, v4
     348:      	mov	w8, #0x42c80000         ; =1120403456
     34c:      	dup.4s	v6, w8
     350:      	fcmge.4s	v7, v6, v3
     354:      	and.16b	v5, v5, v7
     358:      	and.16b	v5, v5, v3
     35c:      	mov	w8, #0xaa3b             ; =43579
     360:      	movk	w8, #0x3fb8, lsl #16
     364:      	dup.4s	v7, w8
     368:      	fmul.4s	v7, v5, v7
     36c:      	movi.4s	v16, #0x4b, lsl #24
     370:      	mvni.4s	v17, #0x80, lsl #24
     374:      	bif.16b	v16, v7, v17
     378:      	fadd.4s	v7, v7, v16
     37c:      	fsub.4s	v7, v7, v16
     380:      	fcvtzs.4s	v7, v7
     384:      	scvtf.4s	v16, v7
     388:      	mov	w8, #0x7200             ; =29184
     38c:      	movk	w8, #0xbf31, lsl #16
     390:      	dup.4s	v17, w8
     394:      	fmul.4s	v17, v16, v17
     398:      	mov	w8, #0xbe8e             ; =48782
     39c:      	movk	w8, #0xb5bf, lsl #16
     3a0:      	dup.4s	v18, w8
     3a4:      	fadd.4s	v5, v5, v17
     3a8:      	fmul.4s	v16, v16, v18
     3ac:      	fadd.4s	v5, v5, v16
     3b0:      	mov	w8, #0x2bda             ; =11226
     3b4:      	movk	w8, #0x3950, lsl #16
     3b8:      	dup.4s	v16, w8
     3bc:      	fmul.4s	v16, v5, v16
     3c0:      	mov	w8, #0x96c9             ; =38601
     3c4:      	movk	w8, #0x3ab6, lsl #16
     3c8:      	dup.4s	v17, w8
     3cc:      	fadd.4s	v16, v16, v17
     3d0:      	fmul.4s	v16, v5, v16
     3d4:      	mov	w8, #0x88a6             ; =34982
     3d8:      	movk	w8, #0x3c08, lsl #16
     3dc:      	dup.4s	v17, w8
     3e0:      	fadd.4s	v16, v16, v17
     3e4:      	fmul.4s	v16, v5, v16
     3e8:      	mov	w8, #0xaa7a             ; =43642
     3ec:      	movk	w8, #0x3d2a, lsl #16
     3f0:      	dup.4s	v17, w8
     3f4:      	fadd.4s	v16, v16, v17
     3f8:      	mov	w8, #0xaaab             ; =43691
     3fc:      	movk	w8, #0x3e2a, lsl #16
     400:      	dup.4s	v17, w8
     404:      	fmul.4s	v16, v5, v16
     408:      	fadd.4s	v16, v16, v17
     40c:      	fmul.4s	v16, v5, v16
     410:      	movi.4s	v17, #0x3f, lsl #24
     414:      	fadd.4s	v16, v16, v17
     418:      	fmul.4s	v17, v5, v5
     41c:      	fmul.4s	v16, v17, v16
     420:      	fadd.4s	v5, v5, v16
     424:      	fadd.4s	v5, v5, v1
     428:      	sshr.4s	v16, v7, #0x1
     42c:      	shl.4s	v17, v16, #0x17
     430:      	add.4s	v17, v17, v1
     434:      	fmul.4s	v5, v5, v17
     438:      	sub.4s	v7, v7, v16
     43c:      	shl.4s	v7, v7, #0x17
     440:      	add.4s	v7, v7, v1
     444:      	fmul.4s	v5, v5, v7
     448:      	fcmgt.4s	v4, v4, v3
     44c:      	fcmgt.4s	v6, v3, v6
     450:      	fcmeq.4s	v3, v3, v3
     454:      	fadd.4s	v5, v5, v1
     458:      	bif.16b	v1, v5, v4
     45c:      	mvni.4s	v4, #0x7f, msl #16
     460:      	fneg.4s	v4, v4
     464:      	bit.16b	v1, v4, v6
     468:      	mvni.4s	v4, #0x3f, msl #16
     46c:      	fneg.4s	v4, v4
     470:      	bif.16b	v1, v4, v3
     474:      	fdiv.4s	v1, v2, v1
     478:      	b	0x82c <ltmp0+0x82c>
     47c:      	mov	x8, #0x0                ; =0
     480:      	add	x9, x19, x22
     484:      	add	x10, x21, x22
     488:      	mov	w11, #0x42d00000        ; =1120927744
     48c:      	dup.4s	v1, w11
     490:      	mov	w11, #-0x3d380000       ; =-1027080192
     494:      	dup.4s	v2, w11
     498:      	mov	w11, #0xaa3b            ; =43579
     49c:      	movk	w11, #0x3fb8, lsl #16
     4a0:      	dup.4s	v3, w11
     4a4:      	mov	w11, #0x7200            ; =29184
     4a8:      	movk	w11, #0xbf31, lsl #16
     4ac:      	dup.4s	v4, w11
     4b0:      	mov	w11, #0xbe8e            ; =48782
     4b4:      	movk	w11, #0xb5bf, lsl #16
     4b8:      	dup.4s	v5, w11
     4bc:      	mov	w11, #0x2bda            ; =11226
     4c0:      	movk	w11, #0x3950, lsl #16
     4c4:      	dup.4s	v6, w11
     4c8:      	mov	w11, #0x96c9            ; =38601
     4cc:      	movk	w11, #0x3ab6, lsl #16
     4d0:      	dup.4s	v7, w11
     4d4:      	mov	w11, #0x88a6            ; =34982
     4d8:      	movk	w11, #0x3c08, lsl #16
     4dc:      	dup.4s	v16, w11
     4e0:      	mov	w11, #0xaa7a            ; =43642
     4e4:      	movk	w11, #0x3d2a, lsl #16
     4e8:      	dup.4s	v17, w11
     4ec:      	mov	w11, #0xaaab            ; =43691
     4f0:      	movk	w11, #0x3e2a, lsl #16
     4f4:      	dup.4s	v18, w11
     4f8:      	add	x11, x23, x22
     4fc:      	movi.4s	v19, #0x4b, lsl #24
     500:      	mvni.4s	v20, #0x80, lsl #24
     504:      	movi.4s	v21, #0x3f, lsl #24
     508:      	fmov.4s	v0, #1.00000000
     50c:      	mvni.4s	v22, #0x7f, msl #16
     510:      	fneg.4s	v22, v22
     514:      	mvni.4s	v23, #0x3f, msl #16
     518:      	fneg.4s	v23, v23
     51c:      	lsl	x12, x8, #5
     520:      	add	x13, x11, x12
     524:      	ldp	q24, q25, [x13]
     528:      	fneg.4s	v26, v25
     52c:      	fneg.4s	v27, v24
     530:      	fcmge.4s	v28, v1, v24
     534:      	fcmge.4s	v29, v1, v25
     538:      	fcmge.4s	v30, v24, v2
     53c:      	fcmge.4s	v31, v25, v2
     540:      	and.16b	v29, v29, v31
     544:      	and.16b	v28, v28, v30
     548:      	and.16b	v27, v28, v27
     54c:      	and.16b	v26, v29, v26
     550:      	fmul.4s	v28, v26, v3
     554:      	fmul.4s	v29, v27, v3
     558:      	mov.16b	v30, v20
     55c:      	bsl.16b	v30, v19, v29
     560:      	mov.16b	v31, v20
     564:      	bsl.16b	v31, v19, v28
     568:      	fadd.4s	v28, v28, v31
     56c:      	fadd.4s	v29, v29, v30
     570:      	fsub.4s	v29, v29, v30
     574:      	fsub.4s	v28, v28, v31
     578:      	fcvtzs.4s	v28, v28
     57c:      	fcvtzs.4s	v29, v29
     580:      	scvtf.4s	v30, v29
     584:      	scvtf.4s	v31, v28
     588:      	fmul.4s	v8, v31, v4
     58c:      	fmul.4s	v9, v30, v4
     590:      	fadd.4s	v27, v27, v9
     594:      	fadd.4s	v26, v26, v8
     598:      	fmul.4s	v30, v30, v5
     59c:      	fmul.4s	v31, v31, v5
     5a0:      	fadd.4s	v26, v26, v31
     5a4:      	fadd.4s	v27, v27, v30
     5a8:      	fmul.4s	v30, v27, v6
     5ac:      	fmul.4s	v31, v26, v6
     5b0:      	fadd.4s	v31, v31, v7
     5b4:      	fadd.4s	v30, v30, v7
     5b8:      	fmul.4s	v30, v27, v30
     5bc:      	fmul.4s	v31, v26, v31
     5c0:      	fadd.4s	v31, v31, v16
     5c4:      	fadd.4s	v30, v30, v16
     5c8:      	fmul.4s	v30, v27, v30
     5cc:      	fmul.4s	v31, v26, v31
     5d0:      	fadd.4s	v31, v31, v17
     5d4:      	fadd.4s	v30, v30, v17
     5d8:      	fmul.4s	v30, v27, v30
     5dc:      	fmul.4s	v31, v26, v31
     5e0:      	fadd.4s	v31, v31, v18
     5e4:      	fadd.4s	v30, v30, v18
     5e8:      	fmul.4s	v30, v27, v30
     5ec:      	fmul.4s	v31, v26, v31
     5f0:      	fadd.4s	v31, v31, v21
     5f4:      	fadd.4s	v30, v30, v21
     5f8:      	fmul.4s	v8, v26, v26
     5fc:      	fmul.4s	v9, v27, v27
     600:      	fmul.4s	v30, v9, v30
     604:      	fmul.4s	v31, v8, v31
     608:      	fadd.4s	v26, v26, v31
     60c:      	fadd.4s	v27, v27, v30
     610:      	sshr.4s	v30, v29, #0x1
     614:      	fadd.4s	v27, v27, v0
     618:      	sshr.4s	v31, v28, #0x1
     61c:      	shl.4s	v8, v31, #0x17
     620:      	shl.4s	v9, v30, #0x17
     624:      	add.4s	v9, v9, v0
     628:      	add.4s	v8, v8, v0
     62c:      	fadd.4s	v26, v26, v0
     630:      	fmul.4s	v26, v26, v8
     634:      	sub.4s	v28, v28, v31
     638:      	sub.4s	v29, v29, v30
     63c:      	shl.4s	v29, v29, #0x17
     640:      	shl.4s	v28, v28, #0x17
     644:      	fmul.4s	v27, v27, v9
     648:      	add.4s	v28, v28, v0
     64c:      	add.4s	v29, v29, v0
     650:      	fmul.4s	v27, v27, v29
     654:      	fmul.4s	v26, v26, v28
     658:      	fcmgt.4s	v28, v25, v1
     65c:      	fcmgt.4s	v29, v24, v1
     660:      	fcmgt.4s	v30, v2, v24
     664:      	fcmgt.4s	v31, v2, v25
     668:      	fcmeq.4s	v8, v25, v25
     66c:      	fadd.4s	v26, v26, v0
     670:      	fadd.4s	v27, v27, v0
     674:      	fcmeq.4s	v9, v24, v24
     678:      	bit.16b	v27, v0, v29
     67c:      	bit.16b	v26, v0, v28
     680:      	bit.16b	v26, v22, v31
     684:      	bit.16b	v27, v22, v30
     688:      	bif.16b	v27, v23, v9
     68c:      	bif.16b	v26, v23, v8
     690:      	fdiv.4s	v25, v25, v26
     694:      	fdiv.4s	v24, v24, v27
     698:      	add	x13, x10, x12
     69c:      	ldp	q27, q26, [x13]
     6a0:      	fmul.4s	v24, v27, v24
     6a4:      	fmul.4s	v25, v26, v25
     6a8:      	add	x12, x9, x12
     6ac:      	stp	q24, q25, [x12]
     6b0:      	add	x8, x8, #0x1
     6b4:      	cmp	x8, #0xc0
     6b8:      	b.ne	0x51c <ltmp0+0x51c>
     6bc:      	mov	w8, #0x1800             ; =6144
     6c0:      	add	x20, x22, x8
     6c4:      	add	x8, x23, x20
     6c8:      	movi.2d	v2, #0000000000000000
     6cc:      	movi.2d	v1, #0000000000000000
     6d0:      	ld1.s	{ v1 }[0], [x8], #4
     6d4:      	ld1.s	{ v1 }[1], [x8]
     6d8:      	fneg.4s	v3, v1
     6dc:      	mov.d	v2[0], v3[0]
     6e0:      	mov	w8, #-0x3d300000        ; =-1026555904
     6e4:      	dup.4s	v3, w8
     6e8:      	fcmge.4s	v4, v2, v3
     6ec:      	mov	w8, #0x42c80000         ; =1120403456
     6f0:      	dup.4s	v5, w8
     6f4:      	fcmge.4s	v6, v5, v2
     6f8:      	and.16b	v4, v4, v6
     6fc:      	and.16b	v4, v4, v2
     700:      	mov	w8, #0xaa3b             ; =43579
     704:      	movk	w8, #0x3fb8, lsl #16
     708:      	dup.4s	v6, w8
     70c:      	fmul.4s	v6, v4, v6
     710:      	movi.4s	v7, #0x4b, lsl #24
     714:      	mvni.4s	v16, #0x80, lsl #24
     718:      	bif.16b	v7, v6, v16
     71c:      	fadd.4s	v6, v6, v7
     720:      	fsub.4s	v6, v6, v7
     724:      	fcvtzs.4s	v6, v6
     728:      	scvtf.4s	v7, v6
     72c:      	mov	w8, #0x7200             ; =29184
     730:      	movk	w8, #0xbf31, lsl #16
     734:      	dup.4s	v16, w8
     738:      	fmul.4s	v16, v7, v16
     73c:      	fadd.4s	v4, v4, v16
     740:      	mov	w8, #0xbe8e             ; =48782
     744:      	movk	w8, #0xb5bf, lsl #16
     748:      	dup.4s	v16, w8
     74c:      	fmul.4s	v7, v7, v16
     750:      	mov	w8, #0x2bda             ; =11226
     754:      	movk	w8, #0x3950, lsl #16
     758:      	dup.4s	v16, w8
     75c:      	fadd.4s	v4, v4, v7
     760:      	fmul.4s	v7, v4, v16
     764:      	mov	w8, #0x96c9             ; =38601
     768:      	movk	w8, #0x3ab6, lsl #16
     76c:      	dup.4s	v16, w8
     770:      	fadd.4s	v7, v7, v16
     774:      	fmul.4s	v7, v4, v7
     778:      	mov	w8, #0x88a6             ; =34982
     77c:      	movk	w8, #0x3c08, lsl #16
     780:      	dup.4s	v16, w8
     784:      	fadd.4s	v7, v7, v16
     788:      	fmul.4s	v7, v4, v7
     78c:      	mov	w8, #0xaa7a             ; =43642
     790:      	movk	w8, #0x3d2a, lsl #16
     794:      	dup.4s	v16, w8
     798:      	fadd.4s	v7, v7, v16
     79c:      	fmul.4s	v7, v4, v7
     7a0:      	mov	w8, #0xaaab             ; =43691
     7a4:      	movk	w8, #0x3e2a, lsl #16
     7a8:      	dup.4s	v16, w8
     7ac:      	fadd.4s	v7, v7, v16
     7b0:      	fmul.4s	v7, v4, v7
     7b4:      	movi.4s	v16, #0x3f, lsl #24
     7b8:      	fadd.4s	v7, v7, v16
     7bc:      	fmul.4s	v16, v4, v4
     7c0:      	fmul.4s	v7, v16, v7
     7c4:      	fadd.4s	v4, v4, v7
     7c8:      	fadd.4s	v4, v4, v0
     7cc:      	sshr.4s	v7, v6, #0x1
     7d0:      	shl.4s	v16, v7, #0x17
     7d4:      	add.4s	v16, v16, v0
     7d8:      	fmul.4s	v4, v4, v16
     7dc:      	sub.4s	v6, v6, v7
     7e0:      	shl.4s	v6, v6, #0x17
     7e4:      	add.4s	v6, v6, v0
     7e8:      	fmul.4s	v4, v4, v6
     7ec:      	fcmgt.4s	v3, v3, v2
     7f0:      	fcmgt.4s	v5, v2, v5
     7f4:      	fcmeq.4s	v2, v2, v2
     7f8:      	fadd.4s	v4, v4, v0
     7fc:      	bif.16b	v0, v4, v3
     800:      	mvni.4s	v3, #0x7f, msl #16
     804:      	fneg.4s	v3, v3
     808:      	bit.16b	v0, v3, v5
     80c:      	mvni.4s	v3, #0x3f, msl #16
     810:      	fneg.4s	v3, v3
     814:      	bif.16b	v0, v3, v2
     818:      	fdiv.4s	v0, v1, v0
     81c:      	add	x8, x21, x20
     820:      	add	x9, x8, #0x4
     824:      	ldr	s1, [x8]
     828:      	ld1.s	{ v1 }[1], [x9]
     82c:      	fmul.4s	v0, v1, v0
     830:      	str	d0, [x19, x20]
     834:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
     838:      	add	sp, sp, #0x50
     83c:      	ldp	x29, x30, [sp, #0x60]
     840:      	ldp	x20, x19, [sp, #0x50]
     844:      	ldp	x22, x21, [sp, #0x40]
     848:      	ldp	x24, x23, [sp, #0x30]
     84c:      	ldp	x28, x27, [sp, #0x20]
     850:      	ldp	d9, d8, [sp, #0x10]
     854:      	ldp	d11, d10, [sp], #0x70
     858:      	ret

000000000000085c <_llm_rows.packet_batch.blocks>:
     85c:      	stp	d15, d14, [sp, #-0xa0]!
     860:      	stp	d13, d12, [sp, #0x10]
     864:      	stp	d11, d10, [sp, #0x20]
     868:      	stp	d9, d8, [sp, #0x30]
     86c:      	stp	x28, x27, [sp, #0x40]
     870:      	stp	x26, x25, [sp, #0x50]
     874:      	stp	x24, x23, [sp, #0x60]
     878:      	stp	x22, x21, [sp, #0x70]
     87c:      	stp	x20, x19, [sp, #0x80]
     880:      	stp	x29, x30, [sp, #0x90]
     884:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
     888:      	sub	sp, sp, #0x2d0
     88c:      	str	x0, [sp, #0xe8]
     890:      	cbz	w3, 0x1cd4 <_llm_rows.packet_batch.blocks+0x1478>
     894:      	mov	x19, x3
     898:      	mov	x20, x2
     89c:      	mov	w22, #0x0               ; =0
     8a0:      	ldp	w9, w8, [x2, #0x2c]
     8a4:      	stp	w8, w9, [sp, #0xe0]
     8a8:      	ldp	w27, w25, [x2]
     8ac:      	adrp	x8, 0x0 <ltmp0>
     8b0:      	ldr	q0, [x8]
     8b4:      	str	q0, [sp, #0xb0]
     8b8:      	adrp	x8, 0x0 <ltmp0>
     8bc:      	ldr	q0, [x8]
     8c0:      	str	q0, [sp, #0xa0]
     8c4:      	adrp	x8, 0x0 <ltmp0>
     8c8:      	ldr	q0, [x8]
     8cc:      	str	q0, [sp, #0x90]
     8d0:      	adrp	x8, 0x0 <ltmp0>
     8d4:      	ldr	q0, [x8]
     8d8:      	str	q0, [sp, #0x80]
     8dc:      	adrp	x8, 0x0 <ltmp0>
     8e0:      	ldr	q0, [x8]
     8e4:      	str	q0, [sp, #0x70]
     8e8:      	adrp	x8, 0x0 <ltmp0>
     8ec:      	ldr	q0, [x8]
     8f0:      	str	q0, [sp, #0x60]
     8f4:      	adrp	x8, 0x0 <ltmp0>
     8f8:      	ldr	q1, [x8]
     8fc:      	mvni.4s	v0, #0x7f, msl #16
     900:      	fneg.4s	v0, v0
     904:      	str	q0, [sp, #0x110]
     908:      	mvni.4s	v0, #0x3f, msl #16
     90c:      	fneg.4s	v0, v0
     910:      	stp	q1, q0, [sp, #0xf0]
     914:      	add	x26, sp, #0x1, lsl #12  ; =0x1000
     918:      	add	x26, x26, #0xab0
     91c:      	ldp	w28, w23, [x2, #0x8]
     920:      	add	x24, sp, #0x290
     924:      	str	w3, [sp, #0xdc]
     928:      	b	0x970 <_llm_rows.packet_batch.blocks+0x114>
     92c:      	mov	w8, #0x18               ; =24
     930:      	str	w8, [x20, #0x24]
     934:      	ldr	w19, [sp, #0xdc]
     938:      	add	w8, w27, #0x1
     93c:      	ldp	w10, w9, [sp, #0xe0]
     940:      	cmp	w8, w9
     944:      	cset	w8, eq
     948:      	csinc	w27, wzr, w27, eq
     94c:      	cinc	w9, w25, eq
     950:      	cmp	w9, w10
     954:      	cset	w10, eq
     958:      	ands	w8, w8, w10
     95c:      	csel	w25, wzr, w9, ne
     960:      	add	w28, w28, w8
     964:      	add	w22, w22, #0x1
     968:      	cmp	w22, w19
     96c:      	b.eq	0x1cd4 <_llm_rows.packet_batch.blocks+0x1478>
     970:      	ubfiz	x8, x27, #5, #32
     974:      	cmp	x8, x23
     978:      	csel	x9, x8, xzr, ls
     97c:      	subs	x10, x23, x9
     980:      	cmp	x10, #0x20
     984:      	mov	w11, #0x20              ; =32
     988:      	csel	x10, x10, x11, lo
     98c:      	cmp	x23, x9
     990:      	stp	w27, w25, [x20]
     994:      	str	w28, [x20, #0x8]
     998:      	str	wzr, [x20, #0x24]
     99c:      	ccmp	x8, x23, #0x2, hi
     9a0:      	csel	x21, x10, xzr, ls
     9a4:      	cmp	x21, #0x20
     9a8:      	b.lo	0x9fc <_llm_rows.packet_batch.blocks+0x1a0>
     9ac:      	ldr	x21, [sp, #0xe8]
     9b0:      	mov	x0, x21
     9b4:      	mov	x1, x20
     9b8:      	bl	0x9b8 <_llm_rows.packet_batch.blocks+0x15c>
     9bc:      	mov	w8, #0x8                ; =8
     9c0:      	str	w8, [x20, #0x24]
     9c4:      	mov	x0, x21
     9c8:      	mov	x1, x20
     9cc:      	bl	0x9cc <_llm_rows.packet_batch.blocks+0x170>
     9d0:      	mov	w8, #0x10               ; =16
     9d4:      	str	w8, [x20, #0x24]
     9d8:      	mov	x0, x21
     9dc:      	mov	x1, x20
     9e0:      	bl	0x9e0 <_llm_rows.packet_batch.blocks+0x184>
     9e4:      	mov	w8, #0x18               ; =24
     9e8:      	str	w8, [x20, #0x24]
     9ec:      	mov	x0, x21
     9f0:      	mov	x1, x20
     9f4:      	bl	0x9f4 <_llm_rows.packet_batch.blocks+0x198>
     9f8:      	b	0x938 <_llm_rows.packet_batch.blocks+0xdc>
     9fc:      	lsr	x19, x21, #3
     a00:      	cmp	x21, #0x8
     a04:      	b.lo	0xa50 <_llm_rows.packet_batch.blocks+0x1f4>
     a08:      	str	wzr, [x20, #0x24]
     a0c:      	ldr	x0, [sp, #0xe8]
     a10:      	mov	x1, x20
     a14:      	bl	0xa14 <_llm_rows.packet_batch.blocks+0x1b8>
     a18:      	cmp	x19, #0x1
     a1c:      	b.eq	0xa50 <_llm_rows.packet_batch.blocks+0x1f4>
     a20:      	mov	w8, #0x8                ; =8
     a24:      	str	w8, [x20, #0x24]
     a28:      	ldr	x0, [sp, #0xe8]
     a2c:      	mov	x1, x20
     a30:      	bl	0xa30 <_llm_rows.packet_batch.blocks+0x1d4>
     a34:      	cmp	x19, #0x2
     a38:      	b.eq	0xa50 <_llm_rows.packet_batch.blocks+0x1f4>
     a3c:      	mov	w8, #0x10               ; =16
     a40:      	str	w8, [x20, #0x24]
     a44:      	ldr	x0, [sp, #0xe8]
     a48:      	mov	x1, x20
     a4c:      	bl	0xa4c <_llm_rows.packet_batch.blocks+0x1f0>
     a50:      	and	w8, w21, #0x7
     a54:      	cbz	w8, 0x92c <_llm_rows.packet_batch.blocks+0xd0>
     a58:      	dup.4s	v0, w8
     a5c:      	ldp	q2, q1, [sp, #0xa0]
     a60:      	cmhi.4s	v19, v0, v2
     a64:      	cmhi.4s	v20, v0, v1
     a68:      	uzp1.8h	v29, v20, v19
     a6c:      	umaxv.8h	h0, v29
     a70:      	fmov	w8, s0
     a74:      	tbz	w8, #0x0, 0x92c <_llm_rows.packet_batch.blocks+0xd0>
     a78:      	ldr	x8, [sp, #0xe8]
     a7c:      	ldr	x11, [x8]
     a80:      	ldr	x9, [x8, #0x10]
     a84:      	ldr	x8, [x8, #0x30]
     a88:      	xtn.4h	v0, v20
     a8c:      	uzp1.8b	v0, v0, v0
     a90:      	sshll.2d	v1, v20, #0x0
     a94:      	sshll.2d	v2, v19, #0x0
     a98:      	sshll2.2d	v11, v20, #0x0
     a9c:      	sshll2.2d	v10, v19, #0x0
     aa0:      	ldp	q3, q4, [sp, #0x80]
     aa4:      	and.16b	v21, v10, v4
     aa8:      	and.16b	v23, v11, v3
     aac:      	ldr	q3, [sp, #0x70]
     ab0:      	and.16b	v22, v2, v3
     ab4:      	ldr	q2, [sp, #0x60]
     ab8:      	and.16b	v30, v1, v2
     abc:      	ubfiz	w10, w27, #2, #27
     ac0:      	orr	w12, w10, w19
     ac4:      	dup.4s	v1, w12
     ac8:      	and.16b	v2, v20, v1
     acc:      	and.16b	v1, v19, v1
     ad0:      	ushll2.2d	v24, v1, #0x0
     ad4:      	ushll2.2d	v27, v2, #0x0
     ad8:      	ushll.2d	v25, v1, #0x0
     adc:      	ushll.2d	v26, v2, #0x0
     ae0:      	subs	x10, x11, x8
     ae4:      	mov	w15, #0x2007            ; =8199
     ae8:      	movk	w15, #0x18, lsl #16
     aec:      	ccmp	x10, x15, #0x0, hs
     af0:      	cset	w10, hi
     af4:      	subs	x13, x8, x11
     af8:      	ccmp	x13, x15, #0x0, hs
     afc:      	csinc	w14, w10, wzr, ls
     b00:      	subs	x10, x9, x8
     b04:      	ccmp	x10, x15, #0x0, hs
     b08:      	cset	w10, hi
     b0c:      	subs	x13, x8, x9
     b10:      	ccmp	x13, x15, #0x0, hs
     b14:      	csinc	w10, w10, wzr, ls
     b18:      	umov.b	w13, v0[0]
     b1c:      	mov	w15, #0x1808            ; =6152
     b20:      	umull	x12, w12, w15
     b24:      	tst	w13, #0x1
     b28:      	csel	x12, x12, xzr, ne
     b2c:      	mov	w15, #-0x3d300000       ; =-1026555904
     b30:      	dup.4s	v1, w15
     b34:      	mov	w15, #0x42c80000        ; =1120403456
     b38:      	dup.4s	v0, w15
     b3c:      	mov	w15, #0xaa3b            ; =43579
     b40:      	movk	w15, #0x3fb8, lsl #16
     b44:      	dup.4s	v18, w15
     b48:      	mov	w15, #0x7200            ; =29184
     b4c:      	movk	w15, #0xbf31, lsl #16
     b50:      	dup.4s	v17, w15
     b54:      	mov	w15, #0xbe8e            ; =48782
     b58:      	movk	w15, #0xb5bf, lsl #16
     b5c:      	dup.4s	v16, w15
     b60:      	mov	w15, #0x2bda            ; =11226
     b64:      	movk	w15, #0x3950, lsl #16
     b68:      	dup.4s	v7, w15
     b6c:      	mov	w15, #0x96c9            ; =38601
     b70:      	movk	w15, #0x3ab6, lsl #16
     b74:      	dup.4s	v6, w15
     b78:      	mov	w15, #0x88a6            ; =34982
     b7c:      	movk	w15, #0x3c08, lsl #16
     b80:      	dup.4s	v5, w15
     b84:      	mov	w15, #0xaa7a            ; =43642
     b88:      	movk	w15, #0x3d2a, lsl #16
     b8c:      	dup.4s	v4, w15
     b90:      	mov	w15, #0xaaab            ; =43691
     b94:      	movk	w15, #0x3e2a, lsl #16
     b98:      	dup.4s	v3, w15
     b9c:      	fmov.4s	v2, #1.00000000
     ba0:      	xtn.2s	v31, v26
     ba4:      	xtn.2s	v24, v24
     ba8:      	str	d24, [sp, #0xc0]
     bac:      	xtn.2s	v26, v25
     bb0:      	mov	w15, #0x602             ; =1538
     bb4:      	dup.2s	v25, w15
     bb8:      	xtn.2s	v27, v27
     bbc:      	cmp	w14, #0x1
     bc0:      	b.ne	0xf58 <_llm_rows.packet_batch.blocks+0x6fc>
     bc4:      	cbz	w10, 0xf58 <_llm_rows.packet_batch.blocks+0x6fc>
     bc8:      	mov	x10, #0x0               ; =0
     bcc:      	add	x13, x8, x12
     bd0:      	add	x14, x9, x12
     bd4:      	add	x12, x11, x12
     bd8:      	ldr	q24, [sp, #0xf0]
     bdc:      	and.16b	v28, v29, v24
     be0:      	addv.8h	h28, v28
     be4:      	fmov	w15, s28
     be8:      	b	0xbf8 <_llm_rows.packet_batch.blocks+0x39c>
     bec:      	add	x10, x10, #0x1
     bf0:      	cmp	x10, #0xc0
     bf4:      	b.eq	0x18cc <_llm_rows.packet_batch.blocks+0x1070>
     bf8:      	add	x16, x12, x10, lsl #5
     bfc:      	movi.2d	v10, #0000000000000000
     c00:      	movi.2d	v9, #0000000000000000
     c04:      	tbz	w15, #0x0, 0xc98 <_llm_rows.packet_batch.blocks+0x43c>
     c08:      	ldr	s10, [x16]
     c0c:      	and	w17, w15, #0xff
     c10:      	tbnz	w17, #0x1, 0xca0 <_llm_rows.packet_batch.blocks+0x444>
     c14:      	tbz	w17, #0x2, 0xcac <_llm_rows.packet_batch.blocks+0x450>
     c18:      	add	x0, x16, #0x8
     c1c:      	ld1.s	{ v10 }[2], [x0]
     c20:      	tbnz	w17, #0x3, 0xcb0 <_llm_rows.packet_batch.blocks+0x454>
     c24:      	tbz	w17, #0x4, 0xcbc <_llm_rows.packet_batch.blocks+0x460>
     c28:      	add	x0, x16, #0x10
     c2c:      	ld1.s	{ v9 }[0], [x0]
     c30:      	tbnz	w17, #0x5, 0xcc0 <_llm_rows.packet_batch.blocks+0x464>
     c34:      	tbz	w17, #0x6, 0xccc <_llm_rows.packet_batch.blocks+0x470>
     c38:      	add	x0, x16, #0x18
     c3c:      	ld1.s	{ v9 }[2], [x0]
     c40:      	tbnz	w17, #0x7, 0xcd0 <_llm_rows.packet_batch.blocks+0x474>
     c44:      	fmov	w17, s28
     c48:      	add	x16, x14, x10, lsl #5
     c4c:      	movi.2d	v8, #0000000000000000
     c50:      	movi.2d	v11, #0000000000000000
     c54:      	tbz	w17, #0x0, 0xcec <_llm_rows.packet_batch.blocks+0x490>
     c58:      	ldr	s8, [x16]
     c5c:      	and	w17, w17, #0xff
     c60:      	tbnz	w17, #0x1, 0xcf4 <_llm_rows.packet_batch.blocks+0x498>
     c64:      	tbz	w17, #0x2, 0xd00 <_llm_rows.packet_batch.blocks+0x4a4>
     c68:      	add	x0, x16, #0x8
     c6c:      	ld1.s	{ v8 }[2], [x0]
     c70:      	tbnz	w17, #0x3, 0xd04 <_llm_rows.packet_batch.blocks+0x4a8>
     c74:      	tbz	w17, #0x4, 0xd10 <_llm_rows.packet_batch.blocks+0x4b4>
     c78:      	add	x0, x16, #0x10
     c7c:      	ld1.s	{ v11 }[0], [x0]
     c80:      	tbnz	w17, #0x5, 0xd14 <_llm_rows.packet_batch.blocks+0x4b8>
     c84:      	tbz	w17, #0x6, 0xd20 <_llm_rows.packet_batch.blocks+0x4c4>
     c88:      	add	x0, x16, #0x18
     c8c:      	ld1.s	{ v11 }[2], [x0]
     c90:      	tbnz	w17, #0x7, 0xd24 <_llm_rows.packet_batch.blocks+0x4c8>
     c94:      	b	0xd2c <_llm_rows.packet_batch.blocks+0x4d0>
     c98:      	and	w17, w15, #0xff
     c9c:      	tbz	w17, #0x1, 0xc14 <_llm_rows.packet_batch.blocks+0x3b8>
     ca0:      	add	x0, x16, #0x4
     ca4:      	ld1.s	{ v10 }[1], [x0]
     ca8:      	tbnz	w17, #0x2, 0xc18 <_llm_rows.packet_batch.blocks+0x3bc>
     cac:      	tbz	w17, #0x3, 0xc24 <_llm_rows.packet_batch.blocks+0x3c8>
     cb0:      	add	x0, x16, #0xc
     cb4:      	ld1.s	{ v10 }[3], [x0]
     cb8:      	tbnz	w17, #0x4, 0xc28 <_llm_rows.packet_batch.blocks+0x3cc>
     cbc:      	tbz	w17, #0x5, 0xc34 <_llm_rows.packet_batch.blocks+0x3d8>
     cc0:      	add	x0, x16, #0x14
     cc4:      	ld1.s	{ v9 }[1], [x0]
     cc8:      	tbnz	w17, #0x6, 0xc38 <_llm_rows.packet_batch.blocks+0x3dc>
     ccc:      	tbz	w17, #0x7, 0xc44 <_llm_rows.packet_batch.blocks+0x3e8>
     cd0:      	add	x16, x16, #0x1c
     cd4:      	ld1.s	{ v9 }[3], [x16]
     cd8:      	fmov	w17, s28
     cdc:      	add	x16, x14, x10, lsl #5
     ce0:      	movi.2d	v8, #0000000000000000
     ce4:      	movi.2d	v11, #0000000000000000
     ce8:      	tbnz	w17, #0x0, 0xc58 <_llm_rows.packet_batch.blocks+0x3fc>
     cec:      	and	w17, w17, #0xff
     cf0:      	tbz	w17, #0x1, 0xc64 <_llm_rows.packet_batch.blocks+0x408>
     cf4:      	add	x0, x16, #0x4
     cf8:      	ld1.s	{ v8 }[1], [x0]
     cfc:      	tbnz	w17, #0x2, 0xc68 <_llm_rows.packet_batch.blocks+0x40c>
     d00:      	tbz	w17, #0x3, 0xc74 <_llm_rows.packet_batch.blocks+0x418>
     d04:      	add	x0, x16, #0xc
     d08:      	ld1.s	{ v8 }[3], [x0]
     d0c:      	tbnz	w17, #0x4, 0xc78 <_llm_rows.packet_batch.blocks+0x41c>
     d10:      	tbz	w17, #0x5, 0xc84 <_llm_rows.packet_batch.blocks+0x428>
     d14:      	add	x0, x16, #0x14
     d18:      	ld1.s	{ v11 }[1], [x0]
     d1c:      	tbnz	w17, #0x6, 0xc88 <_llm_rows.packet_batch.blocks+0x42c>
     d20:      	tbz	w17, #0x7, 0xd2c <_llm_rows.packet_batch.blocks+0x4d0>
     d24:      	add	x16, x16, #0x1c
     d28:      	ld1.s	{ v11 }[3], [x16]
     d2c:      	fneg.4s	v12, v10
     d30:      	and.16b	v12, v20, v12
     d34:      	fcmge.4s	v13, v12, v1
     d38:      	fcmge.4s	v14, v0, v12
     d3c:      	and.16b	v13, v13, v14
     d40:      	and.16b	v13, v13, v12
     d44:      	fmul.4s	v14, v13, v18
     d48:      	movi.4s	v24, #0x4b, lsl #24
     d4c:      	mvni.4s	v15, #0x80, lsl #24
     d50:      	bsl.16b	v15, v24, v14
     d54:      	fadd.4s	v14, v14, v15
     d58:      	fsub.4s	v14, v14, v15
     d5c:      	fcvtzs.4s	v14, v14
     d60:      	scvtf.4s	v15, v14
     d64:      	fmul.4s	v24, v15, v17
     d68:      	fadd.4s	v24, v13, v24
     d6c:      	fmul.4s	v13, v15, v16
     d70:      	fadd.4s	v24, v24, v13
     d74:      	fmul.4s	v13, v24, v7
     d78:      	fadd.4s	v13, v13, v6
     d7c:      	fmul.4s	v13, v24, v13
     d80:      	fadd.4s	v13, v13, v5
     d84:      	fmul.4s	v13, v24, v13
     d88:      	fadd.4s	v13, v13, v4
     d8c:      	fmul.4s	v13, v24, v13
     d90:      	fadd.4s	v13, v13, v3
     d94:      	fmul.4s	v13, v24, v13
     d98:      	movi.4s	v15, #0x3f, lsl #24
     d9c:      	fadd.4s	v13, v13, v15
     da0:      	fmul.4s	v15, v24, v24
     da4:      	fmul.4s	v13, v15, v13
     da8:      	fadd.4s	v24, v24, v13
     dac:      	fadd.4s	v24, v24, v2
     db0:      	sshr.4s	v13, v14, #0x1
     db4:      	shl.4s	v15, v13, #0x17
     db8:      	add.4s	v15, v15, v2
     dbc:      	fmul.4s	v24, v24, v15
     dc0:      	sub.4s	v13, v14, v13
     dc4:      	shl.4s	v13, v13, #0x17
     dc8:      	add.4s	v13, v13, v2
     dcc:      	fmul.4s	v24, v24, v13
     dd0:      	fcmgt.4s	v13, v1, v12
     dd4:      	fcmgt.4s	v14, v12, v0
     dd8:      	fcmeq.4s	v12, v12, v12
     ddc:      	fadd.4s	v24, v24, v2
     de0:      	bit.16b	v24, v2, v13
     de4:      	ldr	q13, [sp, #0x110]
     de8:      	bit.16b	v24, v13, v14
     dec:      	ldr	q13, [sp, #0x100]
     df0:      	bif.16b	v24, v13, v12
     df4:      	fdiv.4s	v24, v10, v24
     df8:      	fmov	w17, s28
     dfc:      	fmul.4s	v8, v8, v24
     e00:      	add	x16, x13, x10, lsl #5
     e04:      	tbz	w17, #0x0, 0xe28 <_llm_rows.packet_batch.blocks+0x5cc>
     e08:      	str	s8, [x16]
     e0c:      	and	w17, w17, #0xff
     e10:      	tbnz	w17, #0x1, 0xe30 <_llm_rows.packet_batch.blocks+0x5d4>
     e14:      	tbz	w17, #0x2, 0xe3c <_llm_rows.packet_batch.blocks+0x5e0>
     e18:      	add	x0, x16, #0x8
     e1c:      	st1.s	{ v8 }[2], [x0]
     e20:      	tbnz	w17, #0x3, 0xe40 <_llm_rows.packet_batch.blocks+0x5e4>
     e24:      	b	0xe48 <_llm_rows.packet_batch.blocks+0x5ec>
     e28:      	and	w17, w17, #0xff
     e2c:      	tbz	w17, #0x1, 0xe14 <_llm_rows.packet_batch.blocks+0x5b8>
     e30:      	add	x0, x16, #0x4
     e34:      	st1.s	{ v8 }[1], [x0]
     e38:      	tbnz	w17, #0x2, 0xe18 <_llm_rows.packet_batch.blocks+0x5bc>
     e3c:      	tbz	w17, #0x3, 0xe48 <_llm_rows.packet_batch.blocks+0x5ec>
     e40:      	add	x0, x16, #0xc
     e44:      	st1.s	{ v8 }[3], [x0]
     e48:      	fneg.4s	v24, v9
     e4c:      	and.16b	v24, v19, v24
     e50:      	fcmge.4s	v8, v24, v1
     e54:      	fcmge.4s	v10, v0, v24
     e58:      	and.16b	v8, v8, v10
     e5c:      	and.16b	v8, v8, v24
     e60:      	fmul.4s	v10, v8, v18
     e64:      	movi.4s	v12, #0x4b, lsl #24
     e68:      	mvni.4s	v13, #0x80, lsl #24
     e6c:      	bif.16b	v12, v10, v13
     e70:      	fadd.4s	v10, v10, v12
     e74:      	fsub.4s	v10, v10, v12
     e78:      	fcvtzs.4s	v10, v10
     e7c:      	scvtf.4s	v12, v10
     e80:      	fmul.4s	v13, v12, v17
     e84:      	fadd.4s	v8, v8, v13
     e88:      	fmul.4s	v12, v12, v16
     e8c:      	fadd.4s	v8, v8, v12
     e90:      	fmul.4s	v12, v8, v7
     e94:      	fadd.4s	v12, v12, v6
     e98:      	fmul.4s	v12, v8, v12
     e9c:      	fadd.4s	v12, v12, v5
     ea0:      	fmul.4s	v12, v8, v12
     ea4:      	fadd.4s	v12, v12, v4
     ea8:      	fmul.4s	v12, v8, v12
     eac:      	fadd.4s	v12, v12, v3
     eb0:      	fmul.4s	v12, v8, v12
     eb4:      	movi.4s	v13, #0x3f, lsl #24
     eb8:      	fadd.4s	v12, v12, v13
     ebc:      	fmul.4s	v13, v8, v8
     ec0:      	fmul.4s	v12, v13, v12
     ec4:      	fadd.4s	v8, v8, v12
     ec8:      	fadd.4s	v8, v8, v2
     ecc:      	sshr.4s	v12, v10, #0x1
     ed0:      	shl.4s	v13, v12, #0x17
     ed4:      	add.4s	v13, v13, v2
     ed8:      	fmul.4s	v8, v8, v13
     edc:      	sub.4s	v10, v10, v12
     ee0:      	shl.4s	v10, v10, #0x17
     ee4:      	add.4s	v10, v10, v2
     ee8:      	fmul.4s	v8, v8, v10
     eec:      	fcmgt.4s	v10, v1, v24
     ef0:      	fcmgt.4s	v12, v24, v0
     ef4:      	fcmeq.4s	v24, v24, v24
     ef8:      	fadd.4s	v8, v8, v2
     efc:      	bit.16b	v8, v2, v10
     f00:      	ldr	q10, [sp, #0x110]
     f04:      	bit.16b	v8, v10, v12
     f08:      	ldr	q10, [sp, #0x100]
     f0c:      	bsl.16b	v24, v8, v10
     f10:      	fdiv.4s	v24, v9, v24
     f14:      	fmul.4s	v8, v11, v24
     f18:      	tbz	w17, #0x4, 0xf38 <_llm_rows.packet_batch.blocks+0x6dc>
     f1c:      	str	s8, [x16, #0x10]
     f20:      	tbnz	w17, #0x5, 0xf3c <_llm_rows.packet_batch.blocks+0x6e0>
     f24:      	tbz	w17, #0x6, 0xf48 <_llm_rows.packet_batch.blocks+0x6ec>
     f28:      	add	x0, x16, #0x18
     f2c:      	st1.s	{ v8 }[2], [x0]
     f30:      	tbz	w17, #0x7, 0xbec <_llm_rows.packet_batch.blocks+0x390>
     f34:      	b	0xf4c <_llm_rows.packet_batch.blocks+0x6f0>
     f38:      	tbz	w17, #0x5, 0xf24 <_llm_rows.packet_batch.blocks+0x6c8>
     f3c:      	add	x0, x16, #0x14
     f40:      	st1.s	{ v8 }[1], [x0]
     f44:      	tbnz	w17, #0x6, 0xf28 <_llm_rows.packet_batch.blocks+0x6cc>
     f48:      	tbz	w17, #0x7, 0xbec <_llm_rows.packet_batch.blocks+0x390>
     f4c:      	add	x16, x16, #0x1c
     f50:      	st1.s	{ v8 }[3], [x16]
     f54:      	b	0xbec <_llm_rows.packet_batch.blocks+0x390>
     f58:      	mov	x10, #0x0               ; =0
     f5c:      	add	x14, x11, x12
     f60:      	b	0xf84 <_llm_rows.packet_batch.blocks+0x728>
     f64:      	add	x15, x26, x10, lsl #5
     f68:      	ldp	q24, q12, [x15]
     f6c:      	bif.16b	v9, v12, v19
     f70:      	bit.16b	v24, v8, v20
     f74:      	stp	q24, q9, [x15]
     f78:      	add	x10, x10, #0x1
     f7c:      	cmp	x10, #0xc0
     f80:      	b.eq	0x1028 <_llm_rows.packet_batch.blocks+0x7cc>
     f84:      	ldr	q24, [sp, #0xf0]
     f88:      	and.16b	v24, v29, v24
     f8c:      	addv.8h	h28, v24
     f90:      	fmov	w16, s28
     f94:      	add	x15, x14, x10, lsl #5
     f98:      	movi.2d	v8, #0000000000000000
     f9c:      	movi.2d	v9, #0000000000000000
     fa0:      	tbz	w16, #0x0, 0xfe4 <_llm_rows.packet_batch.blocks+0x788>
     fa4:      	ldr	s8, [x15]
     fa8:      	and	w16, w16, #0xff
     fac:      	tbnz	w16, #0x1, 0xfec <_llm_rows.packet_batch.blocks+0x790>
     fb0:      	tbz	w16, #0x2, 0xff8 <_llm_rows.packet_batch.blocks+0x79c>
     fb4:      	add	x17, x15, #0x8
     fb8:      	ld1.s	{ v8 }[2], [x17]
     fbc:      	tbnz	w16, #0x3, 0xffc <_llm_rows.packet_batch.blocks+0x7a0>
     fc0:      	tbz	w16, #0x4, 0x1008 <_llm_rows.packet_batch.blocks+0x7ac>
     fc4:      	add	x17, x15, #0x10
     fc8:      	ld1.s	{ v9 }[0], [x17]
     fcc:      	tbnz	w16, #0x5, 0x100c <_llm_rows.packet_batch.blocks+0x7b0>
     fd0:      	tbz	w16, #0x6, 0x1018 <_llm_rows.packet_batch.blocks+0x7bc>
     fd4:      	add	x17, x15, #0x18
     fd8:      	ld1.s	{ v9 }[2], [x17]
     fdc:      	tbz	w16, #0x7, 0xf64 <_llm_rows.packet_batch.blocks+0x708>
     fe0:      	b	0x101c <_llm_rows.packet_batch.blocks+0x7c0>
     fe4:      	and	w16, w16, #0xff
     fe8:      	tbz	w16, #0x1, 0xfb0 <_llm_rows.packet_batch.blocks+0x754>
     fec:      	add	x17, x15, #0x4
     ff0:      	ld1.s	{ v8 }[1], [x17]
     ff4:      	tbnz	w16, #0x2, 0xfb4 <_llm_rows.packet_batch.blocks+0x758>
     ff8:      	tbz	w16, #0x3, 0xfc0 <_llm_rows.packet_batch.blocks+0x764>
     ffc:      	add	x17, x15, #0xc
    1000:      	ld1.s	{ v8 }[3], [x17]
    1004:      	tbnz	w16, #0x4, 0xfc4 <_llm_rows.packet_batch.blocks+0x768>
    1008:      	tbz	w16, #0x5, 0xfd0 <_llm_rows.packet_batch.blocks+0x774>
    100c:      	add	x17, x15, #0x14
    1010:      	ld1.s	{ v9 }[1], [x17]
    1014:      	tbnz	w16, #0x6, 0xfd4 <_llm_rows.packet_batch.blocks+0x778>
    1018:      	tbz	w16, #0x7, 0xf64 <_llm_rows.packet_batch.blocks+0x708>
    101c:      	add	x15, x15, #0x1c
    1020:      	ld1.s	{ v9 }[3], [x15]
    1024:      	b	0xf64 <_llm_rows.packet_batch.blocks+0x708>
    1028:      	xtn.8b	v24, v29
    102c:      	movi	d29, #0x0000000000ffff
    1030:      	and.8b	v29, v24, v29
    1034:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x7a4>
    1038:      	ldr	d8, [x10]
    103c:      	and.8b	v24, v24, v8
    1040:      	addv.8b	b24, v24
    1044:      	fmov	w15, s24
    1048:      	umaxv.8b	b24, v29
    104c:      	fmov	w10, s24
    1050:      	rbit	w14, w15
    1054:      	clz	w14, w14
    1058:      	tst	w10, #0x1
    105c:      	csel	w10, w14, wzr, ne
    1060:      	mov	w14, #0x600             ; =1536
    1064:      	dup.2d	v8, x14
    1068:      	umlal.2d	v30, v31, v25
    106c:      	mov	b24, v29[0]
    1070:      	mov.b	v24[4], v29[1]
    1074:      	add.2d	v30, v30, v8
    1078:      	ushll.2d	v24, v24, #0x0
    107c:      	shl.2d	v24, v24, #0x3f
    1080:      	cmlt.2d	v24, v24, #0
    1084:      	str	q30, [sp, #0x50]
    1088:      	and.16b	v24, v24, v30
    108c:      	movi.2d	v30, #0000000000000000
    1090:      	stp	q30, q30, [sp, #0x260]
    1094:      	stp	q24, q30, [sp, #0x240]
    1098:      	and	x14, x10, #0x7
    109c:      	add	x16, sp, #0x240
    10a0:      	ldr	x14, [x16, x14, lsl #3]
    10a4:      	sub	x14, x14, x10
    10a8:      	lsl	x14, x14, #2
    10ac:      	add	x11, x11, x14
    10b0:      	movi.2d	v31, #0000000000000000
    10b4:      	tbz	w15, #0x0, 0x10f4 <_llm_rows.packet_batch.blocks+0x898>
    10b8:      	ldr	s31, [x11]
    10bc:      	tbnz	w15, #0x1, 0x10f8 <_llm_rows.packet_batch.blocks+0x89c>
    10c0:      	tbz	w15, #0x2, 0x1104 <_llm_rows.packet_batch.blocks+0x8a8>
    10c4:      	add	x16, x11, #0x8
    10c8:      	ld1.s	{ v31 }[2], [x16]
    10cc:      	tbnz	w15, #0x3, 0x1108 <_llm_rows.packet_batch.blocks+0x8ac>
    10d0:      	tbz	w15, #0x4, 0x1114 <_llm_rows.packet_batch.blocks+0x8b8>
    10d4:      	add	x16, x11, #0x10
    10d8:      	ld1.s	{ v30 }[0], [x16]
    10dc:      	tbnz	w15, #0x5, 0x1118 <_llm_rows.packet_batch.blocks+0x8bc>
    10e0:      	tbz	w15, #0x6, 0x1124 <_llm_rows.packet_batch.blocks+0x8c8>
    10e4:      	add	x16, x11, #0x18
    10e8:      	ld1.s	{ v30 }[2], [x16]
    10ec:      	tbnz	w15, #0x7, 0x1128 <_llm_rows.packet_batch.blocks+0x8cc>
    10f0:      	b	0x1130 <_llm_rows.packet_batch.blocks+0x8d4>
    10f4:      	tbz	w15, #0x1, 0x10c0 <_llm_rows.packet_batch.blocks+0x864>
    10f8:      	add	x16, x11, #0x4
    10fc:      	ld1.s	{ v31 }[1], [x16]
    1100:      	tbnz	w15, #0x2, 0x10c4 <_llm_rows.packet_batch.blocks+0x868>
    1104:      	tbz	w15, #0x3, 0x10d0 <_llm_rows.packet_batch.blocks+0x874>
    1108:      	add	x16, x11, #0xc
    110c:      	ld1.s	{ v31 }[3], [x16]
    1110:      	tbnz	w15, #0x4, 0x10d4 <_llm_rows.packet_batch.blocks+0x878>
    1114:      	tbz	w15, #0x5, 0x10e0 <_llm_rows.packet_batch.blocks+0x884>
    1118:      	add	x16, x11, #0x14
    111c:      	ld1.s	{ v30 }[1], [x16]
    1120:      	tbnz	w15, #0x6, 0x10e4 <_llm_rows.packet_batch.blocks+0x888>
    1124:      	tbz	w15, #0x7, 0x1130 <_llm_rows.packet_batch.blocks+0x8d4>
    1128:      	add	x11, x11, #0x1c
    112c:      	ld1.s	{ v30 }[3], [x11]
    1130:      	mov	x17, #0x0               ; =0
    1134:      	umlal.2d	v23, v27, v25
    1138:      	add.2d	v23, v23, v8
    113c:      	umlal.2d	v22, v26, v25
    1140:      	add.2d	v22, v22, v8
    1144:      	stp	q22, q23, [sp, #0x20]
    1148:      	ldr	d22, [sp, #0xc0]
    114c:      	umlal.2d	v21, v22, v25
    1150:      	add.2d	v21, v21, v8
    1154:      	str	q21, [sp, #0x10]
    1158:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7a4>
    115c:      	ldr	q21, [x11]
    1160:      	mov	w11, #0x1800            ; =6144
    1164:      	dup.2d	v22, x11
    1168:      	sshll.2d	v23, v20, #0x0
    116c:      	bif.16b	v21, v22, v23
    1170:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7a4>
    1174:      	ldr	q23, [x11]
    1178:      	sshll.2d	v24, v19, #0x0
    117c:      	bif.16b	v23, v22, v24
    1180:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7a4>
    1184:      	ldr	q24, [x11]
    1188:      	bif.16b	v24, v22, v11
    118c:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7a4>
    1190:      	ldr	q25, [x11]
    1194:      	bit.16b	v22, v25, v10
    1198:      	stp	q23, q22, [sp, #0x220]
    119c:      	stp	q21, q24, [sp, #0x200]
    11a0:      	and	x11, x10, #0x7
    11a4:      	add	x16, sp, #0x200
    11a8:      	ldr	x11, [x16, x11, lsl #3]
    11ac:      	sub	x11, x11, x10, lsl #2
    11b0:      	tst	w15, #0xff
    11b4:      	csel	x15, xzr, x11, eq
    11b8:      	add	x11, x26, x15
    11bc:      	ldp	q21, q22, [x11]
    11c0:      	zip2.8b	v23, v29, v0
    11c4:      	ushll.4s	v23, v23, #0x0
    11c8:      	shl.4s	v23, v23, #0x1f
    11cc:      	cmlt.4s	v23, v23, #0
    11d0:      	str	q30, [sp, #0xc0]
    11d4:      	bit.16b	v22, v30, v23
    11d8:      	zip1.8b	v23, v29, v0
    11dc:      	ushll.4s	v23, v23, #0x0
    11e0:      	shl.4s	v23, v23, #0x1f
    11e4:      	cmlt.4s	v23, v23, #0
    11e8:      	str	q31, [sp, #0x40]
    11ec:      	bit.16b	v21, v31, v23
    11f0:      	stp	q21, q22, [x11]
    11f4:      	add	x16, x9, x12
    11f8:      	ushll2.2d	v21, v19, #0x0
    11fc:      	mov	w11, #0x1               ; =1
    1200:      	dup.2d	v22, x11
    1204:      	and.16b	v24, v21, v22
    1208:      	ushll2.2d	v21, v20, #0x0
    120c:      	and.16b	v25, v21, v22
    1210:      	ushll.2d	v21, v19, #0x0
    1214:      	and.16b	v26, v21, v22
    1218:      	ushll.2d	v21, v20, #0x0
    121c:      	and.16b	v27, v21, v22
    1220:      	movi.2d	v8, #0000000000000000
    1224:      	and	x11, x13, #0x1
    1228:      	movi.2d	v10, #0000000000000000
    122c:      	movi.2d	v11, #0000000000000000
    1230:      	movi.2d	v12, #0000000000000000
    1234:      	b	0x1270 <_llm_rows.packet_batch.blocks+0xa14>
    1238:      	add	x13, x24, x13
    123c:      	ldp	q21, q22, [x13]
    1240:      	bit.16b	v22, v14, v19
    1244:      	bit.16b	v21, v13, v20
    1248:      	stp	q21, q22, [x13]
    124c:      	add.2d	v21, v8, v27
    1250:      	add.2d	v10, v10, v25
    1254:      	add.2d	v11, v11, v26
    1258:      	add.2d	v12, v12, v24
    125c:      	fmov	x13, d8
    1260:      	add	x17, x13, x11
    1264:      	mov.16b	v8, v21
    1268:      	cmp	x17, #0xc0
    126c:      	b.ge	0x130c <_llm_rows.packet_batch.blocks+0xab0>
    1270:      	fmov	w0, s28
    1274:      	lsl	x13, x17, #5
    1278:      	add	x17, x16, x13
    127c:      	movi.2d	v13, #0000000000000000
    1280:      	movi.2d	v14, #0000000000000000
    1284:      	tbz	w0, #0x0, 0x12c8 <_llm_rows.packet_batch.blocks+0xa6c>
    1288:      	ldr	s13, [x17]
    128c:      	and	w0, w0, #0xff
    1290:      	tbnz	w0, #0x1, 0x12d0 <_llm_rows.packet_batch.blocks+0xa74>
    1294:      	tbz	w0, #0x2, 0x12dc <_llm_rows.packet_batch.blocks+0xa80>
    1298:      	add	x1, x17, #0x8
    129c:      	ld1.s	{ v13 }[2], [x1]
    12a0:      	tbnz	w0, #0x3, 0x12e0 <_llm_rows.packet_batch.blocks+0xa84>
    12a4:      	tbz	w0, #0x4, 0x12ec <_llm_rows.packet_batch.blocks+0xa90>
    12a8:      	add	x1, x17, #0x10
    12ac:      	ld1.s	{ v14 }[0], [x1]
    12b0:      	tbnz	w0, #0x5, 0x12f0 <_llm_rows.packet_batch.blocks+0xa94>
    12b4:      	tbz	w0, #0x6, 0x12fc <_llm_rows.packet_batch.blocks+0xaa0>
    12b8:      	add	x1, x17, #0x18
    12bc:      	ld1.s	{ v14 }[2], [x1]
    12c0:      	tbz	w0, #0x7, 0x1238 <_llm_rows.packet_batch.blocks+0x9dc>
    12c4:      	b	0x1300 <_llm_rows.packet_batch.blocks+0xaa4>
    12c8:      	and	w0, w0, #0xff
    12cc:      	tbz	w0, #0x1, 0x1294 <_llm_rows.packet_batch.blocks+0xa38>
    12d0:      	add	x1, x17, #0x4
    12d4:      	ld1.s	{ v13 }[1], [x1]
    12d8:      	tbnz	w0, #0x2, 0x1298 <_llm_rows.packet_batch.blocks+0xa3c>
    12dc:      	tbz	w0, #0x3, 0x12a4 <_llm_rows.packet_batch.blocks+0xa48>
    12e0:      	add	x1, x17, #0xc
    12e4:      	ld1.s	{ v13 }[3], [x1]
    12e8:      	tbnz	w0, #0x4, 0x12a8 <_llm_rows.packet_batch.blocks+0xa4c>
    12ec:      	tbz	w0, #0x5, 0x12b4 <_llm_rows.packet_batch.blocks+0xa58>
    12f0:      	add	x1, x17, #0x14
    12f4:      	ld1.s	{ v14 }[1], [x1]
    12f8:      	tbnz	w0, #0x6, 0x12b8 <_llm_rows.packet_batch.blocks+0xa5c>
    12fc:      	tbz	w0, #0x7, 0x1238 <_llm_rows.packet_batch.blocks+0x9dc>
    1300:      	add	x17, x17, #0x1c
    1304:      	ld1.s	{ v14 }[3], [x17]
    1308:      	b	0x1238 <_llm_rows.packet_batch.blocks+0x9dc>
    130c:      	add	x9, x9, x14
    1310:      	adrp	x13, 0x1000 <_llm_rows.packet_batch.blocks+0x7a4>
    1314:      	ldr	d21, [x13]
    1318:      	shl.8b	v22, v29, #0x7
    131c:      	cmlt.8b	v22, v22, #0
    1320:      	and.8b	v21, v22, v21
    1324:      	addv.8b	b21, v21
    1328:      	str	d21, [sp, #0x8]
    132c:      	fmov	w13, s21
    1330:      	movi.2d	v11, #0000000000000000
    1334:      	movi.2d	v10, #0000000000000000
    1338:      	tbz	w13, #0x0, 0x1378 <_llm_rows.packet_batch.blocks+0xb1c>
    133c:      	ldr	s11, [x9]
    1340:      	tbnz	w13, #0x1, 0x137c <_llm_rows.packet_batch.blocks+0xb20>
    1344:      	tbz	w13, #0x2, 0x1388 <_llm_rows.packet_batch.blocks+0xb2c>
    1348:      	add	x14, x9, #0x8
    134c:      	ld1.s	{ v11 }[2], [x14]
    1350:      	tbnz	w13, #0x3, 0x138c <_llm_rows.packet_batch.blocks+0xb30>
    1354:      	tbz	w13, #0x4, 0x1398 <_llm_rows.packet_batch.blocks+0xb3c>
    1358:      	add	x14, x9, #0x10
    135c:      	ld1.s	{ v10 }[0], [x14]
    1360:      	tbnz	w13, #0x5, 0x139c <_llm_rows.packet_batch.blocks+0xb40>
    1364:      	tbz	w13, #0x6, 0x13a8 <_llm_rows.packet_batch.blocks+0xb4c>
    1368:      	add	x14, x9, #0x18
    136c:      	ld1.s	{ v10 }[2], [x14]
    1370:      	tbnz	w13, #0x7, 0x13ac <_llm_rows.packet_batch.blocks+0xb50>
    1374:      	b	0x13b4 <_llm_rows.packet_batch.blocks+0xb58>
    1378:      	tbz	w13, #0x1, 0x1344 <_llm_rows.packet_batch.blocks+0xae8>
    137c:      	add	x14, x9, #0x4
    1380:      	ld1.s	{ v11 }[1], [x14]
    1384:      	tbnz	w13, #0x2, 0x1348 <_llm_rows.packet_batch.blocks+0xaec>
    1388:      	tbz	w13, #0x3, 0x1354 <_llm_rows.packet_batch.blocks+0xaf8>
    138c:      	add	x14, x9, #0xc
    1390:      	ld1.s	{ v11 }[3], [x14]
    1394:      	tbnz	w13, #0x4, 0x1358 <_llm_rows.packet_batch.blocks+0xafc>
    1398:      	tbz	w13, #0x5, 0x1364 <_llm_rows.packet_batch.blocks+0xb08>
    139c:      	add	x14, x9, #0x14
    13a0:      	ld1.s	{ v10 }[1], [x14]
    13a4:      	tbnz	w13, #0x6, 0x1368 <_llm_rows.packet_batch.blocks+0xb0c>
    13a8:      	tbz	w13, #0x7, 0x13b4 <_llm_rows.packet_batch.blocks+0xb58>
    13ac:      	add	x9, x9, #0x1c
    13b0:      	ld1.s	{ v10 }[3], [x9]
    13b4:      	mov	x14, #0x0               ; =0
    13b8:      	add	x9, x24, x15
    13bc:      	ldp	q21, q22, [x9]
    13c0:      	zip2.8b	v23, v29, v0
    13c4:      	ushll.4s	v23, v23, #0x0
    13c8:      	shl.4s	v23, v23, #0x1f
    13cc:      	cmlt.4s	v23, v23, #0
    13d0:      	bit.16b	v22, v10, v23
    13d4:      	zip1.8b	v23, v29, v0
    13d8:      	ushll.4s	v23, v23, #0x0
    13dc:      	shl.4s	v23, v23, #0x1f
    13e0:      	cmlt.4s	v23, v23, #0
    13e4:      	bit.16b	v21, v11, v23
    13e8:      	stp	q21, q22, [x9]
    13ec:      	add	x9, x8, x12
    13f0:      	movi.2d	v13, #0000000000000000
    13f4:      	movi.2d	v14, #0000000000000000
    13f8:      	movi.2d	v15, #0000000000000000
    13fc:      	movi.2d	v8, #0000000000000000
    1400:      	b	0x1428 <_llm_rows.packet_batch.blocks+0xbcc>
    1404:      	add.2d	v21, v13, v27
    1408:      	add.2d	v14, v14, v25
    140c:      	add.2d	v15, v15, v26
    1410:      	add.2d	v8, v8, v24
    1414:      	fmov	x12, d13
    1418:      	add	x14, x12, x11
    141c:      	mov.16b	v13, v21
    1420:      	cmp	x14, #0xc0
    1424:      	b.ge	0x1678 <_llm_rows.packet_batch.blocks+0xe1c>
    1428:      	fmov	w13, s28
    142c:      	lsl	x12, x14, #5
    1430:      	add	x14, x26, x12
    1434:      	ldp	q21, q23, [x14]
    1438:      	and.16b	v21, v20, v21
    143c:      	fneg.4s	v22, v21
    1440:      	and.16b	v22, v20, v22
    1444:      	fcmge.4s	v31, v22, v1
    1448:      	fcmge.4s	v12, v0, v22
    144c:      	and.16b	v31, v31, v12
    1450:      	and.16b	v31, v31, v22
    1454:      	fmul.4s	v12, v31, v18
    1458:      	movi.4s	v30, #0x4b, lsl #24
    145c:      	mvni.4s	v9, #0x80, lsl #24
    1460:      	bsl.16b	v9, v30, v12
    1464:      	fadd.4s	v12, v12, v9
    1468:      	fsub.4s	v9, v12, v9
    146c:      	fcvtzs.4s	v9, v9
    1470:      	scvtf.4s	v12, v9
    1474:      	fmul.4s	v30, v12, v17
    1478:      	fadd.4s	v30, v31, v30
    147c:      	fmul.4s	v31, v12, v16
    1480:      	fadd.4s	v30, v30, v31
    1484:      	fmul.4s	v31, v30, v7
    1488:      	fadd.4s	v31, v31, v6
    148c:      	fmul.4s	v31, v30, v31
    1490:      	fadd.4s	v31, v31, v5
    1494:      	fmul.4s	v31, v30, v31
    1498:      	fadd.4s	v31, v31, v4
    149c:      	fmul.4s	v31, v30, v31
    14a0:      	fadd.4s	v31, v31, v3
    14a4:      	fmul.4s	v31, v30, v31
    14a8:      	movi.4s	v12, #0x3f, lsl #24
    14ac:      	fadd.4s	v31, v31, v12
    14b0:      	fmul.4s	v12, v30, v30
    14b4:      	fmul.4s	v31, v12, v31
    14b8:      	fadd.4s	v30, v30, v31
    14bc:      	fadd.4s	v30, v30, v2
    14c0:      	sshr.4s	v31, v9, #0x1
    14c4:      	shl.4s	v12, v31, #0x17
    14c8:      	add.4s	v12, v12, v2
    14cc:      	fmul.4s	v30, v30, v12
    14d0:      	sub.4s	v31, v9, v31
    14d4:      	shl.4s	v31, v31, #0x17
    14d8:      	add.4s	v31, v31, v2
    14dc:      	fmul.4s	v30, v30, v31
    14e0:      	fcmgt.4s	v31, v1, v22
    14e4:      	fcmgt.4s	v9, v22, v0
    14e8:      	fcmeq.4s	v22, v22, v22
    14ec:      	fadd.4s	v30, v30, v2
    14f0:      	bit.16b	v30, v2, v31
    14f4:      	ldr	q31, [sp, #0x110]
    14f8:      	bit.16b	v30, v31, v9
    14fc:      	ldr	q31, [sp, #0x100]
    1500:      	bsl.16b	v22, v30, v31
    1504:      	fdiv.4s	v21, v21, v22
    1508:      	add	x14, x24, x12
    150c:      	ldp	q30, q22, [x14]
    1510:      	and.16b	v30, v20, v30
    1514:      	fmul.4s	v21, v30, v21
    1518:      	add	x12, x9, x12
    151c:      	tbz	w13, #0x0, 0x1540 <_llm_rows.packet_batch.blocks+0xce4>
    1520:      	str	s21, [x12]
    1524:      	and	w13, w13, #0xff
    1528:      	tbnz	w13, #0x1, 0x1548 <_llm_rows.packet_batch.blocks+0xcec>
    152c:      	tbz	w13, #0x2, 0x1554 <_llm_rows.packet_batch.blocks+0xcf8>
    1530:      	add	x14, x12, #0x8
    1534:      	st1.s	{ v21 }[2], [x14]
    1538:      	tbnz	w13, #0x3, 0x1558 <_llm_rows.packet_batch.blocks+0xcfc>
    153c:      	b	0x1560 <_llm_rows.packet_batch.blocks+0xd04>
    1540:      	and	w13, w13, #0xff
    1544:      	tbz	w13, #0x1, 0x152c <_llm_rows.packet_batch.blocks+0xcd0>
    1548:      	add	x14, x12, #0x4
    154c:      	st1.s	{ v21 }[1], [x14]
    1550:      	tbnz	w13, #0x2, 0x1530 <_llm_rows.packet_batch.blocks+0xcd4>
    1554:      	tbz	w13, #0x3, 0x1560 <_llm_rows.packet_batch.blocks+0xd04>
    1558:      	add	x14, x12, #0xc
    155c:      	st1.s	{ v21 }[3], [x14]
    1560:      	and.16b	v21, v19, v23
    1564:      	fneg.4s	v23, v21
    1568:      	and.16b	v23, v19, v23
    156c:      	fcmge.4s	v30, v23, v1
    1570:      	fcmge.4s	v31, v0, v23
    1574:      	and.16b	v30, v30, v31
    1578:      	and.16b	v30, v30, v23
    157c:      	fmul.4s	v31, v30, v18
    1580:      	movi.4s	v9, #0x4b, lsl #24
    1584:      	mvni.4s	v12, #0x80, lsl #24
    1588:      	bif.16b	v9, v31, v12
    158c:      	fadd.4s	v31, v31, v9
    1590:      	fsub.4s	v31, v31, v9
    1594:      	fcvtzs.4s	v31, v31
    1598:      	scvtf.4s	v9, v31
    159c:      	fmul.4s	v12, v9, v17
    15a0:      	fadd.4s	v30, v30, v12
    15a4:      	fmul.4s	v9, v9, v16
    15a8:      	fadd.4s	v30, v30, v9
    15ac:      	fmul.4s	v9, v30, v7
    15b0:      	fadd.4s	v9, v9, v6
    15b4:      	fmul.4s	v9, v30, v9
    15b8:      	fadd.4s	v9, v9, v5
    15bc:      	fmul.4s	v9, v30, v9
    15c0:      	fadd.4s	v9, v9, v4
    15c4:      	fmul.4s	v9, v30, v9
    15c8:      	fadd.4s	v9, v9, v3
    15cc:      	fmul.4s	v9, v30, v9
    15d0:      	movi.4s	v12, #0x3f, lsl #24
    15d4:      	fadd.4s	v9, v9, v12
    15d8:      	fmul.4s	v12, v30, v30
    15dc:      	fmul.4s	v9, v12, v9
    15e0:      	fadd.4s	v30, v30, v9
    15e4:      	fadd.4s	v30, v30, v2
    15e8:      	sshr.4s	v9, v31, #0x1
    15ec:      	shl.4s	v12, v9, #0x17
    15f0:      	add.4s	v12, v12, v2
    15f4:      	fmul.4s	v30, v30, v12
    15f8:      	sub.4s	v31, v31, v9
    15fc:      	shl.4s	v31, v31, #0x17
    1600:      	add.4s	v31, v31, v2
    1604:      	fmul.4s	v30, v30, v31
    1608:      	fcmgt.4s	v31, v1, v23
    160c:      	fcmgt.4s	v9, v23, v0
    1610:      	fcmeq.4s	v23, v23, v23
    1614:      	fadd.4s	v30, v30, v2
    1618:      	bit.16b	v30, v2, v31
    161c:      	ldr	q31, [sp, #0x110]
    1620:      	bit.16b	v30, v31, v9
    1624:      	ldr	q31, [sp, #0x100]
    1628:      	bsl.16b	v23, v30, v31
    162c:      	fdiv.4s	v21, v21, v23
    1630:      	and.16b	v22, v19, v22
    1634:      	fmul.4s	v21, v22, v21
    1638:      	tbz	w13, #0x4, 0x1658 <_llm_rows.packet_batch.blocks+0xdfc>
    163c:      	str	s21, [x12, #0x10]
    1640:      	tbnz	w13, #0x5, 0x165c <_llm_rows.packet_batch.blocks+0xe00>
    1644:      	tbz	w13, #0x6, 0x1668 <_llm_rows.packet_batch.blocks+0xe0c>
    1648:      	add	x14, x12, #0x18
    164c:      	st1.s	{ v21 }[2], [x14]
    1650:      	tbz	w13, #0x7, 0x1404 <_llm_rows.packet_batch.blocks+0xba8>
    1654:      	b	0x166c <_llm_rows.packet_batch.blocks+0xe10>
    1658:      	tbz	w13, #0x5, 0x1644 <_llm_rows.packet_batch.blocks+0xde8>
    165c:      	add	x14, x12, #0x14
    1660:      	st1.s	{ v21 }[1], [x14]
    1664:      	tbnz	w13, #0x6, 0x1648 <_llm_rows.packet_batch.blocks+0xdec>
    1668:      	tbz	w13, #0x7, 0x1404 <_llm_rows.packet_batch.blocks+0xba8>
    166c:      	add	x12, x12, #0x1c
    1670:      	st1.s	{ v21 }[3], [x12]
    1674:      	b	0x1404 <_llm_rows.packet_batch.blocks+0xba8>
    1678:      	ldr	q24, [sp, #0x40]
    167c:      	fneg.4s	v19, v24
    1680:      	ldr	d20, [sp, #0x8]
    1684:      	fmov	w9, s20
    1688:      	zip1.8b	v20, v29, v0
    168c:      	ushll.4s	v20, v20, #0x0
    1690:      	shl.4s	v20, v20, #0x1f
    1694:      	cmlt.4s	v20, v20, #0
    1698:      	and.16b	v19, v20, v19
    169c:      	fcmge.4s	v20, v19, v1
    16a0:      	fcmge.4s	v21, v0, v19
    16a4:      	and.16b	v20, v20, v21
    16a8:      	and.16b	v20, v20, v19
    16ac:      	fmul.4s	v21, v20, v18
    16b0:      	movi.4s	v22, #0x4b, lsl #24
    16b4:      	mvni.4s	v23, #0x80, lsl #24
    16b8:      	bif.16b	v22, v21, v23
    16bc:      	fadd.4s	v21, v21, v22
    16c0:      	fsub.4s	v21, v21, v22
    16c4:      	fcvtzs.4s	v21, v21
    16c8:      	scvtf.4s	v22, v21
    16cc:      	fmul.4s	v23, v22, v17
    16d0:      	fadd.4s	v20, v20, v23
    16d4:      	fmul.4s	v22, v22, v16
    16d8:      	fadd.4s	v20, v20, v22
    16dc:      	fmul.4s	v22, v20, v7
    16e0:      	fadd.4s	v22, v22, v6
    16e4:      	fmul.4s	v22, v20, v22
    16e8:      	fadd.4s	v22, v22, v5
    16ec:      	fmul.4s	v22, v20, v22
    16f0:      	fadd.4s	v22, v22, v4
    16f4:      	fmul.4s	v22, v20, v22
    16f8:      	fadd.4s	v22, v22, v3
    16fc:      	fmul.4s	v22, v20, v22
    1700:      	movi.4s	v23, #0x3f, lsl #24
    1704:      	fadd.4s	v22, v22, v23
    1708:      	fmul.4s	v23, v20, v20
    170c:      	fmul.4s	v22, v23, v22
    1710:      	fadd.4s	v20, v20, v22
    1714:      	fadd.4s	v20, v20, v2
    1718:      	sshr.4s	v22, v21, #0x1
    171c:      	shl.4s	v23, v22, #0x17
    1720:      	add.4s	v23, v23, v2
    1724:      	fmul.4s	v20, v20, v23
    1728:      	sub.4s	v21, v21, v22
    172c:      	shl.4s	v21, v21, #0x17
    1730:      	add.4s	v21, v21, v2
    1734:      	fmul.4s	v20, v20, v21
    1738:      	fcmgt.4s	v21, v1, v19
    173c:      	fcmgt.4s	v22, v19, v0
    1740:      	fcmeq.4s	v19, v19, v19
    1744:      	fadd.4s	v20, v20, v2
    1748:      	bit.16b	v20, v2, v21
    174c:      	ldp	q21, q23, [sp, #0x100]
    1750:      	bit.16b	v20, v23, v22
    1754:      	bsl.16b	v19, v20, v21
    1758:      	fdiv.4s	v19, v24, v19
    175c:      	fmul.4s	v19, v19, v11
    1760:      	ldr	q21, [sp, #0x50]
    1764:      	ldp	q23, q22, [sp, #0x20]
    1768:      	stp	q21, q22, [sp, #0x1b0]
    176c:      	ldr	q20, [sp, #0x10]
    1770:      	stp	q23, q20, [sp, #0x1d0]
    1774:      	and	x11, x10, #0x7
    1778:      	add	x12, sp, #0x1b0
    177c:      	ldr	x11, [x12, x11, lsl #3]
    1780:      	sub	x10, x11, x10
    1784:      	add	x8, x8, x10, lsl #2
    1788:      	tbz	w9, #0x0, 0x17ac <_llm_rows.packet_batch.blocks+0xf50>
    178c:      	str	s19, [x8]
    1790:      	ldr	q23, [sp, #0xc0]
    1794:      	tbnz	w9, #0x1, 0x17b4 <_llm_rows.packet_batch.blocks+0xf58>
    1798:      	tbz	w9, #0x2, 0x17c0 <_llm_rows.packet_batch.blocks+0xf64>
    179c:      	add	x10, x8, #0x8
    17a0:      	st1.s	{ v19 }[2], [x10]
    17a4:      	tbnz	w9, #0x3, 0x17c4 <_llm_rows.packet_batch.blocks+0xf68>
    17a8:      	b	0x17cc <_llm_rows.packet_batch.blocks+0xf70>
    17ac:      	ldr	q23, [sp, #0xc0]
    17b0:      	tbz	w9, #0x1, 0x1798 <_llm_rows.packet_batch.blocks+0xf3c>
    17b4:      	add	x10, x8, #0x4
    17b8:      	st1.s	{ v19 }[1], [x10]
    17bc:      	tbnz	w9, #0x2, 0x179c <_llm_rows.packet_batch.blocks+0xf40>
    17c0:      	tbz	w9, #0x3, 0x17cc <_llm_rows.packet_batch.blocks+0xf70>
    17c4:      	add	x10, x8, #0xc
    17c8:      	st1.s	{ v19 }[3], [x10]
    17cc:      	fneg.4s	v19, v23
    17d0:      	zip2.8b	v20, v29, v0
    17d4:      	ushll.4s	v20, v20, #0x0
    17d8:      	shl.4s	v20, v20, #0x1f
    17dc:      	cmlt.4s	v20, v20, #0
    17e0:      	and.16b	v19, v20, v19
    17e4:      	fcmge.4s	v20, v19, v1
    17e8:      	fcmge.4s	v21, v0, v19
    17ec:      	and.16b	v20, v20, v21
    17f0:      	and.16b	v20, v20, v19
    17f4:      	fmul.4s	v18, v20, v18
    17f8:      	movi.4s	v21, #0x4b, lsl #24
    17fc:      	mvni.4s	v22, #0x80, lsl #24
    1800:      	bif.16b	v21, v18, v22
    1804:      	fadd.4s	v18, v18, v21
    1808:      	fsub.4s	v18, v18, v21
    180c:      	fcvtzs.4s	v18, v18
    1810:      	scvtf.4s	v21, v18
    1814:      	fmul.4s	v17, v21, v17
    1818:      	fadd.4s	v17, v20, v17
    181c:      	fmul.4s	v16, v21, v16
    1820:      	fadd.4s	v16, v17, v16
    1824:      	fmul.4s	v7, v16, v7
    1828:      	fadd.4s	v6, v7, v6
    182c:      	fmul.4s	v6, v16, v6
    1830:      	fadd.4s	v5, v6, v5
    1834:      	fmul.4s	v5, v16, v5
    1838:      	fadd.4s	v4, v5, v4
    183c:      	fmul.4s	v4, v16, v4
    1840:      	fadd.4s	v3, v4, v3
    1844:      	fmul.4s	v3, v16, v3
    1848:      	movi.4s	v4, #0x3f, lsl #24
    184c:      	fadd.4s	v3, v3, v4
    1850:      	fmul.4s	v4, v16, v16
    1854:      	fmul.4s	v3, v4, v3
    1858:      	fadd.4s	v3, v16, v3
    185c:      	fadd.4s	v3, v3, v2
    1860:      	sshr.4s	v4, v18, #0x1
    1864:      	shl.4s	v5, v4, #0x17
    1868:      	add.4s	v5, v5, v2
    186c:      	fmul.4s	v3, v3, v5
    1870:      	sub.4s	v4, v18, v4
    1874:      	shl.4s	v4, v4, #0x17
    1878:      	add.4s	v4, v4, v2
    187c:      	fmul.4s	v3, v3, v4
    1880:      	fcmgt.4s	v1, v1, v19
    1884:      	fcmgt.4s	v0, v19, v0
    1888:      	fcmeq.4s	v4, v19, v19
    188c:      	fadd.4s	v3, v3, v2
    1890:      	bsl.16b	v1, v2, v3
    1894:      	ldr	q2, [sp, #0x110]
    1898:      	bsl.16b	v0, v2, v1
    189c:      	ldr	q1, [sp, #0x100]
    18a0:      	bif.16b	v0, v1, v4
    18a4:      	fdiv.4s	v0, v23, v0
    18a8:      	fmul.4s	v0, v0, v10
    18ac:      	tbz	w9, #0x4, 0x1cb4 <_llm_rows.packet_batch.blocks+0x1458>
    18b0:      	str	s0, [x8, #0x10]
    18b4:      	tbnz	w9, #0x5, 0x1cb8 <_llm_rows.packet_batch.blocks+0x145c>
    18b8:      	tbz	w9, #0x6, 0x1cc4 <_llm_rows.packet_batch.blocks+0x1468>
    18bc:      	add	x10, x8, #0x18
    18c0:      	st1.s	{ v0 }[2], [x10]
    18c4:      	tbnz	w9, #0x7, 0x1cc8 <_llm_rows.packet_batch.blocks+0x146c>
    18c8:      	b	0x92c <_llm_rows.packet_batch.blocks+0xd0>
    18cc:      	xtn.8b	v20, v29
    18d0:      	movi	d19, #0x0000000000ffff
    18d4:      	and.8b	v19, v20, v19
    18d8:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x7a4>
    18dc:      	ldr	d24, [x10]
    18e0:      	and.8b	v20, v20, v24
    18e4:      	addv.8b	b20, v20
    18e8:      	fmov	w12, s20
    18ec:      	umaxv.8b	b20, v19
    18f0:      	fmov	w10, s20
    18f4:      	rbit	w13, w12
    18f8:      	clz	w13, w13
    18fc:      	tst	w10, #0x1
    1900:      	csel	w10, w13, wzr, ne
    1904:      	mov	w13, #0x600             ; =1536
    1908:      	dup.2d	v9, x13
    190c:      	umlal.2d	v30, v31, v25
    1910:      	mov	b20, v19[0]
    1914:      	mov.b	v20[4], v19[1]
    1918:      	add.2d	v28, v30, v9
    191c:      	ushll.2d	v20, v20, #0x0
    1920:      	shl.2d	v20, v20, #0x3f
    1924:      	cmlt.2d	v20, v20, #0
    1928:      	and.16b	v20, v20, v28
    192c:      	movi.2d	v24, #0000000000000000
    1930:      	stp	q24, q24, [sp, #0x180]
    1934:      	stp	q20, q24, [sp, #0x160]
    1938:      	and	x13, x10, #0x7
    193c:      	add	x14, sp, #0x160
    1940:      	ldr	x13, [x14, x13, lsl #3]
    1944:      	sub	x13, x13, x10
    1948:      	lsl	x13, x13, #2
    194c:      	add	x11, x11, x13
    1950:      	movi.2d	v29, #0000000000000000
    1954:      	movi.2d	v20, #0000000000000000
    1958:      	tbz	w12, #0x0, 0x1998 <_llm_rows.packet_batch.blocks+0x113c>
    195c:      	ldr	s29, [x11]
    1960:      	tbnz	w12, #0x1, 0x199c <_llm_rows.packet_batch.blocks+0x1140>
    1964:      	tbz	w12, #0x2, 0x19a8 <_llm_rows.packet_batch.blocks+0x114c>
    1968:      	add	x14, x11, #0x8
    196c:      	ld1.s	{ v29 }[2], [x14]
    1970:      	tbnz	w12, #0x3, 0x19ac <_llm_rows.packet_batch.blocks+0x1150>
    1974:      	tbz	w12, #0x4, 0x19b8 <_llm_rows.packet_batch.blocks+0x115c>
    1978:      	add	x14, x11, #0x10
    197c:      	ld1.s	{ v20 }[0], [x14]
    1980:      	tbnz	w12, #0x5, 0x19bc <_llm_rows.packet_batch.blocks+0x1160>
    1984:      	tbz	w12, #0x6, 0x19c8 <_llm_rows.packet_batch.blocks+0x116c>
    1988:      	add	x14, x11, #0x18
    198c:      	ld1.s	{ v20 }[2], [x14]
    1990:      	tbnz	w12, #0x7, 0x19cc <_llm_rows.packet_batch.blocks+0x1170>
    1994:      	b	0x19d4 <_llm_rows.packet_batch.blocks+0x1178>
    1998:      	tbz	w12, #0x1, 0x1964 <_llm_rows.packet_batch.blocks+0x1108>
    199c:      	add	x14, x11, #0x4
    19a0:      	ld1.s	{ v29 }[1], [x14]
    19a4:      	tbnz	w12, #0x2, 0x1968 <_llm_rows.packet_batch.blocks+0x110c>
    19a8:      	tbz	w12, #0x3, 0x1974 <_llm_rows.packet_batch.blocks+0x1118>
    19ac:      	add	x14, x11, #0xc
    19b0:      	ld1.s	{ v29 }[3], [x14]
    19b4:      	tbnz	w12, #0x4, 0x1978 <_llm_rows.packet_batch.blocks+0x111c>
    19b8:      	tbz	w12, #0x5, 0x1984 <_llm_rows.packet_batch.blocks+0x1128>
    19bc:      	add	x14, x11, #0x14
    19c0:      	ld1.s	{ v20 }[1], [x14]
    19c4:      	tbnz	w12, #0x6, 0x1988 <_llm_rows.packet_batch.blocks+0x112c>
    19c8:      	tbz	w12, #0x7, 0x19d4 <_llm_rows.packet_batch.blocks+0x1178>
    19cc:      	add	x11, x11, #0x1c
    19d0:      	ld1.s	{ v20 }[3], [x11]
    19d4:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7a4>
    19d8:      	ldr	d24, [x11]
    19dc:      	shl.8b	v30, v19, #0x7
    19e0:      	cmlt.8b	v30, v30, #0
    19e4:      	and.8b	v24, v30, v24
    19e8:      	addv.8b	b31, v24
    19ec:      	fmov	w11, s31
    19f0:      	add	x9, x9, x13
    19f4:      	movi.2d	v8, #0000000000000000
    19f8:      	movi.2d	v30, #0000000000000000
    19fc:      	tbz	w11, #0x0, 0x1a3c <_llm_rows.packet_batch.blocks+0x11e0>
    1a00:      	ldr	s8, [x9]
    1a04:      	tbnz	w11, #0x1, 0x1a40 <_llm_rows.packet_batch.blocks+0x11e4>
    1a08:      	tbz	w11, #0x2, 0x1a4c <_llm_rows.packet_batch.blocks+0x11f0>
    1a0c:      	add	x12, x9, #0x8
    1a10:      	ld1.s	{ v8 }[2], [x12]
    1a14:      	tbnz	w11, #0x3, 0x1a50 <_llm_rows.packet_batch.blocks+0x11f4>
    1a18:      	tbz	w11, #0x4, 0x1a5c <_llm_rows.packet_batch.blocks+0x1200>
    1a1c:      	add	x12, x9, #0x10
    1a20:      	ld1.s	{ v30 }[0], [x12]
    1a24:      	tbnz	w11, #0x5, 0x1a60 <_llm_rows.packet_batch.blocks+0x1204>
    1a28:      	tbz	w11, #0x6, 0x1a6c <_llm_rows.packet_batch.blocks+0x1210>
    1a2c:      	add	x12, x9, #0x18
    1a30:      	ld1.s	{ v30 }[2], [x12]
    1a34:      	tbnz	w11, #0x7, 0x1a70 <_llm_rows.packet_batch.blocks+0x1214>
    1a38:      	b	0x1a78 <_llm_rows.packet_batch.blocks+0x121c>
    1a3c:      	tbz	w11, #0x1, 0x1a08 <_llm_rows.packet_batch.blocks+0x11ac>
    1a40:      	add	x12, x9, #0x4
    1a44:      	ld1.s	{ v8 }[1], [x12]
    1a48:      	tbnz	w11, #0x2, 0x1a0c <_llm_rows.packet_batch.blocks+0x11b0>
    1a4c:      	tbz	w11, #0x3, 0x1a18 <_llm_rows.packet_batch.blocks+0x11bc>
    1a50:      	add	x12, x9, #0xc
    1a54:      	ld1.s	{ v8 }[3], [x12]
    1a58:      	tbnz	w11, #0x4, 0x1a1c <_llm_rows.packet_batch.blocks+0x11c0>
    1a5c:      	tbz	w11, #0x5, 0x1a28 <_llm_rows.packet_batch.blocks+0x11cc>
    1a60:      	add	x12, x9, #0x14
    1a64:      	ld1.s	{ v30 }[1], [x12]
    1a68:      	tbnz	w11, #0x6, 0x1a2c <_llm_rows.packet_batch.blocks+0x11d0>
    1a6c:      	tbz	w11, #0x7, 0x1a78 <_llm_rows.packet_batch.blocks+0x121c>
    1a70:      	add	x9, x9, #0x1c
    1a74:      	ld1.s	{ v30 }[3], [x9]
    1a78:      	umlal.2d	v23, v27, v25
    1a7c:      	add.2d	v23, v23, v9
    1a80:      	umlal.2d	v22, v26, v25
    1a84:      	add.2d	v22, v22, v9
    1a88:      	ldr	d24, [sp, #0xc0]
    1a8c:      	umlal.2d	v21, v24, v25
    1a90:      	add.2d	v24, v21, v9
    1a94:      	fneg.4s	v21, v29
    1a98:      	zip1.8b	v25, v19, v0
    1a9c:      	ushll.4s	v25, v25, #0x0
    1aa0:      	shl.4s	v25, v25, #0x1f
    1aa4:      	cmlt.4s	v25, v25, #0
    1aa8:      	and.16b	v21, v25, v21
    1aac:      	fcmge.4s	v25, v21, v1
    1ab0:      	fcmge.4s	v26, v0, v21
    1ab4:      	and.16b	v25, v25, v26
    1ab8:      	and.16b	v25, v25, v21
    1abc:      	fmul.4s	v26, v25, v18
    1ac0:      	movi.4s	v27, #0x4b, lsl #24
    1ac4:      	mvni.4s	v9, #0x80, lsl #24
    1ac8:      	bif.16b	v27, v26, v9
    1acc:      	fadd.4s	v26, v26, v27
    1ad0:      	fsub.4s	v26, v26, v27
    1ad4:      	fcvtzs.4s	v26, v26
    1ad8:      	scvtf.4s	v27, v26
    1adc:      	fmul.4s	v9, v27, v17
    1ae0:      	fadd.4s	v25, v25, v9
    1ae4:      	fmul.4s	v27, v27, v16
    1ae8:      	fadd.4s	v25, v25, v27
    1aec:      	fmul.4s	v27, v25, v7
    1af0:      	fadd.4s	v27, v27, v6
    1af4:      	fmul.4s	v27, v25, v27
    1af8:      	fadd.4s	v27, v27, v5
    1afc:      	fmul.4s	v27, v25, v27
    1b00:      	fadd.4s	v27, v27, v4
    1b04:      	fmul.4s	v27, v25, v27
    1b08:      	fadd.4s	v27, v27, v3
    1b0c:      	fmul.4s	v27, v25, v27
    1b10:      	movi.4s	v9, #0x3f, lsl #24
    1b14:      	fadd.4s	v27, v27, v9
    1b18:      	fmul.4s	v9, v25, v25
    1b1c:      	fmul.4s	v27, v9, v27
    1b20:      	fadd.4s	v25, v25, v27
    1b24:      	fadd.4s	v25, v25, v2
    1b28:      	sshr.4s	v27, v26, #0x1
    1b2c:      	shl.4s	v9, v27, #0x17
    1b30:      	add.4s	v9, v9, v2
    1b34:      	fmul.4s	v25, v25, v9
    1b38:      	sub.4s	v26, v26, v27
    1b3c:      	shl.4s	v26, v26, #0x17
    1b40:      	add.4s	v26, v26, v2
    1b44:      	fmul.4s	v25, v25, v26
    1b48:      	fcmgt.4s	v26, v1, v21
    1b4c:      	fcmgt.4s	v27, v21, v0
    1b50:      	fcmeq.4s	v21, v21, v21
    1b54:      	fadd.4s	v25, v25, v2
    1b58:      	bit.16b	v25, v2, v26
    1b5c:      	ldr	q26, [sp, #0x110]
    1b60:      	bit.16b	v25, v26, v27
    1b64:      	ldr	q26, [sp, #0x100]
    1b68:      	bsl.16b	v21, v25, v26
    1b6c:      	fdiv.4s	v21, v29, v21
    1b70:      	fmul.4s	v21, v8, v21
    1b74:      	stp	q28, q23, [sp, #0x120]
    1b78:      	stp	q22, q24, [sp, #0x140]
    1b7c:      	and	x9, x10, #0x7
    1b80:      	add	x11, sp, #0x120
    1b84:      	ldr	x9, [x11, x9, lsl #3]
    1b88:      	sub	x9, x9, x10
    1b8c:      	add	x8, x8, x9, lsl #2
    1b90:      	fmov	w9, s31
    1b94:      	tbz	w9, #0x0, 0x1bb4 <_llm_rows.packet_batch.blocks+0x1358>
    1b98:      	str	s21, [x8]
    1b9c:      	tbnz	w9, #0x1, 0x1bb8 <_llm_rows.packet_batch.blocks+0x135c>
    1ba0:      	tbz	w9, #0x2, 0x1bc4 <_llm_rows.packet_batch.blocks+0x1368>
    1ba4:      	add	x10, x8, #0x8
    1ba8:      	st1.s	{ v21 }[2], [x10]
    1bac:      	tbnz	w9, #0x3, 0x1bc8 <_llm_rows.packet_batch.blocks+0x136c>
    1bb0:      	b	0x1bd0 <_llm_rows.packet_batch.blocks+0x1374>
    1bb4:      	tbz	w9, #0x1, 0x1ba0 <_llm_rows.packet_batch.blocks+0x1344>
    1bb8:      	add	x10, x8, #0x4
    1bbc:      	st1.s	{ v21 }[1], [x10]
    1bc0:      	tbnz	w9, #0x2, 0x1ba4 <_llm_rows.packet_batch.blocks+0x1348>
    1bc4:      	tbz	w9, #0x3, 0x1bd0 <_llm_rows.packet_batch.blocks+0x1374>
    1bc8:      	add	x10, x8, #0xc
    1bcc:      	st1.s	{ v21 }[3], [x10]
    1bd0:      	fneg.4s	v21, v20
    1bd4:      	zip2.8b	v19, v19, v0
    1bd8:      	ushll.4s	v19, v19, #0x0
    1bdc:      	shl.4s	v19, v19, #0x1f
    1be0:      	cmlt.4s	v19, v19, #0
    1be4:      	and.16b	v19, v19, v21
    1be8:      	fcmge.4s	v21, v19, v1
    1bec:      	fcmge.4s	v22, v0, v19
    1bf0:      	and.16b	v21, v21, v22
    1bf4:      	and.16b	v21, v21, v19
    1bf8:      	fmul.4s	v18, v21, v18
    1bfc:      	movi.4s	v22, #0x4b, lsl #24
    1c00:      	mvni.4s	v23, #0x80, lsl #24
    1c04:      	bif.16b	v22, v18, v23
    1c08:      	fadd.4s	v18, v18, v22
    1c0c:      	fsub.4s	v18, v18, v22
    1c10:      	fcvtzs.4s	v18, v18
    1c14:      	scvtf.4s	v22, v18
    1c18:      	fmul.4s	v17, v22, v17
    1c1c:      	fadd.4s	v17, v21, v17
    1c20:      	fmul.4s	v16, v22, v16
    1c24:      	fadd.4s	v16, v17, v16
    1c28:      	fmul.4s	v7, v16, v7
    1c2c:      	fadd.4s	v6, v7, v6
    1c30:      	fmul.4s	v6, v16, v6
    1c34:      	fadd.4s	v5, v6, v5
    1c38:      	fmul.4s	v5, v16, v5
    1c3c:      	fadd.4s	v4, v5, v4
    1c40:      	fmul.4s	v4, v16, v4
    1c44:      	fadd.4s	v3, v4, v3
    1c48:      	fmul.4s	v3, v16, v3
    1c4c:      	movi.4s	v4, #0x3f, lsl #24
    1c50:      	fadd.4s	v3, v3, v4
    1c54:      	fmul.4s	v4, v16, v16
    1c58:      	fmul.4s	v3, v4, v3
    1c5c:      	fadd.4s	v3, v16, v3
    1c60:      	fadd.4s	v3, v3, v2
    1c64:      	sshr.4s	v4, v18, #0x1
    1c68:      	shl.4s	v5, v4, #0x17
    1c6c:      	add.4s	v5, v5, v2
    1c70:      	fmul.4s	v3, v3, v5
    1c74:      	sub.4s	v4, v18, v4
    1c78:      	shl.4s	v4, v4, #0x17
    1c7c:      	add.4s	v4, v4, v2
    1c80:      	fmul.4s	v3, v3, v4
    1c84:      	fcmgt.4s	v1, v1, v19
    1c88:      	fcmgt.4s	v0, v19, v0
    1c8c:      	fcmeq.4s	v4, v19, v19
    1c90:      	fadd.4s	v3, v3, v2
    1c94:      	bsl.16b	v1, v2, v3
    1c98:      	ldr	q2, [sp, #0x110]
    1c9c:      	bsl.16b	v0, v2, v1
    1ca0:      	ldr	q1, [sp, #0x100]
    1ca4:      	bif.16b	v0, v1, v4
    1ca8:      	fdiv.4s	v0, v20, v0
    1cac:      	fmul.4s	v0, v30, v0
    1cb0:      	tbnz	w9, #0x4, 0x18b0 <_llm_rows.packet_batch.blocks+0x1054>
    1cb4:      	tbz	w9, #0x5, 0x18b8 <_llm_rows.packet_batch.blocks+0x105c>
    1cb8:      	add	x10, x8, #0x14
    1cbc:      	st1.s	{ v0 }[1], [x10]
    1cc0:      	tbnz	w9, #0x6, 0x18bc <_llm_rows.packet_batch.blocks+0x1060>
    1cc4:      	tbz	w9, #0x7, 0x92c <_llm_rows.packet_batch.blocks+0xd0>
    1cc8:      	add	x8, x8, #0x1c
    1ccc:      	st1.s	{ v0 }[3], [x8]
    1cd0:      	b	0x92c <_llm_rows.packet_batch.blocks+0xd0>
    1cd4:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    1cd8:      	add	sp, sp, #0x2d0
    1cdc:      	ldp	x29, x30, [sp, #0x90]
    1ce0:      	ldp	x20, x19, [sp, #0x80]
    1ce4:      	ldp	x22, x21, [sp, #0x70]
    1ce8:      	ldp	x24, x23, [sp, #0x60]
    1cec:      	ldp	x26, x25, [sp, #0x50]
    1cf0:      	ldp	x28, x27, [sp, #0x40]
    1cf4:      	ldp	d9, d8, [sp, #0x30]
    1cf8:      	ldp	d11, d10, [sp, #0x20]
    1cfc:      	ldp	d13, d12, [sp, #0x10]
    1d00:      	ldp	d15, d14, [sp], #0xa0
    1d04:      	ret

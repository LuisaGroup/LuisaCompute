
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/swiglu-257x1538/off/object/tile_xir_w8_37994_1788936541854693_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d11, d10, [sp, #-0x70]!
       4:      	stp	d9, d8, [sp, #0x10]
       8:      	stp	x26, x25, [sp, #0x20]
       c:      	stp	x24, x23, [sp, #0x30]
      10:      	stp	x22, x21, [sp, #0x40]
      14:      	stp	x20, x19, [sp, #0x50]
      18:      	stp	x29, x30, [sp, #0x60]
      1c:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      20:      	sub	sp, sp, #0x50
      24:      	ldr	x22, [x0]
      28:      	ldr	x21, [x0, #0x10]
      2c:      	ldr	x19, [x0, #0x30]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w8, w8, #3
      40:      	dup.2s	v0, w8
      44:      	ushll.2d	v0, v0, #0x0
      48:      	subs	x8, x22, x19
      4c:      	mov	w9, #0x2007             ; =8199
      50:      	movk	w9, #0x18, lsl #16
      54:      	ccmp	x8, x9, #0x0, hs
      58:      	cset	w8, hi
      5c:      	subs	x10, x19, x22
      60:      	ccmp	x10, x9, #0x0, hs
      64:      	csinc	w10, w8, wzr, ls
      68:      	subs	x8, x21, x19
      6c:      	ccmp	x8, x9, #0x0, hs
      70:      	cset	w8, hi
      74:      	subs	x11, x19, x21
      78:      	ccmp	x11, x9, #0x0, hs
      7c:      	csinc	w9, w8, wzr, ls
      80:      	fmov	x8, d0
      84:      	mov	w11, #0x1808            ; =6152
      88:      	umull	x8, w8, w11
      8c:      	cmp	w10, #0x1
      90:      	ccmp	w9, #0x0, #0x4, eq
      94:      	b.ne	0x498 <ltmp0+0x498>
      98:      	mov	w20, #0x1800            ; =6144
      9c:      	add	x23, sp, #0x1, lsl #12  ; =0x1000
      a0:      	add	x23, x23, #0x830
      a4:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
      a8:      	add	x0, x0, #0x830
      ac:      	add	x1, x22, x8
      b0:      	mov	w2, #0x1800             ; =6144
      b4:      	str	q0, [sp]
      b8:      	bl	0xb8 <ltmp0+0xb8>
      bc:      	ldr	q0, [sp]
      c0:      	fmov	x24, d0
      c4:      	mov	w25, #0x1808            ; =6152
      c8:      	umaddl	x20, w24, w25, x20
      cc:      	add	x8, x22, x20
      d0:      	add	x9, x8, #0x4
      d4:      	ldr	s0, [x8]
      d8:      	ld1.s	{ v0 }[1], [x9]
      dc:      	str	q0, [sp]
      e0:      	str	q0, [sp, #0x3030]
      e4:      	umaddl	x1, w24, w25, x21
      e8:      	add	x22, sp, #0x10
      ec:      	add	x0, sp, #0x10
      f0:      	mov	w2, #0x1800             ; =6144
      f4:      	bl	0xf4 <ltmp0+0xf4>
      f8:      	mov	x8, #0x0                ; =0
      fc:      	add	x9, x21, x20
     100:      	ldr	s0, [x9], #0x4
     104:      	ld1.s	{ v0 }[1], [x9]
     108:      	str	q0, [sp, #0x1810]
     10c:      	mov	w9, #0x42d00000         ; =1120927744
     110:      	dup.4s	v2, w9
     114:      	mov	w9, #-0x3d380000        ; =-1027080192
     118:      	dup.4s	v3, w9
     11c:      	mov	w9, #0xaa3b             ; =43579
     120:      	movk	w9, #0x3fb8, lsl #16
     124:      	dup.4s	v4, w9
     128:      	umaddl	x9, w24, w25, x19
     12c:      	movi.4s	v5, #0x4b, lsl #24
     130:      	mvni.4s	v6, #0x80, lsl #24
     134:      	mov	w10, #0x7200            ; =29184
     138:      	movk	w10, #0xbf31, lsl #16
     13c:      	dup.4s	v7, w10
     140:      	mov	w10, #0xbe8e            ; =48782
     144:      	movk	w10, #0xb5bf, lsl #16
     148:      	dup.4s	v16, w10
     14c:      	mov	w10, #0x2bda            ; =11226
     150:      	movk	w10, #0x3950, lsl #16
     154:      	dup.4s	v17, w10
     158:      	mov	w10, #0x96c9            ; =38601
     15c:      	movk	w10, #0x3ab6, lsl #16
     160:      	dup.4s	v18, w10
     164:      	mov	w10, #0x88a6            ; =34982
     168:      	movk	w10, #0x3c08, lsl #16
     16c:      	dup.4s	v19, w10
     170:      	mov	w10, #0xaa7a            ; =43642
     174:      	movk	w10, #0x3d2a, lsl #16
     178:      	dup.4s	v20, w10
     17c:      	mov	w10, #0xaaab            ; =43691
     180:      	movk	w10, #0x3e2a, lsl #16
     184:      	dup.4s	v21, w10
     188:      	movi.4s	v22, #0x3f, lsl #24
     18c:      	fmov.4s	v1, #1.00000000
     190:      	mvni.4s	v23, #0x7f, msl #16
     194:      	fneg.4s	v23, v23
     198:      	mvni.4s	v24, #0x3f, msl #16
     19c:      	fneg.4s	v24, v24
     1a0:      	lsl	x10, x8, #5
     1a4:      	add	x11, x23, x10
     1a8:      	ldp	q25, q26, [x11]
     1ac:      	fneg.4s	v27, v26
     1b0:      	fneg.4s	v28, v25
     1b4:      	fcmge.4s	v29, v2, v25
     1b8:      	fcmge.4s	v30, v2, v26
     1bc:      	fcmge.4s	v31, v25, v3
     1c0:      	fcmge.4s	v8, v26, v3
     1c4:      	and.16b	v30, v30, v8
     1c8:      	and.16b	v29, v29, v31
     1cc:      	and.16b	v28, v29, v28
     1d0:      	and.16b	v27, v30, v27
     1d4:      	fmul.4s	v29, v27, v4
     1d8:      	fmul.4s	v30, v28, v4
     1dc:      	mov.16b	v31, v6
     1e0:      	bsl.16b	v31, v5, v30
     1e4:      	mov.16b	v8, v6
     1e8:      	bsl.16b	v8, v5, v29
     1ec:      	fadd.4s	v29, v29, v8
     1f0:      	fadd.4s	v30, v30, v31
     1f4:      	fsub.4s	v30, v30, v31
     1f8:      	fsub.4s	v29, v29, v8
     1fc:      	fcvtzs.4s	v29, v29
     200:      	fcvtzs.4s	v30, v30
     204:      	scvtf.4s	v31, v30
     208:      	scvtf.4s	v8, v29
     20c:      	fmul.4s	v9, v8, v7
     210:      	fmul.4s	v10, v31, v7
     214:      	fadd.4s	v28, v28, v10
     218:      	fadd.4s	v27, v27, v9
     21c:      	fmul.4s	v31, v31, v16
     220:      	fmul.4s	v8, v8, v16
     224:      	fadd.4s	v27, v27, v8
     228:      	fadd.4s	v28, v28, v31
     22c:      	fmul.4s	v31, v28, v17
     230:      	fmul.4s	v8, v27, v17
     234:      	fadd.4s	v8, v8, v18
     238:      	fadd.4s	v31, v31, v18
     23c:      	fmul.4s	v31, v28, v31
     240:      	fmul.4s	v8, v27, v8
     244:      	fadd.4s	v8, v8, v19
     248:      	fadd.4s	v31, v31, v19
     24c:      	fmul.4s	v31, v28, v31
     250:      	fmul.4s	v8, v27, v8
     254:      	fadd.4s	v8, v8, v20
     258:      	fadd.4s	v31, v31, v20
     25c:      	fmul.4s	v31, v28, v31
     260:      	fmul.4s	v8, v27, v8
     264:      	fadd.4s	v8, v8, v21
     268:      	fadd.4s	v31, v31, v21
     26c:      	fmul.4s	v31, v28, v31
     270:      	fmul.4s	v8, v27, v8
     274:      	fadd.4s	v8, v8, v22
     278:      	fadd.4s	v31, v31, v22
     27c:      	fmul.4s	v9, v27, v27
     280:      	fmul.4s	v10, v28, v28
     284:      	fmul.4s	v31, v10, v31
     288:      	fmul.4s	v8, v9, v8
     28c:      	fadd.4s	v27, v27, v8
     290:      	fadd.4s	v28, v28, v31
     294:      	sshr.4s	v31, v30, #0x1
     298:      	fadd.4s	v28, v28, v1
     29c:      	sshr.4s	v8, v29, #0x1
     2a0:      	shl.4s	v9, v8, #0x17
     2a4:      	shl.4s	v10, v31, #0x17
     2a8:      	add.4s	v10, v10, v1
     2ac:      	add.4s	v9, v9, v1
     2b0:      	fadd.4s	v27, v27, v1
     2b4:      	fmul.4s	v27, v27, v9
     2b8:      	sub.4s	v29, v29, v8
     2bc:      	sub.4s	v30, v30, v31
     2c0:      	shl.4s	v30, v30, #0x17
     2c4:      	shl.4s	v29, v29, #0x17
     2c8:      	fmul.4s	v28, v28, v10
     2cc:      	add.4s	v29, v29, v1
     2d0:      	add.4s	v30, v30, v1
     2d4:      	fmul.4s	v28, v28, v30
     2d8:      	fmul.4s	v27, v27, v29
     2dc:      	fcmgt.4s	v29, v26, v2
     2e0:      	fcmgt.4s	v30, v25, v2
     2e4:      	fcmgt.4s	v31, v3, v25
     2e8:      	fcmgt.4s	v8, v3, v26
     2ec:      	fcmeq.4s	v9, v26, v26
     2f0:      	fadd.4s	v27, v27, v1
     2f4:      	fadd.4s	v28, v28, v1
     2f8:      	fcmeq.4s	v10, v25, v25
     2fc:      	bit.16b	v28, v1, v30
     300:      	bit.16b	v27, v1, v29
     304:      	bit.16b	v27, v23, v8
     308:      	bit.16b	v28, v23, v31
     30c:      	bif.16b	v28, v24, v10
     310:      	bif.16b	v27, v24, v9
     314:      	fdiv.4s	v26, v26, v27
     318:      	fdiv.4s	v25, v25, v28
     31c:      	add	x11, x22, x10
     320:      	ldp	q28, q27, [x11]
     324:      	fmul.4s	v25, v28, v25
     328:      	fmul.4s	v26, v27, v26
     32c:      	add	x10, x9, x10
     330:      	stp	q25, q26, [x10]
     334:      	add	x8, x8, #0x1
     338:      	cmp	x8, #0xc0
     33c:      	b.ne	0x1a0 <ltmp0+0x1a0>
     340:      	movi.2d	v3, #0000000000000000
     344:      	movi.2d	v2, #0000000000000000
     348:      	ldr	q4, [sp]
     34c:      	mov.d	v2[0], v4[0]
     350:      	fneg.4s	v4, v2
     354:      	mov.d	v3[0], v4[0]
     358:      	mov	w8, #-0x3d300000        ; =-1026555904
     35c:      	dup.4s	v4, w8
     360:      	fcmge.4s	v5, v3, v4
     364:      	mov	w8, #0x42c80000         ; =1120403456
     368:      	dup.4s	v6, w8
     36c:      	fcmge.4s	v7, v6, v3
     370:      	and.16b	v5, v5, v7
     374:      	and.16b	v5, v5, v3
     378:      	mov	w8, #0xaa3b             ; =43579
     37c:      	movk	w8, #0x3fb8, lsl #16
     380:      	dup.4s	v7, w8
     384:      	fmul.4s	v7, v5, v7
     388:      	movi.4s	v16, #0x4b, lsl #24
     38c:      	mvni.4s	v17, #0x80, lsl #24
     390:      	bif.16b	v16, v7, v17
     394:      	fadd.4s	v7, v7, v16
     398:      	fsub.4s	v7, v7, v16
     39c:      	fcvtzs.4s	v7, v7
     3a0:      	scvtf.4s	v16, v7
     3a4:      	mov	w8, #0x7200             ; =29184
     3a8:      	movk	w8, #0xbf31, lsl #16
     3ac:      	dup.4s	v17, w8
     3b0:      	fmul.4s	v17, v16, v17
     3b4:      	mov	w8, #0xbe8e             ; =48782
     3b8:      	movk	w8, #0xb5bf, lsl #16
     3bc:      	dup.4s	v18, w8
     3c0:      	fadd.4s	v5, v5, v17
     3c4:      	fmul.4s	v16, v16, v18
     3c8:      	fadd.4s	v5, v5, v16
     3cc:      	mov	w8, #0x2bda             ; =11226
     3d0:      	movk	w8, #0x3950, lsl #16
     3d4:      	dup.4s	v16, w8
     3d8:      	fmul.4s	v16, v5, v16
     3dc:      	mov	w8, #0x96c9             ; =38601
     3e0:      	movk	w8, #0x3ab6, lsl #16
     3e4:      	dup.4s	v17, w8
     3e8:      	fadd.4s	v16, v16, v17
     3ec:      	fmul.4s	v16, v5, v16
     3f0:      	mov	w8, #0x88a6             ; =34982
     3f4:      	movk	w8, #0x3c08, lsl #16
     3f8:      	dup.4s	v17, w8
     3fc:      	fadd.4s	v16, v16, v17
     400:      	fmul.4s	v16, v5, v16
     404:      	mov	w8, #0xaa7a             ; =43642
     408:      	movk	w8, #0x3d2a, lsl #16
     40c:      	dup.4s	v17, w8
     410:      	fadd.4s	v16, v16, v17
     414:      	mov	w8, #0xaaab             ; =43691
     418:      	movk	w8, #0x3e2a, lsl #16
     41c:      	dup.4s	v17, w8
     420:      	fmul.4s	v16, v5, v16
     424:      	fadd.4s	v16, v16, v17
     428:      	fmul.4s	v16, v5, v16
     42c:      	movi.4s	v17, #0x3f, lsl #24
     430:      	fadd.4s	v16, v16, v17
     434:      	fmul.4s	v17, v5, v5
     438:      	fmul.4s	v16, v17, v16
     43c:      	fadd.4s	v5, v5, v16
     440:      	fadd.4s	v5, v5, v1
     444:      	sshr.4s	v16, v7, #0x1
     448:      	shl.4s	v17, v16, #0x17
     44c:      	add.4s	v17, v17, v1
     450:      	fmul.4s	v5, v5, v17
     454:      	sub.4s	v7, v7, v16
     458:      	shl.4s	v7, v7, #0x17
     45c:      	add.4s	v7, v7, v1
     460:      	fmul.4s	v5, v5, v7
     464:      	fcmgt.4s	v4, v4, v3
     468:      	fcmgt.4s	v6, v3, v6
     46c:      	fcmeq.4s	v3, v3, v3
     470:      	fadd.4s	v5, v5, v1
     474:      	bif.16b	v1, v5, v4
     478:      	mvni.4s	v4, #0x7f, msl #16
     47c:      	fneg.4s	v4, v4
     480:      	bit.16b	v1, v4, v6
     484:      	mvni.4s	v4, #0x3f, msl #16
     488:      	fneg.4s	v4, v4
     48c:      	bif.16b	v1, v4, v3
     490:      	fdiv.4s	v1, v2, v1
     494:      	b	0x848 <ltmp0+0x848>
     498:      	mov	x9, #0x0                ; =0
     49c:      	add	x10, x19, x8
     4a0:      	add	x11, x21, x8
     4a4:      	mov	w12, #0x42d00000        ; =1120927744
     4a8:      	dup.4s	v1, w12
     4ac:      	mov	w12, #-0x3d380000       ; =-1027080192
     4b0:      	dup.4s	v2, w12
     4b4:      	mov	w12, #0xaa3b            ; =43579
     4b8:      	movk	w12, #0x3fb8, lsl #16
     4bc:      	dup.4s	v3, w12
     4c0:      	mov	w12, #0x7200            ; =29184
     4c4:      	movk	w12, #0xbf31, lsl #16
     4c8:      	dup.4s	v4, w12
     4cc:      	mov	w12, #0xbe8e            ; =48782
     4d0:      	movk	w12, #0xb5bf, lsl #16
     4d4:      	dup.4s	v5, w12
     4d8:      	mov	w12, #0x2bda            ; =11226
     4dc:      	movk	w12, #0x3950, lsl #16
     4e0:      	dup.4s	v6, w12
     4e4:      	mov	w12, #0x96c9            ; =38601
     4e8:      	movk	w12, #0x3ab6, lsl #16
     4ec:      	dup.4s	v7, w12
     4f0:      	mov	w12, #0x88a6            ; =34982
     4f4:      	movk	w12, #0x3c08, lsl #16
     4f8:      	dup.4s	v16, w12
     4fc:      	mov	w12, #0xaa7a            ; =43642
     500:      	movk	w12, #0x3d2a, lsl #16
     504:      	dup.4s	v17, w12
     508:      	mov	w12, #0xaaab            ; =43691
     50c:      	movk	w12, #0x3e2a, lsl #16
     510:      	dup.4s	v18, w12
     514:      	add	x12, x22, x8
     518:      	movi.4s	v19, #0x4b, lsl #24
     51c:      	mvni.4s	v20, #0x80, lsl #24
     520:      	movi.4s	v21, #0x3f, lsl #24
     524:      	fmov.4s	v0, #1.00000000
     528:      	mvni.4s	v22, #0x7f, msl #16
     52c:      	fneg.4s	v22, v22
     530:      	mvni.4s	v23, #0x3f, msl #16
     534:      	fneg.4s	v23, v23
     538:      	lsl	x13, x9, #5
     53c:      	add	x14, x12, x13
     540:      	ldp	q24, q25, [x14]
     544:      	fneg.4s	v26, v25
     548:      	fneg.4s	v27, v24
     54c:      	fcmge.4s	v28, v1, v24
     550:      	fcmge.4s	v29, v1, v25
     554:      	fcmge.4s	v30, v24, v2
     558:      	fcmge.4s	v31, v25, v2
     55c:      	and.16b	v29, v29, v31
     560:      	and.16b	v28, v28, v30
     564:      	and.16b	v27, v28, v27
     568:      	and.16b	v26, v29, v26
     56c:      	fmul.4s	v28, v26, v3
     570:      	fmul.4s	v29, v27, v3
     574:      	mov.16b	v30, v20
     578:      	bsl.16b	v30, v19, v29
     57c:      	mov.16b	v31, v20
     580:      	bsl.16b	v31, v19, v28
     584:      	fadd.4s	v28, v28, v31
     588:      	fadd.4s	v29, v29, v30
     58c:      	fsub.4s	v29, v29, v30
     590:      	fsub.4s	v28, v28, v31
     594:      	fcvtzs.4s	v28, v28
     598:      	fcvtzs.4s	v29, v29
     59c:      	scvtf.4s	v30, v29
     5a0:      	scvtf.4s	v31, v28
     5a4:      	fmul.4s	v8, v31, v4
     5a8:      	fmul.4s	v9, v30, v4
     5ac:      	fadd.4s	v27, v27, v9
     5b0:      	fadd.4s	v26, v26, v8
     5b4:      	fmul.4s	v30, v30, v5
     5b8:      	fmul.4s	v31, v31, v5
     5bc:      	fadd.4s	v26, v26, v31
     5c0:      	fadd.4s	v27, v27, v30
     5c4:      	fmul.4s	v30, v27, v6
     5c8:      	fmul.4s	v31, v26, v6
     5cc:      	fadd.4s	v31, v31, v7
     5d0:      	fadd.4s	v30, v30, v7
     5d4:      	fmul.4s	v30, v27, v30
     5d8:      	fmul.4s	v31, v26, v31
     5dc:      	fadd.4s	v31, v31, v16
     5e0:      	fadd.4s	v30, v30, v16
     5e4:      	fmul.4s	v30, v27, v30
     5e8:      	fmul.4s	v31, v26, v31
     5ec:      	fadd.4s	v31, v31, v17
     5f0:      	fadd.4s	v30, v30, v17
     5f4:      	fmul.4s	v30, v27, v30
     5f8:      	fmul.4s	v31, v26, v31
     5fc:      	fadd.4s	v31, v31, v18
     600:      	fadd.4s	v30, v30, v18
     604:      	fmul.4s	v30, v27, v30
     608:      	fmul.4s	v31, v26, v31
     60c:      	fadd.4s	v31, v31, v21
     610:      	fadd.4s	v30, v30, v21
     614:      	fmul.4s	v8, v26, v26
     618:      	fmul.4s	v9, v27, v27
     61c:      	fmul.4s	v30, v9, v30
     620:      	fmul.4s	v31, v8, v31
     624:      	fadd.4s	v26, v26, v31
     628:      	fadd.4s	v27, v27, v30
     62c:      	sshr.4s	v30, v29, #0x1
     630:      	fadd.4s	v27, v27, v0
     634:      	sshr.4s	v31, v28, #0x1
     638:      	shl.4s	v8, v31, #0x17
     63c:      	shl.4s	v9, v30, #0x17
     640:      	add.4s	v9, v9, v0
     644:      	add.4s	v8, v8, v0
     648:      	fadd.4s	v26, v26, v0
     64c:      	fmul.4s	v26, v26, v8
     650:      	sub.4s	v28, v28, v31
     654:      	sub.4s	v29, v29, v30
     658:      	shl.4s	v29, v29, #0x17
     65c:      	shl.4s	v28, v28, #0x17
     660:      	fmul.4s	v27, v27, v9
     664:      	add.4s	v28, v28, v0
     668:      	add.4s	v29, v29, v0
     66c:      	fmul.4s	v27, v27, v29
     670:      	fmul.4s	v26, v26, v28
     674:      	fcmgt.4s	v28, v25, v1
     678:      	fcmgt.4s	v29, v24, v1
     67c:      	fcmgt.4s	v30, v2, v24
     680:      	fcmgt.4s	v31, v2, v25
     684:      	fcmeq.4s	v8, v25, v25
     688:      	fadd.4s	v26, v26, v0
     68c:      	fadd.4s	v27, v27, v0
     690:      	fcmeq.4s	v9, v24, v24
     694:      	bit.16b	v27, v0, v29
     698:      	bit.16b	v26, v0, v28
     69c:      	bit.16b	v26, v22, v31
     6a0:      	bit.16b	v27, v22, v30
     6a4:      	bif.16b	v27, v23, v9
     6a8:      	bif.16b	v26, v23, v8
     6ac:      	fdiv.4s	v25, v25, v26
     6b0:      	fdiv.4s	v24, v24, v27
     6b4:      	add	x14, x11, x13
     6b8:      	ldp	q27, q26, [x14]
     6bc:      	fmul.4s	v24, v27, v24
     6c0:      	fmul.4s	v25, v26, v25
     6c4:      	add	x13, x10, x13
     6c8:      	stp	q24, q25, [x13]
     6cc:      	add	x9, x9, #0x1
     6d0:      	cmp	x9, #0xc0
     6d4:      	b.ne	0x538 <ltmp0+0x538>
     6d8:      	mov	w9, #0x1800             ; =6144
     6dc:      	add	x20, x8, x9
     6e0:      	add	x8, x22, x20
     6e4:      	movi.2d	v2, #0000000000000000
     6e8:      	movi.2d	v1, #0000000000000000
     6ec:      	ld1.s	{ v1 }[0], [x8], #4
     6f0:      	ld1.s	{ v1 }[1], [x8]
     6f4:      	fneg.4s	v3, v1
     6f8:      	mov.d	v2[0], v3[0]
     6fc:      	mov	w8, #-0x3d300000        ; =-1026555904
     700:      	dup.4s	v3, w8
     704:      	fcmge.4s	v4, v2, v3
     708:      	mov	w8, #0x42c80000         ; =1120403456
     70c:      	dup.4s	v5, w8
     710:      	fcmge.4s	v6, v5, v2
     714:      	and.16b	v4, v4, v6
     718:      	and.16b	v4, v4, v2
     71c:      	mov	w8, #0xaa3b             ; =43579
     720:      	movk	w8, #0x3fb8, lsl #16
     724:      	dup.4s	v6, w8
     728:      	fmul.4s	v6, v4, v6
     72c:      	movi.4s	v7, #0x4b, lsl #24
     730:      	mvni.4s	v16, #0x80, lsl #24
     734:      	bif.16b	v7, v6, v16
     738:      	fadd.4s	v6, v6, v7
     73c:      	fsub.4s	v6, v6, v7
     740:      	fcvtzs.4s	v6, v6
     744:      	scvtf.4s	v7, v6
     748:      	mov	w8, #0x7200             ; =29184
     74c:      	movk	w8, #0xbf31, lsl #16
     750:      	dup.4s	v16, w8
     754:      	fmul.4s	v16, v7, v16
     758:      	fadd.4s	v4, v4, v16
     75c:      	mov	w8, #0xbe8e             ; =48782
     760:      	movk	w8, #0xb5bf, lsl #16
     764:      	dup.4s	v16, w8
     768:      	fmul.4s	v7, v7, v16
     76c:      	mov	w8, #0x2bda             ; =11226
     770:      	movk	w8, #0x3950, lsl #16
     774:      	dup.4s	v16, w8
     778:      	fadd.4s	v4, v4, v7
     77c:      	fmul.4s	v7, v4, v16
     780:      	mov	w8, #0x96c9             ; =38601
     784:      	movk	w8, #0x3ab6, lsl #16
     788:      	dup.4s	v16, w8
     78c:      	fadd.4s	v7, v7, v16
     790:      	fmul.4s	v7, v4, v7
     794:      	mov	w8, #0x88a6             ; =34982
     798:      	movk	w8, #0x3c08, lsl #16
     79c:      	dup.4s	v16, w8
     7a0:      	fadd.4s	v7, v7, v16
     7a4:      	fmul.4s	v7, v4, v7
     7a8:      	mov	w8, #0xaa7a             ; =43642
     7ac:      	movk	w8, #0x3d2a, lsl #16
     7b0:      	dup.4s	v16, w8
     7b4:      	fadd.4s	v7, v7, v16
     7b8:      	fmul.4s	v7, v4, v7
     7bc:      	mov	w8, #0xaaab             ; =43691
     7c0:      	movk	w8, #0x3e2a, lsl #16
     7c4:      	dup.4s	v16, w8
     7c8:      	fadd.4s	v7, v7, v16
     7cc:      	fmul.4s	v7, v4, v7
     7d0:      	movi.4s	v16, #0x3f, lsl #24
     7d4:      	fadd.4s	v7, v7, v16
     7d8:      	fmul.4s	v16, v4, v4
     7dc:      	fmul.4s	v7, v16, v7
     7e0:      	fadd.4s	v4, v4, v7
     7e4:      	fadd.4s	v4, v4, v0
     7e8:      	sshr.4s	v7, v6, #0x1
     7ec:      	shl.4s	v16, v7, #0x17
     7f0:      	add.4s	v16, v16, v0
     7f4:      	fmul.4s	v4, v4, v16
     7f8:      	sub.4s	v6, v6, v7
     7fc:      	shl.4s	v6, v6, #0x17
     800:      	add.4s	v6, v6, v0
     804:      	fmul.4s	v4, v4, v6
     808:      	fcmgt.4s	v3, v3, v2
     80c:      	fcmgt.4s	v5, v2, v5
     810:      	fcmeq.4s	v2, v2, v2
     814:      	fadd.4s	v4, v4, v0
     818:      	bif.16b	v0, v4, v3
     81c:      	mvni.4s	v3, #0x7f, msl #16
     820:      	fneg.4s	v3, v3
     824:      	bit.16b	v0, v3, v5
     828:      	mvni.4s	v3, #0x3f, msl #16
     82c:      	fneg.4s	v3, v3
     830:      	bif.16b	v0, v3, v2
     834:      	fdiv.4s	v0, v1, v0
     838:      	add	x8, x21, x20
     83c:      	add	x9, x8, #0x4
     840:      	ldr	s1, [x8]
     844:      	ld1.s	{ v1 }[1], [x9]
     848:      	fmul.4s	v0, v1, v0
     84c:      	str	d0, [x19, x20]
     850:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
     854:      	add	sp, sp, #0x50
     858:      	ldp	x29, x30, [sp, #0x60]
     85c:      	ldp	x20, x19, [sp, #0x50]
     860:      	ldp	x22, x21, [sp, #0x40]
     864:      	ldp	x24, x23, [sp, #0x30]
     868:      	ldp	x26, x25, [sp, #0x20]
     86c:      	ldp	d9, d8, [sp, #0x10]
     870:      	ldp	d11, d10, [sp], #0x70
     874:      	ret

0000000000000878 <_llm_rows.packet_batch.blocks>:
     878:      	stp	d15, d14, [sp, #-0xa0]!
     87c:      	stp	d13, d12, [sp, #0x10]
     880:      	stp	d11, d10, [sp, #0x20]
     884:      	stp	d9, d8, [sp, #0x30]
     888:      	stp	x28, x27, [sp, #0x40]
     88c:      	stp	x26, x25, [sp, #0x50]
     890:      	stp	x24, x23, [sp, #0x60]
     894:      	stp	x22, x21, [sp, #0x70]
     898:      	stp	x20, x19, [sp, #0x80]
     89c:      	stp	x29, x30, [sp, #0x90]
     8a0:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
     8a4:      	sub	sp, sp, #0x2d0
     8a8:      	str	x0, [sp, #0xe8]
     8ac:      	cbz	w3, 0x1cd8 <_llm_rows.packet_batch.blocks+0x1460>
     8b0:      	mov	x19, x3
     8b4:      	mov	x20, x2
     8b8:      	mov	w22, #0x0               ; =0
     8bc:      	ldp	w9, w8, [x2, #0x2c]
     8c0:      	stp	w8, w9, [sp, #0xe0]
     8c4:      	ldp	w27, w25, [x2]
     8c8:      	adrp	x8, 0x0 <ltmp0>
     8cc:      	ldr	q0, [x8]
     8d0:      	str	q0, [sp, #0xb0]
     8d4:      	adrp	x8, 0x0 <ltmp0>
     8d8:      	ldr	q0, [x8]
     8dc:      	str	q0, [sp, #0xa0]
     8e0:      	adrp	x8, 0x0 <ltmp0>
     8e4:      	ldr	q0, [x8]
     8e8:      	str	q0, [sp, #0x90]
     8ec:      	adrp	x8, 0x0 <ltmp0>
     8f0:      	ldr	q0, [x8]
     8f4:      	str	q0, [sp, #0x80]
     8f8:      	adrp	x8, 0x0 <ltmp0>
     8fc:      	ldr	q0, [x8]
     900:      	str	q0, [sp, #0x70]
     904:      	adrp	x8, 0x0 <ltmp0>
     908:      	ldr	q0, [x8]
     90c:      	str	q0, [sp, #0x60]
     910:      	adrp	x8, 0x0 <ltmp0>
     914:      	ldr	q1, [x8]
     918:      	mvni.4s	v0, #0x7f, msl #16
     91c:      	fneg.4s	v0, v0
     920:      	str	q0, [sp, #0x110]
     924:      	mvni.4s	v0, #0x3f, msl #16
     928:      	fneg.4s	v0, v0
     92c:      	stp	q1, q0, [sp, #0xf0]
     930:      	add	x26, sp, #0x1, lsl #12  ; =0x1000
     934:      	add	x26, x26, #0xab0
     938:      	ldp	w28, w23, [x2, #0x8]
     93c:      	add	x24, sp, #0x290
     940:      	str	w3, [sp, #0xdc]
     944:      	b	0x98c <_llm_rows.packet_batch.blocks+0x114>
     948:      	mov	w8, #0x18               ; =24
     94c:      	str	w8, [x20, #0x24]
     950:      	ldr	w19, [sp, #0xdc]
     954:      	add	w8, w27, #0x1
     958:      	ldp	w10, w9, [sp, #0xe0]
     95c:      	cmp	w8, w9
     960:      	cset	w8, eq
     964:      	csinc	w27, wzr, w27, eq
     968:      	cinc	w9, w25, eq
     96c:      	cmp	w9, w10
     970:      	cset	w10, eq
     974:      	ands	w8, w8, w10
     978:      	csel	w25, wzr, w9, ne
     97c:      	add	w28, w28, w8
     980:      	add	w22, w22, #0x1
     984:      	cmp	w22, w19
     988:      	b.eq	0x1cd8 <_llm_rows.packet_batch.blocks+0x1460>
     98c:      	ubfiz	x8, x27, #5, #32
     990:      	cmp	x8, x23
     994:      	csel	x9, x8, xzr, ls
     998:      	subs	x10, x23, x9
     99c:      	cmp	x10, #0x20
     9a0:      	mov	w11, #0x20              ; =32
     9a4:      	csel	x10, x10, x11, lo
     9a8:      	cmp	x23, x9
     9ac:      	stp	w27, w25, [x20]
     9b0:      	str	w28, [x20, #0x8]
     9b4:      	str	wzr, [x20, #0x24]
     9b8:      	ccmp	x8, x23, #0x2, hi
     9bc:      	csel	x21, x10, xzr, ls
     9c0:      	cmp	x21, #0x20
     9c4:      	b.lo	0xa18 <_llm_rows.packet_batch.blocks+0x1a0>
     9c8:      	ldr	x21, [sp, #0xe8]
     9cc:      	mov	x0, x21
     9d0:      	mov	x1, x20
     9d4:      	bl	0x9d4 <_llm_rows.packet_batch.blocks+0x15c>
     9d8:      	mov	w8, #0x8                ; =8
     9dc:      	str	w8, [x20, #0x24]
     9e0:      	mov	x0, x21
     9e4:      	mov	x1, x20
     9e8:      	bl	0x9e8 <_llm_rows.packet_batch.blocks+0x170>
     9ec:      	mov	w8, #0x10               ; =16
     9f0:      	str	w8, [x20, #0x24]
     9f4:      	mov	x0, x21
     9f8:      	mov	x1, x20
     9fc:      	bl	0x9fc <_llm_rows.packet_batch.blocks+0x184>
     a00:      	mov	w8, #0x18               ; =24
     a04:      	str	w8, [x20, #0x24]
     a08:      	mov	x0, x21
     a0c:      	mov	x1, x20
     a10:      	bl	0xa10 <_llm_rows.packet_batch.blocks+0x198>
     a14:      	b	0x954 <_llm_rows.packet_batch.blocks+0xdc>
     a18:      	lsr	x19, x21, #3
     a1c:      	cmp	x21, #0x8
     a20:      	b.lo	0xa6c <_llm_rows.packet_batch.blocks+0x1f4>
     a24:      	str	wzr, [x20, #0x24]
     a28:      	ldr	x0, [sp, #0xe8]
     a2c:      	mov	x1, x20
     a30:      	bl	0xa30 <_llm_rows.packet_batch.blocks+0x1b8>
     a34:      	cmp	x19, #0x1
     a38:      	b.eq	0xa6c <_llm_rows.packet_batch.blocks+0x1f4>
     a3c:      	mov	w8, #0x8                ; =8
     a40:      	str	w8, [x20, #0x24]
     a44:      	ldr	x0, [sp, #0xe8]
     a48:      	mov	x1, x20
     a4c:      	bl	0xa4c <_llm_rows.packet_batch.blocks+0x1d4>
     a50:      	cmp	x19, #0x2
     a54:      	b.eq	0xa6c <_llm_rows.packet_batch.blocks+0x1f4>
     a58:      	mov	w8, #0x10               ; =16
     a5c:      	str	w8, [x20, #0x24]
     a60:      	ldr	x0, [sp, #0xe8]
     a64:      	mov	x1, x20
     a68:      	bl	0xa68 <_llm_rows.packet_batch.blocks+0x1f0>
     a6c:      	and	w8, w21, #0x7
     a70:      	cbz	w8, 0x948 <_llm_rows.packet_batch.blocks+0xd0>
     a74:      	dup.4s	v0, w8
     a78:      	ldp	q2, q1, [sp, #0xa0]
     a7c:      	cmhi.4s	v19, v0, v2
     a80:      	cmhi.4s	v20, v0, v1
     a84:      	uzp1.8h	v29, v20, v19
     a88:      	umaxv.8h	h0, v29
     a8c:      	fmov	w8, s0
     a90:      	tbz	w8, #0x0, 0x948 <_llm_rows.packet_batch.blocks+0xd0>
     a94:      	ldr	x8, [sp, #0xe8]
     a98:      	ldr	x11, [x8]
     a9c:      	ldr	x9, [x8, #0x10]
     aa0:      	ldr	x8, [x8, #0x30]
     aa4:      	sshll.2d	v0, v20, #0x0
     aa8:      	sshll.2d	v1, v19, #0x0
     aac:      	sshll2.2d	v12, v20, #0x0
     ab0:      	sshll2.2d	v11, v19, #0x0
     ab4:      	ldp	q2, q3, [sp, #0x80]
     ab8:      	and.16b	v21, v11, v3
     abc:      	and.16b	v23, v12, v2
     ac0:      	ldr	q2, [sp, #0x70]
     ac4:      	and.16b	v22, v1, v2
     ac8:      	ldr	q1, [sp, #0x60]
     acc:      	and.16b	v30, v0, v1
     ad0:      	ubfiz	w10, w27, #2, #27
     ad4:      	orr	w10, w10, w19
     ad8:      	dup.4s	v0, w10
     adc:      	and.16b	v1, v20, v0
     ae0:      	and.16b	v0, v19, v0
     ae4:      	ushll2.2d	v24, v0, #0x0
     ae8:      	ushll2.2d	v27, v1, #0x0
     aec:      	ushll.2d	v25, v0, #0x0
     af0:      	ushll.2d	v0, v1, #0x0
     af4:      	subs	x10, x11, x8
     af8:      	mov	w14, #0x2007            ; =8199
     afc:      	movk	w14, #0x18, lsl #16
     b00:      	ccmp	x10, x14, #0x0, hs
     b04:      	cset	w10, hi
     b08:      	subs	x12, x8, x11
     b0c:      	ccmp	x12, x14, #0x0, hs
     b10:      	csinc	w12, w10, wzr, ls
     b14:      	subs	x10, x9, x8
     b18:      	ccmp	x10, x14, #0x0, hs
     b1c:      	cset	w10, hi
     b20:      	subs	x13, x8, x9
     b24:      	ccmp	x13, x14, #0x0, hs
     b28:      	csinc	w10, w10, wzr, ls
     b2c:      	xtn.2s	v31, v0
     b30:      	fmov	x13, d0
     b34:      	mov	w14, #-0x3d300000       ; =-1026555904
     b38:      	dup.4s	v1, w14
     b3c:      	mov	w14, #0x42c80000        ; =1120403456
     b40:      	dup.4s	v0, w14
     b44:      	mov	w14, #0xaa3b            ; =43579
     b48:      	movk	w14, #0x3fb8, lsl #16
     b4c:      	dup.4s	v18, w14
     b50:      	mov	w14, #0x7200            ; =29184
     b54:      	movk	w14, #0xbf31, lsl #16
     b58:      	dup.4s	v17, w14
     b5c:      	mov	w14, #0xbe8e            ; =48782
     b60:      	movk	w14, #0xb5bf, lsl #16
     b64:      	dup.4s	v16, w14
     b68:      	mov	w14, #0x2bda            ; =11226
     b6c:      	movk	w14, #0x3950, lsl #16
     b70:      	dup.4s	v7, w14
     b74:      	mov	w14, #0x96c9            ; =38601
     b78:      	movk	w14, #0x3ab6, lsl #16
     b7c:      	dup.4s	v6, w14
     b80:      	mov	w14, #0x88a6            ; =34982
     b84:      	movk	w14, #0x3c08, lsl #16
     b88:      	dup.4s	v5, w14
     b8c:      	mov	w14, #0x1808            ; =6152
     b90:      	umull	x14, w13, w14
     b94:      	mov	w13, #0xaa7a            ; =43642
     b98:      	movk	w13, #0x3d2a, lsl #16
     b9c:      	dup.4s	v4, w13
     ba0:      	mov	w13, #0xaaab            ; =43691
     ba4:      	movk	w13, #0x3e2a, lsl #16
     ba8:      	dup.4s	v3, w13
     bac:      	fmov.4s	v2, #1.00000000
     bb0:      	xtn.2s	v24, v24
     bb4:      	str	d24, [sp, #0xc0]
     bb8:      	xtn.2s	v26, v25
     bbc:      	mov	w13, #0x602             ; =1538
     bc0:      	dup.2s	v25, w13
     bc4:      	xtn.2s	v27, v27
     bc8:      	cmp	w12, #0x1
     bcc:      	b.ne	0xf64 <_llm_rows.packet_batch.blocks+0x6ec>
     bd0:      	cbz	w10, 0xf64 <_llm_rows.packet_batch.blocks+0x6ec>
     bd4:      	mov	x10, #0x0               ; =0
     bd8:      	add	x12, x8, x14
     bdc:      	add	x13, x9, x14
     be0:      	add	x14, x11, x14
     be4:      	ldr	q24, [sp, #0xf0]
     be8:      	and.16b	v28, v29, v24
     bec:      	addv.8h	h28, v28
     bf0:      	fmov	w15, s28
     bf4:      	b	0xc04 <_llm_rows.packet_batch.blocks+0x38c>
     bf8:      	add	x10, x10, #0x1
     bfc:      	cmp	x10, #0xc0
     c00:      	b.eq	0x18d0 <_llm_rows.packet_batch.blocks+0x1058>
     c04:      	add	x16, x14, x10, lsl #5
     c08:      	movi.2d	v10, #0000000000000000
     c0c:      	movi.2d	v9, #0000000000000000
     c10:      	tbz	w15, #0x0, 0xca4 <_llm_rows.packet_batch.blocks+0x42c>
     c14:      	ldr	s10, [x16]
     c18:      	and	w17, w15, #0xff
     c1c:      	tbnz	w17, #0x1, 0xcac <_llm_rows.packet_batch.blocks+0x434>
     c20:      	tbz	w17, #0x2, 0xcb8 <_llm_rows.packet_batch.blocks+0x440>
     c24:      	add	x0, x16, #0x8
     c28:      	ld1.s	{ v10 }[2], [x0]
     c2c:      	tbnz	w17, #0x3, 0xcbc <_llm_rows.packet_batch.blocks+0x444>
     c30:      	tbz	w17, #0x4, 0xcc8 <_llm_rows.packet_batch.blocks+0x450>
     c34:      	add	x0, x16, #0x10
     c38:      	ld1.s	{ v9 }[0], [x0]
     c3c:      	tbnz	w17, #0x5, 0xccc <_llm_rows.packet_batch.blocks+0x454>
     c40:      	tbz	w17, #0x6, 0xcd8 <_llm_rows.packet_batch.blocks+0x460>
     c44:      	add	x0, x16, #0x18
     c48:      	ld1.s	{ v9 }[2], [x0]
     c4c:      	tbnz	w17, #0x7, 0xcdc <_llm_rows.packet_batch.blocks+0x464>
     c50:      	fmov	w17, s28
     c54:      	add	x16, x13, x10, lsl #5
     c58:      	movi.2d	v8, #0000000000000000
     c5c:      	movi.2d	v11, #0000000000000000
     c60:      	tbz	w17, #0x0, 0xcf8 <_llm_rows.packet_batch.blocks+0x480>
     c64:      	ldr	s8, [x16]
     c68:      	and	w17, w17, #0xff
     c6c:      	tbnz	w17, #0x1, 0xd00 <_llm_rows.packet_batch.blocks+0x488>
     c70:      	tbz	w17, #0x2, 0xd0c <_llm_rows.packet_batch.blocks+0x494>
     c74:      	add	x0, x16, #0x8
     c78:      	ld1.s	{ v8 }[2], [x0]
     c7c:      	tbnz	w17, #0x3, 0xd10 <_llm_rows.packet_batch.blocks+0x498>
     c80:      	tbz	w17, #0x4, 0xd1c <_llm_rows.packet_batch.blocks+0x4a4>
     c84:      	add	x0, x16, #0x10
     c88:      	ld1.s	{ v11 }[0], [x0]
     c8c:      	tbnz	w17, #0x5, 0xd20 <_llm_rows.packet_batch.blocks+0x4a8>
     c90:      	tbz	w17, #0x6, 0xd2c <_llm_rows.packet_batch.blocks+0x4b4>
     c94:      	add	x0, x16, #0x18
     c98:      	ld1.s	{ v11 }[2], [x0]
     c9c:      	tbnz	w17, #0x7, 0xd30 <_llm_rows.packet_batch.blocks+0x4b8>
     ca0:      	b	0xd38 <_llm_rows.packet_batch.blocks+0x4c0>
     ca4:      	and	w17, w15, #0xff
     ca8:      	tbz	w17, #0x1, 0xc20 <_llm_rows.packet_batch.blocks+0x3a8>
     cac:      	add	x0, x16, #0x4
     cb0:      	ld1.s	{ v10 }[1], [x0]
     cb4:      	tbnz	w17, #0x2, 0xc24 <_llm_rows.packet_batch.blocks+0x3ac>
     cb8:      	tbz	w17, #0x3, 0xc30 <_llm_rows.packet_batch.blocks+0x3b8>
     cbc:      	add	x0, x16, #0xc
     cc0:      	ld1.s	{ v10 }[3], [x0]
     cc4:      	tbnz	w17, #0x4, 0xc34 <_llm_rows.packet_batch.blocks+0x3bc>
     cc8:      	tbz	w17, #0x5, 0xc40 <_llm_rows.packet_batch.blocks+0x3c8>
     ccc:      	add	x0, x16, #0x14
     cd0:      	ld1.s	{ v9 }[1], [x0]
     cd4:      	tbnz	w17, #0x6, 0xc44 <_llm_rows.packet_batch.blocks+0x3cc>
     cd8:      	tbz	w17, #0x7, 0xc50 <_llm_rows.packet_batch.blocks+0x3d8>
     cdc:      	add	x16, x16, #0x1c
     ce0:      	ld1.s	{ v9 }[3], [x16]
     ce4:      	fmov	w17, s28
     ce8:      	add	x16, x13, x10, lsl #5
     cec:      	movi.2d	v8, #0000000000000000
     cf0:      	movi.2d	v11, #0000000000000000
     cf4:      	tbnz	w17, #0x0, 0xc64 <_llm_rows.packet_batch.blocks+0x3ec>
     cf8:      	and	w17, w17, #0xff
     cfc:      	tbz	w17, #0x1, 0xc70 <_llm_rows.packet_batch.blocks+0x3f8>
     d00:      	add	x0, x16, #0x4
     d04:      	ld1.s	{ v8 }[1], [x0]
     d08:      	tbnz	w17, #0x2, 0xc74 <_llm_rows.packet_batch.blocks+0x3fc>
     d0c:      	tbz	w17, #0x3, 0xc80 <_llm_rows.packet_batch.blocks+0x408>
     d10:      	add	x0, x16, #0xc
     d14:      	ld1.s	{ v8 }[3], [x0]
     d18:      	tbnz	w17, #0x4, 0xc84 <_llm_rows.packet_batch.blocks+0x40c>
     d1c:      	tbz	w17, #0x5, 0xc90 <_llm_rows.packet_batch.blocks+0x418>
     d20:      	add	x0, x16, #0x14
     d24:      	ld1.s	{ v11 }[1], [x0]
     d28:      	tbnz	w17, #0x6, 0xc94 <_llm_rows.packet_batch.blocks+0x41c>
     d2c:      	tbz	w17, #0x7, 0xd38 <_llm_rows.packet_batch.blocks+0x4c0>
     d30:      	add	x16, x16, #0x1c
     d34:      	ld1.s	{ v11 }[3], [x16]
     d38:      	fneg.4s	v12, v10
     d3c:      	and.16b	v12, v20, v12
     d40:      	fcmge.4s	v13, v12, v1
     d44:      	fcmge.4s	v14, v0, v12
     d48:      	and.16b	v13, v13, v14
     d4c:      	and.16b	v13, v13, v12
     d50:      	fmul.4s	v14, v13, v18
     d54:      	movi.4s	v24, #0x4b, lsl #24
     d58:      	mvni.4s	v15, #0x80, lsl #24
     d5c:      	bsl.16b	v15, v24, v14
     d60:      	fadd.4s	v14, v14, v15
     d64:      	fsub.4s	v14, v14, v15
     d68:      	fcvtzs.4s	v14, v14
     d6c:      	scvtf.4s	v15, v14
     d70:      	fmul.4s	v24, v15, v17
     d74:      	fadd.4s	v24, v13, v24
     d78:      	fmul.4s	v13, v15, v16
     d7c:      	fadd.4s	v24, v24, v13
     d80:      	fmul.4s	v13, v24, v7
     d84:      	fadd.4s	v13, v13, v6
     d88:      	fmul.4s	v13, v24, v13
     d8c:      	fadd.4s	v13, v13, v5
     d90:      	fmul.4s	v13, v24, v13
     d94:      	fadd.4s	v13, v13, v4
     d98:      	fmul.4s	v13, v24, v13
     d9c:      	fadd.4s	v13, v13, v3
     da0:      	fmul.4s	v13, v24, v13
     da4:      	movi.4s	v15, #0x3f, lsl #24
     da8:      	fadd.4s	v13, v13, v15
     dac:      	fmul.4s	v15, v24, v24
     db0:      	fmul.4s	v13, v15, v13
     db4:      	fadd.4s	v24, v24, v13
     db8:      	fadd.4s	v24, v24, v2
     dbc:      	sshr.4s	v13, v14, #0x1
     dc0:      	shl.4s	v15, v13, #0x17
     dc4:      	add.4s	v15, v15, v2
     dc8:      	fmul.4s	v24, v24, v15
     dcc:      	sub.4s	v13, v14, v13
     dd0:      	shl.4s	v13, v13, #0x17
     dd4:      	add.4s	v13, v13, v2
     dd8:      	fmul.4s	v24, v24, v13
     ddc:      	fcmgt.4s	v13, v1, v12
     de0:      	fcmgt.4s	v14, v12, v0
     de4:      	fcmeq.4s	v12, v12, v12
     de8:      	fadd.4s	v24, v24, v2
     dec:      	bit.16b	v24, v2, v13
     df0:      	ldr	q13, [sp, #0x110]
     df4:      	bit.16b	v24, v13, v14
     df8:      	ldr	q13, [sp, #0x100]
     dfc:      	bif.16b	v24, v13, v12
     e00:      	fdiv.4s	v24, v10, v24
     e04:      	fmov	w17, s28
     e08:      	fmul.4s	v8, v8, v24
     e0c:      	add	x16, x12, x10, lsl #5
     e10:      	tbz	w17, #0x0, 0xe34 <_llm_rows.packet_batch.blocks+0x5bc>
     e14:      	str	s8, [x16]
     e18:      	and	w17, w17, #0xff
     e1c:      	tbnz	w17, #0x1, 0xe3c <_llm_rows.packet_batch.blocks+0x5c4>
     e20:      	tbz	w17, #0x2, 0xe48 <_llm_rows.packet_batch.blocks+0x5d0>
     e24:      	add	x0, x16, #0x8
     e28:      	st1.s	{ v8 }[2], [x0]
     e2c:      	tbnz	w17, #0x3, 0xe4c <_llm_rows.packet_batch.blocks+0x5d4>
     e30:      	b	0xe54 <_llm_rows.packet_batch.blocks+0x5dc>
     e34:      	and	w17, w17, #0xff
     e38:      	tbz	w17, #0x1, 0xe20 <_llm_rows.packet_batch.blocks+0x5a8>
     e3c:      	add	x0, x16, #0x4
     e40:      	st1.s	{ v8 }[1], [x0]
     e44:      	tbnz	w17, #0x2, 0xe24 <_llm_rows.packet_batch.blocks+0x5ac>
     e48:      	tbz	w17, #0x3, 0xe54 <_llm_rows.packet_batch.blocks+0x5dc>
     e4c:      	add	x0, x16, #0xc
     e50:      	st1.s	{ v8 }[3], [x0]
     e54:      	fneg.4s	v24, v9
     e58:      	and.16b	v24, v19, v24
     e5c:      	fcmge.4s	v8, v24, v1
     e60:      	fcmge.4s	v10, v0, v24
     e64:      	and.16b	v8, v8, v10
     e68:      	and.16b	v8, v8, v24
     e6c:      	fmul.4s	v10, v8, v18
     e70:      	movi.4s	v12, #0x4b, lsl #24
     e74:      	mvni.4s	v13, #0x80, lsl #24
     e78:      	bif.16b	v12, v10, v13
     e7c:      	fadd.4s	v10, v10, v12
     e80:      	fsub.4s	v10, v10, v12
     e84:      	fcvtzs.4s	v10, v10
     e88:      	scvtf.4s	v12, v10
     e8c:      	fmul.4s	v13, v12, v17
     e90:      	fadd.4s	v8, v8, v13
     e94:      	fmul.4s	v12, v12, v16
     e98:      	fadd.4s	v8, v8, v12
     e9c:      	fmul.4s	v12, v8, v7
     ea0:      	fadd.4s	v12, v12, v6
     ea4:      	fmul.4s	v12, v8, v12
     ea8:      	fadd.4s	v12, v12, v5
     eac:      	fmul.4s	v12, v8, v12
     eb0:      	fadd.4s	v12, v12, v4
     eb4:      	fmul.4s	v12, v8, v12
     eb8:      	fadd.4s	v12, v12, v3
     ebc:      	fmul.4s	v12, v8, v12
     ec0:      	movi.4s	v13, #0x3f, lsl #24
     ec4:      	fadd.4s	v12, v12, v13
     ec8:      	fmul.4s	v13, v8, v8
     ecc:      	fmul.4s	v12, v13, v12
     ed0:      	fadd.4s	v8, v8, v12
     ed4:      	fadd.4s	v8, v8, v2
     ed8:      	sshr.4s	v12, v10, #0x1
     edc:      	shl.4s	v13, v12, #0x17
     ee0:      	add.4s	v13, v13, v2
     ee4:      	fmul.4s	v8, v8, v13
     ee8:      	sub.4s	v10, v10, v12
     eec:      	shl.4s	v10, v10, #0x17
     ef0:      	add.4s	v10, v10, v2
     ef4:      	fmul.4s	v8, v8, v10
     ef8:      	fcmgt.4s	v10, v1, v24
     efc:      	fcmgt.4s	v12, v24, v0
     f00:      	fcmeq.4s	v24, v24, v24
     f04:      	fadd.4s	v8, v8, v2
     f08:      	bit.16b	v8, v2, v10
     f0c:      	ldr	q10, [sp, #0x110]
     f10:      	bit.16b	v8, v10, v12
     f14:      	ldr	q10, [sp, #0x100]
     f18:      	bsl.16b	v24, v8, v10
     f1c:      	fdiv.4s	v24, v9, v24
     f20:      	fmul.4s	v8, v11, v24
     f24:      	tbz	w17, #0x4, 0xf44 <_llm_rows.packet_batch.blocks+0x6cc>
     f28:      	str	s8, [x16, #0x10]
     f2c:      	tbnz	w17, #0x5, 0xf48 <_llm_rows.packet_batch.blocks+0x6d0>
     f30:      	tbz	w17, #0x6, 0xf54 <_llm_rows.packet_batch.blocks+0x6dc>
     f34:      	add	x0, x16, #0x18
     f38:      	st1.s	{ v8 }[2], [x0]
     f3c:      	tbz	w17, #0x7, 0xbf8 <_llm_rows.packet_batch.blocks+0x380>
     f40:      	b	0xf58 <_llm_rows.packet_batch.blocks+0x6e0>
     f44:      	tbz	w17, #0x5, 0xf30 <_llm_rows.packet_batch.blocks+0x6b8>
     f48:      	add	x0, x16, #0x14
     f4c:      	st1.s	{ v8 }[1], [x0]
     f50:      	tbnz	w17, #0x6, 0xf34 <_llm_rows.packet_batch.blocks+0x6bc>
     f54:      	tbz	w17, #0x7, 0xbf8 <_llm_rows.packet_batch.blocks+0x380>
     f58:      	add	x16, x16, #0x1c
     f5c:      	st1.s	{ v8 }[3], [x16]
     f60:      	b	0xbf8 <_llm_rows.packet_batch.blocks+0x380>
     f64:      	mov	x10, #0x0               ; =0
     f68:      	add	x12, x11, x14
     f6c:      	b	0xf90 <_llm_rows.packet_batch.blocks+0x718>
     f70:      	add	x13, x26, x10, lsl #5
     f74:      	ldp	q24, q10, [x13]
     f78:      	bif.16b	v9, v10, v19
     f7c:      	bit.16b	v24, v8, v20
     f80:      	stp	q24, q9, [x13]
     f84:      	add	x10, x10, #0x1
     f88:      	cmp	x10, #0xc0
     f8c:      	b.eq	0x1034 <_llm_rows.packet_batch.blocks+0x7bc>
     f90:      	ldr	q24, [sp, #0xf0]
     f94:      	and.16b	v24, v29, v24
     f98:      	addv.8h	h28, v24
     f9c:      	fmov	w14, s28
     fa0:      	add	x13, x12, x10, lsl #5
     fa4:      	movi.2d	v8, #0000000000000000
     fa8:      	movi.2d	v9, #0000000000000000
     fac:      	tbz	w14, #0x0, 0xff0 <_llm_rows.packet_batch.blocks+0x778>
     fb0:      	ldr	s8, [x13]
     fb4:      	and	w14, w14, #0xff
     fb8:      	tbnz	w14, #0x1, 0xff8 <_llm_rows.packet_batch.blocks+0x780>
     fbc:      	tbz	w14, #0x2, 0x1004 <_llm_rows.packet_batch.blocks+0x78c>
     fc0:      	add	x15, x13, #0x8
     fc4:      	ld1.s	{ v8 }[2], [x15]
     fc8:      	tbnz	w14, #0x3, 0x1008 <_llm_rows.packet_batch.blocks+0x790>
     fcc:      	tbz	w14, #0x4, 0x1014 <_llm_rows.packet_batch.blocks+0x79c>
     fd0:      	add	x15, x13, #0x10
     fd4:      	ld1.s	{ v9 }[0], [x15]
     fd8:      	tbnz	w14, #0x5, 0x1018 <_llm_rows.packet_batch.blocks+0x7a0>
     fdc:      	tbz	w14, #0x6, 0x1024 <_llm_rows.packet_batch.blocks+0x7ac>
     fe0:      	add	x15, x13, #0x18
     fe4:      	ld1.s	{ v9 }[2], [x15]
     fe8:      	tbz	w14, #0x7, 0xf70 <_llm_rows.packet_batch.blocks+0x6f8>
     fec:      	b	0x1028 <_llm_rows.packet_batch.blocks+0x7b0>
     ff0:      	and	w14, w14, #0xff
     ff4:      	tbz	w14, #0x1, 0xfbc <_llm_rows.packet_batch.blocks+0x744>
     ff8:      	add	x15, x13, #0x4
     ffc:      	ld1.s	{ v8 }[1], [x15]
    1000:      	tbnz	w14, #0x2, 0xfc0 <_llm_rows.packet_batch.blocks+0x748>
    1004:      	tbz	w14, #0x3, 0xfcc <_llm_rows.packet_batch.blocks+0x754>
    1008:      	add	x15, x13, #0xc
    100c:      	ld1.s	{ v8 }[3], [x15]
    1010:      	tbnz	w14, #0x4, 0xfd0 <_llm_rows.packet_batch.blocks+0x758>
    1014:      	tbz	w14, #0x5, 0xfdc <_llm_rows.packet_batch.blocks+0x764>
    1018:      	add	x15, x13, #0x14
    101c:      	ld1.s	{ v9 }[1], [x15]
    1020:      	tbnz	w14, #0x6, 0xfe0 <_llm_rows.packet_batch.blocks+0x768>
    1024:      	tbz	w14, #0x7, 0xf70 <_llm_rows.packet_batch.blocks+0x6f8>
    1028:      	add	x13, x13, #0x1c
    102c:      	ld1.s	{ v9 }[3], [x13]
    1030:      	b	0xf70 <_llm_rows.packet_batch.blocks+0x6f8>
    1034:      	xtn.8b	v24, v29
    1038:      	movi	d29, #0x0000000000ffff
    103c:      	and.8b	v29, v24, v29
    1040:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x788>
    1044:      	ldr	d8, [x10]
    1048:      	and.8b	v24, v24, v8
    104c:      	addv.8b	b24, v24
    1050:      	fmov	w13, s24
    1054:      	umaxv.8b	b24, v29
    1058:      	fmov	w10, s24
    105c:      	rbit	w12, w13
    1060:      	clz	w12, w12
    1064:      	tst	w10, #0x1
    1068:      	csel	w10, w12, wzr, ne
    106c:      	mov	w12, #0x600             ; =1536
    1070:      	dup.2d	v13, x12
    1074:      	umlal.2d	v30, v31, v25
    1078:      	mov	b24, v29[0]
    107c:      	mov.b	v24[4], v29[1]
    1080:      	add.2d	v30, v30, v13
    1084:      	ushll.2d	v24, v24, #0x0
    1088:      	shl.2d	v24, v24, #0x3f
    108c:      	cmlt.2d	v24, v24, #0
    1090:      	str	q30, [sp, #0x50]
    1094:      	and.16b	v24, v24, v30
    1098:      	movi.2d	v30, #0000000000000000
    109c:      	stp	q30, q30, [sp, #0x260]
    10a0:      	stp	q24, q30, [sp, #0x240]
    10a4:      	and	x12, x10, #0x7
    10a8:      	add	x14, sp, #0x240
    10ac:      	ldr	x12, [x14, x12, lsl #3]
    10b0:      	sub	x12, x12, x10
    10b4:      	lsl	x12, x12, #2
    10b8:      	add	x11, x11, x12
    10bc:      	movi.2d	v8, #0000000000000000
    10c0:      	tbz	w13, #0x0, 0x1100 <_llm_rows.packet_batch.blocks+0x888>
    10c4:      	ldr	s8, [x11]
    10c8:      	tbnz	w13, #0x1, 0x1104 <_llm_rows.packet_batch.blocks+0x88c>
    10cc:      	tbz	w13, #0x2, 0x1110 <_llm_rows.packet_batch.blocks+0x898>
    10d0:      	add	x14, x11, #0x8
    10d4:      	ld1.s	{ v8 }[2], [x14]
    10d8:      	tbnz	w13, #0x3, 0x1114 <_llm_rows.packet_batch.blocks+0x89c>
    10dc:      	tbz	w13, #0x4, 0x1120 <_llm_rows.packet_batch.blocks+0x8a8>
    10e0:      	add	x14, x11, #0x10
    10e4:      	ld1.s	{ v30 }[0], [x14]
    10e8:      	tbnz	w13, #0x5, 0x1124 <_llm_rows.packet_batch.blocks+0x8ac>
    10ec:      	tbz	w13, #0x6, 0x1130 <_llm_rows.packet_batch.blocks+0x8b8>
    10f0:      	add	x14, x11, #0x18
    10f4:      	ld1.s	{ v30 }[2], [x14]
    10f8:      	tbnz	w13, #0x7, 0x1134 <_llm_rows.packet_batch.blocks+0x8bc>
    10fc:      	b	0x113c <_llm_rows.packet_batch.blocks+0x8c4>
    1100:      	tbz	w13, #0x1, 0x10cc <_llm_rows.packet_batch.blocks+0x854>
    1104:      	add	x14, x11, #0x4
    1108:      	ld1.s	{ v8 }[1], [x14]
    110c:      	tbnz	w13, #0x2, 0x10d0 <_llm_rows.packet_batch.blocks+0x858>
    1110:      	tbz	w13, #0x3, 0x10dc <_llm_rows.packet_batch.blocks+0x864>
    1114:      	add	x14, x11, #0xc
    1118:      	ld1.s	{ v8 }[3], [x14]
    111c:      	tbnz	w13, #0x4, 0x10e0 <_llm_rows.packet_batch.blocks+0x868>
    1120:      	tbz	w13, #0x5, 0x10ec <_llm_rows.packet_batch.blocks+0x874>
    1124:      	add	x14, x11, #0x14
    1128:      	ld1.s	{ v30 }[1], [x14]
    112c:      	tbnz	w13, #0x6, 0x10f0 <_llm_rows.packet_batch.blocks+0x878>
    1130:      	tbz	w13, #0x7, 0x113c <_llm_rows.packet_batch.blocks+0x8c4>
    1134:      	add	x11, x11, #0x1c
    1138:      	ld1.s	{ v30 }[3], [x11]
    113c:      	mov	x15, #0x0               ; =0
    1140:      	umull.2d	v24, v31, v25
    1144:      	umlal.2d	v23, v27, v25
    1148:      	add.2d	v23, v23, v13
    114c:      	umlal.2d	v22, v26, v25
    1150:      	add.2d	v22, v22, v13
    1154:      	stp	q22, q23, [sp, #0x20]
    1158:      	ldr	d22, [sp, #0xc0]
    115c:      	umlal.2d	v21, v22, v25
    1160:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x788>
    1164:      	ldr	q22, [x11]
    1168:      	mov	w11, #0x1800            ; =6144
    116c:      	dup.2d	v23, x11
    1170:      	sshll.2d	v25, v20, #0x0
    1174:      	bif.16b	v22, v23, v25
    1178:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x788>
    117c:      	ldr	q25, [x11]
    1180:      	sshll.2d	v26, v19, #0x0
    1184:      	bif.16b	v25, v23, v26
    1188:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x788>
    118c:      	ldr	q26, [x11]
    1190:      	bif.16b	v26, v23, v12
    1194:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x788>
    1198:      	ldr	q27, [x11]
    119c:      	bit.16b	v23, v27, v11
    11a0:      	stp	q25, q23, [sp, #0x220]
    11a4:      	stp	q22, q26, [sp, #0x200]
    11a8:      	and	x11, x10, #0x7
    11ac:      	add	x14, sp, #0x200
    11b0:      	ldr	x11, [x14, x11, lsl #3]
    11b4:      	add.2d	v21, v21, v13
    11b8:      	str	q21, [sp, #0x10]
    11bc:      	sub	x11, x11, x10, lsl #2
    11c0:      	tst	w13, #0xff
    11c4:      	csel	x11, xzr, x11, eq
    11c8:      	add	x13, x26, x11
    11cc:      	ldp	q21, q22, [x13]
    11d0:      	zip2.8b	v23, v29, v0
    11d4:      	ushll.4s	v23, v23, #0x0
    11d8:      	shl.4s	v23, v23, #0x1f
    11dc:      	cmlt.4s	v23, v23, #0
    11e0:      	str	q30, [sp, #0xc0]
    11e4:      	bit.16b	v22, v30, v23
    11e8:      	zip1.8b	v23, v29, v0
    11ec:      	ushll.4s	v23, v23, #0x0
    11f0:      	shl.4s	v23, v23, #0x1f
    11f4:      	cmlt.4s	v23, v23, #0
    11f8:      	str	q8, [sp, #0x40]
    11fc:      	bit.16b	v21, v8, v23
    1200:      	stp	q21, q22, [x13]
    1204:      	fmov	x13, d24
    1208:      	lsl	x13, x13, #2
    120c:      	mov	w14, #0x1               ; =1
    1210:      	dup.2d	v21, x14
    1214:      	add	x14, x9, x13
    1218:      	ushll2.2d	v22, v19, #0x0
    121c:      	and.16b	v24, v22, v21
    1220:      	ushll2.2d	v22, v20, #0x0
    1224:      	and.16b	v25, v22, v21
    1228:      	ushll.2d	v22, v19, #0x0
    122c:      	and.16b	v26, v22, v21
    1230:      	ushll.2d	v22, v20, #0x0
    1234:      	and.16b	v27, v22, v21
    1238:      	movi.2d	v31, #0000000000000000
    123c:      	movi.2d	v8, #0000000000000000
    1240:      	movi.2d	v11, #0000000000000000
    1244:      	movi.2d	v12, #0000000000000000
    1248:      	b	0x127c <_llm_rows.packet_batch.blocks+0xa04>
    124c:      	add	x15, x24, x15
    1250:      	ldp	q21, q22, [x15]
    1254:      	bit.16b	v22, v14, v19
    1258:      	bit.16b	v21, v13, v20
    125c:      	stp	q21, q22, [x15]
    1260:      	add.2d	v8, v8, v25
    1264:      	add.2d	v11, v11, v26
    1268:      	add.2d	v12, v12, v24
    126c:      	add.2d	v31, v31, v27
    1270:      	fmov	x15, d31
    1274:      	cmp	x15, #0xc0
    1278:      	b.ge	0x1318 <_llm_rows.packet_batch.blocks+0xaa0>
    127c:      	fmov	w17, s28
    1280:      	lsl	x15, x15, #5
    1284:      	add	x16, x14, x15
    1288:      	movi.2d	v13, #0000000000000000
    128c:      	movi.2d	v14, #0000000000000000
    1290:      	tbz	w17, #0x0, 0x12d4 <_llm_rows.packet_batch.blocks+0xa5c>
    1294:      	ldr	s13, [x16]
    1298:      	and	w17, w17, #0xff
    129c:      	tbnz	w17, #0x1, 0x12dc <_llm_rows.packet_batch.blocks+0xa64>
    12a0:      	tbz	w17, #0x2, 0x12e8 <_llm_rows.packet_batch.blocks+0xa70>
    12a4:      	add	x0, x16, #0x8
    12a8:      	ld1.s	{ v13 }[2], [x0]
    12ac:      	tbnz	w17, #0x3, 0x12ec <_llm_rows.packet_batch.blocks+0xa74>
    12b0:      	tbz	w17, #0x4, 0x12f8 <_llm_rows.packet_batch.blocks+0xa80>
    12b4:      	add	x0, x16, #0x10
    12b8:      	ld1.s	{ v14 }[0], [x0]
    12bc:      	tbnz	w17, #0x5, 0x12fc <_llm_rows.packet_batch.blocks+0xa84>
    12c0:      	tbz	w17, #0x6, 0x1308 <_llm_rows.packet_batch.blocks+0xa90>
    12c4:      	add	x0, x16, #0x18
    12c8:      	ld1.s	{ v14 }[2], [x0]
    12cc:      	tbz	w17, #0x7, 0x124c <_llm_rows.packet_batch.blocks+0x9d4>
    12d0:      	b	0x130c <_llm_rows.packet_batch.blocks+0xa94>
    12d4:      	and	w17, w17, #0xff
    12d8:      	tbz	w17, #0x1, 0x12a0 <_llm_rows.packet_batch.blocks+0xa28>
    12dc:      	add	x0, x16, #0x4
    12e0:      	ld1.s	{ v13 }[1], [x0]
    12e4:      	tbnz	w17, #0x2, 0x12a4 <_llm_rows.packet_batch.blocks+0xa2c>
    12e8:      	tbz	w17, #0x3, 0x12b0 <_llm_rows.packet_batch.blocks+0xa38>
    12ec:      	add	x0, x16, #0xc
    12f0:      	ld1.s	{ v13 }[3], [x0]
    12f4:      	tbnz	w17, #0x4, 0x12b4 <_llm_rows.packet_batch.blocks+0xa3c>
    12f8:      	tbz	w17, #0x5, 0x12c0 <_llm_rows.packet_batch.blocks+0xa48>
    12fc:      	add	x0, x16, #0x14
    1300:      	ld1.s	{ v14 }[1], [x0]
    1304:      	tbnz	w17, #0x6, 0x12c4 <_llm_rows.packet_batch.blocks+0xa4c>
    1308:      	tbz	w17, #0x7, 0x124c <_llm_rows.packet_batch.blocks+0x9d4>
    130c:      	add	x16, x16, #0x1c
    1310:      	ld1.s	{ v14 }[3], [x16]
    1314:      	b	0x124c <_llm_rows.packet_batch.blocks+0x9d4>
    1318:      	add	x9, x9, x12
    131c:      	adrp	x12, 0x1000 <_llm_rows.packet_batch.blocks+0x788>
    1320:      	ldr	d21, [x12]
    1324:      	shl.8b	v22, v29, #0x7
    1328:      	cmlt.8b	v22, v22, #0
    132c:      	and.8b	v21, v22, v21
    1330:      	addv.8b	b21, v21
    1334:      	str	d21, [sp, #0x8]
    1338:      	fmov	w12, s21
    133c:      	movi.2d	v11, #0000000000000000
    1340:      	movi.2d	v31, #0000000000000000
    1344:      	tbz	w12, #0x0, 0x1384 <_llm_rows.packet_batch.blocks+0xb0c>
    1348:      	ldr	s11, [x9]
    134c:      	tbnz	w12, #0x1, 0x1388 <_llm_rows.packet_batch.blocks+0xb10>
    1350:      	tbz	w12, #0x2, 0x1394 <_llm_rows.packet_batch.blocks+0xb1c>
    1354:      	add	x14, x9, #0x8
    1358:      	ld1.s	{ v11 }[2], [x14]
    135c:      	tbnz	w12, #0x3, 0x1398 <_llm_rows.packet_batch.blocks+0xb20>
    1360:      	tbz	w12, #0x4, 0x13a4 <_llm_rows.packet_batch.blocks+0xb2c>
    1364:      	add	x14, x9, #0x10
    1368:      	ld1.s	{ v31 }[0], [x14]
    136c:      	tbnz	w12, #0x5, 0x13a8 <_llm_rows.packet_batch.blocks+0xb30>
    1370:      	tbz	w12, #0x6, 0x13b4 <_llm_rows.packet_batch.blocks+0xb3c>
    1374:      	add	x14, x9, #0x18
    1378:      	ld1.s	{ v31 }[2], [x14]
    137c:      	tbnz	w12, #0x7, 0x13b8 <_llm_rows.packet_batch.blocks+0xb40>
    1380:      	b	0x13c0 <_llm_rows.packet_batch.blocks+0xb48>
    1384:      	tbz	w12, #0x1, 0x1350 <_llm_rows.packet_batch.blocks+0xad8>
    1388:      	add	x14, x9, #0x4
    138c:      	ld1.s	{ v11 }[1], [x14]
    1390:      	tbnz	w12, #0x2, 0x1354 <_llm_rows.packet_batch.blocks+0xadc>
    1394:      	tbz	w12, #0x3, 0x1360 <_llm_rows.packet_batch.blocks+0xae8>
    1398:      	add	x14, x9, #0xc
    139c:      	ld1.s	{ v11 }[3], [x14]
    13a0:      	tbnz	w12, #0x4, 0x1364 <_llm_rows.packet_batch.blocks+0xaec>
    13a4:      	tbz	w12, #0x5, 0x1370 <_llm_rows.packet_batch.blocks+0xaf8>
    13a8:      	add	x14, x9, #0x14
    13ac:      	ld1.s	{ v31 }[1], [x14]
    13b0:      	tbnz	w12, #0x6, 0x1374 <_llm_rows.packet_batch.blocks+0xafc>
    13b4:      	tbz	w12, #0x7, 0x13c0 <_llm_rows.packet_batch.blocks+0xb48>
    13b8:      	add	x9, x9, #0x1c
    13bc:      	ld1.s	{ v31 }[3], [x9]
    13c0:      	mov	x14, #0x0               ; =0
    13c4:      	add	x9, x24, x11
    13c8:      	ldp	q21, q22, [x9]
    13cc:      	zip2.8b	v23, v29, v0
    13d0:      	ushll.4s	v23, v23, #0x0
    13d4:      	shl.4s	v23, v23, #0x1f
    13d8:      	cmlt.4s	v23, v23, #0
    13dc:      	bit.16b	v22, v31, v23
    13e0:      	zip1.8b	v23, v29, v0
    13e4:      	ushll.4s	v23, v23, #0x0
    13e8:      	shl.4s	v23, v23, #0x1f
    13ec:      	cmlt.4s	v23, v23, #0
    13f0:      	bit.16b	v21, v11, v23
    13f4:      	stp	q21, q22, [x9]
    13f8:      	add	x9, x8, x13
    13fc:      	movi.2d	v13, #0000000000000000
    1400:      	movi.2d	v14, #0000000000000000
    1404:      	movi.2d	v15, #0000000000000000
    1408:      	movi.2d	v8, #0000000000000000
    140c:      	b	0x142c <_llm_rows.packet_batch.blocks+0xbb4>
    1410:      	add.2d	v14, v14, v25
    1414:      	add.2d	v15, v15, v26
    1418:      	add.2d	v8, v8, v24
    141c:      	add.2d	v13, v13, v27
    1420:      	fmov	x14, d13
    1424:      	cmp	x14, #0xc0
    1428:      	b.ge	0x167c <_llm_rows.packet_batch.blocks+0xe04>
    142c:      	fmov	w12, s28
    1430:      	lsl	x11, x14, #5
    1434:      	add	x13, x26, x11
    1438:      	ldp	q21, q23, [x13]
    143c:      	and.16b	v21, v20, v21
    1440:      	fneg.4s	v22, v21
    1444:      	and.16b	v22, v20, v22
    1448:      	fcmge.4s	v9, v22, v1
    144c:      	fcmge.4s	v12, v0, v22
    1450:      	and.16b	v9, v9, v12
    1454:      	and.16b	v9, v9, v22
    1458:      	fmul.4s	v12, v9, v18
    145c:      	movi.4s	v30, #0x4b, lsl #24
    1460:      	mvni.4s	v10, #0x80, lsl #24
    1464:      	bsl.16b	v10, v30, v12
    1468:      	fadd.4s	v12, v12, v10
    146c:      	fsub.4s	v10, v12, v10
    1470:      	fcvtzs.4s	v10, v10
    1474:      	scvtf.4s	v12, v10
    1478:      	fmul.4s	v30, v12, v17
    147c:      	fadd.4s	v30, v9, v30
    1480:      	fmul.4s	v9, v12, v16
    1484:      	fadd.4s	v30, v30, v9
    1488:      	fmul.4s	v9, v30, v7
    148c:      	fadd.4s	v9, v9, v6
    1490:      	fmul.4s	v9, v30, v9
    1494:      	fadd.4s	v9, v9, v5
    1498:      	fmul.4s	v9, v30, v9
    149c:      	fadd.4s	v9, v9, v4
    14a0:      	fmul.4s	v9, v30, v9
    14a4:      	fadd.4s	v9, v9, v3
    14a8:      	fmul.4s	v9, v30, v9
    14ac:      	movi.4s	v12, #0x3f, lsl #24
    14b0:      	fadd.4s	v9, v9, v12
    14b4:      	fmul.4s	v12, v30, v30
    14b8:      	fmul.4s	v9, v12, v9
    14bc:      	fadd.4s	v30, v30, v9
    14c0:      	fadd.4s	v30, v30, v2
    14c4:      	sshr.4s	v9, v10, #0x1
    14c8:      	shl.4s	v12, v9, #0x17
    14cc:      	add.4s	v12, v12, v2
    14d0:      	fmul.4s	v30, v30, v12
    14d4:      	sub.4s	v9, v10, v9
    14d8:      	shl.4s	v9, v9, #0x17
    14dc:      	add.4s	v9, v9, v2
    14e0:      	fmul.4s	v30, v30, v9
    14e4:      	fcmgt.4s	v9, v1, v22
    14e8:      	fcmgt.4s	v10, v22, v0
    14ec:      	fcmeq.4s	v22, v22, v22
    14f0:      	fadd.4s	v30, v30, v2
    14f4:      	bit.16b	v30, v2, v9
    14f8:      	ldr	q9, [sp, #0x110]
    14fc:      	bit.16b	v30, v9, v10
    1500:      	ldr	q9, [sp, #0x100]
    1504:      	bsl.16b	v22, v30, v9
    1508:      	fdiv.4s	v21, v21, v22
    150c:      	add	x13, x24, x11
    1510:      	ldp	q30, q22, [x13]
    1514:      	and.16b	v30, v20, v30
    1518:      	fmul.4s	v21, v30, v21
    151c:      	add	x11, x9, x11
    1520:      	tbz	w12, #0x0, 0x1544 <_llm_rows.packet_batch.blocks+0xccc>
    1524:      	str	s21, [x11]
    1528:      	and	w12, w12, #0xff
    152c:      	tbnz	w12, #0x1, 0x154c <_llm_rows.packet_batch.blocks+0xcd4>
    1530:      	tbz	w12, #0x2, 0x1558 <_llm_rows.packet_batch.blocks+0xce0>
    1534:      	add	x13, x11, #0x8
    1538:      	st1.s	{ v21 }[2], [x13]
    153c:      	tbnz	w12, #0x3, 0x155c <_llm_rows.packet_batch.blocks+0xce4>
    1540:      	b	0x1564 <_llm_rows.packet_batch.blocks+0xcec>
    1544:      	and	w12, w12, #0xff
    1548:      	tbz	w12, #0x1, 0x1530 <_llm_rows.packet_batch.blocks+0xcb8>
    154c:      	add	x13, x11, #0x4
    1550:      	st1.s	{ v21 }[1], [x13]
    1554:      	tbnz	w12, #0x2, 0x1534 <_llm_rows.packet_batch.blocks+0xcbc>
    1558:      	tbz	w12, #0x3, 0x1564 <_llm_rows.packet_batch.blocks+0xcec>
    155c:      	add	x13, x11, #0xc
    1560:      	st1.s	{ v21 }[3], [x13]
    1564:      	and.16b	v21, v19, v23
    1568:      	fneg.4s	v23, v21
    156c:      	and.16b	v23, v19, v23
    1570:      	fcmge.4s	v30, v23, v1
    1574:      	fcmge.4s	v9, v0, v23
    1578:      	and.16b	v30, v30, v9
    157c:      	and.16b	v30, v30, v23
    1580:      	fmul.4s	v9, v30, v18
    1584:      	movi.4s	v10, #0x4b, lsl #24
    1588:      	mvni.4s	v12, #0x80, lsl #24
    158c:      	bif.16b	v10, v9, v12
    1590:      	fadd.4s	v9, v9, v10
    1594:      	fsub.4s	v9, v9, v10
    1598:      	fcvtzs.4s	v9, v9
    159c:      	scvtf.4s	v10, v9
    15a0:      	fmul.4s	v12, v10, v17
    15a4:      	fadd.4s	v30, v30, v12
    15a8:      	fmul.4s	v10, v10, v16
    15ac:      	fadd.4s	v30, v30, v10
    15b0:      	fmul.4s	v10, v30, v7
    15b4:      	fadd.4s	v10, v10, v6
    15b8:      	fmul.4s	v10, v30, v10
    15bc:      	fadd.4s	v10, v10, v5
    15c0:      	fmul.4s	v10, v30, v10
    15c4:      	fadd.4s	v10, v10, v4
    15c8:      	fmul.4s	v10, v30, v10
    15cc:      	fadd.4s	v10, v10, v3
    15d0:      	fmul.4s	v10, v30, v10
    15d4:      	movi.4s	v12, #0x3f, lsl #24
    15d8:      	fadd.4s	v10, v10, v12
    15dc:      	fmul.4s	v12, v30, v30
    15e0:      	fmul.4s	v10, v12, v10
    15e4:      	fadd.4s	v30, v30, v10
    15e8:      	fadd.4s	v30, v30, v2
    15ec:      	sshr.4s	v10, v9, #0x1
    15f0:      	shl.4s	v12, v10, #0x17
    15f4:      	add.4s	v12, v12, v2
    15f8:      	fmul.4s	v30, v30, v12
    15fc:      	sub.4s	v9, v9, v10
    1600:      	shl.4s	v9, v9, #0x17
    1604:      	add.4s	v9, v9, v2
    1608:      	fmul.4s	v30, v30, v9
    160c:      	fcmgt.4s	v9, v1, v23
    1610:      	fcmgt.4s	v10, v23, v0
    1614:      	fcmeq.4s	v23, v23, v23
    1618:      	fadd.4s	v30, v30, v2
    161c:      	bit.16b	v30, v2, v9
    1620:      	ldr	q9, [sp, #0x110]
    1624:      	bit.16b	v30, v9, v10
    1628:      	ldr	q9, [sp, #0x100]
    162c:      	bsl.16b	v23, v30, v9
    1630:      	fdiv.4s	v21, v21, v23
    1634:      	and.16b	v22, v19, v22
    1638:      	fmul.4s	v21, v22, v21
    163c:      	tbz	w12, #0x4, 0x165c <_llm_rows.packet_batch.blocks+0xde4>
    1640:      	str	s21, [x11, #0x10]
    1644:      	tbnz	w12, #0x5, 0x1660 <_llm_rows.packet_batch.blocks+0xde8>
    1648:      	tbz	w12, #0x6, 0x166c <_llm_rows.packet_batch.blocks+0xdf4>
    164c:      	add	x13, x11, #0x18
    1650:      	st1.s	{ v21 }[2], [x13]
    1654:      	tbz	w12, #0x7, 0x1410 <_llm_rows.packet_batch.blocks+0xb98>
    1658:      	b	0x1670 <_llm_rows.packet_batch.blocks+0xdf8>
    165c:      	tbz	w12, #0x5, 0x1648 <_llm_rows.packet_batch.blocks+0xdd0>
    1660:      	add	x13, x11, #0x14
    1664:      	st1.s	{ v21 }[1], [x13]
    1668:      	tbnz	w12, #0x6, 0x164c <_llm_rows.packet_batch.blocks+0xdd4>
    166c:      	tbz	w12, #0x7, 0x1410 <_llm_rows.packet_batch.blocks+0xb98>
    1670:      	add	x11, x11, #0x1c
    1674:      	st1.s	{ v21 }[3], [x11]
    1678:      	b	0x1410 <_llm_rows.packet_batch.blocks+0xb98>
    167c:      	ldr	q24, [sp, #0x40]
    1680:      	fneg.4s	v19, v24
    1684:      	ldr	d20, [sp, #0x8]
    1688:      	fmov	w9, s20
    168c:      	zip1.8b	v20, v29, v0
    1690:      	ushll.4s	v20, v20, #0x0
    1694:      	shl.4s	v20, v20, #0x1f
    1698:      	cmlt.4s	v20, v20, #0
    169c:      	and.16b	v19, v20, v19
    16a0:      	fcmge.4s	v20, v19, v1
    16a4:      	fcmge.4s	v21, v0, v19
    16a8:      	and.16b	v20, v20, v21
    16ac:      	and.16b	v20, v20, v19
    16b0:      	fmul.4s	v21, v20, v18
    16b4:      	movi.4s	v22, #0x4b, lsl #24
    16b8:      	mvni.4s	v23, #0x80, lsl #24
    16bc:      	bif.16b	v22, v21, v23
    16c0:      	fadd.4s	v21, v21, v22
    16c4:      	fsub.4s	v21, v21, v22
    16c8:      	fcvtzs.4s	v21, v21
    16cc:      	scvtf.4s	v22, v21
    16d0:      	fmul.4s	v23, v22, v17
    16d4:      	fadd.4s	v20, v20, v23
    16d8:      	fmul.4s	v22, v22, v16
    16dc:      	fadd.4s	v20, v20, v22
    16e0:      	fmul.4s	v22, v20, v7
    16e4:      	fadd.4s	v22, v22, v6
    16e8:      	fmul.4s	v22, v20, v22
    16ec:      	fadd.4s	v22, v22, v5
    16f0:      	fmul.4s	v22, v20, v22
    16f4:      	fadd.4s	v22, v22, v4
    16f8:      	fmul.4s	v22, v20, v22
    16fc:      	fadd.4s	v22, v22, v3
    1700:      	fmul.4s	v22, v20, v22
    1704:      	movi.4s	v23, #0x3f, lsl #24
    1708:      	fadd.4s	v22, v22, v23
    170c:      	fmul.4s	v23, v20, v20
    1710:      	fmul.4s	v22, v23, v22
    1714:      	fadd.4s	v20, v20, v22
    1718:      	fadd.4s	v20, v20, v2
    171c:      	sshr.4s	v22, v21, #0x1
    1720:      	shl.4s	v23, v22, #0x17
    1724:      	add.4s	v23, v23, v2
    1728:      	fmul.4s	v20, v20, v23
    172c:      	sub.4s	v21, v21, v22
    1730:      	shl.4s	v21, v21, #0x17
    1734:      	add.4s	v21, v21, v2
    1738:      	fmul.4s	v20, v20, v21
    173c:      	fcmgt.4s	v21, v1, v19
    1740:      	fcmgt.4s	v22, v19, v0
    1744:      	fcmeq.4s	v19, v19, v19
    1748:      	fadd.4s	v20, v20, v2
    174c:      	bit.16b	v20, v2, v21
    1750:      	ldp	q21, q23, [sp, #0x100]
    1754:      	bit.16b	v20, v23, v22
    1758:      	bsl.16b	v19, v20, v21
    175c:      	fdiv.4s	v19, v24, v19
    1760:      	fmul.4s	v19, v19, v11
    1764:      	ldr	q21, [sp, #0x50]
    1768:      	ldp	q23, q22, [sp, #0x20]
    176c:      	stp	q21, q22, [sp, #0x1b0]
    1770:      	ldr	q20, [sp, #0x10]
    1774:      	stp	q23, q20, [sp, #0x1d0]
    1778:      	and	x11, x10, #0x7
    177c:      	add	x12, sp, #0x1b0
    1780:      	ldr	x11, [x12, x11, lsl #3]
    1784:      	sub	x10, x11, x10
    1788:      	add	x8, x8, x10, lsl #2
    178c:      	tbz	w9, #0x0, 0x17b0 <_llm_rows.packet_batch.blocks+0xf38>
    1790:      	str	s19, [x8]
    1794:      	ldr	q23, [sp, #0xc0]
    1798:      	tbnz	w9, #0x1, 0x17b8 <_llm_rows.packet_batch.blocks+0xf40>
    179c:      	tbz	w9, #0x2, 0x17c4 <_llm_rows.packet_batch.blocks+0xf4c>
    17a0:      	add	x10, x8, #0x8
    17a4:      	st1.s	{ v19 }[2], [x10]
    17a8:      	tbnz	w9, #0x3, 0x17c8 <_llm_rows.packet_batch.blocks+0xf50>
    17ac:      	b	0x17d0 <_llm_rows.packet_batch.blocks+0xf58>
    17b0:      	ldr	q23, [sp, #0xc0]
    17b4:      	tbz	w9, #0x1, 0x179c <_llm_rows.packet_batch.blocks+0xf24>
    17b8:      	add	x10, x8, #0x4
    17bc:      	st1.s	{ v19 }[1], [x10]
    17c0:      	tbnz	w9, #0x2, 0x17a0 <_llm_rows.packet_batch.blocks+0xf28>
    17c4:      	tbz	w9, #0x3, 0x17d0 <_llm_rows.packet_batch.blocks+0xf58>
    17c8:      	add	x10, x8, #0xc
    17cc:      	st1.s	{ v19 }[3], [x10]
    17d0:      	fneg.4s	v19, v23
    17d4:      	zip2.8b	v20, v29, v0
    17d8:      	ushll.4s	v20, v20, #0x0
    17dc:      	shl.4s	v20, v20, #0x1f
    17e0:      	cmlt.4s	v20, v20, #0
    17e4:      	and.16b	v19, v20, v19
    17e8:      	fcmge.4s	v20, v19, v1
    17ec:      	fcmge.4s	v21, v0, v19
    17f0:      	and.16b	v20, v20, v21
    17f4:      	and.16b	v20, v20, v19
    17f8:      	fmul.4s	v18, v20, v18
    17fc:      	movi.4s	v21, #0x4b, lsl #24
    1800:      	mvni.4s	v22, #0x80, lsl #24
    1804:      	bif.16b	v21, v18, v22
    1808:      	fadd.4s	v18, v18, v21
    180c:      	fsub.4s	v18, v18, v21
    1810:      	fcvtzs.4s	v18, v18
    1814:      	scvtf.4s	v21, v18
    1818:      	fmul.4s	v17, v21, v17
    181c:      	fadd.4s	v17, v20, v17
    1820:      	fmul.4s	v16, v21, v16
    1824:      	fadd.4s	v16, v17, v16
    1828:      	fmul.4s	v7, v16, v7
    182c:      	fadd.4s	v6, v7, v6
    1830:      	fmul.4s	v6, v16, v6
    1834:      	fadd.4s	v5, v6, v5
    1838:      	fmul.4s	v5, v16, v5
    183c:      	fadd.4s	v4, v5, v4
    1840:      	fmul.4s	v4, v16, v4
    1844:      	fadd.4s	v3, v4, v3
    1848:      	fmul.4s	v3, v16, v3
    184c:      	movi.4s	v4, #0x3f, lsl #24
    1850:      	fadd.4s	v3, v3, v4
    1854:      	fmul.4s	v4, v16, v16
    1858:      	fmul.4s	v3, v4, v3
    185c:      	fadd.4s	v3, v16, v3
    1860:      	fadd.4s	v3, v3, v2
    1864:      	sshr.4s	v4, v18, #0x1
    1868:      	shl.4s	v5, v4, #0x17
    186c:      	add.4s	v5, v5, v2
    1870:      	fmul.4s	v3, v3, v5
    1874:      	sub.4s	v4, v18, v4
    1878:      	shl.4s	v4, v4, #0x17
    187c:      	add.4s	v4, v4, v2
    1880:      	fmul.4s	v3, v3, v4
    1884:      	fcmgt.4s	v1, v1, v19
    1888:      	fcmgt.4s	v0, v19, v0
    188c:      	fcmeq.4s	v4, v19, v19
    1890:      	fadd.4s	v3, v3, v2
    1894:      	bsl.16b	v1, v2, v3
    1898:      	ldr	q2, [sp, #0x110]
    189c:      	bsl.16b	v0, v2, v1
    18a0:      	ldr	q1, [sp, #0x100]
    18a4:      	bif.16b	v0, v1, v4
    18a8:      	fdiv.4s	v0, v23, v0
    18ac:      	fmul.4s	v0, v0, v31
    18b0:      	tbz	w9, #0x4, 0x1cb8 <_llm_rows.packet_batch.blocks+0x1440>
    18b4:      	str	s0, [x8, #0x10]
    18b8:      	tbnz	w9, #0x5, 0x1cbc <_llm_rows.packet_batch.blocks+0x1444>
    18bc:      	tbz	w9, #0x6, 0x1cc8 <_llm_rows.packet_batch.blocks+0x1450>
    18c0:      	add	x10, x8, #0x18
    18c4:      	st1.s	{ v0 }[2], [x10]
    18c8:      	tbnz	w9, #0x7, 0x1ccc <_llm_rows.packet_batch.blocks+0x1454>
    18cc:      	b	0x948 <_llm_rows.packet_batch.blocks+0xd0>
    18d0:      	xtn.8b	v20, v29
    18d4:      	movi	d19, #0x0000000000ffff
    18d8:      	and.8b	v19, v20, v19
    18dc:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x788>
    18e0:      	ldr	d24, [x10]
    18e4:      	and.8b	v20, v20, v24
    18e8:      	addv.8b	b20, v20
    18ec:      	fmov	w12, s20
    18f0:      	umaxv.8b	b20, v19
    18f4:      	fmov	w10, s20
    18f8:      	rbit	w13, w12
    18fc:      	clz	w13, w13
    1900:      	tst	w10, #0x1
    1904:      	csel	w10, w13, wzr, ne
    1908:      	mov	w13, #0x600             ; =1536
    190c:      	dup.2d	v9, x13
    1910:      	umlal.2d	v30, v31, v25
    1914:      	mov	b20, v19[0]
    1918:      	mov.b	v20[4], v19[1]
    191c:      	add.2d	v28, v30, v9
    1920:      	ushll.2d	v20, v20, #0x0
    1924:      	shl.2d	v20, v20, #0x3f
    1928:      	cmlt.2d	v20, v20, #0
    192c:      	and.16b	v20, v20, v28
    1930:      	movi.2d	v24, #0000000000000000
    1934:      	stp	q24, q24, [sp, #0x180]
    1938:      	stp	q20, q24, [sp, #0x160]
    193c:      	and	x13, x10, #0x7
    1940:      	add	x14, sp, #0x160
    1944:      	ldr	x13, [x14, x13, lsl #3]
    1948:      	sub	x13, x13, x10
    194c:      	lsl	x13, x13, #2
    1950:      	add	x11, x11, x13
    1954:      	movi.2d	v29, #0000000000000000
    1958:      	movi.2d	v20, #0000000000000000
    195c:      	tbz	w12, #0x0, 0x199c <_llm_rows.packet_batch.blocks+0x1124>
    1960:      	ldr	s29, [x11]
    1964:      	tbnz	w12, #0x1, 0x19a0 <_llm_rows.packet_batch.blocks+0x1128>
    1968:      	tbz	w12, #0x2, 0x19ac <_llm_rows.packet_batch.blocks+0x1134>
    196c:      	add	x14, x11, #0x8
    1970:      	ld1.s	{ v29 }[2], [x14]
    1974:      	tbnz	w12, #0x3, 0x19b0 <_llm_rows.packet_batch.blocks+0x1138>
    1978:      	tbz	w12, #0x4, 0x19bc <_llm_rows.packet_batch.blocks+0x1144>
    197c:      	add	x14, x11, #0x10
    1980:      	ld1.s	{ v20 }[0], [x14]
    1984:      	tbnz	w12, #0x5, 0x19c0 <_llm_rows.packet_batch.blocks+0x1148>
    1988:      	tbz	w12, #0x6, 0x19cc <_llm_rows.packet_batch.blocks+0x1154>
    198c:      	add	x14, x11, #0x18
    1990:      	ld1.s	{ v20 }[2], [x14]
    1994:      	tbnz	w12, #0x7, 0x19d0 <_llm_rows.packet_batch.blocks+0x1158>
    1998:      	b	0x19d8 <_llm_rows.packet_batch.blocks+0x1160>
    199c:      	tbz	w12, #0x1, 0x1968 <_llm_rows.packet_batch.blocks+0x10f0>
    19a0:      	add	x14, x11, #0x4
    19a4:      	ld1.s	{ v29 }[1], [x14]
    19a8:      	tbnz	w12, #0x2, 0x196c <_llm_rows.packet_batch.blocks+0x10f4>
    19ac:      	tbz	w12, #0x3, 0x1978 <_llm_rows.packet_batch.blocks+0x1100>
    19b0:      	add	x14, x11, #0xc
    19b4:      	ld1.s	{ v29 }[3], [x14]
    19b8:      	tbnz	w12, #0x4, 0x197c <_llm_rows.packet_batch.blocks+0x1104>
    19bc:      	tbz	w12, #0x5, 0x1988 <_llm_rows.packet_batch.blocks+0x1110>
    19c0:      	add	x14, x11, #0x14
    19c4:      	ld1.s	{ v20 }[1], [x14]
    19c8:      	tbnz	w12, #0x6, 0x198c <_llm_rows.packet_batch.blocks+0x1114>
    19cc:      	tbz	w12, #0x7, 0x19d8 <_llm_rows.packet_batch.blocks+0x1160>
    19d0:      	add	x11, x11, #0x1c
    19d4:      	ld1.s	{ v20 }[3], [x11]
    19d8:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x788>
    19dc:      	ldr	d24, [x11]
    19e0:      	shl.8b	v30, v19, #0x7
    19e4:      	cmlt.8b	v30, v30, #0
    19e8:      	and.8b	v24, v30, v24
    19ec:      	addv.8b	b31, v24
    19f0:      	fmov	w11, s31
    19f4:      	add	x9, x9, x13
    19f8:      	movi.2d	v8, #0000000000000000
    19fc:      	movi.2d	v30, #0000000000000000
    1a00:      	tbz	w11, #0x0, 0x1a40 <_llm_rows.packet_batch.blocks+0x11c8>
    1a04:      	ldr	s8, [x9]
    1a08:      	tbnz	w11, #0x1, 0x1a44 <_llm_rows.packet_batch.blocks+0x11cc>
    1a0c:      	tbz	w11, #0x2, 0x1a50 <_llm_rows.packet_batch.blocks+0x11d8>
    1a10:      	add	x12, x9, #0x8
    1a14:      	ld1.s	{ v8 }[2], [x12]
    1a18:      	tbnz	w11, #0x3, 0x1a54 <_llm_rows.packet_batch.blocks+0x11dc>
    1a1c:      	tbz	w11, #0x4, 0x1a60 <_llm_rows.packet_batch.blocks+0x11e8>
    1a20:      	add	x12, x9, #0x10
    1a24:      	ld1.s	{ v30 }[0], [x12]
    1a28:      	tbnz	w11, #0x5, 0x1a64 <_llm_rows.packet_batch.blocks+0x11ec>
    1a2c:      	tbz	w11, #0x6, 0x1a70 <_llm_rows.packet_batch.blocks+0x11f8>
    1a30:      	add	x12, x9, #0x18
    1a34:      	ld1.s	{ v30 }[2], [x12]
    1a38:      	tbnz	w11, #0x7, 0x1a74 <_llm_rows.packet_batch.blocks+0x11fc>
    1a3c:      	b	0x1a7c <_llm_rows.packet_batch.blocks+0x1204>
    1a40:      	tbz	w11, #0x1, 0x1a0c <_llm_rows.packet_batch.blocks+0x1194>
    1a44:      	add	x12, x9, #0x4
    1a48:      	ld1.s	{ v8 }[1], [x12]
    1a4c:      	tbnz	w11, #0x2, 0x1a10 <_llm_rows.packet_batch.blocks+0x1198>
    1a50:      	tbz	w11, #0x3, 0x1a1c <_llm_rows.packet_batch.blocks+0x11a4>
    1a54:      	add	x12, x9, #0xc
    1a58:      	ld1.s	{ v8 }[3], [x12]
    1a5c:      	tbnz	w11, #0x4, 0x1a20 <_llm_rows.packet_batch.blocks+0x11a8>
    1a60:      	tbz	w11, #0x5, 0x1a2c <_llm_rows.packet_batch.blocks+0x11b4>
    1a64:      	add	x12, x9, #0x14
    1a68:      	ld1.s	{ v30 }[1], [x12]
    1a6c:      	tbnz	w11, #0x6, 0x1a30 <_llm_rows.packet_batch.blocks+0x11b8>
    1a70:      	tbz	w11, #0x7, 0x1a7c <_llm_rows.packet_batch.blocks+0x1204>
    1a74:      	add	x9, x9, #0x1c
    1a78:      	ld1.s	{ v30 }[3], [x9]
    1a7c:      	umlal.2d	v23, v27, v25
    1a80:      	add.2d	v23, v23, v9
    1a84:      	umlal.2d	v22, v26, v25
    1a88:      	add.2d	v22, v22, v9
    1a8c:      	ldr	d24, [sp, #0xc0]
    1a90:      	umlal.2d	v21, v24, v25
    1a94:      	add.2d	v24, v21, v9
    1a98:      	fneg.4s	v21, v29
    1a9c:      	zip1.8b	v25, v19, v0
    1aa0:      	ushll.4s	v25, v25, #0x0
    1aa4:      	shl.4s	v25, v25, #0x1f
    1aa8:      	cmlt.4s	v25, v25, #0
    1aac:      	and.16b	v21, v25, v21
    1ab0:      	fcmge.4s	v25, v21, v1
    1ab4:      	fcmge.4s	v26, v0, v21
    1ab8:      	and.16b	v25, v25, v26
    1abc:      	and.16b	v25, v25, v21
    1ac0:      	fmul.4s	v26, v25, v18
    1ac4:      	movi.4s	v27, #0x4b, lsl #24
    1ac8:      	mvni.4s	v9, #0x80, lsl #24
    1acc:      	bif.16b	v27, v26, v9
    1ad0:      	fadd.4s	v26, v26, v27
    1ad4:      	fsub.4s	v26, v26, v27
    1ad8:      	fcvtzs.4s	v26, v26
    1adc:      	scvtf.4s	v27, v26
    1ae0:      	fmul.4s	v9, v27, v17
    1ae4:      	fadd.4s	v25, v25, v9
    1ae8:      	fmul.4s	v27, v27, v16
    1aec:      	fadd.4s	v25, v25, v27
    1af0:      	fmul.4s	v27, v25, v7
    1af4:      	fadd.4s	v27, v27, v6
    1af8:      	fmul.4s	v27, v25, v27
    1afc:      	fadd.4s	v27, v27, v5
    1b00:      	fmul.4s	v27, v25, v27
    1b04:      	fadd.4s	v27, v27, v4
    1b08:      	fmul.4s	v27, v25, v27
    1b0c:      	fadd.4s	v27, v27, v3
    1b10:      	fmul.4s	v27, v25, v27
    1b14:      	movi.4s	v9, #0x3f, lsl #24
    1b18:      	fadd.4s	v27, v27, v9
    1b1c:      	fmul.4s	v9, v25, v25
    1b20:      	fmul.4s	v27, v9, v27
    1b24:      	fadd.4s	v25, v25, v27
    1b28:      	fadd.4s	v25, v25, v2
    1b2c:      	sshr.4s	v27, v26, #0x1
    1b30:      	shl.4s	v9, v27, #0x17
    1b34:      	add.4s	v9, v9, v2
    1b38:      	fmul.4s	v25, v25, v9
    1b3c:      	sub.4s	v26, v26, v27
    1b40:      	shl.4s	v26, v26, #0x17
    1b44:      	add.4s	v26, v26, v2
    1b48:      	fmul.4s	v25, v25, v26
    1b4c:      	fcmgt.4s	v26, v1, v21
    1b50:      	fcmgt.4s	v27, v21, v0
    1b54:      	fcmeq.4s	v21, v21, v21
    1b58:      	fadd.4s	v25, v25, v2
    1b5c:      	bit.16b	v25, v2, v26
    1b60:      	ldr	q26, [sp, #0x110]
    1b64:      	bit.16b	v25, v26, v27
    1b68:      	ldr	q26, [sp, #0x100]
    1b6c:      	bsl.16b	v21, v25, v26
    1b70:      	fdiv.4s	v21, v29, v21
    1b74:      	fmul.4s	v21, v8, v21
    1b78:      	stp	q28, q23, [sp, #0x120]
    1b7c:      	stp	q22, q24, [sp, #0x140]
    1b80:      	and	x9, x10, #0x7
    1b84:      	add	x11, sp, #0x120
    1b88:      	ldr	x9, [x11, x9, lsl #3]
    1b8c:      	sub	x9, x9, x10
    1b90:      	add	x8, x8, x9, lsl #2
    1b94:      	fmov	w9, s31
    1b98:      	tbz	w9, #0x0, 0x1bb8 <_llm_rows.packet_batch.blocks+0x1340>
    1b9c:      	str	s21, [x8]
    1ba0:      	tbnz	w9, #0x1, 0x1bbc <_llm_rows.packet_batch.blocks+0x1344>
    1ba4:      	tbz	w9, #0x2, 0x1bc8 <_llm_rows.packet_batch.blocks+0x1350>
    1ba8:      	add	x10, x8, #0x8
    1bac:      	st1.s	{ v21 }[2], [x10]
    1bb0:      	tbnz	w9, #0x3, 0x1bcc <_llm_rows.packet_batch.blocks+0x1354>
    1bb4:      	b	0x1bd4 <_llm_rows.packet_batch.blocks+0x135c>
    1bb8:      	tbz	w9, #0x1, 0x1ba4 <_llm_rows.packet_batch.blocks+0x132c>
    1bbc:      	add	x10, x8, #0x4
    1bc0:      	st1.s	{ v21 }[1], [x10]
    1bc4:      	tbnz	w9, #0x2, 0x1ba8 <_llm_rows.packet_batch.blocks+0x1330>
    1bc8:      	tbz	w9, #0x3, 0x1bd4 <_llm_rows.packet_batch.blocks+0x135c>
    1bcc:      	add	x10, x8, #0xc
    1bd0:      	st1.s	{ v21 }[3], [x10]
    1bd4:      	fneg.4s	v21, v20
    1bd8:      	zip2.8b	v19, v19, v0
    1bdc:      	ushll.4s	v19, v19, #0x0
    1be0:      	shl.4s	v19, v19, #0x1f
    1be4:      	cmlt.4s	v19, v19, #0
    1be8:      	and.16b	v19, v19, v21
    1bec:      	fcmge.4s	v21, v19, v1
    1bf0:      	fcmge.4s	v22, v0, v19
    1bf4:      	and.16b	v21, v21, v22
    1bf8:      	and.16b	v21, v21, v19
    1bfc:      	fmul.4s	v18, v21, v18
    1c00:      	movi.4s	v22, #0x4b, lsl #24
    1c04:      	mvni.4s	v23, #0x80, lsl #24
    1c08:      	bif.16b	v22, v18, v23
    1c0c:      	fadd.4s	v18, v18, v22
    1c10:      	fsub.4s	v18, v18, v22
    1c14:      	fcvtzs.4s	v18, v18
    1c18:      	scvtf.4s	v22, v18
    1c1c:      	fmul.4s	v17, v22, v17
    1c20:      	fadd.4s	v17, v21, v17
    1c24:      	fmul.4s	v16, v22, v16
    1c28:      	fadd.4s	v16, v17, v16
    1c2c:      	fmul.4s	v7, v16, v7
    1c30:      	fadd.4s	v6, v7, v6
    1c34:      	fmul.4s	v6, v16, v6
    1c38:      	fadd.4s	v5, v6, v5
    1c3c:      	fmul.4s	v5, v16, v5
    1c40:      	fadd.4s	v4, v5, v4
    1c44:      	fmul.4s	v4, v16, v4
    1c48:      	fadd.4s	v3, v4, v3
    1c4c:      	fmul.4s	v3, v16, v3
    1c50:      	movi.4s	v4, #0x3f, lsl #24
    1c54:      	fadd.4s	v3, v3, v4
    1c58:      	fmul.4s	v4, v16, v16
    1c5c:      	fmul.4s	v3, v4, v3
    1c60:      	fadd.4s	v3, v16, v3
    1c64:      	fadd.4s	v3, v3, v2
    1c68:      	sshr.4s	v4, v18, #0x1
    1c6c:      	shl.4s	v5, v4, #0x17
    1c70:      	add.4s	v5, v5, v2
    1c74:      	fmul.4s	v3, v3, v5
    1c78:      	sub.4s	v4, v18, v4
    1c7c:      	shl.4s	v4, v4, #0x17
    1c80:      	add.4s	v4, v4, v2
    1c84:      	fmul.4s	v3, v3, v4
    1c88:      	fcmgt.4s	v1, v1, v19
    1c8c:      	fcmgt.4s	v0, v19, v0
    1c90:      	fcmeq.4s	v4, v19, v19
    1c94:      	fadd.4s	v3, v3, v2
    1c98:      	bsl.16b	v1, v2, v3
    1c9c:      	ldr	q2, [sp, #0x110]
    1ca0:      	bsl.16b	v0, v2, v1
    1ca4:      	ldr	q1, [sp, #0x100]
    1ca8:      	bif.16b	v0, v1, v4
    1cac:      	fdiv.4s	v0, v20, v0
    1cb0:      	fmul.4s	v0, v30, v0
    1cb4:      	tbnz	w9, #0x4, 0x18b4 <_llm_rows.packet_batch.blocks+0x103c>
    1cb8:      	tbz	w9, #0x5, 0x18bc <_llm_rows.packet_batch.blocks+0x1044>
    1cbc:      	add	x10, x8, #0x14
    1cc0:      	st1.s	{ v0 }[1], [x10]
    1cc4:      	tbnz	w9, #0x6, 0x18c0 <_llm_rows.packet_batch.blocks+0x1048>
    1cc8:      	tbz	w9, #0x7, 0x948 <_llm_rows.packet_batch.blocks+0xd0>
    1ccc:      	add	x8, x8, #0x1c
    1cd0:      	st1.s	{ v0 }[3], [x8]
    1cd4:      	b	0x948 <_llm_rows.packet_batch.blocks+0xd0>
    1cd8:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    1cdc:      	add	sp, sp, #0x2d0
    1ce0:      	ldp	x29, x30, [sp, #0x90]
    1ce4:      	ldp	x20, x19, [sp, #0x80]
    1ce8:      	ldp	x22, x21, [sp, #0x70]
    1cec:      	ldp	x24, x23, [sp, #0x60]
    1cf0:      	ldp	x26, x25, [sp, #0x50]
    1cf4:      	ldp	x28, x27, [sp, #0x40]
    1cf8:      	ldp	d9, d8, [sp, #0x30]
    1cfc:      	ldp	d11, d10, [sp, #0x20]
    1d00:      	ldp	d13, d12, [sp, #0x10]
    1d04:      	ldp	d15, d14, [sp], #0xa0
    1d08:      	ret

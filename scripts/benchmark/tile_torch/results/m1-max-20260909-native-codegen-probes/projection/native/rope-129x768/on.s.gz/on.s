
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/rope-129x768/on/object/tile_xir_w8_38084_1788936547867949_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x28, x27, [sp, #-0x60]!
       4:      	stp	x26, x25, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	stp	x29, x30, [sp, #0x50]
      18:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      1c:      	sub	sp, sp, #0x800
      20:      	ldr	x11, [x0]
      24:      	ldr	x22, [x0, #0x10]
      28:      	ldr	x21, [x0, #0x20]
      2c:      	ldr	x20, [x0, #0x30]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w9, w8, #3
      40:      	subs	x8, x11, x20
      44:      	lsr	x8, x8, #10
      48:      	mov	w10, #0x182             ; =386
      4c:      	ccmp	x8, x10, #0x0, hs
      50:      	cset	w8, hi
      54:      	subs	x12, x20, x11
      58:      	lsr	x12, x12, #10
      5c:      	ccmp	x12, x10, #0x0, hs
      60:      	csinc	w12, w8, wzr, ls
      64:      	subs	x8, x22, x20
      68:      	lsr	x8, x8, #10
      6c:      	ccmp	x8, x10, #0x0, hs
      70:      	cset	w8, hi
      74:      	subs	x13, x20, x22
      78:      	lsr	x13, x13, #9
      7c:      	ccmp	x13, x10, #0x0, hs
      80:      	csinc	w8, w8, wzr, ls
      84:      	subs	x13, x21, x20
      88:      	lsr	x13, x13, #10
      8c:      	ccmp	x13, x10, #0x0, hs
      90:      	cset	w13, hi
      94:      	subs	x14, x20, x21
      98:      	lsr	x14, x14, #9
      9c:      	ccmp	x14, x10, #0x0, hs
      a0:      	csinc	w10, w13, wzr, ls
      a4:      	cmp	w10, #0x1
      a8:      	ccmp	w12, #0x0, #0x4, eq
      ac:      	b.eq	0x148 <ltmp0+0x148>
      b0:      	tbz	w8, #0x0, 0x148 <ltmp0+0x148>
      b4:      	mov	x8, #0x0                ; =0
      b8:      	add	x12, x9, x9, lsl #1
      bc:      	lsl	x10, x12, #9
      c0:      	add	x9, x22, x10
      c4:      	add	x10, x21, x10
      c8:      	lsl	x12, x12, #10
      cc:      	add	x11, x11, x12
      d0:      	add	x12, x20, x12
      d4:      	ldp	q1, q0, [x11]
      d8:      	ldr	q2, [x11, #0x610]
      dc:      	ldr	q3, [x11, #0x600]
      e0:      	lsl	x13, x8, #5
      e4:      	add	x14, x9, x13
      e8:      	ldp	q5, q4, [x14]
      ec:      	add	x13, x10, x13
      f0:      	ldp	q7, q6, [x13]
      f4:      	fmul.4s	v16, v1, v5
      f8:      	fmul.4s	v17, v0, v4
      fc:      	fmul.4s	v18, v3, v7
     100:      	fmul.4s	v19, v2, v6
     104:      	fsub.4s	v17, v17, v19
     108:      	fsub.4s	v16, v16, v18
     10c:      	stp	q16, q17, [x12]
     110:      	fmul.4s	v1, v1, v7
     114:      	fmul.4s	v0, v0, v6
     118:      	fmul.4s	v3, v3, v5
     11c:      	fmul.4s	v2, v2, v4
     120:      	fadd.4s	v0, v2, v0
     124:      	fadd.4s	v1, v3, v1
     128:      	str	q1, [x12, #0x600]
     12c:      	str	q0, [x12, #0x610]
     130:      	add	x8, x8, #0x1
     134:      	add	x11, x11, #0x20
     138:      	add	x12, x12, #0x20
     13c:      	cmp	x8, #0x30
     140:      	b.ne	0xd4 <ltmp0+0xd4>
     144:      	b	0x26c <ltmp0+0x26c>
     148:      	add	x25, x9, x9, lsl #1
     14c:      	lsl	x26, x25, #10
     150:      	add	x19, x11, x26
     154:      	add	x23, sp, #0x1, lsl #12  ; =0x1000
     158:      	add	x23, x23, #0x200
     15c:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     160:      	add	x0, x0, #0x200
     164:      	mov	x1, x19
     168:      	mov	w2, #0x600              ; =1536
     16c:      	bl	0x16c <ltmp0+0x16c>
     170:      	add	x24, sp, #0xc00
     174:      	add	x0, sp, #0xc00
     178:      	add	x1, x19, #0x600
     17c:      	mov	w2, #0x600              ; =1536
     180:      	bl	0x180 <ltmp0+0x180>
     184:      	lsl	x25, x25, #9
     188:      	add	x19, sp, #0x600
     18c:      	add	x0, sp, #0x600
     190:      	add	x1, x22, x25
     194:      	mov	w2, #0x600              ; =1536
     198:      	bl	0x198 <ltmp0+0x198>
     19c:      	mov	x22, sp
     1a0:      	mov	x0, sp
     1a4:      	add	x1, x21, x25
     1a8:      	mov	w2, #0x600              ; =1536
     1ac:      	bl	0x1ac <ltmp0+0x1ac>
     1b0:      	mov	x8, #0x0                ; =0
     1b4:      	add	x9, x20, x26
     1b8:      	add	x10, x23, x8
     1bc:      	ldp	q0, q1, [x10]
     1c0:      	add	x10, x19, x8
     1c4:      	ldp	q2, q3, [x10]
     1c8:      	fmul.4s	v1, v1, v3
     1cc:      	fmul.4s	v0, v0, v2
     1d0:      	add	x10, x24, x8
     1d4:      	ldp	q2, q3, [x10]
     1d8:      	add	x10, x22, x8
     1dc:      	ldp	q4, q5, [x10]
     1e0:      	fmul.4s	v3, v3, v5
     1e4:      	fmul.4s	v2, v2, v4
     1e8:      	fsub.4s	v0, v0, v2
     1ec:      	fsub.4s	v1, v1, v3
     1f0:      	add	x10, x9, x8
     1f4:      	stp	q0, q1, [x10]
     1f8:      	add	x8, x8, #0x20
     1fc:      	cmp	x8, #0x600
     200:      	b.ne	0x1b8 <ltmp0+0x1b8>
     204:      	mov	x8, #0x0                ; =0
     208:      	add	x9, x9, #0x600
     20c:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     210:      	add	x10, x10, #0x200
     214:      	mov	x11, sp
     218:      	add	x12, sp, #0xc00
     21c:      	add	x13, sp, #0x600
     220:      	add	x14, x10, x8
     224:      	ldp	q0, q1, [x14]
     228:      	add	x14, x11, x8
     22c:      	ldp	q2, q3, [x14]
     230:      	fmul.4s	v1, v1, v3
     234:      	fmul.4s	v0, v0, v2
     238:      	add	x14, x12, x8
     23c:      	ldp	q2, q3, [x14]
     240:      	add	x14, x13, x8
     244:      	ldp	q4, q5, [x14]
     248:      	fmul.4s	v3, v3, v5
     24c:      	fmul.4s	v2, v2, v4
     250:      	fadd.4s	v0, v0, v2
     254:      	fadd.4s	v1, v1, v3
     258:      	add	x14, x9, x8
     25c:      	stp	q0, q1, [x14]
     260:      	add	x8, x8, #0x20
     264:      	cmp	x8, #0x600
     268:      	b.ne	0x220 <ltmp0+0x220>
     26c:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
     270:      	add	sp, sp, #0x800
     274:      	ldp	x29, x30, [sp, #0x50]
     278:      	ldp	x20, x19, [sp, #0x40]
     27c:      	ldp	x22, x21, [sp, #0x30]
     280:      	ldp	x24, x23, [sp, #0x20]
     284:      	ldp	x26, x25, [sp, #0x10]
     288:      	ldp	x28, x27, [sp], #0x60
     28c:      	ret

0000000000000290 <_llm_rows.packet_batch.blocks>:
     290:      	stp	x28, x27, [sp, #-0x60]!
     294:      	stp	x26, x25, [sp, #0x10]
     298:      	stp	x24, x23, [sp, #0x20]
     29c:      	stp	x22, x21, [sp, #0x30]
     2a0:      	stp	x20, x19, [sp, #0x40]
     2a4:      	stp	x29, x30, [sp, #0x50]
     2a8:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
     2ac:      	sub	sp, sp, #0x880
     2b0:      	str	x0, [sp, #0x68]
     2b4:      	cbz	w3, 0xe94 <_llm_rows.packet_batch.blocks+0xc04>
     2b8:      	mov	x21, x3
     2bc:      	mov	x20, x2
     2c0:      	mov	w22, #0x0               ; =0
     2c4:      	ldp	w9, w8, [x2, #0x2c]
     2c8:      	stp	w8, w9, [sp, #0x60]
     2cc:      	ldp	w28, w26, [x2]
     2d0:      	adrp	x8, 0x0 <ltmp0>
     2d4:      	ldr	q0, [x8]
     2d8:      	str	q0, [sp, #0x20]
     2dc:      	adrp	x8, 0x0 <ltmp0>
     2e0:      	ldr	q0, [x8]
     2e4:      	str	q0, [sp, #0x10]
     2e8:      	adrp	x8, 0x0 <ltmp0>
     2ec:      	ldr	q19, [x8]
     2f0:      	add	x4, sp, #0x1, lsl #12   ; =0x1000
     2f4:      	add	x4, x4, #0x280
     2f8:      	add	x25, sp, #0xc80
     2fc:      	add	x23, sp, #0x680
     300:      	add	x24, sp, #0x80
     304:      	ldp	w19, w8, [x2, #0x8]
     308:      	str	x8, [sp, #0x58]
     30c:      	str	q19, [sp, #0x40]
     310:      	str	w3, [sp, #0x3c]
     314:      	b	0x35c <_llm_rows.packet_batch.blocks+0xcc>
     318:      	mov	w8, #0x18               ; =24
     31c:      	str	w8, [x20, #0x24]
     320:      	ldr	w21, [sp, #0x3c]
     324:      	add	w8, w28, #0x1
     328:      	ldp	w10, w9, [sp, #0x60]
     32c:      	cmp	w8, w9
     330:      	cset	w8, eq
     334:      	csinc	w28, wzr, w28, eq
     338:      	cinc	w9, w26, eq
     33c:      	cmp	w9, w10
     340:      	cset	w10, eq
     344:      	ands	w8, w8, w10
     348:      	csel	w26, wzr, w9, ne
     34c:      	add	w19, w19, w8
     350:      	add	w22, w22, #0x1
     354:      	cmp	w22, w21
     358:      	b.eq	0xe94 <_llm_rows.packet_batch.blocks+0xc04>
     35c:      	ubfiz	x8, x28, #5, #32
     360:      	ldr	x12, [sp, #0x58]
     364:      	cmp	x8, x12
     368:      	csel	x9, x8, xzr, ls
     36c:      	subs	x10, x12, x9
     370:      	cmp	x10, #0x20
     374:      	mov	w11, #0x20              ; =32
     378:      	csel	x10, x10, x11, lo
     37c:      	cmp	x12, x9
     380:      	stp	w28, w26, [x20]
     384:      	str	w19, [x20, #0x8]
     388:      	str	wzr, [x20, #0x24]
     38c:      	ccmp	x8, x12, #0x2, hi
     390:      	csel	x27, x10, xzr, ls
     394:      	cmp	x27, #0x20
     398:      	b.lo	0x3f8 <_llm_rows.packet_batch.blocks+0x168>
     39c:      	ldr	x27, [sp, #0x68]
     3a0:      	mov	x0, x27
     3a4:      	mov	x1, x20
     3a8:      	bl	0x3a8 <_llm_rows.packet_batch.blocks+0x118>
     3ac:      	mov	w8, #0x8                ; =8
     3b0:      	str	w8, [x20, #0x24]
     3b4:      	mov	x0, x27
     3b8:      	mov	x1, x20
     3bc:      	bl	0x3bc <_llm_rows.packet_batch.blocks+0x12c>
     3c0:      	mov	w8, #0x10               ; =16
     3c4:      	str	w8, [x20, #0x24]
     3c8:      	mov	x0, x27
     3cc:      	mov	x1, x20
     3d0:      	bl	0x3d0 <_llm_rows.packet_batch.blocks+0x140>
     3d4:      	mov	w8, #0x18               ; =24
     3d8:      	str	w8, [x20, #0x24]
     3dc:      	mov	x0, x27
     3e0:      	mov	x1, x20
     3e4:      	bl	0x3e4 <_llm_rows.packet_batch.blocks+0x154>
     3e8:      	add	x4, sp, #0x1, lsl #12   ; =0x1000
     3ec:      	add	x4, x4, #0x280
     3f0:      	ldr	q19, [sp, #0x40]
     3f4:      	b	0x324 <_llm_rows.packet_batch.blocks+0x94>
     3f8:      	lsr	x21, x27, #3
     3fc:      	cmp	x27, #0x8
     400:      	b.lo	0x470 <_llm_rows.packet_batch.blocks+0x1e0>
     404:      	str	wzr, [x20, #0x24]
     408:      	ldr	x0, [sp, #0x68]
     40c:      	mov	x1, x20
     410:      	bl	0x410 <_llm_rows.packet_batch.blocks+0x180>
     414:      	add	x4, sp, #0x1, lsl #12   ; =0x1000
     418:      	add	x4, x4, #0x280
     41c:      	ldr	q19, [sp, #0x40]
     420:      	cmp	x21, #0x1
     424:      	b.eq	0x470 <_llm_rows.packet_batch.blocks+0x1e0>
     428:      	mov	w8, #0x8                ; =8
     42c:      	str	w8, [x20, #0x24]
     430:      	ldr	x0, [sp, #0x68]
     434:      	mov	x1, x20
     438:      	bl	0x438 <_llm_rows.packet_batch.blocks+0x1a8>
     43c:      	add	x4, sp, #0x1, lsl #12   ; =0x1000
     440:      	add	x4, x4, #0x280
     444:      	ldr	q19, [sp, #0x40]
     448:      	cmp	x21, #0x2
     44c:      	b.eq	0x470 <_llm_rows.packet_batch.blocks+0x1e0>
     450:      	mov	w8, #0x10               ; =16
     454:      	str	w8, [x20, #0x24]
     458:      	ldr	x0, [sp, #0x68]
     45c:      	mov	x1, x20
     460:      	bl	0x460 <_llm_rows.packet_batch.blocks+0x1d0>
     464:      	add	x4, sp, #0x1, lsl #12   ; =0x1000
     468:      	add	x4, x4, #0x280
     46c:      	ldr	q19, [sp, #0x40]
     470:      	and	w8, w27, #0x7
     474:      	cbz	w8, 0x318 <_llm_rows.packet_batch.blocks+0x88>
     478:      	dup.4s	v2, w8
     47c:      	ldp	q0, q1, [sp, #0x10]
     480:      	cmhi.4s	v0, v2, v0
     484:      	cmhi.4s	v1, v2, v1
     488:      	uzp1.8h	v3, v1, v0
     48c:      	umaxv.8h	h4, v3
     490:      	fmov	w8, s4
     494:      	tbz	w8, #0x0, 0x318 <_llm_rows.packet_batch.blocks+0x88>
     498:      	ldr	x8, [sp, #0x68]
     49c:      	ldr	x9, [x8]
     4a0:      	ldr	x14, [x8, #0x10]
     4a4:      	ldr	x13, [x8, #0x20]
     4a8:      	ldr	x8, [x8, #0x30]
     4ac:      	ubfiz	w10, w28, #2, #27
     4b0:      	orr	w15, w10, w21
     4b4:      	subs	x10, x9, x8
     4b8:      	mov	w16, #0xbff             ; =3071
     4bc:      	movk	w16, #0x6, lsl #16
     4c0:      	ccmp	x10, x16, #0x0, hs
     4c4:      	cset	w10, hi
     4c8:      	subs	x11, x8, x9
     4cc:      	ccmp	x11, x16, #0x0, hs
     4d0:      	csinc	w11, w10, wzr, ls
     4d4:      	subs	x10, x14, x8
     4d8:      	ccmp	x10, x16, #0x0, hs
     4dc:      	cset	w10, hi
     4e0:      	subs	x12, x8, x14
     4e4:      	mov	w17, #0x5ff             ; =1535
     4e8:      	movk	w17, #0x3, lsl #16
     4ec:      	ccmp	x12, x17, #0x0, hs
     4f0:      	csinc	w12, w10, wzr, ls
     4f4:      	subs	x10, x13, x8
     4f8:      	ccmp	x10, x16, #0x0, hs
     4fc:      	cset	w10, hi
     500:      	subs	x16, x8, x13
     504:      	ccmp	x16, x17, #0x0, hs
     508:      	csinc	w16, w10, wzr, ls
     50c:      	fmov	w10, s2
     510:      	cmp	w10, #0x0
     514:      	cset	w10, ne
     518:      	cmp	w16, #0x1
     51c:      	b.ne	0x980 <_llm_rows.packet_batch.blocks+0x6f0>
     520:      	cbz	w11, 0x980 <_llm_rows.packet_batch.blocks+0x6f0>
     524:      	tbz	w12, #0x0, 0x980 <_llm_rows.packet_batch.blocks+0x6f0>
     528:      	mov	x11, #0x0               ; =0
     52c:      	add	x15, x15, x15, lsl #1
     530:      	lsl	x12, x15, #8
     534:      	add	x16, x12, #0x180
     538:      	cmp	w10, #0x0
     53c:      	mov	w17, #0x180             ; =384
     540:      	csel	x16, x16, x17, ne
     544:      	lsl	x15, x15, #7
     548:      	csel	x15, x15, xzr, ne
     54c:      	lsl	x15, x15, #2
     550:      	add	x13, x13, x15
     554:      	add	x14, x14, x15
     558:      	lsl	x16, x16, #2
     55c:      	add	x15, x8, x16
     560:      	add	x16, x9, x16
     564:      	and.16b	v0, v3, v19
     568:      	addv.8h	h0, v0
     56c:      	fmov	w17, s0
     570:      	b	0x590 <_llm_rows.packet_batch.blocks+0x300>
     574:      	add	x11, x11, #0x8
     578:      	add	x13, x13, #0x20
     57c:      	add	x14, x14, #0x20
     580:      	add	x15, x15, #0x20
     584:      	add	x16, x16, #0x20
     588:      	cmp	x11, #0x180
     58c:      	b.eq	0x318 <_llm_rows.packet_batch.blocks+0x88>
     590:      	cmp	w10, #0x0
     594:      	csel	x0, x12, xzr, ne
     598:      	add	x0, x0, x11
     59c:      	lsl	x0, x0, #2
     5a0:      	add	x1, x9, x0
     5a4:      	movi.2d	v2, #0000000000000000
     5a8:      	movi.2d	v1, #0000000000000000
     5ac:      	tbnz	w17, #0x0, 0x6e8 <_llm_rows.packet_batch.blocks+0x458>
     5b0:      	and	w2, w17, #0xff
     5b4:      	tbnz	w2, #0x1, 0x6f4 <_llm_rows.packet_batch.blocks+0x464>
     5b8:      	tbnz	w2, #0x2, 0x700 <_llm_rows.packet_batch.blocks+0x470>
     5bc:      	tbnz	w2, #0x3, 0x70c <_llm_rows.packet_batch.blocks+0x47c>
     5c0:      	tbnz	w2, #0x4, 0x718 <_llm_rows.packet_batch.blocks+0x488>
     5c4:      	tbnz	w2, #0x5, 0x724 <_llm_rows.packet_batch.blocks+0x494>
     5c8:      	tbnz	w2, #0x6, 0x730 <_llm_rows.packet_batch.blocks+0x4a0>
     5cc:      	tbnz	w2, #0x7, 0x73c <_llm_rows.packet_batch.blocks+0x4ac>
     5d0:      	fmov	w1, s0
     5d4:      	movi.2d	v4, #0000000000000000
     5d8:      	movi.2d	v3, #0000000000000000
     5dc:      	tbnz	w1, #0x0, 0x754 <_llm_rows.packet_batch.blocks+0x4c4>
     5e0:      	and	w1, w1, #0xff
     5e4:      	tbnz	w1, #0x1, 0x760 <_llm_rows.packet_batch.blocks+0x4d0>
     5e8:      	tbnz	w1, #0x2, 0x76c <_llm_rows.packet_batch.blocks+0x4dc>
     5ec:      	tbnz	w1, #0x3, 0x778 <_llm_rows.packet_batch.blocks+0x4e8>
     5f0:      	tbnz	w1, #0x4, 0x784 <_llm_rows.packet_batch.blocks+0x4f4>
     5f4:      	tbnz	w1, #0x5, 0x790 <_llm_rows.packet_batch.blocks+0x500>
     5f8:      	tbnz	w1, #0x6, 0x79c <_llm_rows.packet_batch.blocks+0x50c>
     5fc:      	tbnz	w1, #0x7, 0x7a8 <_llm_rows.packet_batch.blocks+0x518>
     600:      	fmov	w1, s0
     604:      	movi.2d	v6, #0000000000000000
     608:      	movi.2d	v5, #0000000000000000
     60c:      	tbnz	w1, #0x0, 0x7c0 <_llm_rows.packet_batch.blocks+0x530>
     610:      	and	w1, w1, #0xff
     614:      	tbnz	w1, #0x1, 0x7cc <_llm_rows.packet_batch.blocks+0x53c>
     618:      	tbnz	w1, #0x2, 0x7d8 <_llm_rows.packet_batch.blocks+0x548>
     61c:      	tbnz	w1, #0x3, 0x7e4 <_llm_rows.packet_batch.blocks+0x554>
     620:      	tbnz	w1, #0x4, 0x7f0 <_llm_rows.packet_batch.blocks+0x560>
     624:      	tbnz	w1, #0x5, 0x7fc <_llm_rows.packet_batch.blocks+0x56c>
     628:      	tbnz	w1, #0x6, 0x808 <_llm_rows.packet_batch.blocks+0x578>
     62c:      	tbnz	w1, #0x7, 0x814 <_llm_rows.packet_batch.blocks+0x584>
     630:      	fmov	w1, s0
     634:      	movi.2d	v16, #0000000000000000
     638:      	movi.2d	v7, #0000000000000000
     63c:      	tbnz	w1, #0x0, 0x82c <_llm_rows.packet_batch.blocks+0x59c>
     640:      	and	w1, w1, #0xff
     644:      	tbnz	w1, #0x1, 0x838 <_llm_rows.packet_batch.blocks+0x5a8>
     648:      	tbnz	w1, #0x2, 0x844 <_llm_rows.packet_batch.blocks+0x5b4>
     64c:      	tbnz	w1, #0x3, 0x850 <_llm_rows.packet_batch.blocks+0x5c0>
     650:      	tbnz	w1, #0x4, 0x85c <_llm_rows.packet_batch.blocks+0x5cc>
     654:      	tbnz	w1, #0x5, 0x868 <_llm_rows.packet_batch.blocks+0x5d8>
     658:      	tbnz	w1, #0x6, 0x874 <_llm_rows.packet_batch.blocks+0x5e4>
     65c:      	tbnz	w1, #0x7, 0x880 <_llm_rows.packet_batch.blocks+0x5f0>
     660:      	fmov	w1, s0
     664:      	fmul.4s	v17, v2, v6
     668:      	fmul.4s	v18, v4, v16
     66c:      	fsub.4s	v17, v17, v18
     670:      	add	x0, x8, x0
     674:      	tbnz	w1, #0x0, 0x8a0 <_llm_rows.packet_batch.blocks+0x610>
     678:      	and	w1, w1, #0xff
     67c:      	tbnz	w1, #0x1, 0x8ac <_llm_rows.packet_batch.blocks+0x61c>
     680:      	tbnz	w1, #0x2, 0x8b8 <_llm_rows.packet_batch.blocks+0x628>
     684:      	tbnz	w1, #0x3, 0x8c4 <_llm_rows.packet_batch.blocks+0x634>
     688:      	fmul.4s	v17, v1, v5
     68c:      	fmul.4s	v18, v3, v7
     690:      	fsub.4s	v17, v17, v18
     694:      	tbnz	w1, #0x4, 0x8dc <_llm_rows.packet_batch.blocks+0x64c>
     698:      	tbnz	w1, #0x5, 0x8e4 <_llm_rows.packet_batch.blocks+0x654>
     69c:      	tbnz	w1, #0x6, 0x8f0 <_llm_rows.packet_batch.blocks+0x660>
     6a0:      	tbnz	w1, #0x7, 0x8fc <_llm_rows.packet_batch.blocks+0x66c>
     6a4:      	fmov	w0, s0
     6a8:      	fmul.4s	v2, v2, v16
     6ac:      	fmul.4s	v4, v4, v6
     6b0:      	fadd.4s	v2, v4, v2
     6b4:      	tbnz	w0, #0x0, 0x918 <_llm_rows.packet_batch.blocks+0x688>
     6b8:      	and	w0, w0, #0xff
     6bc:      	tbnz	w0, #0x1, 0x924 <_llm_rows.packet_batch.blocks+0x694>
     6c0:      	tbnz	w0, #0x2, 0x930 <_llm_rows.packet_batch.blocks+0x6a0>
     6c4:      	tbnz	w0, #0x3, 0x93c <_llm_rows.packet_batch.blocks+0x6ac>
     6c8:      	fmul.4s	v1, v1, v7
     6cc:      	fmul.4s	v2, v3, v5
     6d0:      	fadd.4s	v1, v2, v1
     6d4:      	tbnz	w0, #0x4, 0x954 <_llm_rows.packet_batch.blocks+0x6c4>
     6d8:      	tbnz	w0, #0x5, 0x95c <_llm_rows.packet_batch.blocks+0x6cc>
     6dc:      	tbnz	w0, #0x6, 0x968 <_llm_rows.packet_batch.blocks+0x6d8>
     6e0:      	tbz	w0, #0x7, 0x574 <_llm_rows.packet_batch.blocks+0x2e4>
     6e4:      	b	0x974 <_llm_rows.packet_batch.blocks+0x6e4>
     6e8:      	ldr	s2, [x1]
     6ec:      	and	w2, w17, #0xff
     6f0:      	tbz	w2, #0x1, 0x5b8 <_llm_rows.packet_batch.blocks+0x328>
     6f4:      	add	x3, x1, #0x4
     6f8:      	ld1.s	{ v2 }[1], [x3]
     6fc:      	tbz	w2, #0x2, 0x5bc <_llm_rows.packet_batch.blocks+0x32c>
     700:      	add	x3, x1, #0x8
     704:      	ld1.s	{ v2 }[2], [x3]
     708:      	tbz	w2, #0x3, 0x5c0 <_llm_rows.packet_batch.blocks+0x330>
     70c:      	add	x3, x1, #0xc
     710:      	ld1.s	{ v2 }[3], [x3]
     714:      	tbz	w2, #0x4, 0x5c4 <_llm_rows.packet_batch.blocks+0x334>
     718:      	add	x3, x1, #0x10
     71c:      	ld1.s	{ v1 }[0], [x3]
     720:      	tbz	w2, #0x5, 0x5c8 <_llm_rows.packet_batch.blocks+0x338>
     724:      	add	x3, x1, #0x14
     728:      	ld1.s	{ v1 }[1], [x3]
     72c:      	tbz	w2, #0x6, 0x5cc <_llm_rows.packet_batch.blocks+0x33c>
     730:      	add	x3, x1, #0x18
     734:      	ld1.s	{ v1 }[2], [x3]
     738:      	tbz	w2, #0x7, 0x5d0 <_llm_rows.packet_batch.blocks+0x340>
     73c:      	add	x1, x1, #0x1c
     740:      	ld1.s	{ v1 }[3], [x1]
     744:      	fmov	w1, s0
     748:      	movi.2d	v4, #0000000000000000
     74c:      	movi.2d	v3, #0000000000000000
     750:      	tbz	w1, #0x0, 0x5e0 <_llm_rows.packet_batch.blocks+0x350>
     754:      	ldr	s4, [x16]
     758:      	and	w1, w1, #0xff
     75c:      	tbz	w1, #0x1, 0x5e8 <_llm_rows.packet_batch.blocks+0x358>
     760:      	add	x2, x16, #0x4
     764:      	ld1.s	{ v4 }[1], [x2]
     768:      	tbz	w1, #0x2, 0x5ec <_llm_rows.packet_batch.blocks+0x35c>
     76c:      	add	x2, x16, #0x8
     770:      	ld1.s	{ v4 }[2], [x2]
     774:      	tbz	w1, #0x3, 0x5f0 <_llm_rows.packet_batch.blocks+0x360>
     778:      	add	x2, x16, #0xc
     77c:      	ld1.s	{ v4 }[3], [x2]
     780:      	tbz	w1, #0x4, 0x5f4 <_llm_rows.packet_batch.blocks+0x364>
     784:      	add	x2, x16, #0x10
     788:      	ld1.s	{ v3 }[0], [x2]
     78c:      	tbz	w1, #0x5, 0x5f8 <_llm_rows.packet_batch.blocks+0x368>
     790:      	add	x2, x16, #0x14
     794:      	ld1.s	{ v3 }[1], [x2]
     798:      	tbz	w1, #0x6, 0x5fc <_llm_rows.packet_batch.blocks+0x36c>
     79c:      	add	x2, x16, #0x18
     7a0:      	ld1.s	{ v3 }[2], [x2]
     7a4:      	tbz	w1, #0x7, 0x600 <_llm_rows.packet_batch.blocks+0x370>
     7a8:      	add	x1, x16, #0x1c
     7ac:      	ld1.s	{ v3 }[3], [x1]
     7b0:      	fmov	w1, s0
     7b4:      	movi.2d	v6, #0000000000000000
     7b8:      	movi.2d	v5, #0000000000000000
     7bc:      	tbz	w1, #0x0, 0x610 <_llm_rows.packet_batch.blocks+0x380>
     7c0:      	ldr	s6, [x14]
     7c4:      	and	w1, w1, #0xff
     7c8:      	tbz	w1, #0x1, 0x618 <_llm_rows.packet_batch.blocks+0x388>
     7cc:      	add	x2, x14, #0x4
     7d0:      	ld1.s	{ v6 }[1], [x2]
     7d4:      	tbz	w1, #0x2, 0x61c <_llm_rows.packet_batch.blocks+0x38c>
     7d8:      	add	x2, x14, #0x8
     7dc:      	ld1.s	{ v6 }[2], [x2]
     7e0:      	tbz	w1, #0x3, 0x620 <_llm_rows.packet_batch.blocks+0x390>
     7e4:      	add	x2, x14, #0xc
     7e8:      	ld1.s	{ v6 }[3], [x2]
     7ec:      	tbz	w1, #0x4, 0x624 <_llm_rows.packet_batch.blocks+0x394>
     7f0:      	add	x2, x14, #0x10
     7f4:      	ld1.s	{ v5 }[0], [x2]
     7f8:      	tbz	w1, #0x5, 0x628 <_llm_rows.packet_batch.blocks+0x398>
     7fc:      	add	x2, x14, #0x14
     800:      	ld1.s	{ v5 }[1], [x2]
     804:      	tbz	w1, #0x6, 0x62c <_llm_rows.packet_batch.blocks+0x39c>
     808:      	add	x2, x14, #0x18
     80c:      	ld1.s	{ v5 }[2], [x2]
     810:      	tbz	w1, #0x7, 0x630 <_llm_rows.packet_batch.blocks+0x3a0>
     814:      	add	x1, x14, #0x1c
     818:      	ld1.s	{ v5 }[3], [x1]
     81c:      	fmov	w1, s0
     820:      	movi.2d	v16, #0000000000000000
     824:      	movi.2d	v7, #0000000000000000
     828:      	tbz	w1, #0x0, 0x640 <_llm_rows.packet_batch.blocks+0x3b0>
     82c:      	ldr	s16, [x13]
     830:      	and	w1, w1, #0xff
     834:      	tbz	w1, #0x1, 0x648 <_llm_rows.packet_batch.blocks+0x3b8>
     838:      	add	x2, x13, #0x4
     83c:      	ld1.s	{ v16 }[1], [x2]
     840:      	tbz	w1, #0x2, 0x64c <_llm_rows.packet_batch.blocks+0x3bc>
     844:      	add	x2, x13, #0x8
     848:      	ld1.s	{ v16 }[2], [x2]
     84c:      	tbz	w1, #0x3, 0x650 <_llm_rows.packet_batch.blocks+0x3c0>
     850:      	add	x2, x13, #0xc
     854:      	ld1.s	{ v16 }[3], [x2]
     858:      	tbz	w1, #0x4, 0x654 <_llm_rows.packet_batch.blocks+0x3c4>
     85c:      	add	x2, x13, #0x10
     860:      	ld1.s	{ v7 }[0], [x2]
     864:      	tbz	w1, #0x5, 0x658 <_llm_rows.packet_batch.blocks+0x3c8>
     868:      	add	x2, x13, #0x14
     86c:      	ld1.s	{ v7 }[1], [x2]
     870:      	tbz	w1, #0x6, 0x65c <_llm_rows.packet_batch.blocks+0x3cc>
     874:      	add	x2, x13, #0x18
     878:      	ld1.s	{ v7 }[2], [x2]
     87c:      	tbz	w1, #0x7, 0x660 <_llm_rows.packet_batch.blocks+0x3d0>
     880:      	add	x1, x13, #0x1c
     884:      	ld1.s	{ v7 }[3], [x1]
     888:      	fmov	w1, s0
     88c:      	fmul.4s	v17, v2, v6
     890:      	fmul.4s	v18, v4, v16
     894:      	fsub.4s	v17, v17, v18
     898:      	add	x0, x8, x0
     89c:      	tbz	w1, #0x0, 0x678 <_llm_rows.packet_batch.blocks+0x3e8>
     8a0:      	str	s17, [x0]
     8a4:      	and	w1, w1, #0xff
     8a8:      	tbz	w1, #0x1, 0x680 <_llm_rows.packet_batch.blocks+0x3f0>
     8ac:      	add	x2, x0, #0x4
     8b0:      	st1.s	{ v17 }[1], [x2]
     8b4:      	tbz	w1, #0x2, 0x684 <_llm_rows.packet_batch.blocks+0x3f4>
     8b8:      	add	x2, x0, #0x8
     8bc:      	st1.s	{ v17 }[2], [x2]
     8c0:      	tbz	w1, #0x3, 0x688 <_llm_rows.packet_batch.blocks+0x3f8>
     8c4:      	add	x2, x0, #0xc
     8c8:      	st1.s	{ v17 }[3], [x2]
     8cc:      	fmul.4s	v17, v1, v5
     8d0:      	fmul.4s	v18, v3, v7
     8d4:      	fsub.4s	v17, v17, v18
     8d8:      	tbz	w1, #0x4, 0x698 <_llm_rows.packet_batch.blocks+0x408>
     8dc:      	str	s17, [x0, #0x10]
     8e0:      	tbz	w1, #0x5, 0x69c <_llm_rows.packet_batch.blocks+0x40c>
     8e4:      	add	x2, x0, #0x14
     8e8:      	st1.s	{ v17 }[1], [x2]
     8ec:      	tbz	w1, #0x6, 0x6a0 <_llm_rows.packet_batch.blocks+0x410>
     8f0:      	add	x2, x0, #0x18
     8f4:      	st1.s	{ v17 }[2], [x2]
     8f8:      	tbz	w1, #0x7, 0x6a4 <_llm_rows.packet_batch.blocks+0x414>
     8fc:      	add	x0, x0, #0x1c
     900:      	st1.s	{ v17 }[3], [x0]
     904:      	fmov	w0, s0
     908:      	fmul.4s	v2, v2, v16
     90c:      	fmul.4s	v4, v4, v6
     910:      	fadd.4s	v2, v4, v2
     914:      	tbz	w0, #0x0, 0x6b8 <_llm_rows.packet_batch.blocks+0x428>
     918:      	str	s2, [x15]
     91c:      	and	w0, w0, #0xff
     920:      	tbz	w0, #0x1, 0x6c0 <_llm_rows.packet_batch.blocks+0x430>
     924:      	add	x1, x15, #0x4
     928:      	st1.s	{ v2 }[1], [x1]
     92c:      	tbz	w0, #0x2, 0x6c4 <_llm_rows.packet_batch.blocks+0x434>
     930:      	add	x1, x15, #0x8
     934:      	st1.s	{ v2 }[2], [x1]
     938:      	tbz	w0, #0x3, 0x6c8 <_llm_rows.packet_batch.blocks+0x438>
     93c:      	add	x1, x15, #0xc
     940:      	st1.s	{ v2 }[3], [x1]
     944:      	fmul.4s	v1, v1, v7
     948:      	fmul.4s	v2, v3, v5
     94c:      	fadd.4s	v1, v2, v1
     950:      	tbz	w0, #0x4, 0x6d8 <_llm_rows.packet_batch.blocks+0x448>
     954:      	str	s1, [x15, #0x10]
     958:      	tbz	w0, #0x5, 0x6dc <_llm_rows.packet_batch.blocks+0x44c>
     95c:      	add	x1, x15, #0x14
     960:      	st1.s	{ v1 }[1], [x1]
     964:      	tbz	w0, #0x6, 0x6e0 <_llm_rows.packet_batch.blocks+0x450>
     968:      	add	x1, x15, #0x18
     96c:      	st1.s	{ v1 }[2], [x1]
     970:      	tbz	w0, #0x7, 0x574 <_llm_rows.packet_batch.blocks+0x2e4>
     974:      	add	x0, x15, #0x1c
     978:      	st1.s	{ v1 }[3], [x0]
     97c:      	b	0x574 <_llm_rows.packet_batch.blocks+0x2e4>
     980:      	mov	x12, #0x0               ; =0
     984:      	cmp	w10, #0x0
     988:      	csel	x10, x15, xzr, ne
     98c:      	add	x11, x10, x10, lsl #1
     990:      	lsl	x10, x11, #10
     994:      	add	x9, x9, x10
     998:      	b	0x9bc <_llm_rows.packet_batch.blocks+0x72c>
     99c:      	add	x15, x4, x12
     9a0:      	ldp	q6, q7, [x15]
     9a4:      	bif.16b	v5, v7, v0
     9a8:      	bif.16b	v4, v6, v1
     9ac:      	stp	q4, q5, [x15]
     9b0:      	add	x12, x12, #0x20
     9b4:      	cmp	x12, #0x600
     9b8:      	b.eq	0xa5c <_llm_rows.packet_batch.blocks+0x7cc>
     9bc:      	and.16b	v2, v3, v19
     9c0:      	addv.8h	h2, v2
     9c4:      	fmov	w16, s2
     9c8:      	add	x15, x9, x12
     9cc:      	movi.2d	v4, #0000000000000000
     9d0:      	movi.2d	v5, #0000000000000000
     9d4:      	tbnz	w16, #0x0, 0x9fc <_llm_rows.packet_batch.blocks+0x76c>
     9d8:      	and	w16, w16, #0xff
     9dc:      	tbnz	w16, #0x1, 0xa08 <_llm_rows.packet_batch.blocks+0x778>
     9e0:      	tbnz	w16, #0x2, 0xa14 <_llm_rows.packet_batch.blocks+0x784>
     9e4:      	tbnz	w16, #0x3, 0xa20 <_llm_rows.packet_batch.blocks+0x790>
     9e8:      	tbnz	w16, #0x4, 0xa2c <_llm_rows.packet_batch.blocks+0x79c>
     9ec:      	tbnz	w16, #0x5, 0xa38 <_llm_rows.packet_batch.blocks+0x7a8>
     9f0:      	tbnz	w16, #0x6, 0xa44 <_llm_rows.packet_batch.blocks+0x7b4>
     9f4:      	tbz	w16, #0x7, 0x99c <_llm_rows.packet_batch.blocks+0x70c>
     9f8:      	b	0xa50 <_llm_rows.packet_batch.blocks+0x7c0>
     9fc:      	ldr	s4, [x15]
     a00:      	and	w16, w16, #0xff
     a04:      	tbz	w16, #0x1, 0x9e0 <_llm_rows.packet_batch.blocks+0x750>
     a08:      	add	x17, x15, #0x4
     a0c:      	ld1.s	{ v4 }[1], [x17]
     a10:      	tbz	w16, #0x2, 0x9e4 <_llm_rows.packet_batch.blocks+0x754>
     a14:      	add	x17, x15, #0x8
     a18:      	ld1.s	{ v4 }[2], [x17]
     a1c:      	tbz	w16, #0x3, 0x9e8 <_llm_rows.packet_batch.blocks+0x758>
     a20:      	add	x17, x15, #0xc
     a24:      	ld1.s	{ v4 }[3], [x17]
     a28:      	tbz	w16, #0x4, 0x9ec <_llm_rows.packet_batch.blocks+0x75c>
     a2c:      	add	x17, x15, #0x10
     a30:      	ld1.s	{ v5 }[0], [x17]
     a34:      	tbz	w16, #0x5, 0x9f0 <_llm_rows.packet_batch.blocks+0x760>
     a38:      	add	x17, x15, #0x14
     a3c:      	ld1.s	{ v5 }[1], [x17]
     a40:      	tbz	w16, #0x6, 0x9f4 <_llm_rows.packet_batch.blocks+0x764>
     a44:      	add	x17, x15, #0x18
     a48:      	ld1.s	{ v5 }[2], [x17]
     a4c:      	tbz	w16, #0x7, 0x99c <_llm_rows.packet_batch.blocks+0x70c>
     a50:      	add	x15, x15, #0x1c
     a54:      	ld1.s	{ v5 }[3], [x15]
     a58:      	b	0x99c <_llm_rows.packet_batch.blocks+0x70c>
     a5c:      	mov	x12, #0x0               ; =0
     a60:      	add	x9, x9, #0x600
     a64:      	b	0xa88 <_llm_rows.packet_batch.blocks+0x7f8>
     a68:      	add	x15, x25, x12
     a6c:      	ldp	q5, q6, [x15]
     a70:      	bif.16b	v4, v6, v0
     a74:      	bif.16b	v3, v5, v1
     a78:      	stp	q3, q4, [x15]
     a7c:      	add	x12, x12, #0x20
     a80:      	cmp	x12, #0x600
     a84:      	b.eq	0xb20 <_llm_rows.packet_batch.blocks+0x890>
     a88:      	fmov	w16, s2
     a8c:      	add	x15, x9, x12
     a90:      	movi.2d	v3, #0000000000000000
     a94:      	movi.2d	v4, #0000000000000000
     a98:      	tbnz	w16, #0x0, 0xac0 <_llm_rows.packet_batch.blocks+0x830>
     a9c:      	and	w16, w16, #0xff
     aa0:      	tbnz	w16, #0x1, 0xacc <_llm_rows.packet_batch.blocks+0x83c>
     aa4:      	tbnz	w16, #0x2, 0xad8 <_llm_rows.packet_batch.blocks+0x848>
     aa8:      	tbnz	w16, #0x3, 0xae4 <_llm_rows.packet_batch.blocks+0x854>
     aac:      	tbnz	w16, #0x4, 0xaf0 <_llm_rows.packet_batch.blocks+0x860>
     ab0:      	tbnz	w16, #0x5, 0xafc <_llm_rows.packet_batch.blocks+0x86c>
     ab4:      	tbnz	w16, #0x6, 0xb08 <_llm_rows.packet_batch.blocks+0x878>
     ab8:      	tbz	w16, #0x7, 0xa68 <_llm_rows.packet_batch.blocks+0x7d8>
     abc:      	b	0xb14 <_llm_rows.packet_batch.blocks+0x884>
     ac0:      	ldr	s3, [x15]
     ac4:      	and	w16, w16, #0xff
     ac8:      	tbz	w16, #0x1, 0xaa4 <_llm_rows.packet_batch.blocks+0x814>
     acc:      	add	x17, x15, #0x4
     ad0:      	ld1.s	{ v3 }[1], [x17]
     ad4:      	tbz	w16, #0x2, 0xaa8 <_llm_rows.packet_batch.blocks+0x818>
     ad8:      	add	x17, x15, #0x8
     adc:      	ld1.s	{ v3 }[2], [x17]
     ae0:      	tbz	w16, #0x3, 0xaac <_llm_rows.packet_batch.blocks+0x81c>
     ae4:      	add	x17, x15, #0xc
     ae8:      	ld1.s	{ v3 }[3], [x17]
     aec:      	tbz	w16, #0x4, 0xab0 <_llm_rows.packet_batch.blocks+0x820>
     af0:      	add	x17, x15, #0x10
     af4:      	ld1.s	{ v4 }[0], [x17]
     af8:      	tbz	w16, #0x5, 0xab4 <_llm_rows.packet_batch.blocks+0x824>
     afc:      	add	x17, x15, #0x14
     b00:      	ld1.s	{ v4 }[1], [x17]
     b04:      	tbz	w16, #0x6, 0xab8 <_llm_rows.packet_batch.blocks+0x828>
     b08:      	add	x17, x15, #0x18
     b0c:      	ld1.s	{ v4 }[2], [x17]
     b10:      	tbz	w16, #0x7, 0xa68 <_llm_rows.packet_batch.blocks+0x7d8>
     b14:      	add	x15, x15, #0x1c
     b18:      	ld1.s	{ v4 }[3], [x15]
     b1c:      	b	0xa68 <_llm_rows.packet_batch.blocks+0x7d8>
     b20:      	mov	x12, #0x0               ; =0
     b24:      	lsl	x9, x11, #9
     b28:      	add	x11, x14, x9
     b2c:      	b	0xb50 <_llm_rows.packet_batch.blocks+0x8c0>
     b30:      	add	x14, x23, x12
     b34:      	ldp	q5, q6, [x14]
     b38:      	bif.16b	v4, v6, v0
     b3c:      	bif.16b	v3, v5, v1
     b40:      	stp	q3, q4, [x14]
     b44:      	add	x12, x12, #0x20
     b48:      	cmp	x12, #0x600
     b4c:      	b.eq	0xbe8 <_llm_rows.packet_batch.blocks+0x958>
     b50:      	fmov	w15, s2
     b54:      	add	x14, x11, x12
     b58:      	movi.2d	v3, #0000000000000000
     b5c:      	movi.2d	v4, #0000000000000000
     b60:      	tbnz	w15, #0x0, 0xb88 <_llm_rows.packet_batch.blocks+0x8f8>
     b64:      	and	w15, w15, #0xff
     b68:      	tbnz	w15, #0x1, 0xb94 <_llm_rows.packet_batch.blocks+0x904>
     b6c:      	tbnz	w15, #0x2, 0xba0 <_llm_rows.packet_batch.blocks+0x910>
     b70:      	tbnz	w15, #0x3, 0xbac <_llm_rows.packet_batch.blocks+0x91c>
     b74:      	tbnz	w15, #0x4, 0xbb8 <_llm_rows.packet_batch.blocks+0x928>
     b78:      	tbnz	w15, #0x5, 0xbc4 <_llm_rows.packet_batch.blocks+0x934>
     b7c:      	tbnz	w15, #0x6, 0xbd0 <_llm_rows.packet_batch.blocks+0x940>
     b80:      	tbz	w15, #0x7, 0xb30 <_llm_rows.packet_batch.blocks+0x8a0>
     b84:      	b	0xbdc <_llm_rows.packet_batch.blocks+0x94c>
     b88:      	ldr	s3, [x14]
     b8c:      	and	w15, w15, #0xff
     b90:      	tbz	w15, #0x1, 0xb6c <_llm_rows.packet_batch.blocks+0x8dc>
     b94:      	add	x16, x14, #0x4
     b98:      	ld1.s	{ v3 }[1], [x16]
     b9c:      	tbz	w15, #0x2, 0xb70 <_llm_rows.packet_batch.blocks+0x8e0>
     ba0:      	add	x16, x14, #0x8
     ba4:      	ld1.s	{ v3 }[2], [x16]
     ba8:      	tbz	w15, #0x3, 0xb74 <_llm_rows.packet_batch.blocks+0x8e4>
     bac:      	add	x16, x14, #0xc
     bb0:      	ld1.s	{ v3 }[3], [x16]
     bb4:      	tbz	w15, #0x4, 0xb78 <_llm_rows.packet_batch.blocks+0x8e8>
     bb8:      	add	x16, x14, #0x10
     bbc:      	ld1.s	{ v4 }[0], [x16]
     bc0:      	tbz	w15, #0x5, 0xb7c <_llm_rows.packet_batch.blocks+0x8ec>
     bc4:      	add	x16, x14, #0x14
     bc8:      	ld1.s	{ v4 }[1], [x16]
     bcc:      	tbz	w15, #0x6, 0xb80 <_llm_rows.packet_batch.blocks+0x8f0>
     bd0:      	add	x16, x14, #0x18
     bd4:      	ld1.s	{ v4 }[2], [x16]
     bd8:      	tbz	w15, #0x7, 0xb30 <_llm_rows.packet_batch.blocks+0x8a0>
     bdc:      	add	x14, x14, #0x1c
     be0:      	ld1.s	{ v4 }[3], [x14]
     be4:      	b	0xb30 <_llm_rows.packet_batch.blocks+0x8a0>
     be8:      	mov	x11, #0x0               ; =0
     bec:      	add	x9, x13, x9
     bf0:      	b	0xc14 <_llm_rows.packet_batch.blocks+0x984>
     bf4:      	add	x12, x24, x11
     bf8:      	ldp	q5, q6, [x12]
     bfc:      	bif.16b	v4, v6, v0
     c00:      	bif.16b	v3, v5, v1
     c04:      	stp	q3, q4, [x12]
     c08:      	add	x11, x11, #0x20
     c0c:      	cmp	x11, #0x600
     c10:      	b.eq	0xcac <_llm_rows.packet_batch.blocks+0xa1c>
     c14:      	fmov	w13, s2
     c18:      	add	x12, x9, x11
     c1c:      	movi.2d	v3, #0000000000000000
     c20:      	movi.2d	v4, #0000000000000000
     c24:      	tbnz	w13, #0x0, 0xc4c <_llm_rows.packet_batch.blocks+0x9bc>
     c28:      	and	w13, w13, #0xff
     c2c:      	tbnz	w13, #0x1, 0xc58 <_llm_rows.packet_batch.blocks+0x9c8>
     c30:      	tbnz	w13, #0x2, 0xc64 <_llm_rows.packet_batch.blocks+0x9d4>
     c34:      	tbnz	w13, #0x3, 0xc70 <_llm_rows.packet_batch.blocks+0x9e0>
     c38:      	tbnz	w13, #0x4, 0xc7c <_llm_rows.packet_batch.blocks+0x9ec>
     c3c:      	tbnz	w13, #0x5, 0xc88 <_llm_rows.packet_batch.blocks+0x9f8>
     c40:      	tbnz	w13, #0x6, 0xc94 <_llm_rows.packet_batch.blocks+0xa04>
     c44:      	tbz	w13, #0x7, 0xbf4 <_llm_rows.packet_batch.blocks+0x964>
     c48:      	b	0xca0 <_llm_rows.packet_batch.blocks+0xa10>
     c4c:      	ldr	s3, [x12]
     c50:      	and	w13, w13, #0xff
     c54:      	tbz	w13, #0x1, 0xc30 <_llm_rows.packet_batch.blocks+0x9a0>
     c58:      	add	x14, x12, #0x4
     c5c:      	ld1.s	{ v3 }[1], [x14]
     c60:      	tbz	w13, #0x2, 0xc34 <_llm_rows.packet_batch.blocks+0x9a4>
     c64:      	add	x14, x12, #0x8
     c68:      	ld1.s	{ v3 }[2], [x14]
     c6c:      	tbz	w13, #0x3, 0xc38 <_llm_rows.packet_batch.blocks+0x9a8>
     c70:      	add	x14, x12, #0xc
     c74:      	ld1.s	{ v3 }[3], [x14]
     c78:      	tbz	w13, #0x4, 0xc3c <_llm_rows.packet_batch.blocks+0x9ac>
     c7c:      	add	x14, x12, #0x10
     c80:      	ld1.s	{ v4 }[0], [x14]
     c84:      	tbz	w13, #0x5, 0xc40 <_llm_rows.packet_batch.blocks+0x9b0>
     c88:      	add	x14, x12, #0x14
     c8c:      	ld1.s	{ v4 }[1], [x14]
     c90:      	tbz	w13, #0x6, 0xc44 <_llm_rows.packet_batch.blocks+0x9b4>
     c94:      	add	x14, x12, #0x18
     c98:      	ld1.s	{ v4 }[2], [x14]
     c9c:      	tbz	w13, #0x7, 0xbf4 <_llm_rows.packet_batch.blocks+0x964>
     ca0:      	add	x12, x12, #0x1c
     ca4:      	ld1.s	{ v4 }[3], [x12]
     ca8:      	b	0xbf4 <_llm_rows.packet_batch.blocks+0x964>
     cac:      	mov	x9, #0x0                ; =0
     cb0:      	add	x8, x8, x10
     cb4:      	b	0xcc4 <_llm_rows.packet_batch.blocks+0xa34>
     cb8:      	add	x9, x9, #0x20
     cbc:      	cmp	x9, #0x600
     cc0:      	b.eq	0xda0 <_llm_rows.packet_batch.blocks+0xb10>
     cc4:      	fmov	w11, s2
     cc8:      	add	x10, x4, x9
     ccc:      	ldp	q5, q3, [x10]
     cd0:      	add	x10, x23, x9
     cd4:      	ldp	q6, q4, [x10]
     cd8:      	fmul.4s	v7, v5, v6
     cdc:      	add	x10, x25, x9
     ce0:      	ldp	q16, q5, [x10]
     ce4:      	add	x10, x24, x9
     ce8:      	ldp	q17, q6, [x10]
     cec:      	fmul.4s	v16, v16, v17
     cf0:      	fsub.4s	v7, v7, v16
     cf4:      	and.16b	v7, v1, v7
     cf8:      	add	x10, x8, x9
     cfc:      	tbnz	w11, #0x0, 0xd34 <_llm_rows.packet_batch.blocks+0xaa4>
     d00:      	and	w11, w11, #0xff
     d04:      	tbnz	w11, #0x1, 0xd40 <_llm_rows.packet_batch.blocks+0xab0>
     d08:      	tbnz	w11, #0x2, 0xd4c <_llm_rows.packet_batch.blocks+0xabc>
     d0c:      	tbnz	w11, #0x3, 0xd58 <_llm_rows.packet_batch.blocks+0xac8>
     d10:      	fmul.4s	v3, v3, v4
     d14:      	fmul.4s	v4, v5, v6
     d18:      	fsub.4s	v3, v3, v4
     d1c:      	and.16b	v3, v0, v3
     d20:      	tbnz	w11, #0x4, 0xd74 <_llm_rows.packet_batch.blocks+0xae4>
     d24:      	tbnz	w11, #0x5, 0xd7c <_llm_rows.packet_batch.blocks+0xaec>
     d28:      	tbnz	w11, #0x6, 0xd88 <_llm_rows.packet_batch.blocks+0xaf8>
     d2c:      	tbz	w11, #0x7, 0xcb8 <_llm_rows.packet_batch.blocks+0xa28>
     d30:      	b	0xd94 <_llm_rows.packet_batch.blocks+0xb04>
     d34:      	str	s7, [x10]
     d38:      	and	w11, w11, #0xff
     d3c:      	tbz	w11, #0x1, 0xd08 <_llm_rows.packet_batch.blocks+0xa78>
     d40:      	add	x12, x10, #0x4
     d44:      	st1.s	{ v7 }[1], [x12]
     d48:      	tbz	w11, #0x2, 0xd0c <_llm_rows.packet_batch.blocks+0xa7c>
     d4c:      	add	x12, x10, #0x8
     d50:      	st1.s	{ v7 }[2], [x12]
     d54:      	tbz	w11, #0x3, 0xd10 <_llm_rows.packet_batch.blocks+0xa80>
     d58:      	add	x12, x10, #0xc
     d5c:      	st1.s	{ v7 }[3], [x12]
     d60:      	fmul.4s	v3, v3, v4
     d64:      	fmul.4s	v4, v5, v6
     d68:      	fsub.4s	v3, v3, v4
     d6c:      	and.16b	v3, v0, v3
     d70:      	tbz	w11, #0x4, 0xd24 <_llm_rows.packet_batch.blocks+0xa94>
     d74:      	str	s3, [x10, #0x10]
     d78:      	tbz	w11, #0x5, 0xd28 <_llm_rows.packet_batch.blocks+0xa98>
     d7c:      	add	x12, x10, #0x14
     d80:      	st1.s	{ v3 }[1], [x12]
     d84:      	tbz	w11, #0x6, 0xd2c <_llm_rows.packet_batch.blocks+0xa9c>
     d88:      	add	x12, x10, #0x18
     d8c:      	st1.s	{ v3 }[2], [x12]
     d90:      	tbz	w11, #0x7, 0xcb8 <_llm_rows.packet_batch.blocks+0xa28>
     d94:      	add	x10, x10, #0x1c
     d98:      	st1.s	{ v3 }[3], [x10]
     d9c:      	b	0xcb8 <_llm_rows.packet_batch.blocks+0xa28>
     da0:      	mov	x9, #0x0                ; =0
     da4:      	add	x8, x8, #0x600
     da8:      	b	0xdb8 <_llm_rows.packet_batch.blocks+0xb28>
     dac:      	add	x9, x9, #0x20
     db0:      	cmp	x9, #0x600
     db4:      	b.eq	0x318 <_llm_rows.packet_batch.blocks+0x88>
     db8:      	fmov	w11, s2
     dbc:      	add	x10, x4, x9
     dc0:      	ldp	q5, q3, [x10]
     dc4:      	add	x10, x24, x9
     dc8:      	ldp	q6, q4, [x10]
     dcc:      	fmul.4s	v7, v5, v6
     dd0:      	add	x10, x25, x9
     dd4:      	ldp	q16, q5, [x10]
     dd8:      	add	x10, x23, x9
     ddc:      	ldp	q17, q6, [x10]
     de0:      	fmul.4s	v16, v16, v17
     de4:      	fadd.4s	v7, v7, v16
     de8:      	and.16b	v7, v1, v7
     dec:      	add	x10, x8, x9
     df0:      	tbnz	w11, #0x0, 0xe28 <_llm_rows.packet_batch.blocks+0xb98>
     df4:      	and	w11, w11, #0xff
     df8:      	tbnz	w11, #0x1, 0xe34 <_llm_rows.packet_batch.blocks+0xba4>
     dfc:      	tbnz	w11, #0x2, 0xe40 <_llm_rows.packet_batch.blocks+0xbb0>
     e00:      	tbnz	w11, #0x3, 0xe4c <_llm_rows.packet_batch.blocks+0xbbc>
     e04:      	fmul.4s	v3, v3, v4
     e08:      	fmul.4s	v4, v5, v6
     e0c:      	fadd.4s	v3, v3, v4
     e10:      	and.16b	v3, v0, v3
     e14:      	tbnz	w11, #0x4, 0xe68 <_llm_rows.packet_batch.blocks+0xbd8>
     e18:      	tbnz	w11, #0x5, 0xe70 <_llm_rows.packet_batch.blocks+0xbe0>
     e1c:      	tbnz	w11, #0x6, 0xe7c <_llm_rows.packet_batch.blocks+0xbec>
     e20:      	tbz	w11, #0x7, 0xdac <_llm_rows.packet_batch.blocks+0xb1c>
     e24:      	b	0xe88 <_llm_rows.packet_batch.blocks+0xbf8>
     e28:      	str	s7, [x10]
     e2c:      	and	w11, w11, #0xff
     e30:      	tbz	w11, #0x1, 0xdfc <_llm_rows.packet_batch.blocks+0xb6c>
     e34:      	add	x12, x10, #0x4
     e38:      	st1.s	{ v7 }[1], [x12]
     e3c:      	tbz	w11, #0x2, 0xe00 <_llm_rows.packet_batch.blocks+0xb70>
     e40:      	add	x12, x10, #0x8
     e44:      	st1.s	{ v7 }[2], [x12]
     e48:      	tbz	w11, #0x3, 0xe04 <_llm_rows.packet_batch.blocks+0xb74>
     e4c:      	add	x12, x10, #0xc
     e50:      	st1.s	{ v7 }[3], [x12]
     e54:      	fmul.4s	v3, v3, v4
     e58:      	fmul.4s	v4, v5, v6
     e5c:      	fadd.4s	v3, v3, v4
     e60:      	and.16b	v3, v0, v3
     e64:      	tbz	w11, #0x4, 0xe18 <_llm_rows.packet_batch.blocks+0xb88>
     e68:      	str	s3, [x10, #0x10]
     e6c:      	tbz	w11, #0x5, 0xe1c <_llm_rows.packet_batch.blocks+0xb8c>
     e70:      	add	x12, x10, #0x14
     e74:      	st1.s	{ v3 }[1], [x12]
     e78:      	tbz	w11, #0x6, 0xe20 <_llm_rows.packet_batch.blocks+0xb90>
     e7c:      	add	x12, x10, #0x18
     e80:      	st1.s	{ v3 }[2], [x12]
     e84:      	tbz	w11, #0x7, 0xdac <_llm_rows.packet_batch.blocks+0xb1c>
     e88:      	add	x10, x10, #0x1c
     e8c:      	st1.s	{ v3 }[3], [x10]
     e90:      	b	0xdac <_llm_rows.packet_batch.blocks+0xb1c>
     e94:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
     e98:      	add	sp, sp, #0x880
     e9c:      	ldp	x29, x30, [sp, #0x50]
     ea0:      	ldp	x20, x19, [sp, #0x40]
     ea4:      	ldp	x22, x21, [sp, #0x30]
     ea8:      	ldp	x24, x23, [sp, #0x20]
     eac:      	ldp	x26, x25, [sp, #0x10]
     eb0:      	ldp	x28, x27, [sp], #0x60
     eb4:      	ret

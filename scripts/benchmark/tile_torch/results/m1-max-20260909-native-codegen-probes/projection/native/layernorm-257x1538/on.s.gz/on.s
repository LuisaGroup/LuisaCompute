
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/layernorm-257x1538/on/object/tile_xir_w8_37917_1788936536407504_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x28, x27, [sp, #-0x60]!
       4:      	stp	x26, x25, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	stp	x29, x30, [sp, #0x50]
      18:      	sub	sp, sp, #0x6, lsl #12   ; =0x6000
      1c:      	sub	sp, sp, #0x120
      20:      	ldr	x24, [x0]
      24:      	ldr	x20, [x0, #0x10]
      28:      	ldr	x19, [x0, #0x20]
      2c:      	ldr	x21, [x0, #0x30]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w22, w8, #3
      40:      	mov	w25, #0x1808            ; =6152
      44:      	umull	x23, w22, w25
      48:      	umaddl	x1, w22, w25, x24
      4c:      	mov	w26, #0x1800            ; =6144
      50:      	add	x27, sp, #0x4, lsl #12  ; =0x4000
      54:      	add	x27, x27, #0x900
      58:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
      5c:      	add	x0, x0, #0x900
      60:      	mov	w2, #0x1800             ; =6144
      64:      	bl	0x64 <ltmp0+0x64>
      68:      	umaddl	x22, w22, w25, x26
      6c:      	add	x8, x24, x22
      70:      	add	x9, x8, #0x4
      74:      	ldr	s0, [x8]
      78:      	ld1.s	{ v0 }[1], [x9]
      7c:      	str	q0, [sp, #0x6100]
      80:      	ldr	q1, [sp, #0x4910]
      84:      	ldr	q7, [sp, #0x4900]
      88:      	ldr	q6, [sp, #0x4930]
      8c:      	ldr	q5, [sp, #0x4920]
      90:      	ldr	q2, [sp, #0x4950]
      94:      	ldr	q16, [sp, #0x4940]
      98:      	ldr	q4, [sp, #0x4970]
      9c:      	ldr	q3, [sp, #0x4960]
      a0:      	add	x8, x27, #0xe0
      a4:      	mov	w9, #0x4                ; =4
      a8:      	ldp	q17, q18, [x8, #-0x60]
      ac:      	fadd.4s	v1, v1, v18
      b0:      	fadd.4s	v7, v7, v17
      b4:      	ldp	q17, q18, [x8, #-0x40]
      b8:      	fadd.4s	v6, v6, v18
      bc:      	fadd.4s	v5, v5, v17
      c0:      	ldp	q17, q18, [x8, #-0x20]
      c4:      	fadd.4s	v2, v2, v18
      c8:      	fadd.4s	v16, v16, v17
      cc:      	ldp	q17, q18, [x8], #0x80
      d0:      	fadd.4s	v4, v4, v18
      d4:      	fadd.4s	v3, v3, v17
      d8:      	cmp	x9, #0xbc
      dc:      	add	x9, x9, #0x4
      e0:      	b.lo	0xa8 <ltmp0+0xa8>
      e4:      	mov	x8, #0x0                ; =0
      e8:      	fadd.4s	v17, v0, v7
      ec:      	mov.d	v17[1], v7[1]
      f0:      	fadd.4s	v1, v6, v1
      f4:      	fadd.4s	v5, v5, v17
      f8:      	fadd.4s	v5, v16, v5
      fc:      	fadd.4s	v1, v2, v1
     100:      	fadd.4s	v1, v4, v1
     104:      	fadd.4s	v2, v3, v5
     108:      	rev64.4s	v3, v2
     10c:      	rev64.4s	v4, v1
     110:      	fadd.4s	v1, v1, v4
     114:      	fadd.4s	v2, v2, v3
     118:      	dup.4s	v3, v2[2]
     11c:      	dup.4s	v4, v1[2]
     120:      	fadd.4s	v1, v1, v4
     124:      	fadd.4s	v2, v2, v3
     128:      	fadd.4s	v1, v2, v1
     12c:      	movi	d2, #0000000000000000
     130:      	fadd	s1, s1, s2
     134:      	mov	w9, #0x4000             ; =16384
     138:      	movk	w9, #0x44c0, lsl #16
     13c:      	fmov	s2, w9
     140:      	fdiv	s1, s1, s2
     144:      	dup.4s	v2, v1[0]
     148:      	add	x9, sp, #0x4, lsl #12   ; =0x4000
     14c:      	add	x9, x9, #0x900
     150:      	add	x10, sp, #0x3, lsl #12  ; =0x3000
     154:      	add	x10, x10, #0xe0
     158:      	lsl	x11, x8, #5
     15c:      	add	x12, x9, x11
     160:      	ldp	q4, q3, [x12]
     164:      	fsub.4s	v4, v4, v2
     168:      	fsub.4s	v3, v3, v2
     16c:      	add	x11, x10, x11
     170:      	stp	q4, q3, [x11]
     174:      	add	x8, x8, #0x1
     178:      	cmp	x8, #0xc0
     17c:      	b.ne	0x158 <ltmp0+0x158>
     180:      	dup.4s	v1, v1[0]
     184:      	fsub.4s	v1, v0, v1
     188:      	ldr	q0, [sp, #0x48e0]
     18c:      	str	q1, [sp, #0x80]
     190:      	mov.d	v1[1], v0[1]
     194:      	str	q1, [sp, #0x90]
     198:      	str	q1, [sp, #0x48e0]
     19c:      	ldr	q0, [sp, #0x30e0]
     1a0:      	ldr	q1, [sp, #0x30f0]
     1a4:      	fmul.4s	v2, v1, v1
     1a8:      	fmul.4s	v3, v0, v0
     1ac:      	ldr	q0, [sp, #0x3100]
     1b0:      	ldr	q1, [sp, #0x3110]
     1b4:      	fmul.4s	v5, v1, v1
     1b8:      	fmul.4s	v4, v0, v0
     1bc:      	ldr	q0, [sp, #0x3120]
     1c0:      	ldr	q1, [sp, #0x3130]
     1c4:      	fmul.4s	v6, v1, v1
     1c8:      	fmul.4s	v7, v0, v0
     1cc:      	ldr	q0, [sp, #0x3140]
     1d0:      	ldr	q1, [sp, #0x3150]
     1d4:      	fmul.4s	v17, v1, v1
     1d8:      	fmul.4s	v16, v0, v0
     1dc:      	add	x8, sp, #0x3, lsl #12   ; =0x3000
     1e0:      	add	x8, x8, #0xe0
     1e4:      	add	x8, x8, #0xe0
     1e8:      	mov	w9, #0x4                ; =4
     1ec:      	ldp	q1, q0, [x8, #-0x60]
     1f0:      	fmul.4s	v1, v1, v1
     1f4:      	fmul.4s	v0, v0, v0
     1f8:      	fadd.4s	v2, v2, v0
     1fc:      	fadd.4s	v3, v3, v1
     200:      	ldp	q1, q0, [x8, #-0x40]
     204:      	fmul.4s	v1, v1, v1
     208:      	fmul.4s	v0, v0, v0
     20c:      	fadd.4s	v5, v5, v0
     210:      	fadd.4s	v4, v4, v1
     214:      	ldp	q1, q0, [x8, #-0x20]
     218:      	fmul.4s	v1, v1, v1
     21c:      	fmul.4s	v0, v0, v0
     220:      	fadd.4s	v6, v6, v0
     224:      	fadd.4s	v7, v7, v1
     228:      	ldp	q1, q0, [x8], #0x80
     22c:      	fmul.4s	v1, v1, v1
     230:      	fmul.4s	v0, v0, v0
     234:      	fadd.4s	v17, v17, v0
     238:      	fadd.4s	v16, v16, v1
     23c:      	cmp	x9, #0xbc
     240:      	add	x9, x9, #0x4
     244:      	b.lo	0x1ec <ltmp0+0x1ec>
     248:      	add	x24, sp, #0x1, lsl #12  ; =0x1000
     24c:      	add	x24, x24, #0x8c0
     250:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     254:      	add	x0, x0, #0x8c0
     258:      	mov	x1, x20
     25c:      	mov	w2, #0x1800             ; =6144
     260:      	stp	q5, q2, [sp, #0x10]
     264:      	str	q3, [sp]
     268:      	stp	q7, q4, [sp, #0x30]
     26c:      	stp	q6, q16, [sp, #0x60]
     270:      	str	q17, [sp, #0x50]
     274:      	bl	0x274 <ltmp0+0x274>
     278:      	ldr	q0, [sp, #0x80]
     27c:      	fmul.4s	v0, v0, v0
     280:      	ldp	q1, q2, [sp]
     284:      	fadd.4s	v0, v0, v1
     288:      	mov.d	v0[1], v1[1]
     28c:      	ldr	q1, [sp, #0x20]
     290:      	fadd.4s	v1, v2, v1
     294:      	ldp	q2, q3, [sp, #0x30]
     298:      	fadd.4s	v0, v3, v0
     29c:      	fadd.4s	v0, v2, v0
     2a0:      	ldp	q2, q3, [sp, #0x50]
     2a4:      	fadd.4s	v1, v3, v1
     2a8:      	fadd.4s	v1, v2, v1
     2ac:      	ldr	q2, [sp, #0x70]
     2b0:      	fadd.4s	v0, v2, v0
     2b4:      	rev64.4s	v2, v0
     2b8:      	rev64.4s	v3, v1
     2bc:      	fadd.4s	v0, v0, v2
     2c0:      	dup.4s	v2, v0[2]
     2c4:      	fadd.4s	v1, v1, v3
     2c8:      	dup.4s	v3, v1[2]
     2cc:      	fadd.4s	v1, v1, v3
     2d0:      	fadd.4s	v0, v0, v2
     2d4:      	fadd.4s	v0, v0, v1
     2d8:      	movi	d1, #0000000000000000
     2dc:      	fadd	s0, s0, s1
     2e0:      	mov	w8, #0x4000             ; =16384
     2e4:      	movk	w8, #0x44c0, lsl #16
     2e8:      	fmov	s1, w8
     2ec:      	fdiv	s0, s0, s1
     2f0:      	mov	w8, #0x1804             ; =6148
     2f4:      	add	x8, x20, x8
     2f8:      	ldr	s5, [x20, #0x1800]
     2fc:      	ld1.s	{ v5 }[1], [x8]
     300:      	str	q5, [sp, #0x30c0]
     304:      	mov	w8, #0xc5ac             ; =50604
     308:      	movk	w8, #0x3727, lsl #16
     30c:      	fmov	s1, w8
     310:      	fadd	s0, s0, s1
     314:      	fsqrt	s6, s0
     318:      	subs	x8, x21, x19
     31c:      	lsr	x8, x8, #3
     320:      	mov	w9, #0x300              ; =768
     324:      	ccmp	x8, x9, #0x0, hs
     328:      	cset	w8, hi
     32c:      	mov	w9, #0x2007             ; =8199
     330:      	movk	w9, #0x18, lsl #16
     334:      	sub	x10, x19, x21
     338:      	cmp	x10, x9
     33c:      	ccmp	x19, x21, #0x0, hi
     340:      	b.hs	0x3f4 <ltmp0+0x3f4>
     344:      	tbnz	w8, #0x0, 0x3f4 <ltmp0+0x3f4>
     348:      	stp	q6, q5, [sp, #0x70]
     34c:      	add	x20, sp, #0xa0
     350:      	add	x0, sp, #0xa0
     354:      	mov	x1, x19
     358:      	mov	w2, #0x1800             ; =6144
     35c:      	bl	0x35c <ltmp0+0x35c>
     360:      	ldr	q6, [sp, #0x70]
     364:      	mov	x8, #0x0                ; =0
     368:      	mov	w9, #0x1804             ; =6148
     36c:      	add	x9, x19, x9
     370:      	ldr	s0, [x19, #0x1800]
     374:      	ld1.s	{ v0 }[1], [x9]
     378:      	str	q0, [sp, #0x18a0]
     37c:      	dup.4s	v1, v6[0]
     380:      	add	x9, x21, x23
     384:      	add	x10, sp, #0x3, lsl #12  ; =0x3000
     388:      	add	x10, x10, #0xe0
     38c:      	add	x11, sp, #0x1, lsl #12  ; =0x1000
     390:      	add	x11, x11, #0x8c0
     394:      	lsl	x12, x8, #5
     398:      	add	x13, x10, x12
     39c:      	ldp	q3, q2, [x13]
     3a0:      	fdiv.4s	v3, v3, v1
     3a4:      	fdiv.4s	v2, v2, v1
     3a8:      	add	x13, x11, x12
     3ac:      	ldp	q4, q5, [x13]
     3b0:      	fmul.4s	v2, v2, v5
     3b4:      	fmul.4s	v3, v3, v4
     3b8:      	add	x13, x20, x12
     3bc:      	ldp	q5, q4, [x13]
     3c0:      	fadd.4s	v3, v3, v5
     3c4:      	fadd.4s	v2, v2, v4
     3c8:      	add	x12, x9, x12
     3cc:      	stp	q3, q2, [x12]
     3d0:      	add	x8, x8, #0x1
     3d4:      	cmp	x8, #0xc0
     3d8:      	b.ne	0x394 <ltmp0+0x394>
     3dc:      	dup.4s	v1, v6[0]
     3e0:      	ldp	q2, q3, [sp, #0x80]
     3e4:      	fdiv.4s	v1, v3, v1
     3e8:      	fmul.4s	v1, v1, v2
     3ec:      	fadd.4s	v0, v1, v0
     3f0:      	b	0x474 <ltmp0+0x474>
     3f4:      	mov	x8, #0x0                ; =0
     3f8:      	dup.4s	v0, v6[0]
     3fc:      	add	x9, x21, x23
     400:      	add	x10, sp, #0x3, lsl #12  ; =0x3000
     404:      	add	x10, x10, #0xe0
     408:      	lsl	x11, x8, #5
     40c:      	add	x12, x10, x11
     410:      	ldp	q2, q1, [x12]
     414:      	fdiv.4s	v2, v2, v0
     418:      	fdiv.4s	v1, v1, v0
     41c:      	add	x12, x24, x11
     420:      	ldp	q3, q4, [x12]
     424:      	fmul.4s	v1, v1, v4
     428:      	fmul.4s	v2, v2, v3
     42c:      	add	x12, x19, x11
     430:      	ldp	q4, q3, [x12]
     434:      	fadd.4s	v2, v2, v4
     438:      	fadd.4s	v1, v1, v3
     43c:      	add	x11, x9, x11
     440:      	stp	q2, q1, [x11]
     444:      	add	x8, x8, #0x1
     448:      	cmp	x8, #0xc0
     44c:      	b.lt	0x408 <ltmp0+0x408>
     450:      	dup.4s	v0, v6[0]
     454:      	ldr	q1, [sp, #0x90]
     458:      	fdiv.4s	v0, v1, v0
     45c:      	fmul.4s	v0, v0, v5
     460:      	mov	w8, #0x1804             ; =6148
     464:      	add	x8, x19, x8
     468:      	ldr	s1, [x19, #0x1800]
     46c:      	ld1.s	{ v1 }[1], [x8]
     470:      	fadd.4s	v0, v0, v1
     474:      	str	d0, [x21, x22]
     478:      	add	sp, sp, #0x6, lsl #12   ; =0x6000
     47c:      	add	sp, sp, #0x120
     480:      	ldp	x29, x30, [sp, #0x50]
     484:      	ldp	x20, x19, [sp, #0x40]
     488:      	ldp	x22, x21, [sp, #0x30]
     48c:      	ldp	x24, x23, [sp, #0x20]
     490:      	ldp	x26, x25, [sp, #0x10]
     494:      	ldp	x28, x27, [sp], #0x60
     498:      	ret

000000000000049c <_llm_rows.packet_batch.blocks>:
     49c:      	stp	d15, d14, [sp, #-0xa0]!
     4a0:      	stp	d13, d12, [sp, #0x10]
     4a4:      	stp	d11, d10, [sp, #0x20]
     4a8:      	stp	d9, d8, [sp, #0x30]
     4ac:      	stp	x28, x27, [sp, #0x40]
     4b0:      	stp	x26, x25, [sp, #0x50]
     4b4:      	stp	x24, x23, [sp, #0x60]
     4b8:      	stp	x22, x21, [sp, #0x70]
     4bc:      	stp	x20, x19, [sp, #0x80]
     4c0:      	stp	x29, x30, [sp, #0x90]
     4c4:      	sub	sp, sp, #0x6, lsl #12   ; =0x6000
     4c8:      	sub	sp, sp, #0x660
     4cc:      	str	x0, [sp, #0x188]
     4d0:      	cbz	w3, 0x1cb0 <_llm_rows.packet_batch.blocks+0x1814>
     4d4:      	mov	x26, x3
     4d8:      	mov	x20, x2
     4dc:      	mov	w22, #0x0               ; =0
     4e0:      	ldp	w9, w8, [x2, #0x2c]
     4e4:      	str	w9, [sp, #0x184]
     4e8:      	str	w8, [sp, #0x180]
     4ec:      	add	x25, sp, #0x4, lsl #12  ; =0x4000
     4f0:      	add	x25, x25, #0xe40
     4f4:      	ldp	w24, w12, [x2]
     4f8:      	ldp	w28, w8, [x2, #0x8]
     4fc:      	str	x8, [sp, #0x178]
     500:      	adrp	x8, 0x0 <ltmp0>
     504:      	ldr	q0, [x8]
     508:      	str	q0, [sp, #0x10]
     50c:      	adrp	x8, 0x0 <ltmp0>
     510:      	ldr	q0, [x8]
     514:      	str	q0, [sp, #0x30]
     518:      	adrp	x8, 0x0 <ltmp0>
     51c:      	ldr	q0, [x8]
     520:      	str	q0, [sp, #0x20]
     524:      	mov	w27, #0x4               ; =4
     528:      	add	x19, sp, #0x3, lsl #12  ; =0x3000
     52c:      	add	x19, x19, #0x620
     530:      	str	w3, [sp, #0x14c]
     534:      	b	0x580 <_llm_rows.packet_batch.blocks+0xe4>
     538:      	mov	w8, #0x18               ; =24
     53c:      	str	w8, [x20, #0x24]
     540:      	ldr	w26, [sp, #0x14c]
     544:      	add	w8, w24, #0x1
     548:      	ldr	w9, [sp, #0x184]
     54c:      	cmp	w8, w9
     550:      	cset	w8, eq
     554:      	csinc	w24, wzr, w24, eq
     558:      	cinc	w9, w12, eq
     55c:      	ldr	w10, [sp, #0x180]
     560:      	cmp	w9, w10
     564:      	cset	w10, eq
     568:      	ands	w8, w8, w10
     56c:      	csel	w12, wzr, w9, ne
     570:      	add	w28, w28, w8
     574:      	add	w22, w22, #0x1
     578:      	cmp	w22, w26
     57c:      	b.eq	0x1cb0 <_llm_rows.packet_batch.blocks+0x1814>
     580:      	ubfiz	x8, x24, #5, #32
     584:      	ldr	x13, [sp, #0x178]
     588:      	cmp	x8, x13
     58c:      	csel	x9, x8, xzr, ls
     590:      	subs	x10, x13, x9
     594:      	cmp	x10, #0x20
     598:      	mov	w11, #0x20              ; =32
     59c:      	csel	x10, x10, x11, lo
     5a0:      	cmp	x13, x9
     5a4:      	stp	w24, w12, [x20]
     5a8:      	str	w28, [x20, #0x8]
     5ac:      	str	wzr, [x20, #0x24]
     5b0:      	ccmp	x8, x13, #0x2, hi
     5b4:      	csel	x23, x10, xzr, ls
     5b8:      	cmp	x23, #0x20
     5bc:      	b.lo	0x618 <_llm_rows.packet_batch.blocks+0x17c>
     5c0:      	ldr	x23, [sp, #0x188]
     5c4:      	mov	x0, x23
     5c8:      	mov	x1, x20
     5cc:      	mov	x21, x12
     5d0:      	bl	0x5d0 <_llm_rows.packet_batch.blocks+0x134>
     5d4:      	mov	w8, #0x8                ; =8
     5d8:      	str	w8, [x20, #0x24]
     5dc:      	mov	x0, x23
     5e0:      	mov	x1, x20
     5e4:      	bl	0x5e4 <_llm_rows.packet_batch.blocks+0x148>
     5e8:      	mov	w8, #0x10               ; =16
     5ec:      	str	w8, [x20, #0x24]
     5f0:      	mov	x0, x23
     5f4:      	mov	x1, x20
     5f8:      	bl	0x5f8 <_llm_rows.packet_batch.blocks+0x15c>
     5fc:      	mov	w8, #0x18               ; =24
     600:      	str	w8, [x20, #0x24]
     604:      	mov	x0, x23
     608:      	mov	x1, x20
     60c:      	bl	0x60c <_llm_rows.packet_batch.blocks+0x170>
     610:      	mov	x12, x21
     614:      	b	0x544 <_llm_rows.packet_batch.blocks+0xa8>
     618:      	lsr	x26, x23, #3
     61c:      	cmp	x23, #0x8
     620:      	b.lo	0x67c <_llm_rows.packet_batch.blocks+0x1e0>
     624:      	str	wzr, [x20, #0x24]
     628:      	ldr	x0, [sp, #0x188]
     62c:      	mov	x1, x20
     630:      	mov	x21, x12
     634:      	bl	0x634 <_llm_rows.packet_batch.blocks+0x198>
     638:      	mov	x12, x21
     63c:      	cmp	x26, #0x1
     640:      	b.eq	0x67c <_llm_rows.packet_batch.blocks+0x1e0>
     644:      	mov	w8, #0x8                ; =8
     648:      	str	w8, [x20, #0x24]
     64c:      	ldr	x0, [sp, #0x188]
     650:      	mov	x1, x20
     654:      	bl	0x654 <_llm_rows.packet_batch.blocks+0x1b8>
     658:      	mov	x12, x21
     65c:      	cmp	x26, #0x2
     660:      	b.eq	0x67c <_llm_rows.packet_batch.blocks+0x1e0>
     664:      	mov	w8, #0x10               ; =16
     668:      	str	w8, [x20, #0x24]
     66c:      	ldr	x0, [sp, #0x188]
     670:      	mov	x1, x20
     674:      	bl	0x674 <_llm_rows.packet_batch.blocks+0x1d8>
     678:      	mov	x12, x21
     67c:      	and	w8, w23, #0x7
     680:      	cbz	w8, 0x538 <_llm_rows.packet_batch.blocks+0x9c>
     684:      	dup.4s	v1, w8
     688:      	ldp	q0, q2, [sp, #0x20]
     68c:      	cmhi.4s	v0, v1, v0
     690:      	cmhi.4s	v1, v1, v2
     694:      	uzp1.8h	v3, v1, v0
     698:      	umaxv.8h	h2, v3
     69c:      	fmov	w8, s2
     6a0:      	tbz	w8, #0x0, 0x538 <_llm_rows.packet_batch.blocks+0x9c>
     6a4:      	str	w12, [sp, #0x148]
     6a8:      	mov	x12, #0x0               ; =0
     6ac:      	ldr	x8, [sp, #0x188]
     6b0:      	ldr	x9, [x8]
     6b4:      	ldr	x14, [x8, #0x10]
     6b8:      	ldr	x11, [x8, #0x20]
     6bc:      	ldr	x8, [x8, #0x30]
     6c0:      	ldr	q2, [sp, #0x10]
     6c4:      	and.16b	v2, v3, v2
     6c8:      	addv.8h	h20, v2
     6cc:      	fmov	w10, s20
     6d0:      	and	w13, w10, #0xff
     6d4:      	xtn.4h	v4, v1
     6d8:      	uzp1.8b	v4, v4, v0
     6dc:      	ubfiz	w10, w24, #2, #27
     6e0:      	orr	w10, w10, w26
     6e4:      	dup.4s	v5, w10
     6e8:      	and.16b	v6, v1, v5
     6ec:      	and.16b	v5, v0, v5
     6f0:      	ushll2.2d	v16, v5, #0x0
     6f4:      	ushll2.2d	v17, v6, #0x0
     6f8:      	ushll.2d	v18, v5, #0x0
     6fc:      	umov.b	w15, v4[0]
     700:      	ushll.2d	v5, v6, #0x0
     704:      	mov	w16, #0x1808            ; =6152
     708:      	umull	x10, w10, w16
     70c:      	tst	w15, #0x1
     710:      	csel	x3, x10, xzr, ne
     714:      	add	x16, x9, x3
     718:      	fmov	w17, s20
     71c:      	b	0x740 <_llm_rows.packet_batch.blocks+0x2a4>
     720:      	add	x0, x25, x12, lsl #5
     724:      	ldp	q7, q19, [x0]
     728:      	bif.16b	v6, v19, v0
     72c:      	bif.16b	v4, v7, v1
     730:      	stp	q4, q6, [x0]
     734:      	add	x12, x12, #0x1
     738:      	cmp	x12, #0xc0
     73c:      	b.eq	0x7d4 <_llm_rows.packet_batch.blocks+0x338>
     740:      	add	x0, x16, x12, lsl #5
     744:      	movi.2d	v4, #0000000000000000
     748:      	movi.2d	v6, #0000000000000000
     74c:      	tbnz	w17, #0x0, 0x774 <_llm_rows.packet_batch.blocks+0x2d8>
     750:      	and	w1, w17, #0xff
     754:      	tbnz	w1, #0x1, 0x780 <_llm_rows.packet_batch.blocks+0x2e4>
     758:      	tbnz	w1, #0x2, 0x78c <_llm_rows.packet_batch.blocks+0x2f0>
     75c:      	tbnz	w1, #0x3, 0x798 <_llm_rows.packet_batch.blocks+0x2fc>
     760:      	tbnz	w1, #0x4, 0x7a4 <_llm_rows.packet_batch.blocks+0x308>
     764:      	tbnz	w1, #0x5, 0x7b0 <_llm_rows.packet_batch.blocks+0x314>
     768:      	tbnz	w1, #0x6, 0x7bc <_llm_rows.packet_batch.blocks+0x320>
     76c:      	tbz	w1, #0x7, 0x720 <_llm_rows.packet_batch.blocks+0x284>
     770:      	b	0x7c8 <_llm_rows.packet_batch.blocks+0x32c>
     774:      	ldr	s4, [x0]
     778:      	and	w1, w17, #0xff
     77c:      	tbz	w1, #0x1, 0x758 <_llm_rows.packet_batch.blocks+0x2bc>
     780:      	add	x2, x0, #0x4
     784:      	ld1.s	{ v4 }[1], [x2]
     788:      	tbz	w1, #0x2, 0x75c <_llm_rows.packet_batch.blocks+0x2c0>
     78c:      	add	x2, x0, #0x8
     790:      	ld1.s	{ v4 }[2], [x2]
     794:      	tbz	w1, #0x3, 0x760 <_llm_rows.packet_batch.blocks+0x2c4>
     798:      	add	x2, x0, #0xc
     79c:      	ld1.s	{ v4 }[3], [x2]
     7a0:      	tbz	w1, #0x4, 0x764 <_llm_rows.packet_batch.blocks+0x2c8>
     7a4:      	add	x2, x0, #0x10
     7a8:      	ld1.s	{ v6 }[0], [x2]
     7ac:      	tbz	w1, #0x5, 0x768 <_llm_rows.packet_batch.blocks+0x2cc>
     7b0:      	add	x2, x0, #0x14
     7b4:      	ld1.s	{ v6 }[1], [x2]
     7b8:      	tbz	w1, #0x6, 0x76c <_llm_rows.packet_batch.blocks+0x2d0>
     7bc:      	add	x2, x0, #0x18
     7c0:      	ld1.s	{ v6 }[2], [x2]
     7c4:      	tbz	w1, #0x7, 0x720 <_llm_rows.packet_batch.blocks+0x284>
     7c8:      	add	x0, x0, #0x1c
     7cc:      	ld1.s	{ v6 }[3], [x0]
     7d0:      	b	0x720 <_llm_rows.packet_batch.blocks+0x284>
     7d4:      	xtn.8b	v6, v3
     7d8:      	sshll.2d	v4, v1, #0x0
     7dc:      	movi	d2, #0x0000000000ffff
     7e0:      	and.8b	v7, v6, v2
     7e4:      	adrp	x10, 0x0 <ltmp0>
     7e8:      	ldr	d3, [x10]
     7ec:      	str	q6, [sp, #0x150]
     7f0:      	and.8b	v3, v6, v3
     7f4:      	addv.8b	b3, v3
     7f8:      	fmov	w12, s3
     7fc:      	umaxv.8b	b3, v7
     800:      	fmov	w16, s3
     804:      	rbit	w17, w12
     808:      	clz	w17, w17
     80c:      	tst	w16, #0x1
     810:      	csel	w17, w17, wzr, ne
     814:      	mov	w10, #0x600             ; =1536
     818:      	dup.2d	v6, x10
     81c:      	adrp	x10, 0x0 <ltmp0>
     820:      	ldr	q2, [x10]
     824:      	str	q2, [sp, #0xb0]
     828:      	bif.16b	v2, v6, v4
     82c:      	xtn.2s	v19, v5
     830:      	mov	w10, #0x602             ; =1538
     834:      	dup.2s	v5, w10
     838:      	umlal.2d	v2, v19, v5
     83c:      	mov	b19, v7[0]
     840:      	mov.b	v19[4], v7[1]
     844:      	ushll.2d	v19, v19, #0x0
     848:      	shl.2d	v19, v19, #0x3f
     84c:      	cmlt.2d	v19, v19, #0
     850:      	str	q2, [sp, #0x110]
     854:      	and.16b	v19, v19, v2
     858:      	movi.2d	v2, #0000000000000000
     85c:      	str	q2, [sp, #0x5c0]
     860:      	str	q2, [sp, #0x5b0]
     864:      	str	q2, [sp, #0x5a0]
     868:      	str	q19, [sp, #0x590]
     86c:      	and	x16, x17, #0x7
     870:      	add	x10, sp, #0x590
     874:      	ldr	x16, [x10, x16, lsl #3]
     878:      	sub	x16, x16, x17
     87c:      	add	x9, x9, x16, lsl #2
     880:      	movi.2d	v22, #0000000000000000
     884:      	movi.2d	v23, #0000000000000000
     888:      	tbnz	w12, #0x0, 0x18f4 <_llm_rows.packet_batch.blocks+0x1458>
     88c:      	tbnz	w12, #0x1, 0x18fc <_llm_rows.packet_batch.blocks+0x1460>
     890:      	tbnz	w12, #0x2, 0x1908 <_llm_rows.packet_batch.blocks+0x146c>
     894:      	tbnz	w12, #0x3, 0x1914 <_llm_rows.packet_batch.blocks+0x1478>
     898:      	tbnz	w12, #0x4, 0x1920 <_llm_rows.packet_batch.blocks+0x1484>
     89c:      	tbnz	w12, #0x5, 0x192c <_llm_rows.packet_batch.blocks+0x1490>
     8a0:      	tbnz	w12, #0x6, 0x1938 <_llm_rows.packet_batch.blocks+0x149c>
     8a4:      	str	q20, [sp, #0x130]
     8a8:      	tbz	w12, #0x7, 0x8b4 <_llm_rows.packet_batch.blocks+0x418>
     8ac:      	add	x9, x9, #0x1c
     8b0:      	ld1.s	{ v23 }[3], [x9]
     8b4:      	str	x3, [sp, #0x108]
     8b8:      	str	x8, [sp, #0x140]
     8bc:      	sshll.2d	v19, v0, #0x0
     8c0:      	sshll2.2d	v20, v1, #0x0
     8c4:      	sshll2.2d	v21, v0, #0x0
     8c8:      	adrp	x9, 0x0 <ltmp0>
     8cc:      	ldr	q24, [x9]
     8d0:      	and.16b	v24, v21, v24
     8d4:      	adrp	x9, 0x0 <ltmp0>
     8d8:      	ldr	q27, [x9]
     8dc:      	and.16b	v27, v20, v27
     8e0:      	adrp	x9, 0x0 <ltmp0>
     8e4:      	ldr	q28, [x9]
     8e8:      	and.16b	v28, v19, v28
     8ec:      	adrp	x9, 0x0 <ltmp0>
     8f0:      	ldr	q29, [x9]
     8f4:      	and.16b	v4, v4, v29
     8f8:      	adrp	x9, 0x0 <ltmp0>
     8fc:      	ldr	q29, [x9]
     900:      	mov.16b	v2, v19
     904:      	bsl.16b	v2, v29, v6
     908:      	adrp	x9, 0x0 <ltmp0>
     90c:      	ldr	q19, [x9]
     910:      	mov.16b	v3, v20
     914:      	bsl.16b	v3, v19, v6
     918:      	adrp	x9, 0x0 <ltmp0>
     91c:      	ldr	q19, [x9]
     920:      	bit.16b	v6, v19, v21
     924:      	xtn.2s	v18, v18
     928:      	xtn.2s	v17, v17
     92c:      	xtn.2s	v16, v16
     930:      	umlal.2d	v6, v16, v5
     934:      	umlal.2d	v3, v17, v5
     938:      	stp	q6, q3, [sp, #0xd0]
     93c:      	umlal.2d	v2, v18, v5
     940:      	str	q2, [sp, #0xf0]
     944:      	sshll.2d	v5, v1, #0x0
     948:      	sshll.2d	v16, v0, #0x0
     94c:      	str	q4, [sp, #0x550]
     950:      	str	q27, [sp, #0x560]
     954:      	str	q28, [sp, #0x570]
     958:      	str	q24, [sp, #0x580]
     95c:      	and	x9, x17, #0x7
     960:      	add	x10, sp, #0x550
     964:      	ldr	x9, [x10, x9, lsl #3]
     968:      	orr	x9, x9, #0x1800
     96c:      	str	x17, [sp, #0x128]
     970:      	sub	x9, x9, x17, lsl #2
     974:      	tst	w12, #0xff
     978:      	csel	x21, xzr, x9, eq
     97c:      	add	x9, x25, x21
     980:      	ldp	q4, q17, [x9]
     984:      	zip2.8b	v18, v7, v0
     988:      	ushll.4s	v18, v18, #0x0
     98c:      	shl.4s	v18, v18, #0x1f
     990:      	cmlt.4s	v18, v18, #0
     994:      	str	q23, [sp, #0x90]
     998:      	bit.16b	v17, v23, v18
     99c:      	str	q7, [sp, #0x160]
     9a0:      	zip1.8b	v18, v7, v0
     9a4:      	ushll.4s	v18, v18, #0x0
     9a8:      	shl.4s	v18, v18, #0x1f
     9ac:      	cmlt.4s	v18, v18, #0
     9b0:      	str	q22, [sp, #0xc0]
     9b4:      	bit.16b	v4, v22, v18
     9b8:      	stp	q4, q17, [x9]
     9bc:      	dup.2d	v4, x27
     9c0:      	and.16b	v27, v21, v4
     9c4:      	and.16b	v28, v20, v4
     9c8:      	and.16b	v29, v16, v4
     9cc:      	and.16b	v30, v5, v4
     9d0:      	tst	w15, #0x1
     9d4:      	csel	x5, x27, xzr, ne
     9d8:      	ldr	q4, [sp, #0x4ea0]
     9dc:      	ldr	q5, [sp, #0x4eb0]
     9e0:      	and.16b	v5, v0, v5
     9e4:      	and.16b	v4, v1, v4
     9e8:      	ldr	q17, [sp, #0x4e80]
     9ec:      	ldr	q16, [sp, #0x4e90]
     9f0:      	and.16b	v16, v0, v16
     9f4:      	and.16b	v17, v1, v17
     9f8:      	ldr	q18, [sp, #0x4e60]
     9fc:      	ldr	q19, [sp, #0x4e70]
     a00:      	and.16b	v19, v0, v19
     a04:      	and.16b	v18, v1, v18
     a08:      	ldr	q24, [sp, #0x4e40]
     a0c:      	ldr	q31, [sp, #0x4e50]
     a10:      	and.16b	v31, v0, v31
     a14:      	mov	x9, x5
     a18:      	and.16b	v8, v1, v24
     a1c:      	mov.16b	v14, v30
     a20:      	mov.16b	v24, v28
     a24:      	mov.16b	v11, v29
     a28:      	mov.16b	v12, v27
     a2c:      	sshll.2d	v15, v1, #0x0
     a30:      	sshll.2d	v6, v0, #0x0
     a34:      	add	x9, x25, x9, lsl #5
     a38:      	ldp	q13, q9, [x9]
     a3c:      	fadd.4s	v13, v8, v13
     a40:      	fadd.4s	v9, v31, v9
     a44:      	ldp	q22, q3, [x9, #0x20]
     a48:      	fadd.4s	v22, v18, v22
     a4c:      	fadd.4s	v3, v19, v3
     a50:      	ldp	q7, q10, [x9, #0x40]
     a54:      	fadd.4s	v7, v17, v7
     a58:      	fadd.4s	v10, v16, v10
     a5c:      	ldp	q23, q25, [x9, #0x60]
     a60:      	fadd.4s	v23, v4, v23
     a64:      	fadd.4s	v25, v5, v25
     a68:      	dup.2d	v26, x27
     a6c:      	and.16b	v2, v21, v26
     a70:      	add.2d	v12, v12, v2
     a74:      	and.16b	v2, v20, v26
     a78:      	add.2d	v24, v24, v2
     a7c:      	and.16b	v2, v6, v26
     a80:      	add.2d	v11, v11, v2
     a84:      	and.16b	v2, v15, v26
     a88:      	add.2d	v2, v14, v2
     a8c:      	bit.16b	v31, v9, v0
     a90:      	bit.16b	v8, v13, v1
     a94:      	bit.16b	v19, v3, v0
     a98:      	bit.16b	v18, v22, v1
     a9c:      	bit.16b	v16, v10, v0
     aa0:      	bit.16b	v17, v7, v1
     aa4:      	bit.16b	v5, v25, v0
     aa8:      	bit.16b	v4, v23, v1
     aac:      	fmov	x9, d14
     ab0:      	add	x12, x9, #0x4
     ab4:      	tst	w15, #0x1
     ab8:      	csel	x9, x12, x9, ne
     abc:      	mov.16b	v14, v2
     ac0:      	cmp	x9, #0xc0
     ac4:      	b.lt	0xa2c <_llm_rows.packet_batch.blocks+0x590>
     ac8:      	mov	x6, #0x0                ; =0
     acc:      	movi	d2, #0xffffffffffff0000
     ad0:      	ldp	q24, q23, [sp, #0x150]
     ad4:      	and.8b	v7, v24, v2
     ad8:      	ldr	q25, [sp, #0xc0]
     adc:      	fadd.4s	v2, v25, v8
     ae0:      	ldr	q26, [sp, #0x90]
     ae4:      	fadd.4s	v3, v26, v31
     ae8:      	zip2.8b	v6, v23, v0
     aec:      	ushll.4s	v6, v6, #0x0
     af0:      	shl.4s	v6, v6, #0x1f
     af4:      	cmlt.4s	v6, v6, #0
     af8:      	and.16b	v3, v6, v3
     afc:      	zip1.8b	v6, v23, v0
     b00:      	ushll.4s	v6, v6, #0x0
     b04:      	shl.4s	v6, v6, #0x1f
     b08:      	cmlt.4s	v6, v6, #0
     b0c:      	and.16b	v2, v6, v2
     b10:      	zip1.8b	v6, v7, v0
     b14:      	ushll.4s	v6, v6, #0x0
     b18:      	shl.4s	v6, v6, #0x1f
     b1c:      	cmlt.4s	v6, v6, #0
     b20:      	bit.16b	v2, v13, v6
     b24:      	str	d7, [sp, #0x70]
     b28:      	zip2.8b	v6, v7, v0
     b2c:      	ushll.4s	v6, v6, #0x0
     b30:      	shl.4s	v6, v6, #0x1f
     b34:      	cmlt.4s	v6, v6, #0
     b38:      	bit.16b	v3, v9, v6
     b3c:      	fadd.4s	v3, v19, v3
     b40:      	fadd.4s	v2, v18, v2
     b44:      	fadd.4s	v2, v17, v2
     b48:      	fadd.4s	v3, v16, v3
     b4c:      	fadd.4s	v5, v5, v3
     b50:      	fadd.4s	v4, v4, v2
     b54:      	umov.b	w8, v24[1]
     b58:      	and	w23, w15, w8
     b5c:      	mov	s2, v4[1]
     b60:      	tst	w23, #0x1
     b64:      	movi	d22, #0000000000000000
     b68:      	fcsel	s16, s2, s22, ne
     b6c:      	mvn	w9, w8
     b70:      	add	x12, sp, #0x530
     b74:      	bfi	x12, x9, #2, #1
     b78:      	add	x16, sp, #0x428
     b7c:      	bfxil	x16, x9, #0, #1
     b80:      	str	d24, [sp, #0x428]
     b84:      	ldrb	w9, [x16]
     b88:      	str	w8, [sp, #0xa4]
     b8c:      	and	w9, w8, w9
     b90:      	str	q5, [sp, #0x540]
     b94:      	str	q4, [sp, #0x530]
     b98:      	ldr	s2, [x12]
     b9c:      	tst	w9, #0x1
     ba0:      	fcsel	s17, s2, s22, ne
     ba4:      	umov.b	w12, v24[2]
     ba8:      	ands	w9, w12, #0x1
     bac:      	mov	w10, #0x3               ; =3
     bb0:      	csinc	w16, w10, wzr, ne
     bb4:      	add	x10, sp, #0x428
     bb8:      	orr	x17, x10, x16
     bbc:      	ldrb	w17, [x17]
     bc0:      	add	x0, sp, #0x510
     bc4:      	orr	x16, x0, x16, lsl #2
     bc8:      	str	q5, [sp, #0x520]
     bcc:      	str	q4, [sp, #0x510]
     bd0:      	ldr	s2, [x16]
     bd4:      	tst	w9, w17
     bd8:      	fcsel	s18, s2, s22, ne
     bdc:      	umov.b	w26, v24[3]
     be0:      	ands	w9, w26, #0x1
     be4:      	mov	w2, #0x1                ; =1
     be8:      	cinc	w16, w2, ne
     bec:      	add	x17, sp, #0x428
     bf0:      	bfxil	x17, x16, #0, #3
     bf4:      	ldrb	w17, [x17]
     bf8:      	add	x0, sp, #0x4f0
     bfc:      	orr	x16, x0, x16, lsl #2
     c00:      	str	q5, [sp, #0x500]
     c04:      	str	q4, [sp, #0x4f0]
     c08:      	ldr	s2, [x16]
     c0c:      	tst	w9, w17
     c10:      	fcsel	s2, s2, s22, ne
     c14:      	umov.b	w30, v24[4]
     c18:      	ands	w16, w30, #0x1
     c1c:      	mov	w9, #0x5                ; =5
     c20:      	csinc	w9, w9, wzr, ne
     c24:      	orr	x17, x10, x9
     c28:      	ldrb	w0, [x17]
     c2c:      	str	q5, [sp, #0x4e0]
     c30:      	str	q4, [sp, #0x4d0]
     c34:      	add	x17, sp, #0x4d0
     c38:      	ldr	s3, [x17, w9, uxtw #2]
     c3c:      	mov	w9, #0x2                ; =2
     c40:      	mov	w7, #0x6                ; =6
     c44:      	csel	w17, w7, w9, ne
     c48:      	tst	w16, w0
     c4c:      	umov.b	w9, v24[5]
     c50:      	fcsel	s3, s3, s22, ne
     c54:      	ands	w0, w9, #0x1
     c58:      	csinc	w1, w27, wzr, ne
     c5c:      	orr	x3, x10, x1
     c60:      	ldrb	w3, [x3]
     c64:      	str	q5, [sp, #0x4c0]
     c68:      	str	q4, [sp, #0x4b0]
     c6c:      	add	x8, sp, #0x4b0
     c70:      	ldr	s6, [x8, w1, uxtw #2]
     c74:      	tst	w0, w3
     c78:      	umov.b	w3, v24[6]
     c7c:      	fcsel	s6, s6, s22, ne
     c80:      	ands	w0, w3, #0x1
     c84:      	mov	w8, #0x7                ; =7
     c88:      	csinc	w1, w8, wzr, ne
     c8c:      	orr	x4, x10, x1
     c90:      	ldrb	w4, [x4]
     c94:      	str	q5, [sp, #0x4a0]
     c98:      	str	q4, [sp, #0x490]
     c9c:      	add	x8, sp, #0x490
     ca0:      	ldr	s7, [x8, w1, uxtw #2]
     ca4:      	tst	w0, w4
     ca8:      	umov.b	w4, v24[7]
     cac:      	fcsel	s7, s7, s22, ne
     cb0:      	ands	w0, w4, #0x1
     cb4:      	csinc	w1, w7, wzr, ne
     cb8:      	orr	x7, x10, x1
     cbc:      	ldrb	w7, [x7]
     cc0:      	str	q5, [sp, #0x480]
     cc4:      	str	q4, [sp, #0x470]
     cc8:      	add	x8, sp, #0x470
     ccc:      	ldr	s19, [x8, w1, uxtw #2]
     cd0:      	tst	w0, w7
     cd4:      	mov.s	v16[1], v17[0]
     cd8:      	mov.s	v16[2], v18[0]
     cdc:      	mov.s	v16[3], v2[0]
     ce0:      	mov.s	v3[1], v6[0]
     ce4:      	fcsel	s2, s19, s22, ne
     ce8:      	mov.s	v3[2], v7[0]
     cec:      	mov.s	v3[3], v2[0]
     cf0:      	fadd.4s	v2, v5, v3
     cf4:      	fadd.4s	v3, v4, v16
     cf8:      	and	w1, w15, w12
     cfc:      	mov	s4, v3[2]
     d00:      	tst	w1, #0x1
     d04:      	fcsel	s4, s4, s22, ne
     d08:      	orr	x0, x10, x17
     d0c:      	ldrb	w0, [x0]
     d10:      	str	q2, [sp, #0x460]
     d14:      	str	q3, [sp, #0x450]
     d18:      	add	x8, sp, #0x450
     d1c:      	ldr	s5, [x8, w17, uxtw #2]
     d20:      	tst	w16, w0
     d24:      	fcsel	s5, s5, s22, ne
     d28:      	fadd.4s	v2, v2, v5
     d2c:      	str	w30, [sp, #0x6c]
     d30:      	and	w8, w15, w30
     d34:      	tst	w8, #0x1
     d38:      	fcsel	s2, s2, s22, ne
     d3c:      	tst	w23, #0x1
     d40:      	fadd.4s	v3, v3, v4
     d44:      	fadd	s2, s3, s2
     d48:      	fcsel	s3, s2, s22, ne
     d4c:      	stp	w8, w1, [sp, #0xa8]
     d50:      	tst	w1, #0x1
     d54:      	fcsel	s4, s2, s22, ne
     d58:      	tst	w8, #0x1
     d5c:      	fcsel	s5, s2, s22, ne
     d60:      	tst	w15, #0x1
     d64:      	and	w8, w26, w15
     d68:      	fcsel	s6, s2, s22, ne
     d6c:      	str	w8, [sp, #0x80]
     d70:      	tst	w8, #0x1
     d74:      	fcsel	s7, s2, s22, ne
     d78:      	and	w8, w9, w15
     d7c:      	str	w8, [sp, #0x7c]
     d80:      	tst	w8, #0x1
     d84:      	fcsel	s16, s2, s22, ne
     d88:      	and	w8, w3, w15
     d8c:      	str	w8, [sp, #0x78]
     d90:      	tst	w8, #0x1
     d94:      	fcsel	s17, s2, s22, ne
     d98:      	and	w8, w4, w15
     d9c:      	str	w8, [sp, #0x84]
     da0:      	tst	w8, #0x1
     da4:      	mov.s	v6[1], v3[0]
     da8:      	mov.s	v6[2], v4[0]
     dac:      	mov.s	v6[3], v7[0]
     db0:      	mov.s	v5[1], v16[0]
     db4:      	mov.s	v5[2], v17[0]
     db8:      	fcsel	s2, s2, s22, ne
     dbc:      	mov.s	v5[3], v2[0]
     dc0:      	rbit	w13, w13
     dc4:      	clz	w8, w13
     dc8:      	str	q5, [sp, #0x440]
     dcc:      	str	q6, [sp, #0x430]
     dd0:      	str	x8, [sp, #0x88]
     dd4:      	and	x13, x8, #0x7
     dd8:      	add	x8, sp, #0x430
     ddc:      	ldr	s2, [x8, x13, lsl #2]
     de0:      	fadd	s2, s2, s22
     de4:      	mov	w8, #0x4000             ; =16384
     de8:      	movk	w8, #0x44c0, lsl #16
     dec:      	fmov	s3, w8
     df0:      	fdiv	s2, s2, s3
     df4:      	dup.4s	v4, v2[0]
     df8:      	ushll2.2d	v2, v0, #0x0
     dfc:      	dup.2d	v3, x2
     e00:      	and.16b	v16, v2, v3
     e04:      	ushll2.2d	v2, v1, #0x0
     e08:      	and.16b	v17, v2, v3
     e0c:      	ushll.2d	v2, v0, #0x0
     e10:      	and.16b	v18, v2, v3
     e14:      	ushll.2d	v2, v1, #0x0
     e18:      	and.16b	v19, v2, v3
     e1c:      	movi.2d	v5, #0000000000000000
     e20:      	and	x13, x15, #0x1
     e24:      	movi.2d	v31, #0000000000000000
     e28:      	movi.2d	v8, #0000000000000000
     e2c:      	movi.2d	v9, #0000000000000000
     e30:      	lsl	x16, x6, #5
     e34:      	add	x17, x25, x16
     e38:      	ldp	q3, q2, [x17]
     e3c:      	fsub.4s	v3, v3, v4
     e40:      	fsub.4s	v2, v2, v4
     e44:      	add	x16, x19, x16
     e48:      	ldp	q6, q7, [x16]
     e4c:      	bif.16b	v2, v7, v0
     e50:      	bif.16b	v3, v6, v1
     e54:      	stp	q3, q2, [x16]
     e58:      	add.2d	v2, v5, v19
     e5c:      	add.2d	v31, v31, v17
     e60:      	add.2d	v8, v8, v18
     e64:      	add.2d	v9, v9, v16
     e68:      	fmov	x16, d5
     e6c:      	add	x6, x16, x13
     e70:      	mov.16b	v5, v2
     e74:      	cmp	x6, #0xc0
     e78:      	b.lt	0xe30 <_llm_rows.packet_batch.blocks+0x994>
     e7c:      	fsub.4s	v5, v25, v4
     e80:      	fsub.4s	v6, v26, v4
     e84:      	add	x16, x19, x21
     e88:      	ldp	q2, q3, [x16]
     e8c:      	zip2.8b	v4, v23, v0
     e90:      	ushll.4s	v4, v4, #0x0
     e94:      	shl.4s	v4, v4, #0x1f
     e98:      	cmlt.4s	v4, v4, #0
     e9c:      	stp	q6, q5, [sp, #0x40]
     ea0:      	bit.16b	v3, v6, v4
     ea4:      	zip1.8b	v4, v23, v0
     ea8:      	ushll.4s	v4, v4, #0x0
     eac:      	shl.4s	v4, v4, #0x1f
     eb0:      	cmlt.4s	v4, v4, #0
     eb4:      	bit.16b	v2, v5, v4
     eb8:      	stp	q2, q3, [x16]
     ebc:      	ldr	q2, [sp, #0x3690]
     ec0:      	ldr	q3, [sp, #0x3680]
     ec4:      	fmul.4s	v3, v3, v3
     ec8:      	fmul.4s	v2, v2, v2
     ecc:      	and.16b	v25, v0, v2
     ed0:      	and.16b	v26, v1, v3
     ed4:      	ldr	q2, [sp, #0x3670]
     ed8:      	ldr	q3, [sp, #0x3660]
     edc:      	fmul.4s	v3, v3, v3
     ee0:      	fmul.4s	v2, v2, v2
     ee4:      	and.16b	v13, v0, v2
     ee8:      	and.16b	v12, v1, v3
     eec:      	ldr	q2, [sp, #0x3650]
     ef0:      	ldr	q3, [sp, #0x3640]
     ef4:      	fmul.4s	v3, v3, v3
     ef8:      	fmul.4s	v2, v2, v2
     efc:      	and.16b	v14, v0, v2
     f00:      	and.16b	v15, v1, v3
     f04:      	ldr	q2, [sp, #0x3630]
     f08:      	ldr	q3, [sp, #0x3620]
     f0c:      	fmul.4s	v3, v3, v3
     f10:      	fmul.4s	v2, v2, v2
     f14:      	and.16b	v9, v0, v2
     f18:      	and.16b	v8, v1, v3
     f1c:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
     f20:      	add	x8, x8, #0xe00
     f24:      	sshll.2d	v2, v1, #0x0
     f28:      	sshll.2d	v3, v0, #0x0
     f2c:      	add	x16, x19, x5, lsl #5
     f30:      	ldp	q5, q4, [x16]
     f34:      	and.16b	v5, v1, v5
     f38:      	and.16b	v4, v0, v4
     f3c:      	fmul.4s	v6, v4, v4
     f40:      	fmul.4s	v4, v5, v5
     f44:      	fadd.4s	v4, v8, v4
     f48:      	fadd.4s	v5, v9, v6
     f4c:      	ldp	q7, q6, [x16, #0x20]
     f50:      	and.16b	v7, v1, v7
     f54:      	and.16b	v6, v0, v6
     f58:      	fmul.4s	v6, v6, v6
     f5c:      	fmul.4s	v7, v7, v7
     f60:      	fadd.4s	v7, v15, v7
     f64:      	fadd.4s	v6, v14, v6
     f68:      	ldp	q23, q22, [x16, #0x40]
     f6c:      	and.16b	v23, v1, v23
     f70:      	and.16b	v22, v0, v22
     f74:      	fmul.4s	v22, v22, v22
     f78:      	fmul.4s	v23, v23, v23
     f7c:      	fadd.4s	v23, v12, v23
     f80:      	fadd.4s	v22, v13, v22
     f84:      	ldp	q24, q10, [x16, #0x60]
     f88:      	and.16b	v24, v1, v24
     f8c:      	and.16b	v10, v0, v10
     f90:      	fmul.4s	v10, v10, v10
     f94:      	fmul.4s	v24, v24, v24
     f98:      	fadd.4s	v24, v26, v24
     f9c:      	fadd.4s	v10, v25, v10
     fa0:      	dup.2d	v31, x27
     fa4:      	and.16b	v11, v21, v31
     fa8:      	add.2d	v27, v27, v11
     fac:      	and.16b	v11, v20, v31
     fb0:      	add.2d	v28, v28, v11
     fb4:      	and.16b	v3, v3, v31
     fb8:      	add.2d	v29, v29, v3
     fbc:      	and.16b	v2, v2, v31
     fc0:      	add.2d	v2, v30, v2
     fc4:      	bit.16b	v9, v5, v0
     fc8:      	bit.16b	v8, v4, v1
     fcc:      	bit.16b	v14, v6, v0
     fd0:      	bit.16b	v15, v7, v1
     fd4:      	bit.16b	v13, v22, v0
     fd8:      	bit.16b	v12, v23, v1
     fdc:      	bit.16b	v25, v10, v0
     fe0:      	bit.16b	v26, v24, v1
     fe4:      	fmov	x16, d30
     fe8:      	add	x17, x16, #0x4
     fec:      	tst	w15, #0x1
     ff0:      	csel	x5, x17, x16, ne
     ff4:      	mov.16b	v30, v2
     ff8:      	cmp	x5, #0xc0
     ffc:      	b.lt	0xf24 <_llm_rows.packet_batch.blocks+0xa88>
    1000:      	mov	x16, #0x0               ; =0
    1004:      	movi.2d	v20, #0000000000000000
    1008:      	movi.2d	v21, #0000000000000000
    100c:      	movi.2d	v27, #0000000000000000
    1010:      	movi.2d	v28, #0000000000000000
    1014:      	ldr	q10, [sp, #0x130]
    1018:      	ldr	q31, [sp, #0x160]
    101c:      	b	0x1058 <_llm_rows.packet_batch.blocks+0xbbc>
    1020:      	add	x16, x8, x16
    1024:      	ldp	q2, q3, [x16]
    1028:      	bit.16b	v3, v30, v0
    102c:      	bit.16b	v2, v29, v1
    1030:      	stp	q2, q3, [x16]
    1034:      	add.2d	v2, v20, v19
    1038:      	add.2d	v21, v21, v17
    103c:      	add.2d	v27, v27, v18
    1040:      	add.2d	v28, v28, v16
    1044:      	fmov	x16, d20
    1048:      	add	x16, x16, x13
    104c:      	mov.16b	v20, v2
    1050:      	cmp	x16, #0xc0
    1054:      	b.ge	0x10f4 <_llm_rows.packet_batch.blocks+0xc58>
    1058:      	fmov	w17, s10
    105c:      	lsl	x16, x16, #5
    1060:      	add	x0, x14, x16
    1064:      	movi.2d	v29, #0000000000000000
    1068:      	movi.2d	v30, #0000000000000000
    106c:      	tbnz	w17, #0x0, 0x1094 <_llm_rows.packet_batch.blocks+0xbf8>
    1070:      	and	w17, w17, #0xff
    1074:      	tbnz	w17, #0x1, 0x10a0 <_llm_rows.packet_batch.blocks+0xc04>
    1078:      	tbnz	w17, #0x2, 0x10ac <_llm_rows.packet_batch.blocks+0xc10>
    107c:      	tbnz	w17, #0x3, 0x10b8 <_llm_rows.packet_batch.blocks+0xc1c>
    1080:      	tbnz	w17, #0x4, 0x10c4 <_llm_rows.packet_batch.blocks+0xc28>
    1084:      	tbnz	w17, #0x5, 0x10d0 <_llm_rows.packet_batch.blocks+0xc34>
    1088:      	tbnz	w17, #0x6, 0x10dc <_llm_rows.packet_batch.blocks+0xc40>
    108c:      	tbz	w17, #0x7, 0x1020 <_llm_rows.packet_batch.blocks+0xb84>
    1090:      	b	0x10e8 <_llm_rows.packet_batch.blocks+0xc4c>
    1094:      	ldr	s29, [x0]
    1098:      	and	w17, w17, #0xff
    109c:      	tbz	w17, #0x1, 0x1078 <_llm_rows.packet_batch.blocks+0xbdc>
    10a0:      	add	x1, x0, #0x4
    10a4:      	ld1.s	{ v29 }[1], [x1]
    10a8:      	tbz	w17, #0x2, 0x107c <_llm_rows.packet_batch.blocks+0xbe0>
    10ac:      	add	x1, x0, #0x8
    10b0:      	ld1.s	{ v29 }[2], [x1]
    10b4:      	tbz	w17, #0x3, 0x1080 <_llm_rows.packet_batch.blocks+0xbe4>
    10b8:      	add	x1, x0, #0xc
    10bc:      	ld1.s	{ v29 }[3], [x1]
    10c0:      	tbz	w17, #0x4, 0x1084 <_llm_rows.packet_batch.blocks+0xbe8>
    10c4:      	add	x1, x0, #0x10
    10c8:      	ld1.s	{ v30 }[0], [x1]
    10cc:      	tbz	w17, #0x5, 0x1088 <_llm_rows.packet_batch.blocks+0xbec>
    10d0:      	add	x1, x0, #0x14
    10d4:      	ld1.s	{ v30 }[1], [x1]
    10d8:      	tbz	w17, #0x6, 0x108c <_llm_rows.packet_batch.blocks+0xbf0>
    10dc:      	add	x1, x0, #0x18
    10e0:      	ld1.s	{ v30 }[2], [x1]
    10e4:      	tbz	w17, #0x7, 0x1020 <_llm_rows.packet_batch.blocks+0xb84>
    10e8:      	add	x17, x0, #0x1c
    10ec:      	ld1.s	{ v30 }[3], [x17]
    10f0:      	b	0x1020 <_llm_rows.packet_batch.blocks+0xb84>
    10f4:      	str	w22, [sp, #0x90]
    10f8:      	str	x21, [sp, #0xc0]
    10fc:      	zip2.8b	v2, v31, v0
    1100:      	ushll.4s	v2, v2, #0x0
    1104:      	shl.4s	v2, v2, #0x1f
    1108:      	cmlt.4s	v2, v2, #0
    110c:      	ldp	q3, q6, [sp, #0x40]
    1110:      	and.16b	v20, v2, v3
    1114:      	zip1.8b	v3, v31, v0
    1118:      	ushll.4s	v3, v3, #0x0
    111c:      	shl.4s	v3, v3, #0x1f
    1120:      	cmlt.4s	v3, v3, #0
    1124:      	and.16b	v21, v3, v6
    1128:      	fmul.4s	v6, v21, v21
    112c:      	fmul.4s	v7, v20, v20
    1130:      	fadd.4s	v7, v7, v9
    1134:      	fadd.4s	v6, v6, v8
    1138:      	and.16b	v3, v3, v6
    113c:      	and.16b	v2, v2, v7
    1140:      	ldr	d7, [sp, #0x70]
    1144:      	zip2.8b	v6, v7, v0
    1148:      	ushll.4s	v6, v6, #0x0
    114c:      	shl.4s	v6, v6, #0x1f
    1150:      	cmlt.4s	v6, v6, #0
    1154:      	bit.16b	v2, v5, v6
    1158:      	zip1.8b	v5, v7, v0
    115c:      	ushll.4s	v5, v5, #0x0
    1160:      	shl.4s	v5, v5, #0x1f
    1164:      	cmlt.4s	v5, v5, #0
    1168:      	bit.16b	v3, v4, v5
    116c:      	fadd.4s	v3, v15, v3
    1170:      	fadd.4s	v2, v14, v2
    1174:      	fadd.4s	v2, v13, v2
    1178:      	fadd.4s	v3, v12, v3
    117c:      	fadd.4s	v4, v26, v3
    1180:      	fadd.4s	v5, v25, v2
    1184:      	add	x16, sp, #0x1d8
    1188:      	bfxil	x16, x15, #0, #1
    118c:      	ldr	q2, [sp, #0x150]
    1190:      	str	d2, [sp, #0x1d8]
    1194:      	ldrb	w16, [x16]
    1198:      	add	x17, sp, #0x400
    119c:      	bfi	x17, x15, #2, #1
    11a0:      	str	q5, [sp, #0x410]
    11a4:      	str	q4, [sp, #0x400]
    11a8:      	ldr	s2, [x17]
    11ac:      	ands	w6, w15, #0x1
    11b0:      	mov	w10, #0x2               ; =2
    11b4:      	csel	w17, w10, wzr, ne
    11b8:      	csel	w5, w27, wzr, ne
    11bc:      	tst	w6, w16
    11c0:      	movi	d27, #0000000000000000
    11c4:      	fcsel	s23, s2, s27, ne
    11c8:      	tst	w23, #0x1
    11cc:      	fcsel	s25, s4, s27, ne
    11d0:      	ands	w12, w12, #0x1
    11d4:      	mov	w8, #0x3                ; =3
    11d8:      	csel	w16, w8, wzr, ne
    11dc:      	mov	w30, #0x4               ; =4
    11e0:      	add	x27, sp, #0x1d8
    11e4:      	orr	x0, x27, x16
    11e8:      	ldrb	w0, [x0]
    11ec:      	add	x8, sp, #0x3e0
    11f0:      	orr	x16, x8, x16, lsl #2
    11f4:      	stp	q4, q5, [sp, #0x3e0]
    11f8:      	ldr	s2, [x16]
    11fc:      	tst	w12, w0
    1200:      	fcsel	s24, s2, s27, ne
    1204:      	ands	w16, w26, #0x1
    1208:      	csel	w12, w10, wzr, ne
    120c:      	orr	x0, x27, x12
    1210:      	ldrb	w0, [x0]
    1214:      	lsr	x12, x12, #1
    1218:      	add	x1, sp, #0x3c0
    121c:      	bfi	x1, x12, #3, #1
    1220:      	stp	q4, q5, [sp, #0x3c0]
    1224:      	ldr	s2, [x1]
    1228:      	tst	w16, w0
    122c:      	fcsel	s26, s2, s27, ne
    1230:      	ands	w12, w4, #0x1
    1234:      	mov	w8, #0x6                ; =6
    1238:      	str	w23, [sp, #0x150]
    123c:      	csel	w23, w8, wzr, ne
    1240:      	mov	w10, #0x5               ; =5
    1244:      	csel	w4, w10, wzr, ne
    1248:      	ands	w7, w3, #0x1
    124c:      	mov	w2, #0x7                ; =7
    1250:      	mov	x22, x26
    1254:      	csel	w26, w2, wzr, ne
    1258:      	csel	w3, w30, wzr, ne
    125c:      	ands	w0, w9, #0x1
    1260:      	csel	w1, w30, wzr, ne
    1264:      	csel	w9, w2, wzr, ne
    1268:      	ldr	w2, [sp, #0x6c]
    126c:      	ands	w30, w2, #0x1
    1270:      	csel	w2, w10, wzr, ne
    1274:      	orr	x10, x27, x2
    1278:      	ldrb	w10, [x10]
    127c:      	stp	q4, q5, [sp, #0x3a0]
    1280:      	add	x21, sp, #0x3a0
    1284:      	ldr	s2, [x21, w2, uxtw #2]
    1288:      	orr	x2, x27, x1
    128c:      	ldrb	w2, [x2]
    1290:      	stp	q4, q5, [sp, #0x380]
    1294:      	add	x21, sp, #0x380
    1298:      	ldr	s3, [x21, w1, uxtw #2]
    129c:      	csel	w1, w8, wzr, ne
    12a0:      	tst	w30, w10
    12a4:      	fcsel	s2, s2, s27, ne
    12a8:      	tst	w0, w2
    12ac:      	orr	x10, x27, x26
    12b0:      	ldrb	w10, [x10]
    12b4:      	stp	q4, q5, [sp, #0x360]
    12b8:      	add	x8, sp, #0x360
    12bc:      	ldr	s6, [x8, w26, uxtw #2]
    12c0:      	fcsel	s3, s3, s27, ne
    12c4:      	tst	w7, w10
    12c8:      	orr	x10, x27, x23
    12cc:      	ldrb	w10, [x10]
    12d0:      	stp	q4, q5, [sp, #0x340]
    12d4:      	add	x8, sp, #0x340
    12d8:      	ldr	s7, [x8, w23, uxtw #2]
    12dc:      	fcsel	s6, s6, s27, ne
    12e0:      	tst	w12, w10
    12e4:      	fcsel	s7, s7, s27, ne
    12e8:      	mov.s	v2[1], v3[0]
    12ec:      	mov.s	v2[2], v6[0]
    12f0:      	mov.s	v2[3], v7[0]
    12f4:      	mov.s	v23[1], v25[0]
    12f8:      	lsr	x10, x17, #1
    12fc:      	add	x2, sp, #0x320
    1300:      	bfi	x2, x10, #3, #1
    1304:      	mov.s	v23[2], v24[0]
    1308:      	mov.s	v23[3], v26[0]
    130c:      	fadd.4s	v4, v4, v23
    1310:      	fadd.4s	v5, v5, v2
    1314:      	orr	x10, x27, x17
    1318:      	ldrb	w10, [x10]
    131c:      	stp	q4, q5, [sp, #0x320]
    1320:      	ldr	s2, [x2]
    1324:      	tst	w6, w10
    1328:      	fcsel	s23, s2, s27, ne
    132c:      	ldr	w8, [sp, #0xa4]
    1330:      	ands	w10, w8, #0x1
    1334:      	mov	w8, #0x3                ; =3
    1338:      	csel	w17, w8, wzr, ne
    133c:      	orr	x2, x27, x17
    1340:      	ldrb	w2, [x2]
    1344:      	tst	w10, w2
    1348:      	add	x8, sp, #0x260
    134c:      	orr	x10, x8, x17, lsl #2
    1350:      	stp	q4, q5, [sp, #0x260]
    1354:      	ldr	s2, [x10]
    1358:      	add	x10, sp, #0x1d8
    135c:      	bfxil	x10, x22, #0, #1
    1360:      	ldrb	w10, [x10]
    1364:      	fcsel	s2, s2, s27, ne
    1368:      	ldr	w17, [sp, #0xac]
    136c:      	tst	w17, #0x1
    1370:      	fcsel	s3, s4, s27, ne
    1374:      	tst	w16, w10
    1378:      	add	x10, sp, #0x300
    137c:      	bfi	x10, x22, #2, #1
    1380:      	stp	q4, q5, [sp, #0x300]
    1384:      	ldr	s6, [x10]
    1388:      	orr	x10, x27, x1
    138c:      	ldrb	w10, [x10]
    1390:      	stp	q4, q5, [sp, #0x2e0]
    1394:      	add	x8, sp, #0x2e0
    1398:      	ldr	s7, [x8, w1, uxtw #2]
    139c:      	fcsel	s6, s6, s27, ne
    13a0:      	tst	w30, w10
    13a4:      	fcsel	s7, s7, s27, ne
    13a8:      	orr	x10, x27, x9
    13ac:      	ldrb	w10, [x10]
    13b0:      	tst	w0, w10
    13b4:      	stp	q4, q5, [sp, #0x2c0]
    13b8:      	add	x8, sp, #0x2c0
    13bc:      	ldr	s22, [x8, w9, uxtw #2]
    13c0:      	fcsel	s22, s22, s27, ne
    13c4:      	orr	x9, x27, x3
    13c8:      	ldrb	w9, [x9]
    13cc:      	tst	w7, w9
    13d0:      	stp	q4, q5, [sp, #0x2a0]
    13d4:      	add	x8, sp, #0x2a0
    13d8:      	ldr	s24, [x8, w3, uxtw #2]
    13dc:      	orr	x9, x27, x4
    13e0:      	ldrb	w9, [x9]
    13e4:      	stp	q4, q5, [sp, #0x280]
    13e8:      	add	x8, sp, #0x280
    13ec:      	ldr	s25, [x8, w4, uxtw #2]
    13f0:      	fcsel	s24, s24, s27, ne
    13f4:      	tst	w12, w9
    13f8:      	fcsel	s25, s25, s27, ne
    13fc:      	mov.s	v23[1], v2[0]
    1400:      	mov.s	v23[2], v3[0]
    1404:      	mov.s	v23[3], v6[0]
    1408:      	mov.s	v7[1], v22[0]
    140c:      	orr	x9, x27, x5
    1410:      	ldrb	w9, [x9]
    1414:      	tst	w6, w9
    1418:      	mov.s	v7[2], v24[0]
    141c:      	mov.s	v7[3], v25[0]
    1420:      	fadd.4s	v2, v4, v23
    1424:      	fadd.4s	v3, v5, v7
    1428:      	stp	q2, q3, [sp, #0x240]
    142c:      	add	x8, sp, #0x240
    1430:      	ldr	s3, [x8, w5, uxtw #2]
    1434:      	fcsel	s3, s3, s27, ne
    1438:      	tst	w15, #0x1
    143c:      	fadd	s2, s2, s3
    1440:      	fcsel	s3, s2, s27, ne
    1444:      	ldr	w8, [sp, #0x150]
    1448:      	tst	w8, #0x1
    144c:      	fcsel	s4, s2, s27, ne
    1450:      	tst	w17, #0x1
    1454:      	fcsel	s5, s2, s27, ne
    1458:      	ldr	w8, [sp, #0x80]
    145c:      	tst	w8, #0x1
    1460:      	fcsel	s6, s2, s27, ne
    1464:      	ldr	w8, [sp, #0xa8]
    1468:      	tst	w8, #0x1
    146c:      	fcsel	s7, s2, s27, ne
    1470:      	ldp	w8, w9, [sp, #0x78]
    1474:      	tst	w9, #0x1
    1478:      	fcsel	s22, s2, s27, ne
    147c:      	tst	w8, #0x1
    1480:      	sshll.2d	v24, v1, #0x0
    1484:      	adrp	x8, 0x1000 <_llm_rows.packet_batch.blocks+0xb64>
    1488:      	ldr	d23, [x8]
    148c:      	shl.8b	v25, v31, #0x7
    1490:      	cmlt.8b	v25, v25, #0
    1494:      	and.8b	v23, v25, v23
    1498:      	addv.8b	b23, v23
    149c:      	fcsel	s25, s2, s27, ne
    14a0:      	ldr	w8, [sp, #0x84]
    14a4:      	tst	w8, #0x1
    14a8:      	mov.s	v3[1], v4[0]
    14ac:      	mov.s	v3[2], v5[0]
    14b0:      	mov.s	v3[3], v6[0]
    14b4:      	mov.s	v7[1], v22[0]
    14b8:      	movi	d5, #0000000000000000
    14bc:      	fcsel	s2, s2, s27, ne
    14c0:      	mov.s	v7[2], v25[0]
    14c4:      	mov.s	v7[3], v2[0]
    14c8:      	stp	q3, q7, [sp, #0x220]
    14cc:      	ldr	x8, [sp, #0x88]
    14d0:      	and	x9, x8, #0x7
    14d4:      	add	x8, sp, #0x220
    14d8:      	ldr	s4, [x8, x9, lsl #2]
    14dc:      	ldr	q2, [sp, #0xb0]
    14e0:      	and.16b	v2, v24, v2
    14e4:      	movi.2d	v3, #0000000000000000
    14e8:      	stp	q3, q3, [sp, #0x200]
    14ec:      	stp	q2, q3, [sp, #0x1e0]
    14f0:      	ldr	x2, [sp, #0x128]
    14f4:      	and	x9, x2, #0x7
    14f8:      	add	x8, sp, #0x1e0
    14fc:      	ldr	x9, [x8, x9, lsl #3]
    1500:      	fmov	w12, s23
    1504:      	sub	x9, x9, x2
    1508:      	lsl	x9, x9, #2
    150c:      	add	x14, x14, x9
    1510:      	movi.2d	v22, #0000000000000000
    1514:      	movi.2d	v24, #0000000000000000
    1518:      	tbnz	w12, #0x0, 0x194c <_llm_rows.packet_batch.blocks+0x14b0>
    151c:      	add	x16, sp, #0x5e0
    1520:      	ldr	x1, [sp, #0x140]
    1524:      	ldr	x3, [sp, #0x108]
    1528:      	tbnz	w12, #0x1, 0x1960 <_llm_rows.packet_batch.blocks+0x14c4>
    152c:      	mov	w27, #0x4               ; =4
    1530:      	ldr	x17, [sp, #0xc0]
    1534:      	ldr	w22, [sp, #0x90]
    1538:      	tbnz	w12, #0x2, 0x1978 <_llm_rows.packet_batch.blocks+0x14dc>
    153c:      	tbnz	w12, #0x3, 0x1984 <_llm_rows.packet_batch.blocks+0x14e8>
    1540:      	tbnz	w12, #0x4, 0x1990 <_llm_rows.packet_batch.blocks+0x14f4>
    1544:      	tbnz	w12, #0x5, 0x199c <_llm_rows.packet_batch.blocks+0x1500>
    1548:      	tbnz	w12, #0x6, 0x19a8 <_llm_rows.packet_batch.blocks+0x150c>
    154c:      	tbz	w12, #0x7, 0x1558 <_llm_rows.packet_batch.blocks+0x10bc>
    1550:      	add	x10, x14, #0x1c
    1554:      	ld1.s	{ v24 }[3], [x10]
    1558:      	fadd	s2, s4, s5
    155c:      	mov	w8, #0x4000             ; =16384
    1560:      	movk	w8, #0x44c0, lsl #16
    1564:      	fmov	s3, w8
    1568:      	fdiv	s2, s2, s3
    156c:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
    1570:      	add	x8, x8, #0xe00
    1574:      	add	x10, x8, x17
    1578:      	ldp	q3, q4, [x10]
    157c:      	zip2.8b	v5, v31, v0
    1580:      	ushll.4s	v5, v5, #0x0
    1584:      	shl.4s	v5, v5, #0x1f
    1588:      	cmlt.4s	v5, v5, #0
    158c:      	bit.16b	v4, v24, v5
    1590:      	zip1.8b	v5, v31, v0
    1594:      	ushll.4s	v5, v5, #0x0
    1598:      	shl.4s	v5, v5, #0x1f
    159c:      	cmlt.4s	v5, v5, #0
    15a0:      	bit.16b	v3, v22, v5
    15a4:      	stp	q3, q4, [x10]
    15a8:      	mov	w10, #0xc5ac            ; =50604
    15ac:      	movk	w10, #0x3727, lsl #16
    15b0:      	fmov	s3, w10
    15b4:      	fadd	s2, s2, s3
    15b8:      	fsqrt	s25, s2
    15bc:      	subs	x10, x1, x11
    15c0:      	lsr	x10, x10, #3
    15c4:      	mov	w12, #0x300             ; =768
    15c8:      	ccmp	x10, x12, #0x0, hs
    15cc:      	cset	w12, hi
    15d0:      	sub	x10, x11, x1
    15d4:      	mov	w14, #0x2007            ; =8199
    15d8:      	movk	w14, #0x18, lsl #16
    15dc:      	cmp	x10, x14
    15e0:      	ccmp	x11, x1, #0x0, hi
    15e4:      	b.hs	0x16d8 <_llm_rows.packet_batch.blocks+0x123c>
    15e8:      	tbnz	w12, #0x0, 0x16d8 <_llm_rows.packet_batch.blocks+0x123c>
    15ec:      	mov	x12, #0x0               ; =0
    15f0:      	movi.2d	v4, #0000000000000000
    15f4:      	movi.2d	v5, #0000000000000000
    15f8:      	movi.2d	v26, #0000000000000000
    15fc:      	movi.2d	v27, #0000000000000000
    1600:      	b	0x163c <_llm_rows.packet_batch.blocks+0x11a0>
    1604:      	add	x10, x16, x12
    1608:      	ldp	q2, q3, [x10]
    160c:      	bit.16b	v3, v29, v0
    1610:      	bit.16b	v2, v28, v1
    1614:      	stp	q2, q3, [x10]
    1618:      	add.2d	v2, v4, v19
    161c:      	add.2d	v5, v5, v17
    1620:      	add.2d	v26, v26, v18
    1624:      	add.2d	v27, v27, v16
    1628:      	fmov	x10, d4
    162c:      	add	x12, x10, x13
    1630:      	mov.16b	v4, v2
    1634:      	cmp	x12, #0xc0
    1638:      	b.ge	0x19b8 <_llm_rows.packet_batch.blocks+0x151c>
    163c:      	fmov	w15, s10
    1640:      	lsl	x12, x12, #5
    1644:      	add	x14, x11, x12
    1648:      	movi.2d	v28, #0000000000000000
    164c:      	movi.2d	v29, #0000000000000000
    1650:      	tbnz	w15, #0x0, 0x1678 <_llm_rows.packet_batch.blocks+0x11dc>
    1654:      	and	w15, w15, #0xff
    1658:      	tbnz	w15, #0x1, 0x1684 <_llm_rows.packet_batch.blocks+0x11e8>
    165c:      	tbnz	w15, #0x2, 0x1690 <_llm_rows.packet_batch.blocks+0x11f4>
    1660:      	tbnz	w15, #0x3, 0x169c <_llm_rows.packet_batch.blocks+0x1200>
    1664:      	tbnz	w15, #0x4, 0x16a8 <_llm_rows.packet_batch.blocks+0x120c>
    1668:      	tbnz	w15, #0x5, 0x16b4 <_llm_rows.packet_batch.blocks+0x1218>
    166c:      	tbnz	w15, #0x6, 0x16c0 <_llm_rows.packet_batch.blocks+0x1224>
    1670:      	tbz	w15, #0x7, 0x1604 <_llm_rows.packet_batch.blocks+0x1168>
    1674:      	b	0x16cc <_llm_rows.packet_batch.blocks+0x1230>
    1678:      	ldr	s28, [x14]
    167c:      	and	w15, w15, #0xff
    1680:      	tbz	w15, #0x1, 0x165c <_llm_rows.packet_batch.blocks+0x11c0>
    1684:      	add	x10, x14, #0x4
    1688:      	ld1.s	{ v28 }[1], [x10]
    168c:      	tbz	w15, #0x2, 0x1660 <_llm_rows.packet_batch.blocks+0x11c4>
    1690:      	add	x10, x14, #0x8
    1694:      	ld1.s	{ v28 }[2], [x10]
    1698:      	tbz	w15, #0x3, 0x1664 <_llm_rows.packet_batch.blocks+0x11c8>
    169c:      	add	x10, x14, #0xc
    16a0:      	ld1.s	{ v28 }[3], [x10]
    16a4:      	tbz	w15, #0x4, 0x1668 <_llm_rows.packet_batch.blocks+0x11cc>
    16a8:      	add	x10, x14, #0x10
    16ac:      	ld1.s	{ v29 }[0], [x10]
    16b0:      	tbz	w15, #0x5, 0x166c <_llm_rows.packet_batch.blocks+0x11d0>
    16b4:      	add	x10, x14, #0x14
    16b8:      	ld1.s	{ v29 }[1], [x10]
    16bc:      	tbz	w15, #0x6, 0x1670 <_llm_rows.packet_batch.blocks+0x11d4>
    16c0:      	add	x10, x14, #0x18
    16c4:      	ld1.s	{ v29 }[2], [x10]
    16c8:      	tbz	w15, #0x7, 0x1604 <_llm_rows.packet_batch.blocks+0x1168>
    16cc:      	add	x10, x14, #0x1c
    16d0:      	ld1.s	{ v29 }[3], [x10]
    16d4:      	b	0x1604 <_llm_rows.packet_batch.blocks+0x1168>
    16d8:      	mov	x14, #0x0               ; =0
    16dc:      	dup.4s	v7, v25[0]
    16e0:      	movi.2d	v4, #0000000000000000
    16e4:      	movi.2d	v5, #0000000000000000
    16e8:      	movi.2d	v25, #0000000000000000
    16ec:      	movi.2d	v26, #0000000000000000
    16f0:      	b	0x1710 <_llm_rows.packet_batch.blocks+0x1274>
    16f4:      	add.2d	v4, v4, v19
    16f8:      	add.2d	v5, v5, v17
    16fc:      	add.2d	v25, v25, v18
    1700:      	add.2d	v26, v26, v16
    1704:      	add	x14, x12, x13
    1708:      	cmp	x14, #0xc0
    170c:      	b.ge	0x189c <_llm_rows.packet_batch.blocks+0x1400>
    1710:      	fmov	w17, s10
    1714:      	fmov	x12, d4
    1718:      	lsl	x15, x12, #5
    171c:      	add	x16, x11, x15
    1720:      	movi.2d	v28, #0000000000000000
    1724:      	movi.2d	v27, #0000000000000000
    1728:      	tbnz	w17, #0x0, 0x17cc <_llm_rows.packet_batch.blocks+0x1330>
    172c:      	and	w17, w17, #0xff
    1730:      	tbnz	w17, #0x1, 0x17d8 <_llm_rows.packet_batch.blocks+0x133c>
    1734:      	tbnz	w17, #0x2, 0x17e4 <_llm_rows.packet_batch.blocks+0x1348>
    1738:      	tbnz	w17, #0x3, 0x17f0 <_llm_rows.packet_batch.blocks+0x1354>
    173c:      	tbnz	w17, #0x4, 0x17fc <_llm_rows.packet_batch.blocks+0x1360>
    1740:      	tbnz	w17, #0x5, 0x1808 <_llm_rows.packet_batch.blocks+0x136c>
    1744:      	tbnz	w17, #0x6, 0x1814 <_llm_rows.packet_batch.blocks+0x1378>
    1748:      	tbz	w17, #0x7, 0x1754 <_llm_rows.packet_batch.blocks+0x12b8>
    174c:      	add	x10, x16, #0x1c
    1750:      	ld1.s	{ v27 }[3], [x10]
    1754:      	lsl	x10, x14, #5
    1758:      	add	x16, x19, x10
    175c:      	ldr	q2, [x16]
    1760:      	and.16b	v2, v1, v2
    1764:      	fdiv.4s	v2, v2, v7
    1768:      	add	x17, x8, x10
    176c:      	ldr	q3, [x17]
    1770:      	and.16b	v3, v1, v3
    1774:      	fmul.4s	v2, v2, v3
    1778:      	fmov	w0, s10
    177c:      	fadd.4s	v28, v28, v2
    1780:      	add	x10, x1, x15
    1784:      	add	x14, x10, x3
    1788:      	tbnz	w0, #0x0, 0x1824 <_llm_rows.packet_batch.blocks+0x1388>
    178c:      	and	w15, w0, #0xff
    1790:      	tbnz	w15, #0x1, 0x1830 <_llm_rows.packet_batch.blocks+0x1394>
    1794:      	ldr	q30, [x16, #0x10]
    1798:      	ldr	q29, [x17, #0x10]
    179c:      	tbnz	w15, #0x2, 0x1844 <_llm_rows.packet_batch.blocks+0x13a8>
    17a0:      	tbnz	w15, #0x3, 0x1850 <_llm_rows.packet_batch.blocks+0x13b4>
    17a4:      	and.16b	v2, v0, v30
    17a8:      	fdiv.4s	v2, v2, v7
    17ac:      	and.16b	v3, v0, v29
    17b0:      	fmul.4s	v2, v2, v3
    17b4:      	fadd.4s	v27, v27, v2
    17b8:      	tbnz	w15, #0x4, 0x1870 <_llm_rows.packet_batch.blocks+0x13d4>
    17bc:      	tbnz	w15, #0x5, 0x1878 <_llm_rows.packet_batch.blocks+0x13dc>
    17c0:      	tbnz	w15, #0x6, 0x1884 <_llm_rows.packet_batch.blocks+0x13e8>
    17c4:      	tbz	w15, #0x7, 0x16f4 <_llm_rows.packet_batch.blocks+0x1258>
    17c8:      	b	0x1890 <_llm_rows.packet_batch.blocks+0x13f4>
    17cc:      	ldr	s28, [x16]
    17d0:      	and	w17, w17, #0xff
    17d4:      	tbz	w17, #0x1, 0x1734 <_llm_rows.packet_batch.blocks+0x1298>
    17d8:      	add	x10, x16, #0x4
    17dc:      	ld1.s	{ v28 }[1], [x10]
    17e0:      	tbz	w17, #0x2, 0x1738 <_llm_rows.packet_batch.blocks+0x129c>
    17e4:      	add	x10, x16, #0x8
    17e8:      	ld1.s	{ v28 }[2], [x10]
    17ec:      	tbz	w17, #0x3, 0x173c <_llm_rows.packet_batch.blocks+0x12a0>
    17f0:      	add	x10, x16, #0xc
    17f4:      	ld1.s	{ v28 }[3], [x10]
    17f8:      	tbz	w17, #0x4, 0x1740 <_llm_rows.packet_batch.blocks+0x12a4>
    17fc:      	add	x10, x16, #0x10
    1800:      	ld1.s	{ v27 }[0], [x10]
    1804:      	tbz	w17, #0x5, 0x1744 <_llm_rows.packet_batch.blocks+0x12a8>
    1808:      	add	x10, x16, #0x14
    180c:      	ld1.s	{ v27 }[1], [x10]
    1810:      	tbz	w17, #0x6, 0x1748 <_llm_rows.packet_batch.blocks+0x12ac>
    1814:      	add	x10, x16, #0x18
    1818:      	ld1.s	{ v27 }[2], [x10]
    181c:      	tbnz	w17, #0x7, 0x174c <_llm_rows.packet_batch.blocks+0x12b0>
    1820:      	b	0x1754 <_llm_rows.packet_batch.blocks+0x12b8>
    1824:      	str	s28, [x14]
    1828:      	and	w15, w0, #0xff
    182c:      	tbz	w15, #0x1, 0x1794 <_llm_rows.packet_batch.blocks+0x12f8>
    1830:      	add	x10, x14, #0x4
    1834:      	st1.s	{ v28 }[1], [x10]
    1838:      	ldr	q30, [x16, #0x10]
    183c:      	ldr	q29, [x17, #0x10]
    1840:      	tbz	w15, #0x2, 0x17a0 <_llm_rows.packet_batch.blocks+0x1304>
    1844:      	add	x10, x14, #0x8
    1848:      	st1.s	{ v28 }[2], [x10]
    184c:      	tbz	w15, #0x3, 0x17a4 <_llm_rows.packet_batch.blocks+0x1308>
    1850:      	add	x10, x14, #0xc
    1854:      	st1.s	{ v28 }[3], [x10]
    1858:      	and.16b	v2, v0, v30
    185c:      	fdiv.4s	v2, v2, v7
    1860:      	and.16b	v3, v0, v29
    1864:      	fmul.4s	v2, v2, v3
    1868:      	fadd.4s	v27, v27, v2
    186c:      	tbz	w15, #0x4, 0x17bc <_llm_rows.packet_batch.blocks+0x1320>
    1870:      	str	s27, [x14, #0x10]
    1874:      	tbz	w15, #0x5, 0x17c0 <_llm_rows.packet_batch.blocks+0x1324>
    1878:      	add	x10, x14, #0x14
    187c:      	st1.s	{ v27 }[1], [x10]
    1880:      	tbz	w15, #0x6, 0x17c4 <_llm_rows.packet_batch.blocks+0x1328>
    1884:      	add	x10, x14, #0x18
    1888:      	st1.s	{ v27 }[2], [x10]
    188c:      	tbz	w15, #0x7, 0x16f4 <_llm_rows.packet_batch.blocks+0x1258>
    1890:      	add	x10, x14, #0x1c
    1894:      	st1.s	{ v27 }[3], [x10]
    1898:      	b	0x16f4 <_llm_rows.packet_batch.blocks+0x1258>
    189c:      	add	x9, x11, x9
    18a0:      	fmov	w10, s23
    18a4:      	movi.2d	v0, #0000000000000000
    18a8:      	movi.2d	v1, #0000000000000000
    18ac:      	tbnz	w10, #0x0, 0x1c04 <_llm_rows.packet_batch.blocks+0x1768>
    18b0:      	ldr	w12, [sp, #0x148]
    18b4:      	tbnz	w10, #0x1, 0x1c10 <_llm_rows.packet_batch.blocks+0x1774>
    18b8:      	tbnz	w10, #0x2, 0x1c1c <_llm_rows.packet_batch.blocks+0x1780>
    18bc:      	tbnz	w10, #0x3, 0x1c28 <_llm_rows.packet_batch.blocks+0x178c>
    18c0:      	tbnz	w10, #0x4, 0x1c34 <_llm_rows.packet_batch.blocks+0x1798>
    18c4:      	tbnz	w10, #0x5, 0x1c40 <_llm_rows.packet_batch.blocks+0x17a4>
    18c8:      	tbnz	w10, #0x6, 0x1c4c <_llm_rows.packet_batch.blocks+0x17b0>
    18cc:      	tbz	w10, #0x7, 0x18d8 <_llm_rows.packet_batch.blocks+0x143c>
    18d0:      	add	x9, x9, #0x1c
    18d4:      	ld1.s	{ v1 }[3], [x9]
    18d8:      	fdiv.4s	v2, v20, v7
    18dc:      	fdiv.4s	v3, v21, v7
    18e0:      	fmul.4s	v3, v3, v22
    18e4:      	fmul.4s	v4, v2, v24
    18e8:      	fadd.4s	v2, v3, v0
    18ec:      	fadd.4s	v0, v4, v1
    18f0:      	b	0x1b5c <_llm_rows.packet_batch.blocks+0x16c0>
    18f4:      	ldr	s22, [x9]
    18f8:      	tbz	w12, #0x1, 0x890 <_llm_rows.packet_batch.blocks+0x3f4>
    18fc:      	add	x16, x9, #0x4
    1900:      	ld1.s	{ v22 }[1], [x16]
    1904:      	tbz	w12, #0x2, 0x894 <_llm_rows.packet_batch.blocks+0x3f8>
    1908:      	add	x16, x9, #0x8
    190c:      	ld1.s	{ v22 }[2], [x16]
    1910:      	tbz	w12, #0x3, 0x898 <_llm_rows.packet_batch.blocks+0x3fc>
    1914:      	add	x16, x9, #0xc
    1918:      	ld1.s	{ v22 }[3], [x16]
    191c:      	tbz	w12, #0x4, 0x89c <_llm_rows.packet_batch.blocks+0x400>
    1920:      	add	x16, x9, #0x10
    1924:      	ld1.s	{ v23 }[0], [x16]
    1928:      	tbz	w12, #0x5, 0x8a0 <_llm_rows.packet_batch.blocks+0x404>
    192c:      	add	x16, x9, #0x14
    1930:      	ld1.s	{ v23 }[1], [x16]
    1934:      	tbz	w12, #0x6, 0x8a4 <_llm_rows.packet_batch.blocks+0x408>
    1938:      	add	x16, x9, #0x18
    193c:      	ld1.s	{ v23 }[2], [x16]
    1940:      	str	q20, [sp, #0x130]
    1944:      	tbnz	w12, #0x7, 0x8ac <_llm_rows.packet_batch.blocks+0x410>
    1948:      	b	0x8b4 <_llm_rows.packet_batch.blocks+0x418>
    194c:      	ldr	s22, [x14]
    1950:      	add	x16, sp, #0x5e0
    1954:      	ldr	x1, [sp, #0x140]
    1958:      	ldr	x3, [sp, #0x108]
    195c:      	tbz	w12, #0x1, 0x152c <_llm_rows.packet_batch.blocks+0x1090>
    1960:      	add	x10, x14, #0x4
    1964:      	ld1.s	{ v22 }[1], [x10]
    1968:      	mov	w27, #0x4               ; =4
    196c:      	ldr	x17, [sp, #0xc0]
    1970:      	ldr	w22, [sp, #0x90]
    1974:      	tbz	w12, #0x2, 0x153c <_llm_rows.packet_batch.blocks+0x10a0>
    1978:      	add	x10, x14, #0x8
    197c:      	ld1.s	{ v22 }[2], [x10]
    1980:      	tbz	w12, #0x3, 0x1540 <_llm_rows.packet_batch.blocks+0x10a4>
    1984:      	add	x10, x14, #0xc
    1988:      	ld1.s	{ v22 }[3], [x10]
    198c:      	tbz	w12, #0x4, 0x1544 <_llm_rows.packet_batch.blocks+0x10a8>
    1990:      	add	x10, x14, #0x10
    1994:      	ld1.s	{ v24 }[0], [x10]
    1998:      	tbz	w12, #0x5, 0x1548 <_llm_rows.packet_batch.blocks+0x10ac>
    199c:      	add	x10, x14, #0x14
    19a0:      	ld1.s	{ v24 }[1], [x10]
    19a4:      	tbz	w12, #0x6, 0x154c <_llm_rows.packet_batch.blocks+0x10b0>
    19a8:      	add	x10, x14, #0x18
    19ac:      	ld1.s	{ v24 }[2], [x10]
    19b0:      	tbnz	w12, #0x7, 0x1550 <_llm_rows.packet_batch.blocks+0x10b4>
    19b4:      	b	0x1558 <_llm_rows.packet_batch.blocks+0x10bc>
    19b8:      	add	x9, x11, x9
    19bc:      	fmov	w11, s23
    19c0:      	movi.2d	v4, #0000000000000000
    19c4:      	movi.2d	v5, #0000000000000000
    19c8:      	tbnz	w11, #0x0, 0x1c5c <_llm_rows.packet_batch.blocks+0x17c0>
    19cc:      	tbnz	w11, #0x1, 0x1c64 <_llm_rows.packet_batch.blocks+0x17c8>
    19d0:      	tbnz	w11, #0x2, 0x1c70 <_llm_rows.packet_batch.blocks+0x17d4>
    19d4:      	tbnz	w11, #0x3, 0x1c7c <_llm_rows.packet_batch.blocks+0x17e0>
    19d8:      	tbnz	w11, #0x4, 0x1c88 <_llm_rows.packet_batch.blocks+0x17ec>
    19dc:      	tbnz	w11, #0x5, 0x1c94 <_llm_rows.packet_batch.blocks+0x17f8>
    19e0:      	tbnz	w11, #0x6, 0x1ca0 <_llm_rows.packet_batch.blocks+0x1804>
    19e4:      	tbz	w11, #0x7, 0x19f0 <_llm_rows.packet_batch.blocks+0x1554>
    19e8:      	add	x9, x9, #0x1c
    19ec:      	ld1.s	{ v5 }[3], [x9]
    19f0:      	mov	x11, #0x0               ; =0
    19f4:      	add	x9, x16, x17
    19f8:      	ldp	q2, q3, [x9]
    19fc:      	zip2.8b	v6, v31, v0
    1a00:      	ushll.4s	v6, v6, #0x0
    1a04:      	shl.4s	v6, v6, #0x1f
    1a08:      	cmlt.4s	v6, v6, #0
    1a0c:      	bit.16b	v3, v5, v6
    1a10:      	zip1.8b	v6, v31, v0
    1a14:      	ushll.4s	v6, v6, #0x0
    1a18:      	shl.4s	v6, v6, #0x1f
    1a1c:      	cmlt.4s	v6, v6, #0
    1a20:      	bit.16b	v2, v4, v6
    1a24:      	dup.4s	v7, v25[0]
    1a28:      	stp	q2, q3, [x9]
    1a2c:      	add	x9, x1, x3
    1a30:      	movi.2d	v25, #0000000000000000
    1a34:      	movi.2d	v26, #0000000000000000
    1a38:      	movi.2d	v27, #0000000000000000
    1a3c:      	movi.2d	v28, #0000000000000000
    1a40:      	b	0x1a68 <_llm_rows.packet_batch.blocks+0x15cc>
    1a44:      	add.2d	v2, v25, v19
    1a48:      	add.2d	v26, v26, v17
    1a4c:      	add.2d	v27, v27, v18
    1a50:      	add.2d	v28, v28, v16
    1a54:      	fmov	x10, d25
    1a58:      	add	x11, x10, x13
    1a5c:      	mov.16b	v25, v2
    1a60:      	cmp	x11, #0xc0
    1a64:      	b.ge	0x1b40 <_llm_rows.packet_batch.blocks+0x16a4>
    1a68:      	fmov	w12, s10
    1a6c:      	lsl	x10, x11, #5
    1a70:      	add	x11, x19, x10
    1a74:      	ldp	q2, q29, [x11]
    1a78:      	and.16b	v2, v1, v2
    1a7c:      	fdiv.4s	v2, v2, v7
    1a80:      	add	x11, x8, x10
    1a84:      	ldp	q3, q30, [x11]
    1a88:      	and.16b	v3, v1, v3
    1a8c:      	fmul.4s	v2, v2, v3
    1a90:      	add	x11, x16, x10
    1a94:      	ldp	q3, q31, [x11]
    1a98:      	and.16b	v3, v1, v3
    1a9c:      	fadd.4s	v8, v2, v3
    1aa0:      	add	x10, x9, x10
    1aa4:      	tbnz	w12, #0x0, 0x1aec <_llm_rows.packet_batch.blocks+0x1650>
    1aa8:      	and	w11, w12, #0xff
    1aac:      	tbnz	w11, #0x1, 0x1af8 <_llm_rows.packet_batch.blocks+0x165c>
    1ab0:      	tbnz	w11, #0x2, 0x1b04 <_llm_rows.packet_batch.blocks+0x1668>
    1ab4:      	tbz	w11, #0x3, 0x1ac0 <_llm_rows.packet_batch.blocks+0x1624>
    1ab8:      	add	x12, x10, #0xc
    1abc:      	st1.s	{ v8 }[3], [x12]
    1ac0:      	and.16b	v2, v0, v29
    1ac4:      	fdiv.4s	v2, v2, v7
    1ac8:      	and.16b	v3, v0, v30
    1acc:      	fmul.4s	v2, v2, v3
    1ad0:      	and.16b	v3, v0, v31
    1ad4:      	fadd.4s	v29, v2, v3
    1ad8:      	tbnz	w11, #0x4, 0x1b14 <_llm_rows.packet_batch.blocks+0x1678>
    1adc:      	tbnz	w11, #0x5, 0x1b1c <_llm_rows.packet_batch.blocks+0x1680>
    1ae0:      	tbnz	w11, #0x6, 0x1b28 <_llm_rows.packet_batch.blocks+0x168c>
    1ae4:      	tbz	w11, #0x7, 0x1a44 <_llm_rows.packet_batch.blocks+0x15a8>
    1ae8:      	b	0x1b34 <_llm_rows.packet_batch.blocks+0x1698>
    1aec:      	str	s8, [x10]
    1af0:      	and	w11, w12, #0xff
    1af4:      	tbz	w11, #0x1, 0x1ab0 <_llm_rows.packet_batch.blocks+0x1614>
    1af8:      	add	x12, x10, #0x4
    1afc:      	st1.s	{ v8 }[1], [x12]
    1b00:      	tbz	w11, #0x2, 0x1ab4 <_llm_rows.packet_batch.blocks+0x1618>
    1b04:      	add	x12, x10, #0x8
    1b08:      	st1.s	{ v8 }[2], [x12]
    1b0c:      	tbnz	w11, #0x3, 0x1ab8 <_llm_rows.packet_batch.blocks+0x161c>
    1b10:      	b	0x1ac0 <_llm_rows.packet_batch.blocks+0x1624>
    1b14:      	str	s29, [x10, #0x10]
    1b18:      	tbz	w11, #0x5, 0x1ae0 <_llm_rows.packet_batch.blocks+0x1644>
    1b1c:      	add	x12, x10, #0x14
    1b20:      	st1.s	{ v29 }[1], [x12]
    1b24:      	tbz	w11, #0x6, 0x1ae4 <_llm_rows.packet_batch.blocks+0x1648>
    1b28:      	add	x12, x10, #0x18
    1b2c:      	st1.s	{ v29 }[2], [x12]
    1b30:      	tbz	w11, #0x7, 0x1a44 <_llm_rows.packet_batch.blocks+0x15a8>
    1b34:      	add	x10, x10, #0x1c
    1b38:      	st1.s	{ v29 }[3], [x10]
    1b3c:      	b	0x1a44 <_llm_rows.packet_batch.blocks+0x15a8>
    1b40:      	fdiv.4s	v0, v21, v7
    1b44:      	fdiv.4s	v1, v20, v7
    1b48:      	fmul.4s	v1, v1, v24
    1b4c:      	fmul.4s	v0, v0, v22
    1b50:      	fadd.4s	v2, v0, v4
    1b54:      	fadd.4s	v0, v1, v5
    1b58:      	ldr	w12, [sp, #0x148]
    1b5c:      	ldr	q3, [sp, #0x110]
    1b60:      	ldp	q4, q5, [sp, #0xe0]
    1b64:      	stp	q3, q4, [sp, #0x190]
    1b68:      	ldr	q1, [sp, #0xd0]
    1b6c:      	stp	q5, q1, [sp, #0x1b0]
    1b70:      	and	x9, x2, #0x7
    1b74:      	add	x8, sp, #0x190
    1b78:      	ldr	x9, [x8, x9, lsl #3]
    1b7c:      	sub	x9, x9, x2
    1b80:      	add	x8, x1, x9, lsl #2
    1b84:      	fmov	w9, s23
    1b88:      	tbnz	w9, #0x0, 0x1bac <_llm_rows.packet_batch.blocks+0x1710>
    1b8c:      	tbnz	w9, #0x1, 0x1bb4 <_llm_rows.packet_batch.blocks+0x1718>
    1b90:      	tbnz	w9, #0x2, 0x1bc0 <_llm_rows.packet_batch.blocks+0x1724>
    1b94:      	tbnz	w9, #0x3, 0x1bcc <_llm_rows.packet_batch.blocks+0x1730>
    1b98:      	tbnz	w9, #0x4, 0x1bd8 <_llm_rows.packet_batch.blocks+0x173c>
    1b9c:      	tbnz	w9, #0x5, 0x1be0 <_llm_rows.packet_batch.blocks+0x1744>
    1ba0:      	tbnz	w9, #0x6, 0x1bec <_llm_rows.packet_batch.blocks+0x1750>
    1ba4:      	tbz	w9, #0x7, 0x538 <_llm_rows.packet_batch.blocks+0x9c>
    1ba8:      	b	0x1bf8 <_llm_rows.packet_batch.blocks+0x175c>
    1bac:      	str	s2, [x8]
    1bb0:      	tbz	w9, #0x1, 0x1b90 <_llm_rows.packet_batch.blocks+0x16f4>
    1bb4:      	add	x10, x8, #0x4
    1bb8:      	st1.s	{ v2 }[1], [x10]
    1bbc:      	tbz	w9, #0x2, 0x1b94 <_llm_rows.packet_batch.blocks+0x16f8>
    1bc0:      	add	x10, x8, #0x8
    1bc4:      	st1.s	{ v2 }[2], [x10]
    1bc8:      	tbz	w9, #0x3, 0x1b98 <_llm_rows.packet_batch.blocks+0x16fc>
    1bcc:      	add	x10, x8, #0xc
    1bd0:      	st1.s	{ v2 }[3], [x10]
    1bd4:      	tbz	w9, #0x4, 0x1b9c <_llm_rows.packet_batch.blocks+0x1700>
    1bd8:      	str	s0, [x8, #0x10]
    1bdc:      	tbz	w9, #0x5, 0x1ba0 <_llm_rows.packet_batch.blocks+0x1704>
    1be0:      	add	x10, x8, #0x14
    1be4:      	st1.s	{ v0 }[1], [x10]
    1be8:      	tbz	w9, #0x6, 0x1ba4 <_llm_rows.packet_batch.blocks+0x1708>
    1bec:      	add	x10, x8, #0x18
    1bf0:      	st1.s	{ v0 }[2], [x10]
    1bf4:      	tbz	w9, #0x7, 0x538 <_llm_rows.packet_batch.blocks+0x9c>
    1bf8:      	add	x8, x8, #0x1c
    1bfc:      	st1.s	{ v0 }[3], [x8]
    1c00:      	b	0x538 <_llm_rows.packet_batch.blocks+0x9c>
    1c04:      	ldr	s0, [x9]
    1c08:      	ldr	w12, [sp, #0x148]
    1c0c:      	tbz	w10, #0x1, 0x18b8 <_llm_rows.packet_batch.blocks+0x141c>
    1c10:      	add	x11, x9, #0x4
    1c14:      	ld1.s	{ v0 }[1], [x11]
    1c18:      	tbz	w10, #0x2, 0x18bc <_llm_rows.packet_batch.blocks+0x1420>
    1c1c:      	add	x11, x9, #0x8
    1c20:      	ld1.s	{ v0 }[2], [x11]
    1c24:      	tbz	w10, #0x3, 0x18c0 <_llm_rows.packet_batch.blocks+0x1424>
    1c28:      	add	x11, x9, #0xc
    1c2c:      	ld1.s	{ v0 }[3], [x11]
    1c30:      	tbz	w10, #0x4, 0x18c4 <_llm_rows.packet_batch.blocks+0x1428>
    1c34:      	add	x11, x9, #0x10
    1c38:      	ld1.s	{ v1 }[0], [x11]
    1c3c:      	tbz	w10, #0x5, 0x18c8 <_llm_rows.packet_batch.blocks+0x142c>
    1c40:      	add	x11, x9, #0x14
    1c44:      	ld1.s	{ v1 }[1], [x11]
    1c48:      	tbz	w10, #0x6, 0x18cc <_llm_rows.packet_batch.blocks+0x1430>
    1c4c:      	add	x11, x9, #0x18
    1c50:      	ld1.s	{ v1 }[2], [x11]
    1c54:      	tbnz	w10, #0x7, 0x18d0 <_llm_rows.packet_batch.blocks+0x1434>
    1c58:      	b	0x18d8 <_llm_rows.packet_batch.blocks+0x143c>
    1c5c:      	ldr	s4, [x9]
    1c60:      	tbz	w11, #0x1, 0x19d0 <_llm_rows.packet_batch.blocks+0x1534>
    1c64:      	add	x10, x9, #0x4
    1c68:      	ld1.s	{ v4 }[1], [x10]
    1c6c:      	tbz	w11, #0x2, 0x19d4 <_llm_rows.packet_batch.blocks+0x1538>
    1c70:      	add	x10, x9, #0x8
    1c74:      	ld1.s	{ v4 }[2], [x10]
    1c78:      	tbz	w11, #0x3, 0x19d8 <_llm_rows.packet_batch.blocks+0x153c>
    1c7c:      	add	x10, x9, #0xc
    1c80:      	ld1.s	{ v4 }[3], [x10]
    1c84:      	tbz	w11, #0x4, 0x19dc <_llm_rows.packet_batch.blocks+0x1540>
    1c88:      	add	x10, x9, #0x10
    1c8c:      	ld1.s	{ v5 }[0], [x10]
    1c90:      	tbz	w11, #0x5, 0x19e0 <_llm_rows.packet_batch.blocks+0x1544>
    1c94:      	add	x10, x9, #0x14
    1c98:      	ld1.s	{ v5 }[1], [x10]
    1c9c:      	tbz	w11, #0x6, 0x19e4 <_llm_rows.packet_batch.blocks+0x1548>
    1ca0:      	add	x10, x9, #0x18
    1ca4:      	ld1.s	{ v5 }[2], [x10]
    1ca8:      	tbnz	w11, #0x7, 0x19e8 <_llm_rows.packet_batch.blocks+0x154c>
    1cac:      	b	0x19f0 <_llm_rows.packet_batch.blocks+0x1554>
    1cb0:      	add	sp, sp, #0x6, lsl #12   ; =0x6000
    1cb4:      	add	sp, sp, #0x660
    1cb8:      	ldp	x29, x30, [sp, #0x90]
    1cbc:      	ldp	x20, x19, [sp, #0x80]
    1cc0:      	ldp	x22, x21, [sp, #0x70]
    1cc4:      	ldp	x24, x23, [sp, #0x60]
    1cc8:      	ldp	x26, x25, [sp, #0x50]
    1ccc:      	ldp	x28, x27, [sp, #0x40]
    1cd0:      	ldp	d9, d8, [sp, #0x30]
    1cd4:      	ldp	d11, d10, [sp, #0x20]
    1cd8:      	ldp	d13, d12, [sp, #0x10]
    1cdc:      	ldp	d15, d14, [sp], #0xa0
    1ce0:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/swiglu-129x768/on/object/tile_xir_w8_37989_1788936541577751_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d9, d8, [sp, #-0x50]!
       4:      	stp	x24, x23, [sp, #0x10]
       8:      	stp	x22, x21, [sp, #0x20]
       c:      	stp	x20, x19, [sp, #0x30]
      10:      	stp	x29, x30, [sp, #0x40]
      14:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      18:      	sub	sp, sp, #0x800
      1c:      	ldr	x11, [x0]
      20:      	ldr	x23, [x0, #0x10]
      24:      	ldr	x21, [x0, #0x30]
      28:      	ldr	w8, [x1]
      2c:      	ldr	w9, [x1, #0x24]
      30:      	add	w8, w9, w8, lsl #5
      34:      	lsr	w8, w8, #3
      38:      	subs	x9, x11, x21
      3c:      	lsr	x9, x9, #10
      40:      	mov	w10, #0x182             ; =386
      44:      	ccmp	x9, x10, #0x0, hs
      48:      	cset	w9, hi
      4c:      	subs	x12, x21, x11
      50:      	lsr	x12, x12, #10
      54:      	ccmp	x12, x10, #0x0, hs
      58:      	csinc	w9, w9, wzr, ls
      5c:      	subs	x12, x23, x21
      60:      	lsr	x12, x12, #10
      64:      	ccmp	x12, x10, #0x0, hs
      68:      	cset	w12, hi
      6c:      	subs	x13, x21, x23
      70:      	lsr	x13, x13, #10
      74:      	ccmp	x13, x10, #0x0, hs
      78:      	csinc	w10, w12, wzr, ls
      7c:      	mov	w12, #0xc00             ; =3072
      80:      	umull	x22, w8, w12
      84:      	cmp	w9, #0x1
      88:      	ccmp	w10, #0x0, #0x4, eq
      8c:      	b.ne	0x2f0 <ltmp0+0x2f0>
      90:      	add	x19, sp, #0xc00
      94:      	add	x0, sp, #0xc00
      98:      	add	x1, x11, x22
      9c:      	mov	w2, #0xc00              ; =3072
      a0:      	bl	0xa0 <ltmp0+0xa0>
      a4:      	mov	x20, sp
      a8:      	mov	x0, sp
      ac:      	add	x1, x23, x22
      b0:      	mov	w2, #0xc00              ; =3072
      b4:      	bl	0xb4 <ltmp0+0xb4>
      b8:      	mov	x8, #0x0                ; =0
      bc:      	mov	w9, #0x42d00000         ; =1120927744
      c0:      	dup.4s	v0, w9
      c4:      	mov	w9, #-0x3d380000        ; =-1027080192
      c8:      	dup.4s	v1, w9
      cc:      	mov	w9, #0xaa3b             ; =43579
      d0:      	movk	w9, #0x3fb8, lsl #16
      d4:      	dup.4s	v2, w9
      d8:      	mov	w9, #0x7200             ; =29184
      dc:      	movk	w9, #0xbf31, lsl #16
      e0:      	dup.4s	v3, w9
      e4:      	mov	w9, #0xbe8e             ; =48782
      e8:      	movk	w9, #0xb5bf, lsl #16
      ec:      	dup.4s	v4, w9
      f0:      	mov	w9, #0x2bda             ; =11226
      f4:      	movk	w9, #0x3950, lsl #16
      f8:      	dup.4s	v5, w9
      fc:      	mov	w9, #0x96c9             ; =38601
     100:      	movk	w9, #0x3ab6, lsl #16
     104:      	dup.4s	v6, w9
     108:      	mov	w9, #0x88a6             ; =34982
     10c:      	movk	w9, #0x3c08, lsl #16
     110:      	dup.4s	v7, w9
     114:      	mov	w9, #0xaa7a             ; =43642
     118:      	movk	w9, #0x3d2a, lsl #16
     11c:      	dup.4s	v16, w9
     120:      	add	x9, x21, x22
     124:      	mov	w10, #0xaaab            ; =43691
     128:      	movk	w10, #0x3e2a, lsl #16
     12c:      	dup.4s	v17, w10
     130:      	movi.4s	v18, #0x4b, lsl #24
     134:      	mvni.4s	v19, #0x80, lsl #24
     138:      	movi.4s	v20, #0x3f, lsl #24
     13c:      	fmov.4s	v21, #1.00000000
     140:      	mvni.4s	v22, #0x7f, msl #16
     144:      	fneg.4s	v22, v22
     148:      	mvni.4s	v23, #0x3f, msl #16
     14c:      	fneg.4s	v23, v23
     150:      	add	x10, x19, x8
     154:      	ldp	q24, q25, [x10]
     158:      	fneg.4s	v26, v25
     15c:      	fneg.4s	v27, v24
     160:      	fcmge.4s	v28, v0, v24
     164:      	fcmge.4s	v29, v0, v25
     168:      	fcmge.4s	v30, v24, v1
     16c:      	fcmge.4s	v31, v25, v1
     170:      	and.16b	v29, v29, v31
     174:      	and.16b	v28, v28, v30
     178:      	and.16b	v27, v28, v27
     17c:      	and.16b	v26, v29, v26
     180:      	fmul.4s	v28, v26, v2
     184:      	fmul.4s	v29, v27, v2
     188:      	mov.16b	v30, v19
     18c:      	bsl.16b	v30, v18, v29
     190:      	mov.16b	v31, v19
     194:      	bsl.16b	v31, v18, v28
     198:      	fadd.4s	v28, v28, v31
     19c:      	fadd.4s	v29, v29, v30
     1a0:      	fsub.4s	v29, v29, v30
     1a4:      	fsub.4s	v28, v28, v31
     1a8:      	fcvtzs.4s	v28, v28
     1ac:      	fcvtzs.4s	v29, v29
     1b0:      	scvtf.4s	v30, v29
     1b4:      	scvtf.4s	v31, v28
     1b8:      	fmul.4s	v8, v31, v3
     1bc:      	fmul.4s	v9, v30, v3
     1c0:      	fadd.4s	v27, v27, v9
     1c4:      	fadd.4s	v26, v26, v8
     1c8:      	fmul.4s	v30, v30, v4
     1cc:      	fmul.4s	v31, v31, v4
     1d0:      	fadd.4s	v26, v26, v31
     1d4:      	fadd.4s	v27, v27, v30
     1d8:      	fmul.4s	v30, v27, v5
     1dc:      	fmul.4s	v31, v26, v5
     1e0:      	fadd.4s	v31, v31, v6
     1e4:      	fadd.4s	v30, v30, v6
     1e8:      	fmul.4s	v30, v27, v30
     1ec:      	fmul.4s	v31, v26, v31
     1f0:      	fadd.4s	v31, v31, v7
     1f4:      	fadd.4s	v30, v30, v7
     1f8:      	fmul.4s	v30, v27, v30
     1fc:      	fmul.4s	v31, v26, v31
     200:      	fadd.4s	v31, v31, v16
     204:      	fadd.4s	v30, v30, v16
     208:      	fmul.4s	v30, v27, v30
     20c:      	fmul.4s	v31, v26, v31
     210:      	fadd.4s	v31, v31, v17
     214:      	fadd.4s	v30, v30, v17
     218:      	fmul.4s	v30, v27, v30
     21c:      	fmul.4s	v31, v26, v31
     220:      	fadd.4s	v31, v31, v20
     224:      	fadd.4s	v30, v30, v20
     228:      	fmul.4s	v8, v26, v26
     22c:      	fmul.4s	v9, v27, v27
     230:      	fmul.4s	v30, v9, v30
     234:      	fmul.4s	v31, v8, v31
     238:      	fadd.4s	v26, v26, v31
     23c:      	fadd.4s	v27, v27, v30
     240:      	sshr.4s	v30, v29, #0x1
     244:      	fadd.4s	v27, v27, v21
     248:      	sshr.4s	v31, v28, #0x1
     24c:      	shl.4s	v8, v31, #0x17
     250:      	shl.4s	v9, v30, #0x17
     254:      	add.4s	v9, v9, v21
     258:      	add.4s	v8, v8, v21
     25c:      	fadd.4s	v26, v26, v21
     260:      	fmul.4s	v26, v26, v8
     264:      	sub.4s	v28, v28, v31
     268:      	sub.4s	v29, v29, v30
     26c:      	shl.4s	v29, v29, #0x17
     270:      	shl.4s	v28, v28, #0x17
     274:      	fmul.4s	v27, v27, v9
     278:      	add.4s	v28, v28, v21
     27c:      	add.4s	v29, v29, v21
     280:      	fmul.4s	v27, v27, v29
     284:      	fmul.4s	v26, v26, v28
     288:      	fcmgt.4s	v28, v25, v0
     28c:      	fcmgt.4s	v29, v24, v0
     290:      	fcmgt.4s	v30, v1, v24
     294:      	fcmgt.4s	v31, v1, v25
     298:      	fcmeq.4s	v8, v25, v25
     29c:      	fadd.4s	v26, v26, v21
     2a0:      	fadd.4s	v27, v27, v21
     2a4:      	fcmeq.4s	v9, v24, v24
     2a8:      	bit.16b	v27, v21, v29
     2ac:      	bit.16b	v26, v21, v28
     2b0:      	bit.16b	v26, v22, v31
     2b4:      	bit.16b	v27, v22, v30
     2b8:      	bif.16b	v27, v23, v9
     2bc:      	bif.16b	v26, v23, v8
     2c0:      	fdiv.4s	v25, v25, v26
     2c4:      	fdiv.4s	v24, v24, v27
     2c8:      	add	x10, x20, x8
     2cc:      	ldp	q27, q26, [x10]
     2d0:      	fmul.4s	v24, v27, v24
     2d4:      	fmul.4s	v25, v26, v25
     2d8:      	add	x10, x9, x8
     2dc:      	stp	q24, q25, [x10]
     2e0:      	add	x8, x8, #0x20
     2e4:      	cmp	x8, #0xc00
     2e8:      	b.ne	0x150 <ltmp0+0x150>
     2ec:      	b	0x52c <ltmp0+0x52c>
     2f0:      	mov	x8, #0x0                ; =0
     2f4:      	mov	w9, #0x42d00000         ; =1120927744
     2f8:      	dup.4s	v0, w9
     2fc:      	mov	w9, #-0x3d380000        ; =-1027080192
     300:      	dup.4s	v1, w9
     304:      	mov	w9, #0xaa3b             ; =43579
     308:      	movk	w9, #0x3fb8, lsl #16
     30c:      	dup.4s	v2, w9
     310:      	mov	w9, #0x7200             ; =29184
     314:      	movk	w9, #0xbf31, lsl #16
     318:      	dup.4s	v3, w9
     31c:      	mov	w9, #0xbe8e             ; =48782
     320:      	movk	w9, #0xb5bf, lsl #16
     324:      	dup.4s	v4, w9
     328:      	mov	w9, #0x2bda             ; =11226
     32c:      	movk	w9, #0x3950, lsl #16
     330:      	dup.4s	v5, w9
     334:      	mov	w9, #0x96c9             ; =38601
     338:      	movk	w9, #0x3ab6, lsl #16
     33c:      	dup.4s	v6, w9
     340:      	mov	w9, #0x88a6             ; =34982
     344:      	movk	w9, #0x3c08, lsl #16
     348:      	dup.4s	v7, w9
     34c:      	mov	w9, #0xaa7a             ; =43642
     350:      	movk	w9, #0x3d2a, lsl #16
     354:      	dup.4s	v16, w9
     358:      	add	x9, x21, x22
     35c:      	add	x10, x23, x22
     360:      	add	x11, x11, x22
     364:      	mov	w12, #0xaaab            ; =43691
     368:      	movk	w12, #0x3e2a, lsl #16
     36c:      	dup.4s	v17, w12
     370:      	movi.4s	v18, #0x4b, lsl #24
     374:      	mvni.4s	v19, #0x80, lsl #24
     378:      	movi.4s	v20, #0x3f, lsl #24
     37c:      	fmov.4s	v21, #1.00000000
     380:      	mvni.4s	v22, #0x7f, msl #16
     384:      	fneg.4s	v22, v22
     388:      	mvni.4s	v23, #0x3f, msl #16
     38c:      	fneg.4s	v23, v23
     390:      	add	x12, x11, x8
     394:      	ldp	q24, q25, [x12]
     398:      	fneg.4s	v26, v25
     39c:      	fneg.4s	v27, v24
     3a0:      	fcmge.4s	v28, v0, v24
     3a4:      	fcmge.4s	v29, v0, v25
     3a8:      	fcmge.4s	v30, v24, v1
     3ac:      	fcmge.4s	v31, v25, v1
     3b0:      	and.16b	v29, v29, v31
     3b4:      	and.16b	v28, v28, v30
     3b8:      	and.16b	v27, v28, v27
     3bc:      	and.16b	v26, v29, v26
     3c0:      	fmul.4s	v28, v26, v2
     3c4:      	fmul.4s	v29, v27, v2
     3c8:      	mov.16b	v30, v19
     3cc:      	bsl.16b	v30, v18, v29
     3d0:      	mov.16b	v31, v19
     3d4:      	bsl.16b	v31, v18, v28
     3d8:      	fadd.4s	v28, v28, v31
     3dc:      	fadd.4s	v29, v29, v30
     3e0:      	fsub.4s	v29, v29, v30
     3e4:      	fsub.4s	v28, v28, v31
     3e8:      	fcvtzs.4s	v28, v28
     3ec:      	fcvtzs.4s	v29, v29
     3f0:      	scvtf.4s	v30, v29
     3f4:      	scvtf.4s	v31, v28
     3f8:      	fmul.4s	v8, v31, v3
     3fc:      	fmul.4s	v9, v30, v3
     400:      	fadd.4s	v27, v27, v9
     404:      	fadd.4s	v26, v26, v8
     408:      	fmul.4s	v30, v30, v4
     40c:      	fmul.4s	v31, v31, v4
     410:      	fadd.4s	v26, v26, v31
     414:      	fadd.4s	v27, v27, v30
     418:      	fmul.4s	v30, v27, v5
     41c:      	fmul.4s	v31, v26, v5
     420:      	fadd.4s	v31, v31, v6
     424:      	fadd.4s	v30, v30, v6
     428:      	fmul.4s	v30, v27, v30
     42c:      	fmul.4s	v31, v26, v31
     430:      	fadd.4s	v31, v31, v7
     434:      	fadd.4s	v30, v30, v7
     438:      	fmul.4s	v30, v27, v30
     43c:      	fmul.4s	v31, v26, v31
     440:      	fadd.4s	v31, v31, v16
     444:      	fadd.4s	v30, v30, v16
     448:      	fmul.4s	v30, v27, v30
     44c:      	fmul.4s	v31, v26, v31
     450:      	fadd.4s	v31, v31, v17
     454:      	fadd.4s	v30, v30, v17
     458:      	fmul.4s	v30, v27, v30
     45c:      	fmul.4s	v31, v26, v31
     460:      	fadd.4s	v31, v31, v20
     464:      	fadd.4s	v30, v30, v20
     468:      	fmul.4s	v8, v26, v26
     46c:      	fmul.4s	v9, v27, v27
     470:      	fmul.4s	v30, v9, v30
     474:      	fmul.4s	v31, v8, v31
     478:      	fadd.4s	v26, v26, v31
     47c:      	fadd.4s	v27, v27, v30
     480:      	sshr.4s	v30, v29, #0x1
     484:      	fadd.4s	v27, v27, v21
     488:      	sshr.4s	v31, v28, #0x1
     48c:      	shl.4s	v8, v31, #0x17
     490:      	shl.4s	v9, v30, #0x17
     494:      	add.4s	v9, v9, v21
     498:      	add.4s	v8, v8, v21
     49c:      	fadd.4s	v26, v26, v21
     4a0:      	fmul.4s	v26, v26, v8
     4a4:      	sub.4s	v28, v28, v31
     4a8:      	sub.4s	v29, v29, v30
     4ac:      	shl.4s	v29, v29, #0x17
     4b0:      	shl.4s	v28, v28, #0x17
     4b4:      	fmul.4s	v27, v27, v9
     4b8:      	add.4s	v28, v28, v21
     4bc:      	add.4s	v29, v29, v21
     4c0:      	fmul.4s	v27, v27, v29
     4c4:      	fmul.4s	v26, v26, v28
     4c8:      	fcmgt.4s	v28, v25, v0
     4cc:      	fcmgt.4s	v29, v24, v0
     4d0:      	fcmgt.4s	v30, v1, v24
     4d4:      	fcmgt.4s	v31, v1, v25
     4d8:      	fcmeq.4s	v8, v25, v25
     4dc:      	fadd.4s	v26, v26, v21
     4e0:      	fadd.4s	v27, v27, v21
     4e4:      	fcmeq.4s	v9, v24, v24
     4e8:      	bit.16b	v27, v21, v29
     4ec:      	bit.16b	v26, v21, v28
     4f0:      	bit.16b	v26, v22, v31
     4f4:      	bit.16b	v27, v22, v30
     4f8:      	bif.16b	v27, v23, v9
     4fc:      	bif.16b	v26, v23, v8
     500:      	fdiv.4s	v25, v25, v26
     504:      	fdiv.4s	v24, v24, v27
     508:      	add	x12, x10, x8
     50c:      	ldp	q27, q26, [x12]
     510:      	fmul.4s	v24, v27, v24
     514:      	fmul.4s	v25, v26, v25
     518:      	add	x12, x9, x8
     51c:      	stp	q24, q25, [x12]
     520:      	add	x8, x8, #0x20
     524:      	cmp	x8, #0xc00
     528:      	b.ne	0x390 <ltmp0+0x390>
     52c:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
     530:      	add	sp, sp, #0x800
     534:      	ldp	x29, x30, [sp, #0x40]
     538:      	ldp	x20, x19, [sp, #0x30]
     53c:      	ldp	x22, x21, [sp, #0x20]
     540:      	ldp	x24, x23, [sp, #0x10]
     544:      	ldp	d9, d8, [sp], #0x50
     548:      	ret

000000000000054c <_llm_rows.packet_batch.blocks>:
     54c:      	stp	d13, d12, [sp, #-0x90]!
     550:      	stp	d11, d10, [sp, #0x10]
     554:      	stp	d9, d8, [sp, #0x20]
     558:      	stp	x28, x27, [sp, #0x30]
     55c:      	stp	x26, x25, [sp, #0x40]
     560:      	stp	x24, x23, [sp, #0x50]
     564:      	stp	x22, x21, [sp, #0x60]
     568:      	stp	x20, x19, [sp, #0x70]
     56c:      	stp	x29, x30, [sp, #0x80]
     570:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
     574:      	sub	sp, sp, #0x890
     578:      	str	x0, [sp, #0x80]
     57c:      	cbz	w3, 0xfb0 <_llm_rows.packet_batch.blocks+0xa64>
     580:      	mov	x19, x3
     584:      	mov	x20, x2
     588:      	mov	w22, #0x0               ; =0
     58c:      	ldp	w9, w8, [x2, #0x2c]
     590:      	stp	w8, w9, [sp, #0x78]
     594:      	ldp	w27, w25, [x2]
     598:      	movi.4s	v31, #0x4b, lsl #24
     59c:      	ldp	w26, w28, [x2, #0x8]
     5a0:      	mvni.4s	v8, #0x80, lsl #24
     5a4:      	adrp	x8, 0x0 <ltmp0>
     5a8:      	ldr	q0, [x8]
     5ac:      	str	q0, [sp, #0x20]
     5b0:      	adrp	x8, 0x0 <ltmp0>
     5b4:      	ldr	q0, [x8]
     5b8:      	str	q0, [sp, #0x10]
     5bc:      	adrp	x8, 0x0 <ltmp0>
     5c0:      	ldr	q9, [x8]
     5c4:      	movi.4s	v10, #0x3f, lsl #24
     5c8:      	mvni.4s	v0, #0x7f, msl #16
     5cc:      	fneg.4s	v11, v0
     5d0:      	mvni.4s	v0, #0x3f, msl #16
     5d4:      	fneg.4s	v12, v0
     5d8:      	add	x23, sp, #0xc90
     5dc:      	add	x24, sp, #0x90
     5e0:      	stp	q11, q9, [sp, #0x50]
     5e4:      	str	q12, [sp, #0x40]
     5e8:      	str	w3, [sp, #0x3c]
     5ec:      	b	0x634 <_llm_rows.packet_batch.blocks+0xe8>
     5f0:      	mov	w8, #0x18               ; =24
     5f4:      	str	w8, [x20, #0x24]
     5f8:      	ldr	w19, [sp, #0x3c]
     5fc:      	add	w8, w27, #0x1
     600:      	ldp	w10, w9, [sp, #0x78]
     604:      	cmp	w8, w9
     608:      	cset	w8, eq
     60c:      	csinc	w27, wzr, w27, eq
     610:      	cinc	w9, w25, eq
     614:      	cmp	w9, w10
     618:      	cset	w10, eq
     61c:      	ands	w8, w8, w10
     620:      	csel	w25, wzr, w9, ne
     624:      	add	w26, w26, w8
     628:      	add	w22, w22, #0x1
     62c:      	cmp	w22, w19
     630:      	b.eq	0xfb0 <_llm_rows.packet_batch.blocks+0xa64>
     634:      	ubfiz	x8, x27, #5, #32
     638:      	cmp	x8, x28
     63c:      	csel	x9, x8, xzr, ls
     640:      	subs	x10, x28, x9
     644:      	cmp	x10, #0x20
     648:      	mov	w11, #0x20              ; =32
     64c:      	csel	x10, x10, x11, lo
     650:      	cmp	x28, x9
     654:      	stp	w27, w25, [x20]
     658:      	str	w26, [x20, #0x8]
     65c:      	str	wzr, [x20, #0x24]
     660:      	ccmp	x8, x28, #0x2, hi
     664:      	csel	x21, x10, xzr, ls
     668:      	cmp	x21, #0x20
     66c:      	b.lo	0x6d4 <_llm_rows.packet_batch.blocks+0x188>
     670:      	ldr	x21, [sp, #0x80]
     674:      	mov	x0, x21
     678:      	mov	x1, x20
     67c:      	bl	0x67c <_llm_rows.packet_batch.blocks+0x130>
     680:      	mov	w8, #0x8                ; =8
     684:      	str	w8, [x20, #0x24]
     688:      	mov	x0, x21
     68c:      	mov	x1, x20
     690:      	bl	0x690 <_llm_rows.packet_batch.blocks+0x144>
     694:      	mov	w8, #0x10               ; =16
     698:      	str	w8, [x20, #0x24]
     69c:      	mov	x0, x21
     6a0:      	mov	x1, x20
     6a4:      	bl	0x6a4 <_llm_rows.packet_batch.blocks+0x158>
     6a8:      	mov	w8, #0x18               ; =24
     6ac:      	str	w8, [x20, #0x24]
     6b0:      	mov	x0, x21
     6b4:      	mov	x1, x20
     6b8:      	bl	0x6b8 <_llm_rows.packet_batch.blocks+0x16c>
     6bc:      	ldp	q12, q11, [sp, #0x40]
     6c0:      	movi.4s	v10, #0x3f, lsl #24
     6c4:      	ldr	q9, [sp, #0x60]
     6c8:      	mvni.4s	v8, #0x80, lsl #24
     6cc:      	movi.4s	v31, #0x4b, lsl #24
     6d0:      	b	0x5fc <_llm_rows.packet_batch.blocks+0xb0>
     6d4:      	lsr	x19, x21, #3
     6d8:      	cmp	x21, #0x8
     6dc:      	b.lo	0x764 <_llm_rows.packet_batch.blocks+0x218>
     6e0:      	str	wzr, [x20, #0x24]
     6e4:      	ldr	x0, [sp, #0x80]
     6e8:      	mov	x1, x20
     6ec:      	bl	0x6ec <_llm_rows.packet_batch.blocks+0x1a0>
     6f0:      	ldp	q12, q11, [sp, #0x40]
     6f4:      	movi.4s	v10, #0x3f, lsl #24
     6f8:      	ldr	q9, [sp, #0x60]
     6fc:      	mvni.4s	v8, #0x80, lsl #24
     700:      	movi.4s	v31, #0x4b, lsl #24
     704:      	cmp	x19, #0x1
     708:      	b.eq	0x764 <_llm_rows.packet_batch.blocks+0x218>
     70c:      	mov	w8, #0x8                ; =8
     710:      	str	w8, [x20, #0x24]
     714:      	ldr	x0, [sp, #0x80]
     718:      	mov	x1, x20
     71c:      	bl	0x71c <_llm_rows.packet_batch.blocks+0x1d0>
     720:      	ldp	q12, q11, [sp, #0x40]
     724:      	movi.4s	v10, #0x3f, lsl #24
     728:      	ldr	q9, [sp, #0x60]
     72c:      	mvni.4s	v8, #0x80, lsl #24
     730:      	movi.4s	v31, #0x4b, lsl #24
     734:      	cmp	x19, #0x2
     738:      	b.eq	0x764 <_llm_rows.packet_batch.blocks+0x218>
     73c:      	mov	w8, #0x10               ; =16
     740:      	str	w8, [x20, #0x24]
     744:      	ldr	x0, [sp, #0x80]
     748:      	mov	x1, x20
     74c:      	bl	0x74c <_llm_rows.packet_batch.blocks+0x200>
     750:      	ldp	q12, q11, [sp, #0x40]
     754:      	movi.4s	v10, #0x3f, lsl #24
     758:      	ldr	q9, [sp, #0x60]
     75c:      	mvni.4s	v8, #0x80, lsl #24
     760:      	movi.4s	v31, #0x4b, lsl #24
     764:      	and	w8, w21, #0x7
     768:      	cbz	w8, 0x5f0 <_llm_rows.packet_batch.blocks+0xa4>
     76c:      	dup.4s	v2, w8
     770:      	ldp	q0, q1, [sp, #0x10]
     774:      	cmhi.4s	v0, v2, v0
     778:      	cmhi.4s	v1, v2, v1
     77c:      	uzp1.8h	v22, v1, v0
     780:      	umaxv.8h	h3, v22
     784:      	fmov	w8, s3
     788:      	tbz	w8, #0x0, 0x5f0 <_llm_rows.packet_batch.blocks+0xa4>
     78c:      	ldr	x8, [sp, #0x80]
     790:      	ldr	x12, [x8]
     794:      	ldr	x10, [x8, #0x10]
     798:      	ldr	x9, [x8, #0x30]
     79c:      	ubfiz	w8, w27, #2, #27
     7a0:      	orr	w11, w8, w19
     7a4:      	subs	x8, x12, x9
     7a8:      	mov	w15, #0xbff             ; =3071
     7ac:      	movk	w15, #0x6, lsl #16
     7b0:      	ccmp	x8, x15, #0x0, hs
     7b4:      	cset	w8, hi
     7b8:      	subs	x13, x9, x12
     7bc:      	ccmp	x13, x15, #0x0, hs
     7c0:      	csinc	w13, w8, wzr, ls
     7c4:      	subs	x8, x10, x9
     7c8:      	ccmp	x8, x15, #0x0, hs
     7cc:      	cset	w8, hi
     7d0:      	subs	x14, x9, x10
     7d4:      	ccmp	x14, x15, #0x0, hs
     7d8:      	csinc	w8, w8, wzr, ls
     7dc:      	fmov	w14, s2
     7e0:      	mov	w15, #0xc00             ; =3072
     7e4:      	umull	x11, w11, w15
     7e8:      	cmp	w14, #0x0
     7ec:      	csel	x11, x11, xzr, ne
     7f0:      	mov	w14, #-0x3d300000       ; =-1026555904
     7f4:      	dup.4s	v2, w14
     7f8:      	mov	w14, #0x42c80000        ; =1120403456
     7fc:      	dup.4s	v3, w14
     800:      	mov	w14, #0xaa3b            ; =43579
     804:      	movk	w14, #0x3fb8, lsl #16
     808:      	dup.4s	v4, w14
     80c:      	mov	w14, #0x7200            ; =29184
     810:      	movk	w14, #0xbf31, lsl #16
     814:      	dup.4s	v5, w14
     818:      	mov	w14, #0xbe8e            ; =48782
     81c:      	movk	w14, #0xb5bf, lsl #16
     820:      	dup.4s	v6, w14
     824:      	mov	w14, #0x2bda            ; =11226
     828:      	movk	w14, #0x3950, lsl #16
     82c:      	dup.4s	v7, w14
     830:      	mov	w14, #0x96c9            ; =38601
     834:      	movk	w14, #0x3ab6, lsl #16
     838:      	dup.4s	v16, w14
     83c:      	mov	w14, #0x88a6            ; =34982
     840:      	movk	w14, #0x3c08, lsl #16
     844:      	dup.4s	v17, w14
     848:      	mov	w14, #0xaa7a            ; =43642
     84c:      	movk	w14, #0x3d2a, lsl #16
     850:      	dup.4s	v18, w14
     854:      	mov	w14, #0xaaab            ; =43691
     858:      	movk	w14, #0x3e2a, lsl #16
     85c:      	dup.4s	v19, w14
     860:      	fmov.4s	v20, #1.00000000
     864:      	cmp	w13, #0x1
     868:      	b.ne	0xbdc <_llm_rows.packet_batch.blocks+0x690>
     86c:      	cbz	w8, 0xbdc <_llm_rows.packet_batch.blocks+0x690>
     870:      	mov	x8, #0x0                ; =0
     874:      	add	x9, x9, x11
     878:      	add	x10, x10, x11
     87c:      	add	x11, x12, x11
     880:      	and.16b	v21, v22, v9
     884:      	addv.8h	h21, v21
     888:      	fmov	w12, s21
     88c:      	b	0x89c <_llm_rows.packet_batch.blocks+0x350>
     890:      	add	x8, x8, #0x20
     894:      	cmp	x8, #0xc00
     898:      	b.eq	0x5f0 <_llm_rows.packet_batch.blocks+0xa4>
     89c:      	add	x13, x11, x8
     8a0:      	movi.2d	v23, #0000000000000000
     8a4:      	movi.2d	v22, #0000000000000000
     8a8:      	tbnz	w12, #0x0, 0xac0 <_llm_rows.packet_batch.blocks+0x574>
     8ac:      	and	w14, w12, #0xff
     8b0:      	tbnz	w14, #0x1, 0xacc <_llm_rows.packet_batch.blocks+0x580>
     8b4:      	tbnz	w14, #0x2, 0xad8 <_llm_rows.packet_batch.blocks+0x58c>
     8b8:      	tbnz	w14, #0x3, 0xae4 <_llm_rows.packet_batch.blocks+0x598>
     8bc:      	tbnz	w14, #0x4, 0xaf0 <_llm_rows.packet_batch.blocks+0x5a4>
     8c0:      	tbnz	w14, #0x5, 0xafc <_llm_rows.packet_batch.blocks+0x5b0>
     8c4:      	tbnz	w14, #0x6, 0xb08 <_llm_rows.packet_batch.blocks+0x5bc>
     8c8:      	tbnz	w14, #0x7, 0xb14 <_llm_rows.packet_batch.blocks+0x5c8>
     8cc:      	fmov	w14, s21
     8d0:      	add	x13, x10, x8
     8d4:      	movi.2d	v25, #0000000000000000
     8d8:      	movi.2d	v24, #0000000000000000
     8dc:      	tbnz	w14, #0x0, 0xb30 <_llm_rows.packet_batch.blocks+0x5e4>
     8e0:      	and	w14, w14, #0xff
     8e4:      	tbnz	w14, #0x1, 0xb3c <_llm_rows.packet_batch.blocks+0x5f0>
     8e8:      	tbnz	w14, #0x2, 0xb48 <_llm_rows.packet_batch.blocks+0x5fc>
     8ec:      	tbnz	w14, #0x3, 0xb54 <_llm_rows.packet_batch.blocks+0x608>
     8f0:      	tbnz	w14, #0x4, 0xb60 <_llm_rows.packet_batch.blocks+0x614>
     8f4:      	tbnz	w14, #0x5, 0xb6c <_llm_rows.packet_batch.blocks+0x620>
     8f8:      	tbnz	w14, #0x6, 0xb78 <_llm_rows.packet_batch.blocks+0x62c>
     8fc:      	tbz	w14, #0x7, 0x908 <_llm_rows.packet_batch.blocks+0x3bc>
     900:      	add	x13, x13, #0x1c
     904:      	ld1.s	{ v24 }[3], [x13]
     908:      	fneg.4s	v26, v23
     90c:      	and.16b	v26, v1, v26
     910:      	fcmge.4s	v27, v26, v2
     914:      	fcmge.4s	v28, v3, v26
     918:      	and.16b	v27, v27, v28
     91c:      	and.16b	v27, v27, v26
     920:      	fmul.4s	v28, v27, v4
     924:      	mov.16b	v29, v8
     928:      	bsl.16b	v29, v31, v28
     92c:      	fadd.4s	v28, v28, v29
     930:      	fsub.4s	v28, v28, v29
     934:      	fcvtzs.4s	v28, v28
     938:      	scvtf.4s	v29, v28
     93c:      	fmul.4s	v30, v29, v5
     940:      	fadd.4s	v27, v27, v30
     944:      	fmul.4s	v29, v29, v6
     948:      	fadd.4s	v27, v27, v29
     94c:      	fmul.4s	v29, v27, v7
     950:      	fadd.4s	v29, v29, v16
     954:      	fmul.4s	v29, v27, v29
     958:      	fadd.4s	v29, v29, v17
     95c:      	fmul.4s	v29, v27, v29
     960:      	fadd.4s	v29, v29, v18
     964:      	fmul.4s	v29, v27, v29
     968:      	fadd.4s	v29, v29, v19
     96c:      	fmul.4s	v29, v27, v29
     970:      	fadd.4s	v29, v29, v10
     974:      	fmul.4s	v30, v27, v27
     978:      	fmul.4s	v29, v30, v29
     97c:      	fadd.4s	v27, v27, v29
     980:      	fadd.4s	v27, v27, v20
     984:      	sshr.4s	v29, v28, #0x1
     988:      	shl.4s	v30, v29, #0x17
     98c:      	add.4s	v30, v30, v20
     990:      	fmul.4s	v27, v27, v30
     994:      	sub.4s	v28, v28, v29
     998:      	shl.4s	v28, v28, #0x17
     99c:      	add.4s	v28, v28, v20
     9a0:      	fmul.4s	v27, v27, v28
     9a4:      	fcmgt.4s	v28, v2, v26
     9a8:      	fcmgt.4s	v29, v26, v3
     9ac:      	fcmeq.4s	v26, v26, v26
     9b0:      	fadd.4s	v27, v27, v20
     9b4:      	bit.16b	v27, v20, v28
     9b8:      	bit.16b	v27, v11, v29
     9bc:      	bsl.16b	v26, v27, v12
     9c0:      	fdiv.4s	v23, v23, v26
     9c4:      	fmov	w14, s21
     9c8:      	fmul.4s	v23, v25, v23
     9cc:      	add	x13, x9, x8
     9d0:      	tbnz	w14, #0x0, 0xb88 <_llm_rows.packet_batch.blocks+0x63c>
     9d4:      	and	w14, w14, #0xff
     9d8:      	tbnz	w14, #0x1, 0xb94 <_llm_rows.packet_batch.blocks+0x648>
     9dc:      	tbnz	w14, #0x2, 0xba0 <_llm_rows.packet_batch.blocks+0x654>
     9e0:      	tbz	w14, #0x3, 0x9ec <_llm_rows.packet_batch.blocks+0x4a0>
     9e4:      	add	x15, x13, #0xc
     9e8:      	st1.s	{ v23 }[3], [x15]
     9ec:      	fneg.4s	v23, v22
     9f0:      	and.16b	v23, v0, v23
     9f4:      	fcmge.4s	v25, v23, v2
     9f8:      	fcmge.4s	v26, v3, v23
     9fc:      	and.16b	v25, v25, v26
     a00:      	and.16b	v25, v25, v23
     a04:      	fmul.4s	v26, v25, v4
     a08:      	mov.16b	v27, v8
     a0c:      	bsl.16b	v27, v31, v26
     a10:      	fadd.4s	v26, v26, v27
     a14:      	fsub.4s	v26, v26, v27
     a18:      	fcvtzs.4s	v26, v26
     a1c:      	scvtf.4s	v27, v26
     a20:      	fmul.4s	v28, v27, v5
     a24:      	fadd.4s	v25, v25, v28
     a28:      	fmul.4s	v27, v27, v6
     a2c:      	fadd.4s	v25, v25, v27
     a30:      	fmul.4s	v27, v25, v7
     a34:      	fadd.4s	v27, v27, v16
     a38:      	fmul.4s	v27, v25, v27
     a3c:      	fadd.4s	v27, v27, v17
     a40:      	fmul.4s	v27, v25, v27
     a44:      	fadd.4s	v27, v27, v18
     a48:      	fmul.4s	v27, v25, v27
     a4c:      	fadd.4s	v27, v27, v19
     a50:      	fmul.4s	v27, v25, v27
     a54:      	fadd.4s	v27, v27, v10
     a58:      	fmul.4s	v28, v25, v25
     a5c:      	fmul.4s	v27, v28, v27
     a60:      	fadd.4s	v25, v25, v27
     a64:      	fadd.4s	v25, v25, v20
     a68:      	sshr.4s	v27, v26, #0x1
     a6c:      	shl.4s	v28, v27, #0x17
     a70:      	add.4s	v28, v28, v20
     a74:      	fmul.4s	v25, v25, v28
     a78:      	sub.4s	v26, v26, v27
     a7c:      	shl.4s	v26, v26, #0x17
     a80:      	add.4s	v26, v26, v20
     a84:      	fmul.4s	v25, v25, v26
     a88:      	fcmgt.4s	v26, v2, v23
     a8c:      	fcmgt.4s	v27, v23, v3
     a90:      	fcmeq.4s	v23, v23, v23
     a94:      	fadd.4s	v25, v25, v20
     a98:      	bit.16b	v25, v20, v26
     a9c:      	bit.16b	v25, v11, v27
     aa0:      	bsl.16b	v23, v25, v12
     aa4:      	fdiv.4s	v22, v22, v23
     aa8:      	fmul.4s	v22, v24, v22
     aac:      	tbnz	w14, #0x4, 0xbb0 <_llm_rows.packet_batch.blocks+0x664>
     ab0:      	tbnz	w14, #0x5, 0xbb8 <_llm_rows.packet_batch.blocks+0x66c>
     ab4:      	tbnz	w14, #0x6, 0xbc4 <_llm_rows.packet_batch.blocks+0x678>
     ab8:      	tbz	w14, #0x7, 0x890 <_llm_rows.packet_batch.blocks+0x344>
     abc:      	b	0xbd0 <_llm_rows.packet_batch.blocks+0x684>
     ac0:      	ldr	s23, [x13]
     ac4:      	and	w14, w12, #0xff
     ac8:      	tbz	w14, #0x1, 0x8b4 <_llm_rows.packet_batch.blocks+0x368>
     acc:      	add	x15, x13, #0x4
     ad0:      	ld1.s	{ v23 }[1], [x15]
     ad4:      	tbz	w14, #0x2, 0x8b8 <_llm_rows.packet_batch.blocks+0x36c>
     ad8:      	add	x15, x13, #0x8
     adc:      	ld1.s	{ v23 }[2], [x15]
     ae0:      	tbz	w14, #0x3, 0x8bc <_llm_rows.packet_batch.blocks+0x370>
     ae4:      	add	x15, x13, #0xc
     ae8:      	ld1.s	{ v23 }[3], [x15]
     aec:      	tbz	w14, #0x4, 0x8c0 <_llm_rows.packet_batch.blocks+0x374>
     af0:      	add	x15, x13, #0x10
     af4:      	ld1.s	{ v22 }[0], [x15]
     af8:      	tbz	w14, #0x5, 0x8c4 <_llm_rows.packet_batch.blocks+0x378>
     afc:      	add	x15, x13, #0x14
     b00:      	ld1.s	{ v22 }[1], [x15]
     b04:      	tbz	w14, #0x6, 0x8c8 <_llm_rows.packet_batch.blocks+0x37c>
     b08:      	add	x15, x13, #0x18
     b0c:      	ld1.s	{ v22 }[2], [x15]
     b10:      	tbz	w14, #0x7, 0x8cc <_llm_rows.packet_batch.blocks+0x380>
     b14:      	add	x13, x13, #0x1c
     b18:      	ld1.s	{ v22 }[3], [x13]
     b1c:      	fmov	w14, s21
     b20:      	add	x13, x10, x8
     b24:      	movi.2d	v25, #0000000000000000
     b28:      	movi.2d	v24, #0000000000000000
     b2c:      	tbz	w14, #0x0, 0x8e0 <_llm_rows.packet_batch.blocks+0x394>
     b30:      	ldr	s25, [x13]
     b34:      	and	w14, w14, #0xff
     b38:      	tbz	w14, #0x1, 0x8e8 <_llm_rows.packet_batch.blocks+0x39c>
     b3c:      	add	x15, x13, #0x4
     b40:      	ld1.s	{ v25 }[1], [x15]
     b44:      	tbz	w14, #0x2, 0x8ec <_llm_rows.packet_batch.blocks+0x3a0>
     b48:      	add	x15, x13, #0x8
     b4c:      	ld1.s	{ v25 }[2], [x15]
     b50:      	tbz	w14, #0x3, 0x8f0 <_llm_rows.packet_batch.blocks+0x3a4>
     b54:      	add	x15, x13, #0xc
     b58:      	ld1.s	{ v25 }[3], [x15]
     b5c:      	tbz	w14, #0x4, 0x8f4 <_llm_rows.packet_batch.blocks+0x3a8>
     b60:      	add	x15, x13, #0x10
     b64:      	ld1.s	{ v24 }[0], [x15]
     b68:      	tbz	w14, #0x5, 0x8f8 <_llm_rows.packet_batch.blocks+0x3ac>
     b6c:      	add	x15, x13, #0x14
     b70:      	ld1.s	{ v24 }[1], [x15]
     b74:      	tbz	w14, #0x6, 0x8fc <_llm_rows.packet_batch.blocks+0x3b0>
     b78:      	add	x15, x13, #0x18
     b7c:      	ld1.s	{ v24 }[2], [x15]
     b80:      	tbnz	w14, #0x7, 0x900 <_llm_rows.packet_batch.blocks+0x3b4>
     b84:      	b	0x908 <_llm_rows.packet_batch.blocks+0x3bc>
     b88:      	str	s23, [x13]
     b8c:      	and	w14, w14, #0xff
     b90:      	tbz	w14, #0x1, 0x9dc <_llm_rows.packet_batch.blocks+0x490>
     b94:      	add	x15, x13, #0x4
     b98:      	st1.s	{ v23 }[1], [x15]
     b9c:      	tbz	w14, #0x2, 0x9e0 <_llm_rows.packet_batch.blocks+0x494>
     ba0:      	add	x15, x13, #0x8
     ba4:      	st1.s	{ v23 }[2], [x15]
     ba8:      	tbnz	w14, #0x3, 0x9e4 <_llm_rows.packet_batch.blocks+0x498>
     bac:      	b	0x9ec <_llm_rows.packet_batch.blocks+0x4a0>
     bb0:      	str	s22, [x13, #0x10]
     bb4:      	tbz	w14, #0x5, 0xab4 <_llm_rows.packet_batch.blocks+0x568>
     bb8:      	add	x15, x13, #0x14
     bbc:      	st1.s	{ v22 }[1], [x15]
     bc0:      	tbz	w14, #0x6, 0xab8 <_llm_rows.packet_batch.blocks+0x56c>
     bc4:      	add	x15, x13, #0x18
     bc8:      	st1.s	{ v22 }[2], [x15]
     bcc:      	tbz	w14, #0x7, 0x890 <_llm_rows.packet_batch.blocks+0x344>
     bd0:      	add	x13, x13, #0x1c
     bd4:      	st1.s	{ v22 }[3], [x13]
     bd8:      	b	0x890 <_llm_rows.packet_batch.blocks+0x344>
     bdc:      	mov	x8, #0x0                ; =0
     be0:      	add	x12, x12, x11
     be4:      	b	0xc08 <_llm_rows.packet_batch.blocks+0x6bc>
     be8:      	add	x13, x23, x8
     bec:      	ldp	q25, q26, [x13]
     bf0:      	bif.16b	v24, v26, v0
     bf4:      	bif.16b	v23, v25, v1
     bf8:      	stp	q23, q24, [x13]
     bfc:      	add	x8, x8, #0x20
     c00:      	cmp	x8, #0xc00
     c04:      	b.eq	0xca8 <_llm_rows.packet_batch.blocks+0x75c>
     c08:      	and.16b	v21, v22, v9
     c0c:      	addv.8h	h21, v21
     c10:      	fmov	w14, s21
     c14:      	add	x13, x12, x8
     c18:      	movi.2d	v23, #0000000000000000
     c1c:      	movi.2d	v24, #0000000000000000
     c20:      	tbnz	w14, #0x0, 0xc48 <_llm_rows.packet_batch.blocks+0x6fc>
     c24:      	and	w14, w14, #0xff
     c28:      	tbnz	w14, #0x1, 0xc54 <_llm_rows.packet_batch.blocks+0x708>
     c2c:      	tbnz	w14, #0x2, 0xc60 <_llm_rows.packet_batch.blocks+0x714>
     c30:      	tbnz	w14, #0x3, 0xc6c <_llm_rows.packet_batch.blocks+0x720>
     c34:      	tbnz	w14, #0x4, 0xc78 <_llm_rows.packet_batch.blocks+0x72c>
     c38:      	tbnz	w14, #0x5, 0xc84 <_llm_rows.packet_batch.blocks+0x738>
     c3c:      	tbnz	w14, #0x6, 0xc90 <_llm_rows.packet_batch.blocks+0x744>
     c40:      	tbz	w14, #0x7, 0xbe8 <_llm_rows.packet_batch.blocks+0x69c>
     c44:      	b	0xc9c <_llm_rows.packet_batch.blocks+0x750>
     c48:      	ldr	s23, [x13]
     c4c:      	and	w14, w14, #0xff
     c50:      	tbz	w14, #0x1, 0xc2c <_llm_rows.packet_batch.blocks+0x6e0>
     c54:      	add	x15, x13, #0x4
     c58:      	ld1.s	{ v23 }[1], [x15]
     c5c:      	tbz	w14, #0x2, 0xc30 <_llm_rows.packet_batch.blocks+0x6e4>
     c60:      	add	x15, x13, #0x8
     c64:      	ld1.s	{ v23 }[2], [x15]
     c68:      	tbz	w14, #0x3, 0xc34 <_llm_rows.packet_batch.blocks+0x6e8>
     c6c:      	add	x15, x13, #0xc
     c70:      	ld1.s	{ v23 }[3], [x15]
     c74:      	tbz	w14, #0x4, 0xc38 <_llm_rows.packet_batch.blocks+0x6ec>
     c78:      	add	x15, x13, #0x10
     c7c:      	ld1.s	{ v24 }[0], [x15]
     c80:      	tbz	w14, #0x5, 0xc3c <_llm_rows.packet_batch.blocks+0x6f0>
     c84:      	add	x15, x13, #0x14
     c88:      	ld1.s	{ v24 }[1], [x15]
     c8c:      	tbz	w14, #0x6, 0xc40 <_llm_rows.packet_batch.blocks+0x6f4>
     c90:      	add	x15, x13, #0x18
     c94:      	ld1.s	{ v24 }[2], [x15]
     c98:      	tbz	w14, #0x7, 0xbe8 <_llm_rows.packet_batch.blocks+0x69c>
     c9c:      	add	x13, x13, #0x1c
     ca0:      	ld1.s	{ v24 }[3], [x13]
     ca4:      	b	0xbe8 <_llm_rows.packet_batch.blocks+0x69c>
     ca8:      	mov	x8, #0x0                ; =0
     cac:      	add	x10, x10, x11
     cb0:      	b	0xcd4 <_llm_rows.packet_batch.blocks+0x788>
     cb4:      	add	x12, x24, x8
     cb8:      	ldp	q24, q25, [x12]
     cbc:      	bif.16b	v23, v25, v0
     cc0:      	bif.16b	v22, v24, v1
     cc4:      	stp	q22, q23, [x12]
     cc8:      	add	x8, x8, #0x20
     ccc:      	cmp	x8, #0xc00
     cd0:      	b.eq	0xd6c <_llm_rows.packet_batch.blocks+0x820>
     cd4:      	fmov	w13, s21
     cd8:      	add	x12, x10, x8
     cdc:      	movi.2d	v22, #0000000000000000
     ce0:      	movi.2d	v23, #0000000000000000
     ce4:      	tbnz	w13, #0x0, 0xd0c <_llm_rows.packet_batch.blocks+0x7c0>
     ce8:      	and	w13, w13, #0xff
     cec:      	tbnz	w13, #0x1, 0xd18 <_llm_rows.packet_batch.blocks+0x7cc>
     cf0:      	tbnz	w13, #0x2, 0xd24 <_llm_rows.packet_batch.blocks+0x7d8>
     cf4:      	tbnz	w13, #0x3, 0xd30 <_llm_rows.packet_batch.blocks+0x7e4>
     cf8:      	tbnz	w13, #0x4, 0xd3c <_llm_rows.packet_batch.blocks+0x7f0>
     cfc:      	tbnz	w13, #0x5, 0xd48 <_llm_rows.packet_batch.blocks+0x7fc>
     d00:      	tbnz	w13, #0x6, 0xd54 <_llm_rows.packet_batch.blocks+0x808>
     d04:      	tbz	w13, #0x7, 0xcb4 <_llm_rows.packet_batch.blocks+0x768>
     d08:      	b	0xd60 <_llm_rows.packet_batch.blocks+0x814>
     d0c:      	ldr	s22, [x12]
     d10:      	and	w13, w13, #0xff
     d14:      	tbz	w13, #0x1, 0xcf0 <_llm_rows.packet_batch.blocks+0x7a4>
     d18:      	add	x14, x12, #0x4
     d1c:      	ld1.s	{ v22 }[1], [x14]
     d20:      	tbz	w13, #0x2, 0xcf4 <_llm_rows.packet_batch.blocks+0x7a8>
     d24:      	add	x14, x12, #0x8
     d28:      	ld1.s	{ v22 }[2], [x14]
     d2c:      	tbz	w13, #0x3, 0xcf8 <_llm_rows.packet_batch.blocks+0x7ac>
     d30:      	add	x14, x12, #0xc
     d34:      	ld1.s	{ v22 }[3], [x14]
     d38:      	tbz	w13, #0x4, 0xcfc <_llm_rows.packet_batch.blocks+0x7b0>
     d3c:      	add	x14, x12, #0x10
     d40:      	ld1.s	{ v23 }[0], [x14]
     d44:      	tbz	w13, #0x5, 0xd00 <_llm_rows.packet_batch.blocks+0x7b4>
     d48:      	add	x14, x12, #0x14
     d4c:      	ld1.s	{ v23 }[1], [x14]
     d50:      	tbz	w13, #0x6, 0xd04 <_llm_rows.packet_batch.blocks+0x7b8>
     d54:      	add	x14, x12, #0x18
     d58:      	ld1.s	{ v23 }[2], [x14]
     d5c:      	tbz	w13, #0x7, 0xcb4 <_llm_rows.packet_batch.blocks+0x768>
     d60:      	add	x12, x12, #0x1c
     d64:      	ld1.s	{ v23 }[3], [x12]
     d68:      	b	0xcb4 <_llm_rows.packet_batch.blocks+0x768>
     d6c:      	mov	x8, #0x0                ; =0
     d70:      	add	x9, x9, x11
     d74:      	b	0xd84 <_llm_rows.packet_batch.blocks+0x838>
     d78:      	add	x8, x8, #0x20
     d7c:      	cmp	x8, #0xc00
     d80:      	b.eq	0x5f0 <_llm_rows.packet_batch.blocks+0xa4>
     d84:      	fmov	w11, s21
     d88:      	add	x10, x23, x8
     d8c:      	ldp	q23, q22, [x10]
     d90:      	and.16b	v23, v1, v23
     d94:      	fneg.4s	v24, v23
     d98:      	and.16b	v24, v1, v24
     d9c:      	fcmge.4s	v25, v24, v2
     da0:      	fcmge.4s	v26, v3, v24
     da4:      	and.16b	v25, v25, v26
     da8:      	and.16b	v25, v25, v24
     dac:      	fmul.4s	v26, v25, v4
     db0:      	mov.16b	v27, v8
     db4:      	bsl.16b	v27, v31, v26
     db8:      	fadd.4s	v26, v26, v27
     dbc:      	fsub.4s	v26, v26, v27
     dc0:      	fcvtzs.4s	v26, v26
     dc4:      	scvtf.4s	v27, v26
     dc8:      	fmul.4s	v28, v27, v5
     dcc:      	fadd.4s	v25, v25, v28
     dd0:      	fmul.4s	v27, v27, v6
     dd4:      	fadd.4s	v25, v25, v27
     dd8:      	fmul.4s	v27, v25, v7
     ddc:      	fadd.4s	v27, v27, v16
     de0:      	fmul.4s	v27, v25, v27
     de4:      	fadd.4s	v27, v27, v17
     de8:      	fmul.4s	v27, v25, v27
     dec:      	fadd.4s	v27, v27, v18
     df0:      	fmul.4s	v27, v25, v27
     df4:      	fadd.4s	v27, v27, v19
     df8:      	fmul.4s	v27, v25, v27
     dfc:      	fadd.4s	v27, v27, v10
     e00:      	fmul.4s	v28, v25, v25
     e04:      	fmul.4s	v27, v28, v27
     e08:      	fadd.4s	v25, v25, v27
     e0c:      	fadd.4s	v25, v25, v20
     e10:      	sshr.4s	v27, v26, #0x1
     e14:      	shl.4s	v28, v27, #0x17
     e18:      	add.4s	v28, v28, v20
     e1c:      	fmul.4s	v25, v25, v28
     e20:      	sub.4s	v26, v26, v27
     e24:      	shl.4s	v26, v26, #0x17
     e28:      	add.4s	v26, v26, v20
     e2c:      	fmul.4s	v25, v25, v26
     e30:      	fcmgt.4s	v26, v2, v24
     e34:      	fcmgt.4s	v27, v24, v3
     e38:      	fcmeq.4s	v24, v24, v24
     e3c:      	fadd.4s	v25, v25, v20
     e40:      	bit.16b	v25, v20, v26
     e44:      	bit.16b	v25, v11, v27
     e48:      	bsl.16b	v24, v25, v12
     e4c:      	fdiv.4s	v24, v23, v24
     e50:      	add	x10, x24, x8
     e54:      	ldp	q25, q23, [x10]
     e58:      	and.16b	v25, v1, v25
     e5c:      	fmul.4s	v24, v25, v24
     e60:      	add	x10, x9, x8
     e64:      	tbnz	w11, #0x0, 0xf5c <_llm_rows.packet_batch.blocks+0xa10>
     e68:      	and	w11, w11, #0xff
     e6c:      	tbnz	w11, #0x1, 0xf68 <_llm_rows.packet_batch.blocks+0xa1c>
     e70:      	tbnz	w11, #0x2, 0xf74 <_llm_rows.packet_batch.blocks+0xa28>
     e74:      	tbz	w11, #0x3, 0xe80 <_llm_rows.packet_batch.blocks+0x934>
     e78:      	add	x12, x10, #0xc
     e7c:      	st1.s	{ v24 }[3], [x12]
     e80:      	and.16b	v22, v0, v22
     e84:      	fneg.4s	v24, v22
     e88:      	and.16b	v24, v0, v24
     e8c:      	fcmge.4s	v25, v24, v2
     e90:      	fcmge.4s	v26, v3, v24
     e94:      	and.16b	v25, v25, v26
     e98:      	and.16b	v25, v25, v24
     e9c:      	fmul.4s	v26, v25, v4
     ea0:      	mov.16b	v27, v8
     ea4:      	bsl.16b	v27, v31, v26
     ea8:      	fadd.4s	v26, v26, v27
     eac:      	fsub.4s	v26, v26, v27
     eb0:      	fcvtzs.4s	v26, v26
     eb4:      	scvtf.4s	v27, v26
     eb8:      	fmul.4s	v28, v27, v5
     ebc:      	fadd.4s	v25, v25, v28
     ec0:      	fmul.4s	v27, v27, v6
     ec4:      	fadd.4s	v25, v25, v27
     ec8:      	fmul.4s	v27, v25, v7
     ecc:      	fadd.4s	v27, v27, v16
     ed0:      	fmul.4s	v27, v25, v27
     ed4:      	fadd.4s	v27, v27, v17
     ed8:      	fmul.4s	v27, v25, v27
     edc:      	fadd.4s	v27, v27, v18
     ee0:      	fmul.4s	v27, v25, v27
     ee4:      	fadd.4s	v27, v27, v19
     ee8:      	fmul.4s	v27, v25, v27
     eec:      	fadd.4s	v27, v27, v10
     ef0:      	fmul.4s	v28, v25, v25
     ef4:      	fmul.4s	v27, v28, v27
     ef8:      	fadd.4s	v25, v25, v27
     efc:      	fadd.4s	v25, v25, v20
     f00:      	sshr.4s	v27, v26, #0x1
     f04:      	shl.4s	v28, v27, #0x17
     f08:      	add.4s	v28, v28, v20
     f0c:      	fmul.4s	v25, v25, v28
     f10:      	sub.4s	v26, v26, v27
     f14:      	shl.4s	v26, v26, #0x17
     f18:      	add.4s	v26, v26, v20
     f1c:      	fmul.4s	v25, v25, v26
     f20:      	fcmgt.4s	v26, v2, v24
     f24:      	fcmgt.4s	v27, v24, v3
     f28:      	fcmeq.4s	v24, v24, v24
     f2c:      	fadd.4s	v25, v25, v20
     f30:      	bit.16b	v25, v20, v26
     f34:      	bit.16b	v25, v11, v27
     f38:      	bsl.16b	v24, v25, v12
     f3c:      	fdiv.4s	v22, v22, v24
     f40:      	and.16b	v23, v0, v23
     f44:      	fmul.4s	v22, v23, v22
     f48:      	tbnz	w11, #0x4, 0xf84 <_llm_rows.packet_batch.blocks+0xa38>
     f4c:      	tbnz	w11, #0x5, 0xf8c <_llm_rows.packet_batch.blocks+0xa40>
     f50:      	tbnz	w11, #0x6, 0xf98 <_llm_rows.packet_batch.blocks+0xa4c>
     f54:      	tbz	w11, #0x7, 0xd78 <_llm_rows.packet_batch.blocks+0x82c>
     f58:      	b	0xfa4 <_llm_rows.packet_batch.blocks+0xa58>
     f5c:      	str	s24, [x10]
     f60:      	and	w11, w11, #0xff
     f64:      	tbz	w11, #0x1, 0xe70 <_llm_rows.packet_batch.blocks+0x924>
     f68:      	add	x12, x10, #0x4
     f6c:      	st1.s	{ v24 }[1], [x12]
     f70:      	tbz	w11, #0x2, 0xe74 <_llm_rows.packet_batch.blocks+0x928>
     f74:      	add	x12, x10, #0x8
     f78:      	st1.s	{ v24 }[2], [x12]
     f7c:      	tbnz	w11, #0x3, 0xe78 <_llm_rows.packet_batch.blocks+0x92c>
     f80:      	b	0xe80 <_llm_rows.packet_batch.blocks+0x934>
     f84:      	str	s22, [x10, #0x10]
     f88:      	tbz	w11, #0x5, 0xf50 <_llm_rows.packet_batch.blocks+0xa04>
     f8c:      	add	x12, x10, #0x14
     f90:      	st1.s	{ v22 }[1], [x12]
     f94:      	tbz	w11, #0x6, 0xf54 <_llm_rows.packet_batch.blocks+0xa08>
     f98:      	add	x12, x10, #0x18
     f9c:      	st1.s	{ v22 }[2], [x12]
     fa0:      	tbz	w11, #0x7, 0xd78 <_llm_rows.packet_batch.blocks+0x82c>
     fa4:      	add	x10, x10, #0x1c
     fa8:      	st1.s	{ v22 }[3], [x10]
     fac:      	b	0xd78 <_llm_rows.packet_batch.blocks+0x82c>
     fb0:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
     fb4:      	add	sp, sp, #0x890
     fb8:      	ldp	x29, x30, [sp, #0x80]
     fbc:      	ldp	x20, x19, [sp, #0x70]
     fc0:      	ldp	x22, x21, [sp, #0x60]
     fc4:      	ldp	x24, x23, [sp, #0x50]
     fc8:      	ldp	x26, x25, [sp, #0x40]
     fcc:      	ldp	x28, x27, [sp, #0x30]
     fd0:      	ldp	d9, d8, [sp, #0x20]
     fd4:      	ldp	d11, d10, [sp, #0x10]
     fd8:      	ldp	d13, d12, [sp], #0x90
     fdc:      	ret

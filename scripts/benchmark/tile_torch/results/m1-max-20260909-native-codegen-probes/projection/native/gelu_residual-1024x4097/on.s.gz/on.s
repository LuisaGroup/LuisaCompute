
/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/gelu_residual-1024x4097/on/object/tile_xir_w8_38063_1788936546295434_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x90]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x24, x23, [sp, #0x50]
      18:      	stp	x22, x21, [sp, #0x60]
      1c:      	stp	x20, x19, [sp, #0x70]
      20:      	stp	x29, x30, [sp, #0x80]
      24:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      28:      	sub	sp, sp, #0x170
      2c:      	ldr	x23, [x0]
      30:      	ldr	x21, [x0, #0x10]
      34:      	ldr	x19, [x0, #0x30]
      38:      	ldr	w8, [x1]
      3c:      	ldr	w9, [x1, #0x24]
      40:      	add	w8, w9, w8, lsl #5
      44:      	lsr	w8, w8, #3
      48:      	subs	x9, x23, x19
      4c:      	mov	w10, #0xfff             ; =4095
      50:      	movk	w10, #0x100, lsl #16
      54:      	ccmp	x9, x10, #0x0, hs
      58:      	cset	w9, hi
      5c:      	subs	x11, x19, x23
      60:      	ccmp	x11, x10, #0x0, hs
      64:      	csinc	w9, w9, wzr, ls
      68:      	subs	x11, x21, x19
      6c:      	ccmp	x11, x10, #0x0, hs
      70:      	cset	w11, hi
      74:      	subs	x12, x19, x21
      78:      	ccmp	x12, x10, #0x0, hs
      7c:      	csinc	w10, w11, wzr, ls
      80:      	mov	w11, #0x4004            ; =16388
      84:      	umull	x22, w8, w11
      88:      	cmp	w9, #0x1
      8c:      	ccmp	w10, #0x0, #0x4, eq
      90:      	b.ne	0x7b4 <ltmp0+0x7b4>
      94:      	add	x24, sp, #0x4, lsl #12  ; =0x4000
      98:      	add	x24, x24, #0x150
      9c:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
      a0:      	add	x0, x0, #0x150
      a4:      	add	x1, x23, x22
      a8:      	mov	w2, #0x4000             ; =16384
      ac:      	bl	0xac <ltmp0+0xac>
      b0:      	add	x20, x22, #0x4, lsl #12 ; =0x4000
      b4:      	ldr	s0, [x23, x20]
      b8:      	str	q0, [sp]
      bc:      	str	q0, [sp, #0x8150]
      c0:      	add	x23, sp, #0x130
      c4:      	add	x0, sp, #0x130
      c8:      	add	x1, x21, x22
      cc:      	mov	w2, #0x4000             ; =16384
      d0:      	bl	0xd0 <ltmp0+0xd0>
      d4:      	mov	x8, #0x0                ; =0
      d8:      	ldr	s0, [x21, x20]
      dc:      	mov	w9, #0x2713             ; =10003
      e0:      	movk	w9, #0x3d37, lsl #16
      e4:      	dup.4s	v2, w9
      e8:      	mov	w9, #0x422a             ; =16938
      ec:      	movk	w9, #0x3f4c, lsl #16
      f0:      	dup.4s	v1, w9
      f4:      	stp	q1, q2, [sp, #0x100]
      f8:      	mov	w9, #0x9231             ; =37425
      fc:      	movk	w9, #0x2f30, lsl #16
     100:      	dup.4s	v2, w9
     104:      	mov	w9, #0x322b             ; =12843
     108:      	movk	w9, #0x32d7, lsl #16
     10c:      	dup.4s	v1, w9
     110:      	stp	q1, q2, [sp, #0xe0]
     114:      	mov	w9, #0xef1d             ; =61213
     118:      	movk	w9, #0x3638, lsl #16
     11c:      	dup.4s	v2, w9
     120:      	mov	w9, #0xd01              ; =3329
     124:      	movk	w9, #0x3950, lsl #16
     128:      	dup.4s	v1, w9
     12c:      	stp	q1, q2, [sp, #0xc0]
     130:      	mov	w9, #0x8889             ; =34953
     134:      	movk	w9, #0x3c08, lsl #16
     138:      	dup.4s	v2, w9
     13c:      	mov	w9, #0xaaab             ; =43691
     140:      	movk	w9, #0x3e2a, lsl #16
     144:      	dup.4s	v21, w9
     148:      	mov	w9, #0x76c7             ; =30407
     14c:      	movk	w9, #0x310f, lsl #16
     150:      	dup.4s	v1, w9
     154:      	stp	q1, q2, [sp, #0xa0]
     158:      	mov	w9, #0xf27e             ; =62078
     15c:      	movk	w9, #0x3493, lsl #16
     160:      	dup.4s	v2, w9
     164:      	mov	w9, #0xd01              ; =3329
     168:      	movk	w9, #0x37d0, lsl #16
     16c:      	dup.4s	v1, w9
     170:      	stp	q1, q2, [sp, #0x80]
     174:      	mov	w9, #0xb61              ; =2913
     178:      	movk	w9, #0x3ab6, lsl #16
     17c:      	dup.4s	v2, w9
     180:      	mov	w9, #0xaaab             ; =43691
     184:      	movk	w9, #0x3d2a, lsl #16
     188:      	dup.4s	v1, w9
     18c:      	stp	q1, q2, [sp, #0x60]
     190:      	mov	w9, #-0x3d300000        ; =-1026555904
     194:      	dup.4s	v2, w9
     198:      	mov	w9, #0x42c80000         ; =1120403456
     19c:      	dup.4s	v25, w9
     1a0:      	mov	w9, #0xaa3b             ; =43579
     1a4:      	movk	w9, #0x3fb8, lsl #16
     1a8:      	dup.4s	v1, w9
     1ac:      	stp	q1, q2, [sp, #0x40]
     1b0:      	mov	w9, #0x7200             ; =29184
     1b4:      	movk	w9, #0xbf31, lsl #16
     1b8:      	dup.4s	v2, w9
     1bc:      	mov	w9, #0xbe8e             ; =48782
     1c0:      	movk	w9, #0xb5bf, lsl #16
     1c4:      	dup.4s	v1, w9
     1c8:      	stp	q1, q2, [sp, #0x20]
     1cc:      	mov	w9, #0x2bda             ; =11226
     1d0:      	movk	w9, #0x3950, lsl #16
     1d4:      	dup.4s	v29, w9
     1d8:      	mov	w9, #0x96c9             ; =38601
     1dc:      	movk	w9, #0x3ab6, lsl #16
     1e0:      	dup.4s	v30, w9
     1e4:      	mov	w9, #0x88a6             ; =34982
     1e8:      	movk	w9, #0x3c08, lsl #16
     1ec:      	dup.4s	v31, w9
     1f0:      	mov	w9, #0xaa7a             ; =43642
     1f4:      	movk	w9, #0x3d2a, lsl #16
     1f8:      	dup.4s	v8, w9
     1fc:      	add	x9, x19, x22
     200:      	str	q0, [sp, #0x10]
     204:      	str	q0, [sp, #0x4130]
     208:      	movi.4s	v9, #0x3f, lsl #24
     20c:      	fmov.4s	v19, #1.00000000
     210:      	fmov.4s	v0, #9.00000000
     214:      	str	q0, [sp, #0x120]
     218:      	mvni.4s	v1, #0x7f, msl #16
     21c:      	fneg.4s	v13, v1
     220:      	mvni.4s	v1, #0x3f, msl #16
     224:      	fneg.4s	v15, v1
     228:      	add	x10, x24, x8
     22c:      	ldp	q10, q11, [x10]
     230:      	ldp	q0, q3, [sp, #0x100]
     234:      	fmul.4s	v1, v10, v3
     238:      	fmul.4s	v2, v11, v3
     23c:      	fmul.4s	v2, v11, v2
     240:      	fmul.4s	v1, v10, v1
     244:      	fmul.4s	v1, v10, v1
     248:      	fmul.4s	v2, v11, v2
     24c:      	fadd.4s	v2, v11, v2
     250:      	fadd.4s	v1, v10, v1
     254:      	fmul.4s	v14, v1, v0
     258:      	fmul.4s	v12, v2, v0
     25c:      	fabs.4s	v3, v12
     260:      	fabs.4s	v2, v14
     264:      	fmul.4s	v17, v14, v14
     268:      	ldp	q4, q0, [sp, #0xe0]
     26c:      	mov.16b	v1, v4
     270:      	fmul.4s	v20, v12, v12
     274:      	fmla.4s	v1, v17, v0
     278:      	fmla.4s	v4, v20, v0
     27c:      	ldp	q0, q6, [sp, #0xc0]
     280:      	mov.16b	v5, v6
     284:      	fmla.4s	v5, v17, v1
     288:      	fmla.4s	v6, v20, v4
     28c:      	mov.16b	v4, v0
     290:      	fmla.4s	v4, v17, v5
     294:      	mov.16b	v5, v0
     298:      	ldr	q0, [sp, #0xb0]
     29c:      	mov.16b	v7, v0
     2a0:      	fmla.4s	v5, v20, v6
     2a4:      	mov.16b	v6, v0
     2a8:      	mov.16b	v18, v21
     2ac:      	mov.16b	v16, v21
     2b0:      	mov.16b	v1, v19
     2b4:      	mov.16b	v26, v19
     2b8:      	fmla.4s	v7, v17, v4
     2bc:      	ldp	q22, q0, [sp, #0x90]
     2c0:      	mov.16b	v4, v22
     2c4:      	fmla.4s	v4, v20, v0
     2c8:      	fmla.4s	v22, v17, v0
     2cc:      	ldr	q0, [sp, #0x80]
     2d0:      	mov.16b	v23, v0
     2d4:      	fmla.4s	v6, v20, v5
     2d8:      	fmla.4s	v23, v20, v4
     2dc:      	mov.16b	v4, v0
     2e0:      	fmla.4s	v4, v17, v22
     2e4:      	ldp	q22, q0, [sp, #0x60]
     2e8:      	mov.16b	v5, v0
     2ec:      	fmla.4s	v5, v20, v23
     2f0:      	fmla.4s	v18, v17, v7
     2f4:      	mov.16b	v7, v0
     2f8:      	fmla.4s	v7, v17, v4
     2fc:      	mov.16b	v4, v22
     300:      	fmla.4s	v4, v20, v5
     304:      	fmla.4s	v16, v20, v6
     308:      	fmla.4s	v22, v17, v7
     30c:      	movi.4s	v23, #0x3f, lsl #24
     310:      	fmla.4s	v23, v20, v4
     314:      	movi.4s	v24, #0x3f, lsl #24
     318:      	mov.16b	v6, v19
     31c:      	fmla.4s	v26, v20, v16
     320:      	mov.16b	v0, v19
     324:      	ldr	q5, [sp, #0x120]
     328:      	fcmge.4s	v4, v5, v2
     32c:      	fcmge.4s	v5, v5, v3
     330:      	and.16b	v7, v5, v3
     334:      	and.16b	v16, v4, v2
     338:      	fmla.4s	v6, v20, v23
     33c:      	ldr	q23, [sp, #0x50]
     340:      	fcmge.4s	v20, v16, v23
     344:      	fcmge.4s	v23, v7, v23
     348:      	fcmge.4s	v27, v25, v7
     34c:      	and.16b	v23, v23, v27
     350:      	fcmge.4s	v27, v25, v16
     354:      	fmla.4s	v24, v17, v22
     358:      	and.16b	v20, v20, v27
     35c:      	and.16b	v20, v20, v16
     360:      	and.16b	v22, v23, v7
     364:      	ldr	q27, [sp, #0x40]
     368:      	fmul.4s	v23, v22, v27
     36c:      	fmul.4s	v27, v20, v27
     370:      	fmla.4s	v1, v17, v18
     374:      	movi.4s	v28, #0x4b, lsl #24
     378:      	fadd.4s	v18, v27, v28
     37c:      	fadd.4s	v23, v23, v28
     380:      	movi.4s	v27, #0xcb, lsl #24
     384:      	fadd.4s	v23, v23, v27
     388:      	fadd.4s	v18, v18, v27
     38c:      	fcvtzs.4s	v18, v18
     390:      	fmla.4s	v0, v17, v24
     394:      	fcvtzs.4s	v23, v23
     398:      	scvtf.4s	v17, v23
     39c:      	scvtf.4s	v24, v18
     3a0:      	ldr	q28, [sp, #0x30]
     3a4:      	fmul.4s	v27, v17, v28
     3a8:      	fadd.4s	v22, v22, v27
     3ac:      	fmul.4s	v27, v24, v28
     3b0:      	fadd.4s	v20, v20, v27
     3b4:      	ldr	q27, [sp, #0x20]
     3b8:      	fmul.4s	v17, v17, v27
     3bc:      	fmul.4s	v24, v24, v27
     3c0:      	fadd.4s	v20, v20, v24
     3c4:      	fadd.4s	v22, v22, v17
     3c8:      	fmul.4s	v17, v22, v29
     3cc:      	fmul.4s	v24, v20, v29
     3d0:      	fadd.4s	v24, v24, v30
     3d4:      	fadd.4s	v17, v17, v30
     3d8:      	fmul.4s	v17, v22, v17
     3dc:      	fmul.4s	v24, v20, v24
     3e0:      	fmul.4s	v1, v2, v1
     3e4:      	fadd.4s	v24, v24, v31
     3e8:      	fadd.4s	v17, v17, v31
     3ec:      	fmul.4s	v27, v22, v17
     3f0:      	fmul.4s	v17, v20, v24
     3f4:      	fadd.4s	v24, v17, v8
     3f8:      	fdiv.4s	v17, v1, v0
     3fc:      	fadd.4s	v0, v27, v8
     400:      	fmul.4s	v0, v22, v0
     404:      	fmul.4s	v1, v20, v24
     408:      	fadd.4s	v1, v1, v21
     40c:      	fadd.4s	v0, v0, v21
     410:      	fmul.4s	v0, v22, v0
     414:      	fmul.4s	v1, v20, v1
     418:      	fadd.4s	v1, v1, v9
     41c:      	fadd.4s	v0, v0, v9
     420:      	fmul.4s	v24, v22, v22
     424:      	fmul.4s	v0, v24, v0
     428:      	fmul.4s	v24, v20, v20
     42c:      	fmul.4s	v1, v24, v1
     430:      	fadd.4s	v1, v20, v1
     434:      	fadd.4s	v0, v22, v0
     438:      	fadd.4s	v0, v0, v19
     43c:      	movi.2d	v20, #0xffffffffffffffff
     440:      	add.4s	v18, v18, v20
     444:      	fadd.4s	v1, v1, v19
     448:      	add.4s	v20, v23, v20
     44c:      	sshr.4s	v22, v20, #0x1
     450:      	sshr.4s	v23, v18, #0x1
     454:      	shl.4s	v24, v23, #0x17
     458:      	add.4s	v24, v24, v19
     45c:      	fmul.4s	v1, v1, v24
     460:      	shl.4s	v24, v22, #0x17
     464:      	add.4s	v24, v24, v19
     468:      	fmul.4s	v0, v0, v24
     46c:      	sub.4s	v18, v18, v23
     470:      	sub.4s	v20, v20, v22
     474:      	shl.4s	v20, v20, #0x17
     478:      	add.4s	v20, v20, v19
     47c:      	fmul.4s	v0, v0, v20
     480:      	shl.4s	v18, v18, #0x17
     484:      	add.4s	v18, v18, v19
     488:      	fmul.4s	v1, v1, v18
     48c:      	fmul.4s	v18, v3, v26
     490:      	fcmgt.4s	v7, v7, v25
     494:      	fcmgt.4s	v16, v16, v25
     498:      	bsl.16b	v16, v13, v1
     49c:      	bit.16b	v0, v13, v7
     4a0:      	fmov.4s	v1, #0.25000000
     4a4:      	fdiv.4s	v6, v18, v6
     4a8:      	fdiv.4s	v7, v1, v0
     4ac:      	fsub.4s	v18, v0, v7
     4b0:      	fadd.4s	v0, v0, v7
     4b4:      	fdiv.4s	v0, v18, v0
     4b8:      	bif.16b	v0, v19, v5
     4bc:      	fcmge.4s	v3, v19, v3
     4c0:      	bit.16b	v0, v6, v3
     4c4:      	fdiv.4s	v3, v1, v16
     4c8:      	fsub.4s	v5, v16, v3
     4cc:      	fadd.4s	v3, v16, v3
     4d0:      	fdiv.4s	v3, v5, v3
     4d4:      	bif.16b	v3, v19, v4
     4d8:      	fcmge.4s	v2, v19, v2
     4dc:      	bsl.16b	v2, v17, v3
     4e0:      	mvni.4s	v4, #0x80, lsl #24
     4e4:      	bif.16b	v2, v14, v4
     4e8:      	fcmeq.4s	v3, v14, v14
     4ec:      	fadd.4s	v2, v2, v19
     4f0:      	bif.16b	v2, v15, v3
     4f4:      	bif.16b	v0, v12, v4
     4f8:      	fcmeq.4s	v3, v12, v12
     4fc:      	fadd.4s	v0, v0, v19
     500:      	bif.16b	v0, v15, v3
     504:      	fmul.4s	v3, v11, v9
     508:      	fmul.4s	v0, v3, v0
     50c:      	fmul.4s	v3, v10, v9
     510:      	fmul.4s	v2, v3, v2
     514:      	add	x10, x23, x8
     518:      	ldp	q4, q3, [x10]
     51c:      	fadd.4s	v2, v4, v2
     520:      	fadd.4s	v0, v3, v0
     524:      	add	x10, x9, x8
     528:      	stp	q2, q0, [x10]
     52c:      	add	x8, x8, #0x20
     530:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     534:      	b.ne	0x228 <ltmp0+0x228>
     538:      	movi.2d	v3, #0000000000000000
     53c:      	ldr	q4, [sp]
     540:      	mov.s	v3[0], v4[0]
     544:      	movi.2d	v2, #0000000000000000
     548:      	mov	w8, #0x2713             ; =10003
     54c:      	movk	w8, #0x3d37, lsl #16
     550:      	fmov	s0, w8
     554:      	fmul.4s	v0, v3, v0
     558:      	fmul.4s	v0, v4, v0
     55c:      	fmul.4s	v0, v4, v0
     560:      	fadd.4s	v0, v4, v0
     564:      	mov	w8, #0x422a             ; =16938
     568:      	movk	w8, #0x3f4c, lsl #16
     56c:      	fmov	s4, w8
     570:      	fmul.4s	v0, v0, v4
     574:      	mov.s	v2[0], v0[0]
     578:      	fabs.4s	v4, v2
     57c:      	fmul.4s	v5, v2, v2
     580:      	mov	w8, #0x9231             ; =37425
     584:      	movk	w8, #0x2f30, lsl #16
     588:      	dup.4s	v0, w8
     58c:      	mov	w8, #0x322b             ; =12843
     590:      	movk	w8, #0x32d7, lsl #16
     594:      	dup.4s	v6, w8
     598:      	mov	w8, #0xef1d             ; =61213
     59c:      	movk	w8, #0x3638, lsl #16
     5a0:      	dup.4s	v7, w8
     5a4:      	fmla.4s	v6, v5, v0
     5a8:      	fmla.4s	v7, v5, v6
     5ac:      	mov	w8, #0xd01              ; =3329
     5b0:      	movk	w8, #0x3950, lsl #16
     5b4:      	dup.4s	v0, w8
     5b8:      	fmla.4s	v0, v5, v7
     5bc:      	mov	w8, #0x8889             ; =34953
     5c0:      	movk	w8, #0x3c08, lsl #16
     5c4:      	dup.4s	v17, w8
     5c8:      	mov	w8, #0xaaab             ; =43691
     5cc:      	movk	w8, #0x3e2a, lsl #16
     5d0:      	dup.4s	v18, w8
     5d4:      	fmla.4s	v17, v5, v0
     5d8:      	ldr	q0, [sp, #0x120]
     5dc:      	fcmge.4s	v6, v0, v4
     5e0:      	and.16b	v7, v6, v4
     5e4:      	mov	w8, #-0x3d300000        ; =-1026555904
     5e8:      	dup.4s	v0, w8
     5ec:      	fcmge.4s	v0, v7, v0
     5f0:      	mov	w8, #0x42c80000         ; =1120403456
     5f4:      	dup.4s	v16, w8
     5f8:      	fcmge.4s	v20, v16, v7
     5fc:      	and.16b	v0, v0, v20
     600:      	and.16b	v0, v0, v7
     604:      	mov	w8, #0xaa3b             ; =43579
     608:      	movk	w8, #0x3fb8, lsl #16
     60c:      	dup.4s	v20, w8
     610:      	fmul.4s	v20, v0, v20
     614:      	movi.4s	v21, #0x4b, lsl #24
     618:      	fadd.4s	v20, v20, v21
     61c:      	movi.4s	v21, #0xcb, lsl #24
     620:      	fadd.4s	v20, v20, v21
     624:      	fcvtzs.4s	v20, v20
     628:      	scvtf.4s	v21, v20
     62c:      	mov	w8, #0x7200             ; =29184
     630:      	movk	w8, #0xbf31, lsl #16
     634:      	dup.4s	v22, w8
     638:      	fmul.4s	v22, v21, v22
     63c:      	mov	w8, #0xbe8e             ; =48782
     640:      	movk	w8, #0xb5bf, lsl #16
     644:      	dup.4s	v23, w8
     648:      	fadd.4s	v0, v0, v22
     64c:      	fmul.4s	v21, v21, v23
     650:      	fadd.4s	v0, v0, v21
     654:      	mov	w8, #0x2bda             ; =11226
     658:      	movk	w8, #0x3950, lsl #16
     65c:      	dup.4s	v21, w8
     660:      	fmul.4s	v21, v0, v21
     664:      	mov	w8, #0x96c9             ; =38601
     668:      	movk	w8, #0x3ab6, lsl #16
     66c:      	dup.4s	v22, w8
     670:      	fadd.4s	v21, v21, v22
     674:      	fmul.4s	v21, v0, v21
     678:      	mov	w8, #0x88a6             ; =34982
     67c:      	movk	w8, #0x3c08, lsl #16
     680:      	dup.4s	v22, w8
     684:      	fadd.4s	v21, v21, v22
     688:      	fmul.4s	v21, v0, v21
     68c:      	mov	w8, #0xaa7a             ; =43642
     690:      	movk	w8, #0x3d2a, lsl #16
     694:      	dup.4s	v22, w8
     698:      	fadd.4s	v21, v21, v22
     69c:      	fmul.4s	v21, v0, v21
     6a0:      	fadd.4s	v21, v21, v18
     6a4:      	fmla.4s	v18, v5, v17
     6a8:      	mov.16b	v17, v19
     6ac:      	fmla.4s	v17, v5, v18
     6b0:      	mov	w8, #0x76c7             ; =30407
     6b4:      	movk	w8, #0x310f, lsl #16
     6b8:      	dup.4s	v18, w8
     6bc:      	mov	w8, #0xf27e             ; =62078
     6c0:      	movk	w8, #0x3493, lsl #16
     6c4:      	dup.4s	v22, w8
     6c8:      	mov	w8, #0xd01              ; =3329
     6cc:      	movk	w8, #0x37d0, lsl #16
     6d0:      	dup.4s	v23, w8
     6d4:      	fmla.4s	v22, v5, v18
     6d8:      	fmla.4s	v23, v5, v22
     6dc:      	mov	w8, #0xb61              ; =2913
     6e0:      	movk	w8, #0x3ab6, lsl #16
     6e4:      	dup.4s	v18, w8
     6e8:      	fmla.4s	v18, v5, v23
     6ec:      	mov	w8, #0xaaab             ; =43691
     6f0:      	movk	w8, #0x3d2a, lsl #16
     6f4:      	dup.4s	v22, w8
     6f8:      	fmla.4s	v22, v5, v18
     6fc:      	movi.4s	v18, #0x3f, lsl #24
     700:      	fmla.4s	v18, v5, v22
     704:      	mov.16b	v22, v19
     708:      	fmla.4s	v22, v5, v18
     70c:      	movi.4s	v5, #0x3f, lsl #24
     710:      	fmul.4s	v3, v3, v5
     714:      	fcmge.4s	v18, v19, v4
     718:      	fmul.4s	v4, v4, v17
     71c:      	fdiv.4s	v4, v4, v22
     720:      	fmul.4s	v17, v0, v21
     724:      	fadd.4s	v5, v17, v5
     728:      	fmul.4s	v17, v0, v0
     72c:      	fmul.4s	v5, v17, v5
     730:      	fadd.4s	v0, v0, v5
     734:      	fadd.4s	v0, v0, v19
     738:      	movi.2d	v5, #0xffffffffffffffff
     73c:      	add.4s	v5, v20, v5
     740:      	sshr.4s	v17, v5, #0x1
     744:      	shl.4s	v20, v17, #0x17
     748:      	add.4s	v20, v20, v19
     74c:      	fmul.4s	v0, v0, v20
     750:      	sub.4s	v5, v5, v17
     754:      	shl.4s	v5, v5, #0x17
     758:      	add.4s	v5, v5, v19
     75c:      	fmul.4s	v0, v0, v5
     760:      	fcmgt.4s	v5, v7, v16
     764:      	mvni.4s	v7, #0x7f, msl #16
     768:      	fneg.4s	v7, v7
     76c:      	bit.16b	v0, v7, v5
     770:      	fdiv.4s	v1, v1, v0
     774:      	fsub.4s	v5, v0, v1
     778:      	fadd.4s	v0, v0, v1
     77c:      	fdiv.4s	v0, v5, v0
     780:      	bif.16b	v0, v19, v6
     784:      	bit.16b	v0, v4, v18
     788:      	mvni.4s	v1, #0x80, lsl #24
     78c:      	bif.16b	v0, v2, v1
     790:      	fcmeq.4s	v1, v2, v2
     794:      	fadd.4s	v0, v0, v19
     798:      	mvni.4s	v2, #0x3f, msl #16
     79c:      	fneg.4s	v2, v2
     7a0:      	bif.16b	v0, v2, v1
     7a4:      	fmul.4s	v0, v3, v0
     7a8:      	ldr	q1, [sp, #0x10]
     7ac:      	fadd.4s	v0, v0, v1
     7b0:      	b	0xe98 <ltmp0+0xe98>
     7b4:      	mov	x8, #0x0                ; =0
     7b8:      	mov	w9, #0x2713             ; =10003
     7bc:      	movk	w9, #0x3d37, lsl #16
     7c0:      	dup.4s	v1, w9
     7c4:      	mov	w9, #0x422a             ; =16938
     7c8:      	movk	w9, #0x3f4c, lsl #16
     7cc:      	dup.4s	v0, w9
     7d0:      	stp	q0, q1, [sp, #0xf0]
     7d4:      	mov	w9, #0x9231             ; =37425
     7d8:      	movk	w9, #0x2f30, lsl #16
     7dc:      	dup.4s	v1, w9
     7e0:      	mov	w9, #0x322b             ; =12843
     7e4:      	movk	w9, #0x32d7, lsl #16
     7e8:      	dup.4s	v0, w9
     7ec:      	stp	q0, q1, [sp, #0xd0]
     7f0:      	mov	w9, #0xef1d             ; =61213
     7f4:      	movk	w9, #0x3638, lsl #16
     7f8:      	dup.4s	v1, w9
     7fc:      	mov	w9, #0xd01              ; =3329
     800:      	movk	w9, #0x3950, lsl #16
     804:      	dup.4s	v0, w9
     808:      	stp	q0, q1, [sp, #0xb0]
     80c:      	mov	w9, #0x8889             ; =34953
     810:      	movk	w9, #0x3c08, lsl #16
     814:      	dup.4s	v1, w9
     818:      	mov	w9, #0xaaab             ; =43691
     81c:      	movk	w9, #0x3e2a, lsl #16
     820:      	dup.4s	v21, w9
     824:      	mov	w9, #0x76c7             ; =30407
     828:      	movk	w9, #0x310f, lsl #16
     82c:      	dup.4s	v0, w9
     830:      	stp	q0, q1, [sp, #0x90]
     834:      	mov	w9, #0xf27e             ; =62078
     838:      	movk	w9, #0x3493, lsl #16
     83c:      	dup.4s	v1, w9
     840:      	mov	w9, #0xd01              ; =3329
     844:      	movk	w9, #0x37d0, lsl #16
     848:      	dup.4s	v0, w9
     84c:      	stp	q0, q1, [sp, #0x70]
     850:      	mov	w9, #0xb61              ; =2913
     854:      	movk	w9, #0x3ab6, lsl #16
     858:      	dup.4s	v1, w9
     85c:      	mov	w9, #0xaaab             ; =43691
     860:      	movk	w9, #0x3d2a, lsl #16
     864:      	dup.4s	v0, w9
     868:      	stp	q0, q1, [sp, #0x50]
     86c:      	mov	w9, #-0x3d300000        ; =-1026555904
     870:      	dup.4s	v1, w9
     874:      	mov	w9, #0x42c80000         ; =1120403456
     878:      	dup.4s	v25, w9
     87c:      	mov	w9, #0xaa3b             ; =43579
     880:      	movk	w9, #0x3fb8, lsl #16
     884:      	dup.4s	v0, w9
     888:      	stp	q0, q1, [sp, #0x30]
     88c:      	mov	w9, #0x7200             ; =29184
     890:      	movk	w9, #0xbf31, lsl #16
     894:      	dup.4s	v1, w9
     898:      	mov	w9, #0xbe8e             ; =48782
     89c:      	movk	w9, #0xb5bf, lsl #16
     8a0:      	dup.4s	v0, w9
     8a4:      	stp	q0, q1, [sp, #0x10]
     8a8:      	mov	w9, #0x2bda             ; =11226
     8ac:      	movk	w9, #0x3950, lsl #16
     8b0:      	dup.4s	v0, w9
     8b4:      	str	q0, [sp]
     8b8:      	mov	w9, #0x96c9             ; =38601
     8bc:      	movk	w9, #0x3ab6, lsl #16
     8c0:      	dup.4s	v30, w9
     8c4:      	mov	w9, #0x88a6             ; =34982
     8c8:      	movk	w9, #0x3c08, lsl #16
     8cc:      	dup.4s	v31, w9
     8d0:      	mov	w9, #0xaa7a             ; =43642
     8d4:      	movk	w9, #0x3d2a, lsl #16
     8d8:      	dup.4s	v8, w9
     8dc:      	add	x9, x19, x22
     8e0:      	add	x10, x21, x22
     8e4:      	add	x11, x23, x22
     8e8:      	movi.4s	v9, #0x3f, lsl #24
     8ec:      	fmov.4s	v0, #1.00000000
     8f0:      	fmov.4s	v2, #9.00000000
     8f4:      	mvni.4s	v1, #0x7f, msl #16
     8f8:      	fneg.4s	v13, v1
     8fc:      	fmov.4s	v1, #0.25000000
     900:      	stp	q2, q1, [sp, #0x110]
     904:      	mvni.4s	v1, #0x3f, msl #16
     908:      	fneg.4s	v15, v1
     90c:      	add	x12, x11, x8
     910:      	ldp	q10, q11, [x12]
     914:      	ldp	q3, q2, [sp, #0xf0]
     918:      	fmul.4s	v1, v10, v2
     91c:      	fmul.4s	v2, v11, v2
     920:      	fmul.4s	v2, v11, v2
     924:      	fmul.4s	v1, v10, v1
     928:      	fmul.4s	v1, v10, v1
     92c:      	fmul.4s	v2, v11, v2
     930:      	fadd.4s	v2, v11, v2
     934:      	fadd.4s	v1, v10, v1
     938:      	fmul.4s	v14, v1, v3
     93c:      	fmul.4s	v12, v2, v3
     940:      	fabs.4s	v2, v12
     944:      	fabs.4s	v1, v14
     948:      	fmul.4s	v16, v14, v14
     94c:      	fmul.4s	v19, v12, v12
     950:      	ldp	q4, q5, [sp, #0xd0]
     954:      	mov.16b	v3, v4
     958:      	fmla.4s	v3, v16, v5
     95c:      	fmla.4s	v4, v19, v5
     960:      	ldr	q6, [sp, #0xc0]
     964:      	mov.16b	v5, v6
     968:      	fmla.4s	v5, v16, v3
     96c:      	mov.16b	v3, v6
     970:      	fmla.4s	v3, v19, v4
     974:      	ldp	q7, q6, [sp, #0xa0]
     978:      	mov.16b	v4, v6
     97c:      	fmla.4s	v4, v16, v5
     980:      	mov.16b	v5, v6
     984:      	fmla.4s	v5, v19, v3
     988:      	mov.16b	v6, v7
     98c:      	mov.16b	v18, v21
     990:      	mov.16b	v20, v21
     994:      	mov.16b	v3, v0
     998:      	fmla.4s	v6, v16, v4
     99c:      	ldp	q17, q22, [sp, #0x80]
     9a0:      	mov.16b	v4, v17
     9a4:      	fmla.4s	v4, v19, v22
     9a8:      	fmla.4s	v17, v16, v22
     9ac:      	ldr	q23, [sp, #0x70]
     9b0:      	mov.16b	v22, v23
     9b4:      	fmla.4s	v7, v19, v5
     9b8:      	fmla.4s	v22, v19, v4
     9bc:      	mov.16b	v4, v23
     9c0:      	fmla.4s	v4, v16, v17
     9c4:      	ldr	q17, [sp, #0x60]
     9c8:      	mov.16b	v5, v17
     9cc:      	fmla.4s	v5, v19, v22
     9d0:      	fmla.4s	v18, v16, v6
     9d4:      	mov.16b	v6, v17
     9d8:      	fmla.4s	v6, v16, v4
     9dc:      	ldp	q27, q22, [sp, #0x40]
     9e0:      	mov.16b	v17, v22
     9e4:      	fmla.4s	v17, v19, v5
     9e8:      	fmla.4s	v20, v19, v7
     9ec:      	fmla.4s	v22, v16, v6
     9f0:      	movi.4s	v23, #0x3f, lsl #24
     9f4:      	movi.4s	v24, #0x3f, lsl #24
     9f8:      	mov.16b	v6, v0
     9fc:      	ldr	q5, [sp, #0x110]
     a00:      	fcmge.4s	v4, v5, v1
     a04:      	fmla.4s	v23, v19, v17
     a08:      	fcmge.4s	v5, v5, v2
     a0c:      	and.16b	v7, v5, v2
     a10:      	and.16b	v17, v4, v1
     a14:      	fcmge.4s	v26, v17, v27
     a18:      	fcmge.4s	v27, v7, v27
     a1c:      	fcmge.4s	v28, v25, v7
     a20:      	and.16b	v27, v27, v28
     a24:      	fcmge.4s	v28, v25, v17
     a28:      	and.16b	v26, v26, v28
     a2c:      	and.16b	v26, v26, v17
     a30:      	and.16b	v27, v27, v7
     a34:      	fmla.4s	v3, v19, v20
     a38:      	ldr	q28, [sp, #0x30]
     a3c:      	fmul.4s	v20, v27, v28
     a40:      	fmul.4s	v28, v26, v28
     a44:      	movi.4s	v29, #0x4b, lsl #24
     a48:      	fadd.4s	v28, v28, v29
     a4c:      	fadd.4s	v20, v20, v29
     a50:      	movi.4s	v29, #0xcb, lsl #24
     a54:      	fadd.4s	v20, v20, v29
     a58:      	fmla.4s	v6, v19, v23
     a5c:      	fadd.4s	v19, v28, v29
     a60:      	fcvtzs.4s	v19, v19
     a64:      	fcvtzs.4s	v20, v20
     a68:      	scvtf.4s	v23, v20
     a6c:      	scvtf.4s	v28, v19
     a70:      	fmla.4s	v24, v16, v22
     a74:      	ldr	q29, [sp, #0x20]
     a78:      	fmul.4s	v22, v23, v29
     a7c:      	fadd.4s	v22, v27, v22
     a80:      	fmul.4s	v27, v28, v29
     a84:      	fadd.4s	v26, v26, v27
     a88:      	mov.16b	v27, v0
     a8c:      	fmla.4s	v27, v16, v18
     a90:      	ldr	q29, [sp, #0x10]
     a94:      	fmul.4s	v18, v28, v29
     a98:      	fadd.4s	v18, v26, v18
     a9c:      	fmul.4s	v23, v23, v29
     aa0:      	fadd.4s	v22, v22, v23
     aa4:      	mov.16b	v23, v0
     aa8:      	fmla.4s	v23, v16, v24
     aac:      	ldr	q24, [sp]
     ab0:      	fmul.4s	v16, v22, v24
     ab4:      	fmul.4s	v24, v18, v24
     ab8:      	fadd.4s	v24, v24, v30
     abc:      	fadd.4s	v16, v16, v30
     ac0:      	fmul.4s	v16, v22, v16
     ac4:      	fmul.4s	v26, v1, v27
     ac8:      	fmul.4s	v24, v18, v24
     acc:      	fadd.4s	v24, v24, v31
     ad0:      	fadd.4s	v16, v16, v31
     ad4:      	fmul.4s	v16, v22, v16
     ad8:      	fmul.4s	v24, v18, v24
     adc:      	fadd.4s	v24, v24, v8
     ae0:      	fadd.4s	v16, v16, v8
     ae4:      	fmul.4s	v16, v22, v16
     ae8:      	fmul.4s	v24, v18, v24
     aec:      	fadd.4s	v24, v24, v21
     af0:      	fadd.4s	v27, v16, v21
     af4:      	fdiv.4s	v16, v26, v23
     af8:      	fmul.4s	v23, v22, v27
     afc:      	fmul.4s	v24, v18, v24
     b00:      	fadd.4s	v24, v24, v9
     b04:      	fadd.4s	v23, v23, v9
     b08:      	fmul.4s	v26, v22, v22
     b0c:      	fmul.4s	v23, v26, v23
     b10:      	fmul.4s	v26, v18, v18
     b14:      	fmul.4s	v24, v26, v24
     b18:      	fadd.4s	v18, v18, v24
     b1c:      	fadd.4s	v22, v22, v23
     b20:      	movi.2d	v26, #0xffffffffffffffff
     b24:      	add.4s	v19, v19, v26
     b28:      	fadd.4s	v18, v18, v0
     b2c:      	sshr.4s	v23, v19, #0x1
     b30:      	shl.4s	v24, v23, #0x17
     b34:      	add.4s	v24, v24, v0
     b38:      	fmul.4s	v18, v18, v24
     b3c:      	add.4s	v20, v20, v26
     b40:      	fadd.4s	v22, v22, v0
     b44:      	sub.4s	v19, v19, v23
     b48:      	sshr.4s	v23, v20, #0x1
     b4c:      	sub.4s	v20, v20, v23
     b50:      	shl.4s	v23, v23, #0x17
     b54:      	add.4s	v23, v23, v0
     b58:      	fmul.4s	v22, v22, v23
     b5c:      	shl.4s	v20, v20, #0x17
     b60:      	add.4s	v20, v20, v0
     b64:      	fmul.4s	v20, v22, v20
     b68:      	shl.4s	v19, v19, #0x17
     b6c:      	add.4s	v19, v19, v0
     b70:      	fmul.4s	v18, v18, v19
     b74:      	fcmgt.4s	v17, v17, v25
     b78:      	bsl.16b	v17, v13, v18
     b7c:      	fmul.4s	v3, v2, v3
     b80:      	fcmgt.4s	v7, v7, v25
     b84:      	bsl.16b	v7, v13, v20
     b88:      	fdiv.4s	v3, v3, v6
     b8c:      	ldr	q19, [sp, #0x120]
     b90:      	fdiv.4s	v6, v19, v7
     b94:      	fsub.4s	v18, v7, v6
     b98:      	fadd.4s	v6, v7, v6
     b9c:      	fdiv.4s	v6, v18, v6
     ba0:      	bsl.16b	v5, v6, v0
     ba4:      	fcmge.4s	v2, v0, v2
     ba8:      	bsl.16b	v2, v3, v5
     bac:      	fdiv.4s	v3, v19, v17
     bb0:      	fsub.4s	v5, v17, v3
     bb4:      	fadd.4s	v3, v17, v3
     bb8:      	fdiv.4s	v3, v5, v3
     bbc:      	bif.16b	v3, v0, v4
     bc0:      	fcmge.4s	v1, v0, v1
     bc4:      	bsl.16b	v1, v16, v3
     bc8:      	mvni.4s	v4, #0x80, lsl #24
     bcc:      	bif.16b	v1, v14, v4
     bd0:      	fcmeq.4s	v3, v14, v14
     bd4:      	fadd.4s	v1, v1, v0
     bd8:      	bif.16b	v1, v15, v3
     bdc:      	bif.16b	v2, v12, v4
     be0:      	fcmeq.4s	v3, v12, v12
     be4:      	fadd.4s	v2, v2, v0
     be8:      	bif.16b	v2, v15, v3
     bec:      	fmul.4s	v3, v11, v9
     bf0:      	fmul.4s	v2, v3, v2
     bf4:      	fmul.4s	v3, v10, v9
     bf8:      	fmul.4s	v1, v3, v1
     bfc:      	add	x12, x10, x8
     c00:      	ldp	q4, q3, [x12]
     c04:      	fadd.4s	v1, v4, v1
     c08:      	fadd.4s	v2, v3, v2
     c0c:      	add	x12, x9, x8
     c10:      	stp	q1, q2, [x12]
     c14:      	add	x8, x8, #0x20
     c18:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     c1c:      	b.ne	0x90c <ltmp0+0x90c>
     c20:      	add	x20, x22, #0x4, lsl #12 ; =0x4000
     c24:      	ldr	s2, [x23, x20]
     c28:      	movi.2d	v1, #0000000000000000
     c2c:      	mov	w8, #0x2713             ; =10003
     c30:      	movk	w8, #0x3d37, lsl #16
     c34:      	fmov	s3, w8
     c38:      	fmul.4s	v3, v2, v3
     c3c:      	fmul.4s	v3, v2, v3
     c40:      	fmul.4s	v3, v2, v3
     c44:      	fadd.4s	v3, v2, v3
     c48:      	mov	w8, #0x422a             ; =16938
     c4c:      	movk	w8, #0x3f4c, lsl #16
     c50:      	fmov	s4, w8
     c54:      	fmul.4s	v3, v3, v4
     c58:      	mov.s	v1[0], v3[0]
     c5c:      	fabs.4s	v3, v1
     c60:      	mov	w8, #0x9231             ; =37425
     c64:      	movk	w8, #0x2f30, lsl #16
     c68:      	dup.4s	v5, w8
     c6c:      	mov	w8, #0x322b             ; =12843
     c70:      	movk	w8, #0x32d7, lsl #16
     c74:      	dup.4s	v6, w8
     c78:      	fmul.4s	v4, v1, v1
     c7c:      	fmla.4s	v6, v4, v5
     c80:      	mov	w8, #0xef1d             ; =61213
     c84:      	movk	w8, #0x3638, lsl #16
     c88:      	dup.4s	v5, w8
     c8c:      	fmla.4s	v5, v4, v6
     c90:      	mov	w8, #0xd01              ; =3329
     c94:      	movk	w8, #0x3950, lsl #16
     c98:      	dup.4s	v6, w8
     c9c:      	mov	w8, #0x8889             ; =34953
     ca0:      	movk	w8, #0x3c08, lsl #16
     ca4:      	dup.4s	v16, w8
     ca8:      	fmla.4s	v6, v4, v5
     cac:      	fmla.4s	v16, v4, v6
     cb0:      	mov	w8, #0xaaab             ; =43691
     cb4:      	movk	w8, #0x3e2a, lsl #16
     cb8:      	dup.4s	v17, w8
     cbc:      	ldr	q5, [sp, #0x110]
     cc0:      	fcmge.4s	v5, v5, v3
     cc4:      	and.16b	v6, v5, v3
     cc8:      	mov	w8, #-0x3d300000        ; =-1026555904
     ccc:      	dup.4s	v7, w8
     cd0:      	fcmge.4s	v18, v6, v7
     cd4:      	mov	w8, #0x42c80000         ; =1120403456
     cd8:      	dup.4s	v7, w8
     cdc:      	fcmge.4s	v19, v7, v6
     ce0:      	and.16b	v18, v18, v19
     ce4:      	and.16b	v18, v18, v6
     ce8:      	mov	w8, #0xaa3b             ; =43579
     cec:      	movk	w8, #0x3fb8, lsl #16
     cf0:      	dup.4s	v19, w8
     cf4:      	fmul.4s	v19, v18, v19
     cf8:      	movi.4s	v20, #0x4b, lsl #24
     cfc:      	fadd.4s	v19, v19, v20
     d00:      	movi.4s	v20, #0xcb, lsl #24
     d04:      	fadd.4s	v19, v19, v20
     d08:      	fcvtzs.4s	v19, v19
     d0c:      	scvtf.4s	v20, v19
     d10:      	mov	w8, #0x7200             ; =29184
     d14:      	movk	w8, #0xbf31, lsl #16
     d18:      	dup.4s	v21, w8
     d1c:      	fmul.4s	v21, v20, v21
     d20:      	fadd.4s	v18, v18, v21
     d24:      	mov	w8, #0xbe8e             ; =48782
     d28:      	movk	w8, #0xb5bf, lsl #16
     d2c:      	dup.4s	v21, w8
     d30:      	fmul.4s	v20, v20, v21
     d34:      	fadd.4s	v18, v18, v20
     d38:      	mov	w8, #0x2bda             ; =11226
     d3c:      	movk	w8, #0x3950, lsl #16
     d40:      	dup.4s	v20, w8
     d44:      	fmul.4s	v20, v18, v20
     d48:      	mov	w8, #0x96c9             ; =38601
     d4c:      	movk	w8, #0x3ab6, lsl #16
     d50:      	dup.4s	v21, w8
     d54:      	fadd.4s	v20, v20, v21
     d58:      	mov	w8, #0x88a6             ; =34982
     d5c:      	movk	w8, #0x3c08, lsl #16
     d60:      	dup.4s	v21, w8
     d64:      	fmul.4s	v20, v18, v20
     d68:      	fadd.4s	v20, v20, v21
     d6c:      	fmul.4s	v20, v18, v20
     d70:      	mov	w8, #0xaa7a             ; =43642
     d74:      	movk	w8, #0x3d2a, lsl #16
     d78:      	dup.4s	v21, w8
     d7c:      	fadd.4s	v20, v20, v21
     d80:      	fmul.4s	v20, v18, v20
     d84:      	fadd.4s	v20, v20, v17
     d88:      	fmla.4s	v17, v4, v16
     d8c:      	mov.16b	v16, v0
     d90:      	mov	w8, #0x76c7             ; =30407
     d94:      	movk	w8, #0x310f, lsl #16
     d98:      	dup.4s	v21, w8
     d9c:      	mov	w8, #0xf27e             ; =62078
     da0:      	movk	w8, #0x3493, lsl #16
     da4:      	dup.4s	v22, w8
     da8:      	fmla.4s	v16, v4, v17
     dac:      	fmla.4s	v22, v4, v21
     db0:      	mov	w8, #0xd01              ; =3329
     db4:      	movk	w8, #0x37d0, lsl #16
     db8:      	dup.4s	v17, w8
     dbc:      	fmla.4s	v17, v4, v22
     dc0:      	mov	w8, #0xb61              ; =2913
     dc4:      	movk	w8, #0x3ab6, lsl #16
     dc8:      	dup.4s	v21, w8
     dcc:      	mov	w8, #0xaaab             ; =43691
     dd0:      	movk	w8, #0x3d2a, lsl #16
     dd4:      	dup.4s	v22, w8
     dd8:      	fmla.4s	v21, v4, v17
     ddc:      	fmla.4s	v22, v4, v21
     de0:      	movi.4s	v17, #0x3f, lsl #24
     de4:      	fmla.4s	v17, v4, v22
     de8:      	mov.16b	v21, v0
     dec:      	fmla.4s	v21, v4, v17
     df0:      	movi.4s	v4, #0x3f, lsl #24
     df4:      	fmul.4s	v2, v2, v4
     df8:      	fcmge.4s	v17, v0, v3
     dfc:      	fmul.4s	v3, v3, v16
     e00:      	fdiv.4s	v3, v3, v21
     e04:      	fmul.4s	v16, v18, v20
     e08:      	fadd.4s	v4, v16, v4
     e0c:      	fmul.4s	v16, v18, v18
     e10:      	fmul.4s	v4, v16, v4
     e14:      	fadd.4s	v4, v18, v4
     e18:      	fadd.4s	v4, v4, v0
     e1c:      	movi.2d	v16, #0xffffffffffffffff
     e20:      	add.4s	v16, v19, v16
     e24:      	sshr.4s	v18, v16, #0x1
     e28:      	shl.4s	v19, v18, #0x17
     e2c:      	add.4s	v19, v19, v0
     e30:      	fmul.4s	v4, v4, v19
     e34:      	sub.4s	v16, v16, v18
     e38:      	shl.4s	v16, v16, #0x17
     e3c:      	add.4s	v16, v16, v0
     e40:      	fmul.4s	v4, v4, v16
     e44:      	fcmgt.4s	v6, v6, v7
     e48:      	mvni.4s	v7, #0x7f, msl #16
     e4c:      	fneg.4s	v7, v7
     e50:      	bit.16b	v4, v7, v6
     e54:      	ldr	q6, [sp, #0x120]
     e58:      	fdiv.4s	v6, v6, v4
     e5c:      	fsub.4s	v7, v4, v6
     e60:      	fadd.4s	v4, v4, v6
     e64:      	fdiv.4s	v4, v7, v4
     e68:      	bif.16b	v4, v0, v5
     e6c:      	bif.16b	v3, v4, v17
     e70:      	mvni.4s	v4, #0x80, lsl #24
     e74:      	bif.16b	v3, v1, v4
     e78:      	fcmeq.4s	v1, v1, v1
     e7c:      	fadd.4s	v0, v3, v0
     e80:      	mvni.4s	v3, #0x3f, msl #16
     e84:      	fneg.4s	v3, v3
     e88:      	bif.16b	v0, v3, v1
     e8c:      	fmul.4s	v0, v2, v0
     e90:      	ldr	s1, [x21, x20]
     e94:      	fadd.4s	v0, v1, v0
     e98:      	str	s0, [x19, x20]
     e9c:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
     ea0:      	add	sp, sp, #0x170
     ea4:      	ldp	x29, x30, [sp, #0x80]
     ea8:      	ldp	x20, x19, [sp, #0x70]
     eac:      	ldp	x22, x21, [sp, #0x60]
     eb0:      	ldp	x24, x23, [sp, #0x50]
     eb4:      	ldp	x28, x27, [sp, #0x40]
     eb8:      	ldp	d9, d8, [sp, #0x30]
     ebc:      	ldp	d11, d10, [sp, #0x20]
     ec0:      	ldp	d13, d12, [sp, #0x10]
     ec4:      	ldp	d15, d14, [sp], #0x90
     ec8:      	ret

0000000000000ecc <_llm_rows.packet_batch.blocks>:
     ecc:      	stp	d15, d14, [sp, #-0xa0]!
     ed0:      	stp	d13, d12, [sp, #0x10]
     ed4:      	stp	d11, d10, [sp, #0x20]
     ed8:      	stp	d9, d8, [sp, #0x30]
     edc:      	stp	x28, x27, [sp, #0x40]
     ee0:      	stp	x26, x25, [sp, #0x50]
     ee4:      	stp	x24, x23, [sp, #0x60]
     ee8:      	stp	x22, x21, [sp, #0x70]
     eec:      	stp	x20, x19, [sp, #0x80]
     ef0:      	stp	x29, x30, [sp, #0x90]
     ef4:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
     ef8:      	sub	sp, sp, #0x420
     efc:      	str	x0, [sp, #0x118]
     f00:      	cbz	w3, 0x2acc <_llm_rows.packet_batch.blocks+0x1c00>
     f04:      	mov	x19, x3
     f08:      	mov	x20, x2
     f0c:      	mov	w22, #0x0               ; =0
     f10:      	ldp	w9, w8, [x2, #0x2c]
     f14:      	str	w9, [sp, #0x114]
     f18:      	str	w8, [sp, #0x110]
     f1c:      	adrp	x8, 0x0 <ltmp0>
     f20:      	ldr	q0, [x8]
     f24:      	str	q0, [sp, #0x90]
     f28:      	adrp	x8, 0x0 <ltmp0>
     f2c:      	ldr	q0, [x8]
     f30:      	str	q0, [sp, #0x80]
     f34:      	adrp	x8, 0x0 <ltmp0>
     f38:      	ldr	q0, [x8]
     f3c:      	str	q0, [sp, #0x70]
     f40:      	adrp	x8, 0x0 <ltmp0>
     f44:      	ldr	q0, [x8]
     f48:      	str	q0, [sp, #0x60]
     f4c:      	adrp	x8, 0x0 <ltmp0>
     f50:      	ldr	q0, [x8]
     f54:      	str	q0, [sp, #0x50]
     f58:      	adrp	x8, 0x0 <ltmp0>
     f5c:      	ldr	q0, [x8]
     f60:      	str	q0, [sp, #0x40]
     f64:      	adrp	x8, 0x0 <ltmp0>
     f68:      	ldr	q0, [x8]
     f6c:      	str	q0, [sp, #0x150]
     f70:      	movi.4s	v10, #0x3f, lsl #24
     f74:      	mvni.4s	v0, #0x7f, msl #16
     f78:      	fneg.4s	v1, v0
     f7c:      	mvni.4s	v0, #0x3f, msl #16
     f80:      	fneg.4s	v0, v0
     f84:      	stp	q0, q1, [sp, #0x190]
     f88:      	ldp	w25, w23, [x2]
     f8c:      	add	x24, sp, #0x4, lsl #12  ; =0x4000
     f90:      	add	x24, x24, #0x400
     f94:      	ldp	w28, w26, [x2, #0x8]
     f98:      	add	x27, sp, #0x3e0
     f9c:      	str	w3, [sp, #0xfc]
     fa0:      	b	0xfec <_llm_rows.packet_batch.blocks+0x120>
     fa4:      	mov	w8, #0x18               ; =24
     fa8:      	str	w8, [x20, #0x24]
     fac:      	ldr	w19, [sp, #0xfc]
     fb0:      	add	w8, w25, #0x1
     fb4:      	ldr	w9, [sp, #0x114]
     fb8:      	cmp	w8, w9
     fbc:      	cset	w8, eq
     fc0:      	csinc	w25, wzr, w25, eq
     fc4:      	cinc	w9, w23, eq
     fc8:      	ldr	w10, [sp, #0x110]
     fcc:      	cmp	w9, w10
     fd0:      	cset	w10, eq
     fd4:      	ands	w8, w8, w10
     fd8:      	csel	w23, wzr, w9, ne
     fdc:      	add	w28, w28, w8
     fe0:      	add	w22, w22, #0x1
     fe4:      	cmp	w22, w19
     fe8:      	b.eq	0x2acc <_llm_rows.packet_batch.blocks+0x1c00>
     fec:      	ubfiz	x8, x25, #5, #32
     ff0:      	cmp	x8, x26
     ff4:      	csel	x9, x8, xzr, ls
     ff8:      	subs	x10, x26, x9
     ffc:      	cmp	x10, #0x20
    1000:      	mov	w11, #0x20              ; =32
    1004:      	csel	x10, x10, x11, lo
    1008:      	cmp	x26, x9
    100c:      	stp	w25, w23, [x20]
    1010:      	str	w28, [x20, #0x8]
    1014:      	str	wzr, [x20, #0x24]
    1018:      	ccmp	x8, x26, #0x2, hi
    101c:      	csel	x21, x10, xzr, ls
    1020:      	cmp	x21, #0x20
    1024:      	b.lo	0x107c <_llm_rows.packet_batch.blocks+0x1b0>
    1028:      	ldr	x21, [sp, #0x118]
    102c:      	mov	x0, x21
    1030:      	mov	x1, x20
    1034:      	bl	0x1034 <_llm_rows.packet_batch.blocks+0x168>
    1038:      	mov	w8, #0x8                ; =8
    103c:      	str	w8, [x20, #0x24]
    1040:      	mov	x0, x21
    1044:      	mov	x1, x20
    1048:      	bl	0x1048 <_llm_rows.packet_batch.blocks+0x17c>
    104c:      	mov	w8, #0x10               ; =16
    1050:      	str	w8, [x20, #0x24]
    1054:      	mov	x0, x21
    1058:      	mov	x1, x20
    105c:      	bl	0x105c <_llm_rows.packet_batch.blocks+0x190>
    1060:      	mov	w8, #0x18               ; =24
    1064:      	str	w8, [x20, #0x24]
    1068:      	mov	x0, x21
    106c:      	mov	x1, x20
    1070:      	bl	0x1070 <_llm_rows.packet_batch.blocks+0x1a4>
    1074:      	movi.4s	v10, #0x3f, lsl #24
    1078:      	b	0xfb0 <_llm_rows.packet_batch.blocks+0xe4>
    107c:      	lsr	x19, x21, #3
    1080:      	cmp	x21, #0x8
    1084:      	b.lo	0x10dc <_llm_rows.packet_batch.blocks+0x210>
    1088:      	str	wzr, [x20, #0x24]
    108c:      	ldr	x0, [sp, #0x118]
    1090:      	mov	x1, x20
    1094:      	bl	0x1094 <_llm_rows.packet_batch.blocks+0x1c8>
    1098:      	movi.4s	v10, #0x3f, lsl #24
    109c:      	cmp	x19, #0x1
    10a0:      	b.eq	0x10dc <_llm_rows.packet_batch.blocks+0x210>
    10a4:      	mov	w8, #0x8                ; =8
    10a8:      	str	w8, [x20, #0x24]
    10ac:      	ldr	x0, [sp, #0x118]
    10b0:      	mov	x1, x20
    10b4:      	bl	0x10b4 <_llm_rows.packet_batch.blocks+0x1e8>
    10b8:      	movi.4s	v10, #0x3f, lsl #24
    10bc:      	cmp	x19, #0x2
    10c0:      	b.eq	0x10dc <_llm_rows.packet_batch.blocks+0x210>
    10c4:      	mov	w8, #0x10               ; =16
    10c8:      	str	w8, [x20, #0x24]
    10cc:      	ldr	x0, [sp, #0x118]
    10d0:      	mov	x1, x20
    10d4:      	bl	0x10d4 <_llm_rows.packet_batch.blocks+0x208>
    10d8:      	movi.4s	v10, #0x3f, lsl #24
    10dc:      	and	w8, w21, #0x7
    10e0:      	cbz	w8, 0xfa4 <_llm_rows.packet_batch.blocks+0xd8>
    10e4:      	dup.4s	v0, w8
    10e8:      	ldp	q2, q1, [sp, #0x80]
    10ec:      	cmhi.4s	v21, v0, v2
    10f0:      	cmhi.4s	v9, v0, v1
    10f4:      	uzp1.8h	v2, v9, v21
    10f8:      	umaxv.8h	h0, v2
    10fc:      	fmov	w8, s0
    1100:      	tbz	w8, #0x0, 0xfa4 <_llm_rows.packet_batch.blocks+0xd8>
    1104:      	ldr	x8, [sp, #0x118]
    1108:      	ldr	x11, [x8]
    110c:      	ldr	x9, [x8, #0x10]
    1110:      	xtn.4h	v0, v9
    1114:      	str	d0, [sp, #0x100]
    1118:      	uzp1.8b	v0, v0, v0
    111c:      	ldr	x8, [x8, #0x30]
    1120:      	sshll.2d	v1, v9, #0x0
    1124:      	sshll.2d	v3, v21, #0x0
    1128:      	sshll2.2d	v12, v9, #0x0
    112c:      	sshll2.2d	v15, v21, #0x0
    1130:      	ldp	q4, q5, [sp, #0x60]
    1134:      	and.16b	v29, v15, v5
    1138:      	and.16b	v5, v12, v4
    113c:      	ldp	q4, q6, [sp, #0x40]
    1140:      	and.16b	v3, v3, v6
    1144:      	stp	q5, q3, [sp, #0x130]
    1148:      	ubfiz	w10, w25, #2, #27
    114c:      	orr	w12, w10, w19
    1150:      	dup.4s	v3, w12
    1154:      	and.16b	v1, v1, v4
    1158:      	str	q1, [sp, #0xb0]
    115c:      	and.16b	v1, v9, v3
    1160:      	and.16b	v6, v21, v3
    1164:      	ushll2.2d	v5, v6, #0x0
    1168:      	ushll2.2d	v4, v1, #0x0
    116c:      	subs	x10, x11, x8
    1170:      	mov	w15, #0xfff             ; =4095
    1174:      	movk	w15, #0x100, lsl #16
    1178:      	ccmp	x10, x15, #0x0, hs
    117c:      	cset	w10, hi
    1180:      	mov	w13, #0x2713            ; =10003
    1184:      	movk	w13, #0x3d37, lsl #16
    1188:      	dup.4s	v7, w13
    118c:      	mov	w13, #0x422a            ; =16938
    1190:      	movk	w13, #0x3f4c, lsl #16
    1194:      	dup.4s	v3, w13
    1198:      	stp	q7, q3, [sp, #0x1c0]
    119c:      	subs	x13, x8, x11
    11a0:      	ccmp	x13, x15, #0x0, hs
    11a4:      	mov	w13, #0x9231            ; =37425
    11a8:      	movk	w13, #0x2f30, lsl #16
    11ac:      	dup.4s	v7, w13
    11b0:      	mov	w13, #0x322b            ; =12843
    11b4:      	movk	w13, #0x32d7, lsl #16
    11b8:      	dup.4s	v3, w13
    11bc:      	stp	q7, q3, [sp, #0x1e0]
    11c0:      	csinc	w14, w10, wzr, ls
    11c4:      	subs	x10, x9, x8
    11c8:      	mov	w13, #0xef1d            ; =61213
    11cc:      	movk	w13, #0x3638, lsl #16
    11d0:      	dup.4s	v7, w13
    11d4:      	mov	w13, #0xd01             ; =3329
    11d8:      	movk	w13, #0x3950, lsl #16
    11dc:      	dup.4s	v3, w13
    11e0:      	stp	q7, q3, [sp, #0x200]
    11e4:      	ccmp	x10, x15, #0x0, hs
    11e8:      	cset	w10, hi
    11ec:      	mov	w13, #0x8889            ; =34953
    11f0:      	movk	w13, #0x3c08, lsl #16
    11f4:      	dup.4s	v3, w13
    11f8:      	str	q3, [sp, #0x220]
    11fc:      	mov	w13, #0xaaab            ; =43691
    1200:      	movk	w13, #0x3e2a, lsl #16
    1204:      	dup.4s	v3, w13
    1208:      	str	q3, [sp, #0x1b0]
    120c:      	subs	x13, x8, x9
    1210:      	ccmp	x13, x15, #0x0, hs
    1214:      	umov.b	w13, v0[0]
    1218:      	mov	w15, #0x76c7            ; =30407
    121c:      	movk	w15, #0x310f, lsl #16
    1220:      	dup.4s	v3, w15
    1224:      	ushll.2d	v6, v6, #0x0
    1228:      	ushll.2d	v7, v1, #0x0
    122c:      	csinc	w10, w10, wzr, ls
    1230:      	mov	w15, #0x4004            ; =16388
    1234:      	umull	x12, w12, w15
    1238:      	tst	w13, #0x1
    123c:      	csel	x12, x12, xzr, ne
    1240:      	mov	w15, #0xf27e            ; =62078
    1244:      	movk	w15, #0x3493, lsl #16
    1248:      	dup.4s	v0, w15
    124c:      	stp	q0, q3, [sp, #0x230]
    1250:      	mov	w15, #0xd01             ; =3329
    1254:      	movk	w15, #0x37d0, lsl #16
    1258:      	dup.4s	v3, w15
    125c:      	mov	w15, #0xb61             ; =2913
    1260:      	movk	w15, #0x3ab6, lsl #16
    1264:      	dup.4s	v0, w15
    1268:      	stp	q3, q0, [sp, #0x250]
    126c:      	fmov.4s	v0, #1.00000000
    1270:      	mov	w15, #0xaaab            ; =43691
    1274:      	movk	w15, #0x3d2a, lsl #16
    1278:      	dup.4s	v23, w15
    127c:      	fmov.4s	v28, #9.00000000
    1280:      	mov	w15, #-0x3d300000       ; =-1026555904
    1284:      	dup.4s	v30, w15
    1288:      	mov	w15, #0x42c80000        ; =1120403456
    128c:      	dup.4s	v1, w15
    1290:      	mov	w15, #0xaa3b            ; =43579
    1294:      	movk	w15, #0x3fb8, lsl #16
    1298:      	dup.4s	v27, w15
    129c:      	mov	w15, #0x7200            ; =29184
    12a0:      	movk	w15, #0xbf31, lsl #16
    12a4:      	dup.4s	v8, w15
    12a8:      	mov	w15, #0xbe8e            ; =48782
    12ac:      	movk	w15, #0xb5bf, lsl #16
    12b0:      	dup.4s	v25, w15
    12b4:      	mov	w15, #0x2bda            ; =11226
    12b8:      	movk	w15, #0x3950, lsl #16
    12bc:      	dup.4s	v26, w15
    12c0:      	xtn.2s	v7, v7
    12c4:      	str	d7, [sp, #0xa0]
    12c8:      	xtn.2s	v5, v5
    12cc:      	str	d5, [sp, #0xe0]
    12d0:      	xtn.2s	v5, v6
    12d4:      	str	d5, [sp, #0xd0]
    12d8:      	xtn.2s	v4, v4
    12dc:      	str	d4, [sp, #0xc0]
    12e0:      	mov	w15, #0x96c9            ; =38601
    12e4:      	movk	w15, #0x3ab6, lsl #16
    12e8:      	dup.4s	v20, w15
    12ec:      	mov	w15, #0x88a6            ; =34982
    12f0:      	movk	w15, #0x3c08, lsl #16
    12f4:      	dup.4s	v22, w15
    12f8:      	mov	w15, #0xaa7a            ; =43642
    12fc:      	movk	w15, #0x3d2a, lsl #16
    1300:      	dup.4s	v24, w15
    1304:      	fmov.4s	v31, #0.25000000
    1308:      	mov	w15, #0x1001            ; =4097
    130c:      	dup.2s	v4, w15
    1310:      	str	d4, [sp, #0x120]
    1314:      	cmp	w14, #0x1
    1318:      	b.ne	0x1810 <_llm_rows.packet_batch.blocks+0x944>
    131c:      	cbz	w10, 0x1810 <_llm_rows.packet_batch.blocks+0x944>
    1320:      	mov	x10, #0x0               ; =0
    1324:      	add	x13, x8, x12
    1328:      	add	x14, x9, x12
    132c:      	add	x12, x11, x12
    1330:      	ldr	q4, [sp, #0x150]
    1334:      	and.16b	v2, v2, v4
    1338:      	addv.8h	h11, v2
    133c:      	fmov	w15, s11
    1340:      	b	0x1350 <_llm_rows.packet_batch.blocks+0x484>
    1344:      	add	x10, x10, #0x20
    1348:      	cmp	x10, #0x4, lsl #12      ; =0x4000
    134c:      	b.eq	0x2530 <_llm_rows.packet_batch.blocks+0x1664>
    1350:      	add	x16, x12, x10
    1354:      	movi.2d	v12, #0000000000000000
    1358:      	movi.2d	v15, #0000000000000000
    135c:      	tbz	w15, #0x0, 0x13f0 <_llm_rows.packet_batch.blocks+0x524>
    1360:      	ldr	s12, [x16]
    1364:      	and	w17, w15, #0xff
    1368:      	tbnz	w17, #0x1, 0x13f8 <_llm_rows.packet_batch.blocks+0x52c>
    136c:      	tbz	w17, #0x2, 0x1404 <_llm_rows.packet_batch.blocks+0x538>
    1370:      	add	x0, x16, #0x8
    1374:      	ld1.s	{ v12 }[2], [x0]
    1378:      	tbnz	w17, #0x3, 0x1408 <_llm_rows.packet_batch.blocks+0x53c>
    137c:      	tbz	w17, #0x4, 0x1414 <_llm_rows.packet_batch.blocks+0x548>
    1380:      	add	x0, x16, #0x10
    1384:      	ld1.s	{ v15 }[0], [x0]
    1388:      	tbnz	w17, #0x5, 0x1418 <_llm_rows.packet_batch.blocks+0x54c>
    138c:      	tbz	w17, #0x6, 0x1424 <_llm_rows.packet_batch.blocks+0x558>
    1390:      	add	x0, x16, #0x18
    1394:      	ld1.s	{ v15 }[2], [x0]
    1398:      	tbnz	w17, #0x7, 0x1428 <_llm_rows.packet_batch.blocks+0x55c>
    139c:      	fmov	w17, s11
    13a0:      	add	x16, x14, x10
    13a4:      	movi.2d	v2, #0000000000000000
    13a8:      	movi.2d	v14, #0000000000000000
    13ac:      	tbz	w17, #0x0, 0x1444 <_llm_rows.packet_batch.blocks+0x578>
    13b0:      	ldr	s2, [x16]
    13b4:      	and	w17, w17, #0xff
    13b8:      	tbnz	w17, #0x1, 0x144c <_llm_rows.packet_batch.blocks+0x580>
    13bc:      	tbz	w17, #0x2, 0x1458 <_llm_rows.packet_batch.blocks+0x58c>
    13c0:      	add	x0, x16, #0x8
    13c4:      	ld1.s	{ v2 }[2], [x0]
    13c8:      	tbnz	w17, #0x3, 0x145c <_llm_rows.packet_batch.blocks+0x590>
    13cc:      	tbz	w17, #0x4, 0x1468 <_llm_rows.packet_batch.blocks+0x59c>
    13d0:      	add	x0, x16, #0x10
    13d4:      	ld1.s	{ v14 }[0], [x0]
    13d8:      	tbnz	w17, #0x5, 0x146c <_llm_rows.packet_batch.blocks+0x5a0>
    13dc:      	tbz	w17, #0x6, 0x1478 <_llm_rows.packet_batch.blocks+0x5ac>
    13e0:      	add	x0, x16, #0x18
    13e4:      	ld1.s	{ v14 }[2], [x0]
    13e8:      	tbnz	w17, #0x7, 0x147c <_llm_rows.packet_batch.blocks+0x5b0>
    13ec:      	b	0x1484 <_llm_rows.packet_batch.blocks+0x5b8>
    13f0:      	and	w17, w15, #0xff
    13f4:      	tbz	w17, #0x1, 0x136c <_llm_rows.packet_batch.blocks+0x4a0>
    13f8:      	add	x0, x16, #0x4
    13fc:      	ld1.s	{ v12 }[1], [x0]
    1400:      	tbnz	w17, #0x2, 0x1370 <_llm_rows.packet_batch.blocks+0x4a4>
    1404:      	tbz	w17, #0x3, 0x137c <_llm_rows.packet_batch.blocks+0x4b0>
    1408:      	add	x0, x16, #0xc
    140c:      	ld1.s	{ v12 }[3], [x0]
    1410:      	tbnz	w17, #0x4, 0x1380 <_llm_rows.packet_batch.blocks+0x4b4>
    1414:      	tbz	w17, #0x5, 0x138c <_llm_rows.packet_batch.blocks+0x4c0>
    1418:      	add	x0, x16, #0x14
    141c:      	ld1.s	{ v15 }[1], [x0]
    1420:      	tbnz	w17, #0x6, 0x1390 <_llm_rows.packet_batch.blocks+0x4c4>
    1424:      	tbz	w17, #0x7, 0x139c <_llm_rows.packet_batch.blocks+0x4d0>
    1428:      	add	x16, x16, #0x1c
    142c:      	ld1.s	{ v15 }[3], [x16]
    1430:      	fmov	w17, s11
    1434:      	add	x16, x14, x10
    1438:      	movi.2d	v2, #0000000000000000
    143c:      	movi.2d	v14, #0000000000000000
    1440:      	tbnz	w17, #0x0, 0x13b0 <_llm_rows.packet_batch.blocks+0x4e4>
    1444:      	and	w17, w17, #0xff
    1448:      	tbz	w17, #0x1, 0x13bc <_llm_rows.packet_batch.blocks+0x4f0>
    144c:      	add	x0, x16, #0x4
    1450:      	ld1.s	{ v2 }[1], [x0]
    1454:      	tbnz	w17, #0x2, 0x13c0 <_llm_rows.packet_batch.blocks+0x4f4>
    1458:      	tbz	w17, #0x3, 0x13cc <_llm_rows.packet_batch.blocks+0x500>
    145c:      	add	x0, x16, #0xc
    1460:      	ld1.s	{ v2 }[3], [x0]
    1464:      	tbnz	w17, #0x4, 0x13d0 <_llm_rows.packet_batch.blocks+0x504>
    1468:      	tbz	w17, #0x5, 0x13dc <_llm_rows.packet_batch.blocks+0x510>
    146c:      	add	x0, x16, #0x14
    1470:      	ld1.s	{ v14 }[1], [x0]
    1474:      	tbnz	w17, #0x6, 0x13e0 <_llm_rows.packet_batch.blocks+0x514>
    1478:      	tbz	w17, #0x7, 0x1484 <_llm_rows.packet_batch.blocks+0x5b8>
    147c:      	add	x16, x16, #0x1c
    1480:      	ld1.s	{ v14 }[3], [x16]
    1484:      	ldp	q4, q5, [sp, #0x1c0]
    1488:      	fmul.4s	v4, v12, v4
    148c:      	fmul.4s	v4, v12, v4
    1490:      	fmul.4s	v4, v12, v4
    1494:      	fadd.4s	v4, v12, v4
    1498:      	fmul.4s	v4, v4, v5
    149c:      	and.16b	v4, v9, v4
    14a0:      	fabs.4s	v5, v4
    14a4:      	fmul.4s	v6, v4, v4
    14a8:      	ldp	q16, q7, [sp, #0x1e0]
    14ac:      	fmla.4s	v7, v6, v16
    14b0:      	ldr	q16, [sp, #0x200]
    14b4:      	fmla.4s	v16, v6, v7
    14b8:      	ldr	q7, [sp, #0x210]
    14bc:      	fmla.4s	v7, v6, v16
    14c0:      	ldr	q16, [sp, #0x220]
    14c4:      	fmla.4s	v16, v6, v7
    14c8:      	ldr	q3, [sp, #0x1b0]
    14cc:      	mov.16b	v7, v3
    14d0:      	fmla.4s	v7, v6, v16
    14d4:      	mov.16b	v16, v0
    14d8:      	fmla.4s	v16, v6, v7
    14dc:      	fmul.4s	v7, v5, v16
    14e0:      	ldp	q16, q17, [sp, #0x230]
    14e4:      	fmla.4s	v16, v6, v17
    14e8:      	ldr	q17, [sp, #0x250]
    14ec:      	fmla.4s	v17, v6, v16
    14f0:      	ldr	q16, [sp, #0x260]
    14f4:      	fmla.4s	v16, v6, v17
    14f8:      	mov.16b	v17, v23
    14fc:      	fmla.4s	v17, v6, v16
    1500:      	movi.4s	v16, #0x3f, lsl #24
    1504:      	fmla.4s	v16, v6, v17
    1508:      	mov.16b	v17, v0
    150c:      	fmla.4s	v17, v6, v16
    1510:      	fdiv.4s	v6, v7, v17
    1514:      	fcmge.4s	v7, v28, v5
    1518:      	and.16b	v16, v7, v5
    151c:      	fcmge.4s	v17, v16, v30
    1520:      	fcmge.4s	v18, v1, v16
    1524:      	and.16b	v17, v17, v18
    1528:      	and.16b	v17, v17, v16
    152c:      	fmul.4s	v18, v17, v27
    1530:      	movi.4s	v19, #0x4b, lsl #24
    1534:      	fadd.4s	v18, v18, v19
    1538:      	movi.4s	v19, #0xcb, lsl #24
    153c:      	fadd.4s	v18, v18, v19
    1540:      	fcvtzs.4s	v18, v18
    1544:      	scvtf.4s	v13, v18
    1548:      	fmul.4s	v19, v13, v8
    154c:      	fadd.4s	v17, v17, v19
    1550:      	fmul.4s	v19, v13, v25
    1554:      	fadd.4s	v17, v17, v19
    1558:      	fmul.4s	v19, v17, v26
    155c:      	fadd.4s	v19, v19, v20
    1560:      	fmul.4s	v19, v17, v19
    1564:      	fadd.4s	v19, v19, v22
    1568:      	fmul.4s	v19, v17, v19
    156c:      	fadd.4s	v19, v19, v24
    1570:      	fmul.4s	v19, v17, v19
    1574:      	fadd.4s	v19, v19, v3
    1578:      	fmul.4s	v19, v17, v19
    157c:      	fadd.4s	v19, v19, v10
    1580:      	fmul.4s	v13, v17, v17
    1584:      	fmul.4s	v19, v13, v19
    1588:      	fadd.4s	v17, v17, v19
    158c:      	fadd.4s	v17, v17, v0
    1590:      	movi.2d	v19, #0xffffffffffffffff
    1594:      	add.4s	v18, v18, v19
    1598:      	sshr.4s	v19, v18, #0x1
    159c:      	shl.4s	v13, v19, #0x17
    15a0:      	add.4s	v13, v13, v0
    15a4:      	fmul.4s	v17, v17, v13
    15a8:      	sub.4s	v18, v18, v19
    15ac:      	shl.4s	v18, v18, #0x17
    15b0:      	add.4s	v18, v18, v0
    15b4:      	fmul.4s	v17, v17, v18
    15b8:      	fcmgt.4s	v16, v16, v1
    15bc:      	ldr	q18, [sp, #0x1a0]
    15c0:      	bsl.16b	v16, v18, v17
    15c4:      	fdiv.4s	v17, v31, v16
    15c8:      	fsub.4s	v18, v16, v17
    15cc:      	fadd.4s	v16, v16, v17
    15d0:      	fdiv.4s	v16, v18, v16
    15d4:      	bsl.16b	v7, v16, v0
    15d8:      	fcmge.4s	v5, v0, v5
    15dc:      	bsl.16b	v5, v6, v7
    15e0:      	mvni.4s	v6, #0x80, lsl #24
    15e4:      	bif.16b	v5, v4, v6
    15e8:      	fcmeq.4s	v4, v4, v4
    15ec:      	fadd.4s	v5, v5, v0
    15f0:      	ldr	q6, [sp, #0x190]
    15f4:      	bsl.16b	v4, v5, v6
    15f8:      	fmul.4s	v5, v12, v10
    15fc:      	fmul.4s	v4, v5, v4
    1600:      	fadd.4s	v2, v2, v4
    1604:      	fmov	w17, s11
    1608:      	add	x16, x13, x10
    160c:      	tbz	w17, #0x0, 0x1630 <_llm_rows.packet_batch.blocks+0x764>
    1610:      	str	s2, [x16]
    1614:      	and	w17, w17, #0xff
    1618:      	tbnz	w17, #0x1, 0x1638 <_llm_rows.packet_batch.blocks+0x76c>
    161c:      	tbz	w17, #0x2, 0x1644 <_llm_rows.packet_batch.blocks+0x778>
    1620:      	add	x0, x16, #0x8
    1624:      	st1.s	{ v2 }[2], [x0]
    1628:      	tbnz	w17, #0x3, 0x1648 <_llm_rows.packet_batch.blocks+0x77c>
    162c:      	b	0x1650 <_llm_rows.packet_batch.blocks+0x784>
    1630:      	and	w17, w17, #0xff
    1634:      	tbz	w17, #0x1, 0x161c <_llm_rows.packet_batch.blocks+0x750>
    1638:      	add	x0, x16, #0x4
    163c:      	st1.s	{ v2 }[1], [x0]
    1640:      	tbnz	w17, #0x2, 0x1620 <_llm_rows.packet_batch.blocks+0x754>
    1644:      	tbz	w17, #0x3, 0x1650 <_llm_rows.packet_batch.blocks+0x784>
    1648:      	add	x0, x16, #0xc
    164c:      	st1.s	{ v2 }[3], [x0]
    1650:      	ldp	q2, q4, [sp, #0x1c0]
    1654:      	fmul.4s	v2, v15, v2
    1658:      	fmul.4s	v2, v15, v2
    165c:      	fmul.4s	v2, v15, v2
    1660:      	fadd.4s	v2, v15, v2
    1664:      	fmul.4s	v2, v2, v4
    1668:      	and.16b	v2, v21, v2
    166c:      	fabs.4s	v4, v2
    1670:      	fmul.4s	v5, v2, v2
    1674:      	ldp	q7, q6, [sp, #0x1e0]
    1678:      	fmla.4s	v6, v5, v7
    167c:      	ldr	q7, [sp, #0x200]
    1680:      	fmla.4s	v7, v5, v6
    1684:      	ldr	q6, [sp, #0x210]
    1688:      	fmla.4s	v6, v5, v7
    168c:      	ldr	q7, [sp, #0x220]
    1690:      	fmla.4s	v7, v5, v6
    1694:      	ldr	q3, [sp, #0x1b0]
    1698:      	mov.16b	v6, v3
    169c:      	fmla.4s	v6, v5, v7
    16a0:      	mov.16b	v7, v0
    16a4:      	fmla.4s	v7, v5, v6
    16a8:      	fmul.4s	v6, v4, v7
    16ac:      	ldp	q7, q16, [sp, #0x230]
    16b0:      	fmla.4s	v7, v5, v16
    16b4:      	ldr	q16, [sp, #0x250]
    16b8:      	fmla.4s	v16, v5, v7
    16bc:      	ldr	q7, [sp, #0x260]
    16c0:      	fmla.4s	v7, v5, v16
    16c4:      	mov.16b	v16, v23
    16c8:      	fmla.4s	v16, v5, v7
    16cc:      	movi.4s	v7, #0x3f, lsl #24
    16d0:      	fmla.4s	v7, v5, v16
    16d4:      	mov.16b	v16, v0
    16d8:      	fmla.4s	v16, v5, v7
    16dc:      	fdiv.4s	v5, v6, v16
    16e0:      	fcmge.4s	v6, v28, v4
    16e4:      	and.16b	v7, v6, v4
    16e8:      	fcmge.4s	v16, v7, v30
    16ec:      	fcmge.4s	v17, v1, v7
    16f0:      	and.16b	v16, v16, v17
    16f4:      	and.16b	v16, v16, v7
    16f8:      	fmul.4s	v17, v16, v27
    16fc:      	movi.4s	v18, #0x4b, lsl #24
    1700:      	fadd.4s	v17, v17, v18
    1704:      	movi.4s	v18, #0xcb, lsl #24
    1708:      	fadd.4s	v17, v17, v18
    170c:      	fcvtzs.4s	v17, v17
    1710:      	scvtf.4s	v18, v17
    1714:      	fmul.4s	v19, v18, v8
    1718:      	fadd.4s	v16, v16, v19
    171c:      	fmul.4s	v18, v18, v25
    1720:      	fadd.4s	v16, v16, v18
    1724:      	fmul.4s	v18, v16, v26
    1728:      	fadd.4s	v18, v18, v20
    172c:      	fmul.4s	v18, v16, v18
    1730:      	fadd.4s	v18, v18, v22
    1734:      	fmul.4s	v18, v16, v18
    1738:      	fadd.4s	v18, v18, v24
    173c:      	fmul.4s	v18, v16, v18
    1740:      	fadd.4s	v18, v18, v3
    1744:      	fmul.4s	v18, v16, v18
    1748:      	fadd.4s	v18, v18, v10
    174c:      	fmul.4s	v19, v16, v16
    1750:      	fmul.4s	v18, v19, v18
    1754:      	fadd.4s	v16, v16, v18
    1758:      	fadd.4s	v16, v16, v0
    175c:      	movi.2d	v18, #0xffffffffffffffff
    1760:      	add.4s	v17, v17, v18
    1764:      	sshr.4s	v18, v17, #0x1
    1768:      	shl.4s	v19, v18, #0x17
    176c:      	add.4s	v19, v19, v0
    1770:      	fmul.4s	v16, v16, v19
    1774:      	sub.4s	v17, v17, v18
    1778:      	shl.4s	v17, v17, #0x17
    177c:      	add.4s	v17, v17, v0
    1780:      	fmul.4s	v16, v16, v17
    1784:      	fcmgt.4s	v7, v7, v1
    1788:      	ldr	q17, [sp, #0x1a0]
    178c:      	bsl.16b	v7, v17, v16
    1790:      	fdiv.4s	v16, v31, v7
    1794:      	fsub.4s	v17, v7, v16
    1798:      	fadd.4s	v7, v7, v16
    179c:      	fdiv.4s	v7, v17, v7
    17a0:      	bsl.16b	v6, v7, v0
    17a4:      	fcmge.4s	v4, v0, v4
    17a8:      	bsl.16b	v4, v5, v6
    17ac:      	mvni.4s	v5, #0x80, lsl #24
    17b0:      	bif.16b	v4, v2, v5
    17b4:      	fcmeq.4s	v2, v2, v2
    17b8:      	fadd.4s	v4, v4, v0
    17bc:      	ldr	q5, [sp, #0x190]
    17c0:      	bsl.16b	v2, v4, v5
    17c4:      	fmul.4s	v4, v15, v10
    17c8:      	fmul.4s	v2, v4, v2
    17cc:      	fadd.4s	v2, v14, v2
    17d0:      	tbz	w17, #0x4, 0x17f0 <_llm_rows.packet_batch.blocks+0x924>
    17d4:      	str	s2, [x16, #0x10]
    17d8:      	tbnz	w17, #0x5, 0x17f4 <_llm_rows.packet_batch.blocks+0x928>
    17dc:      	tbz	w17, #0x6, 0x1800 <_llm_rows.packet_batch.blocks+0x934>
    17e0:      	add	x0, x16, #0x18
    17e4:      	st1.s	{ v2 }[2], [x0]
    17e8:      	tbz	w17, #0x7, 0x1344 <_llm_rows.packet_batch.blocks+0x478>
    17ec:      	b	0x1804 <_llm_rows.packet_batch.blocks+0x938>
    17f0:      	tbz	w17, #0x5, 0x17dc <_llm_rows.packet_batch.blocks+0x910>
    17f4:      	add	x0, x16, #0x14
    17f8:      	st1.s	{ v2 }[1], [x0]
    17fc:      	tbnz	w17, #0x6, 0x17e0 <_llm_rows.packet_batch.blocks+0x914>
    1800:      	tbz	w17, #0x7, 0x1344 <_llm_rows.packet_batch.blocks+0x478>
    1804:      	add	x16, x16, #0x1c
    1808:      	st1.s	{ v2 }[3], [x16]
    180c:      	b	0x1344 <_llm_rows.packet_batch.blocks+0x478>
    1810:      	mov	x10, #0x0               ; =0
    1814:      	add	x14, x11, x12
    1818:      	b	0x183c <_llm_rows.packet_batch.blocks+0x970>
    181c:      	add	x15, x24, x10
    1820:      	ldp	q6, q7, [x15]
    1824:      	bif.16b	v5, v7, v21
    1828:      	bif.16b	v4, v6, v9
    182c:      	stp	q4, q5, [x15]
    1830:      	add	x10, x10, #0x20
    1834:      	cmp	x10, #0x4, lsl #12      ; =0x4000
    1838:      	b.eq	0x18e0 <_llm_rows.packet_batch.blocks+0xa14>
    183c:      	ldr	q4, [sp, #0x150]
    1840:      	and.16b	v4, v2, v4
    1844:      	addv.8h	h3, v4
    1848:      	fmov	w16, s3
    184c:      	add	x15, x14, x10
    1850:      	movi.2d	v4, #0000000000000000
    1854:      	movi.2d	v5, #0000000000000000
    1858:      	tbz	w16, #0x0, 0x189c <_llm_rows.packet_batch.blocks+0x9d0>
    185c:      	ldr	s4, [x15]
    1860:      	and	w16, w16, #0xff
    1864:      	tbnz	w16, #0x1, 0x18a4 <_llm_rows.packet_batch.blocks+0x9d8>
    1868:      	tbz	w16, #0x2, 0x18b0 <_llm_rows.packet_batch.blocks+0x9e4>
    186c:      	add	x17, x15, #0x8
    1870:      	ld1.s	{ v4 }[2], [x17]
    1874:      	tbnz	w16, #0x3, 0x18b4 <_llm_rows.packet_batch.blocks+0x9e8>
    1878:      	tbz	w16, #0x4, 0x18c0 <_llm_rows.packet_batch.blocks+0x9f4>
    187c:      	add	x17, x15, #0x10
    1880:      	ld1.s	{ v5 }[0], [x17]
    1884:      	tbnz	w16, #0x5, 0x18c4 <_llm_rows.packet_batch.blocks+0x9f8>
    1888:      	tbz	w16, #0x6, 0x18d0 <_llm_rows.packet_batch.blocks+0xa04>
    188c:      	add	x17, x15, #0x18
    1890:      	ld1.s	{ v5 }[2], [x17]
    1894:      	tbz	w16, #0x7, 0x181c <_llm_rows.packet_batch.blocks+0x950>
    1898:      	b	0x18d4 <_llm_rows.packet_batch.blocks+0xa08>
    189c:      	and	w16, w16, #0xff
    18a0:      	tbz	w16, #0x1, 0x1868 <_llm_rows.packet_batch.blocks+0x99c>
    18a4:      	add	x17, x15, #0x4
    18a8:      	ld1.s	{ v4 }[1], [x17]
    18ac:      	tbnz	w16, #0x2, 0x186c <_llm_rows.packet_batch.blocks+0x9a0>
    18b0:      	tbz	w16, #0x3, 0x1878 <_llm_rows.packet_batch.blocks+0x9ac>
    18b4:      	add	x17, x15, #0xc
    18b8:      	ld1.s	{ v4 }[3], [x17]
    18bc:      	tbnz	w16, #0x4, 0x187c <_llm_rows.packet_batch.blocks+0x9b0>
    18c0:      	tbz	w16, #0x5, 0x1888 <_llm_rows.packet_batch.blocks+0x9bc>
    18c4:      	add	x17, x15, #0x14
    18c8:      	ld1.s	{ v5 }[1], [x17]
    18cc:      	tbnz	w16, #0x6, 0x188c <_llm_rows.packet_batch.blocks+0x9c0>
    18d0:      	tbz	w16, #0x7, 0x181c <_llm_rows.packet_batch.blocks+0x950>
    18d4:      	add	x15, x15, #0x1c
    18d8:      	ld1.s	{ v5 }[3], [x15]
    18dc:      	b	0x181c <_llm_rows.packet_batch.blocks+0x950>
    18e0:      	ldr	d2, [sp, #0x100]
    18e4:      	uzp1.8b	v4, v2, v0
    18e8:      	movi.2d	v5, #0000000000000000
    18ec:      	mov.b	v5[0], v4[0]
    18f0:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x134>
    18f4:      	ldr	d2, [x10]
    18f8:      	str	d2, [sp, #0x20]
    18fc:      	and.8b	v2, v5, v2
    1900:      	addv.8b	b2, v2
    1904:      	fmov	w15, s2
    1908:      	str	q5, [sp, #0x100]
    190c:      	umaxv.8b	b2, v5
    1910:      	fmov	w16, s2
    1914:      	rbit	w10, w15
    1918:      	clz	w10, w10
    191c:      	tst	w16, #0x1
    1920:      	csel	w10, w10, wzr, ne
    1924:      	mov	w14, #0x1000            ; =4096
    1928:      	dup.2d	v2, x14
    192c:      	ldr	d5, [sp, #0x120]
    1930:      	ldr	q6, [sp, #0xb0]
    1934:      	ldr	d7, [sp, #0xa0]
    1938:      	umlal.2d	v6, v7, v5
    193c:      	movi.2d	v5, #0000000000000000
    1940:      	mov.b	v5[0], v4[0]
    1944:      	add.2d	v6, v6, v2
    1948:      	ushll.2d	v4, v5, #0x0
    194c:      	shl.2d	v4, v4, #0x3f
    1950:      	cmlt.2d	v4, v4, #0
    1954:      	str	q6, [sp, #0xb0]
    1958:      	and.16b	v4, v4, v6
    195c:      	movi.2d	v5, #0000000000000000
    1960:      	stp	q5, q5, [sp, #0x3b0]
    1964:      	stp	q4, q5, [sp, #0x390]
    1968:      	and	x14, x10, #0x7
    196c:      	add	x17, sp, #0x390
    1970:      	ldr	x14, [x17, x14, lsl #3]
    1974:      	sub	x14, x14, x10
    1978:      	lsl	x14, x14, #2
    197c:      	add	x11, x11, x14
    1980:      	movi.2d	v13, #0000000000000000
    1984:      	movi.2d	v19, #0000000000000000
    1988:      	tbz	w16, #0x0, 0x19c8 <_llm_rows.packet_batch.blocks+0xafc>
    198c:      	ldr	s13, [x11]
    1990:      	tbnz	w15, #0x1, 0x19cc <_llm_rows.packet_batch.blocks+0xb00>
    1994:      	tbz	w15, #0x2, 0x19d8 <_llm_rows.packet_batch.blocks+0xb0c>
    1998:      	add	x16, x11, #0x8
    199c:      	ld1.s	{ v13 }[2], [x16]
    19a0:      	tbnz	w15, #0x3, 0x19dc <_llm_rows.packet_batch.blocks+0xb10>
    19a4:      	tbz	w15, #0x4, 0x19e8 <_llm_rows.packet_batch.blocks+0xb1c>
    19a8:      	add	x16, x11, #0x10
    19ac:      	ld1.s	{ v19 }[0], [x16]
    19b0:      	tbnz	w15, #0x5, 0x19ec <_llm_rows.packet_batch.blocks+0xb20>
    19b4:      	tbz	w15, #0x6, 0x19f8 <_llm_rows.packet_batch.blocks+0xb2c>
    19b8:      	add	x16, x11, #0x18
    19bc:      	ld1.s	{ v19 }[2], [x16]
    19c0:      	tbnz	w15, #0x7, 0x19fc <_llm_rows.packet_batch.blocks+0xb30>
    19c4:      	b	0x1a04 <_llm_rows.packet_batch.blocks+0xb38>
    19c8:      	tbz	w15, #0x1, 0x1994 <_llm_rows.packet_batch.blocks+0xac8>
    19cc:      	add	x16, x11, #0x4
    19d0:      	ld1.s	{ v13 }[1], [x16]
    19d4:      	tbnz	w15, #0x2, 0x1998 <_llm_rows.packet_batch.blocks+0xacc>
    19d8:      	tbz	w15, #0x3, 0x19a4 <_llm_rows.packet_batch.blocks+0xad8>
    19dc:      	add	x16, x11, #0xc
    19e0:      	ld1.s	{ v13 }[3], [x16]
    19e4:      	tbnz	w15, #0x4, 0x19a8 <_llm_rows.packet_batch.blocks+0xadc>
    19e8:      	tbz	w15, #0x5, 0x19b4 <_llm_rows.packet_batch.blocks+0xae8>
    19ec:      	add	x16, x11, #0x14
    19f0:      	ld1.s	{ v19 }[1], [x16]
    19f4:      	tbnz	w15, #0x6, 0x19b8 <_llm_rows.packet_batch.blocks+0xaec>
    19f8:      	tbz	w15, #0x7, 0x1a04 <_llm_rows.packet_batch.blocks+0xb38>
    19fc:      	add	x11, x11, #0x1c
    1a00:      	ld1.s	{ v19 }[3], [x11]
    1a04:      	mov	x17, #0x0               ; =0
    1a08:      	ldr	q4, [sp, #0x130]
    1a0c:      	ldr	d6, [sp, #0x120]
    1a10:      	ldr	d5, [sp, #0xc0]
    1a14:      	umlal.2d	v4, v5, v6
    1a18:      	add.2d	v4, v4, v2
    1a1c:      	str	q4, [sp, #0xc0]
    1a20:      	ldr	q4, [sp, #0x140]
    1a24:      	ldr	d5, [sp, #0xd0]
    1a28:      	umlal.2d	v4, v5, v6
    1a2c:      	add.2d	v4, v4, v2
    1a30:      	str	q4, [sp, #0xa0]
    1a34:      	ldr	d4, [sp, #0xe0]
    1a38:      	umlal.2d	v29, v4, v6
    1a3c:      	add.2d	v2, v29, v2
    1a40:      	str	q2, [sp, #0x30]
    1a44:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x134>
    1a48:      	ldr	q2, [x11]
    1a4c:      	mov	w11, #0x4000            ; =16384
    1a50:      	dup.2d	v4, x11
    1a54:      	sshll.2d	v5, v9, #0x0
    1a58:      	bif.16b	v2, v4, v5
    1a5c:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x134>
    1a60:      	ldr	q5, [x11]
    1a64:      	sshll.2d	v6, v21, #0x0
    1a68:      	bif.16b	v5, v4, v6
    1a6c:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x134>
    1a70:      	ldr	q6, [x11]
    1a74:      	bif.16b	v6, v4, v12
    1a78:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x134>
    1a7c:      	ldr	q7, [x11]
    1a80:      	bit.16b	v4, v7, v15
    1a84:      	stp	q5, q4, [sp, #0x370]
    1a88:      	stp	q2, q6, [sp, #0x350]
    1a8c:      	and	x11, x10, #0x7
    1a90:      	add	x16, sp, #0x350
    1a94:      	ldr	x11, [x16, x11, lsl #3]
    1a98:      	sub	x11, x11, x10, lsl #2
    1a9c:      	tst	w15, #0xff
    1aa0:      	csel	x15, xzr, x11, eq
    1aa4:      	add	x11, x24, x15
    1aa8:      	ldp	q2, q4, [x11]
    1aac:      	ldr	q6, [sp, #0x100]
    1ab0:      	zip2.8b	v5, v6, v0
    1ab4:      	ushll.4s	v5, v5, #0x0
    1ab8:      	shl.4s	v5, v5, #0x1f
    1abc:      	cmlt.4s	v5, v5, #0
    1ac0:      	bit.16b	v4, v19, v5
    1ac4:      	zip1.8b	v5, v6, v0
    1ac8:      	ushll.4s	v5, v5, #0x0
    1acc:      	shl.4s	v5, v5, #0x1f
    1ad0:      	cmlt.4s	v5, v5, #0
    1ad4:      	bit.16b	v2, v13, v5
    1ad8:      	stp	q2, q4, [x11]
    1adc:      	add	x16, x9, x12
    1ae0:      	ushll2.2d	v2, v21, #0x0
    1ae4:      	mov	w11, #0x1               ; =1
    1ae8:      	dup.2d	v4, x11
    1aec:      	and.16b	v15, v2, v4
    1af0:      	ushll2.2d	v2, v9, #0x0
    1af4:      	and.16b	v11, v2, v4
    1af8:      	ushll.2d	v2, v21, #0x0
    1afc:      	and.16b	v14, v2, v4
    1b00:      	ushll.2d	v2, v9, #0x0
    1b04:      	and.16b	v29, v2, v4
    1b08:      	movi.2d	v2, #0000000000000000
    1b0c:      	and	x11, x13, #0x1
    1b10:      	movi.2d	v4, #0000000000000000
    1b14:      	movi.2d	v5, #0000000000000000
    1b18:      	movi.2d	v6, #0000000000000000
    1b1c:      	b	0x1b58 <_llm_rows.packet_batch.blocks+0xc8c>
    1b20:      	add	x13, x27, x13
    1b24:      	ldp	q17, q18, [x13]
    1b28:      	bif.16b	v16, v18, v21
    1b2c:      	bif.16b	v7, v17, v9
    1b30:      	stp	q7, q16, [x13]
    1b34:      	add.2d	v7, v2, v29
    1b38:      	add.2d	v4, v4, v11
    1b3c:      	add.2d	v5, v5, v14
    1b40:      	add.2d	v6, v6, v15
    1b44:      	fmov	x13, d2
    1b48:      	add	x17, x13, x11
    1b4c:      	mov.16b	v2, v7
    1b50:      	cmp	x17, #0x200
    1b54:      	b.ge	0x1bf4 <_llm_rows.packet_batch.blocks+0xd28>
    1b58:      	fmov	w0, s3
    1b5c:      	lsl	x13, x17, #5
    1b60:      	add	x17, x16, x13
    1b64:      	movi.2d	v7, #0000000000000000
    1b68:      	movi.2d	v16, #0000000000000000
    1b6c:      	tbz	w0, #0x0, 0x1bb0 <_llm_rows.packet_batch.blocks+0xce4>
    1b70:      	ldr	s7, [x17]
    1b74:      	and	w0, w0, #0xff
    1b78:      	tbnz	w0, #0x1, 0x1bb8 <_llm_rows.packet_batch.blocks+0xcec>
    1b7c:      	tbz	w0, #0x2, 0x1bc4 <_llm_rows.packet_batch.blocks+0xcf8>
    1b80:      	add	x1, x17, #0x8
    1b84:      	ld1.s	{ v7 }[2], [x1]
    1b88:      	tbnz	w0, #0x3, 0x1bc8 <_llm_rows.packet_batch.blocks+0xcfc>
    1b8c:      	tbz	w0, #0x4, 0x1bd4 <_llm_rows.packet_batch.blocks+0xd08>
    1b90:      	add	x1, x17, #0x10
    1b94:      	ld1.s	{ v16 }[0], [x1]
    1b98:      	tbnz	w0, #0x5, 0x1bd8 <_llm_rows.packet_batch.blocks+0xd0c>
    1b9c:      	tbz	w0, #0x6, 0x1be4 <_llm_rows.packet_batch.blocks+0xd18>
    1ba0:      	add	x1, x17, #0x18
    1ba4:      	ld1.s	{ v16 }[2], [x1]
    1ba8:      	tbz	w0, #0x7, 0x1b20 <_llm_rows.packet_batch.blocks+0xc54>
    1bac:      	b	0x1be8 <_llm_rows.packet_batch.blocks+0xd1c>
    1bb0:      	and	w0, w0, #0xff
    1bb4:      	tbz	w0, #0x1, 0x1b7c <_llm_rows.packet_batch.blocks+0xcb0>
    1bb8:      	add	x1, x17, #0x4
    1bbc:      	ld1.s	{ v7 }[1], [x1]
    1bc0:      	tbnz	w0, #0x2, 0x1b80 <_llm_rows.packet_batch.blocks+0xcb4>
    1bc4:      	tbz	w0, #0x3, 0x1b8c <_llm_rows.packet_batch.blocks+0xcc0>
    1bc8:      	add	x1, x17, #0xc
    1bcc:      	ld1.s	{ v7 }[3], [x1]
    1bd0:      	tbnz	w0, #0x4, 0x1b90 <_llm_rows.packet_batch.blocks+0xcc4>
    1bd4:      	tbz	w0, #0x5, 0x1b9c <_llm_rows.packet_batch.blocks+0xcd0>
    1bd8:      	add	x1, x17, #0x14
    1bdc:      	ld1.s	{ v16 }[1], [x1]
    1be0:      	tbnz	w0, #0x6, 0x1ba0 <_llm_rows.packet_batch.blocks+0xcd4>
    1be4:      	tbz	w0, #0x7, 0x1b20 <_llm_rows.packet_batch.blocks+0xc54>
    1be8:      	add	x17, x17, #0x1c
    1bec:      	ld1.s	{ v16 }[3], [x17]
    1bf0:      	b	0x1b20 <_llm_rows.packet_batch.blocks+0xc54>
    1bf4:      	add	x9, x9, x14
    1bf8:      	ldr	q2, [sp, #0x100]
    1bfc:      	shl.8b	v2, v2, #0x7
    1c00:      	cmlt.8b	v2, v2, #0
    1c04:      	ldr	d4, [sp, #0x20]
    1c08:      	and.8b	v2, v2, v4
    1c0c:      	addv.8b	b2, v2
    1c10:      	str	d2, [sp, #0x8]
    1c14:      	fmov	w13, s2
    1c18:      	movi.2d	v16, #0000000000000000
    1c1c:      	movi.2d	v7, #0000000000000000
    1c20:      	tbz	w13, #0x0, 0x2130 <_llm_rows.packet_batch.blocks+0x1264>
    1c24:      	ldr	s16, [x9]
    1c28:      	tbnz	w13, #0x1, 0x2134 <_llm_rows.packet_batch.blocks+0x1268>
    1c2c:      	tbz	w13, #0x2, 0x2140 <_llm_rows.packet_batch.blocks+0x1274>
    1c30:      	add	x14, x9, #0x8
    1c34:      	ld1.s	{ v16 }[2], [x14]
    1c38:      	tbnz	w13, #0x3, 0x2144 <_llm_rows.packet_batch.blocks+0x1278>
    1c3c:      	tbz	w13, #0x4, 0x2150 <_llm_rows.packet_batch.blocks+0x1284>
    1c40:      	add	x14, x9, #0x10
    1c44:      	ld1.s	{ v7 }[0], [x14]
    1c48:      	tbnz	w13, #0x5, 0x2154 <_llm_rows.packet_batch.blocks+0x1288>
    1c4c:      	stp	q9, q21, [sp, #0x130]
    1c50:      	tbz	w13, #0x6, 0x1c5c <_llm_rows.packet_batch.blocks+0xd90>
    1c54:      	add	x14, x9, #0x18
    1c58:      	ld1.s	{ v7 }[2], [x14]
    1c5c:      	stp	q13, q19, [sp, #0xd0]
    1c60:      	mov.16b	v9, v1
    1c64:      	str	q3, [sp, #0x120]
    1c68:      	stp	q22, q24, [sp, #0x170]
    1c6c:      	str	q20, [sp, #0x160]
    1c70:      	mov.16b	v12, v23
    1c74:      	mov.16b	v13, v28
    1c78:      	mov.16b	v24, v26
    1c7c:      	tbz	w13, #0x7, 0x1c88 <_llm_rows.packet_batch.blocks+0xdbc>
    1c80:      	add	x9, x9, #0x1c
    1c84:      	ld1.s	{ v7 }[3], [x9]
    1c88:      	mov	x13, #0x0               ; =0
    1c8c:      	add	x9, x27, x15
    1c90:      	ldp	q2, q4, [x9]
    1c94:      	ldr	q6, [sp, #0x100]
    1c98:      	zip2.8b	v5, v6, v0
    1c9c:      	ushll.4s	v5, v5, #0x0
    1ca0:      	shl.4s	v5, v5, #0x1f
    1ca4:      	cmlt.4s	v5, v5, #0
    1ca8:      	stp	q16, q7, [sp, #0x10]
    1cac:      	bit.16b	v4, v7, v5
    1cb0:      	zip1.8b	v5, v6, v0
    1cb4:      	ushll.4s	v5, v5, #0x0
    1cb8:      	shl.4s	v5, v5, #0x1f
    1cbc:      	cmlt.4s	v5, v5, #0
    1cc0:      	bit.16b	v2, v16, v5
    1cc4:      	stp	q2, q4, [x9]
    1cc8:      	add	x9, x8, x12
    1ccc:      	movi.2d	v2, #0000000000000000
    1cd0:      	movi.2d	v4, #0000000000000000
    1cd4:      	movi.2d	v5, #0000000000000000
    1cd8:      	movi.2d	v6, #0000000000000000
    1cdc:      	b	0x1d04 <_llm_rows.packet_batch.blocks+0xe38>
    1ce0:      	add.2d	v7, v2, v29
    1ce4:      	add.2d	v4, v4, v11
    1ce8:      	add.2d	v5, v5, v14
    1cec:      	add.2d	v6, v6, v15
    1cf0:      	fmov	x12, d2
    1cf4:      	add	x13, x12, x11
    1cf8:      	mov.16b	v2, v7
    1cfc:      	cmp	x13, #0x200
    1d00:      	b.ge	0x2168 <_llm_rows.packet_batch.blocks+0x129c>
    1d04:      	mov.16b	v26, v29
    1d08:      	mov.16b	v29, v14
    1d0c:      	mov.16b	v14, v11
    1d10:      	mov.16b	v1, v15
    1d14:      	lsl	x12, x13, #5
    1d18:      	add	x13, x24, x12
    1d1c:      	ldr	q7, [x13]
    1d20:      	ldr	q11, [sp, #0x130]
    1d24:      	and.16b	v7, v11, v7
    1d28:      	ldp	q16, q17, [sp, #0x1c0]
    1d2c:      	fmul.4s	v16, v7, v16
    1d30:      	fmul.4s	v16, v7, v16
    1d34:      	fmul.4s	v16, v7, v16
    1d38:      	fadd.4s	v16, v7, v16
    1d3c:      	fmul.4s	v16, v16, v17
    1d40:      	and.16b	v16, v11, v16
    1d44:      	fabs.4s	v17, v16
    1d48:      	fmul.4s	v18, v16, v16
    1d4c:      	ldp	q20, q19, [sp, #0x1e0]
    1d50:      	fmla.4s	v19, v18, v20
    1d54:      	ldr	q28, [sp, #0x200]
    1d58:      	fmla.4s	v28, v18, v19
    1d5c:      	ldr	q19, [sp, #0x210]
    1d60:      	fmla.4s	v19, v18, v28
    1d64:      	ldr	q28, [sp, #0x220]
    1d68:      	fmla.4s	v28, v18, v19
    1d6c:      	ldr	q21, [sp, #0x1b0]
    1d70:      	mov.16b	v19, v21
    1d74:      	fmla.4s	v19, v18, v28
    1d78:      	mov.16b	v28, v0
    1d7c:      	fmla.4s	v28, v18, v19
    1d80:      	fmul.4s	v19, v17, v28
    1d84:      	ldp	q28, q20, [sp, #0x230]
    1d88:      	fmla.4s	v28, v18, v20
    1d8c:      	ldr	q23, [sp, #0x250]
    1d90:      	fmla.4s	v23, v18, v28
    1d94:      	ldr	q28, [sp, #0x260]
    1d98:      	fmla.4s	v28, v18, v23
    1d9c:      	mov.16b	v23, v12
    1da0:      	fmla.4s	v23, v18, v28
    1da4:      	movi.4s	v28, #0x3f, lsl #24
    1da8:      	fmla.4s	v28, v18, v23
    1dac:      	mov.16b	v23, v0
    1db0:      	fmla.4s	v23, v18, v28
    1db4:      	fdiv.4s	v18, v19, v23
    1db8:      	fcmge.4s	v19, v13, v17
    1dbc:      	and.16b	v23, v19, v17
    1dc0:      	mov.16b	v15, v30
    1dc4:      	fcmge.4s	v28, v23, v30
    1dc8:      	fcmge.4s	v30, v9, v23
    1dcc:      	and.16b	v28, v28, v30
    1dd0:      	and.16b	v28, v28, v23
    1dd4:      	fmul.4s	v30, v28, v27
    1dd8:      	mov.16b	v22, v31
    1ddc:      	movi.4s	v31, #0x4b, lsl #24
    1de0:      	fadd.4s	v30, v30, v31
    1de4:      	movi.4s	v31, #0xcb, lsl #24
    1de8:      	fadd.4s	v30, v30, v31
    1dec:      	fcvtzs.4s	v30, v30
    1df0:      	scvtf.4s	v31, v30
    1df4:      	mov.16b	v20, v8
    1df8:      	fmul.4s	v8, v31, v8
    1dfc:      	fadd.4s	v28, v28, v8
    1e00:      	fmul.4s	v31, v31, v25
    1e04:      	fadd.4s	v28, v28, v31
    1e08:      	fmul.4s	v31, v28, v24
    1e0c:      	ldp	q3, q8, [sp, #0x160]
    1e10:      	fadd.4s	v31, v31, v3
    1e14:      	fmul.4s	v31, v28, v31
    1e18:      	fadd.4s	v31, v31, v8
    1e1c:      	fmul.4s	v31, v28, v31
    1e20:      	ldr	q8, [sp, #0x180]
    1e24:      	fadd.4s	v31, v31, v8
    1e28:      	fmul.4s	v31, v28, v31
    1e2c:      	fadd.4s	v31, v31, v21
    1e30:      	fmul.4s	v31, v28, v31
    1e34:      	fadd.4s	v31, v31, v10
    1e38:      	fmul.4s	v8, v28, v28
    1e3c:      	fmul.4s	v31, v8, v31
    1e40:      	fadd.4s	v28, v28, v31
    1e44:      	fadd.4s	v28, v28, v0
    1e48:      	movi.2d	v31, #0xffffffffffffffff
    1e4c:      	add.4s	v30, v30, v31
    1e50:      	sshr.4s	v31, v30, #0x1
    1e54:      	shl.4s	v8, v31, #0x17
    1e58:      	add.4s	v8, v8, v0
    1e5c:      	fmul.4s	v28, v28, v8
    1e60:      	sub.4s	v30, v30, v31
    1e64:      	shl.4s	v30, v30, #0x17
    1e68:      	add.4s	v30, v30, v0
    1e6c:      	fmul.4s	v28, v28, v30
    1e70:      	fcmgt.4s	v23, v23, v9
    1e74:      	ldr	q30, [sp, #0x1a0]
    1e78:      	bsl.16b	v23, v30, v28
    1e7c:      	fdiv.4s	v28, v22, v23
    1e80:      	fsub.4s	v30, v23, v28
    1e84:      	fadd.4s	v23, v23, v28
    1e88:      	fdiv.4s	v23, v30, v23
    1e8c:      	bsl.16b	v19, v23, v0
    1e90:      	fcmge.4s	v17, v0, v17
    1e94:      	bsl.16b	v17, v18, v19
    1e98:      	mvni.4s	v18, #0x80, lsl #24
    1e9c:      	bif.16b	v17, v16, v18
    1ea0:      	fcmeq.4s	v16, v16, v16
    1ea4:      	fadd.4s	v17, v17, v0
    1ea8:      	ldr	q18, [sp, #0x190]
    1eac:      	bif.16b	v17, v18, v16
    1eb0:      	ldr	q16, [x13, #0x10]
    1eb4:      	fmul.4s	v7, v7, v10
    1eb8:      	fmul.4s	v7, v7, v17
    1ebc:      	add	x13, x27, x12
    1ec0:      	ldr	q17, [x13]
    1ec4:      	and.16b	v17, v11, v17
    1ec8:      	fadd.4s	v17, v17, v7
    1ecc:      	ldr	q7, [x13, #0x10]
    1ed0:      	ldr	q3, [sp, #0x120]
    1ed4:      	fmov	w13, s3
    1ed8:      	add	x12, x9, x12
    1edc:      	tbz	w13, #0x0, 0x1f00 <_llm_rows.packet_batch.blocks+0x1034>
    1ee0:      	str	s17, [x12]
    1ee4:      	and	w13, w13, #0xff
    1ee8:      	tbnz	w13, #0x1, 0x1f08 <_llm_rows.packet_batch.blocks+0x103c>
    1eec:      	tbz	w13, #0x2, 0x1f14 <_llm_rows.packet_batch.blocks+0x1048>
    1ef0:      	add	x14, x12, #0x8
    1ef4:      	st1.s	{ v17 }[2], [x14]
    1ef8:      	tbnz	w13, #0x3, 0x1f18 <_llm_rows.packet_batch.blocks+0x104c>
    1efc:      	b	0x1f20 <_llm_rows.packet_batch.blocks+0x1054>
    1f00:      	and	w13, w13, #0xff
    1f04:      	tbz	w13, #0x1, 0x1eec <_llm_rows.packet_batch.blocks+0x1020>
    1f08:      	add	x14, x12, #0x4
    1f0c:      	st1.s	{ v17 }[1], [x14]
    1f10:      	tbnz	w13, #0x2, 0x1ef0 <_llm_rows.packet_batch.blocks+0x1024>
    1f14:      	tbz	w13, #0x3, 0x1f20 <_llm_rows.packet_batch.blocks+0x1054>
    1f18:      	add	x14, x12, #0xc
    1f1c:      	st1.s	{ v17 }[3], [x14]
    1f20:      	ldr	q11, [sp, #0x140]
    1f24:      	and.16b	v16, v11, v16
    1f28:      	ldp	q17, q18, [sp, #0x1c0]
    1f2c:      	fmul.4s	v17, v16, v17
    1f30:      	fmul.4s	v17, v16, v17
    1f34:      	fmul.4s	v17, v16, v17
    1f38:      	fadd.4s	v17, v16, v17
    1f3c:      	fmul.4s	v17, v17, v18
    1f40:      	and.16b	v17, v11, v17
    1f44:      	fabs.4s	v18, v17
    1f48:      	fmul.4s	v19, v17, v17
    1f4c:      	ldp	q21, q23, [sp, #0x1e0]
    1f50:      	fmla.4s	v23, v19, v21
    1f54:      	ldr	q28, [sp, #0x200]
    1f58:      	fmla.4s	v28, v19, v23
    1f5c:      	ldr	q23, [sp, #0x210]
    1f60:      	fmla.4s	v23, v19, v28
    1f64:      	ldr	q28, [sp, #0x220]
    1f68:      	fmla.4s	v28, v19, v23
    1f6c:      	ldr	q10, [sp, #0x1b0]
    1f70:      	mov.16b	v23, v10
    1f74:      	fmla.4s	v23, v19, v28
    1f78:      	mov.16b	v28, v0
    1f7c:      	fmla.4s	v28, v19, v23
    1f80:      	fmul.4s	v23, v18, v28
    1f84:      	ldp	q28, q21, [sp, #0x230]
    1f88:      	fmla.4s	v28, v19, v21
    1f8c:      	ldr	q30, [sp, #0x250]
    1f90:      	fmla.4s	v30, v19, v28
    1f94:      	ldr	q28, [sp, #0x260]
    1f98:      	fmla.4s	v28, v19, v30
    1f9c:      	mov.16b	v30, v12
    1fa0:      	fmla.4s	v30, v19, v28
    1fa4:      	movi.4s	v28, #0x3f, lsl #24
    1fa8:      	fmla.4s	v28, v19, v30
    1fac:      	mov.16b	v30, v0
    1fb0:      	fmla.4s	v30, v19, v28
    1fb4:      	fdiv.4s	v19, v23, v30
    1fb8:      	fcmge.4s	v23, v13, v18
    1fbc:      	and.16b	v28, v23, v18
    1fc0:      	fcmge.4s	v30, v28, v15
    1fc4:      	fcmge.4s	v31, v9, v28
    1fc8:      	and.16b	v30, v30, v31
    1fcc:      	and.16b	v30, v30, v28
    1fd0:      	fmul.4s	v31, v30, v27
    1fd4:      	movi.4s	v21, #0x4b, lsl #24
    1fd8:      	fadd.4s	v31, v31, v21
    1fdc:      	movi.4s	v21, #0xcb, lsl #24
    1fe0:      	fadd.4s	v31, v31, v21
    1fe4:      	fcvtzs.4s	v31, v31
    1fe8:      	scvtf.4s	v8, v31
    1fec:      	fmul.4s	v21, v8, v20
    1ff0:      	fadd.4s	v21, v30, v21
    1ff4:      	fmul.4s	v30, v8, v25
    1ff8:      	fadd.4s	v21, v21, v30
    1ffc:      	fmul.4s	v30, v21, v24
    2000:      	ldp	q3, q8, [sp, #0x160]
    2004:      	fadd.4s	v30, v30, v3
    2008:      	fmul.4s	v30, v21, v30
    200c:      	fadd.4s	v30, v30, v8
    2010:      	fmul.4s	v30, v21, v30
    2014:      	ldr	q8, [sp, #0x180]
    2018:      	fadd.4s	v30, v30, v8
    201c:      	fmul.4s	v30, v21, v30
    2020:      	fadd.4s	v30, v30, v10
    2024:      	fmul.4s	v30, v21, v30
    2028:      	movi.4s	v8, #0x3f, lsl #24
    202c:      	fadd.4s	v30, v30, v8
    2030:      	fmul.4s	v8, v21, v21
    2034:      	fmul.4s	v30, v8, v30
    2038:      	fadd.4s	v21, v21, v30
    203c:      	fadd.4s	v21, v21, v0
    2040:      	movi.2d	v30, #0xffffffffffffffff
    2044:      	add.4s	v30, v31, v30
    2048:      	sshr.4s	v31, v30, #0x1
    204c:      	shl.4s	v8, v31, #0x17
    2050:      	add.4s	v8, v8, v0
    2054:      	fmul.4s	v21, v21, v8
    2058:      	sub.4s	v30, v30, v31
    205c:      	shl.4s	v30, v30, #0x17
    2060:      	add.4s	v30, v30, v0
    2064:      	fmul.4s	v21, v21, v30
    2068:      	fcmgt.4s	v28, v28, v9
    206c:      	ldr	q30, [sp, #0x1a0]
    2070:      	bit.16b	v21, v30, v28
    2074:      	mov.16b	v31, v22
    2078:      	fdiv.4s	v28, v22, v21
    207c:      	fsub.4s	v30, v21, v28
    2080:      	fadd.4s	v21, v21, v28
    2084:      	fdiv.4s	v21, v30, v21
    2088:      	bif.16b	v21, v0, v23
    208c:      	fcmge.4s	v18, v0, v18
    2090:      	bsl.16b	v18, v19, v21
    2094:      	movi.4s	v10, #0x3f, lsl #24
    2098:      	mvni.4s	v19, #0x80, lsl #24
    209c:      	bif.16b	v18, v17, v19
    20a0:      	fcmeq.4s	v17, v17, v17
    20a4:      	fadd.4s	v18, v18, v0
    20a8:      	ldr	q19, [sp, #0x190]
    20ac:      	bsl.16b	v17, v18, v19
    20b0:      	fmul.4s	v16, v16, v10
    20b4:      	fmul.4s	v16, v16, v17
    20b8:      	and.16b	v7, v11, v7
    20bc:      	fadd.4s	v7, v7, v16
    20c0:      	tbz	w13, #0x4, 0x20f8 <_llm_rows.packet_batch.blocks+0x122c>
    20c4:      	str	s7, [x12, #0x10]
    20c8:      	mov.16b	v11, v14
    20cc:      	tbnz	w13, #0x5, 0x2100 <_llm_rows.packet_batch.blocks+0x1234>
    20d0:      	mov.16b	v8, v20
    20d4:      	mov.16b	v30, v15
    20d8:      	mov.16b	v14, v29
    20dc:      	tbz	w13, #0x6, 0x2118 <_llm_rows.packet_batch.blocks+0x124c>
    20e0:      	add	x14, x12, #0x18
    20e4:      	st1.s	{ v7 }[2], [x14]
    20e8:      	mov.16b	v15, v1
    20ec:      	mov.16b	v29, v26
    20f0:      	tbz	w13, #0x7, 0x1ce0 <_llm_rows.packet_batch.blocks+0xe14>
    20f4:      	b	0x2124 <_llm_rows.packet_batch.blocks+0x1258>
    20f8:      	mov.16b	v11, v14
    20fc:      	tbz	w13, #0x5, 0x20d0 <_llm_rows.packet_batch.blocks+0x1204>
    2100:      	add	x14, x12, #0x14
    2104:      	st1.s	{ v7 }[1], [x14]
    2108:      	mov.16b	v8, v20
    210c:      	mov.16b	v30, v15
    2110:      	mov.16b	v14, v29
    2114:      	tbnz	w13, #0x6, 0x20e0 <_llm_rows.packet_batch.blocks+0x1214>
    2118:      	mov.16b	v15, v1
    211c:      	mov.16b	v29, v26
    2120:      	tbz	w13, #0x7, 0x1ce0 <_llm_rows.packet_batch.blocks+0xe14>
    2124:      	add	x12, x12, #0x1c
    2128:      	st1.s	{ v7 }[3], [x12]
    212c:      	b	0x1ce0 <_llm_rows.packet_batch.blocks+0xe14>
    2130:      	tbz	w13, #0x1, 0x1c2c <_llm_rows.packet_batch.blocks+0xd60>
    2134:      	add	x14, x9, #0x4
    2138:      	ld1.s	{ v16 }[1], [x14]
    213c:      	tbnz	w13, #0x2, 0x1c30 <_llm_rows.packet_batch.blocks+0xd64>
    2140:      	tbz	w13, #0x3, 0x1c3c <_llm_rows.packet_batch.blocks+0xd70>
    2144:      	add	x14, x9, #0xc
    2148:      	ld1.s	{ v16 }[3], [x14]
    214c:      	tbnz	w13, #0x4, 0x1c40 <_llm_rows.packet_batch.blocks+0xd74>
    2150:      	tbz	w13, #0x5, 0x1c4c <_llm_rows.packet_batch.blocks+0xd80>
    2154:      	add	x14, x9, #0x14
    2158:      	ld1.s	{ v7 }[1], [x14]
    215c:      	stp	q9, q21, [sp, #0x130]
    2160:      	tbnz	w13, #0x6, 0x1c54 <_llm_rows.packet_batch.blocks+0xd88>
    2164:      	b	0x1c5c <_llm_rows.packet_batch.blocks+0xd90>
    2168:      	ldp	q2, q4, [sp, #0x1c0]
    216c:      	ldr	q20, [sp, #0xd0]
    2170:      	fmul.4s	v2, v20, v2
    2174:      	fmul.4s	v2, v20, v2
    2178:      	fmul.4s	v2, v20, v2
    217c:      	fadd.4s	v2, v20, v2
    2180:      	fmul.4s	v2, v2, v4
    2184:      	ldr	q4, [sp, #0x100]
    2188:      	zip1.8b	v4, v4, v0
    218c:      	ushll.4s	v4, v4, #0x0
    2190:      	shl.4s	v4, v4, #0x1f
    2194:      	cmlt.4s	v4, v4, #0
    2198:      	and.16b	v2, v4, v2
    219c:      	fabs.4s	v4, v2
    21a0:      	fmul.4s	v5, v2, v2
    21a4:      	ldp	q7, q6, [sp, #0x1e0]
    21a8:      	fmla.4s	v6, v5, v7
    21ac:      	ldr	q7, [sp, #0x200]
    21b0:      	fmla.4s	v7, v5, v6
    21b4:      	ldr	q6, [sp, #0x210]
    21b8:      	fmla.4s	v6, v5, v7
    21bc:      	ldr	q7, [sp, #0x220]
    21c0:      	fmla.4s	v7, v5, v6
    21c4:      	ldr	q3, [sp, #0x1b0]
    21c8:      	mov.16b	v6, v3
    21cc:      	fmla.4s	v6, v5, v7
    21d0:      	mov.16b	v7, v0
    21d4:      	fmla.4s	v7, v5, v6
    21d8:      	fmul.4s	v6, v4, v7
    21dc:      	ldp	q7, q16, [sp, #0x230]
    21e0:      	fmla.4s	v7, v5, v16
    21e4:      	ldr	q16, [sp, #0x250]
    21e8:      	fmla.4s	v16, v5, v7
    21ec:      	ldr	q7, [sp, #0x260]
    21f0:      	fmla.4s	v7, v5, v16
    21f4:      	mov.16b	v16, v12
    21f8:      	fmla.4s	v16, v5, v7
    21fc:      	movi.4s	v7, #0x3f, lsl #24
    2200:      	fmla.4s	v7, v5, v16
    2204:      	mov.16b	v16, v0
    2208:      	fmla.4s	v16, v5, v7
    220c:      	fdiv.4s	v5, v6, v16
    2210:      	fcmge.4s	v6, v13, v4
    2214:      	and.16b	v7, v6, v4
    2218:      	fcmge.4s	v16, v7, v30
    221c:      	fcmge.4s	v17, v9, v7
    2220:      	and.16b	v16, v16, v17
    2224:      	and.16b	v16, v16, v7
    2228:      	fmul.4s	v17, v16, v27
    222c:      	movi.4s	v18, #0x4b, lsl #24
    2230:      	fadd.4s	v17, v17, v18
    2234:      	movi.4s	v18, #0xcb, lsl #24
    2238:      	fadd.4s	v17, v17, v18
    223c:      	fcvtzs.4s	v17, v17
    2240:      	scvtf.4s	v18, v17
    2244:      	fmul.4s	v19, v18, v8
    2248:      	fadd.4s	v16, v16, v19
    224c:      	mov.16b	v22, v25
    2250:      	fmul.4s	v18, v18, v25
    2254:      	fadd.4s	v16, v16, v18
    2258:      	fmul.4s	v18, v16, v24
    225c:      	ldp	q29, q26, [sp, #0x160]
    2260:      	fadd.4s	v18, v18, v29
    2264:      	fmul.4s	v18, v16, v18
    2268:      	fadd.4s	v18, v18, v26
    226c:      	fmul.4s	v18, v16, v18
    2270:      	ldr	q25, [sp, #0x180]
    2274:      	fadd.4s	v18, v18, v25
    2278:      	fmul.4s	v18, v16, v18
    227c:      	fadd.4s	v18, v18, v3
    2280:      	fmul.4s	v18, v16, v18
    2284:      	fadd.4s	v18, v18, v10
    2288:      	fmul.4s	v19, v16, v16
    228c:      	fmul.4s	v18, v19, v18
    2290:      	fadd.4s	v16, v16, v18
    2294:      	fadd.4s	v16, v16, v0
    2298:      	movi.2d	v18, #0xffffffffffffffff
    229c:      	add.4s	v17, v17, v18
    22a0:      	sshr.4s	v18, v17, #0x1
    22a4:      	shl.4s	v19, v18, #0x17
    22a8:      	add.4s	v19, v19, v0
    22ac:      	fmul.4s	v16, v16, v19
    22b0:      	sub.4s	v17, v17, v18
    22b4:      	shl.4s	v17, v17, #0x17
    22b8:      	add.4s	v17, v17, v0
    22bc:      	fmul.4s	v16, v16, v17
    22c0:      	fcmgt.4s	v7, v7, v9
    22c4:      	ldr	q17, [sp, #0x1a0]
    22c8:      	bsl.16b	v7, v17, v16
    22cc:      	fdiv.4s	v16, v31, v7
    22d0:      	fsub.4s	v17, v7, v16
    22d4:      	fadd.4s	v7, v7, v16
    22d8:      	fdiv.4s	v7, v17, v7
    22dc:      	bsl.16b	v6, v7, v0
    22e0:      	fcmge.4s	v4, v0, v4
    22e4:      	bsl.16b	v4, v5, v6
    22e8:      	ldr	d3, [sp, #0x8]
    22ec:      	fmov	w9, s3
    22f0:      	mvni.4s	v5, #0x80, lsl #24
    22f4:      	bif.16b	v4, v2, v5
    22f8:      	fcmeq.4s	v2, v2, v2
    22fc:      	fadd.4s	v4, v4, v0
    2300:      	ldr	q5, [sp, #0x190]
    2304:      	bsl.16b	v2, v4, v5
    2308:      	fmul.4s	v4, v20, v10
    230c:      	fmul.4s	v2, v4, v2
    2310:      	ldr	q3, [sp, #0x10]
    2314:      	fadd.4s	v2, v2, v3
    2318:      	ldp	q1, q4, [sp, #0xb0]
    231c:      	stp	q1, q4, [sp, #0x300]
    2320:      	ldr	q1, [sp, #0xa0]
    2324:      	ldr	q4, [sp, #0x30]
    2328:      	stp	q1, q4, [sp, #0x320]
    232c:      	and	x11, x10, #0x7
    2330:      	add	x12, sp, #0x300
    2334:      	ldr	x11, [x12, x11, lsl #3]
    2338:      	sub	x10, x11, x10
    233c:      	add	x8, x8, x10, lsl #2
    2340:      	tbz	w9, #0x0, 0x2360 <_llm_rows.packet_batch.blocks+0x1494>
    2344:      	str	s2, [x8]
    2348:      	tbnz	w9, #0x1, 0x2364 <_llm_rows.packet_batch.blocks+0x1498>
    234c:      	tbz	w9, #0x2, 0x2370 <_llm_rows.packet_batch.blocks+0x14a4>
    2350:      	add	x10, x8, #0x8
    2354:      	st1.s	{ v2 }[2], [x10]
    2358:      	tbnz	w9, #0x3, 0x2374 <_llm_rows.packet_batch.blocks+0x14a8>
    235c:      	b	0x237c <_llm_rows.packet_batch.blocks+0x14b0>
    2360:      	tbz	w9, #0x1, 0x234c <_llm_rows.packet_batch.blocks+0x1480>
    2364:      	add	x10, x8, #0x4
    2368:      	st1.s	{ v2 }[1], [x10]
    236c:      	tbnz	w9, #0x2, 0x2350 <_llm_rows.packet_batch.blocks+0x1484>
    2370:      	tbz	w9, #0x3, 0x237c <_llm_rows.packet_batch.blocks+0x14b0>
    2374:      	add	x10, x8, #0xc
    2378:      	st1.s	{ v2 }[3], [x10]
    237c:      	ldp	q2, q4, [sp, #0x1c0]
    2380:      	ldr	q20, [sp, #0xe0]
    2384:      	fmul.4s	v2, v20, v2
    2388:      	fmul.4s	v2, v20, v2
    238c:      	fmul.4s	v2, v20, v2
    2390:      	fadd.4s	v2, v20, v2
    2394:      	fmul.4s	v2, v2, v4
    2398:      	ldr	q4, [sp, #0x100]
    239c:      	zip2.8b	v4, v4, v0
    23a0:      	ushll.4s	v4, v4, #0x0
    23a4:      	shl.4s	v4, v4, #0x1f
    23a8:      	cmlt.4s	v4, v4, #0
    23ac:      	and.16b	v2, v4, v2
    23b0:      	fmul.4s	v4, v2, v2
    23b4:      	ldp	q6, q5, [sp, #0x1e0]
    23b8:      	fmla.4s	v5, v4, v6
    23bc:      	ldr	q6, [sp, #0x200]
    23c0:      	fmla.4s	v6, v4, v5
    23c4:      	ldr	q5, [sp, #0x210]
    23c8:      	fmla.4s	v5, v4, v6
    23cc:      	ldp	q6, q16, [sp, #0x220]
    23d0:      	fmla.4s	v6, v4, v5
    23d4:      	ldr	q3, [sp, #0x1b0]
    23d8:      	mov.16b	v5, v3
    23dc:      	fmla.4s	v5, v4, v6
    23e0:      	mov.16b	v6, v0
    23e4:      	fmla.4s	v6, v4, v5
    23e8:      	ldp	q5, q7, [sp, #0x240]
    23ec:      	fmla.4s	v16, v4, v5
    23f0:      	fmla.4s	v7, v4, v16
    23f4:      	ldr	q5, [sp, #0x260]
    23f8:      	fmla.4s	v5, v4, v7
    23fc:      	fmla.4s	v12, v4, v5
    2400:      	movi.4s	v5, #0x3f, lsl #24
    2404:      	fmla.4s	v5, v4, v12
    2408:      	mov.16b	v7, v0
    240c:      	fmla.4s	v7, v4, v5
    2410:      	fabs.4s	v4, v2
    2414:      	fmul.4s	v5, v4, v6
    2418:      	fdiv.4s	v5, v5, v7
    241c:      	fcmge.4s	v6, v13, v4
    2420:      	and.16b	v7, v6, v4
    2424:      	fcmge.4s	v16, v7, v30
    2428:      	fcmge.4s	v17, v9, v7
    242c:      	and.16b	v16, v16, v17
    2430:      	and.16b	v16, v16, v7
    2434:      	fmul.4s	v17, v16, v27
    2438:      	movi.4s	v18, #0x4b, lsl #24
    243c:      	fadd.4s	v17, v17, v18
    2440:      	movi.4s	v18, #0xcb, lsl #24
    2444:      	fadd.4s	v17, v17, v18
    2448:      	fcvtzs.4s	v17, v17
    244c:      	scvtf.4s	v18, v17
    2450:      	fmul.4s	v19, v18, v8
    2454:      	fadd.4s	v16, v16, v19
    2458:      	fmul.4s	v18, v18, v22
    245c:      	fadd.4s	v16, v16, v18
    2460:      	fmul.4s	v18, v16, v24
    2464:      	fadd.4s	v18, v18, v29
    2468:      	fmul.4s	v18, v16, v18
    246c:      	fadd.4s	v18, v18, v26
    2470:      	fmul.4s	v18, v16, v18
    2474:      	fadd.4s	v18, v18, v25
    2478:      	fmul.4s	v18, v16, v18
    247c:      	fadd.4s	v3, v18, v3
    2480:      	fmul.4s	v3, v16, v3
    2484:      	fadd.4s	v3, v3, v10
    2488:      	fmul.4s	v18, v16, v16
    248c:      	fmul.4s	v3, v18, v3
    2490:      	fadd.4s	v3, v16, v3
    2494:      	fadd.4s	v3, v3, v0
    2498:      	movi.2d	v16, #0xffffffffffffffff
    249c:      	add.4s	v16, v17, v16
    24a0:      	sshr.4s	v17, v16, #0x1
    24a4:      	shl.4s	v18, v17, #0x17
    24a8:      	add.4s	v18, v18, v0
    24ac:      	fmul.4s	v3, v3, v18
    24b0:      	sub.4s	v16, v16, v17
    24b4:      	shl.4s	v16, v16, #0x17
    24b8:      	add.4s	v16, v16, v0
    24bc:      	fmul.4s	v3, v3, v16
    24c0:      	fcmgt.4s	v1, v7, v9
    24c4:      	ldr	q7, [sp, #0x1a0]
    24c8:      	bsl.16b	v1, v7, v3
    24cc:      	fdiv.4s	v3, v31, v1
    24d0:      	fsub.4s	v7, v1, v3
    24d4:      	fadd.4s	v1, v1, v3
    24d8:      	fdiv.4s	v1, v7, v1
    24dc:      	bif.16b	v1, v0, v6
    24e0:      	fcmge.4s	v3, v0, v4
    24e4:      	bit.16b	v1, v5, v3
    24e8:      	mvni.4s	v3, #0x80, lsl #24
    24ec:      	bif.16b	v1, v2, v3
    24f0:      	fadd.4s	v0, v1, v0
    24f4:      	fcmeq.4s	v1, v2, v2
    24f8:      	ldr	q2, [sp, #0x190]
    24fc:      	bif.16b	v0, v2, v1
    2500:      	fmul.4s	v1, v20, v10
    2504:      	fmul.4s	v0, v1, v0
    2508:      	ldr	q1, [sp, #0x20]
    250c:      	fadd.4s	v0, v0, v1
    2510:      	tbz	w9, #0x4, 0x2aac <_llm_rows.packet_batch.blocks+0x1be0>
    2514:      	str	s0, [x8, #0x10]
    2518:      	tbnz	w9, #0x5, 0x2ab0 <_llm_rows.packet_batch.blocks+0x1be4>
    251c:      	tbz	w9, #0x6, 0x2abc <_llm_rows.packet_batch.blocks+0x1bf0>
    2520:      	add	x10, x8, #0x18
    2524:      	st1.s	{ v0 }[2], [x10]
    2528:      	tbnz	w9, #0x7, 0x2ac0 <_llm_rows.packet_batch.blocks+0x1bf4>
    252c:      	b	0xfa4 <_llm_rows.packet_batch.blocks+0xd8>
    2530:      	ldr	d2, [sp, #0x100]
    2534:      	uzp1.8b	v4, v2, v0
    2538:      	movi.2d	v21, #0000000000000000
    253c:      	mov.b	v21[0], v4[0]
    2540:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x1134>
    2544:      	ldr	d2, [x10]
    2548:      	and.8b	v5, v21, v2
    254c:      	addv.8b	b5, v5
    2550:      	fmov	w12, s5
    2554:      	umaxv.8b	b5, v21
    2558:      	fmov	w14, s5
    255c:      	rbit	w10, w12
    2560:      	clz	w10, w10
    2564:      	tst	w14, #0x1
    2568:      	csel	w10, w10, wzr, ne
    256c:      	mov	w13, #0x1000            ; =4096
    2570:      	dup.2d	v12, x13
    2574:      	ldr	d5, [sp, #0x120]
    2578:      	ldr	q6, [sp, #0xb0]
    257c:      	ldr	d7, [sp, #0xa0]
    2580:      	umlal.2d	v6, v7, v5
    2584:      	movi.2d	v5, #0000000000000000
    2588:      	mov.b	v5[0], v4[0]
    258c:      	add.2d	v3, v6, v12
    2590:      	ushll.2d	v4, v5, #0x0
    2594:      	shl.2d	v4, v4, #0x3f
    2598:      	cmlt.2d	v4, v4, #0
    259c:      	str	q3, [sp, #0x100]
    25a0:      	and.16b	v4, v4, v3
    25a4:      	movi.2d	v5, #0000000000000000
    25a8:      	stp	q5, q5, [sp, #0x2d0]
    25ac:      	stp	q4, q5, [sp, #0x2b0]
    25b0:      	and	x13, x10, #0x7
    25b4:      	add	x15, sp, #0x2b0
    25b8:      	ldr	x13, [x15, x13, lsl #3]
    25bc:      	sub	x13, x13, x10
    25c0:      	lsl	x13, x13, #2
    25c4:      	add	x11, x11, x13
    25c8:      	movi.2d	v15, #0000000000000000
    25cc:      	movi.2d	v9, #0000000000000000
    25d0:      	tbz	w14, #0x0, 0x2610 <_llm_rows.packet_batch.blocks+0x1744>
    25d4:      	ldr	s15, [x11]
    25d8:      	tbnz	w12, #0x1, 0x2614 <_llm_rows.packet_batch.blocks+0x1748>
    25dc:      	tbz	w12, #0x2, 0x2620 <_llm_rows.packet_batch.blocks+0x1754>
    25e0:      	add	x14, x11, #0x8
    25e4:      	ld1.s	{ v15 }[2], [x14]
    25e8:      	tbnz	w12, #0x3, 0x2624 <_llm_rows.packet_batch.blocks+0x1758>
    25ec:      	tbz	w12, #0x4, 0x2630 <_llm_rows.packet_batch.blocks+0x1764>
    25f0:      	add	x14, x11, #0x10
    25f4:      	ld1.s	{ v9 }[0], [x14]
    25f8:      	tbnz	w12, #0x5, 0x2634 <_llm_rows.packet_batch.blocks+0x1768>
    25fc:      	tbz	w12, #0x6, 0x2640 <_llm_rows.packet_batch.blocks+0x1774>
    2600:      	add	x14, x11, #0x18
    2604:      	ld1.s	{ v9 }[2], [x14]
    2608:      	tbnz	w12, #0x7, 0x2644 <_llm_rows.packet_batch.blocks+0x1778>
    260c:      	b	0x264c <_llm_rows.packet_batch.blocks+0x1780>
    2610:      	tbz	w12, #0x1, 0x25dc <_llm_rows.packet_batch.blocks+0x1710>
    2614:      	add	x14, x11, #0x4
    2618:      	ld1.s	{ v15 }[1], [x14]
    261c:      	tbnz	w12, #0x2, 0x25e0 <_llm_rows.packet_batch.blocks+0x1714>
    2620:      	tbz	w12, #0x3, 0x25ec <_llm_rows.packet_batch.blocks+0x1720>
    2624:      	add	x14, x11, #0xc
    2628:      	ld1.s	{ v15 }[3], [x14]
    262c:      	tbnz	w12, #0x4, 0x25f0 <_llm_rows.packet_batch.blocks+0x1724>
    2630:      	tbz	w12, #0x5, 0x25fc <_llm_rows.packet_batch.blocks+0x1730>
    2634:      	add	x14, x11, #0x14
    2638:      	ld1.s	{ v9 }[1], [x14]
    263c:      	tbnz	w12, #0x6, 0x2600 <_llm_rows.packet_batch.blocks+0x1734>
    2640:      	tbz	w12, #0x7, 0x264c <_llm_rows.packet_batch.blocks+0x1780>
    2644:      	add	x11, x11, #0x1c
    2648:      	ld1.s	{ v9 }[3], [x11]
    264c:      	shl.8b	v4, v21, #0x7
    2650:      	cmlt.8b	v4, v4, #0
    2654:      	and.8b	v2, v4, v2
    2658:      	addv.8b	b2, v2
    265c:      	str	d2, [sp, #0xb0]
    2660:      	fmov	w11, s2
    2664:      	add	x9, x9, x13
    2668:      	movi.2d	v4, #0000000000000000
    266c:      	movi.2d	v13, #0000000000000000
    2670:      	tbz	w11, #0x0, 0x28d0 <_llm_rows.packet_batch.blocks+0x1a04>
    2674:      	ldr	s4, [x9]
    2678:      	tbnz	w11, #0x1, 0x28d4 <_llm_rows.packet_batch.blocks+0x1a08>
    267c:      	tbz	w11, #0x2, 0x28e0 <_llm_rows.packet_batch.blocks+0x1a14>
    2680:      	add	x12, x9, #0x8
    2684:      	ld1.s	{ v4 }[2], [x12]
    2688:      	tbnz	w11, #0x3, 0x28e4 <_llm_rows.packet_batch.blocks+0x1a18>
    268c:      	tbz	w11, #0x4, 0x28f0 <_llm_rows.packet_batch.blocks+0x1a24>
    2690:      	add	x12, x9, #0x10
    2694:      	ld1.s	{ v13 }[0], [x12]
    2698:      	tbnz	w11, #0x5, 0x28f4 <_llm_rows.packet_batch.blocks+0x1a28>
    269c:      	tbz	w11, #0x6, 0x26a8 <_llm_rows.packet_batch.blocks+0x17dc>
    26a0:      	add	x12, x9, #0x18
    26a4:      	ld1.s	{ v13 }[2], [x12]
    26a8:      	ldr	q2, [sp, #0x130]
    26ac:      	ldr	d6, [sp, #0x120]
    26b0:      	ldr	d5, [sp, #0xc0]
    26b4:      	umlal.2d	v2, v5, v6
    26b8:      	str	q2, [sp, #0x130]
    26bc:      	ldr	q2, [sp, #0x140]
    26c0:      	ldr	d5, [sp, #0xd0]
    26c4:      	umlal.2d	v2, v5, v6
    26c8:      	str	q2, [sp, #0x140]
    26cc:      	ldr	d2, [sp, #0xe0]
    26d0:      	umlal.2d	v29, v2, v6
    26d4:      	mov.16b	v2, v29
    26d8:      	tbz	w11, #0x7, 0x26e4 <_llm_rows.packet_batch.blocks+0x1818>
    26dc:      	add	x9, x9, #0x1c
    26e0:      	ld1.s	{ v13 }[3], [x9]
    26e4:      	ldp	q5, q6, [sp, #0x1c0]
    26e8:      	fmul.4s	v5, v15, v5
    26ec:      	fmul.4s	v5, v15, v5
    26f0:      	fmul.4s	v5, v15, v5
    26f4:      	fadd.4s	v5, v15, v5
    26f8:      	fmul.4s	v5, v5, v6
    26fc:      	zip1.8b	v6, v21, v0
    2700:      	ushll.4s	v6, v6, #0x0
    2704:      	shl.4s	v6, v6, #0x1f
    2708:      	cmlt.4s	v6, v6, #0
    270c:      	and.16b	v5, v6, v5
    2710:      	fabs.4s	v6, v5
    2714:      	fmul.4s	v7, v5, v5
    2718:      	ldp	q17, q16, [sp, #0x1e0]
    271c:      	fmla.4s	v16, v7, v17
    2720:      	ldr	q17, [sp, #0x200]
    2724:      	fmla.4s	v17, v7, v16
    2728:      	ldr	q16, [sp, #0x210]
    272c:      	fmla.4s	v16, v7, v17
    2730:      	ldr	q17, [sp, #0x220]
    2734:      	fmla.4s	v17, v7, v16
    2738:      	ldr	q3, [sp, #0x1b0]
    273c:      	mov.16b	v16, v3
    2740:      	fmla.4s	v16, v7, v17
    2744:      	mov.16b	v17, v0
    2748:      	fmla.4s	v17, v7, v16
    274c:      	fmul.4s	v16, v6, v17
    2750:      	ldp	q17, q18, [sp, #0x230]
    2754:      	fmla.4s	v17, v7, v18
    2758:      	ldr	q18, [sp, #0x250]
    275c:      	fmla.4s	v18, v7, v17
    2760:      	ldr	q17, [sp, #0x260]
    2764:      	fmla.4s	v17, v7, v18
    2768:      	mov.16b	v29, v23
    276c:      	mov.16b	v18, v23
    2770:      	fmla.4s	v18, v7, v17
    2774:      	movi.4s	v17, #0x3f, lsl #24
    2778:      	fmla.4s	v17, v7, v18
    277c:      	mov.16b	v18, v0
    2780:      	fmla.4s	v18, v7, v17
    2784:      	fdiv.4s	v7, v16, v18
    2788:      	fcmge.4s	v16, v28, v6
    278c:      	and.16b	v17, v16, v6
    2790:      	fcmge.4s	v18, v17, v30
    2794:      	fcmge.4s	v19, v1, v17
    2798:      	and.16b	v18, v18, v19
    279c:      	and.16b	v18, v18, v17
    27a0:      	fmul.4s	v19, v18, v27
    27a4:      	movi.4s	v23, #0x4b, lsl #24
    27a8:      	fadd.4s	v19, v19, v23
    27ac:      	movi.4s	v23, #0xcb, lsl #24
    27b0:      	fadd.4s	v19, v19, v23
    27b4:      	fcvtzs.4s	v19, v19
    27b8:      	scvtf.4s	v14, v19
    27bc:      	fmul.4s	v11, v14, v8
    27c0:      	fadd.4s	v18, v18, v11
    27c4:      	fmul.4s	v11, v14, v25
    27c8:      	fadd.4s	v18, v18, v11
    27cc:      	fmul.4s	v11, v18, v26
    27d0:      	fadd.4s	v11, v11, v20
    27d4:      	fmul.4s	v11, v18, v11
    27d8:      	fadd.4s	v11, v11, v22
    27dc:      	fmul.4s	v11, v18, v11
    27e0:      	fadd.4s	v11, v11, v24
    27e4:      	fmul.4s	v11, v18, v11
    27e8:      	fadd.4s	v11, v11, v3
    27ec:      	fmul.4s	v11, v18, v11
    27f0:      	fadd.4s	v11, v11, v10
    27f4:      	fmul.4s	v14, v18, v18
    27f8:      	fmul.4s	v11, v14, v11
    27fc:      	fadd.4s	v18, v18, v11
    2800:      	fadd.4s	v18, v18, v0
    2804:      	movi.2d	v23, #0xffffffffffffffff
    2808:      	add.4s	v19, v19, v23
    280c:      	sshr.4s	v11, v19, #0x1
    2810:      	shl.4s	v14, v11, #0x17
    2814:      	add.4s	v14, v14, v0
    2818:      	fmul.4s	v18, v18, v14
    281c:      	sub.4s	v19, v19, v11
    2820:      	shl.4s	v19, v19, #0x17
    2824:      	add.4s	v19, v19, v0
    2828:      	fmul.4s	v18, v18, v19
    282c:      	fcmgt.4s	v17, v17, v1
    2830:      	ldr	q19, [sp, #0x1a0]
    2834:      	bsl.16b	v17, v19, v18
    2838:      	fdiv.4s	v18, v31, v17
    283c:      	fsub.4s	v19, v17, v18
    2840:      	fadd.4s	v17, v17, v18
    2844:      	fdiv.4s	v17, v19, v17
    2848:      	bsl.16b	v16, v17, v0
    284c:      	fcmge.4s	v6, v0, v6
    2850:      	bsl.16b	v6, v7, v16
    2854:      	ldp	q7, q16, [sp, #0x130]
    2858:      	add.2d	v7, v7, v12
    285c:      	add.2d	v16, v16, v12
    2860:      	add.2d	v17, v2, v12
    2864:      	mvni.4s	v18, #0x80, lsl #24
    2868:      	bif.16b	v6, v5, v18
    286c:      	fcmeq.4s	v5, v5, v5
    2870:      	fadd.4s	v6, v6, v0
    2874:      	ldr	q18, [sp, #0x190]
    2878:      	bsl.16b	v5, v6, v18
    287c:      	fmul.4s	v6, v15, v10
    2880:      	fmul.4s	v5, v6, v5
    2884:      	fadd.4s	v4, v4, v5
    2888:      	ldr	q2, [sp, #0x100]
    288c:      	stp	q2, q7, [sp, #0x270]
    2890:      	stp	q16, q17, [sp, #0x290]
    2894:      	ldr	d2, [sp, #0xb0]
    2898:      	fmov	w9, s2
    289c:      	and	x11, x10, #0x7
    28a0:      	add	x12, sp, #0x270
    28a4:      	ldr	x11, [x12, x11, lsl #3]
    28a8:      	sub	x10, x11, x10
    28ac:      	add	x8, x8, x10, lsl #2
    28b0:      	tbz	w9, #0x0, 0x2904 <_llm_rows.packet_batch.blocks+0x1a38>
    28b4:      	str	s4, [x8]
    28b8:      	tbnz	w9, #0x1, 0x2908 <_llm_rows.packet_batch.blocks+0x1a3c>
    28bc:      	tbz	w9, #0x2, 0x2914 <_llm_rows.packet_batch.blocks+0x1a48>
    28c0:      	add	x10, x8, #0x8
    28c4:      	st1.s	{ v4 }[2], [x10]
    28c8:      	tbnz	w9, #0x3, 0x2918 <_llm_rows.packet_batch.blocks+0x1a4c>
    28cc:      	b	0x2920 <_llm_rows.packet_batch.blocks+0x1a54>
    28d0:      	tbz	w11, #0x1, 0x267c <_llm_rows.packet_batch.blocks+0x17b0>
    28d4:      	add	x12, x9, #0x4
    28d8:      	ld1.s	{ v4 }[1], [x12]
    28dc:      	tbnz	w11, #0x2, 0x2680 <_llm_rows.packet_batch.blocks+0x17b4>
    28e0:      	tbz	w11, #0x3, 0x268c <_llm_rows.packet_batch.blocks+0x17c0>
    28e4:      	add	x12, x9, #0xc
    28e8:      	ld1.s	{ v4 }[3], [x12]
    28ec:      	tbnz	w11, #0x4, 0x2690 <_llm_rows.packet_batch.blocks+0x17c4>
    28f0:      	tbz	w11, #0x5, 0x269c <_llm_rows.packet_batch.blocks+0x17d0>
    28f4:      	add	x12, x9, #0x14
    28f8:      	ld1.s	{ v13 }[1], [x12]
    28fc:      	tbnz	w11, #0x6, 0x26a0 <_llm_rows.packet_batch.blocks+0x17d4>
    2900:      	b	0x26a8 <_llm_rows.packet_batch.blocks+0x17dc>
    2904:      	tbz	w9, #0x1, 0x28bc <_llm_rows.packet_batch.blocks+0x19f0>
    2908:      	add	x10, x8, #0x4
    290c:      	st1.s	{ v4 }[1], [x10]
    2910:      	tbnz	w9, #0x2, 0x28c0 <_llm_rows.packet_batch.blocks+0x19f4>
    2914:      	tbz	w9, #0x3, 0x2920 <_llm_rows.packet_batch.blocks+0x1a54>
    2918:      	add	x10, x8, #0xc
    291c:      	st1.s	{ v4 }[3], [x10]
    2920:      	ldp	q2, q4, [sp, #0x1c0]
    2924:      	fmul.4s	v2, v9, v2
    2928:      	fmul.4s	v2, v9, v2
    292c:      	fmul.4s	v2, v9, v2
    2930:      	fadd.4s	v2, v9, v2
    2934:      	fmul.4s	v2, v2, v4
    2938:      	zip2.8b	v4, v21, v0
    293c:      	ushll.4s	v4, v4, #0x0
    2940:      	shl.4s	v4, v4, #0x1f
    2944:      	cmlt.4s	v4, v4, #0
    2948:      	and.16b	v2, v4, v2
    294c:      	fmul.4s	v4, v2, v2
    2950:      	ldp	q6, q5, [sp, #0x1e0]
    2954:      	fmla.4s	v5, v4, v6
    2958:      	ldr	q6, [sp, #0x200]
    295c:      	fmla.4s	v6, v4, v5
    2960:      	ldr	q5, [sp, #0x210]
    2964:      	fmla.4s	v5, v4, v6
    2968:      	ldp	q6, q16, [sp, #0x220]
    296c:      	fmla.4s	v6, v4, v5
    2970:      	ldr	q3, [sp, #0x1b0]
    2974:      	mov.16b	v5, v3
    2978:      	fmla.4s	v5, v4, v6
    297c:      	mov.16b	v6, v0
    2980:      	fmla.4s	v6, v4, v5
    2984:      	ldp	q5, q7, [sp, #0x240]
    2988:      	fmla.4s	v16, v4, v5
    298c:      	fmla.4s	v7, v4, v16
    2990:      	ldr	q5, [sp, #0x260]
    2994:      	fmla.4s	v5, v4, v7
    2998:      	fmla.4s	v29, v4, v5
    299c:      	movi.4s	v5, #0x3f, lsl #24
    29a0:      	fmla.4s	v5, v4, v29
    29a4:      	mov.16b	v7, v0
    29a8:      	fmla.4s	v7, v4, v5
    29ac:      	fabs.4s	v4, v2
    29b0:      	fmul.4s	v5, v4, v6
    29b4:      	fdiv.4s	v5, v5, v7
    29b8:      	fcmge.4s	v6, v28, v4
    29bc:      	and.16b	v7, v6, v4
    29c0:      	fcmge.4s	v16, v7, v30
    29c4:      	fcmge.4s	v17, v1, v7
    29c8:      	and.16b	v16, v16, v17
    29cc:      	and.16b	v16, v16, v7
    29d0:      	fmul.4s	v17, v16, v27
    29d4:      	movi.4s	v18, #0x4b, lsl #24
    29d8:      	fadd.4s	v17, v17, v18
    29dc:      	movi.4s	v18, #0xcb, lsl #24
    29e0:      	fadd.4s	v17, v17, v18
    29e4:      	fcvtzs.4s	v17, v17
    29e8:      	scvtf.4s	v18, v17
    29ec:      	fmul.4s	v19, v18, v8
    29f0:      	fadd.4s	v16, v16, v19
    29f4:      	fmul.4s	v18, v18, v25
    29f8:      	fadd.4s	v16, v16, v18
    29fc:      	fmul.4s	v18, v16, v26
    2a00:      	fadd.4s	v18, v18, v20
    2a04:      	fmul.4s	v18, v16, v18
    2a08:      	fadd.4s	v18, v18, v22
    2a0c:      	fmul.4s	v18, v16, v18
    2a10:      	fadd.4s	v18, v18, v24
    2a14:      	fmul.4s	v18, v16, v18
    2a18:      	fadd.4s	v3, v18, v3
    2a1c:      	fmul.4s	v3, v16, v3
    2a20:      	fadd.4s	v3, v3, v10
    2a24:      	fmul.4s	v18, v16, v16
    2a28:      	fmul.4s	v3, v18, v3
    2a2c:      	fadd.4s	v3, v16, v3
    2a30:      	fadd.4s	v3, v3, v0
    2a34:      	movi.2d	v16, #0xffffffffffffffff
    2a38:      	add.4s	v16, v17, v16
    2a3c:      	sshr.4s	v17, v16, #0x1
    2a40:      	shl.4s	v18, v17, #0x17
    2a44:      	add.4s	v18, v18, v0
    2a48:      	fmul.4s	v3, v3, v18
    2a4c:      	sub.4s	v16, v16, v17
    2a50:      	shl.4s	v16, v16, #0x17
    2a54:      	add.4s	v16, v16, v0
    2a58:      	fmul.4s	v3, v3, v16
    2a5c:      	fcmgt.4s	v1, v7, v1
    2a60:      	ldr	q7, [sp, #0x1a0]
    2a64:      	bsl.16b	v1, v7, v3
    2a68:      	fdiv.4s	v3, v31, v1
    2a6c:      	fsub.4s	v7, v1, v3
    2a70:      	fadd.4s	v1, v1, v3
    2a74:      	fdiv.4s	v1, v7, v1
    2a78:      	bif.16b	v1, v0, v6
    2a7c:      	fcmge.4s	v3, v0, v4
    2a80:      	bit.16b	v1, v5, v3
    2a84:      	mvni.4s	v3, #0x80, lsl #24
    2a88:      	bif.16b	v1, v2, v3
    2a8c:      	fadd.4s	v0, v1, v0
    2a90:      	fcmeq.4s	v1, v2, v2
    2a94:      	ldr	q2, [sp, #0x190]
    2a98:      	bif.16b	v0, v2, v1
    2a9c:      	fmul.4s	v1, v9, v10
    2aa0:      	fmul.4s	v0, v1, v0
    2aa4:      	fadd.4s	v0, v13, v0
    2aa8:      	tbnz	w9, #0x4, 0x2514 <_llm_rows.packet_batch.blocks+0x1648>
    2aac:      	tbz	w9, #0x5, 0x251c <_llm_rows.packet_batch.blocks+0x1650>
    2ab0:      	add	x10, x8, #0x14
    2ab4:      	st1.s	{ v0 }[1], [x10]
    2ab8:      	tbnz	w9, #0x6, 0x2520 <_llm_rows.packet_batch.blocks+0x1654>
    2abc:      	tbz	w9, #0x7, 0xfa4 <_llm_rows.packet_batch.blocks+0xd8>
    2ac0:      	add	x8, x8, #0x1c
    2ac4:      	st1.s	{ v0 }[3], [x8]
    2ac8:      	b	0xfa4 <_llm_rows.packet_batch.blocks+0xd8>
    2acc:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    2ad0:      	add	sp, sp, #0x420
    2ad4:      	ldp	x29, x30, [sp, #0x90]
    2ad8:      	ldp	x20, x19, [sp, #0x80]
    2adc:      	ldp	x22, x21, [sp, #0x70]
    2ae0:      	ldp	x24, x23, [sp, #0x60]
    2ae4:      	ldp	x26, x25, [sp, #0x50]
    2ae8:      	ldp	x28, x27, [sp, #0x40]
    2aec:      	ldp	d9, d8, [sp, #0x30]
    2af0:      	ldp	d11, d10, [sp, #0x20]
    2af4:      	ldp	d13, d12, [sp, #0x10]
    2af8:      	ldp	d15, d14, [sp], #0xa0
    2afc:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/projection-capture/gelu_residual-1024x4097/off/object/tile_xir_w8_38058_1788936545558723_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x90]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x24, x23, [sp, #0x50]
      18:      	stp	x22, x21, [sp, #0x60]
      1c:      	stp	x20, x19, [sp, #0x70]
      20:      	stp	x29, x30, [sp, #0x80]
      24:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      28:      	sub	sp, sp, #0x170
      2c:      	ldr	x22, [x0]
      30:      	ldr	x21, [x0, #0x10]
      34:      	ldr	x19, [x0, #0x30]
      38:      	ldr	w8, [x1]
      3c:      	ldr	w9, [x1, #0x24]
      40:      	add	w8, w9, w8, lsl #5
      44:      	lsr	w8, w8, #3
      48:      	dup.2s	v0, w8
      4c:      	ushll.2d	v0, v0, #0x0
      50:      	subs	x8, x22, x19
      54:      	mov	w9, #0xfff              ; =4095
      58:      	movk	w9, #0x100, lsl #16
      5c:      	ccmp	x8, x9, #0x0, hs
      60:      	cset	w8, hi
      64:      	subs	x10, x19, x22
      68:      	ccmp	x10, x9, #0x0, hs
      6c:      	csinc	w10, w8, wzr, ls
      70:      	subs	x8, x21, x19
      74:      	ccmp	x8, x9, #0x0, hs
      78:      	cset	w8, hi
      7c:      	subs	x11, x19, x21
      80:      	ccmp	x11, x9, #0x0, hs
      84:      	csinc	w9, w8, wzr, ls
      88:      	fmov	x8, d0
      8c:      	add	x8, x8, x8, lsl #12
      90:      	lsl	x8, x8, #2
      94:      	cmp	w10, #0x1
      98:      	ccmp	w9, #0x0, #0x4, eq
      9c:      	b.ne	0x7d4 <ltmp0+0x7d4>
      a0:      	add	x23, sp, #0x4, lsl #12  ; =0x4000
      a4:      	add	x23, x23, #0x150
      a8:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
      ac:      	add	x0, x0, #0x150
      b0:      	add	x1, x22, x8
      b4:      	mov	w2, #0x4000             ; =16384
      b8:      	str	q0, [sp, #0x120]
      bc:      	bl	0xbc <ltmp0+0xbc>
      c0:      	ldr	q0, [sp, #0x120]
      c4:      	fmov	x8, d0
      c8:      	add	x8, x8, x8, lsl #12
      cc:      	lsl	x24, x8, #2
      d0:      	add	x20, x24, #0x4, lsl #12 ; =0x4000
      d4:      	ldr	s0, [x22, x20]
      d8:      	str	q0, [sp]
      dc:      	str	q0, [sp, #0x8150]
      e0:      	add	x22, sp, #0x130
      e4:      	add	x0, sp, #0x130
      e8:      	add	x1, x21, x24
      ec:      	mov	w2, #0x4000             ; =16384
      f0:      	bl	0xf0 <ltmp0+0xf0>
      f4:      	mov	x8, #0x0                ; =0
      f8:      	ldr	s0, [x21, x20]
      fc:      	mov	w9, #0x2713             ; =10003
     100:      	movk	w9, #0x3d37, lsl #16
     104:      	dup.4s	v2, w9
     108:      	mov	w9, #0x422a             ; =16938
     10c:      	movk	w9, #0x3f4c, lsl #16
     110:      	dup.4s	v1, w9
     114:      	stp	q1, q2, [sp, #0x100]
     118:      	mov	w9, #0x9231             ; =37425
     11c:      	movk	w9, #0x2f30, lsl #16
     120:      	dup.4s	v2, w9
     124:      	mov	w9, #0x322b             ; =12843
     128:      	movk	w9, #0x32d7, lsl #16
     12c:      	dup.4s	v1, w9
     130:      	stp	q1, q2, [sp, #0xe0]
     134:      	mov	w9, #0xef1d             ; =61213
     138:      	movk	w9, #0x3638, lsl #16
     13c:      	dup.4s	v2, w9
     140:      	mov	w9, #0xd01              ; =3329
     144:      	movk	w9, #0x3950, lsl #16
     148:      	dup.4s	v1, w9
     14c:      	stp	q1, q2, [sp, #0xc0]
     150:      	mov	w9, #0x8889             ; =34953
     154:      	movk	w9, #0x3c08, lsl #16
     158:      	dup.4s	v2, w9
     15c:      	mov	w9, #0xaaab             ; =43691
     160:      	movk	w9, #0x3e2a, lsl #16
     164:      	dup.4s	v21, w9
     168:      	mov	w9, #0x76c7             ; =30407
     16c:      	movk	w9, #0x310f, lsl #16
     170:      	dup.4s	v1, w9
     174:      	stp	q1, q2, [sp, #0xa0]
     178:      	mov	w9, #0xf27e             ; =62078
     17c:      	movk	w9, #0x3493, lsl #16
     180:      	dup.4s	v2, w9
     184:      	mov	w9, #0xd01              ; =3329
     188:      	movk	w9, #0x37d0, lsl #16
     18c:      	dup.4s	v1, w9
     190:      	stp	q1, q2, [sp, #0x80]
     194:      	mov	w9, #0xb61              ; =2913
     198:      	movk	w9, #0x3ab6, lsl #16
     19c:      	dup.4s	v2, w9
     1a0:      	mov	w9, #0xaaab             ; =43691
     1a4:      	movk	w9, #0x3d2a, lsl #16
     1a8:      	dup.4s	v1, w9
     1ac:      	stp	q1, q2, [sp, #0x60]
     1b0:      	mov	w9, #-0x3d300000        ; =-1026555904
     1b4:      	dup.4s	v2, w9
     1b8:      	mov	w9, #0x42c80000         ; =1120403456
     1bc:      	dup.4s	v25, w9
     1c0:      	mov	w9, #0xaa3b             ; =43579
     1c4:      	movk	w9, #0x3fb8, lsl #16
     1c8:      	dup.4s	v1, w9
     1cc:      	stp	q1, q2, [sp, #0x40]
     1d0:      	mov	w9, #0x7200             ; =29184
     1d4:      	movk	w9, #0xbf31, lsl #16
     1d8:      	dup.4s	v2, w9
     1dc:      	mov	w9, #0xbe8e             ; =48782
     1e0:      	movk	w9, #0xb5bf, lsl #16
     1e4:      	dup.4s	v1, w9
     1e8:      	stp	q1, q2, [sp, #0x20]
     1ec:      	mov	w9, #0x2bda             ; =11226
     1f0:      	movk	w9, #0x3950, lsl #16
     1f4:      	dup.4s	v29, w9
     1f8:      	mov	w9, #0x96c9             ; =38601
     1fc:      	movk	w9, #0x3ab6, lsl #16
     200:      	dup.4s	v30, w9
     204:      	mov	w9, #0x88a6             ; =34982
     208:      	movk	w9, #0x3c08, lsl #16
     20c:      	dup.4s	v31, w9
     210:      	mov	w9, #0xaa7a             ; =43642
     214:      	movk	w9, #0x3d2a, lsl #16
     218:      	dup.4s	v8, w9
     21c:      	add	x9, x19, x24
     220:      	str	q0, [sp, #0x10]
     224:      	str	q0, [sp, #0x4130]
     228:      	movi.4s	v9, #0x3f, lsl #24
     22c:      	fmov.4s	v19, #1.00000000
     230:      	fmov.4s	v0, #9.00000000
     234:      	str	q0, [sp, #0x120]
     238:      	mvni.4s	v1, #0x7f, msl #16
     23c:      	fneg.4s	v13, v1
     240:      	mvni.4s	v1, #0x3f, msl #16
     244:      	fneg.4s	v15, v1
     248:      	add	x10, x23, x8
     24c:      	ldp	q10, q11, [x10]
     250:      	ldp	q0, q3, [sp, #0x100]
     254:      	fmul.4s	v1, v10, v3
     258:      	fmul.4s	v2, v11, v3
     25c:      	fmul.4s	v2, v11, v2
     260:      	fmul.4s	v1, v10, v1
     264:      	fmul.4s	v1, v10, v1
     268:      	fmul.4s	v2, v11, v2
     26c:      	fadd.4s	v2, v11, v2
     270:      	fadd.4s	v1, v10, v1
     274:      	fmul.4s	v14, v1, v0
     278:      	fmul.4s	v12, v2, v0
     27c:      	fabs.4s	v3, v12
     280:      	fabs.4s	v2, v14
     284:      	fmul.4s	v17, v14, v14
     288:      	ldp	q4, q0, [sp, #0xe0]
     28c:      	mov.16b	v1, v4
     290:      	fmul.4s	v20, v12, v12
     294:      	fmla.4s	v1, v17, v0
     298:      	fmla.4s	v4, v20, v0
     29c:      	ldp	q0, q6, [sp, #0xc0]
     2a0:      	mov.16b	v5, v6
     2a4:      	fmla.4s	v5, v17, v1
     2a8:      	fmla.4s	v6, v20, v4
     2ac:      	mov.16b	v4, v0
     2b0:      	fmla.4s	v4, v17, v5
     2b4:      	mov.16b	v5, v0
     2b8:      	ldr	q0, [sp, #0xb0]
     2bc:      	mov.16b	v7, v0
     2c0:      	fmla.4s	v5, v20, v6
     2c4:      	mov.16b	v6, v0
     2c8:      	mov.16b	v18, v21
     2cc:      	mov.16b	v16, v21
     2d0:      	mov.16b	v1, v19
     2d4:      	mov.16b	v26, v19
     2d8:      	fmla.4s	v7, v17, v4
     2dc:      	ldp	q22, q0, [sp, #0x90]
     2e0:      	mov.16b	v4, v22
     2e4:      	fmla.4s	v4, v20, v0
     2e8:      	fmla.4s	v22, v17, v0
     2ec:      	ldr	q0, [sp, #0x80]
     2f0:      	mov.16b	v23, v0
     2f4:      	fmla.4s	v6, v20, v5
     2f8:      	fmla.4s	v23, v20, v4
     2fc:      	mov.16b	v4, v0
     300:      	fmla.4s	v4, v17, v22
     304:      	ldp	q22, q0, [sp, #0x60]
     308:      	mov.16b	v5, v0
     30c:      	fmla.4s	v5, v20, v23
     310:      	fmla.4s	v18, v17, v7
     314:      	mov.16b	v7, v0
     318:      	fmla.4s	v7, v17, v4
     31c:      	mov.16b	v4, v22
     320:      	fmla.4s	v4, v20, v5
     324:      	fmla.4s	v16, v20, v6
     328:      	fmla.4s	v22, v17, v7
     32c:      	movi.4s	v23, #0x3f, lsl #24
     330:      	fmla.4s	v23, v20, v4
     334:      	movi.4s	v24, #0x3f, lsl #24
     338:      	mov.16b	v6, v19
     33c:      	fmla.4s	v26, v20, v16
     340:      	mov.16b	v0, v19
     344:      	ldr	q5, [sp, #0x120]
     348:      	fcmge.4s	v4, v5, v2
     34c:      	fcmge.4s	v5, v5, v3
     350:      	and.16b	v7, v5, v3
     354:      	and.16b	v16, v4, v2
     358:      	fmla.4s	v6, v20, v23
     35c:      	ldr	q23, [sp, #0x50]
     360:      	fcmge.4s	v20, v16, v23
     364:      	fcmge.4s	v23, v7, v23
     368:      	fcmge.4s	v27, v25, v7
     36c:      	and.16b	v23, v23, v27
     370:      	fcmge.4s	v27, v25, v16
     374:      	fmla.4s	v24, v17, v22
     378:      	and.16b	v20, v20, v27
     37c:      	and.16b	v20, v20, v16
     380:      	and.16b	v22, v23, v7
     384:      	ldr	q27, [sp, #0x40]
     388:      	fmul.4s	v23, v22, v27
     38c:      	fmul.4s	v27, v20, v27
     390:      	fmla.4s	v1, v17, v18
     394:      	movi.4s	v28, #0x4b, lsl #24
     398:      	fadd.4s	v18, v27, v28
     39c:      	fadd.4s	v23, v23, v28
     3a0:      	movi.4s	v27, #0xcb, lsl #24
     3a4:      	fadd.4s	v23, v23, v27
     3a8:      	fadd.4s	v18, v18, v27
     3ac:      	fcvtzs.4s	v18, v18
     3b0:      	fmla.4s	v0, v17, v24
     3b4:      	fcvtzs.4s	v23, v23
     3b8:      	scvtf.4s	v17, v23
     3bc:      	scvtf.4s	v24, v18
     3c0:      	ldr	q28, [sp, #0x30]
     3c4:      	fmul.4s	v27, v17, v28
     3c8:      	fadd.4s	v22, v22, v27
     3cc:      	fmul.4s	v27, v24, v28
     3d0:      	fadd.4s	v20, v20, v27
     3d4:      	ldr	q27, [sp, #0x20]
     3d8:      	fmul.4s	v17, v17, v27
     3dc:      	fmul.4s	v24, v24, v27
     3e0:      	fadd.4s	v20, v20, v24
     3e4:      	fadd.4s	v22, v22, v17
     3e8:      	fmul.4s	v17, v22, v29
     3ec:      	fmul.4s	v24, v20, v29
     3f0:      	fadd.4s	v24, v24, v30
     3f4:      	fadd.4s	v17, v17, v30
     3f8:      	fmul.4s	v17, v22, v17
     3fc:      	fmul.4s	v24, v20, v24
     400:      	fmul.4s	v1, v2, v1
     404:      	fadd.4s	v24, v24, v31
     408:      	fadd.4s	v17, v17, v31
     40c:      	fmul.4s	v27, v22, v17
     410:      	fmul.4s	v17, v20, v24
     414:      	fadd.4s	v24, v17, v8
     418:      	fdiv.4s	v17, v1, v0
     41c:      	fadd.4s	v0, v27, v8
     420:      	fmul.4s	v0, v22, v0
     424:      	fmul.4s	v1, v20, v24
     428:      	fadd.4s	v1, v1, v21
     42c:      	fadd.4s	v0, v0, v21
     430:      	fmul.4s	v0, v22, v0
     434:      	fmul.4s	v1, v20, v1
     438:      	fadd.4s	v1, v1, v9
     43c:      	fadd.4s	v0, v0, v9
     440:      	fmul.4s	v24, v22, v22
     444:      	fmul.4s	v0, v24, v0
     448:      	fmul.4s	v24, v20, v20
     44c:      	fmul.4s	v1, v24, v1
     450:      	fadd.4s	v1, v20, v1
     454:      	fadd.4s	v0, v22, v0
     458:      	fadd.4s	v0, v0, v19
     45c:      	movi.2d	v20, #0xffffffffffffffff
     460:      	add.4s	v18, v18, v20
     464:      	fadd.4s	v1, v1, v19
     468:      	add.4s	v20, v23, v20
     46c:      	sshr.4s	v22, v20, #0x1
     470:      	sshr.4s	v23, v18, #0x1
     474:      	shl.4s	v24, v23, #0x17
     478:      	add.4s	v24, v24, v19
     47c:      	fmul.4s	v1, v1, v24
     480:      	shl.4s	v24, v22, #0x17
     484:      	add.4s	v24, v24, v19
     488:      	fmul.4s	v0, v0, v24
     48c:      	sub.4s	v18, v18, v23
     490:      	sub.4s	v20, v20, v22
     494:      	shl.4s	v20, v20, #0x17
     498:      	add.4s	v20, v20, v19
     49c:      	fmul.4s	v0, v0, v20
     4a0:      	shl.4s	v18, v18, #0x17
     4a4:      	add.4s	v18, v18, v19
     4a8:      	fmul.4s	v1, v1, v18
     4ac:      	fmul.4s	v18, v3, v26
     4b0:      	fcmgt.4s	v7, v7, v25
     4b4:      	fcmgt.4s	v16, v16, v25
     4b8:      	bsl.16b	v16, v13, v1
     4bc:      	bit.16b	v0, v13, v7
     4c0:      	fmov.4s	v1, #0.25000000
     4c4:      	fdiv.4s	v6, v18, v6
     4c8:      	fdiv.4s	v7, v1, v0
     4cc:      	fsub.4s	v18, v0, v7
     4d0:      	fadd.4s	v0, v0, v7
     4d4:      	fdiv.4s	v0, v18, v0
     4d8:      	bif.16b	v0, v19, v5
     4dc:      	fcmge.4s	v3, v19, v3
     4e0:      	bit.16b	v0, v6, v3
     4e4:      	fdiv.4s	v3, v1, v16
     4e8:      	fsub.4s	v5, v16, v3
     4ec:      	fadd.4s	v3, v16, v3
     4f0:      	fdiv.4s	v3, v5, v3
     4f4:      	bif.16b	v3, v19, v4
     4f8:      	fcmge.4s	v2, v19, v2
     4fc:      	bsl.16b	v2, v17, v3
     500:      	mvni.4s	v4, #0x80, lsl #24
     504:      	bif.16b	v2, v14, v4
     508:      	fcmeq.4s	v3, v14, v14
     50c:      	fadd.4s	v2, v2, v19
     510:      	bif.16b	v2, v15, v3
     514:      	bif.16b	v0, v12, v4
     518:      	fcmeq.4s	v3, v12, v12
     51c:      	fadd.4s	v0, v0, v19
     520:      	bif.16b	v0, v15, v3
     524:      	fmul.4s	v3, v11, v9
     528:      	fmul.4s	v0, v3, v0
     52c:      	fmul.4s	v3, v10, v9
     530:      	fmul.4s	v2, v3, v2
     534:      	add	x10, x22, x8
     538:      	ldp	q4, q3, [x10]
     53c:      	fadd.4s	v2, v4, v2
     540:      	fadd.4s	v0, v3, v0
     544:      	add	x10, x9, x8
     548:      	stp	q2, q0, [x10]
     54c:      	add	x8, x8, #0x20
     550:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     554:      	b.ne	0x248 <ltmp0+0x248>
     558:      	movi.2d	v3, #0000000000000000
     55c:      	ldr	q4, [sp]
     560:      	mov.s	v3[0], v4[0]
     564:      	movi.2d	v2, #0000000000000000
     568:      	mov	w8, #0x2713             ; =10003
     56c:      	movk	w8, #0x3d37, lsl #16
     570:      	fmov	s0, w8
     574:      	fmul.4s	v0, v3, v0
     578:      	fmul.4s	v0, v4, v0
     57c:      	fmul.4s	v0, v4, v0
     580:      	fadd.4s	v0, v4, v0
     584:      	mov	w8, #0x422a             ; =16938
     588:      	movk	w8, #0x3f4c, lsl #16
     58c:      	fmov	s4, w8
     590:      	fmul.4s	v0, v0, v4
     594:      	mov.s	v2[0], v0[0]
     598:      	fabs.4s	v4, v2
     59c:      	fmul.4s	v5, v2, v2
     5a0:      	mov	w8, #0x9231             ; =37425
     5a4:      	movk	w8, #0x2f30, lsl #16
     5a8:      	dup.4s	v0, w8
     5ac:      	mov	w8, #0x322b             ; =12843
     5b0:      	movk	w8, #0x32d7, lsl #16
     5b4:      	dup.4s	v6, w8
     5b8:      	mov	w8, #0xef1d             ; =61213
     5bc:      	movk	w8, #0x3638, lsl #16
     5c0:      	dup.4s	v7, w8
     5c4:      	fmla.4s	v6, v5, v0
     5c8:      	fmla.4s	v7, v5, v6
     5cc:      	mov	w8, #0xd01              ; =3329
     5d0:      	movk	w8, #0x3950, lsl #16
     5d4:      	dup.4s	v0, w8
     5d8:      	fmla.4s	v0, v5, v7
     5dc:      	mov	w8, #0x8889             ; =34953
     5e0:      	movk	w8, #0x3c08, lsl #16
     5e4:      	dup.4s	v17, w8
     5e8:      	mov	w8, #0xaaab             ; =43691
     5ec:      	movk	w8, #0x3e2a, lsl #16
     5f0:      	dup.4s	v18, w8
     5f4:      	fmla.4s	v17, v5, v0
     5f8:      	ldr	q0, [sp, #0x120]
     5fc:      	fcmge.4s	v6, v0, v4
     600:      	and.16b	v7, v6, v4
     604:      	mov	w8, #-0x3d300000        ; =-1026555904
     608:      	dup.4s	v0, w8
     60c:      	fcmge.4s	v0, v7, v0
     610:      	mov	w8, #0x42c80000         ; =1120403456
     614:      	dup.4s	v16, w8
     618:      	fcmge.4s	v20, v16, v7
     61c:      	and.16b	v0, v0, v20
     620:      	and.16b	v0, v0, v7
     624:      	mov	w8, #0xaa3b             ; =43579
     628:      	movk	w8, #0x3fb8, lsl #16
     62c:      	dup.4s	v20, w8
     630:      	fmul.4s	v20, v0, v20
     634:      	movi.4s	v21, #0x4b, lsl #24
     638:      	fadd.4s	v20, v20, v21
     63c:      	movi.4s	v21, #0xcb, lsl #24
     640:      	fadd.4s	v20, v20, v21
     644:      	fcvtzs.4s	v20, v20
     648:      	scvtf.4s	v21, v20
     64c:      	mov	w8, #0x7200             ; =29184
     650:      	movk	w8, #0xbf31, lsl #16
     654:      	dup.4s	v22, w8
     658:      	fmul.4s	v22, v21, v22
     65c:      	mov	w8, #0xbe8e             ; =48782
     660:      	movk	w8, #0xb5bf, lsl #16
     664:      	dup.4s	v23, w8
     668:      	fadd.4s	v0, v0, v22
     66c:      	fmul.4s	v21, v21, v23
     670:      	fadd.4s	v0, v0, v21
     674:      	mov	w8, #0x2bda             ; =11226
     678:      	movk	w8, #0x3950, lsl #16
     67c:      	dup.4s	v21, w8
     680:      	fmul.4s	v21, v0, v21
     684:      	mov	w8, #0x96c9             ; =38601
     688:      	movk	w8, #0x3ab6, lsl #16
     68c:      	dup.4s	v22, w8
     690:      	fadd.4s	v21, v21, v22
     694:      	fmul.4s	v21, v0, v21
     698:      	mov	w8, #0x88a6             ; =34982
     69c:      	movk	w8, #0x3c08, lsl #16
     6a0:      	dup.4s	v22, w8
     6a4:      	fadd.4s	v21, v21, v22
     6a8:      	fmul.4s	v21, v0, v21
     6ac:      	mov	w8, #0xaa7a             ; =43642
     6b0:      	movk	w8, #0x3d2a, lsl #16
     6b4:      	dup.4s	v22, w8
     6b8:      	fadd.4s	v21, v21, v22
     6bc:      	fmul.4s	v21, v0, v21
     6c0:      	fadd.4s	v21, v21, v18
     6c4:      	fmla.4s	v18, v5, v17
     6c8:      	mov.16b	v17, v19
     6cc:      	fmla.4s	v17, v5, v18
     6d0:      	mov	w8, #0x76c7             ; =30407
     6d4:      	movk	w8, #0x310f, lsl #16
     6d8:      	dup.4s	v18, w8
     6dc:      	mov	w8, #0xf27e             ; =62078
     6e0:      	movk	w8, #0x3493, lsl #16
     6e4:      	dup.4s	v22, w8
     6e8:      	mov	w8, #0xd01              ; =3329
     6ec:      	movk	w8, #0x37d0, lsl #16
     6f0:      	dup.4s	v23, w8
     6f4:      	fmla.4s	v22, v5, v18
     6f8:      	fmla.4s	v23, v5, v22
     6fc:      	mov	w8, #0xb61              ; =2913
     700:      	movk	w8, #0x3ab6, lsl #16
     704:      	dup.4s	v18, w8
     708:      	fmla.4s	v18, v5, v23
     70c:      	mov	w8, #0xaaab             ; =43691
     710:      	movk	w8, #0x3d2a, lsl #16
     714:      	dup.4s	v22, w8
     718:      	fmla.4s	v22, v5, v18
     71c:      	movi.4s	v18, #0x3f, lsl #24
     720:      	fmla.4s	v18, v5, v22
     724:      	mov.16b	v22, v19
     728:      	fmla.4s	v22, v5, v18
     72c:      	movi.4s	v5, #0x3f, lsl #24
     730:      	fmul.4s	v3, v3, v5
     734:      	fcmge.4s	v18, v19, v4
     738:      	fmul.4s	v4, v4, v17
     73c:      	fdiv.4s	v4, v4, v22
     740:      	fmul.4s	v17, v0, v21
     744:      	fadd.4s	v5, v17, v5
     748:      	fmul.4s	v17, v0, v0
     74c:      	fmul.4s	v5, v17, v5
     750:      	fadd.4s	v0, v0, v5
     754:      	fadd.4s	v0, v0, v19
     758:      	movi.2d	v5, #0xffffffffffffffff
     75c:      	add.4s	v5, v20, v5
     760:      	sshr.4s	v17, v5, #0x1
     764:      	shl.4s	v20, v17, #0x17
     768:      	add.4s	v20, v20, v19
     76c:      	fmul.4s	v0, v0, v20
     770:      	sub.4s	v5, v5, v17
     774:      	shl.4s	v5, v5, #0x17
     778:      	add.4s	v5, v5, v19
     77c:      	fmul.4s	v0, v0, v5
     780:      	fcmgt.4s	v5, v7, v16
     784:      	mvni.4s	v7, #0x7f, msl #16
     788:      	fneg.4s	v7, v7
     78c:      	bit.16b	v0, v7, v5
     790:      	fdiv.4s	v1, v1, v0
     794:      	fsub.4s	v5, v0, v1
     798:      	fadd.4s	v0, v0, v1
     79c:      	fdiv.4s	v0, v5, v0
     7a0:      	bif.16b	v0, v19, v6
     7a4:      	bit.16b	v0, v4, v18
     7a8:      	mvni.4s	v1, #0x80, lsl #24
     7ac:      	bif.16b	v0, v2, v1
     7b0:      	fcmeq.4s	v1, v2, v2
     7b4:      	fadd.4s	v0, v0, v19
     7b8:      	mvni.4s	v2, #0x3f, msl #16
     7bc:      	fneg.4s	v2, v2
     7c0:      	bif.16b	v0, v2, v1
     7c4:      	fmul.4s	v0, v3, v0
     7c8:      	ldr	q1, [sp, #0x10]
     7cc:      	fadd.4s	v0, v0, v1
     7d0:      	b	0xeac <ltmp0+0xeac>
     7d4:      	mov	x9, #0x0                ; =0
     7d8:      	add	x10, x19, x8
     7dc:      	add	x11, x21, x8
     7e0:      	mov	w12, #0x2713            ; =10003
     7e4:      	movk	w12, #0x3d37, lsl #16
     7e8:      	dup.4s	v1, w12
     7ec:      	mov	w12, #0x422a            ; =16938
     7f0:      	movk	w12, #0x3f4c, lsl #16
     7f4:      	dup.4s	v0, w12
     7f8:      	stp	q0, q1, [sp, #0x100]
     7fc:      	mov	w12, #0x9231            ; =37425
     800:      	movk	w12, #0x2f30, lsl #16
     804:      	dup.4s	v1, w12
     808:      	mov	w12, #0x322b            ; =12843
     80c:      	movk	w12, #0x32d7, lsl #16
     810:      	dup.4s	v0, w12
     814:      	stp	q0, q1, [sp, #0xe0]
     818:      	mov	w12, #0xef1d            ; =61213
     81c:      	movk	w12, #0x3638, lsl #16
     820:      	dup.4s	v1, w12
     824:      	mov	w12, #0xd01             ; =3329
     828:      	movk	w12, #0x3950, lsl #16
     82c:      	dup.4s	v0, w12
     830:      	stp	q0, q1, [sp, #0xc0]
     834:      	mov	w12, #0x8889            ; =34953
     838:      	movk	w12, #0x3c08, lsl #16
     83c:      	dup.4s	v1, w12
     840:      	mov	w12, #0xaaab            ; =43691
     844:      	movk	w12, #0x3e2a, lsl #16
     848:      	dup.4s	v20, w12
     84c:      	mov	w12, #0x76c7            ; =30407
     850:      	movk	w12, #0x310f, lsl #16
     854:      	dup.4s	v0, w12
     858:      	stp	q0, q1, [sp, #0xa0]
     85c:      	mov	w12, #0xf27e            ; =62078
     860:      	movk	w12, #0x3493, lsl #16
     864:      	dup.4s	v1, w12
     868:      	mov	w12, #0xd01             ; =3329
     86c:      	movk	w12, #0x37d0, lsl #16
     870:      	dup.4s	v0, w12
     874:      	stp	q0, q1, [sp, #0x80]
     878:      	mov	w12, #0xb61             ; =2913
     87c:      	movk	w12, #0x3ab6, lsl #16
     880:      	dup.4s	v1, w12
     884:      	mov	w12, #0xaaab            ; =43691
     888:      	movk	w12, #0x3d2a, lsl #16
     88c:      	dup.4s	v0, w12
     890:      	stp	q0, q1, [sp, #0x60]
     894:      	mov	w12, #-0x3d300000       ; =-1026555904
     898:      	dup.4s	v1, w12
     89c:      	mov	w12, #0x42c80000        ; =1120403456
     8a0:      	dup.4s	v24, w12
     8a4:      	mov	w12, #0xaa3b            ; =43579
     8a8:      	movk	w12, #0x3fb8, lsl #16
     8ac:      	dup.4s	v0, w12
     8b0:      	stp	q0, q1, [sp, #0x40]
     8b4:      	mov	w12, #0x7200            ; =29184
     8b8:      	movk	w12, #0xbf31, lsl #16
     8bc:      	dup.4s	v1, w12
     8c0:      	mov	w12, #0xbe8e            ; =48782
     8c4:      	movk	w12, #0xb5bf, lsl #16
     8c8:      	dup.4s	v0, w12
     8cc:      	stp	q0, q1, [sp, #0x20]
     8d0:      	mov	w12, #0x2bda            ; =11226
     8d4:      	movk	w12, #0x3950, lsl #16
     8d8:      	dup.4s	v28, w12
     8dc:      	mov	w12, #0x96c9            ; =38601
     8e0:      	movk	w12, #0x3ab6, lsl #16
     8e4:      	dup.4s	v29, w12
     8e8:      	mov	w12, #0x88a6            ; =34982
     8ec:      	movk	w12, #0x3c08, lsl #16
     8f0:      	dup.4s	v30, w12
     8f4:      	mov	w12, #0xaa7a            ; =43642
     8f8:      	movk	w12, #0x3d2a, lsl #16
     8fc:      	dup.4s	v31, w12
     900:      	add	x12, x22, x8
     904:      	movi.4s	v8, #0x3f, lsl #24
     908:      	fmov.4s	v18, #1.00000000
     90c:      	fmov.4s	v0, #9.00000000
     910:      	str	q0, [sp, #0x120]
     914:      	mvni.4s	v0, #0x7f, msl #16
     918:      	fneg.4s	v12, v0
     91c:      	mvni.4s	v0, #0x3f, msl #16
     920:      	fneg.4s	v14, v0
     924:      	add	x13, x12, x9
     928:      	ldp	q9, q10, [x13]
     92c:      	ldp	q2, q1, [sp, #0x100]
     930:      	fmul.4s	v0, v9, v1
     934:      	fmul.4s	v1, v10, v1
     938:      	fmul.4s	v1, v10, v1
     93c:      	fmul.4s	v0, v9, v0
     940:      	fmul.4s	v0, v9, v0
     944:      	fmul.4s	v1, v10, v1
     948:      	fadd.4s	v1, v10, v1
     94c:      	fadd.4s	v0, v9, v0
     950:      	fmul.4s	v13, v0, v2
     954:      	fmul.4s	v11, v1, v2
     958:      	fabs.4s	v2, v11
     95c:      	fabs.4s	v1, v13
     960:      	fmul.4s	v16, v13, v13
     964:      	ldp	q3, q4, [sp, #0xe0]
     968:      	mov.16b	v0, v3
     96c:      	fmul.4s	v19, v11, v11
     970:      	fmla.4s	v0, v16, v4
     974:      	fmla.4s	v3, v19, v4
     978:      	ldr	q5, [sp, #0xd0]
     97c:      	mov.16b	v4, v5
     980:      	fmla.4s	v4, v16, v0
     984:      	fmla.4s	v5, v19, v3
     988:      	ldr	q0, [sp, #0xc0]
     98c:      	mov.16b	v3, v0
     990:      	fmla.4s	v3, v16, v4
     994:      	mov.16b	v4, v0
     998:      	ldp	q22, q0, [sp, #0xa0]
     99c:      	mov.16b	v6, v0
     9a0:      	fmla.4s	v4, v19, v5
     9a4:      	mov.16b	v5, v0
     9a8:      	mov.16b	v17, v20
     9ac:      	mov.16b	v7, v20
     9b0:      	mov.16b	v0, v18
     9b4:      	mov.16b	v25, v18
     9b8:      	fmla.4s	v6, v16, v3
     9bc:      	ldp	q23, q21, [sp, #0x80]
     9c0:      	mov.16b	v3, v21
     9c4:      	fmla.4s	v3, v19, v22
     9c8:      	fmla.4s	v21, v16, v22
     9cc:      	mov.16b	v22, v23
     9d0:      	fmla.4s	v5, v19, v4
     9d4:      	fmla.4s	v22, v19, v3
     9d8:      	mov.16b	v3, v23
     9dc:      	fmla.4s	v3, v16, v21
     9e0:      	ldr	q21, [sp, #0x70]
     9e4:      	mov.16b	v4, v21
     9e8:      	fmla.4s	v4, v19, v22
     9ec:      	fmla.4s	v17, v16, v6
     9f0:      	mov.16b	v6, v21
     9f4:      	fmla.4s	v6, v16, v3
     9f8:      	ldr	q21, [sp, #0x60]
     9fc:      	mov.16b	v3, v21
     a00:      	fmla.4s	v3, v19, v4
     a04:      	fmla.4s	v7, v19, v5
     a08:      	fmla.4s	v21, v16, v6
     a0c:      	movi.4s	v22, #0x3f, lsl #24
     a10:      	fmla.4s	v22, v19, v3
     a14:      	movi.4s	v23, #0x3f, lsl #24
     a18:      	mov.16b	v5, v18
     a1c:      	fmla.4s	v25, v19, v7
     a20:      	mov.16b	v15, v18
     a24:      	ldr	q4, [sp, #0x120]
     a28:      	fcmge.4s	v3, v4, v1
     a2c:      	fcmge.4s	v4, v4, v2
     a30:      	and.16b	v6, v4, v2
     a34:      	and.16b	v7, v3, v1
     a38:      	fmla.4s	v5, v19, v22
     a3c:      	ldr	q22, [sp, #0x50]
     a40:      	fcmge.4s	v19, v7, v22
     a44:      	fcmge.4s	v22, v6, v22
     a48:      	fcmge.4s	v26, v24, v6
     a4c:      	and.16b	v22, v22, v26
     a50:      	fcmge.4s	v26, v24, v7
     a54:      	fmla.4s	v23, v16, v21
     a58:      	and.16b	v19, v19, v26
     a5c:      	and.16b	v19, v19, v7
     a60:      	and.16b	v21, v22, v6
     a64:      	ldr	q26, [sp, #0x40]
     a68:      	fmul.4s	v22, v21, v26
     a6c:      	fmul.4s	v26, v19, v26
     a70:      	fmla.4s	v0, v16, v17
     a74:      	movi.4s	v27, #0x4b, lsl #24
     a78:      	fadd.4s	v17, v26, v27
     a7c:      	fadd.4s	v22, v22, v27
     a80:      	movi.4s	v26, #0xcb, lsl #24
     a84:      	fadd.4s	v22, v22, v26
     a88:      	fadd.4s	v17, v17, v26
     a8c:      	fcvtzs.4s	v17, v17
     a90:      	fmla.4s	v15, v16, v23
     a94:      	fcvtzs.4s	v22, v22
     a98:      	scvtf.4s	v16, v22
     a9c:      	scvtf.4s	v23, v17
     aa0:      	ldr	q27, [sp, #0x30]
     aa4:      	fmul.4s	v26, v16, v27
     aa8:      	fadd.4s	v21, v21, v26
     aac:      	fmul.4s	v26, v23, v27
     ab0:      	fadd.4s	v19, v19, v26
     ab4:      	ldr	q26, [sp, #0x20]
     ab8:      	fmul.4s	v16, v16, v26
     abc:      	fmul.4s	v23, v23, v26
     ac0:      	fadd.4s	v19, v19, v23
     ac4:      	fadd.4s	v21, v21, v16
     ac8:      	fmul.4s	v16, v21, v28
     acc:      	fmul.4s	v23, v19, v28
     ad0:      	fadd.4s	v23, v23, v29
     ad4:      	fadd.4s	v16, v16, v29
     ad8:      	fmul.4s	v16, v21, v16
     adc:      	fmul.4s	v23, v19, v23
     ae0:      	fmul.4s	v0, v1, v0
     ae4:      	fadd.4s	v23, v23, v30
     ae8:      	fadd.4s	v16, v16, v30
     aec:      	fmul.4s	v26, v21, v16
     af0:      	fmul.4s	v16, v19, v23
     af4:      	fadd.4s	v23, v16, v31
     af8:      	fdiv.4s	v16, v0, v15
     afc:      	fadd.4s	v0, v26, v31
     b00:      	fmul.4s	v0, v21, v0
     b04:      	fmul.4s	v23, v19, v23
     b08:      	fadd.4s	v23, v23, v20
     b0c:      	fadd.4s	v0, v0, v20
     b10:      	fmul.4s	v0, v21, v0
     b14:      	fmul.4s	v23, v19, v23
     b18:      	fadd.4s	v23, v23, v8
     b1c:      	fadd.4s	v0, v0, v8
     b20:      	fmul.4s	v26, v21, v21
     b24:      	fmul.4s	v0, v26, v0
     b28:      	fmul.4s	v26, v19, v19
     b2c:      	fmul.4s	v23, v26, v23
     b30:      	fadd.4s	v19, v19, v23
     b34:      	fadd.4s	v0, v21, v0
     b38:      	fadd.4s	v0, v0, v18
     b3c:      	movi.2d	v21, #0xffffffffffffffff
     b40:      	add.4s	v17, v17, v21
     b44:      	fadd.4s	v19, v19, v18
     b48:      	add.4s	v21, v22, v21
     b4c:      	sshr.4s	v22, v21, #0x1
     b50:      	sshr.4s	v23, v17, #0x1
     b54:      	shl.4s	v26, v23, #0x17
     b58:      	add.4s	v26, v26, v18
     b5c:      	fmul.4s	v19, v19, v26
     b60:      	shl.4s	v26, v22, #0x17
     b64:      	add.4s	v26, v26, v18
     b68:      	fmul.4s	v0, v0, v26
     b6c:      	sub.4s	v17, v17, v23
     b70:      	sub.4s	v21, v21, v22
     b74:      	shl.4s	v21, v21, #0x17
     b78:      	add.4s	v21, v21, v18
     b7c:      	fmul.4s	v0, v0, v21
     b80:      	shl.4s	v17, v17, #0x17
     b84:      	add.4s	v17, v17, v18
     b88:      	fmul.4s	v17, v19, v17
     b8c:      	fmul.4s	v19, v2, v25
     b90:      	fcmgt.4s	v6, v6, v24
     b94:      	fcmgt.4s	v7, v7, v24
     b98:      	bsl.16b	v7, v12, v17
     b9c:      	bsl.16b	v6, v12, v0
     ba0:      	fmov.4s	v0, #0.25000000
     ba4:      	fdiv.4s	v5, v19, v5
     ba8:      	fdiv.4s	v17, v0, v6
     bac:      	fsub.4s	v19, v6, v17
     bb0:      	fadd.4s	v6, v6, v17
     bb4:      	fdiv.4s	v6, v19, v6
     bb8:      	bsl.16b	v4, v6, v18
     bbc:      	fcmge.4s	v2, v18, v2
     bc0:      	bsl.16b	v2, v5, v4
     bc4:      	fdiv.4s	v4, v0, v7
     bc8:      	fsub.4s	v5, v7, v4
     bcc:      	fadd.4s	v4, v7, v4
     bd0:      	fdiv.4s	v4, v5, v4
     bd4:      	bsl.16b	v3, v4, v18
     bd8:      	fcmge.4s	v1, v18, v1
     bdc:      	bsl.16b	v1, v16, v3
     be0:      	mvni.4s	v4, #0x80, lsl #24
     be4:      	bif.16b	v1, v13, v4
     be8:      	fcmeq.4s	v3, v13, v13
     bec:      	fadd.4s	v1, v1, v18
     bf0:      	bif.16b	v1, v14, v3
     bf4:      	bif.16b	v2, v11, v4
     bf8:      	fcmeq.4s	v3, v11, v11
     bfc:      	fadd.4s	v2, v2, v18
     c00:      	bif.16b	v2, v14, v3
     c04:      	fmul.4s	v3, v10, v8
     c08:      	fmul.4s	v2, v3, v2
     c0c:      	fmul.4s	v3, v9, v8
     c10:      	fmul.4s	v1, v3, v1
     c14:      	add	x13, x11, x9
     c18:      	ldp	q4, q3, [x13]
     c1c:      	fadd.4s	v1, v4, v1
     c20:      	fadd.4s	v2, v3, v2
     c24:      	add	x13, x10, x9
     c28:      	stp	q1, q2, [x13]
     c2c:      	add	x9, x9, #0x20
     c30:      	cmp	x9, #0x4, lsl #12       ; =0x4000
     c34:      	b.ne	0x924 <ltmp0+0x924>
     c38:      	add	x20, x8, #0x4, lsl #12  ; =0x4000
     c3c:      	ldr	s2, [x22, x20]
     c40:      	movi.2d	v1, #0000000000000000
     c44:      	mov	w8, #0x2713             ; =10003
     c48:      	movk	w8, #0x3d37, lsl #16
     c4c:      	fmov	s3, w8
     c50:      	fmul.4s	v3, v2, v3
     c54:      	fmul.4s	v3, v2, v3
     c58:      	fmul.4s	v3, v2, v3
     c5c:      	fadd.4s	v3, v2, v3
     c60:      	mov	w8, #0x422a             ; =16938
     c64:      	movk	w8, #0x3f4c, lsl #16
     c68:      	fmov	s4, w8
     c6c:      	fmul.4s	v3, v3, v4
     c70:      	mov.s	v1[0], v3[0]
     c74:      	fabs.4s	v3, v1
     c78:      	mov	w8, #0x9231             ; =37425
     c7c:      	movk	w8, #0x2f30, lsl #16
     c80:      	dup.4s	v5, w8
     c84:      	mov	w8, #0x322b             ; =12843
     c88:      	movk	w8, #0x32d7, lsl #16
     c8c:      	dup.4s	v6, w8
     c90:      	fmul.4s	v4, v1, v1
     c94:      	fmla.4s	v6, v4, v5
     c98:      	mov	w8, #0xef1d             ; =61213
     c9c:      	movk	w8, #0x3638, lsl #16
     ca0:      	dup.4s	v5, w8
     ca4:      	fmla.4s	v5, v4, v6
     ca8:      	mov	w8, #0xd01              ; =3329
     cac:      	movk	w8, #0x3950, lsl #16
     cb0:      	dup.4s	v6, w8
     cb4:      	mov	w8, #0x8889             ; =34953
     cb8:      	movk	w8, #0x3c08, lsl #16
     cbc:      	dup.4s	v16, w8
     cc0:      	fmla.4s	v6, v4, v5
     cc4:      	fmla.4s	v16, v4, v6
     cc8:      	mov	w8, #0xaaab             ; =43691
     ccc:      	movk	w8, #0x3e2a, lsl #16
     cd0:      	dup.4s	v17, w8
     cd4:      	ldr	q5, [sp, #0x120]
     cd8:      	fcmge.4s	v5, v5, v3
     cdc:      	and.16b	v6, v5, v3
     ce0:      	mov	w8, #-0x3d300000        ; =-1026555904
     ce4:      	dup.4s	v7, w8
     ce8:      	fcmge.4s	v19, v6, v7
     cec:      	mov	w8, #0x42c80000         ; =1120403456
     cf0:      	dup.4s	v7, w8
     cf4:      	fcmge.4s	v20, v7, v6
     cf8:      	and.16b	v19, v19, v20
     cfc:      	and.16b	v19, v19, v6
     d00:      	mov	w8, #0xaa3b             ; =43579
     d04:      	movk	w8, #0x3fb8, lsl #16
     d08:      	dup.4s	v20, w8
     d0c:      	fmul.4s	v20, v19, v20
     d10:      	movi.4s	v21, #0x4b, lsl #24
     d14:      	fadd.4s	v20, v20, v21
     d18:      	movi.4s	v21, #0xcb, lsl #24
     d1c:      	fadd.4s	v20, v20, v21
     d20:      	fcvtzs.4s	v20, v20
     d24:      	scvtf.4s	v21, v20
     d28:      	mov	w8, #0x7200             ; =29184
     d2c:      	movk	w8, #0xbf31, lsl #16
     d30:      	dup.4s	v22, w8
     d34:      	fmul.4s	v22, v21, v22
     d38:      	fadd.4s	v19, v19, v22
     d3c:      	mov	w8, #0xbe8e             ; =48782
     d40:      	movk	w8, #0xb5bf, lsl #16
     d44:      	dup.4s	v22, w8
     d48:      	fmul.4s	v21, v21, v22
     d4c:      	fadd.4s	v19, v19, v21
     d50:      	mov	w8, #0x2bda             ; =11226
     d54:      	movk	w8, #0x3950, lsl #16
     d58:      	dup.4s	v21, w8
     d5c:      	fmul.4s	v21, v19, v21
     d60:      	mov	w8, #0x96c9             ; =38601
     d64:      	movk	w8, #0x3ab6, lsl #16
     d68:      	dup.4s	v22, w8
     d6c:      	fadd.4s	v21, v21, v22
     d70:      	mov	w8, #0x88a6             ; =34982
     d74:      	movk	w8, #0x3c08, lsl #16
     d78:      	dup.4s	v22, w8
     d7c:      	fmul.4s	v21, v19, v21
     d80:      	fadd.4s	v21, v21, v22
     d84:      	fmul.4s	v21, v19, v21
     d88:      	mov	w8, #0xaa7a             ; =43642
     d8c:      	movk	w8, #0x3d2a, lsl #16
     d90:      	dup.4s	v22, w8
     d94:      	fadd.4s	v21, v21, v22
     d98:      	fmul.4s	v21, v19, v21
     d9c:      	fadd.4s	v21, v21, v17
     da0:      	fmla.4s	v17, v4, v16
     da4:      	mov.16b	v16, v18
     da8:      	mov	w8, #0x76c7             ; =30407
     dac:      	movk	w8, #0x310f, lsl #16
     db0:      	dup.4s	v22, w8
     db4:      	mov	w8, #0xf27e             ; =62078
     db8:      	movk	w8, #0x3493, lsl #16
     dbc:      	dup.4s	v23, w8
     dc0:      	fmla.4s	v16, v4, v17
     dc4:      	fmla.4s	v23, v4, v22
     dc8:      	mov	w8, #0xd01              ; =3329
     dcc:      	movk	w8, #0x37d0, lsl #16
     dd0:      	dup.4s	v17, w8
     dd4:      	fmla.4s	v17, v4, v23
     dd8:      	mov	w8, #0xb61              ; =2913
     ddc:      	movk	w8, #0x3ab6, lsl #16
     de0:      	dup.4s	v22, w8
     de4:      	mov	w8, #0xaaab             ; =43691
     de8:      	movk	w8, #0x3d2a, lsl #16
     dec:      	dup.4s	v23, w8
     df0:      	fmla.4s	v22, v4, v17
     df4:      	fmla.4s	v23, v4, v22
     df8:      	movi.4s	v17, #0x3f, lsl #24
     dfc:      	fmla.4s	v17, v4, v23
     e00:      	mov.16b	v22, v18
     e04:      	fmla.4s	v22, v4, v17
     e08:      	movi.4s	v4, #0x3f, lsl #24
     e0c:      	fmul.4s	v2, v2, v4
     e10:      	fcmge.4s	v17, v18, v3
     e14:      	fmul.4s	v3, v3, v16
     e18:      	fdiv.4s	v3, v3, v22
     e1c:      	fmul.4s	v16, v19, v21
     e20:      	fadd.4s	v4, v16, v4
     e24:      	fmul.4s	v16, v19, v19
     e28:      	fmul.4s	v4, v16, v4
     e2c:      	fadd.4s	v4, v19, v4
     e30:      	fadd.4s	v4, v4, v18
     e34:      	movi.2d	v16, #0xffffffffffffffff
     e38:      	add.4s	v16, v20, v16
     e3c:      	sshr.4s	v19, v16, #0x1
     e40:      	shl.4s	v20, v19, #0x17
     e44:      	add.4s	v20, v20, v18
     e48:      	fmul.4s	v4, v4, v20
     e4c:      	sub.4s	v16, v16, v19
     e50:      	shl.4s	v16, v16, #0x17
     e54:      	add.4s	v16, v16, v18
     e58:      	fmul.4s	v4, v4, v16
     e5c:      	fcmgt.4s	v6, v6, v7
     e60:      	mvni.4s	v7, #0x7f, msl #16
     e64:      	fneg.4s	v7, v7
     e68:      	bit.16b	v4, v7, v6
     e6c:      	fdiv.4s	v0, v0, v4
     e70:      	fsub.4s	v6, v4, v0
     e74:      	fadd.4s	v0, v4, v0
     e78:      	fdiv.4s	v0, v6, v0
     e7c:      	bif.16b	v0, v18, v5
     e80:      	bit.16b	v0, v3, v17
     e84:      	mvni.4s	v3, #0x80, lsl #24
     e88:      	bif.16b	v0, v1, v3
     e8c:      	fcmeq.4s	v1, v1, v1
     e90:      	fadd.4s	v0, v0, v18
     e94:      	mvni.4s	v3, #0x3f, msl #16
     e98:      	fneg.4s	v3, v3
     e9c:      	bif.16b	v0, v3, v1
     ea0:      	fmul.4s	v0, v2, v0
     ea4:      	ldr	s1, [x21, x20]
     ea8:      	fadd.4s	v0, v1, v0
     eac:      	str	s0, [x19, x20]
     eb0:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
     eb4:      	add	sp, sp, #0x170
     eb8:      	ldp	x29, x30, [sp, #0x80]
     ebc:      	ldp	x20, x19, [sp, #0x70]
     ec0:      	ldp	x22, x21, [sp, #0x60]
     ec4:      	ldp	x24, x23, [sp, #0x50]
     ec8:      	ldp	x28, x27, [sp, #0x40]
     ecc:      	ldp	d9, d8, [sp, #0x30]
     ed0:      	ldp	d11, d10, [sp, #0x20]
     ed4:      	ldp	d13, d12, [sp, #0x10]
     ed8:      	ldp	d15, d14, [sp], #0x90
     edc:      	ret

0000000000000ee0 <_llm_rows.packet_batch.blocks>:
     ee0:      	stp	d15, d14, [sp, #-0xa0]!
     ee4:      	stp	d13, d12, [sp, #0x10]
     ee8:      	stp	d11, d10, [sp, #0x20]
     eec:      	stp	d9, d8, [sp, #0x30]
     ef0:      	stp	x28, x27, [sp, #0x40]
     ef4:      	stp	x26, x25, [sp, #0x50]
     ef8:      	stp	x24, x23, [sp, #0x60]
     efc:      	stp	x22, x21, [sp, #0x70]
     f00:      	stp	x20, x19, [sp, #0x80]
     f04:      	stp	x29, x30, [sp, #0x90]
     f08:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
     f0c:      	sub	sp, sp, #0x420
     f10:      	str	x0, [sp, #0x118]
     f14:      	cbz	w3, 0x2b28 <_llm_rows.packet_batch.blocks+0x1c48>
     f18:      	mov	x19, x3
     f1c:      	mov	x20, x2
     f20:      	mov	w22, #0x0               ; =0
     f24:      	ldp	w9, w8, [x2, #0x2c]
     f28:      	str	w9, [sp, #0x114]
     f2c:      	str	w8, [sp, #0x110]
     f30:      	adrp	x8, 0x0 <ltmp0>
     f34:      	ldr	q0, [x8]
     f38:      	str	q0, [sp, #0xc0]
     f3c:      	adrp	x8, 0x0 <ltmp0>
     f40:      	ldr	q0, [x8]
     f44:      	str	q0, [sp, #0xb0]
     f48:      	adrp	x8, 0x0 <ltmp0>
     f4c:      	ldr	q0, [x8]
     f50:      	str	q0, [sp, #0x90]
     f54:      	adrp	x8, 0x0 <ltmp0>
     f58:      	ldr	q0, [x8]
     f5c:      	str	q0, [sp, #0x80]
     f60:      	adrp	x8, 0x0 <ltmp0>
     f64:      	ldr	q0, [x8]
     f68:      	str	q0, [sp, #0x70]
     f6c:      	adrp	x8, 0x0 <ltmp0>
     f70:      	ldr	q0, [x8]
     f74:      	str	q0, [sp, #0x60]
     f78:      	adrp	x8, 0x0 <ltmp0>
     f7c:      	ldr	q0, [x8]
     f80:      	str	q0, [sp, #0x130]
     f84:      	mvni.4s	v0, #0x7f, msl #16
     f88:      	fneg.4s	v1, v0
     f8c:      	mvni.4s	v0, #0x3f, msl #16
     f90:      	fneg.4s	v0, v0
     f94:      	stp	q0, q1, [sp, #0x1a0]
     f98:      	ldp	w27, w23, [x2]
     f9c:      	add	x24, sp, #0x4, lsl #12  ; =0x4000
     fa0:      	add	x24, x24, #0x400
     fa4:      	ldp	w28, w25, [x2, #0x8]
     fa8:      	add	x26, sp, #0x3e0
     fac:      	str	w3, [sp, #0x10c]
     fb0:      	b	0xffc <_llm_rows.packet_batch.blocks+0x11c>
     fb4:      	mov	w8, #0x18               ; =24
     fb8:      	str	w8, [x20, #0x24]
     fbc:      	ldr	w19, [sp, #0x10c]
     fc0:      	add	w8, w27, #0x1
     fc4:      	ldr	w9, [sp, #0x114]
     fc8:      	cmp	w8, w9
     fcc:      	cset	w8, eq
     fd0:      	csinc	w27, wzr, w27, eq
     fd4:      	cinc	w9, w23, eq
     fd8:      	ldr	w10, [sp, #0x110]
     fdc:      	cmp	w9, w10
     fe0:      	cset	w10, eq
     fe4:      	ands	w8, w8, w10
     fe8:      	csel	w23, wzr, w9, ne
     fec:      	add	w28, w28, w8
     ff0:      	add	w22, w22, #0x1
     ff4:      	cmp	w22, w19
     ff8:      	b.eq	0x2b28 <_llm_rows.packet_batch.blocks+0x1c48>
     ffc:      	ubfiz	x8, x27, #5, #32
    1000:      	cmp	x8, x25
    1004:      	csel	x9, x8, xzr, ls
    1008:      	subs	x10, x25, x9
    100c:      	cmp	x10, #0x20
    1010:      	mov	w11, #0x20              ; =32
    1014:      	csel	x10, x10, x11, lo
    1018:      	cmp	x25, x9
    101c:      	stp	w27, w23, [x20]
    1020:      	str	w28, [x20, #0x8]
    1024:      	str	wzr, [x20, #0x24]
    1028:      	ccmp	x8, x25, #0x2, hi
    102c:      	csel	x21, x10, xzr, ls
    1030:      	cmp	x21, #0x20
    1034:      	b.lo	0x1088 <_llm_rows.packet_batch.blocks+0x1a8>
    1038:      	ldr	x21, [sp, #0x118]
    103c:      	mov	x0, x21
    1040:      	mov	x1, x20
    1044:      	bl	0x1044 <_llm_rows.packet_batch.blocks+0x164>
    1048:      	mov	w8, #0x8                ; =8
    104c:      	str	w8, [x20, #0x24]
    1050:      	mov	x0, x21
    1054:      	mov	x1, x20
    1058:      	bl	0x1058 <_llm_rows.packet_batch.blocks+0x178>
    105c:      	mov	w8, #0x10               ; =16
    1060:      	str	w8, [x20, #0x24]
    1064:      	mov	x0, x21
    1068:      	mov	x1, x20
    106c:      	bl	0x106c <_llm_rows.packet_batch.blocks+0x18c>
    1070:      	mov	w8, #0x18               ; =24
    1074:      	str	w8, [x20, #0x24]
    1078:      	mov	x0, x21
    107c:      	mov	x1, x20
    1080:      	bl	0x1080 <_llm_rows.packet_batch.blocks+0x1a0>
    1084:      	b	0xfc0 <_llm_rows.packet_batch.blocks+0xe0>
    1088:      	lsr	x19, x21, #3
    108c:      	cmp	x21, #0x8
    1090:      	b.lo	0x10dc <_llm_rows.packet_batch.blocks+0x1fc>
    1094:      	str	wzr, [x20, #0x24]
    1098:      	ldr	x0, [sp, #0x118]
    109c:      	mov	x1, x20
    10a0:      	bl	0x10a0 <_llm_rows.packet_batch.blocks+0x1c0>
    10a4:      	cmp	x19, #0x1
    10a8:      	b.eq	0x10dc <_llm_rows.packet_batch.blocks+0x1fc>
    10ac:      	mov	w8, #0x8                ; =8
    10b0:      	str	w8, [x20, #0x24]
    10b4:      	ldr	x0, [sp, #0x118]
    10b8:      	mov	x1, x20
    10bc:      	bl	0x10bc <_llm_rows.packet_batch.blocks+0x1dc>
    10c0:      	cmp	x19, #0x2
    10c4:      	b.eq	0x10dc <_llm_rows.packet_batch.blocks+0x1fc>
    10c8:      	mov	w8, #0x10               ; =16
    10cc:      	str	w8, [x20, #0x24]
    10d0:      	ldr	x0, [sp, #0x118]
    10d4:      	mov	x1, x20
    10d8:      	bl	0x10d8 <_llm_rows.packet_batch.blocks+0x1f8>
    10dc:      	and	w8, w21, #0x7
    10e0:      	cbz	w8, 0xfb4 <_llm_rows.packet_batch.blocks+0xd4>
    10e4:      	dup.4s	v0, w8
    10e8:      	ldp	q3, q1, [sp, #0xb0]
    10ec:      	cmhi.4s	v2, v0, v3
    10f0:      	cmhi.4s	v9, v0, v1
    10f4:      	uzp1.8h	v3, v9, v2
    10f8:      	umaxv.8h	h0, v3
    10fc:      	fmov	w8, s0
    1100:      	tbz	w8, #0x0, 0xfb4 <_llm_rows.packet_batch.blocks+0xd4>
    1104:      	ldr	x8, [sp, #0x118]
    1108:      	ldr	x11, [x8]
    110c:      	ldr	x9, [x8, #0x10]
    1110:      	ldr	x8, [x8, #0x30]
    1114:      	sshll.2d	v0, v9, #0x0
    1118:      	mov.16b	v4, v2
    111c:      	sshll.2d	v1, v4, #0x0
    1120:      	sshll2.2d	v15, v9, #0x0
    1124:      	sshll2.2d	v12, v2, #0x0
    1128:      	ldp	q2, q5, [sp, #0x80]
    112c:      	and.16b	v18, v12, v5
    1130:      	and.16b	v17, v15, v2
    1134:      	ldr	q2, [sp, #0x70]
    1138:      	and.16b	v16, v1, v2
    113c:      	ldr	q1, [sp, #0x60]
    1140:      	and.16b	v0, v0, v1
    1144:      	str	q0, [sp, #0xd0]
    1148:      	ubfiz	w10, w27, #2, #27
    114c:      	orr	w10, w10, w19
    1150:      	dup.4s	v0, w10
    1154:      	and.16b	v1, v9, v0
    1158:      	str	q4, [sp, #0x180]
    115c:      	and.16b	v0, v4, v0
    1160:      	ushll2.2d	v5, v0, #0x0
    1164:      	ushll2.2d	v4, v1, #0x0
    1168:      	ushll.2d	v6, v0, #0x0
    116c:      	ushll.2d	v0, v1, #0x0
    1170:      	subs	x10, x11, x8
    1174:      	mov	w12, #0x2713            ; =10003
    1178:      	movk	w12, #0x3d37, lsl #16
    117c:      	dup.4s	v2, w12
    1180:      	mov	w14, #0xfff             ; =4095
    1184:      	movk	w14, #0x100, lsl #16
    1188:      	ccmp	x10, x14, #0x0, hs
    118c:      	cset	w10, hi
    1190:      	mov	w12, #0x422a            ; =16938
    1194:      	movk	w12, #0x3f4c, lsl #16
    1198:      	dup.4s	v1, w12
    119c:      	stp	q2, q1, [sp, #0x1c0]
    11a0:      	mov	w12, #0x9231            ; =37425
    11a4:      	movk	w12, #0x2f30, lsl #16
    11a8:      	dup.4s	v1, w12
    11ac:      	str	q1, [sp, #0x200]
    11b0:      	subs	x12, x8, x11
    11b4:      	ccmp	x12, x14, #0x0, hs
    11b8:      	mov	w12, #0x322b            ; =12843
    11bc:      	movk	w12, #0x32d7, lsl #16
    11c0:      	dup.4s	v1, w12
    11c4:      	str	q1, [sp, #0x220]
    11c8:      	mov	w12, #0xef1d            ; =61213
    11cc:      	movk	w12, #0x3638, lsl #16
    11d0:      	dup.4s	v2, w12
    11d4:      	csinc	w12, w10, wzr, ls
    11d8:      	subs	x10, x9, x8
    11dc:      	mov	w13, #0xd01             ; =3329
    11e0:      	movk	w13, #0x3950, lsl #16
    11e4:      	dup.4s	v10, w13
    11e8:      	mov	w13, #0x8889            ; =34953
    11ec:      	movk	w13, #0x3c08, lsl #16
    11f0:      	dup.4s	v22, w13
    11f4:      	ccmp	x10, x14, #0x0, hs
    11f8:      	cset	w10, hi
    11fc:      	mov	w13, #0xaaab            ; =43691
    1200:      	movk	w13, #0x3e2a, lsl #16
    1204:      	dup.4s	v1, w13
    1208:      	stp	q2, q1, [sp, #0x240]
    120c:      	mov	w13, #0x76c7            ; =30407
    1210:      	movk	w13, #0x310f, lsl #16
    1214:      	dup.4s	v29, w13
    1218:      	subs	x13, x8, x9
    121c:      	ccmp	x13, x14, #0x0, hs
    1220:      	csinc	w10, w10, wzr, ls
    1224:      	xtn.2s	v1, v0
    1228:      	str	d1, [sp, #0xf0]
    122c:      	fmov	x13, d0
    1230:      	add	x13, x13, x13, lsl #12
    1234:      	lsl	x14, x13, #2
    1238:      	fmov.4s	v0, #1.00000000
    123c:      	mov	w13, #0xf27e            ; =62078
    1240:      	movk	w13, #0x3493, lsl #16
    1244:      	dup.4s	v2, w13
    1248:      	mov	w13, #0xd01             ; =3329
    124c:      	movk	w13, #0x37d0, lsl #16
    1250:      	dup.4s	v1, w13
    1254:      	stp	q2, q1, [sp, #0x1e0]
    1258:      	mov	w13, #0xb61             ; =2913
    125c:      	movk	w13, #0x3ab6, lsl #16
    1260:      	dup.4s	v1, w13
    1264:      	str	q1, [sp, #0x210]
    1268:      	mov	w13, #0xaaab            ; =43691
    126c:      	movk	w13, #0x3d2a, lsl #16
    1270:      	dup.4s	v1, w13
    1274:      	str	q1, [sp, #0x230]
    1278:      	mov	w13, #-0x3d300000       ; =-1026555904
    127c:      	dup.4s	v28, w13
    1280:      	mov	w13, #0x42c80000        ; =1120403456
    1284:      	dup.4s	v1, w13
    1288:      	str	q1, [sp, #0x260]
    128c:      	mov	w13, #0xaa3b            ; =43579
    1290:      	movk	w13, #0x3fb8, lsl #16
    1294:      	dup.4s	v30, w13
    1298:      	mov	w13, #0x7200            ; =29184
    129c:      	movk	w13, #0xbf31, lsl #16
    12a0:      	dup.4s	v8, w13
    12a4:      	mov	w13, #0xbe8e            ; =48782
    12a8:      	movk	w13, #0xb5bf, lsl #16
    12ac:      	dup.4s	v27, w13
    12b0:      	mov	w13, #0x2bda            ; =11226
    12b4:      	movk	w13, #0x3950, lsl #16
    12b8:      	dup.4s	v25, w13
    12bc:      	mov	w13, #0x96c9            ; =38601
    12c0:      	movk	w13, #0x3ab6, lsl #16
    12c4:      	dup.4s	v20, w13
    12c8:      	fmov.4s	v24, #9.00000000
    12cc:      	xtn.2s	v19, v5
    12d0:      	xtn.2s	v21, v6
    12d4:      	xtn.2s	v1, v4
    12d8:      	str	d1, [sp, #0xe0]
    12dc:      	mov	w13, #0x88a6            ; =34982
    12e0:      	movk	w13, #0x3c08, lsl #16
    12e4:      	dup.4s	v23, w13
    12e8:      	mov	w13, #0xaa7a            ; =43642
    12ec:      	movk	w13, #0x3d2a, lsl #16
    12f0:      	dup.4s	v26, w13
    12f4:      	fmov.4s	v31, #0.25000000
    12f8:      	mov	w13, #0x1001            ; =4097
    12fc:      	dup.2s	v11, w13
    1300:      	cmp	w12, #0x1
    1304:      	str	q10, [sp, #0x190]
    1308:      	b.ne	0x1820 <_llm_rows.packet_batch.blocks+0x940>
    130c:      	cbz	w10, 0x1820 <_llm_rows.packet_batch.blocks+0x940>
    1310:      	str	d11, [sp, #0x20]
    1314:      	str	d21, [sp, #0x30]
    1318:      	str	d19, [sp, #0x40]
    131c:      	str	q17, [sp, #0x50]
    1320:      	str	q16, [sp, #0xa0]
    1324:      	str	q18, [sp, #0x120]
    1328:      	mov	x10, #0x0               ; =0
    132c:      	add	x12, x8, x14
    1330:      	add	x13, x9, x14
    1334:      	add	x14, x11, x14
    1338:      	ldr	q4, [sp, #0x130]
    133c:      	and.16b	v3, v3, v4
    1340:      	addv.8h	h11, v3
    1344:      	fmov	w15, s11
    1348:      	movi.4s	v2, #0x3f, lsl #24
    134c:      	b	0x135c <_llm_rows.packet_batch.blocks+0x47c>
    1350:      	add	x10, x10, #0x20
    1354:      	cmp	x10, #0x4, lsl #12      ; =0x4000
    1358:      	b.eq	0x255c <_llm_rows.packet_batch.blocks+0x167c>
    135c:      	add	x16, x14, x10
    1360:      	movi.2d	v15, #0000000000000000
    1364:      	movi.2d	v12, #0000000000000000
    1368:      	tbz	w15, #0x0, 0x13fc <_llm_rows.packet_batch.blocks+0x51c>
    136c:      	ldr	s15, [x16]
    1370:      	and	w17, w15, #0xff
    1374:      	tbnz	w17, #0x1, 0x1404 <_llm_rows.packet_batch.blocks+0x524>
    1378:      	tbz	w17, #0x2, 0x1410 <_llm_rows.packet_batch.blocks+0x530>
    137c:      	add	x0, x16, #0x8
    1380:      	ld1.s	{ v15 }[2], [x0]
    1384:      	tbnz	w17, #0x3, 0x1414 <_llm_rows.packet_batch.blocks+0x534>
    1388:      	tbz	w17, #0x4, 0x1420 <_llm_rows.packet_batch.blocks+0x540>
    138c:      	add	x0, x16, #0x10
    1390:      	ld1.s	{ v12 }[0], [x0]
    1394:      	tbnz	w17, #0x5, 0x1424 <_llm_rows.packet_batch.blocks+0x544>
    1398:      	tbz	w17, #0x6, 0x1430 <_llm_rows.packet_batch.blocks+0x550>
    139c:      	add	x0, x16, #0x18
    13a0:      	ld1.s	{ v12 }[2], [x0]
    13a4:      	tbnz	w17, #0x7, 0x1434 <_llm_rows.packet_batch.blocks+0x554>
    13a8:      	fmov	w17, s11
    13ac:      	add	x16, x13, x10
    13b0:      	movi.2d	v3, #0000000000000000
    13b4:      	movi.2d	v14, #0000000000000000
    13b8:      	tbz	w17, #0x0, 0x1450 <_llm_rows.packet_batch.blocks+0x570>
    13bc:      	ldr	s3, [x16]
    13c0:      	and	w17, w17, #0xff
    13c4:      	tbnz	w17, #0x1, 0x1458 <_llm_rows.packet_batch.blocks+0x578>
    13c8:      	tbz	w17, #0x2, 0x1464 <_llm_rows.packet_batch.blocks+0x584>
    13cc:      	add	x0, x16, #0x8
    13d0:      	ld1.s	{ v3 }[2], [x0]
    13d4:      	tbnz	w17, #0x3, 0x1468 <_llm_rows.packet_batch.blocks+0x588>
    13d8:      	tbz	w17, #0x4, 0x1474 <_llm_rows.packet_batch.blocks+0x594>
    13dc:      	add	x0, x16, #0x10
    13e0:      	ld1.s	{ v14 }[0], [x0]
    13e4:      	tbnz	w17, #0x5, 0x1478 <_llm_rows.packet_batch.blocks+0x598>
    13e8:      	tbz	w17, #0x6, 0x1484 <_llm_rows.packet_batch.blocks+0x5a4>
    13ec:      	add	x0, x16, #0x18
    13f0:      	ld1.s	{ v14 }[2], [x0]
    13f4:      	tbnz	w17, #0x7, 0x1488 <_llm_rows.packet_batch.blocks+0x5a8>
    13f8:      	b	0x1490 <_llm_rows.packet_batch.blocks+0x5b0>
    13fc:      	and	w17, w15, #0xff
    1400:      	tbz	w17, #0x1, 0x1378 <_llm_rows.packet_batch.blocks+0x498>
    1404:      	add	x0, x16, #0x4
    1408:      	ld1.s	{ v15 }[1], [x0]
    140c:      	tbnz	w17, #0x2, 0x137c <_llm_rows.packet_batch.blocks+0x49c>
    1410:      	tbz	w17, #0x3, 0x1388 <_llm_rows.packet_batch.blocks+0x4a8>
    1414:      	add	x0, x16, #0xc
    1418:      	ld1.s	{ v15 }[3], [x0]
    141c:      	tbnz	w17, #0x4, 0x138c <_llm_rows.packet_batch.blocks+0x4ac>
    1420:      	tbz	w17, #0x5, 0x1398 <_llm_rows.packet_batch.blocks+0x4b8>
    1424:      	add	x0, x16, #0x14
    1428:      	ld1.s	{ v12 }[1], [x0]
    142c:      	tbnz	w17, #0x6, 0x139c <_llm_rows.packet_batch.blocks+0x4bc>
    1430:      	tbz	w17, #0x7, 0x13a8 <_llm_rows.packet_batch.blocks+0x4c8>
    1434:      	add	x16, x16, #0x1c
    1438:      	ld1.s	{ v12 }[3], [x16]
    143c:      	fmov	w17, s11
    1440:      	add	x16, x13, x10
    1444:      	movi.2d	v3, #0000000000000000
    1448:      	movi.2d	v14, #0000000000000000
    144c:      	tbnz	w17, #0x0, 0x13bc <_llm_rows.packet_batch.blocks+0x4dc>
    1450:      	and	w17, w17, #0xff
    1454:      	tbz	w17, #0x1, 0x13c8 <_llm_rows.packet_batch.blocks+0x4e8>
    1458:      	add	x0, x16, #0x4
    145c:      	ld1.s	{ v3 }[1], [x0]
    1460:      	tbnz	w17, #0x2, 0x13cc <_llm_rows.packet_batch.blocks+0x4ec>
    1464:      	tbz	w17, #0x3, 0x13d8 <_llm_rows.packet_batch.blocks+0x4f8>
    1468:      	add	x0, x16, #0xc
    146c:      	ld1.s	{ v3 }[3], [x0]
    1470:      	tbnz	w17, #0x4, 0x13dc <_llm_rows.packet_batch.blocks+0x4fc>
    1474:      	tbz	w17, #0x5, 0x13e8 <_llm_rows.packet_batch.blocks+0x508>
    1478:      	add	x0, x16, #0x14
    147c:      	ld1.s	{ v14 }[1], [x0]
    1480:      	tbnz	w17, #0x6, 0x13ec <_llm_rows.packet_batch.blocks+0x50c>
    1484:      	tbz	w17, #0x7, 0x1490 <_llm_rows.packet_batch.blocks+0x5b0>
    1488:      	add	x16, x16, #0x1c
    148c:      	ld1.s	{ v14 }[3], [x16]
    1490:      	ldp	q5, q1, [sp, #0x1c0]
    1494:      	fmul.4s	v4, v15, v5
    1498:      	fmul.4s	v4, v15, v4
    149c:      	fmul.4s	v4, v15, v4
    14a0:      	fadd.4s	v4, v15, v4
    14a4:      	fmul.4s	v4, v4, v1
    14a8:      	and.16b	v4, v9, v4
    14ac:      	fabs.4s	v5, v4
    14b0:      	fmul.4s	v6, v4, v4
    14b4:      	ldr	q7, [sp, #0x220]
    14b8:      	ldp	q17, q1, [sp, #0x1f0]
    14bc:      	fmla.4s	v7, v6, v1
    14c0:      	ldp	q16, q21, [sp, #0x240]
    14c4:      	fmla.4s	v16, v6, v7
    14c8:      	mov.16b	v7, v10
    14cc:      	fmla.4s	v7, v6, v16
    14d0:      	mov.16b	v16, v22
    14d4:      	fmla.4s	v16, v6, v7
    14d8:      	mov.16b	v7, v21
    14dc:      	fmla.4s	v7, v6, v16
    14e0:      	mov.16b	v16, v0
    14e4:      	fmla.4s	v16, v6, v7
    14e8:      	fmul.4s	v7, v5, v16
    14ec:      	ldr	q16, [sp, #0x1e0]
    14f0:      	fmla.4s	v16, v6, v29
    14f4:      	fmla.4s	v17, v6, v16
    14f8:      	ldr	q16, [sp, #0x210]
    14fc:      	fmla.4s	v16, v6, v17
    1500:      	ldr	q17, [sp, #0x230]
    1504:      	fmla.4s	v17, v6, v16
    1508:      	movi.4s	v16, #0x3f, lsl #24
    150c:      	fmla.4s	v16, v6, v17
    1510:      	mov.16b	v17, v0
    1514:      	fmla.4s	v17, v6, v16
    1518:      	fdiv.4s	v6, v7, v17
    151c:      	fcmge.4s	v7, v24, v5
    1520:      	and.16b	v16, v7, v5
    1524:      	fcmge.4s	v17, v16, v28
    1528:      	ldr	q1, [sp, #0x260]
    152c:      	fcmge.4s	v18, v1, v16
    1530:      	and.16b	v17, v17, v18
    1534:      	and.16b	v17, v17, v16
    1538:      	fmul.4s	v18, v17, v30
    153c:      	movi.4s	v19, #0x4b, lsl #24
    1540:      	fadd.4s	v18, v18, v19
    1544:      	movi.4s	v19, #0xcb, lsl #24
    1548:      	fadd.4s	v18, v18, v19
    154c:      	fcvtzs.4s	v18, v18
    1550:      	scvtf.4s	v13, v18
    1554:      	fmul.4s	v19, v13, v8
    1558:      	fadd.4s	v17, v17, v19
    155c:      	fmul.4s	v19, v13, v27
    1560:      	fadd.4s	v17, v17, v19
    1564:      	fmul.4s	v19, v17, v25
    1568:      	fadd.4s	v19, v19, v20
    156c:      	fmul.4s	v19, v17, v19
    1570:      	fadd.4s	v19, v19, v23
    1574:      	fmul.4s	v19, v17, v19
    1578:      	fadd.4s	v19, v19, v26
    157c:      	fmul.4s	v19, v17, v19
    1580:      	fadd.4s	v19, v19, v21
    1584:      	fmul.4s	v19, v17, v19
    1588:      	fadd.4s	v19, v19, v2
    158c:      	fmul.4s	v13, v17, v17
    1590:      	fmul.4s	v19, v13, v19
    1594:      	fadd.4s	v17, v17, v19
    1598:      	fadd.4s	v17, v17, v0
    159c:      	movi.2d	v19, #0xffffffffffffffff
    15a0:      	add.4s	v18, v18, v19
    15a4:      	sshr.4s	v19, v18, #0x1
    15a8:      	shl.4s	v13, v19, #0x17
    15ac:      	add.4s	v13, v13, v0
    15b0:      	fmul.4s	v17, v17, v13
    15b4:      	sub.4s	v18, v18, v19
    15b8:      	shl.4s	v18, v18, #0x17
    15bc:      	add.4s	v18, v18, v0
    15c0:      	fmul.4s	v17, v17, v18
    15c4:      	fcmgt.4s	v16, v16, v1
    15c8:      	ldr	q18, [sp, #0x1b0]
    15cc:      	bsl.16b	v16, v18, v17
    15d0:      	fdiv.4s	v17, v31, v16
    15d4:      	fsub.4s	v18, v16, v17
    15d8:      	fadd.4s	v16, v16, v17
    15dc:      	fdiv.4s	v16, v18, v16
    15e0:      	bsl.16b	v7, v16, v0
    15e4:      	fcmge.4s	v5, v0, v5
    15e8:      	bsl.16b	v5, v6, v7
    15ec:      	mvni.4s	v6, #0x80, lsl #24
    15f0:      	bif.16b	v5, v4, v6
    15f4:      	fcmeq.4s	v4, v4, v4
    15f8:      	fadd.4s	v5, v5, v0
    15fc:      	ldr	q6, [sp, #0x1a0]
    1600:      	bsl.16b	v4, v5, v6
    1604:      	fmul.4s	v5, v15, v2
    1608:      	fmul.4s	v4, v5, v4
    160c:      	fadd.4s	v3, v3, v4
    1610:      	fmov	w17, s11
    1614:      	add	x16, x12, x10
    1618:      	tbz	w17, #0x0, 0x163c <_llm_rows.packet_batch.blocks+0x75c>
    161c:      	str	s3, [x16]
    1620:      	and	w17, w17, #0xff
    1624:      	tbnz	w17, #0x1, 0x1644 <_llm_rows.packet_batch.blocks+0x764>
    1628:      	tbz	w17, #0x2, 0x1650 <_llm_rows.packet_batch.blocks+0x770>
    162c:      	add	x0, x16, #0x8
    1630:      	st1.s	{ v3 }[2], [x0]
    1634:      	tbnz	w17, #0x3, 0x1654 <_llm_rows.packet_batch.blocks+0x774>
    1638:      	b	0x165c <_llm_rows.packet_batch.blocks+0x77c>
    163c:      	and	w17, w17, #0xff
    1640:      	tbz	w17, #0x1, 0x1628 <_llm_rows.packet_batch.blocks+0x748>
    1644:      	add	x0, x16, #0x4
    1648:      	st1.s	{ v3 }[1], [x0]
    164c:      	tbnz	w17, #0x2, 0x162c <_llm_rows.packet_batch.blocks+0x74c>
    1650:      	tbz	w17, #0x3, 0x165c <_llm_rows.packet_batch.blocks+0x77c>
    1654:      	add	x0, x16, #0xc
    1658:      	st1.s	{ v3 }[3], [x0]
    165c:      	ldp	q4, q1, [sp, #0x1c0]
    1660:      	fmul.4s	v3, v12, v4
    1664:      	fmul.4s	v3, v12, v3
    1668:      	fmul.4s	v3, v12, v3
    166c:      	fadd.4s	v3, v12, v3
    1670:      	fmul.4s	v3, v3, v1
    1674:      	ldr	q1, [sp, #0x180]
    1678:      	and.16b	v3, v1, v3
    167c:      	fabs.4s	v4, v3
    1680:      	fmul.4s	v5, v3, v3
    1684:      	ldr	q6, [sp, #0x220]
    1688:      	ldp	q16, q1, [sp, #0x1f0]
    168c:      	fmla.4s	v6, v5, v1
    1690:      	ldp	q7, q21, [sp, #0x240]
    1694:      	fmla.4s	v7, v5, v6
    1698:      	mov.16b	v6, v10
    169c:      	fmla.4s	v6, v5, v7
    16a0:      	mov.16b	v7, v22
    16a4:      	fmla.4s	v7, v5, v6
    16a8:      	mov.16b	v6, v21
    16ac:      	fmla.4s	v6, v5, v7
    16b0:      	mov.16b	v7, v0
    16b4:      	fmla.4s	v7, v5, v6
    16b8:      	fmul.4s	v6, v4, v7
    16bc:      	ldr	q7, [sp, #0x1e0]
    16c0:      	fmla.4s	v7, v5, v29
    16c4:      	fmla.4s	v16, v5, v7
    16c8:      	ldr	q7, [sp, #0x210]
    16cc:      	fmla.4s	v7, v5, v16
    16d0:      	ldr	q16, [sp, #0x230]
    16d4:      	fmla.4s	v16, v5, v7
    16d8:      	movi.4s	v7, #0x3f, lsl #24
    16dc:      	fmla.4s	v7, v5, v16
    16e0:      	mov.16b	v16, v0
    16e4:      	fmla.4s	v16, v5, v7
    16e8:      	fdiv.4s	v5, v6, v16
    16ec:      	fcmge.4s	v6, v24, v4
    16f0:      	and.16b	v7, v6, v4
    16f4:      	fcmge.4s	v16, v7, v28
    16f8:      	ldr	q1, [sp, #0x260]
    16fc:      	fcmge.4s	v17, v1, v7
    1700:      	and.16b	v16, v16, v17
    1704:      	and.16b	v16, v16, v7
    1708:      	fmul.4s	v17, v16, v30
    170c:      	movi.4s	v18, #0x4b, lsl #24
    1710:      	fadd.4s	v17, v17, v18
    1714:      	movi.4s	v18, #0xcb, lsl #24
    1718:      	fadd.4s	v17, v17, v18
    171c:      	fcvtzs.4s	v17, v17
    1720:      	scvtf.4s	v18, v17
    1724:      	fmul.4s	v19, v18, v8
    1728:      	fadd.4s	v16, v16, v19
    172c:      	fmul.4s	v18, v18, v27
    1730:      	fadd.4s	v16, v16, v18
    1734:      	fmul.4s	v18, v16, v25
    1738:      	fadd.4s	v18, v18, v20
    173c:      	fmul.4s	v18, v16, v18
    1740:      	fadd.4s	v18, v18, v23
    1744:      	fmul.4s	v18, v16, v18
    1748:      	fadd.4s	v18, v18, v26
    174c:      	fmul.4s	v18, v16, v18
    1750:      	fadd.4s	v18, v18, v21
    1754:      	fmul.4s	v18, v16, v18
    1758:      	fadd.4s	v18, v18, v2
    175c:      	fmul.4s	v19, v16, v16
    1760:      	fmul.4s	v18, v19, v18
    1764:      	fadd.4s	v16, v16, v18
    1768:      	fadd.4s	v16, v16, v0
    176c:      	movi.2d	v18, #0xffffffffffffffff
    1770:      	add.4s	v17, v17, v18
    1774:      	sshr.4s	v18, v17, #0x1
    1778:      	shl.4s	v19, v18, #0x17
    177c:      	add.4s	v19, v19, v0
    1780:      	fmul.4s	v16, v16, v19
    1784:      	sub.4s	v17, v17, v18
    1788:      	shl.4s	v17, v17, #0x17
    178c:      	add.4s	v17, v17, v0
    1790:      	fmul.4s	v16, v16, v17
    1794:      	fcmgt.4s	v7, v7, v1
    1798:      	ldr	q17, [sp, #0x1b0]
    179c:      	bsl.16b	v7, v17, v16
    17a0:      	fdiv.4s	v16, v31, v7
    17a4:      	fsub.4s	v17, v7, v16
    17a8:      	fadd.4s	v7, v7, v16
    17ac:      	fdiv.4s	v7, v17, v7
    17b0:      	bsl.16b	v6, v7, v0
    17b4:      	fcmge.4s	v4, v0, v4
    17b8:      	bsl.16b	v4, v5, v6
    17bc:      	mvni.4s	v5, #0x80, lsl #24
    17c0:      	bif.16b	v4, v3, v5
    17c4:      	fcmeq.4s	v3, v3, v3
    17c8:      	fadd.4s	v4, v4, v0
    17cc:      	ldr	q5, [sp, #0x1a0]
    17d0:      	bsl.16b	v3, v4, v5
    17d4:      	fmul.4s	v4, v12, v2
    17d8:      	fmul.4s	v3, v4, v3
    17dc:      	fadd.4s	v3, v14, v3
    17e0:      	tbz	w17, #0x4, 0x1800 <_llm_rows.packet_batch.blocks+0x920>
    17e4:      	str	s3, [x16, #0x10]
    17e8:      	tbnz	w17, #0x5, 0x1804 <_llm_rows.packet_batch.blocks+0x924>
    17ec:      	tbz	w17, #0x6, 0x1810 <_llm_rows.packet_batch.blocks+0x930>
    17f0:      	add	x0, x16, #0x18
    17f4:      	st1.s	{ v3 }[2], [x0]
    17f8:      	tbz	w17, #0x7, 0x1350 <_llm_rows.packet_batch.blocks+0x470>
    17fc:      	b	0x1814 <_llm_rows.packet_batch.blocks+0x934>
    1800:      	tbz	w17, #0x5, 0x17ec <_llm_rows.packet_batch.blocks+0x90c>
    1804:      	add	x0, x16, #0x14
    1808:      	st1.s	{ v3 }[1], [x0]
    180c:      	tbnz	w17, #0x6, 0x17f0 <_llm_rows.packet_batch.blocks+0x910>
    1810:      	tbz	w17, #0x7, 0x1350 <_llm_rows.packet_batch.blocks+0x470>
    1814:      	add	x16, x16, #0x1c
    1818:      	st1.s	{ v3 }[3], [x16]
    181c:      	b	0x1350 <_llm_rows.packet_batch.blocks+0x470>
    1820:      	mov	x10, #0x0               ; =0
    1824:      	add	x12, x11, x14
    1828:      	movi.4s	v2, #0x3f, lsl #24
    182c:      	ldr	q1, [sp, #0x180]
    1830:      	b	0x1854 <_llm_rows.packet_batch.blocks+0x974>
    1834:      	add	x13, x24, x10
    1838:      	ldp	q6, q7, [x13]
    183c:      	bif.16b	v5, v7, v1
    1840:      	bif.16b	v4, v6, v9
    1844:      	stp	q4, q5, [x13]
    1848:      	add	x10, x10, #0x20
    184c:      	cmp	x10, #0x4, lsl #12      ; =0x4000
    1850:      	b.eq	0x18f8 <_llm_rows.packet_batch.blocks+0xa18>
    1854:      	ldr	q4, [sp, #0x130]
    1858:      	and.16b	v4, v3, v4
    185c:      	addv.8h	h14, v4
    1860:      	fmov	w14, s14
    1864:      	add	x13, x12, x10
    1868:      	movi.2d	v4, #0000000000000000
    186c:      	movi.2d	v5, #0000000000000000
    1870:      	tbz	w14, #0x0, 0x18b4 <_llm_rows.packet_batch.blocks+0x9d4>
    1874:      	ldr	s4, [x13]
    1878:      	and	w14, w14, #0xff
    187c:      	tbnz	w14, #0x1, 0x18bc <_llm_rows.packet_batch.blocks+0x9dc>
    1880:      	tbz	w14, #0x2, 0x18c8 <_llm_rows.packet_batch.blocks+0x9e8>
    1884:      	add	x15, x13, #0x8
    1888:      	ld1.s	{ v4 }[2], [x15]
    188c:      	tbnz	w14, #0x3, 0x18cc <_llm_rows.packet_batch.blocks+0x9ec>
    1890:      	tbz	w14, #0x4, 0x18d8 <_llm_rows.packet_batch.blocks+0x9f8>
    1894:      	add	x15, x13, #0x10
    1898:      	ld1.s	{ v5 }[0], [x15]
    189c:      	tbnz	w14, #0x5, 0x18dc <_llm_rows.packet_batch.blocks+0x9fc>
    18a0:      	tbz	w14, #0x6, 0x18e8 <_llm_rows.packet_batch.blocks+0xa08>
    18a4:      	add	x15, x13, #0x18
    18a8:      	ld1.s	{ v5 }[2], [x15]
    18ac:      	tbz	w14, #0x7, 0x1834 <_llm_rows.packet_batch.blocks+0x954>
    18b0:      	b	0x18ec <_llm_rows.packet_batch.blocks+0xa0c>
    18b4:      	and	w14, w14, #0xff
    18b8:      	tbz	w14, #0x1, 0x1880 <_llm_rows.packet_batch.blocks+0x9a0>
    18bc:      	add	x15, x13, #0x4
    18c0:      	ld1.s	{ v4 }[1], [x15]
    18c4:      	tbnz	w14, #0x2, 0x1884 <_llm_rows.packet_batch.blocks+0x9a4>
    18c8:      	tbz	w14, #0x3, 0x1890 <_llm_rows.packet_batch.blocks+0x9b0>
    18cc:      	add	x15, x13, #0xc
    18d0:      	ld1.s	{ v4 }[3], [x15]
    18d4:      	tbnz	w14, #0x4, 0x1894 <_llm_rows.packet_batch.blocks+0x9b4>
    18d8:      	tbz	w14, #0x5, 0x18a0 <_llm_rows.packet_batch.blocks+0x9c0>
    18dc:      	add	x15, x13, #0x14
    18e0:      	ld1.s	{ v5 }[1], [x15]
    18e4:      	tbnz	w14, #0x6, 0x18a4 <_llm_rows.packet_batch.blocks+0x9c4>
    18e8:      	tbz	w14, #0x7, 0x1834 <_llm_rows.packet_batch.blocks+0x954>
    18ec:      	add	x13, x13, #0x1c
    18f0:      	ld1.s	{ v5 }[3], [x13]
    18f4:      	b	0x1834 <_llm_rows.packet_batch.blocks+0x954>
    18f8:      	xtn.4h	v3, v9
    18fc:      	uzp1.8b	v4, v3, v0
    1900:      	movi.2d	v5, #0000000000000000
    1904:      	mov.b	v5[0], v4[0]
    1908:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x120>
    190c:      	ldr	d3, [x10]
    1910:      	str	d3, [sp, #0x20]
    1914:      	and.8b	v3, v5, v3
    1918:      	addv.8b	b3, v3
    191c:      	fmov	w13, s3
    1920:      	str	q5, [sp, #0xa0]
    1924:      	umaxv.8b	b3, v5
    1928:      	fmov	w14, s3
    192c:      	rbit	w10, w13
    1930:      	clz	w10, w10
    1934:      	tst	w14, #0x1
    1938:      	csel	w10, w10, wzr, ne
    193c:      	mov	w12, #0x1000            ; =4096
    1940:      	dup.2d	v3, x12
    1944:      	ldr	d5, [sp, #0xf0]
    1948:      	ldr	q6, [sp, #0xd0]
    194c:      	umlal.2d	v6, v5, v11
    1950:      	movi.2d	v5, #0000000000000000
    1954:      	mov.b	v5[0], v4[0]
    1958:      	add.2d	v6, v6, v3
    195c:      	ushll.2d	v4, v5, #0x0
    1960:      	shl.2d	v4, v4, #0x3f
    1964:      	cmlt.2d	v4, v4, #0
    1968:      	str	q6, [sp, #0x50]
    196c:      	and.16b	v4, v4, v6
    1970:      	movi.2d	v5, #0000000000000000
    1974:      	stp	q5, q5, [sp, #0x3b0]
    1978:      	stp	q4, q5, [sp, #0x390]
    197c:      	and	x12, x10, #0x7
    1980:      	add	x15, sp, #0x390
    1984:      	ldr	x12, [x15, x12, lsl #3]
    1988:      	sub	x12, x12, x10
    198c:      	lsl	x12, x12, #2
    1990:      	add	x11, x11, x12
    1994:      	movi.2d	v4, #0000000000000000
    1998:      	tbz	w14, #0x0, 0x19dc <_llm_rows.packet_batch.blocks+0xafc>
    199c:      	ldr	s5, [x11]
    19a0:      	tbnz	w13, #0x1, 0x19e0 <_llm_rows.packet_batch.blocks+0xb00>
    19a4:      	tbz	w13, #0x2, 0x19ec <_llm_rows.packet_batch.blocks+0xb0c>
    19a8:      	add	x14, x11, #0x8
    19ac:      	ld1.s	{ v5 }[2], [x14]
    19b0:      	tbnz	w13, #0x3, 0x19f0 <_llm_rows.packet_batch.blocks+0xb10>
    19b4:      	tbz	w13, #0x4, 0x19fc <_llm_rows.packet_batch.blocks+0xb1c>
    19b8:      	add	x14, x11, #0x10
    19bc:      	ld1.s	{ v4 }[0], [x14]
    19c0:      	tbnz	w13, #0x5, 0x1a00 <_llm_rows.packet_batch.blocks+0xb20>
    19c4:      	tbz	w13, #0x6, 0x1a0c <_llm_rows.packet_batch.blocks+0xb2c>
    19c8:      	add	x14, x11, #0x18
    19cc:      	ld1.s	{ v4 }[2], [x14]
    19d0:      	str	q5, [sp, #0xd0]
    19d4:      	tbnz	w13, #0x7, 0x1a14 <_llm_rows.packet_batch.blocks+0xb34>
    19d8:      	b	0x1a1c <_llm_rows.packet_batch.blocks+0xb3c>
    19dc:      	tbz	w13, #0x1, 0x19a4 <_llm_rows.packet_batch.blocks+0xac4>
    19e0:      	add	x14, x11, #0x4
    19e4:      	ld1.s	{ v5 }[1], [x14]
    19e8:      	tbnz	w13, #0x2, 0x19a8 <_llm_rows.packet_batch.blocks+0xac8>
    19ec:      	tbz	w13, #0x3, 0x19b4 <_llm_rows.packet_batch.blocks+0xad4>
    19f0:      	add	x14, x11, #0xc
    19f4:      	ld1.s	{ v5 }[3], [x14]
    19f8:      	tbnz	w13, #0x4, 0x19b8 <_llm_rows.packet_batch.blocks+0xad8>
    19fc:      	tbz	w13, #0x5, 0x19c4 <_llm_rows.packet_batch.blocks+0xae4>
    1a00:      	add	x14, x11, #0x14
    1a04:      	ld1.s	{ v4 }[1], [x14]
    1a08:      	tbnz	w13, #0x6, 0x19c8 <_llm_rows.packet_batch.blocks+0xae8>
    1a0c:      	str	q5, [sp, #0xd0]
    1a10:      	tbz	w13, #0x7, 0x1a1c <_llm_rows.packet_batch.blocks+0xb3c>
    1a14:      	add	x11, x11, #0x1c
    1a18:      	ld1.s	{ v4 }[3], [x11]
    1a1c:      	mov.16b	v13, v4
    1a20:      	mov	x15, #0x0               ; =0
    1a24:      	ldr	d4, [sp, #0xf0]
    1a28:      	umull.2d	v4, v4, v11
    1a2c:      	ldr	d5, [sp, #0xe0]
    1a30:      	umlal.2d	v17, v5, v11
    1a34:      	add.2d	v5, v17, v3
    1a38:      	str	q5, [sp, #0xe0]
    1a3c:      	umlal.2d	v16, v21, v11
    1a40:      	add.2d	v5, v16, v3
    1a44:      	str	q5, [sp, #0x40]
    1a48:      	umlal.2d	v18, v19, v11
    1a4c:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x120>
    1a50:      	ldr	q5, [x11]
    1a54:      	mov	w11, #0x4000            ; =16384
    1a58:      	dup.2d	v6, x11
    1a5c:      	sshll.2d	v7, v9, #0x0
    1a60:      	bif.16b	v5, v6, v7
    1a64:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x120>
    1a68:      	ldr	q7, [x11]
    1a6c:      	sshll.2d	v16, v1, #0x0
    1a70:      	bif.16b	v7, v6, v16
    1a74:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x120>
    1a78:      	ldr	q16, [x11]
    1a7c:      	bif.16b	v16, v6, v15
    1a80:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x120>
    1a84:      	ldr	q17, [x11]
    1a88:      	bit.16b	v6, v17, v12
    1a8c:      	stp	q7, q6, [sp, #0x370]
    1a90:      	stp	q5, q16, [sp, #0x350]
    1a94:      	and	x11, x10, #0x7
    1a98:      	add	x14, sp, #0x350
    1a9c:      	ldr	x11, [x14, x11, lsl #3]
    1aa0:      	add.2d	v3, v18, v3
    1aa4:      	str	q3, [sp, #0x30]
    1aa8:      	sub	x11, x11, x10, lsl #2
    1aac:      	tst	w13, #0xff
    1ab0:      	csel	x11, xzr, x11, eq
    1ab4:      	add	x13, x24, x11
    1ab8:      	ldp	q3, q5, [x13]
    1abc:      	ldr	q19, [sp, #0xa0]
    1ac0:      	zip2.8b	v6, v19, v0
    1ac4:      	ushll.4s	v6, v6, #0x0
    1ac8:      	shl.4s	v6, v6, #0x1f
    1acc:      	cmlt.4s	v6, v6, #0
    1ad0:      	str	q13, [sp, #0xf0]
    1ad4:      	bit.16b	v5, v13, v6
    1ad8:      	zip1.8b	v6, v19, v0
    1adc:      	ushll.4s	v6, v6, #0x0
    1ae0:      	shl.4s	v6, v6, #0x1f
    1ae4:      	cmlt.4s	v6, v6, #0
    1ae8:      	ldr	q7, [sp, #0xd0]
    1aec:      	bit.16b	v3, v7, v6
    1af0:      	stp	q3, q5, [x13]
    1af4:      	fmov	x13, d4
    1af8:      	lsl	x13, x13, #2
    1afc:      	mov	w14, #0x1               ; =1
    1b00:      	dup.2d	v3, x14
    1b04:      	add	x14, x9, x13
    1b08:      	ushll2.2d	v4, v1, #0x0
    1b0c:      	and.16b	v21, v4, v3
    1b10:      	ushll2.2d	v4, v9, #0x0
    1b14:      	and.16b	v11, v4, v3
    1b18:      	ushll.2d	v4, v1, #0x0
    1b1c:      	and.16b	v12, v4, v3
    1b20:      	ushll.2d	v4, v9, #0x0
    1b24:      	and.16b	v13, v4, v3
    1b28:      	movi.2d	v3, #0000000000000000
    1b2c:      	movi.2d	v4, #0000000000000000
    1b30:      	movi.2d	v5, #0000000000000000
    1b34:      	movi.2d	v6, #0000000000000000
    1b38:      	b	0x1b6c <_llm_rows.packet_batch.blocks+0xc8c>
    1b3c:      	add	x15, x26, x15
    1b40:      	ldp	q17, q18, [x15]
    1b44:      	bif.16b	v16, v18, v1
    1b48:      	bif.16b	v7, v17, v9
    1b4c:      	stp	q7, q16, [x15]
    1b50:      	add.2d	v4, v4, v11
    1b54:      	add.2d	v5, v5, v12
    1b58:      	add.2d	v6, v6, v21
    1b5c:      	add.2d	v3, v3, v13
    1b60:      	fmov	x15, d3
    1b64:      	cmp	x15, #0x200
    1b68:      	b.ge	0x1c08 <_llm_rows.packet_batch.blocks+0xd28>
    1b6c:      	fmov	w17, s14
    1b70:      	lsl	x15, x15, #5
    1b74:      	add	x16, x14, x15
    1b78:      	movi.2d	v7, #0000000000000000
    1b7c:      	movi.2d	v16, #0000000000000000
    1b80:      	tbz	w17, #0x0, 0x1bc4 <_llm_rows.packet_batch.blocks+0xce4>
    1b84:      	ldr	s7, [x16]
    1b88:      	and	w17, w17, #0xff
    1b8c:      	tbnz	w17, #0x1, 0x1bcc <_llm_rows.packet_batch.blocks+0xcec>
    1b90:      	tbz	w17, #0x2, 0x1bd8 <_llm_rows.packet_batch.blocks+0xcf8>
    1b94:      	add	x0, x16, #0x8
    1b98:      	ld1.s	{ v7 }[2], [x0]
    1b9c:      	tbnz	w17, #0x3, 0x1bdc <_llm_rows.packet_batch.blocks+0xcfc>
    1ba0:      	tbz	w17, #0x4, 0x1be8 <_llm_rows.packet_batch.blocks+0xd08>
    1ba4:      	add	x0, x16, #0x10
    1ba8:      	ld1.s	{ v16 }[0], [x0]
    1bac:      	tbnz	w17, #0x5, 0x1bec <_llm_rows.packet_batch.blocks+0xd0c>
    1bb0:      	tbz	w17, #0x6, 0x1bf8 <_llm_rows.packet_batch.blocks+0xd18>
    1bb4:      	add	x0, x16, #0x18
    1bb8:      	ld1.s	{ v16 }[2], [x0]
    1bbc:      	tbz	w17, #0x7, 0x1b3c <_llm_rows.packet_batch.blocks+0xc5c>
    1bc0:      	b	0x1bfc <_llm_rows.packet_batch.blocks+0xd1c>
    1bc4:      	and	w17, w17, #0xff
    1bc8:      	tbz	w17, #0x1, 0x1b90 <_llm_rows.packet_batch.blocks+0xcb0>
    1bcc:      	add	x0, x16, #0x4
    1bd0:      	ld1.s	{ v7 }[1], [x0]
    1bd4:      	tbnz	w17, #0x2, 0x1b94 <_llm_rows.packet_batch.blocks+0xcb4>
    1bd8:      	tbz	w17, #0x3, 0x1ba0 <_llm_rows.packet_batch.blocks+0xcc0>
    1bdc:      	add	x0, x16, #0xc
    1be0:      	ld1.s	{ v7 }[3], [x0]
    1be4:      	tbnz	w17, #0x4, 0x1ba4 <_llm_rows.packet_batch.blocks+0xcc4>
    1be8:      	tbz	w17, #0x5, 0x1bb0 <_llm_rows.packet_batch.blocks+0xcd0>
    1bec:      	add	x0, x16, #0x14
    1bf0:      	ld1.s	{ v16 }[1], [x0]
    1bf4:      	tbnz	w17, #0x6, 0x1bb4 <_llm_rows.packet_batch.blocks+0xcd4>
    1bf8:      	tbz	w17, #0x7, 0x1b3c <_llm_rows.packet_batch.blocks+0xc5c>
    1bfc:      	add	x16, x16, #0x1c
    1c00:      	ld1.s	{ v16 }[3], [x16]
    1c04:      	b	0x1b3c <_llm_rows.packet_batch.blocks+0xc5c>
    1c08:      	add	x9, x9, x12
    1c0c:      	shl.8b	v3, v19, #0x7
    1c10:      	cmlt.8b	v3, v3, #0
    1c14:      	ldr	d1, [sp, #0x20]
    1c18:      	and.8b	v3, v3, v1
    1c1c:      	addv.8b	b1, v3
    1c20:      	str	d1, [sp, #0x8]
    1c24:      	fmov	w12, s1
    1c28:      	movi.2d	v7, #0000000000000000
    1c2c:      	movi.2d	v6, #0000000000000000
    1c30:      	tbz	w12, #0x0, 0x1c80 <_llm_rows.packet_batch.blocks+0xda0>
    1c34:      	ldr	s7, [x9]
    1c38:      	tbnz	w12, #0x1, 0x1c84 <_llm_rows.packet_batch.blocks+0xda4>
    1c3c:      	tbz	w12, #0x2, 0x1c90 <_llm_rows.packet_batch.blocks+0xdb0>
    1c40:      	add	x14, x9, #0x8
    1c44:      	ld1.s	{ v7 }[2], [x14]
    1c48:      	tbnz	w12, #0x3, 0x1c94 <_llm_rows.packet_batch.blocks+0xdb4>
    1c4c:      	tbz	w12, #0x4, 0x1ca0 <_llm_rows.packet_batch.blocks+0xdc0>
    1c50:      	add	x14, x9, #0x10
    1c54:      	ld1.s	{ v6 }[0], [x14]
    1c58:      	tbnz	w12, #0x5, 0x1ca4 <_llm_rows.packet_batch.blocks+0xdc4>
    1c5c:      	tbz	w12, #0x6, 0x1cb0 <_llm_rows.packet_batch.blocks+0xdd0>
    1c60:      	add	x14, x9, #0x18
    1c64:      	ld1.s	{ v6 }[2], [x14]
    1c68:      	str	q14, [sp, #0x120]
    1c6c:      	stp	q23, q26, [sp, #0x160]
    1c70:      	stp	q25, q20, [sp, #0x140]
    1c74:      	mov.16b	v25, v24
    1c78:      	tbnz	w12, #0x7, 0x1cc4 <_llm_rows.packet_batch.blocks+0xde4>
    1c7c:      	b	0x1ccc <_llm_rows.packet_batch.blocks+0xdec>
    1c80:      	tbz	w12, #0x1, 0x1c3c <_llm_rows.packet_batch.blocks+0xd5c>
    1c84:      	add	x14, x9, #0x4
    1c88:      	ld1.s	{ v7 }[1], [x14]
    1c8c:      	tbnz	w12, #0x2, 0x1c40 <_llm_rows.packet_batch.blocks+0xd60>
    1c90:      	tbz	w12, #0x3, 0x1c4c <_llm_rows.packet_batch.blocks+0xd6c>
    1c94:      	add	x14, x9, #0xc
    1c98:      	ld1.s	{ v7 }[3], [x14]
    1c9c:      	tbnz	w12, #0x4, 0x1c50 <_llm_rows.packet_batch.blocks+0xd70>
    1ca0:      	tbz	w12, #0x5, 0x1c5c <_llm_rows.packet_batch.blocks+0xd7c>
    1ca4:      	add	x14, x9, #0x14
    1ca8:      	ld1.s	{ v6 }[1], [x14]
    1cac:      	tbnz	w12, #0x6, 0x1c60 <_llm_rows.packet_batch.blocks+0xd80>
    1cb0:      	str	q14, [sp, #0x120]
    1cb4:      	stp	q23, q26, [sp, #0x160]
    1cb8:      	stp	q25, q20, [sp, #0x140]
    1cbc:      	mov.16b	v25, v24
    1cc0:      	tbz	w12, #0x7, 0x1ccc <_llm_rows.packet_batch.blocks+0xdec>
    1cc4:      	add	x9, x9, #0x1c
    1cc8:      	ld1.s	{ v6 }[3], [x9]
    1ccc:      	mov	x12, #0x0               ; =0
    1cd0:      	add	x9, x26, x11
    1cd4:      	ldp	q3, q4, [x9]
    1cd8:      	zip2.8b	v5, v19, v0
    1cdc:      	ushll.4s	v5, v5, #0x0
    1ce0:      	shl.4s	v5, v5, #0x1f
    1ce4:      	cmlt.4s	v5, v5, #0
    1ce8:      	stp	q7, q6, [sp, #0x10]
    1cec:      	bit.16b	v4, v6, v5
    1cf0:      	zip1.8b	v5, v19, v0
    1cf4:      	ushll.4s	v5, v5, #0x0
    1cf8:      	shl.4s	v5, v5, #0x1f
    1cfc:      	cmlt.4s	v5, v5, #0
    1d00:      	bit.16b	v3, v7, v5
    1d04:      	stp	q3, q4, [x9]
    1d08:      	add	x9, x8, x13
    1d0c:      	movi.2d	v3, #0000000000000000
    1d10:      	movi.2d	v4, #0000000000000000
    1d14:      	movi.2d	v5, #0000000000000000
    1d18:      	movi.2d	v6, #0000000000000000
    1d1c:      	b	0x1d3c <_llm_rows.packet_batch.blocks+0xe5c>
    1d20:      	add.2d	v4, v4, v11
    1d24:      	add.2d	v5, v5, v12
    1d28:      	add.2d	v6, v6, v21
    1d2c:      	add.2d	v3, v3, v13
    1d30:      	fmov	x12, d3
    1d34:      	cmp	x12, #0x200
    1d38:      	b.ge	0x2180 <_llm_rows.packet_batch.blocks+0x12a0>
    1d3c:      	mov.16b	v20, v13
    1d40:      	mov.16b	v26, v12
    1d44:      	mov.16b	v12, v21
    1d48:      	lsl	x11, x12, #5
    1d4c:      	add	x12, x24, x11
    1d50:      	ldr	q7, [x12]
    1d54:      	and.16b	v7, v9, v7
    1d58:      	ldp	q16, q17, [sp, #0x1c0]
    1d5c:      	fmul.4s	v16, v7, v16
    1d60:      	fmul.4s	v16, v7, v16
    1d64:      	fmul.4s	v16, v7, v16
    1d68:      	fadd.4s	v16, v7, v16
    1d6c:      	fmul.4s	v16, v16, v17
    1d70:      	and.16b	v16, v9, v16
    1d74:      	fabs.4s	v17, v16
    1d78:      	fmul.4s	v18, v16, v16
    1d7c:      	ldr	q19, [sp, #0x220]
    1d80:      	ldr	q21, [sp, #0x200]
    1d84:      	fmla.4s	v19, v18, v21
    1d88:      	ldr	q24, [sp, #0x240]
    1d8c:      	fmla.4s	v24, v18, v19
    1d90:      	mov.16b	v19, v10
    1d94:      	fmla.4s	v19, v18, v24
    1d98:      	mov.16b	v24, v22
    1d9c:      	fmla.4s	v24, v18, v19
    1da0:      	ldr	q10, [sp, #0x250]
    1da4:      	mov.16b	v19, v10
    1da8:      	fmla.4s	v19, v18, v24
    1dac:      	mov.16b	v24, v0
    1db0:      	fmla.4s	v24, v18, v19
    1db4:      	fmul.4s	v19, v17, v24
    1db8:      	ldr	q24, [sp, #0x1e0]
    1dbc:      	mov.16b	v13, v29
    1dc0:      	fmla.4s	v24, v18, v29
    1dc4:      	ldr	q29, [sp, #0x1f0]
    1dc8:      	fmla.4s	v29, v18, v24
    1dcc:      	ldr	q24, [sp, #0x210]
    1dd0:      	fmla.4s	v24, v18, v29
    1dd4:      	ldr	q29, [sp, #0x230]
    1dd8:      	fmla.4s	v29, v18, v24
    1ddc:      	movi.4s	v24, #0x3f, lsl #24
    1de0:      	fmla.4s	v24, v18, v29
    1de4:      	mov.16b	v29, v0
    1de8:      	fmla.4s	v29, v18, v24
    1dec:      	fdiv.4s	v18, v19, v29
    1df0:      	fcmge.4s	v19, v25, v17
    1df4:      	and.16b	v24, v19, v17
    1df8:      	mov.16b	v14, v28
    1dfc:      	fcmge.4s	v29, v24, v28
    1e00:      	ldr	q21, [sp, #0x260]
    1e04:      	fcmge.4s	v28, v21, v24
    1e08:      	and.16b	v28, v29, v28
    1e0c:      	and.16b	v28, v28, v24
    1e10:      	mov.16b	v15, v30
    1e14:      	fmul.4s	v29, v28, v30
    1e18:      	mov.16b	v23, v31
    1e1c:      	movi.4s	v31, #0x4b, lsl #24
    1e20:      	fadd.4s	v29, v29, v31
    1e24:      	movi.4s	v31, #0xcb, lsl #24
    1e28:      	fadd.4s	v29, v29, v31
    1e2c:      	fcvtzs.4s	v29, v29
    1e30:      	scvtf.4s	v31, v29
    1e34:      	mov.16b	v30, v8
    1e38:      	fmul.4s	v8, v31, v8
    1e3c:      	fadd.4s	v28, v28, v8
    1e40:      	fmul.4s	v31, v31, v27
    1e44:      	fadd.4s	v28, v28, v31
    1e48:      	ldr	q1, [sp, #0x140]
    1e4c:      	fmul.4s	v31, v28, v1
    1e50:      	ldr	q1, [sp, #0x150]
    1e54:      	fadd.4s	v31, v31, v1
    1e58:      	fmul.4s	v31, v28, v31
    1e5c:      	ldp	q1, q8, [sp, #0x160]
    1e60:      	fadd.4s	v31, v31, v1
    1e64:      	fmul.4s	v31, v28, v31
    1e68:      	fadd.4s	v31, v31, v8
    1e6c:      	fmul.4s	v31, v28, v31
    1e70:      	fadd.4s	v31, v31, v10
    1e74:      	fmul.4s	v31, v28, v31
    1e78:      	fadd.4s	v31, v31, v2
    1e7c:      	fmul.4s	v8, v28, v28
    1e80:      	fmul.4s	v31, v8, v31
    1e84:      	fadd.4s	v28, v28, v31
    1e88:      	fadd.4s	v28, v28, v0
    1e8c:      	movi.2d	v31, #0xffffffffffffffff
    1e90:      	add.4s	v29, v29, v31
    1e94:      	sshr.4s	v31, v29, #0x1
    1e98:      	shl.4s	v8, v31, #0x17
    1e9c:      	add.4s	v8, v8, v0
    1ea0:      	fmul.4s	v28, v28, v8
    1ea4:      	sub.4s	v29, v29, v31
    1ea8:      	shl.4s	v29, v29, #0x17
    1eac:      	add.4s	v29, v29, v0
    1eb0:      	fmul.4s	v28, v28, v29
    1eb4:      	fcmgt.4s	v24, v24, v21
    1eb8:      	ldr	q29, [sp, #0x1b0]
    1ebc:      	bsl.16b	v24, v29, v28
    1ec0:      	fdiv.4s	v28, v23, v24
    1ec4:      	fsub.4s	v29, v24, v28
    1ec8:      	fadd.4s	v24, v24, v28
    1ecc:      	fdiv.4s	v24, v29, v24
    1ed0:      	bsl.16b	v19, v24, v0
    1ed4:      	fcmge.4s	v17, v0, v17
    1ed8:      	bsl.16b	v17, v18, v19
    1edc:      	mvni.4s	v18, #0x80, lsl #24
    1ee0:      	bif.16b	v17, v16, v18
    1ee4:      	fcmeq.4s	v16, v16, v16
    1ee8:      	fadd.4s	v17, v17, v0
    1eec:      	ldr	q18, [sp, #0x1a0]
    1ef0:      	bif.16b	v17, v18, v16
    1ef4:      	ldr	q16, [x12, #0x10]
    1ef8:      	fmul.4s	v7, v7, v2
    1efc:      	fmul.4s	v7, v7, v17
    1f00:      	add	x12, x26, x11
    1f04:      	ldr	q17, [x12]
    1f08:      	and.16b	v17, v9, v17
    1f0c:      	fadd.4s	v17, v17, v7
    1f10:      	ldr	q7, [x12, #0x10]
    1f14:      	ldr	q2, [sp, #0x120]
    1f18:      	fmov	w12, s2
    1f1c:      	add	x11, x9, x11
    1f20:      	tbz	w12, #0x0, 0x1f54 <_llm_rows.packet_batch.blocks+0x1074>
    1f24:      	str	s17, [x11]
    1f28:      	and	w12, w12, #0xff
    1f2c:      	tbnz	w12, #0x1, 0x1f5c <_llm_rows.packet_batch.blocks+0x107c>
    1f30:      	mov.16b	v1, v11
    1f34:      	mov.16b	v21, v13
    1f38:      	ldr	q2, [sp, #0x190]
    1f3c:      	tbz	w12, #0x2, 0x1f74 <_llm_rows.packet_batch.blocks+0x1094>
    1f40:      	add	x13, x11, #0x8
    1f44:      	st1.s	{ v17 }[2], [x13]
    1f48:      	mov.16b	v11, v9
    1f4c:      	tbnz	w12, #0x3, 0x1f7c <_llm_rows.packet_batch.blocks+0x109c>
    1f50:      	b	0x1f84 <_llm_rows.packet_batch.blocks+0x10a4>
    1f54:      	and	w12, w12, #0xff
    1f58:      	tbz	w12, #0x1, 0x1f30 <_llm_rows.packet_batch.blocks+0x1050>
    1f5c:      	add	x13, x11, #0x4
    1f60:      	st1.s	{ v17 }[1], [x13]
    1f64:      	mov.16b	v1, v11
    1f68:      	mov.16b	v21, v13
    1f6c:      	ldr	q2, [sp, #0x190]
    1f70:      	tbnz	w12, #0x2, 0x1f40 <_llm_rows.packet_batch.blocks+0x1060>
    1f74:      	mov.16b	v11, v9
    1f78:      	tbz	w12, #0x3, 0x1f84 <_llm_rows.packet_batch.blocks+0x10a4>
    1f7c:      	add	x13, x11, #0xc
    1f80:      	st1.s	{ v17 }[3], [x13]
    1f84:      	ldr	q9, [sp, #0x180]
    1f88:      	and.16b	v16, v9, v16
    1f8c:      	ldp	q17, q18, [sp, #0x1c0]
    1f90:      	fmul.4s	v17, v16, v17
    1f94:      	fmul.4s	v17, v16, v17
    1f98:      	fmul.4s	v17, v16, v17
    1f9c:      	fadd.4s	v17, v16, v17
    1fa0:      	fmul.4s	v17, v17, v18
    1fa4:      	and.16b	v17, v9, v17
    1fa8:      	fabs.4s	v18, v17
    1fac:      	fmul.4s	v19, v17, v17
    1fb0:      	ldr	q24, [sp, #0x220]
    1fb4:      	ldp	q29, q28, [sp, #0x1f0]
    1fb8:      	fmla.4s	v24, v19, v28
    1fbc:      	ldp	q28, q10, [sp, #0x240]
    1fc0:      	fmla.4s	v28, v19, v24
    1fc4:      	mov.16b	v24, v2
    1fc8:      	fmla.4s	v24, v19, v28
    1fcc:      	mov.16b	v28, v22
    1fd0:      	fmla.4s	v28, v19, v24
    1fd4:      	mov.16b	v24, v10
    1fd8:      	fmla.4s	v24, v19, v28
    1fdc:      	mov.16b	v28, v0
    1fe0:      	fmla.4s	v28, v19, v24
    1fe4:      	fmul.4s	v24, v18, v28
    1fe8:      	ldr	q28, [sp, #0x1e0]
    1fec:      	fmla.4s	v28, v19, v21
    1ff0:      	fmla.4s	v29, v19, v28
    1ff4:      	ldr	q28, [sp, #0x210]
    1ff8:      	fmla.4s	v28, v19, v29
    1ffc:      	ldr	q29, [sp, #0x230]
    2000:      	fmla.4s	v29, v19, v28
    2004:      	movi.4s	v28, #0x3f, lsl #24
    2008:      	fmla.4s	v28, v19, v29
    200c:      	mov.16b	v29, v0
    2010:      	fmla.4s	v29, v19, v28
    2014:      	fdiv.4s	v19, v24, v29
    2018:      	fcmge.4s	v24, v25, v18
    201c:      	and.16b	v28, v24, v18
    2020:      	fcmge.4s	v29, v28, v14
    2024:      	ldr	q2, [sp, #0x260]
    2028:      	fcmge.4s	v31, v2, v28
    202c:      	and.16b	v29, v29, v31
    2030:      	and.16b	v29, v29, v28
    2034:      	fmul.4s	v31, v29, v15
    2038:      	movi.4s	v21, #0x4b, lsl #24
    203c:      	fadd.4s	v31, v31, v21
    2040:      	movi.4s	v21, #0xcb, lsl #24
    2044:      	fadd.4s	v31, v31, v21
    2048:      	fcvtzs.4s	v31, v31
    204c:      	scvtf.4s	v8, v31
    2050:      	fmul.4s	v21, v8, v30
    2054:      	fadd.4s	v21, v29, v21
    2058:      	fmul.4s	v29, v8, v27
    205c:      	fadd.4s	v21, v21, v29
    2060:      	ldp	q29, q8, [sp, #0x140]
    2064:      	fmul.4s	v29, v21, v29
    2068:      	fadd.4s	v29, v29, v8
    206c:      	fmul.4s	v29, v21, v29
    2070:      	ldr	q8, [sp, #0x160]
    2074:      	fadd.4s	v29, v29, v8
    2078:      	fmul.4s	v29, v21, v29
    207c:      	ldr	q8, [sp, #0x170]
    2080:      	fadd.4s	v29, v29, v8
    2084:      	fmul.4s	v29, v21, v29
    2088:      	fadd.4s	v29, v29, v10
    208c:      	fmul.4s	v29, v21, v29
    2090:      	movi.4s	v8, #0x3f, lsl #24
    2094:      	fadd.4s	v29, v29, v8
    2098:      	fmul.4s	v8, v21, v21
    209c:      	fmul.4s	v29, v8, v29
    20a0:      	fadd.4s	v21, v21, v29
    20a4:      	fadd.4s	v21, v21, v0
    20a8:      	movi.2d	v29, #0xffffffffffffffff
    20ac:      	add.4s	v29, v31, v29
    20b0:      	sshr.4s	v31, v29, #0x1
    20b4:      	shl.4s	v8, v31, #0x17
    20b8:      	add.4s	v8, v8, v0
    20bc:      	fmul.4s	v21, v21, v8
    20c0:      	sub.4s	v29, v29, v31
    20c4:      	shl.4s	v29, v29, #0x17
    20c8:      	add.4s	v29, v29, v0
    20cc:      	fmul.4s	v21, v21, v29
    20d0:      	fcmgt.4s	v28, v28, v2
    20d4:      	ldr	q29, [sp, #0x1b0]
    20d8:      	bit.16b	v21, v29, v28
    20dc:      	mov.16b	v31, v23
    20e0:      	fdiv.4s	v28, v23, v21
    20e4:      	fsub.4s	v29, v21, v28
    20e8:      	fadd.4s	v21, v21, v28
    20ec:      	fdiv.4s	v21, v29, v21
    20f0:      	bif.16b	v21, v0, v24
    20f4:      	fcmge.4s	v18, v0, v18
    20f8:      	bsl.16b	v18, v19, v21
    20fc:      	movi.4s	v2, #0x3f, lsl #24
    2100:      	mvni.4s	v19, #0x80, lsl #24
    2104:      	bif.16b	v18, v17, v19
    2108:      	fcmeq.4s	v17, v17, v17
    210c:      	fadd.4s	v18, v18, v0
    2110:      	ldr	q19, [sp, #0x1a0]
    2114:      	bsl.16b	v17, v18, v19
    2118:      	fmul.4s	v16, v16, v2
    211c:      	fmul.4s	v16, v16, v17
    2120:      	and.16b	v7, v9, v7
    2124:      	fadd.4s	v7, v7, v16
    2128:      	tbz	w12, #0x4, 0x2130 <_llm_rows.packet_batch.blocks+0x1250>
    212c:      	str	s7, [x11, #0x10]
    2130:      	mov.16b	v9, v11
    2134:      	mov.16b	v21, v12
    2138:      	tbz	w12, #0x5, 0x2144 <_llm_rows.packet_batch.blocks+0x1264>
    213c:      	add	x13, x11, #0x14
    2140:      	st1.s	{ v7 }[1], [x13]
    2144:      	mov.16b	v8, v30
    2148:      	mov.16b	v28, v14
    214c:      	mov.16b	v29, v13
    2150:      	ldr	q10, [sp, #0x190]
    2154:      	mov.16b	v11, v1
    2158:      	mov.16b	v12, v26
    215c:      	tbz	w12, #0x6, 0x2168 <_llm_rows.packet_batch.blocks+0x1288>
    2160:      	add	x13, x11, #0x18
    2164:      	st1.s	{ v7 }[2], [x13]
    2168:      	mov.16b	v30, v15
    216c:      	mov.16b	v13, v20
    2170:      	tbz	w12, #0x7, 0x1d20 <_llm_rows.packet_batch.blocks+0xe40>
    2174:      	add	x11, x11, #0x1c
    2178:      	st1.s	{ v7 }[3], [x11]
    217c:      	b	0x1d20 <_llm_rows.packet_batch.blocks+0xe40>
    2180:      	ldp	q1, q2, [sp, #0x1c0]
    2184:      	ldr	q11, [sp, #0xd0]
    2188:      	fmul.4s	v3, v11, v1
    218c:      	fmul.4s	v3, v11, v3
    2190:      	fmul.4s	v3, v11, v3
    2194:      	fadd.4s	v3, v11, v3
    2198:      	fmul.4s	v3, v3, v2
    219c:      	ldr	q9, [sp, #0xa0]
    21a0:      	zip1.8b	v4, v9, v0
    21a4:      	ushll.4s	v4, v4, #0x0
    21a8:      	shl.4s	v4, v4, #0x1f
    21ac:      	cmlt.4s	v4, v4, #0
    21b0:      	and.16b	v3, v4, v3
    21b4:      	fabs.4s	v4, v3
    21b8:      	fmul.4s	v5, v3, v3
    21bc:      	ldr	q6, [sp, #0x220]
    21c0:      	ldp	q16, q2, [sp, #0x1f0]
    21c4:      	fmla.4s	v6, v5, v2
    21c8:      	ldp	q7, q24, [sp, #0x240]
    21cc:      	fmla.4s	v7, v5, v6
    21d0:      	mov.16b	v6, v10
    21d4:      	fmla.4s	v6, v5, v7
    21d8:      	mov.16b	v7, v22
    21dc:      	fmla.4s	v7, v5, v6
    21e0:      	mov.16b	v6, v24
    21e4:      	fmla.4s	v6, v5, v7
    21e8:      	mov.16b	v7, v0
    21ec:      	fmla.4s	v7, v5, v6
    21f0:      	fmul.4s	v6, v4, v7
    21f4:      	ldr	q7, [sp, #0x1e0]
    21f8:      	fmla.4s	v7, v5, v29
    21fc:      	fmla.4s	v16, v5, v7
    2200:      	ldr	q7, [sp, #0x210]
    2204:      	fmla.4s	v7, v5, v16
    2208:      	ldr	q16, [sp, #0x230]
    220c:      	fmla.4s	v16, v5, v7
    2210:      	movi.4s	v7, #0x3f, lsl #24
    2214:      	fmla.4s	v7, v5, v16
    2218:      	mov.16b	v16, v0
    221c:      	fmla.4s	v16, v5, v7
    2220:      	fdiv.4s	v5, v6, v16
    2224:      	mov.16b	v1, v25
    2228:      	fcmge.4s	v6, v25, v4
    222c:      	and.16b	v7, v6, v4
    2230:      	fcmge.4s	v16, v7, v28
    2234:      	movi.4s	v21, #0x3f, lsl #24
    2238:      	ldr	q2, [sp, #0x260]
    223c:      	fcmge.4s	v17, v2, v7
    2240:      	and.16b	v16, v16, v17
    2244:      	and.16b	v16, v16, v7
    2248:      	fmul.4s	v17, v16, v30
    224c:      	movi.4s	v18, #0x4b, lsl #24
    2250:      	fadd.4s	v17, v17, v18
    2254:      	movi.4s	v18, #0xcb, lsl #24
    2258:      	fadd.4s	v17, v17, v18
    225c:      	fcvtzs.4s	v17, v17
    2260:      	scvtf.4s	v18, v17
    2264:      	fmul.4s	v19, v18, v8
    2268:      	fadd.4s	v16, v16, v19
    226c:      	fmul.4s	v18, v18, v27
    2270:      	fadd.4s	v16, v16, v18
    2274:      	ldp	q25, q23, [sp, #0x140]
    2278:      	fmul.4s	v18, v16, v25
    227c:      	fadd.4s	v18, v18, v23
    2280:      	fmul.4s	v18, v16, v18
    2284:      	ldp	q26, q20, [sp, #0x160]
    2288:      	fadd.4s	v18, v18, v26
    228c:      	fmul.4s	v18, v16, v18
    2290:      	fadd.4s	v18, v18, v20
    2294:      	fmul.4s	v18, v16, v18
    2298:      	fadd.4s	v18, v18, v24
    229c:      	fmul.4s	v18, v16, v18
    22a0:      	fadd.4s	v18, v18, v21
    22a4:      	fmul.4s	v19, v16, v16
    22a8:      	fmul.4s	v18, v19, v18
    22ac:      	fadd.4s	v16, v16, v18
    22b0:      	fadd.4s	v16, v16, v0
    22b4:      	movi.2d	v18, #0xffffffffffffffff
    22b8:      	add.4s	v17, v17, v18
    22bc:      	sshr.4s	v18, v17, #0x1
    22c0:      	shl.4s	v19, v18, #0x17
    22c4:      	add.4s	v19, v19, v0
    22c8:      	fmul.4s	v16, v16, v19
    22cc:      	sub.4s	v17, v17, v18
    22d0:      	shl.4s	v17, v17, #0x17
    22d4:      	add.4s	v17, v17, v0
    22d8:      	fmul.4s	v16, v16, v17
    22dc:      	fcmgt.4s	v7, v7, v2
    22e0:      	movi.4s	v2, #0x3f, lsl #24
    22e4:      	ldr	q17, [sp, #0x1b0]
    22e8:      	bsl.16b	v7, v17, v16
    22ec:      	fdiv.4s	v16, v31, v7
    22f0:      	fsub.4s	v17, v7, v16
    22f4:      	fadd.4s	v7, v7, v16
    22f8:      	fdiv.4s	v7, v17, v7
    22fc:      	bsl.16b	v6, v7, v0
    2300:      	fcmge.4s	v4, v0, v4
    2304:      	bsl.16b	v4, v5, v6
    2308:      	ldr	d5, [sp, #0x8]
    230c:      	fmov	w9, s5
    2310:      	mvni.4s	v5, #0x80, lsl #24
    2314:      	bif.16b	v4, v3, v5
    2318:      	fcmeq.4s	v3, v3, v3
    231c:      	fadd.4s	v4, v4, v0
    2320:      	ldr	q5, [sp, #0x1a0]
    2324:      	bsl.16b	v3, v4, v5
    2328:      	fmul.4s	v4, v11, v2
    232c:      	fmul.4s	v3, v4, v3
    2330:      	ldr	q2, [sp, #0x10]
    2334:      	fadd.4s	v3, v3, v2
    2338:      	ldr	q4, [sp, #0x50]
    233c:      	ldr	q2, [sp, #0xe0]
    2340:      	stp	q4, q2, [sp, #0x300]
    2344:      	ldp	q2, q4, [sp, #0x30]
    2348:      	stp	q4, q2, [sp, #0x320]
    234c:      	and	x11, x10, #0x7
    2350:      	add	x12, sp, #0x300
    2354:      	ldr	x11, [x12, x11, lsl #3]
    2358:      	sub	x10, x11, x10
    235c:      	add	x8, x8, x10, lsl #2
    2360:      	tbz	w9, #0x0, 0x2384 <_llm_rows.packet_batch.blocks+0x14a4>
    2364:      	str	s3, [x8]
    2368:      	ldr	q21, [sp, #0xf0]
    236c:      	tbnz	w9, #0x1, 0x238c <_llm_rows.packet_batch.blocks+0x14ac>
    2370:      	tbz	w9, #0x2, 0x2398 <_llm_rows.packet_batch.blocks+0x14b8>
    2374:      	add	x10, x8, #0x8
    2378:      	st1.s	{ v3 }[2], [x10]
    237c:      	tbnz	w9, #0x3, 0x239c <_llm_rows.packet_batch.blocks+0x14bc>
    2380:      	b	0x23a4 <_llm_rows.packet_batch.blocks+0x14c4>
    2384:      	ldr	q21, [sp, #0xf0]
    2388:      	tbz	w9, #0x1, 0x2370 <_llm_rows.packet_batch.blocks+0x1490>
    238c:      	add	x10, x8, #0x4
    2390:      	st1.s	{ v3 }[1], [x10]
    2394:      	tbnz	w9, #0x2, 0x2374 <_llm_rows.packet_batch.blocks+0x1494>
    2398:      	tbz	w9, #0x3, 0x23a4 <_llm_rows.packet_batch.blocks+0x14c4>
    239c:      	add	x10, x8, #0xc
    23a0:      	st1.s	{ v3 }[3], [x10]
    23a4:      	ldp	q4, q2, [sp, #0x1c0]
    23a8:      	fmul.4s	v3, v21, v4
    23ac:      	fmul.4s	v3, v21, v3
    23b0:      	fmul.4s	v3, v21, v3
    23b4:      	fadd.4s	v3, v21, v3
    23b8:      	fmul.4s	v3, v3, v2
    23bc:      	zip2.8b	v4, v9, v0
    23c0:      	ushll.4s	v4, v4, #0x0
    23c4:      	shl.4s	v4, v4, #0x1f
    23c8:      	cmlt.4s	v4, v4, #0
    23cc:      	and.16b	v3, v4, v3
    23d0:      	fmul.4s	v4, v3, v3
    23d4:      	ldr	q5, [sp, #0x220]
    23d8:      	ldp	q7, q2, [sp, #0x1f0]
    23dc:      	fmla.4s	v5, v4, v2
    23e0:      	ldr	q2, [sp, #0x240]
    23e4:      	fmla.4s	v2, v4, v5
    23e8:      	fmla.4s	v10, v4, v2
    23ec:      	fmla.4s	v22, v4, v10
    23f0:      	ldr	q2, [sp, #0x250]
    23f4:      	mov.16b	v5, v2
    23f8:      	fmla.4s	v5, v4, v22
    23fc:      	mov.16b	v6, v0
    2400:      	fmla.4s	v6, v4, v5
    2404:      	ldr	q5, [sp, #0x1e0]
    2408:      	fmla.4s	v5, v4, v29
    240c:      	fmla.4s	v7, v4, v5
    2410:      	ldr	q5, [sp, #0x210]
    2414:      	fmla.4s	v5, v4, v7
    2418:      	ldr	q7, [sp, #0x230]
    241c:      	fmla.4s	v7, v4, v5
    2420:      	movi.4s	v5, #0x3f, lsl #24
    2424:      	fmla.4s	v5, v4, v7
    2428:      	mov.16b	v7, v0
    242c:      	fmla.4s	v7, v4, v5
    2430:      	fabs.4s	v4, v3
    2434:      	fmul.4s	v5, v4, v6
    2438:      	fdiv.4s	v5, v5, v7
    243c:      	fcmge.4s	v6, v1, v4
    2440:      	and.16b	v7, v6, v4
    2444:      	fcmge.4s	v16, v7, v28
    2448:      	ldr	q1, [sp, #0x260]
    244c:      	fcmge.4s	v17, v1, v7
    2450:      	and.16b	v16, v16, v17
    2454:      	and.16b	v16, v16, v7
    2458:      	fmul.4s	v17, v16, v30
    245c:      	movi.4s	v18, #0x4b, lsl #24
    2460:      	fadd.4s	v17, v17, v18
    2464:      	movi.4s	v18, #0xcb, lsl #24
    2468:      	fadd.4s	v17, v17, v18
    246c:      	fcvtzs.4s	v17, v17
    2470:      	scvtf.4s	v18, v17
    2474:      	fmul.4s	v19, v18, v8
    2478:      	fadd.4s	v16, v16, v19
    247c:      	fmul.4s	v18, v18, v27
    2480:      	fadd.4s	v16, v16, v18
    2484:      	fmul.4s	v18, v16, v25
    2488:      	fadd.4s	v18, v18, v23
    248c:      	fmul.4s	v18, v16, v18
    2490:      	fadd.4s	v18, v18, v26
    2494:      	fmul.4s	v18, v16, v18
    2498:      	fadd.4s	v18, v18, v20
    249c:      	fmul.4s	v18, v16, v18
    24a0:      	fadd.4s	v2, v18, v2
    24a4:      	fmul.4s	v2, v16, v2
    24a8:      	movi.4s	v18, #0x3f, lsl #24
    24ac:      	fadd.4s	v2, v2, v18
    24b0:      	fmul.4s	v18, v16, v16
    24b4:      	fmul.4s	v2, v18, v2
    24b8:      	fadd.4s	v2, v16, v2
    24bc:      	fadd.4s	v2, v2, v0
    24c0:      	movi.2d	v16, #0xffffffffffffffff
    24c4:      	add.4s	v16, v17, v16
    24c8:      	sshr.4s	v17, v16, #0x1
    24cc:      	shl.4s	v18, v17, #0x17
    24d0:      	add.4s	v18, v18, v0
    24d4:      	fmul.4s	v2, v2, v18
    24d8:      	sub.4s	v16, v16, v17
    24dc:      	shl.4s	v16, v16, #0x17
    24e0:      	add.4s	v16, v16, v0
    24e4:      	fmul.4s	v2, v2, v16
    24e8:      	fcmgt.4s	v1, v7, v1
    24ec:      	ldr	q7, [sp, #0x1b0]
    24f0:      	bsl.16b	v1, v7, v2
    24f4:      	fdiv.4s	v2, v31, v1
    24f8:      	fsub.4s	v7, v1, v2
    24fc:      	fadd.4s	v1, v1, v2
    2500:      	fdiv.4s	v1, v7, v1
    2504:      	bif.16b	v1, v0, v6
    2508:      	fcmge.4s	v2, v0, v4
    250c:      	bit.16b	v1, v5, v2
    2510:      	mvni.4s	v2, #0x80, lsl #24
    2514:      	bif.16b	v1, v3, v2
    2518:      	fadd.4s	v0, v1, v0
    251c:      	fcmeq.4s	v1, v3, v3
    2520:      	ldr	q2, [sp, #0x1a0]
    2524:      	bif.16b	v0, v2, v1
    2528:      	movi.4s	v1, #0x3f, lsl #24
    252c:      	fmul.4s	v1, v21, v1
    2530:      	fmul.4s	v0, v1, v0
    2534:      	ldr	q1, [sp, #0x20]
    2538:      	fadd.4s	v0, v0, v1
    253c:      	tbz	w9, #0x4, 0x2b08 <_llm_rows.packet_batch.blocks+0x1c28>
    2540:      	str	s0, [x8, #0x10]
    2544:      	tbnz	w9, #0x5, 0x2b0c <_llm_rows.packet_batch.blocks+0x1c2c>
    2548:      	tbz	w9, #0x6, 0x2b18 <_llm_rows.packet_batch.blocks+0x1c38>
    254c:      	add	x10, x8, #0x18
    2550:      	st1.s	{ v0 }[2], [x10]
    2554:      	tbnz	w9, #0x7, 0x2b1c <_llm_rows.packet_batch.blocks+0x1c3c>
    2558:      	b	0xfb4 <_llm_rows.packet_batch.blocks+0xd4>
    255c:      	xtn.4h	v3, v9
    2560:      	uzp1.8b	v4, v3, v0
    2564:      	movi.2d	v10, #0000000000000000
    2568:      	mov.b	v10[0], v4[0]
    256c:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x1120>
    2570:      	ldr	d3, [x10]
    2574:      	and.8b	v5, v10, v3
    2578:      	addv.8b	b5, v5
    257c:      	fmov	w12, s5
    2580:      	umaxv.8b	b5, v10
    2584:      	fmov	w14, s5
    2588:      	rbit	w10, w12
    258c:      	clz	w10, w10
    2590:      	tst	w14, #0x1
    2594:      	csel	w10, w10, wzr, ne
    2598:      	mov	w13, #0x1000            ; =4096
    259c:      	dup.2d	v7, x13
    25a0:      	ldr	d17, [sp, #0x20]
    25a4:      	ldr	d1, [sp, #0xf0]
    25a8:      	ldr	q6, [sp, #0xd0]
    25ac:      	umlal.2d	v6, v1, v17
    25b0:      	movi.2d	v5, #0000000000000000
    25b4:      	mov.b	v5[0], v4[0]
    25b8:      	str	q7, [sp, #0xd0]
    25bc:      	add.2d	v1, v6, v7
    25c0:      	ushll.2d	v4, v5, #0x0
    25c4:      	shl.2d	v4, v4, #0x3f
    25c8:      	cmlt.2d	v4, v4, #0
    25cc:      	str	q1, [sp, #0xf0]
    25d0:      	and.16b	v4, v4, v1
    25d4:      	movi.2d	v5, #0000000000000000
    25d8:      	stp	q5, q5, [sp, #0x2d0]
    25dc:      	stp	q4, q5, [sp, #0x2b0]
    25e0:      	and	x13, x10, #0x7
    25e4:      	add	x15, sp, #0x2b0
    25e8:      	ldr	x13, [x15, x13, lsl #3]
    25ec:      	sub	x13, x13, x10
    25f0:      	lsl	x13, x13, #2
    25f4:      	add	x11, x11, x13
    25f8:      	movi.2d	v15, #0000000000000000
    25fc:      	movi.2d	v9, #0000000000000000
    2600:      	tbz	w14, #0x0, 0x2654 <_llm_rows.packet_batch.blocks+0x1774>
    2604:      	ldr	s15, [x11]
    2608:      	ldr	q1, [sp, #0x120]
    260c:      	ldr	q5, [sp, #0xa0]
    2610:      	ldr	q12, [sp, #0x50]
    2614:      	ldr	d7, [sp, #0x40]
    2618:      	ldr	d16, [sp, #0x30]
    261c:      	tbnz	w12, #0x1, 0x266c <_llm_rows.packet_batch.blocks+0x178c>
    2620:      	tbz	w12, #0x2, 0x2678 <_llm_rows.packet_batch.blocks+0x1798>
    2624:      	add	x14, x11, #0x8
    2628:      	ld1.s	{ v15 }[2], [x14]
    262c:      	tbnz	w12, #0x3, 0x267c <_llm_rows.packet_batch.blocks+0x179c>
    2630:      	tbz	w12, #0x4, 0x2688 <_llm_rows.packet_batch.blocks+0x17a8>
    2634:      	add	x14, x11, #0x10
    2638:      	ld1.s	{ v9 }[0], [x14]
    263c:      	tbnz	w12, #0x5, 0x268c <_llm_rows.packet_batch.blocks+0x17ac>
    2640:      	tbz	w12, #0x6, 0x2698 <_llm_rows.packet_batch.blocks+0x17b8>
    2644:      	add	x14, x11, #0x18
    2648:      	ld1.s	{ v9 }[2], [x14]
    264c:      	tbnz	w12, #0x7, 0x269c <_llm_rows.packet_batch.blocks+0x17bc>
    2650:      	b	0x26a4 <_llm_rows.packet_batch.blocks+0x17c4>
    2654:      	ldr	q1, [sp, #0x120]
    2658:      	ldr	q5, [sp, #0xa0]
    265c:      	ldr	q12, [sp, #0x50]
    2660:      	ldr	d7, [sp, #0x40]
    2664:      	ldr	d16, [sp, #0x30]
    2668:      	tbz	w12, #0x1, 0x2620 <_llm_rows.packet_batch.blocks+0x1740>
    266c:      	add	x14, x11, #0x4
    2670:      	ld1.s	{ v15 }[1], [x14]
    2674:      	tbnz	w12, #0x2, 0x2624 <_llm_rows.packet_batch.blocks+0x1744>
    2678:      	tbz	w12, #0x3, 0x2630 <_llm_rows.packet_batch.blocks+0x1750>
    267c:      	add	x14, x11, #0xc
    2680:      	ld1.s	{ v15 }[3], [x14]
    2684:      	tbnz	w12, #0x4, 0x2634 <_llm_rows.packet_batch.blocks+0x1754>
    2688:      	tbz	w12, #0x5, 0x2640 <_llm_rows.packet_batch.blocks+0x1760>
    268c:      	add	x14, x11, #0x14
    2690:      	ld1.s	{ v9 }[1], [x14]
    2694:      	tbnz	w12, #0x6, 0x2644 <_llm_rows.packet_batch.blocks+0x1764>
    2698:      	tbz	w12, #0x7, 0x26a4 <_llm_rows.packet_batch.blocks+0x17c4>
    269c:      	add	x11, x11, #0x1c
    26a0:      	ld1.s	{ v9 }[3], [x11]
    26a4:      	shl.8b	v4, v10, #0x7
    26a8:      	cmlt.8b	v4, v4, #0
    26ac:      	and.8b	v3, v4, v3
    26b0:      	addv.8b	b3, v3
    26b4:      	str	d3, [sp, #0x10]
    26b8:      	fmov	w11, s3
    26bc:      	add	x9, x9, x13
    26c0:      	movi.2d	v4, #0000000000000000
    26c4:      	movi.2d	v13, #0000000000000000
    26c8:      	tbz	w11, #0x0, 0x2918 <_llm_rows.packet_batch.blocks+0x1a38>
    26cc:      	ldr	s4, [x9]
    26d0:      	tbnz	w11, #0x1, 0x291c <_llm_rows.packet_batch.blocks+0x1a3c>
    26d4:      	tbz	w11, #0x2, 0x2928 <_llm_rows.packet_batch.blocks+0x1a48>
    26d8:      	add	x12, x9, #0x8
    26dc:      	ld1.s	{ v4 }[2], [x12]
    26e0:      	tbnz	w11, #0x3, 0x292c <_llm_rows.packet_batch.blocks+0x1a4c>
    26e4:      	tbz	w11, #0x4, 0x2938 <_llm_rows.packet_batch.blocks+0x1a58>
    26e8:      	add	x12, x9, #0x10
    26ec:      	ld1.s	{ v13 }[0], [x12]
    26f0:      	tbnz	w11, #0x5, 0x293c <_llm_rows.packet_batch.blocks+0x1a5c>
    26f4:      	tbz	w11, #0x6, 0x2700 <_llm_rows.packet_batch.blocks+0x1820>
    26f8:      	add	x12, x9, #0x18
    26fc:      	ld1.s	{ v13 }[2], [x12]
    2700:      	ldr	d3, [sp, #0xe0]
    2704:      	umlal.2d	v12, v3, v17
    2708:      	umlal.2d	v5, v16, v17
    270c:      	umlal.2d	v1, v7, v17
    2710:      	str	q1, [sp, #0x120]
    2714:      	mov.16b	v3, v5
    2718:      	tbz	w11, #0x7, 0x2724 <_llm_rows.packet_batch.blocks+0x1844>
    271c:      	add	x9, x9, #0x1c
    2720:      	ld1.s	{ v13 }[3], [x9]
    2724:      	ldp	q6, q1, [sp, #0x1c0]
    2728:      	fmul.4s	v5, v15, v6
    272c:      	fmul.4s	v5, v15, v5
    2730:      	fmul.4s	v5, v15, v5
    2734:      	fadd.4s	v5, v15, v5
    2738:      	fmul.4s	v5, v5, v1
    273c:      	zip1.8b	v6, v10, v0
    2740:      	ushll.4s	v6, v6, #0x0
    2744:      	shl.4s	v6, v6, #0x1f
    2748:      	cmlt.4s	v6, v6, #0
    274c:      	and.16b	v5, v6, v5
    2750:      	fabs.4s	v6, v5
    2754:      	fmul.4s	v7, v5, v5
    2758:      	ldr	q16, [sp, #0x220]
    275c:      	ldp	q18, q1, [sp, #0x1f0]
    2760:      	fmla.4s	v16, v7, v1
    2764:      	ldp	q17, q21, [sp, #0x240]
    2768:      	fmla.4s	v17, v7, v16
    276c:      	ldr	q16, [sp, #0x190]
    2770:      	fmla.4s	v16, v7, v17
    2774:      	str	q22, [sp, #0x180]
    2778:      	fmla.4s	v22, v7, v16
    277c:      	mov.16b	v16, v21
    2780:      	fmla.4s	v16, v7, v22
    2784:      	mov.16b	v17, v0
    2788:      	fmla.4s	v17, v7, v16
    278c:      	fmul.4s	v16, v6, v17
    2790:      	ldr	q17, [sp, #0x1e0]
    2794:      	fmla.4s	v17, v7, v29
    2798:      	fmla.4s	v18, v7, v17
    279c:      	ldr	q17, [sp, #0x210]
    27a0:      	fmla.4s	v17, v7, v18
    27a4:      	ldr	q18, [sp, #0x230]
    27a8:      	fmla.4s	v18, v7, v17
    27ac:      	movi.4s	v17, #0x3f, lsl #24
    27b0:      	fmla.4s	v17, v7, v18
    27b4:      	mov.16b	v18, v0
    27b8:      	fmla.4s	v18, v7, v17
    27bc:      	fdiv.4s	v7, v16, v18
    27c0:      	mov.16b	v1, v24
    27c4:      	fcmge.4s	v16, v24, v6
    27c8:      	and.16b	v17, v16, v6
    27cc:      	fcmge.4s	v18, v17, v28
    27d0:      	ldr	q22, [sp, #0x260]
    27d4:      	fcmge.4s	v19, v22, v17
    27d8:      	and.16b	v18, v18, v19
    27dc:      	and.16b	v18, v18, v17
    27e0:      	fmul.4s	v19, v18, v30
    27e4:      	movi.4s	v24, #0x4b, lsl #24
    27e8:      	fadd.4s	v19, v19, v24
    27ec:      	movi.4s	v24, #0xcb, lsl #24
    27f0:      	fadd.4s	v19, v19, v24
    27f4:      	fcvtzs.4s	v19, v19
    27f8:      	scvtf.4s	v14, v19
    27fc:      	fmul.4s	v11, v14, v8
    2800:      	fadd.4s	v18, v18, v11
    2804:      	fmul.4s	v11, v14, v27
    2808:      	fadd.4s	v18, v18, v11
    280c:      	fmul.4s	v11, v18, v25
    2810:      	fadd.4s	v11, v11, v20
    2814:      	fmul.4s	v11, v18, v11
    2818:      	fadd.4s	v11, v11, v23
    281c:      	fmul.4s	v11, v18, v11
    2820:      	fadd.4s	v11, v11, v26
    2824:      	fmul.4s	v11, v18, v11
    2828:      	fadd.4s	v11, v11, v21
    282c:      	fmul.4s	v11, v18, v11
    2830:      	fadd.4s	v11, v11, v2
    2834:      	fmul.4s	v14, v18, v18
    2838:      	fmul.4s	v11, v14, v11
    283c:      	fadd.4s	v18, v18, v11
    2840:      	fadd.4s	v18, v18, v0
    2844:      	movi.2d	v24, #0xffffffffffffffff
    2848:      	add.4s	v19, v19, v24
    284c:      	sshr.4s	v11, v19, #0x1
    2850:      	shl.4s	v14, v11, #0x17
    2854:      	add.4s	v14, v14, v0
    2858:      	fmul.4s	v18, v18, v14
    285c:      	sub.4s	v19, v19, v11
    2860:      	shl.4s	v19, v19, #0x17
    2864:      	add.4s	v19, v19, v0
    2868:      	fmul.4s	v18, v18, v19
    286c:      	fcmgt.4s	v17, v17, v22
    2870:      	ldr	q19, [sp, #0x1b0]
    2874:      	bsl.16b	v17, v19, v18
    2878:      	fdiv.4s	v18, v31, v17
    287c:      	fsub.4s	v19, v17, v18
    2880:      	fadd.4s	v17, v17, v18
    2884:      	fdiv.4s	v17, v19, v17
    2888:      	bsl.16b	v16, v17, v0
    288c:      	fcmge.4s	v6, v0, v6
    2890:      	bsl.16b	v6, v7, v16
    2894:      	ldr	q17, [sp, #0xd0]
    2898:      	add.2d	v7, v12, v17
    289c:      	add.2d	v16, v3, v17
    28a0:      	ldr	q3, [sp, #0x120]
    28a4:      	add.2d	v17, v3, v17
    28a8:      	mvni.4s	v18, #0x80, lsl #24
    28ac:      	bif.16b	v6, v5, v18
    28b0:      	fcmeq.4s	v5, v5, v5
    28b4:      	fadd.4s	v6, v6, v0
    28b8:      	ldr	q18, [sp, #0x1a0]
    28bc:      	bsl.16b	v5, v6, v18
    28c0:      	fmul.4s	v6, v15, v2
    28c4:      	fmul.4s	v5, v6, v5
    28c8:      	fadd.4s	v4, v4, v5
    28cc:      	ldr	q2, [sp, #0xf0]
    28d0:      	stp	q2, q7, [sp, #0x270]
    28d4:      	stp	q16, q17, [sp, #0x290]
    28d8:      	ldr	d2, [sp, #0x10]
    28dc:      	fmov	w9, s2
    28e0:      	and	x11, x10, #0x7
    28e4:      	add	x12, sp, #0x270
    28e8:      	ldr	x11, [x12, x11, lsl #3]
    28ec:      	sub	x10, x11, x10
    28f0:      	add	x8, x8, x10, lsl #2
    28f4:      	tbz	w9, #0x0, 0x294c <_llm_rows.packet_batch.blocks+0x1a6c>
    28f8:      	str	s4, [x8]
    28fc:      	tbnz	w9, #0x1, 0x2950 <_llm_rows.packet_batch.blocks+0x1a70>
    2900:      	ldr	q6, [sp, #0x180]
    2904:      	tbz	w9, #0x2, 0x2960 <_llm_rows.packet_batch.blocks+0x1a80>
    2908:      	add	x10, x8, #0x8
    290c:      	st1.s	{ v4 }[2], [x10]
    2910:      	tbnz	w9, #0x3, 0x2964 <_llm_rows.packet_batch.blocks+0x1a84>
    2914:      	b	0x296c <_llm_rows.packet_batch.blocks+0x1a8c>
    2918:      	tbz	w11, #0x1, 0x26d4 <_llm_rows.packet_batch.blocks+0x17f4>
    291c:      	add	x12, x9, #0x4
    2920:      	ld1.s	{ v4 }[1], [x12]
    2924:      	tbnz	w11, #0x2, 0x26d8 <_llm_rows.packet_batch.blocks+0x17f8>
    2928:      	tbz	w11, #0x3, 0x26e4 <_llm_rows.packet_batch.blocks+0x1804>
    292c:      	add	x12, x9, #0xc
    2930:      	ld1.s	{ v4 }[3], [x12]
    2934:      	tbnz	w11, #0x4, 0x26e8 <_llm_rows.packet_batch.blocks+0x1808>
    2938:      	tbz	w11, #0x5, 0x26f4 <_llm_rows.packet_batch.blocks+0x1814>
    293c:      	add	x12, x9, #0x14
    2940:      	ld1.s	{ v13 }[1], [x12]
    2944:      	tbnz	w11, #0x6, 0x26f8 <_llm_rows.packet_batch.blocks+0x1818>
    2948:      	b	0x2700 <_llm_rows.packet_batch.blocks+0x1820>
    294c:      	tbz	w9, #0x1, 0x2900 <_llm_rows.packet_batch.blocks+0x1a20>
    2950:      	add	x10, x8, #0x4
    2954:      	st1.s	{ v4 }[1], [x10]
    2958:      	ldr	q6, [sp, #0x180]
    295c:      	tbnz	w9, #0x2, 0x2908 <_llm_rows.packet_batch.blocks+0x1a28>
    2960:      	tbz	w9, #0x3, 0x296c <_llm_rows.packet_batch.blocks+0x1a8c>
    2964:      	add	x10, x8, #0xc
    2968:      	st1.s	{ v4 }[3], [x10]
    296c:      	ldp	q4, q2, [sp, #0x1c0]
    2970:      	fmul.4s	v3, v9, v4
    2974:      	fmul.4s	v3, v9, v3
    2978:      	fmul.4s	v3, v9, v3
    297c:      	fadd.4s	v3, v9, v3
    2980:      	fmul.4s	v3, v3, v2
    2984:      	zip2.8b	v4, v10, v0
    2988:      	ushll.4s	v4, v4, #0x0
    298c:      	shl.4s	v4, v4, #0x1f
    2990:      	cmlt.4s	v4, v4, #0
    2994:      	and.16b	v3, v4, v3
    2998:      	fmul.4s	v4, v3, v3
    299c:      	ldr	q2, [sp, #0x220]
    29a0:      	ldp	q7, q5, [sp, #0x1f0]
    29a4:      	fmla.4s	v2, v4, v5
    29a8:      	ldr	q5, [sp, #0x240]
    29ac:      	fmla.4s	v5, v4, v2
    29b0:      	ldr	q2, [sp, #0x190]
    29b4:      	fmla.4s	v2, v4, v5
    29b8:      	fmla.4s	v6, v4, v2
    29bc:      	ldr	q2, [sp, #0x250]
    29c0:      	mov.16b	v5, v2
    29c4:      	fmla.4s	v5, v4, v6
    29c8:      	mov.16b	v6, v0
    29cc:      	fmla.4s	v6, v4, v5
    29d0:      	ldr	q5, [sp, #0x1e0]
    29d4:      	fmla.4s	v5, v4, v29
    29d8:      	fmla.4s	v7, v4, v5
    29dc:      	ldr	q5, [sp, #0x210]
    29e0:      	fmla.4s	v5, v4, v7
    29e4:      	ldr	q7, [sp, #0x230]
    29e8:      	fmla.4s	v7, v4, v5
    29ec:      	movi.4s	v5, #0x3f, lsl #24
    29f0:      	fmla.4s	v5, v4, v7
    29f4:      	mov.16b	v7, v0
    29f8:      	fmla.4s	v7, v4, v5
    29fc:      	fabs.4s	v4, v3
    2a00:      	fmul.4s	v5, v4, v6
    2a04:      	fdiv.4s	v5, v5, v7
    2a08:      	fcmge.4s	v6, v1, v4
    2a0c:      	and.16b	v7, v6, v4
    2a10:      	fcmge.4s	v16, v7, v28
    2a14:      	ldr	q1, [sp, #0x260]
    2a18:      	fcmge.4s	v17, v1, v7
    2a1c:      	and.16b	v16, v16, v17
    2a20:      	and.16b	v16, v16, v7
    2a24:      	fmul.4s	v17, v16, v30
    2a28:      	movi.4s	v18, #0x4b, lsl #24
    2a2c:      	fadd.4s	v17, v17, v18
    2a30:      	movi.4s	v18, #0xcb, lsl #24
    2a34:      	fadd.4s	v17, v17, v18
    2a38:      	fcvtzs.4s	v17, v17
    2a3c:      	scvtf.4s	v18, v17
    2a40:      	fmul.4s	v19, v18, v8
    2a44:      	fadd.4s	v16, v16, v19
    2a48:      	fmul.4s	v18, v18, v27
    2a4c:      	fadd.4s	v16, v16, v18
    2a50:      	fmul.4s	v18, v16, v25
    2a54:      	fadd.4s	v18, v18, v20
    2a58:      	fmul.4s	v18, v16, v18
    2a5c:      	fadd.4s	v18, v18, v23
    2a60:      	fmul.4s	v18, v16, v18
    2a64:      	fadd.4s	v18, v18, v26
    2a68:      	fmul.4s	v18, v16, v18
    2a6c:      	fadd.4s	v2, v18, v2
    2a70:      	fmul.4s	v2, v16, v2
    2a74:      	movi.4s	v18, #0x3f, lsl #24
    2a78:      	fadd.4s	v2, v2, v18
    2a7c:      	fmul.4s	v18, v16, v16
    2a80:      	fmul.4s	v2, v18, v2
    2a84:      	fadd.4s	v2, v16, v2
    2a88:      	fadd.4s	v2, v2, v0
    2a8c:      	movi.2d	v16, #0xffffffffffffffff
    2a90:      	add.4s	v16, v17, v16
    2a94:      	sshr.4s	v17, v16, #0x1
    2a98:      	shl.4s	v18, v17, #0x17
    2a9c:      	add.4s	v18, v18, v0
    2aa0:      	fmul.4s	v2, v2, v18
    2aa4:      	sub.4s	v16, v16, v17
    2aa8:      	shl.4s	v16, v16, #0x17
    2aac:      	add.4s	v16, v16, v0
    2ab0:      	fmul.4s	v2, v2, v16
    2ab4:      	fcmgt.4s	v1, v7, v1
    2ab8:      	ldr	q7, [sp, #0x1b0]
    2abc:      	bsl.16b	v1, v7, v2
    2ac0:      	fdiv.4s	v2, v31, v1
    2ac4:      	fsub.4s	v7, v1, v2
    2ac8:      	fadd.4s	v1, v1, v2
    2acc:      	fdiv.4s	v1, v7, v1
    2ad0:      	bif.16b	v1, v0, v6
    2ad4:      	fcmge.4s	v2, v0, v4
    2ad8:      	bit.16b	v1, v5, v2
    2adc:      	mvni.4s	v2, #0x80, lsl #24
    2ae0:      	bif.16b	v1, v3, v2
    2ae4:      	fadd.4s	v0, v1, v0
    2ae8:      	fcmeq.4s	v1, v3, v3
    2aec:      	ldr	q2, [sp, #0x1a0]
    2af0:      	bif.16b	v0, v2, v1
    2af4:      	movi.4s	v1, #0x3f, lsl #24
    2af8:      	fmul.4s	v1, v9, v1
    2afc:      	fmul.4s	v0, v1, v0
    2b00:      	fadd.4s	v0, v13, v0
    2b04:      	tbnz	w9, #0x4, 0x2540 <_llm_rows.packet_batch.blocks+0x1660>
    2b08:      	tbz	w9, #0x5, 0x2548 <_llm_rows.packet_batch.blocks+0x1668>
    2b0c:      	add	x10, x8, #0x14
    2b10:      	st1.s	{ v0 }[1], [x10]
    2b14:      	tbnz	w9, #0x6, 0x254c <_llm_rows.packet_batch.blocks+0x166c>
    2b18:      	tbz	w9, #0x7, 0xfb4 <_llm_rows.packet_batch.blocks+0xd4>
    2b1c:      	add	x8, x8, #0x1c
    2b20:      	st1.s	{ v0 }[3], [x8]
    2b24:      	b	0xfb4 <_llm_rows.packet_batch.blocks+0xd4>
    2b28:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    2b2c:      	add	sp, sp, #0x420
    2b30:      	ldp	x29, x30, [sp, #0x90]
    2b34:      	ldp	x20, x19, [sp, #0x80]
    2b38:      	ldp	x22, x21, [sp, #0x70]
    2b3c:      	ldp	x24, x23, [sp, #0x60]
    2b40:      	ldp	x26, x25, [sp, #0x50]
    2b44:      	ldp	x28, x27, [sp, #0x40]
    2b48:      	ldp	d9, d8, [sp, #0x30]
    2b4c:      	ldp	d11, d10, [sp, #0x20]
    2b50:      	ldp	d13, d12, [sp, #0x10]
    2b54:      	ldp	d15, d14, [sp], #0xa0
    2b58:      	ret

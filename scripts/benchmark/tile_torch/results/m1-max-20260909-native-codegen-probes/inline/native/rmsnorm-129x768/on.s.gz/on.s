
/private/tmp/luisa-packet-inline.UY1lIE/capture/rmsnorm-129x768/on/object/tile_xir_w8_36282_1788935092097030_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d9, d8, [sp, #-0x70]!
       4:      	stp	x28, x27, [sp, #0x10]
       8:      	stp	x26, x25, [sp, #0x20]
       c:      	stp	x24, x23, [sp, #0x30]
      10:      	stp	x22, x21, [sp, #0x40]
      14:      	stp	x20, x19, [sp, #0x50]
      18:      	stp	x29, x30, [sp, #0x60]
      1c:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      20:      	sub	sp, sp, #0xa50
      24:      	str	x0, [sp, #0x20]
      28:      	cbz	w3, 0xb34 <ltmp0+0xb34>
      2c:      	mov	x25, x3
      30:      	mov	w26, #0x0               ; =0
      34:      	add	x24, sp, #0x160
      38:      	ldp	w9, w8, [x2, #0x2c]
      3c:      	stp	w8, w9, [sp, #0x38]
      40:      	add	x27, sp, #0xe50
      44:      	add	x8, x27, #0xe0
      48:      	stp	x2, x8, [sp, #0x8]
      4c:      	ldp	w8, w9, [x2]
      50:      	add	x28, sp, #0x250
      54:      	ldp	w10, w11, [x2, #0x8]
      58:      	str	x11, [sp, #0x30]
      5c:      	movi	d8, #0000000000000000
      60:      	str	w3, [sp, #0x1c]
      64:      	b	0xac <ltmp0+0xac>
      68:      	ldr	x14, [sp, #0x48]
      6c:      	add	w8, w14, #0x1
      70:      	ldp	w9, w13, [sp, #0x3c]
      74:      	cmp	w8, w9
      78:      	cset	w9, eq
      7c:      	csinc	w8, wzr, w14, eq
      80:      	cinc	w10, w13, eq
      84:      	ldr	w11, [sp, #0x38]
      88:      	cmp	w10, w11
      8c:      	cset	w11, eq
      90:      	ands	w11, w9, w11
      94:      	csel	w9, wzr, w10, ne
      98:      	ldr	w12, [sp, #0x44]
      9c:      	add	w10, w12, w11
      a0:      	add	w26, w26, #0x1
      a4:      	cmp	w26, w25
      a8:      	b.eq	0xb20 <ltmp0+0xb20>
      ac:      	str	w10, [sp, #0x44]
      b0:      	mov	x13, x9
      b4:      	mov	x14, x8
      b8:      	ubfiz	x8, x8, #5, #32
      bc:      	ldr	x12, [sp, #0x30]
      c0:      	cmp	x8, x12
      c4:      	csel	x9, x8, xzr, ls
      c8:      	subs	x10, x12, x9
      cc:      	cmp	x10, #0x20
      d0:      	mov	w11, #0x20              ; =32
      d4:      	csel	x10, x10, x11, lo
      d8:      	cmp	x12, x9
      dc:      	ccmp	x8, x12, #0x2, hi
      e0:      	csel	x21, x10, xzr, ls
      e4:      	cmp	x21, #0x20
      e8:      	str	x14, [sp, #0x48]
      ec:      	str	w13, [sp, #0x40]
      f0:      	b.lo	0x2c0 <ltmp0+0x2c0>
      f4:      	mov	x19, #0x0               ; =0
      f8:      	ldr	x8, [sp, #0x20]
      fc:      	ldr	x20, [x8]
     100:      	ldr	x22, [x8, #0x10]
     104:      	ldr	x8, [x8, #0x30]
     108:      	lsl	w21, w14, #2
     10c:      	and	x9, x14, #0x7ffffff
     110:      	mov	w10, #0x3000            ; =12288
     114:      	umaddl	x23, w9, w10, x8
     118:      	add	w8, w19, w21
     11c:      	and	x8, x8, #0x1fffffff
     120:      	mov	w9, #0xc00              ; =3072
     124:      	umaddl	x1, w8, w9, x20
     128:      	add	x0, sp, #0xe50
     12c:      	mov	w2, #0xc00              ; =3072
     130:      	bl	0x130 <ltmp0+0x130>
     134:      	mov	x8, #0x0                ; =0
     138:      	ldr	q0, [x24, #0xcf0]
     13c:      	ldr	q1, [x24, #0xd00]
     140:      	fmul.4s	v2, v1, v1
     144:      	fmul.4s	v3, v0, v0
     148:      	ldr	q0, [x24, #0xd10]
     14c:      	ldr	q1, [x24, #0xd20]
     150:      	fmul.4s	v4, v1, v1
     154:      	fmul.4s	v5, v0, v0
     158:      	ldr	q0, [x24, #0xd30]
     15c:      	ldr	q1, [x24, #0xd40]
     160:      	fmul.4s	v7, v1, v1
     164:      	fmul.4s	v6, v0, v0
     168:      	ldr	q0, [x24, #0xd50]
     16c:      	ldr	q1, [x24, #0xd60]
     170:      	fmul.4s	v16, v1, v1
     174:      	fmul.4s	v17, v0, v0
     178:      	add	x9, x27, x8, lsl #5
     17c:      	ldp	q1, q0, [x9, #0x80]
     180:      	fmul.4s	v1, v1, v1
     184:      	fmul.4s	v0, v0, v0
     188:      	fadd.4s	v2, v2, v0
     18c:      	fadd.4s	v3, v3, v1
     190:      	ldp	q1, q0, [x9, #0xa0]
     194:      	fmul.4s	v1, v1, v1
     198:      	fmul.4s	v0, v0, v0
     19c:      	fadd.4s	v4, v4, v0
     1a0:      	fadd.4s	v5, v5, v1
     1a4:      	ldp	q1, q0, [x9, #0xc0]
     1a8:      	fmul.4s	v1, v1, v1
     1ac:      	fmul.4s	v0, v0, v0
     1b0:      	fadd.4s	v7, v7, v0
     1b4:      	fadd.4s	v6, v6, v1
     1b8:      	ldp	q1, q0, [x9, #0xe0]
     1bc:      	fmul.4s	v1, v1, v1
     1c0:      	fmul.4s	v0, v0, v0
     1c4:      	fadd.4s	v16, v16, v0
     1c8:      	fadd.4s	v17, v17, v1
     1cc:      	add	x8, x8, #0x4
     1d0:      	cmp	x8, #0x5c
     1d4:      	b.lo	0x178 <ltmp0+0x178>
     1d8:      	add	x0, sp, #0x250
     1dc:      	mov	x1, x22
     1e0:      	mov	w2, #0xc00              ; =3072
     1e4:      	stp	q4, q2, [sp, #0x80]
     1e8:      	stp	q5, q3, [sp, #0x50]
     1ec:      	stp	q6, q16, [sp, #0xb0]
     1f0:      	str	q7, [sp, #0x70]
     1f4:      	str	q17, [sp, #0xa0]
     1f8:      	bl	0x1f8 <ltmp0+0x1f8>
     1fc:      	mov	x8, #0x0                ; =0
     200:      	ldp	q1, q0, [sp, #0x50]
     204:      	fadd.4s	v0, v0, v1
     208:      	ldp	q2, q1, [sp, #0x80]
     20c:      	fadd.4s	v1, v1, v2
     210:      	ldr	q2, [sp, #0x70]
     214:      	fadd.4s	v1, v1, v2
     218:      	ldp	q2, q3, [sp, #0xa0]
     21c:      	fadd.4s	v0, v0, v3
     220:      	fadd.4s	v0, v0, v2
     224:      	ldr	q2, [sp, #0xc0]
     228:      	fadd.4s	v1, v1, v2
     22c:      	rev64.4s	v2, v1
     230:      	rev64.4s	v3, v0
     234:      	fadd.4s	v0, v0, v3
     238:      	fadd.4s	v1, v1, v2
     23c:      	dup.4s	v2, v1[2]
     240:      	dup.4s	v3, v0[2]
     244:      	fadd.4s	v0, v0, v3
     248:      	fadd.4s	v1, v1, v2
     24c:      	fadd.4s	v0, v0, v1
     250:      	fadd	s0, s0, s8
     254:      	mov	w9, #0x44400000         ; =1145044992
     258:      	fmov	s1, w9
     25c:      	fdiv	s0, s0, s1
     260:      	mov	w9, #0xc5ac             ; =50604
     264:      	movk	w9, #0x3727, lsl #16
     268:      	fmov	s1, w9
     26c:      	fadd	s0, s0, s1
     270:      	fsqrt	s0, s0
     274:      	dup.4s	v0, v0[0]
     278:      	add	x9, x27, x8
     27c:      	ldp	q1, q2, [x9]
     280:      	fdiv.4s	v2, v2, v0
     284:      	fdiv.4s	v1, v1, v0
     288:      	add	x9, x28, x8
     28c:      	ldp	q4, q3, [x9]
     290:      	fmul.4s	v1, v1, v4
     294:      	fmul.4s	v2, v2, v3
     298:      	add	x9, x23, x8
     29c:      	stp	q1, q2, [x9]
     2a0:      	add	x8, x8, #0x20
     2a4:      	cmp	x8, #0xc00
     2a8:      	b.ne	0x278 <ltmp0+0x278>
     2ac:      	add	x19, x19, #0x1
     2b0:      	add	x23, x23, #0xc00
     2b4:      	cmp	x19, #0x4
     2b8:      	b.ne	0x118 <ltmp0+0x118>
     2bc:      	b	0x68 <ltmp0+0x68>
     2c0:      	str	w26, [sp, #0x2c]
     2c4:      	lsr	x20, x21, #3
     2c8:      	cmp	x21, #0x8
     2cc:      	b.lo	0x49c <ltmp0+0x49c>
     2d0:      	mov	x23, #0x0               ; =0
     2d4:      	ldr	x8, [sp, #0x20]
     2d8:      	ldr	x19, [x8]
     2dc:      	ldr	x22, [x8, #0x10]
     2e0:      	ldr	x8, [x8, #0x30]
     2e4:      	ldr	x9, [sp, #0x48]
     2e8:      	lsl	w25, w9, #2
     2ec:      	and	x9, x9, #0x7ffffff
     2f0:      	mov	w10, #0x3000            ; =12288
     2f4:      	umaddl	x26, w9, w10, x8
     2f8:      	add	w8, w23, w25
     2fc:      	and	x8, x8, #0x1fffffff
     300:      	mov	w9, #0xc00              ; =3072
     304:      	umaddl	x1, w8, w9, x19
     308:      	add	x0, sp, #0xe50
     30c:      	mov	w2, #0xc00              ; =3072
     310:      	bl	0x310 <ltmp0+0x310>
     314:      	mov	x8, #0x0                ; =0
     318:      	ldr	q0, [x24, #0xcf0]
     31c:      	ldr	q1, [x24, #0xd00]
     320:      	fmul.4s	v2, v1, v1
     324:      	fmul.4s	v3, v0, v0
     328:      	ldr	q0, [x24, #0xd10]
     32c:      	ldr	q1, [x24, #0xd20]
     330:      	fmul.4s	v4, v1, v1
     334:      	fmul.4s	v5, v0, v0
     338:      	ldr	q0, [x24, #0xd30]
     33c:      	ldr	q1, [x24, #0xd40]
     340:      	fmul.4s	v7, v1, v1
     344:      	fmul.4s	v6, v0, v0
     348:      	ldr	q0, [x24, #0xd50]
     34c:      	ldr	q1, [x24, #0xd60]
     350:      	fmul.4s	v16, v1, v1
     354:      	fmul.4s	v17, v0, v0
     358:      	add	x9, x27, x8, lsl #5
     35c:      	ldp	q1, q0, [x9, #0x80]
     360:      	fmul.4s	v1, v1, v1
     364:      	fmul.4s	v0, v0, v0
     368:      	fadd.4s	v2, v2, v0
     36c:      	fadd.4s	v3, v3, v1
     370:      	ldp	q1, q0, [x9, #0xa0]
     374:      	fmul.4s	v1, v1, v1
     378:      	fmul.4s	v0, v0, v0
     37c:      	fadd.4s	v4, v4, v0
     380:      	fadd.4s	v5, v5, v1
     384:      	ldp	q1, q0, [x9, #0xc0]
     388:      	fmul.4s	v1, v1, v1
     38c:      	fmul.4s	v0, v0, v0
     390:      	fadd.4s	v7, v7, v0
     394:      	fadd.4s	v6, v6, v1
     398:      	ldp	q1, q0, [x9, #0xe0]
     39c:      	fmul.4s	v1, v1, v1
     3a0:      	fmul.4s	v0, v0, v0
     3a4:      	fadd.4s	v16, v16, v0
     3a8:      	fadd.4s	v17, v17, v1
     3ac:      	add	x8, x8, #0x4
     3b0:      	cmp	x8, #0x5c
     3b4:      	b.lo	0x358 <ltmp0+0x358>
     3b8:      	add	x0, sp, #0x250
     3bc:      	mov	x1, x22
     3c0:      	mov	w2, #0xc00              ; =3072
     3c4:      	stp	q4, q2, [sp, #0x80]
     3c8:      	stp	q5, q3, [sp, #0x50]
     3cc:      	stp	q6, q16, [sp, #0xb0]
     3d0:      	str	q7, [sp, #0x70]
     3d4:      	str	q17, [sp, #0xa0]
     3d8:      	bl	0x3d8 <ltmp0+0x3d8>
     3dc:      	mov	x8, #0x0                ; =0
     3e0:      	ldp	q1, q0, [sp, #0x50]
     3e4:      	fadd.4s	v0, v0, v1
     3e8:      	ldp	q2, q1, [sp, #0x80]
     3ec:      	fadd.4s	v1, v1, v2
     3f0:      	ldr	q2, [sp, #0x70]
     3f4:      	fadd.4s	v1, v1, v2
     3f8:      	ldp	q2, q3, [sp, #0xa0]
     3fc:      	fadd.4s	v0, v0, v3
     400:      	fadd.4s	v0, v0, v2
     404:      	ldr	q2, [sp, #0xc0]
     408:      	fadd.4s	v1, v1, v2
     40c:      	rev64.4s	v2, v1
     410:      	rev64.4s	v3, v0
     414:      	fadd.4s	v0, v0, v3
     418:      	fadd.4s	v1, v1, v2
     41c:      	dup.4s	v2, v1[2]
     420:      	dup.4s	v3, v0[2]
     424:      	fadd.4s	v0, v0, v3
     428:      	fadd.4s	v1, v1, v2
     42c:      	fadd.4s	v0, v0, v1
     430:      	fadd	s0, s0, s8
     434:      	mov	w9, #0x44400000         ; =1145044992
     438:      	fmov	s1, w9
     43c:      	fdiv	s0, s0, s1
     440:      	mov	w9, #0xc5ac             ; =50604
     444:      	movk	w9, #0x3727, lsl #16
     448:      	fmov	s1, w9
     44c:      	fadd	s0, s0, s1
     450:      	fsqrt	s0, s0
     454:      	dup.4s	v0, v0[0]
     458:      	add	x9, x27, x8
     45c:      	ldp	q1, q2, [x9]
     460:      	fdiv.4s	v2, v2, v0
     464:      	fdiv.4s	v1, v1, v0
     468:      	add	x9, x28, x8
     46c:      	ldp	q4, q3, [x9]
     470:      	fmul.4s	v1, v1, v4
     474:      	fmul.4s	v2, v2, v3
     478:      	add	x9, x26, x8
     47c:      	stp	q1, q2, [x9]
     480:      	add	x8, x8, #0x20
     484:      	cmp	x8, #0xc00
     488:      	b.ne	0x458 <ltmp0+0x458>
     48c:      	add	x23, x23, #0x1
     490:      	add	x26, x26, #0xc00
     494:      	cmp	x23, x20
     498:      	b.ne	0x2f8 <ltmp0+0x2f8>
     49c:      	and	w8, w21, #0x7
     4a0:      	ldr	w25, [sp, #0x1c]
     4a4:      	ldr	w26, [sp, #0x2c]
     4a8:      	cbz	w8, 0x68 <ltmp0+0x68>
     4ac:      	dup.4s	v1, w8
     4b0:      	adrp	x8, 0x0 <ltmp0>
     4b4:      	ldr	q3, [x8]
     4b8:      	adrp	x8, 0x0 <ltmp0>
     4bc:      	ldr	q4, [x8]
     4c0:      	cmhi.4s	v0, v1, v4
     4c4:      	cmhi.4s	v1, v1, v3
     4c8:      	uzp1.8h	v5, v1, v0
     4cc:      	umaxv.8h	h2, v5
     4d0:      	fmov	w8, s2
     4d4:      	ldr	x14, [sp, #0x48]
     4d8:      	tbz	w8, #0x0, 0x68 <ltmp0+0x68>
     4dc:      	mov	x12, #0x0               ; =0
     4e0:      	ldr	x13, [sp, #0x20]
     4e4:      	ldr	x11, [x13, #0x10]
     4e8:      	ldr	x8, [x13, #0x30]
     4ec:      	adrp	x9, 0x0 <ltmp0>
     4f0:      	ldr	q2, [x9]
     4f4:      	and.16b	v2, v5, v2
     4f8:      	addv.8h	h2, v2
     4fc:      	fmov	w9, s2
     500:      	and	w10, w9, #0xff
     504:      	ubfiz	w9, w14, #2, #27
     508:      	orr	w9, w9, w20
     50c:      	ldr	x13, [x13]
     510:      	fmov	s6, w9
     514:      	and.16b	v6, v1, v6
     518:      	fmov	w9, s6
     51c:      	mov	w14, #0xc00             ; =3072
     520:      	umaddl	x13, w9, w14, x13
     524:      	umull	x9, w9, w14
     528:      	b	0x54c <ltmp0+0x54c>
     52c:      	add	x14, x27, x12
     530:      	ldp	q16, q17, [x14]
     534:      	bif.16b	v7, v17, v0
     538:      	bif.16b	v6, v16, v1
     53c:      	stp	q6, q7, [x14]
     540:      	add	x12, x12, #0x20
     544:      	cmp	x12, #0xc00
     548:      	b.eq	0x5e4 <ltmp0+0x5e4>
     54c:      	fmov	w15, s2
     550:      	add	x14, x13, x12
     554:      	movi.2d	v6, #0000000000000000
     558:      	movi.2d	v7, #0000000000000000
     55c:      	tbnz	w15, #0x0, 0x584 <ltmp0+0x584>
     560:      	and	w15, w15, #0xff
     564:      	tbnz	w15, #0x1, 0x590 <ltmp0+0x590>
     568:      	tbnz	w15, #0x2, 0x59c <ltmp0+0x59c>
     56c:      	tbnz	w15, #0x3, 0x5a8 <ltmp0+0x5a8>
     570:      	tbnz	w15, #0x4, 0x5b4 <ltmp0+0x5b4>
     574:      	tbnz	w15, #0x5, 0x5c0 <ltmp0+0x5c0>
     578:      	tbnz	w15, #0x6, 0x5cc <ltmp0+0x5cc>
     57c:      	tbz	w15, #0x7, 0x52c <ltmp0+0x52c>
     580:      	b	0x5d8 <ltmp0+0x5d8>
     584:      	ldr	s6, [x14]
     588:      	and	w15, w15, #0xff
     58c:      	tbz	w15, #0x1, 0x568 <ltmp0+0x568>
     590:      	add	x16, x14, #0x4
     594:      	ld1.s	{ v6 }[1], [x16]
     598:      	tbz	w15, #0x2, 0x56c <ltmp0+0x56c>
     59c:      	add	x16, x14, #0x8
     5a0:      	ld1.s	{ v6 }[2], [x16]
     5a4:      	tbz	w15, #0x3, 0x570 <ltmp0+0x570>
     5a8:      	add	x16, x14, #0xc
     5ac:      	ld1.s	{ v6 }[3], [x16]
     5b0:      	tbz	w15, #0x4, 0x574 <ltmp0+0x574>
     5b4:      	add	x16, x14, #0x10
     5b8:      	ld1.s	{ v7 }[0], [x16]
     5bc:      	tbz	w15, #0x5, 0x578 <ltmp0+0x578>
     5c0:      	add	x16, x14, #0x14
     5c4:      	ld1.s	{ v7 }[1], [x16]
     5c8:      	tbz	w15, #0x6, 0x57c <ltmp0+0x57c>
     5cc:      	add	x16, x14, #0x18
     5d0:      	ld1.s	{ v7 }[2], [x16]
     5d4:      	tbz	w15, #0x7, 0x52c <ltmp0+0x52c>
     5d8:      	add	x14, x14, #0x1c
     5dc:      	ld1.s	{ v7 }[3], [x14]
     5e0:      	b	0x52c <ltmp0+0x52c>
     5e4:      	ldr	q6, [x24, #0xd00]
     5e8:      	ldr	q7, [x24, #0xcf0]
     5ec:      	fmul.4s	v16, v7, v7
     5f0:      	fmul.4s	v6, v6, v6
     5f4:      	ldr	q7, [x24, #0xd20]
     5f8:      	ldr	q17, [x24, #0xd10]
     5fc:      	fmul.4s	v17, v17, v17
     600:      	fmul.4s	v18, v7, v7
     604:      	ldr	q7, [x24, #0xd40]
     608:      	ldr	q19, [x24, #0xd30]
     60c:      	fmul.4s	v21, v19, v19
     610:      	fmul.4s	v22, v7, v7
     614:      	ldr	q7, [x24, #0xd60]
     618:      	ldr	q19, [x24, #0xd50]
     61c:      	fmul.4s	v23, v19, v19
     620:      	fmul.4s	v24, v7, v7
     624:      	and.16b	v7, v0, v6
     628:      	and.16b	v6, v1, v16
     62c:      	and.16b	v20, v0, v18
     630:      	and.16b	v19, v1, v17
     634:      	and.16b	v16, v0, v22
     638:      	and.16b	v21, v1, v21
     63c:      	and.16b	v18, v0, v24
     640:      	and.16b	v17, v1, v23
     644:      	ldr	x12, [sp, #0x10]
     648:      	mov	w13, #0x4               ; =4
     64c:      	ldp	q23, q22, [x12, #-0x60]
     650:      	and.16b	v23, v1, v23
     654:      	and.16b	v22, v0, v22
     658:      	fmul.4s	v22, v22, v22
     65c:      	fmul.4s	v23, v23, v23
     660:      	fadd.4s	v23, v6, v23
     664:      	fadd.4s	v22, v7, v22
     668:      	ldp	q25, q24, [x12, #-0x40]
     66c:      	and.16b	v25, v1, v25
     670:      	and.16b	v24, v0, v24
     674:      	fmul.4s	v24, v24, v24
     678:      	fmul.4s	v25, v25, v25
     67c:      	fadd.4s	v25, v19, v25
     680:      	fadd.4s	v24, v20, v24
     684:      	ldp	q27, q26, [x12, #-0x20]
     688:      	and.16b	v27, v1, v27
     68c:      	and.16b	v26, v0, v26
     690:      	fmul.4s	v26, v26, v26
     694:      	fmul.4s	v27, v27, v27
     698:      	fadd.4s	v27, v21, v27
     69c:      	fadd.4s	v26, v16, v26
     6a0:      	ldp	q29, q28, [x12], #0x80
     6a4:      	and.16b	v29, v1, v29
     6a8:      	and.16b	v28, v0, v28
     6ac:      	fmul.4s	v28, v28, v28
     6b0:      	fmul.4s	v29, v29, v29
     6b4:      	fadd.4s	v29, v17, v29
     6b8:      	fadd.4s	v28, v18, v28
     6bc:      	bit.16b	v7, v22, v0
     6c0:      	bit.16b	v6, v23, v1
     6c4:      	bit.16b	v20, v24, v0
     6c8:      	bit.16b	v19, v25, v1
     6cc:      	bit.16b	v16, v26, v0
     6d0:      	bit.16b	v21, v27, v1
     6d4:      	bit.16b	v18, v28, v0
     6d8:      	bit.16b	v17, v29, v1
     6dc:      	cmp	x13, #0x5c
     6e0:      	add	x13, x13, #0x4
     6e4:      	b.lo	0x64c <ltmp0+0x64c>
     6e8:      	mov	x12, #0x0               ; =0
     6ec:      	b	0x710 <ltmp0+0x710>
     6f0:      	add	x13, x28, x12
     6f4:      	ldp	q24, q25, [x13]
     6f8:      	bif.16b	v23, v25, v0
     6fc:      	bif.16b	v22, v24, v1
     700:      	stp	q22, q23, [x13]
     704:      	add	x12, x12, #0x20
     708:      	cmp	x12, #0xc00
     70c:      	b.eq	0x7a8 <ltmp0+0x7a8>
     710:      	fmov	w14, s2
     714:      	add	x13, x11, x12
     718:      	movi.2d	v22, #0000000000000000
     71c:      	movi.2d	v23, #0000000000000000
     720:      	tbnz	w14, #0x0, 0x748 <ltmp0+0x748>
     724:      	and	w14, w14, #0xff
     728:      	tbnz	w14, #0x1, 0x754 <ltmp0+0x754>
     72c:      	tbnz	w14, #0x2, 0x760 <ltmp0+0x760>
     730:      	tbnz	w14, #0x3, 0x76c <ltmp0+0x76c>
     734:      	tbnz	w14, #0x4, 0x778 <ltmp0+0x778>
     738:      	tbnz	w14, #0x5, 0x784 <ltmp0+0x784>
     73c:      	tbnz	w14, #0x6, 0x790 <ltmp0+0x790>
     740:      	tbz	w14, #0x7, 0x6f0 <ltmp0+0x6f0>
     744:      	b	0x79c <ltmp0+0x79c>
     748:      	ldr	s22, [x13]
     74c:      	and	w14, w14, #0xff
     750:      	tbz	w14, #0x1, 0x72c <ltmp0+0x72c>
     754:      	add	x15, x13, #0x4
     758:      	ld1.s	{ v22 }[1], [x15]
     75c:      	tbz	w14, #0x2, 0x730 <ltmp0+0x730>
     760:      	add	x15, x13, #0x8
     764:      	ld1.s	{ v22 }[2], [x15]
     768:      	tbz	w14, #0x3, 0x734 <ltmp0+0x734>
     76c:      	add	x15, x13, #0xc
     770:      	ld1.s	{ v22 }[3], [x15]
     774:      	tbz	w14, #0x4, 0x738 <ltmp0+0x738>
     778:      	add	x15, x13, #0x10
     77c:      	ld1.s	{ v23 }[0], [x15]
     780:      	tbz	w14, #0x5, 0x73c <ltmp0+0x73c>
     784:      	add	x15, x13, #0x14
     788:      	ld1.s	{ v23 }[1], [x15]
     78c:      	tbz	w14, #0x6, 0x740 <ltmp0+0x740>
     790:      	add	x15, x13, #0x18
     794:      	ld1.s	{ v23 }[2], [x15]
     798:      	tbz	w14, #0x7, 0x6f0 <ltmp0+0x6f0>
     79c:      	add	x13, x13, #0x1c
     7a0:      	ld1.s	{ v23 }[3], [x13]
     7a4:      	b	0x6f0 <ltmp0+0x6f0>
     7a8:      	mov	x11, #0x0               ; =0
     7ac:      	xtn.8b	v22, v5
     7b0:      	fadd.4s	v5, v7, v20
     7b4:      	fadd.4s	v6, v6, v19
     7b8:      	fadd.4s	v6, v6, v21
     7bc:      	fadd.4s	v5, v5, v16
     7c0:      	fadd.4s	v5, v5, v18
     7c4:      	fadd.4s	v6, v6, v17
     7c8:      	and.16b	v16, v1, v3
     7cc:      	and.16b	v3, v0, v4
     7d0:      	movi.4s	v4, #0x1
     7d4:      	eor.16b	v7, v3, v4
     7d8:      	eor.16b	v18, v16, v4
     7dc:      	umov.b	w13, v22[0]
     7e0:      	str	q6, [x24, #0xc0]
     7e4:      	ldr	s4, [x24, #0xc4]
     7e8:      	umov.b	w12, v22[1]
     7ec:      	ands	w14, w13, #0x1
     7f0:      	tst	w14, w12
     7f4:      	mov.s	w15, v18[1]
     7f8:      	fcsel	s4, s4, s8, ne
     7fc:      	add	x16, sp, #0xd8
     800:      	bfxil	x16, x15, #0, #3
     804:      	str	d22, [sp, #0xd8]
     808:      	ldrb	w16, [x16]
     80c:      	add	x17, sp, #0x200
     810:      	orr	x15, x17, x15, lsl #2
     814:      	stp	q6, q5, [x24, #0xa0]
     818:      	ldr	s16, [x15]
     81c:      	ands	w15, w12, #0x1
     820:      	tst	w15, w16
     824:      	fcsel	s16, s16, s8, ne
     828:      	mov.s	w15, v18[2]
     82c:      	add	x16, sp, #0xd8
     830:      	bfxil	x16, x15, #0, #3
     834:      	ldrb	w16, [x16]
     838:      	add	x17, sp, #0x1e0
     83c:      	orr	x17, x17, x15, lsl #2
     840:      	umov.b	w15, v22[2]
     844:      	stp	q6, q5, [x24, #0x80]
     848:      	ldr	s17, [x17]
     84c:      	ands	w17, w15, #0x1
     850:      	tst	w17, w16
     854:      	fcsel	s17, s17, s8, ne
     858:      	mov.s	w16, v18[3]
     85c:      	add	x17, sp, #0xd8
     860:      	bfxil	x17, x16, #0, #3
     864:      	ldrb	w17, [x17]
     868:      	add	x0, sp, #0x1c0
     86c:      	orr	x0, x0, x16, lsl #2
     870:      	umov.b	w16, v22[3]
     874:      	stp	q6, q5, [x24, #0x60]
     878:      	ldr	s18, [x0]
     87c:      	ands	w0, w16, #0x1
     880:      	tst	w0, w17
     884:      	fcsel	s18, s18, s8, ne
     888:      	fmov	w0, s7
     88c:      	add	x17, sp, #0xd8
     890:      	bfxil	x17, x0, #0, #3
     894:      	ldrb	w1, [x17]
     898:      	umov.b	w17, v22[4]
     89c:      	and	w1, w17, w1
     8a0:      	stp	q6, q5, [x24, #0x40]
     8a4:      	add	x2, sp, #0x1a0
     8a8:      	ldr	s19, [x2, w0, uxtw #2]
     8ac:      	tst	w1, #0x1
     8b0:      	mov.s	w1, v7[1]
     8b4:      	fcsel	s19, s19, s8, ne
     8b8:      	add	x0, sp, #0xd8
     8bc:      	bfxil	x0, x1, #0, #3
     8c0:      	ldrb	w2, [x0]
     8c4:      	umov.b	w0, v22[5]
     8c8:      	stp	q6, q5, [x24, #0x20]
     8cc:      	add	x3, sp, #0x180
     8d0:      	ldr	s20, [x3, w1, uxtw #2]
     8d4:      	ands	w1, w0, #0x1
     8d8:      	tst	w1, w2
     8dc:      	fcsel	s20, s20, s8, ne
     8e0:      	mov.s	w2, v7[2]
     8e4:      	add	x1, sp, #0xd8
     8e8:      	bfxil	x1, x2, #0, #3
     8ec:      	ldrb	w3, [x1]
     8f0:      	umov.b	w1, v22[6]
     8f4:      	stp	q6, q5, [x24]
     8f8:      	ldr	s21, [x24, w2, uxtw #2]
     8fc:      	ands	w2, w1, #0x1
     900:      	tst	w2, w3
     904:      	fcsel	s21, s21, s8, ne
     908:      	mov.s	w3, v7[3]
     90c:      	add	x2, sp, #0xd8
     910:      	bfxil	x2, x3, #0, #3
     914:      	ldrb	w4, [x2]
     918:      	umov.b	w2, v22[7]
     91c:      	stp	q6, q5, [sp, #0x140]
     920:      	add	x5, sp, #0x140
     924:      	ldr	s7, [x5, w3, uxtw #2]
     928:      	ands	w3, w2, #0x1
     92c:      	tst	w3, w4
     930:      	mov.s	v4[1], v16[0]
     934:      	mov.s	v4[2], v17[0]
     938:      	mov.s	v4[3], v18[0]
     93c:      	mov.s	v19[1], v20[0]
     940:      	fcsel	s7, s7, s8, ne
     944:      	mov.s	v19[2], v21[0]
     948:      	mov.s	v19[3], v7[0]
     94c:      	fadd.4s	v5, v5, v19
     950:      	fadd.4s	v4, v6, v4
     954:      	movi.4s	v6, #0x2
     958:      	eor.16b	v3, v3, v6
     95c:      	str	q4, [sp, #0x120]
     960:      	ldr	s6, [sp, #0x128]
     964:      	fmov	w3, s3
     968:      	add	x4, sp, #0xd8
     96c:      	bfxil	x4, x3, #0, #3
     970:      	ldrb	w4, [x4]
     974:      	stp	q4, q5, [sp, #0x100]
     978:      	add	x5, sp, #0x100
     97c:      	ldr	s3, [x5, w3, uxtw #2]
     980:      	tst	w14, w15
     984:      	fcsel	s6, s6, s8, ne
     988:      	and	w3, w17, w4
     98c:      	tst	w3, #0x1
     990:      	fcsel	s3, s3, s8, ne
     994:      	fadd.4s	v3, v5, v3
     998:      	tst	w14, w17
     99c:      	fcsel	s3, s3, s8, ne
     9a0:      	ands	w13, w13, #0x1
     9a4:      	fadd.4s	v4, v4, v6
     9a8:      	fadd	s3, s4, s3
     9ac:      	fcsel	s4, s3, s8, ne
     9b0:      	tst	w12, #0x1
     9b4:      	fcsel	s5, s4, s8, ne
     9b8:      	tst	w15, #0x1
     9bc:      	fcsel	s6, s4, s8, ne
     9c0:      	tst	w16, #0x1
     9c4:      	fcsel	s7, s4, s8, ne
     9c8:      	tst	w13, w17
     9cc:      	fcsel	s3, s3, s8, ne
     9d0:      	tst	w0, #0x1
     9d4:      	fcsel	s16, s4, s8, ne
     9d8:      	tst	w1, #0x1
     9dc:      	fcsel	s17, s4, s8, ne
     9e0:      	tst	w2, #0x1
     9e4:      	fcsel	s18, s4, s8, ne
     9e8:      	mov.s	v4[1], v5[0]
     9ec:      	mov.s	v4[2], v6[0]
     9f0:      	mov.s	v4[3], v7[0]
     9f4:      	mov.s	v3[1], v16[0]
     9f8:      	mov.s	v3[2], v17[0]
     9fc:      	mov.s	v3[3], v18[0]
     a00:      	rbit	w10, w10
     a04:      	clz	w10, w10
     a08:      	stp	q4, q3, [sp, #0xe0]
     a0c:      	and	x10, x10, #0x7
     a10:      	add	x12, sp, #0xe0
     a14:      	ldr	s3, [x12, x10, lsl #2]
     a18:      	fadd	s3, s3, s8
     a1c:      	mov	w10, #0x44400000        ; =1145044992
     a20:      	fmov	s4, w10
     a24:      	fdiv	s3, s3, s4
     a28:      	mov	w10, #0xc5ac            ; =50604
     a2c:      	movk	w10, #0x3727, lsl #16
     a30:      	fmov	s4, w10
     a34:      	fadd	s3, s3, s4
     a38:      	fsqrt	s3, s3
     a3c:      	dup.4s	v3, v3[0]
     a40:      	add	x8, x8, x9
     a44:      	b	0xa54 <ltmp0+0xa54>
     a48:      	add	x11, x11, #0x20
     a4c:      	cmp	x11, #0xc00
     a50:      	b.eq	0x68 <ltmp0+0x68>
     a54:      	fmov	w10, s2
     a58:      	add	x9, x27, x11
     a5c:      	ldp	q5, q4, [x9]
     a60:      	and.16b	v5, v1, v5
     a64:      	fdiv.4s	v6, v5, v3
     a68:      	add	x9, x28, x11
     a6c:      	ldp	q7, q5, [x9]
     a70:      	and.16b	v7, v1, v7
     a74:      	fmul.4s	v6, v6, v7
     a78:      	add	x9, x8, x11
     a7c:      	tbnz	w10, #0x0, 0xab4 <ltmp0+0xab4>
     a80:      	and	w10, w10, #0xff
     a84:      	tbnz	w10, #0x1, 0xac0 <ltmp0+0xac0>
     a88:      	tbnz	w10, #0x2, 0xacc <ltmp0+0xacc>
     a8c:      	tbnz	w10, #0x3, 0xad8 <ltmp0+0xad8>
     a90:      	and.16b	v4, v0, v4
     a94:      	fdiv.4s	v4, v4, v3
     a98:      	and.16b	v5, v0, v5
     a9c:      	fmul.4s	v4, v4, v5
     aa0:      	tbnz	w10, #0x4, 0xaf4 <ltmp0+0xaf4>
     aa4:      	tbnz	w10, #0x5, 0xafc <ltmp0+0xafc>
     aa8:      	tbnz	w10, #0x6, 0xb08 <ltmp0+0xb08>
     aac:      	tbz	w10, #0x7, 0xa48 <ltmp0+0xa48>
     ab0:      	b	0xb14 <ltmp0+0xb14>
     ab4:      	str	s6, [x9]
     ab8:      	and	w10, w10, #0xff
     abc:      	tbz	w10, #0x1, 0xa88 <ltmp0+0xa88>
     ac0:      	add	x12, x9, #0x4
     ac4:      	st1.s	{ v6 }[1], [x12]
     ac8:      	tbz	w10, #0x2, 0xa8c <ltmp0+0xa8c>
     acc:      	add	x12, x9, #0x8
     ad0:      	st1.s	{ v6 }[2], [x12]
     ad4:      	tbz	w10, #0x3, 0xa90 <ltmp0+0xa90>
     ad8:      	add	x12, x9, #0xc
     adc:      	st1.s	{ v6 }[3], [x12]
     ae0:      	and.16b	v4, v0, v4
     ae4:      	fdiv.4s	v4, v4, v3
     ae8:      	and.16b	v5, v0, v5
     aec:      	fmul.4s	v4, v4, v5
     af0:      	tbz	w10, #0x4, 0xaa4 <ltmp0+0xaa4>
     af4:      	str	s4, [x9, #0x10]
     af8:      	tbz	w10, #0x5, 0xaa8 <ltmp0+0xaa8>
     afc:      	add	x12, x9, #0x14
     b00:      	st1.s	{ v4 }[1], [x12]
     b04:      	tbz	w10, #0x6, 0xaac <ltmp0+0xaac>
     b08:      	add	x12, x9, #0x18
     b0c:      	st1.s	{ v4 }[2], [x12]
     b10:      	tbz	w10, #0x7, 0xa48 <ltmp0+0xa48>
     b14:      	add	x9, x9, #0x1c
     b18:      	st1.s	{ v4 }[3], [x9]
     b1c:      	b	0xa48 <ltmp0+0xa48>
     b20:      	ldr	x9, [sp, #0x8]
     b24:      	stp	w14, w13, [x9]
     b28:      	str	w12, [x9, #0x8]
     b2c:      	mov	w8, #0x18               ; =24
     b30:      	str	w8, [x9, #0x24]
     b34:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
     b38:      	add	sp, sp, #0xa50
     b3c:      	ldp	x29, x30, [sp, #0x60]
     b40:      	ldp	x20, x19, [sp, #0x50]
     b44:      	ldp	x22, x21, [sp, #0x40]
     b48:      	ldp	x24, x23, [sp, #0x30]
     b4c:      	ldp	x26, x25, [sp, #0x20]
     b50:      	ldp	x28, x27, [sp, #0x10]
     b54:      	ldp	d9, d8, [sp], #0x70
     b58:      	ret

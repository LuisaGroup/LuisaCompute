; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [3072 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [3072 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.slot7 = alloca i64, align 8
  store i64 0, ptr %.slot7, align 4
  %.slot8 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot8, align 32
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.spill12 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill12, align 4
  %tile_snapshot.spill13 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill13, align 64
  %.slot14 = alloca i64, align 8
  store i64 0, ptr %.slot14, align 4
  %.spill15 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill15, align 4
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat18, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat20, %41
  %44 = mul i32 %32, 1
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat22, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat24, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat26
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 96
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state27 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state27, 8
  %.splatinsert28 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat29 = shufflevector <8 x i64> %.splatinsert28, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat29, %.spill.load
  %.spill.load30 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load30, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 768)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state31 = load i64, ptr %.slot, align 4
  %.splatinsert32 = insertelement <8 x i64> poison, i64 %.state31, i64 0
  %.splat33 = shufflevector <8 x i64> %.splatinsert32, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat33, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state34 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state34, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  %tile_snapshot.spill.load35 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 0
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 1
  %104 = add <8 x i64> %103, zeroinitializer
  %105 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %102, 0
  %106 = insertvalue { <8 x ptr>, <8 x i64> } %105, <8 x i64> %104, 1
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %106, 1
  %109 = extractelement <8 x ptr> %107, i32 0
  %110 = extractelement <8 x i64> %108, i32 0
  %111 = sub i64 %110, 0
  %112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %113 = select i1 %112, i64 %111, i64 0
  %private.contiguous.address36 = getelementptr i8, ptr %109, i64 %113
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address36, align 4
  %114 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %115 = fmul <8 x float> %114, %114
  %tile_snapshot.spill.load37 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 0
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 1
  %118 = add <8 x i64> %117, splat (i64 32)
  %119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %116, 0
  %120 = insertvalue { <8 x ptr>, <8 x i64> } %119, <8 x i64> %118, 1
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %120, 1
  %123 = extractelement <8 x ptr> %121, i32 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %127 = select i1 %126, i64 %125, i64 0
  %private.contiguous.address38 = getelementptr i8, ptr %123, i64 %127
  %private.contiguous.load39 = load <8 x float>, ptr %private.contiguous.address38, align 4
  %128 = select <8 x i1> %51, <8 x float> %private.contiguous.load39, <8 x float> zeroinitializer
  %129 = fmul <8 x float> %128, %128
  %tile_snapshot.spill.load40 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load40, 0
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load40, 1
  %132 = add <8 x i64> %131, splat (i64 64)
  %133 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %130, 0
  %134 = insertvalue { <8 x ptr>, <8 x i64> } %133, <8 x i64> %132, 1
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %134, 1
  %137 = extractelement <8 x ptr> %135, i32 0
  %138 = extractelement <8 x i64> %136, i32 0
  %139 = sub i64 %138, 0
  %140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %141 = select i1 %140, i64 %139, i64 0
  %private.contiguous.address41 = getelementptr i8, ptr %137, i64 %141
  %private.contiguous.load42 = load <8 x float>, ptr %private.contiguous.address41, align 4
  %142 = select <8 x i1> %51, <8 x float> %private.contiguous.load42, <8 x float> zeroinitializer
  %143 = fmul <8 x float> %142, %142
  %tile_snapshot.spill.load43 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 0
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 1
  %146 = add <8 x i64> %145, splat (i64 96)
  %147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %144, 0
  %148 = insertvalue { <8 x ptr>, <8 x i64> } %147, <8 x i64> %146, 1
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %148, 1
  %151 = extractelement <8 x ptr> %149, i32 0
  %152 = extractelement <8 x i64> %150, i32 0
  %153 = sub i64 %152, 0
  %154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %155 = select i1 %154, i64 %153, i64 0
  %private.contiguous.address44 = getelementptr i8, ptr %151, i64 %155
  %private.contiguous.load45 = load <8 x float>, ptr %private.contiguous.address44, align 4
  %156 = select <8 x i1> %51, <8 x float> %private.contiguous.load45, <8 x float> zeroinitializer
  %157 = fmul <8 x float> %156, %156
  store i64 4, ptr %.slot7, align 4
  %158 = load <8 x float>, ptr %.slot8, align 32
  %159 = select <8 x i1> %51, <8 x float> %115, <8 x float> %158
  store <8 x float> %159, ptr %.slot8, align 32
  %160 = load <8 x float>, ptr %.slot9, align 32
  %161 = select <8 x i1> %51, <8 x float> %129, <8 x float> %160
  store <8 x float> %161, ptr %.slot9, align 32
  %162 = load <8 x float>, ptr %.slot10, align 32
  %163 = select <8 x i1> %51, <8 x float> %143, <8 x float> %162
  store <8 x float> %163, ptr %.slot10, align 32
  %164 = load <8 x float>, ptr %.slot11, align 32
  %165 = select <8 x i1> %51, <8 x float> %157, <8 x float> %164
  store <8 x float> %165, ptr %.slot11, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state46 = load i64, ptr %.slot7, align 4
  %166 = icmp slt i64 %.state46, 96
  br i1 %166, label %direct.true47, label %direct.false48

direct.schedule.5:                                ; preds = %direct.true47
  %.state49 = load i64, ptr %.slot7, align 4
  %167 = add i64 %.state49, 0
  %tile_snapshot.spill.load50 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load50, 0
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load50, 1
  %.splatinsert51 = insertelement <8 x i64> poison, i64 %167, i64 0
  %.splat52 = shufflevector <8 x i64> %.splatinsert51, <8 x i64> poison, <8 x i32> zeroinitializer
  %170 = mul <8 x i64> %.splat52, splat (i64 32)
  %171 = add <8 x i64> %169, %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %173 = insertvalue { <8 x ptr>, <8 x i64> } %172, <8 x i64> %171, 1
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %173, 1
  %176 = extractelement <8 x ptr> %174, i32 0
  %177 = extractelement <8 x i64> %175, i32 0
  %178 = sub i64 %177, 0
  %179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %180 = select i1 %179, i64 %178, i64 0
  %private.contiguous.address53 = getelementptr i8, ptr %176, i64 %180
  %private.contiguous.load54 = load <8 x float>, ptr %private.contiguous.address53, align 4
  %181 = select <8 x i1> %51, <8 x float> %private.contiguous.load54, <8 x float> zeroinitializer
  %182 = fmul <8 x float> %181, %181
  %.state55 = load <8 x float>, ptr %.slot8, align 32
  %183 = fadd <8 x float> %.state55, %182
  %.state56 = load i64, ptr %.slot7, align 4
  %184 = add i64 %.state56, 1
  %tile_snapshot.spill.load57 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 0
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 1
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %184, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %187 = mul <8 x i64> %.splat59, splat (i64 32)
  %188 = add <8 x i64> %186, %187
  %189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %185, 0
  %190 = insertvalue { <8 x ptr>, <8 x i64> } %189, <8 x i64> %188, 1
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %190, 1
  %193 = extractelement <8 x ptr> %191, i32 0
  %194 = extractelement <8 x i64> %192, i32 0
  %195 = sub i64 %194, 0
  %196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %197 = select i1 %196, i64 %195, i64 0
  %private.contiguous.address60 = getelementptr i8, ptr %193, i64 %197
  %private.contiguous.load61 = load <8 x float>, ptr %private.contiguous.address60, align 4
  %198 = select <8 x i1> %51, <8 x float> %private.contiguous.load61, <8 x float> zeroinitializer
  %199 = fmul <8 x float> %198, %198
  %.state62 = load <8 x float>, ptr %.slot9, align 32
  %200 = fadd <8 x float> %.state62, %199
  %.state63 = load i64, ptr %.slot7, align 4
  %201 = add i64 %.state63, 2
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %.splatinsert65 = insertelement <8 x i64> poison, i64 %201, i64 0
  %.splat66 = shufflevector <8 x i64> %.splatinsert65, <8 x i64> poison, <8 x i32> zeroinitializer
  %204 = mul <8 x i64> %.splat66, splat (i64 32)
  %205 = add <8 x i64> %203, %204
  %206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %202, 0
  %207 = insertvalue { <8 x ptr>, <8 x i64> } %206, <8 x i64> %205, 1
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %207, 1
  %210 = extractelement <8 x ptr> %208, i32 0
  %211 = extractelement <8 x i64> %209, i32 0
  %212 = sub i64 %211, 0
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %214 = select i1 %213, i64 %212, i64 0
  %private.contiguous.address67 = getelementptr i8, ptr %210, i64 %214
  %private.contiguous.load68 = load <8 x float>, ptr %private.contiguous.address67, align 4
  %215 = select <8 x i1> %51, <8 x float> %private.contiguous.load68, <8 x float> zeroinitializer
  %216 = fmul <8 x float> %215, %215
  %.state69 = load <8 x float>, ptr %.slot10, align 32
  %217 = fadd <8 x float> %.state69, %216
  %.state70 = load i64, ptr %.slot7, align 4
  %218 = add i64 %.state70, 3
  %tile_snapshot.spill.load71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 0
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 1
  %.splatinsert72 = insertelement <8 x i64> poison, i64 %218, i64 0
  %.splat73 = shufflevector <8 x i64> %.splatinsert72, <8 x i64> poison, <8 x i32> zeroinitializer
  %221 = mul <8 x i64> %.splat73, splat (i64 32)
  %222 = add <8 x i64> %220, %221
  %223 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %219, 0
  %224 = insertvalue { <8 x ptr>, <8 x i64> } %223, <8 x i64> %222, 1
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %224, 1
  %227 = extractelement <8 x ptr> %225, i32 0
  %228 = extractelement <8 x i64> %226, i32 0
  %229 = sub i64 %228, 0
  %230 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %231 = select i1 %230, i64 %229, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %227, i64 %231
  %private.contiguous.load75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %232 = select <8 x i1> %51, <8 x float> %private.contiguous.load75, <8 x float> zeroinitializer
  %233 = fmul <8 x float> %232, %232
  %.state76 = load <8 x float>, ptr %.slot11, align 32
  %234 = fadd <8 x float> %.state76, %233
  %.state77 = load i64, ptr %.slot7, align 4
  %235 = add i64 %.state77, 4
  store i64 %235, ptr %.slot7, align 4
  %236 = load <8 x float>, ptr %.slot8, align 32
  %237 = select <8 x i1> %51, <8 x float> %183, <8 x float> %236
  store <8 x float> %237, ptr %.slot8, align 32
  %238 = load <8 x float>, ptr %.slot9, align 32
  %239 = select <8 x i1> %51, <8 x float> %200, <8 x float> %238
  store <8 x float> %239, ptr %.slot9, align 32
  %240 = load <8 x float>, ptr %.slot10, align 32
  %241 = select <8 x i1> %51, <8 x float> %217, <8 x float> %240
  store <8 x float> %241, ptr %.slot10, align 32
  %242 = load <8 x float>, ptr %.slot11, align 32
  %243 = select <8 x i1> %51, <8 x float> %234, <8 x float> %242
  store <8 x float> %243, ptr %.slot11, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false48
  %.state78 = load <8 x float>, ptr %.slot8, align 32
  %.state79 = load <8 x float>, ptr %.slot9, align 32
  %244 = fadd <8 x float> %.state78, %.state79
  %.state80 = load <8 x float>, ptr %.slot10, align 32
  %245 = fadd <8 x float> %244, %.state80
  %.state81 = load <8 x float>, ptr %.slot11, align 32
  %246 = fadd <8 x float> %245, %.state81
  %.spill.load82 = load <8 x i64>, ptr %.spill, align 64
  %247 = trunc <8 x i64> %.spill.load82 to <8 x i32>
  %248 = xor <8 x i32> %247, splat (i32 1)
  %249 = extractelement <8 x i32> %248, i64 0
  %250 = icmp ult i32 %249, 8
  %251 = select i1 %250, i32 %249, i32 0
  %252 = extractelement <8 x i1> %51, i32 %251
  %253 = extractelement <8 x i1> %51, i64 0
  %254 = and i1 %250, %252
  %255 = and i1 %253, %254
  %256 = extractelement <8 x float> %246, i32 %251
  %257 = select i1 %255, float %256, float 0.000000e+00
  %258 = insertelement <8 x float> poison, float %257, i64 0
  %259 = xor i1 %255, true
  %260 = and i1 %253, %259
  %261 = insertelement <8 x i1> poison, i1 %260, i64 0
  %262 = extractelement <8 x i32> %248, i64 1
  %263 = icmp ult i32 %262, 8
  %264 = select i1 %263, i32 %262, i32 0
  %265 = extractelement <8 x i1> %51, i32 %264
  %266 = extractelement <8 x i1> %51, i64 1
  %267 = and i1 %263, %265
  %268 = and i1 %266, %267
  %269 = extractelement <8 x float> %246, i32 %264
  %270 = select i1 %268, float %269, float 0.000000e+00
  %271 = insertelement <8 x float> %258, float %270, i64 1
  %272 = xor i1 %268, true
  %273 = and i1 %266, %272
  %274 = insertelement <8 x i1> %261, i1 %273, i64 1
  %275 = extractelement <8 x i32> %248, i64 2
  %276 = icmp ult i32 %275, 8
  %277 = select i1 %276, i32 %275, i32 0
  %278 = extractelement <8 x i1> %51, i32 %277
  %279 = extractelement <8 x i1> %51, i64 2
  %280 = and i1 %276, %278
  %281 = and i1 %279, %280
  %282 = extractelement <8 x float> %246, i32 %277
  %283 = select i1 %281, float %282, float 0.000000e+00
  %284 = insertelement <8 x float> %271, float %283, i64 2
  %285 = xor i1 %281, true
  %286 = and i1 %279, %285
  %287 = insertelement <8 x i1> %274, i1 %286, i64 2
  %288 = extractelement <8 x i32> %248, i64 3
  %289 = icmp ult i32 %288, 8
  %290 = select i1 %289, i32 %288, i32 0
  %291 = extractelement <8 x i1> %51, i32 %290
  %292 = extractelement <8 x i1> %51, i64 3
  %293 = and i1 %289, %291
  %294 = and i1 %292, %293
  %295 = extractelement <8 x float> %246, i32 %290
  %296 = select i1 %294, float %295, float 0.000000e+00
  %297 = insertelement <8 x float> %284, float %296, i64 3
  %298 = xor i1 %294, true
  %299 = and i1 %292, %298
  %300 = insertelement <8 x i1> %287, i1 %299, i64 3
  %301 = extractelement <8 x i32> %248, i64 4
  %302 = icmp ult i32 %301, 8
  %303 = select i1 %302, i32 %301, i32 0
  %304 = extractelement <8 x i1> %51, i32 %303
  %305 = extractelement <8 x i1> %51, i64 4
  %306 = and i1 %302, %304
  %307 = and i1 %305, %306
  %308 = extractelement <8 x float> %246, i32 %303
  %309 = select i1 %307, float %308, float 0.000000e+00
  %310 = insertelement <8 x float> %297, float %309, i64 4
  %311 = xor i1 %307, true
  %312 = and i1 %305, %311
  %313 = insertelement <8 x i1> %300, i1 %312, i64 4
  %314 = extractelement <8 x i32> %248, i64 5
  %315 = icmp ult i32 %314, 8
  %316 = select i1 %315, i32 %314, i32 0
  %317 = extractelement <8 x i1> %51, i32 %316
  %318 = extractelement <8 x i1> %51, i64 5
  %319 = and i1 %315, %317
  %320 = and i1 %318, %319
  %321 = extractelement <8 x float> %246, i32 %316
  %322 = select i1 %320, float %321, float 0.000000e+00
  %323 = insertelement <8 x float> %310, float %322, i64 5
  %324 = xor i1 %320, true
  %325 = and i1 %318, %324
  %326 = insertelement <8 x i1> %313, i1 %325, i64 5
  %327 = extractelement <8 x i32> %248, i64 6
  %328 = icmp ult i32 %327, 8
  %329 = select i1 %328, i32 %327, i32 0
  %330 = extractelement <8 x i1> %51, i32 %329
  %331 = extractelement <8 x i1> %51, i64 6
  %332 = and i1 %328, %330
  %333 = and i1 %331, %332
  %334 = extractelement <8 x float> %246, i32 %329
  %335 = select i1 %333, float %334, float 0.000000e+00
  %336 = insertelement <8 x float> %323, float %335, i64 6
  %337 = xor i1 %333, true
  %338 = and i1 %331, %337
  %339 = insertelement <8 x i1> %326, i1 %338, i64 6
  %340 = extractelement <8 x i32> %248, i64 7
  %341 = icmp ult i32 %340, 8
  %342 = select i1 %341, i32 %340, i32 0
  %343 = extractelement <8 x i1> %51, i32 %342
  %344 = extractelement <8 x i1> %51, i64 7
  %345 = and i1 %341, %343
  %346 = and i1 %344, %345
  %347 = extractelement <8 x float> %246, i32 %342
  %348 = select i1 %346, float %347, float 0.000000e+00
  %349 = insertelement <8 x float> %336, float %348, i64 7
  %350 = xor i1 %346, true
  %351 = and i1 %344, %350
  %352 = insertelement <8 x i1> %339, i1 %351, i64 7
  %353 = fadd <8 x float> %246, %349
  %354 = xor <8 x i32> %247, splat (i32 2)
  %355 = extractelement <8 x i32> %354, i64 0
  %356 = icmp ult i32 %355, 8
  %357 = select i1 %356, i32 %355, i32 0
  %358 = extractelement <8 x i1> %51, i32 %357
  %359 = extractelement <8 x i1> %51, i64 0
  %360 = and i1 %356, %358
  %361 = and i1 %359, %360
  %362 = extractelement <8 x float> %353, i32 %357
  %363 = select i1 %361, float %362, float 0.000000e+00
  %364 = insertelement <8 x float> poison, float %363, i64 0
  %365 = xor i1 %361, true
  %366 = and i1 %359, %365
  %367 = insertelement <8 x i1> poison, i1 %366, i64 0
  %368 = extractelement <8 x i32> %354, i64 1
  %369 = icmp ult i32 %368, 8
  %370 = select i1 %369, i32 %368, i32 0
  %371 = extractelement <8 x i1> %51, i32 %370
  %372 = extractelement <8 x i1> %51, i64 1
  %373 = and i1 %369, %371
  %374 = and i1 %372, %373
  %375 = extractelement <8 x float> %353, i32 %370
  %376 = select i1 %374, float %375, float 0.000000e+00
  %377 = insertelement <8 x float> %364, float %376, i64 1
  %378 = xor i1 %374, true
  %379 = and i1 %372, %378
  %380 = insertelement <8 x i1> %367, i1 %379, i64 1
  %381 = extractelement <8 x i32> %354, i64 2
  %382 = icmp ult i32 %381, 8
  %383 = select i1 %382, i32 %381, i32 0
  %384 = extractelement <8 x i1> %51, i32 %383
  %385 = extractelement <8 x i1> %51, i64 2
  %386 = and i1 %382, %384
  %387 = and i1 %385, %386
  %388 = extractelement <8 x float> %353, i32 %383
  %389 = select i1 %387, float %388, float 0.000000e+00
  %390 = insertelement <8 x float> %377, float %389, i64 2
  %391 = xor i1 %387, true
  %392 = and i1 %385, %391
  %393 = insertelement <8 x i1> %380, i1 %392, i64 2
  %394 = extractelement <8 x i32> %354, i64 3
  %395 = icmp ult i32 %394, 8
  %396 = select i1 %395, i32 %394, i32 0
  %397 = extractelement <8 x i1> %51, i32 %396
  %398 = extractelement <8 x i1> %51, i64 3
  %399 = and i1 %395, %397
  %400 = and i1 %398, %399
  %401 = extractelement <8 x float> %353, i32 %396
  %402 = select i1 %400, float %401, float 0.000000e+00
  %403 = insertelement <8 x float> %390, float %402, i64 3
  %404 = xor i1 %400, true
  %405 = and i1 %398, %404
  %406 = insertelement <8 x i1> %393, i1 %405, i64 3
  %407 = extractelement <8 x i32> %354, i64 4
  %408 = icmp ult i32 %407, 8
  %409 = select i1 %408, i32 %407, i32 0
  %410 = extractelement <8 x i1> %51, i32 %409
  %411 = extractelement <8 x i1> %51, i64 4
  %412 = and i1 %408, %410
  %413 = and i1 %411, %412
  %414 = extractelement <8 x float> %353, i32 %409
  %415 = select i1 %413, float %414, float 0.000000e+00
  %416 = insertelement <8 x float> %403, float %415, i64 4
  %417 = xor i1 %413, true
  %418 = and i1 %411, %417
  %419 = insertelement <8 x i1> %406, i1 %418, i64 4
  %420 = extractelement <8 x i32> %354, i64 5
  %421 = icmp ult i32 %420, 8
  %422 = select i1 %421, i32 %420, i32 0
  %423 = extractelement <8 x i1> %51, i32 %422
  %424 = extractelement <8 x i1> %51, i64 5
  %425 = and i1 %421, %423
  %426 = and i1 %424, %425
  %427 = extractelement <8 x float> %353, i32 %422
  %428 = select i1 %426, float %427, float 0.000000e+00
  %429 = insertelement <8 x float> %416, float %428, i64 5
  %430 = xor i1 %426, true
  %431 = and i1 %424, %430
  %432 = insertelement <8 x i1> %419, i1 %431, i64 5
  %433 = extractelement <8 x i32> %354, i64 6
  %434 = icmp ult i32 %433, 8
  %435 = select i1 %434, i32 %433, i32 0
  %436 = extractelement <8 x i1> %51, i32 %435
  %437 = extractelement <8 x i1> %51, i64 6
  %438 = and i1 %434, %436
  %439 = and i1 %437, %438
  %440 = extractelement <8 x float> %353, i32 %435
  %441 = select i1 %439, float %440, float 0.000000e+00
  %442 = insertelement <8 x float> %429, float %441, i64 6
  %443 = xor i1 %439, true
  %444 = and i1 %437, %443
  %445 = insertelement <8 x i1> %432, i1 %444, i64 6
  %446 = extractelement <8 x i32> %354, i64 7
  %447 = icmp ult i32 %446, 8
  %448 = select i1 %447, i32 %446, i32 0
  %449 = extractelement <8 x i1> %51, i32 %448
  %450 = extractelement <8 x i1> %51, i64 7
  %451 = and i1 %447, %449
  %452 = and i1 %450, %451
  %453 = extractelement <8 x float> %353, i32 %448
  %454 = select i1 %452, float %453, float 0.000000e+00
  %455 = insertelement <8 x float> %442, float %454, i64 7
  %456 = xor i1 %452, true
  %457 = and i1 %450, %456
  %458 = insertelement <8 x i1> %445, i1 %457, i64 7
  %459 = fadd <8 x float> %353, %455
  %460 = xor <8 x i32> %247, splat (i32 4)
  %461 = extractelement <8 x i32> %460, i64 0
  %462 = icmp ult i32 %461, 8
  %463 = select i1 %462, i32 %461, i32 0
  %464 = extractelement <8 x i1> %51, i32 %463
  %465 = extractelement <8 x i1> %51, i64 0
  %466 = and i1 %462, %464
  %467 = and i1 %465, %466
  %468 = extractelement <8 x float> %459, i32 %463
  %469 = select i1 %467, float %468, float 0.000000e+00
  %470 = insertelement <8 x float> poison, float %469, i64 0
  %471 = xor i1 %467, true
  %472 = and i1 %465, %471
  %473 = insertelement <8 x i1> poison, i1 %472, i64 0
  %474 = extractelement <8 x i32> %460, i64 1
  %475 = icmp ult i32 %474, 8
  %476 = select i1 %475, i32 %474, i32 0
  %477 = extractelement <8 x i1> %51, i32 %476
  %478 = extractelement <8 x i1> %51, i64 1
  %479 = and i1 %475, %477
  %480 = and i1 %478, %479
  %481 = extractelement <8 x float> %459, i32 %476
  %482 = select i1 %480, float %481, float 0.000000e+00
  %483 = insertelement <8 x float> %470, float %482, i64 1
  %484 = xor i1 %480, true
  %485 = and i1 %478, %484
  %486 = insertelement <8 x i1> %473, i1 %485, i64 1
  %487 = extractelement <8 x i32> %460, i64 2
  %488 = icmp ult i32 %487, 8
  %489 = select i1 %488, i32 %487, i32 0
  %490 = extractelement <8 x i1> %51, i32 %489
  %491 = extractelement <8 x i1> %51, i64 2
  %492 = and i1 %488, %490
  %493 = and i1 %491, %492
  %494 = extractelement <8 x float> %459, i32 %489
  %495 = select i1 %493, float %494, float 0.000000e+00
  %496 = insertelement <8 x float> %483, float %495, i64 2
  %497 = xor i1 %493, true
  %498 = and i1 %491, %497
  %499 = insertelement <8 x i1> %486, i1 %498, i64 2
  %500 = extractelement <8 x i32> %460, i64 3
  %501 = icmp ult i32 %500, 8
  %502 = select i1 %501, i32 %500, i32 0
  %503 = extractelement <8 x i1> %51, i32 %502
  %504 = extractelement <8 x i1> %51, i64 3
  %505 = and i1 %501, %503
  %506 = and i1 %504, %505
  %507 = extractelement <8 x float> %459, i32 %502
  %508 = select i1 %506, float %507, float 0.000000e+00
  %509 = insertelement <8 x float> %496, float %508, i64 3
  %510 = xor i1 %506, true
  %511 = and i1 %504, %510
  %512 = insertelement <8 x i1> %499, i1 %511, i64 3
  %513 = extractelement <8 x i32> %460, i64 4
  %514 = icmp ult i32 %513, 8
  %515 = select i1 %514, i32 %513, i32 0
  %516 = extractelement <8 x i1> %51, i32 %515
  %517 = extractelement <8 x i1> %51, i64 4
  %518 = and i1 %514, %516
  %519 = and i1 %517, %518
  %520 = extractelement <8 x float> %459, i32 %515
  %521 = select i1 %519, float %520, float 0.000000e+00
  %522 = insertelement <8 x float> %509, float %521, i64 4
  %523 = xor i1 %519, true
  %524 = and i1 %517, %523
  %525 = insertelement <8 x i1> %512, i1 %524, i64 4
  %526 = extractelement <8 x i32> %460, i64 5
  %527 = icmp ult i32 %526, 8
  %528 = select i1 %527, i32 %526, i32 0
  %529 = extractelement <8 x i1> %51, i32 %528
  %530 = extractelement <8 x i1> %51, i64 5
  %531 = and i1 %527, %529
  %532 = and i1 %530, %531
  %533 = extractelement <8 x float> %459, i32 %528
  %534 = select i1 %532, float %533, float 0.000000e+00
  %535 = insertelement <8 x float> %522, float %534, i64 5
  %536 = xor i1 %532, true
  %537 = and i1 %530, %536
  %538 = insertelement <8 x i1> %525, i1 %537, i64 5
  %539 = extractelement <8 x i32> %460, i64 6
  %540 = icmp ult i32 %539, 8
  %541 = select i1 %540, i32 %539, i32 0
  %542 = extractelement <8 x i1> %51, i32 %541
  %543 = extractelement <8 x i1> %51, i64 6
  %544 = and i1 %540, %542
  %545 = and i1 %543, %544
  %546 = extractelement <8 x float> %459, i32 %541
  %547 = select i1 %545, float %546, float 0.000000e+00
  %548 = insertelement <8 x float> %535, float %547, i64 6
  %549 = xor i1 %545, true
  %550 = and i1 %543, %549
  %551 = insertelement <8 x i1> %538, i1 %550, i64 6
  %552 = extractelement <8 x i32> %460, i64 7
  %553 = icmp ult i32 %552, 8
  %554 = select i1 %553, i32 %552, i32 0
  %555 = extractelement <8 x i1> %51, i32 %554
  %556 = extractelement <8 x i1> %51, i64 7
  %557 = and i1 %553, %555
  %558 = and i1 %556, %557
  %559 = extractelement <8 x float> %459, i32 %554
  %560 = select i1 %558, float %559, float 0.000000e+00
  %561 = insertelement <8 x float> %548, float %560, i64 7
  %562 = xor i1 %558, true
  %563 = and i1 %556, %562
  %564 = insertelement <8 x i1> %551, i1 %563, i64 7
  %565 = fadd <8 x float> %459, %561
  %566 = extractelement <8 x i1> %51, i32 0
  %567 = extractelement <8 x i1> %51, i64 0
  %568 = and i1 true, %566
  %569 = and i1 %567, %568
  %570 = extractelement <8 x float> %565, i32 0
  %571 = select i1 %569, float %570, float 0.000000e+00
  %572 = insertelement <8 x float> poison, float %571, i64 0
  %573 = xor i1 %569, true
  %574 = and i1 %567, %573
  %575 = insertelement <8 x i1> poison, i1 %574, i64 0
  %576 = extractelement <8 x i1> %51, i32 0
  %577 = extractelement <8 x i1> %51, i64 1
  %578 = and i1 true, %576
  %579 = and i1 %577, %578
  %580 = extractelement <8 x float> %565, i32 0
  %581 = select i1 %579, float %580, float 0.000000e+00
  %582 = insertelement <8 x float> %572, float %581, i64 1
  %583 = xor i1 %579, true
  %584 = and i1 %577, %583
  %585 = insertelement <8 x i1> %575, i1 %584, i64 1
  %586 = extractelement <8 x i1> %51, i32 0
  %587 = extractelement <8 x i1> %51, i64 2
  %588 = and i1 true, %586
  %589 = and i1 %587, %588
  %590 = extractelement <8 x float> %565, i32 0
  %591 = select i1 %589, float %590, float 0.000000e+00
  %592 = insertelement <8 x float> %582, float %591, i64 2
  %593 = xor i1 %589, true
  %594 = and i1 %587, %593
  %595 = insertelement <8 x i1> %585, i1 %594, i64 2
  %596 = extractelement <8 x i1> %51, i32 0
  %597 = extractelement <8 x i1> %51, i64 3
  %598 = and i1 true, %596
  %599 = and i1 %597, %598
  %600 = extractelement <8 x float> %565, i32 0
  %601 = select i1 %599, float %600, float 0.000000e+00
  %602 = insertelement <8 x float> %592, float %601, i64 3
  %603 = xor i1 %599, true
  %604 = and i1 %597, %603
  %605 = insertelement <8 x i1> %595, i1 %604, i64 3
  %606 = extractelement <8 x i1> %51, i32 0
  %607 = extractelement <8 x i1> %51, i64 4
  %608 = and i1 true, %606
  %609 = and i1 %607, %608
  %610 = extractelement <8 x float> %565, i32 0
  %611 = select i1 %609, float %610, float 0.000000e+00
  %612 = insertelement <8 x float> %602, float %611, i64 4
  %613 = xor i1 %609, true
  %614 = and i1 %607, %613
  %615 = insertelement <8 x i1> %605, i1 %614, i64 4
  %616 = extractelement <8 x i1> %51, i32 0
  %617 = extractelement <8 x i1> %51, i64 5
  %618 = and i1 true, %616
  %619 = and i1 %617, %618
  %620 = extractelement <8 x float> %565, i32 0
  %621 = select i1 %619, float %620, float 0.000000e+00
  %622 = insertelement <8 x float> %612, float %621, i64 5
  %623 = xor i1 %619, true
  %624 = and i1 %617, %623
  %625 = insertelement <8 x i1> %615, i1 %624, i64 5
  %626 = extractelement <8 x i1> %51, i32 0
  %627 = extractelement <8 x i1> %51, i64 6
  %628 = and i1 true, %626
  %629 = and i1 %627, %628
  %630 = extractelement <8 x float> %565, i32 0
  %631 = select i1 %629, float %630, float 0.000000e+00
  %632 = insertelement <8 x float> %622, float %631, i64 6
  %633 = xor i1 %629, true
  %634 = and i1 %627, %633
  %635 = insertelement <8 x i1> %625, i1 %634, i64 6
  %636 = extractelement <8 x i1> %51, i32 0
  %637 = extractelement <8 x i1> %51, i64 7
  %638 = and i1 true, %636
  %639 = and i1 %637, %638
  %640 = extractelement <8 x float> %565, i32 0
  %641 = select i1 %639, float %640, float 0.000000e+00
  %642 = insertelement <8 x float> %632, float %641, i64 7
  %643 = xor i1 %639, true
  %644 = and i1 %637, %643
  %645 = insertelement <8 x i1> %635, i1 %644, i64 7
  %646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %647 = bitcast <8 x i1> %51 to i8
  %648 = call i8 @llvm.cttz.i8(i8 %647, i1 false)
  %649 = zext i8 %648 to i32
  %650 = select i1 %646, i32 %649, i32 0
  %651 = extractelement <8 x float> %642, i32 %650
  %.spill.load83 = load float, ptr %.spill5, align 4
  %652 = fadd float %.spill.load83, %651
  %653 = fdiv float %652, 7.680000e+02
  store float %653, ptr %.spill12, align 4
  %654 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %655 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %656 = extractvalue { <8 x ptr>, <8 x i64> } %654, 0
  %657 = select <8 x i1> %51, <8 x ptr> %655, <8 x ptr> %656
  %658 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %659 = extractvalue { <8 x ptr>, <8 x i64> } %654, 1
  %660 = select <8 x i1> %51, <8 x i64> %658, <8 x i64> %659
  %661 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %657, 0
  %662 = insertvalue { <8 x ptr>, <8 x i64> } %661, <8 x i64> %660, 1
  store { <8 x ptr>, <8 x i64> } %662, ptr %tile_snapshot.spill13, align 64
  store i64 0, ptr %.slot14, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state84 = load i64, ptr %.slot14, align 4
  %663 = icmp slt i64 %.state84, 96
  br i1 %663, label %direct.true85, label %direct.false86

direct.schedule.8:                                ; preds = %direct.true85
  %.state87 = load i64, ptr %.slot14, align 4
  %664 = mul i64 %.state87, 8
  %.splatinsert88 = insertelement <8 x i64> poison, i64 %664, i64 0
  %.splat89 = shufflevector <8 x i64> %.splatinsert88, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load90 = load <8 x i64>, ptr %.spill, align 64
  %665 = add <8 x i64> %.splat89, %.spill.load90
  %.spill.load91 = load i64, ptr %.spill6, align 4
  %666 = add i64 %.spill.load91, 0
  %667 = add <8 x i64> zeroinitializer, %665
  %668 = mul i64 %666, 768
  %.splatinsert92 = insertelement <8 x i64> poison, i64 %668, i64 0
  %.splat93 = shufflevector <8 x i64> %.splatinsert92, <8 x i64> poison, <8 x i32> zeroinitializer
  %669 = add <8 x i64> %.splat93, %667
  %670 = extractvalue { ptr, i64 } %15, 0
  %671 = extractelement <8 x i64> %669, i32 0
  %672 = sub i64 %671, 0
  %673 = mul i64 %672, 4
  %buffer.contiguous.address94 = getelementptr i8, ptr %670, i64 %673
  %buffer.contiguous.load95 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address94, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %674 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 0
  %675 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 1
  %.state97 = load i64, ptr %.slot14, align 4
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %.state97, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %676 = mul <8 x i64> %.splat99, splat (i64 32)
  %677 = add <8 x i64> %675, %676
  %678 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %674, 0
  %679 = insertvalue { <8 x ptr>, <8 x i64> } %678, <8 x i64> %677, 1
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %679, 1
  %682 = extractelement <8 x ptr> %680, i32 0
  %683 = extractelement <8 x i64> %681, i32 0
  %684 = sub i64 %683, 0
  %685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %686 = select i1 %685, i64 %684, i64 0
  %private.contiguous.address100 = getelementptr i8, ptr %682, i64 %686
  %private.contiguous.preserve101 = load <8 x float>, ptr %private.contiguous.address100, align 4
  %687 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load95, <8 x float> %private.contiguous.preserve101
  store <8 x float> %687, ptr %private.contiguous.address100, align 4
  %.state102 = load i64, ptr %.slot14, align 4
  %688 = add i64 %.state102, 1
  store i64 %688, ptr %.slot14, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false86
  %.spill.load103 = load float, ptr %.spill12, align 4
  %689 = fadd float %.spill.load103, 0x3EE4F8B580000000
  %690 = call float @llvm.sqrt.f32(float %689)
  store float %690, ptr %.spill15, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.9
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state104 = load i64, ptr %.slot16, align 4
  %691 = icmp slt i64 %.state104, 96
  br i1 %691, label %direct.true105, label %direct.false106

direct.schedule.12:                               ; preds = %direct.true105
  %.state107 = load i64, ptr %.slot16, align 4
  %692 = mul i64 %.state107, 8
  %.splatinsert108 = insertelement <8 x i64> poison, i64 %692, i64 0
  %.splat109 = shufflevector <8 x i64> %.splatinsert108, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load110 = load <8 x i64>, ptr %.spill, align 64
  %693 = add <8 x i64> %.splat109, %.spill.load110
  %tile_snapshot.spill.load111 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 0
  %695 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 1
  %.state112 = load i64, ptr %.slot16, align 4
  %.splatinsert113 = insertelement <8 x i64> poison, i64 %.state112, i64 0
  %.splat114 = shufflevector <8 x i64> %.splatinsert113, <8 x i64> poison, <8 x i32> zeroinitializer
  %696 = mul <8 x i64> %.splat114, splat (i64 32)
  %697 = add <8 x i64> %695, %696
  %698 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %694, 0
  %699 = insertvalue { <8 x ptr>, <8 x i64> } %698, <8 x i64> %697, 1
  %700 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %701 = extractvalue { <8 x ptr>, <8 x i64> } %699, 1
  %702 = extractelement <8 x ptr> %700, i32 0
  %703 = extractelement <8 x i64> %701, i32 0
  %704 = sub i64 %703, 0
  %705 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %706 = select i1 %705, i64 %704, i64 0
  %private.contiguous.address115 = getelementptr i8, ptr %702, i64 %706
  %private.contiguous.load116 = load <8 x float>, ptr %private.contiguous.address115, align 4
  %707 = select <8 x i1> %51, <8 x float> %private.contiguous.load116, <8 x float> zeroinitializer
  %.spill.load117 = load float, ptr %.spill15, align 4
  %.splatinsert118 = insertelement <8 x float> poison, float %.spill.load117, i64 0
  %.splat119 = shufflevector <8 x float> %.splatinsert118, <8 x float> poison, <8 x i32> zeroinitializer
  %708 = fdiv <8 x float> %707, %.splat119
  %tile_snapshot.spill.load120 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %709 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 0
  %710 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 1
  %.state121 = load i64, ptr %.slot16, align 4
  %.splatinsert122 = insertelement <8 x i64> poison, i64 %.state121, i64 0
  %.splat123 = shufflevector <8 x i64> %.splatinsert122, <8 x i64> poison, <8 x i32> zeroinitializer
  %711 = mul <8 x i64> %.splat123, splat (i64 32)
  %712 = add <8 x i64> %710, %711
  %713 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %709, 0
  %714 = insertvalue { <8 x ptr>, <8 x i64> } %713, <8 x i64> %712, 1
  %715 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %716 = extractvalue { <8 x ptr>, <8 x i64> } %714, 1
  %717 = extractelement <8 x ptr> %715, i32 0
  %718 = extractelement <8 x i64> %716, i32 0
  %719 = sub i64 %718, 0
  %720 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %721 = select i1 %720, i64 %719, i64 0
  %private.contiguous.address124 = getelementptr i8, ptr %717, i64 %721
  %private.contiguous.load125 = load <8 x float>, ptr %private.contiguous.address124, align 4
  %722 = select <8 x i1> %51, <8 x float> %private.contiguous.load125, <8 x float> zeroinitializer
  %723 = fmul <8 x float> %708, %722
  %.spill.load126 = load <8 x i64>, ptr %.spill4, align 64
  %724 = add <8 x i64> %.spill.load126, zeroinitializer
  %725 = add <8 x i64> zeroinitializer, %724
  %726 = add <8 x i64> zeroinitializer, %693
  %727 = mul <8 x i64> %725, splat (i64 768)
  %728 = add <8 x i64> %727, %726
  %729 = extractvalue { ptr, i64 } %27, 0
  %730 = extractelement <8 x i64> %728, i32 0
  %731 = sub i64 %730, 0
  %732 = mul i64 %731, 4
  %buffer.contiguous.address127 = getelementptr i8, ptr %729, i64 %732
  call void @llvm.masked.store.v8f32.p0(<8 x float> %723, ptr %buffer.contiguous.address127, i32 1, <8 x i1> %51)
  %.state128 = load i64, ptr %.slot16, align 4
  %733 = add i64 %.state128, 1
  store i64 %733, ptr %.slot16, align 4
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false106
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true47:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false48:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true85:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false86:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true105:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false106:                                  ; preds = %direct.schedule.11
  br label %direct.schedule.13
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [3072 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [3072 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.slot7 = alloca i64, align 8
  store i64 0, ptr %.slot7, align 4
  %.slot8 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot8, align 32
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.spill12 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill12, align 4
  %tile_snapshot.spill13 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill13, align 64
  %.slot14 = alloca i64, align 8
  store i64 0, ptr %.slot14, align 4
  %.spill15 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill15, align 4
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat18, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat20, %41
  %44 = mul i32 %32, 1
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat22, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat24, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert25 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat26
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 96
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state27 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state27, 8
  %.splatinsert28 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat29 = shufflevector <8 x i64> %.splatinsert28, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat29, %.spill.load
  %.spill.load30 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load30, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 768)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state31 = load i64, ptr %.slot, align 4
  %.splatinsert32 = insertelement <8 x i64> poison, i64 %.state31, i64 0
  %.splat33 = shufflevector <8 x i64> %.splatinsert32, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat33, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state34 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state34, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  %tile_snapshot.spill.load35 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 0
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 1
  %104 = add <8 x i64> %103, zeroinitializer
  %105 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %102, 0
  %106 = insertvalue { <8 x ptr>, <8 x i64> } %105, <8 x i64> %104, 1
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %106, 1
  %109 = extractelement <8 x ptr> %107, i32 0
  %110 = extractelement <8 x i64> %108, i32 0
  %111 = sub i64 %110, 0
  %112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %113 = select i1 %112, i64 %111, i64 0
  %private.contiguous.address36 = getelementptr i8, ptr %109, i64 %113
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address36, align 4
  %114 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %115 = fmul <8 x float> %114, %114
  %tile_snapshot.spill.load37 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 0
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 1
  %118 = add <8 x i64> %117, splat (i64 32)
  %119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %116, 0
  %120 = insertvalue { <8 x ptr>, <8 x i64> } %119, <8 x i64> %118, 1
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %120, 1
  %123 = extractelement <8 x ptr> %121, i32 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %127 = select i1 %126, i64 %125, i64 0
  %private.contiguous.address38 = getelementptr i8, ptr %123, i64 %127
  %private.contiguous.load39 = load <8 x float>, ptr %private.contiguous.address38, align 4
  %128 = select <8 x i1> %51, <8 x float> %private.contiguous.load39, <8 x float> zeroinitializer
  %129 = fmul <8 x float> %128, %128
  %tile_snapshot.spill.load40 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load40, 0
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load40, 1
  %132 = add <8 x i64> %131, splat (i64 64)
  %133 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %130, 0
  %134 = insertvalue { <8 x ptr>, <8 x i64> } %133, <8 x i64> %132, 1
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %134, 1
  %137 = extractelement <8 x ptr> %135, i32 0
  %138 = extractelement <8 x i64> %136, i32 0
  %139 = sub i64 %138, 0
  %140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %141 = select i1 %140, i64 %139, i64 0
  %private.contiguous.address41 = getelementptr i8, ptr %137, i64 %141
  %private.contiguous.load42 = load <8 x float>, ptr %private.contiguous.address41, align 4
  %142 = select <8 x i1> %51, <8 x float> %private.contiguous.load42, <8 x float> zeroinitializer
  %143 = fmul <8 x float> %142, %142
  %tile_snapshot.spill.load43 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 0
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 1
  %146 = add <8 x i64> %145, splat (i64 96)
  %147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %144, 0
  %148 = insertvalue { <8 x ptr>, <8 x i64> } %147, <8 x i64> %146, 1
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %148, 1
  %151 = extractelement <8 x ptr> %149, i32 0
  %152 = extractelement <8 x i64> %150, i32 0
  %153 = sub i64 %152, 0
  %154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %155 = select i1 %154, i64 %153, i64 0
  %private.contiguous.address44 = getelementptr i8, ptr %151, i64 %155
  %private.contiguous.load45 = load <8 x float>, ptr %private.contiguous.address44, align 4
  %156 = select <8 x i1> %51, <8 x float> %private.contiguous.load45, <8 x float> zeroinitializer
  %157 = fmul <8 x float> %156, %156
  store i64 4, ptr %.slot7, align 4
  %158 = load <8 x float>, ptr %.slot8, align 32
  %159 = select <8 x i1> %51, <8 x float> %115, <8 x float> %158
  store <8 x float> %159, ptr %.slot8, align 32
  %160 = load <8 x float>, ptr %.slot9, align 32
  %161 = select <8 x i1> %51, <8 x float> %129, <8 x float> %160
  store <8 x float> %161, ptr %.slot9, align 32
  %162 = load <8 x float>, ptr %.slot10, align 32
  %163 = select <8 x i1> %51, <8 x float> %143, <8 x float> %162
  store <8 x float> %163, ptr %.slot10, align 32
  %164 = load <8 x float>, ptr %.slot11, align 32
  %165 = select <8 x i1> %51, <8 x float> %157, <8 x float> %164
  store <8 x float> %165, ptr %.slot11, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state46 = load i64, ptr %.slot7, align 4
  %166 = icmp slt i64 %.state46, 96
  br i1 %166, label %direct.true47, label %direct.false48

direct.schedule.5:                                ; preds = %direct.true47
  %.state49 = load i64, ptr %.slot7, align 4
  %167 = add i64 %.state49, 0
  %tile_snapshot.spill.load50 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load50, 0
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load50, 1
  %.splatinsert51 = insertelement <8 x i64> poison, i64 %167, i64 0
  %.splat52 = shufflevector <8 x i64> %.splatinsert51, <8 x i64> poison, <8 x i32> zeroinitializer
  %170 = mul <8 x i64> %.splat52, splat (i64 32)
  %171 = add <8 x i64> %169, %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %173 = insertvalue { <8 x ptr>, <8 x i64> } %172, <8 x i64> %171, 1
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %173, 1
  %176 = extractelement <8 x ptr> %174, i32 0
  %177 = extractelement <8 x i64> %175, i32 0
  %178 = sub i64 %177, 0
  %179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %180 = select i1 %179, i64 %178, i64 0
  %private.contiguous.address53 = getelementptr i8, ptr %176, i64 %180
  %private.contiguous.load54 = load <8 x float>, ptr %private.contiguous.address53, align 4
  %181 = select <8 x i1> %51, <8 x float> %private.contiguous.load54, <8 x float> zeroinitializer
  %182 = fmul <8 x float> %181, %181
  %.state55 = load <8 x float>, ptr %.slot8, align 32
  %183 = fadd <8 x float> %.state55, %182
  %.state56 = load i64, ptr %.slot7, align 4
  %184 = add i64 %.state56, 1
  %tile_snapshot.spill.load57 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 0
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 1
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %184, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %187 = mul <8 x i64> %.splat59, splat (i64 32)
  %188 = add <8 x i64> %186, %187
  %189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %185, 0
  %190 = insertvalue { <8 x ptr>, <8 x i64> } %189, <8 x i64> %188, 1
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %190, 1
  %193 = extractelement <8 x ptr> %191, i32 0
  %194 = extractelement <8 x i64> %192, i32 0
  %195 = sub i64 %194, 0
  %196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %197 = select i1 %196, i64 %195, i64 0
  %private.contiguous.address60 = getelementptr i8, ptr %193, i64 %197
  %private.contiguous.load61 = load <8 x float>, ptr %private.contiguous.address60, align 4
  %198 = select <8 x i1> %51, <8 x float> %private.contiguous.load61, <8 x float> zeroinitializer
  %199 = fmul <8 x float> %198, %198
  %.state62 = load <8 x float>, ptr %.slot9, align 32
  %200 = fadd <8 x float> %.state62, %199
  %.state63 = load i64, ptr %.slot7, align 4
  %201 = add i64 %.state63, 2
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %.splatinsert65 = insertelement <8 x i64> poison, i64 %201, i64 0
  %.splat66 = shufflevector <8 x i64> %.splatinsert65, <8 x i64> poison, <8 x i32> zeroinitializer
  %204 = mul <8 x i64> %.splat66, splat (i64 32)
  %205 = add <8 x i64> %203, %204
  %206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %202, 0
  %207 = insertvalue { <8 x ptr>, <8 x i64> } %206, <8 x i64> %205, 1
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %207, 1
  %210 = extractelement <8 x ptr> %208, i32 0
  %211 = extractelement <8 x i64> %209, i32 0
  %212 = sub i64 %211, 0
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %214 = select i1 %213, i64 %212, i64 0
  %private.contiguous.address67 = getelementptr i8, ptr %210, i64 %214
  %private.contiguous.load68 = load <8 x float>, ptr %private.contiguous.address67, align 4
  %215 = select <8 x i1> %51, <8 x float> %private.contiguous.load68, <8 x float> zeroinitializer
  %216 = fmul <8 x float> %215, %215
  %.state69 = load <8 x float>, ptr %.slot10, align 32
  %217 = fadd <8 x float> %.state69, %216
  %.state70 = load i64, ptr %.slot7, align 4
  %218 = add i64 %.state70, 3
  %tile_snapshot.spill.load71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 0
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 1
  %.splatinsert72 = insertelement <8 x i64> poison, i64 %218, i64 0
  %.splat73 = shufflevector <8 x i64> %.splatinsert72, <8 x i64> poison, <8 x i32> zeroinitializer
  %221 = mul <8 x i64> %.splat73, splat (i64 32)
  %222 = add <8 x i64> %220, %221
  %223 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %219, 0
  %224 = insertvalue { <8 x ptr>, <8 x i64> } %223, <8 x i64> %222, 1
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %224, 1
  %227 = extractelement <8 x ptr> %225, i32 0
  %228 = extractelement <8 x i64> %226, i32 0
  %229 = sub i64 %228, 0
  %230 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %231 = select i1 %230, i64 %229, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %227, i64 %231
  %private.contiguous.load75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %232 = select <8 x i1> %51, <8 x float> %private.contiguous.load75, <8 x float> zeroinitializer
  %233 = fmul <8 x float> %232, %232
  %.state76 = load <8 x float>, ptr %.slot11, align 32
  %234 = fadd <8 x float> %.state76, %233
  %.state77 = load i64, ptr %.slot7, align 4
  %235 = add i64 %.state77, 4
  store i64 %235, ptr %.slot7, align 4
  %236 = load <8 x float>, ptr %.slot8, align 32
  %237 = select <8 x i1> %51, <8 x float> %183, <8 x float> %236
  store <8 x float> %237, ptr %.slot8, align 32
  %238 = load <8 x float>, ptr %.slot9, align 32
  %239 = select <8 x i1> %51, <8 x float> %200, <8 x float> %238
  store <8 x float> %239, ptr %.slot9, align 32
  %240 = load <8 x float>, ptr %.slot10, align 32
  %241 = select <8 x i1> %51, <8 x float> %217, <8 x float> %240
  store <8 x float> %241, ptr %.slot10, align 32
  %242 = load <8 x float>, ptr %.slot11, align 32
  %243 = select <8 x i1> %51, <8 x float> %234, <8 x float> %242
  store <8 x float> %243, ptr %.slot11, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false48
  %.state78 = load <8 x float>, ptr %.slot8, align 32
  %.state79 = load <8 x float>, ptr %.slot9, align 32
  %244 = fadd <8 x float> %.state78, %.state79
  %.state80 = load <8 x float>, ptr %.slot10, align 32
  %245 = fadd <8 x float> %244, %.state80
  %.state81 = load <8 x float>, ptr %.slot11, align 32
  %246 = fadd <8 x float> %245, %.state81
  %.spill.load82 = load <8 x i64>, ptr %.spill, align 64
  %247 = trunc <8 x i64> %.spill.load82 to <8 x i32>
  %248 = xor <8 x i32> %247, splat (i32 1)
  %249 = extractelement <8 x i32> %248, i64 0
  %250 = icmp ult i32 %249, 8
  %251 = select i1 %250, i32 %249, i32 0
  %252 = extractelement <8 x i1> %51, i32 %251
  %253 = extractelement <8 x i1> %51, i64 0
  %254 = and i1 %250, %252
  %255 = and i1 %253, %254
  %256 = extractelement <8 x float> %246, i32 %251
  %257 = select i1 %255, float %256, float 0.000000e+00
  %258 = insertelement <8 x float> poison, float %257, i64 0
  %259 = xor i1 %255, true
  %260 = and i1 %253, %259
  %261 = insertelement <8 x i1> poison, i1 %260, i64 0
  %262 = extractelement <8 x i32> %248, i64 1
  %263 = icmp ult i32 %262, 8
  %264 = select i1 %263, i32 %262, i32 0
  %265 = extractelement <8 x i1> %51, i32 %264
  %266 = extractelement <8 x i1> %51, i64 1
  %267 = and i1 %263, %265
  %268 = and i1 %266, %267
  %269 = extractelement <8 x float> %246, i32 %264
  %270 = select i1 %268, float %269, float 0.000000e+00
  %271 = insertelement <8 x float> %258, float %270, i64 1
  %272 = xor i1 %268, true
  %273 = and i1 %266, %272
  %274 = insertelement <8 x i1> %261, i1 %273, i64 1
  %275 = extractelement <8 x i32> %248, i64 2
  %276 = icmp ult i32 %275, 8
  %277 = select i1 %276, i32 %275, i32 0
  %278 = extractelement <8 x i1> %51, i32 %277
  %279 = extractelement <8 x i1> %51, i64 2
  %280 = and i1 %276, %278
  %281 = and i1 %279, %280
  %282 = extractelement <8 x float> %246, i32 %277
  %283 = select i1 %281, float %282, float 0.000000e+00
  %284 = insertelement <8 x float> %271, float %283, i64 2
  %285 = xor i1 %281, true
  %286 = and i1 %279, %285
  %287 = insertelement <8 x i1> %274, i1 %286, i64 2
  %288 = extractelement <8 x i32> %248, i64 3
  %289 = icmp ult i32 %288, 8
  %290 = select i1 %289, i32 %288, i32 0
  %291 = extractelement <8 x i1> %51, i32 %290
  %292 = extractelement <8 x i1> %51, i64 3
  %293 = and i1 %289, %291
  %294 = and i1 %292, %293
  %295 = extractelement <8 x float> %246, i32 %290
  %296 = select i1 %294, float %295, float 0.000000e+00
  %297 = insertelement <8 x float> %284, float %296, i64 3
  %298 = xor i1 %294, true
  %299 = and i1 %292, %298
  %300 = insertelement <8 x i1> %287, i1 %299, i64 3
  %301 = extractelement <8 x i32> %248, i64 4
  %302 = icmp ult i32 %301, 8
  %303 = select i1 %302, i32 %301, i32 0
  %304 = extractelement <8 x i1> %51, i32 %303
  %305 = extractelement <8 x i1> %51, i64 4
  %306 = and i1 %302, %304
  %307 = and i1 %305, %306
  %308 = extractelement <8 x float> %246, i32 %303
  %309 = select i1 %307, float %308, float 0.000000e+00
  %310 = insertelement <8 x float> %297, float %309, i64 4
  %311 = xor i1 %307, true
  %312 = and i1 %305, %311
  %313 = insertelement <8 x i1> %300, i1 %312, i64 4
  %314 = extractelement <8 x i32> %248, i64 5
  %315 = icmp ult i32 %314, 8
  %316 = select i1 %315, i32 %314, i32 0
  %317 = extractelement <8 x i1> %51, i32 %316
  %318 = extractelement <8 x i1> %51, i64 5
  %319 = and i1 %315, %317
  %320 = and i1 %318, %319
  %321 = extractelement <8 x float> %246, i32 %316
  %322 = select i1 %320, float %321, float 0.000000e+00
  %323 = insertelement <8 x float> %310, float %322, i64 5
  %324 = xor i1 %320, true
  %325 = and i1 %318, %324
  %326 = insertelement <8 x i1> %313, i1 %325, i64 5
  %327 = extractelement <8 x i32> %248, i64 6
  %328 = icmp ult i32 %327, 8
  %329 = select i1 %328, i32 %327, i32 0
  %330 = extractelement <8 x i1> %51, i32 %329
  %331 = extractelement <8 x i1> %51, i64 6
  %332 = and i1 %328, %330
  %333 = and i1 %331, %332
  %334 = extractelement <8 x float> %246, i32 %329
  %335 = select i1 %333, float %334, float 0.000000e+00
  %336 = insertelement <8 x float> %323, float %335, i64 6
  %337 = xor i1 %333, true
  %338 = and i1 %331, %337
  %339 = insertelement <8 x i1> %326, i1 %338, i64 6
  %340 = extractelement <8 x i32> %248, i64 7
  %341 = icmp ult i32 %340, 8
  %342 = select i1 %341, i32 %340, i32 0
  %343 = extractelement <8 x i1> %51, i32 %342
  %344 = extractelement <8 x i1> %51, i64 7
  %345 = and i1 %341, %343
  %346 = and i1 %344, %345
  %347 = extractelement <8 x float> %246, i32 %342
  %348 = select i1 %346, float %347, float 0.000000e+00
  %349 = insertelement <8 x float> %336, float %348, i64 7
  %350 = xor i1 %346, true
  %351 = and i1 %344, %350
  %352 = insertelement <8 x i1> %339, i1 %351, i64 7
  %353 = fadd <8 x float> %246, %349
  %354 = xor <8 x i32> %247, splat (i32 2)
  %355 = extractelement <8 x i32> %354, i64 0
  %356 = icmp ult i32 %355, 8
  %357 = select i1 %356, i32 %355, i32 0
  %358 = extractelement <8 x i1> %51, i32 %357
  %359 = extractelement <8 x i1> %51, i64 0
  %360 = and i1 %356, %358
  %361 = and i1 %359, %360
  %362 = extractelement <8 x float> %353, i32 %357
  %363 = select i1 %361, float %362, float 0.000000e+00
  %364 = insertelement <8 x float> poison, float %363, i64 0
  %365 = xor i1 %361, true
  %366 = and i1 %359, %365
  %367 = insertelement <8 x i1> poison, i1 %366, i64 0
  %368 = extractelement <8 x i32> %354, i64 1
  %369 = icmp ult i32 %368, 8
  %370 = select i1 %369, i32 %368, i32 0
  %371 = extractelement <8 x i1> %51, i32 %370
  %372 = extractelement <8 x i1> %51, i64 1
  %373 = and i1 %369, %371
  %374 = and i1 %372, %373
  %375 = extractelement <8 x float> %353, i32 %370
  %376 = select i1 %374, float %375, float 0.000000e+00
  %377 = insertelement <8 x float> %364, float %376, i64 1
  %378 = xor i1 %374, true
  %379 = and i1 %372, %378
  %380 = insertelement <8 x i1> %367, i1 %379, i64 1
  %381 = extractelement <8 x i32> %354, i64 2
  %382 = icmp ult i32 %381, 8
  %383 = select i1 %382, i32 %381, i32 0
  %384 = extractelement <8 x i1> %51, i32 %383
  %385 = extractelement <8 x i1> %51, i64 2
  %386 = and i1 %382, %384
  %387 = and i1 %385, %386
  %388 = extractelement <8 x float> %353, i32 %383
  %389 = select i1 %387, float %388, float 0.000000e+00
  %390 = insertelement <8 x float> %377, float %389, i64 2
  %391 = xor i1 %387, true
  %392 = and i1 %385, %391
  %393 = insertelement <8 x i1> %380, i1 %392, i64 2
  %394 = extractelement <8 x i32> %354, i64 3
  %395 = icmp ult i32 %394, 8
  %396 = select i1 %395, i32 %394, i32 0
  %397 = extractelement <8 x i1> %51, i32 %396
  %398 = extractelement <8 x i1> %51, i64 3
  %399 = and i1 %395, %397
  %400 = and i1 %398, %399
  %401 = extractelement <8 x float> %353, i32 %396
  %402 = select i1 %400, float %401, float 0.000000e+00
  %403 = insertelement <8 x float> %390, float %402, i64 3
  %404 = xor i1 %400, true
  %405 = and i1 %398, %404
  %406 = insertelement <8 x i1> %393, i1 %405, i64 3
  %407 = extractelement <8 x i32> %354, i64 4
  %408 = icmp ult i32 %407, 8
  %409 = select i1 %408, i32 %407, i32 0
  %410 = extractelement <8 x i1> %51, i32 %409
  %411 = extractelement <8 x i1> %51, i64 4
  %412 = and i1 %408, %410
  %413 = and i1 %411, %412
  %414 = extractelement <8 x float> %353, i32 %409
  %415 = select i1 %413, float %414, float 0.000000e+00
  %416 = insertelement <8 x float> %403, float %415, i64 4
  %417 = xor i1 %413, true
  %418 = and i1 %411, %417
  %419 = insertelement <8 x i1> %406, i1 %418, i64 4
  %420 = extractelement <8 x i32> %354, i64 5
  %421 = icmp ult i32 %420, 8
  %422 = select i1 %421, i32 %420, i32 0
  %423 = extractelement <8 x i1> %51, i32 %422
  %424 = extractelement <8 x i1> %51, i64 5
  %425 = and i1 %421, %423
  %426 = and i1 %424, %425
  %427 = extractelement <8 x float> %353, i32 %422
  %428 = select i1 %426, float %427, float 0.000000e+00
  %429 = insertelement <8 x float> %416, float %428, i64 5
  %430 = xor i1 %426, true
  %431 = and i1 %424, %430
  %432 = insertelement <8 x i1> %419, i1 %431, i64 5
  %433 = extractelement <8 x i32> %354, i64 6
  %434 = icmp ult i32 %433, 8
  %435 = select i1 %434, i32 %433, i32 0
  %436 = extractelement <8 x i1> %51, i32 %435
  %437 = extractelement <8 x i1> %51, i64 6
  %438 = and i1 %434, %436
  %439 = and i1 %437, %438
  %440 = extractelement <8 x float> %353, i32 %435
  %441 = select i1 %439, float %440, float 0.000000e+00
  %442 = insertelement <8 x float> %429, float %441, i64 6
  %443 = xor i1 %439, true
  %444 = and i1 %437, %443
  %445 = insertelement <8 x i1> %432, i1 %444, i64 6
  %446 = extractelement <8 x i32> %354, i64 7
  %447 = icmp ult i32 %446, 8
  %448 = select i1 %447, i32 %446, i32 0
  %449 = extractelement <8 x i1> %51, i32 %448
  %450 = extractelement <8 x i1> %51, i64 7
  %451 = and i1 %447, %449
  %452 = and i1 %450, %451
  %453 = extractelement <8 x float> %353, i32 %448
  %454 = select i1 %452, float %453, float 0.000000e+00
  %455 = insertelement <8 x float> %442, float %454, i64 7
  %456 = xor i1 %452, true
  %457 = and i1 %450, %456
  %458 = insertelement <8 x i1> %445, i1 %457, i64 7
  %459 = fadd <8 x float> %353, %455
  %460 = xor <8 x i32> %247, splat (i32 4)
  %461 = extractelement <8 x i32> %460, i64 0
  %462 = icmp ult i32 %461, 8
  %463 = select i1 %462, i32 %461, i32 0
  %464 = extractelement <8 x i1> %51, i32 %463
  %465 = extractelement <8 x i1> %51, i64 0
  %466 = and i1 %462, %464
  %467 = and i1 %465, %466
  %468 = extractelement <8 x float> %459, i32 %463
  %469 = select i1 %467, float %468, float 0.000000e+00
  %470 = insertelement <8 x float> poison, float %469, i64 0
  %471 = xor i1 %467, true
  %472 = and i1 %465, %471
  %473 = insertelement <8 x i1> poison, i1 %472, i64 0
  %474 = extractelement <8 x i32> %460, i64 1
  %475 = icmp ult i32 %474, 8
  %476 = select i1 %475, i32 %474, i32 0
  %477 = extractelement <8 x i1> %51, i32 %476
  %478 = extractelement <8 x i1> %51, i64 1
  %479 = and i1 %475, %477
  %480 = and i1 %478, %479
  %481 = extractelement <8 x float> %459, i32 %476
  %482 = select i1 %480, float %481, float 0.000000e+00
  %483 = insertelement <8 x float> %470, float %482, i64 1
  %484 = xor i1 %480, true
  %485 = and i1 %478, %484
  %486 = insertelement <8 x i1> %473, i1 %485, i64 1
  %487 = extractelement <8 x i32> %460, i64 2
  %488 = icmp ult i32 %487, 8
  %489 = select i1 %488, i32 %487, i32 0
  %490 = extractelement <8 x i1> %51, i32 %489
  %491 = extractelement <8 x i1> %51, i64 2
  %492 = and i1 %488, %490
  %493 = and i1 %491, %492
  %494 = extractelement <8 x float> %459, i32 %489
  %495 = select i1 %493, float %494, float 0.000000e+00
  %496 = insertelement <8 x float> %483, float %495, i64 2
  %497 = xor i1 %493, true
  %498 = and i1 %491, %497
  %499 = insertelement <8 x i1> %486, i1 %498, i64 2
  %500 = extractelement <8 x i32> %460, i64 3
  %501 = icmp ult i32 %500, 8
  %502 = select i1 %501, i32 %500, i32 0
  %503 = extractelement <8 x i1> %51, i32 %502
  %504 = extractelement <8 x i1> %51, i64 3
  %505 = and i1 %501, %503
  %506 = and i1 %504, %505
  %507 = extractelement <8 x float> %459, i32 %502
  %508 = select i1 %506, float %507, float 0.000000e+00
  %509 = insertelement <8 x float> %496, float %508, i64 3
  %510 = xor i1 %506, true
  %511 = and i1 %504, %510
  %512 = insertelement <8 x i1> %499, i1 %511, i64 3
  %513 = extractelement <8 x i32> %460, i64 4
  %514 = icmp ult i32 %513, 8
  %515 = select i1 %514, i32 %513, i32 0
  %516 = extractelement <8 x i1> %51, i32 %515
  %517 = extractelement <8 x i1> %51, i64 4
  %518 = and i1 %514, %516
  %519 = and i1 %517, %518
  %520 = extractelement <8 x float> %459, i32 %515
  %521 = select i1 %519, float %520, float 0.000000e+00
  %522 = insertelement <8 x float> %509, float %521, i64 4
  %523 = xor i1 %519, true
  %524 = and i1 %517, %523
  %525 = insertelement <8 x i1> %512, i1 %524, i64 4
  %526 = extractelement <8 x i32> %460, i64 5
  %527 = icmp ult i32 %526, 8
  %528 = select i1 %527, i32 %526, i32 0
  %529 = extractelement <8 x i1> %51, i32 %528
  %530 = extractelement <8 x i1> %51, i64 5
  %531 = and i1 %527, %529
  %532 = and i1 %530, %531
  %533 = extractelement <8 x float> %459, i32 %528
  %534 = select i1 %532, float %533, float 0.000000e+00
  %535 = insertelement <8 x float> %522, float %534, i64 5
  %536 = xor i1 %532, true
  %537 = and i1 %530, %536
  %538 = insertelement <8 x i1> %525, i1 %537, i64 5
  %539 = extractelement <8 x i32> %460, i64 6
  %540 = icmp ult i32 %539, 8
  %541 = select i1 %540, i32 %539, i32 0
  %542 = extractelement <8 x i1> %51, i32 %541
  %543 = extractelement <8 x i1> %51, i64 6
  %544 = and i1 %540, %542
  %545 = and i1 %543, %544
  %546 = extractelement <8 x float> %459, i32 %541
  %547 = select i1 %545, float %546, float 0.000000e+00
  %548 = insertelement <8 x float> %535, float %547, i64 6
  %549 = xor i1 %545, true
  %550 = and i1 %543, %549
  %551 = insertelement <8 x i1> %538, i1 %550, i64 6
  %552 = extractelement <8 x i32> %460, i64 7
  %553 = icmp ult i32 %552, 8
  %554 = select i1 %553, i32 %552, i32 0
  %555 = extractelement <8 x i1> %51, i32 %554
  %556 = extractelement <8 x i1> %51, i64 7
  %557 = and i1 %553, %555
  %558 = and i1 %556, %557
  %559 = extractelement <8 x float> %459, i32 %554
  %560 = select i1 %558, float %559, float 0.000000e+00
  %561 = insertelement <8 x float> %548, float %560, i64 7
  %562 = xor i1 %558, true
  %563 = and i1 %556, %562
  %564 = insertelement <8 x i1> %551, i1 %563, i64 7
  %565 = fadd <8 x float> %459, %561
  %566 = extractelement <8 x i1> %51, i32 0
  %567 = extractelement <8 x i1> %51, i64 0
  %568 = and i1 true, %566
  %569 = and i1 %567, %568
  %570 = extractelement <8 x float> %565, i32 0
  %571 = select i1 %569, float %570, float 0.000000e+00
  %572 = insertelement <8 x float> poison, float %571, i64 0
  %573 = xor i1 %569, true
  %574 = and i1 %567, %573
  %575 = insertelement <8 x i1> poison, i1 %574, i64 0
  %576 = extractelement <8 x i1> %51, i32 0
  %577 = extractelement <8 x i1> %51, i64 1
  %578 = and i1 true, %576
  %579 = and i1 %577, %578
  %580 = extractelement <8 x float> %565, i32 0
  %581 = select i1 %579, float %580, float 0.000000e+00
  %582 = insertelement <8 x float> %572, float %581, i64 1
  %583 = xor i1 %579, true
  %584 = and i1 %577, %583
  %585 = insertelement <8 x i1> %575, i1 %584, i64 1
  %586 = extractelement <8 x i1> %51, i32 0
  %587 = extractelement <8 x i1> %51, i64 2
  %588 = and i1 true, %586
  %589 = and i1 %587, %588
  %590 = extractelement <8 x float> %565, i32 0
  %591 = select i1 %589, float %590, float 0.000000e+00
  %592 = insertelement <8 x float> %582, float %591, i64 2
  %593 = xor i1 %589, true
  %594 = and i1 %587, %593
  %595 = insertelement <8 x i1> %585, i1 %594, i64 2
  %596 = extractelement <8 x i1> %51, i32 0
  %597 = extractelement <8 x i1> %51, i64 3
  %598 = and i1 true, %596
  %599 = and i1 %597, %598
  %600 = extractelement <8 x float> %565, i32 0
  %601 = select i1 %599, float %600, float 0.000000e+00
  %602 = insertelement <8 x float> %592, float %601, i64 3
  %603 = xor i1 %599, true
  %604 = and i1 %597, %603
  %605 = insertelement <8 x i1> %595, i1 %604, i64 3
  %606 = extractelement <8 x i1> %51, i32 0
  %607 = extractelement <8 x i1> %51, i64 4
  %608 = and i1 true, %606
  %609 = and i1 %607, %608
  %610 = extractelement <8 x float> %565, i32 0
  %611 = select i1 %609, float %610, float 0.000000e+00
  %612 = insertelement <8 x float> %602, float %611, i64 4
  %613 = xor i1 %609, true
  %614 = and i1 %607, %613
  %615 = insertelement <8 x i1> %605, i1 %614, i64 4
  %616 = extractelement <8 x i1> %51, i32 0
  %617 = extractelement <8 x i1> %51, i64 5
  %618 = and i1 true, %616
  %619 = and i1 %617, %618
  %620 = extractelement <8 x float> %565, i32 0
  %621 = select i1 %619, float %620, float 0.000000e+00
  %622 = insertelement <8 x float> %612, float %621, i64 5
  %623 = xor i1 %619, true
  %624 = and i1 %617, %623
  %625 = insertelement <8 x i1> %615, i1 %624, i64 5
  %626 = extractelement <8 x i1> %51, i32 0
  %627 = extractelement <8 x i1> %51, i64 6
  %628 = and i1 true, %626
  %629 = and i1 %627, %628
  %630 = extractelement <8 x float> %565, i32 0
  %631 = select i1 %629, float %630, float 0.000000e+00
  %632 = insertelement <8 x float> %622, float %631, i64 6
  %633 = xor i1 %629, true
  %634 = and i1 %627, %633
  %635 = insertelement <8 x i1> %625, i1 %634, i64 6
  %636 = extractelement <8 x i1> %51, i32 0
  %637 = extractelement <8 x i1> %51, i64 7
  %638 = and i1 true, %636
  %639 = and i1 %637, %638
  %640 = extractelement <8 x float> %565, i32 0
  %641 = select i1 %639, float %640, float 0.000000e+00
  %642 = insertelement <8 x float> %632, float %641, i64 7
  %643 = xor i1 %639, true
  %644 = and i1 %637, %643
  %645 = insertelement <8 x i1> %635, i1 %644, i64 7
  %646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %647 = bitcast <8 x i1> %51 to i8
  %648 = call i8 @llvm.cttz.i8(i8 %647, i1 false)
  %649 = zext i8 %648 to i32
  %650 = select i1 %646, i32 %649, i32 0
  %651 = extractelement <8 x float> %642, i32 %650
  %.spill.load83 = load float, ptr %.spill5, align 4
  %652 = fadd float %.spill.load83, %651
  %653 = fdiv float %652, 7.680000e+02
  store float %653, ptr %.spill12, align 4
  %654 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %655 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %656 = extractvalue { <8 x ptr>, <8 x i64> } %654, 0
  %657 = select <8 x i1> %51, <8 x ptr> %655, <8 x ptr> %656
  %658 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %659 = extractvalue { <8 x ptr>, <8 x i64> } %654, 1
  %660 = select <8 x i1> %51, <8 x i64> %658, <8 x i64> %659
  %661 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %657, 0
  %662 = insertvalue { <8 x ptr>, <8 x i64> } %661, <8 x i64> %660, 1
  store { <8 x ptr>, <8 x i64> } %662, ptr %tile_snapshot.spill13, align 64
  store i64 0, ptr %.slot14, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state84 = load i64, ptr %.slot14, align 4
  %663 = icmp slt i64 %.state84, 96
  br i1 %663, label %direct.true85, label %direct.false86

direct.schedule.8:                                ; preds = %direct.true85
  %.state87 = load i64, ptr %.slot14, align 4
  %664 = mul i64 %.state87, 8
  %.splatinsert88 = insertelement <8 x i64> poison, i64 %664, i64 0
  %.splat89 = shufflevector <8 x i64> %.splatinsert88, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load90 = load <8 x i64>, ptr %.spill, align 64
  %665 = add <8 x i64> %.splat89, %.spill.load90
  %.spill.load91 = load i64, ptr %.spill6, align 4
  %666 = add i64 %.spill.load91, 0
  %667 = add <8 x i64> zeroinitializer, %665
  %668 = mul i64 %666, 768
  %.splatinsert92 = insertelement <8 x i64> poison, i64 %668, i64 0
  %.splat93 = shufflevector <8 x i64> %.splatinsert92, <8 x i64> poison, <8 x i32> zeroinitializer
  %669 = add <8 x i64> %.splat93, %667
  %670 = extractvalue { ptr, i64 } %15, 0
  %671 = extractelement <8 x i64> %669, i32 0
  %672 = sub i64 %671, 0
  %673 = mul i64 %672, 4
  %buffer.contiguous.address94 = getelementptr i8, ptr %670, i64 %673
  %buffer.contiguous.load95 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address94, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %674 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 0
  %675 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 1
  %.state97 = load i64, ptr %.slot14, align 4
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %.state97, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %676 = mul <8 x i64> %.splat99, splat (i64 32)
  %677 = add <8 x i64> %675, %676
  %678 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %674, 0
  %679 = insertvalue { <8 x ptr>, <8 x i64> } %678, <8 x i64> %677, 1
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %679, 1
  %682 = extractelement <8 x ptr> %680, i32 0
  %683 = extractelement <8 x i64> %681, i32 0
  %684 = sub i64 %683, 0
  %685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %686 = select i1 %685, i64 %684, i64 0
  %private.contiguous.address100 = getelementptr i8, ptr %682, i64 %686
  %private.contiguous.preserve101 = load <8 x float>, ptr %private.contiguous.address100, align 4
  %687 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load95, <8 x float> %private.contiguous.preserve101
  store <8 x float> %687, ptr %private.contiguous.address100, align 4
  %.state102 = load i64, ptr %.slot14, align 4
  %688 = add i64 %.state102, 1
  store i64 %688, ptr %.slot14, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false86
  %.spill.load103 = load float, ptr %.spill12, align 4
  %689 = fadd float %.spill.load103, 0x3EE4F8B580000000
  %690 = call float @llvm.sqrt.f32(float %689)
  store float %690, ptr %.spill15, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.9
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state104 = load i64, ptr %.slot16, align 4
  %691 = icmp slt i64 %.state104, 96
  br i1 %691, label %direct.true105, label %direct.false106

direct.schedule.12:                               ; preds = %direct.true105
  %.state107 = load i64, ptr %.slot16, align 4
  %692 = mul i64 %.state107, 8
  %.splatinsert108 = insertelement <8 x i64> poison, i64 %692, i64 0
  %.splat109 = shufflevector <8 x i64> %.splatinsert108, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load110 = load <8 x i64>, ptr %.spill, align 64
  %693 = add <8 x i64> %.splat109, %.spill.load110
  %tile_snapshot.spill.load111 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 0
  %695 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 1
  %.state112 = load i64, ptr %.slot16, align 4
  %.splatinsert113 = insertelement <8 x i64> poison, i64 %.state112, i64 0
  %.splat114 = shufflevector <8 x i64> %.splatinsert113, <8 x i64> poison, <8 x i32> zeroinitializer
  %696 = mul <8 x i64> %.splat114, splat (i64 32)
  %697 = add <8 x i64> %695, %696
  %698 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %694, 0
  %699 = insertvalue { <8 x ptr>, <8 x i64> } %698, <8 x i64> %697, 1
  %700 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %701 = extractvalue { <8 x ptr>, <8 x i64> } %699, 1
  %702 = extractelement <8 x ptr> %700, i32 0
  %703 = extractelement <8 x i64> %701, i32 0
  %704 = sub i64 %703, 0
  %705 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %706 = select i1 %705, i64 %704, i64 0
  %private.contiguous.address115 = getelementptr i8, ptr %702, i64 %706
  %private.contiguous.load116 = load <8 x float>, ptr %private.contiguous.address115, align 4
  %707 = select <8 x i1> %51, <8 x float> %private.contiguous.load116, <8 x float> zeroinitializer
  %.spill.load117 = load float, ptr %.spill15, align 4
  %.splatinsert118 = insertelement <8 x float> poison, float %.spill.load117, i64 0
  %.splat119 = shufflevector <8 x float> %.splatinsert118, <8 x float> poison, <8 x i32> zeroinitializer
  %708 = fdiv <8 x float> %707, %.splat119
  %tile_snapshot.spill.load120 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %709 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 0
  %710 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 1
  %.state121 = load i64, ptr %.slot16, align 4
  %.splatinsert122 = insertelement <8 x i64> poison, i64 %.state121, i64 0
  %.splat123 = shufflevector <8 x i64> %.splatinsert122, <8 x i64> poison, <8 x i32> zeroinitializer
  %711 = mul <8 x i64> %.splat123, splat (i64 32)
  %712 = add <8 x i64> %710, %711
  %713 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %709, 0
  %714 = insertvalue { <8 x ptr>, <8 x i64> } %713, <8 x i64> %712, 1
  %715 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %716 = extractvalue { <8 x ptr>, <8 x i64> } %714, 1
  %717 = extractelement <8 x ptr> %715, i32 0
  %718 = extractelement <8 x i64> %716, i32 0
  %719 = sub i64 %718, 0
  %720 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %721 = select i1 %720, i64 %719, i64 0
  %private.contiguous.address124 = getelementptr i8, ptr %717, i64 %721
  %private.contiguous.load125 = load <8 x float>, ptr %private.contiguous.address124, align 4
  %722 = select <8 x i1> %51, <8 x float> %private.contiguous.load125, <8 x float> zeroinitializer
  %723 = fmul <8 x float> %708, %722
  %.spill.load126 = load <8 x i64>, ptr %.spill4, align 64
  %724 = add <8 x i64> %.spill.load126, zeroinitializer
  %725 = add <8 x i64> zeroinitializer, %724
  %726 = add <8 x i64> zeroinitializer, %693
  %727 = mul <8 x i64> %725, splat (i64 768)
  %728 = add <8 x i64> %727, %726
  %729 = extractvalue { ptr, i64 } %27, 0
  %730 = extractelement <8 x i64> %728, i32 0
  %731 = sub i64 %730, 0
  %732 = mul i64 %731, 4
  %buffer.contiguous.address127 = getelementptr i8, ptr %729, i64 %732
  call void @llvm.masked.store.v8f32.p0(<8 x float> %723, ptr %buffer.contiguous.address127, i32 1, <8 x i1> %51)
  %.state128 = load i64, ptr %.slot16, align 4
  %733 = add i64 %.state128, 1
  store i64 %733, ptr %.slot16, align 4
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false106
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true47:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false48:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true85:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false86:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true105:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false106:                                  ; preds = %direct.schedule.11
  br label %direct.schedule.13
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  br label %packet.batch.full.loop

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full.loop
  ret void

packet.batch.full.loop:                           ; preds = %packet.batch.full.loop, %packet.batch.full
  %packet.index = phi i32 [ 0, %packet.batch.full ], [ %packet.index.next, %packet.batch.full.loop ]
  %packet.thread.offset = mul i32 %packet.index, 8
  %packet.thread.index = add i32 %base.thread.index, %packet.thread.offset
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config) #3
  %packet.index.next = add i32 %packet.index, 1
  %packet.batch.has.more = icmp ult i32 %packet.index.next, %packet_count
  br i1 %packet.batch.has.more, label %packet.batch.full.loop, label %packet.batch.exit

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { alwaysinline }

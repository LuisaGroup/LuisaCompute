
/private/tmp/luisa-packet-inline.UY1lIE/capture/layernorm-1024x4097/off/object/tile_xir_w8_36338_1788935095586321_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	mov	x10, #0x0               ; =0
       4:      	ldr	x8, [x1, #0x88]
       8:      	ldr	x15, [x0]
       c:      	ldr	x13, [x0, #0x10]
      10:      	ldr	w9, [x1]
      14:      	ldr	w11, [x1, #0x24]
      18:      	add	w9, w11, w9, lsl #5
      1c:      	lsr	w9, w9, #3
      20:      	dup.2s	v0, w9
      24:      	ushll.2d	v0, v0, #0x0
      28:      	fmov	x9, d0
      2c:      	mov	w11, #0x4004            ; =16388
      30:      	umaddl	x12, w9, w11, x15
      34:      	ldr	x11, [x0, #0x20]
      38:      	ldr	x9, [x0, #0x30]
      3c:      	add	x14, x12, x10
      40:      	ldp	q1, q2, [x14]
      44:      	add	x14, x8, x10
      48:      	stp	q1, q2, [x14]
      4c:      	add	x10, x10, #0x20
      50:      	cmp	x10, #0x4, lsl #12      ; =0x4000
      54:      	b.ne	0x3c <ltmp0+0x3c>
      58:      	fmov	x14, d0
      5c:      	add	x10, x14, x14, lsl #12
      60:      	lsl	x12, x10, #2
      64:      	add	x10, x12, #0x4, lsl #12 ; =0x4000
      68:      	add	x15, x15, x10
      6c:      	ldr	q0, [x8, #0x4000]
      70:      	ld1.s	{ v0 }[0], [x15]
      74:      	str	q0, [x8, #0x4000]
      78:      	ldp	q1, q2, [x8]
      7c:      	ldp	q6, q7, [x8, #0x20]
      80:      	ldp	q16, q3, [x8, #0x40]
      84:      	ldp	q4, q5, [x8, #0x60]
      88:      	add	x15, x8, #0xe0
      8c:      	mov	w16, #0x4               ; =4
      90:      	ldp	q17, q18, [x15, #-0x60]
      94:      	fadd.4s	v2, v2, v18
      98:      	fadd.4s	v1, v1, v17
      9c:      	ldp	q17, q18, [x15, #-0x40]
      a0:      	fadd.4s	v7, v7, v18
      a4:      	fadd.4s	v6, v6, v17
      a8:      	ldp	q17, q18, [x15, #-0x20]
      ac:      	fadd.4s	v3, v3, v18
      b0:      	fadd.4s	v16, v16, v17
      b4:      	ldp	q17, q18, [x15], #0x80
      b8:      	fadd.4s	v5, v5, v18
      bc:      	fadd.4s	v4, v4, v17
      c0:      	cmp	x16, #0x1fc
      c4:      	add	x16, x16, #0x4
      c8:      	b.lo	0x90 <ltmp0+0x90>
      cc:      	mov	w15, #0x4020            ; =16416
      d0:      	add	x15, x8, x15
      d4:      	fadd.4s	v17, v0, v1
      d8:      	mov.s	v1[0], v17[0]
      dc:      	fadd.4s	v2, v7, v2
      e0:      	fadd.4s	v1, v6, v1
      e4:      	fadd.4s	v1, v16, v1
      e8:      	fadd.4s	v2, v3, v2
      ec:      	fadd.4s	v2, v5, v2
      f0:      	fadd.4s	v1, v4, v1
      f4:      	rev64.4s	v3, v1
      f8:      	rev64.4s	v4, v2
      fc:      	fadd.4s	v2, v2, v4
     100:      	fadd.4s	v1, v1, v3
     104:      	dup.4s	v3, v1[2]
     108:      	dup.4s	v4, v2[2]
     10c:      	fadd.4s	v2, v2, v4
     110:      	fadd.4s	v1, v1, v3
     114:      	fadd.4s	v1, v1, v2
     118:      	movi	d2, #0000000000000000
     11c:      	fadd	s1, s1, s2
     120:      	mov	w16, #0x800             ; =2048
     124:      	movk	w16, #0x4580, lsl #16
     128:      	fmov	s2, w16
     12c:      	fdiv	s1, s1, s2
     130:      	dup.4s	v2, v1[0]
     134:      	mov	w16, #0x200             ; =512
     138:      	mov	x17, x8
     13c:      	ldp	q4, q3, [x17]
     140:      	fsub.4s	v4, v4, v2
     144:      	fsub.4s	v3, v3, v2
     148:      	str	q3, [x17, #0x4030]
     14c:      	str	q4, [x17, #0x4020]
     150:      	add	x17, x17, #0x20
     154:      	subs	x16, x16, #0x1
     158:      	b.ne	0x13c <ltmp0+0x13c>
     15c:      	fsub.4s	v0, v0, v1
     160:      	ldr	q1, [x8, #0x8020]
     164:      	mov.s	v1[0], v0[0]
     168:      	str	q1, [x8, #0x8020]
     16c:      	ldr	q1, [x8, #0x4020]
     170:      	ldr	q2, [x8, #0x4030]
     174:      	fmul.4s	v2, v2, v2
     178:      	fmul.4s	v1, v1, v1
     17c:      	ldr	q3, [x8, #0x4040]
     180:      	ldr	q4, [x8, #0x4050]
     184:      	fmul.4s	v4, v4, v4
     188:      	fmul.4s	v3, v3, v3
     18c:      	ldr	q6, [x8, #0x4060]
     190:      	ldr	q5, [x8, #0x4070]
     194:      	fmul.4s	v5, v5, v5
     198:      	fmul.4s	v6, v6, v6
     19c:      	ldr	q7, [x8, #0x4080]
     1a0:      	ldr	q16, [x8, #0x4090]
     1a4:      	fmul.4s	v16, v16, v16
     1a8:      	fmul.4s	v7, v7, v7
     1ac:      	mov	w16, #0x4100            ; =16640
     1b0:      	add	x16, x8, x16
     1b4:      	mov	w17, #0x205             ; =517
     1b8:      	ldp	q18, q17, [x16, #-0x60]
     1bc:      	fmul.4s	v18, v18, v18
     1c0:      	fmul.4s	v17, v17, v17
     1c4:      	fadd.4s	v2, v2, v17
     1c8:      	fadd.4s	v1, v1, v18
     1cc:      	ldp	q18, q17, [x16, #-0x40]
     1d0:      	fmul.4s	v18, v18, v18
     1d4:      	fmul.4s	v17, v17, v17
     1d8:      	fadd.4s	v4, v4, v17
     1dc:      	fadd.4s	v3, v3, v18
     1e0:      	ldp	q18, q17, [x16, #-0x20]
     1e4:      	fmul.4s	v18, v18, v18
     1e8:      	fmul.4s	v17, v17, v17
     1ec:      	fadd.4s	v5, v5, v17
     1f0:      	fadd.4s	v6, v6, v18
     1f4:      	ldp	q18, q17, [x16], #0x80
     1f8:      	fmul.4s	v18, v18, v18
     1fc:      	fmul.4s	v17, v17, v17
     200:      	fadd.4s	v16, v16, v17
     204:      	fadd.4s	v7, v7, v18
     208:      	sub	x0, x17, #0x201
     20c:      	add	x17, x17, #0x4
     210:      	cmp	x0, #0x1fc
     214:      	b.lo	0x1b8 <ltmp0+0x1b8>
     218:      	mov	x17, #0x0               ; =0
     21c:      	mov	w16, #0x8040            ; =32832
     220:      	add	x16, x8, x16
     224:      	add	x0, x13, x17
     228:      	ldp	q17, q18, [x0]
     22c:      	add	x0, x16, x17
     230:      	stp	q17, q18, [x0]
     234:      	add	x17, x17, #0x20
     238:      	cmp	x17, #0x4, lsl #12      ; =0x4000
     23c:      	b.ne	0x224 <ltmp0+0x224>
     240:      	fmul.4s	v0, v0, v0
     244:      	fadd.4s	v0, v0, v1
     248:      	mov.s	v1[0], v0[0]
     24c:      	fadd.4s	v0, v4, v2
     250:      	fadd.4s	v1, v3, v1
     254:      	fadd.4s	v1, v6, v1
     258:      	fadd.4s	v0, v5, v0
     25c:      	fadd.4s	v0, v16, v0
     260:      	fadd.4s	v1, v7, v1
     264:      	rev64.4s	v2, v1
     268:      	rev64.4s	v3, v0
     26c:      	fadd.4s	v0, v0, v3
     270:      	fadd.4s	v1, v1, v2
     274:      	dup.4s	v2, v1[2]
     278:      	dup.4s	v3, v0[2]
     27c:      	fadd.4s	v0, v0, v3
     280:      	fadd.4s	v1, v1, v2
     284:      	fadd.4s	v0, v1, v0
     288:      	movi	d1, #0000000000000000
     28c:      	fadd	s0, s0, s1
     290:      	mov	w17, #0x800             ; =2048
     294:      	movk	w17, #0x4580, lsl #16
     298:      	fmov	s1, w17
     29c:      	fdiv	s0, s0, s1
     2a0:      	mov	w17, #0x4000            ; =16384
     2a4:      	ldr	s1, [x13, x17]
     2a8:      	mov	w13, #0xc040            ; =49216
     2ac:      	str	s1, [x8, x13]
     2b0:      	mov	w13, #0xc5ac            ; =50604
     2b4:      	movk	w13, #0x3727, lsl #16
     2b8:      	fmov	s1, w13
     2bc:      	fadd	s0, s0, s1
     2c0:      	fsqrt	s0, s0
     2c4:      	subs	x13, x9, x11
     2c8:      	mov	w17, #0x4003            ; =16387
     2cc:      	ccmp	x13, x17, #0x0, hs
     2d0:      	cset	w13, hi
     2d4:      	mov	w17, #0xfff             ; =4095
     2d8:      	movk	w17, #0x100, lsl #16
     2dc:      	sub	x0, x11, x9
     2e0:      	cmp	x0, x17
     2e4:      	ccmp	x11, x9, #0x0, hi
     2e8:      	b.hs	0x39c <ltmp0+0x39c>
     2ec:      	tbnz	w13, #0x0, 0x39c <ltmp0+0x39c>
     2f0:      	mov	x13, #0x0               ; =0
     2f4:      	mov	w14, #0xc060            ; =49248
     2f8:      	add	x14, x8, x14
     2fc:      	add	x15, x11, x13
     300:      	ldp	q1, q2, [x15]
     304:      	add	x15, x14, x13
     308:      	stp	q1, q2, [x15]
     30c:      	add	x13, x13, #0x20
     310:      	cmp	x13, #0x4, lsl #12      ; =0x4000
     314:      	b.ne	0x2fc <ltmp0+0x2fc>
     318:      	ldr	s1, [x11, x13]
     31c:      	mov	w11, #0x60              ; =96
     320:      	movk	w11, #0x1, lsl #16
     324:      	str	s1, [x8, x11]
     328:      	dup.4s	v1, v0[0]
     32c:      	add	x11, x9, x12
     330:      	mov	w12, #0x200             ; =512
     334:      	mov	x13, x8
     338:      	ldr	q2, [x13, #0x4030]
     33c:      	ldr	q3, [x13, #0x4020]
     340:      	fdiv.4s	v3, v3, v1
     344:      	fdiv.4s	v2, v2, v1
     348:      	ldr	q4, [x13, #0x8040]
     34c:      	ldr	q5, [x13, #0x8050]
     350:      	fmul.4s	v2, v2, v5
     354:      	fmul.4s	v3, v3, v4
     358:      	ldr	q4, [x13, #0xc070]
     35c:      	ldr	q5, [x13, #0xc060]
     360:      	fadd.4s	v3, v3, v5
     364:      	fadd.4s	v2, v2, v4
     368:      	stp	q3, q2, [x11], #0x20
     36c:      	add	x13, x13, #0x20
     370:      	subs	x12, x12, #0x1
     374:      	b.ne	0x338 <ltmp0+0x338>
     378:      	ldr	q1, [x8, #0x8020]
     37c:      	fdiv.4s	v0, v1, v0
     380:      	ldr	q1, [x8, #0xc040]
     384:      	fmul.4s	v0, v0, v1
     388:      	add	x11, x8, #0x10, lsl #12 ; =0x10000
     38c:      	ldr	q1, [x11, #0x60]
     390:      	fadd.4s	v0, v0, v1
     394:      	str	s0, [x9, x10]
     398:      	ret
     39c:      	mov	x13, #0x0               ; =0
     3a0:      	dup.4s	v1, v0[0]
     3a4:      	mov	w12, #0x4004            ; =16388
     3a8:      	umaddl	x12, w14, w12, x9
     3ac:      	movi.2d	v2, #0000000000000000
     3b0:      	mov	w14, #0x1               ; =1
     3b4:      	dup.2d	v3, x14
     3b8:      	movi.2d	v4, #0000000000000000
     3bc:      	movi.2d	v5, #0000000000000000
     3c0:      	movi.2d	v6, #0000000000000000
     3c4:      	lsl	x13, x13, #5
     3c8:      	add	x14, x15, x13
     3cc:      	ldp	q16, q7, [x14]
     3d0:      	fdiv.4s	v16, v16, v1
     3d4:      	fdiv.4s	v7, v7, v1
     3d8:      	add	x13, x16, x13
     3dc:      	ldp	q17, q18, [x13]
     3e0:      	fmul.4s	v7, v7, v18
     3e4:      	fmul.4s	v16, v16, v17
     3e8:      	fmov	x13, d2
     3ec:      	lsl	x13, x13, #5
     3f0:      	add	x14, x11, x13
     3f4:      	ldp	q18, q17, [x14]
     3f8:      	fadd.4s	v16, v16, v18
     3fc:      	fadd.4s	v7, v7, v17
     400:      	add	x13, x12, x13
     404:      	stp	q16, q7, [x13]
     408:      	add.2d	v5, v5, v3
     40c:      	add.2d	v4, v4, v3
     410:      	add.2d	v6, v6, v3
     414:      	add.2d	v2, v2, v3
     418:      	fmov	x13, d2
     41c:      	cmp	x13, #0x200
     420:      	b.lt	0x3c4 <ltmp0+0x3c4>
     424:      	ldr	q1, [x8, #0x8020]
     428:      	fdiv.4s	v0, v1, v0
     42c:      	ldr	q1, [x8, #0xc040]
     430:      	fmul.4s	v0, v0, v1
     434:      	mov	w8, #0x4000             ; =16384
     438:      	ldr	s1, [x11, x8]
     43c:      	fadd.4s	v0, v0, v1
     440:      	str	s0, [x9, x10]
     444:      	ret

0000000000000448 <_llm_rows.packet_batch.blocks>:
     448:      	cbz	w3, 0x1e18 <_llm_rows.packet_batch.blocks+0x19d0>
     44c:      	stp	d15, d14, [sp, #-0xa0]!
     450:      	stp	d13, d12, [sp, #0x10]
     454:      	stp	d11, d10, [sp, #0x20]
     458:      	stp	d9, d8, [sp, #0x30]
     45c:      	stp	x28, x27, [sp, #0x40]
     460:      	stp	x26, x25, [sp, #0x50]
     464:      	stp	x24, x23, [sp, #0x60]
     468:      	stp	x22, x21, [sp, #0x70]
     46c:      	stp	x20, x19, [sp, #0x80]
     470:      	stp	x29, x30, [sp, #0x90]
     474:      	sub	sp, sp, #0x6c0
     478:      	mov	x19, x3
     47c:      	mov	x20, x2
     480:      	mov	x21, x0
     484:      	mov	w22, #0x0               ; =0
     488:      	ldp	w9, w8, [x2, #0x2c]
     48c:      	str	w9, [sp, #0x1ec]
     490:      	str	w8, [sp, #0x1e8]
     494:      	ldp	w25, w24, [x2]
     498:      	ldp	w23, w28, [x2, #0x8]
     49c:      	adrp	x8, 0x0 <ltmp0>
     4a0:      	ldr	q0, [x8]
     4a4:      	str	q0, [sp, #0x10]
     4a8:      	adrp	x8, 0x0 <ltmp0>
     4ac:      	ldr	q0, [x8]
     4b0:      	str	q0, [sp, #0x30]
     4b4:      	adrp	x8, 0x0 <ltmp0>
     4b8:      	ldr	q0, [x8]
     4bc:      	str	q0, [sp, #0x20]
     4c0:      	mov	w26, #0x4               ; =4
     4c4:      	str	w3, [sp, #0x1bc]
     4c8:      	b	0x514 <_llm_rows.packet_batch.blocks+0xcc>
     4cc:      	mov	w8, #0x18               ; =24
     4d0:      	str	w8, [x20, #0x24]
     4d4:      	ldr	w19, [sp, #0x1bc]
     4d8:      	add	w8, w25, #0x1
     4dc:      	ldr	w9, [sp, #0x1ec]
     4e0:      	cmp	w8, w9
     4e4:      	cset	w8, eq
     4e8:      	csinc	w25, wzr, w25, eq
     4ec:      	cinc	w9, w24, eq
     4f0:      	ldr	w10, [sp, #0x1e8]
     4f4:      	cmp	w9, w10
     4f8:      	cset	w10, eq
     4fc:      	ands	w8, w8, w10
     500:      	csel	w24, wzr, w9, ne
     504:      	add	w23, w23, w8
     508:      	add	w22, w22, #0x1
     50c:      	cmp	w22, w19
     510:      	b.eq	0x1dec <_llm_rows.packet_batch.blocks+0x19a4>
     514:      	ubfiz	x8, x25, #5, #32
     518:      	cmp	x8, x28
     51c:      	csel	x9, x8, xzr, ls
     520:      	subs	x10, x28, x9
     524:      	cmp	x10, #0x20
     528:      	mov	w11, #0x20              ; =32
     52c:      	csel	x10, x10, x11, lo
     530:      	cmp	x28, x9
     534:      	stp	w25, w24, [x20]
     538:      	str	w23, [x20, #0x8]
     53c:      	str	wzr, [x20, #0x24]
     540:      	ccmp	x8, x28, #0x2, hi
     544:      	csel	x27, x10, xzr, ls
     548:      	cmp	x27, #0x20
     54c:      	b.lo	0x59c <_llm_rows.packet_batch.blocks+0x154>
     550:      	mov	x0, x21
     554:      	mov	x1, x20
     558:      	bl	0x558 <_llm_rows.packet_batch.blocks+0x110>
     55c:      	mov	w8, #0x8                ; =8
     560:      	str	w8, [x20, #0x24]
     564:      	mov	x0, x21
     568:      	mov	x1, x20
     56c:      	bl	0x56c <_llm_rows.packet_batch.blocks+0x124>
     570:      	mov	w8, #0x10               ; =16
     574:      	str	w8, [x20, #0x24]
     578:      	mov	x0, x21
     57c:      	mov	x1, x20
     580:      	bl	0x580 <_llm_rows.packet_batch.blocks+0x138>
     584:      	mov	w8, #0x18               ; =24
     588:      	str	w8, [x20, #0x24]
     58c:      	mov	x0, x21
     590:      	mov	x1, x20
     594:      	bl	0x594 <_llm_rows.packet_batch.blocks+0x14c>
     598:      	b	0x4d8 <_llm_rows.packet_batch.blocks+0x90>
     59c:      	lsr	x19, x27, #3
     5a0:      	cmp	x27, #0x8
     5a4:      	b.lo	0x5f0 <_llm_rows.packet_batch.blocks+0x1a8>
     5a8:      	str	wzr, [x20, #0x24]
     5ac:      	mov	x0, x21
     5b0:      	mov	x1, x20
     5b4:      	bl	0x5b4 <_llm_rows.packet_batch.blocks+0x16c>
     5b8:      	cmp	x19, #0x1
     5bc:      	b.eq	0x5f0 <_llm_rows.packet_batch.blocks+0x1a8>
     5c0:      	mov	w8, #0x8                ; =8
     5c4:      	str	w8, [x20, #0x24]
     5c8:      	mov	x0, x21
     5cc:      	mov	x1, x20
     5d0:      	bl	0x5d0 <_llm_rows.packet_batch.blocks+0x188>
     5d4:      	cmp	x19, #0x2
     5d8:      	b.eq	0x5f0 <_llm_rows.packet_batch.blocks+0x1a8>
     5dc:      	mov	w8, #0x10               ; =16
     5e0:      	str	w8, [x20, #0x24]
     5e4:      	mov	x0, x21
     5e8:      	mov	x1, x20
     5ec:      	bl	0x5ec <_llm_rows.packet_batch.blocks+0x1a4>
     5f0:      	and	w8, w27, #0x7
     5f4:      	cbz	w8, 0x4cc <_llm_rows.packet_batch.blocks+0x84>
     5f8:      	dup.4s	v1, w8
     5fc:      	ldp	q0, q2, [sp, #0x20]
     600:      	cmhi.4s	v0, v1, v0
     604:      	cmhi.4s	v1, v1, v2
     608:      	uzp1.8h	v3, v1, v0
     60c:      	umaxv.8h	h2, v3
     610:      	fmov	w8, s2
     614:      	tbz	w8, #0x0, 0x4cc <_llm_rows.packet_batch.blocks+0x84>
     618:      	mov	x14, #0x0               ; =0
     61c:      	ldr	x16, [x20, #0x88]
     620:      	mov	w8, #0x4020             ; =16416
     624:      	add	x10, x16, x8
     628:      	mov	w8, #0x8040             ; =32832
     62c:      	add	x9, x16, x8
     630:      	mov	w8, #0xc060             ; =49248
     634:      	add	x12, x16, x8
     638:      	ldr	x11, [x21]
     63c:      	ldr	x15, [x21, #0x10]
     640:      	ldr	x13, [x21, #0x20]
     644:      	ldr	x8, [x21, #0x30]
     648:      	ldr	q2, [sp, #0x10]
     64c:      	str	q3, [sp, #0xd0]
     650:      	and.16b	v2, v3, v2
     654:      	addv.8h	h18, v2
     658:      	fmov	w17, s18
     65c:      	and	w17, w17, #0xff
     660:      	str	w17, [sp, #0xe0]
     664:      	ubfiz	w17, w25, #2, #27
     668:      	orr	w17, w17, w19
     66c:      	dup.4s	v3, w17
     670:      	and.16b	v4, v1, v3
     674:      	and.16b	v3, v0, v3
     678:      	ushll2.2d	v5, v3, #0x0
     67c:      	ushll2.2d	v6, v4, #0x0
     680:      	ushll.2d	v7, v3, #0x0
     684:      	ushll.2d	v3, v4, #0x0
     688:      	fmov	x17, d3
     68c:      	mov	w0, #0x4004             ; =16388
     690:      	umaddl	x17, w17, w0, x11
     694:      	fmov	w0, s18
     698:      	b	0x6bc <_llm_rows.packet_batch.blocks+0x274>
     69c:      	add	x1, x16, x14
     6a0:      	ldp	q17, q19, [x1]
     6a4:      	bif.16b	v16, v19, v0
     6a8:      	bif.16b	v4, v17, v1
     6ac:      	stp	q4, q16, [x1]
     6b0:      	add	x14, x14, #0x20
     6b4:      	cmp	x14, #0x4, lsl #12      ; =0x4000
     6b8:      	b.eq	0x750 <_llm_rows.packet_batch.blocks+0x308>
     6bc:      	add	x1, x17, x14
     6c0:      	movi.2d	v4, #0000000000000000
     6c4:      	movi.2d	v16, #0000000000000000
     6c8:      	tbnz	w0, #0x0, 0x6f0 <_llm_rows.packet_batch.blocks+0x2a8>
     6cc:      	and	w2, w0, #0xff
     6d0:      	tbnz	w2, #0x1, 0x6fc <_llm_rows.packet_batch.blocks+0x2b4>
     6d4:      	tbnz	w2, #0x2, 0x708 <_llm_rows.packet_batch.blocks+0x2c0>
     6d8:      	tbnz	w2, #0x3, 0x714 <_llm_rows.packet_batch.blocks+0x2cc>
     6dc:      	tbnz	w2, #0x4, 0x720 <_llm_rows.packet_batch.blocks+0x2d8>
     6e0:      	tbnz	w2, #0x5, 0x72c <_llm_rows.packet_batch.blocks+0x2e4>
     6e4:      	tbnz	w2, #0x6, 0x738 <_llm_rows.packet_batch.blocks+0x2f0>
     6e8:      	tbz	w2, #0x7, 0x69c <_llm_rows.packet_batch.blocks+0x254>
     6ec:      	b	0x744 <_llm_rows.packet_batch.blocks+0x2fc>
     6f0:      	ldr	s4, [x1]
     6f4:      	and	w2, w0, #0xff
     6f8:      	tbz	w2, #0x1, 0x6d4 <_llm_rows.packet_batch.blocks+0x28c>
     6fc:      	add	x3, x1, #0x4
     700:      	ld1.s	{ v4 }[1], [x3]
     704:      	tbz	w2, #0x2, 0x6d8 <_llm_rows.packet_batch.blocks+0x290>
     708:      	add	x3, x1, #0x8
     70c:      	ld1.s	{ v4 }[2], [x3]
     710:      	tbz	w2, #0x3, 0x6dc <_llm_rows.packet_batch.blocks+0x294>
     714:      	add	x3, x1, #0xc
     718:      	ld1.s	{ v4 }[3], [x3]
     71c:      	tbz	w2, #0x4, 0x6e0 <_llm_rows.packet_batch.blocks+0x298>
     720:      	add	x3, x1, #0x10
     724:      	ld1.s	{ v16 }[0], [x3]
     728:      	tbz	w2, #0x5, 0x6e4 <_llm_rows.packet_batch.blocks+0x29c>
     72c:      	add	x3, x1, #0x14
     730:      	ld1.s	{ v16 }[1], [x3]
     734:      	tbz	w2, #0x6, 0x6e8 <_llm_rows.packet_batch.blocks+0x2a0>
     738:      	add	x3, x1, #0x18
     73c:      	ld1.s	{ v16 }[2], [x3]
     740:      	tbz	w2, #0x7, 0x69c <_llm_rows.packet_batch.blocks+0x254>
     744:      	add	x1, x1, #0x1c
     748:      	ld1.s	{ v16 }[3], [x1]
     74c:      	b	0x69c <_llm_rows.packet_batch.blocks+0x254>
     750:      	xtn.4h	v4, v1
     754:      	uzp1.8b	v17, v4, v0
     758:      	sshll.2d	v22, v1, #0x0
     75c:      	adrp	x14, 0x0 <ltmp0>
     760:      	ldr	q4, [x14]
     764:      	and.16b	v16, v22, v4
     768:      	movi.2d	v4, #0000000000000000
     76c:      	mov.b	v4[0], v17[0]
     770:      	adrp	x14, 0x0 <ltmp0>
     774:      	ldr	d2, [x14]
     778:      	str	d2, [sp, #0x128]
     77c:      	and.8b	v19, v4, v2
     780:      	addv.8b	b19, v19
     784:      	fmov	w14, s19
     788:      	umaxv.8b	b19, v4
     78c:      	fmov	w17, s19
     790:      	rbit	w0, w14
     794:      	clz	w0, w0
     798:      	tst	w17, #0x1
     79c:      	csel	w2, w0, wzr, ne
     7a0:      	mov	w0, #0x1000             ; =4096
     7a4:      	dup.2d	v24, x0
     7a8:      	orr.16b	v2, v16, v24
     7ac:      	mov	w0, #0x1001             ; =4097
     7b0:      	dup.2s	v23, w0
     7b4:      	xtn.2s	v27, v3
     7b8:      	str	q2, [sp, #0x130]
     7bc:      	umlal.2d	v2, v27, v23
     7c0:      	movi.2d	v3, #0000000000000000
     7c4:      	mov.b	v3[0], v17[0]
     7c8:      	ushll.2d	v3, v3, #0x0
     7cc:      	shl.2d	v3, v3, #0x3f
     7d0:      	cmlt.2d	v3, v3, #0
     7d4:      	str	q2, [sp, #0x190]
     7d8:      	and.16b	v3, v3, v2
     7dc:      	movi.2d	v2, #0000000000000000
     7e0:      	str	q2, [sp, #0x6a0]
     7e4:      	str	q2, [sp, #0x690]
     7e8:      	str	q2, [sp, #0x680]
     7ec:      	str	q3, [sp, #0x670]
     7f0:      	and	x0, x2, #0x7
     7f4:      	add	x1, sp, #0x670
     7f8:      	ldr	x0, [x1, x0, lsl #3]
     7fc:      	sub	x0, x0, x2
     800:      	add	x11, x11, x0, lsl #2
     804:      	movi.2d	v19, #0000000000000000
     808:      	movi.2d	v8, #0000000000000000
     80c:      	tbnz	w17, #0x0, 0x1a00 <_llm_rows.packet_batch.blocks+0x15b8>
     810:      	tbnz	w14, #0x1, 0x1a08 <_llm_rows.packet_batch.blocks+0x15c0>
     814:      	tbnz	w14, #0x2, 0x1a14 <_llm_rows.packet_batch.blocks+0x15cc>
     818:      	tbnz	w14, #0x3, 0x1a20 <_llm_rows.packet_batch.blocks+0x15d8>
     81c:      	tbnz	w14, #0x4, 0x1a2c <_llm_rows.packet_batch.blocks+0x15e4>
     820:      	tbnz	w14, #0x5, 0x1a38 <_llm_rows.packet_batch.blocks+0x15f0>
     824:      	tbnz	w14, #0x6, 0x1a44 <_llm_rows.packet_batch.blocks+0x15fc>
     828:      	str	q18, [sp, #0x1a0]
     82c:      	tbz	w14, #0x7, 0x838 <_llm_rows.packet_batch.blocks+0x3f0>
     830:      	add	x11, x11, #0x1c
     834:      	ld1.s	{ v8 }[3], [x11]
     838:      	str	q16, [sp, #0x1c0]
     83c:      	sshll.2d	v25, v0, #0x0
     840:      	sshll2.2d	v28, v1, #0x0
     844:      	sshll2.2d	v29, v0, #0x0
     848:      	adrp	x11, 0x0 <ltmp0>
     84c:      	ldr	q3, [x11]
     850:      	and.16b	v2, v29, v3
     854:      	adrp	x11, 0x0 <ltmp0>
     858:      	ldr	q20, [x11]
     85c:      	and.16b	v3, v28, v20
     860:      	adrp	x11, 0x0 <ltmp0>
     864:      	ldr	q21, [x11]
     868:      	and.16b	v16, v25, v21
     86c:      	adrp	x11, 0x0 <ltmp0>
     870:      	ldr	q26, [x11]
     874:      	and.16b	v26, v29, v26
     878:      	adrp	x11, 0x0 <ltmp0>
     87c:      	ldr	q30, [x11]
     880:      	and.16b	v30, v28, v30
     884:      	adrp	x11, 0x0 <ltmp0>
     888:      	ldr	q31, [x11]
     88c:      	and.16b	v25, v25, v31
     890:      	adrp	x11, 0x0 <ltmp0>
     894:      	ldr	q31, [x11]
     898:      	and.16b	v22, v22, v31
     89c:      	stp	q16, q3, [sp, #0x80]
     8a0:      	orr.16b	v16, v16, v24
     8a4:      	orr.16b	v17, v3, v24
     8a8:      	str	q2, [sp, #0xa0]
     8ac:      	orr.16b	v3, v2, v24
     8b0:      	umull.2d	v2, v27, v23
     8b4:      	str	q2, [sp, #0x140]
     8b8:      	xtn.2s	v6, v6
     8bc:      	xtn.2s	v7, v7
     8c0:      	xtn.2s	v5, v5
     8c4:      	stp	q16, q3, [sp, #0x100]
     8c8:      	mov.16b	v2, v3
     8cc:      	umlal.2d	v2, v5, v23
     8d0:      	str	q2, [sp, #0x180]
     8d4:      	str	q17, [sp, #0xf0]
     8d8:      	mov.16b	v2, v17
     8dc:      	umlal.2d	v2, v6, v23
     8e0:      	str	q2, [sp, #0x170]
     8e4:      	mov.16b	v2, v16
     8e8:      	umlal.2d	v2, v7, v23
     8ec:      	str	q2, [sp, #0x160]
     8f0:      	sshll.2d	v5, v1, #0x0
     8f4:      	sshll.2d	v6, v0, #0x0
     8f8:      	str	q22, [sp, #0x630]
     8fc:      	str	q30, [sp, #0x640]
     900:      	str	q25, [sp, #0x650]
     904:      	str	q26, [sp, #0x660]
     908:      	and	x11, x2, #0x7
     90c:      	add	x17, sp, #0x630
     910:      	ldr	x11, [x17, x11, lsl #3]
     914:      	orr	x11, x11, #0x4000
     918:      	str	x2, [sp, #0x1b0]
     91c:      	sub	x11, x11, x2, lsl #2
     920:      	tst	w14, #0xff
     924:      	csel	x11, xzr, x11, eq
     928:      	str	x11, [sp, #0x158]
     92c:      	add	x11, x16, x11
     930:      	ldp	q7, q23, [x11]
     934:      	zip2.8b	v24, v4, v0
     938:      	ushll.4s	v24, v24, #0x0
     93c:      	shl.4s	v24, v24, #0x1f
     940:      	cmlt.4s	v24, v24, #0
     944:      	stp	q8, q19, [sp, #0xb0]
     948:      	bit.16b	v23, v8, v24
     94c:      	str	q4, [sp, #0x1d0]
     950:      	zip1.8b	v24, v4, v0
     954:      	ushll.4s	v24, v24, #0x0
     958:      	shl.4s	v24, v24, #0x1f
     95c:      	cmlt.4s	v24, v24, #0
     960:      	bit.16b	v7, v19, v24
     964:      	stp	q7, q23, [x11]
     968:      	fmov	x14, d22
     96c:      	dup.2d	v7, x26
     970:      	and.16b	v26, v29, v7
     974:      	and.16b	v31, v28, v7
     978:      	and.16b	v25, v6, v7
     97c:      	and.16b	v10, v5, v7
     980:      	fmov	x11, d10
     984:      	ldp	q6, q5, [x16, #0x60]
     988:      	and.16b	v5, v0, v5
     98c:      	and.16b	v6, v1, v6
     990:      	ldp	q7, q22, [x16, #0x40]
     994:      	and.16b	v22, v0, v22
     998:      	and.16b	v7, v1, v7
     99c:      	ldp	q24, q23, [x16, #0x20]
     9a0:      	and.16b	v23, v0, v23
     9a4:      	and.16b	v24, v1, v24
     9a8:      	str	x14, [sp, #0x70]
     9ac:      	add	x17, x16, x14
     9b0:      	ldp	q27, q30, [x17]
     9b4:      	and.16b	v11, v0, v30
     9b8:      	mov	x17, x11
     9bc:      	and.16b	v12, v1, v27
     9c0:      	mov.16b	v27, v10
     9c4:      	mov.16b	v15, v31
     9c8:      	mov.16b	v9, v25
     9cc:      	mov.16b	v30, v26
     9d0:      	sshll.2d	v8, v1, #0x0
     9d4:      	sshll.2d	v18, v0, #0x0
     9d8:      	add	x17, x16, x17, lsl #5
     9dc:      	ldp	q13, q14, [x17]
     9e0:      	fadd.4s	v13, v12, v13
     9e4:      	fadd.4s	v14, v11, v14
     9e8:      	ldp	q4, q16, [x17, #0x20]
     9ec:      	fadd.4s	v4, v24, v4
     9f0:      	fadd.4s	v16, v23, v16
     9f4:      	ldp	q20, q3, [x17, #0x40]
     9f8:      	fadd.4s	v20, v7, v20
     9fc:      	fadd.4s	v3, v22, v3
     a00:      	ldp	q17, q21, [x17, #0x60]
     a04:      	fadd.4s	v17, v6, v17
     a08:      	fadd.4s	v21, v5, v21
     a0c:      	dup.2d	v19, x26
     a10:      	and.16b	v2, v29, v19
     a14:      	add.2d	v30, v30, v2
     a18:      	and.16b	v2, v28, v19
     a1c:      	add.2d	v15, v15, v2
     a20:      	and.16b	v2, v18, v19
     a24:      	add.2d	v9, v9, v2
     a28:      	and.16b	v2, v8, v19
     a2c:      	add.2d	v27, v27, v2
     a30:      	bit.16b	v11, v14, v0
     a34:      	bit.16b	v12, v13, v1
     a38:      	bit.16b	v23, v16, v0
     a3c:      	bit.16b	v24, v4, v1
     a40:      	bit.16b	v22, v3, v0
     a44:      	bit.16b	v7, v20, v1
     a48:      	bit.16b	v5, v21, v0
     a4c:      	bit.16b	v6, v17, v1
     a50:      	fmov	x17, d27
     a54:      	cmp	x17, #0x200
     a58:      	b.lt	0x9d0 <_llm_rows.packet_batch.blocks+0x588>
     a5c:      	mov	x0, #0x0                ; =0
     a60:      	ldp	q3, q2, [sp, #0xc0]
     a64:      	xtn.8b	v30, v2
     a68:      	ldr	q2, [sp, #0xb0]
     a6c:      	fadd.4s	v2, v2, v11
     a70:      	fadd.4s	v3, v3, v12
     a74:      	ldr	q27, [sp, #0x1d0]
     a78:      	zip1.8b	v4, v27, v0
     a7c:      	ushll.4s	v4, v4, #0x0
     a80:      	shl.4s	v4, v4, #0x1f
     a84:      	cmlt.4s	v4, v4, #0
     a88:      	and.16b	v3, v4, v3
     a8c:      	zip2.8b	v4, v27, v0
     a90:      	ushll.4s	v4, v4, #0x0
     a94:      	shl.4s	v4, v4, #0x1f
     a98:      	cmlt.4s	v4, v4, #0
     a9c:      	and.16b	v2, v4, v2
     aa0:      	zip2.8b	v4, v30, v0
     aa4:      	ushll.4s	v4, v4, #0x0
     aa8:      	shl.4s	v4, v4, #0x1f
     aac:      	cmlt.4s	v4, v4, #0
     ab0:      	movi.2d	v16, #0000000000000000
     ab4:      	mov.b	v16[2], v30[1]
     ab8:      	mov.b	v16[4], v30[2]
     abc:      	bit.16b	v2, v14, v4
     ac0:      	mov.b	v16[6], v30[3]
     ac4:      	ushll.4s	v4, v16, #0x0
     ac8:      	shl.4s	v4, v4, #0x1f
     acc:      	cmlt.4s	v4, v4, #0
     ad0:      	bit.16b	v3, v13, v4
     ad4:      	fadd.4s	v3, v24, v3
     ad8:      	fadd.4s	v2, v23, v2
     adc:      	fadd.4s	v2, v22, v2
     ae0:      	fadd.4s	v3, v7, v3
     ae4:      	fadd.4s	v6, v6, v3
     ae8:      	fadd.4s	v7, v5, v2
     aec:      	ldr	q2, [sp, #0x1c0]
     af0:      	ldp	q3, q4, [sp, #0x80]
     af4:      	uzp1.4s	v5, v2, v4
     af8:      	ldr	q2, [sp, #0xa0]
     afc:      	uzp1.4s	v3, v3, v2
     b00:      	movi.4s	v4, #0x1
     b04:      	eor.16b	v2, v5, v4
     b08:      	mov.s	w1, v2[1]
     b0c:      	eor.16b	v20, v3, v4
     b10:      	mov.s	w2, v2[2]
     b14:      	mov.s	w5, v2[3]
     b18:      	fmov	w3, s2
     b1c:      	add	x17, sp, #0x4c8
     b20:      	bfxil	x17, x3, #0, #3
     b24:      	str	d30, [sp, #0x4c8]
     b28:      	ldrb	w6, [x17]
     b2c:      	umov.b	w17, v30[0]
     b30:      	and	x3, x3, #0x7
     b34:      	str	q7, [sp, #0x5a0]
     b38:      	str	q6, [sp, #0x590]
     b3c:      	add	x4, sp, #0x590
     b40:      	ldr	s2, [x4, x3, lsl #2]
     b44:      	ands	w4, w17, #0x1
     b48:      	tst	w4, w6
     b4c:      	movi	d22, #0000000000000000
     b50:      	fcsel	s17, s2, s22, ne
     b54:      	and	x6, x1, #0x7
     b58:      	add	x3, sp, #0x4c8
     b5c:      	bfxil	x3, x1, #0, #3
     b60:      	ldrb	w1, [x3]
     b64:      	umov.b	w3, v30[1]
     b68:      	str	q7, [sp, #0x580]
     b6c:      	str	q6, [sp, #0x570]
     b70:      	add	x7, sp, #0x570
     b74:      	ldr	s2, [x7, x6, lsl #2]
     b78:      	and	w1, w3, w1
     b7c:      	tst	w1, #0x1
     b80:      	fcsel	s18, s2, s22, ne
     b84:      	and	x6, x2, #0x7
     b88:      	add	x1, sp, #0x4c8
     b8c:      	bfxil	x1, x2, #0, #3
     b90:      	ldrb	w2, [x1]
     b94:      	umov.b	w1, v30[2]
     b98:      	and	w2, w1, w2
     b9c:      	str	q7, [sp, #0x560]
     ba0:      	str	q6, [sp, #0x550]
     ba4:      	add	x7, sp, #0x550
     ba8:      	ldr	s2, [x7, x6, lsl #2]
     bac:      	tst	w2, #0x1
     bb0:      	fcsel	s19, s2, s22, ne
     bb4:      	and	x6, x5, #0x7
     bb8:      	add	x2, sp, #0x4c8
     bbc:      	bfxil	x2, x5, #0, #3
     bc0:      	ldrb	w5, [x2]
     bc4:      	umov.b	w2, v30[3]
     bc8:      	and	w5, w2, w5
     bcc:      	str	q7, [sp, #0x540]
     bd0:      	str	q6, [sp, #0x530]
     bd4:      	add	x7, sp, #0x530
     bd8:      	ldr	s2, [x7, x6, lsl #2]
     bdc:      	tst	w5, #0x1
     be0:      	mov.s	w5, v20[1]
     be4:      	fcsel	s21, s2, s22, ne
     be8:      	mov.s	w6, v20[2]
     bec:      	mov.s	w7, v20[3]
     bf0:      	fmov	w19, s20
     bf4:      	and	x27, x19, #0x7
     bf8:      	add	x30, sp, #0x4c8
     bfc:      	bfxil	x30, x19, #0, #3
     c00:      	ldrb	w19, [x30]
     c04:      	umov.b	w30, v30[4]
     c08:      	and	w19, w30, w19
     c0c:      	str	q7, [sp, #0x620]
     c10:      	str	q6, [sp, #0x610]
     c14:      	add	x14, sp, #0x610
     c18:      	ldr	s2, [x14, x27, lsl #2]
     c1c:      	tst	w19, #0x1
     c20:      	fcsel	s2, s2, s22, ne
     c24:      	and	x19, x5, #0x7
     c28:      	add	x27, sp, #0x4c8
     c2c:      	bfxil	x27, x5, #0, #3
     c30:      	umov.b	w5, v30[5]
     c34:      	ldrb	w27, [x27]
     c38:      	and	w27, w5, w27
     c3c:      	str	q7, [sp, #0x600]
     c40:      	str	q6, [sp, #0x5f0]
     c44:      	add	x14, sp, #0x5f0
     c48:      	ldr	s4, [x14, x19, lsl #2]
     c4c:      	tst	w27, #0x1
     c50:      	fcsel	s4, s4, s22, ne
     c54:      	and	x19, x6, #0x7
     c58:      	add	x27, sp, #0x4c8
     c5c:      	bfxil	x27, x6, #0, #3
     c60:      	ldrb	w27, [x27]
     c64:      	umov.b	w6, v30[6]
     c68:      	str	q7, [sp, #0x5e0]
     c6c:      	str	q6, [sp, #0x5d0]
     c70:      	add	x14, sp, #0x5d0
     c74:      	ldr	s16, [x14, x19, lsl #2]
     c78:      	and	w19, w6, w27
     c7c:      	tst	w19, #0x1
     c80:      	fcsel	s16, s16, s22, ne
     c84:      	and	x19, x7, #0x7
     c88:      	add	x27, sp, #0x4c8
     c8c:      	bfxil	x27, x7, #0, #3
     c90:      	ldrb	w27, [x27]
     c94:      	umov.b	w7, v30[7]
     c98:      	and	w27, w7, w27
     c9c:      	str	q7, [sp, #0x5c0]
     ca0:      	str	q6, [sp, #0x5b0]
     ca4:      	add	x14, sp, #0x5b0
     ca8:      	ldr	s20, [x14, x19, lsl #2]
     cac:      	tst	w27, #0x1
     cb0:      	fcsel	s20, s20, s22, ne
     cb4:      	mov.s	v2[1], v4[0]
     cb8:      	mov.s	v2[2], v16[0]
     cbc:      	mov.s	v2[3], v20[0]
     cc0:      	mov.s	v17[1], v18[0]
     cc4:      	mov.s	v17[2], v19[0]
     cc8:      	mov.s	v17[3], v21[0]
     ccc:      	fadd.4s	v4, v6, v17
     cd0:      	fadd.4s	v2, v7, v2
     cd4:      	movi.4s	v6, #0x2
     cd8:      	eor.16b	v3, v3, v6
     cdc:      	eor.16b	v5, v5, v6
     ce0:      	fmov	w19, s5
     ce4:      	add	x27, sp, #0x4c8
     ce8:      	bfxil	x27, x19, #0, #3
     cec:      	ldrb	w27, [x27]
     cf0:      	and	x19, x19, #0x7
     cf4:      	str	q2, [sp, #0x520]
     cf8:      	str	q4, [sp, #0x510]
     cfc:      	add	x14, sp, #0x510
     d00:      	ldr	s5, [x14, x19, lsl #2]
     d04:      	tst	w4, w27
     d08:      	fcsel	s5, s5, s22, ne
     d0c:      	fmov	w4, s3
     d10:      	and	x19, x4, #0x7
     d14:      	add	x27, sp, #0x4c8
     d18:      	bfxil	x27, x4, #0, #3
     d1c:      	ldrb	w4, [x27]
     d20:      	and	w4, w30, w4
     d24:      	str	q2, [sp, #0x500]
     d28:      	str	q4, [sp, #0x4f0]
     d2c:      	add	x14, sp, #0x4f0
     d30:      	ldr	s3, [x14, x19, lsl #2]
     d34:      	tst	w4, #0x1
     d38:      	fcsel	s3, s3, s22, ne
     d3c:      	fadd.4s	v2, v2, v3
     d40:      	and	w4, w17, w30
     d44:      	tst	w4, #0x1
     d48:      	fcsel	s2, s2, s22, ne
     d4c:      	ands	w19, w17, #0x1
     d50:      	fadd.4s	v3, v4, v5
     d54:      	fadd	s2, s3, s2
     d58:      	fcsel	s3, s2, s22, ne
     d5c:      	tst	w4, #0x1
     d60:      	and	w14, w3, w17
     d64:      	fcsel	s4, s2, s22, ne
     d68:      	str	w14, [sp, #0xd0]
     d6c:      	tst	w14, #0x1
     d70:      	and	w14, w1, w17
     d74:      	fcsel	s5, s2, s22, ne
     d78:      	str	w14, [sp, #0xb0]
     d7c:      	tst	w14, #0x1
     d80:      	and	w14, w2, w17
     d84:      	fcsel	s6, s2, s22, ne
     d88:      	str	w14, [sp, #0xa0]
     d8c:      	tst	w14, #0x1
     d90:      	fcsel	s7, s2, s22, ne
     d94:      	and	w14, w5, w17
     d98:      	str	w14, [sp, #0x90]
     d9c:      	tst	w14, #0x1
     da0:      	fcsel	s16, s2, s22, ne
     da4:      	and	w14, w6, w17
     da8:      	str	w14, [sp, #0x7c]
     dac:      	tst	w14, #0x1
     db0:      	fcsel	s17, s2, s22, ne
     db4:      	and	w14, w7, w17
     db8:      	str	w14, [sp, #0x80]
     dbc:      	tst	w14, #0x1
     dc0:      	fcsel	s2, s2, s22, ne
     dc4:      	mov.s	v3[1], v5[0]
     dc8:      	mov.s	v3[2], v6[0]
     dcc:      	mov.s	v3[3], v7[0]
     dd0:      	mov.s	v4[1], v16[0]
     dd4:      	mov.s	v4[2], v17[0]
     dd8:      	mov.s	v4[3], v2[0]
     ddc:      	ldr	w14, [sp, #0xe0]
     de0:      	rbit	w27, w14
     de4:      	clz	w14, w27
     de8:      	str	q4, [sp, #0x4e0]
     dec:      	str	q3, [sp, #0x4d0]
     df0:      	str	x14, [sp, #0xc0]
     df4:      	and	x27, x14, #0x7
     df8:      	add	x14, sp, #0x4d0
     dfc:      	ldr	s2, [x14, x27, lsl #2]
     e00:      	str	q30, [sp, #0xe0]
     e04:      	mov.b	v30[0], wzr
     e08:      	str	q30, [sp, #0x60]
     e0c:      	fadd	s2, s2, s22
     e10:      	mov	w14, #0x800             ; =2048
     e14:      	movk	w14, #0x4580, lsl #16
     e18:      	fmov	s3, w14
     e1c:      	fdiv	s2, s2, s3
     e20:      	dup.4s	v3, v2[0]
     e24:      	mov	w14, #0x1               ; =1
     e28:      	dup.2d	v2, x14
     e2c:      	ushll2.2d	v4, v0, #0x0
     e30:      	and.16b	v18, v4, v2
     e34:      	ushll2.2d	v4, v1, #0x0
     e38:      	and.16b	v19, v4, v2
     e3c:      	ushll.2d	v4, v0, #0x0
     e40:      	and.16b	v20, v4, v2
     e44:      	ushll.2d	v4, v1, #0x0
     e48:      	and.16b	v21, v4, v2
     e4c:      	movi.2d	v5, #0000000000000000
     e50:      	movi.2d	v6, #0000000000000000
     e54:      	movi.2d	v7, #0000000000000000
     e58:      	movi.2d	v17, #0000000000000000
     e5c:      	lsl	x0, x0, #5
     e60:      	add	x27, x16, x0
     e64:      	ldp	q4, q2, [x27]
     e68:      	fsub.4s	v4, v4, v3
     e6c:      	fsub.4s	v2, v2, v3
     e70:      	add	x0, x10, x0
     e74:      	ldp	q16, q22, [x0]
     e78:      	bif.16b	v2, v22, v0
     e7c:      	bif.16b	v4, v16, v1
     e80:      	stp	q4, q2, [x0]
     e84:      	add.2d	v6, v6, v19
     e88:      	add.2d	v7, v7, v20
     e8c:      	add.2d	v17, v17, v18
     e90:      	add.2d	v5, v5, v21
     e94:      	fmov	x0, d5
     e98:      	cmp	x0, #0x200
     e9c:      	b.lt	0xe5c <_llm_rows.packet_batch.blocks+0xa14>
     ea0:      	ldr	x27, [sp, #0x158]
     ea4:      	add	x0, x16, x27
     ea8:      	ldp	q4, q2, [x0]
     eac:      	fsub.4s	v5, v4, v3
     eb0:      	fsub.4s	v6, v2, v3
     eb4:      	add	x0, x10, x27
     eb8:      	ldp	q2, q3, [x0]
     ebc:      	zip2.8b	v4, v27, v0
     ec0:      	ushll.4s	v4, v4, #0x0
     ec4:      	shl.4s	v4, v4, #0x1f
     ec8:      	cmlt.4s	v4, v4, #0
     ecc:      	stp	q6, q5, [sp, #0x40]
     ed0:      	bit.16b	v3, v6, v4
     ed4:      	zip1.8b	v4, v27, v0
     ed8:      	ushll.4s	v4, v4, #0x0
     edc:      	shl.4s	v4, v4, #0x1f
     ee0:      	cmlt.4s	v4, v4, #0
     ee4:      	bit.16b	v2, v5, v4
     ee8:      	stp	q2, q3, [x0]
     eec:      	ldr	q2, [x16, #0x4090]
     ef0:      	ldr	q3, [x16, #0x4080]
     ef4:      	fmul.4s	v3, v3, v3
     ef8:      	fmul.4s	v2, v2, v2
     efc:      	and.16b	v12, v0, v2
     f00:      	and.16b	v14, v1, v3
     f04:      	ldr	q2, [x16, #0x4070]
     f08:      	ldr	q3, [x16, #0x4060]
     f0c:      	fmul.4s	v3, v3, v3
     f10:      	fmul.4s	v2, v2, v2
     f14:      	and.16b	v5, v0, v2
     f18:      	and.16b	v17, v1, v3
     f1c:      	ldr	q2, [x16, #0x4050]
     f20:      	ldr	q3, [x16, #0x4040]
     f24:      	fmul.4s	v3, v3, v3
     f28:      	fmul.4s	v2, v2, v2
     f2c:      	and.16b	v6, v0, v2
     f30:      	and.16b	v7, v1, v3
     f34:      	ldr	x14, [sp, #0x70]
     f38:      	add	x14, x10, x14
     f3c:      	ldp	q3, q2, [x14]
     f40:      	fmul.4s	v3, v3, v3
     f44:      	fmul.4s	v2, v2, v2
     f48:      	and.16b	v23, v0, v2
     f4c:      	and.16b	v3, v1, v3
     f50:      	sshll.2d	v2, v1, #0x0
     f54:      	sshll.2d	v4, v0, #0x0
     f58:      	add	x11, x10, x11, lsl #5
     f5c:      	ldp	q22, q16, [x11]
     f60:      	and.16b	v22, v1, v22
     f64:      	and.16b	v16, v0, v16
     f68:      	fmul.4s	v16, v16, v16
     f6c:      	fmul.4s	v22, v22, v22
     f70:      	fadd.4s	v22, v3, v22
     f74:      	fadd.4s	v24, v23, v16
     f78:      	ldp	q30, q16, [x11, #0x20]
     f7c:      	and.16b	v30, v1, v30
     f80:      	and.16b	v16, v0, v16
     f84:      	fmul.4s	v16, v16, v16
     f88:      	fmul.4s	v30, v30, v30
     f8c:      	fadd.4s	v30, v7, v30
     f90:      	fadd.4s	v16, v6, v16
     f94:      	ldp	q9, q8, [x11, #0x40]
     f98:      	and.16b	v9, v1, v9
     f9c:      	and.16b	v8, v0, v8
     fa0:      	fmul.4s	v8, v8, v8
     fa4:      	fmul.4s	v9, v9, v9
     fa8:      	fadd.4s	v9, v17, v9
     fac:      	fadd.4s	v8, v5, v8
     fb0:      	ldp	q15, q13, [x11, #0x60]
     fb4:      	and.16b	v15, v1, v15
     fb8:      	and.16b	v13, v0, v13
     fbc:      	fmul.4s	v13, v13, v13
     fc0:      	fmul.4s	v15, v15, v15
     fc4:      	fadd.4s	v15, v14, v15
     fc8:      	fadd.4s	v13, v12, v13
     fcc:      	dup.2d	v11, x26
     fd0:      	and.16b	v27, v29, v11
     fd4:      	add.2d	v26, v26, v27
     fd8:      	and.16b	v27, v28, v11
     fdc:      	add.2d	v31, v31, v27
     fe0:      	and.16b	v4, v4, v11
     fe4:      	add.2d	v25, v25, v4
     fe8:      	and.16b	v2, v2, v11
     fec:      	add.2d	v10, v10, v2
     ff0:      	bit.16b	v23, v24, v0
     ff4:      	bit.16b	v3, v22, v1
     ff8:      	bit.16b	v6, v16, v0
     ffc:      	bit.16b	v7, v30, v1
    1000:      	bit.16b	v5, v8, v0
    1004:      	bit.16b	v17, v9, v1
    1008:      	bit.16b	v12, v13, v0
    100c:      	bit.16b	v14, v15, v1
    1010:      	fmov	x11, d10
    1014:      	cmp	x11, #0x200
    1018:      	b.lt	0xf50 <_llm_rows.packet_batch.blocks+0xb08>
    101c:      	mov	x11, #0x0               ; =0
    1020:      	movi.2d	v28, #0000000000000000
    1024:      	movi.2d	v29, #0000000000000000
    1028:      	movi.2d	v30, #0000000000000000
    102c:      	movi.2d	v31, #0000000000000000
    1030:      	ldr	q8, [sp, #0x1a0]
    1034:      	b	0x1068 <_llm_rows.packet_batch.blocks+0xc20>
    1038:      	add	x11, x9, x11
    103c:      	ldp	q2, q4, [x11]
    1040:      	bit.16b	v4, v10, v0
    1044:      	bit.16b	v2, v9, v1
    1048:      	stp	q2, q4, [x11]
    104c:      	add.2d	v29, v29, v19
    1050:      	add.2d	v30, v30, v20
    1054:      	add.2d	v31, v31, v18
    1058:      	add.2d	v28, v28, v21
    105c:      	fmov	x11, d28
    1060:      	cmp	x11, #0x200
    1064:      	b.ge	0x1104 <_llm_rows.packet_batch.blocks+0xcbc>
    1068:      	fmov	w16, s8
    106c:      	lsl	x11, x11, #5
    1070:      	add	x14, x15, x11
    1074:      	movi.2d	v9, #0000000000000000
    1078:      	movi.2d	v10, #0000000000000000
    107c:      	tbnz	w16, #0x0, 0x10a4 <_llm_rows.packet_batch.blocks+0xc5c>
    1080:      	and	w16, w16, #0xff
    1084:      	tbnz	w16, #0x1, 0x10b0 <_llm_rows.packet_batch.blocks+0xc68>
    1088:      	tbnz	w16, #0x2, 0x10bc <_llm_rows.packet_batch.blocks+0xc74>
    108c:      	tbnz	w16, #0x3, 0x10c8 <_llm_rows.packet_batch.blocks+0xc80>
    1090:      	tbnz	w16, #0x4, 0x10d4 <_llm_rows.packet_batch.blocks+0xc8c>
    1094:      	tbnz	w16, #0x5, 0x10e0 <_llm_rows.packet_batch.blocks+0xc98>
    1098:      	tbnz	w16, #0x6, 0x10ec <_llm_rows.packet_batch.blocks+0xca4>
    109c:      	tbz	w16, #0x7, 0x1038 <_llm_rows.packet_batch.blocks+0xbf0>
    10a0:      	b	0x10f8 <_llm_rows.packet_batch.blocks+0xcb0>
    10a4:      	ldr	s9, [x14]
    10a8:      	and	w16, w16, #0xff
    10ac:      	tbz	w16, #0x1, 0x1088 <_llm_rows.packet_batch.blocks+0xc40>
    10b0:      	add	x0, x14, #0x4
    10b4:      	ld1.s	{ v9 }[1], [x0]
    10b8:      	tbz	w16, #0x2, 0x108c <_llm_rows.packet_batch.blocks+0xc44>
    10bc:      	add	x0, x14, #0x8
    10c0:      	ld1.s	{ v9 }[2], [x0]
    10c4:      	tbz	w16, #0x3, 0x1090 <_llm_rows.packet_batch.blocks+0xc48>
    10c8:      	add	x0, x14, #0xc
    10cc:      	ld1.s	{ v9 }[3], [x0]
    10d0:      	tbz	w16, #0x4, 0x1094 <_llm_rows.packet_batch.blocks+0xc4c>
    10d4:      	add	x0, x14, #0x10
    10d8:      	ld1.s	{ v10 }[0], [x0]
    10dc:      	tbz	w16, #0x5, 0x1098 <_llm_rows.packet_batch.blocks+0xc50>
    10e0:      	add	x0, x14, #0x14
    10e4:      	ld1.s	{ v10 }[1], [x0]
    10e8:      	tbz	w16, #0x6, 0x109c <_llm_rows.packet_batch.blocks+0xc54>
    10ec:      	add	x0, x14, #0x18
    10f0:      	ld1.s	{ v10 }[2], [x0]
    10f4:      	tbz	w16, #0x7, 0x1038 <_llm_rows.packet_batch.blocks+0xbf0>
    10f8:      	add	x14, x14, #0x1c
    10fc:      	ld1.s	{ v10 }[3], [x14]
    1100:      	b	0x1038 <_llm_rows.packet_batch.blocks+0xbf0>
    1104:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xbb8>
    1108:      	ldr	q2, [x11]
    110c:      	and.16b	v29, v0, v2
    1110:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xbb8>
    1114:      	ldr	q2, [x11]
    1118:      	and.16b	v30, v1, v2
    111c:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xbb8>
    1120:      	ldr	q2, [x11]
    1124:      	and.16b	v28, v1, v2
    1128:      	ldr	q31, [sp, #0x1d0]
    112c:      	zip2.8b	v2, v31, v0
    1130:      	ushll.4s	v2, v2, #0x0
    1134:      	shl.4s	v2, v2, #0x1f
    1138:      	cmlt.4s	v2, v2, #0
    113c:      	ldp	q4, q25, [sp, #0x40]
    1140:      	and.16b	v4, v2, v4
    1144:      	zip1.8b	v16, v31, v0
    1148:      	ushll.4s	v16, v16, #0x0
    114c:      	shl.4s	v16, v16, #0x1f
    1150:      	cmlt.4s	v16, v16, #0
    1154:      	and.16b	v25, v16, v25
    1158:      	fmul.4s	v25, v25, v25
    115c:      	fmul.4s	v4, v4, v4
    1160:      	fadd.4s	v4, v4, v23
    1164:      	fadd.4s	v3, v25, v3
    1168:      	and.16b	v3, v16, v3
    116c:      	and.16b	v2, v2, v4
    1170:      	ldr	q16, [sp, #0x60]
    1174:      	zip2.8b	v4, v16, v0
    1178:      	ushll.4s	v4, v4, #0x0
    117c:      	shl.4s	v4, v4, #0x1f
    1180:      	cmlt.4s	v4, v4, #0
    1184:      	bit.16b	v2, v24, v4
    1188:      	zip1.8b	v4, v16, v0
    118c:      	ushll.4s	v4, v4, #0x0
    1190:      	shl.4s	v4, v4, #0x1f
    1194:      	cmlt.4s	v4, v4, #0
    1198:      	bit.16b	v3, v22, v4
    119c:      	fadd.4s	v3, v7, v3
    11a0:      	fadd.4s	v2, v6, v2
    11a4:      	fadd.4s	v2, v5, v2
    11a8:      	fadd.4s	v3, v17, v3
    11ac:      	fadd.4s	v3, v14, v3
    11b0:      	fadd.4s	v5, v12, v2
    11b4:      	fmov	w11, s30
    11b8:      	add	x14, sp, #0x238
    11bc:      	bfxil	x14, x11, #0, #3
    11c0:      	ldr	q2, [sp, #0xe0]
    11c4:      	str	d2, [sp, #0x238]
    11c8:      	ldrb	w14, [x14]
    11cc:      	add	x16, sp, #0x4a0
    11d0:      	orr	x11, x16, x11, lsl #2
    11d4:      	str	q5, [sp, #0x4b0]
    11d8:      	str	q3, [sp, #0x4a0]
    11dc:      	ldr	s2, [x11]
    11e0:      	tst	w19, w14
    11e4:      	movi	d25, #0000000000000000
    11e8:      	fcsel	s6, s2, s25, ne
    11ec:      	mov.s	w11, v30[1]
    11f0:      	add	x14, sp, #0x238
    11f4:      	bfxil	x14, x11, #0, #3
    11f8:      	ldrb	w11, [x14]
    11fc:      	and	w11, w3, w11
    1200:      	str	q3, [sp, #0x480]
    1204:      	ldr	s2, [sp, #0x480]
    1208:      	tst	w11, #0x1
    120c:      	fcsel	s7, s2, s25, ne
    1210:      	mov.s	w11, v30[2]
    1214:      	add	x14, sp, #0x238
    1218:      	bfxil	x14, x11, #0, #3
    121c:      	add	x16, sp, #0x460
    1220:      	orr	x11, x16, x11, lsl #2
    1224:      	ldrb	w14, [x14]
    1228:      	and	w14, w1, w14
    122c:      	str	q5, [sp, #0x470]
    1230:      	str	q3, [sp, #0x460]
    1234:      	ldr	s2, [x11]
    1238:      	tst	w14, #0x1
    123c:      	fcsel	s17, s2, s25, ne
    1240:      	mov.s	w11, v30[3]
    1244:      	add	x14, sp, #0x238
    1248:      	bfxil	x14, x11, #0, #3
    124c:      	add	x16, sp, #0x440
    1250:      	orr	x11, x16, x11, lsl #2
    1254:      	ldrb	w14, [x14]
    1258:      	and	w14, w2, w14
    125c:      	str	q5, [sp, #0x450]
    1260:      	str	q3, [sp, #0x440]
    1264:      	ldr	s2, [x11]
    1268:      	tst	w14, #0x1
    126c:      	fcsel	s22, s2, s25, ne
    1270:      	fmov	w11, s29
    1274:      	add	x14, sp, #0x238
    1278:      	bfxil	x14, x11, #0, #3
    127c:      	ldrb	w14, [x14]
    1280:      	and	w14, w30, w14
    1284:      	str	q5, [sp, #0x430]
    1288:      	str	q3, [sp, #0x420]
    128c:      	add	x16, sp, #0x420
    1290:      	ldr	s2, [x16, w11, uxtw #2]
    1294:      	tst	w14, #0x1
    1298:      	fcsel	s2, s2, s25, ne
    129c:      	mov.s	w11, v29[1]
    12a0:      	add	x14, sp, #0x238
    12a4:      	bfxil	x14, x11, #0, #3
    12a8:      	ldrb	w14, [x14]
    12ac:      	and	w14, w5, w14
    12b0:      	str	q5, [sp, #0x410]
    12b4:      	str	q3, [sp, #0x400]
    12b8:      	add	x16, sp, #0x400
    12bc:      	ldr	s4, [x16, w11, uxtw #2]
    12c0:      	tst	w14, #0x1
    12c4:      	fcsel	s4, s4, s25, ne
    12c8:      	mov.s	w11, v29[2]
    12cc:      	add	x14, sp, #0x238
    12d0:      	bfxil	x14, x11, #0, #3
    12d4:      	ldrb	w14, [x14]
    12d8:      	and	w14, w6, w14
    12dc:      	stp	q3, q5, [sp, #0x3e0]
    12e0:      	add	x16, sp, #0x3e0
    12e4:      	ldr	s16, [x16, w11, uxtw #2]
    12e8:      	tst	w14, #0x1
    12ec:      	fcsel	s16, s16, s25, ne
    12f0:      	mov.s	w11, v29[3]
    12f4:      	add	x14, sp, #0x238
    12f8:      	bfxil	x14, x11, #0, #3
    12fc:      	ldrb	w14, [x14]
    1300:      	and	w14, w7, w14
    1304:      	stp	q3, q5, [sp, #0x3c0]
    1308:      	add	x16, sp, #0x3c0
    130c:      	ldr	s23, [x16, w11, uxtw #2]
    1310:      	tst	w14, #0x1
    1314:      	fcsel	s23, s23, s25, ne
    1318:      	mov.s	v2[1], v4[0]
    131c:      	mov.s	v2[2], v16[0]
    1320:      	mov.s	v2[3], v23[0]
    1324:      	mov.s	v6[1], v7[0]
    1328:      	mov.s	v6[2], v17[0]
    132c:      	mov.s	v6[3], v22[0]
    1330:      	fadd.4s	v3, v3, v6
    1334:      	fadd.4s	v5, v5, v2
    1338:      	fmov	w11, s28
    133c:      	add	x14, sp, #0x238
    1340:      	bfxil	x14, x11, #0, #3
    1344:      	ldrb	w14, [x14]
    1348:      	add	x16, sp, #0x3a0
    134c:      	orr	x11, x16, x11, lsl #2
    1350:      	stp	q3, q5, [sp, #0x3a0]
    1354:      	ldr	s2, [x11]
    1358:      	mov.s	w11, v28[1]
    135c:      	tst	w19, w14
    1360:      	add	x14, sp, #0x238
    1364:      	bfxil	x14, x11, #0, #3
    1368:      	ldrb	w14, [x14]
    136c:      	and	w14, w3, w14
    1370:      	fcsel	s6, s2, s25, ne
    1374:      	add	x16, sp, #0x380
    1378:      	orr	x11, x16, x11, lsl #2
    137c:      	stp	q3, q5, [sp, #0x380]
    1380:      	ldr	s2, [x11]
    1384:      	mov.s	w11, v28[2]
    1388:      	tst	w14, #0x1
    138c:      	add	x14, sp, #0x238
    1390:      	bfxil	x14, x11, #0, #3
    1394:      	fcsel	s7, s2, s25, ne
    1398:      	ldrb	w11, [x14]
    139c:      	and	w11, w1, w11
    13a0:      	str	q3, [sp, #0x360]
    13a4:      	tst	w11, #0x1
    13a8:      	mov.s	w11, v28[3]
    13ac:      	add	x14, sp, #0x238
    13b0:      	bfxil	x14, x11, #0, #3
    13b4:      	ldrb	w14, [x14]
    13b8:      	and	w14, w2, w14
    13bc:      	adrp	x16, 0x1000 <_llm_rows.packet_batch.blocks+0xbb8>
    13c0:      	ldr	q2, [x16]
    13c4:      	and.16b	v2, v0, v2
    13c8:      	ldr	s4, [sp, #0x360]
    13cc:      	fcsel	s17, s4, s25, ne
    13d0:      	add	x16, sp, #0x340
    13d4:      	orr	x11, x16, x11, lsl #2
    13d8:      	stp	q3, q5, [sp, #0x340]
    13dc:      	ldr	s4, [x11]
    13e0:      	tst	w14, #0x1
    13e4:      	fmov	w11, s2
    13e8:      	add	x14, sp, #0x238
    13ec:      	bfxil	x14, x11, #0, #3
    13f0:      	ldrb	w14, [x14]
    13f4:      	and	w14, w30, w14
    13f8:      	fcsel	s22, s4, s25, ne
    13fc:      	stp	q3, q5, [sp, #0x320]
    1400:      	add	x16, sp, #0x320
    1404:      	ldr	s4, [x16, w11, uxtw #2]
    1408:      	tst	w14, #0x1
    140c:      	mov.s	w11, v2[1]
    1410:      	add	x14, sp, #0x238
    1414:      	bfxil	x14, x11, #0, #3
    1418:      	ldrb	w14, [x14]
    141c:      	and	w14, w5, w14
    1420:      	fcsel	s23, s4, s25, ne
    1424:      	stp	q3, q5, [sp, #0x300]
    1428:      	add	x16, sp, #0x300
    142c:      	ldr	s4, [x16, w11, uxtw #2]
    1430:      	tst	w14, #0x1
    1434:      	mov.s	w11, v2[2]
    1438:      	add	x14, sp, #0x238
    143c:      	bfxil	x14, x11, #0, #3
    1440:      	ldrb	w14, [x14]
    1444:      	and	w14, w6, w14
    1448:      	fcsel	s4, s4, s25, ne
    144c:      	stp	q3, q5, [sp, #0x2e0]
    1450:      	add	x16, sp, #0x2e0
    1454:      	ldr	s16, [x16, w11, uxtw #2]
    1458:      	tst	w14, #0x1
    145c:      	mov.s	w11, v2[3]
    1460:      	add	x14, sp, #0x238
    1464:      	bfxil	x14, x11, #0, #3
    1468:      	ldrb	w14, [x14]
    146c:      	and	w14, w7, w14
    1470:      	movi.4s	v2, #0x4
    1474:      	and.16b	v2, v1, v2
    1478:      	fcsel	s16, s16, s25, ne
    147c:      	stp	q3, q5, [sp, #0x2c0]
    1480:      	add	x16, sp, #0x2c0
    1484:      	ldr	s24, [x16, w11, uxtw #2]
    1488:      	tst	w14, #0x1
    148c:      	fcsel	s24, s24, s25, ne
    1490:      	fmov	w11, s2
    1494:      	add	x14, sp, #0x238
    1498:      	orr	x14, x14, x11
    149c:      	ldrb	w14, [x14]
    14a0:      	tst	w19, w14
    14a4:      	mov.s	v23[1], v4[0]
    14a8:      	mov.s	v23[2], v16[0]
    14ac:      	mov.s	v23[3], v24[0]
    14b0:      	mov.s	v6[1], v7[0]
    14b4:      	mov.s	v6[2], v17[0]
    14b8:      	mov.s	v6[3], v22[0]
    14bc:      	fadd.4s	v2, v3, v6
    14c0:      	fadd.4s	v3, v5, v23
    14c4:      	stp	q2, q3, [sp, #0x2a0]
    14c8:      	add	x14, sp, #0x2a0
    14cc:      	ldr	s3, [x14, w11, uxtw #2]
    14d0:      	fcsel	s3, s3, s25, ne
    14d4:      	tst	w17, #0x1
    14d8:      	fadd	s2, s2, s3
    14dc:      	fcsel	s3, s2, s25, ne
    14e0:      	ldr	w11, [sp, #0xd0]
    14e4:      	tst	w11, #0x1
    14e8:      	fcsel	s4, s2, s25, ne
    14ec:      	ldr	w11, [sp, #0xb0]
    14f0:      	tst	w11, #0x1
    14f4:      	fcsel	s5, s2, s25, ne
    14f8:      	ldr	w11, [sp, #0xa0]
    14fc:      	tst	w11, #0x1
    1500:      	fcsel	s6, s2, s25, ne
    1504:      	tst	w4, #0x1
    1508:      	fcsel	s7, s2, s25, ne
    150c:      	ldr	w11, [sp, #0x90]
    1510:      	tst	w11, #0x1
    1514:      	fcsel	s16, s2, s25, ne
    1518:      	ldr	w11, [sp, #0x7c]
    151c:      	tst	w11, #0x1
    1520:      	shl.8b	v17, v31, #0x7
    1524:      	cmlt.8b	v17, v17, #0
    1528:      	fcsel	s22, s2, s25, ne
    152c:      	ldr	w11, [sp, #0x80]
    1530:      	tst	w11, #0x1
    1534:      	movi	d24, #0000000000000000
    1538:      	fcsel	s2, s2, s25, ne
    153c:      	mov.s	v3[1], v4[0]
    1540:      	mov.s	v3[2], v5[0]
    1544:      	mov.s	v3[3], v6[0]
    1548:      	mov.s	v7[1], v16[0]
    154c:      	mov.s	v7[2], v22[0]
    1550:      	mov.s	v7[3], v2[0]
    1554:      	ldr	d2, [sp, #0x128]
    1558:      	and.8b	v2, v17, v2
    155c:      	stp	q3, q7, [sp, #0x280]
    1560:      	ldr	x11, [sp, #0xc0]
    1564:      	and	x11, x11, #0x7
    1568:      	add	x14, sp, #0x280
    156c:      	ldr	s3, [x14, x11, lsl #2]
    1570:      	addv.8b	b23, v2
    1574:      	mov	b2, v31[0]
    1578:      	mov.b	v2[4], v31[1]
    157c:      	ushll.2d	v2, v2, #0x0
    1580:      	shl.2d	v2, v2, #0x3f
    1584:      	cmlt.2d	v2, v2, #0
    1588:      	ldr	q4, [sp, #0x130]
    158c:      	and.16b	v2, v2, v4
    1590:      	mov	b4, v31[2]
    1594:      	mov.b	v4[4], v31[3]
    1598:      	ushll.2d	v4, v4, #0x0
    159c:      	shl.2d	v4, v4, #0x3f
    15a0:      	cmlt.2d	v4, v4, #0
    15a4:      	ldp	q5, q7, [sp, #0xf0]
    15a8:      	and.16b	v4, v4, v5
    15ac:      	mov	b5, v31[4]
    15b0:      	mov.b	v5[4], v31[5]
    15b4:      	ushll.2d	v5, v5, #0x0
    15b8:      	shl.2d	v5, v5, #0x3f
    15bc:      	cmlt.2d	v5, v5, #0
    15c0:      	mov	b6, v31[6]
    15c4:      	mov.b	v6[4], v31[7]
    15c8:      	and.16b	v5, v5, v7
    15cc:      	ushll.2d	v6, v6, #0x0
    15d0:      	shl.2d	v6, v6, #0x3f
    15d4:      	cmlt.2d	v6, v6, #0
    15d8:      	ldr	q7, [sp, #0x110]
    15dc:      	and.16b	v6, v6, v7
    15e0:      	stp	q5, q6, [sp, #0x260]
    15e4:      	stp	q2, q4, [sp, #0x240]
    15e8:      	ldr	x0, [sp, #0x1b0]
    15ec:      	and	x11, x0, #0x7
    15f0:      	add	x14, sp, #0x240
    15f4:      	ldr	x11, [x14, x11, lsl #3]
    15f8:      	fmov	w14, s23
    15fc:      	sub	x11, x11, x0
    1600:      	lsl	x11, x11, #2
    1604:      	add	x15, x15, x11
    1608:      	movi.2d	v5, #0000000000000000
    160c:      	movi.2d	v6, #0000000000000000
    1610:      	tbnz	w14, #0x0, 0x1a58 <_llm_rows.packet_batch.blocks+0x1610>
    1614:      	ldr	q16, [sp, #0x1c0]
    1618:      	tbnz	w14, #0x1, 0x1a64 <_llm_rows.packet_batch.blocks+0x161c>
    161c:      	tbnz	w14, #0x2, 0x1a70 <_llm_rows.packet_batch.blocks+0x1628>
    1620:      	tbnz	w14, #0x3, 0x1a7c <_llm_rows.packet_batch.blocks+0x1634>
    1624:      	tbnz	w14, #0x4, 0x1a88 <_llm_rows.packet_batch.blocks+0x1640>
    1628:      	tbnz	w14, #0x5, 0x1a94 <_llm_rows.packet_batch.blocks+0x164c>
    162c:      	tbnz	w14, #0x6, 0x1aa0 <_llm_rows.packet_batch.blocks+0x1658>
    1630:      	tbz	w14, #0x7, 0x163c <_llm_rows.packet_batch.blocks+0x11f4>
    1634:      	add	x14, x15, #0x1c
    1638:      	ld1.s	{ v6 }[3], [x14]
    163c:      	fadd	s2, s3, s24
    1640:      	mov	w14, #0x800             ; =2048
    1644:      	movk	w14, #0x4580, lsl #16
    1648:      	fmov	s3, w14
    164c:      	fdiv	s2, s2, s3
    1650:      	add	x14, x9, x27
    1654:      	ldp	q3, q4, [x14]
    1658:      	zip2.8b	v7, v31, v0
    165c:      	ushll.4s	v7, v7, #0x0
    1660:      	shl.4s	v7, v7, #0x1f
    1664:      	cmlt.4s	v7, v7, #0
    1668:      	bit.16b	v4, v6, v7
    166c:      	zip1.8b	v6, v31, v0
    1670:      	ushll.4s	v6, v6, #0x0
    1674:      	shl.4s	v6, v6, #0x1f
    1678:      	cmlt.4s	v6, v6, #0
    167c:      	bit.16b	v3, v5, v6
    1680:      	stp	q3, q4, [x14]
    1684:      	mov	w14, #0xc5ac            ; =50604
    1688:      	movk	w14, #0x3727, lsl #16
    168c:      	fmov	s3, w14
    1690:      	fadd	s2, s2, s3
    1694:      	fsqrt	s22, s2
    1698:      	subs	x14, x8, x13
    169c:      	mov	w15, #0x4003            ; =16387
    16a0:      	ccmp	x14, x15, #0x0, hs
    16a4:      	cset	w14, hi
    16a8:      	sub	x15, x13, x8
    16ac:      	mov	w16, #0xfff             ; =4095
    16b0:      	movk	w16, #0x100, lsl #16
    16b4:      	cmp	x15, x16
    16b8:      	ccmp	x13, x8, #0x0, hi
    16bc:      	b.hs	0x17a8 <_llm_rows.packet_batch.blocks+0x1360>
    16c0:      	tbnz	w14, #0x0, 0x17a8 <_llm_rows.packet_batch.blocks+0x1360>
    16c4:      	mov	x14, #0x0               ; =0
    16c8:      	movi.2d	v3, #0000000000000000
    16cc:      	movi.2d	v5, #0000000000000000
    16d0:      	movi.2d	v6, #0000000000000000
    16d4:      	movi.2d	v7, #0000000000000000
    16d8:      	b	0x170c <_llm_rows.packet_batch.blocks+0x12c4>
    16dc:      	add	x14, x12, x14
    16e0:      	ldp	q2, q4, [x14]
    16e4:      	bit.16b	v4, v17, v0
    16e8:      	bit.16b	v2, v16, v1
    16ec:      	stp	q2, q4, [x14]
    16f0:      	add.2d	v5, v5, v19
    16f4:      	add.2d	v6, v6, v20
    16f8:      	add.2d	v7, v7, v18
    16fc:      	add.2d	v3, v3, v21
    1700:      	fmov	x14, d3
    1704:      	cmp	x14, #0x200
    1708:      	b.ge	0x1ab0 <_llm_rows.packet_batch.blocks+0x1668>
    170c:      	fmov	w16, s8
    1710:      	lsl	x14, x14, #5
    1714:      	add	x15, x13, x14
    1718:      	movi.2d	v16, #0000000000000000
    171c:      	movi.2d	v17, #0000000000000000
    1720:      	tbnz	w16, #0x0, 0x1748 <_llm_rows.packet_batch.blocks+0x1300>
    1724:      	and	w16, w16, #0xff
    1728:      	tbnz	w16, #0x1, 0x1754 <_llm_rows.packet_batch.blocks+0x130c>
    172c:      	tbnz	w16, #0x2, 0x1760 <_llm_rows.packet_batch.blocks+0x1318>
    1730:      	tbnz	w16, #0x3, 0x176c <_llm_rows.packet_batch.blocks+0x1324>
    1734:      	tbnz	w16, #0x4, 0x1778 <_llm_rows.packet_batch.blocks+0x1330>
    1738:      	tbnz	w16, #0x5, 0x1784 <_llm_rows.packet_batch.blocks+0x133c>
    173c:      	tbnz	w16, #0x6, 0x1790 <_llm_rows.packet_batch.blocks+0x1348>
    1740:      	tbz	w16, #0x7, 0x16dc <_llm_rows.packet_batch.blocks+0x1294>
    1744:      	b	0x179c <_llm_rows.packet_batch.blocks+0x1354>
    1748:      	ldr	s16, [x15]
    174c:      	and	w16, w16, #0xff
    1750:      	tbz	w16, #0x1, 0x172c <_llm_rows.packet_batch.blocks+0x12e4>
    1754:      	add	x17, x15, #0x4
    1758:      	ld1.s	{ v16 }[1], [x17]
    175c:      	tbz	w16, #0x2, 0x1730 <_llm_rows.packet_batch.blocks+0x12e8>
    1760:      	add	x17, x15, #0x8
    1764:      	ld1.s	{ v16 }[2], [x17]
    1768:      	tbz	w16, #0x3, 0x1734 <_llm_rows.packet_batch.blocks+0x12ec>
    176c:      	add	x17, x15, #0xc
    1770:      	ld1.s	{ v16 }[3], [x17]
    1774:      	tbz	w16, #0x4, 0x1738 <_llm_rows.packet_batch.blocks+0x12f0>
    1778:      	add	x17, x15, #0x10
    177c:      	ld1.s	{ v17 }[0], [x17]
    1780:      	tbz	w16, #0x5, 0x173c <_llm_rows.packet_batch.blocks+0x12f4>
    1784:      	add	x17, x15, #0x14
    1788:      	ld1.s	{ v17 }[1], [x17]
    178c:      	tbz	w16, #0x6, 0x1740 <_llm_rows.packet_batch.blocks+0x12f8>
    1790:      	add	x17, x15, #0x18
    1794:      	ld1.s	{ v17 }[2], [x17]
    1798:      	tbz	w16, #0x7, 0x16dc <_llm_rows.packet_batch.blocks+0x1294>
    179c:      	add	x15, x15, #0x1c
    17a0:      	ld1.s	{ v17 }[3], [x15]
    17a4:      	b	0x16dc <_llm_rows.packet_batch.blocks+0x1294>
    17a8:      	mov	x12, #0x0               ; =0
    17ac:      	ldr	q2, [sp, #0x140]
    17b0:      	add.2d	v3, v2, v16
    17b4:      	dup.4s	v17, v22[0]
    17b8:      	movi.2d	v5, #0000000000000000
    17bc:      	movi.2d	v6, #0000000000000000
    17c0:      	movi.2d	v7, #0000000000000000
    17c4:      	movi.2d	v22, #0000000000000000
    17c8:      	b	0x17e8 <_llm_rows.packet_batch.blocks+0x13a0>
    17cc:      	add.2d	v6, v6, v19
    17d0:      	add.2d	v7, v7, v20
    17d4:      	add.2d	v22, v22, v18
    17d8:      	add.2d	v5, v5, v21
    17dc:      	fmov	x12, d5
    17e0:      	cmp	x12, #0x200
    17e4:      	b.ge	0x196c <_llm_rows.packet_batch.blocks+0x1524>
    17e8:      	fmov	w15, s8
    17ec:      	shl.2d	v25, v5, #0x3
    17f0:      	orr.16b	v2, v25, v16
    17f4:      	fmov	x14, d2
    17f8:      	add	x14, x13, x14, lsl #2
    17fc:      	movi.2d	v26, #0000000000000000
    1800:      	movi.2d	v24, #0000000000000000
    1804:      	tbnz	w15, #0x0, 0x18a4 <_llm_rows.packet_batch.blocks+0x145c>
    1808:      	and	w15, w15, #0xff
    180c:      	tbnz	w15, #0x1, 0x18b0 <_llm_rows.packet_batch.blocks+0x1468>
    1810:      	tbnz	w15, #0x2, 0x18bc <_llm_rows.packet_batch.blocks+0x1474>
    1814:      	tbnz	w15, #0x3, 0x18c8 <_llm_rows.packet_batch.blocks+0x1480>
    1818:      	tbnz	w15, #0x4, 0x18d4 <_llm_rows.packet_batch.blocks+0x148c>
    181c:      	tbnz	w15, #0x5, 0x18e0 <_llm_rows.packet_batch.blocks+0x1498>
    1820:      	tbnz	w15, #0x6, 0x18ec <_llm_rows.packet_batch.blocks+0x14a4>
    1824:      	tbz	w15, #0x7, 0x1830 <_llm_rows.packet_batch.blocks+0x13e8>
    1828:      	add	x14, x14, #0x1c
    182c:      	ld1.s	{ v24 }[3], [x14]
    1830:      	lsl	x12, x12, #5
    1834:      	add	x14, x10, x12
    1838:      	ldp	q2, q27, [x14]
    183c:      	and.16b	v2, v1, v2
    1840:      	fdiv.4s	v2, v2, v17
    1844:      	add	x12, x9, x12
    1848:      	ldp	q4, q28, [x12]
    184c:      	and.16b	v4, v1, v4
    1850:      	fmul.4s	v2, v2, v4
    1854:      	fmov	w14, s8
    1858:      	fadd.4s	v26, v26, v2
    185c:      	add.2d	v2, v3, v25
    1860:      	fmov	x12, d2
    1864:      	add	x12, x8, x12, lsl #2
    1868:      	tbnz	w14, #0x0, 0x18fc <_llm_rows.packet_batch.blocks+0x14b4>
    186c:      	and	w14, w14, #0xff
    1870:      	tbnz	w14, #0x1, 0x1908 <_llm_rows.packet_batch.blocks+0x14c0>
    1874:      	tbnz	w14, #0x2, 0x1914 <_llm_rows.packet_batch.blocks+0x14cc>
    1878:      	tbnz	w14, #0x3, 0x1920 <_llm_rows.packet_batch.blocks+0x14d8>
    187c:      	and.16b	v2, v0, v27
    1880:      	fdiv.4s	v2, v2, v17
    1884:      	and.16b	v4, v0, v28
    1888:      	fmul.4s	v2, v2, v4
    188c:      	fadd.4s	v24, v24, v2
    1890:      	tbnz	w14, #0x4, 0x1940 <_llm_rows.packet_batch.blocks+0x14f8>
    1894:      	tbnz	w14, #0x5, 0x1948 <_llm_rows.packet_batch.blocks+0x1500>
    1898:      	tbnz	w14, #0x6, 0x1954 <_llm_rows.packet_batch.blocks+0x150c>
    189c:      	tbz	w14, #0x7, 0x17cc <_llm_rows.packet_batch.blocks+0x1384>
    18a0:      	b	0x1960 <_llm_rows.packet_batch.blocks+0x1518>
    18a4:      	ldr	s26, [x14]
    18a8:      	and	w15, w15, #0xff
    18ac:      	tbz	w15, #0x1, 0x1810 <_llm_rows.packet_batch.blocks+0x13c8>
    18b0:      	add	x16, x14, #0x4
    18b4:      	ld1.s	{ v26 }[1], [x16]
    18b8:      	tbz	w15, #0x2, 0x1814 <_llm_rows.packet_batch.blocks+0x13cc>
    18bc:      	add	x16, x14, #0x8
    18c0:      	ld1.s	{ v26 }[2], [x16]
    18c4:      	tbz	w15, #0x3, 0x1818 <_llm_rows.packet_batch.blocks+0x13d0>
    18c8:      	add	x16, x14, #0xc
    18cc:      	ld1.s	{ v26 }[3], [x16]
    18d0:      	tbz	w15, #0x4, 0x181c <_llm_rows.packet_batch.blocks+0x13d4>
    18d4:      	add	x16, x14, #0x10
    18d8:      	ld1.s	{ v24 }[0], [x16]
    18dc:      	tbz	w15, #0x5, 0x1820 <_llm_rows.packet_batch.blocks+0x13d8>
    18e0:      	add	x16, x14, #0x14
    18e4:      	ld1.s	{ v24 }[1], [x16]
    18e8:      	tbz	w15, #0x6, 0x1824 <_llm_rows.packet_batch.blocks+0x13dc>
    18ec:      	add	x16, x14, #0x18
    18f0:      	ld1.s	{ v24 }[2], [x16]
    18f4:      	tbnz	w15, #0x7, 0x1828 <_llm_rows.packet_batch.blocks+0x13e0>
    18f8:      	b	0x1830 <_llm_rows.packet_batch.blocks+0x13e8>
    18fc:      	str	s26, [x12]
    1900:      	and	w14, w14, #0xff
    1904:      	tbz	w14, #0x1, 0x1874 <_llm_rows.packet_batch.blocks+0x142c>
    1908:      	add	x15, x12, #0x4
    190c:      	st1.s	{ v26 }[1], [x15]
    1910:      	tbz	w14, #0x2, 0x1878 <_llm_rows.packet_batch.blocks+0x1430>
    1914:      	add	x15, x12, #0x8
    1918:      	st1.s	{ v26 }[2], [x15]
    191c:      	tbz	w14, #0x3, 0x187c <_llm_rows.packet_batch.blocks+0x1434>
    1920:      	add	x15, x12, #0xc
    1924:      	st1.s	{ v26 }[3], [x15]
    1928:      	and.16b	v2, v0, v27
    192c:      	fdiv.4s	v2, v2, v17
    1930:      	and.16b	v4, v0, v28
    1934:      	fmul.4s	v2, v2, v4
    1938:      	fadd.4s	v24, v24, v2
    193c:      	tbz	w14, #0x4, 0x1894 <_llm_rows.packet_batch.blocks+0x144c>
    1940:      	str	s24, [x12, #0x10]
    1944:      	tbz	w14, #0x5, 0x1898 <_llm_rows.packet_batch.blocks+0x1450>
    1948:      	add	x15, x12, #0x14
    194c:      	st1.s	{ v24 }[1], [x15]
    1950:      	tbz	w14, #0x6, 0x189c <_llm_rows.packet_batch.blocks+0x1454>
    1954:      	add	x15, x12, #0x18
    1958:      	st1.s	{ v24 }[2], [x15]
    195c:      	tbz	w14, #0x7, 0x17cc <_llm_rows.packet_batch.blocks+0x1384>
    1960:      	add	x12, x12, #0x1c
    1964:      	st1.s	{ v24 }[3], [x12]
    1968:      	b	0x17cc <_llm_rows.packet_batch.blocks+0x1384>
    196c:      	add	x10, x10, x27
    1970:      	ldp	q0, q5, [x10]
    1974:      	fmov	w10, s23
    1978:      	add	x9, x9, x27
    197c:      	ldp	q2, q1, [x9]
    1980:      	add	x9, x13, x11
    1984:      	movi.2d	v3, #0000000000000000
    1988:      	movi.2d	v6, #0000000000000000
    198c:      	tbnz	w10, #0x0, 0x1d44 <_llm_rows.packet_batch.blocks+0x18fc>
    1990:      	tbnz	w10, #0x1, 0x1d4c <_llm_rows.packet_batch.blocks+0x1904>
    1994:      	tbnz	w10, #0x2, 0x1d58 <_llm_rows.packet_batch.blocks+0x1910>
    1998:      	tbnz	w10, #0x3, 0x1d64 <_llm_rows.packet_batch.blocks+0x191c>
    199c:      	tbnz	w10, #0x4, 0x1d70 <_llm_rows.packet_batch.blocks+0x1928>
    19a0:      	tbnz	w10, #0x5, 0x1d7c <_llm_rows.packet_batch.blocks+0x1934>
    19a4:      	tbnz	w10, #0x6, 0x1d88 <_llm_rows.packet_batch.blocks+0x1940>
    19a8:      	tbz	w10, #0x7, 0x19b4 <_llm_rows.packet_batch.blocks+0x156c>
    19ac:      	add	x9, x9, #0x1c
    19b0:      	ld1.s	{ v6 }[3], [x9]
    19b4:      	zip2.8b	v4, v31, v0
    19b8:      	ushll.4s	v4, v4, #0x0
    19bc:      	shl.4s	v4, v4, #0x1f
    19c0:      	cmlt.4s	v4, v4, #0
    19c4:      	and.16b	v5, v4, v5
    19c8:      	zip1.8b	v7, v31, v0
    19cc:      	ushll.4s	v7, v7, #0x0
    19d0:      	shl.4s	v7, v7, #0x1f
    19d4:      	cmlt.4s	v7, v7, #0
    19d8:      	and.16b	v0, v7, v0
    19dc:      	fdiv.4s	v0, v0, v17
    19e0:      	fdiv.4s	v5, v5, v17
    19e4:      	and.16b	v2, v7, v2
    19e8:      	and.16b	v1, v4, v1
    19ec:      	fmul.4s	v4, v5, v1
    19f0:      	fmul.4s	v0, v0, v2
    19f4:      	fadd.4s	v1, v3, v0
    19f8:      	fadd.4s	v0, v6, v4
    19fc:      	b	0x1ca0 <_llm_rows.packet_batch.blocks+0x1858>
    1a00:      	ldr	s19, [x11]
    1a04:      	tbz	w14, #0x1, 0x814 <_llm_rows.packet_batch.blocks+0x3cc>
    1a08:      	add	x17, x11, #0x4
    1a0c:      	ld1.s	{ v19 }[1], [x17]
    1a10:      	tbz	w14, #0x2, 0x818 <_llm_rows.packet_batch.blocks+0x3d0>
    1a14:      	add	x17, x11, #0x8
    1a18:      	ld1.s	{ v19 }[2], [x17]
    1a1c:      	tbz	w14, #0x3, 0x81c <_llm_rows.packet_batch.blocks+0x3d4>
    1a20:      	add	x17, x11, #0xc
    1a24:      	ld1.s	{ v19 }[3], [x17]
    1a28:      	tbz	w14, #0x4, 0x820 <_llm_rows.packet_batch.blocks+0x3d8>
    1a2c:      	add	x17, x11, #0x10
    1a30:      	ld1.s	{ v8 }[0], [x17]
    1a34:      	tbz	w14, #0x5, 0x824 <_llm_rows.packet_batch.blocks+0x3dc>
    1a38:      	add	x17, x11, #0x14
    1a3c:      	ld1.s	{ v8 }[1], [x17]
    1a40:      	tbz	w14, #0x6, 0x828 <_llm_rows.packet_batch.blocks+0x3e0>
    1a44:      	add	x17, x11, #0x18
    1a48:      	ld1.s	{ v8 }[2], [x17]
    1a4c:      	str	q18, [sp, #0x1a0]
    1a50:      	tbnz	w14, #0x7, 0x830 <_llm_rows.packet_batch.blocks+0x3e8>
    1a54:      	b	0x838 <_llm_rows.packet_batch.blocks+0x3f0>
    1a58:      	ldr	s5, [x15]
    1a5c:      	ldr	q16, [sp, #0x1c0]
    1a60:      	tbz	w14, #0x1, 0x161c <_llm_rows.packet_batch.blocks+0x11d4>
    1a64:      	add	x16, x15, #0x4
    1a68:      	ld1.s	{ v5 }[1], [x16]
    1a6c:      	tbz	w14, #0x2, 0x1620 <_llm_rows.packet_batch.blocks+0x11d8>
    1a70:      	add	x16, x15, #0x8
    1a74:      	ld1.s	{ v5 }[2], [x16]
    1a78:      	tbz	w14, #0x3, 0x1624 <_llm_rows.packet_batch.blocks+0x11dc>
    1a7c:      	add	x16, x15, #0xc
    1a80:      	ld1.s	{ v5 }[3], [x16]
    1a84:      	tbz	w14, #0x4, 0x1628 <_llm_rows.packet_batch.blocks+0x11e0>
    1a88:      	add	x16, x15, #0x10
    1a8c:      	ld1.s	{ v6 }[0], [x16]
    1a90:      	tbz	w14, #0x5, 0x162c <_llm_rows.packet_batch.blocks+0x11e4>
    1a94:      	add	x16, x15, #0x14
    1a98:      	ld1.s	{ v6 }[1], [x16]
    1a9c:      	tbz	w14, #0x6, 0x1630 <_llm_rows.packet_batch.blocks+0x11e8>
    1aa0:      	add	x16, x15, #0x18
    1aa4:      	ld1.s	{ v6 }[2], [x16]
    1aa8:      	tbnz	w14, #0x7, 0x1634 <_llm_rows.packet_batch.blocks+0x11ec>
    1aac:      	b	0x163c <_llm_rows.packet_batch.blocks+0x11f4>
    1ab0:      	add	x11, x13, x11
    1ab4:      	fmov	w13, s23
    1ab8:      	movi.2d	v3, #0000000000000000
    1abc:      	movi.2d	v5, #0000000000000000
    1ac0:      	tbnz	w13, #0x0, 0x1d98 <_llm_rows.packet_batch.blocks+0x1950>
    1ac4:      	tbnz	w13, #0x1, 0x1da0 <_llm_rows.packet_batch.blocks+0x1958>
    1ac8:      	tbnz	w13, #0x2, 0x1dac <_llm_rows.packet_batch.blocks+0x1964>
    1acc:      	tbnz	w13, #0x3, 0x1db8 <_llm_rows.packet_batch.blocks+0x1970>
    1ad0:      	tbnz	w13, #0x4, 0x1dc4 <_llm_rows.packet_batch.blocks+0x197c>
    1ad4:      	tbnz	w13, #0x5, 0x1dd0 <_llm_rows.packet_batch.blocks+0x1988>
    1ad8:      	tbnz	w13, #0x6, 0x1ddc <_llm_rows.packet_batch.blocks+0x1994>
    1adc:      	tbz	w13, #0x7, 0x1ae8 <_llm_rows.packet_batch.blocks+0x16a0>
    1ae0:      	add	x11, x11, #0x1c
    1ae4:      	ld1.s	{ v5 }[3], [x11]
    1ae8:      	mov	x13, #0x0               ; =0
    1aec:      	add	x11, x12, x27
    1af0:      	ldp	q2, q4, [x11]
    1af4:      	zip2.8b	v6, v31, v0
    1af8:      	ushll.4s	v6, v6, #0x0
    1afc:      	shl.4s	v6, v6, #0x1f
    1b00:      	cmlt.4s	v6, v6, #0
    1b04:      	bit.16b	v4, v5, v6
    1b08:      	zip1.8b	v5, v31, v0
    1b0c:      	ushll.4s	v5, v5, #0x0
    1b10:      	shl.4s	v5, v5, #0x1f
    1b14:      	cmlt.4s	v5, v5, #0
    1b18:      	bit.16b	v2, v3, v5
    1b1c:      	stp	q2, q4, [x11]
    1b20:      	dup.4s	v3, v22[0]
    1b24:      	ldr	q2, [sp, #0x140]
    1b28:      	fmov	x11, d2
    1b2c:      	add	x11, x8, x11, lsl #2
    1b30:      	movi.2d	v5, #0000000000000000
    1b34:      	movi.2d	v6, #0000000000000000
    1b38:      	movi.2d	v7, #0000000000000000
    1b3c:      	movi.2d	v16, #0000000000000000
    1b40:      	b	0x1b60 <_llm_rows.packet_batch.blocks+0x1718>
    1b44:      	add.2d	v6, v6, v19
    1b48:      	add.2d	v7, v7, v20
    1b4c:      	add.2d	v16, v16, v18
    1b50:      	add.2d	v5, v5, v21
    1b54:      	fmov	x13, d5
    1b58:      	cmp	x13, #0x200
    1b5c:      	b.ge	0x1c38 <_llm_rows.packet_batch.blocks+0x17f0>
    1b60:      	fmov	w14, s8
    1b64:      	lsl	x13, x13, #5
    1b68:      	add	x15, x10, x13
    1b6c:      	ldp	q2, q17, [x15]
    1b70:      	and.16b	v2, v1, v2
    1b74:      	fdiv.4s	v2, v2, v3
    1b78:      	add	x15, x9, x13
    1b7c:      	ldp	q4, q22, [x15]
    1b80:      	and.16b	v4, v1, v4
    1b84:      	fmul.4s	v2, v2, v4
    1b88:      	add	x15, x12, x13
    1b8c:      	ldp	q4, q24, [x15]
    1b90:      	and.16b	v4, v1, v4
    1b94:      	fadd.4s	v25, v2, v4
    1b98:      	add	x13, x11, x13
    1b9c:      	tbnz	w14, #0x0, 0x1be4 <_llm_rows.packet_batch.blocks+0x179c>
    1ba0:      	and	w14, w14, #0xff
    1ba4:      	tbnz	w14, #0x1, 0x1bf0 <_llm_rows.packet_batch.blocks+0x17a8>
    1ba8:      	tbnz	w14, #0x2, 0x1bfc <_llm_rows.packet_batch.blocks+0x17b4>
    1bac:      	tbz	w14, #0x3, 0x1bb8 <_llm_rows.packet_batch.blocks+0x1770>
    1bb0:      	add	x15, x13, #0xc
    1bb4:      	st1.s	{ v25 }[3], [x15]
    1bb8:      	and.16b	v2, v0, v17
    1bbc:      	fdiv.4s	v2, v2, v3
    1bc0:      	and.16b	v4, v0, v22
    1bc4:      	fmul.4s	v2, v2, v4
    1bc8:      	and.16b	v4, v0, v24
    1bcc:      	fadd.4s	v17, v2, v4
    1bd0:      	tbnz	w14, #0x4, 0x1c0c <_llm_rows.packet_batch.blocks+0x17c4>
    1bd4:      	tbnz	w14, #0x5, 0x1c14 <_llm_rows.packet_batch.blocks+0x17cc>
    1bd8:      	tbnz	w14, #0x6, 0x1c20 <_llm_rows.packet_batch.blocks+0x17d8>
    1bdc:      	tbz	w14, #0x7, 0x1b44 <_llm_rows.packet_batch.blocks+0x16fc>
    1be0:      	b	0x1c2c <_llm_rows.packet_batch.blocks+0x17e4>
    1be4:      	str	s25, [x13]
    1be8:      	and	w14, w14, #0xff
    1bec:      	tbz	w14, #0x1, 0x1ba8 <_llm_rows.packet_batch.blocks+0x1760>
    1bf0:      	add	x15, x13, #0x4
    1bf4:      	st1.s	{ v25 }[1], [x15]
    1bf8:      	tbz	w14, #0x2, 0x1bac <_llm_rows.packet_batch.blocks+0x1764>
    1bfc:      	add	x15, x13, #0x8
    1c00:      	st1.s	{ v25 }[2], [x15]
    1c04:      	tbnz	w14, #0x3, 0x1bb0 <_llm_rows.packet_batch.blocks+0x1768>
    1c08:      	b	0x1bb8 <_llm_rows.packet_batch.blocks+0x1770>
    1c0c:      	str	s17, [x13, #0x10]
    1c10:      	tbz	w14, #0x5, 0x1bd8 <_llm_rows.packet_batch.blocks+0x1790>
    1c14:      	add	x15, x13, #0x14
    1c18:      	st1.s	{ v17 }[1], [x15]
    1c1c:      	tbz	w14, #0x6, 0x1bdc <_llm_rows.packet_batch.blocks+0x1794>
    1c20:      	add	x15, x13, #0x18
    1c24:      	st1.s	{ v17 }[2], [x15]
    1c28:      	tbz	w14, #0x7, 0x1b44 <_llm_rows.packet_batch.blocks+0x16fc>
    1c2c:      	add	x13, x13, #0x1c
    1c30:      	st1.s	{ v17 }[3], [x13]
    1c34:      	b	0x1b44 <_llm_rows.packet_batch.blocks+0x16fc>
    1c38:      	add	x10, x10, x27
    1c3c:      	ldp	q1, q0, [x10]
    1c40:      	zip1.8b	v2, v31, v0
    1c44:      	ushll.4s	v2, v2, #0x0
    1c48:      	shl.4s	v2, v2, #0x1f
    1c4c:      	cmlt.4s	v2, v2, #0
    1c50:      	and.16b	v1, v2, v1
    1c54:      	zip2.8b	v4, v31, v0
    1c58:      	ushll.4s	v4, v4, #0x0
    1c5c:      	shl.4s	v4, v4, #0x1f
    1c60:      	cmlt.4s	v4, v4, #0
    1c64:      	and.16b	v0, v4, v0
    1c68:      	fdiv.4s	v0, v0, v3
    1c6c:      	fdiv.4s	v1, v1, v3
    1c70:      	add	x9, x9, x27
    1c74:      	ldp	q3, q5, [x9]
    1c78:      	and.16b	v5, v4, v5
    1c7c:      	and.16b	v3, v2, v3
    1c80:      	fmul.4s	v1, v1, v3
    1c84:      	fmul.4s	v0, v0, v5
    1c88:      	add	x9, x12, x27
    1c8c:      	ldp	q5, q3, [x9]
    1c90:      	and.16b	v2, v2, v5
    1c94:      	and.16b	v3, v4, v3
    1c98:      	fadd.4s	v0, v0, v3
    1c9c:      	fadd.4s	v1, v1, v2
    1ca0:      	ldp	q2, q3, [sp, #0x180]
    1ca4:      	ldp	q5, q4, [sp, #0x160]
    1ca8:      	stp	q3, q4, [sp, #0x1f0]
    1cac:      	stp	q5, q2, [sp, #0x210]
    1cb0:      	and	x9, x0, #0x7
    1cb4:      	add	x10, sp, #0x1f0
    1cb8:      	ldr	x9, [x10, x9, lsl #3]
    1cbc:      	sub	x9, x9, x0
    1cc0:      	add	x8, x8, x9, lsl #2
    1cc4:      	fmov	w9, s23
    1cc8:      	tbnz	w9, #0x0, 0x1cec <_llm_rows.packet_batch.blocks+0x18a4>
    1ccc:      	tbnz	w9, #0x1, 0x1cf4 <_llm_rows.packet_batch.blocks+0x18ac>
    1cd0:      	tbnz	w9, #0x2, 0x1d00 <_llm_rows.packet_batch.blocks+0x18b8>
    1cd4:      	tbnz	w9, #0x3, 0x1d0c <_llm_rows.packet_batch.blocks+0x18c4>
    1cd8:      	tbnz	w9, #0x4, 0x1d18 <_llm_rows.packet_batch.blocks+0x18d0>
    1cdc:      	tbnz	w9, #0x5, 0x1d20 <_llm_rows.packet_batch.blocks+0x18d8>
    1ce0:      	tbnz	w9, #0x6, 0x1d2c <_llm_rows.packet_batch.blocks+0x18e4>
    1ce4:      	tbz	w9, #0x7, 0x4cc <_llm_rows.packet_batch.blocks+0x84>
    1ce8:      	b	0x1d38 <_llm_rows.packet_batch.blocks+0x18f0>
    1cec:      	str	s1, [x8]
    1cf0:      	tbz	w9, #0x1, 0x1cd0 <_llm_rows.packet_batch.blocks+0x1888>
    1cf4:      	add	x10, x8, #0x4
    1cf8:      	st1.s	{ v1 }[1], [x10]
    1cfc:      	tbz	w9, #0x2, 0x1cd4 <_llm_rows.packet_batch.blocks+0x188c>
    1d00:      	add	x10, x8, #0x8
    1d04:      	st1.s	{ v1 }[2], [x10]
    1d08:      	tbz	w9, #0x3, 0x1cd8 <_llm_rows.packet_batch.blocks+0x1890>
    1d0c:      	add	x10, x8, #0xc
    1d10:      	st1.s	{ v1 }[3], [x10]
    1d14:      	tbz	w9, #0x4, 0x1cdc <_llm_rows.packet_batch.blocks+0x1894>
    1d18:      	str	s0, [x8, #0x10]
    1d1c:      	tbz	w9, #0x5, 0x1ce0 <_llm_rows.packet_batch.blocks+0x1898>
    1d20:      	add	x10, x8, #0x14
    1d24:      	st1.s	{ v0 }[1], [x10]
    1d28:      	tbz	w9, #0x6, 0x1ce4 <_llm_rows.packet_batch.blocks+0x189c>
    1d2c:      	add	x10, x8, #0x18
    1d30:      	st1.s	{ v0 }[2], [x10]
    1d34:      	tbz	w9, #0x7, 0x4cc <_llm_rows.packet_batch.blocks+0x84>
    1d38:      	add	x8, x8, #0x1c
    1d3c:      	st1.s	{ v0 }[3], [x8]
    1d40:      	b	0x4cc <_llm_rows.packet_batch.blocks+0x84>
    1d44:      	ldr	s3, [x9]
    1d48:      	tbz	w10, #0x1, 0x1994 <_llm_rows.packet_batch.blocks+0x154c>
    1d4c:      	add	x11, x9, #0x4
    1d50:      	ld1.s	{ v3 }[1], [x11]
    1d54:      	tbz	w10, #0x2, 0x1998 <_llm_rows.packet_batch.blocks+0x1550>
    1d58:      	add	x11, x9, #0x8
    1d5c:      	ld1.s	{ v3 }[2], [x11]
    1d60:      	tbz	w10, #0x3, 0x199c <_llm_rows.packet_batch.blocks+0x1554>
    1d64:      	add	x11, x9, #0xc
    1d68:      	ld1.s	{ v3 }[3], [x11]
    1d6c:      	tbz	w10, #0x4, 0x19a0 <_llm_rows.packet_batch.blocks+0x1558>
    1d70:      	add	x11, x9, #0x10
    1d74:      	ld1.s	{ v6 }[0], [x11]
    1d78:      	tbz	w10, #0x5, 0x19a4 <_llm_rows.packet_batch.blocks+0x155c>
    1d7c:      	add	x11, x9, #0x14
    1d80:      	ld1.s	{ v6 }[1], [x11]
    1d84:      	tbz	w10, #0x6, 0x19a8 <_llm_rows.packet_batch.blocks+0x1560>
    1d88:      	add	x11, x9, #0x18
    1d8c:      	ld1.s	{ v6 }[2], [x11]
    1d90:      	tbnz	w10, #0x7, 0x19ac <_llm_rows.packet_batch.blocks+0x1564>
    1d94:      	b	0x19b4 <_llm_rows.packet_batch.blocks+0x156c>
    1d98:      	ldr	s3, [x11]
    1d9c:      	tbz	w13, #0x1, 0x1ac8 <_llm_rows.packet_batch.blocks+0x1680>
    1da0:      	add	x14, x11, #0x4
    1da4:      	ld1.s	{ v3 }[1], [x14]
    1da8:      	tbz	w13, #0x2, 0x1acc <_llm_rows.packet_batch.blocks+0x1684>
    1dac:      	add	x14, x11, #0x8
    1db0:      	ld1.s	{ v3 }[2], [x14]
    1db4:      	tbz	w13, #0x3, 0x1ad0 <_llm_rows.packet_batch.blocks+0x1688>
    1db8:      	add	x14, x11, #0xc
    1dbc:      	ld1.s	{ v3 }[3], [x14]
    1dc0:      	tbz	w13, #0x4, 0x1ad4 <_llm_rows.packet_batch.blocks+0x168c>
    1dc4:      	add	x14, x11, #0x10
    1dc8:      	ld1.s	{ v5 }[0], [x14]
    1dcc:      	tbz	w13, #0x5, 0x1ad8 <_llm_rows.packet_batch.blocks+0x1690>
    1dd0:      	add	x14, x11, #0x14
    1dd4:      	ld1.s	{ v5 }[1], [x14]
    1dd8:      	tbz	w13, #0x6, 0x1adc <_llm_rows.packet_batch.blocks+0x1694>
    1ddc:      	add	x14, x11, #0x18
    1de0:      	ld1.s	{ v5 }[2], [x14]
    1de4:      	tbnz	w13, #0x7, 0x1ae0 <_llm_rows.packet_batch.blocks+0x1698>
    1de8:      	b	0x1ae8 <_llm_rows.packet_batch.blocks+0x16a0>
    1dec:      	add	sp, sp, #0x6c0
    1df0:      	ldp	x29, x30, [sp, #0x90]
    1df4:      	ldp	x20, x19, [sp, #0x80]
    1df8:      	ldp	x22, x21, [sp, #0x70]
    1dfc:      	ldp	x24, x23, [sp, #0x60]
    1e00:      	ldp	x26, x25, [sp, #0x50]
    1e04:      	ldp	x28, x27, [sp, #0x40]
    1e08:      	ldp	d9, d8, [sp, #0x30]
    1e0c:      	ldp	d11, d10, [sp, #0x20]
    1e10:      	ldp	d13, d12, [sp, #0x10]
    1e14:      	ldp	d15, d14, [sp], #0xa0
    1e18:      	ret

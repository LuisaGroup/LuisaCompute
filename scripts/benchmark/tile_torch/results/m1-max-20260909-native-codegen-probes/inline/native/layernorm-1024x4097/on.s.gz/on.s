
/private/tmp/luisa-packet-inline.UY1lIE/capture/layernorm-1024x4097/on/object/tile_xir_w8_36343_1788935096079988_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x6a0
      2c:      	str	x0, [sp, #0x1a0]
      30:      	str	w3, [sp, #0x1b8]
      34:      	cbz	w3, 0x2180 <ltmp0+0x2180>
      38:      	mov	w30, #0x0               ; =0
      3c:      	ldp	w9, w8, [x2, #0x2c]
      40:      	str	w9, [sp, #0x1b4]
      44:      	str	w8, [sp, #0x1b0]
      48:      	ldp	w9, w10, [x2]
      4c:      	mov	w5, #0x800              ; =2048
      50:      	movk	w5, #0x4580, lsl #16
      54:      	ldp	w11, w8, [x2, #0x8]
      58:      	str	x8, [sp, #0x1a8]
      5c:      	mov	w19, #0xc5ac            ; =50604
      60:      	movk	w19, #0x3727, lsl #16
      64:      	mov	w20, #0x1               ; =1
      68:      	movi	d30, #0000000000000000
      6c:      	mov	w21, #0x4004            ; =16388
      70:      	mov	w22, #0x60              ; =96
      74:      	movk	w22, #0x1, lsl #16
      78:      	str	x2, [sp, #0x198]
      7c:      	b	0xcc <ltmp0+0xcc>
      80:      	ldr	x14, [sp, #0x1c8]
      84:      	add	w8, w14, #0x1
      88:      	ldr	w9, [sp, #0x1b4]
      8c:      	cmp	w8, w9
      90:      	cset	w8, eq
      94:      	csinc	w9, wzr, w14, eq
      98:      	ldr	w13, [sp, #0x1c0]
      9c:      	cinc	w10, w13, eq
      a0:      	ldr	w11, [sp, #0x1b0]
      a4:      	cmp	w10, w11
      a8:      	cset	w11, eq
      ac:      	ands	w8, w8, w11
      b0:      	csel	w10, wzr, w10, ne
      b4:      	ldr	w12, [sp, #0x1c4]
      b8:      	add	w11, w12, w8
      bc:      	add	w30, w30, #0x1
      c0:      	ldr	w8, [sp, #0x1b8]
      c4:      	cmp	w30, w8
      c8:      	b.eq	0x2170 <ltmp0+0x2170>
      cc:      	str	w11, [sp, #0x1c4]
      d0:      	mov	x13, x10
      d4:      	mov	x4, x9
      d8:      	ubfiz	x8, x9, #5, #32
      dc:      	ldr	x12, [sp, #0x1a8]
      e0:      	cmp	x8, x12
      e4:      	csel	x9, x8, xzr, ls
      e8:      	subs	x10, x12, x9
      ec:      	cmp	x10, #0x20
      f0:      	mov	w11, #0x20              ; =32
      f4:      	csel	x10, x10, x11, lo
      f8:      	cmp	x12, x9
      fc:      	ccmp	x8, x12, #0x2, hi
     100:      	csel	x9, x10, xzr, ls
     104:      	cmp	x9, #0x20
     108:      	str	w13, [sp, #0x1c0]
     10c:      	str	x4, [sp, #0x1c8]
     110:      	b.lo	0x53c <ltmp0+0x53c>
     114:      	mov	x9, #0x0                ; =0
     118:      	ldr	x10, [x2, #0x88]
     11c:      	mov	w8, #0x4020             ; =16416
     120:      	add	x11, x10, x8
     124:      	mov	w8, #0x8040             ; =32832
     128:      	add	x12, x10, x8
     12c:      	mov	w8, #0xc060             ; =49248
     130:      	add	x13, x10, x8
     134:      	ldr	x8, [sp, #0x1a0]
     138:      	ldr	x14, [x8]
     13c:      	ldr	x15, [x8, #0x10]
     140:      	ldr	x16, [x8, #0x20]
     144:      	ldr	x17, [x8, #0x30]
     148:      	add	x0, x15, #0x4, lsl #12  ; =0x4000
     14c:      	subs	x8, x16, x17
     150:      	mov	w1, #0xfff              ; =4095
     154:      	movk	w1, #0x100, lsl #16
     158:      	ccmp	x8, x1, #0x0, hs
     15c:      	cset	w8, hi
     160:      	subs	x1, x17, x16
     164:      	mov	w3, #0x4003             ; =16387
     168:      	ccmp	x1, x3, #0x0, hs
     16c:      	csinc	w1, w8, wzr, ls
     170:      	add	x6, x16, #0x4, lsl #12  ; =0x4000
     174:      	lsl	w3, w4, #2
     178:      	and	x8, x4, #0x7ffffff
     17c:      	mov	w4, #0x10               ; =16
     180:      	movk	w4, #0x1, lsl #16
     184:      	umaddl	x24, w8, w4, x14
     188:      	add	x25, x10, #0xe0
     18c:      	mov	w7, #0x4100             ; =16640
     190:      	add	x26, x10, x7
     194:      	umaddl	x27, w8, w4, x17
     198:      	b	0x1b8 <ltmp0+0x1b8>
     19c:      	fadd.4s	v1, v1, v2
     1a0:      	str	s1, [x17, x7]
     1a4:      	add	x9, x9, #0x1
     1a8:      	add	x24, x24, x21
     1ac:      	add	x27, x27, x21
     1b0:      	cmp	x9, #0x4
     1b4:      	b.eq	0x80 <ltmp0+0x80>
     1b8:      	mov	x8, #0x0                ; =0
     1bc:      	add	w4, w9, w3
     1c0:      	and	x4, x4, #0x1fffffff
     1c4:      	add	x4, x4, x4, lsl #12
     1c8:      	lsl	x23, x4, #2
     1cc:      	add	x4, x24, x8
     1d0:      	ldp	q1, q2, [x4]
     1d4:      	add	x4, x10, x8
     1d8:      	stp	q1, q2, [x4]
     1dc:      	add	x8, x8, #0x20
     1e0:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     1e4:      	b.ne	0x1cc <ltmp0+0x1cc>
     1e8:      	add	x7, x23, #0x4, lsl #12  ; =0x4000
     1ec:      	add	x8, x14, x7
     1f0:      	ldr	q1, [x10, #0x4000]
     1f4:      	ld1.s	{ v1 }[0], [x8]
     1f8:      	str	q1, [x10, #0x4000]
     1fc:      	ldp	q2, q3, [x10]
     200:      	ldp	q7, q16, [x10, #0x20]
     204:      	ldp	q17, q4, [x10, #0x40]
     208:      	ldp	q5, q6, [x10, #0x60]
     20c:      	mov	x8, x25
     210:      	mov	w4, #0x4                ; =4
     214:      	ldp	q18, q19, [x8, #-0x60]
     218:      	fadd.4s	v3, v3, v19
     21c:      	fadd.4s	v2, v2, v18
     220:      	ldp	q18, q19, [x8, #-0x40]
     224:      	fadd.4s	v16, v16, v19
     228:      	fadd.4s	v7, v7, v18
     22c:      	ldp	q18, q19, [x8, #-0x20]
     230:      	fadd.4s	v4, v4, v19
     234:      	fadd.4s	v17, v17, v18
     238:      	ldp	q18, q19, [x8], #0x80
     23c:      	fadd.4s	v6, v6, v19
     240:      	fadd.4s	v5, v5, v18
     244:      	cmp	x4, #0x1fc
     248:      	add	x4, x4, #0x4
     24c:      	b.lo	0x214 <ltmp0+0x214>
     250:      	fadd.4s	v18, v1, v2
     254:      	mov.s	v2[0], v18[0]
     258:      	fadd.4s	v3, v16, v3
     25c:      	fadd.4s	v2, v7, v2
     260:      	fadd.4s	v2, v17, v2
     264:      	fadd.4s	v3, v4, v3
     268:      	fadd.4s	v3, v6, v3
     26c:      	fadd.4s	v2, v5, v2
     270:      	rev64.4s	v4, v2
     274:      	rev64.4s	v5, v3
     278:      	fadd.4s	v3, v3, v5
     27c:      	fadd.4s	v2, v2, v4
     280:      	dup.4s	v4, v2[2]
     284:      	dup.4s	v5, v3[2]
     288:      	fadd.4s	v3, v3, v5
     28c:      	fadd.4s	v2, v2, v4
     290:      	fadd.4s	v2, v2, v3
     294:      	fadd	s2, s2, s30
     298:      	fmov	s3, w5
     29c:      	fdiv	s2, s2, s3
     2a0:      	dup.4s	v3, v2[0]
     2a4:      	mov	x8, x10
     2a8:      	mov	w4, #0x200              ; =512
     2ac:      	ldp	q5, q4, [x8]
     2b0:      	fsub.4s	v5, v5, v3
     2b4:      	fsub.4s	v4, v4, v3
     2b8:      	str	q4, [x8, #0x4030]
     2bc:      	str	q5, [x8, #0x4020]
     2c0:      	add	x8, x8, #0x20
     2c4:      	subs	x4, x4, #0x1
     2c8:      	b.ne	0x2ac <ltmp0+0x2ac>
     2cc:      	fsub.4s	v1, v1, v2
     2d0:      	ldr	q2, [x10, #0x8020]
     2d4:      	mov.s	v2[0], v1[0]
     2d8:      	str	q2, [x10, #0x8020]
     2dc:      	ldr	q2, [x10, #0x4020]
     2e0:      	ldr	q3, [x10, #0x4030]
     2e4:      	fmul.4s	v3, v3, v3
     2e8:      	fmul.4s	v2, v2, v2
     2ec:      	ldr	q4, [x10, #0x4040]
     2f0:      	ldr	q5, [x10, #0x4050]
     2f4:      	fmul.4s	v5, v5, v5
     2f8:      	fmul.4s	v4, v4, v4
     2fc:      	ldr	q7, [x10, #0x4060]
     300:      	ldr	q6, [x10, #0x4070]
     304:      	fmul.4s	v6, v6, v6
     308:      	fmul.4s	v7, v7, v7
     30c:      	ldr	q16, [x10, #0x4080]
     310:      	ldr	q17, [x10, #0x4090]
     314:      	fmul.4s	v17, v17, v17
     318:      	fmul.4s	v16, v16, v16
     31c:      	mov	x28, x26
     320:      	mov	w4, #0x205              ; =517
     324:      	ldp	q19, q18, [x28, #-0x60]
     328:      	fmul.4s	v19, v19, v19
     32c:      	fmul.4s	v18, v18, v18
     330:      	fadd.4s	v3, v3, v18
     334:      	fadd.4s	v2, v2, v19
     338:      	ldp	q19, q18, [x28, #-0x40]
     33c:      	fmul.4s	v19, v19, v19
     340:      	fmul.4s	v18, v18, v18
     344:      	fadd.4s	v5, v5, v18
     348:      	fadd.4s	v4, v4, v19
     34c:      	ldp	q19, q18, [x28, #-0x20]
     350:      	fmul.4s	v19, v19, v19
     354:      	fmul.4s	v18, v18, v18
     358:      	fadd.4s	v6, v6, v18
     35c:      	fadd.4s	v7, v7, v19
     360:      	ldp	q19, q18, [x28], #0x80
     364:      	fmul.4s	v19, v19, v19
     368:      	fmul.4s	v18, v18, v18
     36c:      	fadd.4s	v17, v17, v18
     370:      	fadd.4s	v16, v16, v19
     374:      	sub	x8, x4, #0x201
     378:      	add	x4, x4, #0x4
     37c:      	cmp	x8, #0x1fc
     380:      	b.lo	0x324 <ltmp0+0x324>
     384:      	mov	x8, #0x0                ; =0
     388:      	add	x4, x15, x8
     38c:      	ldp	q18, q19, [x4]
     390:      	add	x4, x12, x8
     394:      	stp	q18, q19, [x4]
     398:      	add	x8, x8, #0x20
     39c:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     3a0:      	b.ne	0x388 <ltmp0+0x388>
     3a4:      	fmul.4s	v1, v1, v1
     3a8:      	fadd.4s	v1, v1, v2
     3ac:      	mov.s	v2[0], v1[0]
     3b0:      	fadd.4s	v1, v5, v3
     3b4:      	fadd.4s	v2, v4, v2
     3b8:      	fadd.4s	v2, v7, v2
     3bc:      	fadd.4s	v1, v6, v1
     3c0:      	fadd.4s	v1, v17, v1
     3c4:      	fadd.4s	v2, v16, v2
     3c8:      	rev64.4s	v3, v2
     3cc:      	rev64.4s	v4, v1
     3d0:      	fadd.4s	v1, v1, v4
     3d4:      	fadd.4s	v2, v2, v3
     3d8:      	dup.4s	v3, v2[2]
     3dc:      	dup.4s	v4, v1[2]
     3e0:      	fadd.4s	v1, v1, v4
     3e4:      	fadd.4s	v2, v2, v3
     3e8:      	fadd.4s	v1, v2, v1
     3ec:      	fadd	s1, s1, s30
     3f0:      	fmov	s2, w5
     3f4:      	fdiv	s1, s1, s2
     3f8:      	ldr	s2, [x0]
     3fc:      	mov	w8, #0xc040             ; =49216
     400:      	str	s2, [x10, x8]
     404:      	fmov	s2, w19
     408:      	fadd	s1, s1, s2
     40c:      	fsqrt	s1, s1
     410:      	tbz	w1, #0x0, 0x4ac <ltmp0+0x4ac>
     414:      	mov	x4, #0x0                ; =0
     418:      	dup.4s	v2, v1[0]
     41c:      	add	x8, x17, x23
     420:      	movi.2d	v3, #0000000000000000
     424:      	movi.2d	v4, #0000000000000000
     428:      	movi.2d	v5, #0000000000000000
     42c:      	movi.2d	v6, #0000000000000000
     430:      	lsl	x4, x4, #5
     434:      	add	x23, x11, x4
     438:      	ldp	q16, q7, [x23]
     43c:      	fdiv.4s	v16, v16, v2
     440:      	fdiv.4s	v7, v7, v2
     444:      	add	x4, x12, x4
     448:      	ldp	q17, q18, [x4]
     44c:      	fmul.4s	v7, v7, v18
     450:      	fmul.4s	v16, v16, v17
     454:      	fmov	x4, d3
     458:      	lsl	x4, x4, #5
     45c:      	add	x23, x16, x4
     460:      	ldp	q18, q17, [x23]
     464:      	fadd.4s	v16, v16, v18
     468:      	fadd.4s	v7, v7, v17
     46c:      	add	x4, x8, x4
     470:      	stp	q16, q7, [x4]
     474:      	dup.2d	v7, x20
     478:      	add.2d	v5, v5, v7
     47c:      	add.2d	v4, v4, v7
     480:      	add.2d	v6, v6, v7
     484:      	add.2d	v3, v3, v7
     488:      	fmov	x4, d3
     48c:      	cmp	x4, #0x200
     490:      	b.lt	0x430 <ltmp0+0x430>
     494:      	ldr	q2, [x10, #0x8020]
     498:      	fdiv.4s	v1, v2, v1
     49c:      	ldr	q2, [x10, #0xc040]
     4a0:      	fmul.4s	v1, v1, v2
     4a4:      	ldr	s2, [x6]
     4a8:      	b	0x19c <ltmp0+0x19c>
     4ac:      	mov	x8, #0x0                ; =0
     4b0:      	add	x4, x16, x8
     4b4:      	ldp	q2, q3, [x4]
     4b8:      	add	x4, x13, x8
     4bc:      	stp	q2, q3, [x4]
     4c0:      	add	x8, x8, #0x20
     4c4:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     4c8:      	b.ne	0x4b0 <ltmp0+0x4b0>
     4cc:      	ldr	s2, [x6]
     4d0:      	str	s2, [x10, x22]
     4d4:      	dup.4s	v2, v1[0]
     4d8:      	mov	x8, x10
     4dc:      	mov	x4, x27
     4e0:      	mov	w23, #0x200             ; =512
     4e4:      	ldr	q3, [x8, #0x4030]
     4e8:      	ldr	q4, [x8, #0x4020]
     4ec:      	fdiv.4s	v4, v4, v2
     4f0:      	fdiv.4s	v3, v3, v2
     4f4:      	ldr	q5, [x8, #0x8040]
     4f8:      	ldr	q6, [x8, #0x8050]
     4fc:      	fmul.4s	v3, v3, v6
     500:      	fmul.4s	v4, v4, v5
     504:      	ldr	q5, [x8, #0xc070]
     508:      	ldr	q6, [x8, #0xc060]
     50c:      	fadd.4s	v4, v4, v6
     510:      	fadd.4s	v3, v3, v5
     514:      	stp	q4, q3, [x4], #0x20
     518:      	add	x8, x8, #0x20
     51c:      	subs	x23, x23, #0x1
     520:      	b.ne	0x4e4 <ltmp0+0x4e4>
     524:      	ldr	q2, [x10, #0x8020]
     528:      	fdiv.4s	v1, v2, v1
     52c:      	ldr	q2, [x10, #0xc040]
     530:      	fmul.4s	v1, v1, v2
     534:      	ldr	q2, [x10, x22]
     538:      	b	0x19c <ltmp0+0x19c>
     53c:      	str	w30, [sp, #0x1bc]
     540:      	lsr	x10, x9, #3
     544:      	cmp	x9, #0x8
     548:      	b.hs	0x6c8 <ltmp0+0x6c8>
     54c:      	and	w8, w9, #0x7
     550:      	ldr	x2, [sp, #0x198]
     554:      	ldr	w30, [sp, #0x1bc]
     558:      	cbz	w8, 0x80 <ltmp0+0x80>
     55c:      	dup.4s	v1, w8
     560:      	adrp	x8, 0x0 <ltmp0>
     564:      	ldr	q2, [x8]
     568:      	adrp	x8, 0x0 <ltmp0>
     56c:      	ldr	q3, [x8]
     570:      	cmhi.4s	v5, v1, v3
     574:      	cmhi.4s	v6, v1, v2
     578:      	uzp1.8h	v0, v6, v5
     57c:      	umaxv.8h	h1, v0
     580:      	fmov	w8, s1
     584:      	tbz	w8, #0x0, 0x80 <ltmp0+0x80>
     588:      	mov	x12, #0x0               ; =0
     58c:      	ldr	x16, [x2, #0x88]
     590:      	mov	w8, #0x4020             ; =16416
     594:      	add	x24, x16, x8
     598:      	mov	w8, #0x8040             ; =32832
     59c:      	add	x27, x16, x8
     5a0:      	mov	w8, #0xc060             ; =49248
     5a4:      	add	x1, x16, x8
     5a8:      	ldr	x8, [sp, #0x1a0]
     5ac:      	ldr	x11, [x8]
     5b0:      	ldr	x15, [x8, #0x10]
     5b4:      	ldr	x9, [x8, #0x20]
     5b8:      	ldr	x26, [x8, #0x30]
     5bc:      	adrp	x8, 0x0 <ltmp0>
     5c0:      	ldr	q1, [x8]
     5c4:      	and.16b	v1, v0, v1
     5c8:      	addv.8h	h7, v1
     5cc:      	ldr	x8, [sp, #0x1c8]
     5d0:      	ubfiz	w8, w8, #2, #27
     5d4:      	orr	w8, w8, w10
     5d8:      	fmov	w10, s7
     5dc:      	and	w10, w10, #0xff
     5e0:      	str	w10, [sp, #0x90]
     5e4:      	dup.4s	v1, w8
     5e8:      	and.16b	v2, v6, v1
     5ec:      	and.16b	v1, v5, v1
     5f0:      	ushll2.2d	v18, v1, #0x0
     5f4:      	ushll2.2d	v19, v2, #0x0
     5f8:      	ushll.2d	v20, v1, #0x0
     5fc:      	ushll.2d	v1, v2, #0x0
     600:      	fmov	x8, d1
     604:      	umaddl	x10, w8, w21, x11
     608:      	mov	w17, #0x4               ; =4
     60c:      	b	0x630 <ltmp0+0x630>
     610:      	add	x8, x16, x12
     614:      	ldp	q4, q16, [x8]
     618:      	bif.16b	v3, v16, v5
     61c:      	bif.16b	v2, v4, v6
     620:      	stp	q2, q3, [x8]
     624:      	add	x12, x12, #0x20
     628:      	cmp	x12, #0x4, lsl #12      ; =0x4000
     62c:      	b.eq	0xaf8 <ltmp0+0xaf8>
     630:      	fmov	w8, s7
     634:      	add	x13, x10, x12
     638:      	movi.2d	v2, #0000000000000000
     63c:      	movi.2d	v3, #0000000000000000
     640:      	tbnz	w8, #0x0, 0x668 <ltmp0+0x668>
     644:      	and	w14, w8, #0xff
     648:      	tbnz	w14, #0x1, 0x674 <ltmp0+0x674>
     64c:      	tbnz	w14, #0x2, 0x680 <ltmp0+0x680>
     650:      	tbnz	w14, #0x3, 0x68c <ltmp0+0x68c>
     654:      	tbnz	w14, #0x4, 0x698 <ltmp0+0x698>
     658:      	tbnz	w14, #0x5, 0x6a4 <ltmp0+0x6a4>
     65c:      	tbnz	w14, #0x6, 0x6b0 <ltmp0+0x6b0>
     660:      	tbz	w14, #0x7, 0x610 <ltmp0+0x610>
     664:      	b	0x6bc <ltmp0+0x6bc>
     668:      	ldr	s2, [x13]
     66c:      	and	w14, w8, #0xff
     670:      	tbz	w14, #0x1, 0x64c <ltmp0+0x64c>
     674:      	add	x8, x13, #0x4
     678:      	ld1.s	{ v2 }[1], [x8]
     67c:      	tbz	w14, #0x2, 0x650 <ltmp0+0x650>
     680:      	add	x8, x13, #0x8
     684:      	ld1.s	{ v2 }[2], [x8]
     688:      	tbz	w14, #0x3, 0x654 <ltmp0+0x654>
     68c:      	add	x8, x13, #0xc
     690:      	ld1.s	{ v2 }[3], [x8]
     694:      	tbz	w14, #0x4, 0x658 <ltmp0+0x658>
     698:      	add	x8, x13, #0x10
     69c:      	ld1.s	{ v3 }[0], [x8]
     6a0:      	tbz	w14, #0x5, 0x65c <ltmp0+0x65c>
     6a4:      	add	x8, x13, #0x14
     6a8:      	ld1.s	{ v3 }[1], [x8]
     6ac:      	tbz	w14, #0x6, 0x660 <ltmp0+0x660>
     6b0:      	add	x8, x13, #0x18
     6b4:      	ld1.s	{ v3 }[2], [x8]
     6b8:      	tbz	w14, #0x7, 0x610 <ltmp0+0x610>
     6bc:      	add	x8, x13, #0x1c
     6c0:      	ld1.s	{ v3 }[3], [x8]
     6c4:      	b	0x610 <ltmp0+0x610>
     6c8:      	mov	x11, #0x0               ; =0
     6cc:      	ldr	x8, [sp, #0x198]
     6d0:      	ldr	x12, [x8, #0x88]
     6d4:      	ldr	x8, [sp, #0x1a0]
     6d8:      	ldr	x13, [x8]
     6dc:      	ldr	x14, [x8, #0x10]
     6e0:      	ldr	x15, [x8, #0x20]
     6e4:      	ldr	x16, [x8, #0x30]
     6e8:      	mov	w8, #0x4020             ; =16416
     6ec:      	add	x17, x12, x8
     6f0:      	mov	w8, #0x8040             ; =32832
     6f4:      	add	x0, x12, x8
     6f8:      	mov	w8, #0xc060             ; =49248
     6fc:      	add	x1, x12, x8
     700:      	add	x2, x14, #0x4, lsl #12  ; =0x4000
     704:      	subs	x8, x15, x16
     708:      	mov	w3, #0xfff              ; =4095
     70c:      	movk	w3, #0x100, lsl #16
     710:      	ccmp	x8, x3, #0x0, hs
     714:      	cset	w8, hi
     718:      	subs	x3, x16, x15
     71c:      	mov	w4, #0x4003             ; =16387
     720:      	ccmp	x3, x4, #0x0, hs
     724:      	csinc	w3, w8, wzr, ls
     728:      	add	x24, x15, #0x4, lsl #12 ; =0x4000
     72c:      	ldr	x8, [sp, #0x1c8]
     730:      	lsl	w25, w8, #2
     734:      	and	x8, x8, #0x7ffffff
     738:      	mov	w6, #0x10               ; =16
     73c:      	movk	w6, #0x1, lsl #16
     740:      	umaddl	x26, w8, w6, x13
     744:      	add	x27, x12, #0xe0
     748:      	mov	w4, #0x4100             ; =16640
     74c:      	add	x4, x12, x4
     750:      	umaddl	x30, w8, w6, x16
     754:      	b	0x788 <ltmp0+0x788>
     758:      	ldr	q2, [x12, #0x8020]
     75c:      	fdiv.4s	v1, v2, v1
     760:      	ldr	q2, [x12, #0xc040]
     764:      	fmul.4s	v1, v1, v2
     768:      	ldr	q2, [x12, x22]
     76c:      	fadd.4s	v1, v1, v2
     770:      	str	s1, [x16, x7]
     774:      	add	x11, x11, #0x1
     778:      	add	x26, x26, x21
     77c:      	add	x30, x30, x21
     780:      	cmp	x11, x10
     784:      	b.eq	0x54c <ltmp0+0x54c>
     788:      	mov	x8, #0x0                ; =0
     78c:      	add	w7, w11, w25
     790:      	and	x7, x7, #0x1fffffff
     794:      	add	x7, x7, x7, lsl #12
     798:      	lsl	x23, x7, #2
     79c:      	add	x7, x26, x8
     7a0:      	ldp	q1, q2, [x7]
     7a4:      	add	x7, x12, x8
     7a8:      	stp	q1, q2, [x7]
     7ac:      	add	x8, x8, #0x20
     7b0:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     7b4:      	b.ne	0x79c <ltmp0+0x79c>
     7b8:      	add	x7, x23, #0x4, lsl #12  ; =0x4000
     7bc:      	add	x8, x13, x7
     7c0:      	ldr	q1, [x12, #0x4000]
     7c4:      	ld1.s	{ v1 }[0], [x8]
     7c8:      	str	q1, [x12, #0x4000]
     7cc:      	ldp	q2, q3, [x12]
     7d0:      	ldp	q7, q16, [x12, #0x20]
     7d4:      	ldp	q17, q4, [x12, #0x40]
     7d8:      	ldp	q5, q6, [x12, #0x60]
     7dc:      	mov	x8, x27
     7e0:      	mov	w28, #0x4               ; =4
     7e4:      	ldp	q18, q19, [x8, #-0x60]
     7e8:      	fadd.4s	v3, v3, v19
     7ec:      	fadd.4s	v2, v2, v18
     7f0:      	ldp	q18, q19, [x8, #-0x40]
     7f4:      	fadd.4s	v16, v16, v19
     7f8:      	fadd.4s	v7, v7, v18
     7fc:      	ldp	q18, q19, [x8, #-0x20]
     800:      	fadd.4s	v4, v4, v19
     804:      	fadd.4s	v17, v17, v18
     808:      	ldp	q18, q19, [x8], #0x80
     80c:      	fadd.4s	v6, v6, v19
     810:      	fadd.4s	v5, v5, v18
     814:      	cmp	x28, #0x1fc
     818:      	add	x28, x28, #0x4
     81c:      	b.lo	0x7e4 <ltmp0+0x7e4>
     820:      	fadd.4s	v18, v1, v2
     824:      	mov.s	v2[0], v18[0]
     828:      	fadd.4s	v3, v16, v3
     82c:      	fadd.4s	v2, v7, v2
     830:      	fadd.4s	v2, v17, v2
     834:      	fadd.4s	v3, v4, v3
     838:      	fadd.4s	v3, v6, v3
     83c:      	fadd.4s	v2, v5, v2
     840:      	rev64.4s	v4, v2
     844:      	rev64.4s	v5, v3
     848:      	fadd.4s	v3, v3, v5
     84c:      	fadd.4s	v2, v2, v4
     850:      	dup.4s	v4, v2[2]
     854:      	dup.4s	v5, v3[2]
     858:      	fadd.4s	v3, v3, v5
     85c:      	fadd.4s	v2, v2, v4
     860:      	fadd.4s	v2, v2, v3
     864:      	fadd	s2, s2, s30
     868:      	fmov	s3, w5
     86c:      	fdiv	s2, s2, s3
     870:      	dup.4s	v3, v2[0]
     874:      	mov	x8, x12
     878:      	mov	w28, #0x200             ; =512
     87c:      	ldp	q5, q4, [x8]
     880:      	fsub.4s	v5, v5, v3
     884:      	fsub.4s	v4, v4, v3
     888:      	str	q4, [x8, #0x4030]
     88c:      	str	q5, [x8, #0x4020]
     890:      	add	x8, x8, #0x20
     894:      	subs	x28, x28, #0x1
     898:      	b.ne	0x87c <ltmp0+0x87c>
     89c:      	fsub.4s	v1, v1, v2
     8a0:      	ldr	q2, [x12, #0x8020]
     8a4:      	mov.s	v2[0], v1[0]
     8a8:      	str	q2, [x12, #0x8020]
     8ac:      	ldr	q2, [x12, #0x4020]
     8b0:      	ldr	q3, [x12, #0x4030]
     8b4:      	fmul.4s	v3, v3, v3
     8b8:      	fmul.4s	v2, v2, v2
     8bc:      	ldr	q4, [x12, #0x4040]
     8c0:      	ldr	q5, [x12, #0x4050]
     8c4:      	fmul.4s	v5, v5, v5
     8c8:      	fmul.4s	v4, v4, v4
     8cc:      	ldr	q7, [x12, #0x4060]
     8d0:      	ldr	q6, [x12, #0x4070]
     8d4:      	fmul.4s	v6, v6, v6
     8d8:      	fmul.4s	v7, v7, v7
     8dc:      	ldr	q16, [x12, #0x4080]
     8e0:      	ldr	q17, [x12, #0x4090]
     8e4:      	fmul.4s	v17, v17, v17
     8e8:      	fmul.4s	v16, v16, v16
     8ec:      	mov	x28, x4
     8f0:      	mov	w8, #0x205              ; =517
     8f4:      	ldp	q19, q18, [x28, #-0x60]
     8f8:      	fmul.4s	v19, v19, v19
     8fc:      	fmul.4s	v18, v18, v18
     900:      	fadd.4s	v3, v3, v18
     904:      	fadd.4s	v2, v2, v19
     908:      	ldp	q19, q18, [x28, #-0x40]
     90c:      	fmul.4s	v19, v19, v19
     910:      	fmul.4s	v18, v18, v18
     914:      	fadd.4s	v5, v5, v18
     918:      	fadd.4s	v4, v4, v19
     91c:      	ldp	q19, q18, [x28, #-0x20]
     920:      	fmul.4s	v19, v19, v19
     924:      	fmul.4s	v18, v18, v18
     928:      	fadd.4s	v6, v6, v18
     92c:      	fadd.4s	v7, v7, v19
     930:      	ldp	q19, q18, [x28], #0x80
     934:      	fmul.4s	v19, v19, v19
     938:      	fmul.4s	v18, v18, v18
     93c:      	fadd.4s	v17, v17, v18
     940:      	fadd.4s	v16, v16, v19
     944:      	sub	x6, x8, #0x201
     948:      	add	x8, x8, #0x4
     94c:      	cmp	x6, #0x1fc
     950:      	b.lo	0x8f4 <ltmp0+0x8f4>
     954:      	mov	x8, #0x0                ; =0
     958:      	add	x6, x14, x8
     95c:      	ldp	q18, q19, [x6]
     960:      	add	x6, x0, x8
     964:      	stp	q18, q19, [x6]
     968:      	add	x8, x8, #0x20
     96c:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     970:      	b.ne	0x958 <ltmp0+0x958>
     974:      	fmul.4s	v1, v1, v1
     978:      	fadd.4s	v1, v1, v2
     97c:      	mov.s	v2[0], v1[0]
     980:      	fadd.4s	v1, v5, v3
     984:      	fadd.4s	v2, v4, v2
     988:      	fadd.4s	v2, v7, v2
     98c:      	fadd.4s	v1, v6, v1
     990:      	fadd.4s	v1, v17, v1
     994:      	fadd.4s	v2, v16, v2
     998:      	rev64.4s	v3, v2
     99c:      	rev64.4s	v4, v1
     9a0:      	fadd.4s	v1, v1, v4
     9a4:      	fadd.4s	v2, v2, v3
     9a8:      	dup.4s	v3, v2[2]
     9ac:      	dup.4s	v4, v1[2]
     9b0:      	fadd.4s	v1, v1, v4
     9b4:      	fadd.4s	v2, v2, v3
     9b8:      	fadd.4s	v1, v2, v1
     9bc:      	fadd	s1, s1, s30
     9c0:      	fmov	s2, w5
     9c4:      	fdiv	s1, s1, s2
     9c8:      	ldr	s2, [x2]
     9cc:      	mov	w8, #0xc040             ; =49216
     9d0:      	str	s2, [x12, x8]
     9d4:      	fmov	s2, w19
     9d8:      	fadd	s1, s1, s2
     9dc:      	fsqrt	s1, s1
     9e0:      	tbz	w3, #0x0, 0xa7c <ltmp0+0xa7c>
     9e4:      	mov	x28, #0x0               ; =0
     9e8:      	dup.4s	v2, v1[0]
     9ec:      	add	x8, x16, x23
     9f0:      	movi.2d	v3, #0000000000000000
     9f4:      	movi.2d	v4, #0000000000000000
     9f8:      	movi.2d	v5, #0000000000000000
     9fc:      	movi.2d	v6, #0000000000000000
     a00:      	lsl	x6, x28, #5
     a04:      	add	x23, x17, x6
     a08:      	ldp	q16, q7, [x23]
     a0c:      	fdiv.4s	v16, v16, v2
     a10:      	fdiv.4s	v7, v7, v2
     a14:      	add	x6, x0, x6
     a18:      	ldp	q17, q18, [x6]
     a1c:      	fmul.4s	v7, v7, v18
     a20:      	fmul.4s	v16, v16, v17
     a24:      	fmov	x6, d3
     a28:      	lsl	x6, x6, #5
     a2c:      	add	x23, x15, x6
     a30:      	ldp	q18, q17, [x23]
     a34:      	fadd.4s	v16, v16, v18
     a38:      	fadd.4s	v7, v7, v17
     a3c:      	add	x6, x8, x6
     a40:      	stp	q16, q7, [x6]
     a44:      	dup.2d	v7, x20
     a48:      	add.2d	v5, v5, v7
     a4c:      	add.2d	v4, v4, v7
     a50:      	add.2d	v6, v6, v7
     a54:      	add.2d	v3, v3, v7
     a58:      	fmov	x28, d3
     a5c:      	cmp	x28, #0x200
     a60:      	b.lt	0xa00 <ltmp0+0xa00>
     a64:      	ldr	q2, [x12, #0x8020]
     a68:      	fdiv.4s	v1, v2, v1
     a6c:      	ldr	q2, [x12, #0xc040]
     a70:      	fmul.4s	v1, v1, v2
     a74:      	ldr	s2, [x24]
     a78:      	b	0x76c <ltmp0+0x76c>
     a7c:      	mov	x8, #0x0                ; =0
     a80:      	add	x6, x15, x8
     a84:      	ldp	q2, q3, [x6]
     a88:      	add	x6, x1, x8
     a8c:      	stp	q2, q3, [x6]
     a90:      	add	x8, x8, #0x20
     a94:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     a98:      	b.ne	0xa80 <ltmp0+0xa80>
     a9c:      	ldr	s2, [x24]
     aa0:      	str	s2, [x12, x22]
     aa4:      	dup.4s	v2, v1[0]
     aa8:      	mov	x8, x12
     aac:      	mov	x23, x30
     ab0:      	mov	w28, #0x200             ; =512
     ab4:      	ldr	q3, [x8, #0x4030]
     ab8:      	ldr	q4, [x8, #0x4020]
     abc:      	fdiv.4s	v4, v4, v2
     ac0:      	fdiv.4s	v3, v3, v2
     ac4:      	ldr	q5, [x8, #0x8040]
     ac8:      	ldr	q6, [x8, #0x8050]
     acc:      	fmul.4s	v3, v3, v6
     ad0:      	fmul.4s	v4, v4, v5
     ad4:      	ldr	q5, [x8, #0xc070]
     ad8:      	ldr	q6, [x8, #0xc060]
     adc:      	fadd.4s	v4, v4, v6
     ae0:      	fadd.4s	v3, v3, v5
     ae4:      	stp	q4, q3, [x23], #0x20
     ae8:      	add	x8, x8, #0x20
     aec:      	subs	x28, x28, #0x1
     af0:      	b.ne	0xab4 <ltmp0+0xab4>
     af4:      	b	0x758 <ltmp0+0x758>
     af8:      	str	q0, [sp, #0x80]
     afc:      	xtn.4h	v2, v6
     b00:      	uzp1.8b	v2, v2, v0
     b04:      	sshll.2d	v22, v6, #0x0
     b08:      	adrp	x8, 0x0 <ltmp0>
     b0c:      	ldr	q3, [x8]
     b10:      	and.16b	v0, v22, v3
     b14:      	movi.2d	v17, #0000000000000000
     b18:      	mov.b	v17[0], v2[0]
     b1c:      	adrp	x8, 0x0 <ltmp0>
     b20:      	ldr	d3, [x8]
     b24:      	str	d3, [sp, #0xd8]
     b28:      	and.8b	v3, v17, v3
     b2c:      	addv.8b	b3, v3
     b30:      	fmov	w10, s3
     b34:      	umaxv.8b	b3, v17
     b38:      	fmov	w8, s3
     b3c:      	rbit	w12, w10
     b40:      	clz	w12, w12
     b44:      	tst	w8, #0x1
     b48:      	csel	w14, w12, wzr, ne
     b4c:      	mov	w12, #0x1000            ; =4096
     b50:      	dup.2d	v25, x12
     b54:      	str	q0, [sp, #0x170]
     b58:      	orr.16b	v0, v0, v25
     b5c:      	mov	w12, #0x1001            ; =4097
     b60:      	dup.2s	v24, w12
     b64:      	xtn.2s	v26, v1
     b68:      	str	q0, [sp, #0xe0]
     b6c:      	umlal.2d	v0, v26, v24
     b70:      	movi.2d	v1, #0000000000000000
     b74:      	mov.b	v1[0], v2[0]
     b78:      	ushll.2d	v1, v1, #0x0
     b7c:      	shl.2d	v1, v1, #0x3f
     b80:      	cmlt.2d	v1, v1, #0
     b84:      	str	q0, [sp, #0x140]
     b88:      	and.16b	v1, v1, v0
     b8c:      	movi.2d	v0, #0000000000000000
     b90:      	str	q0, [sp, #0x680]
     b94:      	str	q0, [sp, #0x670]
     b98:      	str	q0, [sp, #0x660]
     b9c:      	str	q1, [sp, #0x650]
     ba0:      	and	x12, x14, #0x7
     ba4:      	add	x13, sp, #0x650
     ba8:      	ldr	x12, [x13, x12, lsl #3]
     bac:      	sub	x12, x12, x14
     bb0:      	add	x11, x11, x12, lsl #2
     bb4:      	movi.2d	v21, #0000000000000000
     bb8:      	movi.2d	v23, #0000000000000000
     bbc:      	tbnz	w8, #0x0, 0x1d7c <ltmp0+0x1d7c>
     bc0:      	tbnz	w10, #0x1, 0x1d84 <ltmp0+0x1d84>
     bc4:      	tbnz	w10, #0x2, 0x1d90 <ltmp0+0x1d90>
     bc8:      	tbnz	w10, #0x3, 0x1d9c <ltmp0+0x1d9c>
     bcc:      	tbnz	w10, #0x4, 0x1da8 <ltmp0+0x1da8>
     bd0:      	tbnz	w10, #0x5, 0x1db4 <ltmp0+0x1db4>
     bd4:      	tbnz	w10, #0x6, 0x1dc0 <ltmp0+0x1dc0>
     bd8:      	str	q7, [sp, #0x150]
     bdc:      	tbz	w10, #0x7, 0xbe8 <ltmp0+0xbe8>
     be0:      	add	x8, x11, #0x1c
     be4:      	ld1.s	{ v23 }[3], [x8]
     be8:      	sshll.2d	v27, v5, #0x0
     bec:      	sshll2.2d	v9, v6, #0x0
     bf0:      	sshll2.2d	v10, v5, #0x0
     bf4:      	adrp	x8, 0x0 <ltmp0>
     bf8:      	ldr	q3, [x8]
     bfc:      	and.16b	v0, v10, v3
     c00:      	adrp	x8, 0x0 <ltmp0>
     c04:      	ldr	q4, [x8]
     c08:      	and.16b	v1, v9, v4
     c0c:      	adrp	x8, 0x0 <ltmp0>
     c10:      	ldr	q16, [x8]
     c14:      	and.16b	v2, v27, v16
     c18:      	adrp	x8, 0x0 <ltmp0>
     c1c:      	ldr	q28, [x8]
     c20:      	and.16b	v28, v10, v28
     c24:      	adrp	x8, 0x0 <ltmp0>
     c28:      	ldr	q29, [x8]
     c2c:      	and.16b	v29, v9, v29
     c30:      	adrp	x8, 0x0 <ltmp0>
     c34:      	ldr	q30, [x8]
     c38:      	and.16b	v27, v27, v30
     c3c:      	adrp	x8, 0x0 <ltmp0>
     c40:      	ldr	q30, [x8]
     c44:      	and.16b	v22, v22, v30
     c48:      	stp	q2, q1, [sp, #0x30]
     c4c:      	orr.16b	v2, v2, v25
     c50:      	orr.16b	v3, v1, v25
     c54:      	str	q0, [sp, #0x50]
     c58:      	orr.16b	v1, v0, v25
     c5c:      	umull.2d	v0, v26, v24
     c60:      	str	q0, [sp, #0xf0]
     c64:      	xtn.2s	v19, v19
     c68:      	xtn.2s	v20, v20
     c6c:      	xtn.2s	v18, v18
     c70:      	stp	q2, q1, [sp, #0xb0]
     c74:      	mov.16b	v0, v1
     c78:      	umlal.2d	v0, v18, v24
     c7c:      	str	q0, [sp, #0x130]
     c80:      	str	q3, [sp, #0xa0]
     c84:      	mov.16b	v0, v3
     c88:      	umlal.2d	v0, v19, v24
     c8c:      	str	q0, [sp, #0x120]
     c90:      	mov.16b	v0, v2
     c94:      	umlal.2d	v0, v20, v24
     c98:      	str	q0, [sp, #0x110]
     c9c:      	sshll.2d	v18, v6, #0x0
     ca0:      	sshll.2d	v19, v5, #0x0
     ca4:      	str	q22, [sp, #0x610]
     ca8:      	str	q29, [sp, #0x620]
     cac:      	str	q27, [sp, #0x630]
     cb0:      	str	q28, [sp, #0x640]
     cb4:      	and	x8, x14, #0x7
     cb8:      	add	x11, sp, #0x610
     cbc:      	ldr	x8, [x11, x8, lsl #3]
     cc0:      	orr	x8, x8, #0x4000
     cc4:      	str	x14, [sp, #0x168]
     cc8:      	sub	x8, x8, x14, lsl #2
     ccc:      	tst	w10, #0xff
     cd0:      	csel	x8, xzr, x8, eq
     cd4:      	str	x8, [sp, #0x108]
     cd8:      	add	x8, x16, x8
     cdc:      	ldp	q20, q24, [x8]
     ce0:      	zip2.8b	v25, v17, v0
     ce4:      	ushll.4s	v25, v25, #0x0
     ce8:      	shl.4s	v25, v25, #0x1f
     cec:      	cmlt.4s	v25, v25, #0
     cf0:      	stp	q23, q21, [sp, #0x60]
     cf4:      	bit.16b	v24, v23, v25
     cf8:      	str	q17, [sp, #0x180]
     cfc:      	zip1.8b	v25, v17, v0
     d00:      	ushll.4s	v25, v25, #0x0
     d04:      	shl.4s	v25, v25, #0x1f
     d08:      	cmlt.4s	v25, v25, #0
     d0c:      	bit.16b	v20, v21, v25
     d10:      	stp	q20, q24, [x8]
     d14:      	fmov	x11, d22
     d18:      	dup.2d	v20, x17
     d1c:      	and.16b	v31, v10, v20
     d20:      	and.16b	v12, v9, v20
     d24:      	and.16b	v30, v19, v20
     d28:      	and.16b	v14, v18, v20
     d2c:      	fmov	x14, d14
     d30:      	ldp	q19, q18, [x16, #0x60]
     d34:      	and.16b	v18, v5, v18
     d38:      	and.16b	v19, v6, v19
     d3c:      	ldp	q20, q22, [x16, #0x40]
     d40:      	and.16b	v22, v5, v22
     d44:      	and.16b	v20, v6, v20
     d48:      	ldp	q25, q24, [x16, #0x20]
     d4c:      	and.16b	v24, v5, v24
     d50:      	and.16b	v25, v6, v25
     d54:      	add	x8, x16, x11
     d58:      	ldp	q27, q26, [x8]
     d5c:      	and.16b	v26, v5, v26
     d60:      	mov	x8, x14
     d64:      	and.16b	v27, v6, v27
     d68:      	mov.16b	v8, v14
     d6c:      	mov.16b	v15, v12
     d70:      	mov.16b	v13, v30
     d74:      	mov.16b	v11, v31
     d78:      	sshll.2d	v23, v6, #0x0
     d7c:      	sshll.2d	v21, v5, #0x0
     d80:      	add	x8, x16, x8, lsl #5
     d84:      	ldp	q28, q29, [x8]
     d88:      	fadd.4s	v28, v27, v28
     d8c:      	fadd.4s	v29, v26, v29
     d90:      	ldp	q3, q17, [x8, #0x20]
     d94:      	fadd.4s	v3, v25, v3
     d98:      	fadd.4s	v17, v24, v17
     d9c:      	ldp	q16, q4, [x8, #0x40]
     da0:      	fadd.4s	v16, v20, v16
     da4:      	fadd.4s	v4, v22, v4
     da8:      	ldp	q2, q1, [x8, #0x60]
     dac:      	fadd.4s	v2, v19, v2
     db0:      	fadd.4s	v1, v18, v1
     db4:      	dup.2d	v0, x17
     db8:      	and.16b	v7, v10, v0
     dbc:      	add.2d	v11, v11, v7
     dc0:      	and.16b	v7, v9, v0
     dc4:      	add.2d	v15, v15, v7
     dc8:      	and.16b	v7, v21, v0
     dcc:      	add.2d	v13, v13, v7
     dd0:      	and.16b	v0, v23, v0
     dd4:      	add.2d	v8, v8, v0
     dd8:      	bit.16b	v26, v29, v5
     ddc:      	bit.16b	v27, v28, v6
     de0:      	bit.16b	v24, v17, v5
     de4:      	bit.16b	v25, v3, v6
     de8:      	bit.16b	v22, v4, v5
     dec:      	bit.16b	v20, v16, v6
     df0:      	bit.16b	v18, v1, v5
     df4:      	bit.16b	v19, v2, v6
     df8:      	fmov	x8, d8
     dfc:      	cmp	x8, #0x200
     e00:      	b.lt	0xd78 <ltmp0+0xd78>
     e04:      	mov	x7, #0x0                ; =0
     e08:      	ldp	q1, q0, [sp, #0x70]
     e0c:      	xtn.8b	v23, v0
     e10:      	ldr	q0, [sp, #0x60]
     e14:      	fadd.4s	v0, v0, v26
     e18:      	fadd.4s	v1, v1, v27
     e1c:      	ldr	q27, [sp, #0x180]
     e20:      	zip1.8b	v2, v27, v0
     e24:      	ushll.4s	v2, v2, #0x0
     e28:      	shl.4s	v2, v2, #0x1f
     e2c:      	cmlt.4s	v2, v2, #0
     e30:      	and.16b	v1, v2, v1
     e34:      	zip2.8b	v2, v27, v0
     e38:      	ushll.4s	v2, v2, #0x0
     e3c:      	shl.4s	v2, v2, #0x1f
     e40:      	cmlt.4s	v2, v2, #0
     e44:      	and.16b	v0, v2, v0
     e48:      	zip2.8b	v2, v23, v0
     e4c:      	ushll.4s	v2, v2, #0x0
     e50:      	shl.4s	v2, v2, #0x1f
     e54:      	cmlt.4s	v2, v2, #0
     e58:      	movi.2d	v3, #0000000000000000
     e5c:      	mov.b	v3[2], v23[1]
     e60:      	mov.b	v3[4], v23[2]
     e64:      	bit.16b	v0, v29, v2
     e68:      	mov.b	v3[6], v23[3]
     e6c:      	ushll.4s	v2, v3, #0x0
     e70:      	shl.4s	v2, v2, #0x1f
     e74:      	cmlt.4s	v2, v2, #0
     e78:      	bit.16b	v1, v28, v2
     e7c:      	fadd.4s	v1, v25, v1
     e80:      	fadd.4s	v0, v24, v0
     e84:      	fadd.4s	v0, v22, v0
     e88:      	fadd.4s	v1, v20, v1
     e8c:      	fadd.4s	v2, v19, v1
     e90:      	fadd.4s	v18, v18, v0
     e94:      	ldr	q0, [sp, #0x170]
     e98:      	ldp	q3, q1, [sp, #0x30]
     e9c:      	uzp1.4s	v1, v0, v1
     ea0:      	ldr	q0, [sp, #0x50]
     ea4:      	uzp1.4s	v3, v3, v0
     ea8:      	movi.4s	v4, #0x1
     eac:      	eor.16b	v0, v1, v4
     eb0:      	mov.s	w8, v0[1]
     eb4:      	eor.16b	v20, v3, v4
     eb8:      	mov.s	w10, v0[2]
     ebc:      	mov.s	w12, v0[3]
     ec0:      	fmov	w13, s0
     ec4:      	add	x17, sp, #0x4a8
     ec8:      	bfxil	x17, x13, #0, #3
     ecc:      	str	d23, [sp, #0x4a8]
     ed0:      	ldrb	w2, [x17]
     ed4:      	umov.b	w17, v23[0]
     ed8:      	and	x13, x13, #0x7
     edc:      	str	q18, [sp, #0x580]
     ee0:      	str	q2, [sp, #0x570]
     ee4:      	add	x0, sp, #0x570
     ee8:      	ldr	s0, [x0, x13, lsl #2]
     eec:      	ands	w0, w17, #0x1
     ef0:      	tst	w0, w2
     ef4:      	movi	d21, #0000000000000000
     ef8:      	fcsel	s4, s0, s21, ne
     efc:      	and	x2, x8, #0x7
     f00:      	add	x13, sp, #0x4a8
     f04:      	bfxil	x13, x8, #0, #3
     f08:      	ldrb	w8, [x13]
     f0c:      	umov.b	w13, v23[1]
     f10:      	str	q18, [sp, #0x560]
     f14:      	str	q2, [sp, #0x550]
     f18:      	add	x3, sp, #0x550
     f1c:      	ldr	s0, [x3, x2, lsl #2]
     f20:      	and	w8, w13, w8
     f24:      	tst	w8, #0x1
     f28:      	fcsel	s16, s0, s21, ne
     f2c:      	and	x8, x10, #0x7
     f30:      	add	x2, sp, #0x4a8
     f34:      	bfxil	x2, x10, #0, #3
     f38:      	ldrb	w2, [x2]
     f3c:      	umov.b	w10, v23[2]
     f40:      	and	w2, w10, w2
     f44:      	str	q18, [sp, #0x540]
     f48:      	str	q2, [sp, #0x530]
     f4c:      	add	x3, sp, #0x530
     f50:      	ldr	s0, [x3, x8, lsl #2]
     f54:      	tst	w2, #0x1
     f58:      	fcsel	s19, s0, s21, ne
     f5c:      	and	x8, x12, #0x7
     f60:      	add	x2, sp, #0x4a8
     f64:      	bfxil	x2, x12, #0, #3
     f68:      	ldrb	w2, [x2]
     f6c:      	umov.b	w12, v23[3]
     f70:      	and	w2, w12, w2
     f74:      	str	q18, [sp, #0x520]
     f78:      	str	q2, [sp, #0x510]
     f7c:      	add	x3, sp, #0x510
     f80:      	ldr	s0, [x3, x8, lsl #2]
     f84:      	tst	w2, #0x1
     f88:      	mov.s	w8, v20[1]
     f8c:      	fcsel	s22, s0, s21, ne
     f90:      	mov.s	w2, v20[2]
     f94:      	mov.s	w4, v20[3]
     f98:      	fmov	w3, s20
     f9c:      	and	x6, x3, #0x7
     fa0:      	add	x23, sp, #0x4a8
     fa4:      	bfxil	x23, x3, #0, #3
     fa8:      	ldrb	w3, [x23]
     fac:      	umov.b	w30, v23[4]
     fb0:      	and	w3, w30, w3
     fb4:      	str	q18, [sp, #0x600]
     fb8:      	str	q2, [sp, #0x5f0]
     fbc:      	add	x23, sp, #0x5f0
     fc0:      	ldr	s0, [x23, x6, lsl #2]
     fc4:      	tst	w3, #0x1
     fc8:      	fcsel	s0, s0, s21, ne
     fcc:      	and	x6, x8, #0x7
     fd0:      	add	x23, sp, #0x4a8
     fd4:      	bfxil	x23, x8, #0, #3
     fd8:      	umov.b	w3, v23[5]
     fdc:      	ldrb	w8, [x23]
     fe0:      	and	w8, w3, w8
     fe4:      	str	q18, [sp, #0x5e0]
     fe8:      	str	q2, [sp, #0x5d0]
     fec:      	add	x23, sp, #0x5d0
     ff0:      	ldr	s7, [x23, x6, lsl #2]
     ff4:      	tst	w8, #0x1
     ff8:      	fcsel	s7, s7, s21, ne
     ffc:      	and	x8, x2, #0x7
    1000:      	add	x6, sp, #0x4a8
    1004:      	bfxil	x6, x2, #0, #3
    1008:      	ldrb	w6, [x6]
    100c:      	umov.b	w2, v23[6]
    1010:      	str	q18, [sp, #0x5c0]
    1014:      	str	q2, [sp, #0x5b0]
    1018:      	add	x23, sp, #0x5b0
    101c:      	ldr	s17, [x23, x8, lsl #2]
    1020:      	and	w8, w2, w6
    1024:      	tst	w8, #0x1
    1028:      	fcsel	s17, s17, s21, ne
    102c:      	and	x8, x4, #0x7
    1030:      	add	x6, sp, #0x4a8
    1034:      	bfxil	x6, x4, #0, #3
    1038:      	ldrb	w4, [x6]
    103c:      	umov.b	w28, v23[7]
    1040:      	and	w4, w28, w4
    1044:      	str	q18, [sp, #0x5a0]
    1048:      	str	q2, [sp, #0x590]
    104c:      	add	x6, sp, #0x590
    1050:      	ldr	s20, [x6, x8, lsl #2]
    1054:      	tst	w4, #0x1
    1058:      	fcsel	s20, s20, s21, ne
    105c:      	mov.s	v0[1], v7[0]
    1060:      	mov.s	v0[2], v17[0]
    1064:      	mov.s	v0[3], v20[0]
    1068:      	mov.s	v4[1], v16[0]
    106c:      	mov.s	v4[2], v19[0]
    1070:      	mov.s	v4[3], v22[0]
    1074:      	fadd.4s	v2, v2, v4
    1078:      	fadd.4s	v0, v18, v0
    107c:      	movi.4s	v4, #0x2
    1080:      	eor.16b	v3, v3, v4
    1084:      	eor.16b	v1, v1, v4
    1088:      	fmov	w8, s1
    108c:      	add	x4, sp, #0x4a8
    1090:      	bfxil	x4, x8, #0, #3
    1094:      	ldrb	w4, [x4]
    1098:      	and	x8, x8, #0x7
    109c:      	str	q0, [sp, #0x500]
    10a0:      	str	q2, [sp, #0x4f0]
    10a4:      	add	x6, sp, #0x4f0
    10a8:      	ldr	s1, [x6, x8, lsl #2]
    10ac:      	tst	w0, w4
    10b0:      	fcsel	s1, s1, s21, ne
    10b4:      	fmov	w8, s3
    10b8:      	and	x0, x8, #0x7
    10bc:      	add	x4, sp, #0x4a8
    10c0:      	bfxil	x4, x8, #0, #3
    10c4:      	ldrb	w8, [x4]
    10c8:      	and	w8, w30, w8
    10cc:      	str	q0, [sp, #0x4e0]
    10d0:      	str	q2, [sp, #0x4d0]
    10d4:      	add	x4, sp, #0x4d0
    10d8:      	ldr	s3, [x4, x0, lsl #2]
    10dc:      	tst	w8, #0x1
    10e0:      	fcsel	s3, s3, s21, ne
    10e4:      	fadd.4s	v0, v0, v3
    10e8:      	and	w0, w17, w30
    10ec:      	tst	w0, #0x1
    10f0:      	fcsel	s0, s0, s21, ne
    10f4:      	ands	w25, w17, #0x1
    10f8:      	fadd.4s	v1, v2, v1
    10fc:      	fadd	s0, s1, s0
    1100:      	fcsel	s1, s0, s21, ne
    1104:      	tst	w0, #0x1
    1108:      	and	w6, w13, w17
    110c:      	fcsel	s2, s0, s21, ne
    1110:      	tst	w6, #0x1
    1114:      	and	w8, w10, w17
    1118:      	fcsel	s3, s0, s21, ne
    111c:      	str	w8, [sp, #0x80]
    1120:      	tst	w8, #0x1
    1124:      	and	w8, w12, w17
    1128:      	fcsel	s4, s0, s21, ne
    112c:      	str	w8, [sp, #0x70]
    1130:      	tst	w8, #0x1
    1134:      	fcsel	s7, s0, s21, ne
    1138:      	and	w8, w3, w17
    113c:      	str	w8, [sp, #0x60]
    1140:      	tst	w8, #0x1
    1144:      	fcsel	s16, s0, s21, ne
    1148:      	and	w8, w2, w17
    114c:      	str	w8, [sp, #0x40]
    1150:      	tst	w8, #0x1
    1154:      	fcsel	s17, s0, s21, ne
    1158:      	and	w8, w28, w17
    115c:      	str	w8, [sp, #0x50]
    1160:      	tst	w8, #0x1
    1164:      	fcsel	s0, s0, s21, ne
    1168:      	mov.s	v1[1], v3[0]
    116c:      	mov.s	v1[2], v4[0]
    1170:      	mov.s	v1[3], v7[0]
    1174:      	mov.s	v2[1], v16[0]
    1178:      	mov.s	v2[2], v17[0]
    117c:      	mov.s	v2[3], v0[0]
    1180:      	ldr	w8, [sp, #0x90]
    1184:      	rbit	w8, w8
    1188:      	clz	w23, w8
    118c:      	str	q2, [sp, #0x4c0]
    1190:      	str	q1, [sp, #0x4b0]
    1194:      	and	x8, x23, #0x7
    1198:      	add	x4, sp, #0x4b0
    119c:      	ldr	s0, [x4, x8, lsl #2]
    11a0:      	str	q23, [sp, #0x90]
    11a4:      	mov.b	v23[0], wzr
    11a8:      	str	q23, [sp, #0x30]
    11ac:      	fadd	s0, s0, s21
    11b0:      	fmov	s1, w5
    11b4:      	fdiv	s0, s0, s1
    11b8:      	dup.4s	v1, v0[0]
    11bc:      	dup.2d	v0, x20
    11c0:      	ushll2.2d	v2, v5, #0x0
    11c4:      	and.16b	v23, v2, v0
    11c8:      	ushll2.2d	v2, v6, #0x0
    11cc:      	and.16b	v24, v2, v0
    11d0:      	ushll.2d	v2, v5, #0x0
    11d4:      	and.16b	v25, v2, v0
    11d8:      	ushll.2d	v2, v6, #0x0
    11dc:      	and.16b	v26, v2, v0
    11e0:      	movi.2d	v2, #0000000000000000
    11e4:      	movi.2d	v3, #0000000000000000
    11e8:      	movi.2d	v4, #0000000000000000
    11ec:      	movi.2d	v16, #0000000000000000
    11f0:      	lsl	x8, x7, #5
    11f4:      	add	x4, x16, x8
    11f8:      	ldp	q7, q0, [x4]
    11fc:      	fsub.4s	v7, v7, v1
    1200:      	fsub.4s	v0, v0, v1
    1204:      	add	x8, x24, x8
    1208:      	ldp	q17, q18, [x8]
    120c:      	bif.16b	v0, v18, v5
    1210:      	bif.16b	v7, v17, v6
    1214:      	stp	q7, q0, [x8]
    1218:      	add.2d	v3, v3, v24
    121c:      	add.2d	v4, v4, v25
    1220:      	add.2d	v16, v16, v23
    1224:      	add.2d	v2, v2, v26
    1228:      	fmov	x7, d2
    122c:      	cmp	x7, #0x200
    1230:      	b.lt	0x11f0 <ltmp0+0x11f0>
    1234:      	ldr	x4, [sp, #0x108]
    1238:      	add	x8, x16, x4
    123c:      	ldp	q2, q0, [x8]
    1240:      	fsub.4s	v2, v2, v1
    1244:      	fsub.4s	v1, v0, v1
    1248:      	add	x8, x24, x4
    124c:      	ldp	q0, q3, [x8]
    1250:      	zip2.8b	v4, v27, v0
    1254:      	ushll.4s	v4, v4, #0x0
    1258:      	shl.4s	v4, v4, #0x1f
    125c:      	cmlt.4s	v4, v4, #0
    1260:      	stp	q1, q2, [sp, #0x10]
    1264:      	bit.16b	v3, v1, v4
    1268:      	zip1.8b	v4, v27, v0
    126c:      	ushll.4s	v4, v4, #0x0
    1270:      	shl.4s	v4, v4, #0x1f
    1274:      	cmlt.4s	v4, v4, #0
    1278:      	bit.16b	v0, v2, v4
    127c:      	stp	q0, q3, [x8]
    1280:      	ldr	q0, [x16, #0x4090]
    1284:      	ldr	q3, [x16, #0x4080]
    1288:      	fmul.4s	v3, v3, v3
    128c:      	fmul.4s	v0, v0, v0
    1290:      	and.16b	v4, v5, v0
    1294:      	and.16b	v3, v6, v3
    1298:      	ldr	q0, [x16, #0x4070]
    129c:      	ldr	q7, [x16, #0x4060]
    12a0:      	fmul.4s	v7, v7, v7
    12a4:      	fmul.4s	v0, v0, v0
    12a8:      	and.16b	v18, v5, v0
    12ac:      	and.16b	v22, v6, v7
    12b0:      	ldr	q0, [x16, #0x4050]
    12b4:      	ldr	q7, [x16, #0x4040]
    12b8:      	fmul.4s	v7, v7, v7
    12bc:      	fmul.4s	v0, v0, v0
    12c0:      	and.16b	v19, v5, v0
    12c4:      	and.16b	v20, v6, v7
    12c8:      	add	x8, x24, x11
    12cc:      	ldp	q7, q0, [x8]
    12d0:      	fmul.4s	v7, v7, v7
    12d4:      	fmul.4s	v0, v0, v0
    12d8:      	and.16b	v28, v5, v0
    12dc:      	and.16b	v16, v6, v7
    12e0:      	mov	w11, #0x4               ; =4
    12e4:      	sshll.2d	v0, v6, #0x0
    12e8:      	sshll.2d	v7, v5, #0x0
    12ec:      	add	x8, x24, x14, lsl #5
    12f0:      	ldp	q21, q17, [x8]
    12f4:      	and.16b	v21, v6, v21
    12f8:      	and.16b	v17, v5, v17
    12fc:      	fmul.4s	v17, v17, v17
    1300:      	fmul.4s	v21, v21, v21
    1304:      	fadd.4s	v27, v16, v21
    1308:      	fadd.4s	v29, v28, v17
    130c:      	ldp	q21, q17, [x8, #0x20]
    1310:      	and.16b	v21, v6, v21
    1314:      	and.16b	v17, v5, v17
    1318:      	fmul.4s	v17, v17, v17
    131c:      	fmul.4s	v21, v21, v21
    1320:      	fadd.4s	v21, v20, v21
    1324:      	fadd.4s	v17, v19, v17
    1328:      	ldp	q13, q11, [x8, #0x40]
    132c:      	and.16b	v13, v6, v13
    1330:      	and.16b	v11, v5, v11
    1334:      	fmul.4s	v11, v11, v11
    1338:      	fmul.4s	v13, v13, v13
    133c:      	fadd.4s	v13, v22, v13
    1340:      	fadd.4s	v11, v18, v11
    1344:      	ldp	q1, q2, [x8, #0x60]
    1348:      	and.16b	v1, v6, v1
    134c:      	and.16b	v2, v5, v2
    1350:      	fmul.4s	v2, v2, v2
    1354:      	fmul.4s	v1, v1, v1
    1358:      	fadd.4s	v1, v3, v1
    135c:      	fadd.4s	v2, v4, v2
    1360:      	dup.2d	v15, x11
    1364:      	and.16b	v8, v10, v15
    1368:      	add.2d	v31, v31, v8
    136c:      	and.16b	v8, v9, v15
    1370:      	add.2d	v12, v12, v8
    1374:      	and.16b	v7, v7, v15
    1378:      	add.2d	v30, v30, v7
    137c:      	and.16b	v0, v0, v15
    1380:      	add.2d	v14, v14, v0
    1384:      	bit.16b	v28, v29, v5
    1388:      	bit.16b	v16, v27, v6
    138c:      	bit.16b	v19, v17, v5
    1390:      	bit.16b	v20, v21, v6
    1394:      	bit.16b	v18, v11, v5
    1398:      	bit.16b	v22, v13, v6
    139c:      	bit.16b	v4, v2, v5
    13a0:      	bit.16b	v3, v1, v6
    13a4:      	fmov	x14, d14
    13a8:      	cmp	x14, #0x200
    13ac:      	b.lt	0x12e4 <ltmp0+0x12e4>
    13b0:      	mov	x8, #0x0                ; =0
    13b4:      	movi.2d	v9, #0000000000000000
    13b8:      	movi.2d	v10, #0000000000000000
    13bc:      	movi.2d	v11, #0000000000000000
    13c0:      	movi.2d	v12, #0000000000000000
    13c4:      	movi	d30, #0000000000000000
    13c8:      	ldr	q31, [sp, #0x150]
    13cc:      	ldr	q8, [sp, #0x180]
    13d0:      	b	0x1404 <ltmp0+0x1404>
    13d4:      	add	x8, x27, x11
    13d8:      	ldp	q0, q1, [x8]
    13dc:      	bit.16b	v1, v14, v5
    13e0:      	bit.16b	v0, v13, v6
    13e4:      	stp	q0, q1, [x8]
    13e8:      	add.2d	v10, v10, v24
    13ec:      	add.2d	v11, v11, v25
    13f0:      	add.2d	v12, v12, v23
    13f4:      	add.2d	v9, v9, v26
    13f8:      	fmov	x8, d9
    13fc:      	cmp	x8, #0x200
    1400:      	b.ge	0x14a0 <ltmp0+0x14a0>
    1404:      	fmov	w16, s31
    1408:      	lsl	x11, x8, #5
    140c:      	add	x14, x15, x11
    1410:      	movi.2d	v13, #0000000000000000
    1414:      	movi.2d	v14, #0000000000000000
    1418:      	tbnz	w16, #0x0, 0x1440 <ltmp0+0x1440>
    141c:      	and	w16, w16, #0xff
    1420:      	tbnz	w16, #0x1, 0x144c <ltmp0+0x144c>
    1424:      	tbnz	w16, #0x2, 0x1458 <ltmp0+0x1458>
    1428:      	tbnz	w16, #0x3, 0x1464 <ltmp0+0x1464>
    142c:      	tbnz	w16, #0x4, 0x1470 <ltmp0+0x1470>
    1430:      	tbnz	w16, #0x5, 0x147c <ltmp0+0x147c>
    1434:      	tbnz	w16, #0x6, 0x1488 <ltmp0+0x1488>
    1438:      	tbz	w16, #0x7, 0x13d4 <ltmp0+0x13d4>
    143c:      	b	0x1494 <ltmp0+0x1494>
    1440:      	ldr	s13, [x14]
    1444:      	and	w16, w16, #0xff
    1448:      	tbz	w16, #0x1, 0x1424 <ltmp0+0x1424>
    144c:      	add	x8, x14, #0x4
    1450:      	ld1.s	{ v13 }[1], [x8]
    1454:      	tbz	w16, #0x2, 0x1428 <ltmp0+0x1428>
    1458:      	add	x8, x14, #0x8
    145c:      	ld1.s	{ v13 }[2], [x8]
    1460:      	tbz	w16, #0x3, 0x142c <ltmp0+0x142c>
    1464:      	add	x8, x14, #0xc
    1468:      	ld1.s	{ v13 }[3], [x8]
    146c:      	tbz	w16, #0x4, 0x1430 <ltmp0+0x1430>
    1470:      	add	x8, x14, #0x10
    1474:      	ld1.s	{ v14 }[0], [x8]
    1478:      	tbz	w16, #0x5, 0x1434 <ltmp0+0x1434>
    147c:      	add	x8, x14, #0x14
    1480:      	ld1.s	{ v14 }[1], [x8]
    1484:      	tbz	w16, #0x6, 0x1438 <ltmp0+0x1438>
    1488:      	add	x8, x14, #0x18
    148c:      	ld1.s	{ v14 }[2], [x8]
    1490:      	tbz	w16, #0x7, 0x13d4 <ltmp0+0x13d4>
    1494:      	add	x8, x14, #0x1c
    1498:      	ld1.s	{ v14 }[3], [x8]
    149c:      	b	0x13d4 <ltmp0+0x13d4>
    14a0:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    14a4:      	ldr	q0, [x8]
    14a8:      	and.16b	v10, v5, v0
    14ac:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    14b0:      	ldr	q0, [x8]
    14b4:      	and.16b	v11, v6, v0
    14b8:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    14bc:      	ldr	q0, [x8]
    14c0:      	and.16b	v9, v6, v0
    14c4:      	zip2.8b	v0, v8, v0
    14c8:      	ushll.4s	v0, v0, #0x0
    14cc:      	shl.4s	v0, v0, #0x1f
    14d0:      	cmlt.4s	v0, v0, #0
    14d4:      	ldp	q1, q7, [sp, #0x10]
    14d8:      	and.16b	v1, v0, v1
    14dc:      	zip1.8b	v2, v8, v0
    14e0:      	ushll.4s	v2, v2, #0x0
    14e4:      	shl.4s	v2, v2, #0x1f
    14e8:      	cmlt.4s	v2, v2, #0
    14ec:      	and.16b	v7, v2, v7
    14f0:      	fmul.4s	v7, v7, v7
    14f4:      	fmul.4s	v1, v1, v1
    14f8:      	fadd.4s	v1, v1, v28
    14fc:      	fadd.4s	v7, v7, v16
    1500:      	and.16b	v2, v2, v7
    1504:      	and.16b	v0, v0, v1
    1508:      	ldr	q7, [sp, #0x30]
    150c:      	zip2.8b	v1, v7, v0
    1510:      	ushll.4s	v1, v1, #0x0
    1514:      	shl.4s	v1, v1, #0x1f
    1518:      	cmlt.4s	v1, v1, #0
    151c:      	bit.16b	v0, v29, v1
    1520:      	zip1.8b	v1, v7, v0
    1524:      	ushll.4s	v1, v1, #0x0
    1528:      	shl.4s	v1, v1, #0x1f
    152c:      	cmlt.4s	v1, v1, #0
    1530:      	bsl.16b	v1, v27, v2
    1534:      	fadd.4s	v1, v20, v1
    1538:      	fadd.4s	v0, v19, v0
    153c:      	fadd.4s	v0, v18, v0
    1540:      	fadd.4s	v1, v22, v1
    1544:      	fadd.4s	v1, v3, v1
    1548:      	fadd.4s	v2, v4, v0
    154c:      	fmov	w8, s11
    1550:      	add	x11, sp, #0x218
    1554:      	bfxil	x11, x8, #0, #3
    1558:      	ldr	q0, [sp, #0x90]
    155c:      	str	d0, [sp, #0x218]
    1560:      	ldrb	w11, [x11]
    1564:      	add	x14, sp, #0x480
    1568:      	orr	x8, x14, x8, lsl #2
    156c:      	str	q2, [sp, #0x490]
    1570:      	str	q1, [sp, #0x480]
    1574:      	ldr	s0, [x8]
    1578:      	tst	w25, w11
    157c:      	fcsel	s3, s0, s30, ne
    1580:      	mov.s	w8, v11[1]
    1584:      	add	x11, sp, #0x218
    1588:      	bfxil	x11, x8, #0, #3
    158c:      	ldrb	w8, [x11]
    1590:      	and	w8, w13, w8
    1594:      	str	q1, [sp, #0x460]
    1598:      	ldr	s0, [sp, #0x460]
    159c:      	tst	w8, #0x1
    15a0:      	fcsel	s4, s0, s30, ne
    15a4:      	mov.s	w8, v11[2]
    15a8:      	add	x11, sp, #0x218
    15ac:      	bfxil	x11, x8, #0, #3
    15b0:      	add	x14, sp, #0x440
    15b4:      	orr	x8, x14, x8, lsl #2
    15b8:      	ldrb	w11, [x11]
    15bc:      	and	w11, w10, w11
    15c0:      	str	q2, [sp, #0x450]
    15c4:      	str	q1, [sp, #0x440]
    15c8:      	ldr	s0, [x8]
    15cc:      	tst	w11, #0x1
    15d0:      	fcsel	s16, s0, s30, ne
    15d4:      	mov.s	w8, v11[3]
    15d8:      	add	x11, sp, #0x218
    15dc:      	bfxil	x11, x8, #0, #3
    15e0:      	add	x14, sp, #0x420
    15e4:      	orr	x8, x14, x8, lsl #2
    15e8:      	ldrb	w11, [x11]
    15ec:      	and	w11, w12, w11
    15f0:      	str	q2, [sp, #0x430]
    15f4:      	str	q1, [sp, #0x420]
    15f8:      	ldr	s0, [x8]
    15fc:      	tst	w11, #0x1
    1600:      	fcsel	s18, s0, s30, ne
    1604:      	fmov	w8, s10
    1608:      	add	x11, sp, #0x218
    160c:      	bfxil	x11, x8, #0, #3
    1610:      	ldrb	w11, [x11]
    1614:      	and	w11, w30, w11
    1618:      	str	q2, [sp, #0x410]
    161c:      	str	q1, [sp, #0x400]
    1620:      	add	x14, sp, #0x400
    1624:      	ldr	s0, [x14, w8, uxtw #2]
    1628:      	tst	w11, #0x1
    162c:      	fcsel	s0, s0, s30, ne
    1630:      	mov.s	w8, v10[1]
    1634:      	add	x11, sp, #0x218
    1638:      	bfxil	x11, x8, #0, #3
    163c:      	ldrb	w11, [x11]
    1640:      	and	w11, w3, w11
    1644:      	stp	q1, q2, [sp, #0x3e0]
    1648:      	add	x14, sp, #0x3e0
    164c:      	ldr	s7, [x14, w8, uxtw #2]
    1650:      	tst	w11, #0x1
    1654:      	fcsel	s7, s7, s30, ne
    1658:      	mov.s	w8, v10[2]
    165c:      	add	x11, sp, #0x218
    1660:      	bfxil	x11, x8, #0, #3
    1664:      	ldrb	w11, [x11]
    1668:      	and	w11, w2, w11
    166c:      	stp	q1, q2, [sp, #0x3c0]
    1670:      	add	x14, sp, #0x3c0
    1674:      	ldr	s17, [x14, w8, uxtw #2]
    1678:      	tst	w11, #0x1
    167c:      	fcsel	s17, s17, s30, ne
    1680:      	mov.s	w8, v10[3]
    1684:      	add	x11, sp, #0x218
    1688:      	bfxil	x11, x8, #0, #3
    168c:      	ldrb	w11, [x11]
    1690:      	and	w11, w28, w11
    1694:      	stp	q1, q2, [sp, #0x3a0]
    1698:      	add	x14, sp, #0x3a0
    169c:      	ldr	s19, [x14, w8, uxtw #2]
    16a0:      	tst	w11, #0x1
    16a4:      	fcsel	s19, s19, s30, ne
    16a8:      	mov.s	v0[1], v7[0]
    16ac:      	mov.s	v0[2], v17[0]
    16b0:      	mov.s	v0[3], v19[0]
    16b4:      	mov.s	v3[1], v4[0]
    16b8:      	mov.s	v3[2], v16[0]
    16bc:      	mov.s	v3[3], v18[0]
    16c0:      	fadd.4s	v1, v1, v3
    16c4:      	fadd.4s	v2, v2, v0
    16c8:      	fmov	w8, s9
    16cc:      	add	x11, sp, #0x218
    16d0:      	bfxil	x11, x8, #0, #3
    16d4:      	ldrb	w11, [x11]
    16d8:      	add	x14, sp, #0x380
    16dc:      	orr	x8, x14, x8, lsl #2
    16e0:      	stp	q1, q2, [sp, #0x380]
    16e4:      	ldr	s0, [x8]
    16e8:      	mov.s	w8, v9[1]
    16ec:      	tst	w25, w11
    16f0:      	add	x11, sp, #0x218
    16f4:      	bfxil	x11, x8, #0, #3
    16f8:      	ldrb	w11, [x11]
    16fc:      	and	w11, w13, w11
    1700:      	fcsel	s3, s0, s30, ne
    1704:      	add	x13, sp, #0x360
    1708:      	orr	x8, x13, x8, lsl #2
    170c:      	stp	q1, q2, [sp, #0x360]
    1710:      	ldr	s0, [x8]
    1714:      	mov.s	w8, v9[2]
    1718:      	tst	w11, #0x1
    171c:      	add	x11, sp, #0x218
    1720:      	bfxil	x11, x8, #0, #3
    1724:      	fcsel	s4, s0, s30, ne
    1728:      	ldrb	w8, [x11]
    172c:      	and	w8, w10, w8
    1730:      	str	q1, [sp, #0x340]
    1734:      	tst	w8, #0x1
    1738:      	mov.s	w8, v9[3]
    173c:      	add	x10, sp, #0x218
    1740:      	bfxil	x10, x8, #0, #3
    1744:      	ldrb	w10, [x10]
    1748:      	and	w10, w12, w10
    174c:      	adrp	x11, 0x1000 <ltmp0+0x1000>
    1750:      	ldr	q0, [x11]
    1754:      	and.16b	v0, v5, v0
    1758:      	ldr	s7, [sp, #0x340]
    175c:      	fcsel	s16, s7, s30, ne
    1760:      	add	x11, sp, #0x320
    1764:      	orr	x8, x11, x8, lsl #2
    1768:      	stp	q1, q2, [sp, #0x320]
    176c:      	ldr	s7, [x8]
    1770:      	tst	w10, #0x1
    1774:      	fmov	w8, s0
    1778:      	add	x10, sp, #0x218
    177c:      	bfxil	x10, x8, #0, #3
    1780:      	ldrb	w10, [x10]
    1784:      	and	w10, w30, w10
    1788:      	fcsel	s18, s7, s30, ne
    178c:      	stp	q1, q2, [sp, #0x300]
    1790:      	add	x11, sp, #0x300
    1794:      	ldr	s7, [x11, w8, uxtw #2]
    1798:      	tst	w10, #0x1
    179c:      	mov.s	w8, v0[1]
    17a0:      	add	x10, sp, #0x218
    17a4:      	bfxil	x10, x8, #0, #3
    17a8:      	ldrb	w10, [x10]
    17ac:      	and	w10, w3, w10
    17b0:      	fcsel	s19, s7, s30, ne
    17b4:      	stp	q1, q2, [sp, #0x2e0]
    17b8:      	add	x11, sp, #0x2e0
    17bc:      	ldr	s7, [x11, w8, uxtw #2]
    17c0:      	tst	w10, #0x1
    17c4:      	mov.s	w8, v0[2]
    17c8:      	add	x10, sp, #0x218
    17cc:      	bfxil	x10, x8, #0, #3
    17d0:      	ldrb	w10, [x10]
    17d4:      	and	w10, w2, w10
    17d8:      	fcsel	s7, s7, s30, ne
    17dc:      	stp	q1, q2, [sp, #0x2c0]
    17e0:      	add	x11, sp, #0x2c0
    17e4:      	ldr	s17, [x11, w8, uxtw #2]
    17e8:      	tst	w10, #0x1
    17ec:      	mov.s	w8, v0[3]
    17f0:      	add	x10, sp, #0x218
    17f4:      	bfxil	x10, x8, #0, #3
    17f8:      	ldrb	w10, [x10]
    17fc:      	and	w10, w28, w10
    1800:      	movi.4s	v0, #0x4
    1804:      	and.16b	v0, v6, v0
    1808:      	fcsel	s17, s17, s30, ne
    180c:      	stp	q1, q2, [sp, #0x2a0]
    1810:      	add	x11, sp, #0x2a0
    1814:      	ldr	s20, [x11, w8, uxtw #2]
    1818:      	tst	w10, #0x1
    181c:      	fcsel	s20, s20, s30, ne
    1820:      	fmov	w8, s0
    1824:      	add	x10, sp, #0x218
    1828:      	orr	x10, x10, x8
    182c:      	ldrb	w10, [x10]
    1830:      	tst	w25, w10
    1834:      	mov.s	v19[1], v7[0]
    1838:      	mov.s	v19[2], v17[0]
    183c:      	mov.s	v19[3], v20[0]
    1840:      	mov.s	v3[1], v4[0]
    1844:      	mov.s	v3[2], v16[0]
    1848:      	mov.s	v3[3], v18[0]
    184c:      	fadd.4s	v0, v1, v3
    1850:      	fadd.4s	v1, v2, v19
    1854:      	stp	q0, q1, [sp, #0x280]
    1858:      	add	x10, sp, #0x280
    185c:      	ldr	s1, [x10, w8, uxtw #2]
    1860:      	fcsel	s1, s1, s30, ne
    1864:      	tst	w17, #0x1
    1868:      	fadd	s0, s0, s1
    186c:      	fcsel	s1, s0, s30, ne
    1870:      	tst	w6, #0x1
    1874:      	fcsel	s2, s0, s30, ne
    1878:      	ldr	w8, [sp, #0x80]
    187c:      	tst	w8, #0x1
    1880:      	fcsel	s3, s0, s30, ne
    1884:      	ldr	w8, [sp, #0x70]
    1888:      	tst	w8, #0x1
    188c:      	fcsel	s4, s0, s30, ne
    1890:      	tst	w0, #0x1
    1894:      	fcsel	s7, s0, s30, ne
    1898:      	ldr	w8, [sp, #0x60]
    189c:      	tst	w8, #0x1
    18a0:      	fcsel	s16, s0, s30, ne
    18a4:      	ldr	w8, [sp, #0x40]
    18a8:      	tst	w8, #0x1
    18ac:      	shl.8b	v17, v8, #0x7
    18b0:      	cmlt.8b	v17, v17, #0
    18b4:      	fcsel	s18, s0, s30, ne
    18b8:      	ldr	w8, [sp, #0x50]
    18bc:      	tst	w8, #0x1
    18c0:      	fcsel	s0, s0, s30, ne
    18c4:      	mov.s	v1[1], v2[0]
    18c8:      	mov.s	v1[2], v3[0]
    18cc:      	mov.s	v1[3], v4[0]
    18d0:      	mov.s	v7[1], v16[0]
    18d4:      	mov.s	v7[2], v18[0]
    18d8:      	mov.s	v7[3], v0[0]
    18dc:      	ldr	d0, [sp, #0xd8]
    18e0:      	and.8b	v0, v17, v0
    18e4:      	stp	q1, q7, [sp, #0x260]
    18e8:      	and	x8, x23, #0x7
    18ec:      	add	x10, sp, #0x260
    18f0:      	ldr	s1, [x10, x8, lsl #2]
    18f4:      	addv.8b	b28, v0
    18f8:      	mov	b0, v8[0]
    18fc:      	mov.b	v0[4], v8[1]
    1900:      	ushll.2d	v0, v0, #0x0
    1904:      	shl.2d	v0, v0, #0x3f
    1908:      	cmlt.2d	v0, v0, #0
    190c:      	ldr	q2, [sp, #0xe0]
    1910:      	and.16b	v0, v0, v2
    1914:      	mov	b2, v8[2]
    1918:      	mov.b	v2[4], v8[3]
    191c:      	ushll.2d	v2, v2, #0x0
    1920:      	shl.2d	v2, v2, #0x3f
    1924:      	cmlt.2d	v2, v2, #0
    1928:      	ldp	q3, q7, [sp, #0xa0]
    192c:      	and.16b	v2, v2, v3
    1930:      	mov	b3, v8[4]
    1934:      	mov.b	v3[4], v8[5]
    1938:      	ushll.2d	v3, v3, #0x0
    193c:      	shl.2d	v3, v3, #0x3f
    1940:      	cmlt.2d	v3, v3, #0
    1944:      	mov	b4, v8[6]
    1948:      	mov.b	v4[4], v8[7]
    194c:      	and.16b	v3, v3, v7
    1950:      	ushll.2d	v4, v4, #0x0
    1954:      	shl.2d	v4, v4, #0x3f
    1958:      	cmlt.2d	v4, v4, #0
    195c:      	ldr	q7, [sp, #0xc0]
    1960:      	and.16b	v4, v4, v7
    1964:      	stp	q3, q4, [sp, #0x240]
    1968:      	stp	q0, q2, [sp, #0x220]
    196c:      	ldr	x14, [sp, #0x168]
    1970:      	and	x8, x14, #0x7
    1974:      	add	x10, sp, #0x220
    1978:      	ldr	x8, [x10, x8, lsl #3]
    197c:      	fmov	w11, s28
    1980:      	sub	x8, x8, x14
    1984:      	lsl	x10, x8, #2
    1988:      	add	x12, x15, x10
    198c:      	movi.2d	v2, #0000000000000000
    1990:      	movi.2d	v3, #0000000000000000
    1994:      	tbnz	w11, #0x0, 0x1dd4 <ltmp0+0x1dd4>
    1998:      	ldr	x2, [sp, #0x198]
    199c:      	ldr	w30, [sp, #0x1bc]
    19a0:      	ldr	q17, [sp, #0x170]
    19a4:      	tbnz	w11, #0x1, 0x1de8 <ltmp0+0x1de8>
    19a8:      	tbnz	w11, #0x2, 0x1df4 <ltmp0+0x1df4>
    19ac:      	tbnz	w11, #0x3, 0x1e00 <ltmp0+0x1e00>
    19b0:      	tbnz	w11, #0x4, 0x1e0c <ltmp0+0x1e0c>
    19b4:      	tbnz	w11, #0x5, 0x1e18 <ltmp0+0x1e18>
    19b8:      	tbnz	w11, #0x6, 0x1e24 <ltmp0+0x1e24>
    19bc:      	tbz	w11, #0x7, 0x19c8 <ltmp0+0x19c8>
    19c0:      	add	x8, x12, #0x1c
    19c4:      	ld1.s	{ v3 }[3], [x8]
    19c8:      	fadd	s0, s1, s30
    19cc:      	fmov	s1, w5
    19d0:      	fdiv	s0, s0, s1
    19d4:      	add	x8, x27, x4
    19d8:      	ldp	q1, q4, [x8]
    19dc:      	zip2.8b	v7, v8, v0
    19e0:      	ushll.4s	v7, v7, #0x0
    19e4:      	shl.4s	v7, v7, #0x1f
    19e8:      	cmlt.4s	v7, v7, #0
    19ec:      	bif.16b	v3, v4, v7
    19f0:      	zip1.8b	v4, v8, v0
    19f4:      	ushll.4s	v4, v4, #0x0
    19f8:      	shl.4s	v4, v4, #0x1f
    19fc:      	cmlt.4s	v4, v4, #0
    1a00:      	bit.16b	v1, v2, v4
    1a04:      	stp	q1, q3, [x8]
    1a08:      	fmov	s1, w19
    1a0c:      	fadd	s0, s0, s1
    1a10:      	fsqrt	s27, s0
    1a14:      	subs	x8, x26, x9
    1a18:      	mov	w11, #0x4003            ; =16387
    1a1c:      	ccmp	x8, x11, #0x0, hs
    1a20:      	cset	w8, hi
    1a24:      	sub	x11, x9, x26
    1a28:      	mov	w12, #0xfff             ; =4095
    1a2c:      	movk	w12, #0x100, lsl #16
    1a30:      	cmp	x11, x12
    1a34:      	ccmp	x9, x26, #0x0, hi
    1a38:      	b.hs	0x1b24 <ltmp0+0x1b24>
    1a3c:      	tbnz	w8, #0x0, 0x1b24 <ltmp0+0x1b24>
    1a40:      	mov	x8, #0x0                ; =0
    1a44:      	movi.2d	v1, #0000000000000000
    1a48:      	movi.2d	v2, #0000000000000000
    1a4c:      	movi.2d	v3, #0000000000000000
    1a50:      	movi.2d	v4, #0000000000000000
    1a54:      	b	0x1a88 <ltmp0+0x1a88>
    1a58:      	add	x8, x1, x11
    1a5c:      	ldp	q0, q7, [x8]
    1a60:      	bit.16b	v7, v18, v5
    1a64:      	bit.16b	v0, v16, v6
    1a68:      	stp	q0, q7, [x8]
    1a6c:      	add.2d	v2, v2, v24
    1a70:      	add.2d	v3, v3, v25
    1a74:      	add.2d	v4, v4, v23
    1a78:      	add.2d	v1, v1, v26
    1a7c:      	fmov	x8, d1
    1a80:      	cmp	x8, #0x200
    1a84:      	b.ge	0x1e34 <ltmp0+0x1e34>
    1a88:      	fmov	w13, s31
    1a8c:      	lsl	x11, x8, #5
    1a90:      	add	x12, x9, x11
    1a94:      	movi.2d	v16, #0000000000000000
    1a98:      	movi.2d	v18, #0000000000000000
    1a9c:      	tbnz	w13, #0x0, 0x1ac4 <ltmp0+0x1ac4>
    1aa0:      	and	w13, w13, #0xff
    1aa4:      	tbnz	w13, #0x1, 0x1ad0 <ltmp0+0x1ad0>
    1aa8:      	tbnz	w13, #0x2, 0x1adc <ltmp0+0x1adc>
    1aac:      	tbnz	w13, #0x3, 0x1ae8 <ltmp0+0x1ae8>
    1ab0:      	tbnz	w13, #0x4, 0x1af4 <ltmp0+0x1af4>
    1ab4:      	tbnz	w13, #0x5, 0x1b00 <ltmp0+0x1b00>
    1ab8:      	tbnz	w13, #0x6, 0x1b0c <ltmp0+0x1b0c>
    1abc:      	tbz	w13, #0x7, 0x1a58 <ltmp0+0x1a58>
    1ac0:      	b	0x1b18 <ltmp0+0x1b18>
    1ac4:      	ldr	s16, [x12]
    1ac8:      	and	w13, w13, #0xff
    1acc:      	tbz	w13, #0x1, 0x1aa8 <ltmp0+0x1aa8>
    1ad0:      	add	x8, x12, #0x4
    1ad4:      	ld1.s	{ v16 }[1], [x8]
    1ad8:      	tbz	w13, #0x2, 0x1aac <ltmp0+0x1aac>
    1adc:      	add	x8, x12, #0x8
    1ae0:      	ld1.s	{ v16 }[2], [x8]
    1ae4:      	tbz	w13, #0x3, 0x1ab0 <ltmp0+0x1ab0>
    1ae8:      	add	x8, x12, #0xc
    1aec:      	ld1.s	{ v16 }[3], [x8]
    1af0:      	tbz	w13, #0x4, 0x1ab4 <ltmp0+0x1ab4>
    1af4:      	add	x8, x12, #0x10
    1af8:      	ld1.s	{ v18 }[0], [x8]
    1afc:      	tbz	w13, #0x5, 0x1ab8 <ltmp0+0x1ab8>
    1b00:      	add	x8, x12, #0x14
    1b04:      	ld1.s	{ v18 }[1], [x8]
    1b08:      	tbz	w13, #0x6, 0x1abc <ltmp0+0x1abc>
    1b0c:      	add	x8, x12, #0x18
    1b10:      	ld1.s	{ v18 }[2], [x8]
    1b14:      	tbz	w13, #0x7, 0x1a58 <ltmp0+0x1a58>
    1b18:      	add	x8, x12, #0x1c
    1b1c:      	ld1.s	{ v18 }[3], [x8]
    1b20:      	b	0x1a58 <ltmp0+0x1a58>
    1b24:      	mov	x11, #0x0               ; =0
    1b28:      	ldr	q0, [sp, #0xf0]
    1b2c:      	add.2d	v1, v0, v17
    1b30:      	dup.4s	v22, v27[0]
    1b34:      	movi.2d	v2, #0000000000000000
    1b38:      	movi.2d	v3, #0000000000000000
    1b3c:      	movi.2d	v4, #0000000000000000
    1b40:      	movi.2d	v16, #0000000000000000
    1b44:      	b	0x1b64 <ltmp0+0x1b64>
    1b48:      	add.2d	v3, v3, v24
    1b4c:      	add.2d	v4, v4, v25
    1b50:      	add.2d	v16, v16, v23
    1b54:      	add.2d	v2, v2, v26
    1b58:      	fmov	x11, d2
    1b5c:      	cmp	x11, #0x200
    1b60:      	b.ge	0x1ce8 <ltmp0+0x1ce8>
    1b64:      	fmov	w8, s31
    1b68:      	shl.2d	v19, v2, #0x3
    1b6c:      	orr.16b	v0, v19, v17
    1b70:      	fmov	x12, d0
    1b74:      	add	x12, x9, x12, lsl #2
    1b78:      	movi.2d	v20, #0000000000000000
    1b7c:      	movi.2d	v18, #0000000000000000
    1b80:      	tbnz	w8, #0x0, 0x1c20 <ltmp0+0x1c20>
    1b84:      	and	w13, w8, #0xff
    1b88:      	tbnz	w13, #0x1, 0x1c2c <ltmp0+0x1c2c>
    1b8c:      	tbnz	w13, #0x2, 0x1c38 <ltmp0+0x1c38>
    1b90:      	tbnz	w13, #0x3, 0x1c44 <ltmp0+0x1c44>
    1b94:      	tbnz	w13, #0x4, 0x1c50 <ltmp0+0x1c50>
    1b98:      	tbnz	w13, #0x5, 0x1c5c <ltmp0+0x1c5c>
    1b9c:      	tbnz	w13, #0x6, 0x1c68 <ltmp0+0x1c68>
    1ba0:      	tbz	w13, #0x7, 0x1bac <ltmp0+0x1bac>
    1ba4:      	add	x8, x12, #0x1c
    1ba8:      	ld1.s	{ v18 }[3], [x8]
    1bac:      	lsl	x8, x11, #5
    1bb0:      	add	x11, x24, x8
    1bb4:      	ldp	q0, q27, [x11]
    1bb8:      	and.16b	v0, v6, v0
    1bbc:      	fdiv.4s	v0, v0, v22
    1bc0:      	add	x8, x27, x8
    1bc4:      	ldp	q7, q29, [x8]
    1bc8:      	and.16b	v7, v6, v7
    1bcc:      	fmul.4s	v0, v0, v7
    1bd0:      	fmov	w11, s31
    1bd4:      	fadd.4s	v20, v20, v0
    1bd8:      	add.2d	v0, v1, v19
    1bdc:      	fmov	x8, d0
    1be0:      	add	x8, x26, x8, lsl #2
    1be4:      	tbnz	w11, #0x0, 0x1c78 <ltmp0+0x1c78>
    1be8:      	and	w11, w11, #0xff
    1bec:      	tbnz	w11, #0x1, 0x1c84 <ltmp0+0x1c84>
    1bf0:      	tbnz	w11, #0x2, 0x1c90 <ltmp0+0x1c90>
    1bf4:      	tbnz	w11, #0x3, 0x1c9c <ltmp0+0x1c9c>
    1bf8:      	and.16b	v0, v5, v27
    1bfc:      	fdiv.4s	v0, v0, v22
    1c00:      	and.16b	v7, v5, v29
    1c04:      	fmul.4s	v0, v0, v7
    1c08:      	fadd.4s	v18, v18, v0
    1c0c:      	tbnz	w11, #0x4, 0x1cbc <ltmp0+0x1cbc>
    1c10:      	tbnz	w11, #0x5, 0x1cc4 <ltmp0+0x1cc4>
    1c14:      	tbnz	w11, #0x6, 0x1cd0 <ltmp0+0x1cd0>
    1c18:      	tbz	w11, #0x7, 0x1b48 <ltmp0+0x1b48>
    1c1c:      	b	0x1cdc <ltmp0+0x1cdc>
    1c20:      	ldr	s20, [x12]
    1c24:      	and	w13, w8, #0xff
    1c28:      	tbz	w13, #0x1, 0x1b8c <ltmp0+0x1b8c>
    1c2c:      	add	x8, x12, #0x4
    1c30:      	ld1.s	{ v20 }[1], [x8]
    1c34:      	tbz	w13, #0x2, 0x1b90 <ltmp0+0x1b90>
    1c38:      	add	x8, x12, #0x8
    1c3c:      	ld1.s	{ v20 }[2], [x8]
    1c40:      	tbz	w13, #0x3, 0x1b94 <ltmp0+0x1b94>
    1c44:      	add	x8, x12, #0xc
    1c48:      	ld1.s	{ v20 }[3], [x8]
    1c4c:      	tbz	w13, #0x4, 0x1b98 <ltmp0+0x1b98>
    1c50:      	add	x8, x12, #0x10
    1c54:      	ld1.s	{ v18 }[0], [x8]
    1c58:      	tbz	w13, #0x5, 0x1b9c <ltmp0+0x1b9c>
    1c5c:      	add	x8, x12, #0x14
    1c60:      	ld1.s	{ v18 }[1], [x8]
    1c64:      	tbz	w13, #0x6, 0x1ba0 <ltmp0+0x1ba0>
    1c68:      	add	x8, x12, #0x18
    1c6c:      	ld1.s	{ v18 }[2], [x8]
    1c70:      	tbnz	w13, #0x7, 0x1ba4 <ltmp0+0x1ba4>
    1c74:      	b	0x1bac <ltmp0+0x1bac>
    1c78:      	str	s20, [x8]
    1c7c:      	and	w11, w11, #0xff
    1c80:      	tbz	w11, #0x1, 0x1bf0 <ltmp0+0x1bf0>
    1c84:      	add	x12, x8, #0x4
    1c88:      	st1.s	{ v20 }[1], [x12]
    1c8c:      	tbz	w11, #0x2, 0x1bf4 <ltmp0+0x1bf4>
    1c90:      	add	x12, x8, #0x8
    1c94:      	st1.s	{ v20 }[2], [x12]
    1c98:      	tbz	w11, #0x3, 0x1bf8 <ltmp0+0x1bf8>
    1c9c:      	add	x12, x8, #0xc
    1ca0:      	st1.s	{ v20 }[3], [x12]
    1ca4:      	and.16b	v0, v5, v27
    1ca8:      	fdiv.4s	v0, v0, v22
    1cac:      	and.16b	v7, v5, v29
    1cb0:      	fmul.4s	v0, v0, v7
    1cb4:      	fadd.4s	v18, v18, v0
    1cb8:      	tbz	w11, #0x4, 0x1c10 <ltmp0+0x1c10>
    1cbc:      	str	s18, [x8, #0x10]
    1cc0:      	tbz	w11, #0x5, 0x1c14 <ltmp0+0x1c14>
    1cc4:      	add	x12, x8, #0x14
    1cc8:      	st1.s	{ v18 }[1], [x12]
    1ccc:      	tbz	w11, #0x6, 0x1c18 <ltmp0+0x1c18>
    1cd0:      	add	x12, x8, #0x18
    1cd4:      	st1.s	{ v18 }[2], [x12]
    1cd8:      	tbz	w11, #0x7, 0x1b48 <ltmp0+0x1b48>
    1cdc:      	add	x8, x8, #0x1c
    1ce0:      	st1.s	{ v18 }[3], [x8]
    1ce4:      	b	0x1b48 <ltmp0+0x1b48>
    1ce8:      	add	x8, x24, x4
    1cec:      	ldp	q1, q5, [x8]
    1cf0:      	fmov	w11, s28
    1cf4:      	add	x8, x27, x4
    1cf8:      	ldp	q3, q2, [x8]
    1cfc:      	add	x9, x9, x10
    1d00:      	movi.2d	v4, #0000000000000000
    1d04:      	movi.2d	v6, #0000000000000000
    1d08:      	tbnz	w11, #0x0, 0x20c8 <ltmp0+0x20c8>
    1d0c:      	tbnz	w11, #0x1, 0x20d0 <ltmp0+0x20d0>
    1d10:      	tbnz	w11, #0x2, 0x20dc <ltmp0+0x20dc>
    1d14:      	tbnz	w11, #0x3, 0x20e8 <ltmp0+0x20e8>
    1d18:      	tbnz	w11, #0x4, 0x20f4 <ltmp0+0x20f4>
    1d1c:      	tbnz	w11, #0x5, 0x2100 <ltmp0+0x2100>
    1d20:      	tbnz	w11, #0x6, 0x210c <ltmp0+0x210c>
    1d24:      	tbz	w11, #0x7, 0x1d30 <ltmp0+0x1d30>
    1d28:      	add	x8, x9, #0x1c
    1d2c:      	ld1.s	{ v6 }[3], [x8]
    1d30:      	zip2.8b	v0, v8, v0
    1d34:      	ushll.4s	v0, v0, #0x0
    1d38:      	shl.4s	v0, v0, #0x1f
    1d3c:      	cmlt.4s	v0, v0, #0
    1d40:      	and.16b	v5, v0, v5
    1d44:      	zip1.8b	v7, v8, v0
    1d48:      	ushll.4s	v7, v7, #0x0
    1d4c:      	shl.4s	v7, v7, #0x1f
    1d50:      	cmlt.4s	v7, v7, #0
    1d54:      	and.16b	v1, v7, v1
    1d58:      	fdiv.4s	v1, v1, v22
    1d5c:      	fdiv.4s	v5, v5, v22
    1d60:      	and.16b	v3, v7, v3
    1d64:      	and.16b	v0, v0, v2
    1d68:      	fmul.4s	v0, v5, v0
    1d6c:      	fmul.4s	v1, v1, v3
    1d70:      	fadd.4s	v2, v4, v1
    1d74:      	fadd.4s	v1, v6, v0
    1d78:      	b	0x2024 <ltmp0+0x2024>
    1d7c:      	ldr	s21, [x11]
    1d80:      	tbz	w10, #0x1, 0xbc4 <ltmp0+0xbc4>
    1d84:      	add	x8, x11, #0x4
    1d88:      	ld1.s	{ v21 }[1], [x8]
    1d8c:      	tbz	w10, #0x2, 0xbc8 <ltmp0+0xbc8>
    1d90:      	add	x8, x11, #0x8
    1d94:      	ld1.s	{ v21 }[2], [x8]
    1d98:      	tbz	w10, #0x3, 0xbcc <ltmp0+0xbcc>
    1d9c:      	add	x8, x11, #0xc
    1da0:      	ld1.s	{ v21 }[3], [x8]
    1da4:      	tbz	w10, #0x4, 0xbd0 <ltmp0+0xbd0>
    1da8:      	add	x8, x11, #0x10
    1dac:      	ld1.s	{ v23 }[0], [x8]
    1db0:      	tbz	w10, #0x5, 0xbd4 <ltmp0+0xbd4>
    1db4:      	add	x8, x11, #0x14
    1db8:      	ld1.s	{ v23 }[1], [x8]
    1dbc:      	tbz	w10, #0x6, 0xbd8 <ltmp0+0xbd8>
    1dc0:      	add	x8, x11, #0x18
    1dc4:      	ld1.s	{ v23 }[2], [x8]
    1dc8:      	str	q7, [sp, #0x150]
    1dcc:      	tbnz	w10, #0x7, 0xbe0 <ltmp0+0xbe0>
    1dd0:      	b	0xbe8 <ltmp0+0xbe8>
    1dd4:      	ldr	s2, [x12]
    1dd8:      	ldr	x2, [sp, #0x198]
    1ddc:      	ldr	w30, [sp, #0x1bc]
    1de0:      	ldr	q17, [sp, #0x170]
    1de4:      	tbz	w11, #0x1, 0x19a8 <ltmp0+0x19a8>
    1de8:      	add	x8, x12, #0x4
    1dec:      	ld1.s	{ v2 }[1], [x8]
    1df0:      	tbz	w11, #0x2, 0x19ac <ltmp0+0x19ac>
    1df4:      	add	x8, x12, #0x8
    1df8:      	ld1.s	{ v2 }[2], [x8]
    1dfc:      	tbz	w11, #0x3, 0x19b0 <ltmp0+0x19b0>
    1e00:      	add	x8, x12, #0xc
    1e04:      	ld1.s	{ v2 }[3], [x8]
    1e08:      	tbz	w11, #0x4, 0x19b4 <ltmp0+0x19b4>
    1e0c:      	add	x8, x12, #0x10
    1e10:      	ld1.s	{ v3 }[0], [x8]
    1e14:      	tbz	w11, #0x5, 0x19b8 <ltmp0+0x19b8>
    1e18:      	add	x8, x12, #0x14
    1e1c:      	ld1.s	{ v3 }[1], [x8]
    1e20:      	tbz	w11, #0x6, 0x19bc <ltmp0+0x19bc>
    1e24:      	add	x8, x12, #0x18
    1e28:      	ld1.s	{ v3 }[2], [x8]
    1e2c:      	tbnz	w11, #0x7, 0x19c0 <ltmp0+0x19c0>
    1e30:      	b	0x19c8 <ltmp0+0x19c8>
    1e34:      	add	x9, x9, x10
    1e38:      	fmov	w10, s28
    1e3c:      	movi.2d	v1, #0000000000000000
    1e40:      	movi.2d	v2, #0000000000000000
    1e44:      	tbnz	w10, #0x0, 0x211c <ltmp0+0x211c>
    1e48:      	tbnz	w10, #0x1, 0x2124 <ltmp0+0x2124>
    1e4c:      	tbnz	w10, #0x2, 0x2130 <ltmp0+0x2130>
    1e50:      	tbnz	w10, #0x3, 0x213c <ltmp0+0x213c>
    1e54:      	tbnz	w10, #0x4, 0x2148 <ltmp0+0x2148>
    1e58:      	tbnz	w10, #0x5, 0x2154 <ltmp0+0x2154>
    1e5c:      	tbnz	w10, #0x6, 0x2160 <ltmp0+0x2160>
    1e60:      	tbz	w10, #0x7, 0x1e6c <ltmp0+0x1e6c>
    1e64:      	add	x8, x9, #0x1c
    1e68:      	ld1.s	{ v2 }[3], [x8]
    1e6c:      	mov	x8, #0x0                ; =0
    1e70:      	add	x9, x1, x4
    1e74:      	ldp	q0, q3, [x9]
    1e78:      	zip2.8b	v4, v8, v0
    1e7c:      	ushll.4s	v4, v4, #0x0
    1e80:      	shl.4s	v4, v4, #0x1f
    1e84:      	cmlt.4s	v4, v4, #0
    1e88:      	bif.16b	v2, v3, v4
    1e8c:      	zip1.8b	v3, v8, v0
    1e90:      	ushll.4s	v3, v3, #0x0
    1e94:      	shl.4s	v3, v3, #0x1f
    1e98:      	cmlt.4s	v3, v3, #0
    1e9c:      	bit.16b	v0, v1, v3
    1ea0:      	stp	q0, q2, [x9]
    1ea4:      	dup.4s	v1, v27[0]
    1ea8:      	ldr	q0, [sp, #0xf0]
    1eac:      	fmov	x9, d0
    1eb0:      	add	x9, x26, x9, lsl #2
    1eb4:      	movi.2d	v2, #0000000000000000
    1eb8:      	movi.2d	v3, #0000000000000000
    1ebc:      	movi.2d	v4, #0000000000000000
    1ec0:      	movi.2d	v16, #0000000000000000
    1ec4:      	b	0x1ee4 <ltmp0+0x1ee4>
    1ec8:      	add.2d	v3, v3, v24
    1ecc:      	add.2d	v4, v4, v25
    1ed0:      	add.2d	v16, v16, v23
    1ed4:      	add.2d	v2, v2, v26
    1ed8:      	fmov	x8, d2
    1edc:      	cmp	x8, #0x200
    1ee0:      	b.ge	0x1fbc <ltmp0+0x1fbc>
    1ee4:      	fmov	w10, s31
    1ee8:      	lsl	x8, x8, #5
    1eec:      	add	x11, x24, x8
    1ef0:      	ldp	q0, q18, [x11]
    1ef4:      	and.16b	v0, v6, v0
    1ef8:      	fdiv.4s	v0, v0, v1
    1efc:      	add	x11, x27, x8
    1f00:      	ldp	q7, q19, [x11]
    1f04:      	and.16b	v7, v6, v7
    1f08:      	fmul.4s	v0, v0, v7
    1f0c:      	add	x11, x1, x8
    1f10:      	ldp	q7, q20, [x11]
    1f14:      	and.16b	v7, v6, v7
    1f18:      	fadd.4s	v21, v0, v7
    1f1c:      	add	x8, x9, x8
    1f20:      	tbnz	w10, #0x0, 0x1f68 <ltmp0+0x1f68>
    1f24:      	and	w10, w10, #0xff
    1f28:      	tbnz	w10, #0x1, 0x1f74 <ltmp0+0x1f74>
    1f2c:      	tbnz	w10, #0x2, 0x1f80 <ltmp0+0x1f80>
    1f30:      	tbz	w10, #0x3, 0x1f3c <ltmp0+0x1f3c>
    1f34:      	add	x11, x8, #0xc
    1f38:      	st1.s	{ v21 }[3], [x11]
    1f3c:      	and.16b	v0, v5, v18
    1f40:      	fdiv.4s	v0, v0, v1
    1f44:      	and.16b	v7, v5, v19
    1f48:      	fmul.4s	v0, v0, v7
    1f4c:      	and.16b	v7, v5, v20
    1f50:      	fadd.4s	v18, v0, v7
    1f54:      	tbnz	w10, #0x4, 0x1f90 <ltmp0+0x1f90>
    1f58:      	tbnz	w10, #0x5, 0x1f98 <ltmp0+0x1f98>
    1f5c:      	tbnz	w10, #0x6, 0x1fa4 <ltmp0+0x1fa4>
    1f60:      	tbz	w10, #0x7, 0x1ec8 <ltmp0+0x1ec8>
    1f64:      	b	0x1fb0 <ltmp0+0x1fb0>
    1f68:      	str	s21, [x8]
    1f6c:      	and	w10, w10, #0xff
    1f70:      	tbz	w10, #0x1, 0x1f2c <ltmp0+0x1f2c>
    1f74:      	add	x11, x8, #0x4
    1f78:      	st1.s	{ v21 }[1], [x11]
    1f7c:      	tbz	w10, #0x2, 0x1f30 <ltmp0+0x1f30>
    1f80:      	add	x11, x8, #0x8
    1f84:      	st1.s	{ v21 }[2], [x11]
    1f88:      	tbnz	w10, #0x3, 0x1f34 <ltmp0+0x1f34>
    1f8c:      	b	0x1f3c <ltmp0+0x1f3c>
    1f90:      	str	s18, [x8, #0x10]
    1f94:      	tbz	w10, #0x5, 0x1f5c <ltmp0+0x1f5c>
    1f98:      	add	x11, x8, #0x14
    1f9c:      	st1.s	{ v18 }[1], [x11]
    1fa0:      	tbz	w10, #0x6, 0x1f60 <ltmp0+0x1f60>
    1fa4:      	add	x11, x8, #0x18
    1fa8:      	st1.s	{ v18 }[2], [x11]
    1fac:      	tbz	w10, #0x7, 0x1ec8 <ltmp0+0x1ec8>
    1fb0:      	add	x8, x8, #0x1c
    1fb4:      	st1.s	{ v18 }[3], [x8]
    1fb8:      	b	0x1ec8 <ltmp0+0x1ec8>
    1fbc:      	add	x8, x24, x4
    1fc0:      	ldp	q2, q0, [x8]
    1fc4:      	zip1.8b	v3, v8, v0
    1fc8:      	ushll.4s	v3, v3, #0x0
    1fcc:      	shl.4s	v3, v3, #0x1f
    1fd0:      	cmlt.4s	v3, v3, #0
    1fd4:      	and.16b	v2, v3, v2
    1fd8:      	zip2.8b	v4, v8, v0
    1fdc:      	ushll.4s	v4, v4, #0x0
    1fe0:      	shl.4s	v4, v4, #0x1f
    1fe4:      	cmlt.4s	v4, v4, #0
    1fe8:      	and.16b	v0, v4, v0
    1fec:      	fdiv.4s	v0, v0, v1
    1ff0:      	fdiv.4s	v1, v2, v1
    1ff4:      	add	x8, x27, x4
    1ff8:      	ldp	q2, q5, [x8]
    1ffc:      	and.16b	v5, v4, v5
    2000:      	and.16b	v2, v3, v2
    2004:      	fmul.4s	v2, v1, v2
    2008:      	fmul.4s	v0, v0, v5
    200c:      	add	x8, x1, x4
    2010:      	ldp	q5, q1, [x8]
    2014:      	and.16b	v3, v3, v5
    2018:      	and.16b	v1, v4, v1
    201c:      	fadd.4s	v1, v0, v1
    2020:      	fadd.4s	v2, v2, v3
    2024:      	ldp	q0, q3, [sp, #0x130]
    2028:      	ldp	q5, q4, [sp, #0x110]
    202c:      	stp	q3, q4, [sp, #0x1d0]
    2030:      	stp	q5, q0, [sp, #0x1f0]
    2034:      	and	x8, x14, #0x7
    2038:      	add	x9, sp, #0x1d0
    203c:      	ldr	x8, [x9, x8, lsl #3]
    2040:      	sub	x8, x8, x14
    2044:      	add	x8, x26, x8, lsl #2
    2048:      	fmov	w9, s28
    204c:      	tbnz	w9, #0x0, 0x2070 <ltmp0+0x2070>
    2050:      	tbnz	w9, #0x1, 0x2078 <ltmp0+0x2078>
    2054:      	tbnz	w9, #0x2, 0x2084 <ltmp0+0x2084>
    2058:      	tbnz	w9, #0x3, 0x2090 <ltmp0+0x2090>
    205c:      	tbnz	w9, #0x4, 0x209c <ltmp0+0x209c>
    2060:      	tbnz	w9, #0x5, 0x20a4 <ltmp0+0x20a4>
    2064:      	tbnz	w9, #0x6, 0x20b0 <ltmp0+0x20b0>
    2068:      	tbz	w9, #0x7, 0x80 <ltmp0+0x80>
    206c:      	b	0x20bc <ltmp0+0x20bc>
    2070:      	str	s2, [x8]
    2074:      	tbz	w9, #0x1, 0x2054 <ltmp0+0x2054>
    2078:      	add	x10, x8, #0x4
    207c:      	st1.s	{ v2 }[1], [x10]
    2080:      	tbz	w9, #0x2, 0x2058 <ltmp0+0x2058>
    2084:      	add	x10, x8, #0x8
    2088:      	st1.s	{ v2 }[2], [x10]
    208c:      	tbz	w9, #0x3, 0x205c <ltmp0+0x205c>
    2090:      	add	x10, x8, #0xc
    2094:      	st1.s	{ v2 }[3], [x10]
    2098:      	tbz	w9, #0x4, 0x2060 <ltmp0+0x2060>
    209c:      	str	s1, [x8, #0x10]
    20a0:      	tbz	w9, #0x5, 0x2064 <ltmp0+0x2064>
    20a4:      	add	x10, x8, #0x14
    20a8:      	st1.s	{ v1 }[1], [x10]
    20ac:      	tbz	w9, #0x6, 0x2068 <ltmp0+0x2068>
    20b0:      	add	x10, x8, #0x18
    20b4:      	st1.s	{ v1 }[2], [x10]
    20b8:      	tbz	w9, #0x7, 0x80 <ltmp0+0x80>
    20bc:      	add	x8, x8, #0x1c
    20c0:      	st1.s	{ v1 }[3], [x8]
    20c4:      	b	0x80 <ltmp0+0x80>
    20c8:      	ldr	s4, [x9]
    20cc:      	tbz	w11, #0x1, 0x1d10 <ltmp0+0x1d10>
    20d0:      	add	x8, x9, #0x4
    20d4:      	ld1.s	{ v4 }[1], [x8]
    20d8:      	tbz	w11, #0x2, 0x1d14 <ltmp0+0x1d14>
    20dc:      	add	x8, x9, #0x8
    20e0:      	ld1.s	{ v4 }[2], [x8]
    20e4:      	tbz	w11, #0x3, 0x1d18 <ltmp0+0x1d18>
    20e8:      	add	x8, x9, #0xc
    20ec:      	ld1.s	{ v4 }[3], [x8]
    20f0:      	tbz	w11, #0x4, 0x1d1c <ltmp0+0x1d1c>
    20f4:      	add	x8, x9, #0x10
    20f8:      	ld1.s	{ v6 }[0], [x8]
    20fc:      	tbz	w11, #0x5, 0x1d20 <ltmp0+0x1d20>
    2100:      	add	x8, x9, #0x14
    2104:      	ld1.s	{ v6 }[1], [x8]
    2108:      	tbz	w11, #0x6, 0x1d24 <ltmp0+0x1d24>
    210c:      	add	x8, x9, #0x18
    2110:      	ld1.s	{ v6 }[2], [x8]
    2114:      	tbnz	w11, #0x7, 0x1d28 <ltmp0+0x1d28>
    2118:      	b	0x1d30 <ltmp0+0x1d30>
    211c:      	ldr	s1, [x9]
    2120:      	tbz	w10, #0x1, 0x1e4c <ltmp0+0x1e4c>
    2124:      	add	x8, x9, #0x4
    2128:      	ld1.s	{ v1 }[1], [x8]
    212c:      	tbz	w10, #0x2, 0x1e50 <ltmp0+0x1e50>
    2130:      	add	x8, x9, #0x8
    2134:      	ld1.s	{ v1 }[2], [x8]
    2138:      	tbz	w10, #0x3, 0x1e54 <ltmp0+0x1e54>
    213c:      	add	x8, x9, #0xc
    2140:      	ld1.s	{ v1 }[3], [x8]
    2144:      	tbz	w10, #0x4, 0x1e58 <ltmp0+0x1e58>
    2148:      	add	x8, x9, #0x10
    214c:      	ld1.s	{ v2 }[0], [x8]
    2150:      	tbz	w10, #0x5, 0x1e5c <ltmp0+0x1e5c>
    2154:      	add	x8, x9, #0x14
    2158:      	ld1.s	{ v2 }[1], [x8]
    215c:      	tbz	w10, #0x6, 0x1e60 <ltmp0+0x1e60>
    2160:      	add	x8, x9, #0x18
    2164:      	ld1.s	{ v2 }[2], [x8]
    2168:      	tbnz	w10, #0x7, 0x1e64 <ltmp0+0x1e64>
    216c:      	b	0x1e6c <ltmp0+0x1e6c>
    2170:      	stp	w14, w13, [x2]
    2174:      	str	w12, [x2, #0x8]
    2178:      	mov	w8, #0x18               ; =24
    217c:      	str	w8, [x2, #0x24]
    2180:      	add	sp, sp, #0x6a0
    2184:      	ldp	x29, x30, [sp, #0x90]
    2188:      	ldp	x20, x19, [sp, #0x80]
    218c:      	ldp	x22, x21, [sp, #0x70]
    2190:      	ldp	x24, x23, [sp, #0x60]
    2194:      	ldp	x26, x25, [sp, #0x50]
    2198:      	ldp	x28, x27, [sp, #0x40]
    219c:      	ldp	d9, d8, [sp, #0x30]
    21a0:      	ldp	d11, d10, [sp, #0x20]
    21a4:      	ldp	d13, d12, [sp, #0x10]
    21a8:      	ldp	d15, d14, [sp], #0xa0
    21ac:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/capture/swiglu-129x768/on/object/tile_xir_w8_36406_1788935100916602_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      2c:      	sub	sp, sp, #0x940
      30:      	str	x0, [sp, #0x18]
      34:      	str	w3, [sp, #0x38]
      38:      	cbz	w3, 0x1240 <ltmp0+0x1240>
      3c:      	mov	w12, #0x0               ; =0
      40:      	mov	w8, #0x42d00000         ; =1120927744
      44:      	dup.4s	v23, w8
      48:      	mov	w8, #-0x3d380000        ; =-1027080192
      4c:      	dup.4s	v24, w8
      50:      	mov	w8, #0xaa3b             ; =43579
      54:      	movk	w8, #0x3fb8, lsl #16
      58:      	dup.4s	v25, w8
      5c:      	ldp	w9, w8, [x2, #0x2c]
      60:      	stp	w8, w9, [sp, #0x30]
      64:      	movi.4s	v26, #0x4b, lsl #24
      68:      	mvni.4s	v27, #0x80, lsl #24
      6c:      	mov	w8, #0x7200             ; =29184
      70:      	movk	w8, #0xbf31, lsl #16
      74:      	dup.4s	v28, w8
      78:      	mov	w8, #0xbe8e             ; =48782
      7c:      	movk	w8, #0xb5bf, lsl #16
      80:      	dup.4s	v29, w8
      84:      	mov	w8, #0x2bda             ; =11226
      88:      	movk	w8, #0x3950, lsl #16
      8c:      	dup.4s	v30, w8
      90:      	mov	w8, #0x96c9             ; =38601
      94:      	movk	w8, #0x3ab6, lsl #16
      98:      	dup.4s	v31, w8
      9c:      	mov	w8, #0x88a6             ; =34982
      a0:      	movk	w8, #0x3c08, lsl #16
      a4:      	dup.4s	v8, w8
      a8:      	mov	w8, #0xaa7a             ; =43642
      ac:      	movk	w8, #0x3d2a, lsl #16
      b0:      	dup.4s	v9, w8
      b4:      	mov	w11, #0xaaab            ; =43691
      b8:      	movk	w11, #0x3e2a, lsl #16
      bc:      	movi.4s	v10, #0x3f, lsl #24
      c0:      	ldp	w8, w9, [x2]
      c4:      	fmov.4s	v11, #1.00000000
      c8:      	mvni.4s	v0, #0x7f, msl #16
      cc:      	fneg.4s	v12, v0
      d0:      	mvni.4s	v0, #0x3f, msl #16
      d4:      	ldp	w10, w13, [x2, #0x8]
      d8:      	str	x2, [sp, #0x10]
      dc:      	str	x13, [sp, #0x28]
      e0:      	dup.4s	v13, w11
      e4:      	add	x28, sp, #0xd40
      e8:      	add	x19, sp, #0x140
      ec:      	fneg.4s	v14, v0
      f0:      	stp	q24, q23, [sp, #0x110]
      f4:      	stp	q28, q25, [sp, #0xf0]
      f8:      	stp	q30, q29, [sp, #0xd0]
      fc:      	stp	q8, q31, [sp, #0xb0]
     100:      	stp	q11, q9, [sp, #0x90]
     104:      	stp	q13, q12, [sp, #0x70]
     108:      	str	q14, [sp, #0x60]
     10c:      	b	0x158 <ltmp0+0x158>
     110:      	ldr	x15, [sp, #0x48]
     114:      	add	w8, w15, #0x1
     118:      	ldp	w11, w9, [sp, #0x30]
     11c:      	cmp	w8, w9
     120:      	cset	w9, eq
     124:      	csinc	w8, wzr, w15, eq
     128:      	ldp	w14, w13, [sp, #0x3c]
     12c:      	cinc	w10, w14, eq
     130:      	cmp	w10, w11
     134:      	cset	w11, eq
     138:      	ands	w11, w9, w11
     13c:      	csel	w9, wzr, w10, ne
     140:      	add	w10, w13, w11
     144:      	ldr	w12, [sp, #0x44]
     148:      	add	w12, w12, #0x1
     14c:      	ldr	w11, [sp, #0x38]
     150:      	cmp	w12, w11
     154:      	b.eq	0x122c <ltmp0+0x122c>
     158:      	str	w12, [sp, #0x44]
     15c:      	mov	x13, x10
     160:      	mov	x14, x9
     164:      	mov	x15, x8
     168:      	ubfiz	x8, x8, #5, #32
     16c:      	ldr	x12, [sp, #0x28]
     170:      	cmp	x8, x12
     174:      	csel	x9, x8, xzr, ls
     178:      	subs	x10, x12, x9
     17c:      	cmp	x10, #0x20
     180:      	mov	w11, #0x20              ; =32
     184:      	csel	x10, x10, x11, lo
     188:      	cmp	x12, x9
     18c:      	ccmp	x8, x12, #0x2, hi
     190:      	csel	x8, x10, xzr, ls
     194:      	cmp	x8, #0x20
     198:      	str	x15, [sp, #0x48]
     19c:      	stp	w14, w13, [sp, #0x3c]
     1a0:      	b.lo	0x5d8 <ltmp0+0x5d8>
     1a4:      	mov	x21, #0x0               ; =0
     1a8:      	ldr	x8, [sp, #0x18]
     1ac:      	ldr	x23, [x8]
     1b0:      	ldr	x24, [x8, #0x10]
     1b4:      	ldr	x8, [x8, #0x30]
     1b8:      	subs	x9, x23, x8
     1bc:      	mov	w12, #0xbff             ; =3071
     1c0:      	movk	w12, #0x6, lsl #16
     1c4:      	ccmp	x9, x12, #0x0, hs
     1c8:      	cset	w9, hi
     1cc:      	subs	x10, x8, x23
     1d0:      	ccmp	x10, x12, #0x0, hs
     1d4:      	csinc	w9, w9, wzr, ls
     1d8:      	subs	x10, x24, x8
     1dc:      	ccmp	x10, x12, #0x0, hs
     1e0:      	cset	w10, hi
     1e4:      	subs	x11, x8, x24
     1e8:      	ccmp	x11, x12, #0x0, hs
     1ec:      	csinc	w10, w10, wzr, ls
     1f0:      	and	w25, w9, w10
     1f4:      	lsl	w9, w15, #2
     1f8:      	str	x9, [sp, #0x58]
     1fc:      	and	x9, x15, #0x7ffffff
     200:      	add	x9, x9, x9, lsl #1
     204:      	lsl	x9, x9, #12
     208:      	add	x22, x8, x9
     20c:      	add	x26, x24, x9
     210:      	add	x27, x23, x9
     214:      	b	0x230 <ltmp0+0x230>
     218:      	add	x21, x21, #0x1
     21c:      	add	x22, x22, #0xc00
     220:      	add	x26, x26, #0xc00
     224:      	add	x27, x27, #0xc00
     228:      	cmp	x21, #0x4
     22c:      	b.eq	0x110 <ltmp0+0x110>
     230:      	cbz	w25, 0x3d8 <ltmp0+0x3d8>
     234:      	mov	x8, #0x0                ; =0
     238:      	add	x9, x27, x8
     23c:      	ldp	q0, q1, [x9]
     240:      	fneg.4s	v2, v1
     244:      	fneg.4s	v3, v0
     248:      	fcmge.4s	v4, v23, v0
     24c:      	fcmge.4s	v5, v23, v1
     250:      	fcmge.4s	v6, v0, v24
     254:      	fcmge.4s	v7, v1, v24
     258:      	and.16b	v5, v5, v7
     25c:      	and.16b	v4, v4, v6
     260:      	and.16b	v3, v4, v3
     264:      	and.16b	v2, v5, v2
     268:      	fmul.4s	v4, v2, v25
     26c:      	fmul.4s	v5, v3, v25
     270:      	mov.16b	v6, v27
     274:      	bsl.16b	v6, v26, v5
     278:      	mov.16b	v7, v27
     27c:      	bsl.16b	v7, v26, v4
     280:      	fadd.4s	v4, v4, v7
     284:      	fadd.4s	v5, v5, v6
     288:      	fsub.4s	v5, v5, v6
     28c:      	fsub.4s	v4, v4, v7
     290:      	fcvtzs.4s	v4, v4
     294:      	fcvtzs.4s	v5, v5
     298:      	scvtf.4s	v6, v5
     29c:      	scvtf.4s	v7, v4
     2a0:      	fmul.4s	v16, v7, v28
     2a4:      	fmul.4s	v17, v6, v28
     2a8:      	fadd.4s	v3, v3, v17
     2ac:      	fadd.4s	v2, v2, v16
     2b0:      	fmul.4s	v6, v6, v29
     2b4:      	fmul.4s	v7, v7, v29
     2b8:      	fadd.4s	v2, v2, v7
     2bc:      	fadd.4s	v3, v3, v6
     2c0:      	fmul.4s	v6, v3, v30
     2c4:      	fmul.4s	v7, v2, v30
     2c8:      	fadd.4s	v7, v7, v31
     2cc:      	fadd.4s	v6, v6, v31
     2d0:      	fmul.4s	v6, v3, v6
     2d4:      	fmul.4s	v7, v2, v7
     2d8:      	fadd.4s	v7, v7, v8
     2dc:      	fadd.4s	v6, v6, v8
     2e0:      	fmul.4s	v6, v3, v6
     2e4:      	fmul.4s	v7, v2, v7
     2e8:      	fadd.4s	v7, v7, v9
     2ec:      	fadd.4s	v6, v6, v9
     2f0:      	fmul.4s	v6, v3, v6
     2f4:      	fmul.4s	v7, v2, v7
     2f8:      	fadd.4s	v7, v7, v13
     2fc:      	fadd.4s	v6, v6, v13
     300:      	fmul.4s	v6, v3, v6
     304:      	fmul.4s	v7, v2, v7
     308:      	fadd.4s	v7, v7, v10
     30c:      	fadd.4s	v6, v6, v10
     310:      	fmul.4s	v16, v2, v2
     314:      	fmul.4s	v17, v3, v3
     318:      	fmul.4s	v6, v17, v6
     31c:      	fmul.4s	v7, v16, v7
     320:      	fadd.4s	v2, v2, v7
     324:      	fadd.4s	v3, v3, v6
     328:      	sshr.4s	v6, v5, #0x1
     32c:      	fadd.4s	v3, v3, v11
     330:      	sshr.4s	v7, v4, #0x1
     334:      	shl.4s	v16, v7, #0x17
     338:      	shl.4s	v17, v6, #0x17
     33c:      	add.4s	v17, v17, v11
     340:      	add.4s	v16, v16, v11
     344:      	fadd.4s	v2, v2, v11
     348:      	fmul.4s	v2, v2, v16
     34c:      	sub.4s	v4, v4, v7
     350:      	sub.4s	v5, v5, v6
     354:      	shl.4s	v5, v5, #0x17
     358:      	shl.4s	v4, v4, #0x17
     35c:      	fmul.4s	v3, v3, v17
     360:      	add.4s	v4, v4, v11
     364:      	add.4s	v5, v5, v11
     368:      	fmul.4s	v3, v3, v5
     36c:      	fmul.4s	v2, v2, v4
     370:      	fcmgt.4s	v4, v1, v23
     374:      	fcmgt.4s	v5, v0, v23
     378:      	fcmgt.4s	v6, v24, v0
     37c:      	fcmgt.4s	v7, v24, v1
     380:      	fcmeq.4s	v16, v1, v1
     384:      	fadd.4s	v2, v2, v11
     388:      	fadd.4s	v3, v3, v11
     38c:      	fcmeq.4s	v17, v0, v0
     390:      	bit.16b	v3, v11, v5
     394:      	bit.16b	v2, v11, v4
     398:      	bit.16b	v2, v12, v7
     39c:      	bit.16b	v3, v12, v6
     3a0:      	bif.16b	v3, v14, v17
     3a4:      	bif.16b	v2, v14, v16
     3a8:      	fdiv.4s	v1, v1, v2
     3ac:      	fdiv.4s	v0, v0, v3
     3b0:      	add	x9, x26, x8
     3b4:      	ldp	q3, q2, [x9]
     3b8:      	fmul.4s	v0, v3, v0
     3bc:      	fmul.4s	v1, v2, v1
     3c0:      	add	x9, x22, x8
     3c4:      	stp	q0, q1, [x9]
     3c8:      	add	x8, x8, #0x20
     3cc:      	cmp	x8, #0xc00
     3d0:      	b.ne	0x238 <ltmp0+0x238>
     3d4:      	b	0x218 <ltmp0+0x218>
     3d8:      	ldr	x8, [sp, #0x58]
     3dc:      	add	w8, w21, w8
     3e0:      	and	x8, x8, #0x1fffffff
     3e4:      	add	x8, x8, x8, lsl #1
     3e8:      	lsl	x20, x8, #10
     3ec:      	add	x0, sp, #0xd40
     3f0:      	add	x1, x23, x20
     3f4:      	mov	w2, #0xc00              ; =3072
     3f8:      	bl	0x3f8 <ltmp0+0x3f8>
     3fc:      	add	x0, sp, #0x140
     400:      	add	x1, x24, x20
     404:      	mov	w2, #0xc00              ; =3072
     408:      	bl	0x408 <ltmp0+0x408>
     40c:      	ldp	q14, q13, [sp, #0x60]
     410:      	ldp	q12, q11, [sp, #0x80]
     414:      	movi.4s	v10, #0x3f, lsl #24
     418:      	ldp	q9, q8, [sp, #0xa0]
     41c:      	ldp	q31, q30, [sp, #0xc0]
     420:      	ldp	q29, q28, [sp, #0xe0]
     424:      	mvni.4s	v27, #0x80, lsl #24
     428:      	movi.4s	v26, #0x4b, lsl #24
     42c:      	ldp	q25, q24, [sp, #0x100]
     430:      	ldr	q23, [sp, #0x120]
     434:      	mov	x8, #0x0                ; =0
     438:      	add	x9, x28, x8
     43c:      	ldp	q0, q1, [x9]
     440:      	fneg.4s	v2, v1
     444:      	fneg.4s	v3, v0
     448:      	fcmge.4s	v4, v23, v0
     44c:      	fcmge.4s	v5, v23, v1
     450:      	fcmge.4s	v6, v0, v24
     454:      	fcmge.4s	v7, v1, v24
     458:      	and.16b	v5, v5, v7
     45c:      	and.16b	v4, v4, v6
     460:      	and.16b	v3, v4, v3
     464:      	and.16b	v2, v5, v2
     468:      	fmul.4s	v4, v2, v25
     46c:      	fmul.4s	v5, v3, v25
     470:      	mov.16b	v6, v27
     474:      	bsl.16b	v6, v26, v5
     478:      	mov.16b	v7, v27
     47c:      	bsl.16b	v7, v26, v4
     480:      	fadd.4s	v4, v4, v7
     484:      	fadd.4s	v5, v5, v6
     488:      	fsub.4s	v5, v5, v6
     48c:      	fsub.4s	v4, v4, v7
     490:      	fcvtzs.4s	v4, v4
     494:      	fcvtzs.4s	v5, v5
     498:      	scvtf.4s	v6, v5
     49c:      	scvtf.4s	v7, v4
     4a0:      	fmul.4s	v16, v7, v28
     4a4:      	fmul.4s	v17, v6, v28
     4a8:      	fadd.4s	v3, v3, v17
     4ac:      	fadd.4s	v2, v2, v16
     4b0:      	fmul.4s	v6, v6, v29
     4b4:      	fmul.4s	v7, v7, v29
     4b8:      	fadd.4s	v2, v2, v7
     4bc:      	fadd.4s	v3, v3, v6
     4c0:      	fmul.4s	v6, v3, v30
     4c4:      	fmul.4s	v7, v2, v30
     4c8:      	fadd.4s	v7, v7, v31
     4cc:      	fadd.4s	v6, v6, v31
     4d0:      	fmul.4s	v6, v3, v6
     4d4:      	fmul.4s	v7, v2, v7
     4d8:      	fadd.4s	v7, v7, v8
     4dc:      	fadd.4s	v6, v6, v8
     4e0:      	fmul.4s	v6, v3, v6
     4e4:      	fmul.4s	v7, v2, v7
     4e8:      	fadd.4s	v7, v7, v9
     4ec:      	fadd.4s	v6, v6, v9
     4f0:      	fmul.4s	v6, v3, v6
     4f4:      	fmul.4s	v7, v2, v7
     4f8:      	fadd.4s	v7, v7, v13
     4fc:      	fadd.4s	v6, v6, v13
     500:      	fmul.4s	v6, v3, v6
     504:      	fmul.4s	v7, v2, v7
     508:      	fadd.4s	v7, v7, v10
     50c:      	fadd.4s	v6, v6, v10
     510:      	fmul.4s	v16, v2, v2
     514:      	fmul.4s	v17, v3, v3
     518:      	fmul.4s	v6, v17, v6
     51c:      	fmul.4s	v7, v16, v7
     520:      	fadd.4s	v2, v2, v7
     524:      	fadd.4s	v3, v3, v6
     528:      	sshr.4s	v6, v5, #0x1
     52c:      	fadd.4s	v3, v3, v11
     530:      	sshr.4s	v7, v4, #0x1
     534:      	shl.4s	v16, v7, #0x17
     538:      	shl.4s	v17, v6, #0x17
     53c:      	add.4s	v17, v17, v11
     540:      	add.4s	v16, v16, v11
     544:      	fadd.4s	v2, v2, v11
     548:      	fmul.4s	v2, v2, v16
     54c:      	sub.4s	v4, v4, v7
     550:      	sub.4s	v5, v5, v6
     554:      	shl.4s	v5, v5, #0x17
     558:      	shl.4s	v4, v4, #0x17
     55c:      	fmul.4s	v3, v3, v17
     560:      	add.4s	v4, v4, v11
     564:      	add.4s	v5, v5, v11
     568:      	fmul.4s	v3, v3, v5
     56c:      	fmul.4s	v2, v2, v4
     570:      	fcmgt.4s	v4, v1, v23
     574:      	fcmgt.4s	v5, v0, v23
     578:      	fcmgt.4s	v6, v24, v0
     57c:      	fcmgt.4s	v7, v24, v1
     580:      	fcmeq.4s	v16, v1, v1
     584:      	fadd.4s	v2, v2, v11
     588:      	fadd.4s	v3, v3, v11
     58c:      	fcmeq.4s	v17, v0, v0
     590:      	bit.16b	v3, v11, v5
     594:      	bit.16b	v2, v11, v4
     598:      	bit.16b	v2, v12, v7
     59c:      	bit.16b	v3, v12, v6
     5a0:      	bif.16b	v3, v14, v17
     5a4:      	bif.16b	v2, v14, v16
     5a8:      	fdiv.4s	v1, v1, v2
     5ac:      	fdiv.4s	v0, v0, v3
     5b0:      	add	x9, x19, x8
     5b4:      	ldp	q3, q2, [x9]
     5b8:      	fmul.4s	v0, v3, v0
     5bc:      	fmul.4s	v1, v2, v1
     5c0:      	add	x9, x22, x8
     5c4:      	stp	q0, q1, [x9]
     5c8:      	add	x8, x8, #0x20
     5cc:      	cmp	x8, #0xc00
     5d0:      	b.ne	0x438 <ltmp0+0x438>
     5d4:      	b	0x218 <ltmp0+0x218>
     5d8:      	lsr	x23, x8, #3
     5dc:      	str	x8, [sp, #0x20]
     5e0:      	cmp	x8, #0x8
     5e4:      	b.hs	0xa18 <ltmp0+0xa18>
     5e8:      	ldr	x8, [sp, #0x20]
     5ec:      	and	w8, w8, #0x7
     5f0:      	cbz	w8, 0x110 <ltmp0+0x110>
     5f4:      	dup.4s	v1, w8
     5f8:      	adrp	x8, 0x0 <ltmp0>
     5fc:      	ldr	q2, [x8]
     600:      	adrp	x8, 0x0 <ltmp0>
     604:      	ldr	q0, [x8]
     608:      	cmhi.4s	v0, v1, v0
     60c:      	cmhi.4s	v1, v1, v2
     610:      	uzp1.8h	v4, v1, v0
     614:      	umaxv.8h	h2, v4
     618:      	fmov	w8, s2
     61c:      	adrp	x16, 0x0 <ltmp0>
     620:      	ldr	x11, [sp, #0x48]
     624:      	tbz	w8, #0x0, 0x110 <ltmp0+0x110>
     628:      	ldr	x8, [sp, #0x18]
     62c:      	ldr	x12, [x8]
     630:      	ldr	x10, [x8, #0x10]
     634:      	ldr	x9, [x8, #0x30]
     638:      	ubfiz	w8, w11, #2, #27
     63c:      	orr	w8, w8, w23
     640:      	fmov	s2, w8
     644:      	and.16b	v2, v1, v2
     648:      	subs	x8, x12, x9
     64c:      	mov	w14, #0xbff             ; =3071
     650:      	movk	w14, #0x6, lsl #16
     654:      	ccmp	x8, x14, #0x0, hs
     658:      	cset	w8, hi
     65c:      	subs	x11, x9, x12
     660:      	ccmp	x11, x14, #0x0, hs
     664:      	csinc	w13, w8, wzr, ls
     668:      	subs	x8, x10, x9
     66c:      	ccmp	x8, x14, #0x0, hs
     670:      	cset	w8, hi
     674:      	subs	x11, x9, x10
     678:      	ccmp	x11, x14, #0x0, hs
     67c:      	csinc	w8, w8, wzr, ls
     680:      	fmov	w11, s2
     684:      	mov	w14, #0xc00             ; =3072
     688:      	umull	x11, w11, w14
     68c:      	mov	w14, #-0x3d300000       ; =-1026555904
     690:      	dup.4s	v2, w14
     694:      	mov	w14, #0x42c80000        ; =1120403456
     698:      	dup.4s	v3, w14
     69c:      	cmp	w13, #0x1
     6a0:      	b.ne	0xe54 <ltmp0+0xe54>
     6a4:      	cbz	w8, 0xe54 <ltmp0+0xe54>
     6a8:      	mov	x8, #0x0                ; =0
     6ac:      	add	x9, x9, x11
     6b0:      	add	x10, x10, x11
     6b4:      	add	x11, x12, x11
     6b8:      	b	0x6c8 <ltmp0+0x6c8>
     6bc:      	add	x8, x8, #0x20
     6c0:      	cmp	x8, #0xc00
     6c4:      	b.eq	0x110 <ltmp0+0x110>
     6c8:      	ldr	q5, [x16]
     6cc:      	and.16b	v5, v4, v5
     6d0:      	addv.8h	h6, v5
     6d4:      	fmov	w13, s6
     6d8:      	add	x12, x11, x8
     6dc:      	movi.2d	v7, #0000000000000000
     6e0:      	movi.2d	v5, #0000000000000000
     6e4:      	tbnz	w13, #0x0, 0x8fc <ltmp0+0x8fc>
     6e8:      	and	w13, w13, #0xff
     6ec:      	tbnz	w13, #0x1, 0x908 <ltmp0+0x908>
     6f0:      	tbnz	w13, #0x2, 0x914 <ltmp0+0x914>
     6f4:      	tbnz	w13, #0x3, 0x920 <ltmp0+0x920>
     6f8:      	tbnz	w13, #0x4, 0x92c <ltmp0+0x92c>
     6fc:      	tbnz	w13, #0x5, 0x938 <ltmp0+0x938>
     700:      	tbnz	w13, #0x6, 0x944 <ltmp0+0x944>
     704:      	tbnz	w13, #0x7, 0x950 <ltmp0+0x950>
     708:      	fmov	w13, s6
     70c:      	add	x12, x10, x8
     710:      	movi.2d	v17, #0000000000000000
     714:      	movi.2d	v16, #0000000000000000
     718:      	tbnz	w13, #0x0, 0x96c <ltmp0+0x96c>
     71c:      	and	w13, w13, #0xff
     720:      	tbnz	w13, #0x1, 0x978 <ltmp0+0x978>
     724:      	tbnz	w13, #0x2, 0x984 <ltmp0+0x984>
     728:      	tbnz	w13, #0x3, 0x990 <ltmp0+0x990>
     72c:      	tbnz	w13, #0x4, 0x99c <ltmp0+0x99c>
     730:      	tbnz	w13, #0x5, 0x9a8 <ltmp0+0x9a8>
     734:      	tbnz	w13, #0x6, 0x9b4 <ltmp0+0x9b4>
     738:      	tbz	w13, #0x7, 0x744 <ltmp0+0x744>
     73c:      	add	x12, x12, #0x1c
     740:      	ld1.s	{ v16 }[3], [x12]
     744:      	fneg.4s	v18, v7
     748:      	and.16b	v18, v1, v18
     74c:      	fcmge.4s	v19, v18, v2
     750:      	fcmge.4s	v20, v3, v18
     754:      	and.16b	v19, v19, v20
     758:      	and.16b	v19, v19, v18
     75c:      	fmul.4s	v20, v19, v25
     760:      	mov.16b	v21, v27
     764:      	bsl.16b	v21, v26, v20
     768:      	fadd.4s	v20, v20, v21
     76c:      	fsub.4s	v20, v20, v21
     770:      	fcvtzs.4s	v20, v20
     774:      	scvtf.4s	v21, v20
     778:      	fmul.4s	v22, v21, v28
     77c:      	fadd.4s	v19, v19, v22
     780:      	fmul.4s	v21, v21, v29
     784:      	fadd.4s	v19, v19, v21
     788:      	fmul.4s	v21, v19, v30
     78c:      	fadd.4s	v21, v21, v31
     790:      	fmul.4s	v21, v19, v21
     794:      	fadd.4s	v21, v21, v8
     798:      	fmul.4s	v21, v19, v21
     79c:      	fadd.4s	v21, v21, v9
     7a0:      	fmul.4s	v21, v19, v21
     7a4:      	fadd.4s	v21, v21, v13
     7a8:      	fmul.4s	v21, v19, v21
     7ac:      	fadd.4s	v21, v21, v10
     7b0:      	fmul.4s	v22, v19, v19
     7b4:      	fmul.4s	v21, v22, v21
     7b8:      	fadd.4s	v19, v19, v21
     7bc:      	fadd.4s	v19, v19, v11
     7c0:      	sshr.4s	v21, v20, #0x1
     7c4:      	shl.4s	v22, v21, #0x17
     7c8:      	add.4s	v22, v22, v11
     7cc:      	fmul.4s	v19, v19, v22
     7d0:      	sub.4s	v20, v20, v21
     7d4:      	shl.4s	v20, v20, #0x17
     7d8:      	add.4s	v20, v20, v11
     7dc:      	fmul.4s	v19, v19, v20
     7e0:      	fcmgt.4s	v20, v2, v18
     7e4:      	fcmgt.4s	v21, v18, v3
     7e8:      	fcmeq.4s	v18, v18, v18
     7ec:      	fadd.4s	v19, v19, v11
     7f0:      	bit.16b	v19, v11, v20
     7f4:      	bit.16b	v19, v12, v21
     7f8:      	bsl.16b	v18, v19, v14
     7fc:      	fdiv.4s	v7, v7, v18
     800:      	fmov	w13, s6
     804:      	fmul.4s	v6, v17, v7
     808:      	add	x12, x9, x8
     80c:      	tbnz	w13, #0x0, 0x9c4 <ltmp0+0x9c4>
     810:      	and	w13, w13, #0xff
     814:      	tbnz	w13, #0x1, 0x9d0 <ltmp0+0x9d0>
     818:      	tbnz	w13, #0x2, 0x9dc <ltmp0+0x9dc>
     81c:      	tbz	w13, #0x3, 0x828 <ltmp0+0x828>
     820:      	add	x14, x12, #0xc
     824:      	st1.s	{ v6 }[3], [x14]
     828:      	fneg.4s	v6, v5
     82c:      	and.16b	v6, v0, v6
     830:      	fcmge.4s	v7, v6, v2
     834:      	fcmge.4s	v17, v3, v6
     838:      	and.16b	v7, v7, v17
     83c:      	and.16b	v7, v7, v6
     840:      	fmul.4s	v17, v7, v25
     844:      	mov.16b	v18, v27
     848:      	bsl.16b	v18, v26, v17
     84c:      	fadd.4s	v17, v17, v18
     850:      	fsub.4s	v17, v17, v18
     854:      	fcvtzs.4s	v17, v17
     858:      	scvtf.4s	v18, v17
     85c:      	fmul.4s	v19, v18, v28
     860:      	fadd.4s	v7, v7, v19
     864:      	fmul.4s	v18, v18, v29
     868:      	fadd.4s	v7, v7, v18
     86c:      	fmul.4s	v18, v7, v30
     870:      	fadd.4s	v18, v18, v31
     874:      	fmul.4s	v18, v7, v18
     878:      	fadd.4s	v18, v18, v8
     87c:      	fmul.4s	v18, v7, v18
     880:      	fadd.4s	v18, v18, v9
     884:      	fmul.4s	v18, v7, v18
     888:      	fadd.4s	v18, v18, v13
     88c:      	fmul.4s	v18, v7, v18
     890:      	fadd.4s	v18, v18, v10
     894:      	fmul.4s	v19, v7, v7
     898:      	fmul.4s	v18, v19, v18
     89c:      	fadd.4s	v7, v7, v18
     8a0:      	fadd.4s	v7, v7, v11
     8a4:      	sshr.4s	v18, v17, #0x1
     8a8:      	shl.4s	v19, v18, #0x17
     8ac:      	add.4s	v19, v19, v11
     8b0:      	fmul.4s	v7, v7, v19
     8b4:      	sub.4s	v17, v17, v18
     8b8:      	shl.4s	v17, v17, #0x17
     8bc:      	add.4s	v17, v17, v11
     8c0:      	fmul.4s	v7, v7, v17
     8c4:      	fcmgt.4s	v17, v2, v6
     8c8:      	fcmgt.4s	v18, v6, v3
     8cc:      	fcmeq.4s	v6, v6, v6
     8d0:      	fadd.4s	v7, v7, v11
     8d4:      	bit.16b	v7, v11, v17
     8d8:      	bit.16b	v7, v12, v18
     8dc:      	bsl.16b	v6, v7, v14
     8e0:      	fdiv.4s	v5, v5, v6
     8e4:      	fmul.4s	v5, v16, v5
     8e8:      	tbnz	w13, #0x4, 0x9ec <ltmp0+0x9ec>
     8ec:      	tbnz	w13, #0x5, 0x9f4 <ltmp0+0x9f4>
     8f0:      	tbnz	w13, #0x6, 0xa00 <ltmp0+0xa00>
     8f4:      	tbz	w13, #0x7, 0x6bc <ltmp0+0x6bc>
     8f8:      	b	0xa0c <ltmp0+0xa0c>
     8fc:      	ldr	s7, [x12]
     900:      	and	w13, w13, #0xff
     904:      	tbz	w13, #0x1, 0x6f0 <ltmp0+0x6f0>
     908:      	add	x14, x12, #0x4
     90c:      	ld1.s	{ v7 }[1], [x14]
     910:      	tbz	w13, #0x2, 0x6f4 <ltmp0+0x6f4>
     914:      	add	x14, x12, #0x8
     918:      	ld1.s	{ v7 }[2], [x14]
     91c:      	tbz	w13, #0x3, 0x6f8 <ltmp0+0x6f8>
     920:      	add	x14, x12, #0xc
     924:      	ld1.s	{ v7 }[3], [x14]
     928:      	tbz	w13, #0x4, 0x6fc <ltmp0+0x6fc>
     92c:      	add	x14, x12, #0x10
     930:      	ld1.s	{ v5 }[0], [x14]
     934:      	tbz	w13, #0x5, 0x700 <ltmp0+0x700>
     938:      	add	x14, x12, #0x14
     93c:      	ld1.s	{ v5 }[1], [x14]
     940:      	tbz	w13, #0x6, 0x704 <ltmp0+0x704>
     944:      	add	x14, x12, #0x18
     948:      	ld1.s	{ v5 }[2], [x14]
     94c:      	tbz	w13, #0x7, 0x708 <ltmp0+0x708>
     950:      	add	x12, x12, #0x1c
     954:      	ld1.s	{ v5 }[3], [x12]
     958:      	fmov	w13, s6
     95c:      	add	x12, x10, x8
     960:      	movi.2d	v17, #0000000000000000
     964:      	movi.2d	v16, #0000000000000000
     968:      	tbz	w13, #0x0, 0x71c <ltmp0+0x71c>
     96c:      	ldr	s17, [x12]
     970:      	and	w13, w13, #0xff
     974:      	tbz	w13, #0x1, 0x724 <ltmp0+0x724>
     978:      	add	x14, x12, #0x4
     97c:      	ld1.s	{ v17 }[1], [x14]
     980:      	tbz	w13, #0x2, 0x728 <ltmp0+0x728>
     984:      	add	x14, x12, #0x8
     988:      	ld1.s	{ v17 }[2], [x14]
     98c:      	tbz	w13, #0x3, 0x72c <ltmp0+0x72c>
     990:      	add	x14, x12, #0xc
     994:      	ld1.s	{ v17 }[3], [x14]
     998:      	tbz	w13, #0x4, 0x730 <ltmp0+0x730>
     99c:      	add	x14, x12, #0x10
     9a0:      	ld1.s	{ v16 }[0], [x14]
     9a4:      	tbz	w13, #0x5, 0x734 <ltmp0+0x734>
     9a8:      	add	x14, x12, #0x14
     9ac:      	ld1.s	{ v16 }[1], [x14]
     9b0:      	tbz	w13, #0x6, 0x738 <ltmp0+0x738>
     9b4:      	add	x14, x12, #0x18
     9b8:      	ld1.s	{ v16 }[2], [x14]
     9bc:      	tbnz	w13, #0x7, 0x73c <ltmp0+0x73c>
     9c0:      	b	0x744 <ltmp0+0x744>
     9c4:      	str	s6, [x12]
     9c8:      	and	w13, w13, #0xff
     9cc:      	tbz	w13, #0x1, 0x818 <ltmp0+0x818>
     9d0:      	add	x14, x12, #0x4
     9d4:      	st1.s	{ v6 }[1], [x14]
     9d8:      	tbz	w13, #0x2, 0x81c <ltmp0+0x81c>
     9dc:      	add	x14, x12, #0x8
     9e0:      	st1.s	{ v6 }[2], [x14]
     9e4:      	tbnz	w13, #0x3, 0x820 <ltmp0+0x820>
     9e8:      	b	0x828 <ltmp0+0x828>
     9ec:      	str	s5, [x12, #0x10]
     9f0:      	tbz	w13, #0x5, 0x8f0 <ltmp0+0x8f0>
     9f4:      	add	x14, x12, #0x14
     9f8:      	st1.s	{ v5 }[1], [x14]
     9fc:      	tbz	w13, #0x6, 0x8f4 <ltmp0+0x8f4>
     a00:      	add	x14, x12, #0x18
     a04:      	st1.s	{ v5 }[2], [x14]
     a08:      	tbz	w13, #0x7, 0x6bc <ltmp0+0x6bc>
     a0c:      	add	x12, x12, #0x1c
     a10:      	st1.s	{ v5 }[3], [x12]
     a14:      	b	0x6bc <ltmp0+0x6bc>
     a18:      	mov	x26, #0x0               ; =0
     a1c:      	ldr	x8, [sp, #0x18]
     a20:      	ldr	x13, [x8]
     a24:      	ldr	x24, [x8, #0x10]
     a28:      	ldr	x8, [x8, #0x30]
     a2c:      	subs	x9, x13, x8
     a30:      	mov	w12, #0xbff             ; =3071
     a34:      	movk	w12, #0x6, lsl #16
     a38:      	ccmp	x9, x12, #0x0, hs
     a3c:      	cset	w9, hi
     a40:      	subs	x10, x8, x13
     a44:      	ccmp	x10, x12, #0x0, hs
     a48:      	csinc	w9, w9, wzr, ls
     a4c:      	subs	x10, x24, x8
     a50:      	ccmp	x10, x12, #0x0, hs
     a54:      	cset	w10, hi
     a58:      	subs	x11, x8, x24
     a5c:      	ccmp	x11, x12, #0x0, hs
     a60:      	csinc	w10, w10, wzr, ls
     a64:      	and	w27, w9, w10
     a68:      	ldr	x9, [sp, #0x48]
     a6c:      	lsl	w10, w9, #2
     a70:      	stp	x10, x13, [sp, #0x50]
     a74:      	and	x9, x9, #0x7ffffff
     a78:      	add	x9, x9, x9, lsl #1
     a7c:      	lsl	x9, x9, #12
     a80:      	add	x22, x8, x9
     a84:      	add	x25, x24, x9
     a88:      	add	x20, x13, x9
     a8c:      	b	0xaa8 <ltmp0+0xaa8>
     a90:      	add	x26, x26, #0x1
     a94:      	add	x22, x22, #0xc00
     a98:      	add	x25, x25, #0xc00
     a9c:      	add	x20, x20, #0xc00
     aa0:      	cmp	x26, x23
     aa4:      	b.eq	0x5e8 <ltmp0+0x5e8>
     aa8:      	cbz	w27, 0xc50 <ltmp0+0xc50>
     aac:      	mov	x8, #0x0                ; =0
     ab0:      	add	x9, x20, x8
     ab4:      	ldp	q0, q1, [x9]
     ab8:      	fneg.4s	v2, v1
     abc:      	fneg.4s	v3, v0
     ac0:      	fcmge.4s	v4, v23, v0
     ac4:      	fcmge.4s	v5, v23, v1
     ac8:      	fcmge.4s	v6, v0, v24
     acc:      	fcmge.4s	v7, v1, v24
     ad0:      	and.16b	v5, v5, v7
     ad4:      	and.16b	v4, v4, v6
     ad8:      	and.16b	v3, v4, v3
     adc:      	and.16b	v2, v5, v2
     ae0:      	fmul.4s	v4, v2, v25
     ae4:      	fmul.4s	v5, v3, v25
     ae8:      	mov.16b	v6, v27
     aec:      	bsl.16b	v6, v26, v5
     af0:      	mov.16b	v7, v27
     af4:      	bsl.16b	v7, v26, v4
     af8:      	fadd.4s	v4, v4, v7
     afc:      	fadd.4s	v5, v5, v6
     b00:      	fsub.4s	v5, v5, v6
     b04:      	fsub.4s	v4, v4, v7
     b08:      	fcvtzs.4s	v4, v4
     b0c:      	fcvtzs.4s	v5, v5
     b10:      	scvtf.4s	v6, v5
     b14:      	scvtf.4s	v7, v4
     b18:      	fmul.4s	v16, v7, v28
     b1c:      	fmul.4s	v17, v6, v28
     b20:      	fadd.4s	v3, v3, v17
     b24:      	fadd.4s	v2, v2, v16
     b28:      	fmul.4s	v6, v6, v29
     b2c:      	fmul.4s	v7, v7, v29
     b30:      	fadd.4s	v2, v2, v7
     b34:      	fadd.4s	v3, v3, v6
     b38:      	fmul.4s	v6, v3, v30
     b3c:      	fmul.4s	v7, v2, v30
     b40:      	fadd.4s	v7, v7, v31
     b44:      	fadd.4s	v6, v6, v31
     b48:      	fmul.4s	v6, v3, v6
     b4c:      	fmul.4s	v7, v2, v7
     b50:      	fadd.4s	v7, v7, v8
     b54:      	fadd.4s	v6, v6, v8
     b58:      	fmul.4s	v6, v3, v6
     b5c:      	fmul.4s	v7, v2, v7
     b60:      	fadd.4s	v7, v7, v9
     b64:      	fadd.4s	v6, v6, v9
     b68:      	fmul.4s	v6, v3, v6
     b6c:      	fmul.4s	v7, v2, v7
     b70:      	fadd.4s	v7, v7, v13
     b74:      	fadd.4s	v6, v6, v13
     b78:      	fmul.4s	v6, v3, v6
     b7c:      	fmul.4s	v7, v2, v7
     b80:      	fadd.4s	v7, v7, v10
     b84:      	fadd.4s	v6, v6, v10
     b88:      	fmul.4s	v16, v2, v2
     b8c:      	fmul.4s	v17, v3, v3
     b90:      	fmul.4s	v6, v17, v6
     b94:      	fmul.4s	v7, v16, v7
     b98:      	fadd.4s	v2, v2, v7
     b9c:      	fadd.4s	v3, v3, v6
     ba0:      	sshr.4s	v6, v5, #0x1
     ba4:      	fadd.4s	v3, v3, v11
     ba8:      	sshr.4s	v7, v4, #0x1
     bac:      	shl.4s	v16, v7, #0x17
     bb0:      	shl.4s	v17, v6, #0x17
     bb4:      	add.4s	v17, v17, v11
     bb8:      	add.4s	v16, v16, v11
     bbc:      	fadd.4s	v2, v2, v11
     bc0:      	fmul.4s	v2, v2, v16
     bc4:      	sub.4s	v4, v4, v7
     bc8:      	sub.4s	v5, v5, v6
     bcc:      	shl.4s	v5, v5, #0x17
     bd0:      	shl.4s	v4, v4, #0x17
     bd4:      	fmul.4s	v3, v3, v17
     bd8:      	add.4s	v4, v4, v11
     bdc:      	add.4s	v5, v5, v11
     be0:      	fmul.4s	v3, v3, v5
     be4:      	fmul.4s	v2, v2, v4
     be8:      	fcmgt.4s	v4, v1, v23
     bec:      	fcmgt.4s	v5, v0, v23
     bf0:      	fcmgt.4s	v6, v24, v0
     bf4:      	fcmgt.4s	v7, v24, v1
     bf8:      	fcmeq.4s	v16, v1, v1
     bfc:      	fadd.4s	v2, v2, v11
     c00:      	fadd.4s	v3, v3, v11
     c04:      	fcmeq.4s	v17, v0, v0
     c08:      	bit.16b	v3, v11, v5
     c0c:      	bit.16b	v2, v11, v4
     c10:      	bit.16b	v2, v12, v7
     c14:      	bit.16b	v3, v12, v6
     c18:      	bif.16b	v3, v14, v17
     c1c:      	bif.16b	v2, v14, v16
     c20:      	fdiv.4s	v1, v1, v2
     c24:      	fdiv.4s	v0, v0, v3
     c28:      	add	x9, x25, x8
     c2c:      	ldp	q3, q2, [x9]
     c30:      	fmul.4s	v0, v3, v0
     c34:      	fmul.4s	v1, v2, v1
     c38:      	add	x9, x22, x8
     c3c:      	stp	q0, q1, [x9]
     c40:      	add	x8, x8, #0x20
     c44:      	cmp	x8, #0xc00
     c48:      	b.ne	0xab0 <ltmp0+0xab0>
     c4c:      	b	0xa90 <ltmp0+0xa90>
     c50:      	ldr	x8, [sp, #0x50]
     c54:      	add	w8, w26, w8
     c58:      	and	x8, x8, #0x1fffffff
     c5c:      	add	x8, x8, x8, lsl #1
     c60:      	lsl	x21, x8, #10
     c64:      	add	x0, sp, #0xd40
     c68:      	ldr	x8, [sp, #0x58]
     c6c:      	add	x1, x8, x21
     c70:      	mov	w2, #0xc00              ; =3072
     c74:      	bl	0xc74 <ltmp0+0xc74>
     c78:      	add	x0, sp, #0x140
     c7c:      	add	x1, x24, x21
     c80:      	mov	w2, #0xc00              ; =3072
     c84:      	bl	0xc84 <ltmp0+0xc84>
     c88:      	ldp	q14, q13, [sp, #0x60]
     c8c:      	ldp	q12, q11, [sp, #0x80]
     c90:      	movi.4s	v10, #0x3f, lsl #24
     c94:      	ldp	q9, q8, [sp, #0xa0]
     c98:      	ldp	q31, q30, [sp, #0xc0]
     c9c:      	ldp	q29, q28, [sp, #0xe0]
     ca0:      	mvni.4s	v27, #0x80, lsl #24
     ca4:      	movi.4s	v26, #0x4b, lsl #24
     ca8:      	ldp	q25, q24, [sp, #0x100]
     cac:      	ldr	q23, [sp, #0x120]
     cb0:      	mov	x8, #0x0                ; =0
     cb4:      	add	x9, x28, x8
     cb8:      	ldp	q0, q1, [x9]
     cbc:      	fneg.4s	v2, v1
     cc0:      	fneg.4s	v3, v0
     cc4:      	fcmge.4s	v4, v23, v0
     cc8:      	fcmge.4s	v5, v23, v1
     ccc:      	fcmge.4s	v6, v0, v24
     cd0:      	fcmge.4s	v7, v1, v24
     cd4:      	and.16b	v5, v5, v7
     cd8:      	and.16b	v4, v4, v6
     cdc:      	and.16b	v3, v4, v3
     ce0:      	and.16b	v2, v5, v2
     ce4:      	fmul.4s	v4, v2, v25
     ce8:      	fmul.4s	v5, v3, v25
     cec:      	mov.16b	v6, v27
     cf0:      	bsl.16b	v6, v26, v5
     cf4:      	mov.16b	v7, v27
     cf8:      	bsl.16b	v7, v26, v4
     cfc:      	fadd.4s	v4, v4, v7
     d00:      	fadd.4s	v5, v5, v6
     d04:      	fsub.4s	v5, v5, v6
     d08:      	fsub.4s	v4, v4, v7
     d0c:      	fcvtzs.4s	v4, v4
     d10:      	fcvtzs.4s	v5, v5
     d14:      	scvtf.4s	v6, v5
     d18:      	scvtf.4s	v7, v4
     d1c:      	fmul.4s	v16, v7, v28
     d20:      	fmul.4s	v17, v6, v28
     d24:      	fadd.4s	v3, v3, v17
     d28:      	fadd.4s	v2, v2, v16
     d2c:      	fmul.4s	v6, v6, v29
     d30:      	fmul.4s	v7, v7, v29
     d34:      	fadd.4s	v2, v2, v7
     d38:      	fadd.4s	v3, v3, v6
     d3c:      	fmul.4s	v6, v3, v30
     d40:      	fmul.4s	v7, v2, v30
     d44:      	fadd.4s	v7, v7, v31
     d48:      	fadd.4s	v6, v6, v31
     d4c:      	fmul.4s	v6, v3, v6
     d50:      	fmul.4s	v7, v2, v7
     d54:      	fadd.4s	v7, v7, v8
     d58:      	fadd.4s	v6, v6, v8
     d5c:      	fmul.4s	v6, v3, v6
     d60:      	fmul.4s	v7, v2, v7
     d64:      	fadd.4s	v7, v7, v9
     d68:      	fadd.4s	v6, v6, v9
     d6c:      	fmul.4s	v6, v3, v6
     d70:      	fmul.4s	v7, v2, v7
     d74:      	fadd.4s	v7, v7, v13
     d78:      	fadd.4s	v6, v6, v13
     d7c:      	fmul.4s	v6, v3, v6
     d80:      	fmul.4s	v7, v2, v7
     d84:      	fadd.4s	v7, v7, v10
     d88:      	fadd.4s	v6, v6, v10
     d8c:      	fmul.4s	v16, v2, v2
     d90:      	fmul.4s	v17, v3, v3
     d94:      	fmul.4s	v6, v17, v6
     d98:      	fmul.4s	v7, v16, v7
     d9c:      	fadd.4s	v2, v2, v7
     da0:      	fadd.4s	v3, v3, v6
     da4:      	sshr.4s	v6, v5, #0x1
     da8:      	fadd.4s	v3, v3, v11
     dac:      	sshr.4s	v7, v4, #0x1
     db0:      	shl.4s	v16, v7, #0x17
     db4:      	shl.4s	v17, v6, #0x17
     db8:      	add.4s	v17, v17, v11
     dbc:      	add.4s	v16, v16, v11
     dc0:      	fadd.4s	v2, v2, v11
     dc4:      	fmul.4s	v2, v2, v16
     dc8:      	sub.4s	v4, v4, v7
     dcc:      	sub.4s	v5, v5, v6
     dd0:      	shl.4s	v5, v5, #0x17
     dd4:      	shl.4s	v4, v4, #0x17
     dd8:      	fmul.4s	v3, v3, v17
     ddc:      	add.4s	v4, v4, v11
     de0:      	add.4s	v5, v5, v11
     de4:      	fmul.4s	v3, v3, v5
     de8:      	fmul.4s	v2, v2, v4
     dec:      	fcmgt.4s	v4, v1, v23
     df0:      	fcmgt.4s	v5, v0, v23
     df4:      	fcmgt.4s	v6, v24, v0
     df8:      	fcmgt.4s	v7, v24, v1
     dfc:      	fcmeq.4s	v16, v1, v1
     e00:      	fadd.4s	v2, v2, v11
     e04:      	fadd.4s	v3, v3, v11
     e08:      	fcmeq.4s	v17, v0, v0
     e0c:      	bit.16b	v3, v11, v5
     e10:      	bit.16b	v2, v11, v4
     e14:      	bit.16b	v2, v12, v7
     e18:      	bit.16b	v3, v12, v6
     e1c:      	bif.16b	v3, v14, v17
     e20:      	bif.16b	v2, v14, v16
     e24:      	fdiv.4s	v1, v1, v2
     e28:      	fdiv.4s	v0, v0, v3
     e2c:      	add	x9, x19, x8
     e30:      	ldp	q3, q2, [x9]
     e34:      	fmul.4s	v0, v3, v0
     e38:      	fmul.4s	v1, v2, v1
     e3c:      	add	x9, x22, x8
     e40:      	stp	q0, q1, [x9]
     e44:      	add	x8, x8, #0x20
     e48:      	cmp	x8, #0xc00
     e4c:      	b.ne	0xcb4 <ltmp0+0xcb4>
     e50:      	b	0xa90 <ltmp0+0xa90>
     e54:      	mov	x8, #0x0                ; =0
     e58:      	add	x12, x12, x11
     e5c:      	b	0xe80 <ltmp0+0xe80>
     e60:      	add	x13, x28, x8
     e64:      	ldp	q16, q17, [x13]
     e68:      	bif.16b	v7, v17, v0
     e6c:      	bif.16b	v6, v16, v1
     e70:      	stp	q6, q7, [x13]
     e74:      	add	x8, x8, #0x20
     e78:      	cmp	x8, #0xc00
     e7c:      	b.eq	0xf24 <ltmp0+0xf24>
     e80:      	ldr	q5, [x16]
     e84:      	and.16b	v5, v4, v5
     e88:      	addv.8h	h5, v5
     e8c:      	fmov	w14, s5
     e90:      	add	x13, x12, x8
     e94:      	movi.2d	v6, #0000000000000000
     e98:      	movi.2d	v7, #0000000000000000
     e9c:      	tbnz	w14, #0x0, 0xec4 <ltmp0+0xec4>
     ea0:      	and	w14, w14, #0xff
     ea4:      	tbnz	w14, #0x1, 0xed0 <ltmp0+0xed0>
     ea8:      	tbnz	w14, #0x2, 0xedc <ltmp0+0xedc>
     eac:      	tbnz	w14, #0x3, 0xee8 <ltmp0+0xee8>
     eb0:      	tbnz	w14, #0x4, 0xef4 <ltmp0+0xef4>
     eb4:      	tbnz	w14, #0x5, 0xf00 <ltmp0+0xf00>
     eb8:      	tbnz	w14, #0x6, 0xf0c <ltmp0+0xf0c>
     ebc:      	tbz	w14, #0x7, 0xe60 <ltmp0+0xe60>
     ec0:      	b	0xf18 <ltmp0+0xf18>
     ec4:      	ldr	s6, [x13]
     ec8:      	and	w14, w14, #0xff
     ecc:      	tbz	w14, #0x1, 0xea8 <ltmp0+0xea8>
     ed0:      	add	x15, x13, #0x4
     ed4:      	ld1.s	{ v6 }[1], [x15]
     ed8:      	tbz	w14, #0x2, 0xeac <ltmp0+0xeac>
     edc:      	add	x15, x13, #0x8
     ee0:      	ld1.s	{ v6 }[2], [x15]
     ee4:      	tbz	w14, #0x3, 0xeb0 <ltmp0+0xeb0>
     ee8:      	add	x15, x13, #0xc
     eec:      	ld1.s	{ v6 }[3], [x15]
     ef0:      	tbz	w14, #0x4, 0xeb4 <ltmp0+0xeb4>
     ef4:      	add	x15, x13, #0x10
     ef8:      	ld1.s	{ v7 }[0], [x15]
     efc:      	tbz	w14, #0x5, 0xeb8 <ltmp0+0xeb8>
     f00:      	add	x15, x13, #0x14
     f04:      	ld1.s	{ v7 }[1], [x15]
     f08:      	tbz	w14, #0x6, 0xebc <ltmp0+0xebc>
     f0c:      	add	x15, x13, #0x18
     f10:      	ld1.s	{ v7 }[2], [x15]
     f14:      	tbz	w14, #0x7, 0xe60 <ltmp0+0xe60>
     f18:      	add	x13, x13, #0x1c
     f1c:      	ld1.s	{ v7 }[3], [x13]
     f20:      	b	0xe60 <ltmp0+0xe60>
     f24:      	mov	x8, #0x0                ; =0
     f28:      	add	x10, x10, x11
     f2c:      	b	0xf50 <ltmp0+0xf50>
     f30:      	add	x12, x19, x8
     f34:      	ldp	q7, q16, [x12]
     f38:      	bif.16b	v6, v16, v0
     f3c:      	bif.16b	v4, v7, v1
     f40:      	stp	q4, q6, [x12]
     f44:      	add	x8, x8, #0x20
     f48:      	cmp	x8, #0xc00
     f4c:      	b.eq	0xfe8 <ltmp0+0xfe8>
     f50:      	fmov	w13, s5
     f54:      	add	x12, x10, x8
     f58:      	movi.2d	v4, #0000000000000000
     f5c:      	movi.2d	v6, #0000000000000000
     f60:      	tbnz	w13, #0x0, 0xf88 <ltmp0+0xf88>
     f64:      	and	w13, w13, #0xff
     f68:      	tbnz	w13, #0x1, 0xf94 <ltmp0+0xf94>
     f6c:      	tbnz	w13, #0x2, 0xfa0 <ltmp0+0xfa0>
     f70:      	tbnz	w13, #0x3, 0xfac <ltmp0+0xfac>
     f74:      	tbnz	w13, #0x4, 0xfb8 <ltmp0+0xfb8>
     f78:      	tbnz	w13, #0x5, 0xfc4 <ltmp0+0xfc4>
     f7c:      	tbnz	w13, #0x6, 0xfd0 <ltmp0+0xfd0>
     f80:      	tbz	w13, #0x7, 0xf30 <ltmp0+0xf30>
     f84:      	b	0xfdc <ltmp0+0xfdc>
     f88:      	ldr	s4, [x12]
     f8c:      	and	w13, w13, #0xff
     f90:      	tbz	w13, #0x1, 0xf6c <ltmp0+0xf6c>
     f94:      	add	x14, x12, #0x4
     f98:      	ld1.s	{ v4 }[1], [x14]
     f9c:      	tbz	w13, #0x2, 0xf70 <ltmp0+0xf70>
     fa0:      	add	x14, x12, #0x8
     fa4:      	ld1.s	{ v4 }[2], [x14]
     fa8:      	tbz	w13, #0x3, 0xf74 <ltmp0+0xf74>
     fac:      	add	x14, x12, #0xc
     fb0:      	ld1.s	{ v4 }[3], [x14]
     fb4:      	tbz	w13, #0x4, 0xf78 <ltmp0+0xf78>
     fb8:      	add	x14, x12, #0x10
     fbc:      	ld1.s	{ v6 }[0], [x14]
     fc0:      	tbz	w13, #0x5, 0xf7c <ltmp0+0xf7c>
     fc4:      	add	x14, x12, #0x14
     fc8:      	ld1.s	{ v6 }[1], [x14]
     fcc:      	tbz	w13, #0x6, 0xf80 <ltmp0+0xf80>
     fd0:      	add	x14, x12, #0x18
     fd4:      	ld1.s	{ v6 }[2], [x14]
     fd8:      	tbz	w13, #0x7, 0xf30 <ltmp0+0xf30>
     fdc:      	add	x12, x12, #0x1c
     fe0:      	ld1.s	{ v6 }[3], [x12]
     fe4:      	b	0xf30 <ltmp0+0xf30>
     fe8:      	mov	x8, #0x0                ; =0
     fec:      	add	x9, x9, x11
     ff0:      	b	0x1000 <ltmp0+0x1000>
     ff4:      	add	x8, x8, #0x20
     ff8:      	cmp	x8, #0xc00
     ffc:      	b.eq	0x110 <ltmp0+0x110>
    1000:      	fmov	w11, s5
    1004:      	add	x10, x28, x8
    1008:      	ldp	q6, q4, [x10]
    100c:      	and.16b	v6, v1, v6
    1010:      	fneg.4s	v7, v6
    1014:      	and.16b	v7, v1, v7
    1018:      	fcmge.4s	v16, v7, v2
    101c:      	fcmge.4s	v17, v3, v7
    1020:      	and.16b	v16, v16, v17
    1024:      	and.16b	v16, v16, v7
    1028:      	fmul.4s	v17, v16, v25
    102c:      	mov.16b	v18, v27
    1030:      	bsl.16b	v18, v26, v17
    1034:      	fadd.4s	v17, v17, v18
    1038:      	fsub.4s	v17, v17, v18
    103c:      	fcvtzs.4s	v17, v17
    1040:      	scvtf.4s	v18, v17
    1044:      	fmul.4s	v19, v18, v28
    1048:      	fadd.4s	v16, v16, v19
    104c:      	fmul.4s	v18, v18, v29
    1050:      	fadd.4s	v16, v16, v18
    1054:      	fmul.4s	v18, v16, v30
    1058:      	fadd.4s	v18, v18, v31
    105c:      	fmul.4s	v18, v16, v18
    1060:      	fadd.4s	v18, v18, v8
    1064:      	fmul.4s	v18, v16, v18
    1068:      	fadd.4s	v18, v18, v9
    106c:      	fmul.4s	v18, v16, v18
    1070:      	fadd.4s	v18, v18, v13
    1074:      	fmul.4s	v18, v16, v18
    1078:      	fadd.4s	v18, v18, v10
    107c:      	fmul.4s	v19, v16, v16
    1080:      	fmul.4s	v18, v19, v18
    1084:      	fadd.4s	v16, v16, v18
    1088:      	fadd.4s	v16, v16, v11
    108c:      	sshr.4s	v18, v17, #0x1
    1090:      	shl.4s	v19, v18, #0x17
    1094:      	add.4s	v19, v19, v11
    1098:      	fmul.4s	v16, v16, v19
    109c:      	sub.4s	v17, v17, v18
    10a0:      	shl.4s	v17, v17, #0x17
    10a4:      	add.4s	v17, v17, v11
    10a8:      	fmul.4s	v16, v16, v17
    10ac:      	fcmgt.4s	v17, v2, v7
    10b0:      	fcmgt.4s	v18, v7, v3
    10b4:      	fcmeq.4s	v7, v7, v7
    10b8:      	fadd.4s	v16, v16, v11
    10bc:      	bit.16b	v16, v11, v17
    10c0:      	bit.16b	v16, v12, v18
    10c4:      	bsl.16b	v7, v16, v14
    10c8:      	fdiv.4s	v7, v6, v7
    10cc:      	add	x10, x19, x8
    10d0:      	ldp	q16, q6, [x10]
    10d4:      	and.16b	v16, v1, v16
    10d8:      	fmul.4s	v7, v16, v7
    10dc:      	add	x10, x9, x8
    10e0:      	tbnz	w11, #0x0, 0x11d8 <ltmp0+0x11d8>
    10e4:      	and	w11, w11, #0xff
    10e8:      	tbnz	w11, #0x1, 0x11e4 <ltmp0+0x11e4>
    10ec:      	tbnz	w11, #0x2, 0x11f0 <ltmp0+0x11f0>
    10f0:      	tbz	w11, #0x3, 0x10fc <ltmp0+0x10fc>
    10f4:      	add	x12, x10, #0xc
    10f8:      	st1.s	{ v7 }[3], [x12]
    10fc:      	and.16b	v4, v0, v4
    1100:      	fneg.4s	v7, v4
    1104:      	and.16b	v7, v0, v7
    1108:      	fcmge.4s	v16, v7, v2
    110c:      	fcmge.4s	v17, v3, v7
    1110:      	and.16b	v16, v16, v17
    1114:      	and.16b	v16, v16, v7
    1118:      	fmul.4s	v17, v16, v25
    111c:      	mov.16b	v18, v27
    1120:      	bsl.16b	v18, v26, v17
    1124:      	fadd.4s	v17, v17, v18
    1128:      	fsub.4s	v17, v17, v18
    112c:      	fcvtzs.4s	v17, v17
    1130:      	scvtf.4s	v18, v17
    1134:      	fmul.4s	v19, v18, v28
    1138:      	fadd.4s	v16, v16, v19
    113c:      	fmul.4s	v18, v18, v29
    1140:      	fadd.4s	v16, v16, v18
    1144:      	fmul.4s	v18, v16, v30
    1148:      	fadd.4s	v18, v18, v31
    114c:      	fmul.4s	v18, v16, v18
    1150:      	fadd.4s	v18, v18, v8
    1154:      	fmul.4s	v18, v16, v18
    1158:      	fadd.4s	v18, v18, v9
    115c:      	fmul.4s	v18, v16, v18
    1160:      	fadd.4s	v18, v18, v13
    1164:      	fmul.4s	v18, v16, v18
    1168:      	fadd.4s	v18, v18, v10
    116c:      	fmul.4s	v19, v16, v16
    1170:      	fmul.4s	v18, v19, v18
    1174:      	fadd.4s	v16, v16, v18
    1178:      	fadd.4s	v16, v16, v11
    117c:      	sshr.4s	v18, v17, #0x1
    1180:      	shl.4s	v19, v18, #0x17
    1184:      	add.4s	v19, v19, v11
    1188:      	fmul.4s	v16, v16, v19
    118c:      	sub.4s	v17, v17, v18
    1190:      	shl.4s	v17, v17, #0x17
    1194:      	add.4s	v17, v17, v11
    1198:      	fmul.4s	v16, v16, v17
    119c:      	fcmgt.4s	v17, v2, v7
    11a0:      	fcmgt.4s	v18, v7, v3
    11a4:      	fcmeq.4s	v7, v7, v7
    11a8:      	fadd.4s	v16, v16, v11
    11ac:      	bit.16b	v16, v11, v17
    11b0:      	bit.16b	v16, v12, v18
    11b4:      	bsl.16b	v7, v16, v14
    11b8:      	fdiv.4s	v4, v4, v7
    11bc:      	and.16b	v6, v0, v6
    11c0:      	fmul.4s	v4, v6, v4
    11c4:      	tbnz	w11, #0x4, 0x1200 <ltmp0+0x1200>
    11c8:      	tbnz	w11, #0x5, 0x1208 <ltmp0+0x1208>
    11cc:      	tbnz	w11, #0x6, 0x1214 <ltmp0+0x1214>
    11d0:      	tbz	w11, #0x7, 0xff4 <ltmp0+0xff4>
    11d4:      	b	0x1220 <ltmp0+0x1220>
    11d8:      	str	s7, [x10]
    11dc:      	and	w11, w11, #0xff
    11e0:      	tbz	w11, #0x1, 0x10ec <ltmp0+0x10ec>
    11e4:      	add	x12, x10, #0x4
    11e8:      	st1.s	{ v7 }[1], [x12]
    11ec:      	tbz	w11, #0x2, 0x10f0 <ltmp0+0x10f0>
    11f0:      	add	x12, x10, #0x8
    11f4:      	st1.s	{ v7 }[2], [x12]
    11f8:      	tbnz	w11, #0x3, 0x10f4 <ltmp0+0x10f4>
    11fc:      	b	0x10fc <ltmp0+0x10fc>
    1200:      	str	s4, [x10, #0x10]
    1204:      	tbz	w11, #0x5, 0x11cc <ltmp0+0x11cc>
    1208:      	add	x12, x10, #0x14
    120c:      	st1.s	{ v4 }[1], [x12]
    1210:      	tbz	w11, #0x6, 0x11d0 <ltmp0+0x11d0>
    1214:      	add	x12, x10, #0x18
    1218:      	st1.s	{ v4 }[2], [x12]
    121c:      	tbz	w11, #0x7, 0xff4 <ltmp0+0xff4>
    1220:      	add	x10, x10, #0x1c
    1224:      	st1.s	{ v4 }[3], [x10]
    1228:      	b	0xff4 <ltmp0+0xff4>
    122c:      	ldr	x9, [sp, #0x10]
    1230:      	stp	w15, w14, [x9]
    1234:      	str	w13, [x9, #0x8]
    1238:      	mov	w8, #0x18               ; =24
    123c:      	str	w8, [x9, #0x24]
    1240:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
    1244:      	add	sp, sp, #0x940
    1248:      	ldp	x29, x30, [sp, #0x90]
    124c:      	ldp	x20, x19, [sp, #0x80]
    1250:      	ldp	x22, x21, [sp, #0x70]
    1254:      	ldp	x24, x23, [sp, #0x60]
    1258:      	ldp	x26, x25, [sp, #0x50]
    125c:      	ldp	x28, x27, [sp, #0x40]
    1260:      	ldp	d9, d8, [sp, #0x30]
    1264:      	ldp	d11, d10, [sp, #0x20]
    1268:      	ldp	d13, d12, [sp, #0x10]
    126c:      	ldp	d15, d14, [sp], #0xa0
    1270:      	ret

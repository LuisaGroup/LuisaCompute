
/private/tmp/luisa-packet-inline.UY1lIE/capture/masked_softmax-17x65/on/object/tile_xir_w8_36353_1788935096877589_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      2c:      	sub	sp, sp, #0xa0
      30:      	str	x0, [sp, #0x1d0]
      34:      	str	w3, [sp, #0x1ec]
      38:      	cbz	w3, 0x3120 <ltmp0+0x3120>
      3c:      	mov	w8, #0x0                ; =0
      40:      	add	x9, sp, #0xab8
      44:      	add	x10, sp, #0xcf8
      48:      	dup.2d	v0, x10
      4c:      	add	x11, sp, #0xd40
      50:      	adrp	x10, 0x0 <ltmp0>
      54:      	ldr	q1, [x10]
      58:      	mov	w12, #0x1               ; =1
      5c:      	mov	w13, #0x40              ; =64
      60:      	add.2d	v1, v0, v1
      64:      	str	q1, [sp, #0x3e0]
      68:      	mov	w14, #0x3f04            ; =16132
      6c:      	movk	w14, #0x3f0, lsl #16
      70:      	adrp	x10, 0x0 <ltmp0>
      74:      	ldr	q11, [x10]
      78:      	adrp	x15, 0x0 <ltmp0>
      7c:      	adrp	x10, 0x0 <ltmp0>
      80:      	ldr	q12, [x10]
      84:      	adrp	x16, 0x0 <ltmp0>
      88:      	adrp	x10, 0x0 <ltmp0>
      8c:      	ldr	q21, [x10]
      90:      	adrp	x17, 0x0 <ltmp0>
      94:      	adrp	x10, 0x0 <ltmp0>
      98:      	ldr	q22, [x10]
      9c:      	add	x1, sp, #0xf80
      a0:      	add	x5, sp, #0xbd8
      a4:      	mov	w6, #-0x800000          ; =-8388608
      a8:      	dup.2d	v6, x12
      ac:      	adrp	x10, 0x0 <ltmp0>
      b0:      	ldr	q7, [x10]
      b4:      	adrp	x10, 0x0 <ltmp0>
      b8:      	ldr	q16, [x10]
      bc:      	mvni.4s	v1, #0x7f, msl #16
      c0:      	fneg.4s	v1, v1
      c4:      	str	q1, [sp, #0x340]
      c8:      	mvni.4s	v1, #0x3f, msl #16
      cc:      	fneg.4s	v1, v1
      d0:      	stp	q1, q21, [sp, #0x2b0]
      d4:      	ldr	w10, [x2, #0x2c]
      d8:      	str	w10, [sp, #0x1e8]
      dc:      	ldr	w10, [x2, #0x30]
      e0:      	str	w10, [sp, #0x1e4]
      e4:      	ldp	w10, w0, [x2]
      e8:      	str	x2, [sp, #0x8]
      ec:      	ldp	w3, w2, [x2, #0x8]
      f0:      	str	x2, [sp, #0x1d8]
      f4:      	stp	q12, q11, [sp, #0x2d0]
      f8:      	str	q22, [sp, #0x2f0]
      fc:      	str	q6, [sp, #0x2a0]
     100:      	str	q7, [sp, #0x3f0]
     104:      	b	0x154 <ltmp0+0x154>
     108:      	ldr	x19, [sp, #0x1f8]
     10c:      	add	w10, w19, #0x1
     110:      	ldr	w0, [sp, #0x1e8]
     114:      	cmp	w10, w0
     118:      	cset	w0, eq
     11c:      	csinc	w10, wzr, w19, eq
     120:      	ldr	w7, [sp, #0x1f0]
     124:      	cinc	w2, w7, eq
     128:      	ldr	w3, [sp, #0x1e4]
     12c:      	cmp	w2, w3
     130:      	cset	w3, eq
     134:      	ands	w3, w0, w3
     138:      	csel	w0, wzr, w2, ne
     13c:      	ldr	w4, [sp, #0x1f4]
     140:      	add	w3, w4, w3
     144:      	add	w8, w8, #0x1
     148:      	ldr	w2, [sp, #0x1ec]
     14c:      	cmp	w8, w2
     150:      	b.eq	0x310c <ltmp0+0x310c>
     154:      	str	w3, [sp, #0x1f4]
     158:      	mov	x7, x0
     15c:      	mov	x19, x10
     160:      	ubfiz	x10, x10, #5, #32
     164:      	ldr	x4, [sp, #0x1d8]
     168:      	cmp	x10, x4
     16c:      	csel	x0, x10, xzr, ls
     170:      	subs	x2, x4, x0
     174:      	cmp	x2, #0x20
     178:      	mov	w3, #0x20               ; =32
     17c:      	csel	x2, x2, x3, lo
     180:      	cmp	x4, x0
     184:      	ccmp	x10, x4, #0x2, hi
     188:      	csel	x0, x2, xzr, ls
     18c:      	mov	w10, #0xf2ca            ; =62154
     190:      	movk	w10, #0xf149, lsl #16
     194:      	dup.4s	v1, w10
     198:      	str	q1, [sp, #0x300]
     19c:      	mov	w10, #-0x3d300000       ; =-1026555904
     1a0:      	dup.4s	v1, w10
     1a4:      	str	q1, [sp, #0x400]
     1a8:      	mov	w10, #0x42c80000        ; =1120403456
     1ac:      	dup.4s	v1, w10
     1b0:      	str	q1, [sp, #0x410]
     1b4:      	mov	w10, #0xaa3b            ; =43579
     1b8:      	movk	w10, #0x3fb8, lsl #16
     1bc:      	dup.4s	v2, w10
     1c0:      	mov	w10, #0x7200            ; =29184
     1c4:      	movk	w10, #0xbf31, lsl #16
     1c8:      	dup.4s	v1, w10
     1cc:      	stp	q2, q1, [sp, #0x350]
     1d0:      	mov	w10, #0xbe8e            ; =48782
     1d4:      	movk	w10, #0xb5bf, lsl #16
     1d8:      	dup.4s	v2, w10
     1dc:      	mov	w10, #0x2bda            ; =11226
     1e0:      	movk	w10, #0x3950, lsl #16
     1e4:      	dup.4s	v1, w10
     1e8:      	stp	q2, q1, [sp, #0x370]
     1ec:      	mov	w10, #0x96c9            ; =38601
     1f0:      	movk	w10, #0x3ab6, lsl #16
     1f4:      	dup.4s	v1, w10
     1f8:      	str	q1, [sp, #0x390]
     1fc:      	mov	w10, #0x88a6            ; =34982
     200:      	movk	w10, #0x3c08, lsl #16
     204:      	dup.4s	v2, w10
     208:      	mov	w10, #0xaa7a            ; =43642
     20c:      	movk	w10, #0x3d2a, lsl #16
     210:      	dup.4s	v1, w10
     214:      	stp	q2, q1, [sp, #0x310]
     218:      	mov	w10, #0xaaab            ; =43691
     21c:      	movk	w10, #0x3e2a, lsl #16
     220:      	dup.4s	v1, w10
     224:      	str	q1, [sp, #0x330]
     228:      	fmov.4s	v8, #1.00000000
     22c:      	cmp	x0, #0x20
     230:      	str	w7, [sp, #0x1f0]
     234:      	str	x19, [sp, #0x1f8]
     238:      	b.lo	0xa34 <ltmp0+0xa34>
     23c:      	mov	x10, #0x0               ; =0
     240:      	ldr	x2, [sp, #0x1d0]
     244:      	ldr	x0, [x2]
     248:      	ldr	x3, [x2, #0x30]
     24c:      	lsl	w4, w19, #2
     250:      	mov	x2, #0x0                ; =0
     254:      	add	w7, w10, w4
     258:      	and	x21, x7, #0x1fffffff
     25c:      	add	x7, x21, x21, lsl #6
     260:      	lsl	x7, x7, #2
     264:      	add	x19, x0, x7
     268:      	ldp	q1, q2, [x19, #0xc0]
     26c:      	str	q1, [sp, #0x1040]
     270:      	str	q2, [sp, #0x1050]
     274:      	ldp	q1, q2, [x19, #0xe0]
     278:      	str	q1, [sp, #0x1060]
     27c:      	str	q2, [sp, #0x1070]
     280:      	ldp	q1, q2, [x19, #0x80]
     284:      	str	q1, [sp, #0x1000]
     288:      	str	q2, [sp, #0x1010]
     28c:      	ldp	q1, q2, [x19, #0xa0]
     290:      	str	q1, [sp, #0x1020]
     294:      	str	q2, [sp, #0x1030]
     298:      	ldp	q1, q2, [x19, #0x40]
     29c:      	str	q1, [sp, #0xfc0]
     2a0:      	str	q2, [sp, #0xfd0]
     2a4:      	ldp	q1, q2, [x19, #0x60]
     2a8:      	str	q1, [sp, #0xfe0]
     2ac:      	str	q2, [sp, #0xff0]
     2b0:      	ldp	q1, q2, [x19]
     2b4:      	ldp	q3, q4, [x19, #0x20]
     2b8:      	add	x20, x7, #0x100
     2bc:      	add	x19, x0, x20
     2c0:      	ldr	q18, [sp, #0x3d0]
     2c4:      	ld1.s	{ v18 }[0], [x19]
     2c8:      	str	q1, [sp, #0xf80]
     2cc:      	str	q2, [sp, #0xf90]
     2d0:      	str	q3, [sp, #0xfa0]
     2d4:      	str	q4, [sp, #0xfb0]
     2d8:      	movi.2d	v1, #0000000000000000
     2dc:      	movi.2d	v2, #0000000000000000
     2e0:      	movi.2d	v3, #0000000000000000
     2e4:      	movi.2d	v4, #0000000000000000
     2e8:      	str	q0, [sp, #0x1090]
     2ec:      	str	q18, [sp, #0x1080]
     2f0:      	shl.2d	v5, v1, #0x3
     2f4:      	shl.2d	v17, v2, #0x3
     2f8:      	shl.2d	v19, v3, #0x3
     2fc:      	shl.2d	v20, v4, #0x3
     300:      	orr.16b	v20, v20, v11
     304:      	orr.16b	v19, v19, v12
     308:      	orr.16b	v17, v17, v21
     30c:      	orr.16b	v5, v5, v22
     310:      	add	x2, x11, x2, lsl #6
     314:      	stp	q5, q17, [x2]
     318:      	stp	q19, q20, [x2, #0x20]
     31c:      	add.2d	v3, v3, v6
     320:      	add.2d	v2, v2, v6
     324:      	add.2d	v4, v4, v6
     328:      	add.2d	v1, v1, v6
     32c:      	fmov	x2, d1
     330:      	cmp	x2, #0x8
     334:      	b.lt	0x2f0 <ltmp0+0x2f0>
     338:      	mov	x2, #0x0                ; =0
     33c:      	umull	x19, w21, w14
     340:      	lsr	x19, x19, #32
     344:      	add	w19, w19, w19, lsl #6
     348:      	sub	w19, w21, w19
     34c:      	dup.2s	v1, w19
     350:      	str	x13, [sp, #0xf40]
     354:      	ushll.2d	v1, v1, #0x0
     358:      	movi.2d	v2, #0000000000000000
     35c:      	movi.2d	v3, #0000000000000000
     360:      	movi.2d	v4, #0000000000000000
     364:      	movi.2d	v5, #0000000000000000
     368:      	movi.8b	v22, #0x1
     36c:      	ldr	q23, [sp, #0x410]
     370:      	ldr	q6, [sp, #0x300]
     374:      	add	x2, x11, x2, lsl #6
     378:      	ldp	q19, q17, [x2, #0x20]
     37c:      	ldp	q20, q27, [x2]
     380:      	ldr	q24, [x15]
     384:      	ldr	q25, [x16]
     388:      	add.2d	v28, v5, v25
     38c:      	add.2d	v29, v3, v16
     390:      	add.2d	v29, v29, v0
     394:      	add.2d	v21, v2, v7
     398:      	add.2d	v21, v21, v0
     39c:      	cmge.2d	v27, v1, v27
     3a0:      	cmge.2d	v20, v1, v20
     3a4:      	uzp1.4s	v20, v20, v27
     3a8:      	cmge.2d	v19, v1, v19
     3ac:      	cmge.2d	v17, v1, v17
     3b0:      	uzp1.4s	v17, v19, v17
     3b4:      	uzp1.8h	v17, v20, v17
     3b8:      	xtn.8b	v17, v17
     3bc:      	and.8b	v17, v17, v22
     3c0:      	mov.d	x2, v21[1]
     3c4:      	fmov	x19, d21
     3c8:      	str	b17, [x19]
     3cc:      	st1.b	{ v17 }[1], [x2]
     3d0:      	mov.d	x2, v29[1]
     3d4:      	add.2d	v19, v4, v24
     3d8:      	fmov	x19, d29
     3dc:      	st1.b	{ v17 }[2], [x19]
     3e0:      	st1.b	{ v17 }[3], [x2]
     3e4:      	add.2d	v19, v19, v0
     3e8:      	mov.d	x2, v19[1]
     3ec:      	fmov	x19, d19
     3f0:      	st1.b	{ v17 }[4], [x19]
     3f4:      	add.2d	v19, v28, v0
     3f8:      	st1.b	{ v17 }[5], [x2]
     3fc:      	mov.d	x2, v19[1]
     400:      	fmov	x19, d19
     404:      	st1.b	{ v17 }[6], [x19]
     408:      	st1.b	{ v17 }[7], [x2]
     40c:      	dup.2d	v17, x12
     410:      	add.2d	v4, v4, v17
     414:      	add.2d	v3, v3, v17
     418:      	add.2d	v5, v5, v17
     41c:      	add.2d	v2, v2, v17
     420:      	fmov	x2, d2
     424:      	cmp	x2, #0x8
     428:      	b.lt	0x374 <ltmp0+0x374>
     42c:      	mov	x2, #0x0                ; =0
     430:      	ldr	q2, [x17]
     434:      	cmgt.2d	v1, v1, v2
     438:      	xtn.2s	v1, v1
     43c:      	uzp1.4h	v1, v1, v0
     440:      	uzp1.8b	v1, v1, v0
     444:      	and.8b	v1, v1, v22
     448:      	ldr	q2, [sp, #0x3e0]
     44c:      	fmov	x19, d2
     450:      	str	b1, [x19]
     454:      	movi.2d	v1, #0000000000000000
     458:      	movi.2d	v2, #0000000000000000
     45c:      	movi.2d	v3, #0000000000000000
     460:      	movi.2d	v4, #0000000000000000
     464:      	mvni.4s	v10, #0x80, lsl #24
     468:      	movi.4s	v11, #0x3f, lsl #24
     46c:      	ldr	q12, [sp, #0x340]
     470:      	add.2d	v5, v4, v25
     474:      	add.2d	v17, v3, v24
     478:      	add.2d	v5, v5, v0
     47c:      	add.2d	v19, v2, v16
     480:      	add.2d	v20, v1, v7
     484:      	add.2d	v20, v20, v0
     488:      	mov.d	x19, v20[1]
     48c:      	add.2d	v17, v17, v0
     490:      	add.2d	v19, v19, v0
     494:      	fmov	x21, d20
     498:      	mov.d	x22, v19[1]
     49c:      	mov.d	x23, v17[1]
     4a0:      	fmov	x24, d19
     4a4:      	ldr	b19, [x21]
     4a8:      	ld1.b	{ v19 }[1], [x19]
     4ac:      	mov.d	x19, v5[1]
     4b0:      	fmov	x21, d17
     4b4:      	ld1.b	{ v19 }[2], [x24]
     4b8:      	ld1.b	{ v19 }[3], [x22]
     4bc:      	fmov	x22, d5
     4c0:      	ld1.b	{ v19 }[4], [x21]
     4c4:      	ld1.b	{ v19 }[5], [x23]
     4c8:      	ld1.b	{ v19 }[6], [x22]
     4cc:      	ld1.b	{ v19 }[7], [x19]
     4d0:      	cmeq.8b	v5, v19, #0
     4d4:      	sshll.8h	v5, v5, #0x0
     4d8:      	sshll2.4s	v17, v5, #0x0
     4dc:      	sshll.4s	v5, v5, #0x0
     4e0:      	lsl	x2, x2, #5
     4e4:      	add	x19, x1, x2
     4e8:      	ldp	q20, q19, [x19]
     4ec:      	bsl.16b	v5, v6, v20
     4f0:      	bsl.16b	v17, v6, v19
     4f4:      	add	x2, x5, x2
     4f8:      	dup.2d	v19, x12
     4fc:      	stp	q5, q17, [x2]
     500:      	add.2d	v3, v3, v19
     504:      	add.2d	v2, v2, v19
     508:      	add.2d	v4, v4, v19
     50c:      	add.2d	v1, v1, v19
     510:      	fmov	x2, d1
     514:      	cmp	x2, #0x8
     518:      	b.lt	0x470 <ltmp0+0x470>
     51c:      	mov	x22, #0x0               ; =0
     520:      	ldr	q1, [sp, #0x3e0]
     524:      	fmov	x2, d1
     528:      	ldr	b1, [x2]
     52c:      	cmeq.8b	v1, v1, #0
     530:      	sshll.8h	v1, v1, #0x0
     534:      	stp	q1, q18, [sp, #0x3c0]
     538:      	sshll.4s	v1, v1, #0x0
     53c:      	bsl.16b	v1, v6, v18
     540:      	ldp	q27, q2, [x9, #0x210]
     544:      	mov.s	v2[0], v1[0]
     548:      	str	q2, [sp, #0x3b0]
     54c:      	str	q2, [x9, #0x220]
     550:      	ldp	q2, q3, [x9, #0x120]
     554:      	ldp	q5, q4, [x9, #0x140]
     558:      	ldp	q17, q19, [x9, #0x160]
     55c:      	ldp	q21, q20, [x9, #0x180]
     560:      	ldp	q29, q6, [x9, #0x1f0]
     564:      	fmaxnm.4s	v21, v21, v6
     568:      	fmaxnm.4s	v20, v20, v27
     56c:      	ldp	q27, q6, [x9, #0x1d0]
     570:      	fmaxnm.4s	v19, v19, v29
     574:      	fmaxnm.4s	v17, v17, v6
     578:      	ldp	q29, q6, [x9, #0x1b0]
     57c:      	fmaxnm.4s	v5, v5, v6
     580:      	fmaxnm.4s	v4, v4, v27
     584:      	ldr	q27, [x9, #0x1a0]
     588:      	fmaxnm.4s	v2, v2, v27
     58c:      	movi.2d	v27, #0000000000000000
     590:      	mov.s	v27[0], v1[0]
     594:      	fmaxnm.4s	v1, v2, v27
     598:      	mov.s	v2[0], v1[0]
     59c:      	fmaxnm.4s	v1, v3, v29
     5a0:      	fmaxnm.4s	v1, v1, v4
     5a4:      	fmaxnm.4s	v2, v2, v5
     5a8:      	fmaxnm.4s	v2, v2, v17
     5ac:      	fmaxnm.4s	v1, v1, v19
     5b0:      	fmaxnm.4s	v1, v1, v20
     5b4:      	fmaxnm.4s	v2, v2, v21
     5b8:      	rev64.4s	v3, v2
     5bc:      	rev64.4s	v4, v1
     5c0:      	fmaxnm.4s	v1, v1, v4
     5c4:      	fmaxnm.4s	v2, v2, v3
     5c8:      	ext.16b	v3, v2, v2, #0x8
     5cc:      	ext.16b	v4, v1, v1, #0x8
     5d0:      	fmaxnm.4s	v1, v1, v4
     5d4:      	fmaxnm.4s	v2, v2, v3
     5d8:      	fmaxnm.4s	v1, v2, v1
     5dc:      	fmov	s2, w6
     5e0:      	fmaxnm	s1, s1, s2
     5e4:      	str	q1, [sp, #0x3a0]
     5e8:      	dup.4s	v1, v1[0]
     5ec:      	movi.2d	v17, #0000000000000000
     5f0:      	movi.2d	v27, #0000000000000000
     5f4:      	movi.2d	v2, #0000000000000000
     5f8:      	movi.2d	v3, #0000000000000000
     5fc:      	ldr	q13, [sp, #0x2b0]
     600:      	ldp	q15, q14, [sp, #0x320]
     604:      	ldr	q26, [sp, #0x310]
     608:      	mov.16b	v18, v16
     60c:      	mov.16b	v16, v7
     610:      	ldp	q7, q6, [sp, #0x380]
     614:      	ldp	q31, q30, [sp, #0x360]
     618:      	ldr	q28, [sp, #0x400]
     61c:      	ldr	q9, [sp, #0x350]
     620:      	movi.4s	v22, #0x4b, lsl #24
     624:      	add.2d	v4, v2, v24
     628:      	add.2d	v4, v4, v0
     62c:      	add.2d	v5, v27, v18
     630:      	add.2d	v5, v5, v0
     634:      	add.2d	v19, v17, v16
     638:      	add.2d	v19, v19, v0
     63c:      	mov.d	x23, v19[1]
     640:      	mov.d	x24, v5[1]
     644:      	fmov	x26, d19
     648:      	fmov	x25, d5
     64c:      	mov.d	x21, v4[1]
     650:      	lsl	x22, x22, #5
     654:      	fmov	x2, d4
     658:      	add	x19, x5, x22
     65c:      	ldp	q4, q5, [x19]
     660:      	fsub.4s	v5, v5, v1
     664:      	fsub.4s	v4, v4, v1
     668:      	fcmge.4s	v19, v4, v28
     66c:      	fcmge.4s	v20, v5, v28
     670:      	fcmge.4s	v21, v23, v4
     674:      	fcmge.4s	v29, v23, v5
     678:      	and.16b	v20, v20, v29
     67c:      	and.16b	v19, v19, v21
     680:      	and.16b	v19, v19, v4
     684:      	and.16b	v20, v20, v5
     688:      	fmul.4s	v21, v20, v9
     68c:      	fmul.4s	v29, v19, v9
     690:      	mov.16b	v28, v10
     694:      	bsl.16b	v28, v22, v29
     698:      	movi.4s	v22, #0x4b, lsl #24
     69c:      	bif.16b	v22, v21, v10
     6a0:      	fadd.4s	v21, v21, v22
     6a4:      	fadd.4s	v29, v29, v28
     6a8:      	fsub.4s	v28, v29, v28
     6ac:      	fsub.4s	v21, v21, v22
     6b0:      	fcvtzs.4s	v21, v21
     6b4:      	fcvtzs.4s	v22, v28
     6b8:      	scvtf.4s	v28, v22
     6bc:      	scvtf.4s	v29, v21
     6c0:      	fmul.4s	v23, v28, v31
     6c4:      	fadd.4s	v19, v19, v23
     6c8:      	fmul.4s	v23, v29, v31
     6cc:      	fadd.4s	v20, v20, v23
     6d0:      	add.2d	v23, v3, v25
     6d4:      	add.2d	v23, v23, v0
     6d8:      	mov.d	x19, v23[1]
     6dc:      	fmul.4s	v28, v28, v30
     6e0:      	fmul.4s	v29, v29, v30
     6e4:      	fadd.4s	v20, v20, v29
     6e8:      	fadd.4s	v19, v19, v28
     6ec:      	fmul.4s	v28, v19, v7
     6f0:      	fmul.4s	v29, v20, v7
     6f4:      	fadd.4s	v29, v29, v6
     6f8:      	fadd.4s	v28, v28, v6
     6fc:      	fmul.4s	v28, v19, v28
     700:      	fmul.4s	v29, v20, v29
     704:      	fadd.4s	v29, v29, v26
     708:      	fadd.4s	v28, v28, v26
     70c:      	fmul.4s	v28, v19, v28
     710:      	fmul.4s	v29, v20, v29
     714:      	fadd.4s	v29, v29, v15
     718:      	fadd.4s	v28, v28, v15
     71c:      	fmul.4s	v28, v19, v28
     720:      	fmul.4s	v29, v20, v29
     724:      	fadd.4s	v29, v29, v14
     728:      	fadd.4s	v28, v28, v14
     72c:      	fmov	x27, d23
     730:      	fmul.4s	v23, v19, v28
     734:      	fmul.4s	v28, v20, v29
     738:      	fadd.4s	v28, v28, v11
     73c:      	fadd.4s	v23, v23, v11
     740:      	fmul.4s	v29, v19, v19
     744:      	fmul.4s	v23, v29, v23
     748:      	fmul.4s	v29, v20, v20
     74c:      	fmul.4s	v28, v29, v28
     750:      	fadd.4s	v20, v20, v28
     754:      	fadd.4s	v19, v19, v23
     758:      	sshr.4s	v23, v22, #0x1
     75c:      	fadd.4s	v20, v20, v8
     760:      	sshr.4s	v28, v21, #0x1
     764:      	shl.4s	v29, v28, #0x17
     768:      	add.4s	v29, v29, v8
     76c:      	fmul.4s	v20, v20, v29
     770:      	shl.4s	v29, v23, #0x17
     774:      	fadd.4s	v19, v19, v8
     778:      	add.4s	v29, v29, v8
     77c:      	fmul.4s	v19, v19, v29
     780:      	sub.4s	v21, v21, v28
     784:      	ldr	q28, [sp, #0x400]
     788:      	sub.4s	v22, v22, v23
     78c:      	ldr	q23, [sp, #0x410]
     790:      	shl.4s	v22, v22, #0x17
     794:      	add.4s	v22, v22, v8
     798:      	fmul.4s	v19, v19, v22
     79c:      	ldr	b22, [x26]
     7a0:      	ld1.b	{ v22 }[1], [x23]
     7a4:      	ld1.b	{ v22 }[2], [x25]
     7a8:      	ld1.b	{ v22 }[3], [x24]
     7ac:      	shl.4s	v21, v21, #0x17
     7b0:      	add.4s	v21, v21, v8
     7b4:      	fmul.4s	v20, v20, v21
     7b8:      	fcmgt.4s	v21, v28, v5
     7bc:      	bic.16b	v20, v20, v21
     7c0:      	fcmgt.4s	v21, v28, v4
     7c4:      	bic.16b	v19, v19, v21
     7c8:      	fcmgt.4s	v21, v4, v23
     7cc:      	bit.16b	v19, v12, v21
     7d0:      	fcmgt.4s	v21, v5, v23
     7d4:      	bit.16b	v20, v12, v21
     7d8:      	ld1.b	{ v22 }[4], [x2]
     7dc:      	ld1.b	{ v22 }[5], [x21]
     7e0:      	fcmeq.4s	v5, v5, v5
     7e4:      	bsl.16b	v5, v20, v13
     7e8:      	ld1.b	{ v22 }[6], [x27]
     7ec:      	ld1.b	{ v22 }[7], [x19]
     7f0:      	cmeq.8b	v20, v22, #0
     7f4:      	movi.4s	v22, #0x4b, lsl #24
     7f8:      	sshll.8h	v20, v20, #0x0
     7fc:      	fcmeq.4s	v4, v4, v4
     800:      	bsl.16b	v4, v19, v13
     804:      	sshll.4s	v19, v20, #0x0
     808:      	bic.16b	v4, v4, v19
     80c:      	sshll2.4s	v19, v20, #0x0
     810:      	bic.16b	v5, v5, v19
     814:      	add	x2, x9, x22
     818:      	stp	q4, q5, [x2]
     81c:      	dup.2d	v4, x12
     820:      	add.2d	v2, v2, v4
     824:      	add.2d	v27, v27, v4
     828:      	add.2d	v3, v3, v4
     82c:      	add.2d	v17, v17, v4
     830:      	fmov	x22, d17
     834:      	cmp	x22, #0x8
     838:      	b.lt	0x624 <ltmp0+0x624>
     83c:      	ldp	q2, q1, [sp, #0x3b0]
     840:      	sshll.4s	v1, v1, #0x0
     844:      	ldr	q3, [sp, #0x3a0]
     848:      	fsub.4s	v2, v2, v3
     84c:      	movi.2d	v3, #0000000000000000
     850:      	mov.s	v3[0], v2[0]
     854:      	fcmge.4s	v2, v3, v28
     858:      	fcmge.4s	v4, v23, v3
     85c:      	and.16b	v2, v2, v4
     860:      	and.16b	v2, v2, v3
     864:      	fmul.4s	v4, v2, v9
     868:      	mov.16b	v5, v10
     86c:      	bsl.16b	v5, v22, v4
     870:      	fadd.4s	v4, v4, v5
     874:      	fsub.4s	v4, v4, v5
     878:      	fcvtzs.4s	v4, v4
     87c:      	scvtf.4s	v5, v4
     880:      	fmul.4s	v17, v5, v31
     884:      	fadd.4s	v2, v2, v17
     888:      	fmul.4s	v5, v5, v30
     88c:      	fadd.4s	v2, v2, v5
     890:      	fmul.4s	v5, v2, v7
     894:      	fadd.4s	v5, v5, v6
     898:      	fmul.4s	v5, v2, v5
     89c:      	fadd.4s	v5, v5, v26
     8a0:      	fmul.4s	v5, v2, v5
     8a4:      	fadd.4s	v5, v5, v15
     8a8:      	fmul.4s	v5, v2, v5
     8ac:      	fadd.4s	v5, v5, v14
     8b0:      	fmul.4s	v5, v2, v5
     8b4:      	fadd.4s	v5, v5, v11
     8b8:      	fmul.4s	v17, v2, v2
     8bc:      	fmul.4s	v5, v17, v5
     8c0:      	fadd.4s	v2, v2, v5
     8c4:      	fadd.4s	v2, v2, v8
     8c8:      	sshr.4s	v5, v4, #0x1
     8cc:      	shl.4s	v17, v5, #0x17
     8d0:      	add.4s	v17, v17, v8
     8d4:      	fmul.4s	v2, v2, v17
     8d8:      	sub.4s	v4, v4, v5
     8dc:      	shl.4s	v4, v4, #0x17
     8e0:      	add.4s	v4, v4, v8
     8e4:      	fmul.4s	v2, v2, v4
     8e8:      	fcmgt.4s	v4, v28, v3
     8ec:      	bic.16b	v2, v2, v4
     8f0:      	fcmgt.4s	v4, v3, v23
     8f4:      	bit.16b	v2, v12, v4
     8f8:      	fcmeq.4s	v3, v3, v3
     8fc:      	bif.16b	v2, v13, v3
     900:      	bic.16b	v1, v2, v1
     904:      	ldp	q3, q2, [x9, #0xf0]
     908:      	mov.s	v2[0], v1[0]
     90c:      	str	q2, [x9, #0x100]
     910:      	ldp	q17, q19, [x9]
     914:      	ldp	q20, q21, [x9, #0x20]
     918:      	ldp	q22, q23, [x9, #0x40]
     91c:      	ldp	q24, q25, [x9, #0x60]
     920:      	ldp	q5, q2, [x9, #0xd0]
     924:      	ldp	q28, q4, [x9, #0xb0]
     928:      	ldp	q10, q27, [x9, #0x90]
     92c:      	fadd.4s	v29, v21, v28
     930:      	ldr	q9, [x9, #0x80]
     934:      	fadd.4s	v11, v17, v9
     938:      	fadd.4s	v12, v1, v11
     93c:      	mov.s	v11[0], v12[0]
     940:      	fadd.4s	v12, v20, v27
     944:      	fadd.4s	v11, v12, v11
     948:      	fadd.4s	v12, v19, v10
     94c:      	fadd.4s	v29, v29, v12
     950:      	fadd.4s	v12, v22, v4
     954:      	fadd.4s	v11, v12, v11
     958:      	fadd.4s	v12, v23, v5
     95c:      	fadd.4s	v29, v12, v29
     960:      	fadd.4s	v12, v24, v2
     964:      	fadd.4s	v11, v12, v11
     968:      	fadd.4s	v12, v25, v3
     96c:      	fadd.4s	v29, v12, v29
     970:      	rev64.4s	v12, v11
     974:      	fadd.4s	v11, v11, v12
     978:      	rev64.4s	v12, v29
     97c:      	fadd.4s	v29, v29, v12
     980:      	dup.4s	v12, v11[2]
     984:      	fadd.4s	v11, v11, v12
     988:      	dup.4s	v12, v29[2]
     98c:      	fadd.4s	v29, v29, v12
     990:      	fadd.4s	v29, v11, v29
     994:      	movi	d11, #0000000000000000
     998:      	fadd	s29, s29, s11
     99c:      	dup.4s	v11, v29[0]
     9a0:      	add	x2, x3, x7
     9a4:      	fdiv.4s	v17, v17, v11
     9a8:      	fdiv.4s	v19, v19, v11
     9ac:      	stp	q17, q19, [x2]
     9b0:      	fdiv.4s	v17, v20, v11
     9b4:      	fdiv.4s	v19, v21, v11
     9b8:      	stp	q17, q19, [x2, #0x20]
     9bc:      	fdiv.4s	v17, v22, v11
     9c0:      	fdiv.4s	v19, v23, v11
     9c4:      	stp	q17, q19, [x2, #0x40]
     9c8:      	fdiv.4s	v17, v24, v11
     9cc:      	fdiv.4s	v19, v25, v11
     9d0:      	stp	q17, q19, [x2, #0x60]
     9d4:      	fdiv.4s	v17, v9, v11
     9d8:      	fdiv.4s	v19, v10, v11
     9dc:      	stp	q17, q19, [x2, #0x80]
     9e0:      	fdiv.4s	v17, v27, v11
     9e4:      	fdiv.4s	v19, v28, v11
     9e8:      	stp	q17, q19, [x2, #0xa0]
     9ec:      	fdiv.4s	v4, v4, v11
     9f0:      	fdiv.4s	v5, v5, v11
     9f4:      	stp	q4, q5, [x2, #0xc0]
     9f8:      	fdiv.4s	v2, v2, v11
     9fc:      	fdiv.4s	v3, v3, v11
     a00:      	stp	q2, q3, [x2, #0xe0]
     a04:      	fdiv.4s	v1, v1, v29
     a08:      	str	s1, [x3, x20]
     a0c:      	add	x10, x10, #0x1
     a10:      	cmp	x10, #0x4
     a14:      	ldp	q12, q11, [sp, #0x2d0]
     a18:      	ldr	q21, [sp, #0x2c0]
     a1c:      	ldr	q22, [sp, #0x2f0]
     a20:      	ldr	q6, [sp, #0x2a0]
     a24:      	mov.16b	v7, v16
     a28:      	mov.16b	v16, v18
     a2c:      	b.ne	0x250 <ltmp0+0x250>
     a30:      	b	0x108 <ltmp0+0x108>
     a34:      	lsr	x10, x0, #3
     a38:      	cmp	x0, #0x8
     a3c:      	b.lo	0x1218 <ltmp0+0x1218>
     a40:      	mov	x3, #0x0                ; =0
     a44:      	ldr	x2, [sp, #0x1d0]
     a48:      	ldr	x4, [x2]
     a4c:      	ldr	x7, [x2, #0x30]
     a50:      	ldr	x2, [sp, #0x1f8]
     a54:      	lsl	w20, w2, #2
     a58:      	mov	x2, #0x0                ; =0
     a5c:      	add	w19, w3, w20
     a60:      	and	x23, x19, #0x1fffffff
     a64:      	add	x19, x23, x23, lsl #6
     a68:      	lsl	x21, x19, #2
     a6c:      	add	x19, x4, x21
     a70:      	ldp	q1, q2, [x19, #0xc0]
     a74:      	str	q1, [sp, #0x1040]
     a78:      	str	q2, [sp, #0x1050]
     a7c:      	ldp	q1, q2, [x19, #0xe0]
     a80:      	str	q1, [sp, #0x1060]
     a84:      	str	q2, [sp, #0x1070]
     a88:      	ldp	q1, q2, [x19, #0x80]
     a8c:      	str	q1, [sp, #0x1000]
     a90:      	str	q2, [sp, #0x1010]
     a94:      	ldp	q1, q2, [x19, #0xa0]
     a98:      	str	q1, [sp, #0x1020]
     a9c:      	str	q2, [sp, #0x1030]
     aa0:      	ldp	q1, q2, [x19, #0x40]
     aa4:      	str	q1, [sp, #0xfc0]
     aa8:      	str	q2, [sp, #0xfd0]
     aac:      	ldp	q1, q2, [x19, #0x60]
     ab0:      	str	q1, [sp, #0xfe0]
     ab4:      	str	q2, [sp, #0xff0]
     ab8:      	ldp	q1, q2, [x19]
     abc:      	str	q1, [sp, #0xf80]
     ac0:      	str	q2, [sp, #0xf90]
     ac4:      	ldp	q1, q2, [x19, #0x20]
     ac8:      	add	x22, x21, #0x100
     acc:      	str	q1, [sp, #0xfa0]
     ad0:      	str	q2, [sp, #0xfb0]
     ad4:      	movi.2d	v1, #0000000000000000
     ad8:      	movi.2d	v2, #0000000000000000
     adc:      	ldr	s27, [x4, x22]
     ae0:      	movi.2d	v3, #0000000000000000
     ae4:      	movi.2d	v4, #0000000000000000
     ae8:      	str	q27, [sp, #0x1080]
     aec:      	shl.2d	v5, v1, #0x3
     af0:      	shl.2d	v17, v2, #0x3
     af4:      	shl.2d	v19, v3, #0x3
     af8:      	shl.2d	v20, v4, #0x3
     afc:      	orr.16b	v20, v20, v11
     b00:      	orr.16b	v19, v19, v12
     b04:      	orr.16b	v17, v17, v21
     b08:      	orr.16b	v5, v5, v22
     b0c:      	add	x2, x11, x2, lsl #6
     b10:      	stp	q5, q17, [x2]
     b14:      	stp	q19, q20, [x2, #0x20]
     b18:      	dup.2d	v5, x12
     b1c:      	add.2d	v3, v3, v5
     b20:      	add.2d	v2, v2, v5
     b24:      	add.2d	v4, v4, v5
     b28:      	add.2d	v1, v1, v5
     b2c:      	fmov	x2, d1
     b30:      	cmp	x2, #0x8
     b34:      	b.lt	0xaec <ltmp0+0xaec>
     b38:      	mov	x2, #0x0                ; =0
     b3c:      	umull	x19, w23, w14
     b40:      	lsr	x19, x19, #32
     b44:      	add	w19, w19, w19, lsl #6
     b48:      	sub	w19, w23, w19
     b4c:      	dup.2s	v1, w19
     b50:      	str	x13, [sp, #0xf40]
     b54:      	ushll.2d	v2, v1, #0x0
     b58:      	movi.2d	v3, #0000000000000000
     b5c:      	movi.2d	v4, #0000000000000000
     b60:      	movi.2d	v5, #0000000000000000
     b64:      	movi.2d	v17, #0000000000000000
     b68:      	movi.8b	v29, #0x1
     b6c:      	movi.4s	v9, #0x4b, lsl #24
     b70:      	ldr	q6, [sp, #0x300]
     b74:      	add	x2, x11, x2, lsl #6
     b78:      	ldp	q20, q19, [x2, #0x20]
     b7c:      	ldp	q21, q22, [x2]
     b80:      	ldr	q1, [x15]
     b84:      	ldr	q24, [x16]
     b88:      	add.2d	v23, v17, v24
     b8c:      	add.2d	v25, v4, v16
     b90:      	add.2d	v25, v25, v0
     b94:      	add.2d	v28, v3, v7
     b98:      	add.2d	v28, v28, v0
     b9c:      	cmge.2d	v22, v2, v22
     ba0:      	cmge.2d	v21, v2, v21
     ba4:      	uzp1.4s	v21, v21, v22
     ba8:      	cmge.2d	v20, v2, v20
     bac:      	cmge.2d	v19, v2, v19
     bb0:      	uzp1.4s	v19, v20, v19
     bb4:      	uzp1.8h	v19, v21, v19
     bb8:      	xtn.8b	v19, v19
     bbc:      	and.8b	v19, v19, v29
     bc0:      	mov.d	x2, v28[1]
     bc4:      	fmov	x19, d28
     bc8:      	str	b19, [x19]
     bcc:      	st1.b	{ v19 }[1], [x2]
     bd0:      	mov.d	x2, v25[1]
     bd4:      	add.2d	v20, v5, v1
     bd8:      	fmov	x19, d25
     bdc:      	st1.b	{ v19 }[2], [x19]
     be0:      	st1.b	{ v19 }[3], [x2]
     be4:      	add.2d	v20, v20, v0
     be8:      	mov.d	x2, v20[1]
     bec:      	fmov	x19, d20
     bf0:      	st1.b	{ v19 }[4], [x19]
     bf4:      	add.2d	v20, v23, v0
     bf8:      	st1.b	{ v19 }[5], [x2]
     bfc:      	mov.d	x2, v20[1]
     c00:      	fmov	x19, d20
     c04:      	st1.b	{ v19 }[6], [x19]
     c08:      	st1.b	{ v19 }[7], [x2]
     c0c:      	dup.2d	v19, x12
     c10:      	add.2d	v5, v5, v19
     c14:      	add.2d	v4, v4, v19
     c18:      	add.2d	v17, v17, v19
     c1c:      	add.2d	v3, v3, v19
     c20:      	fmov	x2, d3
     c24:      	cmp	x2, #0x8
     c28:      	b.lt	0xb74 <ltmp0+0xb74>
     c2c:      	mov	x2, #0x0                ; =0
     c30:      	ldr	q3, [x17]
     c34:      	cmgt.2d	v2, v2, v3
     c38:      	xtn.2s	v2, v2
     c3c:      	uzp1.4h	v2, v2, v0
     c40:      	uzp1.8b	v2, v2, v0
     c44:      	and.8b	v2, v2, v29
     c48:      	ldr	q3, [sp, #0x3e0]
     c4c:      	fmov	x19, d3
     c50:      	str	b2, [x19]
     c54:      	movi.2d	v2, #0000000000000000
     c58:      	movi.2d	v3, #0000000000000000
     c5c:      	movi.2d	v4, #0000000000000000
     c60:      	movi.2d	v5, #0000000000000000
     c64:      	add.2d	v17, v5, v24
     c68:      	add.2d	v19, v4, v1
     c6c:      	add.2d	v17, v17, v0
     c70:      	add.2d	v20, v3, v16
     c74:      	add.2d	v21, v2, v7
     c78:      	add.2d	v21, v21, v0
     c7c:      	mov.d	x19, v21[1]
     c80:      	add.2d	v19, v19, v0
     c84:      	add.2d	v20, v20, v0
     c88:      	fmov	x23, d21
     c8c:      	mov.d	x24, v20[1]
     c90:      	mov.d	x25, v19[1]
     c94:      	fmov	x26, d20
     c98:      	ldr	b20, [x23]
     c9c:      	ld1.b	{ v20 }[1], [x19]
     ca0:      	mov.d	x19, v17[1]
     ca4:      	fmov	x23, d19
     ca8:      	ld1.b	{ v20 }[2], [x26]
     cac:      	ld1.b	{ v20 }[3], [x24]
     cb0:      	fmov	x24, d17
     cb4:      	ld1.b	{ v20 }[4], [x23]
     cb8:      	ld1.b	{ v20 }[5], [x25]
     cbc:      	ld1.b	{ v20 }[6], [x24]
     cc0:      	ld1.b	{ v20 }[7], [x19]
     cc4:      	cmeq.8b	v17, v20, #0
     cc8:      	sshll.8h	v17, v17, #0x0
     ccc:      	sshll2.4s	v19, v17, #0x0
     cd0:      	sshll.4s	v17, v17, #0x0
     cd4:      	lsl	x2, x2, #5
     cd8:      	add	x19, x1, x2
     cdc:      	ldp	q21, q20, [x19]
     ce0:      	bsl.16b	v17, v6, v21
     ce4:      	bsl.16b	v19, v6, v20
     ce8:      	add	x2, x5, x2
     cec:      	dup.2d	v20, x12
     cf0:      	stp	q17, q19, [x2]
     cf4:      	add.2d	v4, v4, v20
     cf8:      	add.2d	v3, v3, v20
     cfc:      	add.2d	v5, v5, v20
     d00:      	add.2d	v2, v2, v20
     d04:      	fmov	x2, d2
     d08:      	cmp	x2, #0x8
     d0c:      	b.lt	0xc64 <ltmp0+0xc64>
     d10:      	mov	x24, #0x0               ; =0
     d14:      	ldr	q2, [sp, #0x3e0]
     d18:      	fmov	x2, d2
     d1c:      	ldr	b2, [x2]
     d20:      	cmeq.8b	v2, v2, #0
     d24:      	sshll.8h	v2, v2, #0x0
     d28:      	str	q2, [sp, #0x3d0]
     d2c:      	sshll.4s	v2, v2, #0x0
     d30:      	bsl.16b	v2, v6, v27
     d34:      	ldp	q23, q3, [x9, #0x210]
     d38:      	mov.s	v3[0], v2[0]
     d3c:      	str	q3, [sp, #0x3c0]
     d40:      	str	q3, [x9, #0x220]
     d44:      	ldp	q3, q4, [x9, #0x120]
     d48:      	ldp	q17, q5, [x9, #0x140]
     d4c:      	ldp	q19, q20, [x9, #0x160]
     d50:      	ldp	q22, q21, [x9, #0x180]
     d54:      	ldp	q25, q6, [x9, #0x1f0]
     d58:      	fmaxnm.4s	v22, v22, v6
     d5c:      	fmaxnm.4s	v21, v21, v23
     d60:      	ldp	q23, q6, [x9, #0x1d0]
     d64:      	fmaxnm.4s	v20, v20, v25
     d68:      	fmaxnm.4s	v19, v19, v6
     d6c:      	ldp	q25, q6, [x9, #0x1b0]
     d70:      	fmaxnm.4s	v17, v17, v6
     d74:      	fmaxnm.4s	v5, v5, v23
     d78:      	ldr	q23, [x9, #0x1a0]
     d7c:      	fmaxnm.4s	v3, v3, v23
     d80:      	movi.2d	v23, #0000000000000000
     d84:      	mov.s	v23[0], v2[0]
     d88:      	fmaxnm.4s	v2, v3, v23
     d8c:      	mov.s	v3[0], v2[0]
     d90:      	fmaxnm.4s	v2, v4, v25
     d94:      	fmaxnm.4s	v2, v2, v5
     d98:      	fmaxnm.4s	v3, v3, v17
     d9c:      	fmaxnm.4s	v3, v3, v19
     da0:      	fmaxnm.4s	v2, v2, v20
     da4:      	fmaxnm.4s	v2, v2, v21
     da8:      	fmaxnm.4s	v3, v3, v22
     dac:      	rev64.4s	v4, v3
     db0:      	rev64.4s	v5, v2
     db4:      	fmaxnm.4s	v2, v2, v5
     db8:      	fmaxnm.4s	v3, v3, v4
     dbc:      	ext.16b	v4, v3, v3, #0x8
     dc0:      	ext.16b	v5, v2, v2, #0x8
     dc4:      	fmaxnm.4s	v2, v2, v5
     dc8:      	fmaxnm.4s	v3, v3, v4
     dcc:      	fmaxnm.4s	v2, v3, v2
     dd0:      	fmov	s3, w6
     dd4:      	fmaxnm	s2, s2, s3
     dd8:      	str	q2, [sp, #0x3b0]
     ddc:      	dup.4s	v29, v2[0]
     de0:      	movi.2d	v17, #0000000000000000
     de4:      	movi.2d	v25, #0000000000000000
     de8:      	movi.2d	v2, #0000000000000000
     dec:      	movi.2d	v3, #0000000000000000
     df0:      	ldp	q14, q27, [sp, #0x330]
     df4:      	ldr	q13, [sp, #0x2b0]
     df8:      	ldp	q26, q15, [sp, #0x310]
     dfc:      	ldp	q7, q6, [sp, #0x380]
     e00:      	mov.16b	v18, v16
     e04:      	ldp	q31, q30, [sp, #0x360]
     e08:      	ldr	q23, [sp, #0x410]
     e0c:      	ldr	q10, [sp, #0x400]
     e10:      	ldr	q12, [sp, #0x350]
     e14:      	movi.4s	v11, #0x3f, lsl #24
     e18:      	mvni.4s	v16, #0x80, lsl #24
     e1c:      	add.2d	v4, v2, v1
     e20:      	add.2d	v4, v4, v0
     e24:      	add.2d	v5, v25, v18
     e28:      	add.2d	v5, v5, v0
     e2c:      	ldr	q19, [sp, #0x3f0]
     e30:      	add.2d	v19, v17, v19
     e34:      	add.2d	v19, v19, v0
     e38:      	mov.d	x25, v19[1]
     e3c:      	mov.d	x26, v5[1]
     e40:      	fmov	x28, d19
     e44:      	fmov	x27, d5
     e48:      	mov.d	x23, v4[1]
     e4c:      	lsl	x24, x24, #5
     e50:      	fmov	x2, d4
     e54:      	add	x19, x5, x24
     e58:      	ldp	q5, q4, [x19]
     e5c:      	fsub.4s	v4, v4, v29
     e60:      	fsub.4s	v28, v5, v29
     e64:      	fcmge.4s	v5, v28, v10
     e68:      	fcmge.4s	v19, v4, v10
     e6c:      	fcmge.4s	v20, v23, v28
     e70:      	fcmge.4s	v21, v23, v4
     e74:      	and.16b	v19, v19, v21
     e78:      	and.16b	v5, v5, v20
     e7c:      	and.16b	v5, v5, v28
     e80:      	and.16b	v19, v19, v4
     e84:      	fmul.4s	v20, v19, v12
     e88:      	fmul.4s	v21, v5, v12
     e8c:      	mov.16b	v22, v16
     e90:      	bsl.16b	v22, v9, v21
     e94:      	mov.16b	v23, v16
     e98:      	bsl.16b	v23, v9, v20
     e9c:      	fadd.4s	v20, v20, v23
     ea0:      	fadd.4s	v21, v21, v22
     ea4:      	fsub.4s	v21, v21, v22
     ea8:      	fsub.4s	v20, v20, v23
     eac:      	fcvtzs.4s	v20, v20
     eb0:      	fcvtzs.4s	v21, v21
     eb4:      	scvtf.4s	v22, v21
     eb8:      	scvtf.4s	v23, v20
     ebc:      	fmul.4s	v9, v22, v31
     ec0:      	fadd.4s	v5, v5, v9
     ec4:      	fmul.4s	v9, v23, v31
     ec8:      	fadd.4s	v19, v19, v9
     ecc:      	add.2d	v9, v3, v24
     ed0:      	add.2d	v9, v9, v0
     ed4:      	mov.d	x19, v9[1]
     ed8:      	fmul.4s	v22, v22, v30
     edc:      	fmul.4s	v23, v23, v30
     ee0:      	fadd.4s	v19, v19, v23
     ee4:      	fadd.4s	v5, v5, v22
     ee8:      	fmul.4s	v22, v5, v7
     eec:      	fmul.4s	v23, v19, v7
     ef0:      	fadd.4s	v23, v23, v6
     ef4:      	fadd.4s	v22, v22, v6
     ef8:      	fmul.4s	v22, v5, v22
     efc:      	fmul.4s	v23, v19, v23
     f00:      	fadd.4s	v23, v23, v26
     f04:      	fadd.4s	v22, v22, v26
     f08:      	fmul.4s	v22, v5, v22
     f0c:      	fmul.4s	v23, v19, v23
     f10:      	fadd.4s	v23, v23, v15
     f14:      	fadd.4s	v22, v22, v15
     f18:      	fmul.4s	v22, v5, v22
     f1c:      	fmul.4s	v23, v19, v23
     f20:      	fadd.4s	v23, v23, v14
     f24:      	fadd.4s	v22, v22, v14
     f28:      	fmov	x30, d9
     f2c:      	fmul.4s	v22, v5, v22
     f30:      	fmul.4s	v23, v19, v23
     f34:      	fadd.4s	v23, v23, v11
     f38:      	fadd.4s	v22, v22, v11
     f3c:      	fmul.4s	v9, v5, v5
     f40:      	fmul.4s	v22, v9, v22
     f44:      	fmul.4s	v9, v19, v19
     f48:      	fmul.4s	v23, v9, v23
     f4c:      	fadd.4s	v19, v19, v23
     f50:      	fadd.4s	v5, v5, v22
     f54:      	sshr.4s	v22, v21, #0x1
     f58:      	fadd.4s	v19, v19, v8
     f5c:      	sshr.4s	v23, v20, #0x1
     f60:      	shl.4s	v9, v23, #0x17
     f64:      	add.4s	v9, v9, v8
     f68:      	fmul.4s	v19, v19, v9
     f6c:      	shl.4s	v9, v22, #0x17
     f70:      	fadd.4s	v5, v5, v8
     f74:      	add.4s	v9, v9, v8
     f78:      	fmul.4s	v5, v5, v9
     f7c:      	movi.4s	v9, #0x4b, lsl #24
     f80:      	sub.4s	v20, v20, v23
     f84:      	ldr	q23, [sp, #0x410]
     f88:      	sub.4s	v21, v21, v22
     f8c:      	shl.4s	v21, v21, #0x17
     f90:      	add.4s	v21, v21, v8
     f94:      	fmul.4s	v5, v5, v21
     f98:      	ldr	b21, [x28]
     f9c:      	ld1.b	{ v21 }[1], [x25]
     fa0:      	ld1.b	{ v21 }[2], [x27]
     fa4:      	ld1.b	{ v21 }[3], [x26]
     fa8:      	shl.4s	v20, v20, #0x17
     fac:      	add.4s	v20, v20, v8
     fb0:      	fmul.4s	v19, v19, v20
     fb4:      	fcmgt.4s	v20, v10, v4
     fb8:      	bic.16b	v19, v19, v20
     fbc:      	fcmgt.4s	v20, v10, v28
     fc0:      	bic.16b	v5, v5, v20
     fc4:      	fcmgt.4s	v20, v28, v23
     fc8:      	bit.16b	v5, v27, v20
     fcc:      	fcmgt.4s	v20, v4, v23
     fd0:      	bit.16b	v19, v27, v20
     fd4:      	ld1.b	{ v21 }[4], [x2]
     fd8:      	ld1.b	{ v21 }[5], [x23]
     fdc:      	fcmeq.4s	v4, v4, v4
     fe0:      	bsl.16b	v4, v19, v13
     fe4:      	ld1.b	{ v21 }[6], [x30]
     fe8:      	ld1.b	{ v21 }[7], [x19]
     fec:      	cmeq.8b	v19, v21, #0
     ff0:      	sshll.8h	v19, v19, #0x0
     ff4:      	fcmeq.4s	v20, v28, v28
     ff8:      	bif.16b	v5, v13, v20
     ffc:      	sshll.4s	v20, v19, #0x0
    1000:      	bic.16b	v5, v5, v20
    1004:      	sshll2.4s	v19, v19, #0x0
    1008:      	bic.16b	v4, v4, v19
    100c:      	add	x2, x9, x24
    1010:      	stp	q5, q4, [x2]
    1014:      	dup.2d	v4, x12
    1018:      	add.2d	v2, v2, v4
    101c:      	add.2d	v25, v25, v4
    1020:      	add.2d	v3, v3, v4
    1024:      	add.2d	v17, v17, v4
    1028:      	fmov	x24, d17
    102c:      	cmp	x24, #0x8
    1030:      	b.lt	0xe1c <ltmp0+0xe1c>
    1034:      	ldp	q2, q1, [sp, #0x3c0]
    1038:      	sshll.4s	v1, v1, #0x0
    103c:      	ldr	q3, [sp, #0x3b0]
    1040:      	fsub.4s	v2, v2, v3
    1044:      	movi.2d	v3, #0000000000000000
    1048:      	mov.s	v3[0], v2[0]
    104c:      	fcmge.4s	v2, v3, v10
    1050:      	fcmge.4s	v4, v23, v3
    1054:      	and.16b	v2, v2, v4
    1058:      	and.16b	v2, v2, v3
    105c:      	fmul.4s	v4, v2, v12
    1060:      	mov.16b	v5, v16
    1064:      	bsl.16b	v5, v9, v4
    1068:      	fadd.4s	v4, v4, v5
    106c:      	fsub.4s	v4, v4, v5
    1070:      	fcvtzs.4s	v4, v4
    1074:      	scvtf.4s	v5, v4
    1078:      	fmul.4s	v17, v5, v31
    107c:      	fadd.4s	v2, v2, v17
    1080:      	fmul.4s	v5, v5, v30
    1084:      	fadd.4s	v2, v2, v5
    1088:      	fmul.4s	v5, v2, v7
    108c:      	fadd.4s	v5, v5, v6
    1090:      	fmul.4s	v5, v2, v5
    1094:      	fadd.4s	v5, v5, v26
    1098:      	fmul.4s	v5, v2, v5
    109c:      	fadd.4s	v5, v5, v15
    10a0:      	fmul.4s	v5, v2, v5
    10a4:      	fadd.4s	v5, v5, v14
    10a8:      	fmul.4s	v5, v2, v5
    10ac:      	fadd.4s	v5, v5, v11
    10b0:      	fmul.4s	v17, v2, v2
    10b4:      	fmul.4s	v5, v17, v5
    10b8:      	fadd.4s	v2, v2, v5
    10bc:      	fadd.4s	v2, v2, v8
    10c0:      	sshr.4s	v5, v4, #0x1
    10c4:      	shl.4s	v17, v5, #0x17
    10c8:      	add.4s	v17, v17, v8
    10cc:      	fmul.4s	v2, v2, v17
    10d0:      	sub.4s	v4, v4, v5
    10d4:      	shl.4s	v4, v4, #0x17
    10d8:      	add.4s	v4, v4, v8
    10dc:      	fmul.4s	v2, v2, v4
    10e0:      	fcmgt.4s	v4, v10, v3
    10e4:      	bic.16b	v2, v2, v4
    10e8:      	fcmgt.4s	v4, v3, v23
    10ec:      	bit.16b	v2, v27, v4
    10f0:      	fcmeq.4s	v3, v3, v3
    10f4:      	bif.16b	v2, v13, v3
    10f8:      	bic.16b	v1, v2, v1
    10fc:      	ldp	q17, q19, [x9]
    1100:      	ldp	q20, q21, [x9, #0x20]
    1104:      	ldp	q22, q23, [x9, #0x40]
    1108:      	ldp	q24, q25, [x9, #0x60]
    110c:      	ldp	q2, q3, [x9, #0xe0]
    1110:      	ldp	q4, q5, [x9, #0xc0]
    1114:      	ldp	q27, q28, [x9, #0xa0]
    1118:      	fadd.4s	v29, v21, v28
    111c:      	ldp	q9, q10, [x9, #0x80]
    1120:      	fadd.4s	v11, v17, v9
    1124:      	fadd.4s	v12, v1, v11
    1128:      	mov.s	v11[0], v12[0]
    112c:      	fadd.4s	v12, v20, v27
    1130:      	fadd.4s	v11, v12, v11
    1134:      	fadd.4s	v12, v19, v10
    1138:      	fadd.4s	v29, v29, v12
    113c:      	fadd.4s	v12, v22, v4
    1140:      	fadd.4s	v11, v12, v11
    1144:      	fadd.4s	v12, v23, v5
    1148:      	fadd.4s	v29, v12, v29
    114c:      	fadd.4s	v12, v24, v2
    1150:      	fadd.4s	v11, v12, v11
    1154:      	fadd.4s	v12, v25, v3
    1158:      	fadd.4s	v29, v12, v29
    115c:      	rev64.4s	v12, v11
    1160:      	fadd.4s	v11, v11, v12
    1164:      	rev64.4s	v12, v29
    1168:      	fadd.4s	v29, v29, v12
    116c:      	dup.4s	v12, v11[2]
    1170:      	fadd.4s	v11, v11, v12
    1174:      	dup.4s	v12, v29[2]
    1178:      	fadd.4s	v29, v29, v12
    117c:      	fadd.4s	v29, v11, v29
    1180:      	movi	d11, #0000000000000000
    1184:      	fadd	s29, s29, s11
    1188:      	dup.4s	v11, v29[0]
    118c:      	add	x2, x7, x21
    1190:      	fdiv.4s	v17, v17, v11
    1194:      	fdiv.4s	v19, v19, v11
    1198:      	stp	q17, q19, [x2]
    119c:      	fdiv.4s	v17, v20, v11
    11a0:      	fdiv.4s	v19, v21, v11
    11a4:      	stp	q17, q19, [x2, #0x20]
    11a8:      	fdiv.4s	v17, v22, v11
    11ac:      	fdiv.4s	v19, v23, v11
    11b0:      	stp	q17, q19, [x2, #0x40]
    11b4:      	fdiv.4s	v17, v24, v11
    11b8:      	fdiv.4s	v19, v25, v11
    11bc:      	stp	q17, q19, [x2, #0x60]
    11c0:      	fdiv.4s	v17, v9, v11
    11c4:      	fdiv.4s	v19, v10, v11
    11c8:      	stp	q17, q19, [x2, #0x80]
    11cc:      	fdiv.4s	v17, v27, v11
    11d0:      	fdiv.4s	v19, v28, v11
    11d4:      	stp	q17, q19, [x2, #0xa0]
    11d8:      	fdiv.4s	v4, v4, v11
    11dc:      	fdiv.4s	v5, v5, v11
    11e0:      	stp	q4, q5, [x2, #0xc0]
    11e4:      	fdiv.4s	v2, v2, v11
    11e8:      	fdiv.4s	v3, v3, v11
    11ec:      	stp	q2, q3, [x2, #0xe0]
    11f0:      	fdiv.4s	v1, v1, v29
    11f4:      	str	s1, [x7, x22]
    11f8:      	add	x3, x3, #0x1
    11fc:      	cmp	x3, x10
    1200:      	ldp	q12, q11, [sp, #0x2d0]
    1204:      	ldr	q21, [sp, #0x2c0]
    1208:      	ldr	q22, [sp, #0x2f0]
    120c:      	ldr	q7, [sp, #0x3f0]
    1210:      	mov.16b	v16, v18
    1214:      	b.ne	0xa58 <ltmp0+0xa58>
    1218:      	and	w0, w0, #0x7
    121c:      	ldr	q6, [sp, #0x2a0]
    1220:      	cbz	w0, 0x108 <ltmp0+0x108>
    1224:      	dup.4s	v3, w0
    1228:      	adrp	x0, 0x1000 <ltmp0+0x1000>
    122c:      	ldr	q4, [x0]
    1230:      	adrp	x0, 0x1000 <ltmp0+0x1000>
    1234:      	ldr	q5, [x0]
    1238:      	cmhi.4s	v31, v3, v5
    123c:      	cmhi.4s	v26, v3, v4
    1240:      	uzp1.8h	v2, v26, v31
    1244:      	umaxv.8h	h1, v2
    1248:      	fmov	w0, s1
    124c:      	tbz	w0, #0x0, 0x108 <ltmp0+0x108>
    1250:      	stp	q5, q4, [sp, #0x190]
    1254:      	str	q3, [sp, #0x3a0]
    1258:      	mov	x3, #0x0                ; =0
    125c:      	ldr	x2, [sp, #0x1d0]
    1260:      	ldr	x0, [x2]
    1264:      	ldr	x2, [x2, #0x30]
    1268:      	str	x2, [sp, #0x188]
    126c:      	adrp	x2, 0x1000 <ltmp0+0x1000>
    1270:      	ldr	q1, [x2]
    1274:      	str	q2, [sp, #0xf0]
    1278:      	and.16b	v1, v2, v1
    127c:      	addv.8h	h6, v1
    1280:      	ldr	x2, [sp, #0x1f8]
    1284:      	ubfiz	w2, w2, #2, #27
    1288:      	orr	w10, w2, w10
    128c:      	fmov	w2, s6
    1290:      	and	w2, w2, #0xff
    1294:      	str	w2, [sp, #0x100]
    1298:      	dup.4s	v2, w10
    129c:      	and.16b	v3, v26, v2
    12a0:      	and.16b	v1, v31, v2
    12a4:      	ushll2.2d	v29, v1, #0x0
    12a8:      	ushll2.2d	v30, v3, #0x0
    12ac:      	ushll.2d	v9, v1, #0x0
    12b0:      	str	q3, [sp, #0x3d0]
    12b4:      	ushll.2d	v3, v3, #0x0
    12b8:      	fmov	x10, d3
    12bc:      	mov	w2, #0x104              ; =260
    12c0:      	umaddl	x10, w10, w2, x0
    12c4:      	b	0x12e8 <ltmp0+0x12e8>
    12c8:      	add	x2, x1, x3
    12cc:      	ldp	q4, q5, [x2]
    12d0:      	bit.16b	v5, v17, v31
    12d4:      	bif.16b	v2, v4, v26
    12d8:      	stp	q2, q5, [x2]
    12dc:      	add	x3, x3, #0x20
    12e0:      	cmp	x3, #0x100
    12e4:      	b.eq	0x1380 <ltmp0+0x1380>
    12e8:      	fmov	w2, s6
    12ec:      	add	x4, x10, x3
    12f0:      	movi.2d	v2, #0000000000000000
    12f4:      	movi.2d	v17, #0000000000000000
    12f8:      	tbnz	w2, #0x0, 0x1320 <ltmp0+0x1320>
    12fc:      	and	w2, w2, #0xff
    1300:      	tbnz	w2, #0x1, 0x132c <ltmp0+0x132c>
    1304:      	tbnz	w2, #0x2, 0x1338 <ltmp0+0x1338>
    1308:      	tbnz	w2, #0x3, 0x1344 <ltmp0+0x1344>
    130c:      	tbnz	w2, #0x4, 0x1350 <ltmp0+0x1350>
    1310:      	tbnz	w2, #0x5, 0x135c <ltmp0+0x135c>
    1314:      	tbnz	w2, #0x6, 0x1368 <ltmp0+0x1368>
    1318:      	tbz	w2, #0x7, 0x12c8 <ltmp0+0x12c8>
    131c:      	b	0x1374 <ltmp0+0x1374>
    1320:      	ldr	s2, [x4]
    1324:      	and	w2, w2, #0xff
    1328:      	tbz	w2, #0x1, 0x1304 <ltmp0+0x1304>
    132c:      	add	x7, x4, #0x4
    1330:      	ld1.s	{ v2 }[1], [x7]
    1334:      	tbz	w2, #0x2, 0x1308 <ltmp0+0x1308>
    1338:      	add	x7, x4, #0x8
    133c:      	ld1.s	{ v2 }[2], [x7]
    1340:      	tbz	w2, #0x3, 0x130c <ltmp0+0x130c>
    1344:      	add	x7, x4, #0xc
    1348:      	ld1.s	{ v2 }[3], [x7]
    134c:      	tbz	w2, #0x4, 0x1310 <ltmp0+0x1310>
    1350:      	add	x7, x4, #0x10
    1354:      	ld1.s	{ v17 }[0], [x7]
    1358:      	tbz	w2, #0x5, 0x1314 <ltmp0+0x1314>
    135c:      	add	x7, x4, #0x14
    1360:      	ld1.s	{ v17 }[1], [x7]
    1364:      	tbz	w2, #0x6, 0x1318 <ltmp0+0x1318>
    1368:      	add	x7, x4, #0x18
    136c:      	ld1.s	{ v17 }[2], [x7]
    1370:      	tbz	w2, #0x7, 0x12c8 <ltmp0+0x12c8>
    1374:      	add	x2, x4, #0x1c
    1378:      	ld1.s	{ v17 }[3], [x2]
    137c:      	b	0x12c8 <ltmp0+0x12c8>
    1380:      	xtn.4h	v2, v26
    1384:      	uzp1.8b	v4, v2, v0
    1388:      	sshll.2d	v2, v26, #0x0
    138c:      	and.16b	v17, v2, v22
    1390:      	movi.2d	v22, #0000000000000000
    1394:      	mov.b	v22[0], v4[0]
    1398:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    139c:      	ldr	d5, [x10]
    13a0:      	str	d5, [sp, #0x180]
    13a4:      	and.8b	v5, v22, v5
    13a8:      	addv.8b	b5, v5
    13ac:      	fmov	w10, s5
    13b0:      	umaxv.8b	b5, v22
    13b4:      	fmov	w2, s5
    13b8:      	rbit	w3, w10
    13bc:      	clz	w3, w3
    13c0:      	tst	w2, #0x1
    13c4:      	csel	w22, w3, wzr, ne
    13c8:      	dup.2d	v25, x13
    13cc:      	str	q17, [sp, #0xe0]
    13d0:      	orr.16b	v5, v17, v25
    13d4:      	xtn.2s	v17, v3
    13d8:      	str	q5, [sp, #0x3c0]
    13dc:      	movi.2s	v3, #0x41
    13e0:      	umlal.2d	v5, v17, v3
    13e4:      	movi.2d	v3, #0000000000000000
    13e8:      	mov.b	v3[0], v4[0]
    13ec:      	ushll.2d	v3, v3, #0x0
    13f0:      	shl.2d	v3, v3, #0x3f
    13f4:      	cmlt.2d	v3, v3, #0
    13f8:      	str	q5, [sp, #0x170]
    13fc:      	and.16b	v3, v3, v5
    1400:      	movi.2d	v4, #0000000000000000
    1404:      	str	q4, [sp, #0xaa0]
    1408:      	str	q4, [sp, #0xa90]
    140c:      	str	q4, [sp, #0xa80]
    1410:      	str	q3, [sp, #0xa70]
    1414:      	and	x3, x22, #0x7
    1418:      	add	x4, sp, #0xa70
    141c:      	ldr	x3, [x4, x3, lsl #3]
    1420:      	sub	x3, x3, x22
    1424:      	add	x0, x0, x3, lsl #2
    1428:      	movi.2d	v27, #0000000000000000
    142c:      	movi.2d	v28, #0000000000000000
    1430:      	tbnz	w2, #0x0, 0x1b90 <ltmp0+0x1b90>
    1434:      	ldr	q18, [sp, #0x300]
    1438:      	tbnz	w10, #0x1, 0x1b9c <ltmp0+0x1b9c>
    143c:      	tbnz	w10, #0x2, 0x1ba8 <ltmp0+0x1ba8>
    1440:      	tbnz	w10, #0x3, 0x1bb4 <ltmp0+0x1bb4>
    1444:      	tbnz	w10, #0x4, 0x1bc0 <ltmp0+0x1bc0>
    1448:      	tbnz	w10, #0x5, 0x1bcc <ltmp0+0x1bcc>
    144c:      	tbnz	w10, #0x6, 0x1bd8 <ltmp0+0x1bd8>
    1450:      	str	q6, [sp, #0x280]
    1454:      	tbz	w10, #0x7, 0x1460 <ltmp0+0x1460>
    1458:      	add	x0, x0, #0x1c
    145c:      	ld1.s	{ v28 }[3], [x0]
    1460:      	mov	x0, #0x0                ; =0
    1464:      	sshll.2d	v3, v31, #0x0
    1468:      	sshll2.2d	v23, v26, #0x0
    146c:      	sshll2.2d	v24, v31, #0x0
    1470:      	adrp	x2, 0x1000 <ltmp0+0x1000>
    1474:      	ldr	q4, [x2]
    1478:      	and.16b	v4, v24, v4
    147c:      	adrp	x2, 0x1000 <ltmp0+0x1000>
    1480:      	ldr	q5, [x2]
    1484:      	and.16b	v5, v23, v5
    1488:      	adrp	x2, 0x1000 <ltmp0+0x1000>
    148c:      	ldr	q19, [x2]
    1490:      	and.16b	v19, v3, v19
    1494:      	adrp	x2, 0x1000 <ltmp0+0x1000>
    1498:      	ldr	q20, [x2]
    149c:      	and.16b	v2, v2, v20
    14a0:      	str	q2, [sp, #0xd0]
    14a4:      	str	q2, [sp, #0xa30]
    14a8:      	str	q5, [sp, #0xa40]
    14ac:      	str	q19, [sp, #0xa50]
    14b0:      	str	q4, [sp, #0xa60]
    14b4:      	and	x2, x22, #0x7
    14b8:      	add	x3, sp, #0xa30
    14bc:      	ldr	x2, [x3, x2, lsl #3]
    14c0:      	orr	x2, x2, #0x100
    14c4:      	sub	x2, x2, x22, lsl #2
    14c8:      	tst	w10, #0xff
    14cc:      	csel	x23, xzr, x2, eq
    14d0:      	add	x2, x1, x23
    14d4:      	ldp	q2, q4, [x2]
    14d8:      	zip2.8b	v5, v22, v0
    14dc:      	ushll.4s	v5, v5, #0x0
    14e0:      	shl.4s	v5, v5, #0x1f
    14e4:      	cmlt.4s	v5, v5, #0
    14e8:      	str	q28, [sp, #0x270]
    14ec:      	bit.16b	v4, v28, v5
    14f0:      	str	q22, [sp, #0x1c0]
    14f4:      	zip1.8b	v5, v22, v0
    14f8:      	ushll.4s	v5, v5, #0x0
    14fc:      	shl.4s	v5, v5, #0x1f
    1500:      	cmlt.4s	v5, v5, #0
    1504:      	str	q27, [sp, #0x290]
    1508:      	bit.16b	v2, v27, v5
    150c:      	stp	q2, q4, [x2]
    1510:      	and.16b	v2, v24, v11
    1514:      	and.16b	v4, v23, v21
    1518:      	and.16b	v3, v3, v12
    151c:      	stp	q3, q4, [sp, #0x40]
    1520:      	orr.16b	v19, v3, v25
    1524:      	orr.16b	v20, v4, v25
    1528:      	str	q2, [sp, #0x70]
    152c:      	orr.16b	v6, v2, v25
    1530:      	movi.2s	v5, #0x41
    1534:      	umull.2d	v2, v17, v5
    1538:      	str	q2, [sp, #0x130]
    153c:      	xtn.2s	v2, v30
    1540:      	xtn.2s	v3, v9
    1544:      	xtn.2s	v4, v29
    1548:      	stp	q20, q6, [sp, #0x250]
    154c:      	umlal.2d	v6, v4, v5
    1550:      	str	q6, [sp, #0x160]
    1554:      	mov.16b	v6, v23
    1558:      	mov.16b	v4, v20
    155c:      	umlal.2d	v4, v2, v5
    1560:      	str	q19, [sp, #0x3b0]
    1564:      	mov.16b	v2, v19
    1568:      	umlal.2d	v2, v3, v5
    156c:      	stp	q2, q4, [sp, #0x140]
    1570:      	dup.2d	v2, x12
    1574:      	ushll2.2d	v3, v31, #0x0
    1578:      	and.16b	v30, v3, v2
    157c:      	ushll2.2d	v3, v26, #0x0
    1580:      	and.16b	v13, v3, v2
    1584:      	ushll.2d	v3, v31, #0x0
    1588:      	and.16b	v14, v3, v2
    158c:      	ushll.2d	v3, v26, #0x0
    1590:      	and.16b	v15, v3, v2
    1594:      	movi.2d	v2, #0000000000000000
    1598:      	movi.2d	v3, #0000000000000000
    159c:      	movi.2d	v4, #0000000000000000
    15a0:      	movi.2d	v5, #0000000000000000
    15a4:      	mov.16b	v25, v21
    15a8:      	ldr	q29, [sp, #0x2f0]
    15ac:      	sshll.2d	v17, v31, #0x0
    15b0:      	sshll.2d	v19, v26, #0x0
    15b4:      	shl.2d	v20, v5, #0x3
    15b8:      	shl.2d	v21, v2, #0x3
    15bc:      	shl.2d	v22, v4, #0x3
    15c0:      	shl.2d	v23, v3, #0x3
    15c4:      	orr.16b	v23, v23, v25
    15c8:      	orr.16b	v22, v22, v12
    15cc:      	orr.16b	v21, v21, v29
    15d0:      	orr.16b	v20, v20, v11
    15d4:      	add	x0, x11, x0, lsl #6
    15d8:      	ldp	q28, q27, [x0]
    15dc:      	ldp	q9, q10, [x0, #0x20]
    15e0:      	bif.16b	v20, v10, v24
    15e4:      	bsl.16b	v19, v21, v28
    15e8:      	bsl.16b	v17, v22, v9
    15ec:      	mov.16b	v21, v6
    15f0:      	bsl.16b	v21, v23, v27
    15f4:      	stp	q19, q21, [x0]
    15f8:      	stp	q17, q20, [x0, #0x20]
    15fc:      	add.2d	v3, v3, v13
    1600:      	add.2d	v4, v4, v14
    1604:      	add.2d	v5, v5, v30
    1608:      	add.2d	v2, v2, v15
    160c:      	fmov	x0, d2
    1610:      	cmp	x0, #0x8
    1614:      	b.lt	0x15ac <ltmp0+0x15ac>
    1618:      	mov	x0, #0x0                ; =0
    161c:      	movi.4s	v4, #0x41
    1620:      	and.16b	v2, v26, v4
    1624:      	mvn.16b	v3, v26
    1628:      	and.16b	v4, v31, v4
    162c:      	mvn.16b	v5, v31
    1630:      	sub.4s	v4, v4, v5
    1634:      	mov.s	w2, v4[1]
    1638:      	mov.s	w3, v1[1]
    163c:      	sub.4s	v3, v2, v3
    1640:      	udiv	w4, w3, w2
    1644:      	mov.s	w7, v4[2]
    1648:      	mov.s	w19, v4[3]
    164c:      	msub	w2, w4, w2, w3
    1650:      	fmov	w3, s4
    1654:      	fmov	w4, s1
    1658:      	udiv	w20, w4, w3
    165c:      	msub	w3, w20, w3, w4
    1660:      	fmov	s2, w3
    1664:      	mov.s	v2[1], w2
    1668:      	mov.s	w2, v1[2]
    166c:      	udiv	w3, w2, w7
    1670:      	msub	w2, w3, w7, w2
    1674:      	mov.s	v2[2], w2
    1678:      	mov.s	w2, v1[3]
    167c:      	udiv	w3, w2, w19
    1680:      	msub	w2, w3, w19, w2
    1684:      	mov.s	v2[3], w2
    1688:      	mov.s	w2, v3[1]
    168c:      	ldr	q1, [sp, #0x3d0]
    1690:      	mov.s	w3, v1[1]
    1694:      	udiv	w4, w3, w2
    1698:      	mov.s	w7, v3[2]
    169c:      	mov.s	w19, v3[3]
    16a0:      	msub	w2, w4, w2, w3
    16a4:      	fmov	w3, s3
    16a8:      	fmov	w4, s1
    16ac:      	udiv	w20, w4, w3
    16b0:      	mov.s	w21, v1[2]
    16b4:      	msub	w3, w20, w3, w4
    16b8:      	udiv	w4, w21, w7
    16bc:      	msub	w4, w4, w7, w21
    16c0:      	mov.s	w7, v1[3]
    16c4:      	udiv	w20, w7, w19
    16c8:      	msub	w7, w20, w19, w7
    16cc:      	fmov	s1, w3
    16d0:      	mov.s	v1[1], w2
    16d4:      	sshll.2d	v3, v31, #0x0
    16d8:      	sshll.2d	v4, v26, #0x0
    16dc:      	adrp	x2, 0x1000 <ltmp0+0x1000>
    16e0:      	ldr	q5, [x2]
    16e4:      	and.16b	v5, v4, v5
    16e8:      	adrp	x2, 0x1000 <ltmp0+0x1000>
    16ec:      	ldr	q17, [x2]
    16f0:      	and.16b	v17, v3, v17
    16f4:      	adrp	x2, 0x1000 <ltmp0+0x1000>
    16f8:      	ldr	q19, [x2]
    16fc:      	and.16b	v19, v6, v19
    1700:      	adrp	x2, 0x1000 <ltmp0+0x1000>
    1704:      	ldr	q20, [x2]
    1708:      	and.16b	v20, v24, v20
    170c:      	str	q20, [sp, #0xa20]
    1710:      	str	q17, [sp, #0xa10]
    1714:      	str	q19, [sp, #0xa00]
    1718:      	str	q5, [sp, #0x9f0]
    171c:      	tst	w10, #0xff
    1720:      	and	x10, x22, #0x7
    1724:      	add	x2, sp, #0x9f0
    1728:      	ldr	x10, [x2, x10, lsl #3]
    172c:      	orr	x10, x10, #0x200
    1730:      	sub	x10, x10, x22, lsl #3
    1734:      	csel	x10, xzr, x10, eq
    1738:      	add	x10, x11, x10
    173c:      	ldp	q5, q17, [x10, #0x20]
    1740:      	ldp	q19, q20, [x10]
    1744:      	ldr	q23, [sp, #0x1c0]
    1748:      	mov	b21, v23[2]
    174c:      	mov.b	v21[4], v23[3]
    1750:      	ushll.2d	v21, v21, #0x0
    1754:      	shl.2d	v21, v21, #0x3f
    1758:      	cmlt.2d	v21, v21, #0
    175c:      	ldr	q22, [sp, #0x250]
    1760:      	bif.16b	v22, v20, v21
    1764:      	mov	b20, v23[0]
    1768:      	mov.b	v20[4], v23[1]
    176c:      	ushll.2d	v20, v20, #0x0
    1770:      	shl.2d	v20, v20, #0x3f
    1774:      	cmlt.2d	v20, v20, #0
    1778:      	ldr	q21, [sp, #0x3c0]
    177c:      	bif.16b	v21, v19, v20
    1780:      	mov	b19, v23[6]
    1784:      	mov.b	v19[4], v23[7]
    1788:      	ushll.2d	v19, v19, #0x0
    178c:      	shl.2d	v19, v19, #0x3f
    1790:      	cmlt.2d	v19, v19, #0
    1794:      	ldr	q20, [sp, #0x260]
    1798:      	bif.16b	v20, v17, v19
    179c:      	mov	b17, v23[4]
    17a0:      	mov.b	v17[4], v23[5]
    17a4:      	ushll.2d	v17, v17, #0x0
    17a8:      	shl.2d	v17, v17, #0x3f
    17ac:      	cmlt.2d	v17, v17, #0
    17b0:      	ldr	q19, [sp, #0x3b0]
    17b4:      	bit.16b	v5, v19, v17
    17b8:      	mov.s	v1[2], w4
    17bc:      	mov.s	v1[3], w7
    17c0:      	and.16b	v1, v26, v1
    17c4:      	stp	q5, q20, [sp, #0xb0]
    17c8:      	stp	q5, q20, [x10, #0x20]
    17cc:      	stp	q21, q22, [sp, #0x110]
    17d0:      	stp	q21, q22, [x10]
    17d4:      	and.16b	v2, v31, v2
    17d8:      	ushll2.2d	v5, v2, #0x0
    17dc:      	str	q5, [sp, #0x3b0]
    17e0:      	ushll2.2d	v25, v1, #0x0
    17e4:      	ushll.2d	v29, v2, #0x0
    17e8:      	ushll.2d	v1, v1, #0x0
    17ec:      	and.16b	v27, v24, v0
    17f0:      	and.16b	v28, v6, v0
    17f4:      	and.16b	v9, v3, v0
    17f8:      	and.16b	v10, v4, v0
    17fc:      	ldr	q2, [x16]
    1800:      	str	q24, [sp, #0x1b0]
    1804:      	and.16b	v11, v24, v2
    1808:      	str	q6, [sp, #0x260]
    180c:      	and.16b	v12, v6, v16
    1810:      	ldr	q2, [x15]
    1814:      	and.16b	v5, v3, v2
    1818:      	and.16b	v2, v4, v7
    181c:      	stp	q2, q5, [sp, #0x3c0]
    1820:      	ldr	q3, [sp, #0x3a0]
    1824:      	ldp	q2, q4, [sp, #0x190]
    1828:      	cmhs.4s	v2, v2, v3
    182c:      	cmhs.4s	v3, v4, v3
    1830:      	uzp1.8h	v2, v3, v2
    1834:      	xtn.8b	v2, v2
    1838:      	movi.2d	v3, #0000000000000000
    183c:      	movi.2d	v4, #0000000000000000
    1840:      	movi.2d	v17, #0000000000000000
    1844:      	movi.2d	v24, #0000000000000000
    1848:      	movi.8b	v22, #0x1
    184c:      	ldr	q6, [sp, #0x280]
    1850:      	b	0x1870 <ltmp0+0x1870>
    1854:      	add.2d	v4, v4, v13
    1858:      	add.2d	v17, v17, v14
    185c:      	add.2d	v24, v24, v30
    1860:      	add.2d	v3, v3, v15
    1864:      	fmov	x0, d3
    1868:      	cmp	x0, #0x8
    186c:      	b.ge	0x197c <ltmp0+0x197c>
    1870:      	fmov	w10, s6
    1874:      	add	x0, x11, x0, lsl #6
    1878:      	ldp	q19, q5, [x0, #0x20]
    187c:      	ldp	q20, q21, [x0]
    1880:      	cmge.2d	v21, v25, v21
    1884:      	cmge.2d	v20, v1, v20
    1888:      	uzp1.4s	v20, v20, v21
    188c:      	cmge.2d	v19, v29, v19
    1890:      	ldr	q21, [sp, #0x3b0]
    1894:      	cmge.2d	v5, v21, v5
    1898:      	uzp1.4s	v5, v19, v5
    189c:      	uzp1.8h	v5, v20, v5
    18a0:      	xtn.8b	v5, v5
    18a4:      	orr.8b	v5, v2, v5
    18a8:      	ldr	q19, [sp, #0x3c0]
    18ac:      	add.2d	v19, v3, v19
    18b0:      	add.2d	v19, v10, v19
    18b4:      	and.8b	v5, v5, v22
    18b8:      	tbnz	w10, #0x0, 0x18fc <ltmp0+0x18fc>
    18bc:      	and	w10, w10, #0xff
    18c0:      	tbnz	w10, #0x1, 0x190c <ltmp0+0x190c>
    18c4:      	add.2d	v19, v4, v12
    18c8:      	add.2d	v19, v28, v19
    18cc:      	tbnz	w10, #0x2, 0x1920 <ltmp0+0x1920>
    18d0:      	tbnz	w10, #0x3, 0x192c <ltmp0+0x192c>
    18d4:      	ldr	q19, [sp, #0x3d0]
    18d8:      	add.2d	v19, v17, v19
    18dc:      	add.2d	v19, v9, v19
    18e0:      	tbnz	w10, #0x4, 0x1944 <ltmp0+0x1944>
    18e4:      	tbnz	w10, #0x5, 0x1950 <ltmp0+0x1950>
    18e8:      	add.2d	v19, v24, v11
    18ec:      	add.2d	v19, v27, v19
    18f0:      	tbnz	w10, #0x6, 0x1964 <ltmp0+0x1964>
    18f4:      	tbz	w10, #0x7, 0x1854 <ltmp0+0x1854>
    18f8:      	b	0x1970 <ltmp0+0x1970>
    18fc:      	fmov	x0, d19
    1900:      	str	b5, [x0]
    1904:      	and	w10, w10, #0xff
    1908:      	tbz	w10, #0x1, 0x18c4 <ltmp0+0x18c4>
    190c:      	mov.d	x0, v19[1]
    1910:      	st1.b	{ v5 }[1], [x0]
    1914:      	add.2d	v19, v4, v12
    1918:      	add.2d	v19, v28, v19
    191c:      	tbz	w10, #0x2, 0x18d0 <ltmp0+0x18d0>
    1920:      	fmov	x0, d19
    1924:      	st1.b	{ v5 }[2], [x0]
    1928:      	tbz	w10, #0x3, 0x18d4 <ltmp0+0x18d4>
    192c:      	mov.d	x0, v19[1]
    1930:      	st1.b	{ v5 }[3], [x0]
    1934:      	ldr	q19, [sp, #0x3d0]
    1938:      	add.2d	v19, v17, v19
    193c:      	add.2d	v19, v9, v19
    1940:      	tbz	w10, #0x4, 0x18e4 <ltmp0+0x18e4>
    1944:      	fmov	x0, d19
    1948:      	st1.b	{ v5 }[4], [x0]
    194c:      	tbz	w10, #0x5, 0x18e8 <ltmp0+0x18e8>
    1950:      	mov.d	x0, v19[1]
    1954:      	st1.b	{ v5 }[5], [x0]
    1958:      	add.2d	v19, v24, v11
    195c:      	add.2d	v19, v27, v19
    1960:      	tbz	w10, #0x6, 0x18f4 <ltmp0+0x18f4>
    1964:      	fmov	x0, d19
    1968:      	st1.b	{ v5 }[6], [x0]
    196c:      	tbz	w10, #0x7, 0x1854 <ltmp0+0x1854>
    1970:      	mov.d	x10, v19[1]
    1974:      	st1.b	{ v5 }[7], [x10]
    1978:      	b	0x1854 <ltmp0+0x1854>
    197c:      	ldp	q3, q2, [sp, #0x110]
    1980:      	cmge.2d	v1, v1, v3
    1984:      	cmge.2d	v2, v25, v2
    1988:      	uzp1.4s	v1, v1, v2
    198c:      	ldp	q2, q3, [sp, #0xb0]
    1990:      	cmge.2d	v2, v29, v2
    1994:      	ldr	q4, [sp, #0x3b0]
    1998:      	cmge.2d	v3, v4, v3
    199c:      	uzp1.4s	v2, v2, v3
    19a0:      	uzp1.8h	v1, v1, v2
    19a4:      	xtn.8b	v1, v1
    19a8:      	shl.8b	v2, v23, #0x7
    19ac:      	cmlt.8b	v2, v2, #0
    19b0:      	ldr	d3, [sp, #0x180]
    19b4:      	and.8b	v2, v2, v3
    19b8:      	addv.8b	b21, v2
    19bc:      	fmov	w2, s21
    19c0:      	orn.8b	v1, v1, v23
    19c4:      	ldr	q2, [sp, #0x3c0]
    19c8:      	add.2d	v3, v2, v10
    19cc:      	mov	w10, #0x8               ; =8
    19d0:      	dup.2d	v2, x10
    19d4:      	add.2d	v29, v3, v2
    19d8:      	and.8b	v1, v1, v22
    19dc:      	tbnz	w2, #0x0, 0x1bec <ltmp0+0x1bec>
    19e0:      	mov.d	x4, v29[1]
    19e4:      	tbnz	w2, #0x1, 0x1bfc <ltmp0+0x1bfc>
    19e8:      	add.2d	v3, v12, v28
    19ec:      	add.2d	v25, v3, v2
    19f0:      	tbnz	w2, #0x2, 0x1c0c <ltmp0+0x1c0c>
    19f4:      	mov.d	x3, v25[1]
    19f8:      	tbnz	w2, #0x3, 0x1c1c <ltmp0+0x1c1c>
    19fc:      	ldr	q3, [sp, #0x3d0]
    1a00:      	add.2d	v3, v3, v9
    1a04:      	add.2d	v3, v3, v2
    1a08:      	tbnz	w2, #0x4, 0x1c30 <ltmp0+0x1c30>
    1a0c:      	str	q3, [sp, #0x3b0]
    1a10:      	mov.d	x0, v3[1]
    1a14:      	tbnz	w2, #0x5, 0x1c44 <ltmp0+0x1c44>
    1a18:      	add.2d	v3, v11, v27
    1a1c:      	add.2d	v22, v3, v2
    1a20:      	tbnz	w2, #0x6, 0x1c54 <ltmp0+0x1c54>
    1a24:      	mov.d	x10, v22[1]
    1a28:      	tbz	w2, #0x7, 0x1a30 <ltmp0+0x1a30>
    1a2c:      	st1.b	{ v1 }[7], [x10]
    1a30:      	mov	x7, #0x0                ; =0
    1a34:      	movi.2d	v2, #0000000000000000
    1a38:      	movi.2d	v3, #0000000000000000
    1a3c:      	movi.2d	v17, #0000000000000000
    1a40:      	movi.2d	v1, #0000000000000000
    1a44:      	b	0x1aa4 <ltmp0+0x1aa4>
    1a48:      	cmeq.8b	v4, v24, #0
    1a4c:      	sshll.8h	v4, v4, #0x0
    1a50:      	sshll2.4s	v5, v4, #0x0
    1a54:      	sshll.4s	v4, v4, #0x0
    1a58:      	lsl	x2, x7, #5
    1a5c:      	add	x7, x1, x2
    1a60:      	ldp	q19, q20, [x7]
    1a64:      	and.16b	v20, v31, v20
    1a68:      	and.16b	v19, v26, v19
    1a6c:      	bsl.16b	v4, v18, v19
    1a70:      	bsl.16b	v5, v18, v20
    1a74:      	add	x2, x5, x2
    1a78:      	ldp	q19, q20, [x2]
    1a7c:      	bif.16b	v5, v20, v31
    1a80:      	bif.16b	v4, v19, v26
    1a84:      	stp	q4, q5, [x2]
    1a88:      	add.2d	v3, v3, v13
    1a8c:      	add.2d	v17, v17, v14
    1a90:      	add.2d	v1, v1, v30
    1a94:      	add.2d	v2, v2, v15
    1a98:      	fmov	x7, d2
    1a9c:      	cmp	x7, #0x8
    1aa0:      	b.ge	0x1b74 <ltmp0+0x1b74>
    1aa4:      	fmov	w2, s6
    1aa8:      	ldr	q4, [sp, #0x3c0]
    1aac:      	add.2d	v4, v2, v4
    1ab0:      	add.2d	v4, v10, v4
    1ab4:      	tbz	w2, #0x0, 0x1acc <ltmp0+0x1acc>
    1ab8:      	fmov	x19, d4
    1abc:      	ldr	b24, [x19]
    1ac0:      	and	w2, w2, #0xff
    1ac4:      	tbnz	w2, #0x1, 0x1ad8 <ltmp0+0x1ad8>
    1ac8:      	b	0x1ae0 <ltmp0+0x1ae0>
    1acc:      	movi.2d	v24, #0000000000000000
    1ad0:      	and	w2, w2, #0xff
    1ad4:      	tbz	w2, #0x1, 0x1ae0 <ltmp0+0x1ae0>
    1ad8:      	mov.d	x19, v4[1]
    1adc:      	ld1.b	{ v24 }[1], [x19]
    1ae0:      	add.2d	v4, v3, v12
    1ae4:      	add.2d	v4, v28, v4
    1ae8:      	tbnz	w2, #0x2, 0x1b18 <ltmp0+0x1b18>
    1aec:      	tbnz	w2, #0x3, 0x1b24 <ltmp0+0x1b24>
    1af0:      	ldr	q4, [sp, #0x3d0]
    1af4:      	add.2d	v4, v17, v4
    1af8:      	add.2d	v4, v9, v4
    1afc:      	tbnz	w2, #0x4, 0x1b3c <ltmp0+0x1b3c>
    1b00:      	tbnz	w2, #0x5, 0x1b48 <ltmp0+0x1b48>
    1b04:      	add.2d	v4, v1, v11
    1b08:      	add.2d	v4, v27, v4
    1b0c:      	tbnz	w2, #0x6, 0x1b5c <ltmp0+0x1b5c>
    1b10:      	tbz	w2, #0x7, 0x1a48 <ltmp0+0x1a48>
    1b14:      	b	0x1b68 <ltmp0+0x1b68>
    1b18:      	fmov	x19, d4
    1b1c:      	ld1.b	{ v24 }[2], [x19]
    1b20:      	tbz	w2, #0x3, 0x1af0 <ltmp0+0x1af0>
    1b24:      	mov.d	x19, v4[1]
    1b28:      	ld1.b	{ v24 }[3], [x19]
    1b2c:      	ldr	q4, [sp, #0x3d0]
    1b30:      	add.2d	v4, v17, v4
    1b34:      	add.2d	v4, v9, v4
    1b38:      	tbz	w2, #0x4, 0x1b00 <ltmp0+0x1b00>
    1b3c:      	fmov	x19, d4
    1b40:      	ld1.b	{ v24 }[4], [x19]
    1b44:      	tbz	w2, #0x5, 0x1b04 <ltmp0+0x1b04>
    1b48:      	mov.d	x19, v4[1]
    1b4c:      	ld1.b	{ v24 }[5], [x19]
    1b50:      	add.2d	v4, v1, v11
    1b54:      	add.2d	v4, v27, v4
    1b58:      	tbz	w2, #0x6, 0x1b10 <ltmp0+0x1b10>
    1b5c:      	fmov	x19, d4
    1b60:      	ld1.b	{ v24 }[6], [x19]
    1b64:      	tbz	w2, #0x7, 0x1a48 <ltmp0+0x1a48>
    1b68:      	mov.d	x2, v4[1]
    1b6c:      	ld1.b	{ v24 }[7], [x2]
    1b70:      	b	0x1a48 <ltmp0+0x1a48>
    1b74:      	fmov	w2, s21
    1b78:      	tbz	w2, #0x0, 0x1c68 <ltmp0+0x1c68>
    1b7c:      	fmov	x7, d29
    1b80:      	ldr	b1, [x7]
    1b84:      	ldr	q6, [sp, #0x260]
    1b88:      	tbnz	w2, #0x1, 0x1c74 <ltmp0+0x1c74>
    1b8c:      	b	0x1c78 <ltmp0+0x1c78>
    1b90:      	ldr	s27, [x0]
    1b94:      	ldr	q18, [sp, #0x300]
    1b98:      	tbz	w10, #0x1, 0x143c <ltmp0+0x143c>
    1b9c:      	add	x2, x0, #0x4
    1ba0:      	ld1.s	{ v27 }[1], [x2]
    1ba4:      	tbz	w10, #0x2, 0x1440 <ltmp0+0x1440>
    1ba8:      	add	x2, x0, #0x8
    1bac:      	ld1.s	{ v27 }[2], [x2]
    1bb0:      	tbz	w10, #0x3, 0x1444 <ltmp0+0x1444>
    1bb4:      	add	x2, x0, #0xc
    1bb8:      	ld1.s	{ v27 }[3], [x2]
    1bbc:      	tbz	w10, #0x4, 0x1448 <ltmp0+0x1448>
    1bc0:      	add	x2, x0, #0x10
    1bc4:      	ld1.s	{ v28 }[0], [x2]
    1bc8:      	tbz	w10, #0x5, 0x144c <ltmp0+0x144c>
    1bcc:      	add	x2, x0, #0x14
    1bd0:      	ld1.s	{ v28 }[1], [x2]
    1bd4:      	tbz	w10, #0x6, 0x1450 <ltmp0+0x1450>
    1bd8:      	add	x2, x0, #0x18
    1bdc:      	ld1.s	{ v28 }[2], [x2]
    1be0:      	str	q6, [sp, #0x280]
    1be4:      	tbnz	w10, #0x7, 0x1458 <ltmp0+0x1458>
    1be8:      	b	0x1460 <ltmp0+0x1460>
    1bec:      	fmov	x10, d29
    1bf0:      	str	b1, [x10]
    1bf4:      	mov.d	x4, v29[1]
    1bf8:      	tbz	w2, #0x1, 0x19e8 <ltmp0+0x19e8>
    1bfc:      	st1.b	{ v1 }[1], [x4]
    1c00:      	add.2d	v3, v12, v28
    1c04:      	add.2d	v25, v3, v2
    1c08:      	tbz	w2, #0x2, 0x19f4 <ltmp0+0x19f4>
    1c0c:      	fmov	x10, d25
    1c10:      	st1.b	{ v1 }[2], [x10]
    1c14:      	mov.d	x3, v25[1]
    1c18:      	tbz	w2, #0x3, 0x19fc <ltmp0+0x19fc>
    1c1c:      	st1.b	{ v1 }[3], [x3]
    1c20:      	ldr	q3, [sp, #0x3d0]
    1c24:      	add.2d	v3, v3, v9
    1c28:      	add.2d	v3, v3, v2
    1c2c:      	tbz	w2, #0x4, 0x1a0c <ltmp0+0x1a0c>
    1c30:      	fmov	x10, d3
    1c34:      	st1.b	{ v1 }[4], [x10]
    1c38:      	str	q3, [sp, #0x3b0]
    1c3c:      	mov.d	x0, v3[1]
    1c40:      	tbz	w2, #0x5, 0x1a18 <ltmp0+0x1a18>
    1c44:      	st1.b	{ v1 }[5], [x0]
    1c48:      	add.2d	v3, v11, v27
    1c4c:      	add.2d	v22, v3, v2
    1c50:      	tbz	w2, #0x6, 0x1a24 <ltmp0+0x1a24>
    1c54:      	fmov	x10, d22
    1c58:      	st1.b	{ v1 }[6], [x10]
    1c5c:      	mov.d	x10, v22[1]
    1c60:      	tbnz	w2, #0x7, 0x1a2c <ltmp0+0x1a2c>
    1c64:      	b	0x1a30 <ltmp0+0x1a30>
    1c68:      	movi.2d	v1, #0000000000000000
    1c6c:      	ldr	q6, [sp, #0x260]
    1c70:      	tbz	w2, #0x1, 0x1c78 <ltmp0+0x1c78>
    1c74:      	ld1.b	{ v1 }[1], [x4]
    1c78:      	tbnz	w2, #0x2, 0x306c <ltmp0+0x306c>
    1c7c:      	tbnz	w2, #0x3, 0x3078 <ltmp0+0x3078>
    1c80:      	tbnz	w2, #0x4, 0x3080 <ltmp0+0x3080>
    1c84:      	tbnz	w2, #0x5, 0x3090 <ltmp0+0x3090>
    1c88:      	tbnz	w2, #0x6, 0x3098 <ltmp0+0x3098>
    1c8c:      	mov	w0, #0x4                ; =4
    1c90:      	str	d21, [sp, #0x120]
    1c94:      	stp	q28, q27, [sp, #0x240]
    1c98:      	stp	q10, q9, [sp, #0x220]
    1c9c:      	stp	q12, q11, [sp, #0x200]
    1ca0:      	tbz	w2, #0x7, 0x1ca8 <ltmp0+0x1ca8>
    1ca4:      	ld1.b	{ v1 }[7], [x10]
    1ca8:      	stp	q15, q14, [sp, #0x3a0]
    1cac:      	str	x22, [sp, #0x180]
    1cb0:      	str	w8, [sp, #0x190]
    1cb4:      	sshll.2d	v2, v26, #0x0
    1cb8:      	sshll.2d	v3, v31, #0x0
    1cbc:      	cmeq.8b	v1, v1, #0
    1cc0:      	sshll.8h	v4, v1, #0x0
    1cc4:      	sshll.4s	v1, v4, #0x0
    1cc8:      	str	q4, [sp, #0x80]
    1ccc:      	sshll2.4s	v4, v4, #0x0
    1cd0:      	str	q4, [sp, #0x90]
    1cd4:      	ldr	q5, [sp, #0x270]
    1cd8:      	mov.16b	v17, v4
    1cdc:      	bsl.16b	v17, v18, v5
    1ce0:      	ldr	q4, [sp, #0x290]
    1ce4:      	bif.16b	v18, v4, v1
    1ce8:      	str	x23, [sp, #0x110]
    1cec:      	add	x10, x5, x23
    1cf0:      	ldp	q4, q1, [x10]
    1cf4:      	zip1.8b	v5, v23, v0
    1cf8:      	ushll.4s	v5, v5, #0x0
    1cfc:      	shl.4s	v5, v5, #0x1f
    1d00:      	cmlt.4s	v5, v5, #0
    1d04:      	str	q18, [sp, #0x1a0]
    1d08:      	bit.16b	v4, v18, v5
    1d0c:      	zip2.8b	v5, v23, v0
    1d10:      	ushll.4s	v5, v5, #0x0
    1d14:      	shl.4s	v5, v5, #0x1f
    1d18:      	cmlt.4s	v5, v5, #0
    1d1c:      	str	q17, [sp, #0x10]
    1d20:      	bit.16b	v1, v17, v5
    1d24:      	stp	q4, q1, [x10]
    1d28:      	ldr	q1, [sp, #0xd0]
    1d2c:      	fmov	x8, d1
    1d30:      	dup.2d	v1, x0
    1d34:      	ldr	q14, [sp, #0x1b0]
    1d38:      	and.16b	v20, v14, v1
    1d3c:      	and.16b	v28, v6, v1
    1d40:      	and.16b	v19, v3, v1
    1d44:      	and.16b	v27, v2, v1
    1d48:      	fmov	x25, d27
    1d4c:      	ldp	q2, q1, [x9, #0x180]
    1d50:      	and.16b	v1, v31, v1
    1d54:      	and.16b	v2, v26, v2
    1d58:      	ldp	q3, q4, [x9, #0x160]
    1d5c:      	and.16b	v17, v31, v4
    1d60:      	and.16b	v3, v26, v3
    1d64:      	ldp	q4, q5, [x9, #0x140]
    1d68:      	and.16b	v18, v31, v5
    1d6c:      	and.16b	v24, v26, v4
    1d70:      	str	x8, [sp, #0xa8]
    1d74:      	add	x10, x5, x8
    1d78:      	ldp	q4, q5, [x10]
    1d7c:      	and.16b	v25, v31, v5
    1d80:      	mov	x10, x25
    1d84:      	and.16b	v4, v26, v4
    1d88:      	str	q27, [sp, #0x60]
    1d8c:      	stp	q19, q28, [sp, #0xb0]
    1d90:      	str	q20, [sp, #0xd0]
    1d94:      	sshll.2d	v5, v26, #0x0
    1d98:      	str	q5, [sp, #0x300]
    1d9c:      	sshll.2d	v5, v31, #0x0
    1da0:      	str	q5, [sp, #0x290]
    1da4:      	add	x10, x5, x10, lsl #5
    1da8:      	ldp	q5, q23, [x10]
    1dac:      	and.16b	v23, v31, v23
    1db0:      	and.16b	v5, v26, v5
    1db4:      	fmaxnm.4s	v15, v4, v5
    1db8:      	fmaxnm.4s	v29, v25, v23
    1dbc:      	ldp	q23, q9, [x10, #0x20]
    1dc0:      	and.16b	v9, v31, v9
    1dc4:      	and.16b	v23, v26, v23
    1dc8:      	fmaxnm.4s	v23, v24, v23
    1dcc:      	fmaxnm.4s	v9, v18, v9
    1dd0:      	ldp	q10, q11, [x10, #0x40]
    1dd4:      	and.16b	v11, v31, v11
    1dd8:      	and.16b	v10, v26, v10
    1ddc:      	fmaxnm.4s	v10, v3, v10
    1de0:      	fmaxnm.4s	v11, v17, v11
    1de4:      	ldp	q12, q21, [x10, #0x60]
    1de8:      	and.16b	v21, v31, v21
    1dec:      	and.16b	v12, v26, v12
    1df0:      	fmaxnm.4s	v12, v2, v12
    1df4:      	fmaxnm.4s	v21, v1, v21
    1df8:      	dup.2d	v5, x0
    1dfc:      	and.16b	v22, v14, v5
    1e00:      	add.2d	v20, v20, v22
    1e04:      	and.16b	v22, v6, v5
    1e08:      	add.2d	v28, v28, v22
    1e0c:      	ldr	q22, [sp, #0x290]
    1e10:      	and.16b	v22, v22, v5
    1e14:      	add.2d	v19, v19, v22
    1e18:      	mov.16b	v22, v15
    1e1c:      	ldr	q15, [sp, #0x300]
    1e20:      	and.16b	v5, v15, v5
    1e24:      	add.2d	v27, v27, v5
    1e28:      	bit.16b	v25, v29, v31
    1e2c:      	bit.16b	v4, v22, v26
    1e30:      	bit.16b	v18, v9, v31
    1e34:      	bit.16b	v24, v23, v26
    1e38:      	bit.16b	v17, v11, v31
    1e3c:      	bit.16b	v3, v10, v26
    1e40:      	bit.16b	v1, v21, v31
    1e44:      	bit.16b	v2, v12, v26
    1e48:      	fmov	x10, d27
    1e4c:      	cmp	x10, #0x8
    1e50:      	b.lt	0x1d94 <ltmp0+0x1d94>
    1e54:      	str	q26, [sp, #0x270]
    1e58:      	mov	x0, #0x0                ; =0
    1e5c:      	ldr	q5, [sp, #0xf0]
    1e60:      	xtn.8b	v6, v5
    1e64:      	ldr	q20, [sp, #0x1c0]
    1e68:      	zip1.8b	v5, v20, v0
    1e6c:      	ushll.4s	v5, v5, #0x0
    1e70:      	shl.4s	v5, v5, #0x1f
    1e74:      	cmlt.4s	v5, v5, #0
    1e78:      	ldr	q19, [sp, #0x1a0]
    1e7c:      	and.16b	v19, v5, v19
    1e80:      	zip2.8b	v20, v20, v0
    1e84:      	ushll.4s	v20, v20, #0x0
    1e88:      	shl.4s	v20, v20, #0x1f
    1e8c:      	cmlt.4s	v20, v20, #0
    1e90:      	ldr	q14, [sp, #0x10]
    1e94:      	and.16b	v21, v20, v14
    1e98:      	fmaxnm.4s	v21, v25, v21
    1e9c:      	fmaxnm.4s	v4, v4, v19
    1ea0:      	and.16b	v4, v5, v4
    1ea4:      	and.16b	v5, v20, v21
    1ea8:      	zip2.8b	v19, v6, v0
    1eac:      	ushll.4s	v19, v19, #0x0
    1eb0:      	shl.4s	v19, v19, #0x1f
    1eb4:      	cmlt.4s	v19, v19, #0
    1eb8:      	movi.2d	v20, #0000000000000000
    1ebc:      	mov.b	v20[2], v6[1]
    1ec0:      	mov.b	v20[4], v6[2]
    1ec4:      	mov.b	v20[6], v6[3]
    1ec8:      	bit.16b	v5, v29, v19
    1ecc:      	ushll.4s	v19, v20, #0x0
    1ed0:      	shl.4s	v19, v19, #0x1f
    1ed4:      	cmlt.4s	v19, v19, #0
    1ed8:      	bit.16b	v4, v22, v19
    1edc:      	fmaxnm.4s	v4, v4, v24
    1ee0:      	fmaxnm.4s	v5, v5, v18
    1ee4:      	fmaxnm.4s	v5, v5, v17
    1ee8:      	fmaxnm.4s	v3, v4, v3
    1eec:      	fmaxnm.4s	v17, v3, v2
    1ef0:      	fmaxnm.4s	v24, v5, v1
    1ef4:      	ldr	q1, [sp, #0xe0]
    1ef8:      	ldp	q2, q3, [sp, #0x40]
    1efc:      	uzp1.4s	v23, v1, v3
    1f00:      	ldr	q1, [sp, #0x70]
    1f04:      	uzp1.4s	v1, v2, v1
    1f08:      	movi.4s	v3, #0x1
    1f0c:      	eor.16b	v2, v23, v3
    1f10:      	mov.s	w10, v2[1]
    1f14:      	mov.s	w2, v2[2]
    1f18:      	eor.16b	v4, v1, v3
    1f1c:      	mov.s	w3, v2[3]
    1f20:      	fmov	w4, s2
    1f24:      	add	x7, sp, #0x6b8
    1f28:      	bfxil	x7, x4, #0, #3
    1f2c:      	str	d6, [sp, #0x6b8]
    1f30:      	ldrb	w7, [x7]
    1f34:      	and	x4, x4, #0x7
    1f38:      	umov.b	w8, v6[0]
    1f3c:      	str	w8, [sp, #0x2c]
    1f40:      	str	q24, [sp, #0x950]
    1f44:      	str	q17, [sp, #0x940]
    1f48:      	add	x19, sp, #0x940
    1f4c:      	ldr	s2, [x19, x4, lsl #2]
    1f50:      	ands	w8, w8, #0x1
    1f54:      	tst	w8, w7
    1f58:      	str	w8, [sp, #0x300]
    1f5c:      	movi	d22, #0000000000000000
    1f60:      	fcsel	s2, s2, s22, ne
    1f64:      	and	x7, x10, #0x7
    1f68:      	add	x19, sp, #0x6b8
    1f6c:      	bfxil	x19, x10, #0, #3
    1f70:      	ldrb	w10, [x19]
    1f74:      	umov.b	w21, v6[1]
    1f78:      	and	w10, w21, w10
    1f7c:      	str	w21, [sp, #0x28]
    1f80:      	str	q24, [sp, #0x930]
    1f84:      	str	q17, [sp, #0x920]
    1f88:      	add	x19, sp, #0x920
    1f8c:      	ldr	s3, [x19, x7, lsl #2]
    1f90:      	tst	w10, #0x1
    1f94:      	fcsel	s3, s3, s22, ne
    1f98:      	and	x10, x2, #0x7
    1f9c:      	add	x7, sp, #0x6b8
    1fa0:      	bfxil	x7, x2, #0, #3
    1fa4:      	umov.b	w24, v6[2]
    1fa8:      	ldrb	w2, [x7]
    1fac:      	and	w2, w24, w2
    1fb0:      	str	q24, [sp, #0x910]
    1fb4:      	str	q17, [sp, #0x900]
    1fb8:      	add	x7, sp, #0x900
    1fbc:      	ldr	s5, [x7, x10, lsl #2]
    1fc0:      	tst	w2, #0x1
    1fc4:      	fcsel	s18, s5, s22, ne
    1fc8:      	and	x10, x3, #0x7
    1fcc:      	add	x2, sp, #0x6b8
    1fd0:      	bfxil	x2, x3, #0, #3
    1fd4:      	ldrb	w2, [x2]
    1fd8:      	umov.b	w4, v6[3]
    1fdc:      	str	q24, [sp, #0x8f0]
    1fe0:      	str	q17, [sp, #0x8e0]
    1fe4:      	add	x3, sp, #0x8e0
    1fe8:      	ldr	s5, [x3, x10, lsl #2]
    1fec:      	and	w10, w4, w2
    1ff0:      	tst	w10, #0x1
    1ff4:      	mov.s	w10, v4[1]
    1ff8:      	mov.s	w2, v4[2]
    1ffc:      	fcsel	s5, s5, s22, ne
    2000:      	mov.s	w3, v4[3]
    2004:      	fmov	w7, s4
    2008:      	and	x19, x7, #0x7
    200c:      	add	x20, sp, #0x6b8
    2010:      	bfxil	x20, x7, #0, #3
    2014:      	ldrb	w7, [x20]
    2018:      	umov.b	w14, v6[4]
    201c:      	and	w7, w14, w7
    2020:      	str	q24, [sp, #0x9d0]
    2024:      	str	q17, [sp, #0x9c0]
    2028:      	add	x20, sp, #0x9c0
    202c:      	ldr	s4, [x20, x19, lsl #2]
    2030:      	tst	w7, #0x1
    2034:      	fcsel	s4, s4, s22, ne
    2038:      	and	x7, x10, #0x7
    203c:      	add	x19, sp, #0x6b8
    2040:      	bfxil	x19, x10, #0, #3
    2044:      	ldrb	w10, [x19]
    2048:      	umov.b	w17, v6[5]
    204c:      	and	w10, w17, w10
    2050:      	str	q24, [sp, #0x9b0]
    2054:      	str	q17, [sp, #0x9a0]
    2058:      	add	x19, sp, #0x9a0
    205c:      	ldr	s19, [x19, x7, lsl #2]
    2060:      	tst	w10, #0x1
    2064:      	fcsel	s19, s19, s22, ne
    2068:      	and	x10, x2, #0x7
    206c:      	add	x7, sp, #0x6b8
    2070:      	bfxil	x7, x2, #0, #3
    2074:      	ldrb	w2, [x7]
    2078:      	umov.b	w13, v6[6]
    207c:      	and	w2, w13, w2
    2080:      	str	q24, [sp, #0x990]
    2084:      	str	q17, [sp, #0x980]
    2088:      	add	x7, sp, #0x980
    208c:      	ldr	s20, [x7, x10, lsl #2]
    2090:      	tst	w2, #0x1
    2094:      	fcsel	s20, s20, s22, ne
    2098:      	and	x10, x3, #0x7
    209c:      	add	x2, sp, #0x6b8
    20a0:      	bfxil	x2, x3, #0, #3
    20a4:      	umov.b	w6, v6[7]
    20a8:      	ldrb	w2, [x2]
    20ac:      	and	w2, w6, w2
    20b0:      	str	q24, [sp, #0x970]
    20b4:      	str	q17, [sp, #0x960]
    20b8:      	add	x3, sp, #0x960
    20bc:      	ldr	s21, [x3, x10, lsl #2]
    20c0:      	tst	w2, #0x1
    20c4:      	fcsel	s21, s21, s22, ne
    20c8:      	mov.s	v4[1], v19[0]
    20cc:      	mov.s	v4[2], v20[0]
    20d0:      	mov.s	v4[3], v21[0]
    20d4:      	mov.s	v2[1], v3[0]
    20d8:      	mov.s	v2[2], v18[0]
    20dc:      	mov.s	v2[3], v5[0]
    20e0:      	fmaxnm.4s	v18, v17, v2
    20e4:      	fmaxnm.4s	v24, v24, v4
    20e8:      	movi.4s	v3, #0x2
    20ec:      	eor.16b	v2, v23, v3
    20f0:      	mov.s	w10, v2[1]
    20f4:      	mov.s	w2, v2[2]
    20f8:      	mov.s	w3, v2[3]
    20fc:      	eor.16b	v17, v1, v3
    2100:      	fmov	w7, s2
    2104:      	add	x19, sp, #0x6b8
    2108:      	bfxil	x19, x7, #0, #3
    210c:      	ldrb	w19, [x19]
    2110:      	and	x7, x7, #0x7
    2114:      	str	q24, [sp, #0x8d0]
    2118:      	str	q18, [sp, #0x8c0]
    211c:      	add	x20, sp, #0x8c0
    2120:      	ldr	s1, [x20, x7, lsl #2]
    2124:      	tst	w8, w19
    2128:      	fcsel	s1, s1, s22, ne
    212c:      	and	x7, x10, #0x7
    2130:      	add	x19, sp, #0x6b8
    2134:      	bfxil	x19, x10, #0, #3
    2138:      	ldrb	w10, [x19]
    213c:      	and	w10, w21, w10
    2140:      	str	q24, [sp, #0x8b0]
    2144:      	str	q18, [sp, #0x8a0]
    2148:      	add	x19, sp, #0x8a0
    214c:      	ldr	s2, [x19, x7, lsl #2]
    2150:      	tst	w10, #0x1
    2154:      	fcsel	s2, s2, s22, ne
    2158:      	and	x10, x2, #0x7
    215c:      	add	x7, sp, #0x6b8
    2160:      	bfxil	x7, x2, #0, #3
    2164:      	ldrb	w2, [x7]
    2168:      	and	w2, w24, w2
    216c:      	str	q24, [sp, #0x890]
    2170:      	str	q18, [sp, #0x880]
    2174:      	add	x7, sp, #0x880
    2178:      	ldr	s3, [x7, x10, lsl #2]
    217c:      	tst	w2, #0x1
    2180:      	fcsel	s3, s3, s22, ne
    2184:      	and	x10, x3, #0x7
    2188:      	add	x2, sp, #0x6b8
    218c:      	bfxil	x2, x3, #0, #3
    2190:      	ldrb	w2, [x2]
    2194:      	str	q24, [sp, #0x870]
    2198:      	str	q18, [sp, #0x860]
    219c:      	add	x3, sp, #0x860
    21a0:      	ldr	s4, [x3, x10, lsl #2]
    21a4:      	and	w10, w4, w2
    21a8:      	tst	w10, #0x1
    21ac:      	mov.s	w21, v17[3]
    21b0:      	mov.s	w30, v17[1]
    21b4:      	fmov	w10, s17
    21b8:      	and	x27, x10, #0x7
    21bc:      	add	x23, sp, #0x6b8
    21c0:      	bfxil	x23, x10, #0, #3
    21c4:      	add	x10, sp, #0x6b8
    21c8:      	bfxil	x10, x21, #0, #3
    21cc:      	ldrb	w26, [x10]
    21d0:      	movi.4s	v5, #0x4
    21d4:      	eor.16b	v5, v23, v5
    21d8:      	mov.s	w10, v5[1]
    21dc:      	mov.s	w7, v5[2]
    21e0:      	mov.s	w2, v5[3]
    21e4:      	fmov	w19, s5
    21e8:      	add	x3, sp, #0x6b8
    21ec:      	bfxil	x3, x19, #0, #3
    21f0:      	ldrb	w28, [x3]
    21f4:      	add	x3, sp, #0x6b8
    21f8:      	bfxil	x3, x10, #0, #3
    21fc:      	ldrb	w3, [x3]
    2200:      	add	x20, sp, #0x6b8
    2204:      	bfxil	x20, x7, #0, #3
    2208:      	ldrb	w20, [x20]
    220c:      	add	x22, sp, #0x6b8
    2210:      	bfxil	x22, x2, #0, #3
    2214:      	ldrb	w22, [x22]
    2218:      	ldrb	w23, [x23]
    221c:      	str	q24, [sp, #0x850]
    2220:      	str	q18, [sp, #0x840]
    2224:      	add	x8, sp, #0x840
    2228:      	ldr	s5, [x8, x27, lsl #2]
    222c:      	add	x27, sp, #0x6b8
    2230:      	bfxil	x27, x30, #0, #3
    2234:      	and	x30, x30, #0x7
    2238:      	ldrb	w27, [x27]
    223c:      	str	q24, [sp, #0x830]
    2240:      	str	q18, [sp, #0x820]
    2244:      	add	x8, sp, #0x820
    2248:      	ldr	s19, [x8, x30, lsl #2]
    224c:      	mov	x30, x6
    2250:      	fcsel	s4, s4, s22, ne
    2254:      	and	w23, w14, w23
    2258:      	tst	w23, #0x1
    225c:      	mov.s	w23, v17[2]
    2260:      	fcsel	s5, s5, s22, ne
    2264:      	and	w27, w17, w27
    2268:      	tst	w27, #0x1
    226c:      	add	x27, sp, #0x6b8
    2270:      	bfxil	x27, x23, #0, #3
    2274:      	and	x23, x23, #0x7
    2278:      	ldrb	w27, [x27]
    227c:      	str	q24, [sp, #0x810]
    2280:      	str	q18, [sp, #0x800]
    2284:      	add	x8, sp, #0x800
    2288:      	ldr	s17, [x8, x23, lsl #2]
    228c:      	fcsel	s19, s19, s22, ne
    2290:      	and	w23, w13, w27
    2294:      	mov	x27, x17
    2298:      	tst	w23, #0x1
    229c:      	mov	x23, x4
    22a0:      	and	x21, x21, #0x7
    22a4:      	str	q24, [sp, #0x7f0]
    22a8:      	str	q18, [sp, #0x7e0]
    22ac:      	add	x8, sp, #0x7e0
    22b0:      	ldr	s20, [x8, x21, lsl #2]
    22b4:      	fcsel	s17, s17, s22, ne
    22b8:      	and	w21, w6, w26
    22bc:      	mov	x26, x14
    22c0:      	tst	w21, #0x1
    22c4:      	fcsel	s20, s20, s22, ne
    22c8:      	mov.s	v5[1], v19[0]
    22cc:      	mov.s	v5[2], v17[0]
    22d0:      	mov.s	v5[3], v20[0]
    22d4:      	mov.s	v1[1], v2[0]
    22d8:      	mov.s	v1[2], v3[0]
    22dc:      	mov.s	v1[3], v4[0]
    22e0:      	fmaxnm.4s	v1, v18, v1
    22e4:      	fmaxnm.4s	v2, v24, v5
    22e8:      	and	x19, x19, #0x7
    22ec:      	str	q2, [sp, #0x7d0]
    22f0:      	str	q1, [sp, #0x7c0]
    22f4:      	add	x8, sp, #0x7c0
    22f8:      	ldr	s3, [x8, x19, lsl #2]
    22fc:      	mov	x19, x24
    2300:      	ldr	w24, [sp, #0x28]
    2304:      	ldr	w8, [sp, #0x300]
    2308:      	tst	w8, w28
    230c:      	mov	x28, x13
    2310:      	fcsel	s3, s3, s22, ne
    2314:      	and	x10, x10, #0x7
    2318:      	and	w3, w24, w3
    231c:      	str	q2, [sp, #0x7b0]
    2320:      	str	q1, [sp, #0x7a0]
    2324:      	add	x8, sp, #0x7a0
    2328:      	ldr	s4, [x8, x10, lsl #2]
    232c:      	tst	w3, #0x1
    2330:      	fcsel	s4, s4, s22, ne
    2334:      	and	x10, x7, #0x7
    2338:      	str	q2, [sp, #0x790]
    233c:      	str	q1, [sp, #0x780]
    2340:      	add	x8, sp, #0x780
    2344:      	ldr	s5, [x8, x10, lsl #2]
    2348:      	and	w10, w19, w20
    234c:      	ldr	w20, [sp, #0x2c]
    2350:      	tst	w10, #0x1
    2354:      	fcsel	s5, s5, s22, ne
    2358:      	and	x10, x2, #0x7
    235c:      	and	w2, w4, w22
    2360:      	str	q2, [sp, #0x770]
    2364:      	str	q1, [sp, #0x760]
    2368:      	add	x8, sp, #0x760
    236c:      	ldr	s2, [x8, x10, lsl #2]
    2370:      	tst	w2, #0x1
    2374:      	fcsel	s2, s2, s22, ne
    2378:      	ands	w4, w20, #0x1
    237c:      	mov.s	v3[1], v4[0]
    2380:      	mov.s	v3[2], v5[0]
    2384:      	mov.s	v3[3], v2[0]
    2388:      	fmaxnm.4s	v1, v1, v3
    238c:      	fcsel	s2, s1, s22, ne
    2390:      	and	w8, w24, w20
    2394:      	str	w8, [sp, #0xf0]
    2398:      	tst	w8, #0x1
    239c:      	fcsel	s3, s1, s22, ne
    23a0:      	and	w8, w19, w20
    23a4:      	str	w8, [sp, #0xe0]
    23a8:      	tst	w8, #0x1
    23ac:      	fcsel	s4, s1, s22, ne
    23b0:      	and	w8, w23, w20
    23b4:      	str	w8, [sp, #0x70]
    23b8:      	tst	w8, #0x1
    23bc:      	fcsel	s5, s1, s22, ne
    23c0:      	and	w8, w14, w20
    23c4:      	str	w8, [sp, #0x50]
    23c8:      	tst	w8, #0x1
    23cc:      	fcsel	s17, s1, s22, ne
    23d0:      	and	w8, w17, w20
    23d4:      	str	w8, [sp, #0x40]
    23d8:      	tst	w8, #0x1
    23dc:      	fcsel	s18, s1, s22, ne
    23e0:      	and	w7, w13, w20
    23e4:      	tst	w7, #0x1
    23e8:      	fcsel	s19, s1, s22, ne
    23ec:      	and	w22, w6, w20
    23f0:      	tst	w22, #0x1
    23f4:      	mov.s	v2[1], v3[0]
    23f8:      	mov.s	v2[2], v4[0]
    23fc:      	mov.s	v2[3], v5[0]
    2400:      	mov.s	v17[1], v18[0]
    2404:      	fcsel	s1, s1, s22, ne
    2408:      	mov.s	v17[2], v19[0]
    240c:      	mov.s	v17[3], v1[0]
    2410:      	ldr	w8, [sp, #0x100]
    2414:      	rbit	w10, w8
    2418:      	clz	w21, w10
    241c:      	str	q17, [sp, #0x6d0]
    2420:      	str	q2, [sp, #0x6c0]
    2424:      	and	x10, x21, #0x7
    2428:      	add	x8, sp, #0x6c0
    242c:      	ldr	s1, [x8, x10, lsl #2]
    2430:      	str	q6, [sp, #0x100]
    2434:      	mov.b	v6[0], wzr
    2438:      	str	q6, [sp, #0x30]
    243c:      	mov	w6, #-0x800000          ; =-8388608
    2440:      	fmov	s2, w6
    2444:      	fmaxnm	s1, s1, s2
    2448:      	dup.4s	v15, v1[0]
    244c:      	movi.2d	v18, #0000000000000000
    2450:      	movi.2d	v25, #0000000000000000
    2454:      	movi.2d	v24, #0000000000000000
    2458:      	movi.2d	v1, #0000000000000000
    245c:      	ldp	q12, q11, [sp, #0x2d0]
    2460:      	movi.4s	v23, #0x4b, lsl #24
    2464:      	ldr	q27, [sp, #0x2b0]
    2468:      	ldr	w8, [sp, #0x190]
    246c:      	ldp	q9, q28, [sp, #0x320]
    2470:      	ldr	q10, [sp, #0x310]
    2474:      	str	q30, [sp, #0x300]
    2478:      	str	q13, [sp, #0x290]
    247c:      	ldr	x3, [sp, #0x110]
    2480:      	mov	w14, #0x3f04            ; =16132
    2484:      	movk	w14, #0x3f0, lsl #16
    2488:      	adrp	x17, 0x2000 <ltmp0+0x2000>
    248c:      	mov	w13, #0x40              ; =64
    2490:      	b	0x2688 <ltmp0+0x2688>
    2494:      	lsl	x0, x0, #5
    2498:      	add	x10, x5, x0
    249c:      	ldp	q3, q2, [x10]
    24a0:      	fsub.4s	v4, v3, v15
    24a4:      	fsub.4s	v2, v2, v15
    24a8:      	and.16b	v3, v31, v2
    24ac:      	and.16b	v2, v13, v4
    24b0:      	mov.16b	v26, v31
    24b4:      	ldr	q31, [sp, #0x400]
    24b8:      	fcmge.4s	v4, v2, v31
    24bc:      	fcmge.4s	v5, v3, v31
    24c0:      	ldr	q30, [sp, #0x410]
    24c4:      	fcmge.4s	v17, v30, v2
    24c8:      	fcmge.4s	v19, v30, v3
    24cc:      	and.16b	v5, v5, v19
    24d0:      	and.16b	v4, v4, v17
    24d4:      	and.16b	v4, v4, v2
    24d8:      	and.16b	v5, v5, v3
    24dc:      	ldr	q6, [sp, #0x350]
    24e0:      	fmul.4s	v17, v5, v6
    24e4:      	fmul.4s	v19, v4, v6
    24e8:      	mvni.4s	v21, #0x80, lsl #24
    24ec:      	mov.16b	v20, v21
    24f0:      	bsl.16b	v20, v23, v19
    24f4:      	bsl.16b	v21, v23, v17
    24f8:      	fadd.4s	v17, v17, v21
    24fc:      	fadd.4s	v19, v19, v20
    2500:      	fsub.4s	v19, v19, v20
    2504:      	fsub.4s	v17, v17, v21
    2508:      	fcvtzs.4s	v17, v17
    250c:      	fcvtzs.4s	v19, v19
    2510:      	scvtf.4s	v20, v19
    2514:      	scvtf.4s	v21, v17
    2518:      	ldr	q6, [sp, #0x360]
    251c:      	fmul.4s	v22, v20, v6
    2520:      	fadd.4s	v4, v4, v22
    2524:      	fmul.4s	v22, v21, v6
    2528:      	fadd.4s	v5, v5, v22
    252c:      	ldr	q22, [sp, #0x370]
    2530:      	fmul.4s	v20, v20, v22
    2534:      	fmul.4s	v21, v21, v22
    2538:      	fadd.4s	v5, v5, v21
    253c:      	fadd.4s	v4, v4, v20
    2540:      	ldp	q21, q22, [sp, #0x380]
    2544:      	fmul.4s	v20, v4, v21
    2548:      	fmul.4s	v21, v5, v21
    254c:      	fadd.4s	v21, v21, v22
    2550:      	fadd.4s	v20, v20, v22
    2554:      	fmul.4s	v20, v4, v20
    2558:      	fmul.4s	v21, v5, v21
    255c:      	fadd.4s	v21, v21, v10
    2560:      	fadd.4s	v20, v20, v10
    2564:      	fmul.4s	v20, v4, v20
    2568:      	fmul.4s	v21, v5, v21
    256c:      	fadd.4s	v21, v21, v9
    2570:      	fadd.4s	v20, v20, v9
    2574:      	fmul.4s	v20, v4, v20
    2578:      	fmul.4s	v21, v5, v21
    257c:      	fadd.4s	v21, v21, v28
    2580:      	fadd.4s	v20, v20, v28
    2584:      	fmul.4s	v20, v4, v20
    2588:      	fmul.4s	v21, v5, v21
    258c:      	movi.4s	v22, #0x3f, lsl #24
    2590:      	fadd.4s	v21, v21, v22
    2594:      	fadd.4s	v20, v20, v22
    2598:      	fmul.4s	v22, v4, v4
    259c:      	fmul.4s	v20, v22, v20
    25a0:      	fmul.4s	v22, v5, v5
    25a4:      	fmul.4s	v21, v22, v21
    25a8:      	fadd.4s	v5, v5, v21
    25ac:      	fadd.4s	v4, v4, v20
    25b0:      	fadd.4s	v4, v4, v8
    25b4:      	fadd.4s	v5, v5, v8
    25b8:      	sshr.4s	v20, v19, #0x1
    25bc:      	sshr.4s	v21, v17, #0x1
    25c0:      	shl.4s	v22, v21, #0x17
    25c4:      	add.4s	v22, v22, v8
    25c8:      	fmul.4s	v5, v5, v22
    25cc:      	shl.4s	v22, v20, #0x17
    25d0:      	add.4s	v22, v22, v8
    25d4:      	fmul.4s	v4, v4, v22
    25d8:      	sub.4s	v17, v17, v21
    25dc:      	sub.4s	v19, v19, v20
    25e0:      	shl.4s	v19, v19, #0x17
    25e4:      	add.4s	v19, v19, v8
    25e8:      	fmul.4s	v4, v4, v19
    25ec:      	shl.4s	v17, v17, #0x17
    25f0:      	add.4s	v17, v17, v8
    25f4:      	fmul.4s	v5, v5, v17
    25f8:      	fcmgt.4s	v17, v31, v3
    25fc:      	bic.16b	v5, v5, v17
    2600:      	fcmgt.4s	v17, v31, v2
    2604:      	mov.16b	v31, v26
    2608:      	bic.16b	v4, v4, v17
    260c:      	fcmgt.4s	v17, v2, v30
    2610:      	ldr	q19, [sp, #0x340]
    2614:      	bit.16b	v4, v19, v17
    2618:      	fcmgt.4s	v17, v3, v30
    261c:      	bit.16b	v5, v19, v17
    2620:      	fcmeq.4s	v3, v3, v3
    2624:      	bsl.16b	v3, v5, v27
    2628:      	cmeq.8b	v5, v29, #0
    262c:      	sshll.8h	v5, v5, #0x0
    2630:      	fcmeq.4s	v2, v2, v2
    2634:      	bsl.16b	v2, v4, v27
    2638:      	sshll.4s	v4, v5, #0x0
    263c:      	bic.16b	v2, v2, v4
    2640:      	sshll2.4s	v4, v5, #0x0
    2644:      	bic.16b	v3, v3, v4
    2648:      	add	x10, x9, x0
    264c:      	ldp	q4, q5, [x10]
    2650:      	bif.16b	v3, v5, v26
    2654:      	bif.16b	v2, v4, v13
    2658:      	stp	q2, q3, [x10]
    265c:      	ldr	q2, [sp, #0x290]
    2660:      	add.2d	v25, v25, v2
    2664:      	ldr	q2, [sp, #0x3b0]
    2668:      	add.2d	v24, v24, v2
    266c:      	ldr	q2, [sp, #0x300]
    2670:      	add.2d	v1, v1, v2
    2674:      	ldr	q2, [sp, #0x3a0]
    2678:      	add.2d	v18, v18, v2
    267c:      	fmov	x0, d18
    2680:      	cmp	x0, #0x8
    2684:      	b.ge	0x2788 <ltmp0+0x2788>
    2688:      	ldr	q2, [sp, #0x280]
    268c:      	fmov	w10, s2
    2690:      	ldr	q2, [sp, #0x3c0]
    2694:      	add.2d	v2, v18, v2
    2698:      	ldr	q3, [sp, #0x220]
    269c:      	add.2d	v2, v3, v2
    26a0:      	tbz	w10, #0x0, 0x26bc <ltmp0+0x26bc>
    26a4:      	fmov	x2, d2
    26a8:      	ldr	b29, [x2]
    26ac:      	ldr	q13, [sp, #0x270]
    26b0:      	and	w10, w10, #0xff
    26b4:      	tbnz	w10, #0x1, 0x26cc <ltmp0+0x26cc>
    26b8:      	b	0x26d4 <ltmp0+0x26d4>
    26bc:      	movi.2d	v29, #0000000000000000
    26c0:      	ldr	q13, [sp, #0x270]
    26c4:      	and	w10, w10, #0xff
    26c8:      	tbz	w10, #0x1, 0x26d4 <ltmp0+0x26d4>
    26cc:      	mov.d	x2, v2[1]
    26d0:      	ld1.b	{ v29 }[1], [x2]
    26d4:      	ldr	q2, [sp, #0x200]
    26d8:      	add.2d	v2, v25, v2
    26dc:      	ldr	q3, [sp, #0x240]
    26e0:      	add.2d	v2, v3, v2
    26e4:      	tbnz	w10, #0x2, 0x2720 <ltmp0+0x2720>
    26e8:      	tbnz	w10, #0x3, 0x272c <ltmp0+0x272c>
    26ec:      	ldr	q2, [sp, #0x3d0]
    26f0:      	add.2d	v2, v24, v2
    26f4:      	ldr	q3, [sp, #0x230]
    26f8:      	add.2d	v2, v3, v2
    26fc:      	tbnz	w10, #0x4, 0x2748 <ltmp0+0x2748>
    2700:      	tbnz	w10, #0x5, 0x2754 <ltmp0+0x2754>
    2704:      	ldr	q2, [sp, #0x210]
    2708:      	add.2d	v2, v1, v2
    270c:      	ldr	q3, [sp, #0x250]
    2710:      	add.2d	v2, v3, v2
    2714:      	tbnz	w10, #0x6, 0x2770 <ltmp0+0x2770>
    2718:      	tbz	w10, #0x7, 0x2494 <ltmp0+0x2494>
    271c:      	b	0x277c <ltmp0+0x277c>
    2720:      	fmov	x2, d2
    2724:      	ld1.b	{ v29 }[2], [x2]
    2728:      	tbz	w10, #0x3, 0x26ec <ltmp0+0x26ec>
    272c:      	mov.d	x2, v2[1]
    2730:      	ld1.b	{ v29 }[3], [x2]
    2734:      	ldr	q2, [sp, #0x3d0]
    2738:      	add.2d	v2, v24, v2
    273c:      	ldr	q3, [sp, #0x230]
    2740:      	add.2d	v2, v3, v2
    2744:      	tbz	w10, #0x4, 0x2700 <ltmp0+0x2700>
    2748:      	fmov	x2, d2
    274c:      	ld1.b	{ v29 }[4], [x2]
    2750:      	tbz	w10, #0x5, 0x2704 <ltmp0+0x2704>
    2754:      	mov.d	x2, v2[1]
    2758:      	ld1.b	{ v29 }[5], [x2]
    275c:      	ldr	q2, [sp, #0x210]
    2760:      	add.2d	v2, v1, v2
    2764:      	ldr	q3, [sp, #0x250]
    2768:      	add.2d	v2, v3, v2
    276c:      	tbz	w10, #0x6, 0x2718 <ltmp0+0x2718>
    2770:      	fmov	x2, d2
    2774:      	ld1.b	{ v29 }[6], [x2]
    2778:      	tbz	w10, #0x7, 0x2494 <ltmp0+0x2494>
    277c:      	mov.d	x10, v2[1]
    2780:      	ld1.b	{ v29 }[7], [x10]
    2784:      	b	0x2494 <ltmp0+0x2494>
    2788:      	ldr	q1, [sp, #0x80]
    278c:      	sshll.4s	v1, v1, #0x0
    2790:      	ldr	q2, [sp, #0x1a0]
    2794:      	fsub.4s	v5, v2, v15
    2798:      	fsub.4s	v3, v14, v15
    279c:      	ldr	q17, [sp, #0x1c0]
    27a0:      	zip2.8b	v2, v17, v0
    27a4:      	ushll.4s	v2, v2, #0x0
    27a8:      	shl.4s	v2, v2, #0x1f
    27ac:      	cmlt.4s	v2, v2, #0
    27b0:      	and.16b	v4, v2, v3
    27b4:      	zip1.8b	v3, v17, v0
    27b8:      	ushll.4s	v3, v3, #0x0
    27bc:      	shl.4s	v3, v3, #0x1f
    27c0:      	cmlt.4s	v3, v3, #0
    27c4:      	and.16b	v5, v3, v5
    27c8:      	ldr	q29, [sp, #0x400]
    27cc:      	fcmge.4s	v17, v5, v29
    27d0:      	fcmge.4s	v18, v4, v29
    27d4:      	ldr	q25, [sp, #0x410]
    27d8:      	fcmge.4s	v19, v25, v5
    27dc:      	fcmge.4s	v20, v25, v4
    27e0:      	and.16b	v18, v18, v20
    27e4:      	and.16b	v17, v17, v19
    27e8:      	and.16b	v17, v17, v5
    27ec:      	and.16b	v18, v18, v4
    27f0:      	ldr	q6, [sp, #0x350]
    27f4:      	fmul.4s	v19, v18, v6
    27f8:      	fmul.4s	v20, v17, v6
    27fc:      	mvni.4s	v22, #0x80, lsl #24
    2800:      	mov.16b	v21, v22
    2804:      	bsl.16b	v21, v23, v20
    2808:      	bsl.16b	v22, v23, v19
    280c:      	fadd.4s	v19, v19, v22
    2810:      	fadd.4s	v20, v20, v21
    2814:      	fsub.4s	v20, v20, v21
    2818:      	fsub.4s	v19, v19, v22
    281c:      	fcvtzs.4s	v19, v19
    2820:      	fcvtzs.4s	v20, v20
    2824:      	scvtf.4s	v21, v20
    2828:      	scvtf.4s	v22, v19
    282c:      	ldr	q6, [sp, #0x360]
    2830:      	fmul.4s	v23, v22, v6
    2834:      	fmul.4s	v24, v21, v6
    2838:      	fadd.4s	v17, v17, v24
    283c:      	fadd.4s	v18, v18, v23
    2840:      	ldr	q23, [sp, #0x370]
    2844:      	fmul.4s	v21, v21, v23
    2848:      	fmul.4s	v22, v22, v23
    284c:      	fadd.4s	v18, v18, v22
    2850:      	fadd.4s	v17, v17, v21
    2854:      	ldp	q22, q23, [sp, #0x380]
    2858:      	fmul.4s	v21, v17, v22
    285c:      	fmul.4s	v22, v18, v22
    2860:      	fadd.4s	v22, v22, v23
    2864:      	fadd.4s	v21, v21, v23
    2868:      	fmul.4s	v21, v17, v21
    286c:      	fmul.4s	v22, v18, v22
    2870:      	fadd.4s	v22, v22, v10
    2874:      	fadd.4s	v21, v21, v10
    2878:      	fmul.4s	v21, v17, v21
    287c:      	fmul.4s	v22, v18, v22
    2880:      	fadd.4s	v22, v22, v9
    2884:      	fadd.4s	v21, v21, v9
    2888:      	fmul.4s	v21, v17, v21
    288c:      	fmul.4s	v22, v18, v22
    2890:      	fadd.4s	v22, v22, v28
    2894:      	fadd.4s	v21, v21, v28
    2898:      	fmul.4s	v21, v17, v21
    289c:      	fmul.4s	v22, v18, v22
    28a0:      	movi.4s	v23, #0x3f, lsl #24
    28a4:      	fadd.4s	v22, v22, v23
    28a8:      	fadd.4s	v21, v21, v23
    28ac:      	fmul.4s	v23, v18, v18
    28b0:      	fmul.4s	v24, v17, v17
    28b4:      	fmul.4s	v21, v24, v21
    28b8:      	fmul.4s	v22, v23, v22
    28bc:      	fadd.4s	v18, v18, v22
    28c0:      	fadd.4s	v17, v17, v21
    28c4:      	fadd.4s	v17, v17, v8
    28c8:      	fadd.4s	v18, v18, v8
    28cc:      	sshr.4s	v21, v20, #0x1
    28d0:      	sshr.4s	v22, v19, #0x1
    28d4:      	shl.4s	v23, v22, #0x17
    28d8:      	shl.4s	v24, v21, #0x17
    28dc:      	add.4s	v24, v24, v8
    28e0:      	add.4s	v23, v23, v8
    28e4:      	fmul.4s	v18, v18, v23
    28e8:      	fmul.4s	v17, v17, v24
    28ec:      	sub.4s	v19, v19, v22
    28f0:      	sub.4s	v20, v20, v21
    28f4:      	shl.4s	v20, v20, #0x17
    28f8:      	shl.4s	v19, v19, #0x17
    28fc:      	add.4s	v19, v19, v8
    2900:      	add.4s	v20, v20, v8
    2904:      	fmul.4s	v17, v17, v20
    2908:      	fmul.4s	v18, v18, v19
    290c:      	fcmgt.4s	v19, v29, v4
    2910:      	bic.16b	v18, v18, v19
    2914:      	fcmgt.4s	v19, v29, v5
    2918:      	bic.16b	v17, v17, v19
    291c:      	fcmgt.4s	v19, v4, v25
    2920:      	fcmgt.4s	v20, v5, v25
    2924:      	ldr	q21, [sp, #0x340]
    2928:      	bit.16b	v17, v21, v20
    292c:      	bit.16b	v18, v21, v19
    2930:      	fcmeq.4s	v5, v5, v5
    2934:      	fcmeq.4s	v4, v4, v4
    2938:      	bsl.16b	v4, v18, v27
    293c:      	bsl.16b	v5, v17, v27
    2940:      	bic.16b	v6, v5, v1
    2944:      	ldr	q1, [sp, #0x90]
    2948:      	bic.16b	v5, v4, v1
    294c:      	add	x10, x9, x3
    2950:      	ldp	q1, q4, [x10]
    2954:      	str	q5, [sp, #0x410]
    2958:      	bsl.16b	v2, v5, v4
    295c:      	str	q6, [sp, #0x400]
    2960:      	bit.16b	v1, v6, v3
    2964:      	stp	q1, q2, [x10]
    2968:      	ldp	q1, q2, [x9, #0x60]
    296c:      	and.16b	v2, v31, v2
    2970:      	ldr	q13, [sp, #0x270]
    2974:      	and.16b	v3, v13, v1
    2978:      	ldp	q1, q4, [x9, #0x40]
    297c:      	and.16b	v18, v31, v4
    2980:      	and.16b	v17, v13, v1
    2984:      	ldp	q1, q4, [x9, #0x20]
    2988:      	and.16b	v24, v31, v4
    298c:      	and.16b	v25, v13, v1
    2990:      	ldr	x10, [sp, #0xa8]
    2994:      	add	x10, x9, x10
    2998:      	ldp	q1, q4, [x10]
    299c:      	and.16b	v5, v31, v4
    29a0:      	and.16b	v4, v13, v1
    29a4:      	mov	w0, #0x4                ; =4
    29a8:      	ldr	q10, [sp, #0x1b0]
    29ac:      	ldp	q14, q30, [sp, #0xc0]
    29b0:      	ldr	q15, [sp, #0x60]
    29b4:      	ldr	q6, [sp, #0xb0]
    29b8:      	sshll.2d	v1, v13, #0x0
    29bc:      	sshll.2d	v20, v31, #0x0
    29c0:      	add	x10, x9, x25, lsl #5
    29c4:      	ldp	q21, q19, [x10]
    29c8:      	fadd.4s	v27, v4, v21
    29cc:      	fadd.4s	v19, v5, v19
    29d0:      	ldp	q22, q21, [x10, #0x20]
    29d4:      	fadd.4s	v22, v25, v22
    29d8:      	fadd.4s	v21, v24, v21
    29dc:      	ldp	q28, q23, [x10, #0x40]
    29e0:      	fadd.4s	v28, v17, v28
    29e4:      	fadd.4s	v23, v18, v23
    29e8:      	ldp	q31, q29, [x10, #0x60]
    29ec:      	fadd.4s	v31, v3, v31
    29f0:      	fadd.4s	v29, v2, v29
    29f4:      	dup.2d	v8, x0
    29f8:      	and.16b	v9, v10, v8
    29fc:      	add.2d	v30, v30, v9
    2a00:      	ldr	q9, [sp, #0x260]
    2a04:      	and.16b	v9, v9, v8
    2a08:      	add.2d	v14, v14, v9
    2a0c:      	and.16b	v20, v20, v8
    2a10:      	add.2d	v6, v6, v20
    2a14:      	and.16b	v1, v1, v8
    2a18:      	add.2d	v15, v15, v1
    2a1c:      	bit.16b	v5, v19, v26
    2a20:      	bit.16b	v4, v27, v13
    2a24:      	bit.16b	v24, v21, v26
    2a28:      	bit.16b	v25, v22, v13
    2a2c:      	bit.16b	v18, v23, v26
    2a30:      	bit.16b	v17, v28, v13
    2a34:      	bit.16b	v2, v29, v26
    2a38:      	bit.16b	v3, v31, v13
    2a3c:      	mov.16b	v31, v26
    2a40:      	fmov	x25, d15
    2a44:      	cmp	x25, #0x8
    2a48:      	b.lt	0x29b8 <ltmp0+0x29b8>
    2a4c:      	mov	x0, #0x0                ; =0
    2a50:      	adrp	x10, 0x2000 <ltmp0+0x2000>
    2a54:      	ldr	q1, [x10]
    2a58:      	and.16b	v29, v31, v1
    2a5c:      	adrp	x10, 0x2000 <ltmp0+0x2000>
    2a60:      	ldr	q1, [x10]
    2a64:      	and.16b	v20, v13, v1
    2a68:      	adrp	x10, 0x2000 <ltmp0+0x2000>
    2a6c:      	ldr	q1, [x10]
    2a70:      	and.16b	v1, v13, v1
    2a74:      	ldr	q28, [sp, #0x410]
    2a78:      	fadd.4s	v5, v28, v5
    2a7c:      	ldr	q30, [sp, #0x400]
    2a80:      	fadd.4s	v4, v30, v4
    2a84:      	ldr	q26, [sp, #0x1c0]
    2a88:      	zip1.8b	v21, v26, v0
    2a8c:      	ushll.4s	v21, v21, #0x0
    2a90:      	shl.4s	v21, v21, #0x1f
    2a94:      	cmlt.4s	v21, v21, #0
    2a98:      	and.16b	v4, v21, v4
    2a9c:      	zip2.8b	v21, v26, v0
    2aa0:      	ushll.4s	v21, v21, #0x0
    2aa4:      	shl.4s	v21, v21, #0x1f
    2aa8:      	cmlt.4s	v21, v21, #0
    2aac:      	and.16b	v5, v21, v5
    2ab0:      	ldr	q6, [sp, #0x30]
    2ab4:      	zip2.8b	v21, v6, v0
    2ab8:      	ushll.4s	v21, v21, #0x0
    2abc:      	shl.4s	v21, v21, #0x1f
    2ac0:      	cmlt.4s	v21, v21, #0
    2ac4:      	bit.16b	v5, v19, v21
    2ac8:      	zip1.8b	v19, v6, v0
    2acc:      	ushll.4s	v19, v19, #0x0
    2ad0:      	shl.4s	v19, v19, #0x1f
    2ad4:      	cmlt.4s	v19, v19, #0
    2ad8:      	bit.16b	v4, v27, v19
    2adc:      	fadd.4s	v4, v25, v4
    2ae0:      	fadd.4s	v5, v24, v5
    2ae4:      	fadd.4s	v5, v18, v5
    2ae8:      	fadd.4s	v4, v17, v4
    2aec:      	fadd.4s	v3, v3, v4
    2af0:      	fadd.4s	v17, v2, v5
    2af4:      	fmov	w10, s20
    2af8:      	add	x2, sp, #0x468
    2afc:      	bfxil	x2, x10, #0, #3
    2b00:      	ldr	q2, [sp, #0x100]
    2b04:      	str	d2, [sp, #0x468]
    2b08:      	ldrb	w2, [x2]
    2b0c:      	add	x3, sp, #0x690
    2b10:      	orr	x10, x3, x10, lsl #2
    2b14:      	str	q17, [sp, #0x6a0]
    2b18:      	str	q3, [sp, #0x690]
    2b1c:      	ldr	s2, [x10]
    2b20:      	tst	w4, w2
    2b24:      	movi	d23, #0000000000000000
    2b28:      	fcsel	s2, s2, s23, ne
    2b2c:      	mov.s	w10, v20[1]
    2b30:      	add	x2, sp, #0x468
    2b34:      	bfxil	x2, x10, #0, #3
    2b38:      	ldrb	w10, [x2]
    2b3c:      	and	w10, w24, w10
    2b40:      	str	q3, [sp, #0x670]
    2b44:      	ldr	s4, [sp, #0x670]
    2b48:      	tst	w10, #0x1
    2b4c:      	fcsel	s4, s4, s23, ne
    2b50:      	mov.s	w10, v20[2]
    2b54:      	add	x2, sp, #0x468
    2b58:      	bfxil	x2, x10, #0, #3
    2b5c:      	add	x3, sp, #0x650
    2b60:      	orr	x10, x3, x10, lsl #2
    2b64:      	ldrb	w2, [x2]
    2b68:      	and	w2, w19, w2
    2b6c:      	str	q17, [sp, #0x660]
    2b70:      	str	q3, [sp, #0x650]
    2b74:      	ldr	s5, [x10]
    2b78:      	tst	w2, #0x1
    2b7c:      	fcsel	s5, s5, s23, ne
    2b80:      	mov.s	w10, v20[3]
    2b84:      	add	x2, sp, #0x468
    2b88:      	bfxil	x2, x10, #0, #3
    2b8c:      	add	x3, sp, #0x630
    2b90:      	orr	x10, x3, x10, lsl #2
    2b94:      	ldrb	w2, [x2]
    2b98:      	and	w2, w23, w2
    2b9c:      	str	q17, [sp, #0x640]
    2ba0:      	str	q3, [sp, #0x630]
    2ba4:      	ldr	s18, [x10]
    2ba8:      	tst	w2, #0x1
    2bac:      	fcsel	s18, s18, s23, ne
    2bb0:      	fmov	w10, s29
    2bb4:      	add	x2, sp, #0x468
    2bb8:      	bfxil	x2, x10, #0, #3
    2bbc:      	ldrb	w2, [x2]
    2bc0:      	and	w2, w26, w2
    2bc4:      	str	q17, [sp, #0x620]
    2bc8:      	str	q3, [sp, #0x610]
    2bcc:      	add	x3, sp, #0x610
    2bd0:      	ldr	s19, [x3, w10, uxtw #2]
    2bd4:      	tst	w2, #0x1
    2bd8:      	fcsel	s19, s19, s23, ne
    2bdc:      	mov.s	w10, v29[1]
    2be0:      	add	x2, sp, #0x468
    2be4:      	bfxil	x2, x10, #0, #3
    2be8:      	ldrb	w2, [x2]
    2bec:      	and	w2, w27, w2
    2bf0:      	str	q17, [sp, #0x600]
    2bf4:      	str	q3, [sp, #0x5f0]
    2bf8:      	add	x3, sp, #0x5f0
    2bfc:      	ldr	s20, [x3, w10, uxtw #2]
    2c00:      	tst	w2, #0x1
    2c04:      	fcsel	s20, s20, s23, ne
    2c08:      	mov.s	w10, v29[2]
    2c0c:      	add	x2, sp, #0x468
    2c10:      	bfxil	x2, x10, #0, #3
    2c14:      	ldrb	w2, [x2]
    2c18:      	and	w2, w28, w2
    2c1c:      	str	q17, [sp, #0x5e0]
    2c20:      	str	q3, [sp, #0x5d0]
    2c24:      	add	x3, sp, #0x5d0
    2c28:      	ldr	s21, [x3, w10, uxtw #2]
    2c2c:      	tst	w2, #0x1
    2c30:      	fcsel	s21, s21, s23, ne
    2c34:      	mov.s	w10, v29[3]
    2c38:      	add	x2, sp, #0x468
    2c3c:      	bfxil	x2, x10, #0, #3
    2c40:      	ldrb	w2, [x2]
    2c44:      	and	w2, w30, w2
    2c48:      	str	q17, [sp, #0x5c0]
    2c4c:      	str	q3, [sp, #0x5b0]
    2c50:      	add	x3, sp, #0x5b0
    2c54:      	ldr	s22, [x3, w10, uxtw #2]
    2c58:      	tst	w2, #0x1
    2c5c:      	fcsel	s22, s22, s23, ne
    2c60:      	mov.s	v19[1], v20[0]
    2c64:      	mov.s	v19[2], v21[0]
    2c68:      	mov.s	v19[3], v22[0]
    2c6c:      	mov.s	v2[1], v4[0]
    2c70:      	mov.s	v2[2], v5[0]
    2c74:      	mov.s	v2[3], v18[0]
    2c78:      	fadd.4s	v2, v3, v2
    2c7c:      	fadd.4s	v3, v17, v19
    2c80:      	fmov	w10, s1
    2c84:      	add	x2, sp, #0x468
    2c88:      	bfxil	x2, x10, #0, #3
    2c8c:      	ldrb	w2, [x2]
    2c90:      	add	x3, sp, #0x590
    2c94:      	orr	x10, x3, x10, lsl #2
    2c98:      	str	q3, [sp, #0x5a0]
    2c9c:      	str	q2, [sp, #0x590]
    2ca0:      	ldr	s4, [x10]
    2ca4:      	mov.s	w10, v1[1]
    2ca8:      	tst	w4, w2
    2cac:      	add	x2, sp, #0x468
    2cb0:      	bfxil	x2, x10, #0, #3
    2cb4:      	ldrb	w2, [x2]
    2cb8:      	and	w2, w24, w2
    2cbc:      	fcsel	s4, s4, s23, ne
    2cc0:      	add	x3, sp, #0x570
    2cc4:      	orr	x10, x3, x10, lsl #2
    2cc8:      	str	q3, [sp, #0x580]
    2ccc:      	str	q2, [sp, #0x570]
    2cd0:      	ldr	s17, [x10]
    2cd4:      	mov.s	w10, v1[2]
    2cd8:      	tst	w2, #0x1
    2cdc:      	add	x2, sp, #0x468
    2ce0:      	bfxil	x2, x10, #0, #3
    2ce4:      	adrp	x10, 0x2000 <ltmp0+0x2000>
    2ce8:      	ldr	q5, [x10]
    2cec:      	and.16b	v19, v31, v5
    2cf0:      	movi.4s	v5, #0x4
    2cf4:      	and.16b	v5, v13, v5
    2cf8:      	fcsel	s17, s17, s23, ne
    2cfc:      	ldrb	w10, [x2]
    2d00:      	and	w10, w19, w10
    2d04:      	str	q2, [sp, #0x550]
    2d08:      	ldr	s18, [sp, #0x550]
    2d0c:      	tst	w10, #0x1
    2d10:      	fcsel	s18, s18, s23, ne
    2d14:      	mov.s	w10, v1[3]
    2d18:      	add	x2, sp, #0x468
    2d1c:      	bfxil	x2, x10, #0, #3
    2d20:      	add	x3, sp, #0x530
    2d24:      	orr	x10, x3, x10, lsl #2
    2d28:      	ldrb	w2, [x2]
    2d2c:      	and	w2, w23, w2
    2d30:      	str	q3, [sp, #0x540]
    2d34:      	str	q2, [sp, #0x530]
    2d38:      	ldr	s1, [x10]
    2d3c:      	tst	w2, #0x1
    2d40:      	fcsel	s1, s1, s23, ne
    2d44:      	fmov	w10, s19
    2d48:      	add	x2, sp, #0x468
    2d4c:      	bfxil	x2, x10, #0, #3
    2d50:      	ldrb	w2, [x2]
    2d54:      	and	w2, w26, w2
    2d58:      	str	q3, [sp, #0x520]
    2d5c:      	str	q2, [sp, #0x510]
    2d60:      	add	x3, sp, #0x510
    2d64:      	ldr	s20, [x3, w10, uxtw #2]
    2d68:      	tst	w2, #0x1
    2d6c:      	fcsel	s20, s20, s23, ne
    2d70:      	mov.s	w10, v19[1]
    2d74:      	add	x2, sp, #0x468
    2d78:      	bfxil	x2, x10, #0, #3
    2d7c:      	ldrb	w2, [x2]
    2d80:      	and	w2, w27, w2
    2d84:      	str	q3, [sp, #0x500]
    2d88:      	str	q2, [sp, #0x4f0]
    2d8c:      	add	x3, sp, #0x4f0
    2d90:      	ldr	s21, [x3, w10, uxtw #2]
    2d94:      	tst	w2, #0x1
    2d98:      	fcsel	s21, s21, s23, ne
    2d9c:      	mov.s	w10, v19[2]
    2da0:      	add	x2, sp, #0x468
    2da4:      	bfxil	x2, x10, #0, #3
    2da8:      	ldrb	w2, [x2]
    2dac:      	and	w2, w28, w2
    2db0:      	str	q3, [sp, #0x4e0]
    2db4:      	str	q2, [sp, #0x4d0]
    2db8:      	add	x3, sp, #0x4d0
    2dbc:      	ldr	s22, [x3, w10, uxtw #2]
    2dc0:      	tst	w2, #0x1
    2dc4:      	fcsel	s22, s22, s23, ne
    2dc8:      	mov.s	w10, v19[3]
    2dcc:      	add	x2, sp, #0x468
    2dd0:      	bfxil	x2, x10, #0, #3
    2dd4:      	ldrb	w2, [x2]
    2dd8:      	and	w2, w30, w2
    2ddc:      	str	q3, [sp, #0x4c0]
    2de0:      	str	q2, [sp, #0x4b0]
    2de4:      	add	x3, sp, #0x4b0
    2de8:      	ldr	s19, [x3, w10, uxtw #2]
    2dec:      	tst	w2, #0x1
    2df0:      	fcsel	s19, s19, s23, ne
    2df4:      	mov.s	v20[1], v21[0]
    2df8:      	mov.s	v20[2], v22[0]
    2dfc:      	mov.s	v20[3], v19[0]
    2e00:      	mov.s	v4[1], v17[0]
    2e04:      	mov.s	v4[2], v18[0]
    2e08:      	mov.s	v4[3], v1[0]
    2e0c:      	fadd.4s	v1, v2, v4
    2e10:      	fadd.4s	v2, v3, v20
    2e14:      	fmov	w10, s5
    2e18:      	add	x2, sp, #0x468
    2e1c:      	orr	x2, x2, x10
    2e20:      	ldrb	w2, [x2]
    2e24:      	str	q2, [sp, #0x4a0]
    2e28:      	str	q1, [sp, #0x490]
    2e2c:      	add	x3, sp, #0x490
    2e30:      	ldr	s2, [x3, w10, uxtw #2]
    2e34:      	tst	w4, w2
    2e38:      	fcsel	s2, s2, s23, ne
    2e3c:      	tst	w20, #0x1
    2e40:      	fadd	s1, s1, s2
    2e44:      	fcsel	s2, s1, s23, ne
    2e48:      	ldr	w10, [sp, #0xf0]
    2e4c:      	tst	w10, #0x1
    2e50:      	fcsel	s3, s1, s23, ne
    2e54:      	ldr	w10, [sp, #0xe0]
    2e58:      	tst	w10, #0x1
    2e5c:      	fcsel	s4, s1, s23, ne
    2e60:      	ldr	w10, [sp, #0x70]
    2e64:      	tst	w10, #0x1
    2e68:      	fcsel	s5, s1, s23, ne
    2e6c:      	ldr	w10, [sp, #0x50]
    2e70:      	tst	w10, #0x1
    2e74:      	fcsel	s17, s1, s23, ne
    2e78:      	ldr	w10, [sp, #0x40]
    2e7c:      	tst	w10, #0x1
    2e80:      	fcsel	s18, s1, s23, ne
    2e84:      	tst	w7, #0x1
    2e88:      	fcsel	s19, s1, s23, ne
    2e8c:      	tst	w22, #0x1
    2e90:      	fcsel	s1, s1, s23, ne
    2e94:      	mov.s	v2[1], v3[0]
    2e98:      	mov.s	v2[2], v4[0]
    2e9c:      	mov.s	v2[3], v5[0]
    2ea0:      	mov.s	v17[1], v18[0]
    2ea4:      	mov.s	v17[2], v19[0]
    2ea8:      	mov.s	v17[3], v1[0]
    2eac:      	str	q17, [sp, #0x480]
    2eb0:      	str	q2, [sp, #0x470]
    2eb4:      	and	x10, x21, #0x7
    2eb8:      	add	x2, sp, #0x470
    2ebc:      	ldr	s1, [x2, x10, lsl #2]
    2ec0:      	fadd	s1, s1, s23
    2ec4:      	dup.4s	v1, v1[0]
    2ec8:      	ldr	q2, [sp, #0x130]
    2ecc:      	fmov	x10, d2
    2ed0:      	ldp	x7, x4, [sp, #0x180]
    2ed4:      	add	x10, x4, x10, lsl #2
    2ed8:      	movi.2d	v2, #0000000000000000
    2edc:      	movi.2d	v3, #0000000000000000
    2ee0:      	movi.2d	v4, #0000000000000000
    2ee4:      	movi.2d	v5, #0000000000000000
    2ee8:      	ldr	q21, [sp, #0x2c0]
    2eec:      	ldr	q22, [sp, #0x2f0]
    2ef0:      	ldr	q6, [sp, #0x2a0]
    2ef4:      	ldr	q19, [sp, #0x280]
    2ef8:      	b	0x2f28 <ltmp0+0x2f28>
    2efc:      	ldr	q17, [sp, #0x290]
    2f00:      	add.2d	v3, v3, v17
    2f04:      	ldr	q17, [sp, #0x3b0]
    2f08:      	add.2d	v4, v4, v17
    2f0c:      	ldr	q17, [sp, #0x300]
    2f10:      	add.2d	v5, v5, v17
    2f14:      	ldr	q17, [sp, #0x3a0]
    2f18:      	add.2d	v2, v2, v17
    2f1c:      	fmov	x0, d2
    2f20:      	cmp	x0, #0x8
    2f24:      	b.ge	0x2fd8 <ltmp0+0x2fd8>
    2f28:      	fmov	w2, s19
    2f2c:      	lsl	x0, x0, #5
    2f30:      	add	x3, x9, x0
    2f34:      	ldp	q18, q17, [x3]
    2f38:      	and.16b	v18, v13, v18
    2f3c:      	fdiv.4s	v18, v18, v1
    2f40:      	add	x0, x10, x0
    2f44:      	tbnz	w2, #0x0, 0x2f74 <ltmp0+0x2f74>
    2f48:      	and	w2, w2, #0xff
    2f4c:      	tbnz	w2, #0x1, 0x2f80 <ltmp0+0x2f80>
    2f50:      	tbnz	w2, #0x2, 0x2f8c <ltmp0+0x2f8c>
    2f54:      	tbnz	w2, #0x3, 0x2f98 <ltmp0+0x2f98>
    2f58:      	and.16b	v17, v31, v17
    2f5c:      	fdiv.4s	v17, v17, v1
    2f60:      	tbnz	w2, #0x4, 0x2fac <ltmp0+0x2fac>
    2f64:      	tbnz	w2, #0x5, 0x2fb4 <ltmp0+0x2fb4>
    2f68:      	tbnz	w2, #0x6, 0x2fc0 <ltmp0+0x2fc0>
    2f6c:      	tbz	w2, #0x7, 0x2efc <ltmp0+0x2efc>
    2f70:      	b	0x2fcc <ltmp0+0x2fcc>
    2f74:      	str	s18, [x0]
    2f78:      	and	w2, w2, #0xff
    2f7c:      	tbz	w2, #0x1, 0x2f50 <ltmp0+0x2f50>
    2f80:      	add	x3, x0, #0x4
    2f84:      	st1.s	{ v18 }[1], [x3]
    2f88:      	tbz	w2, #0x2, 0x2f54 <ltmp0+0x2f54>
    2f8c:      	add	x3, x0, #0x8
    2f90:      	st1.s	{ v18 }[2], [x3]
    2f94:      	tbz	w2, #0x3, 0x2f58 <ltmp0+0x2f58>
    2f98:      	add	x3, x0, #0xc
    2f9c:      	st1.s	{ v18 }[3], [x3]
    2fa0:      	and.16b	v17, v31, v17
    2fa4:      	fdiv.4s	v17, v17, v1
    2fa8:      	tbz	w2, #0x4, 0x2f64 <ltmp0+0x2f64>
    2fac:      	str	s17, [x0, #0x10]
    2fb0:      	tbz	w2, #0x5, 0x2f68 <ltmp0+0x2f68>
    2fb4:      	add	x3, x0, #0x14
    2fb8:      	st1.s	{ v17 }[1], [x3]
    2fbc:      	tbz	w2, #0x6, 0x2f6c <ltmp0+0x2f6c>
    2fc0:      	add	x3, x0, #0x18
    2fc4:      	st1.s	{ v17 }[2], [x3]
    2fc8:      	tbz	w2, #0x7, 0x2efc <ltmp0+0x2efc>
    2fcc:      	add	x0, x0, #0x1c
    2fd0:      	st1.s	{ v17 }[3], [x0]
    2fd4:      	b	0x2efc <ltmp0+0x2efc>
    2fd8:      	ldr	d2, [sp, #0x120]
    2fdc:      	fmov	w10, s2
    2fe0:      	zip1.8b	v2, v26, v0
    2fe4:      	ushll.4s	v2, v2, #0x0
    2fe8:      	shl.4s	v2, v2, #0x1f
    2fec:      	cmlt.4s	v2, v2, #0
    2ff0:      	and.16b	v2, v2, v30
    2ff4:      	fdiv.4s	v2, v2, v1
    2ff8:      	ldr	q3, [sp, #0x170]
    2ffc:      	str	q3, [sp, #0x420]
    3000:      	ldp	q3, q4, [sp, #0x140]
    3004:      	str	q4, [sp, #0x430]
    3008:      	str	q3, [sp, #0x440]
    300c:      	ldr	q3, [sp, #0x160]
    3010:      	str	q3, [sp, #0x450]
    3014:      	and	x0, x7, #0x7
    3018:      	add	x2, sp, #0x420
    301c:      	ldr	x0, [x2, x0, lsl #3]
    3020:      	sub	x0, x0, x7
    3024:      	add	x0, x4, x0, lsl #2
    3028:      	tbnz	w10, #0x0, 0x30bc <ltmp0+0x30bc>
    302c:      	tbnz	w10, #0x1, 0x30c4 <ltmp0+0x30c4>
    3030:      	tbnz	w10, #0x2, 0x30d0 <ltmp0+0x30d0>
    3034:      	tbz	w10, #0x3, 0x3040 <ltmp0+0x3040>
    3038:      	add	x2, x0, #0xc
    303c:      	st1.s	{ v2 }[3], [x2]
    3040:      	zip2.8b	v2, v26, v0
    3044:      	ushll.4s	v2, v2, #0x0
    3048:      	shl.4s	v2, v2, #0x1f
    304c:      	cmlt.4s	v2, v2, #0
    3050:      	and.16b	v2, v2, v28
    3054:      	fdiv.4s	v1, v2, v1
    3058:      	tbnz	w10, #0x4, 0x30e0 <ltmp0+0x30e0>
    305c:      	tbnz	w10, #0x5, 0x30e8 <ltmp0+0x30e8>
    3060:      	tbnz	w10, #0x6, 0x30f4 <ltmp0+0x30f4>
    3064:      	tbz	w10, #0x7, 0x108 <ltmp0+0x108>
    3068:      	b	0x3100 <ltmp0+0x3100>
    306c:      	fmov	x4, d25
    3070:      	ld1.b	{ v1 }[2], [x4]
    3074:      	tbz	w2, #0x3, 0x1c80 <ltmp0+0x1c80>
    3078:      	ld1.b	{ v1 }[3], [x3]
    307c:      	tbz	w2, #0x4, 0x1c84 <ltmp0+0x1c84>
    3080:      	ldr	q2, [sp, #0x3b0]
    3084:      	fmov	x3, d2
    3088:      	ld1.b	{ v1 }[4], [x3]
    308c:      	tbz	w2, #0x5, 0x1c88 <ltmp0+0x1c88>
    3090:      	ld1.b	{ v1 }[5], [x0]
    3094:      	tbz	w2, #0x6, 0x1c8c <ltmp0+0x1c8c>
    3098:      	fmov	x0, d22
    309c:      	ld1.b	{ v1 }[6], [x0]
    30a0:      	mov	w0, #0x4                ; =4
    30a4:      	str	d21, [sp, #0x120]
    30a8:      	stp	q28, q27, [sp, #0x240]
    30ac:      	stp	q10, q9, [sp, #0x220]
    30b0:      	stp	q12, q11, [sp, #0x200]
    30b4:      	tbnz	w2, #0x7, 0x1ca4 <ltmp0+0x1ca4>
    30b8:      	b	0x1ca8 <ltmp0+0x1ca8>
    30bc:      	str	s2, [x0]
    30c0:      	tbz	w10, #0x1, 0x3030 <ltmp0+0x3030>
    30c4:      	add	x2, x0, #0x4
    30c8:      	st1.s	{ v2 }[1], [x2]
    30cc:      	tbz	w10, #0x2, 0x3034 <ltmp0+0x3034>
    30d0:      	add	x2, x0, #0x8
    30d4:      	st1.s	{ v2 }[2], [x2]
    30d8:      	tbnz	w10, #0x3, 0x3038 <ltmp0+0x3038>
    30dc:      	b	0x3040 <ltmp0+0x3040>
    30e0:      	str	s1, [x0, #0x10]
    30e4:      	tbz	w10, #0x5, 0x3060 <ltmp0+0x3060>
    30e8:      	add	x2, x0, #0x14
    30ec:      	st1.s	{ v1 }[1], [x2]
    30f0:      	tbz	w10, #0x6, 0x3064 <ltmp0+0x3064>
    30f4:      	add	x2, x0, #0x18
    30f8:      	st1.s	{ v1 }[2], [x2]
    30fc:      	tbz	w10, #0x7, 0x108 <ltmp0+0x108>
    3100:      	add	x10, x0, #0x1c
    3104:      	st1.s	{ v1 }[3], [x10]
    3108:      	b	0x108 <ltmp0+0x108>
    310c:      	ldr	x9, [sp, #0x8]
    3110:      	stp	w19, w7, [x9]
    3114:      	str	w4, [x9, #0x8]
    3118:      	mov	w8, #0x18               ; =24
    311c:      	str	w8, [x9, #0x24]
    3120:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
    3124:      	add	sp, sp, #0xa0
    3128:      	ldp	x29, x30, [sp, #0x90]
    312c:      	ldp	x20, x19, [sp, #0x80]
    3130:      	ldp	x22, x21, [sp, #0x70]
    3134:      	ldp	x24, x23, [sp, #0x60]
    3138:      	ldp	x26, x25, [sp, #0x50]
    313c:      	ldp	x28, x27, [sp, #0x40]
    3140:      	ldp	d9, d8, [sp, #0x30]
    3144:      	ldp	d11, d10, [sp, #0x20]
    3148:      	ldp	d13, d12, [sp, #0x10]
    314c:      	ldp	d15, d14, [sp], #0xa0
    3150:      	ret

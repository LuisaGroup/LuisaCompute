
/private/tmp/luisa-packet-inline.UY1lIE/capture/gelu_residual-257x1538/on/object/tile_xir_w8_36456_1788935104762290_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      2c:      	sub	sp, sp, #0x410
      30:      	str	x0, [sp, #0x18]
      34:      	str	w3, [sp, #0x38]
      38:      	cbz	w3, 0x339c <ltmp0+0x339c>
      3c:      	mov	w16, #0x0               ; =0
      40:      	ldp	w9, w8, [x2, #0x2c]
      44:      	stp	w8, w9, [sp, #0x30]
      48:      	mov	w1, #0x1808             ; =6152
      4c:      	mov	w11, #0x2713            ; =10003
      50:      	movk	w11, #0x3d37, lsl #16
      54:      	ldp	w8, w9, [x2]
      58:      	mov	w12, #0x422a            ; =16938
      5c:      	movk	w12, #0x3f4c, lsl #16
      60:      	fmov.4s	v13, #1.00000000
      64:      	mov	w13, #0x9231            ; =37425
      68:      	movk	w13, #0x2f30, lsl #16
      6c:      	mov	w14, #0x322b            ; =12843
      70:      	movk	w14, #0x32d7, lsl #16
      74:      	ldp	w10, w15, [x2, #0x8]
      78:      	str	x2, [sp, #0x10]
      7c:      	str	x15, [sp, #0x28]
      80:      	mov	w15, #0xef1d            ; =61213
      84:      	movk	w15, #0x3638, lsl #16
      88:      	dup.4s	v21, w11
      8c:      	mov	w11, #0xd01             ; =3329
      90:      	movk	w11, #0x3950, lsl #16
      94:      	dup.4s	v8, w12
      98:      	mov	w12, #0x8889            ; =34953
      9c:      	movk	w12, #0x3c08, lsl #16
      a0:      	dup.4s	v23, w13
      a4:      	mov	w13, #0xaaab            ; =43691
      a8:      	movk	w13, #0x3e2a, lsl #16
      ac:      	dup.4s	v19, w14
      b0:      	mov	w14, #0x76c7            ; =30407
      b4:      	movk	w14, #0x310f, lsl #16
      b8:      	dup.4s	v14, w15
      bc:      	mov	w15, #0xf27e            ; =62078
      c0:      	movk	w15, #0x3493, lsl #16
      c4:      	dup.4s	v9, w11
      c8:      	mov	w11, #0xd01             ; =3329
      cc:      	movk	w11, #0x37d0, lsl #16
      d0:      	dup.4s	v30, w12
      d4:      	mov	w12, #0xb61             ; =2913
      d8:      	movk	w12, #0x3ab6, lsl #16
      dc:      	dup.4s	v31, w13
      e0:      	mov	w13, #0xaaab            ; =43691
      e4:      	movk	w13, #0x3d2a, lsl #16
      e8:      	dup.4s	v27, w14
      ec:      	fmov.4s	v28, #9.00000000
      f0:      	dup.4s	v20, w15
      f4:      	mov	w14, #-0x3d300000       ; =-1026555904
      f8:      	dup.4s	v29, w11
      fc:      	mov	w11, #0x42c80000        ; =1120403456
     100:      	dup.4s	v25, w12
     104:      	mov	w12, #0xaa3b            ; =43579
     108:      	movk	w12, #0x3fb8, lsl #16
     10c:      	dup.4s	v26, w13
     110:      	dup.4s	v1, w14
     114:      	dup.4s	v0, w11
     118:      	str	q0, [sp, #0xd0]
     11c:      	mov	w11, #0x7200            ; =29184
     120:      	movk	w11, #0xbf31, lsl #16
     124:      	dup.4s	v0, w12
     128:      	stp	q0, q1, [sp, #0x230]
     12c:      	mov	w12, #0xbe8e            ; =48782
     130:      	movk	w12, #0xb5bf, lsl #16
     134:      	dup.4s	v15, w11
     138:      	mov	w11, #0x2bda            ; =11226
     13c:      	movk	w11, #0x3950, lsl #16
     140:      	dup.4s	v1, w12
     144:      	mov	w12, #0x96c9            ; =38601
     148:      	movk	w12, #0x3ab6, lsl #16
     14c:      	dup.4s	v11, w11
     150:      	mov	w11, #0x88a6            ; =34982
     154:      	movk	w11, #0x3c08, lsl #16
     158:      	dup.4s	v10, w12
     15c:      	mov	w12, #0xaa7a            ; =43642
     160:      	movk	w12, #0x3d2a, lsl #16
     164:      	dup.4s	v0, w11
     168:      	stp	q0, q1, [sp, #0x210]
     16c:      	add	x23, sp, #0x1, lsl #12  ; =0x1000
     170:      	add	x23, x23, #0xbf0
     174:      	add	x24, sp, #0x3d0
     178:      	dup.4s	v0, w12
     17c:      	stp	q11, q0, [sp, #0x1d0]
     180:      	mvni.4s	v0, #0x7f, msl #16
     184:      	fneg.4s	v22, v0
     188:      	mvni.4s	v0, #0x3f, msl #16
     18c:      	fneg.4s	v18, v0
     190:      	stp	q13, q14, [sp, #0xe0]
     194:      	stp	q21, q23, [sp, #0xb0]
     198:      	stp	q8, q9, [sp, #0x100]
     19c:      	stp	q30, q19, [sp, #0x130]
     1a0:      	str	q31, [sp, #0x120]
     1a4:      	stp	q28, q27, [sp, #0x170]
     1a8:      	str	q20, [sp, #0x250]
     1ac:      	stp	q25, q29, [sp, #0x1a0]
     1b0:      	str	q26, [sp, #0x190]
     1b4:      	stp	q10, q15, [sp, #0x1f0]
     1b8:      	stp	q18, q22, [sp, #0x150]
     1bc:      	b	0x210 <ltmp0+0x210>
     1c0:      	add	x8, x8, #0x1c
     1c4:      	st1.s	{ v0 }[3], [x8]
     1c8:      	ldr	x14, [sp, #0x48]
     1cc:      	add	w8, w14, #0x1
     1d0:      	ldp	w11, w9, [sp, #0x30]
     1d4:      	cmp	w8, w9
     1d8:      	cset	w9, eq
     1dc:      	csinc	w8, wzr, w14, eq
     1e0:      	ldp	w13, w12, [sp, #0x3c]
     1e4:      	cinc	w10, w13, eq
     1e8:      	cmp	w10, w11
     1ec:      	cset	w11, eq
     1f0:      	ands	w11, w9, w11
     1f4:      	csel	w9, wzr, w10, ne
     1f8:      	add	w10, w12, w11
     1fc:      	ldr	w16, [sp, #0x44]
     200:      	add	w16, w16, #0x1
     204:      	ldr	w11, [sp, #0x38]
     208:      	cmp	w16, w11
     20c:      	b.eq	0x3388 <ltmp0+0x3388>
     210:      	mov	x13, x10
     214:      	mov	x14, x9
     218:      	mov	x15, x8
     21c:      	ubfiz	x8, x8, #5, #32
     220:      	ldr	x12, [sp, #0x28]
     224:      	cmp	x8, x12
     228:      	csel	x9, x8, xzr, ls
     22c:      	subs	x10, x12, x9
     230:      	cmp	x10, #0x20
     234:      	mov	w11, #0x20              ; =32
     238:      	csel	x10, x10, x11, lo
     23c:      	cmp	x12, x9
     240:      	ccmp	x8, x12, #0x2, hi
     244:      	csel	x8, x10, xzr, ls
     248:      	fmov.4s	v0, #0.25000000
     24c:      	str	q0, [sp, #0x1c0]
     250:      	cmp	x8, #0x20
     254:      	stp	w13, w16, [sp, #0x40]
     258:      	str	w14, [sp, #0x3c]
     25c:      	str	x15, [sp, #0x48]
     260:      	b.lo	0xe20 <ltmp0+0xe20>
     264:      	mov	x21, #0x0               ; =0
     268:      	ldr	x8, [sp, #0x18]
     26c:      	ldr	x13, [x8]
     270:      	ldr	x25, [x8, #0x10]
     274:      	ldr	x12, [x8, #0x30]
     278:      	subs	x8, x13, x12
     27c:      	mov	w11, #0x2007            ; =8199
     280:      	movk	w11, #0x18, lsl #16
     284:      	ccmp	x8, x11, #0x0, hs
     288:      	cset	w8, hi
     28c:      	subs	x9, x12, x13
     290:      	ccmp	x9, x11, #0x0, hs
     294:      	csinc	w8, w8, wzr, ls
     298:      	subs	x9, x25, x12
     29c:      	ccmp	x9, x11, #0x0, hs
     2a0:      	cset	w9, hi
     2a4:      	subs	x10, x12, x25
     2a8:      	ccmp	x10, x11, #0x0, hs
     2ac:      	csinc	w9, w9, wzr, ls
     2b0:      	and	w11, w8, w9
     2b4:      	lsl	w14, w15, #2
     2b8:      	and	x8, x15, #0x7ffffff
     2bc:      	mov	w9, #0x6020             ; =24608
     2c0:      	umaddl	x26, w8, w9, x12
     2c4:      	umaddl	x28, w8, w9, x25
     2c8:      	str	x13, [sp, #0xa0]
     2cc:      	umaddl	x22, w8, w9, x13
     2d0:      	str	x12, [sp, #0x60]
     2d4:      	str	w11, [sp, #0x58]
     2d8:      	str	x14, [sp, #0x50]
     2dc:      	b	0x4c8 <ltmp0+0x4c8>
     2e0:      	movi.2d	v1, #0000000000000000
     2e4:      	ldr	q0, [sp, #0x70]
     2e8:      	mov.d	v1[0], v0[0]
     2ec:      	fmul.4s	v2, v1, v21
     2f0:      	fmul.4s	v2, v0, v2
     2f4:      	fmul.4s	v2, v0, v2
     2f8:      	fadd.4s	v2, v0, v2
     2fc:      	fmul.4s	v3, v2, v8
     300:      	movi.2d	v2, #0000000000000000
     304:      	mov.d	v2[0], v3[0]
     308:      	fabs.4s	v3, v2
     30c:      	fmul.4s	v4, v2, v2
     310:      	mov.16b	v5, v19
     314:      	fmla.4s	v5, v4, v23
     318:      	mov.16b	v6, v14
     31c:      	fmla.4s	v6, v4, v5
     320:      	mov.16b	v5, v9
     324:      	fmla.4s	v5, v4, v6
     328:      	mov.16b	v6, v30
     32c:      	fmla.4s	v6, v4, v5
     330:      	mov.16b	v5, v31
     334:      	fmla.4s	v5, v4, v6
     338:      	mov.16b	v6, v13
     33c:      	fmla.4s	v6, v4, v5
     340:      	fmul.4s	v5, v3, v6
     344:      	ldr	q20, [sp, #0x250]
     348:      	mov.16b	v6, v20
     34c:      	ldp	q27, q26, [sp, #0x180]
     350:      	fmla.4s	v6, v4, v27
     354:      	ldp	q25, q0, [sp, #0x1a0]
     358:      	mov.16b	v7, v0
     35c:      	fmla.4s	v7, v4, v6
     360:      	mov.16b	v6, v25
     364:      	fmla.4s	v6, v4, v7
     368:      	mov.16b	v7, v26
     36c:      	fmla.4s	v7, v4, v6
     370:      	movi.4s	v6, #0x3f, lsl #24
     374:      	fmla.4s	v6, v4, v7
     378:      	mov.16b	v7, v13
     37c:      	fmla.4s	v7, v4, v6
     380:      	fdiv.4s	v4, v5, v7
     384:      	ldr	q28, [sp, #0x170]
     388:      	fcmge.4s	v5, v28, v3
     38c:      	and.16b	v6, v5, v3
     390:      	ldr	q7, [sp, #0x240]
     394:      	fcmge.4s	v7, v6, v7
     398:      	fcmge.4s	v16, v15, v6
     39c:      	and.16b	v7, v7, v16
     3a0:      	and.16b	v7, v7, v6
     3a4:      	ldr	q16, [sp, #0x230]
     3a8:      	fmul.4s	v16, v7, v16
     3ac:      	movi.4s	v17, #0x4b, lsl #24
     3b0:      	fadd.4s	v16, v16, v17
     3b4:      	movi.4s	v17, #0xcb, lsl #24
     3b8:      	fadd.4s	v16, v16, v17
     3bc:      	fcvtzs.4s	v16, v16
     3c0:      	scvtf.4s	v17, v16
     3c4:      	ldr	q10, [sp, #0x200]
     3c8:      	fmul.4s	v18, v17, v10
     3cc:      	fadd.4s	v7, v7, v18
     3d0:      	ldr	q18, [sp, #0x220]
     3d4:      	fmul.4s	v17, v17, v18
     3d8:      	fadd.4s	v7, v7, v17
     3dc:      	ldr	q11, [sp, #0x1d0]
     3e0:      	fmul.4s	v17, v7, v11
     3e4:      	ldr	q18, [sp, #0x1f0]
     3e8:      	fadd.4s	v17, v17, v18
     3ec:      	fmul.4s	v17, v7, v17
     3f0:      	ldr	q18, [sp, #0x210]
     3f4:      	fadd.4s	v17, v17, v18
     3f8:      	fmul.4s	v17, v7, v17
     3fc:      	ldr	q18, [sp, #0x1e0]
     400:      	fadd.4s	v17, v17, v18
     404:      	fmul.4s	v17, v7, v17
     408:      	fadd.4s	v17, v17, v31
     40c:      	fmul.4s	v17, v7, v17
     410:      	fadd.4s	v17, v17, v29
     414:      	fmul.4s	v18, v7, v7
     418:      	fmul.4s	v17, v18, v17
     41c:      	fadd.4s	v7, v7, v17
     420:      	fadd.4s	v7, v7, v13
     424:      	add.4s	v16, v16, v12
     428:      	sshr.4s	v17, v16, #0x1
     42c:      	shl.4s	v18, v17, #0x17
     430:      	add.4s	v18, v18, v13
     434:      	fmul.4s	v7, v7, v18
     438:      	sub.4s	v16, v16, v17
     43c:      	shl.4s	v16, v16, #0x17
     440:      	add.4s	v16, v16, v13
     444:      	fmul.4s	v7, v7, v16
     448:      	fcmgt.4s	v6, v6, v15
     44c:      	ldp	q18, q22, [sp, #0x150]
     450:      	bsl.16b	v6, v22, v7
     454:      	ldr	q7, [sp, #0x1c0]
     458:      	fdiv.4s	v7, v7, v6
     45c:      	fsub.4s	v16, v6, v7
     460:      	fadd.4s	v6, v6, v7
     464:      	fdiv.4s	v6, v16, v6
     468:      	bsl.16b	v5, v6, v13
     46c:      	fcmge.4s	v3, v13, v3
     470:      	bsl.16b	v3, v4, v5
     474:      	bif.16b	v3, v2, v24
     478:      	fcmeq.4s	v2, v2, v2
     47c:      	fadd.4s	v3, v3, v13
     480:      	bsl.16b	v2, v3, v18
     484:      	fmul.4s	v1, v1, v29
     488:      	fmul.4s	v1, v1, v2
     48c:      	ldr	q3, [sp, #0x90]
     490:      	fadd.4s	v1, v3, v1
     494:      	str	q3, [sp, #0x90]
     498:      	mov	w1, #0x1808             ; =6152
     49c:      	mov.16b	v29, v0
     4a0:      	ldr	x12, [sp, #0x60]
     4a4:      	ldr	w11, [sp, #0x58]
     4a8:      	ldr	x14, [sp, #0x50]
     4ac:      	str	d1, [x12, x27]
     4b0:      	add	x21, x21, #0x1
     4b4:      	add	x26, x26, x1
     4b8:      	add	x28, x28, x1
     4bc:      	add	x22, x22, x1
     4c0:      	cmp	x21, #0x4
     4c4:      	b.eq	0x1c8 <ltmp0+0x1c8>
     4c8:      	add	w8, w21, w14
     4cc:      	and	x8, x8, #0x1fffffff
     4d0:      	umull	x19, w8, w1
     4d4:      	cbz	w11, 0xa08 <ltmp0+0xa08>
     4d8:      	mov	x8, #0x0                ; =0
     4dc:      	ldr	q15, [sp, #0xd0]
     4e0:      	mov.16b	v10, v31
     4e4:      	lsl	x9, x8, #5
     4e8:      	add	x10, x22, x9
     4ec:      	ldp	q0, q1, [x10]
     4f0:      	fmul.4s	v2, v0, v21
     4f4:      	fmul.4s	v3, v1, v21
     4f8:      	fmul.4s	v3, v1, v3
     4fc:      	fmul.4s	v2, v0, v2
     500:      	fmul.4s	v2, v0, v2
     504:      	fmul.4s	v3, v1, v3
     508:      	fadd.4s	v4, v1, v3
     50c:      	fadd.4s	v2, v0, v2
     510:      	fmul.4s	v3, v2, v8
     514:      	fmul.4s	v2, v4, v8
     518:      	fabs.4s	v5, v2
     51c:      	fabs.4s	v4, v3
     520:      	fmul.4s	v19, v3, v3
     524:      	mov.16b	v30, v21
     528:      	fmul.4s	v21, v2, v2
     52c:      	ldp	q18, q7, [sp, #0x130]
     530:      	mov.16b	v6, v7
     534:      	fmla.4s	v6, v19, v23
     538:      	fmla.4s	v7, v21, v23
     53c:      	mov.16b	v16, v14
     540:      	fmla.4s	v16, v19, v6
     544:      	mov.16b	v6, v14
     548:      	fmla.4s	v6, v21, v7
     54c:      	mov.16b	v7, v9
     550:      	fmla.4s	v7, v19, v16
     554:      	mov.16b	v16, v9
     558:      	fmla.4s	v16, v21, v6
     55c:      	mov.16b	v17, v18
     560:      	mov.16b	v22, v10
     564:      	mov.16b	v11, v9
     568:      	mov.16b	v9, v14
     56c:      	mov.16b	v14, v8
     570:      	mov.16b	v8, v23
     574:      	mov.16b	v23, v10
     578:      	mov.16b	v6, v13
     57c:      	fmla.4s	v17, v19, v7
     580:      	mov.16b	v7, v20
     584:      	fmla.4s	v7, v21, v27
     588:      	ldr	q20, [sp, #0x250]
     58c:      	fmla.4s	v20, v19, v27
     590:      	mov.16b	v24, v29
     594:      	fmla.4s	v18, v21, v16
     598:      	fmla.4s	v24, v21, v7
     59c:      	fmla.4s	v29, v19, v20
     5a0:      	mov.16b	v16, v25
     5a4:      	fmla.4s	v16, v21, v24
     5a8:      	fmla.4s	v22, v19, v17
     5ac:      	mov.16b	v17, v25
     5b0:      	fmla.4s	v17, v19, v29
     5b4:      	mov.16b	v20, v26
     5b8:      	fmla.4s	v20, v21, v16
     5bc:      	mov.16b	v24, v26
     5c0:      	fmla.4s	v23, v21, v18
     5c4:      	fmla.4s	v24, v19, v17
     5c8:      	movi.4s	v25, #0x3f, lsl #24
     5cc:      	movi.4s	v26, #0x3f, lsl #24
     5d0:      	mov.16b	v17, v13
     5d4:      	fcmge.4s	v7, v28, v4
     5d8:      	fmla.4s	v25, v21, v20
     5dc:      	fcmge.4s	v16, v28, v5
     5e0:      	and.16b	v18, v16, v5
     5e4:      	and.16b	v20, v7, v4
     5e8:      	ldr	q28, [sp, #0x240]
     5ec:      	fcmge.4s	v27, v20, v28
     5f0:      	fcmge.4s	v28, v18, v28
     5f4:      	fcmge.4s	v29, v15, v18
     5f8:      	and.16b	v28, v28, v29
     5fc:      	fcmge.4s	v29, v15, v20
     600:      	and.16b	v27, v27, v29
     604:      	and.16b	v27, v27, v20
     608:      	and.16b	v28, v28, v18
     60c:      	fmla.4s	v6, v21, v23
     610:      	ldr	q29, [sp, #0x230]
     614:      	fmul.4s	v23, v28, v29
     618:      	fmul.4s	v29, v27, v29
     61c:      	movi.4s	v31, #0x4b, lsl #24
     620:      	fadd.4s	v29, v29, v31
     624:      	fadd.4s	v23, v23, v31
     628:      	movi.4s	v31, #0xcb, lsl #24
     62c:      	fadd.4s	v23, v23, v31
     630:      	fmla.4s	v17, v21, v25
     634:      	fadd.4s	v21, v29, v31
     638:      	fcvtzs.4s	v21, v21
     63c:      	fcvtzs.4s	v23, v23
     640:      	scvtf.4s	v25, v23
     644:      	scvtf.4s	v29, v21
     648:      	fmla.4s	v26, v19, v24
     64c:      	ldr	q31, [sp, #0x200]
     650:      	fmul.4s	v24, v25, v31
     654:      	fadd.4s	v24, v28, v24
     658:      	fmul.4s	v28, v29, v31
     65c:      	fadd.4s	v27, v27, v28
     660:      	mov.16b	v28, v13
     664:      	fmla.4s	v28, v19, v22
     668:      	ldr	q31, [sp, #0x220]
     66c:      	fmul.4s	v22, v29, v31
     670:      	ldr	q29, [sp, #0x1b0]
     674:      	fadd.4s	v22, v27, v22
     678:      	fmul.4s	v25, v25, v31
     67c:      	fadd.4s	v24, v24, v25
     680:      	mov.16b	v25, v13
     684:      	fmla.4s	v25, v19, v26
     688:      	ldr	q26, [sp, #0x1d0]
     68c:      	fmul.4s	v19, v24, v26
     690:      	fmul.4s	v26, v22, v26
     694:      	ldr	q27, [sp, #0x1f0]
     698:      	fadd.4s	v26, v26, v27
     69c:      	fadd.4s	v19, v19, v27
     6a0:      	fmul.4s	v19, v24, v19
     6a4:      	fmul.4s	v27, v4, v28
     6a8:      	fmul.4s	v26, v22, v26
     6ac:      	ldr	q28, [sp, #0x210]
     6b0:      	fadd.4s	v26, v26, v28
     6b4:      	fadd.4s	v19, v19, v28
     6b8:      	fmul.4s	v19, v24, v19
     6bc:      	fmul.4s	v26, v22, v26
     6c0:      	ldr	q28, [sp, #0x1e0]
     6c4:      	fadd.4s	v26, v26, v28
     6c8:      	fadd.4s	v19, v19, v28
     6cc:      	fmul.4s	v19, v24, v19
     6d0:      	fmul.4s	v26, v22, v26
     6d4:      	fadd.4s	v26, v26, v10
     6d8:      	fadd.4s	v28, v19, v10
     6dc:      	fdiv.4s	v19, v27, v25
     6e0:      	fmul.4s	v25, v24, v28
     6e4:      	fmul.4s	v26, v22, v26
     6e8:      	movi.4s	v31, #0x3f, lsl #24
     6ec:      	fadd.4s	v26, v26, v31
     6f0:      	fadd.4s	v25, v25, v31
     6f4:      	fmul.4s	v27, v24, v24
     6f8:      	fmul.4s	v25, v27, v25
     6fc:      	fmul.4s	v27, v22, v22
     700:      	fmul.4s	v26, v27, v26
     704:      	ldp	q12, q27, [sp, #0x170]
     708:      	fadd.4s	v22, v22, v26
     70c:      	fadd.4s	v24, v24, v25
     710:      	movi.2d	v28, #0xffffffffffffffff
     714:      	add.4s	v21, v21, v28
     718:      	fadd.4s	v22, v22, v13
     71c:      	sshr.4s	v25, v21, #0x1
     720:      	shl.4s	v26, v25, #0x17
     724:      	add.4s	v26, v26, v13
     728:      	fmul.4s	v22, v22, v26
     72c:      	add.4s	v23, v23, v28
     730:      	mov.16b	v28, v12
     734:      	fadd.4s	v24, v24, v13
     738:      	sub.4s	v21, v21, v25
     73c:      	sshr.4s	v25, v23, #0x1
     740:      	sub.4s	v23, v23, v25
     744:      	shl.4s	v25, v25, #0x17
     748:      	add.4s	v25, v25, v13
     74c:      	fmul.4s	v24, v24, v25
     750:      	ldp	q26, q25, [sp, #0x190]
     754:      	shl.4s	v23, v23, #0x17
     758:      	add.4s	v23, v23, v13
     75c:      	fmul.4s	v23, v24, v23
     760:      	mvni.4s	v24, #0x80, lsl #24
     764:      	shl.4s	v21, v21, #0x17
     768:      	add.4s	v21, v21, v13
     76c:      	fmul.4s	v21, v22, v21
     770:      	ldr	q22, [sp, #0x160]
     774:      	fcmgt.4s	v20, v20, v15
     778:      	bsl.16b	v20, v22, v21
     77c:      	fmul.4s	v6, v5, v6
     780:      	fcmgt.4s	v18, v18, v15
     784:      	bsl.16b	v18, v22, v23
     788:      	mov.16b	v23, v8
     78c:      	mov.16b	v8, v14
     790:      	mov.16b	v14, v9
     794:      	mov.16b	v9, v11
     798:      	fdiv.4s	v6, v6, v17
     79c:      	ldr	q11, [sp, #0x1c0]
     7a0:      	fdiv.4s	v17, v11, v18
     7a4:      	fsub.4s	v21, v18, v17
     7a8:      	fadd.4s	v17, v18, v17
     7ac:      	ldr	q18, [sp, #0x150]
     7b0:      	fdiv.4s	v17, v21, v17
     7b4:      	mov.16b	v21, v30
     7b8:      	bsl.16b	v16, v17, v13
     7bc:      	fcmge.4s	v5, v13, v5
     7c0:      	bsl.16b	v5, v6, v16
     7c4:      	fdiv.4s	v6, v11, v20
     7c8:      	fsub.4s	v16, v20, v6
     7cc:      	fadd.4s	v6, v20, v6
     7d0:      	ldr	q20, [sp, #0x250]
     7d4:      	fdiv.4s	v6, v16, v6
     7d8:      	bif.16b	v6, v13, v7
     7dc:      	fcmge.4s	v4, v13, v4
     7e0:      	bsl.16b	v4, v19, v6
     7e4:      	bif.16b	v4, v3, v24
     7e8:      	fcmeq.4s	v3, v3, v3
     7ec:      	fadd.4s	v4, v4, v13
     7f0:      	bsl.16b	v3, v4, v18
     7f4:      	mov.16b	v4, v24
     7f8:      	bsl.16b	v4, v5, v2
     7fc:      	fcmeq.4s	v2, v2, v2
     800:      	fadd.4s	v4, v4, v13
     804:      	bsl.16b	v2, v4, v18
     808:      	fmul.4s	v1, v1, v31
     80c:      	fmul.4s	v1, v1, v2
     810:      	fmul.4s	v0, v0, v31
     814:      	fmul.4s	v0, v0, v3
     818:      	add	x10, x28, x9
     81c:      	ldp	q3, q2, [x10]
     820:      	fadd.4s	v0, v3, v0
     824:      	fadd.4s	v1, v2, v1
     828:      	add	x9, x26, x9
     82c:      	stp	q0, q1, [x9]
     830:      	add	x8, x8, #0x1
     834:      	cmp	x8, #0xc0
     838:      	b.ne	0x4e4 <ltmp0+0x4e4>
     83c:      	mov	w8, #0x1800             ; =6144
     840:      	add	x27, x19, x8
     844:      	ldr	x8, [sp, #0xa0]
     848:      	add	x8, x8, x27
     84c:      	movi.2d	v0, #0000000000000000
     850:      	ld1.s	{ v0 }[0], [x8], #4
     854:      	ld1.s	{ v0 }[1], [x8]
     858:      	fmul.4s	v1, v0, v21
     85c:      	fmul.4s	v1, v0, v1
     860:      	fmul.4s	v1, v0, v1
     864:      	fadd.4s	v1, v0, v1
     868:      	fmul.4s	v2, v1, v8
     86c:      	movi.2d	v1, #0000000000000000
     870:      	mov.d	v1[0], v2[0]
     874:      	fabs.4s	v2, v1
     878:      	fmul.4s	v3, v1, v1
     87c:      	ldp	q30, q4, [sp, #0x130]
     880:      	fmla.4s	v4, v3, v23
     884:      	mov.16b	v5, v14
     888:      	fmla.4s	v5, v3, v4
     88c:      	mov.16b	v4, v9
     890:      	fmla.4s	v4, v3, v5
     894:      	mov.16b	v5, v30
     898:      	fmla.4s	v5, v3, v4
     89c:      	mov.16b	v4, v10
     8a0:      	fmla.4s	v4, v3, v5
     8a4:      	mov.16b	v5, v13
     8a8:      	fmla.4s	v5, v3, v4
     8ac:      	fmul.4s	v4, v2, v5
     8b0:      	mov.16b	v5, v20
     8b4:      	fmla.4s	v5, v3, v27
     8b8:      	mov.16b	v6, v29
     8bc:      	fmla.4s	v6, v3, v5
     8c0:      	mov.16b	v5, v25
     8c4:      	fmla.4s	v5, v3, v6
     8c8:      	mov.16b	v6, v26
     8cc:      	fmla.4s	v6, v3, v5
     8d0:      	movi.4s	v5, #0x3f, lsl #24
     8d4:      	fmla.4s	v5, v3, v6
     8d8:      	mov.16b	v6, v13
     8dc:      	fmla.4s	v6, v3, v5
     8e0:      	fdiv.4s	v3, v4, v6
     8e4:      	fcmge.4s	v4, v28, v2
     8e8:      	and.16b	v5, v4, v2
     8ec:      	ldr	q6, [sp, #0x240]
     8f0:      	fcmge.4s	v6, v5, v6
     8f4:      	fcmge.4s	v7, v15, v5
     8f8:      	and.16b	v6, v6, v7
     8fc:      	and.16b	v6, v6, v5
     900:      	ldr	q7, [sp, #0x230]
     904:      	fmul.4s	v7, v6, v7
     908:      	movi.4s	v16, #0x4b, lsl #24
     90c:      	fadd.4s	v7, v7, v16
     910:      	movi.4s	v16, #0xcb, lsl #24
     914:      	fadd.4s	v7, v7, v16
     918:      	fcvtzs.4s	v7, v7
     91c:      	scvtf.4s	v16, v7
     920:      	ldr	q19, [sp, #0x200]
     924:      	fmul.4s	v17, v16, v19
     928:      	fadd.4s	v6, v6, v17
     92c:      	ldr	q17, [sp, #0x220]
     930:      	fmul.4s	v16, v16, v17
     934:      	fadd.4s	v6, v6, v16
     938:      	ldr	q11, [sp, #0x1d0]
     93c:      	fmul.4s	v16, v6, v11
     940:      	ldr	q17, [sp, #0x1f0]
     944:      	fadd.4s	v16, v16, v17
     948:      	fmul.4s	v16, v6, v16
     94c:      	ldr	q17, [sp, #0x210]
     950:      	fadd.4s	v16, v16, v17
     954:      	fmul.4s	v16, v6, v16
     958:      	ldr	q17, [sp, #0x1e0]
     95c:      	fadd.4s	v16, v16, v17
     960:      	fmul.4s	v16, v6, v16
     964:      	fadd.4s	v16, v16, v10
     968:      	fmul.4s	v16, v6, v16
     96c:      	movi.4s	v12, #0x3f, lsl #24
     970:      	fadd.4s	v16, v16, v12
     974:      	fmul.4s	v17, v6, v6
     978:      	fmul.4s	v16, v17, v16
     97c:      	fadd.4s	v6, v6, v16
     980:      	fadd.4s	v6, v6, v13
     984:      	movi.2d	v16, #0xffffffffffffffff
     988:      	add.4s	v7, v7, v16
     98c:      	sshr.4s	v16, v7, #0x1
     990:      	shl.4s	v17, v16, #0x17
     994:      	add.4s	v17, v17, v13
     998:      	fmul.4s	v6, v6, v17
     99c:      	sub.4s	v7, v7, v16
     9a0:      	shl.4s	v7, v7, #0x17
     9a4:      	add.4s	v7, v7, v13
     9a8:      	fmul.4s	v6, v6, v7
     9ac:      	fcmgt.4s	v5, v5, v15
     9b0:      	bsl.16b	v5, v22, v6
     9b4:      	ldr	q6, [sp, #0x1c0]
     9b8:      	fdiv.4s	v6, v6, v5
     9bc:      	fsub.4s	v7, v5, v6
     9c0:      	fadd.4s	v5, v5, v6
     9c4:      	fdiv.4s	v5, v7, v5
     9c8:      	bsl.16b	v4, v5, v13
     9cc:      	fcmge.4s	v2, v13, v2
     9d0:      	bsl.16b	v2, v3, v4
     9d4:      	bif.16b	v2, v1, v24
     9d8:      	fcmeq.4s	v1, v1, v1
     9dc:      	fadd.4s	v2, v2, v13
     9e0:      	bsl.16b	v1, v2, v18
     9e4:      	fmul.4s	v0, v0, v12
     9e8:      	fmul.4s	v0, v0, v1
     9ec:      	add	x8, x25, x27
     9f0:      	add	x9, x8, #0x4
     9f4:      	ldr	s1, [x8]
     9f8:      	ld1.s	{ v1 }[1], [x9]
     9fc:      	fadd.4s	v1, v1, v0
     a00:      	mov.16b	v31, v10
     a04:      	b	0x4ac <ltmp0+0x4ac>
     a08:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     a0c:      	add	x0, x0, #0xbf0
     a10:      	ldr	x20, [sp, #0xa0]
     a14:      	add	x1, x20, x19
     a18:      	mov	w2, #0x1800             ; =6144
     a1c:      	bl	0xa1c <ltmp0+0xa1c>
     a20:      	mov	w8, #0x1800             ; =6144
     a24:      	add	x27, x19, x8
     a28:      	add	x8, x20, x27
     a2c:      	add	x9, x8, #0x4
     a30:      	ldr	s1, [x8]
     a34:      	ld1.s	{ v1 }[1], [x9]
     a38:      	str	q1, [sp, #0x70]
     a3c:      	ldr	q0, [sp, #0x80]
     a40:      	mov.d	v1[1], v0[1]
     a44:      	str	q0, [sp, #0x3400]
     a48:      	str	q1, [sp, #0x80]
     a4c:      	str	q1, [sp, #0x33f0]
     a50:      	add	x0, sp, #0x3d0
     a54:      	add	x1, x25, x19
     a58:      	mov	w2, #0x1800             ; =6144
     a5c:      	bl	0xa5c <ltmp0+0xa5c>
     a60:      	ldp	q31, q30, [sp, #0x120]
     a64:      	ldp	q8, q9, [sp, #0x100]
     a68:      	ldp	q13, q14, [sp, #0xe0]
     a6c:      	ldr	q19, [sp, #0x140]
     a70:      	ldp	q21, q23, [sp, #0xb0]
     a74:      	mov	x8, #0x0                ; =0
     a78:      	add	x9, x25, x27
     a7c:      	add	x10, x9, #0x4
     a80:      	ldr	s1, [x9]
     a84:      	ld1.s	{ v1 }[1], [x10]
     a88:      	ldr	q0, [sp, #0x90]
     a8c:      	mov.d	v1[1], v0[1]
     a90:      	str	q0, [sp, #0x1be0]
     a94:      	str	q1, [sp, #0x90]
     a98:      	str	q1, [sp, #0x1bd0]
     a9c:      	ldr	q15, [sp, #0xd0]
     aa0:      	lsl	x9, x8, #5
     aa4:      	add	x10, x23, x9
     aa8:      	ldp	q1, q2, [x10]
     aac:      	fmul.4s	v3, v1, v21
     ab0:      	fmul.4s	v4, v2, v21
     ab4:      	fmul.4s	v4, v2, v4
     ab8:      	fmul.4s	v3, v1, v3
     abc:      	fmul.4s	v3, v1, v3
     ac0:      	fmul.4s	v4, v2, v4
     ac4:      	fadd.4s	v5, v2, v4
     ac8:      	fadd.4s	v3, v1, v3
     acc:      	fmul.4s	v4, v3, v8
     ad0:      	fmul.4s	v3, v5, v8
     ad4:      	fabs.4s	v6, v3
     ad8:      	fabs.4s	v5, v4
     adc:      	fmul.4s	v20, v4, v4
     ae0:      	fmul.4s	v22, v3, v3
     ae4:      	mov.16b	v7, v19
     ae8:      	fmla.4s	v7, v20, v23
     aec:      	mov.16b	v16, v19
     af0:      	fmla.4s	v16, v22, v23
     af4:      	mov.16b	v17, v14
     af8:      	fmla.4s	v17, v20, v7
     afc:      	mov.16b	v7, v14
     b00:      	fmla.4s	v7, v22, v16
     b04:      	mov.16b	v16, v9
     b08:      	fmla.4s	v16, v20, v17
     b0c:      	mov.16b	v17, v9
     b10:      	fmla.4s	v17, v22, v7
     b14:      	mov.16b	v18, v30
     b18:      	mov.16b	v10, v9
     b1c:      	mov.16b	v9, v8
     b20:      	mov.16b	v8, v19
     b24:      	mov.16b	v19, v30
     b28:      	mov.16b	v0, v14
     b2c:      	mov.16b	v14, v23
     b30:      	mov.16b	v23, v31
     b34:      	mov.16b	v24, v31
     b38:      	mov.16b	v7, v13
     b3c:      	fmla.4s	v18, v20, v16
     b40:      	ldr	q26, [sp, #0x250]
     b44:      	mov.16b	v16, v26
     b48:      	ldr	q25, [sp, #0x180]
     b4c:      	fmla.4s	v16, v22, v25
     b50:      	mov.16b	v11, v21
     b54:      	mov.16b	v21, v26
     b58:      	fmla.4s	v21, v20, v25
     b5c:      	ldr	q26, [sp, #0x1b0]
     b60:      	mov.16b	v25, v26
     b64:      	fmla.4s	v19, v22, v17
     b68:      	fmla.4s	v25, v22, v16
     b6c:      	mov.16b	v16, v26
     b70:      	fmla.4s	v16, v20, v21
     b74:      	ldr	q21, [sp, #0x1a0]
     b78:      	mov.16b	v17, v21
     b7c:      	fmla.4s	v17, v22, v25
     b80:      	fmla.4s	v23, v20, v18
     b84:      	mov.16b	v18, v21
     b88:      	fmla.4s	v18, v20, v16
     b8c:      	ldr	q25, [sp, #0x190]
     b90:      	mov.16b	v21, v25
     b94:      	fmla.4s	v21, v22, v17
     b98:      	fmla.4s	v24, v22, v19
     b9c:      	fmla.4s	v25, v20, v18
     ba0:      	movi.4s	v26, #0x3f, lsl #24
     ba4:      	movi.4s	v27, #0x3f, lsl #24
     ba8:      	mov.16b	v18, v13
     bac:      	ldr	q17, [sp, #0x170]
     bb0:      	fcmge.4s	v16, v17, v5
     bb4:      	fmla.4s	v26, v22, v21
     bb8:      	fcmge.4s	v17, v17, v6
     bbc:      	and.16b	v19, v17, v6
     bc0:      	and.16b	v21, v16, v5
     bc4:      	ldr	q29, [sp, #0x240]
     bc8:      	fcmge.4s	v28, v21, v29
     bcc:      	fcmge.4s	v29, v19, v29
     bd0:      	mov.16b	v31, v30
     bd4:      	fcmge.4s	v30, v15, v19
     bd8:      	and.16b	v29, v29, v30
     bdc:      	fcmge.4s	v30, v15, v21
     be0:      	and.16b	v28, v28, v30
     be4:      	and.16b	v28, v28, v21
     be8:      	and.16b	v29, v29, v19
     bec:      	fmla.4s	v7, v22, v24
     bf0:      	ldr	q30, [sp, #0x230]
     bf4:      	fmul.4s	v24, v29, v30
     bf8:      	fmul.4s	v30, v28, v30
     bfc:      	movi.4s	v12, #0x4b, lsl #24
     c00:      	fadd.4s	v30, v30, v12
     c04:      	fadd.4s	v24, v24, v12
     c08:      	movi.4s	v12, #0xcb, lsl #24
     c0c:      	fadd.4s	v24, v24, v12
     c10:      	fmla.4s	v18, v22, v26
     c14:      	fadd.4s	v22, v30, v12
     c18:      	fcvtzs.4s	v22, v22
     c1c:      	fcvtzs.4s	v24, v24
     c20:      	scvtf.4s	v26, v24
     c24:      	scvtf.4s	v30, v22
     c28:      	fmla.4s	v27, v20, v25
     c2c:      	ldr	q12, [sp, #0x200]
     c30:      	fmul.4s	v25, v26, v12
     c34:      	fadd.4s	v25, v29, v25
     c38:      	fmul.4s	v29, v30, v12
     c3c:      	fadd.4s	v28, v28, v29
     c40:      	mov.16b	v29, v13
     c44:      	fmla.4s	v29, v20, v23
     c48:      	ldr	q12, [sp, #0x220]
     c4c:      	fmul.4s	v23, v30, v12
     c50:      	mov.16b	v30, v31
     c54:      	ldr	q31, [sp, #0x120]
     c58:      	fadd.4s	v23, v28, v23
     c5c:      	fmul.4s	v26, v26, v12
     c60:      	fadd.4s	v25, v25, v26
     c64:      	mov.16b	v26, v13
     c68:      	fmla.4s	v26, v20, v27
     c6c:      	ldr	q27, [sp, #0x1d0]
     c70:      	fmul.4s	v20, v25, v27
     c74:      	fmul.4s	v27, v23, v27
     c78:      	ldr	q28, [sp, #0x1f0]
     c7c:      	fadd.4s	v27, v27, v28
     c80:      	fadd.4s	v20, v20, v28
     c84:      	fmul.4s	v20, v25, v20
     c88:      	fmul.4s	v28, v5, v29
     c8c:      	fmul.4s	v27, v23, v27
     c90:      	ldr	q29, [sp, #0x210]
     c94:      	fadd.4s	v27, v27, v29
     c98:      	fadd.4s	v20, v20, v29
     c9c:      	fmul.4s	v20, v25, v20
     ca0:      	fmul.4s	v27, v23, v27
     ca4:      	ldr	q29, [sp, #0x1e0]
     ca8:      	fadd.4s	v27, v27, v29
     cac:      	fadd.4s	v20, v20, v29
     cb0:      	fmul.4s	v20, v25, v20
     cb4:      	fmul.4s	v27, v23, v27
     cb8:      	fadd.4s	v27, v27, v31
     cbc:      	fadd.4s	v29, v20, v31
     cc0:      	fdiv.4s	v20, v28, v26
     cc4:      	fmul.4s	v26, v25, v29
     cc8:      	movi.4s	v29, #0x3f, lsl #24
     ccc:      	fmul.4s	v27, v23, v27
     cd0:      	fadd.4s	v27, v27, v29
     cd4:      	fadd.4s	v26, v26, v29
     cd8:      	fmul.4s	v28, v25, v25
     cdc:      	fmul.4s	v26, v28, v26
     ce0:      	fmul.4s	v28, v23, v23
     ce4:      	fmul.4s	v27, v28, v27
     ce8:      	fadd.4s	v23, v23, v27
     cec:      	fadd.4s	v25, v25, v26
     cf0:      	movi.2d	v28, #0xffffffffffffffff
     cf4:      	add.4s	v22, v22, v28
     cf8:      	fadd.4s	v23, v23, v13
     cfc:      	sshr.4s	v26, v22, #0x1
     d00:      	shl.4s	v27, v26, #0x17
     d04:      	add.4s	v27, v27, v13
     d08:      	fmul.4s	v23, v23, v27
     d0c:      	movi.2d	v12, #0xffffffffffffffff
     d10:      	add.4s	v24, v24, v28
     d14:      	fadd.4s	v25, v25, v13
     d18:      	sub.4s	v22, v22, v26
     d1c:      	sshr.4s	v26, v24, #0x1
     d20:      	sub.4s	v24, v24, v26
     d24:      	shl.4s	v26, v26, #0x17
     d28:      	add.4s	v26, v26, v13
     d2c:      	fmul.4s	v25, v25, v26
     d30:      	shl.4s	v24, v24, #0x17
     d34:      	add.4s	v24, v24, v13
     d38:      	fmul.4s	v24, v25, v24
     d3c:      	shl.4s	v22, v22, #0x17
     d40:      	add.4s	v22, v22, v13
     d44:      	fmul.4s	v22, v23, v22
     d48:      	mov.16b	v23, v14
     d4c:      	mov.16b	v14, v0
     d50:      	fcmgt.4s	v21, v21, v15
     d54:      	ldr	q0, [sp, #0x160]
     d58:      	bsl.16b	v21, v0, v22
     d5c:      	fmul.4s	v7, v6, v7
     d60:      	fcmgt.4s	v19, v19, v15
     d64:      	bsl.16b	v19, v0, v24
     d68:      	fdiv.4s	v7, v7, v18
     d6c:      	ldr	q0, [sp, #0x1c0]
     d70:      	fdiv.4s	v18, v0, v19
     d74:      	fsub.4s	v22, v19, v18
     d78:      	fadd.4s	v18, v19, v18
     d7c:      	mov.16b	v19, v8
     d80:      	mov.16b	v8, v9
     d84:      	mov.16b	v9, v10
     d88:      	fdiv.4s	v18, v22, v18
     d8c:      	bsl.16b	v17, v18, v13
     d90:      	fcmge.4s	v6, v13, v6
     d94:      	bsl.16b	v6, v7, v17
     d98:      	fdiv.4s	v7, v0, v21
     d9c:      	fsub.4s	v17, v21, v7
     da0:      	fadd.4s	v7, v21, v7
     da4:      	mov.16b	v21, v11
     da8:      	fdiv.4s	v7, v17, v7
     dac:      	bif.16b	v7, v13, v16
     db0:      	fcmge.4s	v5, v13, v5
     db4:      	bsl.16b	v5, v20, v7
     db8:      	mvni.4s	v7, #0x80, lsl #24
     dbc:      	bif.16b	v5, v4, v7
     dc0:      	fcmeq.4s	v4, v4, v4
     dc4:      	fadd.4s	v5, v5, v13
     dc8:      	ldr	q0, [sp, #0x150]
     dcc:      	bsl.16b	v4, v5, v0
     dd0:      	mvni.4s	v24, #0x80, lsl #24
     dd4:      	mov.16b	v5, v7
     dd8:      	bsl.16b	v5, v6, v3
     ddc:      	fcmeq.4s	v3, v3, v3
     de0:      	fadd.4s	v5, v5, v13
     de4:      	bsl.16b	v3, v5, v0
     de8:      	fmul.4s	v2, v2, v29
     dec:      	fmul.4s	v2, v2, v3
     df0:      	fmul.4s	v1, v1, v29
     df4:      	fmul.4s	v1, v1, v4
     df8:      	add	x10, x24, x9
     dfc:      	ldp	q0, q3, [x10]
     e00:      	fadd.4s	v1, v0, v1
     e04:      	fadd.4s	v2, v3, v2
     e08:      	add	x9, x26, x9
     e0c:      	stp	q1, q2, [x9]
     e10:      	add	x8, x8, #0x1
     e14:      	cmp	x8, #0xc0
     e18:      	b.ne	0xaa0 <ltmp0+0xaa0>
     e1c:      	b	0x2e0 <ltmp0+0x2e0>
     e20:      	lsr	x12, x8, #3
     e24:      	str	x8, [sp, #0x20]
     e28:      	cmp	x8, #0x8
     e2c:      	b.hs	0x14d4 <ltmp0+0x14d4>
     e30:      	ldr	x8, [sp, #0x20]
     e34:      	and	w8, w8, #0x7
     e38:      	cbz	w8, 0x1c8 <ltmp0+0x1c8>
     e3c:      	dup.4s	v1, w8
     e40:      	adrp	x8, 0x0 <ltmp0>
     e44:      	ldr	q2, [x8]
     e48:      	adrp	x8, 0x0 <ltmp0>
     e4c:      	ldr	q0, [x8]
     e50:      	cmhi.4s	v0, v1, v0
     e54:      	cmhi.4s	v1, v1, v2
     e58:      	uzp1.8h	v19, v1, v0
     e5c:      	umaxv.8h	h2, v19
     e60:      	fmov	w8, s2
     e64:      	tbz	w8, #0x0, 0x1c8 <ltmp0+0x1c8>
     e68:      	ldr	x8, [sp, #0x18]
     e6c:      	ldr	x11, [x8]
     e70:      	ldr	x9, [x8, #0x10]
     e74:      	ldr	x8, [x8, #0x30]
     e78:      	sshll.2d	v5, v1, #0x0
     e7c:      	sshll.2d	v3, v0, #0x0
     e80:      	sshll2.2d	v24, v1, #0x0
     e84:      	sshll2.2d	v23, v0, #0x0
     e88:      	adrp	x10, 0x0 <ltmp0>
     e8c:      	ldr	q2, [x10]
     e90:      	and.16b	v2, v23, v2
     e94:      	adrp	x10, 0x0 <ltmp0>
     e98:      	ldr	q4, [x10]
     e9c:      	and.16b	v4, v24, v4
     ea0:      	adrp	x10, 0x0 <ltmp0>
     ea4:      	ldr	q6, [x10]
     ea8:      	and.16b	v3, v3, v6
     eac:      	adrp	x10, 0x0 <ltmp0>
     eb0:      	ldr	q6, [x10]
     eb4:      	and.16b	v22, v5, v6
     eb8:      	ldr	x10, [sp, #0x48]
     ebc:      	ubfiz	w10, w10, #2, #27
     ec0:      	orr	w10, w10, w12
     ec4:      	dup.4s	v5, w10
     ec8:      	and.16b	v6, v1, v5
     ecc:      	and.16b	v5, v0, v5
     ed0:      	ushll2.2d	v7, v5, #0x0
     ed4:      	ushll2.2d	v16, v6, #0x0
     ed8:      	ushll.2d	v18, v5, #0x0
     edc:      	ushll.2d	v5, v6, #0x0
     ee0:      	subs	x10, x11, x8
     ee4:      	mov	w14, #0x2007            ; =8199
     ee8:      	movk	w14, #0x18, lsl #16
     eec:      	ccmp	x10, x14, #0x0, hs
     ef0:      	cset	w10, hi
     ef4:      	subs	x12, x8, x11
     ef8:      	ccmp	x12, x14, #0x0, hs
     efc:      	csinc	w12, w10, wzr, ls
     f00:      	subs	x10, x9, x8
     f04:      	ccmp	x10, x14, #0x0, hs
     f08:      	cset	w10, hi
     f0c:      	subs	x13, x8, x9
     f10:      	ccmp	x13, x14, #0x0, hs
     f14:      	csinc	w10, w10, wzr, ls
     f18:      	xtn.2s	v28, v5
     f1c:      	fmov	x13, d5
     f20:      	umull	x14, w13, w1
     f24:      	xtn.2s	v27, v7
     f28:      	xtn.2s	v7, v18
     f2c:      	mov	w13, #0x602             ; =1538
     f30:      	dup.2s	v6, w13
     f34:      	xtn.2s	v16, v16
     f38:      	cmp	w12, #0x1
     f3c:      	adrp	x0, 0x0 <ltmp0>
     f40:      	b.ne	0x2060 <ltmp0+0x2060>
     f44:      	cbz	w10, 0x2060 <ltmp0+0x2060>
     f48:      	str	d7, [sp, #0x80]
     f4c:      	fmov	d7, d28
     f50:      	str	d27, [sp, #0x90]
     f54:      	str	q2, [sp, #0xa0]
     f58:      	mov.16b	v11, v31
     f5c:      	mov.16b	v15, v9
     f60:      	mov.16b	v17, v14
     f64:      	mov	x10, #0x0               ; =0
     f68:      	add	x12, x8, x14
     f6c:      	add	x13, x9, x14
     f70:      	add	x14, x11, x14
     f74:      	b	0xf84 <ltmp0+0xf84>
     f78:      	add	x10, x10, #0x1
     f7c:      	cmp	x10, #0xc0
     f80:      	b.eq	0x2cc0 <ltmp0+0x2cc0>
     f84:      	ldr	q18, [x0]
     f88:      	and.16b	v18, v19, v18
     f8c:      	addv.8h	h20, v18
     f90:      	fmov	w16, s20
     f94:      	add	x15, x14, x10, lsl #5
     f98:      	movi.2d	v21, #0000000000000000
     f9c:      	movi.2d	v18, #0000000000000000
     fa0:      	tbnz	w16, #0x0, 0x13e8 <ltmp0+0x13e8>
     fa4:      	mov.16b	v31, v30
     fa8:      	and	w16, w16, #0xff
     fac:      	tbnz	w16, #0x1, 0x13f8 <ltmp0+0x13f8>
     fb0:      	mov.16b	v30, v15
     fb4:      	tbnz	w16, #0x2, 0x1408 <ltmp0+0x1408>
     fb8:      	tbnz	w16, #0x3, 0x1414 <ltmp0+0x1414>
     fbc:      	tbnz	w16, #0x4, 0x1420 <ltmp0+0x1420>
     fc0:      	tbnz	w16, #0x5, 0x142c <ltmp0+0x142c>
     fc4:      	tbnz	w16, #0x6, 0x1438 <ltmp0+0x1438>
     fc8:      	tbnz	w16, #0x7, 0x1444 <ltmp0+0x1444>
     fcc:      	fmov	w16, s20
     fd0:      	add	x15, x13, x10, lsl #5
     fd4:      	movi.2d	v24, #0000000000000000
     fd8:      	movi.2d	v23, #0000000000000000
     fdc:      	tbnz	w16, #0x0, 0x1460 <ltmp0+0x1460>
     fe0:      	and	w16, w16, #0xff
     fe4:      	tbnz	w16, #0x1, 0x146c <ltmp0+0x146c>
     fe8:      	tbnz	w16, #0x2, 0x1478 <ltmp0+0x1478>
     fec:      	tbnz	w16, #0x3, 0x1484 <ltmp0+0x1484>
     ff0:      	tbnz	w16, #0x4, 0x1490 <ltmp0+0x1490>
     ff4:      	tbnz	w16, #0x5, 0x149c <ltmp0+0x149c>
     ff8:      	tbnz	w16, #0x6, 0x14a8 <ltmp0+0x14a8>
     ffc:      	movi.2d	v15, #0xffffffffffffffff
    1000:      	tbz	w16, #0x7, 0x100c <ltmp0+0x100c>
    1004:      	add	x15, x15, #0x1c
    1008:      	ld1.s	{ v23 }[3], [x15]
    100c:      	ldp	q2, q5, [sp, #0xb0]
    1010:      	fmul.4s	v25, v21, v2
    1014:      	fmul.4s	v25, v21, v25
    1018:      	fmul.4s	v25, v21, v25
    101c:      	fadd.4s	v25, v21, v25
    1020:      	mov.16b	v14, v8
    1024:      	fmul.4s	v25, v25, v8
    1028:      	and.16b	v25, v1, v25
    102c:      	fabs.4s	v26, v25
    1030:      	fmul.4s	v27, v25, v25
    1034:      	ldr	q28, [sp, #0x140]
    1038:      	fmla.4s	v28, v27, v5
    103c:      	fmla.4s	v17, v27, v28
    1040:      	mov.16b	v28, v30
    1044:      	fmla.4s	v28, v27, v17
    1048:      	mov.16b	v29, v31
    104c:      	fmla.4s	v29, v27, v28
    1050:      	mov.16b	v28, v11
    1054:      	fmla.4s	v28, v27, v29
    1058:      	mov.16b	v29, v13
    105c:      	fmla.4s	v29, v27, v28
    1060:      	fmul.4s	v28, v26, v29
    1064:      	ldr	q29, [sp, #0x250]
    1068:      	ldr	q5, [sp, #0x180]
    106c:      	fmla.4s	v29, v27, v5
    1070:      	mov.16b	v5, v11
    1074:      	ldr	q30, [sp, #0x1b0]
    1078:      	fmla.4s	v30, v27, v29
    107c:      	ldr	q29, [sp, #0x1a0]
    1080:      	fmla.4s	v29, v27, v30
    1084:      	ldr	q30, [sp, #0x190]
    1088:      	fmla.4s	v30, v27, v29
    108c:      	movi.4s	v29, #0x3f, lsl #24
    1090:      	fmla.4s	v29, v27, v30
    1094:      	mov.16b	v30, v13
    1098:      	fmla.4s	v30, v27, v29
    109c:      	fdiv.4s	v27, v28, v30
    10a0:      	ldr	q28, [sp, #0x170]
    10a4:      	fcmge.4s	v28, v28, v26
    10a8:      	and.16b	v29, v28, v26
    10ac:      	ldr	q30, [sp, #0x240]
    10b0:      	fcmge.4s	v30, v29, v30
    10b4:      	ldr	q11, [sp, #0xd0]
    10b8:      	fcmge.4s	v31, v11, v29
    10bc:      	and.16b	v30, v30, v31
    10c0:      	and.16b	v30, v30, v29
    10c4:      	ldr	q31, [sp, #0x230]
    10c8:      	fmul.4s	v31, v30, v31
    10cc:      	movi.4s	v9, #0x4b, lsl #24
    10d0:      	fadd.4s	v31, v31, v9
    10d4:      	movi.4s	v2, #0xcb, lsl #24
    10d8:      	fadd.4s	v31, v31, v2
    10dc:      	fcvtzs.4s	v31, v31
    10e0:      	scvtf.4s	v9, v31
    10e4:      	ldp	q2, q10, [sp, #0x1f0]
    10e8:      	fmul.4s	v10, v9, v10
    10ec:      	fadd.4s	v30, v30, v10
    10f0:      	ldr	q10, [sp, #0x220]
    10f4:      	fmul.4s	v9, v9, v10
    10f8:      	fadd.4s	v30, v30, v9
    10fc:      	ldp	q8, q10, [sp, #0x1d0]
    1100:      	fmul.4s	v9, v30, v8
    1104:      	fadd.4s	v9, v9, v2
    1108:      	fmul.4s	v9, v30, v9
    110c:      	ldr	q2, [sp, #0x210]
    1110:      	fadd.4s	v9, v9, v2
    1114:      	fmul.4s	v9, v30, v9
    1118:      	fadd.4s	v9, v9, v10
    111c:      	fmul.4s	v9, v30, v9
    1120:      	fadd.4s	v9, v9, v5
    1124:      	fmul.4s	v9, v30, v9
    1128:      	movi.4s	v5, #0x3f, lsl #24
    112c:      	fadd.4s	v9, v9, v5
    1130:      	fmul.4s	v10, v30, v30
    1134:      	fmul.4s	v9, v10, v9
    1138:      	fadd.4s	v30, v30, v9
    113c:      	fadd.4s	v30, v30, v13
    1140:      	add.4s	v31, v31, v15
    1144:      	sshr.4s	v9, v31, #0x1
    1148:      	shl.4s	v10, v9, #0x17
    114c:      	add.4s	v10, v10, v13
    1150:      	fmul.4s	v30, v30, v10
    1154:      	sub.4s	v31, v31, v9
    1158:      	shl.4s	v31, v31, #0x17
    115c:      	add.4s	v31, v31, v13
    1160:      	fmul.4s	v30, v30, v31
    1164:      	fcmgt.4s	v29, v29, v11
    1168:      	ldr	q5, [sp, #0x160]
    116c:      	bsl.16b	v29, v5, v30
    1170:      	ldr	q9, [sp, #0x1c0]
    1174:      	fdiv.4s	v30, v9, v29
    1178:      	fsub.4s	v31, v29, v30
    117c:      	fadd.4s	v29, v29, v30
    1180:      	fdiv.4s	v29, v31, v29
    1184:      	bsl.16b	v28, v29, v13
    1188:      	movi.4s	v29, #0x3f, lsl #24
    118c:      	fcmge.4s	v26, v13, v26
    1190:      	bsl.16b	v26, v27, v28
    1194:      	mvni.4s	v5, #0x80, lsl #24
    1198:      	bif.16b	v26, v25, v5
    119c:      	fcmeq.4s	v25, v25, v25
    11a0:      	fadd.4s	v26, v26, v13
    11a4:      	ldr	q5, [sp, #0x150]
    11a8:      	bsl.16b	v25, v26, v5
    11ac:      	fmul.4s	v21, v21, v29
    11b0:      	fmul.4s	v21, v21, v25
    11b4:      	fmov	w16, s20
    11b8:      	fadd.4s	v20, v24, v21
    11bc:      	add	x15, x12, x10, lsl #5
    11c0:      	tbz	w16, #0x0, 0x11c8 <ltmp0+0x11c8>
    11c4:      	str	s20, [x15]
    11c8:      	and	w16, w16, #0xff
    11cc:      	tbz	w16, #0x1, 0x11d8 <ltmp0+0x11d8>
    11d0:      	add	x17, x15, #0x4
    11d4:      	st1.s	{ v20 }[1], [x17]
    11d8:      	ldr	q17, [sp, #0xf0]
    11dc:      	ldp	q15, q30, [sp, #0x110]
    11e0:      	ldr	q10, [sp, #0x130]
    11e4:      	ldp	q28, q5, [sp, #0x170]
    11e8:      	ldr	q27, [sp, #0x1b0]
    11ec:      	ldr	q31, [sp, #0x1d0]
    11f0:      	mov.16b	v8, v14
    11f4:      	ldr	q21, [sp, #0xb0]
    11f8:      	tbz	w16, #0x2, 0x1204 <ltmp0+0x1204>
    11fc:      	add	x17, x15, #0x8
    1200:      	st1.s	{ v20 }[2], [x17]
    1204:      	tbz	w16, #0x3, 0x1210 <ltmp0+0x1210>
    1208:      	add	x17, x15, #0xc
    120c:      	st1.s	{ v20 }[3], [x17]
    1210:      	fmul.4s	v20, v18, v21
    1214:      	fmul.4s	v20, v18, v20
    1218:      	fmul.4s	v20, v18, v20
    121c:      	fadd.4s	v20, v18, v20
    1220:      	fmul.4s	v20, v20, v8
    1224:      	and.16b	v20, v0, v20
    1228:      	fabs.4s	v21, v20
    122c:      	fmul.4s	v24, v20, v20
    1230:      	ldr	q25, [sp, #0x140]
    1234:      	ldr	q26, [sp, #0xc0]
    1238:      	fmla.4s	v25, v24, v26
    123c:      	mov.16b	v26, v17
    1240:      	fmla.4s	v26, v24, v25
    1244:      	mov.16b	v25, v15
    1248:      	fmla.4s	v25, v24, v26
    124c:      	mov.16b	v26, v10
    1250:      	fmla.4s	v26, v24, v25
    1254:      	mov.16b	v25, v30
    1258:      	fmla.4s	v25, v24, v26
    125c:      	mov.16b	v26, v13
    1260:      	fmla.4s	v26, v24, v25
    1264:      	fmul.4s	v25, v21, v26
    1268:      	ldr	q26, [sp, #0x250]
    126c:      	fmla.4s	v26, v24, v5
    1270:      	fmla.4s	v27, v24, v26
    1274:      	ldr	q26, [sp, #0x1a0]
    1278:      	fmla.4s	v26, v24, v27
    127c:      	ldr	q27, [sp, #0x190]
    1280:      	fmla.4s	v27, v24, v26
    1284:      	movi.4s	v26, #0x3f, lsl #24
    1288:      	fmla.4s	v26, v24, v27
    128c:      	mov.16b	v27, v13
    1290:      	fmla.4s	v27, v24, v26
    1294:      	fdiv.4s	v24, v25, v27
    1298:      	fcmge.4s	v25, v28, v21
    129c:      	and.16b	v26, v25, v21
    12a0:      	ldp	q5, q2, [sp, #0x230]
    12a4:      	fcmge.4s	v27, v26, v2
    12a8:      	ldr	q11, [sp, #0xd0]
    12ac:      	fcmge.4s	v28, v11, v26
    12b0:      	and.16b	v27, v27, v28
    12b4:      	and.16b	v27, v27, v26
    12b8:      	fmul.4s	v28, v27, v5
    12bc:      	movi.4s	v5, #0x4b, lsl #24
    12c0:      	fadd.4s	v28, v28, v5
    12c4:      	movi.4s	v2, #0xcb, lsl #24
    12c8:      	fadd.4s	v28, v28, v2
    12cc:      	fcvtzs.4s	v28, v28
    12d0:      	scvtf.4s	v29, v28
    12d4:      	mov.16b	v5, v30
    12d8:      	ldr	q2, [sp, #0x200]
    12dc:      	fmul.4s	v30, v29, v2
    12e0:      	fadd.4s	v27, v27, v30
    12e4:      	ldr	q2, [sp, #0x220]
    12e8:      	fmul.4s	v29, v29, v2
    12ec:      	fadd.4s	v27, v27, v29
    12f0:      	fmul.4s	v29, v27, v31
    12f4:      	ldr	q2, [sp, #0x1f0]
    12f8:      	fadd.4s	v29, v29, v2
    12fc:      	fmul.4s	v29, v27, v29
    1300:      	ldr	q2, [sp, #0x210]
    1304:      	fadd.4s	v29, v29, v2
    1308:      	fmul.4s	v29, v27, v29
    130c:      	ldr	q2, [sp, #0x1e0]
    1310:      	fadd.4s	v29, v29, v2
    1314:      	fmul.4s	v29, v27, v29
    1318:      	fadd.4s	v29, v29, v5
    131c:      	fmul.4s	v29, v27, v29
    1320:      	movi.4s	v5, #0x3f, lsl #24
    1324:      	fadd.4s	v29, v29, v5
    1328:      	fmul.4s	v30, v27, v27
    132c:      	fmul.4s	v29, v30, v29
    1330:      	fadd.4s	v27, v27, v29
    1334:      	fadd.4s	v27, v27, v13
    1338:      	movi.2d	v2, #0xffffffffffffffff
    133c:      	add.4s	v28, v28, v2
    1340:      	sshr.4s	v29, v28, #0x1
    1344:      	shl.4s	v30, v29, #0x17
    1348:      	add.4s	v30, v30, v13
    134c:      	fmul.4s	v27, v27, v30
    1350:      	sub.4s	v28, v28, v29
    1354:      	movi.4s	v29, #0x3f, lsl #24
    1358:      	shl.4s	v28, v28, #0x17
    135c:      	add.4s	v28, v28, v13
    1360:      	fmul.4s	v27, v27, v28
    1364:      	fcmgt.4s	v26, v26, v11
    1368:      	ldr	q5, [sp, #0x160]
    136c:      	bsl.16b	v26, v5, v27
    1370:      	fdiv.4s	v27, v9, v26
    1374:      	fsub.4s	v28, v26, v27
    1378:      	fadd.4s	v26, v26, v27
    137c:      	fdiv.4s	v26, v28, v26
    1380:      	bsl.16b	v25, v26, v13
    1384:      	fcmge.4s	v21, v13, v21
    1388:      	bsl.16b	v21, v24, v25
    138c:      	mvni.4s	v5, #0x80, lsl #24
    1390:      	bif.16b	v21, v20, v5
    1394:      	fcmeq.4s	v20, v20, v20
    1398:      	fadd.4s	v21, v21, v13
    139c:      	ldr	q5, [sp, #0x150]
    13a0:      	bsl.16b	v20, v21, v5
    13a4:      	fmul.4s	v18, v18, v29
    13a8:      	fmul.4s	v18, v18, v20
    13ac:      	fadd.4s	v18, v23, v18
    13b0:      	tbz	w16, #0x4, 0x13b8 <ltmp0+0x13b8>
    13b4:      	str	s18, [x15, #0x10]
    13b8:      	tbz	w16, #0x5, 0x13c4 <ltmp0+0x13c4>
    13bc:      	add	x17, x15, #0x14
    13c0:      	st1.s	{ v18 }[1], [x17]
    13c4:      	ldr	q11, [sp, #0x120]
    13c8:      	ldp	q28, q24, [sp, #0x170]
    13cc:      	ldp	q25, q29, [sp, #0x1a0]
    13d0:      	ldr	q26, [sp, #0x190]
    13d4:      	ldr	q23, [sp, #0xc0]
    13d8:      	mov.16b	v30, v10
    13dc:      	tbnz	w16, #0x6, 0x14bc <ltmp0+0x14bc>
    13e0:      	tbz	w16, #0x7, 0xf78 <ltmp0+0xf78>
    13e4:      	b	0x14c8 <ltmp0+0x14c8>
    13e8:      	ldr	s21, [x15]
    13ec:      	mov.16b	v31, v30
    13f0:      	and	w16, w16, #0xff
    13f4:      	tbz	w16, #0x1, 0xfb0 <ltmp0+0xfb0>
    13f8:      	add	x17, x15, #0x4
    13fc:      	ld1.s	{ v21 }[1], [x17]
    1400:      	mov.16b	v30, v15
    1404:      	tbz	w16, #0x2, 0xfb8 <ltmp0+0xfb8>
    1408:      	add	x17, x15, #0x8
    140c:      	ld1.s	{ v21 }[2], [x17]
    1410:      	tbz	w16, #0x3, 0xfbc <ltmp0+0xfbc>
    1414:      	add	x17, x15, #0xc
    1418:      	ld1.s	{ v21 }[3], [x17]
    141c:      	tbz	w16, #0x4, 0xfc0 <ltmp0+0xfc0>
    1420:      	add	x17, x15, #0x10
    1424:      	ld1.s	{ v18 }[0], [x17]
    1428:      	tbz	w16, #0x5, 0xfc4 <ltmp0+0xfc4>
    142c:      	add	x17, x15, #0x14
    1430:      	ld1.s	{ v18 }[1], [x17]
    1434:      	tbz	w16, #0x6, 0xfc8 <ltmp0+0xfc8>
    1438:      	add	x17, x15, #0x18
    143c:      	ld1.s	{ v18 }[2], [x17]
    1440:      	tbz	w16, #0x7, 0xfcc <ltmp0+0xfcc>
    1444:      	add	x15, x15, #0x1c
    1448:      	ld1.s	{ v18 }[3], [x15]
    144c:      	fmov	w16, s20
    1450:      	add	x15, x13, x10, lsl #5
    1454:      	movi.2d	v24, #0000000000000000
    1458:      	movi.2d	v23, #0000000000000000
    145c:      	tbz	w16, #0x0, 0xfe0 <ltmp0+0xfe0>
    1460:      	ldr	s24, [x15]
    1464:      	and	w16, w16, #0xff
    1468:      	tbz	w16, #0x1, 0xfe8 <ltmp0+0xfe8>
    146c:      	add	x17, x15, #0x4
    1470:      	ld1.s	{ v24 }[1], [x17]
    1474:      	tbz	w16, #0x2, 0xfec <ltmp0+0xfec>
    1478:      	add	x17, x15, #0x8
    147c:      	ld1.s	{ v24 }[2], [x17]
    1480:      	tbz	w16, #0x3, 0xff0 <ltmp0+0xff0>
    1484:      	add	x17, x15, #0xc
    1488:      	ld1.s	{ v24 }[3], [x17]
    148c:      	tbz	w16, #0x4, 0xff4 <ltmp0+0xff4>
    1490:      	add	x17, x15, #0x10
    1494:      	ld1.s	{ v23 }[0], [x17]
    1498:      	tbz	w16, #0x5, 0xff8 <ltmp0+0xff8>
    149c:      	add	x17, x15, #0x14
    14a0:      	ld1.s	{ v23 }[1], [x17]
    14a4:      	tbz	w16, #0x6, 0xffc <ltmp0+0xffc>
    14a8:      	add	x17, x15, #0x18
    14ac:      	ld1.s	{ v23 }[2], [x17]
    14b0:      	movi.2d	v15, #0xffffffffffffffff
    14b4:      	tbnz	w16, #0x7, 0x1004 <ltmp0+0x1004>
    14b8:      	b	0x100c <ltmp0+0x100c>
    14bc:      	add	x17, x15, #0x18
    14c0:      	st1.s	{ v18 }[2], [x17]
    14c4:      	tbz	w16, #0x7, 0xf78 <ltmp0+0xf78>
    14c8:      	add	x15, x15, #0x1c
    14cc:      	st1.s	{ v18 }[3], [x15]
    14d0:      	b	0xf78 <ltmp0+0xf78>
    14d4:      	mov	x19, #0x0               ; =0
    14d8:      	ldr	x8, [sp, #0x18]
    14dc:      	ldr	x13, [x8]
    14e0:      	ldr	x20, [x8, #0x10]
    14e4:      	ldr	x14, [x8, #0x30]
    14e8:      	subs	x8, x13, x14
    14ec:      	mov	w11, #0x2007            ; =8199
    14f0:      	movk	w11, #0x18, lsl #16
    14f4:      	ccmp	x8, x11, #0x0, hs
    14f8:      	cset	w8, hi
    14fc:      	subs	x9, x14, x13
    1500:      	ccmp	x9, x11, #0x0, hs
    1504:      	csinc	w8, w8, wzr, ls
    1508:      	subs	x9, x20, x14
    150c:      	ccmp	x9, x11, #0x0, hs
    1510:      	cset	w9, hi
    1514:      	subs	x10, x14, x20
    1518:      	ccmp	x10, x11, #0x0, hs
    151c:      	csinc	w9, w9, wzr, ls
    1520:      	and	w11, w8, w9
    1524:      	ldr	x8, [sp, #0x48]
    1528:      	lsl	w15, w8, #2
    152c:      	and	x8, x8, #0x7ffffff
    1530:      	mov	w9, #0x6020             ; =24608
    1534:      	umaddl	x21, w8, w9, x14
    1538:      	umaddl	x25, w8, w9, x20
    153c:      	str	x13, [sp, #0xa0]
    1540:      	umaddl	x26, w8, w9, x13
    1544:      	str	x12, [sp, #0x70]
    1548:      	str	x14, [sp, #0x60]
    154c:      	str	w11, [sp, #0x58]
    1550:      	str	x15, [sp, #0x50]
    1554:      	b	0x1740 <ltmp0+0x1740>
    1558:      	movi.2d	v1, #0000000000000000
    155c:      	ldr	q0, [sp, #0x80]
    1560:      	mov.d	v1[0], v0[0]
    1564:      	fmul.4s	v2, v1, v21
    1568:      	fmul.4s	v2, v0, v2
    156c:      	fmul.4s	v2, v0, v2
    1570:      	fadd.4s	v2, v0, v2
    1574:      	fmul.4s	v3, v2, v8
    1578:      	movi.2d	v2, #0000000000000000
    157c:      	mov.d	v2[0], v3[0]
    1580:      	fabs.4s	v3, v2
    1584:      	fmul.4s	v4, v2, v2
    1588:      	mov.16b	v5, v19
    158c:      	fmla.4s	v5, v4, v23
    1590:      	mov.16b	v6, v14
    1594:      	fmla.4s	v6, v4, v5
    1598:      	mov.16b	v5, v9
    159c:      	fmla.4s	v5, v4, v6
    15a0:      	mov.16b	v6, v30
    15a4:      	fmla.4s	v6, v4, v5
    15a8:      	mov.16b	v5, v31
    15ac:      	fmla.4s	v5, v4, v6
    15b0:      	mov.16b	v6, v13
    15b4:      	fmla.4s	v6, v4, v5
    15b8:      	fmul.4s	v5, v3, v6
    15bc:      	ldp	q0, q6, [sp, #0x240]
    15c0:      	ldp	q25, q10, [sp, #0x180]
    15c4:      	fmla.4s	v6, v4, v25
    15c8:      	ldp	q26, q7, [sp, #0x1a0]
    15cc:      	fmla.4s	v7, v4, v6
    15d0:      	mov.16b	v6, v26
    15d4:      	fmla.4s	v6, v4, v7
    15d8:      	mov.16b	v7, v10
    15dc:      	fmla.4s	v7, v4, v6
    15e0:      	movi.4s	v6, #0x3f, lsl #24
    15e4:      	fmla.4s	v6, v4, v7
    15e8:      	mov.16b	v7, v13
    15ec:      	fmla.4s	v7, v4, v6
    15f0:      	fdiv.4s	v4, v5, v7
    15f4:      	ldr	q28, [sp, #0x170]
    15f8:      	fcmge.4s	v5, v28, v3
    15fc:      	and.16b	v6, v5, v3
    1600:      	fcmge.4s	v7, v6, v0
    1604:      	fcmge.4s	v16, v15, v6
    1608:      	and.16b	v7, v7, v16
    160c:      	and.16b	v7, v7, v6
    1610:      	ldr	q0, [sp, #0x230]
    1614:      	fmul.4s	v16, v7, v0
    1618:      	movi.4s	v0, #0x4b, lsl #24
    161c:      	fadd.4s	v16, v16, v0
    1620:      	movi.4s	v0, #0xcb, lsl #24
    1624:      	fadd.4s	v16, v16, v0
    1628:      	fcvtzs.4s	v16, v16
    162c:      	scvtf.4s	v17, v16
    1630:      	ldp	q11, q24, [sp, #0x1f0]
    1634:      	fmul.4s	v18, v17, v24
    1638:      	fadd.4s	v7, v7, v18
    163c:      	ldr	q0, [sp, #0x220]
    1640:      	fmul.4s	v17, v17, v0
    1644:      	fadd.4s	v7, v7, v17
    1648:      	ldr	q12, [sp, #0x1d0]
    164c:      	fmul.4s	v17, v7, v12
    1650:      	fadd.4s	v17, v17, v11
    1654:      	fmul.4s	v17, v7, v17
    1658:      	ldr	q0, [sp, #0x210]
    165c:      	fadd.4s	v17, v17, v0
    1660:      	fmul.4s	v17, v7, v17
    1664:      	ldr	q0, [sp, #0x1e0]
    1668:      	fadd.4s	v17, v17, v0
    166c:      	fmul.4s	v17, v7, v17
    1670:      	fadd.4s	v17, v17, v31
    1674:      	fmul.4s	v17, v7, v17
    1678:      	fadd.4s	v17, v17, v29
    167c:      	fmul.4s	v18, v7, v7
    1680:      	fmul.4s	v17, v18, v17
    1684:      	fadd.4s	v7, v7, v17
    1688:      	fadd.4s	v7, v7, v13
    168c:      	add.4s	v16, v16, v27
    1690:      	sshr.4s	v17, v16, #0x1
    1694:      	shl.4s	v18, v17, #0x17
    1698:      	add.4s	v18, v18, v13
    169c:      	fmul.4s	v7, v7, v18
    16a0:      	sub.4s	v16, v16, v17
    16a4:      	shl.4s	v16, v16, #0x17
    16a8:      	add.4s	v16, v16, v13
    16ac:      	fmul.4s	v7, v7, v16
    16b0:      	fcmgt.4s	v6, v6, v15
    16b4:      	ldp	q18, q22, [sp, #0x150]
    16b8:      	bsl.16b	v6, v22, v7
    16bc:      	ldr	q0, [sp, #0x1c0]
    16c0:      	fdiv.4s	v7, v0, v6
    16c4:      	fsub.4s	v16, v6, v7
    16c8:      	fadd.4s	v6, v6, v7
    16cc:      	fdiv.4s	v6, v16, v6
    16d0:      	bsl.16b	v5, v6, v13
    16d4:      	fcmge.4s	v3, v13, v3
    16d8:      	bsl.16b	v3, v4, v5
    16dc:      	bif.16b	v3, v2, v20
    16e0:      	fcmeq.4s	v2, v2, v2
    16e4:      	fadd.4s	v3, v3, v13
    16e8:      	bsl.16b	v2, v3, v18
    16ec:      	fmul.4s	v1, v1, v29
    16f0:      	fmul.4s	v1, v1, v2
    16f4:      	ldr	q0, [sp, #0x90]
    16f8:      	fadd.4s	v0, v0, v1
    16fc:      	mov	w1, #0x1808             ; =6152
    1700:      	mov.16b	v27, v25
    1704:      	ldr	q20, [sp, #0x250]
    1708:      	ldr	q29, [sp, #0x1b0]
    170c:      	mov.16b	v25, v26
    1710:      	mov.16b	v26, v10
    1714:      	ldr	x12, [sp, #0x70]
    1718:      	ldr	x14, [sp, #0x60]
    171c:      	ldr	w11, [sp, #0x58]
    1720:      	ldr	x15, [sp, #0x50]
    1724:      	str	d0, [x14, x28]
    1728:      	add	x19, x19, #0x1
    172c:      	add	x21, x21, x1
    1730:      	add	x25, x25, x1
    1734:      	add	x26, x26, x1
    1738:      	cmp	x19, x12
    173c:      	b.eq	0xe30 <ltmp0+0xe30>
    1740:      	add	w8, w19, w15
    1744:      	and	x8, x8, #0x1fffffff
    1748:      	umull	x22, w8, w1
    174c:      	cbz	w11, 0x1c64 <ltmp0+0x1c64>
    1750:      	mov	x8, #0x0                ; =0
    1754:      	ldr	q15, [sp, #0xd0]
    1758:      	lsl	x9, x8, #5
    175c:      	add	x10, x26, x9
    1760:      	ldp	q0, q1, [x10]
    1764:      	fmul.4s	v2, v0, v21
    1768:      	fmul.4s	v3, v1, v21
    176c:      	fmul.4s	v3, v1, v3
    1770:      	fmul.4s	v2, v0, v2
    1774:      	fmul.4s	v2, v0, v2
    1778:      	fmul.4s	v3, v1, v3
    177c:      	fadd.4s	v4, v1, v3
    1780:      	fadd.4s	v2, v0, v2
    1784:      	ldp	q17, q5, [sp, #0xf0]
    1788:      	fmul.4s	v3, v2, v5
    178c:      	fmul.4s	v2, v4, v5
    1790:      	fabs.4s	v5, v2
    1794:      	fabs.4s	v4, v3
    1798:      	fmul.4s	v19, v3, v3
    179c:      	mov.16b	v30, v21
    17a0:      	fmul.4s	v21, v2, v2
    17a4:      	ldp	q18, q7, [sp, #0x130]
    17a8:      	mov.16b	v6, v7
    17ac:      	fmla.4s	v6, v19, v23
    17b0:      	fmla.4s	v7, v21, v23
    17b4:      	mov.16b	v16, v17
    17b8:      	fmla.4s	v16, v19, v6
    17bc:      	mov.16b	v6, v17
    17c0:      	fmla.4s	v6, v21, v7
    17c4:      	ldr	q17, [sp, #0x110]
    17c8:      	mov.16b	v7, v17
    17cc:      	fmla.4s	v7, v19, v16
    17d0:      	mov.16b	v16, v17
    17d4:      	fmla.4s	v16, v21, v6
    17d8:      	mov.16b	v17, v18
    17dc:      	mov.16b	v22, v31
    17e0:      	mov.16b	v14, v23
    17e4:      	mov.16b	v23, v31
    17e8:      	mov.16b	v6, v13
    17ec:      	fmla.4s	v17, v19, v7
    17f0:      	mov.16b	v7, v20
    17f4:      	fmla.4s	v7, v21, v27
    17f8:      	ldr	q20, [sp, #0x250]
    17fc:      	fmla.4s	v20, v19, v27
    1800:      	mov.16b	v24, v29
    1804:      	fmla.4s	v18, v21, v16
    1808:      	fmla.4s	v24, v21, v7
    180c:      	fmla.4s	v29, v19, v20
    1810:      	mov.16b	v16, v25
    1814:      	fmla.4s	v16, v21, v24
    1818:      	fmla.4s	v22, v19, v17
    181c:      	mov.16b	v17, v25
    1820:      	fmla.4s	v17, v19, v29
    1824:      	mov.16b	v20, v26
    1828:      	fmla.4s	v20, v21, v16
    182c:      	mov.16b	v24, v26
    1830:      	fmla.4s	v23, v21, v18
    1834:      	fmla.4s	v24, v19, v17
    1838:      	movi.4s	v25, #0x3f, lsl #24
    183c:      	movi.4s	v26, #0x3f, lsl #24
    1840:      	mov.16b	v17, v13
    1844:      	fcmge.4s	v7, v28, v4
    1848:      	fmla.4s	v25, v21, v20
    184c:      	fcmge.4s	v16, v28, v5
    1850:      	and.16b	v18, v16, v5
    1854:      	and.16b	v20, v7, v4
    1858:      	ldr	q28, [sp, #0x240]
    185c:      	fcmge.4s	v27, v20, v28
    1860:      	fcmge.4s	v28, v18, v28
    1864:      	fcmge.4s	v29, v15, v18
    1868:      	and.16b	v28, v28, v29
    186c:      	fcmge.4s	v29, v15, v20
    1870:      	and.16b	v27, v27, v29
    1874:      	and.16b	v27, v27, v20
    1878:      	and.16b	v28, v28, v18
    187c:      	fmla.4s	v6, v21, v23
    1880:      	ldr	q29, [sp, #0x230]
    1884:      	fmul.4s	v23, v28, v29
    1888:      	fmul.4s	v29, v27, v29
    188c:      	movi.4s	v8, #0x4b, lsl #24
    1890:      	fadd.4s	v29, v29, v8
    1894:      	movi.4s	v9, #0x4b, lsl #24
    1898:      	fadd.4s	v23, v23, v8
    189c:      	movi.4s	v8, #0xcb, lsl #24
    18a0:      	fadd.4s	v23, v23, v8
    18a4:      	fmla.4s	v17, v21, v25
    18a8:      	movi.4s	v12, #0xcb, lsl #24
    18ac:      	fadd.4s	v21, v29, v8
    18b0:      	fcvtzs.4s	v21, v21
    18b4:      	fcvtzs.4s	v23, v23
    18b8:      	scvtf.4s	v25, v23
    18bc:      	scvtf.4s	v29, v21
    18c0:      	fmla.4s	v26, v19, v24
    18c4:      	ldr	q8, [sp, #0x200]
    18c8:      	fmul.4s	v24, v25, v8
    18cc:      	fadd.4s	v24, v28, v24
    18d0:      	fmul.4s	v28, v29, v8
    18d4:      	fadd.4s	v27, v27, v28
    18d8:      	mov.16b	v28, v13
    18dc:      	fmla.4s	v28, v19, v22
    18e0:      	ldr	q8, [sp, #0x220]
    18e4:      	fmul.4s	v22, v29, v8
    18e8:      	ldr	q29, [sp, #0x1b0]
    18ec:      	fadd.4s	v22, v27, v22
    18f0:      	fmul.4s	v25, v25, v8
    18f4:      	fadd.4s	v24, v24, v25
    18f8:      	mov.16b	v25, v13
    18fc:      	fmla.4s	v25, v19, v26
    1900:      	ldr	q26, [sp, #0x1d0]
    1904:      	fmul.4s	v19, v24, v26
    1908:      	fmul.4s	v26, v22, v26
    190c:      	ldr	q27, [sp, #0x1f0]
    1910:      	fadd.4s	v26, v26, v27
    1914:      	fadd.4s	v19, v19, v27
    1918:      	fmul.4s	v19, v24, v19
    191c:      	fmul.4s	v27, v4, v28
    1920:      	fmul.4s	v26, v22, v26
    1924:      	ldr	q28, [sp, #0x210]
    1928:      	fadd.4s	v26, v26, v28
    192c:      	fadd.4s	v19, v19, v28
    1930:      	fmul.4s	v19, v24, v19
    1934:      	fmul.4s	v26, v22, v26
    1938:      	ldr	q28, [sp, #0x1e0]
    193c:      	fadd.4s	v26, v26, v28
    1940:      	fadd.4s	v19, v19, v28
    1944:      	fmul.4s	v19, v24, v19
    1948:      	fmul.4s	v26, v22, v26
    194c:      	fadd.4s	v26, v26, v31
    1950:      	fadd.4s	v28, v19, v31
    1954:      	fdiv.4s	v19, v27, v25
    1958:      	fmul.4s	v25, v24, v28
    195c:      	fmul.4s	v26, v22, v26
    1960:      	movi.4s	v8, #0x3f, lsl #24
    1964:      	fadd.4s	v26, v26, v8
    1968:      	fadd.4s	v25, v25, v8
    196c:      	fmul.4s	v27, v24, v24
    1970:      	fmul.4s	v25, v27, v25
    1974:      	fmul.4s	v27, v22, v22
    1978:      	fmul.4s	v26, v27, v26
    197c:      	ldp	q28, q27, [sp, #0x170]
    1980:      	fadd.4s	v22, v22, v26
    1984:      	fadd.4s	v24, v24, v25
    1988:      	movi.2d	v10, #0xffffffffffffffff
    198c:      	add.4s	v21, v21, v10
    1990:      	fadd.4s	v22, v22, v13
    1994:      	sshr.4s	v25, v21, #0x1
    1998:      	shl.4s	v26, v25, #0x17
    199c:      	add.4s	v26, v26, v13
    19a0:      	fmul.4s	v22, v22, v26
    19a4:      	movi.2d	v11, #0xffffffffffffffff
    19a8:      	add.4s	v23, v23, v10
    19ac:      	fadd.4s	v24, v24, v13
    19b0:      	sub.4s	v21, v21, v25
    19b4:      	sshr.4s	v25, v23, #0x1
    19b8:      	sub.4s	v23, v23, v25
    19bc:      	shl.4s	v25, v25, #0x17
    19c0:      	add.4s	v25, v25, v13
    19c4:      	fmul.4s	v24, v24, v25
    19c8:      	ldp	q26, q25, [sp, #0x190]
    19cc:      	shl.4s	v23, v23, #0x17
    19d0:      	add.4s	v23, v23, v13
    19d4:      	fmul.4s	v23, v24, v23
    19d8:      	mvni.4s	v24, #0x80, lsl #24
    19dc:      	shl.4s	v21, v21, #0x17
    19e0:      	add.4s	v21, v21, v13
    19e4:      	fmul.4s	v21, v22, v21
    19e8:      	ldr	q22, [sp, #0x160]
    19ec:      	fcmgt.4s	v20, v20, v15
    19f0:      	bsl.16b	v20, v22, v21
    19f4:      	fmul.4s	v6, v5, v6
    19f8:      	fcmgt.4s	v18, v18, v15
    19fc:      	bsl.16b	v18, v22, v23
    1a00:      	mov.16b	v23, v14
    1a04:      	fdiv.4s	v6, v6, v17
    1a08:      	ldr	q14, [sp, #0x1c0]
    1a0c:      	fdiv.4s	v17, v14, v18
    1a10:      	fsub.4s	v21, v18, v17
    1a14:      	fadd.4s	v17, v18, v17
    1a18:      	ldr	q18, [sp, #0x150]
    1a1c:      	fdiv.4s	v17, v21, v17
    1a20:      	mov.16b	v21, v30
    1a24:      	bsl.16b	v16, v17, v13
    1a28:      	fcmge.4s	v5, v13, v5
    1a2c:      	bsl.16b	v5, v6, v16
    1a30:      	fdiv.4s	v6, v14, v20
    1a34:      	fsub.4s	v16, v20, v6
    1a38:      	fadd.4s	v6, v20, v6
    1a3c:      	ldr	q20, [sp, #0x250]
    1a40:      	fdiv.4s	v6, v16, v6
    1a44:      	bif.16b	v6, v13, v7
    1a48:      	fcmge.4s	v4, v13, v4
    1a4c:      	bsl.16b	v4, v19, v6
    1a50:      	bif.16b	v4, v3, v24
    1a54:      	fcmeq.4s	v3, v3, v3
    1a58:      	fadd.4s	v4, v4, v13
    1a5c:      	bsl.16b	v3, v4, v18
    1a60:      	mov.16b	v4, v24
    1a64:      	bsl.16b	v4, v5, v2
    1a68:      	fcmeq.4s	v2, v2, v2
    1a6c:      	fadd.4s	v4, v4, v13
    1a70:      	bsl.16b	v2, v4, v18
    1a74:      	fmul.4s	v1, v1, v8
    1a78:      	fmul.4s	v1, v1, v2
    1a7c:      	fmul.4s	v0, v0, v8
    1a80:      	fmul.4s	v0, v0, v3
    1a84:      	add	x10, x25, x9
    1a88:      	ldp	q3, q2, [x10]
    1a8c:      	fadd.4s	v0, v3, v0
    1a90:      	fadd.4s	v1, v2, v1
    1a94:      	add	x9, x21, x9
    1a98:      	stp	q0, q1, [x9]
    1a9c:      	add	x8, x8, #0x1
    1aa0:      	cmp	x8, #0xc0
    1aa4:      	b.ne	0x1758 <ltmp0+0x1758>
    1aa8:      	mov	w8, #0x1800             ; =6144
    1aac:      	add	x28, x22, x8
    1ab0:      	ldr	x8, [sp, #0xa0]
    1ab4:      	add	x8, x8, x28
    1ab8:      	movi.2d	v0, #0000000000000000
    1abc:      	ld1.s	{ v0 }[0], [x8], #4
    1ac0:      	ld1.s	{ v0 }[1], [x8]
    1ac4:      	fmul.4s	v1, v0, v21
    1ac8:      	fmul.4s	v1, v0, v1
    1acc:      	fmul.4s	v1, v0, v1
    1ad0:      	fadd.4s	v1, v0, v1
    1ad4:      	ldp	q14, q2, [sp, #0xf0]
    1ad8:      	fmul.4s	v2, v1, v2
    1adc:      	movi.2d	v1, #0000000000000000
    1ae0:      	mov.d	v1[0], v2[0]
    1ae4:      	fabs.4s	v2, v1
    1ae8:      	fmul.4s	v3, v1, v1
    1aec:      	ldp	q30, q4, [sp, #0x130]
    1af0:      	fmla.4s	v4, v3, v23
    1af4:      	mov.16b	v5, v14
    1af8:      	fmla.4s	v5, v3, v4
    1afc:      	ldr	q4, [sp, #0x110]
    1b00:      	fmla.4s	v4, v3, v5
    1b04:      	mov.16b	v5, v30
    1b08:      	fmla.4s	v5, v3, v4
    1b0c:      	mov.16b	v4, v31
    1b10:      	fmla.4s	v4, v3, v5
    1b14:      	mov.16b	v5, v13
    1b18:      	fmla.4s	v5, v3, v4
    1b1c:      	fmul.4s	v4, v2, v5
    1b20:      	mov.16b	v5, v20
    1b24:      	fmla.4s	v5, v3, v27
    1b28:      	mov.16b	v6, v29
    1b2c:      	fmla.4s	v6, v3, v5
    1b30:      	mov.16b	v5, v25
    1b34:      	fmla.4s	v5, v3, v6
    1b38:      	mov.16b	v6, v26
    1b3c:      	fmla.4s	v6, v3, v5
    1b40:      	movi.4s	v5, #0x3f, lsl #24
    1b44:      	fmla.4s	v5, v3, v6
    1b48:      	mov.16b	v6, v13
    1b4c:      	fmla.4s	v6, v3, v5
    1b50:      	fdiv.4s	v19, v4, v6
    1b54:      	fcmge.4s	v4, v28, v2
    1b58:      	and.16b	v5, v4, v2
    1b5c:      	ldr	q3, [sp, #0x240]
    1b60:      	fcmge.4s	v6, v5, v3
    1b64:      	fcmge.4s	v7, v15, v5
    1b68:      	and.16b	v6, v6, v7
    1b6c:      	and.16b	v6, v6, v5
    1b70:      	ldr	q3, [sp, #0x230]
    1b74:      	fmul.4s	v7, v6, v3
    1b78:      	fadd.4s	v7, v7, v9
    1b7c:      	fadd.4s	v7, v7, v12
    1b80:      	fcvtzs.4s	v7, v7
    1b84:      	scvtf.4s	v16, v7
    1b88:      	ldp	q10, q12, [sp, #0x1f0]
    1b8c:      	fmul.4s	v17, v16, v12
    1b90:      	fadd.4s	v6, v6, v17
    1b94:      	ldp	q17, q3, [sp, #0x210]
    1b98:      	fmul.4s	v16, v16, v3
    1b9c:      	fadd.4s	v6, v6, v16
    1ba0:      	ldr	q3, [sp, #0x1d0]
    1ba4:      	fmul.4s	v16, v6, v3
    1ba8:      	fadd.4s	v16, v16, v10
    1bac:      	fmul.4s	v16, v6, v16
    1bb0:      	fadd.4s	v16, v16, v17
    1bb4:      	fmul.4s	v16, v6, v16
    1bb8:      	ldr	q17, [sp, #0x1e0]
    1bbc:      	fadd.4s	v16, v16, v17
    1bc0:      	fmul.4s	v16, v6, v16
    1bc4:      	fadd.4s	v16, v16, v31
    1bc8:      	fmul.4s	v16, v6, v16
    1bcc:      	movi.4s	v9, #0x3f, lsl #24
    1bd0:      	fadd.4s	v16, v16, v9
    1bd4:      	fmul.4s	v17, v6, v6
    1bd8:      	fmul.4s	v16, v17, v16
    1bdc:      	fadd.4s	v6, v6, v16
    1be0:      	fadd.4s	v6, v6, v13
    1be4:      	add.4s	v7, v7, v11
    1be8:      	sshr.4s	v16, v7, #0x1
    1bec:      	shl.4s	v17, v16, #0x17
    1bf0:      	add.4s	v17, v17, v13
    1bf4:      	fmul.4s	v6, v6, v17
    1bf8:      	sub.4s	v7, v7, v16
    1bfc:      	shl.4s	v7, v7, #0x17
    1c00:      	add.4s	v7, v7, v13
    1c04:      	fmul.4s	v6, v6, v7
    1c08:      	fcmgt.4s	v5, v5, v15
    1c0c:      	bsl.16b	v5, v22, v6
    1c10:      	ldr	q6, [sp, #0x1c0]
    1c14:      	fdiv.4s	v6, v6, v5
    1c18:      	fsub.4s	v7, v5, v6
    1c1c:      	fadd.4s	v5, v5, v6
    1c20:      	fdiv.4s	v5, v7, v5
    1c24:      	bsl.16b	v4, v5, v13
    1c28:      	fcmge.4s	v2, v13, v2
    1c2c:      	bsl.16b	v2, v19, v4
    1c30:      	bif.16b	v2, v1, v24
    1c34:      	fcmeq.4s	v1, v1, v1
    1c38:      	fadd.4s	v2, v2, v13
    1c3c:      	bsl.16b	v1, v2, v18
    1c40:      	fmul.4s	v0, v0, v9
    1c44:      	fmul.4s	v0, v0, v1
    1c48:      	add	x8, x20, x28
    1c4c:      	add	x9, x8, #0x4
    1c50:      	ldr	s1, [x8]
    1c54:      	ld1.s	{ v1 }[1], [x9]
    1c58:      	fadd.4s	v0, v1, v0
    1c5c:      	ldp	q8, q9, [sp, #0x100]
    1c60:      	b	0x1724 <ltmp0+0x1724>
    1c64:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    1c68:      	add	x0, x0, #0xbf0
    1c6c:      	ldr	x27, [sp, #0xa0]
    1c70:      	add	x1, x27, x22
    1c74:      	mov	w2, #0x1800             ; =6144
    1c78:      	bl	0x1c78 <ltmp0+0x1c78>
    1c7c:      	mov	w8, #0x1800             ; =6144
    1c80:      	add	x28, x22, x8
    1c84:      	add	x8, x27, x28
    1c88:      	add	x9, x8, #0x4
    1c8c:      	ldr	s0, [x8]
    1c90:      	ld1.s	{ v0 }[1], [x9]
    1c94:      	str	q0, [sp, #0x80]
    1c98:      	str	q0, [sp, #0x33f0]
    1c9c:      	add	x0, sp, #0x3d0
    1ca0:      	add	x1, x20, x22
    1ca4:      	mov	w2, #0x1800             ; =6144
    1ca8:      	bl	0x1ca8 <ltmp0+0x1ca8>
    1cac:      	ldp	q31, q30, [sp, #0x120]
    1cb0:      	ldp	q8, q9, [sp, #0x100]
    1cb4:      	ldp	q13, q14, [sp, #0xe0]
    1cb8:      	ldr	q19, [sp, #0x140]
    1cbc:      	ldp	q21, q23, [sp, #0xb0]
    1cc0:      	mov	x8, #0x0                ; =0
    1cc4:      	add	x9, x20, x28
    1cc8:      	add	x10, x9, #0x4
    1ccc:      	ldr	s0, [x9]
    1cd0:      	ld1.s	{ v0 }[1], [x10]
    1cd4:      	str	q0, [sp, #0x90]
    1cd8:      	str	q0, [sp, #0x1bd0]
    1cdc:      	ldr	q15, [sp, #0xd0]
    1ce0:      	lsl	x9, x8, #5
    1ce4:      	add	x10, x23, x9
    1ce8:      	ldp	q1, q2, [x10]
    1cec:      	fmul.4s	v3, v1, v21
    1cf0:      	fmul.4s	v4, v2, v21
    1cf4:      	fmul.4s	v4, v2, v4
    1cf8:      	fmul.4s	v3, v1, v3
    1cfc:      	fmul.4s	v3, v1, v3
    1d00:      	fmul.4s	v4, v2, v4
    1d04:      	fadd.4s	v5, v2, v4
    1d08:      	fadd.4s	v3, v1, v3
    1d0c:      	fmul.4s	v4, v3, v8
    1d10:      	fmul.4s	v3, v5, v8
    1d14:      	fabs.4s	v6, v3
    1d18:      	fabs.4s	v5, v4
    1d1c:      	fmul.4s	v20, v4, v4
    1d20:      	fmul.4s	v22, v3, v3
    1d24:      	mov.16b	v7, v19
    1d28:      	fmla.4s	v7, v20, v23
    1d2c:      	mov.16b	v16, v19
    1d30:      	fmla.4s	v16, v22, v23
    1d34:      	mov.16b	v17, v14
    1d38:      	fmla.4s	v17, v20, v7
    1d3c:      	mov.16b	v7, v14
    1d40:      	fmla.4s	v7, v22, v16
    1d44:      	mov.16b	v16, v9
    1d48:      	fmla.4s	v16, v20, v17
    1d4c:      	mov.16b	v17, v9
    1d50:      	fmla.4s	v17, v22, v7
    1d54:      	mov.16b	v18, v30
    1d58:      	mov.16b	v11, v19
    1d5c:      	mov.16b	v19, v30
    1d60:      	mov.16b	v0, v8
    1d64:      	mov.16b	v8, v23
    1d68:      	mov.16b	v23, v31
    1d6c:      	mov.16b	v24, v31
    1d70:      	mov.16b	v7, v13
    1d74:      	fmla.4s	v18, v20, v16
    1d78:      	ldr	q26, [sp, #0x250]
    1d7c:      	mov.16b	v16, v26
    1d80:      	ldr	q25, [sp, #0x180]
    1d84:      	fmla.4s	v16, v22, v25
    1d88:      	mov.16b	v10, v9
    1d8c:      	mov.16b	v9, v14
    1d90:      	mov.16b	v14, v21
    1d94:      	mov.16b	v21, v26
    1d98:      	fmla.4s	v21, v20, v25
    1d9c:      	ldr	q26, [sp, #0x1b0]
    1da0:      	mov.16b	v25, v26
    1da4:      	fmla.4s	v19, v22, v17
    1da8:      	fmla.4s	v25, v22, v16
    1dac:      	mov.16b	v16, v26
    1db0:      	fmla.4s	v16, v20, v21
    1db4:      	ldr	q21, [sp, #0x1a0]
    1db8:      	mov.16b	v17, v21
    1dbc:      	fmla.4s	v17, v22, v25
    1dc0:      	fmla.4s	v23, v20, v18
    1dc4:      	mov.16b	v18, v21
    1dc8:      	fmla.4s	v18, v20, v16
    1dcc:      	ldr	q25, [sp, #0x190]
    1dd0:      	mov.16b	v21, v25
    1dd4:      	fmla.4s	v21, v22, v17
    1dd8:      	fmla.4s	v24, v22, v19
    1ddc:      	fmla.4s	v25, v20, v18
    1de0:      	movi.4s	v26, #0x3f, lsl #24
    1de4:      	movi.4s	v27, #0x3f, lsl #24
    1de8:      	mov.16b	v18, v13
    1dec:      	ldr	q17, [sp, #0x170]
    1df0:      	fcmge.4s	v16, v17, v5
    1df4:      	fmla.4s	v26, v22, v21
    1df8:      	fcmge.4s	v17, v17, v6
    1dfc:      	and.16b	v19, v17, v6
    1e00:      	and.16b	v21, v16, v5
    1e04:      	ldr	q29, [sp, #0x240]
    1e08:      	fcmge.4s	v28, v21, v29
    1e0c:      	fcmge.4s	v29, v19, v29
    1e10:      	mov.16b	v31, v30
    1e14:      	fcmge.4s	v30, v15, v19
    1e18:      	and.16b	v29, v29, v30
    1e1c:      	fcmge.4s	v30, v15, v21
    1e20:      	and.16b	v28, v28, v30
    1e24:      	and.16b	v28, v28, v21
    1e28:      	and.16b	v29, v29, v19
    1e2c:      	fmla.4s	v7, v22, v24
    1e30:      	ldr	q30, [sp, #0x230]
    1e34:      	fmul.4s	v24, v29, v30
    1e38:      	fmul.4s	v30, v28, v30
    1e3c:      	movi.4s	v12, #0x4b, lsl #24
    1e40:      	fadd.4s	v30, v30, v12
    1e44:      	fadd.4s	v24, v24, v12
    1e48:      	movi.4s	v12, #0xcb, lsl #24
    1e4c:      	fadd.4s	v24, v24, v12
    1e50:      	fmla.4s	v18, v22, v26
    1e54:      	fadd.4s	v22, v30, v12
    1e58:      	fcvtzs.4s	v22, v22
    1e5c:      	fcvtzs.4s	v24, v24
    1e60:      	scvtf.4s	v26, v24
    1e64:      	scvtf.4s	v30, v22
    1e68:      	fmla.4s	v27, v20, v25
    1e6c:      	ldr	q12, [sp, #0x200]
    1e70:      	fmul.4s	v25, v26, v12
    1e74:      	fadd.4s	v25, v29, v25
    1e78:      	fmul.4s	v29, v30, v12
    1e7c:      	fadd.4s	v28, v28, v29
    1e80:      	mov.16b	v29, v13
    1e84:      	fmla.4s	v29, v20, v23
    1e88:      	ldr	q12, [sp, #0x220]
    1e8c:      	fmul.4s	v23, v30, v12
    1e90:      	mov.16b	v30, v31
    1e94:      	ldr	q31, [sp, #0x120]
    1e98:      	fadd.4s	v23, v28, v23
    1e9c:      	fmul.4s	v26, v26, v12
    1ea0:      	fadd.4s	v25, v25, v26
    1ea4:      	mov.16b	v26, v13
    1ea8:      	fmla.4s	v26, v20, v27
    1eac:      	ldr	q27, [sp, #0x1d0]
    1eb0:      	fmul.4s	v20, v25, v27
    1eb4:      	fmul.4s	v27, v23, v27
    1eb8:      	ldr	q28, [sp, #0x1f0]
    1ebc:      	fadd.4s	v27, v27, v28
    1ec0:      	fadd.4s	v20, v20, v28
    1ec4:      	fmul.4s	v20, v25, v20
    1ec8:      	fmul.4s	v28, v5, v29
    1ecc:      	fmul.4s	v27, v23, v27
    1ed0:      	ldr	q29, [sp, #0x210]
    1ed4:      	fadd.4s	v27, v27, v29
    1ed8:      	fadd.4s	v20, v20, v29
    1edc:      	fmul.4s	v20, v25, v20
    1ee0:      	fmul.4s	v27, v23, v27
    1ee4:      	ldr	q29, [sp, #0x1e0]
    1ee8:      	fadd.4s	v27, v27, v29
    1eec:      	fadd.4s	v20, v20, v29
    1ef0:      	fmul.4s	v20, v25, v20
    1ef4:      	fmul.4s	v27, v23, v27
    1ef8:      	fadd.4s	v27, v27, v31
    1efc:      	fadd.4s	v29, v20, v31
    1f00:      	fdiv.4s	v20, v28, v26
    1f04:      	fmul.4s	v26, v25, v29
    1f08:      	movi.4s	v29, #0x3f, lsl #24
    1f0c:      	fmul.4s	v27, v23, v27
    1f10:      	fadd.4s	v27, v27, v29
    1f14:      	fadd.4s	v26, v26, v29
    1f18:      	fmul.4s	v28, v25, v25
    1f1c:      	fmul.4s	v26, v28, v26
    1f20:      	fmul.4s	v28, v23, v23
    1f24:      	fmul.4s	v27, v28, v27
    1f28:      	fadd.4s	v23, v23, v27
    1f2c:      	fadd.4s	v25, v25, v26
    1f30:      	movi.2d	v28, #0xffffffffffffffff
    1f34:      	add.4s	v22, v22, v28
    1f38:      	fadd.4s	v23, v23, v13
    1f3c:      	sshr.4s	v26, v22, #0x1
    1f40:      	shl.4s	v27, v26, #0x17
    1f44:      	add.4s	v27, v27, v13
    1f48:      	fmul.4s	v23, v23, v27
    1f4c:      	movi.2d	v27, #0xffffffffffffffff
    1f50:      	add.4s	v24, v24, v28
    1f54:      	fadd.4s	v25, v25, v13
    1f58:      	sub.4s	v22, v22, v26
    1f5c:      	sshr.4s	v26, v24, #0x1
    1f60:      	sub.4s	v24, v24, v26
    1f64:      	shl.4s	v26, v26, #0x17
    1f68:      	add.4s	v26, v26, v13
    1f6c:      	fmul.4s	v25, v25, v26
    1f70:      	shl.4s	v24, v24, #0x17
    1f74:      	add.4s	v24, v24, v13
    1f78:      	fmul.4s	v24, v25, v24
    1f7c:      	shl.4s	v22, v22, #0x17
    1f80:      	add.4s	v22, v22, v13
    1f84:      	fmul.4s	v22, v23, v22
    1f88:      	mov.16b	v23, v8
    1f8c:      	mov.16b	v8, v0
    1f90:      	fcmgt.4s	v21, v21, v15
    1f94:      	ldr	q0, [sp, #0x160]
    1f98:      	bsl.16b	v21, v0, v22
    1f9c:      	fmul.4s	v7, v6, v7
    1fa0:      	fcmgt.4s	v19, v19, v15
    1fa4:      	bsl.16b	v19, v0, v24
    1fa8:      	fdiv.4s	v7, v7, v18
    1fac:      	ldr	q0, [sp, #0x1c0]
    1fb0:      	fdiv.4s	v18, v0, v19
    1fb4:      	fsub.4s	v22, v19, v18
    1fb8:      	fadd.4s	v18, v19, v18
    1fbc:      	mov.16b	v19, v11
    1fc0:      	fdiv.4s	v18, v22, v18
    1fc4:      	bsl.16b	v17, v18, v13
    1fc8:      	fcmge.4s	v6, v13, v6
    1fcc:      	bsl.16b	v6, v7, v17
    1fd0:      	fdiv.4s	v7, v0, v21
    1fd4:      	fsub.4s	v17, v21, v7
    1fd8:      	fadd.4s	v7, v21, v7
    1fdc:      	mov.16b	v21, v14
    1fe0:      	mov.16b	v14, v9
    1fe4:      	mov.16b	v9, v10
    1fe8:      	fdiv.4s	v7, v17, v7
    1fec:      	bif.16b	v7, v13, v16
    1ff0:      	fcmge.4s	v5, v13, v5
    1ff4:      	bsl.16b	v5, v20, v7
    1ff8:      	mvni.4s	v7, #0x80, lsl #24
    1ffc:      	bif.16b	v5, v4, v7
    2000:      	fcmeq.4s	v4, v4, v4
    2004:      	fadd.4s	v5, v5, v13
    2008:      	ldr	q0, [sp, #0x150]
    200c:      	bsl.16b	v4, v5, v0
    2010:      	mvni.4s	v20, #0x80, lsl #24
    2014:      	mov.16b	v5, v7
    2018:      	bsl.16b	v5, v6, v3
    201c:      	fcmeq.4s	v3, v3, v3
    2020:      	fadd.4s	v5, v5, v13
    2024:      	bsl.16b	v3, v5, v0
    2028:      	fmul.4s	v2, v2, v29
    202c:      	fmul.4s	v2, v2, v3
    2030:      	fmul.4s	v1, v1, v29
    2034:      	fmul.4s	v1, v1, v4
    2038:      	add	x10, x24, x9
    203c:      	ldp	q0, q3, [x10]
    2040:      	fadd.4s	v1, v0, v1
    2044:      	fadd.4s	v2, v3, v2
    2048:      	add	x9, x21, x9
    204c:      	stp	q1, q2, [x9]
    2050:      	add	x8, x8, #0x1
    2054:      	cmp	x8, #0xc0
    2058:      	b.ne	0x1ce0 <ltmp0+0x1ce0>
    205c:      	b	0x1558 <ltmp0+0x1558>
    2060:      	mov	x10, #0x0               ; =0
    2064:      	add	x12, x11, x14
    2068:      	b	0x208c <ltmp0+0x208c>
    206c:      	add	x13, x23, x10, lsl #5
    2070:      	ldp	q25, q26, [x13]
    2074:      	bif.16b	v21, v26, v0
    2078:      	bif.16b	v20, v25, v1
    207c:      	stp	q20, q21, [x13]
    2080:      	add	x10, x10, #0x1
    2084:      	cmp	x10, #0xc0
    2088:      	b.eq	0x2130 <ltmp0+0x2130>
    208c:      	ldr	q18, [x0]
    2090:      	and.16b	v18, v19, v18
    2094:      	addv.8h	h18, v18
    2098:      	fmov	w14, s18
    209c:      	add	x13, x12, x10, lsl #5
    20a0:      	movi.2d	v20, #0000000000000000
    20a4:      	movi.2d	v21, #0000000000000000
    20a8:      	tbnz	w14, #0x0, 0x20d0 <ltmp0+0x20d0>
    20ac:      	and	w14, w14, #0xff
    20b0:      	tbnz	w14, #0x1, 0x20dc <ltmp0+0x20dc>
    20b4:      	tbnz	w14, #0x2, 0x20e8 <ltmp0+0x20e8>
    20b8:      	tbnz	w14, #0x3, 0x20f4 <ltmp0+0x20f4>
    20bc:      	tbnz	w14, #0x4, 0x2100 <ltmp0+0x2100>
    20c0:      	tbnz	w14, #0x5, 0x210c <ltmp0+0x210c>
    20c4:      	tbnz	w14, #0x6, 0x2118 <ltmp0+0x2118>
    20c8:      	tbz	w14, #0x7, 0x206c <ltmp0+0x206c>
    20cc:      	b	0x2124 <ltmp0+0x2124>
    20d0:      	ldr	s20, [x13]
    20d4:      	and	w14, w14, #0xff
    20d8:      	tbz	w14, #0x1, 0x20b4 <ltmp0+0x20b4>
    20dc:      	add	x15, x13, #0x4
    20e0:      	ld1.s	{ v20 }[1], [x15]
    20e4:      	tbz	w14, #0x2, 0x20b8 <ltmp0+0x20b8>
    20e8:      	add	x15, x13, #0x8
    20ec:      	ld1.s	{ v20 }[2], [x15]
    20f0:      	tbz	w14, #0x3, 0x20bc <ltmp0+0x20bc>
    20f4:      	add	x15, x13, #0xc
    20f8:      	ld1.s	{ v20 }[3], [x15]
    20fc:      	tbz	w14, #0x4, 0x20c0 <ltmp0+0x20c0>
    2100:      	add	x15, x13, #0x10
    2104:      	ld1.s	{ v21 }[0], [x15]
    2108:      	tbz	w14, #0x5, 0x20c4 <ltmp0+0x20c4>
    210c:      	add	x15, x13, #0x14
    2110:      	ld1.s	{ v21 }[1], [x15]
    2114:      	tbz	w14, #0x6, 0x20c8 <ltmp0+0x20c8>
    2118:      	add	x15, x13, #0x18
    211c:      	ld1.s	{ v21 }[2], [x15]
    2120:      	tbz	w14, #0x7, 0x206c <ltmp0+0x206c>
    2124:      	add	x13, x13, #0x1c
    2128:      	ld1.s	{ v21 }[3], [x13]
    212c:      	b	0x206c <ltmp0+0x206c>
    2130:      	xtn.8b	v20, v19
    2134:      	movi	d5, #0x0000000000ffff
    2138:      	and.8b	v19, v20, v5
    213c:      	adrp	x10, 0x2000 <ltmp0+0x2000>
    2140:      	ldr	d21, [x10]
    2144:      	and.8b	v20, v20, v21
    2148:      	addv.8b	b20, v20
    214c:      	fmov	w13, s20
    2150:      	umaxv.8b	b20, v19
    2154:      	fmov	w10, s20
    2158:      	rbit	w12, w13
    215c:      	clz	w12, w12
    2160:      	tst	w10, #0x1
    2164:      	csel	w10, w12, wzr, ne
    2168:      	mov	w12, #0x600             ; =1536
    216c:      	dup.2d	v25, x12
    2170:      	umlal.2d	v22, v28, v6
    2174:      	mov	b21, v19[0]
    2178:      	mov.b	v21[4], v19[1]
    217c:      	add.2d	v5, v22, v25
    2180:      	ushll.2d	v17, v21, #0x0
    2184:      	shl.2d	v17, v17, #0x3f
    2188:      	cmlt.2d	v17, v17, #0
    218c:      	str	q5, [sp, #0xa0]
    2190:      	and.16b	v17, v17, v5
    2194:      	movi.2d	v5, #0000000000000000
    2198:      	stp	q5, q5, [sp, #0x3a0]
    219c:      	stp	q17, q5, [sp, #0x380]
    21a0:      	and	x12, x10, #0x7
    21a4:      	add	x14, sp, #0x380
    21a8:      	ldr	x12, [x14, x12, lsl #3]
    21ac:      	sub	x12, x12, x10
    21b0:      	lsl	x12, x12, #2
    21b4:      	add	x11, x11, x12
    21b8:      	movi.2d	v21, #0000000000000000
    21bc:      	movi.2d	v17, #0000000000000000
    21c0:      	tbnz	w13, #0x0, 0x31d8 <ltmp0+0x31d8>
    21c4:      	tbnz	w13, #0x1, 0x31e0 <ltmp0+0x31e0>
    21c8:      	tbnz	w13, #0x2, 0x31ec <ltmp0+0x31ec>
    21cc:      	tbnz	w13, #0x3, 0x31f8 <ltmp0+0x31f8>
    21d0:      	tbnz	w13, #0x4, 0x3204 <ltmp0+0x3204>
    21d4:      	tbnz	w13, #0x5, 0x3210 <ltmp0+0x3210>
    21d8:      	tbnz	w13, #0x6, 0x321c <ltmp0+0x321c>
    21dc:      	tbz	w13, #0x7, 0x21e8 <ltmp0+0x21e8>
    21e0:      	add	x11, x11, #0x1c
    21e4:      	ld1.s	{ v17 }[3], [x11]
    21e8:      	mov	x15, #0x0               ; =0
    21ec:      	umull.2d	v22, v28, v6
    21f0:      	umlal.2d	v4, v16, v6
    21f4:      	add.2d	v4, v4, v25
    21f8:      	umlal.2d	v3, v7, v6
    21fc:      	add.2d	v3, v3, v25
    2200:      	stp	q3, q4, [sp, #0x80]
    2204:      	umlal.2d	v2, v27, v6
    2208:      	adrp	x11, 0x2000 <ltmp0+0x2000>
    220c:      	ldr	q5, [x11]
    2210:      	mov	w11, #0x1800            ; =6144
    2214:      	dup.2d	v6, x11
    2218:      	sshll.2d	v7, v1, #0x0
    221c:      	bif.16b	v5, v6, v7
    2220:      	adrp	x11, 0x2000 <ltmp0+0x2000>
    2224:      	ldr	q7, [x11]
    2228:      	sshll.2d	v16, v0, #0x0
    222c:      	bif.16b	v7, v6, v16
    2230:      	adrp	x11, 0x2000 <ltmp0+0x2000>
    2234:      	ldr	q16, [x11]
    2238:      	bif.16b	v16, v6, v24
    223c:      	adrp	x11, 0x2000 <ltmp0+0x2000>
    2240:      	ldr	q24, [x11]
    2244:      	bit.16b	v6, v24, v23
    2248:      	stp	q7, q6, [sp, #0x360]
    224c:      	stp	q5, q16, [sp, #0x340]
    2250:      	and	x11, x10, #0x7
    2254:      	add	x14, sp, #0x340
    2258:      	ldr	x11, [x14, x11, lsl #3]
    225c:      	add.2d	v2, v2, v25
    2260:      	str	q2, [sp, #0x70]
    2264:      	sub	x11, x11, x10, lsl #2
    2268:      	tst	w13, #0xff
    226c:      	csel	x11, xzr, x11, eq
    2270:      	add	x13, x23, x11
    2274:      	ldp	q5, q6, [x13]
    2278:      	zip2.8b	v7, v19, v0
    227c:      	ushll.4s	v7, v7, #0x0
    2280:      	shl.4s	v7, v7, #0x1f
    2284:      	cmlt.4s	v7, v7, #0
    2288:      	bit.16b	v6, v17, v7
    228c:      	zip1.8b	v7, v19, v0
    2290:      	ushll.4s	v7, v7, #0x0
    2294:      	shl.4s	v7, v7, #0x1f
    2298:      	cmlt.4s	v7, v7, #0
    229c:      	bit.16b	v5, v21, v7
    22a0:      	stp	q5, q6, [x13]
    22a4:      	fmov	x13, d22
    22a8:      	lsl	x13, x13, #2
    22ac:      	mov	w14, #0x1               ; =1
    22b0:      	dup.2d	v5, x14
    22b4:      	add	x14, x9, x13
    22b8:      	ushll2.2d	v6, v0, #0x0
    22bc:      	and.16b	v6, v6, v5
    22c0:      	ushll2.2d	v7, v1, #0x0
    22c4:      	and.16b	v7, v7, v5
    22c8:      	ushll.2d	v16, v0, #0x0
    22cc:      	and.16b	v16, v16, v5
    22d0:      	ushll.2d	v22, v1, #0x0
    22d4:      	and.16b	v22, v22, v5
    22d8:      	movi.2d	v5, #0000000000000000
    22dc:      	movi.2d	v23, #0000000000000000
    22e0:      	movi.2d	v24, #0000000000000000
    22e4:      	movi.2d	v25, #0000000000000000
    22e8:      	b	0x231c <ltmp0+0x231c>
    22ec:      	add	x15, x24, x15
    22f0:      	ldp	q28, q29, [x15]
    22f4:      	bif.16b	v27, v29, v0
    22f8:      	bif.16b	v26, v28, v1
    22fc:      	stp	q26, q27, [x15]
    2300:      	add.2d	v23, v23, v7
    2304:      	add.2d	v24, v24, v16
    2308:      	add.2d	v25, v25, v6
    230c:      	add.2d	v5, v5, v22
    2310:      	fmov	x15, d5
    2314:      	cmp	x15, #0xc0
    2318:      	b.ge	0x23b8 <ltmp0+0x23b8>
    231c:      	fmov	w17, s18
    2320:      	lsl	x15, x15, #5
    2324:      	add	x16, x14, x15
    2328:      	movi.2d	v26, #0000000000000000
    232c:      	movi.2d	v27, #0000000000000000
    2330:      	tbnz	w17, #0x0, 0x2358 <ltmp0+0x2358>
    2334:      	and	w17, w17, #0xff
    2338:      	tbnz	w17, #0x1, 0x2364 <ltmp0+0x2364>
    233c:      	tbnz	w17, #0x2, 0x2370 <ltmp0+0x2370>
    2340:      	tbnz	w17, #0x3, 0x237c <ltmp0+0x237c>
    2344:      	tbnz	w17, #0x4, 0x2388 <ltmp0+0x2388>
    2348:      	tbnz	w17, #0x5, 0x2394 <ltmp0+0x2394>
    234c:      	tbnz	w17, #0x6, 0x23a0 <ltmp0+0x23a0>
    2350:      	tbz	w17, #0x7, 0x22ec <ltmp0+0x22ec>
    2354:      	b	0x23ac <ltmp0+0x23ac>
    2358:      	ldr	s26, [x16]
    235c:      	and	w17, w17, #0xff
    2360:      	tbz	w17, #0x1, 0x233c <ltmp0+0x233c>
    2364:      	add	x0, x16, #0x4
    2368:      	ld1.s	{ v26 }[1], [x0]
    236c:      	tbz	w17, #0x2, 0x2340 <ltmp0+0x2340>
    2370:      	add	x0, x16, #0x8
    2374:      	ld1.s	{ v26 }[2], [x0]
    2378:      	tbz	w17, #0x3, 0x2344 <ltmp0+0x2344>
    237c:      	add	x0, x16, #0xc
    2380:      	ld1.s	{ v26 }[3], [x0]
    2384:      	tbz	w17, #0x4, 0x2348 <ltmp0+0x2348>
    2388:      	add	x0, x16, #0x10
    238c:      	ld1.s	{ v27 }[0], [x0]
    2390:      	tbz	w17, #0x5, 0x234c <ltmp0+0x234c>
    2394:      	add	x0, x16, #0x14
    2398:      	ld1.s	{ v27 }[1], [x0]
    239c:      	tbz	w17, #0x6, 0x2350 <ltmp0+0x2350>
    23a0:      	add	x0, x16, #0x18
    23a4:      	ld1.s	{ v27 }[2], [x0]
    23a8:      	tbz	w17, #0x7, 0x22ec <ltmp0+0x22ec>
    23ac:      	add	x16, x16, #0x1c
    23b0:      	ld1.s	{ v27 }[3], [x16]
    23b4:      	b	0x22ec <ltmp0+0x22ec>
    23b8:      	add	x9, x9, x12
    23bc:      	adrp	x12, 0x2000 <ltmp0+0x2000>
    23c0:      	ldr	d5, [x12]
    23c4:      	shl.8b	v23, v19, #0x7
    23c8:      	cmlt.8b	v23, v23, #0
    23cc:      	and.8b	v5, v23, v5
    23d0:      	addv.8b	b2, v5
    23d4:      	str	d2, [sp, #0x58]
    23d8:      	fmov	w12, s2
    23dc:      	movi.2d	v23, #0000000000000000
    23e0:      	movi.2d	v2, #0000000000000000
    23e4:      	tbnz	w12, #0x0, 0x322c <ltmp0+0x322c>
    23e8:      	tbnz	w12, #0x1, 0x3234 <ltmp0+0x3234>
    23ec:      	tbnz	w12, #0x2, 0x3240 <ltmp0+0x3240>
    23f0:      	tbnz	w12, #0x3, 0x324c <ltmp0+0x324c>
    23f4:      	tbnz	w12, #0x4, 0x3258 <ltmp0+0x3258>
    23f8:      	tbnz	w12, #0x5, 0x3264 <ltmp0+0x3264>
    23fc:      	tbnz	w12, #0x6, 0x3270 <ltmp0+0x3270>
    2400:      	movi.2d	v20, #0xffffffffffffffff
    2404:      	movi.4s	v3, #0xcb, lsl #24
    2408:      	tbz	w12, #0x7, 0x2414 <ltmp0+0x2414>
    240c:      	add	x9, x9, #0x1c
    2410:      	ld1.s	{ v2 }[3], [x9]
    2414:      	mov	x12, #0x0               ; =0
    2418:      	add	x9, x24, x11
    241c:      	ldp	q25, q26, [x9]
    2420:      	zip2.8b	v27, v19, v0
    2424:      	ushll.4s	v27, v27, #0x0
    2428:      	shl.4s	v27, v27, #0x1f
    242c:      	cmlt.4s	v27, v27, #0
    2430:      	str	q2, [sp, #0x60]
    2434:      	bit.16b	v26, v2, v27
    2438:      	zip1.8b	v27, v19, v0
    243c:      	ushll.4s	v27, v27, #0x0
    2440:      	shl.4s	v27, v27, #0x1f
    2444:      	cmlt.4s	v27, v27, #0
    2448:      	bit.16b	v25, v23, v27
    244c:      	stp	q25, q26, [x9]
    2450:      	add	x9, x8, x13
    2454:      	movi.2d	v25, #0000000000000000
    2458:      	movi.2d	v26, #0000000000000000
    245c:      	movi.2d	v27, #0000000000000000
    2460:      	movi.2d	v28, #0000000000000000
    2464:      	b	0x2484 <ltmp0+0x2484>
    2468:      	add.2d	v26, v26, v7
    246c:      	add.2d	v27, v27, v16
    2470:      	add.2d	v28, v28, v6
    2474:      	add.2d	v25, v25, v22
    2478:      	fmov	x12, d25
    247c:      	cmp	x12, #0xc0
    2480:      	b.ge	0x28bc <ltmp0+0x28bc>
    2484:      	lsl	x11, x12, #5
    2488:      	add	x12, x23, x11
    248c:      	ldr	q29, [x12]
    2490:      	and.16b	v29, v1, v29
    2494:      	ldp	q4, q2, [sp, #0xb0]
    2498:      	fmul.4s	v30, v29, v4
    249c:      	fmul.4s	v30, v29, v30
    24a0:      	fmul.4s	v30, v29, v30
    24a4:      	fadd.4s	v30, v29, v30
    24a8:      	fmul.4s	v30, v30, v8
    24ac:      	and.16b	v30, v1, v30
    24b0:      	fabs.4s	v31, v30
    24b4:      	fmul.4s	v9, v30, v30
    24b8:      	ldr	q10, [sp, #0x140]
    24bc:      	fmla.4s	v10, v9, v2
    24c0:      	ldr	q11, [sp, #0xf0]
    24c4:      	fmla.4s	v11, v9, v10
    24c8:      	ldp	q10, q4, [sp, #0x110]
    24cc:      	fmla.4s	v10, v9, v11
    24d0:      	ldr	q11, [sp, #0x130]
    24d4:      	fmla.4s	v11, v9, v10
    24d8:      	mov.16b	v10, v4
    24dc:      	fmla.4s	v10, v9, v11
    24e0:      	mov.16b	v11, v13
    24e4:      	fmla.4s	v11, v9, v10
    24e8:      	fmul.4s	v10, v31, v11
    24ec:      	ldr	q11, [sp, #0x250]
    24f0:      	ldr	q12, [sp, #0x180]
    24f4:      	fmla.4s	v11, v9, v12
    24f8:      	ldr	q12, [sp, #0x1b0]
    24fc:      	fmla.4s	v12, v9, v11
    2500:      	ldr	q11, [sp, #0x1a0]
    2504:      	fmla.4s	v11, v9, v12
    2508:      	ldr	q12, [sp, #0x190]
    250c:      	fmla.4s	v12, v9, v11
    2510:      	movi.4s	v11, #0x3f, lsl #24
    2514:      	fmla.4s	v11, v9, v12
    2518:      	mov.16b	v12, v13
    251c:      	fmla.4s	v12, v9, v11
    2520:      	fdiv.4s	v9, v10, v12
    2524:      	ldr	q10, [sp, #0x170]
    2528:      	fcmge.4s	v10, v10, v31
    252c:      	and.16b	v11, v10, v31
    2530:      	ldr	q12, [sp, #0x240]
    2534:      	fcmge.4s	v12, v11, v12
    2538:      	ldr	q2, [sp, #0xd0]
    253c:      	fcmge.4s	v13, v2, v11
    2540:      	and.16b	v12, v12, v13
    2544:      	and.16b	v12, v12, v11
    2548:      	ldr	q13, [sp, #0x230]
    254c:      	fmul.4s	v13, v12, v13
    2550:      	movi.4s	v14, #0x4b, lsl #24
    2554:      	fadd.4s	v13, v13, v14
    2558:      	fadd.4s	v13, v13, v3
    255c:      	fcvtzs.4s	v13, v13
    2560:      	scvtf.4s	v14, v13
    2564:      	ldr	q15, [sp, #0x200]
    2568:      	fmul.4s	v15, v14, v15
    256c:      	fadd.4s	v12, v12, v15
    2570:      	ldr	q15, [sp, #0x220]
    2574:      	fmul.4s	v14, v14, v15
    2578:      	fadd.4s	v12, v12, v14
    257c:      	ldr	q8, [sp, #0x1d0]
    2580:      	fmul.4s	v14, v12, v8
    2584:      	ldr	q8, [sp, #0x1f0]
    2588:      	fadd.4s	v14, v14, v8
    258c:      	fmul.4s	v14, v12, v14
    2590:      	ldr	q8, [sp, #0x210]
    2594:      	fadd.4s	v14, v14, v8
    2598:      	fmul.4s	v14, v12, v14
    259c:      	ldr	q8, [sp, #0x1e0]
    25a0:      	fadd.4s	v14, v14, v8
    25a4:      	fmul.4s	v14, v12, v14
    25a8:      	fadd.4s	v14, v14, v4
    25ac:      	fmul.4s	v14, v12, v14
    25b0:      	movi.4s	v8, #0x3f, lsl #24
    25b4:      	fadd.4s	v14, v14, v8
    25b8:      	fmul.4s	v15, v12, v12
    25bc:      	fmul.4s	v14, v15, v14
    25c0:      	fadd.4s	v12, v12, v14
    25c4:      	ldr	q14, [sp, #0xe0]
    25c8:      	fadd.4s	v12, v12, v14
    25cc:      	add.4s	v13, v13, v20
    25d0:      	sshr.4s	v14, v13, #0x1
    25d4:      	shl.4s	v15, v14, #0x17
    25d8:      	ldr	q4, [sp, #0xe0]
    25dc:      	add.4s	v15, v15, v4
    25e0:      	fmul.4s	v12, v12, v15
    25e4:      	sub.4s	v13, v13, v14
    25e8:      	shl.4s	v13, v13, #0x17
    25ec:      	ldr	q4, [sp, #0xe0]
    25f0:      	add.4s	v13, v13, v4
    25f4:      	fmul.4s	v12, v12, v13
    25f8:      	fcmgt.4s	v11, v11, v2
    25fc:      	ldr	q2, [sp, #0x160]
    2600:      	bsl.16b	v11, v2, v12
    2604:      	ldr	q2, [sp, #0x1c0]
    2608:      	fdiv.4s	v12, v2, v11
    260c:      	fsub.4s	v13, v11, v12
    2610:      	fadd.4s	v11, v11, v12
    2614:      	fdiv.4s	v11, v13, v11
    2618:      	ldr	q13, [sp, #0xe0]
    261c:      	bsl.16b	v10, v11, v13
    2620:      	fcmge.4s	v31, v13, v31
    2624:      	bsl.16b	v31, v9, v10
    2628:      	mvni.4s	v2, #0x80, lsl #24
    262c:      	bif.16b	v31, v30, v2
    2630:      	fcmeq.4s	v30, v30, v30
    2634:      	fadd.4s	v31, v31, v13
    2638:      	ldr	q2, [sp, #0x150]
    263c:      	bif.16b	v31, v2, v30
    2640:      	ldr	q30, [x12, #0x10]
    2644:      	fmul.4s	v29, v29, v8
    2648:      	fmul.4s	v29, v29, v31
    264c:      	add	x12, x24, x11
    2650:      	ldr	q31, [x12]
    2654:      	and.16b	v31, v1, v31
    2658:      	fadd.4s	v31, v31, v29
    265c:      	ldr	q29, [x12, #0x10]
    2660:      	fmov	w12, s18
    2664:      	add	x11, x9, x11
    2668:      	tbnz	w12, #0x0, 0x2858 <ltmp0+0x2858>
    266c:      	and	w12, w12, #0xff
    2670:      	tbnz	w12, #0x1, 0x2864 <ltmp0+0x2864>
    2674:      	ldp	q4, q12, [sp, #0xb0]
    2678:      	ldr	q8, [sp, #0x100]
    267c:      	ldr	q11, [sp, #0x140]
    2680:      	tbnz	w12, #0x2, 0x287c <ltmp0+0x287c>
    2684:      	tbz	w12, #0x3, 0x2690 <ltmp0+0x2690>
    2688:      	add	x13, x11, #0xc
    268c:      	st1.s	{ v31 }[3], [x13]
    2690:      	and.16b	v30, v0, v30
    2694:      	fmul.4s	v31, v30, v4
    2698:      	fmul.4s	v31, v30, v31
    269c:      	fmul.4s	v31, v30, v31
    26a0:      	fadd.4s	v31, v30, v31
    26a4:      	fmul.4s	v31, v31, v8
    26a8:      	and.16b	v31, v0, v31
    26ac:      	fabs.4s	v9, v31
    26b0:      	fmul.4s	v10, v31, v31
    26b4:      	fmla.4s	v11, v10, v12
    26b8:      	ldr	q12, [sp, #0xf0]
    26bc:      	fmla.4s	v12, v10, v11
    26c0:      	ldp	q11, q4, [sp, #0x110]
    26c4:      	fmla.4s	v11, v10, v12
    26c8:      	ldr	q12, [sp, #0x130]
    26cc:      	fmla.4s	v12, v10, v11
    26d0:      	mov.16b	v11, v4
    26d4:      	fmla.4s	v11, v10, v12
    26d8:      	mov.16b	v12, v13
    26dc:      	fmla.4s	v12, v10, v11
    26e0:      	fmul.4s	v11, v9, v12
    26e4:      	ldr	q12, [sp, #0x250]
    26e8:      	ldp	q8, q2, [sp, #0x170]
    26ec:      	fmla.4s	v12, v10, v2
    26f0:      	ldr	q13, [sp, #0x1b0]
    26f4:      	fmla.4s	v13, v10, v12
    26f8:      	ldr	q12, [sp, #0x1a0]
    26fc:      	fmla.4s	v12, v10, v13
    2700:      	ldr	q13, [sp, #0x190]
    2704:      	fmla.4s	v13, v10, v12
    2708:      	movi.4s	v12, #0x3f, lsl #24
    270c:      	fmla.4s	v12, v10, v13
    2710:      	ldp	q2, q13, [sp, #0xd0]
    2714:      	fmla.4s	v13, v10, v12
    2718:      	fdiv.4s	v10, v11, v13
    271c:      	fcmge.4s	v11, v8, v9
    2720:      	and.16b	v12, v11, v9
    2724:      	ldp	q8, q5, [sp, #0x230]
    2728:      	fcmge.4s	v13, v12, v5
    272c:      	fcmge.4s	v14, v2, v12
    2730:      	and.16b	v13, v13, v14
    2734:      	and.16b	v13, v13, v12
    2738:      	fmul.4s	v14, v13, v8
    273c:      	movi.4s	v8, #0x4b, lsl #24
    2740:      	fadd.4s	v14, v14, v8
    2744:      	fadd.4s	v14, v14, v3
    2748:      	fcvtzs.4s	v14, v14
    274c:      	scvtf.4s	v15, v14
    2750:      	ldr	q8, [sp, #0x200]
    2754:      	fmul.4s	v8, v15, v8
    2758:      	fadd.4s	v8, v13, v8
    275c:      	ldr	q13, [sp, #0x220]
    2760:      	fmul.4s	v13, v15, v13
    2764:      	fadd.4s	v8, v8, v13
    2768:      	ldr	q13, [sp, #0x1d0]
    276c:      	fmul.4s	v13, v8, v13
    2770:      	ldr	q15, [sp, #0x1f0]
    2774:      	fadd.4s	v13, v13, v15
    2778:      	fmul.4s	v13, v8, v13
    277c:      	ldr	q15, [sp, #0x210]
    2780:      	fadd.4s	v13, v13, v15
    2784:      	fmul.4s	v13, v8, v13
    2788:      	ldr	q15, [sp, #0x1e0]
    278c:      	fadd.4s	v13, v13, v15
    2790:      	fmul.4s	v13, v8, v13
    2794:      	fadd.4s	v13, v13, v4
    2798:      	fmul.4s	v13, v8, v13
    279c:      	movi.4s	v15, #0x3f, lsl #24
    27a0:      	fadd.4s	v13, v13, v15
    27a4:      	fmul.4s	v15, v8, v8
    27a8:      	fmul.4s	v13, v15, v13
    27ac:      	fadd.4s	v8, v8, v13
    27b0:      	ldr	q13, [sp, #0xe0]
    27b4:      	fadd.4s	v8, v8, v13
    27b8:      	add.4s	v13, v14, v20
    27bc:      	sshr.4s	v14, v13, #0x1
    27c0:      	shl.4s	v15, v14, #0x17
    27c4:      	ldr	q4, [sp, #0xe0]
    27c8:      	add.4s	v15, v15, v4
    27cc:      	fmul.4s	v8, v8, v15
    27d0:      	sub.4s	v13, v13, v14
    27d4:      	shl.4s	v13, v13, #0x17
    27d8:      	ldr	q4, [sp, #0xe0]
    27dc:      	add.4s	v13, v13, v4
    27e0:      	fmul.4s	v8, v8, v13
    27e4:      	fcmgt.4s	v12, v12, v2
    27e8:      	ldr	q2, [sp, #0x160]
    27ec:      	bit.16b	v8, v2, v12
    27f0:      	ldr	q2, [sp, #0x1c0]
    27f4:      	fdiv.4s	v12, v2, v8
    27f8:      	fsub.4s	v13, v8, v12
    27fc:      	fadd.4s	v8, v8, v12
    2800:      	fdiv.4s	v8, v13, v8
    2804:      	ldr	q13, [sp, #0xe0]
    2808:      	bif.16b	v8, v13, v11
    280c:      	fcmge.4s	v9, v13, v9
    2810:      	bit.16b	v8, v10, v9
    2814:      	mvni.4s	v2, #0x80, lsl #24
    2818:      	bif.16b	v8, v31, v2
    281c:      	fcmeq.4s	v31, v31, v31
    2820:      	fadd.4s	v8, v8, v13
    2824:      	ldr	q2, [sp, #0x150]
    2828:      	bsl.16b	v31, v8, v2
    282c:      	movi.4s	v2, #0x3f, lsl #24
    2830:      	fmul.4s	v30, v30, v2
    2834:      	fmul.4s	v30, v30, v31
    2838:      	and.16b	v29, v0, v29
    283c:      	fadd.4s	v29, v29, v30
    2840:      	tbnz	w12, #0x4, 0x288c <ltmp0+0x288c>
    2844:      	tbnz	w12, #0x5, 0x2894 <ltmp0+0x2894>
    2848:      	ldr	q8, [sp, #0x100]
    284c:      	tbnz	w12, #0x6, 0x28a4 <ltmp0+0x28a4>
    2850:      	tbz	w12, #0x7, 0x2468 <ltmp0+0x2468>
    2854:      	b	0x28b0 <ltmp0+0x28b0>
    2858:      	str	s31, [x11]
    285c:      	and	w12, w12, #0xff
    2860:      	tbz	w12, #0x1, 0x2674 <ltmp0+0x2674>
    2864:      	add	x13, x11, #0x4
    2868:      	st1.s	{ v31 }[1], [x13]
    286c:      	ldp	q4, q12, [sp, #0xb0]
    2870:      	ldr	q8, [sp, #0x100]
    2874:      	ldr	q11, [sp, #0x140]
    2878:      	tbz	w12, #0x2, 0x2684 <ltmp0+0x2684>
    287c:      	add	x13, x11, #0x8
    2880:      	st1.s	{ v31 }[2], [x13]
    2884:      	tbnz	w12, #0x3, 0x2688 <ltmp0+0x2688>
    2888:      	b	0x2690 <ltmp0+0x2690>
    288c:      	str	s29, [x11, #0x10]
    2890:      	tbz	w12, #0x5, 0x2848 <ltmp0+0x2848>
    2894:      	add	x13, x11, #0x14
    2898:      	st1.s	{ v29 }[1], [x13]
    289c:      	ldr	q8, [sp, #0x100]
    28a0:      	tbz	w12, #0x6, 0x2850 <ltmp0+0x2850>
    28a4:      	add	x13, x11, #0x18
    28a8:      	st1.s	{ v29 }[2], [x13]
    28ac:      	tbz	w12, #0x7, 0x2468 <ltmp0+0x2468>
    28b0:      	add	x11, x11, #0x1c
    28b4:      	st1.s	{ v29 }[3], [x11]
    28b8:      	b	0x2468 <ltmp0+0x2468>
    28bc:      	ldp	q0, q2, [sp, #0xb0]
    28c0:      	fmul.4s	v0, v21, v0
    28c4:      	fmul.4s	v0, v21, v0
    28c8:      	fmul.4s	v0, v21, v0
    28cc:      	fadd.4s	v0, v21, v0
    28d0:      	mov.16b	v24, v8
    28d4:      	fmul.4s	v0, v0, v8
    28d8:      	zip1.8b	v1, v19, v0
    28dc:      	ushll.4s	v1, v1, #0x0
    28e0:      	shl.4s	v1, v1, #0x1f
    28e4:      	cmlt.4s	v1, v1, #0
    28e8:      	and.16b	v0, v1, v0
    28ec:      	fabs.4s	v1, v0
    28f0:      	fmul.4s	v6, v0, v0
    28f4:      	ldr	q7, [sp, #0x140]
    28f8:      	fmla.4s	v7, v6, v2
    28fc:      	ldr	q14, [sp, #0xf0]
    2900:      	mov.16b	v16, v14
    2904:      	fmla.4s	v16, v6, v7
    2908:      	ldp	q7, q20, [sp, #0x110]
    290c:      	mov.16b	v30, v7
    2910:      	fmla.4s	v7, v6, v16
    2914:      	ldr	q16, [sp, #0x130]
    2918:      	mov.16b	v5, v16
    291c:      	fmla.4s	v16, v6, v7
    2920:      	mov.16b	v7, v20
    2924:      	fmla.4s	v7, v6, v16
    2928:      	mov.16b	v16, v13
    292c:      	fmla.4s	v16, v6, v7
    2930:      	fmul.4s	v7, v1, v16
    2934:      	ldp	q4, q16, [sp, #0x240]
    2938:      	ldp	q28, q27, [sp, #0x170]
    293c:      	fmla.4s	v16, v6, v27
    2940:      	ldr	q29, [sp, #0x1b0]
    2944:      	mov.16b	v18, v29
    2948:      	fmla.4s	v18, v6, v16
    294c:      	ldr	q16, [sp, #0x1a0]
    2950:      	fmla.4s	v16, v6, v18
    2954:      	ldr	q18, [sp, #0x190]
    2958:      	fmla.4s	v18, v6, v16
    295c:      	movi.4s	v16, #0x3f, lsl #24
    2960:      	fmla.4s	v16, v6, v18
    2964:      	mov.16b	v18, v13
    2968:      	fmla.4s	v18, v6, v16
    296c:      	fdiv.4s	v6, v7, v18
    2970:      	fcmge.4s	v7, v28, v1
    2974:      	and.16b	v16, v7, v1
    2978:      	fcmge.4s	v18, v16, v4
    297c:      	ldr	q2, [sp, #0xd0]
    2980:      	fcmge.4s	v22, v2, v16
    2984:      	and.16b	v18, v18, v22
    2988:      	and.16b	v18, v18, v16
    298c:      	ldr	q3, [sp, #0x230]
    2990:      	fmul.4s	v22, v18, v3
    2994:      	movi.4s	v4, #0x4b, lsl #24
    2998:      	fadd.4s	v22, v22, v4
    299c:      	movi.4s	v3, #0xcb, lsl #24
    29a0:      	fadd.4s	v22, v22, v3
    29a4:      	fcvtzs.4s	v22, v22
    29a8:      	scvtf.4s	v25, v22
    29ac:      	ldr	q3, [sp, #0x200]
    29b0:      	mov.16b	v8, v3
    29b4:      	fmul.4s	v26, v25, v3
    29b8:      	fadd.4s	v18, v18, v26
    29bc:      	ldr	q3, [sp, #0x220]
    29c0:      	fmul.4s	v25, v25, v3
    29c4:      	fadd.4s	v18, v18, v25
    29c8:      	ldp	q3, q31, [sp, #0x1d0]
    29cc:      	mov.16b	v11, v3
    29d0:      	fmul.4s	v25, v18, v3
    29d4:      	ldr	q3, [sp, #0x1f0]
    29d8:      	mov.16b	v10, v3
    29dc:      	fadd.4s	v25, v25, v3
    29e0:      	fmul.4s	v25, v18, v25
    29e4:      	ldr	q3, [sp, #0x210]
    29e8:      	fadd.4s	v25, v25, v3
    29ec:      	fmul.4s	v25, v18, v25
    29f0:      	fadd.4s	v25, v25, v31
    29f4:      	fmul.4s	v25, v18, v25
    29f8:      	mov.16b	v15, v20
    29fc:      	fadd.4s	v25, v25, v20
    2a00:      	fmul.4s	v25, v18, v25
    2a04:      	movi.4s	v3, #0x3f, lsl #24
    2a08:      	fadd.4s	v25, v25, v3
    2a0c:      	fmul.4s	v26, v18, v18
    2a10:      	fmul.4s	v25, v26, v25
    2a14:      	fadd.4s	v18, v18, v25
    2a18:      	fadd.4s	v18, v18, v13
    2a1c:      	movi.2d	v12, #0xffffffffffffffff
    2a20:      	add.4s	v22, v22, v12
    2a24:      	sshr.4s	v25, v22, #0x1
    2a28:      	shl.4s	v26, v25, #0x17
    2a2c:      	add.4s	v26, v26, v13
    2a30:      	fmul.4s	v18, v18, v26
    2a34:      	sub.4s	v22, v22, v25
    2a38:      	shl.4s	v22, v22, #0x17
    2a3c:      	add.4s	v22, v22, v13
    2a40:      	fmul.4s	v18, v18, v22
    2a44:      	fcmgt.4s	v16, v16, v2
    2a48:      	ldr	q2, [sp, #0x160]
    2a4c:      	bsl.16b	v16, v2, v18
    2a50:      	ldr	q9, [sp, #0x1c0]
    2a54:      	fdiv.4s	v18, v9, v16
    2a58:      	fsub.4s	v22, v16, v18
    2a5c:      	fadd.4s	v16, v16, v18
    2a60:      	fdiv.4s	v16, v22, v16
    2a64:      	bsl.16b	v7, v16, v13
    2a68:      	fcmge.4s	v1, v13, v1
    2a6c:      	bsl.16b	v1, v6, v7
    2a70:      	ldr	d2, [sp, #0x58]
    2a74:      	fmov	w9, s2
    2a78:      	mvni.4s	v2, #0x80, lsl #24
    2a7c:      	bif.16b	v1, v0, v2
    2a80:      	fcmeq.4s	v0, v0, v0
    2a84:      	fadd.4s	v1, v1, v13
    2a88:      	ldr	q2, [sp, #0x150]
    2a8c:      	bsl.16b	v0, v1, v2
    2a90:      	fmul.4s	v1, v21, v3
    2a94:      	fmul.4s	v0, v1, v0
    2a98:      	fadd.4s	v0, v0, v23
    2a9c:      	ldp	q1, q2, [sp, #0x90]
    2aa0:      	stp	q2, q1, [sp, #0x2f0]
    2aa4:      	ldp	q1, q2, [sp, #0x70]
    2aa8:      	stp	q2, q1, [sp, #0x310]
    2aac:      	and	x11, x10, #0x7
    2ab0:      	add	x12, sp, #0x2f0
    2ab4:      	ldr	x11, [x12, x11, lsl #3]
    2ab8:      	sub	x10, x11, x10
    2abc:      	add	x8, x8, x10, lsl #2
    2ac0:      	tbz	w9, #0x0, 0x2ac8 <ltmp0+0x2ac8>
    2ac4:      	str	s0, [x8]
    2ac8:      	tbz	w9, #0x1, 0x2ad4 <ltmp0+0x2ad4>
    2acc:      	add	x10, x8, #0x4
    2ad0:      	st1.s	{ v0 }[1], [x10]
    2ad4:      	ldp	q7, q20, [sp, #0x240]
    2ad8:      	ldp	q26, q25, [sp, #0x190]
    2adc:      	movi.4s	v16, #0x4b, lsl #24
    2ae0:      	ldr	q18, [sp, #0x230]
    2ae4:      	ldr	q22, [sp, #0x160]
    2ae8:      	ldp	q1, q23, [sp, #0xb0]
    2aec:      	tbz	w9, #0x2, 0x2af8 <ltmp0+0x2af8>
    2af0:      	add	x10, x8, #0x8
    2af4:      	st1.s	{ v0 }[2], [x10]
    2af8:      	tbz	w9, #0x3, 0x2b04 <ltmp0+0x2b04>
    2afc:      	add	x10, x8, #0xc
    2b00:      	st1.s	{ v0 }[3], [x10]
    2b04:      	fmul.4s	v0, v17, v1
    2b08:      	fmul.4s	v0, v17, v0
    2b0c:      	fmul.4s	v0, v17, v0
    2b10:      	fadd.4s	v0, v17, v0
    2b14:      	fmul.4s	v0, v0, v24
    2b18:      	zip2.8b	v1, v19, v0
    2b1c:      	ushll.4s	v1, v1, #0x0
    2b20:      	shl.4s	v1, v1, #0x1f
    2b24:      	cmlt.4s	v1, v1, #0
    2b28:      	and.16b	v0, v1, v0
    2b2c:      	fabs.4s	v1, v0
    2b30:      	fmul.4s	v2, v0, v0
    2b34:      	ldr	q3, [sp, #0x140]
    2b38:      	fmla.4s	v3, v2, v23
    2b3c:      	mov.16b	v4, v14
    2b40:      	fmla.4s	v4, v2, v3
    2b44:      	mov.16b	v3, v30
    2b48:      	fmla.4s	v3, v2, v4
    2b4c:      	mov.16b	v4, v5
    2b50:      	fmla.4s	v4, v2, v3
    2b54:      	mov.16b	v21, v15
    2b58:      	mov.16b	v3, v15
    2b5c:      	fmla.4s	v3, v2, v4
    2b60:      	mov.16b	v4, v13
    2b64:      	fmla.4s	v4, v2, v3
    2b68:      	fmul.4s	v3, v1, v4
    2b6c:      	mov.16b	v4, v20
    2b70:      	fmla.4s	v4, v2, v27
    2b74:      	mov.16b	v6, v29
    2b78:      	fmla.4s	v6, v2, v4
    2b7c:      	mov.16b	v4, v25
    2b80:      	fmla.4s	v4, v2, v6
    2b84:      	mov.16b	v6, v26
    2b88:      	fmla.4s	v6, v2, v4
    2b8c:      	movi.4s	v4, #0x3f, lsl #24
    2b90:      	fmla.4s	v4, v2, v6
    2b94:      	mov.16b	v6, v13
    2b98:      	fmla.4s	v6, v2, v4
    2b9c:      	fdiv.4s	v2, v3, v6
    2ba0:      	fcmge.4s	v3, v28, v1
    2ba4:      	and.16b	v4, v3, v1
    2ba8:      	fcmge.4s	v6, v4, v7
    2bac:      	ldr	q19, [sp, #0xd0]
    2bb0:      	fcmge.4s	v7, v19, v4
    2bb4:      	and.16b	v6, v6, v7
    2bb8:      	and.16b	v6, v6, v4
    2bbc:      	fmul.4s	v7, v6, v18
    2bc0:      	fadd.4s	v7, v7, v16
    2bc4:      	movi.4s	v16, #0xcb, lsl #24
    2bc8:      	fadd.4s	v7, v7, v16
    2bcc:      	fcvtzs.4s	v7, v7
    2bd0:      	scvtf.4s	v16, v7
    2bd4:      	fmul.4s	v18, v16, v8
    2bd8:      	fadd.4s	v6, v6, v18
    2bdc:      	ldr	q18, [sp, #0x220]
    2be0:      	fmul.4s	v16, v16, v18
    2be4:      	fadd.4s	v6, v6, v16
    2be8:      	fmul.4s	v16, v6, v11
    2bec:      	fadd.4s	v16, v16, v10
    2bf0:      	fmul.4s	v16, v6, v16
    2bf4:      	ldr	q18, [sp, #0x210]
    2bf8:      	fadd.4s	v16, v16, v18
    2bfc:      	fmul.4s	v16, v6, v16
    2c00:      	fadd.4s	v16, v16, v31
    2c04:      	mov.16b	v31, v15
    2c08:      	fmul.4s	v16, v6, v16
    2c0c:      	fadd.4s	v16, v16, v21
    2c10:      	fmul.4s	v16, v6, v16
    2c14:      	movi.4s	v21, #0x3f, lsl #24
    2c18:      	fadd.4s	v16, v16, v21
    2c1c:      	fmul.4s	v18, v6, v6
    2c20:      	fmul.4s	v16, v18, v16
    2c24:      	fadd.4s	v6, v6, v16
    2c28:      	fadd.4s	v6, v6, v13
    2c2c:      	add.4s	v7, v7, v12
    2c30:      	sshr.4s	v16, v7, #0x1
    2c34:      	shl.4s	v18, v16, #0x17
    2c38:      	add.4s	v18, v18, v13
    2c3c:      	fmul.4s	v6, v6, v18
    2c40:      	sub.4s	v7, v7, v16
    2c44:      	shl.4s	v7, v7, #0x17
    2c48:      	add.4s	v7, v7, v13
    2c4c:      	fmul.4s	v6, v6, v7
    2c50:      	fcmgt.4s	v4, v4, v19
    2c54:      	bsl.16b	v4, v22, v6
    2c58:      	fdiv.4s	v6, v9, v4
    2c5c:      	fsub.4s	v7, v4, v6
    2c60:      	fadd.4s	v4, v4, v6
    2c64:      	fdiv.4s	v4, v7, v4
    2c68:      	bsl.16b	v3, v4, v13
    2c6c:      	fcmge.4s	v1, v13, v1
    2c70:      	bsl.16b	v1, v2, v3
    2c74:      	mvni.4s	v2, #0x80, lsl #24
    2c78:      	bif.16b	v1, v0, v2
    2c7c:      	fcmeq.4s	v0, v0, v0
    2c80:      	fadd.4s	v1, v1, v13
    2c84:      	ldr	q18, [sp, #0x150]
    2c88:      	bsl.16b	v0, v1, v18
    2c8c:      	fmul.4s	v1, v17, v21
    2c90:      	fmul.4s	v0, v1, v0
    2c94:      	ldr	q1, [sp, #0x60]
    2c98:      	fadd.4s	v0, v0, v1
    2c9c:      	tbnz	w9, #0x4, 0x3288 <ltmp0+0x3288>
    2ca0:      	tbnz	w9, #0x5, 0x3290 <ltmp0+0x3290>
    2ca4:      	mov.16b	v8, v24
    2ca8:      	ldr	q21, [sp, #0xb0]
    2cac:      	mov.16b	v9, v30
    2cb0:      	tbnz	w9, #0x6, 0x32a8 <ltmp0+0x32a8>
    2cb4:      	mov.16b	v30, v5
    2cb8:      	tbnz	w9, #0x7, 0x1c0 <ltmp0+0x1c0>
    2cbc:      	b	0x1c8 <ltmp0+0x1c8>
    2cc0:      	xtn.8b	v0, v19
    2cc4:      	movi	d1, #0x0000000000ffff
    2cc8:      	and.8b	v1, v0, v1
    2ccc:      	adrp	x10, 0x2000 <ltmp0+0x2000>
    2cd0:      	ldr	d18, [x10]
    2cd4:      	and.8b	v0, v0, v18
    2cd8:      	addv.8b	b0, v0
    2cdc:      	fmov	w12, s0
    2ce0:      	umaxv.8b	b0, v1
    2ce4:      	fmov	w10, s0
    2ce8:      	rbit	w13, w12
    2cec:      	clz	w13, w13
    2cf0:      	tst	w10, #0x1
    2cf4:      	csel	w10, w13, wzr, ne
    2cf8:      	mov	w13, #0x600             ; =1536
    2cfc:      	dup.2d	v18, x13
    2d00:      	umlal.2d	v22, v7, v6
    2d04:      	mov	b0, v1[0]
    2d08:      	mov.b	v0[4], v1[1]
    2d0c:      	add.2d	v30, v22, v18
    2d10:      	ushll.2d	v0, v0, #0x0
    2d14:      	shl.2d	v0, v0, #0x3f
    2d18:      	cmlt.2d	v0, v0, #0
    2d1c:      	and.16b	v0, v0, v30
    2d20:      	movi.2d	v5, #0000000000000000
    2d24:      	stp	q5, q5, [sp, #0x2c0]
    2d28:      	stp	q0, q5, [sp, #0x2a0]
    2d2c:      	and	x13, x10, #0x7
    2d30:      	add	x14, sp, #0x2a0
    2d34:      	ldr	x13, [x14, x13, lsl #3]
    2d38:      	sub	x13, x13, x10
    2d3c:      	lsl	x13, x13, #2
    2d40:      	add	x11, x11, x13
    2d44:      	movi.2d	v20, #0000000000000000
    2d48:      	movi.2d	v0, #0000000000000000
    2d4c:      	tbnz	w12, #0x0, 0x32bc <ltmp0+0x32bc>
    2d50:      	ldr	d2, [sp, #0x80]
    2d54:      	tbnz	w12, #0x1, 0x32c8 <ltmp0+0x32c8>
    2d58:      	tbnz	w12, #0x2, 0x32d4 <ltmp0+0x32d4>
    2d5c:      	tbnz	w12, #0x3, 0x32e0 <ltmp0+0x32e0>
    2d60:      	tbnz	w12, #0x4, 0x32ec <ltmp0+0x32ec>
    2d64:      	tbnz	w12, #0x5, 0x32f8 <ltmp0+0x32f8>
    2d68:      	tbnz	w12, #0x6, 0x3304 <ltmp0+0x3304>
    2d6c:      	tbz	w12, #0x7, 0x2d78 <ltmp0+0x2d78>
    2d70:      	add	x11, x11, #0x1c
    2d74:      	ld1.s	{ v0 }[3], [x11]
    2d78:      	adrp	x11, 0x2000 <ltmp0+0x2000>
    2d7c:      	ldr	d19, [x11]
    2d80:      	shl.8b	v21, v1, #0x7
    2d84:      	cmlt.8b	v21, v21, #0
    2d88:      	and.8b	v19, v21, v19
    2d8c:      	addv.8b	b21, v19
    2d90:      	fmov	w11, s21
    2d94:      	add	x9, x9, x13
    2d98:      	movi.2d	v22, #0000000000000000
    2d9c:      	movi.2d	v19, #0000000000000000
    2da0:      	tbnz	w11, #0x0, 0x3314 <ltmp0+0x3314>
    2da4:      	tbnz	w11, #0x1, 0x331c <ltmp0+0x331c>
    2da8:      	tbnz	w11, #0x2, 0x3328 <ltmp0+0x3328>
    2dac:      	tbnz	w11, #0x3, 0x3334 <ltmp0+0x3334>
    2db0:      	tbnz	w11, #0x4, 0x3340 <ltmp0+0x3340>
    2db4:      	tbnz	w11, #0x5, 0x334c <ltmp0+0x334c>
    2db8:      	tbz	w11, #0x6, 0x2dc4 <ltmp0+0x2dc4>
    2dbc:      	add	x12, x9, #0x18
    2dc0:      	ld1.s	{ v19 }[2], [x12]
    2dc4:      	umlal.2d	v4, v16, v6
    2dc8:      	umlal.2d	v3, v2, v6
    2dcc:      	ldr	q2, [sp, #0xa0]
    2dd0:      	ldr	d5, [sp, #0x90]
    2dd4:      	umlal.2d	v2, v5, v6
    2dd8:      	str	q2, [sp, #0xa0]
    2ddc:      	tbz	w11, #0x7, 0x2de8 <ltmp0+0x2de8>
    2de0:      	add	x9, x9, #0x1c
    2de4:      	ld1.s	{ v19 }[3], [x9]
    2de8:      	ldr	q5, [sp, #0xb0]
    2dec:      	fmul.4s	v5, v20, v5
    2df0:      	fmul.4s	v5, v20, v5
    2df4:      	fmul.4s	v5, v20, v5
    2df8:      	fadd.4s	v5, v20, v5
    2dfc:      	fmul.4s	v5, v5, v8
    2e00:      	zip1.8b	v6, v1, v0
    2e04:      	ushll.4s	v6, v6, #0x0
    2e08:      	shl.4s	v6, v6, #0x1f
    2e0c:      	cmlt.4s	v6, v6, #0
    2e10:      	and.16b	v5, v6, v5
    2e14:      	fabs.4s	v6, v5
    2e18:      	fmul.4s	v7, v5, v5
    2e1c:      	ldr	q16, [sp, #0x140]
    2e20:      	fmla.4s	v16, v7, v23
    2e24:      	mov.16b	v23, v17
    2e28:      	fmla.4s	v23, v7, v16
    2e2c:      	mov.16b	v16, v15
    2e30:      	fmla.4s	v16, v7, v23
    2e34:      	mov.16b	v23, v10
    2e38:      	fmla.4s	v23, v7, v16
    2e3c:      	mov.16b	v16, v11
    2e40:      	fmla.4s	v16, v7, v23
    2e44:      	mov.16b	v23, v13
    2e48:      	fmla.4s	v23, v7, v16
    2e4c:      	fmul.4s	v16, v6, v23
    2e50:      	ldr	q23, [sp, #0x250]
    2e54:      	fmla.4s	v23, v7, v24
    2e58:      	mov.16b	v24, v29
    2e5c:      	fmla.4s	v24, v7, v23
    2e60:      	mov.16b	v23, v25
    2e64:      	fmla.4s	v23, v7, v24
    2e68:      	mov.16b	v24, v26
    2e6c:      	fmla.4s	v24, v7, v23
    2e70:      	movi.4s	v23, #0x3f, lsl #24
    2e74:      	fmla.4s	v23, v7, v24
    2e78:      	mov.16b	v24, v13
    2e7c:      	fmla.4s	v24, v7, v23
    2e80:      	fdiv.4s	v7, v16, v24
    2e84:      	fcmge.4s	v16, v28, v6
    2e88:      	and.16b	v23, v16, v6
    2e8c:      	ldr	q24, [sp, #0x240]
    2e90:      	fcmge.4s	v24, v23, v24
    2e94:      	ldr	q2, [sp, #0xd0]
    2e98:      	fcmge.4s	v25, v2, v23
    2e9c:      	and.16b	v24, v24, v25
    2ea0:      	and.16b	v24, v24, v23
    2ea4:      	ldr	q25, [sp, #0x230]
    2ea8:      	fmul.4s	v25, v24, v25
    2eac:      	movi.4s	v26, #0x4b, lsl #24
    2eb0:      	fadd.4s	v25, v25, v26
    2eb4:      	movi.4s	v26, #0xcb, lsl #24
    2eb8:      	fadd.4s	v25, v25, v26
    2ebc:      	fcvtzs.4s	v25, v25
    2ec0:      	scvtf.4s	v26, v25
    2ec4:      	ldr	q27, [sp, #0x200]
    2ec8:      	fmul.4s	v27, v26, v27
    2ecc:      	fadd.4s	v24, v24, v27
    2ed0:      	ldr	q27, [sp, #0x220]
    2ed4:      	fmul.4s	v26, v26, v27
    2ed8:      	fadd.4s	v24, v24, v26
    2edc:      	fmul.4s	v26, v24, v31
    2ee0:      	ldr	q27, [sp, #0x1f0]
    2ee4:      	fadd.4s	v26, v26, v27
    2ee8:      	fmul.4s	v26, v24, v26
    2eec:      	ldr	q27, [sp, #0x210]
    2ef0:      	fadd.4s	v26, v26, v27
    2ef4:      	fmul.4s	v26, v24, v26
    2ef8:      	ldr	q27, [sp, #0x1e0]
    2efc:      	fadd.4s	v26, v26, v27
    2f00:      	fmul.4s	v26, v24, v26
    2f04:      	fadd.4s	v26, v26, v11
    2f08:      	fmul.4s	v26, v24, v26
    2f0c:      	movi.4s	v8, #0x3f, lsl #24
    2f10:      	fadd.4s	v26, v26, v8
    2f14:      	fmul.4s	v27, v24, v24
    2f18:      	fmul.4s	v26, v27, v26
    2f1c:      	fadd.4s	v24, v24, v26
    2f20:      	fadd.4s	v24, v24, v13
    2f24:      	movi.2d	v26, #0xffffffffffffffff
    2f28:      	add.4s	v25, v25, v26
    2f2c:      	sshr.4s	v26, v25, #0x1
    2f30:      	shl.4s	v27, v26, #0x17
    2f34:      	add.4s	v27, v27, v13
    2f38:      	fmul.4s	v24, v24, v27
    2f3c:      	sub.4s	v25, v25, v26
    2f40:      	shl.4s	v25, v25, #0x17
    2f44:      	add.4s	v25, v25, v13
    2f48:      	fmul.4s	v24, v24, v25
    2f4c:      	fcmgt.4s	v23, v23, v2
    2f50:      	ldr	q25, [sp, #0x160]
    2f54:      	bsl.16b	v23, v25, v24
    2f58:      	fdiv.4s	v24, v9, v23
    2f5c:      	fsub.4s	v25, v23, v24
    2f60:      	fadd.4s	v23, v23, v24
    2f64:      	fdiv.4s	v23, v25, v23
    2f68:      	bsl.16b	v16, v23, v13
    2f6c:      	fcmge.4s	v6, v13, v6
    2f70:      	bsl.16b	v6, v7, v16
    2f74:      	add.2d	v4, v4, v18
    2f78:      	add.2d	v3, v3, v18
    2f7c:      	ldr	q2, [sp, #0xa0]
    2f80:      	add.2d	v7, v2, v18
    2f84:      	mvni.4s	v23, #0x80, lsl #24
    2f88:      	mov.16b	v2, v23
    2f8c:      	bsl.16b	v2, v6, v5
    2f90:      	fcmeq.4s	v5, v5, v5
    2f94:      	fadd.4s	v2, v2, v13
    2f98:      	ldr	q6, [sp, #0x150]
    2f9c:      	bif.16b	v2, v6, v5
    2fa0:      	fmul.4s	v5, v20, v8
    2fa4:      	fmul.4s	v2, v5, v2
    2fa8:      	fadd.4s	v2, v22, v2
    2fac:      	stp	q30, q4, [sp, #0x260]
    2fb0:      	stp	q3, q7, [sp, #0x280]
    2fb4:      	fmov	w9, s21
    2fb8:      	and	x11, x10, #0x7
    2fbc:      	add	x12, sp, #0x260
    2fc0:      	ldr	x11, [x12, x11, lsl #3]
    2fc4:      	sub	x10, x11, x10
    2fc8:      	add	x8, x8, x10, lsl #2
    2fcc:      	tbz	w9, #0x0, 0x2fd4 <ltmp0+0x2fd4>
    2fd0:      	str	s2, [x8]
    2fd4:      	tbz	w9, #0x1, 0x2fe0 <ltmp0+0x2fe0>
    2fd8:      	add	x10, x8, #0x4
    2fdc:      	st1.s	{ v2 }[1], [x10]
    2fe0:      	ldp	q27, q26, [sp, #0x180]
    2fe4:      	ldp	q7, q20, [sp, #0x240]
    2fe8:      	ldr	q25, [sp, #0x1a0]
    2fec:      	movi.4s	v16, #0x4b, lsl #24
    2ff0:      	ldr	q21, [sp, #0x230]
    2ff4:      	ldr	q22, [sp, #0x160]
    2ff8:      	mov.16b	v8, v14
    2ffc:      	ldr	q3, [sp, #0xb0]
    3000:      	mov.16b	v30, v10
    3004:      	tbz	w9, #0x2, 0x3010 <ltmp0+0x3010>
    3008:      	add	x10, x8, #0x8
    300c:      	st1.s	{ v2 }[2], [x10]
    3010:      	mov.16b	v14, v17
    3014:      	tbz	w9, #0x3, 0x3020 <ltmp0+0x3020>
    3018:      	add	x10, x8, #0xc
    301c:      	st1.s	{ v2 }[3], [x10]
    3020:      	fmul.4s	v2, v0, v3
    3024:      	fmul.4s	v2, v0, v2
    3028:      	fmul.4s	v2, v0, v2
    302c:      	fadd.4s	v2, v0, v2
    3030:      	fmul.4s	v2, v2, v8
    3034:      	zip2.8b	v1, v1, v0
    3038:      	ushll.4s	v1, v1, #0x0
    303c:      	shl.4s	v1, v1, #0x1f
    3040:      	cmlt.4s	v1, v1, #0
    3044:      	and.16b	v1, v1, v2
    3048:      	fabs.4s	v2, v1
    304c:      	fmul.4s	v3, v1, v1
    3050:      	ldr	q4, [sp, #0x140]
    3054:      	ldr	q5, [sp, #0xc0]
    3058:      	fmla.4s	v4, v3, v5
    305c:      	mov.16b	v5, v14
    3060:      	fmla.4s	v5, v3, v4
    3064:      	mov.16b	v4, v15
    3068:      	fmla.4s	v4, v3, v5
    306c:      	mov.16b	v5, v30
    3070:      	fmla.4s	v5, v3, v4
    3074:      	mov.16b	v24, v11
    3078:      	mov.16b	v4, v11
    307c:      	fmla.4s	v4, v3, v5
    3080:      	mov.16b	v5, v13
    3084:      	fmla.4s	v5, v3, v4
    3088:      	fmul.4s	v4, v2, v5
    308c:      	mov.16b	v5, v20
    3090:      	fmla.4s	v5, v3, v27
    3094:      	mov.16b	v6, v29
    3098:      	fmla.4s	v6, v3, v5
    309c:      	mov.16b	v5, v25
    30a0:      	fmla.4s	v5, v3, v6
    30a4:      	mov.16b	v6, v26
    30a8:      	fmla.4s	v6, v3, v5
    30ac:      	movi.4s	v5, #0x3f, lsl #24
    30b0:      	fmla.4s	v5, v3, v6
    30b4:      	mov.16b	v6, v13
    30b8:      	fmla.4s	v6, v3, v5
    30bc:      	fdiv.4s	v3, v4, v6
    30c0:      	fcmge.4s	v4, v28, v2
    30c4:      	and.16b	v5, v4, v2
    30c8:      	fcmge.4s	v6, v5, v7
    30cc:      	ldr	q18, [sp, #0xd0]
    30d0:      	fcmge.4s	v7, v18, v5
    30d4:      	and.16b	v6, v6, v7
    30d8:      	and.16b	v6, v6, v5
    30dc:      	fmul.4s	v7, v6, v21
    30e0:      	fadd.4s	v7, v7, v16
    30e4:      	movi.4s	v16, #0xcb, lsl #24
    30e8:      	fadd.4s	v7, v7, v16
    30ec:      	fcvtzs.4s	v7, v7
    30f0:      	scvtf.4s	v16, v7
    30f4:      	ldp	q10, q17, [sp, #0x1f0]
    30f8:      	fmul.4s	v17, v16, v17
    30fc:      	fadd.4s	v6, v6, v17
    3100:      	ldp	q17, q21, [sp, #0x210]
    3104:      	fmul.4s	v16, v16, v21
    3108:      	fadd.4s	v6, v6, v16
    310c:      	fmul.4s	v16, v6, v31
    3110:      	fadd.4s	v16, v16, v10
    3114:      	fmul.4s	v16, v6, v16
    3118:      	fadd.4s	v16, v16, v17
    311c:      	fmul.4s	v16, v6, v16
    3120:      	ldr	q17, [sp, #0x1e0]
    3124:      	fadd.4s	v16, v16, v17
    3128:      	mov.16b	v31, v11
    312c:      	fmul.4s	v16, v6, v16
    3130:      	fadd.4s	v16, v16, v24
    3134:      	fmul.4s	v16, v6, v16
    3138:      	movi.4s	v21, #0x3f, lsl #24
    313c:      	fadd.4s	v16, v16, v21
    3140:      	fmul.4s	v17, v6, v6
    3144:      	fmul.4s	v16, v17, v16
    3148:      	fadd.4s	v6, v6, v16
    314c:      	fadd.4s	v6, v6, v13
    3150:      	movi.2d	v16, #0xffffffffffffffff
    3154:      	add.4s	v7, v7, v16
    3158:      	sshr.4s	v16, v7, #0x1
    315c:      	shl.4s	v17, v16, #0x17
    3160:      	add.4s	v17, v17, v13
    3164:      	fmul.4s	v6, v6, v17
    3168:      	sub.4s	v7, v7, v16
    316c:      	shl.4s	v7, v7, #0x17
    3170:      	add.4s	v7, v7, v13
    3174:      	fmul.4s	v6, v6, v7
    3178:      	fcmgt.4s	v5, v5, v18
    317c:      	bsl.16b	v5, v22, v6
    3180:      	fdiv.4s	v6, v9, v5
    3184:      	fsub.4s	v7, v5, v6
    3188:      	fadd.4s	v5, v5, v6
    318c:      	fdiv.4s	v5, v7, v5
    3190:      	bsl.16b	v4, v5, v13
    3194:      	fcmge.4s	v2, v13, v2
    3198:      	bsl.16b	v2, v3, v4
    319c:      	bif.16b	v2, v1, v23
    31a0:      	fcmeq.4s	v1, v1, v1
    31a4:      	fadd.4s	v2, v2, v13
    31a8:      	ldr	q18, [sp, #0x150]
    31ac:      	bsl.16b	v1, v2, v18
    31b0:      	fmul.4s	v0, v0, v21
    31b4:      	fmul.4s	v0, v0, v1
    31b8:      	fadd.4s	v0, v19, v0
    31bc:      	tbnz	w9, #0x4, 0x335c <ltmp0+0x335c>
    31c0:      	tbnz	w9, #0x5, 0x3364 <ltmp0+0x3364>
    31c4:      	ldp	q21, q23, [sp, #0xb0]
    31c8:      	mov.16b	v9, v15
    31cc:      	tbnz	w9, #0x6, 0x3378 <ltmp0+0x3378>
    31d0:      	tbnz	w9, #0x7, 0x1c0 <ltmp0+0x1c0>
    31d4:      	b	0x1c8 <ltmp0+0x1c8>
    31d8:      	ldr	s21, [x11]
    31dc:      	tbz	w13, #0x1, 0x21c8 <ltmp0+0x21c8>
    31e0:      	add	x14, x11, #0x4
    31e4:      	ld1.s	{ v21 }[1], [x14]
    31e8:      	tbz	w13, #0x2, 0x21cc <ltmp0+0x21cc>
    31ec:      	add	x14, x11, #0x8
    31f0:      	ld1.s	{ v21 }[2], [x14]
    31f4:      	tbz	w13, #0x3, 0x21d0 <ltmp0+0x21d0>
    31f8:      	add	x14, x11, #0xc
    31fc:      	ld1.s	{ v21 }[3], [x14]
    3200:      	tbz	w13, #0x4, 0x21d4 <ltmp0+0x21d4>
    3204:      	add	x14, x11, #0x10
    3208:      	ld1.s	{ v17 }[0], [x14]
    320c:      	tbz	w13, #0x5, 0x21d8 <ltmp0+0x21d8>
    3210:      	add	x14, x11, #0x14
    3214:      	ld1.s	{ v17 }[1], [x14]
    3218:      	tbz	w13, #0x6, 0x21dc <ltmp0+0x21dc>
    321c:      	add	x14, x11, #0x18
    3220:      	ld1.s	{ v17 }[2], [x14]
    3224:      	tbnz	w13, #0x7, 0x21e0 <ltmp0+0x21e0>
    3228:      	b	0x21e8 <ltmp0+0x21e8>
    322c:      	ldr	s23, [x9]
    3230:      	tbz	w12, #0x1, 0x23ec <ltmp0+0x23ec>
    3234:      	add	x14, x9, #0x4
    3238:      	ld1.s	{ v23 }[1], [x14]
    323c:      	tbz	w12, #0x2, 0x23f0 <ltmp0+0x23f0>
    3240:      	add	x14, x9, #0x8
    3244:      	ld1.s	{ v23 }[2], [x14]
    3248:      	tbz	w12, #0x3, 0x23f4 <ltmp0+0x23f4>
    324c:      	add	x14, x9, #0xc
    3250:      	ld1.s	{ v23 }[3], [x14]
    3254:      	tbz	w12, #0x4, 0x23f8 <ltmp0+0x23f8>
    3258:      	add	x14, x9, #0x10
    325c:      	ld1.s	{ v2 }[0], [x14]
    3260:      	tbz	w12, #0x5, 0x23fc <ltmp0+0x23fc>
    3264:      	add	x14, x9, #0x14
    3268:      	ld1.s	{ v2 }[1], [x14]
    326c:      	tbz	w12, #0x6, 0x2400 <ltmp0+0x2400>
    3270:      	add	x14, x9, #0x18
    3274:      	ld1.s	{ v2 }[2], [x14]
    3278:      	movi.2d	v20, #0xffffffffffffffff
    327c:      	movi.4s	v3, #0xcb, lsl #24
    3280:      	tbnz	w12, #0x7, 0x240c <ltmp0+0x240c>
    3284:      	b	0x2414 <ltmp0+0x2414>
    3288:      	str	s0, [x8, #0x10]
    328c:      	tbz	w9, #0x5, 0x2ca4 <ltmp0+0x2ca4>
    3290:      	add	x10, x8, #0x14
    3294:      	st1.s	{ v0 }[1], [x10]
    3298:      	mov.16b	v8, v24
    329c:      	ldr	q21, [sp, #0xb0]
    32a0:      	mov.16b	v9, v30
    32a4:      	tbz	w9, #0x6, 0x2cb4 <ltmp0+0x2cb4>
    32a8:      	add	x10, x8, #0x18
    32ac:      	st1.s	{ v0 }[2], [x10]
    32b0:      	mov.16b	v30, v5
    32b4:      	tbnz	w9, #0x7, 0x1c0 <ltmp0+0x1c0>
    32b8:      	b	0x1c8 <ltmp0+0x1c8>
    32bc:      	ldr	s20, [x11]
    32c0:      	ldr	d2, [sp, #0x80]
    32c4:      	tbz	w12, #0x1, 0x2d58 <ltmp0+0x2d58>
    32c8:      	add	x14, x11, #0x4
    32cc:      	ld1.s	{ v20 }[1], [x14]
    32d0:      	tbz	w12, #0x2, 0x2d5c <ltmp0+0x2d5c>
    32d4:      	add	x14, x11, #0x8
    32d8:      	ld1.s	{ v20 }[2], [x14]
    32dc:      	tbz	w12, #0x3, 0x2d60 <ltmp0+0x2d60>
    32e0:      	add	x14, x11, #0xc
    32e4:      	ld1.s	{ v20 }[3], [x14]
    32e8:      	tbz	w12, #0x4, 0x2d64 <ltmp0+0x2d64>
    32ec:      	add	x14, x11, #0x10
    32f0:      	ld1.s	{ v0 }[0], [x14]
    32f4:      	tbz	w12, #0x5, 0x2d68 <ltmp0+0x2d68>
    32f8:      	add	x14, x11, #0x14
    32fc:      	ld1.s	{ v0 }[1], [x14]
    3300:      	tbz	w12, #0x6, 0x2d6c <ltmp0+0x2d6c>
    3304:      	add	x14, x11, #0x18
    3308:      	ld1.s	{ v0 }[2], [x14]
    330c:      	tbnz	w12, #0x7, 0x2d70 <ltmp0+0x2d70>
    3310:      	b	0x2d78 <ltmp0+0x2d78>
    3314:      	ldr	s22, [x9]
    3318:      	tbz	w11, #0x1, 0x2da8 <ltmp0+0x2da8>
    331c:      	add	x12, x9, #0x4
    3320:      	ld1.s	{ v22 }[1], [x12]
    3324:      	tbz	w11, #0x2, 0x2dac <ltmp0+0x2dac>
    3328:      	add	x12, x9, #0x8
    332c:      	ld1.s	{ v22 }[2], [x12]
    3330:      	tbz	w11, #0x3, 0x2db0 <ltmp0+0x2db0>
    3334:      	add	x12, x9, #0xc
    3338:      	ld1.s	{ v22 }[3], [x12]
    333c:      	tbz	w11, #0x4, 0x2db4 <ltmp0+0x2db4>
    3340:      	add	x12, x9, #0x10
    3344:      	ld1.s	{ v19 }[0], [x12]
    3348:      	tbz	w11, #0x5, 0x2db8 <ltmp0+0x2db8>
    334c:      	add	x12, x9, #0x14
    3350:      	ld1.s	{ v19 }[1], [x12]
    3354:      	tbnz	w11, #0x6, 0x2dbc <ltmp0+0x2dbc>
    3358:      	b	0x2dc4 <ltmp0+0x2dc4>
    335c:      	str	s0, [x8, #0x10]
    3360:      	tbz	w9, #0x5, 0x31c4 <ltmp0+0x31c4>
    3364:      	add	x10, x8, #0x14
    3368:      	st1.s	{ v0 }[1], [x10]
    336c:      	ldp	q21, q23, [sp, #0xb0]
    3370:      	mov.16b	v9, v15
    3374:      	tbz	w9, #0x6, 0x31d0 <ltmp0+0x31d0>
    3378:      	add	x10, x8, #0x18
    337c:      	st1.s	{ v0 }[2], [x10]
    3380:      	tbnz	w9, #0x7, 0x1c0 <ltmp0+0x1c0>
    3384:      	b	0x1c8 <ltmp0+0x1c8>
    3388:      	ldr	x9, [sp, #0x10]
    338c:      	stp	w14, w13, [x9]
    3390:      	str	w12, [x9, #0x8]
    3394:      	mov	w8, #0x18               ; =24
    3398:      	str	w8, [x9, #0x24]
    339c:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    33a0:      	add	sp, sp, #0x410
    33a4:      	ldp	x29, x30, [sp, #0x90]
    33a8:      	ldp	x20, x19, [sp, #0x80]
    33ac:      	ldp	x22, x21, [sp, #0x70]
    33b0:      	ldp	x24, x23, [sp, #0x60]
    33b4:      	ldp	x26, x25, [sp, #0x50]
    33b8:      	ldp	x28, x27, [sp, #0x40]
    33bc:      	ldp	d9, d8, [sp, #0x30]
    33c0:      	ldp	d11, d10, [sp, #0x20]
    33c4:      	ldp	d13, d12, [sp, #0x10]
    33c8:      	ldp	d15, d14, [sp], #0xa0
    33cc:      	ret

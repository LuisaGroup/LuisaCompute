
/private/tmp/luisa-packet-inline.UY1lIE/capture/rope-1024x4098/on/object/tile_xir_w8_36507_1788935109359382_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      2c:      	sub	sp, sp, #0x4c0
      30:      	str	x0, [sp, #0x58]
      34:      	str	w3, [sp, #0x88]
      38:      	cbz	w3, 0x2098 <ltmp0+0x2098>
      3c:      	mov	w12, #0x0               ; =0
      40:      	mov	w8, #0x1fff             ; =8191
      44:      	movk	w8, #0x100, lsl #16
      48:      	sub	x8, x8, #0x801, lsl #12 ; =0x801000
      4c:      	str	x8, [sp, #0x50]
      50:      	ldp	w9, w8, [x2, #0x2c]
      54:      	stp	w8, w9, [sp, #0x80]
      58:      	mov	w11, #0x1002            ; =4098
      5c:      	ldp	w8, w9, [x2]
      60:      	add	x3, sp, #0x6, lsl #12   ; =0x6000
      64:      	add	x3, x3, #0x4a0
      68:      	add	x4, sp, #0x4, lsl #12   ; =0x4000
      6c:      	add	x4, x4, #0x480
      70:      	add	x5, sp, #0x2, lsl #12   ; =0x2000
      74:      	add	x5, x5, #0x460
      78:      	add	x6, sp, #0x440
      7c:      	ldp	w10, w13, [x2, #0x8]
      80:      	str	x2, [sp, #0x8]
      84:      	str	x13, [sp, #0x78]
      88:      	dup.2s	v8, w11
      8c:      	adrp	x11, 0x0 <ltmp0>
      90:      	ldr	q0, [x11]
      94:      	str	q0, [sp, #0x40]
      98:      	adrp	x11, 0x0 <ltmp0>
      9c:      	ldr	q0, [x11]
      a0:      	str	q0, [sp, #0x30]
      a4:      	adrp	x11, 0x0 <ltmp0>
      a8:      	ldr	q0, [x11]
      ac:      	str	q0, [sp, #0x20]
      b0:      	b	0xfc <ltmp0+0xfc>
      b4:      	ldr	x15, [sp, #0x98]
      b8:      	add	w8, w15, #0x1
      bc:      	ldp	w11, w9, [sp, #0x80]
      c0:      	cmp	w8, w9
      c4:      	cset	w9, eq
      c8:      	csinc	w8, wzr, w15, eq
      cc:      	ldp	w14, w13, [sp, #0x8c]
      d0:      	cinc	w10, w14, eq
      d4:      	cmp	w10, w11
      d8:      	cset	w11, eq
      dc:      	ands	w11, w9, w11
      e0:      	csel	w9, wzr, w10, ne
      e4:      	add	w10, w13, w11
      e8:      	ldr	w12, [sp, #0x94]
      ec:      	add	w12, w12, #0x1
      f0:      	ldr	w11, [sp, #0x88]
      f4:      	cmp	w12, w11
      f8:      	b.eq	0x2084 <ltmp0+0x2084>
      fc:      	str	w12, [sp, #0x94]
     100:      	mov	x13, x10
     104:      	mov	x14, x9
     108:      	mov	x15, x8
     10c:      	ubfiz	x8, x8, #5, #32
     110:      	ldr	x12, [sp, #0x78]
     114:      	cmp	x8, x12
     118:      	csel	x9, x8, xzr, ls
     11c:      	subs	x10, x12, x9
     120:      	cmp	x10, #0x20
     124:      	mov	w11, #0x20              ; =32
     128:      	csel	x10, x10, x11, lo
     12c:      	cmp	x12, x9
     130:      	ccmp	x8, x12, #0x2, hi
     134:      	csel	x8, x10, xzr, ls
     138:      	cmp	x8, #0x20
     13c:      	stp	w14, w13, [sp, #0x8c]
     140:      	str	x15, [sp, #0x98]
     144:      	b.lo	0x4c8 <ltmp0+0x4c8>
     148:      	mov	w22, #0x0               ; =0
     14c:      	ldp	x12, x8, [sp, #0x50]
     150:      	ldr	x26, [x8]
     154:      	ldr	x21, [x8, #0x10]
     158:      	ldr	x23, [x8, #0x20]
     15c:      	ldr	x19, [x8, #0x30]
     160:      	subs	x8, x26, x19
     164:      	mov	w11, #0x1fff            ; =8191
     168:      	movk	w11, #0x100, lsl #16
     16c:      	ccmp	x8, x11, #0x0, hs
     170:      	cset	w8, hi
     174:      	subs	x9, x19, x26
     178:      	ccmp	x9, x11, #0x0, hs
     17c:      	csinc	w8, w8, wzr, ls
     180:      	subs	x9, x21, x19
     184:      	ccmp	x9, x11, #0x0, hs
     188:      	cset	w9, hi
     18c:      	subs	x10, x19, x21
     190:      	ccmp	x10, x12, #0x0, hs
     194:      	csinc	w9, w9, wzr, ls
     198:      	and	w8, w8, w9
     19c:      	subs	x9, x23, x19
     1a0:      	ccmp	x9, x11, #0x0, hs
     1a4:      	cset	w9, hi
     1a8:      	subs	x10, x19, x23
     1ac:      	ccmp	x10, x12, #0x0, hs
     1b0:      	csinc	w9, w9, wzr, ls
     1b4:      	and	w16, w9, w8
     1b8:      	mov	w8, #0x2004             ; =8196
     1bc:      	add	x24, x26, x8
     1c0:      	add	x17, x19, x8
     1c4:      	lsl	w0, w15, #2
     1c8:      	str	w16, [sp, #0xd0]
     1cc:      	str	x24, [sp, #0xc0]
     1d0:      	str	x17, [sp, #0xb0]
     1d4:      	str	w0, [sp, #0xa0]
     1d8:      	add	w8, w22, w0
     1dc:      	and	w8, w8, #0x1fffffff
     1e0:      	dup.2s	v0, w8
     1e4:      	ushll.2d	v1, v0, #0x0
     1e8:      	tbz	w16, #0x0, 0x2e8 <ltmp0+0x2e8>
     1ec:      	mov	x9, #0x0                ; =0
     1f0:      	xtn.2s	v0, v1
     1f4:      	umull.2d	v0, v0, v8
     1f8:      	fmov	x11, d0
     1fc:      	fmov	x8, d1
     200:      	add	x10, x8, x8, lsl #11
     204:      	lsl	x12, x11, #2
     208:      	add	x11, x17, x12
     20c:      	add	x12, x24, x12
     210:      	fmov	d1, x9
     214:      	add.2d	v1, v1, v0
     218:      	fmov	x13, d1
     21c:      	lsl	x13, x13, #2
     220:      	add	x14, x26, x13
     224:      	ldp	q1, q2, [x14]
     228:      	ldp	q3, q4, [x12], #0x20
     22c:      	add	x14, x9, x10
     230:      	lsl	x14, x14, #2
     234:      	add	x15, x21, x14
     238:      	ldp	q5, q6, [x15]
     23c:      	add	x14, x23, x14
     240:      	ldp	q7, q16, [x14]
     244:      	fmul.4s	v17, v2, v6
     248:      	fmul.4s	v18, v1, v5
     24c:      	fmul.4s	v19, v4, v16
     250:      	fmul.4s	v20, v3, v7
     254:      	fsub.4s	v18, v18, v20
     258:      	fsub.4s	v17, v17, v19
     25c:      	add	x13, x19, x13
     260:      	stp	q18, q17, [x13]
     264:      	fmul.4s	v2, v2, v16
     268:      	fmul.4s	v1, v1, v7
     26c:      	fmul.4s	v4, v4, v6
     270:      	fmul.4s	v3, v3, v5
     274:      	fadd.4s	v1, v3, v1
     278:      	fadd.4s	v2, v4, v2
     27c:      	stp	q1, q2, [x11], #0x20
     280:      	add	x9, x9, #0x8
     284:      	cmp	x9, #0x800
     288:      	b.ne	0x210 <ltmp0+0x210>
     28c:      	lsl	x9, x10, #3
     290:      	add	x10, x9, #0x2, lsl #12  ; =0x2000
     294:      	ldr	s0, [x26, x10]
     298:      	mov	w11, #0x4004            ; =16388
     29c:      	add	x25, x9, x11
     2a0:      	ldr	s1, [x26, x25]
     2a4:      	mov	w9, #0x2004             ; =8196
     2a8:      	umull	x8, w8, w9
     2ac:      	add	x8, x8, #0x2, lsl #12   ; =0x2000
     2b0:      	ldr	s2, [x21, x8]
     2b4:      	ldr	s3, [x23, x8]
     2b8:      	fmul.4s	v4, v0, v2
     2bc:      	fmul.4s	v5, v1, v3
     2c0:      	fsub.4s	v4, v4, v5
     2c4:      	str	s4, [x19, x10]
     2c8:      	fmul.4s	v0, v0, v3
     2cc:      	fmul.4s	v1, v1, v2
     2d0:      	fadd.4s	v0, v1, v0
     2d4:      	str	s0, [x19, x25]
     2d8:      	add	w22, w22, #0x1
     2dc:      	cmp	w22, #0x4
     2e0:      	b.ne	0x1d8 <ltmp0+0x1d8>
     2e4:      	b	0xb4 <ltmp0+0xb4>
     2e8:      	fmov	x8, d1
     2ec:      	add	x20, x8, x8, lsl #11
     2f0:      	lsl	x27, x20, #3
     2f4:      	add	x0, sp, #0x6, lsl #12   ; =0x6000
     2f8:      	add	x0, x0, #0x4a0
     2fc:      	add	x1, x26, x27
     300:      	mov	w2, #0x2000             ; =8192
     304:      	str	q21, [sp, #0xe0]
     308:      	bl	0x308 <ltmp0+0x308>
     30c:      	add	x28, x27, #0x2, lsl #12 ; =0x2000
     310:      	add	x8, x26, x28
     314:      	ldr	q0, [sp, #0x110]
     318:      	ld1.s	{ v0 }[0], [x8]
     31c:      	str	q0, [sp, #0x84b0]
     320:      	str	q0, [sp, #0x110]
     324:      	str	q0, [sp, #0x84a0]
     328:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     32c:      	add	x0, x0, #0x480
     330:      	add	x1, x24, x27
     334:      	mov	w2, #0x2000             ; =8192
     338:      	bl	0x338 <ltmp0+0x338>
     33c:      	mov	w8, #0x4004             ; =16388
     340:      	add	x25, x27, x8
     344:      	add	x8, x26, x25
     348:      	ldr	q0, [sp, #0x100]
     34c:      	ld1.s	{ v0 }[0], [x8]
     350:      	str	q0, [sp, #0x6490]
     354:      	str	q0, [sp, #0x100]
     358:      	str	q0, [sp, #0x6480]
     35c:      	lsl	x20, x20, #2
     360:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     364:      	add	x0, x0, #0x460
     368:      	add	x1, x21, x20
     36c:      	mov	w2, #0x2000             ; =8192
     370:      	bl	0x370 <ltmp0+0x370>
     374:      	add	x24, x20, #0x2, lsl #12 ; =0x2000
     378:      	add	x8, x21, x24
     37c:      	ldr	q0, [sp, #0xf0]
     380:      	ld1.s	{ v0 }[0], [x8]
     384:      	str	q0, [sp, #0x4470]
     388:      	str	q0, [sp, #0xf0]
     38c:      	str	q0, [sp, #0x4460]
     390:      	add	x0, sp, #0x440
     394:      	add	x1, x23, x20
     398:      	mov	w2, #0x2000             ; =8192
     39c:      	bl	0x39c <ltmp0+0x39c>
     3a0:      	ldr	q21, [sp, #0xe0]
     3a4:      	add	x6, sp, #0x440
     3a8:      	add	x5, sp, #0x2, lsl #12   ; =0x2000
     3ac:      	add	x5, x5, #0x460
     3b0:      	add	x4, sp, #0x4, lsl #12   ; =0x4000
     3b4:      	add	x4, x4, #0x480
     3b8:      	add	x3, sp, #0x6, lsl #12   ; =0x6000
     3bc:      	add	x3, x3, #0x4a0
     3c0:      	mov	x8, #0x0                ; =0
     3c4:      	add	x9, x23, x24
     3c8:      	ld1.s	{ v21 }[0], [x9]
     3cc:      	str	q0, [sp, #0x2450]
     3d0:      	str	q21, [sp, #0x2440]
     3d4:      	add	x9, x19, x27
     3d8:      	add	x10, x3, x8
     3dc:      	ldp	q0, q1, [x10]
     3e0:      	add	x10, x5, x8
     3e4:      	ldp	q2, q3, [x10]
     3e8:      	fmul.4s	v1, v1, v3
     3ec:      	fmul.4s	v0, v0, v2
     3f0:      	add	x10, x4, x8
     3f4:      	ldp	q2, q3, [x10]
     3f8:      	add	x10, x6, x8
     3fc:      	ldp	q4, q5, [x10]
     400:      	fmul.4s	v3, v3, v5
     404:      	fmul.4s	v2, v2, v4
     408:      	fsub.4s	v0, v0, v2
     40c:      	fsub.4s	v1, v1, v3
     410:      	add	x10, x9, x8
     414:      	stp	q0, q1, [x10]
     418:      	add	x8, x8, #0x20
     41c:      	cmp	x8, #0x2, lsl #12       ; =0x2000
     420:      	b.ne	0x3d8 <ltmp0+0x3d8>
     424:      	mov	x8, #0x0                ; =0
     428:      	ldr	q0, [sp, #0x110]
     42c:      	ldp	q2, q1, [sp, #0xf0]
     430:      	fmul.4s	v0, v0, v2
     434:      	fmul.4s	v1, v1, v21
     438:      	fsub.4s	v0, v0, v1
     43c:      	str	s0, [x19, x28]
     440:      	ldr	x17, [sp, #0xb0]
     444:      	add	x9, x17, x27
     448:      	add	x10, x3, x8
     44c:      	ldp	q0, q1, [x10]
     450:      	add	x10, x6, x8
     454:      	ldp	q2, q3, [x10]
     458:      	fmul.4s	v1, v1, v3
     45c:      	fmul.4s	v0, v0, v2
     460:      	add	x10, x4, x8
     464:      	ldp	q2, q3, [x10]
     468:      	add	x10, x5, x8
     46c:      	ldp	q4, q5, [x10]
     470:      	fmul.4s	v3, v3, v5
     474:      	fmul.4s	v2, v2, v4
     478:      	fadd.4s	v0, v0, v2
     47c:      	fadd.4s	v1, v1, v3
     480:      	add	x10, x9, x8
     484:      	stp	q0, q1, [x10]
     488:      	add	x8, x8, #0x20
     48c:      	cmp	x8, #0x2, lsl #12       ; =0x2000
     490:      	b.ne	0x448 <ltmp0+0x448>
     494:      	ldp	q1, q0, [sp, #0x100]
     498:      	fmul.4s	v0, v0, v21
     49c:      	ldr	q2, [sp, #0xf0]
     4a0:      	fmul.4s	v1, v1, v2
     4a4:      	fadd.4s	v0, v1, v0
     4a8:      	ldr	w16, [sp, #0xd0]
     4ac:      	ldr	x24, [sp, #0xc0]
     4b0:      	ldr	w0, [sp, #0xa0]
     4b4:      	str	s0, [x19, x25]
     4b8:      	add	w22, w22, #0x1
     4bc:      	cmp	w22, #0x4
     4c0:      	b.ne	0x1d8 <ltmp0+0x1d8>
     4c4:      	b	0xb4 <ltmp0+0xb4>
     4c8:      	lsr	x16, x8, #3
     4cc:      	str	x8, [sp, #0x60]
     4d0:      	cmp	x8, #0x8
     4d4:      	b.lo	0x830 <ltmp0+0x830>
     4d8:      	mov	w21, #0x0               ; =0
     4dc:      	ldp	x12, x8, [sp, #0x50]
     4e0:      	ldr	x23, [x8]
     4e4:      	ldr	x25, [x8, #0x10]
     4e8:      	ldr	x19, [x8, #0x20]
     4ec:      	ldr	x26, [x8, #0x30]
     4f0:      	subs	x8, x23, x26
     4f4:      	mov	w11, #0x1fff            ; =8191
     4f8:      	movk	w11, #0x100, lsl #16
     4fc:      	ccmp	x8, x11, #0x0, hs
     500:      	cset	w8, hi
     504:      	subs	x9, x26, x23
     508:      	ccmp	x9, x11, #0x0, hs
     50c:      	csinc	w8, w8, wzr, ls
     510:      	subs	x9, x25, x26
     514:      	ccmp	x9, x11, #0x0, hs
     518:      	cset	w9, hi
     51c:      	subs	x10, x26, x25
     520:      	ccmp	x10, x12, #0x0, hs
     524:      	csinc	w9, w9, wzr, ls
     528:      	and	w8, w8, w9
     52c:      	subs	x9, x19, x26
     530:      	ccmp	x9, x11, #0x0, hs
     534:      	cset	w9, hi
     538:      	subs	x10, x26, x19
     53c:      	ccmp	x10, x12, #0x0, hs
     540:      	csinc	w9, w9, wzr, ls
     544:      	and	w17, w9, w8
     548:      	ldr	x8, [sp, #0x98]
     54c:      	lsl	w0, w8, #2
     550:      	mov	w8, #0x2004             ; =8196
     554:      	add	x9, x26, x8
     558:      	str	x9, [sp, #0xb0]
     55c:      	add	x8, x23, x8
     560:      	str	x8, [sp, #0xa0]
     564:      	str	x16, [sp, #0xe0]
     568:      	str	w17, [sp, #0xd0]
     56c:      	str	w0, [sp, #0xc0]
     570:      	add	w8, w21, w0
     574:      	and	w8, w8, #0x1fffffff
     578:      	dup.2s	v0, w8
     57c:      	ushll.2d	v1, v0, #0x0
     580:      	tbz	w17, #0x0, 0x688 <ltmp0+0x688>
     584:      	mov	x9, #0x0                ; =0
     588:      	xtn.2s	v0, v1
     58c:      	umull.2d	v0, v0, v8
     590:      	fmov	x11, d0
     594:      	fmov	x8, d1
     598:      	add	x10, x8, x8, lsl #11
     59c:      	lsl	x12, x11, #2
     5a0:      	ldr	x11, [sp, #0xb0]
     5a4:      	add	x11, x11, x12
     5a8:      	ldr	x13, [sp, #0xa0]
     5ac:      	add	x12, x13, x12
     5b0:      	fmov	d1, x9
     5b4:      	add.2d	v1, v1, v0
     5b8:      	fmov	x13, d1
     5bc:      	lsl	x13, x13, #2
     5c0:      	add	x14, x23, x13
     5c4:      	ldp	q1, q2, [x14]
     5c8:      	ldp	q3, q4, [x12], #0x20
     5cc:      	add	x14, x9, x10
     5d0:      	lsl	x14, x14, #2
     5d4:      	add	x15, x25, x14
     5d8:      	ldp	q5, q6, [x15]
     5dc:      	add	x14, x19, x14
     5e0:      	ldp	q7, q16, [x14]
     5e4:      	fmul.4s	v17, v2, v6
     5e8:      	fmul.4s	v18, v1, v5
     5ec:      	fmul.4s	v19, v4, v16
     5f0:      	fmul.4s	v20, v3, v7
     5f4:      	fsub.4s	v18, v18, v20
     5f8:      	fsub.4s	v17, v17, v19
     5fc:      	add	x13, x26, x13
     600:      	stp	q18, q17, [x13]
     604:      	fmul.4s	v2, v2, v16
     608:      	fmul.4s	v1, v1, v7
     60c:      	fmul.4s	v4, v4, v6
     610:      	fmul.4s	v3, v3, v5
     614:      	fadd.4s	v1, v3, v1
     618:      	fadd.4s	v2, v4, v2
     61c:      	stp	q1, q2, [x11], #0x20
     620:      	add	x9, x9, #0x8
     624:      	cmp	x9, #0x800
     628:      	b.ne	0x5b0 <ltmp0+0x5b0>
     62c:      	lsl	x9, x10, #3
     630:      	add	x10, x9, #0x2, lsl #12  ; =0x2000
     634:      	ldr	s0, [x23, x10]
     638:      	mov	w11, #0x4004            ; =16388
     63c:      	add	x22, x9, x11
     640:      	ldr	s1, [x23, x22]
     644:      	mov	w9, #0x2004             ; =8196
     648:      	umull	x8, w8, w9
     64c:      	add	x8, x8, #0x2, lsl #12   ; =0x2000
     650:      	ldr	s2, [x25, x8]
     654:      	ldr	s3, [x19, x8]
     658:      	fmul.4s	v4, v0, v2
     65c:      	fmul.4s	v5, v1, v3
     660:      	fsub.4s	v4, v4, v5
     664:      	str	s4, [x26, x10]
     668:      	fmul.4s	v0, v0, v3
     66c:      	fmul.4s	v1, v1, v2
     670:      	fadd.4s	v0, v1, v0
     674:      	str	s0, [x26, x22]
     678:      	add	w21, w21, #0x1
     67c:      	cmp	w21, w16
     680:      	b.ne	0x570 <ltmp0+0x570>
     684:      	b	0x830 <ltmp0+0x830>
     688:      	fmov	x8, d1
     68c:      	add	x20, x8, x8, lsl #11
     690:      	lsl	x24, x20, #3
     694:      	add	x22, x23, x24
     698:      	add	x0, sp, #0x6, lsl #12   ; =0x6000
     69c:      	add	x0, x0, #0x4a0
     6a0:      	mov	x1, x22
     6a4:      	mov	w2, #0x2000             ; =8192
     6a8:      	bl	0x6a8 <ltmp0+0x6a8>
     6ac:      	add	x27, x24, #0x2, lsl #12 ; =0x2000
     6b0:      	ldr	s0, [x23, x27]
     6b4:      	str	q0, [sp, #0x110]
     6b8:      	str	q0, [sp, #0x84a0]
     6bc:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     6c0:      	add	x0, x0, #0x480
     6c4:      	mov	w8, #0x2004             ; =8196
     6c8:      	add	x1, x22, x8
     6cc:      	mov	w2, #0x2000             ; =8192
     6d0:      	bl	0x6d0 <ltmp0+0x6d0>
     6d4:      	mov	w8, #0x4004             ; =16388
     6d8:      	add	x22, x24, x8
     6dc:      	ldr	s0, [x23, x22]
     6e0:      	str	q0, [sp, #0x100]
     6e4:      	str	q0, [sp, #0x6480]
     6e8:      	lsl	x20, x20, #2
     6ec:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     6f0:      	add	x0, x0, #0x460
     6f4:      	add	x1, x25, x20
     6f8:      	mov	w2, #0x2000             ; =8192
     6fc:      	bl	0x6fc <ltmp0+0x6fc>
     700:      	add	x28, x20, #0x2, lsl #12 ; =0x2000
     704:      	ldr	s0, [x25, x28]
     708:      	str	q0, [sp, #0xf0]
     70c:      	str	q0, [sp, #0x4460]
     710:      	add	x0, sp, #0x440
     714:      	add	x1, x19, x20
     718:      	mov	w2, #0x2000             ; =8192
     71c:      	bl	0x71c <ltmp0+0x71c>
     720:      	add	x6, sp, #0x440
     724:      	add	x5, sp, #0x2, lsl #12   ; =0x2000
     728:      	add	x5, x5, #0x460
     72c:      	add	x4, sp, #0x4, lsl #12   ; =0x4000
     730:      	add	x4, x4, #0x480
     734:      	add	x3, sp, #0x6, lsl #12   ; =0x6000
     738:      	add	x3, x3, #0x4a0
     73c:      	mov	x9, #0x0                ; =0
     740:      	ldr	s0, [x19, x28]
     744:      	str	q0, [sp, #0x2440]
     748:      	add	x8, x26, x24
     74c:      	add	x10, x3, x9
     750:      	ldp	q1, q2, [x10]
     754:      	add	x10, x5, x9
     758:      	ldp	q3, q4, [x10]
     75c:      	fmul.4s	v2, v2, v4
     760:      	fmul.4s	v1, v1, v3
     764:      	add	x10, x4, x9
     768:      	ldp	q3, q4, [x10]
     76c:      	add	x10, x6, x9
     770:      	ldp	q5, q6, [x10]
     774:      	fmul.4s	v4, v4, v6
     778:      	fmul.4s	v3, v3, v5
     77c:      	fsub.4s	v1, v1, v3
     780:      	fsub.4s	v2, v2, v4
     784:      	add	x10, x8, x9
     788:      	stp	q1, q2, [x10]
     78c:      	add	x9, x9, #0x20
     790:      	cmp	x9, #0x2, lsl #12       ; =0x2000
     794:      	b.ne	0x74c <ltmp0+0x74c>
     798:      	mov	x9, #0x0                ; =0
     79c:      	ldp	q16, q7, [sp, #0x100]
     7a0:      	ldr	q17, [sp, #0xf0]
     7a4:      	fmul.4s	v1, v7, v17
     7a8:      	fmul.4s	v2, v16, v0
     7ac:      	fsub.4s	v1, v1, v2
     7b0:      	str	s1, [x26, x27]
     7b4:      	mov	w10, #0x2004            ; =8196
     7b8:      	add	x8, x8, x10
     7bc:      	ldr	x16, [sp, #0xe0]
     7c0:      	add	x10, x3, x9
     7c4:      	ldp	q1, q2, [x10]
     7c8:      	add	x10, x6, x9
     7cc:      	ldp	q3, q4, [x10]
     7d0:      	fmul.4s	v2, v2, v4
     7d4:      	fmul.4s	v1, v1, v3
     7d8:      	add	x10, x4, x9
     7dc:      	ldp	q3, q4, [x10]
     7e0:      	add	x10, x5, x9
     7e4:      	ldp	q5, q6, [x10]
     7e8:      	fmul.4s	v4, v4, v6
     7ec:      	fmul.4s	v3, v3, v5
     7f0:      	fadd.4s	v1, v1, v3
     7f4:      	fadd.4s	v2, v2, v4
     7f8:      	add	x10, x8, x9
     7fc:      	stp	q1, q2, [x10]
     800:      	add	x9, x9, #0x20
     804:      	cmp	x9, #0x2, lsl #12       ; =0x2000
     808:      	b.ne	0x7c0 <ltmp0+0x7c0>
     80c:      	fmul.4s	v0, v7, v0
     810:      	fmul.4s	v1, v16, v17
     814:      	fadd.4s	v0, v1, v0
     818:      	ldr	w17, [sp, #0xd0]
     81c:      	ldr	w0, [sp, #0xc0]
     820:      	str	s0, [x26, x22]
     824:      	add	w21, w21, #0x1
     828:      	cmp	w21, w16
     82c:      	b.ne	0x570 <ltmp0+0x570>
     830:      	ldr	x8, [sp, #0x60]
     834:      	and	w8, w8, #0x7
     838:      	cbz	w8, 0xb4 <ltmp0+0xb4>
     83c:      	dup.4s	v0, w8
     840:      	ldp	q2, q1, [sp, #0x30]
     844:      	cmhi.4s	v6, v0, v2
     848:      	cmhi.4s	v0, v0, v1
     84c:      	uzp1.8h	v21, v0, v6
     850:      	umaxv.8h	h1, v21
     854:      	fmov	w8, s1
     858:      	tbz	w8, #0x0, 0xb4 <ltmp0+0xb4>
     85c:      	ldr	x8, [sp, #0x58]
     860:      	ldr	x11, [x8]
     864:      	ldr	x10, [x8, #0x10]
     868:      	ldr	x9, [x8, #0x20]
     86c:      	ldr	x8, [x8, #0x30]
     870:      	sshll.2d	v1, v0, #0x0
     874:      	sshll.2d	v2, v6, #0x0
     878:      	sshll2.2d	v24, v0, #0x0
     87c:      	sshll2.2d	v23, v6, #0x0
     880:      	ldr	q3, [sp, #0x20]
     884:      	and.16b	v16, v23, v3
     888:      	adrp	x12, 0x0 <ltmp0>
     88c:      	ldr	q3, [x12]
     890:      	and.16b	v14, v24, v3
     894:      	adrp	x12, 0x0 <ltmp0>
     898:      	ldr	q3, [x12]
     89c:      	and.16b	v15, v2, v3
     8a0:      	adrp	x12, 0x0 <ltmp0>
     8a4:      	ldr	q2, [x12]
     8a8:      	and.16b	v20, v1, v2
     8ac:      	ldr	x12, [sp, #0x98]
     8b0:      	ubfiz	w12, w12, #2, #27
     8b4:      	orr	w12, w12, w16
     8b8:      	dup.4s	v1, w12
     8bc:      	and.16b	v2, v0, v1
     8c0:      	and.16b	v1, v6, v1
     8c4:      	ushll2.2d	v4, v1, #0x0
     8c8:      	ushll2.2d	v5, v2, #0x0
     8cc:      	ushll.2d	v1, v1, #0x0
     8d0:      	ushll.2d	v3, v2, #0x0
     8d4:      	subs	x12, x11, x8
     8d8:      	mov	w15, #0x1fff            ; =8191
     8dc:      	movk	w15, #0x100, lsl #16
     8e0:      	ccmp	x12, x15, #0x0, hs
     8e4:      	cset	w12, hi
     8e8:      	subs	x13, x8, x11
     8ec:      	ccmp	x13, x15, #0x0, hs
     8f0:      	csinc	w12, w12, wzr, ls
     8f4:      	subs	x13, x10, x8
     8f8:      	ccmp	x13, x15, #0x0, hs
     8fc:      	cset	w13, hi
     900:      	subs	x14, x8, x10
     904:      	ldr	x16, [sp, #0x50]
     908:      	ccmp	x14, x16, #0x0, hs
     90c:      	csinc	w13, w13, wzr, ls
     910:      	subs	x14, x9, x8
     914:      	ccmp	x14, x15, #0x0, hs
     918:      	cset	w14, hi
     91c:      	subs	x15, x8, x9
     920:      	ccmp	x15, x16, #0x0, hs
     924:      	csinc	w14, w14, wzr, ls
     928:      	xtn.2s	v10, v5
     92c:      	xtn.2s	v5, v1
     930:      	xtn.2s	v11, v4
     934:      	xtn.2s	v1, v3
     938:      	mov	w15, #0x801             ; =2049
     93c:      	dup.2s	v2, w15
     940:      	cmp	w14, #0x1
     944:      	adrp	x7, 0x0 <ltmp0>
     948:      	b.ne	0x131c <ltmp0+0x131c>
     94c:      	cbz	w12, 0x131c <ltmp0+0x131c>
     950:      	tbz	w13, #0x0, 0x131c <ltmp0+0x131c>
     954:      	mov	x12, #0x0               ; =0
     958:      	umull.2d	v6, v10, v8
     95c:      	umull.2d	v19, v5, v8
     960:      	umull.2d	v7, v11, v8
     964:      	umull.2d	v22, v1, v8
     968:      	fmov	x13, d22
     96c:      	add	x13, x13, #0x801
     970:      	fmov	x14, d3
     974:      	add	x14, x14, x14, lsl #11
     978:      	b	0x988 <ltmp0+0x988>
     97c:      	add	x12, x12, #0x8
     980:      	cmp	x12, #0x800
     984:      	b.eq	0xda0 <ltmp0+0xda0>
     988:      	ldr	q3, [x7]
     98c:      	and.16b	v3, v21, v3
     990:      	addv.8h	h24, v3
     994:      	fmov	w17, s24
     998:      	dup.2d	v3, x12
     99c:      	orr.16b	v26, v3, v20
     9a0:      	add.2d	v3, v26, v22
     9a4:      	fmov	x15, d3
     9a8:      	lsl	x15, x15, #2
     9ac:      	add	x16, x11, x15
     9b0:      	movi.2d	v25, #0000000000000000
     9b4:      	movi.2d	v23, #0000000000000000
     9b8:      	tbz	w17, #0x0, 0x9fc <ltmp0+0x9fc>
     9bc:      	ldr	s25, [x16]
     9c0:      	and	w17, w17, #0xff
     9c4:      	tbnz	w17, #0x1, 0xa04 <ltmp0+0xa04>
     9c8:      	tbz	w17, #0x2, 0xa10 <ltmp0+0xa10>
     9cc:      	add	x0, x16, #0x8
     9d0:      	ld1.s	{ v25 }[2], [x0]
     9d4:      	tbnz	w17, #0x3, 0xa14 <ltmp0+0xa14>
     9d8:      	tbz	w17, #0x4, 0xa20 <ltmp0+0xa20>
     9dc:      	add	x0, x16, #0x10
     9e0:      	ld1.s	{ v23 }[0], [x0]
     9e4:      	tbnz	w17, #0x5, 0xa24 <ltmp0+0xa24>
     9e8:      	tbz	w17, #0x6, 0xa30 <ltmp0+0xa30>
     9ec:      	add	x0, x16, #0x18
     9f0:      	ld1.s	{ v23 }[2], [x0]
     9f4:      	tbnz	w17, #0x7, 0xa34 <ltmp0+0xa34>
     9f8:      	b	0xa3c <ltmp0+0xa3c>
     9fc:      	and	w17, w17, #0xff
     a00:      	tbz	w17, #0x1, 0x9c8 <ltmp0+0x9c8>
     a04:      	add	x0, x16, #0x4
     a08:      	ld1.s	{ v25 }[1], [x0]
     a0c:      	tbnz	w17, #0x2, 0x9cc <ltmp0+0x9cc>
     a10:      	tbz	w17, #0x3, 0x9d8 <ltmp0+0x9d8>
     a14:      	add	x0, x16, #0xc
     a18:      	ld1.s	{ v25 }[3], [x0]
     a1c:      	tbnz	w17, #0x4, 0x9dc <ltmp0+0x9dc>
     a20:      	tbz	w17, #0x5, 0x9e8 <ltmp0+0x9e8>
     a24:      	add	x0, x16, #0x14
     a28:      	ld1.s	{ v23 }[1], [x0]
     a2c:      	tbnz	w17, #0x6, 0x9ec <ltmp0+0x9ec>
     a30:      	tbz	w17, #0x7, 0xa3c <ltmp0+0xa3c>
     a34:      	add	x16, x16, #0x1c
     a38:      	ld1.s	{ v23 }[3], [x16]
     a3c:      	fmov	w1, s24
     a40:      	fmov	x17, d26
     a44:      	add	x16, x13, x17
     a48:      	lsl	x16, x16, #2
     a4c:      	add	x0, x11, x16
     a50:      	movi.2d	v27, #0000000000000000
     a54:      	movi.2d	v26, #0000000000000000
     a58:      	tbz	w1, #0x0, 0xa9c <ltmp0+0xa9c>
     a5c:      	ldr	s27, [x0]
     a60:      	and	w1, w1, #0xff
     a64:      	tbnz	w1, #0x1, 0xaa4 <ltmp0+0xaa4>
     a68:      	tbz	w1, #0x2, 0xab0 <ltmp0+0xab0>
     a6c:      	add	x2, x0, #0x8
     a70:      	ld1.s	{ v27 }[2], [x2]
     a74:      	tbnz	w1, #0x3, 0xab4 <ltmp0+0xab4>
     a78:      	tbz	w1, #0x4, 0xac0 <ltmp0+0xac0>
     a7c:      	add	x2, x0, #0x10
     a80:      	ld1.s	{ v26 }[0], [x2]
     a84:      	tbnz	w1, #0x5, 0xac4 <ltmp0+0xac4>
     a88:      	tbz	w1, #0x6, 0xad0 <ltmp0+0xad0>
     a8c:      	add	x2, x0, #0x18
     a90:      	ld1.s	{ v26 }[2], [x2]
     a94:      	tbnz	w1, #0x7, 0xad4 <ltmp0+0xad4>
     a98:      	b	0xadc <ltmp0+0xadc>
     a9c:      	and	w1, w1, #0xff
     aa0:      	tbz	w1, #0x1, 0xa68 <ltmp0+0xa68>
     aa4:      	add	x2, x0, #0x4
     aa8:      	ld1.s	{ v27 }[1], [x2]
     aac:      	tbnz	w1, #0x2, 0xa6c <ltmp0+0xa6c>
     ab0:      	tbz	w1, #0x3, 0xa78 <ltmp0+0xa78>
     ab4:      	add	x2, x0, #0xc
     ab8:      	ld1.s	{ v27 }[3], [x2]
     abc:      	tbnz	w1, #0x4, 0xa7c <ltmp0+0xa7c>
     ac0:      	tbz	w1, #0x5, 0xa88 <ltmp0+0xa88>
     ac4:      	add	x2, x0, #0x14
     ac8:      	ld1.s	{ v26 }[1], [x2]
     acc:      	tbnz	w1, #0x6, 0xa8c <ltmp0+0xa8c>
     ad0:      	tbz	w1, #0x7, 0xadc <ltmp0+0xadc>
     ad4:      	add	x0, x0, #0x1c
     ad8:      	ld1.s	{ v26 }[3], [x0]
     adc:      	fmov	w1, s24
     ae0:      	add	x17, x17, x14
     ae4:      	lsl	x17, x17, #2
     ae8:      	add	x0, x10, x17
     aec:      	movi.2d	v29, #0000000000000000
     af0:      	movi.2d	v28, #0000000000000000
     af4:      	tbz	w1, #0x0, 0xc40 <ltmp0+0xc40>
     af8:      	ldr	s29, [x0]
     afc:      	and	w1, w1, #0xff
     b00:      	tbnz	w1, #0x1, 0xc48 <ltmp0+0xc48>
     b04:      	tbz	w1, #0x2, 0xc54 <ltmp0+0xc54>
     b08:      	add	x2, x0, #0x8
     b0c:      	ld1.s	{ v29 }[2], [x2]
     b10:      	tbnz	w1, #0x3, 0xc58 <ltmp0+0xc58>
     b14:      	tbz	w1, #0x4, 0xc64 <ltmp0+0xc64>
     b18:      	add	x2, x0, #0x10
     b1c:      	ld1.s	{ v28 }[0], [x2]
     b20:      	tbnz	w1, #0x5, 0xc68 <ltmp0+0xc68>
     b24:      	tbz	w1, #0x6, 0xc74 <ltmp0+0xc74>
     b28:      	add	x2, x0, #0x18
     b2c:      	ld1.s	{ v28 }[2], [x2]
     b30:      	tbnz	w1, #0x7, 0xc78 <ltmp0+0xc78>
     b34:      	fmov	w0, s24
     b38:      	add	x17, x9, x17
     b3c:      	movi.2d	v31, #0000000000000000
     b40:      	movi.2d	v30, #0000000000000000
     b44:      	tbz	w0, #0x0, 0xc94 <ltmp0+0xc94>
     b48:      	ldr	s31, [x17]
     b4c:      	and	w0, w0, #0xff
     b50:      	tbnz	w0, #0x1, 0xc9c <ltmp0+0xc9c>
     b54:      	tbz	w0, #0x2, 0xca8 <ltmp0+0xca8>
     b58:      	add	x1, x17, #0x8
     b5c:      	ld1.s	{ v31 }[2], [x1]
     b60:      	tbnz	w0, #0x3, 0xcac <ltmp0+0xcac>
     b64:      	tbz	w0, #0x4, 0xcb8 <ltmp0+0xcb8>
     b68:      	add	x1, x17, #0x10
     b6c:      	ld1.s	{ v30 }[0], [x1]
     b70:      	tbnz	w0, #0x5, 0xcbc <ltmp0+0xcbc>
     b74:      	tbz	w0, #0x6, 0xcc8 <ltmp0+0xcc8>
     b78:      	add	x1, x17, #0x18
     b7c:      	ld1.s	{ v30 }[2], [x1]
     b80:      	tbnz	w0, #0x7, 0xccc <ltmp0+0xccc>
     b84:      	fmov	w17, s24
     b88:      	fmul.4s	v3, v25, v29
     b8c:      	fmul.4s	v4, v27, v31
     b90:      	fsub.4s	v3, v3, v4
     b94:      	add	x15, x8, x15
     b98:      	tbz	w17, #0x0, 0xcec <ltmp0+0xcec>
     b9c:      	str	s3, [x15]
     ba0:      	and	w17, w17, #0xff
     ba4:      	tbnz	w17, #0x1, 0xcf4 <ltmp0+0xcf4>
     ba8:      	tbz	w17, #0x2, 0xd00 <ltmp0+0xd00>
     bac:      	add	x0, x15, #0x8
     bb0:      	st1.s	{ v3 }[2], [x0]
     bb4:      	tbnz	w17, #0x3, 0xd04 <ltmp0+0xd04>
     bb8:      	fmul.4s	v3, v23, v28
     bbc:      	fmul.4s	v4, v26, v30
     bc0:      	fsub.4s	v3, v3, v4
     bc4:      	tbz	w17, #0x4, 0xd1c <ltmp0+0xd1c>
     bc8:      	str	s3, [x15, #0x10]
     bcc:      	tbnz	w17, #0x5, 0xd20 <ltmp0+0xd20>
     bd0:      	tbz	w17, #0x6, 0xd2c <ltmp0+0xd2c>
     bd4:      	add	x0, x15, #0x18
     bd8:      	st1.s	{ v3 }[2], [x0]
     bdc:      	tbnz	w17, #0x7, 0xd30 <ltmp0+0xd30>
     be0:      	fmov	w17, s24
     be4:      	fmul.4s	v3, v25, v31
     be8:      	fmul.4s	v4, v27, v29
     bec:      	fadd.4s	v3, v4, v3
     bf0:      	add	x15, x8, x16
     bf4:      	tbz	w17, #0x0, 0xd50 <ltmp0+0xd50>
     bf8:      	str	s3, [x15]
     bfc:      	and	w16, w17, #0xff
     c00:      	tbnz	w16, #0x1, 0xd58 <ltmp0+0xd58>
     c04:      	tbz	w16, #0x2, 0xd64 <ltmp0+0xd64>
     c08:      	add	x17, x15, #0x8
     c0c:      	st1.s	{ v3 }[2], [x17]
     c10:      	tbnz	w16, #0x3, 0xd68 <ltmp0+0xd68>
     c14:      	fmul.4s	v3, v23, v30
     c18:      	fmul.4s	v4, v26, v28
     c1c:      	fadd.4s	v3, v4, v3
     c20:      	tbz	w16, #0x4, 0xd80 <ltmp0+0xd80>
     c24:      	str	s3, [x15, #0x10]
     c28:      	tbnz	w16, #0x5, 0xd84 <ltmp0+0xd84>
     c2c:      	tbz	w16, #0x6, 0xd90 <ltmp0+0xd90>
     c30:      	add	x17, x15, #0x18
     c34:      	st1.s	{ v3 }[2], [x17]
     c38:      	tbz	w16, #0x7, 0x97c <ltmp0+0x97c>
     c3c:      	b	0xd94 <ltmp0+0xd94>
     c40:      	and	w1, w1, #0xff
     c44:      	tbz	w1, #0x1, 0xb04 <ltmp0+0xb04>
     c48:      	add	x2, x0, #0x4
     c4c:      	ld1.s	{ v29 }[1], [x2]
     c50:      	tbnz	w1, #0x2, 0xb08 <ltmp0+0xb08>
     c54:      	tbz	w1, #0x3, 0xb14 <ltmp0+0xb14>
     c58:      	add	x2, x0, #0xc
     c5c:      	ld1.s	{ v29 }[3], [x2]
     c60:      	tbnz	w1, #0x4, 0xb18 <ltmp0+0xb18>
     c64:      	tbz	w1, #0x5, 0xb24 <ltmp0+0xb24>
     c68:      	add	x2, x0, #0x14
     c6c:      	ld1.s	{ v28 }[1], [x2]
     c70:      	tbnz	w1, #0x6, 0xb28 <ltmp0+0xb28>
     c74:      	tbz	w1, #0x7, 0xb34 <ltmp0+0xb34>
     c78:      	add	x0, x0, #0x1c
     c7c:      	ld1.s	{ v28 }[3], [x0]
     c80:      	fmov	w0, s24
     c84:      	add	x17, x9, x17
     c88:      	movi.2d	v31, #0000000000000000
     c8c:      	movi.2d	v30, #0000000000000000
     c90:      	tbnz	w0, #0x0, 0xb48 <ltmp0+0xb48>
     c94:      	and	w0, w0, #0xff
     c98:      	tbz	w0, #0x1, 0xb54 <ltmp0+0xb54>
     c9c:      	add	x1, x17, #0x4
     ca0:      	ld1.s	{ v31 }[1], [x1]
     ca4:      	tbnz	w0, #0x2, 0xb58 <ltmp0+0xb58>
     ca8:      	tbz	w0, #0x3, 0xb64 <ltmp0+0xb64>
     cac:      	add	x1, x17, #0xc
     cb0:      	ld1.s	{ v31 }[3], [x1]
     cb4:      	tbnz	w0, #0x4, 0xb68 <ltmp0+0xb68>
     cb8:      	tbz	w0, #0x5, 0xb74 <ltmp0+0xb74>
     cbc:      	add	x1, x17, #0x14
     cc0:      	ld1.s	{ v30 }[1], [x1]
     cc4:      	tbnz	w0, #0x6, 0xb78 <ltmp0+0xb78>
     cc8:      	tbz	w0, #0x7, 0xb84 <ltmp0+0xb84>
     ccc:      	add	x17, x17, #0x1c
     cd0:      	ld1.s	{ v30 }[3], [x17]
     cd4:      	fmov	w17, s24
     cd8:      	fmul.4s	v3, v25, v29
     cdc:      	fmul.4s	v4, v27, v31
     ce0:      	fsub.4s	v3, v3, v4
     ce4:      	add	x15, x8, x15
     ce8:      	tbnz	w17, #0x0, 0xb9c <ltmp0+0xb9c>
     cec:      	and	w17, w17, #0xff
     cf0:      	tbz	w17, #0x1, 0xba8 <ltmp0+0xba8>
     cf4:      	add	x0, x15, #0x4
     cf8:      	st1.s	{ v3 }[1], [x0]
     cfc:      	tbnz	w17, #0x2, 0xbac <ltmp0+0xbac>
     d00:      	tbz	w17, #0x3, 0xbb8 <ltmp0+0xbb8>
     d04:      	add	x0, x15, #0xc
     d08:      	st1.s	{ v3 }[3], [x0]
     d0c:      	fmul.4s	v3, v23, v28
     d10:      	fmul.4s	v4, v26, v30
     d14:      	fsub.4s	v3, v3, v4
     d18:      	tbnz	w17, #0x4, 0xbc8 <ltmp0+0xbc8>
     d1c:      	tbz	w17, #0x5, 0xbd0 <ltmp0+0xbd0>
     d20:      	add	x0, x15, #0x14
     d24:      	st1.s	{ v3 }[1], [x0]
     d28:      	tbnz	w17, #0x6, 0xbd4 <ltmp0+0xbd4>
     d2c:      	tbz	w17, #0x7, 0xbe0 <ltmp0+0xbe0>
     d30:      	add	x15, x15, #0x1c
     d34:      	st1.s	{ v3 }[3], [x15]
     d38:      	fmov	w17, s24
     d3c:      	fmul.4s	v3, v25, v31
     d40:      	fmul.4s	v4, v27, v29
     d44:      	fadd.4s	v3, v4, v3
     d48:      	add	x15, x8, x16
     d4c:      	tbnz	w17, #0x0, 0xbf8 <ltmp0+0xbf8>
     d50:      	and	w16, w17, #0xff
     d54:      	tbz	w16, #0x1, 0xc04 <ltmp0+0xc04>
     d58:      	add	x17, x15, #0x4
     d5c:      	st1.s	{ v3 }[1], [x17]
     d60:      	tbnz	w16, #0x2, 0xc08 <ltmp0+0xc08>
     d64:      	tbz	w16, #0x3, 0xc14 <ltmp0+0xc14>
     d68:      	add	x17, x15, #0xc
     d6c:      	st1.s	{ v3 }[3], [x17]
     d70:      	fmul.4s	v3, v23, v30
     d74:      	fmul.4s	v4, v26, v28
     d78:      	fadd.4s	v3, v4, v3
     d7c:      	tbnz	w16, #0x4, 0xc24 <ltmp0+0xc24>
     d80:      	tbz	w16, #0x5, 0xc2c <ltmp0+0xc2c>
     d84:      	add	x17, x15, #0x14
     d88:      	st1.s	{ v3 }[1], [x17]
     d8c:      	tbnz	w16, #0x6, 0xc30 <ltmp0+0xc30>
     d90:      	tbz	w16, #0x7, 0x97c <ltmp0+0x97c>
     d94:      	add	x15, x15, #0x1c
     d98:      	st1.s	{ v3 }[3], [x15]
     d9c:      	b	0x97c <ltmp0+0x97c>
     da0:      	xtn.4h	v0, v0
     da4:      	uzp1.8b	v0, v0, v0
     da8:      	movi.2d	v29, #0000000000000000
     dac:      	mov.b	v29[0], v0[0]
     db0:      	adrp	x12, 0x0 <ltmp0>
     db4:      	ldr	d26, [x12]
     db8:      	and.8b	v3, v29, v26
     dbc:      	addv.8b	b3, v3
     dc0:      	fmov	w13, s3
     dc4:      	umaxv.8b	b3, v29
     dc8:      	fmov	w15, s3
     dcc:      	rbit	w12, w13
     dd0:      	clz	w12, w12
     dd4:      	tst	w15, #0x1
     dd8:      	csel	w12, w12, wzr, ne
     ddc:      	mov	w14, #0x800             ; =2048
     de0:      	dup.2d	v31, x14
     de4:      	orr.16b	v30, v20, v31
     de8:      	add.2d	v23, v22, v30
     dec:      	movi.2d	v3, #0000000000000000
     df0:      	mov.b	v3[0], v0[0]
     df4:      	ushll.2d	v0, v3, #0x0
     df8:      	shl.2d	v0, v0, #0x3f
     dfc:      	cmlt.2d	v0, v0, #0
     e00:      	and.16b	v0, v0, v23
     e04:      	movi.2d	v3, #0000000000000000
     e08:      	stp	q3, q3, [sp, #0x240]
     e0c:      	stp	q0, q3, [sp, #0x220]
     e10:      	and	x14, x12, #0x7
     e14:      	add	x16, sp, #0x220
     e18:      	ldr	x14, [x16, x14, lsl #3]
     e1c:      	sub	x14, x14, x12
     e20:      	add	x14, x11, x14, lsl #2
     e24:      	movi.2d	v21, #0000000000000000
     e28:      	movi.2d	v0, #0000000000000000
     e2c:      	tbz	w15, #0x0, 0xe6c <ltmp0+0xe6c>
     e30:      	ldr	s21, [x14]
     e34:      	tbnz	w13, #0x1, 0xe70 <ltmp0+0xe70>
     e38:      	tbz	w13, #0x2, 0xe7c <ltmp0+0xe7c>
     e3c:      	add	x15, x14, #0x8
     e40:      	ld1.s	{ v21 }[2], [x15]
     e44:      	tbnz	w13, #0x3, 0xe80 <ltmp0+0xe80>
     e48:      	tbz	w13, #0x4, 0xe8c <ltmp0+0xe8c>
     e4c:      	add	x15, x14, #0x10
     e50:      	ld1.s	{ v0 }[0], [x15]
     e54:      	tbnz	w13, #0x5, 0xe90 <ltmp0+0xe90>
     e58:      	tbz	w13, #0x6, 0xe9c <ltmp0+0xe9c>
     e5c:      	add	x15, x14, #0x18
     e60:      	ld1.s	{ v0 }[2], [x15]
     e64:      	tbnz	w13, #0x7, 0xea0 <ltmp0+0xea0>
     e68:      	b	0xea8 <ltmp0+0xea8>
     e6c:      	tbz	w13, #0x1, 0xe38 <ltmp0+0xe38>
     e70:      	add	x15, x14, #0x4
     e74:      	ld1.s	{ v21 }[1], [x15]
     e78:      	tbnz	w13, #0x2, 0xe3c <ltmp0+0xe3c>
     e7c:      	tbz	w13, #0x3, 0xe48 <ltmp0+0xe48>
     e80:      	add	x15, x14, #0xc
     e84:      	ld1.s	{ v21 }[3], [x15]
     e88:      	tbnz	w13, #0x4, 0xe4c <ltmp0+0xe4c>
     e8c:      	tbz	w13, #0x5, 0xe58 <ltmp0+0xe58>
     e90:      	add	x15, x14, #0x14
     e94:      	ld1.s	{ v0 }[1], [x15]
     e98:      	tbnz	w13, #0x6, 0xe5c <ltmp0+0xe5c>
     e9c:      	tbz	w13, #0x7, 0xea8 <ltmp0+0xea8>
     ea0:      	add	x13, x14, #0x1c
     ea4:      	ld1.s	{ v0 }[3], [x13]
     ea8:      	add.2d	v3, v20, v22
     eac:      	add.2d	v4, v14, v6
     eb0:      	add.2d	v22, v15, v19
     eb4:      	add.2d	v20, v16, v7
     eb8:      	mov	w13, #0x1001            ; =4097
     ebc:      	dup.2d	v25, x13
     ec0:      	add.2d	v20, v20, v25
     ec4:      	add.2d	v22, v22, v25
     ec8:      	add.2d	v24, v4, v25
     ecc:      	mov	b4, v29[0]
     ed0:      	mov.b	v4[4], v29[1]
     ed4:      	add.2d	v25, v3, v25
     ed8:      	ushll.2d	v3, v4, #0x0
     edc:      	shl.2d	v3, v3, #0x3f
     ee0:      	cmlt.2d	v3, v3, #0
     ee4:      	and.16b	v3, v3, v25
     ee8:      	mov	b4, v29[2]
     eec:      	mov.b	v4[4], v29[3]
     ef0:      	ushll.2d	v4, v4, #0x0
     ef4:      	shl.2d	v4, v4, #0x3f
     ef8:      	cmlt.2d	v4, v4, #0
     efc:      	and.16b	v4, v4, v24
     f00:      	mov	b27, v29[4]
     f04:      	mov.b	v27[4], v29[5]
     f08:      	ushll.2d	v27, v27, #0x0
     f0c:      	shl.2d	v27, v27, #0x3f
     f10:      	cmlt.2d	v27, v27, #0
     f14:      	and.16b	v28, v27, v22
     f18:      	mov	b27, v29[6]
     f1c:      	mov.b	v27[4], v29[7]
     f20:      	ushll.2d	v27, v27, #0x0
     f24:      	shl.2d	v27, v27, #0x3f
     f28:      	cmlt.2d	v27, v27, #0
     f2c:      	and.16b	v9, v27, v20
     f30:      	shl.8b	v27, v29, #0x7
     f34:      	cmlt.8b	v27, v27, #0
     f38:      	and.8b	v26, v27, v26
     f3c:      	addv.8b	b27, v26
     f40:      	fmov	w13, s27
     f44:      	stp	q28, q9, [sp, #0x200]
     f48:      	stp	q3, q4, [sp, #0x1e0]
     f4c:      	and	x14, x12, #0x7
     f50:      	add	x15, sp, #0x1e0
     f54:      	ldr	x14, [x15, x14, lsl #3]
     f58:      	sub	x14, x14, x12
     f5c:      	add	x11, x11, x14, lsl #2
     f60:      	movi.2d	v28, #0000000000000000
     f64:      	movi.2d	v26, #0000000000000000
     f68:      	tbz	w13, #0x0, 0xfa8 <ltmp0+0xfa8>
     f6c:      	ldr	s28, [x11]
     f70:      	tbnz	w13, #0x1, 0xfac <ltmp0+0xfac>
     f74:      	tbz	w13, #0x2, 0xfb8 <ltmp0+0xfb8>
     f78:      	add	x14, x11, #0x8
     f7c:      	ld1.s	{ v28 }[2], [x14]
     f80:      	tbnz	w13, #0x3, 0xfbc <ltmp0+0xfbc>
     f84:      	tbz	w13, #0x4, 0xfc8 <ltmp0+0xfc8>
     f88:      	add	x14, x11, #0x10
     f8c:      	ld1.s	{ v26 }[0], [x14]
     f90:      	tbnz	w13, #0x5, 0xfcc <ltmp0+0xfcc>
     f94:      	tbz	w13, #0x6, 0xfd8 <ltmp0+0xfd8>
     f98:      	add	x14, x11, #0x18
     f9c:      	ld1.s	{ v26 }[2], [x14]
     fa0:      	tbnz	w13, #0x7, 0xfdc <ltmp0+0xfdc>
     fa4:      	b	0xfe4 <ltmp0+0xfe4>
     fa8:      	tbz	w13, #0x1, 0xf74 <ltmp0+0xf74>
     fac:      	add	x14, x11, #0x4
     fb0:      	ld1.s	{ v28 }[1], [x14]
     fb4:      	tbnz	w13, #0x2, 0xf78 <ltmp0+0xf78>
     fb8:      	tbz	w13, #0x3, 0xf84 <ltmp0+0xf84>
     fbc:      	add	x14, x11, #0xc
     fc0:      	ld1.s	{ v28 }[3], [x14]
     fc4:      	tbnz	w13, #0x4, 0xf88 <ltmp0+0xf88>
     fc8:      	tbz	w13, #0x5, 0xf94 <ltmp0+0xf94>
     fcc:      	add	x14, x11, #0x14
     fd0:      	ld1.s	{ v26 }[1], [x14]
     fd4:      	tbnz	w13, #0x6, 0xf98 <ltmp0+0xf98>
     fd8:      	tbz	w13, #0x7, 0xfe4 <ltmp0+0xfe4>
     fdc:      	add	x11, x11, #0x1c
     fe0:      	ld1.s	{ v26 }[3], [x11]
     fe4:      	orr.16b	v16, v16, v31
     fe8:      	orr.16b	v17, v14, v31
     fec:      	orr.16b	v18, v15, v31
     ff0:      	mov.16b	v3, v16
     ff4:      	umlal.2d	v3, v11, v2
     ff8:      	mov.16b	v4, v18
     ffc:      	umlal.2d	v4, v5, v2
    1000:      	mov.16b	v5, v17
    1004:      	umlal.2d	v5, v10, v2
    1008:      	umlal.2d	v30, v1, v2
    100c:      	mov	b1, v29[0]
    1010:      	mov.b	v1[4], v29[1]
    1014:      	ushll.2d	v1, v1, #0x0
    1018:      	shl.2d	v1, v1, #0x3f
    101c:      	cmlt.2d	v1, v1, #0
    1020:      	and.16b	v1, v1, v30
    1024:      	mov	b2, v29[2]
    1028:      	mov.b	v2[4], v29[3]
    102c:      	ushll.2d	v2, v2, #0x0
    1030:      	shl.2d	v2, v2, #0x3f
    1034:      	cmlt.2d	v2, v2, #0
    1038:      	and.16b	v2, v2, v5
    103c:      	mov	b5, v29[4]
    1040:      	mov.b	v5[4], v29[5]
    1044:      	ushll.2d	v5, v5, #0x0
    1048:      	shl.2d	v5, v5, #0x3f
    104c:      	cmlt.2d	v5, v5, #0
    1050:      	mov	b30, v29[6]
    1054:      	mov.b	v30[4], v29[7]
    1058:      	and.16b	v4, v5, v4
    105c:      	ushll.2d	v5, v30, #0x0
    1060:      	shl.2d	v5, v5, #0x3f
    1064:      	cmlt.2d	v5, v5, #0
    1068:      	and.16b	v3, v5, v3
    106c:      	stp	q4, q3, [sp, #0x1c0]
    1070:      	stp	q1, q2, [sp, #0x1a0]
    1074:      	and	x11, x12, #0x7
    1078:      	add	x13, sp, #0x1a0
    107c:      	ldr	x11, [x13, x11, lsl #3]
    1080:      	fmov	w13, s27
    1084:      	sub	x11, x11, x12
    1088:      	lsl	x11, x11, #2
    108c:      	add	x10, x10, x11
    1090:      	movi.2d	v2, #0000000000000000
    1094:      	movi.2d	v1, #0000000000000000
    1098:      	tbz	w13, #0x0, 0x1124 <ltmp0+0x1124>
    109c:      	ldr	s2, [x10]
    10a0:      	tbnz	w13, #0x1, 0x1128 <ltmp0+0x1128>
    10a4:      	tbz	w13, #0x2, 0x1134 <ltmp0+0x1134>
    10a8:      	add	x14, x10, #0x8
    10ac:      	ld1.s	{ v2 }[2], [x14]
    10b0:      	tbnz	w13, #0x3, 0x1138 <ltmp0+0x1138>
    10b4:      	tbz	w13, #0x4, 0x1144 <ltmp0+0x1144>
    10b8:      	add	x14, x10, #0x10
    10bc:      	ld1.s	{ v1 }[0], [x14]
    10c0:      	tbnz	w13, #0x5, 0x1148 <ltmp0+0x1148>
    10c4:      	tbz	w13, #0x6, 0x1154 <ltmp0+0x1154>
    10c8:      	add	x14, x10, #0x18
    10cc:      	ld1.s	{ v1 }[2], [x14]
    10d0:      	tbnz	w13, #0x7, 0x1158 <ltmp0+0x1158>
    10d4:      	add	x9, x9, x11
    10d8:      	fmov	w10, s27
    10dc:      	movi.2d	v4, #0000000000000000
    10e0:      	movi.2d	v3, #0000000000000000
    10e4:      	tbz	w10, #0x0, 0x1174 <ltmp0+0x1174>
    10e8:      	ldr	s4, [x9]
    10ec:      	tbnz	w10, #0x1, 0x1178 <ltmp0+0x1178>
    10f0:      	tbz	w10, #0x2, 0x1184 <ltmp0+0x1184>
    10f4:      	add	x11, x9, #0x8
    10f8:      	ld1.s	{ v4 }[2], [x11]
    10fc:      	tbnz	w10, #0x3, 0x1188 <ltmp0+0x1188>
    1100:      	tbz	w10, #0x4, 0x1194 <ltmp0+0x1194>
    1104:      	add	x11, x9, #0x10
    1108:      	ld1.s	{ v3 }[0], [x11]
    110c:      	tbnz	w10, #0x5, 0x1198 <ltmp0+0x1198>
    1110:      	tbz	w10, #0x6, 0x11a4 <ltmp0+0x11a4>
    1114:      	add	x11, x9, #0x18
    1118:      	ld1.s	{ v3 }[2], [x11]
    111c:      	tbnz	w10, #0x7, 0x11a8 <ltmp0+0x11a8>
    1120:      	b	0x11b0 <ltmp0+0x11b0>
    1124:      	tbz	w13, #0x1, 0x10a4 <ltmp0+0x10a4>
    1128:      	add	x14, x10, #0x4
    112c:      	ld1.s	{ v2 }[1], [x14]
    1130:      	tbnz	w13, #0x2, 0x10a8 <ltmp0+0x10a8>
    1134:      	tbz	w13, #0x3, 0x10b4 <ltmp0+0x10b4>
    1138:      	add	x14, x10, #0xc
    113c:      	ld1.s	{ v2 }[3], [x14]
    1140:      	tbnz	w13, #0x4, 0x10b8 <ltmp0+0x10b8>
    1144:      	tbz	w13, #0x5, 0x10c4 <ltmp0+0x10c4>
    1148:      	add	x14, x10, #0x14
    114c:      	ld1.s	{ v1 }[1], [x14]
    1150:      	tbnz	w13, #0x6, 0x10c8 <ltmp0+0x10c8>
    1154:      	tbz	w13, #0x7, 0x10d4 <ltmp0+0x10d4>
    1158:      	add	x10, x10, #0x1c
    115c:      	ld1.s	{ v1 }[3], [x10]
    1160:      	add	x9, x9, x11
    1164:      	fmov	w10, s27
    1168:      	movi.2d	v4, #0000000000000000
    116c:      	movi.2d	v3, #0000000000000000
    1170:      	tbnz	w10, #0x0, 0x10e8 <ltmp0+0x10e8>
    1174:      	tbz	w10, #0x1, 0x10f0 <ltmp0+0x10f0>
    1178:      	add	x11, x9, #0x4
    117c:      	ld1.s	{ v4 }[1], [x11]
    1180:      	tbnz	w10, #0x2, 0x10f4 <ltmp0+0x10f4>
    1184:      	tbz	w10, #0x3, 0x1100 <ltmp0+0x1100>
    1188:      	add	x11, x9, #0xc
    118c:      	ld1.s	{ v4 }[3], [x11]
    1190:      	tbnz	w10, #0x4, 0x1104 <ltmp0+0x1104>
    1194:      	tbz	w10, #0x5, 0x1110 <ltmp0+0x1110>
    1198:      	add	x11, x9, #0x14
    119c:      	ld1.s	{ v3 }[1], [x11]
    11a0:      	tbnz	w10, #0x6, 0x1114 <ltmp0+0x1114>
    11a4:      	tbz	w10, #0x7, 0x11b0 <ltmp0+0x11b0>
    11a8:      	add	x9, x9, #0x1c
    11ac:      	ld1.s	{ v3 }[3], [x9]
    11b0:      	add.2d	v18, v19, v18
    11b4:      	add.2d	v6, v6, v17
    11b8:      	add.2d	v7, v7, v16
    11bc:      	fmul.4s	v5, v21, v2
    11c0:      	fmul.4s	v16, v28, v4
    11c4:      	fsub.4s	v5, v5, v16
    11c8:      	stp	q23, q6, [sp, #0x160]
    11cc:      	stp	q18, q7, [sp, #0x180]
    11d0:      	and	x9, x12, #0x7
    11d4:      	add	x10, sp, #0x160
    11d8:      	ldr	x9, [x10, x9, lsl #3]
    11dc:      	sub	x9, x9, x12
    11e0:      	add	x9, x8, x9, lsl #2
    11e4:      	fmov	w10, s27
    11e8:      	tbz	w10, #0x0, 0x1230 <ltmp0+0x1230>
    11ec:      	str	s5, [x9]
    11f0:      	tbnz	w10, #0x1, 0x1234 <ltmp0+0x1234>
    11f4:      	tbz	w10, #0x2, 0x1240 <ltmp0+0x1240>
    11f8:      	add	x11, x9, #0x8
    11fc:      	st1.s	{ v5 }[2], [x11]
    1200:      	tbnz	w10, #0x3, 0x1244 <ltmp0+0x1244>
    1204:      	fmul.4s	v5, v0, v1
    1208:      	fmul.4s	v6, v26, v3
    120c:      	fsub.4s	v5, v5, v6
    1210:      	tbz	w10, #0x4, 0x125c <ltmp0+0x125c>
    1214:      	str	s5, [x9, #0x10]
    1218:      	tbnz	w10, #0x5, 0x1260 <ltmp0+0x1260>
    121c:      	tbz	w10, #0x6, 0x126c <ltmp0+0x126c>
    1220:      	add	x11, x9, #0x18
    1224:      	st1.s	{ v5 }[2], [x11]
    1228:      	tbnz	w10, #0x7, 0x1270 <ltmp0+0x1270>
    122c:      	b	0x1278 <ltmp0+0x1278>
    1230:      	tbz	w10, #0x1, 0x11f4 <ltmp0+0x11f4>
    1234:      	add	x11, x9, #0x4
    1238:      	st1.s	{ v5 }[1], [x11]
    123c:      	tbnz	w10, #0x2, 0x11f8 <ltmp0+0x11f8>
    1240:      	tbz	w10, #0x3, 0x1204 <ltmp0+0x1204>
    1244:      	add	x11, x9, #0xc
    1248:      	st1.s	{ v5 }[3], [x11]
    124c:      	fmul.4s	v5, v0, v1
    1250:      	fmul.4s	v6, v26, v3
    1254:      	fsub.4s	v5, v5, v6
    1258:      	tbnz	w10, #0x4, 0x1214 <ltmp0+0x1214>
    125c:      	tbz	w10, #0x5, 0x121c <ltmp0+0x121c>
    1260:      	add	x11, x9, #0x14
    1264:      	st1.s	{ v5 }[1], [x11]
    1268:      	tbnz	w10, #0x6, 0x1220 <ltmp0+0x1220>
    126c:      	tbz	w10, #0x7, 0x1278 <ltmp0+0x1278>
    1270:      	add	x9, x9, #0x1c
    1274:      	st1.s	{ v5 }[3], [x9]
    1278:      	fmul.4s	v4, v21, v4
    127c:      	fmul.4s	v2, v28, v2
    1280:      	fadd.4s	v2, v2, v4
    1284:      	stp	q25, q24, [sp, #0x120]
    1288:      	stp	q22, q20, [sp, #0x140]
    128c:      	and	x9, x12, #0x7
    1290:      	add	x10, sp, #0x120
    1294:      	ldr	x9, [x10, x9, lsl #3]
    1298:      	sub	x9, x9, x12
    129c:      	add	x8, x8, x9, lsl #2
    12a0:      	fmov	w9, s27
    12a4:      	tbz	w9, #0x0, 0x12ec <ltmp0+0x12ec>
    12a8:      	str	s2, [x8]
    12ac:      	tbnz	w9, #0x1, 0x12f0 <ltmp0+0x12f0>
    12b0:      	tbz	w9, #0x2, 0x12fc <ltmp0+0x12fc>
    12b4:      	add	x10, x8, #0x8
    12b8:      	st1.s	{ v2 }[2], [x10]
    12bc:      	tbnz	w9, #0x3, 0x1300 <ltmp0+0x1300>
    12c0:      	fmul.4s	v0, v0, v3
    12c4:      	fmul.4s	v1, v26, v1
    12c8:      	fadd.4s	v0, v1, v0
    12cc:      	tbz	w9, #0x4, 0x2064 <ltmp0+0x2064>
    12d0:      	str	s0, [x8, #0x10]
    12d4:      	tbnz	w9, #0x5, 0x2068 <ltmp0+0x2068>
    12d8:      	tbz	w9, #0x6, 0x2074 <ltmp0+0x2074>
    12dc:      	add	x10, x8, #0x18
    12e0:      	st1.s	{ v0 }[2], [x10]
    12e4:      	tbnz	w9, #0x7, 0x2078 <ltmp0+0x2078>
    12e8:      	b	0xb4 <ltmp0+0xb4>
    12ec:      	tbz	w9, #0x1, 0x12b0 <ltmp0+0x12b0>
    12f0:      	add	x10, x8, #0x4
    12f4:      	st1.s	{ v2 }[1], [x10]
    12f8:      	tbnz	w9, #0x2, 0x12b4 <ltmp0+0x12b4>
    12fc:      	tbz	w9, #0x3, 0x12c0 <ltmp0+0x12c0>
    1300:      	add	x10, x8, #0xc
    1304:      	st1.s	{ v2 }[3], [x10]
    1308:      	fmul.4s	v0, v0, v3
    130c:      	fmul.4s	v1, v26, v1
    1310:      	fadd.4s	v0, v1, v0
    1314:      	tbz	w9, #0x4, 0x2064 <ltmp0+0x2064>
    1318:      	b	0x12d0 <ltmp0+0x12d0>
    131c:      	mov	x12, #0x0               ; =0
    1320:      	fmov	x15, d3
    1324:      	mov	w13, #0x4008            ; =16392
    1328:      	umaddl	x13, w15, w13, x11
    132c:      	b	0x1350 <ltmp0+0x1350>
    1330:      	add	x14, x3, x12
    1334:      	ldp	q4, q22, [x14]
    1338:      	bif.16b	v3, v22, v6
    133c:      	bit.16b	v4, v19, v0
    1340:      	stp	q4, q3, [x14]
    1344:      	add	x12, x12, #0x20
    1348:      	cmp	x12, #0x2, lsl #12      ; =0x2000
    134c:      	b.eq	0x13f4 <ltmp0+0x13f4>
    1350:      	ldr	q3, [x7]
    1354:      	and.16b	v3, v21, v3
    1358:      	addv.8h	h7, v3
    135c:      	fmov	w16, s7
    1360:      	add	x14, x13, x12
    1364:      	movi.2d	v19, #0000000000000000
    1368:      	movi.2d	v3, #0000000000000000
    136c:      	tbz	w16, #0x0, 0x13b0 <ltmp0+0x13b0>
    1370:      	ldr	s19, [x14]
    1374:      	and	w16, w16, #0xff
    1378:      	tbnz	w16, #0x1, 0x13b8 <ltmp0+0x13b8>
    137c:      	tbz	w16, #0x2, 0x13c4 <ltmp0+0x13c4>
    1380:      	add	x17, x14, #0x8
    1384:      	ld1.s	{ v19 }[2], [x17]
    1388:      	tbnz	w16, #0x3, 0x13c8 <ltmp0+0x13c8>
    138c:      	tbz	w16, #0x4, 0x13d4 <ltmp0+0x13d4>
    1390:      	add	x17, x14, #0x10
    1394:      	ld1.s	{ v3 }[0], [x17]
    1398:      	tbnz	w16, #0x5, 0x13d8 <ltmp0+0x13d8>
    139c:      	tbz	w16, #0x6, 0x13e4 <ltmp0+0x13e4>
    13a0:      	add	x17, x14, #0x18
    13a4:      	ld1.s	{ v3 }[2], [x17]
    13a8:      	tbz	w16, #0x7, 0x1330 <ltmp0+0x1330>
    13ac:      	b	0x13e8 <ltmp0+0x13e8>
    13b0:      	and	w16, w16, #0xff
    13b4:      	tbz	w16, #0x1, 0x137c <ltmp0+0x137c>
    13b8:      	add	x17, x14, #0x4
    13bc:      	ld1.s	{ v19 }[1], [x17]
    13c0:      	tbnz	w16, #0x2, 0x1380 <ltmp0+0x1380>
    13c4:      	tbz	w16, #0x3, 0x138c <ltmp0+0x138c>
    13c8:      	add	x17, x14, #0xc
    13cc:      	ld1.s	{ v19 }[3], [x17]
    13d0:      	tbnz	w16, #0x4, 0x1390 <ltmp0+0x1390>
    13d4:      	tbz	w16, #0x5, 0x139c <ltmp0+0x139c>
    13d8:      	add	x17, x14, #0x14
    13dc:      	ld1.s	{ v3 }[1], [x17]
    13e0:      	tbnz	w16, #0x6, 0x13a0 <ltmp0+0x13a0>
    13e4:      	tbz	w16, #0x7, 0x1330 <ltmp0+0x1330>
    13e8:      	add	x14, x14, #0x1c
    13ec:      	ld1.s	{ v3 }[3], [x14]
    13f0:      	b	0x1330 <ltmp0+0x1330>
    13f4:      	str	d11, [sp, #0x110]
    13f8:      	xtn.4h	v3, v0
    13fc:      	uzp1.8b	v3, v3, v0
    1400:      	movi.2d	v19, #0000000000000000
    1404:      	mov.b	v19[0], v3[0]
    1408:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    140c:      	ldr	d31, [x12]
    1410:      	and.8b	v4, v19, v31
    1414:      	addv.8b	b4, v4
    1418:      	fmov	w13, s4
    141c:      	umaxv.8b	b4, v19
    1420:      	fmov	w16, s4
    1424:      	rbit	w12, w13
    1428:      	clz	w12, w12
    142c:      	tst	w16, #0x1
    1430:      	csel	w12, w12, wzr, ne
    1434:      	mov	w14, #0x800             ; =2048
    1438:      	dup.2d	v21, x14
    143c:      	orr.16b	v11, v20, v21
    1440:      	mov.16b	v17, v11
    1444:      	umlal.2d	v17, v1, v8
    1448:      	movi.2d	v4, #0000000000000000
    144c:      	mov.b	v4[0], v3[0]
    1450:      	ushll.2d	v3, v4, #0x0
    1454:      	shl.2d	v3, v3, #0x3f
    1458:      	cmlt.2d	v3, v3, #0
    145c:      	str	q17, [sp, #0xc0]
    1460:      	and.16b	v3, v3, v17
    1464:      	movi.2d	v4, #0000000000000000
    1468:      	str	q4, [sp, #0x420]
    146c:      	str	q4, [sp, #0x410]
    1470:      	stp	q3, q4, [sp, #0x3f0]
    1474:      	and	x14, x12, #0x7
    1478:      	add	x17, sp, #0x3f0
    147c:      	ldr	x14, [x17, x14, lsl #3]
    1480:      	sub	x14, x14, x12
    1484:      	add	x14, x11, x14, lsl #2
    1488:      	movi.2d	v25, #0000000000000000
    148c:      	movi.2d	v26, #0000000000000000
    1490:      	tbz	w16, #0x0, 0x14d0 <ltmp0+0x14d0>
    1494:      	ldr	s25, [x14]
    1498:      	tbnz	w13, #0x1, 0x14d4 <ltmp0+0x14d4>
    149c:      	tbz	w13, #0x2, 0x14e0 <ltmp0+0x14e0>
    14a0:      	add	x16, x14, #0x8
    14a4:      	ld1.s	{ v25 }[2], [x16]
    14a8:      	tbnz	w13, #0x3, 0x14e4 <ltmp0+0x14e4>
    14ac:      	tbz	w13, #0x4, 0x14f0 <ltmp0+0x14f0>
    14b0:      	add	x16, x14, #0x10
    14b4:      	ld1.s	{ v26 }[0], [x16]
    14b8:      	tbnz	w13, #0x5, 0x14f4 <ltmp0+0x14f4>
    14bc:      	tbz	w13, #0x6, 0x1500 <ltmp0+0x1500>
    14c0:      	add	x16, x14, #0x18
    14c4:      	ld1.s	{ v26 }[2], [x16]
    14c8:      	tbnz	w13, #0x7, 0x1504 <ltmp0+0x1504>
    14cc:      	b	0x150c <ltmp0+0x150c>
    14d0:      	tbz	w13, #0x1, 0x149c <ltmp0+0x149c>
    14d4:      	add	x16, x14, #0x4
    14d8:      	ld1.s	{ v25 }[1], [x16]
    14dc:      	tbnz	w13, #0x2, 0x14a0 <ltmp0+0x14a0>
    14e0:      	tbz	w13, #0x3, 0x14ac <ltmp0+0x14ac>
    14e4:      	add	x16, x14, #0xc
    14e8:      	ld1.s	{ v25 }[3], [x16]
    14ec:      	tbnz	w13, #0x4, 0x14b0 <ltmp0+0x14b0>
    14f0:      	tbz	w13, #0x5, 0x14bc <ltmp0+0x14bc>
    14f4:      	add	x16, x14, #0x14
    14f8:      	ld1.s	{ v26 }[1], [x16]
    14fc:      	tbnz	w13, #0x6, 0x14c0 <ltmp0+0x14c0>
    1500:      	tbz	w13, #0x7, 0x150c <ltmp0+0x150c>
    1504:      	add	x14, x14, #0x1c
    1508:      	ld1.s	{ v26 }[3], [x14]
    150c:      	mov	x17, #0x0               ; =0
    1510:      	orr.16b	v12, v16, v21
    1514:      	mov.16b	v13, v14
    1518:      	orr.16b	v14, v14, v21
    151c:      	mov.16b	v18, v15
    1520:      	orr.16b	v17, v15, v21
    1524:      	umull.2d	v9, v1, v8
    1528:      	fmov	d3, d10
    152c:      	umull.2d	v10, v10, v8
    1530:      	umull.2d	v15, v5, v8
    1534:      	ldr	d4, [sp, #0x110]
    1538:      	umull.2d	v21, v4, v8
    153c:      	mov.16b	v22, v17
    1540:      	str	d5, [sp, #0xe0]
    1544:      	umlal.2d	v22, v5, v8
    1548:      	mov.16b	v5, v14
    154c:      	str	d3, [sp, #0xf0]
    1550:      	umlal.2d	v5, v3, v8
    1554:      	stp	q5, q22, [sp, #0xa0]
    1558:      	mov.16b	v3, v12
    155c:      	umlal.2d	v3, v4, v8
    1560:      	str	q3, [sp, #0x60]
    1564:      	adrp	x14, 0x1000 <ltmp0+0x1000>
    1568:      	ldr	q3, [x14]
    156c:      	mov	w14, #0x2000            ; =8192
    1570:      	dup.2d	v4, x14
    1574:      	sshll.2d	v27, v0, #0x0
    1578:      	bif.16b	v3, v4, v27
    157c:      	adrp	x14, 0x1000 <ltmp0+0x1000>
    1580:      	ldr	q27, [x14]
    1584:      	sshll.2d	v28, v6, #0x0
    1588:      	bif.16b	v27, v4, v28
    158c:      	adrp	x14, 0x1000 <ltmp0+0x1000>
    1590:      	ldr	q28, [x14]
    1594:      	bsl.16b	v24, v28, v4
    1598:      	adrp	x14, 0x1000 <ltmp0+0x1000>
    159c:      	ldr	q28, [x14]
    15a0:      	bit.16b	v4, v28, v23
    15a4:      	stp	q27, q4, [sp, #0x3d0]
    15a8:      	stp	q3, q24, [sp, #0x3b0]
    15ac:      	and	x14, x12, #0x7
    15b0:      	add	x16, sp, #0x3b0
    15b4:      	ldr	x14, [x16, x14, lsl #3]
    15b8:      	sub	x14, x14, x12, lsl #2
    15bc:      	tst	w13, #0xff
    15c0:      	csel	x13, xzr, x14, eq
    15c4:      	add	x14, x3, x13
    15c8:      	ldp	q3, q4, [x14]
    15cc:      	zip2.8b	v23, v19, v0
    15d0:      	ushll.4s	v23, v23, #0x0
    15d4:      	shl.4s	v23, v23, #0x1f
    15d8:      	cmlt.4s	v23, v23, #0
    15dc:      	mov.16b	v5, v23
    15e0:      	bsl.16b	v5, v26, v4
    15e4:      	zip1.8b	v4, v19, v0
    15e8:      	ushll.4s	v4, v4, #0x0
    15ec:      	shl.4s	v4, v4, #0x1f
    15f0:      	cmlt.4s	v4, v4, #0
    15f4:      	bit.16b	v3, v25, v4
    15f8:      	str	q3, [sp, #0x100]
    15fc:      	stp	q3, q5, [x14]
    1600:      	str	q5, [sp, #0xd0]
    1604:      	fmov	x14, d9
    1608:      	ushll2.2d	v3, v6, #0x0
    160c:      	mov	w16, #0x1               ; =1
    1610:      	dup.2d	v4, x16
    1614:      	and.16b	v24, v3, v4
    1618:      	ushll2.2d	v3, v0, #0x0
    161c:      	and.16b	v25, v3, v4
    1620:      	ushll.2d	v3, v6, #0x0
    1624:      	and.16b	v26, v3, v4
    1628:      	ushll.2d	v3, v0, #0x0
    162c:      	and.16b	v27, v3, v4
    1630:      	lsl	x14, x14, #2
    1634:      	mov	w16, #0x2004            ; =8196
    1638:      	add	x16, x11, x16
    163c:      	add	x16, x16, x14
    1640:      	movi.2d	v23, #0000000000000000
    1644:      	movi.2d	v28, #0000000000000000
    1648:      	movi.2d	v29, #0000000000000000
    164c:      	movi.2d	v30, #0000000000000000
    1650:      	b	0x1684 <ltmp0+0x1684>
    1654:      	add	x17, x4, x17
    1658:      	ldp	q5, q22, [x17]
    165c:      	bif.16b	v4, v22, v6
    1660:      	bif.16b	v3, v5, v0
    1664:      	stp	q3, q4, [x17]
    1668:      	add.2d	v28, v28, v25
    166c:      	add.2d	v29, v29, v26
    1670:      	add.2d	v30, v30, v24
    1674:      	add.2d	v23, v23, v27
    1678:      	fmov	x17, d23
    167c:      	cmp	x17, #0x100
    1680:      	b.ge	0x1720 <ltmp0+0x1720>
    1684:      	fmov	w1, s7
    1688:      	lsl	x17, x17, #5
    168c:      	add	x0, x16, x17
    1690:      	movi.2d	v3, #0000000000000000
    1694:      	movi.2d	v4, #0000000000000000
    1698:      	tbz	w1, #0x0, 0x16dc <ltmp0+0x16dc>
    169c:      	ldr	s3, [x0]
    16a0:      	and	w1, w1, #0xff
    16a4:      	tbnz	w1, #0x1, 0x16e4 <ltmp0+0x16e4>
    16a8:      	tbz	w1, #0x2, 0x16f0 <ltmp0+0x16f0>
    16ac:      	add	x2, x0, #0x8
    16b0:      	ld1.s	{ v3 }[2], [x2]
    16b4:      	tbnz	w1, #0x3, 0x16f4 <ltmp0+0x16f4>
    16b8:      	tbz	w1, #0x4, 0x1700 <ltmp0+0x1700>
    16bc:      	add	x2, x0, #0x10
    16c0:      	ld1.s	{ v4 }[0], [x2]
    16c4:      	tbnz	w1, #0x5, 0x1704 <ltmp0+0x1704>
    16c8:      	tbz	w1, #0x6, 0x1710 <ltmp0+0x1710>
    16cc:      	add	x2, x0, #0x18
    16d0:      	ld1.s	{ v4 }[2], [x2]
    16d4:      	tbz	w1, #0x7, 0x1654 <ltmp0+0x1654>
    16d8:      	b	0x1714 <ltmp0+0x1714>
    16dc:      	and	w1, w1, #0xff
    16e0:      	tbz	w1, #0x1, 0x16a8 <ltmp0+0x16a8>
    16e4:      	add	x2, x0, #0x4
    16e8:      	ld1.s	{ v3 }[1], [x2]
    16ec:      	tbnz	w1, #0x2, 0x16ac <ltmp0+0x16ac>
    16f0:      	tbz	w1, #0x3, 0x16b8 <ltmp0+0x16b8>
    16f4:      	add	x2, x0, #0xc
    16f8:      	ld1.s	{ v3 }[3], [x2]
    16fc:      	tbnz	w1, #0x4, 0x16bc <ltmp0+0x16bc>
    1700:      	tbz	w1, #0x5, 0x16c8 <ltmp0+0x16c8>
    1704:      	add	x2, x0, #0x14
    1708:      	ld1.s	{ v4 }[1], [x2]
    170c:      	tbnz	w1, #0x6, 0x16cc <ltmp0+0x16cc>
    1710:      	tbz	w1, #0x7, 0x1654 <ltmp0+0x1654>
    1714:      	add	x0, x0, #0x1c
    1718:      	ld1.s	{ v4 }[3], [x0]
    171c:      	b	0x1654 <ltmp0+0x1654>
    1720:      	add.2d	v3, v20, v9
    1724:      	add.2d	v4, v13, v10
    1728:      	add.2d	v5, v18, v15
    172c:      	add.2d	v16, v16, v21
    1730:      	mov	w16, #0x1001            ; =4097
    1734:      	dup.2d	v20, x16
    1738:      	add.2d	v18, v16, v20
    173c:      	add.2d	v15, v5, v20
    1740:      	add.2d	v16, v4, v20
    1744:      	mov	b4, v19[0]
    1748:      	mov.b	v4[4], v19[1]
    174c:      	add.2d	v20, v3, v20
    1750:      	ushll.2d	v3, v4, #0x0
    1754:      	shl.2d	v3, v3, #0x3f
    1758:      	cmlt.2d	v3, v3, #0
    175c:      	and.16b	v3, v3, v20
    1760:      	mov	b4, v19[2]
    1764:      	mov.b	v4[4], v19[3]
    1768:      	ushll.2d	v4, v4, #0x0
    176c:      	shl.2d	v4, v4, #0x3f
    1770:      	cmlt.2d	v4, v4, #0
    1774:      	and.16b	v4, v4, v16
    1778:      	mov	b5, v19[4]
    177c:      	mov.b	v5[4], v19[5]
    1780:      	ushll.2d	v5, v5, #0x0
    1784:      	shl.2d	v5, v5, #0x3f
    1788:      	cmlt.2d	v5, v5, #0
    178c:      	and.16b	v5, v5, v15
    1790:      	mov	b21, v19[6]
    1794:      	mov.b	v21[4], v19[7]
    1798:      	ushll.2d	v21, v21, #0x0
    179c:      	shl.2d	v21, v21, #0x3f
    17a0:      	cmlt.2d	v21, v21, #0
    17a4:      	str	q18, [sp, #0x10]
    17a8:      	and.16b	v21, v21, v18
    17ac:      	shl.8b	v22, v19, #0x7
    17b0:      	cmlt.8b	v22, v22, #0
    17b4:      	and.8b	v22, v22, v31
    17b8:      	addv.8b	b31, v22
    17bc:      	fmov	w16, s31
    17c0:      	stp	q5, q21, [sp, #0x380]
    17c4:      	stp	q3, q4, [sp, #0x360]
    17c8:      	and	x17, x12, #0x7
    17cc:      	add	x0, sp, #0x360
    17d0:      	ldr	x17, [x0, x17, lsl #3]
    17d4:      	sub	x17, x17, x12
    17d8:      	add	x11, x11, x17, lsl #2
    17dc:      	movi.2d	v21, #0000000000000000
    17e0:      	movi.2d	v3, #0000000000000000
    17e4:      	tbz	w16, #0x0, 0x1828 <ltmp0+0x1828>
    17e8:      	ldr	s21, [x11]
    17ec:      	fmov	d18, d1
    17f0:      	tbnz	w16, #0x1, 0x1830 <ltmp0+0x1830>
    17f4:      	tbz	w16, #0x2, 0x183c <ltmp0+0x183c>
    17f8:      	add	x17, x11, #0x8
    17fc:      	ld1.s	{ v21 }[2], [x17]
    1800:      	tbnz	w16, #0x3, 0x1840 <ltmp0+0x1840>
    1804:      	tbz	w16, #0x4, 0x184c <ltmp0+0x184c>
    1808:      	add	x17, x11, #0x10
    180c:      	ld1.s	{ v3 }[0], [x17]
    1810:      	tbnz	w16, #0x5, 0x1850 <ltmp0+0x1850>
    1814:      	tbz	w16, #0x6, 0x185c <ltmp0+0x185c>
    1818:      	add	x17, x11, #0x18
    181c:      	ld1.s	{ v3 }[2], [x17]
    1820:      	tbnz	w16, #0x7, 0x1860 <ltmp0+0x1860>
    1824:      	b	0x1868 <ltmp0+0x1868>
    1828:      	fmov	d18, d1
    182c:      	tbz	w16, #0x1, 0x17f4 <ltmp0+0x17f4>
    1830:      	add	x17, x11, #0x4
    1834:      	ld1.s	{ v21 }[1], [x17]
    1838:      	tbnz	w16, #0x2, 0x17f8 <ltmp0+0x17f8>
    183c:      	tbz	w16, #0x3, 0x1804 <ltmp0+0x1804>
    1840:      	add	x17, x11, #0xc
    1844:      	ld1.s	{ v21 }[3], [x17]
    1848:      	tbnz	w16, #0x4, 0x1808 <ltmp0+0x1808>
    184c:      	tbz	w16, #0x5, 0x1814 <ltmp0+0x1814>
    1850:      	add	x17, x11, #0x14
    1854:      	ld1.s	{ v3 }[1], [x17]
    1858:      	tbnz	w16, #0x6, 0x1818 <ltmp0+0x1818>
    185c:      	tbz	w16, #0x7, 0x1868 <ltmp0+0x1868>
    1860:      	add	x11, x11, #0x1c
    1864:      	ld1.s	{ v3 }[3], [x11]
    1868:      	mov	x16, #0x0               ; =0
    186c:      	add	x11, x4, x13
    1870:      	ldp	q4, q5, [x11]
    1874:      	zip2.8b	v22, v19, v0
    1878:      	ushll.4s	v22, v22, #0x0
    187c:      	shl.4s	v22, v22, #0x1f
    1880:      	cmlt.4s	v22, v22, #0
    1884:      	mov.16b	v9, v22
    1888:      	bsl.16b	v9, v3, v5
    188c:      	zip1.8b	v3, v19, v0
    1890:      	ushll.4s	v3, v3, #0x0
    1894:      	shl.4s	v3, v3, #0x1f
    1898:      	cmlt.4s	v3, v3, #0
    189c:      	mov.16b	v10, v3
    18a0:      	bsl.16b	v10, v21, v4
    18a4:      	stp	q10, q9, [x11]
    18a8:      	mov	w11, #0x2004            ; =8196
    18ac:      	umaddl	x11, w15, w11, x10
    18b0:      	movi.2d	v21, #0000000000000000
    18b4:      	movi.2d	v23, #0000000000000000
    18b8:      	movi.2d	v28, #0000000000000000
    18bc:      	movi.2d	v29, #0000000000000000
    18c0:      	b	0x18f4 <ltmp0+0x18f4>
    18c4:      	add	x15, x5, x15
    18c8:      	ldp	q5, q22, [x15]
    18cc:      	bif.16b	v4, v22, v6
    18d0:      	bif.16b	v3, v5, v0
    18d4:      	stp	q3, q4, [x15]
    18d8:      	add.2d	v23, v23, v25
    18dc:      	add.2d	v28, v28, v26
    18e0:      	add.2d	v29, v29, v24
    18e4:      	add.2d	v21, v21, v27
    18e8:      	fmov	x16, d21
    18ec:      	cmp	x16, #0x100
    18f0:      	b.ge	0x1990 <ltmp0+0x1990>
    18f4:      	fmov	w17, s7
    18f8:      	lsl	x15, x16, #5
    18fc:      	add	x16, x11, x15
    1900:      	movi.2d	v3, #0000000000000000
    1904:      	movi.2d	v4, #0000000000000000
    1908:      	tbz	w17, #0x0, 0x194c <ltmp0+0x194c>
    190c:      	ldr	s3, [x16]
    1910:      	and	w17, w17, #0xff
    1914:      	tbnz	w17, #0x1, 0x1954 <ltmp0+0x1954>
    1918:      	tbz	w17, #0x2, 0x1960 <ltmp0+0x1960>
    191c:      	add	x0, x16, #0x8
    1920:      	ld1.s	{ v3 }[2], [x0]
    1924:      	tbnz	w17, #0x3, 0x1964 <ltmp0+0x1964>
    1928:      	tbz	w17, #0x4, 0x1970 <ltmp0+0x1970>
    192c:      	add	x0, x16, #0x10
    1930:      	ld1.s	{ v4 }[0], [x0]
    1934:      	tbnz	w17, #0x5, 0x1974 <ltmp0+0x1974>
    1938:      	tbz	w17, #0x6, 0x1980 <ltmp0+0x1980>
    193c:      	add	x0, x16, #0x18
    1940:      	ld1.s	{ v4 }[2], [x0]
    1944:      	tbz	w17, #0x7, 0x18c4 <ltmp0+0x18c4>
    1948:      	b	0x1984 <ltmp0+0x1984>
    194c:      	and	w17, w17, #0xff
    1950:      	tbz	w17, #0x1, 0x1918 <ltmp0+0x1918>
    1954:      	add	x0, x16, #0x4
    1958:      	ld1.s	{ v3 }[1], [x0]
    195c:      	tbnz	w17, #0x2, 0x191c <ltmp0+0x191c>
    1960:      	tbz	w17, #0x3, 0x1928 <ltmp0+0x1928>
    1964:      	add	x0, x16, #0xc
    1968:      	ld1.s	{ v3 }[3], [x0]
    196c:      	tbnz	w17, #0x4, 0x192c <ltmp0+0x192c>
    1970:      	tbz	w17, #0x5, 0x1938 <ltmp0+0x1938>
    1974:      	add	x0, x16, #0x14
    1978:      	ld1.s	{ v4 }[1], [x0]
    197c:      	tbnz	w17, #0x6, 0x193c <ltmp0+0x193c>
    1980:      	tbz	w17, #0x7, 0x18c4 <ltmp0+0x18c4>
    1984:      	add	x16, x16, #0x1c
    1988:      	ld1.s	{ v4 }[3], [x16]
    198c:      	b	0x18c4 <ltmp0+0x18c4>
    1990:      	ldr	d1, [sp, #0x110]
    1994:      	umlal.2d	v12, v1, v2
    1998:      	ldr	d3, [sp, #0xe0]
    199c:      	umlal.2d	v17, v3, v2
    19a0:      	ldr	d3, [sp, #0xf0]
    19a4:      	umlal.2d	v14, v3, v2
    19a8:      	umlal.2d	v11, v18, v2
    19ac:      	mov	b3, v19[0]
    19b0:      	mov.b	v3[4], v19[1]
    19b4:      	ushll.2d	v3, v3, #0x0
    19b8:      	shl.2d	v3, v3, #0x3f
    19bc:      	cmlt.2d	v3, v3, #0
    19c0:      	and.16b	v3, v3, v11
    19c4:      	mov	b4, v19[2]
    19c8:      	mov.b	v4[4], v19[3]
    19cc:      	ushll.2d	v4, v4, #0x0
    19d0:      	shl.2d	v4, v4, #0x3f
    19d4:      	cmlt.2d	v4, v4, #0
    19d8:      	and.16b	v4, v4, v14
    19dc:      	mov	b5, v19[4]
    19e0:      	mov.b	v5[4], v19[5]
    19e4:      	ushll.2d	v5, v5, #0x0
    19e8:      	shl.2d	v5, v5, #0x3f
    19ec:      	cmlt.2d	v5, v5, #0
    19f0:      	mov	b21, v19[6]
    19f4:      	mov.b	v21[4], v19[7]
    19f8:      	and.16b	v5, v5, v17
    19fc:      	ushll.2d	v21, v21, #0x0
    1a00:      	shl.2d	v21, v21, #0x3f
    1a04:      	cmlt.2d	v21, v21, #0
    1a08:      	and.16b	v21, v21, v12
    1a0c:      	stp	q5, q21, [sp, #0x330]
    1a10:      	stp	q3, q4, [sp, #0x310]
    1a14:      	and	x11, x12, #0x7
    1a18:      	add	x15, sp, #0x310
    1a1c:      	ldr	x11, [x15, x11, lsl #3]
    1a20:      	fmov	w15, s31
    1a24:      	sub	x11, x11, x12
    1a28:      	lsl	x11, x11, #2
    1a2c:      	add	x10, x10, x11
    1a30:      	movi.2d	v3, #0000000000000000
    1a34:      	movi.2d	v4, #0000000000000000
    1a38:      	tbz	w15, #0x0, 0x1a7c <ltmp0+0x1a7c>
    1a3c:      	ldr	s3, [x10]
    1a40:      	ldr	q17, [sp, #0xd0]
    1a44:      	tbnz	w15, #0x1, 0x1a84 <ltmp0+0x1a84>
    1a48:      	tbz	w15, #0x2, 0x1a90 <ltmp0+0x1a90>
    1a4c:      	add	x16, x10, #0x8
    1a50:      	ld1.s	{ v3 }[2], [x16]
    1a54:      	tbnz	w15, #0x3, 0x1a94 <ltmp0+0x1a94>
    1a58:      	tbz	w15, #0x4, 0x1aa0 <ltmp0+0x1aa0>
    1a5c:      	add	x16, x10, #0x10
    1a60:      	ld1.s	{ v4 }[0], [x16]
    1a64:      	tbnz	w15, #0x5, 0x1aa4 <ltmp0+0x1aa4>
    1a68:      	tbz	w15, #0x6, 0x1ab0 <ltmp0+0x1ab0>
    1a6c:      	add	x16, x10, #0x18
    1a70:      	ld1.s	{ v4 }[2], [x16]
    1a74:      	tbnz	w15, #0x7, 0x1ab4 <ltmp0+0x1ab4>
    1a78:      	b	0x1abc <ltmp0+0x1abc>
    1a7c:      	ldr	q17, [sp, #0xd0]
    1a80:      	tbz	w15, #0x1, 0x1a48 <ltmp0+0x1a48>
    1a84:      	add	x16, x10, #0x4
    1a88:      	ld1.s	{ v3 }[1], [x16]
    1a8c:      	tbnz	w15, #0x2, 0x1a4c <ltmp0+0x1a4c>
    1a90:      	tbz	w15, #0x3, 0x1a58 <ltmp0+0x1a58>
    1a94:      	add	x16, x10, #0xc
    1a98:      	ld1.s	{ v3 }[3], [x16]
    1a9c:      	tbnz	w15, #0x4, 0x1a5c <ltmp0+0x1a5c>
    1aa0:      	tbz	w15, #0x5, 0x1a68 <ltmp0+0x1a68>
    1aa4:      	add	x16, x10, #0x14
    1aa8:      	ld1.s	{ v4 }[1], [x16]
    1aac:      	tbnz	w15, #0x6, 0x1a6c <ltmp0+0x1a6c>
    1ab0:      	tbz	w15, #0x7, 0x1abc <ltmp0+0x1abc>
    1ab4:      	add	x10, x10, #0x1c
    1ab8:      	ld1.s	{ v4 }[3], [x10]
    1abc:      	mov	x15, #0x0               ; =0
    1ac0:      	umull.2d	v5, v18, v2
    1ac4:      	add	x10, x5, x13
    1ac8:      	ldp	q2, q1, [x10]
    1acc:      	zip2.8b	v21, v19, v0
    1ad0:      	ushll.4s	v21, v21, #0x0
    1ad4:      	shl.4s	v21, v21, #0x1f
    1ad8:      	cmlt.4s	v21, v21, #0
    1adc:      	bit.16b	v1, v4, v21
    1ae0:      	zip1.8b	v4, v19, v0
    1ae4:      	ushll.4s	v4, v4, #0x0
    1ae8:      	shl.4s	v4, v4, #0x1f
    1aec:      	cmlt.4s	v4, v4, #0
    1af0:      	bit.16b	v2, v3, v4
    1af4:      	stp	q2, q1, [x10]
    1af8:      	fmov	x10, d5
    1afc:      	add	x10, x9, x10, lsl #2
    1b00:      	movi.2d	v3, #0000000000000000
    1b04:      	movi.2d	v4, #0000000000000000
    1b08:      	movi.2d	v5, #0000000000000000
    1b0c:      	movi.2d	v21, #0000000000000000
    1b10:      	b	0x1b44 <ltmp0+0x1b44>
    1b14:      	add	x15, x6, x15
    1b18:      	ldp	q22, q29, [x15]
    1b1c:      	bif.16b	v28, v29, v6
    1b20:      	bit.16b	v22, v23, v0
    1b24:      	stp	q22, q28, [x15]
    1b28:      	add.2d	v4, v4, v25
    1b2c:      	add.2d	v5, v5, v26
    1b30:      	add.2d	v21, v21, v24
    1b34:      	add.2d	v3, v3, v27
    1b38:      	fmov	x15, d3
    1b3c:      	cmp	x15, #0x100
    1b40:      	b.ge	0x1be0 <ltmp0+0x1be0>
    1b44:      	fmov	w17, s7
    1b48:      	lsl	x15, x15, #5
    1b4c:      	add	x16, x10, x15
    1b50:      	movi.2d	v23, #0000000000000000
    1b54:      	movi.2d	v28, #0000000000000000
    1b58:      	tbz	w17, #0x0, 0x1b9c <ltmp0+0x1b9c>
    1b5c:      	ldr	s23, [x16]
    1b60:      	and	w17, w17, #0xff
    1b64:      	tbnz	w17, #0x1, 0x1ba4 <ltmp0+0x1ba4>
    1b68:      	tbz	w17, #0x2, 0x1bb0 <ltmp0+0x1bb0>
    1b6c:      	add	x0, x16, #0x8
    1b70:      	ld1.s	{ v23 }[2], [x0]
    1b74:      	tbnz	w17, #0x3, 0x1bb4 <ltmp0+0x1bb4>
    1b78:      	tbz	w17, #0x4, 0x1bc0 <ltmp0+0x1bc0>
    1b7c:      	add	x0, x16, #0x10
    1b80:      	ld1.s	{ v28 }[0], [x0]
    1b84:      	tbnz	w17, #0x5, 0x1bc4 <ltmp0+0x1bc4>
    1b88:      	tbz	w17, #0x6, 0x1bd0 <ltmp0+0x1bd0>
    1b8c:      	add	x0, x16, #0x18
    1b90:      	ld1.s	{ v28 }[2], [x0]
    1b94:      	tbz	w17, #0x7, 0x1b14 <ltmp0+0x1b14>
    1b98:      	b	0x1bd4 <ltmp0+0x1bd4>
    1b9c:      	and	w17, w17, #0xff
    1ba0:      	tbz	w17, #0x1, 0x1b68 <ltmp0+0x1b68>
    1ba4:      	add	x0, x16, #0x4
    1ba8:      	ld1.s	{ v23 }[1], [x0]
    1bac:      	tbnz	w17, #0x2, 0x1b6c <ltmp0+0x1b6c>
    1bb0:      	tbz	w17, #0x3, 0x1b78 <ltmp0+0x1b78>
    1bb4:      	add	x0, x16, #0xc
    1bb8:      	ld1.s	{ v23 }[3], [x0]
    1bbc:      	tbnz	w17, #0x4, 0x1b7c <ltmp0+0x1b7c>
    1bc0:      	tbz	w17, #0x5, 0x1b88 <ltmp0+0x1b88>
    1bc4:      	add	x0, x16, #0x14
    1bc8:      	ld1.s	{ v28 }[1], [x0]
    1bcc:      	tbnz	w17, #0x6, 0x1b8c <ltmp0+0x1b8c>
    1bd0:      	tbz	w17, #0x7, 0x1b14 <ltmp0+0x1b14>
    1bd4:      	add	x16, x16, #0x1c
    1bd8:      	ld1.s	{ v28 }[3], [x16]
    1bdc:      	b	0x1b14 <ltmp0+0x1b14>
    1be0:      	add	x9, x9, x11
    1be4:      	fmov	w10, s31
    1be8:      	movi.2d	v4, #0000000000000000
    1bec:      	movi.2d	v3, #0000000000000000
    1bf0:      	tbz	w10, #0x0, 0x1c30 <ltmp0+0x1c30>
    1bf4:      	ldr	s4, [x9]
    1bf8:      	tbnz	w10, #0x1, 0x1c34 <ltmp0+0x1c34>
    1bfc:      	tbz	w10, #0x2, 0x1c40 <ltmp0+0x1c40>
    1c00:      	add	x11, x9, #0x8
    1c04:      	ld1.s	{ v4 }[2], [x11]
    1c08:      	tbnz	w10, #0x3, 0x1c44 <ltmp0+0x1c44>
    1c0c:      	tbz	w10, #0x4, 0x1c50 <ltmp0+0x1c50>
    1c10:      	add	x11, x9, #0x10
    1c14:      	ld1.s	{ v3 }[0], [x11]
    1c18:      	tbnz	w10, #0x5, 0x1c54 <ltmp0+0x1c54>
    1c1c:      	tbz	w10, #0x6, 0x1c60 <ltmp0+0x1c60>
    1c20:      	add	x11, x9, #0x18
    1c24:      	ld1.s	{ v3 }[2], [x11]
    1c28:      	tbnz	w10, #0x7, 0x1c64 <ltmp0+0x1c64>
    1c2c:      	b	0x1c6c <ltmp0+0x1c6c>
    1c30:      	tbz	w10, #0x1, 0x1bfc <ltmp0+0x1bfc>
    1c34:      	add	x11, x9, #0x4
    1c38:      	ld1.s	{ v4 }[1], [x11]
    1c3c:      	tbnz	w10, #0x2, 0x1c00 <ltmp0+0x1c00>
    1c40:      	tbz	w10, #0x3, 0x1c0c <ltmp0+0x1c0c>
    1c44:      	add	x11, x9, #0xc
    1c48:      	ld1.s	{ v4 }[3], [x11]
    1c4c:      	tbnz	w10, #0x4, 0x1c10 <ltmp0+0x1c10>
    1c50:      	tbz	w10, #0x5, 0x1c1c <ltmp0+0x1c1c>
    1c54:      	add	x11, x9, #0x14
    1c58:      	ld1.s	{ v3 }[1], [x11]
    1c5c:      	tbnz	w10, #0x6, 0x1c20 <ltmp0+0x1c20>
    1c60:      	tbz	w10, #0x7, 0x1c6c <ltmp0+0x1c6c>
    1c64:      	add	x9, x9, #0x1c
    1c68:      	ld1.s	{ v3 }[3], [x9]
    1c6c:      	mov	x10, #0x0               ; =0
    1c70:      	add	x9, x6, x13
    1c74:      	ldp	q5, q21, [x9]
    1c78:      	zip2.8b	v22, v19, v0
    1c7c:      	ushll.4s	v22, v22, #0x0
    1c80:      	shl.4s	v22, v22, #0x1f
    1c84:      	cmlt.4s	v22, v22, #0
    1c88:      	bif.16b	v3, v21, v22
    1c8c:      	zip1.8b	v21, v19, v0
    1c90:      	ushll.4s	v21, v21, #0x0
    1c94:      	shl.4s	v21, v21, #0x1f
    1c98:      	cmlt.4s	v21, v21, #0
    1c9c:      	bif.16b	v4, v5, v21
    1ca0:      	stp	q4, q3, [x9]
    1ca4:      	add	x9, x8, x14
    1ca8:      	movi.2d	v5, #0000000000000000
    1cac:      	movi.2d	v21, #0000000000000000
    1cb0:      	movi.2d	v23, #0000000000000000
    1cb4:      	movi.2d	v28, #0000000000000000
    1cb8:      	b	0x1cd8 <ltmp0+0x1cd8>
    1cbc:      	add.2d	v21, v21, v25
    1cc0:      	add.2d	v23, v23, v26
    1cc4:      	add.2d	v28, v28, v24
    1cc8:      	add.2d	v5, v5, v27
    1ccc:      	fmov	x10, d5
    1cd0:      	cmp	x10, #0x100
    1cd4:      	b.ge	0x1db8 <ltmp0+0x1db8>
    1cd8:      	fmov	w11, s7
    1cdc:      	lsl	x10, x10, #5
    1ce0:      	add	x13, x3, x10
    1ce4:      	ldp	q22, q29, [x13]
    1ce8:      	add	x13, x5, x10
    1cec:      	ldp	q11, q30, [x13]
    1cf0:      	fmul.4s	v22, v22, v11
    1cf4:      	add	x13, x4, x10
    1cf8:      	ldp	q13, q11, [x13]
    1cfc:      	add	x13, x6, x10
    1d00:      	ldp	q14, q12, [x13]
    1d04:      	fmul.4s	v13, v13, v14
    1d08:      	fsub.4s	v22, v22, v13
    1d0c:      	and.16b	v13, v0, v22
    1d10:      	add	x10, x9, x10
    1d14:      	tbz	w11, #0x0, 0x1d64 <ltmp0+0x1d64>
    1d18:      	str	s13, [x10]
    1d1c:      	and	w11, w11, #0xff
    1d20:      	tbnz	w11, #0x1, 0x1d6c <ltmp0+0x1d6c>
    1d24:      	tbz	w11, #0x2, 0x1d78 <ltmp0+0x1d78>
    1d28:      	add	x13, x10, #0x8
    1d2c:      	st1.s	{ v13 }[2], [x13]
    1d30:      	tbnz	w11, #0x3, 0x1d7c <ltmp0+0x1d7c>
    1d34:      	fmul.4s	v22, v29, v30
    1d38:      	fmul.4s	v29, v11, v12
    1d3c:      	fsub.4s	v22, v22, v29
    1d40:      	and.16b	v29, v6, v22
    1d44:      	tbz	w11, #0x4, 0x1d98 <ltmp0+0x1d98>
    1d48:      	str	s29, [x10, #0x10]
    1d4c:      	tbnz	w11, #0x5, 0x1d9c <ltmp0+0x1d9c>
    1d50:      	tbz	w11, #0x6, 0x1da8 <ltmp0+0x1da8>
    1d54:      	add	x13, x10, #0x18
    1d58:      	st1.s	{ v29 }[2], [x13]
    1d5c:      	tbz	w11, #0x7, 0x1cbc <ltmp0+0x1cbc>
    1d60:      	b	0x1dac <ltmp0+0x1dac>
    1d64:      	and	w11, w11, #0xff
    1d68:      	tbz	w11, #0x1, 0x1d24 <ltmp0+0x1d24>
    1d6c:      	add	x13, x10, #0x4
    1d70:      	st1.s	{ v13 }[1], [x13]
    1d74:      	tbnz	w11, #0x2, 0x1d28 <ltmp0+0x1d28>
    1d78:      	tbz	w11, #0x3, 0x1d34 <ltmp0+0x1d34>
    1d7c:      	add	x13, x10, #0xc
    1d80:      	st1.s	{ v13 }[3], [x13]
    1d84:      	fmul.4s	v22, v29, v30
    1d88:      	fmul.4s	v29, v11, v12
    1d8c:      	fsub.4s	v22, v22, v29
    1d90:      	and.16b	v29, v6, v22
    1d94:      	tbnz	w11, #0x4, 0x1d48 <ltmp0+0x1d48>
    1d98:      	tbz	w11, #0x5, 0x1d50 <ltmp0+0x1d50>
    1d9c:      	add	x13, x10, #0x14
    1da0:      	st1.s	{ v29 }[1], [x13]
    1da4:      	tbnz	w11, #0x6, 0x1d54 <ltmp0+0x1d54>
    1da8:      	tbz	w11, #0x7, 0x1cbc <ltmp0+0x1cbc>
    1dac:      	add	x10, x10, #0x1c
    1db0:      	st1.s	{ v29 }[3], [x10]
    1db4:      	b	0x1cbc <ltmp0+0x1cbc>
    1db8:      	ldr	q5, [sp, #0x100]
    1dbc:      	fmul.4s	v5, v5, v2
    1dc0:      	fmul.4s	v21, v10, v4
    1dc4:      	fsub.4s	v5, v5, v21
    1dc8:      	zip1.8b	v21, v19, v0
    1dcc:      	ushll.4s	v21, v21, #0x0
    1dd0:      	shl.4s	v21, v21, #0x1f
    1dd4:      	cmlt.4s	v21, v21, #0
    1dd8:      	and.16b	v5, v21, v5
    1ddc:      	fmov	w10, s31
    1de0:      	ldr	q21, [sp, #0xc0]
    1de4:      	ldp	q22, q23, [sp, #0xa0]
    1de8:      	stp	q21, q22, [sp, #0x2c0]
    1dec:      	ldr	q18, [sp, #0x60]
    1df0:      	stp	q23, q18, [sp, #0x2e0]
    1df4:      	and	x11, x12, #0x7
    1df8:      	add	x13, sp, #0x2c0
    1dfc:      	ldr	x11, [x13, x11, lsl #3]
    1e00:      	sub	x11, x11, x12
    1e04:      	add	x11, x8, x11, lsl #2
    1e08:      	tbz	w10, #0x0, 0x1e28 <ltmp0+0x1e28>
    1e0c:      	str	s5, [x11]
    1e10:      	tbnz	w10, #0x1, 0x1e2c <ltmp0+0x1e2c>
    1e14:      	tbz	w10, #0x2, 0x1e38 <ltmp0+0x1e38>
    1e18:      	add	x13, x11, #0x8
    1e1c:      	st1.s	{ v5 }[2], [x13]
    1e20:      	tbnz	w10, #0x3, 0x1e3c <ltmp0+0x1e3c>
    1e24:      	b	0x1e44 <ltmp0+0x1e44>
    1e28:      	tbz	w10, #0x1, 0x1e14 <ltmp0+0x1e14>
    1e2c:      	add	x13, x11, #0x4
    1e30:      	st1.s	{ v5 }[1], [x13]
    1e34:      	tbnz	w10, #0x2, 0x1e18 <ltmp0+0x1e18>
    1e38:      	tbz	w10, #0x3, 0x1e44 <ltmp0+0x1e44>
    1e3c:      	add	x13, x11, #0xc
    1e40:      	st1.s	{ v5 }[3], [x13]
    1e44:      	fmul.4s	v5, v17, v1
    1e48:      	fmul.4s	v21, v9, v3
    1e4c:      	fsub.4s	v5, v5, v21
    1e50:      	zip2.8b	v21, v19, v0
    1e54:      	ushll.4s	v21, v21, #0x0
    1e58:      	shl.4s	v21, v21, #0x1f
    1e5c:      	cmlt.4s	v21, v21, #0
    1e60:      	and.16b	v5, v21, v5
    1e64:      	tbz	w10, #0x4, 0x1e84 <ltmp0+0x1e84>
    1e68:      	str	s5, [x11, #0x10]
    1e6c:      	tbnz	w10, #0x5, 0x1e88 <ltmp0+0x1e88>
    1e70:      	tbz	w10, #0x6, 0x1e94 <ltmp0+0x1e94>
    1e74:      	add	x13, x11, #0x18
    1e78:      	st1.s	{ v5 }[2], [x13]
    1e7c:      	tbnz	w10, #0x7, 0x1e98 <ltmp0+0x1e98>
    1e80:      	b	0x1ea0 <ltmp0+0x1ea0>
    1e84:      	tbz	w10, #0x5, 0x1e70 <ltmp0+0x1e70>
    1e88:      	add	x13, x11, #0x14
    1e8c:      	st1.s	{ v5 }[1], [x13]
    1e90:      	tbnz	w10, #0x6, 0x1e74 <ltmp0+0x1e74>
    1e94:      	tbz	w10, #0x7, 0x1ea0 <ltmp0+0x1ea0>
    1e98:      	add	x10, x11, #0x1c
    1e9c:      	st1.s	{ v5 }[3], [x10]
    1ea0:      	mov	x10, #0x0               ; =0
    1ea4:      	mov	w11, #0x2004            ; =8196
    1ea8:      	add	x9, x9, x11
    1eac:      	movi.2d	v5, #0000000000000000
    1eb0:      	movi.2d	v21, #0000000000000000
    1eb4:      	movi.2d	v22, #0000000000000000
    1eb8:      	movi.2d	v23, #0000000000000000
    1ebc:      	b	0x1edc <ltmp0+0x1edc>
    1ec0:      	add.2d	v21, v21, v25
    1ec4:      	add.2d	v22, v22, v26
    1ec8:      	add.2d	v23, v23, v24
    1ecc:      	add.2d	v5, v5, v27
    1ed0:      	fmov	x10, d5
    1ed4:      	cmp	x10, #0x100
    1ed8:      	b.ge	0x1fbc <ltmp0+0x1fbc>
    1edc:      	fmov	w11, s7
    1ee0:      	lsl	x10, x10, #5
    1ee4:      	add	x13, x3, x10
    1ee8:      	ldp	q30, q28, [x13]
    1eec:      	add	x13, x6, x10
    1ef0:      	ldp	q11, q29, [x13]
    1ef4:      	fmul.4s	v12, v30, v11
    1ef8:      	add	x13, x4, x10
    1efc:      	ldp	q13, q30, [x13]
    1f00:      	add	x13, x5, x10
    1f04:      	ldp	q14, q11, [x13]
    1f08:      	fmul.4s	v13, v13, v14
    1f0c:      	fadd.4s	v12, v12, v13
    1f10:      	and.16b	v12, v0, v12
    1f14:      	add	x10, x9, x10
    1f18:      	tbz	w11, #0x0, 0x1f68 <ltmp0+0x1f68>
    1f1c:      	str	s12, [x10]
    1f20:      	and	w11, w11, #0xff
    1f24:      	tbnz	w11, #0x1, 0x1f70 <ltmp0+0x1f70>
    1f28:      	tbz	w11, #0x2, 0x1f7c <ltmp0+0x1f7c>
    1f2c:      	add	x13, x10, #0x8
    1f30:      	st1.s	{ v12 }[2], [x13]
    1f34:      	tbnz	w11, #0x3, 0x1f80 <ltmp0+0x1f80>
    1f38:      	fmul.4s	v28, v28, v29
    1f3c:      	fmul.4s	v29, v30, v11
    1f40:      	fadd.4s	v28, v28, v29
    1f44:      	and.16b	v28, v6, v28
    1f48:      	tbz	w11, #0x4, 0x1f9c <ltmp0+0x1f9c>
    1f4c:      	str	s28, [x10, #0x10]
    1f50:      	tbnz	w11, #0x5, 0x1fa0 <ltmp0+0x1fa0>
    1f54:      	tbz	w11, #0x6, 0x1fac <ltmp0+0x1fac>
    1f58:      	add	x13, x10, #0x18
    1f5c:      	st1.s	{ v28 }[2], [x13]
    1f60:      	tbz	w11, #0x7, 0x1ec0 <ltmp0+0x1ec0>
    1f64:      	b	0x1fb0 <ltmp0+0x1fb0>
    1f68:      	and	w11, w11, #0xff
    1f6c:      	tbz	w11, #0x1, 0x1f28 <ltmp0+0x1f28>
    1f70:      	add	x13, x10, #0x4
    1f74:      	st1.s	{ v12 }[1], [x13]
    1f78:      	tbnz	w11, #0x2, 0x1f2c <ltmp0+0x1f2c>
    1f7c:      	tbz	w11, #0x3, 0x1f38 <ltmp0+0x1f38>
    1f80:      	add	x13, x10, #0xc
    1f84:      	st1.s	{ v12 }[3], [x13]
    1f88:      	fmul.4s	v28, v28, v29
    1f8c:      	fmul.4s	v29, v30, v11
    1f90:      	fadd.4s	v28, v28, v29
    1f94:      	and.16b	v28, v6, v28
    1f98:      	tbnz	w11, #0x4, 0x1f4c <ltmp0+0x1f4c>
    1f9c:      	tbz	w11, #0x5, 0x1f54 <ltmp0+0x1f54>
    1fa0:      	add	x13, x10, #0x14
    1fa4:      	st1.s	{ v28 }[1], [x13]
    1fa8:      	tbnz	w11, #0x6, 0x1f58 <ltmp0+0x1f58>
    1fac:      	tbz	w11, #0x7, 0x1ec0 <ltmp0+0x1ec0>
    1fb0:      	add	x10, x10, #0x1c
    1fb4:      	st1.s	{ v28 }[3], [x10]
    1fb8:      	b	0x1ec0 <ltmp0+0x1ec0>
    1fbc:      	ldr	q0, [sp, #0x100]
    1fc0:      	fmul.4s	v0, v0, v4
    1fc4:      	fmul.4s	v2, v10, v2
    1fc8:      	fadd.4s	v0, v2, v0
    1fcc:      	zip1.8b	v2, v19, v0
    1fd0:      	ushll.4s	v2, v2, #0x0
    1fd4:      	shl.4s	v2, v2, #0x1f
    1fd8:      	cmlt.4s	v2, v2, #0
    1fdc:      	and.16b	v0, v2, v0
    1fe0:      	fmov	w9, s31
    1fe4:      	stp	q20, q16, [sp, #0x270]
    1fe8:      	ldr	q2, [sp, #0x10]
    1fec:      	stp	q15, q2, [sp, #0x290]
    1ff0:      	and	x10, x12, #0x7
    1ff4:      	add	x11, sp, #0x270
    1ff8:      	ldr	x10, [x11, x10, lsl #3]
    1ffc:      	sub	x10, x10, x12
    2000:      	add	x8, x8, x10, lsl #2
    2004:      	tbz	w9, #0x0, 0x2024 <ltmp0+0x2024>
    2008:      	str	s0, [x8]
    200c:      	tbnz	w9, #0x1, 0x2028 <ltmp0+0x2028>
    2010:      	tbz	w9, #0x2, 0x2034 <ltmp0+0x2034>
    2014:      	add	x10, x8, #0x8
    2018:      	st1.s	{ v0 }[2], [x10]
    201c:      	tbnz	w9, #0x3, 0x2038 <ltmp0+0x2038>
    2020:      	b	0x2040 <ltmp0+0x2040>
    2024:      	tbz	w9, #0x1, 0x2010 <ltmp0+0x2010>
    2028:      	add	x10, x8, #0x4
    202c:      	st1.s	{ v0 }[1], [x10]
    2030:      	tbnz	w9, #0x2, 0x2014 <ltmp0+0x2014>
    2034:      	tbz	w9, #0x3, 0x2040 <ltmp0+0x2040>
    2038:      	add	x10, x8, #0xc
    203c:      	st1.s	{ v0 }[3], [x10]
    2040:      	fmul.4s	v0, v17, v3
    2044:      	fmul.4s	v1, v9, v1
    2048:      	fadd.4s	v0, v1, v0
    204c:      	zip2.8b	v1, v19, v0
    2050:      	ushll.4s	v1, v1, #0x0
    2054:      	shl.4s	v1, v1, #0x1f
    2058:      	cmlt.4s	v1, v1, #0
    205c:      	and.16b	v0, v1, v0
    2060:      	tbnz	w9, #0x4, 0x12d0 <ltmp0+0x12d0>
    2064:      	tbz	w9, #0x5, 0x12d8 <ltmp0+0x12d8>
    2068:      	add	x10, x8, #0x14
    206c:      	st1.s	{ v0 }[1], [x10]
    2070:      	tbnz	w9, #0x6, 0x12dc <ltmp0+0x12dc>
    2074:      	tbz	w9, #0x7, 0xb4 <ltmp0+0xb4>
    2078:      	add	x8, x8, #0x1c
    207c:      	st1.s	{ v0 }[3], [x8]
    2080:      	b	0xb4 <ltmp0+0xb4>
    2084:      	ldr	x9, [sp, #0x8]
    2088:      	stp	w15, w14, [x9]
    208c:      	str	w13, [x9, #0x8]
    2090:      	mov	w8, #0x18               ; =24
    2094:      	str	w8, [x9, #0x24]
    2098:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    209c:      	add	sp, sp, #0x4c0
    20a0:      	ldp	x29, x30, [sp, #0x90]
    20a4:      	ldp	x20, x19, [sp, #0x80]
    20a8:      	ldp	x22, x21, [sp, #0x70]
    20ac:      	ldp	x24, x23, [sp, #0x60]
    20b0:      	ldp	x26, x25, [sp, #0x50]
    20b4:      	ldp	x28, x27, [sp, #0x40]
    20b8:      	ldp	d9, d8, [sp, #0x30]
    20bc:      	ldp	d11, d10, [sp, #0x20]
    20c0:      	ldp	d13, d12, [sp, #0x10]
    20c4:      	ldp	d15, d14, [sp], #0xa0
    20c8:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/capture/rmsnorm-257x1538/on/object/tile_xir_w8_36292_1788935092639104_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      2c:      	sub	sp, sp, #0x400
      30:      	str	x0, [sp, #0x30]
      34:      	str	w3, [sp, #0x48]
      38:      	cbz	w3, 0x1254 <ltmp0+0x1254>
      3c:      	mov	w12, #0x0               ; =0
      40:      	ldp	w9, w8, [x2, #0x2c]
      44:      	stp	w8, w9, [sp, #0x40]
      48:      	add	x26, sp, #0x1, lsl #12  ; =0x1000
      4c:      	add	x26, x26, #0xbe0
      50:      	add	x24, sp, #0x3c0
      54:      	ldp	w8, w9, [x2]
      58:      	ldp	w10, w11, [x2, #0x8]
      5c:      	str	x2, [sp, #0x8]
      60:      	str	x11, [sp, #0x38]
      64:      	movi	d8, #0000000000000000
      68:      	b	0xb4 <ltmp0+0xb4>
      6c:      	ldr	x15, [sp, #0x58]
      70:      	add	w8, w15, #0x1
      74:      	ldp	w11, w9, [sp, #0x40]
      78:      	cmp	w8, w9
      7c:      	cset	w9, eq
      80:      	csinc	w8, wzr, w15, eq
      84:      	ldp	w14, w13, [sp, #0x4c]
      88:      	cinc	w10, w14, eq
      8c:      	cmp	w10, w11
      90:      	cset	w11, eq
      94:      	ands	w11, w9, w11
      98:      	csel	w9, wzr, w10, ne
      9c:      	add	w10, w13, w11
      a0:      	ldr	w12, [sp, #0x54]
      a4:      	add	w12, w12, #0x1
      a8:      	ldr	w11, [sp, #0x48]
      ac:      	cmp	w12, w11
      b0:      	b.eq	0x1240 <ltmp0+0x1240>
      b4:      	stp	w10, w12, [sp, #0x50]
      b8:      	mov	x14, x9
      bc:      	mov	x15, x8
      c0:      	ubfiz	x8, x8, #5, #32
      c4:      	ldr	x13, [sp, #0x38]
      c8:      	cmp	x8, x13
      cc:      	csel	x9, x8, xzr, ls
      d0:      	subs	x10, x13, x9
      d4:      	cmp	x10, #0x20
      d8:      	mov	w11, #0x20              ; =32
      dc:      	csel	x10, x10, x11, lo
      e0:      	cmp	x13, x9
      e4:      	ccmp	x8, x13, #0x2, hi
      e8:      	csel	x9, x10, xzr, ls
      ec:      	cmp	x9, #0x20
      f0:      	str	w14, [sp, #0x4c]
      f4:      	str	x15, [sp, #0x58]
      f8:      	b.lo	0x36c <ltmp0+0x36c>
      fc:      	mov	x20, #0x0               ; =0
     100:      	ldr	x8, [sp, #0x30]
     104:      	ldr	x21, [x8]
     108:      	ldr	x22, [x8, #0x10]
     10c:      	ldr	x23, [x8, #0x30]
     110:      	mov	w8, #0x1800             ; =6144
     114:      	add	x8, x22, x8
     118:      	str	x8, [sp, #0x70]
     11c:      	lsl	w8, w15, #2
     120:      	str	x8, [sp, #0x60]
     124:      	and	x8, x15, #0x7ffffff
     128:      	mov	w9, #0x6020             ; =24608
     12c:      	umaddl	x27, w8, w9, x23
     130:      	mov	w8, #0x1804             ; =6148
     134:      	add	x28, x22, x8
     138:      	mov	w9, #0x1808             ; =6152
     13c:      	str	q2, [sp, #0x120]
     140:      	ldr	x8, [sp, #0x60]
     144:      	add	w8, w20, w8
     148:      	and	x19, x8, #0x1fffffff
     14c:      	umaddl	x1, w19, w9, x21
     150:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     154:      	add	x0, x0, #0xbe0
     158:      	mov	w2, #0x1800             ; =6144
     15c:      	mov	w25, #0x1808            ; =6152
     160:      	bl	0x160 <ltmp0+0x160>
     164:      	mov	x8, #0x0                ; =0
     168:      	mov	w9, #0x1800             ; =6144
     16c:      	umaddl	x19, w19, w25, x9
     170:      	add	x9, x21, x19
     174:      	ldr	s0, [x9], #0x4
     178:      	ld1.s	{ v0 }[1], [x9]
     17c:      	str	q0, [sp, #0x100]
     180:      	ldr	q1, [sp, #0x120]
     184:      	mov.d	v0[1], v1[1]
     188:      	str	q0, [sp, #0x33f0]
     18c:      	str	q0, [sp, #0x120]
     190:      	str	q0, [sp, #0x33e0]
     194:      	ldr	q0, [sp, #0x1be0]
     198:      	ldr	q1, [sp, #0x1bf0]
     19c:      	fmul.4s	v2, v1, v1
     1a0:      	fmul.4s	v3, v0, v0
     1a4:      	ldr	q0, [sp, #0x1c00]
     1a8:      	ldr	q1, [sp, #0x1c10]
     1ac:      	fmul.4s	v5, v1, v1
     1b0:      	fmul.4s	v4, v0, v0
     1b4:      	ldr	q0, [sp, #0x1c20]
     1b8:      	ldr	q1, [sp, #0x1c30]
     1bc:      	fmul.4s	v6, v1, v1
     1c0:      	fmul.4s	v7, v0, v0
     1c4:      	ldr	q0, [sp, #0x1c40]
     1c8:      	ldr	q1, [sp, #0x1c50]
     1cc:      	fmul.4s	v17, v1, v1
     1d0:      	fmul.4s	v16, v0, v0
     1d4:      	add	x9, x26, x8, lsl #5
     1d8:      	ldp	q1, q0, [x9, #0x80]
     1dc:      	fmul.4s	v1, v1, v1
     1e0:      	fmul.4s	v0, v0, v0
     1e4:      	fadd.4s	v2, v2, v0
     1e8:      	fadd.4s	v3, v3, v1
     1ec:      	ldp	q1, q0, [x9, #0xa0]
     1f0:      	fmul.4s	v1, v1, v1
     1f4:      	fmul.4s	v0, v0, v0
     1f8:      	fadd.4s	v5, v5, v0
     1fc:      	fadd.4s	v4, v4, v1
     200:      	ldp	q1, q0, [x9, #0xc0]
     204:      	fmul.4s	v1, v1, v1
     208:      	fmul.4s	v0, v0, v0
     20c:      	fadd.4s	v6, v6, v0
     210:      	fadd.4s	v7, v7, v1
     214:      	ldp	q1, q0, [x9, #0xe0]
     218:      	fmul.4s	v1, v1, v1
     21c:      	fmul.4s	v0, v0, v0
     220:      	fadd.4s	v17, v17, v0
     224:      	fadd.4s	v16, v16, v1
     228:      	add	x8, x8, #0x4
     22c:      	cmp	x8, #0xbc
     230:      	b.lo	0x1d4 <ltmp0+0x1d4>
     234:      	add	x0, sp, #0x3c0
     238:      	mov	x1, x22
     23c:      	mov	w2, #0x1800             ; =6144
     240:      	stp	q5, q2, [sp, #0x90]
     244:      	str	q3, [sp, #0x80]
     248:      	stp	q7, q4, [sp, #0xb0]
     24c:      	stp	q6, q16, [sp, #0xe0]
     250:      	str	q17, [sp, #0xd0]
     254:      	bl	0x254 <ltmp0+0x254>
     258:      	mov	x8, #0x0                ; =0
     25c:      	ldr	q0, [sp, #0x100]
     260:      	fmul.4s	v0, v0, v0
     264:      	ldp	q1, q2, [sp, #0x80]
     268:      	fadd.4s	v0, v0, v1
     26c:      	mov.d	v0[1], v1[1]
     270:      	ldr	q1, [sp, #0xa0]
     274:      	fadd.4s	v1, v2, v1
     278:      	ldp	q2, q3, [sp, #0xb0]
     27c:      	fadd.4s	v0, v3, v0
     280:      	fadd.4s	v0, v2, v0
     284:      	ldp	q2, q3, [sp, #0xd0]
     288:      	fadd.4s	v1, v3, v1
     28c:      	fadd.4s	v1, v2, v1
     290:      	ldr	q2, [sp, #0xf0]
     294:      	fadd.4s	v0, v2, v0
     298:      	rev64.4s	v2, v0
     29c:      	rev64.4s	v3, v1
     2a0:      	fadd.4s	v1, v1, v3
     2a4:      	fadd.4s	v0, v0, v2
     2a8:      	dup.4s	v2, v0[2]
     2ac:      	dup.4s	v3, v1[2]
     2b0:      	fadd.4s	v1, v1, v3
     2b4:      	fadd.4s	v0, v0, v2
     2b8:      	fadd.4s	v0, v0, v1
     2bc:      	fadd	s0, s0, s8
     2c0:      	mov	w9, #0x4000             ; =16384
     2c4:      	movk	w9, #0x44c0, lsl #16
     2c8:      	fmov	s1, w9
     2cc:      	fdiv	s1, s0, s1
     2d0:      	ldr	x9, [sp, #0x70]
     2d4:      	ldr	s0, [x9]
     2d8:      	ld1.s	{ v0 }[1], [x28]
     2dc:      	ldr	q2, [sp, #0x110]
     2e0:      	mov.d	v0[1], v2[1]
     2e4:      	str	q0, [sp, #0x1bd0]
     2e8:      	str	q0, [sp, #0x1bc0]
     2ec:      	mov	w9, #0xc5ac             ; =50604
     2f0:      	movk	w9, #0x3727, lsl #16
     2f4:      	fmov	s2, w9
     2f8:      	fadd	s1, s1, s2
     2fc:      	fsqrt	s1, s1
     300:      	dup.4s	v2, v1[0]
     304:      	lsl	x9, x8, #5
     308:      	add	x10, x26, x9
     30c:      	ldp	q3, q4, [x10]
     310:      	fdiv.4s	v4, v4, v2
     314:      	fdiv.4s	v3, v3, v2
     318:      	add	x10, x24, x9
     31c:      	ldp	q6, q5, [x10]
     320:      	fmul.4s	v3, v3, v6
     324:      	fmul.4s	v4, v4, v5
     328:      	add	x9, x27, x9
     32c:      	stp	q3, q4, [x9]
     330:      	add	x8, x8, #0x1
     334:      	cmp	x8, #0xc0
     338:      	b.ne	0x304 <ltmp0+0x304>
     33c:      	dup.2s	v1, v1[0]
     340:      	ldr	q2, [sp, #0x120]
     344:      	fdiv.2s	v1, v2, v1
     348:      	fmul.2s	v1, v1, v0
     34c:      	str	d1, [x23, x19]
     350:      	add	x20, x20, #0x1
     354:      	mov	w9, #0x1808             ; =6152
     358:      	add	x27, x27, x9
     35c:      	str	q0, [sp, #0x110]
     360:      	cmp	x20, #0x4
     364:      	b.ne	0x13c <ltmp0+0x13c>
     368:      	b	0x6c <ltmp0+0x6c>
     36c:      	lsr	x8, x9, #3
     370:      	str	x8, [sp, #0x90]
     374:      	str	x9, [sp, #0x70]
     378:      	cmp	x9, #0x8
     37c:      	b.lo	0x5c4 <ltmp0+0x5c4>
     380:      	mov	x23, #0x0               ; =0
     384:      	ldr	x8, [sp, #0x30]
     388:      	ldr	x27, [x8]
     38c:      	ldr	x22, [x8, #0x10]
     390:      	ldr	x20, [x8, #0x30]
     394:      	mov	w8, #0x1800             ; =6144
     398:      	add	x8, x22, x8
     39c:      	str	x8, [sp, #0x80]
     3a0:      	ldr	x8, [sp, #0x58]
     3a4:      	lsl	w21, w8, #2
     3a8:      	and	x8, x8, #0x7ffffff
     3ac:      	mov	w9, #0x6020             ; =24608
     3b0:      	umaddl	x19, w8, w9, x20
     3b4:      	mov	w9, #0x1808             ; =6152
     3b8:      	add	w8, w23, w21
     3bc:      	and	x28, x8, #0x1fffffff
     3c0:      	umaddl	x1, w28, w9, x27
     3c4:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     3c8:      	add	x0, x0, #0xbe0
     3cc:      	mov	w2, #0x1800             ; =6144
     3d0:      	mov	w25, #0x1808            ; =6152
     3d4:      	bl	0x3d4 <ltmp0+0x3d4>
     3d8:      	mov	x8, #0x0                ; =0
     3dc:      	mov	w9, #0x1800             ; =6144
     3e0:      	umaddl	x28, w28, w25, x9
     3e4:      	add	x9, x27, x28
     3e8:      	ldr	s0, [x9], #0x4
     3ec:      	ld1.s	{ v0 }[1], [x9]
     3f0:      	str	q0, [sp, #0x120]
     3f4:      	str	q0, [sp, #0x33e0]
     3f8:      	ldr	q0, [sp, #0x1be0]
     3fc:      	ldr	q1, [sp, #0x1bf0]
     400:      	fmul.4s	v2, v1, v1
     404:      	fmul.4s	v17, v0, v0
     408:      	ldr	q0, [sp, #0x1c00]
     40c:      	ldr	q1, [sp, #0x1c10]
     410:      	fmul.4s	v4, v1, v1
     414:      	fmul.4s	v3, v0, v0
     418:      	ldr	q0, [sp, #0x1c20]
     41c:      	ldr	q1, [sp, #0x1c30]
     420:      	fmul.4s	v5, v1, v1
     424:      	fmul.4s	v6, v0, v0
     428:      	ldr	q0, [sp, #0x1c40]
     42c:      	ldr	q1, [sp, #0x1c50]
     430:      	fmul.4s	v16, v1, v1
     434:      	fmul.4s	v7, v0, v0
     438:      	add	x9, x26, x8, lsl #5
     43c:      	ldp	q1, q0, [x9, #0x80]
     440:      	fmul.4s	v1, v1, v1
     444:      	fmul.4s	v0, v0, v0
     448:      	fadd.4s	v2, v2, v0
     44c:      	fadd.4s	v17, v17, v1
     450:      	ldp	q1, q0, [x9, #0xa0]
     454:      	fmul.4s	v1, v1, v1
     458:      	fmul.4s	v0, v0, v0
     45c:      	fadd.4s	v4, v4, v0
     460:      	fadd.4s	v3, v3, v1
     464:      	ldp	q1, q0, [x9, #0xc0]
     468:      	fmul.4s	v1, v1, v1
     46c:      	fmul.4s	v0, v0, v0
     470:      	fadd.4s	v5, v5, v0
     474:      	fadd.4s	v6, v6, v1
     478:      	ldp	q1, q0, [x9, #0xe0]
     47c:      	fmul.4s	v1, v1, v1
     480:      	fmul.4s	v0, v0, v0
     484:      	fadd.4s	v16, v16, v0
     488:      	fadd.4s	v7, v7, v1
     48c:      	add	x8, x8, #0x4
     490:      	cmp	x8, #0xbc
     494:      	b.lo	0x438 <ltmp0+0x438>
     498:      	add	x0, sp, #0x3c0
     49c:      	mov	x1, x22
     4a0:      	mov	w2, #0x1800             ; =6144
     4a4:      	stp	q4, q2, [sp, #0xb0]
     4a8:      	stp	q6, q3, [sp, #0xd0]
     4ac:      	stp	q5, q7, [sp, #0x100]
     4b0:      	str	q16, [sp, #0xf0]
     4b4:      	str	q17, [sp, #0xa0]
     4b8:      	bl	0x4b8 <ltmp0+0x4b8>
     4bc:      	mov	x8, #0x0                ; =0
     4c0:      	ldr	q7, [sp, #0x120]
     4c4:      	fmul.4s	v0, v7, v7
     4c8:      	ldp	q2, q3, [sp, #0xa0]
     4cc:      	fadd.4s	v1, v0, v2
     4d0:      	mov.d	v1[1], v2[1]
     4d4:      	mov	w9, #0x1804             ; =6148
     4d8:      	add	x9, x22, x9
     4dc:      	ldr	x10, [sp, #0x80]
     4e0:      	ldr	s0, [x10]
     4e4:      	ld1.s	{ v0 }[1], [x9]
     4e8:      	ldr	q2, [sp, #0xc0]
     4ec:      	fadd.4s	v2, v3, v2
     4f0:      	ldp	q3, q4, [sp, #0xd0]
     4f4:      	fadd.4s	v1, v4, v1
     4f8:      	fadd.4s	v1, v3, v1
     4fc:      	ldp	q3, q4, [sp, #0xf0]
     500:      	fadd.4s	v2, v4, v2
     504:      	fadd.4s	v2, v3, v2
     508:      	ldr	q3, [sp, #0x110]
     50c:      	fadd.4s	v1, v3, v1
     510:      	rev64.4s	v3, v1
     514:      	rev64.4s	v4, v2
     518:      	fadd.4s	v2, v2, v4
     51c:      	fadd.4s	v1, v1, v3
     520:      	dup.4s	v3, v1[2]
     524:      	dup.4s	v4, v2[2]
     528:      	fadd.4s	v2, v2, v4
     52c:      	fadd.4s	v1, v1, v3
     530:      	fadd.4s	v1, v1, v2
     534:      	fadd	s1, s1, s8
     538:      	mov	w9, #0x4000             ; =16384
     53c:      	movk	w9, #0x44c0, lsl #16
     540:      	fmov	s2, w9
     544:      	fdiv	s1, s1, s2
     548:      	str	q0, [sp, #0x1bc0]
     54c:      	mov	w9, #0xc5ac             ; =50604
     550:      	movk	w9, #0x3727, lsl #16
     554:      	fmov	s2, w9
     558:      	fadd	s1, s1, s2
     55c:      	fsqrt	s1, s1
     560:      	dup.4s	v2, v1[0]
     564:      	lsl	x9, x8, #5
     568:      	add	x10, x26, x9
     56c:      	ldp	q3, q4, [x10]
     570:      	fdiv.4s	v4, v4, v2
     574:      	fdiv.4s	v3, v3, v2
     578:      	add	x10, x24, x9
     57c:      	ldp	q6, q5, [x10]
     580:      	fmul.4s	v3, v3, v6
     584:      	fmul.4s	v4, v4, v5
     588:      	add	x9, x19, x9
     58c:      	stp	q3, q4, [x9]
     590:      	add	x8, x8, #0x1
     594:      	cmp	x8, #0xc0
     598:      	b.ne	0x564 <ltmp0+0x564>
     59c:      	dup.2s	v1, v1[0]
     5a0:      	fdiv.2s	v1, v7, v1
     5a4:      	fmul.2s	v0, v1, v0
     5a8:      	str	d0, [x20, x28]
     5ac:      	add	x23, x23, #0x1
     5b0:      	mov	w9, #0x1808             ; =6152
     5b4:      	add	x19, x19, x9
     5b8:      	ldr	x8, [sp, #0x90]
     5bc:      	cmp	x23, x8
     5c0:      	b.ne	0x3b8 <ltmp0+0x3b8>
     5c4:      	ldr	x8, [sp, #0x70]
     5c8:      	and	w8, w8, #0x7
     5cc:      	cbz	w8, 0x6c <ltmp0+0x6c>
     5d0:      	mov	w14, #0x1808            ; =6152
     5d4:      	dup.4s	v1, w8
     5d8:      	adrp	x8, 0x0 <ltmp0>
     5dc:      	ldr	q2, [x8]
     5e0:      	adrp	x8, 0x0 <ltmp0>
     5e4:      	ldr	q0, [x8]
     5e8:      	cmhi.4s	v0, v1, v0
     5ec:      	cmhi.4s	v1, v1, v2
     5f0:      	uzp1.8h	v3, v1, v0
     5f4:      	umaxv.8h	h2, v3
     5f8:      	fmov	w8, s2
     5fc:      	tbz	w8, #0x0, 0x6c <ltmp0+0x6c>
     600:      	mov	x9, #0x0                ; =0
     604:      	ldr	x8, [sp, #0x30]
     608:      	ldr	x12, [x8]
     60c:      	ldr	x10, [x8, #0x10]
     610:      	ldr	x8, [x8, #0x30]
     614:      	adrp	x11, 0x0 <ltmp0>
     618:      	ldr	q2, [x11]
     61c:      	and.16b	v2, v3, v2
     620:      	addv.8h	h2, v2
     624:      	ldr	x11, [sp, #0x58]
     628:      	ubfiz	w11, w11, #2, #27
     62c:      	ldr	x13, [sp, #0x90]
     630:      	orr	w13, w11, w13
     634:      	fmov	w11, s2
     638:      	and	w11, w11, #0xff
     63c:      	dup.4s	v4, w13
     640:      	and.16b	v5, v1, v4
     644:      	and.16b	v4, v0, v4
     648:      	ushll2.2d	v7, v4, #0x0
     64c:      	ushll2.2d	v16, v5, #0x0
     650:      	ushll.2d	v17, v4, #0x0
     654:      	ushll.2d	v4, v5, #0x0
     658:      	fmov	x13, d4
     65c:      	umaddl	x13, w13, w14, x12
     660:      	b	0x684 <ltmp0+0x684>
     664:      	add	x14, x26, x9, lsl #5
     668:      	ldp	q18, q19, [x14]
     66c:      	bif.16b	v6, v19, v0
     670:      	bif.16b	v5, v18, v1
     674:      	stp	q5, q6, [x14]
     678:      	add	x9, x9, #0x1
     67c:      	cmp	x9, #0xc0
     680:      	b.eq	0x71c <ltmp0+0x71c>
     684:      	fmov	w15, s2
     688:      	add	x14, x13, x9, lsl #5
     68c:      	movi.2d	v5, #0000000000000000
     690:      	movi.2d	v6, #0000000000000000
     694:      	tbnz	w15, #0x0, 0x6bc <ltmp0+0x6bc>
     698:      	and	w15, w15, #0xff
     69c:      	tbnz	w15, #0x1, 0x6c8 <ltmp0+0x6c8>
     6a0:      	tbnz	w15, #0x2, 0x6d4 <ltmp0+0x6d4>
     6a4:      	tbnz	w15, #0x3, 0x6e0 <ltmp0+0x6e0>
     6a8:      	tbnz	w15, #0x4, 0x6ec <ltmp0+0x6ec>
     6ac:      	tbnz	w15, #0x5, 0x6f8 <ltmp0+0x6f8>
     6b0:      	tbnz	w15, #0x6, 0x704 <ltmp0+0x704>
     6b4:      	tbz	w15, #0x7, 0x664 <ltmp0+0x664>
     6b8:      	b	0x710 <ltmp0+0x710>
     6bc:      	ldr	s5, [x14]
     6c0:      	and	w15, w15, #0xff
     6c4:      	tbz	w15, #0x1, 0x6a0 <ltmp0+0x6a0>
     6c8:      	add	x16, x14, #0x4
     6cc:      	ld1.s	{ v5 }[1], [x16]
     6d0:      	tbz	w15, #0x2, 0x6a4 <ltmp0+0x6a4>
     6d4:      	add	x16, x14, #0x8
     6d8:      	ld1.s	{ v5 }[2], [x16]
     6dc:      	tbz	w15, #0x3, 0x6a8 <ltmp0+0x6a8>
     6e0:      	add	x16, x14, #0xc
     6e4:      	ld1.s	{ v5 }[3], [x16]
     6e8:      	tbz	w15, #0x4, 0x6ac <ltmp0+0x6ac>
     6ec:      	add	x16, x14, #0x10
     6f0:      	ld1.s	{ v6 }[0], [x16]
     6f4:      	tbz	w15, #0x5, 0x6b0 <ltmp0+0x6b0>
     6f8:      	add	x16, x14, #0x14
     6fc:      	ld1.s	{ v6 }[1], [x16]
     700:      	tbz	w15, #0x6, 0x6b4 <ltmp0+0x6b4>
     704:      	add	x16, x14, #0x18
     708:      	ld1.s	{ v6 }[2], [x16]
     70c:      	tbz	w15, #0x7, 0x664 <ltmp0+0x664>
     710:      	add	x14, x14, #0x1c
     714:      	ld1.s	{ v6 }[3], [x14]
     718:      	b	0x664 <ltmp0+0x664>
     71c:      	xtn.8b	v24, v3
     720:      	sshll.2d	v18, v1, #0x0
     724:      	adrp	x9, 0x0 <ltmp0>
     728:      	ldr	q3, [x9]
     72c:      	and.16b	v5, v18, v3
     730:      	movi	d3, #0x0000000000ffff
     734:      	and.8b	v6, v24, v3
     738:      	adrp	x9, 0x0 <ltmp0>
     73c:      	ldr	d3, [x9]
     740:      	and.8b	v3, v24, v3
     744:      	addv.8b	b3, v3
     748:      	fmov	w13, s3
     74c:      	umaxv.8b	b3, v6
     750:      	fmov	w9, s3
     754:      	rbit	w14, w13
     758:      	clz	w14, w14
     75c:      	tst	w9, #0x1
     760:      	csel	w9, w14, wzr, ne
     764:      	mov	w14, #0x600             ; =1536
     768:      	dup.2d	v22, x14
     76c:      	str	q5, [sp, #0x70]
     770:      	orr.16b	v3, v5, v22
     774:      	mov	w14, #0x602             ; =1538
     778:      	dup.2s	v19, w14
     77c:      	xtn.2s	v23, v4
     780:      	str	q3, [sp, #0xb0]
     784:      	mov.16b	v4, v3
     788:      	umlal.2d	v4, v23, v19
     78c:      	mov	b3, v6[0]
     790:      	mov.b	v3[4], v6[1]
     794:      	ushll.2d	v3, v3, #0x0
     798:      	shl.2d	v3, v3, #0x3f
     79c:      	cmlt.2d	v3, v3, #0
     7a0:      	str	q4, [sp, #0x110]
     7a4:      	and.16b	v3, v3, v4
     7a8:      	movi.2d	v4, #0000000000000000
     7ac:      	stp	q4, q4, [sp, #0x390]
     7b0:      	stp	q3, q4, [sp, #0x370]
     7b4:      	and	x14, x9, #0x7
     7b8:      	add	x15, sp, #0x370
     7bc:      	ldr	x14, [x15, x14, lsl #3]
     7c0:      	sub	x14, x14, x9
     7c4:      	add	x12, x12, x14, lsl #2
     7c8:      	movi.2d	v5, #0000000000000000
     7cc:      	movi.2d	v3, #0000000000000000
     7d0:      	tbnz	w13, #0x0, 0x1134 <ltmp0+0x1134>
     7d4:      	tbnz	w13, #0x1, 0x113c <ltmp0+0x113c>
     7d8:      	mov	w15, #0x4               ; =4
     7dc:      	tbnz	w13, #0x2, 0x114c <ltmp0+0x114c>
     7e0:      	tbnz	w13, #0x3, 0x1158 <ltmp0+0x1158>
     7e4:      	tbnz	w13, #0x4, 0x1164 <ltmp0+0x1164>
     7e8:      	tbnz	w13, #0x5, 0x1170 <ltmp0+0x1170>
     7ec:      	tbnz	w13, #0x6, 0x117c <ltmp0+0x117c>
     7f0:      	tbz	w13, #0x7, 0x7fc <ltmp0+0x7fc>
     7f4:      	add	x12, x12, #0x1c
     7f8:      	ld1.s	{ v3 }[3], [x12]
     7fc:      	sshll.2d	v4, v0, #0x0
     800:      	sshll2.2d	v20, v1, #0x0
     804:      	sshll2.2d	v21, v0, #0x0
     808:      	adrp	x12, 0x0 <ltmp0>
     80c:      	ldr	q25, [x12]
     810:      	and.16b	v30, v21, v25
     814:      	adrp	x12, 0x0 <ltmp0>
     818:      	ldr	q25, [x12]
     81c:      	and.16b	v29, v20, v25
     820:      	adrp	x12, 0x0 <ltmp0>
     824:      	ldr	q25, [x12]
     828:      	and.16b	v28, v4, v25
     82c:      	adrp	x12, 0x0 <ltmp0>
     830:      	ldr	q25, [x12]
     834:      	and.16b	v25, v21, v25
     838:      	adrp	x12, 0x0 <ltmp0>
     83c:      	ldr	q26, [x12]
     840:      	and.16b	v26, v20, v26
     844:      	adrp	x12, 0x0 <ltmp0>
     848:      	ldr	q27, [x12]
     84c:      	and.16b	v27, v4, v27
     850:      	adrp	x12, 0x0 <ltmp0>
     854:      	ldr	q4, [x12]
     858:      	and.16b	v4, v18, v4
     85c:      	stp	q28, q29, [sp, #0x10]
     860:      	orr.16b	v28, v28, v22
     864:      	orr.16b	v29, v29, v22
     868:      	str	q30, [sp, #0x60]
     86c:      	orr.16b	v22, v30, v22
     870:      	umull.2d	v30, v23, v19
     874:      	xtn.2s	v16, v16
     878:      	xtn.2s	v17, v17
     87c:      	xtn.2s	v7, v7
     880:      	stp	q28, q22, [sp, #0x90]
     884:      	mov.16b	v18, v22
     888:      	umlal.2d	v18, v7, v19
     88c:      	str	q29, [sp, #0x80]
     890:      	mov.16b	v7, v29
     894:      	umlal.2d	v7, v16, v19
     898:      	stp	q7, q18, [sp, #0xe0]
     89c:      	mov.16b	v7, v28
     8a0:      	umlal.2d	v7, v17, v19
     8a4:      	stp	q30, q7, [sp, #0xc0]
     8a8:      	sshll.2d	v7, v1, #0x0
     8ac:      	sshll.2d	v18, v0, #0x0
     8b0:      	stp	q4, q26, [sp, #0x330]
     8b4:      	stp	q27, q25, [sp, #0x350]
     8b8:      	and	x12, x9, #0x7
     8bc:      	add	x14, sp, #0x330
     8c0:      	ldr	x12, [x14, x12, lsl #3]
     8c4:      	orr	x12, x12, #0x1800
     8c8:      	sub	x12, x12, x9, lsl #2
     8cc:      	tst	w13, #0xff
     8d0:      	csel	x12, xzr, x12, eq
     8d4:      	add	x13, x26, x12
     8d8:      	ldp	q16, q17, [x13]
     8dc:      	zip2.8b	v19, v6, v0
     8e0:      	ushll.4s	v19, v19, #0x0
     8e4:      	shl.4s	v19, v19, #0x1f
     8e8:      	cmlt.4s	v19, v19, #0
     8ec:      	str	q3, [sp, #0x120]
     8f0:      	bit.16b	v17, v3, v19
     8f4:      	zip1.8b	v19, v6, v0
     8f8:      	ushll.4s	v19, v19, #0x0
     8fc:      	shl.4s	v19, v19, #0x1f
     900:      	cmlt.4s	v19, v19, #0
     904:      	str	q5, [sp, #0x100]
     908:      	bit.16b	v16, v5, v19
     90c:      	stp	q16, q17, [x13]
     910:      	dup.2d	v19, x15
     914:      	and.16b	v16, v21, v19
     918:      	and.16b	v17, v20, v19
     91c:      	and.16b	v22, v18, v19
     920:      	and.16b	v23, v7, v19
     924:      	fmov	x13, d23
     928:      	ldr	q7, [sp, #0x1c50]
     92c:      	ldr	q18, [sp, #0x1c40]
     930:      	fmul.4s	v18, v18, v18
     934:      	fmul.4s	v7, v7, v7
     938:      	and.16b	v11, v0, v7
     93c:      	and.16b	v12, v1, v18
     940:      	ldr	q7, [sp, #0x1c30]
     944:      	ldr	q18, [sp, #0x1c20]
     948:      	fmul.4s	v18, v18, v18
     94c:      	fmul.4s	v7, v7, v7
     950:      	and.16b	v14, v0, v7
     954:      	and.16b	v13, v1, v18
     958:      	ldr	q7, [sp, #0x1c10]
     95c:      	ldr	q18, [sp, #0x1c00]
     960:      	fmul.4s	v18, v18, v18
     964:      	fmul.4s	v7, v7, v7
     968:      	and.16b	v15, v0, v7
     96c:      	and.16b	v9, v1, v18
     970:      	fmov	x14, d4
     974:      	add	x14, x26, x14
     978:      	ldp	q7, q4, [x14]
     97c:      	fmul.4s	v7, v7, v7
     980:      	fmul.4s	v4, v4, v4
     984:      	and.16b	v18, v0, v4
     988:      	and.16b	v10, v1, v7
     98c:      	sshll.2d	v4, v1, #0x0
     990:      	sshll.2d	v25, v0, #0x0
     994:      	add	x13, x26, x13, lsl #5
     998:      	ldp	q19, q7, [x13]
     99c:      	and.16b	v19, v1, v19
     9a0:      	and.16b	v7, v0, v7
     9a4:      	fmul.4s	v7, v7, v7
     9a8:      	fmul.4s	v19, v19, v19
     9ac:      	fadd.4s	v19, v10, v19
     9b0:      	fadd.4s	v7, v18, v7
     9b4:      	ldp	q27, q26, [x13, #0x20]
     9b8:      	and.16b	v27, v1, v27
     9bc:      	and.16b	v26, v0, v26
     9c0:      	fmul.4s	v26, v26, v26
     9c4:      	fmul.4s	v27, v27, v27
     9c8:      	fadd.4s	v27, v9, v27
     9cc:      	fadd.4s	v26, v15, v26
     9d0:      	ldp	q5, q28, [x13, #0x40]
     9d4:      	and.16b	v5, v1, v5
     9d8:      	and.16b	v28, v0, v28
     9dc:      	fmul.4s	v28, v28, v28
     9e0:      	fmul.4s	v5, v5, v5
     9e4:      	fadd.4s	v5, v13, v5
     9e8:      	fadd.4s	v28, v14, v28
     9ec:      	ldp	q30, q29, [x13, #0x60]
     9f0:      	and.16b	v30, v1, v30
     9f4:      	and.16b	v29, v0, v29
     9f8:      	fmul.4s	v29, v29, v29
     9fc:      	fmul.4s	v30, v30, v30
     a00:      	fadd.4s	v30, v12, v30
     a04:      	fadd.4s	v29, v11, v29
     a08:      	dup.2d	v31, x15
     a0c:      	and.16b	v3, v21, v31
     a10:      	add.2d	v16, v16, v3
     a14:      	and.16b	v3, v20, v31
     a18:      	add.2d	v17, v17, v3
     a1c:      	and.16b	v3, v25, v31
     a20:      	add.2d	v22, v22, v3
     a24:      	and.16b	v3, v4, v31
     a28:      	add.2d	v23, v23, v3
     a2c:      	bit.16b	v18, v7, v0
     a30:      	bit.16b	v10, v19, v1
     a34:      	bit.16b	v15, v26, v0
     a38:      	bit.16b	v9, v27, v1
     a3c:      	bit.16b	v14, v28, v0
     a40:      	bit.16b	v13, v5, v1
     a44:      	bit.16b	v11, v29, v0
     a48:      	bit.16b	v12, v30, v1
     a4c:      	fmov	x13, d23
     a50:      	cmp	x13, #0xc0
     a54:      	b.lt	0x98c <ltmp0+0x98c>
     a58:      	mov	x13, #0x0               ; =0
     a5c:      	mov	w14, #0x1               ; =1
     a60:      	dup.2d	v3, x14
     a64:      	ushll2.2d	v4, v0, #0x0
     a68:      	and.16b	v20, v4, v3
     a6c:      	ushll2.2d	v4, v1, #0x0
     a70:      	and.16b	v21, v4, v3
     a74:      	ushll.2d	v4, v0, #0x0
     a78:      	and.16b	v22, v4, v3
     a7c:      	ushll.2d	v4, v1, #0x0
     a80:      	and.16b	v23, v4, v3
     a84:      	movi.2d	v16, #0000000000000000
     a88:      	movi.2d	v17, #0000000000000000
     a8c:      	movi.2d	v25, #0000000000000000
     a90:      	movi.2d	v26, #0000000000000000
     a94:      	ldr	q29, [sp, #0x120]
     a98:      	ldr	q30, [sp, #0x100]
     a9c:      	b	0xad0 <ltmp0+0xad0>
     aa0:      	add	x13, x24, x13
     aa4:      	ldp	q3, q5, [x13]
     aa8:      	bif.16b	v4, v5, v0
     aac:      	bit.16b	v3, v27, v1
     ab0:      	stp	q3, q4, [x13]
     ab4:      	add.2d	v17, v17, v21
     ab8:      	add.2d	v25, v25, v22
     abc:      	add.2d	v26, v26, v20
     ac0:      	add.2d	v16, v16, v23
     ac4:      	fmov	x13, d16
     ac8:      	cmp	x13, #0xc0
     acc:      	b.ge	0xb6c <ltmp0+0xb6c>
     ad0:      	fmov	w15, s2
     ad4:      	lsl	x13, x13, #5
     ad8:      	add	x14, x10, x13
     adc:      	movi.2d	v27, #0000000000000000
     ae0:      	movi.2d	v4, #0000000000000000
     ae4:      	tbnz	w15, #0x0, 0xb0c <ltmp0+0xb0c>
     ae8:      	and	w15, w15, #0xff
     aec:      	tbnz	w15, #0x1, 0xb18 <ltmp0+0xb18>
     af0:      	tbnz	w15, #0x2, 0xb24 <ltmp0+0xb24>
     af4:      	tbnz	w15, #0x3, 0xb30 <ltmp0+0xb30>
     af8:      	tbnz	w15, #0x4, 0xb3c <ltmp0+0xb3c>
     afc:      	tbnz	w15, #0x5, 0xb48 <ltmp0+0xb48>
     b00:      	tbnz	w15, #0x6, 0xb54 <ltmp0+0xb54>
     b04:      	tbz	w15, #0x7, 0xaa0 <ltmp0+0xaa0>
     b08:      	b	0xb60 <ltmp0+0xb60>
     b0c:      	ldr	s27, [x14]
     b10:      	and	w15, w15, #0xff
     b14:      	tbz	w15, #0x1, 0xaf0 <ltmp0+0xaf0>
     b18:      	add	x16, x14, #0x4
     b1c:      	ld1.s	{ v27 }[1], [x16]
     b20:      	tbz	w15, #0x2, 0xaf4 <ltmp0+0xaf4>
     b24:      	add	x16, x14, #0x8
     b28:      	ld1.s	{ v27 }[2], [x16]
     b2c:      	tbz	w15, #0x3, 0xaf8 <ltmp0+0xaf8>
     b30:      	add	x16, x14, #0xc
     b34:      	ld1.s	{ v27 }[3], [x16]
     b38:      	tbz	w15, #0x4, 0xafc <ltmp0+0xafc>
     b3c:      	add	x16, x14, #0x10
     b40:      	ld1.s	{ v4 }[0], [x16]
     b44:      	tbz	w15, #0x5, 0xb00 <ltmp0+0xb00>
     b48:      	add	x16, x14, #0x14
     b4c:      	ld1.s	{ v4 }[1], [x16]
     b50:      	tbz	w15, #0x6, 0xb04 <ltmp0+0xb04>
     b54:      	add	x16, x14, #0x18
     b58:      	ld1.s	{ v4 }[2], [x16]
     b5c:      	tbz	w15, #0x7, 0xaa0 <ltmp0+0xaa0>
     b60:      	add	x14, x14, #0x1c
     b64:      	ld1.s	{ v4 }[3], [x14]
     b68:      	b	0xaa0 <ltmp0+0xaa0>
     b6c:      	movi	d3, #0xffffffffffff0000
     b70:      	and.8b	v3, v24, v3
     b74:      	fmul.4s	v4, v30, v30
     b78:      	fmul.4s	v5, v29, v29
     b7c:      	fadd.4s	v5, v5, v18
     b80:      	fadd.4s	v4, v4, v10
     b84:      	zip1.8b	v16, v6, v0
     b88:      	ushll.4s	v16, v16, #0x0
     b8c:      	shl.4s	v16, v16, #0x1f
     b90:      	cmlt.4s	v16, v16, #0
     b94:      	and.16b	v4, v16, v4
     b98:      	zip2.8b	v16, v6, v0
     b9c:      	ushll.4s	v16, v16, #0x0
     ba0:      	shl.4s	v16, v16, #0x1f
     ba4:      	cmlt.4s	v16, v16, #0
     ba8:      	and.16b	v5, v16, v5
     bac:      	zip2.8b	v16, v3, v0
     bb0:      	ushll.4s	v16, v16, #0x0
     bb4:      	shl.4s	v16, v16, #0x1f
     bb8:      	cmlt.4s	v16, v16, #0
     bbc:      	bit.16b	v5, v7, v16
     bc0:      	zip1.8b	v3, v3, v0
     bc4:      	ushll.4s	v3, v3, #0x0
     bc8:      	shl.4s	v3, v3, #0x1f
     bcc:      	cmlt.4s	v3, v3, #0
     bd0:      	bsl.16b	v3, v19, v4
     bd4:      	fadd.4s	v3, v9, v3
     bd8:      	fadd.4s	v4, v15, v5
     bdc:      	fadd.4s	v4, v14, v4
     be0:      	fadd.4s	v3, v13, v3
     be4:      	fadd.4s	v18, v12, v3
     be8:      	fadd.4s	v19, v11, v4
     bec:      	ldp	q3, q5, [sp, #0x60]
     bf0:      	ldr	q4, [sp, #0x20]
     bf4:      	uzp1.4s	v7, v5, v4
     bf8:      	ldr	q4, [sp, #0x10]
     bfc:      	uzp1.4s	v28, v4, v3
     c00:      	movi.4s	v4, #0x1
     c04:      	eor.16b	v3, v7, v4
     c08:      	mov.s	w14, v3[1]
     c0c:      	mov.s	w17, v3[2]
     c10:      	eor.16b	v25, v28, v4
     c14:      	mov.s	w0, v3[3]
     c18:      	fmov	w13, s3
     c1c:      	add	x15, sp, #0x178
     c20:      	bfxil	x15, x13, #0, #3
     c24:      	str	d24, [sp, #0x178]
     c28:      	ldrb	w16, [x15]
     c2c:      	and	x15, x13, #0x7
     c30:      	umov.b	w13, v24[0]
     c34:      	stp	q18, q19, [sp, #0x280]
     c38:      	add	x1, sp, #0x280
     c3c:      	ldr	s3, [x1, x15, lsl #2]
     c40:      	ands	w15, w13, #0x1
     c44:      	tst	w15, w16
     c48:      	fcsel	s16, s3, s8, ne
     c4c:      	add	x16, sp, #0x178
     c50:      	bfxil	x16, x14, #0, #3
     c54:      	ldrb	w16, [x16]
     c58:      	and	x1, x14, #0x7
     c5c:      	umov.b	w14, v24[1]
     c60:      	stp	q18, q19, [sp, #0x260]
     c64:      	add	x2, sp, #0x260
     c68:      	ldr	s3, [x2, x1, lsl #2]
     c6c:      	ands	w1, w14, #0x1
     c70:      	tst	w1, w16
     c74:      	fcsel	s17, s3, s8, ne
     c78:      	add	x16, sp, #0x178
     c7c:      	bfxil	x16, x17, #0, #3
     c80:      	ldrb	w1, [x16]
     c84:      	umov.b	w16, v24[2]
     c88:      	and	x17, x17, #0x7
     c8c:      	stp	q18, q19, [sp, #0x240]
     c90:      	add	x2, sp, #0x240
     c94:      	ldr	s3, [x2, x17, lsl #2]
     c98:      	ands	w17, w16, #0x1
     c9c:      	tst	w17, w1
     ca0:      	fcsel	s4, s3, s8, ne
     ca4:      	add	x17, sp, #0x178
     ca8:      	bfxil	x17, x0, #0, #3
     cac:      	ldrb	w1, [x17]
     cb0:      	and	x0, x0, #0x7
     cb4:      	umov.b	w17, v24[3]
     cb8:      	stp	q18, q19, [sp, #0x220]
     cbc:      	add	x2, sp, #0x220
     cc0:      	ldr	s3, [x2, x0, lsl #2]
     cc4:      	ands	w0, w17, #0x1
     cc8:      	tst	w0, w1
     ccc:      	mov.s	w1, v25[1]
     cd0:      	mov.s	w2, v25[2]
     cd4:      	fcsel	s26, s3, s8, ne
     cd8:      	mov.s	w4, v25[3]
     cdc:      	fmov	w0, s25
     ce0:      	and	x3, x0, #0x7
     ce4:      	add	x5, sp, #0x178
     ce8:      	bfxil	x5, x0, #0, #3
     cec:      	ldrb	w5, [x5]
     cf0:      	umov.b	w0, v24[4]
     cf4:      	and	w5, w0, w5
     cf8:      	stp	q18, q19, [sp, #0x300]
     cfc:      	add	x6, sp, #0x300
     d00:      	ldr	s3, [x6, x3, lsl #2]
     d04:      	tst	w5, #0x1
     d08:      	fcsel	s3, s3, s8, ne
     d0c:      	add	x3, sp, #0x178
     d10:      	bfxil	x3, x1, #0, #3
     d14:      	ldrb	w3, [x3]
     d18:      	and	x5, x1, #0x7
     d1c:      	umov.b	w1, v24[5]
     d20:      	stp	q18, q19, [sp, #0x2e0]
     d24:      	add	x6, sp, #0x2e0
     d28:      	ldr	s5, [x6, x5, lsl #2]
     d2c:      	ands	w5, w1, #0x1
     d30:      	tst	w5, w3
     d34:      	fcsel	s5, s5, s8, ne
     d38:      	add	x3, sp, #0x178
     d3c:      	bfxil	x3, x2, #0, #3
     d40:      	ldrb	w3, [x3]
     d44:      	and	x5, x2, #0x7
     d48:      	umov.b	w2, v24[6]
     d4c:      	stp	q18, q19, [sp, #0x2c0]
     d50:      	add	x6, sp, #0x2c0
     d54:      	ldr	s25, [x6, x5, lsl #2]
     d58:      	ands	w5, w2, #0x1
     d5c:      	tst	w5, w3
     d60:      	fcsel	s25, s25, s8, ne
     d64:      	add	x3, sp, #0x178
     d68:      	bfxil	x3, x4, #0, #3
     d6c:      	ldrb	w5, [x3]
     d70:      	umov.b	w3, v24[7]
     d74:      	and	x4, x4, #0x7
     d78:      	stp	q18, q19, [sp, #0x2a0]
     d7c:      	add	x6, sp, #0x2a0
     d80:      	ldr	s24, [x6, x4, lsl #2]
     d84:      	ands	w4, w3, #0x1
     d88:      	tst	w4, w5
     d8c:      	fcsel	s24, s24, s8, ne
     d90:      	mov.s	v3[1], v5[0]
     d94:      	mov.s	v3[2], v25[0]
     d98:      	mov.s	v3[3], v24[0]
     d9c:      	mov.s	v16[1], v17[0]
     da0:      	mov.s	v16[2], v4[0]
     da4:      	mov.s	v16[3], v26[0]
     da8:      	fadd.4s	v4, v18, v16
     dac:      	fadd.4s	v3, v19, v3
     db0:      	movi.4s	v16, #0x2
     db4:      	eor.16b	v5, v28, v16
     db8:      	eor.16b	v7, v7, v16
     dbc:      	fmov	w4, s7
     dc0:      	add	x5, sp, #0x178
     dc4:      	bfxil	x5, x4, #0, #3
     dc8:      	ldrb	w5, [x5]
     dcc:      	and	x4, x4, #0x7
     dd0:      	stp	q4, q3, [sp, #0x200]
     dd4:      	add	x6, sp, #0x200
     dd8:      	ldr	s7, [x6, x4, lsl #2]
     ddc:      	tst	w15, w5
     de0:      	fcsel	s7, s7, s8, ne
     de4:      	fmov	w4, s5
     de8:      	and	x5, x4, #0x7
     dec:      	add	x6, sp, #0x178
     df0:      	bfxil	x6, x4, #0, #3
     df4:      	ldrb	w4, [x6]
     df8:      	and	w4, w0, w4
     dfc:      	stp	q4, q3, [sp, #0x1e0]
     e00:      	add	x6, sp, #0x1e0
     e04:      	ldr	s5, [x6, x5, lsl #2]
     e08:      	tst	w4, #0x1
     e0c:      	fcsel	s5, s5, s8, ne
     e10:      	fadd.4s	v3, v3, v5
     e14:      	tst	w15, w0
     e18:      	fcsel	s3, s3, s8, ne
     e1c:      	ands	w13, w13, #0x1
     e20:      	fadd.4s	v4, v4, v7
     e24:      	fadd	s3, s4, s3
     e28:      	fcsel	s4, s3, s8, ne
     e2c:      	tst	w14, #0x1
     e30:      	fcsel	s5, s4, s8, ne
     e34:      	tst	w16, #0x1
     e38:      	fcsel	s7, s4, s8, ne
     e3c:      	tst	w17, #0x1
     e40:      	fcsel	s16, s4, s8, ne
     e44:      	tst	w13, w0
     e48:      	fcsel	s3, s3, s8, ne
     e4c:      	tst	w1, #0x1
     e50:      	fcsel	s17, s4, s8, ne
     e54:      	tst	w2, #0x1
     e58:      	fcsel	s18, s4, s8, ne
     e5c:      	tst	w3, #0x1
     e60:      	adrp	x13, 0x0 <ltmp0>
     e64:      	ldr	d19, [x13]
     e68:      	shl.8b	v24, v6, #0x7
     e6c:      	cmlt.8b	v24, v24, #0
     e70:      	and.8b	v19, v24, v19
     e74:      	addv.8b	b24, v19
     e78:      	fmov	w13, s24
     e7c:      	fcsel	s19, s4, s8, ne
     e80:      	mov.s	v4[1], v5[0]
     e84:      	mov.s	v4[2], v7[0]
     e88:      	mov.s	v4[3], v16[0]
     e8c:      	mov.s	v3[1], v17[0]
     e90:      	mov.s	v3[2], v18[0]
     e94:      	mov.s	v3[3], v19[0]
     e98:      	rbit	w11, w11
     e9c:      	clz	w11, w11
     ea0:      	stp	q4, q3, [sp, #0x1c0]
     ea4:      	and	x11, x11, #0x7
     ea8:      	add	x14, sp, #0x1c0
     eac:      	ldr	s19, [x14, x11, lsl #2]
     eb0:      	mov	b3, v6[0]
     eb4:      	mov.b	v3[4], v6[1]
     eb8:      	ushll.2d	v3, v3, #0x0
     ebc:      	shl.2d	v3, v3, #0x3f
     ec0:      	cmlt.2d	v3, v3, #0
     ec4:      	mov	b4, v6[2]
     ec8:      	mov.b	v4[4], v6[3]
     ecc:      	ldp	q16, q5, [sp, #0xa0]
     ed0:      	and.16b	v3, v3, v5
     ed4:      	ushll.2d	v4, v4, #0x0
     ed8:      	shl.2d	v4, v4, #0x3f
     edc:      	cmlt.2d	v4, v4, #0
     ee0:      	ldp	q5, q7, [sp, #0x80]
     ee4:      	and.16b	v4, v4, v5
     ee8:      	mov	b5, v6[4]
     eec:      	mov.b	v5[4], v6[5]
     ef0:      	ushll.2d	v5, v5, #0x0
     ef4:      	shl.2d	v5, v5, #0x3f
     ef8:      	cmlt.2d	v5, v5, #0
     efc:      	and.16b	v5, v5, v7
     f00:      	mov	b7, v6[6]
     f04:      	mov.b	v7[4], v6[7]
     f08:      	ushll.2d	v7, v7, #0x0
     f0c:      	shl.2d	v7, v7, #0x3f
     f10:      	cmlt.2d	v7, v7, #0
     f14:      	and.16b	v7, v7, v16
     f18:      	stp	q5, q7, [sp, #0x1a0]
     f1c:      	stp	q3, q4, [sp, #0x180]
     f20:      	and	x11, x9, #0x7
     f24:      	add	x14, sp, #0x180
     f28:      	ldr	x11, [x14, x11, lsl #3]
     f2c:      	sub	x11, x11, x9
     f30:      	add	x10, x10, x11, lsl #2
     f34:      	movi.2d	v7, #0000000000000000
     f38:      	movi.2d	v18, #0000000000000000
     f3c:      	tbnz	w13, #0x0, 0x118c <ltmp0+0x118c>
     f40:      	tbnz	w13, #0x1, 0x1194 <ltmp0+0x1194>
     f44:      	tbnz	w13, #0x2, 0x11a0 <ltmp0+0x11a0>
     f48:      	tbnz	w13, #0x3, 0x11ac <ltmp0+0x11ac>
     f4c:      	tbnz	w13, #0x4, 0x11b8 <ltmp0+0x11b8>
     f50:      	tbnz	w13, #0x5, 0x11c4 <ltmp0+0x11c4>
     f54:      	tbnz	w13, #0x6, 0x11d0 <ltmp0+0x11d0>
     f58:      	tbz	w13, #0x7, 0xf64 <ltmp0+0xf64>
     f5c:      	add	x10, x10, #0x1c
     f60:      	ld1.s	{ v18 }[3], [x10]
     f64:      	mov	x11, #0x0               ; =0
     f68:      	fadd	s3, s19, s8
     f6c:      	mov	w10, #0x4000            ; =16384
     f70:      	movk	w10, #0x44c0, lsl #16
     f74:      	fmov	s4, w10
     f78:      	fdiv	s3, s3, s4
     f7c:      	add	x10, x24, x12
     f80:      	ldp	q4, q5, [x10]
     f84:      	zip2.8b	v16, v6, v0
     f88:      	ushll.4s	v16, v16, #0x0
     f8c:      	shl.4s	v16, v16, #0x1f
     f90:      	cmlt.4s	v16, v16, #0
     f94:      	bit.16b	v5, v18, v16
     f98:      	zip1.8b	v6, v6, v0
     f9c:      	ushll.4s	v6, v6, #0x0
     fa0:      	shl.4s	v6, v6, #0x1f
     fa4:      	cmlt.4s	v6, v6, #0
     fa8:      	bit.16b	v4, v7, v6
     fac:      	stp	q4, q5, [x10]
     fb0:      	mov	w10, #0xc5ac            ; =50604
     fb4:      	movk	w10, #0x3727, lsl #16
     fb8:      	fmov	s4, w10
     fbc:      	fadd	s3, s3, s4
     fc0:      	fsqrt	s3, s3
     fc4:      	dup.4s	v6, v3[0]
     fc8:      	ldr	q3, [sp, #0xc0]
     fcc:      	fmov	x10, d3
     fd0:      	add	x10, x8, x10, lsl #2
     fd4:      	movi.2d	v4, #0000000000000000
     fd8:      	movi.2d	v16, #0000000000000000
     fdc:      	movi.2d	v17, #0000000000000000
     fe0:      	movi.2d	v19, #0000000000000000
     fe4:      	b	0x1004 <ltmp0+0x1004>
     fe8:      	add.2d	v16, v16, v21
     fec:      	add.2d	v17, v17, v22
     ff0:      	add.2d	v19, v19, v20
     ff4:      	add.2d	v4, v4, v23
     ff8:      	fmov	x11, d4
     ffc:      	cmp	x11, #0xc0
    1000:      	b.ge	0x10d4 <ltmp0+0x10d4>
    1004:      	fmov	w12, s2
    1008:      	lsl	x11, x11, #5
    100c:      	add	x13, x26, x11
    1010:      	ldp	q3, q25, [x13]
    1014:      	and.16b	v3, v1, v3
    1018:      	fdiv.4s	v3, v3, v6
    101c:      	add	x13, x24, x11
    1020:      	ldp	q5, q26, [x13]
    1024:      	and.16b	v5, v1, v5
    1028:      	fmul.4s	v27, v3, v5
    102c:      	add	x11, x10, x11
    1030:      	tbnz	w12, #0x0, 0x1068 <ltmp0+0x1068>
    1034:      	and	w12, w12, #0xff
    1038:      	tbnz	w12, #0x1, 0x1074 <ltmp0+0x1074>
    103c:      	tbnz	w12, #0x2, 0x1080 <ltmp0+0x1080>
    1040:      	tbnz	w12, #0x3, 0x108c <ltmp0+0x108c>
    1044:      	and.16b	v3, v0, v25
    1048:      	fdiv.4s	v3, v3, v6
    104c:      	and.16b	v5, v0, v26
    1050:      	fmul.4s	v25, v3, v5
    1054:      	tbnz	w12, #0x4, 0x10a8 <ltmp0+0x10a8>
    1058:      	tbnz	w12, #0x5, 0x10b0 <ltmp0+0x10b0>
    105c:      	tbnz	w12, #0x6, 0x10bc <ltmp0+0x10bc>
    1060:      	tbz	w12, #0x7, 0xfe8 <ltmp0+0xfe8>
    1064:      	b	0x10c8 <ltmp0+0x10c8>
    1068:      	str	s27, [x11]
    106c:      	and	w12, w12, #0xff
    1070:      	tbz	w12, #0x1, 0x103c <ltmp0+0x103c>
    1074:      	add	x13, x11, #0x4
    1078:      	st1.s	{ v27 }[1], [x13]
    107c:      	tbz	w12, #0x2, 0x1040 <ltmp0+0x1040>
    1080:      	add	x13, x11, #0x8
    1084:      	st1.s	{ v27 }[2], [x13]
    1088:      	tbz	w12, #0x3, 0x1044 <ltmp0+0x1044>
    108c:      	add	x13, x11, #0xc
    1090:      	st1.s	{ v27 }[3], [x13]
    1094:      	and.16b	v3, v0, v25
    1098:      	fdiv.4s	v3, v3, v6
    109c:      	and.16b	v5, v0, v26
    10a0:      	fmul.4s	v25, v3, v5
    10a4:      	tbz	w12, #0x4, 0x1058 <ltmp0+0x1058>
    10a8:      	str	s25, [x11, #0x10]
    10ac:      	tbz	w12, #0x5, 0x105c <ltmp0+0x105c>
    10b0:      	add	x13, x11, #0x14
    10b4:      	st1.s	{ v25 }[1], [x13]
    10b8:      	tbz	w12, #0x6, 0x1060 <ltmp0+0x1060>
    10bc:      	add	x13, x11, #0x18
    10c0:      	st1.s	{ v25 }[2], [x13]
    10c4:      	tbz	w12, #0x7, 0xfe8 <ltmp0+0xfe8>
    10c8:      	add	x11, x11, #0x1c
    10cc:      	st1.s	{ v25 }[3], [x11]
    10d0:      	b	0xfe8 <ltmp0+0xfe8>
    10d4:      	fdiv.4s	v0, v30, v6
    10d8:      	fmul.4s	v0, v0, v7
    10dc:      	ldr	q2, [sp, #0x110]
    10e0:      	ldp	q4, q3, [sp, #0xd0]
    10e4:      	stp	q2, q3, [sp, #0x130]
    10e8:      	ldr	q1, [sp, #0xf0]
    10ec:      	stp	q4, q1, [sp, #0x150]
    10f0:      	and	x10, x9, #0x7
    10f4:      	add	x11, sp, #0x130
    10f8:      	ldr	x10, [x11, x10, lsl #3]
    10fc:      	sub	x9, x10, x9
    1100:      	add	x8, x8, x9, lsl #2
    1104:      	fmov	w9, s24
    1108:      	tbnz	w9, #0x0, 0x11e0 <ltmp0+0x11e0>
    110c:      	tbnz	w9, #0x1, 0x11e8 <ltmp0+0x11e8>
    1110:      	tbnz	w9, #0x2, 0x11f4 <ltmp0+0x11f4>
    1114:      	tbnz	w9, #0x3, 0x1200 <ltmp0+0x1200>
    1118:      	fdiv.4s	v0, v29, v6
    111c:      	fmul.4s	v0, v0, v18
    1120:      	tbnz	w9, #0x4, 0x1214 <ltmp0+0x1214>
    1124:      	tbnz	w9, #0x5, 0x121c <ltmp0+0x121c>
    1128:      	tbnz	w9, #0x6, 0x1228 <ltmp0+0x1228>
    112c:      	tbz	w9, #0x7, 0x6c <ltmp0+0x6c>
    1130:      	b	0x1234 <ltmp0+0x1234>
    1134:      	ldr	s5, [x12]
    1138:      	tbz	w13, #0x1, 0x7d8 <ltmp0+0x7d8>
    113c:      	add	x14, x12, #0x4
    1140:      	ld1.s	{ v5 }[1], [x14]
    1144:      	mov	w15, #0x4               ; =4
    1148:      	tbz	w13, #0x2, 0x7e0 <ltmp0+0x7e0>
    114c:      	add	x14, x12, #0x8
    1150:      	ld1.s	{ v5 }[2], [x14]
    1154:      	tbz	w13, #0x3, 0x7e4 <ltmp0+0x7e4>
    1158:      	add	x14, x12, #0xc
    115c:      	ld1.s	{ v5 }[3], [x14]
    1160:      	tbz	w13, #0x4, 0x7e8 <ltmp0+0x7e8>
    1164:      	add	x14, x12, #0x10
    1168:      	ld1.s	{ v3 }[0], [x14]
    116c:      	tbz	w13, #0x5, 0x7ec <ltmp0+0x7ec>
    1170:      	add	x14, x12, #0x14
    1174:      	ld1.s	{ v3 }[1], [x14]
    1178:      	tbz	w13, #0x6, 0x7f0 <ltmp0+0x7f0>
    117c:      	add	x14, x12, #0x18
    1180:      	ld1.s	{ v3 }[2], [x14]
    1184:      	tbnz	w13, #0x7, 0x7f4 <ltmp0+0x7f4>
    1188:      	b	0x7fc <ltmp0+0x7fc>
    118c:      	ldr	s7, [x10]
    1190:      	tbz	w13, #0x1, 0xf44 <ltmp0+0xf44>
    1194:      	add	x11, x10, #0x4
    1198:      	ld1.s	{ v7 }[1], [x11]
    119c:      	tbz	w13, #0x2, 0xf48 <ltmp0+0xf48>
    11a0:      	add	x11, x10, #0x8
    11a4:      	ld1.s	{ v7 }[2], [x11]
    11a8:      	tbz	w13, #0x3, 0xf4c <ltmp0+0xf4c>
    11ac:      	add	x11, x10, #0xc
    11b0:      	ld1.s	{ v7 }[3], [x11]
    11b4:      	tbz	w13, #0x4, 0xf50 <ltmp0+0xf50>
    11b8:      	add	x11, x10, #0x10
    11bc:      	ld1.s	{ v18 }[0], [x11]
    11c0:      	tbz	w13, #0x5, 0xf54 <ltmp0+0xf54>
    11c4:      	add	x11, x10, #0x14
    11c8:      	ld1.s	{ v18 }[1], [x11]
    11cc:      	tbz	w13, #0x6, 0xf58 <ltmp0+0xf58>
    11d0:      	add	x11, x10, #0x18
    11d4:      	ld1.s	{ v18 }[2], [x11]
    11d8:      	tbnz	w13, #0x7, 0xf5c <ltmp0+0xf5c>
    11dc:      	b	0xf64 <ltmp0+0xf64>
    11e0:      	str	s0, [x8]
    11e4:      	tbz	w9, #0x1, 0x1110 <ltmp0+0x1110>
    11e8:      	add	x10, x8, #0x4
    11ec:      	st1.s	{ v0 }[1], [x10]
    11f0:      	tbz	w9, #0x2, 0x1114 <ltmp0+0x1114>
    11f4:      	add	x10, x8, #0x8
    11f8:      	st1.s	{ v0 }[2], [x10]
    11fc:      	tbz	w9, #0x3, 0x1118 <ltmp0+0x1118>
    1200:      	add	x10, x8, #0xc
    1204:      	st1.s	{ v0 }[3], [x10]
    1208:      	fdiv.4s	v0, v29, v6
    120c:      	fmul.4s	v0, v0, v18
    1210:      	tbz	w9, #0x4, 0x1124 <ltmp0+0x1124>
    1214:      	str	s0, [x8, #0x10]
    1218:      	tbz	w9, #0x5, 0x1128 <ltmp0+0x1128>
    121c:      	add	x10, x8, #0x14
    1220:      	st1.s	{ v0 }[1], [x10]
    1224:      	tbz	w9, #0x6, 0x112c <ltmp0+0x112c>
    1228:      	add	x10, x8, #0x18
    122c:      	st1.s	{ v0 }[2], [x10]
    1230:      	tbz	w9, #0x7, 0x6c <ltmp0+0x6c>
    1234:      	add	x8, x8, #0x1c
    1238:      	st1.s	{ v0 }[3], [x8]
    123c:      	b	0x6c <ltmp0+0x6c>
    1240:      	ldr	x9, [sp, #0x8]
    1244:      	stp	w15, w14, [x9]
    1248:      	str	w13, [x9, #0x8]
    124c:      	mov	w8, #0x18               ; =24
    1250:      	str	w8, [x9, #0x24]
    1254:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    1258:      	add	sp, sp, #0x400
    125c:      	ldp	x29, x30, [sp, #0x90]
    1260:      	ldp	x20, x19, [sp, #0x80]
    1264:      	ldp	x22, x21, [sp, #0x70]
    1268:      	ldp	x24, x23, [sp, #0x60]
    126c:      	ldp	x26, x25, [sp, #0x50]
    1270:      	ldp	x28, x27, [sp, #0x40]
    1274:      	ldp	d9, d8, [sp, #0x30]
    1278:      	ldp	d11, d10, [sp, #0x20]
    127c:      	ldp	d13, d12, [sp, #0x10]
    1280:      	ldp	d15, d14, [sp], #0xa0
    1284:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/capture/gelu_residual-129x768/on/object/tile_xir_w8_36446_1788935104029247_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      2c:      	sub	sp, sp, #0xa20
      30:      	str	x0, [sp, #0x18]
      34:      	str	w3, [sp, #0x38]
      38:      	cbz	w3, 0x1c58 <ltmp0+0x1c58>
      3c:      	mov	w17, #0x0               ; =0
      40:      	ldp	w9, w8, [x2, #0x2c]
      44:      	stp	w8, w9, [sp, #0x30]
      48:      	mov	w10, #0x2713            ; =10003
      4c:      	movk	w10, #0x3d37, lsl #16
      50:      	ldp	w8, w9, [x2]
      54:      	mov	w11, #0x422a            ; =16938
      58:      	movk	w11, #0x3f4c, lsl #16
      5c:      	fmov.4s	v31, #1.00000000
      60:      	mov	w12, #0x9231            ; =37425
      64:      	movk	w12, #0x2f30, lsl #16
      68:      	dup.4s	v1, w10
      6c:      	mov	w10, #0x322b            ; =12843
      70:      	movk	w10, #0x32d7, lsl #16
      74:      	dup.4s	v0, w11
      78:      	stp	q0, q1, [sp, #0x1f0]
      7c:      	mov	w11, #0xef1d            ; =61213
      80:      	movk	w11, #0x3638, lsl #16
      84:      	dup.4s	v1, w12
      88:      	mov	w12, #0xd01             ; =3329
      8c:      	movk	w12, #0x3950, lsl #16
      90:      	dup.4s	v0, w10
      94:      	stp	q0, q1, [sp, #0x1d0]
      98:      	mov	w10, #0x8889            ; =34953
      9c:      	movk	w10, #0x3c08, lsl #16
      a0:      	dup.4s	v1, w11
      a4:      	mov	w11, #0xaaab            ; =43691
      a8:      	movk	w11, #0x3e2a, lsl #16
      ac:      	dup.4s	v0, w12
      b0:      	stp	q0, q1, [sp, #0x1b0]
      b4:      	mov	w12, #0x76c7            ; =30407
      b8:      	movk	w12, #0x310f, lsl #16
      bc:      	dup.4s	v1, w10
      c0:      	mov	w13, #0xf27e            ; =62078
      c4:      	movk	w13, #0x3493, lsl #16
      c8:      	mov	w14, #0xd01             ; =3329
      cc:      	movk	w14, #0x37d0, lsl #16
      d0:      	mov	w15, #0xb61             ; =2913
      d4:      	movk	w15, #0x3ab6, lsl #16
      d8:      	mov	w16, #0xaaab            ; =43691
      dc:      	movk	w16, #0x3d2a, lsl #16
      e0:      	ldp	w10, w0, [x2, #0x8]
      e4:      	str	x2, [sp, #0x10]
      e8:      	str	x0, [sp, #0x28]
      ec:      	fmov.4s	v0, #9.00000000
      f0:      	stp	q0, q1, [sp, #0x190]
      f4:      	dup.4s	v29, w11
      f8:      	mov	w11, #-0x3d300000       ; =-1026555904
      fc:      	dup.4s	v1, w12
     100:      	mov	w12, #0x42c80000        ; =1120403456
     104:      	dup.4s	v2, w13
     108:      	mov	w13, #0xaa3b            ; =43579
     10c:      	movk	w13, #0x3fb8, lsl #16
     110:      	dup.4s	v0, w14
     114:      	stp	q0, q1, [sp, #0xe0]
     118:      	dup.4s	v1, w15
     11c:      	dup.4s	v0, w16
     120:      	stp	q0, q1, [sp, #0xc0]
     124:      	mov	w14, #0x7200            ; =29184
     128:      	movk	w14, #0xbf31, lsl #16
     12c:      	dup.4s	v0, w11
     130:      	stp	q0, q2, [sp, #0x160]
     134:      	mov	w11, #0xbe8e            ; =48782
     138:      	movk	w11, #0xb5bf, lsl #16
     13c:      	dup.4s	v1, w12
     140:      	mov	w12, #0x2bda            ; =11226
     144:      	movk	w12, #0x3950, lsl #16
     148:      	dup.4s	v2, w13
     14c:      	mov	w13, #0x96c9            ; =38601
     150:      	movk	w13, #0x3ab6, lsl #16
     154:      	dup.4s	v0, w14
     158:      	stp	q0, q2, [sp, #0x140]
     15c:      	mov	w14, #0x88a6            ; =34982
     160:      	movk	w14, #0x3c08, lsl #16
     164:      	dup.4s	v2, w11
     168:      	mov	w11, #0xaa7a            ; =43642
     16c:      	movk	w11, #0x3d2a, lsl #16
     170:      	dup.4s	v0, w12
     174:      	stp	q0, q2, [sp, #0xa0]
     178:      	dup.4s	v0, w13
     17c:      	stp	q1, q0, [sp, #0x70]
     180:      	mvni.4s	v0, #0x7f, msl #16
     184:      	dup.4s	v1, w14
     188:      	fneg.4s	v0, v0
     18c:      	str	q0, [sp, #0x90]
     190:      	dup.4s	v2, w11
     194:      	fmov.4s	v0, #0.25000000
     198:      	stp	q0, q2, [sp, #0x120]
     19c:      	mvni.4s	v0, #0x3f, msl #16
     1a0:      	add	x28, sp, #0xe20
     1a4:      	fneg.4s	v0, v0
     1a8:      	stp	q1, q0, [sp, #0x100]
     1ac:      	add	x19, sp, #0x220
     1b0:      	str	q31, [sp, #0x60]
     1b4:      	str	q29, [sp, #0x180]
     1b8:      	b	0x204 <ltmp0+0x204>
     1bc:      	ldr	x14, [sp, #0x48]
     1c0:      	add	w8, w14, #0x1
     1c4:      	ldp	w11, w9, [sp, #0x30]
     1c8:      	cmp	w8, w9
     1cc:      	cset	w9, eq
     1d0:      	csinc	w8, wzr, w14, eq
     1d4:      	ldp	w13, w12, [sp, #0x3c]
     1d8:      	cinc	w10, w13, eq
     1dc:      	cmp	w10, w11
     1e0:      	cset	w11, eq
     1e4:      	ands	w11, w9, w11
     1e8:      	csel	w9, wzr, w10, ne
     1ec:      	add	w10, w12, w11
     1f0:      	ldr	w17, [sp, #0x44]
     1f4:      	add	w17, w17, #0x1
     1f8:      	ldr	w11, [sp, #0x38]
     1fc:      	cmp	w17, w11
     200:      	b.eq	0x1c44 <ltmp0+0x1c44>
     204:      	mov	x13, x10
     208:      	mov	x14, x9
     20c:      	mov	x15, x8
     210:      	ubfiz	x8, x8, #5, #32
     214:      	ldr	x12, [sp, #0x28]
     218:      	cmp	x8, x12
     21c:      	csel	x9, x8, xzr, ls
     220:      	subs	x10, x12, x9
     224:      	cmp	x10, #0x20
     228:      	mov	w11, #0x20              ; =32
     22c:      	csel	x10, x10, x11, lo
     230:      	cmp	x12, x9
     234:      	ccmp	x8, x12, #0x2, hi
     238:      	csel	x8, x10, xzr, ls
     23c:      	cmp	x8, #0x20
     240:      	str	x15, [sp, #0x48]
     244:      	stp	w13, w17, [sp, #0x40]
     248:      	str	w14, [sp, #0x3c]
     24c:      	b.lo	0x990 <ltmp0+0x990>
     250:      	mov	x21, #0x0               ; =0
     254:      	ldr	x8, [sp, #0x18]
     258:      	ldr	x23, [x8]
     25c:      	ldr	x24, [x8, #0x10]
     260:      	ldr	x8, [x8, #0x30]
     264:      	subs	x9, x23, x8
     268:      	mov	w12, #0xbff             ; =3071
     26c:      	movk	w12, #0x6, lsl #16
     270:      	ccmp	x9, x12, #0x0, hs
     274:      	cset	w9, hi
     278:      	subs	x10, x8, x23
     27c:      	ccmp	x10, x12, #0x0, hs
     280:      	csinc	w9, w9, wzr, ls
     284:      	subs	x10, x24, x8
     288:      	ccmp	x10, x12, #0x0, hs
     28c:      	cset	w10, hi
     290:      	subs	x11, x8, x24
     294:      	ccmp	x11, x12, #0x0, hs
     298:      	csinc	w10, w10, wzr, ls
     29c:      	and	w25, w9, w10
     2a0:      	lsl	w9, w15, #2
     2a4:      	str	x9, [sp, #0x58]
     2a8:      	and	x9, x15, #0x7ffffff
     2ac:      	add	x9, x9, x9, lsl #1
     2b0:      	lsl	x9, x9, #12
     2b4:      	add	x22, x8, x9
     2b8:      	add	x26, x24, x9
     2bc:      	add	x27, x23, x9
     2c0:      	b	0x2dc <ltmp0+0x2dc>
     2c4:      	add	x21, x21, #0x1
     2c8:      	add	x22, x22, #0xc00
     2cc:      	add	x26, x26, #0xc00
     2d0:      	add	x27, x27, #0xc00
     2d4:      	cmp	x21, #0x4
     2d8:      	b.eq	0x1bc <ltmp0+0x1bc>
     2dc:      	cbz	w25, 0x618 <ltmp0+0x618>
     2e0:      	mov	x8, #0x0                ; =0
     2e4:      	ldp	q11, q10, [sp, #0x70]
     2e8:      	ldr	q8, [sp, #0xb0]
     2ec:      	ldp	q12, q13, [sp, #0x100]
     2f0:      	ldr	q14, [sp, #0x90]
     2f4:      	ldp	q30, q15, [sp, #0x120]
     2f8:      	add	x9, x27, x8
     2fc:      	ldp	q0, q1, [x9]
     300:      	ldp	q5, q3, [sp, #0x1f0]
     304:      	fmul.4s	v2, v0, v3
     308:      	fmul.4s	v3, v1, v3
     30c:      	fmul.4s	v3, v1, v3
     310:      	fmul.4s	v2, v0, v2
     314:      	fmul.4s	v2, v0, v2
     318:      	fmul.4s	v3, v1, v3
     31c:      	fadd.4s	v4, v1, v3
     320:      	fadd.4s	v2, v0, v2
     324:      	fmul.4s	v3, v2, v5
     328:      	fmul.4s	v2, v4, v5
     32c:      	fabs.4s	v5, v2
     330:      	fabs.4s	v4, v3
     334:      	fmul.4s	v19, v3, v3
     338:      	fmul.4s	v21, v2, v2
     33c:      	ldp	q7, q16, [sp, #0x1d0]
     340:      	mov.16b	v6, v7
     344:      	fmla.4s	v6, v19, v16
     348:      	fmla.4s	v7, v21, v16
     34c:      	ldr	q17, [sp, #0x1c0]
     350:      	mov.16b	v16, v17
     354:      	fmla.4s	v16, v19, v6
     358:      	mov.16b	v6, v17
     35c:      	fmla.4s	v6, v21, v7
     360:      	ldp	q18, q17, [sp, #0x1a0]
     364:      	mov.16b	v7, v17
     368:      	fmla.4s	v7, v19, v16
     36c:      	mov.16b	v16, v17
     370:      	fmla.4s	v16, v21, v6
     374:      	mov.16b	v17, v18
     378:      	mov.16b	v22, v29
     37c:      	mov.16b	v23, v29
     380:      	mov.16b	v6, v31
     384:      	fmla.4s	v17, v19, v7
     388:      	ldr	q20, [sp, #0x170]
     38c:      	mov.16b	v7, v20
     390:      	ldp	q25, q24, [sp, #0xe0]
     394:      	fmla.4s	v7, v21, v24
     398:      	fmla.4s	v20, v19, v24
     39c:      	mov.16b	v24, v25
     3a0:      	fmla.4s	v18, v21, v16
     3a4:      	fmla.4s	v24, v21, v7
     3a8:      	mov.16b	v7, v25
     3ac:      	fmla.4s	v7, v19, v20
     3b0:      	ldr	q20, [sp, #0xd0]
     3b4:      	mov.16b	v16, v20
     3b8:      	fmla.4s	v16, v21, v24
     3bc:      	fmla.4s	v22, v19, v17
     3c0:      	mov.16b	v17, v20
     3c4:      	fmla.4s	v17, v19, v7
     3c8:      	ldr	q24, [sp, #0xc0]
     3cc:      	mov.16b	v20, v24
     3d0:      	fmla.4s	v20, v21, v16
     3d4:      	fmla.4s	v23, v21, v18
     3d8:      	fmla.4s	v24, v19, v17
     3dc:      	movi.4s	v25, #0x3f, lsl #24
     3e0:      	movi.4s	v26, #0x3f, lsl #24
     3e4:      	mov.16b	v17, v31
     3e8:      	ldr	q16, [sp, #0x190]
     3ec:      	fcmge.4s	v7, v16, v4
     3f0:      	fmla.4s	v25, v21, v20
     3f4:      	fcmge.4s	v16, v16, v5
     3f8:      	and.16b	v18, v16, v5
     3fc:      	and.16b	v20, v7, v4
     400:      	ldr	q28, [sp, #0x160]
     404:      	fcmge.4s	v27, v20, v28
     408:      	fcmge.4s	v28, v18, v28
     40c:      	fcmge.4s	v29, v11, v18
     410:      	and.16b	v28, v28, v29
     414:      	fcmge.4s	v29, v11, v20
     418:      	and.16b	v27, v27, v29
     41c:      	and.16b	v27, v27, v20
     420:      	and.16b	v28, v28, v18
     424:      	fmla.4s	v6, v21, v23
     428:      	ldr	q29, [sp, #0x150]
     42c:      	fmul.4s	v23, v28, v29
     430:      	fmul.4s	v29, v27, v29
     434:      	movi.4s	v9, #0x4b, lsl #24
     438:      	fadd.4s	v29, v29, v9
     43c:      	fadd.4s	v23, v23, v9
     440:      	movi.4s	v9, #0xcb, lsl #24
     444:      	fadd.4s	v23, v23, v9
     448:      	fmla.4s	v17, v21, v25
     44c:      	fadd.4s	v21, v29, v9
     450:      	fcvtzs.4s	v21, v21
     454:      	fcvtzs.4s	v23, v23
     458:      	scvtf.4s	v25, v23
     45c:      	scvtf.4s	v29, v21
     460:      	fmla.4s	v26, v19, v24
     464:      	ldr	q9, [sp, #0x140]
     468:      	fmul.4s	v24, v25, v9
     46c:      	fadd.4s	v24, v28, v24
     470:      	fmul.4s	v28, v29, v9
     474:      	fadd.4s	v27, v27, v28
     478:      	mov.16b	v28, v31
     47c:      	fmla.4s	v28, v19, v22
     480:      	fmul.4s	v22, v29, v8
     484:      	ldr	q29, [sp, #0x180]
     488:      	fadd.4s	v22, v27, v22
     48c:      	fmul.4s	v25, v25, v8
     490:      	fadd.4s	v24, v24, v25
     494:      	mov.16b	v25, v31
     498:      	fmla.4s	v25, v19, v26
     49c:      	ldr	q26, [sp, #0xa0]
     4a0:      	fmul.4s	v19, v24, v26
     4a4:      	fmul.4s	v26, v22, v26
     4a8:      	fadd.4s	v26, v26, v10
     4ac:      	fadd.4s	v19, v19, v10
     4b0:      	fmul.4s	v19, v24, v19
     4b4:      	fmul.4s	v27, v4, v28
     4b8:      	fmul.4s	v26, v22, v26
     4bc:      	fadd.4s	v26, v26, v12
     4c0:      	fadd.4s	v19, v19, v12
     4c4:      	fmul.4s	v19, v24, v19
     4c8:      	fmul.4s	v26, v22, v26
     4cc:      	fadd.4s	v26, v26, v15
     4d0:      	fadd.4s	v19, v19, v15
     4d4:      	fmul.4s	v19, v24, v19
     4d8:      	fmul.4s	v26, v22, v26
     4dc:      	fadd.4s	v26, v26, v29
     4e0:      	fadd.4s	v28, v19, v29
     4e4:      	fdiv.4s	v19, v27, v25
     4e8:      	fmul.4s	v25, v24, v28
     4ec:      	fmul.4s	v26, v22, v26
     4f0:      	movi.4s	v28, #0x3f, lsl #24
     4f4:      	fadd.4s	v26, v26, v28
     4f8:      	fadd.4s	v25, v25, v28
     4fc:      	fmul.4s	v27, v24, v24
     500:      	fmul.4s	v25, v27, v25
     504:      	fmul.4s	v27, v22, v22
     508:      	fmul.4s	v26, v27, v26
     50c:      	fadd.4s	v22, v22, v26
     510:      	fadd.4s	v24, v24, v25
     514:      	movi.2d	v27, #0xffffffffffffffff
     518:      	add.4s	v21, v21, v27
     51c:      	fadd.4s	v22, v22, v31
     520:      	sshr.4s	v25, v21, #0x1
     524:      	shl.4s	v26, v25, #0x17
     528:      	add.4s	v26, v26, v31
     52c:      	fmul.4s	v22, v22, v26
     530:      	add.4s	v23, v23, v27
     534:      	fadd.4s	v24, v24, v31
     538:      	sub.4s	v21, v21, v25
     53c:      	sshr.4s	v25, v23, #0x1
     540:      	sub.4s	v23, v23, v25
     544:      	shl.4s	v25, v25, #0x17
     548:      	add.4s	v25, v25, v31
     54c:      	fmul.4s	v24, v24, v25
     550:      	shl.4s	v23, v23, #0x17
     554:      	add.4s	v23, v23, v31
     558:      	fmul.4s	v23, v24, v23
     55c:      	shl.4s	v21, v21, #0x17
     560:      	add.4s	v21, v21, v31
     564:      	fmul.4s	v21, v22, v21
     568:      	fcmgt.4s	v20, v20, v11
     56c:      	bsl.16b	v20, v14, v21
     570:      	fmul.4s	v6, v5, v6
     574:      	fcmgt.4s	v18, v18, v11
     578:      	bsl.16b	v18, v14, v23
     57c:      	fdiv.4s	v6, v6, v17
     580:      	fdiv.4s	v17, v30, v18
     584:      	fsub.4s	v21, v18, v17
     588:      	fadd.4s	v17, v18, v17
     58c:      	fdiv.4s	v17, v21, v17
     590:      	bsl.16b	v16, v17, v31
     594:      	fcmge.4s	v5, v31, v5
     598:      	bsl.16b	v5, v6, v16
     59c:      	fdiv.4s	v6, v30, v20
     5a0:      	fsub.4s	v16, v20, v6
     5a4:      	fadd.4s	v6, v20, v6
     5a8:      	fdiv.4s	v6, v16, v6
     5ac:      	bif.16b	v6, v31, v7
     5b0:      	fcmge.4s	v4, v31, v4
     5b4:      	bsl.16b	v4, v19, v6
     5b8:      	mvni.4s	v6, #0x80, lsl #24
     5bc:      	bif.16b	v4, v3, v6
     5c0:      	fcmeq.4s	v3, v3, v3
     5c4:      	fadd.4s	v4, v4, v31
     5c8:      	bsl.16b	v3, v4, v13
     5cc:      	mov.16b	v4, v6
     5d0:      	bsl.16b	v4, v5, v2
     5d4:      	fcmeq.4s	v2, v2, v2
     5d8:      	fadd.4s	v4, v4, v31
     5dc:      	bsl.16b	v2, v4, v13
     5e0:      	fmul.4s	v1, v1, v28
     5e4:      	fmul.4s	v1, v1, v2
     5e8:      	fmul.4s	v0, v0, v28
     5ec:      	fmul.4s	v0, v0, v3
     5f0:      	add	x9, x26, x8
     5f4:      	ldp	q3, q2, [x9]
     5f8:      	fadd.4s	v0, v3, v0
     5fc:      	fadd.4s	v1, v2, v1
     600:      	add	x9, x22, x8
     604:      	stp	q0, q1, [x9]
     608:      	add	x8, x8, #0x20
     60c:      	cmp	x8, #0xc00
     610:      	b.ne	0x2f8 <ltmp0+0x2f8>
     614:      	b	0x2c4 <ltmp0+0x2c4>
     618:      	ldr	x8, [sp, #0x58]
     61c:      	add	w8, w21, w8
     620:      	and	x8, x8, #0x1fffffff
     624:      	add	x8, x8, x8, lsl #1
     628:      	lsl	x20, x8, #10
     62c:      	add	x0, sp, #0xe20
     630:      	add	x1, x23, x20
     634:      	mov	w2, #0xc00              ; =3072
     638:      	bl	0x638 <ltmp0+0x638>
     63c:      	add	x0, sp, #0x220
     640:      	add	x1, x24, x20
     644:      	mov	w2, #0xc00              ; =3072
     648:      	bl	0x648 <ltmp0+0x648>
     64c:      	ldr	q29, [sp, #0x180]
     650:      	ldp	q31, q11, [sp, #0x60]
     654:      	mov	x8, #0x0                ; =0
     658:      	ldp	q10, q8, [sp, #0xe0]
     65c:      	ldp	q14, q12, [sp, #0xc0]
     660:      	ldp	q15, q9, [sp, #0x90]
     664:      	ldr	q13, [sp, #0x80]
     668:      	add	x9, x28, x8
     66c:      	ldp	q0, q1, [x9]
     670:      	ldp	q5, q3, [sp, #0x1f0]
     674:      	fmul.4s	v2, v0, v3
     678:      	fmul.4s	v3, v1, v3
     67c:      	fmul.4s	v3, v1, v3
     680:      	fmul.4s	v2, v0, v2
     684:      	fmul.4s	v2, v0, v2
     688:      	fmul.4s	v3, v1, v3
     68c:      	fadd.4s	v4, v1, v3
     690:      	fadd.4s	v2, v0, v2
     694:      	fmul.4s	v3, v2, v5
     698:      	fmul.4s	v2, v4, v5
     69c:      	fabs.4s	v5, v2
     6a0:      	fabs.4s	v4, v3
     6a4:      	fmul.4s	v19, v3, v3
     6a8:      	fmul.4s	v21, v2, v2
     6ac:      	ldp	q7, q16, [sp, #0x1d0]
     6b0:      	mov.16b	v6, v7
     6b4:      	fmla.4s	v6, v19, v16
     6b8:      	fmla.4s	v7, v21, v16
     6bc:      	ldr	q17, [sp, #0x1c0]
     6c0:      	mov.16b	v16, v17
     6c4:      	fmla.4s	v16, v19, v6
     6c8:      	mov.16b	v6, v17
     6cc:      	fmla.4s	v6, v21, v7
     6d0:      	ldp	q18, q17, [sp, #0x1a0]
     6d4:      	mov.16b	v7, v17
     6d8:      	fmla.4s	v7, v19, v16
     6dc:      	mov.16b	v16, v17
     6e0:      	fmla.4s	v16, v21, v6
     6e4:      	mov.16b	v17, v18
     6e8:      	mov.16b	v22, v29
     6ec:      	mov.16b	v23, v29
     6f0:      	mov.16b	v6, v31
     6f4:      	fmla.4s	v17, v19, v7
     6f8:      	ldr	q20, [sp, #0x170]
     6fc:      	mov.16b	v7, v20
     700:      	fmla.4s	v7, v21, v8
     704:      	fmla.4s	v20, v19, v8
     708:      	mov.16b	v24, v10
     70c:      	fmla.4s	v18, v21, v16
     710:      	fmla.4s	v24, v21, v7
     714:      	mov.16b	v7, v10
     718:      	fmla.4s	v7, v19, v20
     71c:      	mov.16b	v16, v12
     720:      	fmla.4s	v16, v21, v24
     724:      	fmla.4s	v22, v19, v17
     728:      	mov.16b	v17, v12
     72c:      	fmla.4s	v17, v19, v7
     730:      	mov.16b	v20, v14
     734:      	fmla.4s	v20, v21, v16
     738:      	mov.16b	v24, v14
     73c:      	fmla.4s	v23, v21, v18
     740:      	fmla.4s	v24, v19, v17
     744:      	movi.4s	v25, #0x3f, lsl #24
     748:      	movi.4s	v26, #0x3f, lsl #24
     74c:      	mov.16b	v17, v31
     750:      	ldr	q16, [sp, #0x190]
     754:      	fcmge.4s	v7, v16, v4
     758:      	fmla.4s	v25, v21, v20
     75c:      	fcmge.4s	v16, v16, v5
     760:      	and.16b	v18, v16, v5
     764:      	and.16b	v20, v7, v4
     768:      	ldr	q28, [sp, #0x160]
     76c:      	fcmge.4s	v27, v20, v28
     770:      	fcmge.4s	v28, v18, v28
     774:      	fcmge.4s	v29, v11, v18
     778:      	and.16b	v28, v28, v29
     77c:      	fcmge.4s	v29, v11, v20
     780:      	and.16b	v27, v27, v29
     784:      	and.16b	v27, v27, v20
     788:      	and.16b	v28, v28, v18
     78c:      	fmla.4s	v6, v21, v23
     790:      	ldr	q29, [sp, #0x150]
     794:      	fmul.4s	v23, v28, v29
     798:      	fmul.4s	v29, v27, v29
     79c:      	movi.4s	v30, #0x4b, lsl #24
     7a0:      	fadd.4s	v29, v29, v30
     7a4:      	fadd.4s	v23, v23, v30
     7a8:      	movi.4s	v30, #0xcb, lsl #24
     7ac:      	fadd.4s	v23, v23, v30
     7b0:      	fmla.4s	v17, v21, v25
     7b4:      	fadd.4s	v21, v29, v30
     7b8:      	fcvtzs.4s	v21, v21
     7bc:      	fcvtzs.4s	v23, v23
     7c0:      	scvtf.4s	v25, v23
     7c4:      	scvtf.4s	v29, v21
     7c8:      	fmla.4s	v26, v19, v24
     7cc:      	ldr	q30, [sp, #0x140]
     7d0:      	fmul.4s	v24, v25, v30
     7d4:      	fadd.4s	v24, v28, v24
     7d8:      	fmul.4s	v28, v29, v30
     7dc:      	fadd.4s	v27, v27, v28
     7e0:      	mov.16b	v28, v31
     7e4:      	fmla.4s	v28, v19, v22
     7e8:      	ldr	q30, [sp, #0xb0]
     7ec:      	fmul.4s	v22, v29, v30
     7f0:      	ldr	q29, [sp, #0x180]
     7f4:      	fadd.4s	v22, v27, v22
     7f8:      	fmul.4s	v25, v25, v30
     7fc:      	fadd.4s	v24, v24, v25
     800:      	mov.16b	v25, v31
     804:      	fmla.4s	v25, v19, v26
     808:      	fmul.4s	v19, v24, v9
     80c:      	fmul.4s	v26, v22, v9
     810:      	fadd.4s	v26, v26, v13
     814:      	fadd.4s	v19, v19, v13
     818:      	fmul.4s	v19, v24, v19
     81c:      	fmul.4s	v27, v4, v28
     820:      	fmul.4s	v26, v22, v26
     824:      	ldr	q28, [sp, #0x100]
     828:      	fadd.4s	v26, v26, v28
     82c:      	fadd.4s	v19, v19, v28
     830:      	fmul.4s	v19, v24, v19
     834:      	fmul.4s	v26, v22, v26
     838:      	ldr	q28, [sp, #0x130]
     83c:      	fadd.4s	v26, v26, v28
     840:      	fadd.4s	v19, v19, v28
     844:      	fmul.4s	v19, v24, v19
     848:      	fmul.4s	v26, v22, v26
     84c:      	fadd.4s	v26, v26, v29
     850:      	fadd.4s	v28, v19, v29
     854:      	fdiv.4s	v19, v27, v25
     858:      	fmul.4s	v25, v24, v28
     85c:      	fmul.4s	v26, v22, v26
     860:      	movi.4s	v28, #0x3f, lsl #24
     864:      	fadd.4s	v26, v26, v28
     868:      	fadd.4s	v25, v25, v28
     86c:      	fmul.4s	v27, v24, v24
     870:      	fmul.4s	v25, v27, v25
     874:      	fmul.4s	v27, v22, v22
     878:      	fmul.4s	v26, v27, v26
     87c:      	fadd.4s	v22, v22, v26
     880:      	fadd.4s	v24, v24, v25
     884:      	movi.2d	v27, #0xffffffffffffffff
     888:      	add.4s	v21, v21, v27
     88c:      	fadd.4s	v22, v22, v31
     890:      	sshr.4s	v25, v21, #0x1
     894:      	shl.4s	v26, v25, #0x17
     898:      	add.4s	v26, v26, v31
     89c:      	fmul.4s	v22, v22, v26
     8a0:      	add.4s	v23, v23, v27
     8a4:      	fadd.4s	v24, v24, v31
     8a8:      	sub.4s	v21, v21, v25
     8ac:      	sshr.4s	v25, v23, #0x1
     8b0:      	sub.4s	v23, v23, v25
     8b4:      	shl.4s	v25, v25, #0x17
     8b8:      	add.4s	v25, v25, v31
     8bc:      	fmul.4s	v24, v24, v25
     8c0:      	shl.4s	v23, v23, #0x17
     8c4:      	add.4s	v23, v23, v31
     8c8:      	fmul.4s	v23, v24, v23
     8cc:      	shl.4s	v21, v21, #0x17
     8d0:      	add.4s	v21, v21, v31
     8d4:      	fmul.4s	v21, v22, v21
     8d8:      	fcmgt.4s	v20, v20, v11
     8dc:      	bsl.16b	v20, v15, v21
     8e0:      	fmul.4s	v6, v5, v6
     8e4:      	fcmgt.4s	v18, v18, v11
     8e8:      	bsl.16b	v18, v15, v23
     8ec:      	fdiv.4s	v6, v6, v17
     8f0:      	ldr	q22, [sp, #0x120]
     8f4:      	fdiv.4s	v17, v22, v18
     8f8:      	fsub.4s	v21, v18, v17
     8fc:      	fadd.4s	v17, v18, v17
     900:      	fdiv.4s	v17, v21, v17
     904:      	bsl.16b	v16, v17, v31
     908:      	fcmge.4s	v5, v31, v5
     90c:      	bsl.16b	v5, v6, v16
     910:      	fdiv.4s	v6, v22, v20
     914:      	fsub.4s	v16, v20, v6
     918:      	fadd.4s	v6, v20, v6
     91c:      	fdiv.4s	v6, v16, v6
     920:      	bif.16b	v6, v31, v7
     924:      	fcmge.4s	v4, v31, v4
     928:      	bsl.16b	v4, v19, v6
     92c:      	mvni.4s	v6, #0x80, lsl #24
     930:      	bif.16b	v4, v3, v6
     934:      	fcmeq.4s	v3, v3, v3
     938:      	fadd.4s	v4, v4, v31
     93c:      	ldr	q7, [sp, #0x110]
     940:      	bsl.16b	v3, v4, v7
     944:      	mov.16b	v4, v6
     948:      	bsl.16b	v4, v5, v2
     94c:      	fcmeq.4s	v2, v2, v2
     950:      	fadd.4s	v4, v4, v31
     954:      	bsl.16b	v2, v4, v7
     958:      	fmul.4s	v1, v1, v28
     95c:      	fmul.4s	v1, v1, v2
     960:      	fmul.4s	v0, v0, v28
     964:      	fmul.4s	v0, v0, v3
     968:      	add	x9, x19, x8
     96c:      	ldp	q3, q2, [x9]
     970:      	fadd.4s	v0, v3, v0
     974:      	fadd.4s	v1, v2, v1
     978:      	add	x9, x22, x8
     97c:      	stp	q0, q1, [x9]
     980:      	add	x8, x8, #0x20
     984:      	cmp	x8, #0xc00
     988:      	b.ne	0x668 <ltmp0+0x668>
     98c:      	b	0x2c4 <ltmp0+0x2c4>
     990:      	mvni.4s	v8, #0x80, lsl #24
     994:      	lsr	x25, x8, #3
     998:      	str	x8, [sp, #0x20]
     99c:      	cmp	x8, #0x8
     9a0:      	b.hs	0xf90 <ltmp0+0xf90>
     9a4:      	ldr	x8, [sp, #0x20]
     9a8:      	and	w8, w8, #0x7
     9ac:      	cbz	w8, 0x1bc <ltmp0+0x1bc>
     9b0:      	dup.4s	v1, w8
     9b4:      	adrp	x8, 0x0 <ltmp0>
     9b8:      	ldr	q2, [x8]
     9bc:      	adrp	x8, 0x0 <ltmp0>
     9c0:      	ldr	q0, [x8]
     9c4:      	cmhi.4s	v0, v1, v0
     9c8:      	cmhi.4s	v1, v1, v2
     9cc:      	uzp1.8h	v2, v1, v0
     9d0:      	umaxv.8h	h3, v2
     9d4:      	fmov	w8, s3
     9d8:      	ldp	q26, q22, [sp, #0xe0]
     9dc:      	ldp	q10, q25, [sp, #0x160]
     9e0:      	ldp	q9, q28, [sp, #0xc0]
     9e4:      	ldp	q11, q30, [sp, #0x70]
     9e8:      	ldp	q13, q12, [sp, #0x140]
     9ec:      	ldp	q15, q14, [sp, #0xa0]
     9f0:      	movi.2d	v24, #0xffffffffffffffff
     9f4:      	ldr	q27, [sp, #0x100]
     9f8:      	adrp	x16, 0x0 <ltmp0>
     9fc:      	ldr	x11, [sp, #0x48]
     a00:      	tbz	w8, #0x0, 0x1bc <ltmp0+0x1bc>
     a04:      	ldr	x8, [sp, #0x18]
     a08:      	ldr	x12, [x8]
     a0c:      	ldr	x10, [x8, #0x10]
     a10:      	ldr	x9, [x8, #0x30]
     a14:      	ubfiz	w8, w11, #2, #27
     a18:      	orr	w8, w8, w25
     a1c:      	fmov	s3, w8
     a20:      	and.16b	v3, v1, v3
     a24:      	subs	x8, x12, x9
     a28:      	mov	w14, #0xbff             ; =3071
     a2c:      	movk	w14, #0x6, lsl #16
     a30:      	ccmp	x8, x14, #0x0, hs
     a34:      	cset	w8, hi
     a38:      	subs	x11, x9, x12
     a3c:      	ccmp	x11, x14, #0x0, hs
     a40:      	csinc	w13, w8, wzr, ls
     a44:      	subs	x8, x10, x9
     a48:      	ccmp	x8, x14, #0x0, hs
     a4c:      	cset	w8, hi
     a50:      	subs	x11, x9, x10
     a54:      	ccmp	x11, x14, #0x0, hs
     a58:      	csinc	w8, w8, wzr, ls
     a5c:      	fmov	w11, s3
     a60:      	mov	w14, #0xc00             ; =3072
     a64:      	umull	x11, w11, w14
     a68:      	cmp	w13, #0x1
     a6c:      	b.ne	0x16dc <ltmp0+0x16dc>
     a70:      	cbz	w8, 0x16dc <ltmp0+0x16dc>
     a74:      	mov	x8, #0x0                ; =0
     a78:      	add	x9, x9, x11
     a7c:      	add	x10, x10, x11
     a80:      	add	x11, x12, x11
     a84:      	b	0xa94 <ltmp0+0xa94>
     a88:      	add	x8, x8, #0x20
     a8c:      	cmp	x8, #0xc00
     a90:      	b.eq	0x1bc <ltmp0+0x1bc>
     a94:      	ldr	q3, [x16]
     a98:      	and.16b	v3, v2, v3
     a9c:      	addv.8h	h4, v3
     aa0:      	fmov	w13, s4
     aa4:      	add	x12, x11, x8
     aa8:      	movi.2d	v5, #0000000000000000
     aac:      	movi.2d	v3, #0000000000000000
     ab0:      	tbnz	w13, #0x0, 0xe64 <ltmp0+0xe64>
     ab4:      	and	w13, w13, #0xff
     ab8:      	tbnz	w13, #0x1, 0xe70 <ltmp0+0xe70>
     abc:      	tbnz	w13, #0x2, 0xe7c <ltmp0+0xe7c>
     ac0:      	tbnz	w13, #0x3, 0xe88 <ltmp0+0xe88>
     ac4:      	tbnz	w13, #0x4, 0xe94 <ltmp0+0xe94>
     ac8:      	tbnz	w13, #0x5, 0xea0 <ltmp0+0xea0>
     acc:      	tbnz	w13, #0x6, 0xeac <ltmp0+0xeac>
     ad0:      	tbnz	w13, #0x7, 0xeb8 <ltmp0+0xeb8>
     ad4:      	fmov	w13, s4
     ad8:      	add	x12, x10, x8
     adc:      	movi.2d	v7, #0000000000000000
     ae0:      	movi.2d	v6, #0000000000000000
     ae4:      	tbnz	w13, #0x0, 0xed4 <ltmp0+0xed4>
     ae8:      	and	w13, w13, #0xff
     aec:      	tbnz	w13, #0x1, 0xee0 <ltmp0+0xee0>
     af0:      	tbnz	w13, #0x2, 0xeec <ltmp0+0xeec>
     af4:      	tbnz	w13, #0x3, 0xef8 <ltmp0+0xef8>
     af8:      	tbnz	w13, #0x4, 0xf04 <ltmp0+0xf04>
     afc:      	tbnz	w13, #0x5, 0xf10 <ltmp0+0xf10>
     b00:      	tbnz	w13, #0x6, 0xf1c <ltmp0+0xf1c>
     b04:      	movi.2d	v27, #0xffffffffffffffff
     b08:      	tbz	w13, #0x7, 0xb14 <ltmp0+0xb14>
     b0c:      	add	x12, x12, #0x1c
     b10:      	ld1.s	{ v6 }[3], [x12]
     b14:      	ldp	q17, q16, [sp, #0x1f0]
     b18:      	fmul.4s	v16, v5, v16
     b1c:      	fmul.4s	v16, v5, v16
     b20:      	fmul.4s	v16, v5, v16
     b24:      	fadd.4s	v16, v5, v16
     b28:      	fmul.4s	v16, v16, v17
     b2c:      	and.16b	v16, v1, v16
     b30:      	fabs.4s	v17, v16
     b34:      	fmul.4s	v18, v16, v16
     b38:      	ldp	q19, q20, [sp, #0x1d0]
     b3c:      	fmla.4s	v19, v18, v20
     b40:      	ldr	q20, [sp, #0x1c0]
     b44:      	fmla.4s	v20, v18, v19
     b48:      	ldr	q19, [sp, #0x1b0]
     b4c:      	fmla.4s	v19, v18, v20
     b50:      	ldr	q20, [sp, #0x1a0]
     b54:      	fmla.4s	v20, v18, v19
     b58:      	mov.16b	v19, v29
     b5c:      	fmla.4s	v19, v18, v20
     b60:      	mov.16b	v20, v31
     b64:      	fmla.4s	v20, v18, v19
     b68:      	fmul.4s	v19, v17, v20
     b6c:      	mov.16b	v20, v25
     b70:      	fmla.4s	v20, v18, v22
     b74:      	mov.16b	v21, v26
     b78:      	fmla.4s	v21, v18, v20
     b7c:      	mov.16b	v20, v28
     b80:      	fmla.4s	v20, v18, v21
     b84:      	mov.16b	v21, v9
     b88:      	fmla.4s	v21, v18, v20
     b8c:      	movi.4s	v20, #0x3f, lsl #24
     b90:      	fmla.4s	v20, v18, v21
     b94:      	mov.16b	v21, v31
     b98:      	fmla.4s	v21, v18, v20
     b9c:      	fdiv.4s	v18, v19, v21
     ba0:      	ldr	q19, [sp, #0x190]
     ba4:      	fcmge.4s	v19, v19, v17
     ba8:      	and.16b	v20, v19, v17
     bac:      	fcmge.4s	v21, v20, v10
     bb0:      	fcmge.4s	v22, v11, v20
     bb4:      	and.16b	v21, v21, v22
     bb8:      	and.16b	v21, v21, v20
     bbc:      	fmul.4s	v22, v21, v12
     bc0:      	movi.4s	v23, #0x4b, lsl #24
     bc4:      	fadd.4s	v22, v22, v23
     bc8:      	movi.4s	v23, #0xcb, lsl #24
     bcc:      	fadd.4s	v22, v22, v23
     bd0:      	fcvtzs.4s	v22, v22
     bd4:      	scvtf.4s	v23, v22
     bd8:      	fmul.4s	v24, v23, v13
     bdc:      	fadd.4s	v21, v21, v24
     be0:      	fmul.4s	v23, v23, v14
     be4:      	fadd.4s	v21, v21, v23
     be8:      	fmul.4s	v23, v21, v15
     bec:      	fadd.4s	v23, v23, v30
     bf0:      	fmul.4s	v23, v21, v23
     bf4:      	ldr	q24, [sp, #0x100]
     bf8:      	fadd.4s	v23, v23, v24
     bfc:      	fmul.4s	v23, v21, v23
     c00:      	ldr	q24, [sp, #0x130]
     c04:      	fadd.4s	v23, v23, v24
     c08:      	fmul.4s	v23, v21, v23
     c0c:      	fadd.4s	v23, v23, v29
     c10:      	fmul.4s	v23, v21, v23
     c14:      	movi.4s	v30, #0x3f, lsl #24
     c18:      	fadd.4s	v23, v23, v30
     c1c:      	fmul.4s	v24, v21, v21
     c20:      	fmul.4s	v23, v24, v23
     c24:      	fadd.4s	v21, v21, v23
     c28:      	fadd.4s	v21, v21, v31
     c2c:      	add.4s	v22, v22, v27
     c30:      	sshr.4s	v23, v22, #0x1
     c34:      	shl.4s	v24, v23, #0x17
     c38:      	add.4s	v24, v24, v31
     c3c:      	fmul.4s	v21, v21, v24
     c40:      	sub.4s	v22, v22, v23
     c44:      	shl.4s	v22, v22, #0x17
     c48:      	add.4s	v22, v22, v31
     c4c:      	fmul.4s	v21, v21, v22
     c50:      	fcmgt.4s	v20, v20, v11
     c54:      	ldr	q22, [sp, #0x90]
     c58:      	bsl.16b	v20, v22, v21
     c5c:      	ldr	q21, [sp, #0x120]
     c60:      	fdiv.4s	v21, v21, v20
     c64:      	fsub.4s	v22, v20, v21
     c68:      	fadd.4s	v20, v20, v21
     c6c:      	fdiv.4s	v20, v22, v20
     c70:      	bsl.16b	v19, v20, v31
     c74:      	fcmge.4s	v17, v31, v17
     c78:      	bsl.16b	v17, v18, v19
     c7c:      	bif.16b	v17, v16, v8
     c80:      	fcmeq.4s	v16, v16, v16
     c84:      	fadd.4s	v17, v17, v31
     c88:      	ldr	q18, [sp, #0x110]
     c8c:      	bsl.16b	v16, v17, v18
     c90:      	fmul.4s	v5, v5, v30
     c94:      	fmul.4s	v5, v5, v16
     c98:      	fmov	w13, s4
     c9c:      	fadd.4s	v4, v7, v5
     ca0:      	add	x12, x9, x8
     ca4:      	tbnz	w13, #0x0, 0xf30 <ltmp0+0xf30>
     ca8:      	and	w13, w13, #0xff
     cac:      	tbnz	w13, #0x1, 0xf3c <ltmp0+0xf3c>
     cb0:      	ldp	q22, q23, [sp, #0xf0]
     cb4:      	movi.2d	v24, #0xffffffffffffffff
     cb8:      	ldr	q30, [sp, #0x80]
     cbc:      	tbnz	w13, #0x2, 0xf54 <ltmp0+0xf54>
     cc0:      	tbz	w13, #0x3, 0xccc <ltmp0+0xccc>
     cc4:      	add	x14, x12, #0xc
     cc8:      	st1.s	{ v4 }[3], [x14]
     ccc:      	ldp	q5, q4, [sp, #0x1f0]
     cd0:      	fmul.4s	v4, v3, v4
     cd4:      	fmul.4s	v4, v3, v4
     cd8:      	fmul.4s	v4, v3, v4
     cdc:      	fadd.4s	v4, v3, v4
     ce0:      	fmul.4s	v4, v4, v5
     ce4:      	and.16b	v4, v0, v4
     ce8:      	fabs.4s	v5, v4
     cec:      	fmul.4s	v7, v4, v4
     cf0:      	ldp	q16, q17, [sp, #0x1d0]
     cf4:      	fmla.4s	v16, v7, v17
     cf8:      	ldr	q17, [sp, #0x1c0]
     cfc:      	fmla.4s	v17, v7, v16
     d00:      	ldr	q16, [sp, #0x1b0]
     d04:      	fmla.4s	v16, v7, v17
     d08:      	ldr	q17, [sp, #0x1a0]
     d0c:      	fmla.4s	v17, v7, v16
     d10:      	mov.16b	v16, v29
     d14:      	fmla.4s	v16, v7, v17
     d18:      	mov.16b	v17, v31
     d1c:      	fmla.4s	v17, v7, v16
     d20:      	fmul.4s	v16, v5, v17
     d24:      	mov.16b	v17, v25
     d28:      	fmla.4s	v17, v7, v22
     d2c:      	mov.16b	v18, v26
     d30:      	fmla.4s	v18, v7, v17
     d34:      	mov.16b	v17, v28
     d38:      	fmla.4s	v17, v7, v18
     d3c:      	mov.16b	v18, v9
     d40:      	fmla.4s	v18, v7, v17
     d44:      	movi.4s	v17, #0x3f, lsl #24
     d48:      	fmla.4s	v17, v7, v18
     d4c:      	mov.16b	v18, v31
     d50:      	fmla.4s	v18, v7, v17
     d54:      	fdiv.4s	v7, v16, v18
     d58:      	ldr	q16, [sp, #0x190]
     d5c:      	fcmge.4s	v16, v16, v5
     d60:      	and.16b	v17, v16, v5
     d64:      	fcmge.4s	v18, v17, v10
     d68:      	fcmge.4s	v19, v11, v17
     d6c:      	and.16b	v18, v18, v19
     d70:      	and.16b	v18, v18, v17
     d74:      	fmul.4s	v19, v18, v12
     d78:      	movi.4s	v20, #0x4b, lsl #24
     d7c:      	fadd.4s	v19, v19, v20
     d80:      	movi.4s	v20, #0xcb, lsl #24
     d84:      	fadd.4s	v19, v19, v20
     d88:      	fcvtzs.4s	v19, v19
     d8c:      	scvtf.4s	v20, v19
     d90:      	fmul.4s	v21, v20, v13
     d94:      	fadd.4s	v18, v18, v21
     d98:      	fmul.4s	v20, v20, v14
     d9c:      	fadd.4s	v18, v18, v20
     da0:      	fmul.4s	v20, v18, v15
     da4:      	fadd.4s	v20, v20, v30
     da8:      	fmul.4s	v20, v18, v20
     dac:      	fadd.4s	v20, v20, v23
     db0:      	fmul.4s	v20, v18, v20
     db4:      	ldr	q21, [sp, #0x130]
     db8:      	fadd.4s	v20, v20, v21
     dbc:      	fmul.4s	v20, v18, v20
     dc0:      	fadd.4s	v20, v20, v29
     dc4:      	fmul.4s	v20, v18, v20
     dc8:      	movi.4s	v23, #0x3f, lsl #24
     dcc:      	fadd.4s	v20, v20, v23
     dd0:      	fmul.4s	v21, v18, v18
     dd4:      	fmul.4s	v20, v21, v20
     dd8:      	fadd.4s	v18, v18, v20
     ddc:      	fadd.4s	v18, v18, v31
     de0:      	add.4s	v19, v19, v24
     de4:      	sshr.4s	v20, v19, #0x1
     de8:      	shl.4s	v21, v20, #0x17
     dec:      	add.4s	v21, v21, v31
     df0:      	fmul.4s	v18, v18, v21
     df4:      	sub.4s	v19, v19, v20
     df8:      	shl.4s	v19, v19, #0x17
     dfc:      	add.4s	v19, v19, v31
     e00:      	fmul.4s	v18, v18, v19
     e04:      	fcmgt.4s	v17, v17, v11
     e08:      	ldr	q19, [sp, #0x90]
     e0c:      	bsl.16b	v17, v19, v18
     e10:      	ldr	q18, [sp, #0x120]
     e14:      	fdiv.4s	v18, v18, v17
     e18:      	fsub.4s	v19, v17, v18
     e1c:      	fadd.4s	v17, v17, v18
     e20:      	fdiv.4s	v17, v19, v17
     e24:      	bsl.16b	v16, v17, v31
     e28:      	fcmge.4s	v5, v31, v5
     e2c:      	bsl.16b	v5, v7, v16
     e30:      	bif.16b	v5, v4, v8
     e34:      	fcmeq.4s	v4, v4, v4
     e38:      	fadd.4s	v5, v5, v31
     e3c:      	ldr	q7, [sp, #0x110]
     e40:      	bsl.16b	v4, v5, v7
     e44:      	fmul.4s	v3, v3, v23
     e48:      	fmul.4s	v3, v3, v4
     e4c:      	fadd.4s	v3, v6, v3
     e50:      	tbnz	w13, #0x4, 0xf64 <ltmp0+0xf64>
     e54:      	tbnz	w13, #0x5, 0xf6c <ltmp0+0xf6c>
     e58:      	tbnz	w13, #0x6, 0xf78 <ltmp0+0xf78>
     e5c:      	tbz	w13, #0x7, 0xa88 <ltmp0+0xa88>
     e60:      	b	0xf84 <ltmp0+0xf84>
     e64:      	ldr	s5, [x12]
     e68:      	and	w13, w13, #0xff
     e6c:      	tbz	w13, #0x1, 0xabc <ltmp0+0xabc>
     e70:      	add	x14, x12, #0x4
     e74:      	ld1.s	{ v5 }[1], [x14]
     e78:      	tbz	w13, #0x2, 0xac0 <ltmp0+0xac0>
     e7c:      	add	x14, x12, #0x8
     e80:      	ld1.s	{ v5 }[2], [x14]
     e84:      	tbz	w13, #0x3, 0xac4 <ltmp0+0xac4>
     e88:      	add	x14, x12, #0xc
     e8c:      	ld1.s	{ v5 }[3], [x14]
     e90:      	tbz	w13, #0x4, 0xac8 <ltmp0+0xac8>
     e94:      	add	x14, x12, #0x10
     e98:      	ld1.s	{ v3 }[0], [x14]
     e9c:      	tbz	w13, #0x5, 0xacc <ltmp0+0xacc>
     ea0:      	add	x14, x12, #0x14
     ea4:      	ld1.s	{ v3 }[1], [x14]
     ea8:      	tbz	w13, #0x6, 0xad0 <ltmp0+0xad0>
     eac:      	add	x14, x12, #0x18
     eb0:      	ld1.s	{ v3 }[2], [x14]
     eb4:      	tbz	w13, #0x7, 0xad4 <ltmp0+0xad4>
     eb8:      	add	x12, x12, #0x1c
     ebc:      	ld1.s	{ v3 }[3], [x12]
     ec0:      	fmov	w13, s4
     ec4:      	add	x12, x10, x8
     ec8:      	movi.2d	v7, #0000000000000000
     ecc:      	movi.2d	v6, #0000000000000000
     ed0:      	tbz	w13, #0x0, 0xae8 <ltmp0+0xae8>
     ed4:      	ldr	s7, [x12]
     ed8:      	and	w13, w13, #0xff
     edc:      	tbz	w13, #0x1, 0xaf0 <ltmp0+0xaf0>
     ee0:      	add	x14, x12, #0x4
     ee4:      	ld1.s	{ v7 }[1], [x14]
     ee8:      	tbz	w13, #0x2, 0xaf4 <ltmp0+0xaf4>
     eec:      	add	x14, x12, #0x8
     ef0:      	ld1.s	{ v7 }[2], [x14]
     ef4:      	tbz	w13, #0x3, 0xaf8 <ltmp0+0xaf8>
     ef8:      	add	x14, x12, #0xc
     efc:      	ld1.s	{ v7 }[3], [x14]
     f00:      	tbz	w13, #0x4, 0xafc <ltmp0+0xafc>
     f04:      	add	x14, x12, #0x10
     f08:      	ld1.s	{ v6 }[0], [x14]
     f0c:      	tbz	w13, #0x5, 0xb00 <ltmp0+0xb00>
     f10:      	add	x14, x12, #0x14
     f14:      	ld1.s	{ v6 }[1], [x14]
     f18:      	tbz	w13, #0x6, 0xb04 <ltmp0+0xb04>
     f1c:      	add	x14, x12, #0x18
     f20:      	ld1.s	{ v6 }[2], [x14]
     f24:      	movi.2d	v27, #0xffffffffffffffff
     f28:      	tbnz	w13, #0x7, 0xb0c <ltmp0+0xb0c>
     f2c:      	b	0xb14 <ltmp0+0xb14>
     f30:      	str	s4, [x12]
     f34:      	and	w13, w13, #0xff
     f38:      	tbz	w13, #0x1, 0xcb0 <ltmp0+0xcb0>
     f3c:      	add	x14, x12, #0x4
     f40:      	st1.s	{ v4 }[1], [x14]
     f44:      	ldp	q22, q23, [sp, #0xf0]
     f48:      	movi.2d	v24, #0xffffffffffffffff
     f4c:      	ldr	q30, [sp, #0x80]
     f50:      	tbz	w13, #0x2, 0xcc0 <ltmp0+0xcc0>
     f54:      	add	x14, x12, #0x8
     f58:      	st1.s	{ v4 }[2], [x14]
     f5c:      	tbnz	w13, #0x3, 0xcc4 <ltmp0+0xcc4>
     f60:      	b	0xccc <ltmp0+0xccc>
     f64:      	str	s3, [x12, #0x10]
     f68:      	tbz	w13, #0x5, 0xe58 <ltmp0+0xe58>
     f6c:      	add	x14, x12, #0x14
     f70:      	st1.s	{ v3 }[1], [x14]
     f74:      	tbz	w13, #0x6, 0xe5c <ltmp0+0xe5c>
     f78:      	add	x14, x12, #0x18
     f7c:      	st1.s	{ v3 }[2], [x14]
     f80:      	tbz	w13, #0x7, 0xa88 <ltmp0+0xa88>
     f84:      	add	x12, x12, #0x1c
     f88:      	st1.s	{ v3 }[3], [x12]
     f8c:      	b	0xa88 <ltmp0+0xa88>
     f90:      	mov	x24, #0x0               ; =0
     f94:      	ldr	x8, [sp, #0x18]
     f98:      	ldr	x13, [x8]
     f9c:      	ldr	x26, [x8, #0x10]
     fa0:      	ldr	x8, [x8, #0x30]
     fa4:      	subs	x9, x13, x8
     fa8:      	mov	w12, #0xbff             ; =3071
     fac:      	movk	w12, #0x6, lsl #16
     fb0:      	ccmp	x9, x12, #0x0, hs
     fb4:      	cset	w9, hi
     fb8:      	subs	x10, x8, x13
     fbc:      	ccmp	x10, x12, #0x0, hs
     fc0:      	csinc	w9, w9, wzr, ls
     fc4:      	subs	x10, x26, x8
     fc8:      	ccmp	x10, x12, #0x0, hs
     fcc:      	cset	w10, hi
     fd0:      	subs	x11, x8, x26
     fd4:      	ccmp	x11, x12, #0x0, hs
     fd8:      	csinc	w10, w10, wzr, ls
     fdc:      	and	w27, w9, w10
     fe0:      	ldr	x9, [sp, #0x48]
     fe4:      	lsl	w10, w9, #2
     fe8:      	stp	x10, x13, [sp, #0x50]
     fec:      	and	x9, x9, #0x7ffffff
     ff0:      	add	x9, x9, x9, lsl #1
     ff4:      	lsl	x9, x9, #12
     ff8:      	add	x22, x8, x9
     ffc:      	add	x23, x26, x9
    1000:      	add	x20, x13, x9
    1004:      	b	0x1024 <ltmp0+0x1024>
    1008:      	mvni.4s	v8, #0x80, lsl #24
    100c:      	add	x24, x24, #0x1
    1010:      	add	x22, x22, #0xc00
    1014:      	add	x23, x23, #0xc00
    1018:      	add	x20, x20, #0xc00
    101c:      	cmp	x24, x25
    1020:      	b.eq	0x9a4 <ltmp0+0x9a4>
    1024:      	cbz	w27, 0x1360 <ltmp0+0x1360>
    1028:      	mov	x8, #0x0                ; =0
    102c:      	ldp	q11, q10, [sp, #0x70]
    1030:      	ldr	q8, [sp, #0xb0]
    1034:      	ldp	q12, q13, [sp, #0x100]
    1038:      	ldr	q14, [sp, #0x90]
    103c:      	ldp	q30, q15, [sp, #0x120]
    1040:      	add	x9, x20, x8
    1044:      	ldp	q0, q1, [x9]
    1048:      	ldp	q5, q3, [sp, #0x1f0]
    104c:      	fmul.4s	v2, v0, v3
    1050:      	fmul.4s	v3, v1, v3
    1054:      	fmul.4s	v3, v1, v3
    1058:      	fmul.4s	v2, v0, v2
    105c:      	fmul.4s	v2, v0, v2
    1060:      	fmul.4s	v3, v1, v3
    1064:      	fadd.4s	v4, v1, v3
    1068:      	fadd.4s	v2, v0, v2
    106c:      	fmul.4s	v3, v2, v5
    1070:      	fmul.4s	v2, v4, v5
    1074:      	fabs.4s	v5, v2
    1078:      	fabs.4s	v4, v3
    107c:      	fmul.4s	v19, v3, v3
    1080:      	fmul.4s	v21, v2, v2
    1084:      	ldp	q7, q16, [sp, #0x1d0]
    1088:      	mov.16b	v6, v7
    108c:      	fmla.4s	v6, v19, v16
    1090:      	fmla.4s	v7, v21, v16
    1094:      	ldr	q17, [sp, #0x1c0]
    1098:      	mov.16b	v16, v17
    109c:      	fmla.4s	v16, v19, v6
    10a0:      	mov.16b	v6, v17
    10a4:      	fmla.4s	v6, v21, v7
    10a8:      	ldp	q18, q17, [sp, #0x1a0]
    10ac:      	mov.16b	v7, v17
    10b0:      	fmla.4s	v7, v19, v16
    10b4:      	mov.16b	v16, v17
    10b8:      	fmla.4s	v16, v21, v6
    10bc:      	mov.16b	v17, v18
    10c0:      	mov.16b	v22, v29
    10c4:      	mov.16b	v23, v29
    10c8:      	mov.16b	v6, v31
    10cc:      	fmla.4s	v17, v19, v7
    10d0:      	ldr	q20, [sp, #0x170]
    10d4:      	mov.16b	v7, v20
    10d8:      	ldp	q25, q24, [sp, #0xe0]
    10dc:      	fmla.4s	v7, v21, v24
    10e0:      	fmla.4s	v20, v19, v24
    10e4:      	mov.16b	v24, v25
    10e8:      	fmla.4s	v18, v21, v16
    10ec:      	fmla.4s	v24, v21, v7
    10f0:      	mov.16b	v7, v25
    10f4:      	fmla.4s	v7, v19, v20
    10f8:      	ldr	q20, [sp, #0xd0]
    10fc:      	mov.16b	v16, v20
    1100:      	fmla.4s	v16, v21, v24
    1104:      	fmla.4s	v22, v19, v17
    1108:      	mov.16b	v17, v20
    110c:      	fmla.4s	v17, v19, v7
    1110:      	ldr	q24, [sp, #0xc0]
    1114:      	mov.16b	v20, v24
    1118:      	fmla.4s	v20, v21, v16
    111c:      	fmla.4s	v23, v21, v18
    1120:      	fmla.4s	v24, v19, v17
    1124:      	movi.4s	v25, #0x3f, lsl #24
    1128:      	movi.4s	v26, #0x3f, lsl #24
    112c:      	mov.16b	v17, v31
    1130:      	ldr	q16, [sp, #0x190]
    1134:      	fcmge.4s	v7, v16, v4
    1138:      	fmla.4s	v25, v21, v20
    113c:      	fcmge.4s	v16, v16, v5
    1140:      	and.16b	v18, v16, v5
    1144:      	and.16b	v20, v7, v4
    1148:      	ldr	q28, [sp, #0x160]
    114c:      	fcmge.4s	v27, v20, v28
    1150:      	fcmge.4s	v28, v18, v28
    1154:      	fcmge.4s	v29, v11, v18
    1158:      	and.16b	v28, v28, v29
    115c:      	fcmge.4s	v29, v11, v20
    1160:      	and.16b	v27, v27, v29
    1164:      	and.16b	v27, v27, v20
    1168:      	and.16b	v28, v28, v18
    116c:      	fmla.4s	v6, v21, v23
    1170:      	ldr	q29, [sp, #0x150]
    1174:      	fmul.4s	v23, v28, v29
    1178:      	fmul.4s	v29, v27, v29
    117c:      	movi.4s	v9, #0x4b, lsl #24
    1180:      	fadd.4s	v29, v29, v9
    1184:      	fadd.4s	v23, v23, v9
    1188:      	movi.4s	v9, #0xcb, lsl #24
    118c:      	fadd.4s	v23, v23, v9
    1190:      	fmla.4s	v17, v21, v25
    1194:      	fadd.4s	v21, v29, v9
    1198:      	fcvtzs.4s	v21, v21
    119c:      	fcvtzs.4s	v23, v23
    11a0:      	scvtf.4s	v25, v23
    11a4:      	scvtf.4s	v29, v21
    11a8:      	fmla.4s	v26, v19, v24
    11ac:      	ldr	q9, [sp, #0x140]
    11b0:      	fmul.4s	v24, v25, v9
    11b4:      	fadd.4s	v24, v28, v24
    11b8:      	fmul.4s	v28, v29, v9
    11bc:      	fadd.4s	v27, v27, v28
    11c0:      	mov.16b	v28, v31
    11c4:      	fmla.4s	v28, v19, v22
    11c8:      	fmul.4s	v22, v29, v8
    11cc:      	ldr	q29, [sp, #0x180]
    11d0:      	fadd.4s	v22, v27, v22
    11d4:      	fmul.4s	v25, v25, v8
    11d8:      	fadd.4s	v24, v24, v25
    11dc:      	mov.16b	v25, v31
    11e0:      	fmla.4s	v25, v19, v26
    11e4:      	ldr	q26, [sp, #0xa0]
    11e8:      	fmul.4s	v19, v24, v26
    11ec:      	fmul.4s	v26, v22, v26
    11f0:      	fadd.4s	v26, v26, v10
    11f4:      	fadd.4s	v19, v19, v10
    11f8:      	fmul.4s	v19, v24, v19
    11fc:      	fmul.4s	v27, v4, v28
    1200:      	fmul.4s	v26, v22, v26
    1204:      	fadd.4s	v26, v26, v12
    1208:      	fadd.4s	v19, v19, v12
    120c:      	fmul.4s	v19, v24, v19
    1210:      	fmul.4s	v26, v22, v26
    1214:      	fadd.4s	v26, v26, v15
    1218:      	fadd.4s	v19, v19, v15
    121c:      	fmul.4s	v19, v24, v19
    1220:      	fmul.4s	v26, v22, v26
    1224:      	fadd.4s	v26, v26, v29
    1228:      	fadd.4s	v28, v19, v29
    122c:      	fdiv.4s	v19, v27, v25
    1230:      	fmul.4s	v25, v24, v28
    1234:      	fmul.4s	v26, v22, v26
    1238:      	movi.4s	v28, #0x3f, lsl #24
    123c:      	fadd.4s	v26, v26, v28
    1240:      	fadd.4s	v25, v25, v28
    1244:      	fmul.4s	v27, v24, v24
    1248:      	fmul.4s	v25, v27, v25
    124c:      	fmul.4s	v27, v22, v22
    1250:      	fmul.4s	v26, v27, v26
    1254:      	fadd.4s	v22, v22, v26
    1258:      	fadd.4s	v24, v24, v25
    125c:      	movi.2d	v27, #0xffffffffffffffff
    1260:      	add.4s	v21, v21, v27
    1264:      	fadd.4s	v22, v22, v31
    1268:      	sshr.4s	v25, v21, #0x1
    126c:      	shl.4s	v26, v25, #0x17
    1270:      	add.4s	v26, v26, v31
    1274:      	fmul.4s	v22, v22, v26
    1278:      	add.4s	v23, v23, v27
    127c:      	fadd.4s	v24, v24, v31
    1280:      	sub.4s	v21, v21, v25
    1284:      	sshr.4s	v25, v23, #0x1
    1288:      	sub.4s	v23, v23, v25
    128c:      	shl.4s	v25, v25, #0x17
    1290:      	add.4s	v25, v25, v31
    1294:      	fmul.4s	v24, v24, v25
    1298:      	shl.4s	v23, v23, #0x17
    129c:      	add.4s	v23, v23, v31
    12a0:      	fmul.4s	v23, v24, v23
    12a4:      	shl.4s	v21, v21, #0x17
    12a8:      	add.4s	v21, v21, v31
    12ac:      	fmul.4s	v21, v22, v21
    12b0:      	fcmgt.4s	v20, v20, v11
    12b4:      	bsl.16b	v20, v14, v21
    12b8:      	fmul.4s	v6, v5, v6
    12bc:      	fcmgt.4s	v18, v18, v11
    12c0:      	bsl.16b	v18, v14, v23
    12c4:      	fdiv.4s	v6, v6, v17
    12c8:      	fdiv.4s	v17, v30, v18
    12cc:      	fsub.4s	v21, v18, v17
    12d0:      	fadd.4s	v17, v18, v17
    12d4:      	fdiv.4s	v17, v21, v17
    12d8:      	bsl.16b	v16, v17, v31
    12dc:      	fcmge.4s	v5, v31, v5
    12e0:      	bsl.16b	v5, v6, v16
    12e4:      	fdiv.4s	v6, v30, v20
    12e8:      	fsub.4s	v16, v20, v6
    12ec:      	fadd.4s	v6, v20, v6
    12f0:      	fdiv.4s	v6, v16, v6
    12f4:      	bif.16b	v6, v31, v7
    12f8:      	fcmge.4s	v4, v31, v4
    12fc:      	bsl.16b	v4, v19, v6
    1300:      	mvni.4s	v6, #0x80, lsl #24
    1304:      	bif.16b	v4, v3, v6
    1308:      	fcmeq.4s	v3, v3, v3
    130c:      	fadd.4s	v4, v4, v31
    1310:      	bsl.16b	v3, v4, v13
    1314:      	mov.16b	v4, v6
    1318:      	bsl.16b	v4, v5, v2
    131c:      	fcmeq.4s	v2, v2, v2
    1320:      	fadd.4s	v4, v4, v31
    1324:      	bsl.16b	v2, v4, v13
    1328:      	fmul.4s	v1, v1, v28
    132c:      	fmul.4s	v1, v1, v2
    1330:      	fmul.4s	v0, v0, v28
    1334:      	fmul.4s	v0, v0, v3
    1338:      	add	x9, x23, x8
    133c:      	ldp	q3, q2, [x9]
    1340:      	fadd.4s	v0, v3, v0
    1344:      	fadd.4s	v1, v2, v1
    1348:      	add	x9, x22, x8
    134c:      	stp	q0, q1, [x9]
    1350:      	add	x8, x8, #0x20
    1354:      	cmp	x8, #0xc00
    1358:      	b.ne	0x1040 <ltmp0+0x1040>
    135c:      	b	0x1008 <ltmp0+0x1008>
    1360:      	ldr	x8, [sp, #0x50]
    1364:      	add	w8, w24, w8
    1368:      	and	x8, x8, #0x1fffffff
    136c:      	add	x8, x8, x8, lsl #1
    1370:      	lsl	x21, x8, #10
    1374:      	add	x0, sp, #0xe20
    1378:      	ldr	x8, [sp, #0x58]
    137c:      	add	x1, x8, x21
    1380:      	mov	w2, #0xc00              ; =3072
    1384:      	bl	0x1384 <ltmp0+0x1384>
    1388:      	add	x0, sp, #0x220
    138c:      	add	x1, x26, x21
    1390:      	mov	w2, #0xc00              ; =3072
    1394:      	bl	0x1394 <ltmp0+0x1394>
    1398:      	ldr	q29, [sp, #0x180]
    139c:      	ldp	q31, q11, [sp, #0x60]
    13a0:      	mov	x8, #0x0                ; =0
    13a4:      	ldp	q10, q8, [sp, #0xe0]
    13a8:      	ldp	q14, q12, [sp, #0xc0]
    13ac:      	ldp	q15, q9, [sp, #0x90]
    13b0:      	ldr	q13, [sp, #0x80]
    13b4:      	add	x9, x28, x8
    13b8:      	ldp	q0, q1, [x9]
    13bc:      	ldp	q5, q3, [sp, #0x1f0]
    13c0:      	fmul.4s	v2, v0, v3
    13c4:      	fmul.4s	v3, v1, v3
    13c8:      	fmul.4s	v3, v1, v3
    13cc:      	fmul.4s	v2, v0, v2
    13d0:      	fmul.4s	v2, v0, v2
    13d4:      	fmul.4s	v3, v1, v3
    13d8:      	fadd.4s	v4, v1, v3
    13dc:      	fadd.4s	v2, v0, v2
    13e0:      	fmul.4s	v3, v2, v5
    13e4:      	fmul.4s	v2, v4, v5
    13e8:      	fabs.4s	v5, v2
    13ec:      	fabs.4s	v4, v3
    13f0:      	fmul.4s	v19, v3, v3
    13f4:      	fmul.4s	v21, v2, v2
    13f8:      	ldp	q7, q16, [sp, #0x1d0]
    13fc:      	mov.16b	v6, v7
    1400:      	fmla.4s	v6, v19, v16
    1404:      	fmla.4s	v7, v21, v16
    1408:      	ldr	q17, [sp, #0x1c0]
    140c:      	mov.16b	v16, v17
    1410:      	fmla.4s	v16, v19, v6
    1414:      	mov.16b	v6, v17
    1418:      	fmla.4s	v6, v21, v7
    141c:      	ldp	q18, q17, [sp, #0x1a0]
    1420:      	mov.16b	v7, v17
    1424:      	fmla.4s	v7, v19, v16
    1428:      	mov.16b	v16, v17
    142c:      	fmla.4s	v16, v21, v6
    1430:      	mov.16b	v17, v18
    1434:      	mov.16b	v22, v29
    1438:      	mov.16b	v23, v29
    143c:      	mov.16b	v6, v31
    1440:      	fmla.4s	v17, v19, v7
    1444:      	ldr	q20, [sp, #0x170]
    1448:      	mov.16b	v7, v20
    144c:      	fmla.4s	v7, v21, v8
    1450:      	fmla.4s	v20, v19, v8
    1454:      	mov.16b	v24, v10
    1458:      	fmla.4s	v18, v21, v16
    145c:      	fmla.4s	v24, v21, v7
    1460:      	mov.16b	v7, v10
    1464:      	fmla.4s	v7, v19, v20
    1468:      	mov.16b	v16, v12
    146c:      	fmla.4s	v16, v21, v24
    1470:      	fmla.4s	v22, v19, v17
    1474:      	mov.16b	v17, v12
    1478:      	fmla.4s	v17, v19, v7
    147c:      	mov.16b	v20, v14
    1480:      	fmla.4s	v20, v21, v16
    1484:      	mov.16b	v24, v14
    1488:      	fmla.4s	v23, v21, v18
    148c:      	fmla.4s	v24, v19, v17
    1490:      	movi.4s	v25, #0x3f, lsl #24
    1494:      	movi.4s	v26, #0x3f, lsl #24
    1498:      	mov.16b	v17, v31
    149c:      	ldr	q16, [sp, #0x190]
    14a0:      	fcmge.4s	v7, v16, v4
    14a4:      	fmla.4s	v25, v21, v20
    14a8:      	fcmge.4s	v16, v16, v5
    14ac:      	and.16b	v18, v16, v5
    14b0:      	and.16b	v20, v7, v4
    14b4:      	ldr	q28, [sp, #0x160]
    14b8:      	fcmge.4s	v27, v20, v28
    14bc:      	fcmge.4s	v28, v18, v28
    14c0:      	fcmge.4s	v29, v11, v18
    14c4:      	and.16b	v28, v28, v29
    14c8:      	fcmge.4s	v29, v11, v20
    14cc:      	and.16b	v27, v27, v29
    14d0:      	and.16b	v27, v27, v20
    14d4:      	and.16b	v28, v28, v18
    14d8:      	fmla.4s	v6, v21, v23
    14dc:      	ldr	q29, [sp, #0x150]
    14e0:      	fmul.4s	v23, v28, v29
    14e4:      	fmul.4s	v29, v27, v29
    14e8:      	movi.4s	v30, #0x4b, lsl #24
    14ec:      	fadd.4s	v29, v29, v30
    14f0:      	fadd.4s	v23, v23, v30
    14f4:      	movi.4s	v30, #0xcb, lsl #24
    14f8:      	fadd.4s	v23, v23, v30
    14fc:      	fmla.4s	v17, v21, v25
    1500:      	fadd.4s	v21, v29, v30
    1504:      	fcvtzs.4s	v21, v21
    1508:      	fcvtzs.4s	v23, v23
    150c:      	scvtf.4s	v25, v23
    1510:      	scvtf.4s	v29, v21
    1514:      	fmla.4s	v26, v19, v24
    1518:      	ldr	q30, [sp, #0x140]
    151c:      	fmul.4s	v24, v25, v30
    1520:      	fadd.4s	v24, v28, v24
    1524:      	fmul.4s	v28, v29, v30
    1528:      	fadd.4s	v27, v27, v28
    152c:      	mov.16b	v28, v31
    1530:      	fmla.4s	v28, v19, v22
    1534:      	ldr	q30, [sp, #0xb0]
    1538:      	fmul.4s	v22, v29, v30
    153c:      	ldr	q29, [sp, #0x180]
    1540:      	fadd.4s	v22, v27, v22
    1544:      	fmul.4s	v25, v25, v30
    1548:      	fadd.4s	v24, v24, v25
    154c:      	mov.16b	v25, v31
    1550:      	fmla.4s	v25, v19, v26
    1554:      	fmul.4s	v19, v24, v9
    1558:      	fmul.4s	v26, v22, v9
    155c:      	fadd.4s	v26, v26, v13
    1560:      	fadd.4s	v19, v19, v13
    1564:      	fmul.4s	v19, v24, v19
    1568:      	fmul.4s	v27, v4, v28
    156c:      	fmul.4s	v26, v22, v26
    1570:      	ldr	q28, [sp, #0x100]
    1574:      	fadd.4s	v26, v26, v28
    1578:      	fadd.4s	v19, v19, v28
    157c:      	fmul.4s	v19, v24, v19
    1580:      	fmul.4s	v26, v22, v26
    1584:      	ldr	q28, [sp, #0x130]
    1588:      	fadd.4s	v26, v26, v28
    158c:      	fadd.4s	v19, v19, v28
    1590:      	fmul.4s	v19, v24, v19
    1594:      	fmul.4s	v26, v22, v26
    1598:      	fadd.4s	v26, v26, v29
    159c:      	fadd.4s	v28, v19, v29
    15a0:      	fdiv.4s	v19, v27, v25
    15a4:      	fmul.4s	v25, v24, v28
    15a8:      	fmul.4s	v26, v22, v26
    15ac:      	movi.4s	v28, #0x3f, lsl #24
    15b0:      	fadd.4s	v26, v26, v28
    15b4:      	fadd.4s	v25, v25, v28
    15b8:      	fmul.4s	v27, v24, v24
    15bc:      	fmul.4s	v25, v27, v25
    15c0:      	fmul.4s	v27, v22, v22
    15c4:      	fmul.4s	v26, v27, v26
    15c8:      	fadd.4s	v22, v22, v26
    15cc:      	fadd.4s	v24, v24, v25
    15d0:      	movi.2d	v27, #0xffffffffffffffff
    15d4:      	add.4s	v21, v21, v27
    15d8:      	fadd.4s	v22, v22, v31
    15dc:      	sshr.4s	v25, v21, #0x1
    15e0:      	shl.4s	v26, v25, #0x17
    15e4:      	add.4s	v26, v26, v31
    15e8:      	fmul.4s	v22, v22, v26
    15ec:      	add.4s	v23, v23, v27
    15f0:      	fadd.4s	v24, v24, v31
    15f4:      	sub.4s	v21, v21, v25
    15f8:      	sshr.4s	v25, v23, #0x1
    15fc:      	sub.4s	v23, v23, v25
    1600:      	shl.4s	v25, v25, #0x17
    1604:      	add.4s	v25, v25, v31
    1608:      	fmul.4s	v24, v24, v25
    160c:      	shl.4s	v23, v23, #0x17
    1610:      	add.4s	v23, v23, v31
    1614:      	fmul.4s	v23, v24, v23
    1618:      	shl.4s	v21, v21, #0x17
    161c:      	add.4s	v21, v21, v31
    1620:      	fmul.4s	v21, v22, v21
    1624:      	fcmgt.4s	v20, v20, v11
    1628:      	bsl.16b	v20, v15, v21
    162c:      	fmul.4s	v6, v5, v6
    1630:      	fcmgt.4s	v18, v18, v11
    1634:      	bsl.16b	v18, v15, v23
    1638:      	fdiv.4s	v6, v6, v17
    163c:      	ldr	q22, [sp, #0x120]
    1640:      	fdiv.4s	v17, v22, v18
    1644:      	fsub.4s	v21, v18, v17
    1648:      	fadd.4s	v17, v18, v17
    164c:      	fdiv.4s	v17, v21, v17
    1650:      	bsl.16b	v16, v17, v31
    1654:      	fcmge.4s	v5, v31, v5
    1658:      	bsl.16b	v5, v6, v16
    165c:      	fdiv.4s	v6, v22, v20
    1660:      	fsub.4s	v16, v20, v6
    1664:      	fadd.4s	v6, v20, v6
    1668:      	fdiv.4s	v6, v16, v6
    166c:      	bif.16b	v6, v31, v7
    1670:      	fcmge.4s	v4, v31, v4
    1674:      	bsl.16b	v4, v19, v6
    1678:      	mvni.4s	v6, #0x80, lsl #24
    167c:      	bif.16b	v4, v3, v6
    1680:      	fcmeq.4s	v3, v3, v3
    1684:      	fadd.4s	v4, v4, v31
    1688:      	ldr	q7, [sp, #0x110]
    168c:      	bsl.16b	v3, v4, v7
    1690:      	mov.16b	v4, v6
    1694:      	bsl.16b	v4, v5, v2
    1698:      	fcmeq.4s	v2, v2, v2
    169c:      	fadd.4s	v4, v4, v31
    16a0:      	bsl.16b	v2, v4, v7
    16a4:      	fmul.4s	v1, v1, v28
    16a8:      	fmul.4s	v1, v1, v2
    16ac:      	fmul.4s	v0, v0, v28
    16b0:      	fmul.4s	v0, v0, v3
    16b4:      	add	x9, x19, x8
    16b8:      	ldp	q3, q2, [x9]
    16bc:      	fadd.4s	v0, v3, v0
    16c0:      	fadd.4s	v1, v2, v1
    16c4:      	add	x9, x22, x8
    16c8:      	stp	q0, q1, [x9]
    16cc:      	add	x8, x8, #0x20
    16d0:      	cmp	x8, #0xc00
    16d4:      	b.ne	0x13b4 <ltmp0+0x13b4>
    16d8:      	b	0x1008 <ltmp0+0x1008>
    16dc:      	mov	x8, #0x0                ; =0
    16e0:      	add	x12, x12, x11
    16e4:      	b	0x1708 <ltmp0+0x1708>
    16e8:      	add	x13, x28, x8
    16ec:      	ldp	q6, q7, [x13]
    16f0:      	bif.16b	v5, v7, v0
    16f4:      	bif.16b	v4, v6, v1
    16f8:      	stp	q4, q5, [x13]
    16fc:      	add	x8, x8, #0x20
    1700:      	cmp	x8, #0xc00
    1704:      	b.eq	0x17ac <ltmp0+0x17ac>
    1708:      	ldr	q3, [x16]
    170c:      	and.16b	v3, v2, v3
    1710:      	addv.8h	h3, v3
    1714:      	fmov	w14, s3
    1718:      	add	x13, x12, x8
    171c:      	movi.2d	v4, #0000000000000000
    1720:      	movi.2d	v5, #0000000000000000
    1724:      	tbnz	w14, #0x0, 0x174c <ltmp0+0x174c>
    1728:      	and	w14, w14, #0xff
    172c:      	tbnz	w14, #0x1, 0x1758 <ltmp0+0x1758>
    1730:      	tbnz	w14, #0x2, 0x1764 <ltmp0+0x1764>
    1734:      	tbnz	w14, #0x3, 0x1770 <ltmp0+0x1770>
    1738:      	tbnz	w14, #0x4, 0x177c <ltmp0+0x177c>
    173c:      	tbnz	w14, #0x5, 0x1788 <ltmp0+0x1788>
    1740:      	tbnz	w14, #0x6, 0x1794 <ltmp0+0x1794>
    1744:      	tbz	w14, #0x7, 0x16e8 <ltmp0+0x16e8>
    1748:      	b	0x17a0 <ltmp0+0x17a0>
    174c:      	ldr	s4, [x13]
    1750:      	and	w14, w14, #0xff
    1754:      	tbz	w14, #0x1, 0x1730 <ltmp0+0x1730>
    1758:      	add	x15, x13, #0x4
    175c:      	ld1.s	{ v4 }[1], [x15]
    1760:      	tbz	w14, #0x2, 0x1734 <ltmp0+0x1734>
    1764:      	add	x15, x13, #0x8
    1768:      	ld1.s	{ v4 }[2], [x15]
    176c:      	tbz	w14, #0x3, 0x1738 <ltmp0+0x1738>
    1770:      	add	x15, x13, #0xc
    1774:      	ld1.s	{ v4 }[3], [x15]
    1778:      	tbz	w14, #0x4, 0x173c <ltmp0+0x173c>
    177c:      	add	x15, x13, #0x10
    1780:      	ld1.s	{ v5 }[0], [x15]
    1784:      	tbz	w14, #0x5, 0x1740 <ltmp0+0x1740>
    1788:      	add	x15, x13, #0x14
    178c:      	ld1.s	{ v5 }[1], [x15]
    1790:      	tbz	w14, #0x6, 0x1744 <ltmp0+0x1744>
    1794:      	add	x15, x13, #0x18
    1798:      	ld1.s	{ v5 }[2], [x15]
    179c:      	tbz	w14, #0x7, 0x16e8 <ltmp0+0x16e8>
    17a0:      	add	x13, x13, #0x1c
    17a4:      	ld1.s	{ v5 }[3], [x13]
    17a8:      	b	0x16e8 <ltmp0+0x16e8>
    17ac:      	mov	x8, #0x0                ; =0
    17b0:      	add	x10, x10, x11
    17b4:      	b	0x17d8 <ltmp0+0x17d8>
    17b8:      	add	x12, x19, x8
    17bc:      	ldp	q5, q6, [x12]
    17c0:      	bif.16b	v4, v6, v0
    17c4:      	bif.16b	v2, v5, v1
    17c8:      	stp	q2, q4, [x12]
    17cc:      	add	x8, x8, #0x20
    17d0:      	cmp	x8, #0xc00
    17d4:      	b.eq	0x1870 <ltmp0+0x1870>
    17d8:      	fmov	w13, s3
    17dc:      	add	x12, x10, x8
    17e0:      	movi.2d	v2, #0000000000000000
    17e4:      	movi.2d	v4, #0000000000000000
    17e8:      	tbnz	w13, #0x0, 0x1810 <ltmp0+0x1810>
    17ec:      	and	w13, w13, #0xff
    17f0:      	tbnz	w13, #0x1, 0x181c <ltmp0+0x181c>
    17f4:      	tbnz	w13, #0x2, 0x1828 <ltmp0+0x1828>
    17f8:      	tbnz	w13, #0x3, 0x1834 <ltmp0+0x1834>
    17fc:      	tbnz	w13, #0x4, 0x1840 <ltmp0+0x1840>
    1800:      	tbnz	w13, #0x5, 0x184c <ltmp0+0x184c>
    1804:      	tbnz	w13, #0x6, 0x1858 <ltmp0+0x1858>
    1808:      	tbz	w13, #0x7, 0x17b8 <ltmp0+0x17b8>
    180c:      	b	0x1864 <ltmp0+0x1864>
    1810:      	ldr	s2, [x12]
    1814:      	and	w13, w13, #0xff
    1818:      	tbz	w13, #0x1, 0x17f4 <ltmp0+0x17f4>
    181c:      	add	x14, x12, #0x4
    1820:      	ld1.s	{ v2 }[1], [x14]
    1824:      	tbz	w13, #0x2, 0x17f8 <ltmp0+0x17f8>
    1828:      	add	x14, x12, #0x8
    182c:      	ld1.s	{ v2 }[2], [x14]
    1830:      	tbz	w13, #0x3, 0x17fc <ltmp0+0x17fc>
    1834:      	add	x14, x12, #0xc
    1838:      	ld1.s	{ v2 }[3], [x14]
    183c:      	tbz	w13, #0x4, 0x1800 <ltmp0+0x1800>
    1840:      	add	x14, x12, #0x10
    1844:      	ld1.s	{ v4 }[0], [x14]
    1848:      	tbz	w13, #0x5, 0x1804 <ltmp0+0x1804>
    184c:      	add	x14, x12, #0x14
    1850:      	ld1.s	{ v4 }[1], [x14]
    1854:      	tbz	w13, #0x6, 0x1808 <ltmp0+0x1808>
    1858:      	add	x14, x12, #0x18
    185c:      	ld1.s	{ v4 }[2], [x14]
    1860:      	tbz	w13, #0x7, 0x17b8 <ltmp0+0x17b8>
    1864:      	add	x12, x12, #0x1c
    1868:      	ld1.s	{ v4 }[3], [x12]
    186c:      	b	0x17b8 <ltmp0+0x17b8>
    1870:      	mov	x8, #0x0                ; =0
    1874:      	add	x9, x9, x11
    1878:      	b	0x1888 <ltmp0+0x1888>
    187c:      	add	x8, x8, #0x20
    1880:      	cmp	x8, #0xc00
    1884:      	b.eq	0x1bc <ltmp0+0x1bc>
    1888:      	add	x10, x28, x8
    188c:      	ldr	q2, [x10]
    1890:      	and.16b	v2, v1, v2
    1894:      	ldp	q5, q4, [sp, #0x1f0]
    1898:      	fmul.4s	v4, v2, v4
    189c:      	fmul.4s	v4, v2, v4
    18a0:      	fmul.4s	v4, v2, v4
    18a4:      	fadd.4s	v4, v2, v4
    18a8:      	fmul.4s	v4, v4, v5
    18ac:      	and.16b	v4, v1, v4
    18b0:      	fabs.4s	v5, v4
    18b4:      	fmul.4s	v6, v4, v4
    18b8:      	ldp	q7, q16, [sp, #0x1d0]
    18bc:      	fmla.4s	v7, v6, v16
    18c0:      	ldr	q16, [sp, #0x1c0]
    18c4:      	fmla.4s	v16, v6, v7
    18c8:      	ldr	q7, [sp, #0x1b0]
    18cc:      	fmla.4s	v7, v6, v16
    18d0:      	ldr	q16, [sp, #0x1a0]
    18d4:      	fmla.4s	v16, v6, v7
    18d8:      	mov.16b	v7, v29
    18dc:      	fmla.4s	v7, v6, v16
    18e0:      	mov.16b	v16, v31
    18e4:      	fmla.4s	v16, v6, v7
    18e8:      	fmul.4s	v7, v5, v16
    18ec:      	mov.16b	v16, v25
    18f0:      	fmla.4s	v16, v6, v22
    18f4:      	mov.16b	v17, v26
    18f8:      	fmla.4s	v17, v6, v16
    18fc:      	mov.16b	v16, v28
    1900:      	fmla.4s	v16, v6, v17
    1904:      	mov.16b	v17, v9
    1908:      	fmla.4s	v17, v6, v16
    190c:      	movi.4s	v16, #0x3f, lsl #24
    1910:      	fmla.4s	v16, v6, v17
    1914:      	mov.16b	v17, v31
    1918:      	fmla.4s	v17, v6, v16
    191c:      	fdiv.4s	v6, v7, v17
    1920:      	ldr	q7, [sp, #0x190]
    1924:      	fcmge.4s	v7, v7, v5
    1928:      	and.16b	v16, v7, v5
    192c:      	fcmge.4s	v17, v16, v10
    1930:      	fcmge.4s	v18, v11, v16
    1934:      	and.16b	v17, v17, v18
    1938:      	and.16b	v17, v17, v16
    193c:      	fmul.4s	v18, v17, v12
    1940:      	movi.4s	v19, #0x4b, lsl #24
    1944:      	fadd.4s	v18, v18, v19
    1948:      	movi.4s	v19, #0xcb, lsl #24
    194c:      	fadd.4s	v18, v18, v19
    1950:      	fcvtzs.4s	v18, v18
    1954:      	scvtf.4s	v19, v18
    1958:      	fmul.4s	v20, v19, v13
    195c:      	fadd.4s	v17, v17, v20
    1960:      	fmul.4s	v19, v19, v14
    1964:      	fadd.4s	v17, v17, v19
    1968:      	fmul.4s	v19, v17, v15
    196c:      	fadd.4s	v19, v19, v30
    1970:      	fmul.4s	v19, v17, v19
    1974:      	fadd.4s	v19, v19, v27
    1978:      	fmul.4s	v19, v17, v19
    197c:      	ldr	q20, [sp, #0x130]
    1980:      	fadd.4s	v19, v19, v20
    1984:      	fmul.4s	v19, v17, v19
    1988:      	fadd.4s	v19, v19, v29
    198c:      	fmul.4s	v19, v17, v19
    1990:      	movi.4s	v21, #0x3f, lsl #24
    1994:      	fadd.4s	v19, v19, v21
    1998:      	fmul.4s	v20, v17, v17
    199c:      	fmul.4s	v19, v20, v19
    19a0:      	fadd.4s	v17, v17, v19
    19a4:      	fadd.4s	v17, v17, v31
    19a8:      	add.4s	v18, v18, v24
    19ac:      	sshr.4s	v19, v18, #0x1
    19b0:      	shl.4s	v20, v19, #0x17
    19b4:      	add.4s	v20, v20, v31
    19b8:      	fmul.4s	v17, v17, v20
    19bc:      	sub.4s	v18, v18, v19
    19c0:      	shl.4s	v18, v18, #0x17
    19c4:      	add.4s	v18, v18, v31
    19c8:      	fmul.4s	v17, v17, v18
    19cc:      	fcmgt.4s	v16, v16, v11
    19d0:      	ldr	q18, [sp, #0x90]
    19d4:      	bsl.16b	v16, v18, v17
    19d8:      	ldr	q17, [sp, #0x120]
    19dc:      	fdiv.4s	v17, v17, v16
    19e0:      	fsub.4s	v18, v16, v17
    19e4:      	fadd.4s	v16, v16, v17
    19e8:      	fdiv.4s	v16, v18, v16
    19ec:      	bsl.16b	v7, v16, v31
    19f0:      	fcmge.4s	v5, v31, v5
    19f4:      	bsl.16b	v5, v6, v7
    19f8:      	bif.16b	v5, v4, v8
    19fc:      	fcmeq.4s	v4, v4, v4
    1a00:      	fadd.4s	v5, v5, v31
    1a04:      	ldr	q6, [sp, #0x110]
    1a08:      	bif.16b	v5, v6, v4
    1a0c:      	ldr	q4, [x10, #0x10]
    1a10:      	fmul.4s	v2, v2, v21
    1a14:      	fmul.4s	v2, v2, v5
    1a18:      	add	x10, x19, x8
    1a1c:      	ldr	q5, [x10]
    1a20:      	and.16b	v5, v1, v5
    1a24:      	fadd.4s	v5, v5, v2
    1a28:      	ldr	q2, [x10, #0x10]
    1a2c:      	fmov	w11, s3
    1a30:      	add	x10, x9, x8
    1a34:      	tbnz	w11, #0x0, 0x1bf0 <ltmp0+0x1bf0>
    1a38:      	and	w11, w11, #0xff
    1a3c:      	tbnz	w11, #0x1, 0x1bfc <ltmp0+0x1bfc>
    1a40:      	tbnz	w11, #0x2, 0x1c08 <ltmp0+0x1c08>
    1a44:      	tbz	w11, #0x3, 0x1a50 <ltmp0+0x1a50>
    1a48:      	add	x12, x10, #0xc
    1a4c:      	st1.s	{ v5 }[3], [x12]
    1a50:      	and.16b	v4, v0, v4
    1a54:      	ldp	q6, q5, [sp, #0x1f0]
    1a58:      	fmul.4s	v5, v4, v5
    1a5c:      	fmul.4s	v5, v4, v5
    1a60:      	fmul.4s	v5, v4, v5
    1a64:      	fadd.4s	v5, v4, v5
    1a68:      	fmul.4s	v5, v5, v6
    1a6c:      	and.16b	v5, v0, v5
    1a70:      	fabs.4s	v6, v5
    1a74:      	fmul.4s	v7, v5, v5
    1a78:      	ldp	q16, q17, [sp, #0x1d0]
    1a7c:      	fmla.4s	v16, v7, v17
    1a80:      	ldr	q17, [sp, #0x1c0]
    1a84:      	fmla.4s	v17, v7, v16
    1a88:      	ldr	q16, [sp, #0x1b0]
    1a8c:      	fmla.4s	v16, v7, v17
    1a90:      	ldr	q17, [sp, #0x1a0]
    1a94:      	fmla.4s	v17, v7, v16
    1a98:      	mov.16b	v16, v29
    1a9c:      	fmla.4s	v16, v7, v17
    1aa0:      	mov.16b	v17, v31
    1aa4:      	fmla.4s	v17, v7, v16
    1aa8:      	fmul.4s	v16, v6, v17
    1aac:      	mov.16b	v17, v25
    1ab0:      	fmla.4s	v17, v7, v22
    1ab4:      	mov.16b	v18, v26
    1ab8:      	fmla.4s	v18, v7, v17
    1abc:      	mov.16b	v17, v28
    1ac0:      	fmla.4s	v17, v7, v18
    1ac4:      	mov.16b	v18, v9
    1ac8:      	fmla.4s	v18, v7, v17
    1acc:      	movi.4s	v17, #0x3f, lsl #24
    1ad0:      	fmla.4s	v17, v7, v18
    1ad4:      	mov.16b	v18, v31
    1ad8:      	fmla.4s	v18, v7, v17
    1adc:      	fdiv.4s	v7, v16, v18
    1ae0:      	ldr	q16, [sp, #0x190]
    1ae4:      	fcmge.4s	v16, v16, v6
    1ae8:      	and.16b	v17, v16, v6
    1aec:      	fcmge.4s	v18, v17, v10
    1af0:      	fcmge.4s	v19, v11, v17
    1af4:      	and.16b	v18, v18, v19
    1af8:      	and.16b	v18, v18, v17
    1afc:      	fmul.4s	v19, v18, v12
    1b00:      	movi.4s	v20, #0x4b, lsl #24
    1b04:      	fadd.4s	v19, v19, v20
    1b08:      	movi.4s	v20, #0xcb, lsl #24
    1b0c:      	fadd.4s	v19, v19, v20
    1b10:      	fcvtzs.4s	v19, v19
    1b14:      	scvtf.4s	v20, v19
    1b18:      	fmul.4s	v21, v20, v13
    1b1c:      	fadd.4s	v18, v18, v21
    1b20:      	fmul.4s	v20, v20, v14
    1b24:      	fadd.4s	v18, v18, v20
    1b28:      	fmul.4s	v20, v18, v15
    1b2c:      	fadd.4s	v20, v20, v30
    1b30:      	fmul.4s	v20, v18, v20
    1b34:      	fadd.4s	v20, v20, v27
    1b38:      	fmul.4s	v20, v18, v20
    1b3c:      	ldr	q21, [sp, #0x130]
    1b40:      	fadd.4s	v20, v20, v21
    1b44:      	fmul.4s	v20, v18, v20
    1b48:      	fadd.4s	v20, v20, v29
    1b4c:      	fmul.4s	v20, v18, v20
    1b50:      	movi.4s	v23, #0x3f, lsl #24
    1b54:      	fadd.4s	v20, v20, v23
    1b58:      	fmul.4s	v21, v18, v18
    1b5c:      	fmul.4s	v20, v21, v20
    1b60:      	fadd.4s	v18, v18, v20
    1b64:      	fadd.4s	v18, v18, v31
    1b68:      	add.4s	v19, v19, v24
    1b6c:      	sshr.4s	v20, v19, #0x1
    1b70:      	shl.4s	v21, v20, #0x17
    1b74:      	add.4s	v21, v21, v31
    1b78:      	fmul.4s	v18, v18, v21
    1b7c:      	sub.4s	v19, v19, v20
    1b80:      	shl.4s	v19, v19, #0x17
    1b84:      	add.4s	v19, v19, v31
    1b88:      	fmul.4s	v18, v18, v19
    1b8c:      	fcmgt.4s	v17, v17, v11
    1b90:      	ldr	q19, [sp, #0x90]
    1b94:      	bsl.16b	v17, v19, v18
    1b98:      	ldr	q18, [sp, #0x120]
    1b9c:      	fdiv.4s	v18, v18, v17
    1ba0:      	fsub.4s	v19, v17, v18
    1ba4:      	fadd.4s	v17, v17, v18
    1ba8:      	fdiv.4s	v17, v19, v17
    1bac:      	bsl.16b	v16, v17, v31
    1bb0:      	fcmge.4s	v6, v31, v6
    1bb4:      	bsl.16b	v6, v7, v16
    1bb8:      	bif.16b	v6, v5, v8
    1bbc:      	fcmeq.4s	v5, v5, v5
    1bc0:      	fadd.4s	v6, v6, v31
    1bc4:      	ldr	q7, [sp, #0x110]
    1bc8:      	bsl.16b	v5, v6, v7
    1bcc:      	fmul.4s	v4, v4, v23
    1bd0:      	fmul.4s	v4, v4, v5
    1bd4:      	and.16b	v2, v0, v2
    1bd8:      	fadd.4s	v2, v2, v4
    1bdc:      	tbnz	w11, #0x4, 0x1c18 <ltmp0+0x1c18>
    1be0:      	tbnz	w11, #0x5, 0x1c20 <ltmp0+0x1c20>
    1be4:      	tbnz	w11, #0x6, 0x1c2c <ltmp0+0x1c2c>
    1be8:      	tbz	w11, #0x7, 0x187c <ltmp0+0x187c>
    1bec:      	b	0x1c38 <ltmp0+0x1c38>
    1bf0:      	str	s5, [x10]
    1bf4:      	and	w11, w11, #0xff
    1bf8:      	tbz	w11, #0x1, 0x1a40 <ltmp0+0x1a40>
    1bfc:      	add	x12, x10, #0x4
    1c00:      	st1.s	{ v5 }[1], [x12]
    1c04:      	tbz	w11, #0x2, 0x1a44 <ltmp0+0x1a44>
    1c08:      	add	x12, x10, #0x8
    1c0c:      	st1.s	{ v5 }[2], [x12]
    1c10:      	tbnz	w11, #0x3, 0x1a48 <ltmp0+0x1a48>
    1c14:      	b	0x1a50 <ltmp0+0x1a50>
    1c18:      	str	s2, [x10, #0x10]
    1c1c:      	tbz	w11, #0x5, 0x1be4 <ltmp0+0x1be4>
    1c20:      	add	x12, x10, #0x14
    1c24:      	st1.s	{ v2 }[1], [x12]
    1c28:      	tbz	w11, #0x6, 0x1be8 <ltmp0+0x1be8>
    1c2c:      	add	x12, x10, #0x18
    1c30:      	st1.s	{ v2 }[2], [x12]
    1c34:      	tbz	w11, #0x7, 0x187c <ltmp0+0x187c>
    1c38:      	add	x10, x10, #0x1c
    1c3c:      	st1.s	{ v2 }[3], [x10]
    1c40:      	b	0x187c <ltmp0+0x187c>
    1c44:      	ldr	x9, [sp, #0x10]
    1c48:      	stp	w14, w13, [x9]
    1c4c:      	str	w12, [x9, #0x8]
    1c50:      	mov	w8, #0x18               ; =24
    1c54:      	str	w8, [x9, #0x24]
    1c58:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
    1c5c:      	add	sp, sp, #0xa20
    1c60:      	ldp	x29, x30, [sp, #0x90]
    1c64:      	ldp	x20, x19, [sp, #0x80]
    1c68:      	ldp	x22, x21, [sp, #0x70]
    1c6c:      	ldp	x24, x23, [sp, #0x60]
    1c70:      	ldp	x26, x25, [sp, #0x50]
    1c74:      	ldp	x28, x27, [sp, #0x40]
    1c78:      	ldp	d9, d8, [sp, #0x30]
    1c7c:      	ldp	d11, d10, [sp, #0x20]
    1c80:      	ldp	d13, d12, [sp, #0x10]
    1c84:      	ldp	d15, d14, [sp], #0xa0
    1c88:      	ret

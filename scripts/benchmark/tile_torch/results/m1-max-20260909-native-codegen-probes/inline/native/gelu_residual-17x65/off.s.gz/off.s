
/private/tmp/luisa-packet-inline.UY1lIE/capture/gelu_residual-17x65/off/object/tile_xir_w8_36431_1788935103148447_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x50]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	sub	sp, sp, #0x360
      18:      	ldr	x12, [x0]
      1c:      	ldr	x10, [x0, #0x10]
      20:      	ldr	w8, [x1]
      24:      	ldr	w9, [x1, #0x24]
      28:      	add	w8, w9, w8, lsl #5
      2c:      	lsr	w8, w8, #3
      30:      	dup.2s	v0, w8
      34:      	ldr	x8, [x0, #0x30]
      38:      	ushll.2d	v0, v0, #0x0
      3c:      	subs	x9, x12, x8
      40:      	lsr	x9, x9, #2
      44:      	mov	w11, #0x450             ; =1104
      48:      	ccmp	x9, x11, #0x0, hs
      4c:      	cset	w9, hi
      50:      	subs	x13, x8, x12
      54:      	lsr	x13, x13, #2
      58:      	ccmp	x13, x11, #0x0, hs
      5c:      	csinc	w13, w9, wzr, ls
      60:      	subs	x9, x10, x8
      64:      	lsr	x9, x9, #2
      68:      	ccmp	x9, x11, #0x0, hs
      6c:      	cset	w9, hi
      70:      	subs	x14, x8, x10
      74:      	lsr	x14, x14, #2
      78:      	ccmp	x14, x11, #0x0, hs
      7c:      	csinc	w11, w9, wzr, ls
      80:      	fmov	x9, d0
      84:      	add	x9, x9, x9, lsl #6
      88:      	lsl	x9, x9, #2
      8c:      	cmp	w13, #0x1
      90:      	ccmp	w11, #0x0, #0x4, eq
      94:      	b.ne	0x828 <ltmp0+0x828>
      98:      	mov	x11, #0x0               ; =0
      9c:      	add	x9, x12, x9
      a0:      	ldp	q1, q2, [x9, #0xc0]
      a4:      	stp	q1, q2, [sp, #0x300]
      a8:      	ldp	q1, q2, [x9, #0xe0]
      ac:      	stp	q1, q2, [sp, #0x320]
      b0:      	ldp	q1, q2, [x9, #0x80]
      b4:      	stp	q1, q2, [sp, #0x2c0]
      b8:      	ldp	q1, q2, [x9, #0xa0]
      bc:      	stp	q1, q2, [sp, #0x2e0]
      c0:      	ldp	q1, q2, [x9, #0x40]
      c4:      	stp	q1, q2, [sp, #0x280]
      c8:      	ldp	q1, q2, [x9, #0x60]
      cc:      	stp	q1, q2, [sp, #0x2a0]
      d0:      	ldp	q1, q2, [x9]
      d4:      	stp	q1, q2, [sp, #0x240]
      d8:      	ldp	q1, q2, [x9, #0x20]
      dc:      	stp	q1, q2, [sp, #0x260]
      e0:      	fmov	x9, d0
      e4:      	add	x9, x9, x9, lsl #6
      e8:      	lsl	x13, x9, #2
      ec:      	add	x9, x13, #0x100
      f0:      	ldr	s0, [x12, x9]
      f4:      	str	q0, [sp]
      f8:      	str	q0, [sp, #0x340]
      fc:      	add	x12, x10, x13
     100:      	ldp	q0, q1, [x12, #0xc0]
     104:      	stp	q0, q1, [sp, #0x1e0]
     108:      	ldp	q0, q1, [x12, #0xe0]
     10c:      	stp	q0, q1, [sp, #0x200]
     110:      	ldp	q0, q1, [x12, #0x80]
     114:      	stp	q0, q1, [sp, #0x1a0]
     118:      	ldp	q0, q1, [x12, #0xa0]
     11c:      	stp	q0, q1, [sp, #0x1c0]
     120:      	ldp	q0, q1, [x12, #0x40]
     124:      	stp	q0, q1, [sp, #0x160]
     128:      	ldp	q0, q1, [x12, #0x60]
     12c:      	stp	q0, q1, [sp, #0x180]
     130:      	ldp	q3, q4, [x12]
     134:      	ldp	q0, q1, [x12, #0x20]
     138:      	ldr	s2, [x10, x9]
     13c:      	add	x10, x8, x13
     140:      	add	x12, sp, #0x240
     144:      	mov	w13, #0x2713            ; =10003
     148:      	movk	w13, #0x3d37, lsl #16
     14c:      	dup.4s	v6, w13
     150:      	mov	w13, #0x422a            ; =16938
     154:      	movk	w13, #0x3f4c, lsl #16
     158:      	dup.4s	v5, w13
     15c:      	stp	q5, q6, [sp, #0xf0]
     160:      	fmov.4s	v19, #1.00000000
     164:      	mov	w13, #0x9231            ; =37425
     168:      	movk	w13, #0x2f30, lsl #16
     16c:      	dup.4s	v6, w13
     170:      	mov	w13, #0x322b            ; =12843
     174:      	movk	w13, #0x32d7, lsl #16
     178:      	dup.4s	v5, w13
     17c:      	stp	q5, q6, [sp, #0xd0]
     180:      	mov	w13, #0xef1d            ; =61213
     184:      	movk	w13, #0x3638, lsl #16
     188:      	dup.4s	v6, w13
     18c:      	mov	w13, #0xd01             ; =3329
     190:      	movk	w13, #0x3950, lsl #16
     194:      	dup.4s	v5, w13
     198:      	stp	q5, q6, [sp, #0xb0]
     19c:      	mov	w13, #0x8889            ; =34953
     1a0:      	movk	w13, #0x3c08, lsl #16
     1a4:      	dup.4s	v6, w13
     1a8:      	mov	w13, #0xaaab            ; =43691
     1ac:      	movk	w13, #0x3e2a, lsl #16
     1b0:      	dup.4s	v22, w13
     1b4:      	mov	w13, #0x76c7            ; =30407
     1b8:      	movk	w13, #0x310f, lsl #16
     1bc:      	dup.4s	v5, w13
     1c0:      	stp	q5, q6, [sp, #0x90]
     1c4:      	mov	w13, #0xf27e            ; =62078
     1c8:      	movk	w13, #0x3493, lsl #16
     1cc:      	dup.4s	v6, w13
     1d0:      	mov	w13, #0xd01             ; =3329
     1d4:      	movk	w13, #0x37d0, lsl #16
     1d8:      	dup.4s	v5, w13
     1dc:      	stp	q5, q6, [sp, #0x70]
     1e0:      	mov	w13, #0xb61             ; =2913
     1e4:      	movk	w13, #0x3ab6, lsl #16
     1e8:      	dup.4s	v6, w13
     1ec:      	mov	w13, #0xaaab            ; =43691
     1f0:      	movk	w13, #0x3d2a, lsl #16
     1f4:      	dup.4s	v5, w13
     1f8:      	stp	q5, q6, [sp, #0x50]
     1fc:      	mov	w13, #-0x3d300000       ; =-1026555904
     200:      	dup.4s	v6, w13
     204:      	mov	w13, #0x42c80000        ; =1120403456
     208:      	dup.4s	v27, w13
     20c:      	fmov.4s	v5, #9.00000000
     210:      	str	q5, [sp, #0x110]
     214:      	mov	w13, #0xaa3b            ; =43579
     218:      	movk	w13, #0x3fb8, lsl #16
     21c:      	dup.4s	v5, w13
     220:      	stp	q5, q6, [sp, #0x30]
     224:      	mov	w13, #0x7200            ; =29184
     228:      	movk	w13, #0xbf31, lsl #16
     22c:      	dup.4s	v5, w13
     230:      	str	q5, [sp, #0x20]
     234:      	mov	w13, #0xbe8e            ; =48782
     238:      	movk	w13, #0xb5bf, lsl #16
     23c:      	dup.4s	v8, w13
     240:      	mov	w13, #0x2bda            ; =11226
     244:      	movk	w13, #0x3950, lsl #16
     248:      	dup.4s	v9, w13
     24c:      	mov	w13, #0x96c9            ; =38601
     250:      	movk	w13, #0x3ab6, lsl #16
     254:      	dup.4s	v10, w13
     258:      	mov	w13, #0x88a6            ; =34982
     25c:      	movk	w13, #0x3c08, lsl #16
     260:      	dup.4s	v11, w13
     264:      	mov	w13, #0xaa7a            ; =43642
     268:      	movk	w13, #0x3d2a, lsl #16
     26c:      	stp	q3, q4, [sp, #0x120]
     270:      	mvni.4s	v3, #0x7f, msl #16
     274:      	fneg.4s	v13, v3
     278:      	stp	q0, q1, [sp, #0x140]
     27c:      	mvni.4s	v0, #0x3f, msl #16
     280:      	dup.4s	v14, w13
     284:      	fneg.4s	v15, v0
     288:      	add	x13, sp, #0x120
     28c:      	str	q2, [sp, #0x10]
     290:      	str	q2, [sp, #0x220]
     294:      	add	x14, x12, x11
     298:      	ldp	q29, q30, [x14]
     29c:      	ldp	q2, q1, [sp, #0xf0]
     2a0:      	fmul.4s	v0, v29, v1
     2a4:      	fmul.4s	v1, v30, v1
     2a8:      	fmul.4s	v1, v30, v1
     2ac:      	fmul.4s	v0, v29, v0
     2b0:      	fmul.4s	v0, v29, v0
     2b4:      	fmul.4s	v1, v30, v1
     2b8:      	fadd.4s	v1, v30, v1
     2bc:      	fadd.4s	v0, v29, v0
     2c0:      	fmul.4s	v0, v0, v2
     2c4:      	fmul.4s	v12, v1, v2
     2c8:      	fabs.4s	v4, v12
     2cc:      	fabs.4s	v3, v0
     2d0:      	fmul.4s	v18, v0, v0
     2d4:      	ldp	q5, q2, [sp, #0xd0]
     2d8:      	mov.16b	v1, v5
     2dc:      	fmul.4s	v21, v12, v12
     2e0:      	fmla.4s	v1, v18, v2
     2e4:      	fmla.4s	v5, v21, v2
     2e8:      	ldr	q7, [sp, #0xc0]
     2ec:      	mov.16b	v6, v7
     2f0:      	fmla.4s	v6, v18, v1
     2f4:      	fmla.4s	v7, v21, v5
     2f8:      	ldr	q1, [sp, #0xb0]
     2fc:      	mov.16b	v5, v1
     300:      	fmla.4s	v5, v18, v6
     304:      	mov.16b	v6, v1
     308:      	ldp	q2, q1, [sp, #0x90]
     30c:      	mov.16b	v16, v1
     310:      	fmla.4s	v6, v21, v7
     314:      	mov.16b	v7, v1
     318:      	mov.16b	v20, v22
     31c:      	mov.16b	v17, v22
     320:      	mov.16b	v1, v19
     324:      	mov.16b	v26, v19
     328:      	fmla.4s	v16, v18, v5
     32c:      	ldr	q23, [sp, #0x80]
     330:      	mov.16b	v5, v23
     334:      	fmla.4s	v5, v21, v2
     338:      	fmla.4s	v23, v18, v2
     33c:      	ldr	q2, [sp, #0x70]
     340:      	mov.16b	v24, v2
     344:      	fmla.4s	v7, v21, v6
     348:      	fmla.4s	v24, v21, v5
     34c:      	mov.16b	v5, v2
     350:      	fmla.4s	v5, v18, v23
     354:      	ldp	q23, q2, [sp, #0x50]
     358:      	mov.16b	v6, v2
     35c:      	fmla.4s	v6, v21, v24
     360:      	fmla.4s	v20, v18, v16
     364:      	mov.16b	v16, v2
     368:      	fmla.4s	v16, v18, v5
     36c:      	mov.16b	v5, v23
     370:      	fmla.4s	v5, v21, v6
     374:      	fmla.4s	v17, v21, v7
     378:      	fmla.4s	v23, v18, v16
     37c:      	movi.4s	v24, #0x3f, lsl #24
     380:      	fmla.4s	v24, v21, v5
     384:      	movi.4s	v25, #0x3f, lsl #24
     388:      	mov.16b	v7, v19
     38c:      	fmla.4s	v26, v21, v17
     390:      	mov.16b	v2, v19
     394:      	ldr	q6, [sp, #0x110]
     398:      	fcmge.4s	v5, v6, v3
     39c:      	fcmge.4s	v6, v6, v4
     3a0:      	and.16b	v16, v6, v4
     3a4:      	and.16b	v17, v5, v3
     3a8:      	fmla.4s	v7, v21, v24
     3ac:      	ldr	q24, [sp, #0x40]
     3b0:      	fcmge.4s	v21, v17, v24
     3b4:      	fcmge.4s	v24, v16, v24
     3b8:      	fcmge.4s	v28, v27, v16
     3bc:      	and.16b	v24, v24, v28
     3c0:      	fcmge.4s	v28, v27, v17
     3c4:      	fmla.4s	v25, v18, v23
     3c8:      	and.16b	v21, v21, v28
     3cc:      	and.16b	v21, v21, v17
     3d0:      	and.16b	v23, v24, v16
     3d4:      	ldr	q28, [sp, #0x30]
     3d8:      	fmul.4s	v24, v23, v28
     3dc:      	fmul.4s	v28, v21, v28
     3e0:      	fmla.4s	v1, v18, v20
     3e4:      	movi.4s	v31, #0x4b, lsl #24
     3e8:      	fadd.4s	v20, v28, v31
     3ec:      	fadd.4s	v24, v24, v31
     3f0:      	movi.4s	v28, #0xcb, lsl #24
     3f4:      	fadd.4s	v24, v24, v28
     3f8:      	fadd.4s	v20, v20, v28
     3fc:      	fcvtzs.4s	v20, v20
     400:      	fmla.4s	v2, v18, v25
     404:      	fcvtzs.4s	v24, v24
     408:      	scvtf.4s	v18, v24
     40c:      	scvtf.4s	v25, v20
     410:      	ldr	q31, [sp, #0x20]
     414:      	fmul.4s	v28, v18, v31
     418:      	fadd.4s	v23, v23, v28
     41c:      	fmul.4s	v28, v25, v31
     420:      	fadd.4s	v21, v21, v28
     424:      	fmul.4s	v18, v18, v8
     428:      	fmul.4s	v25, v25, v8
     42c:      	fadd.4s	v21, v21, v25
     430:      	fadd.4s	v23, v23, v18
     434:      	fmul.4s	v18, v23, v9
     438:      	fmul.4s	v25, v21, v9
     43c:      	fadd.4s	v25, v25, v10
     440:      	fadd.4s	v18, v18, v10
     444:      	fmul.4s	v18, v23, v18
     448:      	fmul.4s	v25, v21, v25
     44c:      	fmul.4s	v1, v3, v1
     450:      	fadd.4s	v25, v25, v11
     454:      	fadd.4s	v18, v18, v11
     458:      	fmul.4s	v28, v23, v18
     45c:      	fmul.4s	v18, v21, v25
     460:      	fadd.4s	v25, v18, v14
     464:      	fdiv.4s	v18, v1, v2
     468:      	fadd.4s	v1, v28, v14
     46c:      	fmul.4s	v1, v23, v1
     470:      	fmul.4s	v2, v21, v25
     474:      	fadd.4s	v2, v2, v22
     478:      	fadd.4s	v1, v1, v22
     47c:      	fmul.4s	v1, v23, v1
     480:      	fmul.4s	v2, v21, v2
     484:      	movi.4s	v28, #0x3f, lsl #24
     488:      	fadd.4s	v2, v2, v28
     48c:      	fadd.4s	v1, v1, v28
     490:      	fmul.4s	v25, v23, v23
     494:      	fmul.4s	v1, v25, v1
     498:      	fmul.4s	v25, v21, v21
     49c:      	fmul.4s	v2, v25, v2
     4a0:      	fadd.4s	v2, v21, v2
     4a4:      	fadd.4s	v1, v23, v1
     4a8:      	fadd.4s	v1, v1, v19
     4ac:      	movi.2d	v21, #0xffffffffffffffff
     4b0:      	add.4s	v20, v20, v21
     4b4:      	fadd.4s	v2, v2, v19
     4b8:      	add.4s	v21, v24, v21
     4bc:      	sshr.4s	v23, v21, #0x1
     4c0:      	sshr.4s	v24, v20, #0x1
     4c4:      	shl.4s	v25, v24, #0x17
     4c8:      	add.4s	v25, v25, v19
     4cc:      	fmul.4s	v2, v2, v25
     4d0:      	shl.4s	v25, v23, #0x17
     4d4:      	add.4s	v25, v25, v19
     4d8:      	fmul.4s	v1, v1, v25
     4dc:      	sub.4s	v20, v20, v24
     4e0:      	sub.4s	v21, v21, v23
     4e4:      	shl.4s	v21, v21, #0x17
     4e8:      	add.4s	v21, v21, v19
     4ec:      	fmul.4s	v1, v1, v21
     4f0:      	shl.4s	v20, v20, #0x17
     4f4:      	add.4s	v20, v20, v19
     4f8:      	fmul.4s	v2, v2, v20
     4fc:      	fmul.4s	v20, v4, v26
     500:      	fcmgt.4s	v16, v16, v27
     504:      	fcmgt.4s	v17, v17, v27
     508:      	bit.16b	v2, v13, v17
     50c:      	bsl.16b	v16, v13, v1
     510:      	fmov.4s	v1, #0.25000000
     514:      	fdiv.4s	v7, v20, v7
     518:      	fdiv.4s	v17, v1, v16
     51c:      	fsub.4s	v20, v16, v17
     520:      	fadd.4s	v16, v16, v17
     524:      	fdiv.4s	v16, v20, v16
     528:      	bsl.16b	v6, v16, v19
     52c:      	fcmge.4s	v4, v19, v4
     530:      	bsl.16b	v4, v7, v6
     534:      	fdiv.4s	v6, v1, v2
     538:      	fsub.4s	v7, v2, v6
     53c:      	fadd.4s	v2, v2, v6
     540:      	fdiv.4s	v2, v7, v2
     544:      	bif.16b	v2, v19, v5
     548:      	fcmge.4s	v3, v19, v3
     54c:      	bit.16b	v2, v18, v3
     550:      	mvni.4s	v3, #0x80, lsl #24
     554:      	bif.16b	v2, v0, v3
     558:      	fcmeq.4s	v0, v0, v0
     55c:      	fadd.4s	v2, v2, v19
     560:      	bsl.16b	v0, v2, v15
     564:      	mov.16b	v2, v3
     568:      	bsl.16b	v2, v4, v12
     56c:      	fcmeq.4s	v3, v12, v12
     570:      	fadd.4s	v2, v2, v19
     574:      	bif.16b	v2, v15, v3
     578:      	fmul.4s	v3, v30, v28
     57c:      	fmul.4s	v2, v3, v2
     580:      	fmul.4s	v3, v29, v28
     584:      	fmul.4s	v0, v3, v0
     588:      	add	x14, x13, x11
     58c:      	ldp	q4, q3, [x14]
     590:      	fadd.4s	v0, v4, v0
     594:      	fadd.4s	v2, v3, v2
     598:      	add	x14, x10, x11
     59c:      	stp	q0, q2, [x14]
     5a0:      	add	x11, x11, #0x20
     5a4:      	cmp	x11, #0x100
     5a8:      	b.ne	0x294 <ltmp0+0x294>
     5ac:      	movi.2d	v3, #0000000000000000
     5b0:      	ldr	q4, [sp]
     5b4:      	mov.s	v3[0], v4[0]
     5b8:      	movi.2d	v0, #0000000000000000
     5bc:      	mov	w10, #0x2713            ; =10003
     5c0:      	movk	w10, #0x3d37, lsl #16
     5c4:      	fmov	s2, w10
     5c8:      	fmul.4s	v2, v3, v2
     5cc:      	fmul.4s	v2, v4, v2
     5d0:      	fmul.4s	v2, v4, v2
     5d4:      	fadd.4s	v2, v4, v2
     5d8:      	mov	w10, #0x422a            ; =16938
     5dc:      	movk	w10, #0x3f4c, lsl #16
     5e0:      	fmov	s4, w10
     5e4:      	fmul.4s	v2, v2, v4
     5e8:      	mov.s	v0[0], v2[0]
     5ec:      	fabs.4s	v4, v0
     5f0:      	fmul.4s	v5, v0, v0
     5f4:      	mov	w10, #0x9231            ; =37425
     5f8:      	movk	w10, #0x2f30, lsl #16
     5fc:      	dup.4s	v2, w10
     600:      	mov	w10, #0x322b            ; =12843
     604:      	movk	w10, #0x32d7, lsl #16
     608:      	dup.4s	v6, w10
     60c:      	mov	w10, #0xef1d            ; =61213
     610:      	movk	w10, #0x3638, lsl #16
     614:      	dup.4s	v7, w10
     618:      	fmla.4s	v6, v5, v2
     61c:      	fmla.4s	v7, v5, v6
     620:      	mov	w10, #0xd01             ; =3329
     624:      	movk	w10, #0x3950, lsl #16
     628:      	dup.4s	v2, w10
     62c:      	fmla.4s	v2, v5, v7
     630:      	mov	w10, #0x8889            ; =34953
     634:      	movk	w10, #0x3c08, lsl #16
     638:      	dup.4s	v17, w10
     63c:      	mov	w10, #0xaaab            ; =43691
     640:      	movk	w10, #0x3e2a, lsl #16
     644:      	dup.4s	v18, w10
     648:      	fmla.4s	v17, v5, v2
     64c:      	ldr	q2, [sp, #0x110]
     650:      	fcmge.4s	v6, v2, v4
     654:      	and.16b	v7, v6, v4
     658:      	mov	w10, #-0x3d300000       ; =-1026555904
     65c:      	dup.4s	v2, w10
     660:      	fcmge.4s	v2, v7, v2
     664:      	mov	w10, #0x42c80000        ; =1120403456
     668:      	dup.4s	v16, w10
     66c:      	fcmge.4s	v20, v16, v7
     670:      	and.16b	v2, v2, v20
     674:      	and.16b	v2, v2, v7
     678:      	mov	w10, #0xaa3b            ; =43579
     67c:      	movk	w10, #0x3fb8, lsl #16
     680:      	dup.4s	v20, w10
     684:      	fmul.4s	v20, v2, v20
     688:      	movi.4s	v21, #0x4b, lsl #24
     68c:      	fadd.4s	v20, v20, v21
     690:      	movi.4s	v21, #0xcb, lsl #24
     694:      	fadd.4s	v20, v20, v21
     698:      	fcvtzs.4s	v20, v20
     69c:      	scvtf.4s	v21, v20
     6a0:      	mov	w10, #0x7200            ; =29184
     6a4:      	movk	w10, #0xbf31, lsl #16
     6a8:      	dup.4s	v22, w10
     6ac:      	fmul.4s	v22, v21, v22
     6b0:      	mov	w10, #0xbe8e            ; =48782
     6b4:      	movk	w10, #0xb5bf, lsl #16
     6b8:      	dup.4s	v23, w10
     6bc:      	fadd.4s	v2, v2, v22
     6c0:      	fmul.4s	v21, v21, v23
     6c4:      	fadd.4s	v2, v2, v21
     6c8:      	mov	w10, #0x2bda            ; =11226
     6cc:      	movk	w10, #0x3950, lsl #16
     6d0:      	dup.4s	v21, w10
     6d4:      	fmul.4s	v21, v2, v21
     6d8:      	mov	w10, #0x96c9            ; =38601
     6dc:      	movk	w10, #0x3ab6, lsl #16
     6e0:      	dup.4s	v22, w10
     6e4:      	fadd.4s	v21, v21, v22
     6e8:      	fmul.4s	v21, v2, v21
     6ec:      	mov	w10, #0x88a6            ; =34982
     6f0:      	movk	w10, #0x3c08, lsl #16
     6f4:      	dup.4s	v22, w10
     6f8:      	fadd.4s	v21, v21, v22
     6fc:      	fmul.4s	v21, v2, v21
     700:      	mov	w10, #0xaa7a            ; =43642
     704:      	movk	w10, #0x3d2a, lsl #16
     708:      	dup.4s	v22, w10
     70c:      	fadd.4s	v21, v21, v22
     710:      	fmul.4s	v21, v2, v21
     714:      	fadd.4s	v21, v21, v18
     718:      	fmla.4s	v18, v5, v17
     71c:      	mov.16b	v17, v19
     720:      	fmla.4s	v17, v5, v18
     724:      	mov	w10, #0x76c7            ; =30407
     728:      	movk	w10, #0x310f, lsl #16
     72c:      	dup.4s	v18, w10
     730:      	mov	w10, #0xf27e            ; =62078
     734:      	movk	w10, #0x3493, lsl #16
     738:      	dup.4s	v22, w10
     73c:      	mov	w10, #0xd01             ; =3329
     740:      	movk	w10, #0x37d0, lsl #16
     744:      	dup.4s	v23, w10
     748:      	fmla.4s	v22, v5, v18
     74c:      	fmla.4s	v23, v5, v22
     750:      	mov	w10, #0xb61             ; =2913
     754:      	movk	w10, #0x3ab6, lsl #16
     758:      	dup.4s	v18, w10
     75c:      	fmla.4s	v18, v5, v23
     760:      	mov	w10, #0xaaab            ; =43691
     764:      	movk	w10, #0x3d2a, lsl #16
     768:      	dup.4s	v22, w10
     76c:      	fmla.4s	v22, v5, v18
     770:      	movi.4s	v18, #0x3f, lsl #24
     774:      	fmla.4s	v18, v5, v22
     778:      	mov.16b	v22, v19
     77c:      	fmla.4s	v22, v5, v18
     780:      	movi.4s	v5, #0x3f, lsl #24
     784:      	fmul.4s	v3, v3, v5
     788:      	fcmge.4s	v18, v19, v4
     78c:      	fmul.4s	v4, v4, v17
     790:      	fdiv.4s	v4, v4, v22
     794:      	fmul.4s	v17, v2, v21
     798:      	fadd.4s	v5, v17, v5
     79c:      	fmul.4s	v17, v2, v2
     7a0:      	fmul.4s	v5, v17, v5
     7a4:      	fadd.4s	v2, v2, v5
     7a8:      	fadd.4s	v2, v2, v19
     7ac:      	movi.2d	v5, #0xffffffffffffffff
     7b0:      	add.4s	v5, v20, v5
     7b4:      	sshr.4s	v17, v5, #0x1
     7b8:      	shl.4s	v20, v17, #0x17
     7bc:      	add.4s	v20, v20, v19
     7c0:      	fmul.4s	v2, v2, v20
     7c4:      	sub.4s	v5, v5, v17
     7c8:      	shl.4s	v5, v5, #0x17
     7cc:      	add.4s	v5, v5, v19
     7d0:      	fmul.4s	v2, v2, v5
     7d4:      	fcmgt.4s	v5, v7, v16
     7d8:      	mvni.4s	v7, #0x7f, msl #16
     7dc:      	fneg.4s	v7, v7
     7e0:      	bit.16b	v2, v7, v5
     7e4:      	fdiv.4s	v1, v1, v2
     7e8:      	fsub.4s	v5, v2, v1
     7ec:      	fadd.4s	v1, v2, v1
     7f0:      	fdiv.4s	v1, v5, v1
     7f4:      	bif.16b	v1, v19, v6
     7f8:      	bit.16b	v1, v4, v18
     7fc:      	mvni.4s	v2, #0x80, lsl #24
     800:      	bif.16b	v1, v0, v2
     804:      	fcmeq.4s	v0, v0, v0
     808:      	fadd.4s	v1, v1, v19
     80c:      	mvni.4s	v2, #0x3f, msl #16
     810:      	fneg.4s	v2, v2
     814:      	bsl.16b	v0, v1, v2
     818:      	fmul.4s	v0, v3, v0
     81c:      	ldr	q1, [sp, #0x10]
     820:      	fadd.4s	v0, v0, v1
     824:      	b	0xf00 <ltmp0+0xf00>
     828:      	mov	x11, #0x0               ; =0
     82c:      	add	x13, x8, x9
     830:      	add	x14, x10, x9
     834:      	mov	w15, #0x2713            ; =10003
     838:      	movk	w15, #0x3d37, lsl #16
     83c:      	dup.4s	v1, w15
     840:      	mov	w15, #0x422a            ; =16938
     844:      	movk	w15, #0x3f4c, lsl #16
     848:      	dup.4s	v0, w15
     84c:      	stp	q0, q1, [sp, #0xf0]
     850:      	mov	w15, #0x9231            ; =37425
     854:      	movk	w15, #0x2f30, lsl #16
     858:      	dup.4s	v1, w15
     85c:      	mov	w15, #0x322b            ; =12843
     860:      	movk	w15, #0x32d7, lsl #16
     864:      	dup.4s	v0, w15
     868:      	stp	q0, q1, [sp, #0xd0]
     86c:      	mov	w15, #0xef1d            ; =61213
     870:      	movk	w15, #0x3638, lsl #16
     874:      	dup.4s	v1, w15
     878:      	mov	w15, #0xd01             ; =3329
     87c:      	movk	w15, #0x3950, lsl #16
     880:      	dup.4s	v0, w15
     884:      	stp	q0, q1, [sp, #0xb0]
     888:      	mov	w15, #0x8889            ; =34953
     88c:      	movk	w15, #0x3c08, lsl #16
     890:      	dup.4s	v1, w15
     894:      	mov	w15, #0xaaab            ; =43691
     898:      	movk	w15, #0x3e2a, lsl #16
     89c:      	dup.4s	v20, w15
     8a0:      	mov	w15, #0x76c7            ; =30407
     8a4:      	movk	w15, #0x310f, lsl #16
     8a8:      	dup.4s	v0, w15
     8ac:      	stp	q0, q1, [sp, #0x90]
     8b0:      	mov	w15, #0xf27e            ; =62078
     8b4:      	movk	w15, #0x3493, lsl #16
     8b8:      	dup.4s	v1, w15
     8bc:      	mov	w15, #0xd01             ; =3329
     8c0:      	movk	w15, #0x37d0, lsl #16
     8c4:      	dup.4s	v0, w15
     8c8:      	stp	q0, q1, [sp, #0x70]
     8cc:      	mov	w15, #0xb61             ; =2913
     8d0:      	movk	w15, #0x3ab6, lsl #16
     8d4:      	dup.4s	v1, w15
     8d8:      	mov	w15, #0xaaab            ; =43691
     8dc:      	movk	w15, #0x3d2a, lsl #16
     8e0:      	dup.4s	v0, w15
     8e4:      	stp	q0, q1, [sp, #0x50]
     8e8:      	mov	w15, #-0x3d300000       ; =-1026555904
     8ec:      	dup.4s	v1, w15
     8f0:      	mov	w15, #0x42c80000        ; =1120403456
     8f4:      	dup.4s	v24, w15
     8f8:      	mov	w15, #0xaa3b            ; =43579
     8fc:      	movk	w15, #0x3fb8, lsl #16
     900:      	dup.4s	v0, w15
     904:      	stp	q0, q1, [sp, #0x30]
     908:      	mov	w15, #0x7200            ; =29184
     90c:      	movk	w15, #0xbf31, lsl #16
     910:      	dup.4s	v1, w15
     914:      	mov	w15, #0xbe8e            ; =48782
     918:      	movk	w15, #0xb5bf, lsl #16
     91c:      	dup.4s	v0, w15
     920:      	stp	q0, q1, [sp, #0x10]
     924:      	mov	w15, #0x2bda            ; =11226
     928:      	movk	w15, #0x3950, lsl #16
     92c:      	dup.4s	v28, w15
     930:      	mov	w15, #0x96c9            ; =38601
     934:      	movk	w15, #0x3ab6, lsl #16
     938:      	dup.4s	v29, w15
     93c:      	mov	w15, #0x88a6            ; =34982
     940:      	movk	w15, #0x3c08, lsl #16
     944:      	dup.4s	v30, w15
     948:      	mov	w15, #0xaa7a            ; =43642
     94c:      	movk	w15, #0x3d2a, lsl #16
     950:      	dup.4s	v31, w15
     954:      	add	x15, x12, x9
     958:      	movi.4s	v8, #0x3f, lsl #24
     95c:      	fmov.4s	v18, #1.00000000
     960:      	fmov.4s	v0, #9.00000000
     964:      	str	q0, [sp, #0x110]
     968:      	mvni.4s	v0, #0x7f, msl #16
     96c:      	fneg.4s	v12, v0
     970:      	mvni.4s	v0, #0x3f, msl #16
     974:      	fneg.4s	v14, v0
     978:      	add	x16, x15, x11
     97c:      	ldp	q9, q10, [x16]
     980:      	ldp	q2, q1, [sp, #0xf0]
     984:      	fmul.4s	v0, v9, v1
     988:      	fmul.4s	v1, v10, v1
     98c:      	fmul.4s	v1, v10, v1
     990:      	fmul.4s	v0, v9, v0
     994:      	fmul.4s	v0, v9, v0
     998:      	fmul.4s	v1, v10, v1
     99c:      	fadd.4s	v1, v10, v1
     9a0:      	fadd.4s	v0, v9, v0
     9a4:      	fmul.4s	v13, v0, v2
     9a8:      	fmul.4s	v11, v1, v2
     9ac:      	fabs.4s	v2, v11
     9b0:      	fabs.4s	v1, v13
     9b4:      	fmul.4s	v16, v13, v13
     9b8:      	ldp	q3, q4, [sp, #0xd0]
     9bc:      	mov.16b	v0, v3
     9c0:      	fmul.4s	v19, v11, v11
     9c4:      	fmla.4s	v0, v16, v4
     9c8:      	fmla.4s	v3, v19, v4
     9cc:      	ldr	q5, [sp, #0xc0]
     9d0:      	mov.16b	v4, v5
     9d4:      	fmla.4s	v4, v16, v0
     9d8:      	fmla.4s	v5, v19, v3
     9dc:      	ldr	q0, [sp, #0xb0]
     9e0:      	mov.16b	v3, v0
     9e4:      	fmla.4s	v3, v16, v4
     9e8:      	mov.16b	v4, v0
     9ec:      	ldp	q22, q0, [sp, #0x90]
     9f0:      	mov.16b	v6, v0
     9f4:      	fmla.4s	v4, v19, v5
     9f8:      	mov.16b	v5, v0
     9fc:      	mov.16b	v17, v20
     a00:      	mov.16b	v7, v20
     a04:      	mov.16b	v0, v18
     a08:      	mov.16b	v25, v18
     a0c:      	fmla.4s	v6, v16, v3
     a10:      	ldp	q23, q21, [sp, #0x70]
     a14:      	mov.16b	v3, v21
     a18:      	fmla.4s	v3, v19, v22
     a1c:      	fmla.4s	v21, v16, v22
     a20:      	mov.16b	v22, v23
     a24:      	fmla.4s	v5, v19, v4
     a28:      	fmla.4s	v22, v19, v3
     a2c:      	mov.16b	v3, v23
     a30:      	fmla.4s	v3, v16, v21
     a34:      	ldr	q21, [sp, #0x60]
     a38:      	mov.16b	v4, v21
     a3c:      	fmla.4s	v4, v19, v22
     a40:      	fmla.4s	v17, v16, v6
     a44:      	mov.16b	v6, v21
     a48:      	fmla.4s	v6, v16, v3
     a4c:      	ldr	q21, [sp, #0x50]
     a50:      	mov.16b	v3, v21
     a54:      	fmla.4s	v3, v19, v4
     a58:      	fmla.4s	v7, v19, v5
     a5c:      	fmla.4s	v21, v16, v6
     a60:      	movi.4s	v22, #0x3f, lsl #24
     a64:      	fmla.4s	v22, v19, v3
     a68:      	movi.4s	v23, #0x3f, lsl #24
     a6c:      	mov.16b	v5, v18
     a70:      	fmla.4s	v25, v19, v7
     a74:      	mov.16b	v15, v18
     a78:      	ldr	q4, [sp, #0x110]
     a7c:      	fcmge.4s	v3, v4, v1
     a80:      	fcmge.4s	v4, v4, v2
     a84:      	and.16b	v6, v4, v2
     a88:      	and.16b	v7, v3, v1
     a8c:      	fmla.4s	v5, v19, v22
     a90:      	ldr	q22, [sp, #0x40]
     a94:      	fcmge.4s	v19, v7, v22
     a98:      	fcmge.4s	v22, v6, v22
     a9c:      	fcmge.4s	v26, v24, v6
     aa0:      	and.16b	v22, v22, v26
     aa4:      	fcmge.4s	v26, v24, v7
     aa8:      	fmla.4s	v23, v16, v21
     aac:      	and.16b	v19, v19, v26
     ab0:      	and.16b	v19, v19, v7
     ab4:      	and.16b	v21, v22, v6
     ab8:      	ldr	q26, [sp, #0x30]
     abc:      	fmul.4s	v22, v21, v26
     ac0:      	fmul.4s	v26, v19, v26
     ac4:      	fmla.4s	v0, v16, v17
     ac8:      	movi.4s	v27, #0x4b, lsl #24
     acc:      	fadd.4s	v17, v26, v27
     ad0:      	fadd.4s	v22, v22, v27
     ad4:      	movi.4s	v26, #0xcb, lsl #24
     ad8:      	fadd.4s	v22, v22, v26
     adc:      	fadd.4s	v17, v17, v26
     ae0:      	fcvtzs.4s	v17, v17
     ae4:      	fmla.4s	v15, v16, v23
     ae8:      	fcvtzs.4s	v22, v22
     aec:      	scvtf.4s	v16, v22
     af0:      	scvtf.4s	v23, v17
     af4:      	ldr	q27, [sp, #0x20]
     af8:      	fmul.4s	v26, v16, v27
     afc:      	fadd.4s	v21, v21, v26
     b00:      	fmul.4s	v26, v23, v27
     b04:      	fadd.4s	v19, v19, v26
     b08:      	ldr	q26, [sp, #0x10]
     b0c:      	fmul.4s	v16, v16, v26
     b10:      	fmul.4s	v23, v23, v26
     b14:      	fadd.4s	v19, v19, v23
     b18:      	fadd.4s	v21, v21, v16
     b1c:      	fmul.4s	v16, v21, v28
     b20:      	fmul.4s	v23, v19, v28
     b24:      	fadd.4s	v23, v23, v29
     b28:      	fadd.4s	v16, v16, v29
     b2c:      	fmul.4s	v16, v21, v16
     b30:      	fmul.4s	v23, v19, v23
     b34:      	fmul.4s	v0, v1, v0
     b38:      	fadd.4s	v23, v23, v30
     b3c:      	fadd.4s	v16, v16, v30
     b40:      	fmul.4s	v26, v21, v16
     b44:      	fmul.4s	v16, v19, v23
     b48:      	fadd.4s	v23, v16, v31
     b4c:      	fdiv.4s	v16, v0, v15
     b50:      	fadd.4s	v0, v26, v31
     b54:      	fmul.4s	v0, v21, v0
     b58:      	fmul.4s	v23, v19, v23
     b5c:      	fadd.4s	v23, v23, v20
     b60:      	fadd.4s	v0, v0, v20
     b64:      	fmul.4s	v0, v21, v0
     b68:      	fmul.4s	v23, v19, v23
     b6c:      	fadd.4s	v23, v23, v8
     b70:      	fadd.4s	v0, v0, v8
     b74:      	fmul.4s	v26, v21, v21
     b78:      	fmul.4s	v0, v26, v0
     b7c:      	fmul.4s	v26, v19, v19
     b80:      	fmul.4s	v23, v26, v23
     b84:      	fadd.4s	v19, v19, v23
     b88:      	fadd.4s	v0, v21, v0
     b8c:      	fadd.4s	v0, v0, v18
     b90:      	movi.2d	v21, #0xffffffffffffffff
     b94:      	add.4s	v17, v17, v21
     b98:      	fadd.4s	v19, v19, v18
     b9c:      	add.4s	v21, v22, v21
     ba0:      	sshr.4s	v22, v21, #0x1
     ba4:      	sshr.4s	v23, v17, #0x1
     ba8:      	shl.4s	v26, v23, #0x17
     bac:      	add.4s	v26, v26, v18
     bb0:      	fmul.4s	v19, v19, v26
     bb4:      	shl.4s	v26, v22, #0x17
     bb8:      	add.4s	v26, v26, v18
     bbc:      	fmul.4s	v0, v0, v26
     bc0:      	sub.4s	v17, v17, v23
     bc4:      	sub.4s	v21, v21, v22
     bc8:      	shl.4s	v21, v21, #0x17
     bcc:      	add.4s	v21, v21, v18
     bd0:      	fmul.4s	v0, v0, v21
     bd4:      	shl.4s	v17, v17, #0x17
     bd8:      	add.4s	v17, v17, v18
     bdc:      	fmul.4s	v17, v19, v17
     be0:      	fmul.4s	v19, v2, v25
     be4:      	fcmgt.4s	v6, v6, v24
     be8:      	fcmgt.4s	v7, v7, v24
     bec:      	bsl.16b	v7, v12, v17
     bf0:      	bsl.16b	v6, v12, v0
     bf4:      	fmov.4s	v0, #0.25000000
     bf8:      	fdiv.4s	v5, v19, v5
     bfc:      	fdiv.4s	v17, v0, v6
     c00:      	fsub.4s	v19, v6, v17
     c04:      	fadd.4s	v6, v6, v17
     c08:      	fdiv.4s	v6, v19, v6
     c0c:      	bsl.16b	v4, v6, v18
     c10:      	fcmge.4s	v2, v18, v2
     c14:      	bsl.16b	v2, v5, v4
     c18:      	fdiv.4s	v4, v0, v7
     c1c:      	fsub.4s	v5, v7, v4
     c20:      	fadd.4s	v4, v7, v4
     c24:      	fdiv.4s	v4, v5, v4
     c28:      	bsl.16b	v3, v4, v18
     c2c:      	fcmge.4s	v1, v18, v1
     c30:      	bsl.16b	v1, v16, v3
     c34:      	mvni.4s	v4, #0x80, lsl #24
     c38:      	bif.16b	v1, v13, v4
     c3c:      	fcmeq.4s	v3, v13, v13
     c40:      	fadd.4s	v1, v1, v18
     c44:      	bif.16b	v1, v14, v3
     c48:      	bif.16b	v2, v11, v4
     c4c:      	fcmeq.4s	v3, v11, v11
     c50:      	fadd.4s	v2, v2, v18
     c54:      	bif.16b	v2, v14, v3
     c58:      	fmul.4s	v3, v10, v8
     c5c:      	fmul.4s	v2, v3, v2
     c60:      	fmul.4s	v3, v9, v8
     c64:      	fmul.4s	v1, v3, v1
     c68:      	add	x16, x14, x11
     c6c:      	ldp	q4, q3, [x16]
     c70:      	fadd.4s	v1, v4, v1
     c74:      	fadd.4s	v2, v3, v2
     c78:      	add	x16, x13, x11
     c7c:      	stp	q1, q2, [x16]
     c80:      	add	x11, x11, #0x20
     c84:      	cmp	x11, #0x100
     c88:      	b.ne	0x978 <ltmp0+0x978>
     c8c:      	add	x9, x9, #0x100
     c90:      	ldr	s2, [x12, x9]
     c94:      	movi.2d	v1, #0000000000000000
     c98:      	mov	w11, #0x2713            ; =10003
     c9c:      	movk	w11, #0x3d37, lsl #16
     ca0:      	fmov	s3, w11
     ca4:      	fmul.4s	v3, v2, v3
     ca8:      	fmul.4s	v3, v2, v3
     cac:      	fmul.4s	v3, v2, v3
     cb0:      	fadd.4s	v3, v2, v3
     cb4:      	mov	w11, #0x422a            ; =16938
     cb8:      	movk	w11, #0x3f4c, lsl #16
     cbc:      	fmov	s4, w11
     cc0:      	fmul.4s	v3, v3, v4
     cc4:      	mov.s	v1[0], v3[0]
     cc8:      	fabs.4s	v3, v1
     ccc:      	mov	w11, #0x9231            ; =37425
     cd0:      	movk	w11, #0x2f30, lsl #16
     cd4:      	dup.4s	v5, w11
     cd8:      	mov	w11, #0x322b            ; =12843
     cdc:      	movk	w11, #0x32d7, lsl #16
     ce0:      	dup.4s	v6, w11
     ce4:      	fmul.4s	v4, v1, v1
     ce8:      	fmla.4s	v6, v4, v5
     cec:      	mov	w11, #0xef1d            ; =61213
     cf0:      	movk	w11, #0x3638, lsl #16
     cf4:      	dup.4s	v5, w11
     cf8:      	fmla.4s	v5, v4, v6
     cfc:      	mov	w11, #0xd01             ; =3329
     d00:      	movk	w11, #0x3950, lsl #16
     d04:      	dup.4s	v6, w11
     d08:      	mov	w11, #0x8889            ; =34953
     d0c:      	movk	w11, #0x3c08, lsl #16
     d10:      	dup.4s	v16, w11
     d14:      	fmla.4s	v6, v4, v5
     d18:      	fmla.4s	v16, v4, v6
     d1c:      	mov	w11, #0xaaab            ; =43691
     d20:      	movk	w11, #0x3e2a, lsl #16
     d24:      	dup.4s	v17, w11
     d28:      	ldr	q5, [sp, #0x110]
     d2c:      	fcmge.4s	v5, v5, v3
     d30:      	and.16b	v6, v5, v3
     d34:      	mov	w11, #-0x3d300000       ; =-1026555904
     d38:      	dup.4s	v7, w11
     d3c:      	fcmge.4s	v19, v6, v7
     d40:      	mov	w11, #0x42c80000        ; =1120403456
     d44:      	dup.4s	v7, w11
     d48:      	fcmge.4s	v20, v7, v6
     d4c:      	and.16b	v19, v19, v20
     d50:      	and.16b	v19, v19, v6
     d54:      	mov	w11, #0xaa3b            ; =43579
     d58:      	movk	w11, #0x3fb8, lsl #16
     d5c:      	dup.4s	v20, w11
     d60:      	fmul.4s	v20, v19, v20
     d64:      	movi.4s	v21, #0x4b, lsl #24
     d68:      	fadd.4s	v20, v20, v21
     d6c:      	movi.4s	v21, #0xcb, lsl #24
     d70:      	fadd.4s	v20, v20, v21
     d74:      	fcvtzs.4s	v20, v20
     d78:      	scvtf.4s	v21, v20
     d7c:      	mov	w11, #0x7200            ; =29184
     d80:      	movk	w11, #0xbf31, lsl #16
     d84:      	dup.4s	v22, w11
     d88:      	fmul.4s	v22, v21, v22
     d8c:      	fadd.4s	v19, v19, v22
     d90:      	mov	w11, #0xbe8e            ; =48782
     d94:      	movk	w11, #0xb5bf, lsl #16
     d98:      	dup.4s	v22, w11
     d9c:      	fmul.4s	v21, v21, v22
     da0:      	fadd.4s	v19, v19, v21
     da4:      	mov	w11, #0x2bda            ; =11226
     da8:      	movk	w11, #0x3950, lsl #16
     dac:      	dup.4s	v21, w11
     db0:      	fmul.4s	v21, v19, v21
     db4:      	mov	w11, #0x96c9            ; =38601
     db8:      	movk	w11, #0x3ab6, lsl #16
     dbc:      	dup.4s	v22, w11
     dc0:      	fadd.4s	v21, v21, v22
     dc4:      	mov	w11, #0x88a6            ; =34982
     dc8:      	movk	w11, #0x3c08, lsl #16
     dcc:      	dup.4s	v22, w11
     dd0:      	fmul.4s	v21, v19, v21
     dd4:      	fadd.4s	v21, v21, v22
     dd8:      	fmul.4s	v21, v19, v21
     ddc:      	mov	w11, #0xaa7a            ; =43642
     de0:      	movk	w11, #0x3d2a, lsl #16
     de4:      	dup.4s	v22, w11
     de8:      	fadd.4s	v21, v21, v22
     dec:      	fmul.4s	v21, v19, v21
     df0:      	fadd.4s	v21, v21, v17
     df4:      	fmla.4s	v17, v4, v16
     df8:      	mov.16b	v16, v18
     dfc:      	mov	w11, #0x76c7            ; =30407
     e00:      	movk	w11, #0x310f, lsl #16
     e04:      	dup.4s	v22, w11
     e08:      	mov	w11, #0xf27e            ; =62078
     e0c:      	movk	w11, #0x3493, lsl #16
     e10:      	dup.4s	v23, w11
     e14:      	fmla.4s	v16, v4, v17
     e18:      	fmla.4s	v23, v4, v22
     e1c:      	mov	w11, #0xd01             ; =3329
     e20:      	movk	w11, #0x37d0, lsl #16
     e24:      	dup.4s	v17, w11
     e28:      	fmla.4s	v17, v4, v23
     e2c:      	mov	w11, #0xb61             ; =2913
     e30:      	movk	w11, #0x3ab6, lsl #16
     e34:      	dup.4s	v22, w11
     e38:      	mov	w11, #0xaaab            ; =43691
     e3c:      	movk	w11, #0x3d2a, lsl #16
     e40:      	dup.4s	v23, w11
     e44:      	fmla.4s	v22, v4, v17
     e48:      	fmla.4s	v23, v4, v22
     e4c:      	movi.4s	v17, #0x3f, lsl #24
     e50:      	fmla.4s	v17, v4, v23
     e54:      	mov.16b	v22, v18
     e58:      	fmla.4s	v22, v4, v17
     e5c:      	movi.4s	v4, #0x3f, lsl #24
     e60:      	fmul.4s	v2, v2, v4
     e64:      	fcmge.4s	v17, v18, v3
     e68:      	fmul.4s	v3, v3, v16
     e6c:      	fdiv.4s	v3, v3, v22
     e70:      	fmul.4s	v16, v19, v21
     e74:      	fadd.4s	v4, v16, v4
     e78:      	fmul.4s	v16, v19, v19
     e7c:      	fmul.4s	v4, v16, v4
     e80:      	fadd.4s	v4, v19, v4
     e84:      	fadd.4s	v4, v4, v18
     e88:      	movi.2d	v16, #0xffffffffffffffff
     e8c:      	add.4s	v16, v20, v16
     e90:      	sshr.4s	v19, v16, #0x1
     e94:      	shl.4s	v20, v19, #0x17
     e98:      	add.4s	v20, v20, v18
     e9c:      	fmul.4s	v4, v4, v20
     ea0:      	sub.4s	v16, v16, v19
     ea4:      	shl.4s	v16, v16, #0x17
     ea8:      	add.4s	v16, v16, v18
     eac:      	fmul.4s	v4, v4, v16
     eb0:      	fcmgt.4s	v6, v6, v7
     eb4:      	mvni.4s	v7, #0x7f, msl #16
     eb8:      	fneg.4s	v7, v7
     ebc:      	bit.16b	v4, v7, v6
     ec0:      	fdiv.4s	v0, v0, v4
     ec4:      	fsub.4s	v6, v4, v0
     ec8:      	fadd.4s	v0, v4, v0
     ecc:      	fdiv.4s	v0, v6, v0
     ed0:      	bif.16b	v0, v18, v5
     ed4:      	bit.16b	v0, v3, v17
     ed8:      	mvni.4s	v3, #0x80, lsl #24
     edc:      	bif.16b	v0, v1, v3
     ee0:      	fcmeq.4s	v1, v1, v1
     ee4:      	fadd.4s	v0, v0, v18
     ee8:      	mvni.4s	v3, #0x3f, msl #16
     eec:      	fneg.4s	v3, v3
     ef0:      	bif.16b	v0, v3, v1
     ef4:      	fmul.4s	v0, v2, v0
     ef8:      	ldr	s1, [x10, x9]
     efc:      	fadd.4s	v0, v1, v0
     f00:      	str	s0, [x8, x9]
     f04:      	add	sp, sp, #0x360
     f08:      	ldp	x28, x27, [sp, #0x40]
     f0c:      	ldp	d9, d8, [sp, #0x30]
     f10:      	ldp	d11, d10, [sp, #0x20]
     f14:      	ldp	d13, d12, [sp, #0x10]
     f18:      	ldp	d15, d14, [sp], #0x50
     f1c:      	ret

0000000000000f20 <_llm_rows.packet_batch.blocks>:
     f20:      	stp	d15, d14, [sp, #-0xa0]!
     f24:      	stp	d13, d12, [sp, #0x10]
     f28:      	stp	d11, d10, [sp, #0x20]
     f2c:      	stp	d9, d8, [sp, #0x30]
     f30:      	stp	x28, x27, [sp, #0x40]
     f34:      	stp	x26, x25, [sp, #0x50]
     f38:      	stp	x24, x23, [sp, #0x60]
     f3c:      	stp	x22, x21, [sp, #0x70]
     f40:      	stp	x20, x19, [sp, #0x80]
     f44:      	stp	x29, x30, [sp, #0x90]
     f48:      	sub	sp, sp, #0x620
     f4c:      	str	x0, [sp, #0x118]
     f50:      	cbz	w3, 0x2b94 <_llm_rows.packet_batch.blocks+0x1c74>
     f54:      	mov	x19, x3
     f58:      	mov	x20, x2
     f5c:      	mov	w22, #0x0               ; =0
     f60:      	ldp	w9, w8, [x2, #0x2c]
     f64:      	str	w9, [sp, #0x114]
     f68:      	str	w8, [sp, #0x110]
     f6c:      	ldp	w26, w27, [x2]
     f70:      	adrp	x8, 0x0 <ltmp0>
     f74:      	ldr	q0, [x8]
     f78:      	str	q0, [sp, #0xa0]
     f7c:      	adrp	x8, 0x0 <ltmp0>
     f80:      	ldr	q0, [x8]
     f84:      	str	q0, [sp, #0x90]
     f88:      	adrp	x8, 0x0 <ltmp0>
     f8c:      	ldr	q0, [x8]
     f90:      	str	q0, [sp, #0x80]
     f94:      	adrp	x8, 0x0 <ltmp0>
     f98:      	ldr	q0, [x8]
     f9c:      	str	q0, [sp, #0x70]
     fa0:      	adrp	x8, 0x0 <ltmp0>
     fa4:      	ldr	q0, [x8]
     fa8:      	str	q0, [sp, #0x60]
     fac:      	adrp	x8, 0x0 <ltmp0>
     fb0:      	ldr	q0, [x8]
     fb4:      	str	q0, [sp, #0x50]
     fb8:      	adrp	x8, 0x0 <ltmp0>
     fbc:      	ldr	q0, [x8]
     fc0:      	str	q0, [sp, #0x120]
     fc4:      	mvni.4s	v0, #0x7f, msl #16
     fc8:      	fneg.4s	v1, v0
     fcc:      	mvni.4s	v0, #0x3f, msl #16
     fd0:      	fneg.4s	v0, v0
     fd4:      	stp	q0, q1, [sp, #0x1a0]
     fd8:      	add	x23, sp, #0x500
     fdc:      	ldp	w28, w24, [x2, #0x8]
     fe0:      	add	x25, sp, #0x3e0
     fe4:      	str	w3, [sp, #0x10c]
     fe8:      	b	0x1034 <_llm_rows.packet_batch.blocks+0x114>
     fec:      	mov	w8, #0x18               ; =24
     ff0:      	str	w8, [x20, #0x24]
     ff4:      	ldr	w19, [sp, #0x10c]
     ff8:      	add	w8, w26, #0x1
     ffc:      	ldr	w9, [sp, #0x114]
    1000:      	cmp	w8, w9
    1004:      	cset	w8, eq
    1008:      	csinc	w26, wzr, w26, eq
    100c:      	cinc	w9, w27, eq
    1010:      	ldr	w10, [sp, #0x110]
    1014:      	cmp	w9, w10
    1018:      	cset	w10, eq
    101c:      	ands	w8, w8, w10
    1020:      	csel	w27, wzr, w9, ne
    1024:      	add	w28, w28, w8
    1028:      	add	w22, w22, #0x1
    102c:      	cmp	w22, w19
    1030:      	b.eq	0x2b94 <_llm_rows.packet_batch.blocks+0x1c74>
    1034:      	ubfiz	x8, x26, #5, #32
    1038:      	cmp	x8, x24
    103c:      	csel	x9, x8, xzr, ls
    1040:      	subs	x10, x24, x9
    1044:      	cmp	x10, #0x20
    1048:      	mov	w11, #0x20              ; =32
    104c:      	csel	x10, x10, x11, lo
    1050:      	cmp	x24, x9
    1054:      	stp	w26, w27, [x20]
    1058:      	str	w28, [x20, #0x8]
    105c:      	str	wzr, [x20, #0x24]
    1060:      	ccmp	x8, x24, #0x2, hi
    1064:      	csel	x21, x10, xzr, ls
    1068:      	cmp	x21, #0x20
    106c:      	b.lo	0x10c0 <_llm_rows.packet_batch.blocks+0x1a0>
    1070:      	ldr	x21, [sp, #0x118]
    1074:      	mov	x0, x21
    1078:      	mov	x1, x20
    107c:      	bl	0x107c <_llm_rows.packet_batch.blocks+0x15c>
    1080:      	mov	w8, #0x8                ; =8
    1084:      	str	w8, [x20, #0x24]
    1088:      	mov	x0, x21
    108c:      	mov	x1, x20
    1090:      	bl	0x1090 <_llm_rows.packet_batch.blocks+0x170>
    1094:      	mov	w8, #0x10               ; =16
    1098:      	str	w8, [x20, #0x24]
    109c:      	mov	x0, x21
    10a0:      	mov	x1, x20
    10a4:      	bl	0x10a4 <_llm_rows.packet_batch.blocks+0x184>
    10a8:      	mov	w8, #0x18               ; =24
    10ac:      	str	w8, [x20, #0x24]
    10b0:      	mov	x0, x21
    10b4:      	mov	x1, x20
    10b8:      	bl	0x10b8 <_llm_rows.packet_batch.blocks+0x198>
    10bc:      	b	0xff8 <_llm_rows.packet_batch.blocks+0xd8>
    10c0:      	lsr	x19, x21, #3
    10c4:      	cmp	x21, #0x8
    10c8:      	b.lo	0x1114 <_llm_rows.packet_batch.blocks+0x1f4>
    10cc:      	str	wzr, [x20, #0x24]
    10d0:      	ldr	x0, [sp, #0x118]
    10d4:      	mov	x1, x20
    10d8:      	bl	0x10d8 <_llm_rows.packet_batch.blocks+0x1b8>
    10dc:      	cmp	x19, #0x1
    10e0:      	b.eq	0x1114 <_llm_rows.packet_batch.blocks+0x1f4>
    10e4:      	mov	w8, #0x8                ; =8
    10e8:      	str	w8, [x20, #0x24]
    10ec:      	ldr	x0, [sp, #0x118]
    10f0:      	mov	x1, x20
    10f4:      	bl	0x10f4 <_llm_rows.packet_batch.blocks+0x1d4>
    10f8:      	cmp	x19, #0x2
    10fc:      	b.eq	0x1114 <_llm_rows.packet_batch.blocks+0x1f4>
    1100:      	mov	w8, #0x10               ; =16
    1104:      	str	w8, [x20, #0x24]
    1108:      	ldr	x0, [sp, #0x118]
    110c:      	mov	x1, x20
    1110:      	bl	0x1110 <_llm_rows.packet_batch.blocks+0x1f0>
    1114:      	and	w8, w21, #0x7
    1118:      	cbz	w8, 0xfec <_llm_rows.packet_batch.blocks+0xcc>
    111c:      	dup.4s	v0, w8
    1120:      	ldp	q2, q1, [sp, #0x90]
    1124:      	cmhi.4s	v19, v0, v2
    1128:      	cmhi.4s	v10, v0, v1
    112c:      	uzp1.8h	v3, v10, v19
    1130:      	umaxv.8h	h0, v3
    1134:      	fmov	w8, s0
    1138:      	tbz	w8, #0x0, 0xfec <_llm_rows.packet_batch.blocks+0xcc>
    113c:      	ldr	x8, [sp, #0x118]
    1140:      	ldr	x11, [x8]
    1144:      	ldr	x9, [x8, #0x10]
    1148:      	ldr	x8, [x8, #0x30]
    114c:      	sshll.2d	v0, v10, #0x0
    1150:      	sshll.2d	v1, v19, #0x0
    1154:      	sshll2.2d	v13, v10, #0x0
    1158:      	sshll2.2d	v12, v19, #0x0
    115c:      	ldp	q2, q4, [sp, #0x70]
    1160:      	and.16b	v18, v12, v4
    1164:      	and.16b	v17, v13, v2
    1168:      	ldp	q2, q4, [sp, #0x50]
    116c:      	and.16b	v16, v1, v4
    1170:      	ubfiz	w10, w26, #2, #27
    1174:      	orr	w10, w10, w19
    1178:      	dup.4s	v1, w10
    117c:      	and.16b	v0, v0, v2
    1180:      	str	q0, [sp, #0xb0]
    1184:      	and.16b	v0, v10, v1
    1188:      	and.16b	v1, v19, v1
    118c:      	ushll2.2d	v5, v1, #0x0
    1190:      	ushll2.2d	v4, v0, #0x0
    1194:      	ushll.2d	v6, v1, #0x0
    1198:      	ushll.2d	v0, v0, #0x0
    119c:      	subs	x10, x11, x8
    11a0:      	lsr	x10, x10, #2
    11a4:      	mov	w14, #0x450             ; =1104
    11a8:      	ccmp	x10, x14, #0x0, hs
    11ac:      	cset	w10, hi
    11b0:      	subs	x12, x8, x11
    11b4:      	lsr	x12, x12, #2
    11b8:      	ccmp	x12, x14, #0x0, hs
    11bc:      	mov	w12, #0x2713            ; =10003
    11c0:      	movk	w12, #0x3d37, lsl #16
    11c4:      	dup.4s	v2, w12
    11c8:      	mov	w12, #0x422a            ; =16938
    11cc:      	movk	w12, #0x3f4c, lsl #16
    11d0:      	dup.4s	v1, w12
    11d4:      	stp	q2, q1, [sp, #0x1c0]
    11d8:      	csinc	w12, w10, wzr, ls
    11dc:      	subs	x10, x9, x8
    11e0:      	mov	w13, #0x9231            ; =37425
    11e4:      	movk	w13, #0x2f30, lsl #16
    11e8:      	dup.4s	v1, w13
    11ec:      	str	q1, [sp, #0x210]
    11f0:      	mov	w13, #0x322b            ; =12843
    11f4:      	movk	w13, #0x32d7, lsl #16
    11f8:      	dup.4s	v1, w13
    11fc:      	str	q1, [sp, #0x230]
    1200:      	lsr	x10, x10, #2
    1204:      	ccmp	x10, x14, #0x0, hs
    1208:      	mov	w10, #0xef1d            ; =61213
    120c:      	movk	w10, #0x3638, lsl #16
    1210:      	dup.4s	v11, w10
    1214:      	mov	w10, #0xd01             ; =3329
    1218:      	movk	w10, #0x3950, lsl #16
    121c:      	dup.4s	v23, w10
    1220:      	cset	w10, hi
    1224:      	subs	x13, x8, x9
    1228:      	mov	w15, #0x8889            ; =34953
    122c:      	movk	w15, #0x3c08, lsl #16
    1230:      	dup.4s	v28, w15
    1234:      	mov	w15, #0xaaab            ; =43691
    1238:      	movk	w15, #0x3e2a, lsl #16
    123c:      	dup.4s	v1, w15
    1240:      	str	q1, [sp, #0x250]
    1244:      	lsr	x13, x13, #2
    1248:      	ccmp	x13, x14, #0x0, hs
    124c:      	csinc	w10, w10, wzr, ls
    1250:      	xtn.2s	v1, v0
    1254:      	str	d1, [sp, #0xf0]
    1258:      	fmov	x13, d0
    125c:      	add	x13, x13, x13, lsl #6
    1260:      	lsl	x14, x13, #2
    1264:      	fmov.4s	v0, #1.00000000
    1268:      	mov	w13, #0x76c7            ; =30407
    126c:      	movk	w13, #0x310f, lsl #16
    1270:      	dup.4s	v2, w13
    1274:      	mov	w13, #0xf27e            ; =62078
    1278:      	movk	w13, #0x3493, lsl #16
    127c:      	dup.4s	v1, w13
    1280:      	stp	q2, q1, [sp, #0x1e0]
    1284:      	mov	w13, #0xd01             ; =3329
    1288:      	movk	w13, #0x37d0, lsl #16
    128c:      	dup.4s	v1, w13
    1290:      	str	q1, [sp, #0x200]
    1294:      	mov	w13, #0xb61             ; =2913
    1298:      	movk	w13, #0x3ab6, lsl #16
    129c:      	dup.4s	v1, w13
    12a0:      	str	q1, [sp, #0x220]
    12a4:      	mov	w13, #0xaaab            ; =43691
    12a8:      	movk	w13, #0x3d2a, lsl #16
    12ac:      	dup.4s	v1, w13
    12b0:      	str	q1, [sp, #0x240]
    12b4:      	mov	w13, #-0x3d300000       ; =-1026555904
    12b8:      	dup.4s	v30, w13
    12bc:      	mov	w13, #0x42c80000        ; =1120403456
    12c0:      	dup.4s	v1, w13
    12c4:      	str	q1, [sp, #0x260]
    12c8:      	mov	w13, #0xaa3b            ; =43579
    12cc:      	movk	w13, #0x3fb8, lsl #16
    12d0:      	dup.4s	v29, w13
    12d4:      	mov	w13, #0x7200            ; =29184
    12d8:      	movk	w13, #0xbf31, lsl #16
    12dc:      	dup.4s	v9, w13
    12e0:      	mov	w13, #0xbe8e            ; =48782
    12e4:      	movk	w13, #0xb5bf, lsl #16
    12e8:      	dup.4s	v26, w13
    12ec:      	mov	w13, #0x2bda            ; =11226
    12f0:      	movk	w13, #0x3950, lsl #16
    12f4:      	dup.4s	v24, w13
    12f8:      	fmov.4s	v27, #9.00000000
    12fc:      	mov	w13, #0x96c9            ; =38601
    1300:      	movk	w13, #0x3ab6, lsl #16
    1304:      	dup.4s	v20, w13
    1308:      	xtn.2s	v1, v5
    130c:      	xtn.2s	v21, v6
    1310:      	xtn.2s	v8, v4
    1314:      	mov	w13, #0x88a6            ; =34982
    1318:      	movk	w13, #0x3c08, lsl #16
    131c:      	dup.4s	v22, w13
    1320:      	mov	w13, #0xaa7a            ; =43642
    1324:      	movk	w13, #0x3d2a, lsl #16
    1328:      	dup.4s	v25, w13
    132c:      	fmov.4s	v31, #0.25000000
    1330:      	cmp	w12, #0x1
    1334:      	stp	q19, q11, [sp, #0x180]
    1338:      	b.ne	0x1858 <_llm_rows.packet_batch.blocks+0x938>
    133c:      	cbz	w10, 0x1858 <_llm_rows.packet_batch.blocks+0x938>
    1340:      	str	d8, [sp, #0x20]
    1344:      	str	d21, [sp, #0x30]
    1348:      	str	d1, [sp, #0x40]
    134c:      	stp	q17, q16, [sp, #0xc0]
    1350:      	str	q18, [sp, #0xe0]
    1354:      	mov	x10, #0x0               ; =0
    1358:      	add	x12, x8, x14
    135c:      	add	x13, x9, x14
    1360:      	add	x14, x11, x14
    1364:      	ldr	q4, [sp, #0x120]
    1368:      	and.16b	v3, v3, v4
    136c:      	addv.8h	h12, v3
    1370:      	fmov	w15, s12
    1374:      	movi.4s	v2, #0x3f, lsl #24
    1378:      	b	0x1388 <_llm_rows.packet_batch.blocks+0x468>
    137c:      	add	x10, x10, #0x20
    1380:      	cmp	x10, #0x100
    1384:      	b.eq	0x25d4 <_llm_rows.packet_batch.blocks+0x16b4>
    1388:      	add	x16, x14, x10
    138c:      	movi.2d	v15, #0000000000000000
    1390:      	movi.2d	v13, #0000000000000000
    1394:      	tbz	w15, #0x0, 0x1428 <_llm_rows.packet_batch.blocks+0x508>
    1398:      	ldr	s15, [x16]
    139c:      	and	w17, w15, #0xff
    13a0:      	tbnz	w17, #0x1, 0x1430 <_llm_rows.packet_batch.blocks+0x510>
    13a4:      	tbz	w17, #0x2, 0x143c <_llm_rows.packet_batch.blocks+0x51c>
    13a8:      	add	x0, x16, #0x8
    13ac:      	ld1.s	{ v15 }[2], [x0]
    13b0:      	tbnz	w17, #0x3, 0x1440 <_llm_rows.packet_batch.blocks+0x520>
    13b4:      	tbz	w17, #0x4, 0x144c <_llm_rows.packet_batch.blocks+0x52c>
    13b8:      	add	x0, x16, #0x10
    13bc:      	ld1.s	{ v13 }[0], [x0]
    13c0:      	tbnz	w17, #0x5, 0x1450 <_llm_rows.packet_batch.blocks+0x530>
    13c4:      	tbz	w17, #0x6, 0x145c <_llm_rows.packet_batch.blocks+0x53c>
    13c8:      	add	x0, x16, #0x18
    13cc:      	ld1.s	{ v13 }[2], [x0]
    13d0:      	tbnz	w17, #0x7, 0x1460 <_llm_rows.packet_batch.blocks+0x540>
    13d4:      	fmov	w17, s12
    13d8:      	add	x16, x13, x10
    13dc:      	movi.2d	v3, #0000000000000000
    13e0:      	movi.2d	v14, #0000000000000000
    13e4:      	tbz	w17, #0x0, 0x147c <_llm_rows.packet_batch.blocks+0x55c>
    13e8:      	ldr	s3, [x16]
    13ec:      	and	w17, w17, #0xff
    13f0:      	tbnz	w17, #0x1, 0x1484 <_llm_rows.packet_batch.blocks+0x564>
    13f4:      	tbz	w17, #0x2, 0x1490 <_llm_rows.packet_batch.blocks+0x570>
    13f8:      	add	x0, x16, #0x8
    13fc:      	ld1.s	{ v3 }[2], [x0]
    1400:      	tbnz	w17, #0x3, 0x1494 <_llm_rows.packet_batch.blocks+0x574>
    1404:      	tbz	w17, #0x4, 0x14a0 <_llm_rows.packet_batch.blocks+0x580>
    1408:      	add	x0, x16, #0x10
    140c:      	ld1.s	{ v14 }[0], [x0]
    1410:      	tbnz	w17, #0x5, 0x14a4 <_llm_rows.packet_batch.blocks+0x584>
    1414:      	tbz	w17, #0x6, 0x14b0 <_llm_rows.packet_batch.blocks+0x590>
    1418:      	add	x0, x16, #0x18
    141c:      	ld1.s	{ v14 }[2], [x0]
    1420:      	tbnz	w17, #0x7, 0x14b4 <_llm_rows.packet_batch.blocks+0x594>
    1424:      	b	0x14bc <_llm_rows.packet_batch.blocks+0x59c>
    1428:      	and	w17, w15, #0xff
    142c:      	tbz	w17, #0x1, 0x13a4 <_llm_rows.packet_batch.blocks+0x484>
    1430:      	add	x0, x16, #0x4
    1434:      	ld1.s	{ v15 }[1], [x0]
    1438:      	tbnz	w17, #0x2, 0x13a8 <_llm_rows.packet_batch.blocks+0x488>
    143c:      	tbz	w17, #0x3, 0x13b4 <_llm_rows.packet_batch.blocks+0x494>
    1440:      	add	x0, x16, #0xc
    1444:      	ld1.s	{ v15 }[3], [x0]
    1448:      	tbnz	w17, #0x4, 0x13b8 <_llm_rows.packet_batch.blocks+0x498>
    144c:      	tbz	w17, #0x5, 0x13c4 <_llm_rows.packet_batch.blocks+0x4a4>
    1450:      	add	x0, x16, #0x14
    1454:      	ld1.s	{ v13 }[1], [x0]
    1458:      	tbnz	w17, #0x6, 0x13c8 <_llm_rows.packet_batch.blocks+0x4a8>
    145c:      	tbz	w17, #0x7, 0x13d4 <_llm_rows.packet_batch.blocks+0x4b4>
    1460:      	add	x16, x16, #0x1c
    1464:      	ld1.s	{ v13 }[3], [x16]
    1468:      	fmov	w17, s12
    146c:      	add	x16, x13, x10
    1470:      	movi.2d	v3, #0000000000000000
    1474:      	movi.2d	v14, #0000000000000000
    1478:      	tbnz	w17, #0x0, 0x13e8 <_llm_rows.packet_batch.blocks+0x4c8>
    147c:      	and	w17, w17, #0xff
    1480:      	tbz	w17, #0x1, 0x13f4 <_llm_rows.packet_batch.blocks+0x4d4>
    1484:      	add	x0, x16, #0x4
    1488:      	ld1.s	{ v3 }[1], [x0]
    148c:      	tbnz	w17, #0x2, 0x13f8 <_llm_rows.packet_batch.blocks+0x4d8>
    1490:      	tbz	w17, #0x3, 0x1404 <_llm_rows.packet_batch.blocks+0x4e4>
    1494:      	add	x0, x16, #0xc
    1498:      	ld1.s	{ v3 }[3], [x0]
    149c:      	tbnz	w17, #0x4, 0x1408 <_llm_rows.packet_batch.blocks+0x4e8>
    14a0:      	tbz	w17, #0x5, 0x1414 <_llm_rows.packet_batch.blocks+0x4f4>
    14a4:      	add	x0, x16, #0x14
    14a8:      	ld1.s	{ v14 }[1], [x0]
    14ac:      	tbnz	w17, #0x6, 0x1418 <_llm_rows.packet_batch.blocks+0x4f8>
    14b0:      	tbz	w17, #0x7, 0x14bc <_llm_rows.packet_batch.blocks+0x59c>
    14b4:      	add	x16, x16, #0x1c
    14b8:      	ld1.s	{ v14 }[3], [x16]
    14bc:      	ldp	q5, q1, [sp, #0x1c0]
    14c0:      	fmul.4s	v4, v15, v5
    14c4:      	fmul.4s	v4, v15, v4
    14c8:      	fmul.4s	v4, v15, v4
    14cc:      	fadd.4s	v4, v15, v4
    14d0:      	fmul.4s	v4, v4, v1
    14d4:      	and.16b	v4, v10, v4
    14d8:      	fabs.4s	v5, v4
    14dc:      	fmul.4s	v6, v4, v4
    14e0:      	ldr	q7, [sp, #0x230]
    14e4:      	ldp	q17, q1, [sp, #0x200]
    14e8:      	fmla.4s	v7, v6, v1
    14ec:      	mov.16b	v16, v11
    14f0:      	fmla.4s	v16, v6, v7
    14f4:      	mov.16b	v7, v23
    14f8:      	fmla.4s	v7, v6, v16
    14fc:      	mov.16b	v16, v28
    1500:      	fmla.4s	v16, v6, v7
    1504:      	ldr	q21, [sp, #0x250]
    1508:      	mov.16b	v7, v21
    150c:      	fmla.4s	v7, v6, v16
    1510:      	mov.16b	v16, v0
    1514:      	fmla.4s	v16, v6, v7
    1518:      	fmul.4s	v7, v5, v16
    151c:      	ldp	q1, q16, [sp, #0x1e0]
    1520:      	fmla.4s	v16, v6, v1
    1524:      	fmla.4s	v17, v6, v16
    1528:      	ldr	q16, [sp, #0x220]
    152c:      	fmla.4s	v16, v6, v17
    1530:      	ldr	q17, [sp, #0x240]
    1534:      	fmla.4s	v17, v6, v16
    1538:      	movi.4s	v16, #0x3f, lsl #24
    153c:      	fmla.4s	v16, v6, v17
    1540:      	mov.16b	v17, v0
    1544:      	fmla.4s	v17, v6, v16
    1548:      	fdiv.4s	v6, v7, v17
    154c:      	fcmge.4s	v7, v27, v5
    1550:      	and.16b	v16, v7, v5
    1554:      	fcmge.4s	v17, v16, v30
    1558:      	ldr	q1, [sp, #0x260]
    155c:      	fcmge.4s	v18, v1, v16
    1560:      	and.16b	v17, v17, v18
    1564:      	and.16b	v17, v17, v16
    1568:      	fmul.4s	v18, v17, v29
    156c:      	movi.4s	v19, #0x4b, lsl #24
    1570:      	fadd.4s	v18, v18, v19
    1574:      	movi.4s	v19, #0xcb, lsl #24
    1578:      	fadd.4s	v18, v18, v19
    157c:      	fcvtzs.4s	v18, v18
    1580:      	scvtf.4s	v8, v18
    1584:      	fmul.4s	v19, v8, v9
    1588:      	fadd.4s	v17, v17, v19
    158c:      	fmul.4s	v19, v8, v26
    1590:      	fadd.4s	v17, v17, v19
    1594:      	fmul.4s	v19, v17, v24
    1598:      	fadd.4s	v19, v19, v20
    159c:      	fmul.4s	v19, v17, v19
    15a0:      	fadd.4s	v19, v19, v22
    15a4:      	fmul.4s	v19, v17, v19
    15a8:      	fadd.4s	v19, v19, v25
    15ac:      	fmul.4s	v19, v17, v19
    15b0:      	fadd.4s	v19, v19, v21
    15b4:      	fmul.4s	v19, v17, v19
    15b8:      	fadd.4s	v19, v19, v2
    15bc:      	fmul.4s	v8, v17, v17
    15c0:      	fmul.4s	v19, v8, v19
    15c4:      	fadd.4s	v17, v17, v19
    15c8:      	fadd.4s	v17, v17, v0
    15cc:      	movi.2d	v19, #0xffffffffffffffff
    15d0:      	add.4s	v18, v18, v19
    15d4:      	sshr.4s	v19, v18, #0x1
    15d8:      	shl.4s	v8, v19, #0x17
    15dc:      	add.4s	v8, v8, v0
    15e0:      	fmul.4s	v17, v17, v8
    15e4:      	sub.4s	v18, v18, v19
    15e8:      	shl.4s	v18, v18, #0x17
    15ec:      	add.4s	v18, v18, v0
    15f0:      	fmul.4s	v17, v17, v18
    15f4:      	fcmgt.4s	v16, v16, v1
    15f8:      	ldr	q18, [sp, #0x1b0]
    15fc:      	bsl.16b	v16, v18, v17
    1600:      	fdiv.4s	v17, v31, v16
    1604:      	fsub.4s	v18, v16, v17
    1608:      	fadd.4s	v16, v16, v17
    160c:      	fdiv.4s	v16, v18, v16
    1610:      	bsl.16b	v7, v16, v0
    1614:      	fcmge.4s	v5, v0, v5
    1618:      	bsl.16b	v5, v6, v7
    161c:      	mvni.4s	v6, #0x80, lsl #24
    1620:      	bif.16b	v5, v4, v6
    1624:      	fcmeq.4s	v4, v4, v4
    1628:      	fadd.4s	v5, v5, v0
    162c:      	ldr	q6, [sp, #0x1a0]
    1630:      	bsl.16b	v4, v5, v6
    1634:      	fmul.4s	v5, v15, v2
    1638:      	fmul.4s	v4, v5, v4
    163c:      	fadd.4s	v3, v3, v4
    1640:      	fmov	w17, s12
    1644:      	add	x16, x12, x10
    1648:      	tbz	w17, #0x0, 0x1670 <_llm_rows.packet_batch.blocks+0x750>
    164c:      	str	s3, [x16]
    1650:      	and	w17, w17, #0xff
    1654:      	ldr	q4, [sp, #0x180]
    1658:      	tbnz	w17, #0x1, 0x167c <_llm_rows.packet_batch.blocks+0x75c>
    165c:      	tbz	w17, #0x2, 0x1688 <_llm_rows.packet_batch.blocks+0x768>
    1660:      	add	x0, x16, #0x8
    1664:      	st1.s	{ v3 }[2], [x0]
    1668:      	tbnz	w17, #0x3, 0x168c <_llm_rows.packet_batch.blocks+0x76c>
    166c:      	b	0x1694 <_llm_rows.packet_batch.blocks+0x774>
    1670:      	and	w17, w17, #0xff
    1674:      	ldr	q4, [sp, #0x180]
    1678:      	tbz	w17, #0x1, 0x165c <_llm_rows.packet_batch.blocks+0x73c>
    167c:      	add	x0, x16, #0x4
    1680:      	st1.s	{ v3 }[1], [x0]
    1684:      	tbnz	w17, #0x2, 0x1660 <_llm_rows.packet_batch.blocks+0x740>
    1688:      	tbz	w17, #0x3, 0x1694 <_llm_rows.packet_batch.blocks+0x774>
    168c:      	add	x0, x16, #0xc
    1690:      	st1.s	{ v3 }[3], [x0]
    1694:      	ldp	q5, q1, [sp, #0x1c0]
    1698:      	fmul.4s	v3, v13, v5
    169c:      	fmul.4s	v3, v13, v3
    16a0:      	fmul.4s	v3, v13, v3
    16a4:      	fadd.4s	v3, v13, v3
    16a8:      	fmul.4s	v3, v3, v1
    16ac:      	and.16b	v3, v4, v3
    16b0:      	fabs.4s	v4, v3
    16b4:      	fmul.4s	v5, v3, v3
    16b8:      	ldr	q6, [sp, #0x230]
    16bc:      	ldp	q16, q1, [sp, #0x200]
    16c0:      	fmla.4s	v6, v5, v1
    16c4:      	mov.16b	v7, v11
    16c8:      	fmla.4s	v7, v5, v6
    16cc:      	mov.16b	v6, v23
    16d0:      	fmla.4s	v6, v5, v7
    16d4:      	mov.16b	v7, v28
    16d8:      	fmla.4s	v7, v5, v6
    16dc:      	ldr	q21, [sp, #0x250]
    16e0:      	mov.16b	v6, v21
    16e4:      	fmla.4s	v6, v5, v7
    16e8:      	mov.16b	v7, v0
    16ec:      	fmla.4s	v7, v5, v6
    16f0:      	fmul.4s	v6, v4, v7
    16f4:      	ldp	q1, q7, [sp, #0x1e0]
    16f8:      	fmla.4s	v7, v5, v1
    16fc:      	fmla.4s	v16, v5, v7
    1700:      	ldr	q7, [sp, #0x220]
    1704:      	fmla.4s	v7, v5, v16
    1708:      	ldr	q16, [sp, #0x240]
    170c:      	fmla.4s	v16, v5, v7
    1710:      	movi.4s	v7, #0x3f, lsl #24
    1714:      	fmla.4s	v7, v5, v16
    1718:      	mov.16b	v16, v0
    171c:      	fmla.4s	v16, v5, v7
    1720:      	fdiv.4s	v5, v6, v16
    1724:      	fcmge.4s	v6, v27, v4
    1728:      	and.16b	v7, v6, v4
    172c:      	fcmge.4s	v16, v7, v30
    1730:      	ldr	q1, [sp, #0x260]
    1734:      	fcmge.4s	v17, v1, v7
    1738:      	and.16b	v16, v16, v17
    173c:      	and.16b	v16, v16, v7
    1740:      	fmul.4s	v17, v16, v29
    1744:      	movi.4s	v18, #0x4b, lsl #24
    1748:      	fadd.4s	v17, v17, v18
    174c:      	movi.4s	v18, #0xcb, lsl #24
    1750:      	fadd.4s	v17, v17, v18
    1754:      	fcvtzs.4s	v17, v17
    1758:      	scvtf.4s	v18, v17
    175c:      	fmul.4s	v19, v18, v9
    1760:      	fadd.4s	v16, v16, v19
    1764:      	fmul.4s	v18, v18, v26
    1768:      	fadd.4s	v16, v16, v18
    176c:      	fmul.4s	v18, v16, v24
    1770:      	fadd.4s	v18, v18, v20
    1774:      	fmul.4s	v18, v16, v18
    1778:      	fadd.4s	v18, v18, v22
    177c:      	fmul.4s	v18, v16, v18
    1780:      	fadd.4s	v18, v18, v25
    1784:      	fmul.4s	v18, v16, v18
    1788:      	fadd.4s	v18, v18, v21
    178c:      	fmul.4s	v18, v16, v18
    1790:      	fadd.4s	v18, v18, v2
    1794:      	fmul.4s	v19, v16, v16
    1798:      	fmul.4s	v18, v19, v18
    179c:      	fadd.4s	v16, v16, v18
    17a0:      	fadd.4s	v16, v16, v0
    17a4:      	movi.2d	v18, #0xffffffffffffffff
    17a8:      	add.4s	v17, v17, v18
    17ac:      	sshr.4s	v18, v17, #0x1
    17b0:      	shl.4s	v19, v18, #0x17
    17b4:      	add.4s	v19, v19, v0
    17b8:      	fmul.4s	v16, v16, v19
    17bc:      	sub.4s	v17, v17, v18
    17c0:      	shl.4s	v17, v17, #0x17
    17c4:      	add.4s	v17, v17, v0
    17c8:      	fmul.4s	v16, v16, v17
    17cc:      	fcmgt.4s	v7, v7, v1
    17d0:      	ldr	q17, [sp, #0x1b0]
    17d4:      	bsl.16b	v7, v17, v16
    17d8:      	fdiv.4s	v16, v31, v7
    17dc:      	fsub.4s	v17, v7, v16
    17e0:      	fadd.4s	v7, v7, v16
    17e4:      	fdiv.4s	v7, v17, v7
    17e8:      	bsl.16b	v6, v7, v0
    17ec:      	fcmge.4s	v4, v0, v4
    17f0:      	bsl.16b	v4, v5, v6
    17f4:      	mvni.4s	v5, #0x80, lsl #24
    17f8:      	bif.16b	v4, v3, v5
    17fc:      	fcmeq.4s	v3, v3, v3
    1800:      	fadd.4s	v4, v4, v0
    1804:      	ldr	q5, [sp, #0x1a0]
    1808:      	bsl.16b	v3, v4, v5
    180c:      	fmul.4s	v4, v13, v2
    1810:      	fmul.4s	v3, v4, v3
    1814:      	fadd.4s	v3, v14, v3
    1818:      	tbz	w17, #0x4, 0x1838 <_llm_rows.packet_batch.blocks+0x918>
    181c:      	str	s3, [x16, #0x10]
    1820:      	tbnz	w17, #0x5, 0x183c <_llm_rows.packet_batch.blocks+0x91c>
    1824:      	tbz	w17, #0x6, 0x1848 <_llm_rows.packet_batch.blocks+0x928>
    1828:      	add	x0, x16, #0x18
    182c:      	st1.s	{ v3 }[2], [x0]
    1830:      	tbz	w17, #0x7, 0x137c <_llm_rows.packet_batch.blocks+0x45c>
    1834:      	b	0x184c <_llm_rows.packet_batch.blocks+0x92c>
    1838:      	tbz	w17, #0x5, 0x1824 <_llm_rows.packet_batch.blocks+0x904>
    183c:      	add	x0, x16, #0x14
    1840:      	st1.s	{ v3 }[1], [x0]
    1844:      	tbnz	w17, #0x6, 0x1828 <_llm_rows.packet_batch.blocks+0x908>
    1848:      	tbz	w17, #0x7, 0x137c <_llm_rows.packet_batch.blocks+0x45c>
    184c:      	add	x16, x16, #0x1c
    1850:      	st1.s	{ v3 }[3], [x16]
    1854:      	b	0x137c <_llm_rows.packet_batch.blocks+0x45c>
    1858:      	mov	x10, #0x0               ; =0
    185c:      	add	x12, x11, x14
    1860:      	movi.4s	v2, #0x3f, lsl #24
    1864:      	b	0x1888 <_llm_rows.packet_batch.blocks+0x968>
    1868:      	add	x13, x23, x10
    186c:      	ldp	q6, q7, [x13]
    1870:      	bif.16b	v5, v7, v19
    1874:      	bif.16b	v4, v6, v10
    1878:      	stp	q4, q5, [x13]
    187c:      	add	x10, x10, #0x20
    1880:      	cmp	x10, #0x100
    1884:      	b.eq	0x192c <_llm_rows.packet_batch.blocks+0xa0c>
    1888:      	ldr	q4, [sp, #0x120]
    188c:      	and.16b	v4, v3, v4
    1890:      	addv.8h	h15, v4
    1894:      	fmov	w14, s15
    1898:      	add	x13, x12, x10
    189c:      	movi.2d	v4, #0000000000000000
    18a0:      	movi.2d	v5, #0000000000000000
    18a4:      	tbz	w14, #0x0, 0x18e8 <_llm_rows.packet_batch.blocks+0x9c8>
    18a8:      	ldr	s4, [x13]
    18ac:      	and	w14, w14, #0xff
    18b0:      	tbnz	w14, #0x1, 0x18f0 <_llm_rows.packet_batch.blocks+0x9d0>
    18b4:      	tbz	w14, #0x2, 0x18fc <_llm_rows.packet_batch.blocks+0x9dc>
    18b8:      	add	x15, x13, #0x8
    18bc:      	ld1.s	{ v4 }[2], [x15]
    18c0:      	tbnz	w14, #0x3, 0x1900 <_llm_rows.packet_batch.blocks+0x9e0>
    18c4:      	tbz	w14, #0x4, 0x190c <_llm_rows.packet_batch.blocks+0x9ec>
    18c8:      	add	x15, x13, #0x10
    18cc:      	ld1.s	{ v5 }[0], [x15]
    18d0:      	tbnz	w14, #0x5, 0x1910 <_llm_rows.packet_batch.blocks+0x9f0>
    18d4:      	tbz	w14, #0x6, 0x191c <_llm_rows.packet_batch.blocks+0x9fc>
    18d8:      	add	x15, x13, #0x18
    18dc:      	ld1.s	{ v5 }[2], [x15]
    18e0:      	tbz	w14, #0x7, 0x1868 <_llm_rows.packet_batch.blocks+0x948>
    18e4:      	b	0x1920 <_llm_rows.packet_batch.blocks+0xa00>
    18e8:      	and	w14, w14, #0xff
    18ec:      	tbz	w14, #0x1, 0x18b4 <_llm_rows.packet_batch.blocks+0x994>
    18f0:      	add	x15, x13, #0x4
    18f4:      	ld1.s	{ v4 }[1], [x15]
    18f8:      	tbnz	w14, #0x2, 0x18b8 <_llm_rows.packet_batch.blocks+0x998>
    18fc:      	tbz	w14, #0x3, 0x18c4 <_llm_rows.packet_batch.blocks+0x9a4>
    1900:      	add	x15, x13, #0xc
    1904:      	ld1.s	{ v4 }[3], [x15]
    1908:      	tbnz	w14, #0x4, 0x18c8 <_llm_rows.packet_batch.blocks+0x9a8>
    190c:      	tbz	w14, #0x5, 0x18d4 <_llm_rows.packet_batch.blocks+0x9b4>
    1910:      	add	x15, x13, #0x14
    1914:      	ld1.s	{ v5 }[1], [x15]
    1918:      	tbnz	w14, #0x6, 0x18d8 <_llm_rows.packet_batch.blocks+0x9b8>
    191c:      	tbz	w14, #0x7, 0x1868 <_llm_rows.packet_batch.blocks+0x948>
    1920:      	add	x13, x13, #0x1c
    1924:      	ld1.s	{ v5 }[3], [x13]
    1928:      	b	0x1868 <_llm_rows.packet_batch.blocks+0x948>
    192c:      	xtn.4h	v3, v10
    1930:      	uzp1.8b	v4, v3, v0
    1934:      	movi.2d	v5, #0000000000000000
    1938:      	mov.b	v5[0], v4[0]
    193c:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0xe0>
    1940:      	ldr	d3, [x10]
    1944:      	str	d3, [sp, #0x20]
    1948:      	and.8b	v3, v5, v3
    194c:      	addv.8b	b3, v3
    1950:      	fmov	w13, s3
    1954:      	str	q5, [sp, #0xe0]
    1958:      	umaxv.8b	b3, v5
    195c:      	fmov	w14, s3
    1960:      	rbit	w10, w13
    1964:      	clz	w10, w10
    1968:      	tst	w14, #0x1
    196c:      	csel	w10, w10, wzr, ne
    1970:      	mov	w12, #0x40              ; =64
    1974:      	dup.2d	v3, x12
    1978:      	movi.2s	v5, #0x41
    197c:      	ldr	d6, [sp, #0xf0]
    1980:      	ldr	q7, [sp, #0xb0]
    1984:      	umlal.2d	v7, v6, v5
    1988:      	movi.2d	v5, #0000000000000000
    198c:      	mov.b	v5[0], v4[0]
    1990:      	add.2d	v6, v7, v3
    1994:      	ushll.2d	v4, v5, #0x0
    1998:      	shl.2d	v4, v4, #0x3f
    199c:      	cmlt.2d	v4, v4, #0
    19a0:      	str	q6, [sp, #0xc0]
    19a4:      	and.16b	v4, v4, v6
    19a8:      	movi.2d	v5, #0000000000000000
    19ac:      	stp	q5, q5, [sp, #0x3b0]
    19b0:      	stp	q4, q5, [sp, #0x390]
    19b4:      	and	x12, x10, #0x7
    19b8:      	add	x15, sp, #0x390
    19bc:      	ldr	x12, [x15, x12, lsl #3]
    19c0:      	sub	x12, x12, x10
    19c4:      	lsl	x12, x12, #2
    19c8:      	add	x11, x11, x12
    19cc:      	movi.2d	v4, #0000000000000000
    19d0:      	tbz	w14, #0x0, 0x1a14 <_llm_rows.packet_batch.blocks+0xaf4>
    19d4:      	ldr	s5, [x11]
    19d8:      	tbnz	w13, #0x1, 0x1a18 <_llm_rows.packet_batch.blocks+0xaf8>
    19dc:      	tbz	w13, #0x2, 0x1a24 <_llm_rows.packet_batch.blocks+0xb04>
    19e0:      	add	x14, x11, #0x8
    19e4:      	ld1.s	{ v5 }[2], [x14]
    19e8:      	tbnz	w13, #0x3, 0x1a28 <_llm_rows.packet_batch.blocks+0xb08>
    19ec:      	tbz	w13, #0x4, 0x1a34 <_llm_rows.packet_batch.blocks+0xb14>
    19f0:      	add	x14, x11, #0x10
    19f4:      	ld1.s	{ v4 }[0], [x14]
    19f8:      	tbnz	w13, #0x5, 0x1a38 <_llm_rows.packet_batch.blocks+0xb18>
    19fc:      	tbz	w13, #0x6, 0x1a44 <_llm_rows.packet_batch.blocks+0xb24>
    1a00:      	add	x14, x11, #0x18
    1a04:      	ld1.s	{ v4 }[2], [x14]
    1a08:      	str	q5, [sp, #0xd0]
    1a0c:      	tbnz	w13, #0x7, 0x1a4c <_llm_rows.packet_batch.blocks+0xb2c>
    1a10:      	b	0x1a54 <_llm_rows.packet_batch.blocks+0xb34>
    1a14:      	tbz	w13, #0x1, 0x19dc <_llm_rows.packet_batch.blocks+0xabc>
    1a18:      	add	x14, x11, #0x4
    1a1c:      	ld1.s	{ v5 }[1], [x14]
    1a20:      	tbnz	w13, #0x2, 0x19e0 <_llm_rows.packet_batch.blocks+0xac0>
    1a24:      	tbz	w13, #0x3, 0x19ec <_llm_rows.packet_batch.blocks+0xacc>
    1a28:      	add	x14, x11, #0xc
    1a2c:      	ld1.s	{ v5 }[3], [x14]
    1a30:      	tbnz	w13, #0x4, 0x19f0 <_llm_rows.packet_batch.blocks+0xad0>
    1a34:      	tbz	w13, #0x5, 0x19fc <_llm_rows.packet_batch.blocks+0xadc>
    1a38:      	add	x14, x11, #0x14
    1a3c:      	ld1.s	{ v4 }[1], [x14]
    1a40:      	tbnz	w13, #0x6, 0x1a00 <_llm_rows.packet_batch.blocks+0xae0>
    1a44:      	str	q5, [sp, #0xd0]
    1a48:      	tbz	w13, #0x7, 0x1a54 <_llm_rows.packet_batch.blocks+0xb34>
    1a4c:      	add	x11, x11, #0x1c
    1a50:      	ld1.s	{ v4 }[3], [x11]
    1a54:      	mov.16b	v14, v4
    1a58:      	mov	x15, #0x0               ; =0
    1a5c:      	movi.2s	v5, #0x41
    1a60:      	ldr	d4, [sp, #0xf0]
    1a64:      	umull.2d	v4, v4, v5
    1a68:      	umlal.2d	v17, v8, v5
    1a6c:      	add.2d	v6, v17, v3
    1a70:      	str	q6, [sp, #0xb0]
    1a74:      	umlal.2d	v16, v21, v5
    1a78:      	add.2d	v6, v16, v3
    1a7c:      	str	q6, [sp, #0x40]
    1a80:      	umlal.2d	v18, v1, v5
    1a84:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xe0>
    1a88:      	ldr	q5, [x11]
    1a8c:      	mov	w11, #0x100             ; =256
    1a90:      	dup.2d	v6, x11
    1a94:      	sshll.2d	v7, v10, #0x0
    1a98:      	bif.16b	v5, v6, v7
    1a9c:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xe0>
    1aa0:      	ldr	q7, [x11]
    1aa4:      	sshll.2d	v16, v19, #0x0
    1aa8:      	bif.16b	v7, v6, v16
    1aac:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xe0>
    1ab0:      	ldr	q16, [x11]
    1ab4:      	bif.16b	v16, v6, v13
    1ab8:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0xe0>
    1abc:      	ldr	q17, [x11]
    1ac0:      	bit.16b	v6, v17, v12
    1ac4:      	stp	q7, q6, [sp, #0x370]
    1ac8:      	stp	q5, q16, [sp, #0x350]
    1acc:      	and	x11, x10, #0x7
    1ad0:      	add	x14, sp, #0x350
    1ad4:      	ldr	x11, [x14, x11, lsl #3]
    1ad8:      	add.2d	v1, v18, v3
    1adc:      	str	q1, [sp, #0x30]
    1ae0:      	sub	x11, x11, x10, lsl #2
    1ae4:      	tst	w13, #0xff
    1ae8:      	csel	x11, xzr, x11, eq
    1aec:      	add	x13, x23, x11
    1af0:      	ldp	q3, q5, [x13]
    1af4:      	ldp	q1, q21, [sp, #0xd0]
    1af8:      	zip2.8b	v6, v21, v0
    1afc:      	ushll.4s	v6, v6, #0x0
    1b00:      	shl.4s	v6, v6, #0x1f
    1b04:      	cmlt.4s	v6, v6, #0
    1b08:      	str	q14, [sp, #0xf0]
    1b0c:      	bit.16b	v5, v14, v6
    1b10:      	zip1.8b	v6, v21, v0
    1b14:      	ushll.4s	v6, v6, #0x0
    1b18:      	shl.4s	v6, v6, #0x1f
    1b1c:      	cmlt.4s	v6, v6, #0
    1b20:      	bit.16b	v3, v1, v6
    1b24:      	stp	q3, q5, [x13]
    1b28:      	fmov	x13, d4
    1b2c:      	lsl	x13, x13, #2
    1b30:      	mov	w14, #0x1               ; =1
    1b34:      	dup.2d	v3, x14
    1b38:      	add	x14, x9, x13
    1b3c:      	ushll2.2d	v4, v19, #0x0
    1b40:      	and.16b	v8, v4, v3
    1b44:      	ushll2.2d	v4, v10, #0x0
    1b48:      	and.16b	v12, v4, v3
    1b4c:      	ushll.2d	v4, v19, #0x0
    1b50:      	and.16b	v13, v4, v3
    1b54:      	ushll.2d	v4, v10, #0x0
    1b58:      	and.16b	v14, v4, v3
    1b5c:      	movi.2d	v3, #0000000000000000
    1b60:      	movi.2d	v4, #0000000000000000
    1b64:      	movi.2d	v5, #0000000000000000
    1b68:      	movi.2d	v6, #0000000000000000
    1b6c:      	b	0x1ba0 <_llm_rows.packet_batch.blocks+0xc80>
    1b70:      	add	x15, x25, x15
    1b74:      	ldp	q17, q18, [x15]
    1b78:      	bif.16b	v16, v18, v19
    1b7c:      	bif.16b	v7, v17, v10
    1b80:      	stp	q7, q16, [x15]
    1b84:      	add.2d	v4, v4, v12
    1b88:      	add.2d	v5, v5, v13
    1b8c:      	add.2d	v6, v6, v8
    1b90:      	add.2d	v3, v3, v14
    1b94:      	fmov	x15, d3
    1b98:      	cmp	x15, #0x8
    1b9c:      	b.ge	0x1c3c <_llm_rows.packet_batch.blocks+0xd1c>
    1ba0:      	fmov	w17, s15
    1ba4:      	lsl	x15, x15, #5
    1ba8:      	add	x16, x14, x15
    1bac:      	movi.2d	v7, #0000000000000000
    1bb0:      	movi.2d	v16, #0000000000000000
    1bb4:      	tbz	w17, #0x0, 0x1bf8 <_llm_rows.packet_batch.blocks+0xcd8>
    1bb8:      	ldr	s7, [x16]
    1bbc:      	and	w17, w17, #0xff
    1bc0:      	tbnz	w17, #0x1, 0x1c00 <_llm_rows.packet_batch.blocks+0xce0>
    1bc4:      	tbz	w17, #0x2, 0x1c0c <_llm_rows.packet_batch.blocks+0xcec>
    1bc8:      	add	x0, x16, #0x8
    1bcc:      	ld1.s	{ v7 }[2], [x0]
    1bd0:      	tbnz	w17, #0x3, 0x1c10 <_llm_rows.packet_batch.blocks+0xcf0>
    1bd4:      	tbz	w17, #0x4, 0x1c1c <_llm_rows.packet_batch.blocks+0xcfc>
    1bd8:      	add	x0, x16, #0x10
    1bdc:      	ld1.s	{ v16 }[0], [x0]
    1be0:      	tbnz	w17, #0x5, 0x1c20 <_llm_rows.packet_batch.blocks+0xd00>
    1be4:      	tbz	w17, #0x6, 0x1c2c <_llm_rows.packet_batch.blocks+0xd0c>
    1be8:      	add	x0, x16, #0x18
    1bec:      	ld1.s	{ v16 }[2], [x0]
    1bf0:      	tbz	w17, #0x7, 0x1b70 <_llm_rows.packet_batch.blocks+0xc50>
    1bf4:      	b	0x1c30 <_llm_rows.packet_batch.blocks+0xd10>
    1bf8:      	and	w17, w17, #0xff
    1bfc:      	tbz	w17, #0x1, 0x1bc4 <_llm_rows.packet_batch.blocks+0xca4>
    1c00:      	add	x0, x16, #0x4
    1c04:      	ld1.s	{ v7 }[1], [x0]
    1c08:      	tbnz	w17, #0x2, 0x1bc8 <_llm_rows.packet_batch.blocks+0xca8>
    1c0c:      	tbz	w17, #0x3, 0x1bd4 <_llm_rows.packet_batch.blocks+0xcb4>
    1c10:      	add	x0, x16, #0xc
    1c14:      	ld1.s	{ v7 }[3], [x0]
    1c18:      	tbnz	w17, #0x4, 0x1bd8 <_llm_rows.packet_batch.blocks+0xcb8>
    1c1c:      	tbz	w17, #0x5, 0x1be4 <_llm_rows.packet_batch.blocks+0xcc4>
    1c20:      	add	x0, x16, #0x14
    1c24:      	ld1.s	{ v16 }[1], [x0]
    1c28:      	tbnz	w17, #0x6, 0x1be8 <_llm_rows.packet_batch.blocks+0xcc8>
    1c2c:      	tbz	w17, #0x7, 0x1b70 <_llm_rows.packet_batch.blocks+0xc50>
    1c30:      	add	x16, x16, #0x1c
    1c34:      	ld1.s	{ v16 }[3], [x16]
    1c38:      	b	0x1b70 <_llm_rows.packet_batch.blocks+0xc50>
    1c3c:      	add	x9, x9, x12
    1c40:      	shl.8b	v3, v21, #0x7
    1c44:      	cmlt.8b	v3, v3, #0
    1c48:      	ldr	d1, [sp, #0x20]
    1c4c:      	and.8b	v3, v3, v1
    1c50:      	addv.8b	b1, v3
    1c54:      	str	d1, [sp, #0x8]
    1c58:      	fmov	w12, s1
    1c5c:      	movi.2d	v7, #0000000000000000
    1c60:      	movi.2d	v6, #0000000000000000
    1c64:      	tbz	w12, #0x0, 0x1cb4 <_llm_rows.packet_batch.blocks+0xd94>
    1c68:      	ldr	s7, [x9]
    1c6c:      	tbnz	w12, #0x1, 0x1cb8 <_llm_rows.packet_batch.blocks+0xd98>
    1c70:      	tbz	w12, #0x2, 0x1cc4 <_llm_rows.packet_batch.blocks+0xda4>
    1c74:      	add	x14, x9, #0x8
    1c78:      	ld1.s	{ v7 }[2], [x14]
    1c7c:      	tbnz	w12, #0x3, 0x1cc8 <_llm_rows.packet_batch.blocks+0xda8>
    1c80:      	tbz	w12, #0x4, 0x1cd4 <_llm_rows.packet_batch.blocks+0xdb4>
    1c84:      	add	x14, x9, #0x10
    1c88:      	ld1.s	{ v6 }[0], [x14]
    1c8c:      	tbnz	w12, #0x5, 0x1cd8 <_llm_rows.packet_batch.blocks+0xdb8>
    1c90:      	tbz	w12, #0x6, 0x1ce4 <_llm_rows.packet_batch.blocks+0xdc4>
    1c94:      	add	x14, x9, #0x18
    1c98:      	ld1.s	{ v6 }[2], [x14]
    1c9c:      	stp	q22, q25, [sp, #0x160]
    1ca0:      	stp	q24, q20, [sp, #0x140]
    1ca4:      	str	q26, [sp, #0x130]
    1ca8:      	mov.16b	v26, v23
    1cac:      	tbnz	w12, #0x7, 0x1cf8 <_llm_rows.packet_batch.blocks+0xdd8>
    1cb0:      	b	0x1d00 <_llm_rows.packet_batch.blocks+0xde0>
    1cb4:      	tbz	w12, #0x1, 0x1c70 <_llm_rows.packet_batch.blocks+0xd50>
    1cb8:      	add	x14, x9, #0x4
    1cbc:      	ld1.s	{ v7 }[1], [x14]
    1cc0:      	tbnz	w12, #0x2, 0x1c74 <_llm_rows.packet_batch.blocks+0xd54>
    1cc4:      	tbz	w12, #0x3, 0x1c80 <_llm_rows.packet_batch.blocks+0xd60>
    1cc8:      	add	x14, x9, #0xc
    1ccc:      	ld1.s	{ v7 }[3], [x14]
    1cd0:      	tbnz	w12, #0x4, 0x1c84 <_llm_rows.packet_batch.blocks+0xd64>
    1cd4:      	tbz	w12, #0x5, 0x1c90 <_llm_rows.packet_batch.blocks+0xd70>
    1cd8:      	add	x14, x9, #0x14
    1cdc:      	ld1.s	{ v6 }[1], [x14]
    1ce0:      	tbnz	w12, #0x6, 0x1c94 <_llm_rows.packet_batch.blocks+0xd74>
    1ce4:      	stp	q22, q25, [sp, #0x160]
    1ce8:      	stp	q24, q20, [sp, #0x140]
    1cec:      	str	q26, [sp, #0x130]
    1cf0:      	mov.16b	v26, v23
    1cf4:      	tbz	w12, #0x7, 0x1d00 <_llm_rows.packet_batch.blocks+0xde0>
    1cf8:      	add	x9, x9, #0x1c
    1cfc:      	ld1.s	{ v6 }[3], [x9]
    1d00:      	mov	x12, #0x0               ; =0
    1d04:      	add	x9, x25, x11
    1d08:      	ldp	q3, q4, [x9]
    1d0c:      	zip2.8b	v5, v21, v0
    1d10:      	ushll.4s	v5, v5, #0x0
    1d14:      	shl.4s	v5, v5, #0x1f
    1d18:      	cmlt.4s	v5, v5, #0
    1d1c:      	stp	q7, q6, [sp, #0x10]
    1d20:      	bit.16b	v4, v6, v5
    1d24:      	zip1.8b	v5, v21, v0
    1d28:      	ushll.4s	v5, v5, #0x0
    1d2c:      	shl.4s	v5, v5, #0x1f
    1d30:      	cmlt.4s	v5, v5, #0
    1d34:      	bit.16b	v3, v7, v5
    1d38:      	stp	q3, q4, [x9]
    1d3c:      	add	x9, x8, x13
    1d40:      	movi.2d	v3, #0000000000000000
    1d44:      	movi.2d	v4, #0000000000000000
    1d48:      	movi.2d	v5, #0000000000000000
    1d4c:      	movi.2d	v6, #0000000000000000
    1d50:      	b	0x1d74 <_llm_rows.packet_batch.blocks+0xe54>
    1d54:      	add.2d	v4, v4, v12
    1d58:      	add.2d	v5, v5, v13
    1d5c:      	mov.16b	v8, v1
    1d60:      	add.2d	v6, v6, v1
    1d64:      	add.2d	v3, v3, v14
    1d68:      	fmov	x12, d3
    1d6c:      	cmp	x12, #0x8
    1d70:      	b.ge	0x21f8 <_llm_rows.packet_batch.blocks+0x12d8>
    1d74:      	mov.16b	v24, v14
    1d78:      	mov.16b	v25, v12
    1d7c:      	mov.16b	v1, v8
    1d80:      	lsl	x11, x12, #5
    1d84:      	add	x12, x23, x11
    1d88:      	ldr	q7, [x12]
    1d8c:      	and.16b	v7, v10, v7
    1d90:      	ldp	q16, q17, [sp, #0x1c0]
    1d94:      	fmul.4s	v16, v7, v16
    1d98:      	fmul.4s	v16, v7, v16
    1d9c:      	fmul.4s	v16, v7, v16
    1da0:      	fadd.4s	v16, v7, v16
    1da4:      	fmul.4s	v16, v16, v17
    1da8:      	and.16b	v16, v10, v16
    1dac:      	fabs.4s	v17, v16
    1db0:      	fmul.4s	v18, v16, v16
    1db4:      	ldr	q19, [sp, #0x230]
    1db8:      	ldr	q21, [sp, #0x210]
    1dbc:      	fmla.4s	v19, v18, v21
    1dc0:      	mov.16b	v23, v11
    1dc4:      	fmla.4s	v23, v18, v19
    1dc8:      	mov.16b	v19, v26
    1dcc:      	fmla.4s	v19, v18, v23
    1dd0:      	mov.16b	v12, v28
    1dd4:      	mov.16b	v23, v28
    1dd8:      	fmla.4s	v23, v18, v19
    1ddc:      	ldr	q11, [sp, #0x250]
    1de0:      	mov.16b	v19, v11
    1de4:      	fmla.4s	v19, v18, v23
    1de8:      	mov.16b	v23, v0
    1dec:      	fmla.4s	v23, v18, v19
    1df0:      	fmul.4s	v19, v17, v23
    1df4:      	ldp	q21, q23, [sp, #0x1e0]
    1df8:      	fmla.4s	v23, v18, v21
    1dfc:      	ldr	q28, [sp, #0x200]
    1e00:      	fmla.4s	v28, v18, v23
    1e04:      	ldr	q23, [sp, #0x220]
    1e08:      	fmla.4s	v23, v18, v28
    1e0c:      	ldr	q28, [sp, #0x240]
    1e10:      	fmla.4s	v28, v18, v23
    1e14:      	movi.4s	v23, #0x3f, lsl #24
    1e18:      	fmla.4s	v23, v18, v28
    1e1c:      	mov.16b	v28, v0
    1e20:      	fmla.4s	v28, v18, v23
    1e24:      	fdiv.4s	v18, v19, v28
    1e28:      	fcmge.4s	v19, v27, v17
    1e2c:      	and.16b	v23, v19, v17
    1e30:      	mov.16b	v14, v30
    1e34:      	fcmge.4s	v28, v23, v30
    1e38:      	ldr	q21, [sp, #0x260]
    1e3c:      	fcmge.4s	v30, v21, v23
    1e40:      	and.16b	v28, v28, v30
    1e44:      	and.16b	v28, v28, v23
    1e48:      	mov.16b	v8, v29
    1e4c:      	fmul.4s	v30, v28, v29
    1e50:      	mov.16b	v22, v31
    1e54:      	movi.4s	v31, #0x4b, lsl #24
    1e58:      	fadd.4s	v30, v30, v31
    1e5c:      	movi.4s	v31, #0xcb, lsl #24
    1e60:      	fadd.4s	v30, v30, v31
    1e64:      	fcvtzs.4s	v30, v30
    1e68:      	scvtf.4s	v31, v30
    1e6c:      	mov.16b	v29, v9
    1e70:      	fmul.4s	v9, v31, v9
    1e74:      	fadd.4s	v28, v28, v9
    1e78:      	ldr	q20, [sp, #0x130]
    1e7c:      	fmul.4s	v31, v31, v20
    1e80:      	fadd.4s	v28, v28, v31
    1e84:      	ldp	q20, q9, [sp, #0x140]
    1e88:      	fmul.4s	v31, v28, v20
    1e8c:      	fadd.4s	v31, v31, v9
    1e90:      	fmul.4s	v31, v28, v31
    1e94:      	ldr	q9, [sp, #0x160]
    1e98:      	fadd.4s	v31, v31, v9
    1e9c:      	fmul.4s	v31, v28, v31
    1ea0:      	ldr	q9, [sp, #0x170]
    1ea4:      	fadd.4s	v31, v31, v9
    1ea8:      	fmul.4s	v31, v28, v31
    1eac:      	fadd.4s	v31, v31, v11
    1eb0:      	fmul.4s	v31, v28, v31
    1eb4:      	fadd.4s	v31, v31, v2
    1eb8:      	fmul.4s	v9, v28, v28
    1ebc:      	fmul.4s	v31, v9, v31
    1ec0:      	fadd.4s	v28, v28, v31
    1ec4:      	fadd.4s	v28, v28, v0
    1ec8:      	movi.2d	v31, #0xffffffffffffffff
    1ecc:      	add.4s	v30, v30, v31
    1ed0:      	sshr.4s	v31, v30, #0x1
    1ed4:      	shl.4s	v9, v31, #0x17
    1ed8:      	add.4s	v9, v9, v0
    1edc:      	fmul.4s	v28, v28, v9
    1ee0:      	sub.4s	v30, v30, v31
    1ee4:      	shl.4s	v30, v30, #0x17
    1ee8:      	add.4s	v30, v30, v0
    1eec:      	fmul.4s	v28, v28, v30
    1ef0:      	fcmgt.4s	v23, v23, v21
    1ef4:      	ldr	q30, [sp, #0x1b0]
    1ef8:      	bsl.16b	v23, v30, v28
    1efc:      	fdiv.4s	v28, v22, v23
    1f00:      	fsub.4s	v30, v23, v28
    1f04:      	fadd.4s	v23, v23, v28
    1f08:      	fdiv.4s	v23, v30, v23
    1f0c:      	bsl.16b	v19, v23, v0
    1f10:      	fcmge.4s	v17, v0, v17
    1f14:      	bsl.16b	v17, v18, v19
    1f18:      	mvni.4s	v18, #0x80, lsl #24
    1f1c:      	bif.16b	v17, v16, v18
    1f20:      	fcmeq.4s	v16, v16, v16
    1f24:      	fadd.4s	v17, v17, v0
    1f28:      	ldr	q18, [sp, #0x1a0]
    1f2c:      	bif.16b	v17, v18, v16
    1f30:      	ldr	q16, [x12, #0x10]
    1f34:      	fmul.4s	v7, v7, v2
    1f38:      	fmul.4s	v7, v7, v17
    1f3c:      	add	x12, x25, x11
    1f40:      	ldr	q17, [x12]
    1f44:      	and.16b	v17, v10, v17
    1f48:      	fadd.4s	v17, v17, v7
    1f4c:      	ldr	q7, [x12, #0x10]
    1f50:      	fmov	w12, s15
    1f54:      	add	x11, x9, x11
    1f58:      	tbz	w12, #0x0, 0x1f8c <_llm_rows.packet_batch.blocks+0x106c>
    1f5c:      	str	s17, [x11]
    1f60:      	mov.16b	v20, v13
    1f64:      	and	w12, w12, #0xff
    1f68:      	tbnz	w12, #0x1, 0x1f98 <_llm_rows.packet_batch.blocks+0x1078>
    1f6c:      	mov.16b	v13, v15
    1f70:      	ldr	q28, [sp, #0x190]
    1f74:      	tbz	w12, #0x2, 0x1fac <_llm_rows.packet_batch.blocks+0x108c>
    1f78:      	add	x13, x11, #0x8
    1f7c:      	st1.s	{ v17 }[2], [x13]
    1f80:      	mov.16b	v15, v10
    1f84:      	tbnz	w12, #0x3, 0x1fb4 <_llm_rows.packet_batch.blocks+0x1094>
    1f88:      	b	0x1fbc <_llm_rows.packet_batch.blocks+0x109c>
    1f8c:      	mov.16b	v20, v13
    1f90:      	and	w12, w12, #0xff
    1f94:      	tbz	w12, #0x1, 0x1f6c <_llm_rows.packet_batch.blocks+0x104c>
    1f98:      	add	x13, x11, #0x4
    1f9c:      	st1.s	{ v17 }[1], [x13]
    1fa0:      	mov.16b	v13, v15
    1fa4:      	ldr	q28, [sp, #0x190]
    1fa8:      	tbnz	w12, #0x2, 0x1f78 <_llm_rows.packet_batch.blocks+0x1058>
    1fac:      	mov.16b	v15, v10
    1fb0:      	tbz	w12, #0x3, 0x1fbc <_llm_rows.packet_batch.blocks+0x109c>
    1fb4:      	add	x13, x11, #0xc
    1fb8:      	st1.s	{ v17 }[3], [x13]
    1fbc:      	ldr	q10, [sp, #0x180]
    1fc0:      	and.16b	v16, v10, v16
    1fc4:      	ldr	q2, [sp, #0x1c0]
    1fc8:      	fmul.4s	v17, v16, v2
    1fcc:      	fmul.4s	v17, v16, v17
    1fd0:      	fmul.4s	v17, v16, v17
    1fd4:      	fadd.4s	v17, v16, v17
    1fd8:      	ldr	q2, [sp, #0x1d0]
    1fdc:      	fmul.4s	v17, v17, v2
    1fe0:      	and.16b	v17, v10, v17
    1fe4:      	fabs.4s	v18, v17
    1fe8:      	fmul.4s	v19, v17, v17
    1fec:      	ldr	q23, [sp, #0x230]
    1ff0:      	ldp	q30, q2, [sp, #0x200]
    1ff4:      	fmla.4s	v23, v19, v2
    1ff8:      	fmla.4s	v28, v19, v23
    1ffc:      	mov.16b	v23, v26
    2000:      	fmla.4s	v23, v19, v28
    2004:      	mov.16b	v28, v12
    2008:      	fmla.4s	v28, v19, v23
    200c:      	ldr	q11, [sp, #0x250]
    2010:      	mov.16b	v23, v11
    2014:      	fmla.4s	v23, v19, v28
    2018:      	mov.16b	v28, v0
    201c:      	fmla.4s	v28, v19, v23
    2020:      	fmul.4s	v23, v18, v28
    2024:      	ldp	q2, q28, [sp, #0x1e0]
    2028:      	fmla.4s	v28, v19, v2
    202c:      	fmla.4s	v30, v19, v28
    2030:      	ldr	q28, [sp, #0x220]
    2034:      	fmla.4s	v28, v19, v30
    2038:      	ldr	q30, [sp, #0x240]
    203c:      	fmla.4s	v30, v19, v28
    2040:      	movi.4s	v28, #0x3f, lsl #24
    2044:      	fmla.4s	v28, v19, v30
    2048:      	mov.16b	v30, v0
    204c:      	fmla.4s	v30, v19, v28
    2050:      	fdiv.4s	v19, v23, v30
    2054:      	fcmge.4s	v23, v27, v18
    2058:      	and.16b	v28, v23, v18
    205c:      	fcmge.4s	v30, v28, v14
    2060:      	ldr	q2, [sp, #0x260]
    2064:      	fcmge.4s	v31, v2, v28
    2068:      	and.16b	v30, v30, v31
    206c:      	and.16b	v30, v30, v28
    2070:      	fmul.4s	v31, v30, v8
    2074:      	movi.4s	v21, #0x4b, lsl #24
    2078:      	fadd.4s	v31, v31, v21
    207c:      	movi.4s	v21, #0xcb, lsl #24
    2080:      	fadd.4s	v31, v31, v21
    2084:      	fcvtzs.4s	v31, v31
    2088:      	scvtf.4s	v9, v31
    208c:      	fmul.4s	v21, v9, v29
    2090:      	fadd.4s	v21, v30, v21
    2094:      	ldr	q30, [sp, #0x130]
    2098:      	fmul.4s	v30, v9, v30
    209c:      	fadd.4s	v21, v21, v30
    20a0:      	ldp	q30, q9, [sp, #0x140]
    20a4:      	fmul.4s	v30, v21, v30
    20a8:      	fadd.4s	v30, v30, v9
    20ac:      	fmul.4s	v30, v21, v30
    20b0:      	ldr	q9, [sp, #0x160]
    20b4:      	fadd.4s	v30, v30, v9
    20b8:      	fmul.4s	v30, v21, v30
    20bc:      	ldr	q9, [sp, #0x170]
    20c0:      	fadd.4s	v30, v30, v9
    20c4:      	fmul.4s	v30, v21, v30
    20c8:      	fadd.4s	v30, v30, v11
    20cc:      	fmul.4s	v30, v21, v30
    20d0:      	movi.4s	v9, #0x3f, lsl #24
    20d4:      	fadd.4s	v30, v30, v9
    20d8:      	fmul.4s	v9, v21, v21
    20dc:      	fmul.4s	v30, v9, v30
    20e0:      	fadd.4s	v21, v21, v30
    20e4:      	fadd.4s	v21, v21, v0
    20e8:      	movi.2d	v30, #0xffffffffffffffff
    20ec:      	add.4s	v30, v31, v30
    20f0:      	sshr.4s	v31, v30, #0x1
    20f4:      	shl.4s	v9, v31, #0x17
    20f8:      	add.4s	v9, v9, v0
    20fc:      	fmul.4s	v21, v21, v9
    2100:      	sub.4s	v30, v30, v31
    2104:      	shl.4s	v30, v30, #0x17
    2108:      	add.4s	v30, v30, v0
    210c:      	fmul.4s	v21, v21, v30
    2110:      	fcmgt.4s	v28, v28, v2
    2114:      	ldr	q30, [sp, #0x1b0]
    2118:      	bit.16b	v21, v30, v28
    211c:      	mov.16b	v31, v22
    2120:      	fdiv.4s	v28, v22, v21
    2124:      	fsub.4s	v30, v21, v28
    2128:      	fadd.4s	v21, v21, v28
    212c:      	fdiv.4s	v21, v30, v21
    2130:      	bif.16b	v21, v0, v23
    2134:      	fcmge.4s	v18, v0, v18
    2138:      	bsl.16b	v18, v19, v21
    213c:      	movi.4s	v2, #0x3f, lsl #24
    2140:      	mvni.4s	v19, #0x80, lsl #24
    2144:      	bif.16b	v18, v17, v19
    2148:      	fcmeq.4s	v17, v17, v17
    214c:      	fadd.4s	v18, v18, v0
    2150:      	ldr	q19, [sp, #0x1a0]
    2154:      	bsl.16b	v17, v18, v19
    2158:      	fmul.4s	v16, v16, v2
    215c:      	fmul.4s	v16, v16, v17
    2160:      	and.16b	v7, v10, v7
    2164:      	fadd.4s	v7, v7, v16
    2168:      	tbz	w12, #0x4, 0x21b0 <_llm_rows.packet_batch.blocks+0x1290>
    216c:      	str	s7, [x11, #0x10]
    2170:      	mov.16b	v10, v15
    2174:      	tbnz	w12, #0x5, 0x21b8 <_llm_rows.packet_batch.blocks+0x1298>
    2178:      	mov.16b	v9, v29
    217c:      	mov.16b	v30, v14
    2180:      	mov.16b	v28, v12
    2184:      	ldr	q11, [sp, #0x190]
    2188:      	mov.16b	v15, v13
    218c:      	tbz	w12, #0x6, 0x21d8 <_llm_rows.packet_batch.blocks+0x12b8>
    2190:      	add	x13, x11, #0x18
    2194:      	st1.s	{ v7 }[2], [x13]
    2198:      	mov.16b	v29, v8
    219c:      	mov.16b	v12, v25
    21a0:      	mov.16b	v13, v20
    21a4:      	mov.16b	v14, v24
    21a8:      	tbz	w12, #0x7, 0x1d54 <_llm_rows.packet_batch.blocks+0xe34>
    21ac:      	b	0x21ec <_llm_rows.packet_batch.blocks+0x12cc>
    21b0:      	mov.16b	v10, v15
    21b4:      	tbz	w12, #0x5, 0x2178 <_llm_rows.packet_batch.blocks+0x1258>
    21b8:      	add	x13, x11, #0x14
    21bc:      	st1.s	{ v7 }[1], [x13]
    21c0:      	mov.16b	v9, v29
    21c4:      	mov.16b	v30, v14
    21c8:      	mov.16b	v28, v12
    21cc:      	ldr	q11, [sp, #0x190]
    21d0:      	mov.16b	v15, v13
    21d4:      	tbnz	w12, #0x6, 0x2190 <_llm_rows.packet_batch.blocks+0x1270>
    21d8:      	mov.16b	v29, v8
    21dc:      	mov.16b	v12, v25
    21e0:      	mov.16b	v13, v20
    21e4:      	mov.16b	v14, v24
    21e8:      	tbz	w12, #0x7, 0x1d54 <_llm_rows.packet_batch.blocks+0xe34>
    21ec:      	add	x11, x11, #0x1c
    21f0:      	st1.s	{ v7 }[3], [x11]
    21f4:      	b	0x1d54 <_llm_rows.packet_batch.blocks+0xe34>
    21f8:      	ldp	q1, q2, [sp, #0x1c0]
    21fc:      	ldp	q10, q8, [sp, #0xd0]
    2200:      	fmul.4s	v3, v10, v1
    2204:      	fmul.4s	v3, v10, v3
    2208:      	fmul.4s	v3, v10, v3
    220c:      	fadd.4s	v3, v10, v3
    2210:      	fmul.4s	v3, v3, v2
    2214:      	zip1.8b	v4, v8, v0
    2218:      	ushll.4s	v4, v4, #0x0
    221c:      	shl.4s	v4, v4, #0x1f
    2220:      	cmlt.4s	v4, v4, #0
    2224:      	and.16b	v3, v4, v3
    2228:      	fabs.4s	v4, v3
    222c:      	fmul.4s	v5, v3, v3
    2230:      	ldr	q6, [sp, #0x230]
    2234:      	ldp	q16, q2, [sp, #0x200]
    2238:      	fmla.4s	v6, v5, v2
    223c:      	mov.16b	v7, v11
    2240:      	fmla.4s	v7, v5, v6
    2244:      	mov.16b	v1, v26
    2248:      	mov.16b	v6, v26
    224c:      	fmla.4s	v6, v5, v7
    2250:      	mov.16b	v7, v28
    2254:      	fmla.4s	v7, v5, v6
    2258:      	ldr	q23, [sp, #0x250]
    225c:      	mov.16b	v6, v23
    2260:      	fmla.4s	v6, v5, v7
    2264:      	mov.16b	v7, v0
    2268:      	fmla.4s	v7, v5, v6
    226c:      	fmul.4s	v6, v4, v7
    2270:      	ldp	q2, q7, [sp, #0x1e0]
    2274:      	fmla.4s	v7, v5, v2
    2278:      	fmla.4s	v16, v5, v7
    227c:      	ldr	q7, [sp, #0x220]
    2280:      	fmla.4s	v7, v5, v16
    2284:      	ldr	q16, [sp, #0x240]
    2288:      	fmla.4s	v16, v5, v7
    228c:      	movi.4s	v7, #0x3f, lsl #24
    2290:      	fmla.4s	v7, v5, v16
    2294:      	mov.16b	v16, v0
    2298:      	fmla.4s	v16, v5, v7
    229c:      	fdiv.4s	v5, v6, v16
    22a0:      	fcmge.4s	v6, v27, v4
    22a4:      	and.16b	v7, v6, v4
    22a8:      	fcmge.4s	v16, v7, v30
    22ac:      	movi.4s	v21, #0x3f, lsl #24
    22b0:      	ldr	q2, [sp, #0x260]
    22b4:      	fcmge.4s	v17, v2, v7
    22b8:      	and.16b	v16, v16, v17
    22bc:      	and.16b	v16, v16, v7
    22c0:      	fmul.4s	v17, v16, v29
    22c4:      	movi.4s	v18, #0x4b, lsl #24
    22c8:      	fadd.4s	v17, v17, v18
    22cc:      	movi.4s	v18, #0xcb, lsl #24
    22d0:      	fadd.4s	v17, v17, v18
    22d4:      	fcvtzs.4s	v17, v17
    22d8:      	scvtf.4s	v18, v17
    22dc:      	fmul.4s	v19, v18, v9
    22e0:      	fadd.4s	v16, v16, v19
    22e4:      	ldp	q26, q22, [sp, #0x130]
    22e8:      	fmul.4s	v18, v18, v26
    22ec:      	fadd.4s	v16, v16, v18
    22f0:      	fmul.4s	v18, v16, v22
    22f4:      	ldp	q24, q25, [sp, #0x150]
    22f8:      	fadd.4s	v18, v18, v24
    22fc:      	fmul.4s	v18, v16, v18
    2300:      	fadd.4s	v18, v18, v25
    2304:      	fmul.4s	v18, v16, v18
    2308:      	ldr	q20, [sp, #0x170]
    230c:      	fadd.4s	v18, v18, v20
    2310:      	fmul.4s	v18, v16, v18
    2314:      	fadd.4s	v18, v18, v23
    2318:      	fmul.4s	v18, v16, v18
    231c:      	fadd.4s	v18, v18, v21
    2320:      	fmul.4s	v19, v16, v16
    2324:      	fmul.4s	v18, v19, v18
    2328:      	fadd.4s	v16, v16, v18
    232c:      	fadd.4s	v16, v16, v0
    2330:      	movi.2d	v18, #0xffffffffffffffff
    2334:      	add.4s	v17, v17, v18
    2338:      	sshr.4s	v18, v17, #0x1
    233c:      	shl.4s	v19, v18, #0x17
    2340:      	add.4s	v19, v19, v0
    2344:      	fmul.4s	v16, v16, v19
    2348:      	sub.4s	v17, v17, v18
    234c:      	shl.4s	v17, v17, #0x17
    2350:      	add.4s	v17, v17, v0
    2354:      	fmul.4s	v16, v16, v17
    2358:      	fcmgt.4s	v7, v7, v2
    235c:      	movi.4s	v2, #0x3f, lsl #24
    2360:      	ldr	q17, [sp, #0x1b0]
    2364:      	bsl.16b	v7, v17, v16
    2368:      	fdiv.4s	v16, v31, v7
    236c:      	fsub.4s	v17, v7, v16
    2370:      	fadd.4s	v7, v7, v16
    2374:      	fdiv.4s	v7, v17, v7
    2378:      	bsl.16b	v6, v7, v0
    237c:      	fcmge.4s	v4, v0, v4
    2380:      	bsl.16b	v4, v5, v6
    2384:      	ldr	d5, [sp, #0x8]
    2388:      	fmov	w9, s5
    238c:      	mvni.4s	v5, #0x80, lsl #24
    2390:      	bif.16b	v4, v3, v5
    2394:      	fcmeq.4s	v3, v3, v3
    2398:      	fadd.4s	v4, v4, v0
    239c:      	ldr	q5, [sp, #0x1a0]
    23a0:      	bsl.16b	v3, v4, v5
    23a4:      	fmul.4s	v4, v10, v2
    23a8:      	fmul.4s	v3, v4, v3
    23ac:      	ldr	q2, [sp, #0x10]
    23b0:      	fadd.4s	v3, v3, v2
    23b4:      	ldp	q2, q4, [sp, #0xb0]
    23b8:      	stp	q4, q2, [sp, #0x300]
    23bc:      	ldp	q2, q4, [sp, #0x30]
    23c0:      	stp	q4, q2, [sp, #0x320]
    23c4:      	and	x11, x10, #0x7
    23c8:      	add	x12, sp, #0x300
    23cc:      	ldr	x11, [x12, x11, lsl #3]
    23d0:      	sub	x10, x11, x10
    23d4:      	add	x8, x8, x10, lsl #2
    23d8:      	tbz	w9, #0x0, 0x23fc <_llm_rows.packet_batch.blocks+0x14dc>
    23dc:      	str	s3, [x8]
    23e0:      	ldr	q21, [sp, #0xf0]
    23e4:      	tbnz	w9, #0x1, 0x2404 <_llm_rows.packet_batch.blocks+0x14e4>
    23e8:      	tbz	w9, #0x2, 0x2410 <_llm_rows.packet_batch.blocks+0x14f0>
    23ec:      	add	x10, x8, #0x8
    23f0:      	st1.s	{ v3 }[2], [x10]
    23f4:      	tbnz	w9, #0x3, 0x2414 <_llm_rows.packet_batch.blocks+0x14f4>
    23f8:      	b	0x241c <_llm_rows.packet_batch.blocks+0x14fc>
    23fc:      	ldr	q21, [sp, #0xf0]
    2400:      	tbz	w9, #0x1, 0x23e8 <_llm_rows.packet_batch.blocks+0x14c8>
    2404:      	add	x10, x8, #0x4
    2408:      	st1.s	{ v3 }[1], [x10]
    240c:      	tbnz	w9, #0x2, 0x23ec <_llm_rows.packet_batch.blocks+0x14cc>
    2410:      	tbz	w9, #0x3, 0x241c <_llm_rows.packet_batch.blocks+0x14fc>
    2414:      	add	x10, x8, #0xc
    2418:      	st1.s	{ v3 }[3], [x10]
    241c:      	ldp	q4, q2, [sp, #0x1c0]
    2420:      	fmul.4s	v3, v21, v4
    2424:      	fmul.4s	v3, v21, v3
    2428:      	fmul.4s	v3, v21, v3
    242c:      	fadd.4s	v3, v21, v3
    2430:      	fmul.4s	v3, v3, v2
    2434:      	zip2.8b	v4, v8, v0
    2438:      	ushll.4s	v4, v4, #0x0
    243c:      	shl.4s	v4, v4, #0x1f
    2440:      	cmlt.4s	v4, v4, #0
    2444:      	and.16b	v3, v4, v3
    2448:      	fmul.4s	v4, v3, v3
    244c:      	ldr	q2, [sp, #0x230]
    2450:      	ldr	q5, [sp, #0x210]
    2454:      	fmla.4s	v2, v4, v5
    2458:      	fmla.4s	v11, v4, v2
    245c:      	fmla.4s	v1, v4, v11
    2460:      	fmla.4s	v28, v4, v1
    2464:      	ldr	q2, [sp, #0x250]
    2468:      	mov.16b	v5, v2
    246c:      	fmla.4s	v5, v4, v28
    2470:      	mov.16b	v6, v0
    2474:      	fmla.4s	v6, v4, v5
    2478:      	ldp	q1, q5, [sp, #0x1e0]
    247c:      	fmla.4s	v5, v4, v1
    2480:      	ldr	q1, [sp, #0x200]
    2484:      	fmla.4s	v1, v4, v5
    2488:      	ldr	q5, [sp, #0x220]
    248c:      	fmla.4s	v5, v4, v1
    2490:      	ldr	q1, [sp, #0x240]
    2494:      	fmla.4s	v1, v4, v5
    2498:      	movi.4s	v5, #0x3f, lsl #24
    249c:      	fmla.4s	v5, v4, v1
    24a0:      	mov.16b	v7, v0
    24a4:      	fmla.4s	v7, v4, v5
    24a8:      	fabs.4s	v4, v3
    24ac:      	fmul.4s	v5, v4, v6
    24b0:      	fdiv.4s	v5, v5, v7
    24b4:      	fcmge.4s	v6, v27, v4
    24b8:      	and.16b	v7, v6, v4
    24bc:      	fcmge.4s	v16, v7, v30
    24c0:      	ldr	q1, [sp, #0x260]
    24c4:      	fcmge.4s	v17, v1, v7
    24c8:      	and.16b	v16, v16, v17
    24cc:      	and.16b	v16, v16, v7
    24d0:      	fmul.4s	v17, v16, v29
    24d4:      	movi.4s	v18, #0x4b, lsl #24
    24d8:      	fadd.4s	v17, v17, v18
    24dc:      	movi.4s	v18, #0xcb, lsl #24
    24e0:      	fadd.4s	v17, v17, v18
    24e4:      	fcvtzs.4s	v17, v17
    24e8:      	scvtf.4s	v18, v17
    24ec:      	fmul.4s	v19, v18, v9
    24f0:      	fadd.4s	v16, v16, v19
    24f4:      	fmul.4s	v18, v18, v26
    24f8:      	fadd.4s	v16, v16, v18
    24fc:      	fmul.4s	v18, v16, v22
    2500:      	fadd.4s	v18, v18, v24
    2504:      	fmul.4s	v18, v16, v18
    2508:      	fadd.4s	v18, v18, v25
    250c:      	fmul.4s	v18, v16, v18
    2510:      	fadd.4s	v18, v18, v20
    2514:      	fmul.4s	v18, v16, v18
    2518:      	fadd.4s	v2, v18, v2
    251c:      	fmul.4s	v2, v16, v2
    2520:      	movi.4s	v18, #0x3f, lsl #24
    2524:      	fadd.4s	v2, v2, v18
    2528:      	fmul.4s	v18, v16, v16
    252c:      	fmul.4s	v2, v18, v2
    2530:      	fadd.4s	v2, v16, v2
    2534:      	fadd.4s	v2, v2, v0
    2538:      	movi.2d	v16, #0xffffffffffffffff
    253c:      	add.4s	v16, v17, v16
    2540:      	sshr.4s	v17, v16, #0x1
    2544:      	shl.4s	v18, v17, #0x17
    2548:      	add.4s	v18, v18, v0
    254c:      	fmul.4s	v2, v2, v18
    2550:      	sub.4s	v16, v16, v17
    2554:      	shl.4s	v16, v16, #0x17
    2558:      	add.4s	v16, v16, v0
    255c:      	fmul.4s	v2, v2, v16
    2560:      	fcmgt.4s	v1, v7, v1
    2564:      	ldr	q7, [sp, #0x1b0]
    2568:      	bsl.16b	v1, v7, v2
    256c:      	fdiv.4s	v2, v31, v1
    2570:      	fsub.4s	v7, v1, v2
    2574:      	fadd.4s	v1, v1, v2
    2578:      	fdiv.4s	v1, v7, v1
    257c:      	bif.16b	v1, v0, v6
    2580:      	fcmge.4s	v2, v0, v4
    2584:      	bit.16b	v1, v5, v2
    2588:      	mvni.4s	v2, #0x80, lsl #24
    258c:      	bif.16b	v1, v3, v2
    2590:      	fadd.4s	v0, v1, v0
    2594:      	fcmeq.4s	v1, v3, v3
    2598:      	ldr	q2, [sp, #0x1a0]
    259c:      	bif.16b	v0, v2, v1
    25a0:      	movi.4s	v1, #0x3f, lsl #24
    25a4:      	fmul.4s	v1, v21, v1
    25a8:      	fmul.4s	v0, v1, v0
    25ac:      	ldr	q1, [sp, #0x20]
    25b0:      	fadd.4s	v0, v0, v1
    25b4:      	tbz	w9, #0x4, 0x2b74 <_llm_rows.packet_batch.blocks+0x1c54>
    25b8:      	str	s0, [x8, #0x10]
    25bc:      	tbnz	w9, #0x5, 0x2b78 <_llm_rows.packet_batch.blocks+0x1c58>
    25c0:      	tbz	w9, #0x6, 0x2b84 <_llm_rows.packet_batch.blocks+0x1c64>
    25c4:      	add	x10, x8, #0x18
    25c8:      	st1.s	{ v0 }[2], [x10]
    25cc:      	tbnz	w9, #0x7, 0x2b88 <_llm_rows.packet_batch.blocks+0x1c68>
    25d0:      	b	0xfec <_llm_rows.packet_batch.blocks+0xcc>
    25d4:      	xtn.4h	v3, v10
    25d8:      	uzp1.8b	v4, v3, v0
    25dc:      	movi.2d	v10, #0000000000000000
    25e0:      	mov.b	v10[0], v4[0]
    25e4:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x10e0>
    25e8:      	ldr	d3, [x10]
    25ec:      	and.8b	v5, v10, v3
    25f0:      	addv.8b	b5, v5
    25f4:      	fmov	w12, s5
    25f8:      	umaxv.8b	b5, v10
    25fc:      	fmov	w14, s5
    2600:      	rbit	w10, w12
    2604:      	clz	w10, w10
    2608:      	tst	w14, #0x1
    260c:      	csel	w10, w10, wzr, ne
    2610:      	mov	w13, #0x40              ; =64
    2614:      	dup.2d	v12, x13
    2618:      	movi.2s	v5, #0x41
    261c:      	ldr	d1, [sp, #0xf0]
    2620:      	ldr	q6, [sp, #0xb0]
    2624:      	umlal.2d	v6, v1, v5
    2628:      	movi.2d	v5, #0000000000000000
    262c:      	mov.b	v5[0], v4[0]
    2630:      	add.2d	v1, v6, v12
    2634:      	ushll.2d	v4, v5, #0x0
    2638:      	shl.2d	v4, v4, #0x3f
    263c:      	cmlt.2d	v4, v4, #0
    2640:      	str	q1, [sp, #0x180]
    2644:      	and.16b	v4, v4, v1
    2648:      	movi.2d	v5, #0000000000000000
    264c:      	stp	q5, q5, [sp, #0x2d0]
    2650:      	stp	q4, q5, [sp, #0x2b0]
    2654:      	and	x13, x10, #0x7
    2658:      	add	x15, sp, #0x2b0
    265c:      	ldr	x13, [x15, x13, lsl #3]
    2660:      	sub	x13, x13, x10
    2664:      	lsl	x13, x13, #2
    2668:      	add	x11, x11, x13
    266c:      	movi.2d	v15, #0000000000000000
    2670:      	movi.2d	v8, #0000000000000000
    2674:      	tbz	w14, #0x0, 0x26b4 <_llm_rows.packet_batch.blocks+0x1794>
    2678:      	ldr	s15, [x11]
    267c:      	tbnz	w12, #0x1, 0x26b8 <_llm_rows.packet_batch.blocks+0x1798>
    2680:      	tbz	w12, #0x2, 0x26c4 <_llm_rows.packet_batch.blocks+0x17a4>
    2684:      	add	x14, x11, #0x8
    2688:      	ld1.s	{ v15 }[2], [x14]
    268c:      	tbnz	w12, #0x3, 0x26c8 <_llm_rows.packet_batch.blocks+0x17a8>
    2690:      	tbz	w12, #0x4, 0x26d4 <_llm_rows.packet_batch.blocks+0x17b4>
    2694:      	add	x14, x11, #0x10
    2698:      	ld1.s	{ v8 }[0], [x14]
    269c:      	tbnz	w12, #0x5, 0x26d8 <_llm_rows.packet_batch.blocks+0x17b8>
    26a0:      	tbz	w12, #0x6, 0x26e4 <_llm_rows.packet_batch.blocks+0x17c4>
    26a4:      	add	x14, x11, #0x18
    26a8:      	ld1.s	{ v8 }[2], [x14]
    26ac:      	tbnz	w12, #0x7, 0x26e8 <_llm_rows.packet_batch.blocks+0x17c8>
    26b0:      	b	0x26f0 <_llm_rows.packet_batch.blocks+0x17d0>
    26b4:      	tbz	w12, #0x1, 0x2680 <_llm_rows.packet_batch.blocks+0x1760>
    26b8:      	add	x14, x11, #0x4
    26bc:      	ld1.s	{ v15 }[1], [x14]
    26c0:      	tbnz	w12, #0x2, 0x2684 <_llm_rows.packet_batch.blocks+0x1764>
    26c4:      	tbz	w12, #0x3, 0x2690 <_llm_rows.packet_batch.blocks+0x1770>
    26c8:      	add	x14, x11, #0xc
    26cc:      	ld1.s	{ v15 }[3], [x14]
    26d0:      	tbnz	w12, #0x4, 0x2694 <_llm_rows.packet_batch.blocks+0x1774>
    26d4:      	tbz	w12, #0x5, 0x26a0 <_llm_rows.packet_batch.blocks+0x1780>
    26d8:      	add	x14, x11, #0x14
    26dc:      	ld1.s	{ v8 }[1], [x14]
    26e0:      	tbnz	w12, #0x6, 0x26a4 <_llm_rows.packet_batch.blocks+0x1784>
    26e4:      	tbz	w12, #0x7, 0x26f0 <_llm_rows.packet_batch.blocks+0x17d0>
    26e8:      	add	x11, x11, #0x1c
    26ec:      	ld1.s	{ v8 }[3], [x11]
    26f0:      	shl.8b	v4, v10, #0x7
    26f4:      	cmlt.8b	v4, v4, #0
    26f8:      	and.8b	v3, v4, v3
    26fc:      	addv.8b	b1, v3
    2700:      	str	d1, [sp, #0xf0]
    2704:      	fmov	w11, s1
    2708:      	add	x9, x9, x13
    270c:      	movi.2d	v4, #0000000000000000
    2710:      	movi.2d	v13, #0000000000000000
    2714:      	tbz	w11, #0x0, 0x2988 <_llm_rows.packet_batch.blocks+0x1a68>
    2718:      	ldr	s4, [x9]
    271c:      	tbnz	w11, #0x1, 0x298c <_llm_rows.packet_batch.blocks+0x1a6c>
    2720:      	tbz	w11, #0x2, 0x2998 <_llm_rows.packet_batch.blocks+0x1a78>
    2724:      	add	x12, x9, #0x8
    2728:      	ld1.s	{ v4 }[2], [x12]
    272c:      	tbnz	w11, #0x3, 0x299c <_llm_rows.packet_batch.blocks+0x1a7c>
    2730:      	tbz	w11, #0x4, 0x29a8 <_llm_rows.packet_batch.blocks+0x1a88>
    2734:      	add	x12, x9, #0x10
    2738:      	ld1.s	{ v13 }[0], [x12]
    273c:      	tbnz	w11, #0x5, 0x29ac <_llm_rows.packet_batch.blocks+0x1a8c>
    2740:      	tbz	w11, #0x6, 0x274c <_llm_rows.packet_batch.blocks+0x182c>
    2744:      	add	x12, x9, #0x18
    2748:      	ld1.s	{ v13 }[2], [x12]
    274c:      	movi.2s	v5, #0x41
    2750:      	ldr	q1, [sp, #0xc0]
    2754:      	ldr	d3, [sp, #0x20]
    2758:      	umlal.2d	v1, v3, v5
    275c:      	str	q1, [sp, #0xc0]
    2760:      	ldr	q1, [sp, #0xd0]
    2764:      	ldr	d3, [sp, #0x30]
    2768:      	umlal.2d	v1, v3, v5
    276c:      	str	q1, [sp, #0xd0]
    2770:      	ldr	q1, [sp, #0xe0]
    2774:      	ldr	d3, [sp, #0x40]
    2778:      	umlal.2d	v1, v3, v5
    277c:      	str	q1, [sp, #0xe0]
    2780:      	tbz	w11, #0x7, 0x278c <_llm_rows.packet_batch.blocks+0x186c>
    2784:      	add	x9, x9, #0x1c
    2788:      	ld1.s	{ v13 }[3], [x9]
    278c:      	ldp	q3, q1, [sp, #0x1c0]
    2790:      	fmul.4s	v5, v15, v3
    2794:      	fmul.4s	v5, v15, v5
    2798:      	fmul.4s	v5, v15, v5
    279c:      	fadd.4s	v5, v15, v5
    27a0:      	fmul.4s	v5, v5, v1
    27a4:      	zip1.8b	v6, v10, v0
    27a8:      	ushll.4s	v6, v6, #0x0
    27ac:      	shl.4s	v6, v6, #0x1f
    27b0:      	cmlt.4s	v6, v6, #0
    27b4:      	and.16b	v5, v6, v5
    27b8:      	fabs.4s	v6, v5
    27bc:      	fmul.4s	v7, v5, v5
    27c0:      	ldr	q16, [sp, #0x230]
    27c4:      	ldp	q18, q1, [sp, #0x200]
    27c8:      	fmla.4s	v16, v7, v1
    27cc:      	mov.16b	v17, v11
    27d0:      	fmla.4s	v17, v7, v16
    27d4:      	mov.16b	v1, v23
    27d8:      	mov.16b	v16, v23
    27dc:      	fmla.4s	v16, v7, v17
    27e0:      	mov.16b	v17, v28
    27e4:      	fmla.4s	v17, v7, v16
    27e8:      	ldr	q21, [sp, #0x250]
    27ec:      	mov.16b	v16, v21
    27f0:      	fmla.4s	v16, v7, v17
    27f4:      	mov.16b	v17, v0
    27f8:      	fmla.4s	v17, v7, v16
    27fc:      	fmul.4s	v16, v6, v17
    2800:      	ldp	q3, q17, [sp, #0x1e0]
    2804:      	fmla.4s	v17, v7, v3
    2808:      	fmla.4s	v18, v7, v17
    280c:      	ldr	q17, [sp, #0x220]
    2810:      	fmla.4s	v17, v7, v18
    2814:      	ldr	q18, [sp, #0x240]
    2818:      	fmla.4s	v18, v7, v17
    281c:      	movi.4s	v17, #0x3f, lsl #24
    2820:      	fmla.4s	v17, v7, v18
    2824:      	mov.16b	v18, v0
    2828:      	fmla.4s	v18, v7, v17
    282c:      	fdiv.4s	v7, v16, v18
    2830:      	fcmge.4s	v16, v27, v6
    2834:      	and.16b	v17, v16, v6
    2838:      	fcmge.4s	v18, v17, v30
    283c:      	ldr	q3, [sp, #0x260]
    2840:      	fcmge.4s	v19, v3, v17
    2844:      	and.16b	v18, v18, v19
    2848:      	and.16b	v18, v18, v17
    284c:      	fmul.4s	v19, v18, v29
    2850:      	movi.4s	v23, #0x4b, lsl #24
    2854:      	fadd.4s	v19, v19, v23
    2858:      	movi.4s	v23, #0xcb, lsl #24
    285c:      	fadd.4s	v19, v19, v23
    2860:      	fcvtzs.4s	v19, v19
    2864:      	scvtf.4s	v14, v19
    2868:      	fmul.4s	v11, v14, v9
    286c:      	fadd.4s	v18, v18, v11
    2870:      	fmul.4s	v11, v14, v26
    2874:      	fadd.4s	v18, v18, v11
    2878:      	fmul.4s	v11, v18, v24
    287c:      	fadd.4s	v11, v11, v20
    2880:      	fmul.4s	v11, v18, v11
    2884:      	fadd.4s	v11, v11, v22
    2888:      	fmul.4s	v11, v18, v11
    288c:      	fadd.4s	v11, v11, v25
    2890:      	fmul.4s	v11, v18, v11
    2894:      	fadd.4s	v11, v11, v21
    2898:      	fmul.4s	v11, v18, v11
    289c:      	fadd.4s	v11, v11, v2
    28a0:      	fmul.4s	v14, v18, v18
    28a4:      	fmul.4s	v11, v14, v11
    28a8:      	fadd.4s	v18, v18, v11
    28ac:      	fadd.4s	v18, v18, v0
    28b0:      	movi.2d	v23, #0xffffffffffffffff
    28b4:      	add.4s	v19, v19, v23
    28b8:      	sshr.4s	v11, v19, #0x1
    28bc:      	shl.4s	v14, v11, #0x17
    28c0:      	add.4s	v14, v14, v0
    28c4:      	fmul.4s	v18, v18, v14
    28c8:      	sub.4s	v19, v19, v11
    28cc:      	shl.4s	v19, v19, #0x17
    28d0:      	add.4s	v19, v19, v0
    28d4:      	fmul.4s	v18, v18, v19
    28d8:      	fcmgt.4s	v17, v17, v3
    28dc:      	ldr	q19, [sp, #0x1b0]
    28e0:      	bsl.16b	v17, v19, v18
    28e4:      	fdiv.4s	v18, v31, v17
    28e8:      	fsub.4s	v19, v17, v18
    28ec:      	fadd.4s	v17, v17, v18
    28f0:      	fdiv.4s	v17, v19, v17
    28f4:      	bsl.16b	v16, v17, v0
    28f8:      	fcmge.4s	v6, v0, v6
    28fc:      	bsl.16b	v6, v7, v16
    2900:      	ldr	q3, [sp, #0xc0]
    2904:      	add.2d	v7, v3, v12
    2908:      	ldr	q3, [sp, #0xd0]
    290c:      	add.2d	v16, v3, v12
    2910:      	ldr	q3, [sp, #0xe0]
    2914:      	add.2d	v17, v3, v12
    2918:      	mvni.4s	v18, #0x80, lsl #24
    291c:      	bif.16b	v6, v5, v18
    2920:      	fcmeq.4s	v5, v5, v5
    2924:      	fadd.4s	v6, v6, v0
    2928:      	ldr	q18, [sp, #0x1a0]
    292c:      	bsl.16b	v5, v6, v18
    2930:      	fmul.4s	v6, v15, v2
    2934:      	fmul.4s	v5, v6, v5
    2938:      	fadd.4s	v4, v4, v5
    293c:      	ldr	q2, [sp, #0x180]
    2940:      	stp	q2, q7, [sp, #0x270]
    2944:      	stp	q16, q17, [sp, #0x290]
    2948:      	ldr	d2, [sp, #0xf0]
    294c:      	fmov	w9, s2
    2950:      	and	x11, x10, #0x7
    2954:      	add	x12, sp, #0x270
    2958:      	ldr	x11, [x12, x11, lsl #3]
    295c:      	sub	x10, x11, x10
    2960:      	add	x8, x8, x10, lsl #2
    2964:      	tbz	w9, #0x0, 0x29bc <_llm_rows.packet_batch.blocks+0x1a9c>
    2968:      	str	s4, [x8]
    296c:      	tbnz	w9, #0x1, 0x29c0 <_llm_rows.packet_batch.blocks+0x1aa0>
    2970:      	ldr	q2, [sp, #0x190]
    2974:      	tbz	w9, #0x2, 0x29d0 <_llm_rows.packet_batch.blocks+0x1ab0>
    2978:      	add	x10, x8, #0x8
    297c:      	st1.s	{ v4 }[2], [x10]
    2980:      	tbnz	w9, #0x3, 0x29d4 <_llm_rows.packet_batch.blocks+0x1ab4>
    2984:      	b	0x29dc <_llm_rows.packet_batch.blocks+0x1abc>
    2988:      	tbz	w11, #0x1, 0x2720 <_llm_rows.packet_batch.blocks+0x1800>
    298c:      	add	x12, x9, #0x4
    2990:      	ld1.s	{ v4 }[1], [x12]
    2994:      	tbnz	w11, #0x2, 0x2724 <_llm_rows.packet_batch.blocks+0x1804>
    2998:      	tbz	w11, #0x3, 0x2730 <_llm_rows.packet_batch.blocks+0x1810>
    299c:      	add	x12, x9, #0xc
    29a0:      	ld1.s	{ v4 }[3], [x12]
    29a4:      	tbnz	w11, #0x4, 0x2734 <_llm_rows.packet_batch.blocks+0x1814>
    29a8:      	tbz	w11, #0x5, 0x2740 <_llm_rows.packet_batch.blocks+0x1820>
    29ac:      	add	x12, x9, #0x14
    29b0:      	ld1.s	{ v13 }[1], [x12]
    29b4:      	tbnz	w11, #0x6, 0x2744 <_llm_rows.packet_batch.blocks+0x1824>
    29b8:      	b	0x274c <_llm_rows.packet_batch.blocks+0x182c>
    29bc:      	tbz	w9, #0x1, 0x2970 <_llm_rows.packet_batch.blocks+0x1a50>
    29c0:      	add	x10, x8, #0x4
    29c4:      	st1.s	{ v4 }[1], [x10]
    29c8:      	ldr	q2, [sp, #0x190]
    29cc:      	tbnz	w9, #0x2, 0x2978 <_llm_rows.packet_batch.blocks+0x1a58>
    29d0:      	tbz	w9, #0x3, 0x29dc <_llm_rows.packet_batch.blocks+0x1abc>
    29d4:      	add	x10, x8, #0xc
    29d8:      	st1.s	{ v4 }[3], [x10]
    29dc:      	ldp	q3, q4, [sp, #0x1c0]
    29e0:      	fmul.4s	v3, v8, v3
    29e4:      	fmul.4s	v3, v8, v3
    29e8:      	fmul.4s	v3, v8, v3
    29ec:      	fadd.4s	v3, v8, v3
    29f0:      	fmul.4s	v3, v3, v4
    29f4:      	zip2.8b	v4, v10, v0
    29f8:      	ushll.4s	v4, v4, #0x0
    29fc:      	shl.4s	v4, v4, #0x1f
    2a00:      	cmlt.4s	v4, v4, #0
    2a04:      	and.16b	v3, v4, v3
    2a08:      	fmul.4s	v4, v3, v3
    2a0c:      	ldr	q5, [sp, #0x230]
    2a10:      	ldr	q6, [sp, #0x210]
    2a14:      	fmla.4s	v5, v4, v6
    2a18:      	fmla.4s	v2, v4, v5
    2a1c:      	fmla.4s	v1, v4, v2
    2a20:      	fmla.4s	v28, v4, v1
    2a24:      	ldr	q2, [sp, #0x250]
    2a28:      	mov.16b	v5, v2
    2a2c:      	fmla.4s	v5, v4, v28
    2a30:      	mov.16b	v6, v0
    2a34:      	fmla.4s	v6, v4, v5
    2a38:      	ldp	q1, q5, [sp, #0x1e0]
    2a3c:      	fmla.4s	v5, v4, v1
    2a40:      	ldr	q1, [sp, #0x200]
    2a44:      	fmla.4s	v1, v4, v5
    2a48:      	ldr	q5, [sp, #0x220]
    2a4c:      	fmla.4s	v5, v4, v1
    2a50:      	ldr	q1, [sp, #0x240]
    2a54:      	fmla.4s	v1, v4, v5
    2a58:      	movi.4s	v5, #0x3f, lsl #24
    2a5c:      	fmla.4s	v5, v4, v1
    2a60:      	mov.16b	v7, v0
    2a64:      	fmla.4s	v7, v4, v5
    2a68:      	fabs.4s	v4, v3
    2a6c:      	fmul.4s	v5, v4, v6
    2a70:      	fdiv.4s	v5, v5, v7
    2a74:      	fcmge.4s	v6, v27, v4
    2a78:      	and.16b	v7, v6, v4
    2a7c:      	fcmge.4s	v16, v7, v30
    2a80:      	ldr	q1, [sp, #0x260]
    2a84:      	fcmge.4s	v17, v1, v7
    2a88:      	and.16b	v16, v16, v17
    2a8c:      	and.16b	v16, v16, v7
    2a90:      	fmul.4s	v17, v16, v29
    2a94:      	movi.4s	v18, #0x4b, lsl #24
    2a98:      	fadd.4s	v17, v17, v18
    2a9c:      	movi.4s	v18, #0xcb, lsl #24
    2aa0:      	fadd.4s	v17, v17, v18
    2aa4:      	fcvtzs.4s	v17, v17
    2aa8:      	scvtf.4s	v18, v17
    2aac:      	fmul.4s	v19, v18, v9
    2ab0:      	fadd.4s	v16, v16, v19
    2ab4:      	fmul.4s	v18, v18, v26
    2ab8:      	fadd.4s	v16, v16, v18
    2abc:      	fmul.4s	v18, v16, v24
    2ac0:      	fadd.4s	v18, v18, v20
    2ac4:      	fmul.4s	v18, v16, v18
    2ac8:      	fadd.4s	v18, v18, v22
    2acc:      	fmul.4s	v18, v16, v18
    2ad0:      	fadd.4s	v18, v18, v25
    2ad4:      	fmul.4s	v18, v16, v18
    2ad8:      	fadd.4s	v2, v18, v2
    2adc:      	fmul.4s	v2, v16, v2
    2ae0:      	movi.4s	v18, #0x3f, lsl #24
    2ae4:      	fadd.4s	v2, v2, v18
    2ae8:      	fmul.4s	v18, v16, v16
    2aec:      	fmul.4s	v2, v18, v2
    2af0:      	fadd.4s	v2, v16, v2
    2af4:      	fadd.4s	v2, v2, v0
    2af8:      	movi.2d	v16, #0xffffffffffffffff
    2afc:      	add.4s	v16, v17, v16
    2b00:      	sshr.4s	v17, v16, #0x1
    2b04:      	shl.4s	v18, v17, #0x17
    2b08:      	add.4s	v18, v18, v0
    2b0c:      	fmul.4s	v2, v2, v18
    2b10:      	sub.4s	v16, v16, v17
    2b14:      	shl.4s	v16, v16, #0x17
    2b18:      	add.4s	v16, v16, v0
    2b1c:      	fmul.4s	v2, v2, v16
    2b20:      	fcmgt.4s	v1, v7, v1
    2b24:      	ldr	q7, [sp, #0x1b0]
    2b28:      	bsl.16b	v1, v7, v2
    2b2c:      	fdiv.4s	v2, v31, v1
    2b30:      	fsub.4s	v7, v1, v2
    2b34:      	fadd.4s	v1, v1, v2
    2b38:      	fdiv.4s	v1, v7, v1
    2b3c:      	bif.16b	v1, v0, v6
    2b40:      	fcmge.4s	v2, v0, v4
    2b44:      	bit.16b	v1, v5, v2
    2b48:      	mvni.4s	v2, #0x80, lsl #24
    2b4c:      	bif.16b	v1, v3, v2
    2b50:      	fadd.4s	v0, v1, v0
    2b54:      	fcmeq.4s	v1, v3, v3
    2b58:      	ldr	q2, [sp, #0x1a0]
    2b5c:      	bif.16b	v0, v2, v1
    2b60:      	movi.4s	v1, #0x3f, lsl #24
    2b64:      	fmul.4s	v1, v8, v1
    2b68:      	fmul.4s	v0, v1, v0
    2b6c:      	fadd.4s	v0, v13, v0
    2b70:      	tbnz	w9, #0x4, 0x25b8 <_llm_rows.packet_batch.blocks+0x1698>
    2b74:      	tbz	w9, #0x5, 0x25c0 <_llm_rows.packet_batch.blocks+0x16a0>
    2b78:      	add	x10, x8, #0x14
    2b7c:      	st1.s	{ v0 }[1], [x10]
    2b80:      	tbnz	w9, #0x6, 0x25c4 <_llm_rows.packet_batch.blocks+0x16a4>
    2b84:      	tbz	w9, #0x7, 0xfec <_llm_rows.packet_batch.blocks+0xcc>
    2b88:      	add	x8, x8, #0x1c
    2b8c:      	st1.s	{ v0 }[3], [x8]
    2b90:      	b	0xfec <_llm_rows.packet_batch.blocks+0xcc>
    2b94:      	add	sp, sp, #0x620
    2b98:      	ldp	x29, x30, [sp, #0x90]
    2b9c:      	ldp	x20, x19, [sp, #0x80]
    2ba0:      	ldp	x22, x21, [sp, #0x70]
    2ba4:      	ldp	x24, x23, [sp, #0x60]
    2ba8:      	ldp	x26, x25, [sp, #0x50]
    2bac:      	ldp	x28, x27, [sp, #0x40]
    2bb0:      	ldp	d9, d8, [sp, #0x30]
    2bb4:      	ldp	d11, d10, [sp, #0x20]
    2bb8:      	ldp	d13, d12, [sp, #0x10]
    2bbc:      	ldp	d15, d14, [sp], #0xa0
    2bc0:      	ret

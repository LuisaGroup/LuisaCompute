; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [288 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.spill6 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill6, align 4
  %.spill7 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill7, align 4
  %.spill8 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill8, align 4
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot9 = alloca i64, align 8
  store i64 0, ptr %.slot9, align 4
  %.spill10 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill10, align 1
  %tile_snapshot.spill11 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill11, align 64
  %.slot12 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot12, align 64
  %.slot13 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot13, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert14 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat15 = shufflevector <8 x i32> %.splatinsert14, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat15, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert16 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat17 = shufflevector <8 x i32> %.splatinsert16, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat17, %41
  %44 = mul i32 %32, 1
  %.splatinsert18 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat19 = shufflevector <8 x i32> %.splatinsert18, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat19, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert20 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat21, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert22 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat23 = shufflevector <8 x i32> %.splatinsert22, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat23
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  store float 5.000000e-01, ptr %.spill5, align 4
  store float 0x3FA6E4E260000000, ptr %.spill6, align 4
  store float 0x3FE9884540000000, ptr %.spill7, align 4
  store float 1.000000e+00, ptr %.spill8, align 4
  %66 = extractvalue { ptr, i64 } %9, 1
  %67 = extractvalue { ptr, i64 } %9, 0
  %68 = ptrtoint ptr %67 to i64
  %69 = extractvalue { ptr, i64 } %27, 1
  %70 = extractvalue { ptr, i64 } %27, 0
  %71 = ptrtoint ptr %70 to i64
  %72 = icmp uge i64 %68, %71
  %73 = sub i64 %68, %71
  %74 = icmp uge i64 %73, 4420
  %75 = and i1 %72, %74
  %76 = icmp uge i64 %71, %68
  %77 = sub i64 %71, %68
  %78 = icmp uge i64 %77, 4420
  %79 = and i1 %76, %78
  %80 = or i1 %75, %79
  %81 = and i1 true, %80
  %82 = extractvalue { ptr, i64 } %15, 1
  %83 = extractvalue { ptr, i64 } %15, 0
  %84 = ptrtoint ptr %83 to i64
  %85 = icmp uge i64 %84, %71
  %86 = sub i64 %84, %71
  %87 = icmp uge i64 %86, 4420
  %88 = and i1 %85, %87
  %89 = icmp uge i64 %71, %84
  %90 = sub i64 %71, %84
  %91 = icmp uge i64 %90, 4420
  %92 = and i1 %89, %91
  %93 = or i1 %88, %92
  %94 = and i1 %81, %93
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.1:                                ; preds = %direct.true
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.2:                                ; preds = %direct.schedule.3, %direct.schedule.1
  %.state = load i64, ptr %.slot, align 4
  %95 = icmp slt i64 %.state, 8
  br i1 %95, label %direct.true24, label %direct.false25

direct.schedule.3:                                ; preds = %direct.true24
  %.state26 = load i64, ptr %.slot, align 4
  %96 = mul i64 %.state26, 8
  %.splatinsert27 = insertelement <8 x i64> poison, i64 %96, i64 0
  %.splat28 = shufflevector <8 x i64> %.splatinsert27, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %97 = add <8 x i64> %.splat28, %.spill.load
  %.spill.load29 = load <8 x i64>, ptr %.spill4, align 64
  %98 = add <8 x i64> %.spill.load29, zeroinitializer
  %99 = add <8 x i64> zeroinitializer, %98
  %100 = add <8 x i64> zeroinitializer, %97
  %101 = mul <8 x i64> %99, splat (i64 65)
  %102 = add <8 x i64> %101, %100
  %103 = extractvalue { ptr, i64 } %9, 0
  %104 = extractelement <8 x i64> %102, i32 0
  %105 = sub i64 %104, 0
  %106 = mul i64 %105, 4
  %buffer.contiguous.address = getelementptr i8, ptr %103, i64 %106
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %.spill.load30 = load float, ptr %.spill5, align 4
  %.splatinsert31 = insertelement <8 x float> poison, float %.spill.load30, i64 0
  %.splat32 = shufflevector <8 x float> %.splatinsert31, <8 x float> poison, <8 x i32> zeroinitializer
  %107 = fmul <8 x float> %.splat32, %buffer.contiguous.load
  %.spill.load33 = load float, ptr %.spill6, align 4
  %.splatinsert34 = insertelement <8 x float> poison, float %.spill.load33, i64 0
  %.splat35 = shufflevector <8 x float> %.splatinsert34, <8 x float> poison, <8 x i32> zeroinitializer
  %108 = fmul <8 x float> %.splat35, %buffer.contiguous.load
  %109 = fmul <8 x float> %108, %buffer.contiguous.load
  %110 = fmul <8 x float> %109, %buffer.contiguous.load
  %111 = fadd <8 x float> %buffer.contiguous.load, %110
  %.spill.load36 = load float, ptr %.spill7, align 4
  %.splatinsert37 = insertelement <8 x float> poison, float %.spill.load36, i64 0
  %.splat38 = shufflevector <8 x float> %.splatinsert37, <8 x float> poison, <8 x i32> zeroinitializer
  %112 = fmul <8 x float> %.splat38, %111
  %113 = select <8 x i1> %51, <8 x float> %112, <8 x float> zeroinitializer
  %native.tanh = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %113)
  %.spill.load39 = load float, ptr %.spill8, align 4
  %.splatinsert40 = insertelement <8 x float> poison, float %.spill.load39, i64 0
  %.splat41 = shufflevector <8 x float> %.splatinsert40, <8 x float> poison, <8 x i32> zeroinitializer
  %114 = fadd <8 x float> %.splat41, %native.tanh
  %115 = fmul <8 x float> %107, %114
  %116 = extractvalue { ptr, i64 } %15, 0
  %117 = extractelement <8 x i64> %102, i32 0
  %118 = sub i64 %117, 0
  %119 = mul i64 %118, 4
  %buffer.contiguous.address42 = getelementptr i8, ptr %116, i64 %119
  %buffer.contiguous.load43 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address42, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %120 = fadd <8 x float> %115, %buffer.contiguous.load43
  %121 = extractvalue { ptr, i64 } %27, 0
  %122 = extractelement <8 x i64> %102, i32 0
  %123 = sub i64 %122, 0
  %124 = mul i64 %123, 4
  %buffer.contiguous.address44 = getelementptr i8, ptr %121, i64 %124
  call void @llvm.masked.store.v8f32.p0(<8 x float> %120, ptr %buffer.contiguous.address44, i32 1, <8 x i1> %51)
  %.state45 = load i64, ptr %.slot, align 4
  %125 = add i64 %.state45, 1
  store i64 %125, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.4:                                ; preds = %direct.false25
  %.spill.load46 = load <8 x i64>, ptr %.spill, align 64
  %126 = icmp slt <8 x i64> %.spill.load46, splat (i64 1)
  %127 = and <8 x i1> %51, %126
  %128 = xor <8 x i1> %126, splat (i1 true)
  %129 = and <8 x i1> %51, %128
  %130 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %127)
  %131 = bitcast <8 x i1> %127 to i8
  %132 = call i8 @llvm.cttz.i8(i8 %131, i1 false)
  %133 = zext i8 %132 to i32
  %134 = select i1 %130, i32 %133, i32 0
  %.spill.load47 = load <8 x i64>, ptr %.spill, align 64
  %135 = add <8 x i64> splat (i64 64), %.spill.load47
  %.spill.load48 = load <8 x i64>, ptr %.spill4, align 64
  %136 = add <8 x i64> %.spill.load48, zeroinitializer
  %137 = add <8 x i64> zeroinitializer, %136
  %138 = add <8 x i64> zeroinitializer, %135
  %139 = mul <8 x i64> %137, splat (i64 65)
  %140 = add <8 x i64> %139, %138
  %141 = extractvalue { ptr, i64 } %9, 0
  %142 = select <8 x i1> %127, <8 x i64> %140, <8 x i64> zeroinitializer
  %143 = extractelement <8 x i64> %142, i32 %134
  %144 = zext i32 %134 to i64
  %145 = sub i64 %143, %144
  %146 = mul i64 %145, 4
  %buffer.contiguous.address49 = getelementptr i8, ptr %141, i64 %146
  %buffer.contiguous.load50 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address49, i32 1, <8 x i1> %127, <8 x float> zeroinitializer)
  %.spill.load51 = load float, ptr %.spill5, align 4
  %.splatinsert52 = insertelement <8 x float> poison, float %.spill.load51, i64 0
  %.splat53 = shufflevector <8 x float> %.splatinsert52, <8 x float> poison, <8 x i32> zeroinitializer
  %147 = fmul <8 x float> %.splat53, %buffer.contiguous.load50
  %.spill.load54 = load float, ptr %.spill6, align 4
  %.splatinsert55 = insertelement <8 x float> poison, float %.spill.load54, i64 0
  %.splat56 = shufflevector <8 x float> %.splatinsert55, <8 x float> poison, <8 x i32> zeroinitializer
  %148 = fmul <8 x float> %.splat56, %buffer.contiguous.load50
  %149 = fmul <8 x float> %148, %buffer.contiguous.load50
  %150 = fmul <8 x float> %149, %buffer.contiguous.load50
  %151 = fadd <8 x float> %buffer.contiguous.load50, %150
  %.spill.load57 = load float, ptr %.spill7, align 4
  %.splatinsert58 = insertelement <8 x float> poison, float %.spill.load57, i64 0
  %.splat59 = shufflevector <8 x float> %.splatinsert58, <8 x float> poison, <8 x i32> zeroinitializer
  %152 = fmul <8 x float> %.splat59, %151
  %153 = select <8 x i1> %127, <8 x float> %152, <8 x float> zeroinitializer
  %native.tanh60 = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %153)
  %.spill.load61 = load float, ptr %.spill8, align 4
  %.splatinsert62 = insertelement <8 x float> poison, float %.spill.load61, i64 0
  %.splat63 = shufflevector <8 x float> %.splatinsert62, <8 x float> poison, <8 x i32> zeroinitializer
  %154 = fadd <8 x float> %.splat63, %native.tanh60
  %155 = fmul <8 x float> %147, %154
  %156 = extractvalue { ptr, i64 } %15, 0
  %157 = select <8 x i1> %127, <8 x i64> %140, <8 x i64> zeroinitializer
  %158 = extractelement <8 x i64> %157, i32 %134
  %159 = zext i32 %134 to i64
  %160 = sub i64 %158, %159
  %161 = mul i64 %160, 4
  %buffer.contiguous.address64 = getelementptr i8, ptr %156, i64 %161
  %buffer.contiguous.load65 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address64, i32 1, <8 x i1> %127, <8 x float> zeroinitializer)
  %162 = fadd <8 x float> %155, %buffer.contiguous.load65
  %163 = extractvalue { ptr, i64 } %27, 0
  %164 = extractelement <8 x i64> %140, i32 %134
  %165 = zext i32 %134 to i64
  %166 = sub i64 %164, %165
  %167 = mul i64 %166, 4
  %buffer.contiguous.address66 = getelementptr i8, ptr %163, i64 %167
  call void @llvm.masked.store.v8f32.p0(<8 x float> %162, ptr %buffer.contiguous.address66, i32 1, <8 x i1> %127)
  %168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %169 = bitcast <8 x i1> %129 to i8
  %170 = call i8 @llvm.cttz.i8(i8 %169, i1 false)
  %171 = zext i8 %170 to i32
  %172 = select i1 %168, i32 %171, i32 0
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.20, %direct.schedule.4
  ret void

direct.schedule.7:                                ; preds = %direct.false
  %173 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %173, 0
  %176 = select <8 x i1> %51, <8 x ptr> %174, <8 x ptr> %175
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %173, 1
  %179 = select <8 x i1> %51, <8 x i64> %177, <8 x i64> %178
  %180 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %176, 0
  %181 = insertvalue { <8 x ptr>, <8 x i64> } %180, <8 x i64> %179, 1
  store { <8 x ptr>, <8 x i64> } %181, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot9, align 4
  br label %direct.schedule.8

direct.schedule.8:                                ; preds = %direct.schedule.9, %direct.schedule.7
  %.state67 = load i64, ptr %.slot9, align 4
  %182 = icmp slt i64 %.state67, 8
  br i1 %182, label %direct.true68, label %direct.false69

direct.schedule.9:                                ; preds = %direct.true68
  %.state70 = load i64, ptr %.slot9, align 4
  %183 = mul i64 %.state70, 8
  %.splatinsert71 = insertelement <8 x i64> poison, i64 %183, i64 0
  %.splat72 = shufflevector <8 x i64> %.splatinsert71, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load73 = load <8 x i64>, ptr %.spill, align 64
  %184 = add <8 x i64> %.splat72, %.spill.load73
  %.spill.load74 = load <8 x i64>, ptr %.spill4, align 64
  %185 = add <8 x i64> %.spill.load74, zeroinitializer
  %186 = add <8 x i64> zeroinitializer, %185
  %187 = add <8 x i64> zeroinitializer, %184
  %188 = mul <8 x i64> %186, splat (i64 65)
  %189 = add <8 x i64> %188, %187
  %190 = extractvalue { ptr, i64 } %9, 0
  %191 = extractelement <8 x i64> %189, i32 0
  %192 = sub i64 %191, 0
  %193 = mul i64 %192, 4
  %buffer.contiguous.address75 = getelementptr i8, ptr %190, i64 %193
  %buffer.contiguous.load76 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address75, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %194 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state77 = load i64, ptr %.slot9, align 4
  %.splatinsert78 = insertelement <8 x i64> poison, i64 %.state77, i64 0
  %.splat79 = shufflevector <8 x i64> %.splatinsert78, <8 x i64> poison, <8 x i32> zeroinitializer
  %196 = mul <8 x i64> %.splat79, splat (i64 32)
  %197 = add <8 x i64> %195, %196
  %198 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %194, 0
  %199 = insertvalue { <8 x ptr>, <8 x i64> } %198, <8 x i64> %197, 1
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %199, 1
  %202 = extractelement <8 x ptr> %200, i32 0
  %203 = extractelement <8 x i64> %201, i32 0
  %204 = sub i64 %203, 0
  %205 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %206 = select i1 %205, i64 %204, i64 0
  %private.contiguous.address = getelementptr i8, ptr %202, i64 %206
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %207 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load76, <8 x float> %private.contiguous.preserve
  store <8 x float> %207, ptr %private.contiguous.address, align 4
  %.state80 = load i64, ptr %.slot9, align 4
  %208 = add i64 %.state80, 1
  store i64 %208, ptr %.slot9, align 4
  br label %direct.schedule.8

direct.schedule.10:                               ; preds = %direct.false69
  %.spill.load81 = load <8 x i64>, ptr %.spill, align 64
  %209 = icmp slt <8 x i64> %.spill.load81, splat (i64 1)
  %210 = load <8 x i1>, ptr %.spill10, align 1
  %211 = select <8 x i1> %51, <8 x i1> %209, <8 x i1> %210
  store <8 x i1> %211, ptr %.spill10, align 1
  %212 = and <8 x i1> %51, %209
  %213 = xor <8 x i1> %209, splat (i1 true)
  %214 = and <8 x i1> %51, %213
  %215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %212)
  %216 = bitcast <8 x i1> %212 to i8
  %217 = call i8 @llvm.cttz.i8(i8 %216, i1 false)
  %218 = zext i8 %217 to i32
  %219 = select i1 %215, i32 %218, i32 0
  %.spill.load82 = load <8 x i64>, ptr %.spill, align 64
  %220 = add <8 x i64> splat (i64 64), %.spill.load82
  %.spill.load83 = load <8 x i64>, ptr %.spill4, align 64
  %221 = add <8 x i64> %.spill.load83, zeroinitializer
  %222 = add <8 x i64> zeroinitializer, %221
  %223 = add <8 x i64> zeroinitializer, %220
  %224 = mul <8 x i64> %222, splat (i64 65)
  %225 = add <8 x i64> %224, %223
  %226 = extractvalue { ptr, i64 } %9, 0
  %227 = select <8 x i1> %212, <8 x i64> %225, <8 x i64> zeroinitializer
  %228 = extractelement <8 x i64> %227, i32 %219
  %229 = zext i32 %219 to i64
  %230 = sub i64 %228, %229
  %231 = mul i64 %230, 4
  %buffer.contiguous.address84 = getelementptr i8, ptr %226, i64 %231
  %buffer.contiguous.load85 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address84, i32 1, <8 x i1> %212, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load86 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 0
  %233 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 1
  %234 = add <8 x i64> %233, splat (i64 256)
  %235 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %232, 0
  %236 = insertvalue { <8 x ptr>, <8 x i64> } %235, <8 x i64> %234, 1
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %236, 1
  %239 = extractelement <8 x ptr> %237, i32 0
  %240 = extractelement <8 x i64> %238, i32 %219
  %241 = zext i32 %219 to i64
  %242 = mul i64 %241, 4
  %243 = sub i64 %240, %242
  %244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %212)
  %245 = select i1 %244, i64 %243, i64 0
  %private.contiguous.address87 = getelementptr i8, ptr %239, i64 %245
  %private.contiguous.preserve88 = load <8 x float>, ptr %private.contiguous.address87, align 4
  %246 = select <8 x i1> %212, <8 x float> %buffer.contiguous.load85, <8 x float> %private.contiguous.preserve88
  store <8 x float> %246, ptr %private.contiguous.address87, align 4
  %247 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %214)
  %248 = bitcast <8 x i1> %214 to i8
  %249 = call i8 @llvm.cttz.i8(i8 %248, i1 false)
  %250 = zext i8 %249 to i32
  %251 = select i1 %247, i32 %250, i32 0
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.10
  %252 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %252, 0
  %255 = select <8 x i1> %51, <8 x ptr> %253, <8 x ptr> %254
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %252, 1
  %258 = select <8 x i1> %51, <8 x i64> %256, <8 x i64> %257
  %259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %255, 0
  %260 = insertvalue { <8 x ptr>, <8 x i64> } %259, <8 x i64> %258, 1
  store { <8 x ptr>, <8 x i64> } %260, ptr %tile_snapshot.spill11, align 64
  %261 = load <8 x i64>, ptr %.slot12, align 64
  %262 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %261
  store <8 x i64> %262, ptr %.slot12, align 64
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state89 = load <8 x i64>, ptr %.slot12, align 64
  %263 = icmp slt <8 x i64> %.state89, splat (i64 8)
  %264 = extractelement <8 x i1> %263, i32 0
  br i1 %264, label %direct.true90, label %direct.false91

direct.schedule.14:                               ; preds = %direct.true90
  %.state92 = load <8 x i64>, ptr %.slot12, align 64
  %265 = mul <8 x i64> %.state92, splat (i64 8)
  %.spill.load93 = load <8 x i64>, ptr %.spill, align 64
  %266 = add <8 x i64> %265, %.spill.load93
  %.spill.load94 = load <8 x i64>, ptr %.spill4, align 64
  %267 = add <8 x i64> %.spill.load94, zeroinitializer
  %268 = add <8 x i64> zeroinitializer, %267
  %269 = add <8 x i64> zeroinitializer, %266
  %270 = mul <8 x i64> %268, splat (i64 65)
  %271 = add <8 x i64> %270, %269
  %272 = extractvalue { ptr, i64 } %15, 0
  %273 = extractelement <8 x i64> %271, i32 0
  %274 = sub i64 %273, 0
  %275 = mul i64 %274, 4
  %buffer.contiguous.address95 = getelementptr i8, ptr %272, i64 %275
  %buffer.contiguous.load96 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address95, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load97 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 0
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 1
  %.state98 = load <8 x i64>, ptr %.slot12, align 64
  %278 = mul <8 x i64> %.state98, splat (i64 32)
  %279 = add <8 x i64> %277, %278
  %280 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %276, 0
  %281 = insertvalue { <8 x ptr>, <8 x i64> } %280, <8 x i64> %279, 1
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %281, 1
  %284 = extractelement <8 x ptr> %282, i32 0
  %285 = extractelement <8 x i64> %283, i32 0
  %286 = sub i64 %285, 0
  %287 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %288 = select i1 %287, i64 %286, i64 0
  %private.contiguous.address99 = getelementptr i8, ptr %284, i64 %288
  %private.contiguous.preserve100 = load <8 x float>, ptr %private.contiguous.address99, align 4
  %289 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load96, <8 x float> %private.contiguous.preserve100
  store <8 x float> %289, ptr %private.contiguous.address99, align 4
  %.state101 = load <8 x i64>, ptr %.slot12, align 64
  %290 = add <8 x i64> %.state101, splat (i64 1)
  %291 = load <8 x i64>, ptr %.slot12, align 64
  %292 = select <8 x i1> %51, <8 x i64> %290, <8 x i64> %291
  store <8 x i64> %292, ptr %.slot12, align 64
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false91
  %.spill.load102 = load <8 x i1>, ptr %.spill10, align 1
  %293 = and <8 x i1> %51, %.spill.load102
  %294 = xor <8 x i1> %.spill.load102, splat (i1 true)
  %295 = and <8 x i1> %51, %294
  %296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %293)
  %297 = bitcast <8 x i1> %293 to i8
  %298 = call i8 @llvm.cttz.i8(i8 %297, i1 false)
  %299 = zext i8 %298 to i32
  %300 = select i1 %296, i32 %299, i32 0
  %.spill.load103 = load <8 x i64>, ptr %.spill, align 64
  %301 = add <8 x i64> splat (i64 64), %.spill.load103
  %.spill.load104 = load <8 x i64>, ptr %.spill4, align 64
  %302 = add <8 x i64> %.spill.load104, zeroinitializer
  %303 = add <8 x i64> zeroinitializer, %302
  %304 = add <8 x i64> zeroinitializer, %301
  %305 = mul <8 x i64> %303, splat (i64 65)
  %306 = add <8 x i64> %305, %304
  %307 = extractvalue { ptr, i64 } %15, 0
  %308 = select <8 x i1> %293, <8 x i64> %306, <8 x i64> zeroinitializer
  %309 = extractelement <8 x i64> %308, i32 %300
  %310 = zext i32 %300 to i64
  %311 = sub i64 %309, %310
  %312 = mul i64 %311, 4
  %buffer.contiguous.address105 = getelementptr i8, ptr %307, i64 %312
  %buffer.contiguous.load106 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address105, i32 1, <8 x i1> %293, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load107 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 1
  %315 = add <8 x i64> %314, splat (i64 256)
  %316 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %313, 0
  %317 = insertvalue { <8 x ptr>, <8 x i64> } %316, <8 x i64> %315, 1
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %317, 1
  %320 = extractelement <8 x ptr> %318, i32 0
  %321 = extractelement <8 x i64> %319, i32 %300
  %322 = zext i32 %300 to i64
  %323 = mul i64 %322, 4
  %324 = sub i64 %321, %323
  %325 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %293)
  %326 = select i1 %325, i64 %324, i64 0
  %private.contiguous.address108 = getelementptr i8, ptr %320, i64 %326
  %private.contiguous.preserve109 = load <8 x float>, ptr %private.contiguous.address108, align 4
  %327 = select <8 x i1> %293, <8 x float> %buffer.contiguous.load106, <8 x float> %private.contiguous.preserve109
  store <8 x float> %327, ptr %private.contiguous.address108, align 4
  %328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %295)
  %329 = bitcast <8 x i1> %295 to i8
  %330 = call i8 @llvm.cttz.i8(i8 %329, i1 false)
  %331 = zext i8 %330 to i32
  %332 = select i1 %328, i32 %331, i32 0
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.15
  %333 = load <8 x i64>, ptr %.slot13, align 64
  %334 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %333
  store <8 x i64> %334, ptr %.slot13, align 64
  br label %direct.schedule.18

direct.schedule.18:                               ; preds = %direct.schedule.19, %direct.schedule.17
  %.state110 = load <8 x i64>, ptr %.slot13, align 64
  %335 = icmp slt <8 x i64> %.state110, splat (i64 8)
  %336 = extractelement <8 x i1> %335, i32 0
  br i1 %336, label %direct.true111, label %direct.false112

direct.schedule.19:                               ; preds = %direct.true111
  %.state113 = load <8 x i64>, ptr %.slot13, align 64
  %337 = mul <8 x i64> %.state113, splat (i64 8)
  %.spill.load114 = load <8 x i64>, ptr %.spill, align 64
  %338 = add <8 x i64> %337, %.spill.load114
  %.spill.load115 = load <8 x i64>, ptr %.spill4, align 64
  %339 = add <8 x i64> %.spill.load115, zeroinitializer
  %340 = add <8 x i64> zeroinitializer, %339
  %341 = add <8 x i64> zeroinitializer, %338
  %342 = mul <8 x i64> %340, splat (i64 65)
  %343 = add <8 x i64> %342, %341
  %tile_snapshot.spill.load116 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 0
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 1
  %.state117 = load <8 x i64>, ptr %.slot13, align 64
  %346 = mul <8 x i64> %.state117, splat (i64 32)
  %347 = add <8 x i64> %345, %346
  %348 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %344, 0
  %349 = insertvalue { <8 x ptr>, <8 x i64> } %348, <8 x i64> %347, 1
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %351 = extractvalue { <8 x ptr>, <8 x i64> } %349, 1
  %352 = extractelement <8 x ptr> %350, i32 0
  %353 = extractelement <8 x i64> %351, i32 0
  %354 = sub i64 %353, 0
  %355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %356 = select i1 %355, i64 %354, i64 0
  %private.contiguous.address118 = getelementptr i8, ptr %352, i64 %356
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address118, align 4
  %357 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.spill.load119 = load float, ptr %.spill5, align 4
  %.splatinsert120 = insertelement <8 x float> poison, float %.spill.load119, i64 0
  %.splat121 = shufflevector <8 x float> %.splatinsert120, <8 x float> poison, <8 x i32> zeroinitializer
  %358 = fmul <8 x float> %.splat121, %357
  %.spill.load122 = load float, ptr %.spill6, align 4
  %.splatinsert123 = insertelement <8 x float> poison, float %.spill.load122, i64 0
  %.splat124 = shufflevector <8 x float> %.splatinsert123, <8 x float> poison, <8 x i32> zeroinitializer
  %359 = fmul <8 x float> %.splat124, %357
  %360 = fmul <8 x float> %359, %357
  %361 = fmul <8 x float> %360, %357
  %362 = fadd <8 x float> %357, %361
  %.spill.load125 = load float, ptr %.spill7, align 4
  %.splatinsert126 = insertelement <8 x float> poison, float %.spill.load125, i64 0
  %.splat127 = shufflevector <8 x float> %.splatinsert126, <8 x float> poison, <8 x i32> zeroinitializer
  %363 = fmul <8 x float> %.splat127, %362
  %364 = select <8 x i1> %51, <8 x float> %363, <8 x float> zeroinitializer
  %native.tanh128 = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %364)
  %.spill.load129 = load float, ptr %.spill8, align 4
  %.splatinsert130 = insertelement <8 x float> poison, float %.spill.load129, i64 0
  %.splat131 = shufflevector <8 x float> %.splatinsert130, <8 x float> poison, <8 x i32> zeroinitializer
  %365 = fadd <8 x float> %.splat131, %native.tanh128
  %366 = fmul <8 x float> %358, %365
  %tile_snapshot.spill.load132 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %367 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 0
  %368 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 1
  %.state133 = load <8 x i64>, ptr %.slot13, align 64
  %369 = mul <8 x i64> %.state133, splat (i64 32)
  %370 = add <8 x i64> %368, %369
  %371 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %367, 0
  %372 = insertvalue { <8 x ptr>, <8 x i64> } %371, <8 x i64> %370, 1
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %372, 1
  %375 = extractelement <8 x ptr> %373, i32 0
  %376 = extractelement <8 x i64> %374, i32 0
  %377 = sub i64 %376, 0
  %378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %379 = select i1 %378, i64 %377, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %375, i64 %379
  %private.contiguous.load135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %380 = select <8 x i1> %51, <8 x float> %private.contiguous.load135, <8 x float> zeroinitializer
  %381 = fadd <8 x float> %366, %380
  %382 = extractvalue { ptr, i64 } %27, 0
  %383 = extractelement <8 x i64> %343, i32 0
  %384 = sub i64 %383, 0
  %385 = mul i64 %384, 4
  %buffer.contiguous.address136 = getelementptr i8, ptr %382, i64 %385
  call void @llvm.masked.store.v8f32.p0(<8 x float> %381, ptr %buffer.contiguous.address136, i32 1, <8 x i1> %51)
  %.state137 = load <8 x i64>, ptr %.slot13, align 64
  %386 = add <8 x i64> %.state137, splat (i64 1)
  %387 = load <8 x i64>, ptr %.slot13, align 64
  %388 = select <8 x i1> %51, <8 x i64> %386, <8 x i64> %387
  store <8 x i64> %388, ptr %.slot13, align 64
  br label %direct.schedule.18

direct.schedule.20:                               ; preds = %direct.false112
  %.spill.load138 = load <8 x i1>, ptr %.spill10, align 1
  %389 = and <8 x i1> %51, %.spill.load138
  %390 = xor <8 x i1> %.spill.load138, splat (i1 true)
  %391 = and <8 x i1> %51, %390
  %392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %389)
  %393 = bitcast <8 x i1> %389 to i8
  %394 = call i8 @llvm.cttz.i8(i8 %393, i1 false)
  %395 = zext i8 %394 to i32
  %396 = select i1 %392, i32 %395, i32 0
  %.spill.load139 = load <8 x i64>, ptr %.spill, align 64
  %397 = add <8 x i64> splat (i64 64), %.spill.load139
  %.spill.load140 = load <8 x i64>, ptr %.spill4, align 64
  %398 = add <8 x i64> %.spill.load140, zeroinitializer
  %399 = add <8 x i64> zeroinitializer, %398
  %400 = add <8 x i64> zeroinitializer, %397
  %401 = mul <8 x i64> %399, splat (i64 65)
  %402 = add <8 x i64> %401, %400
  %tile_snapshot.spill.load141 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 0
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 1
  %405 = add <8 x i64> %404, splat (i64 256)
  %406 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %403, 0
  %407 = insertvalue { <8 x ptr>, <8 x i64> } %406, <8 x i64> %405, 1
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %407, 1
  %410 = extractelement <8 x ptr> %408, i32 0
  %411 = extractelement <8 x i64> %409, i32 %396
  %412 = zext i32 %396 to i64
  %413 = mul i64 %412, 4
  %414 = sub i64 %411, %413
  %415 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %389)
  %416 = select i1 %415, i64 %414, i64 0
  %private.contiguous.address142 = getelementptr i8, ptr %410, i64 %416
  %private.contiguous.load143 = load <8 x float>, ptr %private.contiguous.address142, align 4
  %417 = select <8 x i1> %389, <8 x float> %private.contiguous.load143, <8 x float> zeroinitializer
  %.spill.load144 = load float, ptr %.spill5, align 4
  %.splatinsert145 = insertelement <8 x float> poison, float %.spill.load144, i64 0
  %.splat146 = shufflevector <8 x float> %.splatinsert145, <8 x float> poison, <8 x i32> zeroinitializer
  %418 = fmul <8 x float> %.splat146, %417
  %.spill.load147 = load float, ptr %.spill6, align 4
  %.splatinsert148 = insertelement <8 x float> poison, float %.spill.load147, i64 0
  %.splat149 = shufflevector <8 x float> %.splatinsert148, <8 x float> poison, <8 x i32> zeroinitializer
  %419 = fmul <8 x float> %.splat149, %417
  %420 = fmul <8 x float> %419, %417
  %421 = fmul <8 x float> %420, %417
  %422 = fadd <8 x float> %417, %421
  %.spill.load150 = load float, ptr %.spill7, align 4
  %.splatinsert151 = insertelement <8 x float> poison, float %.spill.load150, i64 0
  %.splat152 = shufflevector <8 x float> %.splatinsert151, <8 x float> poison, <8 x i32> zeroinitializer
  %423 = fmul <8 x float> %.splat152, %422
  %424 = select <8 x i1> %389, <8 x float> %423, <8 x float> zeroinitializer
  %native.tanh153 = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %424)
  %.spill.load154 = load float, ptr %.spill8, align 4
  %.splatinsert155 = insertelement <8 x float> poison, float %.spill.load154, i64 0
  %.splat156 = shufflevector <8 x float> %.splatinsert155, <8 x float> poison, <8 x i32> zeroinitializer
  %425 = fadd <8 x float> %.splat156, %native.tanh153
  %426 = fmul <8 x float> %418, %425
  %tile_snapshot.spill.load157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 0
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 1
  %429 = add <8 x i64> %428, splat (i64 256)
  %430 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %427, 0
  %431 = insertvalue { <8 x ptr>, <8 x i64> } %430, <8 x i64> %429, 1
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %431, 1
  %434 = extractelement <8 x ptr> %432, i32 0
  %435 = extractelement <8 x i64> %433, i32 %396
  %436 = zext i32 %396 to i64
  %437 = mul i64 %436, 4
  %438 = sub i64 %435, %437
  %439 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %389)
  %440 = select i1 %439, i64 %438, i64 0
  %private.contiguous.address158 = getelementptr i8, ptr %434, i64 %440
  %private.contiguous.load159 = load <8 x float>, ptr %private.contiguous.address158, align 4
  %441 = select <8 x i1> %389, <8 x float> %private.contiguous.load159, <8 x float> zeroinitializer
  %442 = fadd <8 x float> %426, %441
  %443 = extractvalue { ptr, i64 } %27, 0
  %444 = extractelement <8 x i64> %402, i32 %396
  %445 = zext i32 %396 to i64
  %446 = sub i64 %444, %445
  %447 = mul i64 %446, 4
  %buffer.contiguous.address160 = getelementptr i8, ptr %443, i64 %447
  call void @llvm.masked.store.v8f32.p0(<8 x float> %442, ptr %buffer.contiguous.address160, i32 1, <8 x i1> %389)
  %448 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %391)
  %449 = bitcast <8 x i1> %391 to i8
  %450 = call i8 @llvm.cttz.i8(i8 %449, i1 false)
  %451 = zext i8 %450 to i32
  %452 = select i1 %448, i32 %451, i32 0
  br label %direct.schedule.6

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.0
  br label %direct.schedule.1

direct.false:                                     ; preds = %direct.schedule.0
  br label %direct.schedule.7

direct.true24:                                    ; preds = %direct.schedule.2
  br label %direct.schedule.3

direct.false25:                                   ; preds = %direct.schedule.2
  br label %direct.schedule.4

direct.true68:                                    ; preds = %direct.schedule.8
  br label %direct.schedule.9

direct.false69:                                   ; preds = %direct.schedule.8
  br label %direct.schedule.10

direct.true90:                                    ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false91:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true111:                                   ; preds = %direct.schedule.18
  br label %direct.schedule.19

direct.false112:                                  ; preds = %direct.schedule.18
  br label %direct.schedule.20
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %x) #2 {
entry:
  %0 = bitcast <8 x float> %x to <8 x i32>
  %1 = and <8 x i32> %0, splat (i32 2147483647)
  %2 = bitcast <8 x i32> %1 to <8 x float>
  %3 = fcmp contract ole <8 x float> %2, splat (float 1.000000e+00)
  %4 = fmul contract <8 x float> %2, %2
  %5 = fmul contract <8 x float> splat (float 0x3DE6124620000000), %4
  %6 = fadd contract <8 x float> %5, splat (float 0x3E5AE64560000000)
  %7 = fmul contract <8 x float> %6, %4
  %8 = fadd contract <8 x float> %7, splat (float 0x3EC71DE3A0000000)
  %9 = fmul contract <8 x float> %8, %4
  %10 = fadd contract <8 x float> %9, splat (float 0x3F2A01A020000000)
  %11 = fmul contract <8 x float> %10, %4
  %12 = fadd contract <8 x float> %11, splat (float 0x3F81111120000000)
  %13 = fmul contract <8 x float> %12, %4
  %14 = fadd contract <8 x float> %13, splat (float 0x3FC5555560000000)
  %15 = fmul contract <8 x float> %14, %4
  %16 = fadd contract <8 x float> %15, splat (float 1.000000e+00)
  %17 = fmul contract <8 x float> %2, %16
  %18 = fmul contract <8 x float> %2, %2
  %19 = fmul contract <8 x float> splat (float 0x3E21EED8E0000000), %18
  %20 = fadd contract <8 x float> %19, splat (float 0x3E927E4FC0000000)
  %21 = fmul contract <8 x float> %20, %18
  %22 = fadd contract <8 x float> %21, splat (float 0x3EFA01A020000000)
  %23 = fmul contract <8 x float> %22, %18
  %24 = fadd contract <8 x float> %23, splat (float 0x3F56C16C20000000)
  %25 = fmul contract <8 x float> %24, %18
  %26 = fadd contract <8 x float> %25, splat (float 0x3FA5555560000000)
  %27 = fmul contract <8 x float> %26, %18
  %28 = fadd contract <8 x float> %27, splat (float 5.000000e-01)
  %29 = fmul contract <8 x float> %28, %18
  %30 = fadd contract <8 x float> %29, splat (float 1.000000e+00)
  %31 = fdiv contract <8 x float> %17, %30
  %32 = fcmp contract ole <8 x float> %2, splat (float 9.000000e+00)
  %33 = select contract <8 x i1> %32, <8 x float> %2, <8 x float> zeroinitializer
  %exp.half = call contract <8 x float> @__luisa_cpu_native_exp_half_f32_v8_u10(<8 x float> %33)
  %34 = fdiv contract <8 x float> splat (float 2.500000e-01), %exp.half
  %35 = fsub contract <8 x float> %exp.half, %34
  %36 = fadd contract <8 x float> %exp.half, %34
  %37 = fdiv contract <8 x float> %35, %36
  %38 = select contract <8 x i1> %32, <8 x float> %37, <8 x float> splat (float 1.000000e+00)
  %39 = select contract <8 x i1> %3, <8 x float> %31, <8 x float> %38
  %40 = bitcast <8 x float> %39 to <8 x i32>
  %41 = and <8 x i32> %40, splat (i32 2147483647)
  %42 = bitcast <8 x float> %x to <8 x i32>
  %43 = and <8 x i32> %42, splat (i32 -2147483648)
  %44 = or <8 x i32> %41, %43
  %45 = bitcast <8 x i32> %44 to <8 x float>
  %46 = fcmp contract uno <8 x float> %x, %x
  %47 = select contract <8 x i1> %46, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %45
  ret <8 x float> %47
}

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_half_f32_v8_u10(<8 x float> %x) #2 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = sub <8 x i32> %11, splat (i32 1)
  %32 = ashr <8 x i32> %31, splat (i32 1)
  %33 = add <8 x i32> %32, splat (i32 127)
  %34 = shl <8 x i32> %33, splat (i32 23)
  %35 = bitcast <8 x i32> %34 to <8 x float>
  %36 = fmul <8 x float> %30, %35
  %37 = sub <8 x i32> %31, %32
  %38 = add <8 x i32> %37, splat (i32 127)
  %39 = shl <8 x i32> %38, splat (i32 23)
  %40 = bitcast <8 x i32> %39 to <8 x float>
  %41 = fmul <8 x float> %36, %40
  %42 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %43 = select <8 x i1> %42, <8 x float> zeroinitializer, <8 x float> %41
  %44 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %45 = select <8 x i1> %44, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %43
  %46 = fcmp uno <8 x float> %x, %x
  %47 = select <8 x i1> %46, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %45
  ret <8 x float> %47
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [288 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.spill6 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill6, align 4
  %.spill7 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill7, align 4
  %.spill8 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill8, align 4
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot9 = alloca i64, align 8
  store i64 0, ptr %.slot9, align 4
  %.spill10 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill10, align 1
  %tile_snapshot.spill11 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill11, align 64
  %.slot12 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot12, align 64
  %.slot13 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot13, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert14 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat15 = shufflevector <8 x i32> %.splatinsert14, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat15, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert16 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat17 = shufflevector <8 x i32> %.splatinsert16, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat17, %41
  %44 = mul i32 %32, 1
  %.splatinsert18 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat19 = shufflevector <8 x i32> %.splatinsert18, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat19, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert20 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat21, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert22 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat23 = shufflevector <8 x i32> %.splatinsert22, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat23
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  store float 5.000000e-01, ptr %.spill5, align 4
  store float 0x3FA6E4E260000000, ptr %.spill6, align 4
  store float 0x3FE9884540000000, ptr %.spill7, align 4
  store float 1.000000e+00, ptr %.spill8, align 4
  %66 = extractvalue { ptr, i64 } %9, 1
  %67 = extractvalue { ptr, i64 } %9, 0
  %68 = ptrtoint ptr %67 to i64
  %69 = extractvalue { ptr, i64 } %27, 1
  %70 = extractvalue { ptr, i64 } %27, 0
  %71 = ptrtoint ptr %70 to i64
  %72 = icmp uge i64 %68, %71
  %73 = sub i64 %68, %71
  %74 = icmp uge i64 %73, 4420
  %75 = and i1 %72, %74
  %76 = icmp uge i64 %71, %68
  %77 = sub i64 %71, %68
  %78 = icmp uge i64 %77, 4420
  %79 = and i1 %76, %78
  %80 = or i1 %75, %79
  %81 = and i1 true, %80
  %82 = extractvalue { ptr, i64 } %15, 1
  %83 = extractvalue { ptr, i64 } %15, 0
  %84 = ptrtoint ptr %83 to i64
  %85 = icmp uge i64 %84, %71
  %86 = sub i64 %84, %71
  %87 = icmp uge i64 %86, 4420
  %88 = and i1 %85, %87
  %89 = icmp uge i64 %71, %84
  %90 = sub i64 %71, %84
  %91 = icmp uge i64 %90, 4420
  %92 = and i1 %89, %91
  %93 = or i1 %88, %92
  %94 = and i1 %81, %93
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.1:                                ; preds = %direct.true
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.2:                                ; preds = %direct.schedule.3, %direct.schedule.1
  %.state = load i64, ptr %.slot, align 4
  %95 = icmp slt i64 %.state, 8
  br i1 %95, label %direct.true24, label %direct.false25

direct.schedule.3:                                ; preds = %direct.true24
  %.state26 = load i64, ptr %.slot, align 4
  %96 = mul i64 %.state26, 8
  %.splatinsert27 = insertelement <8 x i64> poison, i64 %96, i64 0
  %.splat28 = shufflevector <8 x i64> %.splatinsert27, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %97 = add <8 x i64> %.splat28, %.spill.load
  %.spill.load29 = load <8 x i64>, ptr %.spill4, align 64
  %98 = add <8 x i64> %.spill.load29, zeroinitializer
  %99 = add <8 x i64> zeroinitializer, %98
  %100 = add <8 x i64> zeroinitializer, %97
  %101 = mul <8 x i64> %99, splat (i64 65)
  %102 = add <8 x i64> %101, %100
  %103 = extractvalue { ptr, i64 } %9, 0
  %104 = extractelement <8 x i64> %102, i32 0
  %105 = sub i64 %104, 0
  %106 = mul i64 %105, 4
  %buffer.contiguous.address = getelementptr i8, ptr %103, i64 %106
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %.spill.load30 = load float, ptr %.spill5, align 4
  %.splatinsert31 = insertelement <8 x float> poison, float %.spill.load30, i64 0
  %.splat32 = shufflevector <8 x float> %.splatinsert31, <8 x float> poison, <8 x i32> zeroinitializer
  %107 = fmul <8 x float> %.splat32, %buffer.contiguous.load
  %.spill.load33 = load float, ptr %.spill6, align 4
  %.splatinsert34 = insertelement <8 x float> poison, float %.spill.load33, i64 0
  %.splat35 = shufflevector <8 x float> %.splatinsert34, <8 x float> poison, <8 x i32> zeroinitializer
  %108 = fmul <8 x float> %.splat35, %buffer.contiguous.load
  %109 = fmul <8 x float> %108, %buffer.contiguous.load
  %110 = fmul <8 x float> %109, %buffer.contiguous.load
  %111 = fadd <8 x float> %buffer.contiguous.load, %110
  %.spill.load36 = load float, ptr %.spill7, align 4
  %.splatinsert37 = insertelement <8 x float> poison, float %.spill.load36, i64 0
  %.splat38 = shufflevector <8 x float> %.splatinsert37, <8 x float> poison, <8 x i32> zeroinitializer
  %112 = fmul <8 x float> %.splat38, %111
  %113 = select <8 x i1> %51, <8 x float> %112, <8 x float> zeroinitializer
  %native.tanh = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %113)
  %.spill.load39 = load float, ptr %.spill8, align 4
  %.splatinsert40 = insertelement <8 x float> poison, float %.spill.load39, i64 0
  %.splat41 = shufflevector <8 x float> %.splatinsert40, <8 x float> poison, <8 x i32> zeroinitializer
  %114 = fadd <8 x float> %.splat41, %native.tanh
  %115 = fmul <8 x float> %107, %114
  %116 = extractvalue { ptr, i64 } %15, 0
  %117 = extractelement <8 x i64> %102, i32 0
  %118 = sub i64 %117, 0
  %119 = mul i64 %118, 4
  %buffer.contiguous.address42 = getelementptr i8, ptr %116, i64 %119
  %buffer.contiguous.load43 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address42, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %120 = fadd <8 x float> %115, %buffer.contiguous.load43
  %121 = extractvalue { ptr, i64 } %27, 0
  %122 = extractelement <8 x i64> %102, i32 0
  %123 = sub i64 %122, 0
  %124 = mul i64 %123, 4
  %buffer.contiguous.address44 = getelementptr i8, ptr %121, i64 %124
  call void @llvm.masked.store.v8f32.p0(<8 x float> %120, ptr %buffer.contiguous.address44, i32 1, <8 x i1> %51)
  %.state45 = load i64, ptr %.slot, align 4
  %125 = add i64 %.state45, 1
  store i64 %125, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.4:                                ; preds = %direct.false25
  %.spill.load46 = load <8 x i64>, ptr %.spill, align 64
  %126 = icmp slt <8 x i64> %.spill.load46, splat (i64 1)
  %127 = and <8 x i1> %51, %126
  %128 = xor <8 x i1> %126, splat (i1 true)
  %129 = and <8 x i1> %51, %128
  %130 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %127)
  %131 = bitcast <8 x i1> %127 to i8
  %132 = call i8 @llvm.cttz.i8(i8 %131, i1 false)
  %133 = zext i8 %132 to i32
  %134 = select i1 %130, i32 %133, i32 0
  %.spill.load47 = load <8 x i64>, ptr %.spill, align 64
  %135 = add <8 x i64> splat (i64 64), %.spill.load47
  %.spill.load48 = load <8 x i64>, ptr %.spill4, align 64
  %136 = add <8 x i64> %.spill.load48, zeroinitializer
  %137 = add <8 x i64> zeroinitializer, %136
  %138 = add <8 x i64> zeroinitializer, %135
  %139 = mul <8 x i64> %137, splat (i64 65)
  %140 = add <8 x i64> %139, %138
  %141 = extractvalue { ptr, i64 } %9, 0
  %142 = select <8 x i1> %127, <8 x i64> %140, <8 x i64> zeroinitializer
  %143 = extractelement <8 x i64> %142, i32 %134
  %144 = zext i32 %134 to i64
  %145 = sub i64 %143, %144
  %146 = mul i64 %145, 4
  %buffer.contiguous.address49 = getelementptr i8, ptr %141, i64 %146
  %buffer.contiguous.load50 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address49, i32 1, <8 x i1> %127, <8 x float> zeroinitializer)
  %.spill.load51 = load float, ptr %.spill5, align 4
  %.splatinsert52 = insertelement <8 x float> poison, float %.spill.load51, i64 0
  %.splat53 = shufflevector <8 x float> %.splatinsert52, <8 x float> poison, <8 x i32> zeroinitializer
  %147 = fmul <8 x float> %.splat53, %buffer.contiguous.load50
  %.spill.load54 = load float, ptr %.spill6, align 4
  %.splatinsert55 = insertelement <8 x float> poison, float %.spill.load54, i64 0
  %.splat56 = shufflevector <8 x float> %.splatinsert55, <8 x float> poison, <8 x i32> zeroinitializer
  %148 = fmul <8 x float> %.splat56, %buffer.contiguous.load50
  %149 = fmul <8 x float> %148, %buffer.contiguous.load50
  %150 = fmul <8 x float> %149, %buffer.contiguous.load50
  %151 = fadd <8 x float> %buffer.contiguous.load50, %150
  %.spill.load57 = load float, ptr %.spill7, align 4
  %.splatinsert58 = insertelement <8 x float> poison, float %.spill.load57, i64 0
  %.splat59 = shufflevector <8 x float> %.splatinsert58, <8 x float> poison, <8 x i32> zeroinitializer
  %152 = fmul <8 x float> %.splat59, %151
  %153 = select <8 x i1> %127, <8 x float> %152, <8 x float> zeroinitializer
  %native.tanh60 = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %153)
  %.spill.load61 = load float, ptr %.spill8, align 4
  %.splatinsert62 = insertelement <8 x float> poison, float %.spill.load61, i64 0
  %.splat63 = shufflevector <8 x float> %.splatinsert62, <8 x float> poison, <8 x i32> zeroinitializer
  %154 = fadd <8 x float> %.splat63, %native.tanh60
  %155 = fmul <8 x float> %147, %154
  %156 = extractvalue { ptr, i64 } %15, 0
  %157 = select <8 x i1> %127, <8 x i64> %140, <8 x i64> zeroinitializer
  %158 = extractelement <8 x i64> %157, i32 %134
  %159 = zext i32 %134 to i64
  %160 = sub i64 %158, %159
  %161 = mul i64 %160, 4
  %buffer.contiguous.address64 = getelementptr i8, ptr %156, i64 %161
  %buffer.contiguous.load65 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address64, i32 1, <8 x i1> %127, <8 x float> zeroinitializer)
  %162 = fadd <8 x float> %155, %buffer.contiguous.load65
  %163 = extractvalue { ptr, i64 } %27, 0
  %164 = extractelement <8 x i64> %140, i32 %134
  %165 = zext i32 %134 to i64
  %166 = sub i64 %164, %165
  %167 = mul i64 %166, 4
  %buffer.contiguous.address66 = getelementptr i8, ptr %163, i64 %167
  call void @llvm.masked.store.v8f32.p0(<8 x float> %162, ptr %buffer.contiguous.address66, i32 1, <8 x i1> %127)
  %168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %129)
  %169 = bitcast <8 x i1> %129 to i8
  %170 = call i8 @llvm.cttz.i8(i8 %169, i1 false)
  %171 = zext i8 %170 to i32
  %172 = select i1 %168, i32 %171, i32 0
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.20, %direct.schedule.4
  ret void

direct.schedule.7:                                ; preds = %direct.false
  %173 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %173, 0
  %176 = select <8 x i1> %51, <8 x ptr> %174, <8 x ptr> %175
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %173, 1
  %179 = select <8 x i1> %51, <8 x i64> %177, <8 x i64> %178
  %180 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %176, 0
  %181 = insertvalue { <8 x ptr>, <8 x i64> } %180, <8 x i64> %179, 1
  store { <8 x ptr>, <8 x i64> } %181, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot9, align 4
  br label %direct.schedule.8

direct.schedule.8:                                ; preds = %direct.schedule.9, %direct.schedule.7
  %.state67 = load i64, ptr %.slot9, align 4
  %182 = icmp slt i64 %.state67, 8
  br i1 %182, label %direct.true68, label %direct.false69

direct.schedule.9:                                ; preds = %direct.true68
  %.state70 = load i64, ptr %.slot9, align 4
  %183 = mul i64 %.state70, 8
  %.splatinsert71 = insertelement <8 x i64> poison, i64 %183, i64 0
  %.splat72 = shufflevector <8 x i64> %.splatinsert71, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load73 = load <8 x i64>, ptr %.spill, align 64
  %184 = add <8 x i64> %.splat72, %.spill.load73
  %.spill.load74 = load <8 x i64>, ptr %.spill4, align 64
  %185 = add <8 x i64> %.spill.load74, zeroinitializer
  %186 = add <8 x i64> zeroinitializer, %185
  %187 = add <8 x i64> zeroinitializer, %184
  %188 = mul <8 x i64> %186, splat (i64 65)
  %189 = add <8 x i64> %188, %187
  %190 = extractvalue { ptr, i64 } %9, 0
  %191 = extractelement <8 x i64> %189, i32 0
  %192 = sub i64 %191, 0
  %193 = mul i64 %192, 4
  %buffer.contiguous.address75 = getelementptr i8, ptr %190, i64 %193
  %buffer.contiguous.load76 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address75, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %194 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state77 = load i64, ptr %.slot9, align 4
  %.splatinsert78 = insertelement <8 x i64> poison, i64 %.state77, i64 0
  %.splat79 = shufflevector <8 x i64> %.splatinsert78, <8 x i64> poison, <8 x i32> zeroinitializer
  %196 = mul <8 x i64> %.splat79, splat (i64 32)
  %197 = add <8 x i64> %195, %196
  %198 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %194, 0
  %199 = insertvalue { <8 x ptr>, <8 x i64> } %198, <8 x i64> %197, 1
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %199, 1
  %202 = extractelement <8 x ptr> %200, i32 0
  %203 = extractelement <8 x i64> %201, i32 0
  %204 = sub i64 %203, 0
  %205 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %206 = select i1 %205, i64 %204, i64 0
  %private.contiguous.address = getelementptr i8, ptr %202, i64 %206
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %207 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load76, <8 x float> %private.contiguous.preserve
  store <8 x float> %207, ptr %private.contiguous.address, align 4
  %.state80 = load i64, ptr %.slot9, align 4
  %208 = add i64 %.state80, 1
  store i64 %208, ptr %.slot9, align 4
  br label %direct.schedule.8

direct.schedule.10:                               ; preds = %direct.false69
  %.spill.load81 = load <8 x i64>, ptr %.spill, align 64
  %209 = icmp slt <8 x i64> %.spill.load81, splat (i64 1)
  %210 = load <8 x i1>, ptr %.spill10, align 1
  %211 = select <8 x i1> %51, <8 x i1> %209, <8 x i1> %210
  store <8 x i1> %211, ptr %.spill10, align 1
  %212 = and <8 x i1> %51, %209
  %213 = xor <8 x i1> %209, splat (i1 true)
  %214 = and <8 x i1> %51, %213
  %215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %212)
  %216 = bitcast <8 x i1> %212 to i8
  %217 = call i8 @llvm.cttz.i8(i8 %216, i1 false)
  %218 = zext i8 %217 to i32
  %219 = select i1 %215, i32 %218, i32 0
  %.spill.load82 = load <8 x i64>, ptr %.spill, align 64
  %220 = add <8 x i64> splat (i64 64), %.spill.load82
  %.spill.load83 = load <8 x i64>, ptr %.spill4, align 64
  %221 = add <8 x i64> %.spill.load83, zeroinitializer
  %222 = add <8 x i64> zeroinitializer, %221
  %223 = add <8 x i64> zeroinitializer, %220
  %224 = mul <8 x i64> %222, splat (i64 65)
  %225 = add <8 x i64> %224, %223
  %226 = extractvalue { ptr, i64 } %9, 0
  %227 = select <8 x i1> %212, <8 x i64> %225, <8 x i64> zeroinitializer
  %228 = extractelement <8 x i64> %227, i32 %219
  %229 = zext i32 %219 to i64
  %230 = sub i64 %228, %229
  %231 = mul i64 %230, 4
  %buffer.contiguous.address84 = getelementptr i8, ptr %226, i64 %231
  %buffer.contiguous.load85 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address84, i32 1, <8 x i1> %212, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load86 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 0
  %233 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 1
  %234 = add <8 x i64> %233, splat (i64 256)
  %235 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %232, 0
  %236 = insertvalue { <8 x ptr>, <8 x i64> } %235, <8 x i64> %234, 1
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %236, 1
  %239 = extractelement <8 x ptr> %237, i32 0
  %240 = extractelement <8 x i64> %238, i32 %219
  %241 = zext i32 %219 to i64
  %242 = mul i64 %241, 4
  %243 = sub i64 %240, %242
  %244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %212)
  %245 = select i1 %244, i64 %243, i64 0
  %private.contiguous.address87 = getelementptr i8, ptr %239, i64 %245
  %private.contiguous.preserve88 = load <8 x float>, ptr %private.contiguous.address87, align 4
  %246 = select <8 x i1> %212, <8 x float> %buffer.contiguous.load85, <8 x float> %private.contiguous.preserve88
  store <8 x float> %246, ptr %private.contiguous.address87, align 4
  %247 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %214)
  %248 = bitcast <8 x i1> %214 to i8
  %249 = call i8 @llvm.cttz.i8(i8 %248, i1 false)
  %250 = zext i8 %249 to i32
  %251 = select i1 %247, i32 %250, i32 0
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.10
  %252 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %252, 0
  %255 = select <8 x i1> %51, <8 x ptr> %253, <8 x ptr> %254
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %252, 1
  %258 = select <8 x i1> %51, <8 x i64> %256, <8 x i64> %257
  %259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %255, 0
  %260 = insertvalue { <8 x ptr>, <8 x i64> } %259, <8 x i64> %258, 1
  store { <8 x ptr>, <8 x i64> } %260, ptr %tile_snapshot.spill11, align 64
  %261 = load <8 x i64>, ptr %.slot12, align 64
  %262 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %261
  store <8 x i64> %262, ptr %.slot12, align 64
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state89 = load <8 x i64>, ptr %.slot12, align 64
  %263 = icmp slt <8 x i64> %.state89, splat (i64 8)
  %264 = extractelement <8 x i1> %263, i32 0
  br i1 %264, label %direct.true90, label %direct.false91

direct.schedule.14:                               ; preds = %direct.true90
  %.state92 = load <8 x i64>, ptr %.slot12, align 64
  %265 = mul <8 x i64> %.state92, splat (i64 8)
  %.spill.load93 = load <8 x i64>, ptr %.spill, align 64
  %266 = add <8 x i64> %265, %.spill.load93
  %.spill.load94 = load <8 x i64>, ptr %.spill4, align 64
  %267 = add <8 x i64> %.spill.load94, zeroinitializer
  %268 = add <8 x i64> zeroinitializer, %267
  %269 = add <8 x i64> zeroinitializer, %266
  %270 = mul <8 x i64> %268, splat (i64 65)
  %271 = add <8 x i64> %270, %269
  %272 = extractvalue { ptr, i64 } %15, 0
  %273 = extractelement <8 x i64> %271, i32 0
  %274 = sub i64 %273, 0
  %275 = mul i64 %274, 4
  %buffer.contiguous.address95 = getelementptr i8, ptr %272, i64 %275
  %buffer.contiguous.load96 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address95, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load97 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 0
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load97, 1
  %.state98 = load <8 x i64>, ptr %.slot12, align 64
  %278 = mul <8 x i64> %.state98, splat (i64 32)
  %279 = add <8 x i64> %277, %278
  %280 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %276, 0
  %281 = insertvalue { <8 x ptr>, <8 x i64> } %280, <8 x i64> %279, 1
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %281, 1
  %284 = extractelement <8 x ptr> %282, i32 0
  %285 = extractelement <8 x i64> %283, i32 0
  %286 = sub i64 %285, 0
  %287 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %288 = select i1 %287, i64 %286, i64 0
  %private.contiguous.address99 = getelementptr i8, ptr %284, i64 %288
  %private.contiguous.preserve100 = load <8 x float>, ptr %private.contiguous.address99, align 4
  %289 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load96, <8 x float> %private.contiguous.preserve100
  store <8 x float> %289, ptr %private.contiguous.address99, align 4
  %.state101 = load <8 x i64>, ptr %.slot12, align 64
  %290 = add <8 x i64> %.state101, splat (i64 1)
  %291 = load <8 x i64>, ptr %.slot12, align 64
  %292 = select <8 x i1> %51, <8 x i64> %290, <8 x i64> %291
  store <8 x i64> %292, ptr %.slot12, align 64
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false91
  %.spill.load102 = load <8 x i1>, ptr %.spill10, align 1
  %293 = and <8 x i1> %51, %.spill.load102
  %294 = xor <8 x i1> %.spill.load102, splat (i1 true)
  %295 = and <8 x i1> %51, %294
  %296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %293)
  %297 = bitcast <8 x i1> %293 to i8
  %298 = call i8 @llvm.cttz.i8(i8 %297, i1 false)
  %299 = zext i8 %298 to i32
  %300 = select i1 %296, i32 %299, i32 0
  %.spill.load103 = load <8 x i64>, ptr %.spill, align 64
  %301 = add <8 x i64> splat (i64 64), %.spill.load103
  %.spill.load104 = load <8 x i64>, ptr %.spill4, align 64
  %302 = add <8 x i64> %.spill.load104, zeroinitializer
  %303 = add <8 x i64> zeroinitializer, %302
  %304 = add <8 x i64> zeroinitializer, %301
  %305 = mul <8 x i64> %303, splat (i64 65)
  %306 = add <8 x i64> %305, %304
  %307 = extractvalue { ptr, i64 } %15, 0
  %308 = select <8 x i1> %293, <8 x i64> %306, <8 x i64> zeroinitializer
  %309 = extractelement <8 x i64> %308, i32 %300
  %310 = zext i32 %300 to i64
  %311 = sub i64 %309, %310
  %312 = mul i64 %311, 4
  %buffer.contiguous.address105 = getelementptr i8, ptr %307, i64 %312
  %buffer.contiguous.load106 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address105, i32 1, <8 x i1> %293, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load107 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 1
  %315 = add <8 x i64> %314, splat (i64 256)
  %316 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %313, 0
  %317 = insertvalue { <8 x ptr>, <8 x i64> } %316, <8 x i64> %315, 1
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %317, 1
  %320 = extractelement <8 x ptr> %318, i32 0
  %321 = extractelement <8 x i64> %319, i32 %300
  %322 = zext i32 %300 to i64
  %323 = mul i64 %322, 4
  %324 = sub i64 %321, %323
  %325 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %293)
  %326 = select i1 %325, i64 %324, i64 0
  %private.contiguous.address108 = getelementptr i8, ptr %320, i64 %326
  %private.contiguous.preserve109 = load <8 x float>, ptr %private.contiguous.address108, align 4
  %327 = select <8 x i1> %293, <8 x float> %buffer.contiguous.load106, <8 x float> %private.contiguous.preserve109
  store <8 x float> %327, ptr %private.contiguous.address108, align 4
  %328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %295)
  %329 = bitcast <8 x i1> %295 to i8
  %330 = call i8 @llvm.cttz.i8(i8 %329, i1 false)
  %331 = zext i8 %330 to i32
  %332 = select i1 %328, i32 %331, i32 0
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.15
  %333 = load <8 x i64>, ptr %.slot13, align 64
  %334 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %333
  store <8 x i64> %334, ptr %.slot13, align 64
  br label %direct.schedule.18

direct.schedule.18:                               ; preds = %direct.schedule.19, %direct.schedule.17
  %.state110 = load <8 x i64>, ptr %.slot13, align 64
  %335 = icmp slt <8 x i64> %.state110, splat (i64 8)
  %336 = extractelement <8 x i1> %335, i32 0
  br i1 %336, label %direct.true111, label %direct.false112

direct.schedule.19:                               ; preds = %direct.true111
  %.state113 = load <8 x i64>, ptr %.slot13, align 64
  %337 = mul <8 x i64> %.state113, splat (i64 8)
  %.spill.load114 = load <8 x i64>, ptr %.spill, align 64
  %338 = add <8 x i64> %337, %.spill.load114
  %.spill.load115 = load <8 x i64>, ptr %.spill4, align 64
  %339 = add <8 x i64> %.spill.load115, zeroinitializer
  %340 = add <8 x i64> zeroinitializer, %339
  %341 = add <8 x i64> zeroinitializer, %338
  %342 = mul <8 x i64> %340, splat (i64 65)
  %343 = add <8 x i64> %342, %341
  %tile_snapshot.spill.load116 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 0
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 1
  %.state117 = load <8 x i64>, ptr %.slot13, align 64
  %346 = mul <8 x i64> %.state117, splat (i64 32)
  %347 = add <8 x i64> %345, %346
  %348 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %344, 0
  %349 = insertvalue { <8 x ptr>, <8 x i64> } %348, <8 x i64> %347, 1
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %351 = extractvalue { <8 x ptr>, <8 x i64> } %349, 1
  %352 = extractelement <8 x ptr> %350, i32 0
  %353 = extractelement <8 x i64> %351, i32 0
  %354 = sub i64 %353, 0
  %355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %356 = select i1 %355, i64 %354, i64 0
  %private.contiguous.address118 = getelementptr i8, ptr %352, i64 %356
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address118, align 4
  %357 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.spill.load119 = load float, ptr %.spill5, align 4
  %.splatinsert120 = insertelement <8 x float> poison, float %.spill.load119, i64 0
  %.splat121 = shufflevector <8 x float> %.splatinsert120, <8 x float> poison, <8 x i32> zeroinitializer
  %358 = fmul <8 x float> %.splat121, %357
  %.spill.load122 = load float, ptr %.spill6, align 4
  %.splatinsert123 = insertelement <8 x float> poison, float %.spill.load122, i64 0
  %.splat124 = shufflevector <8 x float> %.splatinsert123, <8 x float> poison, <8 x i32> zeroinitializer
  %359 = fmul <8 x float> %.splat124, %357
  %360 = fmul <8 x float> %359, %357
  %361 = fmul <8 x float> %360, %357
  %362 = fadd <8 x float> %357, %361
  %.spill.load125 = load float, ptr %.spill7, align 4
  %.splatinsert126 = insertelement <8 x float> poison, float %.spill.load125, i64 0
  %.splat127 = shufflevector <8 x float> %.splatinsert126, <8 x float> poison, <8 x i32> zeroinitializer
  %363 = fmul <8 x float> %.splat127, %362
  %364 = select <8 x i1> %51, <8 x float> %363, <8 x float> zeroinitializer
  %native.tanh128 = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %364)
  %.spill.load129 = load float, ptr %.spill8, align 4
  %.splatinsert130 = insertelement <8 x float> poison, float %.spill.load129, i64 0
  %.splat131 = shufflevector <8 x float> %.splatinsert130, <8 x float> poison, <8 x i32> zeroinitializer
  %365 = fadd <8 x float> %.splat131, %native.tanh128
  %366 = fmul <8 x float> %358, %365
  %tile_snapshot.spill.load132 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %367 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 0
  %368 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 1
  %.state133 = load <8 x i64>, ptr %.slot13, align 64
  %369 = mul <8 x i64> %.state133, splat (i64 32)
  %370 = add <8 x i64> %368, %369
  %371 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %367, 0
  %372 = insertvalue { <8 x ptr>, <8 x i64> } %371, <8 x i64> %370, 1
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %372, 1
  %375 = extractelement <8 x ptr> %373, i32 0
  %376 = extractelement <8 x i64> %374, i32 0
  %377 = sub i64 %376, 0
  %378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %379 = select i1 %378, i64 %377, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %375, i64 %379
  %private.contiguous.load135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %380 = select <8 x i1> %51, <8 x float> %private.contiguous.load135, <8 x float> zeroinitializer
  %381 = fadd <8 x float> %366, %380
  %382 = extractvalue { ptr, i64 } %27, 0
  %383 = extractelement <8 x i64> %343, i32 0
  %384 = sub i64 %383, 0
  %385 = mul i64 %384, 4
  %buffer.contiguous.address136 = getelementptr i8, ptr %382, i64 %385
  call void @llvm.masked.store.v8f32.p0(<8 x float> %381, ptr %buffer.contiguous.address136, i32 1, <8 x i1> %51)
  %.state137 = load <8 x i64>, ptr %.slot13, align 64
  %386 = add <8 x i64> %.state137, splat (i64 1)
  %387 = load <8 x i64>, ptr %.slot13, align 64
  %388 = select <8 x i1> %51, <8 x i64> %386, <8 x i64> %387
  store <8 x i64> %388, ptr %.slot13, align 64
  br label %direct.schedule.18

direct.schedule.20:                               ; preds = %direct.false112
  %.spill.load138 = load <8 x i1>, ptr %.spill10, align 1
  %389 = and <8 x i1> %51, %.spill.load138
  %390 = xor <8 x i1> %.spill.load138, splat (i1 true)
  %391 = and <8 x i1> %51, %390
  %392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %389)
  %393 = bitcast <8 x i1> %389 to i8
  %394 = call i8 @llvm.cttz.i8(i8 %393, i1 false)
  %395 = zext i8 %394 to i32
  %396 = select i1 %392, i32 %395, i32 0
  %.spill.load139 = load <8 x i64>, ptr %.spill, align 64
  %397 = add <8 x i64> splat (i64 64), %.spill.load139
  %.spill.load140 = load <8 x i64>, ptr %.spill4, align 64
  %398 = add <8 x i64> %.spill.load140, zeroinitializer
  %399 = add <8 x i64> zeroinitializer, %398
  %400 = add <8 x i64> zeroinitializer, %397
  %401 = mul <8 x i64> %399, splat (i64 65)
  %402 = add <8 x i64> %401, %400
  %tile_snapshot.spill.load141 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 0
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 1
  %405 = add <8 x i64> %404, splat (i64 256)
  %406 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %403, 0
  %407 = insertvalue { <8 x ptr>, <8 x i64> } %406, <8 x i64> %405, 1
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %407, 1
  %410 = extractelement <8 x ptr> %408, i32 0
  %411 = extractelement <8 x i64> %409, i32 %396
  %412 = zext i32 %396 to i64
  %413 = mul i64 %412, 4
  %414 = sub i64 %411, %413
  %415 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %389)
  %416 = select i1 %415, i64 %414, i64 0
  %private.contiguous.address142 = getelementptr i8, ptr %410, i64 %416
  %private.contiguous.load143 = load <8 x float>, ptr %private.contiguous.address142, align 4
  %417 = select <8 x i1> %389, <8 x float> %private.contiguous.load143, <8 x float> zeroinitializer
  %.spill.load144 = load float, ptr %.spill5, align 4
  %.splatinsert145 = insertelement <8 x float> poison, float %.spill.load144, i64 0
  %.splat146 = shufflevector <8 x float> %.splatinsert145, <8 x float> poison, <8 x i32> zeroinitializer
  %418 = fmul <8 x float> %.splat146, %417
  %.spill.load147 = load float, ptr %.spill6, align 4
  %.splatinsert148 = insertelement <8 x float> poison, float %.spill.load147, i64 0
  %.splat149 = shufflevector <8 x float> %.splatinsert148, <8 x float> poison, <8 x i32> zeroinitializer
  %419 = fmul <8 x float> %.splat149, %417
  %420 = fmul <8 x float> %419, %417
  %421 = fmul <8 x float> %420, %417
  %422 = fadd <8 x float> %417, %421
  %.spill.load150 = load float, ptr %.spill7, align 4
  %.splatinsert151 = insertelement <8 x float> poison, float %.spill.load150, i64 0
  %.splat152 = shufflevector <8 x float> %.splatinsert151, <8 x float> poison, <8 x i32> zeroinitializer
  %423 = fmul <8 x float> %.splat152, %422
  %424 = select <8 x i1> %389, <8 x float> %423, <8 x float> zeroinitializer
  %native.tanh153 = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %424)
  %.spill.load154 = load float, ptr %.spill8, align 4
  %.splatinsert155 = insertelement <8 x float> poison, float %.spill.load154, i64 0
  %.splat156 = shufflevector <8 x float> %.splatinsert155, <8 x float> poison, <8 x i32> zeroinitializer
  %425 = fadd <8 x float> %.splat156, %native.tanh153
  %426 = fmul <8 x float> %418, %425
  %tile_snapshot.spill.load157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 0
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 1
  %429 = add <8 x i64> %428, splat (i64 256)
  %430 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %427, 0
  %431 = insertvalue { <8 x ptr>, <8 x i64> } %430, <8 x i64> %429, 1
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %431, 1
  %434 = extractelement <8 x ptr> %432, i32 0
  %435 = extractelement <8 x i64> %433, i32 %396
  %436 = zext i32 %396 to i64
  %437 = mul i64 %436, 4
  %438 = sub i64 %435, %437
  %439 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %389)
  %440 = select i1 %439, i64 %438, i64 0
  %private.contiguous.address158 = getelementptr i8, ptr %434, i64 %440
  %private.contiguous.load159 = load <8 x float>, ptr %private.contiguous.address158, align 4
  %441 = select <8 x i1> %389, <8 x float> %private.contiguous.load159, <8 x float> zeroinitializer
  %442 = fadd <8 x float> %426, %441
  %443 = extractvalue { ptr, i64 } %27, 0
  %444 = extractelement <8 x i64> %402, i32 %396
  %445 = zext i32 %396 to i64
  %446 = sub i64 %444, %445
  %447 = mul i64 %446, 4
  %buffer.contiguous.address160 = getelementptr i8, ptr %443, i64 %447
  call void @llvm.masked.store.v8f32.p0(<8 x float> %442, ptr %buffer.contiguous.address160, i32 1, <8 x i1> %389)
  %448 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %391)
  %449 = bitcast <8 x i1> %391 to i8
  %450 = call i8 @llvm.cttz.i8(i8 %449, i1 false)
  %451 = zext i8 %450 to i32
  %452 = select i1 %448, i32 %451, i32 0
  br label %direct.schedule.6

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.0
  br label %direct.schedule.1

direct.false:                                     ; preds = %direct.schedule.0
  br label %direct.schedule.7

direct.true24:                                    ; preds = %direct.schedule.2
  br label %direct.schedule.3

direct.false25:                                   ; preds = %direct.schedule.2
  br label %direct.schedule.4

direct.true68:                                    ; preds = %direct.schedule.8
  br label %direct.schedule.9

direct.false69:                                   ; preds = %direct.schedule.8
  br label %direct.schedule.10

direct.true90:                                    ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false91:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true111:                                   ; preds = %direct.schedule.18
  br label %direct.schedule.19

direct.false112:                                  ; preds = %direct.schedule.18
  br label %direct.schedule.20
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  br label %packet.batch.full.loop

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full.loop
  ret void

packet.batch.full.loop:                           ; preds = %packet.batch.full.loop, %packet.batch.full
  %packet.index = phi i32 [ 0, %packet.batch.full ], [ %packet.index.next, %packet.batch.full.loop ]
  %packet.thread.offset = mul i32 %packet.index, 8
  %packet.thread.index = add i32 %base.thread.index, %packet.thread.offset
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config) #4
  %packet.index.next = add i32 %packet.index, 1
  %packet.batch.has.more = icmp ult i32 %packet.index.next, %packet_count
  br i1 %packet.batch.has.more, label %packet.batch.full.loop, label %packet.batch.exit

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #4 = { alwaysinline }

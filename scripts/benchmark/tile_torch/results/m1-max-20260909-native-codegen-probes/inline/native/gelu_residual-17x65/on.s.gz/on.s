
/private/tmp/luisa-packet-inline.UY1lIE/capture/gelu_residual-17x65/on/object/tile_xir_w8_36436_1788935103514491_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x3420 <ltmp0+0x3420>
       4:      	stp	d15, d14, [sp, #-0xa0]!
       8:      	stp	d13, d12, [sp, #0x10]
       c:      	stp	d11, d10, [sp, #0x20]
      10:      	stp	d9, d8, [sp, #0x30]
      14:      	stp	x28, x27, [sp, #0x40]
      18:      	stp	x26, x25, [sp, #0x50]
      1c:      	stp	x24, x23, [sp, #0x60]
      20:      	stp	x22, x21, [sp, #0x70]
      24:      	stp	x20, x19, [sp, #0x80]
      28:      	stp	x29, x30, [sp, #0x90]
      2c:      	sub	sp, sp, #0x660
      30:      	mov	w8, #0x0                ; =0
      34:      	ldp	w9, w10, [x2, #0x2c]
      38:      	mov	w22, #0x20              ; =32
      3c:      	mov	w12, #0x450             ; =1104
      40:      	movi.4s	v9, #0x3f, lsl #24
      44:      	mov	w13, #0x2713            ; =10003
      48:      	movk	w13, #0x3d37, lsl #16
      4c:      	mov	w14, #0x422a            ; =16938
      50:      	movk	w14, #0x3f4c, lsl #16
      54:      	fmov.4s	v19, #1.00000000
      58:      	ldp	w11, w1, [x2]
      5c:      	mov	w16, #0x9231            ; =37425
      60:      	movk	w16, #0x2f30, lsl #16
      64:      	mov	w17, #0x322b            ; =12843
      68:      	movk	w17, #0x32d7, lsl #16
      6c:      	mov	w5, #0xef1d             ; =61213
      70:      	movk	w5, #0x3638, lsl #16
      74:      	mov	w6, #0xd01              ; =3329
      78:      	movk	w6, #0x3950, lsl #16
      7c:      	ldp	w4, w15, [x2, #0x8]
      80:      	str	x2, [sp, #0x10]
      84:      	mov	w7, #0x8889             ; =34953
      88:      	movk	w7, #0x3c08, lsl #16
      8c:      	dup.4s	v25, w13
      90:      	mov	w19, #0xaaab            ; =43691
      94:      	movk	w19, #0x3e2a, lsl #16
      98:      	dup.4s	v26, w14
      9c:      	mov	w20, #0x76c7            ; =30407
      a0:      	movk	w20, #0x310f, lsl #16
      a4:      	dup.4s	v29, w16
      a8:      	mov	w16, #0xf27e            ; =62078
      ac:      	movk	w16, #0x3493, lsl #16
      b0:      	dup.4s	v31, w17
      b4:      	mov	w17, #0xd01             ; =3329
      b8:      	movk	w17, #0x37d0, lsl #16
      bc:      	dup.4s	v8, w5
      c0:      	mov	w5, #0xb61              ; =2913
      c4:      	movk	w5, #0x3ab6, lsl #16
      c8:      	dup.4s	v0, w6
      cc:      	str	q0, [sp, #0x250]
      d0:      	mov	w6, #0xaaab             ; =43691
      d4:      	movk	w6, #0x3d2a, lsl #16
      d8:      	dup.4s	v15, w7
      dc:      	fmov.4s	v17, #9.00000000
      e0:      	dup.4s	v10, w19
      e4:      	mov	w7, #-0x3d300000        ; =-1026555904
      e8:      	dup.4s	v20, w20
      ec:      	mov	w19, #0x42c80000        ; =1120403456
      f0:      	dup.4s	v23, w16
      f4:      	mov	w16, #0xaa3b            ; =43579
      f8:      	movk	w16, #0x3fb8, lsl #16
      fc:      	dup.4s	v7, w17
     100:      	movi.4s	v21, #0x4b, lsl #24
     104:      	dup.4s	v13, w5
     108:      	movi.4s	v18, #0xcb, lsl #24
     10c:      	dup.4s	v5, w6
     110:      	mov	w17, #0x7200            ; =29184
     114:      	movk	w17, #0xbf31, lsl #16
     118:      	dup.4s	v12, w7
     11c:      	mov	w5, #0xbe8e             ; =48782
     120:      	movk	w5, #0xb5bf, lsl #16
     124:      	dup.4s	v27, w19
     128:      	mov	w6, #0x2bda             ; =11226
     12c:      	movk	w6, #0x3950, lsl #16
     130:      	dup.4s	v6, w16
     134:      	mov	w7, #0x96c9             ; =38601
     138:      	movk	w7, #0x3ab6, lsl #16
     13c:      	dup.4s	v24, w17
     140:      	mov	w19, #0x88a6            ; =34982
     144:      	movk	w19, #0x3c08, lsl #16
     148:      	dup.4s	v1, w5
     14c:      	mov	w5, #0xaa7a             ; =43642
     150:      	movk	w5, #0x3d2a, lsl #16
     154:      	dup.4s	v0, w6
     158:      	stp	q0, q1, [sp, #0x140]
     15c:      	add	x16, sp, #0x540
     160:      	dup.4s	v1, w7
     164:      	add	x17, sp, #0x420
     168:      	dup.4s	v0, w19
     16c:      	stp	q0, q1, [sp, #0x120]
     170:      	dup.4s	v0, w5
     174:      	str	q0, [sp, #0x240]
     178:      	mvni.4s	v0, #0x7f, msl #16
     17c:      	fneg.4s	v0, v0
     180:      	stp	q0, q13, [sp, #0x200]
     184:      	mvni.4s	v14, #0x80, lsl #24
     188:      	adrp	x20, 0x0 <ltmp0>
     18c:      	mvni.4s	v0, #0x3f, msl #16
     190:      	fneg.4s	v0, v0
     194:      	stp	q0, q24, [sp, #0x220]
     198:      	stp	q26, q25, [sp, #0x1a0]
     19c:      	stp	q31, q29, [sp, #0x180]
     1a0:      	stp	q10, q8, [sp, #0x160]
     1a4:      	stp	q15, q23, [sp, #0x280]
     1a8:      	stp	q17, q5, [sp, #0x1e0]
     1ac:      	str	q20, [sp, #0x2a0]
     1b0:      	str	q7, [sp, #0x270]
     1b4:      	stp	q12, q6, [sp, #0x1c0]
     1b8:      	str	q27, [sp, #0x110]
     1bc:      	b	0x1f4 <ltmp0+0x1f4>
     1c0:      	add	w11, w30, #0x1
     1c4:      	cmp	w11, w9
     1c8:      	cset	w1, eq
     1cc:      	csinc	w11, wzr, w30, eq
     1d0:      	cinc	w2, w28, eq
     1d4:      	cmp	w2, w10
     1d8:      	cset	w4, eq
     1dc:      	ands	w4, w1, w4
     1e0:      	csel	w1, wzr, w2, ne
     1e4:      	add	w4, w27, w4
     1e8:      	add	w8, w8, #0x1
     1ec:      	cmp	w8, w3
     1f0:      	b.eq	0x33e0 <ltmp0+0x33e0>
     1f4:      	mov	x27, x4
     1f8:      	mov	x28, x1
     1fc:      	mov	x30, x11
     200:      	ubfiz	x11, x11, #5, #32
     204:      	cmp	x11, x15
     208:      	csel	x1, x11, xzr, ls
     20c:      	subs	x4, x15, x1
     210:      	cmp	x4, #0x20
     214:      	csel	x4, x4, x22, lo
     218:      	cmp	x15, x1
     21c:      	ccmp	x11, x15, #0x2, hi
     220:      	csel	x23, x4, xzr, ls
     224:      	fmov.4s	v0, #0.25000000
     228:      	str	q0, [sp, #0x260]
     22c:      	cmp	x23, #0x20
     230:      	b.lo	0xdec <ltmp0+0xdec>
     234:      	mov	x23, #0x0               ; =0
     238:      	ldr	x24, [x0]
     23c:      	ldr	x25, [x0, #0x10]
     240:      	ldr	x26, [x0, #0x30]
     244:      	subs	x11, x24, x26
     248:      	lsr	x11, x11, #2
     24c:      	ccmp	x11, x12, #0x0, hs
     250:      	cset	w11, hi
     254:      	subs	x1, x26, x24
     258:      	lsr	x1, x1, #2
     25c:      	ccmp	x1, x12, #0x0, hs
     260:      	csinc	w11, w11, wzr, ls
     264:      	subs	x1, x25, x26
     268:      	lsr	x1, x1, #2
     26c:      	ccmp	x1, x12, #0x0, hs
     270:      	cset	w1, hi
     274:      	subs	x4, x26, x25
     278:      	lsr	x4, x4, #2
     27c:      	ccmp	x4, x12, #0x0, hs
     280:      	csinc	w1, w1, wzr, ls
     284:      	and	w5, w11, w1
     288:      	lsl	w6, w30, #2
     28c:      	and	x11, x30, #0x7ffffff
     290:      	add	x11, x11, x11, lsl #6
     294:      	lsl	x11, x11, #4
     298:      	add	x7, x26, x11
     29c:      	add	x19, x25, x11
     2a0:      	add	x21, x24, x11
     2a4:      	b	0x488 <ltmp0+0x488>
     2a8:      	movi.2d	v0, #0000000000000000
     2ac:      	ldr	q2, [sp, #0xe0]
     2b0:      	mov.s	v0[0], v2[0]
     2b4:      	fmov	s1, w13
     2b8:      	fmul.4s	v1, v0, v1
     2bc:      	fmul.4s	v1, v2, v1
     2c0:      	fmul.4s	v1, v2, v1
     2c4:      	fadd.4s	v1, v2, v1
     2c8:      	fmov	s2, w14
     2cc:      	fmul.4s	v2, v1, v2
     2d0:      	movi.2d	v1, #0000000000000000
     2d4:      	mov.s	v1[0], v2[0]
     2d8:      	fabs.4s	v2, v1
     2dc:      	fmul.4s	v3, v1, v1
     2e0:      	mov.16b	v4, v31
     2e4:      	fmla.4s	v4, v3, v29
     2e8:      	mov.16b	v16, v8
     2ec:      	fmla.4s	v16, v3, v4
     2f0:      	ldr	q4, [sp, #0x250]
     2f4:      	fmla.4s	v4, v3, v16
     2f8:      	ldr	q16, [sp, #0x280]
     2fc:      	fmla.4s	v16, v3, v4
     300:      	mov.16b	v4, v27
     304:      	fmla.4s	v4, v3, v16
     308:      	mov.16b	v16, v19
     30c:      	fmla.4s	v16, v3, v4
     310:      	fmul.4s	v4, v2, v16
     314:      	ldp	q16, q17, [sp, #0x290]
     318:      	fmla.4s	v16, v3, v17
     31c:      	ldr	q17, [sp, #0x270]
     320:      	fmla.4s	v17, v3, v16
     324:      	ldr	q16, [sp, #0x210]
     328:      	fmla.4s	v16, v3, v17
     32c:      	ldp	q30, q11, [sp, #0x1e0]
     330:      	mov.16b	v17, v11
     334:      	fmla.4s	v17, v3, v16
     338:      	movi.4s	v16, #0x3f, lsl #24
     33c:      	fmla.4s	v16, v3, v17
     340:      	mov.16b	v17, v19
     344:      	fmla.4s	v17, v3, v16
     348:      	fdiv.4s	v3, v4, v17
     34c:      	str	q3, [sp, #0xe0]
     350:      	fcmge.4s	v4, v30, v2
     354:      	and.16b	v16, v4, v2
     358:      	ldp	q28, q3, [sp, #0x1c0]
     35c:      	fcmge.4s	v17, v16, v28
     360:      	fcmge.4s	v18, v6, v16
     364:      	and.16b	v17, v17, v18
     368:      	and.16b	v17, v17, v16
     36c:      	fmul.4s	v18, v17, v3
     370:      	fadd.4s	v18, v18, v12
     374:      	fadd.4s	v18, v18, v15
     378:      	fcvtzs.4s	v18, v18
     37c:      	scvtf.4s	v21, v18
     380:      	ldr	q24, [sp, #0x230]
     384:      	fmul.4s	v22, v21, v24
     388:      	fadd.4s	v17, v17, v22
     38c:      	fmul.4s	v21, v21, v5
     390:      	fadd.4s	v17, v17, v21
     394:      	fmul.4s	v21, v17, v7
     398:      	fadd.4s	v21, v21, v20
     39c:      	fmul.4s	v21, v17, v21
     3a0:      	fadd.4s	v21, v21, v23
     3a4:      	fmul.4s	v21, v17, v21
     3a8:      	ldr	q5, [sp, #0x240]
     3ac:      	fadd.4s	v21, v21, v5
     3b0:      	fmul.4s	v21, v17, v21
     3b4:      	fadd.4s	v21, v21, v27
     3b8:      	fmul.4s	v21, v17, v21
     3bc:      	fadd.4s	v21, v21, v9
     3c0:      	fmul.4s	v22, v17, v17
     3c4:      	fmul.4s	v21, v22, v21
     3c8:      	fadd.4s	v17, v17, v21
     3cc:      	fadd.4s	v17, v17, v19
     3d0:      	add.4s	v18, v18, v10
     3d4:      	sshr.4s	v21, v18, #0x1
     3d8:      	shl.4s	v22, v21, #0x17
     3dc:      	add.4s	v22, v22, v19
     3e0:      	fmul.4s	v17, v17, v22
     3e4:      	sub.4s	v18, v18, v21
     3e8:      	shl.4s	v18, v18, #0x17
     3ec:      	add.4s	v18, v18, v19
     3f0:      	fmul.4s	v17, v17, v18
     3f4:      	fcmgt.4s	v16, v16, v6
     3f8:      	ldr	q5, [sp, #0x200]
     3fc:      	bsl.16b	v16, v5, v17
     400:      	ldr	q5, [sp, #0x260]
     404:      	fdiv.4s	v17, v5, v16
     408:      	fsub.4s	v18, v16, v17
     40c:      	fadd.4s	v16, v16, v17
     410:      	fdiv.4s	v16, v18, v16
     414:      	bsl.16b	v4, v16, v19
     418:      	fcmge.4s	v2, v19, v2
     41c:      	ldr	q5, [sp, #0xe0]
     420:      	bsl.16b	v2, v5, v4
     424:      	bif.16b	v2, v1, v14
     428:      	fcmeq.4s	v1, v1, v1
     42c:      	fadd.4s	v2, v2, v19
     430:      	ldr	q4, [sp, #0x220]
     434:      	bsl.16b	v1, v2, v4
     438:      	fmul.4s	v0, v0, v9
     43c:      	fmul.4s	v0, v0, v1
     440:      	ldr	q1, [sp, #0x100]
     444:      	fadd.4s	v0, v1, v0
     448:      	ldp	q15, q23, [sp, #0x280]
     44c:      	mov.16b	v17, v30
     450:      	ldr	q20, [sp, #0x2a0]
     454:      	movi.4s	v21, #0x4b, lsl #24
     458:      	movi.4s	v18, #0xcb, lsl #24
     45c:      	mov.16b	v5, v11
     460:      	mov.16b	v12, v28
     464:      	mov.16b	v27, v6
     468:      	mov.16b	v6, v3
     46c:      	str	s0, [x26, x1]
     470:      	add	x23, x23, #0x1
     474:      	add	x7, x7, #0x104
     478:      	add	x19, x19, #0x104
     47c:      	add	x21, x21, #0x104
     480:      	cmp	x23, #0x4
     484:      	b.eq	0x1c0 <ltmp0+0x1c0>
     488:      	add	w11, w23, w6
     48c:      	and	x11, x11, #0x1fffffff
     490:      	add	x11, x11, x11, lsl #6
     494:      	lsl	x11, x11, #2
     498:      	cbz	w5, 0x9a0 <ltmp0+0x9a0>
     49c:      	mov	x1, #0x0                ; =0
     4a0:      	ldp	q5, q27, [sp, #0x150]
     4a4:      	ldp	q6, q23, [sp, #0x110]
     4a8:      	ldp	q20, q7, [sp, #0x130]
     4ac:      	add	x4, x21, x1
     4b0:      	ldp	q22, q24, [x4]
     4b4:      	fmul.4s	v0, v22, v25
     4b8:      	fmul.4s	v1, v24, v25
     4bc:      	fmul.4s	v1, v24, v1
     4c0:      	fmul.4s	v0, v22, v0
     4c4:      	fmul.4s	v0, v22, v0
     4c8:      	fmul.4s	v1, v24, v1
     4cc:      	fadd.4s	v1, v24, v1
     4d0:      	fadd.4s	v0, v22, v0
     4d4:      	fmul.4s	v13, v0, v26
     4d8:      	fmul.4s	v11, v1, v26
     4dc:      	fabs.4s	v3, v11
     4e0:      	fabs.4s	v2, v13
     4e4:      	fmul.4s	v28, v13, v13
     4e8:      	fmul.4s	v30, v11, v11
     4ec:      	mov.16b	v0, v31
     4f0:      	fmla.4s	v0, v28, v29
     4f4:      	mov.16b	v1, v31
     4f8:      	fmla.4s	v1, v30, v29
     4fc:      	mov.16b	v4, v8
     500:      	fmla.4s	v4, v28, v0
     504:      	mov.16b	v0, v8
     508:      	fmla.4s	v0, v30, v1
     50c:      	ldr	q1, [sp, #0x250]
     510:      	mov.16b	v17, v1
     514:      	fmla.4s	v17, v28, v4
     518:      	mov.16b	v4, v1
     51c:      	fmla.4s	v4, v30, v0
     520:      	ldp	q26, q29, [sp, #0x280]
     524:      	mov.16b	v0, v26
     528:      	mov.16b	v18, v27
     52c:      	mov.16b	v31, v27
     530:      	mov.16b	v1, v19
     534:      	fmla.4s	v0, v28, v17
     538:      	mov.16b	v17, v29
     53c:      	ldr	q16, [sp, #0x2a0]
     540:      	fmla.4s	v17, v30, v16
     544:      	fmla.4s	v29, v28, v16
     548:      	ldr	q16, [sp, #0x270]
     54c:      	mov.16b	v21, v16
     550:      	fmla.4s	v26, v30, v4
     554:      	fmla.4s	v21, v30, v17
     558:      	mov.16b	v4, v16
     55c:      	fmla.4s	v4, v28, v29
     560:      	ldr	q16, [sp, #0x210]
     564:      	mov.16b	v17, v16
     568:      	fmla.4s	v17, v30, v21
     56c:      	fmla.4s	v18, v28, v0
     570:      	mov.16b	v0, v16
     574:      	fmla.4s	v0, v28, v4
     578:      	ldr	q25, [sp, #0x1f0]
     57c:      	mov.16b	v21, v25
     580:      	fmla.4s	v21, v30, v17
     584:      	fmla.4s	v31, v30, v26
     588:      	fmla.4s	v25, v28, v0
     58c:      	movi.4s	v16, #0x3f, lsl #24
     590:      	movi.4s	v8, #0x3f, lsl #24
     594:      	mov.16b	v0, v19
     598:      	ldr	q17, [sp, #0x1e0]
     59c:      	fcmge.4s	v4, v17, v2
     5a0:      	fmla.4s	v16, v30, v21
     5a4:      	fcmge.4s	v17, v17, v3
     5a8:      	and.16b	v26, v17, v3
     5ac:      	and.16b	v29, v4, v2
     5b0:      	ldr	q9, [sp, #0x1c0]
     5b4:      	fcmge.4s	v21, v29, v9
     5b8:      	fcmge.4s	v9, v26, v9
     5bc:      	fcmge.4s	v10, v6, v26
     5c0:      	and.16b	v9, v9, v10
     5c4:      	fcmge.4s	v10, v6, v29
     5c8:      	and.16b	v21, v21, v10
     5cc:      	and.16b	v21, v21, v29
     5d0:      	and.16b	v9, v9, v26
     5d4:      	fmla.4s	v1, v30, v31
     5d8:      	ldr	q10, [sp, #0x1d0]
     5dc:      	fmul.4s	v31, v9, v10
     5e0:      	fmul.4s	v10, v21, v10
     5e4:      	movi.4s	v14, #0x4b, lsl #24
     5e8:      	fadd.4s	v10, v10, v14
     5ec:      	movi.4s	v12, #0x4b, lsl #24
     5f0:      	fadd.4s	v31, v31, v14
     5f4:      	movi.4s	v14, #0xcb, lsl #24
     5f8:      	fadd.4s	v31, v31, v14
     5fc:      	fmla.4s	v0, v30, v16
     600:      	movi.4s	v15, #0xcb, lsl #24
     604:      	fadd.4s	v16, v10, v14
     608:      	fcvtzs.4s	v16, v16
     60c:      	fcvtzs.4s	v30, v31
     610:      	scvtf.4s	v31, v30
     614:      	scvtf.4s	v10, v16
     618:      	fmla.4s	v8, v28, v25
     61c:      	ldr	q14, [sp, #0x230]
     620:      	fmul.4s	v25, v31, v14
     624:      	fadd.4s	v25, v9, v25
     628:      	fmul.4s	v9, v10, v14
     62c:      	fadd.4s	v21, v21, v9
     630:      	mov.16b	v9, v19
     634:      	fmla.4s	v9, v28, v18
     638:      	fmul.4s	v18, v10, v5
     63c:      	fadd.4s	v21, v21, v18
     640:      	fmul.4s	v18, v31, v5
     644:      	fadd.4s	v25, v25, v18
     648:      	mov.16b	v18, v19
     64c:      	fmla.4s	v18, v28, v8
     650:      	fmul.4s	v28, v25, v7
     654:      	fmul.4s	v31, v21, v7
     658:      	fadd.4s	v31, v31, v20
     65c:      	fadd.4s	v28, v28, v20
     660:      	fmul.4s	v28, v25, v28
     664:      	fmul.4s	v8, v2, v9
     668:      	movi.4s	v9, #0x3f, lsl #24
     66c:      	fmul.4s	v31, v21, v31
     670:      	fadd.4s	v31, v31, v23
     674:      	fadd.4s	v28, v28, v23
     678:      	fmul.4s	v28, v25, v28
     67c:      	fmul.4s	v31, v21, v31
     680:      	ldr	q10, [sp, #0x240]
     684:      	fadd.4s	v31, v31, v10
     688:      	fadd.4s	v28, v28, v10
     68c:      	fmul.4s	v28, v25, v28
     690:      	fmul.4s	v31, v21, v31
     694:      	fadd.4s	v31, v31, v27
     698:      	fadd.4s	v28, v28, v27
     69c:      	fdiv.4s	v18, v8, v18
     6a0:      	fmul.4s	v28, v25, v28
     6a4:      	fmul.4s	v31, v21, v31
     6a8:      	fadd.4s	v31, v31, v9
     6ac:      	fadd.4s	v28, v28, v9
     6b0:      	fmul.4s	v8, v25, v25
     6b4:      	fmul.4s	v28, v8, v28
     6b8:      	fmul.4s	v8, v21, v21
     6bc:      	fmul.4s	v31, v8, v31
     6c0:      	fadd.4s	v21, v21, v31
     6c4:      	fadd.4s	v25, v25, v28
     6c8:      	movi.2d	v14, #0xffffffffffffffff
     6cc:      	add.4s	v16, v16, v14
     6d0:      	fadd.4s	v21, v21, v19
     6d4:      	sshr.4s	v28, v16, #0x1
     6d8:      	shl.4s	v31, v28, #0x17
     6dc:      	add.4s	v31, v31, v19
     6e0:      	fmul.4s	v21, v21, v31
     6e4:      	ldp	q8, q31, [sp, #0x170]
     6e8:      	movi.2d	v10, #0xffffffffffffffff
     6ec:      	add.4s	v30, v30, v14
     6f0:      	fadd.4s	v25, v25, v19
     6f4:      	sub.4s	v16, v16, v28
     6f8:      	sshr.4s	v28, v30, #0x1
     6fc:      	sub.4s	v30, v30, v28
     700:      	shl.4s	v28, v28, #0x17
     704:      	add.4s	v28, v28, v19
     708:      	fmul.4s	v25, v25, v28
     70c:      	shl.4s	v28, v30, #0x17
     710:      	add.4s	v28, v28, v19
     714:      	fmul.4s	v25, v25, v28
     718:      	shl.4s	v16, v16, #0x17
     71c:      	add.4s	v16, v16, v19
     720:      	fmul.4s	v16, v21, v16
     724:      	fcmgt.4s	v21, v29, v6
     728:      	ldr	q28, [sp, #0x200]
     72c:      	bit.16b	v16, v28, v21
     730:      	fmul.4s	v1, v3, v1
     734:      	fcmgt.4s	v21, v26, v6
     738:      	ldp	q29, q26, [sp, #0x190]
     73c:      	bsl.16b	v21, v28, v25
     740:      	fdiv.4s	v0, v1, v0
     744:      	ldr	q28, [sp, #0x260]
     748:      	fdiv.4s	v1, v28, v21
     74c:      	fsub.4s	v25, v21, v1
     750:      	fadd.4s	v1, v21, v1
     754:      	fdiv.4s	v1, v25, v1
     758:      	ldr	q25, [sp, #0x1b0]
     75c:      	bif.16b	v1, v19, v17
     760:      	fcmge.4s	v3, v19, v3
     764:      	bif.16b	v0, v1, v3
     768:      	fdiv.4s	v1, v28, v16
     76c:      	fsub.4s	v3, v16, v1
     770:      	fadd.4s	v1, v16, v1
     774:      	fdiv.4s	v1, v3, v1
     778:      	bif.16b	v1, v19, v4
     77c:      	fcmge.4s	v2, v19, v2
     780:      	bit.16b	v1, v18, v2
     784:      	mvni.4s	v4, #0x80, lsl #24
     788:      	bif.16b	v1, v13, v4
     78c:      	fcmeq.4s	v2, v13, v13
     790:      	fadd.4s	v1, v1, v19
     794:      	ldr	q3, [sp, #0x220]
     798:      	bif.16b	v1, v3, v2
     79c:      	mvni.4s	v14, #0x80, lsl #24
     7a0:      	bif.16b	v0, v11, v4
     7a4:      	fcmeq.4s	v2, v11, v11
     7a8:      	fadd.4s	v0, v0, v19
     7ac:      	bif.16b	v0, v3, v2
     7b0:      	fmul.4s	v2, v24, v9
     7b4:      	fmul.4s	v0, v2, v0
     7b8:      	fmul.4s	v2, v22, v9
     7bc:      	fmul.4s	v1, v2, v1
     7c0:      	add	x4, x19, x1
     7c4:      	ldp	q3, q2, [x4]
     7c8:      	fadd.4s	v1, v3, v1
     7cc:      	fadd.4s	v0, v2, v0
     7d0:      	add	x4, x7, x1
     7d4:      	stp	q1, q0, [x4]
     7d8:      	add	x1, x1, #0x20
     7dc:      	cmp	x1, #0x100
     7e0:      	b.ne	0x4ac <ltmp0+0x4ac>
     7e4:      	add	x1, x11, #0x100
     7e8:      	ldr	s0, [x24, x1]
     7ec:      	fmov	s1, w13
     7f0:      	fmul.4s	v1, v0, v1
     7f4:      	fmul.4s	v1, v0, v1
     7f8:      	fmul.4s	v1, v0, v1
     7fc:      	fadd.4s	v1, v0, v1
     800:      	fmov	s2, w14
     804:      	fmul.4s	v2, v1, v2
     808:      	movi.2d	v1, #0000000000000000
     80c:      	mov.s	v1[0], v2[0]
     810:      	fabs.4s	v2, v1
     814:      	fmul.4s	v3, v1, v1
     818:      	mov.16b	v4, v31
     81c:      	fmla.4s	v4, v3, v29
     820:      	mov.16b	v16, v8
     824:      	fmla.4s	v16, v3, v4
     828:      	ldr	q4, [sp, #0x250]
     82c:      	fmla.4s	v4, v3, v16
     830:      	ldr	q16, [sp, #0x280]
     834:      	fmla.4s	v16, v3, v4
     838:      	mov.16b	v4, v27
     83c:      	fmla.4s	v4, v3, v16
     840:      	mov.16b	v16, v19
     844:      	fmla.4s	v16, v3, v4
     848:      	fmul.4s	v4, v2, v16
     84c:      	ldp	q16, q17, [sp, #0x290]
     850:      	fmla.4s	v16, v3, v17
     854:      	ldr	q17, [sp, #0x270]
     858:      	fmla.4s	v17, v3, v16
     85c:      	ldr	q16, [sp, #0x210]
     860:      	fmla.4s	v16, v3, v17
     864:      	ldp	q28, q11, [sp, #0x1e0]
     868:      	mov.16b	v17, v11
     86c:      	fmla.4s	v17, v3, v16
     870:      	movi.4s	v16, #0x3f, lsl #24
     874:      	fmla.4s	v16, v3, v17
     878:      	mov.16b	v17, v19
     87c:      	fmla.4s	v17, v3, v16
     880:      	fdiv.4s	v3, v4, v17
     884:      	str	q3, [sp, #0xe0]
     888:      	fcmge.4s	v4, v28, v2
     88c:      	and.16b	v16, v4, v2
     890:      	ldp	q30, q3, [sp, #0x1c0]
     894:      	fcmge.4s	v17, v16, v30
     898:      	fcmge.4s	v18, v6, v16
     89c:      	and.16b	v17, v17, v18
     8a0:      	and.16b	v17, v17, v16
     8a4:      	fmul.4s	v18, v17, v3
     8a8:      	fadd.4s	v18, v18, v12
     8ac:      	fadd.4s	v18, v18, v15
     8b0:      	fcvtzs.4s	v18, v18
     8b4:      	scvtf.4s	v21, v18
     8b8:      	ldr	q24, [sp, #0x230]
     8bc:      	fmul.4s	v22, v21, v24
     8c0:      	fadd.4s	v17, v17, v22
     8c4:      	fmul.4s	v21, v21, v5
     8c8:      	fadd.4s	v17, v17, v21
     8cc:      	fmul.4s	v21, v17, v7
     8d0:      	fadd.4s	v21, v21, v20
     8d4:      	fmul.4s	v21, v17, v21
     8d8:      	fadd.4s	v21, v21, v23
     8dc:      	fmul.4s	v21, v17, v21
     8e0:      	ldr	q5, [sp, #0x240]
     8e4:      	fadd.4s	v21, v21, v5
     8e8:      	fmul.4s	v21, v17, v21
     8ec:      	fadd.4s	v21, v21, v27
     8f0:      	fmul.4s	v21, v17, v21
     8f4:      	fadd.4s	v21, v21, v9
     8f8:      	fmul.4s	v22, v17, v17
     8fc:      	fmul.4s	v21, v22, v21
     900:      	fadd.4s	v17, v17, v21
     904:      	fadd.4s	v17, v17, v19
     908:      	add.4s	v18, v18, v10
     90c:      	sshr.4s	v21, v18, #0x1
     910:      	shl.4s	v22, v21, #0x17
     914:      	add.4s	v22, v22, v19
     918:      	fmul.4s	v17, v17, v22
     91c:      	sub.4s	v18, v18, v21
     920:      	shl.4s	v18, v18, #0x17
     924:      	add.4s	v18, v18, v19
     928:      	fmul.4s	v17, v17, v18
     92c:      	fcmgt.4s	v16, v16, v6
     930:      	ldr	q5, [sp, #0x200]
     934:      	bsl.16b	v16, v5, v17
     938:      	ldr	q5, [sp, #0x260]
     93c:      	fdiv.4s	v17, v5, v16
     940:      	fsub.4s	v18, v16, v17
     944:      	fadd.4s	v16, v16, v17
     948:      	fdiv.4s	v16, v18, v16
     94c:      	bsl.16b	v4, v16, v19
     950:      	fcmge.4s	v2, v19, v2
     954:      	ldr	q5, [sp, #0xe0]
     958:      	bsl.16b	v2, v5, v4
     95c:      	bif.16b	v2, v1, v14
     960:      	fcmeq.4s	v1, v1, v1
     964:      	fadd.4s	v2, v2, v19
     968:      	ldr	q4, [sp, #0x220]
     96c:      	bsl.16b	v1, v2, v4
     970:      	fmul.4s	v0, v0, v9
     974:      	fmul.4s	v0, v0, v1
     978:      	ldr	s1, [x25, x1]
     97c:      	fadd.4s	v0, v1, v0
     980:      	ldp	q15, q23, [sp, #0x280]
     984:      	mov.16b	v17, v28
     988:      	ldr	q20, [sp, #0x2a0]
     98c:      	movi.4s	v21, #0x4b, lsl #24
     990:      	movi.4s	v18, #0xcb, lsl #24
     994:      	mov.16b	v5, v11
     998:      	mov.16b	v12, v30
     99c:      	b	0x464 <ltmp0+0x464>
     9a0:      	mov	x4, #0x0                ; =0
     9a4:      	add	x1, x24, x11
     9a8:      	ldp	q0, q1, [x1, #0xc0]
     9ac:      	str	q0, [sp, #0x600]
     9b0:      	str	q1, [sp, #0x610]
     9b4:      	ldp	q0, q1, [x1, #0xe0]
     9b8:      	str	q0, [sp, #0x620]
     9bc:      	str	q1, [sp, #0x630]
     9c0:      	ldp	q0, q1, [x1, #0x80]
     9c4:      	str	q0, [sp, #0x5c0]
     9c8:      	str	q1, [sp, #0x5d0]
     9cc:      	ldp	q0, q1, [x1, #0xa0]
     9d0:      	str	q0, [sp, #0x5e0]
     9d4:      	str	q1, [sp, #0x5f0]
     9d8:      	ldp	q0, q1, [x1, #0x40]
     9dc:      	str	q0, [sp, #0x580]
     9e0:      	str	q1, [sp, #0x590]
     9e4:      	ldp	q0, q1, [x1, #0x60]
     9e8:      	str	q0, [sp, #0x5a0]
     9ec:      	str	q1, [sp, #0x5b0]
     9f0:      	ldp	q0, q1, [x1]
     9f4:      	str	q0, [sp, #0x540]
     9f8:      	str	q1, [sp, #0x550]
     9fc:      	ldp	q0, q1, [x1, #0x20]
     a00:      	str	q0, [sp, #0x560]
     a04:      	str	q1, [sp, #0x570]
     a08:      	add	x1, x11, #0x100
     a0c:      	add	x11, x25, x11
     a10:      	ldp	q0, q1, [x11, #0xc0]
     a14:      	str	q0, [sp, #0x4e0]
     a18:      	str	q1, [sp, #0x4f0]
     a1c:      	ldp	q0, q1, [x11, #0xe0]
     a20:      	str	q0, [sp, #0x500]
     a24:      	str	q1, [sp, #0x510]
     a28:      	ldp	q0, q1, [x11, #0x80]
     a2c:      	str	q0, [sp, #0x4a0]
     a30:      	str	q1, [sp, #0x4b0]
     a34:      	ldp	q0, q1, [x11, #0xa0]
     a38:      	str	q0, [sp, #0x4c0]
     a3c:      	str	q1, [sp, #0x4d0]
     a40:      	ldp	q0, q1, [x11, #0x40]
     a44:      	str	q0, [sp, #0x460]
     a48:      	str	q1, [sp, #0x470]
     a4c:      	ldp	q0, q1, [x11, #0x60]
     a50:      	str	q0, [sp, #0x480]
     a54:      	str	q1, [sp, #0x490]
     a58:      	ldp	q0, q1, [x11]
     a5c:      	ldp	q2, q3, [x11, #0x20]
     a60:      	add	x11, x25, x1
     a64:      	ldp	q4, q6, [sp, #0x100]
     a68:      	ld1.s	{ v4 }[0], [x11]
     a6c:      	str	q0, [sp, #0x420]
     a70:      	str	q1, [sp, #0x430]
     a74:      	ldr	s1, [x24, x1]
     a78:      	ldr	q0, [sp, #0xf0]
     a7c:      	mov.s	v0[0], v1[0]
     a80:      	str	q0, [sp, #0x650]
     a84:      	stp	q1, q0, [sp, #0xe0]
     a88:      	str	q0, [sp, #0x640]
     a8c:      	str	q2, [sp, #0x440]
     a90:      	str	q3, [sp, #0x450]
     a94:      	str	q0, [sp, #0x530]
     a98:      	str	q4, [sp, #0x100]
     a9c:      	str	q4, [sp, #0x520]
     aa0:      	ldp	q5, q27, [sp, #0x150]
     aa4:      	ldp	q20, q7, [sp, #0x130]
     aa8:      	ldr	q23, [sp, #0x120]
     aac:      	add	x11, x16, x4
     ab0:      	ldp	q22, q24, [x11]
     ab4:      	fmul.4s	v0, v22, v25
     ab8:      	fmul.4s	v1, v24, v25
     abc:      	fmul.4s	v1, v24, v1
     ac0:      	fmul.4s	v0, v22, v0
     ac4:      	fmul.4s	v0, v22, v0
     ac8:      	fmul.4s	v1, v24, v1
     acc:      	fadd.4s	v1, v24, v1
     ad0:      	fadd.4s	v0, v22, v0
     ad4:      	fmul.4s	v13, v0, v26
     ad8:      	fmul.4s	v11, v1, v26
     adc:      	fabs.4s	v3, v11
     ae0:      	fabs.4s	v2, v13
     ae4:      	fmul.4s	v28, v13, v13
     ae8:      	fmul.4s	v30, v11, v11
     aec:      	mov.16b	v0, v31
     af0:      	fmla.4s	v0, v28, v29
     af4:      	mov.16b	v1, v31
     af8:      	fmla.4s	v1, v30, v29
     afc:      	mov.16b	v4, v8
     b00:      	fmla.4s	v4, v28, v0
     b04:      	mov.16b	v0, v8
     b08:      	fmla.4s	v0, v30, v1
     b0c:      	ldr	q1, [sp, #0x250]
     b10:      	mov.16b	v16, v1
     b14:      	fmla.4s	v16, v28, v4
     b18:      	mov.16b	v4, v1
     b1c:      	fmla.4s	v4, v30, v0
     b20:      	ldp	q17, q25, [sp, #0x280]
     b24:      	mov.16b	v0, v17
     b28:      	mov.16b	v18, v27
     b2c:      	mov.16b	v21, v27
     b30:      	mov.16b	v1, v19
     b34:      	fmla.4s	v0, v28, v16
     b38:      	mov.16b	v16, v25
     b3c:      	ldr	q26, [sp, #0x2a0]
     b40:      	fmla.4s	v16, v30, v26
     b44:      	fmla.4s	v25, v28, v26
     b48:      	ldr	q29, [sp, #0x270]
     b4c:      	mov.16b	v26, v29
     b50:      	fmla.4s	v17, v30, v4
     b54:      	fmla.4s	v26, v30, v16
     b58:      	mov.16b	v4, v29
     b5c:      	fmla.4s	v4, v28, v25
     b60:      	ldr	q25, [sp, #0x210]
     b64:      	mov.16b	v16, v25
     b68:      	fmla.4s	v16, v30, v26
     b6c:      	fmla.4s	v18, v28, v0
     b70:      	mov.16b	v0, v25
     b74:      	fmla.4s	v0, v28, v4
     b78:      	ldr	q4, [sp, #0x1f0]
     b7c:      	mov.16b	v25, v4
     b80:      	fmla.4s	v25, v30, v16
     b84:      	mov.16b	v16, v4
     b88:      	fmla.4s	v21, v30, v17
     b8c:      	fmla.4s	v16, v28, v0
     b90:      	movi.4s	v31, #0x3f, lsl #24
     b94:      	movi.4s	v8, #0x3f, lsl #24
     b98:      	mov.16b	v0, v19
     b9c:      	ldr	q17, [sp, #0x1e0]
     ba0:      	fcmge.4s	v4, v17, v2
     ba4:      	fmla.4s	v31, v30, v25
     ba8:      	fcmge.4s	v17, v17, v3
     bac:      	and.16b	v26, v17, v3
     bb0:      	and.16b	v29, v4, v2
     bb4:      	ldr	q9, [sp, #0x1c0]
     bb8:      	fcmge.4s	v25, v29, v9
     bbc:      	fcmge.4s	v9, v26, v9
     bc0:      	fcmge.4s	v10, v6, v26
     bc4:      	and.16b	v9, v9, v10
     bc8:      	fcmge.4s	v10, v6, v29
     bcc:      	and.16b	v25, v25, v10
     bd0:      	and.16b	v25, v25, v29
     bd4:      	and.16b	v9, v9, v26
     bd8:      	fmla.4s	v1, v30, v21
     bdc:      	ldr	q10, [sp, #0x1d0]
     be0:      	fmul.4s	v21, v9, v10
     be4:      	fmul.4s	v10, v25, v10
     be8:      	movi.4s	v14, #0x4b, lsl #24
     bec:      	fadd.4s	v10, v10, v14
     bf0:      	movi.4s	v12, #0x4b, lsl #24
     bf4:      	fadd.4s	v21, v21, v14
     bf8:      	movi.4s	v14, #0xcb, lsl #24
     bfc:      	fadd.4s	v21, v21, v14
     c00:      	fmla.4s	v0, v30, v31
     c04:      	movi.4s	v15, #0xcb, lsl #24
     c08:      	fadd.4s	v30, v10, v14
     c0c:      	fcvtzs.4s	v30, v30
     c10:      	fcvtzs.4s	v21, v21
     c14:      	scvtf.4s	v31, v21
     c18:      	scvtf.4s	v10, v30
     c1c:      	fmla.4s	v8, v28, v16
     c20:      	ldr	q14, [sp, #0x230]
     c24:      	fmul.4s	v16, v31, v14
     c28:      	fadd.4s	v16, v9, v16
     c2c:      	fmul.4s	v9, v10, v14
     c30:      	fadd.4s	v25, v25, v9
     c34:      	mov.16b	v9, v19
     c38:      	fmla.4s	v9, v28, v18
     c3c:      	fmul.4s	v18, v10, v5
     c40:      	fadd.4s	v25, v25, v18
     c44:      	fmul.4s	v18, v31, v5
     c48:      	fadd.4s	v16, v16, v18
     c4c:      	mov.16b	v18, v19
     c50:      	fmla.4s	v18, v28, v8
     c54:      	fmul.4s	v28, v16, v7
     c58:      	fmul.4s	v31, v25, v7
     c5c:      	fadd.4s	v31, v31, v20
     c60:      	fadd.4s	v28, v28, v20
     c64:      	fmul.4s	v28, v16, v28
     c68:      	fmul.4s	v8, v2, v9
     c6c:      	movi.4s	v9, #0x3f, lsl #24
     c70:      	fmul.4s	v31, v25, v31
     c74:      	fadd.4s	v31, v31, v23
     c78:      	fadd.4s	v28, v28, v23
     c7c:      	fmul.4s	v28, v16, v28
     c80:      	fmul.4s	v31, v25, v31
     c84:      	ldr	q10, [sp, #0x240]
     c88:      	fadd.4s	v31, v31, v10
     c8c:      	fadd.4s	v28, v28, v10
     c90:      	fmul.4s	v28, v16, v28
     c94:      	fmul.4s	v31, v25, v31
     c98:      	fadd.4s	v31, v31, v27
     c9c:      	fadd.4s	v28, v28, v27
     ca0:      	fdiv.4s	v18, v8, v18
     ca4:      	fmul.4s	v28, v16, v28
     ca8:      	fmul.4s	v31, v25, v31
     cac:      	fadd.4s	v31, v31, v9
     cb0:      	fadd.4s	v28, v28, v9
     cb4:      	fmul.4s	v8, v16, v16
     cb8:      	fmul.4s	v28, v8, v28
     cbc:      	fmul.4s	v8, v25, v25
     cc0:      	fmul.4s	v31, v8, v31
     cc4:      	fadd.4s	v25, v25, v31
     cc8:      	fadd.4s	v16, v16, v28
     ccc:      	movi.2d	v14, #0xffffffffffffffff
     cd0:      	add.4s	v28, v30, v14
     cd4:      	fadd.4s	v25, v25, v19
     cd8:      	sshr.4s	v30, v28, #0x1
     cdc:      	shl.4s	v31, v30, #0x17
     ce0:      	add.4s	v31, v31, v19
     ce4:      	fmul.4s	v25, v25, v31
     ce8:      	ldp	q8, q31, [sp, #0x170]
     cec:      	movi.2d	v10, #0xffffffffffffffff
     cf0:      	add.4s	v21, v21, v14
     cf4:      	fadd.4s	v16, v16, v19
     cf8:      	sub.4s	v28, v28, v30
     cfc:      	sshr.4s	v30, v21, #0x1
     d00:      	sub.4s	v21, v21, v30
     d04:      	shl.4s	v30, v30, #0x17
     d08:      	add.4s	v30, v30, v19
     d0c:      	fmul.4s	v16, v16, v30
     d10:      	shl.4s	v21, v21, #0x17
     d14:      	add.4s	v21, v21, v19
     d18:      	fmul.4s	v16, v16, v21
     d1c:      	shl.4s	v21, v28, #0x17
     d20:      	add.4s	v21, v21, v19
     d24:      	fmul.4s	v21, v25, v21
     d28:      	fcmgt.4s	v25, v29, v6
     d2c:      	ldr	q28, [sp, #0x200]
     d30:      	bit.16b	v21, v28, v25
     d34:      	fmul.4s	v1, v3, v1
     d38:      	fcmgt.4s	v25, v26, v6
     d3c:      	ldp	q29, q26, [sp, #0x190]
     d40:      	bit.16b	v16, v28, v25
     d44:      	fdiv.4s	v0, v1, v0
     d48:      	ldr	q28, [sp, #0x260]
     d4c:      	fdiv.4s	v1, v28, v16
     d50:      	fsub.4s	v25, v16, v1
     d54:      	fadd.4s	v1, v16, v1
     d58:      	fdiv.4s	v1, v25, v1
     d5c:      	ldr	q25, [sp, #0x1b0]
     d60:      	bif.16b	v1, v19, v17
     d64:      	fcmge.4s	v3, v19, v3
     d68:      	bif.16b	v0, v1, v3
     d6c:      	fdiv.4s	v1, v28, v21
     d70:      	fsub.4s	v3, v21, v1
     d74:      	fadd.4s	v1, v21, v1
     d78:      	fdiv.4s	v1, v3, v1
     d7c:      	bif.16b	v1, v19, v4
     d80:      	fcmge.4s	v2, v19, v2
     d84:      	bit.16b	v1, v18, v2
     d88:      	mvni.4s	v4, #0x80, lsl #24
     d8c:      	bif.16b	v1, v13, v4
     d90:      	fcmeq.4s	v2, v13, v13
     d94:      	fadd.4s	v1, v1, v19
     d98:      	ldr	q3, [sp, #0x220]
     d9c:      	bif.16b	v1, v3, v2
     da0:      	mvni.4s	v14, #0x80, lsl #24
     da4:      	bif.16b	v0, v11, v4
     da8:      	fcmeq.4s	v2, v11, v11
     dac:      	fadd.4s	v0, v0, v19
     db0:      	bif.16b	v0, v3, v2
     db4:      	fmul.4s	v2, v24, v9
     db8:      	fmul.4s	v0, v2, v0
     dbc:      	fmul.4s	v2, v22, v9
     dc0:      	fmul.4s	v1, v2, v1
     dc4:      	add	x11, x17, x4
     dc8:      	ldp	q3, q2, [x11]
     dcc:      	fadd.4s	v1, v3, v1
     dd0:      	fadd.4s	v0, v2, v0
     dd4:      	add	x11, x7, x4
     dd8:      	stp	q1, q0, [x11]
     ddc:      	add	x4, x4, #0x20
     de0:      	cmp	x4, #0x100
     de4:      	b.ne	0xaac <ltmp0+0xaac>
     de8:      	b	0x2a8 <ltmp0+0x2a8>
     dec:      	lsr	x25, x23, #3
     df0:      	cmp	x23, #0x8
     df4:      	b.hs	0x14b8 <ltmp0+0x14b8>
     df8:      	and	w11, w23, #0x7
     dfc:      	mov	w22, #0x20              ; =32
     e00:      	cbz	w11, 0x1c0 <ltmp0+0x1c0>
     e04:      	dup.4s	v0, w11
     e08:      	adrp	x11, 0x0 <ltmp0>
     e0c:      	ldr	q1, [x11]
     e10:      	adrp	x11, 0x0 <ltmp0>
     e14:      	ldr	q2, [x11]
     e18:      	cmhi.4s	v28, v0, v2
     e1c:      	cmhi.4s	v3, v0, v1
     e20:      	uzp1.8h	v16, v3, v28
     e24:      	umaxv.8h	h0, v16
     e28:      	fmov	w11, s0
     e2c:      	tbz	w11, #0x0, 0x1c0 <ltmp0+0x1c0>
     e30:      	ldr	x1, [x0]
     e34:      	ldr	x24, [x0, #0x10]
     e38:      	ldr	x23, [x0, #0x30]
     e3c:      	sshll.2d	v0, v3, #0x0
     e40:      	sshll.2d	v1, v28, #0x0
     e44:      	sshll2.2d	v4, v3, #0x0
     e48:      	sshll2.2d	v11, v28, #0x0
     e4c:      	adrp	x11, 0x0 <ltmp0>
     e50:      	ldr	q2, [x11]
     e54:      	and.16b	v22, v11, v2
     e58:      	adrp	x11, 0x0 <ltmp0>
     e5c:      	ldr	q2, [x11]
     e60:      	and.16b	v2, v4, v2
     e64:      	str	q2, [sp, #0xd0]
     e68:      	adrp	x11, 0x0 <ltmp0>
     e6c:      	ldr	q2, [x11]
     e70:      	and.16b	v1, v1, v2
     e74:      	str	q1, [sp, #0x90]
     e78:      	adrp	x11, 0x0 <ltmp0>
     e7c:      	ldr	q1, [x11]
     e80:      	and.16b	v0, v0, v1
     e84:      	str	q0, [sp, #0x40]
     e88:      	ubfiz	w11, w30, #2, #27
     e8c:      	orr	w11, w11, w25
     e90:      	dup.4s	v0, w11
     e94:      	str	q3, [sp, #0x100]
     e98:      	and.16b	v1, v3, v0
     e9c:      	and.16b	v0, v28, v0
     ea0:      	ushll.2d	v2, v1, #0x0
     ea4:      	subs	x11, x1, x23
     ea8:      	lsr	x11, x11, #2
     eac:      	ccmp	x11, x12, #0x0, hs
     eb0:      	cset	w11, hi
     eb4:      	subs	x2, x23, x1
     eb8:      	lsr	x2, x2, #2
     ebc:      	ccmp	x2, x12, #0x0, hs
     ec0:      	csinc	w2, w11, wzr, ls
     ec4:      	subs	x11, x24, x23
     ec8:      	lsr	x11, x11, #2
     ecc:      	ccmp	x11, x12, #0x0, hs
     ed0:      	cset	w11, hi
     ed4:      	subs	x4, x23, x24
     ed8:      	lsr	x4, x4, #2
     edc:      	ccmp	x4, x12, #0x0, hs
     ee0:      	xtn.2s	v3, v2
     ee4:      	str	d3, [sp, #0x50]
     ee8:      	fmov	x4, d2
     eec:      	ushll2.2d	v2, v0, #0x0
     ef0:      	ushll2.2d	v1, v1, #0x0
     ef4:      	ushll.2d	v0, v0, #0x0
     ef8:      	csinc	w11, w11, wzr, ls
     efc:      	add	x4, x4, x4, lsl #6
     f00:      	lsl	x4, x4, #2
     f04:      	xtn.2s	v2, v2
     f08:      	str	d2, [sp, #0x80]
     f0c:      	xtn.2s	v0, v0
     f10:      	str	d0, [sp, #0x70]
     f14:      	xtn.2s	v0, v1
     f18:      	str	d0, [sp, #0x60]
     f1c:      	cmp	w2, #0x1
     f20:      	str	q28, [sp, #0xf0]
     f24:      	b.ne	0x2058 <ltmp0+0x2058>
     f28:      	cbz	w11, 0x2058 <ltmp0+0x2058>
     f2c:      	str	q22, [sp, #0xc0]
     f30:      	mov	x5, #0x0                ; =0
     f34:      	add	x6, x23, x4
     f38:      	add	x7, x24, x4
     f3c:      	add	x19, x1, x4
     f40:      	str	q16, [sp, #0xe0]
     f44:      	b	0xf5c <ltmp0+0xf5c>
     f48:      	add	x5, x5, #0x20
     f4c:      	cmp	x5, #0x100
     f50:      	mov.16b	v23, v7
     f54:      	ldr	q7, [sp, #0x270]
     f58:      	b.eq	0x2dec <ltmp0+0x2dec>
     f5c:      	ldr	q0, [x20]
     f60:      	and.16b	v0, v16, v0
     f64:      	addv.8h	h1, v0
     f68:      	fmov	w4, s1
     f6c:      	add	x11, x19, x5
     f70:      	movi.2d	v11, #0000000000000000
     f74:      	movi.2d	v0, #0000000000000000
     f78:      	tbz	w4, #0x0, 0x101c <ltmp0+0x101c>
     f7c:      	ldr	s11, [x11]
     f80:      	and	w4, w4, #0xff
     f84:      	tbnz	w4, #0x1, 0x1024 <ltmp0+0x1024>
     f88:      	tbz	w4, #0x2, 0x1030 <ltmp0+0x1030>
     f8c:      	add	x2, x11, #0x8
     f90:      	ld1.s	{ v11 }[2], [x2]
     f94:      	tbnz	w4, #0x3, 0x1034 <ltmp0+0x1034>
     f98:      	tbz	w4, #0x4, 0x1040 <ltmp0+0x1040>
     f9c:      	add	x2, x11, #0x10
     fa0:      	ld1.s	{ v0 }[0], [x2]
     fa4:      	tbnz	w4, #0x5, 0x1044 <ltmp0+0x1044>
     fa8:      	tbz	w4, #0x6, 0x1050 <ltmp0+0x1050>
     fac:      	add	x2, x11, #0x18
     fb0:      	ld1.s	{ v0 }[2], [x2]
     fb4:      	tbnz	w4, #0x7, 0x1054 <ltmp0+0x1054>
     fb8:      	fmov	w4, s1
     fbc:      	add	x11, x7, x5
     fc0:      	movi.2d	v22, #0000000000000000
     fc4:      	movi.2d	v13, #0000000000000000
     fc8:      	tbz	w4, #0x0, 0x1070 <ltmp0+0x1070>
     fcc:      	ldr	s22, [x11]
     fd0:      	and	w4, w4, #0xff
     fd4:      	tbnz	w4, #0x1, 0x1078 <ltmp0+0x1078>
     fd8:      	tbz	w4, #0x2, 0x1084 <ltmp0+0x1084>
     fdc:      	add	x2, x11, #0x8
     fe0:      	ld1.s	{ v22 }[2], [x2]
     fe4:      	tbnz	w4, #0x3, 0x1088 <ltmp0+0x1088>
     fe8:      	tbz	w4, #0x4, 0x1094 <ltmp0+0x1094>
     fec:      	add	x2, x11, #0x10
     ff0:      	ld1.s	{ v13 }[0], [x2]
     ff4:      	tbnz	w4, #0x5, 0x1098 <ltmp0+0x1098>
     ff8:      	tbz	w4, #0x6, 0x10a4 <ltmp0+0x10a4>
     ffc:      	add	x2, x11, #0x18
    1000:      	ld1.s	{ v13 }[2], [x2]
    1004:      	mov.16b	v28, v15
    1008:      	mov.16b	v5, v12
    100c:      	mov.16b	v15, v1
    1010:      	mov.16b	v12, v0
    1014:      	tbnz	w4, #0x7, 0x10b8 <ltmp0+0x10b8>
    1018:      	b	0x10c0 <ltmp0+0x10c0>
    101c:      	and	w4, w4, #0xff
    1020:      	tbz	w4, #0x1, 0xf88 <ltmp0+0xf88>
    1024:      	add	x2, x11, #0x4
    1028:      	ld1.s	{ v11 }[1], [x2]
    102c:      	tbnz	w4, #0x2, 0xf8c <ltmp0+0xf8c>
    1030:      	tbz	w4, #0x3, 0xf98 <ltmp0+0xf98>
    1034:      	add	x2, x11, #0xc
    1038:      	ld1.s	{ v11 }[3], [x2]
    103c:      	tbnz	w4, #0x4, 0xf9c <ltmp0+0xf9c>
    1040:      	tbz	w4, #0x5, 0xfa8 <ltmp0+0xfa8>
    1044:      	add	x2, x11, #0x14
    1048:      	ld1.s	{ v0 }[1], [x2]
    104c:      	tbnz	w4, #0x6, 0xfac <ltmp0+0xfac>
    1050:      	tbz	w4, #0x7, 0xfb8 <ltmp0+0xfb8>
    1054:      	add	x11, x11, #0x1c
    1058:      	ld1.s	{ v0 }[3], [x11]
    105c:      	fmov	w4, s1
    1060:      	add	x11, x7, x5
    1064:      	movi.2d	v22, #0000000000000000
    1068:      	movi.2d	v13, #0000000000000000
    106c:      	tbnz	w4, #0x0, 0xfcc <ltmp0+0xfcc>
    1070:      	and	w4, w4, #0xff
    1074:      	tbz	w4, #0x1, 0xfd8 <ltmp0+0xfd8>
    1078:      	add	x2, x11, #0x4
    107c:      	ld1.s	{ v22 }[1], [x2]
    1080:      	tbnz	w4, #0x2, 0xfdc <ltmp0+0xfdc>
    1084:      	tbz	w4, #0x3, 0xfe8 <ltmp0+0xfe8>
    1088:      	add	x2, x11, #0xc
    108c:      	ld1.s	{ v22 }[3], [x2]
    1090:      	tbnz	w4, #0x4, 0xfec <ltmp0+0xfec>
    1094:      	tbz	w4, #0x5, 0xff8 <ltmp0+0xff8>
    1098:      	add	x2, x11, #0x14
    109c:      	ld1.s	{ v13 }[1], [x2]
    10a0:      	tbnz	w4, #0x6, 0xffc <ltmp0+0xffc>
    10a4:      	mov.16b	v28, v15
    10a8:      	mov.16b	v5, v12
    10ac:      	mov.16b	v15, v1
    10b0:      	mov.16b	v12, v0
    10b4:      	tbz	w4, #0x7, 0x10c0 <ltmp0+0x10c0>
    10b8:      	add	x11, x11, #0x1c
    10bc:      	ld1.s	{ v13 }[3], [x11]
    10c0:      	fmul.4s	v0, v11, v25
    10c4:      	fmul.4s	v0, v11, v0
    10c8:      	fmul.4s	v0, v11, v0
    10cc:      	fadd.4s	v0, v11, v0
    10d0:      	fmul.4s	v0, v0, v26
    10d4:      	ldr	q1, [sp, #0x100]
    10d8:      	and.16b	v0, v1, v0
    10dc:      	fabs.4s	v1, v0
    10e0:      	fmul.4s	v2, v0, v0
    10e4:      	mov.16b	v3, v31
    10e8:      	fmla.4s	v3, v2, v29
    10ec:      	mov.16b	v4, v8
    10f0:      	fmla.4s	v4, v2, v3
    10f4:      	ldr	q3, [sp, #0x250]
    10f8:      	fmla.4s	v3, v2, v4
    10fc:      	mov.16b	v4, v28
    1100:      	fmla.4s	v4, v2, v3
    1104:      	ldr	q27, [sp, #0x160]
    1108:      	mov.16b	v3, v27
    110c:      	fmla.4s	v3, v2, v4
    1110:      	mov.16b	v4, v19
    1114:      	fmla.4s	v4, v2, v3
    1118:      	fmul.4s	v3, v1, v4
    111c:      	mov.16b	v7, v23
    1120:      	mov.16b	v4, v23
    1124:      	mov.16b	v23, v20
    1128:      	fmla.4s	v4, v2, v20
    112c:      	ldr	q16, [sp, #0x270]
    1130:      	fmla.4s	v16, v2, v4
    1134:      	ldr	q4, [sp, #0x210]
    1138:      	fmla.4s	v4, v2, v16
    113c:      	ldr	q16, [sp, #0x1f0]
    1140:      	fmla.4s	v16, v2, v4
    1144:      	movi.4s	v4, #0x3f, lsl #24
    1148:      	fmla.4s	v4, v2, v16
    114c:      	mov.16b	v16, v19
    1150:      	fmla.4s	v16, v2, v4
    1154:      	fdiv.4s	v2, v3, v16
    1158:      	mov.16b	v20, v17
    115c:      	fcmge.4s	v3, v17, v1
    1160:      	and.16b	v4, v3, v1
    1164:      	fcmge.4s	v16, v4, v5
    1168:      	ldr	q24, [sp, #0x110]
    116c:      	fcmge.4s	v17, v24, v4
    1170:      	and.16b	v16, v16, v17
    1174:      	and.16b	v16, v16, v4
    1178:      	fmul.4s	v17, v16, v6
    117c:      	fadd.4s	v17, v17, v21
    1180:      	movi.4s	v30, #0xcb, lsl #24
    1184:      	fadd.4s	v17, v17, v18
    1188:      	fcvtzs.4s	v17, v17
    118c:      	scvtf.4s	v18, v17
    1190:      	ldr	q21, [sp, #0x230]
    1194:      	fmul.4s	v21, v18, v21
    1198:      	fadd.4s	v16, v16, v21
    119c:      	ldr	q21, [sp, #0x150]
    11a0:      	fmul.4s	v18, v18, v21
    11a4:      	fadd.4s	v16, v16, v18
    11a8:      	ldp	q21, q18, [sp, #0x130]
    11ac:      	fmul.4s	v18, v16, v18
    11b0:      	fadd.4s	v18, v18, v21
    11b4:      	fmul.4s	v18, v16, v18
    11b8:      	ldr	q21, [sp, #0x120]
    11bc:      	fadd.4s	v18, v18, v21
    11c0:      	fmul.4s	v18, v16, v18
    11c4:      	ldr	q21, [sp, #0x240]
    11c8:      	fadd.4s	v18, v18, v21
    11cc:      	fmul.4s	v18, v16, v18
    11d0:      	fadd.4s	v18, v18, v27
    11d4:      	fmul.4s	v18, v16, v18
    11d8:      	fadd.4s	v18, v18, v9
    11dc:      	fmul.4s	v21, v16, v16
    11e0:      	fmul.4s	v18, v21, v18
    11e4:      	fadd.4s	v16, v16, v18
    11e8:      	fadd.4s	v16, v16, v19
    11ec:      	movi.2d	v18, #0xffffffffffffffff
    11f0:      	add.4s	v17, v17, v18
    11f4:      	sshr.4s	v18, v17, #0x1
    11f8:      	shl.4s	v21, v18, #0x17
    11fc:      	add.4s	v21, v21, v19
    1200:      	fmul.4s	v16, v16, v21
    1204:      	sub.4s	v17, v17, v18
    1208:      	shl.4s	v17, v17, #0x17
    120c:      	add.4s	v17, v17, v19
    1210:      	fmul.4s	v16, v16, v17
    1214:      	fcmgt.4s	v4, v4, v24
    1218:      	ldr	q17, [sp, #0x200]
    121c:      	bsl.16b	v4, v17, v16
    1220:      	ldr	q16, [sp, #0x260]
    1224:      	fdiv.4s	v16, v16, v4
    1228:      	fsub.4s	v17, v4, v16
    122c:      	fadd.4s	v4, v4, v16
    1230:      	fdiv.4s	v4, v17, v4
    1234:      	bsl.16b	v3, v4, v19
    1238:      	fcmge.4s	v1, v19, v1
    123c:      	bsl.16b	v1, v2, v3
    1240:      	bif.16b	v1, v0, v14
    1244:      	fcmeq.4s	v0, v0, v0
    1248:      	fadd.4s	v1, v1, v19
    124c:      	ldr	q2, [sp, #0x220]
    1250:      	bsl.16b	v0, v1, v2
    1254:      	fmul.4s	v1, v11, v9
    1258:      	fmul.4s	v0, v1, v0
    125c:      	fmov	w4, s15
    1260:      	fadd.4s	v0, v22, v0
    1264:      	add	x11, x6, x5
    1268:      	tbz	w4, #0x0, 0x1298 <ltmp0+0x1298>
    126c:      	str	s0, [x11]
    1270:      	and	w4, w4, #0xff
    1274:      	tbnz	w4, #0x1, 0x12a0 <ltmp0+0x12a0>
    1278:      	ldr	q22, [sp, #0x220]
    127c:      	movi.4s	v18, #0x4b, lsl #24
    1280:      	mov.16b	v15, v28
    1284:      	tbz	w4, #0x2, 0x12b8 <ltmp0+0x12b8>
    1288:      	add	x2, x11, #0x8
    128c:      	st1.s	{ v0 }[2], [x2]
    1290:      	tbnz	w4, #0x3, 0x12bc <ltmp0+0x12bc>
    1294:      	b	0x12c4 <ltmp0+0x12c4>
    1298:      	and	w4, w4, #0xff
    129c:      	tbz	w4, #0x1, 0x1278 <ltmp0+0x1278>
    12a0:      	add	x2, x11, #0x4
    12a4:      	st1.s	{ v0 }[1], [x2]
    12a8:      	ldr	q22, [sp, #0x220]
    12ac:      	movi.4s	v18, #0x4b, lsl #24
    12b0:      	mov.16b	v15, v28
    12b4:      	tbnz	w4, #0x2, 0x1288 <ltmp0+0x1288>
    12b8:      	tbz	w4, #0x3, 0x12c4 <ltmp0+0x12c4>
    12bc:      	add	x2, x11, #0xc
    12c0:      	st1.s	{ v0 }[3], [x2]
    12c4:      	fmul.4s	v0, v12, v25
    12c8:      	fmul.4s	v0, v12, v0
    12cc:      	fmul.4s	v0, v12, v0
    12d0:      	fadd.4s	v0, v12, v0
    12d4:      	fmul.4s	v0, v0, v26
    12d8:      	ldr	q1, [sp, #0xf0]
    12dc:      	and.16b	v0, v1, v0
    12e0:      	fabs.4s	v1, v0
    12e4:      	fmul.4s	v2, v0, v0
    12e8:      	mov.16b	v3, v31
    12ec:      	fmla.4s	v3, v2, v29
    12f0:      	mov.16b	v4, v8
    12f4:      	fmla.4s	v4, v2, v3
    12f8:      	ldr	q3, [sp, #0x250]
    12fc:      	fmla.4s	v3, v2, v4
    1300:      	mov.16b	v4, v15
    1304:      	fmla.4s	v4, v2, v3
    1308:      	ldr	q27, [sp, #0x160]
    130c:      	mov.16b	v3, v27
    1310:      	fmla.4s	v3, v2, v4
    1314:      	mov.16b	v4, v19
    1318:      	fmla.4s	v4, v2, v3
    131c:      	fmul.4s	v3, v1, v4
    1320:      	mov.16b	v4, v7
    1324:      	fmla.4s	v4, v2, v23
    1328:      	ldr	q16, [sp, #0x270]
    132c:      	fmla.4s	v16, v2, v4
    1330:      	ldr	q4, [sp, #0x210]
    1334:      	fmla.4s	v4, v2, v16
    1338:      	ldr	q16, [sp, #0x1f0]
    133c:      	fmla.4s	v16, v2, v4
    1340:      	movi.4s	v4, #0x3f, lsl #24
    1344:      	fmla.4s	v4, v2, v16
    1348:      	mov.16b	v16, v19
    134c:      	fmla.4s	v16, v2, v4
    1350:      	fdiv.4s	v2, v3, v16
    1354:      	fcmge.4s	v3, v20, v1
    1358:      	and.16b	v4, v3, v1
    135c:      	fcmge.4s	v16, v4, v5
    1360:      	ldr	q24, [sp, #0x110]
    1364:      	fcmge.4s	v17, v24, v4
    1368:      	and.16b	v16, v16, v17
    136c:      	and.16b	v16, v16, v4
    1370:      	fmul.4s	v17, v16, v6
    1374:      	fadd.4s	v17, v17, v18
    1378:      	fadd.4s	v17, v17, v30
    137c:      	fcvtzs.4s	v17, v17
    1380:      	scvtf.4s	v18, v17
    1384:      	ldr	q21, [sp, #0x230]
    1388:      	fmul.4s	v21, v18, v21
    138c:      	fadd.4s	v16, v16, v21
    1390:      	ldr	q21, [sp, #0x150]
    1394:      	fmul.4s	v18, v18, v21
    1398:      	fadd.4s	v16, v16, v18
    139c:      	ldp	q21, q18, [sp, #0x130]
    13a0:      	fmul.4s	v18, v16, v18
    13a4:      	fadd.4s	v18, v18, v21
    13a8:      	fmul.4s	v18, v16, v18
    13ac:      	ldr	q21, [sp, #0x120]
    13b0:      	fadd.4s	v18, v18, v21
    13b4:      	fmul.4s	v18, v16, v18
    13b8:      	ldr	q21, [sp, #0x240]
    13bc:      	fadd.4s	v18, v18, v21
    13c0:      	fmul.4s	v18, v16, v18
    13c4:      	fadd.4s	v18, v18, v27
    13c8:      	mov.16b	v27, v24
    13cc:      	fmul.4s	v18, v16, v18
    13d0:      	fadd.4s	v18, v18, v9
    13d4:      	fmul.4s	v21, v16, v16
    13d8:      	fmul.4s	v18, v21, v18
    13dc:      	fadd.4s	v16, v16, v18
    13e0:      	fadd.4s	v16, v16, v19
    13e4:      	movi.2d	v18, #0xffffffffffffffff
    13e8:      	add.4s	v17, v17, v18
    13ec:      	sshr.4s	v18, v17, #0x1
    13f0:      	shl.4s	v21, v18, #0x17
    13f4:      	add.4s	v21, v21, v19
    13f8:      	fmul.4s	v16, v16, v21
    13fc:      	sub.4s	v17, v17, v18
    1400:      	shl.4s	v17, v17, #0x17
    1404:      	add.4s	v17, v17, v19
    1408:      	fmul.4s	v16, v16, v17
    140c:      	fcmgt.4s	v4, v4, v24
    1410:      	ldr	q17, [sp, #0x200]
    1414:      	bsl.16b	v4, v17, v16
    1418:      	ldr	q16, [sp, #0x260]
    141c:      	fdiv.4s	v16, v16, v4
    1420:      	fsub.4s	v17, v4, v16
    1424:      	fadd.4s	v4, v4, v16
    1428:      	fdiv.4s	v4, v17, v4
    142c:      	bsl.16b	v3, v4, v19
    1430:      	fcmge.4s	v1, v19, v1
    1434:      	bsl.16b	v1, v2, v3
    1438:      	bif.16b	v1, v0, v14
    143c:      	fcmeq.4s	v0, v0, v0
    1440:      	fadd.4s	v1, v1, v19
    1444:      	bsl.16b	v0, v1, v22
    1448:      	fmul.4s	v1, v12, v9
    144c:      	fmul.4s	v0, v1, v0
    1450:      	fadd.4s	v0, v13, v0
    1454:      	tbz	w4, #0x4, 0x145c <ltmp0+0x145c>
    1458:      	str	s0, [x11, #0x10]
    145c:      	ldr	q16, [sp, #0xe0]
    1460:      	tbz	w4, #0x5, 0x146c <ltmp0+0x146c>
    1464:      	add	x2, x11, #0x14
    1468:      	st1.s	{ v0 }[1], [x2]
    146c:      	movi.4s	v21, #0x4b, lsl #24
    1470:      	movi.4s	v18, #0xcb, lsl #24
    1474:      	mov.16b	v17, v20
    1478:      	mov.16b	v12, v5
    147c:      	ldr	q10, [sp, #0x160]
    1480:      	ldr	q24, [sp, #0x230]
    1484:      	tbz	w4, #0x6, 0x14a0 <ltmp0+0x14a0>
    1488:      	add	x2, x11, #0x18
    148c:      	st1.s	{ v0 }[2], [x2]
    1490:      	mov.16b	v20, v23
    1494:      	ldr	q5, [sp, #0x1f0]
    1498:      	tbz	w4, #0x7, 0xf48 <ltmp0+0xf48>
    149c:      	b	0x14ac <ltmp0+0x14ac>
    14a0:      	mov.16b	v20, v23
    14a4:      	ldr	q5, [sp, #0x1f0]
    14a8:      	tbz	w4, #0x7, 0xf48 <ltmp0+0xf48>
    14ac:      	add	x11, x11, #0x1c
    14b0:      	st1.s	{ v0 }[3], [x11]
    14b4:      	b	0xf48 <ltmp0+0xf48>
    14b8:      	mov	x24, #0x0               ; =0
    14bc:      	ldr	x26, [x0]
    14c0:      	ldr	x5, [x0, #0x10]
    14c4:      	ldr	x6, [x0, #0x30]
    14c8:      	subs	x11, x26, x6
    14cc:      	lsr	x11, x11, #2
    14d0:      	ccmp	x11, x12, #0x0, hs
    14d4:      	cset	w11, hi
    14d8:      	subs	x1, x6, x26
    14dc:      	lsr	x1, x1, #2
    14e0:      	ccmp	x1, x12, #0x0, hs
    14e4:      	csinc	w11, w11, wzr, ls
    14e8:      	subs	x1, x5, x6
    14ec:      	lsr	x1, x1, #2
    14f0:      	ccmp	x1, x12, #0x0, hs
    14f4:      	cset	w1, hi
    14f8:      	subs	x4, x6, x5
    14fc:      	lsr	x4, x4, #2
    1500:      	ccmp	x4, x12, #0x0, hs
    1504:      	csinc	w1, w1, wzr, ls
    1508:      	and	w7, w11, w1
    150c:      	lsl	w19, w30, #2
    1510:      	and	x11, x30, #0x7ffffff
    1514:      	add	x11, x11, x11, lsl #6
    1518:      	lsl	x11, x11, #4
    151c:      	add	x21, x6, x11
    1520:      	add	x22, x5, x11
    1524:      	add	x1, x26, x11
    1528:      	b	0x170c <ltmp0+0x170c>
    152c:      	movi.2d	v0, #0000000000000000
    1530:      	ldr	q2, [sp, #0xf0]
    1534:      	mov.s	v0[0], v2[0]
    1538:      	fmov	s1, w13
    153c:      	fmul.4s	v1, v0, v1
    1540:      	fmul.4s	v1, v2, v1
    1544:      	fmul.4s	v1, v2, v1
    1548:      	fadd.4s	v1, v2, v1
    154c:      	fmov	s2, w14
    1550:      	fmul.4s	v2, v1, v2
    1554:      	movi.2d	v1, #0000000000000000
    1558:      	mov.s	v1[0], v2[0]
    155c:      	fabs.4s	v2, v1
    1560:      	fmul.4s	v3, v1, v1
    1564:      	mov.16b	v4, v31
    1568:      	fmla.4s	v4, v3, v29
    156c:      	mov.16b	v16, v8
    1570:      	fmla.4s	v16, v3, v4
    1574:      	ldr	q4, [sp, #0x250]
    1578:      	fmla.4s	v4, v3, v16
    157c:      	ldr	q16, [sp, #0x280]
    1580:      	fmla.4s	v16, v3, v4
    1584:      	mov.16b	v4, v27
    1588:      	fmla.4s	v4, v3, v16
    158c:      	mov.16b	v16, v19
    1590:      	fmla.4s	v16, v3, v4
    1594:      	fmul.4s	v4, v2, v16
    1598:      	ldp	q16, q17, [sp, #0x290]
    159c:      	fmla.4s	v16, v3, v17
    15a0:      	ldr	q17, [sp, #0x270]
    15a4:      	fmla.4s	v17, v3, v16
    15a8:      	ldr	q16, [sp, #0x210]
    15ac:      	fmla.4s	v16, v3, v17
    15b0:      	ldp	q30, q11, [sp, #0x1e0]
    15b4:      	mov.16b	v17, v11
    15b8:      	fmla.4s	v17, v3, v16
    15bc:      	movi.4s	v16, #0x3f, lsl #24
    15c0:      	fmla.4s	v16, v3, v17
    15c4:      	mov.16b	v17, v19
    15c8:      	fmla.4s	v17, v3, v16
    15cc:      	fdiv.4s	v3, v4, v17
    15d0:      	str	q3, [sp, #0xf0]
    15d4:      	fcmge.4s	v4, v30, v2
    15d8:      	and.16b	v16, v4, v2
    15dc:      	ldp	q28, q3, [sp, #0x1c0]
    15e0:      	fcmge.4s	v17, v16, v28
    15e4:      	fcmge.4s	v18, v6, v16
    15e8:      	and.16b	v17, v17, v18
    15ec:      	and.16b	v17, v17, v16
    15f0:      	fmul.4s	v18, v17, v3
    15f4:      	fadd.4s	v18, v18, v12
    15f8:      	fadd.4s	v18, v18, v15
    15fc:      	fcvtzs.4s	v18, v18
    1600:      	scvtf.4s	v21, v18
    1604:      	ldr	q24, [sp, #0x230]
    1608:      	fmul.4s	v22, v21, v24
    160c:      	fadd.4s	v17, v17, v22
    1610:      	fmul.4s	v21, v21, v5
    1614:      	fadd.4s	v17, v17, v21
    1618:      	fmul.4s	v21, v17, v7
    161c:      	fadd.4s	v21, v21, v20
    1620:      	fmul.4s	v21, v17, v21
    1624:      	fadd.4s	v21, v21, v23
    1628:      	fmul.4s	v21, v17, v21
    162c:      	ldr	q5, [sp, #0x240]
    1630:      	fadd.4s	v21, v21, v5
    1634:      	fmul.4s	v21, v17, v21
    1638:      	fadd.4s	v21, v21, v27
    163c:      	fmul.4s	v21, v17, v21
    1640:      	fadd.4s	v21, v21, v9
    1644:      	fmul.4s	v22, v17, v17
    1648:      	fmul.4s	v21, v22, v21
    164c:      	fadd.4s	v17, v17, v21
    1650:      	fadd.4s	v17, v17, v19
    1654:      	add.4s	v18, v18, v10
    1658:      	sshr.4s	v21, v18, #0x1
    165c:      	shl.4s	v22, v21, #0x17
    1660:      	add.4s	v22, v22, v19
    1664:      	fmul.4s	v17, v17, v22
    1668:      	sub.4s	v18, v18, v21
    166c:      	shl.4s	v18, v18, #0x17
    1670:      	add.4s	v18, v18, v19
    1674:      	fmul.4s	v17, v17, v18
    1678:      	fcmgt.4s	v16, v16, v6
    167c:      	ldr	q5, [sp, #0x200]
    1680:      	bsl.16b	v16, v5, v17
    1684:      	ldr	q5, [sp, #0x260]
    1688:      	fdiv.4s	v17, v5, v16
    168c:      	fsub.4s	v18, v16, v17
    1690:      	fadd.4s	v16, v16, v17
    1694:      	fdiv.4s	v16, v18, v16
    1698:      	bsl.16b	v4, v16, v19
    169c:      	fcmge.4s	v2, v19, v2
    16a0:      	ldr	q5, [sp, #0xf0]
    16a4:      	bsl.16b	v2, v5, v4
    16a8:      	bif.16b	v2, v1, v14
    16ac:      	fcmeq.4s	v1, v1, v1
    16b0:      	fadd.4s	v2, v2, v19
    16b4:      	ldr	q4, [sp, #0x220]
    16b8:      	bsl.16b	v1, v2, v4
    16bc:      	fmul.4s	v0, v0, v9
    16c0:      	fmul.4s	v0, v0, v1
    16c4:      	ldr	q1, [sp, #0x100]
    16c8:      	fadd.4s	v0, v1, v0
    16cc:      	ldp	q15, q23, [sp, #0x280]
    16d0:      	mov.16b	v17, v30
    16d4:      	ldr	q20, [sp, #0x2a0]
    16d8:      	movi.4s	v21, #0x4b, lsl #24
    16dc:      	movi.4s	v18, #0xcb, lsl #24
    16e0:      	mov.16b	v5, v11
    16e4:      	mov.16b	v12, v28
    16e8:      	mov.16b	v27, v6
    16ec:      	mov.16b	v6, v3
    16f0:      	str	s0, [x6, x4]
    16f4:      	add	x24, x24, #0x1
    16f8:      	add	x21, x21, #0x104
    16fc:      	add	x22, x22, #0x104
    1700:      	add	x1, x1, #0x104
    1704:      	cmp	x24, x25
    1708:      	b.eq	0xdf8 <ltmp0+0xdf8>
    170c:      	add	w11, w24, w19
    1710:      	and	x11, x11, #0x1fffffff
    1714:      	add	x11, x11, x11, lsl #6
    1718:      	lsl	x4, x11, #2
    171c:      	mov	x11, #0x0               ; =0
    1720:      	cbz	w7, 0x1c28 <ltmp0+0x1c28>
    1724:      	ldp	q5, q27, [sp, #0x150]
    1728:      	ldp	q6, q23, [sp, #0x110]
    172c:      	ldp	q20, q7, [sp, #0x130]
    1730:      	add	x2, x1, x11
    1734:      	ldp	q22, q24, [x2]
    1738:      	fmul.4s	v0, v22, v25
    173c:      	fmul.4s	v1, v24, v25
    1740:      	fmul.4s	v1, v24, v1
    1744:      	fmul.4s	v0, v22, v0
    1748:      	fmul.4s	v0, v22, v0
    174c:      	fmul.4s	v1, v24, v1
    1750:      	fadd.4s	v1, v24, v1
    1754:      	fadd.4s	v0, v22, v0
    1758:      	fmul.4s	v13, v0, v26
    175c:      	fmul.4s	v11, v1, v26
    1760:      	fabs.4s	v3, v11
    1764:      	fabs.4s	v2, v13
    1768:      	fmul.4s	v28, v13, v13
    176c:      	fmul.4s	v30, v11, v11
    1770:      	mov.16b	v0, v31
    1774:      	fmla.4s	v0, v28, v29
    1778:      	mov.16b	v1, v31
    177c:      	fmla.4s	v1, v30, v29
    1780:      	mov.16b	v4, v8
    1784:      	fmla.4s	v4, v28, v0
    1788:      	mov.16b	v0, v8
    178c:      	fmla.4s	v0, v30, v1
    1790:      	ldr	q1, [sp, #0x250]
    1794:      	mov.16b	v16, v1
    1798:      	fmla.4s	v16, v28, v4
    179c:      	mov.16b	v4, v1
    17a0:      	fmla.4s	v4, v30, v0
    17a4:      	ldp	q17, q25, [sp, #0x280]
    17a8:      	mov.16b	v0, v17
    17ac:      	mov.16b	v18, v27
    17b0:      	mov.16b	v21, v27
    17b4:      	mov.16b	v1, v19
    17b8:      	fmla.4s	v0, v28, v16
    17bc:      	mov.16b	v16, v25
    17c0:      	ldr	q26, [sp, #0x2a0]
    17c4:      	fmla.4s	v16, v30, v26
    17c8:      	fmla.4s	v25, v28, v26
    17cc:      	ldr	q29, [sp, #0x270]
    17d0:      	mov.16b	v26, v29
    17d4:      	fmla.4s	v17, v30, v4
    17d8:      	fmla.4s	v26, v30, v16
    17dc:      	mov.16b	v4, v29
    17e0:      	fmla.4s	v4, v28, v25
    17e4:      	ldr	q25, [sp, #0x210]
    17e8:      	mov.16b	v16, v25
    17ec:      	fmla.4s	v16, v30, v26
    17f0:      	fmla.4s	v18, v28, v0
    17f4:      	mov.16b	v0, v25
    17f8:      	fmla.4s	v0, v28, v4
    17fc:      	ldr	q4, [sp, #0x1f0]
    1800:      	mov.16b	v25, v4
    1804:      	fmla.4s	v25, v30, v16
    1808:      	mov.16b	v16, v4
    180c:      	fmla.4s	v21, v30, v17
    1810:      	fmla.4s	v16, v28, v0
    1814:      	movi.4s	v31, #0x3f, lsl #24
    1818:      	movi.4s	v8, #0x3f, lsl #24
    181c:      	mov.16b	v0, v19
    1820:      	ldr	q17, [sp, #0x1e0]
    1824:      	fcmge.4s	v4, v17, v2
    1828:      	fmla.4s	v31, v30, v25
    182c:      	fcmge.4s	v17, v17, v3
    1830:      	and.16b	v26, v17, v3
    1834:      	and.16b	v29, v4, v2
    1838:      	ldr	q9, [sp, #0x1c0]
    183c:      	fcmge.4s	v25, v29, v9
    1840:      	fcmge.4s	v9, v26, v9
    1844:      	fcmge.4s	v10, v6, v26
    1848:      	and.16b	v9, v9, v10
    184c:      	fcmge.4s	v10, v6, v29
    1850:      	and.16b	v25, v25, v10
    1854:      	and.16b	v25, v25, v29
    1858:      	and.16b	v9, v9, v26
    185c:      	fmla.4s	v1, v30, v21
    1860:      	ldr	q10, [sp, #0x1d0]
    1864:      	fmul.4s	v21, v9, v10
    1868:      	fmul.4s	v10, v25, v10
    186c:      	movi.4s	v14, #0x4b, lsl #24
    1870:      	fadd.4s	v10, v10, v14
    1874:      	movi.4s	v12, #0x4b, lsl #24
    1878:      	fadd.4s	v21, v21, v14
    187c:      	movi.4s	v14, #0xcb, lsl #24
    1880:      	fadd.4s	v21, v21, v14
    1884:      	fmla.4s	v0, v30, v31
    1888:      	movi.4s	v15, #0xcb, lsl #24
    188c:      	fadd.4s	v30, v10, v14
    1890:      	fcvtzs.4s	v30, v30
    1894:      	fcvtzs.4s	v21, v21
    1898:      	scvtf.4s	v31, v21
    189c:      	scvtf.4s	v10, v30
    18a0:      	fmla.4s	v8, v28, v16
    18a4:      	ldr	q14, [sp, #0x230]
    18a8:      	fmul.4s	v16, v31, v14
    18ac:      	fadd.4s	v16, v9, v16
    18b0:      	fmul.4s	v9, v10, v14
    18b4:      	fadd.4s	v25, v25, v9
    18b8:      	mov.16b	v9, v19
    18bc:      	fmla.4s	v9, v28, v18
    18c0:      	fmul.4s	v18, v10, v5
    18c4:      	fadd.4s	v25, v25, v18
    18c8:      	fmul.4s	v18, v31, v5
    18cc:      	fadd.4s	v16, v16, v18
    18d0:      	mov.16b	v18, v19
    18d4:      	fmla.4s	v18, v28, v8
    18d8:      	fmul.4s	v28, v16, v7
    18dc:      	fmul.4s	v31, v25, v7
    18e0:      	fadd.4s	v31, v31, v20
    18e4:      	fadd.4s	v28, v28, v20
    18e8:      	fmul.4s	v28, v16, v28
    18ec:      	fmul.4s	v8, v2, v9
    18f0:      	movi.4s	v9, #0x3f, lsl #24
    18f4:      	fmul.4s	v31, v25, v31
    18f8:      	fadd.4s	v31, v31, v23
    18fc:      	fadd.4s	v28, v28, v23
    1900:      	fmul.4s	v28, v16, v28
    1904:      	fmul.4s	v31, v25, v31
    1908:      	ldr	q10, [sp, #0x240]
    190c:      	fadd.4s	v31, v31, v10
    1910:      	fadd.4s	v28, v28, v10
    1914:      	fmul.4s	v28, v16, v28
    1918:      	fmul.4s	v31, v25, v31
    191c:      	fadd.4s	v31, v31, v27
    1920:      	fadd.4s	v28, v28, v27
    1924:      	fdiv.4s	v18, v8, v18
    1928:      	fmul.4s	v28, v16, v28
    192c:      	fmul.4s	v31, v25, v31
    1930:      	fadd.4s	v31, v31, v9
    1934:      	fadd.4s	v28, v28, v9
    1938:      	fmul.4s	v8, v16, v16
    193c:      	fmul.4s	v28, v8, v28
    1940:      	fmul.4s	v8, v25, v25
    1944:      	fmul.4s	v31, v8, v31
    1948:      	fadd.4s	v25, v25, v31
    194c:      	fadd.4s	v16, v16, v28
    1950:      	movi.2d	v14, #0xffffffffffffffff
    1954:      	add.4s	v28, v30, v14
    1958:      	fadd.4s	v25, v25, v19
    195c:      	sshr.4s	v30, v28, #0x1
    1960:      	shl.4s	v31, v30, #0x17
    1964:      	add.4s	v31, v31, v19
    1968:      	fmul.4s	v25, v25, v31
    196c:      	ldp	q8, q31, [sp, #0x170]
    1970:      	movi.2d	v10, #0xffffffffffffffff
    1974:      	add.4s	v21, v21, v14
    1978:      	fadd.4s	v16, v16, v19
    197c:      	sub.4s	v28, v28, v30
    1980:      	sshr.4s	v30, v21, #0x1
    1984:      	sub.4s	v21, v21, v30
    1988:      	shl.4s	v30, v30, #0x17
    198c:      	add.4s	v30, v30, v19
    1990:      	fmul.4s	v16, v16, v30
    1994:      	shl.4s	v21, v21, #0x17
    1998:      	add.4s	v21, v21, v19
    199c:      	fmul.4s	v16, v16, v21
    19a0:      	shl.4s	v21, v28, #0x17
    19a4:      	add.4s	v21, v21, v19
    19a8:      	fmul.4s	v21, v25, v21
    19ac:      	fcmgt.4s	v25, v29, v6
    19b0:      	ldr	q28, [sp, #0x200]
    19b4:      	bit.16b	v21, v28, v25
    19b8:      	fmul.4s	v1, v3, v1
    19bc:      	fcmgt.4s	v25, v26, v6
    19c0:      	ldp	q29, q26, [sp, #0x190]
    19c4:      	bit.16b	v16, v28, v25
    19c8:      	fdiv.4s	v0, v1, v0
    19cc:      	ldr	q28, [sp, #0x260]
    19d0:      	fdiv.4s	v1, v28, v16
    19d4:      	fsub.4s	v25, v16, v1
    19d8:      	fadd.4s	v1, v16, v1
    19dc:      	fdiv.4s	v1, v25, v1
    19e0:      	ldr	q25, [sp, #0x1b0]
    19e4:      	bif.16b	v1, v19, v17
    19e8:      	fcmge.4s	v3, v19, v3
    19ec:      	bif.16b	v0, v1, v3
    19f0:      	fdiv.4s	v1, v28, v21
    19f4:      	fsub.4s	v3, v21, v1
    19f8:      	fadd.4s	v1, v21, v1
    19fc:      	fdiv.4s	v1, v3, v1
    1a00:      	bif.16b	v1, v19, v4
    1a04:      	fcmge.4s	v2, v19, v2
    1a08:      	bit.16b	v1, v18, v2
    1a0c:      	mvni.4s	v4, #0x80, lsl #24
    1a10:      	bif.16b	v1, v13, v4
    1a14:      	fcmeq.4s	v2, v13, v13
    1a18:      	fadd.4s	v1, v1, v19
    1a1c:      	ldr	q3, [sp, #0x220]
    1a20:      	bif.16b	v1, v3, v2
    1a24:      	mvni.4s	v14, #0x80, lsl #24
    1a28:      	bif.16b	v0, v11, v4
    1a2c:      	fcmeq.4s	v2, v11, v11
    1a30:      	fadd.4s	v0, v0, v19
    1a34:      	bif.16b	v0, v3, v2
    1a38:      	fmul.4s	v2, v24, v9
    1a3c:      	fmul.4s	v0, v2, v0
    1a40:      	fmul.4s	v2, v22, v9
    1a44:      	fmul.4s	v1, v2, v1
    1a48:      	add	x2, x22, x11
    1a4c:      	ldp	q3, q2, [x2]
    1a50:      	fadd.4s	v1, v3, v1
    1a54:      	fadd.4s	v0, v2, v0
    1a58:      	add	x2, x21, x11
    1a5c:      	stp	q1, q0, [x2]
    1a60:      	add	x11, x11, #0x20
    1a64:      	cmp	x11, #0x100
    1a68:      	b.ne	0x1730 <ltmp0+0x1730>
    1a6c:      	add	x4, x4, #0x100
    1a70:      	ldr	s0, [x26, x4]
    1a74:      	fmov	s1, w13
    1a78:      	fmul.4s	v1, v0, v1
    1a7c:      	fmul.4s	v1, v0, v1
    1a80:      	fmul.4s	v1, v0, v1
    1a84:      	fadd.4s	v1, v0, v1
    1a88:      	fmov	s2, w14
    1a8c:      	fmul.4s	v2, v1, v2
    1a90:      	movi.2d	v1, #0000000000000000
    1a94:      	mov.s	v1[0], v2[0]
    1a98:      	fabs.4s	v2, v1
    1a9c:      	fmul.4s	v3, v1, v1
    1aa0:      	mov.16b	v4, v31
    1aa4:      	fmla.4s	v4, v3, v29
    1aa8:      	mov.16b	v16, v8
    1aac:      	fmla.4s	v16, v3, v4
    1ab0:      	ldr	q4, [sp, #0x250]
    1ab4:      	fmla.4s	v4, v3, v16
    1ab8:      	ldr	q16, [sp, #0x280]
    1abc:      	fmla.4s	v16, v3, v4
    1ac0:      	mov.16b	v4, v27
    1ac4:      	fmla.4s	v4, v3, v16
    1ac8:      	mov.16b	v16, v19
    1acc:      	fmla.4s	v16, v3, v4
    1ad0:      	fmul.4s	v4, v2, v16
    1ad4:      	ldp	q16, q17, [sp, #0x290]
    1ad8:      	fmla.4s	v16, v3, v17
    1adc:      	ldr	q17, [sp, #0x270]
    1ae0:      	fmla.4s	v17, v3, v16
    1ae4:      	ldr	q16, [sp, #0x210]
    1ae8:      	fmla.4s	v16, v3, v17
    1aec:      	ldp	q28, q11, [sp, #0x1e0]
    1af0:      	mov.16b	v17, v11
    1af4:      	fmla.4s	v17, v3, v16
    1af8:      	movi.4s	v16, #0x3f, lsl #24
    1afc:      	fmla.4s	v16, v3, v17
    1b00:      	mov.16b	v17, v19
    1b04:      	fmla.4s	v17, v3, v16
    1b08:      	fdiv.4s	v3, v4, v17
    1b0c:      	str	q3, [sp, #0x100]
    1b10:      	fcmge.4s	v4, v28, v2
    1b14:      	and.16b	v16, v4, v2
    1b18:      	ldp	q30, q3, [sp, #0x1c0]
    1b1c:      	fcmge.4s	v17, v16, v30
    1b20:      	fcmge.4s	v18, v6, v16
    1b24:      	and.16b	v17, v17, v18
    1b28:      	and.16b	v17, v17, v16
    1b2c:      	fmul.4s	v18, v17, v3
    1b30:      	fadd.4s	v18, v18, v12
    1b34:      	fadd.4s	v18, v18, v15
    1b38:      	fcvtzs.4s	v18, v18
    1b3c:      	scvtf.4s	v21, v18
    1b40:      	ldr	q24, [sp, #0x230]
    1b44:      	fmul.4s	v22, v21, v24
    1b48:      	fadd.4s	v17, v17, v22
    1b4c:      	fmul.4s	v21, v21, v5
    1b50:      	fadd.4s	v17, v17, v21
    1b54:      	fmul.4s	v21, v17, v7
    1b58:      	fadd.4s	v21, v21, v20
    1b5c:      	fmul.4s	v21, v17, v21
    1b60:      	fadd.4s	v21, v21, v23
    1b64:      	fmul.4s	v21, v17, v21
    1b68:      	ldr	q5, [sp, #0x240]
    1b6c:      	fadd.4s	v21, v21, v5
    1b70:      	fmul.4s	v21, v17, v21
    1b74:      	fadd.4s	v21, v21, v27
    1b78:      	fmul.4s	v21, v17, v21
    1b7c:      	fadd.4s	v21, v21, v9
    1b80:      	fmul.4s	v22, v17, v17
    1b84:      	fmul.4s	v21, v22, v21
    1b88:      	fadd.4s	v17, v17, v21
    1b8c:      	fadd.4s	v17, v17, v19
    1b90:      	add.4s	v18, v18, v10
    1b94:      	sshr.4s	v21, v18, #0x1
    1b98:      	shl.4s	v22, v21, #0x17
    1b9c:      	add.4s	v22, v22, v19
    1ba0:      	fmul.4s	v17, v17, v22
    1ba4:      	sub.4s	v18, v18, v21
    1ba8:      	shl.4s	v18, v18, #0x17
    1bac:      	add.4s	v18, v18, v19
    1bb0:      	fmul.4s	v17, v17, v18
    1bb4:      	fcmgt.4s	v16, v16, v6
    1bb8:      	ldr	q5, [sp, #0x200]
    1bbc:      	bsl.16b	v16, v5, v17
    1bc0:      	ldr	q5, [sp, #0x260]
    1bc4:      	fdiv.4s	v17, v5, v16
    1bc8:      	fsub.4s	v18, v16, v17
    1bcc:      	fadd.4s	v16, v16, v17
    1bd0:      	fdiv.4s	v16, v18, v16
    1bd4:      	bsl.16b	v4, v16, v19
    1bd8:      	fcmge.4s	v2, v19, v2
    1bdc:      	ldr	q5, [sp, #0x100]
    1be0:      	bsl.16b	v2, v5, v4
    1be4:      	bif.16b	v2, v1, v14
    1be8:      	fcmeq.4s	v1, v1, v1
    1bec:      	fadd.4s	v2, v2, v19
    1bf0:      	ldr	q4, [sp, #0x220]
    1bf4:      	bsl.16b	v1, v2, v4
    1bf8:      	fmul.4s	v0, v0, v9
    1bfc:      	fmul.4s	v0, v0, v1
    1c00:      	ldr	s1, [x5, x4]
    1c04:      	fadd.4s	v0, v1, v0
    1c08:      	ldp	q15, q23, [sp, #0x280]
    1c0c:      	mov.16b	v17, v28
    1c10:      	ldr	q20, [sp, #0x2a0]
    1c14:      	movi.4s	v21, #0x4b, lsl #24
    1c18:      	movi.4s	v18, #0xcb, lsl #24
    1c1c:      	mov.16b	v5, v11
    1c20:      	mov.16b	v12, v30
    1c24:      	b	0x16e8 <ltmp0+0x16e8>
    1c28:      	add	x2, x26, x4
    1c2c:      	ldp	q0, q1, [x2, #0xc0]
    1c30:      	str	q0, [sp, #0x600]
    1c34:      	str	q1, [sp, #0x610]
    1c38:      	ldp	q0, q1, [x2, #0xe0]
    1c3c:      	str	q0, [sp, #0x620]
    1c40:      	str	q1, [sp, #0x630]
    1c44:      	ldp	q0, q1, [x2, #0x80]
    1c48:      	str	q0, [sp, #0x5c0]
    1c4c:      	str	q1, [sp, #0x5d0]
    1c50:      	ldp	q0, q1, [x2, #0xa0]
    1c54:      	str	q0, [sp, #0x5e0]
    1c58:      	str	q1, [sp, #0x5f0]
    1c5c:      	ldp	q0, q1, [x2, #0x40]
    1c60:      	str	q0, [sp, #0x580]
    1c64:      	str	q1, [sp, #0x590]
    1c68:      	ldp	q0, q1, [x2, #0x60]
    1c6c:      	str	q0, [sp, #0x5a0]
    1c70:      	str	q1, [sp, #0x5b0]
    1c74:      	ldp	q0, q1, [x2]
    1c78:      	str	q0, [sp, #0x540]
    1c7c:      	str	q1, [sp, #0x550]
    1c80:      	ldp	q0, q1, [x2, #0x20]
    1c84:      	str	q0, [sp, #0x560]
    1c88:      	str	q1, [sp, #0x570]
    1c8c:      	add	x2, x5, x4
    1c90:      	ldp	q0, q1, [x2, #0xc0]
    1c94:      	str	q0, [sp, #0x4e0]
    1c98:      	str	q1, [sp, #0x4f0]
    1c9c:      	ldp	q0, q1, [x2, #0xe0]
    1ca0:      	str	q0, [sp, #0x500]
    1ca4:      	str	q1, [sp, #0x510]
    1ca8:      	ldp	q0, q1, [x2, #0x80]
    1cac:      	str	q0, [sp, #0x4a0]
    1cb0:      	str	q1, [sp, #0x4b0]
    1cb4:      	ldp	q0, q1, [x2, #0xa0]
    1cb8:      	str	q0, [sp, #0x4c0]
    1cbc:      	str	q1, [sp, #0x4d0]
    1cc0:      	ldp	q0, q1, [x2, #0x40]
    1cc4:      	str	q0, [sp, #0x460]
    1cc8:      	str	q1, [sp, #0x470]
    1ccc:      	ldp	q0, q1, [x2, #0x60]
    1cd0:      	str	q0, [sp, #0x480]
    1cd4:      	str	q1, [sp, #0x490]
    1cd8:      	ldp	q0, q1, [x2]
    1cdc:      	ldp	q2, q3, [x2, #0x20]
    1ce0:      	add	x4, x4, #0x100
    1ce4:      	str	q0, [sp, #0x420]
    1ce8:      	str	q1, [sp, #0x430]
    1cec:      	ldr	s0, [x26, x4]
    1cf0:      	str	q0, [sp, #0xf0]
    1cf4:      	str	q0, [sp, #0x640]
    1cf8:      	str	q2, [sp, #0x440]
    1cfc:      	str	q3, [sp, #0x450]
    1d00:      	ldr	s0, [x5, x4]
    1d04:      	str	q0, [sp, #0x100]
    1d08:      	str	q0, [sp, #0x520]
    1d0c:      	ldp	q5, q27, [sp, #0x150]
    1d10:      	ldp	q6, q23, [sp, #0x110]
    1d14:      	ldp	q20, q7, [sp, #0x130]
    1d18:      	add	x2, x16, x11
    1d1c:      	ldp	q22, q24, [x2]
    1d20:      	fmul.4s	v0, v22, v25
    1d24:      	fmul.4s	v1, v24, v25
    1d28:      	fmul.4s	v1, v24, v1
    1d2c:      	fmul.4s	v0, v22, v0
    1d30:      	fmul.4s	v0, v22, v0
    1d34:      	fmul.4s	v1, v24, v1
    1d38:      	fadd.4s	v1, v24, v1
    1d3c:      	fadd.4s	v0, v22, v0
    1d40:      	fmul.4s	v13, v0, v26
    1d44:      	fmul.4s	v11, v1, v26
    1d48:      	fabs.4s	v3, v11
    1d4c:      	fabs.4s	v2, v13
    1d50:      	fmul.4s	v28, v13, v13
    1d54:      	fmul.4s	v30, v11, v11
    1d58:      	mov.16b	v0, v31
    1d5c:      	fmla.4s	v0, v28, v29
    1d60:      	mov.16b	v1, v31
    1d64:      	fmla.4s	v1, v30, v29
    1d68:      	mov.16b	v4, v8
    1d6c:      	fmla.4s	v4, v28, v0
    1d70:      	mov.16b	v0, v8
    1d74:      	fmla.4s	v0, v30, v1
    1d78:      	ldr	q1, [sp, #0x250]
    1d7c:      	mov.16b	v16, v1
    1d80:      	fmla.4s	v16, v28, v4
    1d84:      	mov.16b	v4, v1
    1d88:      	fmla.4s	v4, v30, v0
    1d8c:      	ldp	q17, q25, [sp, #0x280]
    1d90:      	mov.16b	v0, v17
    1d94:      	mov.16b	v18, v27
    1d98:      	mov.16b	v21, v27
    1d9c:      	mov.16b	v1, v19
    1da0:      	fmla.4s	v0, v28, v16
    1da4:      	mov.16b	v16, v25
    1da8:      	ldr	q26, [sp, #0x2a0]
    1dac:      	fmla.4s	v16, v30, v26
    1db0:      	fmla.4s	v25, v28, v26
    1db4:      	ldr	q29, [sp, #0x270]
    1db8:      	mov.16b	v26, v29
    1dbc:      	fmla.4s	v17, v30, v4
    1dc0:      	fmla.4s	v26, v30, v16
    1dc4:      	mov.16b	v4, v29
    1dc8:      	fmla.4s	v4, v28, v25
    1dcc:      	ldr	q25, [sp, #0x210]
    1dd0:      	mov.16b	v16, v25
    1dd4:      	fmla.4s	v16, v30, v26
    1dd8:      	fmla.4s	v18, v28, v0
    1ddc:      	mov.16b	v0, v25
    1de0:      	fmla.4s	v0, v28, v4
    1de4:      	ldr	q4, [sp, #0x1f0]
    1de8:      	mov.16b	v25, v4
    1dec:      	fmla.4s	v25, v30, v16
    1df0:      	mov.16b	v16, v4
    1df4:      	fmla.4s	v21, v30, v17
    1df8:      	fmla.4s	v16, v28, v0
    1dfc:      	movi.4s	v31, #0x3f, lsl #24
    1e00:      	movi.4s	v8, #0x3f, lsl #24
    1e04:      	mov.16b	v0, v19
    1e08:      	ldr	q17, [sp, #0x1e0]
    1e0c:      	fcmge.4s	v4, v17, v2
    1e10:      	fmla.4s	v31, v30, v25
    1e14:      	fcmge.4s	v17, v17, v3
    1e18:      	and.16b	v26, v17, v3
    1e1c:      	and.16b	v29, v4, v2
    1e20:      	ldr	q9, [sp, #0x1c0]
    1e24:      	fcmge.4s	v25, v29, v9
    1e28:      	fcmge.4s	v9, v26, v9
    1e2c:      	fcmge.4s	v10, v6, v26
    1e30:      	and.16b	v9, v9, v10
    1e34:      	fcmge.4s	v10, v6, v29
    1e38:      	and.16b	v25, v25, v10
    1e3c:      	and.16b	v25, v25, v29
    1e40:      	and.16b	v9, v9, v26
    1e44:      	fmla.4s	v1, v30, v21
    1e48:      	ldr	q10, [sp, #0x1d0]
    1e4c:      	fmul.4s	v21, v9, v10
    1e50:      	fmul.4s	v10, v25, v10
    1e54:      	movi.4s	v14, #0x4b, lsl #24
    1e58:      	fadd.4s	v10, v10, v14
    1e5c:      	movi.4s	v12, #0x4b, lsl #24
    1e60:      	fadd.4s	v21, v21, v14
    1e64:      	movi.4s	v14, #0xcb, lsl #24
    1e68:      	fadd.4s	v21, v21, v14
    1e6c:      	fmla.4s	v0, v30, v31
    1e70:      	movi.4s	v15, #0xcb, lsl #24
    1e74:      	fadd.4s	v30, v10, v14
    1e78:      	fcvtzs.4s	v30, v30
    1e7c:      	fcvtzs.4s	v21, v21
    1e80:      	scvtf.4s	v31, v21
    1e84:      	scvtf.4s	v10, v30
    1e88:      	fmla.4s	v8, v28, v16
    1e8c:      	ldr	q14, [sp, #0x230]
    1e90:      	fmul.4s	v16, v31, v14
    1e94:      	fadd.4s	v16, v9, v16
    1e98:      	fmul.4s	v9, v10, v14
    1e9c:      	fadd.4s	v25, v25, v9
    1ea0:      	mov.16b	v9, v19
    1ea4:      	fmla.4s	v9, v28, v18
    1ea8:      	fmul.4s	v18, v10, v5
    1eac:      	fadd.4s	v25, v25, v18
    1eb0:      	fmul.4s	v18, v31, v5
    1eb4:      	fadd.4s	v16, v16, v18
    1eb8:      	mov.16b	v18, v19
    1ebc:      	fmla.4s	v18, v28, v8
    1ec0:      	fmul.4s	v28, v16, v7
    1ec4:      	fmul.4s	v31, v25, v7
    1ec8:      	fadd.4s	v31, v31, v20
    1ecc:      	fadd.4s	v28, v28, v20
    1ed0:      	fmul.4s	v28, v16, v28
    1ed4:      	fmul.4s	v8, v2, v9
    1ed8:      	movi.4s	v9, #0x3f, lsl #24
    1edc:      	fmul.4s	v31, v25, v31
    1ee0:      	fadd.4s	v31, v31, v23
    1ee4:      	fadd.4s	v28, v28, v23
    1ee8:      	fmul.4s	v28, v16, v28
    1eec:      	fmul.4s	v31, v25, v31
    1ef0:      	ldr	q10, [sp, #0x240]
    1ef4:      	fadd.4s	v31, v31, v10
    1ef8:      	fadd.4s	v28, v28, v10
    1efc:      	fmul.4s	v28, v16, v28
    1f00:      	fmul.4s	v31, v25, v31
    1f04:      	fadd.4s	v31, v31, v27
    1f08:      	fadd.4s	v28, v28, v27
    1f0c:      	fdiv.4s	v18, v8, v18
    1f10:      	fmul.4s	v28, v16, v28
    1f14:      	fmul.4s	v31, v25, v31
    1f18:      	fadd.4s	v31, v31, v9
    1f1c:      	fadd.4s	v28, v28, v9
    1f20:      	fmul.4s	v8, v16, v16
    1f24:      	fmul.4s	v28, v8, v28
    1f28:      	fmul.4s	v8, v25, v25
    1f2c:      	fmul.4s	v31, v8, v31
    1f30:      	fadd.4s	v25, v25, v31
    1f34:      	fadd.4s	v16, v16, v28
    1f38:      	movi.2d	v14, #0xffffffffffffffff
    1f3c:      	add.4s	v28, v30, v14
    1f40:      	fadd.4s	v25, v25, v19
    1f44:      	sshr.4s	v30, v28, #0x1
    1f48:      	shl.4s	v31, v30, #0x17
    1f4c:      	add.4s	v31, v31, v19
    1f50:      	fmul.4s	v25, v25, v31
    1f54:      	ldp	q8, q31, [sp, #0x170]
    1f58:      	movi.2d	v10, #0xffffffffffffffff
    1f5c:      	add.4s	v21, v21, v14
    1f60:      	fadd.4s	v16, v16, v19
    1f64:      	sub.4s	v28, v28, v30
    1f68:      	sshr.4s	v30, v21, #0x1
    1f6c:      	sub.4s	v21, v21, v30
    1f70:      	shl.4s	v30, v30, #0x17
    1f74:      	add.4s	v30, v30, v19
    1f78:      	fmul.4s	v16, v16, v30
    1f7c:      	shl.4s	v21, v21, #0x17
    1f80:      	add.4s	v21, v21, v19
    1f84:      	fmul.4s	v16, v16, v21
    1f88:      	shl.4s	v21, v28, #0x17
    1f8c:      	add.4s	v21, v21, v19
    1f90:      	fmul.4s	v21, v25, v21
    1f94:      	fcmgt.4s	v25, v29, v6
    1f98:      	ldr	q28, [sp, #0x200]
    1f9c:      	bit.16b	v21, v28, v25
    1fa0:      	fmul.4s	v1, v3, v1
    1fa4:      	fcmgt.4s	v25, v26, v6
    1fa8:      	ldp	q29, q26, [sp, #0x190]
    1fac:      	bit.16b	v16, v28, v25
    1fb0:      	fdiv.4s	v0, v1, v0
    1fb4:      	ldr	q28, [sp, #0x260]
    1fb8:      	fdiv.4s	v1, v28, v16
    1fbc:      	fsub.4s	v25, v16, v1
    1fc0:      	fadd.4s	v1, v16, v1
    1fc4:      	fdiv.4s	v1, v25, v1
    1fc8:      	ldr	q25, [sp, #0x1b0]
    1fcc:      	bif.16b	v1, v19, v17
    1fd0:      	fcmge.4s	v3, v19, v3
    1fd4:      	bif.16b	v0, v1, v3
    1fd8:      	fdiv.4s	v1, v28, v21
    1fdc:      	fsub.4s	v3, v21, v1
    1fe0:      	fadd.4s	v1, v21, v1
    1fe4:      	fdiv.4s	v1, v3, v1
    1fe8:      	bif.16b	v1, v19, v4
    1fec:      	fcmge.4s	v2, v19, v2
    1ff0:      	bit.16b	v1, v18, v2
    1ff4:      	mvni.4s	v4, #0x80, lsl #24
    1ff8:      	bif.16b	v1, v13, v4
    1ffc:      	fcmeq.4s	v2, v13, v13
    2000:      	fadd.4s	v1, v1, v19
    2004:      	ldr	q3, [sp, #0x220]
    2008:      	bif.16b	v1, v3, v2
    200c:      	mvni.4s	v14, #0x80, lsl #24
    2010:      	bif.16b	v0, v11, v4
    2014:      	fcmeq.4s	v2, v11, v11
    2018:      	fadd.4s	v0, v0, v19
    201c:      	bif.16b	v0, v3, v2
    2020:      	fmul.4s	v2, v24, v9
    2024:      	fmul.4s	v0, v2, v0
    2028:      	fmul.4s	v2, v22, v9
    202c:      	fmul.4s	v1, v2, v1
    2030:      	add	x2, x17, x11
    2034:      	ldp	q3, q2, [x2]
    2038:      	fadd.4s	v1, v3, v1
    203c:      	fadd.4s	v0, v2, v0
    2040:      	add	x2, x21, x11
    2044:      	stp	q1, q0, [x2]
    2048:      	add	x11, x11, #0x20
    204c:      	cmp	x11, #0x100
    2050:      	b.ne	0x1d18 <ltmp0+0x1d18>
    2054:      	b	0x152c <ltmp0+0x152c>
    2058:      	str	q4, [sp, #0xe0]
    205c:      	mov	x11, #0x0               ; =0
    2060:      	add	x4, x1, x4
    2064:      	ldr	q6, [sp, #0x100]
    2068:      	ldr	d4, [sp, #0x50]
    206c:      	b	0x2090 <ltmp0+0x2090>
    2070:      	add	x2, x16, x11
    2074:      	ldp	q0, q3, [x2]
    2078:      	bif.16b	v2, v3, v28
    207c:      	bit.16b	v0, v1, v6
    2080:      	stp	q0, q2, [x2]
    2084:      	add	x11, x11, #0x20
    2088:      	cmp	x11, #0x100
    208c:      	b.eq	0x2134 <ltmp0+0x2134>
    2090:      	ldr	q0, [x20]
    2094:      	and.16b	v0, v16, v0
    2098:      	addv.8h	h14, v0
    209c:      	fmov	w6, s14
    20a0:      	add	x5, x4, x11
    20a4:      	movi.2d	v1, #0000000000000000
    20a8:      	movi.2d	v2, #0000000000000000
    20ac:      	tbz	w6, #0x0, 0x20f0 <ltmp0+0x20f0>
    20b0:      	ldr	s1, [x5]
    20b4:      	and	w6, w6, #0xff
    20b8:      	tbnz	w6, #0x1, 0x20f8 <ltmp0+0x20f8>
    20bc:      	tbz	w6, #0x2, 0x2104 <ltmp0+0x2104>
    20c0:      	add	x2, x5, #0x8
    20c4:      	ld1.s	{ v1 }[2], [x2]
    20c8:      	tbnz	w6, #0x3, 0x2108 <ltmp0+0x2108>
    20cc:      	tbz	w6, #0x4, 0x2114 <ltmp0+0x2114>
    20d0:      	add	x2, x5, #0x10
    20d4:      	ld1.s	{ v2 }[0], [x2]
    20d8:      	tbnz	w6, #0x5, 0x2118 <ltmp0+0x2118>
    20dc:      	tbz	w6, #0x6, 0x2124 <ltmp0+0x2124>
    20e0:      	add	x2, x5, #0x18
    20e4:      	ld1.s	{ v2 }[2], [x2]
    20e8:      	tbz	w6, #0x7, 0x2070 <ltmp0+0x2070>
    20ec:      	b	0x2128 <ltmp0+0x2128>
    20f0:      	and	w6, w6, #0xff
    20f4:      	tbz	w6, #0x1, 0x20bc <ltmp0+0x20bc>
    20f8:      	add	x2, x5, #0x4
    20fc:      	ld1.s	{ v1 }[1], [x2]
    2100:      	tbnz	w6, #0x2, 0x20c0 <ltmp0+0x20c0>
    2104:      	tbz	w6, #0x3, 0x20cc <ltmp0+0x20cc>
    2108:      	add	x2, x5, #0xc
    210c:      	ld1.s	{ v1 }[3], [x2]
    2110:      	tbnz	w6, #0x4, 0x20d0 <ltmp0+0x20d0>
    2114:      	tbz	w6, #0x5, 0x20dc <ltmp0+0x20dc>
    2118:      	add	x2, x5, #0x14
    211c:      	ld1.s	{ v2 }[1], [x2]
    2120:      	tbnz	w6, #0x6, 0x20e0 <ltmp0+0x20e0>
    2124:      	tbz	w6, #0x7, 0x2070 <ltmp0+0x2070>
    2128:      	add	x2, x5, #0x1c
    212c:      	ld1.s	{ v2 }[3], [x2]
    2130:      	b	0x2070 <ltmp0+0x2070>
    2134:      	xtn.4h	v0, v6
    2138:      	uzp1.8b	v0, v0, v0
    213c:      	movi.2d	v2, #0000000000000000
    2140:      	mov.b	v2[0], v0[0]
    2144:      	adrp	x11, 0x2000 <ltmp0+0x2000>
    2148:      	ldr	d1, [x11]
    214c:      	str	d1, [sp, #0x30]
    2150:      	and.8b	v1, v2, v1
    2154:      	addv.8b	b1, v1
    2158:      	fmov	w11, s1
    215c:      	str	q2, [sp, #0xa0]
    2160:      	umaxv.8b	b1, v2
    2164:      	fmov	w2, s1
    2168:      	rbit	w4, w11
    216c:      	clz	w4, w4
    2170:      	tst	w2, #0x1
    2174:      	csel	w25, w4, wzr, ne
    2178:      	mov	w4, #0x40               ; =64
    217c:      	dup.2d	v2, x4
    2180:      	movi.2s	v1, #0x41
    2184:      	ldr	q3, [sp, #0x40]
    2188:      	umlal.2d	v3, v4, v1
    218c:      	movi.2d	v1, #0000000000000000
    2190:      	mov.b	v1[0], v0[0]
    2194:      	add.2d	v3, v3, v2
    2198:      	ushll.2d	v0, v1, #0x0
    219c:      	shl.2d	v0, v0, #0x3f
    21a0:      	cmlt.2d	v0, v0, #0
    21a4:      	str	q3, [sp, #0x40]
    21a8:      	and.16b	v0, v0, v3
    21ac:      	movi.2d	v1, #0000000000000000
    21b0:      	stp	q1, q1, [sp, #0x3f0]
    21b4:      	stp	q0, q1, [sp, #0x3d0]
    21b8:      	and	x4, x25, #0x7
    21bc:      	add	x5, sp, #0x3d0
    21c0:      	ldr	x4, [x5, x4, lsl #3]
    21c4:      	sub	x4, x4, x25
    21c8:      	lsl	x4, x4, #2
    21cc:      	add	x1, x1, x4
    21d0:      	movi.2d	v24, #0000000000000000
    21d4:      	movi.2d	v18, #0000000000000000
    21d8:      	tbz	w2, #0x0, 0x2218 <ltmp0+0x2218>
    21dc:      	ldr	s24, [x1]
    21e0:      	tbnz	w11, #0x1, 0x221c <ltmp0+0x221c>
    21e4:      	tbz	w11, #0x2, 0x2228 <ltmp0+0x2228>
    21e8:      	add	x2, x1, #0x8
    21ec:      	ld1.s	{ v24 }[2], [x2]
    21f0:      	tbnz	w11, #0x3, 0x222c <ltmp0+0x222c>
    21f4:      	tbz	w11, #0x4, 0x2238 <ltmp0+0x2238>
    21f8:      	add	x2, x1, #0x10
    21fc:      	ld1.s	{ v18 }[0], [x2]
    2200:      	tbnz	w11, #0x5, 0x223c <ltmp0+0x223c>
    2204:      	tbz	w11, #0x6, 0x2248 <ltmp0+0x2248>
    2208:      	add	x2, x1, #0x18
    220c:      	ld1.s	{ v18 }[2], [x2]
    2210:      	tbnz	w11, #0x7, 0x224c <ltmp0+0x224c>
    2214:      	b	0x2254 <ltmp0+0x2254>
    2218:      	tbz	w11, #0x1, 0x21e4 <ltmp0+0x21e4>
    221c:      	add	x2, x1, #0x4
    2220:      	ld1.s	{ v24 }[1], [x2]
    2224:      	tbnz	w11, #0x2, 0x21e8 <ltmp0+0x21e8>
    2228:      	tbz	w11, #0x3, 0x21f4 <ltmp0+0x21f4>
    222c:      	add	x2, x1, #0xc
    2230:      	ld1.s	{ v24 }[3], [x2]
    2234:      	tbnz	w11, #0x4, 0x21f8 <ltmp0+0x21f8>
    2238:      	tbz	w11, #0x5, 0x2204 <ltmp0+0x2204>
    223c:      	add	x2, x1, #0x14
    2240:      	ld1.s	{ v18 }[1], [x2]
    2244:      	tbnz	w11, #0x6, 0x2208 <ltmp0+0x2208>
    2248:      	tbz	w11, #0x7, 0x2254 <ltmp0+0x2254>
    224c:      	add	x1, x1, #0x1c
    2250:      	ld1.s	{ v18 }[3], [x1]
    2254:      	mov	x6, #0x0                ; =0
    2258:      	movi.2s	v1, #0x41
    225c:      	umull.2d	v0, v4, v1
    2260:      	ldr	q3, [sp, #0xd0]
    2264:      	ldr	d4, [sp, #0x60]
    2268:      	umlal.2d	v3, v4, v1
    226c:      	add.2d	v7, v3, v2
    2270:      	ldr	q3, [sp, #0x90]
    2274:      	ldr	d4, [sp, #0x70]
    2278:      	umlal.2d	v3, v4, v1
    227c:      	add.2d	v3, v3, v2
    2280:      	stp	q7, q3, [sp, #0x60]
    2284:      	ldr	d3, [sp, #0x80]
    2288:      	umlal.2d	v22, v3, v1
    228c:      	adrp	x1, 0x2000 <ltmp0+0x2000>
    2290:      	ldr	q1, [x1]
    2294:      	mov	w1, #0x100              ; =256
    2298:      	dup.2d	v3, x1
    229c:      	sshll.2d	v4, v6, #0x0
    22a0:      	bif.16b	v1, v3, v4
    22a4:      	adrp	x1, 0x2000 <ltmp0+0x2000>
    22a8:      	ldr	q4, [x1]
    22ac:      	sshll.2d	v16, v28, #0x0
    22b0:      	bif.16b	v4, v3, v16
    22b4:      	adrp	x1, 0x2000 <ltmp0+0x2000>
    22b8:      	ldr	q16, [x1]
    22bc:      	ldr	q17, [sp, #0xe0]
    22c0:      	bif.16b	v16, v3, v17
    22c4:      	adrp	x1, 0x2000 <ltmp0+0x2000>
    22c8:      	ldr	q17, [x1]
    22cc:      	bit.16b	v3, v17, v11
    22d0:      	stp	q4, q3, [sp, #0x3b0]
    22d4:      	stp	q1, q16, [sp, #0x390]
    22d8:      	and	x1, x25, #0x7
    22dc:      	add	x2, sp, #0x390
    22e0:      	ldr	x1, [x2, x1, lsl #3]
    22e4:      	add.2d	v1, v22, v2
    22e8:      	str	q1, [sp, #0x50]
    22ec:      	sub	x1, x1, x25, lsl #2
    22f0:      	tst	w11, #0xff
    22f4:      	csel	x11, xzr, x1, eq
    22f8:      	add	x1, x16, x11
    22fc:      	ldp	q1, q2, [x1]
    2300:      	ldr	q4, [sp, #0xa0]
    2304:      	zip2.8b	v3, v4, v0
    2308:      	ushll.4s	v3, v3, #0x0
    230c:      	shl.4s	v3, v3, #0x1f
    2310:      	cmlt.4s	v3, v3, #0
    2314:      	bit.16b	v2, v18, v3
    2318:      	zip1.8b	v3, v4, v0
    231c:      	ushll.4s	v3, v3, #0x0
    2320:      	shl.4s	v3, v3, #0x1f
    2324:      	cmlt.4s	v3, v3, #0
    2328:      	str	q24, [sp, #0x80]
    232c:      	bit.16b	v1, v24, v3
    2330:      	stp	q1, q2, [x1]
    2334:      	fmov	x1, d0
    2338:      	lsl	x1, x1, #2
    233c:      	mov	w2, #0x1                ; =1
    2340:      	dup.2d	v0, x2
    2344:      	add	x5, x24, x1
    2348:      	ushll2.2d	v1, v28, #0x0
    234c:      	and.16b	v17, v1, v0
    2350:      	ushll2.2d	v1, v6, #0x0
    2354:      	and.16b	v2, v1, v0
    2358:      	ushll.2d	v1, v28, #0x0
    235c:      	and.16b	v1, v1, v0
    2360:      	stp	q1, q2, [sp, #0xd0]
    2364:      	ushll.2d	v1, v6, #0x0
    2368:      	and.16b	v0, v1, v0
    236c:      	str	q0, [sp, #0xc0]
    2370:      	movi.2d	v2, #0000000000000000
    2374:      	movi.2d	v3, #0000000000000000
    2378:      	movi.2d	v22, #0000000000000000
    237c:      	movi.2d	v24, #0000000000000000
    2380:      	b	0x23bc <ltmp0+0x23bc>
    2384:      	add	x2, x17, x6
    2388:      	ldp	q0, q16, [x2]
    238c:      	bif.16b	v4, v16, v28
    2390:      	bit.16b	v0, v1, v6
    2394:      	stp	q0, q4, [x2]
    2398:      	ldp	q0, q1, [sp, #0xd0]
    239c:      	add.2d	v3, v3, v1
    23a0:      	add.2d	v22, v22, v0
    23a4:      	add.2d	v24, v24, v17
    23a8:      	ldr	q0, [sp, #0xc0]
    23ac:      	add.2d	v2, v2, v0
    23b0:      	fmov	x6, d2
    23b4:      	cmp	x6, #0x8
    23b8:      	b.ge	0x2458 <ltmp0+0x2458>
    23bc:      	fmov	w19, s14
    23c0:      	lsl	x6, x6, #5
    23c4:      	add	x7, x5, x6
    23c8:      	movi.2d	v1, #0000000000000000
    23cc:      	movi.2d	v4, #0000000000000000
    23d0:      	tbz	w19, #0x0, 0x2414 <ltmp0+0x2414>
    23d4:      	ldr	s1, [x7]
    23d8:      	and	w19, w19, #0xff
    23dc:      	tbnz	w19, #0x1, 0x241c <ltmp0+0x241c>
    23e0:      	tbz	w19, #0x2, 0x2428 <ltmp0+0x2428>
    23e4:      	add	x2, x7, #0x8
    23e8:      	ld1.s	{ v1 }[2], [x2]
    23ec:      	tbnz	w19, #0x3, 0x242c <ltmp0+0x242c>
    23f0:      	tbz	w19, #0x4, 0x2438 <ltmp0+0x2438>
    23f4:      	add	x2, x7, #0x10
    23f8:      	ld1.s	{ v4 }[0], [x2]
    23fc:      	tbnz	w19, #0x5, 0x243c <ltmp0+0x243c>
    2400:      	tbz	w19, #0x6, 0x2448 <ltmp0+0x2448>
    2404:      	add	x2, x7, #0x18
    2408:      	ld1.s	{ v4 }[2], [x2]
    240c:      	tbz	w19, #0x7, 0x2384 <ltmp0+0x2384>
    2410:      	b	0x244c <ltmp0+0x244c>
    2414:      	and	w19, w19, #0xff
    2418:      	tbz	w19, #0x1, 0x23e0 <ltmp0+0x23e0>
    241c:      	add	x2, x7, #0x4
    2420:      	ld1.s	{ v1 }[1], [x2]
    2424:      	tbnz	w19, #0x2, 0x23e4 <ltmp0+0x23e4>
    2428:      	tbz	w19, #0x3, 0x23f0 <ltmp0+0x23f0>
    242c:      	add	x2, x7, #0xc
    2430:      	ld1.s	{ v1 }[3], [x2]
    2434:      	tbnz	w19, #0x4, 0x23f4 <ltmp0+0x23f4>
    2438:      	tbz	w19, #0x5, 0x2400 <ltmp0+0x2400>
    243c:      	add	x2, x7, #0x14
    2440:      	ld1.s	{ v4 }[1], [x2]
    2444:      	tbnz	w19, #0x6, 0x2404 <ltmp0+0x2404>
    2448:      	tbz	w19, #0x7, 0x2384 <ltmp0+0x2384>
    244c:      	add	x2, x7, #0x1c
    2450:      	ld1.s	{ v4 }[3], [x2]
    2454:      	b	0x2384 <ltmp0+0x2384>
    2458:      	add	x4, x24, x4
    245c:      	ldr	q0, [sp, #0xa0]
    2460:      	shl.8b	v0, v0, #0x7
    2464:      	cmlt.8b	v0, v0, #0
    2468:      	ldr	d1, [sp, #0x30]
    246c:      	and.8b	v0, v0, v1
    2470:      	addv.8b	b0, v0
    2474:      	str	d0, [sp, #0x18]
    2478:      	fmov	w5, s0
    247c:      	movi.2d	v16, #0000000000000000
    2480:      	movi.2d	v4, #0000000000000000
    2484:      	tbz	w5, #0x0, 0x24d0 <ltmp0+0x24d0>
    2488:      	ldr	s16, [x4]
    248c:      	ldr	q6, [sp, #0x1d0]
    2490:      	ldr	q24, [sp, #0x230]
    2494:      	tbnz	w5, #0x1, 0x24dc <ltmp0+0x24dc>
    2498:      	tbz	w5, #0x2, 0x24e8 <ltmp0+0x24e8>
    249c:      	add	x2, x4, #0x8
    24a0:      	ld1.s	{ v16 }[2], [x2]
    24a4:      	tbnz	w5, #0x3, 0x24ec <ltmp0+0x24ec>
    24a8:      	tbz	w5, #0x4, 0x24f8 <ltmp0+0x24f8>
    24ac:      	add	x2, x4, #0x10
    24b0:      	ld1.s	{ v4 }[0], [x2]
    24b4:      	tbnz	w5, #0x5, 0x24fc <ltmp0+0x24fc>
    24b8:      	tbz	w5, #0x6, 0x2508 <ltmp0+0x2508>
    24bc:      	add	x2, x4, #0x18
    24c0:      	ld1.s	{ v4 }[2], [x2]
    24c4:      	str	q14, [sp, #0xb0]
    24c8:      	tbnz	w5, #0x7, 0x2510 <ltmp0+0x2510>
    24cc:      	b	0x2518 <ltmp0+0x2518>
    24d0:      	ldr	q6, [sp, #0x1d0]
    24d4:      	ldr	q24, [sp, #0x230]
    24d8:      	tbz	w5, #0x1, 0x2498 <ltmp0+0x2498>
    24dc:      	add	x2, x4, #0x4
    24e0:      	ld1.s	{ v16 }[1], [x2]
    24e4:      	tbnz	w5, #0x2, 0x249c <ltmp0+0x249c>
    24e8:      	tbz	w5, #0x3, 0x24a8 <ltmp0+0x24a8>
    24ec:      	add	x2, x4, #0xc
    24f0:      	ld1.s	{ v16 }[3], [x2]
    24f4:      	tbnz	w5, #0x4, 0x24ac <ltmp0+0x24ac>
    24f8:      	tbz	w5, #0x5, 0x24b8 <ltmp0+0x24b8>
    24fc:      	add	x2, x4, #0x14
    2500:      	ld1.s	{ v4 }[1], [x2]
    2504:      	tbnz	w5, #0x6, 0x24bc <ltmp0+0x24bc>
    2508:      	str	q14, [sp, #0xb0]
    250c:      	tbz	w5, #0x7, 0x2518 <ltmp0+0x2518>
    2510:      	add	x2, x4, #0x1c
    2514:      	ld1.s	{ v4 }[3], [x2]
    2518:      	str	q18, [sp, #0x90]
    251c:      	mov	x4, #0x0                ; =0
    2520:      	add	x11, x17, x11
    2524:      	ldp	q0, q1, [x11]
    2528:      	ldr	q3, [sp, #0xa0]
    252c:      	zip2.8b	v2, v3, v0
    2530:      	ushll.4s	v2, v2, #0x0
    2534:      	shl.4s	v2, v2, #0x1f
    2538:      	cmlt.4s	v2, v2, #0
    253c:      	stp	q16, q4, [sp, #0x20]
    2540:      	bit.16b	v1, v4, v2
    2544:      	zip1.8b	v2, v3, v0
    2548:      	ushll.4s	v2, v2, #0x0
    254c:      	shl.4s	v2, v2, #0x1f
    2550:      	cmlt.4s	v2, v2, #0
    2554:      	bit.16b	v0, v16, v2
    2558:      	stp	q0, q1, [x11]
    255c:      	add	x11, x23, x1
    2560:      	movi.2d	v10, #0000000000000000
    2564:      	movi.2d	v13, #0000000000000000
    2568:      	movi.2d	v23, #0000000000000000
    256c:      	movi.2d	v28, #0000000000000000
    2570:      	b	0x2598 <ltmp0+0x2598>
    2574:      	ldp	q0, q1, [sp, #0xd0]
    2578:      	add.2d	v13, v13, v1
    257c:      	add.2d	v23, v23, v0
    2580:      	add.2d	v28, v28, v17
    2584:      	ldr	q0, [sp, #0xc0]
    2588:      	add.2d	v10, v10, v0
    258c:      	fmov	x4, d10
    2590:      	cmp	x4, #0x8
    2594:      	b.ge	0x29d0 <ltmp0+0x29d0>
    2598:      	mov.16b	v7, v17
    259c:      	lsl	x1, x4, #5
    25a0:      	add	x4, x16, x1
    25a4:      	ldr	q0, [x4]
    25a8:      	mov.16b	v18, v5
    25ac:      	ldr	q5, [sp, #0x100]
    25b0:      	and.16b	v0, v5, v0
    25b4:      	fmul.4s	v1, v0, v25
    25b8:      	fmul.4s	v1, v0, v1
    25bc:      	fmul.4s	v1, v0, v1
    25c0:      	fadd.4s	v1, v0, v1
    25c4:      	fmul.4s	v1, v1, v26
    25c8:      	and.16b	v1, v5, v1
    25cc:      	fabs.4s	v2, v1
    25d0:      	fmul.4s	v3, v1, v1
    25d4:      	mov.16b	v4, v31
    25d8:      	fmla.4s	v4, v3, v29
    25dc:      	mov.16b	v16, v8
    25e0:      	fmla.4s	v16, v3, v4
    25e4:      	ldr	q4, [sp, #0x250]
    25e8:      	fmla.4s	v4, v3, v16
    25ec:      	mov.16b	v20, v15
    25f0:      	fmla.4s	v15, v3, v4
    25f4:      	ldr	q11, [sp, #0x160]
    25f8:      	mov.16b	v4, v11
    25fc:      	fmla.4s	v4, v3, v15
    2600:      	mov.16b	v16, v19
    2604:      	fmla.4s	v16, v3, v4
    2608:      	fmul.4s	v4, v2, v16
    260c:      	ldp	q16, q17, [sp, #0x290]
    2610:      	fmla.4s	v16, v3, v17
    2614:      	ldr	q17, [sp, #0x270]
    2618:      	fmla.4s	v17, v3, v16
    261c:      	ldr	q16, [sp, #0x210]
    2620:      	mov.16b	v15, v16
    2624:      	fmla.4s	v16, v3, v17
    2628:      	mvni.4s	v30, #0x80, lsl #24
    262c:      	mov.16b	v14, v18
    2630:      	mov.16b	v17, v18
    2634:      	fmla.4s	v17, v3, v16
    2638:      	movi.4s	v16, #0x3f, lsl #24
    263c:      	fmla.4s	v16, v3, v17
    2640:      	mov.16b	v17, v19
    2644:      	fmla.4s	v17, v3, v16
    2648:      	fdiv.4s	v3, v4, v17
    264c:      	ldr	q4, [sp, #0x1e0]
    2650:      	fcmge.4s	v4, v4, v2
    2654:      	and.16b	v16, v4, v2
    2658:      	fcmge.4s	v17, v16, v12
    265c:      	fcmge.4s	v18, v27, v16
    2660:      	and.16b	v17, v17, v18
    2664:      	and.16b	v17, v17, v16
    2668:      	fmul.4s	v18, v17, v6
    266c:      	fadd.4s	v18, v18, v21
    2670:      	movi.4s	v21, #0xcb, lsl #24
    2674:      	fadd.4s	v18, v18, v21
    2678:      	fcvtzs.4s	v18, v18
    267c:      	scvtf.4s	v21, v18
    2680:      	fmul.4s	v22, v21, v24
    2684:      	fadd.4s	v17, v17, v22
    2688:      	ldr	q22, [sp, #0x150]
    268c:      	fmul.4s	v21, v21, v22
    2690:      	fadd.4s	v17, v17, v21
    2694:      	ldp	q22, q21, [sp, #0x130]
    2698:      	fmul.4s	v21, v17, v21
    269c:      	fadd.4s	v21, v21, v22
    26a0:      	fmul.4s	v21, v17, v21
    26a4:      	ldr	q22, [sp, #0x120]
    26a8:      	fadd.4s	v21, v21, v22
    26ac:      	fmul.4s	v21, v17, v21
    26b0:      	ldr	q22, [sp, #0x240]
    26b4:      	fadd.4s	v21, v21, v22
    26b8:      	fmul.4s	v21, v17, v21
    26bc:      	fadd.4s	v21, v21, v11
    26c0:      	fmul.4s	v21, v17, v21
    26c4:      	fadd.4s	v21, v21, v9
    26c8:      	fmul.4s	v22, v17, v17
    26cc:      	fmul.4s	v21, v22, v21
    26d0:      	fadd.4s	v17, v17, v21
    26d4:      	fadd.4s	v17, v17, v19
    26d8:      	movi.2d	v21, #0xffffffffffffffff
    26dc:      	add.4s	v18, v18, v21
    26e0:      	sshr.4s	v21, v18, #0x1
    26e4:      	shl.4s	v22, v21, #0x17
    26e8:      	add.4s	v22, v22, v19
    26ec:      	fmul.4s	v17, v17, v22
    26f0:      	sub.4s	v18, v18, v21
    26f4:      	shl.4s	v18, v18, #0x17
    26f8:      	add.4s	v18, v18, v19
    26fc:      	fmul.4s	v17, v17, v18
    2700:      	fcmgt.4s	v16, v16, v27
    2704:      	ldr	q11, [sp, #0x200]
    2708:      	bsl.16b	v16, v11, v17
    270c:      	ldr	q17, [sp, #0x260]
    2710:      	fdiv.4s	v17, v17, v16
    2714:      	fsub.4s	v18, v16, v17
    2718:      	fadd.4s	v16, v16, v17
    271c:      	fdiv.4s	v16, v18, v16
    2720:      	bsl.16b	v4, v16, v19
    2724:      	fcmge.4s	v2, v19, v2
    2728:      	bsl.16b	v2, v3, v4
    272c:      	bif.16b	v2, v1, v30
    2730:      	fcmeq.4s	v1, v1, v1
    2734:      	fadd.4s	v2, v2, v19
    2738:      	ldr	q3, [sp, #0x220]
    273c:      	bsl.16b	v1, v2, v3
    2740:      	ldr	q2, [x4, #0x10]
    2744:      	fmul.4s	v0, v0, v9
    2748:      	fmul.4s	v0, v0, v1
    274c:      	add	x2, x17, x1
    2750:      	ldr	q1, [x2]
    2754:      	and.16b	v1, v5, v1
    2758:      	fadd.4s	v0, v1, v0
    275c:      	ldr	q1, [x2, #0x10]
    2760:      	ldr	q3, [sp, #0xb0]
    2764:      	fmov	w4, s3
    2768:      	add	x1, x11, x1
    276c:      	tbz	w4, #0x0, 0x27a0 <ltmp0+0x27a0>
    2770:      	str	s0, [x1]
    2774:      	and	w4, w4, #0xff
    2778:      	tbnz	w4, #0x1, 0x27a8 <ltmp0+0x27a8>
    277c:      	mov.16b	v5, v14
    2780:      	mov.16b	v21, v15
    2784:      	tbz	w4, #0x2, 0x27bc <ltmp0+0x27bc>
    2788:      	add	x2, x1, #0x8
    278c:      	st1.s	{ v0 }[2], [x2]
    2790:      	mvni.4s	v14, #0x80, lsl #24
    2794:      	ldr	q15, [sp, #0xf0]
    2798:      	tbnz	w4, #0x3, 0x27c8 <ltmp0+0x27c8>
    279c:      	b	0x27d0 <ltmp0+0x27d0>
    27a0:      	and	w4, w4, #0xff
    27a4:      	tbz	w4, #0x1, 0x277c <ltmp0+0x277c>
    27a8:      	add	x2, x1, #0x4
    27ac:      	st1.s	{ v0 }[1], [x2]
    27b0:      	mov.16b	v5, v14
    27b4:      	mov.16b	v21, v15
    27b8:      	tbnz	w4, #0x2, 0x2788 <ltmp0+0x2788>
    27bc:      	mvni.4s	v14, #0x80, lsl #24
    27c0:      	ldr	q15, [sp, #0xf0]
    27c4:      	tbz	w4, #0x3, 0x27d0 <ltmp0+0x27d0>
    27c8:      	add	x2, x1, #0xc
    27cc:      	st1.s	{ v0 }[3], [x2]
    27d0:      	and.16b	v0, v15, v2
    27d4:      	fmul.4s	v2, v0, v25
    27d8:      	fmul.4s	v2, v0, v2
    27dc:      	fmul.4s	v2, v0, v2
    27e0:      	fadd.4s	v2, v0, v2
    27e4:      	fmul.4s	v2, v2, v26
    27e8:      	and.16b	v2, v15, v2
    27ec:      	fabs.4s	v3, v2
    27f0:      	fmul.4s	v4, v2, v2
    27f4:      	mov.16b	v16, v31
    27f8:      	fmla.4s	v16, v4, v29
    27fc:      	mov.16b	v17, v8
    2800:      	fmla.4s	v17, v4, v16
    2804:      	ldr	q16, [sp, #0x250]
    2808:      	fmla.4s	v16, v4, v17
    280c:      	mov.16b	v17, v20
    2810:      	fmla.4s	v17, v4, v16
    2814:      	ldr	q30, [sp, #0x160]
    2818:      	mov.16b	v16, v30
    281c:      	fmla.4s	v16, v4, v17
    2820:      	mov.16b	v17, v19
    2824:      	fmla.4s	v17, v4, v16
    2828:      	fmul.4s	v16, v3, v17
    282c:      	ldp	q17, q18, [sp, #0x290]
    2830:      	fmla.4s	v17, v4, v18
    2834:      	ldr	q18, [sp, #0x270]
    2838:      	fmla.4s	v18, v4, v17
    283c:      	mov.16b	v17, v21
    2840:      	fmla.4s	v17, v4, v18
    2844:      	mov.16b	v18, v5
    2848:      	fmla.4s	v18, v4, v17
    284c:      	movi.4s	v17, #0x3f, lsl #24
    2850:      	fmla.4s	v17, v4, v18
    2854:      	mov.16b	v18, v19
    2858:      	fmla.4s	v18, v4, v17
    285c:      	fdiv.4s	v4, v16, v18
    2860:      	ldr	q16, [sp, #0x1e0]
    2864:      	fcmge.4s	v16, v16, v3
    2868:      	and.16b	v17, v16, v3
    286c:      	fcmge.4s	v18, v17, v12
    2870:      	fcmge.4s	v21, v27, v17
    2874:      	and.16b	v18, v18, v21
    2878:      	and.16b	v18, v18, v17
    287c:      	fmul.4s	v21, v18, v6
    2880:      	movi.4s	v6, #0x4b, lsl #24
    2884:      	fadd.4s	v21, v21, v6
    2888:      	movi.4s	v6, #0xcb, lsl #24
    288c:      	fadd.4s	v21, v21, v6
    2890:      	fcvtzs.4s	v21, v21
    2894:      	scvtf.4s	v22, v21
    2898:      	fmul.4s	v24, v22, v24
    289c:      	fadd.4s	v18, v18, v24
    28a0:      	ldr	q6, [sp, #0x150]
    28a4:      	fmul.4s	v22, v22, v6
    28a8:      	fadd.4s	v18, v18, v22
    28ac:      	ldr	q6, [sp, #0x140]
    28b0:      	fmul.4s	v22, v18, v6
    28b4:      	ldr	q6, [sp, #0x130]
    28b8:      	fadd.4s	v22, v22, v6
    28bc:      	fmul.4s	v22, v18, v22
    28c0:      	ldr	q6, [sp, #0x120]
    28c4:      	fadd.4s	v22, v22, v6
    28c8:      	fmul.4s	v22, v18, v22
    28cc:      	ldr	q6, [sp, #0x240]
    28d0:      	fadd.4s	v22, v22, v6
    28d4:      	fmul.4s	v22, v18, v22
    28d8:      	fadd.4s	v22, v22, v30
    28dc:      	fmul.4s	v22, v18, v22
    28e0:      	fadd.4s	v22, v22, v9
    28e4:      	fmul.4s	v24, v18, v18
    28e8:      	fmul.4s	v22, v24, v22
    28ec:      	fadd.4s	v18, v18, v22
    28f0:      	fadd.4s	v18, v18, v19
    28f4:      	movi.2d	v6, #0xffffffffffffffff
    28f8:      	add.4s	v21, v21, v6
    28fc:      	sshr.4s	v22, v21, #0x1
    2900:      	shl.4s	v24, v22, #0x17
    2904:      	add.4s	v24, v24, v19
    2908:      	fmul.4s	v18, v18, v24
    290c:      	sub.4s	v21, v21, v22
    2910:      	shl.4s	v21, v21, #0x17
    2914:      	add.4s	v21, v21, v19
    2918:      	fmul.4s	v18, v18, v21
    291c:      	fcmgt.4s	v17, v17, v27
    2920:      	bsl.16b	v17, v11, v18
    2924:      	ldr	q6, [sp, #0x260]
    2928:      	fdiv.4s	v18, v6, v17
    292c:      	fsub.4s	v21, v17, v18
    2930:      	fadd.4s	v17, v17, v18
    2934:      	fdiv.4s	v17, v21, v17
    2938:      	bsl.16b	v16, v17, v19
    293c:      	fcmge.4s	v3, v19, v3
    2940:      	bsl.16b	v3, v4, v16
    2944:      	bif.16b	v3, v2, v14
    2948:      	fcmeq.4s	v2, v2, v2
    294c:      	fadd.4s	v3, v3, v19
    2950:      	ldr	q22, [sp, #0x220]
    2954:      	bsl.16b	v2, v3, v22
    2958:      	fmul.4s	v0, v0, v9
    295c:      	fmul.4s	v0, v0, v2
    2960:      	and.16b	v1, v15, v1
    2964:      	fadd.4s	v0, v1, v0
    2968:      	tbz	w4, #0x4, 0x299c <ltmp0+0x299c>
    296c:      	str	s0, [x1, #0x10]
    2970:      	mov.16b	v17, v7
    2974:      	tbnz	w4, #0x5, 0x29a4 <ltmp0+0x29a4>
    2978:      	ldr	q6, [sp, #0x1d0]
    297c:      	ldr	q24, [sp, #0x230]
    2980:      	movi.4s	v21, #0x4b, lsl #24
    2984:      	mov.16b	v15, v20
    2988:      	tbz	w4, #0x6, 0x29c0 <ltmp0+0x29c0>
    298c:      	add	x2, x1, #0x18
    2990:      	st1.s	{ v0 }[2], [x2]
    2994:      	tbz	w4, #0x7, 0x2574 <ltmp0+0x2574>
    2998:      	b	0x29c4 <ltmp0+0x29c4>
    299c:      	mov.16b	v17, v7
    29a0:      	tbz	w4, #0x5, 0x2978 <ltmp0+0x2978>
    29a4:      	add	x2, x1, #0x14
    29a8:      	st1.s	{ v0 }[1], [x2]
    29ac:      	ldr	q6, [sp, #0x1d0]
    29b0:      	ldr	q24, [sp, #0x230]
    29b4:      	movi.4s	v21, #0x4b, lsl #24
    29b8:      	mov.16b	v15, v20
    29bc:      	tbnz	w4, #0x6, 0x298c <ltmp0+0x298c>
    29c0:      	tbz	w4, #0x7, 0x2574 <ltmp0+0x2574>
    29c4:      	add	x1, x1, #0x1c
    29c8:      	st1.s	{ v0 }[3], [x1]
    29cc:      	b	0x2574 <ltmp0+0x2574>
    29d0:      	ldr	q20, [sp, #0x80]
    29d4:      	fmul.4s	v0, v20, v25
    29d8:      	fmul.4s	v0, v20, v0
    29dc:      	fmul.4s	v0, v20, v0
    29e0:      	fadd.4s	v0, v20, v0
    29e4:      	fmul.4s	v0, v0, v26
    29e8:      	ldr	q1, [sp, #0xa0]
    29ec:      	zip1.8b	v1, v1, v0
    29f0:      	ushll.4s	v1, v1, #0x0
    29f4:      	shl.4s	v1, v1, #0x1f
    29f8:      	cmlt.4s	v1, v1, #0
    29fc:      	and.16b	v0, v1, v0
    2a00:      	fabs.4s	v1, v0
    2a04:      	fmul.4s	v2, v0, v0
    2a08:      	mov.16b	v3, v31
    2a0c:      	fmla.4s	v3, v2, v29
    2a10:      	mov.16b	v4, v8
    2a14:      	fmla.4s	v4, v2, v3
    2a18:      	ldr	q3, [sp, #0x250]
    2a1c:      	fmla.4s	v3, v2, v4
    2a20:      	mov.16b	v4, v15
    2a24:      	fmla.4s	v4, v2, v3
    2a28:      	ldr	q10, [sp, #0x160]
    2a2c:      	mov.16b	v3, v10
    2a30:      	fmla.4s	v3, v2, v4
    2a34:      	mov.16b	v4, v19
    2a38:      	fmla.4s	v4, v2, v3
    2a3c:      	fmul.4s	v3, v1, v4
    2a40:      	ldp	q23, q16, [sp, #0x290]
    2a44:      	mov.16b	v4, v23
    2a48:      	fmla.4s	v4, v2, v16
    2a4c:      	ldr	q7, [sp, #0x270]
    2a50:      	mov.16b	v16, v7
    2a54:      	fmla.4s	v16, v2, v4
    2a58:      	ldr	q4, [sp, #0x210]
    2a5c:      	fmla.4s	v4, v2, v16
    2a60:      	mov.16b	v16, v5
    2a64:      	fmla.4s	v16, v2, v4
    2a68:      	movi.4s	v4, #0x3f, lsl #24
    2a6c:      	fmla.4s	v4, v2, v16
    2a70:      	mov.16b	v16, v19
    2a74:      	fmla.4s	v16, v2, v4
    2a78:      	fdiv.4s	v2, v3, v16
    2a7c:      	ldr	q3, [sp, #0x1e0]
    2a80:      	mov.16b	v11, v3
    2a84:      	fcmge.4s	v3, v3, v1
    2a88:      	and.16b	v4, v3, v1
    2a8c:      	fcmge.4s	v16, v4, v12
    2a90:      	fcmge.4s	v17, v27, v4
    2a94:      	and.16b	v16, v16, v17
    2a98:      	and.16b	v16, v16, v4
    2a9c:      	fmul.4s	v17, v16, v6
    2aa0:      	fadd.4s	v17, v17, v21
    2aa4:      	movi.4s	v18, #0xcb, lsl #24
    2aa8:      	fadd.4s	v17, v17, v18
    2aac:      	fcvtzs.4s	v17, v17
    2ab0:      	scvtf.4s	v18, v17
    2ab4:      	fmul.4s	v21, v18, v24
    2ab8:      	fadd.4s	v16, v16, v21
    2abc:      	ldr	q21, [sp, #0x150]
    2ac0:      	fmul.4s	v18, v18, v21
    2ac4:      	fadd.4s	v16, v16, v18
    2ac8:      	ldp	q21, q18, [sp, #0x130]
    2acc:      	fmul.4s	v18, v16, v18
    2ad0:      	fadd.4s	v18, v18, v21
    2ad4:      	fmul.4s	v18, v16, v18
    2ad8:      	ldr	q21, [sp, #0x120]
    2adc:      	fadd.4s	v18, v18, v21
    2ae0:      	fmul.4s	v18, v16, v18
    2ae4:      	ldr	q21, [sp, #0x240]
    2ae8:      	fadd.4s	v18, v18, v21
    2aec:      	fmul.4s	v18, v16, v18
    2af0:      	fadd.4s	v18, v18, v10
    2af4:      	fmul.4s	v18, v16, v18
    2af8:      	fadd.4s	v18, v18, v9
    2afc:      	fmul.4s	v21, v16, v16
    2b00:      	fmul.4s	v18, v21, v18
    2b04:      	fadd.4s	v16, v16, v18
    2b08:      	fadd.4s	v16, v16, v19
    2b0c:      	movi.2d	v18, #0xffffffffffffffff
    2b10:      	add.4s	v17, v17, v18
    2b14:      	sshr.4s	v18, v17, #0x1
    2b18:      	shl.4s	v21, v18, #0x17
    2b1c:      	add.4s	v21, v21, v19
    2b20:      	fmul.4s	v16, v16, v21
    2b24:      	sub.4s	v17, v17, v18
    2b28:      	shl.4s	v17, v17, #0x17
    2b2c:      	add.4s	v17, v17, v19
    2b30:      	fmul.4s	v16, v16, v17
    2b34:      	fcmgt.4s	v4, v4, v27
    2b38:      	ldr	q17, [sp, #0x200]
    2b3c:      	bsl.16b	v4, v17, v16
    2b40:      	ldr	q16, [sp, #0x260]
    2b44:      	fdiv.4s	v16, v16, v4
    2b48:      	fsub.4s	v17, v4, v16
    2b4c:      	fadd.4s	v4, v4, v16
    2b50:      	fdiv.4s	v4, v17, v4
    2b54:      	bsl.16b	v3, v4, v19
    2b58:      	fcmge.4s	v1, v19, v1
    2b5c:      	bsl.16b	v1, v2, v3
    2b60:      	ldr	d2, [sp, #0x18]
    2b64:      	fmov	w11, s2
    2b68:      	bif.16b	v1, v0, v14
    2b6c:      	fcmeq.4s	v0, v0, v0
    2b70:      	fadd.4s	v1, v1, v19
    2b74:      	bsl.16b	v0, v1, v22
    2b78:      	fmul.4s	v1, v20, v9
    2b7c:      	fmul.4s	v0, v1, v0
    2b80:      	ldr	q1, [sp, #0x20]
    2b84:      	fadd.4s	v0, v0, v1
    2b88:      	ldr	q3, [sp, #0x40]
    2b8c:      	ldp	q4, q1, [sp, #0x60]
    2b90:      	stp	q3, q4, [sp, #0x340]
    2b94:      	str	q1, [sp, #0x360]
    2b98:      	ldr	q1, [sp, #0x50]
    2b9c:      	str	q1, [sp, #0x370]
    2ba0:      	and	x1, x25, #0x7
    2ba4:      	add	x2, sp, #0x340
    2ba8:      	ldr	x1, [x2, x1, lsl #3]
    2bac:      	sub	x1, x1, x25
    2bb0:      	add	x1, x23, x1, lsl #2
    2bb4:      	tbz	w11, #0x0, 0x2be0 <ltmp0+0x2be0>
    2bb8:      	str	s0, [x1]
    2bbc:      	tbnz	w11, #0x1, 0x2be4 <ltmp0+0x2be4>
    2bc0:      	movi.4s	v18, #0x4b, lsl #24
    2bc4:      	ldr	q20, [sp, #0x2a0]
    2bc8:      	mov.16b	v17, v11
    2bcc:      	tbz	w11, #0x2, 0x2bfc <ltmp0+0x2bfc>
    2bd0:      	add	x2, x1, #0x8
    2bd4:      	st1.s	{ v0 }[2], [x2]
    2bd8:      	tbnz	w11, #0x3, 0x2c00 <ltmp0+0x2c00>
    2bdc:      	b	0x2c08 <ltmp0+0x2c08>
    2be0:      	tbz	w11, #0x1, 0x2bc0 <ltmp0+0x2bc0>
    2be4:      	add	x2, x1, #0x4
    2be8:      	st1.s	{ v0 }[1], [x2]
    2bec:      	movi.4s	v18, #0x4b, lsl #24
    2bf0:      	ldr	q20, [sp, #0x2a0]
    2bf4:      	mov.16b	v17, v11
    2bf8:      	tbnz	w11, #0x2, 0x2bd0 <ltmp0+0x2bd0>
    2bfc:      	tbz	w11, #0x3, 0x2c08 <ltmp0+0x2c08>
    2c00:      	add	x2, x1, #0xc
    2c04:      	st1.s	{ v0 }[3], [x2]
    2c08:      	ldp	q28, q1, [sp, #0x90]
    2c0c:      	fmul.4s	v0, v28, v25
    2c10:      	fmul.4s	v0, v28, v0
    2c14:      	fmul.4s	v0, v28, v0
    2c18:      	fadd.4s	v0, v28, v0
    2c1c:      	fmul.4s	v0, v0, v26
    2c20:      	zip2.8b	v1, v1, v0
    2c24:      	ushll.4s	v1, v1, #0x0
    2c28:      	shl.4s	v1, v1, #0x1f
    2c2c:      	cmlt.4s	v1, v1, #0
    2c30:      	and.16b	v0, v1, v0
    2c34:      	fabs.4s	v1, v0
    2c38:      	fmul.4s	v2, v0, v0
    2c3c:      	mov.16b	v3, v31
    2c40:      	fmla.4s	v3, v2, v29
    2c44:      	mov.16b	v4, v8
    2c48:      	fmla.4s	v4, v2, v3
    2c4c:      	ldr	q3, [sp, #0x250]
    2c50:      	fmla.4s	v3, v2, v4
    2c54:      	mov.16b	v4, v15
    2c58:      	fmla.4s	v4, v2, v3
    2c5c:      	mov.16b	v3, v10
    2c60:      	fmla.4s	v3, v2, v4
    2c64:      	mov.16b	v4, v19
    2c68:      	fmla.4s	v4, v2, v3
    2c6c:      	fmul.4s	v3, v1, v4
    2c70:      	mov.16b	v4, v23
    2c74:      	fmla.4s	v4, v2, v20
    2c78:      	mov.16b	v16, v7
    2c7c:      	fmla.4s	v16, v2, v4
    2c80:      	ldr	q4, [sp, #0x210]
    2c84:      	fmla.4s	v4, v2, v16
    2c88:      	mov.16b	v16, v5
    2c8c:      	fmla.4s	v16, v2, v4
    2c90:      	movi.4s	v4, #0x3f, lsl #24
    2c94:      	fmla.4s	v4, v2, v16
    2c98:      	mov.16b	v16, v19
    2c9c:      	fmla.4s	v16, v2, v4
    2ca0:      	fdiv.4s	v2, v3, v16
    2ca4:      	fcmge.4s	v3, v17, v1
    2ca8:      	and.16b	v4, v3, v1
    2cac:      	fcmge.4s	v16, v4, v12
    2cb0:      	fcmge.4s	v17, v27, v4
    2cb4:      	and.16b	v16, v16, v17
    2cb8:      	and.16b	v16, v16, v4
    2cbc:      	fmul.4s	v17, v16, v6
    2cc0:      	fadd.4s	v17, v17, v18
    2cc4:      	movi.4s	v18, #0xcb, lsl #24
    2cc8:      	fadd.4s	v17, v17, v18
    2ccc:      	fcvtzs.4s	v17, v17
    2cd0:      	scvtf.4s	v18, v17
    2cd4:      	fmul.4s	v21, v18, v24
    2cd8:      	fadd.4s	v16, v16, v21
    2cdc:      	ldr	q21, [sp, #0x150]
    2ce0:      	fmul.4s	v18, v18, v21
    2ce4:      	fadd.4s	v16, v16, v18
    2ce8:      	ldp	q21, q18, [sp, #0x130]
    2cec:      	fmul.4s	v18, v16, v18
    2cf0:      	fadd.4s	v18, v18, v21
    2cf4:      	fmul.4s	v18, v16, v18
    2cf8:      	ldr	q21, [sp, #0x120]
    2cfc:      	fadd.4s	v18, v18, v21
    2d00:      	fmul.4s	v18, v16, v18
    2d04:      	ldr	q21, [sp, #0x240]
    2d08:      	fadd.4s	v18, v18, v21
    2d0c:      	fmul.4s	v18, v16, v18
    2d10:      	fadd.4s	v18, v18, v10
    2d14:      	fmul.4s	v18, v16, v18
    2d18:      	fadd.4s	v18, v18, v9
    2d1c:      	fmul.4s	v21, v16, v16
    2d20:      	fmul.4s	v18, v21, v18
    2d24:      	fadd.4s	v16, v16, v18
    2d28:      	fadd.4s	v16, v16, v19
    2d2c:      	movi.2d	v18, #0xffffffffffffffff
    2d30:      	add.4s	v17, v17, v18
    2d34:      	sshr.4s	v18, v17, #0x1
    2d38:      	shl.4s	v21, v18, #0x17
    2d3c:      	add.4s	v21, v21, v19
    2d40:      	fmul.4s	v16, v16, v21
    2d44:      	sub.4s	v17, v17, v18
    2d48:      	shl.4s	v17, v17, #0x17
    2d4c:      	add.4s	v17, v17, v19
    2d50:      	fmul.4s	v16, v16, v17
    2d54:      	fcmgt.4s	v4, v4, v27
    2d58:      	ldr	q17, [sp, #0x200]
    2d5c:      	bsl.16b	v4, v17, v16
    2d60:      	ldr	q16, [sp, #0x260]
    2d64:      	fdiv.4s	v16, v16, v4
    2d68:      	fsub.4s	v17, v4, v16
    2d6c:      	fadd.4s	v4, v4, v16
    2d70:      	fdiv.4s	v4, v17, v4
    2d74:      	bsl.16b	v3, v4, v19
    2d78:      	fcmge.4s	v1, v19, v1
    2d7c:      	bsl.16b	v1, v2, v3
    2d80:      	bif.16b	v1, v0, v14
    2d84:      	fcmeq.4s	v0, v0, v0
    2d88:      	fadd.4s	v1, v1, v19
    2d8c:      	bsl.16b	v0, v1, v22
    2d90:      	fmul.4s	v1, v28, v9
    2d94:      	fmul.4s	v0, v1, v0
    2d98:      	ldr	q1, [sp, #0x30]
    2d9c:      	fadd.4s	v0, v0, v1
    2da0:      	tbz	w11, #0x4, 0x2dcc <ltmp0+0x2dcc>
    2da4:      	str	s0, [x1, #0x10]
    2da8:      	tbnz	w11, #0x5, 0x2dd0 <ltmp0+0x2dd0>
    2dac:      	movi.4s	v21, #0x4b, lsl #24
    2db0:      	movi.4s	v18, #0xcb, lsl #24
    2db4:      	mov.16b	v17, v11
    2db8:      	tbz	w11, #0x6, 0x33b0 <ltmp0+0x33b0>
    2dbc:      	add	x2, x1, #0x18
    2dc0:      	st1.s	{ v0 }[2], [x2]
    2dc4:      	tbnz	w11, #0x7, 0x33b4 <ltmp0+0x33b4>
    2dc8:      	b	0x1c0 <ltmp0+0x1c0>
    2dcc:      	tbz	w11, #0x5, 0x2dac <ltmp0+0x2dac>
    2dd0:      	add	x2, x1, #0x14
    2dd4:      	st1.s	{ v0 }[1], [x2]
    2dd8:      	movi.4s	v21, #0x4b, lsl #24
    2ddc:      	movi.4s	v18, #0xcb, lsl #24
    2de0:      	mov.16b	v17, v11
    2de4:      	tbz	w11, #0x6, 0x33b0 <ltmp0+0x33b0>
    2de8:      	b	0x2dbc <ltmp0+0x2dbc>
    2dec:      	ldr	q0, [sp, #0x100]
    2df0:      	xtn.4h	v0, v0
    2df4:      	uzp1.8b	v0, v0, v0
    2df8:      	movi.2d	v16, #0000000000000000
    2dfc:      	mov.b	v16[0], v0[0]
    2e00:      	adrp	x11, 0x2000 <ltmp0+0x2000>
    2e04:      	ldr	d2, [x11]
    2e08:      	and.8b	v1, v16, v2
    2e0c:      	addv.8b	b1, v1
    2e10:      	fmov	w11, s1
    2e14:      	umaxv.8b	b1, v16
    2e18:      	fmov	w2, s1
    2e1c:      	rbit	w4, w11
    2e20:      	clz	w4, w4
    2e24:      	tst	w2, #0x1
    2e28:      	csel	w4, w4, wzr, ne
    2e2c:      	mov	w5, #0x40               ; =64
    2e30:      	dup.2d	v30, x5
    2e34:      	movi.2s	v1, #0x41
    2e38:      	ldr	d3, [sp, #0x50]
    2e3c:      	ldr	q4, [sp, #0x40]
    2e40:      	umlal.2d	v4, v3, v1
    2e44:      	movi.2d	v1, #0000000000000000
    2e48:      	mov.b	v1[0], v0[0]
    2e4c:      	add.2d	v3, v4, v30
    2e50:      	ushll.2d	v0, v1, #0x0
    2e54:      	shl.2d	v0, v0, #0x3f
    2e58:      	cmlt.2d	v0, v0, #0
    2e5c:      	stp	q30, q3, [sp, #0xe0]
    2e60:      	and.16b	v0, v0, v3
    2e64:      	movi.2d	v1, #0000000000000000
    2e68:      	stp	q1, q1, [sp, #0x310]
    2e6c:      	stp	q0, q1, [sp, #0x2f0]
    2e70:      	and	x5, x4, #0x7
    2e74:      	add	x6, sp, #0x2f0
    2e78:      	ldr	x5, [x6, x5, lsl #3]
    2e7c:      	sub	x5, x5, x4
    2e80:      	lsl	x5, x5, #2
    2e84:      	add	x1, x1, x5
    2e88:      	movi.2d	v11, #0000000000000000
    2e8c:      	movi.2d	v0, #0000000000000000
    2e90:      	tbz	w2, #0x0, 0x2ed4 <ltmp0+0x2ed4>
    2e94:      	ldr	s11, [x1]
    2e98:      	ldr	q28, [sp, #0x90]
    2e9c:      	tbnz	w11, #0x1, 0x2edc <ltmp0+0x2edc>
    2ea0:      	tbz	w11, #0x2, 0x2ee8 <ltmp0+0x2ee8>
    2ea4:      	add	x2, x1, #0x8
    2ea8:      	ld1.s	{ v11 }[2], [x2]
    2eac:      	tbnz	w11, #0x3, 0x2eec <ltmp0+0x2eec>
    2eb0:      	tbz	w11, #0x4, 0x2ef8 <ltmp0+0x2ef8>
    2eb4:      	add	x2, x1, #0x10
    2eb8:      	ld1.s	{ v0 }[0], [x2]
    2ebc:      	tbnz	w11, #0x5, 0x2efc <ltmp0+0x2efc>
    2ec0:      	tbz	w11, #0x6, 0x2f08 <ltmp0+0x2f08>
    2ec4:      	add	x2, x1, #0x18
    2ec8:      	ld1.s	{ v0 }[2], [x2]
    2ecc:      	tbnz	w11, #0x7, 0x2f0c <ltmp0+0x2f0c>
    2ed0:      	b	0x2f14 <ltmp0+0x2f14>
    2ed4:      	ldr	q28, [sp, #0x90]
    2ed8:      	tbz	w11, #0x1, 0x2ea0 <ltmp0+0x2ea0>
    2edc:      	add	x2, x1, #0x4
    2ee0:      	ld1.s	{ v11 }[1], [x2]
    2ee4:      	tbnz	w11, #0x2, 0x2ea4 <ltmp0+0x2ea4>
    2ee8:      	tbz	w11, #0x3, 0x2eb0 <ltmp0+0x2eb0>
    2eec:      	add	x2, x1, #0xc
    2ef0:      	ld1.s	{ v11 }[3], [x2]
    2ef4:      	tbnz	w11, #0x4, 0x2eb4 <ltmp0+0x2eb4>
    2ef8:      	tbz	w11, #0x5, 0x2ec0 <ltmp0+0x2ec0>
    2efc:      	add	x2, x1, #0x14
    2f00:      	ld1.s	{ v0 }[1], [x2]
    2f04:      	tbnz	w11, #0x6, 0x2ec4 <ltmp0+0x2ec4>
    2f08:      	tbz	w11, #0x7, 0x2f14 <ltmp0+0x2f14>
    2f0c:      	add	x11, x1, #0x1c
    2f10:      	ld1.s	{ v0 }[3], [x11]
    2f14:      	str	q0, [sp, #0x100]
    2f18:      	shl.8b	v0, v16, #0x7
    2f1c:      	cmlt.8b	v0, v0, #0
    2f20:      	and.8b	v0, v0, v2
    2f24:      	addv.8b	b0, v0
    2f28:      	str	d0, [sp, #0xa0]
    2f2c:      	fmov	w1, s0
    2f30:      	add	x11, x24, x5
    2f34:      	movi.2d	v13, #0000000000000000
    2f38:      	movi.2d	v3, #0000000000000000
    2f3c:      	tbz	w1, #0x0, 0x31a4 <ltmp0+0x31a4>
    2f40:      	ldr	s13, [x11]
    2f44:      	tbnz	w1, #0x1, 0x31a8 <ltmp0+0x31a8>
    2f48:      	tbz	w1, #0x2, 0x31b4 <ltmp0+0x31b4>
    2f4c:      	add	x2, x11, #0x8
    2f50:      	ld1.s	{ v13 }[2], [x2]
    2f54:      	tbnz	w1, #0x3, 0x31b8 <ltmp0+0x31b8>
    2f58:      	tbz	w1, #0x4, 0x31c4 <ltmp0+0x31c4>
    2f5c:      	add	x2, x11, #0x10
    2f60:      	ld1.s	{ v3 }[0], [x2]
    2f64:      	tbnz	w1, #0x5, 0x31c8 <ltmp0+0x31c8>
    2f68:      	tbz	w1, #0x6, 0x2f74 <ltmp0+0x2f74>
    2f6c:      	add	x2, x11, #0x18
    2f70:      	ld1.s	{ v3 }[2], [x2]
    2f74:      	movi.2s	v0, #0x41
    2f78:      	ldr	q1, [sp, #0xd0]
    2f7c:      	ldr	d2, [sp, #0x60]
    2f80:      	umlal.2d	v1, v2, v0
    2f84:      	str	q1, [sp, #0xd0]
    2f88:      	ldr	d1, [sp, #0x70]
    2f8c:      	umlal.2d	v28, v1, v0
    2f90:      	ldr	q1, [sp, #0xc0]
    2f94:      	ldr	d2, [sp, #0x80]
    2f98:      	umlal.2d	v1, v2, v0
    2f9c:      	str	q1, [sp, #0xc0]
    2fa0:      	tbz	w1, #0x7, 0x2fac <ltmp0+0x2fac>
    2fa4:      	add	x11, x11, #0x1c
    2fa8:      	ld1.s	{ v3 }[3], [x11]
    2fac:      	str	q3, [sp, #0xb0]
    2fb0:      	fmul.4s	v0, v11, v25
    2fb4:      	fmul.4s	v0, v11, v0
    2fb8:      	fmul.4s	v0, v11, v0
    2fbc:      	fadd.4s	v0, v11, v0
    2fc0:      	fmul.4s	v0, v0, v26
    2fc4:      	mov.16b	v30, v16
    2fc8:      	zip1.8b	v1, v16, v0
    2fcc:      	ushll.4s	v1, v1, #0x0
    2fd0:      	shl.4s	v1, v1, #0x1f
    2fd4:      	cmlt.4s	v1, v1, #0
    2fd8:      	and.16b	v0, v1, v0
    2fdc:      	fabs.4s	v1, v0
    2fe0:      	fmul.4s	v2, v0, v0
    2fe4:      	mov.16b	v3, v31
    2fe8:      	fmla.4s	v3, v2, v29
    2fec:      	mov.16b	v4, v8
    2ff0:      	fmla.4s	v4, v2, v3
    2ff4:      	ldr	q3, [sp, #0x250]
    2ff8:      	fmla.4s	v3, v2, v4
    2ffc:      	mov.16b	v4, v15
    3000:      	fmla.4s	v4, v2, v3
    3004:      	mov.16b	v3, v10
    3008:      	fmla.4s	v3, v2, v4
    300c:      	mov.16b	v4, v19
    3010:      	fmla.4s	v4, v2, v3
    3014:      	fmul.4s	v3, v1, v4
    3018:      	mov.16b	v4, v23
    301c:      	fmla.4s	v4, v2, v20
    3020:      	mov.16b	v16, v7
    3024:      	fmla.4s	v16, v2, v4
    3028:      	ldr	q4, [sp, #0x210]
    302c:      	fmla.4s	v4, v2, v16
    3030:      	mov.16b	v16, v5
    3034:      	fmla.4s	v16, v2, v4
    3038:      	movi.4s	v4, #0x3f, lsl #24
    303c:      	fmla.4s	v4, v2, v16
    3040:      	mov.16b	v16, v19
    3044:      	fmla.4s	v16, v2, v4
    3048:      	fdiv.4s	v2, v3, v16
    304c:      	fcmge.4s	v3, v17, v1
    3050:      	and.16b	v4, v3, v1
    3054:      	fcmge.4s	v16, v4, v12
    3058:      	fcmge.4s	v17, v27, v4
    305c:      	and.16b	v16, v16, v17
    3060:      	and.16b	v16, v16, v4
    3064:      	fmul.4s	v17, v16, v6
    3068:      	fadd.4s	v17, v17, v21
    306c:      	fadd.4s	v17, v17, v18
    3070:      	fcvtzs.4s	v17, v17
    3074:      	scvtf.4s	v18, v17
    3078:      	fmul.4s	v21, v18, v24
    307c:      	fadd.4s	v16, v16, v21
    3080:      	ldr	q21, [sp, #0x150]
    3084:      	fmul.4s	v18, v18, v21
    3088:      	fadd.4s	v16, v16, v18
    308c:      	ldp	q21, q18, [sp, #0x130]
    3090:      	fmul.4s	v18, v16, v18
    3094:      	fadd.4s	v18, v18, v21
    3098:      	fmul.4s	v18, v16, v18
    309c:      	ldr	q21, [sp, #0x120]
    30a0:      	fadd.4s	v18, v18, v21
    30a4:      	fmul.4s	v18, v16, v18
    30a8:      	ldr	q21, [sp, #0x240]
    30ac:      	fadd.4s	v18, v18, v21
    30b0:      	fmul.4s	v18, v16, v18
    30b4:      	fadd.4s	v18, v18, v10
    30b8:      	fmul.4s	v18, v16, v18
    30bc:      	fadd.4s	v18, v18, v9
    30c0:      	fmul.4s	v21, v16, v16
    30c4:      	fmul.4s	v18, v21, v18
    30c8:      	fadd.4s	v16, v16, v18
    30cc:      	fadd.4s	v16, v16, v19
    30d0:      	movi.2d	v18, #0xffffffffffffffff
    30d4:      	add.4s	v17, v17, v18
    30d8:      	sshr.4s	v18, v17, #0x1
    30dc:      	shl.4s	v21, v18, #0x17
    30e0:      	add.4s	v21, v21, v19
    30e4:      	fmul.4s	v16, v16, v21
    30e8:      	sub.4s	v17, v17, v18
    30ec:      	shl.4s	v17, v17, #0x17
    30f0:      	add.4s	v17, v17, v19
    30f4:      	fmul.4s	v16, v16, v17
    30f8:      	fcmgt.4s	v4, v4, v27
    30fc:      	ldr	q17, [sp, #0x200]
    3100:      	bsl.16b	v4, v17, v16
    3104:      	ldr	q16, [sp, #0x260]
    3108:      	fdiv.4s	v16, v16, v4
    310c:      	fsub.4s	v17, v4, v16
    3110:      	fadd.4s	v4, v4, v16
    3114:      	fdiv.4s	v4, v17, v4
    3118:      	bsl.16b	v3, v4, v19
    311c:      	fcmge.4s	v1, v19, v1
    3120:      	bsl.16b	v1, v2, v3
    3124:      	ldp	q2, q16, [sp, #0xd0]
    3128:      	add.2d	v2, v2, v16
    312c:      	add.2d	v3, v28, v16
    3130:      	ldr	q4, [sp, #0xc0]
    3134:      	add.2d	v4, v4, v16
    3138:      	bif.16b	v1, v0, v14
    313c:      	fcmeq.4s	v0, v0, v0
    3140:      	fadd.4s	v1, v1, v19
    3144:      	bsl.16b	v0, v1, v22
    3148:      	fmul.4s	v1, v11, v9
    314c:      	fmul.4s	v0, v1, v0
    3150:      	fadd.4s	v0, v13, v0
    3154:      	ldr	q1, [sp, #0xf0]
    3158:      	stp	q1, q2, [sp, #0x2b0]
    315c:      	stp	q3, q4, [sp, #0x2d0]
    3160:      	ldr	d1, [sp, #0xa0]
    3164:      	fmov	w11, s1
    3168:      	and	x1, x4, #0x7
    316c:      	add	x2, sp, #0x2b0
    3170:      	ldr	x1, [x2, x1, lsl #3]
    3174:      	sub	x1, x1, x4
    3178:      	add	x1, x23, x1, lsl #2
    317c:      	tbz	w11, #0x0, 0x31d8 <ltmp0+0x31d8>
    3180:      	str	s0, [x1]
    3184:      	tbnz	w11, #0x1, 0x31dc <ltmp0+0x31dc>
    3188:      	movi.4s	v18, #0x4b, lsl #24
    318c:      	ldr	q17, [sp, #0x1e0]
    3190:      	tbz	w11, #0x2, 0x31f0 <ltmp0+0x31f0>
    3194:      	add	x2, x1, #0x8
    3198:      	st1.s	{ v0 }[2], [x2]
    319c:      	tbnz	w11, #0x3, 0x31f4 <ltmp0+0x31f4>
    31a0:      	b	0x31fc <ltmp0+0x31fc>
    31a4:      	tbz	w1, #0x1, 0x2f48 <ltmp0+0x2f48>
    31a8:      	add	x2, x11, #0x4
    31ac:      	ld1.s	{ v13 }[1], [x2]
    31b0:      	tbnz	w1, #0x2, 0x2f4c <ltmp0+0x2f4c>
    31b4:      	tbz	w1, #0x3, 0x2f58 <ltmp0+0x2f58>
    31b8:      	add	x2, x11, #0xc
    31bc:      	ld1.s	{ v13 }[3], [x2]
    31c0:      	tbnz	w1, #0x4, 0x2f5c <ltmp0+0x2f5c>
    31c4:      	tbz	w1, #0x5, 0x2f68 <ltmp0+0x2f68>
    31c8:      	add	x2, x11, #0x14
    31cc:      	ld1.s	{ v3 }[1], [x2]
    31d0:      	tbnz	w1, #0x6, 0x2f6c <ltmp0+0x2f6c>
    31d4:      	b	0x2f74 <ltmp0+0x2f74>
    31d8:      	tbz	w11, #0x1, 0x3188 <ltmp0+0x3188>
    31dc:      	add	x2, x1, #0x4
    31e0:      	st1.s	{ v0 }[1], [x2]
    31e4:      	movi.4s	v18, #0x4b, lsl #24
    31e8:      	ldr	q17, [sp, #0x1e0]
    31ec:      	tbnz	w11, #0x2, 0x3194 <ltmp0+0x3194>
    31f0:      	tbz	w11, #0x3, 0x31fc <ltmp0+0x31fc>
    31f4:      	add	x2, x1, #0xc
    31f8:      	st1.s	{ v0 }[3], [x2]
    31fc:      	ldr	q28, [sp, #0x100]
    3200:      	fmul.4s	v0, v28, v25
    3204:      	fmul.4s	v0, v28, v0
    3208:      	fmul.4s	v0, v28, v0
    320c:      	fadd.4s	v0, v28, v0
    3210:      	fmul.4s	v0, v0, v26
    3214:      	zip2.8b	v1, v30, v0
    3218:      	ushll.4s	v1, v1, #0x0
    321c:      	shl.4s	v1, v1, #0x1f
    3220:      	cmlt.4s	v1, v1, #0
    3224:      	and.16b	v0, v1, v0
    3228:      	fabs.4s	v1, v0
    322c:      	fmul.4s	v2, v0, v0
    3230:      	mov.16b	v3, v31
    3234:      	fmla.4s	v3, v2, v29
    3238:      	mov.16b	v4, v8
    323c:      	fmla.4s	v4, v2, v3
    3240:      	ldr	q3, [sp, #0x250]
    3244:      	fmla.4s	v3, v2, v4
    3248:      	mov.16b	v4, v15
    324c:      	fmla.4s	v4, v2, v3
    3250:      	mov.16b	v3, v10
    3254:      	fmla.4s	v3, v2, v4
    3258:      	mov.16b	v4, v19
    325c:      	fmla.4s	v4, v2, v3
    3260:      	fmul.4s	v3, v1, v4
    3264:      	mov.16b	v4, v23
    3268:      	fmla.4s	v4, v2, v20
    326c:      	mov.16b	v16, v7
    3270:      	fmla.4s	v16, v2, v4
    3274:      	ldr	q4, [sp, #0x210]
    3278:      	fmla.4s	v4, v2, v16
    327c:      	mov.16b	v16, v5
    3280:      	fmla.4s	v16, v2, v4
    3284:      	movi.4s	v4, #0x3f, lsl #24
    3288:      	fmla.4s	v4, v2, v16
    328c:      	mov.16b	v16, v19
    3290:      	fmla.4s	v16, v2, v4
    3294:      	fdiv.4s	v2, v3, v16
    3298:      	fcmge.4s	v3, v17, v1
    329c:      	and.16b	v4, v3, v1
    32a0:      	fcmge.4s	v16, v4, v12
    32a4:      	fcmge.4s	v17, v27, v4
    32a8:      	and.16b	v16, v16, v17
    32ac:      	and.16b	v16, v16, v4
    32b0:      	fmul.4s	v17, v16, v6
    32b4:      	fadd.4s	v17, v17, v18
    32b8:      	movi.4s	v18, #0xcb, lsl #24
    32bc:      	fadd.4s	v17, v17, v18
    32c0:      	fcvtzs.4s	v17, v17
    32c4:      	scvtf.4s	v18, v17
    32c8:      	fmul.4s	v21, v18, v24
    32cc:      	fadd.4s	v16, v16, v21
    32d0:      	ldr	q21, [sp, #0x150]
    32d4:      	fmul.4s	v18, v18, v21
    32d8:      	fadd.4s	v16, v16, v18
    32dc:      	ldp	q21, q18, [sp, #0x130]
    32e0:      	fmul.4s	v18, v16, v18
    32e4:      	fadd.4s	v18, v18, v21
    32e8:      	fmul.4s	v18, v16, v18
    32ec:      	ldr	q21, [sp, #0x120]
    32f0:      	fadd.4s	v18, v18, v21
    32f4:      	fmul.4s	v18, v16, v18
    32f8:      	ldr	q21, [sp, #0x240]
    32fc:      	fadd.4s	v18, v18, v21
    3300:      	fmul.4s	v18, v16, v18
    3304:      	fadd.4s	v18, v18, v10
    3308:      	fmul.4s	v18, v16, v18
    330c:      	fadd.4s	v18, v18, v9
    3310:      	fmul.4s	v21, v16, v16
    3314:      	fmul.4s	v18, v21, v18
    3318:      	fadd.4s	v16, v16, v18
    331c:      	fadd.4s	v16, v16, v19
    3320:      	movi.2d	v18, #0xffffffffffffffff
    3324:      	add.4s	v17, v17, v18
    3328:      	sshr.4s	v18, v17, #0x1
    332c:      	shl.4s	v21, v18, #0x17
    3330:      	add.4s	v21, v21, v19
    3334:      	fmul.4s	v16, v16, v21
    3338:      	sub.4s	v17, v17, v18
    333c:      	shl.4s	v17, v17, #0x17
    3340:      	add.4s	v17, v17, v19
    3344:      	fmul.4s	v16, v16, v17
    3348:      	fcmgt.4s	v4, v4, v27
    334c:      	ldr	q17, [sp, #0x200]
    3350:      	bsl.16b	v4, v17, v16
    3354:      	ldr	q16, [sp, #0x260]
    3358:      	fdiv.4s	v16, v16, v4
    335c:      	fsub.4s	v17, v4, v16
    3360:      	fadd.4s	v4, v4, v16
    3364:      	fdiv.4s	v4, v17, v4
    3368:      	bsl.16b	v3, v4, v19
    336c:      	fcmge.4s	v1, v19, v1
    3370:      	bsl.16b	v1, v2, v3
    3374:      	bif.16b	v1, v0, v14
    3378:      	fcmeq.4s	v0, v0, v0
    337c:      	fadd.4s	v1, v1, v19
    3380:      	bsl.16b	v0, v1, v22
    3384:      	fmul.4s	v1, v28, v9
    3388:      	fmul.4s	v0, v1, v0
    338c:      	ldr	q1, [sp, #0xb0]
    3390:      	fadd.4s	v0, v1, v0
    3394:      	tbz	w11, #0x4, 0x33c0 <ltmp0+0x33c0>
    3398:      	str	s0, [x1, #0x10]
    339c:      	tbnz	w11, #0x5, 0x33c4 <ltmp0+0x33c4>
    33a0:      	movi.4s	v21, #0x4b, lsl #24
    33a4:      	movi.4s	v18, #0xcb, lsl #24
    33a8:      	ldr	q17, [sp, #0x1e0]
    33ac:      	tbnz	w11, #0x6, 0x2dbc <ltmp0+0x2dbc>
    33b0:      	tbz	w11, #0x7, 0x1c0 <ltmp0+0x1c0>
    33b4:      	add	x11, x1, #0x1c
    33b8:      	st1.s	{ v0 }[3], [x11]
    33bc:      	b	0x1c0 <ltmp0+0x1c0>
    33c0:      	tbz	w11, #0x5, 0x33a0 <ltmp0+0x33a0>
    33c4:      	add	x2, x1, #0x14
    33c8:      	st1.s	{ v0 }[1], [x2]
    33cc:      	movi.4s	v21, #0x4b, lsl #24
    33d0:      	movi.4s	v18, #0xcb, lsl #24
    33d4:      	ldr	q17, [sp, #0x1e0]
    33d8:      	tbz	w11, #0x6, 0x33b0 <ltmp0+0x33b0>
    33dc:      	b	0x2dbc <ltmp0+0x2dbc>
    33e0:      	ldr	x9, [sp, #0x10]
    33e4:      	stp	w30, w28, [x9]
    33e8:      	str	w27, [x9, #0x8]
    33ec:      	mov	w8, #0x18               ; =24
    33f0:      	str	w8, [x9, #0x24]
    33f4:      	add	sp, sp, #0x660
    33f8:      	ldp	x29, x30, [sp, #0x90]
    33fc:      	ldp	x20, x19, [sp, #0x80]
    3400:      	ldp	x22, x21, [sp, #0x70]
    3404:      	ldp	x24, x23, [sp, #0x60]
    3408:      	ldp	x26, x25, [sp, #0x50]
    340c:      	ldp	x28, x27, [sp, #0x40]
    3410:      	ldp	d9, d8, [sp, #0x30]
    3414:      	ldp	d11, d10, [sp, #0x20]
    3418:      	ldp	d13, d12, [sp, #0x10]
    341c:      	ldp	d15, d14, [sp], #0xa0
    3420:      	ret

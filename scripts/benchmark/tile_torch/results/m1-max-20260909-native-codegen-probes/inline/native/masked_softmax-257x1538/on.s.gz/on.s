
/private/tmp/luisa-packet-inline.UY1lIE/capture/masked_softmax-257x1538/on/object/tile_xir_w8_36373_1788935098186075_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      2c:      	sub	sp, sp, #0x920
      30:      	str	x0, [sp, #0x180]
      34:      	str	w3, [sp, #0x198]
      38:      	cbz	w3, 0x30c0 <ltmp0+0x30c0>
      3c:      	mov	w12, #0x0               ; =0
      40:      	add	x23, sp, #0xa78
      44:      	add	x8, sp, #0x3, lsl #12   ; =0x3000
      48:      	add	x8, x8, #0xab8
      4c:      	dup.2d	v1, x8
      50:      	adrp	x8, 0x0 <ltmp0>
      54:      	ldr	q0, [x8]
      58:      	mov	w0, #0x1808             ; =6152
      5c:      	str	q1, [sp, #0x2b0]
      60:      	add.2d	v0, v1, v0
      64:      	str	q0, [sp, #0x3b0]
      68:      	add	x28, sp, #0x7, lsl #12  ; =0x7000
      6c:      	add	x28, x28, #0x100
      70:      	adrp	x8, 0x0 <ltmp0>
      74:      	ldr	q0, [x8]
      78:      	str	q0, [sp, #0x2a0]
      7c:      	add	x19, sp, #0x4, lsl #12  ; =0x4000
      80:      	add	x19, x19, #0xc0
      84:      	adrp	x8, 0x0 <ltmp0>
      88:      	ldr	q0, [x8]
      8c:      	str	q0, [sp, #0x290]
      90:      	mov	w25, #0x1               ; =1
      94:      	adrp	x8, 0x0 <ltmp0>
      98:      	ldr	q0, [x8]
      9c:      	str	q0, [sp, #0x280]
      a0:      	adrp	x8, 0x0 <ltmp0>
      a4:      	ldr	q0, [x8]
      a8:      	str	q0, [sp, #0x270]
      ac:      	adrp	x22, 0x0 <ltmp0>
      b0:      	adrp	x3, 0x0 <ltmp0>
      b4:      	adrp	x27, 0x0 <ltmp0>
      b8:      	dup.2d	v0, x25
      bc:      	str	q0, [sp, #0x210]
      c0:      	adrp	x24, 0x0 <ltmp0>
      c4:      	adrp	x8, 0x0 <ltmp0>
      c8:      	ldr	q1, [x8]
      cc:      	movi.8b	v8, #0x1
      d0:      	add	x20, sp, #0x2, lsl #12  ; =0x2000
      d4:      	add	x20, x20, #0x298
      d8:      	mvni.4s	v0, #0x7f, msl #16
      dc:      	fneg.4s	v0, v0
      e0:      	stp	q1, q0, [sp, #0x250]
      e4:      	mvni.4s	v0, #0x3f, msl #16
      e8:      	fneg.4s	v0, v0
      ec:      	str	q0, [sp, #0x3c0]
      f0:      	ldp	w9, w8, [x2, #0x2c]
      f4:      	str	w9, [sp, #0x194]
      f8:      	str	w8, [sp, #0x190]
      fc:      	ldp	w8, w9, [x2]
     100:      	ldp	w10, w11, [x2, #0x8]
     104:      	str	x2, [sp, #0x8]
     108:      	str	x11, [sp, #0x188]
     10c:      	b	0x160 <ltmp0+0x160>
     110:      	ldr	x15, [sp, #0x1a8]
     114:      	add	w8, w15, #0x1
     118:      	ldr	w9, [sp, #0x194]
     11c:      	cmp	w8, w9
     120:      	cset	w9, eq
     124:      	csinc	w8, wzr, w15, eq
     128:      	ldr	w14, [sp, #0x19c]
     12c:      	cinc	w10, w14, eq
     130:      	ldr	w11, [sp, #0x190]
     134:      	cmp	w10, w11
     138:      	cset	w11, eq
     13c:      	ands	w11, w9, w11
     140:      	csel	w9, wzr, w10, ne
     144:      	ldr	w13, [sp, #0x1a0]
     148:      	add	w10, w13, w11
     14c:      	ldr	w12, [sp, #0x1a4]
     150:      	add	w12, w12, #0x1
     154:      	ldr	w11, [sp, #0x198]
     158:      	cmp	w12, w11
     15c:      	b.eq	0x30ac <ltmp0+0x30ac>
     160:      	str	w12, [sp, #0x1a4]
     164:      	mov	x13, x10
     168:      	mov	x14, x9
     16c:      	mov	x15, x8
     170:      	ubfiz	x8, x8, #5, #32
     174:      	ldr	x12, [sp, #0x188]
     178:      	cmp	x8, x12
     17c:      	csel	x9, x8, xzr, ls
     180:      	subs	x10, x12, x9
     184:      	cmp	x10, #0x20
     188:      	mov	w11, #0x20              ; =32
     18c:      	csel	x10, x10, x11, lo
     190:      	cmp	x12, x9
     194:      	ccmp	x8, x12, #0x2, hi
     198:      	csel	x9, x10, xzr, ls
     19c:      	mov	w8, #0xf2ca             ; =62154
     1a0:      	movk	w8, #0xf149, lsl #16
     1a4:      	dup.4s	v0, w8
     1a8:      	str	q0, [sp, #0x2c0]
     1ac:      	mov	w8, #-0x3d300000        ; =-1026555904
     1b0:      	dup.4s	v1, w8
     1b4:      	mov	w8, #0x42c80000         ; =1120403456
     1b8:      	dup.4s	v0, w8
     1bc:      	stp	q1, q0, [sp, #0x2e0]
     1c0:      	mov	w8, #0xaa3b             ; =43579
     1c4:      	movk	w8, #0x3fb8, lsl #16
     1c8:      	dup.4s	v1, w8
     1cc:      	mov	w8, #0x7200             ; =29184
     1d0:      	movk	w8, #0xbf31, lsl #16
     1d4:      	dup.4s	v0, w8
     1d8:      	stp	q1, q0, [sp, #0x300]
     1dc:      	mov	w8, #0xbe8e             ; =48782
     1e0:      	movk	w8, #0xb5bf, lsl #16
     1e4:      	dup.4s	v1, w8
     1e8:      	mov	w8, #0x2bda             ; =11226
     1ec:      	movk	w8, #0x3950, lsl #16
     1f0:      	dup.4s	v0, w8
     1f4:      	stp	q1, q0, [sp, #0x320]
     1f8:      	mov	w8, #0x96c9             ; =38601
     1fc:      	movk	w8, #0x3ab6, lsl #16
     200:      	dup.4s	v1, w8
     204:      	mov	w8, #0x88a6             ; =34982
     208:      	movk	w8, #0x3c08, lsl #16
     20c:      	dup.4s	v0, w8
     210:      	stp	q1, q0, [sp, #0x340]
     214:      	mov	w8, #0xaa7a             ; =43642
     218:      	movk	w8, #0x3d2a, lsl #16
     21c:      	dup.4s	v0, w8
     220:      	str	q0, [sp, #0x360]
     224:      	mov	w8, #0xaaab             ; =43691
     228:      	movk	w8, #0x3e2a, lsl #16
     22c:      	dup.4s	v0, w8
     230:      	str	q0, [sp, #0x3d0]
     234:      	fmov.4s	v0, #1.00000000
     238:      	str	q0, [sp, #0x2d0]
     23c:      	cmp	x9, #0x20
     240:      	str	w13, [sp, #0x1a0]
     244:      	str	w14, [sp, #0x19c]
     248:      	str	x15, [sp, #0x1a8]
     24c:      	b.lo	0xa70 <ltmp0+0xa70>
     250:      	mov	x26, #0x0               ; =0
     254:      	ldr	x8, [sp, #0x180]
     258:      	ldr	x9, [x8]
     25c:      	str	x9, [sp, #0x240]
     260:      	ldr	x10, [x8, #0x30]
     264:      	lsl	w8, w15, #2
     268:      	str	x8, [sp, #0x220]
     26c:      	and	x8, x15, #0x7ffffff
     270:      	mov	w9, #0x6020             ; =24608
     274:      	str	x10, [sp, #0x230]
     278:      	umaddl	x21, w8, w9, x10
     27c:      	str	q0, [sp, #0x3a0]
     280:      	ldr	x8, [sp, #0x220]
     284:      	add	w8, w26, w8
     288:      	and	x22, x8, #0x1fffffff
     28c:      	ldr	x28, [sp, #0x240]
     290:      	umaddl	x1, w22, w0, x28
     294:      	add	x0, sp, #0x7, lsl #12   ; =0x7000
     298:      	add	x0, x0, #0x100
     29c:      	mov	w2, #0x1800             ; =6144
     2a0:      	bl	0x2a0 <ltmp0+0x2a0>
     2a4:      	ldr	q21, [sp, #0x210]
     2a8:      	mov	w0, #0x1808             ; =6152
     2ac:      	mov	x9, #0x0                ; =0
     2b0:      	mov	w8, #0x1800             ; =6144
     2b4:      	umaddl	x8, w22, w0, x8
     2b8:      	add	x10, x28, x8
     2bc:      	add	x11, x10, #0x4
     2c0:      	ldr	s26, [x10]
     2c4:      	ld1.s	{ v26 }[1], [x11]
     2c8:      	ldr	q0, [sp, #0x3a0]
     2cc:      	mov.d	v26[1], v0[1]
     2d0:      	str	q0, [sp, #0x8910]
     2d4:      	str	q26, [sp, #0x8900]
     2d8:      	movi.2d	v1, #0000000000000000
     2dc:      	movi.2d	v2, #0000000000000000
     2e0:      	movi.2d	v3, #0000000000000000
     2e4:      	movi.2d	v4, #0000000000000000
     2e8:      	ldp	q18, q17, [sp, #0x290]
     2ec:      	ldp	q20, q19, [sp, #0x270]
     2f0:      	shl.2d	v5, v1, #0x3
     2f4:      	shl.2d	v6, v2, #0x3
     2f8:      	shl.2d	v7, v3, #0x3
     2fc:      	shl.2d	v16, v4, #0x3
     300:      	orr.16b	v16, v16, v17
     304:      	orr.16b	v7, v7, v18
     308:      	orr.16b	v6, v6, v19
     30c:      	orr.16b	v5, v5, v20
     310:      	add	x9, x19, x9, lsl #6
     314:      	stp	q5, q6, [x9]
     318:      	stp	q7, q16, [x9, #0x20]
     31c:      	add.2d	v3, v3, v21
     320:      	add.2d	v2, v2, v21
     324:      	add.2d	v4, v4, v21
     328:      	add.2d	v1, v1, v21
     32c:      	fmov	x9, d1
     330:      	cmp	x9, #0xc0
     334:      	b.lt	0x2f0 <ltmp0+0x2f0>
     338:      	mov	x9, #0x0                ; =0
     33c:      	mov	w10, #0x1da1            ; =7585
     340:      	movk	w10, #0xaa7, lsl #16
     344:      	umull	x10, w22, w10
     348:      	lsr	x10, x10, #38
     34c:      	mov	w11, #0x602             ; =1538
     350:      	msub	w10, w10, w11, w22
     354:      	dup.4s	v5, w10
     358:      	ldr	q1, [sp, #0x250]
     35c:      	str	q1, [sp, #0x70c0]
     360:      	ushll.2d	v6, v5, #0x0
     364:      	movi.2d	v7, #0000000000000000
     368:      	movi.2d	v16, #0000000000000000
     36c:      	movi.2d	v17, #0000000000000000
     370:      	movi.2d	v18, #0000000000000000
     374:      	ldr	q30, [sp, #0x2b0]
     378:      	adrp	x22, 0x0 <ltmp0>
     37c:      	adrp	x3, 0x0 <ltmp0>
     380:      	add	x28, sp, #0x7, lsl #12  ; =0x7000
     384:      	add	x28, x28, #0x100
     388:      	add	x9, x19, x9, lsl #6
     38c:      	ldp	q20, q19, [x9, #0x20]
     390:      	ldp	q21, q22, [x9]
     394:      	ldr	q1, [x22]
     398:      	ldr	q2, [x3]
     39c:      	ldr	q3, [x27]
     3a0:      	ldr	q4, [x24]
     3a4:      	add.2d	v23, v18, v4
     3a8:      	add.2d	v24, v16, v2
     3ac:      	add.2d	v24, v24, v30
     3b0:      	add.2d	v25, v7, v1
     3b4:      	add.2d	v25, v25, v30
     3b8:      	cmge.2d	v22, v6, v22
     3bc:      	cmge.2d	v21, v6, v21
     3c0:      	uzp1.4s	v21, v21, v22
     3c4:      	cmge.2d	v20, v6, v20
     3c8:      	cmge.2d	v19, v6, v19
     3cc:      	uzp1.4s	v19, v20, v19
     3d0:      	uzp1.8h	v19, v21, v19
     3d4:      	xtn.8b	v19, v19
     3d8:      	and.8b	v19, v19, v8
     3dc:      	mov.d	x9, v25[1]
     3e0:      	fmov	x10, d25
     3e4:      	str	b19, [x10]
     3e8:      	st1.b	{ v19 }[1], [x9]
     3ec:      	mov.d	x9, v24[1]
     3f0:      	add.2d	v20, v17, v3
     3f4:      	fmov	x10, d24
     3f8:      	st1.b	{ v19 }[2], [x10]
     3fc:      	st1.b	{ v19 }[3], [x9]
     400:      	add.2d	v20, v20, v30
     404:      	mov.d	x9, v20[1]
     408:      	fmov	x10, d20
     40c:      	st1.b	{ v19 }[4], [x10]
     410:      	add.2d	v20, v23, v30
     414:      	st1.b	{ v19 }[5], [x9]
     418:      	mov.d	x9, v20[1]
     41c:      	fmov	x10, d20
     420:      	st1.b	{ v19 }[6], [x10]
     424:      	st1.b	{ v19 }[7], [x9]
     428:      	dup.2d	v19, x25
     42c:      	add.2d	v17, v17, v19
     430:      	add.2d	v16, v16, v19
     434:      	add.2d	v18, v18, v19
     438:      	add.2d	v7, v7, v19
     43c:      	fmov	x9, d7
     440:      	cmp	x9, #0xc0
     444:      	b.lt	0x388 <ltmp0+0x388>
     448:      	mov	x10, #0x0               ; =0
     44c:      	adrp	x9, 0x0 <ltmp0>
     450:      	ldr	q6, [x9]
     454:      	cmhs.4s	v5, v5, v6
     458:      	xtn.4h	v5, v5
     45c:      	uzp1.8b	v5, v5, v0
     460:      	and.8b	v5, v5, v8
     464:      	ldp	q6, q27, [sp, #0x3b0]
     468:      	fmov	x9, d6
     46c:      	str	b5, [x9]
     470:      	mov.d	x9, v6[1]
     474:      	st1.b	{ v5 }[1], [x9]
     478:      	movi.2d	v5, #0000000000000000
     47c:      	movi.2d	v6, #0000000000000000
     480:      	movi.2d	v7, #0000000000000000
     484:      	movi.2d	v16, #0000000000000000
     488:      	movi.4s	v28, #0x4b, lsl #24
     48c:      	mvni.4s	v29, #0x80, lsl #24
     490:      	ldr	q8, [sp, #0x260]
     494:      	ldp	q15, q13, [sp, #0x2e0]
     498:      	ldr	q0, [sp, #0x2c0]
     49c:      	add.2d	v17, v16, v4
     4a0:      	add.2d	v18, v7, v3
     4a4:      	add.2d	v17, v17, v30
     4a8:      	add.2d	v19, v6, v2
     4ac:      	add.2d	v20, v5, v1
     4b0:      	add.2d	v20, v20, v30
     4b4:      	mov.d	x11, v20[1]
     4b8:      	add.2d	v18, v18, v30
     4bc:      	add.2d	v19, v19, v30
     4c0:      	fmov	x12, d20
     4c4:      	mov.d	x13, v19[1]
     4c8:      	mov.d	x14, v18[1]
     4cc:      	fmov	x15, d19
     4d0:      	ldr	b19, [x12]
     4d4:      	ld1.b	{ v19 }[1], [x11]
     4d8:      	mov.d	x11, v17[1]
     4dc:      	fmov	x12, d18
     4e0:      	ld1.b	{ v19 }[2], [x15]
     4e4:      	ld1.b	{ v19 }[3], [x13]
     4e8:      	fmov	x13, d17
     4ec:      	ld1.b	{ v19 }[4], [x12]
     4f0:      	ld1.b	{ v19 }[5], [x14]
     4f4:      	ld1.b	{ v19 }[6], [x13]
     4f8:      	ld1.b	{ v19 }[7], [x11]
     4fc:      	cmeq.8b	v17, v19, #0
     500:      	sshll.8h	v17, v17, #0x0
     504:      	sshll2.4s	v18, v17, #0x0
     508:      	sshll.4s	v17, v17, #0x0
     50c:      	lsl	x10, x10, #5
     510:      	add	x11, x28, x10
     514:      	ldp	q20, q19, [x11]
     518:      	bsl.16b	v17, v0, v20
     51c:      	bsl.16b	v18, v0, v19
     520:      	add	x10, x20, x10
     524:      	dup.2d	v19, x25
     528:      	stp	q17, q18, [x10]
     52c:      	add.2d	v7, v7, v19
     530:      	add.2d	v6, v6, v19
     534:      	add.2d	v16, v16, v19
     538:      	add.2d	v5, v5, v19
     53c:      	fmov	x10, d5
     540:      	cmp	x10, #0xc0
     544:      	b.lt	0x49c <ltmp0+0x49c>
     548:      	mov	x10, #0x0               ; =0
     54c:      	ldr	q5, [sp, #0x3b0]
     550:      	fmov	x11, d5
     554:      	ldr	b5, [x11]
     558:      	ld1.b	{ v5 }[1], [x9]
     55c:      	cmeq.8b	v5, v5, #0
     560:      	sshll.8h	v5, v5, #0x0
     564:      	stp	q5, q26, [sp, #0x390]
     568:      	sshll.4s	v6, v5, #0x0
     56c:      	mov.16b	v7, v6
     570:      	bsl.16b	v7, v0, v26
     574:      	ldr	q16, [x23, #0x3020]
     578:      	mov.16b	v0, v7
     57c:      	mov.d	v0[1], v16[1]
     580:      	str	q0, [sp, #0x380]
     584:      	str	q0, [x23, #0x3020]
     588:      	ldr	q16, [x23, #0x1830]
     58c:      	ldr	q22, [x23, #0x1820]
     590:      	ldr	q21, [x23, #0x1850]
     594:      	ldr	q20, [x23, #0x1840]
     598:      	ldr	q17, [x23, #0x1870]
     59c:      	ldr	q23, [x23, #0x1860]
     5a0:      	ldr	q19, [x23, #0x1890]
     5a4:      	ldr	q18, [x23, #0x1880]
     5a8:      	add	x9, x20, x10, lsl #5
     5ac:      	ldp	q24, q25, [x9, #0x80]
     5b0:      	fmaxnm.4s	v16, v16, v25
     5b4:      	fmaxnm.4s	v22, v22, v24
     5b8:      	ldp	q24, q25, [x9, #0xa0]
     5bc:      	fmaxnm.4s	v21, v21, v25
     5c0:      	fmaxnm.4s	v20, v20, v24
     5c4:      	ldp	q24, q25, [x9, #0xc0]
     5c8:      	fmaxnm.4s	v17, v17, v25
     5cc:      	fmaxnm.4s	v23, v23, v24
     5d0:      	ldp	q24, q25, [x9, #0xe0]
     5d4:      	fmaxnm.4s	v19, v19, v25
     5d8:      	fmaxnm.4s	v18, v18, v24
     5dc:      	add	x10, x10, #0x4
     5e0:      	cmp	x10, #0xbc
     5e4:      	b.lo	0x5a8 <ltmp0+0x5a8>
     5e8:      	mov	x14, #0x0               ; =0
     5ec:      	movi.2d	v24, #0000000000000000
     5f0:      	mov.d	v24[0], v7[0]
     5f4:      	fmaxnm.4s	v7, v22, v24
     5f8:      	mov.d	v7[1], v22[1]
     5fc:      	fmaxnm.4s	v16, v16, v21
     600:      	fmaxnm.4s	v7, v7, v20
     604:      	fmaxnm.4s	v7, v7, v23
     608:      	fmaxnm.4s	v16, v16, v17
     60c:      	fmaxnm.4s	v16, v16, v19
     610:      	fmaxnm.4s	v7, v7, v18
     614:      	rev64.4s	v17, v7
     618:      	rev64.4s	v18, v16
     61c:      	fmaxnm.4s	v16, v16, v18
     620:      	fmaxnm.4s	v7, v7, v17
     624:      	ext.16b	v17, v7, v7, #0x8
     628:      	ext.16b	v18, v16, v16, #0x8
     62c:      	fmaxnm.4s	v16, v16, v18
     630:      	fmaxnm.4s	v7, v7, v17
     634:      	fmaxnm.4s	v7, v7, v16
     638:      	mov	w9, #-0x800000          ; =-8388608
     63c:      	fmov	s16, w9
     640:      	fmaxnm	s0, s7, s16
     644:      	str	q0, [sp, #0x370]
     648:      	dup.4s	v16, v0[0]
     64c:      	movi.2d	v17, #0000000000000000
     650:      	movi.2d	v18, #0000000000000000
     654:      	movi.2d	v19, #0000000000000000
     658:      	movi.2d	v20, #0000000000000000
     65c:      	ldr	q14, [sp, #0x2d0]
     660:      	ldp	q7, q0, [sp, #0x350]
     664:      	ldp	q31, q10, [sp, #0x330]
     668:      	ldp	q6, q9, [sp, #0x310]
     66c:      	ldr	q5, [sp, #0x300]
     670:      	add.2d	v21, v19, v3
     674:      	add.2d	v21, v21, v30
     678:      	add.2d	v22, v18, v2
     67c:      	add.2d	v22, v22, v30
     680:      	add.2d	v23, v17, v1
     684:      	add.2d	v23, v23, v30
     688:      	mov.d	x10, v23[1]
     68c:      	mov.d	x11, v22[1]
     690:      	fmov	x13, d23
     694:      	fmov	x12, d22
     698:      	mov.d	x9, v21[1]
     69c:      	lsl	x14, x14, #5
     6a0:      	fmov	x15, d21
     6a4:      	add	x16, x20, x14
     6a8:      	ldp	q21, q22, [x16]
     6ac:      	fsub.4s	v22, v22, v16
     6b0:      	fsub.4s	v21, v21, v16
     6b4:      	fcmge.4s	v23, v21, v15
     6b8:      	fcmge.4s	v24, v22, v15
     6bc:      	fcmge.4s	v25, v13, v21
     6c0:      	fcmge.4s	v26, v13, v22
     6c4:      	and.16b	v24, v24, v26
     6c8:      	and.16b	v23, v23, v25
     6cc:      	and.16b	v23, v23, v21
     6d0:      	and.16b	v24, v24, v22
     6d4:      	fmul.4s	v25, v24, v5
     6d8:      	fmul.4s	v26, v23, v5
     6dc:      	mov.16b	v11, v27
     6e0:      	mov.16b	v27, v29
     6e4:      	bsl.16b	v27, v28, v26
     6e8:      	movi.4s	v28, #0x4b, lsl #24
     6ec:      	bif.16b	v28, v25, v29
     6f0:      	fadd.4s	v25, v25, v28
     6f4:      	fadd.4s	v26, v26, v27
     6f8:      	fsub.4s	v26, v26, v27
     6fc:      	fsub.4s	v25, v25, v28
     700:      	fcvtzs.4s	v25, v25
     704:      	fcvtzs.4s	v26, v26
     708:      	scvtf.4s	v27, v26
     70c:      	scvtf.4s	v28, v25
     710:      	fmul.4s	v29, v27, v6
     714:      	fadd.4s	v23, v23, v29
     718:      	fmul.4s	v29, v28, v6
     71c:      	fadd.4s	v24, v24, v29
     720:      	add.2d	v29, v20, v4
     724:      	add.2d	v29, v29, v30
     728:      	mov.d	x16, v29[1]
     72c:      	fmul.4s	v27, v27, v9
     730:      	fmul.4s	v28, v28, v9
     734:      	fadd.4s	v24, v24, v28
     738:      	fadd.4s	v23, v23, v27
     73c:      	fmul.4s	v27, v23, v31
     740:      	fmul.4s	v28, v24, v31
     744:      	fadd.4s	v28, v28, v10
     748:      	fadd.4s	v27, v27, v10
     74c:      	fmul.4s	v27, v23, v27
     750:      	fmul.4s	v28, v24, v28
     754:      	fadd.4s	v28, v28, v7
     758:      	fadd.4s	v27, v27, v7
     75c:      	fmul.4s	v27, v23, v27
     760:      	fmul.4s	v28, v24, v28
     764:      	fadd.4s	v28, v28, v0
     768:      	fadd.4s	v27, v27, v0
     76c:      	fmul.4s	v27, v23, v27
     770:      	fmul.4s	v28, v24, v28
     774:      	ldr	q12, [sp, #0x3d0]
     778:      	fadd.4s	v28, v28, v12
     77c:      	fadd.4s	v27, v27, v12
     780:      	fmov	x17, d29
     784:      	fmul.4s	v27, v23, v27
     788:      	fmul.4s	v28, v24, v28
     78c:      	movi.4s	v29, #0x3f, lsl #24
     790:      	fadd.4s	v28, v28, v29
     794:      	movi.4s	v12, #0x3f, lsl #24
     798:      	fadd.4s	v27, v27, v29
     79c:      	fmul.4s	v29, v23, v23
     7a0:      	fmul.4s	v27, v29, v27
     7a4:      	fmul.4s	v29, v24, v24
     7a8:      	fmul.4s	v28, v29, v28
     7ac:      	fadd.4s	v24, v24, v28
     7b0:      	fadd.4s	v23, v23, v27
     7b4:      	sshr.4s	v27, v26, #0x1
     7b8:      	fadd.4s	v24, v24, v14
     7bc:      	sshr.4s	v28, v25, #0x1
     7c0:      	shl.4s	v29, v28, #0x17
     7c4:      	add.4s	v29, v29, v14
     7c8:      	fmul.4s	v24, v24, v29
     7cc:      	shl.4s	v29, v27, #0x17
     7d0:      	fadd.4s	v23, v23, v14
     7d4:      	add.4s	v29, v29, v14
     7d8:      	fmul.4s	v23, v23, v29
     7dc:      	mvni.4s	v29, #0x80, lsl #24
     7e0:      	sub.4s	v25, v25, v28
     7e4:      	movi.4s	v28, #0x4b, lsl #24
     7e8:      	sub.4s	v26, v26, v27
     7ec:      	mov.16b	v27, v11
     7f0:      	shl.4s	v26, v26, #0x17
     7f4:      	add.4s	v26, v26, v14
     7f8:      	fmul.4s	v23, v23, v26
     7fc:      	ldr	b26, [x13]
     800:      	ld1.b	{ v26 }[1], [x10]
     804:      	ld1.b	{ v26 }[2], [x12]
     808:      	ld1.b	{ v26 }[3], [x11]
     80c:      	shl.4s	v25, v25, #0x17
     810:      	add.4s	v25, v25, v14
     814:      	fmul.4s	v24, v24, v25
     818:      	fcmgt.4s	v25, v15, v22
     81c:      	bic.16b	v24, v24, v25
     820:      	fcmgt.4s	v25, v15, v21
     824:      	bic.16b	v23, v23, v25
     828:      	fcmgt.4s	v25, v21, v13
     82c:      	bit.16b	v23, v8, v25
     830:      	fcmgt.4s	v25, v22, v13
     834:      	bit.16b	v24, v8, v25
     838:      	ld1.b	{ v26 }[4], [x15]
     83c:      	ld1.b	{ v26 }[5], [x9]
     840:      	fcmeq.4s	v22, v22, v22
     844:      	bsl.16b	v22, v24, v11
     848:      	ld1.b	{ v26 }[6], [x17]
     84c:      	ld1.b	{ v26 }[7], [x16]
     850:      	cmeq.8b	v24, v26, #0
     854:      	sshll.8h	v24, v24, #0x0
     858:      	fcmeq.4s	v21, v21, v21
     85c:      	bsl.16b	v21, v23, v11
     860:      	sshll.4s	v23, v24, #0x0
     864:      	bic.16b	v21, v21, v23
     868:      	sshll2.4s	v23, v24, #0x0
     86c:      	bic.16b	v22, v22, v23
     870:      	add	x9, x23, x14
     874:      	stp	q21, q22, [x9]
     878:      	dup.2d	v21, x25
     87c:      	add.2d	v19, v19, v21
     880:      	add.2d	v18, v18, v21
     884:      	add.2d	v20, v20, v21
     888:      	add.2d	v17, v17, v21
     88c:      	fmov	x14, d17
     890:      	cmp	x14, #0xc0
     894:      	b.lt	0x670 <ltmp0+0x670>
     898:      	mov	x9, #0x0                ; =0
     89c:      	ldp	q1, q3, [sp, #0x370]
     8a0:      	dup.4s	v1, v1[0]
     8a4:      	ldr	q2, [sp, #0x390]
     8a8:      	sshll.4s	v2, v2, #0x0
     8ac:      	fsub.4s	v1, v3, v1
     8b0:      	movi.2d	v3, #0000000000000000
     8b4:      	mov.d	v3[0], v1[0]
     8b8:      	fcmge.4s	v1, v3, v15
     8bc:      	fcmge.4s	v4, v13, v3
     8c0:      	and.16b	v1, v1, v4
     8c4:      	and.16b	v1, v1, v3
     8c8:      	fmul.4s	v4, v1, v5
     8cc:      	mov.16b	v5, v29
     8d0:      	bsl.16b	v5, v28, v4
     8d4:      	fadd.4s	v4, v4, v5
     8d8:      	fsub.4s	v4, v4, v5
     8dc:      	fcvtzs.4s	v4, v4
     8e0:      	scvtf.4s	v5, v4
     8e4:      	fmul.4s	v6, v5, v6
     8e8:      	fadd.4s	v1, v1, v6
     8ec:      	fmul.4s	v5, v5, v9
     8f0:      	fadd.4s	v1, v1, v5
     8f4:      	fmul.4s	v5, v1, v31
     8f8:      	fadd.4s	v5, v5, v10
     8fc:      	fmul.4s	v5, v1, v5
     900:      	fadd.4s	v5, v5, v7
     904:      	fmul.4s	v5, v1, v5
     908:      	fadd.4s	v5, v5, v0
     90c:      	fmul.4s	v5, v1, v5
     910:      	ldr	q0, [sp, #0x3d0]
     914:      	fadd.4s	v5, v5, v0
     918:      	fmul.4s	v5, v1, v5
     91c:      	fadd.4s	v5, v5, v12
     920:      	fmul.4s	v6, v1, v1
     924:      	fmul.4s	v5, v6, v5
     928:      	fadd.4s	v1, v1, v5
     92c:      	fadd.4s	v1, v1, v14
     930:      	sshr.4s	v5, v4, #0x1
     934:      	shl.4s	v6, v5, #0x17
     938:      	add.4s	v6, v6, v14
     93c:      	fmul.4s	v1, v1, v6
     940:      	sub.4s	v4, v4, v5
     944:      	shl.4s	v4, v4, #0x17
     948:      	add.4s	v4, v4, v14
     94c:      	fmul.4s	v1, v1, v4
     950:      	fcmgt.4s	v4, v15, v3
     954:      	bic.16b	v1, v1, v4
     958:      	fcmgt.4s	v4, v3, v13
     95c:      	bit.16b	v1, v8, v4
     960:      	fcmeq.4s	v3, v3, v3
     964:      	bif.16b	v1, v27, v3
     968:      	bic.16b	v1, v1, v2
     96c:      	ldr	q2, [x23, #0x1800]
     970:      	mov.d	v1[1], v2[1]
     974:      	str	q1, [x23, #0x1800]
     978:      	ldp	q16, q2, [x23]
     97c:      	ldp	q6, q7, [x23, #0x20]
     980:      	ldp	q17, q3, [x23, #0x40]
     984:      	ldp	q4, q5, [x23, #0x60]
     988:      	add	x10, x23, x9, lsl #5
     98c:      	ldp	q18, q19, [x10, #0x80]
     990:      	fadd.4s	v2, v2, v19
     994:      	fadd.4s	v16, v16, v18
     998:      	ldp	q18, q19, [x10, #0xa0]
     99c:      	fadd.4s	v7, v7, v19
     9a0:      	fadd.4s	v6, v6, v18
     9a4:      	ldp	q18, q19, [x10, #0xc0]
     9a8:      	fadd.4s	v3, v3, v19
     9ac:      	fadd.4s	v17, v17, v18
     9b0:      	ldp	q18, q19, [x10, #0xe0]
     9b4:      	fadd.4s	v5, v5, v19
     9b8:      	fadd.4s	v4, v4, v18
     9bc:      	add	x9, x9, #0x4
     9c0:      	cmp	x9, #0xbc
     9c4:      	b.lo	0x988 <ltmp0+0x988>
     9c8:      	mov	x9, #0x0                ; =0
     9cc:      	fadd.4s	v18, v1, v16
     9d0:      	mov.d	v18[1], v16[1]
     9d4:      	fadd.4s	v2, v7, v2
     9d8:      	fadd.4s	v6, v6, v18
     9dc:      	fadd.4s	v6, v17, v6
     9e0:      	fadd.4s	v2, v3, v2
     9e4:      	fadd.4s	v2, v5, v2
     9e8:      	fadd.4s	v3, v4, v6
     9ec:      	rev64.4s	v4, v3
     9f0:      	rev64.4s	v5, v2
     9f4:      	fadd.4s	v2, v2, v5
     9f8:      	fadd.4s	v3, v3, v4
     9fc:      	dup.4s	v4, v3[2]
     a00:      	dup.4s	v5, v2[2]
     a04:      	fadd.4s	v2, v2, v5
     a08:      	fadd.4s	v3, v3, v4
     a0c:      	fadd.4s	v2, v3, v2
     a10:      	movi	d0, #0000000000000000
     a14:      	fadd	s2, s2, s0
     a18:      	dup.4s	v3, v2[0]
     a1c:      	movi.8b	v8, #0x1
     a20:      	ldr	q0, [sp, #0x3a0]
     a24:      	lsl	x10, x9, #5
     a28:      	add	x11, x23, x10
     a2c:      	ldp	q5, q4, [x11]
     a30:      	fdiv.4s	v5, v5, v3
     a34:      	fdiv.4s	v4, v4, v3
     a38:      	add	x10, x21, x10
     a3c:      	stp	q5, q4, [x10]
     a40:      	add	x9, x9, #0x1
     a44:      	cmp	x9, #0xc0
     a48:      	b.ne	0xa24 <ltmp0+0xa24>
     a4c:      	dup.2s	v2, v2[0]
     a50:      	fdiv.2s	v1, v1, v2
     a54:      	ldr	x9, [sp, #0x230]
     a58:      	str	d1, [x9, x8]
     a5c:      	add	x26, x26, #0x1
     a60:      	add	x21, x21, x0
     a64:      	cmp	x26, #0x4
     a68:      	b.ne	0x27c <ltmp0+0x27c>
     a6c:      	b	0x110 <ltmp0+0x110>
     a70:      	lsr	x8, x9, #3
     a74:      	str	x8, [sp, #0x240]
     a78:      	str	x9, [sp, #0x1f0]
     a7c:      	cmp	x9, #0x8
     a80:      	b.lo	0x128c <ltmp0+0x128c>
     a84:      	mov	x10, #0x0               ; =0
     a88:      	ldr	x8, [sp, #0x180]
     a8c:      	ldr	x9, [x8]
     a90:      	str	x9, [sp, #0x230]
     a94:      	ldr	x11, [x8, #0x30]
     a98:      	ldr	x8, [sp, #0x1a8]
     a9c:      	lsl	w9, w8, #2
     aa0:      	str	x9, [sp, #0x200]
     aa4:      	and	x8, x8, #0x7ffffff
     aa8:      	mov	w9, #0x6020             ; =24608
     aac:      	str	x11, [sp, #0x220]
     ab0:      	umaddl	x26, w8, w9, x11
     ab4:      	mov	x24, x27
     ab8:      	str	x10, [sp, #0x3a0]
     abc:      	ldr	x8, [sp, #0x200]
     ac0:      	add	w8, w10, w8
     ac4:      	and	x21, x8, #0x1fffffff
     ac8:      	ldr	x27, [sp, #0x230]
     acc:      	umaddl	x1, w21, w0, x27
     ad0:      	add	x0, sp, #0x7, lsl #12   ; =0x7000
     ad4:      	add	x0, x0, #0x100
     ad8:      	mov	w2, #0x1800             ; =6144
     adc:      	bl	0xadc <ltmp0+0xadc>
     ae0:      	mov	w0, #0x1808             ; =6152
     ae4:      	mov	x9, #0x0                ; =0
     ae8:      	mov	w8, #0x1800             ; =6144
     aec:      	umaddl	x8, w21, w0, x8
     af0:      	add	x10, x27, x8
     af4:      	add	x11, x10, #0x4
     af8:      	ldr	s26, [x10]
     afc:      	ld1.s	{ v26 }[1], [x11]
     b00:      	str	q26, [sp, #0x8900]
     b04:      	movi.2d	v0, #0000000000000000
     b08:      	movi.2d	v1, #0000000000000000
     b0c:      	movi.2d	v2, #0000000000000000
     b10:      	movi.2d	v3, #0000000000000000
     b14:      	ldp	q18, q17, [sp, #0x290]
     b18:      	ldp	q20, q19, [sp, #0x270]
     b1c:      	shl.2d	v4, v0, #0x3
     b20:      	shl.2d	v6, v1, #0x3
     b24:      	shl.2d	v7, v2, #0x3
     b28:      	shl.2d	v16, v3, #0x3
     b2c:      	orr.16b	v16, v16, v17
     b30:      	orr.16b	v7, v7, v18
     b34:      	orr.16b	v6, v6, v19
     b38:      	orr.16b	v4, v4, v20
     b3c:      	add	x9, x19, x9, lsl #6
     b40:      	stp	q4, q6, [x9]
     b44:      	stp	q7, q16, [x9, #0x20]
     b48:      	dup.2d	v4, x25
     b4c:      	add.2d	v2, v2, v4
     b50:      	add.2d	v1, v1, v4
     b54:      	add.2d	v3, v3, v4
     b58:      	add.2d	v0, v0, v4
     b5c:      	fmov	x9, d0
     b60:      	cmp	x9, #0xc0
     b64:      	b.lt	0xb1c <ltmp0+0xb1c>
     b68:      	mov	x9, #0x0                ; =0
     b6c:      	mov	w10, #0x1da1            ; =7585
     b70:      	movk	w10, #0xaa7, lsl #16
     b74:      	umull	x10, w21, w10
     b78:      	lsr	x10, x10, #38
     b7c:      	mov	w11, #0x602             ; =1538
     b80:      	msub	w10, w10, w11, w21
     b84:      	dup.4s	v4, w10
     b88:      	ldr	q0, [sp, #0x250]
     b8c:      	str	q0, [sp, #0x70c0]
     b90:      	ushll.2d	v6, v4, #0x0
     b94:      	movi.2d	v7, #0000000000000000
     b98:      	movi.2d	v16, #0000000000000000
     b9c:      	movi.2d	v17, #0000000000000000
     ba0:      	movi.2d	v18, #0000000000000000
     ba4:      	ldr	q29, [sp, #0x2b0]
     ba8:      	adrp	x3, 0x0 <ltmp0>
     bac:      	mov	x27, x24
     bb0:      	adrp	x11, 0x0 <ltmp0>
     bb4:      	add	x9, x19, x9, lsl #6
     bb8:      	ldp	q20, q19, [x9, #0x20]
     bbc:      	ldp	q21, q22, [x9]
     bc0:      	ldr	q0, [x22]
     bc4:      	ldr	q1, [x3]
     bc8:      	ldr	q2, [x27]
     bcc:      	ldr	q3, [x11]
     bd0:      	add.2d	v23, v18, v3
     bd4:      	add.2d	v24, v16, v1
     bd8:      	add.2d	v24, v24, v29
     bdc:      	add.2d	v25, v7, v0
     be0:      	add.2d	v25, v25, v29
     be4:      	cmge.2d	v22, v6, v22
     be8:      	cmge.2d	v21, v6, v21
     bec:      	uzp1.4s	v21, v21, v22
     bf0:      	cmge.2d	v20, v6, v20
     bf4:      	cmge.2d	v19, v6, v19
     bf8:      	uzp1.4s	v19, v20, v19
     bfc:      	uzp1.8h	v19, v21, v19
     c00:      	xtn.8b	v19, v19
     c04:      	and.8b	v19, v19, v8
     c08:      	mov.d	x9, v25[1]
     c0c:      	fmov	x10, d25
     c10:      	str	b19, [x10]
     c14:      	st1.b	{ v19 }[1], [x9]
     c18:      	mov.d	x9, v24[1]
     c1c:      	add.2d	v20, v17, v2
     c20:      	fmov	x10, d24
     c24:      	st1.b	{ v19 }[2], [x10]
     c28:      	st1.b	{ v19 }[3], [x9]
     c2c:      	add.2d	v20, v20, v29
     c30:      	mov.d	x9, v20[1]
     c34:      	fmov	x10, d20
     c38:      	st1.b	{ v19 }[4], [x10]
     c3c:      	add.2d	v20, v23, v29
     c40:      	st1.b	{ v19 }[5], [x9]
     c44:      	mov.d	x9, v20[1]
     c48:      	fmov	x10, d20
     c4c:      	st1.b	{ v19 }[6], [x10]
     c50:      	st1.b	{ v19 }[7], [x9]
     c54:      	dup.2d	v19, x25
     c58:      	add.2d	v17, v17, v19
     c5c:      	add.2d	v16, v16, v19
     c60:      	add.2d	v18, v18, v19
     c64:      	add.2d	v7, v7, v19
     c68:      	fmov	x9, d7
     c6c:      	cmp	x9, #0xc0
     c70:      	b.lt	0xbb4 <ltmp0+0xbb4>
     c74:      	mov	x10, #0x0               ; =0
     c78:      	adrp	x9, 0x0 <ltmp0>
     c7c:      	ldr	q6, [x9]
     c80:      	cmhs.4s	v4, v4, v6
     c84:      	xtn.4h	v4, v4
     c88:      	uzp1.8b	v4, v4, v0
     c8c:      	and.8b	v4, v4, v8
     c90:      	ldr	q6, [sp, #0x3b0]
     c94:      	fmov	x9, d6
     c98:      	str	b4, [x9]
     c9c:      	mov.d	x9, v6[1]
     ca0:      	st1.b	{ v4 }[1], [x9]
     ca4:      	movi.2d	v4, #0000000000000000
     ca8:      	movi.2d	v6, #0000000000000000
     cac:      	movi.2d	v7, #0000000000000000
     cb0:      	movi.2d	v16, #0000000000000000
     cb4:      	movi.4s	v27, #0x4b, lsl #24
     cb8:      	mvni.4s	v28, #0x80, lsl #24
     cbc:      	ldr	q10, [sp, #0x260]
     cc0:      	ldp	q13, q12, [sp, #0x2e0]
     cc4:      	ldp	q5, q15, [sp, #0x2c0]
     cc8:      	ldr	q14, [sp, #0x3d0]
     ccc:      	add.2d	v17, v16, v3
     cd0:      	add.2d	v18, v7, v2
     cd4:      	add.2d	v17, v17, v29
     cd8:      	add.2d	v19, v6, v1
     cdc:      	add.2d	v20, v4, v0
     ce0:      	add.2d	v20, v20, v29
     ce4:      	mov.d	x11, v20[1]
     ce8:      	add.2d	v18, v18, v29
     cec:      	add.2d	v19, v19, v29
     cf0:      	fmov	x12, d20
     cf4:      	mov.d	x13, v19[1]
     cf8:      	mov.d	x14, v18[1]
     cfc:      	fmov	x15, d19
     d00:      	ldr	b19, [x12]
     d04:      	ld1.b	{ v19 }[1], [x11]
     d08:      	mov.d	x11, v17[1]
     d0c:      	fmov	x12, d18
     d10:      	ld1.b	{ v19 }[2], [x15]
     d14:      	ld1.b	{ v19 }[3], [x13]
     d18:      	fmov	x13, d17
     d1c:      	ld1.b	{ v19 }[4], [x12]
     d20:      	ld1.b	{ v19 }[5], [x14]
     d24:      	ld1.b	{ v19 }[6], [x13]
     d28:      	ld1.b	{ v19 }[7], [x11]
     d2c:      	cmeq.8b	v17, v19, #0
     d30:      	sshll.8h	v17, v17, #0x0
     d34:      	sshll2.4s	v18, v17, #0x0
     d38:      	sshll.4s	v17, v17, #0x0
     d3c:      	lsl	x10, x10, #5
     d40:      	add	x11, x28, x10
     d44:      	ldp	q20, q19, [x11]
     d48:      	bsl.16b	v17, v5, v20
     d4c:      	bsl.16b	v18, v5, v19
     d50:      	add	x10, x20, x10
     d54:      	dup.2d	v19, x25
     d58:      	stp	q17, q18, [x10]
     d5c:      	add.2d	v7, v7, v19
     d60:      	add.2d	v6, v6, v19
     d64:      	add.2d	v16, v16, v19
     d68:      	add.2d	v4, v4, v19
     d6c:      	fmov	x10, d4
     d70:      	cmp	x10, #0xc0
     d74:      	b.lt	0xccc <ltmp0+0xccc>
     d78:      	mov	x10, #0x0               ; =0
     d7c:      	ldr	q4, [sp, #0x3b0]
     d80:      	fmov	x11, d4
     d84:      	ldr	b4, [x11]
     d88:      	ld1.b	{ v4 }[1], [x9]
     d8c:      	cmeq.8b	v4, v4, #0
     d90:      	sshll.8h	v4, v4, #0x0
     d94:      	str	q4, [sp, #0x390]
     d98:      	sshll.4s	v6, v4, #0x0
     d9c:      	bsl.16b	v6, v5, v26
     da0:      	ldr	q7, [x23, #0x3020]
     da4:      	mov.16b	v4, v6
     da8:      	mov.d	v4[1], v7[1]
     dac:      	str	q4, [sp, #0x380]
     db0:      	str	q4, [x23, #0x3020]
     db4:      	ldr	q7, [x23, #0x1830]
     db8:      	ldr	q21, [x23, #0x1820]
     dbc:      	ldr	q20, [x23, #0x1850]
     dc0:      	ldr	q19, [x23, #0x1840]
     dc4:      	ldr	q16, [x23, #0x1870]
     dc8:      	ldr	q22, [x23, #0x1860]
     dcc:      	ldr	q18, [x23, #0x1890]
     dd0:      	ldr	q17, [x23, #0x1880]
     dd4:      	add	x9, x20, x10, lsl #5
     dd8:      	ldp	q23, q24, [x9, #0x80]
     ddc:      	fmaxnm.4s	v7, v7, v24
     de0:      	fmaxnm.4s	v21, v21, v23
     de4:      	ldp	q23, q24, [x9, #0xa0]
     de8:      	fmaxnm.4s	v20, v20, v24
     dec:      	fmaxnm.4s	v19, v19, v23
     df0:      	ldp	q23, q24, [x9, #0xc0]
     df4:      	fmaxnm.4s	v16, v16, v24
     df8:      	fmaxnm.4s	v22, v22, v23
     dfc:      	ldp	q23, q24, [x9, #0xe0]
     e00:      	fmaxnm.4s	v18, v18, v24
     e04:      	fmaxnm.4s	v17, v17, v23
     e08:      	add	x10, x10, #0x4
     e0c:      	cmp	x10, #0xbc
     e10:      	b.lo	0xdd4 <ltmp0+0xdd4>
     e14:      	mov	x14, #0x0               ; =0
     e18:      	movi.2d	v23, #0000000000000000
     e1c:      	mov.d	v23[0], v6[0]
     e20:      	fmaxnm.4s	v6, v21, v23
     e24:      	mov.d	v6[1], v21[1]
     e28:      	fmaxnm.4s	v7, v7, v20
     e2c:      	fmaxnm.4s	v6, v6, v19
     e30:      	fmaxnm.4s	v6, v6, v22
     e34:      	fmaxnm.4s	v7, v7, v16
     e38:      	fmaxnm.4s	v7, v7, v18
     e3c:      	fmaxnm.4s	v6, v6, v17
     e40:      	rev64.4s	v16, v6
     e44:      	rev64.4s	v17, v7
     e48:      	fmaxnm.4s	v7, v7, v17
     e4c:      	fmaxnm.4s	v6, v6, v16
     e50:      	ext.16b	v16, v6, v6, #0x8
     e54:      	ext.16b	v17, v7, v7, #0x8
     e58:      	fmaxnm.4s	v7, v7, v17
     e5c:      	fmaxnm.4s	v6, v6, v16
     e60:      	fmaxnm.4s	v6, v6, v7
     e64:      	mov	w9, #-0x800000          ; =-8388608
     e68:      	fmov	s7, w9
     e6c:      	fmaxnm	s4, s6, s7
     e70:      	str	q4, [sp, #0x370]
     e74:      	dup.4s	v7, v4[0]
     e78:      	movi.2d	v16, #0000000000000000
     e7c:      	movi.2d	v17, #0000000000000000
     e80:      	movi.2d	v18, #0000000000000000
     e84:      	movi.2d	v19, #0000000000000000
     e88:      	ldp	q8, q6, [sp, #0x350]
     e8c:      	ldp	q30, q9, [sp, #0x330]
     e90:      	ldp	q5, q31, [sp, #0x310]
     e94:      	ldr	q4, [sp, #0x300]
     e98:      	add.2d	v20, v18, v2
     e9c:      	add.2d	v20, v20, v29
     ea0:      	add.2d	v21, v17, v1
     ea4:      	add.2d	v21, v21, v29
     ea8:      	add.2d	v22, v16, v0
     eac:      	add.2d	v22, v22, v29
     eb0:      	mov.d	x10, v22[1]
     eb4:      	mov.d	x11, v21[1]
     eb8:      	fmov	x13, d22
     ebc:      	fmov	x12, d21
     ec0:      	mov.d	x9, v20[1]
     ec4:      	lsl	x14, x14, #5
     ec8:      	fmov	x15, d20
     ecc:      	add	x16, x20, x14
     ed0:      	ldp	q20, q21, [x16]
     ed4:      	fsub.4s	v21, v21, v7
     ed8:      	fsub.4s	v20, v20, v7
     edc:      	fcmge.4s	v22, v20, v13
     ee0:      	fcmge.4s	v23, v21, v13
     ee4:      	fcmge.4s	v24, v12, v20
     ee8:      	fcmge.4s	v25, v12, v21
     eec:      	and.16b	v23, v23, v25
     ef0:      	and.16b	v22, v22, v24
     ef4:      	and.16b	v22, v22, v20
     ef8:      	and.16b	v23, v23, v21
     efc:      	fmul.4s	v24, v23, v4
     f00:      	fmul.4s	v25, v22, v4
     f04:      	mov.16b	v26, v28
     f08:      	bsl.16b	v26, v27, v25
     f0c:      	movi.4s	v27, #0x4b, lsl #24
     f10:      	bif.16b	v27, v24, v28
     f14:      	fadd.4s	v24, v24, v27
     f18:      	fadd.4s	v25, v25, v26
     f1c:      	fsub.4s	v25, v25, v26
     f20:      	fsub.4s	v24, v24, v27
     f24:      	fcvtzs.4s	v24, v24
     f28:      	fcvtzs.4s	v25, v25
     f2c:      	scvtf.4s	v26, v25
     f30:      	scvtf.4s	v27, v24
     f34:      	fmul.4s	v28, v26, v5
     f38:      	fadd.4s	v22, v22, v28
     f3c:      	fmul.4s	v28, v27, v5
     f40:      	fadd.4s	v23, v23, v28
     f44:      	add.2d	v28, v19, v3
     f48:      	add.2d	v28, v28, v29
     f4c:      	mov.d	x16, v28[1]
     f50:      	fmul.4s	v26, v26, v31
     f54:      	fmul.4s	v27, v27, v31
     f58:      	fadd.4s	v23, v23, v27
     f5c:      	fadd.4s	v22, v22, v26
     f60:      	fmul.4s	v26, v22, v30
     f64:      	fmul.4s	v27, v23, v30
     f68:      	fadd.4s	v27, v27, v9
     f6c:      	fadd.4s	v26, v26, v9
     f70:      	fmul.4s	v26, v22, v26
     f74:      	fmul.4s	v27, v23, v27
     f78:      	fadd.4s	v27, v27, v8
     f7c:      	fadd.4s	v26, v26, v8
     f80:      	fmul.4s	v26, v22, v26
     f84:      	fmul.4s	v27, v23, v27
     f88:      	fadd.4s	v27, v27, v6
     f8c:      	fadd.4s	v26, v26, v6
     f90:      	fmul.4s	v26, v22, v26
     f94:      	fmul.4s	v27, v23, v27
     f98:      	fadd.4s	v27, v27, v14
     f9c:      	fadd.4s	v26, v26, v14
     fa0:      	fmov	x17, d28
     fa4:      	fmul.4s	v26, v22, v26
     fa8:      	fmul.4s	v27, v23, v27
     fac:      	movi.4s	v28, #0x3f, lsl #24
     fb0:      	fadd.4s	v27, v27, v28
     fb4:      	movi.4s	v11, #0x3f, lsl #24
     fb8:      	fadd.4s	v26, v26, v28
     fbc:      	fmul.4s	v28, v22, v22
     fc0:      	fmul.4s	v26, v28, v26
     fc4:      	fmul.4s	v28, v23, v23
     fc8:      	fmul.4s	v27, v28, v27
     fcc:      	fadd.4s	v23, v23, v27
     fd0:      	fadd.4s	v22, v22, v26
     fd4:      	sshr.4s	v26, v25, #0x1
     fd8:      	fadd.4s	v23, v23, v15
     fdc:      	sshr.4s	v27, v24, #0x1
     fe0:      	shl.4s	v28, v27, #0x17
     fe4:      	add.4s	v28, v28, v15
     fe8:      	fmul.4s	v23, v23, v28
     fec:      	shl.4s	v28, v26, #0x17
     ff0:      	fadd.4s	v22, v22, v15
     ff4:      	add.4s	v28, v28, v15
     ff8:      	fmul.4s	v22, v22, v28
     ffc:      	mvni.4s	v28, #0x80, lsl #24
    1000:      	sub.4s	v24, v24, v27
    1004:      	movi.4s	v27, #0x4b, lsl #24
    1008:      	sub.4s	v25, v25, v26
    100c:      	ldr	q26, [sp, #0x3c0]
    1010:      	shl.4s	v25, v25, #0x17
    1014:      	add.4s	v25, v25, v15
    1018:      	fmul.4s	v22, v22, v25
    101c:      	ldr	b25, [x13]
    1020:      	ld1.b	{ v25 }[1], [x10]
    1024:      	ld1.b	{ v25 }[2], [x12]
    1028:      	ld1.b	{ v25 }[3], [x11]
    102c:      	shl.4s	v24, v24, #0x17
    1030:      	add.4s	v24, v24, v15
    1034:      	fmul.4s	v23, v23, v24
    1038:      	fcmgt.4s	v24, v13, v21
    103c:      	bic.16b	v23, v23, v24
    1040:      	fcmgt.4s	v24, v13, v20
    1044:      	bic.16b	v22, v22, v24
    1048:      	fcmgt.4s	v24, v20, v12
    104c:      	bit.16b	v22, v10, v24
    1050:      	fcmgt.4s	v24, v21, v12
    1054:      	bit.16b	v23, v10, v24
    1058:      	ld1.b	{ v25 }[4], [x15]
    105c:      	ld1.b	{ v25 }[5], [x9]
    1060:      	fcmeq.4s	v21, v21, v21
    1064:      	bsl.16b	v21, v23, v26
    1068:      	ld1.b	{ v25 }[6], [x17]
    106c:      	ld1.b	{ v25 }[7], [x16]
    1070:      	cmeq.8b	v23, v25, #0
    1074:      	sshll.8h	v23, v23, #0x0
    1078:      	fcmeq.4s	v20, v20, v20
    107c:      	bsl.16b	v20, v22, v26
    1080:      	sshll.4s	v22, v23, #0x0
    1084:      	bic.16b	v20, v20, v22
    1088:      	sshll2.4s	v22, v23, #0x0
    108c:      	bic.16b	v21, v21, v22
    1090:      	add	x9, x23, x14
    1094:      	stp	q20, q21, [x9]
    1098:      	dup.2d	v20, x25
    109c:      	add.2d	v18, v18, v20
    10a0:      	add.2d	v17, v17, v20
    10a4:      	add.2d	v19, v19, v20
    10a8:      	add.2d	v16, v16, v20
    10ac:      	fmov	x14, d16
    10b0:      	cmp	x14, #0xc0
    10b4:      	b.lt	0xe98 <ltmp0+0xe98>
    10b8:      	mov	x9, #0x0                ; =0
    10bc:      	ldp	q0, q2, [sp, #0x370]
    10c0:      	dup.4s	v0, v0[0]
    10c4:      	ldr	q1, [sp, #0x390]
    10c8:      	sshll.4s	v1, v1, #0x0
    10cc:      	fsub.4s	v0, v2, v0
    10d0:      	movi.2d	v2, #0000000000000000
    10d4:      	mov.d	v2[0], v0[0]
    10d8:      	fcmge.4s	v0, v2, v13
    10dc:      	fcmge.4s	v3, v12, v2
    10e0:      	and.16b	v0, v0, v3
    10e4:      	and.16b	v0, v0, v2
    10e8:      	fmul.4s	v3, v0, v4
    10ec:      	mov.16b	v4, v28
    10f0:      	bsl.16b	v4, v27, v3
    10f4:      	fadd.4s	v3, v3, v4
    10f8:      	fsub.4s	v3, v3, v4
    10fc:      	fcvtzs.4s	v3, v3
    1100:      	scvtf.4s	v4, v3
    1104:      	fmul.4s	v5, v4, v5
    1108:      	fadd.4s	v0, v0, v5
    110c:      	fmul.4s	v4, v4, v31
    1110:      	fadd.4s	v0, v0, v4
    1114:      	fmul.4s	v4, v0, v30
    1118:      	fadd.4s	v4, v4, v9
    111c:      	fmul.4s	v4, v0, v4
    1120:      	fadd.4s	v4, v4, v8
    1124:      	fmul.4s	v4, v0, v4
    1128:      	fadd.4s	v4, v4, v6
    112c:      	fmul.4s	v4, v0, v4
    1130:      	fadd.4s	v4, v4, v14
    1134:      	fmul.4s	v4, v0, v4
    1138:      	fadd.4s	v4, v4, v11
    113c:      	fmul.4s	v5, v0, v0
    1140:      	fmul.4s	v4, v5, v4
    1144:      	fadd.4s	v0, v0, v4
    1148:      	fadd.4s	v0, v0, v15
    114c:      	sshr.4s	v4, v3, #0x1
    1150:      	shl.4s	v5, v4, #0x17
    1154:      	add.4s	v5, v5, v15
    1158:      	fmul.4s	v0, v0, v5
    115c:      	sub.4s	v3, v3, v4
    1160:      	shl.4s	v3, v3, #0x17
    1164:      	add.4s	v3, v3, v15
    1168:      	fmul.4s	v0, v0, v3
    116c:      	fcmgt.4s	v3, v13, v2
    1170:      	bic.16b	v0, v0, v3
    1174:      	fcmgt.4s	v3, v2, v12
    1178:      	bit.16b	v0, v10, v3
    117c:      	fcmeq.4s	v2, v2, v2
    1180:      	bif.16b	v0, v26, v2
    1184:      	bic.16b	v0, v0, v1
    1188:      	ldr	q1, [x23, #0x1800]
    118c:      	mov.d	v0[1], v1[1]
    1190:      	str	q0, [x23, #0x1800]
    1194:      	ldp	q7, q1, [x23]
    1198:      	ldp	q5, q6, [x23, #0x20]
    119c:      	ldp	q16, q2, [x23, #0x40]
    11a0:      	ldp	q3, q4, [x23, #0x60]
    11a4:      	add	x10, x23, x9, lsl #5
    11a8:      	ldp	q17, q18, [x10, #0x80]
    11ac:      	fadd.4s	v1, v1, v18
    11b0:      	fadd.4s	v7, v7, v17
    11b4:      	ldp	q17, q18, [x10, #0xa0]
    11b8:      	fadd.4s	v6, v6, v18
    11bc:      	fadd.4s	v5, v5, v17
    11c0:      	ldp	q17, q18, [x10, #0xc0]
    11c4:      	fadd.4s	v2, v2, v18
    11c8:      	fadd.4s	v16, v16, v17
    11cc:      	ldp	q17, q18, [x10, #0xe0]
    11d0:      	fadd.4s	v4, v4, v18
    11d4:      	fadd.4s	v3, v3, v17
    11d8:      	add	x9, x9, #0x4
    11dc:      	cmp	x9, #0xbc
    11e0:      	b.lo	0x11a4 <ltmp0+0x11a4>
    11e4:      	mov	x9, #0x0                ; =0
    11e8:      	fadd.4s	v17, v0, v7
    11ec:      	mov.d	v17[1], v7[1]
    11f0:      	fadd.4s	v1, v6, v1
    11f4:      	fadd.4s	v5, v5, v17
    11f8:      	fadd.4s	v5, v16, v5
    11fc:      	fadd.4s	v1, v2, v1
    1200:      	fadd.4s	v1, v4, v1
    1204:      	fadd.4s	v2, v3, v5
    1208:      	rev64.4s	v3, v2
    120c:      	rev64.4s	v4, v1
    1210:      	fadd.4s	v1, v1, v4
    1214:      	fadd.4s	v2, v2, v3
    1218:      	dup.4s	v3, v2[2]
    121c:      	dup.4s	v4, v1[2]
    1220:      	fadd.4s	v1, v1, v4
    1224:      	fadd.4s	v2, v2, v3
    1228:      	fadd.4s	v1, v2, v1
    122c:      	movi	d2, #0000000000000000
    1230:      	fadd	s1, s1, s2
    1234:      	dup.4s	v2, v1[0]
    1238:      	movi.8b	v8, #0x1
    123c:      	lsl	x10, x9, #5
    1240:      	add	x11, x23, x10
    1244:      	ldp	q4, q3, [x11]
    1248:      	fdiv.4s	v4, v4, v2
    124c:      	fdiv.4s	v3, v3, v2
    1250:      	add	x10, x26, x10
    1254:      	stp	q4, q3, [x10]
    1258:      	add	x9, x9, #0x1
    125c:      	cmp	x9, #0xc0
    1260:      	b.ne	0x123c <ltmp0+0x123c>
    1264:      	dup.2s	v1, v1[0]
    1268:      	fdiv.2s	v0, v0, v1
    126c:      	ldr	x9, [sp, #0x220]
    1270:      	str	d0, [x9, x8]
    1274:      	ldr	x10, [sp, #0x3a0]
    1278:      	add	x10, x10, #0x1
    127c:      	add	x26, x26, x0
    1280:      	ldr	x8, [sp, #0x240]
    1284:      	cmp	x10, x8
    1288:      	b.ne	0xab4 <ltmp0+0xab4>
    128c:      	ldr	x8, [sp, #0x1f0]
    1290:      	and	w8, w8, #0x7
    1294:      	adrp	x24, 0x1000 <ltmp0+0x1000>
    1298:      	cbz	w8, 0x110 <ltmp0+0x110>
    129c:      	dup.4s	v20, w8
    12a0:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    12a4:      	ldr	q4, [x8]
    12a8:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    12ac:      	ldr	q5, [x8]
    12b0:      	cmhi.4s	v0, v20, v5
    12b4:      	cmhi.4s	v1, v20, v4
    12b8:      	uzp1.8h	v3, v1, v0
    12bc:      	umaxv.8h	h2, v3
    12c0:      	fmov	w8, s2
    12c4:      	tbz	w8, #0x0, 0x110 <ltmp0+0x110>
    12c8:      	str	q5, [sp, #0x110]
    12cc:      	str	q4, [sp, #0x1f0]
    12d0:      	mov	x8, #0x0                ; =0
    12d4:      	ldr	x9, [sp, #0x180]
    12d8:      	ldr	x10, [x9]
    12dc:      	ldr	x14, [x9, #0x30]
    12e0:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    12e4:      	ldr	q2, [x9]
    12e8:      	and.16b	v2, v3, v2
    12ec:      	addv.8h	h19, v2
    12f0:      	ldr	x9, [sp, #0x1a8]
    12f4:      	ubfiz	w9, w9, #2, #27
    12f8:      	ldr	x11, [sp, #0x240]
    12fc:      	orr	w9, w9, w11
    1300:      	fmov	w11, s19
    1304:      	and	w11, w11, #0xff
    1308:      	str	w11, [sp, #0x9c]
    130c:      	dup.4s	v2, w9
    1310:      	and.16b	v25, v1, v2
    1314:      	and.16b	v26, v0, v2
    1318:      	ushll2.2d	v16, v26, #0x0
    131c:      	ushll2.2d	v22, v25, #0x0
    1320:      	ushll.2d	v18, v26, #0x0
    1324:      	ushll.2d	v5, v25, #0x0
    1328:      	fmov	x9, d5
    132c:      	umaddl	x9, w9, w0, x10
    1330:      	ldp	q13, q12, [sp, #0x290]
    1334:      	ldp	q15, q14, [sp, #0x270]
    1338:      	b	0x135c <ltmp0+0x135c>
    133c:      	add	x11, x28, x8, lsl #5
    1340:      	ldp	q2, q7, [x11]
    1344:      	bif.16b	v6, v7, v0
    1348:      	bit.16b	v2, v4, v1
    134c:      	stp	q2, q6, [x11]
    1350:      	add	x8, x8, #0x1
    1354:      	cmp	x8, #0xc0
    1358:      	b.eq	0x13f4 <ltmp0+0x13f4>
    135c:      	fmov	w12, s19
    1360:      	add	x11, x9, x8, lsl #5
    1364:      	movi.2d	v4, #0000000000000000
    1368:      	movi.2d	v6, #0000000000000000
    136c:      	tbnz	w12, #0x0, 0x1394 <ltmp0+0x1394>
    1370:      	and	w12, w12, #0xff
    1374:      	tbnz	w12, #0x1, 0x13a0 <ltmp0+0x13a0>
    1378:      	tbnz	w12, #0x2, 0x13ac <ltmp0+0x13ac>
    137c:      	tbnz	w12, #0x3, 0x13b8 <ltmp0+0x13b8>
    1380:      	tbnz	w12, #0x4, 0x13c4 <ltmp0+0x13c4>
    1384:      	tbnz	w12, #0x5, 0x13d0 <ltmp0+0x13d0>
    1388:      	tbnz	w12, #0x6, 0x13dc <ltmp0+0x13dc>
    138c:      	tbz	w12, #0x7, 0x133c <ltmp0+0x133c>
    1390:      	b	0x13e8 <ltmp0+0x13e8>
    1394:      	ldr	s4, [x11]
    1398:      	and	w12, w12, #0xff
    139c:      	tbz	w12, #0x1, 0x1378 <ltmp0+0x1378>
    13a0:      	add	x13, x11, #0x4
    13a4:      	ld1.s	{ v4 }[1], [x13]
    13a8:      	tbz	w12, #0x2, 0x137c <ltmp0+0x137c>
    13ac:      	add	x13, x11, #0x8
    13b0:      	ld1.s	{ v4 }[2], [x13]
    13b4:      	tbz	w12, #0x3, 0x1380 <ltmp0+0x1380>
    13b8:      	add	x13, x11, #0xc
    13bc:      	ld1.s	{ v4 }[3], [x13]
    13c0:      	tbz	w12, #0x4, 0x1384 <ltmp0+0x1384>
    13c4:      	add	x13, x11, #0x10
    13c8:      	ld1.s	{ v6 }[0], [x13]
    13cc:      	tbz	w12, #0x5, 0x1388 <ltmp0+0x1388>
    13d0:      	add	x13, x11, #0x14
    13d4:      	ld1.s	{ v6 }[1], [x13]
    13d8:      	tbz	w12, #0x6, 0x138c <ltmp0+0x138c>
    13dc:      	add	x13, x11, #0x18
    13e0:      	ld1.s	{ v6 }[2], [x13]
    13e4:      	tbz	w12, #0x7, 0x133c <ltmp0+0x133c>
    13e8:      	add	x11, x11, #0x1c
    13ec:      	ld1.s	{ v6 }[3], [x11]
    13f0:      	b	0x133c <ltmp0+0x133c>
    13f4:      	str	q19, [sp, #0x230]
    13f8:      	xtn.8b	v3, v3
    13fc:      	sshll.2d	v4, v1, #0x0
    1400:      	and.16b	v6, v4, v15
    1404:      	movi	d2, #0x0000000000ffff
    1408:      	and.8b	v21, v3, v2
    140c:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1410:      	ldr	d2, [x8]
    1414:      	str	q3, [sp, #0x160]
    1418:      	and.8b	v2, v3, v2
    141c:      	addv.8b	b2, v2
    1420:      	fmov	w8, s2
    1424:      	umaxv.8b	b2, v21
    1428:      	fmov	w9, s2
    142c:      	rbit	w11, w8
    1430:      	clz	w11, w11
    1434:      	tst	w9, #0x1
    1438:      	csel	w2, w11, wzr, ne
    143c:      	mov	w9, #0x600              ; =1536
    1440:      	dup.2d	v29, x9
    1444:      	str	q6, [sp, #0x130]
    1448:      	orr.16b	v27, v6, v29
    144c:      	mov	w9, #0x602              ; =1538
    1450:      	dup.2s	v19, w9
    1454:      	xtn.2s	v31, v5
    1458:      	mov.16b	v3, v27
    145c:      	umlal.2d	v3, v31, v19
    1460:      	mov	b2, v21[0]
    1464:      	mov.b	v2[4], v21[1]
    1468:      	ushll.2d	v2, v2, #0x0
    146c:      	shl.2d	v2, v2, #0x3f
    1470:      	cmlt.2d	v2, v2, #0
    1474:      	str	q3, [sp, #0xf0]
    1478:      	and.16b	v2, v2, v3
    147c:      	movi.2d	v3, #0000000000000000
    1480:      	str	q3, [sp, #0xa60]
    1484:      	str	q3, [sp, #0xa50]
    1488:      	str	q3, [sp, #0xa40]
    148c:      	str	q2, [sp, #0xa30]
    1490:      	and	x9, x2, #0x7
    1494:      	add	x11, sp, #0xa30
    1498:      	ldr	x9, [x11, x9, lsl #3]
    149c:      	sub	x9, x9, x2
    14a0:      	add	x10, x10, x9, lsl #2
    14a4:      	movi.2d	v24, #0000000000000000
    14a8:      	movi.2d	v28, #0000000000000000
    14ac:      	tbnz	w8, #0x0, 0x1c08 <ltmp0+0x1c08>
    14b0:      	tbnz	w8, #0x1, 0x1c10 <ltmp0+0x1c10>
    14b4:      	tbnz	w8, #0x2, 0x1c1c <ltmp0+0x1c1c>
    14b8:      	tbnz	w8, #0x3, 0x1c28 <ltmp0+0x1c28>
    14bc:      	tbnz	w8, #0x4, 0x1c34 <ltmp0+0x1c34>
    14c0:      	tbnz	w8, #0x5, 0x1c40 <ltmp0+0x1c40>
    14c4:      	tbnz	w8, #0x6, 0x1c4c <ltmp0+0x1c4c>
    14c8:      	tbz	w8, #0x7, 0x14d4 <ltmp0+0x14d4>
    14cc:      	add	x9, x10, #0x1c
    14d0:      	ld1.s	{ v28 }[3], [x9]
    14d4:      	str	x14, [sp, #0x108]
    14d8:      	mov	x10, #0x0               ; =0
    14dc:      	sshll.2d	v2, v0, #0x0
    14e0:      	sshll2.2d	v17, v1, #0x0
    14e4:      	sshll2.2d	v23, v0, #0x0
    14e8:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    14ec:      	ldr	q3, [x9]
    14f0:      	and.16b	v3, v23, v3
    14f4:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    14f8:      	ldr	q5, [x9]
    14fc:      	and.16b	v5, v17, v5
    1500:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1504:      	ldr	q6, [x9]
    1508:      	and.16b	v6, v2, v6
    150c:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1510:      	ldr	q7, [x9]
    1514:      	and.16b	v4, v4, v7
    1518:      	str	q4, [sp, #0x80]
    151c:      	str	q4, [sp, #0x9f0]
    1520:      	str	q5, [sp, #0xa00]
    1524:      	str	q6, [sp, #0xa10]
    1528:      	str	q3, [sp, #0xa20]
    152c:      	and	x9, x2, #0x7
    1530:      	add	x11, sp, #0x9f0
    1534:      	ldr	x9, [x11, x9, lsl #3]
    1538:      	orr	x9, x9, #0x1800
    153c:      	sub	x9, x9, x2, lsl #2
    1540:      	tst	w8, #0xff
    1544:      	csel	x4, xzr, x9, eq
    1548:      	add	x9, x28, x4
    154c:      	ldp	q3, q4, [x9]
    1550:      	zip2.8b	v5, v21, v0
    1554:      	ushll.4s	v5, v5, #0x0
    1558:      	shl.4s	v5, v5, #0x1f
    155c:      	cmlt.4s	v5, v5, #0
    1560:      	str	q28, [sp, #0x120]
    1564:      	bit.16b	v4, v28, v5
    1568:      	str	q21, [sp, #0x170]
    156c:      	zip1.8b	v5, v21, v0
    1570:      	ushll.4s	v5, v5, #0x0
    1574:      	shl.4s	v5, v5, #0x1f
    1578:      	cmlt.4s	v5, v5, #0
    157c:      	str	q24, [sp, #0x220]
    1580:      	bit.16b	v3, v24, v5
    1584:      	stp	q3, q4, [x9]
    1588:      	and.16b	v3, v23, v12
    158c:      	and.16b	v4, v17, v14
    1590:      	and.16b	v2, v2, v13
    1594:      	stp	q2, q4, [sp, #0x50]
    1598:      	orr.16b	v28, v2, v29
    159c:      	orr.16b	v30, v4, v29
    15a0:      	str	q3, [sp, #0x70]
    15a4:      	orr.16b	v29, v3, v29
    15a8:      	umull.2d	v6, v31, v19
    15ac:      	xtn.2s	v2, v22
    15b0:      	xtn.2s	v3, v18
    15b4:      	mov.16b	v18, v23
    15b8:      	xtn.2s	v4, v16
    15bc:      	mov.16b	v5, v29
    15c0:      	umlal.2d	v5, v4, v19
    15c4:      	mov.16b	v4, v30
    15c8:      	umlal.2d	v4, v2, v19
    15cc:      	stp	q4, q5, [sp, #0xd0]
    15d0:      	mov.16b	v2, v28
    15d4:      	umlal.2d	v2, v3, v19
    15d8:      	stp	q6, q2, [sp, #0xb0]
    15dc:      	dup.2d	v2, x25
    15e0:      	ushll2.2d	v3, v0, #0x0
    15e4:      	and.16b	v19, v3, v2
    15e8:      	ushll2.2d	v3, v1, #0x0
    15ec:      	and.16b	v31, v3, v2
    15f0:      	ushll.2d	v3, v0, #0x0
    15f4:      	and.16b	v9, v3, v2
    15f8:      	ushll.2d	v3, v1, #0x0
    15fc:      	and.16b	v16, v3, v2
    1600:      	movi.2d	v2, #0000000000000000
    1604:      	movi.2d	v3, #0000000000000000
    1608:      	movi.2d	v4, #0000000000000000
    160c:      	movi.2d	v5, #0000000000000000
    1610:      	str	q31, [sp, #0x370]
    1614:      	str	q9, [sp, #0x240]
    1618:      	sshll.2d	v6, v0, #0x0
    161c:      	sshll.2d	v7, v1, #0x0
    1620:      	shl.2d	v21, v5, #0x3
    1624:      	shl.2d	v22, v2, #0x3
    1628:      	shl.2d	v23, v4, #0x3
    162c:      	shl.2d	v24, v3, #0x3
    1630:      	orr.16b	v24, v24, v14
    1634:      	orr.16b	v23, v23, v13
    1638:      	orr.16b	v22, v22, v15
    163c:      	orr.16b	v21, v21, v12
    1640:      	add	x9, x19, x10, lsl #6
    1644:      	ldp	q9, q31, [x9]
    1648:      	ldp	q10, q11, [x9, #0x20]
    164c:      	bif.16b	v21, v11, v18
    1650:      	bsl.16b	v7, v22, v9
    1654:      	ldr	q9, [sp, #0x240]
    1658:      	bsl.16b	v6, v23, v10
    165c:      	mov.16b	v22, v17
    1660:      	bsl.16b	v22, v24, v31
    1664:      	ldr	q31, [sp, #0x370]
    1668:      	stp	q7, q22, [x9]
    166c:      	stp	q6, q21, [x9, #0x20]
    1670:      	add.2d	v3, v3, v31
    1674:      	add.2d	v4, v4, v9
    1678:      	add.2d	v5, v5, v19
    167c:      	add.2d	v2, v2, v16
    1680:      	fmov	x10, d2
    1684:      	cmp	x10, #0xc0
    1688:      	b.lt	0x1618 <ltmp0+0x1618>
    168c:      	mov	x10, #0x0               ; =0
    1690:      	mov	w9, #0x602              ; =1538
    1694:      	dup.4s	v2, w9
    1698:      	and.16b	v3, v1, v2
    169c:      	mvn.16b	v4, v1
    16a0:      	sub.4s	v3, v3, v4
    16a4:      	and.16b	v2, v0, v2
    16a8:      	mvn.16b	v4, v0
    16ac:      	sub.4s	v2, v2, v4
    16b0:      	mov.s	w9, v2[1]
    16b4:      	mov.s	w11, v26[1]
    16b8:      	udiv	w12, w11, w9
    16bc:      	msub	w11, w12, w9, w11
    16c0:      	mov.s	w9, v2[2]
    16c4:      	mov.s	w12, v2[3]
    16c8:      	fmov	w13, s2
    16cc:      	fmov	w14, s26
    16d0:      	udiv	w15, w14, w13
    16d4:      	msub	w13, w15, w13, w14
    16d8:      	mov.s	w14, v26[2]
    16dc:      	udiv	w15, w14, w9
    16e0:      	msub	w14, w15, w9, w14
    16e4:      	mov.s	w9, v26[3]
    16e8:      	udiv	w15, w9, w12
    16ec:      	msub	w12, w15, w12, w9
    16f0:      	mov.s	w9, v3[1]
    16f4:      	mov.s	w15, v25[1]
    16f8:      	udiv	w16, w15, w9
    16fc:      	msub	w15, w16, w9, w15
    1700:      	mov.s	w9, v3[2]
    1704:      	mov.s	w16, v3[3]
    1708:      	fmov	w17, s3
    170c:      	fmov	w0, s25
    1710:      	udiv	w1, w0, w17
    1714:      	msub	w17, w1, w17, w0
    1718:      	mov.s	w0, v25[2]
    171c:      	udiv	w1, w0, w9
    1720:      	msub	w9, w1, w9, w0
    1724:      	mov.s	w0, v25[3]
    1728:      	udiv	w1, w0, w16
    172c:      	msub	w16, w1, w16, w0
    1730:      	tst	w8, #0xff
    1734:      	fmov	s5, w13
    1738:      	mov.s	v5[1], w11
    173c:      	mov.s	v5[2], w14
    1740:      	mov.s	v5[3], w12
    1744:      	fmov	s21, w17
    1748:      	sshll.2d	v3, v0, #0x0
    174c:      	sshll.2d	v2, v1, #0x0
    1750:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1754:      	ldr	q4, [x8]
    1758:      	and.16b	v4, v2, v4
    175c:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1760:      	ldr	q6, [x8]
    1764:      	and.16b	v6, v3, v6
    1768:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    176c:      	ldr	q7, [x8]
    1770:      	and.16b	v7, v17, v7
    1774:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1778:      	ldr	q22, [x8]
    177c:      	and.16b	v22, v18, v22
    1780:      	str	q22, [sp, #0x9e0]
    1784:      	str	q6, [sp, #0x9d0]
    1788:      	str	q7, [sp, #0x9c0]
    178c:      	str	q4, [sp, #0x9b0]
    1790:      	mov.s	v21[1], w15
    1794:      	and	x8, x2, #0x7
    1798:      	add	x11, sp, #0x9b0
    179c:      	ldr	x8, [x11, x8, lsl #3]
    17a0:      	orr	x8, x8, #0x3000
    17a4:      	sub	x8, x8, x2, lsl #3
    17a8:      	csel	x8, xzr, x8, eq
    17ac:      	add	x8, x19, x8
    17b0:      	ldp	q7, q6, [x8, #0x20]
    17b4:      	mov.16b	v25, v18
    17b8:      	ldr	q18, [sp, #0x170]
    17bc:      	mov	b4, v18[2]
    17c0:      	mov.b	v4[4], v18[3]
    17c4:      	ldp	q22, q23, [x8]
    17c8:      	ushll.2d	v4, v4, #0x0
    17cc:      	shl.2d	v4, v4, #0x3f
    17d0:      	cmlt.2d	v4, v4, #0
    17d4:      	mov.16b	v14, v4
    17d8:      	bsl.16b	v14, v30, v23
    17dc:      	mov	b4, v18[0]
    17e0:      	mov.b	v4[4], v18[1]
    17e4:      	ushll.2d	v4, v4, #0x0
    17e8:      	shl.2d	v4, v4, #0x3f
    17ec:      	cmlt.2d	v4, v4, #0
    17f0:      	bsl.16b	v4, v27, v22
    17f4:      	mov	b22, v18[6]
    17f8:      	mov.b	v22[4], v18[7]
    17fc:      	ushll.2d	v22, v22, #0x0
    1800:      	shl.2d	v22, v22, #0x3f
    1804:      	cmlt.2d	v22, v22, #0
    1808:      	bit.16b	v6, v29, v22
    180c:      	mov	b22, v18[4]
    1810:      	mov.b	v22[4], v18[5]
    1814:      	ushll.2d	v22, v22, #0x0
    1818:      	shl.2d	v22, v22, #0x3f
    181c:      	cmlt.2d	v22, v22, #0
    1820:      	bit.16b	v7, v28, v22
    1824:      	mov.s	v21[2], w9
    1828:      	mov.s	v21[3], w16
    182c:      	and.16b	v21, v1, v21
    1830:      	stp	q7, q6, [x8, #0x20]
    1834:      	stp	q4, q14, [x8]
    1838:      	and.16b	v5, v0, v5
    183c:      	ushll2.2d	v15, v5, #0x0
    1840:      	ushll2.2d	v11, v21, #0x0
    1844:      	ushll.2d	v24, v5, #0x0
    1848:      	ushll.2d	v13, v21, #0x0
    184c:      	ldr	q5, [sp, #0x2b0]
    1850:      	and.16b	v27, v25, v5
    1854:      	and.16b	v28, v17, v5
    1858:      	and.16b	v29, v3, v5
    185c:      	and.16b	v30, v2, v5
    1860:      	ldr	q5, [x24]
    1864:      	str	q25, [sp, #0x140]
    1868:      	and.16b	v12, v25, v5
    186c:      	ldr	q5, [x3]
    1870:      	str	q17, [sp, #0x150]
    1874:      	and.16b	v5, v17, v5
    1878:      	str	q5, [sp, #0x3a0]
    187c:      	ldr	q5, [x27]
    1880:      	and.16b	v3, v3, v5
    1884:      	str	q3, [sp, #0x390]
    1888:      	ldr	q3, [x22]
    188c:      	and.16b	v2, v2, v3
    1890:      	str	q2, [sp, #0x380]
    1894:      	ldr	q2, [sp, #0x110]
    1898:      	cmhs.4s	v2, v2, v20
    189c:      	ldr	q3, [sp, #0x1f0]
    18a0:      	cmhs.4s	v3, v3, v20
    18a4:      	uzp1.8h	v2, v3, v2
    18a8:      	xtn.8b	v20, v2
    18ac:      	movi.2d	v21, #0000000000000000
    18b0:      	movi.2d	v5, #0000000000000000
    18b4:      	movi.2d	v10, #0000000000000000
    18b8:      	movi.2d	v3, #0000000000000000
    18bc:      	mov	w15, #0x4               ; =4
    18c0:      	ldr	q17, [sp, #0x230]
    18c4:      	mov.16b	v26, v16
    18c8:      	b	0x18e8 <ltmp0+0x18e8>
    18cc:      	add.2d	v5, v5, v31
    18d0:      	add.2d	v10, v10, v9
    18d4:      	add.2d	v3, v3, v19
    18d8:      	add.2d	v21, v21, v26
    18dc:      	fmov	x10, d21
    18e0:      	cmp	x10, #0xc0
    18e4:      	b.ge	0x19f8 <ltmp0+0x19f8>
    18e8:      	fmov	w8, s17
    18ec:      	add	x9, x19, x10, lsl #6
    18f0:      	ldp	q22, q2, [x9, #0x20]
    18f4:      	ldp	q23, q25, [x9]
    18f8:      	cmge.2d	v25, v11, v25
    18fc:      	cmge.2d	v23, v13, v23
    1900:      	uzp1.4s	v23, v23, v25
    1904:      	cmge.2d	v22, v24, v22
    1908:      	cmge.2d	v2, v15, v2
    190c:      	uzp1.4s	v2, v22, v2
    1910:      	uzp1.8h	v2, v23, v2
    1914:      	xtn.8b	v2, v2
    1918:      	orr.8b	v2, v20, v2
    191c:      	ldr	q16, [sp, #0x380]
    1920:      	add.2d	v22, v21, v16
    1924:      	add.2d	v22, v30, v22
    1928:      	and.8b	v2, v2, v8
    192c:      	tbnz	w8, #0x0, 0x1974 <ltmp0+0x1974>
    1930:      	and	w8, w8, #0xff
    1934:      	tbnz	w8, #0x1, 0x1984 <ltmp0+0x1984>
    1938:      	ldr	q16, [sp, #0x3a0]
    193c:      	add.2d	v22, v5, v16
    1940:      	add.2d	v22, v28, v22
    1944:      	tbnz	w8, #0x2, 0x199c <ltmp0+0x199c>
    1948:      	tbnz	w8, #0x3, 0x19a8 <ltmp0+0x19a8>
    194c:      	ldr	q16, [sp, #0x390]
    1950:      	add.2d	v22, v10, v16
    1954:      	add.2d	v22, v29, v22
    1958:      	tbnz	w8, #0x4, 0x19c0 <ltmp0+0x19c0>
    195c:      	tbnz	w8, #0x5, 0x19cc <ltmp0+0x19cc>
    1960:      	add.2d	v22, v3, v12
    1964:      	add.2d	v22, v27, v22
    1968:      	tbnz	w8, #0x6, 0x19e0 <ltmp0+0x19e0>
    196c:      	tbz	w8, #0x7, 0x18cc <ltmp0+0x18cc>
    1970:      	b	0x19ec <ltmp0+0x19ec>
    1974:      	fmov	x9, d22
    1978:      	str	b2, [x9]
    197c:      	and	w8, w8, #0xff
    1980:      	tbz	w8, #0x1, 0x1938 <ltmp0+0x1938>
    1984:      	mov.d	x9, v22[1]
    1988:      	st1.b	{ v2 }[1], [x9]
    198c:      	ldr	q16, [sp, #0x3a0]
    1990:      	add.2d	v22, v5, v16
    1994:      	add.2d	v22, v28, v22
    1998:      	tbz	w8, #0x2, 0x1948 <ltmp0+0x1948>
    199c:      	fmov	x9, d22
    19a0:      	st1.b	{ v2 }[2], [x9]
    19a4:      	tbz	w8, #0x3, 0x194c <ltmp0+0x194c>
    19a8:      	mov.d	x9, v22[1]
    19ac:      	st1.b	{ v2 }[3], [x9]
    19b0:      	ldr	q16, [sp, #0x390]
    19b4:      	add.2d	v22, v10, v16
    19b8:      	add.2d	v22, v29, v22
    19bc:      	tbz	w8, #0x4, 0x195c <ltmp0+0x195c>
    19c0:      	fmov	x9, d22
    19c4:      	st1.b	{ v2 }[4], [x9]
    19c8:      	tbz	w8, #0x5, 0x1960 <ltmp0+0x1960>
    19cc:      	mov.d	x9, v22[1]
    19d0:      	st1.b	{ v2 }[5], [x9]
    19d4:      	add.2d	v22, v3, v12
    19d8:      	add.2d	v22, v27, v22
    19dc:      	tbz	w8, #0x6, 0x196c <ltmp0+0x196c>
    19e0:      	fmov	x9, d22
    19e4:      	st1.b	{ v2 }[6], [x9]
    19e8:      	tbz	w8, #0x7, 0x18cc <ltmp0+0x18cc>
    19ec:      	mov.d	x8, v22[1]
    19f0:      	st1.b	{ v2 }[7], [x8]
    19f4:      	b	0x18cc <ltmp0+0x18cc>
    19f8:      	cmge.2d	v2, v13, v4
    19fc:      	cmge.2d	v3, v11, v14
    1a00:      	uzp1.4s	v2, v2, v3
    1a04:      	cmge.2d	v3, v24, v7
    1a08:      	cmge.2d	v4, v15, v6
    1a0c:      	uzp1.4s	v3, v3, v4
    1a10:      	uzp1.8h	v2, v2, v3
    1a14:      	xtn.8b	v2, v2
    1a18:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1a1c:      	ldr	d3, [x8]
    1a20:      	shl.8b	v4, v18, #0x7
    1a24:      	cmlt.8b	v4, v4, #0
    1a28:      	and.8b	v3, v4, v3
    1a2c:      	addv.8b	b22, v3
    1a30:      	fmov	w9, s22
    1a34:      	orn.8b	v2, v2, v18
    1a38:      	ldr	q3, [sp, #0x380]
    1a3c:      	add.2d	v4, v3, v30
    1a40:      	mov	w8, #0xc0               ; =192
    1a44:      	dup.2d	v3, x8
    1a48:      	add.2d	v14, v4, v3
    1a4c:      	and.8b	v2, v2, v8
    1a50:      	ldr	q16, [sp, #0x2c0]
    1a54:      	tbnz	w9, #0x0, 0x1c5c <ltmp0+0x1c5c>
    1a58:      	mov.d	x12, v14[1]
    1a5c:      	tbnz	w9, #0x1, 0x1c6c <ltmp0+0x1c6c>
    1a60:      	ldr	q4, [sp, #0x3a0]
    1a64:      	add.2d	v4, v4, v28
    1a68:      	add.2d	v13, v4, v3
    1a6c:      	tbnz	w9, #0x2, 0x1c80 <ltmp0+0x1c80>
    1a70:      	mov.d	x11, v13[1]
    1a74:      	tbnz	w9, #0x3, 0x1c90 <ltmp0+0x1c90>
    1a78:      	ldr	q4, [sp, #0x390]
    1a7c:      	add.2d	v4, v4, v29
    1a80:      	add.2d	v24, v4, v3
    1a84:      	tbnz	w9, #0x4, 0x1ca4 <ltmp0+0x1ca4>
    1a88:      	mov.d	x10, v24[1]
    1a8c:      	tbnz	w9, #0x5, 0x1cb4 <ltmp0+0x1cb4>
    1a90:      	add.2d	v4, v12, v27
    1a94:      	add.2d	v20, v4, v3
    1a98:      	tbnz	w9, #0x6, 0x1cc4 <ltmp0+0x1cc4>
    1a9c:      	mov.d	x8, v20[1]
    1aa0:      	tbz	w9, #0x7, 0x1aa8 <ltmp0+0x1aa8>
    1aa4:      	st1.b	{ v2 }[7], [x8]
    1aa8:      	mov	x13, #0x0               ; =0
    1aac:      	movi.2d	v15, #0000000000000000
    1ab0:      	movi.2d	v6, #0000000000000000
    1ab4:      	movi.2d	v4, #0000000000000000
    1ab8:      	movi.2d	v7, #0000000000000000
    1abc:      	b	0x1b1c <ltmp0+0x1b1c>
    1ac0:      	cmeq.8b	v2, v21, #0
    1ac4:      	sshll.8h	v2, v2, #0x0
    1ac8:      	sshll2.4s	v3, v2, #0x0
    1acc:      	sshll.4s	v2, v2, #0x0
    1ad0:      	lsl	x9, x13, #5
    1ad4:      	add	x13, x28, x9
    1ad8:      	ldp	q5, q21, [x13]
    1adc:      	and.16b	v21, v0, v21
    1ae0:      	and.16b	v5, v1, v5
    1ae4:      	bsl.16b	v2, v16, v5
    1ae8:      	bsl.16b	v3, v16, v21
    1aec:      	add	x9, x20, x9
    1af0:      	ldp	q5, q21, [x9]
    1af4:      	bif.16b	v3, v21, v0
    1af8:      	bif.16b	v2, v5, v1
    1afc:      	stp	q2, q3, [x9]
    1b00:      	add.2d	v6, v6, v31
    1b04:      	add.2d	v4, v4, v9
    1b08:      	add.2d	v7, v7, v19
    1b0c:      	add.2d	v15, v15, v26
    1b10:      	fmov	x13, d15
    1b14:      	cmp	x13, #0xc0
    1b18:      	b.ge	0x1bf0 <ltmp0+0x1bf0>
    1b1c:      	fmov	w9, s17
    1b20:      	ldr	q2, [sp, #0x380]
    1b24:      	add.2d	v2, v15, v2
    1b28:      	add.2d	v2, v30, v2
    1b2c:      	tbz	w9, #0x0, 0x1b44 <ltmp0+0x1b44>
    1b30:      	fmov	x14, d2
    1b34:      	ldr	b21, [x14]
    1b38:      	and	w14, w9, #0xff
    1b3c:      	tbnz	w14, #0x1, 0x1b50 <ltmp0+0x1b50>
    1b40:      	b	0x1b58 <ltmp0+0x1b58>
    1b44:      	movi.2d	v21, #0000000000000000
    1b48:      	and	w14, w9, #0xff
    1b4c:      	tbz	w14, #0x1, 0x1b58 <ltmp0+0x1b58>
    1b50:      	mov.d	x9, v2[1]
    1b54:      	ld1.b	{ v21 }[1], [x9]
    1b58:      	ldr	q2, [sp, #0x3a0]
    1b5c:      	add.2d	v2, v6, v2
    1b60:      	add.2d	v2, v28, v2
    1b64:      	tbnz	w14, #0x2, 0x1b94 <ltmp0+0x1b94>
    1b68:      	tbnz	w14, #0x3, 0x1ba0 <ltmp0+0x1ba0>
    1b6c:      	ldr	q2, [sp, #0x390]
    1b70:      	add.2d	v2, v4, v2
    1b74:      	add.2d	v2, v29, v2
    1b78:      	tbnz	w14, #0x4, 0x1bb8 <ltmp0+0x1bb8>
    1b7c:      	tbnz	w14, #0x5, 0x1bc4 <ltmp0+0x1bc4>
    1b80:      	add.2d	v2, v7, v12
    1b84:      	add.2d	v2, v27, v2
    1b88:      	tbnz	w14, #0x6, 0x1bd8 <ltmp0+0x1bd8>
    1b8c:      	tbz	w14, #0x7, 0x1ac0 <ltmp0+0x1ac0>
    1b90:      	b	0x1be4 <ltmp0+0x1be4>
    1b94:      	fmov	x9, d2
    1b98:      	ld1.b	{ v21 }[2], [x9]
    1b9c:      	tbz	w14, #0x3, 0x1b6c <ltmp0+0x1b6c>
    1ba0:      	mov.d	x9, v2[1]
    1ba4:      	ld1.b	{ v21 }[3], [x9]
    1ba8:      	ldr	q2, [sp, #0x390]
    1bac:      	add.2d	v2, v4, v2
    1bb0:      	add.2d	v2, v29, v2
    1bb4:      	tbz	w14, #0x4, 0x1b7c <ltmp0+0x1b7c>
    1bb8:      	fmov	x9, d2
    1bbc:      	ld1.b	{ v21 }[4], [x9]
    1bc0:      	tbz	w14, #0x5, 0x1b80 <ltmp0+0x1b80>
    1bc4:      	mov.d	x9, v2[1]
    1bc8:      	ld1.b	{ v21 }[5], [x9]
    1bcc:      	add.2d	v2, v7, v12
    1bd0:      	add.2d	v2, v27, v2
    1bd4:      	tbz	w14, #0x6, 0x1b8c <ltmp0+0x1b8c>
    1bd8:      	fmov	x9, d2
    1bdc:      	ld1.b	{ v21 }[6], [x9]
    1be0:      	tbz	w14, #0x7, 0x1ac0 <ltmp0+0x1ac0>
    1be4:      	mov.d	x9, v2[1]
    1be8:      	ld1.b	{ v21 }[7], [x9]
    1bec:      	b	0x1ac0 <ltmp0+0x1ac0>
    1bf0:      	fmov	w13, s22
    1bf4:      	tbz	w13, #0x0, 0x1cd8 <ltmp0+0x1cd8>
    1bf8:      	fmov	x9, d14
    1bfc:      	ldr	b3, [x9]
    1c00:      	tbnz	w13, #0x1, 0x1ce0 <ltmp0+0x1ce0>
    1c04:      	b	0x1ce4 <ltmp0+0x1ce4>
    1c08:      	ldr	s24, [x10]
    1c0c:      	tbz	w8, #0x1, 0x14b4 <ltmp0+0x14b4>
    1c10:      	add	x9, x10, #0x4
    1c14:      	ld1.s	{ v24 }[1], [x9]
    1c18:      	tbz	w8, #0x2, 0x14b8 <ltmp0+0x14b8>
    1c1c:      	add	x9, x10, #0x8
    1c20:      	ld1.s	{ v24 }[2], [x9]
    1c24:      	tbz	w8, #0x3, 0x14bc <ltmp0+0x14bc>
    1c28:      	add	x9, x10, #0xc
    1c2c:      	ld1.s	{ v24 }[3], [x9]
    1c30:      	tbz	w8, #0x4, 0x14c0 <ltmp0+0x14c0>
    1c34:      	add	x9, x10, #0x10
    1c38:      	ld1.s	{ v28 }[0], [x9]
    1c3c:      	tbz	w8, #0x5, 0x14c4 <ltmp0+0x14c4>
    1c40:      	add	x9, x10, #0x14
    1c44:      	ld1.s	{ v28 }[1], [x9]
    1c48:      	tbz	w8, #0x6, 0x14c8 <ltmp0+0x14c8>
    1c4c:      	add	x9, x10, #0x18
    1c50:      	ld1.s	{ v28 }[2], [x9]
    1c54:      	tbnz	w8, #0x7, 0x14cc <ltmp0+0x14cc>
    1c58:      	b	0x14d4 <ltmp0+0x14d4>
    1c5c:      	fmov	x8, d14
    1c60:      	str	b2, [x8]
    1c64:      	mov.d	x12, v14[1]
    1c68:      	tbz	w9, #0x1, 0x1a60 <ltmp0+0x1a60>
    1c6c:      	st1.b	{ v2 }[1], [x12]
    1c70:      	ldr	q4, [sp, #0x3a0]
    1c74:      	add.2d	v4, v4, v28
    1c78:      	add.2d	v13, v4, v3
    1c7c:      	tbz	w9, #0x2, 0x1a70 <ltmp0+0x1a70>
    1c80:      	fmov	x8, d13
    1c84:      	st1.b	{ v2 }[2], [x8]
    1c88:      	mov.d	x11, v13[1]
    1c8c:      	tbz	w9, #0x3, 0x1a78 <ltmp0+0x1a78>
    1c90:      	st1.b	{ v2 }[3], [x11]
    1c94:      	ldr	q4, [sp, #0x390]
    1c98:      	add.2d	v4, v4, v29
    1c9c:      	add.2d	v24, v4, v3
    1ca0:      	tbz	w9, #0x4, 0x1a88 <ltmp0+0x1a88>
    1ca4:      	fmov	x8, d24
    1ca8:      	st1.b	{ v2 }[4], [x8]
    1cac:      	mov.d	x10, v24[1]
    1cb0:      	tbz	w9, #0x5, 0x1a90 <ltmp0+0x1a90>
    1cb4:      	st1.b	{ v2 }[5], [x10]
    1cb8:      	add.2d	v4, v12, v27
    1cbc:      	add.2d	v20, v4, v3
    1cc0:      	tbz	w9, #0x6, 0x1a9c <ltmp0+0x1a9c>
    1cc4:      	fmov	x8, d20
    1cc8:      	st1.b	{ v2 }[6], [x8]
    1ccc:      	mov.d	x8, v20[1]
    1cd0:      	tbnz	w9, #0x7, 0x1aa4 <ltmp0+0x1aa4>
    1cd4:      	b	0x1aa8 <ltmp0+0x1aa8>
    1cd8:      	movi.2d	v3, #0000000000000000
    1cdc:      	tbz	w13, #0x1, 0x1ce4 <ltmp0+0x1ce4>
    1ce0:      	ld1.b	{ v3 }[1], [x12]
    1ce4:      	tbnz	w13, #0x2, 0x3010 <ltmp0+0x3010>
    1ce8:      	tbnz	w13, #0x3, 0x301c <ltmp0+0x301c>
    1cec:      	tbnz	w13, #0x4, 0x3024 <ltmp0+0x3024>
    1cf0:      	ldr	q6, [sp, #0x220]
    1cf4:      	tbnz	w13, #0x5, 0x3034 <ltmp0+0x3034>
    1cf8:      	tbnz	w13, #0x6, 0x303c <ltmp0+0x303c>
    1cfc:      	stp	q27, q26, [sp, #0x1f0]
    1d00:      	str	d22, [sp, #0xa8]
    1d04:      	stp	q29, q28, [sp, #0x1d0]
    1d08:      	stp	q12, q30, [sp, #0x1b0]
    1d0c:      	tbz	w13, #0x7, 0x1d14 <ltmp0+0x1d14>
    1d10:      	ld1.b	{ v3 }[7], [x8]
    1d14:      	str	q19, [sp, #0x220]
    1d18:      	str	x2, [sp, #0x100]
    1d1c:      	sshll.2d	v4, v1, #0x0
    1d20:      	sshll.2d	v5, v0, #0x0
    1d24:      	cmeq.8b	v2, v3, #0
    1d28:      	sshll.8h	v3, v2, #0x0
    1d2c:      	sshll.4s	v2, v3, #0x0
    1d30:      	str	q3, [sp, #0x10]
    1d34:      	sshll2.4s	v3, v3, #0x0
    1d38:      	str	q3, [sp, #0x30]
    1d3c:      	ldr	q7, [sp, #0x120]
    1d40:      	bit.16b	v7, v16, v3
    1d44:      	bif.16b	v16, v6, v2
    1d48:      	str	x4, [sp, #0xa0]
    1d4c:      	add	x8, x20, x4
    1d50:      	ldp	q3, q2, [x8]
    1d54:      	zip1.8b	v6, v18, v0
    1d58:      	ushll.4s	v6, v6, #0x0
    1d5c:      	shl.4s	v6, v6, #0x1f
    1d60:      	cmlt.4s	v6, v6, #0
    1d64:      	stp	q16, q7, [sp, #0x110]
    1d68:      	bit.16b	v3, v16, v6
    1d6c:      	zip2.8b	v6, v18, v0
    1d70:      	ushll.4s	v6, v6, #0x0
    1d74:      	shl.4s	v6, v6, #0x1f
    1d78:      	cmlt.4s	v6, v6, #0
    1d7c:      	bit.16b	v2, v7, v6
    1d80:      	stp	q3, q2, [x8]
    1d84:      	ldr	q2, [sp, #0x80]
    1d88:      	fmov	x8, d2
    1d8c:      	dup.2d	v3, x15
    1d90:      	ldp	q2, q19, [sp, #0x140]
    1d94:      	and.16b	v14, v2, v3
    1d98:      	and.16b	v22, v19, v3
    1d9c:      	and.16b	v23, v5, v3
    1da0:      	and.16b	v9, v4, v3
    1da4:      	fmov	x16, d9
    1da8:      	ldr	q3, [x23, #0x1880]
    1dac:      	ldr	q4, [x23, #0x1890]
    1db0:      	and.16b	v4, v0, v4
    1db4:      	and.16b	v6, v1, v3
    1db8:      	ldr	q3, [x23, #0x1860]
    1dbc:      	ldr	q5, [x23, #0x1870]
    1dc0:      	and.16b	v20, v0, v5
    1dc4:      	and.16b	v7, v1, v3
    1dc8:      	ldr	q3, [x23, #0x1840]
    1dcc:      	ldr	q5, [x23, #0x1850]
    1dd0:      	and.16b	v24, v0, v5
    1dd4:      	and.16b	v13, v1, v3
    1dd8:      	str	x8, [sp, #0x40]
    1ddc:      	add	x8, x20, x8
    1de0:      	ldp	q3, q5, [x8]
    1de4:      	and.16b	v5, v0, v5
    1de8:      	mov	x8, x16
    1dec:      	and.16b	v21, v1, v3
    1df0:      	mov.16b	v11, v9
    1df4:      	mov.16b	v15, v22
    1df8:      	mov.16b	v10, v23
    1dfc:      	str	q14, [sp, #0x80]
    1e00:      	sshll.2d	v26, v1, #0x0
    1e04:      	sshll.2d	v27, v0, #0x0
    1e08:      	add	x8, x20, x8, lsl #5
    1e0c:      	ldp	q3, q25, [x8]
    1e10:      	and.16b	v25, v0, v25
    1e14:      	and.16b	v3, v1, v3
    1e18:      	fmaxnm.4s	v3, v21, v3
    1e1c:      	fmaxnm.4s	v25, v5, v25
    1e20:      	ldp	q28, q29, [x8, #0x20]
    1e24:      	and.16b	v29, v0, v29
    1e28:      	and.16b	v28, v1, v28
    1e2c:      	fmaxnm.4s	v28, v13, v28
    1e30:      	fmaxnm.4s	v29, v24, v29
    1e34:      	ldp	q30, q16, [x8, #0x40]
    1e38:      	and.16b	v16, v0, v16
    1e3c:      	and.16b	v30, v1, v30
    1e40:      	fmaxnm.4s	v30, v7, v30
    1e44:      	fmaxnm.4s	v16, v20, v16
    1e48:      	ldp	q31, q17, [x8, #0x60]
    1e4c:      	and.16b	v17, v0, v17
    1e50:      	and.16b	v31, v1, v31
    1e54:      	fmaxnm.4s	v31, v6, v31
    1e58:      	fmaxnm.4s	v17, v4, v17
    1e5c:      	dup.2d	v18, x15
    1e60:      	and.16b	v12, v2, v18
    1e64:      	add.2d	v14, v14, v12
    1e68:      	and.16b	v12, v19, v18
    1e6c:      	add.2d	v15, v15, v12
    1e70:      	and.16b	v27, v27, v18
    1e74:      	add.2d	v10, v10, v27
    1e78:      	and.16b	v18, v26, v18
    1e7c:      	add.2d	v11, v11, v18
    1e80:      	bit.16b	v5, v25, v0
    1e84:      	bit.16b	v21, v3, v1
    1e88:      	bit.16b	v24, v29, v0
    1e8c:      	bit.16b	v13, v28, v1
    1e90:      	bit.16b	v20, v16, v0
    1e94:      	bit.16b	v7, v30, v1
    1e98:      	bit.16b	v4, v17, v0
    1e9c:      	bit.16b	v6, v31, v1
    1ea0:      	fmov	x8, d11
    1ea4:      	cmp	x8, #0xc0
    1ea8:      	b.lt	0x1e00 <ltmp0+0x1e00>
    1eac:      	mov	x21, #0x0               ; =0
    1eb0:      	movi	d16, #0xffffffffffff0000
    1eb4:      	ldp	q27, q18, [sp, #0x160]
    1eb8:      	and.8b	v2, v27, v16
    1ebc:      	zip1.8b	v16, v18, v0
    1ec0:      	ushll.4s	v16, v16, #0x0
    1ec4:      	shl.4s	v16, v16, #0x1f
    1ec8:      	cmlt.4s	v16, v16, #0
    1ecc:      	ldp	q17, q19, [sp, #0x110]
    1ed0:      	and.16b	v17, v16, v17
    1ed4:      	zip2.8b	v18, v18, v0
    1ed8:      	ushll.4s	v18, v18, #0x0
    1edc:      	shl.4s	v18, v18, #0x1f
    1ee0:      	cmlt.4s	v18, v18, #0
    1ee4:      	and.16b	v26, v18, v19
    1ee8:      	fmaxnm.4s	v5, v5, v26
    1eec:      	fmaxnm.4s	v17, v21, v17
    1ef0:      	and.16b	v16, v16, v17
    1ef4:      	and.16b	v5, v18, v5
    1ef8:      	zip2.8b	v17, v2, v0
    1efc:      	ushll.4s	v17, v17, #0x0
    1f00:      	shl.4s	v17, v17, #0x1f
    1f04:      	cmlt.4s	v17, v17, #0
    1f08:      	bit.16b	v5, v25, v17
    1f0c:      	str	d2, [sp, #0x28]
    1f10:      	zip1.8b	v17, v2, v0
    1f14:      	ushll.4s	v17, v17, #0x0
    1f18:      	shl.4s	v17, v17, #0x1f
    1f1c:      	cmlt.4s	v17, v17, #0
    1f20:      	bif.16b	v3, v16, v17
    1f24:      	fmaxnm.4s	v3, v3, v13
    1f28:      	fmaxnm.4s	v5, v5, v24
    1f2c:      	fmaxnm.4s	v5, v5, v20
    1f30:      	fmaxnm.4s	v3, v3, v7
    1f34:      	fmaxnm.4s	v20, v3, v6
    1f38:      	fmaxnm.4s	v24, v5, v4
    1f3c:      	ldr	q2, [sp, #0x130]
    1f40:      	ldp	q3, q4, [sp, #0x50]
    1f44:      	uzp1.4s	v7, v2, v4
    1f48:      	ldr	q2, [sp, #0x70]
    1f4c:      	uzp1.4s	v4, v3, v2
    1f50:      	movi.4s	v5, #0x1
    1f54:      	eor.16b	v3, v7, v5
    1f58:      	mov.s	w9, v3[1]
    1f5c:      	eor.16b	v21, v4, v5
    1f60:      	mov.s	w10, v3[2]
    1f64:      	mov.s	w11, v3[3]
    1f68:      	fmov	w8, s3
    1f6c:      	add	x12, sp, #0x678
    1f70:      	bfxil	x12, x8, #0, #3
    1f74:      	str	d27, [sp, #0x678]
    1f78:      	ldrb	w13, [x12]
    1f7c:      	umov.b	w12, v27[0]
    1f80:      	and	x8, x8, #0x7
    1f84:      	str	q24, [sp, #0x910]
    1f88:      	str	q20, [sp, #0x900]
    1f8c:      	add	x14, sp, #0x900
    1f90:      	ldr	s3, [x14, x8, lsl #2]
    1f94:      	ands	w8, w12, #0x1
    1f98:      	tst	w8, w13
    1f9c:      	movi	d19, #0000000000000000
    1fa0:      	fcsel	s6, s3, s19, ne
    1fa4:      	and	x13, x9, #0x7
    1fa8:      	add	x14, sp, #0x678
    1fac:      	bfxil	x14, x9, #0, #3
    1fb0:      	ldrb	w9, [x14]
    1fb4:      	umov.b	w5, v27[1]
    1fb8:      	str	q24, [sp, #0x8f0]
    1fbc:      	str	q20, [sp, #0x8e0]
    1fc0:      	add	x14, sp, #0x8e0
    1fc4:      	ldr	s3, [x14, x13, lsl #2]
    1fc8:      	and	w9, w5, w9
    1fcc:      	str	w5, [sp, #0x130]
    1fd0:      	tst	w9, #0x1
    1fd4:      	fcsel	s13, s3, s19, ne
    1fd8:      	and	x9, x10, #0x7
    1fdc:      	add	x13, sp, #0x678
    1fe0:      	bfxil	x13, x10, #0, #3
    1fe4:      	ldrb	w10, [x13]
    1fe8:      	umov.b	w6, v27[2]
    1fec:      	and	w10, w6, w10
    1ff0:      	str	w6, [sp, #0x2c0]
    1ff4:      	str	q24, [sp, #0x8d0]
    1ff8:      	str	q20, [sp, #0x8c0]
    1ffc:      	add	x14, sp, #0x8c0
    2000:      	ldr	s3, [x14, x9, lsl #2]
    2004:      	tst	w10, #0x1
    2008:      	fcsel	s5, s3, s19, ne
    200c:      	and	x9, x11, #0x7
    2010:      	add	x10, sp, #0x678
    2014:      	bfxil	x10, x11, #0, #3
    2018:      	ldrb	w10, [x10]
    201c:      	umov.b	w15, v27[3]
    2020:      	and	w10, w15, w10
    2024:      	str	q24, [sp, #0x8b0]
    2028:      	str	q20, [sp, #0x8a0]
    202c:      	add	x11, sp, #0x8a0
    2030:      	ldr	s3, [x11, x9, lsl #2]
    2034:      	tst	w10, #0x1
    2038:      	mov.s	w9, v21[1]
    203c:      	fcsel	s3, s3, s19, ne
    2040:      	mov.s	w10, v21[2]
    2044:      	mov.s	w11, v21[3]
    2048:      	fmov	w17, s21
    204c:      	and	x1, x17, #0x7
    2050:      	add	x0, sp, #0x678
    2054:      	bfxil	x0, x17, #0, #3
    2058:      	ldrb	w17, [x0]
    205c:      	umov.b	w14, v27[4]
    2060:      	and	w17, w14, w17
    2064:      	str	q24, [sp, #0x990]
    2068:      	str	q20, [sp, #0x980]
    206c:      	add	x2, sp, #0x980
    2070:      	ldr	s16, [x2, x1, lsl #2]
    2074:      	tst	w17, #0x1
    2078:      	fcsel	s16, s16, s19, ne
    207c:      	and	x1, x9, #0x7
    2080:      	add	x2, sp, #0x678
    2084:      	bfxil	x2, x9, #0, #3
    2088:      	umov.b	w13, v27[5]
    208c:      	ldrb	w9, [x2]
    2090:      	and	w9, w13, w9
    2094:      	str	q24, [sp, #0x970]
    2098:      	str	q20, [sp, #0x960]
    209c:      	add	x17, sp, #0x960
    20a0:      	ldr	s17, [x17, x1, lsl #2]
    20a4:      	tst	w9, #0x1
    20a8:      	fcsel	s17, s17, s19, ne
    20ac:      	and	x9, x10, #0x7
    20b0:      	add	x1, sp, #0x678
    20b4:      	bfxil	x1, x10, #0, #3
    20b8:      	ldrb	w10, [x1]
    20bc:      	umov.b	w1, v27[6]
    20c0:      	str	q24, [sp, #0x950]
    20c4:      	str	q20, [sp, #0x940]
    20c8:      	add	x17, sp, #0x940
    20cc:      	ldr	s18, [x17, x9, lsl #2]
    20d0:      	and	w9, w1, w10
    20d4:      	tst	w9, #0x1
    20d8:      	fcsel	s18, s18, s19, ne
    20dc:      	and	x9, x11, #0x7
    20e0:      	add	x10, sp, #0x678
    20e4:      	bfxil	x10, x11, #0, #3
    20e8:      	ldrb	w10, [x10]
    20ec:      	umov.b	w2, v27[7]
    20f0:      	and	w10, w2, w10
    20f4:      	str	q24, [sp, #0x930]
    20f8:      	str	q20, [sp, #0x920]
    20fc:      	add	x11, sp, #0x920
    2100:      	ldr	s21, [x11, x9, lsl #2]
    2104:      	tst	w10, #0x1
    2108:      	fcsel	s21, s21, s19, ne
    210c:      	mov.s	v16[1], v17[0]
    2110:      	mov.s	v16[2], v18[0]
    2114:      	mov.s	v16[3], v21[0]
    2118:      	mov.s	v6[1], v13[0]
    211c:      	mov.s	v6[2], v5[0]
    2120:      	mov.s	v6[3], v3[0]
    2124:      	fmaxnm.4s	v6, v20, v6
    2128:      	fmaxnm.4s	v20, v24, v16
    212c:      	movi.4s	v5, #0x2
    2130:      	eor.16b	v3, v7, v5
    2134:      	mov.s	w9, v3[1]
    2138:      	mov.s	w10, v3[2]
    213c:      	eor.16b	v5, v4, v5
    2140:      	mov.s	w11, v3[3]
    2144:      	fmov	w3, s3
    2148:      	add	x4, sp, #0x678
    214c:      	bfxil	x4, x3, #0, #3
    2150:      	ldrb	w4, [x4]
    2154:      	and	x3, x3, #0x7
    2158:      	str	q20, [sp, #0x890]
    215c:      	str	q6, [sp, #0x880]
    2160:      	add	x17, sp, #0x880
    2164:      	ldr	s3, [x17, x3, lsl #2]
    2168:      	tst	w8, w4
    216c:      	fcsel	s4, s3, s19, ne
    2170:      	and	x3, x9, #0x7
    2174:      	add	x4, sp, #0x678
    2178:      	bfxil	x4, x9, #0, #3
    217c:      	ldrb	w9, [x4]
    2180:      	and	w9, w5, w9
    2184:      	str	q20, [sp, #0x870]
    2188:      	str	q6, [sp, #0x860]
    218c:      	add	x17, sp, #0x860
    2190:      	ldr	s3, [x17, x3, lsl #2]
    2194:      	tst	w9, #0x1
    2198:      	fcsel	s24, s3, s19, ne
    219c:      	and	x9, x10, #0x7
    21a0:      	add	x3, sp, #0x678
    21a4:      	bfxil	x3, x10, #0, #3
    21a8:      	ldrb	w10, [x3]
    21ac:      	and	w10, w6, w10
    21b0:      	str	q20, [sp, #0x850]
    21b4:      	str	q6, [sp, #0x840]
    21b8:      	add	x17, sp, #0x840
    21bc:      	ldr	s3, [x17, x9, lsl #2]
    21c0:      	tst	w10, #0x1
    21c4:      	fcsel	s13, s3, s19, ne
    21c8:      	and	x9, x11, #0x7
    21cc:      	add	x10, sp, #0x678
    21d0:      	bfxil	x10, x11, #0, #3
    21d4:      	ldrb	w10, [x10]
    21d8:      	and	w10, w15, w10
    21dc:      	str	q20, [sp, #0x830]
    21e0:      	str	q6, [sp, #0x820]
    21e4:      	add	x11, sp, #0x820
    21e8:      	ldr	s3, [x11, x9, lsl #2]
    21ec:      	tst	w10, #0x1
    21f0:      	mov.s	w30, v5[3]
    21f4:      	fmov	w9, s5
    21f8:      	and	x22, x9, #0x7
    21fc:      	add	x17, sp, #0x678
    2200:      	bfxil	x17, x9, #0, #3
    2204:      	add	x9, sp, #0x678
    2208:      	bfxil	x9, x30, #0, #3
    220c:      	ldrb	w9, [x9]
    2210:      	movi.4s	v16, #0x4
    2214:      	eor.16b	v7, v7, v16
    2218:      	mov.s	w4, v7[1]
    221c:      	mov.s	w11, v7[2]
    2220:      	mov.s	w10, v7[3]
    2224:      	fmov	w3, s7
    2228:      	add	x5, sp, #0x678
    222c:      	bfxil	x5, x3, #0, #3
    2230:      	ldrb	w7, [x5]
    2234:      	add	x5, sp, #0x678
    2238:      	bfxil	x5, x4, #0, #3
    223c:      	ldrb	w26, [x5]
    2240:      	add	x5, sp, #0x678
    2244:      	bfxil	x5, x11, #0, #3
    2248:      	ldrb	w6, [x5]
    224c:      	add	x5, sp, #0x678
    2250:      	bfxil	x5, x10, #0, #3
    2254:      	ldrb	w5, [x5]
    2258:      	ldrb	w17, [x17]
    225c:      	str	q20, [sp, #0x810]
    2260:      	str	q6, [sp, #0x800]
    2264:      	add	x0, sp, #0x800
    2268:      	ldr	s7, [x0, x22, lsl #2]
    226c:      	mov.s	w22, v5[1]
    2270:      	fcsel	s3, s3, s19, ne
    2274:      	and	w17, w14, w17
    2278:      	tst	w17, #0x1
    227c:      	add	x17, sp, #0x678
    2280:      	bfxil	x17, x22, #0, #3
    2284:      	and	x22, x22, #0x7
    2288:      	ldrb	w17, [x17]
    228c:      	str	q20, [sp, #0x7f0]
    2290:      	str	q6, [sp, #0x7e0]
    2294:      	add	x0, sp, #0x7e0
    2298:      	ldr	s16, [x0, x22, lsl #2]
    229c:      	mov.s	w22, v5[2]
    22a0:      	fcsel	s5, s7, s19, ne
    22a4:      	and	w17, w13, w17
    22a8:      	tst	w17, #0x1
    22ac:      	add	x17, sp, #0x678
    22b0:      	bfxil	x17, x22, #0, #3
    22b4:      	and	x22, x22, #0x7
    22b8:      	ldrb	w17, [x17]
    22bc:      	str	q20, [sp, #0x7d0]
    22c0:      	str	q6, [sp, #0x7c0]
    22c4:      	add	x0, sp, #0x7c0
    22c8:      	ldr	s7, [x0, x22, lsl #2]
    22cc:      	fcsel	s16, s16, s19, ne
    22d0:      	and	w17, w1, w17
    22d4:      	tst	w17, #0x1
    22d8:      	and	x17, x30, #0x7
    22dc:      	str	q20, [sp, #0x7b0]
    22e0:      	str	q6, [sp, #0x7a0]
    22e4:      	add	x0, sp, #0x7a0
    22e8:      	ldr	s17, [x0, x17, lsl #2]
    22ec:      	fcsel	s7, s7, s19, ne
    22f0:      	and	w9, w2, w9
    22f4:      	tst	w9, #0x1
    22f8:      	fcsel	s17, s17, s19, ne
    22fc:      	mov.s	v5[1], v16[0]
    2300:      	mov.s	v5[2], v7[0]
    2304:      	mov.s	v5[3], v17[0]
    2308:      	mov.s	v4[1], v24[0]
    230c:      	mov.s	v4[2], v13[0]
    2310:      	mov.s	v4[3], v3[0]
    2314:      	fmaxnm.4s	v3, v6, v4
    2318:      	fmaxnm.4s	v4, v20, v5
    231c:      	and	x9, x3, #0x7
    2320:      	str	q4, [sp, #0x790]
    2324:      	str	q3, [sp, #0x780]
    2328:      	add	x17, sp, #0x780
    232c:      	ldr	s5, [x17, x9, lsl #2]
    2330:      	tst	w8, w7
    2334:      	fcsel	s5, s5, s19, ne
    2338:      	and	x8, x4, #0x7
    233c:      	ldr	w0, [sp, #0x130]
    2340:      	and	w9, w0, w26
    2344:      	str	q4, [sp, #0x770]
    2348:      	str	q3, [sp, #0x760]
    234c:      	add	x17, sp, #0x760
    2350:      	ldr	s6, [x17, x8, lsl #2]
    2354:      	tst	w9, #0x1
    2358:      	fcsel	s6, s6, s19, ne
    235c:      	and	x8, x11, #0x7
    2360:      	ldr	w17, [sp, #0x2c0]
    2364:      	and	w9, w17, w6
    2368:      	str	q4, [sp, #0x750]
    236c:      	str	q3, [sp, #0x740]
    2370:      	add	x11, sp, #0x740
    2374:      	ldr	s7, [x11, x8, lsl #2]
    2378:      	tst	w9, #0x1
    237c:      	fcsel	s7, s7, s19, ne
    2380:      	and	x8, x10, #0x7
    2384:      	str	q4, [sp, #0x730]
    2388:      	str	q3, [sp, #0x720]
    238c:      	add	x9, sp, #0x720
    2390:      	ldr	s4, [x9, x8, lsl #2]
    2394:      	and	w8, w15, w5
    2398:      	tst	w8, #0x1
    239c:      	fcsel	s4, s4, s19, ne
    23a0:      	ands	w4, w12, #0x1
    23a4:      	mov.s	v5[1], v6[0]
    23a8:      	mov.s	v5[2], v7[0]
    23ac:      	mov.s	v5[3], v4[0]
    23b0:      	fmaxnm.4s	v3, v3, v5
    23b4:      	fcsel	s4, s3, s19, ne
    23b8:      	and	w5, w0, w12
    23bc:      	tst	w5, #0x1
    23c0:      	fcsel	s5, s3, s19, ne
    23c4:      	and	w6, w17, w12
    23c8:      	tst	w6, #0x1
    23cc:      	fcsel	s6, s3, s19, ne
    23d0:      	stp	w15, w14, [sp, #0x4c]
    23d4:      	and	w7, w15, w12
    23d8:      	tst	w7, #0x1
    23dc:      	fcsel	s7, s3, s19, ne
    23e0:      	and	w26, w14, w12
    23e4:      	tst	w26, #0x1
    23e8:      	fcsel	s16, s3, s19, ne
    23ec:      	str	w13, [sp, #0x70]
    23f0:      	and	w30, w13, w12
    23f4:      	tst	w30, #0x1
    23f8:      	fcsel	s17, s3, s19, ne
    23fc:      	and	w8, w1, w12
    2400:      	tst	w8, #0x1
    2404:      	fcsel	s18, s3, s19, ne
    2408:      	str	w12, [sp, #0x60]
    240c:      	and	w11, w2, w12
    2410:      	tst	w11, #0x1
    2414:      	mov.s	v4[1], v5[0]
    2418:      	mov.s	v4[2], v6[0]
    241c:      	mov.s	v4[3], v7[0]
    2420:      	mov.s	v16[1], v17[0]
    2424:      	mov.s	v16[2], v18[0]
    2428:      	fcsel	s3, s3, s19, ne
    242c:      	mov.s	v16[3], v3[0]
    2430:      	ldr	w9, [sp, #0x9c]
    2434:      	rbit	w9, w9
    2438:      	clz	w10, w9
    243c:      	str	q16, [sp, #0x690]
    2440:      	str	q4, [sp, #0x680]
    2444:      	and	x9, x10, #0x7
    2448:      	add	x17, sp, #0x680
    244c:      	ldr	s3, [x17, x9, lsl #2]
    2450:      	mov	w9, #-0x800000          ; =-8388608
    2454:      	fmov	s4, w9
    2458:      	fmaxnm	s3, s3, s4
    245c:      	dup.4s	v4, v3[0]
    2460:      	movi.2d	v6, #0000000000000000
    2464:      	movi.2d	v7, #0000000000000000
    2468:      	movi.2d	v24, #0000000000000000
    246c:      	movi.2d	v13, #0000000000000000
    2470:      	adrp	x22, 0x2000 <ltmp0+0x2000>
    2474:      	movi.4s	v28, #0x4b, lsl #24
    2478:      	mvni.4s	v29, #0x80, lsl #24
    247c:      	movi.4s	v30, #0x3f, lsl #24
    2480:      	ldr	q31, [sp, #0x260]
    2484:      	ldp	q10, q14, [sp, #0x3c0]
    2488:      	ldp	q12, q11, [sp, #0x2e0]
    248c:      	ldr	q15, [sp, #0x2d0]
    2490:      	b	0x2670 <ltmp0+0x2670>
    2494:      	lsl	x21, x21, #5
    2498:      	add	x9, x20, x21
    249c:      	ldp	q5, q3, [x9]
    24a0:      	fsub.4s	v16, v5, v4
    24a4:      	fsub.4s	v3, v3, v4
    24a8:      	and.16b	v5, v0, v3
    24ac:      	and.16b	v3, v1, v16
    24b0:      	fcmge.4s	v16, v3, v12
    24b4:      	fcmge.4s	v17, v5, v12
    24b8:      	fcmge.4s	v18, v11, v3
    24bc:      	fcmge.4s	v21, v11, v5
    24c0:      	and.16b	v17, v17, v21
    24c4:      	and.16b	v16, v16, v18
    24c8:      	and.16b	v16, v16, v3
    24cc:      	and.16b	v17, v17, v5
    24d0:      	ldp	q2, q19, [sp, #0x300]
    24d4:      	fmul.4s	v18, v17, v2
    24d8:      	fmul.4s	v21, v16, v2
    24dc:      	mov.16b	v25, v29
    24e0:      	bsl.16b	v25, v28, v21
    24e4:      	mov.16b	v26, v29
    24e8:      	bsl.16b	v26, v28, v18
    24ec:      	fadd.4s	v18, v18, v26
    24f0:      	fadd.4s	v21, v21, v25
    24f4:      	fsub.4s	v21, v21, v25
    24f8:      	fsub.4s	v18, v18, v26
    24fc:      	fcvtzs.4s	v18, v18
    2500:      	fcvtzs.4s	v21, v21
    2504:      	scvtf.4s	v25, v21
    2508:      	scvtf.4s	v26, v18
    250c:      	fmul.4s	v27, v25, v19
    2510:      	fadd.4s	v16, v16, v27
    2514:      	fmul.4s	v27, v26, v19
    2518:      	fadd.4s	v17, v17, v27
    251c:      	ldr	q27, [sp, #0x320]
    2520:      	fmul.4s	v25, v25, v27
    2524:      	fmul.4s	v26, v26, v27
    2528:      	fadd.4s	v17, v17, v26
    252c:      	fadd.4s	v16, v16, v25
    2530:      	ldp	q26, q27, [sp, #0x330]
    2534:      	fmul.4s	v25, v16, v26
    2538:      	fmul.4s	v26, v17, v26
    253c:      	fadd.4s	v26, v26, v27
    2540:      	fadd.4s	v25, v25, v27
    2544:      	fmul.4s	v25, v16, v25
    2548:      	fmul.4s	v26, v17, v26
    254c:      	ldp	q2, q27, [sp, #0x350]
    2550:      	fadd.4s	v26, v26, v2
    2554:      	fadd.4s	v25, v25, v2
    2558:      	fmul.4s	v25, v16, v25
    255c:      	fmul.4s	v26, v17, v26
    2560:      	fadd.4s	v26, v26, v27
    2564:      	fadd.4s	v25, v25, v27
    2568:      	fmul.4s	v25, v16, v25
    256c:      	fmul.4s	v26, v17, v26
    2570:      	fadd.4s	v26, v26, v14
    2574:      	fadd.4s	v25, v25, v14
    2578:      	fmul.4s	v25, v16, v25
    257c:      	fmul.4s	v26, v17, v26
    2580:      	fadd.4s	v26, v26, v30
    2584:      	fadd.4s	v25, v25, v30
    2588:      	fmul.4s	v27, v16, v16
    258c:      	fmul.4s	v25, v27, v25
    2590:      	fmul.4s	v27, v17, v17
    2594:      	fmul.4s	v26, v27, v26
    2598:      	fadd.4s	v17, v17, v26
    259c:      	fadd.4s	v16, v16, v25
    25a0:      	fadd.4s	v16, v16, v15
    25a4:      	fadd.4s	v17, v17, v15
    25a8:      	sshr.4s	v25, v21, #0x1
    25ac:      	sshr.4s	v26, v18, #0x1
    25b0:      	shl.4s	v27, v26, #0x17
    25b4:      	add.4s	v27, v27, v15
    25b8:      	fmul.4s	v17, v17, v27
    25bc:      	shl.4s	v27, v25, #0x17
    25c0:      	add.4s	v27, v27, v15
    25c4:      	fmul.4s	v16, v16, v27
    25c8:      	sub.4s	v18, v18, v26
    25cc:      	sub.4s	v21, v21, v25
    25d0:      	shl.4s	v21, v21, #0x17
    25d4:      	add.4s	v21, v21, v15
    25d8:      	fmul.4s	v16, v16, v21
    25dc:      	shl.4s	v18, v18, #0x17
    25e0:      	add.4s	v18, v18, v15
    25e4:      	fmul.4s	v17, v17, v18
    25e8:      	fcmgt.4s	v18, v12, v5
    25ec:      	bic.16b	v17, v17, v18
    25f0:      	fcmgt.4s	v18, v12, v3
    25f4:      	bic.16b	v16, v16, v18
    25f8:      	fcmgt.4s	v18, v3, v11
    25fc:      	bit.16b	v16, v31, v18
    2600:      	fcmgt.4s	v18, v5, v11
    2604:      	bit.16b	v17, v31, v18
    2608:      	fcmeq.4s	v5, v5, v5
    260c:      	bsl.16b	v5, v17, v10
    2610:      	cmeq.8b	v17, v20, #0
    2614:      	sshll.8h	v17, v17, #0x0
    2618:      	fcmeq.4s	v3, v3, v3
    261c:      	bsl.16b	v3, v16, v10
    2620:      	sshll.4s	v16, v17, #0x0
    2624:      	bic.16b	v3, v3, v16
    2628:      	sshll2.4s	v16, v17, #0x0
    262c:      	bic.16b	v5, v5, v16
    2630:      	add	x9, x23, x21
    2634:      	ldp	q16, q2, [x9]
    2638:      	bif.16b	v5, v2, v0
    263c:      	bif.16b	v3, v16, v1
    2640:      	stp	q3, q5, [x9]
    2644:      	ldr	q3, [sp, #0x370]
    2648:      	add.2d	v7, v7, v3
    264c:      	ldr	q3, [sp, #0x240]
    2650:      	add.2d	v24, v24, v3
    2654:      	ldr	q3, [sp, #0x220]
    2658:      	add.2d	v13, v13, v3
    265c:      	ldr	q3, [sp, #0x200]
    2660:      	add.2d	v6, v6, v3
    2664:      	fmov	x21, d6
    2668:      	cmp	x21, #0xc0
    266c:      	b.ge	0x2768 <ltmp0+0x2768>
    2670:      	ldr	q3, [sp, #0x230]
    2674:      	fmov	w9, s3
    2678:      	ldr	q2, [sp, #0x380]
    267c:      	add.2d	v3, v6, v2
    2680:      	ldr	q2, [sp, #0x1c0]
    2684:      	add.2d	v3, v2, v3
    2688:      	tbz	w9, #0x0, 0x26a4 <ltmp0+0x26a4>
    268c:      	fmov	x17, d3
    2690:      	ldr	b20, [x17]
    2694:      	ldr	q2, [sp, #0x1f0]
    2698:      	and	w3, w9, #0xff
    269c:      	tbnz	w3, #0x1, 0x26b4 <ltmp0+0x26b4>
    26a0:      	b	0x26bc <ltmp0+0x26bc>
    26a4:      	movi.2d	v20, #0000000000000000
    26a8:      	ldr	q2, [sp, #0x1f0]
    26ac:      	and	w3, w9, #0xff
    26b0:      	tbz	w3, #0x1, 0x26bc <ltmp0+0x26bc>
    26b4:      	mov.d	x9, v3[1]
    26b8:      	ld1.b	{ v20 }[1], [x9]
    26bc:      	ldr	q3, [sp, #0x3a0]
    26c0:      	add.2d	v3, v7, v3
    26c4:      	ldr	q5, [sp, #0x1e0]
    26c8:      	add.2d	v3, v5, v3
    26cc:      	tbnz	w3, #0x2, 0x2704 <ltmp0+0x2704>
    26d0:      	tbnz	w3, #0x3, 0x2710 <ltmp0+0x2710>
    26d4:      	ldr	q3, [sp, #0x390]
    26d8:      	add.2d	v3, v24, v3
    26dc:      	ldr	q5, [sp, #0x1d0]
    26e0:      	add.2d	v3, v5, v3
    26e4:      	tbnz	w3, #0x4, 0x272c <ltmp0+0x272c>
    26e8:      	tbnz	w3, #0x5, 0x2738 <ltmp0+0x2738>
    26ec:      	ldr	q3, [sp, #0x1b0]
    26f0:      	add.2d	v3, v13, v3
    26f4:      	add.2d	v3, v2, v3
    26f8:      	tbnz	w3, #0x6, 0x2750 <ltmp0+0x2750>
    26fc:      	tbz	w3, #0x7, 0x2494 <ltmp0+0x2494>
    2700:      	b	0x275c <ltmp0+0x275c>
    2704:      	fmov	x9, d3
    2708:      	ld1.b	{ v20 }[2], [x9]
    270c:      	tbz	w3, #0x3, 0x26d4 <ltmp0+0x26d4>
    2710:      	mov.d	x9, v3[1]
    2714:      	ld1.b	{ v20 }[3], [x9]
    2718:      	ldr	q3, [sp, #0x390]
    271c:      	add.2d	v3, v24, v3
    2720:      	ldr	q5, [sp, #0x1d0]
    2724:      	add.2d	v3, v5, v3
    2728:      	tbz	w3, #0x4, 0x26e8 <ltmp0+0x26e8>
    272c:      	fmov	x9, d3
    2730:      	ld1.b	{ v20 }[4], [x9]
    2734:      	tbz	w3, #0x5, 0x26ec <ltmp0+0x26ec>
    2738:      	mov.d	x9, v3[1]
    273c:      	ld1.b	{ v20 }[5], [x9]
    2740:      	ldr	q3, [sp, #0x1b0]
    2744:      	add.2d	v3, v13, v3
    2748:      	add.2d	v3, v2, v3
    274c:      	tbz	w3, #0x6, 0x26fc <ltmp0+0x26fc>
    2750:      	fmov	x9, d3
    2754:      	ld1.b	{ v20 }[6], [x9]
    2758:      	tbz	w3, #0x7, 0x2494 <ltmp0+0x2494>
    275c:      	mov.d	x9, v3[1]
    2760:      	ld1.b	{ v20 }[7], [x9]
    2764:      	b	0x2494 <ltmp0+0x2494>
    2768:      	ldr	q2, [sp, #0x10]
    276c:      	sshll.4s	v3, v2, #0x0
    2770:      	ldp	q5, q2, [sp, #0x110]
    2774:      	fsub.4s	v6, v5, v4
    2778:      	fsub.4s	v4, v2, v4
    277c:      	ldr	q7, [sp, #0x170]
    2780:      	zip2.8b	v5, v7, v0
    2784:      	ushll.4s	v5, v5, #0x0
    2788:      	shl.4s	v5, v5, #0x1f
    278c:      	cmlt.4s	v5, v5, #0
    2790:      	and.16b	v4, v5, v4
    2794:      	zip1.8b	v7, v7, v0
    2798:      	ushll.4s	v7, v7, #0x0
    279c:      	shl.4s	v7, v7, #0x1f
    27a0:      	cmlt.4s	v7, v7, #0
    27a4:      	and.16b	v6, v7, v6
    27a8:      	fcmge.4s	v16, v6, v12
    27ac:      	fcmge.4s	v17, v4, v12
    27b0:      	fcmge.4s	v18, v11, v6
    27b4:      	fcmge.4s	v20, v11, v4
    27b8:      	and.16b	v17, v17, v20
    27bc:      	and.16b	v16, v16, v18
    27c0:      	and.16b	v16, v16, v6
    27c4:      	and.16b	v17, v17, v4
    27c8:      	ldp	q2, q19, [sp, #0x300]
    27cc:      	fmul.4s	v18, v17, v2
    27d0:      	fmul.4s	v20, v16, v2
    27d4:      	mov.16b	v21, v29
    27d8:      	bsl.16b	v21, v28, v20
    27dc:      	mov.16b	v24, v29
    27e0:      	bsl.16b	v24, v28, v18
    27e4:      	fadd.4s	v18, v18, v24
    27e8:      	fadd.4s	v20, v20, v21
    27ec:      	fsub.4s	v20, v20, v21
    27f0:      	fsub.4s	v18, v18, v24
    27f4:      	fcvtzs.4s	v18, v18
    27f8:      	fcvtzs.4s	v20, v20
    27fc:      	scvtf.4s	v21, v20
    2800:      	scvtf.4s	v24, v18
    2804:      	fmul.4s	v25, v24, v19
    2808:      	fmul.4s	v26, v21, v19
    280c:      	fadd.4s	v16, v16, v26
    2810:      	fadd.4s	v17, v17, v25
    2814:      	ldr	q25, [sp, #0x320]
    2818:      	fmul.4s	v21, v21, v25
    281c:      	fmul.4s	v24, v24, v25
    2820:      	fadd.4s	v17, v17, v24
    2824:      	fadd.4s	v16, v16, v21
    2828:      	ldp	q24, q25, [sp, #0x330]
    282c:      	fmul.4s	v21, v16, v24
    2830:      	fmul.4s	v24, v17, v24
    2834:      	fadd.4s	v24, v24, v25
    2838:      	fadd.4s	v21, v21, v25
    283c:      	fmul.4s	v21, v16, v21
    2840:      	fmul.4s	v24, v17, v24
    2844:      	ldp	q2, q25, [sp, #0x350]
    2848:      	fadd.4s	v24, v24, v2
    284c:      	fadd.4s	v21, v21, v2
    2850:      	fmul.4s	v21, v16, v21
    2854:      	fmul.4s	v24, v17, v24
    2858:      	fadd.4s	v24, v24, v25
    285c:      	fadd.4s	v21, v21, v25
    2860:      	fmul.4s	v21, v16, v21
    2864:      	fmul.4s	v24, v17, v24
    2868:      	fadd.4s	v24, v24, v14
    286c:      	fadd.4s	v21, v21, v14
    2870:      	fmul.4s	v21, v16, v21
    2874:      	fmul.4s	v24, v17, v24
    2878:      	fadd.4s	v24, v24, v30
    287c:      	fadd.4s	v21, v21, v30
    2880:      	fmul.4s	v25, v17, v17
    2884:      	fmul.4s	v26, v16, v16
    2888:      	fmul.4s	v21, v26, v21
    288c:      	fmul.4s	v24, v25, v24
    2890:      	fadd.4s	v17, v17, v24
    2894:      	fadd.4s	v16, v16, v21
    2898:      	fadd.4s	v16, v16, v15
    289c:      	fadd.4s	v17, v17, v15
    28a0:      	sshr.4s	v21, v20, #0x1
    28a4:      	sshr.4s	v24, v18, #0x1
    28a8:      	shl.4s	v25, v24, #0x17
    28ac:      	shl.4s	v26, v21, #0x17
    28b0:      	add.4s	v26, v26, v15
    28b4:      	add.4s	v25, v25, v15
    28b8:      	fmul.4s	v17, v17, v25
    28bc:      	fmul.4s	v16, v16, v26
    28c0:      	sub.4s	v18, v18, v24
    28c4:      	sub.4s	v20, v20, v21
    28c8:      	shl.4s	v20, v20, #0x17
    28cc:      	shl.4s	v18, v18, #0x17
    28d0:      	add.4s	v18, v18, v15
    28d4:      	add.4s	v20, v20, v15
    28d8:      	fmul.4s	v16, v16, v20
    28dc:      	fmul.4s	v17, v17, v18
    28e0:      	fcmgt.4s	v18, v12, v4
    28e4:      	bic.16b	v17, v17, v18
    28e8:      	fcmgt.4s	v18, v12, v6
    28ec:      	bic.16b	v16, v16, v18
    28f0:      	fcmgt.4s	v18, v4, v11
    28f4:      	fcmgt.4s	v20, v6, v11
    28f8:      	bit.16b	v16, v31, v20
    28fc:      	bit.16b	v17, v31, v18
    2900:      	fcmeq.4s	v6, v6, v6
    2904:      	fcmeq.4s	v4, v4, v4
    2908:      	bsl.16b	v4, v17, v10
    290c:      	bsl.16b	v6, v16, v10
    2910:      	bic.16b	v6, v6, v3
    2914:      	ldr	q2, [sp, #0x30]
    2918:      	bic.16b	v4, v4, v2
    291c:      	ldr	x9, [sp, #0xa0]
    2920:      	add	x9, x23, x9
    2924:      	ldp	q3, q16, [x9]
    2928:      	bsl.16b	v5, v4, v16
    292c:      	bit.16b	v3, v6, v7
    2930:      	stp	q3, q5, [x9]
    2934:      	ldp	q3, q5, [x23, #0x60]
    2938:      	and.16b	v20, v0, v5
    293c:      	and.16b	v24, v1, v3
    2940:      	ldp	q3, q5, [x23, #0x40]
    2944:      	and.16b	v26, v0, v5
    2948:      	and.16b	v25, v1, v3
    294c:      	ldp	q3, q5, [x23, #0x20]
    2950:      	and.16b	v27, v0, v5
    2954:      	and.16b	v5, v1, v3
    2958:      	ldr	x9, [sp, #0x40]
    295c:      	add	x9, x23, x9
    2960:      	ldp	q3, q7, [x9]
    2964:      	and.16b	v21, v0, v7
    2968:      	and.16b	v3, v1, v3
    296c:      	mov	w17, #0x4               ; =4
    2970:      	ldp	q2, q19, [sp, #0x140]
    2974:      	ldr	q14, [sp, #0x80]
    2978:      	sshll.2d	v7, v1, #0x0
    297c:      	sshll.2d	v16, v0, #0x0
    2980:      	add	x9, x23, x16, lsl #5
    2984:      	ldp	q18, q17, [x9]
    2988:      	fadd.4s	v28, v3, v18
    298c:      	fadd.4s	v29, v21, v17
    2990:      	ldp	q18, q17, [x9, #0x20]
    2994:      	fadd.4s	v18, v5, v18
    2998:      	fadd.4s	v17, v27, v17
    299c:      	ldp	q31, q30, [x9, #0x40]
    29a0:      	fadd.4s	v31, v25, v31
    29a4:      	fadd.4s	v30, v26, v30
    29a8:      	ldp	q11, q10, [x9, #0x60]
    29ac:      	fadd.4s	v11, v24, v11
    29b0:      	fadd.4s	v10, v20, v10
    29b4:      	dup.2d	v12, x17
    29b8:      	and.16b	v13, v2, v12
    29bc:      	add.2d	v14, v14, v13
    29c0:      	and.16b	v13, v19, v12
    29c4:      	add.2d	v22, v22, v13
    29c8:      	and.16b	v16, v16, v12
    29cc:      	add.2d	v23, v23, v16
    29d0:      	and.16b	v7, v7, v12
    29d4:      	add.2d	v9, v9, v7
    29d8:      	bit.16b	v21, v29, v0
    29dc:      	bit.16b	v3, v28, v1
    29e0:      	bit.16b	v27, v17, v0
    29e4:      	bit.16b	v5, v18, v1
    29e8:      	bit.16b	v26, v30, v0
    29ec:      	bit.16b	v25, v31, v1
    29f0:      	bit.16b	v20, v10, v0
    29f4:      	bit.16b	v24, v11, v1
    29f8:      	fmov	x16, d9
    29fc:      	cmp	x16, #0xc0
    2a00:      	b.lt	0x2978 <ltmp0+0x2978>
    2a04:      	mov	x16, #0x0               ; =0
    2a08:      	adrp	x9, 0x2000 <ltmp0+0x2000>
    2a0c:      	ldr	q2, [x9]
    2a10:      	and.16b	v22, v0, v2
    2a14:      	adrp	x9, 0x2000 <ltmp0+0x2000>
    2a18:      	ldr	q2, [x9]
    2a1c:      	and.16b	v23, v1, v2
    2a20:      	adrp	x9, 0x2000 <ltmp0+0x2000>
    2a24:      	ldr	q2, [x9]
    2a28:      	and.16b	v7, v1, v2
    2a2c:      	fadd.4s	v2, v4, v21
    2a30:      	fadd.4s	v3, v6, v3
    2a34:      	ldr	q30, [sp, #0x170]
    2a38:      	zip1.8b	v16, v30, v0
    2a3c:      	ushll.4s	v16, v16, #0x0
    2a40:      	shl.4s	v16, v16, #0x1f
    2a44:      	cmlt.4s	v16, v16, #0
    2a48:      	and.16b	v3, v16, v3
    2a4c:      	zip2.8b	v16, v30, v0
    2a50:      	ushll.4s	v16, v16, #0x0
    2a54:      	shl.4s	v16, v16, #0x1f
    2a58:      	cmlt.4s	v16, v16, #0
    2a5c:      	and.16b	v2, v16, v2
    2a60:      	ldr	d17, [sp, #0x28]
    2a64:      	zip2.8b	v16, v17, v0
    2a68:      	ushll.4s	v16, v16, #0x0
    2a6c:      	shl.4s	v16, v16, #0x1f
    2a70:      	cmlt.4s	v16, v16, #0
    2a74:      	bit.16b	v2, v29, v16
    2a78:      	zip1.8b	v16, v17, v0
    2a7c:      	ushll.4s	v16, v16, #0x0
    2a80:      	shl.4s	v16, v16, #0x1f
    2a84:      	cmlt.4s	v16, v16, #0
    2a88:      	bit.16b	v3, v28, v16
    2a8c:      	fadd.4s	v3, v5, v3
    2a90:      	fadd.4s	v2, v27, v2
    2a94:      	fadd.4s	v2, v26, v2
    2a98:      	fadd.4s	v3, v25, v3
    2a9c:      	fadd.4s	v5, v24, v3
    2aa0:      	fadd.4s	v20, v20, v2
    2aa4:      	fmov	w9, s23
    2aa8:      	add	x17, sp, #0x428
    2aac:      	bfxil	x17, x9, #0, #3
    2ab0:      	ldr	q2, [sp, #0x160]
    2ab4:      	str	d2, [sp, #0x428]
    2ab8:      	ldrb	w17, [x17]
    2abc:      	add	x0, sp, #0x650
    2ac0:      	orr	x9, x0, x9, lsl #2
    2ac4:      	str	q20, [sp, #0x660]
    2ac8:      	str	q5, [sp, #0x650]
    2acc:      	ldr	s2, [x9]
    2ad0:      	tst	w4, w17
    2ad4:      	movi	d19, #0000000000000000
    2ad8:      	fcsel	s3, s2, s19, ne
    2adc:      	mov.s	w9, v23[1]
    2ae0:      	add	x17, sp, #0x428
    2ae4:      	bfxil	x17, x9, #0, #3
    2ae8:      	ldrb	w9, [x17]
    2aec:      	ldr	w12, [sp, #0x130]
    2af0:      	and	w9, w12, w9
    2af4:      	str	q5, [sp, #0x630]
    2af8:      	ldr	s2, [sp, #0x630]
    2afc:      	tst	w9, #0x1
    2b00:      	fcsel	s21, s2, s19, ne
    2b04:      	mov.s	w9, v23[2]
    2b08:      	add	x17, sp, #0x428
    2b0c:      	bfxil	x17, x9, #0, #3
    2b10:      	add	x0, sp, #0x610
    2b14:      	orr	x9, x0, x9, lsl #2
    2b18:      	ldrb	w17, [x17]
    2b1c:      	ldr	w13, [sp, #0x2c0]
    2b20:      	and	w17, w13, w17
    2b24:      	str	q20, [sp, #0x620]
    2b28:      	str	q5, [sp, #0x610]
    2b2c:      	ldr	s2, [x9]
    2b30:      	tst	w17, #0x1
    2b34:      	fcsel	s2, s2, s19, ne
    2b38:      	mov.s	w9, v23[3]
    2b3c:      	add	x17, sp, #0x428
    2b40:      	bfxil	x17, x9, #0, #3
    2b44:      	add	x0, sp, #0x5f0
    2b48:      	orr	x9, x0, x9, lsl #2
    2b4c:      	ldrb	w17, [x17]
    2b50:      	ldp	w21, w14, [sp, #0x4c]
    2b54:      	and	w17, w21, w17
    2b58:      	str	q20, [sp, #0x600]
    2b5c:      	str	q5, [sp, #0x5f0]
    2b60:      	ldr	s16, [x9]
    2b64:      	tst	w17, #0x1
    2b68:      	fcsel	s23, s16, s19, ne
    2b6c:      	fmov	w9, s22
    2b70:      	add	x17, sp, #0x428
    2b74:      	bfxil	x17, x9, #0, #3
    2b78:      	ldrb	w17, [x17]
    2b7c:      	and	w17, w14, w17
    2b80:      	str	q20, [sp, #0x5e0]
    2b84:      	str	q5, [sp, #0x5d0]
    2b88:      	add	x0, sp, #0x5d0
    2b8c:      	ldr	s16, [x0, w9, uxtw #2]
    2b90:      	tst	w17, #0x1
    2b94:      	fcsel	s16, s16, s19, ne
    2b98:      	mov.s	w9, v22[1]
    2b9c:      	add	x17, sp, #0x428
    2ba0:      	bfxil	x17, x9, #0, #3
    2ba4:      	ldrb	w17, [x17]
    2ba8:      	ldr	w3, [sp, #0x70]
    2bac:      	and	w17, w3, w17
    2bb0:      	str	q20, [sp, #0x5c0]
    2bb4:      	str	q5, [sp, #0x5b0]
    2bb8:      	add	x0, sp, #0x5b0
    2bbc:      	ldr	s17, [x0, w9, uxtw #2]
    2bc0:      	tst	w17, #0x1
    2bc4:      	fcsel	s17, s17, s19, ne
    2bc8:      	mov.s	w9, v22[2]
    2bcc:      	add	x17, sp, #0x428
    2bd0:      	bfxil	x17, x9, #0, #3
    2bd4:      	ldrb	w17, [x17]
    2bd8:      	and	w17, w1, w17
    2bdc:      	str	q20, [sp, #0x5a0]
    2be0:      	str	q5, [sp, #0x590]
    2be4:      	add	x0, sp, #0x590
    2be8:      	ldr	s18, [x0, w9, uxtw #2]
    2bec:      	tst	w17, #0x1
    2bf0:      	fcsel	s18, s18, s19, ne
    2bf4:      	mov.s	w9, v22[3]
    2bf8:      	add	x17, sp, #0x428
    2bfc:      	bfxil	x17, x9, #0, #3
    2c00:      	ldrb	w17, [x17]
    2c04:      	and	w17, w2, w17
    2c08:      	str	q20, [sp, #0x580]
    2c0c:      	str	q5, [sp, #0x570]
    2c10:      	add	x0, sp, #0x570
    2c14:      	ldr	s22, [x0, w9, uxtw #2]
    2c18:      	tst	w17, #0x1
    2c1c:      	fcsel	s22, s22, s19, ne
    2c20:      	mov.s	v16[1], v17[0]
    2c24:      	mov.s	v16[2], v18[0]
    2c28:      	mov.s	v16[3], v22[0]
    2c2c:      	mov.s	v3[1], v21[0]
    2c30:      	mov.s	v3[2], v2[0]
    2c34:      	mov.s	v3[3], v23[0]
    2c38:      	fadd.4s	v5, v5, v3
    2c3c:      	fadd.4s	v20, v20, v16
    2c40:      	fmov	w9, s7
    2c44:      	add	x17, sp, #0x428
    2c48:      	bfxil	x17, x9, #0, #3
    2c4c:      	ldrb	w17, [x17]
    2c50:      	add	x0, sp, #0x550
    2c54:      	orr	x9, x0, x9, lsl #2
    2c58:      	str	q20, [sp, #0x560]
    2c5c:      	str	q5, [sp, #0x550]
    2c60:      	ldr	s2, [x9]
    2c64:      	mov.s	w9, v7[1]
    2c68:      	tst	w4, w17
    2c6c:      	add	x17, sp, #0x428
    2c70:      	bfxil	x17, x9, #0, #3
    2c74:      	ldrb	w17, [x17]
    2c78:      	and	w15, w12, w17
    2c7c:      	fcsel	s3, s2, s19, ne
    2c80:      	add	x17, sp, #0x530
    2c84:      	orr	x9, x17, x9, lsl #2
    2c88:      	str	q20, [sp, #0x540]
    2c8c:      	str	q5, [sp, #0x530]
    2c90:      	ldr	s2, [x9]
    2c94:      	mov.s	w9, v7[2]
    2c98:      	tst	w15, #0x1
    2c9c:      	add	x15, sp, #0x428
    2ca0:      	bfxil	x15, x9, #0, #3
    2ca4:      	adrp	x9, 0x2000 <ltmp0+0x2000>
    2ca8:      	ldr	q16, [x9]
    2cac:      	and.16b	v16, v0, v16
    2cb0:      	movi.4s	v17, #0x4
    2cb4:      	and.16b	v21, v1, v17
    2cb8:      	fcsel	s2, s2, s19, ne
    2cbc:      	ldrb	w9, [x15]
    2cc0:      	and	w9, w13, w9
    2cc4:      	str	q5, [sp, #0x510]
    2cc8:      	ldr	s17, [sp, #0x510]
    2ccc:      	tst	w9, #0x1
    2cd0:      	fcsel	s22, s17, s19, ne
    2cd4:      	mov.s	w9, v7[3]
    2cd8:      	add	x13, sp, #0x428
    2cdc:      	bfxil	x13, x9, #0, #3
    2ce0:      	add	x15, sp, #0x4f0
    2ce4:      	orr	x9, x15, x9, lsl #2
    2ce8:      	ldrb	w13, [x13]
    2cec:      	and	w13, w21, w13
    2cf0:      	str	q20, [sp, #0x500]
    2cf4:      	str	q5, [sp, #0x4f0]
    2cf8:      	ldr	s7, [x9]
    2cfc:      	tst	w13, #0x1
    2d00:      	fcsel	s7, s7, s19, ne
    2d04:      	fmov	w9, s16
    2d08:      	add	x13, sp, #0x428
    2d0c:      	bfxil	x13, x9, #0, #3
    2d10:      	ldrb	w13, [x13]
    2d14:      	and	w13, w14, w13
    2d18:      	str	q20, [sp, #0x4e0]
    2d1c:      	str	q5, [sp, #0x4d0]
    2d20:      	add	x14, sp, #0x4d0
    2d24:      	ldr	s17, [x14, w9, uxtw #2]
    2d28:      	tst	w13, #0x1
    2d2c:      	fcsel	s17, s17, s19, ne
    2d30:      	mov.s	w9, v16[1]
    2d34:      	add	x13, sp, #0x428
    2d38:      	bfxil	x13, x9, #0, #3
    2d3c:      	ldrb	w13, [x13]
    2d40:      	and	w13, w3, w13
    2d44:      	str	q20, [sp, #0x4c0]
    2d48:      	str	q5, [sp, #0x4b0]
    2d4c:      	add	x14, sp, #0x4b0
    2d50:      	ldr	s18, [x14, w9, uxtw #2]
    2d54:      	tst	w13, #0x1
    2d58:      	fcsel	s18, s18, s19, ne
    2d5c:      	mov.s	w9, v16[2]
    2d60:      	add	x13, sp, #0x428
    2d64:      	bfxil	x13, x9, #0, #3
    2d68:      	ldrb	w13, [x13]
    2d6c:      	and	w13, w1, w13
    2d70:      	str	q20, [sp, #0x4a0]
    2d74:      	str	q5, [sp, #0x490]
    2d78:      	add	x14, sp, #0x490
    2d7c:      	ldr	s23, [x14, w9, uxtw #2]
    2d80:      	tst	w13, #0x1
    2d84:      	fcsel	s23, s23, s19, ne
    2d88:      	mov.s	w9, v16[3]
    2d8c:      	add	x13, sp, #0x428
    2d90:      	bfxil	x13, x9, #0, #3
    2d94:      	ldrb	w13, [x13]
    2d98:      	and	w13, w2, w13
    2d9c:      	str	q20, [sp, #0x480]
    2da0:      	str	q5, [sp, #0x470]
    2da4:      	add	x14, sp, #0x470
    2da8:      	ldr	s16, [x14, w9, uxtw #2]
    2dac:      	tst	w13, #0x1
    2db0:      	fcsel	s16, s16, s19, ne
    2db4:      	mov.s	v17[1], v18[0]
    2db8:      	mov.s	v17[2], v23[0]
    2dbc:      	mov.s	v17[3], v16[0]
    2dc0:      	mov.s	v3[1], v2[0]
    2dc4:      	mov.s	v3[2], v22[0]
    2dc8:      	mov.s	v3[3], v7[0]
    2dcc:      	fadd.4s	v2, v5, v3
    2dd0:      	fadd.4s	v3, v20, v17
    2dd4:      	fmov	w9, s21
    2dd8:      	add	x13, sp, #0x428
    2ddc:      	orr	x13, x13, x9
    2de0:      	ldrb	w13, [x13]
    2de4:      	str	q3, [sp, #0x460]
    2de8:      	str	q2, [sp, #0x450]
    2dec:      	add	x14, sp, #0x450
    2df0:      	ldr	s3, [x14, w9, uxtw #2]
    2df4:      	tst	w4, w13
    2df8:      	fcsel	s3, s3, s19, ne
    2dfc:      	ldr	w9, [sp, #0x60]
    2e00:      	tst	w9, #0x1
    2e04:      	fadd	s2, s2, s3
    2e08:      	fcsel	s3, s2, s19, ne
    2e0c:      	tst	w5, #0x1
    2e10:      	fcsel	s5, s2, s19, ne
    2e14:      	tst	w6, #0x1
    2e18:      	fcsel	s7, s2, s19, ne
    2e1c:      	tst	w7, #0x1
    2e20:      	fcsel	s16, s2, s19, ne
    2e24:      	tst	w26, #0x1
    2e28:      	fcsel	s17, s2, s19, ne
    2e2c:      	tst	w30, #0x1
    2e30:      	fcsel	s18, s2, s19, ne
    2e34:      	tst	w8, #0x1
    2e38:      	fcsel	s20, s2, s19, ne
    2e3c:      	tst	w11, #0x1
    2e40:      	fcsel	s2, s2, s19, ne
    2e44:      	mov.s	v3[1], v5[0]
    2e48:      	mov.s	v3[2], v7[0]
    2e4c:      	mov.s	v3[3], v16[0]
    2e50:      	mov.s	v17[1], v18[0]
    2e54:      	mov.s	v17[2], v20[0]
    2e58:      	mov.s	v17[3], v2[0]
    2e5c:      	str	q17, [sp, #0x440]
    2e60:      	str	q3, [sp, #0x430]
    2e64:      	and	x8, x10, #0x7
    2e68:      	add	x9, sp, #0x430
    2e6c:      	ldr	s2, [x9, x8, lsl #2]
    2e70:      	fadd	s2, s2, s19
    2e74:      	dup.4s	v5, v2[0]
    2e78:      	ldr	q2, [sp, #0xb0]
    2e7c:      	fmov	x8, d2
    2e80:      	ldp	x13, x12, [sp, #0x100]
    2e84:      	add	x8, x12, x8, lsl #2
    2e88:      	movi.2d	v3, #0000000000000000
    2e8c:      	movi.2d	v7, #0000000000000000
    2e90:      	movi.2d	v20, #0000000000000000
    2e94:      	movi.2d	v21, #0000000000000000
    2e98:      	mov	w0, #0x1808             ; =6152
    2e9c:      	adrp	x3, 0x2000 <ltmp0+0x2000>
    2ea0:      	ldp	q18, q17, [sp, #0x220]
    2ea4:      	ldr	q19, [sp, #0x370]
    2ea8:      	ldr	q23, [sp, #0x240]
    2eac:      	ldr	q24, [sp, #0x200]
    2eb0:      	b	0x2ed0 <ltmp0+0x2ed0>
    2eb4:      	add.2d	v7, v7, v19
    2eb8:      	add.2d	v20, v20, v23
    2ebc:      	add.2d	v21, v21, v18
    2ec0:      	add.2d	v3, v3, v24
    2ec4:      	fmov	x16, d3
    2ec8:      	cmp	x16, #0xc0
    2ecc:      	b.ge	0x2f80 <ltmp0+0x2f80>
    2ed0:      	fmov	w10, s17
    2ed4:      	lsl	x9, x16, #5
    2ed8:      	add	x11, x23, x9
    2edc:      	ldp	q16, q2, [x11]
    2ee0:      	and.16b	v16, v1, v16
    2ee4:      	fdiv.4s	v22, v16, v5
    2ee8:      	add	x9, x8, x9
    2eec:      	tbnz	w10, #0x0, 0x2f1c <ltmp0+0x2f1c>
    2ef0:      	and	w10, w10, #0xff
    2ef4:      	tbnz	w10, #0x1, 0x2f28 <ltmp0+0x2f28>
    2ef8:      	tbnz	w10, #0x2, 0x2f34 <ltmp0+0x2f34>
    2efc:      	tbnz	w10, #0x3, 0x2f40 <ltmp0+0x2f40>
    2f00:      	and.16b	v2, v0, v2
    2f04:      	fdiv.4s	v2, v2, v5
    2f08:      	tbnz	w10, #0x4, 0x2f54 <ltmp0+0x2f54>
    2f0c:      	tbnz	w10, #0x5, 0x2f5c <ltmp0+0x2f5c>
    2f10:      	tbnz	w10, #0x6, 0x2f68 <ltmp0+0x2f68>
    2f14:      	tbz	w10, #0x7, 0x2eb4 <ltmp0+0x2eb4>
    2f18:      	b	0x2f74 <ltmp0+0x2f74>
    2f1c:      	str	s22, [x9]
    2f20:      	and	w10, w10, #0xff
    2f24:      	tbz	w10, #0x1, 0x2ef8 <ltmp0+0x2ef8>
    2f28:      	add	x11, x9, #0x4
    2f2c:      	st1.s	{ v22 }[1], [x11]
    2f30:      	tbz	w10, #0x2, 0x2efc <ltmp0+0x2efc>
    2f34:      	add	x11, x9, #0x8
    2f38:      	st1.s	{ v22 }[2], [x11]
    2f3c:      	tbz	w10, #0x3, 0x2f00 <ltmp0+0x2f00>
    2f40:      	add	x11, x9, #0xc
    2f44:      	st1.s	{ v22 }[3], [x11]
    2f48:      	and.16b	v2, v0, v2
    2f4c:      	fdiv.4s	v2, v2, v5
    2f50:      	tbz	w10, #0x4, 0x2f0c <ltmp0+0x2f0c>
    2f54:      	str	s2, [x9, #0x10]
    2f58:      	tbz	w10, #0x5, 0x2f10 <ltmp0+0x2f10>
    2f5c:      	add	x11, x9, #0x14
    2f60:      	st1.s	{ v2 }[1], [x11]
    2f64:      	tbz	w10, #0x6, 0x2f14 <ltmp0+0x2f14>
    2f68:      	add	x11, x9, #0x18
    2f6c:      	st1.s	{ v2 }[2], [x11]
    2f70:      	tbz	w10, #0x7, 0x2eb4 <ltmp0+0x2eb4>
    2f74:      	add	x9, x9, #0x1c
    2f78:      	st1.s	{ v2 }[3], [x9]
    2f7c:      	b	0x2eb4 <ltmp0+0x2eb4>
    2f80:      	ldr	d0, [sp, #0xa8]
    2f84:      	fmov	w8, s0
    2f88:      	zip1.8b	v0, v30, v0
    2f8c:      	ushll.4s	v0, v0, #0x0
    2f90:      	shl.4s	v0, v0, #0x1f
    2f94:      	cmlt.4s	v0, v0, #0
    2f98:      	and.16b	v0, v0, v6
    2f9c:      	fdiv.4s	v0, v0, v5
    2fa0:      	ldr	q2, [sp, #0xf0]
    2fa4:      	ldp	q1, q3, [sp, #0xc0]
    2fa8:      	stp	q2, q3, [sp, #0x3e0]
    2fac:      	str	q1, [sp, #0x400]
    2fb0:      	ldr	q1, [sp, #0xe0]
    2fb4:      	str	q1, [sp, #0x410]
    2fb8:      	and	x9, x13, #0x7
    2fbc:      	add	x10, sp, #0x3e0
    2fc0:      	ldr	x9, [x10, x9, lsl #3]
    2fc4:      	sub	x9, x9, x13
    2fc8:      	add	x9, x12, x9, lsl #2
    2fcc:      	tbnz	w8, #0x0, 0x305c <ltmp0+0x305c>
    2fd0:      	tbnz	w8, #0x1, 0x3064 <ltmp0+0x3064>
    2fd4:      	tbnz	w8, #0x2, 0x3070 <ltmp0+0x3070>
    2fd8:      	tbz	w8, #0x3, 0x2fe4 <ltmp0+0x2fe4>
    2fdc:      	add	x10, x9, #0xc
    2fe0:      	st1.s	{ v0 }[3], [x10]
    2fe4:      	zip2.8b	v0, v30, v0
    2fe8:      	ushll.4s	v0, v0, #0x0
    2fec:      	shl.4s	v0, v0, #0x1f
    2ff0:      	cmlt.4s	v0, v0, #0
    2ff4:      	and.16b	v0, v0, v4
    2ff8:      	fdiv.4s	v0, v0, v5
    2ffc:      	tbnz	w8, #0x4, 0x3080 <ltmp0+0x3080>
    3000:      	tbnz	w8, #0x5, 0x3088 <ltmp0+0x3088>
    3004:      	tbnz	w8, #0x6, 0x3094 <ltmp0+0x3094>
    3008:      	tbz	w8, #0x7, 0x110 <ltmp0+0x110>
    300c:      	b	0x30a0 <ltmp0+0x30a0>
    3010:      	fmov	x9, d13
    3014:      	ld1.b	{ v3 }[2], [x9]
    3018:      	tbz	w13, #0x3, 0x1cec <ltmp0+0x1cec>
    301c:      	ld1.b	{ v3 }[3], [x11]
    3020:      	tbz	w13, #0x4, 0x1cf0 <ltmp0+0x1cf0>
    3024:      	fmov	x9, d24
    3028:      	ld1.b	{ v3 }[4], [x9]
    302c:      	ldr	q6, [sp, #0x220]
    3030:      	tbz	w13, #0x5, 0x1cf8 <ltmp0+0x1cf8>
    3034:      	ld1.b	{ v3 }[5], [x10]
    3038:      	tbz	w13, #0x6, 0x1cfc <ltmp0+0x1cfc>
    303c:      	fmov	x9, d20
    3040:      	ld1.b	{ v3 }[6], [x9]
    3044:      	stp	q27, q26, [sp, #0x1f0]
    3048:      	str	d22, [sp, #0xa8]
    304c:      	stp	q29, q28, [sp, #0x1d0]
    3050:      	stp	q12, q30, [sp, #0x1b0]
    3054:      	tbnz	w13, #0x7, 0x1d10 <ltmp0+0x1d10>
    3058:      	b	0x1d14 <ltmp0+0x1d14>
    305c:      	str	s0, [x9]
    3060:      	tbz	w8, #0x1, 0x2fd4 <ltmp0+0x2fd4>
    3064:      	add	x10, x9, #0x4
    3068:      	st1.s	{ v0 }[1], [x10]
    306c:      	tbz	w8, #0x2, 0x2fd8 <ltmp0+0x2fd8>
    3070:      	add	x10, x9, #0x8
    3074:      	st1.s	{ v0 }[2], [x10]
    3078:      	tbnz	w8, #0x3, 0x2fdc <ltmp0+0x2fdc>
    307c:      	b	0x2fe4 <ltmp0+0x2fe4>
    3080:      	str	s0, [x9, #0x10]
    3084:      	tbz	w8, #0x5, 0x3004 <ltmp0+0x3004>
    3088:      	add	x10, x9, #0x14
    308c:      	st1.s	{ v0 }[1], [x10]
    3090:      	tbz	w8, #0x6, 0x3008 <ltmp0+0x3008>
    3094:      	add	x10, x9, #0x18
    3098:      	st1.s	{ v0 }[2], [x10]
    309c:      	tbz	w8, #0x7, 0x110 <ltmp0+0x110>
    30a0:      	add	x8, x9, #0x1c
    30a4:      	st1.s	{ v0 }[3], [x8]
    30a8:      	b	0x110 <ltmp0+0x110>
    30ac:      	ldr	x9, [sp, #0x8]
    30b0:      	stp	w15, w14, [x9]
    30b4:      	str	w13, [x9, #0x8]
    30b8:      	mov	w8, #0x18               ; =24
    30bc:      	str	w8, [x9, #0x24]
    30c0:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    30c4:      	add	sp, sp, #0x920
    30c8:      	ldp	x29, x30, [sp, #0x90]
    30cc:      	ldp	x20, x19, [sp, #0x80]
    30d0:      	ldp	x22, x21, [sp, #0x70]
    30d4:      	ldp	x24, x23, [sp, #0x60]
    30d8:      	ldp	x26, x25, [sp, #0x50]
    30dc:      	ldp	x28, x27, [sp, #0x40]
    30e0:      	ldp	d9, d8, [sp, #0x30]
    30e4:      	ldp	d11, d10, [sp, #0x20]
    30e8:      	ldp	d13, d12, [sp, #0x10]
    30ec:      	ldp	d15, d14, [sp], #0xa0
    30f0:      	ret

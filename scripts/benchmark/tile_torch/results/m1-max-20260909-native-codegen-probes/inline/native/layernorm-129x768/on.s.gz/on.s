
/private/tmp/luisa-packet-inline.UY1lIE/capture/layernorm-129x768/on/object/tile_xir_w8_36322_1788935094582643_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d9, d8, [sp, #-0x70]!
       4:      	stp	x28, x27, [sp, #0x10]
       8:      	stp	x26, x25, [sp, #0x20]
       c:      	stp	x24, x23, [sp, #0x30]
      10:      	stp	x22, x21, [sp, #0x40]
      14:      	stp	x20, x19, [sp, #0x50]
      18:      	stp	x29, x30, [sp, #0x60]
      1c:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      20:      	sub	sp, sp, #0x4c0
      24:      	str	x0, [sp, #0x20]
      28:      	str	w3, [sp, #0x40]
      2c:      	cbz	w3, 0x15e8 <ltmp0+0x15e8>
      30:      	mov	w12, #0x0               ; =0
      34:      	add	x25, sp, #0x180
      38:      	add	x27, sp, #0x2, lsl #12  ; =0x2000
      3c:      	add	x27, x27, #0x8c0
      40:      	ldp	w9, w8, [x2, #0x2c]
      44:      	stp	w8, w9, [sp, #0x38]
      48:      	add	x9, x27, #0xe0
      4c:      	add	x26, sp, #0x1, lsl #12  ; =0x1000
      50:      	add	x26, x26, #0xcc0
      54:      	add	x8, x26, #0xe0
      58:      	stp	x8, x9, [sp, #0x10]
      5c:      	ldp	w8, w9, [x2]
      60:      	ldp	w10, w11, [x2, #0x8]
      64:      	str	x2, [sp, #0x8]
      68:      	str	x11, [sp, #0x30]
      6c:      	add	x21, sp, #0x1, lsl #12  ; =0x1000
      70:      	add	x21, x21, #0xc0
      74:      	movi	d8, #0000000000000000
      78:      	add	x24, sp, #0x4c0
      7c:      	b	0xc8 <ltmp0+0xc8>
      80:      	ldr	x15, [sp, #0x50]
      84:      	add	w8, w15, #0x1
      88:      	ldp	w11, w9, [sp, #0x38]
      8c:      	cmp	w8, w9
      90:      	cset	w9, eq
      94:      	csinc	w8, wzr, w15, eq
      98:      	ldp	w14, w13, [sp, #0x44]
      9c:      	cinc	w10, w14, eq
      a0:      	cmp	w10, w11
      a4:      	cset	w11, eq
      a8:      	ands	w11, w9, w11
      ac:      	csel	w9, wzr, w10, ne
      b0:      	add	w10, w13, w11
      b4:      	ldr	w12, [sp, #0x4c]
      b8:      	add	w12, w12, #0x1
      bc:      	ldr	w11, [sp, #0x40]
      c0:      	cmp	w12, w11
      c4:      	b.eq	0x15d4 <ltmp0+0x15d4>
      c8:      	str	w12, [sp, #0x4c]
      cc:      	mov	x13, x10
      d0:      	mov	x14, x9
      d4:      	mov	x15, x8
      d8:      	ubfiz	x8, x8, #5, #32
      dc:      	ldr	x12, [sp, #0x30]
      e0:      	cmp	x8, x12
      e4:      	csel	x9, x8, xzr, ls
      e8:      	subs	x10, x12, x9
      ec:      	cmp	x10, #0x20
      f0:      	mov	w11, #0x20              ; =32
      f4:      	csel	x10, x10, x11, lo
      f8:      	cmp	x12, x9
      fc:      	ccmp	x8, x12, #0x2, hi
     100:      	csel	x9, x10, xzr, ls
     104:      	cmp	x9, #0x20
     108:      	str	x15, [sp, #0x50]
     10c:      	stp	w14, w13, [sp, #0x44]
     110:      	b.lo	0x474 <ltmp0+0x474>
     114:      	mov	x19, #0x0               ; =0
     118:      	ldr	x8, [sp, #0x20]
     11c:      	ldr	x10, [x8]
     120:      	ldr	x9, [x8, #0x10]
     124:      	stp	x9, x10, [sp, #0x60]
     128:      	ldr	x23, [x8, #0x20]
     12c:      	ldr	x8, [x8, #0x30]
     130:      	subs	x9, x23, x8
     134:      	mov	w10, #0xbff             ; =3071
     138:      	movk	w10, #0x6, lsl #16
     13c:      	ccmp	x9, x10, #0x0, hs
     140:      	cset	w9, hi
     144:      	subs	x10, x8, x23
     148:      	mov	w11, #0xbff             ; =3071
     14c:      	ccmp	x10, x11, #0x0, hs
     150:      	csinc	w28, w9, wzr, ls
     154:      	and	x9, x15, #0x7ffffff
     158:      	mov	w10, #0x3000            ; =12288
     15c:      	umaddl	x20, w9, w10, x8
     160:      	lsl	w22, w15, #2
     164:      	b	0x178 <ltmp0+0x178>
     168:      	add	x19, x19, #0x1
     16c:      	add	x20, x20, #0xc00
     170:      	cmp	x19, #0x4
     174:      	b.eq	0x80 <ltmp0+0x80>
     178:      	add	w8, w19, w22
     17c:      	and	x8, x8, #0x1fffffff
     180:      	mov	w9, #0xc00              ; =3072
     184:      	ldr	x10, [sp, #0x68]
     188:      	umaddl	x1, w8, w9, x10
     18c:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     190:      	add	x0, x0, #0x8c0
     194:      	mov	w2, #0xc00              ; =3072
     198:      	bl	0x198 <ltmp0+0x198>
     19c:      	mov	x8, #0x0                ; =0
     1a0:      	ldr	q0, [x25, #0x2750]
     1a4:      	ldr	q2, [x25, #0x2740]
     1a8:      	ldr	q1, [x25, #0x2770]
     1ac:      	ldr	q6, [x25, #0x2760]
     1b0:      	ldr	q4, [x25, #0x2790]
     1b4:      	ldr	q3, [x25, #0x2780]
     1b8:      	ldr	q5, [x25, #0x27b0]
     1bc:      	ldr	q7, [x25, #0x27a0]
     1c0:      	add	x9, x27, x8, lsl #5
     1c4:      	ldp	q16, q17, [x9, #0x80]
     1c8:      	fadd.4s	v0, v0, v17
     1cc:      	fadd.4s	v2, v2, v16
     1d0:      	ldp	q16, q17, [x9, #0xa0]
     1d4:      	fadd.4s	v1, v1, v17
     1d8:      	fadd.4s	v6, v6, v16
     1dc:      	ldp	q16, q17, [x9, #0xc0]
     1e0:      	fadd.4s	v4, v4, v17
     1e4:      	fadd.4s	v3, v3, v16
     1e8:      	ldp	q16, q17, [x9, #0xe0]
     1ec:      	fadd.4s	v5, v5, v17
     1f0:      	fadd.4s	v7, v7, v16
     1f4:      	add	x8, x8, #0x4
     1f8:      	cmp	x8, #0x5c
     1fc:      	b.lo	0x1c0 <ltmp0+0x1c0>
     200:      	mov	x8, #0x0                ; =0
     204:      	fadd.4s	v2, v2, v6
     208:      	fadd.4s	v0, v0, v1
     20c:      	fadd.4s	v0, v0, v4
     210:      	fadd.4s	v1, v2, v3
     214:      	fadd.4s	v1, v1, v7
     218:      	fadd.4s	v0, v0, v5
     21c:      	rev64.4s	v2, v0
     220:      	rev64.4s	v3, v1
     224:      	fadd.4s	v1, v1, v3
     228:      	fadd.4s	v0, v0, v2
     22c:      	dup.4s	v2, v0[2]
     230:      	dup.4s	v3, v1[2]
     234:      	fadd.4s	v1, v1, v3
     238:      	fadd.4s	v0, v0, v2
     23c:      	fadd.4s	v0, v1, v0
     240:      	fadd	s0, s0, s8
     244:      	mov	w9, #0x44400000         ; =1145044992
     248:      	fmov	s1, w9
     24c:      	fdiv	s0, s0, s1
     250:      	dup.4s	v0, v0[0]
     254:      	add	x9, x27, x8
     258:      	ldp	q2, q1, [x9]
     25c:      	fsub.4s	v2, v2, v0
     260:      	fsub.4s	v1, v1, v0
     264:      	add	x9, x26, x8
     268:      	stp	q2, q1, [x9]
     26c:      	add	x8, x8, #0x20
     270:      	cmp	x8, #0xc00
     274:      	b.ne	0x254 <ltmp0+0x254>
     278:      	mov	x8, #0x0                ; =0
     27c:      	ldr	q0, [x25, #0x1b40]
     280:      	ldr	q1, [x25, #0x1b50]
     284:      	fmul.4s	v2, v1, v1
     288:      	fmul.4s	v3, v0, v0
     28c:      	ldr	q0, [x25, #0x1b60]
     290:      	ldr	q1, [x25, #0x1b70]
     294:      	fmul.4s	v4, v1, v1
     298:      	fmul.4s	v5, v0, v0
     29c:      	ldr	q0, [x25, #0x1b80]
     2a0:      	ldr	q1, [x25, #0x1b90]
     2a4:      	fmul.4s	v7, v1, v1
     2a8:      	fmul.4s	v6, v0, v0
     2ac:      	ldr	q0, [x25, #0x1ba0]
     2b0:      	ldr	q1, [x25, #0x1bb0]
     2b4:      	fmul.4s	v16, v1, v1
     2b8:      	fmul.4s	v17, v0, v0
     2bc:      	add	x9, x26, x8, lsl #5
     2c0:      	ldp	q1, q0, [x9, #0x80]
     2c4:      	fmul.4s	v1, v1, v1
     2c8:      	fmul.4s	v0, v0, v0
     2cc:      	fadd.4s	v2, v2, v0
     2d0:      	fadd.4s	v3, v3, v1
     2d4:      	ldp	q1, q0, [x9, #0xa0]
     2d8:      	fmul.4s	v1, v1, v1
     2dc:      	fmul.4s	v0, v0, v0
     2e0:      	fadd.4s	v4, v4, v0
     2e4:      	fadd.4s	v5, v5, v1
     2e8:      	ldp	q1, q0, [x9, #0xc0]
     2ec:      	fmul.4s	v1, v1, v1
     2f0:      	fmul.4s	v0, v0, v0
     2f4:      	fadd.4s	v7, v7, v0
     2f8:      	fadd.4s	v6, v6, v1
     2fc:      	ldp	q1, q0, [x9, #0xe0]
     300:      	fmul.4s	v1, v1, v1
     304:      	fmul.4s	v0, v0, v0
     308:      	fadd.4s	v16, v16, v0
     30c:      	fadd.4s	v17, v17, v1
     310:      	add	x8, x8, #0x4
     314:      	cmp	x8, #0x5c
     318:      	b.lo	0x2bc <ltmp0+0x2bc>
     31c:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     320:      	add	x0, x0, #0xc0
     324:      	ldr	x1, [sp, #0x60]
     328:      	mov	w2, #0xc00              ; =3072
     32c:      	stp	q4, q2, [sp, #0xa0]
     330:      	stp	q5, q3, [sp, #0x70]
     334:      	stp	q6, q16, [sp, #0xd0]
     338:      	str	q7, [sp, #0x90]
     33c:      	str	q17, [sp, #0xc0]
     340:      	bl	0x340 <ltmp0+0x340>
     344:      	ldp	q1, q0, [sp, #0x70]
     348:      	fadd.4s	v0, v0, v1
     34c:      	ldp	q2, q1, [sp, #0xa0]
     350:      	fadd.4s	v1, v1, v2
     354:      	ldr	q2, [sp, #0x90]
     358:      	fadd.4s	v1, v1, v2
     35c:      	ldp	q2, q3, [sp, #0xc0]
     360:      	fadd.4s	v0, v0, v3
     364:      	fadd.4s	v0, v0, v2
     368:      	ldr	q2, [sp, #0xe0]
     36c:      	fadd.4s	v1, v1, v2
     370:      	rev64.4s	v2, v1
     374:      	rev64.4s	v3, v0
     378:      	fadd.4s	v1, v1, v2
     37c:      	dup.4s	v2, v1[2]
     380:      	fadd.4s	v0, v0, v3
     384:      	dup.4s	v3, v0[2]
     388:      	fadd.4s	v0, v0, v3
     38c:      	fadd.4s	v1, v1, v2
     390:      	fadd.4s	v0, v0, v1
     394:      	fadd	s0, s0, s8
     398:      	mov	w8, #0x44400000         ; =1145044992
     39c:      	fmov	s1, w8
     3a0:      	fdiv	s0, s0, s1
     3a4:      	mov	w8, #0xc5ac             ; =50604
     3a8:      	movk	w8, #0x3727, lsl #16
     3ac:      	fmov	s1, w8
     3b0:      	fadd	s0, s0, s1
     3b4:      	fsqrt	s0, s0
     3b8:      	tbz	w28, #0x0, 0x40c <ltmp0+0x40c>
     3bc:      	mov	x8, #0x0                ; =0
     3c0:      	dup.4s	v0, v0[0]
     3c4:      	add	x9, x26, x8
     3c8:      	ldp	q2, q1, [x9]
     3cc:      	fdiv.4s	v2, v2, v0
     3d0:      	fdiv.4s	v1, v1, v0
     3d4:      	add	x9, x21, x8
     3d8:      	ldp	q3, q4, [x9]
     3dc:      	fmul.4s	v1, v1, v4
     3e0:      	fmul.4s	v2, v2, v3
     3e4:      	add	x9, x23, x8
     3e8:      	ldp	q4, q3, [x9]
     3ec:      	fadd.4s	v2, v2, v4
     3f0:      	fadd.4s	v1, v1, v3
     3f4:      	add	x9, x20, x8
     3f8:      	stp	q2, q1, [x9]
     3fc:      	add	x8, x8, #0x20
     400:      	cmp	x8, #0xc00
     404:      	b.ne	0x3c4 <ltmp0+0x3c4>
     408:      	b	0x168 <ltmp0+0x168>
     40c:      	add	x0, sp, #0x4c0
     410:      	mov	x1, x23
     414:      	mov	w2, #0xc00              ; =3072
     418:      	str	q0, [sp, #0xe0]
     41c:      	bl	0x41c <ltmp0+0x41c>
     420:      	mov	x8, #0x0                ; =0
     424:      	ldr	q0, [sp, #0xe0]
     428:      	dup.4s	v0, v0[0]
     42c:      	add	x9, x26, x8
     430:      	ldp	q2, q1, [x9]
     434:      	fdiv.4s	v2, v2, v0
     438:      	fdiv.4s	v1, v1, v0
     43c:      	add	x9, x21, x8
     440:      	ldp	q3, q4, [x9]
     444:      	fmul.4s	v1, v1, v4
     448:      	fmul.4s	v2, v2, v3
     44c:      	add	x9, x24, x8
     450:      	ldp	q4, q3, [x9]
     454:      	fadd.4s	v2, v2, v4
     458:      	fadd.4s	v1, v1, v3
     45c:      	add	x9, x20, x8
     460:      	stp	q2, q1, [x9]
     464:      	add	x8, x8, #0x20
     468:      	cmp	x8, #0xc00
     46c:      	b.ne	0x42c <ltmp0+0x42c>
     470:      	b	0x168 <ltmp0+0x168>
     474:      	lsr	x8, x9, #3
     478:      	str	x8, [sp, #0x68]
     47c:      	str	x9, [sp, #0x28]
     480:      	cmp	x9, #0x8
     484:      	b.hs	0x5d8 <ltmp0+0x5d8>
     488:      	ldr	x8, [sp, #0x28]
     48c:      	and	w8, w8, #0x7
     490:      	cbz	w8, 0x80 <ltmp0+0x80>
     494:      	dup.4s	v1, w8
     498:      	adrp	x8, 0x0 <ltmp0>
     49c:      	ldr	q4, [x8]
     4a0:      	adrp	x8, 0x0 <ltmp0>
     4a4:      	ldr	q5, [x8]
     4a8:      	cmhi.4s	v0, v1, v5
     4ac:      	cmhi.4s	v1, v1, v4
     4b0:      	uzp1.8h	v3, v1, v0
     4b4:      	umaxv.8h	h2, v3
     4b8:      	fmov	w8, s2
     4bc:      	ldr	x14, [sp, #0x50]
     4c0:      	tbz	w8, #0x0, 0x80 <ltmp0+0x80>
     4c4:      	mov	x11, #0x0               ; =0
     4c8:      	ldr	x13, [sp, #0x20]
     4cc:      	ldr	x12, [x13, #0x10]
     4d0:      	ldr	x8, [x13, #0x20]
     4d4:      	ldr	x9, [x13, #0x30]
     4d8:      	adrp	x10, 0x0 <ltmp0>
     4dc:      	ldr	q2, [x10]
     4e0:      	and.16b	v2, v3, v2
     4e4:      	addv.8h	h2, v2
     4e8:      	fmov	w10, s2
     4ec:      	and	w23, w10, #0xff
     4f0:      	ubfiz	w10, w14, #2, #27
     4f4:      	ldr	x14, [sp, #0x68]
     4f8:      	orr	w10, w10, w14
     4fc:      	ldr	x13, [x13]
     500:      	fmov	s6, w10
     504:      	and.16b	v6, v1, v6
     508:      	fmov	w10, s6
     50c:      	mov	w14, #0xc00             ; =3072
     510:      	umaddl	x13, w10, w14, x13
     514:      	umull	x10, w10, w14
     518:      	str	x10, [sp, #0xe0]
     51c:      	b	0x540 <ltmp0+0x540>
     520:      	add	x14, x27, x11
     524:      	ldp	q16, q17, [x14]
     528:      	bif.16b	v7, v17, v0
     52c:      	bif.16b	v6, v16, v1
     530:      	stp	q6, q7, [x14]
     534:      	add	x11, x11, #0x20
     538:      	cmp	x11, #0xc00
     53c:      	b.eq	0x940 <ltmp0+0x940>
     540:      	fmov	w15, s2
     544:      	add	x14, x13, x11
     548:      	movi.2d	v6, #0000000000000000
     54c:      	movi.2d	v7, #0000000000000000
     550:      	tbnz	w15, #0x0, 0x578 <ltmp0+0x578>
     554:      	and	w15, w15, #0xff
     558:      	tbnz	w15, #0x1, 0x584 <ltmp0+0x584>
     55c:      	tbnz	w15, #0x2, 0x590 <ltmp0+0x590>
     560:      	tbnz	w15, #0x3, 0x59c <ltmp0+0x59c>
     564:      	tbnz	w15, #0x4, 0x5a8 <ltmp0+0x5a8>
     568:      	tbnz	w15, #0x5, 0x5b4 <ltmp0+0x5b4>
     56c:      	tbnz	w15, #0x6, 0x5c0 <ltmp0+0x5c0>
     570:      	tbz	w15, #0x7, 0x520 <ltmp0+0x520>
     574:      	b	0x5cc <ltmp0+0x5cc>
     578:      	ldr	s6, [x14]
     57c:      	and	w15, w15, #0xff
     580:      	tbz	w15, #0x1, 0x55c <ltmp0+0x55c>
     584:      	add	x16, x14, #0x4
     588:      	ld1.s	{ v6 }[1], [x16]
     58c:      	tbz	w15, #0x2, 0x560 <ltmp0+0x560>
     590:      	add	x16, x14, #0x8
     594:      	ld1.s	{ v6 }[2], [x16]
     598:      	tbz	w15, #0x3, 0x564 <ltmp0+0x564>
     59c:      	add	x16, x14, #0xc
     5a0:      	ld1.s	{ v6 }[3], [x16]
     5a4:      	tbz	w15, #0x4, 0x568 <ltmp0+0x568>
     5a8:      	add	x16, x14, #0x10
     5ac:      	ld1.s	{ v7 }[0], [x16]
     5b0:      	tbz	w15, #0x5, 0x56c <ltmp0+0x56c>
     5b4:      	add	x16, x14, #0x14
     5b8:      	ld1.s	{ v7 }[1], [x16]
     5bc:      	tbz	w15, #0x6, 0x570 <ltmp0+0x570>
     5c0:      	add	x16, x14, #0x18
     5c4:      	ld1.s	{ v7 }[2], [x16]
     5c8:      	tbz	w15, #0x7, 0x520 <ltmp0+0x520>
     5cc:      	add	x14, x14, #0x1c
     5d0:      	ld1.s	{ v7 }[3], [x14]
     5d4:      	b	0x520 <ltmp0+0x520>
     5d8:      	mov	x20, #0x0               ; =0
     5dc:      	ldr	x8, [sp, #0x20]
     5e0:      	ldr	x10, [x8]
     5e4:      	ldr	x9, [x8, #0x10]
     5e8:      	stp	x9, x10, [sp, #0x58]
     5ec:      	ldr	x23, [x8, #0x20]
     5f0:      	ldr	x8, [x8, #0x30]
     5f4:      	subs	x9, x23, x8
     5f8:      	mov	w10, #0xbff             ; =3071
     5fc:      	movk	w10, #0x6, lsl #16
     600:      	ccmp	x9, x10, #0x0, hs
     604:      	cset	w9, hi
     608:      	subs	x10, x8, x23
     60c:      	mov	w11, #0xbff             ; =3071
     610:      	ccmp	x10, x11, #0x0, hs
     614:      	csinc	w28, w9, wzr, ls
     618:      	ldr	x11, [sp, #0x50]
     61c:      	and	x9, x11, #0x7ffffff
     620:      	mov	w10, #0x3000            ; =12288
     624:      	umaddl	x19, w9, w10, x8
     628:      	lsl	w22, w11, #2
     62c:      	b	0x644 <ltmp0+0x644>
     630:      	add	x20, x20, #0x1
     634:      	add	x19, x19, #0xc00
     638:      	ldr	x8, [sp, #0x68]
     63c:      	cmp	x20, x8
     640:      	b.eq	0x488 <ltmp0+0x488>
     644:      	add	w8, w20, w22
     648:      	and	x8, x8, #0x1fffffff
     64c:      	mov	w9, #0xc00              ; =3072
     650:      	ldr	x10, [sp, #0x60]
     654:      	umaddl	x1, w8, w9, x10
     658:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     65c:      	add	x0, x0, #0x8c0
     660:      	mov	w2, #0xc00              ; =3072
     664:      	bl	0x664 <ltmp0+0x664>
     668:      	mov	x8, #0x0                ; =0
     66c:      	ldr	q0, [x25, #0x2750]
     670:      	ldr	q2, [x25, #0x2740]
     674:      	ldr	q1, [x25, #0x2770]
     678:      	ldr	q6, [x25, #0x2760]
     67c:      	ldr	q4, [x25, #0x2790]
     680:      	ldr	q3, [x25, #0x2780]
     684:      	ldr	q5, [x25, #0x27b0]
     688:      	ldr	q7, [x25, #0x27a0]
     68c:      	add	x9, x27, x8, lsl #5
     690:      	ldp	q16, q17, [x9, #0x80]
     694:      	fadd.4s	v0, v0, v17
     698:      	fadd.4s	v2, v2, v16
     69c:      	ldp	q16, q17, [x9, #0xa0]
     6a0:      	fadd.4s	v1, v1, v17
     6a4:      	fadd.4s	v6, v6, v16
     6a8:      	ldp	q16, q17, [x9, #0xc0]
     6ac:      	fadd.4s	v4, v4, v17
     6b0:      	fadd.4s	v3, v3, v16
     6b4:      	ldp	q16, q17, [x9, #0xe0]
     6b8:      	fadd.4s	v5, v5, v17
     6bc:      	fadd.4s	v7, v7, v16
     6c0:      	add	x8, x8, #0x4
     6c4:      	cmp	x8, #0x5c
     6c8:      	b.lo	0x68c <ltmp0+0x68c>
     6cc:      	mov	x8, #0x0                ; =0
     6d0:      	fadd.4s	v2, v2, v6
     6d4:      	fadd.4s	v0, v0, v1
     6d8:      	fadd.4s	v0, v0, v4
     6dc:      	fadd.4s	v1, v2, v3
     6e0:      	fadd.4s	v1, v1, v7
     6e4:      	fadd.4s	v0, v0, v5
     6e8:      	rev64.4s	v2, v0
     6ec:      	rev64.4s	v3, v1
     6f0:      	fadd.4s	v1, v1, v3
     6f4:      	fadd.4s	v0, v0, v2
     6f8:      	dup.4s	v2, v0[2]
     6fc:      	dup.4s	v3, v1[2]
     700:      	fadd.4s	v1, v1, v3
     704:      	fadd.4s	v0, v0, v2
     708:      	fadd.4s	v0, v1, v0
     70c:      	fadd	s0, s0, s8
     710:      	mov	w9, #0x44400000         ; =1145044992
     714:      	fmov	s1, w9
     718:      	fdiv	s0, s0, s1
     71c:      	dup.4s	v0, v0[0]
     720:      	add	x9, x27, x8
     724:      	ldp	q2, q1, [x9]
     728:      	fsub.4s	v2, v2, v0
     72c:      	fsub.4s	v1, v1, v0
     730:      	add	x9, x26, x8
     734:      	stp	q2, q1, [x9]
     738:      	add	x8, x8, #0x20
     73c:      	cmp	x8, #0xc00
     740:      	b.ne	0x720 <ltmp0+0x720>
     744:      	mov	x8, #0x0                ; =0
     748:      	ldr	q0, [x25, #0x1b40]
     74c:      	ldr	q1, [x25, #0x1b50]
     750:      	fmul.4s	v2, v1, v1
     754:      	fmul.4s	v3, v0, v0
     758:      	ldr	q0, [x25, #0x1b60]
     75c:      	ldr	q1, [x25, #0x1b70]
     760:      	fmul.4s	v4, v1, v1
     764:      	fmul.4s	v5, v0, v0
     768:      	ldr	q0, [x25, #0x1b80]
     76c:      	ldr	q1, [x25, #0x1b90]
     770:      	fmul.4s	v7, v1, v1
     774:      	fmul.4s	v6, v0, v0
     778:      	ldr	q0, [x25, #0x1ba0]
     77c:      	ldr	q1, [x25, #0x1bb0]
     780:      	fmul.4s	v16, v1, v1
     784:      	fmul.4s	v17, v0, v0
     788:      	add	x9, x26, x8, lsl #5
     78c:      	ldp	q1, q0, [x9, #0x80]
     790:      	fmul.4s	v1, v1, v1
     794:      	fmul.4s	v0, v0, v0
     798:      	fadd.4s	v2, v2, v0
     79c:      	fadd.4s	v3, v3, v1
     7a0:      	ldp	q1, q0, [x9, #0xa0]
     7a4:      	fmul.4s	v1, v1, v1
     7a8:      	fmul.4s	v0, v0, v0
     7ac:      	fadd.4s	v4, v4, v0
     7b0:      	fadd.4s	v5, v5, v1
     7b4:      	ldp	q1, q0, [x9, #0xc0]
     7b8:      	fmul.4s	v1, v1, v1
     7bc:      	fmul.4s	v0, v0, v0
     7c0:      	fadd.4s	v7, v7, v0
     7c4:      	fadd.4s	v6, v6, v1
     7c8:      	ldp	q1, q0, [x9, #0xe0]
     7cc:      	fmul.4s	v1, v1, v1
     7d0:      	fmul.4s	v0, v0, v0
     7d4:      	fadd.4s	v16, v16, v0
     7d8:      	fadd.4s	v17, v17, v1
     7dc:      	add	x8, x8, #0x4
     7e0:      	cmp	x8, #0x5c
     7e4:      	b.lo	0x788 <ltmp0+0x788>
     7e8:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     7ec:      	add	x0, x0, #0xc0
     7f0:      	ldr	x1, [sp, #0x58]
     7f4:      	mov	w2, #0xc00              ; =3072
     7f8:      	stp	q4, q2, [sp, #0xa0]
     7fc:      	stp	q5, q3, [sp, #0x70]
     800:      	stp	q6, q16, [sp, #0xd0]
     804:      	str	q7, [sp, #0x90]
     808:      	str	q17, [sp, #0xc0]
     80c:      	bl	0x80c <ltmp0+0x80c>
     810:      	ldp	q1, q0, [sp, #0x70]
     814:      	fadd.4s	v0, v0, v1
     818:      	ldp	q2, q1, [sp, #0xa0]
     81c:      	fadd.4s	v1, v1, v2
     820:      	ldr	q2, [sp, #0x90]
     824:      	fadd.4s	v1, v1, v2
     828:      	ldp	q2, q3, [sp, #0xc0]
     82c:      	fadd.4s	v0, v0, v3
     830:      	fadd.4s	v0, v0, v2
     834:      	ldr	q2, [sp, #0xe0]
     838:      	fadd.4s	v1, v1, v2
     83c:      	rev64.4s	v2, v1
     840:      	rev64.4s	v3, v0
     844:      	fadd.4s	v1, v1, v2
     848:      	dup.4s	v2, v1[2]
     84c:      	fadd.4s	v0, v0, v3
     850:      	dup.4s	v3, v0[2]
     854:      	fadd.4s	v0, v0, v3
     858:      	fadd.4s	v1, v1, v2
     85c:      	fadd.4s	v0, v0, v1
     860:      	fadd	s0, s0, s8
     864:      	mov	w8, #0x44400000         ; =1145044992
     868:      	fmov	s1, w8
     86c:      	fdiv	s0, s0, s1
     870:      	mov	w8, #0xc5ac             ; =50604
     874:      	movk	w8, #0x3727, lsl #16
     878:      	fmov	s1, w8
     87c:      	fadd	s0, s0, s1
     880:      	fsqrt	s0, s0
     884:      	tbz	w28, #0x0, 0x8d8 <ltmp0+0x8d8>
     888:      	mov	x8, #0x0                ; =0
     88c:      	dup.4s	v0, v0[0]
     890:      	add	x9, x26, x8
     894:      	ldp	q2, q1, [x9]
     898:      	fdiv.4s	v2, v2, v0
     89c:      	fdiv.4s	v1, v1, v0
     8a0:      	add	x9, x21, x8
     8a4:      	ldp	q3, q4, [x9]
     8a8:      	fmul.4s	v1, v1, v4
     8ac:      	fmul.4s	v2, v2, v3
     8b0:      	add	x9, x23, x8
     8b4:      	ldp	q4, q3, [x9]
     8b8:      	fadd.4s	v2, v2, v4
     8bc:      	fadd.4s	v1, v1, v3
     8c0:      	add	x9, x19, x8
     8c4:      	stp	q2, q1, [x9]
     8c8:      	add	x8, x8, #0x20
     8cc:      	cmp	x8, #0xc00
     8d0:      	b.ne	0x890 <ltmp0+0x890>
     8d4:      	b	0x630 <ltmp0+0x630>
     8d8:      	add	x0, sp, #0x4c0
     8dc:      	mov	x1, x23
     8e0:      	mov	w2, #0xc00              ; =3072
     8e4:      	str	q0, [sp, #0xe0]
     8e8:      	bl	0x8e8 <ltmp0+0x8e8>
     8ec:      	mov	x8, #0x0                ; =0
     8f0:      	ldr	q0, [sp, #0xe0]
     8f4:      	dup.4s	v0, v0[0]
     8f8:      	add	x9, x26, x8
     8fc:      	ldp	q2, q1, [x9]
     900:      	fdiv.4s	v2, v2, v0
     904:      	fdiv.4s	v1, v1, v0
     908:      	add	x9, x21, x8
     90c:      	ldp	q3, q4, [x9]
     910:      	fmul.4s	v1, v1, v4
     914:      	fmul.4s	v2, v2, v3
     918:      	add	x9, x24, x8
     91c:      	ldp	q4, q3, [x9]
     920:      	fadd.4s	v2, v2, v4
     924:      	fadd.4s	v1, v1, v3
     928:      	add	x9, x19, x8
     92c:      	stp	q2, q1, [x9]
     930:      	add	x8, x8, #0x20
     934:      	cmp	x8, #0xc00
     938:      	b.ne	0x8f8 <ltmp0+0x8f8>
     93c:      	b	0x630 <ltmp0+0x630>
     940:      	ldr	q6, [x25, #0x2740]
     944:      	ldr	q7, [x25, #0x2750]
     948:      	ldr	q16, [x25, #0x2760]
     94c:      	ldr	q17, [x25, #0x2770]
     950:      	ldr	q18, [x25, #0x2780]
     954:      	ldr	q21, [x25, #0x2790]
     958:      	ldr	q22, [x25, #0x27a0]
     95c:      	and.16b	v7, v0, v7
     960:      	and.16b	v6, v1, v6
     964:      	ldr	q23, [x25, #0x27b0]
     968:      	and.16b	v20, v0, v17
     96c:      	and.16b	v19, v1, v16
     970:      	and.16b	v16, v0, v21
     974:      	and.16b	v21, v1, v18
     978:      	and.16b	v18, v0, v23
     97c:      	and.16b	v17, v1, v22
     980:      	ldr	x11, [sp, #0x18]
     984:      	mov	w13, #0x4               ; =4
     988:      	ldp	q23, q22, [x11, #-0x60]
     98c:      	fadd.4s	v23, v6, v23
     990:      	fadd.4s	v22, v7, v22
     994:      	ldp	q25, q24, [x11, #-0x40]
     998:      	fadd.4s	v25, v19, v25
     99c:      	fadd.4s	v24, v20, v24
     9a0:      	ldp	q27, q26, [x11, #-0x20]
     9a4:      	fadd.4s	v27, v21, v27
     9a8:      	fadd.4s	v26, v16, v26
     9ac:      	ldp	q29, q28, [x11], #0x80
     9b0:      	fadd.4s	v29, v17, v29
     9b4:      	fadd.4s	v28, v18, v28
     9b8:      	bit.16b	v7, v22, v0
     9bc:      	bit.16b	v6, v23, v1
     9c0:      	bit.16b	v20, v24, v0
     9c4:      	bit.16b	v19, v25, v1
     9c8:      	bit.16b	v16, v26, v0
     9cc:      	bit.16b	v21, v27, v1
     9d0:      	bit.16b	v18, v28, v0
     9d4:      	bit.16b	v17, v29, v1
     9d8:      	cmp	x13, #0x5c
     9dc:      	add	x13, x13, #0x4
     9e0:      	b.lo	0x988 <ltmp0+0x988>
     9e4:      	mov	x19, #0x0               ; =0
     9e8:      	xtn.8b	v3, v3
     9ec:      	fadd.4s	v7, v7, v20
     9f0:      	fadd.4s	v6, v6, v19
     9f4:      	fadd.4s	v19, v6, v21
     9f8:      	fadd.4s	v6, v7, v16
     9fc:      	fadd.4s	v6, v6, v18
     a00:      	fadd.4s	v7, v19, v17
     a04:      	and.16b	v17, v1, v4
     a08:      	and.16b	v4, v0, v5
     a0c:      	movi.4s	v5, #0x1
     a10:      	eor.16b	v16, v4, v5
     a14:      	eor.16b	v19, v17, v5
     a18:      	umov.b	w11, v3[0]
     a1c:      	str	q7, [x25, #0x310]
     a20:      	ldr	s5, [sp, #0x494]
     a24:      	umov.b	w14, v3[1]
     a28:      	ands	w13, w11, #0x1
     a2c:      	tst	w13, w14
     a30:      	fcsel	s5, s5, s8, ne
     a34:      	mov.s	w15, v19[1]
     a38:      	add	x10, sp, #0x470
     a3c:      	orr	x16, x10, x15, lsl #2
     a40:      	add	x17, sp, #0x348
     a44:      	bfxil	x17, x15, #0, #3
     a48:      	str	d3, [x25, #0x1c8]
     a4c:      	ldrb	w15, [x17]
     a50:      	and	w15, w14, w15
     a54:      	stp	q7, q6, [x25, #0x2f0]
     a58:      	ldr	s17, [x16]
     a5c:      	tst	w15, #0x1
     a60:      	fcsel	s17, s17, s8, ne
     a64:      	mov.s	w15, v19[2]
     a68:      	add	x10, sp, #0x450
     a6c:      	orr	x16, x10, x15, lsl #2
     a70:      	add	x17, sp, #0x348
     a74:      	bfxil	x17, x15, #0, #3
     a78:      	ldrb	w15, [x17]
     a7c:      	umov.b	w1, v3[2]
     a80:      	and	w15, w1, w15
     a84:      	stp	q7, q6, [x25, #0x2d0]
     a88:      	ldr	s18, [x16]
     a8c:      	tst	w15, #0x1
     a90:      	fcsel	s18, s18, s8, ne
     a94:      	mov.s	w15, v19[3]
     a98:      	add	x10, sp, #0x430
     a9c:      	orr	x16, x10, x15, lsl #2
     aa0:      	add	x17, sp, #0x348
     aa4:      	bfxil	x17, x15, #0, #3
     aa8:      	ldrb	w15, [x17]
     aac:      	umov.b	w2, v3[3]
     ab0:      	and	w15, w2, w15
     ab4:      	stp	q7, q6, [x25, #0x2b0]
     ab8:      	ldr	s19, [x16]
     abc:      	tst	w15, #0x1
     ac0:      	fcsel	s19, s19, s8, ne
     ac4:      	fmov	w16, s16
     ac8:      	add	x15, sp, #0x348
     acc:      	bfxil	x15, x16, #0, #3
     ad0:      	ldrb	w17, [x15]
     ad4:      	umov.b	w15, v3[4]
     ad8:      	and	w17, w15, w17
     adc:      	stp	q7, q6, [x25, #0x290]
     ae0:      	add	x10, sp, #0x410
     ae4:      	ldr	s20, [x10, w16, uxtw #2]
     ae8:      	tst	w17, #0x1
     aec:      	fcsel	s20, s20, s8, ne
     af0:      	mov.s	w17, v16[1]
     af4:      	add	x0, sp, #0x348
     af8:      	bfxil	x0, x17, #0, #3
     afc:      	umov.b	w16, v3[5]
     b00:      	ldrb	w0, [x0]
     b04:      	and	w0, w16, w0
     b08:      	stp	q7, q6, [x25, #0x270]
     b0c:      	add	x10, sp, #0x3f0
     b10:      	ldr	s21, [x10, w17, uxtw #2]
     b14:      	tst	w0, #0x1
     b18:      	fcsel	s21, s21, s8, ne
     b1c:      	mov.s	w0, v16[2]
     b20:      	add	x17, sp, #0x348
     b24:      	bfxil	x17, x0, #0, #3
     b28:      	ldrb	w3, [x17]
     b2c:      	umov.b	w17, v3[6]
     b30:      	and	w3, w17, w3
     b34:      	stp	q7, q6, [x25, #0x250]
     b38:      	add	x10, sp, #0x3d0
     b3c:      	ldr	s22, [x10, w0, uxtw #2]
     b40:      	tst	w3, #0x1
     b44:      	fcsel	s22, s22, s8, ne
     b48:      	mov.s	w3, v16[3]
     b4c:      	add	x0, sp, #0x348
     b50:      	bfxil	x0, x3, #0, #3
     b54:      	ldrb	w4, [x0]
     b58:      	umov.b	w0, v3[7]
     b5c:      	and	w4, w0, w4
     b60:      	stp	q7, q6, [x25, #0x230]
     b64:      	add	x10, sp, #0x3b0
     b68:      	ldr	s16, [x10, w3, uxtw #2]
     b6c:      	tst	w4, #0x1
     b70:      	fcsel	s16, s16, s8, ne
     b74:      	mov.s	v5[1], v17[0]
     b78:      	mov.s	v5[2], v18[0]
     b7c:      	mov.s	v5[3], v19[0]
     b80:      	mov.s	v20[1], v21[0]
     b84:      	mov.s	v20[2], v22[0]
     b88:      	mov.s	v20[3], v16[0]
     b8c:      	fadd.4s	v6, v6, v20
     b90:      	fadd.4s	v5, v7, v5
     b94:      	movi.4s	v7, #0x2
     b98:      	eor.16b	v4, v4, v7
     b9c:      	str	q5, [x25, #0x210]
     ba0:      	ldr	s7, [sp, #0x398]
     ba4:      	tst	w13, w1
     ba8:      	fcsel	s7, s7, s8, ne
     bac:      	fmov	w13, s4
     bb0:      	add	x3, sp, #0x348
     bb4:      	bfxil	x3, x13, #0, #3
     bb8:      	ldrb	w3, [x3]
     bbc:      	and	w3, w15, w3
     bc0:      	stp	q5, q6, [x25, #0x1f0]
     bc4:      	add	x10, sp, #0x370
     bc8:      	ldr	s4, [x10, w13, uxtw #2]
     bcc:      	tst	w3, #0x1
     bd0:      	fcsel	s4, s4, s8, ne
     bd4:      	fadd.4s	v4, v6, v4
     bd8:      	and	w13, w11, w15
     bdc:      	tst	w13, #0x1
     be0:      	fcsel	s4, s4, s8, ne
     be4:      	ands	w30, w11, #0x1
     be8:      	fadd.4s	v5, v5, v7
     bec:      	fadd	s4, s5, s4
     bf0:      	fcsel	s5, s4, s8, ne
     bf4:      	tst	w13, #0x1
     bf8:      	and	w3, w14, w11
     bfc:      	fcsel	s6, s4, s8, ne
     c00:      	tst	w3, #0x1
     c04:      	and	w4, w1, w11
     c08:      	fcsel	s7, s4, s8, ne
     c0c:      	tst	w4, #0x1
     c10:      	and	w5, w2, w11
     c14:      	fcsel	s16, s4, s8, ne
     c18:      	tst	w5, #0x1
     c1c:      	fcsel	s17, s4, s8, ne
     c20:      	and	w6, w16, w11
     c24:      	tst	w6, #0x1
     c28:      	fcsel	s18, s4, s8, ne
     c2c:      	and	w7, w17, w11
     c30:      	tst	w7, #0x1
     c34:      	fcsel	s19, s4, s8, ne
     c38:      	and	w22, w0, w11
     c3c:      	tst	w22, #0x1
     c40:      	mov.s	v5[1], v7[0]
     c44:      	mov.s	v5[2], v16[0]
     c48:      	mov.s	v5[3], v17[0]
     c4c:      	mov.s	v6[1], v18[0]
     c50:      	fcsel	s4, s4, s8, ne
     c54:      	mov.s	v6[2], v19[0]
     c58:      	mov.s	v6[3], v4[0]
     c5c:      	rbit	w20, w23
     c60:      	clz	w23, w20
     c64:      	stp	q5, q6, [x25, #0x1d0]
     c68:      	and	x20, x23, #0x7
     c6c:      	add	x10, sp, #0x350
     c70:      	ldr	s4, [x10, x20, lsl #2]
     c74:      	fadd	s4, s4, s8
     c78:      	mov	w10, #0x44400000        ; =1145044992
     c7c:      	fmov	s5, w10
     c80:      	fdiv	s4, s4, s5
     c84:      	dup.4s	v4, v4[0]
     c88:      	add	x20, x27, x19
     c8c:      	ldp	q6, q5, [x20]
     c90:      	fsub.4s	v6, v6, v4
     c94:      	fsub.4s	v5, v5, v4
     c98:      	add	x20, x26, x19
     c9c:      	ldp	q7, q16, [x20]
     ca0:      	bif.16b	v5, v16, v0
     ca4:      	bif.16b	v6, v7, v1
     ca8:      	stp	q6, q5, [x20]
     cac:      	add	x19, x19, #0x20
     cb0:      	cmp	x19, #0xc00
     cb4:      	b.ne	0xc88 <ltmp0+0xc88>
     cb8:      	ldr	q4, [x25, #0x1b50]
     cbc:      	ldr	q5, [x25, #0x1b40]
     cc0:      	fmul.4s	v6, v5, v5
     cc4:      	fmul.4s	v4, v4, v4
     cc8:      	ldr	q5, [x25, #0x1b70]
     ccc:      	ldr	q7, [x25, #0x1b60]
     cd0:      	fmul.4s	v7, v7, v7
     cd4:      	fmul.4s	v16, v5, v5
     cd8:      	ldr	q5, [x25, #0x1b90]
     cdc:      	ldr	q17, [x25, #0x1b80]
     ce0:      	fmul.4s	v19, v17, v17
     ce4:      	fmul.4s	v20, v5, v5
     ce8:      	ldr	q5, [x25, #0x1bb0]
     cec:      	ldr	q17, [x25, #0x1ba0]
     cf0:      	fmul.4s	v21, v17, v17
     cf4:      	fmul.4s	v22, v5, v5
     cf8:      	and.16b	v5, v0, v4
     cfc:      	and.16b	v4, v1, v6
     d00:      	and.16b	v18, v0, v16
     d04:      	and.16b	v17, v1, v7
     d08:      	and.16b	v6, v0, v20
     d0c:      	and.16b	v19, v1, v19
     d10:      	and.16b	v16, v0, v22
     d14:      	and.16b	v7, v1, v21
     d18:      	ldr	x19, [sp, #0x10]
     d1c:      	mov	w20, #0x4               ; =4
     d20:      	ldp	q21, q20, [x19, #-0x60]
     d24:      	and.16b	v21, v1, v21
     d28:      	and.16b	v20, v0, v20
     d2c:      	fmul.4s	v20, v20, v20
     d30:      	fmul.4s	v21, v21, v21
     d34:      	fadd.4s	v21, v4, v21
     d38:      	fadd.4s	v20, v5, v20
     d3c:      	ldp	q23, q22, [x19, #-0x40]
     d40:      	and.16b	v23, v1, v23
     d44:      	and.16b	v22, v0, v22
     d48:      	fmul.4s	v22, v22, v22
     d4c:      	fmul.4s	v23, v23, v23
     d50:      	fadd.4s	v23, v17, v23
     d54:      	fadd.4s	v22, v18, v22
     d58:      	ldp	q25, q24, [x19, #-0x20]
     d5c:      	and.16b	v25, v1, v25
     d60:      	and.16b	v24, v0, v24
     d64:      	fmul.4s	v24, v24, v24
     d68:      	fmul.4s	v25, v25, v25
     d6c:      	fadd.4s	v25, v19, v25
     d70:      	fadd.4s	v24, v6, v24
     d74:      	ldp	q27, q26, [x19], #0x80
     d78:      	and.16b	v27, v1, v27
     d7c:      	and.16b	v26, v0, v26
     d80:      	fmul.4s	v26, v26, v26
     d84:      	fmul.4s	v27, v27, v27
     d88:      	fadd.4s	v27, v7, v27
     d8c:      	fadd.4s	v26, v16, v26
     d90:      	bit.16b	v5, v20, v0
     d94:      	bit.16b	v4, v21, v1
     d98:      	bit.16b	v18, v22, v0
     d9c:      	bit.16b	v17, v23, v1
     da0:      	bit.16b	v6, v24, v0
     da4:      	bit.16b	v19, v25, v1
     da8:      	bit.16b	v16, v26, v0
     dac:      	bit.16b	v7, v27, v1
     db0:      	cmp	x20, #0x5c
     db4:      	add	x20, x20, #0x4
     db8:      	b.lo	0xd20 <ltmp0+0xd20>
     dbc:      	mov	x19, #0x0               ; =0
     dc0:      	b	0xde4 <ltmp0+0xde4>
     dc4:      	add	x10, x21, x19
     dc8:      	ldp	q22, q23, [x10]
     dcc:      	bif.16b	v21, v23, v0
     dd0:      	bif.16b	v20, v22, v1
     dd4:      	stp	q20, q21, [x10]
     dd8:      	add	x19, x19, #0x20
     ddc:      	cmp	x19, #0xc00
     de0:      	b.eq	0xe7c <ltmp0+0xe7c>
     de4:      	fmov	w28, s2
     de8:      	add	x20, x12, x19
     dec:      	movi.2d	v20, #0000000000000000
     df0:      	movi.2d	v21, #0000000000000000
     df4:      	tbnz	w28, #0x0, 0xe1c <ltmp0+0xe1c>
     df8:      	and	w28, w28, #0xff
     dfc:      	tbnz	w28, #0x1, 0xe28 <ltmp0+0xe28>
     e00:      	tbnz	w28, #0x2, 0xe34 <ltmp0+0xe34>
     e04:      	tbnz	w28, #0x3, 0xe40 <ltmp0+0xe40>
     e08:      	tbnz	w28, #0x4, 0xe4c <ltmp0+0xe4c>
     e0c:      	tbnz	w28, #0x5, 0xe58 <ltmp0+0xe58>
     e10:      	tbnz	w28, #0x6, 0xe64 <ltmp0+0xe64>
     e14:      	tbz	w28, #0x7, 0xdc4 <ltmp0+0xdc4>
     e18:      	b	0xe70 <ltmp0+0xe70>
     e1c:      	ldr	s20, [x20]
     e20:      	and	w28, w28, #0xff
     e24:      	tbz	w28, #0x1, 0xe00 <ltmp0+0xe00>
     e28:      	add	x10, x20, #0x4
     e2c:      	ld1.s	{ v20 }[1], [x10]
     e30:      	tbz	w28, #0x2, 0xe04 <ltmp0+0xe04>
     e34:      	add	x10, x20, #0x8
     e38:      	ld1.s	{ v20 }[2], [x10]
     e3c:      	tbz	w28, #0x3, 0xe08 <ltmp0+0xe08>
     e40:      	add	x10, x20, #0xc
     e44:      	ld1.s	{ v20 }[3], [x10]
     e48:      	tbz	w28, #0x4, 0xe0c <ltmp0+0xe0c>
     e4c:      	add	x10, x20, #0x10
     e50:      	ld1.s	{ v21 }[0], [x10]
     e54:      	tbz	w28, #0x5, 0xe10 <ltmp0+0xe10>
     e58:      	add	x10, x20, #0x14
     e5c:      	ld1.s	{ v21 }[1], [x10]
     e60:      	tbz	w28, #0x6, 0xe14 <ltmp0+0xe14>
     e64:      	add	x10, x20, #0x18
     e68:      	ld1.s	{ v21 }[2], [x10]
     e6c:      	tbz	w28, #0x7, 0xdc4 <ltmp0+0xdc4>
     e70:      	add	x10, x20, #0x1c
     e74:      	ld1.s	{ v21 }[3], [x10]
     e78:      	b	0xdc4 <ltmp0+0xdc4>
     e7c:      	adrp	x10, 0x0 <ltmp0>
     e80:      	ldr	q20, [x10]
     e84:      	and.16b	v21, v0, v20
     e88:      	adrp	x10, 0x0 <ltmp0>
     e8c:      	ldr	q20, [x10]
     e90:      	and.16b	v22, v1, v20
     e94:      	adrp	x10, 0x0 <ltmp0>
     e98:      	ldr	q20, [x10]
     e9c:      	and.16b	v20, v1, v20
     ea0:      	fadd.4s	v5, v5, v18
     ea4:      	fadd.4s	v4, v4, v17
     ea8:      	fadd.4s	v17, v4, v19
     eac:      	fadd.4s	v4, v5, v6
     eb0:      	fadd.4s	v4, v4, v16
     eb4:      	fadd.4s	v5, v17, v7
     eb8:      	fmov	w10, s22
     ebc:      	add	x12, sp, #0xf8
     ec0:      	bfxil	x12, x10, #0, #3
     ec4:      	str	d3, [sp, #0xf8]
     ec8:      	ldrb	w12, [x12]
     ecc:      	add	x19, sp, #0x320
     ed0:      	orr	x10, x19, x10, lsl #2
     ed4:      	stp	q5, q4, [x25, #0x1a0]
     ed8:      	ldr	s3, [x10]
     edc:      	tst	w30, w12
     ee0:      	mov.s	w10, v22[1]
     ee4:      	fcsel	s6, s3, s8, ne
     ee8:      	add	x12, sp, #0xf8
     eec:      	bfxil	x12, x10, #0, #3
     ef0:      	ldrb	w10, [x12]
     ef4:      	and	w10, w14, w10
     ef8:      	str	q5, [x25, #0x180]
     efc:      	ldr	s3, [sp, #0x300]
     f00:      	tst	w10, #0x1
     f04:      	fcsel	s3, s3, s8, ne
     f08:      	mov.s	w10, v22[2]
     f0c:      	add	x12, sp, #0xf8
     f10:      	bfxil	x12, x10, #0, #3
     f14:      	add	x19, sp, #0x2e0
     f18:      	orr	x10, x19, x10, lsl #2
     f1c:      	ldrb	w12, [x12]
     f20:      	and	w12, w1, w12
     f24:      	stp	q5, q4, [x25, #0x160]
     f28:      	ldr	s7, [x10]
     f2c:      	tst	w12, #0x1
     f30:      	fcsel	s7, s7, s8, ne
     f34:      	mov.s	w10, v22[3]
     f38:      	add	x12, sp, #0xf8
     f3c:      	bfxil	x12, x10, #0, #3
     f40:      	add	x19, sp, #0x2c0
     f44:      	orr	x10, x19, x10, lsl #2
     f48:      	ldrb	w12, [x12]
     f4c:      	and	w12, w2, w12
     f50:      	stp	q5, q4, [x25, #0x140]
     f54:      	ldr	s16, [x10]
     f58:      	tst	w12, #0x1
     f5c:      	fcsel	s16, s16, s8, ne
     f60:      	fmov	w10, s21
     f64:      	add	x12, sp, #0xf8
     f68:      	bfxil	x12, x10, #0, #3
     f6c:      	ldrb	w12, [x12]
     f70:      	and	w12, w15, w12
     f74:      	stp	q5, q4, [x25, #0x120]
     f78:      	add	x19, sp, #0x2a0
     f7c:      	ldr	s17, [x19, w10, uxtw #2]
     f80:      	tst	w12, #0x1
     f84:      	fcsel	s17, s17, s8, ne
     f88:      	mov.s	w10, v21[1]
     f8c:      	add	x12, sp, #0xf8
     f90:      	bfxil	x12, x10, #0, #3
     f94:      	ldrb	w12, [x12]
     f98:      	and	w12, w16, w12
     f9c:      	stp	q5, q4, [x25, #0x100]
     fa0:      	add	x19, sp, #0x280
     fa4:      	ldr	s18, [x19, w10, uxtw #2]
     fa8:      	tst	w12, #0x1
     fac:      	fcsel	s18, s18, s8, ne
     fb0:      	mov.s	w10, v21[2]
     fb4:      	add	x12, sp, #0xf8
     fb8:      	bfxil	x12, x10, #0, #3
     fbc:      	ldrb	w12, [x12]
     fc0:      	and	w12, w17, w12
     fc4:      	stp	q5, q4, [x25, #0xe0]
     fc8:      	add	x19, sp, #0x260
     fcc:      	ldr	s19, [x19, w10, uxtw #2]
     fd0:      	tst	w12, #0x1
     fd4:      	fcsel	s19, s19, s8, ne
     fd8:      	mov.s	w10, v21[3]
     fdc:      	add	x12, sp, #0xf8
     fe0:      	bfxil	x12, x10, #0, #3
     fe4:      	ldrb	w12, [x12]
     fe8:      	and	w12, w0, w12
     fec:      	stp	q5, q4, [x25, #0xc0]
     ff0:      	add	x19, sp, #0x240
     ff4:      	ldr	s21, [x19, w10, uxtw #2]
     ff8:      	tst	w12, #0x1
     ffc:      	fcsel	s21, s21, s8, ne
    1000:      	mov.s	v6[1], v3[0]
    1004:      	mov.s	v6[2], v7[0]
    1008:      	mov.s	v6[3], v16[0]
    100c:      	mov.s	v17[1], v18[0]
    1010:      	mov.s	v17[2], v19[0]
    1014:      	mov.s	v17[3], v21[0]
    1018:      	fadd.4s	v3, v4, v17
    101c:      	fadd.4s	v4, v5, v6
    1020:      	fmov	w10, s20
    1024:      	add	x12, sp, #0xf8
    1028:      	bfxil	x12, x10, #0, #3
    102c:      	ldrb	w12, [x12]
    1030:      	add	x19, sp, #0x220
    1034:      	orr	x10, x19, x10, lsl #2
    1038:      	stp	q4, q3, [x25, #0xa0]
    103c:      	ldr	s5, [x10]
    1040:      	tst	w30, w12
    1044:      	mov.s	w10, v20[1]
    1048:      	add	x12, sp, #0xf8
    104c:      	bfxil	x12, x10, #0, #3
    1050:      	ldrb	w12, [x12]
    1054:      	and	w12, w14, w12
    1058:      	fcsel	s5, s5, s8, ne
    105c:      	add	x14, sp, #0x200
    1060:      	orr	x10, x14, x10, lsl #2
    1064:      	stp	q4, q3, [x25, #0x80]
    1068:      	ldr	s6, [x10]
    106c:      	tst	w12, #0x1
    1070:      	mov.s	w10, v20[2]
    1074:      	add	x12, sp, #0xf8
    1078:      	bfxil	x12, x10, #0, #3
    107c:      	fcsel	s6, s6, s8, ne
    1080:      	ldrb	w10, [x12]
    1084:      	and	w10, w1, w10
    1088:      	str	q4, [x25, #0x60]
    108c:      	tst	w10, #0x1
    1090:      	mov.s	w10, v20[3]
    1094:      	add	x12, sp, #0xf8
    1098:      	bfxil	x12, x10, #0, #3
    109c:      	ldrb	w12, [x12]
    10a0:      	and	w12, w2, w12
    10a4:      	adrp	x14, 0x1000 <ltmp0+0x1000>
    10a8:      	ldr	q7, [x14]
    10ac:      	and.16b	v18, v0, v7
    10b0:      	ldr	s7, [sp, #0x1e0]
    10b4:      	fcsel	s7, s7, s8, ne
    10b8:      	add	x14, sp, #0x1c0
    10bc:      	orr	x10, x14, x10, lsl #2
    10c0:      	stp	q4, q3, [x25, #0x40]
    10c4:      	ldr	s16, [x10]
    10c8:      	tst	w12, #0x1
    10cc:      	fmov	w10, s18
    10d0:      	add	x12, sp, #0xf8
    10d4:      	bfxil	x12, x10, #0, #3
    10d8:      	ldrb	w12, [x12]
    10dc:      	and	w12, w15, w12
    10e0:      	fcsel	s16, s16, s8, ne
    10e4:      	stp	q4, q3, [x25, #0x20]
    10e8:      	add	x14, sp, #0x1a0
    10ec:      	ldr	s17, [x14, w10, uxtw #2]
    10f0:      	tst	w12, #0x1
    10f4:      	mov.s	w10, v18[1]
    10f8:      	add	x12, sp, #0xf8
    10fc:      	bfxil	x12, x10, #0, #3
    1100:      	ldrb	w12, [x12]
    1104:      	and	w12, w16, w12
    1108:      	fcsel	s17, s17, s8, ne
    110c:      	stp	q4, q3, [x25]
    1110:      	ldr	s19, [x25, w10, uxtw #2]
    1114:      	tst	w12, #0x1
    1118:      	mov.s	w10, v18[2]
    111c:      	add	x12, sp, #0xf8
    1120:      	bfxil	x12, x10, #0, #3
    1124:      	ldrb	w12, [x12]
    1128:      	and	w12, w17, w12
    112c:      	fcsel	s19, s19, s8, ne
    1130:      	stp	q4, q3, [sp, #0x160]
    1134:      	add	x14, sp, #0x160
    1138:      	ldr	s20, [x14, w10, uxtw #2]
    113c:      	tst	w12, #0x1
    1140:      	mov.s	w10, v18[3]
    1144:      	add	x12, sp, #0xf8
    1148:      	bfxil	x12, x10, #0, #3
    114c:      	ldrb	w12, [x12]
    1150:      	and	w12, w0, w12
    1154:      	movi.4s	v18, #0x4
    1158:      	and.16b	v18, v1, v18
    115c:      	fcsel	s20, s20, s8, ne
    1160:      	stp	q4, q3, [sp, #0x140]
    1164:      	add	x14, sp, #0x140
    1168:      	ldr	s21, [x14, w10, uxtw #2]
    116c:      	tst	w12, #0x1
    1170:      	fcsel	s21, s21, s8, ne
    1174:      	fmov	w10, s18
    1178:      	add	x12, sp, #0xf8
    117c:      	orr	x12, x12, x10
    1180:      	ldrb	w12, [x12]
    1184:      	tst	w30, w12
    1188:      	mov.s	v17[1], v19[0]
    118c:      	mov.s	v17[2], v20[0]
    1190:      	mov.s	v17[3], v21[0]
    1194:      	mov.s	v5[1], v6[0]
    1198:      	mov.s	v5[2], v7[0]
    119c:      	mov.s	v5[3], v16[0]
    11a0:      	fadd.4s	v4, v4, v5
    11a4:      	fadd.4s	v3, v3, v17
    11a8:      	stp	q4, q3, [sp, #0x120]
    11ac:      	add	x12, sp, #0x120
    11b0:      	ldr	s3, [x12, w10, uxtw #2]
    11b4:      	fcsel	s3, s3, s8, ne
    11b8:      	tst	w11, #0x1
    11bc:      	fadd	s3, s4, s3
    11c0:      	fcsel	s4, s3, s8, ne
    11c4:      	tst	w3, #0x1
    11c8:      	fcsel	s5, s3, s8, ne
    11cc:      	tst	w4, #0x1
    11d0:      	fcsel	s6, s3, s8, ne
    11d4:      	tst	w5, #0x1
    11d8:      	fcsel	s7, s3, s8, ne
    11dc:      	tst	w13, #0x1
    11e0:      	fcsel	s16, s3, s8, ne
    11e4:      	tst	w6, #0x1
    11e8:      	fcsel	s17, s3, s8, ne
    11ec:      	tst	w7, #0x1
    11f0:      	fcsel	s18, s3, s8, ne
    11f4:      	tst	w22, #0x1
    11f8:      	fcsel	s3, s3, s8, ne
    11fc:      	mov.s	v4[1], v5[0]
    1200:      	mov.s	v4[2], v6[0]
    1204:      	mov.s	v4[3], v7[0]
    1208:      	mov.s	v16[1], v17[0]
    120c:      	mov.s	v16[2], v18[0]
    1210:      	mov.s	v16[3], v3[0]
    1214:      	stp	q4, q16, [sp, #0x100]
    1218:      	and	x10, x23, #0x7
    121c:      	add	x11, sp, #0x100
    1220:      	ldr	s3, [x11, x10, lsl #2]
    1224:      	subs	x10, x9, x8
    1228:      	mov	w11, #0xbff             ; =3071
    122c:      	ccmp	x10, x11, #0x0, hs
    1230:      	cset	w11, hi
    1234:      	sub	x10, x8, x9
    1238:      	mov	w12, #0xbff             ; =3071
    123c:      	movk	w12, #0x6, lsl #16
    1240:      	cmp	x10, x12
    1244:      	fadd	s3, s3, s8
    1248:      	mov	w10, #0x44400000        ; =1145044992
    124c:      	fmov	s4, w10
    1250:      	fdiv	s3, s3, s4
    1254:      	mov	w10, #0xc5ac            ; =50604
    1258:      	movk	w10, #0x3727, lsl #16
    125c:      	fmov	s4, w10
    1260:      	fadd	s3, s3, s4
    1264:      	fsqrt	s3, s3
    1268:      	ccmp	x8, x9, #0x0, hi
    126c:      	b.hs	0x1334 <ltmp0+0x1334>
    1270:      	tbnz	w11, #0x0, 0x1334 <ltmp0+0x1334>
    1274:      	mov	x11, #0x0               ; =0
    1278:      	b	0x129c <ltmp0+0x129c>
    127c:      	add	x10, x24, x11
    1280:      	ldp	q6, q7, [x10]
    1284:      	bif.16b	v5, v7, v0
    1288:      	bif.16b	v4, v6, v1
    128c:      	stp	q4, q5, [x10]
    1290:      	add	x11, x11, #0x20
    1294:      	cmp	x11, #0xc00
    1298:      	b.eq	0x14d0 <ltmp0+0x14d0>
    129c:      	fmov	w13, s2
    12a0:      	add	x12, x8, x11
    12a4:      	movi.2d	v4, #0000000000000000
    12a8:      	movi.2d	v5, #0000000000000000
    12ac:      	tbnz	w13, #0x0, 0x12d4 <ltmp0+0x12d4>
    12b0:      	and	w13, w13, #0xff
    12b4:      	tbnz	w13, #0x1, 0x12e0 <ltmp0+0x12e0>
    12b8:      	tbnz	w13, #0x2, 0x12ec <ltmp0+0x12ec>
    12bc:      	tbnz	w13, #0x3, 0x12f8 <ltmp0+0x12f8>
    12c0:      	tbnz	w13, #0x4, 0x1304 <ltmp0+0x1304>
    12c4:      	tbnz	w13, #0x5, 0x1310 <ltmp0+0x1310>
    12c8:      	tbnz	w13, #0x6, 0x131c <ltmp0+0x131c>
    12cc:      	tbz	w13, #0x7, 0x127c <ltmp0+0x127c>
    12d0:      	b	0x1328 <ltmp0+0x1328>
    12d4:      	ldr	s4, [x12]
    12d8:      	and	w13, w13, #0xff
    12dc:      	tbz	w13, #0x1, 0x12b8 <ltmp0+0x12b8>
    12e0:      	add	x10, x12, #0x4
    12e4:      	ld1.s	{ v4 }[1], [x10]
    12e8:      	tbz	w13, #0x2, 0x12bc <ltmp0+0x12bc>
    12ec:      	add	x10, x12, #0x8
    12f0:      	ld1.s	{ v4 }[2], [x10]
    12f4:      	tbz	w13, #0x3, 0x12c0 <ltmp0+0x12c0>
    12f8:      	add	x10, x12, #0xc
    12fc:      	ld1.s	{ v4 }[3], [x10]
    1300:      	tbz	w13, #0x4, 0x12c4 <ltmp0+0x12c4>
    1304:      	add	x10, x12, #0x10
    1308:      	ld1.s	{ v5 }[0], [x10]
    130c:      	tbz	w13, #0x5, 0x12c8 <ltmp0+0x12c8>
    1310:      	add	x10, x12, #0x14
    1314:      	ld1.s	{ v5 }[1], [x10]
    1318:      	tbz	w13, #0x6, 0x12cc <ltmp0+0x12cc>
    131c:      	add	x10, x12, #0x18
    1320:      	ld1.s	{ v5 }[2], [x10]
    1324:      	tbz	w13, #0x7, 0x127c <ltmp0+0x127c>
    1328:      	add	x10, x12, #0x1c
    132c:      	ld1.s	{ v5 }[3], [x10]
    1330:      	b	0x127c <ltmp0+0x127c>
    1334:      	mov	x11, #0x0               ; =0
    1338:      	dup.4s	v3, v3[0]
    133c:      	ldr	x10, [sp, #0xe0]
    1340:      	add	x9, x9, x10
    1344:      	b	0x1354 <ltmp0+0x1354>
    1348:      	add	x11, x11, #0x20
    134c:      	cmp	x11, #0xc00
    1350:      	b.eq	0x80 <ltmp0+0x80>
    1354:      	fmov	w12, s2
    1358:      	add	x10, x8, x11
    135c:      	movi.2d	v5, #0000000000000000
    1360:      	movi.2d	v4, #0000000000000000
    1364:      	tbnz	w12, #0x0, 0x1400 <ltmp0+0x1400>
    1368:      	and	w12, w12, #0xff
    136c:      	tbnz	w12, #0x1, 0x140c <ltmp0+0x140c>
    1370:      	tbnz	w12, #0x2, 0x1418 <ltmp0+0x1418>
    1374:      	tbnz	w12, #0x3, 0x1424 <ltmp0+0x1424>
    1378:      	tbnz	w12, #0x4, 0x1430 <ltmp0+0x1430>
    137c:      	tbnz	w12, #0x5, 0x143c <ltmp0+0x143c>
    1380:      	tbnz	w12, #0x6, 0x1448 <ltmp0+0x1448>
    1384:      	tbz	w12, #0x7, 0x1390 <ltmp0+0x1390>
    1388:      	add	x10, x10, #0x1c
    138c:      	ld1.s	{ v4 }[3], [x10]
    1390:      	add	x13, x26, x11
    1394:      	ldr	q6, [x13]
    1398:      	and.16b	v6, v1, v6
    139c:      	fdiv.4s	v6, v6, v3
    13a0:      	add	x14, x21, x11
    13a4:      	ldr	q7, [x14]
    13a8:      	and.16b	v7, v1, v7
    13ac:      	fmul.4s	v6, v6, v7
    13b0:      	fmov	w12, s2
    13b4:      	fadd.4s	v5, v5, v6
    13b8:      	add	x10, x9, x11
    13bc:      	tbnz	w12, #0x0, 0x1458 <ltmp0+0x1458>
    13c0:      	and	w12, w12, #0xff
    13c4:      	tbnz	w12, #0x1, 0x1464 <ltmp0+0x1464>
    13c8:      	ldr	q7, [x13, #0x10]
    13cc:      	ldr	q6, [x14, #0x10]
    13d0:      	tbnz	w12, #0x2, 0x1478 <ltmp0+0x1478>
    13d4:      	tbnz	w12, #0x3, 0x1484 <ltmp0+0x1484>
    13d8:      	and.16b	v5, v0, v7
    13dc:      	fdiv.4s	v5, v5, v3
    13e0:      	and.16b	v6, v0, v6
    13e4:      	fmul.4s	v5, v5, v6
    13e8:      	fadd.4s	v4, v4, v5
    13ec:      	tbnz	w12, #0x4, 0x14a4 <ltmp0+0x14a4>
    13f0:      	tbnz	w12, #0x5, 0x14ac <ltmp0+0x14ac>
    13f4:      	tbnz	w12, #0x6, 0x14b8 <ltmp0+0x14b8>
    13f8:      	tbz	w12, #0x7, 0x1348 <ltmp0+0x1348>
    13fc:      	b	0x14c4 <ltmp0+0x14c4>
    1400:      	ldr	s5, [x10]
    1404:      	and	w12, w12, #0xff
    1408:      	tbz	w12, #0x1, 0x1370 <ltmp0+0x1370>
    140c:      	add	x13, x10, #0x4
    1410:      	ld1.s	{ v5 }[1], [x13]
    1414:      	tbz	w12, #0x2, 0x1374 <ltmp0+0x1374>
    1418:      	add	x13, x10, #0x8
    141c:      	ld1.s	{ v5 }[2], [x13]
    1420:      	tbz	w12, #0x3, 0x1378 <ltmp0+0x1378>
    1424:      	add	x13, x10, #0xc
    1428:      	ld1.s	{ v5 }[3], [x13]
    142c:      	tbz	w12, #0x4, 0x137c <ltmp0+0x137c>
    1430:      	add	x13, x10, #0x10
    1434:      	ld1.s	{ v4 }[0], [x13]
    1438:      	tbz	w12, #0x5, 0x1380 <ltmp0+0x1380>
    143c:      	add	x13, x10, #0x14
    1440:      	ld1.s	{ v4 }[1], [x13]
    1444:      	tbz	w12, #0x6, 0x1384 <ltmp0+0x1384>
    1448:      	add	x13, x10, #0x18
    144c:      	ld1.s	{ v4 }[2], [x13]
    1450:      	tbnz	w12, #0x7, 0x1388 <ltmp0+0x1388>
    1454:      	b	0x1390 <ltmp0+0x1390>
    1458:      	str	s5, [x10]
    145c:      	and	w12, w12, #0xff
    1460:      	tbz	w12, #0x1, 0x13c8 <ltmp0+0x13c8>
    1464:      	add	x15, x10, #0x4
    1468:      	st1.s	{ v5 }[1], [x15]
    146c:      	ldr	q7, [x13, #0x10]
    1470:      	ldr	q6, [x14, #0x10]
    1474:      	tbz	w12, #0x2, 0x13d4 <ltmp0+0x13d4>
    1478:      	add	x13, x10, #0x8
    147c:      	st1.s	{ v5 }[2], [x13]
    1480:      	tbz	w12, #0x3, 0x13d8 <ltmp0+0x13d8>
    1484:      	add	x13, x10, #0xc
    1488:      	st1.s	{ v5 }[3], [x13]
    148c:      	and.16b	v5, v0, v7
    1490:      	fdiv.4s	v5, v5, v3
    1494:      	and.16b	v6, v0, v6
    1498:      	fmul.4s	v5, v5, v6
    149c:      	fadd.4s	v4, v4, v5
    14a0:      	tbz	w12, #0x4, 0x13f0 <ltmp0+0x13f0>
    14a4:      	str	s4, [x10, #0x10]
    14a8:      	tbz	w12, #0x5, 0x13f4 <ltmp0+0x13f4>
    14ac:      	add	x13, x10, #0x14
    14b0:      	st1.s	{ v4 }[1], [x13]
    14b4:      	tbz	w12, #0x6, 0x13f8 <ltmp0+0x13f8>
    14b8:      	add	x13, x10, #0x18
    14bc:      	st1.s	{ v4 }[2], [x13]
    14c0:      	tbz	w12, #0x7, 0x1348 <ltmp0+0x1348>
    14c4:      	add	x10, x10, #0x1c
    14c8:      	st1.s	{ v4 }[3], [x10]
    14cc:      	b	0x1348 <ltmp0+0x1348>
    14d0:      	mov	x8, #0x0                ; =0
    14d4:      	dup.4s	v3, v3[0]
    14d8:      	ldr	x10, [sp, #0xe0]
    14dc:      	add	x9, x9, x10
    14e0:      	b	0x14f0 <ltmp0+0x14f0>
    14e4:      	add	x8, x8, #0x20
    14e8:      	cmp	x8, #0xc00
    14ec:      	b.eq	0x80 <ltmp0+0x80>
    14f0:      	fmov	w11, s2
    14f4:      	add	x12, x26, x8
    14f8:      	ldr	q4, [x12]
    14fc:      	and.16b	v4, v1, v4
    1500:      	fdiv.4s	v4, v4, v3
    1504:      	add	x13, x21, x8
    1508:      	ldr	q5, [x13]
    150c:      	and.16b	v5, v1, v5
    1510:      	fmul.4s	v5, v4, v5
    1514:      	add	x10, x24, x8
    1518:      	ldp	q6, q4, [x10]
    151c:      	and.16b	v6, v1, v6
    1520:      	fadd.4s	v5, v5, v6
    1524:      	add	x10, x9, x8
    1528:      	tbnz	w11, #0x0, 0x1578 <ltmp0+0x1578>
    152c:      	and	w11, w11, #0xff
    1530:      	ldr	q7, [x12, #0x10]
    1534:      	ldr	q6, [x13, #0x10]
    1538:      	tbnz	w11, #0x1, 0x158c <ltmp0+0x158c>
    153c:      	tbnz	w11, #0x2, 0x1598 <ltmp0+0x1598>
    1540:      	tbz	w11, #0x3, 0x154c <ltmp0+0x154c>
    1544:      	add	x12, x10, #0xc
    1548:      	st1.s	{ v5 }[3], [x12]
    154c:      	and.16b	v5, v0, v7
    1550:      	fdiv.4s	v5, v5, v3
    1554:      	and.16b	v6, v0, v6
    1558:      	fmul.4s	v5, v5, v6
    155c:      	and.16b	v4, v0, v4
    1560:      	fadd.4s	v4, v5, v4
    1564:      	tbnz	w11, #0x4, 0x15a8 <ltmp0+0x15a8>
    1568:      	tbnz	w11, #0x5, 0x15b0 <ltmp0+0x15b0>
    156c:      	tbnz	w11, #0x6, 0x15bc <ltmp0+0x15bc>
    1570:      	tbz	w11, #0x7, 0x14e4 <ltmp0+0x14e4>
    1574:      	b	0x15c8 <ltmp0+0x15c8>
    1578:      	str	s5, [x10]
    157c:      	and	w11, w11, #0xff
    1580:      	ldr	q7, [x12, #0x10]
    1584:      	ldr	q6, [x13, #0x10]
    1588:      	tbz	w11, #0x1, 0x153c <ltmp0+0x153c>
    158c:      	add	x12, x10, #0x4
    1590:      	st1.s	{ v5 }[1], [x12]
    1594:      	tbz	w11, #0x2, 0x1540 <ltmp0+0x1540>
    1598:      	add	x12, x10, #0x8
    159c:      	st1.s	{ v5 }[2], [x12]
    15a0:      	tbnz	w11, #0x3, 0x1544 <ltmp0+0x1544>
    15a4:      	b	0x154c <ltmp0+0x154c>
    15a8:      	str	s4, [x10, #0x10]
    15ac:      	tbz	w11, #0x5, 0x156c <ltmp0+0x156c>
    15b0:      	add	x12, x10, #0x14
    15b4:      	st1.s	{ v4 }[1], [x12]
    15b8:      	tbz	w11, #0x6, 0x1570 <ltmp0+0x1570>
    15bc:      	add	x12, x10, #0x18
    15c0:      	st1.s	{ v4 }[2], [x12]
    15c4:      	tbz	w11, #0x7, 0x14e4 <ltmp0+0x14e4>
    15c8:      	add	x10, x10, #0x1c
    15cc:      	st1.s	{ v4 }[3], [x10]
    15d0:      	b	0x14e4 <ltmp0+0x14e4>
    15d4:      	ldr	x9, [sp, #0x8]
    15d8:      	stp	w15, w14, [x9]
    15dc:      	str	w13, [x9, #0x8]
    15e0:      	mov	w8, #0x18               ; =24
    15e4:      	str	w8, [x9, #0x24]
    15e8:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    15ec:      	add	sp, sp, #0x4c0
    15f0:      	ldp	x29, x30, [sp, #0x60]
    15f4:      	ldp	x20, x19, [sp, #0x50]
    15f8:      	ldp	x22, x21, [sp, #0x40]
    15fc:      	ldp	x24, x23, [sp, #0x30]
    1600:      	ldp	x26, x25, [sp, #0x20]
    1604:      	ldp	x28, x27, [sp, #0x10]
    1608:      	ldp	d9, d8, [sp], #0x70
    160c:      	ret

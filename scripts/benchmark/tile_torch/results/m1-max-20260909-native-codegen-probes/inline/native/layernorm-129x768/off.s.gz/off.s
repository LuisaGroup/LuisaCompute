
/private/tmp/luisa-packet-inline.UY1lIE/capture/layernorm-129x768/off/object/tile_xir_w8_36317_1788935094321288_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x24, x23, [sp, #-0x40]!
       4:      	stp	x22, x21, [sp, #0x10]
       8:      	stp	x20, x19, [sp, #0x20]
       c:      	stp	x29, x30, [sp, #0x30]
      10:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      14:      	sub	sp, sp, #0x80
      18:      	ldr	x8, [x0]
      1c:      	ldr	x20, [x0, #0x10]
      20:      	ldr	x19, [x0, #0x20]
      24:      	ldr	x21, [x0, #0x30]
      28:      	ldr	w9, [x1]
      2c:      	ldr	w10, [x1, #0x24]
      30:      	add	w9, w10, w9, lsl #5
      34:      	lsr	w9, w9, #3
      38:      	mov	w10, #0xc00             ; =3072
      3c:      	umull	x22, w9, w10
      40:      	umaddl	x1, w9, w10, x8
      44:      	add	x23, sp, #0x2, lsl #12  ; =0x2000
      48:      	add	x23, x23, #0x480
      4c:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
      50:      	add	x0, x0, #0x480
      54:      	mov	w2, #0xc00              ; =3072
      58:      	bl	0x58 <ltmp0+0x58>
      5c:      	ldr	q0, [sp, #0x2490]
      60:      	ldr	q2, [sp, #0x2480]
      64:      	ldr	q1, [sp, #0x24b0]
      68:      	ldr	q5, [sp, #0x24a0]
      6c:      	ldr	q4, [sp, #0x24d0]
      70:      	ldr	q3, [sp, #0x24c0]
      74:      	add	x8, x23, #0xe0
      78:      	mov	w9, #0x4                ; =4
      7c:      	ldr	q6, [sp, #0x24f0]
      80:      	ldr	q7, [sp, #0x24e0]
      84:      	ldp	q16, q17, [x8, #-0x60]
      88:      	fadd.4s	v0, v0, v17
      8c:      	fadd.4s	v2, v2, v16
      90:      	ldp	q16, q17, [x8, #-0x40]
      94:      	fadd.4s	v1, v1, v17
      98:      	fadd.4s	v5, v5, v16
      9c:      	ldp	q16, q17, [x8, #-0x20]
      a0:      	fadd.4s	v4, v4, v17
      a4:      	fadd.4s	v3, v3, v16
      a8:      	ldp	q16, q17, [x8], #0x80
      ac:      	fadd.4s	v6, v6, v17
      b0:      	fadd.4s	v7, v7, v16
      b4:      	cmp	x9, #0x5c
      b8:      	add	x9, x9, #0x4
      bc:      	b.lo	0x84 <ltmp0+0x84>
      c0:      	mov	x8, #0x0                ; =0
      c4:      	fadd.4s	v2, v2, v5
      c8:      	fadd.4s	v0, v0, v1
      cc:      	fadd.4s	v0, v0, v4
      d0:      	fadd.4s	v1, v2, v3
      d4:      	fadd.4s	v1, v1, v7
      d8:      	fadd.4s	v0, v0, v6
      dc:      	rev64.4s	v2, v0
      e0:      	rev64.4s	v3, v1
      e4:      	fadd.4s	v1, v1, v3
      e8:      	fadd.4s	v0, v0, v2
      ec:      	dup.4s	v2, v0[2]
      f0:      	dup.4s	v3, v1[2]
      f4:      	fadd.4s	v1, v1, v3
      f8:      	fadd.4s	v0, v0, v2
      fc:      	fadd.4s	v0, v1, v0
     100:      	movi	d1, #0000000000000000
     104:      	fadd	s0, s0, s1
     108:      	mov	w9, #0x44400000         ; =1145044992
     10c:      	fmov	s1, w9
     110:      	fdiv	s0, s0, s1
     114:      	dup.4s	v0, v0[0]
     118:      	add	x9, sp, #0x2, lsl #12   ; =0x2000
     11c:      	add	x9, x9, #0x480
     120:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     124:      	add	x10, x10, #0x880
     128:      	add	x11, x9, x8
     12c:      	ldp	q2, q1, [x11]
     130:      	fsub.4s	v2, v2, v0
     134:      	fsub.4s	v1, v1, v0
     138:      	add	x11, x10, x8
     13c:      	stp	q2, q1, [x11]
     140:      	add	x8, x8, #0x20
     144:      	cmp	x8, #0xc00
     148:      	b.ne	0x128 <ltmp0+0x128>
     14c:      	ldr	q0, [sp, #0x1880]
     150:      	ldr	q1, [sp, #0x1890]
     154:      	fmul.4s	v2, v1, v1
     158:      	fmul.4s	v3, v0, v0
     15c:      	ldr	q0, [sp, #0x18a0]
     160:      	ldr	q1, [sp, #0x18b0]
     164:      	fmul.4s	v4, v1, v1
     168:      	fmul.4s	v5, v0, v0
     16c:      	ldr	q0, [sp, #0x18c0]
     170:      	ldr	q1, [sp, #0x18d0]
     174:      	fmul.4s	v7, v1, v1
     178:      	fmul.4s	v6, v0, v0
     17c:      	ldr	q0, [sp, #0x18e0]
     180:      	ldr	q1, [sp, #0x18f0]
     184:      	fmul.4s	v16, v1, v1
     188:      	fmul.4s	v17, v0, v0
     18c:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
     190:      	add	x8, x8, #0x880
     194:      	add	x8, x8, #0xe0
     198:      	mov	w9, #0x4                ; =4
     19c:      	ldp	q1, q0, [x8, #-0x60]
     1a0:      	fmul.4s	v1, v1, v1
     1a4:      	fmul.4s	v0, v0, v0
     1a8:      	fadd.4s	v2, v2, v0
     1ac:      	fadd.4s	v3, v3, v1
     1b0:      	ldp	q1, q0, [x8, #-0x40]
     1b4:      	fmul.4s	v1, v1, v1
     1b8:      	fmul.4s	v0, v0, v0
     1bc:      	fadd.4s	v4, v4, v0
     1c0:      	fadd.4s	v5, v5, v1
     1c4:      	ldp	q1, q0, [x8, #-0x20]
     1c8:      	fmul.4s	v1, v1, v1
     1cc:      	fmul.4s	v0, v0, v0
     1d0:      	fadd.4s	v7, v7, v0
     1d4:      	fadd.4s	v6, v6, v1
     1d8:      	ldp	q1, q0, [x8], #0x80
     1dc:      	fmul.4s	v1, v1, v1
     1e0:      	fmul.4s	v0, v0, v0
     1e4:      	fadd.4s	v16, v16, v0
     1e8:      	fadd.4s	v17, v17, v1
     1ec:      	cmp	x9, #0x5c
     1f0:      	add	x9, x9, #0x4
     1f4:      	b.lo	0x19c <ltmp0+0x19c>
     1f8:      	add	x23, sp, #0xc80
     1fc:      	add	x0, sp, #0xc80
     200:      	mov	x1, x20
     204:      	mov	w2, #0xc00              ; =3072
     208:      	stp	q4, q2, [sp, #0x30]
     20c:      	stp	q5, q3, [sp]
     210:      	stp	q6, q16, [sp, #0x60]
     214:      	str	q7, [sp, #0x20]
     218:      	str	q17, [sp, #0x50]
     21c:      	bl	0x21c <ltmp0+0x21c>
     220:      	ldp	q1, q0, [sp]
     224:      	fadd.4s	v0, v0, v1
     228:      	ldp	q2, q1, [sp, #0x30]
     22c:      	fadd.4s	v1, v1, v2
     230:      	ldr	q2, [sp, #0x20]
     234:      	fadd.4s	v1, v1, v2
     238:      	ldp	q2, q3, [sp, #0x50]
     23c:      	fadd.4s	v0, v0, v3
     240:      	fadd.4s	v0, v0, v2
     244:      	ldr	q2, [sp, #0x70]
     248:      	fadd.4s	v1, v1, v2
     24c:      	rev64.4s	v2, v1
     250:      	rev64.4s	v3, v0
     254:      	fadd.4s	v0, v0, v3
     258:      	fadd.4s	v1, v1, v2
     25c:      	dup.4s	v2, v1[2]
     260:      	dup.4s	v3, v0[2]
     264:      	fadd.4s	v0, v0, v3
     268:      	fadd.4s	v1, v1, v2
     26c:      	fadd.4s	v0, v0, v1
     270:      	movi	d1, #0000000000000000
     274:      	fadd	s0, s0, s1
     278:      	mov	w8, #0x44400000         ; =1145044992
     27c:      	fmov	s1, w8
     280:      	fdiv	s0, s0, s1
     284:      	mov	w8, #0xc5ac             ; =50604
     288:      	movk	w8, #0x3727, lsl #16
     28c:      	fmov	s1, w8
     290:      	fadd	s0, s0, s1
     294:      	fsqrt	s0, s0
     298:      	sub	x8, x19, x21
     29c:      	lsr	x9, x8, #10
     2a0:      	subs	x8, x21, x19
     2a4:      	mov	w10, #0xbff             ; =3071
     2a8:      	ccmp	x8, x10, #0x0, hs
     2ac:      	cset	w8, hi
     2b0:      	cmp	x9, #0x182
     2b4:      	ccmp	x19, x21, #0x0, hi
     2b8:      	b.hs	0x33c <ltmp0+0x33c>
     2bc:      	tbnz	w8, #0x0, 0x33c <ltmp0+0x33c>
     2c0:      	add	x20, sp, #0x80
     2c4:      	add	x0, sp, #0x80
     2c8:      	mov	x1, x19
     2cc:      	mov	w2, #0xc00              ; =3072
     2d0:      	str	q0, [sp, #0x70]
     2d4:      	bl	0x2d4 <ltmp0+0x2d4>
     2d8:      	mov	x8, #0x0                ; =0
     2dc:      	ldr	q0, [sp, #0x70]
     2e0:      	dup.4s	v0, v0[0]
     2e4:      	add	x9, x21, x22
     2e8:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     2ec:      	add	x10, x10, #0x880
     2f0:      	add	x11, sp, #0xc80
     2f4:      	add	x12, x10, x8
     2f8:      	ldp	q2, q1, [x12]
     2fc:      	fdiv.4s	v2, v2, v0
     300:      	fdiv.4s	v1, v1, v0
     304:      	add	x12, x11, x8
     308:      	ldp	q3, q4, [x12]
     30c:      	fmul.4s	v1, v1, v4
     310:      	fmul.4s	v2, v2, v3
     314:      	add	x12, x20, x8
     318:      	ldp	q4, q3, [x12]
     31c:      	fadd.4s	v2, v2, v4
     320:      	fadd.4s	v1, v1, v3
     324:      	add	x12, x9, x8
     328:      	stp	q2, q1, [x12]
     32c:      	add	x8, x8, #0x20
     330:      	cmp	x8, #0xc00
     334:      	b.ne	0x2f4 <ltmp0+0x2f4>
     338:      	b	0x394 <ltmp0+0x394>
     33c:      	mov	x8, #0x0                ; =0
     340:      	dup.4s	v0, v0[0]
     344:      	add	x9, x21, x22
     348:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     34c:      	add	x10, x10, #0x880
     350:      	add	x11, x10, x8
     354:      	ldp	q2, q1, [x11]
     358:      	fdiv.4s	v2, v2, v0
     35c:      	fdiv.4s	v1, v1, v0
     360:      	add	x11, x23, x8
     364:      	ldp	q3, q4, [x11]
     368:      	fmul.4s	v1, v1, v4
     36c:      	fmul.4s	v2, v2, v3
     370:      	add	x11, x19, x8
     374:      	ldp	q4, q3, [x11]
     378:      	fadd.4s	v2, v2, v4
     37c:      	fadd.4s	v1, v1, v3
     380:      	add	x11, x9, x8
     384:      	stp	q2, q1, [x11]
     388:      	add	x8, x8, #0x20
     38c:      	cmp	x8, #0xc00
     390:      	b.ne	0x350 <ltmp0+0x350>
     394:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
     398:      	add	sp, sp, #0x80
     39c:      	ldp	x29, x30, [sp, #0x30]
     3a0:      	ldp	x20, x19, [sp, #0x20]
     3a4:      	ldp	x22, x21, [sp, #0x10]
     3a8:      	ldp	x24, x23, [sp], #0x40
     3ac:      	ret

00000000000003b0 <_llm_rows.packet_batch.blocks>:
     3b0:      	stp	d9, d8, [sp, #-0x70]!
     3b4:      	stp	x28, x27, [sp, #0x10]
     3b8:      	stp	x26, x25, [sp, #0x20]
     3bc:      	stp	x24, x23, [sp, #0x30]
     3c0:      	stp	x22, x21, [sp, #0x40]
     3c4:      	stp	x20, x19, [sp, #0x50]
     3c8:      	stp	x29, x30, [sp, #0x60]
     3cc:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
     3d0:      	sub	sp, sp, #0x470
     3d4:      	str	x0, [sp, #0x98]
     3d8:      	cbz	w3, 0x1380 <_llm_rows.packet_batch.blocks+0xfd0>
     3dc:      	mov	x19, x3
     3e0:      	mov	x20, x2
     3e4:      	mov	w22, #0x0               ; =0
     3e8:      	add	x24, sp, #0x2, lsl #12  ; =0x2000
     3ec:      	add	x24, x24, #0x870
     3f0:      	add	x9, x24, #0xe0
     3f4:      	ldp	w10, w8, [x2, #0x2c]
     3f8:      	stp	w8, w10, [sp, #0x90]
     3fc:      	add	x28, sp, #0x1, lsl #12  ; =0x1000
     400:      	add	x28, x28, #0xc70
     404:      	add	x8, x28, #0xe0
     408:      	stp	x8, x9, [sp, #0x28]
     40c:      	ldp	w25, w12, [x2]
     410:      	ldp	w27, w8, [x2, #0x8]
     414:      	str	x8, [sp, #0x88]
     418:      	adrp	x8, 0x0 <ltmp0>
     41c:      	ldr	q0, [x8]
     420:      	str	q0, [sp, #0x10]
     424:      	adrp	x8, 0x0 <ltmp0>
     428:      	ldr	q0, [x8]
     42c:      	str	q0, [sp, #0x70]
     430:      	adrp	x8, 0x0 <ltmp0>
     434:      	ldr	q0, [x8]
     438:      	str	q0, [sp, #0x60]
     43c:      	movi	d8, #0000000000000000
     440:      	add	x21, sp, #0x1, lsl #12  ; =0x1000
     444:      	add	x21, x21, #0x70
     448:      	str	w3, [sp, #0x5c]
     44c:      	b	0x494 <_llm_rows.packet_batch.blocks+0xe4>
     450:      	mov	w8, #0x18               ; =24
     454:      	str	w8, [x20, #0x24]
     458:      	ldr	w19, [sp, #0x5c]
     45c:      	add	w8, w25, #0x1
     460:      	ldp	w10, w9, [sp, #0x90]
     464:      	cmp	w8, w9
     468:      	cset	w8, eq
     46c:      	csinc	w25, wzr, w25, eq
     470:      	cinc	w9, w26, eq
     474:      	cmp	w9, w10
     478:      	cset	w10, eq
     47c:      	ands	w8, w8, w10
     480:      	csel	w12, wzr, w9, ne
     484:      	add	w27, w27, w8
     488:      	add	w22, w22, #0x1
     48c:      	cmp	w22, w19
     490:      	b.eq	0x1380 <_llm_rows.packet_batch.blocks+0xfd0>
     494:      	ubfiz	x8, x25, #5, #32
     498:      	ldr	x13, [sp, #0x88]
     49c:      	cmp	x8, x13
     4a0:      	csel	x9, x8, xzr, ls
     4a4:      	subs	x10, x13, x9
     4a8:      	cmp	x10, #0x20
     4ac:      	mov	w11, #0x20              ; =32
     4b0:      	csel	x10, x10, x11, lo
     4b4:      	cmp	x13, x9
     4b8:      	stp	w25, w12, [x20]
     4bc:      	mov	x23, x12
     4c0:      	str	w27, [x20, #0x8]
     4c4:      	str	wzr, [x20, #0x24]
     4c8:      	ccmp	x8, x13, #0x2, hi
     4cc:      	csel	x26, x10, xzr, ls
     4d0:      	cmp	x26, #0x20
     4d4:      	b.lo	0x52c <_llm_rows.packet_batch.blocks+0x17c>
     4d8:      	ldr	x26, [sp, #0x98]
     4dc:      	mov	x0, x26
     4e0:      	mov	x1, x20
     4e4:      	bl	0x4e4 <_llm_rows.packet_batch.blocks+0x134>
     4e8:      	mov	w8, #0x8                ; =8
     4ec:      	str	w8, [x20, #0x24]
     4f0:      	mov	x0, x26
     4f4:      	mov	x1, x20
     4f8:      	bl	0x4f8 <_llm_rows.packet_batch.blocks+0x148>
     4fc:      	mov	w8, #0x10               ; =16
     500:      	str	w8, [x20, #0x24]
     504:      	mov	x0, x26
     508:      	mov	x1, x20
     50c:      	bl	0x50c <_llm_rows.packet_batch.blocks+0x15c>
     510:      	mov	w8, #0x18               ; =24
     514:      	str	w8, [x20, #0x24]
     518:      	mov	x0, x26
     51c:      	mov	x1, x20
     520:      	bl	0x520 <_llm_rows.packet_batch.blocks+0x170>
     524:      	mov	x26, x23
     528:      	b	0x45c <_llm_rows.packet_batch.blocks+0xac>
     52c:      	lsr	x19, x26, #3
     530:      	cmp	x26, #0x8
     534:      	b.lo	0x580 <_llm_rows.packet_batch.blocks+0x1d0>
     538:      	str	wzr, [x20, #0x24]
     53c:      	ldr	x0, [sp, #0x98]
     540:      	mov	x1, x20
     544:      	bl	0x544 <_llm_rows.packet_batch.blocks+0x194>
     548:      	cmp	x19, #0x1
     54c:      	b.eq	0x580 <_llm_rows.packet_batch.blocks+0x1d0>
     550:      	mov	w8, #0x8                ; =8
     554:      	str	w8, [x20, #0x24]
     558:      	ldr	x0, [sp, #0x98]
     55c:      	mov	x1, x20
     560:      	bl	0x560 <_llm_rows.packet_batch.blocks+0x1b0>
     564:      	cmp	x19, #0x2
     568:      	b.eq	0x580 <_llm_rows.packet_batch.blocks+0x1d0>
     56c:      	mov	w8, #0x10               ; =16
     570:      	str	w8, [x20, #0x24]
     574:      	ldr	x0, [sp, #0x98]
     578:      	mov	x1, x20
     57c:      	bl	0x57c <_llm_rows.packet_batch.blocks+0x1cc>
     580:      	and	w8, w26, #0x7
     584:      	mov	x26, x23
     588:      	add	x23, sp, #0x470
     58c:      	cbz	w8, 0x450 <_llm_rows.packet_batch.blocks+0xa0>
     590:      	dup.4s	v1, w8
     594:      	ldp	q0, q2, [sp, #0x60]
     598:      	cmhi.4s	v0, v1, v0
     59c:      	cmhi.4s	v1, v1, v2
     5a0:      	uzp1.8h	v3, v1, v0
     5a4:      	umaxv.8h	h2, v3
     5a8:      	fmov	w8, s2
     5ac:      	tbz	w8, #0x0, 0x450 <_llm_rows.packet_batch.blocks+0xa0>
     5b0:      	mov	x9, #0x0                ; =0
     5b4:      	ldr	x11, [sp, #0x98]
     5b8:      	ldr	x12, [x11, #0x10]
     5bc:      	ldr	x8, [x11, #0x20]
     5c0:      	ldr	x10, [x11, #0x30]
     5c4:      	str	x10, [sp, #0x50]
     5c8:      	ldr	q2, [sp, #0x10]
     5cc:      	and.16b	v2, v3, v2
     5d0:      	addv.8h	h2, v2
     5d4:      	fmov	w10, s2
     5d8:      	and	w10, w10, #0xff
     5dc:      	ldr	x11, [x11]
     5e0:      	ubfiz	w13, w25, #2, #27
     5e4:      	orr	w13, w13, w19
     5e8:      	fmov	s4, w13
     5ec:      	and.16b	v4, v1, v4
     5f0:      	fmov	w13, s4
     5f4:      	mov	w14, #0xc00             ; =3072
     5f8:      	umull	x15, w13, w14
     5fc:      	str	x15, [sp, #0x48]
     600:      	umaddl	x11, w13, w14, x11
     604:      	fmov	w13, s2
     608:      	b	0x62c <_llm_rows.packet_batch.blocks+0x27c>
     60c:      	add	x14, x24, x9
     610:      	ldp	q6, q7, [x14]
     614:      	bif.16b	v5, v7, v0
     618:      	bif.16b	v4, v6, v1
     61c:      	stp	q4, q5, [x14]
     620:      	add	x9, x9, #0x20
     624:      	cmp	x9, #0xc00
     628:      	b.eq	0x6c0 <_llm_rows.packet_batch.blocks+0x310>
     62c:      	add	x14, x11, x9
     630:      	movi.2d	v4, #0000000000000000
     634:      	movi.2d	v5, #0000000000000000
     638:      	tbnz	w13, #0x0, 0x660 <_llm_rows.packet_batch.blocks+0x2b0>
     63c:      	and	w15, w13, #0xff
     640:      	tbnz	w15, #0x1, 0x66c <_llm_rows.packet_batch.blocks+0x2bc>
     644:      	tbnz	w15, #0x2, 0x678 <_llm_rows.packet_batch.blocks+0x2c8>
     648:      	tbnz	w15, #0x3, 0x684 <_llm_rows.packet_batch.blocks+0x2d4>
     64c:      	tbnz	w15, #0x4, 0x690 <_llm_rows.packet_batch.blocks+0x2e0>
     650:      	tbnz	w15, #0x5, 0x69c <_llm_rows.packet_batch.blocks+0x2ec>
     654:      	tbnz	w15, #0x6, 0x6a8 <_llm_rows.packet_batch.blocks+0x2f8>
     658:      	tbz	w15, #0x7, 0x60c <_llm_rows.packet_batch.blocks+0x25c>
     65c:      	b	0x6b4 <_llm_rows.packet_batch.blocks+0x304>
     660:      	ldr	s4, [x14]
     664:      	and	w15, w13, #0xff
     668:      	tbz	w15, #0x1, 0x644 <_llm_rows.packet_batch.blocks+0x294>
     66c:      	add	x16, x14, #0x4
     670:      	ld1.s	{ v4 }[1], [x16]
     674:      	tbz	w15, #0x2, 0x648 <_llm_rows.packet_batch.blocks+0x298>
     678:      	add	x16, x14, #0x8
     67c:      	ld1.s	{ v4 }[2], [x16]
     680:      	tbz	w15, #0x3, 0x64c <_llm_rows.packet_batch.blocks+0x29c>
     684:      	add	x16, x14, #0xc
     688:      	ld1.s	{ v4 }[3], [x16]
     68c:      	tbz	w15, #0x4, 0x650 <_llm_rows.packet_batch.blocks+0x2a0>
     690:      	add	x16, x14, #0x10
     694:      	ld1.s	{ v5 }[0], [x16]
     698:      	tbz	w15, #0x5, 0x654 <_llm_rows.packet_batch.blocks+0x2a4>
     69c:      	add	x16, x14, #0x14
     6a0:      	ld1.s	{ v5 }[1], [x16]
     6a4:      	tbz	w15, #0x6, 0x658 <_llm_rows.packet_batch.blocks+0x2a8>
     6a8:      	add	x16, x14, #0x18
     6ac:      	ld1.s	{ v5 }[2], [x16]
     6b0:      	tbz	w15, #0x7, 0x60c <_llm_rows.packet_batch.blocks+0x25c>
     6b4:      	add	x14, x14, #0x1c
     6b8:      	ld1.s	{ v5 }[3], [x14]
     6bc:      	b	0x60c <_llm_rows.packet_batch.blocks+0x25c>
     6c0:      	add	x9, sp, #0x130
     6c4:      	ldr	q4, [x9, #0x2740]
     6c8:      	ldr	q5, [x9, #0x2750]
     6cc:      	ldr	q6, [x9, #0x2760]
     6d0:      	ldr	q7, [x9, #0x2770]
     6d4:      	ldr	q16, [x9, #0x2780]
     6d8:      	ldr	q19, [x9, #0x2790]
     6dc:      	ldr	q20, [x9, #0x27a0]
     6e0:      	and.16b	v5, v0, v5
     6e4:      	and.16b	v4, v1, v4
     6e8:      	ldr	q21, [x9, #0x27b0]
     6ec:      	and.16b	v18, v0, v7
     6f0:      	and.16b	v17, v1, v6
     6f4:      	and.16b	v6, v0, v19
     6f8:      	and.16b	v19, v1, v16
     6fc:      	and.16b	v16, v0, v21
     700:      	and.16b	v7, v1, v20
     704:      	ldr	x9, [sp, #0x30]
     708:      	mov	w11, #0x4               ; =4
     70c:      	ldp	q21, q20, [x9, #-0x60]
     710:      	fadd.4s	v21, v4, v21
     714:      	fadd.4s	v20, v5, v20
     718:      	ldp	q23, q22, [x9, #-0x40]
     71c:      	fadd.4s	v23, v17, v23
     720:      	fadd.4s	v22, v18, v22
     724:      	ldp	q25, q24, [x9, #-0x20]
     728:      	fadd.4s	v25, v19, v25
     72c:      	fadd.4s	v24, v6, v24
     730:      	ldp	q27, q26, [x9], #0x80
     734:      	fadd.4s	v27, v7, v27
     738:      	fadd.4s	v26, v16, v26
     73c:      	bit.16b	v5, v20, v0
     740:      	bit.16b	v4, v21, v1
     744:      	bit.16b	v18, v22, v0
     748:      	bit.16b	v17, v23, v1
     74c:      	bit.16b	v6, v24, v0
     750:      	bit.16b	v19, v25, v1
     754:      	bit.16b	v16, v26, v0
     758:      	bit.16b	v7, v27, v1
     75c:      	cmp	x11, #0x5c
     760:      	add	x11, x11, #0x4
     764:      	b.lo	0x70c <_llm_rows.packet_batch.blocks+0x35c>
     768:      	mov	x3, #0x0                ; =0
     76c:      	xtn.8b	v3, v3
     770:      	fadd.4s	v5, v5, v18
     774:      	fadd.4s	v4, v4, v17
     778:      	fadd.4s	v17, v4, v19
     77c:      	fadd.4s	v4, v5, v6
     780:      	fadd.4s	v4, v4, v16
     784:      	fadd.4s	v5, v17, v7
     788:      	ldr	q6, [sp, #0x70]
     78c:      	and.16b	v7, v1, v6
     790:      	ldr	q6, [sp, #0x60]
     794:      	and.16b	v6, v0, v6
     798:      	movi.4s	v17, #0x1
     79c:      	eor.16b	v16, v6, v17
     7a0:      	eor.16b	v19, v7, v17
     7a4:      	umov.b	w11, v3[0]
     7a8:      	add	x5, sp, #0x130
     7ac:      	str	q5, [x5, #0x310]
     7b0:      	ldr	s7, [sp, #0x444]
     7b4:      	umov.b	w14, v3[1]
     7b8:      	ands	w9, w11, #0x1
     7bc:      	tst	w9, w14
     7c0:      	fcsel	s7, s7, s8, ne
     7c4:      	mov.s	w13, v19[1]
     7c8:      	add	x15, sp, #0x420
     7cc:      	orr	x15, x15, x13, lsl #2
     7d0:      	add	x16, sp, #0x2f8
     7d4:      	bfxil	x16, x13, #0, #3
     7d8:      	str	d3, [x5, #0x1c8]
     7dc:      	ldrb	w13, [x16]
     7e0:      	and	w13, w14, w13
     7e4:      	stp	q5, q4, [x5, #0x2f0]
     7e8:      	ldr	s17, [x15]
     7ec:      	tst	w13, #0x1
     7f0:      	fcsel	s17, s17, s8, ne
     7f4:      	mov.s	w13, v19[2]
     7f8:      	add	x15, sp, #0x400
     7fc:      	orr	x15, x15, x13, lsl #2
     800:      	add	x16, sp, #0x2f8
     804:      	bfxil	x16, x13, #0, #3
     808:      	ldrb	w13, [x16]
     80c:      	umov.b	w1, v3[2]
     810:      	and	w13, w1, w13
     814:      	stp	q5, q4, [x5, #0x2d0]
     818:      	ldr	s18, [x15]
     81c:      	tst	w13, #0x1
     820:      	fcsel	s18, s18, s8, ne
     824:      	mov.s	w13, v19[3]
     828:      	add	x15, sp, #0x3e0
     82c:      	orr	x15, x15, x13, lsl #2
     830:      	add	x16, sp, #0x2f8
     834:      	bfxil	x16, x13, #0, #3
     838:      	ldrb	w13, [x16]
     83c:      	umov.b	w2, v3[3]
     840:      	and	w13, w2, w13
     844:      	stp	q5, q4, [x5, #0x2b0]
     848:      	ldr	s19, [x15]
     84c:      	tst	w13, #0x1
     850:      	fcsel	s19, s19, s8, ne
     854:      	fmov	w13, s16
     858:      	add	x15, sp, #0x2f8
     85c:      	bfxil	x15, x13, #0, #3
     860:      	ldrb	w16, [x15]
     864:      	umov.b	w15, v3[4]
     868:      	and	w16, w15, w16
     86c:      	stp	q5, q4, [x5, #0x290]
     870:      	add	x17, sp, #0x3c0
     874:      	ldr	s20, [x17, w13, uxtw #2]
     878:      	tst	w16, #0x1
     87c:      	fcsel	s20, s20, s8, ne
     880:      	mov.s	w13, v16[1]
     884:      	add	x17, sp, #0x2f8
     888:      	bfxil	x17, x13, #0, #3
     88c:      	umov.b	w16, v3[5]
     890:      	ldrb	w17, [x17]
     894:      	and	w17, w16, w17
     898:      	stp	q5, q4, [x5, #0x270]
     89c:      	add	x0, sp, #0x3a0
     8a0:      	ldr	s21, [x0, w13, uxtw #2]
     8a4:      	tst	w17, #0x1
     8a8:      	fcsel	s21, s21, s8, ne
     8ac:      	mov.s	w13, v16[2]
     8b0:      	add	x17, sp, #0x2f8
     8b4:      	bfxil	x17, x13, #0, #3
     8b8:      	ldrb	w0, [x17]
     8bc:      	umov.b	w17, v3[6]
     8c0:      	and	w0, w17, w0
     8c4:      	stp	q5, q4, [x5, #0x250]
     8c8:      	add	x4, sp, #0x380
     8cc:      	ldr	s22, [x4, w13, uxtw #2]
     8d0:      	tst	w0, #0x1
     8d4:      	fcsel	s22, s22, s8, ne
     8d8:      	mov.s	w13, v16[3]
     8dc:      	add	x0, sp, #0x2f8
     8e0:      	bfxil	x0, x13, #0, #3
     8e4:      	ldrb	w4, [x0]
     8e8:      	umov.b	w0, v3[7]
     8ec:      	and	w4, w0, w4
     8f0:      	stp	q5, q4, [x5, #0x230]
     8f4:      	add	x6, sp, #0x360
     8f8:      	ldr	s16, [x6, w13, uxtw #2]
     8fc:      	tst	w4, #0x1
     900:      	fcsel	s16, s16, s8, ne
     904:      	mov.s	v7[1], v17[0]
     908:      	mov.s	v7[2], v18[0]
     90c:      	mov.s	v7[3], v19[0]
     910:      	mov.s	v20[1], v21[0]
     914:      	mov.s	v20[2], v22[0]
     918:      	mov.s	v20[3], v16[0]
     91c:      	fadd.4s	v4, v4, v20
     920:      	fadd.4s	v5, v5, v7
     924:      	movi.4s	v7, #0x2
     928:      	eor.16b	v6, v6, v7
     92c:      	str	q5, [x5, #0x210]
     930:      	ldr	s7, [sp, #0x348]
     934:      	tst	w9, w1
     938:      	fcsel	s7, s7, s8, ne
     93c:      	fmov	w9, s6
     940:      	add	x13, sp, #0x2f8
     944:      	bfxil	x13, x9, #0, #3
     948:      	ldrb	w13, [x13]
     94c:      	and	w13, w15, w13
     950:      	stp	q5, q4, [x5, #0x1f0]
     954:      	add	x4, sp, #0x320
     958:      	ldr	s6, [x4, w9, uxtw #2]
     95c:      	tst	w13, #0x1
     960:      	fcsel	s6, s6, s8, ne
     964:      	fadd.4s	v4, v4, v6
     968:      	and	w13, w11, w15
     96c:      	tst	w13, #0x1
     970:      	fcsel	s4, s4, s8, ne
     974:      	ands	w9, w11, #0x1
     978:      	fadd.4s	v5, v5, v7
     97c:      	fadd	s4, s5, s4
     980:      	fcsel	s5, s4, s8, ne
     984:      	tst	w13, #0x1
     988:      	and	w4, w14, w11
     98c:      	fcsel	s6, s4, s8, ne
     990:      	str	w4, [sp, #0x44]
     994:      	tst	w4, #0x1
     998:      	and	w4, w1, w11
     99c:      	fcsel	s7, s4, s8, ne
     9a0:      	str	w4, [sp, #0x40]
     9a4:      	tst	w4, #0x1
     9a8:      	and	w4, w2, w11
     9ac:      	fcsel	s16, s4, s8, ne
     9b0:      	str	w4, [sp, #0x3c]
     9b4:      	tst	w4, #0x1
     9b8:      	fcsel	s17, s4, s8, ne
     9bc:      	and	w6, w16, w11
     9c0:      	tst	w6, #0x1
     9c4:      	fcsel	s18, s4, s8, ne
     9c8:      	and	w7, w17, w11
     9cc:      	tst	w7, #0x1
     9d0:      	fcsel	s19, s4, s8, ne
     9d4:      	and	w30, w0, w11
     9d8:      	tst	w30, #0x1
     9dc:      	mov.s	v5[1], v7[0]
     9e0:      	mov.s	v5[2], v16[0]
     9e4:      	mov.s	v5[3], v17[0]
     9e8:      	mov.s	v6[1], v18[0]
     9ec:      	fcsel	s4, s4, s8, ne
     9f0:      	mov.s	v6[2], v19[0]
     9f4:      	mov.s	v6[3], v4[0]
     9f8:      	rbit	w10, w10
     9fc:      	clz	w10, w10
     a00:      	stp	q5, q6, [x5, #0x1d0]
     a04:      	and	x4, x10, #0x7
     a08:      	add	x5, sp, #0x300
     a0c:      	ldr	s4, [x5, x4, lsl #2]
     a10:      	fadd	s4, s4, s8
     a14:      	mov	w4, #0x44400000         ; =1145044992
     a18:      	fmov	s5, w4
     a1c:      	fdiv	s4, s4, s5
     a20:      	dup.4s	v4, v4[0]
     a24:      	add	x4, x24, x3
     a28:      	ldp	q6, q5, [x4]
     a2c:      	fsub.4s	v6, v6, v4
     a30:      	fsub.4s	v5, v5, v4
     a34:      	add	x4, x28, x3
     a38:      	ldp	q7, q16, [x4]
     a3c:      	bif.16b	v5, v16, v0
     a40:      	bif.16b	v6, v7, v1
     a44:      	stp	q6, q5, [x4]
     a48:      	add	x3, x3, #0x20
     a4c:      	cmp	x3, #0xc00
     a50:      	b.ne	0xa24 <_llm_rows.packet_batch.blocks+0x674>
     a54:      	add	x3, sp, #0x130
     a58:      	ldr	q4, [x3, #0x1b50]
     a5c:      	ldr	q5, [x3, #0x1b40]
     a60:      	fmul.4s	v6, v5, v5
     a64:      	fmul.4s	v4, v4, v4
     a68:      	ldr	q5, [x3, #0x1b70]
     a6c:      	ldr	q7, [x3, #0x1b60]
     a70:      	fmul.4s	v7, v7, v7
     a74:      	fmul.4s	v16, v5, v5
     a78:      	ldr	q5, [x3, #0x1b90]
     a7c:      	ldr	q17, [x3, #0x1b80]
     a80:      	fmul.4s	v19, v17, v17
     a84:      	fmul.4s	v20, v5, v5
     a88:      	ldr	q5, [x3, #0x1bb0]
     a8c:      	ldr	q17, [x3, #0x1ba0]
     a90:      	fmul.4s	v21, v17, v17
     a94:      	fmul.4s	v22, v5, v5
     a98:      	and.16b	v5, v0, v4
     a9c:      	and.16b	v4, v1, v6
     aa0:      	and.16b	v18, v0, v16
     aa4:      	and.16b	v17, v1, v7
     aa8:      	and.16b	v6, v0, v20
     aac:      	and.16b	v19, v1, v19
     ab0:      	and.16b	v16, v0, v22
     ab4:      	and.16b	v7, v1, v21
     ab8:      	ldr	x3, [sp, #0x28]
     abc:      	mov	w4, #0x4                ; =4
     ac0:      	ldp	q21, q20, [x3, #-0x60]
     ac4:      	and.16b	v21, v1, v21
     ac8:      	and.16b	v20, v0, v20
     acc:      	fmul.4s	v20, v20, v20
     ad0:      	fmul.4s	v21, v21, v21
     ad4:      	fadd.4s	v21, v4, v21
     ad8:      	fadd.4s	v20, v5, v20
     adc:      	ldp	q23, q22, [x3, #-0x40]
     ae0:      	and.16b	v23, v1, v23
     ae4:      	and.16b	v22, v0, v22
     ae8:      	fmul.4s	v22, v22, v22
     aec:      	fmul.4s	v23, v23, v23
     af0:      	fadd.4s	v23, v17, v23
     af4:      	fadd.4s	v22, v18, v22
     af8:      	ldp	q25, q24, [x3, #-0x20]
     afc:      	and.16b	v25, v1, v25
     b00:      	and.16b	v24, v0, v24
     b04:      	fmul.4s	v24, v24, v24
     b08:      	fmul.4s	v25, v25, v25
     b0c:      	fadd.4s	v25, v19, v25
     b10:      	fadd.4s	v24, v6, v24
     b14:      	ldp	q27, q26, [x3], #0x80
     b18:      	and.16b	v27, v1, v27
     b1c:      	and.16b	v26, v0, v26
     b20:      	fmul.4s	v26, v26, v26
     b24:      	fmul.4s	v27, v27, v27
     b28:      	fadd.4s	v27, v7, v27
     b2c:      	fadd.4s	v26, v16, v26
     b30:      	bit.16b	v5, v20, v0
     b34:      	bit.16b	v4, v21, v1
     b38:      	bit.16b	v18, v22, v0
     b3c:      	bit.16b	v17, v23, v1
     b40:      	bit.16b	v6, v24, v0
     b44:      	bit.16b	v19, v25, v1
     b48:      	bit.16b	v16, v26, v0
     b4c:      	bit.16b	v7, v27, v1
     b50:      	cmp	x4, #0x5c
     b54:      	add	x4, x4, #0x4
     b58:      	b.lo	0xac0 <_llm_rows.packet_batch.blocks+0x710>
     b5c:      	mov	x3, #0x0                ; =0
     b60:      	b	0xb84 <_llm_rows.packet_batch.blocks+0x7d4>
     b64:      	add	x4, x21, x3
     b68:      	ldp	q22, q23, [x4]
     b6c:      	bif.16b	v21, v23, v0
     b70:      	bif.16b	v20, v22, v1
     b74:      	stp	q20, q21, [x4]
     b78:      	add	x3, x3, #0x20
     b7c:      	cmp	x3, #0xc00
     b80:      	b.eq	0xc1c <_llm_rows.packet_batch.blocks+0x86c>
     b84:      	fmov	w5, s2
     b88:      	add	x4, x12, x3
     b8c:      	movi.2d	v20, #0000000000000000
     b90:      	movi.2d	v21, #0000000000000000
     b94:      	tbnz	w5, #0x0, 0xbbc <_llm_rows.packet_batch.blocks+0x80c>
     b98:      	and	w5, w5, #0xff
     b9c:      	tbnz	w5, #0x1, 0xbc8 <_llm_rows.packet_batch.blocks+0x818>
     ba0:      	tbnz	w5, #0x2, 0xbd4 <_llm_rows.packet_batch.blocks+0x824>
     ba4:      	tbnz	w5, #0x3, 0xbe0 <_llm_rows.packet_batch.blocks+0x830>
     ba8:      	tbnz	w5, #0x4, 0xbec <_llm_rows.packet_batch.blocks+0x83c>
     bac:      	tbnz	w5, #0x5, 0xbf8 <_llm_rows.packet_batch.blocks+0x848>
     bb0:      	tbnz	w5, #0x6, 0xc04 <_llm_rows.packet_batch.blocks+0x854>
     bb4:      	tbz	w5, #0x7, 0xb64 <_llm_rows.packet_batch.blocks+0x7b4>
     bb8:      	b	0xc10 <_llm_rows.packet_batch.blocks+0x860>
     bbc:      	ldr	s20, [x4]
     bc0:      	and	w5, w5, #0xff
     bc4:      	tbz	w5, #0x1, 0xba0 <_llm_rows.packet_batch.blocks+0x7f0>
     bc8:      	add	x19, x4, #0x4
     bcc:      	ld1.s	{ v20 }[1], [x19]
     bd0:      	tbz	w5, #0x2, 0xba4 <_llm_rows.packet_batch.blocks+0x7f4>
     bd4:      	add	x19, x4, #0x8
     bd8:      	ld1.s	{ v20 }[2], [x19]
     bdc:      	tbz	w5, #0x3, 0xba8 <_llm_rows.packet_batch.blocks+0x7f8>
     be0:      	add	x19, x4, #0xc
     be4:      	ld1.s	{ v20 }[3], [x19]
     be8:      	tbz	w5, #0x4, 0xbac <_llm_rows.packet_batch.blocks+0x7fc>
     bec:      	add	x19, x4, #0x10
     bf0:      	ld1.s	{ v21 }[0], [x19]
     bf4:      	tbz	w5, #0x5, 0xbb0 <_llm_rows.packet_batch.blocks+0x800>
     bf8:      	add	x19, x4, #0x14
     bfc:      	ld1.s	{ v21 }[1], [x19]
     c00:      	tbz	w5, #0x6, 0xbb4 <_llm_rows.packet_batch.blocks+0x804>
     c04:      	add	x19, x4, #0x18
     c08:      	ld1.s	{ v21 }[2], [x19]
     c0c:      	tbz	w5, #0x7, 0xb64 <_llm_rows.packet_batch.blocks+0x7b4>
     c10:      	add	x4, x4, #0x1c
     c14:      	ld1.s	{ v21 }[3], [x4]
     c18:      	b	0xb64 <_llm_rows.packet_batch.blocks+0x7b4>
     c1c:      	adrp	x12, 0x0 <ltmp0>
     c20:      	ldr	q20, [x12]
     c24:      	and.16b	v21, v0, v20
     c28:      	adrp	x12, 0x0 <ltmp0>
     c2c:      	ldr	q20, [x12]
     c30:      	and.16b	v22, v1, v20
     c34:      	adrp	x12, 0x0 <ltmp0>
     c38:      	ldr	q20, [x12]
     c3c:      	and.16b	v20, v1, v20
     c40:      	fadd.4s	v5, v5, v18
     c44:      	fadd.4s	v4, v4, v17
     c48:      	fadd.4s	v17, v4, v19
     c4c:      	fadd.4s	v4, v5, v6
     c50:      	fadd.4s	v4, v4, v16
     c54:      	fadd.4s	v5, v17, v7
     c58:      	fmov	w12, s22
     c5c:      	add	x3, sp, #0xa8
     c60:      	bfxil	x3, x12, #0, #3
     c64:      	str	d3, [sp, #0xa8]
     c68:      	ldrb	w3, [x3]
     c6c:      	add	x4, sp, #0x2d0
     c70:      	orr	x12, x4, x12, lsl #2
     c74:      	add	x4, sp, #0x130
     c78:      	stp	q5, q4, [x4, #0x1a0]
     c7c:      	ldr	s3, [x12]
     c80:      	tst	w9, w3
     c84:      	mov.s	w12, v22[1]
     c88:      	fcsel	s6, s3, s8, ne
     c8c:      	add	x3, sp, #0xa8
     c90:      	bfxil	x3, x12, #0, #3
     c94:      	ldrb	w12, [x3]
     c98:      	and	w12, w14, w12
     c9c:      	str	q5, [x4, #0x180]
     ca0:      	ldr	s3, [sp, #0x2b0]
     ca4:      	tst	w12, #0x1
     ca8:      	fcsel	s3, s3, s8, ne
     cac:      	mov.s	w12, v22[2]
     cb0:      	add	x3, sp, #0xa8
     cb4:      	bfxil	x3, x12, #0, #3
     cb8:      	add	x5, sp, #0x290
     cbc:      	orr	x12, x5, x12, lsl #2
     cc0:      	ldrb	w3, [x3]
     cc4:      	and	w3, w1, w3
     cc8:      	stp	q5, q4, [x4, #0x160]
     ccc:      	ldr	s7, [x12]
     cd0:      	tst	w3, #0x1
     cd4:      	fcsel	s7, s7, s8, ne
     cd8:      	mov.s	w12, v22[3]
     cdc:      	add	x3, sp, #0xa8
     ce0:      	bfxil	x3, x12, #0, #3
     ce4:      	add	x5, sp, #0x270
     ce8:      	orr	x12, x5, x12, lsl #2
     cec:      	ldrb	w3, [x3]
     cf0:      	and	w3, w2, w3
     cf4:      	stp	q5, q4, [x4, #0x140]
     cf8:      	ldr	s16, [x12]
     cfc:      	tst	w3, #0x1
     d00:      	fcsel	s16, s16, s8, ne
     d04:      	fmov	w12, s21
     d08:      	add	x3, sp, #0xa8
     d0c:      	bfxil	x3, x12, #0, #3
     d10:      	ldrb	w3, [x3]
     d14:      	and	w3, w15, w3
     d18:      	stp	q5, q4, [x4, #0x120]
     d1c:      	add	x5, sp, #0x250
     d20:      	ldr	s17, [x5, w12, uxtw #2]
     d24:      	tst	w3, #0x1
     d28:      	fcsel	s17, s17, s8, ne
     d2c:      	mov.s	w12, v21[1]
     d30:      	add	x3, sp, #0xa8
     d34:      	bfxil	x3, x12, #0, #3
     d38:      	ldrb	w3, [x3]
     d3c:      	and	w3, w16, w3
     d40:      	stp	q5, q4, [x4, #0x100]
     d44:      	add	x5, sp, #0x230
     d48:      	ldr	s18, [x5, w12, uxtw #2]
     d4c:      	tst	w3, #0x1
     d50:      	fcsel	s18, s18, s8, ne
     d54:      	mov.s	w12, v21[2]
     d58:      	add	x3, sp, #0xa8
     d5c:      	bfxil	x3, x12, #0, #3
     d60:      	ldrb	w3, [x3]
     d64:      	and	w3, w17, w3
     d68:      	stp	q5, q4, [x4, #0xe0]
     d6c:      	add	x5, sp, #0x210
     d70:      	ldr	s19, [x5, w12, uxtw #2]
     d74:      	tst	w3, #0x1
     d78:      	fcsel	s19, s19, s8, ne
     d7c:      	mov.s	w12, v21[3]
     d80:      	add	x3, sp, #0xa8
     d84:      	bfxil	x3, x12, #0, #3
     d88:      	ldrb	w3, [x3]
     d8c:      	and	w3, w0, w3
     d90:      	stp	q5, q4, [x4, #0xc0]
     d94:      	add	x5, sp, #0x1f0
     d98:      	ldr	s21, [x5, w12, uxtw #2]
     d9c:      	tst	w3, #0x1
     da0:      	fcsel	s21, s21, s8, ne
     da4:      	mov.s	v6[1], v3[0]
     da8:      	mov.s	v6[2], v7[0]
     dac:      	mov.s	v6[3], v16[0]
     db0:      	mov.s	v17[1], v18[0]
     db4:      	mov.s	v17[2], v19[0]
     db8:      	mov.s	v17[3], v21[0]
     dbc:      	fadd.4s	v3, v4, v17
     dc0:      	fadd.4s	v4, v5, v6
     dc4:      	fmov	w12, s20
     dc8:      	add	x3, sp, #0xa8
     dcc:      	bfxil	x3, x12, #0, #3
     dd0:      	ldrb	w3, [x3]
     dd4:      	add	x5, sp, #0x1d0
     dd8:      	orr	x12, x5, x12, lsl #2
     ddc:      	stp	q4, q3, [x4, #0xa0]
     de0:      	ldr	s5, [x12]
     de4:      	tst	w9, w3
     de8:      	mov.s	w12, v20[1]
     dec:      	add	x3, sp, #0xa8
     df0:      	bfxil	x3, x12, #0, #3
     df4:      	ldrb	w3, [x3]
     df8:      	and	w14, w14, w3
     dfc:      	fcsel	s5, s5, s8, ne
     e00:      	add	x3, sp, #0x1b0
     e04:      	orr	x12, x3, x12, lsl #2
     e08:      	stp	q4, q3, [x4, #0x80]
     e0c:      	ldr	s6, [x12]
     e10:      	tst	w14, #0x1
     e14:      	mov.s	w12, v20[2]
     e18:      	add	x14, sp, #0xa8
     e1c:      	bfxil	x14, x12, #0, #3
     e20:      	fcsel	s6, s6, s8, ne
     e24:      	ldrb	w12, [x14]
     e28:      	and	w12, w1, w12
     e2c:      	str	q4, [x4, #0x60]
     e30:      	tst	w12, #0x1
     e34:      	mov.s	w12, v20[3]
     e38:      	add	x14, sp, #0xa8
     e3c:      	bfxil	x14, x12, #0, #3
     e40:      	ldrb	w14, [x14]
     e44:      	and	w14, w2, w14
     e48:      	adrp	x1, 0x0 <ltmp0>
     e4c:      	ldr	q7, [x1]
     e50:      	and.16b	v18, v0, v7
     e54:      	ldr	s7, [sp, #0x190]
     e58:      	fcsel	s7, s7, s8, ne
     e5c:      	add	x1, sp, #0x170
     e60:      	orr	x12, x1, x12, lsl #2
     e64:      	stp	q4, q3, [x4, #0x40]
     e68:      	ldr	s16, [x12]
     e6c:      	tst	w14, #0x1
     e70:      	fmov	w12, s18
     e74:      	add	x14, sp, #0xa8
     e78:      	bfxil	x14, x12, #0, #3
     e7c:      	ldrb	w14, [x14]
     e80:      	and	w14, w15, w14
     e84:      	fcsel	s16, s16, s8, ne
     e88:      	stp	q4, q3, [x4, #0x20]
     e8c:      	add	x15, sp, #0x150
     e90:      	ldr	s17, [x15, w12, uxtw #2]
     e94:      	tst	w14, #0x1
     e98:      	mov.s	w12, v18[1]
     e9c:      	add	x14, sp, #0xa8
     ea0:      	bfxil	x14, x12, #0, #3
     ea4:      	ldrb	w14, [x14]
     ea8:      	and	w14, w16, w14
     eac:      	fcsel	s17, s17, s8, ne
     eb0:      	stp	q4, q3, [x4]
     eb4:      	ldr	s19, [x4, w12, uxtw #2]
     eb8:      	tst	w14, #0x1
     ebc:      	mov.s	w12, v18[2]
     ec0:      	add	x14, sp, #0xa8
     ec4:      	bfxil	x14, x12, #0, #3
     ec8:      	ldrb	w14, [x14]
     ecc:      	and	w14, w17, w14
     ed0:      	fcsel	s19, s19, s8, ne
     ed4:      	stp	q4, q3, [sp, #0x110]
     ed8:      	add	x15, sp, #0x110
     edc:      	ldr	s20, [x15, w12, uxtw #2]
     ee0:      	tst	w14, #0x1
     ee4:      	mov.s	w12, v18[3]
     ee8:      	add	x14, sp, #0xa8
     eec:      	bfxil	x14, x12, #0, #3
     ef0:      	ldrb	w14, [x14]
     ef4:      	and	w14, w0, w14
     ef8:      	movi.4s	v18, #0x4
     efc:      	and.16b	v18, v1, v18
     f00:      	fcsel	s20, s20, s8, ne
     f04:      	stp	q4, q3, [sp, #0xf0]
     f08:      	add	x15, sp, #0xf0
     f0c:      	ldr	s21, [x15, w12, uxtw #2]
     f10:      	tst	w14, #0x1
     f14:      	fcsel	s21, s21, s8, ne
     f18:      	fmov	w12, s18
     f1c:      	add	x14, sp, #0xa8
     f20:      	orr	x14, x14, x12
     f24:      	ldrb	w14, [x14]
     f28:      	tst	w9, w14
     f2c:      	mov.s	v17[1], v19[0]
     f30:      	mov.s	v17[2], v20[0]
     f34:      	mov.s	v17[3], v21[0]
     f38:      	mov.s	v5[1], v6[0]
     f3c:      	mov.s	v5[2], v7[0]
     f40:      	mov.s	v5[3], v16[0]
     f44:      	fadd.4s	v4, v4, v5
     f48:      	fadd.4s	v3, v3, v17
     f4c:      	stp	q4, q3, [sp, #0xd0]
     f50:      	add	x9, sp, #0xd0
     f54:      	ldr	s3, [x9, w12, uxtw #2]
     f58:      	fcsel	s3, s3, s8, ne
     f5c:      	tst	w11, #0x1
     f60:      	fadd	s3, s4, s3
     f64:      	fcsel	s4, s3, s8, ne
     f68:      	ldp	w9, w11, [sp, #0x40]
     f6c:      	tst	w11, #0x1
     f70:      	fcsel	s5, s3, s8, ne
     f74:      	tst	w9, #0x1
     f78:      	fcsel	s6, s3, s8, ne
     f7c:      	ldr	w9, [sp, #0x3c]
     f80:      	tst	w9, #0x1
     f84:      	fcsel	s7, s3, s8, ne
     f88:      	tst	w13, #0x1
     f8c:      	fcsel	s16, s3, s8, ne
     f90:      	tst	w6, #0x1
     f94:      	fcsel	s17, s3, s8, ne
     f98:      	tst	w7, #0x1
     f9c:      	fcsel	s18, s3, s8, ne
     fa0:      	tst	w30, #0x1
     fa4:      	fcsel	s3, s3, s8, ne
     fa8:      	mov.s	v4[1], v5[0]
     fac:      	mov.s	v4[2], v6[0]
     fb0:      	mov.s	v4[3], v7[0]
     fb4:      	mov.s	v16[1], v17[0]
     fb8:      	mov.s	v16[2], v18[0]
     fbc:      	mov.s	v16[3], v3[0]
     fc0:      	stp	q4, q16, [sp, #0xb0]
     fc4:      	and	x9, x10, #0x7
     fc8:      	add	x10, sp, #0xb0
     fcc:      	ldr	s3, [x10, x9, lsl #2]
     fd0:      	ldr	x13, [sp, #0x50]
     fd4:      	sub	x9, x8, x13
     fd8:      	lsr	x10, x9, #10
     fdc:      	subs	x9, x13, x8
     fe0:      	mov	w11, #0xbff             ; =3071
     fe4:      	ccmp	x9, x11, #0x0, hs
     fe8:      	cset	w9, hi
     fec:      	cmp	x10, #0x182
     ff0:      	fadd	s3, s3, s8
     ff4:      	mov	w10, #0x44400000        ; =1145044992
     ff8:      	fmov	s4, w10
     ffc:      	fdiv	s3, s3, s4
    1000:      	mov	w10, #0xc5ac            ; =50604
    1004:      	movk	w10, #0x3727, lsl #16
    1008:      	fmov	s4, w10
    100c:      	fadd	s3, s3, s4
    1010:      	fsqrt	s3, s3
    1014:      	ccmp	x8, x13, #0x0, hi
    1018:      	b.hs	0x10e0 <_llm_rows.packet_batch.blocks+0xd30>
    101c:      	tbnz	w9, #0x0, 0x10e0 <_llm_rows.packet_batch.blocks+0xd30>
    1020:      	mov	x9, #0x0                ; =0
    1024:      	b	0x1048 <_llm_rows.packet_batch.blocks+0xc98>
    1028:      	add	x10, x23, x9
    102c:      	ldp	q6, q7, [x10]
    1030:      	bif.16b	v5, v7, v0
    1034:      	bif.16b	v4, v6, v1
    1038:      	stp	q4, q5, [x10]
    103c:      	add	x9, x9, #0x20
    1040:      	cmp	x9, #0xc00
    1044:      	b.eq	0x127c <_llm_rows.packet_batch.blocks+0xecc>
    1048:      	fmov	w11, s2
    104c:      	add	x10, x8, x9
    1050:      	movi.2d	v4, #0000000000000000
    1054:      	movi.2d	v5, #0000000000000000
    1058:      	tbnz	w11, #0x0, 0x1080 <_llm_rows.packet_batch.blocks+0xcd0>
    105c:      	and	w11, w11, #0xff
    1060:      	tbnz	w11, #0x1, 0x108c <_llm_rows.packet_batch.blocks+0xcdc>
    1064:      	tbnz	w11, #0x2, 0x1098 <_llm_rows.packet_batch.blocks+0xce8>
    1068:      	tbnz	w11, #0x3, 0x10a4 <_llm_rows.packet_batch.blocks+0xcf4>
    106c:      	tbnz	w11, #0x4, 0x10b0 <_llm_rows.packet_batch.blocks+0xd00>
    1070:      	tbnz	w11, #0x5, 0x10bc <_llm_rows.packet_batch.blocks+0xd0c>
    1074:      	tbnz	w11, #0x6, 0x10c8 <_llm_rows.packet_batch.blocks+0xd18>
    1078:      	tbz	w11, #0x7, 0x1028 <_llm_rows.packet_batch.blocks+0xc78>
    107c:      	b	0x10d4 <_llm_rows.packet_batch.blocks+0xd24>
    1080:      	ldr	s4, [x10]
    1084:      	and	w11, w11, #0xff
    1088:      	tbz	w11, #0x1, 0x1064 <_llm_rows.packet_batch.blocks+0xcb4>
    108c:      	add	x12, x10, #0x4
    1090:      	ld1.s	{ v4 }[1], [x12]
    1094:      	tbz	w11, #0x2, 0x1068 <_llm_rows.packet_batch.blocks+0xcb8>
    1098:      	add	x12, x10, #0x8
    109c:      	ld1.s	{ v4 }[2], [x12]
    10a0:      	tbz	w11, #0x3, 0x106c <_llm_rows.packet_batch.blocks+0xcbc>
    10a4:      	add	x12, x10, #0xc
    10a8:      	ld1.s	{ v4 }[3], [x12]
    10ac:      	tbz	w11, #0x4, 0x1070 <_llm_rows.packet_batch.blocks+0xcc0>
    10b0:      	add	x12, x10, #0x10
    10b4:      	ld1.s	{ v5 }[0], [x12]
    10b8:      	tbz	w11, #0x5, 0x1074 <_llm_rows.packet_batch.blocks+0xcc4>
    10bc:      	add	x12, x10, #0x14
    10c0:      	ld1.s	{ v5 }[1], [x12]
    10c4:      	tbz	w11, #0x6, 0x1078 <_llm_rows.packet_batch.blocks+0xcc8>
    10c8:      	add	x12, x10, #0x18
    10cc:      	ld1.s	{ v5 }[2], [x12]
    10d0:      	tbz	w11, #0x7, 0x1028 <_llm_rows.packet_batch.blocks+0xc78>
    10d4:      	add	x10, x10, #0x1c
    10d8:      	ld1.s	{ v5 }[3], [x10]
    10dc:      	b	0x1028 <_llm_rows.packet_batch.blocks+0xc78>
    10e0:      	mov	x9, #0x0                ; =0
    10e4:      	dup.4s	v3, v3[0]
    10e8:      	ldr	x10, [sp, #0x48]
    10ec:      	add	x10, x13, x10
    10f0:      	b	0x1100 <_llm_rows.packet_batch.blocks+0xd50>
    10f4:      	add	x9, x9, #0x20
    10f8:      	cmp	x9, #0xc00
    10fc:      	b.eq	0x450 <_llm_rows.packet_batch.blocks+0xa0>
    1100:      	fmov	w12, s2
    1104:      	add	x11, x8, x9
    1108:      	movi.2d	v5, #0000000000000000
    110c:      	movi.2d	v4, #0000000000000000
    1110:      	tbnz	w12, #0x0, 0x11ac <_llm_rows.packet_batch.blocks+0xdfc>
    1114:      	and	w12, w12, #0xff
    1118:      	tbnz	w12, #0x1, 0x11b8 <_llm_rows.packet_batch.blocks+0xe08>
    111c:      	tbnz	w12, #0x2, 0x11c4 <_llm_rows.packet_batch.blocks+0xe14>
    1120:      	tbnz	w12, #0x3, 0x11d0 <_llm_rows.packet_batch.blocks+0xe20>
    1124:      	tbnz	w12, #0x4, 0x11dc <_llm_rows.packet_batch.blocks+0xe2c>
    1128:      	tbnz	w12, #0x5, 0x11e8 <_llm_rows.packet_batch.blocks+0xe38>
    112c:      	tbnz	w12, #0x6, 0x11f4 <_llm_rows.packet_batch.blocks+0xe44>
    1130:      	tbz	w12, #0x7, 0x113c <_llm_rows.packet_batch.blocks+0xd8c>
    1134:      	add	x11, x11, #0x1c
    1138:      	ld1.s	{ v4 }[3], [x11]
    113c:      	add	x13, x28, x9
    1140:      	ldr	q6, [x13]
    1144:      	and.16b	v6, v1, v6
    1148:      	fdiv.4s	v6, v6, v3
    114c:      	add	x14, x21, x9
    1150:      	ldr	q7, [x14]
    1154:      	and.16b	v7, v1, v7
    1158:      	fmul.4s	v6, v6, v7
    115c:      	fmov	w12, s2
    1160:      	fadd.4s	v5, v5, v6
    1164:      	add	x11, x10, x9
    1168:      	tbnz	w12, #0x0, 0x1204 <_llm_rows.packet_batch.blocks+0xe54>
    116c:      	and	w12, w12, #0xff
    1170:      	tbnz	w12, #0x1, 0x1210 <_llm_rows.packet_batch.blocks+0xe60>
    1174:      	ldr	q7, [x13, #0x10]
    1178:      	ldr	q6, [x14, #0x10]
    117c:      	tbnz	w12, #0x2, 0x1224 <_llm_rows.packet_batch.blocks+0xe74>
    1180:      	tbnz	w12, #0x3, 0x1230 <_llm_rows.packet_batch.blocks+0xe80>
    1184:      	and.16b	v5, v0, v7
    1188:      	fdiv.4s	v5, v5, v3
    118c:      	and.16b	v6, v0, v6
    1190:      	fmul.4s	v5, v5, v6
    1194:      	fadd.4s	v4, v4, v5
    1198:      	tbnz	w12, #0x4, 0x1250 <_llm_rows.packet_batch.blocks+0xea0>
    119c:      	tbnz	w12, #0x5, 0x1258 <_llm_rows.packet_batch.blocks+0xea8>
    11a0:      	tbnz	w12, #0x6, 0x1264 <_llm_rows.packet_batch.blocks+0xeb4>
    11a4:      	tbz	w12, #0x7, 0x10f4 <_llm_rows.packet_batch.blocks+0xd44>
    11a8:      	b	0x1270 <_llm_rows.packet_batch.blocks+0xec0>
    11ac:      	ldr	s5, [x11]
    11b0:      	and	w12, w12, #0xff
    11b4:      	tbz	w12, #0x1, 0x111c <_llm_rows.packet_batch.blocks+0xd6c>
    11b8:      	add	x13, x11, #0x4
    11bc:      	ld1.s	{ v5 }[1], [x13]
    11c0:      	tbz	w12, #0x2, 0x1120 <_llm_rows.packet_batch.blocks+0xd70>
    11c4:      	add	x13, x11, #0x8
    11c8:      	ld1.s	{ v5 }[2], [x13]
    11cc:      	tbz	w12, #0x3, 0x1124 <_llm_rows.packet_batch.blocks+0xd74>
    11d0:      	add	x13, x11, #0xc
    11d4:      	ld1.s	{ v5 }[3], [x13]
    11d8:      	tbz	w12, #0x4, 0x1128 <_llm_rows.packet_batch.blocks+0xd78>
    11dc:      	add	x13, x11, #0x10
    11e0:      	ld1.s	{ v4 }[0], [x13]
    11e4:      	tbz	w12, #0x5, 0x112c <_llm_rows.packet_batch.blocks+0xd7c>
    11e8:      	add	x13, x11, #0x14
    11ec:      	ld1.s	{ v4 }[1], [x13]
    11f0:      	tbz	w12, #0x6, 0x1130 <_llm_rows.packet_batch.blocks+0xd80>
    11f4:      	add	x13, x11, #0x18
    11f8:      	ld1.s	{ v4 }[2], [x13]
    11fc:      	tbnz	w12, #0x7, 0x1134 <_llm_rows.packet_batch.blocks+0xd84>
    1200:      	b	0x113c <_llm_rows.packet_batch.blocks+0xd8c>
    1204:      	str	s5, [x11]
    1208:      	and	w12, w12, #0xff
    120c:      	tbz	w12, #0x1, 0x1174 <_llm_rows.packet_batch.blocks+0xdc4>
    1210:      	add	x15, x11, #0x4
    1214:      	st1.s	{ v5 }[1], [x15]
    1218:      	ldr	q7, [x13, #0x10]
    121c:      	ldr	q6, [x14, #0x10]
    1220:      	tbz	w12, #0x2, 0x1180 <_llm_rows.packet_batch.blocks+0xdd0>
    1224:      	add	x13, x11, #0x8
    1228:      	st1.s	{ v5 }[2], [x13]
    122c:      	tbz	w12, #0x3, 0x1184 <_llm_rows.packet_batch.blocks+0xdd4>
    1230:      	add	x13, x11, #0xc
    1234:      	st1.s	{ v5 }[3], [x13]
    1238:      	and.16b	v5, v0, v7
    123c:      	fdiv.4s	v5, v5, v3
    1240:      	and.16b	v6, v0, v6
    1244:      	fmul.4s	v5, v5, v6
    1248:      	fadd.4s	v4, v4, v5
    124c:      	tbz	w12, #0x4, 0x119c <_llm_rows.packet_batch.blocks+0xdec>
    1250:      	str	s4, [x11, #0x10]
    1254:      	tbz	w12, #0x5, 0x11a0 <_llm_rows.packet_batch.blocks+0xdf0>
    1258:      	add	x13, x11, #0x14
    125c:      	st1.s	{ v4 }[1], [x13]
    1260:      	tbz	w12, #0x6, 0x11a4 <_llm_rows.packet_batch.blocks+0xdf4>
    1264:      	add	x13, x11, #0x18
    1268:      	st1.s	{ v4 }[2], [x13]
    126c:      	tbz	w12, #0x7, 0x10f4 <_llm_rows.packet_batch.blocks+0xd44>
    1270:      	add	x11, x11, #0x1c
    1274:      	st1.s	{ v4 }[3], [x11]
    1278:      	b	0x10f4 <_llm_rows.packet_batch.blocks+0xd44>
    127c:      	mov	x8, #0x0                ; =0
    1280:      	dup.4s	v3, v3[0]
    1284:      	ldr	x9, [sp, #0x48]
    1288:      	add	x9, x13, x9
    128c:      	b	0x129c <_llm_rows.packet_batch.blocks+0xeec>
    1290:      	add	x8, x8, #0x20
    1294:      	cmp	x8, #0xc00
    1298:      	b.eq	0x450 <_llm_rows.packet_batch.blocks+0xa0>
    129c:      	fmov	w11, s2
    12a0:      	add	x12, x28, x8
    12a4:      	ldr	q4, [x12]
    12a8:      	and.16b	v4, v1, v4
    12ac:      	fdiv.4s	v4, v4, v3
    12b0:      	add	x13, x21, x8
    12b4:      	ldr	q5, [x13]
    12b8:      	and.16b	v5, v1, v5
    12bc:      	fmul.4s	v5, v4, v5
    12c0:      	add	x10, x23, x8
    12c4:      	ldp	q6, q4, [x10]
    12c8:      	and.16b	v6, v1, v6
    12cc:      	fadd.4s	v5, v5, v6
    12d0:      	add	x10, x9, x8
    12d4:      	tbnz	w11, #0x0, 0x1324 <_llm_rows.packet_batch.blocks+0xf74>
    12d8:      	and	w11, w11, #0xff
    12dc:      	ldr	q7, [x12, #0x10]
    12e0:      	ldr	q6, [x13, #0x10]
    12e4:      	tbnz	w11, #0x1, 0x1338 <_llm_rows.packet_batch.blocks+0xf88>
    12e8:      	tbnz	w11, #0x2, 0x1344 <_llm_rows.packet_batch.blocks+0xf94>
    12ec:      	tbz	w11, #0x3, 0x12f8 <_llm_rows.packet_batch.blocks+0xf48>
    12f0:      	add	x12, x10, #0xc
    12f4:      	st1.s	{ v5 }[3], [x12]
    12f8:      	and.16b	v5, v0, v7
    12fc:      	fdiv.4s	v5, v5, v3
    1300:      	and.16b	v6, v0, v6
    1304:      	fmul.4s	v5, v5, v6
    1308:      	and.16b	v4, v0, v4
    130c:      	fadd.4s	v4, v5, v4
    1310:      	tbnz	w11, #0x4, 0x1354 <_llm_rows.packet_batch.blocks+0xfa4>
    1314:      	tbnz	w11, #0x5, 0x135c <_llm_rows.packet_batch.blocks+0xfac>
    1318:      	tbnz	w11, #0x6, 0x1368 <_llm_rows.packet_batch.blocks+0xfb8>
    131c:      	tbz	w11, #0x7, 0x1290 <_llm_rows.packet_batch.blocks+0xee0>
    1320:      	b	0x1374 <_llm_rows.packet_batch.blocks+0xfc4>
    1324:      	str	s5, [x10]
    1328:      	and	w11, w11, #0xff
    132c:      	ldr	q7, [x12, #0x10]
    1330:      	ldr	q6, [x13, #0x10]
    1334:      	tbz	w11, #0x1, 0x12e8 <_llm_rows.packet_batch.blocks+0xf38>
    1338:      	add	x12, x10, #0x4
    133c:      	st1.s	{ v5 }[1], [x12]
    1340:      	tbz	w11, #0x2, 0x12ec <_llm_rows.packet_batch.blocks+0xf3c>
    1344:      	add	x12, x10, #0x8
    1348:      	st1.s	{ v5 }[2], [x12]
    134c:      	tbnz	w11, #0x3, 0x12f0 <_llm_rows.packet_batch.blocks+0xf40>
    1350:      	b	0x12f8 <_llm_rows.packet_batch.blocks+0xf48>
    1354:      	str	s4, [x10, #0x10]
    1358:      	tbz	w11, #0x5, 0x1318 <_llm_rows.packet_batch.blocks+0xf68>
    135c:      	add	x12, x10, #0x14
    1360:      	st1.s	{ v4 }[1], [x12]
    1364:      	tbz	w11, #0x6, 0x131c <_llm_rows.packet_batch.blocks+0xf6c>
    1368:      	add	x12, x10, #0x18
    136c:      	st1.s	{ v4 }[2], [x12]
    1370:      	tbz	w11, #0x7, 0x1290 <_llm_rows.packet_batch.blocks+0xee0>
    1374:      	add	x10, x10, #0x1c
    1378:      	st1.s	{ v4 }[3], [x10]
    137c:      	b	0x1290 <_llm_rows.packet_batch.blocks+0xee0>
    1380:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    1384:      	add	sp, sp, #0x470
    1388:      	ldp	x29, x30, [sp, #0x60]
    138c:      	ldp	x20, x19, [sp, #0x50]
    1390:      	ldp	x22, x21, [sp, #0x40]
    1394:      	ldp	x24, x23, [sp, #0x30]
    1398:      	ldp	x26, x25, [sp, #0x20]
    139c:      	ldp	x28, x27, [sp, #0x10]
    13a0:      	ldp	d9, d8, [sp], #0x70
    13a4:      	ret

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 16416
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 49248
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 513, i64 1026, i64 1539, i64 2052, i64 2565, i64 3078, i64 3591>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 53352
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 69768
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill17 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill17, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill18 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill18, align 1
  %tile_snapshot.spill19 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill19, align 64
  %.slot20 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot20, align 64
  %.spill21 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill21, align 64
  %tile_snapshot.spill22 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill22, align 64
  %.slot23 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot23, align 64
  %.spill24 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill24, align 4
  %tile_snapshot.spill25 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill25, align 64
  %.slot26 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot26, align 64
  %.spill27 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill27, align 4
  %.slot28 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot28, align 64
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.slot30 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot30, align 32
  %.slot31 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot31, align 32
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.spill34 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill34, align 32
  %.spill35 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill35, align 32
  %.spill36 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill36, align 32
  %.spill37 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill37, align 4
  %.spill38 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill38, align 4
  %tile_snapshot.spill39 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill39, align 64
  %.slot40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot40, align 64
  %.slot41 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot41, align 64
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot46, align 32
  %.spill47 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill47, align 4
  %.slot48 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot48, align 64
  %15 = getelementptr i8, ptr %argument_buffer, i64 0
  %16 = load ptr, ptr %15, align 16
  %17 = getelementptr i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = insertvalue { ptr, i64 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i64 } %19, i64 %18, 1
  %21 = getelementptr i8, ptr %argument_buffer, i64 16
  %22 = load ptr, ptr %21, align 16
  %23 = getelementptr i8, ptr %21, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = insertvalue { ptr, i64 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i64 } %25, i64 %24, 1
  %27 = getelementptr i8, ptr %argument_buffer, i64 32
  %28 = load ptr, ptr %27, align 16
  %29 = getelementptr i8, ptr %27, i64 8
  %30 = load i64, ptr %29, align 8
  %31 = insertvalue { ptr, i64 } poison, ptr %28, 0
  %32 = insertvalue { ptr, i64 } %31, i64 %30, 1
  %33 = getelementptr i8, ptr %argument_buffer, i64 48
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = load i32, ptr %launch_config, align 4
  %40 = getelementptr i8, ptr %launch_config, i64 12
  %41 = load i32, ptr %40, align 4
  %42 = getelementptr i8, ptr %launch_config, i64 4
  %43 = load i32, ptr %42, align 4
  %44 = getelementptr i8, ptr %launch_config, i64 16
  %45 = load i32, ptr %44, align 4
  %46 = getelementptr i8, ptr %launch_config, i64 8
  %47 = load i32, ptr %46, align 4
  %48 = getelementptr i8, ptr %launch_config, i64 20
  %49 = load i32, ptr %48, align 4
  %50 = getelementptr i8, ptr %launch_config, i64 36
  %51 = load i32, ptr %50, align 4
  %.splatinsert49 = insertelement <8 x i32> poison, i32 %51, i64 0
  %.splat50 = shufflevector <8 x i32> %.splatinsert49, <8 x i32> poison, <8 x i32> zeroinitializer
  %52 = add <8 x i32> %.splat50, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %53 = mul i32 %39, 32
  %.splatinsert51 = insertelement <8 x i32> poison, i32 %53, i64 0
  %.splat52 = shufflevector <8 x i32> %.splatinsert51, <8 x i32> poison, <8 x i32> zeroinitializer
  %54 = add <8 x i32> %.splat52, %52
  %55 = mul i32 %43, 1
  %.splatinsert53 = insertelement <8 x i32> poison, i32 %55, i64 0
  %.splat54 = shufflevector <8 x i32> %.splatinsert53, <8 x i32> poison, <8 x i32> zeroinitializer
  %56 = add <8 x i32> %.splat54, zeroinitializer
  %57 = mul i32 %47, 1
  %.splatinsert55 = insertelement <8 x i32> poison, i32 %57, i64 0
  %.splat56 = shufflevector <8 x i32> %.splatinsert55, <8 x i32> poison, <8 x i32> zeroinitializer
  %58 = add <8 x i32> %.splat56, zeroinitializer
  %59 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %54, 0
  %60 = insertvalue [3 x <8 x i32>] %59, <8 x i32> %56, 1
  %61 = insertvalue [3 x <8 x i32>] %60, <8 x i32> %58, 2
  %.splatinsert57 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat58 = shufflevector <8 x i32> %.splatinsert57, <8 x i32> poison, <8 x i32> zeroinitializer
  %62 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat58
  %63 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  br i1 %63, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %64 = extractvalue [3 x <8 x i32>] %61, 0
  %65 = load <8 x i64>, ptr %.spill, align 64
  %66 = select <8 x i1> %62, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %65
  store <8 x i64> %66, ptr %.spill, align 64
  %67 = sub <8 x i32> %64, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %68 = select <8 x i1> %62, <8 x i32> %67, <8 x i32> zeroinitializer
  %69 = select <8 x i1> %62, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %70 = lshr <8 x i32> %68, %69
  %71 = zext <8 x i32> %70 to <8 x i64>
  %72 = select <8 x i1> %62, <8 x i64> %71, <8 x i64> zeroinitializer
  %73 = select <8 x i1> %62, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %74 = sdiv <8 x i64> %72, %73
  %75 = load <8 x i64>, ptr %.spill17, align 64
  %76 = select <8 x i1> %62, <8 x i64> %74, <8 x i64> %75
  store <8 x i64> %76, ptr %.spill17, align 64
  %77 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %78 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %79 = extractvalue { <8 x ptr>, <8 x i64> } %77, 0
  %80 = select <8 x i1> %62, <8 x ptr> %78, <8 x ptr> %79
  %81 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %82 = extractvalue { <8 x ptr>, <8 x i64> } %77, 1
  %83 = select <8 x i1> %62, <8 x i64> %81, <8 x i64> %82
  %84 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %80, 0
  %85 = insertvalue { <8 x ptr>, <8 x i64> } %84, <8 x i64> %83, 1
  store { <8 x ptr>, <8 x i64> } %85, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %86 = icmp slt i64 %.state, 512
  br i1 %86, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state59 = load i64, ptr %.slot, align 4
  %87 = mul i64 %.state59, 8
  %.splatinsert60 = insertelement <8 x i64> poison, i64 %87, i64 0
  %.splat61 = shufflevector <8 x i64> %.splatinsert60, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %88 = add <8 x i64> %.splat61, %.spill.load
  %.spill.load62 = load <8 x i64>, ptr %.spill17, align 64
  %89 = add <8 x i64> %.spill.load62, zeroinitializer
  %90 = add <8 x i64> zeroinitializer, %89
  %91 = add <8 x i64> zeroinitializer, %88
  %92 = mul <8 x i64> %90, splat (i64 4097)
  %93 = add <8 x i64> %92, %91
  %94 = extractvalue { ptr, i64 } %20, 0
  %95 = extractelement <8 x i64> %93, i32 0
  %96 = sub i64 %95, 0
  %97 = mul i64 %96, 4
  %buffer.contiguous.address = getelementptr i8, ptr %94, i64 %97
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %62, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state63 = load i64, ptr %.slot, align 4
  %.splatinsert64 = insertelement <8 x i64> poison, i64 %.state63, i64 0
  %.splat65 = shufflevector <8 x i64> %.splatinsert64, <8 x i64> poison, <8 x i32> zeroinitializer
  %100 = mul <8 x i64> %.splat65, splat (i64 32)
  %101 = add <8 x i64> %99, %100
  %102 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %98, 0
  %103 = insertvalue { <8 x ptr>, <8 x i64> } %102, <8 x i64> %101, 1
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %105 = extractvalue { <8 x ptr>, <8 x i64> } %103, 1
  %106 = extractelement <8 x ptr> %104, i32 0
  %107 = extractelement <8 x i64> %105, i32 0
  %108 = sub i64 %107, 0
  %109 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %110 = select i1 %109, i64 %108, i64 0
  %private.contiguous.address = getelementptr i8, ptr %106, i64 %110
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %111 = select <8 x i1> %62, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %111, ptr %private.contiguous.address, align 4
  %.state66 = load i64, ptr %.slot, align 4
  %112 = add i64 %.state66, 1
  store i64 %112, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load67 = load <8 x i64>, ptr %.spill, align 64
  %113 = icmp slt <8 x i64> %.spill.load67, splat (i64 1)
  %114 = load <8 x i1>, ptr %.spill18, align 1
  %115 = select <8 x i1> %62, <8 x i1> %113, <8 x i1> %114
  store <8 x i1> %115, ptr %.spill18, align 1
  %116 = and <8 x i1> %62, %113
  %117 = xor <8 x i1> %113, splat (i1 true)
  %118 = and <8 x i1> %62, %117
  %119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  %120 = bitcast <8 x i1> %116 to i8
  %121 = call i8 @llvm.cttz.i8(i8 %120, i1 false)
  %122 = zext i8 %121 to i32
  %123 = select i1 %119, i32 %122, i32 0
  %.spill.load68 = load <8 x i64>, ptr %.spill, align 64
  %124 = add <8 x i64> splat (i64 4096), %.spill.load68
  %.spill.load69 = load <8 x i64>, ptr %.spill17, align 64
  %125 = add <8 x i64> %.spill.load69, zeroinitializer
  %126 = add <8 x i64> zeroinitializer, %125
  %127 = add <8 x i64> zeroinitializer, %124
  %128 = mul <8 x i64> %126, splat (i64 4097)
  %129 = add <8 x i64> %128, %127
  %130 = extractvalue { ptr, i64 } %20, 0
  %131 = select <8 x i1> %116, <8 x i64> %129, <8 x i64> zeroinitializer
  %132 = extractelement <8 x i64> %131, i32 %123
  %133 = zext i32 %123 to i64
  %134 = sub i64 %132, %133
  %135 = mul i64 %134, 4
  %buffer.contiguous.address70 = getelementptr i8, ptr %130, i64 %135
  %buffer.contiguous.load71 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address70, i32 1, <8 x i1> %116, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load72 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load72, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load72, 1
  %138 = add <8 x i64> %137, splat (i64 16384)
  %139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %140 = insertvalue { <8 x ptr>, <8 x i64> } %139, <8 x i64> %138, 1
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %140, 1
  %143 = extractelement <8 x ptr> %141, i32 0
  %144 = extractelement <8 x i64> %142, i32 %123
  %145 = zext i32 %123 to i64
  %146 = mul i64 %145, 4
  %147 = sub i64 %144, %146
  %148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  %149 = select i1 %148, i64 %147, i64 0
  %private.contiguous.address73 = getelementptr i8, ptr %143, i64 %149
  %private.contiguous.preserve74 = load <8 x float>, ptr %private.contiguous.address73, align 4
  %150 = select <8 x i1> %116, <8 x float> %buffer.contiguous.load71, <8 x float> %private.contiguous.preserve74
  store <8 x float> %150, ptr %private.contiguous.address73, align 4
  %151 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %118)
  %152 = bitcast <8 x i1> %118 to i8
  %153 = call i8 @llvm.cttz.i8(i8 %152, i1 false)
  %154 = zext i8 %153 to i32
  %155 = select i1 %151, i32 %154, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  %156 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %156, 0
  %159 = select <8 x i1> %62, <8 x ptr> %157, <8 x ptr> %158
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %156, 1
  %162 = select <8 x i1> %62, <8 x i64> %160, <8 x i64> %161
  %163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %159, 0
  %164 = insertvalue { <8 x ptr>, <8 x i64> } %163, <8 x i64> %162, 1
  store { <8 x ptr>, <8 x i64> } %164, ptr %tile_snapshot.spill19, align 64
  %165 = load <8 x i64>, ptr %.slot20, align 64
  %166 = select <8 x i1> %62, <8 x i64> zeroinitializer, <8 x i64> %165
  store <8 x i64> %166, ptr %.slot20, align 64
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state75 = load <8 x i64>, ptr %.slot20, align 64
  %167 = icmp slt <8 x i64> %.state75, splat (i64 512)
  %168 = extractelement <8 x i1> %167, i32 0
  br i1 %168, label %direct.true76, label %direct.false77

direct.schedule.7:                                ; preds = %direct.true76
  %.state78 = load <8 x i64>, ptr %.slot20, align 64
  %169 = mul <8 x i64> %.state78, splat (i64 8)
  %.spill.load79 = load <8 x i64>, ptr %.spill, align 64
  %170 = add <8 x i64> %169, %.spill.load79
  %tile_snapshot.spill.load80 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 0
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 1
  %.state81 = load <8 x i64>, ptr %.slot20, align 64
  %173 = mul <8 x i64> %.state81, splat (i64 64)
  %174 = add <8 x i64> %172, %173
  %175 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %171, 0
  %176 = insertvalue { <8 x ptr>, <8 x i64> } %175, <8 x i64> %174, 1
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %176, 1
  %179 = extractelement <8 x ptr> %177, i32 0
  %180 = extractelement <8 x i64> %178, i32 0
  %181 = sub i64 %180, 0
  %182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %183 = select i1 %182, i64 %181, i64 0
  %private.contiguous.address82 = getelementptr i8, ptr %179, i64 %183
  %private.contiguous.preserve83 = load <8 x i64>, ptr %private.contiguous.address82, align 8
  %184 = select <8 x i1> %62, <8 x i64> %170, <8 x i64> %private.contiguous.preserve83
  store <8 x i64> %184, ptr %private.contiguous.address82, align 8
  %.state84 = load <8 x i64>, ptr %.slot20, align 64
  %185 = add <8 x i64> %.state84, splat (i64 1)
  %186 = load <8 x i64>, ptr %.slot20, align 64
  %187 = select <8 x i1> %62, <8 x i64> %185, <8 x i64> %186
  store <8 x i64> %187, ptr %.slot20, align 64
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false77
  %.spill.load85 = load <8 x i1>, ptr %.spill18, align 1
  %188 = and <8 x i1> %62, %.spill.load85
  %189 = xor <8 x i1> %.spill.load85, splat (i1 true)
  %190 = and <8 x i1> %62, %189
  %191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %188)
  %192 = bitcast <8 x i1> %188 to i8
  %193 = call i8 @llvm.cttz.i8(i8 %192, i1 false)
  %194 = zext i8 %193 to i32
  %195 = select i1 %191, i32 %194, i32 0
  %.spill.load86 = load <8 x i64>, ptr %.spill, align 64
  %196 = add <8 x i64> splat (i64 4096), %.spill.load86
  %tile_snapshot.spill.load87 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %197 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 0
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 1
  %199 = add <8 x i64> %198, splat (i64 32768)
  %200 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %197, 0
  %201 = insertvalue { <8 x ptr>, <8 x i64> } %200, <8 x i64> %199, 1
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %201, 1
  %204 = extractelement <8 x ptr> %202, i32 0
  %205 = extractelement <8 x i64> %203, i32 %195
  %206 = zext i32 %195 to i64
  %207 = mul i64 %206, 8
  %208 = sub i64 %205, %207
  %209 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %188)
  %210 = select i1 %209, i64 %208, i64 0
  %private.contiguous.address88 = getelementptr i8, ptr %204, i64 %210
  %private.contiguous.preserve89 = load <8 x i64>, ptr %private.contiguous.address88, align 8
  %211 = select <8 x i1> %188, <8 x i64> %196, <8 x i64> %private.contiguous.preserve89
  store <8 x i64> %211, ptr %private.contiguous.address88, align 8
  %212 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %190)
  %213 = bitcast <8 x i1> %190 to i8
  %214 = call i8 @llvm.cttz.i8(i8 %213, i1 false)
  %215 = zext i8 %214 to i32
  %216 = select i1 %212, i32 %215, i32 0
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %.spill.load90 = load <8 x i64>, ptr %.spill17, align 64
  %217 = select <8 x i1> %62, <8 x i64> %.spill.load90, <8 x i64> zeroinitializer
  %218 = select <8 x i1> %62, <8 x i64> splat (i64 4097), <8 x i64> splat (i64 1)
  %219 = srem <8 x i64> %217, %218
  %220 = load <8 x i64>, ptr %.spill21, align 64
  %221 = select <8 x i1> %62, <8 x i64> %219, <8 x i64> %220
  store <8 x i64> %221, ptr %.spill21, align 64
  %222 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %222, 0
  %225 = select <8 x i1> %62, <8 x ptr> %223, <8 x ptr> %224
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %222, 1
  %228 = select <8 x i1> %62, <8 x i64> %226, <8 x i64> %227
  %229 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %225, 0
  %230 = insertvalue { <8 x ptr>, <8 x i64> } %229, <8 x i64> %228, 1
  store { <8 x ptr>, <8 x i64> } %230, ptr %tile_snapshot.spill22, align 64
  %231 = load <8 x i64>, ptr %.slot23, align 64
  %232 = select <8 x i1> %62, <8 x i64> zeroinitializer, <8 x i64> %231
  store <8 x i64> %232, ptr %.slot23, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state91 = load <8 x i64>, ptr %.slot23, align 64
  %233 = icmp slt <8 x i64> %.state91, splat (i64 512)
  %234 = extractelement <8 x i1> %233, i32 0
  br i1 %234, label %direct.true92, label %direct.false93

direct.schedule.12:                               ; preds = %direct.true92
  %tile_snapshot.spill.load94 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 0
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 1
  %.state95 = load <8 x i64>, ptr %.slot23, align 64
  %237 = mul <8 x i64> %.state95, splat (i64 64)
  %238 = add <8 x i64> %236, %237
  %239 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %235, 0
  %240 = insertvalue { <8 x ptr>, <8 x i64> } %239, <8 x i64> %238, 1
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %242 = extractvalue { <8 x ptr>, <8 x i64> } %240, 1
  %243 = extractelement <8 x ptr> %241, i32 0
  %244 = extractelement <8 x i64> %242, i32 0
  %245 = sub i64 %244, 0
  %246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %247 = select i1 %246, i64 %245, i64 0
  %private.contiguous.address96 = getelementptr i8, ptr %243, i64 %247
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address96, align 8
  %248 = select <8 x i1> %62, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load97 = load <8 x i64>, ptr %.spill21, align 64
  %249 = icmp sle <8 x i64> %248, %.spill.load97
  %tile_snapshot.spill.load98 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %250 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 0
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 1
  %.state99 = load <8 x i64>, ptr %.slot23, align 64
  %252 = add <8 x i64> %251, %.state99
  %253 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %250, 0
  %254 = insertvalue { <8 x ptr>, <8 x i64> } %253, <8 x i64> %252, 1
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %254, 0
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %254, 1
  %257 = getelementptr i8, <8 x ptr> %255, <8 x i64> %256
  %258 = zext <8 x i1> %249 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %258, <8 x ptr> %257, i32 1, <8 x i1> %62)
  %.state100 = load <8 x i64>, ptr %.slot23, align 64
  %259 = add <8 x i64> %.state100, splat (i64 1)
  %260 = load <8 x i64>, ptr %.slot23, align 64
  %261 = select <8 x i1> %62, <8 x i64> %259, <8 x i64> %260
  store <8 x i64> %261, ptr %.slot23, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false93
  %.spill.load101 = load <8 x i1>, ptr %.spill18, align 1
  %262 = and <8 x i1> %62, %.spill.load101
  %263 = xor <8 x i1> %.spill.load101, splat (i1 true)
  %264 = and <8 x i1> %62, %263
  %265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %262)
  %266 = bitcast <8 x i1> %262 to i8
  %267 = call i8 @llvm.cttz.i8(i8 %266, i1 false)
  %268 = zext i8 %267 to i32
  %269 = select i1 %265, i32 %268, i32 0
  %tile_snapshot.spill.load102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 0
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 1
  %272 = add <8 x i64> %271, splat (i64 32768)
  %273 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %270, 0
  %274 = insertvalue { <8 x ptr>, <8 x i64> } %273, <8 x i64> %272, 1
  %275 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %274, 1
  %277 = extractelement <8 x ptr> %275, i32 0
  %278 = extractelement <8 x i64> %276, i32 %269
  %279 = zext i32 %269 to i64
  %280 = mul i64 %279, 8
  %281 = sub i64 %278, %280
  %282 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %262)
  %283 = select i1 %282, i64 %281, i64 0
  %private.contiguous.address103 = getelementptr i8, ptr %277, i64 %283
  %private.contiguous.load104 = load <8 x i64>, ptr %private.contiguous.address103, align 8
  %284 = select <8 x i1> %262, <8 x i64> %private.contiguous.load104, <8 x i64> zeroinitializer
  %.spill.load105 = load <8 x i64>, ptr %.spill21, align 64
  %285 = icmp sle <8 x i64> %284, %.spill.load105
  %tile_snapshot.spill.load106 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 1
  %288 = add <8 x i64> %287, splat (i64 512)
  %289 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %286, 0
  %290 = insertvalue { <8 x ptr>, <8 x i64> } %289, <8 x i64> %288, 1
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %290, 0
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %290, 1
  %293 = getelementptr i8, <8 x ptr> %291, <8 x i64> %292
  %294 = zext <8 x i1> %285 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %294, <8 x ptr> %293, i32 1, <8 x i1> %262)
  %295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %264)
  %296 = bitcast <8 x i1> %264 to i8
  %297 = call i8 @llvm.cttz.i8(i8 %296, i1 false)
  %298 = zext i8 %297 to i32
  %299 = select i1 %295, i32 %298, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  store float 0xC6293E5940000000, ptr %.spill24, align 4
  %300 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %302 = extractvalue { <8 x ptr>, <8 x i64> } %300, 0
  %303 = select <8 x i1> %62, <8 x ptr> %301, <8 x ptr> %302
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %300, 1
  %306 = select <8 x i1> %62, <8 x i64> %304, <8 x i64> %305
  %307 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %303, 0
  %308 = insertvalue { <8 x ptr>, <8 x i64> } %307, <8 x i64> %306, 1
  store { <8 x ptr>, <8 x i64> } %308, ptr %tile_snapshot.spill25, align 64
  %309 = load <8 x i64>, ptr %.slot26, align 64
  %310 = select <8 x i1> %62, <8 x i64> zeroinitializer, <8 x i64> %309
  store <8 x i64> %310, ptr %.slot26, align 64
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state107 = load <8 x i64>, ptr %.slot26, align 64
  %311 = icmp slt <8 x i64> %.state107, splat (i64 512)
  %312 = extractelement <8 x i1> %311, i32 0
  br i1 %312, label %direct.true108, label %direct.false109

direct.schedule.17:                               ; preds = %direct.true108
  %tile_snapshot.spill.load110 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load110, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load110, 1
  %.state111 = load <8 x i64>, ptr %.slot26, align 64
  %315 = add <8 x i64> %314, %.state111
  %316 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %313, 0
  %317 = insertvalue { <8 x ptr>, <8 x i64> } %316, <8 x i64> %315, 1
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %317, 0
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %317, 1
  %320 = getelementptr i8, <8 x ptr> %318, <8 x i64> %319
  %321 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %320, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %322 = icmp ne <8 x i8> %321, zeroinitializer
  %tile_snapshot.spill.load112 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load112, 0
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load112, 1
  %.state113 = load <8 x i64>, ptr %.slot26, align 64
  %325 = mul <8 x i64> %.state113, splat (i64 32)
  %326 = add <8 x i64> %324, %325
  %327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %323, 0
  %328 = insertvalue { <8 x ptr>, <8 x i64> } %327, <8 x i64> %326, 1
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %328, 1
  %331 = extractelement <8 x ptr> %329, i32 0
  %332 = extractelement <8 x i64> %330, i32 0
  %333 = sub i64 %332, 0
  %334 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %335 = select i1 %334, i64 %333, i64 0
  %private.contiguous.address114 = getelementptr i8, ptr %331, i64 %335
  %private.contiguous.load115 = load <8 x float>, ptr %private.contiguous.address114, align 4
  %336 = select <8 x i1> %62, <8 x float> %private.contiguous.load115, <8 x float> zeroinitializer
  %.spill.load116 = load float, ptr %.spill24, align 4
  %.splatinsert117 = insertelement <8 x float> poison, float %.spill.load116, i64 0
  %.splat118 = shufflevector <8 x float> %.splatinsert117, <8 x float> poison, <8 x i32> zeroinitializer
  %337 = select <8 x i1> %322, <8 x float> %336, <8 x float> %.splat118
  %tile_snapshot.spill.load119 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 1
  %.state120 = load <8 x i64>, ptr %.slot26, align 64
  %340 = mul <8 x i64> %.state120, splat (i64 32)
  %341 = add <8 x i64> %339, %340
  %342 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %338, 0
  %343 = insertvalue { <8 x ptr>, <8 x i64> } %342, <8 x i64> %341, 1
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %343, 1
  %346 = extractelement <8 x ptr> %344, i32 0
  %347 = extractelement <8 x i64> %345, i32 0
  %348 = sub i64 %347, 0
  %349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %350 = select i1 %349, i64 %348, i64 0
  %private.contiguous.address121 = getelementptr i8, ptr %346, i64 %350
  %private.contiguous.preserve122 = load <8 x float>, ptr %private.contiguous.address121, align 4
  %351 = select <8 x i1> %62, <8 x float> %337, <8 x float> %private.contiguous.preserve122
  store <8 x float> %351, ptr %private.contiguous.address121, align 4
  %.state123 = load <8 x i64>, ptr %.slot26, align 64
  %352 = add <8 x i64> %.state123, splat (i64 1)
  %353 = load <8 x i64>, ptr %.slot26, align 64
  %354 = select <8 x i1> %62, <8 x i64> %352, <8 x i64> %353
  store <8 x i64> %354, ptr %.slot26, align 64
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false109
  %.spill.load124 = load <8 x i1>, ptr %.spill18, align 1
  %355 = and <8 x i1> %62, %.spill.load124
  %356 = xor <8 x i1> %.spill.load124, splat (i1 true)
  %357 = and <8 x i1> %62, %356
  %358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %355)
  %359 = bitcast <8 x i1> %355 to i8
  %360 = call i8 @llvm.cttz.i8(i8 %359, i1 false)
  %361 = zext i8 %360 to i32
  %362 = select i1 %358, i32 %361, i32 0
  %tile_snapshot.spill.load125 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 1
  %365 = add <8 x i64> %364, splat (i64 512)
  %366 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %363, 0
  %367 = insertvalue { <8 x ptr>, <8 x i64> } %366, <8 x i64> %365, 1
  %368 = extractvalue { <8 x ptr>, <8 x i64> } %367, 0
  %369 = extractvalue { <8 x ptr>, <8 x i64> } %367, 1
  %370 = getelementptr i8, <8 x ptr> %368, <8 x i64> %369
  %371 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %370, i32 1, <8 x i1> %355, <8 x i8> zeroinitializer)
  %372 = icmp ne <8 x i8> %371, zeroinitializer
  %tile_snapshot.spill.load126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 0
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 1
  %375 = add <8 x i64> %374, splat (i64 16384)
  %376 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %373, 0
  %377 = insertvalue { <8 x ptr>, <8 x i64> } %376, <8 x i64> %375, 1
  %378 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %379 = extractvalue { <8 x ptr>, <8 x i64> } %377, 1
  %380 = extractelement <8 x ptr> %378, i32 0
  %381 = extractelement <8 x i64> %379, i32 %362
  %382 = zext i32 %362 to i64
  %383 = mul i64 %382, 4
  %384 = sub i64 %381, %383
  %385 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %355)
  %386 = select i1 %385, i64 %384, i64 0
  %private.contiguous.address127 = getelementptr i8, ptr %380, i64 %386
  %private.contiguous.load128 = load <8 x float>, ptr %private.contiguous.address127, align 4
  %387 = select <8 x i1> %355, <8 x float> %private.contiguous.load128, <8 x float> zeroinitializer
  %.spill.load129 = load float, ptr %.spill24, align 4
  %.splatinsert130 = insertelement <8 x float> poison, float %.spill.load129, i64 0
  %.splat131 = shufflevector <8 x float> %.splatinsert130, <8 x float> poison, <8 x i32> zeroinitializer
  %388 = select <8 x i1> %372, <8 x float> %387, <8 x float> %.splat131
  %tile_snapshot.spill.load132 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 0
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 1
  %391 = add <8 x i64> %390, splat (i64 16384)
  %392 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %389, 0
  %393 = insertvalue { <8 x ptr>, <8 x i64> } %392, <8 x i64> %391, 1
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %393, 1
  %396 = extractelement <8 x ptr> %394, i32 0
  %397 = extractelement <8 x i64> %395, i32 %362
  %398 = zext i32 %362 to i64
  %399 = mul i64 %398, 4
  %400 = sub i64 %397, %399
  %401 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %355)
  %402 = select i1 %401, i64 %400, i64 0
  %private.contiguous.address133 = getelementptr i8, ptr %396, i64 %402
  %private.contiguous.preserve134 = load <8 x float>, ptr %private.contiguous.address133, align 4
  %403 = select <8 x i1> %355, <8 x float> %388, <8 x float> %private.contiguous.preserve134
  store <8 x float> %403, ptr %private.contiguous.address133, align 4
  %404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %357)
  %405 = bitcast <8 x i1> %357 to i8
  %406 = call i8 @llvm.cttz.i8(i8 %405, i1 false)
  %407 = zext i8 %406 to i32
  %408 = select i1 %404, i32 %407, i32 0
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  store float 0xFFF0000000000000, ptr %.spill27, align 4
  %tile_snapshot.spill.load135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 0
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 1
  %411 = add <8 x i64> %410, zeroinitializer
  %412 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %409, 0
  %413 = insertvalue { <8 x ptr>, <8 x i64> } %412, <8 x i64> %411, 1
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %413, 1
  %416 = extractelement <8 x ptr> %414, i32 0
  %417 = extractelement <8 x i64> %415, i32 0
  %418 = sub i64 %417, 0
  %419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %420 = select i1 %419, i64 %418, i64 0
  %private.contiguous.address136 = getelementptr i8, ptr %416, i64 %420
  %private.contiguous.load137 = load <8 x float>, ptr %private.contiguous.address136, align 4
  %421 = select <8 x i1> %62, <8 x float> %private.contiguous.load137, <8 x float> zeroinitializer
  %tile_snapshot.spill.load138 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 1
  %424 = add <8 x i64> %423, splat (i64 32)
  %425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %422, 0
  %426 = insertvalue { <8 x ptr>, <8 x i64> } %425, <8 x i64> %424, 1
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %426, 1
  %429 = extractelement <8 x ptr> %427, i32 0
  %430 = extractelement <8 x i64> %428, i32 0
  %431 = sub i64 %430, 0
  %432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %433 = select i1 %432, i64 %431, i64 0
  %private.contiguous.address139 = getelementptr i8, ptr %429, i64 %433
  %private.contiguous.load140 = load <8 x float>, ptr %private.contiguous.address139, align 4
  %434 = select <8 x i1> %62, <8 x float> %private.contiguous.load140, <8 x float> zeroinitializer
  %tile_snapshot.spill.load141 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %435 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 0
  %436 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 1
  %437 = add <8 x i64> %436, splat (i64 64)
  %438 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %435, 0
  %439 = insertvalue { <8 x ptr>, <8 x i64> } %438, <8 x i64> %437, 1
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %441 = extractvalue { <8 x ptr>, <8 x i64> } %439, 1
  %442 = extractelement <8 x ptr> %440, i32 0
  %443 = extractelement <8 x i64> %441, i32 0
  %444 = sub i64 %443, 0
  %445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %446 = select i1 %445, i64 %444, i64 0
  %private.contiguous.address142 = getelementptr i8, ptr %442, i64 %446
  %private.contiguous.load143 = load <8 x float>, ptr %private.contiguous.address142, align 4
  %447 = select <8 x i1> %62, <8 x float> %private.contiguous.load143, <8 x float> zeroinitializer
  %tile_snapshot.spill.load144 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 0
  %449 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 1
  %450 = add <8 x i64> %449, splat (i64 96)
  %451 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %448, 0
  %452 = insertvalue { <8 x ptr>, <8 x i64> } %451, <8 x i64> %450, 1
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %454 = extractvalue { <8 x ptr>, <8 x i64> } %452, 1
  %455 = extractelement <8 x ptr> %453, i32 0
  %456 = extractelement <8 x i64> %454, i32 0
  %457 = sub i64 %456, 0
  %458 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %459 = select i1 %458, i64 %457, i64 0
  %private.contiguous.address145 = getelementptr i8, ptr %455, i64 %459
  %private.contiguous.load146 = load <8 x float>, ptr %private.contiguous.address145, align 4
  %460 = select <8 x i1> %62, <8 x float> %private.contiguous.load146, <8 x float> zeroinitializer
  %461 = load <8 x i64>, ptr %.slot28, align 64
  %462 = select <8 x i1> %62, <8 x i64> splat (i64 4), <8 x i64> %461
  store <8 x i64> %462, ptr %.slot28, align 64
  %463 = load <8 x float>, ptr %.slot29, align 32
  %464 = select <8 x i1> %62, <8 x float> %421, <8 x float> %463
  store <8 x float> %464, ptr %.slot29, align 32
  %465 = load <8 x float>, ptr %.slot30, align 32
  %466 = select <8 x i1> %62, <8 x float> %434, <8 x float> %465
  store <8 x float> %466, ptr %.slot30, align 32
  %467 = load <8 x float>, ptr %.slot31, align 32
  %468 = select <8 x i1> %62, <8 x float> %447, <8 x float> %467
  store <8 x float> %468, ptr %.slot31, align 32
  %469 = load <8 x float>, ptr %.slot32, align 32
  %470 = select <8 x i1> %62, <8 x float> %460, <8 x float> %469
  store <8 x float> %470, ptr %.slot32, align 32
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.22, %direct.schedule.20
  %.state147 = load <8 x i64>, ptr %.slot28, align 64
  %471 = icmp slt <8 x i64> %.state147, splat (i64 512)
  %472 = extractelement <8 x i1> %471, i32 0
  br i1 %472, label %direct.true148, label %direct.false149

direct.schedule.22:                               ; preds = %direct.true148
  %.state150 = load <8 x i64>, ptr %.slot28, align 64
  %473 = add <8 x i64> %.state150, zeroinitializer
  %tile_snapshot.spill.load151 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load151, 0
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load151, 1
  %476 = mul <8 x i64> %473, splat (i64 32)
  %477 = add <8 x i64> %475, %476
  %478 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %474, 0
  %479 = insertvalue { <8 x ptr>, <8 x i64> } %478, <8 x i64> %477, 1
  %480 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %479, 1
  %482 = extractelement <8 x ptr> %480, i32 0
  %483 = extractelement <8 x i64> %481, i32 0
  %484 = sub i64 %483, 0
  %485 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %486 = select i1 %485, i64 %484, i64 0
  %private.contiguous.address152 = getelementptr i8, ptr %482, i64 %486
  %private.contiguous.load153 = load <8 x float>, ptr %private.contiguous.address152, align 4
  %487 = select <8 x i1> %62, <8 x float> %private.contiguous.load153, <8 x float> zeroinitializer
  %.state154 = load <8 x float>, ptr %.slot29, align 32
  %488 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state154, <8 x float> %487)
  %.state155 = load <8 x i64>, ptr %.slot28, align 64
  %489 = add <8 x i64> %.state155, splat (i64 1)
  %tile_snapshot.spill.load156 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load156, 0
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load156, 1
  %492 = mul <8 x i64> %489, splat (i64 32)
  %493 = add <8 x i64> %491, %492
  %494 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %490, 0
  %495 = insertvalue { <8 x ptr>, <8 x i64> } %494, <8 x i64> %493, 1
  %496 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %497 = extractvalue { <8 x ptr>, <8 x i64> } %495, 1
  %498 = extractelement <8 x ptr> %496, i32 0
  %499 = extractelement <8 x i64> %497, i32 0
  %500 = sub i64 %499, 0
  %501 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %502 = select i1 %501, i64 %500, i64 0
  %private.contiguous.address157 = getelementptr i8, ptr %498, i64 %502
  %private.contiguous.load158 = load <8 x float>, ptr %private.contiguous.address157, align 4
  %503 = select <8 x i1> %62, <8 x float> %private.contiguous.load158, <8 x float> zeroinitializer
  %.state159 = load <8 x float>, ptr %.slot30, align 32
  %504 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state159, <8 x float> %503)
  %.state160 = load <8 x i64>, ptr %.slot28, align 64
  %505 = add <8 x i64> %.state160, splat (i64 2)
  %tile_snapshot.spill.load161 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 0
  %507 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 1
  %508 = mul <8 x i64> %505, splat (i64 32)
  %509 = add <8 x i64> %507, %508
  %510 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %506, 0
  %511 = insertvalue { <8 x ptr>, <8 x i64> } %510, <8 x i64> %509, 1
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %511, 1
  %514 = extractelement <8 x ptr> %512, i32 0
  %515 = extractelement <8 x i64> %513, i32 0
  %516 = sub i64 %515, 0
  %517 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %518 = select i1 %517, i64 %516, i64 0
  %private.contiguous.address162 = getelementptr i8, ptr %514, i64 %518
  %private.contiguous.load163 = load <8 x float>, ptr %private.contiguous.address162, align 4
  %519 = select <8 x i1> %62, <8 x float> %private.contiguous.load163, <8 x float> zeroinitializer
  %.state164 = load <8 x float>, ptr %.slot31, align 32
  %520 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state164, <8 x float> %519)
  %.state165 = load <8 x i64>, ptr %.slot28, align 64
  %521 = add <8 x i64> %.state165, splat (i64 3)
  %tile_snapshot.spill.load166 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %522 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load166, 0
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load166, 1
  %524 = mul <8 x i64> %521, splat (i64 32)
  %525 = add <8 x i64> %523, %524
  %526 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %522, 0
  %527 = insertvalue { <8 x ptr>, <8 x i64> } %526, <8 x i64> %525, 1
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %527, 1
  %530 = extractelement <8 x ptr> %528, i32 0
  %531 = extractelement <8 x i64> %529, i32 0
  %532 = sub i64 %531, 0
  %533 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %534 = select i1 %533, i64 %532, i64 0
  %private.contiguous.address167 = getelementptr i8, ptr %530, i64 %534
  %private.contiguous.load168 = load <8 x float>, ptr %private.contiguous.address167, align 4
  %535 = select <8 x i1> %62, <8 x float> %private.contiguous.load168, <8 x float> zeroinitializer
  %.state169 = load <8 x float>, ptr %.slot32, align 32
  %536 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state169, <8 x float> %535)
  %.state170 = load <8 x i64>, ptr %.slot28, align 64
  %537 = add <8 x i64> %.state170, splat (i64 4)
  %538 = load <8 x i64>, ptr %.slot28, align 64
  %539 = select <8 x i1> %62, <8 x i64> %537, <8 x i64> %538
  store <8 x i64> %539, ptr %.slot28, align 64
  %540 = load <8 x float>, ptr %.slot29, align 32
  %541 = select <8 x i1> %62, <8 x float> %488, <8 x float> %540
  store <8 x float> %541, ptr %.slot29, align 32
  %542 = load <8 x float>, ptr %.slot30, align 32
  %543 = select <8 x i1> %62, <8 x float> %504, <8 x float> %542
  store <8 x float> %543, ptr %.slot30, align 32
  %544 = load <8 x float>, ptr %.slot31, align 32
  %545 = select <8 x i1> %62, <8 x float> %520, <8 x float> %544
  store <8 x float> %545, ptr %.slot31, align 32
  %546 = load <8 x float>, ptr %.slot32, align 32
  %547 = select <8 x i1> %62, <8 x float> %536, <8 x float> %546
  store <8 x float> %547, ptr %.slot32, align 32
  br label %direct.schedule.21

direct.schedule.23:                               ; preds = %direct.false149
  %.spill.load171 = load <8 x i1>, ptr %.spill18, align 1
  %548 = and <8 x i1> %62, %.spill.load171
  %549 = xor <8 x i1> %.spill.load171, splat (i1 true)
  %550 = and <8 x i1> %62, %549
  %551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %548)
  %552 = bitcast <8 x i1> %548 to i8
  %553 = call i8 @llvm.cttz.i8(i8 %552, i1 false)
  %554 = zext i8 %553 to i32
  %555 = select i1 %551, i32 %554, i32 0
  %tile_snapshot.spill.load172 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %556 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load172, 0
  %557 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load172, 1
  %558 = add <8 x i64> %557, splat (i64 16384)
  %559 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %556, 0
  %560 = insertvalue { <8 x ptr>, <8 x i64> } %559, <8 x i64> %558, 1
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %562 = extractvalue { <8 x ptr>, <8 x i64> } %560, 1
  %563 = extractelement <8 x ptr> %561, i32 0
  %564 = extractelement <8 x i64> %562, i32 %555
  %565 = zext i32 %555 to i64
  %566 = mul i64 %565, 4
  %567 = sub i64 %564, %566
  %568 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %548)
  %569 = select i1 %568, i64 %567, i64 0
  %private.contiguous.address173 = getelementptr i8, ptr %563, i64 %569
  %private.contiguous.load174 = load <8 x float>, ptr %private.contiguous.address173, align 4
  %570 = select <8 x i1> %548, <8 x float> %private.contiguous.load174, <8 x float> zeroinitializer
  %.state175 = load <8 x float>, ptr %.slot29, align 32
  %571 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state175, <8 x float> %570)
  %572 = load <8 x float>, ptr %.slot33, align 32
  %573 = select <8 x i1> %548, <8 x float> %571, <8 x float> %572
  store <8 x float> %573, ptr %.slot33, align 32
  %574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %550)
  %575 = bitcast <8 x i1> %550 to i8
  %576 = call i8 @llvm.cttz.i8(i8 %575, i1 false)
  %577 = zext i8 %576 to i32
  %578 = select i1 %574, i32 %577, i32 0
  %.state176 = load <8 x float>, ptr %.slot29, align 32
  %579 = load <8 x float>, ptr %.slot33, align 32
  %580 = select <8 x i1> %550, <8 x float> %.state176, <8 x float> %579
  store <8 x float> %580, ptr %.slot33, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.23
  %.state177 = load <8 x float>, ptr %.slot33, align 32
  %.state178 = load <8 x float>, ptr %.slot30, align 32
  %581 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state177, <8 x float> %.state178)
  %.state179 = load <8 x float>, ptr %.slot31, align 32
  %582 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %581, <8 x float> %.state179)
  %.state180 = load <8 x float>, ptr %.slot32, align 32
  %583 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %582, <8 x float> %.state180)
  %.spill.load181 = load <8 x i64>, ptr %.spill, align 64
  %584 = trunc <8 x i64> %.spill.load181 to <8 x i32>
  %585 = xor <8 x i32> %584, splat (i32 1)
  %586 = load <8 x i32>, ptr %.spill34, align 32
  %587 = select <8 x i1> %62, <8 x i32> %585, <8 x i32> %586
  store <8 x i32> %587, ptr %.spill34, align 32
  %588 = extractelement <8 x i32> %585, i64 0
  %589 = icmp ult i32 %588, 8
  %590 = select i1 %589, i32 %588, i32 0
  %591 = extractelement <8 x i1> %62, i32 %590
  %592 = extractelement <8 x i1> %62, i64 0
  %593 = and i1 %589, %591
  %594 = and i1 %592, %593
  %595 = extractelement <8 x float> %583, i32 %590
  %596 = select i1 %594, float %595, float 0.000000e+00
  %597 = insertelement <8 x float> poison, float %596, i64 0
  %598 = xor i1 %594, true
  %599 = and i1 %592, %598
  %600 = insertelement <8 x i1> poison, i1 %599, i64 0
  %601 = extractelement <8 x i32> %585, i64 1
  %602 = icmp ult i32 %601, 8
  %603 = select i1 %602, i32 %601, i32 0
  %604 = extractelement <8 x i1> %62, i32 %603
  %605 = extractelement <8 x i1> %62, i64 1
  %606 = and i1 %602, %604
  %607 = and i1 %605, %606
  %608 = extractelement <8 x float> %583, i32 %603
  %609 = select i1 %607, float %608, float 0.000000e+00
  %610 = insertelement <8 x float> %597, float %609, i64 1
  %611 = xor i1 %607, true
  %612 = and i1 %605, %611
  %613 = insertelement <8 x i1> %600, i1 %612, i64 1
  %614 = extractelement <8 x i32> %585, i64 2
  %615 = icmp ult i32 %614, 8
  %616 = select i1 %615, i32 %614, i32 0
  %617 = extractelement <8 x i1> %62, i32 %616
  %618 = extractelement <8 x i1> %62, i64 2
  %619 = and i1 %615, %617
  %620 = and i1 %618, %619
  %621 = extractelement <8 x float> %583, i32 %616
  %622 = select i1 %620, float %621, float 0.000000e+00
  %623 = insertelement <8 x float> %610, float %622, i64 2
  %624 = xor i1 %620, true
  %625 = and i1 %618, %624
  %626 = insertelement <8 x i1> %613, i1 %625, i64 2
  %627 = extractelement <8 x i32> %585, i64 3
  %628 = icmp ult i32 %627, 8
  %629 = select i1 %628, i32 %627, i32 0
  %630 = extractelement <8 x i1> %62, i32 %629
  %631 = extractelement <8 x i1> %62, i64 3
  %632 = and i1 %628, %630
  %633 = and i1 %631, %632
  %634 = extractelement <8 x float> %583, i32 %629
  %635 = select i1 %633, float %634, float 0.000000e+00
  %636 = insertelement <8 x float> %623, float %635, i64 3
  %637 = xor i1 %633, true
  %638 = and i1 %631, %637
  %639 = insertelement <8 x i1> %626, i1 %638, i64 3
  %640 = extractelement <8 x i32> %585, i64 4
  %641 = icmp ult i32 %640, 8
  %642 = select i1 %641, i32 %640, i32 0
  %643 = extractelement <8 x i1> %62, i32 %642
  %644 = extractelement <8 x i1> %62, i64 4
  %645 = and i1 %641, %643
  %646 = and i1 %644, %645
  %647 = extractelement <8 x float> %583, i32 %642
  %648 = select i1 %646, float %647, float 0.000000e+00
  %649 = insertelement <8 x float> %636, float %648, i64 4
  %650 = xor i1 %646, true
  %651 = and i1 %644, %650
  %652 = insertelement <8 x i1> %639, i1 %651, i64 4
  %653 = extractelement <8 x i32> %585, i64 5
  %654 = icmp ult i32 %653, 8
  %655 = select i1 %654, i32 %653, i32 0
  %656 = extractelement <8 x i1> %62, i32 %655
  %657 = extractelement <8 x i1> %62, i64 5
  %658 = and i1 %654, %656
  %659 = and i1 %657, %658
  %660 = extractelement <8 x float> %583, i32 %655
  %661 = select i1 %659, float %660, float 0.000000e+00
  %662 = insertelement <8 x float> %649, float %661, i64 5
  %663 = xor i1 %659, true
  %664 = and i1 %657, %663
  %665 = insertelement <8 x i1> %652, i1 %664, i64 5
  %666 = extractelement <8 x i32> %585, i64 6
  %667 = icmp ult i32 %666, 8
  %668 = select i1 %667, i32 %666, i32 0
  %669 = extractelement <8 x i1> %62, i32 %668
  %670 = extractelement <8 x i1> %62, i64 6
  %671 = and i1 %667, %669
  %672 = and i1 %670, %671
  %673 = extractelement <8 x float> %583, i32 %668
  %674 = select i1 %672, float %673, float 0.000000e+00
  %675 = insertelement <8 x float> %662, float %674, i64 6
  %676 = xor i1 %672, true
  %677 = and i1 %670, %676
  %678 = insertelement <8 x i1> %665, i1 %677, i64 6
  %679 = extractelement <8 x i32> %585, i64 7
  %680 = icmp ult i32 %679, 8
  %681 = select i1 %680, i32 %679, i32 0
  %682 = extractelement <8 x i1> %62, i32 %681
  %683 = extractelement <8 x i1> %62, i64 7
  %684 = and i1 %680, %682
  %685 = and i1 %683, %684
  %686 = extractelement <8 x float> %583, i32 %681
  %687 = select i1 %685, float %686, float 0.000000e+00
  %688 = insertelement <8 x float> %675, float %687, i64 7
  %689 = xor i1 %685, true
  %690 = and i1 %683, %689
  %691 = insertelement <8 x i1> %678, i1 %690, i64 7
  %692 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %583, <8 x float> %688)
  %693 = xor <8 x i32> %584, splat (i32 2)
  %694 = load <8 x i32>, ptr %.spill35, align 32
  %695 = select <8 x i1> %62, <8 x i32> %693, <8 x i32> %694
  store <8 x i32> %695, ptr %.spill35, align 32
  %696 = extractelement <8 x i32> %693, i64 0
  %697 = icmp ult i32 %696, 8
  %698 = select i1 %697, i32 %696, i32 0
  %699 = extractelement <8 x i1> %62, i32 %698
  %700 = extractelement <8 x i1> %62, i64 0
  %701 = and i1 %697, %699
  %702 = and i1 %700, %701
  %703 = extractelement <8 x float> %692, i32 %698
  %704 = select i1 %702, float %703, float 0.000000e+00
  %705 = insertelement <8 x float> poison, float %704, i64 0
  %706 = xor i1 %702, true
  %707 = and i1 %700, %706
  %708 = insertelement <8 x i1> poison, i1 %707, i64 0
  %709 = extractelement <8 x i32> %693, i64 1
  %710 = icmp ult i32 %709, 8
  %711 = select i1 %710, i32 %709, i32 0
  %712 = extractelement <8 x i1> %62, i32 %711
  %713 = extractelement <8 x i1> %62, i64 1
  %714 = and i1 %710, %712
  %715 = and i1 %713, %714
  %716 = extractelement <8 x float> %692, i32 %711
  %717 = select i1 %715, float %716, float 0.000000e+00
  %718 = insertelement <8 x float> %705, float %717, i64 1
  %719 = xor i1 %715, true
  %720 = and i1 %713, %719
  %721 = insertelement <8 x i1> %708, i1 %720, i64 1
  %722 = extractelement <8 x i32> %693, i64 2
  %723 = icmp ult i32 %722, 8
  %724 = select i1 %723, i32 %722, i32 0
  %725 = extractelement <8 x i1> %62, i32 %724
  %726 = extractelement <8 x i1> %62, i64 2
  %727 = and i1 %723, %725
  %728 = and i1 %726, %727
  %729 = extractelement <8 x float> %692, i32 %724
  %730 = select i1 %728, float %729, float 0.000000e+00
  %731 = insertelement <8 x float> %718, float %730, i64 2
  %732 = xor i1 %728, true
  %733 = and i1 %726, %732
  %734 = insertelement <8 x i1> %721, i1 %733, i64 2
  %735 = extractelement <8 x i32> %693, i64 3
  %736 = icmp ult i32 %735, 8
  %737 = select i1 %736, i32 %735, i32 0
  %738 = extractelement <8 x i1> %62, i32 %737
  %739 = extractelement <8 x i1> %62, i64 3
  %740 = and i1 %736, %738
  %741 = and i1 %739, %740
  %742 = extractelement <8 x float> %692, i32 %737
  %743 = select i1 %741, float %742, float 0.000000e+00
  %744 = insertelement <8 x float> %731, float %743, i64 3
  %745 = xor i1 %741, true
  %746 = and i1 %739, %745
  %747 = insertelement <8 x i1> %734, i1 %746, i64 3
  %748 = extractelement <8 x i32> %693, i64 4
  %749 = icmp ult i32 %748, 8
  %750 = select i1 %749, i32 %748, i32 0
  %751 = extractelement <8 x i1> %62, i32 %750
  %752 = extractelement <8 x i1> %62, i64 4
  %753 = and i1 %749, %751
  %754 = and i1 %752, %753
  %755 = extractelement <8 x float> %692, i32 %750
  %756 = select i1 %754, float %755, float 0.000000e+00
  %757 = insertelement <8 x float> %744, float %756, i64 4
  %758 = xor i1 %754, true
  %759 = and i1 %752, %758
  %760 = insertelement <8 x i1> %747, i1 %759, i64 4
  %761 = extractelement <8 x i32> %693, i64 5
  %762 = icmp ult i32 %761, 8
  %763 = select i1 %762, i32 %761, i32 0
  %764 = extractelement <8 x i1> %62, i32 %763
  %765 = extractelement <8 x i1> %62, i64 5
  %766 = and i1 %762, %764
  %767 = and i1 %765, %766
  %768 = extractelement <8 x float> %692, i32 %763
  %769 = select i1 %767, float %768, float 0.000000e+00
  %770 = insertelement <8 x float> %757, float %769, i64 5
  %771 = xor i1 %767, true
  %772 = and i1 %765, %771
  %773 = insertelement <8 x i1> %760, i1 %772, i64 5
  %774 = extractelement <8 x i32> %693, i64 6
  %775 = icmp ult i32 %774, 8
  %776 = select i1 %775, i32 %774, i32 0
  %777 = extractelement <8 x i1> %62, i32 %776
  %778 = extractelement <8 x i1> %62, i64 6
  %779 = and i1 %775, %777
  %780 = and i1 %778, %779
  %781 = extractelement <8 x float> %692, i32 %776
  %782 = select i1 %780, float %781, float 0.000000e+00
  %783 = insertelement <8 x float> %770, float %782, i64 6
  %784 = xor i1 %780, true
  %785 = and i1 %778, %784
  %786 = insertelement <8 x i1> %773, i1 %785, i64 6
  %787 = extractelement <8 x i32> %693, i64 7
  %788 = icmp ult i32 %787, 8
  %789 = select i1 %788, i32 %787, i32 0
  %790 = extractelement <8 x i1> %62, i32 %789
  %791 = extractelement <8 x i1> %62, i64 7
  %792 = and i1 %788, %790
  %793 = and i1 %791, %792
  %794 = extractelement <8 x float> %692, i32 %789
  %795 = select i1 %793, float %794, float 0.000000e+00
  %796 = insertelement <8 x float> %783, float %795, i64 7
  %797 = xor i1 %793, true
  %798 = and i1 %791, %797
  %799 = insertelement <8 x i1> %786, i1 %798, i64 7
  %800 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %692, <8 x float> %796)
  %801 = xor <8 x i32> %584, splat (i32 4)
  %802 = load <8 x i32>, ptr %.spill36, align 32
  %803 = select <8 x i1> %62, <8 x i32> %801, <8 x i32> %802
  store <8 x i32> %803, ptr %.spill36, align 32
  %804 = extractelement <8 x i32> %801, i64 0
  %805 = icmp ult i32 %804, 8
  %806 = select i1 %805, i32 %804, i32 0
  %807 = extractelement <8 x i1> %62, i32 %806
  %808 = extractelement <8 x i1> %62, i64 0
  %809 = and i1 %805, %807
  %810 = and i1 %808, %809
  %811 = extractelement <8 x float> %800, i32 %806
  %812 = select i1 %810, float %811, float 0.000000e+00
  %813 = insertelement <8 x float> poison, float %812, i64 0
  %814 = xor i1 %810, true
  %815 = and i1 %808, %814
  %816 = insertelement <8 x i1> poison, i1 %815, i64 0
  %817 = extractelement <8 x i32> %801, i64 1
  %818 = icmp ult i32 %817, 8
  %819 = select i1 %818, i32 %817, i32 0
  %820 = extractelement <8 x i1> %62, i32 %819
  %821 = extractelement <8 x i1> %62, i64 1
  %822 = and i1 %818, %820
  %823 = and i1 %821, %822
  %824 = extractelement <8 x float> %800, i32 %819
  %825 = select i1 %823, float %824, float 0.000000e+00
  %826 = insertelement <8 x float> %813, float %825, i64 1
  %827 = xor i1 %823, true
  %828 = and i1 %821, %827
  %829 = insertelement <8 x i1> %816, i1 %828, i64 1
  %830 = extractelement <8 x i32> %801, i64 2
  %831 = icmp ult i32 %830, 8
  %832 = select i1 %831, i32 %830, i32 0
  %833 = extractelement <8 x i1> %62, i32 %832
  %834 = extractelement <8 x i1> %62, i64 2
  %835 = and i1 %831, %833
  %836 = and i1 %834, %835
  %837 = extractelement <8 x float> %800, i32 %832
  %838 = select i1 %836, float %837, float 0.000000e+00
  %839 = insertelement <8 x float> %826, float %838, i64 2
  %840 = xor i1 %836, true
  %841 = and i1 %834, %840
  %842 = insertelement <8 x i1> %829, i1 %841, i64 2
  %843 = extractelement <8 x i32> %801, i64 3
  %844 = icmp ult i32 %843, 8
  %845 = select i1 %844, i32 %843, i32 0
  %846 = extractelement <8 x i1> %62, i32 %845
  %847 = extractelement <8 x i1> %62, i64 3
  %848 = and i1 %844, %846
  %849 = and i1 %847, %848
  %850 = extractelement <8 x float> %800, i32 %845
  %851 = select i1 %849, float %850, float 0.000000e+00
  %852 = insertelement <8 x float> %839, float %851, i64 3
  %853 = xor i1 %849, true
  %854 = and i1 %847, %853
  %855 = insertelement <8 x i1> %842, i1 %854, i64 3
  %856 = extractelement <8 x i32> %801, i64 4
  %857 = icmp ult i32 %856, 8
  %858 = select i1 %857, i32 %856, i32 0
  %859 = extractelement <8 x i1> %62, i32 %858
  %860 = extractelement <8 x i1> %62, i64 4
  %861 = and i1 %857, %859
  %862 = and i1 %860, %861
  %863 = extractelement <8 x float> %800, i32 %858
  %864 = select i1 %862, float %863, float 0.000000e+00
  %865 = insertelement <8 x float> %852, float %864, i64 4
  %866 = xor i1 %862, true
  %867 = and i1 %860, %866
  %868 = insertelement <8 x i1> %855, i1 %867, i64 4
  %869 = extractelement <8 x i32> %801, i64 5
  %870 = icmp ult i32 %869, 8
  %871 = select i1 %870, i32 %869, i32 0
  %872 = extractelement <8 x i1> %62, i32 %871
  %873 = extractelement <8 x i1> %62, i64 5
  %874 = and i1 %870, %872
  %875 = and i1 %873, %874
  %876 = extractelement <8 x float> %800, i32 %871
  %877 = select i1 %875, float %876, float 0.000000e+00
  %878 = insertelement <8 x float> %865, float %877, i64 5
  %879 = xor i1 %875, true
  %880 = and i1 %873, %879
  %881 = insertelement <8 x i1> %868, i1 %880, i64 5
  %882 = extractelement <8 x i32> %801, i64 6
  %883 = icmp ult i32 %882, 8
  %884 = select i1 %883, i32 %882, i32 0
  %885 = extractelement <8 x i1> %62, i32 %884
  %886 = extractelement <8 x i1> %62, i64 6
  %887 = and i1 %883, %885
  %888 = and i1 %886, %887
  %889 = extractelement <8 x float> %800, i32 %884
  %890 = select i1 %888, float %889, float 0.000000e+00
  %891 = insertelement <8 x float> %878, float %890, i64 6
  %892 = xor i1 %888, true
  %893 = and i1 %886, %892
  %894 = insertelement <8 x i1> %881, i1 %893, i64 6
  %895 = extractelement <8 x i32> %801, i64 7
  %896 = icmp ult i32 %895, 8
  %897 = select i1 %896, i32 %895, i32 0
  %898 = extractelement <8 x i1> %62, i32 %897
  %899 = extractelement <8 x i1> %62, i64 7
  %900 = and i1 %896, %898
  %901 = and i1 %899, %900
  %902 = extractelement <8 x float> %800, i32 %897
  %903 = select i1 %901, float %902, float 0.000000e+00
  %904 = insertelement <8 x float> %891, float %903, i64 7
  %905 = xor i1 %901, true
  %906 = and i1 %899, %905
  %907 = insertelement <8 x i1> %894, i1 %906, i64 7
  %908 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %800, <8 x float> %904)
  %909 = extractelement <8 x i1> %62, i32 0
  %910 = extractelement <8 x i1> %62, i64 0
  %911 = and i1 true, %909
  %912 = and i1 %910, %911
  %913 = extractelement <8 x float> %908, i32 0
  %914 = select i1 %912, float %913, float 0.000000e+00
  %915 = insertelement <8 x float> poison, float %914, i64 0
  %916 = xor i1 %912, true
  %917 = and i1 %910, %916
  %918 = insertelement <8 x i1> poison, i1 %917, i64 0
  %919 = extractelement <8 x i1> %62, i32 0
  %920 = extractelement <8 x i1> %62, i64 1
  %921 = and i1 true, %919
  %922 = and i1 %920, %921
  %923 = extractelement <8 x float> %908, i32 0
  %924 = select i1 %922, float %923, float 0.000000e+00
  %925 = insertelement <8 x float> %915, float %924, i64 1
  %926 = xor i1 %922, true
  %927 = and i1 %920, %926
  %928 = insertelement <8 x i1> %918, i1 %927, i64 1
  %929 = extractelement <8 x i1> %62, i32 0
  %930 = extractelement <8 x i1> %62, i64 2
  %931 = and i1 true, %929
  %932 = and i1 %930, %931
  %933 = extractelement <8 x float> %908, i32 0
  %934 = select i1 %932, float %933, float 0.000000e+00
  %935 = insertelement <8 x float> %925, float %934, i64 2
  %936 = xor i1 %932, true
  %937 = and i1 %930, %936
  %938 = insertelement <8 x i1> %928, i1 %937, i64 2
  %939 = extractelement <8 x i1> %62, i32 0
  %940 = extractelement <8 x i1> %62, i64 3
  %941 = and i1 true, %939
  %942 = and i1 %940, %941
  %943 = extractelement <8 x float> %908, i32 0
  %944 = select i1 %942, float %943, float 0.000000e+00
  %945 = insertelement <8 x float> %935, float %944, i64 3
  %946 = xor i1 %942, true
  %947 = and i1 %940, %946
  %948 = insertelement <8 x i1> %938, i1 %947, i64 3
  %949 = extractelement <8 x i1> %62, i32 0
  %950 = extractelement <8 x i1> %62, i64 4
  %951 = and i1 true, %949
  %952 = and i1 %950, %951
  %953 = extractelement <8 x float> %908, i32 0
  %954 = select i1 %952, float %953, float 0.000000e+00
  %955 = insertelement <8 x float> %945, float %954, i64 4
  %956 = xor i1 %952, true
  %957 = and i1 %950, %956
  %958 = insertelement <8 x i1> %948, i1 %957, i64 4
  %959 = extractelement <8 x i1> %62, i32 0
  %960 = extractelement <8 x i1> %62, i64 5
  %961 = and i1 true, %959
  %962 = and i1 %960, %961
  %963 = extractelement <8 x float> %908, i32 0
  %964 = select i1 %962, float %963, float 0.000000e+00
  %965 = insertelement <8 x float> %955, float %964, i64 5
  %966 = xor i1 %962, true
  %967 = and i1 %960, %966
  %968 = insertelement <8 x i1> %958, i1 %967, i64 5
  %969 = extractelement <8 x i1> %62, i32 0
  %970 = extractelement <8 x i1> %62, i64 6
  %971 = and i1 true, %969
  %972 = and i1 %970, %971
  %973 = extractelement <8 x float> %908, i32 0
  %974 = select i1 %972, float %973, float 0.000000e+00
  %975 = insertelement <8 x float> %965, float %974, i64 6
  %976 = xor i1 %972, true
  %977 = and i1 %970, %976
  %978 = insertelement <8 x i1> %968, i1 %977, i64 6
  %979 = extractelement <8 x i1> %62, i32 0
  %980 = extractelement <8 x i1> %62, i64 7
  %981 = and i1 true, %979
  %982 = and i1 %980, %981
  %983 = extractelement <8 x float> %908, i32 0
  %984 = select i1 %982, float %983, float 0.000000e+00
  %985 = insertelement <8 x float> %975, float %984, i64 7
  %986 = xor i1 %982, true
  %987 = and i1 %980, %986
  %988 = insertelement <8 x i1> %978, i1 %987, i64 7
  %989 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %990 = bitcast <8 x i1> %62 to i8
  %991 = call i8 @llvm.cttz.i8(i8 %990, i1 false)
  %992 = zext i8 %991 to i32
  %993 = select i1 %989, i32 %992, i32 0
  %994 = extractelement <8 x float> %985, i32 %993
  %.spill.load182 = load float, ptr %.spill27, align 4
  %995 = call float @llvm.maxnum.f32(float %.spill.load182, float %994)
  store float %995, ptr %.spill37, align 4
  store float 0.000000e+00, ptr %.spill38, align 4
  %996 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %997 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %998 = extractvalue { <8 x ptr>, <8 x i64> } %996, 0
  %999 = select <8 x i1> %62, <8 x ptr> %997, <8 x ptr> %998
  %1000 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1001 = extractvalue { <8 x ptr>, <8 x i64> } %996, 1
  %1002 = select <8 x i1> %62, <8 x i64> %1000, <8 x i64> %1001
  %1003 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %999, 0
  %1004 = insertvalue { <8 x ptr>, <8 x i64> } %1003, <8 x i64> %1002, 1
  store { <8 x ptr>, <8 x i64> } %1004, ptr %tile_snapshot.spill39, align 64
  %1005 = load <8 x i64>, ptr %.slot40, align 64
  %1006 = select <8 x i1> %62, <8 x i64> zeroinitializer, <8 x i64> %1005
  store <8 x i64> %1006, ptr %.slot40, align 64
  br label %direct.schedule.26

direct.schedule.26:                               ; preds = %direct.schedule.27, %direct.schedule.25
  %.state183 = load <8 x i64>, ptr %.slot40, align 64
  %1007 = icmp slt <8 x i64> %.state183, splat (i64 512)
  %1008 = extractelement <8 x i1> %1007, i32 0
  br i1 %1008, label %direct.true184, label %direct.false185

direct.schedule.27:                               ; preds = %direct.true184
  %tile_snapshot.spill.load186 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %1009 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load186, 0
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load186, 1
  %.state187 = load <8 x i64>, ptr %.slot40, align 64
  %1011 = add <8 x i64> %1010, %.state187
  %1012 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1009, 0
  %1013 = insertvalue { <8 x ptr>, <8 x i64> } %1012, <8 x i64> %1011, 1
  %1014 = extractvalue { <8 x ptr>, <8 x i64> } %1013, 0
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %1013, 1
  %1016 = getelementptr i8, <8 x ptr> %1014, <8 x i64> %1015
  %1017 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %1016, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %1018 = icmp ne <8 x i8> %1017, zeroinitializer
  %tile_snapshot.spill.load188 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %1019 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %1020 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %.state189 = load <8 x i64>, ptr %.slot40, align 64
  %1021 = mul <8 x i64> %.state189, splat (i64 32)
  %1022 = add <8 x i64> %1020, %1021
  %1023 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1019, 0
  %1024 = insertvalue { <8 x ptr>, <8 x i64> } %1023, <8 x i64> %1022, 1
  %1025 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1026 = extractvalue { <8 x ptr>, <8 x i64> } %1024, 1
  %1027 = extractelement <8 x ptr> %1025, i32 0
  %1028 = extractelement <8 x i64> %1026, i32 0
  %1029 = sub i64 %1028, 0
  %1030 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1031 = select i1 %1030, i64 %1029, i64 0
  %private.contiguous.address190 = getelementptr i8, ptr %1027, i64 %1031
  %private.contiguous.load191 = load <8 x float>, ptr %private.contiguous.address190, align 4
  %1032 = select <8 x i1> %62, <8 x float> %private.contiguous.load191, <8 x float> zeroinitializer
  %.spill.load192 = load float, ptr %.spill37, align 4
  %.splatinsert193 = insertelement <8 x float> poison, float %.spill.load192, i64 0
  %.splat194 = shufflevector <8 x float> %.splatinsert193, <8 x float> poison, <8 x i32> zeroinitializer
  %1033 = fsub <8 x float> %1032, %.splat194
  %1034 = select <8 x i1> %62, <8 x float> %1033, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1034)
  %.spill.load195 = load float, ptr %.spill38, align 4
  %.splatinsert196 = insertelement <8 x float> poison, float %.spill.load195, i64 0
  %.splat197 = shufflevector <8 x float> %.splatinsert196, <8 x float> poison, <8 x i32> zeroinitializer
  %1035 = select <8 x i1> %1018, <8 x float> %native.exp, <8 x float> %.splat197
  %tile_snapshot.spill.load198 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 0
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 1
  %.state199 = load <8 x i64>, ptr %.slot40, align 64
  %1038 = mul <8 x i64> %.state199, splat (i64 32)
  %1039 = add <8 x i64> %1037, %1038
  %1040 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1036, 0
  %1041 = insertvalue { <8 x ptr>, <8 x i64> } %1040, <8 x i64> %1039, 1
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1043 = extractvalue { <8 x ptr>, <8 x i64> } %1041, 1
  %1044 = extractelement <8 x ptr> %1042, i32 0
  %1045 = extractelement <8 x i64> %1043, i32 0
  %1046 = sub i64 %1045, 0
  %1047 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1048 = select i1 %1047, i64 %1046, i64 0
  %private.contiguous.address200 = getelementptr i8, ptr %1044, i64 %1048
  %private.contiguous.preserve201 = load <8 x float>, ptr %private.contiguous.address200, align 4
  %1049 = select <8 x i1> %62, <8 x float> %1035, <8 x float> %private.contiguous.preserve201
  store <8 x float> %1049, ptr %private.contiguous.address200, align 4
  %.state202 = load <8 x i64>, ptr %.slot40, align 64
  %1050 = add <8 x i64> %.state202, splat (i64 1)
  %1051 = load <8 x i64>, ptr %.slot40, align 64
  %1052 = select <8 x i1> %62, <8 x i64> %1050, <8 x i64> %1051
  store <8 x i64> %1052, ptr %.slot40, align 64
  br label %direct.schedule.26

direct.schedule.28:                               ; preds = %direct.false185
  %.spill.load203 = load <8 x i1>, ptr %.spill18, align 1
  %1053 = and <8 x i1> %62, %.spill.load203
  %1054 = xor <8 x i1> %.spill.load203, splat (i1 true)
  %1055 = and <8 x i1> %62, %1054
  %1056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1053)
  %1057 = bitcast <8 x i1> %1053 to i8
  %1058 = call i8 @llvm.cttz.i8(i8 %1057, i1 false)
  %1059 = zext i8 %1058 to i32
  %1060 = select i1 %1056, i32 %1059, i32 0
  %tile_snapshot.spill.load204 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %1061 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load204, 0
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load204, 1
  %1063 = add <8 x i64> %1062, splat (i64 512)
  %1064 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1061, 0
  %1065 = insertvalue { <8 x ptr>, <8 x i64> } %1064, <8 x i64> %1063, 1
  %1066 = extractvalue { <8 x ptr>, <8 x i64> } %1065, 0
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %1065, 1
  %1068 = getelementptr i8, <8 x ptr> %1066, <8 x i64> %1067
  %1069 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %1068, i32 1, <8 x i1> %1053, <8 x i8> zeroinitializer)
  %1070 = icmp ne <8 x i8> %1069, zeroinitializer
  %tile_snapshot.spill.load205 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %1071 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load205, 0
  %1072 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load205, 1
  %1073 = add <8 x i64> %1072, splat (i64 16384)
  %1074 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1071, 0
  %1075 = insertvalue { <8 x ptr>, <8 x i64> } %1074, <8 x i64> %1073, 1
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1077 = extractvalue { <8 x ptr>, <8 x i64> } %1075, 1
  %1078 = extractelement <8 x ptr> %1076, i32 0
  %1079 = extractelement <8 x i64> %1077, i32 %1060
  %1080 = zext i32 %1060 to i64
  %1081 = mul i64 %1080, 4
  %1082 = sub i64 %1079, %1081
  %1083 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1053)
  %1084 = select i1 %1083, i64 %1082, i64 0
  %private.contiguous.address206 = getelementptr i8, ptr %1078, i64 %1084
  %private.contiguous.load207 = load <8 x float>, ptr %private.contiguous.address206, align 4
  %1085 = select <8 x i1> %1053, <8 x float> %private.contiguous.load207, <8 x float> zeroinitializer
  %.spill.load208 = load float, ptr %.spill37, align 4
  %.splatinsert209 = insertelement <8 x float> poison, float %.spill.load208, i64 0
  %.splat210 = shufflevector <8 x float> %.splatinsert209, <8 x float> poison, <8 x i32> zeroinitializer
  %1086 = fsub <8 x float> %1085, %.splat210
  %1087 = select <8 x i1> %1053, <8 x float> %1086, <8 x float> zeroinitializer
  %native.exp211 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1087)
  %.spill.load212 = load float, ptr %.spill38, align 4
  %.splatinsert213 = insertelement <8 x float> poison, float %.spill.load212, i64 0
  %.splat214 = shufflevector <8 x float> %.splatinsert213, <8 x float> poison, <8 x i32> zeroinitializer
  %1088 = select <8 x i1> %1070, <8 x float> %native.exp211, <8 x float> %.splat214
  %tile_snapshot.spill.load215 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 0
  %1090 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 1
  %1091 = add <8 x i64> %1090, splat (i64 16384)
  %1092 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1089, 0
  %1093 = insertvalue { <8 x ptr>, <8 x i64> } %1092, <8 x i64> %1091, 1
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1095 = extractvalue { <8 x ptr>, <8 x i64> } %1093, 1
  %1096 = extractelement <8 x ptr> %1094, i32 0
  %1097 = extractelement <8 x i64> %1095, i32 %1060
  %1098 = zext i32 %1060 to i64
  %1099 = mul i64 %1098, 4
  %1100 = sub i64 %1097, %1099
  %1101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1053)
  %1102 = select i1 %1101, i64 %1100, i64 0
  %private.contiguous.address216 = getelementptr i8, ptr %1096, i64 %1102
  %private.contiguous.preserve217 = load <8 x float>, ptr %private.contiguous.address216, align 4
  %1103 = select <8 x i1> %1053, <8 x float> %1088, <8 x float> %private.contiguous.preserve217
  store <8 x float> %1103, ptr %private.contiguous.address216, align 4
  %1104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1055)
  %1105 = bitcast <8 x i1> %1055 to i8
  %1106 = call i8 @llvm.cttz.i8(i8 %1105, i1 false)
  %1107 = zext i8 %1106 to i32
  %1108 = select i1 %1104, i32 %1107, i32 0
  br label %direct.schedule.30

direct.schedule.30:                               ; preds = %direct.schedule.28
  %tile_snapshot.spill.load218 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1109 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 0
  %1110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 1
  %1111 = add <8 x i64> %1110, zeroinitializer
  %1112 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1109, 0
  %1113 = insertvalue { <8 x ptr>, <8 x i64> } %1112, <8 x i64> %1111, 1
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %1113, 1
  %1116 = extractelement <8 x ptr> %1114, i32 0
  %1117 = extractelement <8 x i64> %1115, i32 0
  %1118 = sub i64 %1117, 0
  %1119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1120 = select i1 %1119, i64 %1118, i64 0
  %private.contiguous.address219 = getelementptr i8, ptr %1116, i64 %1120
  %private.contiguous.load220 = load <8 x float>, ptr %private.contiguous.address219, align 4
  %1121 = select <8 x i1> %62, <8 x float> %private.contiguous.load220, <8 x float> zeroinitializer
  %tile_snapshot.spill.load221 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1122 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %1123 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %1124 = add <8 x i64> %1123, splat (i64 32)
  %1125 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1122, 0
  %1126 = insertvalue { <8 x ptr>, <8 x i64> } %1125, <8 x i64> %1124, 1
  %1127 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1128 = extractvalue { <8 x ptr>, <8 x i64> } %1126, 1
  %1129 = extractelement <8 x ptr> %1127, i32 0
  %1130 = extractelement <8 x i64> %1128, i32 0
  %1131 = sub i64 %1130, 0
  %1132 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1133 = select i1 %1132, i64 %1131, i64 0
  %private.contiguous.address222 = getelementptr i8, ptr %1129, i64 %1133
  %private.contiguous.load223 = load <8 x float>, ptr %private.contiguous.address222, align 4
  %1134 = select <8 x i1> %62, <8 x float> %private.contiguous.load223, <8 x float> zeroinitializer
  %tile_snapshot.spill.load224 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1135 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load224, 0
  %1136 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load224, 1
  %1137 = add <8 x i64> %1136, splat (i64 64)
  %1138 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1135, 0
  %1139 = insertvalue { <8 x ptr>, <8 x i64> } %1138, <8 x i64> %1137, 1
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %1139, 1
  %1142 = extractelement <8 x ptr> %1140, i32 0
  %1143 = extractelement <8 x i64> %1141, i32 0
  %1144 = sub i64 %1143, 0
  %1145 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1146 = select i1 %1145, i64 %1144, i64 0
  %private.contiguous.address225 = getelementptr i8, ptr %1142, i64 %1146
  %private.contiguous.load226 = load <8 x float>, ptr %private.contiguous.address225, align 4
  %1147 = select <8 x i1> %62, <8 x float> %private.contiguous.load226, <8 x float> zeroinitializer
  %tile_snapshot.spill.load227 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1148 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 0
  %1149 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 1
  %1150 = add <8 x i64> %1149, splat (i64 96)
  %1151 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1148, 0
  %1152 = insertvalue { <8 x ptr>, <8 x i64> } %1151, <8 x i64> %1150, 1
  %1153 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %1152, 1
  %1155 = extractelement <8 x ptr> %1153, i32 0
  %1156 = extractelement <8 x i64> %1154, i32 0
  %1157 = sub i64 %1156, 0
  %1158 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1159 = select i1 %1158, i64 %1157, i64 0
  %private.contiguous.address228 = getelementptr i8, ptr %1155, i64 %1159
  %private.contiguous.load229 = load <8 x float>, ptr %private.contiguous.address228, align 4
  %1160 = select <8 x i1> %62, <8 x float> %private.contiguous.load229, <8 x float> zeroinitializer
  %1161 = load <8 x i64>, ptr %.slot41, align 64
  %1162 = select <8 x i1> %62, <8 x i64> splat (i64 4), <8 x i64> %1161
  store <8 x i64> %1162, ptr %.slot41, align 64
  %1163 = load <8 x float>, ptr %.slot42, align 32
  %1164 = select <8 x i1> %62, <8 x float> %1121, <8 x float> %1163
  store <8 x float> %1164, ptr %.slot42, align 32
  %1165 = load <8 x float>, ptr %.slot43, align 32
  %1166 = select <8 x i1> %62, <8 x float> %1134, <8 x float> %1165
  store <8 x float> %1166, ptr %.slot43, align 32
  %1167 = load <8 x float>, ptr %.slot44, align 32
  %1168 = select <8 x i1> %62, <8 x float> %1147, <8 x float> %1167
  store <8 x float> %1168, ptr %.slot44, align 32
  %1169 = load <8 x float>, ptr %.slot45, align 32
  %1170 = select <8 x i1> %62, <8 x float> %1160, <8 x float> %1169
  store <8 x float> %1170, ptr %.slot45, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state230 = load <8 x i64>, ptr %.slot41, align 64
  %1171 = icmp slt <8 x i64> %.state230, splat (i64 512)
  %1172 = extractelement <8 x i1> %1171, i32 0
  br i1 %1172, label %direct.true231, label %direct.false232

direct.schedule.32:                               ; preds = %direct.true231
  %.state233 = load <8 x i64>, ptr %.slot41, align 64
  %1173 = add <8 x i64> %.state233, zeroinitializer
  %tile_snapshot.spill.load234 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load234, 0
  %1175 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load234, 1
  %1176 = mul <8 x i64> %1173, splat (i64 32)
  %1177 = add <8 x i64> %1175, %1176
  %1178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1174, 0
  %1179 = insertvalue { <8 x ptr>, <8 x i64> } %1178, <8 x i64> %1177, 1
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1181 = extractvalue { <8 x ptr>, <8 x i64> } %1179, 1
  %1182 = extractelement <8 x ptr> %1180, i32 0
  %1183 = extractelement <8 x i64> %1181, i32 0
  %1184 = sub i64 %1183, 0
  %1185 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1186 = select i1 %1185, i64 %1184, i64 0
  %private.contiguous.address235 = getelementptr i8, ptr %1182, i64 %1186
  %private.contiguous.load236 = load <8 x float>, ptr %private.contiguous.address235, align 4
  %1187 = select <8 x i1> %62, <8 x float> %private.contiguous.load236, <8 x float> zeroinitializer
  %.state237 = load <8 x float>, ptr %.slot42, align 32
  %1188 = fadd <8 x float> %.state237, %1187
  %.state238 = load <8 x i64>, ptr %.slot41, align 64
  %1189 = add <8 x i64> %.state238, splat (i64 1)
  %tile_snapshot.spill.load239 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1190 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 0
  %1191 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 1
  %1192 = mul <8 x i64> %1189, splat (i64 32)
  %1193 = add <8 x i64> %1191, %1192
  %1194 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1190, 0
  %1195 = insertvalue { <8 x ptr>, <8 x i64> } %1194, <8 x i64> %1193, 1
  %1196 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %1195, 1
  %1198 = extractelement <8 x ptr> %1196, i32 0
  %1199 = extractelement <8 x i64> %1197, i32 0
  %1200 = sub i64 %1199, 0
  %1201 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1202 = select i1 %1201, i64 %1200, i64 0
  %private.contiguous.address240 = getelementptr i8, ptr %1198, i64 %1202
  %private.contiguous.load241 = load <8 x float>, ptr %private.contiguous.address240, align 4
  %1203 = select <8 x i1> %62, <8 x float> %private.contiguous.load241, <8 x float> zeroinitializer
  %.state242 = load <8 x float>, ptr %.slot43, align 32
  %1204 = fadd <8 x float> %.state242, %1203
  %.state243 = load <8 x i64>, ptr %.slot41, align 64
  %1205 = add <8 x i64> %.state243, splat (i64 2)
  %tile_snapshot.spill.load244 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1206 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 0
  %1207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 1
  %1208 = mul <8 x i64> %1205, splat (i64 32)
  %1209 = add <8 x i64> %1207, %1208
  %1210 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1206, 0
  %1211 = insertvalue { <8 x ptr>, <8 x i64> } %1210, <8 x i64> %1209, 1
  %1212 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1213 = extractvalue { <8 x ptr>, <8 x i64> } %1211, 1
  %1214 = extractelement <8 x ptr> %1212, i32 0
  %1215 = extractelement <8 x i64> %1213, i32 0
  %1216 = sub i64 %1215, 0
  %1217 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1218 = select i1 %1217, i64 %1216, i64 0
  %private.contiguous.address245 = getelementptr i8, ptr %1214, i64 %1218
  %private.contiguous.load246 = load <8 x float>, ptr %private.contiguous.address245, align 4
  %1219 = select <8 x i1> %62, <8 x float> %private.contiguous.load246, <8 x float> zeroinitializer
  %.state247 = load <8 x float>, ptr %.slot44, align 32
  %1220 = fadd <8 x float> %.state247, %1219
  %.state248 = load <8 x i64>, ptr %.slot41, align 64
  %1221 = add <8 x i64> %.state248, splat (i64 3)
  %tile_snapshot.spill.load249 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load249, 0
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load249, 1
  %1224 = mul <8 x i64> %1221, splat (i64 32)
  %1225 = add <8 x i64> %1223, %1224
  %1226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1222, 0
  %1227 = insertvalue { <8 x ptr>, <8 x i64> } %1226, <8 x i64> %1225, 1
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %1227, 1
  %1230 = extractelement <8 x ptr> %1228, i32 0
  %1231 = extractelement <8 x i64> %1229, i32 0
  %1232 = sub i64 %1231, 0
  %1233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1234 = select i1 %1233, i64 %1232, i64 0
  %private.contiguous.address250 = getelementptr i8, ptr %1230, i64 %1234
  %private.contiguous.load251 = load <8 x float>, ptr %private.contiguous.address250, align 4
  %1235 = select <8 x i1> %62, <8 x float> %private.contiguous.load251, <8 x float> zeroinitializer
  %.state252 = load <8 x float>, ptr %.slot45, align 32
  %1236 = fadd <8 x float> %.state252, %1235
  %.state253 = load <8 x i64>, ptr %.slot41, align 64
  %1237 = add <8 x i64> %.state253, splat (i64 4)
  %1238 = load <8 x i64>, ptr %.slot41, align 64
  %1239 = select <8 x i1> %62, <8 x i64> %1237, <8 x i64> %1238
  store <8 x i64> %1239, ptr %.slot41, align 64
  %1240 = load <8 x float>, ptr %.slot42, align 32
  %1241 = select <8 x i1> %62, <8 x float> %1188, <8 x float> %1240
  store <8 x float> %1241, ptr %.slot42, align 32
  %1242 = load <8 x float>, ptr %.slot43, align 32
  %1243 = select <8 x i1> %62, <8 x float> %1204, <8 x float> %1242
  store <8 x float> %1243, ptr %.slot43, align 32
  %1244 = load <8 x float>, ptr %.slot44, align 32
  %1245 = select <8 x i1> %62, <8 x float> %1220, <8 x float> %1244
  store <8 x float> %1245, ptr %.slot44, align 32
  %1246 = load <8 x float>, ptr %.slot45, align 32
  %1247 = select <8 x i1> %62, <8 x float> %1236, <8 x float> %1246
  store <8 x float> %1247, ptr %.slot45, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false232
  %.spill.load254 = load <8 x i1>, ptr %.spill18, align 1
  %1248 = and <8 x i1> %62, %.spill.load254
  %1249 = xor <8 x i1> %.spill.load254, splat (i1 true)
  %1250 = and <8 x i1> %62, %1249
  %1251 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1248)
  %1252 = bitcast <8 x i1> %1248 to i8
  %1253 = call i8 @llvm.cttz.i8(i8 %1252, i1 false)
  %1254 = zext i8 %1253 to i32
  %1255 = select i1 %1251, i32 %1254, i32 0
  %tile_snapshot.spill.load255 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load255, 0
  %1257 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load255, 1
  %1258 = add <8 x i64> %1257, splat (i64 16384)
  %1259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1256, 0
  %1260 = insertvalue { <8 x ptr>, <8 x i64> } %1259, <8 x i64> %1258, 1
  %1261 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1262 = extractvalue { <8 x ptr>, <8 x i64> } %1260, 1
  %1263 = extractelement <8 x ptr> %1261, i32 0
  %1264 = extractelement <8 x i64> %1262, i32 %1255
  %1265 = zext i32 %1255 to i64
  %1266 = mul i64 %1265, 4
  %1267 = sub i64 %1264, %1266
  %1268 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1248)
  %1269 = select i1 %1268, i64 %1267, i64 0
  %private.contiguous.address256 = getelementptr i8, ptr %1263, i64 %1269
  %private.contiguous.load257 = load <8 x float>, ptr %private.contiguous.address256, align 4
  %1270 = select <8 x i1> %1248, <8 x float> %private.contiguous.load257, <8 x float> zeroinitializer
  %.state258 = load <8 x float>, ptr %.slot42, align 32
  %1271 = fadd <8 x float> %.state258, %1270
  %1272 = load <8 x float>, ptr %.slot46, align 32
  %1273 = select <8 x i1> %1248, <8 x float> %1271, <8 x float> %1272
  store <8 x float> %1273, ptr %.slot46, align 32
  %1274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1250)
  %1275 = bitcast <8 x i1> %1250 to i8
  %1276 = call i8 @llvm.cttz.i8(i8 %1275, i1 false)
  %1277 = zext i8 %1276 to i32
  %1278 = select i1 %1274, i32 %1277, i32 0
  %.state259 = load <8 x float>, ptr %.slot42, align 32
  %1279 = load <8 x float>, ptr %.slot46, align 32
  %1280 = select <8 x i1> %1250, <8 x float> %.state259, <8 x float> %1279
  store <8 x float> %1280, ptr %.slot46, align 32
  br label %direct.schedule.35

direct.schedule.35:                               ; preds = %direct.schedule.33
  %.state260 = load <8 x float>, ptr %.slot46, align 32
  %.state261 = load <8 x float>, ptr %.slot43, align 32
  %1281 = fadd <8 x float> %.state260, %.state261
  %.state262 = load <8 x float>, ptr %.slot44, align 32
  %1282 = fadd <8 x float> %1281, %.state262
  %.state263 = load <8 x float>, ptr %.slot45, align 32
  %1283 = fadd <8 x float> %1282, %.state263
  %.spill.load264 = load <8 x i32>, ptr %.spill34, align 32
  %1284 = extractelement <8 x i32> %.spill.load264, i64 0
  %1285 = icmp ult i32 %1284, 8
  %1286 = select i1 %1285, i32 %1284, i32 0
  %1287 = extractelement <8 x i1> %62, i32 %1286
  %1288 = extractelement <8 x i1> %62, i64 0
  %1289 = and i1 %1285, %1287
  %1290 = and i1 %1288, %1289
  %1291 = extractelement <8 x float> %1283, i32 %1286
  %1292 = select i1 %1290, float %1291, float 0.000000e+00
  %1293 = insertelement <8 x float> poison, float %1292, i64 0
  %1294 = xor i1 %1290, true
  %1295 = and i1 %1288, %1294
  %1296 = insertelement <8 x i1> poison, i1 %1295, i64 0
  %1297 = extractelement <8 x i32> %.spill.load264, i64 1
  %1298 = icmp ult i32 %1297, 8
  %1299 = select i1 %1298, i32 %1297, i32 0
  %1300 = extractelement <8 x i1> %62, i32 %1299
  %1301 = extractelement <8 x i1> %62, i64 1
  %1302 = and i1 %1298, %1300
  %1303 = and i1 %1301, %1302
  %1304 = extractelement <8 x float> %1283, i32 %1299
  %1305 = select i1 %1303, float %1304, float 0.000000e+00
  %1306 = insertelement <8 x float> %1293, float %1305, i64 1
  %1307 = xor i1 %1303, true
  %1308 = and i1 %1301, %1307
  %1309 = insertelement <8 x i1> %1296, i1 %1308, i64 1
  %1310 = extractelement <8 x i32> %.spill.load264, i64 2
  %1311 = icmp ult i32 %1310, 8
  %1312 = select i1 %1311, i32 %1310, i32 0
  %1313 = extractelement <8 x i1> %62, i32 %1312
  %1314 = extractelement <8 x i1> %62, i64 2
  %1315 = and i1 %1311, %1313
  %1316 = and i1 %1314, %1315
  %1317 = extractelement <8 x float> %1283, i32 %1312
  %1318 = select i1 %1316, float %1317, float 0.000000e+00
  %1319 = insertelement <8 x float> %1306, float %1318, i64 2
  %1320 = xor i1 %1316, true
  %1321 = and i1 %1314, %1320
  %1322 = insertelement <8 x i1> %1309, i1 %1321, i64 2
  %1323 = extractelement <8 x i32> %.spill.load264, i64 3
  %1324 = icmp ult i32 %1323, 8
  %1325 = select i1 %1324, i32 %1323, i32 0
  %1326 = extractelement <8 x i1> %62, i32 %1325
  %1327 = extractelement <8 x i1> %62, i64 3
  %1328 = and i1 %1324, %1326
  %1329 = and i1 %1327, %1328
  %1330 = extractelement <8 x float> %1283, i32 %1325
  %1331 = select i1 %1329, float %1330, float 0.000000e+00
  %1332 = insertelement <8 x float> %1319, float %1331, i64 3
  %1333 = xor i1 %1329, true
  %1334 = and i1 %1327, %1333
  %1335 = insertelement <8 x i1> %1322, i1 %1334, i64 3
  %1336 = extractelement <8 x i32> %.spill.load264, i64 4
  %1337 = icmp ult i32 %1336, 8
  %1338 = select i1 %1337, i32 %1336, i32 0
  %1339 = extractelement <8 x i1> %62, i32 %1338
  %1340 = extractelement <8 x i1> %62, i64 4
  %1341 = and i1 %1337, %1339
  %1342 = and i1 %1340, %1341
  %1343 = extractelement <8 x float> %1283, i32 %1338
  %1344 = select i1 %1342, float %1343, float 0.000000e+00
  %1345 = insertelement <8 x float> %1332, float %1344, i64 4
  %1346 = xor i1 %1342, true
  %1347 = and i1 %1340, %1346
  %1348 = insertelement <8 x i1> %1335, i1 %1347, i64 4
  %1349 = extractelement <8 x i32> %.spill.load264, i64 5
  %1350 = icmp ult i32 %1349, 8
  %1351 = select i1 %1350, i32 %1349, i32 0
  %1352 = extractelement <8 x i1> %62, i32 %1351
  %1353 = extractelement <8 x i1> %62, i64 5
  %1354 = and i1 %1350, %1352
  %1355 = and i1 %1353, %1354
  %1356 = extractelement <8 x float> %1283, i32 %1351
  %1357 = select i1 %1355, float %1356, float 0.000000e+00
  %1358 = insertelement <8 x float> %1345, float %1357, i64 5
  %1359 = xor i1 %1355, true
  %1360 = and i1 %1353, %1359
  %1361 = insertelement <8 x i1> %1348, i1 %1360, i64 5
  %1362 = extractelement <8 x i32> %.spill.load264, i64 6
  %1363 = icmp ult i32 %1362, 8
  %1364 = select i1 %1363, i32 %1362, i32 0
  %1365 = extractelement <8 x i1> %62, i32 %1364
  %1366 = extractelement <8 x i1> %62, i64 6
  %1367 = and i1 %1363, %1365
  %1368 = and i1 %1366, %1367
  %1369 = extractelement <8 x float> %1283, i32 %1364
  %1370 = select i1 %1368, float %1369, float 0.000000e+00
  %1371 = insertelement <8 x float> %1358, float %1370, i64 6
  %1372 = xor i1 %1368, true
  %1373 = and i1 %1366, %1372
  %1374 = insertelement <8 x i1> %1361, i1 %1373, i64 6
  %1375 = extractelement <8 x i32> %.spill.load264, i64 7
  %1376 = icmp ult i32 %1375, 8
  %1377 = select i1 %1376, i32 %1375, i32 0
  %1378 = extractelement <8 x i1> %62, i32 %1377
  %1379 = extractelement <8 x i1> %62, i64 7
  %1380 = and i1 %1376, %1378
  %1381 = and i1 %1379, %1380
  %1382 = extractelement <8 x float> %1283, i32 %1377
  %1383 = select i1 %1381, float %1382, float 0.000000e+00
  %1384 = insertelement <8 x float> %1371, float %1383, i64 7
  %1385 = xor i1 %1381, true
  %1386 = and i1 %1379, %1385
  %1387 = insertelement <8 x i1> %1374, i1 %1386, i64 7
  %1388 = fadd <8 x float> %1283, %1384
  %.spill.load265 = load <8 x i32>, ptr %.spill35, align 32
  %1389 = extractelement <8 x i32> %.spill.load265, i64 0
  %1390 = icmp ult i32 %1389, 8
  %1391 = select i1 %1390, i32 %1389, i32 0
  %1392 = extractelement <8 x i1> %62, i32 %1391
  %1393 = extractelement <8 x i1> %62, i64 0
  %1394 = and i1 %1390, %1392
  %1395 = and i1 %1393, %1394
  %1396 = extractelement <8 x float> %1388, i32 %1391
  %1397 = select i1 %1395, float %1396, float 0.000000e+00
  %1398 = insertelement <8 x float> poison, float %1397, i64 0
  %1399 = xor i1 %1395, true
  %1400 = and i1 %1393, %1399
  %1401 = insertelement <8 x i1> poison, i1 %1400, i64 0
  %1402 = extractelement <8 x i32> %.spill.load265, i64 1
  %1403 = icmp ult i32 %1402, 8
  %1404 = select i1 %1403, i32 %1402, i32 0
  %1405 = extractelement <8 x i1> %62, i32 %1404
  %1406 = extractelement <8 x i1> %62, i64 1
  %1407 = and i1 %1403, %1405
  %1408 = and i1 %1406, %1407
  %1409 = extractelement <8 x float> %1388, i32 %1404
  %1410 = select i1 %1408, float %1409, float 0.000000e+00
  %1411 = insertelement <8 x float> %1398, float %1410, i64 1
  %1412 = xor i1 %1408, true
  %1413 = and i1 %1406, %1412
  %1414 = insertelement <8 x i1> %1401, i1 %1413, i64 1
  %1415 = extractelement <8 x i32> %.spill.load265, i64 2
  %1416 = icmp ult i32 %1415, 8
  %1417 = select i1 %1416, i32 %1415, i32 0
  %1418 = extractelement <8 x i1> %62, i32 %1417
  %1419 = extractelement <8 x i1> %62, i64 2
  %1420 = and i1 %1416, %1418
  %1421 = and i1 %1419, %1420
  %1422 = extractelement <8 x float> %1388, i32 %1417
  %1423 = select i1 %1421, float %1422, float 0.000000e+00
  %1424 = insertelement <8 x float> %1411, float %1423, i64 2
  %1425 = xor i1 %1421, true
  %1426 = and i1 %1419, %1425
  %1427 = insertelement <8 x i1> %1414, i1 %1426, i64 2
  %1428 = extractelement <8 x i32> %.spill.load265, i64 3
  %1429 = icmp ult i32 %1428, 8
  %1430 = select i1 %1429, i32 %1428, i32 0
  %1431 = extractelement <8 x i1> %62, i32 %1430
  %1432 = extractelement <8 x i1> %62, i64 3
  %1433 = and i1 %1429, %1431
  %1434 = and i1 %1432, %1433
  %1435 = extractelement <8 x float> %1388, i32 %1430
  %1436 = select i1 %1434, float %1435, float 0.000000e+00
  %1437 = insertelement <8 x float> %1424, float %1436, i64 3
  %1438 = xor i1 %1434, true
  %1439 = and i1 %1432, %1438
  %1440 = insertelement <8 x i1> %1427, i1 %1439, i64 3
  %1441 = extractelement <8 x i32> %.spill.load265, i64 4
  %1442 = icmp ult i32 %1441, 8
  %1443 = select i1 %1442, i32 %1441, i32 0
  %1444 = extractelement <8 x i1> %62, i32 %1443
  %1445 = extractelement <8 x i1> %62, i64 4
  %1446 = and i1 %1442, %1444
  %1447 = and i1 %1445, %1446
  %1448 = extractelement <8 x float> %1388, i32 %1443
  %1449 = select i1 %1447, float %1448, float 0.000000e+00
  %1450 = insertelement <8 x float> %1437, float %1449, i64 4
  %1451 = xor i1 %1447, true
  %1452 = and i1 %1445, %1451
  %1453 = insertelement <8 x i1> %1440, i1 %1452, i64 4
  %1454 = extractelement <8 x i32> %.spill.load265, i64 5
  %1455 = icmp ult i32 %1454, 8
  %1456 = select i1 %1455, i32 %1454, i32 0
  %1457 = extractelement <8 x i1> %62, i32 %1456
  %1458 = extractelement <8 x i1> %62, i64 5
  %1459 = and i1 %1455, %1457
  %1460 = and i1 %1458, %1459
  %1461 = extractelement <8 x float> %1388, i32 %1456
  %1462 = select i1 %1460, float %1461, float 0.000000e+00
  %1463 = insertelement <8 x float> %1450, float %1462, i64 5
  %1464 = xor i1 %1460, true
  %1465 = and i1 %1458, %1464
  %1466 = insertelement <8 x i1> %1453, i1 %1465, i64 5
  %1467 = extractelement <8 x i32> %.spill.load265, i64 6
  %1468 = icmp ult i32 %1467, 8
  %1469 = select i1 %1468, i32 %1467, i32 0
  %1470 = extractelement <8 x i1> %62, i32 %1469
  %1471 = extractelement <8 x i1> %62, i64 6
  %1472 = and i1 %1468, %1470
  %1473 = and i1 %1471, %1472
  %1474 = extractelement <8 x float> %1388, i32 %1469
  %1475 = select i1 %1473, float %1474, float 0.000000e+00
  %1476 = insertelement <8 x float> %1463, float %1475, i64 6
  %1477 = xor i1 %1473, true
  %1478 = and i1 %1471, %1477
  %1479 = insertelement <8 x i1> %1466, i1 %1478, i64 6
  %1480 = extractelement <8 x i32> %.spill.load265, i64 7
  %1481 = icmp ult i32 %1480, 8
  %1482 = select i1 %1481, i32 %1480, i32 0
  %1483 = extractelement <8 x i1> %62, i32 %1482
  %1484 = extractelement <8 x i1> %62, i64 7
  %1485 = and i1 %1481, %1483
  %1486 = and i1 %1484, %1485
  %1487 = extractelement <8 x float> %1388, i32 %1482
  %1488 = select i1 %1486, float %1487, float 0.000000e+00
  %1489 = insertelement <8 x float> %1476, float %1488, i64 7
  %1490 = xor i1 %1486, true
  %1491 = and i1 %1484, %1490
  %1492 = insertelement <8 x i1> %1479, i1 %1491, i64 7
  %1493 = fadd <8 x float> %1388, %1489
  %.spill.load266 = load <8 x i32>, ptr %.spill36, align 32
  %1494 = extractelement <8 x i32> %.spill.load266, i64 0
  %1495 = icmp ult i32 %1494, 8
  %1496 = select i1 %1495, i32 %1494, i32 0
  %1497 = extractelement <8 x i1> %62, i32 %1496
  %1498 = extractelement <8 x i1> %62, i64 0
  %1499 = and i1 %1495, %1497
  %1500 = and i1 %1498, %1499
  %1501 = extractelement <8 x float> %1493, i32 %1496
  %1502 = select i1 %1500, float %1501, float 0.000000e+00
  %1503 = insertelement <8 x float> poison, float %1502, i64 0
  %1504 = xor i1 %1500, true
  %1505 = and i1 %1498, %1504
  %1506 = insertelement <8 x i1> poison, i1 %1505, i64 0
  %1507 = extractelement <8 x i32> %.spill.load266, i64 1
  %1508 = icmp ult i32 %1507, 8
  %1509 = select i1 %1508, i32 %1507, i32 0
  %1510 = extractelement <8 x i1> %62, i32 %1509
  %1511 = extractelement <8 x i1> %62, i64 1
  %1512 = and i1 %1508, %1510
  %1513 = and i1 %1511, %1512
  %1514 = extractelement <8 x float> %1493, i32 %1509
  %1515 = select i1 %1513, float %1514, float 0.000000e+00
  %1516 = insertelement <8 x float> %1503, float %1515, i64 1
  %1517 = xor i1 %1513, true
  %1518 = and i1 %1511, %1517
  %1519 = insertelement <8 x i1> %1506, i1 %1518, i64 1
  %1520 = extractelement <8 x i32> %.spill.load266, i64 2
  %1521 = icmp ult i32 %1520, 8
  %1522 = select i1 %1521, i32 %1520, i32 0
  %1523 = extractelement <8 x i1> %62, i32 %1522
  %1524 = extractelement <8 x i1> %62, i64 2
  %1525 = and i1 %1521, %1523
  %1526 = and i1 %1524, %1525
  %1527 = extractelement <8 x float> %1493, i32 %1522
  %1528 = select i1 %1526, float %1527, float 0.000000e+00
  %1529 = insertelement <8 x float> %1516, float %1528, i64 2
  %1530 = xor i1 %1526, true
  %1531 = and i1 %1524, %1530
  %1532 = insertelement <8 x i1> %1519, i1 %1531, i64 2
  %1533 = extractelement <8 x i32> %.spill.load266, i64 3
  %1534 = icmp ult i32 %1533, 8
  %1535 = select i1 %1534, i32 %1533, i32 0
  %1536 = extractelement <8 x i1> %62, i32 %1535
  %1537 = extractelement <8 x i1> %62, i64 3
  %1538 = and i1 %1534, %1536
  %1539 = and i1 %1537, %1538
  %1540 = extractelement <8 x float> %1493, i32 %1535
  %1541 = select i1 %1539, float %1540, float 0.000000e+00
  %1542 = insertelement <8 x float> %1529, float %1541, i64 3
  %1543 = xor i1 %1539, true
  %1544 = and i1 %1537, %1543
  %1545 = insertelement <8 x i1> %1532, i1 %1544, i64 3
  %1546 = extractelement <8 x i32> %.spill.load266, i64 4
  %1547 = icmp ult i32 %1546, 8
  %1548 = select i1 %1547, i32 %1546, i32 0
  %1549 = extractelement <8 x i1> %62, i32 %1548
  %1550 = extractelement <8 x i1> %62, i64 4
  %1551 = and i1 %1547, %1549
  %1552 = and i1 %1550, %1551
  %1553 = extractelement <8 x float> %1493, i32 %1548
  %1554 = select i1 %1552, float %1553, float 0.000000e+00
  %1555 = insertelement <8 x float> %1542, float %1554, i64 4
  %1556 = xor i1 %1552, true
  %1557 = and i1 %1550, %1556
  %1558 = insertelement <8 x i1> %1545, i1 %1557, i64 4
  %1559 = extractelement <8 x i32> %.spill.load266, i64 5
  %1560 = icmp ult i32 %1559, 8
  %1561 = select i1 %1560, i32 %1559, i32 0
  %1562 = extractelement <8 x i1> %62, i32 %1561
  %1563 = extractelement <8 x i1> %62, i64 5
  %1564 = and i1 %1560, %1562
  %1565 = and i1 %1563, %1564
  %1566 = extractelement <8 x float> %1493, i32 %1561
  %1567 = select i1 %1565, float %1566, float 0.000000e+00
  %1568 = insertelement <8 x float> %1555, float %1567, i64 5
  %1569 = xor i1 %1565, true
  %1570 = and i1 %1563, %1569
  %1571 = insertelement <8 x i1> %1558, i1 %1570, i64 5
  %1572 = extractelement <8 x i32> %.spill.load266, i64 6
  %1573 = icmp ult i32 %1572, 8
  %1574 = select i1 %1573, i32 %1572, i32 0
  %1575 = extractelement <8 x i1> %62, i32 %1574
  %1576 = extractelement <8 x i1> %62, i64 6
  %1577 = and i1 %1573, %1575
  %1578 = and i1 %1576, %1577
  %1579 = extractelement <8 x float> %1493, i32 %1574
  %1580 = select i1 %1578, float %1579, float 0.000000e+00
  %1581 = insertelement <8 x float> %1568, float %1580, i64 6
  %1582 = xor i1 %1578, true
  %1583 = and i1 %1576, %1582
  %1584 = insertelement <8 x i1> %1571, i1 %1583, i64 6
  %1585 = extractelement <8 x i32> %.spill.load266, i64 7
  %1586 = icmp ult i32 %1585, 8
  %1587 = select i1 %1586, i32 %1585, i32 0
  %1588 = extractelement <8 x i1> %62, i32 %1587
  %1589 = extractelement <8 x i1> %62, i64 7
  %1590 = and i1 %1586, %1588
  %1591 = and i1 %1589, %1590
  %1592 = extractelement <8 x float> %1493, i32 %1587
  %1593 = select i1 %1591, float %1592, float 0.000000e+00
  %1594 = insertelement <8 x float> %1581, float %1593, i64 7
  %1595 = xor i1 %1591, true
  %1596 = and i1 %1589, %1595
  %1597 = insertelement <8 x i1> %1584, i1 %1596, i64 7
  %1598 = fadd <8 x float> %1493, %1594
  %1599 = extractelement <8 x i1> %62, i32 0
  %1600 = extractelement <8 x i1> %62, i64 0
  %1601 = and i1 true, %1599
  %1602 = and i1 %1600, %1601
  %1603 = extractelement <8 x float> %1598, i32 0
  %1604 = select i1 %1602, float %1603, float 0.000000e+00
  %1605 = insertelement <8 x float> poison, float %1604, i64 0
  %1606 = xor i1 %1602, true
  %1607 = and i1 %1600, %1606
  %1608 = insertelement <8 x i1> poison, i1 %1607, i64 0
  %1609 = extractelement <8 x i1> %62, i32 0
  %1610 = extractelement <8 x i1> %62, i64 1
  %1611 = and i1 true, %1609
  %1612 = and i1 %1610, %1611
  %1613 = extractelement <8 x float> %1598, i32 0
  %1614 = select i1 %1612, float %1613, float 0.000000e+00
  %1615 = insertelement <8 x float> %1605, float %1614, i64 1
  %1616 = xor i1 %1612, true
  %1617 = and i1 %1610, %1616
  %1618 = insertelement <8 x i1> %1608, i1 %1617, i64 1
  %1619 = extractelement <8 x i1> %62, i32 0
  %1620 = extractelement <8 x i1> %62, i64 2
  %1621 = and i1 true, %1619
  %1622 = and i1 %1620, %1621
  %1623 = extractelement <8 x float> %1598, i32 0
  %1624 = select i1 %1622, float %1623, float 0.000000e+00
  %1625 = insertelement <8 x float> %1615, float %1624, i64 2
  %1626 = xor i1 %1622, true
  %1627 = and i1 %1620, %1626
  %1628 = insertelement <8 x i1> %1618, i1 %1627, i64 2
  %1629 = extractelement <8 x i1> %62, i32 0
  %1630 = extractelement <8 x i1> %62, i64 3
  %1631 = and i1 true, %1629
  %1632 = and i1 %1630, %1631
  %1633 = extractelement <8 x float> %1598, i32 0
  %1634 = select i1 %1632, float %1633, float 0.000000e+00
  %1635 = insertelement <8 x float> %1625, float %1634, i64 3
  %1636 = xor i1 %1632, true
  %1637 = and i1 %1630, %1636
  %1638 = insertelement <8 x i1> %1628, i1 %1637, i64 3
  %1639 = extractelement <8 x i1> %62, i32 0
  %1640 = extractelement <8 x i1> %62, i64 4
  %1641 = and i1 true, %1639
  %1642 = and i1 %1640, %1641
  %1643 = extractelement <8 x float> %1598, i32 0
  %1644 = select i1 %1642, float %1643, float 0.000000e+00
  %1645 = insertelement <8 x float> %1635, float %1644, i64 4
  %1646 = xor i1 %1642, true
  %1647 = and i1 %1640, %1646
  %1648 = insertelement <8 x i1> %1638, i1 %1647, i64 4
  %1649 = extractelement <8 x i1> %62, i32 0
  %1650 = extractelement <8 x i1> %62, i64 5
  %1651 = and i1 true, %1649
  %1652 = and i1 %1650, %1651
  %1653 = extractelement <8 x float> %1598, i32 0
  %1654 = select i1 %1652, float %1653, float 0.000000e+00
  %1655 = insertelement <8 x float> %1645, float %1654, i64 5
  %1656 = xor i1 %1652, true
  %1657 = and i1 %1650, %1656
  %1658 = insertelement <8 x i1> %1648, i1 %1657, i64 5
  %1659 = extractelement <8 x i1> %62, i32 0
  %1660 = extractelement <8 x i1> %62, i64 6
  %1661 = and i1 true, %1659
  %1662 = and i1 %1660, %1661
  %1663 = extractelement <8 x float> %1598, i32 0
  %1664 = select i1 %1662, float %1663, float 0.000000e+00
  %1665 = insertelement <8 x float> %1655, float %1664, i64 6
  %1666 = xor i1 %1662, true
  %1667 = and i1 %1660, %1666
  %1668 = insertelement <8 x i1> %1658, i1 %1667, i64 6
  %1669 = extractelement <8 x i1> %62, i32 0
  %1670 = extractelement <8 x i1> %62, i64 7
  %1671 = and i1 true, %1669
  %1672 = and i1 %1670, %1671
  %1673 = extractelement <8 x float> %1598, i32 0
  %1674 = select i1 %1672, float %1673, float 0.000000e+00
  %1675 = insertelement <8 x float> %1665, float %1674, i64 7
  %1676 = xor i1 %1672, true
  %1677 = and i1 %1670, %1676
  %1678 = insertelement <8 x i1> %1668, i1 %1677, i64 7
  %1679 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1680 = bitcast <8 x i1> %62 to i8
  %1681 = call i8 @llvm.cttz.i8(i8 %1680, i1 false)
  %1682 = zext i8 %1681 to i32
  %1683 = select i1 %1679, i32 %1682, i32 0
  %1684 = extractelement <8 x float> %1675, i32 %1683
  %.spill.load267 = load float, ptr %.spill38, align 4
  %1685 = fadd float %.spill.load267, %1684
  store float %1685, ptr %.spill47, align 4
  br label %direct.schedule.36

direct.schedule.36:                               ; preds = %direct.schedule.35
  %1686 = load <8 x i64>, ptr %.slot48, align 64
  %1687 = select <8 x i1> %62, <8 x i64> zeroinitializer, <8 x i64> %1686
  store <8 x i64> %1687, ptr %.slot48, align 64
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state268 = load <8 x i64>, ptr %.slot48, align 64
  %1688 = icmp slt <8 x i64> %.state268, splat (i64 512)
  %1689 = extractelement <8 x i1> %1688, i32 0
  br i1 %1689, label %direct.true269, label %direct.false270

direct.schedule.38:                               ; preds = %direct.true269
  %.state271 = load <8 x i64>, ptr %.slot48, align 64
  %1690 = mul <8 x i64> %.state271, splat (i64 8)
  %.spill.load272 = load <8 x i64>, ptr %.spill, align 64
  %1691 = add <8 x i64> %1690, %.spill.load272
  %tile_snapshot.spill.load273 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1692 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load273, 0
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load273, 1
  %.state274 = load <8 x i64>, ptr %.slot48, align 64
  %1694 = mul <8 x i64> %.state274, splat (i64 32)
  %1695 = add <8 x i64> %1693, %1694
  %1696 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1692, 0
  %1697 = insertvalue { <8 x ptr>, <8 x i64> } %1696, <8 x i64> %1695, 1
  %1698 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1699 = extractvalue { <8 x ptr>, <8 x i64> } %1697, 1
  %1700 = extractelement <8 x ptr> %1698, i32 0
  %1701 = extractelement <8 x i64> %1699, i32 0
  %1702 = sub i64 %1701, 0
  %1703 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1704 = select i1 %1703, i64 %1702, i64 0
  %private.contiguous.address275 = getelementptr i8, ptr %1700, i64 %1704
  %private.contiguous.load276 = load <8 x float>, ptr %private.contiguous.address275, align 4
  %1705 = select <8 x i1> %62, <8 x float> %private.contiguous.load276, <8 x float> zeroinitializer
  %.spill.load277 = load float, ptr %.spill47, align 4
  %.splatinsert278 = insertelement <8 x float> poison, float %.spill.load277, i64 0
  %.splat279 = shufflevector <8 x float> %.splatinsert278, <8 x float> poison, <8 x i32> zeroinitializer
  %1706 = fdiv <8 x float> %1705, %.splat279
  %.spill.load280 = load <8 x i64>, ptr %.spill17, align 64
  %1707 = add <8 x i64> %.spill.load280, zeroinitializer
  %1708 = add <8 x i64> zeroinitializer, %1707
  %1709 = add <8 x i64> zeroinitializer, %1691
  %1710 = mul <8 x i64> %1708, splat (i64 4097)
  %1711 = add <8 x i64> %1710, %1709
  %1712 = extractvalue { ptr, i64 } %38, 0
  %1713 = extractelement <8 x i64> %1711, i32 0
  %1714 = sub i64 %1713, 0
  %1715 = mul i64 %1714, 4
  %buffer.contiguous.address281 = getelementptr i8, ptr %1712, i64 %1715
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1706, ptr %buffer.contiguous.address281, i32 1, <8 x i1> %62)
  %.state282 = load <8 x i64>, ptr %.slot48, align 64
  %1716 = add <8 x i64> %.state282, splat (i64 1)
  %1717 = load <8 x i64>, ptr %.slot48, align 64
  %1718 = select <8 x i1> %62, <8 x i64> %1716, <8 x i64> %1717
  store <8 x i64> %1718, ptr %.slot48, align 64
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false270
  %.spill.load283 = load <8 x i1>, ptr %.spill18, align 1
  %1719 = and <8 x i1> %62, %.spill.load283
  %1720 = xor <8 x i1> %.spill.load283, splat (i1 true)
  %1721 = and <8 x i1> %62, %1720
  %1722 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1719)
  %1723 = bitcast <8 x i1> %1719 to i8
  %1724 = call i8 @llvm.cttz.i8(i8 %1723, i1 false)
  %1725 = zext i8 %1724 to i32
  %1726 = select i1 %1722, i32 %1725, i32 0
  %.spill.load284 = load <8 x i64>, ptr %.spill, align 64
  %1727 = add <8 x i64> splat (i64 4096), %.spill.load284
  %tile_snapshot.spill.load285 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1728 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 0
  %1729 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 1
  %1730 = add <8 x i64> %1729, splat (i64 16384)
  %1731 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1728, 0
  %1732 = insertvalue { <8 x ptr>, <8 x i64> } %1731, <8 x i64> %1730, 1
  %1733 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1734 = extractvalue { <8 x ptr>, <8 x i64> } %1732, 1
  %1735 = extractelement <8 x ptr> %1733, i32 0
  %1736 = extractelement <8 x i64> %1734, i32 %1726
  %1737 = zext i32 %1726 to i64
  %1738 = mul i64 %1737, 4
  %1739 = sub i64 %1736, %1738
  %1740 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1719)
  %1741 = select i1 %1740, i64 %1739, i64 0
  %private.contiguous.address286 = getelementptr i8, ptr %1735, i64 %1741
  %private.contiguous.load287 = load <8 x float>, ptr %private.contiguous.address286, align 4
  %1742 = select <8 x i1> %1719, <8 x float> %private.contiguous.load287, <8 x float> zeroinitializer
  %.spill.load288 = load float, ptr %.spill47, align 4
  %.splatinsert289 = insertelement <8 x float> poison, float %.spill.load288, i64 0
  %.splat290 = shufflevector <8 x float> %.splatinsert289, <8 x float> poison, <8 x i32> zeroinitializer
  %1743 = fdiv <8 x float> %1742, %.splat290
  %.spill.load291 = load <8 x i64>, ptr %.spill17, align 64
  %1744 = add <8 x i64> %.spill.load291, zeroinitializer
  %1745 = add <8 x i64> zeroinitializer, %1744
  %1746 = add <8 x i64> zeroinitializer, %1727
  %1747 = mul <8 x i64> %1745, splat (i64 4097)
  %1748 = add <8 x i64> %1747, %1746
  %1749 = extractvalue { ptr, i64 } %38, 0
  %1750 = extractelement <8 x i64> %1748, i32 %1726
  %1751 = zext i32 %1726 to i64
  %1752 = sub i64 %1750, %1751
  %1753 = mul i64 %1752, 4
  %buffer.contiguous.address292 = getelementptr i8, ptr %1749, i64 %1753
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1743, ptr %buffer.contiguous.address292, i32 1, <8 x i1> %1719)
  %1754 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1721)
  %1755 = bitcast <8 x i1> %1721 to i8
  %1756 = call i8 @llvm.cttz.i8(i8 %1755, i1 false)
  %1757 = zext i8 %1756 to i32
  %1758 = select i1 %1754, i32 %1757, i32 0
  br label %direct.schedule.41

direct.schedule.41:                               ; preds = %direct.schedule.39
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true76:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false77:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true92:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false93:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true108:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false109:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true148:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false149:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.23

direct.true184:                                   ; preds = %direct.schedule.26
  br label %direct.schedule.27

direct.false185:                                  ; preds = %direct.schedule.26
  br label %direct.schedule.28

direct.true231:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false232:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true269:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false270:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, i32 immarg, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x i8>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maxnum.f32(float, float) #0

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #4 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #5

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 16416
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 49248
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 513, i64 1026, i64 1539, i64 2052, i64 2565, i64 3078, i64 3591>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 53352
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 69768
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill17 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill17, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill18 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill18, align 1
  %tile_snapshot.spill19 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill19, align 64
  %.slot20 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot20, align 64
  %.spill21 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill21, align 64
  %tile_snapshot.spill22 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill22, align 64
  %.slot23 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot23, align 64
  %.spill24 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill24, align 4
  %tile_snapshot.spill25 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill25, align 64
  %.slot26 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot26, align 64
  %.spill27 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill27, align 4
  %.slot28 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot28, align 64
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.slot30 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot30, align 32
  %.slot31 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot31, align 32
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.spill34 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill34, align 32
  %.spill35 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill35, align 32
  %.spill36 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill36, align 32
  %.spill37 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill37, align 4
  %.spill38 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill38, align 4
  %tile_snapshot.spill39 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill39, align 64
  %.slot40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot40, align 64
  %.slot41 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot41, align 64
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot46, align 32
  %.spill47 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill47, align 4
  %.slot48 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot48, align 64
  %15 = getelementptr i8, ptr %argument_buffer, i64 0
  %16 = load ptr, ptr %15, align 16
  %17 = getelementptr i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = insertvalue { ptr, i64 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i64 } %19, i64 %18, 1
  %21 = getelementptr i8, ptr %argument_buffer, i64 16
  %22 = load ptr, ptr %21, align 16
  %23 = getelementptr i8, ptr %21, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = insertvalue { ptr, i64 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i64 } %25, i64 %24, 1
  %27 = getelementptr i8, ptr %argument_buffer, i64 32
  %28 = load ptr, ptr %27, align 16
  %29 = getelementptr i8, ptr %27, i64 8
  %30 = load i64, ptr %29, align 8
  %31 = insertvalue { ptr, i64 } poison, ptr %28, 0
  %32 = insertvalue { ptr, i64 } %31, i64 %30, 1
  %33 = getelementptr i8, ptr %argument_buffer, i64 48
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = load i32, ptr %launch_config, align 4
  %40 = getelementptr i8, ptr %launch_config, i64 12
  %41 = load i32, ptr %40, align 4
  %42 = getelementptr i8, ptr %launch_config, i64 4
  %43 = load i32, ptr %42, align 4
  %44 = getelementptr i8, ptr %launch_config, i64 16
  %45 = load i32, ptr %44, align 4
  %46 = getelementptr i8, ptr %launch_config, i64 8
  %47 = load i32, ptr %46, align 4
  %48 = getelementptr i8, ptr %launch_config, i64 20
  %49 = load i32, ptr %48, align 4
  %50 = getelementptr i8, ptr %launch_config, i64 36
  %51 = load i32, ptr %50, align 4
  %.splatinsert49 = insertelement <8 x i32> poison, i32 %51, i64 0
  %.splat50 = shufflevector <8 x i32> %.splatinsert49, <8 x i32> poison, <8 x i32> zeroinitializer
  %52 = add <8 x i32> %.splat50, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %53 = mul i32 %39, 32
  %.splatinsert51 = insertelement <8 x i32> poison, i32 %53, i64 0
  %.splat52 = shufflevector <8 x i32> %.splatinsert51, <8 x i32> poison, <8 x i32> zeroinitializer
  %54 = add <8 x i32> %.splat52, %52
  %55 = mul i32 %43, 1
  %.splatinsert53 = insertelement <8 x i32> poison, i32 %55, i64 0
  %.splat54 = shufflevector <8 x i32> %.splatinsert53, <8 x i32> poison, <8 x i32> zeroinitializer
  %56 = add <8 x i32> %.splat54, zeroinitializer
  %57 = mul i32 %47, 1
  %.splatinsert55 = insertelement <8 x i32> poison, i32 %57, i64 0
  %.splat56 = shufflevector <8 x i32> %.splatinsert55, <8 x i32> poison, <8 x i32> zeroinitializer
  %58 = add <8 x i32> %.splat56, zeroinitializer
  %59 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %54, 0
  %60 = insertvalue [3 x <8 x i32>] %59, <8 x i32> %56, 1
  %61 = insertvalue [3 x <8 x i32>] %60, <8 x i32> %58, 2
  %.splatinsert57 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat58 = shufflevector <8 x i32> %.splatinsert57, <8 x i32> poison, <8 x i32> zeroinitializer
  %62 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat58
  %63 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  br i1 %63, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %64 = extractvalue [3 x <8 x i32>] %61, 0
  %65 = load <8 x i64>, ptr %.spill, align 64
  %66 = select <8 x i1> %62, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %65
  store <8 x i64> %66, ptr %.spill, align 64
  %67 = sub <8 x i32> %64, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %68 = select <8 x i1> %62, <8 x i32> %67, <8 x i32> zeroinitializer
  %69 = select <8 x i1> %62, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %70 = lshr <8 x i32> %68, %69
  %71 = zext <8 x i32> %70 to <8 x i64>
  %72 = select <8 x i1> %62, <8 x i64> %71, <8 x i64> zeroinitializer
  %73 = select <8 x i1> %62, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %74 = sdiv <8 x i64> %72, %73
  %75 = load <8 x i64>, ptr %.spill17, align 64
  %76 = select <8 x i1> %62, <8 x i64> %74, <8 x i64> %75
  store <8 x i64> %76, ptr %.spill17, align 64
  %77 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %78 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %79 = extractvalue { <8 x ptr>, <8 x i64> } %77, 0
  %80 = select <8 x i1> %62, <8 x ptr> %78, <8 x ptr> %79
  %81 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %82 = extractvalue { <8 x ptr>, <8 x i64> } %77, 1
  %83 = select <8 x i1> %62, <8 x i64> %81, <8 x i64> %82
  %84 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %80, 0
  %85 = insertvalue { <8 x ptr>, <8 x i64> } %84, <8 x i64> %83, 1
  store { <8 x ptr>, <8 x i64> } %85, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %86 = icmp slt i64 %.state, 512
  br i1 %86, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state59 = load i64, ptr %.slot, align 4
  %87 = mul i64 %.state59, 8
  %.splatinsert60 = insertelement <8 x i64> poison, i64 %87, i64 0
  %.splat61 = shufflevector <8 x i64> %.splatinsert60, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %88 = add <8 x i64> %.splat61, %.spill.load
  %.spill.load62 = load <8 x i64>, ptr %.spill17, align 64
  %89 = add <8 x i64> %.spill.load62, zeroinitializer
  %90 = add <8 x i64> zeroinitializer, %89
  %91 = add <8 x i64> zeroinitializer, %88
  %92 = mul <8 x i64> %90, splat (i64 4097)
  %93 = add <8 x i64> %92, %91
  %94 = extractvalue { ptr, i64 } %20, 0
  %95 = extractelement <8 x i64> %93, i32 0
  %96 = sub i64 %95, 0
  %97 = mul i64 %96, 4
  %buffer.contiguous.address = getelementptr i8, ptr %94, i64 %97
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %62, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state63 = load i64, ptr %.slot, align 4
  %.splatinsert64 = insertelement <8 x i64> poison, i64 %.state63, i64 0
  %.splat65 = shufflevector <8 x i64> %.splatinsert64, <8 x i64> poison, <8 x i32> zeroinitializer
  %100 = mul <8 x i64> %.splat65, splat (i64 32)
  %101 = add <8 x i64> %99, %100
  %102 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %98, 0
  %103 = insertvalue { <8 x ptr>, <8 x i64> } %102, <8 x i64> %101, 1
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %105 = extractvalue { <8 x ptr>, <8 x i64> } %103, 1
  %106 = extractelement <8 x ptr> %104, i32 0
  %107 = extractelement <8 x i64> %105, i32 0
  %108 = sub i64 %107, 0
  %109 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %110 = select i1 %109, i64 %108, i64 0
  %private.contiguous.address = getelementptr i8, ptr %106, i64 %110
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %111 = select <8 x i1> %62, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %111, ptr %private.contiguous.address, align 4
  %.state66 = load i64, ptr %.slot, align 4
  %112 = add i64 %.state66, 1
  store i64 %112, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load67 = load <8 x i64>, ptr %.spill, align 64
  %113 = icmp slt <8 x i64> %.spill.load67, splat (i64 1)
  %114 = load <8 x i1>, ptr %.spill18, align 1
  %115 = select <8 x i1> %62, <8 x i1> %113, <8 x i1> %114
  store <8 x i1> %115, ptr %.spill18, align 1
  %116 = and <8 x i1> %62, %113
  %117 = xor <8 x i1> %113, splat (i1 true)
  %118 = and <8 x i1> %62, %117
  %119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  %120 = bitcast <8 x i1> %116 to i8
  %121 = call i8 @llvm.cttz.i8(i8 %120, i1 false)
  %122 = zext i8 %121 to i32
  %123 = select i1 %119, i32 %122, i32 0
  %.spill.load68 = load <8 x i64>, ptr %.spill, align 64
  %124 = add <8 x i64> splat (i64 4096), %.spill.load68
  %.spill.load69 = load <8 x i64>, ptr %.spill17, align 64
  %125 = add <8 x i64> %.spill.load69, zeroinitializer
  %126 = add <8 x i64> zeroinitializer, %125
  %127 = add <8 x i64> zeroinitializer, %124
  %128 = mul <8 x i64> %126, splat (i64 4097)
  %129 = add <8 x i64> %128, %127
  %130 = extractvalue { ptr, i64 } %20, 0
  %131 = select <8 x i1> %116, <8 x i64> %129, <8 x i64> zeroinitializer
  %132 = extractelement <8 x i64> %131, i32 %123
  %133 = zext i32 %123 to i64
  %134 = sub i64 %132, %133
  %135 = mul i64 %134, 4
  %buffer.contiguous.address70 = getelementptr i8, ptr %130, i64 %135
  %buffer.contiguous.load71 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address70, i32 1, <8 x i1> %116, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load72 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load72, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load72, 1
  %138 = add <8 x i64> %137, splat (i64 16384)
  %139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %140 = insertvalue { <8 x ptr>, <8 x i64> } %139, <8 x i64> %138, 1
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %140, 1
  %143 = extractelement <8 x ptr> %141, i32 0
  %144 = extractelement <8 x i64> %142, i32 %123
  %145 = zext i32 %123 to i64
  %146 = mul i64 %145, 4
  %147 = sub i64 %144, %146
  %148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %116)
  %149 = select i1 %148, i64 %147, i64 0
  %private.contiguous.address73 = getelementptr i8, ptr %143, i64 %149
  %private.contiguous.preserve74 = load <8 x float>, ptr %private.contiguous.address73, align 4
  %150 = select <8 x i1> %116, <8 x float> %buffer.contiguous.load71, <8 x float> %private.contiguous.preserve74
  store <8 x float> %150, ptr %private.contiguous.address73, align 4
  %151 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %118)
  %152 = bitcast <8 x i1> %118 to i8
  %153 = call i8 @llvm.cttz.i8(i8 %152, i1 false)
  %154 = zext i8 %153 to i32
  %155 = select i1 %151, i32 %154, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  %156 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %156, 0
  %159 = select <8 x i1> %62, <8 x ptr> %157, <8 x ptr> %158
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %156, 1
  %162 = select <8 x i1> %62, <8 x i64> %160, <8 x i64> %161
  %163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %159, 0
  %164 = insertvalue { <8 x ptr>, <8 x i64> } %163, <8 x i64> %162, 1
  store { <8 x ptr>, <8 x i64> } %164, ptr %tile_snapshot.spill19, align 64
  %165 = load <8 x i64>, ptr %.slot20, align 64
  %166 = select <8 x i1> %62, <8 x i64> zeroinitializer, <8 x i64> %165
  store <8 x i64> %166, ptr %.slot20, align 64
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state75 = load <8 x i64>, ptr %.slot20, align 64
  %167 = icmp slt <8 x i64> %.state75, splat (i64 512)
  %168 = extractelement <8 x i1> %167, i32 0
  br i1 %168, label %direct.true76, label %direct.false77

direct.schedule.7:                                ; preds = %direct.true76
  %.state78 = load <8 x i64>, ptr %.slot20, align 64
  %169 = mul <8 x i64> %.state78, splat (i64 8)
  %.spill.load79 = load <8 x i64>, ptr %.spill, align 64
  %170 = add <8 x i64> %169, %.spill.load79
  %tile_snapshot.spill.load80 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 0
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 1
  %.state81 = load <8 x i64>, ptr %.slot20, align 64
  %173 = mul <8 x i64> %.state81, splat (i64 64)
  %174 = add <8 x i64> %172, %173
  %175 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %171, 0
  %176 = insertvalue { <8 x ptr>, <8 x i64> } %175, <8 x i64> %174, 1
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %176, 1
  %179 = extractelement <8 x ptr> %177, i32 0
  %180 = extractelement <8 x i64> %178, i32 0
  %181 = sub i64 %180, 0
  %182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %183 = select i1 %182, i64 %181, i64 0
  %private.contiguous.address82 = getelementptr i8, ptr %179, i64 %183
  %private.contiguous.preserve83 = load <8 x i64>, ptr %private.contiguous.address82, align 8
  %184 = select <8 x i1> %62, <8 x i64> %170, <8 x i64> %private.contiguous.preserve83
  store <8 x i64> %184, ptr %private.contiguous.address82, align 8
  %.state84 = load <8 x i64>, ptr %.slot20, align 64
  %185 = add <8 x i64> %.state84, splat (i64 1)
  %186 = load <8 x i64>, ptr %.slot20, align 64
  %187 = select <8 x i1> %62, <8 x i64> %185, <8 x i64> %186
  store <8 x i64> %187, ptr %.slot20, align 64
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false77
  %.spill.load85 = load <8 x i1>, ptr %.spill18, align 1
  %188 = and <8 x i1> %62, %.spill.load85
  %189 = xor <8 x i1> %.spill.load85, splat (i1 true)
  %190 = and <8 x i1> %62, %189
  %191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %188)
  %192 = bitcast <8 x i1> %188 to i8
  %193 = call i8 @llvm.cttz.i8(i8 %192, i1 false)
  %194 = zext i8 %193 to i32
  %195 = select i1 %191, i32 %194, i32 0
  %.spill.load86 = load <8 x i64>, ptr %.spill, align 64
  %196 = add <8 x i64> splat (i64 4096), %.spill.load86
  %tile_snapshot.spill.load87 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %197 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 0
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 1
  %199 = add <8 x i64> %198, splat (i64 32768)
  %200 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %197, 0
  %201 = insertvalue { <8 x ptr>, <8 x i64> } %200, <8 x i64> %199, 1
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %201, 1
  %204 = extractelement <8 x ptr> %202, i32 0
  %205 = extractelement <8 x i64> %203, i32 %195
  %206 = zext i32 %195 to i64
  %207 = mul i64 %206, 8
  %208 = sub i64 %205, %207
  %209 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %188)
  %210 = select i1 %209, i64 %208, i64 0
  %private.contiguous.address88 = getelementptr i8, ptr %204, i64 %210
  %private.contiguous.preserve89 = load <8 x i64>, ptr %private.contiguous.address88, align 8
  %211 = select <8 x i1> %188, <8 x i64> %196, <8 x i64> %private.contiguous.preserve89
  store <8 x i64> %211, ptr %private.contiguous.address88, align 8
  %212 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %190)
  %213 = bitcast <8 x i1> %190 to i8
  %214 = call i8 @llvm.cttz.i8(i8 %213, i1 false)
  %215 = zext i8 %214 to i32
  %216 = select i1 %212, i32 %215, i32 0
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %.spill.load90 = load <8 x i64>, ptr %.spill17, align 64
  %217 = select <8 x i1> %62, <8 x i64> %.spill.load90, <8 x i64> zeroinitializer
  %218 = select <8 x i1> %62, <8 x i64> splat (i64 4097), <8 x i64> splat (i64 1)
  %219 = srem <8 x i64> %217, %218
  %220 = load <8 x i64>, ptr %.spill21, align 64
  %221 = select <8 x i1> %62, <8 x i64> %219, <8 x i64> %220
  store <8 x i64> %221, ptr %.spill21, align 64
  %222 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %222, 0
  %225 = select <8 x i1> %62, <8 x ptr> %223, <8 x ptr> %224
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %222, 1
  %228 = select <8 x i1> %62, <8 x i64> %226, <8 x i64> %227
  %229 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %225, 0
  %230 = insertvalue { <8 x ptr>, <8 x i64> } %229, <8 x i64> %228, 1
  store { <8 x ptr>, <8 x i64> } %230, ptr %tile_snapshot.spill22, align 64
  %231 = load <8 x i64>, ptr %.slot23, align 64
  %232 = select <8 x i1> %62, <8 x i64> zeroinitializer, <8 x i64> %231
  store <8 x i64> %232, ptr %.slot23, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state91 = load <8 x i64>, ptr %.slot23, align 64
  %233 = icmp slt <8 x i64> %.state91, splat (i64 512)
  %234 = extractelement <8 x i1> %233, i32 0
  br i1 %234, label %direct.true92, label %direct.false93

direct.schedule.12:                               ; preds = %direct.true92
  %tile_snapshot.spill.load94 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 0
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 1
  %.state95 = load <8 x i64>, ptr %.slot23, align 64
  %237 = mul <8 x i64> %.state95, splat (i64 64)
  %238 = add <8 x i64> %236, %237
  %239 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %235, 0
  %240 = insertvalue { <8 x ptr>, <8 x i64> } %239, <8 x i64> %238, 1
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %242 = extractvalue { <8 x ptr>, <8 x i64> } %240, 1
  %243 = extractelement <8 x ptr> %241, i32 0
  %244 = extractelement <8 x i64> %242, i32 0
  %245 = sub i64 %244, 0
  %246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %247 = select i1 %246, i64 %245, i64 0
  %private.contiguous.address96 = getelementptr i8, ptr %243, i64 %247
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address96, align 8
  %248 = select <8 x i1> %62, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load97 = load <8 x i64>, ptr %.spill21, align 64
  %249 = icmp sle <8 x i64> %248, %.spill.load97
  %tile_snapshot.spill.load98 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %250 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 0
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 1
  %.state99 = load <8 x i64>, ptr %.slot23, align 64
  %252 = add <8 x i64> %251, %.state99
  %253 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %250, 0
  %254 = insertvalue { <8 x ptr>, <8 x i64> } %253, <8 x i64> %252, 1
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %254, 0
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %254, 1
  %257 = getelementptr i8, <8 x ptr> %255, <8 x i64> %256
  %258 = zext <8 x i1> %249 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %258, <8 x ptr> %257, i32 1, <8 x i1> %62)
  %.state100 = load <8 x i64>, ptr %.slot23, align 64
  %259 = add <8 x i64> %.state100, splat (i64 1)
  %260 = load <8 x i64>, ptr %.slot23, align 64
  %261 = select <8 x i1> %62, <8 x i64> %259, <8 x i64> %260
  store <8 x i64> %261, ptr %.slot23, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false93
  %.spill.load101 = load <8 x i1>, ptr %.spill18, align 1
  %262 = and <8 x i1> %62, %.spill.load101
  %263 = xor <8 x i1> %.spill.load101, splat (i1 true)
  %264 = and <8 x i1> %62, %263
  %265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %262)
  %266 = bitcast <8 x i1> %262 to i8
  %267 = call i8 @llvm.cttz.i8(i8 %266, i1 false)
  %268 = zext i8 %267 to i32
  %269 = select i1 %265, i32 %268, i32 0
  %tile_snapshot.spill.load102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 0
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 1
  %272 = add <8 x i64> %271, splat (i64 32768)
  %273 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %270, 0
  %274 = insertvalue { <8 x ptr>, <8 x i64> } %273, <8 x i64> %272, 1
  %275 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %274, 1
  %277 = extractelement <8 x ptr> %275, i32 0
  %278 = extractelement <8 x i64> %276, i32 %269
  %279 = zext i32 %269 to i64
  %280 = mul i64 %279, 8
  %281 = sub i64 %278, %280
  %282 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %262)
  %283 = select i1 %282, i64 %281, i64 0
  %private.contiguous.address103 = getelementptr i8, ptr %277, i64 %283
  %private.contiguous.load104 = load <8 x i64>, ptr %private.contiguous.address103, align 8
  %284 = select <8 x i1> %262, <8 x i64> %private.contiguous.load104, <8 x i64> zeroinitializer
  %.spill.load105 = load <8 x i64>, ptr %.spill21, align 64
  %285 = icmp sle <8 x i64> %284, %.spill.load105
  %tile_snapshot.spill.load106 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 1
  %288 = add <8 x i64> %287, splat (i64 512)
  %289 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %286, 0
  %290 = insertvalue { <8 x ptr>, <8 x i64> } %289, <8 x i64> %288, 1
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %290, 0
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %290, 1
  %293 = getelementptr i8, <8 x ptr> %291, <8 x i64> %292
  %294 = zext <8 x i1> %285 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %294, <8 x ptr> %293, i32 1, <8 x i1> %262)
  %295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %264)
  %296 = bitcast <8 x i1> %264 to i8
  %297 = call i8 @llvm.cttz.i8(i8 %296, i1 false)
  %298 = zext i8 %297 to i32
  %299 = select i1 %295, i32 %298, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  store float 0xC6293E5940000000, ptr %.spill24, align 4
  %300 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %302 = extractvalue { <8 x ptr>, <8 x i64> } %300, 0
  %303 = select <8 x i1> %62, <8 x ptr> %301, <8 x ptr> %302
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %300, 1
  %306 = select <8 x i1> %62, <8 x i64> %304, <8 x i64> %305
  %307 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %303, 0
  %308 = insertvalue { <8 x ptr>, <8 x i64> } %307, <8 x i64> %306, 1
  store { <8 x ptr>, <8 x i64> } %308, ptr %tile_snapshot.spill25, align 64
  %309 = load <8 x i64>, ptr %.slot26, align 64
  %310 = select <8 x i1> %62, <8 x i64> zeroinitializer, <8 x i64> %309
  store <8 x i64> %310, ptr %.slot26, align 64
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state107 = load <8 x i64>, ptr %.slot26, align 64
  %311 = icmp slt <8 x i64> %.state107, splat (i64 512)
  %312 = extractelement <8 x i1> %311, i32 0
  br i1 %312, label %direct.true108, label %direct.false109

direct.schedule.17:                               ; preds = %direct.true108
  %tile_snapshot.spill.load110 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load110, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load110, 1
  %.state111 = load <8 x i64>, ptr %.slot26, align 64
  %315 = add <8 x i64> %314, %.state111
  %316 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %313, 0
  %317 = insertvalue { <8 x ptr>, <8 x i64> } %316, <8 x i64> %315, 1
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %317, 0
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %317, 1
  %320 = getelementptr i8, <8 x ptr> %318, <8 x i64> %319
  %321 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %320, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %322 = icmp ne <8 x i8> %321, zeroinitializer
  %tile_snapshot.spill.load112 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load112, 0
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load112, 1
  %.state113 = load <8 x i64>, ptr %.slot26, align 64
  %325 = mul <8 x i64> %.state113, splat (i64 32)
  %326 = add <8 x i64> %324, %325
  %327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %323, 0
  %328 = insertvalue { <8 x ptr>, <8 x i64> } %327, <8 x i64> %326, 1
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %328, 1
  %331 = extractelement <8 x ptr> %329, i32 0
  %332 = extractelement <8 x i64> %330, i32 0
  %333 = sub i64 %332, 0
  %334 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %335 = select i1 %334, i64 %333, i64 0
  %private.contiguous.address114 = getelementptr i8, ptr %331, i64 %335
  %private.contiguous.load115 = load <8 x float>, ptr %private.contiguous.address114, align 4
  %336 = select <8 x i1> %62, <8 x float> %private.contiguous.load115, <8 x float> zeroinitializer
  %.spill.load116 = load float, ptr %.spill24, align 4
  %.splatinsert117 = insertelement <8 x float> poison, float %.spill.load116, i64 0
  %.splat118 = shufflevector <8 x float> %.splatinsert117, <8 x float> poison, <8 x i32> zeroinitializer
  %337 = select <8 x i1> %322, <8 x float> %336, <8 x float> %.splat118
  %tile_snapshot.spill.load119 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 1
  %.state120 = load <8 x i64>, ptr %.slot26, align 64
  %340 = mul <8 x i64> %.state120, splat (i64 32)
  %341 = add <8 x i64> %339, %340
  %342 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %338, 0
  %343 = insertvalue { <8 x ptr>, <8 x i64> } %342, <8 x i64> %341, 1
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %343, 1
  %346 = extractelement <8 x ptr> %344, i32 0
  %347 = extractelement <8 x i64> %345, i32 0
  %348 = sub i64 %347, 0
  %349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %350 = select i1 %349, i64 %348, i64 0
  %private.contiguous.address121 = getelementptr i8, ptr %346, i64 %350
  %private.contiguous.preserve122 = load <8 x float>, ptr %private.contiguous.address121, align 4
  %351 = select <8 x i1> %62, <8 x float> %337, <8 x float> %private.contiguous.preserve122
  store <8 x float> %351, ptr %private.contiguous.address121, align 4
  %.state123 = load <8 x i64>, ptr %.slot26, align 64
  %352 = add <8 x i64> %.state123, splat (i64 1)
  %353 = load <8 x i64>, ptr %.slot26, align 64
  %354 = select <8 x i1> %62, <8 x i64> %352, <8 x i64> %353
  store <8 x i64> %354, ptr %.slot26, align 64
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false109
  %.spill.load124 = load <8 x i1>, ptr %.spill18, align 1
  %355 = and <8 x i1> %62, %.spill.load124
  %356 = xor <8 x i1> %.spill.load124, splat (i1 true)
  %357 = and <8 x i1> %62, %356
  %358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %355)
  %359 = bitcast <8 x i1> %355 to i8
  %360 = call i8 @llvm.cttz.i8(i8 %359, i1 false)
  %361 = zext i8 %360 to i32
  %362 = select i1 %358, i32 %361, i32 0
  %tile_snapshot.spill.load125 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 1
  %365 = add <8 x i64> %364, splat (i64 512)
  %366 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %363, 0
  %367 = insertvalue { <8 x ptr>, <8 x i64> } %366, <8 x i64> %365, 1
  %368 = extractvalue { <8 x ptr>, <8 x i64> } %367, 0
  %369 = extractvalue { <8 x ptr>, <8 x i64> } %367, 1
  %370 = getelementptr i8, <8 x ptr> %368, <8 x i64> %369
  %371 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %370, i32 1, <8 x i1> %355, <8 x i8> zeroinitializer)
  %372 = icmp ne <8 x i8> %371, zeroinitializer
  %tile_snapshot.spill.load126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 0
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 1
  %375 = add <8 x i64> %374, splat (i64 16384)
  %376 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %373, 0
  %377 = insertvalue { <8 x ptr>, <8 x i64> } %376, <8 x i64> %375, 1
  %378 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %379 = extractvalue { <8 x ptr>, <8 x i64> } %377, 1
  %380 = extractelement <8 x ptr> %378, i32 0
  %381 = extractelement <8 x i64> %379, i32 %362
  %382 = zext i32 %362 to i64
  %383 = mul i64 %382, 4
  %384 = sub i64 %381, %383
  %385 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %355)
  %386 = select i1 %385, i64 %384, i64 0
  %private.contiguous.address127 = getelementptr i8, ptr %380, i64 %386
  %private.contiguous.load128 = load <8 x float>, ptr %private.contiguous.address127, align 4
  %387 = select <8 x i1> %355, <8 x float> %private.contiguous.load128, <8 x float> zeroinitializer
  %.spill.load129 = load float, ptr %.spill24, align 4
  %.splatinsert130 = insertelement <8 x float> poison, float %.spill.load129, i64 0
  %.splat131 = shufflevector <8 x float> %.splatinsert130, <8 x float> poison, <8 x i32> zeroinitializer
  %388 = select <8 x i1> %372, <8 x float> %387, <8 x float> %.splat131
  %tile_snapshot.spill.load132 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 0
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 1
  %391 = add <8 x i64> %390, splat (i64 16384)
  %392 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %389, 0
  %393 = insertvalue { <8 x ptr>, <8 x i64> } %392, <8 x i64> %391, 1
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %393, 1
  %396 = extractelement <8 x ptr> %394, i32 0
  %397 = extractelement <8 x i64> %395, i32 %362
  %398 = zext i32 %362 to i64
  %399 = mul i64 %398, 4
  %400 = sub i64 %397, %399
  %401 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %355)
  %402 = select i1 %401, i64 %400, i64 0
  %private.contiguous.address133 = getelementptr i8, ptr %396, i64 %402
  %private.contiguous.preserve134 = load <8 x float>, ptr %private.contiguous.address133, align 4
  %403 = select <8 x i1> %355, <8 x float> %388, <8 x float> %private.contiguous.preserve134
  store <8 x float> %403, ptr %private.contiguous.address133, align 4
  %404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %357)
  %405 = bitcast <8 x i1> %357 to i8
  %406 = call i8 @llvm.cttz.i8(i8 %405, i1 false)
  %407 = zext i8 %406 to i32
  %408 = select i1 %404, i32 %407, i32 0
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  store float 0xFFF0000000000000, ptr %.spill27, align 4
  %tile_snapshot.spill.load135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 0
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 1
  %411 = add <8 x i64> %410, zeroinitializer
  %412 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %409, 0
  %413 = insertvalue { <8 x ptr>, <8 x i64> } %412, <8 x i64> %411, 1
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %413, 1
  %416 = extractelement <8 x ptr> %414, i32 0
  %417 = extractelement <8 x i64> %415, i32 0
  %418 = sub i64 %417, 0
  %419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %420 = select i1 %419, i64 %418, i64 0
  %private.contiguous.address136 = getelementptr i8, ptr %416, i64 %420
  %private.contiguous.load137 = load <8 x float>, ptr %private.contiguous.address136, align 4
  %421 = select <8 x i1> %62, <8 x float> %private.contiguous.load137, <8 x float> zeroinitializer
  %tile_snapshot.spill.load138 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 1
  %424 = add <8 x i64> %423, splat (i64 32)
  %425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %422, 0
  %426 = insertvalue { <8 x ptr>, <8 x i64> } %425, <8 x i64> %424, 1
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %426, 1
  %429 = extractelement <8 x ptr> %427, i32 0
  %430 = extractelement <8 x i64> %428, i32 0
  %431 = sub i64 %430, 0
  %432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %433 = select i1 %432, i64 %431, i64 0
  %private.contiguous.address139 = getelementptr i8, ptr %429, i64 %433
  %private.contiguous.load140 = load <8 x float>, ptr %private.contiguous.address139, align 4
  %434 = select <8 x i1> %62, <8 x float> %private.contiguous.load140, <8 x float> zeroinitializer
  %tile_snapshot.spill.load141 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %435 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 0
  %436 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 1
  %437 = add <8 x i64> %436, splat (i64 64)
  %438 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %435, 0
  %439 = insertvalue { <8 x ptr>, <8 x i64> } %438, <8 x i64> %437, 1
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %441 = extractvalue { <8 x ptr>, <8 x i64> } %439, 1
  %442 = extractelement <8 x ptr> %440, i32 0
  %443 = extractelement <8 x i64> %441, i32 0
  %444 = sub i64 %443, 0
  %445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %446 = select i1 %445, i64 %444, i64 0
  %private.contiguous.address142 = getelementptr i8, ptr %442, i64 %446
  %private.contiguous.load143 = load <8 x float>, ptr %private.contiguous.address142, align 4
  %447 = select <8 x i1> %62, <8 x float> %private.contiguous.load143, <8 x float> zeroinitializer
  %tile_snapshot.spill.load144 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 0
  %449 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 1
  %450 = add <8 x i64> %449, splat (i64 96)
  %451 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %448, 0
  %452 = insertvalue { <8 x ptr>, <8 x i64> } %451, <8 x i64> %450, 1
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %454 = extractvalue { <8 x ptr>, <8 x i64> } %452, 1
  %455 = extractelement <8 x ptr> %453, i32 0
  %456 = extractelement <8 x i64> %454, i32 0
  %457 = sub i64 %456, 0
  %458 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %459 = select i1 %458, i64 %457, i64 0
  %private.contiguous.address145 = getelementptr i8, ptr %455, i64 %459
  %private.contiguous.load146 = load <8 x float>, ptr %private.contiguous.address145, align 4
  %460 = select <8 x i1> %62, <8 x float> %private.contiguous.load146, <8 x float> zeroinitializer
  %461 = load <8 x i64>, ptr %.slot28, align 64
  %462 = select <8 x i1> %62, <8 x i64> splat (i64 4), <8 x i64> %461
  store <8 x i64> %462, ptr %.slot28, align 64
  %463 = load <8 x float>, ptr %.slot29, align 32
  %464 = select <8 x i1> %62, <8 x float> %421, <8 x float> %463
  store <8 x float> %464, ptr %.slot29, align 32
  %465 = load <8 x float>, ptr %.slot30, align 32
  %466 = select <8 x i1> %62, <8 x float> %434, <8 x float> %465
  store <8 x float> %466, ptr %.slot30, align 32
  %467 = load <8 x float>, ptr %.slot31, align 32
  %468 = select <8 x i1> %62, <8 x float> %447, <8 x float> %467
  store <8 x float> %468, ptr %.slot31, align 32
  %469 = load <8 x float>, ptr %.slot32, align 32
  %470 = select <8 x i1> %62, <8 x float> %460, <8 x float> %469
  store <8 x float> %470, ptr %.slot32, align 32
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.22, %direct.schedule.20
  %.state147 = load <8 x i64>, ptr %.slot28, align 64
  %471 = icmp slt <8 x i64> %.state147, splat (i64 512)
  %472 = extractelement <8 x i1> %471, i32 0
  br i1 %472, label %direct.true148, label %direct.false149

direct.schedule.22:                               ; preds = %direct.true148
  %.state150 = load <8 x i64>, ptr %.slot28, align 64
  %473 = add <8 x i64> %.state150, zeroinitializer
  %tile_snapshot.spill.load151 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load151, 0
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load151, 1
  %476 = mul <8 x i64> %473, splat (i64 32)
  %477 = add <8 x i64> %475, %476
  %478 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %474, 0
  %479 = insertvalue { <8 x ptr>, <8 x i64> } %478, <8 x i64> %477, 1
  %480 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %479, 1
  %482 = extractelement <8 x ptr> %480, i32 0
  %483 = extractelement <8 x i64> %481, i32 0
  %484 = sub i64 %483, 0
  %485 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %486 = select i1 %485, i64 %484, i64 0
  %private.contiguous.address152 = getelementptr i8, ptr %482, i64 %486
  %private.contiguous.load153 = load <8 x float>, ptr %private.contiguous.address152, align 4
  %487 = select <8 x i1> %62, <8 x float> %private.contiguous.load153, <8 x float> zeroinitializer
  %.state154 = load <8 x float>, ptr %.slot29, align 32
  %488 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state154, <8 x float> %487)
  %.state155 = load <8 x i64>, ptr %.slot28, align 64
  %489 = add <8 x i64> %.state155, splat (i64 1)
  %tile_snapshot.spill.load156 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load156, 0
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load156, 1
  %492 = mul <8 x i64> %489, splat (i64 32)
  %493 = add <8 x i64> %491, %492
  %494 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %490, 0
  %495 = insertvalue { <8 x ptr>, <8 x i64> } %494, <8 x i64> %493, 1
  %496 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %497 = extractvalue { <8 x ptr>, <8 x i64> } %495, 1
  %498 = extractelement <8 x ptr> %496, i32 0
  %499 = extractelement <8 x i64> %497, i32 0
  %500 = sub i64 %499, 0
  %501 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %502 = select i1 %501, i64 %500, i64 0
  %private.contiguous.address157 = getelementptr i8, ptr %498, i64 %502
  %private.contiguous.load158 = load <8 x float>, ptr %private.contiguous.address157, align 4
  %503 = select <8 x i1> %62, <8 x float> %private.contiguous.load158, <8 x float> zeroinitializer
  %.state159 = load <8 x float>, ptr %.slot30, align 32
  %504 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state159, <8 x float> %503)
  %.state160 = load <8 x i64>, ptr %.slot28, align 64
  %505 = add <8 x i64> %.state160, splat (i64 2)
  %tile_snapshot.spill.load161 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 0
  %507 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load161, 1
  %508 = mul <8 x i64> %505, splat (i64 32)
  %509 = add <8 x i64> %507, %508
  %510 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %506, 0
  %511 = insertvalue { <8 x ptr>, <8 x i64> } %510, <8 x i64> %509, 1
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %511, 1
  %514 = extractelement <8 x ptr> %512, i32 0
  %515 = extractelement <8 x i64> %513, i32 0
  %516 = sub i64 %515, 0
  %517 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %518 = select i1 %517, i64 %516, i64 0
  %private.contiguous.address162 = getelementptr i8, ptr %514, i64 %518
  %private.contiguous.load163 = load <8 x float>, ptr %private.contiguous.address162, align 4
  %519 = select <8 x i1> %62, <8 x float> %private.contiguous.load163, <8 x float> zeroinitializer
  %.state164 = load <8 x float>, ptr %.slot31, align 32
  %520 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state164, <8 x float> %519)
  %.state165 = load <8 x i64>, ptr %.slot28, align 64
  %521 = add <8 x i64> %.state165, splat (i64 3)
  %tile_snapshot.spill.load166 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %522 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load166, 0
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load166, 1
  %524 = mul <8 x i64> %521, splat (i64 32)
  %525 = add <8 x i64> %523, %524
  %526 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %522, 0
  %527 = insertvalue { <8 x ptr>, <8 x i64> } %526, <8 x i64> %525, 1
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %527, 1
  %530 = extractelement <8 x ptr> %528, i32 0
  %531 = extractelement <8 x i64> %529, i32 0
  %532 = sub i64 %531, 0
  %533 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %534 = select i1 %533, i64 %532, i64 0
  %private.contiguous.address167 = getelementptr i8, ptr %530, i64 %534
  %private.contiguous.load168 = load <8 x float>, ptr %private.contiguous.address167, align 4
  %535 = select <8 x i1> %62, <8 x float> %private.contiguous.load168, <8 x float> zeroinitializer
  %.state169 = load <8 x float>, ptr %.slot32, align 32
  %536 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state169, <8 x float> %535)
  %.state170 = load <8 x i64>, ptr %.slot28, align 64
  %537 = add <8 x i64> %.state170, splat (i64 4)
  %538 = load <8 x i64>, ptr %.slot28, align 64
  %539 = select <8 x i1> %62, <8 x i64> %537, <8 x i64> %538
  store <8 x i64> %539, ptr %.slot28, align 64
  %540 = load <8 x float>, ptr %.slot29, align 32
  %541 = select <8 x i1> %62, <8 x float> %488, <8 x float> %540
  store <8 x float> %541, ptr %.slot29, align 32
  %542 = load <8 x float>, ptr %.slot30, align 32
  %543 = select <8 x i1> %62, <8 x float> %504, <8 x float> %542
  store <8 x float> %543, ptr %.slot30, align 32
  %544 = load <8 x float>, ptr %.slot31, align 32
  %545 = select <8 x i1> %62, <8 x float> %520, <8 x float> %544
  store <8 x float> %545, ptr %.slot31, align 32
  %546 = load <8 x float>, ptr %.slot32, align 32
  %547 = select <8 x i1> %62, <8 x float> %536, <8 x float> %546
  store <8 x float> %547, ptr %.slot32, align 32
  br label %direct.schedule.21

direct.schedule.23:                               ; preds = %direct.false149
  %.spill.load171 = load <8 x i1>, ptr %.spill18, align 1
  %548 = and <8 x i1> %62, %.spill.load171
  %549 = xor <8 x i1> %.spill.load171, splat (i1 true)
  %550 = and <8 x i1> %62, %549
  %551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %548)
  %552 = bitcast <8 x i1> %548 to i8
  %553 = call i8 @llvm.cttz.i8(i8 %552, i1 false)
  %554 = zext i8 %553 to i32
  %555 = select i1 %551, i32 %554, i32 0
  %tile_snapshot.spill.load172 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %556 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load172, 0
  %557 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load172, 1
  %558 = add <8 x i64> %557, splat (i64 16384)
  %559 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %556, 0
  %560 = insertvalue { <8 x ptr>, <8 x i64> } %559, <8 x i64> %558, 1
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %562 = extractvalue { <8 x ptr>, <8 x i64> } %560, 1
  %563 = extractelement <8 x ptr> %561, i32 0
  %564 = extractelement <8 x i64> %562, i32 %555
  %565 = zext i32 %555 to i64
  %566 = mul i64 %565, 4
  %567 = sub i64 %564, %566
  %568 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %548)
  %569 = select i1 %568, i64 %567, i64 0
  %private.contiguous.address173 = getelementptr i8, ptr %563, i64 %569
  %private.contiguous.load174 = load <8 x float>, ptr %private.contiguous.address173, align 4
  %570 = select <8 x i1> %548, <8 x float> %private.contiguous.load174, <8 x float> zeroinitializer
  %.state175 = load <8 x float>, ptr %.slot29, align 32
  %571 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state175, <8 x float> %570)
  %572 = load <8 x float>, ptr %.slot33, align 32
  %573 = select <8 x i1> %548, <8 x float> %571, <8 x float> %572
  store <8 x float> %573, ptr %.slot33, align 32
  %574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %550)
  %575 = bitcast <8 x i1> %550 to i8
  %576 = call i8 @llvm.cttz.i8(i8 %575, i1 false)
  %577 = zext i8 %576 to i32
  %578 = select i1 %574, i32 %577, i32 0
  %.state176 = load <8 x float>, ptr %.slot29, align 32
  %579 = load <8 x float>, ptr %.slot33, align 32
  %580 = select <8 x i1> %550, <8 x float> %.state176, <8 x float> %579
  store <8 x float> %580, ptr %.slot33, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.23
  %.state177 = load <8 x float>, ptr %.slot33, align 32
  %.state178 = load <8 x float>, ptr %.slot30, align 32
  %581 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state177, <8 x float> %.state178)
  %.state179 = load <8 x float>, ptr %.slot31, align 32
  %582 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %581, <8 x float> %.state179)
  %.state180 = load <8 x float>, ptr %.slot32, align 32
  %583 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %582, <8 x float> %.state180)
  %.spill.load181 = load <8 x i64>, ptr %.spill, align 64
  %584 = trunc <8 x i64> %.spill.load181 to <8 x i32>
  %585 = xor <8 x i32> %584, splat (i32 1)
  %586 = load <8 x i32>, ptr %.spill34, align 32
  %587 = select <8 x i1> %62, <8 x i32> %585, <8 x i32> %586
  store <8 x i32> %587, ptr %.spill34, align 32
  %588 = extractelement <8 x i32> %585, i64 0
  %589 = icmp ult i32 %588, 8
  %590 = select i1 %589, i32 %588, i32 0
  %591 = extractelement <8 x i1> %62, i32 %590
  %592 = extractelement <8 x i1> %62, i64 0
  %593 = and i1 %589, %591
  %594 = and i1 %592, %593
  %595 = extractelement <8 x float> %583, i32 %590
  %596 = select i1 %594, float %595, float 0.000000e+00
  %597 = insertelement <8 x float> poison, float %596, i64 0
  %598 = xor i1 %594, true
  %599 = and i1 %592, %598
  %600 = insertelement <8 x i1> poison, i1 %599, i64 0
  %601 = extractelement <8 x i32> %585, i64 1
  %602 = icmp ult i32 %601, 8
  %603 = select i1 %602, i32 %601, i32 0
  %604 = extractelement <8 x i1> %62, i32 %603
  %605 = extractelement <8 x i1> %62, i64 1
  %606 = and i1 %602, %604
  %607 = and i1 %605, %606
  %608 = extractelement <8 x float> %583, i32 %603
  %609 = select i1 %607, float %608, float 0.000000e+00
  %610 = insertelement <8 x float> %597, float %609, i64 1
  %611 = xor i1 %607, true
  %612 = and i1 %605, %611
  %613 = insertelement <8 x i1> %600, i1 %612, i64 1
  %614 = extractelement <8 x i32> %585, i64 2
  %615 = icmp ult i32 %614, 8
  %616 = select i1 %615, i32 %614, i32 0
  %617 = extractelement <8 x i1> %62, i32 %616
  %618 = extractelement <8 x i1> %62, i64 2
  %619 = and i1 %615, %617
  %620 = and i1 %618, %619
  %621 = extractelement <8 x float> %583, i32 %616
  %622 = select i1 %620, float %621, float 0.000000e+00
  %623 = insertelement <8 x float> %610, float %622, i64 2
  %624 = xor i1 %620, true
  %625 = and i1 %618, %624
  %626 = insertelement <8 x i1> %613, i1 %625, i64 2
  %627 = extractelement <8 x i32> %585, i64 3
  %628 = icmp ult i32 %627, 8
  %629 = select i1 %628, i32 %627, i32 0
  %630 = extractelement <8 x i1> %62, i32 %629
  %631 = extractelement <8 x i1> %62, i64 3
  %632 = and i1 %628, %630
  %633 = and i1 %631, %632
  %634 = extractelement <8 x float> %583, i32 %629
  %635 = select i1 %633, float %634, float 0.000000e+00
  %636 = insertelement <8 x float> %623, float %635, i64 3
  %637 = xor i1 %633, true
  %638 = and i1 %631, %637
  %639 = insertelement <8 x i1> %626, i1 %638, i64 3
  %640 = extractelement <8 x i32> %585, i64 4
  %641 = icmp ult i32 %640, 8
  %642 = select i1 %641, i32 %640, i32 0
  %643 = extractelement <8 x i1> %62, i32 %642
  %644 = extractelement <8 x i1> %62, i64 4
  %645 = and i1 %641, %643
  %646 = and i1 %644, %645
  %647 = extractelement <8 x float> %583, i32 %642
  %648 = select i1 %646, float %647, float 0.000000e+00
  %649 = insertelement <8 x float> %636, float %648, i64 4
  %650 = xor i1 %646, true
  %651 = and i1 %644, %650
  %652 = insertelement <8 x i1> %639, i1 %651, i64 4
  %653 = extractelement <8 x i32> %585, i64 5
  %654 = icmp ult i32 %653, 8
  %655 = select i1 %654, i32 %653, i32 0
  %656 = extractelement <8 x i1> %62, i32 %655
  %657 = extractelement <8 x i1> %62, i64 5
  %658 = and i1 %654, %656
  %659 = and i1 %657, %658
  %660 = extractelement <8 x float> %583, i32 %655
  %661 = select i1 %659, float %660, float 0.000000e+00
  %662 = insertelement <8 x float> %649, float %661, i64 5
  %663 = xor i1 %659, true
  %664 = and i1 %657, %663
  %665 = insertelement <8 x i1> %652, i1 %664, i64 5
  %666 = extractelement <8 x i32> %585, i64 6
  %667 = icmp ult i32 %666, 8
  %668 = select i1 %667, i32 %666, i32 0
  %669 = extractelement <8 x i1> %62, i32 %668
  %670 = extractelement <8 x i1> %62, i64 6
  %671 = and i1 %667, %669
  %672 = and i1 %670, %671
  %673 = extractelement <8 x float> %583, i32 %668
  %674 = select i1 %672, float %673, float 0.000000e+00
  %675 = insertelement <8 x float> %662, float %674, i64 6
  %676 = xor i1 %672, true
  %677 = and i1 %670, %676
  %678 = insertelement <8 x i1> %665, i1 %677, i64 6
  %679 = extractelement <8 x i32> %585, i64 7
  %680 = icmp ult i32 %679, 8
  %681 = select i1 %680, i32 %679, i32 0
  %682 = extractelement <8 x i1> %62, i32 %681
  %683 = extractelement <8 x i1> %62, i64 7
  %684 = and i1 %680, %682
  %685 = and i1 %683, %684
  %686 = extractelement <8 x float> %583, i32 %681
  %687 = select i1 %685, float %686, float 0.000000e+00
  %688 = insertelement <8 x float> %675, float %687, i64 7
  %689 = xor i1 %685, true
  %690 = and i1 %683, %689
  %691 = insertelement <8 x i1> %678, i1 %690, i64 7
  %692 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %583, <8 x float> %688)
  %693 = xor <8 x i32> %584, splat (i32 2)
  %694 = load <8 x i32>, ptr %.spill35, align 32
  %695 = select <8 x i1> %62, <8 x i32> %693, <8 x i32> %694
  store <8 x i32> %695, ptr %.spill35, align 32
  %696 = extractelement <8 x i32> %693, i64 0
  %697 = icmp ult i32 %696, 8
  %698 = select i1 %697, i32 %696, i32 0
  %699 = extractelement <8 x i1> %62, i32 %698
  %700 = extractelement <8 x i1> %62, i64 0
  %701 = and i1 %697, %699
  %702 = and i1 %700, %701
  %703 = extractelement <8 x float> %692, i32 %698
  %704 = select i1 %702, float %703, float 0.000000e+00
  %705 = insertelement <8 x float> poison, float %704, i64 0
  %706 = xor i1 %702, true
  %707 = and i1 %700, %706
  %708 = insertelement <8 x i1> poison, i1 %707, i64 0
  %709 = extractelement <8 x i32> %693, i64 1
  %710 = icmp ult i32 %709, 8
  %711 = select i1 %710, i32 %709, i32 0
  %712 = extractelement <8 x i1> %62, i32 %711
  %713 = extractelement <8 x i1> %62, i64 1
  %714 = and i1 %710, %712
  %715 = and i1 %713, %714
  %716 = extractelement <8 x float> %692, i32 %711
  %717 = select i1 %715, float %716, float 0.000000e+00
  %718 = insertelement <8 x float> %705, float %717, i64 1
  %719 = xor i1 %715, true
  %720 = and i1 %713, %719
  %721 = insertelement <8 x i1> %708, i1 %720, i64 1
  %722 = extractelement <8 x i32> %693, i64 2
  %723 = icmp ult i32 %722, 8
  %724 = select i1 %723, i32 %722, i32 0
  %725 = extractelement <8 x i1> %62, i32 %724
  %726 = extractelement <8 x i1> %62, i64 2
  %727 = and i1 %723, %725
  %728 = and i1 %726, %727
  %729 = extractelement <8 x float> %692, i32 %724
  %730 = select i1 %728, float %729, float 0.000000e+00
  %731 = insertelement <8 x float> %718, float %730, i64 2
  %732 = xor i1 %728, true
  %733 = and i1 %726, %732
  %734 = insertelement <8 x i1> %721, i1 %733, i64 2
  %735 = extractelement <8 x i32> %693, i64 3
  %736 = icmp ult i32 %735, 8
  %737 = select i1 %736, i32 %735, i32 0
  %738 = extractelement <8 x i1> %62, i32 %737
  %739 = extractelement <8 x i1> %62, i64 3
  %740 = and i1 %736, %738
  %741 = and i1 %739, %740
  %742 = extractelement <8 x float> %692, i32 %737
  %743 = select i1 %741, float %742, float 0.000000e+00
  %744 = insertelement <8 x float> %731, float %743, i64 3
  %745 = xor i1 %741, true
  %746 = and i1 %739, %745
  %747 = insertelement <8 x i1> %734, i1 %746, i64 3
  %748 = extractelement <8 x i32> %693, i64 4
  %749 = icmp ult i32 %748, 8
  %750 = select i1 %749, i32 %748, i32 0
  %751 = extractelement <8 x i1> %62, i32 %750
  %752 = extractelement <8 x i1> %62, i64 4
  %753 = and i1 %749, %751
  %754 = and i1 %752, %753
  %755 = extractelement <8 x float> %692, i32 %750
  %756 = select i1 %754, float %755, float 0.000000e+00
  %757 = insertelement <8 x float> %744, float %756, i64 4
  %758 = xor i1 %754, true
  %759 = and i1 %752, %758
  %760 = insertelement <8 x i1> %747, i1 %759, i64 4
  %761 = extractelement <8 x i32> %693, i64 5
  %762 = icmp ult i32 %761, 8
  %763 = select i1 %762, i32 %761, i32 0
  %764 = extractelement <8 x i1> %62, i32 %763
  %765 = extractelement <8 x i1> %62, i64 5
  %766 = and i1 %762, %764
  %767 = and i1 %765, %766
  %768 = extractelement <8 x float> %692, i32 %763
  %769 = select i1 %767, float %768, float 0.000000e+00
  %770 = insertelement <8 x float> %757, float %769, i64 5
  %771 = xor i1 %767, true
  %772 = and i1 %765, %771
  %773 = insertelement <8 x i1> %760, i1 %772, i64 5
  %774 = extractelement <8 x i32> %693, i64 6
  %775 = icmp ult i32 %774, 8
  %776 = select i1 %775, i32 %774, i32 0
  %777 = extractelement <8 x i1> %62, i32 %776
  %778 = extractelement <8 x i1> %62, i64 6
  %779 = and i1 %775, %777
  %780 = and i1 %778, %779
  %781 = extractelement <8 x float> %692, i32 %776
  %782 = select i1 %780, float %781, float 0.000000e+00
  %783 = insertelement <8 x float> %770, float %782, i64 6
  %784 = xor i1 %780, true
  %785 = and i1 %778, %784
  %786 = insertelement <8 x i1> %773, i1 %785, i64 6
  %787 = extractelement <8 x i32> %693, i64 7
  %788 = icmp ult i32 %787, 8
  %789 = select i1 %788, i32 %787, i32 0
  %790 = extractelement <8 x i1> %62, i32 %789
  %791 = extractelement <8 x i1> %62, i64 7
  %792 = and i1 %788, %790
  %793 = and i1 %791, %792
  %794 = extractelement <8 x float> %692, i32 %789
  %795 = select i1 %793, float %794, float 0.000000e+00
  %796 = insertelement <8 x float> %783, float %795, i64 7
  %797 = xor i1 %793, true
  %798 = and i1 %791, %797
  %799 = insertelement <8 x i1> %786, i1 %798, i64 7
  %800 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %692, <8 x float> %796)
  %801 = xor <8 x i32> %584, splat (i32 4)
  %802 = load <8 x i32>, ptr %.spill36, align 32
  %803 = select <8 x i1> %62, <8 x i32> %801, <8 x i32> %802
  store <8 x i32> %803, ptr %.spill36, align 32
  %804 = extractelement <8 x i32> %801, i64 0
  %805 = icmp ult i32 %804, 8
  %806 = select i1 %805, i32 %804, i32 0
  %807 = extractelement <8 x i1> %62, i32 %806
  %808 = extractelement <8 x i1> %62, i64 0
  %809 = and i1 %805, %807
  %810 = and i1 %808, %809
  %811 = extractelement <8 x float> %800, i32 %806
  %812 = select i1 %810, float %811, float 0.000000e+00
  %813 = insertelement <8 x float> poison, float %812, i64 0
  %814 = xor i1 %810, true
  %815 = and i1 %808, %814
  %816 = insertelement <8 x i1> poison, i1 %815, i64 0
  %817 = extractelement <8 x i32> %801, i64 1
  %818 = icmp ult i32 %817, 8
  %819 = select i1 %818, i32 %817, i32 0
  %820 = extractelement <8 x i1> %62, i32 %819
  %821 = extractelement <8 x i1> %62, i64 1
  %822 = and i1 %818, %820
  %823 = and i1 %821, %822
  %824 = extractelement <8 x float> %800, i32 %819
  %825 = select i1 %823, float %824, float 0.000000e+00
  %826 = insertelement <8 x float> %813, float %825, i64 1
  %827 = xor i1 %823, true
  %828 = and i1 %821, %827
  %829 = insertelement <8 x i1> %816, i1 %828, i64 1
  %830 = extractelement <8 x i32> %801, i64 2
  %831 = icmp ult i32 %830, 8
  %832 = select i1 %831, i32 %830, i32 0
  %833 = extractelement <8 x i1> %62, i32 %832
  %834 = extractelement <8 x i1> %62, i64 2
  %835 = and i1 %831, %833
  %836 = and i1 %834, %835
  %837 = extractelement <8 x float> %800, i32 %832
  %838 = select i1 %836, float %837, float 0.000000e+00
  %839 = insertelement <8 x float> %826, float %838, i64 2
  %840 = xor i1 %836, true
  %841 = and i1 %834, %840
  %842 = insertelement <8 x i1> %829, i1 %841, i64 2
  %843 = extractelement <8 x i32> %801, i64 3
  %844 = icmp ult i32 %843, 8
  %845 = select i1 %844, i32 %843, i32 0
  %846 = extractelement <8 x i1> %62, i32 %845
  %847 = extractelement <8 x i1> %62, i64 3
  %848 = and i1 %844, %846
  %849 = and i1 %847, %848
  %850 = extractelement <8 x float> %800, i32 %845
  %851 = select i1 %849, float %850, float 0.000000e+00
  %852 = insertelement <8 x float> %839, float %851, i64 3
  %853 = xor i1 %849, true
  %854 = and i1 %847, %853
  %855 = insertelement <8 x i1> %842, i1 %854, i64 3
  %856 = extractelement <8 x i32> %801, i64 4
  %857 = icmp ult i32 %856, 8
  %858 = select i1 %857, i32 %856, i32 0
  %859 = extractelement <8 x i1> %62, i32 %858
  %860 = extractelement <8 x i1> %62, i64 4
  %861 = and i1 %857, %859
  %862 = and i1 %860, %861
  %863 = extractelement <8 x float> %800, i32 %858
  %864 = select i1 %862, float %863, float 0.000000e+00
  %865 = insertelement <8 x float> %852, float %864, i64 4
  %866 = xor i1 %862, true
  %867 = and i1 %860, %866
  %868 = insertelement <8 x i1> %855, i1 %867, i64 4
  %869 = extractelement <8 x i32> %801, i64 5
  %870 = icmp ult i32 %869, 8
  %871 = select i1 %870, i32 %869, i32 0
  %872 = extractelement <8 x i1> %62, i32 %871
  %873 = extractelement <8 x i1> %62, i64 5
  %874 = and i1 %870, %872
  %875 = and i1 %873, %874
  %876 = extractelement <8 x float> %800, i32 %871
  %877 = select i1 %875, float %876, float 0.000000e+00
  %878 = insertelement <8 x float> %865, float %877, i64 5
  %879 = xor i1 %875, true
  %880 = and i1 %873, %879
  %881 = insertelement <8 x i1> %868, i1 %880, i64 5
  %882 = extractelement <8 x i32> %801, i64 6
  %883 = icmp ult i32 %882, 8
  %884 = select i1 %883, i32 %882, i32 0
  %885 = extractelement <8 x i1> %62, i32 %884
  %886 = extractelement <8 x i1> %62, i64 6
  %887 = and i1 %883, %885
  %888 = and i1 %886, %887
  %889 = extractelement <8 x float> %800, i32 %884
  %890 = select i1 %888, float %889, float 0.000000e+00
  %891 = insertelement <8 x float> %878, float %890, i64 6
  %892 = xor i1 %888, true
  %893 = and i1 %886, %892
  %894 = insertelement <8 x i1> %881, i1 %893, i64 6
  %895 = extractelement <8 x i32> %801, i64 7
  %896 = icmp ult i32 %895, 8
  %897 = select i1 %896, i32 %895, i32 0
  %898 = extractelement <8 x i1> %62, i32 %897
  %899 = extractelement <8 x i1> %62, i64 7
  %900 = and i1 %896, %898
  %901 = and i1 %899, %900
  %902 = extractelement <8 x float> %800, i32 %897
  %903 = select i1 %901, float %902, float 0.000000e+00
  %904 = insertelement <8 x float> %891, float %903, i64 7
  %905 = xor i1 %901, true
  %906 = and i1 %899, %905
  %907 = insertelement <8 x i1> %894, i1 %906, i64 7
  %908 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %800, <8 x float> %904)
  %909 = extractelement <8 x i1> %62, i32 0
  %910 = extractelement <8 x i1> %62, i64 0
  %911 = and i1 true, %909
  %912 = and i1 %910, %911
  %913 = extractelement <8 x float> %908, i32 0
  %914 = select i1 %912, float %913, float 0.000000e+00
  %915 = insertelement <8 x float> poison, float %914, i64 0
  %916 = xor i1 %912, true
  %917 = and i1 %910, %916
  %918 = insertelement <8 x i1> poison, i1 %917, i64 0
  %919 = extractelement <8 x i1> %62, i32 0
  %920 = extractelement <8 x i1> %62, i64 1
  %921 = and i1 true, %919
  %922 = and i1 %920, %921
  %923 = extractelement <8 x float> %908, i32 0
  %924 = select i1 %922, float %923, float 0.000000e+00
  %925 = insertelement <8 x float> %915, float %924, i64 1
  %926 = xor i1 %922, true
  %927 = and i1 %920, %926
  %928 = insertelement <8 x i1> %918, i1 %927, i64 1
  %929 = extractelement <8 x i1> %62, i32 0
  %930 = extractelement <8 x i1> %62, i64 2
  %931 = and i1 true, %929
  %932 = and i1 %930, %931
  %933 = extractelement <8 x float> %908, i32 0
  %934 = select i1 %932, float %933, float 0.000000e+00
  %935 = insertelement <8 x float> %925, float %934, i64 2
  %936 = xor i1 %932, true
  %937 = and i1 %930, %936
  %938 = insertelement <8 x i1> %928, i1 %937, i64 2
  %939 = extractelement <8 x i1> %62, i32 0
  %940 = extractelement <8 x i1> %62, i64 3
  %941 = and i1 true, %939
  %942 = and i1 %940, %941
  %943 = extractelement <8 x float> %908, i32 0
  %944 = select i1 %942, float %943, float 0.000000e+00
  %945 = insertelement <8 x float> %935, float %944, i64 3
  %946 = xor i1 %942, true
  %947 = and i1 %940, %946
  %948 = insertelement <8 x i1> %938, i1 %947, i64 3
  %949 = extractelement <8 x i1> %62, i32 0
  %950 = extractelement <8 x i1> %62, i64 4
  %951 = and i1 true, %949
  %952 = and i1 %950, %951
  %953 = extractelement <8 x float> %908, i32 0
  %954 = select i1 %952, float %953, float 0.000000e+00
  %955 = insertelement <8 x float> %945, float %954, i64 4
  %956 = xor i1 %952, true
  %957 = and i1 %950, %956
  %958 = insertelement <8 x i1> %948, i1 %957, i64 4
  %959 = extractelement <8 x i1> %62, i32 0
  %960 = extractelement <8 x i1> %62, i64 5
  %961 = and i1 true, %959
  %962 = and i1 %960, %961
  %963 = extractelement <8 x float> %908, i32 0
  %964 = select i1 %962, float %963, float 0.000000e+00
  %965 = insertelement <8 x float> %955, float %964, i64 5
  %966 = xor i1 %962, true
  %967 = and i1 %960, %966
  %968 = insertelement <8 x i1> %958, i1 %967, i64 5
  %969 = extractelement <8 x i1> %62, i32 0
  %970 = extractelement <8 x i1> %62, i64 6
  %971 = and i1 true, %969
  %972 = and i1 %970, %971
  %973 = extractelement <8 x float> %908, i32 0
  %974 = select i1 %972, float %973, float 0.000000e+00
  %975 = insertelement <8 x float> %965, float %974, i64 6
  %976 = xor i1 %972, true
  %977 = and i1 %970, %976
  %978 = insertelement <8 x i1> %968, i1 %977, i64 6
  %979 = extractelement <8 x i1> %62, i32 0
  %980 = extractelement <8 x i1> %62, i64 7
  %981 = and i1 true, %979
  %982 = and i1 %980, %981
  %983 = extractelement <8 x float> %908, i32 0
  %984 = select i1 %982, float %983, float 0.000000e+00
  %985 = insertelement <8 x float> %975, float %984, i64 7
  %986 = xor i1 %982, true
  %987 = and i1 %980, %986
  %988 = insertelement <8 x i1> %978, i1 %987, i64 7
  %989 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %990 = bitcast <8 x i1> %62 to i8
  %991 = call i8 @llvm.cttz.i8(i8 %990, i1 false)
  %992 = zext i8 %991 to i32
  %993 = select i1 %989, i32 %992, i32 0
  %994 = extractelement <8 x float> %985, i32 %993
  %.spill.load182 = load float, ptr %.spill27, align 4
  %995 = call float @llvm.maxnum.f32(float %.spill.load182, float %994)
  store float %995, ptr %.spill37, align 4
  store float 0.000000e+00, ptr %.spill38, align 4
  %996 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %997 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %998 = extractvalue { <8 x ptr>, <8 x i64> } %996, 0
  %999 = select <8 x i1> %62, <8 x ptr> %997, <8 x ptr> %998
  %1000 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1001 = extractvalue { <8 x ptr>, <8 x i64> } %996, 1
  %1002 = select <8 x i1> %62, <8 x i64> %1000, <8 x i64> %1001
  %1003 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %999, 0
  %1004 = insertvalue { <8 x ptr>, <8 x i64> } %1003, <8 x i64> %1002, 1
  store { <8 x ptr>, <8 x i64> } %1004, ptr %tile_snapshot.spill39, align 64
  %1005 = load <8 x i64>, ptr %.slot40, align 64
  %1006 = select <8 x i1> %62, <8 x i64> zeroinitializer, <8 x i64> %1005
  store <8 x i64> %1006, ptr %.slot40, align 64
  br label %direct.schedule.26

direct.schedule.26:                               ; preds = %direct.schedule.27, %direct.schedule.25
  %.state183 = load <8 x i64>, ptr %.slot40, align 64
  %1007 = icmp slt <8 x i64> %.state183, splat (i64 512)
  %1008 = extractelement <8 x i1> %1007, i32 0
  br i1 %1008, label %direct.true184, label %direct.false185

direct.schedule.27:                               ; preds = %direct.true184
  %tile_snapshot.spill.load186 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %1009 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load186, 0
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load186, 1
  %.state187 = load <8 x i64>, ptr %.slot40, align 64
  %1011 = add <8 x i64> %1010, %.state187
  %1012 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1009, 0
  %1013 = insertvalue { <8 x ptr>, <8 x i64> } %1012, <8 x i64> %1011, 1
  %1014 = extractvalue { <8 x ptr>, <8 x i64> } %1013, 0
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %1013, 1
  %1016 = getelementptr i8, <8 x ptr> %1014, <8 x i64> %1015
  %1017 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %1016, i32 1, <8 x i1> %62, <8 x i8> zeroinitializer)
  %1018 = icmp ne <8 x i8> %1017, zeroinitializer
  %tile_snapshot.spill.load188 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %1019 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %1020 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %.state189 = load <8 x i64>, ptr %.slot40, align 64
  %1021 = mul <8 x i64> %.state189, splat (i64 32)
  %1022 = add <8 x i64> %1020, %1021
  %1023 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1019, 0
  %1024 = insertvalue { <8 x ptr>, <8 x i64> } %1023, <8 x i64> %1022, 1
  %1025 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1026 = extractvalue { <8 x ptr>, <8 x i64> } %1024, 1
  %1027 = extractelement <8 x ptr> %1025, i32 0
  %1028 = extractelement <8 x i64> %1026, i32 0
  %1029 = sub i64 %1028, 0
  %1030 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1031 = select i1 %1030, i64 %1029, i64 0
  %private.contiguous.address190 = getelementptr i8, ptr %1027, i64 %1031
  %private.contiguous.load191 = load <8 x float>, ptr %private.contiguous.address190, align 4
  %1032 = select <8 x i1> %62, <8 x float> %private.contiguous.load191, <8 x float> zeroinitializer
  %.spill.load192 = load float, ptr %.spill37, align 4
  %.splatinsert193 = insertelement <8 x float> poison, float %.spill.load192, i64 0
  %.splat194 = shufflevector <8 x float> %.splatinsert193, <8 x float> poison, <8 x i32> zeroinitializer
  %1033 = fsub <8 x float> %1032, %.splat194
  %1034 = select <8 x i1> %62, <8 x float> %1033, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1034)
  %.spill.load195 = load float, ptr %.spill38, align 4
  %.splatinsert196 = insertelement <8 x float> poison, float %.spill.load195, i64 0
  %.splat197 = shufflevector <8 x float> %.splatinsert196, <8 x float> poison, <8 x i32> zeroinitializer
  %1035 = select <8 x i1> %1018, <8 x float> %native.exp, <8 x float> %.splat197
  %tile_snapshot.spill.load198 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 0
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 1
  %.state199 = load <8 x i64>, ptr %.slot40, align 64
  %1038 = mul <8 x i64> %.state199, splat (i64 32)
  %1039 = add <8 x i64> %1037, %1038
  %1040 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1036, 0
  %1041 = insertvalue { <8 x ptr>, <8 x i64> } %1040, <8 x i64> %1039, 1
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1043 = extractvalue { <8 x ptr>, <8 x i64> } %1041, 1
  %1044 = extractelement <8 x ptr> %1042, i32 0
  %1045 = extractelement <8 x i64> %1043, i32 0
  %1046 = sub i64 %1045, 0
  %1047 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1048 = select i1 %1047, i64 %1046, i64 0
  %private.contiguous.address200 = getelementptr i8, ptr %1044, i64 %1048
  %private.contiguous.preserve201 = load <8 x float>, ptr %private.contiguous.address200, align 4
  %1049 = select <8 x i1> %62, <8 x float> %1035, <8 x float> %private.contiguous.preserve201
  store <8 x float> %1049, ptr %private.contiguous.address200, align 4
  %.state202 = load <8 x i64>, ptr %.slot40, align 64
  %1050 = add <8 x i64> %.state202, splat (i64 1)
  %1051 = load <8 x i64>, ptr %.slot40, align 64
  %1052 = select <8 x i1> %62, <8 x i64> %1050, <8 x i64> %1051
  store <8 x i64> %1052, ptr %.slot40, align 64
  br label %direct.schedule.26

direct.schedule.28:                               ; preds = %direct.false185
  %.spill.load203 = load <8 x i1>, ptr %.spill18, align 1
  %1053 = and <8 x i1> %62, %.spill.load203
  %1054 = xor <8 x i1> %.spill.load203, splat (i1 true)
  %1055 = and <8 x i1> %62, %1054
  %1056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1053)
  %1057 = bitcast <8 x i1> %1053 to i8
  %1058 = call i8 @llvm.cttz.i8(i8 %1057, i1 false)
  %1059 = zext i8 %1058 to i32
  %1060 = select i1 %1056, i32 %1059, i32 0
  %tile_snapshot.spill.load204 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %1061 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load204, 0
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load204, 1
  %1063 = add <8 x i64> %1062, splat (i64 512)
  %1064 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1061, 0
  %1065 = insertvalue { <8 x ptr>, <8 x i64> } %1064, <8 x i64> %1063, 1
  %1066 = extractvalue { <8 x ptr>, <8 x i64> } %1065, 0
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %1065, 1
  %1068 = getelementptr i8, <8 x ptr> %1066, <8 x i64> %1067
  %1069 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %1068, i32 1, <8 x i1> %1053, <8 x i8> zeroinitializer)
  %1070 = icmp ne <8 x i8> %1069, zeroinitializer
  %tile_snapshot.spill.load205 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill25, align 64
  %1071 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load205, 0
  %1072 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load205, 1
  %1073 = add <8 x i64> %1072, splat (i64 16384)
  %1074 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1071, 0
  %1075 = insertvalue { <8 x ptr>, <8 x i64> } %1074, <8 x i64> %1073, 1
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1077 = extractvalue { <8 x ptr>, <8 x i64> } %1075, 1
  %1078 = extractelement <8 x ptr> %1076, i32 0
  %1079 = extractelement <8 x i64> %1077, i32 %1060
  %1080 = zext i32 %1060 to i64
  %1081 = mul i64 %1080, 4
  %1082 = sub i64 %1079, %1081
  %1083 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1053)
  %1084 = select i1 %1083, i64 %1082, i64 0
  %private.contiguous.address206 = getelementptr i8, ptr %1078, i64 %1084
  %private.contiguous.load207 = load <8 x float>, ptr %private.contiguous.address206, align 4
  %1085 = select <8 x i1> %1053, <8 x float> %private.contiguous.load207, <8 x float> zeroinitializer
  %.spill.load208 = load float, ptr %.spill37, align 4
  %.splatinsert209 = insertelement <8 x float> poison, float %.spill.load208, i64 0
  %.splat210 = shufflevector <8 x float> %.splatinsert209, <8 x float> poison, <8 x i32> zeroinitializer
  %1086 = fsub <8 x float> %1085, %.splat210
  %1087 = select <8 x i1> %1053, <8 x float> %1086, <8 x float> zeroinitializer
  %native.exp211 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1087)
  %.spill.load212 = load float, ptr %.spill38, align 4
  %.splatinsert213 = insertelement <8 x float> poison, float %.spill.load212, i64 0
  %.splat214 = shufflevector <8 x float> %.splatinsert213, <8 x float> poison, <8 x i32> zeroinitializer
  %1088 = select <8 x i1> %1070, <8 x float> %native.exp211, <8 x float> %.splat214
  %tile_snapshot.spill.load215 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 0
  %1090 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 1
  %1091 = add <8 x i64> %1090, splat (i64 16384)
  %1092 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1089, 0
  %1093 = insertvalue { <8 x ptr>, <8 x i64> } %1092, <8 x i64> %1091, 1
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1095 = extractvalue { <8 x ptr>, <8 x i64> } %1093, 1
  %1096 = extractelement <8 x ptr> %1094, i32 0
  %1097 = extractelement <8 x i64> %1095, i32 %1060
  %1098 = zext i32 %1060 to i64
  %1099 = mul i64 %1098, 4
  %1100 = sub i64 %1097, %1099
  %1101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1053)
  %1102 = select i1 %1101, i64 %1100, i64 0
  %private.contiguous.address216 = getelementptr i8, ptr %1096, i64 %1102
  %private.contiguous.preserve217 = load <8 x float>, ptr %private.contiguous.address216, align 4
  %1103 = select <8 x i1> %1053, <8 x float> %1088, <8 x float> %private.contiguous.preserve217
  store <8 x float> %1103, ptr %private.contiguous.address216, align 4
  %1104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1055)
  %1105 = bitcast <8 x i1> %1055 to i8
  %1106 = call i8 @llvm.cttz.i8(i8 %1105, i1 false)
  %1107 = zext i8 %1106 to i32
  %1108 = select i1 %1104, i32 %1107, i32 0
  br label %direct.schedule.30

direct.schedule.30:                               ; preds = %direct.schedule.28
  %tile_snapshot.spill.load218 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1109 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 0
  %1110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 1
  %1111 = add <8 x i64> %1110, zeroinitializer
  %1112 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1109, 0
  %1113 = insertvalue { <8 x ptr>, <8 x i64> } %1112, <8 x i64> %1111, 1
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %1113, 1
  %1116 = extractelement <8 x ptr> %1114, i32 0
  %1117 = extractelement <8 x i64> %1115, i32 0
  %1118 = sub i64 %1117, 0
  %1119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1120 = select i1 %1119, i64 %1118, i64 0
  %private.contiguous.address219 = getelementptr i8, ptr %1116, i64 %1120
  %private.contiguous.load220 = load <8 x float>, ptr %private.contiguous.address219, align 4
  %1121 = select <8 x i1> %62, <8 x float> %private.contiguous.load220, <8 x float> zeroinitializer
  %tile_snapshot.spill.load221 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1122 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %1123 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %1124 = add <8 x i64> %1123, splat (i64 32)
  %1125 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1122, 0
  %1126 = insertvalue { <8 x ptr>, <8 x i64> } %1125, <8 x i64> %1124, 1
  %1127 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1128 = extractvalue { <8 x ptr>, <8 x i64> } %1126, 1
  %1129 = extractelement <8 x ptr> %1127, i32 0
  %1130 = extractelement <8 x i64> %1128, i32 0
  %1131 = sub i64 %1130, 0
  %1132 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1133 = select i1 %1132, i64 %1131, i64 0
  %private.contiguous.address222 = getelementptr i8, ptr %1129, i64 %1133
  %private.contiguous.load223 = load <8 x float>, ptr %private.contiguous.address222, align 4
  %1134 = select <8 x i1> %62, <8 x float> %private.contiguous.load223, <8 x float> zeroinitializer
  %tile_snapshot.spill.load224 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1135 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load224, 0
  %1136 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load224, 1
  %1137 = add <8 x i64> %1136, splat (i64 64)
  %1138 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1135, 0
  %1139 = insertvalue { <8 x ptr>, <8 x i64> } %1138, <8 x i64> %1137, 1
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %1139, 1
  %1142 = extractelement <8 x ptr> %1140, i32 0
  %1143 = extractelement <8 x i64> %1141, i32 0
  %1144 = sub i64 %1143, 0
  %1145 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1146 = select i1 %1145, i64 %1144, i64 0
  %private.contiguous.address225 = getelementptr i8, ptr %1142, i64 %1146
  %private.contiguous.load226 = load <8 x float>, ptr %private.contiguous.address225, align 4
  %1147 = select <8 x i1> %62, <8 x float> %private.contiguous.load226, <8 x float> zeroinitializer
  %tile_snapshot.spill.load227 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1148 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 0
  %1149 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load227, 1
  %1150 = add <8 x i64> %1149, splat (i64 96)
  %1151 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1148, 0
  %1152 = insertvalue { <8 x ptr>, <8 x i64> } %1151, <8 x i64> %1150, 1
  %1153 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %1152, 1
  %1155 = extractelement <8 x ptr> %1153, i32 0
  %1156 = extractelement <8 x i64> %1154, i32 0
  %1157 = sub i64 %1156, 0
  %1158 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1159 = select i1 %1158, i64 %1157, i64 0
  %private.contiguous.address228 = getelementptr i8, ptr %1155, i64 %1159
  %private.contiguous.load229 = load <8 x float>, ptr %private.contiguous.address228, align 4
  %1160 = select <8 x i1> %62, <8 x float> %private.contiguous.load229, <8 x float> zeroinitializer
  %1161 = load <8 x i64>, ptr %.slot41, align 64
  %1162 = select <8 x i1> %62, <8 x i64> splat (i64 4), <8 x i64> %1161
  store <8 x i64> %1162, ptr %.slot41, align 64
  %1163 = load <8 x float>, ptr %.slot42, align 32
  %1164 = select <8 x i1> %62, <8 x float> %1121, <8 x float> %1163
  store <8 x float> %1164, ptr %.slot42, align 32
  %1165 = load <8 x float>, ptr %.slot43, align 32
  %1166 = select <8 x i1> %62, <8 x float> %1134, <8 x float> %1165
  store <8 x float> %1166, ptr %.slot43, align 32
  %1167 = load <8 x float>, ptr %.slot44, align 32
  %1168 = select <8 x i1> %62, <8 x float> %1147, <8 x float> %1167
  store <8 x float> %1168, ptr %.slot44, align 32
  %1169 = load <8 x float>, ptr %.slot45, align 32
  %1170 = select <8 x i1> %62, <8 x float> %1160, <8 x float> %1169
  store <8 x float> %1170, ptr %.slot45, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state230 = load <8 x i64>, ptr %.slot41, align 64
  %1171 = icmp slt <8 x i64> %.state230, splat (i64 512)
  %1172 = extractelement <8 x i1> %1171, i32 0
  br i1 %1172, label %direct.true231, label %direct.false232

direct.schedule.32:                               ; preds = %direct.true231
  %.state233 = load <8 x i64>, ptr %.slot41, align 64
  %1173 = add <8 x i64> %.state233, zeroinitializer
  %tile_snapshot.spill.load234 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load234, 0
  %1175 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load234, 1
  %1176 = mul <8 x i64> %1173, splat (i64 32)
  %1177 = add <8 x i64> %1175, %1176
  %1178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1174, 0
  %1179 = insertvalue { <8 x ptr>, <8 x i64> } %1178, <8 x i64> %1177, 1
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1181 = extractvalue { <8 x ptr>, <8 x i64> } %1179, 1
  %1182 = extractelement <8 x ptr> %1180, i32 0
  %1183 = extractelement <8 x i64> %1181, i32 0
  %1184 = sub i64 %1183, 0
  %1185 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1186 = select i1 %1185, i64 %1184, i64 0
  %private.contiguous.address235 = getelementptr i8, ptr %1182, i64 %1186
  %private.contiguous.load236 = load <8 x float>, ptr %private.contiguous.address235, align 4
  %1187 = select <8 x i1> %62, <8 x float> %private.contiguous.load236, <8 x float> zeroinitializer
  %.state237 = load <8 x float>, ptr %.slot42, align 32
  %1188 = fadd <8 x float> %.state237, %1187
  %.state238 = load <8 x i64>, ptr %.slot41, align 64
  %1189 = add <8 x i64> %.state238, splat (i64 1)
  %tile_snapshot.spill.load239 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1190 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 0
  %1191 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 1
  %1192 = mul <8 x i64> %1189, splat (i64 32)
  %1193 = add <8 x i64> %1191, %1192
  %1194 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1190, 0
  %1195 = insertvalue { <8 x ptr>, <8 x i64> } %1194, <8 x i64> %1193, 1
  %1196 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %1195, 1
  %1198 = extractelement <8 x ptr> %1196, i32 0
  %1199 = extractelement <8 x i64> %1197, i32 0
  %1200 = sub i64 %1199, 0
  %1201 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1202 = select i1 %1201, i64 %1200, i64 0
  %private.contiguous.address240 = getelementptr i8, ptr %1198, i64 %1202
  %private.contiguous.load241 = load <8 x float>, ptr %private.contiguous.address240, align 4
  %1203 = select <8 x i1> %62, <8 x float> %private.contiguous.load241, <8 x float> zeroinitializer
  %.state242 = load <8 x float>, ptr %.slot43, align 32
  %1204 = fadd <8 x float> %.state242, %1203
  %.state243 = load <8 x i64>, ptr %.slot41, align 64
  %1205 = add <8 x i64> %.state243, splat (i64 2)
  %tile_snapshot.spill.load244 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1206 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 0
  %1207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 1
  %1208 = mul <8 x i64> %1205, splat (i64 32)
  %1209 = add <8 x i64> %1207, %1208
  %1210 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1206, 0
  %1211 = insertvalue { <8 x ptr>, <8 x i64> } %1210, <8 x i64> %1209, 1
  %1212 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1213 = extractvalue { <8 x ptr>, <8 x i64> } %1211, 1
  %1214 = extractelement <8 x ptr> %1212, i32 0
  %1215 = extractelement <8 x i64> %1213, i32 0
  %1216 = sub i64 %1215, 0
  %1217 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1218 = select i1 %1217, i64 %1216, i64 0
  %private.contiguous.address245 = getelementptr i8, ptr %1214, i64 %1218
  %private.contiguous.load246 = load <8 x float>, ptr %private.contiguous.address245, align 4
  %1219 = select <8 x i1> %62, <8 x float> %private.contiguous.load246, <8 x float> zeroinitializer
  %.state247 = load <8 x float>, ptr %.slot44, align 32
  %1220 = fadd <8 x float> %.state247, %1219
  %.state248 = load <8 x i64>, ptr %.slot41, align 64
  %1221 = add <8 x i64> %.state248, splat (i64 3)
  %tile_snapshot.spill.load249 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load249, 0
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load249, 1
  %1224 = mul <8 x i64> %1221, splat (i64 32)
  %1225 = add <8 x i64> %1223, %1224
  %1226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1222, 0
  %1227 = insertvalue { <8 x ptr>, <8 x i64> } %1226, <8 x i64> %1225, 1
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %1227, 1
  %1230 = extractelement <8 x ptr> %1228, i32 0
  %1231 = extractelement <8 x i64> %1229, i32 0
  %1232 = sub i64 %1231, 0
  %1233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1234 = select i1 %1233, i64 %1232, i64 0
  %private.contiguous.address250 = getelementptr i8, ptr %1230, i64 %1234
  %private.contiguous.load251 = load <8 x float>, ptr %private.contiguous.address250, align 4
  %1235 = select <8 x i1> %62, <8 x float> %private.contiguous.load251, <8 x float> zeroinitializer
  %.state252 = load <8 x float>, ptr %.slot45, align 32
  %1236 = fadd <8 x float> %.state252, %1235
  %.state253 = load <8 x i64>, ptr %.slot41, align 64
  %1237 = add <8 x i64> %.state253, splat (i64 4)
  %1238 = load <8 x i64>, ptr %.slot41, align 64
  %1239 = select <8 x i1> %62, <8 x i64> %1237, <8 x i64> %1238
  store <8 x i64> %1239, ptr %.slot41, align 64
  %1240 = load <8 x float>, ptr %.slot42, align 32
  %1241 = select <8 x i1> %62, <8 x float> %1188, <8 x float> %1240
  store <8 x float> %1241, ptr %.slot42, align 32
  %1242 = load <8 x float>, ptr %.slot43, align 32
  %1243 = select <8 x i1> %62, <8 x float> %1204, <8 x float> %1242
  store <8 x float> %1243, ptr %.slot43, align 32
  %1244 = load <8 x float>, ptr %.slot44, align 32
  %1245 = select <8 x i1> %62, <8 x float> %1220, <8 x float> %1244
  store <8 x float> %1245, ptr %.slot44, align 32
  %1246 = load <8 x float>, ptr %.slot45, align 32
  %1247 = select <8 x i1> %62, <8 x float> %1236, <8 x float> %1246
  store <8 x float> %1247, ptr %.slot45, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false232
  %.spill.load254 = load <8 x i1>, ptr %.spill18, align 1
  %1248 = and <8 x i1> %62, %.spill.load254
  %1249 = xor <8 x i1> %.spill.load254, splat (i1 true)
  %1250 = and <8 x i1> %62, %1249
  %1251 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1248)
  %1252 = bitcast <8 x i1> %1248 to i8
  %1253 = call i8 @llvm.cttz.i8(i8 %1252, i1 false)
  %1254 = zext i8 %1253 to i32
  %1255 = select i1 %1251, i32 %1254, i32 0
  %tile_snapshot.spill.load255 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load255, 0
  %1257 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load255, 1
  %1258 = add <8 x i64> %1257, splat (i64 16384)
  %1259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1256, 0
  %1260 = insertvalue { <8 x ptr>, <8 x i64> } %1259, <8 x i64> %1258, 1
  %1261 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1262 = extractvalue { <8 x ptr>, <8 x i64> } %1260, 1
  %1263 = extractelement <8 x ptr> %1261, i32 0
  %1264 = extractelement <8 x i64> %1262, i32 %1255
  %1265 = zext i32 %1255 to i64
  %1266 = mul i64 %1265, 4
  %1267 = sub i64 %1264, %1266
  %1268 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1248)
  %1269 = select i1 %1268, i64 %1267, i64 0
  %private.contiguous.address256 = getelementptr i8, ptr %1263, i64 %1269
  %private.contiguous.load257 = load <8 x float>, ptr %private.contiguous.address256, align 4
  %1270 = select <8 x i1> %1248, <8 x float> %private.contiguous.load257, <8 x float> zeroinitializer
  %.state258 = load <8 x float>, ptr %.slot42, align 32
  %1271 = fadd <8 x float> %.state258, %1270
  %1272 = load <8 x float>, ptr %.slot46, align 32
  %1273 = select <8 x i1> %1248, <8 x float> %1271, <8 x float> %1272
  store <8 x float> %1273, ptr %.slot46, align 32
  %1274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1250)
  %1275 = bitcast <8 x i1> %1250 to i8
  %1276 = call i8 @llvm.cttz.i8(i8 %1275, i1 false)
  %1277 = zext i8 %1276 to i32
  %1278 = select i1 %1274, i32 %1277, i32 0
  %.state259 = load <8 x float>, ptr %.slot42, align 32
  %1279 = load <8 x float>, ptr %.slot46, align 32
  %1280 = select <8 x i1> %1250, <8 x float> %.state259, <8 x float> %1279
  store <8 x float> %1280, ptr %.slot46, align 32
  br label %direct.schedule.35

direct.schedule.35:                               ; preds = %direct.schedule.33
  %.state260 = load <8 x float>, ptr %.slot46, align 32
  %.state261 = load <8 x float>, ptr %.slot43, align 32
  %1281 = fadd <8 x float> %.state260, %.state261
  %.state262 = load <8 x float>, ptr %.slot44, align 32
  %1282 = fadd <8 x float> %1281, %.state262
  %.state263 = load <8 x float>, ptr %.slot45, align 32
  %1283 = fadd <8 x float> %1282, %.state263
  %.spill.load264 = load <8 x i32>, ptr %.spill34, align 32
  %1284 = extractelement <8 x i32> %.spill.load264, i64 0
  %1285 = icmp ult i32 %1284, 8
  %1286 = select i1 %1285, i32 %1284, i32 0
  %1287 = extractelement <8 x i1> %62, i32 %1286
  %1288 = extractelement <8 x i1> %62, i64 0
  %1289 = and i1 %1285, %1287
  %1290 = and i1 %1288, %1289
  %1291 = extractelement <8 x float> %1283, i32 %1286
  %1292 = select i1 %1290, float %1291, float 0.000000e+00
  %1293 = insertelement <8 x float> poison, float %1292, i64 0
  %1294 = xor i1 %1290, true
  %1295 = and i1 %1288, %1294
  %1296 = insertelement <8 x i1> poison, i1 %1295, i64 0
  %1297 = extractelement <8 x i32> %.spill.load264, i64 1
  %1298 = icmp ult i32 %1297, 8
  %1299 = select i1 %1298, i32 %1297, i32 0
  %1300 = extractelement <8 x i1> %62, i32 %1299
  %1301 = extractelement <8 x i1> %62, i64 1
  %1302 = and i1 %1298, %1300
  %1303 = and i1 %1301, %1302
  %1304 = extractelement <8 x float> %1283, i32 %1299
  %1305 = select i1 %1303, float %1304, float 0.000000e+00
  %1306 = insertelement <8 x float> %1293, float %1305, i64 1
  %1307 = xor i1 %1303, true
  %1308 = and i1 %1301, %1307
  %1309 = insertelement <8 x i1> %1296, i1 %1308, i64 1
  %1310 = extractelement <8 x i32> %.spill.load264, i64 2
  %1311 = icmp ult i32 %1310, 8
  %1312 = select i1 %1311, i32 %1310, i32 0
  %1313 = extractelement <8 x i1> %62, i32 %1312
  %1314 = extractelement <8 x i1> %62, i64 2
  %1315 = and i1 %1311, %1313
  %1316 = and i1 %1314, %1315
  %1317 = extractelement <8 x float> %1283, i32 %1312
  %1318 = select i1 %1316, float %1317, float 0.000000e+00
  %1319 = insertelement <8 x float> %1306, float %1318, i64 2
  %1320 = xor i1 %1316, true
  %1321 = and i1 %1314, %1320
  %1322 = insertelement <8 x i1> %1309, i1 %1321, i64 2
  %1323 = extractelement <8 x i32> %.spill.load264, i64 3
  %1324 = icmp ult i32 %1323, 8
  %1325 = select i1 %1324, i32 %1323, i32 0
  %1326 = extractelement <8 x i1> %62, i32 %1325
  %1327 = extractelement <8 x i1> %62, i64 3
  %1328 = and i1 %1324, %1326
  %1329 = and i1 %1327, %1328
  %1330 = extractelement <8 x float> %1283, i32 %1325
  %1331 = select i1 %1329, float %1330, float 0.000000e+00
  %1332 = insertelement <8 x float> %1319, float %1331, i64 3
  %1333 = xor i1 %1329, true
  %1334 = and i1 %1327, %1333
  %1335 = insertelement <8 x i1> %1322, i1 %1334, i64 3
  %1336 = extractelement <8 x i32> %.spill.load264, i64 4
  %1337 = icmp ult i32 %1336, 8
  %1338 = select i1 %1337, i32 %1336, i32 0
  %1339 = extractelement <8 x i1> %62, i32 %1338
  %1340 = extractelement <8 x i1> %62, i64 4
  %1341 = and i1 %1337, %1339
  %1342 = and i1 %1340, %1341
  %1343 = extractelement <8 x float> %1283, i32 %1338
  %1344 = select i1 %1342, float %1343, float 0.000000e+00
  %1345 = insertelement <8 x float> %1332, float %1344, i64 4
  %1346 = xor i1 %1342, true
  %1347 = and i1 %1340, %1346
  %1348 = insertelement <8 x i1> %1335, i1 %1347, i64 4
  %1349 = extractelement <8 x i32> %.spill.load264, i64 5
  %1350 = icmp ult i32 %1349, 8
  %1351 = select i1 %1350, i32 %1349, i32 0
  %1352 = extractelement <8 x i1> %62, i32 %1351
  %1353 = extractelement <8 x i1> %62, i64 5
  %1354 = and i1 %1350, %1352
  %1355 = and i1 %1353, %1354
  %1356 = extractelement <8 x float> %1283, i32 %1351
  %1357 = select i1 %1355, float %1356, float 0.000000e+00
  %1358 = insertelement <8 x float> %1345, float %1357, i64 5
  %1359 = xor i1 %1355, true
  %1360 = and i1 %1353, %1359
  %1361 = insertelement <8 x i1> %1348, i1 %1360, i64 5
  %1362 = extractelement <8 x i32> %.spill.load264, i64 6
  %1363 = icmp ult i32 %1362, 8
  %1364 = select i1 %1363, i32 %1362, i32 0
  %1365 = extractelement <8 x i1> %62, i32 %1364
  %1366 = extractelement <8 x i1> %62, i64 6
  %1367 = and i1 %1363, %1365
  %1368 = and i1 %1366, %1367
  %1369 = extractelement <8 x float> %1283, i32 %1364
  %1370 = select i1 %1368, float %1369, float 0.000000e+00
  %1371 = insertelement <8 x float> %1358, float %1370, i64 6
  %1372 = xor i1 %1368, true
  %1373 = and i1 %1366, %1372
  %1374 = insertelement <8 x i1> %1361, i1 %1373, i64 6
  %1375 = extractelement <8 x i32> %.spill.load264, i64 7
  %1376 = icmp ult i32 %1375, 8
  %1377 = select i1 %1376, i32 %1375, i32 0
  %1378 = extractelement <8 x i1> %62, i32 %1377
  %1379 = extractelement <8 x i1> %62, i64 7
  %1380 = and i1 %1376, %1378
  %1381 = and i1 %1379, %1380
  %1382 = extractelement <8 x float> %1283, i32 %1377
  %1383 = select i1 %1381, float %1382, float 0.000000e+00
  %1384 = insertelement <8 x float> %1371, float %1383, i64 7
  %1385 = xor i1 %1381, true
  %1386 = and i1 %1379, %1385
  %1387 = insertelement <8 x i1> %1374, i1 %1386, i64 7
  %1388 = fadd <8 x float> %1283, %1384
  %.spill.load265 = load <8 x i32>, ptr %.spill35, align 32
  %1389 = extractelement <8 x i32> %.spill.load265, i64 0
  %1390 = icmp ult i32 %1389, 8
  %1391 = select i1 %1390, i32 %1389, i32 0
  %1392 = extractelement <8 x i1> %62, i32 %1391
  %1393 = extractelement <8 x i1> %62, i64 0
  %1394 = and i1 %1390, %1392
  %1395 = and i1 %1393, %1394
  %1396 = extractelement <8 x float> %1388, i32 %1391
  %1397 = select i1 %1395, float %1396, float 0.000000e+00
  %1398 = insertelement <8 x float> poison, float %1397, i64 0
  %1399 = xor i1 %1395, true
  %1400 = and i1 %1393, %1399
  %1401 = insertelement <8 x i1> poison, i1 %1400, i64 0
  %1402 = extractelement <8 x i32> %.spill.load265, i64 1
  %1403 = icmp ult i32 %1402, 8
  %1404 = select i1 %1403, i32 %1402, i32 0
  %1405 = extractelement <8 x i1> %62, i32 %1404
  %1406 = extractelement <8 x i1> %62, i64 1
  %1407 = and i1 %1403, %1405
  %1408 = and i1 %1406, %1407
  %1409 = extractelement <8 x float> %1388, i32 %1404
  %1410 = select i1 %1408, float %1409, float 0.000000e+00
  %1411 = insertelement <8 x float> %1398, float %1410, i64 1
  %1412 = xor i1 %1408, true
  %1413 = and i1 %1406, %1412
  %1414 = insertelement <8 x i1> %1401, i1 %1413, i64 1
  %1415 = extractelement <8 x i32> %.spill.load265, i64 2
  %1416 = icmp ult i32 %1415, 8
  %1417 = select i1 %1416, i32 %1415, i32 0
  %1418 = extractelement <8 x i1> %62, i32 %1417
  %1419 = extractelement <8 x i1> %62, i64 2
  %1420 = and i1 %1416, %1418
  %1421 = and i1 %1419, %1420
  %1422 = extractelement <8 x float> %1388, i32 %1417
  %1423 = select i1 %1421, float %1422, float 0.000000e+00
  %1424 = insertelement <8 x float> %1411, float %1423, i64 2
  %1425 = xor i1 %1421, true
  %1426 = and i1 %1419, %1425
  %1427 = insertelement <8 x i1> %1414, i1 %1426, i64 2
  %1428 = extractelement <8 x i32> %.spill.load265, i64 3
  %1429 = icmp ult i32 %1428, 8
  %1430 = select i1 %1429, i32 %1428, i32 0
  %1431 = extractelement <8 x i1> %62, i32 %1430
  %1432 = extractelement <8 x i1> %62, i64 3
  %1433 = and i1 %1429, %1431
  %1434 = and i1 %1432, %1433
  %1435 = extractelement <8 x float> %1388, i32 %1430
  %1436 = select i1 %1434, float %1435, float 0.000000e+00
  %1437 = insertelement <8 x float> %1424, float %1436, i64 3
  %1438 = xor i1 %1434, true
  %1439 = and i1 %1432, %1438
  %1440 = insertelement <8 x i1> %1427, i1 %1439, i64 3
  %1441 = extractelement <8 x i32> %.spill.load265, i64 4
  %1442 = icmp ult i32 %1441, 8
  %1443 = select i1 %1442, i32 %1441, i32 0
  %1444 = extractelement <8 x i1> %62, i32 %1443
  %1445 = extractelement <8 x i1> %62, i64 4
  %1446 = and i1 %1442, %1444
  %1447 = and i1 %1445, %1446
  %1448 = extractelement <8 x float> %1388, i32 %1443
  %1449 = select i1 %1447, float %1448, float 0.000000e+00
  %1450 = insertelement <8 x float> %1437, float %1449, i64 4
  %1451 = xor i1 %1447, true
  %1452 = and i1 %1445, %1451
  %1453 = insertelement <8 x i1> %1440, i1 %1452, i64 4
  %1454 = extractelement <8 x i32> %.spill.load265, i64 5
  %1455 = icmp ult i32 %1454, 8
  %1456 = select i1 %1455, i32 %1454, i32 0
  %1457 = extractelement <8 x i1> %62, i32 %1456
  %1458 = extractelement <8 x i1> %62, i64 5
  %1459 = and i1 %1455, %1457
  %1460 = and i1 %1458, %1459
  %1461 = extractelement <8 x float> %1388, i32 %1456
  %1462 = select i1 %1460, float %1461, float 0.000000e+00
  %1463 = insertelement <8 x float> %1450, float %1462, i64 5
  %1464 = xor i1 %1460, true
  %1465 = and i1 %1458, %1464
  %1466 = insertelement <8 x i1> %1453, i1 %1465, i64 5
  %1467 = extractelement <8 x i32> %.spill.load265, i64 6
  %1468 = icmp ult i32 %1467, 8
  %1469 = select i1 %1468, i32 %1467, i32 0
  %1470 = extractelement <8 x i1> %62, i32 %1469
  %1471 = extractelement <8 x i1> %62, i64 6
  %1472 = and i1 %1468, %1470
  %1473 = and i1 %1471, %1472
  %1474 = extractelement <8 x float> %1388, i32 %1469
  %1475 = select i1 %1473, float %1474, float 0.000000e+00
  %1476 = insertelement <8 x float> %1463, float %1475, i64 6
  %1477 = xor i1 %1473, true
  %1478 = and i1 %1471, %1477
  %1479 = insertelement <8 x i1> %1466, i1 %1478, i64 6
  %1480 = extractelement <8 x i32> %.spill.load265, i64 7
  %1481 = icmp ult i32 %1480, 8
  %1482 = select i1 %1481, i32 %1480, i32 0
  %1483 = extractelement <8 x i1> %62, i32 %1482
  %1484 = extractelement <8 x i1> %62, i64 7
  %1485 = and i1 %1481, %1483
  %1486 = and i1 %1484, %1485
  %1487 = extractelement <8 x float> %1388, i32 %1482
  %1488 = select i1 %1486, float %1487, float 0.000000e+00
  %1489 = insertelement <8 x float> %1476, float %1488, i64 7
  %1490 = xor i1 %1486, true
  %1491 = and i1 %1484, %1490
  %1492 = insertelement <8 x i1> %1479, i1 %1491, i64 7
  %1493 = fadd <8 x float> %1388, %1489
  %.spill.load266 = load <8 x i32>, ptr %.spill36, align 32
  %1494 = extractelement <8 x i32> %.spill.load266, i64 0
  %1495 = icmp ult i32 %1494, 8
  %1496 = select i1 %1495, i32 %1494, i32 0
  %1497 = extractelement <8 x i1> %62, i32 %1496
  %1498 = extractelement <8 x i1> %62, i64 0
  %1499 = and i1 %1495, %1497
  %1500 = and i1 %1498, %1499
  %1501 = extractelement <8 x float> %1493, i32 %1496
  %1502 = select i1 %1500, float %1501, float 0.000000e+00
  %1503 = insertelement <8 x float> poison, float %1502, i64 0
  %1504 = xor i1 %1500, true
  %1505 = and i1 %1498, %1504
  %1506 = insertelement <8 x i1> poison, i1 %1505, i64 0
  %1507 = extractelement <8 x i32> %.spill.load266, i64 1
  %1508 = icmp ult i32 %1507, 8
  %1509 = select i1 %1508, i32 %1507, i32 0
  %1510 = extractelement <8 x i1> %62, i32 %1509
  %1511 = extractelement <8 x i1> %62, i64 1
  %1512 = and i1 %1508, %1510
  %1513 = and i1 %1511, %1512
  %1514 = extractelement <8 x float> %1493, i32 %1509
  %1515 = select i1 %1513, float %1514, float 0.000000e+00
  %1516 = insertelement <8 x float> %1503, float %1515, i64 1
  %1517 = xor i1 %1513, true
  %1518 = and i1 %1511, %1517
  %1519 = insertelement <8 x i1> %1506, i1 %1518, i64 1
  %1520 = extractelement <8 x i32> %.spill.load266, i64 2
  %1521 = icmp ult i32 %1520, 8
  %1522 = select i1 %1521, i32 %1520, i32 0
  %1523 = extractelement <8 x i1> %62, i32 %1522
  %1524 = extractelement <8 x i1> %62, i64 2
  %1525 = and i1 %1521, %1523
  %1526 = and i1 %1524, %1525
  %1527 = extractelement <8 x float> %1493, i32 %1522
  %1528 = select i1 %1526, float %1527, float 0.000000e+00
  %1529 = insertelement <8 x float> %1516, float %1528, i64 2
  %1530 = xor i1 %1526, true
  %1531 = and i1 %1524, %1530
  %1532 = insertelement <8 x i1> %1519, i1 %1531, i64 2
  %1533 = extractelement <8 x i32> %.spill.load266, i64 3
  %1534 = icmp ult i32 %1533, 8
  %1535 = select i1 %1534, i32 %1533, i32 0
  %1536 = extractelement <8 x i1> %62, i32 %1535
  %1537 = extractelement <8 x i1> %62, i64 3
  %1538 = and i1 %1534, %1536
  %1539 = and i1 %1537, %1538
  %1540 = extractelement <8 x float> %1493, i32 %1535
  %1541 = select i1 %1539, float %1540, float 0.000000e+00
  %1542 = insertelement <8 x float> %1529, float %1541, i64 3
  %1543 = xor i1 %1539, true
  %1544 = and i1 %1537, %1543
  %1545 = insertelement <8 x i1> %1532, i1 %1544, i64 3
  %1546 = extractelement <8 x i32> %.spill.load266, i64 4
  %1547 = icmp ult i32 %1546, 8
  %1548 = select i1 %1547, i32 %1546, i32 0
  %1549 = extractelement <8 x i1> %62, i32 %1548
  %1550 = extractelement <8 x i1> %62, i64 4
  %1551 = and i1 %1547, %1549
  %1552 = and i1 %1550, %1551
  %1553 = extractelement <8 x float> %1493, i32 %1548
  %1554 = select i1 %1552, float %1553, float 0.000000e+00
  %1555 = insertelement <8 x float> %1542, float %1554, i64 4
  %1556 = xor i1 %1552, true
  %1557 = and i1 %1550, %1556
  %1558 = insertelement <8 x i1> %1545, i1 %1557, i64 4
  %1559 = extractelement <8 x i32> %.spill.load266, i64 5
  %1560 = icmp ult i32 %1559, 8
  %1561 = select i1 %1560, i32 %1559, i32 0
  %1562 = extractelement <8 x i1> %62, i32 %1561
  %1563 = extractelement <8 x i1> %62, i64 5
  %1564 = and i1 %1560, %1562
  %1565 = and i1 %1563, %1564
  %1566 = extractelement <8 x float> %1493, i32 %1561
  %1567 = select i1 %1565, float %1566, float 0.000000e+00
  %1568 = insertelement <8 x float> %1555, float %1567, i64 5
  %1569 = xor i1 %1565, true
  %1570 = and i1 %1563, %1569
  %1571 = insertelement <8 x i1> %1558, i1 %1570, i64 5
  %1572 = extractelement <8 x i32> %.spill.load266, i64 6
  %1573 = icmp ult i32 %1572, 8
  %1574 = select i1 %1573, i32 %1572, i32 0
  %1575 = extractelement <8 x i1> %62, i32 %1574
  %1576 = extractelement <8 x i1> %62, i64 6
  %1577 = and i1 %1573, %1575
  %1578 = and i1 %1576, %1577
  %1579 = extractelement <8 x float> %1493, i32 %1574
  %1580 = select i1 %1578, float %1579, float 0.000000e+00
  %1581 = insertelement <8 x float> %1568, float %1580, i64 6
  %1582 = xor i1 %1578, true
  %1583 = and i1 %1576, %1582
  %1584 = insertelement <8 x i1> %1571, i1 %1583, i64 6
  %1585 = extractelement <8 x i32> %.spill.load266, i64 7
  %1586 = icmp ult i32 %1585, 8
  %1587 = select i1 %1586, i32 %1585, i32 0
  %1588 = extractelement <8 x i1> %62, i32 %1587
  %1589 = extractelement <8 x i1> %62, i64 7
  %1590 = and i1 %1586, %1588
  %1591 = and i1 %1589, %1590
  %1592 = extractelement <8 x float> %1493, i32 %1587
  %1593 = select i1 %1591, float %1592, float 0.000000e+00
  %1594 = insertelement <8 x float> %1581, float %1593, i64 7
  %1595 = xor i1 %1591, true
  %1596 = and i1 %1589, %1595
  %1597 = insertelement <8 x i1> %1584, i1 %1596, i64 7
  %1598 = fadd <8 x float> %1493, %1594
  %1599 = extractelement <8 x i1> %62, i32 0
  %1600 = extractelement <8 x i1> %62, i64 0
  %1601 = and i1 true, %1599
  %1602 = and i1 %1600, %1601
  %1603 = extractelement <8 x float> %1598, i32 0
  %1604 = select i1 %1602, float %1603, float 0.000000e+00
  %1605 = insertelement <8 x float> poison, float %1604, i64 0
  %1606 = xor i1 %1602, true
  %1607 = and i1 %1600, %1606
  %1608 = insertelement <8 x i1> poison, i1 %1607, i64 0
  %1609 = extractelement <8 x i1> %62, i32 0
  %1610 = extractelement <8 x i1> %62, i64 1
  %1611 = and i1 true, %1609
  %1612 = and i1 %1610, %1611
  %1613 = extractelement <8 x float> %1598, i32 0
  %1614 = select i1 %1612, float %1613, float 0.000000e+00
  %1615 = insertelement <8 x float> %1605, float %1614, i64 1
  %1616 = xor i1 %1612, true
  %1617 = and i1 %1610, %1616
  %1618 = insertelement <8 x i1> %1608, i1 %1617, i64 1
  %1619 = extractelement <8 x i1> %62, i32 0
  %1620 = extractelement <8 x i1> %62, i64 2
  %1621 = and i1 true, %1619
  %1622 = and i1 %1620, %1621
  %1623 = extractelement <8 x float> %1598, i32 0
  %1624 = select i1 %1622, float %1623, float 0.000000e+00
  %1625 = insertelement <8 x float> %1615, float %1624, i64 2
  %1626 = xor i1 %1622, true
  %1627 = and i1 %1620, %1626
  %1628 = insertelement <8 x i1> %1618, i1 %1627, i64 2
  %1629 = extractelement <8 x i1> %62, i32 0
  %1630 = extractelement <8 x i1> %62, i64 3
  %1631 = and i1 true, %1629
  %1632 = and i1 %1630, %1631
  %1633 = extractelement <8 x float> %1598, i32 0
  %1634 = select i1 %1632, float %1633, float 0.000000e+00
  %1635 = insertelement <8 x float> %1625, float %1634, i64 3
  %1636 = xor i1 %1632, true
  %1637 = and i1 %1630, %1636
  %1638 = insertelement <8 x i1> %1628, i1 %1637, i64 3
  %1639 = extractelement <8 x i1> %62, i32 0
  %1640 = extractelement <8 x i1> %62, i64 4
  %1641 = and i1 true, %1639
  %1642 = and i1 %1640, %1641
  %1643 = extractelement <8 x float> %1598, i32 0
  %1644 = select i1 %1642, float %1643, float 0.000000e+00
  %1645 = insertelement <8 x float> %1635, float %1644, i64 4
  %1646 = xor i1 %1642, true
  %1647 = and i1 %1640, %1646
  %1648 = insertelement <8 x i1> %1638, i1 %1647, i64 4
  %1649 = extractelement <8 x i1> %62, i32 0
  %1650 = extractelement <8 x i1> %62, i64 5
  %1651 = and i1 true, %1649
  %1652 = and i1 %1650, %1651
  %1653 = extractelement <8 x float> %1598, i32 0
  %1654 = select i1 %1652, float %1653, float 0.000000e+00
  %1655 = insertelement <8 x float> %1645, float %1654, i64 5
  %1656 = xor i1 %1652, true
  %1657 = and i1 %1650, %1656
  %1658 = insertelement <8 x i1> %1648, i1 %1657, i64 5
  %1659 = extractelement <8 x i1> %62, i32 0
  %1660 = extractelement <8 x i1> %62, i64 6
  %1661 = and i1 true, %1659
  %1662 = and i1 %1660, %1661
  %1663 = extractelement <8 x float> %1598, i32 0
  %1664 = select i1 %1662, float %1663, float 0.000000e+00
  %1665 = insertelement <8 x float> %1655, float %1664, i64 6
  %1666 = xor i1 %1662, true
  %1667 = and i1 %1660, %1666
  %1668 = insertelement <8 x i1> %1658, i1 %1667, i64 6
  %1669 = extractelement <8 x i1> %62, i32 0
  %1670 = extractelement <8 x i1> %62, i64 7
  %1671 = and i1 true, %1669
  %1672 = and i1 %1670, %1671
  %1673 = extractelement <8 x float> %1598, i32 0
  %1674 = select i1 %1672, float %1673, float 0.000000e+00
  %1675 = insertelement <8 x float> %1665, float %1674, i64 7
  %1676 = xor i1 %1672, true
  %1677 = and i1 %1670, %1676
  %1678 = insertelement <8 x i1> %1668, i1 %1677, i64 7
  %1679 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1680 = bitcast <8 x i1> %62 to i8
  %1681 = call i8 @llvm.cttz.i8(i8 %1680, i1 false)
  %1682 = zext i8 %1681 to i32
  %1683 = select i1 %1679, i32 %1682, i32 0
  %1684 = extractelement <8 x float> %1675, i32 %1683
  %.spill.load267 = load float, ptr %.spill38, align 4
  %1685 = fadd float %.spill.load267, %1684
  store float %1685, ptr %.spill47, align 4
  br label %direct.schedule.36

direct.schedule.36:                               ; preds = %direct.schedule.35
  %1686 = load <8 x i64>, ptr %.slot48, align 64
  %1687 = select <8 x i1> %62, <8 x i64> zeroinitializer, <8 x i64> %1686
  store <8 x i64> %1687, ptr %.slot48, align 64
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state268 = load <8 x i64>, ptr %.slot48, align 64
  %1688 = icmp slt <8 x i64> %.state268, splat (i64 512)
  %1689 = extractelement <8 x i1> %1688, i32 0
  br i1 %1689, label %direct.true269, label %direct.false270

direct.schedule.38:                               ; preds = %direct.true269
  %.state271 = load <8 x i64>, ptr %.slot48, align 64
  %1690 = mul <8 x i64> %.state271, splat (i64 8)
  %.spill.load272 = load <8 x i64>, ptr %.spill, align 64
  %1691 = add <8 x i64> %1690, %.spill.load272
  %tile_snapshot.spill.load273 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1692 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load273, 0
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load273, 1
  %.state274 = load <8 x i64>, ptr %.slot48, align 64
  %1694 = mul <8 x i64> %.state274, splat (i64 32)
  %1695 = add <8 x i64> %1693, %1694
  %1696 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1692, 0
  %1697 = insertvalue { <8 x ptr>, <8 x i64> } %1696, <8 x i64> %1695, 1
  %1698 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1699 = extractvalue { <8 x ptr>, <8 x i64> } %1697, 1
  %1700 = extractelement <8 x ptr> %1698, i32 0
  %1701 = extractelement <8 x i64> %1699, i32 0
  %1702 = sub i64 %1701, 0
  %1703 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %1704 = select i1 %1703, i64 %1702, i64 0
  %private.contiguous.address275 = getelementptr i8, ptr %1700, i64 %1704
  %private.contiguous.load276 = load <8 x float>, ptr %private.contiguous.address275, align 4
  %1705 = select <8 x i1> %62, <8 x float> %private.contiguous.load276, <8 x float> zeroinitializer
  %.spill.load277 = load float, ptr %.spill47, align 4
  %.splatinsert278 = insertelement <8 x float> poison, float %.spill.load277, i64 0
  %.splat279 = shufflevector <8 x float> %.splatinsert278, <8 x float> poison, <8 x i32> zeroinitializer
  %1706 = fdiv <8 x float> %1705, %.splat279
  %.spill.load280 = load <8 x i64>, ptr %.spill17, align 64
  %1707 = add <8 x i64> %.spill.load280, zeroinitializer
  %1708 = add <8 x i64> zeroinitializer, %1707
  %1709 = add <8 x i64> zeroinitializer, %1691
  %1710 = mul <8 x i64> %1708, splat (i64 4097)
  %1711 = add <8 x i64> %1710, %1709
  %1712 = extractvalue { ptr, i64 } %38, 0
  %1713 = extractelement <8 x i64> %1711, i32 0
  %1714 = sub i64 %1713, 0
  %1715 = mul i64 %1714, 4
  %buffer.contiguous.address281 = getelementptr i8, ptr %1712, i64 %1715
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1706, ptr %buffer.contiguous.address281, i32 1, <8 x i1> %62)
  %.state282 = load <8 x i64>, ptr %.slot48, align 64
  %1716 = add <8 x i64> %.state282, splat (i64 1)
  %1717 = load <8 x i64>, ptr %.slot48, align 64
  %1718 = select <8 x i1> %62, <8 x i64> %1716, <8 x i64> %1717
  store <8 x i64> %1718, ptr %.slot48, align 64
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false270
  %.spill.load283 = load <8 x i1>, ptr %.spill18, align 1
  %1719 = and <8 x i1> %62, %.spill.load283
  %1720 = xor <8 x i1> %.spill.load283, splat (i1 true)
  %1721 = and <8 x i1> %62, %1720
  %1722 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1719)
  %1723 = bitcast <8 x i1> %1719 to i8
  %1724 = call i8 @llvm.cttz.i8(i8 %1723, i1 false)
  %1725 = zext i8 %1724 to i32
  %1726 = select i1 %1722, i32 %1725, i32 0
  %.spill.load284 = load <8 x i64>, ptr %.spill, align 64
  %1727 = add <8 x i64> splat (i64 4096), %.spill.load284
  %tile_snapshot.spill.load285 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1728 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 0
  %1729 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 1
  %1730 = add <8 x i64> %1729, splat (i64 16384)
  %1731 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1728, 0
  %1732 = insertvalue { <8 x ptr>, <8 x i64> } %1731, <8 x i64> %1730, 1
  %1733 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1734 = extractvalue { <8 x ptr>, <8 x i64> } %1732, 1
  %1735 = extractelement <8 x ptr> %1733, i32 0
  %1736 = extractelement <8 x i64> %1734, i32 %1726
  %1737 = zext i32 %1726 to i64
  %1738 = mul i64 %1737, 4
  %1739 = sub i64 %1736, %1738
  %1740 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1719)
  %1741 = select i1 %1740, i64 %1739, i64 0
  %private.contiguous.address286 = getelementptr i8, ptr %1735, i64 %1741
  %private.contiguous.load287 = load <8 x float>, ptr %private.contiguous.address286, align 4
  %1742 = select <8 x i1> %1719, <8 x float> %private.contiguous.load287, <8 x float> zeroinitializer
  %.spill.load288 = load float, ptr %.spill47, align 4
  %.splatinsert289 = insertelement <8 x float> poison, float %.spill.load288, i64 0
  %.splat290 = shufflevector <8 x float> %.splatinsert289, <8 x float> poison, <8 x i32> zeroinitializer
  %1743 = fdiv <8 x float> %1742, %.splat290
  %.spill.load291 = load <8 x i64>, ptr %.spill17, align 64
  %1744 = add <8 x i64> %.spill.load291, zeroinitializer
  %1745 = add <8 x i64> zeroinitializer, %1744
  %1746 = add <8 x i64> zeroinitializer, %1727
  %1747 = mul <8 x i64> %1745, splat (i64 4097)
  %1748 = add <8 x i64> %1747, %1746
  %1749 = extractvalue { ptr, i64 } %38, 0
  %1750 = extractelement <8 x i64> %1748, i32 %1726
  %1751 = zext i32 %1726 to i64
  %1752 = sub i64 %1750, %1751
  %1753 = mul i64 %1752, 4
  %buffer.contiguous.address292 = getelementptr i8, ptr %1749, i64 %1753
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1743, ptr %buffer.contiguous.address292, i32 1, <8 x i1> %1719)
  %1754 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1721)
  %1755 = bitcast <8 x i1> %1721 to i8
  %1756 = call i8 @llvm.cttz.i8(i8 %1755, i1 false)
  %1757 = zext i8 %1756 to i32
  %1758 = select i1 %1754, i32 %1757, i32 0
  br label %direct.schedule.41

direct.schedule.41:                               ; preds = %direct.schedule.39
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true76:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false77:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true92:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false93:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true108:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false109:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true148:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false149:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.23

direct.true184:                                   ; preds = %direct.schedule.26
  br label %direct.schedule.27

direct.false185:                                  ; preds = %direct.schedule.26
  br label %direct.schedule.28

direct.true231:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false232:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true269:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false270:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  br label %packet.batch.full.loop

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full.loop
  ret void

packet.batch.full.loop:                           ; preds = %packet.batch.full.loop, %packet.batch.full
  %packet.index = phi i32 [ 0, %packet.batch.full ], [ %packet.index.next, %packet.batch.full.loop ]
  %packet.thread.offset = mul i32 %packet.index, 8
  %packet.thread.index = add i32 %base.thread.index, %packet.thread.offset
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config) #6
  %packet.index.next = add i32 %packet.index, 1
  %packet.batch.has.more = icmp ult i32 %packet.index.next, %packet_count
  br i1 %packet.batch.has.more, label %packet.batch.full.loop, label %packet.batch.exit

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #4 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #6 = { alwaysinline }


/private/tmp/luisa-packet-inline.UY1lIE/capture/masked_softmax-1024x4097/off/object/tile_xir_w8_36378_1788935098703788_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0x90
       4:      	stp	d15, d14, [sp, #0x10]
       8:      	stp	d13, d12, [sp, #0x20]
       c:      	stp	d11, d10, [sp, #0x30]
      10:      	stp	d9, d8, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	mov	x11, #0x0               ; =0
      28:      	ldr	x8, [x1, #0x88]
      2c:      	mov	w9, #0x5088             ; =20616
      30:      	movk	w9, #0x1, lsl #16
      34:      	add	x10, x8, #0x11, lsl #12 ; =0x11000
      38:      	add	x13, x10, #0x68
      3c:      	mov	w10, #0xd068            ; =53352
      40:      	add	x14, x8, x10
      44:      	ldr	x16, [x0]
      48:      	ldr	w10, [x1]
      4c:      	ldr	w12, [x1, #0x24]
      50:      	add	w10, w12, w10, lsl #5
      54:      	lsr	w10, w10, #3
      58:      	dup.4s	v0, w10
      5c:      	ushll.2d	v1, v0, #0x0
      60:      	fmov	x10, d1
      64:      	mov	w12, #0x4004            ; =16388
      68:      	umaddl	x12, w10, w12, x16
      6c:      	mov	w15, #0xc020            ; =49184
      70:      	ldr	x10, [x0, #0x30]
      74:      	add	x17, x12, x11
      78:      	ldp	q2, q3, [x17]
      7c:      	add	x17, x8, x11
      80:      	stp	q2, q3, [x17]
      84:      	add	x11, x11, #0x20
      88:      	cmp	x11, #0x4, lsl #12      ; =0x4000
      8c:      	b.ne	0x74 <ltmp0+0x74>
      90:      	mov	x17, #0x0               ; =0
      94:      	fmov	x11, d1
      98:      	add	x11, x11, x11, lsl #12
      9c:      	lsl	x12, x11, #2
      a0:      	add	x11, x12, #0x4, lsl #12 ; =0x4000
      a4:      	ldr	s1, [x16, x11]
      a8:      	mov	w16, #0x4000            ; =16384
      ac:      	str	s1, [x8, x16]
      b0:      	adrp	x16, 0x0 <ltmp0>
      b4:      	ldr	q1, [x16]
      b8:      	adrp	x16, 0x0 <ltmp0>
      bc:      	ldr	q2, [x16]
      c0:      	adrp	x16, 0x0 <ltmp0>
      c4:      	ldr	q3, [x16]
      c8:      	adrp	x16, 0x0 <ltmp0>
      cc:      	ldr	q4, [x16]
      d0:      	mov	w16, #0x1               ; =1
      d4:      	dup.2d	v5, x16
      d8:      	mov	w16, #0x4020            ; =16416
      dc:      	add	x16, x8, x16
      e0:      	movi.2d	v6, #0000000000000000
      e4:      	movi.2d	v7, #0000000000000000
      e8:      	movi.2d	v16, #0000000000000000
      ec:      	movi.2d	v17, #0000000000000000
      f0:      	shl.2d	v18, v6, #0x3
      f4:      	shl.2d	v19, v7, #0x3
      f8:      	shl.2d	v20, v16, #0x3
      fc:      	shl.2d	v21, v17, #0x3
     100:      	orr.16b	v21, v21, v1
     104:      	orr.16b	v20, v20, v2
     108:      	orr.16b	v19, v19, v3
     10c:      	orr.16b	v18, v18, v4
     110:      	add	x17, x16, x17, lsl #6
     114:      	stp	q18, q19, [x17]
     118:      	stp	q20, q21, [x17, #0x20]
     11c:      	add.2d	v16, v16, v5
     120:      	add.2d	v7, v7, v5
     124:      	add.2d	v17, v17, v5
     128:      	add.2d	v6, v6, v5
     12c:      	fmov	x17, d6
     130:      	cmp	x17, #0x200
     134:      	b.lt	0xf0 <ltmp0+0xf0>
     138:      	mov	x17, #0x0               ; =0
     13c:      	mov	w0, #0x1000             ; =4096
     140:      	str	x0, [x8, x15]
     144:      	mov	w0, #0xf001             ; =61441
     148:      	movk	w0, #0xff, lsl #16
     14c:      	dup.4s	v1, w0
     150:      	mov	w0, #0x1001             ; =4097
     154:      	dup.4s	v2, w0
     158:      	mov	w0, #0xc060             ; =49248
     15c:      	add	x0, x8, x0
     160:      	umull2.2d	v3, v0, v1
     164:      	umull.2d	v4, v0, v1
     168:      	uzp2.4s	v4, v4, v3
     16c:      	ushr.4s	v4, v4, #0x4
     170:      	mov.16b	v6, v0
     174:      	mls.4s	v6, v4, v2
     178:      	umull.2d	v1, v0, v1
     17c:      	uzp2.4s	v1, v1, v3
     180:      	ushr.4s	v1, v1, #0x4
     184:      	mls.4s	v0, v1, v2
     188:      	ushll2.2d	v5, v0, #0x0
     18c:      	ushll2.2d	v7, v6, #0x0
     190:      	ushll.2d	v16, v0, #0x0
     194:      	ushll.2d	v6, v6, #0x0
     198:      	movi.2d	v17, #0000000000000000
     19c:      	dup.2d	v0, x0
     1a0:      	adrp	x0, 0x0 <ltmp0>
     1a4:      	ldr	q1, [x0]
     1a8:      	adrp	x0, 0x0 <ltmp0>
     1ac:      	ldr	q2, [x0]
     1b0:      	adrp	x0, 0x0 <ltmp0>
     1b4:      	ldr	q3, [x0]
     1b8:      	adrp	x0, 0x0 <ltmp0>
     1bc:      	ldr	q4, [x0]
     1c0:      	movi.8b	v18, #0x1
     1c4:      	mov	w0, #0x1                ; =1
     1c8:      	dup.2d	v19, x0
     1cc:      	movi.2d	v20, #0000000000000000
     1d0:      	movi.2d	v21, #0000000000000000
     1d4:      	movi.2d	v22, #0000000000000000
     1d8:      	add	x17, x16, x17, lsl #6
     1dc:      	ldp	q24, q23, [x17, #0x20]
     1e0:      	ldp	q25, q26, [x17]
     1e4:      	add.2d	v27, v22, v4
     1e8:      	add.2d	v27, v27, v0
     1ec:      	add.2d	v28, v21, v3
     1f0:      	add.2d	v29, v20, v2
     1f4:      	add.2d	v30, v17, v1
     1f8:      	add.2d	v30, v30, v0
     1fc:      	cmge.2d	v26, v7, v26
     200:      	cmge.2d	v25, v6, v25
     204:      	uzp1.4s	v25, v25, v26
     208:      	cmge.2d	v24, v16, v24
     20c:      	cmge.2d	v23, v5, v23
     210:      	uzp1.4s	v23, v24, v23
     214:      	uzp1.8h	v23, v25, v23
     218:      	xtn.8b	v23, v23
     21c:      	and.8b	v23, v23, v18
     220:      	mov.d	x17, v30[1]
     224:      	fmov	x0, d30
     228:      	str	b23, [x0]
     22c:      	st1.b	{ v23 }[1], [x17]
     230:      	add.2d	v24, v29, v0
     234:      	mov.d	x17, v24[1]
     238:      	fmov	x0, d24
     23c:      	st1.b	{ v23 }[2], [x0]
     240:      	add.2d	v24, v28, v0
     244:      	st1.b	{ v23 }[3], [x17]
     248:      	mov.d	x17, v24[1]
     24c:      	fmov	x0, d24
     250:      	st1.b	{ v23 }[4], [x0]
     254:      	st1.b	{ v23 }[5], [x17]
     258:      	mov.d	x17, v27[1]
     25c:      	fmov	x0, d27
     260:      	st1.b	{ v23 }[6], [x0]
     264:      	st1.b	{ v23 }[7], [x17]
     268:      	add.2d	v21, v21, v19
     26c:      	add.2d	v20, v20, v19
     270:      	add.2d	v22, v22, v19
     274:      	add.2d	v17, v17, v19
     278:      	fmov	x17, d17
     27c:      	cmp	x17, #0x200
     280:      	b.lt	0x1d8 <ltmp0+0x1d8>
     284:      	mov	x16, #0x0               ; =0
     288:      	ldr	d7, [x8, x15]
     28c:      	adrp	x15, 0x0 <ltmp0>
     290:      	ldr	q5, [x15]
     294:      	add.2d	v5, v0, v5
     298:      	cmge.2d	v6, v6, v7
     29c:      	xtn.2s	v6, v6
     2a0:      	uzp1.4h	v6, v6, v0
     2a4:      	uzp1.8b	v6, v6, v0
     2a8:      	movi.8b	v7, #0x1
     2ac:      	and.8b	v6, v6, v7
     2b0:      	fmov	x15, d5
     2b4:      	str	b6, [x15]
     2b8:      	mov	w15, #0xf2ca            ; =62154
     2bc:      	movk	w15, #0xf149, lsl #16
     2c0:      	dup.4s	v6, w15
     2c4:      	mov	w15, #0x1               ; =1
     2c8:      	dup.2d	v7, x15
     2cc:      	movi.2d	v16, #0000000000000000
     2d0:      	movi.2d	v17, #0000000000000000
     2d4:      	movi.2d	v18, #0000000000000000
     2d8:      	movi.2d	v19, #0000000000000000
     2dc:      	add.2d	v20, v19, v4
     2e0:      	add.2d	v20, v20, v0
     2e4:      	add.2d	v21, v18, v3
     2e8:      	add.2d	v21, v21, v0
     2ec:      	add.2d	v22, v17, v2
     2f0:      	add.2d	v22, v22, v0
     2f4:      	add.2d	v23, v16, v1
     2f8:      	add.2d	v23, v23, v0
     2fc:      	mov.d	x15, v23[1]
     300:      	mov.d	x17, v22[1]
     304:      	fmov	x0, d23
     308:      	fmov	x1, d22
     30c:      	mov.d	x2, v21[1]
     310:      	fmov	x3, d21
     314:      	ldr	b21, [x0]
     318:      	ld1.b	{ v21 }[1], [x15]
     31c:      	ld1.b	{ v21 }[2], [x1]
     320:      	mov.d	x15, v20[1]
     324:      	ld1.b	{ v21 }[3], [x17]
     328:      	ld1.b	{ v21 }[4], [x3]
     32c:      	ld1.b	{ v21 }[5], [x2]
     330:      	fmov	x17, d20
     334:      	ld1.b	{ v21 }[6], [x17]
     338:      	ld1.b	{ v21 }[7], [x15]
     33c:      	cmeq.8b	v20, v21, #0
     340:      	sshll.8h	v20, v20, #0x0
     344:      	sshll2.4s	v21, v20, #0x0
     348:      	lsl	x15, x16, #5
     34c:      	add	x16, x8, x15
     350:      	ldp	q23, q22, [x16]
     354:      	sshll.4s	v20, v20, #0x0
     358:      	bsl.16b	v20, v6, v23
     35c:      	bsl.16b	v21, v6, v22
     360:      	add	x15, x14, x15
     364:      	stp	q20, q21, [x15]
     368:      	add.2d	v18, v18, v7
     36c:      	add.2d	v17, v17, v7
     370:      	add.2d	v19, v19, v7
     374:      	add.2d	v16, v16, v7
     378:      	fmov	x16, d16
     37c:      	cmp	x16, #0x200
     380:      	b.lt	0x2dc <ltmp0+0x2dc>
     384:      	mov	x15, #0x0               ; =0
     388:      	str	q5, [sp]
     38c:      	fmov	x16, d5
     390:      	ldr	b6, [x16]
     394:      	cmeq.8b	v6, v6, #0
     398:      	sshll.8h	v6, v6, #0x0
     39c:      	sshll.4s	v6, v6, #0x0
     3a0:      	ldr	q7, [x8, #0x4000]
     3a4:      	mov	w16, #0xf2ca            ; =62154
     3a8:      	movk	w16, #0xf149, lsl #16
     3ac:      	fmov	s16, w16
     3b0:      	bsl.16b	v6, v16, v7
     3b4:      	ldr	q7, [x13]
     3b8:      	mov.s	v7[0], v6[0]
     3bc:      	str	q7, [x13]
     3c0:      	ldp	q7, q16, [x14]
     3c4:      	ldp	q20, q21, [x14, #0x20]
     3c8:      	ldp	q22, q17, [x14, #0x40]
     3cc:      	ldp	q18, q19, [x14, #0x60]
     3d0:      	mov	w16, #0xd128            ; =53544
     3d4:      	add	x16, x8, x16
     3d8:      	add	x17, x16, x15, lsl #5
     3dc:      	ldp	q23, q24, [x17, #-0x40]
     3e0:      	fmaxnm.4s	v16, v16, v24
     3e4:      	fmaxnm.4s	v7, v7, v23
     3e8:      	ldp	q23, q24, [x17, #-0x20]
     3ec:      	fmaxnm.4s	v21, v21, v24
     3f0:      	fmaxnm.4s	v20, v20, v23
     3f4:      	ldp	q23, q24, [x17]
     3f8:      	fmaxnm.4s	v17, v17, v24
     3fc:      	fmaxnm.4s	v22, v22, v23
     400:      	ldp	q23, q24, [x17, #0x20]
     404:      	fmaxnm.4s	v19, v19, v24
     408:      	fmaxnm.4s	v18, v18, v23
     40c:      	add	x15, x15, #0x4
     410:      	cmp	x15, #0x1fc
     414:      	b.lo	0x3d8 <ltmp0+0x3d8>
     418:      	mov	x6, #0x0                ; =0
     41c:      	add	x15, x13, #0x20
     420:      	movi.2d	v23, #0000000000000000
     424:      	mov.s	v23[0], v6[0]
     428:      	fmaxnm.4s	v6, v7, v23
     42c:      	mov.s	v7[0], v6[0]
     430:      	movi.2d	v6, #0000000000000000
     434:      	fmaxnm.4s	v16, v16, v21
     438:      	fmaxnm.4s	v7, v7, v20
     43c:      	fmaxnm.4s	v7, v7, v22
     440:      	fmaxnm.4s	v16, v16, v17
     444:      	fmaxnm.4s	v16, v16, v19
     448:      	fmaxnm.4s	v7, v7, v18
     44c:      	rev64.4s	v17, v7
     450:      	rev64.4s	v18, v16
     454:      	fmaxnm.4s	v16, v16, v18
     458:      	fmaxnm.4s	v7, v7, v17
     45c:      	ext.16b	v17, v7, v7, #0x8
     460:      	ext.16b	v18, v16, v16, #0x8
     464:      	fmaxnm.4s	v16, v16, v18
     468:      	fmaxnm.4s	v7, v7, v17
     46c:      	fmaxnm.4s	v7, v7, v16
     470:      	mov	w16, #-0x800000         ; =-8388608
     474:      	fmov	s16, w16
     478:      	fmaxnm	s7, s7, s16
     47c:      	dup.4s	v16, v7[0]
     480:      	mov	w16, #-0x3d300000       ; =-1026555904
     484:      	dup.4s	v17, w16
     488:      	mov	w16, #0x42c80000        ; =1120403456
     48c:      	dup.4s	v18, w16
     490:      	mov	w16, #0xaa3b            ; =43579
     494:      	movk	w16, #0x3fb8, lsl #16
     498:      	dup.4s	v19, w16
     49c:      	movi.4s	v20, #0x4b, lsl #24
     4a0:      	mvni.4s	v21, #0x80, lsl #24
     4a4:      	mov	w16, #0x7200            ; =29184
     4a8:      	movk	w16, #0xbf31, lsl #16
     4ac:      	mov	w17, #0xbe8e            ; =48782
     4b0:      	movk	w17, #0xb5bf, lsl #16
     4b4:      	mov	w0, #0x2bda             ; =11226
     4b8:      	movk	w0, #0x3950, lsl #16
     4bc:      	mov	w1, #0x96c9             ; =38601
     4c0:      	movk	w1, #0x3ab6, lsl #16
     4c4:      	mov	w2, #0x88a6             ; =34982
     4c8:      	movk	w2, #0x3c08, lsl #16
     4cc:      	mov	w3, #0xaa7a             ; =43642
     4d0:      	movk	w3, #0x3d2a, lsl #16
     4d4:      	mov	w4, #0xaaab             ; =43691
     4d8:      	movk	w4, #0x3e2a, lsl #16
     4dc:      	movi.4s	v22, #0x3f, lsl #24
     4e0:      	mvni.4s	v23, #0x7f, msl #16
     4e4:      	fneg.4s	v23, v23
     4e8:      	mvni.4s	v24, #0x3f, msl #16
     4ec:      	fneg.4s	v24, v24
     4f0:      	mov	w5, #0x1                ; =1
     4f4:      	movi.2d	v25, #0000000000000000
     4f8:      	movi.2d	v26, #0000000000000000
     4fc:      	movi.2d	v27, #0000000000000000
     500:      	add.2d	v28, v27, v4
     504:      	add.2d	v28, v28, v0
     508:      	add.2d	v29, v26, v3
     50c:      	add.2d	v29, v29, v0
     510:      	add.2d	v30, v25, v2
     514:      	add.2d	v31, v6, v1
     518:      	add.2d	v30, v30, v0
     51c:      	add.2d	v31, v31, v0
     520:      	mov.d	x7, v31[1]
     524:      	fmov	x19, d31
     528:      	mov.d	x20, v30[1]
     52c:      	fmov	x21, d30
     530:      	mov.d	x22, v29[1]
     534:      	fmov	x23, d29
     538:      	mov.d	x24, v28[1]
     53c:      	fmov	x25, d28
     540:      	ldr	b28, [x19]
     544:      	ld1.b	{ v28 }[1], [x7]
     548:      	ld1.b	{ v28 }[2], [x21]
     54c:      	ld1.b	{ v28 }[3], [x20]
     550:      	lsl	x6, x6, #5
     554:      	add	x7, x14, x6
     558:      	ld1.b	{ v28 }[4], [x23]
     55c:      	ldp	q30, q29, [x7]
     560:      	fsub.4s	v29, v29, v16
     564:      	fsub.4s	v30, v30, v16
     568:      	ld1.b	{ v28 }[5], [x22]
     56c:      	fcmge.4s	v31, v30, v17
     570:      	fcmge.4s	v8, v29, v17
     574:      	fcmge.4s	v9, v18, v30
     578:      	fcmge.4s	v10, v18, v29
     57c:      	ld1.b	{ v28 }[6], [x25]
     580:      	and.16b	v8, v8, v10
     584:      	and.16b	v31, v31, v9
     588:      	and.16b	v31, v31, v30
     58c:      	and.16b	v8, v8, v29
     590:      	ld1.b	{ v28 }[7], [x24]
     594:      	fmul.4s	v9, v8, v19
     598:      	fmul.4s	v10, v31, v19
     59c:      	mov.16b	v11, v21
     5a0:      	bsl.16b	v11, v20, v10
     5a4:      	mov.16b	v12, v21
     5a8:      	bsl.16b	v12, v20, v9
     5ac:      	fadd.4s	v9, v9, v12
     5b0:      	cmeq.8b	v28, v28, #0
     5b4:      	fadd.4s	v10, v10, v11
     5b8:      	fsub.4s	v10, v10, v11
     5bc:      	fsub.4s	v9, v9, v12
     5c0:      	fcvtzs.4s	v9, v9
     5c4:      	fcvtzs.4s	v10, v10
     5c8:      	sshll.8h	v28, v28, #0x0
     5cc:      	scvtf.4s	v11, v10
     5d0:      	scvtf.4s	v12, v9
     5d4:      	dup.4s	v13, w16
     5d8:      	fmul.4s	v14, v12, v13
     5dc:      	fmul.4s	v13, v11, v13
     5e0:      	fadd.4s	v13, v31, v13
     5e4:      	fadd.4s	v8, v8, v14
     5e8:      	dup.4s	v14, w17
     5ec:      	fmul.4s	v11, v11, v14
     5f0:      	sshll2.4s	v31, v28, #0x0
     5f4:      	fmul.4s	v12, v12, v14
     5f8:      	fadd.4s	v8, v8, v12
     5fc:      	fadd.4s	v11, v13, v11
     600:      	dup.4s	v12, w0
     604:      	fmul.4s	v13, v11, v12
     608:      	fmul.4s	v12, v8, v12
     60c:      	dup.4s	v14, w1
     610:      	fadd.4s	v12, v12, v14
     614:      	fadd.4s	v13, v13, v14
     618:      	fmul.4s	v13, v11, v13
     61c:      	fmul.4s	v12, v8, v12
     620:      	dup.4s	v14, w2
     624:      	fadd.4s	v12, v12, v14
     628:      	fadd.4s	v13, v13, v14
     62c:      	fmul.4s	v13, v11, v13
     630:      	fmul.4s	v12, v8, v12
     634:      	dup.4s	v14, w3
     638:      	fadd.4s	v12, v12, v14
     63c:      	fadd.4s	v13, v13, v14
     640:      	fmul.4s	v13, v11, v13
     644:      	fmul.4s	v12, v8, v12
     648:      	dup.4s	v14, w4
     64c:      	fadd.4s	v12, v12, v14
     650:      	fadd.4s	v13, v13, v14
     654:      	fmul.4s	v13, v11, v13
     658:      	fmul.4s	v12, v8, v12
     65c:      	fadd.4s	v12, v12, v22
     660:      	fadd.4s	v13, v13, v22
     664:      	fmul.4s	v14, v8, v8
     668:      	fmul.4s	v15, v11, v11
     66c:      	sshll.4s	v5, v28, #0x0
     670:      	fmul.4s	v28, v15, v13
     674:      	fmul.4s	v12, v14, v12
     678:      	fadd.4s	v8, v8, v12
     67c:      	fadd.4s	v11, v11, v28
     680:      	fmov.4s	v28, #1.00000000
     684:      	fadd.4s	v11, v11, v28
     688:      	sshr.4s	v12, v10, #0x1
     68c:      	sshr.4s	v13, v9, #0x1
     690:      	shl.4s	v14, v13, #0x17
     694:      	shl.4s	v15, v12, #0x17
     698:      	add.4s	v15, v15, v28
     69c:      	fadd.4s	v8, v8, v28
     6a0:      	add.4s	v14, v14, v28
     6a4:      	fmul.4s	v8, v8, v14
     6a8:      	sub.4s	v9, v9, v13
     6ac:      	sub.4s	v10, v10, v12
     6b0:      	shl.4s	v10, v10, #0x17
     6b4:      	fmul.4s	v11, v11, v15
     6b8:      	shl.4s	v9, v9, #0x17
     6bc:      	add.4s	v9, v9, v28
     6c0:      	add.4s	v10, v10, v28
     6c4:      	fmul.4s	v10, v11, v10
     6c8:      	fcmgt.4s	v11, v17, v29
     6cc:      	fmul.4s	v8, v8, v9
     6d0:      	bic.16b	v8, v8, v11
     6d4:      	fcmgt.4s	v9, v17, v30
     6d8:      	bic.16b	v9, v10, v9
     6dc:      	fcmgt.4s	v10, v29, v18
     6e0:      	fcmgt.4s	v11, v30, v18
     6e4:      	bit.16b	v9, v23, v11
     6e8:      	bit.16b	v8, v23, v10
     6ec:      	fcmeq.4s	v30, v30, v30
     6f0:      	fcmeq.4s	v29, v29, v29
     6f4:      	bsl.16b	v29, v8, v24
     6f8:      	bsl.16b	v30, v9, v24
     6fc:      	bic.16b	v5, v30, v5
     700:      	bic.16b	v29, v29, v31
     704:      	add	x6, x15, x6
     708:      	dup.2d	v30, x5
     70c:      	stp	q5, q29, [x6]
     710:      	add.2d	v26, v26, v30
     714:      	add.2d	v25, v25, v30
     718:      	add.2d	v27, v27, v30
     71c:      	add.2d	v6, v6, v30
     720:      	fmov	x6, d6
     724:      	cmp	x6, #0x200
     728:      	b.lt	0x500 <ltmp0+0x500>
     72c:      	mov	x14, #0x0               ; =0
     730:      	ldr	q0, [sp]
     734:      	fmov	x16, d0
     738:      	ldr	q0, [x13]
     73c:      	fsub.4s	v1, v0, v7
     740:      	movi.2d	v0, #0000000000000000
     744:      	mov.s	v0[0], v1[0]
     748:      	mov	w17, #-0x3d300000       ; =-1026555904
     74c:      	dup.4s	v1, w17
     750:      	fcmge.4s	v3, v0, v1
     754:      	mov	w17, #0x42c80000        ; =1120403456
     758:      	dup.4s	v2, w17
     75c:      	fcmge.4s	v4, v2, v0
     760:      	and.16b	v3, v3, v4
     764:      	and.16b	v3, v3, v0
     768:      	mov	w17, #0xaa3b            ; =43579
     76c:      	movk	w17, #0x3fb8, lsl #16
     770:      	dup.4s	v4, w17
     774:      	fmul.4s	v4, v3, v4
     778:      	movi.4s	v5, #0x4b, lsl #24
     77c:      	mvni.4s	v6, #0x80, lsl #24
     780:      	bif.16b	v5, v4, v6
     784:      	fadd.4s	v4, v4, v5
     788:      	fsub.4s	v4, v4, v5
     78c:      	fcvtzs.4s	v4, v4
     790:      	scvtf.4s	v5, v4
     794:      	mov	w17, #0x7200            ; =29184
     798:      	movk	w17, #0xbf31, lsl #16
     79c:      	dup.4s	v6, w17
     7a0:      	fmul.4s	v6, v5, v6
     7a4:      	mov	w17, #0xbe8e            ; =48782
     7a8:      	movk	w17, #0xb5bf, lsl #16
     7ac:      	dup.4s	v7, w17
     7b0:      	fadd.4s	v3, v3, v6
     7b4:      	fmul.4s	v5, v5, v7
     7b8:      	fadd.4s	v3, v3, v5
     7bc:      	mov	w17, #0x2bda            ; =11226
     7c0:      	movk	w17, #0x3950, lsl #16
     7c4:      	dup.4s	v5, w17
     7c8:      	fmul.4s	v5, v3, v5
     7cc:      	mov	w17, #0x96c9            ; =38601
     7d0:      	movk	w17, #0x3ab6, lsl #16
     7d4:      	dup.4s	v6, w17
     7d8:      	fadd.4s	v5, v5, v6
     7dc:      	fmul.4s	v5, v3, v5
     7e0:      	mov	w17, #0x88a6            ; =34982
     7e4:      	movk	w17, #0x3c08, lsl #16
     7e8:      	dup.4s	v6, w17
     7ec:      	mov	w17, #0xaa7a            ; =43642
     7f0:      	movk	w17, #0x3d2a, lsl #16
     7f4:      	dup.4s	v7, w17
     7f8:      	fadd.4s	v5, v5, v6
     7fc:      	mov	w17, #0xaaab            ; =43691
     800:      	movk	w17, #0x3e2a, lsl #16
     804:      	dup.4s	v6, w17
     808:      	fmul.4s	v5, v3, v5
     80c:      	fadd.4s	v5, v5, v7
     810:      	ldr	b7, [x16]
     814:      	cmeq.8b	v7, v7, #0
     818:      	sshll.8h	v7, v7, #0x0
     81c:      	sshll.4s	v7, v7, #0x0
     820:      	fmul.4s	v5, v3, v5
     824:      	fadd.4s	v5, v5, v6
     828:      	fmul.4s	v5, v3, v5
     82c:      	movi.4s	v6, #0x3f, lsl #24
     830:      	fadd.4s	v5, v5, v6
     834:      	fmul.4s	v6, v3, v3
     838:      	fmul.4s	v5, v6, v5
     83c:      	fadd.4s	v3, v3, v5
     840:      	fadd.4s	v3, v3, v28
     844:      	sshr.4s	v5, v4, #0x1
     848:      	shl.4s	v6, v5, #0x17
     84c:      	add.4s	v6, v6, v28
     850:      	fmul.4s	v3, v3, v6
     854:      	sub.4s	v4, v4, v5
     858:      	shl.4s	v4, v4, #0x17
     85c:      	add.4s	v4, v4, v28
     860:      	fmul.4s	v3, v3, v4
     864:      	fcmgt.4s	v1, v1, v0
     868:      	bic.16b	v1, v3, v1
     86c:      	fcmgt.4s	v2, v0, v2
     870:      	mvni.4s	v3, #0x7f, msl #16
     874:      	fneg.4s	v3, v3
     878:      	bit.16b	v1, v3, v2
     87c:      	fcmeq.4s	v0, v0, v0
     880:      	mvni.4s	v2, #0x3f, msl #16
     884:      	fneg.4s	v2, v2
     888:      	bsl.16b	v0, v1, v2
     88c:      	bic.16b	v1, v0, v7
     890:      	ldr	q0, [x8, x9]
     894:      	mov.s	v0[0], v1[0]
     898:      	str	q0, [x8, x9]
     89c:      	ldp	q1, q2, [x13, #0x20]
     8a0:      	ldp	q6, q7, [x13, #0x40]
     8a4:      	ldp	q16, q3, [x13, #0x60]
     8a8:      	ldp	q4, q5, [x13, #0x80]
     8ac:      	add	x13, x8, #0x11, lsl #12 ; =0x11000
     8b0:      	add	x13, x13, #0x148
     8b4:      	add	x16, x13, x14, lsl #5
     8b8:      	ldp	q17, q18, [x16, #-0x40]
     8bc:      	fadd.4s	v2, v2, v18
     8c0:      	fadd.4s	v1, v1, v17
     8c4:      	ldp	q17, q18, [x16, #-0x20]
     8c8:      	fadd.4s	v7, v7, v18
     8cc:      	fadd.4s	v6, v6, v17
     8d0:      	ldp	q17, q18, [x16]
     8d4:      	fadd.4s	v3, v3, v18
     8d8:      	fadd.4s	v16, v16, v17
     8dc:      	ldp	q17, q18, [x16, #0x20]
     8e0:      	fadd.4s	v5, v5, v18
     8e4:      	fadd.4s	v4, v4, v17
     8e8:      	add	x14, x14, #0x4
     8ec:      	cmp	x14, #0x1fc
     8f0:      	b.lo	0x8b4 <ltmp0+0x8b4>
     8f4:      	mov	x13, #0x0               ; =0
     8f8:      	fadd.4s	v0, v0, v1
     8fc:      	mov.s	v1[0], v0[0]
     900:      	fadd.4s	v0, v7, v2
     904:      	fadd.4s	v1, v6, v1
     908:      	fadd.4s	v1, v16, v1
     90c:      	fadd.4s	v0, v3, v0
     910:      	fadd.4s	v0, v5, v0
     914:      	fadd.4s	v1, v4, v1
     918:      	rev64.4s	v2, v1
     91c:      	rev64.4s	v3, v0
     920:      	fadd.4s	v0, v0, v3
     924:      	fadd.4s	v1, v1, v2
     928:      	dup.4s	v2, v1[2]
     92c:      	dup.4s	v3, v0[2]
     930:      	fadd.4s	v0, v0, v3
     934:      	fadd.4s	v1, v1, v2
     938:      	fadd.4s	v0, v1, v0
     93c:      	movi	d1, #0000000000000000
     940:      	fadd	s0, s0, s1
     944:      	dup.4s	v1, v0[0]
     948:      	add	x12, x10, x12
     94c:      	add	x14, x15, x13
     950:      	ldp	q3, q2, [x14]
     954:      	fdiv.4s	v3, v3, v1
     958:      	fdiv.4s	v2, v2, v1
     95c:      	add	x14, x12, x13
     960:      	stp	q3, q2, [x14]
     964:      	add	x13, x13, #0x20
     968:      	cmp	x13, #0x4, lsl #12      ; =0x4000
     96c:      	b.ne	0x94c <ltmp0+0x94c>
     970:      	ldr	q1, [x8, x9]
     974:      	fdiv.4s	v0, v1, v0
     978:      	str	s0, [x10, x11]
     97c:      	ldp	x20, x19, [sp, #0x80]
     980:      	ldp	x22, x21, [sp, #0x70]
     984:      	ldp	x24, x23, [sp, #0x60]
     988:      	ldp	x26, x25, [sp, #0x50]
     98c:      	ldp	d9, d8, [sp, #0x40]
     990:      	ldp	d11, d10, [sp, #0x30]
     994:      	ldp	d13, d12, [sp, #0x20]
     998:      	ldp	d15, d14, [sp, #0x10]
     99c:      	add	sp, sp, #0x90
     9a0:      	ret

00000000000009a4 <_llm_rows.packet_batch.blocks>:
     9a4:      	stp	d15, d14, [sp, #-0xa0]!
     9a8:      	stp	d13, d12, [sp, #0x10]
     9ac:      	stp	d11, d10, [sp, #0x20]
     9b0:      	stp	d9, d8, [sp, #0x30]
     9b4:      	stp	x28, x27, [sp, #0x40]
     9b8:      	stp	x26, x25, [sp, #0x50]
     9bc:      	stp	x24, x23, [sp, #0x60]
     9c0:      	stp	x22, x21, [sp, #0x70]
     9c4:      	stp	x20, x19, [sp, #0x80]
     9c8:      	stp	x29, x30, [sp, #0x90]
     9cc:      	sub	sp, sp, #0x9f0
     9d0:      	str	x0, [sp, #0x248]
     9d4:      	cbz	w3, 0x2b0c <_llm_rows.packet_batch.blocks+0x2168>
     9d8:      	mov	x19, x3
     9dc:      	mov	x20, x2
     9e0:      	mov	w22, #0x0               ; =0
     9e4:      	adrp	x8, 0x0 <ltmp0>
     9e8:      	ldr	q0, [x8]
     9ec:      	str	q0, [sp, #0x10]
     9f0:      	adrp	x8, 0x0 <ltmp0>
     9f4:      	ldr	q0, [x8]
     9f8:      	str	q0, [sp, #0x200]
     9fc:      	adrp	x8, 0x0 <ltmp0>
     a00:      	ldr	q0, [x8]
     a04:      	str	q0, [sp, #0x1f0]
     a08:      	movi.8b	v11, #0x1
     a0c:      	mvni.4s	v0, #0x7f, msl #16
     a10:      	fneg.4s	v1, v0
     a14:      	mvni.4s	v0, #0x3f, msl #16
     a18:      	fneg.4s	v0, v0
     a1c:      	stp	q0, q1, [sp, #0x2c0]
     a20:      	ldp	w9, w8, [x2, #0x2c]
     a24:      	str	w9, [sp, #0x244]
     a28:      	str	w8, [sp, #0x240]
     a2c:      	mov	w7, #0xf2ca             ; =62154
     a30:      	movk	w7, #0xf149, lsl #16
     a34:      	ldp	w24, w26, [x2]
     a38:      	mov	w23, #0x4               ; =4
     a3c:      	ldp	w27, w28, [x2, #0x8]
     a40:      	str	w3, [sp, #0x2c]
     a44:      	str	x28, [sp, #0x8]
     a48:      	b	0xa90 <_llm_rows.packet_batch.blocks+0xec>
     a4c:      	mov	w8, #0x18               ; =24
     a50:      	str	w8, [x20, #0x24]
     a54:      	add	w8, w24, #0x1
     a58:      	ldr	w9, [sp, #0x244]
     a5c:      	cmp	w8, w9
     a60:      	cset	w8, eq
     a64:      	csinc	w24, wzr, w24, eq
     a68:      	cinc	w9, w26, eq
     a6c:      	ldr	w10, [sp, #0x240]
     a70:      	cmp	w9, w10
     a74:      	cset	w10, eq
     a78:      	ands	w8, w8, w10
     a7c:      	csel	w26, wzr, w9, ne
     a80:      	add	w27, w27, w8
     a84:      	add	w22, w22, #0x1
     a88:      	cmp	w22, w19
     a8c:      	b.eq	0x2b0c <_llm_rows.packet_batch.blocks+0x2168>
     a90:      	ubfiz	x8, x24, #5, #32
     a94:      	cmp	x8, x28
     a98:      	csel	x9, x8, xzr, ls
     a9c:      	subs	x10, x28, x9
     aa0:      	cmp	x10, #0x20
     aa4:      	mov	w11, #0x20              ; =32
     aa8:      	csel	x10, x10, x11, lo
     aac:      	cmp	x28, x9
     ab0:      	stp	w24, w26, [x20]
     ab4:      	str	w27, [x20, #0x8]
     ab8:      	str	wzr, [x20, #0x24]
     abc:      	ccmp	x8, x28, #0x2, hi
     ac0:      	csel	x25, x10, xzr, ls
     ac4:      	cmp	x25, #0x20
     ac8:      	b.lo	0xb24 <_llm_rows.packet_batch.blocks+0x180>
     acc:      	ldr	x21, [sp, #0x248]
     ad0:      	mov	x0, x21
     ad4:      	mov	x1, x20
     ad8:      	bl	0xad8 <_llm_rows.packet_batch.blocks+0x134>
     adc:      	mov	w8, #0x8                ; =8
     ae0:      	str	w8, [x20, #0x24]
     ae4:      	mov	x0, x21
     ae8:      	mov	x1, x20
     aec:      	bl	0xaec <_llm_rows.packet_batch.blocks+0x148>
     af0:      	mov	w8, #0x10               ; =16
     af4:      	str	w8, [x20, #0x24]
     af8:      	mov	x0, x21
     afc:      	mov	x1, x20
     b00:      	bl	0xb00 <_llm_rows.packet_batch.blocks+0x15c>
     b04:      	mov	w8, #0x18               ; =24
     b08:      	str	w8, [x20, #0x24]
     b0c:      	mov	x0, x21
     b10:      	mov	x1, x20
     b14:      	bl	0xb14 <_llm_rows.packet_batch.blocks+0x170>
     b18:      	mov	w7, #0xf2ca             ; =62154
     b1c:      	movk	w7, #0xf149, lsl #16
     b20:      	b	0xa54 <_llm_rows.packet_batch.blocks+0xb0>
     b24:      	lsr	x21, x25, #3
     b28:      	cmp	x25, #0x8
     b2c:      	b.lo	0xb90 <_llm_rows.packet_batch.blocks+0x1ec>
     b30:      	str	wzr, [x20, #0x24]
     b34:      	ldr	x0, [sp, #0x248]
     b38:      	mov	x1, x20
     b3c:      	bl	0xb3c <_llm_rows.packet_batch.blocks+0x198>
     b40:      	mov	w7, #0xf2ca             ; =62154
     b44:      	movk	w7, #0xf149, lsl #16
     b48:      	cmp	x21, #0x1
     b4c:      	b.eq	0xb90 <_llm_rows.packet_batch.blocks+0x1ec>
     b50:      	mov	w8, #0x8                ; =8
     b54:      	str	w8, [x20, #0x24]
     b58:      	ldr	x0, [sp, #0x248]
     b5c:      	mov	x1, x20
     b60:      	bl	0xb60 <_llm_rows.packet_batch.blocks+0x1bc>
     b64:      	mov	w7, #0xf2ca             ; =62154
     b68:      	movk	w7, #0xf149, lsl #16
     b6c:      	cmp	x21, #0x2
     b70:      	b.eq	0xb90 <_llm_rows.packet_batch.blocks+0x1ec>
     b74:      	mov	w8, #0x10               ; =16
     b78:      	str	w8, [x20, #0x24]
     b7c:      	ldr	x0, [sp, #0x248]
     b80:      	mov	x1, x20
     b84:      	bl	0xb84 <_llm_rows.packet_batch.blocks+0x1e0>
     b88:      	mov	w7, #0xf2ca             ; =62154
     b8c:      	movk	w7, #0xf149, lsl #16
     b90:      	and	w8, w25, #0x7
     b94:      	cbz	w8, 0xa4c <_llm_rows.packet_batch.blocks+0xa8>
     b98:      	dup.4s	v6, w8
     b9c:      	ldp	q0, q1, [sp, #0x1f0]
     ba0:      	cmhi.4s	v0, v6, v0
     ba4:      	cmhi.4s	v1, v6, v1
     ba8:      	uzp1.8h	v3, v1, v0
     bac:      	umaxv.8h	h2, v3
     bb0:      	fmov	w8, s2
     bb4:      	tbz	w8, #0x0, 0xa4c <_llm_rows.packet_batch.blocks+0xa8>
     bb8:      	mov	x10, #0x0               ; =0
     bbc:      	ldr	x2, [x20, #0x88]
     bc0:      	mov	w8, #0x10a8             ; =4264
     bc4:      	movk	w8, #0x1, lsl #16
     bc8:      	add	x8, x2, x8
     bcc:      	str	x8, [sp, #0x178]
     bd0:      	mov	w8, #0xd088             ; =53384
     bd4:      	add	x17, x2, x8
     bd8:      	mov	w8, #0x4020             ; =16416
     bdc:      	add	x8, x2, x8
     be0:      	mov	w9, #0xc060             ; =49248
     be4:      	add	x9, x2, x9
     be8:      	dup.2d	v20, x9
     bec:      	mov	w9, #0xd068             ; =53352
     bf0:      	add	x13, x2, x9
     bf4:      	mov	w9, #0x1088             ; =4232
     bf8:      	movk	w9, #0x1, lsl #16
     bfc:      	add	x9, x2, x9
     c00:      	ldr	x11, [sp, #0x248]
     c04:      	ldr	x12, [x11]
     c08:      	ldr	x11, [x11, #0x30]
     c0c:      	str	x11, [sp, #0x1e8]
     c10:      	ldr	q2, [sp, #0x10]
     c14:      	str	q3, [sp, #0x150]
     c18:      	and.16b	v2, v3, v2
     c1c:      	addv.8h	h3, v2
     c20:      	fmov	w11, s3
     c24:      	and	w11, w11, #0xff
     c28:      	str	w11, [sp, #0x160]
     c2c:      	ubfiz	w11, w24, #2, #27
     c30:      	orr	w11, w11, w21
     c34:      	dup.4s	v2, w11
     c38:      	and.16b	v24, v1, v2
     c3c:      	and.16b	v25, v0, v2
     c40:      	ushll2.2d	v16, v25, #0x0
     c44:      	ushll2.2d	v17, v24, #0x0
     c48:      	ushll.2d	v18, v25, #0x0
     c4c:      	ushll.2d	v5, v24, #0x0
     c50:      	fmov	x11, d5
     c54:      	mov	w14, #0x4004            ; =16388
     c58:      	umaddl	x11, w11, w14, x12
     c5c:      	str	q3, [sp, #0x2f0]
     c60:      	fmov	w14, s3
     c64:      	b	0xc88 <_llm_rows.packet_batch.blocks+0x2e4>
     c68:      	add	x15, x2, x10
     c6c:      	ldp	q4, q7, [x15]
     c70:      	bif.16b	v3, v7, v0
     c74:      	bif.16b	v2, v4, v1
     c78:      	stp	q2, q3, [x15]
     c7c:      	add	x10, x10, #0x20
     c80:      	cmp	x10, #0x4, lsl #12      ; =0x4000
     c84:      	b.eq	0xd1c <_llm_rows.packet_batch.blocks+0x378>
     c88:      	add	x15, x11, x10
     c8c:      	movi.2d	v2, #0000000000000000
     c90:      	movi.2d	v3, #0000000000000000
     c94:      	tbnz	w14, #0x0, 0xcbc <_llm_rows.packet_batch.blocks+0x318>
     c98:      	and	w16, w14, #0xff
     c9c:      	tbnz	w16, #0x1, 0xcc8 <_llm_rows.packet_batch.blocks+0x324>
     ca0:      	tbnz	w16, #0x2, 0xcd4 <_llm_rows.packet_batch.blocks+0x330>
     ca4:      	tbnz	w16, #0x3, 0xce0 <_llm_rows.packet_batch.blocks+0x33c>
     ca8:      	tbnz	w16, #0x4, 0xcec <_llm_rows.packet_batch.blocks+0x348>
     cac:      	tbnz	w16, #0x5, 0xcf8 <_llm_rows.packet_batch.blocks+0x354>
     cb0:      	tbnz	w16, #0x6, 0xd04 <_llm_rows.packet_batch.blocks+0x360>
     cb4:      	tbz	w16, #0x7, 0xc68 <_llm_rows.packet_batch.blocks+0x2c4>
     cb8:      	b	0xd10 <_llm_rows.packet_batch.blocks+0x36c>
     cbc:      	ldr	s2, [x15]
     cc0:      	and	w16, w14, #0xff
     cc4:      	tbz	w16, #0x1, 0xca0 <_llm_rows.packet_batch.blocks+0x2fc>
     cc8:      	add	x0, x15, #0x4
     ccc:      	ld1.s	{ v2 }[1], [x0]
     cd0:      	tbz	w16, #0x2, 0xca4 <_llm_rows.packet_batch.blocks+0x300>
     cd4:      	add	x0, x15, #0x8
     cd8:      	ld1.s	{ v2 }[2], [x0]
     cdc:      	tbz	w16, #0x3, 0xca8 <_llm_rows.packet_batch.blocks+0x304>
     ce0:      	add	x0, x15, #0xc
     ce4:      	ld1.s	{ v2 }[3], [x0]
     ce8:      	tbz	w16, #0x4, 0xcac <_llm_rows.packet_batch.blocks+0x308>
     cec:      	add	x0, x15, #0x10
     cf0:      	ld1.s	{ v3 }[0], [x0]
     cf4:      	tbz	w16, #0x5, 0xcb0 <_llm_rows.packet_batch.blocks+0x30c>
     cf8:      	add	x0, x15, #0x14
     cfc:      	ld1.s	{ v3 }[1], [x0]
     d00:      	tbz	w16, #0x6, 0xcb4 <_llm_rows.packet_batch.blocks+0x310>
     d04:      	add	x0, x15, #0x18
     d08:      	ld1.s	{ v3 }[2], [x0]
     d0c:      	tbz	w16, #0x7, 0xc68 <_llm_rows.packet_batch.blocks+0x2c4>
     d10:      	add	x15, x15, #0x1c
     d14:      	ld1.s	{ v3 }[3], [x15]
     d18:      	b	0xc68 <_llm_rows.packet_batch.blocks+0x2c4>
     d1c:      	xtn.4h	v2, v1
     d20:      	uzp1.8b	v7, v2, v0
     d24:      	sshll.2d	v4, v1, #0x0
     d28:      	adrp	x10, 0x0 <ltmp0>
     d2c:      	ldr	q27, [x10]
     d30:      	and.16b	v19, v4, v27
     d34:      	movi.2d	v30, #0000000000000000
     d38:      	mov.b	v30[0], v7[0]
     d3c:      	adrp	x10, 0x0 <ltmp0>
     d40:      	ldr	d10, [x10]
     d44:      	and.8b	v2, v30, v10
     d48:      	addv.8b	b2, v2
     d4c:      	fmov	w11, s2
     d50:      	umaxv.8b	b2, v30
     d54:      	fmov	w10, s2
     d58:      	rbit	w14, w11
     d5c:      	clz	w14, w14
     d60:      	tst	w10, #0x1
     d64:      	csel	w21, w14, wzr, ne
     d68:      	mov	w14, #0x1000            ; =4096
     d6c:      	dup.2d	v3, x14
     d70:      	str	q19, [sp, #0x140]
     d74:      	orr.16b	v26, v19, v3
     d78:      	mov	w14, #0x1001            ; =4097
     d7c:      	dup.2s	v2, w14
     d80:      	xtn.2s	v19, v5
     d84:      	mov.16b	v21, v26
     d88:      	umlal.2d	v21, v19, v2
     d8c:      	movi.2d	v5, #0000000000000000
     d90:      	mov.b	v5[0], v7[0]
     d94:      	ushll.2d	v5, v5, #0x0
     d98:      	shl.2d	v5, v5, #0x3f
     d9c:      	cmlt.2d	v5, v5, #0
     da0:      	str	q21, [sp, #0x1d0]
     da4:      	and.16b	v5, v5, v21
     da8:      	movi.2d	v7, #0000000000000000
     dac:      	str	q7, [sp, #0x9d0]
     db0:      	str	q7, [sp, #0x9c0]
     db4:      	str	q7, [sp, #0x9b0]
     db8:      	str	q5, [sp, #0x9a0]
     dbc:      	and	x14, x21, #0x7
     dc0:      	add	x15, sp, #0x9a0
     dc4:      	ldr	x14, [x15, x14, lsl #3]
     dc8:      	sub	x14, x14, x21
     dcc:      	add	x12, x12, x14, lsl #2
     dd0:      	movi.2d	v21, #0000000000000000
     dd4:      	tbnz	w10, #0x0, 0x1520 <_llm_rows.packet_batch.blocks+0xb7c>
     dd8:      	tbnz	w11, #0x1, 0x1528 <_llm_rows.packet_batch.blocks+0xb84>
     ddc:      	tbnz	w11, #0x2, 0x1534 <_llm_rows.packet_batch.blocks+0xb90>
     de0:      	tbnz	w11, #0x3, 0x1540 <_llm_rows.packet_batch.blocks+0xb9c>
     de4:      	tbnz	w11, #0x4, 0x154c <_llm_rows.packet_batch.blocks+0xba8>
     de8:      	tbnz	w11, #0x5, 0x1558 <_llm_rows.packet_batch.blocks+0xbb4>
     dec:      	tbnz	w11, #0x6, 0x1564 <_llm_rows.packet_batch.blocks+0xbc0>
     df0:      	tbz	w11, #0x7, 0xdfc <_llm_rows.packet_batch.blocks+0x458>
     df4:      	add	x10, x12, #0x1c
     df8:      	ld1.s	{ v21 }[3], [x10]
     dfc:      	mov	x12, #0x0               ; =0
     e00:      	sshll.2d	v28, v0, #0x0
     e04:      	sshll2.2d	v15, v1, #0x0
     e08:      	sshll2.2d	v31, v0, #0x0
     e0c:      	adrp	x10, 0x0 <ltmp0>
     e10:      	ldr	q5, [x10]
     e14:      	and.16b	v22, v31, v5
     e18:      	adrp	x10, 0x0 <ltmp0>
     e1c:      	ldr	q5, [x10]
     e20:      	and.16b	v23, v15, v5
     e24:      	adrp	x10, 0x0 <ltmp0>
     e28:      	ldr	q5, [x10]
     e2c:      	and.16b	v29, v28, v5
     e30:      	adrp	x10, 0x0 <ltmp0>
     e34:      	ldr	q5, [x10]
     e38:      	and.16b	v5, v4, v5
     e3c:      	str	q5, [sp, #0x960]
     e40:      	str	q23, [sp, #0x970]
     e44:      	str	q29, [sp, #0x980]
     e48:      	str	q22, [sp, #0x990]
     e4c:      	and	x10, x21, #0x7
     e50:      	add	x14, sp, #0x960
     e54:      	ldr	x10, [x14, x10, lsl #3]
     e58:      	orr	x10, x10, #0x4000
     e5c:      	sub	x10, x10, x21, lsl #2
     e60:      	tst	w11, #0xff
     e64:      	csel	x25, xzr, x10, eq
     e68:      	add	x10, x2, x25
     e6c:      	ldp	q4, q22, [x10]
     e70:      	zip2.8b	v23, v30, v0
     e74:      	ushll.4s	v23, v23, #0x0
     e78:      	shl.4s	v23, v23, #0x1f
     e7c:      	cmlt.4s	v23, v23, #0
     e80:      	bif.16b	v21, v22, v23
     e84:      	str	q30, [sp, #0x230]
     e88:      	zip1.8b	v22, v30, v0
     e8c:      	ushll.4s	v22, v22, #0x0
     e90:      	shl.4s	v22, v22, #0x1f
     e94:      	cmlt.4s	v22, v22, #0
     e98:      	bit.16b	v4, v7, v22
     e9c:      	mov.16b	v7, v31
     ea0:      	stp	q4, q21, [x10]
     ea4:      	adrp	x10, 0x0 <ltmp0>
     ea8:      	ldr	q21, [x10]
     eac:      	and.16b	v4, v31, v21
     eb0:      	adrp	x10, 0x0 <ltmp0>
     eb4:      	ldr	q22, [x10]
     eb8:      	and.16b	v23, v15, v22
     ebc:      	adrp	x10, 0x0 <ltmp0>
     ec0:      	ldr	q31, [x10]
     ec4:      	and.16b	v28, v28, v31
     ec8:      	str	q28, [sp, #0x100]
     ecc:      	orr.16b	v28, v28, v3
     ed0:      	stp	q23, q4, [sp, #0x120]
     ed4:      	orr.16b	v30, v23, v3
     ed8:      	orr.16b	v29, v4, v3
     edc:      	umull.2d	v3, v19, v2
     ee0:      	str	q3, [sp, #0x180]
     ee4:      	xtn.2s	v3, v17
     ee8:      	xtn.2s	v17, v18
     eec:      	xtn.2s	v16, v16
     ef0:      	mov.16b	v4, v29
     ef4:      	umlal.2d	v4, v16, v2
     ef8:      	str	q4, [sp, #0x1b0]
     efc:      	mov.16b	v4, v30
     f00:      	umlal.2d	v4, v3, v2
     f04:      	mov.16b	v3, v28
     f08:      	umlal.2d	v3, v17, v2
     f0c:      	stp	q3, q4, [sp, #0x190]
     f10:      	mov	w10, #0x1               ; =1
     f14:      	dup.2d	v2, x10
     f18:      	ushll2.2d	v3, v0, #0x0
     f1c:      	and.16b	v8, v3, v2
     f20:      	ushll2.2d	v3, v1, #0x0
     f24:      	and.16b	v9, v3, v2
     f28:      	ushll.2d	v3, v0, #0x0
     f2c:      	and.16b	v12, v3, v2
     f30:      	ushll.2d	v3, v1, #0x0
     f34:      	and.16b	v13, v3, v2
     f38:      	movi.2d	v2, #0000000000000000
     f3c:      	movi.2d	v3, #0000000000000000
     f40:      	movi.2d	v16, #0000000000000000
     f44:      	movi.2d	v17, #0000000000000000
     f48:      	stp	q9, q8, [sp, #0x320]
     f4c:      	stp	q13, q12, [sp, #0x300]
     f50:      	str	q15, [sp, #0x2e0]
     f54:      	sshll.2d	v18, v0, #0x0
     f58:      	sshll.2d	v19, v1, #0x0
     f5c:      	shl.2d	v8, v17, #0x3
     f60:      	shl.2d	v9, v2, #0x3
     f64:      	shl.2d	v12, v16, #0x3
     f68:      	shl.2d	v13, v3, #0x3
     f6c:      	orr.16b	v13, v13, v22
     f70:      	orr.16b	v12, v12, v31
     f74:      	orr.16b	v9, v9, v27
     f78:      	orr.16b	v8, v8, v21
     f7c:      	add	x10, x8, x12, lsl #6
     f80:      	ldp	q15, q14, [x10]
     f84:      	ldp	q4, q23, [x10, #0x20]
     f88:      	bit.16b	v23, v8, v7
     f8c:      	bsl.16b	v19, v9, v15
     f90:      	ldr	q15, [sp, #0x2e0]
     f94:      	ldp	q9, q8, [sp, #0x320]
     f98:      	bit.16b	v4, v12, v18
     f9c:      	mov.16b	v18, v15
     fa0:      	bsl.16b	v18, v13, v14
     fa4:      	ldp	q13, q12, [sp, #0x300]
     fa8:      	stp	q19, q18, [x10]
     fac:      	stp	q4, q23, [x10, #0x20]
     fb0:      	add.2d	v3, v3, v9
     fb4:      	add.2d	v16, v16, v12
     fb8:      	add.2d	v17, v17, v8
     fbc:      	add.2d	v2, v2, v13
     fc0:      	fmov	x12, d2
     fc4:      	cmp	x12, #0x200
     fc8:      	b.lt	0xf54 <_llm_rows.packet_batch.blocks+0x5b0>
     fcc:      	mov	x12, #0x0               ; =0
     fd0:      	mov	w10, #0x1001            ; =4097
     fd4:      	dup.4s	v2, w10
     fd8:      	and.16b	v3, v1, v2
     fdc:      	mvn.16b	v4, v1
     fe0:      	sub.4s	v3, v3, v4
     fe4:      	and.16b	v2, v0, v2
     fe8:      	mvn.16b	v4, v0
     fec:      	sub.4s	v2, v2, v4
     ff0:      	mov.s	w10, v2[1]
     ff4:      	mov.s	w14, v25[1]
     ff8:      	udiv	w15, w14, w10
     ffc:      	msub	w14, w15, w10, w14
    1000:      	mov.s	w10, v2[2]
    1004:      	mov.s	w15, v2[3]
    1008:      	fmov	w16, s2
    100c:      	fmov	w0, s25
    1010:      	udiv	w1, w0, w16
    1014:      	msub	w16, w1, w16, w0
    1018:      	mov.s	w0, v25[2]
    101c:      	udiv	w1, w0, w10
    1020:      	msub	w0, w1, w10, w0
    1024:      	mov.s	w10, v25[3]
    1028:      	udiv	w1, w10, w15
    102c:      	msub	w15, w1, w15, w10
    1030:      	mov.s	w10, v3[1]
    1034:      	mov.s	w1, v24[1]
    1038:      	udiv	w3, w1, w10
    103c:      	msub	w1, w3, w10, w1
    1040:      	mov.s	w10, v3[2]
    1044:      	mov.s	w3, v3[3]
    1048:      	fmov	w4, s3
    104c:      	fmov	w5, s24
    1050:      	udiv	w6, w5, w4
    1054:      	msub	w4, w6, w4, w5
    1058:      	mov.s	w5, v24[2]
    105c:      	udiv	w6, w5, w10
    1060:      	msub	w10, w6, w10, w5
    1064:      	mov.s	w5, v24[3]
    1068:      	udiv	w6, w5, w3
    106c:      	msub	w3, w6, w3, w5
    1070:      	tst	w11, #0xff
    1074:      	fmov	s2, w16
    1078:      	mov.s	v2[1], w14
    107c:      	mov.s	v2[2], w0
    1080:      	mov.s	v2[3], w15
    1084:      	sshll.2d	v19, v0, #0x0
    1088:      	sshll.2d	v18, v1, #0x0
    108c:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x65c>
    1090:      	ldr	q3, [x11]
    1094:      	and.16b	v3, v18, v3
    1098:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x65c>
    109c:      	ldr	q4, [x11]
    10a0:      	and.16b	v4, v19, v4
    10a4:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x65c>
    10a8:      	ldr	q16, [x11]
    10ac:      	and.16b	v16, v15, v16
    10b0:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x65c>
    10b4:      	ldr	q17, [x11]
    10b8:      	and.16b	v17, v7, v17
    10bc:      	str	q17, [sp, #0x950]
    10c0:      	str	q4, [sp, #0x940]
    10c4:      	str	q16, [sp, #0x930]
    10c8:      	str	q3, [sp, #0x920]
    10cc:      	fmov	s3, w4
    10d0:      	and	x11, x21, #0x7
    10d4:      	add	x14, sp, #0x920
    10d8:      	ldr	x11, [x14, x11, lsl #3]
    10dc:      	orr	x11, x11, #0x8000
    10e0:      	sub	x11, x11, x21, lsl #3
    10e4:      	csel	x11, xzr, x11, eq
    10e8:      	mov.s	v3[1], w1
    10ec:      	add	x14, x8, x11
    10f0:      	ldp	q4, q16, [x14, #0x20]
    10f4:      	ldr	q25, [sp, #0x230]
    10f8:      	mov	b17, v25[2]
    10fc:      	mov.b	v17[4], v25[3]
    1100:      	ldp	q21, q22, [x14]
    1104:      	ushll.2d	v17, v17, #0x0
    1108:      	shl.2d	v17, v17, #0x3f
    110c:      	cmlt.2d	v17, v17, #0
    1110:      	bsl.16b	v17, v30, v22
    1114:      	mov	b22, v25[0]
    1118:      	mov.b	v22[4], v25[1]
    111c:      	ushll.2d	v22, v22, #0x0
    1120:      	shl.2d	v22, v22, #0x3f
    1124:      	cmlt.2d	v22, v22, #0
    1128:      	bit.16b	v21, v26, v22
    112c:      	mov	b22, v25[6]
    1130:      	mov.b	v22[4], v25[7]
    1134:      	ushll.2d	v22, v22, #0x0
    1138:      	shl.2d	v22, v22, #0x3f
    113c:      	cmlt.2d	v22, v22, #0
    1140:      	bit.16b	v16, v29, v22
    1144:      	mov	b22, v25[4]
    1148:      	mov.b	v22[4], v25[5]
    114c:      	ushll.2d	v22, v22, #0x0
    1150:      	shl.2d	v22, v22, #0x3f
    1154:      	cmlt.2d	v22, v22, #0
    1158:      	bit.16b	v4, v28, v22
    115c:      	mov.s	v3[2], w10
    1160:      	mov.s	v3[3], w3
    1164:      	and.16b	v22, v1, v3
    1168:      	stp	q4, q16, [x14, #0x20]
    116c:      	stp	q21, q17, [x14]
    1170:      	and.16b	v3, v0, v2
    1174:      	ushll2.2d	v2, v3, #0x0
    1178:      	ushll2.2d	v16, v22, #0x0
    117c:      	ushll.2d	v3, v3, #0x0
    1180:      	ushll.2d	v17, v22, #0x0
    1184:      	and.16b	v26, v7, v20
    1188:      	and.16b	v27, v15, v20
    118c:      	and.16b	v28, v19, v20
    1190:      	and.16b	v29, v18, v20
    1194:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x65c>
    1198:      	ldr	q4, [x10]
    119c:      	str	q7, [sp, #0x210]
    11a0:      	and.16b	v30, v7, v4
    11a4:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x65c>
    11a8:      	ldr	q4, [x10]
    11ac:      	and.16b	v31, v15, v4
    11b0:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x65c>
    11b4:      	ldr	q4, [x10]
    11b8:      	and.16b	v14, v19, v4
    11bc:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x65c>
    11c0:      	ldr	q4, [x10]
    11c4:      	and.16b	v4, v18, v4
    11c8:      	str	q4, [sp, #0x340]
    11cc:      	ldp	q4, q7, [sp, #0x1f0]
    11d0:      	cmhs.4s	v4, v4, v6
    11d4:      	cmhs.4s	v6, v7, v6
    11d8:      	uzp1.8h	v4, v6, v4
    11dc:      	xtn.8b	v6, v4
    11e0:      	movi.2d	v18, #0000000000000000
    11e4:      	movi.2d	v20, #0000000000000000
    11e8:      	movi.2d	v21, #0000000000000000
    11ec:      	movi.2d	v22, #0000000000000000
    11f0:      	ldr	q7, [sp, #0x2f0]
    11f4:      	b	0x1214 <_llm_rows.packet_batch.blocks+0x870>
    11f8:      	add.2d	v20, v20, v9
    11fc:      	add.2d	v21, v21, v12
    1200:      	add.2d	v22, v22, v8
    1204:      	add.2d	v18, v18, v13
    1208:      	fmov	x12, d18
    120c:      	cmp	x12, #0x200
    1210:      	b.ge	0x1314 <_llm_rows.packet_batch.blocks+0x970>
    1214:      	fmov	w10, s7
    1218:      	add	x12, x8, x12, lsl #6
    121c:      	ldp	q19, q4, [x12, #0x20]
    1220:      	ldp	q23, q24, [x12]
    1224:      	cmge.2d	v24, v16, v24
    1228:      	cmge.2d	v23, v17, v23
    122c:      	uzp1.4s	v23, v23, v24
    1230:      	cmge.2d	v19, v3, v19
    1234:      	cmge.2d	v4, v2, v4
    1238:      	uzp1.4s	v4, v19, v4
    123c:      	uzp1.8h	v4, v23, v4
    1240:      	xtn.8b	v4, v4
    1244:      	orr.8b	v4, v6, v4
    1248:      	ldr	q19, [sp, #0x340]
    124c:      	add.2d	v19, v18, v19
    1250:      	add.2d	v24, v29, v19
    1254:      	and.8b	v19, v4, v11
    1258:      	tbnz	w10, #0x0, 0x1298 <_llm_rows.packet_batch.blocks+0x8f4>
    125c:      	and	w10, w10, #0xff
    1260:      	tbnz	w10, #0x1, 0x12a8 <_llm_rows.packet_batch.blocks+0x904>
    1264:      	add.2d	v4, v20, v31
    1268:      	add.2d	v24, v27, v4
    126c:      	tbnz	w10, #0x2, 0x12bc <_llm_rows.packet_batch.blocks+0x918>
    1270:      	tbnz	w10, #0x3, 0x12c8 <_llm_rows.packet_batch.blocks+0x924>
    1274:      	add.2d	v4, v21, v14
    1278:      	add.2d	v24, v28, v4
    127c:      	tbnz	w10, #0x4, 0x12dc <_llm_rows.packet_batch.blocks+0x938>
    1280:      	tbnz	w10, #0x5, 0x12e8 <_llm_rows.packet_batch.blocks+0x944>
    1284:      	add.2d	v4, v22, v30
    1288:      	add.2d	v24, v26, v4
    128c:      	tbnz	w10, #0x6, 0x12fc <_llm_rows.packet_batch.blocks+0x958>
    1290:      	tbz	w10, #0x7, 0x11f8 <_llm_rows.packet_batch.blocks+0x854>
    1294:      	b	0x1308 <_llm_rows.packet_batch.blocks+0x964>
    1298:      	fmov	x12, d24
    129c:      	str	b19, [x12]
    12a0:      	and	w10, w10, #0xff
    12a4:      	tbz	w10, #0x1, 0x1264 <_llm_rows.packet_batch.blocks+0x8c0>
    12a8:      	mov.d	x12, v24[1]
    12ac:      	st1.b	{ v19 }[1], [x12]
    12b0:      	add.2d	v4, v20, v31
    12b4:      	add.2d	v24, v27, v4
    12b8:      	tbz	w10, #0x2, 0x1270 <_llm_rows.packet_batch.blocks+0x8cc>
    12bc:      	fmov	x12, d24
    12c0:      	st1.b	{ v19 }[2], [x12]
    12c4:      	tbz	w10, #0x3, 0x1274 <_llm_rows.packet_batch.blocks+0x8d0>
    12c8:      	mov.d	x12, v24[1]
    12cc:      	st1.b	{ v19 }[3], [x12]
    12d0:      	add.2d	v4, v21, v14
    12d4:      	add.2d	v24, v28, v4
    12d8:      	tbz	w10, #0x4, 0x1280 <_llm_rows.packet_batch.blocks+0x8dc>
    12dc:      	fmov	x12, d24
    12e0:      	st1.b	{ v19 }[4], [x12]
    12e4:      	tbz	w10, #0x5, 0x1284 <_llm_rows.packet_batch.blocks+0x8e0>
    12e8:      	mov.d	x12, v24[1]
    12ec:      	st1.b	{ v19 }[5], [x12]
    12f0:      	add.2d	v4, v22, v30
    12f4:      	add.2d	v24, v26, v4
    12f8:      	tbz	w10, #0x6, 0x1290 <_llm_rows.packet_batch.blocks+0x8ec>
    12fc:      	fmov	x12, d24
    1300:      	st1.b	{ v19 }[6], [x12]
    1304:      	tbz	w10, #0x7, 0x11f8 <_llm_rows.packet_batch.blocks+0x854>
    1308:      	mov.d	x10, v24[1]
    130c:      	st1.b	{ v19 }[7], [x10]
    1310:      	b	0x11f8 <_llm_rows.packet_batch.blocks+0x854>
    1314:      	add	x8, x8, x11
    1318:      	ldp	q6, q4, [x8, #0x20]
    131c:      	ldp	q18, q19, [x8]
    1320:      	cmge.2d	v16, v16, v19
    1324:      	cmge.2d	v17, v17, v18
    1328:      	uzp1.4s	v16, v17, v16
    132c:      	cmge.2d	v3, v3, v6
    1330:      	cmge.2d	v2, v2, v4
    1334:      	uzp1.4s	v2, v3, v2
    1338:      	uzp1.8h	v2, v16, v2
    133c:      	xtn.8b	v2, v2
    1340:      	shl.8b	v3, v25, #0x7
    1344:      	cmlt.8b	v3, v3, #0
    1348:      	and.8b	v3, v3, v10
    134c:      	addv.8b	b3, v3
    1350:      	str	d3, [sp, #0x228]
    1354:      	fmov	w8, s3
    1358:      	orn.8b	v2, v2, v25
    135c:      	ldr	q3, [sp, #0x340]
    1360:      	add.2d	v4, v3, v29
    1364:      	mov	w10, #0x200             ; =512
    1368:      	dup.2d	v3, x10
    136c:      	add.2d	v24, v4, v3
    1370:      	and.8b	v2, v2, v11
    1374:      	tbnz	w8, #0x0, 0x1574 <_llm_rows.packet_batch.blocks+0xbd0>
    1378:      	mov.d	x16, v24[1]
    137c:      	tbnz	w8, #0x1, 0x1584 <_llm_rows.packet_batch.blocks+0xbe0>
    1380:      	add.2d	v4, v31, v27
    1384:      	add.2d	v23, v4, v3
    1388:      	tbnz	w8, #0x2, 0x1594 <_llm_rows.packet_batch.blocks+0xbf0>
    138c:      	mov.d	x15, v23[1]
    1390:      	tbnz	w8, #0x3, 0x15a4 <_llm_rows.packet_batch.blocks+0xc00>
    1394:      	add.2d	v4, v14, v28
    1398:      	add.2d	v22, v4, v3
    139c:      	tbnz	w8, #0x4, 0x15b4 <_llm_rows.packet_batch.blocks+0xc10>
    13a0:      	mov.d	x14, v22[1]
    13a4:      	tbnz	w8, #0x5, 0x15c4 <_llm_rows.packet_batch.blocks+0xc20>
    13a8:      	add.2d	v4, v30, v26
    13ac:      	add.2d	v21, v4, v3
    13b0:      	tbnz	w8, #0x6, 0x15d4 <_llm_rows.packet_batch.blocks+0xc30>
    13b4:      	mov.d	x12, v21[1]
    13b8:      	tbz	w8, #0x7, 0x13c0 <_llm_rows.packet_batch.blocks+0xa1c>
    13bc:      	st1.b	{ v2 }[7], [x12]
    13c0:      	mov	x8, #0x0                ; =0
    13c4:      	movi.2d	v2, #0000000000000000
    13c8:      	movi.2d	v3, #0000000000000000
    13cc:      	movi.2d	v6, #0000000000000000
    13d0:      	movi.2d	v16, #0000000000000000
    13d4:      	b	0x1438 <_llm_rows.packet_batch.blocks+0xa94>
    13d8:      	cmeq.8b	v4, v17, #0
    13dc:      	sshll.8h	v4, v4, #0x0
    13e0:      	sshll2.4s	v18, v4, #0x0
    13e4:      	sshll.4s	v4, v4, #0x0
    13e8:      	lsl	x8, x8, #5
    13ec:      	add	x10, x2, x8
    13f0:      	ldp	q17, q19, [x10]
    13f4:      	and.16b	v19, v0, v19
    13f8:      	and.16b	v20, v1, v17
    13fc:      	dup.4s	v17, w7
    1400:      	bsl.16b	v4, v17, v20
    1404:      	bsl.16b	v18, v17, v19
    1408:      	add	x8, x13, x8
    140c:      	ldp	q19, q20, [x8]
    1410:      	bif.16b	v18, v20, v0
    1414:      	bif.16b	v4, v19, v1
    1418:      	stp	q4, q18, [x8]
    141c:      	add.2d	v3, v3, v9
    1420:      	add.2d	v6, v6, v12
    1424:      	add.2d	v16, v16, v8
    1428:      	add.2d	v2, v2, v13
    142c:      	fmov	x8, d2
    1430:      	cmp	x8, #0x200
    1434:      	b.ge	0x1500 <_llm_rows.packet_batch.blocks+0xb5c>
    1438:      	fmov	w10, s7
    143c:      	ldr	q4, [sp, #0x340]
    1440:      	add.2d	v4, v2, v4
    1444:      	add.2d	v18, v29, v4
    1448:      	tbz	w10, #0x0, 0x1460 <_llm_rows.packet_batch.blocks+0xabc>
    144c:      	fmov	x11, d18
    1450:      	ldr	b17, [x11]
    1454:      	and	w10, w10, #0xff
    1458:      	tbnz	w10, #0x1, 0x146c <_llm_rows.packet_batch.blocks+0xac8>
    145c:      	b	0x1474 <_llm_rows.packet_batch.blocks+0xad0>
    1460:      	movi.2d	v17, #0000000000000000
    1464:      	and	w10, w10, #0xff
    1468:      	tbz	w10, #0x1, 0x1474 <_llm_rows.packet_batch.blocks+0xad0>
    146c:      	mov.d	x11, v18[1]
    1470:      	ld1.b	{ v17 }[1], [x11]
    1474:      	add.2d	v4, v3, v31
    1478:      	add.2d	v18, v27, v4
    147c:      	tbnz	w10, #0x2, 0x14a8 <_llm_rows.packet_batch.blocks+0xb04>
    1480:      	tbnz	w10, #0x3, 0x14b4 <_llm_rows.packet_batch.blocks+0xb10>
    1484:      	add.2d	v4, v6, v14
    1488:      	add.2d	v18, v28, v4
    148c:      	tbnz	w10, #0x4, 0x14c8 <_llm_rows.packet_batch.blocks+0xb24>
    1490:      	tbnz	w10, #0x5, 0x14d4 <_llm_rows.packet_batch.blocks+0xb30>
    1494:      	add.2d	v4, v16, v30
    1498:      	add.2d	v18, v26, v4
    149c:      	tbnz	w10, #0x6, 0x14e8 <_llm_rows.packet_batch.blocks+0xb44>
    14a0:      	tbz	w10, #0x7, 0x13d8 <_llm_rows.packet_batch.blocks+0xa34>
    14a4:      	b	0x14f4 <_llm_rows.packet_batch.blocks+0xb50>
    14a8:      	fmov	x11, d18
    14ac:      	ld1.b	{ v17 }[2], [x11]
    14b0:      	tbz	w10, #0x3, 0x1484 <_llm_rows.packet_batch.blocks+0xae0>
    14b4:      	mov.d	x11, v18[1]
    14b8:      	ld1.b	{ v17 }[3], [x11]
    14bc:      	add.2d	v4, v6, v14
    14c0:      	add.2d	v18, v28, v4
    14c4:      	tbz	w10, #0x4, 0x1490 <_llm_rows.packet_batch.blocks+0xaec>
    14c8:      	fmov	x11, d18
    14cc:      	ld1.b	{ v17 }[4], [x11]
    14d0:      	tbz	w10, #0x5, 0x1494 <_llm_rows.packet_batch.blocks+0xaf0>
    14d4:      	mov.d	x11, v18[1]
    14d8:      	ld1.b	{ v17 }[5], [x11]
    14dc:      	add.2d	v4, v16, v30
    14e0:      	add.2d	v18, v26, v4
    14e4:      	tbz	w10, #0x6, 0x14a0 <_llm_rows.packet_batch.blocks+0xafc>
    14e8:      	fmov	x11, d18
    14ec:      	ld1.b	{ v17 }[6], [x11]
    14f0:      	tbz	w10, #0x7, 0x13d8 <_llm_rows.packet_batch.blocks+0xa34>
    14f4:      	mov.d	x10, v18[1]
    14f8:      	ld1.b	{ v17 }[7], [x10]
    14fc:      	b	0x13d8 <_llm_rows.packet_batch.blocks+0xa34>
    1500:      	ldr	d2, [sp, #0x228]
    1504:      	fmov	w8, s2
    1508:      	tbz	w8, #0x0, 0x15e8 <_llm_rows.packet_batch.blocks+0xc44>
    150c:      	fmov	x10, d24
    1510:      	ldr	b2, [x10]
    1514:      	ldr	q7, [sp, #0x210]
    1518:      	tbnz	w8, #0x1, 0x15f4 <_llm_rows.packet_batch.blocks+0xc50>
    151c:      	b	0x15f8 <_llm_rows.packet_batch.blocks+0xc54>
    1520:      	ldr	s7, [x12]
    1524:      	tbz	w11, #0x1, 0xddc <_llm_rows.packet_batch.blocks+0x438>
    1528:      	add	x10, x12, #0x4
    152c:      	ld1.s	{ v7 }[1], [x10]
    1530:      	tbz	w11, #0x2, 0xde0 <_llm_rows.packet_batch.blocks+0x43c>
    1534:      	add	x10, x12, #0x8
    1538:      	ld1.s	{ v7 }[2], [x10]
    153c:      	tbz	w11, #0x3, 0xde4 <_llm_rows.packet_batch.blocks+0x440>
    1540:      	add	x10, x12, #0xc
    1544:      	ld1.s	{ v7 }[3], [x10]
    1548:      	tbz	w11, #0x4, 0xde8 <_llm_rows.packet_batch.blocks+0x444>
    154c:      	add	x10, x12, #0x10
    1550:      	ld1.s	{ v21 }[0], [x10]
    1554:      	tbz	w11, #0x5, 0xdec <_llm_rows.packet_batch.blocks+0x448>
    1558:      	add	x10, x12, #0x14
    155c:      	ld1.s	{ v21 }[1], [x10]
    1560:      	tbz	w11, #0x6, 0xdf0 <_llm_rows.packet_batch.blocks+0x44c>
    1564:      	add	x10, x12, #0x18
    1568:      	ld1.s	{ v21 }[2], [x10]
    156c:      	tbnz	w11, #0x7, 0xdf4 <_llm_rows.packet_batch.blocks+0x450>
    1570:      	b	0xdfc <_llm_rows.packet_batch.blocks+0x458>
    1574:      	fmov	x10, d24
    1578:      	str	b2, [x10]
    157c:      	mov.d	x16, v24[1]
    1580:      	tbz	w8, #0x1, 0x1380 <_llm_rows.packet_batch.blocks+0x9dc>
    1584:      	st1.b	{ v2 }[1], [x16]
    1588:      	add.2d	v4, v31, v27
    158c:      	add.2d	v23, v4, v3
    1590:      	tbz	w8, #0x2, 0x138c <_llm_rows.packet_batch.blocks+0x9e8>
    1594:      	fmov	x10, d23
    1598:      	st1.b	{ v2 }[2], [x10]
    159c:      	mov.d	x15, v23[1]
    15a0:      	tbz	w8, #0x3, 0x1394 <_llm_rows.packet_batch.blocks+0x9f0>
    15a4:      	st1.b	{ v2 }[3], [x15]
    15a8:      	add.2d	v4, v14, v28
    15ac:      	add.2d	v22, v4, v3
    15b0:      	tbz	w8, #0x4, 0x13a0 <_llm_rows.packet_batch.blocks+0x9fc>
    15b4:      	fmov	x10, d22
    15b8:      	st1.b	{ v2 }[4], [x10]
    15bc:      	mov.d	x14, v22[1]
    15c0:      	tbz	w8, #0x5, 0x13a8 <_llm_rows.packet_batch.blocks+0xa04>
    15c4:      	st1.b	{ v2 }[5], [x14]
    15c8:      	add.2d	v4, v30, v26
    15cc:      	add.2d	v21, v4, v3
    15d0:      	tbz	w8, #0x6, 0x13b4 <_llm_rows.packet_batch.blocks+0xa10>
    15d4:      	fmov	x10, d21
    15d8:      	st1.b	{ v2 }[6], [x10]
    15dc:      	mov.d	x12, v21[1]
    15e0:      	tbnz	w8, #0x7, 0x13bc <_llm_rows.packet_batch.blocks+0xa18>
    15e4:      	b	0x13c0 <_llm_rows.packet_batch.blocks+0xa1c>
    15e8:      	movi.2d	v2, #0000000000000000
    15ec:      	ldr	q7, [sp, #0x210]
    15f0:      	tbz	w8, #0x1, 0x15f8 <_llm_rows.packet_batch.blocks+0xc54>
    15f4:      	ld1.b	{ v2 }[1], [x16]
    15f8:      	tbnz	w8, #0x2, 0x2150 <_llm_rows.packet_batch.blocks+0x17ac>
    15fc:      	tbnz	w8, #0x3, 0x215c <_llm_rows.packet_batch.blocks+0x17b8>
    1600:      	tbnz	w8, #0x4, 0x2164 <_llm_rows.packet_batch.blocks+0x17c0>
    1604:      	tbnz	w8, #0x5, 0x2170 <_llm_rows.packet_batch.blocks+0x17cc>
    1608:      	tbz	w8, #0x6, 0x1614 <_llm_rows.packet_batch.blocks+0xc70>
    160c:      	fmov	x10, d21
    1610:      	ld1.b	{ v2 }[6], [x10]
    1614:      	stp	q27, q26, [sp, #0x2a0]
    1618:      	stp	q29, q28, [sp, #0x280]
    161c:      	stp	q31, q30, [sp, #0x260]
    1620:      	str	q14, [sp, #0x250]
    1624:      	str	q21, [sp, #0x90]
    1628:      	str	q22, [sp, #0x70]
    162c:      	str	q23, [sp, #0x50]
    1630:      	str	q24, [sp, #0x30]
    1634:      	tbz	w8, #0x7, 0x163c <_llm_rows.packet_batch.blocks+0xc98>
    1638:      	ld1.b	{ v2 }[7], [x12]
    163c:      	str	w27, [sp, #0xcc]
    1640:      	str	w22, [sp, #0xec]
    1644:      	str	w26, [sp, #0x11c]
    1648:      	str	x16, [sp, #0x48]
    164c:      	str	x15, [sp, #0x68]
    1650:      	str	x14, [sp, #0x88]
    1654:      	str	x12, [sp, #0xa8]
    1658:      	str	x21, [sp, #0x1e0]
    165c:      	sshll.2d	v3, v1, #0x0
    1660:      	sshll.2d	v4, v0, #0x0
    1664:      	cmeq.8b	v2, v2, #0
    1668:      	sshll.8h	v2, v2, #0x0
    166c:      	sshll2.4s	v6, v2, #0x0
    1670:      	sshll.4s	v2, v2, #0x0
    1674:      	add	x8, x2, x25
    1678:      	ldp	q16, q18, [x8]
    167c:      	zip2.8b	v19, v25, v0
    1680:      	ushll.4s	v19, v19, #0x0
    1684:      	shl.4s	v19, v19, #0x1f
    1688:      	cmlt.4s	v19, v19, #0
    168c:      	and.16b	v18, v19, v18
    1690:      	zip1.8b	v20, v25, v0
    1694:      	ushll.4s	v20, v20, #0x0
    1698:      	shl.4s	v20, v20, #0x1f
    169c:      	cmlt.4s	v20, v20, #0
    16a0:      	and.16b	v16, v20, v16
    16a4:      	mov.16b	v21, v2
    16a8:      	bsl.16b	v21, v17, v16
    16ac:      	mov.16b	v16, v6
    16b0:      	bsl.16b	v16, v17, v18
    16b4:      	str	x25, [sp, #0x1c8]
    16b8:      	add	x8, x13, x25
    16bc:      	ldp	q2, q6, [x8]
    16c0:      	str	q16, [sp, #0xf0]
    16c4:      	bit.16b	v6, v16, v19
    16c8:      	str	q21, [sp, #0xd0]
    16cc:      	bit.16b	v2, v21, v20
    16d0:      	stp	q2, q6, [x8]
    16d4:      	fmov	x8, d5
    16d8:      	dup.2d	v2, x23
    16dc:      	and.16b	v25, v7, v2
    16e0:      	and.16b	v20, v15, v2
    16e4:      	and.16b	v5, v4, v2
    16e8:      	and.16b	v6, v3, v2
    16ec:      	fmov	x2, d6
    16f0:      	ldp	q3, q2, [x17, #0x40]
    16f4:      	and.16b	v2, v0, v2
    16f8:      	and.16b	v3, v1, v3
    16fc:      	ldp	q4, q16, [x17, #0x20]
    1700:      	and.16b	v17, v0, v16
    1704:      	and.16b	v16, v1, v4
    1708:      	ldp	q4, q18, [x17]
    170c:      	and.16b	v18, v0, v18
    1710:      	and.16b	v21, v1, v4
    1714:      	str	x8, [sp, #0xe0]
    1718:      	add	x8, x13, x8
    171c:      	ldp	q4, q19, [x8]
    1720:      	and.16b	v9, v0, v19
    1724:      	mov	x8, x2
    1728:      	and.16b	v10, v1, v4
    172c:      	mov.16b	v12, v6
    1730:      	mov.16b	v13, v20
    1734:      	mov.16b	v14, v5
    1738:      	mov.16b	v30, v15
    173c:      	mov.16b	v15, v25
    1740:      	mov.16b	v31, v7
    1744:      	sshll.2d	v4, v1, #0x0
    1748:      	sshll.2d	v23, v0, #0x0
    174c:      	add	x8, x13, x8, lsl #5
    1750:      	ldp	q19, q24, [x8]
    1754:      	and.16b	v24, v0, v24
    1758:      	and.16b	v19, v1, v19
    175c:      	fmaxnm.4s	v19, v10, v19
    1760:      	fmaxnm.4s	v24, v9, v24
    1764:      	ldp	q7, q11, [x8, #0x20]
    1768:      	and.16b	v11, v0, v11
    176c:      	and.16b	v7, v1, v7
    1770:      	fmaxnm.4s	v7, v21, v7
    1774:      	fmaxnm.4s	v11, v18, v11
    1778:      	ldp	q22, q8, [x8, #0x40]
    177c:      	and.16b	v8, v0, v8
    1780:      	and.16b	v22, v1, v22
    1784:      	fmaxnm.4s	v22, v16, v22
    1788:      	fmaxnm.4s	v8, v17, v8
    178c:      	ldp	q26, q27, [x8, #0x60]
    1790:      	and.16b	v27, v0, v27
    1794:      	and.16b	v26, v1, v26
    1798:      	fmaxnm.4s	v26, v3, v26
    179c:      	fmaxnm.4s	v27, v2, v27
    17a0:      	dup.2d	v28, x23
    17a4:      	and.16b	v29, v31, v28
    17a8:      	add.2d	v15, v15, v29
    17ac:      	and.16b	v29, v30, v28
    17b0:      	add.2d	v13, v13, v29
    17b4:      	and.16b	v23, v23, v28
    17b8:      	add.2d	v14, v14, v23
    17bc:      	and.16b	v4, v4, v28
    17c0:      	add.2d	v12, v12, v4
    17c4:      	bit.16b	v9, v24, v0
    17c8:      	bit.16b	v10, v19, v1
    17cc:      	bit.16b	v18, v11, v0
    17d0:      	bit.16b	v21, v7, v1
    17d4:      	bit.16b	v17, v8, v0
    17d8:      	bit.16b	v16, v22, v1
    17dc:      	bit.16b	v2, v27, v0
    17e0:      	bit.16b	v3, v26, v1
    17e4:      	fmov	x8, d12
    17e8:      	cmp	x8, #0x200
    17ec:      	b.lt	0x1744 <_llm_rows.packet_batch.blocks+0xda0>
    17f0:      	mov	x1, #0x0                ; =0
    17f4:      	ldr	q4, [sp, #0x150]
    17f8:      	xtn.8b	v27, v4
    17fc:      	ldr	q22, [sp, #0x230]
    1800:      	zip1.8b	v4, v22, v0
    1804:      	ushll.4s	v4, v4, #0x0
    1808:      	shl.4s	v4, v4, #0x1f
    180c:      	cmlt.4s	v4, v4, #0
    1810:      	ldr	q7, [sp, #0xd0]
    1814:      	and.16b	v7, v4, v7
    1818:      	zip2.8b	v22, v22, v0
    181c:      	ushll.4s	v22, v22, #0x0
    1820:      	shl.4s	v22, v22, #0x1f
    1824:      	cmlt.4s	v22, v22, #0
    1828:      	ldr	q23, [sp, #0xf0]
    182c:      	and.16b	v23, v22, v23
    1830:      	fmaxnm.4s	v23, v9, v23
    1834:      	fmaxnm.4s	v7, v10, v7
    1838:      	and.16b	v4, v4, v7
    183c:      	and.16b	v7, v22, v23
    1840:      	zip2.8b	v22, v27, v0
    1844:      	ushll.4s	v22, v22, #0x0
    1848:      	shl.4s	v22, v22, #0x1f
    184c:      	cmlt.4s	v22, v22, #0
    1850:      	movi.2d	v23, #0000000000000000
    1854:      	mov.b	v23[2], v27[1]
    1858:      	mov.b	v23[4], v27[2]
    185c:      	mov.b	v23[6], v27[3]
    1860:      	bit.16b	v7, v24, v22
    1864:      	ushll.4s	v22, v23, #0x0
    1868:      	shl.4s	v22, v22, #0x1f
    186c:      	cmlt.4s	v22, v22, #0
    1870:      	bit.16b	v4, v19, v22
    1874:      	fmaxnm.4s	v4, v4, v21
    1878:      	fmaxnm.4s	v7, v7, v18
    187c:      	fmaxnm.4s	v7, v7, v17
    1880:      	fmaxnm.4s	v4, v4, v16
    1884:      	fmaxnm.4s	v3, v4, v3
    1888:      	fmaxnm.4s	v16, v7, v2
    188c:      	ldp	q2, q7, [sp, #0x130]
    1890:      	ldr	q4, [sp, #0x120]
    1894:      	uzp1.4s	v23, v7, v4
    1898:      	ldr	q4, [sp, #0x100]
    189c:      	uzp1.4s	v2, v4, v2
    18a0:      	movi.4s	v7, #0x1
    18a4:      	eor.16b	v4, v23, v7
    18a8:      	mov.s	w10, v4[1]
    18ac:      	mov.s	w11, v4[2]
    18b0:      	eor.16b	v18, v2, v7
    18b4:      	mov.s	w12, v4[3]
    18b8:      	fmov	w8, s4
    18bc:      	add	x14, sp, #0x5e8
    18c0:      	bfxil	x14, x8, #0, #3
    18c4:      	str	d27, [sp, #0x5e8]
    18c8:      	ldrb	w14, [x14]
    18cc:      	and	x8, x8, #0x7
    18d0:      	umov.b	w26, v27[0]
    18d4:      	str	q16, [sp, #0x880]
    18d8:      	str	q3, [sp, #0x870]
    18dc:      	add	x15, sp, #0x870
    18e0:      	ldr	s4, [x15, x8, lsl #2]
    18e4:      	ands	w8, w26, #0x1
    18e8:      	tst	w8, w14
    18ec:      	movi	d26, #0000000000000000
    18f0:      	fcsel	s4, s4, s26, ne
    18f4:      	and	x14, x10, #0x7
    18f8:      	add	x15, sp, #0x5e8
    18fc:      	bfxil	x15, x10, #0, #3
    1900:      	ldrb	w10, [x15]
    1904:      	umov.b	w28, v27[1]
    1908:      	and	w10, w28, w10
    190c:      	str	q16, [sp, #0x860]
    1910:      	str	q3, [sp, #0x850]
    1914:      	add	x15, sp, #0x850
    1918:      	ldr	s7, [x15, x14, lsl #2]
    191c:      	tst	w10, #0x1
    1920:      	fcsel	s7, s7, s26, ne
    1924:      	and	x10, x11, #0x7
    1928:      	add	x14, sp, #0x5e8
    192c:      	bfxil	x14, x11, #0, #3
    1930:      	umov.b	w4, v27[2]
    1934:      	ldrb	w11, [x14]
    1938:      	and	w11, w4, w11
    193c:      	str	q16, [sp, #0x840]
    1940:      	str	q3, [sp, #0x830]
    1944:      	add	x14, sp, #0x830
    1948:      	ldr	s17, [x14, x10, lsl #2]
    194c:      	tst	w11, #0x1
    1950:      	fcsel	s17, s17, s26, ne
    1954:      	and	x10, x12, #0x7
    1958:      	add	x11, sp, #0x5e8
    195c:      	bfxil	x11, x12, #0, #3
    1960:      	ldrb	w11, [x11]
    1964:      	umov.b	w5, v27[3]
    1968:      	str	q16, [sp, #0x820]
    196c:      	str	q3, [sp, #0x810]
    1970:      	add	x12, sp, #0x810
    1974:      	ldr	s19, [x12, x10, lsl #2]
    1978:      	and	w10, w5, w11
    197c:      	tst	w10, #0x1
    1980:      	mov.s	w10, v18[1]
    1984:      	mov.s	w11, v18[2]
    1988:      	fcsel	s19, s19, s26, ne
    198c:      	mov.s	w12, v18[3]
    1990:      	fmov	w14, s18
    1994:      	and	x15, x14, #0x7
    1998:      	add	x16, sp, #0x5e8
    199c:      	bfxil	x16, x14, #0, #3
    19a0:      	ldrb	w14, [x16]
    19a4:      	umov.b	w17, v27[4]
    19a8:      	and	w14, w17, w14
    19ac:      	str	q16, [sp, #0x900]
    19b0:      	str	q3, [sp, #0x8f0]
    19b4:      	add	x16, sp, #0x8f0
    19b8:      	ldr	s18, [x16, x15, lsl #2]
    19bc:      	tst	w14, #0x1
    19c0:      	fcsel	s18, s18, s26, ne
    19c4:      	and	x14, x10, #0x7
    19c8:      	add	x15, sp, #0x5e8
    19cc:      	bfxil	x15, x10, #0, #3
    19d0:      	ldrb	w10, [x15]
    19d4:      	umov.b	w23, v27[5]
    19d8:      	and	w10, w23, w10
    19dc:      	str	q16, [sp, #0x8e0]
    19e0:      	str	q3, [sp, #0x8d0]
    19e4:      	add	x15, sp, #0x8d0
    19e8:      	ldr	s21, [x15, x14, lsl #2]
    19ec:      	tst	w10, #0x1
    19f0:      	fcsel	s21, s21, s26, ne
    19f4:      	and	x10, x11, #0x7
    19f8:      	add	x14, sp, #0x5e8
    19fc:      	bfxil	x14, x11, #0, #3
    1a00:      	ldrb	w11, [x14]
    1a04:      	umov.b	w22, v27[6]
    1a08:      	and	w11, w22, w11
    1a0c:      	str	q16, [sp, #0x8c0]
    1a10:      	str	q3, [sp, #0x8b0]
    1a14:      	add	x14, sp, #0x8b0
    1a18:      	ldr	s22, [x14, x10, lsl #2]
    1a1c:      	tst	w11, #0x1
    1a20:      	fcsel	s22, s22, s26, ne
    1a24:      	and	x10, x12, #0x7
    1a28:      	add	x11, sp, #0x5e8
    1a2c:      	bfxil	x11, x12, #0, #3
    1a30:      	umov.b	w27, v27[7]
    1a34:      	ldrb	w11, [x11]
    1a38:      	and	w11, w27, w11
    1a3c:      	str	q16, [sp, #0x8a0]
    1a40:      	str	q3, [sp, #0x890]
    1a44:      	add	x12, sp, #0x890
    1a48:      	ldr	s24, [x12, x10, lsl #2]
    1a4c:      	tst	w11, #0x1
    1a50:      	fcsel	s24, s24, s26, ne
    1a54:      	mov.s	v18[1], v21[0]
    1a58:      	mov.s	v18[2], v22[0]
    1a5c:      	mov.s	v18[3], v24[0]
    1a60:      	mov.s	v4[1], v7[0]
    1a64:      	mov.s	v4[2], v17[0]
    1a68:      	mov.s	v4[3], v19[0]
    1a6c:      	fmaxnm.4s	v3, v3, v4
    1a70:      	fmaxnm.4s	v4, v16, v18
    1a74:      	movi.4s	v16, #0x2
    1a78:      	eor.16b	v7, v23, v16
    1a7c:      	mov.s	w10, v7[1]
    1a80:      	mov.s	w11, v7[2]
    1a84:      	mov.s	w12, v7[3]
    1a88:      	eor.16b	v17, v2, v16
    1a8c:      	fmov	w15, s7
    1a90:      	add	x16, sp, #0x5e8
    1a94:      	bfxil	x16, x15, #0, #3
    1a98:      	ldrb	w16, [x16]
    1a9c:      	and	x15, x15, #0x7
    1aa0:      	str	q4, [sp, #0x800]
    1aa4:      	str	q3, [sp, #0x7f0]
    1aa8:      	add	x14, sp, #0x7f0
    1aac:      	ldr	s2, [x14, x15, lsl #2]
    1ab0:      	tst	w8, w16
    1ab4:      	fcsel	s2, s2, s26, ne
    1ab8:      	and	x15, x10, #0x7
    1abc:      	add	x16, sp, #0x5e8
    1ac0:      	bfxil	x16, x10, #0, #3
    1ac4:      	ldrb	w10, [x16]
    1ac8:      	and	w10, w28, w10
    1acc:      	str	q4, [sp, #0x7e0]
    1ad0:      	str	q3, [sp, #0x7d0]
    1ad4:      	add	x14, sp, #0x7d0
    1ad8:      	ldr	s7, [x14, x15, lsl #2]
    1adc:      	tst	w10, #0x1
    1ae0:      	fcsel	s7, s7, s26, ne
    1ae4:      	and	x10, x11, #0x7
    1ae8:      	add	x15, sp, #0x5e8
    1aec:      	bfxil	x15, x11, #0, #3
    1af0:      	ldrb	w11, [x15]
    1af4:      	and	w11, w4, w11
    1af8:      	str	q4, [sp, #0x7c0]
    1afc:      	str	q3, [sp, #0x7b0]
    1b00:      	add	x14, sp, #0x7b0
    1b04:      	ldr	s16, [x14, x10, lsl #2]
    1b08:      	tst	w11, #0x1
    1b0c:      	fcsel	s16, s16, s26, ne
    1b10:      	and	x10, x12, #0x7
    1b14:      	add	x11, sp, #0x5e8
    1b18:      	bfxil	x11, x12, #0, #3
    1b1c:      	ldrb	w11, [x11]
    1b20:      	str	q4, [sp, #0x7a0]
    1b24:      	str	q3, [sp, #0x790]
    1b28:      	add	x12, sp, #0x790
    1b2c:      	ldr	s18, [x12, x10, lsl #2]
    1b30:      	and	w10, w5, w11
    1b34:      	tst	w10, #0x1
    1b38:      	mov.s	w15, v17[3]
    1b3c:      	mov.s	w25, v17[1]
    1b40:      	fmov	w10, s17
    1b44:      	and	x14, x10, #0x7
    1b48:      	add	x19, sp, #0x5e8
    1b4c:      	bfxil	x19, x10, #0, #3
    1b50:      	add	x10, sp, #0x5e8
    1b54:      	bfxil	x10, x15, #0, #3
    1b58:      	ldrb	w21, [x10]
    1b5c:      	movi.4s	v19, #0x4
    1b60:      	eor.16b	v19, v23, v19
    1b64:      	mov.s	w0, v19[1]
    1b68:      	mov.s	w12, v19[2]
    1b6c:      	mov.s	w11, v19[3]
    1b70:      	fmov	w30, s19
    1b74:      	add	x10, sp, #0x5e8
    1b78:      	bfxil	x10, x30, #0, #3
    1b7c:      	ldrb	w6, [x10]
    1b80:      	add	x10, sp, #0x5e8
    1b84:      	bfxil	x10, x0, #0, #3
    1b88:      	ldrb	w7, [x10]
    1b8c:      	add	x10, sp, #0x5e8
    1b90:      	bfxil	x10, x12, #0, #3
    1b94:      	ldrb	w10, [x10]
    1b98:      	add	x16, sp, #0x5e8
    1b9c:      	bfxil	x16, x11, #0, #3
    1ba0:      	ldrb	w16, [x16]
    1ba4:      	ldrb	w19, [x19]
    1ba8:      	str	q4, [sp, #0x780]
    1bac:      	str	q3, [sp, #0x770]
    1bb0:      	add	x3, sp, #0x770
    1bb4:      	ldr	s19, [x3, x14, lsl #2]
    1bb8:      	add	x14, sp, #0x5e8
    1bbc:      	bfxil	x14, x25, #0, #3
    1bc0:      	and	x25, x25, #0x7
    1bc4:      	ldrb	w14, [x14]
    1bc8:      	str	q4, [sp, #0x760]
    1bcc:      	str	q3, [sp, #0x750]
    1bd0:      	add	x3, sp, #0x750
    1bd4:      	ldr	s21, [x3, x25, lsl #2]
    1bd8:      	fcsel	s18, s18, s26, ne
    1bdc:      	and	w19, w17, w19
    1be0:      	tst	w19, #0x1
    1be4:      	mov.s	w19, v17[2]
    1be8:      	fcsel	s17, s19, s26, ne
    1bec:      	and	w14, w23, w14
    1bf0:      	tst	w14, #0x1
    1bf4:      	add	x14, sp, #0x5e8
    1bf8:      	bfxil	x14, x19, #0, #3
    1bfc:      	and	x19, x19, #0x7
    1c00:      	ldrb	w14, [x14]
    1c04:      	str	q4, [sp, #0x740]
    1c08:      	str	q3, [sp, #0x730]
    1c0c:      	add	x3, sp, #0x730
    1c10:      	ldr	s19, [x3, x19, lsl #2]
    1c14:      	fcsel	s21, s21, s26, ne
    1c18:      	and	w14, w22, w14
    1c1c:      	tst	w14, #0x1
    1c20:      	and	x14, x15, #0x7
    1c24:      	str	q4, [sp, #0x720]
    1c28:      	str	q3, [sp, #0x710]
    1c2c:      	add	x15, sp, #0x710
    1c30:      	ldr	s22, [x15, x14, lsl #2]
    1c34:      	fcsel	s19, s19, s26, ne
    1c38:      	and	w14, w27, w21
    1c3c:      	tst	w14, #0x1
    1c40:      	fcsel	s22, s22, s26, ne
    1c44:      	mov.s	v17[1], v21[0]
    1c48:      	mov.s	v17[2], v19[0]
    1c4c:      	mov.s	v17[3], v22[0]
    1c50:      	mov.s	v2[1], v7[0]
    1c54:      	mov.s	v2[2], v16[0]
    1c58:      	mov.s	v2[3], v18[0]
    1c5c:      	fmaxnm.4s	v2, v3, v2
    1c60:      	fmaxnm.4s	v3, v4, v17
    1c64:      	and	x14, x30, #0x7
    1c68:      	str	q3, [sp, #0x700]
    1c6c:      	str	q2, [sp, #0x6f0]
    1c70:      	add	x15, sp, #0x6f0
    1c74:      	ldr	s4, [x15, x14, lsl #2]
    1c78:      	tst	w8, w6
    1c7c:      	fcsel	s4, s4, s26, ne
    1c80:      	and	x8, x0, #0x7
    1c84:      	and	w14, w28, w7
    1c88:      	str	q3, [sp, #0x6e0]
    1c8c:      	str	q2, [sp, #0x6d0]
    1c90:      	add	x15, sp, #0x6d0
    1c94:      	ldr	s7, [x15, x8, lsl #2]
    1c98:      	tst	w14, #0x1
    1c9c:      	fcsel	s7, s7, s26, ne
    1ca0:      	and	x8, x12, #0x7
    1ca4:      	str	q3, [sp, #0x6c0]
    1ca8:      	str	q2, [sp, #0x6b0]
    1cac:      	add	x12, sp, #0x6b0
    1cb0:      	ldr	s16, [x12, x8, lsl #2]
    1cb4:      	and	w8, w4, w10
    1cb8:      	tst	w8, #0x1
    1cbc:      	fcsel	s16, s16, s26, ne
    1cc0:      	and	x8, x11, #0x7
    1cc4:      	and	w10, w5, w16
    1cc8:      	str	q3, [sp, #0x6a0]
    1ccc:      	str	q2, [sp, #0x690]
    1cd0:      	add	x11, sp, #0x690
    1cd4:      	ldr	s3, [x11, x8, lsl #2]
    1cd8:      	tst	w10, #0x1
    1cdc:      	fcsel	s3, s3, s26, ne
    1ce0:      	ands	w15, w26, #0x1
    1ce4:      	mov.s	v4[1], v7[0]
    1ce8:      	mov.s	v4[2], v16[0]
    1cec:      	mov.s	v4[3], v3[0]
    1cf0:      	fmaxnm.4s	v2, v2, v4
    1cf4:      	fcsel	s3, s2, s26, ne
    1cf8:      	str	w28, [sp, #0x140]
    1cfc:      	and	w8, w28, w26
    1d00:      	str	w8, [sp, #0xc8]
    1d04:      	tst	w8, #0x1
    1d08:      	fcsel	s4, s2, s26, ne
    1d0c:      	str	w4, [sp, #0x150]
    1d10:      	and	w8, w4, w26
    1d14:      	mov	x4, x5
    1d18:      	str	w8, [sp, #0xc4]
    1d1c:      	tst	w8, #0x1
    1d20:      	fcsel	s7, s2, s26, ne
    1d24:      	and	w8, w5, w26
    1d28:      	str	w8, [sp, #0xc0]
    1d2c:      	tst	w8, #0x1
    1d30:      	fcsel	s16, s2, s26, ne
    1d34:      	str	w17, [sp, #0x130]
    1d38:      	and	w8, w17, w26
    1d3c:      	tst	w8, #0x1
    1d40:      	fcsel	s17, s2, s26, ne
    1d44:      	str	w23, [sp, #0x100]
    1d48:      	and	w11, w23, w26
    1d4c:      	tst	w11, #0x1
    1d50:      	fcsel	s18, s2, s26, ne
    1d54:      	str	w22, [sp, #0xf0]
    1d58:      	and	w12, w22, w26
    1d5c:      	tst	w12, #0x1
    1d60:      	fcsel	s19, s2, s26, ne
    1d64:      	str	w26, [sp, #0x120]
    1d68:      	str	w27, [sp, #0xd0]
    1d6c:      	and	w16, w27, w26
    1d70:      	tst	w16, #0x1
    1d74:      	mov.s	v3[1], v4[0]
    1d78:      	mov.s	v3[2], v7[0]
    1d7c:      	mov.s	v3[3], v16[0]
    1d80:      	mov.s	v17[1], v18[0]
    1d84:      	fcsel	s2, s2, s26, ne
    1d88:      	mov.s	v17[2], v19[0]
    1d8c:      	mov.s	v17[3], v2[0]
    1d90:      	ldr	w10, [sp, #0x160]
    1d94:      	rbit	w10, w10
    1d98:      	clz	w0, w10
    1d9c:      	str	q17, [sp, #0x600]
    1da0:      	str	q3, [sp, #0x5f0]
    1da4:      	and	x10, x0, #0x7
    1da8:      	add	x14, sp, #0x5f0
    1dac:      	ldr	s2, [x14, x10, lsl #2]
    1db0:      	str	q27, [sp, #0x160]
    1db4:      	mov.b	v27[0], wzr
    1db8:      	str	q27, [sp, #0xb0]
    1dbc:      	mov	w10, #-0x800000         ; =-8388608
    1dc0:      	fmov	s3, w10
    1dc4:      	fmaxnm	s2, s2, s3
    1dc8:      	dup.4s	v7, v2[0]
    1dcc:      	movi.2d	v12, #0000000000000000
    1dd0:      	movi.2d	v13, #0000000000000000
    1dd4:      	movi.2d	v14, #0000000000000000
    1dd8:      	movi.2d	v8, #0000000000000000
    1ddc:      	ldr	w19, [sp, #0x2c]
    1de0:      	mov	w3, #-0x3d300000        ; =-1026555904
    1de4:      	mov	w6, #0x42c80000         ; =1120403456
    1de8:      	mov	w7, #0xaa3b             ; =43579
    1dec:      	movk	w7, #0x3fb8, lsl #16
    1df0:      	mov	w21, #0x7200            ; =29184
    1df4:      	movk	w21, #0xbf31, lsl #16
    1df8:      	mov	w25, #0xbe8e            ; =48782
    1dfc:      	movk	w25, #0xb5bf, lsl #16
    1e00:      	mov	w30, #0x2bda            ; =11226
    1e04:      	movk	w30, #0x3950, lsl #16
    1e08:      	ldr	x28, [sp, #0x8]
    1e0c:      	ldr	w26, [sp, #0x11c]
    1e10:      	ldr	w27, [sp, #0xcc]
    1e14:      	b	0x203c <_llm_rows.packet_batch.blocks+0x1698>
    1e18:      	lsl	x1, x1, #5
    1e1c:      	add	x10, x13, x1
    1e20:      	ldp	q3, q2, [x10]
    1e24:      	fsub.4s	v3, v3, v7
    1e28:      	fsub.4s	v2, v2, v7
    1e2c:      	and.16b	v24, v0, v2
    1e30:      	and.16b	v19, v1, v3
    1e34:      	dup.4s	v23, w3
    1e38:      	fcmge.4s	v2, v19, v23
    1e3c:      	fcmge.4s	v3, v24, v23
    1e40:      	dup.4s	v10, w6
    1e44:      	fcmge.4s	v4, v10, v19
    1e48:      	fcmge.4s	v16, v10, v24
    1e4c:      	and.16b	v3, v3, v16
    1e50:      	and.16b	v2, v2, v4
    1e54:      	and.16b	v2, v2, v19
    1e58:      	and.16b	v4, v3, v24
    1e5c:      	dup.4s	v9, w7
    1e60:      	fmul.4s	v3, v4, v9
    1e64:      	fmul.4s	v16, v2, v9
    1e68:      	movi.4s	v21, #0x4b, lsl #24
    1e6c:      	mvni.4s	v22, #0x80, lsl #24
    1e70:      	mov.16b	v17, v22
    1e74:      	bsl.16b	v17, v21, v16
    1e78:      	bif.16b	v21, v3, v22
    1e7c:      	fadd.4s	v3, v3, v21
    1e80:      	fadd.4s	v16, v16, v17
    1e84:      	fsub.4s	v16, v16, v17
    1e88:      	fsub.4s	v3, v3, v21
    1e8c:      	fcvtzs.4s	v26, v3
    1e90:      	fcvtzs.4s	v27, v16
    1e94:      	scvtf.4s	v16, v27
    1e98:      	scvtf.4s	v17, v26
    1e9c:      	dup.4s	v3, w21
    1ea0:      	fmul.4s	v21, v17, v3
    1ea4:      	fmul.4s	v22, v16, v3
    1ea8:      	fadd.4s	v2, v2, v22
    1eac:      	fadd.4s	v4, v4, v21
    1eb0:      	dup.4s	v11, w25
    1eb4:      	fmul.4s	v16, v16, v11
    1eb8:      	fmul.4s	v17, v17, v11
    1ebc:      	fadd.4s	v4, v4, v17
    1ec0:      	fadd.4s	v28, v2, v16
    1ec4:      	dup.4s	v2, w30
    1ec8:      	fmul.4s	v16, v28, v2
    1ecc:      	fmul.4s	v17, v4, v2
    1ed0:      	mov	w10, #0x96c9            ; =38601
    1ed4:      	movk	w10, #0x3ab6, lsl #16
    1ed8:      	dup.4s	v21, w10
    1edc:      	fadd.4s	v17, v17, v21
    1ee0:      	fadd.4s	v16, v16, v21
    1ee4:      	fmul.4s	v16, v28, v16
    1ee8:      	fmul.4s	v17, v4, v17
    1eec:      	mov	w10, #0x88a6            ; =34982
    1ef0:      	movk	w10, #0x3c08, lsl #16
    1ef4:      	dup.4s	v22, w10
    1ef8:      	fadd.4s	v17, v17, v22
    1efc:      	fadd.4s	v16, v16, v22
    1f00:      	fmul.4s	v29, v28, v16
    1f04:      	fmul.4s	v17, v4, v17
    1f08:      	mov	w10, #0xaa7a            ; =43642
    1f0c:      	movk	w10, #0x3d2a, lsl #16
    1f10:      	dup.4s	v16, w10
    1f14:      	fadd.4s	v17, v17, v16
    1f18:      	fadd.4s	v29, v29, v16
    1f1c:      	fmul.4s	v29, v28, v29
    1f20:      	fmul.4s	v15, v4, v17
    1f24:      	mov	w10, #0xaaab            ; =43691
    1f28:      	movk	w10, #0x3e2a, lsl #16
    1f2c:      	dup.4s	v17, w10
    1f30:      	fadd.4s	v15, v15, v17
    1f34:      	fadd.4s	v29, v29, v17
    1f38:      	fmul.4s	v29, v28, v29
    1f3c:      	fmul.4s	v15, v4, v15
    1f40:      	movi.4s	v30, #0x3f, lsl #24
    1f44:      	fadd.4s	v15, v15, v30
    1f48:      	fadd.4s	v29, v29, v30
    1f4c:      	fmul.4s	v30, v4, v4
    1f50:      	fmul.4s	v31, v28, v28
    1f54:      	fmul.4s	v29, v31, v29
    1f58:      	fmul.4s	v30, v30, v15
    1f5c:      	fadd.4s	v30, v4, v30
    1f60:      	fadd.4s	v28, v28, v29
    1f64:      	fmov.4s	v4, #1.00000000
    1f68:      	fadd.4s	v28, v28, v4
    1f6c:      	fadd.4s	v29, v30, v4
    1f70:      	sshr.4s	v30, v27, #0x1
    1f74:      	sshr.4s	v31, v26, #0x1
    1f78:      	shl.4s	v15, v31, #0x17
    1f7c:      	add.4s	v15, v15, v4
    1f80:      	fmul.4s	v29, v29, v15
    1f84:      	shl.4s	v15, v30, #0x17
    1f88:      	add.4s	v15, v15, v4
    1f8c:      	fmul.4s	v28, v28, v15
    1f90:      	sub.4s	v26, v26, v31
    1f94:      	sub.4s	v27, v27, v30
    1f98:      	shl.4s	v27, v27, #0x17
    1f9c:      	add.4s	v27, v27, v4
    1fa0:      	fmul.4s	v27, v28, v27
    1fa4:      	shl.4s	v26, v26, #0x17
    1fa8:      	add.4s	v26, v26, v4
    1fac:      	fmul.4s	v26, v29, v26
    1fb0:      	fcmgt.4s	v28, v23, v24
    1fb4:      	bic.16b	v26, v26, v28
    1fb8:      	fcmgt.4s	v28, v23, v19
    1fbc:      	bic.16b	v27, v27, v28
    1fc0:      	fcmgt.4s	v28, v19, v10
    1fc4:      	ldr	q29, [sp, #0x2d0]
    1fc8:      	bit.16b	v27, v29, v28
    1fcc:      	fcmgt.4s	v28, v24, v10
    1fd0:      	bit.16b	v26, v29, v28
    1fd4:      	fcmeq.4s	v24, v24, v24
    1fd8:      	ldr	q28, [sp, #0x2c0]
    1fdc:      	bsl.16b	v24, v26, v28
    1fe0:      	cmeq.8b	v18, v18, #0
    1fe4:      	sshll.8h	v18, v18, #0x0
    1fe8:      	fcmeq.4s	v19, v19, v19
    1fec:      	bsl.16b	v19, v27, v28
    1ff0:      	sshll.4s	v26, v18, #0x0
    1ff4:      	bic.16b	v19, v19, v26
    1ff8:      	sshll2.4s	v18, v18, #0x0
    1ffc:      	bic.16b	v18, v24, v18
    2000:      	add	x10, x9, x1
    2004:      	ldp	q24, q26, [x10]
    2008:      	bif.16b	v18, v26, v0
    200c:      	bif.16b	v19, v24, v1
    2010:      	stp	q19, q18, [x10]
    2014:      	ldp	q18, q19, [sp, #0x310]
    2018:      	add.2d	v13, v13, v19
    201c:      	add.2d	v14, v14, v18
    2020:      	ldr	q18, [sp, #0x330]
    2024:      	add.2d	v8, v8, v18
    2028:      	ldr	q18, [sp, #0x300]
    202c:      	add.2d	v12, v12, v18
    2030:      	fmov	x1, d12
    2034:      	cmp	x1, #0x200
    2038:      	b.ge	0x2130 <_llm_rows.packet_batch.blocks+0x178c>
    203c:      	ldr	q2, [sp, #0x2f0]
    2040:      	fmov	w10, s2
    2044:      	ldr	q2, [sp, #0x340]
    2048:      	add.2d	v2, v12, v2
    204c:      	ldr	q3, [sp, #0x280]
    2050:      	add.2d	v2, v3, v2
    2054:      	ldr	q19, [sp, #0x260]
    2058:      	tbz	w10, #0x0, 0x207c <_llm_rows.packet_batch.blocks+0x16d8>
    205c:      	fmov	x14, d2
    2060:      	ldr	b18, [x14]
    2064:      	ldp	q4, q3, [sp, #0x2a0]
    2068:      	ldr	q16, [sp, #0x290]
    206c:      	ldr	q17, [sp, #0x270]
    2070:      	and	w10, w10, #0xff
    2074:      	tbnz	w10, #0x1, 0x2094 <_llm_rows.packet_batch.blocks+0x16f0>
    2078:      	b	0x209c <_llm_rows.packet_batch.blocks+0x16f8>
    207c:      	movi.2d	v18, #0000000000000000
    2080:      	ldp	q4, q3, [sp, #0x2a0]
    2084:      	ldr	q16, [sp, #0x290]
    2088:      	ldr	q17, [sp, #0x270]
    208c:      	and	w10, w10, #0xff
    2090:      	tbz	w10, #0x1, 0x209c <_llm_rows.packet_batch.blocks+0x16f8>
    2094:      	mov.d	x14, v2[1]
    2098:      	ld1.b	{ v18 }[1], [x14]
    209c:      	add.2d	v2, v13, v19
    20a0:      	add.2d	v2, v4, v2
    20a4:      	tbnz	w10, #0x2, 0x20d4 <_llm_rows.packet_batch.blocks+0x1730>
    20a8:      	tbnz	w10, #0x3, 0x20e0 <_llm_rows.packet_batch.blocks+0x173c>
    20ac:      	ldr	q2, [sp, #0x250]
    20b0:      	add.2d	v2, v14, v2
    20b4:      	add.2d	v2, v16, v2
    20b8:      	tbnz	w10, #0x4, 0x20f8 <_llm_rows.packet_batch.blocks+0x1754>
    20bc:      	tbnz	w10, #0x5, 0x2104 <_llm_rows.packet_batch.blocks+0x1760>
    20c0:      	add.2d	v2, v8, v17
    20c4:      	add.2d	v2, v3, v2
    20c8:      	tbnz	w10, #0x6, 0x2118 <_llm_rows.packet_batch.blocks+0x1774>
    20cc:      	tbz	w10, #0x7, 0x1e18 <_llm_rows.packet_batch.blocks+0x1474>
    20d0:      	b	0x2124 <_llm_rows.packet_batch.blocks+0x1780>
    20d4:      	fmov	x14, d2
    20d8:      	ld1.b	{ v18 }[2], [x14]
    20dc:      	tbz	w10, #0x3, 0x20ac <_llm_rows.packet_batch.blocks+0x1708>
    20e0:      	mov.d	x14, v2[1]
    20e4:      	ld1.b	{ v18 }[3], [x14]
    20e8:      	ldr	q2, [sp, #0x250]
    20ec:      	add.2d	v2, v14, v2
    20f0:      	add.2d	v2, v16, v2
    20f4:      	tbz	w10, #0x4, 0x20bc <_llm_rows.packet_batch.blocks+0x1718>
    20f8:      	fmov	x14, d2
    20fc:      	ld1.b	{ v18 }[4], [x14]
    2100:      	tbz	w10, #0x5, 0x20c0 <_llm_rows.packet_batch.blocks+0x171c>
    2104:      	mov.d	x14, v2[1]
    2108:      	ld1.b	{ v18 }[5], [x14]
    210c:      	add.2d	v2, v8, v17
    2110:      	add.2d	v2, v3, v2
    2114:      	tbz	w10, #0x6, 0x20cc <_llm_rows.packet_batch.blocks+0x1728>
    2118:      	fmov	x14, d2
    211c:      	ld1.b	{ v18 }[6], [x14]
    2120:      	tbz	w10, #0x7, 0x1e18 <_llm_rows.packet_batch.blocks+0x1474>
    2124:      	mov.d	x10, v2[1]
    2128:      	ld1.b	{ v18 }[7], [x10]
    212c:      	b	0x1e18 <_llm_rows.packet_batch.blocks+0x1474>
    2130:      	ldr	d18, [sp, #0x228]
    2134:      	fmov	w10, s18
    2138:      	ldr	q15, [sp, #0x2e0]
    213c:      	tbz	w10, #0x0, 0x217c <_llm_rows.packet_batch.blocks+0x17d8>
    2140:      	ldr	q18, [sp, #0x30]
    2144:      	fmov	x14, d18
    2148:      	ldr	b18, [x14]
    214c:      	b	0x2180 <_llm_rows.packet_batch.blocks+0x17dc>
    2150:      	fmov	x10, d23
    2154:      	ld1.b	{ v2 }[2], [x10]
    2158:      	tbz	w8, #0x3, 0x1600 <_llm_rows.packet_batch.blocks+0xc5c>
    215c:      	ld1.b	{ v2 }[3], [x15]
    2160:      	tbz	w8, #0x4, 0x1604 <_llm_rows.packet_batch.blocks+0xc60>
    2164:      	fmov	x10, d22
    2168:      	ld1.b	{ v2 }[4], [x10]
    216c:      	tbz	w8, #0x5, 0x1608 <_llm_rows.packet_batch.blocks+0xc64>
    2170:      	ld1.b	{ v2 }[5], [x14]
    2174:      	tbnz	w8, #0x6, 0x160c <_llm_rows.packet_batch.blocks+0xc68>
    2178:      	b	0x1614 <_llm_rows.packet_batch.blocks+0xc70>
    217c:      	movi.2d	v18, #0000000000000000
    2180:      	mov	w7, #0xf2ca             ; =62154
    2184:      	movk	w7, #0xf149, lsl #16
    2188:      	ldr	q13, [sp, #0x230]
    218c:      	ldr	x3, [sp, #0x1e0]
    2190:      	ldr	x6, [sp, #0x1c8]
    2194:      	ldr	q14, [sp, #0x300]
    2198:      	mov	w23, #0x4               ; =4
    219c:      	tbnz	w10, #0x1, 0x2a64 <_llm_rows.packet_batch.blocks+0x20c0>
    21a0:      	tbnz	w10, #0x2, 0x2a70 <_llm_rows.packet_batch.blocks+0x20cc>
    21a4:      	tbnz	w10, #0x3, 0x2a80 <_llm_rows.packet_batch.blocks+0x20dc>
    21a8:      	tbnz	w10, #0x4, 0x2a8c <_llm_rows.packet_batch.blocks+0x20e8>
    21ac:      	tbnz	w10, #0x5, 0x2a9c <_llm_rows.packet_batch.blocks+0x20f8>
    21b0:      	tbnz	w10, #0x6, 0x2aa8 <_llm_rows.packet_batch.blocks+0x2104>
    21b4:      	tbz	w10, #0x7, 0x21c0 <_llm_rows.packet_batch.blocks+0x181c>
    21b8:      	ldr	x10, [sp, #0xa8]
    21bc:      	ld1.b	{ v18 }[7], [x10]
    21c0:      	cmeq.8b	v18, v18, #0
    21c4:      	sshll.8h	v19, v18, #0x0
    21c8:      	sshll2.4s	v18, v19, #0x0
    21cc:      	sshll.4s	v19, v19, #0x0
    21d0:      	add	x10, x13, x6
    21d4:      	ldp	q26, q24, [x10]
    21d8:      	fsub.4s	v26, v26, v7
    21dc:      	fsub.4s	v24, v24, v7
    21e0:      	zip2.8b	v7, v13, v0
    21e4:      	ushll.4s	v7, v7, #0x0
    21e8:      	shl.4s	v7, v7, #0x1f
    21ec:      	cmlt.4s	v7, v7, #0
    21f0:      	and.16b	v27, v7, v24
    21f4:      	zip1.8b	v24, v13, v0
    21f8:      	ushll.4s	v24, v24, #0x0
    21fc:      	shl.4s	v24, v24, #0x1f
    2200:      	cmlt.4s	v24, v24, #0
    2204:      	and.16b	v26, v24, v26
    2208:      	fcmge.4s	v28, v26, v23
    220c:      	fcmge.4s	v29, v27, v23
    2210:      	fcmge.4s	v30, v10, v26
    2214:      	fcmge.4s	v31, v10, v27
    2218:      	and.16b	v29, v29, v31
    221c:      	and.16b	v28, v28, v30
    2220:      	and.16b	v28, v28, v26
    2224:      	and.16b	v29, v29, v27
    2228:      	fmul.4s	v30, v29, v9
    222c:      	fmul.4s	v31, v28, v9
    2230:      	movi.4s	v9, #0x4b, lsl #24
    2234:      	mvni.4s	v12, #0x80, lsl #24
    2238:      	mov.16b	v8, v12
    223c:      	bsl.16b	v8, v9, v31
    2240:      	bif.16b	v9, v30, v12
    2244:      	fadd.4s	v30, v30, v9
    2248:      	fadd.4s	v31, v31, v8
    224c:      	fsub.4s	v31, v31, v8
    2250:      	fsub.4s	v30, v30, v9
    2254:      	fcvtzs.4s	v30, v30
    2258:      	fcvtzs.4s	v31, v31
    225c:      	scvtf.4s	v8, v31
    2260:      	scvtf.4s	v9, v30
    2264:      	fmul.4s	v12, v9, v3
    2268:      	fmul.4s	v3, v8, v3
    226c:      	fadd.4s	v3, v28, v3
    2270:      	fadd.4s	v28, v29, v12
    2274:      	fmul.4s	v29, v8, v11
    2278:      	fmul.4s	v8, v9, v11
    227c:      	fadd.4s	v28, v28, v8
    2280:      	fadd.4s	v3, v3, v29
    2284:      	fmul.4s	v29, v3, v2
    2288:      	fmul.4s	v2, v28, v2
    228c:      	fadd.4s	v2, v2, v21
    2290:      	fadd.4s	v21, v29, v21
    2294:      	fmul.4s	v21, v3, v21
    2298:      	fmul.4s	v2, v28, v2
    229c:      	fadd.4s	v2, v2, v22
    22a0:      	fadd.4s	v21, v21, v22
    22a4:      	fmul.4s	v21, v3, v21
    22a8:      	fmul.4s	v2, v28, v2
    22ac:      	fadd.4s	v2, v2, v16
    22b0:      	fadd.4s	v16, v21, v16
    22b4:      	fmul.4s	v16, v3, v16
    22b8:      	fmul.4s	v2, v28, v2
    22bc:      	fadd.4s	v2, v2, v17
    22c0:      	fadd.4s	v16, v16, v17
    22c4:      	fmul.4s	v16, v3, v16
    22c8:      	fmul.4s	v2, v28, v2
    22cc:      	movi.4s	v17, #0x3f, lsl #24
    22d0:      	fadd.4s	v2, v2, v17
    22d4:      	fadd.4s	v16, v16, v17
    22d8:      	fmul.4s	v17, v28, v28
    22dc:      	fmul.4s	v21, v3, v3
    22e0:      	fmul.4s	v16, v21, v16
    22e4:      	fmul.4s	v2, v17, v2
    22e8:      	fadd.4s	v2, v28, v2
    22ec:      	fadd.4s	v3, v3, v16
    22f0:      	fadd.4s	v3, v3, v4
    22f4:      	fadd.4s	v2, v2, v4
    22f8:      	sshr.4s	v16, v31, #0x1
    22fc:      	sshr.4s	v17, v30, #0x1
    2300:      	shl.4s	v21, v17, #0x17
    2304:      	shl.4s	v22, v16, #0x17
    2308:      	add.4s	v22, v22, v4
    230c:      	add.4s	v21, v21, v4
    2310:      	fmul.4s	v2, v2, v21
    2314:      	fmul.4s	v3, v3, v22
    2318:      	sub.4s	v17, v30, v17
    231c:      	sub.4s	v16, v31, v16
    2320:      	shl.4s	v16, v16, #0x17
    2324:      	shl.4s	v17, v17, #0x17
    2328:      	add.4s	v17, v17, v4
    232c:      	add.4s	v4, v16, v4
    2330:      	fmul.4s	v3, v3, v4
    2334:      	fmul.4s	v2, v2, v17
    2338:      	fcmgt.4s	v4, v23, v27
    233c:      	bic.16b	v2, v2, v4
    2340:      	fcmgt.4s	v4, v23, v26
    2344:      	bic.16b	v3, v3, v4
    2348:      	fcmgt.4s	v4, v27, v10
    234c:      	fcmgt.4s	v16, v26, v10
    2350:      	ldp	q17, q21, [sp, #0x2c0]
    2354:      	bit.16b	v3, v21, v16
    2358:      	bit.16b	v2, v21, v4
    235c:      	fcmeq.4s	v4, v26, v26
    2360:      	fcmeq.4s	v16, v27, v27
    2364:      	bif.16b	v2, v17, v16
    2368:      	bif.16b	v3, v17, v4
    236c:      	bic.16b	v21, v3, v19
    2370:      	bic.16b	v22, v2, v18
    2374:      	add	x10, x9, x6
    2378:      	ldp	q2, q3, [x10]
    237c:      	bit.16b	v3, v22, v7
    2380:      	bit.16b	v2, v21, v24
    2384:      	stp	q2, q3, [x10]
    2388:      	ldr	x10, [sp, #0x178]
    238c:      	ldp	q2, q3, [x10, #0x40]
    2390:      	and.16b	v3, v0, v3
    2394:      	and.16b	v4, v1, v2
    2398:      	ldp	q2, q7, [x10, #0x20]
    239c:      	and.16b	v16, v0, v7
    23a0:      	and.16b	v7, v1, v2
    23a4:      	ldp	q2, q17, [x10]
    23a8:      	and.16b	v17, v0, v17
    23ac:      	and.16b	v18, v1, v2
    23b0:      	ldr	x10, [sp, #0xe0]
    23b4:      	add	x10, x9, x10
    23b8:      	ldp	q2, q19, [x10]
    23bc:      	and.16b	v23, v0, v19
    23c0:      	and.16b	v19, v1, v2
    23c4:      	ldr	q12, [sp, #0x210]
    23c8:      	sshll.2d	v2, v1, #0x0
    23cc:      	sshll.2d	v27, v0, #0x0
    23d0:      	add	x10, x9, x2, lsl #5
    23d4:      	ldp	q24, q26, [x10]
    23d8:      	fadd.4s	v24, v19, v24
    23dc:      	fadd.4s	v26, v23, v26
    23e0:      	ldp	q29, q28, [x10, #0x20]
    23e4:      	fadd.4s	v29, v18, v29
    23e8:      	fadd.4s	v28, v17, v28
    23ec:      	ldp	q31, q30, [x10, #0x40]
    23f0:      	fadd.4s	v31, v7, v31
    23f4:      	fadd.4s	v30, v16, v30
    23f8:      	ldp	q9, q8, [x10, #0x60]
    23fc:      	fadd.4s	v9, v4, v9
    2400:      	fadd.4s	v8, v3, v8
    2404:      	dup.2d	v10, x23
    2408:      	and.16b	v11, v12, v10
    240c:      	add.2d	v25, v25, v11
    2410:      	and.16b	v11, v15, v10
    2414:      	add.2d	v20, v20, v11
    2418:      	and.16b	v27, v27, v10
    241c:      	add.2d	v5, v5, v27
    2420:      	and.16b	v2, v2, v10
    2424:      	add.2d	v6, v6, v2
    2428:      	bit.16b	v23, v26, v0
    242c:      	bit.16b	v19, v24, v1
    2430:      	bit.16b	v17, v28, v0
    2434:      	bit.16b	v18, v29, v1
    2438:      	bit.16b	v16, v30, v0
    243c:      	bit.16b	v7, v31, v1
    2440:      	bit.16b	v3, v8, v0
    2444:      	bit.16b	v4, v9, v1
    2448:      	fmov	x2, d6
    244c:      	cmp	x2, #0x200
    2450:      	b.lt	0x23c8 <_llm_rows.packet_batch.blocks+0x1a24>
    2454:      	mov	x13, #0x0               ; =0
    2458:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x165c>
    245c:      	ldr	q2, [x10]
    2460:      	and.16b	v5, v0, v2
    2464:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x165c>
    2468:      	ldr	q2, [x10]
    246c:      	and.16b	v20, v1, v2
    2470:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x165c>
    2474:      	ldr	q2, [x10]
    2478:      	and.16b	v2, v1, v2
    247c:      	fadd.4s	v6, v22, v23
    2480:      	fadd.4s	v19, v21, v19
    2484:      	zip1.8b	v21, v13, v0
    2488:      	ushll.4s	v21, v21, #0x0
    248c:      	shl.4s	v21, v21, #0x1f
    2490:      	cmlt.4s	v21, v21, #0
    2494:      	and.16b	v19, v21, v19
    2498:      	zip2.8b	v21, v13, v0
    249c:      	ushll.4s	v21, v21, #0x0
    24a0:      	shl.4s	v21, v21, #0x1f
    24a4:      	cmlt.4s	v21, v21, #0
    24a8:      	and.16b	v6, v21, v6
    24ac:      	ldr	q22, [sp, #0xb0]
    24b0:      	zip2.8b	v21, v22, v0
    24b4:      	ushll.4s	v21, v21, #0x0
    24b8:      	shl.4s	v21, v21, #0x1f
    24bc:      	cmlt.4s	v21, v21, #0
    24c0:      	bit.16b	v6, v26, v21
    24c4:      	zip1.8b	v21, v22, v0
    24c8:      	ushll.4s	v21, v21, #0x0
    24cc:      	shl.4s	v21, v21, #0x1f
    24d0:      	cmlt.4s	v21, v21, #0
    24d4:      	bit.16b	v19, v24, v21
    24d8:      	fadd.4s	v18, v18, v19
    24dc:      	fadd.4s	v6, v17, v6
    24e0:      	fadd.4s	v6, v16, v6
    24e4:      	fadd.4s	v7, v7, v18
    24e8:      	fadd.4s	v4, v4, v7
    24ec:      	fadd.4s	v6, v3, v6
    24f0:      	fmov	w10, s20
    24f4:      	add	x14, sp, #0x398
    24f8:      	bfxil	x14, x10, #0, #3
    24fc:      	ldr	q3, [sp, #0x160]
    2500:      	str	d3, [sp, #0x398]
    2504:      	ldrb	w14, [x14]
    2508:      	add	x1, sp, #0x5c0
    250c:      	orr	x10, x1, x10, lsl #2
    2510:      	str	q6, [sp, #0x5d0]
    2514:      	str	q4, [sp, #0x5c0]
    2518:      	ldr	s3, [x10]
    251c:      	tst	w15, w14
    2520:      	movi	d21, #0000000000000000
    2524:      	fcsel	s3, s3, s21, ne
    2528:      	mov.s	w10, v20[1]
    252c:      	add	x14, sp, #0x398
    2530:      	bfxil	x14, x10, #0, #3
    2534:      	ldrb	w10, [x14]
    2538:      	ldr	w5, [sp, #0x140]
    253c:      	and	w10, w5, w10
    2540:      	str	q4, [sp, #0x5a0]
    2544:      	ldr	s7, [sp, #0x5a0]
    2548:      	tst	w10, #0x1
    254c:      	fcsel	s7, s7, s21, ne
    2550:      	mov.s	w10, v20[2]
    2554:      	add	x14, sp, #0x398
    2558:      	bfxil	x14, x10, #0, #3
    255c:      	add	x1, sp, #0x580
    2560:      	orr	x10, x1, x10, lsl #2
    2564:      	ldrb	w14, [x14]
    2568:      	ldr	w2, [sp, #0x150]
    256c:      	and	w14, w2, w14
    2570:      	str	q6, [sp, #0x590]
    2574:      	str	q4, [sp, #0x580]
    2578:      	ldr	s16, [x10]
    257c:      	tst	w14, #0x1
    2580:      	fcsel	s16, s16, s21, ne
    2584:      	mov.s	w10, v20[3]
    2588:      	add	x14, sp, #0x398
    258c:      	bfxil	x14, x10, #0, #3
    2590:      	add	x1, sp, #0x560
    2594:      	orr	x10, x1, x10, lsl #2
    2598:      	ldrb	w14, [x14]
    259c:      	and	w14, w4, w14
    25a0:      	str	q6, [sp, #0x570]
    25a4:      	str	q4, [sp, #0x560]
    25a8:      	ldr	s17, [x10]
    25ac:      	tst	w14, #0x1
    25b0:      	fcsel	s17, s17, s21, ne
    25b4:      	fmov	w10, s5
    25b8:      	add	x14, sp, #0x398
    25bc:      	bfxil	x14, x10, #0, #3
    25c0:      	ldrb	w14, [x14]
    25c4:      	ldr	w17, [sp, #0x130]
    25c8:      	and	w14, w17, w14
    25cc:      	str	q6, [sp, #0x550]
    25d0:      	str	q4, [sp, #0x540]
    25d4:      	add	x1, sp, #0x540
    25d8:      	ldr	s18, [x1, w10, uxtw #2]
    25dc:      	tst	w14, #0x1
    25e0:      	fcsel	s18, s18, s21, ne
    25e4:      	mov.s	w10, v5[1]
    25e8:      	add	x14, sp, #0x398
    25ec:      	bfxil	x14, x10, #0, #3
    25f0:      	ldrb	w14, [x14]
    25f4:      	ldr	w21, [sp, #0x100]
    25f8:      	and	w14, w21, w14
    25fc:      	str	q6, [sp, #0x530]
    2600:      	str	q4, [sp, #0x520]
    2604:      	add	x1, sp, #0x520
    2608:      	ldr	s19, [x1, w10, uxtw #2]
    260c:      	tst	w14, #0x1
    2610:      	fcsel	s19, s19, s21, ne
    2614:      	mov.s	w10, v5[2]
    2618:      	add	x14, sp, #0x398
    261c:      	bfxil	x14, x10, #0, #3
    2620:      	ldrb	w14, [x14]
    2624:      	ldr	w22, [sp, #0xf0]
    2628:      	and	w14, w22, w14
    262c:      	str	q6, [sp, #0x510]
    2630:      	str	q4, [sp, #0x500]
    2634:      	add	x1, sp, #0x500
    2638:      	ldr	s20, [x1, w10, uxtw #2]
    263c:      	tst	w14, #0x1
    2640:      	fcsel	s20, s20, s21, ne
    2644:      	mov.s	w10, v5[3]
    2648:      	add	x14, sp, #0x398
    264c:      	bfxil	x14, x10, #0, #3
    2650:      	ldrb	w14, [x14]
    2654:      	ldr	w25, [sp, #0xd0]
    2658:      	and	w14, w25, w14
    265c:      	str	q6, [sp, #0x4f0]
    2660:      	str	q4, [sp, #0x4e0]
    2664:      	add	x1, sp, #0x4e0
    2668:      	ldr	s5, [x1, w10, uxtw #2]
    266c:      	tst	w14, #0x1
    2670:      	fcsel	s5, s5, s21, ne
    2674:      	mov.s	v18[1], v19[0]
    2678:      	mov.s	v18[2], v20[0]
    267c:      	mov.s	v18[3], v5[0]
    2680:      	mov.s	v3[1], v7[0]
    2684:      	mov.s	v3[2], v16[0]
    2688:      	mov.s	v3[3], v17[0]
    268c:      	fadd.4s	v3, v4, v3
    2690:      	fadd.4s	v4, v6, v18
    2694:      	fmov	w10, s2
    2698:      	add	x14, sp, #0x398
    269c:      	bfxil	x14, x10, #0, #3
    26a0:      	ldrb	w14, [x14]
    26a4:      	add	x1, sp, #0x4c0
    26a8:      	orr	x10, x1, x10, lsl #2
    26ac:      	str	q4, [sp, #0x4d0]
    26b0:      	str	q3, [sp, #0x4c0]
    26b4:      	ldr	s5, [x10]
    26b8:      	mov.s	w10, v2[1]
    26bc:      	tst	w15, w14
    26c0:      	add	x14, sp, #0x398
    26c4:      	bfxil	x14, x10, #0, #3
    26c8:      	ldrb	w14, [x14]
    26cc:      	and	w14, w5, w14
    26d0:      	fcsel	s5, s5, s21, ne
    26d4:      	add	x1, sp, #0x4a0
    26d8:      	orr	x10, x1, x10, lsl #2
    26dc:      	str	q4, [sp, #0x4b0]
    26e0:      	str	q3, [sp, #0x4a0]
    26e4:      	ldr	s7, [x10]
    26e8:      	mov.s	w10, v2[2]
    26ec:      	tst	w14, #0x1
    26f0:      	add	x14, sp, #0x398
    26f4:      	bfxil	x14, x10, #0, #3
    26f8:      	adrp	x10, 0x2000 <_llm_rows.packet_batch.blocks+0x165c>
    26fc:      	ldr	q6, [x10]
    2700:      	and.16b	v17, v0, v6
    2704:      	movi.4s	v6, #0x4
    2708:      	and.16b	v6, v1, v6
    270c:      	fcsel	s7, s7, s21, ne
    2710:      	ldrb	w10, [x14]
    2714:      	and	w10, w2, w10
    2718:      	str	q3, [sp, #0x480]
    271c:      	ldr	s16, [sp, #0x480]
    2720:      	tst	w10, #0x1
    2724:      	fcsel	s16, s16, s21, ne
    2728:      	mov.s	w10, v2[3]
    272c:      	add	x14, sp, #0x398
    2730:      	bfxil	x14, x10, #0, #3
    2734:      	add	x1, sp, #0x460
    2738:      	orr	x10, x1, x10, lsl #2
    273c:      	ldrb	w14, [x14]
    2740:      	and	w14, w4, w14
    2744:      	str	q4, [sp, #0x470]
    2748:      	str	q3, [sp, #0x460]
    274c:      	ldr	s2, [x10]
    2750:      	tst	w14, #0x1
    2754:      	fcsel	s2, s2, s21, ne
    2758:      	fmov	w10, s17
    275c:      	add	x14, sp, #0x398
    2760:      	bfxil	x14, x10, #0, #3
    2764:      	ldrb	w14, [x14]
    2768:      	and	w14, w17, w14
    276c:      	str	q4, [sp, #0x450]
    2770:      	str	q3, [sp, #0x440]
    2774:      	add	x1, sp, #0x440
    2778:      	ldr	s18, [x1, w10, uxtw #2]
    277c:      	tst	w14, #0x1
    2780:      	fcsel	s18, s18, s21, ne
    2784:      	mov.s	w10, v17[1]
    2788:      	add	x14, sp, #0x398
    278c:      	bfxil	x14, x10, #0, #3
    2790:      	ldrb	w14, [x14]
    2794:      	and	w14, w21, w14
    2798:      	str	q4, [sp, #0x430]
    279c:      	str	q3, [sp, #0x420]
    27a0:      	add	x1, sp, #0x420
    27a4:      	ldr	s19, [x1, w10, uxtw #2]
    27a8:      	tst	w14, #0x1
    27ac:      	fcsel	s19, s19, s21, ne
    27b0:      	mov.s	w10, v17[2]
    27b4:      	add	x14, sp, #0x398
    27b8:      	bfxil	x14, x10, #0, #3
    27bc:      	ldrb	w14, [x14]
    27c0:      	and	w14, w22, w14
    27c4:      	str	q4, [sp, #0x410]
    27c8:      	str	q3, [sp, #0x400]
    27cc:      	add	x1, sp, #0x400
    27d0:      	ldr	s20, [x1, w10, uxtw #2]
    27d4:      	tst	w14, #0x1
    27d8:      	fcsel	s20, s20, s21, ne
    27dc:      	mov.s	w10, v17[3]
    27e0:      	add	x14, sp, #0x398
    27e4:      	bfxil	x14, x10, #0, #3
    27e8:      	ldrb	w14, [x14]
    27ec:      	and	w14, w25, w14
    27f0:      	stp	q3, q4, [sp, #0x3e0]
    27f4:      	add	x1, sp, #0x3e0
    27f8:      	ldr	s17, [x1, w10, uxtw #2]
    27fc:      	tst	w14, #0x1
    2800:      	fcsel	s17, s17, s21, ne
    2804:      	mov.s	v18[1], v19[0]
    2808:      	mov.s	v18[2], v20[0]
    280c:      	mov.s	v18[3], v17[0]
    2810:      	mov.s	v5[1], v7[0]
    2814:      	mov.s	v5[2], v16[0]
    2818:      	mov.s	v5[3], v2[0]
    281c:      	fadd.4s	v2, v3, v5
    2820:      	fadd.4s	v3, v4, v18
    2824:      	fmov	w10, s6
    2828:      	add	x14, sp, #0x398
    282c:      	orr	x14, x14, x10
    2830:      	ldrb	w14, [x14]
    2834:      	stp	q2, q3, [sp, #0x3c0]
    2838:      	add	x1, sp, #0x3c0
    283c:      	ldr	s3, [x1, w10, uxtw #2]
    2840:      	tst	w15, w14
    2844:      	fcsel	s3, s3, s21, ne
    2848:      	ldr	w10, [sp, #0x120]
    284c:      	tst	w10, #0x1
    2850:      	fadd	s2, s2, s3
    2854:      	fcsel	s3, s2, s21, ne
    2858:      	ldr	w10, [sp, #0xc8]
    285c:      	tst	w10, #0x1
    2860:      	fcsel	s4, s2, s21, ne
    2864:      	ldr	w10, [sp, #0xc4]
    2868:      	tst	w10, #0x1
    286c:      	fcsel	s5, s2, s21, ne
    2870:      	ldr	w10, [sp, #0xc0]
    2874:      	tst	w10, #0x1
    2878:      	fcsel	s6, s2, s21, ne
    287c:      	tst	w8, #0x1
    2880:      	fcsel	s7, s2, s21, ne
    2884:      	tst	w11, #0x1
    2888:      	fcsel	s16, s2, s21, ne
    288c:      	tst	w12, #0x1
    2890:      	fcsel	s17, s2, s21, ne
    2894:      	tst	w16, #0x1
    2898:      	fcsel	s2, s2, s21, ne
    289c:      	mov.s	v3[1], v4[0]
    28a0:      	mov.s	v3[2], v5[0]
    28a4:      	mov.s	v3[3], v6[0]
    28a8:      	mov.s	v7[1], v16[0]
    28ac:      	mov.s	v7[2], v17[0]
    28b0:      	mov.s	v7[3], v2[0]
    28b4:      	stp	q3, q7, [sp, #0x3a0]
    28b8:      	and	x8, x0, #0x7
    28bc:      	add	x10, sp, #0x3a0
    28c0:      	ldr	s2, [x10, x8, lsl #2]
    28c4:      	fadd	s2, s2, s21
    28c8:      	dup.4s	v2, v2[0]
    28cc:      	ldr	q3, [sp, #0x180]
    28d0:      	fmov	x8, d3
    28d4:      	ldr	x14, [sp, #0x1e8]
    28d8:      	add	x8, x14, x8, lsl #2
    28dc:      	movi.2d	v3, #0000000000000000
    28e0:      	movi.2d	v4, #0000000000000000
    28e4:      	movi.2d	v5, #0000000000000000
    28e8:      	movi.2d	v6, #0000000000000000
    28ec:      	movi.8b	v11, #0x1
    28f0:      	ldr	q17, [sp, #0x2f0]
    28f4:      	ldp	q19, q18, [sp, #0x320]
    28f8:      	ldr	q20, [sp, #0x310]
    28fc:      	ldr	w22, [sp, #0xec]
    2900:      	b	0x2920 <_llm_rows.packet_batch.blocks+0x1f7c>
    2904:      	add.2d	v4, v4, v19
    2908:      	add.2d	v5, v5, v20
    290c:      	add.2d	v6, v6, v18
    2910:      	add.2d	v3, v3, v14
    2914:      	fmov	x13, d3
    2918:      	cmp	x13, #0x200
    291c:      	b.ge	0x29d0 <_llm_rows.packet_batch.blocks+0x202c>
    2920:      	fmov	w11, s17
    2924:      	lsl	x10, x13, #5
    2928:      	add	x12, x9, x10
    292c:      	ldp	q16, q7, [x12]
    2930:      	and.16b	v16, v1, v16
    2934:      	fdiv.4s	v16, v16, v2
    2938:      	add	x10, x8, x10
    293c:      	tbnz	w11, #0x0, 0x296c <_llm_rows.packet_batch.blocks+0x1fc8>
    2940:      	and	w11, w11, #0xff
    2944:      	tbnz	w11, #0x1, 0x2978 <_llm_rows.packet_batch.blocks+0x1fd4>
    2948:      	tbnz	w11, #0x2, 0x2984 <_llm_rows.packet_batch.blocks+0x1fe0>
    294c:      	tbnz	w11, #0x3, 0x2990 <_llm_rows.packet_batch.blocks+0x1fec>
    2950:      	and.16b	v7, v0, v7
    2954:      	fdiv.4s	v7, v7, v2
    2958:      	tbnz	w11, #0x4, 0x29a4 <_llm_rows.packet_batch.blocks+0x2000>
    295c:      	tbnz	w11, #0x5, 0x29ac <_llm_rows.packet_batch.blocks+0x2008>
    2960:      	tbnz	w11, #0x6, 0x29b8 <_llm_rows.packet_batch.blocks+0x2014>
    2964:      	tbz	w11, #0x7, 0x2904 <_llm_rows.packet_batch.blocks+0x1f60>
    2968:      	b	0x29c4 <_llm_rows.packet_batch.blocks+0x2020>
    296c:      	str	s16, [x10]
    2970:      	and	w11, w11, #0xff
    2974:      	tbz	w11, #0x1, 0x2948 <_llm_rows.packet_batch.blocks+0x1fa4>
    2978:      	add	x12, x10, #0x4
    297c:      	st1.s	{ v16 }[1], [x12]
    2980:      	tbz	w11, #0x2, 0x294c <_llm_rows.packet_batch.blocks+0x1fa8>
    2984:      	add	x12, x10, #0x8
    2988:      	st1.s	{ v16 }[2], [x12]
    298c:      	tbz	w11, #0x3, 0x2950 <_llm_rows.packet_batch.blocks+0x1fac>
    2990:      	add	x12, x10, #0xc
    2994:      	st1.s	{ v16 }[3], [x12]
    2998:      	and.16b	v7, v0, v7
    299c:      	fdiv.4s	v7, v7, v2
    29a0:      	tbz	w11, #0x4, 0x295c <_llm_rows.packet_batch.blocks+0x1fb8>
    29a4:      	str	s7, [x10, #0x10]
    29a8:      	tbz	w11, #0x5, 0x2960 <_llm_rows.packet_batch.blocks+0x1fbc>
    29ac:      	add	x12, x10, #0x14
    29b0:      	st1.s	{ v7 }[1], [x12]
    29b4:      	tbz	w11, #0x6, 0x2964 <_llm_rows.packet_batch.blocks+0x1fc0>
    29b8:      	add	x12, x10, #0x18
    29bc:      	st1.s	{ v7 }[2], [x12]
    29c0:      	tbz	w11, #0x7, 0x2904 <_llm_rows.packet_batch.blocks+0x1f60>
    29c4:      	add	x10, x10, #0x1c
    29c8:      	st1.s	{ v7 }[3], [x10]
    29cc:      	b	0x2904 <_llm_rows.packet_batch.blocks+0x1f60>
    29d0:      	add	x8, x9, x6
    29d4:      	ldp	q1, q0, [x8]
    29d8:      	zip1.8b	v3, v13, v0
    29dc:      	ushll.4s	v3, v3, #0x0
    29e0:      	shl.4s	v3, v3, #0x1f
    29e4:      	cmlt.4s	v3, v3, #0
    29e8:      	and.16b	v1, v3, v1
    29ec:      	ldr	d3, [sp, #0x228]
    29f0:      	fmov	w8, s3
    29f4:      	fdiv.4s	v1, v1, v2
    29f8:      	ldr	q4, [sp, #0x1d0]
    29fc:      	ldp	q6, q5, [sp, #0x190]
    2a00:      	stp	q4, q5, [sp, #0x350]
    2a04:      	ldr	q3, [sp, #0x1b0]
    2a08:      	stp	q6, q3, [sp, #0x370]
    2a0c:      	and	x9, x3, #0x7
    2a10:      	add	x10, sp, #0x350
    2a14:      	ldr	x9, [x10, x9, lsl #3]
    2a18:      	sub	x9, x9, x3
    2a1c:      	add	x9, x14, x9, lsl #2
    2a20:      	tbnz	w8, #0x0, 0x2abc <_llm_rows.packet_batch.blocks+0x2118>
    2a24:      	tbnz	w8, #0x1, 0x2ac4 <_llm_rows.packet_batch.blocks+0x2120>
    2a28:      	tbnz	w8, #0x2, 0x2ad0 <_llm_rows.packet_batch.blocks+0x212c>
    2a2c:      	tbz	w8, #0x3, 0x2a38 <_llm_rows.packet_batch.blocks+0x2094>
    2a30:      	add	x10, x9, #0xc
    2a34:      	st1.s	{ v1 }[3], [x10]
    2a38:      	zip2.8b	v1, v13, v0
    2a3c:      	ushll.4s	v1, v1, #0x0
    2a40:      	shl.4s	v1, v1, #0x1f
    2a44:      	cmlt.4s	v1, v1, #0
    2a48:      	and.16b	v0, v1, v0
    2a4c:      	fdiv.4s	v0, v0, v2
    2a50:      	tbnz	w8, #0x4, 0x2ae0 <_llm_rows.packet_batch.blocks+0x213c>
    2a54:      	tbnz	w8, #0x5, 0x2ae8 <_llm_rows.packet_batch.blocks+0x2144>
    2a58:      	tbnz	w8, #0x6, 0x2af4 <_llm_rows.packet_batch.blocks+0x2150>
    2a5c:      	tbz	w8, #0x7, 0xa4c <_llm_rows.packet_batch.blocks+0xa8>
    2a60:      	b	0x2b00 <_llm_rows.packet_batch.blocks+0x215c>
    2a64:      	ldr	x14, [sp, #0x48]
    2a68:      	ld1.b	{ v18 }[1], [x14]
    2a6c:      	tbz	w10, #0x2, 0x21a4 <_llm_rows.packet_batch.blocks+0x1800>
    2a70:      	ldr	q19, [sp, #0x50]
    2a74:      	fmov	x14, d19
    2a78:      	ld1.b	{ v18 }[2], [x14]
    2a7c:      	tbz	w10, #0x3, 0x21a8 <_llm_rows.packet_batch.blocks+0x1804>
    2a80:      	ldr	x14, [sp, #0x68]
    2a84:      	ld1.b	{ v18 }[3], [x14]
    2a88:      	tbz	w10, #0x4, 0x21ac <_llm_rows.packet_batch.blocks+0x1808>
    2a8c:      	ldr	q19, [sp, #0x70]
    2a90:      	fmov	x14, d19
    2a94:      	ld1.b	{ v18 }[4], [x14]
    2a98:      	tbz	w10, #0x5, 0x21b0 <_llm_rows.packet_batch.blocks+0x180c>
    2a9c:      	ldr	x14, [sp, #0x88]
    2aa0:      	ld1.b	{ v18 }[5], [x14]
    2aa4:      	tbz	w10, #0x6, 0x21b4 <_llm_rows.packet_batch.blocks+0x1810>
    2aa8:      	ldr	q19, [sp, #0x90]
    2aac:      	fmov	x14, d19
    2ab0:      	ld1.b	{ v18 }[6], [x14]
    2ab4:      	tbnz	w10, #0x7, 0x21b8 <_llm_rows.packet_batch.blocks+0x1814>
    2ab8:      	b	0x21c0 <_llm_rows.packet_batch.blocks+0x181c>
    2abc:      	str	s1, [x9]
    2ac0:      	tbz	w8, #0x1, 0x2a28 <_llm_rows.packet_batch.blocks+0x2084>
    2ac4:      	add	x10, x9, #0x4
    2ac8:      	st1.s	{ v1 }[1], [x10]
    2acc:      	tbz	w8, #0x2, 0x2a2c <_llm_rows.packet_batch.blocks+0x2088>
    2ad0:      	add	x10, x9, #0x8
    2ad4:      	st1.s	{ v1 }[2], [x10]
    2ad8:      	tbnz	w8, #0x3, 0x2a30 <_llm_rows.packet_batch.blocks+0x208c>
    2adc:      	b	0x2a38 <_llm_rows.packet_batch.blocks+0x2094>
    2ae0:      	str	s0, [x9, #0x10]
    2ae4:      	tbz	w8, #0x5, 0x2a58 <_llm_rows.packet_batch.blocks+0x20b4>
    2ae8:      	add	x10, x9, #0x14
    2aec:      	st1.s	{ v0 }[1], [x10]
    2af0:      	tbz	w8, #0x6, 0x2a5c <_llm_rows.packet_batch.blocks+0x20b8>
    2af4:      	add	x10, x9, #0x18
    2af8:      	st1.s	{ v0 }[2], [x10]
    2afc:      	tbz	w8, #0x7, 0xa4c <_llm_rows.packet_batch.blocks+0xa8>
    2b00:      	add	x8, x9, #0x1c
    2b04:      	st1.s	{ v0 }[3], [x8]
    2b08:      	b	0xa4c <_llm_rows.packet_batch.blocks+0xa8>
    2b0c:      	add	sp, sp, #0x9f0
    2b10:      	ldp	x29, x30, [sp, #0x90]
    2b14:      	ldp	x20, x19, [sp, #0x80]
    2b18:      	ldp	x22, x21, [sp, #0x70]
    2b1c:      	ldp	x24, x23, [sp, #0x60]
    2b20:      	ldp	x26, x25, [sp, #0x50]
    2b24:      	ldp	x28, x27, [sp, #0x40]
    2b28:      	ldp	d9, d8, [sp, #0x30]
    2b2c:      	ldp	d11, d10, [sp, #0x20]
    2b30:      	ldp	d13, d12, [sp, #0x10]
    2b34:      	ldp	d15, d14, [sp], #0xa0
    2b38:      	ret

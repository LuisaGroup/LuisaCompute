
/private/tmp/luisa-packet-inline.UY1lIE/capture/masked_softmax-1024x4097/on/object/tile_xir_w8_36383_1788935099527848_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0xb50
      2c:      	str	x0, [sp, #0x230]
      30:      	str	w3, [sp, #0x24c]
      34:      	cbz	w3, 0x32b8 <ltmp0+0x32b8>
      38:      	mov	w13, #0x0               ; =0
      3c:      	mov	w11, #0x5088            ; =20616
      40:      	movk	w11, #0x1, lsl #16
      44:      	mov	w14, #0xc020            ; =49184
      48:      	adrp	x8, 0x0 <ltmp0>
      4c:      	ldr	q0, [x8]
      50:      	str	q0, [sp, #0x210]
      54:      	adrp	x8, 0x0 <ltmp0>
      58:      	ldr	q23, [x8]
      5c:      	adrp	x8, 0x0 <ltmp0>
      60:      	ldr	q24, [x8]
      64:      	adrp	x8, 0x0 <ltmp0>
      68:      	ldr	q27, [x8]
      6c:      	adrp	x8, 0x0 <ltmp0>
      70:      	ldr	q25, [x8]
      74:      	mov	w6, #0x1                ; =1
      78:      	dup.2d	v26, x6
      7c:      	adrp	x8, 0x0 <ltmp0>
      80:      	ldr	q11, [x8]
      84:      	adrp	x8, 0x0 <ltmp0>
      88:      	ldr	q7, [x8]
      8c:      	adrp	x8, 0x0 <ltmp0>
      90:      	ldr	q16, [x8]
      94:      	adrp	x8, 0x0 <ltmp0>
      98:      	ldr	q17, [x8]
      9c:      	mvni.4s	v0, #0x7f, msl #16
      a0:      	fneg.4s	v8, v0
      a4:      	mov	w4, #0x4004             ; =16388
      a8:      	mvni.4s	v0, #0x3f, msl #16
      ac:      	fneg.4s	v9, v0
      b0:      	ldp	w9, w8, [x2, #0x2c]
      b4:      	str	w9, [sp, #0x248]
      b8:      	str	w8, [sp, #0x244]
      bc:      	ldp	w8, w9, [x2]
      c0:      	ldp	w10, w12, [x2, #0x8]
      c4:      	str	x12, [sp, #0x238]
      c8:      	stp	q25, q23, [sp, #0x3a0]
      cc:      	stp	q27, q24, [sp, #0x3e0]
      d0:      	str	q8, [sp, #0x2c0]
      d4:      	str	q26, [sp, #0x390]
      d8:      	str	x2, [sp, #0x228]
      dc:      	str	q11, [sp, #0x4a0]
      e0:      	str	q7, [sp, #0x490]
      e4:      	str	q16, [sp, #0x480]
      e8:      	str	q17, [sp, #0x470]
      ec:      	str	q9, [sp, #0x1c0]
      f0:      	b	0x144 <ltmp0+0x144>
      f4:      	ldr	x17, [sp, #0x278]
      f8:      	add	w8, w17, #0x1
      fc:      	ldr	w9, [sp, #0x248]
     100:      	cmp	w8, w9
     104:      	cset	w9, eq
     108:      	csinc	w8, wzr, w17, eq
     10c:      	ldr	w16, [sp, #0x26c]
     110:      	cinc	w10, w16, eq
     114:      	ldr	w12, [sp, #0x244]
     118:      	cmp	w10, w12
     11c:      	cset	w12, eq
     120:      	ands	w12, w9, w12
     124:      	csel	w9, wzr, w10, ne
     128:      	ldr	w15, [sp, #0x270]
     12c:      	add	w10, w15, w12
     130:      	ldr	w13, [sp, #0x274]
     134:      	add	w13, w13, #0x1
     138:      	ldr	w12, [sp, #0x24c]
     13c:      	cmp	w13, w12
     140:      	b.eq	0x32a8 <ltmp0+0x32a8>
     144:      	str	w13, [sp, #0x274]
     148:      	mov	x15, x10
     14c:      	str	w9, [sp, #0x26c]
     150:      	mov	x17, x8
     154:      	ubfiz	x8, x8, #5, #32
     158:      	ldr	x13, [sp, #0x238]
     15c:      	cmp	x8, x13
     160:      	csel	x9, x8, xzr, ls
     164:      	subs	x10, x13, x9
     168:      	cmp	x10, #0x20
     16c:      	mov	w12, #0x20              ; =32
     170:      	csel	x10, x10, x12, lo
     174:      	cmp	x13, x9
     178:      	ccmp	x8, x13, #0x2, hi
     17c:      	csel	x10, x10, xzr, ls
     180:      	mov	w8, #0xf2ca             ; =62154
     184:      	movk	w8, #0xf149, lsl #16
     188:      	dup.4s	v5, w8
     18c:      	mov	w8, #-0x3d300000        ; =-1026555904
     190:      	dup.4s	v1, w8
     194:      	mov	w8, #0x42c80000         ; =1120403456
     198:      	dup.4s	v0, w8
     19c:      	stp	q1, q0, [sp, #0x350]
     1a0:      	mov	w8, #0xaa3b             ; =43579
     1a4:      	movk	w8, #0x3fb8, lsl #16
     1a8:      	dup.4s	v0, w8
     1ac:      	str	q0, [sp, #0x400]
     1b0:      	mov	w8, #0x7200             ; =29184
     1b4:      	movk	w8, #0xbf31, lsl #16
     1b8:      	dup.4s	v0, w8
     1bc:      	str	q0, [sp, #0x410]
     1c0:      	mov	w8, #0xbe8e             ; =48782
     1c4:      	movk	w8, #0xb5bf, lsl #16
     1c8:      	dup.4s	v6, w8
     1cc:      	mov	w8, #0x2bda             ; =11226
     1d0:      	movk	w8, #0x3950, lsl #16
     1d4:      	dup.4s	v0, w8
     1d8:      	str	q0, [sp, #0x420]
     1dc:      	mov	w8, #0x96c9             ; =38601
     1e0:      	movk	w8, #0x3ab6, lsl #16
     1e4:      	dup.4s	v0, w8
     1e8:      	str	q0, [sp, #0x430]
     1ec:      	mov	w8, #0x88a6             ; =34982
     1f0:      	movk	w8, #0x3c08, lsl #16
     1f4:      	dup.4s	v0, w8
     1f8:      	str	q0, [sp, #0x440]
     1fc:      	mov	w8, #0xaa7a             ; =43642
     200:      	movk	w8, #0x3d2a, lsl #16
     204:      	dup.4s	v0, w8
     208:      	str	q0, [sp, #0x450]
     20c:      	mov	w8, #0xaaab             ; =43691
     210:      	movk	w8, #0x3e2a, lsl #16
     214:      	dup.4s	v0, w8
     218:      	stp	q5, q0, [sp, #0x3c0]
     21c:      	fmov.4s	v31, #1.00000000
     220:      	cmp	x10, #0x20
     224:      	str	w15, [sp, #0x270]
     228:      	str	x17, [sp, #0x278]
     22c:      	b.lo	0xa7c <ltmp0+0xa7c>
     230:      	mov	x9, #0x0                ; =0
     234:      	ldr	x10, [x2, #0x88]
     238:      	mov	w8, #0x1068             ; =4200
     23c:      	movk	w8, #0x1, lsl #16
     240:      	add	x12, x10, x8
     244:      	mov	w8, #0xd068             ; =53352
     248:      	add	x13, x10, x8
     24c:      	mov	w8, #0x4020             ; =16416
     250:      	add	x15, x10, x8
     254:      	mov	w8, #0xc060             ; =49248
     258:      	add	x8, x10, x8
     25c:      	mov	w16, #0x1088            ; =4232
     260:      	movk	w16, #0x1, lsl #16
     264:      	add	x0, x10, x16
     268:      	ldr	x16, [sp, #0x230]
     26c:      	ldr	x1, [x16]
     270:      	ldr	x30, [x16, #0x30]
     274:      	dup.2d	v0, x8
     278:      	ldr	q1, [sp, #0x210]
     27c:      	add.2d	v1, v0, v1
     280:      	lsl	w3, w17, #2
     284:      	and	x8, x17, #0x7ffffff
     288:      	mov	w16, #0x10              ; =16
     28c:      	movk	w16, #0x1, lsl #16
     290:      	umaddl	x22, w8, w16, x1
     294:      	mov	w17, #0xd128            ; =53544
     298:      	add	x24, x10, x17
     29c:      	mov	w17, #0x1148            ; =4424
     2a0:      	movk	w17, #0x1, lsl #16
     2a4:      	add	x25, x10, x17
     2a8:      	umaddl	x26, w8, w16, x30
     2ac:      	str	q1, [sp, #0x380]
     2b0:      	fmov	x27, d1
     2b4:      	mov	x16, #0x0               ; =0
     2b8:      	add	w8, w9, w3
     2bc:      	and	x8, x8, #0x1fffffff
     2c0:      	add	x17, x8, x8, lsl #12
     2c4:      	lsl	x17, x17, #2
     2c8:      	add	x5, x22, x16
     2cc:      	ldp	q1, q2, [x5]
     2d0:      	add	x5, x10, x16
     2d4:      	stp	q1, q2, [x5]
     2d8:      	add	x16, x16, #0x20
     2dc:      	cmp	x16, #0x4, lsl #12      ; =0x4000
     2e0:      	b.ne	0x2c8 <ltmp0+0x2c8>
     2e4:      	mov	x16, #0x0               ; =0
     2e8:      	add	x17, x17, #0x4, lsl #12 ; =0x4000
     2ec:      	ldr	s1, [x1, x17]
     2f0:      	mov	w5, #0x4000             ; =16384
     2f4:      	str	s1, [x10, x5]
     2f8:      	movi.2d	v1, #0000000000000000
     2fc:      	movi.2d	v2, #0000000000000000
     300:      	movi.2d	v3, #0000000000000000
     304:      	movi.2d	v4, #0000000000000000
     308:      	shl.2d	v18, v1, #0x3
     30c:      	shl.2d	v20, v2, #0x3
     310:      	shl.2d	v21, v3, #0x3
     314:      	shl.2d	v22, v4, #0x3
     318:      	orr.16b	v22, v22, v23
     31c:      	orr.16b	v21, v21, v24
     320:      	orr.16b	v20, v20, v27
     324:      	orr.16b	v18, v18, v25
     328:      	add	x16, x15, x16, lsl #6
     32c:      	stp	q18, q20, [x16]
     330:      	stp	q21, q22, [x16, #0x20]
     334:      	add.2d	v3, v3, v26
     338:      	add.2d	v2, v2, v26
     33c:      	add.2d	v4, v4, v26
     340:      	add.2d	v1, v1, v26
     344:      	fmov	x16, d1
     348:      	cmp	x16, #0x200
     34c:      	b.lt	0x308 <ltmp0+0x308>
     350:      	mov	x16, #0x0               ; =0
     354:      	mov	w5, #0x1000             ; =4096
     358:      	str	x5, [x10, x14]
     35c:      	mov	w5, #0xf001             ; =61441
     360:      	movk	w5, #0xff, lsl #16
     364:      	umull	x5, w8, w5
     368:      	lsr	x5, x5, #36
     36c:      	add	w5, w5, w5, lsl #12
     370:      	sub	w8, w8, w5
     374:      	dup.2s	v1, w8
     378:      	ushll.2d	v1, v1, #0x0
     37c:      	movi.2d	v2, #0000000000000000
     380:      	movi.2d	v3, #0000000000000000
     384:      	movi.2d	v4, #0000000000000000
     388:      	movi.2d	v18, #0000000000000000
     38c:      	movi.8b	v23, #0x1
     390:      	add	x8, x15, x16, lsl #6
     394:      	ldp	q21, q20, [x8, #0x20]
     398:      	ldp	q22, q25, [x8]
     39c:      	add.2d	v26, v18, v17
     3a0:      	add.2d	v27, v3, v7
     3a4:      	add.2d	v27, v27, v0
     3a8:      	add.2d	v28, v2, v11
     3ac:      	add.2d	v28, v28, v0
     3b0:      	cmge.2d	v25, v1, v25
     3b4:      	cmge.2d	v22, v1, v22
     3b8:      	uzp1.4s	v22, v22, v25
     3bc:      	cmge.2d	v21, v1, v21
     3c0:      	cmge.2d	v20, v1, v20
     3c4:      	uzp1.4s	v20, v21, v20
     3c8:      	uzp1.8h	v20, v22, v20
     3cc:      	xtn.8b	v20, v20
     3d0:      	and.8b	v20, v20, v23
     3d4:      	mov.d	x8, v28[1]
     3d8:      	fmov	x16, d28
     3dc:      	str	b20, [x16]
     3e0:      	st1.b	{ v20 }[1], [x8]
     3e4:      	mov.d	x8, v27[1]
     3e8:      	add.2d	v21, v4, v16
     3ec:      	fmov	x16, d27
     3f0:      	st1.b	{ v20 }[2], [x16]
     3f4:      	st1.b	{ v20 }[3], [x8]
     3f8:      	add.2d	v21, v21, v0
     3fc:      	mov.d	x8, v21[1]
     400:      	fmov	x16, d21
     404:      	st1.b	{ v20 }[4], [x16]
     408:      	add.2d	v21, v26, v0
     40c:      	st1.b	{ v20 }[5], [x8]
     410:      	mov.d	x8, v21[1]
     414:      	fmov	x16, d21
     418:      	st1.b	{ v20 }[6], [x16]
     41c:      	st1.b	{ v20 }[7], [x8]
     420:      	dup.2d	v20, x6
     424:      	add.2d	v4, v4, v20
     428:      	add.2d	v3, v3, v20
     42c:      	add.2d	v18, v18, v20
     430:      	add.2d	v2, v2, v20
     434:      	fmov	x16, d2
     438:      	cmp	x16, #0x200
     43c:      	b.lt	0x390 <ltmp0+0x390>
     440:      	mov	x8, #0x0                ; =0
     444:      	ldr	d2, [x10, x14]
     448:      	cmge.2d	v1, v1, v2
     44c:      	xtn.2s	v1, v1
     450:      	uzp1.4h	v1, v1, v0
     454:      	uzp1.8b	v1, v1, v0
     458:      	and.8b	v1, v1, v23
     45c:      	ldr	q2, [sp, #0x380]
     460:      	fmov	x16, d2
     464:      	str	b1, [x16]
     468:      	movi.2d	v1, #0000000000000000
     46c:      	movi.2d	v2, #0000000000000000
     470:      	movi.2d	v3, #0000000000000000
     474:      	movi.2d	v18, #0000000000000000
     478:      	movi.4s	v24, #0x4b, lsl #24
     47c:      	add.2d	v4, v18, v17
     480:      	add.2d	v20, v3, v16
     484:      	add.2d	v4, v4, v0
     488:      	add.2d	v21, v2, v7
     48c:      	add.2d	v22, v1, v11
     490:      	add.2d	v22, v22, v0
     494:      	mov.d	x16, v22[1]
     498:      	add.2d	v20, v20, v0
     49c:      	add.2d	v21, v21, v0
     4a0:      	fmov	x5, d22
     4a4:      	mov.d	x7, v21[1]
     4a8:      	mov.d	x19, v20[1]
     4ac:      	fmov	x20, d21
     4b0:      	ldr	b21, [x5]
     4b4:      	ld1.b	{ v21 }[1], [x16]
     4b8:      	mov.d	x16, v4[1]
     4bc:      	fmov	x5, d20
     4c0:      	ld1.b	{ v21 }[2], [x20]
     4c4:      	ld1.b	{ v21 }[3], [x7]
     4c8:      	fmov	x7, d4
     4cc:      	ld1.b	{ v21 }[4], [x5]
     4d0:      	ld1.b	{ v21 }[5], [x19]
     4d4:      	ld1.b	{ v21 }[6], [x7]
     4d8:      	ld1.b	{ v21 }[7], [x16]
     4dc:      	cmeq.8b	v4, v21, #0
     4e0:      	sshll.8h	v4, v4, #0x0
     4e4:      	sshll2.4s	v20, v4, #0x0
     4e8:      	sshll.4s	v4, v4, #0x0
     4ec:      	lsl	x8, x8, #5
     4f0:      	add	x16, x10, x8
     4f4:      	ldp	q22, q21, [x16]
     4f8:      	bsl.16b	v4, v5, v22
     4fc:      	bsl.16b	v20, v5, v21
     500:      	add	x8, x13, x8
     504:      	dup.2d	v21, x6
     508:      	stp	q4, q20, [x8]
     50c:      	add.2d	v3, v3, v21
     510:      	add.2d	v2, v2, v21
     514:      	add.2d	v18, v18, v21
     518:      	add.2d	v1, v1, v21
     51c:      	fmov	x8, d1
     520:      	cmp	x8, #0x200
     524:      	b.lt	0x47c <ltmp0+0x47c>
     528:      	mov.16b	v5, v6
     52c:      	mov.16b	v10, v8
     530:      	mov.16b	v11, v9
     534:      	mov	x8, #0x0                ; =0
     538:      	ldr	b1, [x27]
     53c:      	cmeq.8b	v1, v1, #0
     540:      	sshll.8h	v1, v1, #0x0
     544:      	sshll.4s	v1, v1, #0x0
     548:      	ldr	q2, [x10, #0x4000]
     54c:      	mov	w16, #0xf2ca            ; =62154
     550:      	movk	w16, #0xf149, lsl #16
     554:      	fmov	s3, w16
     558:      	bsl.16b	v1, v3, v2
     55c:      	ldr	q2, [x12]
     560:      	mov.s	v2[0], v1[0]
     564:      	str	q2, [x12]
     568:      	ldp	q2, q3, [x13]
     56c:      	ldp	q21, q22, [x13, #0x20]
     570:      	ldp	q25, q4, [x13, #0x40]
     574:      	ldp	q18, q20, [x13, #0x60]
     578:      	add	x16, x24, x8, lsl #5
     57c:      	ldp	q26, q27, [x16, #-0x40]
     580:      	fmaxnm.4s	v3, v3, v27
     584:      	fmaxnm.4s	v2, v2, v26
     588:      	ldp	q26, q27, [x16, #-0x20]
     58c:      	fmaxnm.4s	v22, v22, v27
     590:      	fmaxnm.4s	v21, v21, v26
     594:      	ldp	q26, q27, [x16]
     598:      	fmaxnm.4s	v4, v4, v27
     59c:      	fmaxnm.4s	v25, v25, v26
     5a0:      	ldp	q26, q27, [x16, #0x20]
     5a4:      	fmaxnm.4s	v20, v20, v27
     5a8:      	fmaxnm.4s	v18, v18, v26
     5ac:      	add	x8, x8, #0x4
     5b0:      	cmp	x8, #0x1fc
     5b4:      	b.lo	0x578 <ltmp0+0x578>
     5b8:      	mov	x7, #0x0                ; =0
     5bc:      	movi.2d	v26, #0000000000000000
     5c0:      	mov.s	v26[0], v1[0]
     5c4:      	fmaxnm.4s	v1, v2, v26
     5c8:      	mov.s	v2[0], v1[0]
     5cc:      	fmaxnm.4s	v1, v3, v22
     5d0:      	fmaxnm.4s	v2, v2, v21
     5d4:      	fmaxnm.4s	v2, v2, v25
     5d8:      	fmaxnm.4s	v1, v1, v4
     5dc:      	fmaxnm.4s	v1, v1, v20
     5e0:      	fmaxnm.4s	v2, v2, v18
     5e4:      	rev64.4s	v3, v2
     5e8:      	rev64.4s	v4, v1
     5ec:      	fmaxnm.4s	v1, v1, v4
     5f0:      	fmaxnm.4s	v2, v2, v3
     5f4:      	ext.16b	v3, v2, v2, #0x8
     5f8:      	ext.16b	v4, v1, v1, #0x8
     5fc:      	fmaxnm.4s	v1, v1, v4
     600:      	fmaxnm.4s	v2, v2, v3
     604:      	fmaxnm.4s	v1, v2, v1
     608:      	mov	w8, #-0x800000          ; =-8388608
     60c:      	fmov	s2, w8
     610:      	fmaxnm	s1, s1, s2
     614:      	str	q1, [sp, #0x460]
     618:      	dup.4s	v27, v1[0]
     61c:      	movi.2d	v28, #0000000000000000
     620:      	movi.2d	v25, #0000000000000000
     624:      	movi.2d	v18, #0000000000000000
     628:      	movi.2d	v1, #0000000000000000
     62c:      	ldr	q12, [sp, #0x3d0]
     630:      	ldr	q13, [sp, #0x450]
     634:      	ldr	q14, [sp, #0x440]
     638:      	ldr	q15, [sp, #0x430]
     63c:      	ldr	q9, [sp, #0x420]
     640:      	ldr	q8, [sp, #0x410]
     644:      	ldr	q6, [sp, #0x400]
     648:      	ldr	q17, [sp, #0x480]
     64c:      	ldr	q19, [sp, #0x470]
     650:      	ldp	q30, q29, [sp, #0x350]
     654:      	add.2d	v2, v18, v17
     658:      	add.2d	v2, v2, v0
     65c:      	ldr	q3, [sp, #0x490]
     660:      	add.2d	v3, v25, v3
     664:      	add.2d	v3, v3, v0
     668:      	ldr	q4, [sp, #0x4a0]
     66c:      	add.2d	v4, v28, v4
     670:      	add.2d	v4, v4, v0
     674:      	mov.d	x8, v4[1]
     678:      	mov.d	x16, v3[1]
     67c:      	fmov	x19, d4
     680:      	fmov	x5, d3
     684:      	mov.d	x23, v2[1]
     688:      	lsl	x7, x7, #5
     68c:      	fmov	x21, d2
     690:      	add	x20, x13, x7
     694:      	ldp	q2, q3, [x20]
     698:      	fsub.4s	v3, v3, v27
     69c:      	fsub.4s	v2, v2, v27
     6a0:      	fcmge.4s	v4, v2, v30
     6a4:      	fcmge.4s	v20, v3, v30
     6a8:      	fcmge.4s	v21, v29, v2
     6ac:      	fcmge.4s	v22, v29, v3
     6b0:      	and.16b	v20, v20, v22
     6b4:      	and.16b	v4, v4, v21
     6b8:      	and.16b	v4, v4, v2
     6bc:      	and.16b	v20, v20, v3
     6c0:      	fmul.4s	v21, v20, v6
     6c4:      	fmul.4s	v22, v4, v6
     6c8:      	mvni.4s	v7, #0x80, lsl #24
     6cc:      	mov.16b	v26, v7
     6d0:      	bsl.16b	v26, v24, v22
     6d4:      	mvni.4s	v16, #0x80, lsl #24
     6d8:      	mov.16b	v23, v7
     6dc:      	bsl.16b	v23, v24, v21
     6e0:      	fadd.4s	v21, v21, v23
     6e4:      	fadd.4s	v22, v22, v26
     6e8:      	fsub.4s	v22, v22, v26
     6ec:      	fsub.4s	v21, v21, v23
     6f0:      	fcvtzs.4s	v21, v21
     6f4:      	fcvtzs.4s	v22, v22
     6f8:      	scvtf.4s	v23, v22
     6fc:      	scvtf.4s	v26, v21
     700:      	fmul.4s	v24, v23, v8
     704:      	fadd.4s	v4, v4, v24
     708:      	fmul.4s	v24, v26, v8
     70c:      	fadd.4s	v20, v20, v24
     710:      	add.2d	v24, v1, v19
     714:      	add.2d	v24, v24, v0
     718:      	mov.d	x20, v24[1]
     71c:      	fmul.4s	v23, v23, v5
     720:      	fmul.4s	v26, v26, v5
     724:      	fadd.4s	v20, v20, v26
     728:      	fadd.4s	v4, v4, v23
     72c:      	fmul.4s	v23, v4, v9
     730:      	fmul.4s	v26, v20, v9
     734:      	fadd.4s	v26, v26, v15
     738:      	fadd.4s	v23, v23, v15
     73c:      	fmul.4s	v23, v4, v23
     740:      	fmul.4s	v26, v20, v26
     744:      	fadd.4s	v26, v26, v14
     748:      	fadd.4s	v23, v23, v14
     74c:      	fmul.4s	v23, v4, v23
     750:      	fmul.4s	v26, v20, v26
     754:      	fadd.4s	v26, v26, v13
     758:      	fadd.4s	v23, v23, v13
     75c:      	fmul.4s	v23, v4, v23
     760:      	fmul.4s	v26, v20, v26
     764:      	fadd.4s	v26, v26, v12
     768:      	fadd.4s	v23, v23, v12
     76c:      	fmov	x28, d24
     770:      	fmul.4s	v23, v4, v23
     774:      	fmul.4s	v24, v20, v26
     778:      	movi.4s	v26, #0x3f, lsl #24
     77c:      	fadd.4s	v24, v24, v26
     780:      	movi.4s	v7, #0x3f, lsl #24
     784:      	fadd.4s	v23, v23, v26
     788:      	fmul.4s	v26, v4, v4
     78c:      	fmul.4s	v23, v26, v23
     790:      	fmul.4s	v26, v20, v20
     794:      	fmul.4s	v24, v26, v24
     798:      	fadd.4s	v20, v20, v24
     79c:      	fadd.4s	v4, v4, v23
     7a0:      	sshr.4s	v23, v22, #0x1
     7a4:      	fadd.4s	v20, v20, v31
     7a8:      	sshr.4s	v24, v21, #0x1
     7ac:      	shl.4s	v26, v24, #0x17
     7b0:      	add.4s	v26, v26, v31
     7b4:      	fmul.4s	v20, v20, v26
     7b8:      	shl.4s	v26, v23, #0x17
     7bc:      	fadd.4s	v4, v4, v31
     7c0:      	add.4s	v26, v26, v31
     7c4:      	fmul.4s	v4, v4, v26
     7c8:      	sub.4s	v21, v21, v24
     7cc:      	movi.4s	v24, #0x4b, lsl #24
     7d0:      	sub.4s	v22, v22, v23
     7d4:      	shl.4s	v22, v22, #0x17
     7d8:      	add.4s	v22, v22, v31
     7dc:      	fmul.4s	v4, v4, v22
     7e0:      	ldr	b22, [x19]
     7e4:      	ld1.b	{ v22 }[1], [x8]
     7e8:      	ld1.b	{ v22 }[2], [x5]
     7ec:      	ld1.b	{ v22 }[3], [x16]
     7f0:      	shl.4s	v21, v21, #0x17
     7f4:      	add.4s	v21, v21, v31
     7f8:      	fmul.4s	v20, v20, v21
     7fc:      	fcmgt.4s	v21, v30, v3
     800:      	bic.16b	v20, v20, v21
     804:      	fcmgt.4s	v21, v30, v2
     808:      	bic.16b	v4, v4, v21
     80c:      	fcmgt.4s	v21, v2, v29
     810:      	bit.16b	v4, v10, v21
     814:      	fcmgt.4s	v21, v3, v29
     818:      	bit.16b	v20, v10, v21
     81c:      	ld1.b	{ v22 }[4], [x21]
     820:      	ld1.b	{ v22 }[5], [x23]
     824:      	fcmeq.4s	v3, v3, v3
     828:      	bsl.16b	v3, v20, v11
     82c:      	ld1.b	{ v22 }[6], [x28]
     830:      	ld1.b	{ v22 }[7], [x20]
     834:      	cmeq.8b	v20, v22, #0
     838:      	sshll.8h	v20, v20, #0x0
     83c:      	fcmeq.4s	v2, v2, v2
     840:      	bsl.16b	v2, v4, v11
     844:      	sshll.4s	v4, v20, #0x0
     848:      	bic.16b	v2, v2, v4
     84c:      	sshll2.4s	v4, v20, #0x0
     850:      	bic.16b	v3, v3, v4
     854:      	add	x8, x0, x7
     858:      	stp	q2, q3, [x8]
     85c:      	dup.2d	v2, x6
     860:      	add.2d	v18, v18, v2
     864:      	add.2d	v25, v25, v2
     868:      	add.2d	v1, v1, v2
     86c:      	add.2d	v28, v28, v2
     870:      	fmov	x7, d28
     874:      	cmp	x7, #0x200
     878:      	b.lt	0x654 <ltmp0+0x654>
     87c:      	mov	x8, #0x0                ; =0
     880:      	ldr	b1, [x27]
     884:      	cmeq.8b	v1, v1, #0
     888:      	sshll.8h	v1, v1, #0x0
     88c:      	sshll.4s	v1, v1, #0x0
     890:      	ldr	q2, [x12]
     894:      	ldr	q3, [sp, #0x460]
     898:      	fsub.4s	v2, v2, v3
     89c:      	movi.2d	v3, #0000000000000000
     8a0:      	mov.s	v3[0], v2[0]
     8a4:      	fcmge.4s	v2, v3, v30
     8a8:      	fcmge.4s	v4, v29, v3
     8ac:      	and.16b	v2, v2, v4
     8b0:      	and.16b	v2, v2, v3
     8b4:      	fmul.4s	v4, v2, v6
     8b8:      	mov.16b	v18, v16
     8bc:      	bsl.16b	v18, v24, v4
     8c0:      	fadd.4s	v4, v4, v18
     8c4:      	fsub.4s	v4, v4, v18
     8c8:      	fcvtzs.4s	v4, v4
     8cc:      	scvtf.4s	v18, v4
     8d0:      	fmul.4s	v20, v18, v8
     8d4:      	fadd.4s	v2, v2, v20
     8d8:      	fmul.4s	v18, v18, v5
     8dc:      	fadd.4s	v2, v2, v18
     8e0:      	fmul.4s	v18, v2, v9
     8e4:      	fadd.4s	v18, v18, v15
     8e8:      	fmul.4s	v18, v2, v18
     8ec:      	fadd.4s	v18, v18, v14
     8f0:      	fmul.4s	v18, v2, v18
     8f4:      	fadd.4s	v18, v18, v13
     8f8:      	fmul.4s	v18, v2, v18
     8fc:      	fadd.4s	v18, v18, v12
     900:      	fmul.4s	v18, v2, v18
     904:      	fadd.4s	v18, v18, v7
     908:      	fmul.4s	v20, v2, v2
     90c:      	fmul.4s	v18, v20, v18
     910:      	fadd.4s	v2, v2, v18
     914:      	fadd.4s	v2, v2, v31
     918:      	sshr.4s	v18, v4, #0x1
     91c:      	shl.4s	v20, v18, #0x17
     920:      	add.4s	v20, v20, v31
     924:      	fmul.4s	v2, v2, v20
     928:      	sub.4s	v4, v4, v18
     92c:      	shl.4s	v4, v4, #0x17
     930:      	add.4s	v4, v4, v31
     934:      	fmul.4s	v2, v2, v4
     938:      	fcmgt.4s	v4, v30, v3
     93c:      	bic.16b	v2, v2, v4
     940:      	fcmgt.4s	v4, v3, v29
     944:      	bit.16b	v2, v10, v4
     948:      	fcmeq.4s	v3, v3, v3
     94c:      	bif.16b	v2, v11, v3
     950:      	bic.16b	v2, v2, v1
     954:      	ldr	q1, [x10, x11]
     958:      	mov.s	v1[0], v2[0]
     95c:      	str	q1, [x10, x11]
     960:      	ldp	q2, q3, [x12, #0x20]
     964:      	ldp	q21, q22, [x12, #0x40]
     968:      	ldp	q25, q4, [x12, #0x60]
     96c:      	ldp	q18, q20, [x12, #0x80]
     970:      	mov.16b	v9, v11
     974:      	mov.16b	v8, v10
     978:      	mov.16b	v6, v5
     97c:      	add	x16, x25, x8, lsl #5
     980:      	ldp	q23, q24, [x16, #-0x40]
     984:      	fadd.4s	v3, v3, v24
     988:      	fadd.4s	v2, v2, v23
     98c:      	ldp	q23, q24, [x16, #-0x20]
     990:      	fadd.4s	v22, v22, v24
     994:      	fadd.4s	v21, v21, v23
     998:      	ldp	q23, q24, [x16]
     99c:      	fadd.4s	v4, v4, v24
     9a0:      	fadd.4s	v25, v25, v23
     9a4:      	ldp	q23, q24, [x16, #0x20]
     9a8:      	fadd.4s	v20, v20, v24
     9ac:      	fadd.4s	v18, v18, v23
     9b0:      	add	x8, x8, #0x4
     9b4:      	cmp	x8, #0x1fc
     9b8:      	b.lo	0x97c <ltmp0+0x97c>
     9bc:      	mov	x8, #0x0                ; =0
     9c0:      	fadd.4s	v1, v1, v2
     9c4:      	mov.s	v2[0], v1[0]
     9c8:      	fadd.4s	v1, v22, v3
     9cc:      	fadd.4s	v2, v21, v2
     9d0:      	fadd.4s	v2, v25, v2
     9d4:      	fadd.4s	v1, v4, v1
     9d8:      	fadd.4s	v1, v20, v1
     9dc:      	fadd.4s	v2, v18, v2
     9e0:      	rev64.4s	v3, v2
     9e4:      	rev64.4s	v4, v1
     9e8:      	fadd.4s	v1, v1, v4
     9ec:      	fadd.4s	v2, v2, v3
     9f0:      	dup.4s	v3, v2[2]
     9f4:      	dup.4s	v4, v1[2]
     9f8:      	fadd.4s	v1, v1, v4
     9fc:      	fadd.4s	v2, v2, v3
     a00:      	fadd.4s	v1, v2, v1
     a04:      	movi	d2, #0000000000000000
     a08:      	fadd	s1, s1, s2
     a0c:      	dup.4s	v2, v1[0]
     a10:      	ldp	q23, q5, [sp, #0x3b0]
     a14:      	ldr	q27, [sp, #0x3e0]
     a18:      	ldr	q11, [sp, #0x4a0]
     a1c:      	ldr	q7, [sp, #0x490]
     a20:      	ldr	q16, [sp, #0x480]
     a24:      	ldr	q17, [sp, #0x470]
     a28:      	ldr	q26, [sp, #0x390]
     a2c:      	add	x16, x0, x8
     a30:      	ldp	q4, q3, [x16]
     a34:      	fdiv.4s	v4, v4, v2
     a38:      	fdiv.4s	v3, v3, v2
     a3c:      	add	x16, x26, x8
     a40:      	stp	q4, q3, [x16]
     a44:      	add	x8, x8, #0x20
     a48:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     a4c:      	b.ne	0xa2c <ltmp0+0xa2c>
     a50:      	ldr	q2, [x10, x11]
     a54:      	fdiv.4s	v1, v2, v1
     a58:      	str	s1, [x30, x17]
     a5c:      	add	x9, x9, #0x1
     a60:      	add	x22, x22, x4
     a64:      	add	x26, x26, x4
     a68:      	cmp	x9, #0x4
     a6c:      	ldr	q24, [sp, #0x3f0]
     a70:      	ldr	q25, [sp, #0x3a0]
     a74:      	b.ne	0x2b4 <ltmp0+0x2b4>
     a78:      	b	0xf4 <ltmp0+0xf4>
     a7c:      	lsr	x9, x10, #3
     a80:      	str	x10, [sp, #0x370]
     a84:      	cmp	x10, #0x8
     a88:      	str	q6, [sp, #0x340]
     a8c:      	ldp	q30, q29, [sp, #0x350]
     a90:      	b.lo	0x12dc <ltmp0+0x12dc>
     a94:      	mov	x12, #0x0               ; =0
     a98:      	ldr	x8, [sp, #0x228]
     a9c:      	ldr	x13, [x8, #0x88]
     aa0:      	mov	w8, #0x1068             ; =4200
     aa4:      	movk	w8, #0x1, lsl #16
     aa8:      	add	x15, x13, x8
     aac:      	mov	w8, #0xd068             ; =53352
     ab0:      	add	x0, x13, x8
     ab4:      	ldr	x8, [sp, #0x230]
     ab8:      	ldr	x1, [x8]
     abc:      	ldr	x2, [x8, #0x30]
     ac0:      	mov	w8, #0x4020             ; =16416
     ac4:      	add	x3, x13, x8
     ac8:      	mov	w8, #0xc060             ; =49248
     acc:      	add	x8, x13, x8
     ad0:      	dup.2d	v0, x8
     ad4:      	ldr	q1, [sp, #0x210]
     ad8:      	add.2d	v1, v0, v1
     adc:      	mov	w8, #0x1088             ; =4232
     ae0:      	movk	w8, #0x1, lsl #16
     ae4:      	add	x22, x13, x8
     ae8:      	ldr	x8, [sp, #0x278]
     aec:      	lsl	w24, w8, #2
     af0:      	and	x8, x8, #0x7ffffff
     af4:      	mov	w10, #0x10              ; =16
     af8:      	movk	w10, #0x1, lsl #16
     afc:      	umaddl	x25, w8, w10, x1
     b00:      	mov	w16, #0xd128            ; =53544
     b04:      	add	x26, x13, x16
     b08:      	mov	w16, #0x1148            ; =4424
     b0c:      	movk	w16, #0x1, lsl #16
     b10:      	add	x27, x13, x16
     b14:      	umaddl	x28, w8, w10, x2
     b18:      	str	q1, [sp, #0x380]
     b1c:      	fmov	x30, d1
     b20:      	mov	x16, #0x0               ; =0
     b24:      	add	w8, w12, w24
     b28:      	and	x8, x8, #0x1fffffff
     b2c:      	add	x17, x8, x8, lsl #12
     b30:      	lsl	x17, x17, #2
     b34:      	add	x5, x25, x16
     b38:      	ldp	q1, q2, [x5]
     b3c:      	add	x5, x13, x16
     b40:      	stp	q1, q2, [x5]
     b44:      	add	x16, x16, #0x20
     b48:      	cmp	x16, #0x4, lsl #12      ; =0x4000
     b4c:      	b.ne	0xb34 <ltmp0+0xb34>
     b50:      	mov	x16, #0x0               ; =0
     b54:      	add	x17, x17, #0x4, lsl #12 ; =0x4000
     b58:      	ldr	s1, [x1, x17]
     b5c:      	mov	w10, #0x4000            ; =16384
     b60:      	str	s1, [x13, x10]
     b64:      	movi.2d	v1, #0000000000000000
     b68:      	movi.2d	v2, #0000000000000000
     b6c:      	movi.2d	v3, #0000000000000000
     b70:      	movi.2d	v4, #0000000000000000
     b74:      	shl.2d	v18, v1, #0x3
     b78:      	shl.2d	v20, v2, #0x3
     b7c:      	shl.2d	v21, v3, #0x3
     b80:      	shl.2d	v22, v4, #0x3
     b84:      	orr.16b	v22, v22, v23
     b88:      	orr.16b	v21, v21, v24
     b8c:      	orr.16b	v20, v20, v27
     b90:      	orr.16b	v18, v18, v25
     b94:      	add	x16, x3, x16, lsl #6
     b98:      	stp	q18, q20, [x16]
     b9c:      	stp	q21, q22, [x16, #0x20]
     ba0:      	dup.2d	v18, x6
     ba4:      	add.2d	v3, v3, v18
     ba8:      	add.2d	v2, v2, v18
     bac:      	add.2d	v4, v4, v18
     bb0:      	add.2d	v1, v1, v18
     bb4:      	fmov	x16, d1
     bb8:      	cmp	x16, #0x200
     bbc:      	b.lt	0xb74 <ltmp0+0xb74>
     bc0:      	mov	x16, #0x0               ; =0
     bc4:      	mov	w10, #0x1000            ; =4096
     bc8:      	str	x10, [x13, x14]
     bcc:      	mov	w10, #0xf001            ; =61441
     bd0:      	movk	w10, #0xff, lsl #16
     bd4:      	umull	x5, w8, w10
     bd8:      	lsr	x5, x5, #36
     bdc:      	add	w5, w5, w5, lsl #12
     be0:      	sub	w8, w8, w5
     be4:      	dup.2s	v1, w8
     be8:      	ushll.2d	v1, v1, #0x0
     bec:      	movi.2d	v2, #0000000000000000
     bf0:      	movi.2d	v3, #0000000000000000
     bf4:      	movi.2d	v4, #0000000000000000
     bf8:      	movi.2d	v18, #0000000000000000
     bfc:      	movi.8b	v27, #0x1
     c00:      	add	x8, x3, x16, lsl #6
     c04:      	ldp	q21, q20, [x8, #0x20]
     c08:      	ldp	q22, q23, [x8]
     c0c:      	add.2d	v24, v18, v17
     c10:      	add.2d	v25, v3, v7
     c14:      	add.2d	v25, v25, v0
     c18:      	add.2d	v26, v2, v11
     c1c:      	add.2d	v26, v26, v0
     c20:      	cmge.2d	v23, v1, v23
     c24:      	cmge.2d	v22, v1, v22
     c28:      	uzp1.4s	v22, v22, v23
     c2c:      	cmge.2d	v21, v1, v21
     c30:      	cmge.2d	v20, v1, v20
     c34:      	uzp1.4s	v20, v21, v20
     c38:      	uzp1.8h	v20, v22, v20
     c3c:      	xtn.8b	v20, v20
     c40:      	and.8b	v20, v20, v27
     c44:      	mov.d	x8, v26[1]
     c48:      	fmov	x16, d26
     c4c:      	str	b20, [x16]
     c50:      	st1.b	{ v20 }[1], [x8]
     c54:      	mov.d	x8, v25[1]
     c58:      	add.2d	v21, v4, v16
     c5c:      	fmov	x16, d25
     c60:      	st1.b	{ v20 }[2], [x16]
     c64:      	st1.b	{ v20 }[3], [x8]
     c68:      	add.2d	v21, v21, v0
     c6c:      	mov.d	x8, v21[1]
     c70:      	fmov	x16, d21
     c74:      	st1.b	{ v20 }[4], [x16]
     c78:      	add.2d	v21, v24, v0
     c7c:      	st1.b	{ v20 }[5], [x8]
     c80:      	mov.d	x8, v21[1]
     c84:      	fmov	x16, d21
     c88:      	st1.b	{ v20 }[6], [x16]
     c8c:      	st1.b	{ v20 }[7], [x8]
     c90:      	dup.2d	v20, x6
     c94:      	add.2d	v4, v4, v20
     c98:      	add.2d	v3, v3, v20
     c9c:      	add.2d	v18, v18, v20
     ca0:      	add.2d	v2, v2, v20
     ca4:      	fmov	x16, d2
     ca8:      	cmp	x16, #0x200
     cac:      	b.lt	0xc00 <ltmp0+0xc00>
     cb0:      	mov	x8, #0x0                ; =0
     cb4:      	ldr	d2, [x13, x14]
     cb8:      	cmge.2d	v1, v1, v2
     cbc:      	xtn.2s	v1, v1
     cc0:      	uzp1.4h	v1, v1, v0
     cc4:      	uzp1.8b	v1, v1, v0
     cc8:      	and.8b	v1, v1, v27
     ccc:      	ldr	q2, [sp, #0x380]
     cd0:      	fmov	x16, d2
     cd4:      	str	b1, [x16]
     cd8:      	movi.2d	v1, #0000000000000000
     cdc:      	movi.2d	v2, #0000000000000000
     ce0:      	movi.2d	v3, #0000000000000000
     ce4:      	movi.2d	v18, #0000000000000000
     ce8:      	add.2d	v4, v18, v17
     cec:      	add.2d	v20, v3, v16
     cf0:      	add.2d	v4, v4, v0
     cf4:      	add.2d	v21, v2, v7
     cf8:      	add.2d	v22, v1, v11
     cfc:      	add.2d	v22, v22, v0
     d00:      	mov.d	x16, v22[1]
     d04:      	add.2d	v20, v20, v0
     d08:      	add.2d	v21, v21, v0
     d0c:      	fmov	x5, d22
     d10:      	mov.d	x7, v21[1]
     d14:      	mov.d	x19, v20[1]
     d18:      	fmov	x20, d21
     d1c:      	ldr	b21, [x5]
     d20:      	ld1.b	{ v21 }[1], [x16]
     d24:      	mov.d	x16, v4[1]
     d28:      	fmov	x5, d20
     d2c:      	ld1.b	{ v21 }[2], [x20]
     d30:      	ld1.b	{ v21 }[3], [x7]
     d34:      	fmov	x7, d4
     d38:      	ld1.b	{ v21 }[4], [x5]
     d3c:      	ld1.b	{ v21 }[5], [x19]
     d40:      	ld1.b	{ v21 }[6], [x7]
     d44:      	ld1.b	{ v21 }[7], [x16]
     d48:      	cmeq.8b	v4, v21, #0
     d4c:      	sshll.8h	v4, v4, #0x0
     d50:      	sshll2.4s	v20, v4, #0x0
     d54:      	sshll.4s	v4, v4, #0x0
     d58:      	lsl	x8, x8, #5
     d5c:      	add	x16, x13, x8
     d60:      	ldp	q22, q21, [x16]
     d64:      	bsl.16b	v4, v5, v22
     d68:      	bsl.16b	v20, v5, v21
     d6c:      	add	x8, x0, x8
     d70:      	dup.2d	v21, x6
     d74:      	stp	q4, q20, [x8]
     d78:      	add.2d	v3, v3, v21
     d7c:      	add.2d	v2, v2, v21
     d80:      	add.2d	v18, v18, v21
     d84:      	add.2d	v1, v1, v21
     d88:      	fmov	x8, d1
     d8c:      	cmp	x8, #0x200
     d90:      	b.lt	0xce8 <ltmp0+0xce8>
     d94:      	mov.16b	v11, v9
     d98:      	mov	x8, #0x0                ; =0
     d9c:      	ldr	b1, [x30]
     da0:      	cmeq.8b	v1, v1, #0
     da4:      	sshll.8h	v1, v1, #0x0
     da8:      	sshll.4s	v1, v1, #0x0
     dac:      	ldr	q2, [x13, #0x4000]
     db0:      	mov	w10, #0xf2ca            ; =62154
     db4:      	movk	w10, #0xf149, lsl #16
     db8:      	fmov	s3, w10
     dbc:      	bsl.16b	v1, v3, v2
     dc0:      	ldr	q2, [x15]
     dc4:      	mov.s	v2[0], v1[0]
     dc8:      	str	q2, [x15]
     dcc:      	ldp	q2, q3, [x0]
     dd0:      	ldp	q21, q22, [x0, #0x20]
     dd4:      	ldp	q25, q4, [x0, #0x40]
     dd8:      	ldp	q18, q20, [x0, #0x60]
     ddc:      	add	x16, x26, x8, lsl #5
     de0:      	ldp	q23, q24, [x16, #-0x40]
     de4:      	fmaxnm.4s	v3, v3, v24
     de8:      	fmaxnm.4s	v2, v2, v23
     dec:      	ldp	q23, q24, [x16, #-0x20]
     df0:      	fmaxnm.4s	v22, v22, v24
     df4:      	fmaxnm.4s	v21, v21, v23
     df8:      	ldp	q23, q24, [x16]
     dfc:      	fmaxnm.4s	v4, v4, v24
     e00:      	fmaxnm.4s	v25, v25, v23
     e04:      	ldp	q23, q24, [x16, #0x20]
     e08:      	fmaxnm.4s	v20, v20, v24
     e0c:      	fmaxnm.4s	v18, v18, v23
     e10:      	add	x8, x8, #0x4
     e14:      	cmp	x8, #0x1fc
     e18:      	b.lo	0xddc <ltmp0+0xddc>
     e1c:      	mov	x7, #0x0                ; =0
     e20:      	movi.2d	v23, #0000000000000000
     e24:      	mov.s	v23[0], v1[0]
     e28:      	fmaxnm.4s	v1, v2, v23
     e2c:      	mov.s	v2[0], v1[0]
     e30:      	fmaxnm.4s	v1, v3, v22
     e34:      	fmaxnm.4s	v2, v2, v21
     e38:      	fmaxnm.4s	v2, v2, v25
     e3c:      	fmaxnm.4s	v1, v1, v4
     e40:      	fmaxnm.4s	v1, v1, v20
     e44:      	fmaxnm.4s	v2, v2, v18
     e48:      	rev64.4s	v3, v2
     e4c:      	rev64.4s	v4, v1
     e50:      	fmaxnm.4s	v1, v1, v4
     e54:      	fmaxnm.4s	v2, v2, v3
     e58:      	ext.16b	v3, v2, v2, #0x8
     e5c:      	ext.16b	v4, v1, v1, #0x8
     e60:      	fmaxnm.4s	v1, v1, v4
     e64:      	fmaxnm.4s	v2, v2, v3
     e68:      	fmaxnm.4s	v1, v2, v1
     e6c:      	mov	w8, #-0x800000          ; =-8388608
     e70:      	fmov	s2, w8
     e74:      	fmaxnm	s1, s1, s2
     e78:      	str	q1, [sp, #0x460]
     e7c:      	dup.4s	v27, v1[0]
     e80:      	movi.2d	v28, #0000000000000000
     e84:      	movi.2d	v25, #0000000000000000
     e88:      	movi.2d	v18, #0000000000000000
     e8c:      	movi.2d	v1, #0000000000000000
     e90:      	ldr	q10, [sp, #0x2c0]
     e94:      	ldr	q13, [sp, #0x3d0]
     e98:      	ldr	q14, [sp, #0x450]
     e9c:      	ldr	q15, [sp, #0x440]
     ea0:      	ldr	q5, [sp, #0x430]
     ea4:      	ldr	q6, [sp, #0x420]
     ea8:      	ldr	q19, [sp, #0x470]
     eac:      	ldr	q12, [sp, #0x340]
     eb0:      	ldr	q8, [sp, #0x410]
     eb4:      	ldr	q9, [sp, #0x400]
     eb8:      	ldr	q2, [sp, #0x480]
     ebc:      	add.2d	v2, v18, v2
     ec0:      	add.2d	v2, v2, v0
     ec4:      	ldr	q3, [sp, #0x490]
     ec8:      	add.2d	v3, v25, v3
     ecc:      	add.2d	v3, v3, v0
     ed0:      	ldr	q4, [sp, #0x4a0]
     ed4:      	add.2d	v4, v28, v4
     ed8:      	add.2d	v4, v4, v0
     edc:      	mov.d	x16, v4[1]
     ee0:      	mov.d	x8, v3[1]
     ee4:      	fmov	x19, d4
     ee8:      	fmov	x5, d3
     eec:      	mov.d	x23, v2[1]
     ef0:      	lsl	x7, x7, #5
     ef4:      	fmov	x21, d2
     ef8:      	add	x20, x0, x7
     efc:      	ldp	q3, q2, [x20]
     f00:      	fsub.4s	v2, v2, v27
     f04:      	fsub.4s	v26, v3, v27
     f08:      	fcmge.4s	v3, v26, v30
     f0c:      	fcmge.4s	v4, v2, v30
     f10:      	fcmge.4s	v20, v29, v26
     f14:      	fcmge.4s	v21, v29, v2
     f18:      	and.16b	v4, v4, v21
     f1c:      	and.16b	v3, v3, v20
     f20:      	and.16b	v3, v3, v26
     f24:      	and.16b	v4, v4, v2
     f28:      	fmul.4s	v20, v4, v9
     f2c:      	fmul.4s	v21, v3, v9
     f30:      	movi.4s	v7, #0x4b, lsl #24
     f34:      	mvni.4s	v23, #0x80, lsl #24
     f38:      	mov.16b	v22, v23
     f3c:      	bsl.16b	v22, v7, v21
     f40:      	movi.4s	v16, #0x4b, lsl #24
     f44:      	mvni.4s	v17, #0x80, lsl #24
     f48:      	bsl.16b	v23, v7, v20
     f4c:      	fadd.4s	v20, v20, v23
     f50:      	fadd.4s	v21, v21, v22
     f54:      	fsub.4s	v21, v21, v22
     f58:      	fsub.4s	v20, v20, v23
     f5c:      	fcvtzs.4s	v20, v20
     f60:      	fcvtzs.4s	v21, v21
     f64:      	scvtf.4s	v22, v21
     f68:      	scvtf.4s	v23, v20
     f6c:      	fmul.4s	v24, v22, v8
     f70:      	fadd.4s	v3, v3, v24
     f74:      	fmul.4s	v24, v23, v8
     f78:      	fadd.4s	v4, v4, v24
     f7c:      	add.2d	v24, v1, v19
     f80:      	add.2d	v24, v24, v0
     f84:      	mov.d	x20, v24[1]
     f88:      	fmul.4s	v22, v22, v12
     f8c:      	fmul.4s	v23, v23, v12
     f90:      	fadd.4s	v4, v4, v23
     f94:      	fadd.4s	v3, v3, v22
     f98:      	fmul.4s	v22, v3, v6
     f9c:      	fmul.4s	v23, v4, v6
     fa0:      	fadd.4s	v23, v23, v5
     fa4:      	fadd.4s	v22, v22, v5
     fa8:      	fmul.4s	v22, v3, v22
     fac:      	fmul.4s	v23, v4, v23
     fb0:      	fadd.4s	v23, v23, v15
     fb4:      	fadd.4s	v22, v22, v15
     fb8:      	fmul.4s	v22, v3, v22
     fbc:      	fmul.4s	v23, v4, v23
     fc0:      	fadd.4s	v23, v23, v14
     fc4:      	fadd.4s	v22, v22, v14
     fc8:      	fmul.4s	v22, v3, v22
     fcc:      	fmul.4s	v23, v4, v23
     fd0:      	fadd.4s	v23, v23, v13
     fd4:      	fadd.4s	v22, v22, v13
     fd8:      	fmov	x10, d24
     fdc:      	fmul.4s	v22, v3, v22
     fe0:      	fmul.4s	v23, v4, v23
     fe4:      	movi.4s	v24, #0x3f, lsl #24
     fe8:      	fadd.4s	v23, v23, v24
     fec:      	movi.4s	v7, #0x3f, lsl #24
     ff0:      	fadd.4s	v22, v22, v24
     ff4:      	fmul.4s	v24, v3, v3
     ff8:      	fmul.4s	v22, v24, v22
     ffc:      	fmul.4s	v24, v4, v4
    1000:      	fmul.4s	v23, v24, v23
    1004:      	fadd.4s	v4, v4, v23
    1008:      	fadd.4s	v3, v3, v22
    100c:      	sshr.4s	v22, v21, #0x1
    1010:      	fadd.4s	v4, v4, v31
    1014:      	sshr.4s	v23, v20, #0x1
    1018:      	shl.4s	v24, v23, #0x17
    101c:      	add.4s	v24, v24, v31
    1020:      	fmul.4s	v4, v4, v24
    1024:      	shl.4s	v24, v22, #0x17
    1028:      	fadd.4s	v3, v3, v31
    102c:      	add.4s	v24, v24, v31
    1030:      	fmul.4s	v3, v3, v24
    1034:      	sub.4s	v20, v20, v23
    1038:      	sub.4s	v21, v21, v22
    103c:      	shl.4s	v21, v21, #0x17
    1040:      	add.4s	v21, v21, v31
    1044:      	fmul.4s	v3, v3, v21
    1048:      	ldr	b21, [x19]
    104c:      	ld1.b	{ v21 }[1], [x16]
    1050:      	ld1.b	{ v21 }[2], [x5]
    1054:      	ld1.b	{ v21 }[3], [x8]
    1058:      	shl.4s	v20, v20, #0x17
    105c:      	add.4s	v20, v20, v31
    1060:      	fmul.4s	v4, v4, v20
    1064:      	fcmgt.4s	v20, v30, v2
    1068:      	bic.16b	v4, v4, v20
    106c:      	fcmgt.4s	v20, v30, v26
    1070:      	bic.16b	v3, v3, v20
    1074:      	fcmgt.4s	v20, v26, v29
    1078:      	bit.16b	v3, v10, v20
    107c:      	fcmgt.4s	v20, v2, v29
    1080:      	bit.16b	v4, v10, v20
    1084:      	ld1.b	{ v21 }[4], [x21]
    1088:      	ld1.b	{ v21 }[5], [x23]
    108c:      	fcmeq.4s	v2, v2, v2
    1090:      	bsl.16b	v2, v4, v11
    1094:      	ld1.b	{ v21 }[6], [x10]
    1098:      	ld1.b	{ v21 }[7], [x20]
    109c:      	cmeq.8b	v4, v21, #0
    10a0:      	sshll.8h	v4, v4, #0x0
    10a4:      	fcmeq.4s	v20, v26, v26
    10a8:      	bif.16b	v3, v11, v20
    10ac:      	sshll.4s	v20, v4, #0x0
    10b0:      	bic.16b	v3, v3, v20
    10b4:      	sshll2.4s	v4, v4, #0x0
    10b8:      	bic.16b	v2, v2, v4
    10bc:      	add	x8, x22, x7
    10c0:      	stp	q3, q2, [x8]
    10c4:      	dup.2d	v2, x6
    10c8:      	add.2d	v18, v18, v2
    10cc:      	add.2d	v25, v25, v2
    10d0:      	add.2d	v1, v1, v2
    10d4:      	add.2d	v28, v28, v2
    10d8:      	fmov	x7, d28
    10dc:      	cmp	x7, #0x200
    10e0:      	b.lt	0xeb8 <ltmp0+0xeb8>
    10e4:      	mov	x8, #0x0                ; =0
    10e8:      	ldr	b1, [x30]
    10ec:      	cmeq.8b	v1, v1, #0
    10f0:      	sshll.8h	v1, v1, #0x0
    10f4:      	sshll.4s	v1, v1, #0x0
    10f8:      	ldr	q2, [x15]
    10fc:      	ldr	q3, [sp, #0x460]
    1100:      	fsub.4s	v2, v2, v3
    1104:      	movi.2d	v3, #0000000000000000
    1108:      	mov.s	v3[0], v2[0]
    110c:      	fcmge.4s	v2, v3, v30
    1110:      	fcmge.4s	v4, v29, v3
    1114:      	and.16b	v2, v2, v4
    1118:      	and.16b	v2, v2, v3
    111c:      	fmul.4s	v4, v2, v9
    1120:      	mov.16b	v18, v17
    1124:      	bsl.16b	v18, v16, v4
    1128:      	fadd.4s	v4, v4, v18
    112c:      	fsub.4s	v4, v4, v18
    1130:      	fcvtzs.4s	v4, v4
    1134:      	scvtf.4s	v18, v4
    1138:      	fmul.4s	v20, v18, v8
    113c:      	fadd.4s	v2, v2, v20
    1140:      	fmul.4s	v18, v18, v12
    1144:      	fadd.4s	v2, v2, v18
    1148:      	fmul.4s	v18, v2, v6
    114c:      	fadd.4s	v18, v18, v5
    1150:      	fmul.4s	v18, v2, v18
    1154:      	fadd.4s	v18, v18, v15
    1158:      	fmul.4s	v18, v2, v18
    115c:      	fadd.4s	v18, v18, v14
    1160:      	fmul.4s	v18, v2, v18
    1164:      	fadd.4s	v18, v18, v13
    1168:      	fmul.4s	v18, v2, v18
    116c:      	fadd.4s	v18, v18, v7
    1170:      	fmul.4s	v20, v2, v2
    1174:      	fmul.4s	v18, v20, v18
    1178:      	fadd.4s	v2, v2, v18
    117c:      	fadd.4s	v2, v2, v31
    1180:      	sshr.4s	v18, v4, #0x1
    1184:      	shl.4s	v20, v18, #0x17
    1188:      	add.4s	v20, v20, v31
    118c:      	fmul.4s	v2, v2, v20
    1190:      	sub.4s	v4, v4, v18
    1194:      	shl.4s	v4, v4, #0x17
    1198:      	add.4s	v4, v4, v31
    119c:      	fmul.4s	v2, v2, v4
    11a0:      	fcmgt.4s	v4, v30, v3
    11a4:      	bic.16b	v2, v2, v4
    11a8:      	fcmgt.4s	v4, v3, v29
    11ac:      	bit.16b	v2, v10, v4
    11b0:      	fcmeq.4s	v3, v3, v3
    11b4:      	bif.16b	v2, v11, v3
    11b8:      	bic.16b	v2, v2, v1
    11bc:      	ldr	q1, [x13, x11]
    11c0:      	mov.s	v1[0], v2[0]
    11c4:      	str	q1, [x13, x11]
    11c8:      	ldp	q2, q3, [x15, #0x20]
    11cc:      	ldp	q21, q22, [x15, #0x40]
    11d0:      	ldp	q25, q4, [x15, #0x60]
    11d4:      	ldp	q18, q20, [x15, #0x80]
    11d8:      	mov.16b	v8, v10
    11dc:      	mov.16b	v9, v11
    11e0:      	add	x10, x27, x8, lsl #5
    11e4:      	ldp	q23, q24, [x10, #-0x40]
    11e8:      	fadd.4s	v3, v3, v24
    11ec:      	fadd.4s	v2, v2, v23
    11f0:      	ldp	q23, q24, [x10, #-0x20]
    11f4:      	fadd.4s	v22, v22, v24
    11f8:      	fadd.4s	v21, v21, v23
    11fc:      	ldp	q23, q24, [x10]
    1200:      	fadd.4s	v4, v4, v24
    1204:      	fadd.4s	v25, v25, v23
    1208:      	ldp	q23, q24, [x10, #0x20]
    120c:      	fadd.4s	v20, v20, v24
    1210:      	fadd.4s	v18, v18, v23
    1214:      	add	x8, x8, #0x4
    1218:      	cmp	x8, #0x1fc
    121c:      	b.lo	0x11e0 <ltmp0+0x11e0>
    1220:      	mov	x8, #0x0                ; =0
    1224:      	fadd.4s	v1, v1, v2
    1228:      	mov.s	v2[0], v1[0]
    122c:      	fadd.4s	v1, v22, v3
    1230:      	fadd.4s	v2, v21, v2
    1234:      	fadd.4s	v2, v25, v2
    1238:      	fadd.4s	v1, v4, v1
    123c:      	fadd.4s	v1, v20, v1
    1240:      	fadd.4s	v2, v18, v2
    1244:      	rev64.4s	v3, v2
    1248:      	rev64.4s	v4, v1
    124c:      	fadd.4s	v1, v1, v4
    1250:      	fadd.4s	v2, v2, v3
    1254:      	dup.4s	v3, v2[2]
    1258:      	dup.4s	v4, v1[2]
    125c:      	fadd.4s	v1, v1, v4
    1260:      	fadd.4s	v2, v2, v3
    1264:      	fadd.4s	v1, v2, v1
    1268:      	movi	d2, #0000000000000000
    126c:      	fadd	s1, s1, s2
    1270:      	dup.4s	v2, v1[0]
    1274:      	ldp	q23, q5, [sp, #0x3b0]
    1278:      	ldr	q27, [sp, #0x3e0]
    127c:      	ldr	q26, [sp, #0x390]
    1280:      	ldr	q11, [sp, #0x4a0]
    1284:      	ldr	q7, [sp, #0x490]
    1288:      	ldr	q16, [sp, #0x480]
    128c:      	ldr	q17, [sp, #0x470]
    1290:      	add	x10, x22, x8
    1294:      	ldp	q4, q3, [x10]
    1298:      	fdiv.4s	v4, v4, v2
    129c:      	fdiv.4s	v3, v3, v2
    12a0:      	add	x10, x28, x8
    12a4:      	stp	q4, q3, [x10]
    12a8:      	add	x8, x8, #0x20
    12ac:      	cmp	x8, #0x4, lsl #12       ; =0x4000
    12b0:      	b.ne	0x1290 <ltmp0+0x1290>
    12b4:      	ldr	q2, [x13, x11]
    12b8:      	fdiv.4s	v1, v2, v1
    12bc:      	str	s1, [x2, x17]
    12c0:      	add	x12, x12, #0x1
    12c4:      	add	x25, x25, x4
    12c8:      	add	x28, x28, x4
    12cc:      	cmp	x12, x9
    12d0:      	ldr	q24, [sp, #0x3f0]
    12d4:      	ldr	q25, [sp, #0x3a0]
    12d8:      	b.ne	0xb20 <ltmp0+0xb20>
    12dc:      	ldr	x8, [sp, #0x370]
    12e0:      	and	w8, w8, #0x7
    12e4:      	ldr	x2, [sp, #0x228]
    12e8:      	cbz	w8, 0xf4 <ltmp0+0xf4>
    12ec:      	dup.4s	v2, w8
    12f0:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    12f4:      	ldr	q3, [x8]
    12f8:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    12fc:      	ldr	q4, [x8]
    1300:      	cmhi.4s	v13, v2, v4
    1304:      	cmhi.4s	v14, v2, v3
    1308:      	uzp1.8h	v1, v14, v13
    130c:      	umaxv.8h	h0, v1
    1310:      	fmov	w8, s0
    1314:      	tbz	w8, #0x0, 0xf4 <ltmp0+0xf4>
    1318:      	stp	q3, q2, [sp, #0x2d0]
    131c:      	mov	x13, #0x0               ; =0
    1320:      	ldr	x15, [x2, #0x88]
    1324:      	mov	w8, #0x10a8             ; =4264
    1328:      	movk	w8, #0x1, lsl #16
    132c:      	add	x8, x15, x8
    1330:      	str	x8, [sp, #0x138]
    1334:      	mov	w8, #0xd088             ; =53384
    1338:      	add	x24, x15, x8
    133c:      	mov	w8, #0x4020             ; =16416
    1340:      	add	x10, x15, x8
    1344:      	mov	w8, #0xc060             ; =49248
    1348:      	add	x8, x15, x8
    134c:      	dup.2d	v0, x8
    1350:      	str	q0, [sp, #0x3c0]
    1354:      	mov	w8, #0xd068             ; =53352
    1358:      	add	x30, x15, x8
    135c:      	mov	w8, #0x1088             ; =4232
    1360:      	movk	w8, #0x1, lsl #16
    1364:      	add	x25, x15, x8
    1368:      	ldr	x8, [sp, #0x230]
    136c:      	ldr	x12, [x8]
    1370:      	ldr	x8, [x8, #0x30]
    1374:      	str	x8, [sp, #0x1b8]
    1378:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    137c:      	ldr	q0, [x8]
    1380:      	str	q1, [sp, #0x120]
    1384:      	and.16b	v0, v1, v0
    1388:      	addv.8h	h19, v0
    138c:      	ldr	x8, [sp, #0x278]
    1390:      	ubfiz	w8, w8, #2, #27
    1394:      	orr	w8, w8, w9
    1398:      	fmov	w9, s19
    139c:      	and	w9, w9, #0xff
    13a0:      	str	w9, [sp, #0x134]
    13a4:      	dup.4s	v0, w8
    13a8:      	and.16b	v1, v14, v0
    13ac:      	and.16b	v0, v13, v0
    13b0:      	ushll2.2d	v22, v0, #0x0
    13b4:      	ushll2.2d	v23, v1, #0x0
    13b8:      	str	q0, [sp, #0x380]
    13bc:      	ushll.2d	v10, v0, #0x0
    13c0:      	str	q1, [sp, #0x460]
    13c4:      	ushll.2d	v0, v1, #0x0
    13c8:      	fmov	x8, d0
    13cc:      	umaddl	x9, w8, w4, x12
    13d0:      	b	0x13f4 <ltmp0+0x13f4>
    13d4:      	add	x8, x15, x13
    13d8:      	ldp	q2, q3, [x8]
    13dc:      	bit.16b	v3, v18, v13
    13e0:      	bif.16b	v1, v2, v14
    13e4:      	stp	q1, q3, [x8]
    13e8:      	add	x13, x13, #0x20
    13ec:      	cmp	x13, #0x4, lsl #12      ; =0x4000
    13f0:      	b.eq	0x148c <ltmp0+0x148c>
    13f4:      	fmov	w16, s19
    13f8:      	add	x8, x9, x13
    13fc:      	movi.2d	v1, #0000000000000000
    1400:      	movi.2d	v18, #0000000000000000
    1404:      	tbnz	w16, #0x0, 0x142c <ltmp0+0x142c>
    1408:      	and	w16, w16, #0xff
    140c:      	tbnz	w16, #0x1, 0x1438 <ltmp0+0x1438>
    1410:      	tbnz	w16, #0x2, 0x1444 <ltmp0+0x1444>
    1414:      	tbnz	w16, #0x3, 0x1450 <ltmp0+0x1450>
    1418:      	tbnz	w16, #0x4, 0x145c <ltmp0+0x145c>
    141c:      	tbnz	w16, #0x5, 0x1468 <ltmp0+0x1468>
    1420:      	tbnz	w16, #0x6, 0x1474 <ltmp0+0x1474>
    1424:      	tbz	w16, #0x7, 0x13d4 <ltmp0+0x13d4>
    1428:      	b	0x1480 <ltmp0+0x1480>
    142c:      	ldr	s1, [x8]
    1430:      	and	w16, w16, #0xff
    1434:      	tbz	w16, #0x1, 0x1410 <ltmp0+0x1410>
    1438:      	add	x17, x8, #0x4
    143c:      	ld1.s	{ v1 }[1], [x17]
    1440:      	tbz	w16, #0x2, 0x1414 <ltmp0+0x1414>
    1444:      	add	x17, x8, #0x8
    1448:      	ld1.s	{ v1 }[2], [x17]
    144c:      	tbz	w16, #0x3, 0x1418 <ltmp0+0x1418>
    1450:      	add	x17, x8, #0xc
    1454:      	ld1.s	{ v1 }[3], [x17]
    1458:      	tbz	w16, #0x4, 0x141c <ltmp0+0x141c>
    145c:      	add	x17, x8, #0x10
    1460:      	ld1.s	{ v18 }[0], [x17]
    1464:      	tbz	w16, #0x5, 0x1420 <ltmp0+0x1420>
    1468:      	add	x17, x8, #0x14
    146c:      	ld1.s	{ v18 }[1], [x17]
    1470:      	tbz	w16, #0x6, 0x1424 <ltmp0+0x1424>
    1474:      	add	x17, x8, #0x18
    1478:      	ld1.s	{ v18 }[2], [x17]
    147c:      	tbz	w16, #0x7, 0x13d4 <ltmp0+0x13d4>
    1480:      	add	x8, x8, #0x1c
    1484:      	ld1.s	{ v18 }[3], [x8]
    1488:      	b	0x13d4 <ltmp0+0x13d4>
    148c:      	str	q4, [sp, #0x2b0]
    1490:      	xtn.4h	v1, v14
    1494:      	uzp1.8b	v2, v1, v0
    1498:      	sshll.2d	v1, v14, #0x0
    149c:      	and.16b	v6, v1, v25
    14a0:      	movi.2d	v4, #0000000000000000
    14a4:      	mov.b	v4[0], v2[0]
    14a8:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    14ac:      	ldr	d3, [x8]
    14b0:      	str	d3, [sp, #0x2a0]
    14b4:      	and.8b	v3, v4, v3
    14b8:      	addv.8b	b3, v3
    14bc:      	fmov	w9, s3
    14c0:      	str	q4, [sp, #0x250]
    14c4:      	umaxv.8b	b3, v4
    14c8:      	fmov	w13, s3
    14cc:      	rbit	w8, w9
    14d0:      	clz	w8, w8
    14d4:      	tst	w13, #0x1
    14d8:      	csel	w19, w8, wzr, ne
    14dc:      	mov	w8, #0x1000             ; =4096
    14e0:      	dup.2d	v26, x8
    14e4:      	str	q6, [sp, #0x90]
    14e8:      	orr.16b	v4, v6, v26
    14ec:      	mov	w8, #0x1001             ; =4097
    14f0:      	dup.2s	v25, w8
    14f4:      	xtn.2s	v0, v0
    14f8:      	str	q4, [sp, #0x370]
    14fc:      	umlal.2d	v4, v0, v25
    1500:      	movi.2d	v3, #0000000000000000
    1504:      	mov.b	v3[0], v2[0]
    1508:      	ushll.2d	v2, v3, #0x0
    150c:      	shl.2d	v2, v2, #0x3f
    1510:      	cmlt.2d	v2, v2, #0
    1514:      	str	q4, [sp, #0x1a0]
    1518:      	and.16b	v2, v2, v4
    151c:      	movi.2d	v3, #0000000000000000
    1520:      	str	q3, [sp, #0xb30]
    1524:      	str	q3, [sp, #0xb20]
    1528:      	str	q3, [sp, #0xb10]
    152c:      	str	q2, [sp, #0xb00]
    1530:      	and	x8, x19, #0x7
    1534:      	add	x16, sp, #0xb00
    1538:      	ldr	x8, [x16, x8, lsl #3]
    153c:      	sub	x8, x8, x19
    1540:      	add	x8, x12, x8, lsl #2
    1544:      	movi.2d	v18, #0000000000000000
    1548:      	movi.2d	v28, #0000000000000000
    154c:      	tbnz	w13, #0x0, 0x1cec <ltmp0+0x1cec>
    1550:      	tbnz	w9, #0x1, 0x1cf4 <ltmp0+0x1cf4>
    1554:      	tbnz	w9, #0x2, 0x1d00 <ltmp0+0x1d00>
    1558:      	tbnz	w9, #0x3, 0x1d0c <ltmp0+0x1d0c>
    155c:      	tbnz	w9, #0x4, 0x1d18 <ltmp0+0x1d18>
    1560:      	tbnz	w9, #0x5, 0x1d24 <ltmp0+0x1d24>
    1564:      	tbnz	w9, #0x6, 0x1d30 <ltmp0+0x1d30>
    1568:      	str	q19, [sp, #0x1f0]
    156c:      	tbz	w9, #0x7, 0x1578 <ltmp0+0x1578>
    1570:      	add	x8, x8, #0x1c
    1574:      	ld1.s	{ v28 }[3], [x8]
    1578:      	mov	x8, #0x0                ; =0
    157c:      	sshll.2d	v2, v13, #0x0
    1580:      	sshll2.2d	v6, v14, #0x0
    1584:      	sshll2.2d	v12, v13, #0x0
    1588:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    158c:      	ldr	q3, [x12]
    1590:      	and.16b	v3, v12, v3
    1594:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    1598:      	ldr	q4, [x12]
    159c:      	and.16b	v4, v6, v4
    15a0:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    15a4:      	ldr	q20, [x12]
    15a8:      	and.16b	v20, v2, v20
    15ac:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    15b0:      	ldr	q21, [x12]
    15b4:      	and.16b	v1, v1, v21
    15b8:      	str	q1, [sp, #0x2f0]
    15bc:      	str	q1, [sp, #0xac0]
    15c0:      	str	q4, [sp, #0xad0]
    15c4:      	str	q20, [sp, #0xae0]
    15c8:      	str	q3, [sp, #0xaf0]
    15cc:      	and	x12, x19, #0x7
    15d0:      	add	x13, sp, #0xac0
    15d4:      	ldr	x12, [x13, x12, lsl #3]
    15d8:      	orr	x12, x12, #0x4000
    15dc:      	sub	x12, x12, x19, lsl #2
    15e0:      	tst	w9, #0xff
    15e4:      	csel	x20, xzr, x12, eq
    15e8:      	add	x12, x15, x20
    15ec:      	ldp	q1, q3, [x12]
    15f0:      	ldr	q19, [sp, #0x250]
    15f4:      	zip2.8b	v4, v19, v0
    15f8:      	ushll.4s	v4, v4, #0x0
    15fc:      	shl.4s	v4, v4, #0x1f
    1600:      	cmlt.4s	v4, v4, #0
    1604:      	bit.16b	v3, v28, v4
    1608:      	zip1.8b	v4, v19, v0
    160c:      	ushll.4s	v4, v4, #0x0
    1610:      	shl.4s	v4, v4, #0x1f
    1614:      	cmlt.4s	v4, v4, #0
    1618:      	bit.16b	v1, v18, v4
    161c:      	stp	q1, q3, [x12]
    1620:      	ldr	q30, [sp, #0x3b0]
    1624:      	and.16b	v1, v12, v30
    1628:      	and.16b	v3, v6, v27
    162c:      	and.16b	v2, v2, v24
    1630:      	stp	q2, q3, [sp, #0x50]
    1634:      	orr.16b	v4, v2, v26
    1638:      	orr.16b	v18, v3, v26
    163c:      	str	q1, [sp, #0x70]
    1640:      	orr.16b	v3, v1, v26
    1644:      	umull.2d	v0, v0, v25
    1648:      	str	q0, [sp, #0x140]
    164c:      	xtn.2s	v0, v23
    1650:      	xtn.2s	v1, v10
    1654:      	xtn.2s	v2, v22
    1658:      	str	q3, [sp, #0x300]
    165c:      	umlal.2d	v3, v2, v25
    1660:      	str	q18, [sp, #0x290]
    1664:      	mov.16b	v2, v18
    1668:      	umlal.2d	v2, v0, v25
    166c:      	stp	q2, q3, [sp, #0x170]
    1670:      	str	q4, [sp, #0x330]
    1674:      	mov.16b	v0, v4
    1678:      	umlal.2d	v0, v1, v25
    167c:      	str	q0, [sp, #0x160]
    1680:      	dup.2d	v0, x6
    1684:      	ushll2.2d	v1, v13, #0x0
    1688:      	and.16b	v19, v1, v0
    168c:      	ushll2.2d	v1, v14, #0x0
    1690:      	and.16b	v15, v1, v0
    1694:      	ushll.2d	v1, v13, #0x0
    1698:      	and.16b	v10, v1, v0
    169c:      	ushll.2d	v1, v14, #0x0
    16a0:      	and.16b	v9, v1, v0
    16a4:      	movi.2d	v0, #0000000000000000
    16a8:      	movi.2d	v1, #0000000000000000
    16ac:      	movi.2d	v2, #0000000000000000
    16b0:      	movi.2d	v3, #0000000000000000
    16b4:      	ldr	q28, [sp, #0x3a0]
    16b8:      	sshll.2d	v4, v13, #0x0
    16bc:      	sshll.2d	v18, v14, #0x0
    16c0:      	shl.2d	v20, v3, #0x3
    16c4:      	shl.2d	v21, v0, #0x3
    16c8:      	shl.2d	v22, v2, #0x3
    16cc:      	shl.2d	v23, v1, #0x3
    16d0:      	orr.16b	v23, v23, v27
    16d4:      	orr.16b	v22, v22, v24
    16d8:      	orr.16b	v21, v21, v28
    16dc:      	orr.16b	v20, v20, v30
    16e0:      	add	x8, x10, x8, lsl #6
    16e4:      	ldp	q25, q24, [x8]
    16e8:      	ldp	q26, q27, [x8, #0x20]
    16ec:      	bif.16b	v20, v27, v12
    16f0:      	bsl.16b	v18, v21, v25
    16f4:      	bsl.16b	v4, v22, v26
    16f8:      	mov.16b	v21, v6
    16fc:      	bsl.16b	v21, v23, v24
    1700:      	ldp	q27, q24, [sp, #0x3e0]
    1704:      	stp	q18, q21, [x8]
    1708:      	stp	q4, q20, [x8, #0x20]
    170c:      	add.2d	v1, v1, v15
    1710:      	add.2d	v2, v2, v10
    1714:      	add.2d	v3, v3, v19
    1718:      	add.2d	v0, v0, v9
    171c:      	fmov	x8, d0
    1720:      	cmp	x8, #0x200
    1724:      	b.lt	0x16b8 <ltmp0+0x16b8>
    1728:      	mov	x12, #0x0               ; =0
    172c:      	mov	w8, #0x1001             ; =4097
    1730:      	dup.4s	v0, w8
    1734:      	and.16b	v1, v14, v0
    1738:      	mvn.16b	v2, v14
    173c:      	sub.4s	v1, v1, v2
    1740:      	and.16b	v0, v13, v0
    1744:      	mvn.16b	v2, v13
    1748:      	sub.4s	v0, v0, v2
    174c:      	mov.s	w8, v0[1]
    1750:      	ldr	q2, [sp, #0x380]
    1754:      	mov.s	w13, v2[1]
    1758:      	udiv	w16, w13, w8
    175c:      	msub	w13, w16, w8, w13
    1760:      	mov.s	w8, v0[2]
    1764:      	mov.s	w16, v0[3]
    1768:      	fmov	w17, s0
    176c:      	fmov	w0, s2
    1770:      	udiv	w1, w0, w17
    1774:      	msub	w17, w1, w17, w0
    1778:      	mov.s	w0, v2[2]
    177c:      	udiv	w1, w0, w8
    1780:      	msub	w0, w1, w8, w0
    1784:      	mov.s	w8, v2[3]
    1788:      	udiv	w1, w8, w16
    178c:      	msub	w16, w1, w16, w8
    1790:      	mov.s	w8, v1[1]
    1794:      	ldr	q0, [sp, #0x460]
    1798:      	mov.s	w1, v0[1]
    179c:      	udiv	w2, w1, w8
    17a0:      	msub	w1, w2, w8, w1
    17a4:      	mov.s	w8, v1[2]
    17a8:      	mov.s	w2, v1[3]
    17ac:      	fmov	w3, s1
    17b0:      	fmov	w5, s0
    17b4:      	udiv	w7, w5, w3
    17b8:      	msub	w3, w7, w3, w5
    17bc:      	mov.s	w5, v0[2]
    17c0:      	udiv	w7, w5, w8
    17c4:      	msub	w8, w7, w8, w5
    17c8:      	mov.s	w5, v0[3]
    17cc:      	udiv	w7, w5, w2
    17d0:      	msub	w2, w7, w2, w5
    17d4:      	tst	w9, #0xff
    17d8:      	fmov	s2, w17
    17dc:      	mov.s	v2[1], w13
    17e0:      	mov.s	v2[2], w0
    17e4:      	mov.s	v2[3], w16
    17e8:      	sshll.2d	v0, v13, #0x0
    17ec:      	sshll.2d	v1, v14, #0x0
    17f0:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    17f4:      	ldr	q3, [x9]
    17f8:      	and.16b	v3, v1, v3
    17fc:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1800:      	ldr	q4, [x9]
    1804:      	and.16b	v4, v0, v4
    1808:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    180c:      	ldr	q18, [x9]
    1810:      	and.16b	v18, v6, v18
    1814:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1818:      	ldr	q20, [x9]
    181c:      	and.16b	v20, v12, v20
    1820:      	str	q20, [sp, #0xab0]
    1824:      	str	q4, [sp, #0xaa0]
    1828:      	str	q18, [sp, #0xa90]
    182c:      	str	q3, [sp, #0xa80]
    1830:      	fmov	s3, w3
    1834:      	and	x9, x19, #0x7
    1838:      	add	x13, sp, #0xa80
    183c:      	ldr	x9, [x13, x9, lsl #3]
    1840:      	orr	x9, x9, #0x8000
    1844:      	sub	x9, x9, x19, lsl #3
    1848:      	csel	x9, xzr, x9, eq
    184c:      	mov.s	v3[1], w1
    1850:      	add	x13, x10, x9
    1854:      	ldp	q4, q18, [x13, #0x20]
    1858:      	ldp	q20, q21, [x13]
    185c:      	ldr	q24, [sp, #0x250]
    1860:      	mov	b22, v24[2]
    1864:      	mov.b	v22[4], v24[3]
    1868:      	ushll.2d	v22, v22, #0x0
    186c:      	shl.2d	v22, v22, #0x3f
    1870:      	cmlt.2d	v22, v22, #0
    1874:      	ldr	q23, [sp, #0x290]
    1878:      	bit.16b	v21, v23, v22
    187c:      	mov	b22, v24[0]
    1880:      	mov.b	v22[4], v24[1]
    1884:      	ushll.2d	v22, v22, #0x0
    1888:      	shl.2d	v22, v22, #0x3f
    188c:      	cmlt.2d	v22, v22, #0
    1890:      	mov	b23, v24[6]
    1894:      	mov.b	v23[4], v24[7]
    1898:      	ldr	q25, [sp, #0x370]
    189c:      	bit.16b	v20, v25, v22
    18a0:      	ushll.2d	v22, v23, #0x0
    18a4:      	shl.2d	v22, v22, #0x3f
    18a8:      	cmlt.2d	v22, v22, #0
    18ac:      	ldr	q23, [sp, #0x300]
    18b0:      	bit.16b	v18, v23, v22
    18b4:      	mov	b22, v24[4]
    18b8:      	mov.b	v22[4], v24[5]
    18bc:      	ushll.2d	v22, v22, #0x0
    18c0:      	shl.2d	v22, v22, #0x3f
    18c4:      	cmlt.2d	v22, v22, #0
    18c8:      	ldr	q23, [sp, #0x330]
    18cc:      	bit.16b	v4, v23, v22
    18d0:      	mov.s	v3[2], w8
    18d4:      	mov.s	v3[3], w2
    18d8:      	and.16b	v3, v14, v3
    18dc:      	stp	q4, q18, [x13, #0x20]
    18e0:      	stp	q20, q21, [x13]
    18e4:      	and.16b	v2, v13, v2
    18e8:      	ushll2.2d	v4, v2, #0x0
    18ec:      	str	q4, [sp, #0x330]
    18f0:      	ushll2.2d	v18, v3, #0x0
    18f4:      	ushll.2d	v2, v2, #0x0
    18f8:      	str	q2, [sp, #0x300]
    18fc:      	ushll.2d	v25, v3, #0x0
    1900:      	ldr	q4, [sp, #0x3c0]
    1904:      	and.16b	v27, v12, v4
    1908:      	and.16b	v3, v6, v4
    190c:      	and.16b	v2, v0, v4
    1910:      	str	q2, [sp, #0x460]
    1914:      	and.16b	v4, v1, v4
    1918:      	stp	q12, q6, [sp, #0x1d0]
    191c:      	and.16b	v12, v12, v17
    1920:      	and.16b	v2, v6, v7
    1924:      	str	q2, [sp, #0x3c0]
    1928:      	and.16b	v2, v0, v16
    192c:      	and.16b	v0, v1, v11
    1930:      	stp	q0, q2, [sp, #0x370]
    1934:      	ldp	q2, q1, [sp, #0x2d0]
    1938:      	ldr	q0, [sp, #0x2b0]
    193c:      	cmhs.4s	v0, v0, v1
    1940:      	cmhs.4s	v1, v2, v1
    1944:      	uzp1.8h	v0, v1, v0
    1948:      	xtn.8b	v26, v0
    194c:      	movi.2d	v28, #0000000000000000
    1950:      	movi.2d	v2, #0000000000000000
    1954:      	movi.2d	v0, #0000000000000000
    1958:      	movi.2d	v1, #0000000000000000
    195c:      	movi.8b	v22, #0x1
    1960:      	ldr	q30, [sp, #0x1f0]
    1964:      	mov.16b	v24, v9
    1968:      	mov.16b	v9, v4
    196c:      	mov.16b	v6, v3
    1970:      	b	0x1990 <ltmp0+0x1990>
    1974:      	add.2d	v2, v2, v15
    1978:      	add.2d	v0, v0, v10
    197c:      	add.2d	v1, v1, v19
    1980:      	add.2d	v28, v28, v24
    1984:      	fmov	x12, d28
    1988:      	cmp	x12, #0x200
    198c:      	b.ge	0x1ab0 <ltmp0+0x1ab0>
    1990:      	fmov	w8, s30
    1994:      	add	x12, x10, x12, lsl #6
    1998:      	ldp	q4, q3, [x12, #0x20]
    199c:      	ldp	q20, q21, [x12]
    19a0:      	cmge.2d	v21, v18, v21
    19a4:      	cmge.2d	v20, v25, v20
    19a8:      	uzp1.4s	v20, v20, v21
    19ac:      	ldr	q21, [sp, #0x300]
    19b0:      	cmge.2d	v4, v21, v4
    19b4:      	ldr	q21, [sp, #0x330]
    19b8:      	cmge.2d	v3, v21, v3
    19bc:      	uzp1.4s	v3, v4, v3
    19c0:      	uzp1.8h	v3, v20, v3
    19c4:      	xtn.8b	v3, v3
    19c8:      	orr.8b	v3, v26, v3
    19cc:      	ldr	q4, [sp, #0x370]
    19d0:      	add.2d	v4, v28, v4
    19d4:      	add.2d	v4, v9, v4
    19d8:      	and.8b	v3, v3, v22
    19dc:      	tbnz	w8, #0x0, 0x1a28 <ltmp0+0x1a28>
    19e0:      	and	w8, w8, #0xff
    19e4:      	tbnz	w8, #0x1, 0x1a38 <ltmp0+0x1a38>
    19e8:      	ldr	q4, [sp, #0x3c0]
    19ec:      	add.2d	v4, v2, v4
    19f0:      	add.2d	v4, v6, v4
    19f4:      	tbnz	w8, #0x2, 0x1a50 <ltmp0+0x1a50>
    19f8:      	tbnz	w8, #0x3, 0x1a5c <ltmp0+0x1a5c>
    19fc:      	ldr	q4, [sp, #0x380]
    1a00:      	add.2d	v4, v0, v4
    1a04:      	ldr	q20, [sp, #0x460]
    1a08:      	add.2d	v4, v20, v4
    1a0c:      	tbnz	w8, #0x4, 0x1a78 <ltmp0+0x1a78>
    1a10:      	tbnz	w8, #0x5, 0x1a84 <ltmp0+0x1a84>
    1a14:      	add.2d	v4, v1, v12
    1a18:      	add.2d	v4, v27, v4
    1a1c:      	tbnz	w8, #0x6, 0x1a98 <ltmp0+0x1a98>
    1a20:      	tbz	w8, #0x7, 0x1974 <ltmp0+0x1974>
    1a24:      	b	0x1aa4 <ltmp0+0x1aa4>
    1a28:      	fmov	x12, d4
    1a2c:      	str	b3, [x12]
    1a30:      	and	w8, w8, #0xff
    1a34:      	tbz	w8, #0x1, 0x19e8 <ltmp0+0x19e8>
    1a38:      	mov.d	x12, v4[1]
    1a3c:      	st1.b	{ v3 }[1], [x12]
    1a40:      	ldr	q4, [sp, #0x3c0]
    1a44:      	add.2d	v4, v2, v4
    1a48:      	add.2d	v4, v6, v4
    1a4c:      	tbz	w8, #0x2, 0x19f8 <ltmp0+0x19f8>
    1a50:      	fmov	x12, d4
    1a54:      	st1.b	{ v3 }[2], [x12]
    1a58:      	tbz	w8, #0x3, 0x19fc <ltmp0+0x19fc>
    1a5c:      	mov.d	x12, v4[1]
    1a60:      	st1.b	{ v3 }[3], [x12]
    1a64:      	ldr	q4, [sp, #0x380]
    1a68:      	add.2d	v4, v0, v4
    1a6c:      	ldr	q20, [sp, #0x460]
    1a70:      	add.2d	v4, v20, v4
    1a74:      	tbz	w8, #0x4, 0x1a10 <ltmp0+0x1a10>
    1a78:      	fmov	x12, d4
    1a7c:      	st1.b	{ v3 }[4], [x12]
    1a80:      	tbz	w8, #0x5, 0x1a14 <ltmp0+0x1a14>
    1a84:      	mov.d	x12, v4[1]
    1a88:      	st1.b	{ v3 }[5], [x12]
    1a8c:      	add.2d	v4, v1, v12
    1a90:      	add.2d	v4, v27, v4
    1a94:      	tbz	w8, #0x6, 0x1a20 <ltmp0+0x1a20>
    1a98:      	fmov	x12, d4
    1a9c:      	st1.b	{ v3 }[6], [x12]
    1aa0:      	tbz	w8, #0x7, 0x1974 <ltmp0+0x1974>
    1aa4:      	mov.d	x8, v4[1]
    1aa8:      	st1.b	{ v3 }[7], [x8]
    1aac:      	b	0x1974 <ltmp0+0x1974>
    1ab0:      	add	x8, x10, x9
    1ab4:      	ldp	q1, q0, [x8, #0x20]
    1ab8:      	ldp	q2, q3, [x8]
    1abc:      	cmge.2d	v3, v18, v3
    1ac0:      	cmge.2d	v2, v25, v2
    1ac4:      	uzp1.4s	v2, v2, v3
    1ac8:      	ldr	q3, [sp, #0x300]
    1acc:      	cmge.2d	v1, v3, v1
    1ad0:      	ldr	q3, [sp, #0x330]
    1ad4:      	cmge.2d	v0, v3, v0
    1ad8:      	uzp1.4s	v0, v1, v0
    1adc:      	uzp1.8h	v0, v2, v0
    1ae0:      	xtn.8b	v0, v0
    1ae4:      	ldr	q2, [sp, #0x250]
    1ae8:      	shl.8b	v1, v2, #0x7
    1aec:      	cmlt.8b	v1, v1, #0
    1af0:      	ldr	d3, [sp, #0x2a0]
    1af4:      	and.8b	v1, v1, v3
    1af8:      	addv.8b	b1, v1
    1afc:      	str	d1, [sp, #0x208]
    1b00:      	fmov	w8, s1
    1b04:      	orn.8b	v0, v0, v2
    1b08:      	ldr	q1, [sp, #0x370]
    1b0c:      	add.2d	v2, v1, v9
    1b10:      	mov	w9, #0x200              ; =512
    1b14:      	dup.2d	v1, x9
    1b18:      	add.2d	v2, v2, v1
    1b1c:      	and.8b	v0, v0, v22
    1b20:      	tbnz	w8, #0x0, 0x1d44 <ltmp0+0x1d44>
    1b24:      	str	q2, [sp, #0xe0]
    1b28:      	mov.d	x17, v2[1]
    1b2c:      	tbnz	w8, #0x1, 0x1d58 <ltmp0+0x1d58>
    1b30:      	ldr	q2, [sp, #0x3c0]
    1b34:      	add.2d	v2, v2, v6
    1b38:      	add.2d	v28, v2, v1
    1b3c:      	tbnz	w8, #0x2, 0x1d6c <ltmp0+0x1d6c>
    1b40:      	mov.d	x16, v28[1]
    1b44:      	tbnz	w8, #0x3, 0x1d7c <ltmp0+0x1d7c>
    1b48:      	ldr	q2, [sp, #0x460]
    1b4c:      	ldr	q3, [sp, #0x380]
    1b50:      	add.2d	v2, v3, v2
    1b54:      	add.2d	v22, v2, v1
    1b58:      	tbnz	w8, #0x4, 0x1d94 <ltmp0+0x1d94>
    1b5c:      	mov.d	x13, v22[1]
    1b60:      	tbnz	w8, #0x5, 0x1da4 <ltmp0+0x1da4>
    1b64:      	add.2d	v2, v12, v27
    1b68:      	add.2d	v21, v2, v1
    1b6c:      	tbnz	w8, #0x6, 0x1db4 <ltmp0+0x1db4>
    1b70:      	mov.d	x12, v21[1]
    1b74:      	tbz	w8, #0x7, 0x1b7c <ltmp0+0x1b7c>
    1b78:      	st1.b	{ v0 }[7], [x12]
    1b7c:      	mov	x9, #0x0                ; =0
    1b80:      	movi.2d	v0, #0000000000000000
    1b84:      	movi.2d	v1, #0000000000000000
    1b88:      	movi.2d	v18, #0000000000000000
    1b8c:      	movi.2d	v25, #0000000000000000
    1b90:      	b	0x1bf0 <ltmp0+0x1bf0>
    1b94:      	cmeq.8b	v2, v26, #0
    1b98:      	sshll.8h	v2, v2, #0x0
    1b9c:      	sshll2.4s	v3, v2, #0x0
    1ba0:      	sshll.4s	v2, v2, #0x0
    1ba4:      	lsl	x8, x9, #5
    1ba8:      	add	x9, x15, x8
    1bac:      	ldp	q4, q20, [x9]
    1bb0:      	and.16b	v20, v13, v20
    1bb4:      	and.16b	v4, v14, v4
    1bb8:      	bsl.16b	v2, v5, v4
    1bbc:      	bsl.16b	v3, v5, v20
    1bc0:      	add	x8, x30, x8
    1bc4:      	ldp	q4, q20, [x8]
    1bc8:      	bif.16b	v3, v20, v13
    1bcc:      	bif.16b	v2, v4, v14
    1bd0:      	stp	q2, q3, [x8]
    1bd4:      	add.2d	v1, v1, v15
    1bd8:      	add.2d	v18, v18, v10
    1bdc:      	add.2d	v25, v25, v19
    1be0:      	add.2d	v0, v0, v24
    1be4:      	fmov	x9, d0
    1be8:      	cmp	x9, #0x200
    1bec:      	b.ge	0x1ccc <ltmp0+0x1ccc>
    1bf0:      	fmov	w8, s30
    1bf4:      	ldr	q2, [sp, #0x370]
    1bf8:      	add.2d	v2, v0, v2
    1bfc:      	add.2d	v2, v9, v2
    1c00:      	tbz	w8, #0x0, 0x1c18 <ltmp0+0x1c18>
    1c04:      	fmov	x10, d2
    1c08:      	ldr	b26, [x10]
    1c0c:      	and	w8, w8, #0xff
    1c10:      	tbnz	w8, #0x1, 0x1c24 <ltmp0+0x1c24>
    1c14:      	b	0x1c2c <ltmp0+0x1c2c>
    1c18:      	movi.2d	v26, #0000000000000000
    1c1c:      	and	w8, w8, #0xff
    1c20:      	tbz	w8, #0x1, 0x1c2c <ltmp0+0x1c2c>
    1c24:      	mov.d	x10, v2[1]
    1c28:      	ld1.b	{ v26 }[1], [x10]
    1c2c:      	ldr	q2, [sp, #0x3c0]
    1c30:      	add.2d	v2, v1, v2
    1c34:      	add.2d	v2, v6, v2
    1c38:      	tbnz	w8, #0x2, 0x1c6c <ltmp0+0x1c6c>
    1c3c:      	tbnz	w8, #0x3, 0x1c78 <ltmp0+0x1c78>
    1c40:      	ldr	q2, [sp, #0x380]
    1c44:      	add.2d	v2, v18, v2
    1c48:      	ldr	q3, [sp, #0x460]
    1c4c:      	add.2d	v2, v3, v2
    1c50:      	tbnz	w8, #0x4, 0x1c94 <ltmp0+0x1c94>
    1c54:      	tbnz	w8, #0x5, 0x1ca0 <ltmp0+0x1ca0>
    1c58:      	add.2d	v2, v25, v12
    1c5c:      	add.2d	v2, v27, v2
    1c60:      	tbnz	w8, #0x6, 0x1cb4 <ltmp0+0x1cb4>
    1c64:      	tbz	w8, #0x7, 0x1b94 <ltmp0+0x1b94>
    1c68:      	b	0x1cc0 <ltmp0+0x1cc0>
    1c6c:      	fmov	x10, d2
    1c70:      	ld1.b	{ v26 }[2], [x10]
    1c74:      	tbz	w8, #0x3, 0x1c40 <ltmp0+0x1c40>
    1c78:      	mov.d	x10, v2[1]
    1c7c:      	ld1.b	{ v26 }[3], [x10]
    1c80:      	ldr	q2, [sp, #0x380]
    1c84:      	add.2d	v2, v18, v2
    1c88:      	ldr	q3, [sp, #0x460]
    1c8c:      	add.2d	v2, v3, v2
    1c90:      	tbz	w8, #0x4, 0x1c54 <ltmp0+0x1c54>
    1c94:      	fmov	x10, d2
    1c98:      	ld1.b	{ v26 }[4], [x10]
    1c9c:      	tbz	w8, #0x5, 0x1c58 <ltmp0+0x1c58>
    1ca0:      	mov.d	x10, v2[1]
    1ca4:      	ld1.b	{ v26 }[5], [x10]
    1ca8:      	add.2d	v2, v25, v12
    1cac:      	add.2d	v2, v27, v2
    1cb0:      	tbz	w8, #0x6, 0x1c64 <ltmp0+0x1c64>
    1cb4:      	fmov	x10, d2
    1cb8:      	ld1.b	{ v26 }[6], [x10]
    1cbc:      	tbz	w8, #0x7, 0x1b94 <ltmp0+0x1b94>
    1cc0:      	mov.d	x8, v2[1]
    1cc4:      	ld1.b	{ v26 }[7], [x8]
    1cc8:      	b	0x1b94 <ltmp0+0x1b94>
    1ccc:      	ldr	d0, [sp, #0x208]
    1cd0:      	fmov	w8, s0
    1cd4:      	tbz	w8, #0x0, 0x1dc8 <ltmp0+0x1dc8>
    1cd8:      	ldr	q0, [sp, #0xe0]
    1cdc:      	fmov	x9, d0
    1ce0:      	ldr	b0, [x9]
    1ce4:      	tbnz	w8, #0x1, 0x1dd0 <ltmp0+0x1dd0>
    1ce8:      	b	0x1dd4 <ltmp0+0x1dd4>
    1cec:      	ldr	s18, [x8]
    1cf0:      	tbz	w9, #0x1, 0x1554 <ltmp0+0x1554>
    1cf4:      	add	x12, x8, #0x4
    1cf8:      	ld1.s	{ v18 }[1], [x12]
    1cfc:      	tbz	w9, #0x2, 0x1558 <ltmp0+0x1558>
    1d00:      	add	x12, x8, #0x8
    1d04:      	ld1.s	{ v18 }[2], [x12]
    1d08:      	tbz	w9, #0x3, 0x155c <ltmp0+0x155c>
    1d0c:      	add	x12, x8, #0xc
    1d10:      	ld1.s	{ v18 }[3], [x12]
    1d14:      	tbz	w9, #0x4, 0x1560 <ltmp0+0x1560>
    1d18:      	add	x12, x8, #0x10
    1d1c:      	ld1.s	{ v28 }[0], [x12]
    1d20:      	tbz	w9, #0x5, 0x1564 <ltmp0+0x1564>
    1d24:      	add	x12, x8, #0x14
    1d28:      	ld1.s	{ v28 }[1], [x12]
    1d2c:      	tbz	w9, #0x6, 0x1568 <ltmp0+0x1568>
    1d30:      	add	x12, x8, #0x18
    1d34:      	ld1.s	{ v28 }[2], [x12]
    1d38:      	str	q19, [sp, #0x1f0]
    1d3c:      	tbnz	w9, #0x7, 0x1570 <ltmp0+0x1570>
    1d40:      	b	0x1578 <ltmp0+0x1578>
    1d44:      	fmov	x9, d2
    1d48:      	str	b0, [x9]
    1d4c:      	str	q2, [sp, #0xe0]
    1d50:      	mov.d	x17, v2[1]
    1d54:      	tbz	w8, #0x1, 0x1b30 <ltmp0+0x1b30>
    1d58:      	st1.b	{ v0 }[1], [x17]
    1d5c:      	ldr	q2, [sp, #0x3c0]
    1d60:      	add.2d	v2, v2, v6
    1d64:      	add.2d	v28, v2, v1
    1d68:      	tbz	w8, #0x2, 0x1b40 <ltmp0+0x1b40>
    1d6c:      	fmov	x9, d28
    1d70:      	st1.b	{ v0 }[2], [x9]
    1d74:      	mov.d	x16, v28[1]
    1d78:      	tbz	w8, #0x3, 0x1b48 <ltmp0+0x1b48>
    1d7c:      	st1.b	{ v0 }[3], [x16]
    1d80:      	ldr	q2, [sp, #0x460]
    1d84:      	ldr	q3, [sp, #0x380]
    1d88:      	add.2d	v2, v3, v2
    1d8c:      	add.2d	v22, v2, v1
    1d90:      	tbz	w8, #0x4, 0x1b5c <ltmp0+0x1b5c>
    1d94:      	fmov	x9, d22
    1d98:      	st1.b	{ v0 }[4], [x9]
    1d9c:      	mov.d	x13, v22[1]
    1da0:      	tbz	w8, #0x5, 0x1b64 <ltmp0+0x1b64>
    1da4:      	st1.b	{ v0 }[5], [x13]
    1da8:      	add.2d	v2, v12, v27
    1dac:      	add.2d	v21, v2, v1
    1db0:      	tbz	w8, #0x6, 0x1b70 <ltmp0+0x1b70>
    1db4:      	fmov	x9, d21
    1db8:      	st1.b	{ v0 }[6], [x9]
    1dbc:      	mov.d	x12, v21[1]
    1dc0:      	tbnz	w8, #0x7, 0x1b78 <ltmp0+0x1b78>
    1dc4:      	b	0x1b7c <ltmp0+0x1b7c>
    1dc8:      	movi.2d	v0, #0000000000000000
    1dcc:      	tbz	w8, #0x1, 0x1dd4 <ltmp0+0x1dd4>
    1dd0:      	ld1.b	{ v0 }[1], [x17]
    1dd4:      	tbnz	w8, #0x2, 0x28c0 <ltmp0+0x28c0>
    1dd8:      	tbnz	w8, #0x3, 0x28cc <ltmp0+0x28cc>
    1ddc:      	tbnz	w8, #0x4, 0x28d4 <ltmp0+0x28d4>
    1de0:      	tbnz	w8, #0x5, 0x28e0 <ltmp0+0x28e0>
    1de4:      	tbz	w8, #0x6, 0x1df0 <ltmp0+0x1df0>
    1de8:      	fmov	x9, d21
    1dec:      	ld1.b	{ v0 }[6], [x9]
    1df0:      	mov	w9, #0x4                ; =4
    1df4:      	stp	q6, q9, [sp, #0x2a0]
    1df8:      	stp	q15, q19, [sp, #0x320]
    1dfc:      	str	q24, [sp, #0x310]
    1e00:      	stp	q22, q21, [sp, #0x100]
    1e04:      	str	q28, [sp, #0xf0]
    1e08:      	stp	q12, q27, [sp, #0x280]
    1e0c:      	tbz	w8, #0x7, 0x1e14 <ltmp0+0x1e14>
    1e10:      	ld1.b	{ v0 }[7], [x12]
    1e14:      	stp	x17, x16, [sp, #0x10]
    1e18:      	stp	x13, x12, [sp, #0x20]
    1e1c:      	str	x19, [sp, #0x1b0]
    1e20:      	sshll.2d	v1, v14, #0x0
    1e24:      	sshll.2d	v2, v13, #0x0
    1e28:      	cmeq.8b	v0, v0, #0
    1e2c:      	sshll.8h	v0, v0, #0x0
    1e30:      	sshll2.4s	v3, v0, #0x0
    1e34:      	sshll.4s	v0, v0, #0x0
    1e38:      	add	x8, x15, x20
    1e3c:      	ldp	q4, q18, [x8]
    1e40:      	ldr	q19, [sp, #0x250]
    1e44:      	zip2.8b	v20, v19, v0
    1e48:      	ushll.4s	v20, v20, #0x0
    1e4c:      	shl.4s	v20, v20, #0x1f
    1e50:      	cmlt.4s	v20, v20, #0
    1e54:      	and.16b	v18, v20, v18
    1e58:      	zip1.8b	v21, v19, v0
    1e5c:      	ushll.4s	v21, v21, #0x0
    1e60:      	shl.4s	v21, v21, #0x1f
    1e64:      	cmlt.4s	v21, v21, #0
    1e68:      	and.16b	v4, v21, v4
    1e6c:      	mov.16b	v6, v0
    1e70:      	bsl.16b	v6, v5, v4
    1e74:      	mov.16b	v4, v3
    1e78:      	bsl.16b	v4, v5, v18
    1e7c:      	str	x20, [sp, #0x198]
    1e80:      	add	x8, x30, x20
    1e84:      	ldp	q0, q3, [x8]
    1e88:      	stp	q6, q4, [sp, #0x30]
    1e8c:      	bit.16b	v3, v4, v20
    1e90:      	bit.16b	v0, v6, v21
    1e94:      	stp	q0, q3, [x8]
    1e98:      	ldr	q0, [sp, #0x2f0]
    1e9c:      	fmov	x8, d0
    1ea0:      	dup.2d	v0, x9
    1ea4:      	ldp	q12, q5, [sp, #0x1d0]
    1ea8:      	and.16b	v22, v12, v0
    1eac:      	and.16b	v20, v5, v0
    1eb0:      	and.16b	v21, v2, v0
    1eb4:      	and.16b	v4, v1, v0
    1eb8:      	fmov	x15, d4
    1ebc:      	ldp	q1, q0, [x24, #0x40]
    1ec0:      	and.16b	v6, v13, v0
    1ec4:      	and.16b	v9, v14, v1
    1ec8:      	ldp	q2, q3, [x24, #0x20]
    1ecc:      	and.16b	v19, v13, v3
    1ed0:      	and.16b	v18, v14, v2
    1ed4:      	ldp	q2, q3, [x24]
    1ed8:      	and.16b	v25, v13, v3
    1edc:      	and.16b	v26, v14, v2
    1ee0:      	str	x8, [sp, #0x88]
    1ee4:      	add	x8, x30, x8
    1ee8:      	ldp	q2, q3, [x8]
    1eec:      	and.16b	v28, v13, v3
    1ef0:      	mov	x8, x15
    1ef4:      	and.16b	v2, v14, v2
    1ef8:      	stp	q4, q21, [sp, #0xa0]
    1efc:      	stp	q20, q22, [sp, #0xc0]
    1f00:      	sshll.2d	v1, v14, #0x0
    1f04:      	sshll.2d	v0, v13, #0x0
    1f08:      	stp	q0, q1, [sp, #0x2f0]
    1f0c:      	add	x8, x30, x8, lsl #5
    1f10:      	ldp	q3, q27, [x8]
    1f14:      	and.16b	v27, v13, v27
    1f18:      	and.16b	v3, v14, v3
    1f1c:      	fmaxnm.4s	v29, v2, v3
    1f20:      	fmaxnm.4s	v15, v28, v27
    1f24:      	ldp	q3, q23, [x8, #0x20]
    1f28:      	and.16b	v23, v13, v23
    1f2c:      	and.16b	v3, v14, v3
    1f30:      	fmaxnm.4s	v1, v26, v3
    1f34:      	fmaxnm.4s	v0, v25, v23
    1f38:      	stp	q0, q1, [sp, #0x2d0]
    1f3c:      	ldp	q27, q24, [x8, #0x40]
    1f40:      	and.16b	v24, v13, v24
    1f44:      	and.16b	v27, v14, v27
    1f48:      	fmaxnm.4s	v27, v18, v27
    1f4c:      	fmaxnm.4s	v24, v19, v24
    1f50:      	ldp	q0, q3, [x8, #0x60]
    1f54:      	and.16b	v3, v13, v3
    1f58:      	and.16b	v0, v14, v0
    1f5c:      	fmaxnm.4s	v0, v9, v0
    1f60:      	fmaxnm.4s	v3, v6, v3
    1f64:      	dup.2d	v1, x9
    1f68:      	and.16b	v23, v12, v1
    1f6c:      	add.2d	v22, v22, v23
    1f70:      	and.16b	v23, v5, v1
    1f74:      	add.2d	v20, v20, v23
    1f78:      	ldr	q23, [sp, #0x2f0]
    1f7c:      	and.16b	v23, v23, v1
    1f80:      	add.2d	v21, v21, v23
    1f84:      	mov.16b	v23, v29
    1f88:      	ldr	q29, [sp, #0x300]
    1f8c:      	and.16b	v1, v29, v1
    1f90:      	add.2d	v4, v4, v1
    1f94:      	bit.16b	v28, v15, v13
    1f98:      	bit.16b	v2, v23, v14
    1f9c:      	ldr	q1, [sp, #0x2d0]
    1fa0:      	bit.16b	v25, v1, v13
    1fa4:      	ldr	q1, [sp, #0x2e0]
    1fa8:      	bit.16b	v26, v1, v14
    1fac:      	bit.16b	v19, v24, v13
    1fb0:      	bit.16b	v18, v27, v14
    1fb4:      	bit.16b	v6, v3, v13
    1fb8:      	bit.16b	v9, v0, v14
    1fbc:      	fmov	x8, d4
    1fc0:      	cmp	x8, #0x200
    1fc4:      	b.lt	0x1f00 <ltmp0+0x1f00>
    1fc8:      	mov	x17, #0x0               ; =0
    1fcc:      	ldr	q0, [sp, #0x120]
    1fd0:      	xtn.8b	v22, v0
    1fd4:      	ldr	q3, [sp, #0x250]
    1fd8:      	zip1.8b	v0, v3, v0
    1fdc:      	ushll.4s	v0, v0, #0x0
    1fe0:      	shl.4s	v0, v0, #0x1f
    1fe4:      	cmlt.4s	v0, v0, #0
    1fe8:      	ldp	q1, q4, [sp, #0x30]
    1fec:      	and.16b	v1, v0, v1
    1ff0:      	zip2.8b	v3, v3, v0
    1ff4:      	ushll.4s	v3, v3, #0x0
    1ff8:      	shl.4s	v3, v3, #0x1f
    1ffc:      	cmlt.4s	v3, v3, #0
    2000:      	and.16b	v4, v3, v4
    2004:      	fmaxnm.4s	v4, v28, v4
    2008:      	fmaxnm.4s	v1, v2, v1
    200c:      	and.16b	v0, v0, v1
    2010:      	and.16b	v1, v3, v4
    2014:      	zip2.8b	v2, v22, v0
    2018:      	ushll.4s	v2, v2, #0x0
    201c:      	shl.4s	v2, v2, #0x1f
    2020:      	cmlt.4s	v2, v2, #0
    2024:      	movi.2d	v3, #0000000000000000
    2028:      	mov.b	v3[2], v22[1]
    202c:      	mov.b	v3[4], v22[2]
    2030:      	mov.b	v3[6], v22[3]
    2034:      	bit.16b	v1, v15, v2
    2038:      	ushll.4s	v2, v3, #0x0
    203c:      	shl.4s	v2, v2, #0x1f
    2040:      	cmlt.4s	v2, v2, #0
    2044:      	bit.16b	v0, v23, v2
    2048:      	fmaxnm.4s	v0, v0, v26
    204c:      	fmaxnm.4s	v1, v1, v25
    2050:      	fmaxnm.4s	v1, v1, v19
    2054:      	fmaxnm.4s	v0, v0, v18
    2058:      	fmaxnm.4s	v25, v0, v9
    205c:      	fmaxnm.4s	v26, v1, v6
    2060:      	ldr	q0, [sp, #0x90]
    2064:      	ldp	q1, q2, [sp, #0x50]
    2068:      	uzp1.4s	v19, v0, v2
    206c:      	ldr	q0, [sp, #0x70]
    2070:      	uzp1.4s	v0, v1, v0
    2074:      	movi.4s	v2, #0x1
    2078:      	eor.16b	v1, v19, v2
    207c:      	mov.s	w8, v1[1]
    2080:      	mov.s	w9, v1[2]
    2084:      	eor.16b	v2, v0, v2
    2088:      	mov.s	w12, v1[3]
    208c:      	fmov	w10, s1
    2090:      	add	x13, sp, #0x748
    2094:      	bfxil	x13, x10, #0, #3
    2098:      	str	d22, [sp, #0x748]
    209c:      	ldrb	w13, [x13]
    20a0:      	and	x10, x10, #0x7
    20a4:      	umov.b	w0, v22[0]
    20a8:      	str	w0, [sp, #0x2e0]
    20ac:      	str	q26, [sp, #0x9e0]
    20b0:      	str	q25, [sp, #0x9d0]
    20b4:      	add	x16, sp, #0x9d0
    20b8:      	ldr	s1, [x16, x10, lsl #2]
    20bc:      	ands	w20, w0, #0x1
    20c0:      	tst	w20, w13
    20c4:      	str	w20, [sp, #0x300]
    20c8:      	movi	d5, #0000000000000000
    20cc:      	fcsel	s1, s1, s5, ne
    20d0:      	and	x13, x8, #0x7
    20d4:      	add	x16, sp, #0x748
    20d8:      	bfxil	x16, x8, #0, #3
    20dc:      	ldrb	w8, [x16]
    20e0:      	umov.b	w24, v22[1]
    20e4:      	and	w8, w24, w8
    20e8:      	str	q26, [sp, #0x9c0]
    20ec:      	str	q25, [sp, #0x9b0]
    20f0:      	add	x16, sp, #0x9b0
    20f4:      	ldr	s3, [x16, x13, lsl #2]
    20f8:      	tst	w8, #0x1
    20fc:      	fcsel	s18, s3, s5, ne
    2100:      	and	x8, x9, #0x7
    2104:      	add	x13, sp, #0x748
    2108:      	bfxil	x13, x9, #0, #3
    210c:      	umov.b	w2, v22[2]
    2110:      	ldrb	w9, [x13]
    2114:      	and	w9, w2, w9
    2118:      	str	q26, [sp, #0x9a0]
    211c:      	str	q25, [sp, #0x990]
    2120:      	add	x13, sp, #0x990
    2124:      	ldr	s3, [x13, x8, lsl #2]
    2128:      	tst	w9, #0x1
    212c:      	fcsel	s28, s3, s5, ne
    2130:      	and	x8, x12, #0x7
    2134:      	add	x9, sp, #0x748
    2138:      	bfxil	x9, x12, #0, #3
    213c:      	ldrb	w9, [x9]
    2140:      	umov.b	w3, v22[3]
    2144:      	str	q26, [sp, #0x980]
    2148:      	str	q25, [sp, #0x970]
    214c:      	add	x12, sp, #0x970
    2150:      	ldr	s3, [x12, x8, lsl #2]
    2154:      	and	w8, w3, w9
    2158:      	tst	w8, #0x1
    215c:      	mov.s	w8, v2[1]
    2160:      	mov.s	w13, v2[2]
    2164:      	fcsel	s3, s3, s5, ne
    2168:      	mov.s	w16, v2[3]
    216c:      	fmov	w9, s2
    2170:      	and	x12, x9, #0x7
    2174:      	add	x0, sp, #0x748
    2178:      	bfxil	x0, x9, #0, #3
    217c:      	ldrb	w0, [x0]
    2180:      	umov.b	w1, v22[4]
    2184:      	and	w0, w1, w0
    2188:      	str	q26, [sp, #0xa60]
    218c:      	str	q25, [sp, #0xa50]
    2190:      	add	x9, sp, #0xa50
    2194:      	ldr	s2, [x9, x12, lsl #2]
    2198:      	tst	w0, #0x1
    219c:      	fcsel	s2, s2, s5, ne
    21a0:      	and	x0, x8, #0x7
    21a4:      	add	x12, sp, #0x748
    21a8:      	bfxil	x12, x8, #0, #3
    21ac:      	ldrb	w8, [x12]
    21b0:      	umov.b	w10, v22[5]
    21b4:      	and	w8, w10, w8
    21b8:      	str	q26, [sp, #0xa40]
    21bc:      	str	q25, [sp, #0xa30]
    21c0:      	add	x9, sp, #0xa30
    21c4:      	ldr	s4, [x9, x0, lsl #2]
    21c8:      	tst	w8, #0x1
    21cc:      	fcsel	s4, s4, s5, ne
    21d0:      	and	x8, x13, #0x7
    21d4:      	add	x0, sp, #0x748
    21d8:      	bfxil	x0, x13, #0, #3
    21dc:      	ldrb	w0, [x0]
    21e0:      	umov.b	w13, v22[6]
    21e4:      	and	w0, w13, w0
    21e8:      	str	q26, [sp, #0xa20]
    21ec:      	str	q25, [sp, #0xa10]
    21f0:      	add	x9, sp, #0xa10
    21f4:      	ldr	s20, [x9, x8, lsl #2]
    21f8:      	tst	w0, #0x1
    21fc:      	fcsel	s20, s20, s5, ne
    2200:      	and	x8, x16, #0x7
    2204:      	add	x5, sp, #0x748
    2208:      	bfxil	x5, x16, #0, #3
    220c:      	umov.b	w0, v22[7]
    2210:      	ldrb	w16, [x5]
    2214:      	and	w16, w0, w16
    2218:      	str	q26, [sp, #0xa00]
    221c:      	str	q25, [sp, #0x9f0]
    2220:      	add	x9, sp, #0x9f0
    2224:      	ldr	s21, [x9, x8, lsl #2]
    2228:      	tst	w16, #0x1
    222c:      	fcsel	s21, s21, s5, ne
    2230:      	mov.s	v2[1], v4[0]
    2234:      	mov.s	v2[2], v20[0]
    2238:      	mov.s	v2[3], v21[0]
    223c:      	mov.s	v1[1], v18[0]
    2240:      	mov.s	v1[2], v28[0]
    2244:      	mov.s	v1[3], v3[0]
    2248:      	fmaxnm.4s	v25, v25, v1
    224c:      	fmaxnm.4s	v28, v26, v2
    2250:      	movi.4s	v2, #0x2
    2254:      	eor.16b	v1, v19, v2
    2258:      	mov.s	w8, v1[1]
    225c:      	mov.s	w16, v1[2]
    2260:      	mov.s	w5, v1[3]
    2264:      	eor.16b	v26, v0, v2
    2268:      	fmov	w7, s1
    226c:      	add	x19, sp, #0x748
    2270:      	bfxil	x19, x7, #0, #3
    2274:      	ldrb	w19, [x19]
    2278:      	and	x7, x7, #0x7
    227c:      	str	q28, [sp, #0x960]
    2280:      	str	q25, [sp, #0x950]
    2284:      	add	x9, sp, #0x950
    2288:      	ldr	s0, [x9, x7, lsl #2]
    228c:      	tst	w20, w19
    2290:      	fcsel	s0, s0, s5, ne
    2294:      	and	x7, x8, #0x7
    2298:      	add	x19, sp, #0x748
    229c:      	bfxil	x19, x8, #0, #3
    22a0:      	ldrb	w8, [x19]
    22a4:      	and	w8, w24, w8
    22a8:      	str	q28, [sp, #0x940]
    22ac:      	str	q25, [sp, #0x930]
    22b0:      	add	x9, sp, #0x930
    22b4:      	ldr	s1, [x9, x7, lsl #2]
    22b8:      	tst	w8, #0x1
    22bc:      	fcsel	s1, s1, s5, ne
    22c0:      	and	x8, x16, #0x7
    22c4:      	add	x7, sp, #0x748
    22c8:      	bfxil	x7, x16, #0, #3
    22cc:      	ldrb	w16, [x7]
    22d0:      	and	w16, w2, w16
    22d4:      	str	q28, [sp, #0x920]
    22d8:      	str	q25, [sp, #0x910]
    22dc:      	add	x9, sp, #0x910
    22e0:      	ldr	s2, [x9, x8, lsl #2]
    22e4:      	tst	w16, #0x1
    22e8:      	fcsel	s18, s2, s5, ne
    22ec:      	and	x8, x5, #0x7
    22f0:      	add	x16, sp, #0x748
    22f4:      	bfxil	x16, x5, #0, #3
    22f8:      	ldrb	w16, [x16]
    22fc:      	str	q28, [sp, #0x900]
    2300:      	str	q25, [sp, #0x8f0]
    2304:      	add	x9, sp, #0x8f0
    2308:      	ldr	s2, [x9, x8, lsl #2]
    230c:      	and	w8, w3, w16
    2310:      	tst	w8, #0x1
    2314:      	mov.s	w5, v26[3]
    2318:      	mov.s	w28, v26[1]
    231c:      	fmov	w8, s26
    2320:      	and	x26, x8, #0x7
    2324:      	add	x9, sp, #0x748
    2328:      	bfxil	x9, x8, #0, #3
    232c:      	add	x8, sp, #0x748
    2330:      	bfxil	x8, x5, #0, #3
    2334:      	ldrb	w20, [x8]
    2338:      	movi.4s	v3, #0x4
    233c:      	eor.16b	v3, v19, v3
    2340:      	mov.s	w19, v3[1]
    2344:      	mov.s	w16, v3[2]
    2348:      	mov.s	w8, v3[3]
    234c:      	fmov	w27, s3
    2350:      	add	x7, sp, #0x748
    2354:      	bfxil	x7, x27, #0, #3
    2358:      	ldrb	w22, [x7]
    235c:      	add	x7, sp, #0x748
    2360:      	bfxil	x7, x19, #0, #3
    2364:      	ldrb	w23, [x7]
    2368:      	add	x7, sp, #0x748
    236c:      	bfxil	x7, x16, #0, #3
    2370:      	ldrb	w21, [x7]
    2374:      	add	x7, sp, #0x748
    2378:      	bfxil	x7, x8, #0, #3
    237c:      	ldrb	w7, [x7]
    2380:      	ldrb	w9, [x9]
    2384:      	str	q28, [sp, #0x8e0]
    2388:      	str	q25, [sp, #0x8d0]
    238c:      	add	x12, sp, #0x8d0
    2390:      	ldr	s3, [x12, x26, lsl #2]
    2394:      	add	x26, sp, #0x748
    2398:      	bfxil	x26, x28, #0, #3
    239c:      	and	x28, x28, #0x7
    23a0:      	ldrb	w26, [x26]
    23a4:      	str	q28, [sp, #0x8c0]
    23a8:      	str	q25, [sp, #0x8b0]
    23ac:      	add	x12, sp, #0x8b0
    23b0:      	ldr	s4, [x12, x28, lsl #2]
    23b4:      	fcsel	s2, s2, s5, ne
    23b8:      	and	w9, w1, w9
    23bc:      	tst	w9, #0x1
    23c0:      	mov.s	w9, v26[2]
    23c4:      	fcsel	s3, s3, s5, ne
    23c8:      	and	w26, w10, w26
    23cc:      	tst	w26, #0x1
    23d0:      	add	x26, sp, #0x748
    23d4:      	bfxil	x26, x9, #0, #3
    23d8:      	and	x9, x9, #0x7
    23dc:      	ldrb	w26, [x26]
    23e0:      	str	q28, [sp, #0x8a0]
    23e4:      	str	q25, [sp, #0x890]
    23e8:      	add	x12, sp, #0x890
    23ec:      	ldr	s19, [x12, x9, lsl #2]
    23f0:      	fcsel	s4, s4, s5, ne
    23f4:      	and	w9, w13, w26
    23f8:      	tst	w9, #0x1
    23fc:      	and	x9, x5, #0x7
    2400:      	mov	x5, x1
    2404:      	mov	x1, x2
    2408:      	mov	x2, x24
    240c:      	str	q28, [sp, #0x880]
    2410:      	str	q25, [sp, #0x870]
    2414:      	add	x12, sp, #0x870
    2418:      	ldr	s20, [x12, x9, lsl #2]
    241c:      	fcsel	s19, s19, s5, ne
    2420:      	and	w9, w0, w20
    2424:      	tst	w9, #0x1
    2428:      	fcsel	s20, s20, s5, ne
    242c:      	mov.s	v3[1], v4[0]
    2430:      	mov.s	v3[2], v19[0]
    2434:      	mov.s	v3[3], v20[0]
    2438:      	mov.s	v0[1], v1[0]
    243c:      	mov.s	v0[2], v18[0]
    2440:      	mov.s	v0[3], v2[0]
    2444:      	fmaxnm.4s	v0, v25, v0
    2448:      	fmaxnm.4s	v1, v28, v3
    244c:      	and	x9, x27, #0x7
    2450:      	str	q1, [sp, #0x860]
    2454:      	str	q0, [sp, #0x850]
    2458:      	add	x12, sp, #0x850
    245c:      	ldr	s2, [x12, x9, lsl #2]
    2460:      	ldr	w9, [sp, #0x300]
    2464:      	tst	w9, w22
    2468:      	fcsel	s2, s2, s5, ne
    246c:      	and	x9, x19, #0x7
    2470:      	mov	x19, x10
    2474:      	and	w10, w24, w23
    2478:      	str	q1, [sp, #0x840]
    247c:      	str	q0, [sp, #0x830]
    2480:      	add	x12, sp, #0x830
    2484:      	ldr	s3, [x12, x9, lsl #2]
    2488:      	tst	w10, #0x1
    248c:      	fcsel	s3, s3, s5, ne
    2490:      	and	x9, x16, #0x7
    2494:      	str	q1, [sp, #0x820]
    2498:      	str	q0, [sp, #0x810]
    249c:      	add	x10, sp, #0x810
    24a0:      	ldr	s4, [x10, x9, lsl #2]
    24a4:      	and	w9, w1, w21
    24a8:      	tst	w9, #0x1
    24ac:      	fcsel	s4, s4, s5, ne
    24b0:      	and	x8, x8, #0x7
    24b4:      	and	w9, w3, w7
    24b8:      	ldr	w7, [sp, #0x2e0]
    24bc:      	str	q1, [sp, #0x800]
    24c0:      	str	q0, [sp, #0x7f0]
    24c4:      	add	x10, sp, #0x7f0
    24c8:      	ldr	s1, [x10, x8, lsl #2]
    24cc:      	tst	w9, #0x1
    24d0:      	fcsel	s1, s1, s5, ne
    24d4:      	ands	w22, w7, #0x1
    24d8:      	mov.s	v2[1], v3[0]
    24dc:      	mov.s	v2[2], v4[0]
    24e0:      	mov.s	v2[3], v1[0]
    24e4:      	fmaxnm.4s	v0, v0, v2
    24e8:      	fcsel	s1, s0, s5, ne
    24ec:      	and	w20, w24, w7
    24f0:      	tst	w20, #0x1
    24f4:      	fcsel	s2, s0, s5, ne
    24f8:      	and	w21, w1, w7
    24fc:      	tst	w21, #0x1
    2500:      	fcsel	s3, s0, s5, ne
    2504:      	and	w23, w3, w7
    2508:      	tst	w23, #0x1
    250c:      	fcsel	s4, s0, s5, ne
    2510:      	and	w24, w5, w7
    2514:      	tst	w24, #0x1
    2518:      	fcsel	s18, s0, s5, ne
    251c:      	and	w26, w19, w7
    2520:      	tst	w26, #0x1
    2524:      	fcsel	s19, s0, s5, ne
    2528:      	and	w28, w13, w7
    252c:      	tst	w28, #0x1
    2530:      	fcsel	s20, s0, s5, ne
    2534:      	and	w10, w0, w7
    2538:      	tst	w10, #0x1
    253c:      	mov.s	v1[1], v2[0]
    2540:      	mov.s	v1[2], v3[0]
    2544:      	mov.s	v1[3], v4[0]
    2548:      	mov.s	v18[1], v19[0]
    254c:      	fcsel	s0, s0, s5, ne
    2550:      	mov.s	v18[2], v20[0]
    2554:      	mov.s	v18[3], v0[0]
    2558:      	ldr	w8, [sp, #0x134]
    255c:      	rbit	w8, w8
    2560:      	clz	w27, w8
    2564:      	str	q18, [sp, #0x760]
    2568:      	str	q1, [sp, #0x750]
    256c:      	and	x8, x27, #0x7
    2570:      	add	x9, sp, #0x750
    2574:      	ldr	s0, [x9, x8, lsl #2]
    2578:      	str	q22, [sp, #0x300]
    257c:      	mov.b	v22[0], wzr
    2580:      	str	q22, [sp, #0x2f0]
    2584:      	mov	w8, #-0x800000          ; =-8388608
    2588:      	fmov	s1, w8
    258c:      	fmaxnm	s0, s0, s1
    2590:      	dup.4s	v6, v0[0]
    2594:      	movi.2d	v0, #0000000000000000
    2598:      	movi.2d	v25, #0000000000000000
    259c:      	movi.2d	v19, #0000000000000000
    25a0:      	movi.2d	v28, #0000000000000000
    25a4:      	movi.4s	v24, #0x4b, lsl #24
    25a8:      	ldr	q27, [sp, #0x3d0]
    25ac:      	ldr	x16, [sp, #0x1b0]
    25b0:      	ldr	q12, [sp, #0x1c0]
    25b4:      	ldp	q29, q9, [sp, #0x350]
    25b8:      	b	0x27a4 <ltmp0+0x27a4>
    25bc:      	lsl	x8, x17, #5
    25c0:      	add	x9, x30, x8
    25c4:      	ldp	q2, q1, [x9]
    25c8:      	fsub.4s	v3, v2, v6
    25cc:      	fsub.4s	v1, v1, v6
    25d0:      	and.16b	v2, v13, v1
    25d4:      	and.16b	v1, v14, v3
    25d8:      	fcmge.4s	v3, v1, v29
    25dc:      	fcmge.4s	v4, v2, v29
    25e0:      	fcmge.4s	v18, v9, v1
    25e4:      	fcmge.4s	v20, v9, v2
    25e8:      	and.16b	v4, v4, v20
    25ec:      	and.16b	v3, v3, v18
    25f0:      	and.16b	v3, v3, v1
    25f4:      	and.16b	v4, v4, v2
    25f8:      	ldr	q5, [sp, #0x400]
    25fc:      	fmul.4s	v18, v4, v5
    2600:      	fmul.4s	v20, v3, v5
    2604:      	mvni.4s	v5, #0x80, lsl #24
    2608:      	mov.16b	v21, v5
    260c:      	bsl.16b	v21, v24, v20
    2610:      	mov.16b	v22, v5
    2614:      	bsl.16b	v22, v24, v18
    2618:      	fadd.4s	v18, v18, v22
    261c:      	fadd.4s	v20, v20, v21
    2620:      	fsub.4s	v20, v20, v21
    2624:      	fsub.4s	v18, v18, v22
    2628:      	fcvtzs.4s	v18, v18
    262c:      	fcvtzs.4s	v20, v20
    2630:      	scvtf.4s	v21, v20
    2634:      	scvtf.4s	v22, v18
    2638:      	ldr	q5, [sp, #0x410]
    263c:      	fmul.4s	v23, v21, v5
    2640:      	fadd.4s	v3, v3, v23
    2644:      	fmul.4s	v23, v22, v5
    2648:      	fadd.4s	v4, v4, v23
    264c:      	ldr	q5, [sp, #0x340]
    2650:      	fmul.4s	v21, v21, v5
    2654:      	fmul.4s	v22, v22, v5
    2658:      	fadd.4s	v4, v4, v22
    265c:      	fadd.4s	v3, v3, v21
    2660:      	ldr	q5, [sp, #0x420]
    2664:      	fmul.4s	v21, v3, v5
    2668:      	fmul.4s	v22, v4, v5
    266c:      	ldr	q5, [sp, #0x430]
    2670:      	fadd.4s	v22, v22, v5
    2674:      	fadd.4s	v21, v21, v5
    2678:      	fmul.4s	v21, v3, v21
    267c:      	fmul.4s	v22, v4, v22
    2680:      	ldr	q23, [sp, #0x440]
    2684:      	fadd.4s	v22, v22, v23
    2688:      	fadd.4s	v21, v21, v23
    268c:      	fmul.4s	v21, v3, v21
    2690:      	fmul.4s	v22, v4, v22
    2694:      	ldr	q23, [sp, #0x450]
    2698:      	fadd.4s	v22, v22, v23
    269c:      	fadd.4s	v21, v21, v23
    26a0:      	fmul.4s	v21, v3, v21
    26a4:      	fmul.4s	v22, v4, v22
    26a8:      	fadd.4s	v22, v22, v27
    26ac:      	fadd.4s	v21, v21, v27
    26b0:      	fmul.4s	v21, v3, v21
    26b4:      	fmul.4s	v22, v4, v22
    26b8:      	movi.4s	v5, #0x3f, lsl #24
    26bc:      	fadd.4s	v22, v22, v5
    26c0:      	fadd.4s	v21, v21, v5
    26c4:      	fmul.4s	v23, v3, v3
    26c8:      	fmul.4s	v21, v23, v21
    26cc:      	fmul.4s	v23, v4, v4
    26d0:      	fmul.4s	v22, v23, v22
    26d4:      	fadd.4s	v4, v4, v22
    26d8:      	fadd.4s	v3, v3, v21
    26dc:      	fadd.4s	v3, v3, v31
    26e0:      	fadd.4s	v4, v4, v31
    26e4:      	sshr.4s	v21, v20, #0x1
    26e8:      	sshr.4s	v22, v18, #0x1
    26ec:      	shl.4s	v23, v22, #0x17
    26f0:      	add.4s	v23, v23, v31
    26f4:      	fmul.4s	v4, v4, v23
    26f8:      	shl.4s	v23, v21, #0x17
    26fc:      	add.4s	v23, v23, v31
    2700:      	fmul.4s	v3, v3, v23
    2704:      	sub.4s	v18, v18, v22
    2708:      	sub.4s	v20, v20, v21
    270c:      	shl.4s	v20, v20, #0x17
    2710:      	add.4s	v20, v20, v31
    2714:      	fmul.4s	v3, v3, v20
    2718:      	shl.4s	v18, v18, #0x17
    271c:      	add.4s	v18, v18, v31
    2720:      	fmul.4s	v4, v4, v18
    2724:      	fcmgt.4s	v18, v29, v2
    2728:      	bic.16b	v4, v4, v18
    272c:      	fcmgt.4s	v18, v29, v1
    2730:      	bic.16b	v3, v3, v18
    2734:      	fcmgt.4s	v18, v1, v9
    2738:      	bit.16b	v3, v8, v18
    273c:      	fcmgt.4s	v18, v2, v9
    2740:      	bit.16b	v4, v8, v18
    2744:      	fcmeq.4s	v2, v2, v2
    2748:      	bsl.16b	v2, v4, v12
    274c:      	cmeq.8b	v4, v26, #0
    2750:      	sshll.8h	v4, v4, #0x0
    2754:      	fcmeq.4s	v1, v1, v1
    2758:      	bsl.16b	v1, v3, v12
    275c:      	sshll.4s	v3, v4, #0x0
    2760:      	bic.16b	v1, v1, v3
    2764:      	sshll2.4s	v3, v4, #0x0
    2768:      	bic.16b	v2, v2, v3
    276c:      	add	x8, x25, x8
    2770:      	ldp	q3, q4, [x8]
    2774:      	bif.16b	v2, v4, v13
    2778:      	bif.16b	v1, v3, v14
    277c:      	stp	q1, q2, [x8]
    2780:      	ldp	q2, q1, [sp, #0x320]
    2784:      	add.2d	v25, v25, v2
    2788:      	add.2d	v19, v19, v10
    278c:      	add.2d	v28, v28, v1
    2790:      	ldr	q1, [sp, #0x310]
    2794:      	add.2d	v0, v0, v1
    2798:      	fmov	x17, d0
    279c:      	cmp	x17, #0x200
    27a0:      	b.ge	0x2890 <ltmp0+0x2890>
    27a4:      	fmov	w8, s30
    27a8:      	ldr	q1, [sp, #0x370]
    27ac:      	add.2d	v1, v0, v1
    27b0:      	ldr	q2, [sp, #0x2b0]
    27b4:      	add.2d	v1, v2, v1
    27b8:      	tbz	w8, #0x0, 0x27d0 <ltmp0+0x27d0>
    27bc:      	fmov	x9, d1
    27c0:      	ldr	b26, [x9]
    27c4:      	and	w8, w8, #0xff
    27c8:      	tbnz	w8, #0x1, 0x27dc <ltmp0+0x27dc>
    27cc:      	b	0x27e4 <ltmp0+0x27e4>
    27d0:      	movi.2d	v26, #0000000000000000
    27d4:      	and	w8, w8, #0xff
    27d8:      	tbz	w8, #0x1, 0x27e4 <ltmp0+0x27e4>
    27dc:      	mov.d	x9, v1[1]
    27e0:      	ld1.b	{ v26 }[1], [x9]
    27e4:      	ldr	q1, [sp, #0x3c0]
    27e8:      	add.2d	v1, v25, v1
    27ec:      	ldr	q2, [sp, #0x2a0]
    27f0:      	add.2d	v1, v2, v1
    27f4:      	tbnz	w8, #0x2, 0x282c <ltmp0+0x282c>
    27f8:      	tbnz	w8, #0x3, 0x2838 <ltmp0+0x2838>
    27fc:      	ldr	q1, [sp, #0x380]
    2800:      	add.2d	v1, v19, v1
    2804:      	ldr	q2, [sp, #0x460]
    2808:      	add.2d	v1, v2, v1
    280c:      	tbnz	w8, #0x4, 0x2854 <ltmp0+0x2854>
    2810:      	tbnz	w8, #0x5, 0x2860 <ltmp0+0x2860>
    2814:      	ldp	q1, q2, [sp, #0x280]
    2818:      	add.2d	v1, v28, v1
    281c:      	add.2d	v1, v2, v1
    2820:      	tbnz	w8, #0x6, 0x2878 <ltmp0+0x2878>
    2824:      	tbz	w8, #0x7, 0x25bc <ltmp0+0x25bc>
    2828:      	b	0x2884 <ltmp0+0x2884>
    282c:      	fmov	x9, d1
    2830:      	ld1.b	{ v26 }[2], [x9]
    2834:      	tbz	w8, #0x3, 0x27fc <ltmp0+0x27fc>
    2838:      	mov.d	x9, v1[1]
    283c:      	ld1.b	{ v26 }[3], [x9]
    2840:      	ldr	q1, [sp, #0x380]
    2844:      	add.2d	v1, v19, v1
    2848:      	ldr	q2, [sp, #0x460]
    284c:      	add.2d	v1, v2, v1
    2850:      	tbz	w8, #0x4, 0x2810 <ltmp0+0x2810>
    2854:      	fmov	x9, d1
    2858:      	ld1.b	{ v26 }[4], [x9]
    285c:      	tbz	w8, #0x5, 0x2814 <ltmp0+0x2814>
    2860:      	mov.d	x9, v1[1]
    2864:      	ld1.b	{ v26 }[5], [x9]
    2868:      	ldp	q1, q2, [sp, #0x280]
    286c:      	add.2d	v1, v28, v1
    2870:      	add.2d	v1, v2, v1
    2874:      	tbz	w8, #0x6, 0x2824 <ltmp0+0x2824>
    2878:      	fmov	x9, d1
    287c:      	ld1.b	{ v26 }[6], [x9]
    2880:      	tbz	w8, #0x7, 0x25bc <ltmp0+0x25bc>
    2884:      	mov.d	x8, v1[1]
    2888:      	ld1.b	{ v26 }[7], [x8]
    288c:      	b	0x25bc <ltmp0+0x25bc>
    2890:      	ldr	d0, [sp, #0x208]
    2894:      	fmov	w8, s0
    2898:      	ldp	q2, q1, [sp, #0x100]
    289c:      	tbz	w8, #0x0, 0x28ec <ltmp0+0x28ec>
    28a0:      	ldp	q0, q3, [sp, #0xe0]
    28a4:      	fmov	x9, d0
    28a8:      	ldr	b0, [x9]
    28ac:      	ldr	q5, [sp, #0x410]
    28b0:      	ldr	q23, [sp, #0x400]
    28b4:      	ldr	x17, [sp, #0x198]
    28b8:      	tbnz	w8, #0x1, 0x2904 <ltmp0+0x2904>
    28bc:      	b	0x290c <ltmp0+0x290c>
    28c0:      	fmov	x9, d28
    28c4:      	ld1.b	{ v0 }[2], [x9]
    28c8:      	tbz	w8, #0x3, 0x1ddc <ltmp0+0x1ddc>
    28cc:      	ld1.b	{ v0 }[3], [x16]
    28d0:      	tbz	w8, #0x4, 0x1de0 <ltmp0+0x1de0>
    28d4:      	fmov	x9, d22
    28d8:      	ld1.b	{ v0 }[4], [x9]
    28dc:      	tbz	w8, #0x5, 0x1de4 <ltmp0+0x1de4>
    28e0:      	ld1.b	{ v0 }[5], [x13]
    28e4:      	tbnz	w8, #0x6, 0x1de8 <ltmp0+0x1de8>
    28e8:      	b	0x1df0 <ltmp0+0x1df0>
    28ec:      	movi.2d	v0, #0000000000000000
    28f0:      	ldr	q5, [sp, #0x410]
    28f4:      	ldr	q23, [sp, #0x400]
    28f8:      	ldr	x17, [sp, #0x198]
    28fc:      	ldr	q3, [sp, #0xf0]
    2900:      	tbz	w8, #0x1, 0x290c <ltmp0+0x290c>
    2904:      	ldr	x9, [sp, #0x10]
    2908:      	ld1.b	{ v0 }[1], [x9]
    290c:      	tbnz	w8, #0x2, 0x320c <ltmp0+0x320c>
    2910:      	tbnz	w8, #0x3, 0x3218 <ltmp0+0x3218>
    2914:      	tbnz	w8, #0x4, 0x3224 <ltmp0+0x3224>
    2918:      	tbnz	w8, #0x5, 0x3230 <ltmp0+0x3230>
    291c:      	tbnz	w8, #0x6, 0x323c <ltmp0+0x323c>
    2920:      	mov	w9, #0x4                ; =4
    2924:      	str	q10, [sp, #0x150]
    2928:      	tbz	w8, #0x7, 0x2934 <ltmp0+0x2934>
    292c:      	ldr	x8, [sp, #0x28]
    2930:      	ld1.b	{ v0 }[7], [x8]
    2934:      	cmeq.8b	v0, v0, #0
    2938:      	sshll.8h	v1, v0, #0x0
    293c:      	sshll2.4s	v0, v1, #0x0
    2940:      	sshll.4s	v1, v1, #0x0
    2944:      	add	x8, x30, x17
    2948:      	ldp	q3, q2, [x8]
    294c:      	fsub.4s	v4, v3, v6
    2950:      	fsub.4s	v3, v2, v6
    2954:      	ldr	q19, [sp, #0x250]
    2958:      	zip2.8b	v2, v19, v0
    295c:      	ushll.4s	v2, v2, #0x0
    2960:      	shl.4s	v2, v2, #0x1f
    2964:      	cmlt.4s	v2, v2, #0
    2968:      	and.16b	v18, v2, v3
    296c:      	zip1.8b	v3, v19, v0
    2970:      	ushll.4s	v3, v3, #0x0
    2974:      	shl.4s	v3, v3, #0x1f
    2978:      	cmlt.4s	v3, v3, #0
    297c:      	and.16b	v4, v3, v4
    2980:      	fcmge.4s	v19, v4, v29
    2984:      	fcmge.4s	v20, v18, v29
    2988:      	fcmge.4s	v21, v9, v4
    298c:      	fcmge.4s	v22, v9, v18
    2990:      	and.16b	v20, v20, v22
    2994:      	and.16b	v19, v19, v21
    2998:      	and.16b	v19, v19, v4
    299c:      	and.16b	v20, v20, v18
    29a0:      	fmul.4s	v21, v20, v23
    29a4:      	fmul.4s	v22, v19, v23
    29a8:      	mvni.4s	v6, #0x80, lsl #24
    29ac:      	mov.16b	v23, v6
    29b0:      	bsl.16b	v23, v24, v22
    29b4:      	movi.4s	v24, #0x4b, lsl #24
    29b8:      	bif.16b	v24, v21, v6
    29bc:      	fadd.4s	v21, v21, v24
    29c0:      	fadd.4s	v22, v22, v23
    29c4:      	fsub.4s	v22, v22, v23
    29c8:      	fsub.4s	v21, v21, v24
    29cc:      	fcvtzs.4s	v21, v21
    29d0:      	fcvtzs.4s	v22, v22
    29d4:      	scvtf.4s	v23, v22
    29d8:      	scvtf.4s	v24, v21
    29dc:      	fmul.4s	v25, v24, v5
    29e0:      	fmul.4s	v26, v23, v5
    29e4:      	fadd.4s	v19, v19, v26
    29e8:      	fadd.4s	v20, v20, v25
    29ec:      	ldr	q5, [sp, #0x340]
    29f0:      	fmul.4s	v23, v23, v5
    29f4:      	fmul.4s	v24, v24, v5
    29f8:      	fadd.4s	v20, v20, v24
    29fc:      	fadd.4s	v19, v19, v23
    2a00:      	ldr	q5, [sp, #0x420]
    2a04:      	fmul.4s	v23, v19, v5
    2a08:      	fmul.4s	v24, v20, v5
    2a0c:      	ldr	q5, [sp, #0x430]
    2a10:      	fadd.4s	v24, v24, v5
    2a14:      	fadd.4s	v23, v23, v5
    2a18:      	fmul.4s	v23, v19, v23
    2a1c:      	fmul.4s	v24, v20, v24
    2a20:      	ldr	q25, [sp, #0x440]
    2a24:      	fadd.4s	v24, v24, v25
    2a28:      	fadd.4s	v23, v23, v25
    2a2c:      	fmul.4s	v23, v19, v23
    2a30:      	fmul.4s	v24, v20, v24
    2a34:      	ldr	q25, [sp, #0x450]
    2a38:      	fadd.4s	v24, v24, v25
    2a3c:      	fadd.4s	v23, v23, v25
    2a40:      	fmul.4s	v23, v19, v23
    2a44:      	fmul.4s	v24, v20, v24
    2a48:      	fadd.4s	v24, v24, v27
    2a4c:      	fadd.4s	v23, v23, v27
    2a50:      	fmul.4s	v23, v19, v23
    2a54:      	fmul.4s	v24, v20, v24
    2a58:      	movi.4s	v5, #0x3f, lsl #24
    2a5c:      	fadd.4s	v24, v24, v5
    2a60:      	fadd.4s	v23, v23, v5
    2a64:      	fmul.4s	v25, v20, v20
    2a68:      	fmul.4s	v26, v19, v19
    2a6c:      	fmul.4s	v23, v26, v23
    2a70:      	fmul.4s	v24, v25, v24
    2a74:      	fadd.4s	v20, v20, v24
    2a78:      	fadd.4s	v19, v19, v23
    2a7c:      	fadd.4s	v19, v19, v31
    2a80:      	fadd.4s	v20, v20, v31
    2a84:      	sshr.4s	v23, v22, #0x1
    2a88:      	sshr.4s	v24, v21, #0x1
    2a8c:      	shl.4s	v25, v24, #0x17
    2a90:      	shl.4s	v26, v23, #0x17
    2a94:      	add.4s	v26, v26, v31
    2a98:      	add.4s	v25, v25, v31
    2a9c:      	fmul.4s	v20, v20, v25
    2aa0:      	fmul.4s	v19, v19, v26
    2aa4:      	sub.4s	v21, v21, v24
    2aa8:      	sub.4s	v22, v22, v23
    2aac:      	shl.4s	v22, v22, #0x17
    2ab0:      	shl.4s	v21, v21, #0x17
    2ab4:      	add.4s	v21, v21, v31
    2ab8:      	add.4s	v22, v22, v31
    2abc:      	fmul.4s	v19, v19, v22
    2ac0:      	fmul.4s	v20, v20, v21
    2ac4:      	fcmgt.4s	v21, v29, v18
    2ac8:      	bic.16b	v20, v20, v21
    2acc:      	fcmgt.4s	v21, v29, v4
    2ad0:      	bic.16b	v19, v19, v21
    2ad4:      	fcmgt.4s	v21, v18, v9
    2ad8:      	fcmgt.4s	v22, v4, v9
    2adc:      	bit.16b	v19, v8, v22
    2ae0:      	bit.16b	v20, v8, v21
    2ae4:      	fcmeq.4s	v4, v4, v4
    2ae8:      	fcmeq.4s	v18, v18, v18
    2aec:      	bsl.16b	v18, v20, v12
    2af0:      	bsl.16b	v4, v19, v12
    2af4:      	bic.16b	v4, v4, v1
    2af8:      	bic.16b	v5, v18, v0
    2afc:      	add	x8, x25, x17
    2b00:      	ldp	q0, q1, [x8]
    2b04:      	str	q5, [sp, #0x450]
    2b08:      	bit.16b	v1, v5, v2
    2b0c:      	str	q4, [sp, #0x460]
    2b10:      	bit.16b	v0, v4, v3
    2b14:      	stp	q0, q1, [x8]
    2b18:      	ldr	x8, [sp, #0x138]
    2b1c:      	ldp	q0, q1, [x8, #0x40]
    2b20:      	and.16b	v1, v13, v1
    2b24:      	and.16b	v18, v14, v0
    2b28:      	ldp	q0, q2, [x8, #0x20]
    2b2c:      	and.16b	v25, v13, v2
    2b30:      	and.16b	v19, v14, v0
    2b34:      	ldp	q0, q2, [x8]
    2b38:      	and.16b	v26, v13, v2
    2b3c:      	and.16b	v28, v14, v0
    2b40:      	ldr	x8, [sp, #0x88]
    2b44:      	add	x8, x25, x8
    2b48:      	ldp	q0, q2, [x8]
    2b4c:      	and.16b	v3, v13, v2
    2b50:      	and.16b	v2, v14, v0
    2b54:      	ldp	q6, q5, [sp, #0x1d0]
    2b58:      	ldp	q30, q29, [sp, #0xc0]
    2b5c:      	ldp	q12, q15, [sp, #0xa0]
    2b60:      	sshll.2d	v0, v14, #0x0
    2b64:      	sshll.2d	v21, v13, #0x0
    2b68:      	add	x8, x25, x15, lsl #5
    2b6c:      	ldp	q4, q20, [x8]
    2b70:      	fadd.4s	v4, v2, v4
    2b74:      	fadd.4s	v20, v3, v20
    2b78:      	ldp	q23, q22, [x8, #0x20]
    2b7c:      	fadd.4s	v23, v28, v23
    2b80:      	fadd.4s	v22, v26, v22
    2b84:      	ldp	q27, q24, [x8, #0x40]
    2b88:      	fadd.4s	v27, v19, v27
    2b8c:      	fadd.4s	v24, v25, v24
    2b90:      	ldp	q8, q31, [x8, #0x60]
    2b94:      	fadd.4s	v8, v18, v8
    2b98:      	fadd.4s	v31, v1, v31
    2b9c:      	dup.2d	v9, x9
    2ba0:      	and.16b	v10, v6, v9
    2ba4:      	add.2d	v29, v29, v10
    2ba8:      	and.16b	v10, v5, v9
    2bac:      	add.2d	v30, v30, v10
    2bb0:      	and.16b	v21, v21, v9
    2bb4:      	add.2d	v15, v15, v21
    2bb8:      	and.16b	v0, v0, v9
    2bbc:      	add.2d	v12, v12, v0
    2bc0:      	bit.16b	v3, v20, v13
    2bc4:      	bit.16b	v2, v4, v14
    2bc8:      	bit.16b	v26, v22, v13
    2bcc:      	bit.16b	v28, v23, v14
    2bd0:      	bit.16b	v25, v24, v13
    2bd4:      	bit.16b	v19, v27, v14
    2bd8:      	bit.16b	v1, v31, v13
    2bdc:      	bit.16b	v18, v8, v14
    2be0:      	fmov	x15, d12
    2be4:      	cmp	x15, #0x200
    2be8:      	b.lt	0x2b60 <ltmp0+0x2b60>
    2bec:      	mov	x15, #0x0               ; =0
    2bf0:      	adrp	x8, 0x2000 <ltmp0+0x2000>
    2bf4:      	ldr	q0, [x8]
    2bf8:      	and.16b	v31, v13, v0
    2bfc:      	adrp	x8, 0x2000 <ltmp0+0x2000>
    2c00:      	ldr	q0, [x8]
    2c04:      	and.16b	v21, v14, v0
    2c08:      	adrp	x8, 0x2000 <ltmp0+0x2000>
    2c0c:      	ldr	q0, [x8]
    2c10:      	and.16b	v0, v14, v0
    2c14:      	ldr	q5, [sp, #0x450]
    2c18:      	fadd.4s	v3, v5, v3
    2c1c:      	ldr	q5, [sp, #0x460]
    2c20:      	fadd.4s	v2, v5, v2
    2c24:      	ldr	q29, [sp, #0x250]
    2c28:      	zip1.8b	v22, v29, v0
    2c2c:      	ushll.4s	v22, v22, #0x0
    2c30:      	shl.4s	v22, v22, #0x1f
    2c34:      	cmlt.4s	v22, v22, #0
    2c38:      	and.16b	v2, v22, v2
    2c3c:      	zip2.8b	v22, v29, v0
    2c40:      	ushll.4s	v22, v22, #0x0
    2c44:      	shl.4s	v22, v22, #0x1f
    2c48:      	cmlt.4s	v22, v22, #0
    2c4c:      	and.16b	v3, v22, v3
    2c50:      	ldr	q5, [sp, #0x2f0]
    2c54:      	zip2.8b	v22, v5, v0
    2c58:      	ushll.4s	v22, v22, #0x0
    2c5c:      	shl.4s	v22, v22, #0x1f
    2c60:      	cmlt.4s	v22, v22, #0
    2c64:      	bit.16b	v3, v20, v22
    2c68:      	zip1.8b	v20, v5, v0
    2c6c:      	ushll.4s	v20, v20, #0x0
    2c70:      	shl.4s	v20, v20, #0x1f
    2c74:      	cmlt.4s	v20, v20, #0
    2c78:      	bit.16b	v2, v4, v20
    2c7c:      	fadd.4s	v2, v28, v2
    2c80:      	fadd.4s	v3, v26, v3
    2c84:      	fadd.4s	v3, v25, v3
    2c88:      	fadd.4s	v2, v19, v2
    2c8c:      	fadd.4s	v18, v18, v2
    2c90:      	fadd.4s	v19, v1, v3
    2c94:      	fmov	w8, s21
    2c98:      	add	x9, sp, #0x4f8
    2c9c:      	bfxil	x9, x8, #0, #3
    2ca0:      	ldr	q1, [sp, #0x300]
    2ca4:      	str	d1, [sp, #0x4f8]
    2ca8:      	ldrb	w9, [x9]
    2cac:      	add	x12, sp, #0x720
    2cb0:      	orr	x8, x12, x8, lsl #2
    2cb4:      	str	q19, [sp, #0x730]
    2cb8:      	str	q18, [sp, #0x720]
    2cbc:      	ldr	s1, [x8]
    2cc0:      	tst	w22, w9
    2cc4:      	movi	d5, #0000000000000000
    2cc8:      	fcsel	s1, s1, s5, ne
    2ccc:      	mov.s	w8, v21[1]
    2cd0:      	add	x9, sp, #0x4f8
    2cd4:      	bfxil	x9, x8, #0, #3
    2cd8:      	ldrb	w8, [x9]
    2cdc:      	and	w8, w2, w8
    2ce0:      	str	q18, [sp, #0x700]
    2ce4:      	ldr	s2, [sp, #0x700]
    2ce8:      	tst	w8, #0x1
    2cec:      	fcsel	s2, s2, s5, ne
    2cf0:      	mov.s	w8, v21[2]
    2cf4:      	add	x9, sp, #0x4f8
    2cf8:      	bfxil	x9, x8, #0, #3
    2cfc:      	add	x12, sp, #0x6e0
    2d00:      	orr	x8, x12, x8, lsl #2
    2d04:      	ldrb	w9, [x9]
    2d08:      	and	w9, w1, w9
    2d0c:      	str	q19, [sp, #0x6f0]
    2d10:      	str	q18, [sp, #0x6e0]
    2d14:      	ldr	s3, [x8]
    2d18:      	tst	w9, #0x1
    2d1c:      	fcsel	s3, s3, s5, ne
    2d20:      	mov.s	w8, v21[3]
    2d24:      	add	x9, sp, #0x4f8
    2d28:      	bfxil	x9, x8, #0, #3
    2d2c:      	add	x12, sp, #0x6c0
    2d30:      	orr	x8, x12, x8, lsl #2
    2d34:      	ldrb	w9, [x9]
    2d38:      	and	w9, w3, w9
    2d3c:      	str	q19, [sp, #0x6d0]
    2d40:      	str	q18, [sp, #0x6c0]
    2d44:      	ldr	s4, [x8]
    2d48:      	tst	w9, #0x1
    2d4c:      	fcsel	s4, s4, s5, ne
    2d50:      	fmov	w8, s31
    2d54:      	add	x9, sp, #0x4f8
    2d58:      	bfxil	x9, x8, #0, #3
    2d5c:      	ldrb	w9, [x9]
    2d60:      	and	w9, w5, w9
    2d64:      	str	q19, [sp, #0x6b0]
    2d68:      	str	q18, [sp, #0x6a0]
    2d6c:      	add	x12, sp, #0x6a0
    2d70:      	ldr	s20, [x12, w8, uxtw #2]
    2d74:      	tst	w9, #0x1
    2d78:      	fcsel	s20, s20, s5, ne
    2d7c:      	mov.s	w8, v31[1]
    2d80:      	add	x9, sp, #0x4f8
    2d84:      	bfxil	x9, x8, #0, #3
    2d88:      	ldrb	w9, [x9]
    2d8c:      	and	w9, w19, w9
    2d90:      	str	q19, [sp, #0x690]
    2d94:      	str	q18, [sp, #0x680]
    2d98:      	add	x12, sp, #0x680
    2d9c:      	ldr	s21, [x12, w8, uxtw #2]
    2da0:      	tst	w9, #0x1
    2da4:      	fcsel	s21, s21, s5, ne
    2da8:      	mov.s	w8, v31[2]
    2dac:      	add	x9, sp, #0x4f8
    2db0:      	bfxil	x9, x8, #0, #3
    2db4:      	ldrb	w9, [x9]
    2db8:      	and	w9, w13, w9
    2dbc:      	str	q19, [sp, #0x670]
    2dc0:      	str	q18, [sp, #0x660]
    2dc4:      	add	x12, sp, #0x660
    2dc8:      	ldr	s22, [x12, w8, uxtw #2]
    2dcc:      	tst	w9, #0x1
    2dd0:      	fcsel	s22, s22, s5, ne
    2dd4:      	mov.s	w8, v31[3]
    2dd8:      	add	x9, sp, #0x4f8
    2ddc:      	bfxil	x9, x8, #0, #3
    2de0:      	ldrb	w9, [x9]
    2de4:      	and	w9, w0, w9
    2de8:      	str	q19, [sp, #0x650]
    2dec:      	str	q18, [sp, #0x640]
    2df0:      	add	x12, sp, #0x640
    2df4:      	ldr	s23, [x12, w8, uxtw #2]
    2df8:      	tst	w9, #0x1
    2dfc:      	fcsel	s23, s23, s5, ne
    2e00:      	mov.s	v20[1], v21[0]
    2e04:      	mov.s	v20[2], v22[0]
    2e08:      	mov.s	v20[3], v23[0]
    2e0c:      	mov.s	v1[1], v2[0]
    2e10:      	mov.s	v1[2], v3[0]
    2e14:      	mov.s	v1[3], v4[0]
    2e18:      	fadd.4s	v1, v18, v1
    2e1c:      	fadd.4s	v18, v19, v20
    2e20:      	fmov	w8, s0
    2e24:      	add	x9, sp, #0x4f8
    2e28:      	bfxil	x9, x8, #0, #3
    2e2c:      	ldrb	w9, [x9]
    2e30:      	add	x12, sp, #0x620
    2e34:      	orr	x8, x12, x8, lsl #2
    2e38:      	str	q18, [sp, #0x630]
    2e3c:      	str	q1, [sp, #0x620]
    2e40:      	ldr	s2, [x8]
    2e44:      	mov.s	w8, v0[1]
    2e48:      	tst	w22, w9
    2e4c:      	add	x9, sp, #0x4f8
    2e50:      	bfxil	x9, x8, #0, #3
    2e54:      	ldrb	w9, [x9]
    2e58:      	and	w9, w2, w9
    2e5c:      	fcsel	s2, s2, s5, ne
    2e60:      	add	x12, sp, #0x600
    2e64:      	orr	x8, x12, x8, lsl #2
    2e68:      	str	q18, [sp, #0x610]
    2e6c:      	str	q1, [sp, #0x600]
    2e70:      	ldr	s4, [x8]
    2e74:      	mov.s	w8, v0[2]
    2e78:      	tst	w9, #0x1
    2e7c:      	add	x9, sp, #0x4f8
    2e80:      	bfxil	x9, x8, #0, #3
    2e84:      	adrp	x8, 0x2000 <ltmp0+0x2000>
    2e88:      	ldr	q3, [x8]
    2e8c:      	and.16b	v20, v13, v3
    2e90:      	movi.4s	v3, #0x4
    2e94:      	and.16b	v3, v14, v3
    2e98:      	fcsel	s4, s4, s5, ne
    2e9c:      	ldrb	w8, [x9]
    2ea0:      	and	w8, w1, w8
    2ea4:      	str	q1, [sp, #0x5e0]
    2ea8:      	ldr	s19, [sp, #0x5e0]
    2eac:      	tst	w8, #0x1
    2eb0:      	fcsel	s19, s19, s5, ne
    2eb4:      	mov.s	w8, v0[3]
    2eb8:      	add	x9, sp, #0x4f8
    2ebc:      	bfxil	x9, x8, #0, #3
    2ec0:      	add	x12, sp, #0x5c0
    2ec4:      	orr	x8, x12, x8, lsl #2
    2ec8:      	ldrb	w9, [x9]
    2ecc:      	and	w9, w3, w9
    2ed0:      	str	q18, [sp, #0x5d0]
    2ed4:      	str	q1, [sp, #0x5c0]
    2ed8:      	ldr	s0, [x8]
    2edc:      	tst	w9, #0x1
    2ee0:      	fcsel	s0, s0, s5, ne
    2ee4:      	fmov	w8, s20
    2ee8:      	add	x9, sp, #0x4f8
    2eec:      	bfxil	x9, x8, #0, #3
    2ef0:      	ldrb	w9, [x9]
    2ef4:      	and	w9, w5, w9
    2ef8:      	str	q18, [sp, #0x5b0]
    2efc:      	str	q1, [sp, #0x5a0]
    2f00:      	add	x12, sp, #0x5a0
    2f04:      	ldr	s21, [x12, w8, uxtw #2]
    2f08:      	tst	w9, #0x1
    2f0c:      	fcsel	s21, s21, s5, ne
    2f10:      	mov.s	w8, v20[1]
    2f14:      	add	x9, sp, #0x4f8
    2f18:      	bfxil	x9, x8, #0, #3
    2f1c:      	ldrb	w9, [x9]
    2f20:      	and	w9, w19, w9
    2f24:      	str	q18, [sp, #0x590]
    2f28:      	str	q1, [sp, #0x580]
    2f2c:      	add	x12, sp, #0x580
    2f30:      	ldr	s22, [x12, w8, uxtw #2]
    2f34:      	tst	w9, #0x1
    2f38:      	fcsel	s22, s22, s5, ne
    2f3c:      	mov.s	w8, v20[2]
    2f40:      	add	x9, sp, #0x4f8
    2f44:      	bfxil	x9, x8, #0, #3
    2f48:      	ldrb	w9, [x9]
    2f4c:      	and	w9, w13, w9
    2f50:      	str	q18, [sp, #0x570]
    2f54:      	str	q1, [sp, #0x560]
    2f58:      	add	x12, sp, #0x560
    2f5c:      	ldr	s23, [x12, w8, uxtw #2]
    2f60:      	tst	w9, #0x1
    2f64:      	fcsel	s23, s23, s5, ne
    2f68:      	mov.s	w8, v20[3]
    2f6c:      	add	x9, sp, #0x4f8
    2f70:      	bfxil	x9, x8, #0, #3
    2f74:      	ldrb	w9, [x9]
    2f78:      	and	w9, w0, w9
    2f7c:      	str	q18, [sp, #0x550]
    2f80:      	str	q1, [sp, #0x540]
    2f84:      	add	x12, sp, #0x540
    2f88:      	ldr	s20, [x12, w8, uxtw #2]
    2f8c:      	tst	w9, #0x1
    2f90:      	fcsel	s20, s20, s5, ne
    2f94:      	mov.s	v21[1], v22[0]
    2f98:      	mov.s	v21[2], v23[0]
    2f9c:      	mov.s	v21[3], v20[0]
    2fa0:      	mov.s	v2[1], v4[0]
    2fa4:      	mov.s	v2[2], v19[0]
    2fa8:      	mov.s	v2[3], v0[0]
    2fac:      	fadd.4s	v0, v1, v2
    2fb0:      	fadd.4s	v1, v18, v21
    2fb4:      	fmov	w8, s3
    2fb8:      	add	x9, sp, #0x4f8
    2fbc:      	orr	x9, x9, x8
    2fc0:      	ldrb	w9, [x9]
    2fc4:      	str	q1, [sp, #0x530]
    2fc8:      	str	q0, [sp, #0x520]
    2fcc:      	add	x12, sp, #0x520
    2fd0:      	ldr	s1, [x12, w8, uxtw #2]
    2fd4:      	tst	w22, w9
    2fd8:      	fcsel	s1, s1, s5, ne
    2fdc:      	tst	w7, #0x1
    2fe0:      	fadd	s0, s0, s1
    2fe4:      	fcsel	s1, s0, s5, ne
    2fe8:      	tst	w20, #0x1
    2fec:      	fcsel	s2, s0, s5, ne
    2ff0:      	tst	w21, #0x1
    2ff4:      	fcsel	s3, s0, s5, ne
    2ff8:      	tst	w23, #0x1
    2ffc:      	fcsel	s4, s0, s5, ne
    3000:      	tst	w24, #0x1
    3004:      	fcsel	s18, s0, s5, ne
    3008:      	tst	w26, #0x1
    300c:      	fcsel	s19, s0, s5, ne
    3010:      	tst	w28, #0x1
    3014:      	fcsel	s20, s0, s5, ne
    3018:      	tst	w10, #0x1
    301c:      	fcsel	s0, s0, s5, ne
    3020:      	mov.s	v1[1], v2[0]
    3024:      	mov.s	v1[2], v3[0]
    3028:      	mov.s	v1[3], v4[0]
    302c:      	mov.s	v18[1], v19[0]
    3030:      	mov.s	v18[2], v20[0]
    3034:      	mov.s	v18[3], v0[0]
    3038:      	str	q18, [sp, #0x510]
    303c:      	str	q1, [sp, #0x500]
    3040:      	and	x8, x27, #0x7
    3044:      	add	x9, sp, #0x500
    3048:      	ldr	s0, [x9, x8, lsl #2]
    304c:      	fadd	s0, s0, s5
    3050:      	dup.4s	v0, v0[0]
    3054:      	ldp	q1, q20, [sp, #0x140]
    3058:      	fmov	x8, d1
    305c:      	ldr	x13, [sp, #0x1b8]
    3060:      	add	x8, x13, x8, lsl #2
    3064:      	movi.2d	v1, #0000000000000000
    3068:      	movi.2d	v2, #0000000000000000
    306c:      	movi.2d	v3, #0000000000000000
    3070:      	movi.2d	v4, #0000000000000000
    3074:      	ldr	x2, [sp, #0x228]
    3078:      	ldp	q25, q23, [sp, #0x3a0]
    307c:      	ldp	q27, q24, [sp, #0x3e0]
    3080:      	ldr	q26, [sp, #0x390]
    3084:      	ldr	q21, [sp, #0x1f0]
    3088:      	ldr	q9, [sp, #0x1c0]
    308c:      	b	0x30b4 <ltmp0+0x30b4>
    3090:      	ldr	q6, [sp, #0x320]
    3094:      	add.2d	v2, v2, v6
    3098:      	add.2d	v3, v3, v20
    309c:      	add.2d	v4, v4, v5
    30a0:      	ldr	q5, [sp, #0x310]
    30a4:      	add.2d	v1, v1, v5
    30a8:      	fmov	x15, d1
    30ac:      	cmp	x15, #0x200
    30b0:      	b.ge	0x316c <ltmp0+0x316c>
    30b4:      	fmov	w10, s21
    30b8:      	lsl	x9, x15, #5
    30bc:      	add	x12, x25, x9
    30c0:      	ldp	q19, q18, [x12]
    30c4:      	and.16b	v19, v14, v19
    30c8:      	fdiv.4s	v19, v19, v0
    30cc:      	add	x9, x8, x9
    30d0:      	tbnz	w10, #0x0, 0x3104 <ltmp0+0x3104>
    30d4:      	and	w10, w10, #0xff
    30d8:      	tbnz	w10, #0x1, 0x3110 <ltmp0+0x3110>
    30dc:      	tbnz	w10, #0x2, 0x311c <ltmp0+0x311c>
    30e0:      	tbnz	w10, #0x3, 0x3128 <ltmp0+0x3128>
    30e4:      	and.16b	v18, v13, v18
    30e8:      	fdiv.4s	v18, v18, v0
    30ec:      	tbnz	w10, #0x4, 0x313c <ltmp0+0x313c>
    30f0:      	ldr	q5, [sp, #0x330]
    30f4:      	tbnz	w10, #0x5, 0x3148 <ltmp0+0x3148>
    30f8:      	tbnz	w10, #0x6, 0x3154 <ltmp0+0x3154>
    30fc:      	tbz	w10, #0x7, 0x3090 <ltmp0+0x3090>
    3100:      	b	0x3160 <ltmp0+0x3160>
    3104:      	str	s19, [x9]
    3108:      	and	w10, w10, #0xff
    310c:      	tbz	w10, #0x1, 0x30dc <ltmp0+0x30dc>
    3110:      	add	x12, x9, #0x4
    3114:      	st1.s	{ v19 }[1], [x12]
    3118:      	tbz	w10, #0x2, 0x30e0 <ltmp0+0x30e0>
    311c:      	add	x12, x9, #0x8
    3120:      	st1.s	{ v19 }[2], [x12]
    3124:      	tbz	w10, #0x3, 0x30e4 <ltmp0+0x30e4>
    3128:      	add	x12, x9, #0xc
    312c:      	st1.s	{ v19 }[3], [x12]
    3130:      	and.16b	v18, v13, v18
    3134:      	fdiv.4s	v18, v18, v0
    3138:      	tbz	w10, #0x4, 0x30f0 <ltmp0+0x30f0>
    313c:      	str	s18, [x9, #0x10]
    3140:      	ldr	q5, [sp, #0x330]
    3144:      	tbz	w10, #0x5, 0x30f8 <ltmp0+0x30f8>
    3148:      	add	x12, x9, #0x14
    314c:      	st1.s	{ v18 }[1], [x12]
    3150:      	tbz	w10, #0x6, 0x30fc <ltmp0+0x30fc>
    3154:      	add	x12, x9, #0x18
    3158:      	st1.s	{ v18 }[2], [x12]
    315c:      	tbz	w10, #0x7, 0x3090 <ltmp0+0x3090>
    3160:      	add	x9, x9, #0x1c
    3164:      	st1.s	{ v18 }[3], [x9]
    3168:      	b	0x3090 <ltmp0+0x3090>
    316c:      	add	x8, x25, x17
    3170:      	ldp	q2, q1, [x8]
    3174:      	zip1.8b	v3, v29, v0
    3178:      	ushll.4s	v3, v3, #0x0
    317c:      	shl.4s	v3, v3, #0x1f
    3180:      	cmlt.4s	v3, v3, #0
    3184:      	and.16b	v2, v3, v2
    3188:      	ldr	d3, [sp, #0x208]
    318c:      	fmov	w8, s3
    3190:      	fdiv.4s	v2, v2, v0
    3194:      	ldr	q3, [sp, #0x1a0]
    3198:      	str	q3, [sp, #0x4b0]
    319c:      	ldp	q3, q4, [sp, #0x160]
    31a0:      	str	q4, [sp, #0x4c0]
    31a4:      	str	q3, [sp, #0x4d0]
    31a8:      	ldr	q3, [sp, #0x180]
    31ac:      	str	q3, [sp, #0x4e0]
    31b0:      	and	x9, x16, #0x7
    31b4:      	add	x10, sp, #0x4b0
    31b8:      	ldr	x9, [x10, x9, lsl #3]
    31bc:      	sub	x9, x9, x16
    31c0:      	add	x9, x13, x9, lsl #2
    31c4:      	tbnz	w8, #0x0, 0x3254 <ltmp0+0x3254>
    31c8:      	tbnz	w8, #0x1, 0x325c <ltmp0+0x325c>
    31cc:      	ldr	q8, [sp, #0x2c0]
    31d0:      	tbnz	w8, #0x2, 0x326c <ltmp0+0x326c>
    31d4:      	tbz	w8, #0x3, 0x31e0 <ltmp0+0x31e0>
    31d8:      	add	x10, x9, #0xc
    31dc:      	st1.s	{ v2 }[3], [x10]
    31e0:      	zip2.8b	v2, v29, v0
    31e4:      	ushll.4s	v2, v2, #0x0
    31e8:      	shl.4s	v2, v2, #0x1f
    31ec:      	cmlt.4s	v2, v2, #0
    31f0:      	and.16b	v1, v2, v1
    31f4:      	fdiv.4s	v0, v1, v0
    31f8:      	tbnz	w8, #0x4, 0x327c <ltmp0+0x327c>
    31fc:      	tbnz	w8, #0x5, 0x3284 <ltmp0+0x3284>
    3200:      	tbnz	w8, #0x6, 0x3290 <ltmp0+0x3290>
    3204:      	tbz	w8, #0x7, 0xf4 <ltmp0+0xf4>
    3208:      	b	0x329c <ltmp0+0x329c>
    320c:      	fmov	x9, d3
    3210:      	ld1.b	{ v0 }[2], [x9]
    3214:      	tbz	w8, #0x3, 0x2914 <ltmp0+0x2914>
    3218:      	ldr	x9, [sp, #0x18]
    321c:      	ld1.b	{ v0 }[3], [x9]
    3220:      	tbz	w8, #0x4, 0x2918 <ltmp0+0x2918>
    3224:      	fmov	x9, d2
    3228:      	ld1.b	{ v0 }[4], [x9]
    322c:      	tbz	w8, #0x5, 0x291c <ltmp0+0x291c>
    3230:      	ldr	x9, [sp, #0x20]
    3234:      	ld1.b	{ v0 }[5], [x9]
    3238:      	tbz	w8, #0x6, 0x2920 <ltmp0+0x2920>
    323c:      	fmov	x9, d1
    3240:      	ld1.b	{ v0 }[6], [x9]
    3244:      	mov	w9, #0x4                ; =4
    3248:      	str	q10, [sp, #0x150]
    324c:      	tbnz	w8, #0x7, 0x292c <ltmp0+0x292c>
    3250:      	b	0x2934 <ltmp0+0x2934>
    3254:      	str	s2, [x9]
    3258:      	tbz	w8, #0x1, 0x31cc <ltmp0+0x31cc>
    325c:      	add	x10, x9, #0x4
    3260:      	st1.s	{ v2 }[1], [x10]
    3264:      	ldr	q8, [sp, #0x2c0]
    3268:      	tbz	w8, #0x2, 0x31d4 <ltmp0+0x31d4>
    326c:      	add	x10, x9, #0x8
    3270:      	st1.s	{ v2 }[2], [x10]
    3274:      	tbnz	w8, #0x3, 0x31d8 <ltmp0+0x31d8>
    3278:      	b	0x31e0 <ltmp0+0x31e0>
    327c:      	str	s0, [x9, #0x10]
    3280:      	tbz	w8, #0x5, 0x3200 <ltmp0+0x3200>
    3284:      	add	x10, x9, #0x14
    3288:      	st1.s	{ v0 }[1], [x10]
    328c:      	tbz	w8, #0x6, 0x3204 <ltmp0+0x3204>
    3290:      	add	x10, x9, #0x18
    3294:      	st1.s	{ v0 }[2], [x10]
    3298:      	tbz	w8, #0x7, 0xf4 <ltmp0+0xf4>
    329c:      	add	x8, x9, #0x1c
    32a0:      	st1.s	{ v0 }[3], [x8]
    32a4:      	b	0xf4 <ltmp0+0xf4>
    32a8:      	stp	w17, w16, [x2]
    32ac:      	str	w15, [x2, #0x8]
    32b0:      	mov	w8, #0x18               ; =24
    32b4:      	str	w8, [x2, #0x24]
    32b8:      	add	sp, sp, #0xb50
    32bc:      	ldp	x29, x30, [sp, #0x90]
    32c0:      	ldp	x20, x19, [sp, #0x80]
    32c4:      	ldp	x22, x21, [sp, #0x70]
    32c8:      	ldp	x24, x23, [sp, #0x60]
    32cc:      	ldp	x26, x25, [sp, #0x50]
    32d0:      	ldp	x28, x27, [sp, #0x40]
    32d4:      	ldp	d9, d8, [sp, #0x30]
    32d8:      	ldp	d11, d10, [sp, #0x20]
    32dc:      	ldp	d13, d12, [sp, #0x10]
    32e0:      	ldp	d15, d14, [sp], #0xa0
    32e4:      	ret

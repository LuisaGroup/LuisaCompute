
/private/tmp/luisa-packet-inline.UY1lIE/capture/rope-17x66/on/object/tile_xir_w8_36477_1788935107263024_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x3bb0 <ltmp0+0x3bb0>
       4:      	stp	d15, d14, [sp, #-0xa0]!
       8:      	stp	d13, d12, [sp, #0x10]
       c:      	stp	d11, d10, [sp, #0x20]
      10:      	stp	d9, d8, [sp, #0x30]
      14:      	stp	x28, x27, [sp, #0x40]
      18:      	stp	x26, x25, [sp, #0x50]
      1c:      	stp	x24, x23, [sp, #0x60]
      20:      	stp	x22, x21, [sp, #0x70]
      24:      	stp	x20, x19, [sp, #0x80]
      28:      	stp	x29, x30, [sp, #0x90]
      2c:      	sub	sp, sp, #0x850
      30:      	mov	w8, #0x0                ; =0
      34:      	mov	w9, #0x20               ; =32
      38:      	mov	w10, #0x230             ; =560
      3c:      	mov	w11, #0x8c3             ; =2243
      40:      	ldp	w12, w13, [x2, #0x2c]
      44:      	mov	w14, #0x18              ; =24
      48:      	ldp	w20, w16, [x2, #0x4]
      4c:      	adrp	x17, 0x0 <ltmp0>
      50:      	ldr	w6, [x2]
      54:      	mov	w15, #0x40              ; =64
      58:      	fmov	d0, x15
      5c:      	str	q0, [sp, #0x20]
      60:      	mov	w15, #0x60              ; =96
      64:      	fmov	d0, x15
      68:      	str	q0, [sp, #0x10]
      6c:      	add	x28, sp, #0x7b0
      70:      	add	x26, sp, #0x710
      74:      	add	x24, sp, #0x670
      78:      	add	x27, sp, #0x5d0
      7c:      	b	0xbc <ltmp0+0xbc>
      80:      	st1.s	{ v0 }[3], [x15]
      84:      	str	w14, [x2, #0x24]
      88:      	add	w15, w6, #0x1
      8c:      	cmp	w15, w12
      90:      	cset	w15, eq
      94:      	csinc	w6, wzr, w6, eq
      98:      	cinc	w1, w20, eq
      9c:      	cmp	w1, w13
      a0:      	cset	w4, eq
      a4:      	ands	w15, w15, w4
      a8:      	csel	w20, wzr, w1, ne
      ac:      	add	w16, w16, w15
      b0:      	add	w8, w8, #0x1
      b4:      	cmp	w8, w3
      b8:      	b.eq	0x3b84 <ltmp0+0x3b84>
      bc:      	ldr	w15, [x2, #0xc]
      c0:      	ubfiz	x1, x6, #5, #32
      c4:      	cmp	x1, x15
      c8:      	csel	x4, x1, xzr, ls
      cc:      	subs	x5, x15, x4
      d0:      	cmp	x5, #0x20
      d4:      	csel	x5, x5, x9, lo
      d8:      	cmp	x15, x4
      dc:      	stp	w6, w20, [x2]
      e0:      	str	w16, [x2, #0x8]
      e4:      	ccmp	x1, x15, #0x2, hi
      e8:      	csel	x1, x5, xzr, ls
      ec:      	cmp	x1, #0x20
      f0:      	b.lo	0x50c <ltmp0+0x50c>
      f4:      	mov	x1, #0x0                ; =0
      f8:      	ldr	x15, [x0]
      fc:      	ldr	x21, [x0, #0x10]
     100:      	ldr	x19, [x0, #0x20]
     104:      	ldr	x7, [x0, #0x30]
     108:      	subs	x4, x15, x7
     10c:      	lsr	x4, x4, #3
     110:      	ccmp	x4, x10, #0x0, hs
     114:      	cset	w4, hi
     118:      	subs	x5, x7, x15
     11c:      	lsr	x5, x5, #3
     120:      	ccmp	x5, x10, #0x0, hs
     124:      	csinc	w4, w4, wzr, ls
     128:      	subs	x5, x21, x7
     12c:      	lsr	x5, x5, #3
     130:      	ccmp	x5, x10, #0x0, hs
     134:      	cset	w5, hi
     138:      	subs	x22, x7, x21
     13c:      	ccmp	x22, x11, #0x0, hs
     140:      	csinc	w5, w5, wzr, ls
     144:      	and	w4, w4, w5
     148:      	subs	x5, x19, x7
     14c:      	lsr	x5, x5, #3
     150:      	ccmp	x5, x10, #0x0, hs
     154:      	cset	w5, hi
     158:      	subs	x22, x7, x19
     15c:      	ccmp	x22, x11, #0x0, hs
     160:      	csinc	w5, w5, wzr, ls
     164:      	and	w4, w5, w4
     168:      	and	x5, x6, #0x7ffffff
     16c:      	add	x22, x5, x5, lsl #5
     170:      	lsl	x23, x22, #5
     174:      	add	x5, x15, x23
     178:      	add	x7, x7, x23
     17c:      	lsl	x15, x22, #4
     180:      	add	x19, x19, x15
     184:      	add	x19, x19, #0x40
     188:      	add	x15, x21, x15
     18c:      	add	x21, x15, #0x40
     190:      	b	0x390 <ltmp0+0x390>
     194:      	ldp	q5, q16, [x22, #0x20]
     198:      	stp	q16, q5, [sp, #0x170]
     19c:      	ldp	q0, q3, [x22, #0x40]
     1a0:      	str	q3, [sp, #0x190]
     1a4:      	ldur	q19, [x22, #0x84]
     1a8:      	ldur	q23, [x22, #0x94]
     1ac:      	ldur	q17, [x22, #0xa4]
     1b0:      	str	q17, [sp, #0x160]
     1b4:      	ldur	q18, [x22, #0xb4]
     1b8:      	stp	q19, q18, [sp, #0x140]
     1bc:      	ldur	q4, [x22, #0xc4]
     1c0:      	ldur	q7, [x22, #0xd4]
     1c4:      	stp	q7, q4, [sp, #0x1d0]
     1c8:      	ldp	q28, q29, [x21, #-0x40]
     1cc:      	ldp	q24, q21, [x21, #-0x20]
     1d0:      	stp	q0, q24, [sp, #0x1b0]
     1d4:      	ldp	q20, q22, [x21]
     1d8:      	stp	q22, q20, [sp, #0x1f0]
     1dc:      	fmul.4s	v30, v6, v29
     1e0:      	fmul.4s	v31, v27, v28
     1e4:      	ldp	q2, q1, [x19, #-0x40]
     1e8:      	fmul.4s	v8, v23, v1
     1ec:      	fmul.4s	v9, v19, v2
     1f0:      	fsub.4s	v19, v31, v9
     1f4:      	str	q19, [sp, #0x1a0]
     1f8:      	ldp	q11, q15, [x19, #-0x20]
     1fc:      	fsub.4s	v19, v30, v8
     200:      	str	q19, [sp, #0x130]
     204:      	fmul.4s	v31, v16, v21
     208:      	fmul.4s	v8, v5, v24
     20c:      	ldp	q30, q12, [x19]
     210:      	fmul.4s	v9, v18, v15
     214:      	fmul.4s	v10, v17, v11
     218:      	fsub.4s	v19, v8, v10
     21c:      	fsub.4s	v18, v31, v9
     220:      	fmul.4s	v31, v3, v22
     224:      	fmul.4s	v8, v0, v20
     228:      	fmul.4s	v9, v7, v12
     22c:      	fmul.4s	v10, v4, v30
     230:      	fsub.4s	v17, v8, v10
     234:      	fsub.4s	v16, v31, v9
     238:      	ldp	q8, q13, [x22, #0x60]
     23c:      	ldur	q31, [x22, #0xe4]
     240:      	ldp	q9, q10, [x21, #0x20]
     244:      	ldp	q14, q3, [x19, #0x20]
     248:      	fmul.4s	v0, v8, v9
     24c:      	fmul.4s	v20, v31, v14
     250:      	fsub.4s	v7, v0, v20
     254:      	ldur	q20, [x22, #0xf4]
     258:      	fmul.4s	v0, v13, v10
     25c:      	fmul.4s	v22, v20, v3
     260:      	fsub.4s	v4, v0, v22
     264:      	ldr	s22, [x22, #0x80]
     268:      	ldp	q26, q25, [sp, #0x210]
     26c:      	mov.s	v26[0], v22[0]
     270:      	ldr	s0, [x21, #0x40]
     274:      	ldr	q24, [sp, #0x230]
     278:      	mov.s	v24[0], v0[0]
     27c:      	fmul.4s	v0, v22, v0
     280:      	ldr	s22, [x22, #0x104]
     284:      	mov.s	v25[0], v22[0]
     288:      	ldr	s5, [x19, #0x40]
     28c:      	fmul.4s	v22, v22, v5
     290:      	fsub.4s	v0, v0, v22
     294:      	fmul.4s	v1, v6, v1
     298:      	ldr	q22, [sp, #0x240]
     29c:      	mov.s	v22[0], v5[0]
     2a0:      	fmul.4s	v2, v27, v2
     2a4:      	fmul.4s	v5, v23, v29
     2a8:      	ldp	q27, q6, [sp, #0x130]
     2ac:      	fmul.4s	v6, v6, v28
     2b0:      	add	x15, x7, x1
     2b4:      	ldr	q23, [sp, #0x1a0]
     2b8:      	stp	q23, q27, [x15]
     2bc:      	fadd.4s	v2, v6, v2
     2c0:      	fadd.4s	v1, v5, v1
     2c4:      	ldp	q5, q6, [sp, #0x170]
     2c8:      	fmul.4s	v5, v5, v15
     2cc:      	stp	q19, q18, [x15, #0x20]
     2d0:      	fmul.4s	v6, v6, v11
     2d4:      	ldr	q18, [sp, #0x150]
     2d8:      	fmul.4s	v18, v18, v21
     2dc:      	ldr	q19, [sp, #0x1c0]
     2e0:      	ldr	q21, [sp, #0x160]
     2e4:      	fmul.4s	v19, v21, v19
     2e8:      	stp	q17, q16, [x15, #0x40]
     2ec:      	fadd.4s	v6, v19, v6
     2f0:      	fadd.4s	v5, v18, v5
     2f4:      	ldr	q16, [sp, #0x190]
     2f8:      	fmul.4s	v16, v16, v12
     2fc:      	stp	q7, q4, [x15, #0x60]
     300:      	ldr	q4, [sp, #0x1b0]
     304:      	fmul.4s	v4, v4, v30
     308:      	str	s0, [x15, #0x80]
     30c:      	ldp	q17, q0, [sp, #0x1e0]
     310:      	ldr	q7, [sp, #0x1d0]
     314:      	fmul.4s	v0, v7, v0
     318:      	ldr	q7, [sp, #0x200]
     31c:      	fmul.4s	v7, v17, v7
     320:      	stur	q1, [x15, #0x94]
     324:      	fadd.4s	v1, v7, v4
     328:      	stur	q2, [x15, #0x84]
     32c:      	fadd.4s	v0, v0, v16
     330:      	fmul.4s	v2, v13, v3
     334:      	stur	q5, [x15, #0xb4]
     338:      	fmul.4s	v3, v8, v14
     33c:      	stur	q6, [x15, #0xa4]
     340:      	fmul.4s	v4, v20, v10
     344:      	fmul.4s	v5, v31, v9
     348:      	stur	q0, [x15, #0xd4]
     34c:      	fadd.4s	v0, v5, v3
     350:      	stur	q1, [x15, #0xc4]
     354:      	fadd.4s	v1, v4, v2
     358:      	stp	q24, q22, [sp, #0x230]
     35c:      	stp	q26, q25, [sp, #0x210]
     360:      	fmul.4s	v2, v26, v22
     364:      	stur	q1, [x15, #0xf4]
     368:      	fmul.4s	v1, v25, v24
     36c:      	fadd.4s	v4, v1, v2
     370:      	stur	q0, [x15, #0xe4]
     374:      	add	x15, x7, x1
     378:      	str	s4, [x15, #0x104]
     37c:      	add	x1, x1, #0x108
     380:      	add	x19, x19, #0x84
     384:      	add	x21, x21, #0x84
     388:      	cmp	x1, #0x420
     38c:      	b.eq	0x84 <ltmp0+0x84>
     390:      	add	x22, x5, x1
     394:      	ldp	q27, q6, [x22]
     398:      	cbz	w4, 0x194 <ltmp0+0x194>
     39c:      	ldur	q4, [x22, #0x84]
     3a0:      	ldur	q7, [x22, #0x94]
     3a4:      	ldp	q16, q17, [x21, #-0x40]
     3a8:      	ldp	q18, q19, [x19, #-0x40]
     3ac:      	fmul.4s	v20, v6, v17
     3b0:      	fmul.4s	v21, v27, v16
     3b4:      	fmul.4s	v22, v7, v19
     3b8:      	fmul.4s	v23, v4, v18
     3bc:      	fsub.4s	v21, v21, v23
     3c0:      	fsub.4s	v20, v20, v22
     3c4:      	add	x15, x7, x1
     3c8:      	stp	q21, q20, [x15]
     3cc:      	fmul.4s	v6, v6, v19
     3d0:      	fmul.4s	v5, v27, v18
     3d4:      	fmul.4s	v7, v7, v17
     3d8:      	fmul.4s	v4, v4, v16
     3dc:      	fadd.4s	v4, v4, v5
     3e0:      	fadd.4s	v5, v7, v6
     3e4:      	stur	q5, [x15, #0x94]
     3e8:      	stur	q4, [x15, #0x84]
     3ec:      	ldp	q4, q5, [x22, #0x20]
     3f0:      	ldur	q6, [x22, #0xa4]
     3f4:      	ldur	q7, [x22, #0xb4]
     3f8:      	ldp	q16, q17, [x21, #-0x20]
     3fc:      	ldp	q18, q19, [x19, #-0x20]
     400:      	fmul.4s	v20, v5, v17
     404:      	fmul.4s	v21, v4, v16
     408:      	fmul.4s	v22, v7, v19
     40c:      	fmul.4s	v23, v6, v18
     410:      	fsub.4s	v21, v21, v23
     414:      	fsub.4s	v20, v20, v22
     418:      	stp	q21, q20, [x15, #0x20]
     41c:      	fmul.4s	v5, v5, v19
     420:      	fmul.4s	v4, v4, v18
     424:      	fmul.4s	v7, v7, v17
     428:      	fmul.4s	v6, v6, v16
     42c:      	fadd.4s	v4, v6, v4
     430:      	fadd.4s	v5, v7, v5
     434:      	stur	q5, [x15, #0xb4]
     438:      	stur	q4, [x15, #0xa4]
     43c:      	ldp	q4, q5, [x22, #0x40]
     440:      	ldur	q6, [x22, #0xc4]
     444:      	ldur	q7, [x22, #0xd4]
     448:      	ldp	q16, q17, [x21]
     44c:      	ldp	q18, q19, [x19]
     450:      	fmul.4s	v20, v5, v17
     454:      	fmul.4s	v21, v4, v16
     458:      	fmul.4s	v22, v7, v19
     45c:      	fmul.4s	v23, v6, v18
     460:      	fsub.4s	v21, v21, v23
     464:      	fsub.4s	v20, v20, v22
     468:      	stp	q21, q20, [x15, #0x40]
     46c:      	fmul.4s	v5, v5, v19
     470:      	fmul.4s	v4, v4, v18
     474:      	fmul.4s	v7, v7, v17
     478:      	fmul.4s	v6, v6, v16
     47c:      	fadd.4s	v4, v6, v4
     480:      	fadd.4s	v5, v7, v5
     484:      	stur	q5, [x15, #0xd4]
     488:      	stur	q4, [x15, #0xc4]
     48c:      	ldp	q5, q4, [x22, #0x60]
     490:      	ldur	q6, [x22, #0xf4]
     494:      	ldur	q7, [x22, #0xe4]
     498:      	ldp	q17, q16, [x21, #0x20]
     49c:      	ldp	q19, q18, [x19, #0x20]
     4a0:      	fmul.4s	v20, v5, v17
     4a4:      	fmul.4s	v21, v4, v16
     4a8:      	fmul.4s	v22, v7, v19
     4ac:      	fmul.4s	v23, v6, v18
     4b0:      	fsub.4s	v21, v21, v23
     4b4:      	fsub.4s	v20, v20, v22
     4b8:      	stp	q20, q21, [x15, #0x60]
     4bc:      	fmul.4s	v5, v5, v19
     4c0:      	fmul.4s	v4, v4, v18
     4c4:      	fmul.4s	v7, v7, v17
     4c8:      	fmul.4s	v6, v6, v16
     4cc:      	fadd.4s	v4, v6, v4
     4d0:      	fadd.4s	v5, v7, v5
     4d4:      	stur	q5, [x15, #0xe4]
     4d8:      	stur	q4, [x15, #0xf4]
     4dc:      	ldr	s4, [x22, #0x80]
     4e0:      	ldr	s5, [x22, #0x104]
     4e4:      	ldr	s6, [x21, #0x40]
     4e8:      	ldr	s7, [x19, #0x40]
     4ec:      	fmul.4s	v16, v4, v6
     4f0:      	fmul.4s	v17, v5, v7
     4f4:      	fsub.4s	v16, v16, v17
     4f8:      	str	s16, [x15, #0x80]
     4fc:      	fmul.4s	v4, v4, v7
     500:      	fmul.4s	v5, v5, v6
     504:      	fadd.4s	v4, v5, v4
     508:      	b	0x374 <ltmp0+0x374>
     50c:      	lsr	x19, x1, #3
     510:      	cmp	x1, #0x8
     514:      	b.hs	0x1028 <ltmp0+0x1028>
     518:      	and	w15, w1, #0x7
     51c:      	cbz	w15, 0x84 <ltmp0+0x84>
     520:      	lsl	w1, w19, #3
     524:      	str	w1, [x2, #0x24]
     528:      	dup.4s	v0, w15
     52c:      	adrp	x15, 0x0 <ltmp0>
     530:      	ldr	q1, [x15]
     534:      	ldr	q2, [x17]
     538:      	cmhi.4s	v21, v0, v2
     53c:      	cmhi.4s	v5, v0, v1
     540:      	uzp1.8h	v0, v5, v21
     544:      	umaxv.8h	h1, v0
     548:      	fmov	w15, s1
     54c:      	tbz	w15, #0x0, 0x84 <ltmp0+0x84>
     550:      	ldr	x7, [x0]
     554:      	ldr	x5, [x0, #0x10]
     558:      	ldr	x4, [x0, #0x20]
     55c:      	ldr	x1, [x0, #0x30]
     560:      	sshll.2d	v1, v5, #0x0
     564:      	sshll.2d	v2, v21, #0x0
     568:      	sshll2.2d	v13, v5, #0x0
     56c:      	sshll2.2d	v14, v21, #0x0
     570:      	adrp	x15, 0x0 <ltmp0>
     574:      	ldr	q3, [x15]
     578:      	and.16b	v30, v14, v3
     57c:      	adrp	x15, 0x0 <ltmp0>
     580:      	ldr	q3, [x15]
     584:      	and.16b	v31, v13, v3
     588:      	adrp	x15, 0x0 <ltmp0>
     58c:      	ldr	q3, [x15]
     590:      	and.16b	v8, v2, v3
     594:      	adrp	x15, 0x0 <ltmp0>
     598:      	ldr	q2, [x15]
     59c:      	and.16b	v20, v1, v2
     5a0:      	ubfiz	w15, w6, #2, #27
     5a4:      	orr	w15, w15, w19
     5a8:      	dup.4s	v1, w15
     5ac:      	and.16b	v2, v5, v1
     5b0:      	and.16b	v1, v21, v1
     5b4:      	ushll2.2d	v3, v1, #0x0
     5b8:      	ushll2.2d	v4, v2, #0x0
     5bc:      	ushll.2d	v1, v1, #0x0
     5c0:      	ushll.2d	v2, v2, #0x0
     5c4:      	subs	x15, x7, x1
     5c8:      	lsr	x15, x15, #3
     5cc:      	ccmp	x15, x10, #0x0, hs
     5d0:      	cset	w15, hi
     5d4:      	subs	x19, x1, x7
     5d8:      	lsr	x19, x19, #3
     5dc:      	ccmp	x19, x10, #0x0, hs
     5e0:      	csinc	w15, w15, wzr, ls
     5e4:      	subs	x19, x5, x1
     5e8:      	lsr	x19, x19, #3
     5ec:      	ccmp	x19, x10, #0x0, hs
     5f0:      	cset	w19, hi
     5f4:      	subs	x21, x1, x5
     5f8:      	ccmp	x21, x11, #0x0, hs
     5fc:      	csinc	w19, w19, wzr, ls
     600:      	subs	x21, x4, x1
     604:      	lsr	x21, x21, #3
     608:      	ccmp	x21, x10, #0x0, hs
     60c:      	cset	w21, hi
     610:      	subs	x22, x1, x4
     614:      	ccmp	x22, x11, #0x0, hs
     618:      	csinc	w21, w21, wzr, ls
     61c:      	xtn.2s	v11, v2
     620:      	xtn.2s	v15, v4
     624:      	xtn.2s	v28, v1
     628:      	xtn.2s	v29, v3
     62c:      	cmp	w21, #0x1
     630:      	b.ne	0x1428 <ltmp0+0x1428>
     634:      	cbz	w15, 0x1428 <ltmp0+0x1428>
     638:      	cbz	w19, 0x1428 <ltmp0+0x1428>
     63c:      	adrp	x15, 0x0 <ltmp0>
     640:      	ldr	q1, [x15]
     644:      	and.16b	v0, v0, v1
     648:      	addv.8h	h22, v0
     64c:      	fmov	w15, s22
     650:      	mov.16b	v0, v20
     654:      	movi.2s	v1, #0x42
     658:      	umlal.2d	v0, v11, v1
     65c:      	fmov	x19, d0
     660:      	lsl	x21, x19, #2
     664:      	add	x19, x7, x21
     668:      	movi.2d	v1, #0000000000000000
     66c:      	movi.2d	v0, #0000000000000000
     670:      	tbnz	w15, #0x0, 0x24b8 <ltmp0+0x24b8>
     674:      	and	w15, w15, #0xff
     678:      	tbnz	w15, #0x1, 0x24c4 <ltmp0+0x24c4>
     67c:      	tbnz	w15, #0x2, 0x24d0 <ltmp0+0x24d0>
     680:      	tbnz	w15, #0x3, 0x24dc <ltmp0+0x24dc>
     684:      	tbnz	w15, #0x4, 0x24e8 <ltmp0+0x24e8>
     688:      	tbnz	w15, #0x5, 0x24f4 <ltmp0+0x24f4>
     68c:      	tbnz	w15, #0x6, 0x2500 <ltmp0+0x2500>
     690:      	tbz	w15, #0x7, 0x69c <ltmp0+0x69c>
     694:      	add	x15, x19, #0x1c
     698:      	ld1.s	{ v0 }[3], [x15]
     69c:      	movi.2s	v2, #0x42
     6a0:      	umull.2d	v21, v11, v2
     6a4:      	fmov	w15, s22
     6a8:      	fmov	x19, d21
     6ac:      	lsl	x19, x19, #2
     6b0:      	add	x22, x19, #0x84
     6b4:      	add	x23, x7, x22
     6b8:      	movi.2d	v3, #0000000000000000
     6bc:      	movi.2d	v2, #0000000000000000
     6c0:      	tbnz	w15, #0x0, 0x2510 <ltmp0+0x2510>
     6c4:      	and	w15, w15, #0xff
     6c8:      	tbnz	w15, #0x1, 0x251c <ltmp0+0x251c>
     6cc:      	tbnz	w15, #0x2, 0x2528 <ltmp0+0x2528>
     6d0:      	tbnz	w15, #0x3, 0x2534 <ltmp0+0x2534>
     6d4:      	tbnz	w15, #0x4, 0x2540 <ltmp0+0x2540>
     6d8:      	tbnz	w15, #0x5, 0x254c <ltmp0+0x254c>
     6dc:      	tbnz	w15, #0x6, 0x2558 <ltmp0+0x2558>
     6e0:      	tbz	w15, #0x7, 0x6ec <ltmp0+0x6ec>
     6e4:      	add	x15, x23, #0x1c
     6e8:      	ld1.s	{ v2 }[3], [x15]
     6ec:      	fmov	w15, s22
     6f0:      	mov.16b	v4, v20
     6f4:      	movi.2s	v6, #0x21
     6f8:      	umlal.2d	v4, v11, v6
     6fc:      	fmov	x23, d4
     700:      	lsl	x23, x23, #2
     704:      	add	x25, x5, x23
     708:      	movi.2d	v6, #0000000000000000
     70c:      	movi.2d	v4, #0000000000000000
     710:      	tbnz	w15, #0x0, 0x2568 <ltmp0+0x2568>
     714:      	and	w15, w15, #0xff
     718:      	tbnz	w15, #0x1, 0x2574 <ltmp0+0x2574>
     71c:      	tbnz	w15, #0x2, 0x2580 <ltmp0+0x2580>
     720:      	tbnz	w15, #0x3, 0x258c <ltmp0+0x258c>
     724:      	tbnz	w15, #0x4, 0x2598 <ltmp0+0x2598>
     728:      	tbnz	w15, #0x5, 0x25a4 <ltmp0+0x25a4>
     72c:      	tbnz	w15, #0x6, 0x25b0 <ltmp0+0x25b0>
     730:      	tbnz	w15, #0x7, 0x25bc <ltmp0+0x25bc>
     734:      	fmov	w15, s22
     738:      	add	x23, x4, x23
     73c:      	movi.2d	v16, #0000000000000000
     740:      	movi.2d	v7, #0000000000000000
     744:      	tbnz	w15, #0x0, 0x25d8 <ltmp0+0x25d8>
     748:      	and	w15, w15, #0xff
     74c:      	tbnz	w15, #0x1, 0x25e4 <ltmp0+0x25e4>
     750:      	tbnz	w15, #0x2, 0x25f0 <ltmp0+0x25f0>
     754:      	tbnz	w15, #0x3, 0x25fc <ltmp0+0x25fc>
     758:      	tbnz	w15, #0x4, 0x2608 <ltmp0+0x2608>
     75c:      	tbnz	w15, #0x5, 0x2614 <ltmp0+0x2614>
     760:      	tbnz	w15, #0x6, 0x2620 <ltmp0+0x2620>
     764:      	tbnz	w15, #0x7, 0x262c <ltmp0+0x262c>
     768:      	fmov	w23, s22
     76c:      	fmul.4s	v17, v1, v6
     770:      	fmul.4s	v18, v3, v16
     774:      	fsub.4s	v17, v17, v18
     778:      	add	x15, x1, x21
     77c:      	tbnz	w23, #0x0, 0x264c <ltmp0+0x264c>
     780:      	and	w21, w23, #0xff
     784:      	tbnz	w21, #0x1, 0x2658 <ltmp0+0x2658>
     788:      	tbnz	w21, #0x2, 0x2664 <ltmp0+0x2664>
     78c:      	tbnz	w21, #0x3, 0x2670 <ltmp0+0x2670>
     790:      	fmul.4s	v17, v0, v4
     794:      	fmul.4s	v18, v2, v7
     798:      	fsub.4s	v17, v17, v18
     79c:      	tbnz	w21, #0x4, 0x2688 <ltmp0+0x2688>
     7a0:      	tbnz	w21, #0x5, 0x2690 <ltmp0+0x2690>
     7a4:      	tbnz	w21, #0x6, 0x269c <ltmp0+0x269c>
     7a8:      	tbnz	w21, #0x7, 0x26a8 <ltmp0+0x26a8>
     7ac:      	fmov	w21, s22
     7b0:      	fmul.4s	v1, v1, v16
     7b4:      	fmul.4s	v3, v3, v6
     7b8:      	fadd.4s	v1, v3, v1
     7bc:      	add	x15, x1, x22
     7c0:      	tbnz	w21, #0x0, 0x26c8 <ltmp0+0x26c8>
     7c4:      	and	w21, w21, #0xff
     7c8:      	tbnz	w21, #0x1, 0x26d4 <ltmp0+0x26d4>
     7cc:      	tbnz	w21, #0x2, 0x26e0 <ltmp0+0x26e0>
     7d0:      	tbnz	w21, #0x3, 0x26ec <ltmp0+0x26ec>
     7d4:      	fmul.4s	v0, v0, v7
     7d8:      	fmul.4s	v1, v2, v4
     7dc:      	fadd.4s	v0, v1, v0
     7e0:      	tbnz	w21, #0x4, 0x2704 <ltmp0+0x2704>
     7e4:      	tbnz	w21, #0x5, 0x270c <ltmp0+0x270c>
     7e8:      	tbnz	w21, #0x6, 0x2718 <ltmp0+0x2718>
     7ec:      	tbz	w21, #0x7, 0x7f8 <ltmp0+0x7f8>
     7f0:      	add	x15, x15, #0x1c
     7f4:      	st1.s	{ v0 }[3], [x15]
     7f8:      	fmov	w15, s22
     7fc:      	mov	w21, #0x8               ; =8
     800:      	dup.2d	v0, x21
     804:      	orr.16b	v6, v20, v0
     808:      	add.2d	v0, v21, v6
     80c:      	fmov	x21, d0
     810:      	lsl	x21, x21, #2
     814:      	add	x22, x7, x21
     818:      	movi.2d	v2, #0000000000000000
     81c:      	movi.2d	v1, #0000000000000000
     820:      	tbnz	w15, #0x0, 0x2728 <ltmp0+0x2728>
     824:      	and	w15, w15, #0xff
     828:      	tbnz	w15, #0x1, 0x2734 <ltmp0+0x2734>
     82c:      	tbnz	w15, #0x2, 0x2740 <ltmp0+0x2740>
     830:      	tbnz	w15, #0x3, 0x274c <ltmp0+0x274c>
     834:      	tbnz	w15, #0x4, 0x2758 <ltmp0+0x2758>
     838:      	tbnz	w15, #0x5, 0x2764 <ltmp0+0x2764>
     83c:      	tbnz	w15, #0x6, 0x2770 <ltmp0+0x2770>
     840:      	tbnz	w15, #0x7, 0x277c <ltmp0+0x277c>
     844:      	fmov	w15, s22
     848:      	add	x22, x19, #0xa4
     84c:      	add	x23, x7, x22
     850:      	movi.2d	v4, #0000000000000000
     854:      	movi.2d	v3, #0000000000000000
     858:      	tbnz	w15, #0x0, 0x279c <ltmp0+0x279c>
     85c:      	and	w15, w15, #0xff
     860:      	tbnz	w15, #0x1, 0x27a8 <ltmp0+0x27a8>
     864:      	tbnz	w15, #0x2, 0x27b4 <ltmp0+0x27b4>
     868:      	tbnz	w15, #0x3, 0x27c0 <ltmp0+0x27c0>
     86c:      	tbnz	w15, #0x4, 0x27cc <ltmp0+0x27cc>
     870:      	tbnz	w15, #0x5, 0x27d8 <ltmp0+0x27d8>
     874:      	tbnz	w15, #0x6, 0x27e4 <ltmp0+0x27e4>
     878:      	tbz	w15, #0x7, 0x884 <ltmp0+0x884>
     87c:      	add	x15, x23, #0x1c
     880:      	ld1.s	{ v3 }[3], [x15]
     884:      	movi.2s	v0, #0x21
     888:      	umull.2d	v0, v11, v0
     88c:      	fmov	w15, s22
     890:      	add.2d	v6, v0, v6
     894:      	fmov	x23, d6
     898:      	lsl	x23, x23, #2
     89c:      	add	x25, x5, x23
     8a0:      	movi.2d	v7, #0000000000000000
     8a4:      	movi.2d	v6, #0000000000000000
     8a8:      	tbnz	w15, #0x0, 0x27f4 <ltmp0+0x27f4>
     8ac:      	and	w15, w15, #0xff
     8b0:      	tbnz	w15, #0x1, 0x2800 <ltmp0+0x2800>
     8b4:      	tbnz	w15, #0x2, 0x280c <ltmp0+0x280c>
     8b8:      	tbnz	w15, #0x3, 0x2818 <ltmp0+0x2818>
     8bc:      	tbnz	w15, #0x4, 0x2824 <ltmp0+0x2824>
     8c0:      	tbnz	w15, #0x5, 0x2830 <ltmp0+0x2830>
     8c4:      	tbnz	w15, #0x6, 0x283c <ltmp0+0x283c>
     8c8:      	tbnz	w15, #0x7, 0x2848 <ltmp0+0x2848>
     8cc:      	fmov	w15, s22
     8d0:      	add	x23, x4, x23
     8d4:      	movi.2d	v17, #0000000000000000
     8d8:      	movi.2d	v16, #0000000000000000
     8dc:      	tbnz	w15, #0x0, 0x2864 <ltmp0+0x2864>
     8e0:      	and	w15, w15, #0xff
     8e4:      	tbnz	w15, #0x1, 0x2870 <ltmp0+0x2870>
     8e8:      	tbnz	w15, #0x2, 0x287c <ltmp0+0x287c>
     8ec:      	tbnz	w15, #0x3, 0x2888 <ltmp0+0x2888>
     8f0:      	tbnz	w15, #0x4, 0x2894 <ltmp0+0x2894>
     8f4:      	tbnz	w15, #0x5, 0x28a0 <ltmp0+0x28a0>
     8f8:      	tbnz	w15, #0x6, 0x28ac <ltmp0+0x28ac>
     8fc:      	tbnz	w15, #0x7, 0x28b8 <ltmp0+0x28b8>
     900:      	fmov	w23, s22
     904:      	fmul.4s	v18, v2, v7
     908:      	fmul.4s	v19, v4, v17
     90c:      	fsub.4s	v18, v18, v19
     910:      	add	x15, x1, x21
     914:      	tbnz	w23, #0x0, 0x28d8 <ltmp0+0x28d8>
     918:      	and	w21, w23, #0xff
     91c:      	tbnz	w21, #0x1, 0x28e4 <ltmp0+0x28e4>
     920:      	tbnz	w21, #0x2, 0x28f0 <ltmp0+0x28f0>
     924:      	tbnz	w21, #0x3, 0x28fc <ltmp0+0x28fc>
     928:      	fmul.4s	v18, v1, v6
     92c:      	fmul.4s	v19, v3, v16
     930:      	fsub.4s	v18, v18, v19
     934:      	tbnz	w21, #0x4, 0x2914 <ltmp0+0x2914>
     938:      	tbnz	w21, #0x5, 0x291c <ltmp0+0x291c>
     93c:      	tbnz	w21, #0x6, 0x2928 <ltmp0+0x2928>
     940:      	tbnz	w21, #0x7, 0x2934 <ltmp0+0x2934>
     944:      	fmov	w21, s22
     948:      	fmul.4s	v2, v2, v17
     94c:      	fmul.4s	v4, v4, v7
     950:      	fadd.4s	v2, v4, v2
     954:      	add	x15, x1, x22
     958:      	tbnz	w21, #0x0, 0x2954 <ltmp0+0x2954>
     95c:      	and	w21, w21, #0xff
     960:      	tbnz	w21, #0x1, 0x2960 <ltmp0+0x2960>
     964:      	tbnz	w21, #0x2, 0x296c <ltmp0+0x296c>
     968:      	tbnz	w21, #0x3, 0x2978 <ltmp0+0x2978>
     96c:      	fmul.4s	v1, v1, v16
     970:      	fmul.4s	v2, v3, v6
     974:      	fadd.4s	v1, v2, v1
     978:      	tbnz	w21, #0x4, 0x2990 <ltmp0+0x2990>
     97c:      	tbnz	w21, #0x5, 0x2998 <ltmp0+0x2998>
     980:      	tbnz	w21, #0x6, 0x29a4 <ltmp0+0x29a4>
     984:      	tbz	w21, #0x7, 0x990 <ltmp0+0x990>
     988:      	add	x15, x15, #0x1c
     98c:      	st1.s	{ v1 }[3], [x15]
     990:      	fmov	w15, s22
     994:      	mov	w21, #0x10              ; =16
     998:      	dup.2d	v1, x21
     99c:      	orr.16b	v6, v20, v1
     9a0:      	add.2d	v1, v21, v6
     9a4:      	fmov	x21, d1
     9a8:      	lsl	x21, x21, #2
     9ac:      	add	x22, x7, x21
     9b0:      	movi.2d	v2, #0000000000000000
     9b4:      	movi.2d	v1, #0000000000000000
     9b8:      	tbnz	w15, #0x0, 0x29b4 <ltmp0+0x29b4>
     9bc:      	and	w15, w15, #0xff
     9c0:      	tbnz	w15, #0x1, 0x29c0 <ltmp0+0x29c0>
     9c4:      	tbnz	w15, #0x2, 0x29cc <ltmp0+0x29cc>
     9c8:      	tbnz	w15, #0x3, 0x29d8 <ltmp0+0x29d8>
     9cc:      	tbnz	w15, #0x4, 0x29e4 <ltmp0+0x29e4>
     9d0:      	tbnz	w15, #0x5, 0x29f0 <ltmp0+0x29f0>
     9d4:      	tbnz	w15, #0x6, 0x29fc <ltmp0+0x29fc>
     9d8:      	tbnz	w15, #0x7, 0x2a08 <ltmp0+0x2a08>
     9dc:      	fmov	w15, s22
     9e0:      	add	x22, x19, #0xc4
     9e4:      	add	x23, x7, x22
     9e8:      	movi.2d	v4, #0000000000000000
     9ec:      	movi.2d	v3, #0000000000000000
     9f0:      	tbnz	w15, #0x0, 0x2a28 <ltmp0+0x2a28>
     9f4:      	and	w15, w15, #0xff
     9f8:      	tbnz	w15, #0x1, 0x2a34 <ltmp0+0x2a34>
     9fc:      	tbnz	w15, #0x2, 0x2a40 <ltmp0+0x2a40>
     a00:      	tbnz	w15, #0x3, 0x2a4c <ltmp0+0x2a4c>
     a04:      	tbnz	w15, #0x4, 0x2a58 <ltmp0+0x2a58>
     a08:      	tbnz	w15, #0x5, 0x2a64 <ltmp0+0x2a64>
     a0c:      	tbnz	w15, #0x6, 0x2a70 <ltmp0+0x2a70>
     a10:      	tbz	w15, #0x7, 0xa1c <ltmp0+0xa1c>
     a14:      	add	x15, x23, #0x1c
     a18:      	ld1.s	{ v3 }[3], [x15]
     a1c:      	fmov	w15, s22
     a20:      	add.2d	v6, v0, v6
     a24:      	fmov	x23, d6
     a28:      	lsl	x23, x23, #2
     a2c:      	add	x25, x5, x23
     a30:      	movi.2d	v7, #0000000000000000
     a34:      	movi.2d	v6, #0000000000000000
     a38:      	tbnz	w15, #0x0, 0x2a80 <ltmp0+0x2a80>
     a3c:      	and	w15, w15, #0xff
     a40:      	tbnz	w15, #0x1, 0x2a8c <ltmp0+0x2a8c>
     a44:      	tbnz	w15, #0x2, 0x2a98 <ltmp0+0x2a98>
     a48:      	tbnz	w15, #0x3, 0x2aa4 <ltmp0+0x2aa4>
     a4c:      	tbnz	w15, #0x4, 0x2ab0 <ltmp0+0x2ab0>
     a50:      	tbnz	w15, #0x5, 0x2abc <ltmp0+0x2abc>
     a54:      	tbnz	w15, #0x6, 0x2ac8 <ltmp0+0x2ac8>
     a58:      	tbnz	w15, #0x7, 0x2ad4 <ltmp0+0x2ad4>
     a5c:      	fmov	w15, s22
     a60:      	add	x23, x4, x23
     a64:      	movi.2d	v17, #0000000000000000
     a68:      	movi.2d	v16, #0000000000000000
     a6c:      	tbnz	w15, #0x0, 0x2af0 <ltmp0+0x2af0>
     a70:      	and	w15, w15, #0xff
     a74:      	tbnz	w15, #0x1, 0x2afc <ltmp0+0x2afc>
     a78:      	tbnz	w15, #0x2, 0x2b08 <ltmp0+0x2b08>
     a7c:      	tbnz	w15, #0x3, 0x2b14 <ltmp0+0x2b14>
     a80:      	tbnz	w15, #0x4, 0x2b20 <ltmp0+0x2b20>
     a84:      	tbnz	w15, #0x5, 0x2b2c <ltmp0+0x2b2c>
     a88:      	tbnz	w15, #0x6, 0x2b38 <ltmp0+0x2b38>
     a8c:      	tbnz	w15, #0x7, 0x2b44 <ltmp0+0x2b44>
     a90:      	fmov	w23, s22
     a94:      	fmul.4s	v18, v2, v7
     a98:      	fmul.4s	v19, v4, v17
     a9c:      	fsub.4s	v18, v18, v19
     aa0:      	add	x15, x1, x21
     aa4:      	tbnz	w23, #0x0, 0x2b64 <ltmp0+0x2b64>
     aa8:      	and	w21, w23, #0xff
     aac:      	tbnz	w21, #0x1, 0x2b70 <ltmp0+0x2b70>
     ab0:      	tbnz	w21, #0x2, 0x2b7c <ltmp0+0x2b7c>
     ab4:      	tbnz	w21, #0x3, 0x2b88 <ltmp0+0x2b88>
     ab8:      	fmul.4s	v18, v1, v6
     abc:      	fmul.4s	v19, v3, v16
     ac0:      	fsub.4s	v18, v18, v19
     ac4:      	tbnz	w21, #0x4, 0x2ba0 <ltmp0+0x2ba0>
     ac8:      	tbnz	w21, #0x5, 0x2ba8 <ltmp0+0x2ba8>
     acc:      	tbnz	w21, #0x6, 0x2bb4 <ltmp0+0x2bb4>
     ad0:      	tbnz	w21, #0x7, 0x2bc0 <ltmp0+0x2bc0>
     ad4:      	fmov	w21, s22
     ad8:      	fmul.4s	v2, v2, v17
     adc:      	fmul.4s	v4, v4, v7
     ae0:      	fadd.4s	v2, v4, v2
     ae4:      	add	x15, x1, x22
     ae8:      	tbnz	w21, #0x0, 0x2be0 <ltmp0+0x2be0>
     aec:      	and	w21, w21, #0xff
     af0:      	tbnz	w21, #0x1, 0x2bec <ltmp0+0x2bec>
     af4:      	tbnz	w21, #0x2, 0x2bf8 <ltmp0+0x2bf8>
     af8:      	tbnz	w21, #0x3, 0x2c04 <ltmp0+0x2c04>
     afc:      	fmul.4s	v1, v1, v16
     b00:      	fmul.4s	v2, v3, v6
     b04:      	fadd.4s	v1, v2, v1
     b08:      	tbnz	w21, #0x4, 0x2c1c <ltmp0+0x2c1c>
     b0c:      	tbnz	w21, #0x5, 0x2c24 <ltmp0+0x2c24>
     b10:      	tbnz	w21, #0x6, 0x2c30 <ltmp0+0x2c30>
     b14:      	tbz	w21, #0x7, 0xb20 <ltmp0+0xb20>
     b18:      	add	x15, x15, #0x1c
     b1c:      	st1.s	{ v1 }[3], [x15]
     b20:      	fmov	w15, s22
     b24:      	dup.2d	v1, x14
     b28:      	orr.16b	v6, v20, v1
     b2c:      	add.2d	v1, v21, v6
     b30:      	fmov	x21, d1
     b34:      	lsl	x21, x21, #2
     b38:      	add	x22, x7, x21
     b3c:      	movi.2d	v2, #0000000000000000
     b40:      	movi.2d	v1, #0000000000000000
     b44:      	tbnz	w15, #0x0, 0x2c40 <ltmp0+0x2c40>
     b48:      	and	w15, w15, #0xff
     b4c:      	tbnz	w15, #0x1, 0x2c4c <ltmp0+0x2c4c>
     b50:      	tbnz	w15, #0x2, 0x2c58 <ltmp0+0x2c58>
     b54:      	tbnz	w15, #0x3, 0x2c64 <ltmp0+0x2c64>
     b58:      	tbnz	w15, #0x4, 0x2c70 <ltmp0+0x2c70>
     b5c:      	tbnz	w15, #0x5, 0x2c7c <ltmp0+0x2c7c>
     b60:      	tbnz	w15, #0x6, 0x2c88 <ltmp0+0x2c88>
     b64:      	tbnz	w15, #0x7, 0x2c94 <ltmp0+0x2c94>
     b68:      	fmov	w15, s22
     b6c:      	add	x19, x19, #0xe4
     b70:      	add	x22, x7, x19
     b74:      	movi.2d	v4, #0000000000000000
     b78:      	movi.2d	v3, #0000000000000000
     b7c:      	tbnz	w15, #0x0, 0x2cb4 <ltmp0+0x2cb4>
     b80:      	and	w15, w15, #0xff
     b84:      	tbnz	w15, #0x1, 0x2cc0 <ltmp0+0x2cc0>
     b88:      	tbnz	w15, #0x2, 0x2ccc <ltmp0+0x2ccc>
     b8c:      	tbnz	w15, #0x3, 0x2cd8 <ltmp0+0x2cd8>
     b90:      	tbnz	w15, #0x4, 0x2ce4 <ltmp0+0x2ce4>
     b94:      	tbnz	w15, #0x5, 0x2cf0 <ltmp0+0x2cf0>
     b98:      	tbnz	w15, #0x6, 0x2cfc <ltmp0+0x2cfc>
     b9c:      	tbz	w15, #0x7, 0xba8 <ltmp0+0xba8>
     ba0:      	add	x15, x22, #0x1c
     ba4:      	ld1.s	{ v3 }[3], [x15]
     ba8:      	fmov	w15, s22
     bac:      	add.2d	v6, v0, v6
     bb0:      	fmov	x22, d6
     bb4:      	lsl	x22, x22, #2
     bb8:      	add	x23, x5, x22
     bbc:      	movi.2d	v7, #0000000000000000
     bc0:      	movi.2d	v6, #0000000000000000
     bc4:      	tbnz	w15, #0x0, 0x2d0c <ltmp0+0x2d0c>
     bc8:      	and	w15, w15, #0xff
     bcc:      	tbnz	w15, #0x1, 0x2d18 <ltmp0+0x2d18>
     bd0:      	tbnz	w15, #0x2, 0x2d24 <ltmp0+0x2d24>
     bd4:      	tbnz	w15, #0x3, 0x2d30 <ltmp0+0x2d30>
     bd8:      	tbnz	w15, #0x4, 0x2d3c <ltmp0+0x2d3c>
     bdc:      	tbnz	w15, #0x5, 0x2d48 <ltmp0+0x2d48>
     be0:      	tbnz	w15, #0x6, 0x2d54 <ltmp0+0x2d54>
     be4:      	tbnz	w15, #0x7, 0x2d60 <ltmp0+0x2d60>
     be8:      	fmov	w15, s22
     bec:      	add	x22, x4, x22
     bf0:      	movi.2d	v17, #0000000000000000
     bf4:      	movi.2d	v16, #0000000000000000
     bf8:      	tbnz	w15, #0x0, 0x2d7c <ltmp0+0x2d7c>
     bfc:      	and	w15, w15, #0xff
     c00:      	tbnz	w15, #0x1, 0x2d88 <ltmp0+0x2d88>
     c04:      	tbnz	w15, #0x2, 0x2d94 <ltmp0+0x2d94>
     c08:      	tbnz	w15, #0x3, 0x2da0 <ltmp0+0x2da0>
     c0c:      	tbnz	w15, #0x4, 0x2dac <ltmp0+0x2dac>
     c10:      	tbnz	w15, #0x5, 0x2db8 <ltmp0+0x2db8>
     c14:      	tbnz	w15, #0x6, 0x2dc4 <ltmp0+0x2dc4>
     c18:      	tbnz	w15, #0x7, 0x2dd0 <ltmp0+0x2dd0>
     c1c:      	fmov	w22, s22
     c20:      	fmul.4s	v18, v2, v7
     c24:      	fmul.4s	v19, v4, v17
     c28:      	fsub.4s	v18, v18, v19
     c2c:      	add	x15, x1, x21
     c30:      	tbnz	w22, #0x0, 0x2df0 <ltmp0+0x2df0>
     c34:      	and	w21, w22, #0xff
     c38:      	tbnz	w21, #0x1, 0x2dfc <ltmp0+0x2dfc>
     c3c:      	tbnz	w21, #0x2, 0x2e08 <ltmp0+0x2e08>
     c40:      	tbnz	w21, #0x3, 0x2e14 <ltmp0+0x2e14>
     c44:      	fmul.4s	v18, v1, v6
     c48:      	fmul.4s	v19, v3, v16
     c4c:      	fsub.4s	v18, v18, v19
     c50:      	tbnz	w21, #0x4, 0x2e2c <ltmp0+0x2e2c>
     c54:      	tbnz	w21, #0x5, 0x2e34 <ltmp0+0x2e34>
     c58:      	tbnz	w21, #0x6, 0x2e40 <ltmp0+0x2e40>
     c5c:      	tbnz	w21, #0x7, 0x2e4c <ltmp0+0x2e4c>
     c60:      	fmov	w21, s22
     c64:      	fmul.4s	v2, v2, v17
     c68:      	fmul.4s	v4, v4, v7
     c6c:      	fadd.4s	v2, v4, v2
     c70:      	add	x15, x1, x19
     c74:      	tbnz	w21, #0x0, 0x2e6c <ltmp0+0x2e6c>
     c78:      	and	w19, w21, #0xff
     c7c:      	tbnz	w19, #0x1, 0x2e78 <ltmp0+0x2e78>
     c80:      	tbnz	w19, #0x2, 0x2e84 <ltmp0+0x2e84>
     c84:      	tbnz	w19, #0x3, 0x2e90 <ltmp0+0x2e90>
     c88:      	fmul.4s	v1, v1, v16
     c8c:      	fmul.4s	v2, v3, v6
     c90:      	fadd.4s	v1, v2, v1
     c94:      	tbnz	w19, #0x4, 0x2ea8 <ltmp0+0x2ea8>
     c98:      	tbnz	w19, #0x5, 0x2eb0 <ltmp0+0x2eb0>
     c9c:      	tbnz	w19, #0x6, 0x2ebc <ltmp0+0x2ebc>
     ca0:      	tbz	w19, #0x7, 0xcac <ltmp0+0xcac>
     ca4:      	add	x15, x15, #0x1c
     ca8:      	st1.s	{ v1 }[3], [x15]
     cac:      	xtn.4h	v1, v5
     cb0:      	uzp1.8b	v1, v1, v0
     cb4:      	movi.2d	v23, #0000000000000000
     cb8:      	mov.b	v23[0], v1[0]
     cbc:      	adrp	x15, 0x0 <ltmp0>
     cc0:      	ldr	d16, [x15]
     cc4:      	and.8b	v2, v23, v16
     cc8:      	addv.8b	b2, v2
     ccc:      	fmov	w21, s2
     cd0:      	umaxv.8b	b2, v23
     cd4:      	fmov	w15, s2
     cd8:      	rbit	w19, w21
     cdc:      	clz	w19, w19
     ce0:      	tst	w15, #0x1
     ce4:      	csel	w19, w19, wzr, ne
     ce8:      	dup.2d	v25, x9
     cec:      	orr.16b	v24, v20, v25
     cf0:      	add.2d	v3, v21, v24
     cf4:      	movi.2d	v2, #0000000000000000
     cf8:      	mov.b	v2[0], v1[0]
     cfc:      	ushll.2d	v1, v2, #0x0
     d00:      	shl.2d	v1, v1, #0x3f
     d04:      	cmlt.2d	v1, v1, #0
     d08:      	and.16b	v1, v1, v3
     d0c:      	movi.2d	v2, #0000000000000000
     d10:      	stp	q2, q2, [sp, #0x370]
     d14:      	stp	q1, q2, [sp, #0x350]
     d18:      	and	x22, x19, #0x7
     d1c:      	add	x23, sp, #0x350
     d20:      	ldr	x22, [x23, x22, lsl #3]
     d24:      	sub	x22, x22, x19
     d28:      	add	x22, x7, x22, lsl #2
     d2c:      	movi.2d	v1, #0000000000000000
     d30:      	tbnz	w15, #0x0, 0x2ecc <ltmp0+0x2ecc>
     d34:      	tbnz	w21, #0x1, 0x2ed4 <ltmp0+0x2ed4>
     d38:      	tbnz	w21, #0x2, 0x2ee0 <ltmp0+0x2ee0>
     d3c:      	tbnz	w21, #0x3, 0x2eec <ltmp0+0x2eec>
     d40:      	tbnz	w21, #0x4, 0x2ef8 <ltmp0+0x2ef8>
     d44:      	tbnz	w21, #0x5, 0x2f04 <ltmp0+0x2f04>
     d48:      	tbnz	w21, #0x6, 0x2f10 <ltmp0+0x2f10>
     d4c:      	tbz	w21, #0x7, 0xd58 <ltmp0+0xd58>
     d50:      	add	x15, x22, #0x1c
     d54:      	ld1.s	{ v1 }[3], [x15]
     d58:      	movi.2s	v4, #0x42
     d5c:      	umull.2d	v18, v15, v4
     d60:      	umull.2d	v22, v28, v4
     d64:      	umull.2d	v19, v29, v4
     d68:      	add.2d	v7, v20, v21
     d6c:      	add.2d	v6, v31, v18
     d70:      	add.2d	v5, v8, v22
     d74:      	add.2d	v4, v30, v19
     d78:      	mov	w15, #0x41              ; =65
     d7c:      	dup.2d	v17, x15
     d80:      	add.2d	v4, v4, v17
     d84:      	add.2d	v5, v5, v17
     d88:      	add.2d	v6, v6, v17
     d8c:      	mov	b20, v23[0]
     d90:      	mov.b	v20[4], v23[1]
     d94:      	add.2d	v7, v7, v17
     d98:      	ushll.2d	v17, v20, #0x0
     d9c:      	shl.2d	v17, v17, #0x3f
     da0:      	cmlt.2d	v17, v17, #0
     da4:      	and.16b	v20, v17, v7
     da8:      	mov	b17, v23[2]
     dac:      	mov.b	v17[4], v23[3]
     db0:      	ushll.2d	v17, v17, #0x0
     db4:      	shl.2d	v17, v17, #0x3f
     db8:      	cmlt.2d	v17, v17, #0
     dbc:      	and.16b	v21, v17, v6
     dc0:      	mov	b17, v23[4]
     dc4:      	mov.b	v17[4], v23[5]
     dc8:      	ushll.2d	v17, v17, #0x0
     dcc:      	shl.2d	v17, v17, #0x3f
     dd0:      	cmlt.2d	v17, v17, #0
     dd4:      	and.16b	v26, v17, v5
     dd8:      	mov	b17, v23[6]
     ddc:      	mov.b	v17[4], v23[7]
     de0:      	ushll.2d	v17, v17, #0x0
     de4:      	shl.2d	v17, v17, #0x3f
     de8:      	cmlt.2d	v17, v17, #0
     dec:      	and.16b	v27, v17, v4
     df0:      	shl.8b	v17, v23, #0x7
     df4:      	cmlt.8b	v17, v17, #0
     df8:      	and.8b	v16, v17, v16
     dfc:      	addv.8b	b17, v16
     e00:      	fmov	w21, s17
     e04:      	stp	q26, q27, [sp, #0x330]
     e08:      	stp	q20, q21, [sp, #0x310]
     e0c:      	and	x15, x19, #0x7
     e10:      	add	x22, sp, #0x310
     e14:      	ldr	x15, [x22, x15, lsl #3]
     e18:      	sub	x15, x15, x19
     e1c:      	add	x7, x7, x15, lsl #2
     e20:      	movi.2d	v20, #0000000000000000
     e24:      	movi.2d	v16, #0000000000000000
     e28:      	tbnz	w21, #0x0, 0x2f20 <ltmp0+0x2f20>
     e2c:      	tbnz	w21, #0x1, 0x2f28 <ltmp0+0x2f28>
     e30:      	tbnz	w21, #0x2, 0x2f34 <ltmp0+0x2f34>
     e34:      	tbnz	w21, #0x3, 0x2f40 <ltmp0+0x2f40>
     e38:      	tbnz	w21, #0x4, 0x2f4c <ltmp0+0x2f4c>
     e3c:      	tbnz	w21, #0x5, 0x2f58 <ltmp0+0x2f58>
     e40:      	tbnz	w21, #0x6, 0x2f64 <ltmp0+0x2f64>
     e44:      	tbz	w21, #0x7, 0xe50 <ltmp0+0xe50>
     e48:      	add	x15, x7, #0x1c
     e4c:      	ld1.s	{ v16 }[3], [x15]
     e50:      	movi.2s	v21, #0x21
     e54:      	umull.2d	v27, v15, v21
     e58:      	umull.2d	v28, v28, v21
     e5c:      	umull.2d	v29, v29, v21
     e60:      	orr.16b	v21, v30, v25
     e64:      	orr.16b	v26, v31, v25
     e68:      	orr.16b	v25, v8, v25
     e6c:      	add.2d	v29, v29, v21
     e70:      	add.2d	v28, v28, v25
     e74:      	add.2d	v27, v27, v26
     e78:      	add.2d	v0, v0, v24
     e7c:      	mov	b24, v23[0]
     e80:      	mov.b	v24[4], v23[1]
     e84:      	ushll.2d	v24, v24, #0x0
     e88:      	shl.2d	v24, v24, #0x3f
     e8c:      	cmlt.2d	v24, v24, #0
     e90:      	and.16b	v0, v24, v0
     e94:      	mov	b24, v23[2]
     e98:      	mov.b	v24[4], v23[3]
     e9c:      	ushll.2d	v24, v24, #0x0
     ea0:      	shl.2d	v24, v24, #0x3f
     ea4:      	cmlt.2d	v24, v24, #0
     ea8:      	and.16b	v24, v24, v27
     eac:      	mov	b27, v23[4]
     eb0:      	mov.b	v27[4], v23[5]
     eb4:      	ushll.2d	v27, v27, #0x0
     eb8:      	shl.2d	v27, v27, #0x3f
     ebc:      	cmlt.2d	v27, v27, #0
     ec0:      	mov	b30, v23[6]
     ec4:      	mov.b	v30[4], v23[7]
     ec8:      	and.16b	v23, v27, v28
     ecc:      	ushll.2d	v27, v30, #0x0
     ed0:      	shl.2d	v27, v27, #0x3f
     ed4:      	cmlt.2d	v27, v27, #0
     ed8:      	and.16b	v27, v27, v29
     edc:      	stp	q23, q27, [sp, #0x2f0]
     ee0:      	stp	q0, q24, [sp, #0x2d0]
     ee4:      	and	x15, x19, #0x7
     ee8:      	add	x7, sp, #0x2d0
     eec:      	ldr	x15, [x7, x15, lsl #3]
     ef0:      	fmov	w21, s17
     ef4:      	sub	x15, x15, x19
     ef8:      	lsl	x7, x15, #2
     efc:      	add	x5, x5, x7
     f00:      	movi.2d	v23, #0000000000000000
     f04:      	movi.2d	v0, #0000000000000000
     f08:      	tbnz	w21, #0x0, 0x2f74 <ltmp0+0x2f74>
     f0c:      	tbnz	w21, #0x1, 0x2f7c <ltmp0+0x2f7c>
     f10:      	tbnz	w21, #0x2, 0x2f88 <ltmp0+0x2f88>
     f14:      	tbnz	w21, #0x3, 0x2f94 <ltmp0+0x2f94>
     f18:      	tbnz	w21, #0x4, 0x2fa0 <ltmp0+0x2fa0>
     f1c:      	tbnz	w21, #0x5, 0x2fac <ltmp0+0x2fac>
     f20:      	tbnz	w21, #0x6, 0x2fb8 <ltmp0+0x2fb8>
     f24:      	tbnz	w21, #0x7, 0x2fc4 <ltmp0+0x2fc4>
     f28:      	add	x4, x4, x7
     f2c:      	fmov	w5, s17
     f30:      	movi.2d	v27, #0000000000000000
     f34:      	movi.2d	v24, #0000000000000000
     f38:      	tbnz	w5, #0x0, 0x2fe0 <ltmp0+0x2fe0>
     f3c:      	tbnz	w5, #0x1, 0x2fe8 <ltmp0+0x2fe8>
     f40:      	tbnz	w5, #0x2, 0x2ff4 <ltmp0+0x2ff4>
     f44:      	tbnz	w5, #0x3, 0x3000 <ltmp0+0x3000>
     f48:      	tbnz	w5, #0x4, 0x300c <ltmp0+0x300c>
     f4c:      	tbnz	w5, #0x5, 0x3018 <ltmp0+0x3018>
     f50:      	tbnz	w5, #0x6, 0x3024 <ltmp0+0x3024>
     f54:      	tbz	w5, #0x7, 0xf60 <ltmp0+0xf60>
     f58:      	add	x15, x4, #0x1c
     f5c:      	ld1.s	{ v24 }[3], [x15]
     f60:      	add.2d	v22, v22, v25
     f64:      	add.2d	v25, v18, v26
     f68:      	add.2d	v19, v19, v21
     f6c:      	fmul.4s	v18, v2, v23
     f70:      	fmul.4s	v21, v20, v27
     f74:      	fsub.4s	v18, v18, v21
     f78:      	stp	q3, q25, [sp, #0x290]
     f7c:      	stp	q22, q19, [sp, #0x2b0]
     f80:      	and	x15, x19, #0x7
     f84:      	add	x4, sp, #0x290
     f88:      	ldr	x15, [x4, x15, lsl #3]
     f8c:      	sub	x15, x15, x19
     f90:      	add	x15, x1, x15, lsl #2
     f94:      	fmov	w4, s17
     f98:      	tbnz	w4, #0x0, 0x3034 <ltmp0+0x3034>
     f9c:      	tbnz	w4, #0x1, 0x303c <ltmp0+0x303c>
     fa0:      	tbnz	w4, #0x2, 0x3048 <ltmp0+0x3048>
     fa4:      	tbnz	w4, #0x3, 0x3054 <ltmp0+0x3054>
     fa8:      	fmul.4s	v3, v1, v0
     fac:      	fmul.4s	v18, v16, v24
     fb0:      	fsub.4s	v3, v3, v18
     fb4:      	tbnz	w4, #0x4, 0x306c <ltmp0+0x306c>
     fb8:      	tbnz	w4, #0x5, 0x3074 <ltmp0+0x3074>
     fbc:      	tbnz	w4, #0x6, 0x3080 <ltmp0+0x3080>
     fc0:      	tbz	w4, #0x7, 0xfcc <ltmp0+0xfcc>
     fc4:      	add	x15, x15, #0x1c
     fc8:      	st1.s	{ v3 }[3], [x15]
     fcc:      	fmul.4s	v2, v2, v27
     fd0:      	fmul.4s	v3, v20, v23
     fd4:      	fadd.4s	v2, v3, v2
     fd8:      	stp	q7, q6, [sp, #0x250]
     fdc:      	stp	q5, q4, [sp, #0x270]
     fe0:      	and	x15, x19, #0x7
     fe4:      	add	x4, sp, #0x250
     fe8:      	ldr	x15, [x4, x15, lsl #3]
     fec:      	sub	x15, x15, x19
     ff0:      	add	x15, x1, x15, lsl #2
     ff4:      	fmov	w1, s17
     ff8:      	tbnz	w1, #0x0, 0x3090 <ltmp0+0x3090>
     ffc:      	tbnz	w1, #0x1, 0x3098 <ltmp0+0x3098>
    1000:      	tbnz	w1, #0x2, 0x30a4 <ltmp0+0x30a4>
    1004:      	tbnz	w1, #0x3, 0x30b0 <ltmp0+0x30b0>
    1008:      	fmul.4s	v1, v1, v24
    100c:      	fmul.4s	v0, v16, v0
    1010:      	fadd.4s	v0, v0, v1
    1014:      	tbnz	w1, #0x4, 0x30c8 <ltmp0+0x30c8>
    1018:      	tbnz	w1, #0x5, 0x30d0 <ltmp0+0x30d0>
    101c:      	tbnz	w1, #0x6, 0x30dc <ltmp0+0x30dc>
    1020:      	tbz	w1, #0x7, 0x84 <ltmp0+0x84>
    1024:      	b	0x30e8 <ltmp0+0x30e8>
    1028:      	mov	x4, #0x0                ; =0
    102c:      	ldr	x15, [x0]
    1030:      	ldr	x22, [x0, #0x10]
    1034:      	ldr	x23, [x0, #0x20]
    1038:      	ldr	x7, [x0, #0x30]
    103c:      	subs	x5, x15, x7
    1040:      	lsr	x5, x5, #3
    1044:      	ccmp	x5, x10, #0x0, hs
    1048:      	cset	w5, hi
    104c:      	subs	x21, x7, x15
    1050:      	lsr	x21, x21, #3
    1054:      	ccmp	x21, x10, #0x0, hs
    1058:      	csinc	w5, w5, wzr, ls
    105c:      	subs	x21, x22, x7
    1060:      	lsr	x21, x21, #3
    1064:      	ccmp	x21, x10, #0x0, hs
    1068:      	cset	w21, hi
    106c:      	subs	x25, x7, x22
    1070:      	ccmp	x25, x11, #0x0, hs
    1074:      	csinc	w21, w21, wzr, ls
    1078:      	and	w5, w5, w21
    107c:      	subs	x21, x23, x7
    1080:      	lsr	x21, x21, #3
    1084:      	ccmp	x21, x10, #0x0, hs
    1088:      	cset	w21, hi
    108c:      	subs	x25, x7, x23
    1090:      	ccmp	x25, x11, #0x0, hs
    1094:      	csinc	w21, w21, wzr, ls
    1098:      	and	w5, w21, w5
    109c:      	and	x21, x6, #0x7ffffff
    10a0:      	add	x25, x21, x21, lsl #5
    10a4:      	lsl	x21, x25, #5
    10a8:      	add	x7, x7, x21
    10ac:      	add	x21, x15, x21
    10b0:      	lsl	x15, x25, #4
    10b4:      	add	x25, x22, x15
    10b8:      	add	x15, x23, x15
    10bc:      	add	x22, x19, x19, lsl #5
    10c0:      	lsl	x22, x22, #3
    10c4:      	add	x23, x25, #0x40
    10c8:      	add	x25, x15, #0x40
    10cc:      	b	0x1258 <ltmp0+0x1258>
    10d0:      	ldur	q0, [x30, #0x84]
    10d4:      	ldur	q3, [x30, #0x94]
    10d8:      	ldp	q4, q5, [x23, #-0x40]
    10dc:      	ldp	q6, q7, [x25, #-0x40]
    10e0:      	fmul.4s	v16, v2, v5
    10e4:      	fmul.4s	v17, v1, v4
    10e8:      	fmul.4s	v18, v3, v7
    10ec:      	fmul.4s	v19, v0, v6
    10f0:      	fsub.4s	v17, v17, v19
    10f4:      	fsub.4s	v16, v16, v18
    10f8:      	add	x15, x7, x4
    10fc:      	stp	q17, q16, [x15]
    1100:      	fmul.4s	v2, v2, v7
    1104:      	fmul.4s	v1, v1, v6
    1108:      	fmul.4s	v3, v3, v5
    110c:      	fmul.4s	v0, v0, v4
    1110:      	fadd.4s	v0, v0, v1
    1114:      	fadd.4s	v1, v3, v2
    1118:      	stur	q1, [x15, #0x94]
    111c:      	stur	q0, [x15, #0x84]
    1120:      	ldp	q0, q1, [x30, #0x20]
    1124:      	ldur	q2, [x30, #0xa4]
    1128:      	ldur	q3, [x30, #0xb4]
    112c:      	ldp	q4, q5, [x23, #-0x20]
    1130:      	ldp	q6, q7, [x25, #-0x20]
    1134:      	fmul.4s	v16, v1, v5
    1138:      	fmul.4s	v17, v0, v4
    113c:      	fmul.4s	v18, v3, v7
    1140:      	fmul.4s	v19, v2, v6
    1144:      	fsub.4s	v17, v17, v19
    1148:      	fsub.4s	v16, v16, v18
    114c:      	stp	q17, q16, [x15, #0x20]
    1150:      	fmul.4s	v1, v1, v7
    1154:      	fmul.4s	v0, v0, v6
    1158:      	fmul.4s	v3, v3, v5
    115c:      	fmul.4s	v2, v2, v4
    1160:      	fadd.4s	v0, v2, v0
    1164:      	fadd.4s	v1, v3, v1
    1168:      	stur	q1, [x15, #0xb4]
    116c:      	stur	q0, [x15, #0xa4]
    1170:      	ldp	q0, q1, [x30, #0x40]
    1174:      	ldur	q2, [x30, #0xc4]
    1178:      	ldur	q3, [x30, #0xd4]
    117c:      	ldp	q4, q5, [x23]
    1180:      	ldp	q6, q7, [x25]
    1184:      	fmul.4s	v16, v1, v5
    1188:      	fmul.4s	v17, v0, v4
    118c:      	fmul.4s	v18, v3, v7
    1190:      	fmul.4s	v19, v2, v6
    1194:      	fsub.4s	v17, v17, v19
    1198:      	fsub.4s	v16, v16, v18
    119c:      	stp	q17, q16, [x15, #0x40]
    11a0:      	fmul.4s	v1, v1, v7
    11a4:      	fmul.4s	v0, v0, v6
    11a8:      	fmul.4s	v3, v3, v5
    11ac:      	fmul.4s	v2, v2, v4
    11b0:      	fadd.4s	v0, v2, v0
    11b4:      	fadd.4s	v1, v3, v1
    11b8:      	stur	q1, [x15, #0xd4]
    11bc:      	stur	q0, [x15, #0xc4]
    11c0:      	ldp	q1, q0, [x30, #0x60]
    11c4:      	ldur	q2, [x30, #0xf4]
    11c8:      	ldur	q3, [x30, #0xe4]
    11cc:      	ldp	q5, q4, [x23, #0x20]
    11d0:      	ldp	q7, q6, [x25, #0x20]
    11d4:      	fmul.4s	v16, v1, v5
    11d8:      	fmul.4s	v17, v0, v4
    11dc:      	fmul.4s	v18, v3, v7
    11e0:      	fmul.4s	v19, v2, v6
    11e4:      	fsub.4s	v17, v17, v19
    11e8:      	fsub.4s	v16, v16, v18
    11ec:      	stp	q16, q17, [x15, #0x60]
    11f0:      	fmul.4s	v1, v1, v7
    11f4:      	fmul.4s	v0, v0, v6
    11f8:      	fmul.4s	v3, v3, v5
    11fc:      	fmul.4s	v2, v2, v4
    1200:      	fadd.4s	v0, v2, v0
    1204:      	fadd.4s	v1, v3, v1
    1208:      	stur	q1, [x15, #0xe4]
    120c:      	stur	q0, [x15, #0xf4]
    1210:      	ldr	s0, [x30, #0x80]
    1214:      	ldr	s1, [x30, #0x104]
    1218:      	ldr	s2, [x23, #0x40]
    121c:      	ldr	s3, [x25, #0x40]
    1220:      	fmul.4s	v4, v0, v2
    1224:      	fmul.4s	v5, v1, v3
    1228:      	fsub.4s	v4, v4, v5
    122c:      	str	s4, [x15, #0x80]
    1230:      	fmul.4s	v0, v0, v3
    1234:      	fmul.4s	v1, v1, v2
    1238:      	fadd.4s	v0, v1, v0
    123c:      	add	x15, x7, x4
    1240:      	str	s0, [x15, #0x104]
    1244:      	add	x4, x4, #0x108
    1248:      	add	x23, x23, #0x84
    124c:      	add	x25, x25, #0x84
    1250:      	cmp	x22, x4
    1254:      	b.eq	0x518 <ltmp0+0x518>
    1258:      	add	x30, x21, x4
    125c:      	ldp	q1, q2, [x30]
    1260:      	cbnz	w5, 0x10d0 <ltmp0+0x10d0>
    1264:      	ldp	q6, q7, [x30, #0x20]
    1268:      	stp	q7, q6, [sp, #0x1c0]
    126c:      	ldp	q0, q3, [x30, #0x40]
    1270:      	str	q3, [sp, #0x1e0]
    1274:      	ldur	q19, [x30, #0x84]
    1278:      	ldur	q21, [x30, #0x94]
    127c:      	stp	q21, q19, [sp, #0x180]
    1280:      	ldur	q16, [x30, #0xa4]
    1284:      	ldur	q17, [x30, #0xb4]
    1288:      	stp	q17, q16, [sp, #0x1a0]
    128c:      	ldur	q4, [x30, #0xc4]
    1290:      	ldur	q5, [x30, #0xd4]
    1294:      	stp	q5, q4, [sp, #0x220]
    1298:      	ldp	q22, q24, [x23, #-0x40]
    129c:      	ldp	q18, q20, [x23, #-0x20]
    12a0:      	stp	q0, q18, [sp, #0x200]
    12a4:      	str	q20, [sp, #0x240]
    12a8:      	fmul.4s	v26, v2, v24
    12ac:      	ldp	q31, q8, [x25, #-0x40]
    12b0:      	fmul.4s	v27, v1, v22
    12b4:      	fmul.4s	v28, v21, v8
    12b8:      	fmul.4s	v29, v19, v31
    12bc:      	ldp	q23, q25, [x23]
    12c0:      	fsub.4s	v19, v27, v29
    12c4:      	str	q19, [sp, #0x1f0]
    12c8:      	fsub.4s	v19, v26, v28
    12cc:      	str	q19, [sp, #0x170]
    12d0:      	fmul.4s	v26, v7, v20
    12d4:      	ldp	q11, q12, [x25, #-0x20]
    12d8:      	fmul.4s	v27, v6, v18
    12dc:      	fmul.4s	v28, v17, v12
    12e0:      	fmul.4s	v30, v16, v11
    12e4:      	ldp	q29, q13, [x25]
    12e8:      	fsub.4s	v14, v27, v30
    12ec:      	fsub.4s	v15, v26, v28
    12f0:      	fmul.4s	v26, v3, v25
    12f4:      	fmul.4s	v27, v0, v23
    12f8:      	fmul.4s	v28, v5, v13
    12fc:      	fmul.4s	v30, v4, v29
    1300:      	fsub.4s	v21, v27, v30
    1304:      	fsub.4s	v20, v26, v28
    1308:      	ldp	q27, q17, [x30, #0x60]
    130c:      	ldur	q26, [x30, #0xe4]
    1310:      	ldp	q28, q30, [x23, #0x20]
    1314:      	fmul.4s	v0, v27, v28
    1318:      	ldp	q7, q5, [x25, #0x20]
    131c:      	fmul.4s	v16, v26, v7
    1320:      	fsub.4s	v19, v0, v16
    1324:      	fmul.4s	v16, v17, v30
    1328:      	ldur	q4, [x30, #0xf4]
    132c:      	fmul.4s	v9, v4, v5
    1330:      	fsub.4s	v18, v16, v9
    1334:      	ldr	s9, [x30, #0x80]
    1338:      	ldr	s16, [x23, #0x40]
    133c:      	fmul.4s	v0, v9, v16
    1340:      	ldr	s6, [x30, #0x104]
    1344:      	ldr	s3, [x25, #0x40]
    1348:      	fmul.4s	v10, v6, v3
    134c:      	fsub.4s	v0, v0, v10
    1350:      	fmul.4s	v2, v2, v8
    1354:      	fmul.4s	v1, v1, v31
    1358:      	ldr	q31, [sp, #0x180]
    135c:      	fmul.4s	v24, v31, v24
    1360:      	ldp	q31, q8, [sp, #0x190]
    1364:      	fmul.4s	v22, v31, v22
    1368:      	add	x15, x7, x4
    136c:      	ldr	q31, [sp, #0x170]
    1370:      	stp	q31, q14, [x15, #0x10]
    1374:      	ldr	q31, [sp, #0x1f0]
    1378:      	str	q31, [x15]
    137c:      	fadd.4s	v1, v22, v1
    1380:      	fadd.4s	v2, v24, v2
    1384:      	ldp	q22, q24, [sp, #0x1c0]
    1388:      	fmul.4s	v22, v22, v12
    138c:      	stp	q15, q21, [x15, #0x30]
    1390:      	fmul.4s	v24, v24, v11
    1394:      	ldr	q31, [sp, #0x240]
    1398:      	fmul.4s	v31, v8, v31
    139c:      	ldr	q8, [sp, #0x210]
    13a0:      	ldr	q10, [sp, #0x1b0]
    13a4:      	fmul.4s	v8, v10, v8
    13a8:      	stp	q20, q19, [x15, #0x50]
    13ac:      	fadd.4s	v20, v8, v24
    13b0:      	fadd.4s	v21, v31, v22
    13b4:      	ldr	q22, [sp, #0x1e0]
    13b8:      	fmul.4s	v22, v22, v13
    13bc:      	str	q18, [x15, #0x70]
    13c0:      	ldr	q18, [sp, #0x200]
    13c4:      	fmul.4s	v18, v18, v29
    13c8:      	str	s0, [x15, #0x80]
    13cc:      	ldp	q0, q19, [sp, #0x220]
    13d0:      	fmul.4s	v0, v0, v25
    13d4:      	fmul.4s	v19, v19, v23
    13d8:      	stur	q2, [x15, #0x94]
    13dc:      	fadd.4s	v2, v19, v18
    13e0:      	stur	q1, [x15, #0x84]
    13e4:      	fadd.4s	v0, v0, v22
    13e8:      	fmul.4s	v1, v17, v5
    13ec:      	stur	q21, [x15, #0xb4]
    13f0:      	fmul.4s	v5, v27, v7
    13f4:      	stur	q20, [x15, #0xa4]
    13f8:      	fmul.4s	v4, v4, v30
    13fc:      	fmul.4s	v7, v26, v28
    1400:      	stur	q0, [x15, #0xd4]
    1404:      	fadd.4s	v5, v7, v5
    1408:      	stur	q2, [x15, #0xc4]
    140c:      	fadd.4s	v0, v4, v1
    1410:      	fmul.4s	v1, v9, v3
    1414:      	stur	q0, [x15, #0xf4]
    1418:      	fmul.4s	v0, v6, v16
    141c:      	fadd.4s	v0, v0, v1
    1420:      	stur	q5, [x15, #0xe4]
    1424:      	b	0x123c <ltmp0+0x123c>
    1428:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    142c:      	ldr	q1, [x15]
    1430:      	and.16b	v0, v0, v1
    1434:      	addv.8h	h22, v0
    1438:      	fmov	w15, s22
    143c:      	mov.16b	v26, v20
    1440:      	movi.2s	v0, #0x42
    1444:      	umlal.2d	v26, v11, v0
    1448:      	fmov	x19, d26
    144c:      	add	x19, x7, x19, lsl #2
    1450:      	movi.2d	v1, #0000000000000000
    1454:      	movi.2d	v2, #0000000000000000
    1458:      	tbnz	w15, #0x0, 0x30f0 <ltmp0+0x30f0>
    145c:      	and	w15, w15, #0xff
    1460:      	tbnz	w15, #0x1, 0x30fc <ltmp0+0x30fc>
    1464:      	tbnz	w15, #0x2, 0x3108 <ltmp0+0x3108>
    1468:      	tbnz	w15, #0x3, 0x3114 <ltmp0+0x3114>
    146c:      	tbnz	w15, #0x4, 0x3120 <ltmp0+0x3120>
    1470:      	tbnz	w15, #0x5, 0x312c <ltmp0+0x312c>
    1474:      	tbnz	w15, #0x6, 0x3138 <ltmp0+0x3138>
    1478:      	tbz	w15, #0x7, 0x1484 <ltmp0+0x1484>
    147c:      	add	x15, x19, #0x1c
    1480:      	ld1.s	{ v2 }[3], [x15]
    1484:      	umull.2d	v0, v11, v0
    1488:      	fmov	w15, s22
    148c:      	str	q1, [sp, #0x7b0]
    1490:      	str	q2, [sp, #0x7c0]
    1494:      	mov	w19, #0x8               ; =8
    1498:      	dup.2d	v2, x19
    149c:      	add.2d	v1, v0, v20
    14a0:      	add.2d	v2, v1, v2
    14a4:      	str	q2, [sp, #0x200]
    14a8:      	fmov	x19, d2
    14ac:      	add	x19, x7, x19, lsl #2
    14b0:      	movi.2d	v2, #0000000000000000
    14b4:      	movi.2d	v3, #0000000000000000
    14b8:      	tbnz	w15, #0x0, 0x3148 <ltmp0+0x3148>
    14bc:      	and	w15, w15, #0xff
    14c0:      	tbnz	w15, #0x1, 0x3154 <ltmp0+0x3154>
    14c4:      	tbnz	w15, #0x2, 0x3160 <ltmp0+0x3160>
    14c8:      	tbnz	w15, #0x3, 0x316c <ltmp0+0x316c>
    14cc:      	tbnz	w15, #0x4, 0x3178 <ltmp0+0x3178>
    14d0:      	tbnz	w15, #0x5, 0x3184 <ltmp0+0x3184>
    14d4:      	tbnz	w15, #0x6, 0x3190 <ltmp0+0x3190>
    14d8:      	tbz	w15, #0x7, 0x14e4 <ltmp0+0x14e4>
    14dc:      	add	x15, x19, #0x1c
    14e0:      	ld1.s	{ v3 }[3], [x15]
    14e4:      	fmov	w15, s22
    14e8:      	mov	w19, #0x10              ; =16
    14ec:      	dup.2d	v4, x19
    14f0:      	str	q2, [sp, #0x7d0]
    14f4:      	str	q3, [sp, #0x7e0]
    14f8:      	add.2d	v2, v1, v4
    14fc:      	str	q2, [sp, #0x220]
    1500:      	fmov	x19, d2
    1504:      	add	x19, x7, x19, lsl #2
    1508:      	movi.2d	v2, #0000000000000000
    150c:      	movi.2d	v3, #0000000000000000
    1510:      	tbnz	w15, #0x0, 0x31a0 <ltmp0+0x31a0>
    1514:      	and	w15, w15, #0xff
    1518:      	tbnz	w15, #0x1, 0x31ac <ltmp0+0x31ac>
    151c:      	tbnz	w15, #0x2, 0x31b8 <ltmp0+0x31b8>
    1520:      	tbnz	w15, #0x3, 0x31c4 <ltmp0+0x31c4>
    1524:      	tbnz	w15, #0x4, 0x31d0 <ltmp0+0x31d0>
    1528:      	tbnz	w15, #0x5, 0x31dc <ltmp0+0x31dc>
    152c:      	tbnz	w15, #0x6, 0x31e8 <ltmp0+0x31e8>
    1530:      	tbz	w15, #0x7, 0x153c <ltmp0+0x153c>
    1534:      	add	x15, x19, #0x1c
    1538:      	ld1.s	{ v3 }[3], [x15]
    153c:      	fmov	w15, s22
    1540:      	dup.2d	v4, x14
    1544:      	str	q2, [sp, #0x7f0]
    1548:      	str	q3, [sp, #0x800]
    154c:      	add.2d	v1, v1, v4
    1550:      	str	q1, [sp, #0x210]
    1554:      	fmov	x19, d1
    1558:      	add	x19, x7, x19, lsl #2
    155c:      	movi.2d	v1, #0000000000000000
    1560:      	movi.2d	v2, #0000000000000000
    1564:      	tbnz	w15, #0x0, 0x31f8 <ltmp0+0x31f8>
    1568:      	and	w15, w15, #0xff
    156c:      	tbnz	w15, #0x1, 0x3204 <ltmp0+0x3204>
    1570:      	tbnz	w15, #0x2, 0x3210 <ltmp0+0x3210>
    1574:      	tbnz	w15, #0x3, 0x321c <ltmp0+0x321c>
    1578:      	tbnz	w15, #0x4, 0x3228 <ltmp0+0x3228>
    157c:      	tbnz	w15, #0x5, 0x3234 <ltmp0+0x3234>
    1580:      	tbnz	w15, #0x6, 0x3240 <ltmp0+0x3240>
    1584:      	tbz	w15, #0x7, 0x1590 <ltmp0+0x1590>
    1588:      	add	x15, x19, #0x1c
    158c:      	ld1.s	{ v2 }[3], [x15]
    1590:      	xtn.4h	v3, v5
    1594:      	uzp1.8b	v3, v3, v0
    1598:      	str	q1, [sp, #0x810]
    159c:      	str	q2, [sp, #0x820]
    15a0:      	movi.2d	v25, #0000000000000000
    15a4:      	mov.b	v25[0], v3[0]
    15a8:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    15ac:      	ldr	d4, [x15]
    15b0:      	and.8b	v1, v25, v4
    15b4:      	addv.8b	b1, v1
    15b8:      	fmov	w21, s1
    15bc:      	umaxv.8b	b1, v25
    15c0:      	fmov	w15, s1
    15c4:      	rbit	w19, w21
    15c8:      	clz	w19, w19
    15cc:      	tst	w15, #0x1
    15d0:      	csel	w19, w19, wzr, ne
    15d4:      	dup.2d	v6, x9
    15d8:      	orr.16b	v1, v20, v6
    15dc:      	str	q1, [sp, #0x120]
    15e0:      	add.2d	v1, v0, v1
    15e4:      	movi.2d	v2, #0000000000000000
    15e8:      	mov.b	v2[0], v3[0]
    15ec:      	ushll.2d	v2, v2, #0x0
    15f0:      	shl.2d	v2, v2, #0x3f
    15f4:      	cmlt.2d	v2, v2, #0
    15f8:      	and.16b	v1, v2, v1
    15fc:      	movi.2d	v2, #0000000000000000
    1600:      	str	q2, [sp, #0x5b0]
    1604:      	str	q2, [sp, #0x5a0]
    1608:      	str	q2, [sp, #0x590]
    160c:      	str	q1, [sp, #0x580]
    1610:      	and	x22, x19, #0x7
    1614:      	add	x23, sp, #0x580
    1618:      	ldr	x22, [x23, x22, lsl #3]
    161c:      	sub	x22, x22, x19
    1620:      	add	x22, x7, x22, lsl #2
    1624:      	movi.2d	v1, #0000000000000000
    1628:      	movi.2d	v3, #0000000000000000
    162c:      	tbnz	w15, #0x0, 0x3250 <ltmp0+0x3250>
    1630:      	tbnz	w21, #0x1, 0x3258 <ltmp0+0x3258>
    1634:      	tbnz	w21, #0x2, 0x3264 <ltmp0+0x3264>
    1638:      	tbnz	w21, #0x3, 0x3270 <ltmp0+0x3270>
    163c:      	tbnz	w21, #0x4, 0x327c <ltmp0+0x327c>
    1640:      	tbnz	w21, #0x5, 0x3288 <ltmp0+0x3288>
    1644:      	tbnz	w21, #0x6, 0x3294 <ltmp0+0x3294>
    1648:      	tbz	w21, #0x7, 0x1654 <ltmp0+0x1654>
    164c:      	add	x15, x22, #0x1c
    1650:      	ld1.s	{ v3 }[3], [x15]
    1654:      	sshll.2d	v2, v5, #0x0
    1658:      	and.16b	v17, v2, v0
    165c:      	fmov	w15, s22
    1660:      	adrp	x22, 0x1000 <ltmp0+0x1000>
    1664:      	ldr	q0, [x22]
    1668:      	adrp	x22, 0x1000 <ltmp0+0x1000>
    166c:      	ldr	q7, [x22]
    1670:      	str	q0, [sp, #0x560]
    1674:      	str	q7, [sp, #0x550]
    1678:      	adrp	x22, 0x1000 <ltmp0+0x1000>
    167c:      	ldr	q0, [x22]
    1680:      	adrp	x22, 0x1000 <ltmp0+0x1000>
    1684:      	ldr	q7, [x22]
    1688:      	str	q0, [sp, #0x540]
    168c:      	str	q7, [sp, #0x530]
    1690:      	and	x22, x19, #0x7
    1694:      	add	x23, sp, #0x530
    1698:      	ldr	x23, [x23, x22, lsl #3]
    169c:      	lsl	x22, x19, #2
    16a0:      	sub	x23, x23, x22
    16a4:      	tst	w21, #0xff
    16a8:      	csel	x23, xzr, x23, eq
    16ac:      	add	x25, x28, x23
    16b0:      	ldp	q0, q7, [x25]
    16b4:      	zip2.8b	v16, v25, v0
    16b8:      	ushll.4s	v16, v16, #0x0
    16bc:      	shl.4s	v16, v16, #0x1f
    16c0:      	cmlt.4s	v16, v16, #0
    16c4:      	bif.16b	v3, v7, v16
    16c8:      	zip1.8b	v7, v25, v0
    16cc:      	ushll.4s	v7, v7, #0x0
    16d0:      	shl.4s	v7, v7, #0x1f
    16d4:      	cmlt.4s	v7, v7, #0
    16d8:      	bit.16b	v0, v1, v7
    16dc:      	stp	q0, q3, [x25]
    16e0:      	mov	w25, #0x21              ; =33
    16e4:      	dup.2d	v0, x25
    16e8:      	add.2d	v3, v20, v17
    16ec:      	add.2d	v0, v3, v0
    16f0:      	str	q0, [sp, #0x1f0]
    16f4:      	fmov	x25, d0
    16f8:      	add	x25, x7, x25, lsl #2
    16fc:      	movi.2d	v0, #0000000000000000
    1700:      	movi.2d	v16, #0000000000000000
    1704:      	tbnz	w15, #0x0, 0x32a4 <ltmp0+0x32a4>
    1708:      	and	w15, w15, #0xff
    170c:      	tbnz	w15, #0x1, 0x32b0 <ltmp0+0x32b0>
    1710:      	tbnz	w15, #0x2, 0x32bc <ltmp0+0x32bc>
    1714:      	tbnz	w15, #0x3, 0x32c8 <ltmp0+0x32c8>
    1718:      	tbnz	w15, #0x4, 0x32d4 <ltmp0+0x32d4>
    171c:      	tbnz	w15, #0x5, 0x32e0 <ltmp0+0x32e0>
    1720:      	tbnz	w15, #0x6, 0x32ec <ltmp0+0x32ec>
    1724:      	tbz	w15, #0x7, 0x1730 <ltmp0+0x1730>
    1728:      	add	x15, x25, #0x1c
    172c:      	ld1.s	{ v16 }[3], [x15]
    1730:      	sshll.2d	v1, v5, #0x0
    1734:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    1738:      	ldr	q7, [x15]
    173c:      	and.16b	v7, v1, v7
    1740:      	fmov	w15, s22
    1744:      	str	q0, [sp, #0x710]
    1748:      	str	q16, [sp, #0x720]
    174c:      	mov	w25, #0x21              ; =33
    1750:      	dup.2d	v0, x25
    1754:      	str	q17, [sp, #0x1e0]
    1758:      	add.2d	v17, v17, v0
    175c:      	add.2d	v0, v17, v7
    1760:      	str	q0, [sp, #0x1d0]
    1764:      	fmov	x25, d0
    1768:      	add	x25, x7, x25, lsl #2
    176c:      	movi.2d	v18, #0000000000000000
    1770:      	movi.2d	v19, #0000000000000000
    1774:      	tbnz	w15, #0x0, 0x32fc <ltmp0+0x32fc>
    1778:      	and	w15, w15, #0xff
    177c:      	tbnz	w15, #0x1, 0x3308 <ltmp0+0x3308>
    1780:      	tbnz	w15, #0x2, 0x3314 <ltmp0+0x3314>
    1784:      	tbnz	w15, #0x3, 0x3320 <ltmp0+0x3320>
    1788:      	tbnz	w15, #0x4, 0x332c <ltmp0+0x332c>
    178c:      	tbnz	w15, #0x5, 0x3338 <ltmp0+0x3338>
    1790:      	tbnz	w15, #0x6, 0x3344 <ltmp0+0x3344>
    1794:      	tbz	w15, #0x7, 0x17a0 <ltmp0+0x17a0>
    1798:      	add	x15, x25, #0x1c
    179c:      	ld1.s	{ v19 }[3], [x15]
    17a0:      	sshll.2d	v0, v5, #0x0
    17a4:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    17a8:      	ldr	q16, [x15]
    17ac:      	and.16b	v16, v0, v16
    17b0:      	fmov	w15, s22
    17b4:      	str	q18, [sp, #0x730]
    17b8:      	str	q19, [sp, #0x740]
    17bc:      	add.2d	v18, v17, v16
    17c0:      	str	q18, [sp, #0x1c0]
    17c4:      	fmov	x25, d18
    17c8:      	add	x25, x7, x25, lsl #2
    17cc:      	movi.2d	v18, #0000000000000000
    17d0:      	movi.2d	v19, #0000000000000000
    17d4:      	tbnz	w15, #0x0, 0x3354 <ltmp0+0x3354>
    17d8:      	and	w15, w15, #0xff
    17dc:      	tbnz	w15, #0x1, 0x3360 <ltmp0+0x3360>
    17e0:      	tbnz	w15, #0x2, 0x336c <ltmp0+0x336c>
    17e4:      	tbnz	w15, #0x3, 0x3378 <ltmp0+0x3378>
    17e8:      	tbnz	w15, #0x4, 0x3384 <ltmp0+0x3384>
    17ec:      	tbnz	w15, #0x5, 0x3390 <ltmp0+0x3390>
    17f0:      	tbnz	w15, #0x6, 0x339c <ltmp0+0x339c>
    17f4:      	tbz	w15, #0x7, 0x1800 <ltmp0+0x1800>
    17f8:      	add	x15, x25, #0x1c
    17fc:      	ld1.s	{ v19 }[3], [x15]
    1800:      	sshll.2d	v27, v5, #0x0
    1804:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    1808:      	ldr	q23, [x15]
    180c:      	and.16b	v10, v27, v23
    1810:      	fmov	w15, s22
    1814:      	str	q18, [sp, #0x750]
    1818:      	str	q19, [sp, #0x760]
    181c:      	add.2d	v17, v17, v10
    1820:      	str	q17, [sp, #0x1b0]
    1824:      	fmov	x25, d17
    1828:      	add	x25, x7, x25, lsl #2
    182c:      	movi.2d	v17, #0000000000000000
    1830:      	movi.2d	v18, #0000000000000000
    1834:      	tbnz	w15, #0x0, 0x33ac <ltmp0+0x33ac>
    1838:      	and	w15, w15, #0xff
    183c:      	tbnz	w15, #0x1, 0x33b8 <ltmp0+0x33b8>
    1840:      	tbnz	w15, #0x2, 0x33c4 <ltmp0+0x33c4>
    1844:      	tbnz	w15, #0x3, 0x33d0 <ltmp0+0x33d0>
    1848:      	str	q22, [sp, #0x230]
    184c:      	tbnz	w15, #0x4, 0x33e0 <ltmp0+0x33e0>
    1850:      	fmov	d9, d28
    1854:      	tbnz	w15, #0x5, 0x33f0 <ltmp0+0x33f0>
    1858:      	fmov	d28, d29
    185c:      	mov.16b	v29, v8
    1860:      	tbnz	w15, #0x6, 0x3404 <ltmp0+0x3404>
    1864:      	mov.16b	v8, v31
    1868:      	mov.16b	v31, v30
    186c:      	tbz	w15, #0x7, 0x1878 <ltmp0+0x1878>
    1870:      	add	x15, x25, #0x1c
    1874:      	ld1.s	{ v18 }[3], [x15]
    1878:      	sshll.2d	v12, v21, #0x0
    187c:      	movi.2s	v24, #0x42
    1880:      	umull.2d	v19, v28, v24
    1884:      	umull.2d	v23, v9, v24
    1888:      	umull.2d	v24, v15, v24
    188c:      	and.16b	v24, v13, v24
    1890:      	stp	q24, q12, [sp, #0x150]
    1894:      	and.16b	v12, v12, v23
    1898:      	and.16b	v30, v14, v19
    189c:      	ldr	q19, [sp, #0x770]
    18a0:      	ldr	q23, [sp, #0x780]
    18a4:      	bif.16b	v18, v23, v21
    18a8:      	bif.16b	v17, v19, v5
    18ac:      	str	q17, [sp, #0x770]
    18b0:      	str	q18, [sp, #0x780]
    18b4:      	add.2d	v17, v8, v24
    18b8:      	stp	q30, q12, [sp, #0x130]
    18bc:      	add.2d	v18, v29, v12
    18c0:      	add.2d	v19, v31, v30
    18c4:      	mov.16b	v30, v31
    18c8:      	mov	w15, #0x41              ; =65
    18cc:      	dup.2d	v23, x15
    18d0:      	add.2d	v24, v19, v23
    18d4:      	add.2d	v19, v18, v23
    18d8:      	add.2d	v18, v17, v23
    18dc:      	mov	b17, v25[0]
    18e0:      	mov.b	v17[4], v25[1]
    18e4:      	add.2d	v23, v3, v23
    18e8:      	ushll.2d	v3, v17, #0x0
    18ec:      	shl.2d	v3, v3, #0x3f
    18f0:      	cmlt.2d	v3, v3, #0
    18f4:      	stp	q23, q18, [sp, #0x170]
    18f8:      	and.16b	v3, v3, v23
    18fc:      	mov	b17, v25[2]
    1900:      	mov.b	v17[4], v25[3]
    1904:      	ushll.2d	v17, v17, #0x0
    1908:      	shl.2d	v17, v17, #0x3f
    190c:      	cmlt.2d	v17, v17, #0
    1910:      	and.16b	v17, v17, v18
    1914:      	mov	b18, v25[4]
    1918:      	mov.b	v18[4], v25[5]
    191c:      	ushll.2d	v18, v18, #0x0
    1920:      	shl.2d	v18, v18, #0x3f
    1924:      	cmlt.2d	v18, v18, #0
    1928:      	stp	q19, q24, [sp, #0x190]
    192c:      	and.16b	v18, v18, v19
    1930:      	mov	b19, v25[6]
    1934:      	mov.b	v19[4], v25[7]
    1938:      	ushll.2d	v19, v19, #0x0
    193c:      	shl.2d	v19, v19, #0x3f
    1940:      	cmlt.2d	v19, v19, #0
    1944:      	and.16b	v19, v19, v24
    1948:      	shl.8b	v23, v25, #0x7
    194c:      	cmlt.8b	v23, v23, #0
    1950:      	and.8b	v4, v23, v4
    1954:      	addv.8b	b4, v4
    1958:      	str	d4, [sp, #0x240]
    195c:      	fmov	w25, s4
    1960:      	str	q19, [sp, #0x510]
    1964:      	str	q18, [sp, #0x500]
    1968:      	str	q17, [sp, #0x4f0]
    196c:      	str	q3, [sp, #0x4e0]
    1970:      	and	x15, x19, #0x7
    1974:      	add	x30, sp, #0x4e0
    1978:      	ldr	x15, [x30, x15, lsl #3]
    197c:      	sub	x15, x15, x19
    1980:      	add	x7, x7, x15, lsl #2
    1984:      	movi.2d	v3, #0000000000000000
    1988:      	movi.2d	v4, #0000000000000000
    198c:      	tbnz	w25, #0x0, 0x341c <ltmp0+0x341c>
    1990:      	tbnz	w25, #0x1, 0x3424 <ltmp0+0x3424>
    1994:      	mov.16b	v24, v8
    1998:      	mov.16b	v31, v29
    199c:      	tbnz	w25, #0x2, 0x3438 <ltmp0+0x3438>
    19a0:      	fmov	d29, d28
    19a4:      	tbnz	w25, #0x3, 0x3448 <ltmp0+0x3448>
    19a8:      	fmov	d8, d15
    19ac:      	ldr	q15, [sp, #0x230]
    19b0:      	tbnz	w25, #0x4, 0x345c <ltmp0+0x345c>
    19b4:      	tbnz	w25, #0x5, 0x3468 <ltmp0+0x3468>
    19b8:      	tbnz	w25, #0x6, 0x3474 <ltmp0+0x3474>
    19bc:      	tbz	w25, #0x7, 0x19c8 <ltmp0+0x19c8>
    19c0:      	add	x15, x7, #0x1c
    19c4:      	ld1.s	{ v4 }[3], [x15]
    19c8:      	fmov	w15, s15
    19cc:      	sshll.2d	v17, v5, #0x0
    19d0:      	add	x7, x26, x23
    19d4:      	ldp	q18, q19, [x7]
    19d8:      	zip2.8b	v23, v25, v0
    19dc:      	ushll.4s	v23, v23, #0x0
    19e0:      	shl.4s	v23, v23, #0x1f
    19e4:      	cmlt.4s	v23, v23, #0
    19e8:      	bif.16b	v4, v19, v23
    19ec:      	zip1.8b	v19, v25, v0
    19f0:      	ushll.4s	v19, v19, #0x0
    19f4:      	shl.4s	v19, v19, #0x1f
    19f8:      	cmlt.4s	v19, v19, #0
    19fc:      	bif.16b	v3, v18, v19
    1a00:      	stp	q3, q4, [x7]
    1a04:      	movi.2s	v3, #0x21
    1a08:      	umull.2d	v3, v11, v3
    1a0c:      	and.16b	v12, v17, v3
    1a10:      	add.2d	v19, v12, v20
    1a14:      	fmov	x7, d19
    1a18:      	add	x7, x5, x7, lsl #2
    1a1c:      	movi.2d	v3, #0000000000000000
    1a20:      	movi.2d	v4, #0000000000000000
    1a24:      	tbnz	w15, #0x0, 0x3484 <ltmp0+0x3484>
    1a28:      	and	w15, w15, #0xff
    1a2c:      	tbnz	w15, #0x1, 0x3490 <ltmp0+0x3490>
    1a30:      	tbnz	w15, #0x2, 0x349c <ltmp0+0x349c>
    1a34:      	tbnz	w15, #0x3, 0x34a8 <ltmp0+0x34a8>
    1a38:      	tbnz	w15, #0x4, 0x34b4 <ltmp0+0x34b4>
    1a3c:      	tbnz	w15, #0x5, 0x34c0 <ltmp0+0x34c0>
    1a40:      	tbnz	w15, #0x6, 0x34cc <ltmp0+0x34cc>
    1a44:      	tbz	w15, #0x7, 0x1a50 <ltmp0+0x1a50>
    1a48:      	add	x15, x7, #0x1c
    1a4c:      	ld1.s	{ v4 }[3], [x15]
    1a50:      	fmov	w15, s15
    1a54:      	ldr	q18, [sp, #0x670]
    1a58:      	ldr	q20, [sp, #0x680]
    1a5c:      	bif.16b	v4, v20, v21
    1a60:      	bif.16b	v3, v18, v5
    1a64:      	str	q3, [sp, #0x670]
    1a68:      	str	q4, [sp, #0x680]
    1a6c:      	add.2d	v18, v12, v7
    1a70:      	fmov	x7, d18
    1a74:      	add	x7, x5, x7, lsl #2
    1a78:      	movi.2d	v3, #0000000000000000
    1a7c:      	movi.2d	v4, #0000000000000000
    1a80:      	tbnz	w15, #0x0, 0x34dc <ltmp0+0x34dc>
    1a84:      	and	w15, w15, #0xff
    1a88:      	tbnz	w15, #0x1, 0x34e8 <ltmp0+0x34e8>
    1a8c:      	tbnz	w15, #0x2, 0x34f4 <ltmp0+0x34f4>
    1a90:      	tbnz	w15, #0x3, 0x3500 <ltmp0+0x3500>
    1a94:      	tbnz	w15, #0x4, 0x350c <ltmp0+0x350c>
    1a98:      	tbnz	w15, #0x5, 0x3518 <ltmp0+0x3518>
    1a9c:      	tbnz	w15, #0x6, 0x3524 <ltmp0+0x3524>
    1aa0:      	tbz	w15, #0x7, 0x1aac <ltmp0+0x1aac>
    1aa4:      	add	x15, x7, #0x1c
    1aa8:      	ld1.s	{ v4 }[3], [x15]
    1aac:      	fmov	w15, s15
    1ab0:      	ldr	q7, [sp, #0x690]
    1ab4:      	ldr	q20, [sp, #0x6a0]
    1ab8:      	bif.16b	v4, v20, v21
    1abc:      	bif.16b	v3, v7, v5
    1ac0:      	str	q3, [sp, #0x690]
    1ac4:      	str	q4, [sp, #0x6a0]
    1ac8:      	add.2d	v11, v12, v16
    1acc:      	fmov	x7, d11
    1ad0:      	add	x7, x5, x7, lsl #2
    1ad4:      	movi.2d	v3, #0000000000000000
    1ad8:      	movi.2d	v4, #0000000000000000
    1adc:      	tbnz	w15, #0x0, 0x3534 <ltmp0+0x3534>
    1ae0:      	and	w15, w15, #0xff
    1ae4:      	tbnz	w15, #0x1, 0x3540 <ltmp0+0x3540>
    1ae8:      	tbnz	w15, #0x2, 0x354c <ltmp0+0x354c>
    1aec:      	tbnz	w15, #0x3, 0x3558 <ltmp0+0x3558>
    1af0:      	tbnz	w15, #0x4, 0x3564 <ltmp0+0x3564>
    1af4:      	tbnz	w15, #0x5, 0x3570 <ltmp0+0x3570>
    1af8:      	tbnz	w15, #0x6, 0x357c <ltmp0+0x357c>
    1afc:      	tbz	w15, #0x7, 0x1b08 <ltmp0+0x1b08>
    1b00:      	add	x15, x7, #0x1c
    1b04:      	ld1.s	{ v4 }[3], [x15]
    1b08:      	fmov	w15, s15
    1b0c:      	ldr	q7, [sp, #0x6b0]
    1b10:      	ldr	q16, [sp, #0x6c0]
    1b14:      	bif.16b	v4, v16, v21
    1b18:      	bif.16b	v3, v7, v5
    1b1c:      	str	q3, [sp, #0x6b0]
    1b20:      	str	q4, [sp, #0x6c0]
    1b24:      	add.2d	v20, v12, v10
    1b28:      	fmov	x7, d20
    1b2c:      	add	x7, x5, x7, lsl #2
    1b30:      	movi.2d	v3, #0000000000000000
    1b34:      	movi.2d	v4, #0000000000000000
    1b38:      	tbnz	w15, #0x0, 0x358c <ltmp0+0x358c>
    1b3c:      	and	w15, w15, #0xff
    1b40:      	tbnz	w15, #0x1, 0x3598 <ltmp0+0x3598>
    1b44:      	tbnz	w15, #0x2, 0x35a4 <ltmp0+0x35a4>
    1b48:      	tbnz	w15, #0x3, 0x35b0 <ltmp0+0x35b0>
    1b4c:      	tbnz	w15, #0x4, 0x35bc <ltmp0+0x35bc>
    1b50:      	tbnz	w15, #0x5, 0x35c8 <ltmp0+0x35c8>
    1b54:      	tbnz	w15, #0x6, 0x35d4 <ltmp0+0x35d4>
    1b58:      	tbz	w15, #0x7, 0x1b64 <ltmp0+0x1b64>
    1b5c:      	add	x15, x7, #0x1c
    1b60:      	ld1.s	{ v4 }[3], [x15]
    1b64:      	orr.16b	v31, v31, v6
    1b68:      	orr.16b	v7, v24, v6
    1b6c:      	orr.16b	v6, v30, v6
    1b70:      	mov.16b	v30, v7
    1b74:      	sshll.2d	v7, v21, #0x0
    1b78:      	movi.2s	v24, #0x21
    1b7c:      	umull.2d	v16, v8, v24
    1b80:      	umull.2d	v23, v9, v24
    1b84:      	umull.2d	v24, v29, v24
    1b88:      	and.16b	v24, v14, v24
    1b8c:      	and.16b	v7, v7, v23
    1b90:      	and.16b	v16, v13, v16
    1b94:      	ldr	q23, [sp, #0x6d0]
    1b98:      	ldr	q28, [sp, #0x6e0]
    1b9c:      	bif.16b	v4, v28, v21
    1ba0:      	bif.16b	v3, v23, v5
    1ba4:      	str	q3, [sp, #0x6d0]
    1ba8:      	str	q4, [sp, #0x6e0]
    1bac:      	add.2d	v3, v24, v6
    1bb0:      	str	q31, [sp, #0x110]
    1bb4:      	add.2d	v4, v7, v31
    1bb8:      	add.2d	v7, v16, v30
    1bbc:      	ldr	q28, [sp, #0x120]
    1bc0:      	add.2d	v16, v12, v28
    1bc4:      	mov	b23, v25[0]
    1bc8:      	mov.b	v23[4], v25[1]
    1bcc:      	ushll.2d	v23, v23, #0x0
    1bd0:      	shl.2d	v23, v23, #0x3f
    1bd4:      	cmlt.2d	v23, v23, #0
    1bd8:      	and.16b	v16, v23, v16
    1bdc:      	mov	b23, v25[2]
    1be0:      	mov.b	v23[4], v25[3]
    1be4:      	ushll.2d	v23, v23, #0x0
    1be8:      	shl.2d	v23, v23, #0x3f
    1bec:      	cmlt.2d	v23, v23, #0
    1bf0:      	and.16b	v7, v23, v7
    1bf4:      	mov	b23, v25[4]
    1bf8:      	mov.b	v23[4], v25[5]
    1bfc:      	ushll.2d	v23, v23, #0x0
    1c00:      	shl.2d	v23, v23, #0x3f
    1c04:      	cmlt.2d	v23, v23, #0
    1c08:      	mov	b24, v25[6]
    1c0c:      	mov.b	v24[4], v25[7]
    1c10:      	and.16b	v4, v23, v4
    1c14:      	ushll.2d	v23, v24, #0x0
    1c18:      	shl.2d	v23, v23, #0x3f
    1c1c:      	cmlt.2d	v23, v23, #0
    1c20:      	and.16b	v3, v23, v3
    1c24:      	str	q3, [sp, #0x4c0]
    1c28:      	str	q4, [sp, #0x4b0]
    1c2c:      	str	q7, [sp, #0x4a0]
    1c30:      	str	q16, [sp, #0x490]
    1c34:      	and	x15, x19, #0x7
    1c38:      	add	x7, sp, #0x490
    1c3c:      	ldr	x15, [x7, x15, lsl #3]
    1c40:      	ldr	d23, [sp, #0x240]
    1c44:      	fmov	w25, s23
    1c48:      	sub	x15, x15, x19
    1c4c:      	lsl	x7, x15, #2
    1c50:      	add	x5, x5, x7
    1c54:      	movi.2d	v3, #0000000000000000
    1c58:      	movi.2d	v4, #0000000000000000
    1c5c:      	tbnz	w25, #0x0, 0x35e4 <ltmp0+0x35e4>
    1c60:      	tbnz	w25, #0x1, 0x35ec <ltmp0+0x35ec>
    1c64:      	tbnz	w25, #0x2, 0x35f8 <ltmp0+0x35f8>
    1c68:      	tbnz	w25, #0x3, 0x3604 <ltmp0+0x3604>
    1c6c:      	tbnz	w25, #0x4, 0x3610 <ltmp0+0x3610>
    1c70:      	tbnz	w25, #0x5, 0x361c <ltmp0+0x361c>
    1c74:      	tbnz	w25, #0x6, 0x3628 <ltmp0+0x3628>
    1c78:      	tbz	w25, #0x7, 0x1c84 <ltmp0+0x1c84>
    1c7c:      	add	x15, x5, #0x1c
    1c80:      	ld1.s	{ v4 }[3], [x15]
    1c84:      	and.16b	v7, v17, v19
    1c88:      	fmov	w15, s15
    1c8c:      	add	x5, x24, x23
    1c90:      	ldp	q16, q17, [x5]
    1c94:      	zip2.8b	v19, v25, v0
    1c98:      	ushll.4s	v19, v19, #0x0
    1c9c:      	shl.4s	v19, v19, #0x1f
    1ca0:      	cmlt.4s	v19, v19, #0
    1ca4:      	bif.16b	v4, v17, v19
    1ca8:      	zip1.8b	v17, v25, v0
    1cac:      	ushll.4s	v17, v17, #0x0
    1cb0:      	shl.4s	v17, v17, #0x1f
    1cb4:      	cmlt.4s	v17, v17, #0
    1cb8:      	bif.16b	v3, v16, v17
    1cbc:      	stp	q3, q4, [x5]
    1cc0:      	fmov	x5, d7
    1cc4:      	add	x5, x4, x5, lsl #2
    1cc8:      	movi.2d	v3, #0000000000000000
    1ccc:      	movi.2d	v4, #0000000000000000
    1cd0:      	tbnz	w15, #0x0, 0x3638 <ltmp0+0x3638>
    1cd4:      	and	w15, w15, #0xff
    1cd8:      	tbnz	w15, #0x1, 0x3644 <ltmp0+0x3644>
    1cdc:      	tbnz	w15, #0x2, 0x3650 <ltmp0+0x3650>
    1ce0:      	tbnz	w15, #0x3, 0x365c <ltmp0+0x365c>
    1ce4:      	tbnz	w15, #0x4, 0x3668 <ltmp0+0x3668>
    1ce8:      	tbnz	w15, #0x5, 0x3674 <ltmp0+0x3674>
    1cec:      	tbnz	w15, #0x6, 0x3680 <ltmp0+0x3680>
    1cf0:      	tbz	w15, #0x7, 0x1cfc <ltmp0+0x1cfc>
    1cf4:      	add	x15, x5, #0x1c
    1cf8:      	ld1.s	{ v4 }[3], [x15]
    1cfc:      	sshll.2d	v7, v5, #0x0
    1d00:      	and.16b	v7, v7, v18
    1d04:      	fmov	w15, s15
    1d08:      	ldr	q16, [sp, #0x5d0]
    1d0c:      	ldr	q17, [sp, #0x5e0]
    1d10:      	bif.16b	v4, v17, v21
    1d14:      	bif.16b	v3, v16, v5
    1d18:      	str	q3, [sp, #0x5d0]
    1d1c:      	str	q4, [sp, #0x5e0]
    1d20:      	fmov	x5, d7
    1d24:      	add	x5, x4, x5, lsl #2
    1d28:      	movi.2d	v3, #0000000000000000
    1d2c:      	movi.2d	v4, #0000000000000000
    1d30:      	tbnz	w15, #0x0, 0x3690 <ltmp0+0x3690>
    1d34:      	and	w15, w15, #0xff
    1d38:      	tbnz	w15, #0x1, 0x369c <ltmp0+0x369c>
    1d3c:      	tbnz	w15, #0x2, 0x36a8 <ltmp0+0x36a8>
    1d40:      	tbnz	w15, #0x3, 0x36b4 <ltmp0+0x36b4>
    1d44:      	tbnz	w15, #0x4, 0x36c0 <ltmp0+0x36c0>
    1d48:      	tbnz	w15, #0x5, 0x36cc <ltmp0+0x36cc>
    1d4c:      	tbnz	w15, #0x6, 0x36d8 <ltmp0+0x36d8>
    1d50:      	tbz	w15, #0x7, 0x1d5c <ltmp0+0x1d5c>
    1d54:      	add	x15, x5, #0x1c
    1d58:      	ld1.s	{ v4 }[3], [x15]
    1d5c:      	sshll.2d	v7, v5, #0x0
    1d60:      	and.16b	v7, v7, v11
    1d64:      	fmov	w15, s15
    1d68:      	ldr	q16, [sp, #0x5f0]
    1d6c:      	ldr	q17, [sp, #0x600]
    1d70:      	bif.16b	v4, v17, v21
    1d74:      	bif.16b	v3, v16, v5
    1d78:      	str	q3, [sp, #0x5f0]
    1d7c:      	str	q4, [sp, #0x600]
    1d80:      	fmov	x5, d7
    1d84:      	add	x5, x4, x5, lsl #2
    1d88:      	movi.2d	v3, #0000000000000000
    1d8c:      	movi.2d	v4, #0000000000000000
    1d90:      	tbnz	w15, #0x0, 0x36e8 <ltmp0+0x36e8>
    1d94:      	and	w15, w15, #0xff
    1d98:      	tbnz	w15, #0x1, 0x36f4 <ltmp0+0x36f4>
    1d9c:      	tbnz	w15, #0x2, 0x3700 <ltmp0+0x3700>
    1da0:      	tbnz	w15, #0x3, 0x370c <ltmp0+0x370c>
    1da4:      	tbnz	w15, #0x4, 0x3718 <ltmp0+0x3718>
    1da8:      	tbnz	w15, #0x5, 0x3724 <ltmp0+0x3724>
    1dac:      	tbnz	w15, #0x6, 0x3730 <ltmp0+0x3730>
    1db0:      	tbz	w15, #0x7, 0x1dbc <ltmp0+0x1dbc>
    1db4:      	add	x15, x5, #0x1c
    1db8:      	ld1.s	{ v4 }[3], [x15]
    1dbc:      	sshll.2d	v7, v5, #0x0
    1dc0:      	and.16b	v7, v7, v20
    1dc4:      	fmov	w15, s15
    1dc8:      	ldr	q16, [sp, #0x610]
    1dcc:      	ldr	q17, [sp, #0x620]
    1dd0:      	bif.16b	v4, v17, v21
    1dd4:      	bif.16b	v3, v16, v5
    1dd8:      	str	q3, [sp, #0x610]
    1ddc:      	str	q4, [sp, #0x620]
    1de0:      	fmov	x5, d7
    1de4:      	add	x5, x4, x5, lsl #2
    1de8:      	movi.2d	v3, #0000000000000000
    1dec:      	movi.2d	v4, #0000000000000000
    1df0:      	tbnz	w15, #0x0, 0x3740 <ltmp0+0x3740>
    1df4:      	and	w15, w15, #0xff
    1df8:      	tbnz	w15, #0x1, 0x374c <ltmp0+0x374c>
    1dfc:      	tbnz	w15, #0x2, 0x3758 <ltmp0+0x3758>
    1e00:      	tbnz	w15, #0x3, 0x3764 <ltmp0+0x3764>
    1e04:      	tbnz	w15, #0x4, 0x3770 <ltmp0+0x3770>
    1e08:      	tbnz	w15, #0x5, 0x377c <ltmp0+0x377c>
    1e0c:      	tbnz	w15, #0x6, 0x3788 <ltmp0+0x3788>
    1e10:      	tbz	w15, #0x7, 0x1e1c <ltmp0+0x1e1c>
    1e14:      	add	x15, x5, #0x1c
    1e18:      	ld1.s	{ v4 }[3], [x15]
    1e1c:      	ldr	q7, [sp, #0x630]
    1e20:      	ldr	q16, [sp, #0x640]
    1e24:      	bif.16b	v4, v16, v21
    1e28:      	bif.16b	v3, v7, v5
    1e2c:      	str	q3, [sp, #0x630]
    1e30:      	str	q4, [sp, #0x640]
    1e34:      	add	x4, x4, x7
    1e38:      	fmov	w5, s23
    1e3c:      	movi.2d	v3, #0000000000000000
    1e40:      	movi.2d	v4, #0000000000000000
    1e44:      	tbnz	w5, #0x0, 0x3798 <ltmp0+0x3798>
    1e48:      	tbnz	w5, #0x1, 0x37a0 <ltmp0+0x37a0>
    1e4c:      	tbnz	w5, #0x2, 0x37ac <ltmp0+0x37ac>
    1e50:      	tbnz	w5, #0x3, 0x37b8 <ltmp0+0x37b8>
    1e54:      	tbnz	w5, #0x4, 0x37c4 <ltmp0+0x37c4>
    1e58:      	tbnz	w5, #0x5, 0x37d0 <ltmp0+0x37d0>
    1e5c:      	tbnz	w5, #0x6, 0x37dc <ltmp0+0x37dc>
    1e60:      	tbz	w5, #0x7, 0x1e6c <ltmp0+0x1e6c>
    1e64:      	add	x15, x4, #0x1c
    1e68:      	ld1.s	{ v4 }[3], [x15]
    1e6c:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    1e70:      	ldr	q7, [x15]
    1e74:      	and.16b	v18, v2, v7
    1e78:      	and.16b	v7, v2, v26
    1e7c:      	fmov	w4, s15
    1e80:      	add	x15, x27, x23
    1e84:      	ldp	q2, q16, [x15]
    1e88:      	zip2.8b	v17, v25, v0
    1e8c:      	ushll.4s	v17, v17, #0x0
    1e90:      	shl.4s	v17, v17, #0x1f
    1e94:      	cmlt.4s	v17, v17, #0
    1e98:      	bif.16b	v4, v16, v17
    1e9c:      	zip1.8b	v16, v25, v0
    1ea0:      	ushll.4s	v16, v16, #0x0
    1ea4:      	shl.4s	v16, v16, #0x1f
    1ea8:      	cmlt.4s	v16, v16, #0
    1eac:      	bit.16b	v2, v3, v16
    1eb0:      	stp	q2, q4, [x15]
    1eb4:      	fmov	x15, d18
    1eb8:      	add	x5, x28, x15
    1ebc:      	ldp	q2, q3, [x5]
    1ec0:      	add	x5, x24, x15
    1ec4:      	ldp	q4, q16, [x5]
    1ec8:      	stp	q4, q2, [sp, #0xb0]
    1ecc:      	fmul.4s	v2, v2, v4
    1ed0:      	add	x5, x26, x15
    1ed4:      	ldp	q4, q17, [x5]
    1ed8:      	add	x15, x27, x15
    1edc:      	ldp	q19, q31, [x15]
    1ee0:      	stp	q19, q4, [sp, #0x90]
    1ee4:      	fmul.4s	v4, v4, v19
    1ee8:      	fsub.4s	v2, v2, v4
    1eec:      	and.16b	v2, v5, v2
    1ef0:      	fmov	x15, d7
    1ef4:      	add	x15, x1, x15, lsl #2
    1ef8:      	tbnz	w4, #0x0, 0x37ec <ltmp0+0x37ec>
    1efc:      	and	w4, w4, #0xff
    1f00:      	tbnz	w4, #0x1, 0x37f8 <ltmp0+0x37f8>
    1f04:      	tbnz	w4, #0x2, 0x3804 <ltmp0+0x3804>
    1f08:      	tbnz	w4, #0x3, 0x3810 <ltmp0+0x3810>
    1f0c:      	fmul.4s	v2, v3, v16
    1f10:      	fmul.4s	v4, v17, v31
    1f14:      	fsub.4s	v2, v2, v4
    1f18:      	and.16b	v2, v21, v2
    1f1c:      	tbnz	w4, #0x4, 0x382c <ltmp0+0x382c>
    1f20:      	tbnz	w4, #0x5, 0x3834 <ltmp0+0x3834>
    1f24:      	tbnz	w4, #0x6, 0x3840 <ltmp0+0x3840>
    1f28:      	tbz	w4, #0x7, 0x1f34 <ltmp0+0x1f34>
    1f2c:      	add	x15, x15, #0x1c
    1f30:      	st1.s	{ v2 }[3], [x15]
    1f34:      	ldr	q2, [sp, #0x200]
    1f38:      	and.16b	v2, v1, v2
    1f3c:      	fmov	d1, x9
    1f40:      	and.16b	v1, v0, v1
    1f44:      	fmov	w4, s15
    1f48:      	fmov	x15, d1
    1f4c:      	add	x5, x28, x15
    1f50:      	ldp	q1, q7, [x5]
    1f54:      	add	x5, x24, x15
    1f58:      	ldp	q4, q19, [x5]
    1f5c:      	stp	q4, q1, [sp, #0x70]
    1f60:      	fmul.4s	v1, v1, v4
    1f64:      	add	x5, x26, x15
    1f68:      	ldp	q4, q20, [x5]
    1f6c:      	add	x15, x27, x15
    1f70:      	ldp	q22, q26, [x15]
    1f74:      	stp	q22, q4, [sp, #0x40]
    1f78:      	fmul.4s	v4, v4, v22
    1f7c:      	fsub.4s	v1, v1, v4
    1f80:      	and.16b	v1, v5, v1
    1f84:      	fmov	x15, d2
    1f88:      	add	x15, x1, x15, lsl #2
    1f8c:      	tbnz	w4, #0x0, 0x3850 <ltmp0+0x3850>
    1f90:      	and	w4, w4, #0xff
    1f94:      	tbnz	w4, #0x1, 0x385c <ltmp0+0x385c>
    1f98:      	tbnz	w4, #0x2, 0x3868 <ltmp0+0x3868>
    1f9c:      	tbnz	w4, #0x3, 0x3874 <ltmp0+0x3874>
    1fa0:      	fmul.4s	v1, v7, v19
    1fa4:      	fmul.4s	v2, v20, v26
    1fa8:      	fsub.4s	v1, v1, v2
    1fac:      	and.16b	v1, v21, v1
    1fb0:      	tbnz	w4, #0x4, 0x3890 <ltmp0+0x3890>
    1fb4:      	tbnz	w4, #0x5, 0x3898 <ltmp0+0x3898>
    1fb8:      	tbnz	w4, #0x6, 0x38a4 <ltmp0+0x38a4>
    1fbc:      	stp	q7, q17, [sp, #0xf0]
    1fc0:      	str	q16, [sp, #0x200]
    1fc4:      	tbz	w4, #0x7, 0x1fd0 <ltmp0+0x1fd0>
    1fc8:      	add	x15, x15, #0x1c
    1fcc:      	st1.s	{ v1 }[3], [x15]
    1fd0:      	ldr	q1, [sp, #0x220]
    1fd4:      	and.16b	v1, v0, v1
    1fd8:      	ldr	q0, [sp, #0x20]
    1fdc:      	and.16b	v0, v27, v0
    1fe0:      	fmov	w4, s15
    1fe4:      	fmov	x15, d0
    1fe8:      	add	x5, x28, x15
    1fec:      	ldp	q0, q9, [x5]
    1ff0:      	add	x5, x24, x15
    1ff4:      	ldp	q16, q8, [x5]
    1ff8:      	str	q0, [sp, #0x30]
    1ffc:      	fmul.4s	v0, v0, v16
    2000:      	add	x5, x26, x15
    2004:      	ldp	q4, q22, [x5]
    2008:      	add	x15, x27, x15
    200c:      	ldp	q17, q23, [x15]
    2010:      	fmul.4s	v2, v4, v17
    2014:      	fsub.4s	v0, v0, v2
    2018:      	and.16b	v0, v5, v0
    201c:      	fmov	x15, d1
    2020:      	add	x15, x1, x15, lsl #2
    2024:      	tbnz	w4, #0x0, 0x38bc <ltmp0+0x38bc>
    2028:      	and	w4, w4, #0xff
    202c:      	tbnz	w4, #0x1, 0x38c8 <ltmp0+0x38c8>
    2030:      	tbnz	w4, #0x2, 0x38d4 <ltmp0+0x38d4>
    2034:      	tbnz	w4, #0x3, 0x38e0 <ltmp0+0x38e0>
    2038:      	fmul.4s	v0, v9, v8
    203c:      	fmul.4s	v1, v22, v23
    2040:      	fsub.4s	v0, v0, v1
    2044:      	and.16b	v0, v21, v0
    2048:      	tbnz	w4, #0x4, 0x38fc <ltmp0+0x38fc>
    204c:      	tbnz	w4, #0x5, 0x3904 <ltmp0+0x3904>
    2050:      	tbnz	w4, #0x6, 0x3910 <ltmp0+0x3910>
    2054:      	stp	q26, q20, [sp, #0xd0]
    2058:      	str	q19, [sp, #0x220]
    205c:      	tbz	w4, #0x7, 0x2068 <ltmp0+0x2068>
    2060:      	add	x15, x15, #0x1c
    2064:      	st1.s	{ v0 }[3], [x15]
    2068:      	ldr	q0, [sp, #0x210]
    206c:      	and.16b	v1, v27, v0
    2070:      	sshll.2d	v0, v5, #0x0
    2074:      	ldr	q2, [sp, #0x10]
    2078:      	and.16b	v0, v0, v2
    207c:      	fmov	w4, s15
    2080:      	fmov	x15, d0
    2084:      	add	x5, x28, x15
    2088:      	ldp	q19, q24, [x5]
    208c:      	add	x5, x24, x15
    2090:      	ldp	q20, q27, [x5]
    2094:      	fmul.4s	v0, v19, v20
    2098:      	add	x5, x26, x15
    209c:      	ldp	q26, q7, [x5]
    20a0:      	add	x15, x27, x15
    20a4:      	ldp	q10, q29, [x15]
    20a8:      	fmul.4s	v2, v26, v10
    20ac:      	fsub.4s	v0, v0, v2
    20b0:      	and.16b	v0, v5, v0
    20b4:      	fmov	x15, d1
    20b8:      	add	x15, x1, x15, lsl #2
    20bc:      	tbnz	w4, #0x0, 0x3928 <ltmp0+0x3928>
    20c0:      	and	w4, w4, #0xff
    20c4:      	tbnz	w4, #0x1, 0x3934 <ltmp0+0x3934>
    20c8:      	tbnz	w4, #0x2, 0x3940 <ltmp0+0x3940>
    20cc:      	tbnz	w4, #0x3, 0x394c <ltmp0+0x394c>
    20d0:      	fmul.4s	v0, v24, v27
    20d4:      	fmul.4s	v1, v7, v29
    20d8:      	fsub.4s	v0, v0, v1
    20dc:      	and.16b	v0, v21, v0
    20e0:      	tbnz	w4, #0x4, 0x3968 <ltmp0+0x3968>
    20e4:      	tbnz	w4, #0x5, 0x3970 <ltmp0+0x3970>
    20e8:      	str	q29, [sp, #0x60]
    20ec:      	tbnz	w4, #0x6, 0x3980 <ltmp0+0x3980>
    20f0:      	str	q27, [sp, #0x210]
    20f4:      	mov.16b	v29, v3
    20f8:      	tbz	w4, #0x7, 0x2104 <ltmp0+0x2104>
    20fc:      	add	x15, x15, #0x1c
    2100:      	st1.s	{ v0 }[3], [x15]
    2104:      	adrp	x15, 0x2000 <ltmp0+0x2000>
    2108:      	ldr	q0, [x15]
    210c:      	and.16b	v0, v14, v0
    2110:      	adrp	x15, 0x2000 <ltmp0+0x2000>
    2114:      	ldr	q1, [x15]
    2118:      	and.16b	v1, v13, v1
    211c:      	adrp	x15, 0x2000 <ltmp0+0x2000>
    2120:      	ldr	q2, [x15]
    2124:      	ldr	q3, [sp, #0x160]
    2128:      	and.16b	v2, v3, v2
    212c:      	ldr	q3, [sp, #0x130]
    2130:      	add.2d	v15, v3, v6
    2134:      	ldr	q3, [sp, #0x140]
    2138:      	ldr	q6, [sp, #0x110]
    213c:      	add.2d	v3, v3, v6
    2140:      	ldr	q6, [sp, #0x150]
    2144:      	add.2d	v27, v6, v30
    2148:      	ldr	q6, [sp, #0x1e0]
    214c:      	add.2d	v28, v6, v28
    2150:      	str	q18, [sp, #0x440]
    2154:      	str	q1, [sp, #0x450]
    2158:      	str	q2, [sp, #0x460]
    215c:      	str	q0, [sp, #0x470]
    2160:      	ubfiz	x4, x19, #3, #3
    2164:      	add	x15, sp, #0x440
    2168:      	ldr	x15, [x15, x4]
    216c:      	orr	x15, x15, #0x80
    2170:      	sub	x15, x15, x22
    2174:      	tst	w21, #0xff
    2178:      	csel	x15, xzr, x15, eq
    217c:      	add	x5, x28, x15
    2180:      	ldp	q0, q6, [x5]
    2184:      	add	x5, x24, x15
    2188:      	ldp	q11, q2, [x5]
    218c:      	fmul.4s	v14, v0, v11
    2190:      	add	x5, x26, x15
    2194:      	ldp	q12, q18, [x5]
    2198:      	add	x15, x27, x15
    219c:      	ldp	q13, q1, [x15]
    21a0:      	fmul.4s	v30, v12, v13
    21a4:      	fsub.4s	v30, v14, v30
    21a8:      	zip1.8b	v14, v25, v0
    21ac:      	ushll.4s	v14, v14, #0x0
    21b0:      	shl.4s	v14, v14, #0x1f
    21b4:      	cmlt.4s	v14, v14, #0
    21b8:      	and.16b	v14, v14, v30
    21bc:      	ldr	d30, [sp, #0x240]
    21c0:      	fmov	w15, s30
    21c4:      	str	q28, [sp, #0x400]
    21c8:      	str	q27, [sp, #0x410]
    21cc:      	str	q3, [sp, #0x420]
    21d0:      	str	q15, [sp, #0x430]
    21d4:      	add	x5, sp, #0x400
    21d8:      	ldr	x4, [x5, x4]
    21dc:      	sub	x4, x4, x19
    21e0:      	add	x4, x1, x4, lsl #2
    21e4:      	tbnz	w15, #0x0, 0x3998 <ltmp0+0x3998>
    21e8:      	ldr	q15, [sp, #0x230]
    21ec:      	tbnz	w15, #0x1, 0x39a4 <ltmp0+0x39a4>
    21f0:      	tbnz	w15, #0x2, 0x39b0 <ltmp0+0x39b0>
    21f4:      	tbz	w15, #0x3, 0x2200 <ltmp0+0x2200>
    21f8:      	add	x5, x4, #0xc
    21fc:      	st1.s	{ v14 }[3], [x5]
    2200:      	fmul.4s	v3, v6, v2
    2204:      	fmul.4s	v27, v18, v1
    2208:      	fsub.4s	v3, v3, v27
    220c:      	zip2.8b	v27, v25, v0
    2210:      	ushll.4s	v27, v27, #0x0
    2214:      	shl.4s	v27, v27, #0x1f
    2218:      	cmlt.4s	v27, v27, #0
    221c:      	and.16b	v14, v27, v3
    2220:      	tbnz	w15, #0x4, 0x39c0 <ltmp0+0x39c0>
    2224:      	tbnz	w15, #0x5, 0x39c8 <ltmp0+0x39c8>
    2228:      	tbnz	w15, #0x6, 0x39d4 <ltmp0+0x39d4>
    222c:      	tbz	w15, #0x7, 0x2238 <ltmp0+0x2238>
    2230:      	add	x15, x4, #0x1c
    2234:      	st1.s	{ v14 }[3], [x15]
    2238:      	sshll.2d	v3, v5, #0x0
    223c:      	ldr	q27, [sp, #0x1f0]
    2240:      	and.16b	v27, v3, v27
    2244:      	fmov	w4, s15
    2248:      	ldr	q3, [sp, #0xc0]
    224c:      	ldp	q28, q14, [sp, #0x90]
    2250:      	fmul.4s	v3, v3, v28
    2254:      	ldr	q28, [sp, #0xb0]
    2258:      	fmul.4s	v28, v28, v14
    225c:      	fadd.4s	v3, v28, v3
    2260:      	and.16b	v3, v5, v3
    2264:      	fmov	x15, d27
    2268:      	add	x15, x1, x15, lsl #2
    226c:      	tbnz	w4, #0x0, 0x39e4 <ltmp0+0x39e4>
    2270:      	and	w4, w4, #0xff
    2274:      	tbnz	w4, #0x1, 0x39f0 <ltmp0+0x39f0>
    2278:      	tbnz	w4, #0x2, 0x39fc <ltmp0+0x39fc>
    227c:      	tbz	w4, #0x3, 0x2288 <ltmp0+0x2288>
    2280:      	add	x5, x15, #0xc
    2284:      	st1.s	{ v3 }[3], [x5]
    2288:      	fmul.4s	v3, v29, v31
    228c:      	ldr	q27, [sp, #0x200]
    2290:      	ldr	q28, [sp, #0x100]
    2294:      	fmul.4s	v27, v27, v28
    2298:      	fadd.4s	v3, v27, v3
    229c:      	and.16b	v3, v21, v3
    22a0:      	tbnz	w4, #0x4, 0x3a0c <ltmp0+0x3a0c>
    22a4:      	mov.16b	v28, v23
    22a8:      	mov.16b	v29, v7
    22ac:      	tbnz	w4, #0x5, 0x3a1c <ltmp0+0x3a1c>
    22b0:      	tbnz	w4, #0x6, 0x3a28 <ltmp0+0x3a28>
    22b4:      	tbz	w4, #0x7, 0x22c0 <ltmp0+0x22c0>
    22b8:      	add	x15, x15, #0x1c
    22bc:      	st1.s	{ v3 }[3], [x15]
    22c0:      	sshll.2d	v3, v5, #0x0
    22c4:      	ldr	q27, [sp, #0x1d0]
    22c8:      	and.16b	v27, v3, v27
    22cc:      	fmov	w4, s15
    22d0:      	ldr	q3, [sp, #0x80]
    22d4:      	ldp	q7, q23, [sp, #0x40]
    22d8:      	fmul.4s	v3, v3, v7
    22dc:      	ldr	q7, [sp, #0x70]
    22e0:      	fmul.4s	v23, v7, v23
    22e4:      	fadd.4s	v3, v23, v3
    22e8:      	and.16b	v3, v5, v3
    22ec:      	fmov	x15, d27
    22f0:      	add	x15, x1, x15, lsl #2
    22f4:      	tbnz	w4, #0x0, 0x3a38 <ltmp0+0x3a38>
    22f8:      	and	w4, w4, #0xff
    22fc:      	mov.16b	v27, v24
    2300:      	tbnz	w4, #0x1, 0x3a48 <ltmp0+0x3a48>
    2304:      	tbnz	w4, #0x2, 0x3a54 <ltmp0+0x3a54>
    2308:      	tbz	w4, #0x3, 0x2314 <ltmp0+0x2314>
    230c:      	add	x5, x15, #0xc
    2310:      	st1.s	{ v3 }[3], [x5]
    2314:      	ldp	q24, q3, [sp, #0xe0]
    2318:      	ldr	q23, [sp, #0xd0]
    231c:      	fmul.4s	v3, v3, v23
    2320:      	ldr	q23, [sp, #0x220]
    2324:      	fmul.4s	v23, v23, v24
    2328:      	fadd.4s	v3, v23, v3
    232c:      	and.16b	v3, v21, v3
    2330:      	tbnz	w4, #0x4, 0x3a64 <ltmp0+0x3a64>
    2334:      	tbnz	w4, #0x5, 0x3a6c <ltmp0+0x3a6c>
    2338:      	tbnz	w4, #0x6, 0x3a78 <ltmp0+0x3a78>
    233c:      	tbz	w4, #0x7, 0x2348 <ltmp0+0x2348>
    2340:      	add	x15, x15, #0x1c
    2344:      	st1.s	{ v3 }[3], [x15]
    2348:      	sshll.2d	v3, v5, #0x0
    234c:      	ldr	q23, [sp, #0x1c0]
    2350:      	and.16b	v23, v3, v23
    2354:      	fmov	w4, s15
    2358:      	ldr	q3, [sp, #0x30]
    235c:      	fmul.4s	v3, v3, v17
    2360:      	fmul.4s	v4, v16, v4
    2364:      	fadd.4s	v3, v4, v3
    2368:      	and.16b	v3, v5, v3
    236c:      	fmov	x15, d23
    2370:      	add	x15, x1, x15, lsl #2
    2374:      	tbnz	w4, #0x0, 0x3a88 <ltmp0+0x3a88>
    2378:      	and	w4, w4, #0xff
    237c:      	tbnz	w4, #0x1, 0x3a94 <ltmp0+0x3a94>
    2380:      	tbnz	w4, #0x2, 0x3aa0 <ltmp0+0x3aa0>
    2384:      	tbnz	w4, #0x3, 0x3aac <ltmp0+0x3aac>
    2388:      	fmul.4s	v3, v9, v28
    238c:      	fmul.4s	v4, v8, v22
    2390:      	fadd.4s	v3, v4, v3
    2394:      	and.16b	v3, v21, v3
    2398:      	tbnz	w4, #0x4, 0x3ac8 <ltmp0+0x3ac8>
    239c:      	tbnz	w4, #0x5, 0x3ad0 <ltmp0+0x3ad0>
    23a0:      	tbnz	w4, #0x6, 0x3adc <ltmp0+0x3adc>
    23a4:      	tbz	w4, #0x7, 0x23b0 <ltmp0+0x23b0>
    23a8:      	add	x15, x15, #0x1c
    23ac:      	st1.s	{ v3 }[3], [x15]
    23b0:      	sshll.2d	v3, v5, #0x0
    23b4:      	ldr	q4, [sp, #0x1b0]
    23b8:      	and.16b	v4, v3, v4
    23bc:      	fmov	w4, s15
    23c0:      	fmul.4s	v3, v19, v10
    23c4:      	fmul.4s	v7, v20, v26
    23c8:      	fadd.4s	v3, v7, v3
    23cc:      	and.16b	v3, v5, v3
    23d0:      	fmov	x15, d4
    23d4:      	add	x15, x1, x15, lsl #2
    23d8:      	tbnz	w4, #0x0, 0x3aec <ltmp0+0x3aec>
    23dc:      	and	w4, w4, #0xff
    23e0:      	tbnz	w4, #0x1, 0x3af8 <ltmp0+0x3af8>
    23e4:      	tbnz	w4, #0x2, 0x3b04 <ltmp0+0x3b04>
    23e8:      	tbz	w4, #0x3, 0x23f4 <ltmp0+0x23f4>
    23ec:      	add	x5, x15, #0xc
    23f0:      	st1.s	{ v3 }[3], [x5]
    23f4:      	ldr	q3, [sp, #0x60]
    23f8:      	fmul.4s	v3, v27, v3
    23fc:      	ldr	q4, [sp, #0x210]
    2400:      	fmul.4s	v4, v4, v29
    2404:      	fadd.4s	v3, v4, v3
    2408:      	and.16b	v3, v21, v3
    240c:      	tbnz	w4, #0x4, 0x3b14 <ltmp0+0x3b14>
    2410:      	tbnz	w4, #0x5, 0x3b1c <ltmp0+0x3b1c>
    2414:      	tbnz	w4, #0x6, 0x3b28 <ltmp0+0x3b28>
    2418:      	tbz	w4, #0x7, 0x2424 <ltmp0+0x2424>
    241c:      	add	x15, x15, #0x1c
    2420:      	st1.s	{ v3 }[3], [x15]
    2424:      	fmul.4s	v0, v0, v13
    2428:      	fmul.4s	v3, v11, v12
    242c:      	fadd.4s	v0, v3, v0
    2430:      	zip1.8b	v3, v25, v0
    2434:      	ushll.4s	v3, v3, #0x0
    2438:      	shl.4s	v3, v3, #0x1f
    243c:      	cmlt.4s	v3, v3, #0
    2440:      	and.16b	v0, v3, v0
    2444:      	fmov	w15, s30
    2448:      	ldp	q4, q3, [sp, #0x170]
    244c:      	stp	q4, q3, [sp, #0x3b0]
    2450:      	ldp	q4, q3, [sp, #0x190]
    2454:      	stp	q4, q3, [sp, #0x3d0]
    2458:      	and	x4, x19, #0x7
    245c:      	add	x5, sp, #0x3b0
    2460:      	ldr	x4, [x5, x4, lsl #3]
    2464:      	sub	x4, x4, x19
    2468:      	add	x1, x1, x4, lsl #2
    246c:      	tbnz	w15, #0x0, 0x3b38 <ltmp0+0x3b38>
    2470:      	tbnz	w15, #0x1, 0x3b40 <ltmp0+0x3b40>
    2474:      	tbnz	w15, #0x2, 0x3b4c <ltmp0+0x3b4c>
    2478:      	tbz	w15, #0x3, 0x2484 <ltmp0+0x2484>
    247c:      	add	x4, x1, #0xc
    2480:      	st1.s	{ v0 }[3], [x4]
    2484:      	fmul.4s	v0, v6, v1
    2488:      	fmul.4s	v1, v2, v18
    248c:      	fadd.4s	v0, v1, v0
    2490:      	zip2.8b	v1, v25, v0
    2494:      	ushll.4s	v1, v1, #0x0
    2498:      	shl.4s	v1, v1, #0x1f
    249c:      	cmlt.4s	v1, v1, #0
    24a0:      	and.16b	v0, v1, v0
    24a4:      	tbnz	w15, #0x4, 0x3b5c <ltmp0+0x3b5c>
    24a8:      	tbnz	w15, #0x5, 0x3b64 <ltmp0+0x3b64>
    24ac:      	tbnz	w15, #0x6, 0x3b70 <ltmp0+0x3b70>
    24b0:      	tbz	w15, #0x7, 0x84 <ltmp0+0x84>
    24b4:      	b	0x3b7c <ltmp0+0x3b7c>
    24b8:      	ldr	s1, [x19]
    24bc:      	and	w15, w15, #0xff
    24c0:      	tbz	w15, #0x1, 0x67c <ltmp0+0x67c>
    24c4:      	add	x22, x19, #0x4
    24c8:      	ld1.s	{ v1 }[1], [x22]
    24cc:      	tbz	w15, #0x2, 0x680 <ltmp0+0x680>
    24d0:      	add	x22, x19, #0x8
    24d4:      	ld1.s	{ v1 }[2], [x22]
    24d8:      	tbz	w15, #0x3, 0x684 <ltmp0+0x684>
    24dc:      	add	x22, x19, #0xc
    24e0:      	ld1.s	{ v1 }[3], [x22]
    24e4:      	tbz	w15, #0x4, 0x688 <ltmp0+0x688>
    24e8:      	add	x22, x19, #0x10
    24ec:      	ld1.s	{ v0 }[0], [x22]
    24f0:      	tbz	w15, #0x5, 0x68c <ltmp0+0x68c>
    24f4:      	add	x22, x19, #0x14
    24f8:      	ld1.s	{ v0 }[1], [x22]
    24fc:      	tbz	w15, #0x6, 0x690 <ltmp0+0x690>
    2500:      	add	x22, x19, #0x18
    2504:      	ld1.s	{ v0 }[2], [x22]
    2508:      	tbnz	w15, #0x7, 0x694 <ltmp0+0x694>
    250c:      	b	0x69c <ltmp0+0x69c>
    2510:      	ldr	s3, [x23]
    2514:      	and	w15, w15, #0xff
    2518:      	tbz	w15, #0x1, 0x6cc <ltmp0+0x6cc>
    251c:      	add	x25, x23, #0x4
    2520:      	ld1.s	{ v3 }[1], [x25]
    2524:      	tbz	w15, #0x2, 0x6d0 <ltmp0+0x6d0>
    2528:      	add	x25, x23, #0x8
    252c:      	ld1.s	{ v3 }[2], [x25]
    2530:      	tbz	w15, #0x3, 0x6d4 <ltmp0+0x6d4>
    2534:      	add	x25, x23, #0xc
    2538:      	ld1.s	{ v3 }[3], [x25]
    253c:      	tbz	w15, #0x4, 0x6d8 <ltmp0+0x6d8>
    2540:      	add	x25, x23, #0x10
    2544:      	ld1.s	{ v2 }[0], [x25]
    2548:      	tbz	w15, #0x5, 0x6dc <ltmp0+0x6dc>
    254c:      	add	x25, x23, #0x14
    2550:      	ld1.s	{ v2 }[1], [x25]
    2554:      	tbz	w15, #0x6, 0x6e0 <ltmp0+0x6e0>
    2558:      	add	x25, x23, #0x18
    255c:      	ld1.s	{ v2 }[2], [x25]
    2560:      	tbnz	w15, #0x7, 0x6e4 <ltmp0+0x6e4>
    2564:      	b	0x6ec <ltmp0+0x6ec>
    2568:      	ldr	s6, [x25]
    256c:      	and	w15, w15, #0xff
    2570:      	tbz	w15, #0x1, 0x71c <ltmp0+0x71c>
    2574:      	add	x30, x25, #0x4
    2578:      	ld1.s	{ v6 }[1], [x30]
    257c:      	tbz	w15, #0x2, 0x720 <ltmp0+0x720>
    2580:      	add	x30, x25, #0x8
    2584:      	ld1.s	{ v6 }[2], [x30]
    2588:      	tbz	w15, #0x3, 0x724 <ltmp0+0x724>
    258c:      	add	x30, x25, #0xc
    2590:      	ld1.s	{ v6 }[3], [x30]
    2594:      	tbz	w15, #0x4, 0x728 <ltmp0+0x728>
    2598:      	add	x30, x25, #0x10
    259c:      	ld1.s	{ v4 }[0], [x30]
    25a0:      	tbz	w15, #0x5, 0x72c <ltmp0+0x72c>
    25a4:      	add	x30, x25, #0x14
    25a8:      	ld1.s	{ v4 }[1], [x30]
    25ac:      	tbz	w15, #0x6, 0x730 <ltmp0+0x730>
    25b0:      	add	x30, x25, #0x18
    25b4:      	ld1.s	{ v4 }[2], [x30]
    25b8:      	tbz	w15, #0x7, 0x734 <ltmp0+0x734>
    25bc:      	add	x15, x25, #0x1c
    25c0:      	ld1.s	{ v4 }[3], [x15]
    25c4:      	fmov	w15, s22
    25c8:      	add	x23, x4, x23
    25cc:      	movi.2d	v16, #0000000000000000
    25d0:      	movi.2d	v7, #0000000000000000
    25d4:      	tbz	w15, #0x0, 0x748 <ltmp0+0x748>
    25d8:      	ldr	s16, [x23]
    25dc:      	and	w15, w15, #0xff
    25e0:      	tbz	w15, #0x1, 0x750 <ltmp0+0x750>
    25e4:      	add	x25, x23, #0x4
    25e8:      	ld1.s	{ v16 }[1], [x25]
    25ec:      	tbz	w15, #0x2, 0x754 <ltmp0+0x754>
    25f0:      	add	x25, x23, #0x8
    25f4:      	ld1.s	{ v16 }[2], [x25]
    25f8:      	tbz	w15, #0x3, 0x758 <ltmp0+0x758>
    25fc:      	add	x25, x23, #0xc
    2600:      	ld1.s	{ v16 }[3], [x25]
    2604:      	tbz	w15, #0x4, 0x75c <ltmp0+0x75c>
    2608:      	add	x25, x23, #0x10
    260c:      	ld1.s	{ v7 }[0], [x25]
    2610:      	tbz	w15, #0x5, 0x760 <ltmp0+0x760>
    2614:      	add	x25, x23, #0x14
    2618:      	ld1.s	{ v7 }[1], [x25]
    261c:      	tbz	w15, #0x6, 0x764 <ltmp0+0x764>
    2620:      	add	x25, x23, #0x18
    2624:      	ld1.s	{ v7 }[2], [x25]
    2628:      	tbz	w15, #0x7, 0x768 <ltmp0+0x768>
    262c:      	add	x15, x23, #0x1c
    2630:      	ld1.s	{ v7 }[3], [x15]
    2634:      	fmov	w23, s22
    2638:      	fmul.4s	v17, v1, v6
    263c:      	fmul.4s	v18, v3, v16
    2640:      	fsub.4s	v17, v17, v18
    2644:      	add	x15, x1, x21
    2648:      	tbz	w23, #0x0, 0x780 <ltmp0+0x780>
    264c:      	str	s17, [x15]
    2650:      	and	w21, w23, #0xff
    2654:      	tbz	w21, #0x1, 0x788 <ltmp0+0x788>
    2658:      	add	x23, x15, #0x4
    265c:      	st1.s	{ v17 }[1], [x23]
    2660:      	tbz	w21, #0x2, 0x78c <ltmp0+0x78c>
    2664:      	add	x23, x15, #0x8
    2668:      	st1.s	{ v17 }[2], [x23]
    266c:      	tbz	w21, #0x3, 0x790 <ltmp0+0x790>
    2670:      	add	x23, x15, #0xc
    2674:      	st1.s	{ v17 }[3], [x23]
    2678:      	fmul.4s	v17, v0, v4
    267c:      	fmul.4s	v18, v2, v7
    2680:      	fsub.4s	v17, v17, v18
    2684:      	tbz	w21, #0x4, 0x7a0 <ltmp0+0x7a0>
    2688:      	str	s17, [x15, #0x10]
    268c:      	tbz	w21, #0x5, 0x7a4 <ltmp0+0x7a4>
    2690:      	add	x23, x15, #0x14
    2694:      	st1.s	{ v17 }[1], [x23]
    2698:      	tbz	w21, #0x6, 0x7a8 <ltmp0+0x7a8>
    269c:      	add	x23, x15, #0x18
    26a0:      	st1.s	{ v17 }[2], [x23]
    26a4:      	tbz	w21, #0x7, 0x7ac <ltmp0+0x7ac>
    26a8:      	add	x15, x15, #0x1c
    26ac:      	st1.s	{ v17 }[3], [x15]
    26b0:      	fmov	w21, s22
    26b4:      	fmul.4s	v1, v1, v16
    26b8:      	fmul.4s	v3, v3, v6
    26bc:      	fadd.4s	v1, v3, v1
    26c0:      	add	x15, x1, x22
    26c4:      	tbz	w21, #0x0, 0x7c4 <ltmp0+0x7c4>
    26c8:      	str	s1, [x15]
    26cc:      	and	w21, w21, #0xff
    26d0:      	tbz	w21, #0x1, 0x7cc <ltmp0+0x7cc>
    26d4:      	add	x22, x15, #0x4
    26d8:      	st1.s	{ v1 }[1], [x22]
    26dc:      	tbz	w21, #0x2, 0x7d0 <ltmp0+0x7d0>
    26e0:      	add	x22, x15, #0x8
    26e4:      	st1.s	{ v1 }[2], [x22]
    26e8:      	tbz	w21, #0x3, 0x7d4 <ltmp0+0x7d4>
    26ec:      	add	x22, x15, #0xc
    26f0:      	st1.s	{ v1 }[3], [x22]
    26f4:      	fmul.4s	v0, v0, v7
    26f8:      	fmul.4s	v1, v2, v4
    26fc:      	fadd.4s	v0, v1, v0
    2700:      	tbz	w21, #0x4, 0x7e4 <ltmp0+0x7e4>
    2704:      	str	s0, [x15, #0x10]
    2708:      	tbz	w21, #0x5, 0x7e8 <ltmp0+0x7e8>
    270c:      	add	x22, x15, #0x14
    2710:      	st1.s	{ v0 }[1], [x22]
    2714:      	tbz	w21, #0x6, 0x7ec <ltmp0+0x7ec>
    2718:      	add	x22, x15, #0x18
    271c:      	st1.s	{ v0 }[2], [x22]
    2720:      	tbnz	w21, #0x7, 0x7f0 <ltmp0+0x7f0>
    2724:      	b	0x7f8 <ltmp0+0x7f8>
    2728:      	ldr	s2, [x22]
    272c:      	and	w15, w15, #0xff
    2730:      	tbz	w15, #0x1, 0x82c <ltmp0+0x82c>
    2734:      	add	x23, x22, #0x4
    2738:      	ld1.s	{ v2 }[1], [x23]
    273c:      	tbz	w15, #0x2, 0x830 <ltmp0+0x830>
    2740:      	add	x23, x22, #0x8
    2744:      	ld1.s	{ v2 }[2], [x23]
    2748:      	tbz	w15, #0x3, 0x834 <ltmp0+0x834>
    274c:      	add	x23, x22, #0xc
    2750:      	ld1.s	{ v2 }[3], [x23]
    2754:      	tbz	w15, #0x4, 0x838 <ltmp0+0x838>
    2758:      	add	x23, x22, #0x10
    275c:      	ld1.s	{ v1 }[0], [x23]
    2760:      	tbz	w15, #0x5, 0x83c <ltmp0+0x83c>
    2764:      	add	x23, x22, #0x14
    2768:      	ld1.s	{ v1 }[1], [x23]
    276c:      	tbz	w15, #0x6, 0x840 <ltmp0+0x840>
    2770:      	add	x23, x22, #0x18
    2774:      	ld1.s	{ v1 }[2], [x23]
    2778:      	tbz	w15, #0x7, 0x844 <ltmp0+0x844>
    277c:      	add	x15, x22, #0x1c
    2780:      	ld1.s	{ v1 }[3], [x15]
    2784:      	fmov	w15, s22
    2788:      	add	x22, x19, #0xa4
    278c:      	add	x23, x7, x22
    2790:      	movi.2d	v4, #0000000000000000
    2794:      	movi.2d	v3, #0000000000000000
    2798:      	tbz	w15, #0x0, 0x85c <ltmp0+0x85c>
    279c:      	ldr	s4, [x23]
    27a0:      	and	w15, w15, #0xff
    27a4:      	tbz	w15, #0x1, 0x864 <ltmp0+0x864>
    27a8:      	add	x25, x23, #0x4
    27ac:      	ld1.s	{ v4 }[1], [x25]
    27b0:      	tbz	w15, #0x2, 0x868 <ltmp0+0x868>
    27b4:      	add	x25, x23, #0x8
    27b8:      	ld1.s	{ v4 }[2], [x25]
    27bc:      	tbz	w15, #0x3, 0x86c <ltmp0+0x86c>
    27c0:      	add	x25, x23, #0xc
    27c4:      	ld1.s	{ v4 }[3], [x25]
    27c8:      	tbz	w15, #0x4, 0x870 <ltmp0+0x870>
    27cc:      	add	x25, x23, #0x10
    27d0:      	ld1.s	{ v3 }[0], [x25]
    27d4:      	tbz	w15, #0x5, 0x874 <ltmp0+0x874>
    27d8:      	add	x25, x23, #0x14
    27dc:      	ld1.s	{ v3 }[1], [x25]
    27e0:      	tbz	w15, #0x6, 0x878 <ltmp0+0x878>
    27e4:      	add	x25, x23, #0x18
    27e8:      	ld1.s	{ v3 }[2], [x25]
    27ec:      	tbnz	w15, #0x7, 0x87c <ltmp0+0x87c>
    27f0:      	b	0x884 <ltmp0+0x884>
    27f4:      	ldr	s7, [x25]
    27f8:      	and	w15, w15, #0xff
    27fc:      	tbz	w15, #0x1, 0x8b4 <ltmp0+0x8b4>
    2800:      	add	x30, x25, #0x4
    2804:      	ld1.s	{ v7 }[1], [x30]
    2808:      	tbz	w15, #0x2, 0x8b8 <ltmp0+0x8b8>
    280c:      	add	x30, x25, #0x8
    2810:      	ld1.s	{ v7 }[2], [x30]
    2814:      	tbz	w15, #0x3, 0x8bc <ltmp0+0x8bc>
    2818:      	add	x30, x25, #0xc
    281c:      	ld1.s	{ v7 }[3], [x30]
    2820:      	tbz	w15, #0x4, 0x8c0 <ltmp0+0x8c0>
    2824:      	add	x30, x25, #0x10
    2828:      	ld1.s	{ v6 }[0], [x30]
    282c:      	tbz	w15, #0x5, 0x8c4 <ltmp0+0x8c4>
    2830:      	add	x30, x25, #0x14
    2834:      	ld1.s	{ v6 }[1], [x30]
    2838:      	tbz	w15, #0x6, 0x8c8 <ltmp0+0x8c8>
    283c:      	add	x30, x25, #0x18
    2840:      	ld1.s	{ v6 }[2], [x30]
    2844:      	tbz	w15, #0x7, 0x8cc <ltmp0+0x8cc>
    2848:      	add	x15, x25, #0x1c
    284c:      	ld1.s	{ v6 }[3], [x15]
    2850:      	fmov	w15, s22
    2854:      	add	x23, x4, x23
    2858:      	movi.2d	v17, #0000000000000000
    285c:      	movi.2d	v16, #0000000000000000
    2860:      	tbz	w15, #0x0, 0x8e0 <ltmp0+0x8e0>
    2864:      	ldr	s17, [x23]
    2868:      	and	w15, w15, #0xff
    286c:      	tbz	w15, #0x1, 0x8e8 <ltmp0+0x8e8>
    2870:      	add	x25, x23, #0x4
    2874:      	ld1.s	{ v17 }[1], [x25]
    2878:      	tbz	w15, #0x2, 0x8ec <ltmp0+0x8ec>
    287c:      	add	x25, x23, #0x8
    2880:      	ld1.s	{ v17 }[2], [x25]
    2884:      	tbz	w15, #0x3, 0x8f0 <ltmp0+0x8f0>
    2888:      	add	x25, x23, #0xc
    288c:      	ld1.s	{ v17 }[3], [x25]
    2890:      	tbz	w15, #0x4, 0x8f4 <ltmp0+0x8f4>
    2894:      	add	x25, x23, #0x10
    2898:      	ld1.s	{ v16 }[0], [x25]
    289c:      	tbz	w15, #0x5, 0x8f8 <ltmp0+0x8f8>
    28a0:      	add	x25, x23, #0x14
    28a4:      	ld1.s	{ v16 }[1], [x25]
    28a8:      	tbz	w15, #0x6, 0x8fc <ltmp0+0x8fc>
    28ac:      	add	x25, x23, #0x18
    28b0:      	ld1.s	{ v16 }[2], [x25]
    28b4:      	tbz	w15, #0x7, 0x900 <ltmp0+0x900>
    28b8:      	add	x15, x23, #0x1c
    28bc:      	ld1.s	{ v16 }[3], [x15]
    28c0:      	fmov	w23, s22
    28c4:      	fmul.4s	v18, v2, v7
    28c8:      	fmul.4s	v19, v4, v17
    28cc:      	fsub.4s	v18, v18, v19
    28d0:      	add	x15, x1, x21
    28d4:      	tbz	w23, #0x0, 0x918 <ltmp0+0x918>
    28d8:      	str	s18, [x15]
    28dc:      	and	w21, w23, #0xff
    28e0:      	tbz	w21, #0x1, 0x920 <ltmp0+0x920>
    28e4:      	add	x23, x15, #0x4
    28e8:      	st1.s	{ v18 }[1], [x23]
    28ec:      	tbz	w21, #0x2, 0x924 <ltmp0+0x924>
    28f0:      	add	x23, x15, #0x8
    28f4:      	st1.s	{ v18 }[2], [x23]
    28f8:      	tbz	w21, #0x3, 0x928 <ltmp0+0x928>
    28fc:      	add	x23, x15, #0xc
    2900:      	st1.s	{ v18 }[3], [x23]
    2904:      	fmul.4s	v18, v1, v6
    2908:      	fmul.4s	v19, v3, v16
    290c:      	fsub.4s	v18, v18, v19
    2910:      	tbz	w21, #0x4, 0x938 <ltmp0+0x938>
    2914:      	str	s18, [x15, #0x10]
    2918:      	tbz	w21, #0x5, 0x93c <ltmp0+0x93c>
    291c:      	add	x23, x15, #0x14
    2920:      	st1.s	{ v18 }[1], [x23]
    2924:      	tbz	w21, #0x6, 0x940 <ltmp0+0x940>
    2928:      	add	x23, x15, #0x18
    292c:      	st1.s	{ v18 }[2], [x23]
    2930:      	tbz	w21, #0x7, 0x944 <ltmp0+0x944>
    2934:      	add	x15, x15, #0x1c
    2938:      	st1.s	{ v18 }[3], [x15]
    293c:      	fmov	w21, s22
    2940:      	fmul.4s	v2, v2, v17
    2944:      	fmul.4s	v4, v4, v7
    2948:      	fadd.4s	v2, v4, v2
    294c:      	add	x15, x1, x22
    2950:      	tbz	w21, #0x0, 0x95c <ltmp0+0x95c>
    2954:      	str	s2, [x15]
    2958:      	and	w21, w21, #0xff
    295c:      	tbz	w21, #0x1, 0x964 <ltmp0+0x964>
    2960:      	add	x22, x15, #0x4
    2964:      	st1.s	{ v2 }[1], [x22]
    2968:      	tbz	w21, #0x2, 0x968 <ltmp0+0x968>
    296c:      	add	x22, x15, #0x8
    2970:      	st1.s	{ v2 }[2], [x22]
    2974:      	tbz	w21, #0x3, 0x96c <ltmp0+0x96c>
    2978:      	add	x22, x15, #0xc
    297c:      	st1.s	{ v2 }[3], [x22]
    2980:      	fmul.4s	v1, v1, v16
    2984:      	fmul.4s	v2, v3, v6
    2988:      	fadd.4s	v1, v2, v1
    298c:      	tbz	w21, #0x4, 0x97c <ltmp0+0x97c>
    2990:      	str	s1, [x15, #0x10]
    2994:      	tbz	w21, #0x5, 0x980 <ltmp0+0x980>
    2998:      	add	x22, x15, #0x14
    299c:      	st1.s	{ v1 }[1], [x22]
    29a0:      	tbz	w21, #0x6, 0x984 <ltmp0+0x984>
    29a4:      	add	x22, x15, #0x18
    29a8:      	st1.s	{ v1 }[2], [x22]
    29ac:      	tbnz	w21, #0x7, 0x988 <ltmp0+0x988>
    29b0:      	b	0x990 <ltmp0+0x990>
    29b4:      	ldr	s2, [x22]
    29b8:      	and	w15, w15, #0xff
    29bc:      	tbz	w15, #0x1, 0x9c4 <ltmp0+0x9c4>
    29c0:      	add	x23, x22, #0x4
    29c4:      	ld1.s	{ v2 }[1], [x23]
    29c8:      	tbz	w15, #0x2, 0x9c8 <ltmp0+0x9c8>
    29cc:      	add	x23, x22, #0x8
    29d0:      	ld1.s	{ v2 }[2], [x23]
    29d4:      	tbz	w15, #0x3, 0x9cc <ltmp0+0x9cc>
    29d8:      	add	x23, x22, #0xc
    29dc:      	ld1.s	{ v2 }[3], [x23]
    29e0:      	tbz	w15, #0x4, 0x9d0 <ltmp0+0x9d0>
    29e4:      	add	x23, x22, #0x10
    29e8:      	ld1.s	{ v1 }[0], [x23]
    29ec:      	tbz	w15, #0x5, 0x9d4 <ltmp0+0x9d4>
    29f0:      	add	x23, x22, #0x14
    29f4:      	ld1.s	{ v1 }[1], [x23]
    29f8:      	tbz	w15, #0x6, 0x9d8 <ltmp0+0x9d8>
    29fc:      	add	x23, x22, #0x18
    2a00:      	ld1.s	{ v1 }[2], [x23]
    2a04:      	tbz	w15, #0x7, 0x9dc <ltmp0+0x9dc>
    2a08:      	add	x15, x22, #0x1c
    2a0c:      	ld1.s	{ v1 }[3], [x15]
    2a10:      	fmov	w15, s22
    2a14:      	add	x22, x19, #0xc4
    2a18:      	add	x23, x7, x22
    2a1c:      	movi.2d	v4, #0000000000000000
    2a20:      	movi.2d	v3, #0000000000000000
    2a24:      	tbz	w15, #0x0, 0x9f4 <ltmp0+0x9f4>
    2a28:      	ldr	s4, [x23]
    2a2c:      	and	w15, w15, #0xff
    2a30:      	tbz	w15, #0x1, 0x9fc <ltmp0+0x9fc>
    2a34:      	add	x25, x23, #0x4
    2a38:      	ld1.s	{ v4 }[1], [x25]
    2a3c:      	tbz	w15, #0x2, 0xa00 <ltmp0+0xa00>
    2a40:      	add	x25, x23, #0x8
    2a44:      	ld1.s	{ v4 }[2], [x25]
    2a48:      	tbz	w15, #0x3, 0xa04 <ltmp0+0xa04>
    2a4c:      	add	x25, x23, #0xc
    2a50:      	ld1.s	{ v4 }[3], [x25]
    2a54:      	tbz	w15, #0x4, 0xa08 <ltmp0+0xa08>
    2a58:      	add	x25, x23, #0x10
    2a5c:      	ld1.s	{ v3 }[0], [x25]
    2a60:      	tbz	w15, #0x5, 0xa0c <ltmp0+0xa0c>
    2a64:      	add	x25, x23, #0x14
    2a68:      	ld1.s	{ v3 }[1], [x25]
    2a6c:      	tbz	w15, #0x6, 0xa10 <ltmp0+0xa10>
    2a70:      	add	x25, x23, #0x18
    2a74:      	ld1.s	{ v3 }[2], [x25]
    2a78:      	tbnz	w15, #0x7, 0xa14 <ltmp0+0xa14>
    2a7c:      	b	0xa1c <ltmp0+0xa1c>
    2a80:      	ldr	s7, [x25]
    2a84:      	and	w15, w15, #0xff
    2a88:      	tbz	w15, #0x1, 0xa44 <ltmp0+0xa44>
    2a8c:      	add	x30, x25, #0x4
    2a90:      	ld1.s	{ v7 }[1], [x30]
    2a94:      	tbz	w15, #0x2, 0xa48 <ltmp0+0xa48>
    2a98:      	add	x30, x25, #0x8
    2a9c:      	ld1.s	{ v7 }[2], [x30]
    2aa0:      	tbz	w15, #0x3, 0xa4c <ltmp0+0xa4c>
    2aa4:      	add	x30, x25, #0xc
    2aa8:      	ld1.s	{ v7 }[3], [x30]
    2aac:      	tbz	w15, #0x4, 0xa50 <ltmp0+0xa50>
    2ab0:      	add	x30, x25, #0x10
    2ab4:      	ld1.s	{ v6 }[0], [x30]
    2ab8:      	tbz	w15, #0x5, 0xa54 <ltmp0+0xa54>
    2abc:      	add	x30, x25, #0x14
    2ac0:      	ld1.s	{ v6 }[1], [x30]
    2ac4:      	tbz	w15, #0x6, 0xa58 <ltmp0+0xa58>
    2ac8:      	add	x30, x25, #0x18
    2acc:      	ld1.s	{ v6 }[2], [x30]
    2ad0:      	tbz	w15, #0x7, 0xa5c <ltmp0+0xa5c>
    2ad4:      	add	x15, x25, #0x1c
    2ad8:      	ld1.s	{ v6 }[3], [x15]
    2adc:      	fmov	w15, s22
    2ae0:      	add	x23, x4, x23
    2ae4:      	movi.2d	v17, #0000000000000000
    2ae8:      	movi.2d	v16, #0000000000000000
    2aec:      	tbz	w15, #0x0, 0xa70 <ltmp0+0xa70>
    2af0:      	ldr	s17, [x23]
    2af4:      	and	w15, w15, #0xff
    2af8:      	tbz	w15, #0x1, 0xa78 <ltmp0+0xa78>
    2afc:      	add	x25, x23, #0x4
    2b00:      	ld1.s	{ v17 }[1], [x25]
    2b04:      	tbz	w15, #0x2, 0xa7c <ltmp0+0xa7c>
    2b08:      	add	x25, x23, #0x8
    2b0c:      	ld1.s	{ v17 }[2], [x25]
    2b10:      	tbz	w15, #0x3, 0xa80 <ltmp0+0xa80>
    2b14:      	add	x25, x23, #0xc
    2b18:      	ld1.s	{ v17 }[3], [x25]
    2b1c:      	tbz	w15, #0x4, 0xa84 <ltmp0+0xa84>
    2b20:      	add	x25, x23, #0x10
    2b24:      	ld1.s	{ v16 }[0], [x25]
    2b28:      	tbz	w15, #0x5, 0xa88 <ltmp0+0xa88>
    2b2c:      	add	x25, x23, #0x14
    2b30:      	ld1.s	{ v16 }[1], [x25]
    2b34:      	tbz	w15, #0x6, 0xa8c <ltmp0+0xa8c>
    2b38:      	add	x25, x23, #0x18
    2b3c:      	ld1.s	{ v16 }[2], [x25]
    2b40:      	tbz	w15, #0x7, 0xa90 <ltmp0+0xa90>
    2b44:      	add	x15, x23, #0x1c
    2b48:      	ld1.s	{ v16 }[3], [x15]
    2b4c:      	fmov	w23, s22
    2b50:      	fmul.4s	v18, v2, v7
    2b54:      	fmul.4s	v19, v4, v17
    2b58:      	fsub.4s	v18, v18, v19
    2b5c:      	add	x15, x1, x21
    2b60:      	tbz	w23, #0x0, 0xaa8 <ltmp0+0xaa8>
    2b64:      	str	s18, [x15]
    2b68:      	and	w21, w23, #0xff
    2b6c:      	tbz	w21, #0x1, 0xab0 <ltmp0+0xab0>
    2b70:      	add	x23, x15, #0x4
    2b74:      	st1.s	{ v18 }[1], [x23]
    2b78:      	tbz	w21, #0x2, 0xab4 <ltmp0+0xab4>
    2b7c:      	add	x23, x15, #0x8
    2b80:      	st1.s	{ v18 }[2], [x23]
    2b84:      	tbz	w21, #0x3, 0xab8 <ltmp0+0xab8>
    2b88:      	add	x23, x15, #0xc
    2b8c:      	st1.s	{ v18 }[3], [x23]
    2b90:      	fmul.4s	v18, v1, v6
    2b94:      	fmul.4s	v19, v3, v16
    2b98:      	fsub.4s	v18, v18, v19
    2b9c:      	tbz	w21, #0x4, 0xac8 <ltmp0+0xac8>
    2ba0:      	str	s18, [x15, #0x10]
    2ba4:      	tbz	w21, #0x5, 0xacc <ltmp0+0xacc>
    2ba8:      	add	x23, x15, #0x14
    2bac:      	st1.s	{ v18 }[1], [x23]
    2bb0:      	tbz	w21, #0x6, 0xad0 <ltmp0+0xad0>
    2bb4:      	add	x23, x15, #0x18
    2bb8:      	st1.s	{ v18 }[2], [x23]
    2bbc:      	tbz	w21, #0x7, 0xad4 <ltmp0+0xad4>
    2bc0:      	add	x15, x15, #0x1c
    2bc4:      	st1.s	{ v18 }[3], [x15]
    2bc8:      	fmov	w21, s22
    2bcc:      	fmul.4s	v2, v2, v17
    2bd0:      	fmul.4s	v4, v4, v7
    2bd4:      	fadd.4s	v2, v4, v2
    2bd8:      	add	x15, x1, x22
    2bdc:      	tbz	w21, #0x0, 0xaec <ltmp0+0xaec>
    2be0:      	str	s2, [x15]
    2be4:      	and	w21, w21, #0xff
    2be8:      	tbz	w21, #0x1, 0xaf4 <ltmp0+0xaf4>
    2bec:      	add	x22, x15, #0x4
    2bf0:      	st1.s	{ v2 }[1], [x22]
    2bf4:      	tbz	w21, #0x2, 0xaf8 <ltmp0+0xaf8>
    2bf8:      	add	x22, x15, #0x8
    2bfc:      	st1.s	{ v2 }[2], [x22]
    2c00:      	tbz	w21, #0x3, 0xafc <ltmp0+0xafc>
    2c04:      	add	x22, x15, #0xc
    2c08:      	st1.s	{ v2 }[3], [x22]
    2c0c:      	fmul.4s	v1, v1, v16
    2c10:      	fmul.4s	v2, v3, v6
    2c14:      	fadd.4s	v1, v2, v1
    2c18:      	tbz	w21, #0x4, 0xb0c <ltmp0+0xb0c>
    2c1c:      	str	s1, [x15, #0x10]
    2c20:      	tbz	w21, #0x5, 0xb10 <ltmp0+0xb10>
    2c24:      	add	x22, x15, #0x14
    2c28:      	st1.s	{ v1 }[1], [x22]
    2c2c:      	tbz	w21, #0x6, 0xb14 <ltmp0+0xb14>
    2c30:      	add	x22, x15, #0x18
    2c34:      	st1.s	{ v1 }[2], [x22]
    2c38:      	tbnz	w21, #0x7, 0xb18 <ltmp0+0xb18>
    2c3c:      	b	0xb20 <ltmp0+0xb20>
    2c40:      	ldr	s2, [x22]
    2c44:      	and	w15, w15, #0xff
    2c48:      	tbz	w15, #0x1, 0xb50 <ltmp0+0xb50>
    2c4c:      	add	x23, x22, #0x4
    2c50:      	ld1.s	{ v2 }[1], [x23]
    2c54:      	tbz	w15, #0x2, 0xb54 <ltmp0+0xb54>
    2c58:      	add	x23, x22, #0x8
    2c5c:      	ld1.s	{ v2 }[2], [x23]
    2c60:      	tbz	w15, #0x3, 0xb58 <ltmp0+0xb58>
    2c64:      	add	x23, x22, #0xc
    2c68:      	ld1.s	{ v2 }[3], [x23]
    2c6c:      	tbz	w15, #0x4, 0xb5c <ltmp0+0xb5c>
    2c70:      	add	x23, x22, #0x10
    2c74:      	ld1.s	{ v1 }[0], [x23]
    2c78:      	tbz	w15, #0x5, 0xb60 <ltmp0+0xb60>
    2c7c:      	add	x23, x22, #0x14
    2c80:      	ld1.s	{ v1 }[1], [x23]
    2c84:      	tbz	w15, #0x6, 0xb64 <ltmp0+0xb64>
    2c88:      	add	x23, x22, #0x18
    2c8c:      	ld1.s	{ v1 }[2], [x23]
    2c90:      	tbz	w15, #0x7, 0xb68 <ltmp0+0xb68>
    2c94:      	add	x15, x22, #0x1c
    2c98:      	ld1.s	{ v1 }[3], [x15]
    2c9c:      	fmov	w15, s22
    2ca0:      	add	x19, x19, #0xe4
    2ca4:      	add	x22, x7, x19
    2ca8:      	movi.2d	v4, #0000000000000000
    2cac:      	movi.2d	v3, #0000000000000000
    2cb0:      	tbz	w15, #0x0, 0xb80 <ltmp0+0xb80>
    2cb4:      	ldr	s4, [x22]
    2cb8:      	and	w15, w15, #0xff
    2cbc:      	tbz	w15, #0x1, 0xb88 <ltmp0+0xb88>
    2cc0:      	add	x23, x22, #0x4
    2cc4:      	ld1.s	{ v4 }[1], [x23]
    2cc8:      	tbz	w15, #0x2, 0xb8c <ltmp0+0xb8c>
    2ccc:      	add	x23, x22, #0x8
    2cd0:      	ld1.s	{ v4 }[2], [x23]
    2cd4:      	tbz	w15, #0x3, 0xb90 <ltmp0+0xb90>
    2cd8:      	add	x23, x22, #0xc
    2cdc:      	ld1.s	{ v4 }[3], [x23]
    2ce0:      	tbz	w15, #0x4, 0xb94 <ltmp0+0xb94>
    2ce4:      	add	x23, x22, #0x10
    2ce8:      	ld1.s	{ v3 }[0], [x23]
    2cec:      	tbz	w15, #0x5, 0xb98 <ltmp0+0xb98>
    2cf0:      	add	x23, x22, #0x14
    2cf4:      	ld1.s	{ v3 }[1], [x23]
    2cf8:      	tbz	w15, #0x6, 0xb9c <ltmp0+0xb9c>
    2cfc:      	add	x23, x22, #0x18
    2d00:      	ld1.s	{ v3 }[2], [x23]
    2d04:      	tbnz	w15, #0x7, 0xba0 <ltmp0+0xba0>
    2d08:      	b	0xba8 <ltmp0+0xba8>
    2d0c:      	ldr	s7, [x23]
    2d10:      	and	w15, w15, #0xff
    2d14:      	tbz	w15, #0x1, 0xbd0 <ltmp0+0xbd0>
    2d18:      	add	x25, x23, #0x4
    2d1c:      	ld1.s	{ v7 }[1], [x25]
    2d20:      	tbz	w15, #0x2, 0xbd4 <ltmp0+0xbd4>
    2d24:      	add	x25, x23, #0x8
    2d28:      	ld1.s	{ v7 }[2], [x25]
    2d2c:      	tbz	w15, #0x3, 0xbd8 <ltmp0+0xbd8>
    2d30:      	add	x25, x23, #0xc
    2d34:      	ld1.s	{ v7 }[3], [x25]
    2d38:      	tbz	w15, #0x4, 0xbdc <ltmp0+0xbdc>
    2d3c:      	add	x25, x23, #0x10
    2d40:      	ld1.s	{ v6 }[0], [x25]
    2d44:      	tbz	w15, #0x5, 0xbe0 <ltmp0+0xbe0>
    2d48:      	add	x25, x23, #0x14
    2d4c:      	ld1.s	{ v6 }[1], [x25]
    2d50:      	tbz	w15, #0x6, 0xbe4 <ltmp0+0xbe4>
    2d54:      	add	x25, x23, #0x18
    2d58:      	ld1.s	{ v6 }[2], [x25]
    2d5c:      	tbz	w15, #0x7, 0xbe8 <ltmp0+0xbe8>
    2d60:      	add	x15, x23, #0x1c
    2d64:      	ld1.s	{ v6 }[3], [x15]
    2d68:      	fmov	w15, s22
    2d6c:      	add	x22, x4, x22
    2d70:      	movi.2d	v17, #0000000000000000
    2d74:      	movi.2d	v16, #0000000000000000
    2d78:      	tbz	w15, #0x0, 0xbfc <ltmp0+0xbfc>
    2d7c:      	ldr	s17, [x22]
    2d80:      	and	w15, w15, #0xff
    2d84:      	tbz	w15, #0x1, 0xc04 <ltmp0+0xc04>
    2d88:      	add	x23, x22, #0x4
    2d8c:      	ld1.s	{ v17 }[1], [x23]
    2d90:      	tbz	w15, #0x2, 0xc08 <ltmp0+0xc08>
    2d94:      	add	x23, x22, #0x8
    2d98:      	ld1.s	{ v17 }[2], [x23]
    2d9c:      	tbz	w15, #0x3, 0xc0c <ltmp0+0xc0c>
    2da0:      	add	x23, x22, #0xc
    2da4:      	ld1.s	{ v17 }[3], [x23]
    2da8:      	tbz	w15, #0x4, 0xc10 <ltmp0+0xc10>
    2dac:      	add	x23, x22, #0x10
    2db0:      	ld1.s	{ v16 }[0], [x23]
    2db4:      	tbz	w15, #0x5, 0xc14 <ltmp0+0xc14>
    2db8:      	add	x23, x22, #0x14
    2dbc:      	ld1.s	{ v16 }[1], [x23]
    2dc0:      	tbz	w15, #0x6, 0xc18 <ltmp0+0xc18>
    2dc4:      	add	x23, x22, #0x18
    2dc8:      	ld1.s	{ v16 }[2], [x23]
    2dcc:      	tbz	w15, #0x7, 0xc1c <ltmp0+0xc1c>
    2dd0:      	add	x15, x22, #0x1c
    2dd4:      	ld1.s	{ v16 }[3], [x15]
    2dd8:      	fmov	w22, s22
    2ddc:      	fmul.4s	v18, v2, v7
    2de0:      	fmul.4s	v19, v4, v17
    2de4:      	fsub.4s	v18, v18, v19
    2de8:      	add	x15, x1, x21
    2dec:      	tbz	w22, #0x0, 0xc34 <ltmp0+0xc34>
    2df0:      	str	s18, [x15]
    2df4:      	and	w21, w22, #0xff
    2df8:      	tbz	w21, #0x1, 0xc3c <ltmp0+0xc3c>
    2dfc:      	add	x22, x15, #0x4
    2e00:      	st1.s	{ v18 }[1], [x22]
    2e04:      	tbz	w21, #0x2, 0xc40 <ltmp0+0xc40>
    2e08:      	add	x22, x15, #0x8
    2e0c:      	st1.s	{ v18 }[2], [x22]
    2e10:      	tbz	w21, #0x3, 0xc44 <ltmp0+0xc44>
    2e14:      	add	x22, x15, #0xc
    2e18:      	st1.s	{ v18 }[3], [x22]
    2e1c:      	fmul.4s	v18, v1, v6
    2e20:      	fmul.4s	v19, v3, v16
    2e24:      	fsub.4s	v18, v18, v19
    2e28:      	tbz	w21, #0x4, 0xc54 <ltmp0+0xc54>
    2e2c:      	str	s18, [x15, #0x10]
    2e30:      	tbz	w21, #0x5, 0xc58 <ltmp0+0xc58>
    2e34:      	add	x22, x15, #0x14
    2e38:      	st1.s	{ v18 }[1], [x22]
    2e3c:      	tbz	w21, #0x6, 0xc5c <ltmp0+0xc5c>
    2e40:      	add	x22, x15, #0x18
    2e44:      	st1.s	{ v18 }[2], [x22]
    2e48:      	tbz	w21, #0x7, 0xc60 <ltmp0+0xc60>
    2e4c:      	add	x15, x15, #0x1c
    2e50:      	st1.s	{ v18 }[3], [x15]
    2e54:      	fmov	w21, s22
    2e58:      	fmul.4s	v2, v2, v17
    2e5c:      	fmul.4s	v4, v4, v7
    2e60:      	fadd.4s	v2, v4, v2
    2e64:      	add	x15, x1, x19
    2e68:      	tbz	w21, #0x0, 0xc78 <ltmp0+0xc78>
    2e6c:      	str	s2, [x15]
    2e70:      	and	w19, w21, #0xff
    2e74:      	tbz	w19, #0x1, 0xc80 <ltmp0+0xc80>
    2e78:      	add	x21, x15, #0x4
    2e7c:      	st1.s	{ v2 }[1], [x21]
    2e80:      	tbz	w19, #0x2, 0xc84 <ltmp0+0xc84>
    2e84:      	add	x21, x15, #0x8
    2e88:      	st1.s	{ v2 }[2], [x21]
    2e8c:      	tbz	w19, #0x3, 0xc88 <ltmp0+0xc88>
    2e90:      	add	x21, x15, #0xc
    2e94:      	st1.s	{ v2 }[3], [x21]
    2e98:      	fmul.4s	v1, v1, v16
    2e9c:      	fmul.4s	v2, v3, v6
    2ea0:      	fadd.4s	v1, v2, v1
    2ea4:      	tbz	w19, #0x4, 0xc98 <ltmp0+0xc98>
    2ea8:      	str	s1, [x15, #0x10]
    2eac:      	tbz	w19, #0x5, 0xc9c <ltmp0+0xc9c>
    2eb0:      	add	x21, x15, #0x14
    2eb4:      	st1.s	{ v1 }[1], [x21]
    2eb8:      	tbz	w19, #0x6, 0xca0 <ltmp0+0xca0>
    2ebc:      	add	x21, x15, #0x18
    2ec0:      	st1.s	{ v1 }[2], [x21]
    2ec4:      	tbnz	w19, #0x7, 0xca4 <ltmp0+0xca4>
    2ec8:      	b	0xcac <ltmp0+0xcac>
    2ecc:      	ldr	s2, [x22]
    2ed0:      	tbz	w21, #0x1, 0xd38 <ltmp0+0xd38>
    2ed4:      	add	x15, x22, #0x4
    2ed8:      	ld1.s	{ v2 }[1], [x15]
    2edc:      	tbz	w21, #0x2, 0xd3c <ltmp0+0xd3c>
    2ee0:      	add	x15, x22, #0x8
    2ee4:      	ld1.s	{ v2 }[2], [x15]
    2ee8:      	tbz	w21, #0x3, 0xd40 <ltmp0+0xd40>
    2eec:      	add	x15, x22, #0xc
    2ef0:      	ld1.s	{ v2 }[3], [x15]
    2ef4:      	tbz	w21, #0x4, 0xd44 <ltmp0+0xd44>
    2ef8:      	add	x15, x22, #0x10
    2efc:      	ld1.s	{ v1 }[0], [x15]
    2f00:      	tbz	w21, #0x5, 0xd48 <ltmp0+0xd48>
    2f04:      	add	x15, x22, #0x14
    2f08:      	ld1.s	{ v1 }[1], [x15]
    2f0c:      	tbz	w21, #0x6, 0xd4c <ltmp0+0xd4c>
    2f10:      	add	x15, x22, #0x18
    2f14:      	ld1.s	{ v1 }[2], [x15]
    2f18:      	tbnz	w21, #0x7, 0xd50 <ltmp0+0xd50>
    2f1c:      	b	0xd58 <ltmp0+0xd58>
    2f20:      	ldr	s20, [x7]
    2f24:      	tbz	w21, #0x1, 0xe30 <ltmp0+0xe30>
    2f28:      	add	x15, x7, #0x4
    2f2c:      	ld1.s	{ v20 }[1], [x15]
    2f30:      	tbz	w21, #0x2, 0xe34 <ltmp0+0xe34>
    2f34:      	add	x15, x7, #0x8
    2f38:      	ld1.s	{ v20 }[2], [x15]
    2f3c:      	tbz	w21, #0x3, 0xe38 <ltmp0+0xe38>
    2f40:      	add	x15, x7, #0xc
    2f44:      	ld1.s	{ v20 }[3], [x15]
    2f48:      	tbz	w21, #0x4, 0xe3c <ltmp0+0xe3c>
    2f4c:      	add	x15, x7, #0x10
    2f50:      	ld1.s	{ v16 }[0], [x15]
    2f54:      	tbz	w21, #0x5, 0xe40 <ltmp0+0xe40>
    2f58:      	add	x15, x7, #0x14
    2f5c:      	ld1.s	{ v16 }[1], [x15]
    2f60:      	tbz	w21, #0x6, 0xe44 <ltmp0+0xe44>
    2f64:      	add	x15, x7, #0x18
    2f68:      	ld1.s	{ v16 }[2], [x15]
    2f6c:      	tbnz	w21, #0x7, 0xe48 <ltmp0+0xe48>
    2f70:      	b	0xe50 <ltmp0+0xe50>
    2f74:      	ldr	s23, [x5]
    2f78:      	tbz	w21, #0x1, 0xf10 <ltmp0+0xf10>
    2f7c:      	add	x15, x5, #0x4
    2f80:      	ld1.s	{ v23 }[1], [x15]
    2f84:      	tbz	w21, #0x2, 0xf14 <ltmp0+0xf14>
    2f88:      	add	x15, x5, #0x8
    2f8c:      	ld1.s	{ v23 }[2], [x15]
    2f90:      	tbz	w21, #0x3, 0xf18 <ltmp0+0xf18>
    2f94:      	add	x15, x5, #0xc
    2f98:      	ld1.s	{ v23 }[3], [x15]
    2f9c:      	tbz	w21, #0x4, 0xf1c <ltmp0+0xf1c>
    2fa0:      	add	x15, x5, #0x10
    2fa4:      	ld1.s	{ v0 }[0], [x15]
    2fa8:      	tbz	w21, #0x5, 0xf20 <ltmp0+0xf20>
    2fac:      	add	x15, x5, #0x14
    2fb0:      	ld1.s	{ v0 }[1], [x15]
    2fb4:      	tbz	w21, #0x6, 0xf24 <ltmp0+0xf24>
    2fb8:      	add	x15, x5, #0x18
    2fbc:      	ld1.s	{ v0 }[2], [x15]
    2fc0:      	tbz	w21, #0x7, 0xf28 <ltmp0+0xf28>
    2fc4:      	add	x15, x5, #0x1c
    2fc8:      	ld1.s	{ v0 }[3], [x15]
    2fcc:      	add	x4, x4, x7
    2fd0:      	fmov	w5, s17
    2fd4:      	movi.2d	v27, #0000000000000000
    2fd8:      	movi.2d	v24, #0000000000000000
    2fdc:      	tbz	w5, #0x0, 0xf3c <ltmp0+0xf3c>
    2fe0:      	ldr	s27, [x4]
    2fe4:      	tbz	w5, #0x1, 0xf40 <ltmp0+0xf40>
    2fe8:      	add	x15, x4, #0x4
    2fec:      	ld1.s	{ v27 }[1], [x15]
    2ff0:      	tbz	w5, #0x2, 0xf44 <ltmp0+0xf44>
    2ff4:      	add	x15, x4, #0x8
    2ff8:      	ld1.s	{ v27 }[2], [x15]
    2ffc:      	tbz	w5, #0x3, 0xf48 <ltmp0+0xf48>
    3000:      	add	x15, x4, #0xc
    3004:      	ld1.s	{ v27 }[3], [x15]
    3008:      	tbz	w5, #0x4, 0xf4c <ltmp0+0xf4c>
    300c:      	add	x15, x4, #0x10
    3010:      	ld1.s	{ v24 }[0], [x15]
    3014:      	tbz	w5, #0x5, 0xf50 <ltmp0+0xf50>
    3018:      	add	x15, x4, #0x14
    301c:      	ld1.s	{ v24 }[1], [x15]
    3020:      	tbz	w5, #0x6, 0xf54 <ltmp0+0xf54>
    3024:      	add	x15, x4, #0x18
    3028:      	ld1.s	{ v24 }[2], [x15]
    302c:      	tbnz	w5, #0x7, 0xf58 <ltmp0+0xf58>
    3030:      	b	0xf60 <ltmp0+0xf60>
    3034:      	str	s18, [x15]
    3038:      	tbz	w4, #0x1, 0xfa0 <ltmp0+0xfa0>
    303c:      	add	x5, x15, #0x4
    3040:      	st1.s	{ v18 }[1], [x5]
    3044:      	tbz	w4, #0x2, 0xfa4 <ltmp0+0xfa4>
    3048:      	add	x5, x15, #0x8
    304c:      	st1.s	{ v18 }[2], [x5]
    3050:      	tbz	w4, #0x3, 0xfa8 <ltmp0+0xfa8>
    3054:      	add	x5, x15, #0xc
    3058:      	st1.s	{ v18 }[3], [x5]
    305c:      	fmul.4s	v3, v1, v0
    3060:      	fmul.4s	v18, v16, v24
    3064:      	fsub.4s	v3, v3, v18
    3068:      	tbz	w4, #0x4, 0xfb8 <ltmp0+0xfb8>
    306c:      	str	s3, [x15, #0x10]
    3070:      	tbz	w4, #0x5, 0xfbc <ltmp0+0xfbc>
    3074:      	add	x5, x15, #0x14
    3078:      	st1.s	{ v3 }[1], [x5]
    307c:      	tbz	w4, #0x6, 0xfc0 <ltmp0+0xfc0>
    3080:      	add	x5, x15, #0x18
    3084:      	st1.s	{ v3 }[2], [x5]
    3088:      	tbnz	w4, #0x7, 0xfc4 <ltmp0+0xfc4>
    308c:      	b	0xfcc <ltmp0+0xfcc>
    3090:      	str	s2, [x15]
    3094:      	tbz	w1, #0x1, 0x1000 <ltmp0+0x1000>
    3098:      	add	x4, x15, #0x4
    309c:      	st1.s	{ v2 }[1], [x4]
    30a0:      	tbz	w1, #0x2, 0x1004 <ltmp0+0x1004>
    30a4:      	add	x4, x15, #0x8
    30a8:      	st1.s	{ v2 }[2], [x4]
    30ac:      	tbz	w1, #0x3, 0x1008 <ltmp0+0x1008>
    30b0:      	add	x4, x15, #0xc
    30b4:      	st1.s	{ v2 }[3], [x4]
    30b8:      	fmul.4s	v1, v1, v24
    30bc:      	fmul.4s	v0, v16, v0
    30c0:      	fadd.4s	v0, v0, v1
    30c4:      	tbz	w1, #0x4, 0x1018 <ltmp0+0x1018>
    30c8:      	str	s0, [x15, #0x10]
    30cc:      	tbz	w1, #0x5, 0x101c <ltmp0+0x101c>
    30d0:      	add	x4, x15, #0x14
    30d4:      	st1.s	{ v0 }[1], [x4]
    30d8:      	tbz	w1, #0x6, 0x1020 <ltmp0+0x1020>
    30dc:      	add	x4, x15, #0x18
    30e0:      	st1.s	{ v0 }[2], [x4]
    30e4:      	tbz	w1, #0x7, 0x84 <ltmp0+0x84>
    30e8:      	add	x15, x15, #0x1c
    30ec:      	b	0x80 <ltmp0+0x80>
    30f0:      	ldr	s1, [x19]
    30f4:      	and	w15, w15, #0xff
    30f8:      	tbz	w15, #0x1, 0x1464 <ltmp0+0x1464>
    30fc:      	add	x21, x19, #0x4
    3100:      	ld1.s	{ v1 }[1], [x21]
    3104:      	tbz	w15, #0x2, 0x1468 <ltmp0+0x1468>
    3108:      	add	x21, x19, #0x8
    310c:      	ld1.s	{ v1 }[2], [x21]
    3110:      	tbz	w15, #0x3, 0x146c <ltmp0+0x146c>
    3114:      	add	x21, x19, #0xc
    3118:      	ld1.s	{ v1 }[3], [x21]
    311c:      	tbz	w15, #0x4, 0x1470 <ltmp0+0x1470>
    3120:      	add	x21, x19, #0x10
    3124:      	ld1.s	{ v2 }[0], [x21]
    3128:      	tbz	w15, #0x5, 0x1474 <ltmp0+0x1474>
    312c:      	add	x21, x19, #0x14
    3130:      	ld1.s	{ v2 }[1], [x21]
    3134:      	tbz	w15, #0x6, 0x1478 <ltmp0+0x1478>
    3138:      	add	x21, x19, #0x18
    313c:      	ld1.s	{ v2 }[2], [x21]
    3140:      	tbnz	w15, #0x7, 0x147c <ltmp0+0x147c>
    3144:      	b	0x1484 <ltmp0+0x1484>
    3148:      	ldr	s2, [x19]
    314c:      	and	w15, w15, #0xff
    3150:      	tbz	w15, #0x1, 0x14c4 <ltmp0+0x14c4>
    3154:      	add	x21, x19, #0x4
    3158:      	ld1.s	{ v2 }[1], [x21]
    315c:      	tbz	w15, #0x2, 0x14c8 <ltmp0+0x14c8>
    3160:      	add	x21, x19, #0x8
    3164:      	ld1.s	{ v2 }[2], [x21]
    3168:      	tbz	w15, #0x3, 0x14cc <ltmp0+0x14cc>
    316c:      	add	x21, x19, #0xc
    3170:      	ld1.s	{ v2 }[3], [x21]
    3174:      	tbz	w15, #0x4, 0x14d0 <ltmp0+0x14d0>
    3178:      	add	x21, x19, #0x10
    317c:      	ld1.s	{ v3 }[0], [x21]
    3180:      	tbz	w15, #0x5, 0x14d4 <ltmp0+0x14d4>
    3184:      	add	x21, x19, #0x14
    3188:      	ld1.s	{ v3 }[1], [x21]
    318c:      	tbz	w15, #0x6, 0x14d8 <ltmp0+0x14d8>
    3190:      	add	x21, x19, #0x18
    3194:      	ld1.s	{ v3 }[2], [x21]
    3198:      	tbnz	w15, #0x7, 0x14dc <ltmp0+0x14dc>
    319c:      	b	0x14e4 <ltmp0+0x14e4>
    31a0:      	ldr	s2, [x19]
    31a4:      	and	w15, w15, #0xff
    31a8:      	tbz	w15, #0x1, 0x151c <ltmp0+0x151c>
    31ac:      	add	x21, x19, #0x4
    31b0:      	ld1.s	{ v2 }[1], [x21]
    31b4:      	tbz	w15, #0x2, 0x1520 <ltmp0+0x1520>
    31b8:      	add	x21, x19, #0x8
    31bc:      	ld1.s	{ v2 }[2], [x21]
    31c0:      	tbz	w15, #0x3, 0x1524 <ltmp0+0x1524>
    31c4:      	add	x21, x19, #0xc
    31c8:      	ld1.s	{ v2 }[3], [x21]
    31cc:      	tbz	w15, #0x4, 0x1528 <ltmp0+0x1528>
    31d0:      	add	x21, x19, #0x10
    31d4:      	ld1.s	{ v3 }[0], [x21]
    31d8:      	tbz	w15, #0x5, 0x152c <ltmp0+0x152c>
    31dc:      	add	x21, x19, #0x14
    31e0:      	ld1.s	{ v3 }[1], [x21]
    31e4:      	tbz	w15, #0x6, 0x1530 <ltmp0+0x1530>
    31e8:      	add	x21, x19, #0x18
    31ec:      	ld1.s	{ v3 }[2], [x21]
    31f0:      	tbnz	w15, #0x7, 0x1534 <ltmp0+0x1534>
    31f4:      	b	0x153c <ltmp0+0x153c>
    31f8:      	ldr	s1, [x19]
    31fc:      	and	w15, w15, #0xff
    3200:      	tbz	w15, #0x1, 0x1570 <ltmp0+0x1570>
    3204:      	add	x21, x19, #0x4
    3208:      	ld1.s	{ v1 }[1], [x21]
    320c:      	tbz	w15, #0x2, 0x1574 <ltmp0+0x1574>
    3210:      	add	x21, x19, #0x8
    3214:      	ld1.s	{ v1 }[2], [x21]
    3218:      	tbz	w15, #0x3, 0x1578 <ltmp0+0x1578>
    321c:      	add	x21, x19, #0xc
    3220:      	ld1.s	{ v1 }[3], [x21]
    3224:      	tbz	w15, #0x4, 0x157c <ltmp0+0x157c>
    3228:      	add	x21, x19, #0x10
    322c:      	ld1.s	{ v2 }[0], [x21]
    3230:      	tbz	w15, #0x5, 0x1580 <ltmp0+0x1580>
    3234:      	add	x21, x19, #0x14
    3238:      	ld1.s	{ v2 }[1], [x21]
    323c:      	tbz	w15, #0x6, 0x1584 <ltmp0+0x1584>
    3240:      	add	x21, x19, #0x18
    3244:      	ld1.s	{ v2 }[2], [x21]
    3248:      	tbnz	w15, #0x7, 0x1588 <ltmp0+0x1588>
    324c:      	b	0x1590 <ltmp0+0x1590>
    3250:      	ldr	s1, [x22]
    3254:      	tbz	w21, #0x1, 0x1634 <ltmp0+0x1634>
    3258:      	add	x15, x22, #0x4
    325c:      	ld1.s	{ v1 }[1], [x15]
    3260:      	tbz	w21, #0x2, 0x1638 <ltmp0+0x1638>
    3264:      	add	x15, x22, #0x8
    3268:      	ld1.s	{ v1 }[2], [x15]
    326c:      	tbz	w21, #0x3, 0x163c <ltmp0+0x163c>
    3270:      	add	x15, x22, #0xc
    3274:      	ld1.s	{ v1 }[3], [x15]
    3278:      	tbz	w21, #0x4, 0x1640 <ltmp0+0x1640>
    327c:      	add	x15, x22, #0x10
    3280:      	ld1.s	{ v3 }[0], [x15]
    3284:      	tbz	w21, #0x5, 0x1644 <ltmp0+0x1644>
    3288:      	add	x15, x22, #0x14
    328c:      	ld1.s	{ v3 }[1], [x15]
    3290:      	tbz	w21, #0x6, 0x1648 <ltmp0+0x1648>
    3294:      	add	x15, x22, #0x18
    3298:      	ld1.s	{ v3 }[2], [x15]
    329c:      	tbnz	w21, #0x7, 0x164c <ltmp0+0x164c>
    32a0:      	b	0x1654 <ltmp0+0x1654>
    32a4:      	ldr	s0, [x25]
    32a8:      	and	w15, w15, #0xff
    32ac:      	tbz	w15, #0x1, 0x1710 <ltmp0+0x1710>
    32b0:      	add	x30, x25, #0x4
    32b4:      	ld1.s	{ v0 }[1], [x30]
    32b8:      	tbz	w15, #0x2, 0x1714 <ltmp0+0x1714>
    32bc:      	add	x30, x25, #0x8
    32c0:      	ld1.s	{ v0 }[2], [x30]
    32c4:      	tbz	w15, #0x3, 0x1718 <ltmp0+0x1718>
    32c8:      	add	x30, x25, #0xc
    32cc:      	ld1.s	{ v0 }[3], [x30]
    32d0:      	tbz	w15, #0x4, 0x171c <ltmp0+0x171c>
    32d4:      	add	x30, x25, #0x10
    32d8:      	ld1.s	{ v16 }[0], [x30]
    32dc:      	tbz	w15, #0x5, 0x1720 <ltmp0+0x1720>
    32e0:      	add	x30, x25, #0x14
    32e4:      	ld1.s	{ v16 }[1], [x30]
    32e8:      	tbz	w15, #0x6, 0x1724 <ltmp0+0x1724>
    32ec:      	add	x30, x25, #0x18
    32f0:      	ld1.s	{ v16 }[2], [x30]
    32f4:      	tbnz	w15, #0x7, 0x1728 <ltmp0+0x1728>
    32f8:      	b	0x1730 <ltmp0+0x1730>
    32fc:      	ldr	s18, [x25]
    3300:      	and	w15, w15, #0xff
    3304:      	tbz	w15, #0x1, 0x1780 <ltmp0+0x1780>
    3308:      	add	x30, x25, #0x4
    330c:      	ld1.s	{ v18 }[1], [x30]
    3310:      	tbz	w15, #0x2, 0x1784 <ltmp0+0x1784>
    3314:      	add	x30, x25, #0x8
    3318:      	ld1.s	{ v18 }[2], [x30]
    331c:      	tbz	w15, #0x3, 0x1788 <ltmp0+0x1788>
    3320:      	add	x30, x25, #0xc
    3324:      	ld1.s	{ v18 }[3], [x30]
    3328:      	tbz	w15, #0x4, 0x178c <ltmp0+0x178c>
    332c:      	add	x30, x25, #0x10
    3330:      	ld1.s	{ v19 }[0], [x30]
    3334:      	tbz	w15, #0x5, 0x1790 <ltmp0+0x1790>
    3338:      	add	x30, x25, #0x14
    333c:      	ld1.s	{ v19 }[1], [x30]
    3340:      	tbz	w15, #0x6, 0x1794 <ltmp0+0x1794>
    3344:      	add	x30, x25, #0x18
    3348:      	ld1.s	{ v19 }[2], [x30]
    334c:      	tbnz	w15, #0x7, 0x1798 <ltmp0+0x1798>
    3350:      	b	0x17a0 <ltmp0+0x17a0>
    3354:      	ldr	s18, [x25]
    3358:      	and	w15, w15, #0xff
    335c:      	tbz	w15, #0x1, 0x17e0 <ltmp0+0x17e0>
    3360:      	add	x30, x25, #0x4
    3364:      	ld1.s	{ v18 }[1], [x30]
    3368:      	tbz	w15, #0x2, 0x17e4 <ltmp0+0x17e4>
    336c:      	add	x30, x25, #0x8
    3370:      	ld1.s	{ v18 }[2], [x30]
    3374:      	tbz	w15, #0x3, 0x17e8 <ltmp0+0x17e8>
    3378:      	add	x30, x25, #0xc
    337c:      	ld1.s	{ v18 }[3], [x30]
    3380:      	tbz	w15, #0x4, 0x17ec <ltmp0+0x17ec>
    3384:      	add	x30, x25, #0x10
    3388:      	ld1.s	{ v19 }[0], [x30]
    338c:      	tbz	w15, #0x5, 0x17f0 <ltmp0+0x17f0>
    3390:      	add	x30, x25, #0x14
    3394:      	ld1.s	{ v19 }[1], [x30]
    3398:      	tbz	w15, #0x6, 0x17f4 <ltmp0+0x17f4>
    339c:      	add	x30, x25, #0x18
    33a0:      	ld1.s	{ v19 }[2], [x30]
    33a4:      	tbnz	w15, #0x7, 0x17f8 <ltmp0+0x17f8>
    33a8:      	b	0x1800 <ltmp0+0x1800>
    33ac:      	ldr	s17, [x25]
    33b0:      	and	w15, w15, #0xff
    33b4:      	tbz	w15, #0x1, 0x1840 <ltmp0+0x1840>
    33b8:      	add	x30, x25, #0x4
    33bc:      	ld1.s	{ v17 }[1], [x30]
    33c0:      	tbz	w15, #0x2, 0x1844 <ltmp0+0x1844>
    33c4:      	add	x30, x25, #0x8
    33c8:      	ld1.s	{ v17 }[2], [x30]
    33cc:      	tbz	w15, #0x3, 0x1848 <ltmp0+0x1848>
    33d0:      	add	x30, x25, #0xc
    33d4:      	ld1.s	{ v17 }[3], [x30]
    33d8:      	str	q22, [sp, #0x230]
    33dc:      	tbz	w15, #0x4, 0x1850 <ltmp0+0x1850>
    33e0:      	add	x30, x25, #0x10
    33e4:      	ld1.s	{ v18 }[0], [x30]
    33e8:      	fmov	d9, d28
    33ec:      	tbz	w15, #0x5, 0x1858 <ltmp0+0x1858>
    33f0:      	add	x30, x25, #0x14
    33f4:      	ld1.s	{ v18 }[1], [x30]
    33f8:      	fmov	d28, d29
    33fc:      	mov.16b	v29, v8
    3400:      	tbz	w15, #0x6, 0x1864 <ltmp0+0x1864>
    3404:      	add	x30, x25, #0x18
    3408:      	ld1.s	{ v18 }[2], [x30]
    340c:      	mov.16b	v8, v31
    3410:      	mov.16b	v31, v30
    3414:      	tbnz	w15, #0x7, 0x1870 <ltmp0+0x1870>
    3418:      	b	0x1878 <ltmp0+0x1878>
    341c:      	ldr	s3, [x7]
    3420:      	tbz	w25, #0x1, 0x1994 <ltmp0+0x1994>
    3424:      	add	x15, x7, #0x4
    3428:      	ld1.s	{ v3 }[1], [x15]
    342c:      	mov.16b	v24, v8
    3430:      	mov.16b	v31, v29
    3434:      	tbz	w25, #0x2, 0x19a0 <ltmp0+0x19a0>
    3438:      	add	x15, x7, #0x8
    343c:      	ld1.s	{ v3 }[2], [x15]
    3440:      	fmov	d29, d28
    3444:      	tbz	w25, #0x3, 0x19a8 <ltmp0+0x19a8>
    3448:      	add	x15, x7, #0xc
    344c:      	ld1.s	{ v3 }[3], [x15]
    3450:      	fmov	d8, d15
    3454:      	ldr	q15, [sp, #0x230]
    3458:      	tbz	w25, #0x4, 0x19b4 <ltmp0+0x19b4>
    345c:      	add	x15, x7, #0x10
    3460:      	ld1.s	{ v4 }[0], [x15]
    3464:      	tbz	w25, #0x5, 0x19b8 <ltmp0+0x19b8>
    3468:      	add	x15, x7, #0x14
    346c:      	ld1.s	{ v4 }[1], [x15]
    3470:      	tbz	w25, #0x6, 0x19bc <ltmp0+0x19bc>
    3474:      	add	x15, x7, #0x18
    3478:      	ld1.s	{ v4 }[2], [x15]
    347c:      	tbnz	w25, #0x7, 0x19c0 <ltmp0+0x19c0>
    3480:      	b	0x19c8 <ltmp0+0x19c8>
    3484:      	ldr	s3, [x7]
    3488:      	and	w15, w15, #0xff
    348c:      	tbz	w15, #0x1, 0x1a30 <ltmp0+0x1a30>
    3490:      	add	x25, x7, #0x4
    3494:      	ld1.s	{ v3 }[1], [x25]
    3498:      	tbz	w15, #0x2, 0x1a34 <ltmp0+0x1a34>
    349c:      	add	x25, x7, #0x8
    34a0:      	ld1.s	{ v3 }[2], [x25]
    34a4:      	tbz	w15, #0x3, 0x1a38 <ltmp0+0x1a38>
    34a8:      	add	x25, x7, #0xc
    34ac:      	ld1.s	{ v3 }[3], [x25]
    34b0:      	tbz	w15, #0x4, 0x1a3c <ltmp0+0x1a3c>
    34b4:      	add	x25, x7, #0x10
    34b8:      	ld1.s	{ v4 }[0], [x25]
    34bc:      	tbz	w15, #0x5, 0x1a40 <ltmp0+0x1a40>
    34c0:      	add	x25, x7, #0x14
    34c4:      	ld1.s	{ v4 }[1], [x25]
    34c8:      	tbz	w15, #0x6, 0x1a44 <ltmp0+0x1a44>
    34cc:      	add	x25, x7, #0x18
    34d0:      	ld1.s	{ v4 }[2], [x25]
    34d4:      	tbnz	w15, #0x7, 0x1a48 <ltmp0+0x1a48>
    34d8:      	b	0x1a50 <ltmp0+0x1a50>
    34dc:      	ldr	s3, [x7]
    34e0:      	and	w15, w15, #0xff
    34e4:      	tbz	w15, #0x1, 0x1a8c <ltmp0+0x1a8c>
    34e8:      	add	x25, x7, #0x4
    34ec:      	ld1.s	{ v3 }[1], [x25]
    34f0:      	tbz	w15, #0x2, 0x1a90 <ltmp0+0x1a90>
    34f4:      	add	x25, x7, #0x8
    34f8:      	ld1.s	{ v3 }[2], [x25]
    34fc:      	tbz	w15, #0x3, 0x1a94 <ltmp0+0x1a94>
    3500:      	add	x25, x7, #0xc
    3504:      	ld1.s	{ v3 }[3], [x25]
    3508:      	tbz	w15, #0x4, 0x1a98 <ltmp0+0x1a98>
    350c:      	add	x25, x7, #0x10
    3510:      	ld1.s	{ v4 }[0], [x25]
    3514:      	tbz	w15, #0x5, 0x1a9c <ltmp0+0x1a9c>
    3518:      	add	x25, x7, #0x14
    351c:      	ld1.s	{ v4 }[1], [x25]
    3520:      	tbz	w15, #0x6, 0x1aa0 <ltmp0+0x1aa0>
    3524:      	add	x25, x7, #0x18
    3528:      	ld1.s	{ v4 }[2], [x25]
    352c:      	tbnz	w15, #0x7, 0x1aa4 <ltmp0+0x1aa4>
    3530:      	b	0x1aac <ltmp0+0x1aac>
    3534:      	ldr	s3, [x7]
    3538:      	and	w15, w15, #0xff
    353c:      	tbz	w15, #0x1, 0x1ae8 <ltmp0+0x1ae8>
    3540:      	add	x25, x7, #0x4
    3544:      	ld1.s	{ v3 }[1], [x25]
    3548:      	tbz	w15, #0x2, 0x1aec <ltmp0+0x1aec>
    354c:      	add	x25, x7, #0x8
    3550:      	ld1.s	{ v3 }[2], [x25]
    3554:      	tbz	w15, #0x3, 0x1af0 <ltmp0+0x1af0>
    3558:      	add	x25, x7, #0xc
    355c:      	ld1.s	{ v3 }[3], [x25]
    3560:      	tbz	w15, #0x4, 0x1af4 <ltmp0+0x1af4>
    3564:      	add	x25, x7, #0x10
    3568:      	ld1.s	{ v4 }[0], [x25]
    356c:      	tbz	w15, #0x5, 0x1af8 <ltmp0+0x1af8>
    3570:      	add	x25, x7, #0x14
    3574:      	ld1.s	{ v4 }[1], [x25]
    3578:      	tbz	w15, #0x6, 0x1afc <ltmp0+0x1afc>
    357c:      	add	x25, x7, #0x18
    3580:      	ld1.s	{ v4 }[2], [x25]
    3584:      	tbnz	w15, #0x7, 0x1b00 <ltmp0+0x1b00>
    3588:      	b	0x1b08 <ltmp0+0x1b08>
    358c:      	ldr	s3, [x7]
    3590:      	and	w15, w15, #0xff
    3594:      	tbz	w15, #0x1, 0x1b44 <ltmp0+0x1b44>
    3598:      	add	x25, x7, #0x4
    359c:      	ld1.s	{ v3 }[1], [x25]
    35a0:      	tbz	w15, #0x2, 0x1b48 <ltmp0+0x1b48>
    35a4:      	add	x25, x7, #0x8
    35a8:      	ld1.s	{ v3 }[2], [x25]
    35ac:      	tbz	w15, #0x3, 0x1b4c <ltmp0+0x1b4c>
    35b0:      	add	x25, x7, #0xc
    35b4:      	ld1.s	{ v3 }[3], [x25]
    35b8:      	tbz	w15, #0x4, 0x1b50 <ltmp0+0x1b50>
    35bc:      	add	x25, x7, #0x10
    35c0:      	ld1.s	{ v4 }[0], [x25]
    35c4:      	tbz	w15, #0x5, 0x1b54 <ltmp0+0x1b54>
    35c8:      	add	x25, x7, #0x14
    35cc:      	ld1.s	{ v4 }[1], [x25]
    35d0:      	tbz	w15, #0x6, 0x1b58 <ltmp0+0x1b58>
    35d4:      	add	x25, x7, #0x18
    35d8:      	ld1.s	{ v4 }[2], [x25]
    35dc:      	tbnz	w15, #0x7, 0x1b5c <ltmp0+0x1b5c>
    35e0:      	b	0x1b64 <ltmp0+0x1b64>
    35e4:      	ldr	s3, [x5]
    35e8:      	tbz	w25, #0x1, 0x1c64 <ltmp0+0x1c64>
    35ec:      	add	x15, x5, #0x4
    35f0:      	ld1.s	{ v3 }[1], [x15]
    35f4:      	tbz	w25, #0x2, 0x1c68 <ltmp0+0x1c68>
    35f8:      	add	x15, x5, #0x8
    35fc:      	ld1.s	{ v3 }[2], [x15]
    3600:      	tbz	w25, #0x3, 0x1c6c <ltmp0+0x1c6c>
    3604:      	add	x15, x5, #0xc
    3608:      	ld1.s	{ v3 }[3], [x15]
    360c:      	tbz	w25, #0x4, 0x1c70 <ltmp0+0x1c70>
    3610:      	add	x15, x5, #0x10
    3614:      	ld1.s	{ v4 }[0], [x15]
    3618:      	tbz	w25, #0x5, 0x1c74 <ltmp0+0x1c74>
    361c:      	add	x15, x5, #0x14
    3620:      	ld1.s	{ v4 }[1], [x15]
    3624:      	tbz	w25, #0x6, 0x1c78 <ltmp0+0x1c78>
    3628:      	add	x15, x5, #0x18
    362c:      	ld1.s	{ v4 }[2], [x15]
    3630:      	tbnz	w25, #0x7, 0x1c7c <ltmp0+0x1c7c>
    3634:      	b	0x1c84 <ltmp0+0x1c84>
    3638:      	ldr	s3, [x5]
    363c:      	and	w15, w15, #0xff
    3640:      	tbz	w15, #0x1, 0x1cdc <ltmp0+0x1cdc>
    3644:      	add	x25, x5, #0x4
    3648:      	ld1.s	{ v3 }[1], [x25]
    364c:      	tbz	w15, #0x2, 0x1ce0 <ltmp0+0x1ce0>
    3650:      	add	x25, x5, #0x8
    3654:      	ld1.s	{ v3 }[2], [x25]
    3658:      	tbz	w15, #0x3, 0x1ce4 <ltmp0+0x1ce4>
    365c:      	add	x25, x5, #0xc
    3660:      	ld1.s	{ v3 }[3], [x25]
    3664:      	tbz	w15, #0x4, 0x1ce8 <ltmp0+0x1ce8>
    3668:      	add	x25, x5, #0x10
    366c:      	ld1.s	{ v4 }[0], [x25]
    3670:      	tbz	w15, #0x5, 0x1cec <ltmp0+0x1cec>
    3674:      	add	x25, x5, #0x14
    3678:      	ld1.s	{ v4 }[1], [x25]
    367c:      	tbz	w15, #0x6, 0x1cf0 <ltmp0+0x1cf0>
    3680:      	add	x25, x5, #0x18
    3684:      	ld1.s	{ v4 }[2], [x25]
    3688:      	tbnz	w15, #0x7, 0x1cf4 <ltmp0+0x1cf4>
    368c:      	b	0x1cfc <ltmp0+0x1cfc>
    3690:      	ldr	s3, [x5]
    3694:      	and	w15, w15, #0xff
    3698:      	tbz	w15, #0x1, 0x1d3c <ltmp0+0x1d3c>
    369c:      	add	x25, x5, #0x4
    36a0:      	ld1.s	{ v3 }[1], [x25]
    36a4:      	tbz	w15, #0x2, 0x1d40 <ltmp0+0x1d40>
    36a8:      	add	x25, x5, #0x8
    36ac:      	ld1.s	{ v3 }[2], [x25]
    36b0:      	tbz	w15, #0x3, 0x1d44 <ltmp0+0x1d44>
    36b4:      	add	x25, x5, #0xc
    36b8:      	ld1.s	{ v3 }[3], [x25]
    36bc:      	tbz	w15, #0x4, 0x1d48 <ltmp0+0x1d48>
    36c0:      	add	x25, x5, #0x10
    36c4:      	ld1.s	{ v4 }[0], [x25]
    36c8:      	tbz	w15, #0x5, 0x1d4c <ltmp0+0x1d4c>
    36cc:      	add	x25, x5, #0x14
    36d0:      	ld1.s	{ v4 }[1], [x25]
    36d4:      	tbz	w15, #0x6, 0x1d50 <ltmp0+0x1d50>
    36d8:      	add	x25, x5, #0x18
    36dc:      	ld1.s	{ v4 }[2], [x25]
    36e0:      	tbnz	w15, #0x7, 0x1d54 <ltmp0+0x1d54>
    36e4:      	b	0x1d5c <ltmp0+0x1d5c>
    36e8:      	ldr	s3, [x5]
    36ec:      	and	w15, w15, #0xff
    36f0:      	tbz	w15, #0x1, 0x1d9c <ltmp0+0x1d9c>
    36f4:      	add	x25, x5, #0x4
    36f8:      	ld1.s	{ v3 }[1], [x25]
    36fc:      	tbz	w15, #0x2, 0x1da0 <ltmp0+0x1da0>
    3700:      	add	x25, x5, #0x8
    3704:      	ld1.s	{ v3 }[2], [x25]
    3708:      	tbz	w15, #0x3, 0x1da4 <ltmp0+0x1da4>
    370c:      	add	x25, x5, #0xc
    3710:      	ld1.s	{ v3 }[3], [x25]
    3714:      	tbz	w15, #0x4, 0x1da8 <ltmp0+0x1da8>
    3718:      	add	x25, x5, #0x10
    371c:      	ld1.s	{ v4 }[0], [x25]
    3720:      	tbz	w15, #0x5, 0x1dac <ltmp0+0x1dac>
    3724:      	add	x25, x5, #0x14
    3728:      	ld1.s	{ v4 }[1], [x25]
    372c:      	tbz	w15, #0x6, 0x1db0 <ltmp0+0x1db0>
    3730:      	add	x25, x5, #0x18
    3734:      	ld1.s	{ v4 }[2], [x25]
    3738:      	tbnz	w15, #0x7, 0x1db4 <ltmp0+0x1db4>
    373c:      	b	0x1dbc <ltmp0+0x1dbc>
    3740:      	ldr	s3, [x5]
    3744:      	and	w15, w15, #0xff
    3748:      	tbz	w15, #0x1, 0x1dfc <ltmp0+0x1dfc>
    374c:      	add	x25, x5, #0x4
    3750:      	ld1.s	{ v3 }[1], [x25]
    3754:      	tbz	w15, #0x2, 0x1e00 <ltmp0+0x1e00>
    3758:      	add	x25, x5, #0x8
    375c:      	ld1.s	{ v3 }[2], [x25]
    3760:      	tbz	w15, #0x3, 0x1e04 <ltmp0+0x1e04>
    3764:      	add	x25, x5, #0xc
    3768:      	ld1.s	{ v3 }[3], [x25]
    376c:      	tbz	w15, #0x4, 0x1e08 <ltmp0+0x1e08>
    3770:      	add	x25, x5, #0x10
    3774:      	ld1.s	{ v4 }[0], [x25]
    3778:      	tbz	w15, #0x5, 0x1e0c <ltmp0+0x1e0c>
    377c:      	add	x25, x5, #0x14
    3780:      	ld1.s	{ v4 }[1], [x25]
    3784:      	tbz	w15, #0x6, 0x1e10 <ltmp0+0x1e10>
    3788:      	add	x25, x5, #0x18
    378c:      	ld1.s	{ v4 }[2], [x25]
    3790:      	tbnz	w15, #0x7, 0x1e14 <ltmp0+0x1e14>
    3794:      	b	0x1e1c <ltmp0+0x1e1c>
    3798:      	ldr	s3, [x4]
    379c:      	tbz	w5, #0x1, 0x1e4c <ltmp0+0x1e4c>
    37a0:      	add	x15, x4, #0x4
    37a4:      	ld1.s	{ v3 }[1], [x15]
    37a8:      	tbz	w5, #0x2, 0x1e50 <ltmp0+0x1e50>
    37ac:      	add	x15, x4, #0x8
    37b0:      	ld1.s	{ v3 }[2], [x15]
    37b4:      	tbz	w5, #0x3, 0x1e54 <ltmp0+0x1e54>
    37b8:      	add	x15, x4, #0xc
    37bc:      	ld1.s	{ v3 }[3], [x15]
    37c0:      	tbz	w5, #0x4, 0x1e58 <ltmp0+0x1e58>
    37c4:      	add	x15, x4, #0x10
    37c8:      	ld1.s	{ v4 }[0], [x15]
    37cc:      	tbz	w5, #0x5, 0x1e5c <ltmp0+0x1e5c>
    37d0:      	add	x15, x4, #0x14
    37d4:      	ld1.s	{ v4 }[1], [x15]
    37d8:      	tbz	w5, #0x6, 0x1e60 <ltmp0+0x1e60>
    37dc:      	add	x15, x4, #0x18
    37e0:      	ld1.s	{ v4 }[2], [x15]
    37e4:      	tbnz	w5, #0x7, 0x1e64 <ltmp0+0x1e64>
    37e8:      	b	0x1e6c <ltmp0+0x1e6c>
    37ec:      	str	s2, [x15]
    37f0:      	and	w4, w4, #0xff
    37f4:      	tbz	w4, #0x1, 0x1f04 <ltmp0+0x1f04>
    37f8:      	add	x5, x15, #0x4
    37fc:      	st1.s	{ v2 }[1], [x5]
    3800:      	tbz	w4, #0x2, 0x1f08 <ltmp0+0x1f08>
    3804:      	add	x5, x15, #0x8
    3808:      	st1.s	{ v2 }[2], [x5]
    380c:      	tbz	w4, #0x3, 0x1f0c <ltmp0+0x1f0c>
    3810:      	add	x5, x15, #0xc
    3814:      	st1.s	{ v2 }[3], [x5]
    3818:      	fmul.4s	v2, v3, v16
    381c:      	fmul.4s	v4, v17, v31
    3820:      	fsub.4s	v2, v2, v4
    3824:      	and.16b	v2, v21, v2
    3828:      	tbz	w4, #0x4, 0x1f20 <ltmp0+0x1f20>
    382c:      	str	s2, [x15, #0x10]
    3830:      	tbz	w4, #0x5, 0x1f24 <ltmp0+0x1f24>
    3834:      	add	x5, x15, #0x14
    3838:      	st1.s	{ v2 }[1], [x5]
    383c:      	tbz	w4, #0x6, 0x1f28 <ltmp0+0x1f28>
    3840:      	add	x5, x15, #0x18
    3844:      	st1.s	{ v2 }[2], [x5]
    3848:      	tbnz	w4, #0x7, 0x1f2c <ltmp0+0x1f2c>
    384c:      	b	0x1f34 <ltmp0+0x1f34>
    3850:      	str	s1, [x15]
    3854:      	and	w4, w4, #0xff
    3858:      	tbz	w4, #0x1, 0x1f98 <ltmp0+0x1f98>
    385c:      	add	x5, x15, #0x4
    3860:      	st1.s	{ v1 }[1], [x5]
    3864:      	tbz	w4, #0x2, 0x1f9c <ltmp0+0x1f9c>
    3868:      	add	x5, x15, #0x8
    386c:      	st1.s	{ v1 }[2], [x5]
    3870:      	tbz	w4, #0x3, 0x1fa0 <ltmp0+0x1fa0>
    3874:      	add	x5, x15, #0xc
    3878:      	st1.s	{ v1 }[3], [x5]
    387c:      	fmul.4s	v1, v7, v19
    3880:      	fmul.4s	v2, v20, v26
    3884:      	fsub.4s	v1, v1, v2
    3888:      	and.16b	v1, v21, v1
    388c:      	tbz	w4, #0x4, 0x1fb4 <ltmp0+0x1fb4>
    3890:      	str	s1, [x15, #0x10]
    3894:      	tbz	w4, #0x5, 0x1fb8 <ltmp0+0x1fb8>
    3898:      	add	x5, x15, #0x14
    389c:      	st1.s	{ v1 }[1], [x5]
    38a0:      	tbz	w4, #0x6, 0x1fbc <ltmp0+0x1fbc>
    38a4:      	add	x5, x15, #0x18
    38a8:      	st1.s	{ v1 }[2], [x5]
    38ac:      	stp	q7, q17, [sp, #0xf0]
    38b0:      	str	q16, [sp, #0x200]
    38b4:      	tbnz	w4, #0x7, 0x1fc8 <ltmp0+0x1fc8>
    38b8:      	b	0x1fd0 <ltmp0+0x1fd0>
    38bc:      	str	s0, [x15]
    38c0:      	and	w4, w4, #0xff
    38c4:      	tbz	w4, #0x1, 0x2030 <ltmp0+0x2030>
    38c8:      	add	x5, x15, #0x4
    38cc:      	st1.s	{ v0 }[1], [x5]
    38d0:      	tbz	w4, #0x2, 0x2034 <ltmp0+0x2034>
    38d4:      	add	x5, x15, #0x8
    38d8:      	st1.s	{ v0 }[2], [x5]
    38dc:      	tbz	w4, #0x3, 0x2038 <ltmp0+0x2038>
    38e0:      	add	x5, x15, #0xc
    38e4:      	st1.s	{ v0 }[3], [x5]
    38e8:      	fmul.4s	v0, v9, v8
    38ec:      	fmul.4s	v1, v22, v23
    38f0:      	fsub.4s	v0, v0, v1
    38f4:      	and.16b	v0, v21, v0
    38f8:      	tbz	w4, #0x4, 0x204c <ltmp0+0x204c>
    38fc:      	str	s0, [x15, #0x10]
    3900:      	tbz	w4, #0x5, 0x2050 <ltmp0+0x2050>
    3904:      	add	x5, x15, #0x14
    3908:      	st1.s	{ v0 }[1], [x5]
    390c:      	tbz	w4, #0x6, 0x2054 <ltmp0+0x2054>
    3910:      	add	x5, x15, #0x18
    3914:      	st1.s	{ v0 }[2], [x5]
    3918:      	stp	q26, q20, [sp, #0xd0]
    391c:      	str	q19, [sp, #0x220]
    3920:      	tbnz	w4, #0x7, 0x2060 <ltmp0+0x2060>
    3924:      	b	0x2068 <ltmp0+0x2068>
    3928:      	str	s0, [x15]
    392c:      	and	w4, w4, #0xff
    3930:      	tbz	w4, #0x1, 0x20c8 <ltmp0+0x20c8>
    3934:      	add	x5, x15, #0x4
    3938:      	st1.s	{ v0 }[1], [x5]
    393c:      	tbz	w4, #0x2, 0x20cc <ltmp0+0x20cc>
    3940:      	add	x5, x15, #0x8
    3944:      	st1.s	{ v0 }[2], [x5]
    3948:      	tbz	w4, #0x3, 0x20d0 <ltmp0+0x20d0>
    394c:      	add	x5, x15, #0xc
    3950:      	st1.s	{ v0 }[3], [x5]
    3954:      	fmul.4s	v0, v24, v27
    3958:      	fmul.4s	v1, v7, v29
    395c:      	fsub.4s	v0, v0, v1
    3960:      	and.16b	v0, v21, v0
    3964:      	tbz	w4, #0x4, 0x20e4 <ltmp0+0x20e4>
    3968:      	str	s0, [x15, #0x10]
    396c:      	tbz	w4, #0x5, 0x20e8 <ltmp0+0x20e8>
    3970:      	add	x5, x15, #0x14
    3974:      	st1.s	{ v0 }[1], [x5]
    3978:      	str	q29, [sp, #0x60]
    397c:      	tbz	w4, #0x6, 0x20f0 <ltmp0+0x20f0>
    3980:      	add	x5, x15, #0x18
    3984:      	st1.s	{ v0 }[2], [x5]
    3988:      	str	q27, [sp, #0x210]
    398c:      	mov.16b	v29, v3
    3990:      	tbnz	w4, #0x7, 0x20fc <ltmp0+0x20fc>
    3994:      	b	0x2104 <ltmp0+0x2104>
    3998:      	str	s14, [x4]
    399c:      	ldr	q15, [sp, #0x230]
    39a0:      	tbz	w15, #0x1, 0x21f0 <ltmp0+0x21f0>
    39a4:      	add	x5, x4, #0x4
    39a8:      	st1.s	{ v14 }[1], [x5]
    39ac:      	tbz	w15, #0x2, 0x21f4 <ltmp0+0x21f4>
    39b0:      	add	x5, x4, #0x8
    39b4:      	st1.s	{ v14 }[2], [x5]
    39b8:      	tbnz	w15, #0x3, 0x21f8 <ltmp0+0x21f8>
    39bc:      	b	0x2200 <ltmp0+0x2200>
    39c0:      	str	s14, [x4, #0x10]
    39c4:      	tbz	w15, #0x5, 0x2228 <ltmp0+0x2228>
    39c8:      	add	x5, x4, #0x14
    39cc:      	st1.s	{ v14 }[1], [x5]
    39d0:      	tbz	w15, #0x6, 0x222c <ltmp0+0x222c>
    39d4:      	add	x5, x4, #0x18
    39d8:      	st1.s	{ v14 }[2], [x5]
    39dc:      	tbnz	w15, #0x7, 0x2230 <ltmp0+0x2230>
    39e0:      	b	0x2238 <ltmp0+0x2238>
    39e4:      	str	s3, [x15]
    39e8:      	and	w4, w4, #0xff
    39ec:      	tbz	w4, #0x1, 0x2278 <ltmp0+0x2278>
    39f0:      	add	x5, x15, #0x4
    39f4:      	st1.s	{ v3 }[1], [x5]
    39f8:      	tbz	w4, #0x2, 0x227c <ltmp0+0x227c>
    39fc:      	add	x5, x15, #0x8
    3a00:      	st1.s	{ v3 }[2], [x5]
    3a04:      	tbnz	w4, #0x3, 0x2280 <ltmp0+0x2280>
    3a08:      	b	0x2288 <ltmp0+0x2288>
    3a0c:      	str	s3, [x15, #0x10]
    3a10:      	mov.16b	v28, v23
    3a14:      	mov.16b	v29, v7
    3a18:      	tbz	w4, #0x5, 0x22b0 <ltmp0+0x22b0>
    3a1c:      	add	x5, x15, #0x14
    3a20:      	st1.s	{ v3 }[1], [x5]
    3a24:      	tbz	w4, #0x6, 0x22b4 <ltmp0+0x22b4>
    3a28:      	add	x5, x15, #0x18
    3a2c:      	st1.s	{ v3 }[2], [x5]
    3a30:      	tbnz	w4, #0x7, 0x22b8 <ltmp0+0x22b8>
    3a34:      	b	0x22c0 <ltmp0+0x22c0>
    3a38:      	str	s3, [x15]
    3a3c:      	and	w4, w4, #0xff
    3a40:      	mov.16b	v27, v24
    3a44:      	tbz	w4, #0x1, 0x2304 <ltmp0+0x2304>
    3a48:      	add	x5, x15, #0x4
    3a4c:      	st1.s	{ v3 }[1], [x5]
    3a50:      	tbz	w4, #0x2, 0x2308 <ltmp0+0x2308>
    3a54:      	add	x5, x15, #0x8
    3a58:      	st1.s	{ v3 }[2], [x5]
    3a5c:      	tbnz	w4, #0x3, 0x230c <ltmp0+0x230c>
    3a60:      	b	0x2314 <ltmp0+0x2314>
    3a64:      	str	s3, [x15, #0x10]
    3a68:      	tbz	w4, #0x5, 0x2338 <ltmp0+0x2338>
    3a6c:      	add	x5, x15, #0x14
    3a70:      	st1.s	{ v3 }[1], [x5]
    3a74:      	tbz	w4, #0x6, 0x233c <ltmp0+0x233c>
    3a78:      	add	x5, x15, #0x18
    3a7c:      	st1.s	{ v3 }[2], [x5]
    3a80:      	tbnz	w4, #0x7, 0x2340 <ltmp0+0x2340>
    3a84:      	b	0x2348 <ltmp0+0x2348>
    3a88:      	str	s3, [x15]
    3a8c:      	and	w4, w4, #0xff
    3a90:      	tbz	w4, #0x1, 0x2380 <ltmp0+0x2380>
    3a94:      	add	x5, x15, #0x4
    3a98:      	st1.s	{ v3 }[1], [x5]
    3a9c:      	tbz	w4, #0x2, 0x2384 <ltmp0+0x2384>
    3aa0:      	add	x5, x15, #0x8
    3aa4:      	st1.s	{ v3 }[2], [x5]
    3aa8:      	tbz	w4, #0x3, 0x2388 <ltmp0+0x2388>
    3aac:      	add	x5, x15, #0xc
    3ab0:      	st1.s	{ v3 }[3], [x5]
    3ab4:      	fmul.4s	v3, v9, v28
    3ab8:      	fmul.4s	v4, v8, v22
    3abc:      	fadd.4s	v3, v4, v3
    3ac0:      	and.16b	v3, v21, v3
    3ac4:      	tbz	w4, #0x4, 0x239c <ltmp0+0x239c>
    3ac8:      	str	s3, [x15, #0x10]
    3acc:      	tbz	w4, #0x5, 0x23a0 <ltmp0+0x23a0>
    3ad0:      	add	x5, x15, #0x14
    3ad4:      	st1.s	{ v3 }[1], [x5]
    3ad8:      	tbz	w4, #0x6, 0x23a4 <ltmp0+0x23a4>
    3adc:      	add	x5, x15, #0x18
    3ae0:      	st1.s	{ v3 }[2], [x5]
    3ae4:      	tbnz	w4, #0x7, 0x23a8 <ltmp0+0x23a8>
    3ae8:      	b	0x23b0 <ltmp0+0x23b0>
    3aec:      	str	s3, [x15]
    3af0:      	and	w4, w4, #0xff
    3af4:      	tbz	w4, #0x1, 0x23e4 <ltmp0+0x23e4>
    3af8:      	add	x5, x15, #0x4
    3afc:      	st1.s	{ v3 }[1], [x5]
    3b00:      	tbz	w4, #0x2, 0x23e8 <ltmp0+0x23e8>
    3b04:      	add	x5, x15, #0x8
    3b08:      	st1.s	{ v3 }[2], [x5]
    3b0c:      	tbnz	w4, #0x3, 0x23ec <ltmp0+0x23ec>
    3b10:      	b	0x23f4 <ltmp0+0x23f4>
    3b14:      	str	s3, [x15, #0x10]
    3b18:      	tbz	w4, #0x5, 0x2414 <ltmp0+0x2414>
    3b1c:      	add	x5, x15, #0x14
    3b20:      	st1.s	{ v3 }[1], [x5]
    3b24:      	tbz	w4, #0x6, 0x2418 <ltmp0+0x2418>
    3b28:      	add	x5, x15, #0x18
    3b2c:      	st1.s	{ v3 }[2], [x5]
    3b30:      	tbnz	w4, #0x7, 0x241c <ltmp0+0x241c>
    3b34:      	b	0x2424 <ltmp0+0x2424>
    3b38:      	str	s0, [x1]
    3b3c:      	tbz	w15, #0x1, 0x2474 <ltmp0+0x2474>
    3b40:      	add	x4, x1, #0x4
    3b44:      	st1.s	{ v0 }[1], [x4]
    3b48:      	tbz	w15, #0x2, 0x2478 <ltmp0+0x2478>
    3b4c:      	add	x4, x1, #0x8
    3b50:      	st1.s	{ v0 }[2], [x4]
    3b54:      	tbnz	w15, #0x3, 0x247c <ltmp0+0x247c>
    3b58:      	b	0x2484 <ltmp0+0x2484>
    3b5c:      	str	s0, [x1, #0x10]
    3b60:      	tbz	w15, #0x5, 0x24ac <ltmp0+0x24ac>
    3b64:      	add	x4, x1, #0x14
    3b68:      	st1.s	{ v0 }[1], [x4]
    3b6c:      	tbz	w15, #0x6, 0x24b0 <ltmp0+0x24b0>
    3b70:      	add	x4, x1, #0x18
    3b74:      	st1.s	{ v0 }[2], [x4]
    3b78:      	tbz	w15, #0x7, 0x84 <ltmp0+0x84>
    3b7c:      	add	x15, x1, #0x1c
    3b80:      	b	0x80 <ltmp0+0x80>
    3b84:      	add	sp, sp, #0x850
    3b88:      	ldp	x29, x30, [sp, #0x90]
    3b8c:      	ldp	x20, x19, [sp, #0x80]
    3b90:      	ldp	x22, x21, [sp, #0x70]
    3b94:      	ldp	x24, x23, [sp, #0x60]
    3b98:      	ldp	x26, x25, [sp, #0x50]
    3b9c:      	ldp	x28, x27, [sp, #0x40]
    3ba0:      	ldp	d9, d8, [sp, #0x30]
    3ba4:      	ldp	d11, d10, [sp, #0x20]
    3ba8:      	ldp	d13, d12, [sp, #0x10]
    3bac:      	ldp	d15, d14, [sp], #0xa0
    3bb0:      	ret

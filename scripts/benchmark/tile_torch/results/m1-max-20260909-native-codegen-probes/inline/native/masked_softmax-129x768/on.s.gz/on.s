
/private/tmp/luisa-packet-inline.UY1lIE/capture/masked_softmax-129x768/on/object/tile_xir_w8_36363_1788935097447657_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x4, lsl #12   ; =0x4000
      2c:      	sub	sp, sp, #0x660
      30:      	str	x0, [sp, #0x20]
      34:      	str	w3, [sp, #0x40]
      38:      	cbz	w3, 0x1f40 <ltmp0+0x1f40>
      3c:      	mov	w12, #0x0               ; =0
      40:      	add	x23, sp, #0x260
      44:      	add	x8, sp, #0x1, lsl #12   ; =0x1000
      48:      	add	x8, x8, #0xf60
      4c:      	add	x24, sp, #0x1, lsl #12  ; =0x1000
      50:      	add	x24, x24, #0x360
      54:      	dup.2d	v0, x8
      58:      	str	q0, [sp, #0xc0]
      5c:      	add	x9, x24, #0xe0
      60:      	add	x26, sp, #0x760
      64:      	add	x8, x26, #0xe0
      68:      	stp	x8, x9, [sp, #0x10]
      6c:      	add	x19, sp, #0x3, lsl #12  ; =0x3000
      70:      	add	x19, x19, #0xa60
      74:      	adrp	x8, 0x0 <ltmp0>
      78:      	ldr	q0, [x8]
      7c:      	str	q0, [sp, #0x100]
      80:      	adrp	x8, 0x0 <ltmp0>
      84:      	ldr	q0, [x8]
      88:      	str	q0, [sp, #0xf0]
      8c:      	adrp	x8, 0x0 <ltmp0>
      90:      	ldr	q0, [x8]
      94:      	str	q0, [sp, #0xe0]
      98:      	adrp	x8, 0x0 <ltmp0>
      9c:      	ldr	q0, [x8]
      a0:      	str	q0, [sp, #0xd0]
      a4:      	add	x20, sp, #0x2, lsl #12  ; =0x2000
      a8:      	add	x20, x20, #0x260
      ac:      	adrp	x8, 0x0 <ltmp0>
      b0:      	ldr	q0, [x8]
      b4:      	str	q0, [sp, #0xb0]
      b8:      	adrp	x8, 0x0 <ltmp0>
      bc:      	ldr	q0, [x8]
      c0:      	str	q0, [sp, #0xa0]
      c4:      	adrp	x8, 0x0 <ltmp0>
      c8:      	ldr	q0, [x8]
      cc:      	str	q0, [sp, #0x90]
      d0:      	adrp	x8, 0x0 <ltmp0>
      d4:      	ldr	q1, [x8]
      d8:      	movi.8b	v9, #0x1
      dc:      	mov	w8, #0xf2ca             ; =62154
      e0:      	movk	w8, #0xf149, lsl #16
      e4:      	dup.4s	v0, w8
      e8:      	str	q0, [sp, #0x110]
      ec:      	mvni.4s	v0, #0x7f, msl #16
      f0:      	fneg.4s	v0, v0
      f4:      	stp	q0, q1, [sp, #0x70]
      f8:      	mvni.4s	v0, #0x3f, msl #16
      fc:      	fneg.4s	v0, v0
     100:      	str	q0, [sp, #0x60]
     104:      	ldp	w9, w8, [x2, #0x2c]
     108:      	stp	w8, w9, [sp, #0x38]
     10c:      	ldp	w8, w9, [x2]
     110:      	ldp	w10, w11, [x2, #0x8]
     114:      	str	x2, [sp, #0x8]
     118:      	str	x11, [sp, #0x30]
     11c:      	b	0x168 <ltmp0+0x168>
     120:      	ldr	x15, [sp, #0x50]
     124:      	add	w8, w15, #0x1
     128:      	ldp	w11, w9, [sp, #0x38]
     12c:      	cmp	w8, w9
     130:      	cset	w9, eq
     134:      	csinc	w8, wzr, w15, eq
     138:      	ldp	w14, w13, [sp, #0x44]
     13c:      	cinc	w10, w14, eq
     140:      	cmp	w10, w11
     144:      	cset	w11, eq
     148:      	ands	w11, w9, w11
     14c:      	csel	w9, wzr, w10, ne
     150:      	add	w10, w13, w11
     154:      	ldr	w12, [sp, #0x4c]
     158:      	add	w12, w12, #0x1
     15c:      	ldr	w11, [sp, #0x40]
     160:      	cmp	w12, w11
     164:      	b.eq	0x1f2c <ltmp0+0x1f2c>
     168:      	str	w12, [sp, #0x4c]
     16c:      	mov	x13, x10
     170:      	mov	x14, x9
     174:      	mov	x15, x8
     178:      	ubfiz	x8, x8, #5, #32
     17c:      	ldr	x12, [sp, #0x30]
     180:      	cmp	x8, x12
     184:      	csel	x9, x8, xzr, ls
     188:      	subs	x10, x12, x9
     18c:      	cmp	x10, #0x20
     190:      	mov	w11, #0x20              ; =32
     194:      	csel	x10, x10, x11, lo
     198:      	cmp	x12, x9
     19c:      	ccmp	x8, x12, #0x2, hi
     1a0:      	csel	x9, x10, xzr, ls
     1a4:      	mov	w8, #-0x3d300000        ; =-1026555904
     1a8:      	dup.4s	v1, w8
     1ac:      	mov	w8, #0x42c80000         ; =1120403456
     1b0:      	dup.4s	v0, w8
     1b4:      	stp	q0, q1, [sp, #0x140]
     1b8:      	mov	w8, #0xaa3b             ; =43579
     1bc:      	movk	w8, #0x3fb8, lsl #16
     1c0:      	dup.4s	v1, w8
     1c4:      	mov	w8, #0x7200             ; =29184
     1c8:      	movk	w8, #0xbf31, lsl #16
     1cc:      	dup.4s	v0, w8
     1d0:      	stp	q0, q1, [sp, #0x120]
     1d4:      	mov	w8, #0xbe8e             ; =48782
     1d8:      	movk	w8, #0xb5bf, lsl #16
     1dc:      	dup.4s	v1, w8
     1e0:      	mov	w8, #0x2bda             ; =11226
     1e4:      	movk	w8, #0x3950, lsl #16
     1e8:      	dup.4s	v0, w8
     1ec:      	stp	q0, q1, [sp, #0x1b0]
     1f0:      	mov	w8, #0x96c9             ; =38601
     1f4:      	movk	w8, #0x3ab6, lsl #16
     1f8:      	dup.4s	v1, w8
     1fc:      	mov	w8, #0x88a6             ; =34982
     200:      	movk	w8, #0x3c08, lsl #16
     204:      	dup.4s	v0, w8
     208:      	stp	q0, q1, [sp, #0x190]
     20c:      	mov	w8, #0xaa7a             ; =43642
     210:      	movk	w8, #0x3d2a, lsl #16
     214:      	dup.4s	v1, w8
     218:      	mov	w8, #0xaaab             ; =43691
     21c:      	movk	w8, #0x3e2a, lsl #16
     220:      	dup.4s	v0, w8
     224:      	stp	q0, q1, [sp, #0x170]
     228:      	fmov.4s	v0, #1.00000000
     22c:      	str	q0, [sp, #0x160]
     230:      	cmp	x9, #0x20
     234:      	str	x15, [sp, #0x50]
     238:      	stp	w14, w13, [sp, #0x44]
     23c:      	b.lo	0x7d0 <ltmp0+0x7d0>
     240:      	mov	x21, #0x0               ; =0
     244:      	ldr	x8, [sp, #0x20]
     248:      	ldr	x22, [x8]
     24c:      	ldr	x8, [x8, #0x30]
     250:      	lsl	w25, w15, #2
     254:      	and	x9, x15, #0x7ffffff
     258:      	mov	w10, #0x3000            ; =12288
     25c:      	umaddl	x27, w9, w10, x8
     260:      	add	w8, w21, w25
     264:      	and	x28, x8, #0x1fffffff
     268:      	mov	w8, #0xc00              ; =3072
     26c:      	umaddl	x1, w28, w8, x22
     270:      	add	x0, sp, #0x3, lsl #12   ; =0x3000
     274:      	add	x0, x0, #0xa60
     278:      	mov	w2, #0xc00              ; =3072
     27c:      	bl	0x27c <ltmp0+0x27c>
     280:      	mov	x8, #0x0                ; =0
     284:      	add	x9, sp, #0x2, lsl #12   ; =0x2000
     288:      	add	x9, x9, #0x260
     28c:      	ldp	q5, q4, [sp, #0xf0]
     290:      	ldp	q7, q6, [sp, #0xd0]
     294:      	dup.2d	v0, x8
     298:      	orr.16b	v1, v0, v4
     29c:      	orr.16b	v2, v0, v5
     2a0:      	orr.16b	v3, v0, v6
     2a4:      	orr.16b	v0, v0, v7
     2a8:      	stp	q3, q0, [x9, #0x20]
     2ac:      	stp	q1, q2, [x9], #0x40
     2b0:      	add	x8, x8, #0x8
     2b4:      	cmp	x8, #0x300
     2b8:      	b.ne	0x294 <ltmp0+0x294>
     2bc:      	mov	x8, #0x0                ; =0
     2c0:      	mov	w9, #0xaaab             ; =43691
     2c4:      	movk	w9, #0xaaa, lsl #16
     2c8:      	umull	x9, w28, w9
     2cc:      	lsr	x9, x9, #37
     2d0:      	mov	w10, #0x300             ; =768
     2d4:      	msub	w9, w9, w10, w28
     2d8:      	dup.2s	v0, w9
     2dc:      	ushll.2d	v0, v0, #0x0
     2e0:      	ldp	q20, q19, [sp, #0xb0]
     2e4:      	ldp	q22, q21, [sp, #0x90]
     2e8:      	ldr	q23, [sp, #0x80]
     2ec:      	ldr	q16, [sp, #0x110]
     2f0:      	dup.2d	v1, x8
     2f4:      	add	x9, x20, x8, lsl #6
     2f8:      	ldp	q3, q2, [x9, #0x20]
     2fc:      	ldp	q4, q5, [x9]
     300:      	add.2d	v1, v1, v19
     304:      	add.2d	v6, v1, v21
     308:      	add.2d	v7, v1, v20
     30c:      	cmge.2d	v5, v0, v5
     310:      	cmge.2d	v4, v0, v4
     314:      	uzp1.4s	v4, v4, v5
     318:      	cmge.2d	v3, v0, v3
     31c:      	cmge.2d	v2, v0, v2
     320:      	uzp1.4s	v2, v3, v2
     324:      	uzp1.8h	v2, v4, v2
     328:      	xtn.8b	v2, v2
     32c:      	and.8b	v2, v2, v9
     330:      	mov.d	x9, v7[1]
     334:      	fmov	x10, d7
     338:      	str	b2, [x10]
     33c:      	st1.b	{ v2 }[1], [x9]
     340:      	mov.d	x9, v6[1]
     344:      	fmov	x10, d6
     348:      	st1.b	{ v2 }[2], [x10]
     34c:      	st1.b	{ v2 }[3], [x9]
     350:      	add.2d	v3, v1, v22
     354:      	mov.d	x9, v3[1]
     358:      	fmov	x10, d3
     35c:      	st1.b	{ v2 }[4], [x10]
     360:      	add.2d	v1, v1, v23
     364:      	st1.b	{ v2 }[5], [x9]
     368:      	mov.d	x9, v1[1]
     36c:      	fmov	x10, d1
     370:      	st1.b	{ v2 }[6], [x10]
     374:      	st1.b	{ v2 }[7], [x9]
     378:      	add	x8, x8, #0x1
     37c:      	cmp	x8, #0x60
     380:      	b.ne	0x2f0 <ltmp0+0x2f0>
     384:      	mov	x8, #0x0                ; =0
     388:      	movi.4s	v24, #0x4b, lsl #24
     38c:      	mvni.4s	v25, #0x80, lsl #24
     390:      	movi.4s	v26, #0x3f, lsl #24
     394:      	ldp	q28, q27, [sp, #0x60]
     398:      	ldp	q30, q29, [sp, #0x140]
     39c:      	ldp	q10, q31, [sp, #0x120]
     3a0:      	ldp	q12, q11, [sp, #0x1b0]
     3a4:      	ldp	q14, q13, [sp, #0x190]
     3a8:      	ldr	q15, [sp, #0x180]
     3ac:      	dup.2d	v0, x8
     3b0:      	add.2d	v0, v0, v19
     3b4:      	add.2d	v1, v0, v23
     3b8:      	add.2d	v2, v0, v20
     3bc:      	mov.d	x9, v2[1]
     3c0:      	add.2d	v3, v0, v22
     3c4:      	add.2d	v0, v0, v21
     3c8:      	fmov	x10, d2
     3cc:      	mov.d	x11, v0[1]
     3d0:      	mov.d	x12, v3[1]
     3d4:      	fmov	x13, d0
     3d8:      	ldr	b0, [x10]
     3dc:      	ld1.b	{ v0 }[1], [x9]
     3e0:      	mov.d	x9, v1[1]
     3e4:      	fmov	x10, d3
     3e8:      	ld1.b	{ v0 }[2], [x13]
     3ec:      	ld1.b	{ v0 }[3], [x11]
     3f0:      	fmov	x11, d1
     3f4:      	ld1.b	{ v0 }[4], [x10]
     3f8:      	ld1.b	{ v0 }[5], [x12]
     3fc:      	ld1.b	{ v0 }[6], [x11]
     400:      	ld1.b	{ v0 }[7], [x9]
     404:      	cmeq.8b	v0, v0, #0
     408:      	sshll.8h	v0, v0, #0x0
     40c:      	sshll2.4s	v1, v0, #0x0
     410:      	sshll.4s	v0, v0, #0x0
     414:      	lsl	x9, x8, #5
     418:      	add	x10, x19, x9
     41c:      	ldp	q3, q2, [x10]
     420:      	bsl.16b	v0, v16, v3
     424:      	bsl.16b	v1, v16, v2
     428:      	add	x9, x24, x9
     42c:      	stp	q0, q1, [x9]
     430:      	add	x8, x8, #0x1
     434:      	cmp	x8, #0x60
     438:      	b.ne	0x3ac <ltmp0+0x3ac>
     43c:      	mov	x8, #0x0                ; =0
     440:      	ldr	q0, [x23, #0x1110]
     444:      	ldr	q3, [x23, #0x1100]
     448:      	ldr	q2, [x23, #0x1130]
     44c:      	ldr	q7, [x23, #0x1120]
     450:      	ldr	q5, [x23, #0x1150]
     454:      	ldr	q4, [x23, #0x1140]
     458:      	ldr	q1, [x23, #0x1170]
     45c:      	ldr	q6, [x23, #0x1160]
     460:      	add	x9, x24, x8, lsl #5
     464:      	ldp	q16, q17, [x9, #0x80]
     468:      	fmaxnm.4s	v0, v0, v17
     46c:      	fmaxnm.4s	v3, v3, v16
     470:      	ldp	q16, q17, [x9, #0xa0]
     474:      	fmaxnm.4s	v2, v2, v17
     478:      	fmaxnm.4s	v7, v7, v16
     47c:      	ldp	q16, q17, [x9, #0xc0]
     480:      	fmaxnm.4s	v5, v5, v17
     484:      	fmaxnm.4s	v4, v4, v16
     488:      	ldp	q16, q17, [x9, #0xe0]
     48c:      	fmaxnm.4s	v1, v1, v17
     490:      	fmaxnm.4s	v6, v6, v16
     494:      	add	x8, x8, #0x4
     498:      	cmp	x8, #0x5c
     49c:      	b.lo	0x460 <ltmp0+0x460>
     4a0:      	mov	x8, #0x0                ; =0
     4a4:      	fmaxnm.4s	v3, v3, v7
     4a8:      	fmaxnm.4s	v0, v0, v2
     4ac:      	fmaxnm.4s	v0, v0, v5
     4b0:      	fmaxnm.4s	v2, v3, v4
     4b4:      	fmaxnm.4s	v2, v2, v6
     4b8:      	fmaxnm.4s	v0, v0, v1
     4bc:      	rev64.4s	v1, v0
     4c0:      	rev64.4s	v3, v2
     4c4:      	fmaxnm.4s	v2, v2, v3
     4c8:      	fmaxnm.4s	v0, v0, v1
     4cc:      	ext.16b	v1, v0, v0, #0x8
     4d0:      	ext.16b	v3, v2, v2, #0x8
     4d4:      	fmaxnm.4s	v2, v2, v3
     4d8:      	fmaxnm.4s	v0, v0, v1
     4dc:      	fmaxnm.4s	v0, v2, v0
     4e0:      	mov	w9, #-0x800000          ; =-8388608
     4e4:      	fmov	s1, w9
     4e8:      	fmaxnm	s0, s0, s1
     4ec:      	dup.4s	v0, v0[0]
     4f0:      	ldp	q8, q9, [sp, #0x160]
     4f4:      	dup.2d	v1, x8
     4f8:      	add.2d	v3, v1, v19
     4fc:      	add.2d	v4, v3, v21
     500:      	add.2d	v1, v3, v20
     504:      	mov.d	x9, v1[1]
     508:      	lsl	x10, x8, #5
     50c:      	fmov	x11, d1
     510:      	add	x12, x24, x10
     514:      	ldp	q1, q2, [x12]
     518:      	fsub.4s	v2, v2, v0
     51c:      	mov.d	x12, v4[1]
     520:      	fsub.4s	v1, v1, v0
     524:      	fcmge.4s	v5, v1, v29
     528:      	fcmge.4s	v6, v2, v29
     52c:      	fcmge.4s	v7, v30, v1
     530:      	fcmge.4s	v16, v30, v2
     534:      	and.16b	v6, v6, v16
     538:      	and.16b	v5, v5, v7
     53c:      	and.16b	v5, v5, v1
     540:      	and.16b	v6, v6, v2
     544:      	fmul.4s	v7, v6, v31
     548:      	fmul.4s	v16, v5, v31
     54c:      	mov.16b	v17, v25
     550:      	bsl.16b	v17, v24, v16
     554:      	mov.16b	v18, v25
     558:      	bsl.16b	v18, v24, v7
     55c:      	fadd.4s	v7, v7, v18
     560:      	fadd.4s	v16, v16, v17
     564:      	fsub.4s	v16, v16, v17
     568:      	fsub.4s	v7, v7, v18
     56c:      	fmov	x16, d4
     570:      	fcvtzs.4s	v4, v7
     574:      	fcvtzs.4s	v7, v16
     578:      	scvtf.4s	v16, v7
     57c:      	scvtf.4s	v17, v4
     580:      	fmul.4s	v18, v16, v10
     584:      	fadd.4s	v5, v5, v18
     588:      	fmul.4s	v18, v17, v10
     58c:      	fadd.4s	v6, v6, v18
     590:      	add.2d	v18, v3, v22
     594:      	mov.d	x14, v18[1]
     598:      	fmov	x15, d18
     59c:      	add.2d	v3, v3, v23
     5a0:      	mov.d	x13, v3[1]
     5a4:      	fmul.4s	v16, v16, v11
     5a8:      	fmul.4s	v17, v17, v11
     5ac:      	fadd.4s	v6, v6, v17
     5b0:      	fadd.4s	v5, v5, v16
     5b4:      	fmul.4s	v16, v5, v12
     5b8:      	fmul.4s	v17, v6, v12
     5bc:      	fadd.4s	v17, v17, v13
     5c0:      	fadd.4s	v16, v16, v13
     5c4:      	fmul.4s	v16, v5, v16
     5c8:      	fmul.4s	v17, v6, v17
     5cc:      	fadd.4s	v17, v17, v14
     5d0:      	fadd.4s	v16, v16, v14
     5d4:      	fmul.4s	v16, v5, v16
     5d8:      	fmul.4s	v17, v6, v17
     5dc:      	fadd.4s	v17, v17, v15
     5e0:      	fadd.4s	v16, v16, v15
     5e4:      	fmul.4s	v16, v5, v16
     5e8:      	fmul.4s	v17, v6, v17
     5ec:      	fadd.4s	v17, v17, v9
     5f0:      	fadd.4s	v16, v16, v9
     5f4:      	fmov	x17, d3
     5f8:      	fmul.4s	v3, v5, v16
     5fc:      	fmul.4s	v16, v6, v17
     600:      	fadd.4s	v16, v16, v26
     604:      	fadd.4s	v3, v3, v26
     608:      	fmul.4s	v17, v5, v5
     60c:      	fmul.4s	v3, v17, v3
     610:      	fmul.4s	v17, v6, v6
     614:      	fmul.4s	v16, v17, v16
     618:      	fadd.4s	v6, v6, v16
     61c:      	fadd.4s	v3, v5, v3
     620:      	sshr.4s	v5, v7, #0x1
     624:      	fadd.4s	v6, v6, v8
     628:      	sshr.4s	v16, v4, #0x1
     62c:      	shl.4s	v17, v16, #0x17
     630:      	add.4s	v17, v17, v8
     634:      	fmul.4s	v6, v6, v17
     638:      	shl.4s	v17, v5, #0x17
     63c:      	fadd.4s	v3, v3, v8
     640:      	add.4s	v17, v17, v8
     644:      	fmul.4s	v3, v3, v17
     648:      	sub.4s	v4, v4, v16
     64c:      	sub.4s	v5, v7, v5
     650:      	shl.4s	v5, v5, #0x17
     654:      	add.4s	v5, v5, v8
     658:      	fmul.4s	v3, v3, v5
     65c:      	ldr	b5, [x11]
     660:      	ld1.b	{ v5 }[1], [x9]
     664:      	ld1.b	{ v5 }[2], [x16]
     668:      	ld1.b	{ v5 }[3], [x12]
     66c:      	shl.4s	v4, v4, #0x17
     670:      	add.4s	v4, v4, v8
     674:      	fmul.4s	v4, v6, v4
     678:      	fcmgt.4s	v6, v29, v2
     67c:      	bic.16b	v4, v4, v6
     680:      	fcmgt.4s	v6, v29, v1
     684:      	bic.16b	v3, v3, v6
     688:      	fcmgt.4s	v6, v1, v30
     68c:      	bit.16b	v3, v27, v6
     690:      	fcmgt.4s	v6, v2, v30
     694:      	bit.16b	v4, v27, v6
     698:      	ld1.b	{ v5 }[4], [x15]
     69c:      	ld1.b	{ v5 }[5], [x14]
     6a0:      	fcmeq.4s	v2, v2, v2
     6a4:      	bsl.16b	v2, v4, v28
     6a8:      	ld1.b	{ v5 }[6], [x17]
     6ac:      	ld1.b	{ v5 }[7], [x13]
     6b0:      	cmeq.8b	v4, v5, #0
     6b4:      	sshll.8h	v4, v4, #0x0
     6b8:      	fcmeq.4s	v1, v1, v1
     6bc:      	bsl.16b	v1, v3, v28
     6c0:      	sshll.4s	v3, v4, #0x0
     6c4:      	bic.16b	v1, v1, v3
     6c8:      	sshll2.4s	v3, v4, #0x0
     6cc:      	bic.16b	v2, v2, v3
     6d0:      	add	x9, x26, x10
     6d4:      	stp	q1, q2, [x9]
     6d8:      	add	x8, x8, #0x1
     6dc:      	cmp	x8, #0x60
     6e0:      	b.ne	0x4f4 <ltmp0+0x4f4>
     6e4:      	mov	x8, #0x0                ; =0
     6e8:      	ldr	q0, [x23, #0x510]
     6ec:      	ldr	q3, [x23, #0x500]
     6f0:      	ldr	q2, [x23, #0x530]
     6f4:      	ldr	q7, [x23, #0x520]
     6f8:      	ldr	q5, [x23, #0x550]
     6fc:      	ldr	q4, [x23, #0x540]
     700:      	ldr	q1, [x23, #0x570]
     704:      	ldr	q6, [x23, #0x560]
     708:      	add	x9, x26, x8, lsl #5
     70c:      	ldp	q16, q17, [x9, #0x80]
     710:      	fadd.4s	v0, v0, v17
     714:      	fadd.4s	v3, v3, v16
     718:      	ldp	q16, q17, [x9, #0xa0]
     71c:      	fadd.4s	v2, v2, v17
     720:      	fadd.4s	v7, v7, v16
     724:      	ldp	q16, q17, [x9, #0xc0]
     728:      	fadd.4s	v5, v5, v17
     72c:      	fadd.4s	v4, v4, v16
     730:      	ldp	q16, q17, [x9, #0xe0]
     734:      	fadd.4s	v1, v1, v17
     738:      	fadd.4s	v6, v6, v16
     73c:      	add	x8, x8, #0x4
     740:      	cmp	x8, #0x5c
     744:      	b.lo	0x708 <ltmp0+0x708>
     748:      	mov	x8, #0x0                ; =0
     74c:      	fadd.4s	v3, v3, v7
     750:      	fadd.4s	v0, v0, v2
     754:      	fadd.4s	v0, v0, v5
     758:      	fadd.4s	v2, v3, v4
     75c:      	fadd.4s	v2, v2, v6
     760:      	fadd.4s	v0, v0, v1
     764:      	rev64.4s	v1, v0
     768:      	rev64.4s	v3, v2
     76c:      	fadd.4s	v2, v2, v3
     770:      	fadd.4s	v0, v0, v1
     774:      	dup.4s	v1, v0[2]
     778:      	dup.4s	v3, v2[2]
     77c:      	fadd.4s	v2, v2, v3
     780:      	fadd.4s	v0, v0, v1
     784:      	fadd.4s	v0, v2, v0
     788:      	movi	d1, #0000000000000000
     78c:      	fadd	s0, s0, s1
     790:      	dup.4s	v0, v0[0]
     794:      	movi.8b	v9, #0x1
     798:      	add	x9, x26, x8
     79c:      	ldp	q2, q1, [x9]
     7a0:      	fdiv.4s	v2, v2, v0
     7a4:      	fdiv.4s	v1, v1, v0
     7a8:      	add	x9, x27, x8
     7ac:      	stp	q2, q1, [x9]
     7b0:      	add	x8, x8, #0x20
     7b4:      	cmp	x8, #0xc00
     7b8:      	b.ne	0x798 <ltmp0+0x798>
     7bc:      	add	x21, x21, #0x1
     7c0:      	add	x27, x27, #0xc00
     7c4:      	cmp	x21, #0x4
     7c8:      	b.ne	0x260 <ltmp0+0x260>
     7cc:      	b	0x120 <ltmp0+0x120>
     7d0:      	lsr	x8, x9, #3
     7d4:      	str	x8, [sp, #0x58]
     7d8:      	str	x9, [sp, #0x28]
     7dc:      	cmp	x9, #0x8
     7e0:      	b.lo	0xd78 <ltmp0+0xd78>
     7e4:      	mov	x28, #0x0               ; =0
     7e8:      	ldr	x8, [sp, #0x20]
     7ec:      	ldr	x27, [x8]
     7f0:      	ldr	x8, [x8, #0x30]
     7f4:      	ldr	x9, [sp, #0x50]
     7f8:      	lsl	w21, w9, #2
     7fc:      	and	x9, x9, #0x7ffffff
     800:      	mov	w10, #0x3000            ; =12288
     804:      	umaddl	x25, w9, w10, x8
     808:      	add	w8, w28, w21
     80c:      	and	x22, x8, #0x1fffffff
     810:      	mov	w8, #0xc00              ; =3072
     814:      	umaddl	x1, w22, w8, x27
     818:      	add	x0, sp, #0x3, lsl #12   ; =0x3000
     81c:      	add	x0, x0, #0xa60
     820:      	mov	w2, #0xc00              ; =3072
     824:      	bl	0x824 <ltmp0+0x824>
     828:      	mov	x8, #0x0                ; =0
     82c:      	add	x9, sp, #0x2, lsl #12   ; =0x2000
     830:      	add	x9, x9, #0x260
     834:      	ldp	q5, q4, [sp, #0xf0]
     838:      	ldp	q7, q6, [sp, #0xd0]
     83c:      	dup.2d	v0, x8
     840:      	orr.16b	v1, v0, v4
     844:      	orr.16b	v2, v0, v5
     848:      	orr.16b	v3, v0, v6
     84c:      	orr.16b	v0, v0, v7
     850:      	stp	q3, q0, [x9, #0x20]
     854:      	stp	q1, q2, [x9], #0x40
     858:      	add	x8, x8, #0x8
     85c:      	cmp	x8, #0x300
     860:      	b.ne	0x83c <ltmp0+0x83c>
     864:      	mov	x8, #0x0                ; =0
     868:      	mov	w9, #0xaaab             ; =43691
     86c:      	movk	w9, #0xaaa, lsl #16
     870:      	umull	x9, w22, w9
     874:      	lsr	x9, x9, #37
     878:      	mov	w10, #0x300             ; =768
     87c:      	msub	w9, w9, w10, w22
     880:      	dup.2s	v0, w9
     884:      	ushll.2d	v0, v0, #0x0
     888:      	ldp	q20, q19, [sp, #0xb0]
     88c:      	ldp	q22, q21, [sp, #0x90]
     890:      	ldr	q23, [sp, #0x80]
     894:      	ldr	q16, [sp, #0x110]
     898:      	dup.2d	v1, x8
     89c:      	add	x9, x20, x8, lsl #6
     8a0:      	ldp	q3, q2, [x9, #0x20]
     8a4:      	ldp	q4, q5, [x9]
     8a8:      	add.2d	v1, v1, v19
     8ac:      	add.2d	v6, v1, v21
     8b0:      	add.2d	v7, v1, v20
     8b4:      	cmge.2d	v5, v0, v5
     8b8:      	cmge.2d	v4, v0, v4
     8bc:      	uzp1.4s	v4, v4, v5
     8c0:      	cmge.2d	v3, v0, v3
     8c4:      	cmge.2d	v2, v0, v2
     8c8:      	uzp1.4s	v2, v3, v2
     8cc:      	uzp1.8h	v2, v4, v2
     8d0:      	xtn.8b	v2, v2
     8d4:      	and.8b	v2, v2, v9
     8d8:      	mov.d	x9, v7[1]
     8dc:      	fmov	x10, d7
     8e0:      	str	b2, [x10]
     8e4:      	st1.b	{ v2 }[1], [x9]
     8e8:      	mov.d	x9, v6[1]
     8ec:      	fmov	x10, d6
     8f0:      	st1.b	{ v2 }[2], [x10]
     8f4:      	st1.b	{ v2 }[3], [x9]
     8f8:      	add.2d	v3, v1, v22
     8fc:      	mov.d	x9, v3[1]
     900:      	fmov	x10, d3
     904:      	st1.b	{ v2 }[4], [x10]
     908:      	add.2d	v1, v1, v23
     90c:      	st1.b	{ v2 }[5], [x9]
     910:      	mov.d	x9, v1[1]
     914:      	fmov	x10, d1
     918:      	st1.b	{ v2 }[6], [x10]
     91c:      	st1.b	{ v2 }[7], [x9]
     920:      	add	x8, x8, #0x1
     924:      	cmp	x8, #0x60
     928:      	b.ne	0x898 <ltmp0+0x898>
     92c:      	mov	x8, #0x0                ; =0
     930:      	movi.4s	v24, #0x4b, lsl #24
     934:      	mvni.4s	v25, #0x80, lsl #24
     938:      	movi.4s	v26, #0x3f, lsl #24
     93c:      	ldp	q28, q27, [sp, #0x60]
     940:      	ldp	q30, q29, [sp, #0x140]
     944:      	ldp	q10, q31, [sp, #0x120]
     948:      	ldp	q12, q11, [sp, #0x1b0]
     94c:      	ldp	q14, q13, [sp, #0x190]
     950:      	ldr	q15, [sp, #0x180]
     954:      	dup.2d	v0, x8
     958:      	add.2d	v0, v0, v19
     95c:      	add.2d	v1, v0, v23
     960:      	add.2d	v2, v0, v20
     964:      	mov.d	x9, v2[1]
     968:      	add.2d	v3, v0, v22
     96c:      	add.2d	v0, v0, v21
     970:      	fmov	x10, d2
     974:      	mov.d	x11, v0[1]
     978:      	mov.d	x12, v3[1]
     97c:      	fmov	x13, d0
     980:      	ldr	b0, [x10]
     984:      	ld1.b	{ v0 }[1], [x9]
     988:      	mov.d	x9, v1[1]
     98c:      	fmov	x10, d3
     990:      	ld1.b	{ v0 }[2], [x13]
     994:      	ld1.b	{ v0 }[3], [x11]
     998:      	fmov	x11, d1
     99c:      	ld1.b	{ v0 }[4], [x10]
     9a0:      	ld1.b	{ v0 }[5], [x12]
     9a4:      	ld1.b	{ v0 }[6], [x11]
     9a8:      	ld1.b	{ v0 }[7], [x9]
     9ac:      	cmeq.8b	v0, v0, #0
     9b0:      	sshll.8h	v0, v0, #0x0
     9b4:      	sshll2.4s	v1, v0, #0x0
     9b8:      	sshll.4s	v0, v0, #0x0
     9bc:      	lsl	x9, x8, #5
     9c0:      	add	x10, x19, x9
     9c4:      	ldp	q3, q2, [x10]
     9c8:      	bsl.16b	v0, v16, v3
     9cc:      	bsl.16b	v1, v16, v2
     9d0:      	add	x9, x24, x9
     9d4:      	stp	q0, q1, [x9]
     9d8:      	add	x8, x8, #0x1
     9dc:      	cmp	x8, #0x60
     9e0:      	b.ne	0x954 <ltmp0+0x954>
     9e4:      	mov	x8, #0x0                ; =0
     9e8:      	ldr	q0, [x23, #0x1110]
     9ec:      	ldr	q3, [x23, #0x1100]
     9f0:      	ldr	q2, [x23, #0x1130]
     9f4:      	ldr	q7, [x23, #0x1120]
     9f8:      	ldr	q5, [x23, #0x1150]
     9fc:      	ldr	q4, [x23, #0x1140]
     a00:      	ldr	q1, [x23, #0x1170]
     a04:      	ldr	q6, [x23, #0x1160]
     a08:      	add	x9, x24, x8, lsl #5
     a0c:      	ldp	q16, q17, [x9, #0x80]
     a10:      	fmaxnm.4s	v0, v0, v17
     a14:      	fmaxnm.4s	v3, v3, v16
     a18:      	ldp	q16, q17, [x9, #0xa0]
     a1c:      	fmaxnm.4s	v2, v2, v17
     a20:      	fmaxnm.4s	v7, v7, v16
     a24:      	ldp	q16, q17, [x9, #0xc0]
     a28:      	fmaxnm.4s	v5, v5, v17
     a2c:      	fmaxnm.4s	v4, v4, v16
     a30:      	ldp	q16, q17, [x9, #0xe0]
     a34:      	fmaxnm.4s	v1, v1, v17
     a38:      	fmaxnm.4s	v6, v6, v16
     a3c:      	add	x8, x8, #0x4
     a40:      	cmp	x8, #0x5c
     a44:      	b.lo	0xa08 <ltmp0+0xa08>
     a48:      	mov	x8, #0x0                ; =0
     a4c:      	fmaxnm.4s	v3, v3, v7
     a50:      	fmaxnm.4s	v0, v0, v2
     a54:      	fmaxnm.4s	v0, v0, v5
     a58:      	fmaxnm.4s	v2, v3, v4
     a5c:      	fmaxnm.4s	v2, v2, v6
     a60:      	fmaxnm.4s	v0, v0, v1
     a64:      	rev64.4s	v1, v0
     a68:      	rev64.4s	v3, v2
     a6c:      	fmaxnm.4s	v2, v2, v3
     a70:      	fmaxnm.4s	v0, v0, v1
     a74:      	ext.16b	v1, v0, v0, #0x8
     a78:      	ext.16b	v3, v2, v2, #0x8
     a7c:      	fmaxnm.4s	v2, v2, v3
     a80:      	fmaxnm.4s	v0, v0, v1
     a84:      	fmaxnm.4s	v0, v2, v0
     a88:      	mov	w9, #-0x800000          ; =-8388608
     a8c:      	fmov	s1, w9
     a90:      	fmaxnm	s0, s0, s1
     a94:      	dup.4s	v0, v0[0]
     a98:      	ldp	q8, q9, [sp, #0x160]
     a9c:      	dup.2d	v1, x8
     aa0:      	add.2d	v3, v1, v19
     aa4:      	add.2d	v4, v3, v21
     aa8:      	add.2d	v1, v3, v20
     aac:      	mov.d	x9, v1[1]
     ab0:      	lsl	x10, x8, #5
     ab4:      	fmov	x11, d1
     ab8:      	add	x12, x24, x10
     abc:      	ldp	q1, q2, [x12]
     ac0:      	fsub.4s	v2, v2, v0
     ac4:      	mov.d	x12, v4[1]
     ac8:      	fsub.4s	v1, v1, v0
     acc:      	fcmge.4s	v5, v1, v29
     ad0:      	fcmge.4s	v6, v2, v29
     ad4:      	fcmge.4s	v7, v30, v1
     ad8:      	fcmge.4s	v16, v30, v2
     adc:      	and.16b	v6, v6, v16
     ae0:      	and.16b	v5, v5, v7
     ae4:      	and.16b	v5, v5, v1
     ae8:      	and.16b	v6, v6, v2
     aec:      	fmul.4s	v7, v6, v31
     af0:      	fmul.4s	v16, v5, v31
     af4:      	mov.16b	v17, v25
     af8:      	bsl.16b	v17, v24, v16
     afc:      	mov.16b	v18, v25
     b00:      	bsl.16b	v18, v24, v7
     b04:      	fadd.4s	v7, v7, v18
     b08:      	fadd.4s	v16, v16, v17
     b0c:      	fsub.4s	v16, v16, v17
     b10:      	fsub.4s	v7, v7, v18
     b14:      	fmov	x16, d4
     b18:      	fcvtzs.4s	v4, v7
     b1c:      	fcvtzs.4s	v7, v16
     b20:      	scvtf.4s	v16, v7
     b24:      	scvtf.4s	v17, v4
     b28:      	fmul.4s	v18, v16, v10
     b2c:      	fadd.4s	v5, v5, v18
     b30:      	fmul.4s	v18, v17, v10
     b34:      	fadd.4s	v6, v6, v18
     b38:      	add.2d	v18, v3, v22
     b3c:      	mov.d	x14, v18[1]
     b40:      	fmov	x15, d18
     b44:      	add.2d	v3, v3, v23
     b48:      	mov.d	x13, v3[1]
     b4c:      	fmul.4s	v16, v16, v11
     b50:      	fmul.4s	v17, v17, v11
     b54:      	fadd.4s	v6, v6, v17
     b58:      	fadd.4s	v5, v5, v16
     b5c:      	fmul.4s	v16, v5, v12
     b60:      	fmul.4s	v17, v6, v12
     b64:      	fadd.4s	v17, v17, v13
     b68:      	fadd.4s	v16, v16, v13
     b6c:      	fmul.4s	v16, v5, v16
     b70:      	fmul.4s	v17, v6, v17
     b74:      	fadd.4s	v17, v17, v14
     b78:      	fadd.4s	v16, v16, v14
     b7c:      	fmul.4s	v16, v5, v16
     b80:      	fmul.4s	v17, v6, v17
     b84:      	fadd.4s	v17, v17, v15
     b88:      	fadd.4s	v16, v16, v15
     b8c:      	fmul.4s	v16, v5, v16
     b90:      	fmul.4s	v17, v6, v17
     b94:      	fadd.4s	v17, v17, v9
     b98:      	fadd.4s	v16, v16, v9
     b9c:      	fmov	x17, d3
     ba0:      	fmul.4s	v3, v5, v16
     ba4:      	fmul.4s	v16, v6, v17
     ba8:      	fadd.4s	v16, v16, v26
     bac:      	fadd.4s	v3, v3, v26
     bb0:      	fmul.4s	v17, v5, v5
     bb4:      	fmul.4s	v3, v17, v3
     bb8:      	fmul.4s	v17, v6, v6
     bbc:      	fmul.4s	v16, v17, v16
     bc0:      	fadd.4s	v6, v6, v16
     bc4:      	fadd.4s	v3, v5, v3
     bc8:      	sshr.4s	v5, v7, #0x1
     bcc:      	fadd.4s	v6, v6, v8
     bd0:      	sshr.4s	v16, v4, #0x1
     bd4:      	shl.4s	v17, v16, #0x17
     bd8:      	add.4s	v17, v17, v8
     bdc:      	fmul.4s	v6, v6, v17
     be0:      	shl.4s	v17, v5, #0x17
     be4:      	fadd.4s	v3, v3, v8
     be8:      	add.4s	v17, v17, v8
     bec:      	fmul.4s	v3, v3, v17
     bf0:      	sub.4s	v4, v4, v16
     bf4:      	sub.4s	v5, v7, v5
     bf8:      	shl.4s	v5, v5, #0x17
     bfc:      	add.4s	v5, v5, v8
     c00:      	fmul.4s	v3, v3, v5
     c04:      	ldr	b5, [x11]
     c08:      	ld1.b	{ v5 }[1], [x9]
     c0c:      	ld1.b	{ v5 }[2], [x16]
     c10:      	ld1.b	{ v5 }[3], [x12]
     c14:      	shl.4s	v4, v4, #0x17
     c18:      	add.4s	v4, v4, v8
     c1c:      	fmul.4s	v4, v6, v4
     c20:      	fcmgt.4s	v6, v29, v2
     c24:      	bic.16b	v4, v4, v6
     c28:      	fcmgt.4s	v6, v29, v1
     c2c:      	bic.16b	v3, v3, v6
     c30:      	fcmgt.4s	v6, v1, v30
     c34:      	bit.16b	v3, v27, v6
     c38:      	fcmgt.4s	v6, v2, v30
     c3c:      	bit.16b	v4, v27, v6
     c40:      	ld1.b	{ v5 }[4], [x15]
     c44:      	ld1.b	{ v5 }[5], [x14]
     c48:      	fcmeq.4s	v2, v2, v2
     c4c:      	bsl.16b	v2, v4, v28
     c50:      	ld1.b	{ v5 }[6], [x17]
     c54:      	ld1.b	{ v5 }[7], [x13]
     c58:      	cmeq.8b	v4, v5, #0
     c5c:      	sshll.8h	v4, v4, #0x0
     c60:      	fcmeq.4s	v1, v1, v1
     c64:      	bsl.16b	v1, v3, v28
     c68:      	sshll.4s	v3, v4, #0x0
     c6c:      	bic.16b	v1, v1, v3
     c70:      	sshll2.4s	v3, v4, #0x0
     c74:      	bic.16b	v2, v2, v3
     c78:      	add	x9, x26, x10
     c7c:      	stp	q1, q2, [x9]
     c80:      	add	x8, x8, #0x1
     c84:      	cmp	x8, #0x60
     c88:      	b.ne	0xa9c <ltmp0+0xa9c>
     c8c:      	mov	x8, #0x0                ; =0
     c90:      	ldr	q0, [x23, #0x510]
     c94:      	ldr	q3, [x23, #0x500]
     c98:      	ldr	q2, [x23, #0x530]
     c9c:      	ldr	q7, [x23, #0x520]
     ca0:      	ldr	q5, [x23, #0x550]
     ca4:      	ldr	q4, [x23, #0x540]
     ca8:      	ldr	q1, [x23, #0x570]
     cac:      	ldr	q6, [x23, #0x560]
     cb0:      	add	x9, x26, x8, lsl #5
     cb4:      	ldp	q16, q17, [x9, #0x80]
     cb8:      	fadd.4s	v0, v0, v17
     cbc:      	fadd.4s	v3, v3, v16
     cc0:      	ldp	q16, q17, [x9, #0xa0]
     cc4:      	fadd.4s	v2, v2, v17
     cc8:      	fadd.4s	v7, v7, v16
     ccc:      	ldp	q16, q17, [x9, #0xc0]
     cd0:      	fadd.4s	v5, v5, v17
     cd4:      	fadd.4s	v4, v4, v16
     cd8:      	ldp	q16, q17, [x9, #0xe0]
     cdc:      	fadd.4s	v1, v1, v17
     ce0:      	fadd.4s	v6, v6, v16
     ce4:      	add	x8, x8, #0x4
     ce8:      	cmp	x8, #0x5c
     cec:      	b.lo	0xcb0 <ltmp0+0xcb0>
     cf0:      	mov	x8, #0x0                ; =0
     cf4:      	fadd.4s	v3, v3, v7
     cf8:      	fadd.4s	v0, v0, v2
     cfc:      	fadd.4s	v0, v0, v5
     d00:      	fadd.4s	v2, v3, v4
     d04:      	fadd.4s	v2, v2, v6
     d08:      	fadd.4s	v0, v0, v1
     d0c:      	rev64.4s	v1, v0
     d10:      	rev64.4s	v3, v2
     d14:      	fadd.4s	v2, v2, v3
     d18:      	fadd.4s	v0, v0, v1
     d1c:      	dup.4s	v1, v0[2]
     d20:      	dup.4s	v3, v2[2]
     d24:      	fadd.4s	v2, v2, v3
     d28:      	fadd.4s	v0, v0, v1
     d2c:      	fadd.4s	v0, v2, v0
     d30:      	movi	d1, #0000000000000000
     d34:      	fadd	s0, s0, s1
     d38:      	dup.4s	v0, v0[0]
     d3c:      	movi.8b	v9, #0x1
     d40:      	add	x9, x26, x8
     d44:      	ldp	q2, q1, [x9]
     d48:      	fdiv.4s	v2, v2, v0
     d4c:      	fdiv.4s	v1, v1, v0
     d50:      	add	x9, x25, x8
     d54:      	stp	q2, q1, [x9]
     d58:      	add	x8, x8, #0x20
     d5c:      	cmp	x8, #0xc00
     d60:      	b.ne	0xd40 <ltmp0+0xd40>
     d64:      	add	x28, x28, #0x1
     d68:      	add	x25, x25, #0xc00
     d6c:      	ldr	x8, [sp, #0x58]
     d70:      	cmp	x28, x8
     d74:      	b.ne	0x808 <ltmp0+0x808>
     d78:      	ldr	x8, [sp, #0x28]
     d7c:      	and	w8, w8, #0x7
     d80:      	ldr	q12, [sp, #0x110]
     d84:      	cbz	w8, 0x120 <ltmp0+0x120>
     d88:      	dup.4s	v3, w8
     d8c:      	adrp	x8, 0x0 <ltmp0>
     d90:      	ldr	q16, [x8]
     d94:      	adrp	x8, 0x0 <ltmp0>
     d98:      	ldr	q17, [x8]
     d9c:      	cmhi.4s	v0, v3, v17
     da0:      	cmhi.4s	v1, v3, v16
     da4:      	uzp1.8h	v7, v1, v0
     da8:      	umaxv.8h	h2, v7
     dac:      	fmov	w8, s2
     db0:      	ldp	q30, q29, [sp, #0xf0]
     db4:      	ldp	q10, q31, [sp, #0xd0]
     db8:      	ldr	x13, [sp, #0x50]
     dbc:      	tbz	w8, #0x0, 0x120 <ltmp0+0x120>
     dc0:      	mov	x11, #0x0               ; =0
     dc4:      	ldr	x12, [sp, #0x20]
     dc8:      	ldr	x8, [x12, #0x30]
     dcc:      	adrp	x9, 0x0 <ltmp0>
     dd0:      	ldr	q2, [x9]
     dd4:      	and.16b	v2, v7, v2
     dd8:      	addv.8h	h2, v2
     ddc:      	fmov	w9, s2
     de0:      	and	w10, w9, #0xff
     de4:      	ubfiz	w9, w13, #2, #27
     de8:      	ldr	x13, [sp, #0x58]
     dec:      	orr	w9, w9, w13
     df0:      	ldr	x12, [x12]
     df4:      	dup.4s	v5, w9
     df8:      	and.16b	v4, v1, v5
     dfc:      	fmov	w9, s4
     e00:      	mov	w13, #0xc00             ; =3072
     e04:      	umaddl	x12, w9, w13, x12
     e08:      	umull	x9, w9, w13
     e0c:      	ldr	q11, [sp, #0xb0]
     e10:      	b	0xe34 <ltmp0+0xe34>
     e14:      	add	x13, x19, x11
     e18:      	ldp	q19, q20, [x13]
     e1c:      	bif.16b	v18, v20, v0
     e20:      	bif.16b	v6, v19, v1
     e24:      	stp	q6, q18, [x13]
     e28:      	add	x11, x11, #0x20
     e2c:      	cmp	x11, #0xc00
     e30:      	b.eq	0xecc <ltmp0+0xecc>
     e34:      	fmov	w14, s2
     e38:      	add	x13, x12, x11
     e3c:      	movi.2d	v6, #0000000000000000
     e40:      	movi.2d	v18, #0000000000000000
     e44:      	tbnz	w14, #0x0, 0xe6c <ltmp0+0xe6c>
     e48:      	and	w14, w14, #0xff
     e4c:      	tbnz	w14, #0x1, 0xe78 <ltmp0+0xe78>
     e50:      	tbnz	w14, #0x2, 0xe84 <ltmp0+0xe84>
     e54:      	tbnz	w14, #0x3, 0xe90 <ltmp0+0xe90>
     e58:      	tbnz	w14, #0x4, 0xe9c <ltmp0+0xe9c>
     e5c:      	tbnz	w14, #0x5, 0xea8 <ltmp0+0xea8>
     e60:      	tbnz	w14, #0x6, 0xeb4 <ltmp0+0xeb4>
     e64:      	tbz	w14, #0x7, 0xe14 <ltmp0+0xe14>
     e68:      	b	0xec0 <ltmp0+0xec0>
     e6c:      	ldr	s6, [x13]
     e70:      	and	w14, w14, #0xff
     e74:      	tbz	w14, #0x1, 0xe50 <ltmp0+0xe50>
     e78:      	add	x15, x13, #0x4
     e7c:      	ld1.s	{ v6 }[1], [x15]
     e80:      	tbz	w14, #0x2, 0xe54 <ltmp0+0xe54>
     e84:      	add	x15, x13, #0x8
     e88:      	ld1.s	{ v6 }[2], [x15]
     e8c:      	tbz	w14, #0x3, 0xe58 <ltmp0+0xe58>
     e90:      	add	x15, x13, #0xc
     e94:      	ld1.s	{ v6 }[3], [x15]
     e98:      	tbz	w14, #0x4, 0xe5c <ltmp0+0xe5c>
     e9c:      	add	x15, x13, #0x10
     ea0:      	ld1.s	{ v18 }[0], [x15]
     ea4:      	tbz	w14, #0x5, 0xe60 <ltmp0+0xe60>
     ea8:      	add	x15, x13, #0x14
     eac:      	ld1.s	{ v18 }[1], [x15]
     eb0:      	tbz	w14, #0x6, 0xe64 <ltmp0+0xe64>
     eb4:      	add	x15, x13, #0x18
     eb8:      	ld1.s	{ v18 }[2], [x15]
     ebc:      	tbz	w14, #0x7, 0xe14 <ltmp0+0xe14>
     ec0:      	add	x13, x13, #0x1c
     ec4:      	ld1.s	{ v18 }[3], [x13]
     ec8:      	b	0xe14 <ltmp0+0xe14>
     ecc:      	mov	x11, #0x0               ; =0
     ed0:      	add	x12, sp, #0x2, lsl #12  ; =0x2000
     ed4:      	add	x12, x12, #0x260
     ed8:      	sshll2.2d	v6, v0, #0x0
     edc:      	sshll2.2d	v19, v1, #0x0
     ee0:      	sshll.2d	v18, v0, #0x0
     ee4:      	sshll.2d	v20, v1, #0x0
     ee8:      	dup.2d	v21, x11
     eec:      	orr.16b	v22, v21, v10
     ef0:      	orr.16b	v23, v21, v30
     ef4:      	orr.16b	v24, v21, v31
     ef8:      	orr.16b	v21, v21, v29
     efc:      	ldp	q26, q25, [x12, #0x20]
     f00:      	ldp	q28, q27, [x12]
     f04:      	bsl.16b	v20, v21, v28
     f08:      	bsl.16b	v18, v24, v26
     f0c:      	mov.16b	v21, v19
     f10:      	bsl.16b	v21, v23, v27
     f14:      	bif.16b	v22, v25, v6
     f18:      	stp	q18, q22, [x12, #0x20]
     f1c:      	stp	q20, q21, [x12], #0x40
     f20:      	add	x11, x11, #0x8
     f24:      	cmp	x11, #0x300
     f28:      	b.ne	0xed8 <ltmp0+0xed8>
     f2c:      	mov	x11, #0x0               ; =0
     f30:      	and.16b	v5, v0, v5
     f34:      	movi.4s	v21, #0x3, lsl #8
     f38:      	and.16b	v18, v0, v21
     f3c:      	mvn.16b	v20, v0
     f40:      	sub.4s	v18, v18, v20
     f44:      	and.16b	v20, v1, v21
     f48:      	mvn.16b	v21, v1
     f4c:      	sub.4s	v20, v20, v21
     f50:      	mov.s	w12, v20[1]
     f54:      	mov.s	w13, v4[1]
     f58:      	udiv	w14, w13, w12
     f5c:      	msub	w12, w14, w12, w13
     f60:      	mov.s	w13, v20[3]
     f64:      	mov.s	w14, v20[2]
     f68:      	fmov	w15, s20
     f6c:      	fmov	w16, s4
     f70:      	udiv	w17, w16, w15
     f74:      	msub	w15, w17, w15, w16
     f78:      	mov.s	w16, v4[3]
     f7c:      	udiv	w17, w16, w13
     f80:      	msub	w13, w17, w13, w16
     f84:      	mov.s	w16, v4[2]
     f88:      	udiv	w17, w16, w14
     f8c:      	msub	w14, w17, w14, w16
     f90:      	mov.s	w16, v18[1]
     f94:      	mov.s	w17, v5[1]
     f98:      	udiv	w0, w17, w16
     f9c:      	msub	w16, w0, w16, w17
     fa0:      	mov.s	w17, v18[3]
     fa4:      	mov.s	w0, v18[2]
     fa8:      	fmov	w1, s18
     fac:      	mov.s	w2, v5[3]
     fb0:      	mov.s	w3, v5[2]
     fb4:      	fmov	w4, s5
     fb8:      	udiv	w5, w4, w1
     fbc:      	msub	w1, w5, w1, w4
     fc0:      	udiv	w4, w2, w17
     fc4:      	msub	w17, w4, w17, w2
     fc8:      	udiv	w2, w3, w0
     fcc:      	msub	w0, w2, w0, w3
     fd0:      	sshll.2d	v4, v1, #0x0
     fd4:      	sshll.2d	v5, v0, #0x0
     fd8:      	fmov	s18, w0
     fdc:      	mov.s	v18[1], w17
     fe0:      	ushll.2d	v18, v18, #0x0
     fe4:      	fmov	s20, w1
     fe8:      	mov.s	v20[1], w16
     fec:      	fmov	s21, w14
     ff0:      	mov.s	v21[1], w13
     ff4:      	ushll.2d	v20, v20, #0x0
     ff8:      	ushll.2d	v21, v21, #0x0
     ffc:      	fmov	s22, w15
    1000:      	mov.s	v22[1], w12
    1004:      	ushll.2d	v22, v22, #0x0
    1008:      	ldr	q26, [sp, #0xc0]
    100c:      	and.16b	v23, v6, v26
    1010:      	and.16b	v24, v19, v26
    1014:      	and.16b	v25, v5, v26
    1018:      	and.16b	v26, v4, v26
    101c:      	ldr	q27, [sp, #0x80]
    1020:      	and.16b	v27, v6, v27
    1024:      	ldr	q6, [sp, #0xa0]
    1028:      	and.16b	v19, v19, v6
    102c:      	ldr	q6, [sp, #0x90]
    1030:      	and.16b	v28, v5, v6
    1034:      	and.16b	v29, v4, v11
    1038:      	cmhs.4s	v4, v17, v3
    103c:      	cmhs.4s	v3, v16, v3
    1040:      	uzp1.8h	v3, v3, v4
    1044:      	xtn.8b	v30, v3
    1048:      	ldp	q14, q13, [sp, #0x130]
    104c:      	ldr	q15, [sp, #0x120]
    1050:      	b	0x1060 <ltmp0+0x1060>
    1054:      	add	x11, x11, #0x1
    1058:      	cmp	x11, #0x60
    105c:      	b.eq	0x1160 <ltmp0+0x1160>
    1060:      	dup.2d	v31, x11
    1064:      	fmov	w12, s2
    1068:      	add	x13, x20, x11, lsl #6
    106c:      	ldp	q4, q3, [x13, #0x20]
    1070:      	ldp	q5, q6, [x13]
    1074:      	cmge.2d	v6, v21, v6
    1078:      	cmge.2d	v5, v22, v5
    107c:      	uzp1.4s	v5, v5, v6
    1080:      	cmge.2d	v4, v20, v4
    1084:      	cmge.2d	v3, v18, v3
    1088:      	uzp1.4s	v3, v4, v3
    108c:      	uzp1.8h	v3, v5, v3
    1090:      	xtn.8b	v3, v3
    1094:      	orr.8b	v5, v30, v3
    1098:      	add.2d	v3, v26, v29
    109c:      	add.2d	v4, v3, v31
    10a0:      	and.8b	v10, v5, v9
    10a4:      	tbnz	w12, #0x0, 0x10e4 <ltmp0+0x10e4>
    10a8:      	and	w12, w12, #0xff
    10ac:      	tbnz	w12, #0x1, 0x10f4 <ltmp0+0x10f4>
    10b0:      	add.2d	v4, v24, v19
    10b4:      	add.2d	v5, v4, v31
    10b8:      	tbnz	w12, #0x2, 0x1108 <ltmp0+0x1108>
    10bc:      	tbnz	w12, #0x3, 0x1114 <ltmp0+0x1114>
    10c0:      	add.2d	v5, v25, v28
    10c4:      	add.2d	v6, v5, v31
    10c8:      	tbnz	w12, #0x4, 0x1128 <ltmp0+0x1128>
    10cc:      	tbnz	w12, #0x5, 0x1134 <ltmp0+0x1134>
    10d0:      	add.2d	v6, v23, v27
    10d4:      	add.2d	v31, v6, v31
    10d8:      	tbnz	w12, #0x6, 0x1148 <ltmp0+0x1148>
    10dc:      	tbz	w12, #0x7, 0x1054 <ltmp0+0x1054>
    10e0:      	b	0x1154 <ltmp0+0x1154>
    10e4:      	fmov	x13, d4
    10e8:      	str	b10, [x13]
    10ec:      	and	w12, w12, #0xff
    10f0:      	tbz	w12, #0x1, 0x10b0 <ltmp0+0x10b0>
    10f4:      	mov.d	x13, v4[1]
    10f8:      	st1.b	{ v10 }[1], [x13]
    10fc:      	add.2d	v4, v24, v19
    1100:      	add.2d	v5, v4, v31
    1104:      	tbz	w12, #0x2, 0x10bc <ltmp0+0x10bc>
    1108:      	fmov	x13, d5
    110c:      	st1.b	{ v10 }[2], [x13]
    1110:      	tbz	w12, #0x3, 0x10c0 <ltmp0+0x10c0>
    1114:      	mov.d	x13, v5[1]
    1118:      	st1.b	{ v10 }[3], [x13]
    111c:      	add.2d	v5, v25, v28
    1120:      	add.2d	v6, v5, v31
    1124:      	tbz	w12, #0x4, 0x10cc <ltmp0+0x10cc>
    1128:      	fmov	x13, d6
    112c:      	st1.b	{ v10 }[4], [x13]
    1130:      	tbz	w12, #0x5, 0x10d0 <ltmp0+0x10d0>
    1134:      	mov.d	x13, v6[1]
    1138:      	st1.b	{ v10 }[5], [x13]
    113c:      	add.2d	v6, v23, v27
    1140:      	add.2d	v31, v6, v31
    1144:      	tbz	w12, #0x6, 0x10dc <ltmp0+0x10dc>
    1148:      	fmov	x13, d31
    114c:      	st1.b	{ v10 }[6], [x13]
    1150:      	tbz	w12, #0x7, 0x1054 <ltmp0+0x1054>
    1154:      	mov.d	x12, v31[1]
    1158:      	st1.b	{ v10 }[7], [x12]
    115c:      	b	0x1054 <ltmp0+0x1054>
    1160:      	mov	x11, #0x0               ; =0
    1164:      	b	0x11b4 <ltmp0+0x11b4>
    1168:      	cmeq.8b	v18, v18, #0
    116c:      	sshll.8h	v18, v18, #0x0
    1170:      	sshll2.4s	v19, v18, #0x0
    1174:      	sshll.4s	v18, v18, #0x0
    1178:      	lsl	x12, x11, #5
    117c:      	add	x13, x19, x12
    1180:      	ldp	q20, q21, [x13]
    1184:      	and.16b	v21, v0, v21
    1188:      	and.16b	v20, v1, v20
    118c:      	bsl.16b	v18, v12, v20
    1190:      	bsl.16b	v19, v12, v21
    1194:      	add	x12, x24, x12
    1198:      	ldp	q20, q21, [x12]
    119c:      	bif.16b	v19, v21, v0
    11a0:      	bif.16b	v18, v20, v1
    11a4:      	stp	q18, q19, [x12]
    11a8:      	add	x11, x11, #0x1
    11ac:      	cmp	x11, #0x60
    11b0:      	b.eq	0x1264 <ltmp0+0x1264>
    11b4:      	fmov	w12, s2
    11b8:      	dup.2d	v19, x11
    11bc:      	add.2d	v20, v3, v19
    11c0:      	tbz	w12, #0x0, 0x11d8 <ltmp0+0x11d8>
    11c4:      	fmov	x13, d20
    11c8:      	ldr	b18, [x13]
    11cc:      	and	w12, w12, #0xff
    11d0:      	tbnz	w12, #0x1, 0x11e4 <ltmp0+0x11e4>
    11d4:      	b	0x11ec <ltmp0+0x11ec>
    11d8:      	movi.2d	v18, #0000000000000000
    11dc:      	and	w12, w12, #0xff
    11e0:      	tbz	w12, #0x1, 0x11ec <ltmp0+0x11ec>
    11e4:      	mov.d	x13, v20[1]
    11e8:      	ld1.b	{ v18 }[1], [x13]
    11ec:      	add.2d	v20, v4, v19
    11f0:      	tbnz	w12, #0x2, 0x1214 <ltmp0+0x1214>
    11f4:      	tbnz	w12, #0x3, 0x1220 <ltmp0+0x1220>
    11f8:      	add.2d	v20, v5, v19
    11fc:      	tbnz	w12, #0x4, 0x1230 <ltmp0+0x1230>
    1200:      	tbnz	w12, #0x5, 0x123c <ltmp0+0x123c>
    1204:      	add.2d	v19, v6, v19
    1208:      	tbnz	w12, #0x6, 0x124c <ltmp0+0x124c>
    120c:      	tbz	w12, #0x7, 0x1168 <ltmp0+0x1168>
    1210:      	b	0x1258 <ltmp0+0x1258>
    1214:      	fmov	x13, d20
    1218:      	ld1.b	{ v18 }[2], [x13]
    121c:      	tbz	w12, #0x3, 0x11f8 <ltmp0+0x11f8>
    1220:      	mov.d	x13, v20[1]
    1224:      	ld1.b	{ v18 }[3], [x13]
    1228:      	add.2d	v20, v5, v19
    122c:      	tbz	w12, #0x4, 0x1200 <ltmp0+0x1200>
    1230:      	fmov	x13, d20
    1234:      	ld1.b	{ v18 }[4], [x13]
    1238:      	tbz	w12, #0x5, 0x1204 <ltmp0+0x1204>
    123c:      	mov.d	x13, v20[1]
    1240:      	ld1.b	{ v18 }[5], [x13]
    1244:      	add.2d	v19, v6, v19
    1248:      	tbz	w12, #0x6, 0x120c <ltmp0+0x120c>
    124c:      	fmov	x13, d19
    1250:      	ld1.b	{ v18 }[6], [x13]
    1254:      	tbz	w12, #0x7, 0x1168 <ltmp0+0x1168>
    1258:      	mov.d	x12, v19[1]
    125c:      	ld1.b	{ v18 }[7], [x12]
    1260:      	b	0x1168 <ltmp0+0x1168>
    1264:      	ldr	q18, [x23, #0x1100]
    1268:      	ldr	q19, [x23, #0x1110]
    126c:      	ldr	q20, [x23, #0x1120]
    1270:      	ldr	q21, [x23, #0x1130]
    1274:      	ldr	q22, [x23, #0x1140]
    1278:      	ldr	q25, [x23, #0x1150]
    127c:      	ldr	q26, [x23, #0x1160]
    1280:      	and.16b	v19, v0, v19
    1284:      	and.16b	v18, v1, v18
    1288:      	ldr	q27, [x23, #0x1170]
    128c:      	and.16b	v24, v0, v21
    1290:      	and.16b	v23, v1, v20
    1294:      	and.16b	v20, v0, v25
    1298:      	and.16b	v25, v1, v22
    129c:      	and.16b	v22, v0, v27
    12a0:      	and.16b	v21, v1, v26
    12a4:      	ldr	x11, [sp, #0x18]
    12a8:      	mov	w12, #0x4               ; =4
    12ac:      	ldp	q26, q27, [x11, #-0x60]
    12b0:      	and.16b	v27, v0, v27
    12b4:      	and.16b	v26, v1, v26
    12b8:      	fmaxnm.4s	v26, v18, v26
    12bc:      	fmaxnm.4s	v27, v19, v27
    12c0:      	ldp	q28, q29, [x11, #-0x40]
    12c4:      	and.16b	v29, v0, v29
    12c8:      	and.16b	v28, v1, v28
    12cc:      	fmaxnm.4s	v28, v23, v28
    12d0:      	fmaxnm.4s	v29, v24, v29
    12d4:      	ldp	q30, q31, [x11, #-0x20]
    12d8:      	and.16b	v31, v0, v31
    12dc:      	and.16b	v30, v1, v30
    12e0:      	fmaxnm.4s	v30, v25, v30
    12e4:      	fmaxnm.4s	v31, v20, v31
    12e8:      	ldp	q10, q11, [x11], #0x80
    12ec:      	and.16b	v11, v0, v11
    12f0:      	and.16b	v10, v1, v10
    12f4:      	fmaxnm.4s	v10, v21, v10
    12f8:      	fmaxnm.4s	v11, v22, v11
    12fc:      	bit.16b	v19, v27, v0
    1300:      	bit.16b	v18, v26, v1
    1304:      	bit.16b	v24, v29, v0
    1308:      	bit.16b	v23, v28, v1
    130c:      	bit.16b	v20, v31, v0
    1310:      	bit.16b	v25, v30, v1
    1314:      	bit.16b	v22, v11, v0
    1318:      	bit.16b	v21, v10, v1
    131c:      	cmp	x12, #0x5c
    1320:      	add	x12, x12, #0x4
    1324:      	b.lo	0x12ac <ltmp0+0x12ac>
    1328:      	mov	x21, #0x0               ; =0
    132c:      	xtn.8b	v7, v7
    1330:      	fmaxnm.4s	v19, v19, v24
    1334:      	fmaxnm.4s	v18, v18, v23
    1338:      	fmaxnm.4s	v23, v18, v25
    133c:      	fmaxnm.4s	v18, v19, v20
    1340:      	fmaxnm.4s	v18, v18, v22
    1344:      	fmaxnm.4s	v19, v23, v21
    1348:      	and.16b	v16, v1, v16
    134c:      	and.16b	v17, v0, v17
    1350:      	movi.4s	v20, #0x1
    1354:      	eor.16b	v21, v17, v20
    1358:      	eor.16b	v24, v16, v20
    135c:      	umov.b	w11, v7[0]
    1360:      	str	q19, [x23, #0x4d0]
    1364:      	ldr	s20, [x23, #0x4d4]
    1368:      	umov.b	w12, v7[1]
    136c:      	ands	w1, w11, #0x1
    1370:      	tst	w1, w12
    1374:      	movi	d28, #0000000000000000
    1378:      	fcsel	s20, s20, s28, ne
    137c:      	mov.s	w13, v24[1]
    1380:      	add	x14, sp, #0x710
    1384:      	orr	x14, x14, x13, lsl #2
    1388:      	add	x15, sp, #0x428
    138c:      	bfxil	x15, x13, #0, #3
    1390:      	str	d7, [x23, #0x1c8]
    1394:      	ldrb	w13, [x15]
    1398:      	and	w13, w12, w13
    139c:      	str	q19, [x23, #0x4b0]
    13a0:      	str	q18, [x23, #0x4c0]
    13a4:      	ldr	s22, [x14]
    13a8:      	tst	w13, #0x1
    13ac:      	fcsel	s22, s22, s28, ne
    13b0:      	mov.s	w13, v24[2]
    13b4:      	add	x14, sp, #0x6f0
    13b8:      	orr	x14, x14, x13, lsl #2
    13bc:      	add	x15, sp, #0x428
    13c0:      	bfxil	x15, x13, #0, #3
    13c4:      	ldrb	w15, [x15]
    13c8:      	umov.b	w13, v7[2]
    13cc:      	and	w15, w13, w15
    13d0:      	str	q19, [x23, #0x490]
    13d4:      	str	q18, [x23, #0x4a0]
    13d8:      	ldr	s23, [x14]
    13dc:      	tst	w15, #0x1
    13e0:      	fcsel	s23, s23, s28, ne
    13e4:      	mov.s	w14, v24[3]
    13e8:      	add	x15, sp, #0x6d0
    13ec:      	orr	x15, x15, x14, lsl #2
    13f0:      	add	x16, sp, #0x428
    13f4:      	bfxil	x16, x14, #0, #3
    13f8:      	ldrb	w16, [x16]
    13fc:      	umov.b	w14, v7[3]
    1400:      	and	w16, w14, w16
    1404:      	str	q19, [x23, #0x470]
    1408:      	str	q18, [x23, #0x480]
    140c:      	ldr	s24, [x15]
    1410:      	tst	w16, #0x1
    1414:      	fcsel	s24, s24, s28, ne
    1418:      	fmov	w16, s21
    141c:      	add	x15, sp, #0x428
    1420:      	bfxil	x15, x16, #0, #3
    1424:      	ldrb	w17, [x15]
    1428:      	umov.b	w15, v7[4]
    142c:      	str	q19, [x23, #0x450]
    1430:      	str	q18, [x23, #0x460]
    1434:      	add	x0, sp, #0x6b0
    1438:      	ldr	s25, [x0, w16, uxtw #2]
    143c:      	and	w16, w15, w17
    1440:      	tst	w16, #0x1
    1444:      	fcsel	s25, s25, s28, ne
    1448:      	mov.s	w17, v21[1]
    144c:      	add	x16, sp, #0x428
    1450:      	bfxil	x16, x17, #0, #3
    1454:      	ldrb	w0, [x16]
    1458:      	umov.b	w16, v7[5]
    145c:      	and	w0, w16, w0
    1460:      	str	q19, [x23, #0x430]
    1464:      	str	q18, [x23, #0x440]
    1468:      	add	x2, sp, #0x690
    146c:      	ldr	s26, [x2, w17, uxtw #2]
    1470:      	tst	w0, #0x1
    1474:      	mov.s	w0, v21[2]
    1478:      	fcsel	s26, s26, s28, ne
    147c:      	add	x17, sp, #0x428
    1480:      	bfxil	x17, x0, #0, #3
    1484:      	ldrb	w2, [x17]
    1488:      	umov.b	w17, v7[6]
    148c:      	and	w2, w17, w2
    1490:      	str	q19, [x23, #0x410]
    1494:      	str	q18, [x23, #0x420]
    1498:      	add	x3, sp, #0x670
    149c:      	ldr	s27, [x3, w0, uxtw #2]
    14a0:      	tst	w2, #0x1
    14a4:      	fcsel	s27, s27, s28, ne
    14a8:      	mov.s	w2, v21[3]
    14ac:      	add	x0, sp, #0x428
    14b0:      	bfxil	x0, x2, #0, #3
    14b4:      	ldrb	w3, [x0]
    14b8:      	umov.b	w0, v7[7]
    14bc:      	stp	q19, q18, [x23, #0x3f0]
    14c0:      	add	x4, sp, #0x650
    14c4:      	ldr	s21, [x4, w2, uxtw #2]
    14c8:      	and	w2, w0, w3
    14cc:      	tst	w2, #0x1
    14d0:      	mov.s	v20[1], v22[0]
    14d4:      	mov.s	v20[2], v23[0]
    14d8:      	mov.s	v20[3], v24[0]
    14dc:      	mov.s	v25[1], v26[0]
    14e0:      	mov.s	v25[2], v27[0]
    14e4:      	fcsel	s21, s21, s28, ne
    14e8:      	mov.s	v25[3], v21[0]
    14ec:      	fmaxnm.4s	v18, v18, v25
    14f0:      	fmaxnm.4s	v19, v19, v20
    14f4:      	movi.4s	v20, #0x2
    14f8:      	eor.16b	v21, v17, v20
    14fc:      	eor.16b	v22, v16, v20
    1500:      	str	q19, [x23, #0x3d0]
    1504:      	ldr	s17, [x23, #0x3d8]
    1508:      	tst	w1, w13
    150c:      	mov.s	w2, v22[1]
    1510:      	fcsel	s17, s17, s28, ne
    1514:      	add	x3, sp, #0x610
    1518:      	orr	x3, x3, x2, lsl #2
    151c:      	add	x4, sp, #0x428
    1520:      	bfxil	x4, x2, #0, #3
    1524:      	ldrb	w2, [x4]
    1528:      	and	w2, w12, w2
    152c:      	stp	q19, q18, [x23, #0x3b0]
    1530:      	ldr	s20, [x3]
    1534:      	tst	w2, #0x1
    1538:      	mov.s	w2, v22[2]
    153c:      	fcsel	s20, s20, s28, ne
    1540:      	add	x3, sp, #0x5f0
    1544:      	orr	x3, x3, x2, lsl #2
    1548:      	add	x4, sp, #0x428
    154c:      	bfxil	x4, x2, #0, #3
    1550:      	ldrb	w2, [x4]
    1554:      	and	w2, w13, w2
    1558:      	stp	q19, q18, [x23, #0x390]
    155c:      	ldr	s23, [x3]
    1560:      	tst	w2, #0x1
    1564:      	mov.s	w2, v22[3]
    1568:      	fcsel	s22, s23, s28, ne
    156c:      	add	x3, sp, #0x5d0
    1570:      	orr	x3, x3, x2, lsl #2
    1574:      	add	x4, sp, #0x428
    1578:      	bfxil	x4, x2, #0, #3
    157c:      	ldrb	w2, [x4]
    1580:      	and	w2, w14, w2
    1584:      	stp	q19, q18, [x23, #0x370]
    1588:      	ldr	s23, [x3]
    158c:      	tst	w2, #0x1
    1590:      	fcsel	s23, s23, s28, ne
    1594:      	fmov	w2, s21
    1598:      	add	x3, sp, #0x428
    159c:      	bfxil	x3, x2, #0, #3
    15a0:      	ldrb	w3, [x3]
    15a4:      	and	w3, w15, w3
    15a8:      	stp	q19, q18, [x23, #0x350]
    15ac:      	add	x4, sp, #0x5b0
    15b0:      	ldr	s24, [x4, w2, uxtw #2]
    15b4:      	tst	w3, #0x1
    15b8:      	fcsel	s24, s24, s28, ne
    15bc:      	mov.s	w2, v21[1]
    15c0:      	add	x3, sp, #0x428
    15c4:      	bfxil	x3, x2, #0, #3
    15c8:      	ldrb	w3, [x3]
    15cc:      	and	w3, w16, w3
    15d0:      	stp	q19, q18, [x23, #0x330]
    15d4:      	add	x4, sp, #0x590
    15d8:      	ldr	s25, [x4, w2, uxtw #2]
    15dc:      	tst	w3, #0x1
    15e0:      	fcsel	s25, s25, s28, ne
    15e4:      	mov.s	w2, v21[2]
    15e8:      	add	x3, sp, #0x428
    15ec:      	bfxil	x3, x2, #0, #3
    15f0:      	ldrb	w3, [x3]
    15f4:      	and	w3, w17, w3
    15f8:      	stp	q19, q18, [x23, #0x310]
    15fc:      	add	x4, sp, #0x570
    1600:      	ldr	s26, [x4, w2, uxtw #2]
    1604:      	tst	w3, #0x1
    1608:      	fcsel	s26, s26, s28, ne
    160c:      	mov.s	w2, v21[3]
    1610:      	add	x3, sp, #0x428
    1614:      	bfxil	x3, x2, #0, #3
    1618:      	ldrb	w3, [x3]
    161c:      	and	w3, w0, w3
    1620:      	stp	q19, q18, [x23, #0x2f0]
    1624:      	add	x4, sp, #0x550
    1628:      	ldr	s21, [x4, w2, uxtw #2]
    162c:      	tst	w3, #0x1
    1630:      	fcsel	s21, s21, s28, ne
    1634:      	mov.s	v24[1], v25[0]
    1638:      	mov.s	v24[2], v26[0]
    163c:      	mov.s	v24[3], v21[0]
    1640:      	mov.s	v17[1], v20[0]
    1644:      	mov.s	v17[2], v22[0]
    1648:      	mov.s	v17[3], v23[0]
    164c:      	fmaxnm.4s	v17, v19, v17
    1650:      	fmaxnm.4s	v18, v18, v24
    1654:      	orr.4s	v16, #0x4
    1658:      	str	q18, [x23, #0x2e0]
    165c:      	ldr	s19, [x23, #0x2e0]
    1660:      	tst	w1, w15
    1664:      	fcsel	s19, s19, s28, ne
    1668:      	mov.s	w1, v16[1]
    166c:      	add	x2, sp, #0x428
    1670:      	bfxil	x2, x1, #0, #3
    1674:      	ldrb	w2, [x2]
    1678:      	and	w2, w12, w2
    167c:      	stp	q17, q18, [x23, #0x2b0]
    1680:      	add	x3, sp, #0x510
    1684:      	ldr	s20, [x3, w1, uxtw #2]
    1688:      	tst	w2, #0x1
    168c:      	fcsel	s20, s20, s28, ne
    1690:      	mov.s	w1, v16[2]
    1694:      	add	x2, sp, #0x428
    1698:      	bfxil	x2, x1, #0, #3
    169c:      	ldrb	w2, [x2]
    16a0:      	and	w2, w13, w2
    16a4:      	stp	q17, q18, [x23, #0x290]
    16a8:      	add	x3, sp, #0x4f0
    16ac:      	ldr	s21, [x3, w1, uxtw #2]
    16b0:      	tst	w2, #0x1
    16b4:      	fcsel	s21, s21, s28, ne
    16b8:      	mov.s	w1, v16[3]
    16bc:      	add	x2, sp, #0x428
    16c0:      	bfxil	x2, x1, #0, #3
    16c4:      	ldrb	w2, [x2]
    16c8:      	and	w2, w14, w2
    16cc:      	stp	q17, q18, [x23, #0x270]
    16d0:      	add	x3, sp, #0x4d0
    16d4:      	ldr	s16, [x3, w1, uxtw #2]
    16d8:      	tst	w2, #0x1
    16dc:      	fcsel	s16, s16, s28, ne
    16e0:      	mov.s	v19[1], v20[0]
    16e4:      	mov.s	v19[2], v21[0]
    16e8:      	mov.s	v19[3], v16[0]
    16ec:      	ands	w3, w11, #0x1
    16f0:      	fmaxnm.4s	v16, v17, v19
    16f4:      	fcsel	s17, s16, s28, ne
    16f8:      	and	w1, w12, w11
    16fc:      	tst	w1, #0x1
    1700:      	fcsel	s18, s16, s28, ne
    1704:      	and	w2, w13, w11
    1708:      	tst	w2, #0x1
    170c:      	fcsel	s19, s16, s28, ne
    1710:      	and	w4, w14, w11
    1714:      	tst	w4, #0x1
    1718:      	fcsel	s20, s16, s28, ne
    171c:      	and	w5, w15, w11
    1720:      	tst	w5, #0x1
    1724:      	fcsel	s21, s16, s28, ne
    1728:      	and	w6, w16, w11
    172c:      	tst	w6, #0x1
    1730:      	fcsel	s22, s16, s28, ne
    1734:      	and	w7, w17, w11
    1738:      	tst	w7, #0x1
    173c:      	fcsel	s23, s16, s28, ne
    1740:      	and	w30, w0, w11
    1744:      	tst	w30, #0x1
    1748:      	fcsel	s16, s16, s28, ne
    174c:      	mov.s	v17[1], v18[0]
    1750:      	mov.s	v17[2], v19[0]
    1754:      	mov.s	v17[3], v20[0]
    1758:      	mov.s	v21[1], v22[0]
    175c:      	mov.s	v21[2], v23[0]
    1760:      	mov.s	v21[3], v16[0]
    1764:      	rbit	w10, w10
    1768:      	clz	w10, w10
    176c:      	stp	q17, q21, [x23, #0x1d0]
    1770:      	and	x22, x10, #0x7
    1774:      	add	x25, sp, #0x430
    1778:      	ldr	s16, [x25, x22, lsl #2]
    177c:      	mov	w22, #-0x800000         ; =-8388608
    1780:      	fmov	s17, w22
    1784:      	fmaxnm	s16, s16, s17
    1788:      	dup.4s	v16, v16[0]
    178c:      	movi.4s	v29, #0x4b, lsl #24
    1790:      	mvni.4s	v30, #0x80, lsl #24
    1794:      	movi.4s	v31, #0x3f, lsl #24
    1798:      	ldp	q11, q10, [sp, #0x60]
    179c:      	ldr	q12, [sp, #0x150]
    17a0:      	b	0x1960 <ltmp0+0x1960>
    17a4:      	cmeq.8b	v17, v17, #0
    17a8:      	sshll.8h	v18, v17, #0x0
    17ac:      	sshll2.4s	v17, v18, #0x0
    17b0:      	sshll.4s	v18, v18, #0x0
    17b4:      	lsl	x22, x21, #5
    17b8:      	add	x25, x24, x22
    17bc:      	ldp	q20, q19, [x25]
    17c0:      	fsub.4s	v20, v20, v16
    17c4:      	fsub.4s	v19, v19, v16
    17c8:      	and.16b	v19, v0, v19
    17cc:      	and.16b	v20, v1, v20
    17d0:      	fcmge.4s	v21, v20, v12
    17d4:      	fcmge.4s	v22, v19, v12
    17d8:      	fcmge.4s	v23, v13, v20
    17dc:      	fcmge.4s	v24, v13, v19
    17e0:      	and.16b	v22, v22, v24
    17e4:      	and.16b	v21, v21, v23
    17e8:      	and.16b	v21, v21, v20
    17ec:      	and.16b	v22, v22, v19
    17f0:      	fmul.4s	v23, v22, v14
    17f4:      	fmul.4s	v24, v21, v14
    17f8:      	mov.16b	v25, v30
    17fc:      	bsl.16b	v25, v29, v24
    1800:      	mov.16b	v26, v30
    1804:      	bsl.16b	v26, v29, v23
    1808:      	fadd.4s	v23, v23, v26
    180c:      	fadd.4s	v24, v24, v25
    1810:      	fsub.4s	v24, v24, v25
    1814:      	fsub.4s	v23, v23, v26
    1818:      	fcvtzs.4s	v23, v23
    181c:      	fcvtzs.4s	v24, v24
    1820:      	scvtf.4s	v25, v24
    1824:      	scvtf.4s	v26, v23
    1828:      	fmul.4s	v27, v26, v15
    182c:      	fmul.4s	v28, v25, v15
    1830:      	fadd.4s	v21, v21, v28
    1834:      	fadd.4s	v22, v22, v27
    1838:      	ldr	q27, [sp, #0x1c0]
    183c:      	fmul.4s	v25, v25, v27
    1840:      	fmul.4s	v26, v26, v27
    1844:      	fadd.4s	v22, v22, v26
    1848:      	fadd.4s	v21, v21, v25
    184c:      	ldp	q27, q26, [sp, #0x1a0]
    1850:      	fmul.4s	v25, v21, v26
    1854:      	fmul.4s	v26, v22, v26
    1858:      	fadd.4s	v26, v26, v27
    185c:      	fadd.4s	v25, v25, v27
    1860:      	fmul.4s	v25, v21, v25
    1864:      	fmul.4s	v26, v22, v26
    1868:      	ldp	q27, q28, [sp, #0x180]
    186c:      	fadd.4s	v26, v26, v28
    1870:      	fadd.4s	v25, v25, v28
    1874:      	fmul.4s	v25, v21, v25
    1878:      	fmul.4s	v26, v22, v26
    187c:      	fadd.4s	v26, v26, v27
    1880:      	fadd.4s	v25, v25, v27
    1884:      	fmul.4s	v25, v21, v25
    1888:      	fmul.4s	v26, v22, v26
    188c:      	ldp	q8, q27, [sp, #0x160]
    1890:      	fadd.4s	v26, v26, v27
    1894:      	fadd.4s	v25, v25, v27
    1898:      	fmul.4s	v25, v21, v25
    189c:      	fmul.4s	v26, v22, v26
    18a0:      	fadd.4s	v26, v26, v31
    18a4:      	fadd.4s	v25, v25, v31
    18a8:      	fmul.4s	v27, v22, v22
    18ac:      	fmul.4s	v28, v21, v21
    18b0:      	fmul.4s	v25, v28, v25
    18b4:      	fmul.4s	v26, v27, v26
    18b8:      	fadd.4s	v22, v22, v26
    18bc:      	fadd.4s	v21, v21, v25
    18c0:      	fadd.4s	v21, v21, v8
    18c4:      	fadd.4s	v22, v22, v8
    18c8:      	sshr.4s	v25, v24, #0x1
    18cc:      	sshr.4s	v26, v23, #0x1
    18d0:      	shl.4s	v27, v26, #0x17
    18d4:      	shl.4s	v28, v25, #0x17
    18d8:      	add.4s	v28, v28, v8
    18dc:      	add.4s	v27, v27, v8
    18e0:      	fmul.4s	v22, v22, v27
    18e4:      	fmul.4s	v21, v21, v28
    18e8:      	sub.4s	v23, v23, v26
    18ec:      	sub.4s	v24, v24, v25
    18f0:      	shl.4s	v24, v24, #0x17
    18f4:      	shl.4s	v23, v23, #0x17
    18f8:      	add.4s	v23, v23, v8
    18fc:      	add.4s	v24, v24, v8
    1900:      	fmul.4s	v21, v21, v24
    1904:      	fmul.4s	v22, v22, v23
    1908:      	fcmgt.4s	v23, v12, v19
    190c:      	bic.16b	v22, v22, v23
    1910:      	fcmgt.4s	v23, v12, v20
    1914:      	bic.16b	v21, v21, v23
    1918:      	fcmgt.4s	v23, v19, v13
    191c:      	fcmgt.4s	v24, v20, v13
    1920:      	bit.16b	v21, v10, v24
    1924:      	bit.16b	v22, v10, v23
    1928:      	fcmeq.4s	v20, v20, v20
    192c:      	fcmeq.4s	v19, v19, v19
    1930:      	bsl.16b	v19, v22, v11
    1934:      	bsl.16b	v20, v21, v11
    1938:      	bic.16b	v18, v20, v18
    193c:      	bic.16b	v17, v19, v17
    1940:      	add	x22, x26, x22
    1944:      	ldp	q19, q20, [x22]
    1948:      	bif.16b	v17, v20, v0
    194c:      	bif.16b	v18, v19, v1
    1950:      	stp	q18, q17, [x22]
    1954:      	add	x21, x21, #0x1
    1958:      	cmp	x21, #0x60
    195c:      	b.eq	0x1a10 <ltmp0+0x1a10>
    1960:      	fmov	w22, s2
    1964:      	dup.2d	v18, x21
    1968:      	add.2d	v19, v3, v18
    196c:      	tbz	w22, #0x0, 0x1984 <ltmp0+0x1984>
    1970:      	fmov	x25, d19
    1974:      	ldr	b17, [x25]
    1978:      	and	w22, w22, #0xff
    197c:      	tbnz	w22, #0x1, 0x1990 <ltmp0+0x1990>
    1980:      	b	0x1998 <ltmp0+0x1998>
    1984:      	movi.2d	v17, #0000000000000000
    1988:      	and	w22, w22, #0xff
    198c:      	tbz	w22, #0x1, 0x1998 <ltmp0+0x1998>
    1990:      	mov.d	x25, v19[1]
    1994:      	ld1.b	{ v17 }[1], [x25]
    1998:      	add.2d	v19, v4, v18
    199c:      	tbnz	w22, #0x2, 0x19c0 <ltmp0+0x19c0>
    19a0:      	tbnz	w22, #0x3, 0x19cc <ltmp0+0x19cc>
    19a4:      	add.2d	v19, v5, v18
    19a8:      	tbnz	w22, #0x4, 0x19dc <ltmp0+0x19dc>
    19ac:      	tbnz	w22, #0x5, 0x19e8 <ltmp0+0x19e8>
    19b0:      	add.2d	v18, v6, v18
    19b4:      	tbnz	w22, #0x6, 0x19f8 <ltmp0+0x19f8>
    19b8:      	tbz	w22, #0x7, 0x17a4 <ltmp0+0x17a4>
    19bc:      	b	0x1a04 <ltmp0+0x1a04>
    19c0:      	fmov	x25, d19
    19c4:      	ld1.b	{ v17 }[2], [x25]
    19c8:      	tbz	w22, #0x3, 0x19a4 <ltmp0+0x19a4>
    19cc:      	mov.d	x25, v19[1]
    19d0:      	ld1.b	{ v17 }[3], [x25]
    19d4:      	add.2d	v19, v5, v18
    19d8:      	tbz	w22, #0x4, 0x19ac <ltmp0+0x19ac>
    19dc:      	fmov	x25, d19
    19e0:      	ld1.b	{ v17 }[4], [x25]
    19e4:      	tbz	w22, #0x5, 0x19b0 <ltmp0+0x19b0>
    19e8:      	mov.d	x25, v19[1]
    19ec:      	ld1.b	{ v17 }[5], [x25]
    19f0:      	add.2d	v18, v6, v18
    19f4:      	tbz	w22, #0x6, 0x19b8 <ltmp0+0x19b8>
    19f8:      	fmov	x25, d18
    19fc:      	ld1.b	{ v17 }[6], [x25]
    1a00:      	tbz	w22, #0x7, 0x17a4 <ltmp0+0x17a4>
    1a04:      	mov.d	x22, v18[1]
    1a08:      	ld1.b	{ v17 }[7], [x22]
    1a0c:      	b	0x17a4 <ltmp0+0x17a4>
    1a10:      	ldr	q3, [x23, #0x500]
    1a14:      	ldr	q4, [x23, #0x510]
    1a18:      	ldr	q6, [x23, #0x520]
    1a1c:      	ldr	q16, [x23, #0x530]
    1a20:      	ldr	q17, [x23, #0x540]
    1a24:      	ldr	q18, [x23, #0x550]
    1a28:      	ldr	q22, [x23, #0x560]
    1a2c:      	and.16b	v5, v0, v4
    1a30:      	and.16b	v4, v1, v3
    1a34:      	ldr	q3, [x23, #0x570]
    1a38:      	and.16b	v20, v0, v16
    1a3c:      	and.16b	v19, v1, v6
    1a40:      	and.16b	v6, v0, v18
    1a44:      	and.16b	v21, v1, v17
    1a48:      	and.16b	v18, v0, v3
    1a4c:      	and.16b	v17, v1, v22
    1a50:      	ldr	x21, [sp, #0x10]
    1a54:      	mov	w22, #0x4               ; =4
    1a58:      	ldp	q16, q3, [x21, #-0x60]
    1a5c:      	fadd.4s	v16, v4, v16
    1a60:      	fadd.4s	v3, v5, v3
    1a64:      	ldp	q23, q22, [x21, #-0x40]
    1a68:      	fadd.4s	v23, v19, v23
    1a6c:      	fadd.4s	v22, v20, v22
    1a70:      	ldp	q25, q24, [x21, #-0x20]
    1a74:      	fadd.4s	v25, v21, v25
    1a78:      	fadd.4s	v24, v6, v24
    1a7c:      	ldp	q27, q26, [x21], #0x80
    1a80:      	fadd.4s	v27, v17, v27
    1a84:      	fadd.4s	v26, v18, v26
    1a88:      	bit.16b	v5, v3, v0
    1a8c:      	bit.16b	v4, v16, v1
    1a90:      	bit.16b	v20, v22, v0
    1a94:      	bit.16b	v19, v23, v1
    1a98:      	bit.16b	v6, v24, v0
    1a9c:      	bit.16b	v21, v25, v1
    1aa0:      	bit.16b	v18, v26, v0
    1aa4:      	bit.16b	v17, v27, v1
    1aa8:      	cmp	x22, #0x5c
    1aac:      	add	x22, x22, #0x4
    1ab0:      	b.lo	0x1a58 <ltmp0+0x1a58>
    1ab4:      	mov	x21, #0x0               ; =0
    1ab8:      	adrp	x22, 0x1000 <ltmp0+0x1000>
    1abc:      	ldr	q3, [x22]
    1ac0:      	and.16b	v16, v0, v3
    1ac4:      	adrp	x22, 0x1000 <ltmp0+0x1000>
    1ac8:      	ldr	q3, [x22]
    1acc:      	and.16b	v22, v1, v3
    1ad0:      	adrp	x22, 0x1000 <ltmp0+0x1000>
    1ad4:      	ldr	q3, [x22]
    1ad8:      	and.16b	v3, v1, v3
    1adc:      	fadd.4s	v5, v5, v20
    1ae0:      	fadd.4s	v4, v4, v19
    1ae4:      	fadd.4s	v19, v4, v21
    1ae8:      	fadd.4s	v4, v5, v6
    1aec:      	fadd.4s	v4, v4, v18
    1af0:      	fadd.4s	v5, v19, v17
    1af4:      	fmov	w22, s22
    1af8:      	add	x25, sp, #0x1d8
    1afc:      	bfxil	x25, x22, #0, #3
    1b00:      	str	d7, [sp, #0x1d8]
    1b04:      	ldrb	w25, [x25]
    1b08:      	add	x27, sp, #0x400
    1b0c:      	orr	x22, x27, x22, lsl #2
    1b10:      	stp	q5, q4, [x23, #0x1a0]
    1b14:      	ldr	s6, [x22]
    1b18:      	tst	w3, w25
    1b1c:      	movi	d23, #0000000000000000
    1b20:      	fcsel	s6, s6, s23, ne
    1b24:      	mov.s	w22, v22[1]
    1b28:      	add	x25, sp, #0x1d8
    1b2c:      	bfxil	x25, x22, #0, #3
    1b30:      	ldrb	w22, [x25]
    1b34:      	and	w22, w12, w22
    1b38:      	str	q5, [x23, #0x180]
    1b3c:      	ldr	s7, [x23, #0x180]
    1b40:      	tst	w22, #0x1
    1b44:      	fcsel	s7, s7, s23, ne
    1b48:      	mov.s	w22, v22[2]
    1b4c:      	add	x25, sp, #0x1d8
    1b50:      	bfxil	x25, x22, #0, #3
    1b54:      	add	x27, sp, #0x3c0
    1b58:      	orr	x22, x27, x22, lsl #2
    1b5c:      	ldrb	w25, [x25]
    1b60:      	and	w25, w13, w25
    1b64:      	stp	q5, q4, [x23, #0x160]
    1b68:      	ldr	s17, [x22]
    1b6c:      	tst	w25, #0x1
    1b70:      	fcsel	s17, s17, s23, ne
    1b74:      	mov.s	w22, v22[3]
    1b78:      	add	x25, sp, #0x1d8
    1b7c:      	bfxil	x25, x22, #0, #3
    1b80:      	add	x27, sp, #0x3a0
    1b84:      	orr	x22, x27, x22, lsl #2
    1b88:      	ldrb	w25, [x25]
    1b8c:      	and	w25, w14, w25
    1b90:      	stp	q5, q4, [x23, #0x140]
    1b94:      	ldr	s18, [x22]
    1b98:      	tst	w25, #0x1
    1b9c:      	fcsel	s18, s18, s23, ne
    1ba0:      	fmov	w22, s16
    1ba4:      	add	x25, sp, #0x1d8
    1ba8:      	bfxil	x25, x22, #0, #3
    1bac:      	ldrb	w25, [x25]
    1bb0:      	and	w25, w15, w25
    1bb4:      	stp	q5, q4, [x23, #0x120]
    1bb8:      	add	x27, sp, #0x380
    1bbc:      	ldr	s19, [x27, w22, uxtw #2]
    1bc0:      	tst	w25, #0x1
    1bc4:      	mov.s	w22, v16[1]
    1bc8:      	fcsel	s19, s19, s23, ne
    1bcc:      	add	x25, sp, #0x1d8
    1bd0:      	bfxil	x25, x22, #0, #3
    1bd4:      	ldrb	w25, [x25]
    1bd8:      	and	w25, w16, w25
    1bdc:      	stp	q5, q4, [x23, #0x100]
    1be0:      	add	x27, sp, #0x360
    1be4:      	ldr	s20, [x27, w22, uxtw #2]
    1be8:      	tst	w25, #0x1
    1bec:      	mov.s	w22, v16[2]
    1bf0:      	fcsel	s20, s20, s23, ne
    1bf4:      	add	x25, sp, #0x1d8
    1bf8:      	bfxil	x25, x22, #0, #3
    1bfc:      	ldrb	w25, [x25]
    1c00:      	and	w25, w17, w25
    1c04:      	stp	q5, q4, [x23, #0xe0]
    1c08:      	add	x27, sp, #0x340
    1c0c:      	ldr	s21, [x27, w22, uxtw #2]
    1c10:      	tst	w25, #0x1
    1c14:      	mov.s	w22, v16[3]
    1c18:      	fcsel	s16, s21, s23, ne
    1c1c:      	add	x25, sp, #0x1d8
    1c20:      	bfxil	x25, x22, #0, #3
    1c24:      	ldrb	w25, [x25]
    1c28:      	and	w25, w0, w25
    1c2c:      	stp	q5, q4, [x23, #0xc0]
    1c30:      	add	x27, sp, #0x320
    1c34:      	ldr	s21, [x27, w22, uxtw #2]
    1c38:      	tst	w25, #0x1
    1c3c:      	mov.s	v6[1], v7[0]
    1c40:      	mov.s	v6[2], v17[0]
    1c44:      	mov.s	v6[3], v18[0]
    1c48:      	mov.s	v19[1], v20[0]
    1c4c:      	fcsel	s7, s21, s23, ne
    1c50:      	mov.s	v19[2], v16[0]
    1c54:      	mov.s	v19[3], v7[0]
    1c58:      	fadd.4s	v4, v4, v19
    1c5c:      	fadd.4s	v5, v5, v6
    1c60:      	fmov	w22, s3
    1c64:      	add	x25, sp, #0x1d8
    1c68:      	bfxil	x25, x22, #0, #3
    1c6c:      	ldrb	w25, [x25]
    1c70:      	add	x27, sp, #0x300
    1c74:      	orr	x22, x27, x22, lsl #2
    1c78:      	stp	q5, q4, [x23, #0xa0]
    1c7c:      	ldr	s6, [x22]
    1c80:      	tst	w3, w25
    1c84:      	mov.s	w22, v3[1]
    1c88:      	add	x25, sp, #0x1d8
    1c8c:      	bfxil	x25, x22, #0, #3
    1c90:      	ldrb	w25, [x25]
    1c94:      	and	w12, w12, w25
    1c98:      	fcsel	s6, s6, s23, ne
    1c9c:      	add	x25, sp, #0x2e0
    1ca0:      	orr	x22, x25, x22, lsl #2
    1ca4:      	stp	q5, q4, [x23, #0x80]
    1ca8:      	ldr	s7, [x22]
    1cac:      	tst	w12, #0x1
    1cb0:      	mov.s	w12, v3[2]
    1cb4:      	add	x22, sp, #0x1d8
    1cb8:      	bfxil	x22, x12, #0, #3
    1cbc:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    1cc0:      	ldr	q16, [x12]
    1cc4:      	and.16b	v17, v0, v16
    1cc8:      	fcsel	s7, s7, s23, ne
    1ccc:      	ldrb	w12, [x22]
    1cd0:      	and	w12, w13, w12
    1cd4:      	str	q5, [x23, #0x60]
    1cd8:      	ldr	s16, [x23, #0x60]
    1cdc:      	tst	w12, #0x1
    1ce0:      	mov.s	w12, v3[3]
    1ce4:      	fcsel	s3, s16, s23, ne
    1ce8:      	add	x13, sp, #0x1d8
    1cec:      	bfxil	x13, x12, #0, #3
    1cf0:      	add	x22, sp, #0x2a0
    1cf4:      	orr	x12, x22, x12, lsl #2
    1cf8:      	ldrb	w13, [x13]
    1cfc:      	and	w13, w14, w13
    1d00:      	stp	q5, q4, [x23, #0x40]
    1d04:      	ldr	s16, [x12]
    1d08:      	tst	w13, #0x1
    1d0c:      	fcsel	s16, s16, s23, ne
    1d10:      	fmov	w12, s17
    1d14:      	add	x13, sp, #0x1d8
    1d18:      	bfxil	x13, x12, #0, #3
    1d1c:      	ldrb	w13, [x13]
    1d20:      	and	w13, w15, w13
    1d24:      	stp	q5, q4, [x23, #0x20]
    1d28:      	add	x14, sp, #0x280
    1d2c:      	ldr	s18, [x14, w12, uxtw #2]
    1d30:      	tst	w13, #0x1
    1d34:      	fcsel	s18, s18, s23, ne
    1d38:      	mov.s	w12, v17[1]
    1d3c:      	add	x13, sp, #0x1d8
    1d40:      	bfxil	x13, x12, #0, #3
    1d44:      	ldrb	w13, [x13]
    1d48:      	and	w13, w16, w13
    1d4c:      	stp	q5, q4, [x23]
    1d50:      	ldr	s19, [x23, w12, uxtw #2]
    1d54:      	tst	w13, #0x1
    1d58:      	fcsel	s19, s19, s23, ne
    1d5c:      	mov.s	w12, v17[2]
    1d60:      	add	x13, sp, #0x1d8
    1d64:      	bfxil	x13, x12, #0, #3
    1d68:      	ldrb	w13, [x13]
    1d6c:      	and	w13, w17, w13
    1d70:      	stp	q5, q4, [sp, #0x240]
    1d74:      	add	x14, sp, #0x240
    1d78:      	ldr	s20, [x14, w12, uxtw #2]
    1d7c:      	tst	w13, #0x1
    1d80:      	fcsel	s20, s20, s23, ne
    1d84:      	mov.s	w12, v17[3]
    1d88:      	add	x13, sp, #0x1d8
    1d8c:      	bfxil	x13, x12, #0, #3
    1d90:      	ldrb	w13, [x13]
    1d94:      	and	w13, w0, w13
    1d98:      	stp	q5, q4, [sp, #0x220]
    1d9c:      	add	x14, sp, #0x220
    1da0:      	ldr	s17, [x14, w12, uxtw #2]
    1da4:      	tst	w13, #0x1
    1da8:      	fcsel	s17, s17, s23, ne
    1dac:      	mov.s	v18[1], v19[0]
    1db0:      	mov.s	v18[2], v20[0]
    1db4:      	mov.s	v18[3], v17[0]
    1db8:      	mov.s	v6[1], v7[0]
    1dbc:      	movi.4s	v7, #0x4
    1dc0:      	and.16b	v7, v1, v7
    1dc4:      	mov.s	v6[2], v3[0]
    1dc8:      	mov.s	v6[3], v16[0]
    1dcc:      	fadd.4s	v3, v5, v6
    1dd0:      	fadd.4s	v4, v4, v18
    1dd4:      	fmov	w12, s7
    1dd8:      	add	x13, sp, #0x1d8
    1ddc:      	orr	x13, x13, x12
    1de0:      	ldrb	w13, [x13]
    1de4:      	stp	q3, q4, [sp, #0x200]
    1de8:      	add	x14, sp, #0x200
    1dec:      	ldr	s4, [x14, w12, uxtw #2]
    1df0:      	tst	w3, w13
    1df4:      	fcsel	s4, s4, s23, ne
    1df8:      	tst	w11, #0x1
    1dfc:      	fadd	s3, s3, s4
    1e00:      	fcsel	s4, s3, s23, ne
    1e04:      	tst	w1, #0x1
    1e08:      	fcsel	s5, s3, s23, ne
    1e0c:      	tst	w2, #0x1
    1e10:      	fcsel	s6, s3, s23, ne
    1e14:      	tst	w4, #0x1
    1e18:      	fcsel	s7, s3, s23, ne
    1e1c:      	tst	w5, #0x1
    1e20:      	fcsel	s16, s3, s23, ne
    1e24:      	tst	w6, #0x1
    1e28:      	fcsel	s17, s3, s23, ne
    1e2c:      	tst	w7, #0x1
    1e30:      	fcsel	s18, s3, s23, ne
    1e34:      	tst	w30, #0x1
    1e38:      	mov.s	v4[1], v5[0]
    1e3c:      	mov.s	v4[2], v6[0]
    1e40:      	mov.s	v4[3], v7[0]
    1e44:      	mov.s	v16[1], v17[0]
    1e48:      	mov.s	v16[2], v18[0]
    1e4c:      	fcsel	s3, s3, s23, ne
    1e50:      	mov.s	v16[3], v3[0]
    1e54:      	stp	q4, q16, [sp, #0x1e0]
    1e58:      	and	x10, x10, #0x7
    1e5c:      	add	x11, sp, #0x1e0
    1e60:      	ldr	s3, [x11, x10, lsl #2]
    1e64:      	fadd	s3, s3, s23
    1e68:      	add	x8, x8, x9
    1e6c:      	dup.4s	v3, v3[0]
    1e70:      	b	0x1e80 <ltmp0+0x1e80>
    1e74:      	add	x21, x21, #0x20
    1e78:      	cmp	x21, #0xc00
    1e7c:      	b.eq	0x120 <ltmp0+0x120>
    1e80:      	fmov	w10, s2
    1e84:      	add	x9, x26, x21
    1e88:      	ldp	q5, q4, [x9]
    1e8c:      	and.16b	v5, v1, v5
    1e90:      	fdiv.4s	v5, v5, v3
    1e94:      	add	x9, x8, x21
    1e98:      	tbnz	w10, #0x0, 0x1ec8 <ltmp0+0x1ec8>
    1e9c:      	and	w10, w10, #0xff
    1ea0:      	tbnz	w10, #0x1, 0x1ed4 <ltmp0+0x1ed4>
    1ea4:      	tbnz	w10, #0x2, 0x1ee0 <ltmp0+0x1ee0>
    1ea8:      	tbnz	w10, #0x3, 0x1eec <ltmp0+0x1eec>
    1eac:      	and.16b	v4, v0, v4
    1eb0:      	fdiv.4s	v4, v4, v3
    1eb4:      	tbnz	w10, #0x4, 0x1f00 <ltmp0+0x1f00>
    1eb8:      	tbnz	w10, #0x5, 0x1f08 <ltmp0+0x1f08>
    1ebc:      	tbnz	w10, #0x6, 0x1f14 <ltmp0+0x1f14>
    1ec0:      	tbz	w10, #0x7, 0x1e74 <ltmp0+0x1e74>
    1ec4:      	b	0x1f20 <ltmp0+0x1f20>
    1ec8:      	str	s5, [x9]
    1ecc:      	and	w10, w10, #0xff
    1ed0:      	tbz	w10, #0x1, 0x1ea4 <ltmp0+0x1ea4>
    1ed4:      	add	x11, x9, #0x4
    1ed8:      	st1.s	{ v5 }[1], [x11]
    1edc:      	tbz	w10, #0x2, 0x1ea8 <ltmp0+0x1ea8>
    1ee0:      	add	x11, x9, #0x8
    1ee4:      	st1.s	{ v5 }[2], [x11]
    1ee8:      	tbz	w10, #0x3, 0x1eac <ltmp0+0x1eac>
    1eec:      	add	x11, x9, #0xc
    1ef0:      	st1.s	{ v5 }[3], [x11]
    1ef4:      	and.16b	v4, v0, v4
    1ef8:      	fdiv.4s	v4, v4, v3
    1efc:      	tbz	w10, #0x4, 0x1eb8 <ltmp0+0x1eb8>
    1f00:      	str	s4, [x9, #0x10]
    1f04:      	tbz	w10, #0x5, 0x1ebc <ltmp0+0x1ebc>
    1f08:      	add	x11, x9, #0x14
    1f0c:      	st1.s	{ v4 }[1], [x11]
    1f10:      	tbz	w10, #0x6, 0x1ec0 <ltmp0+0x1ec0>
    1f14:      	add	x11, x9, #0x18
    1f18:      	st1.s	{ v4 }[2], [x11]
    1f1c:      	tbz	w10, #0x7, 0x1e74 <ltmp0+0x1e74>
    1f20:      	add	x9, x9, #0x1c
    1f24:      	st1.s	{ v4 }[3], [x9]
    1f28:      	b	0x1e74 <ltmp0+0x1e74>
    1f2c:      	ldr	x9, [sp, #0x8]
    1f30:      	stp	w15, w14, [x9]
    1f34:      	str	w13, [x9, #0x8]
    1f38:      	mov	w8, #0x18               ; =24
    1f3c:      	str	w8, [x9, #0x24]
    1f40:      	add	sp, sp, #0x4, lsl #12   ; =0x4000
    1f44:      	add	sp, sp, #0x660
    1f48:      	ldp	x29, x30, [sp, #0x90]
    1f4c:      	ldp	x20, x19, [sp, #0x80]
    1f50:      	ldp	x22, x21, [sp, #0x70]
    1f54:      	ldp	x24, x23, [sp, #0x60]
    1f58:      	ldp	x26, x25, [sp, #0x50]
    1f5c:      	ldp	x28, x27, [sp, #0x40]
    1f60:      	ldp	d9, d8, [sp, #0x30]
    1f64:      	ldp	d11, d10, [sp, #0x20]
    1f68:      	ldp	d13, d12, [sp, #0x10]
    1f6c:      	ldp	d15, d14, [sp], #0xa0
    1f70:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/capture/rmsnorm-1024x4097/on/object/tile_xir_w8_36302_1788935093370272_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      2c:      	sub	sp, sp, #0x410
      30:      	str	x0, [sp, #0x60]
      34:      	str	w3, [sp, #0x78]
      38:      	cbz	w3, 0x1204 <ltmp0+0x1204>
      3c:      	mov	w12, #0x0               ; =0
      40:      	add	x26, sp, #0x4, lsl #12  ; =0x4000
      44:      	add	x26, x26, #0x3f0
      48:      	ldp	w9, w8, [x2, #0x2c]
      4c:      	stp	w8, w9, [sp, #0x70]
      50:      	add	x19, sp, #0x3d0
      54:      	ldp	w8, w9, [x2]
      58:      	ldp	w10, w11, [x2, #0x8]
      5c:      	str	x2, [sp, #0x8]
      60:      	str	x11, [sp, #0x68]
      64:      	movi	d8, #0000000000000000
      68:      	b	0xb4 <ltmp0+0xb4>
      6c:      	ldr	x15, [sp, #0x88]
      70:      	add	w8, w15, #0x1
      74:      	ldp	w11, w9, [sp, #0x70]
      78:      	cmp	w8, w9
      7c:      	cset	w9, eq
      80:      	csinc	w8, wzr, w15, eq
      84:      	ldp	w14, w13, [sp, #0x7c]
      88:      	cinc	w10, w14, eq
      8c:      	cmp	w10, w11
      90:      	cset	w11, eq
      94:      	ands	w11, w9, w11
      98:      	csel	w9, wzr, w10, ne
      9c:      	add	w10, w13, w11
      a0:      	ldr	w12, [sp, #0x84]
      a4:      	add	w12, w12, #0x1
      a8:      	ldr	w11, [sp, #0x78]
      ac:      	cmp	w12, w11
      b0:      	b.eq	0x11f0 <ltmp0+0x11f0>
      b4:      	stp	w10, w12, [sp, #0x80]
      b8:      	mov	x14, x9
      bc:      	mov	x15, x8
      c0:      	ubfiz	x8, x8, #5, #32
      c4:      	ldr	x13, [sp, #0x68]
      c8:      	cmp	x8, x13
      cc:      	csel	x9, x8, xzr, ls
      d0:      	subs	x10, x13, x9
      d4:      	cmp	x10, #0x20
      d8:      	mov	w11, #0x20              ; =32
      dc:      	csel	x10, x10, x11, lo
      e0:      	cmp	x13, x9
      e4:      	ccmp	x8, x13, #0x2, hi
      e8:      	csel	x9, x10, xzr, ls
      ec:      	cmp	x9, #0x20
      f0:      	str	w14, [sp, #0x7c]
      f4:      	str	x15, [sp, #0x88]
      f8:      	b.lo	0x330 <ltmp0+0x330>
      fc:      	mov	x20, #0x0               ; =0
     100:      	ldr	x8, [sp, #0x60]
     104:      	ldr	x28, [x8]
     108:      	ldr	x22, [x8, #0x10]
     10c:      	ldr	x21, [x8, #0x30]
     110:      	add	x23, x22, #0x4, lsl #12 ; =0x4000
     114:      	lsl	w27, w15, #2
     118:      	and	x8, x15, #0x7ffffff
     11c:      	mov	w9, #0x10               ; =16
     120:      	movk	w9, #0x1, lsl #16
     124:      	umaddl	x24, w8, w9, x21
     128:      	add	w8, w20, w27
     12c:      	and	x8, x8, #0x1fffffff
     130:      	add	x8, x8, x8, lsl #12
     134:      	lsl	x25, x8, #2
     138:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     13c:      	add	x0, x0, #0x3f0
     140:      	add	x1, x28, x25
     144:      	mov	w2, #0x4000             ; =16384
     148:      	bl	0x148 <ltmp0+0x148>
     14c:      	mov	x8, #0x0                ; =0
     150:      	add	x25, x25, #0x4, lsl #12 ; =0x4000
     154:      	ldr	s0, [x28, x25]
     158:      	str	q0, [sp, #0x110]
     15c:      	ldr	q1, [sp, #0x130]
     160:      	mov.s	v1[0], v0[0]
     164:      	str	q0, [sp, #0x8400]
     168:      	str	q1, [sp, #0x130]
     16c:      	str	q1, [sp, #0x83f0]
     170:      	ldr	q0, [sp, #0x43f0]
     174:      	ldr	q1, [sp, #0x4400]
     178:      	fmul.4s	v3, v1, v1
     17c:      	fmul.4s	v2, v0, v0
     180:      	ldr	q0, [sp, #0x4410]
     184:      	ldr	q1, [sp, #0x4420]
     188:      	fmul.4s	v5, v1, v1
     18c:      	fmul.4s	v4, v0, v0
     190:      	ldr	q0, [sp, #0x4430]
     194:      	ldr	q1, [sp, #0x4440]
     198:      	fmul.4s	v6, v1, v1
     19c:      	fmul.4s	v7, v0, v0
     1a0:      	ldr	q0, [sp, #0x4450]
     1a4:      	ldr	q1, [sp, #0x4460]
     1a8:      	fmul.4s	v17, v1, v1
     1ac:      	fmul.4s	v16, v0, v0
     1b0:      	add	x9, x26, x8, lsl #5
     1b4:      	ldp	q1, q0, [x9, #0x80]
     1b8:      	fmul.4s	v1, v1, v1
     1bc:      	fmul.4s	v0, v0, v0
     1c0:      	fadd.4s	v3, v3, v0
     1c4:      	fadd.4s	v2, v2, v1
     1c8:      	ldp	q1, q0, [x9, #0xa0]
     1cc:      	fmul.4s	v1, v1, v1
     1d0:      	fmul.4s	v0, v0, v0
     1d4:      	fadd.4s	v5, v5, v0
     1d8:      	fadd.4s	v4, v4, v1
     1dc:      	ldp	q1, q0, [x9, #0xc0]
     1e0:      	fmul.4s	v1, v1, v1
     1e4:      	fmul.4s	v0, v0, v0
     1e8:      	fadd.4s	v6, v6, v0
     1ec:      	fadd.4s	v7, v7, v1
     1f0:      	ldp	q1, q0, [x9, #0xe0]
     1f4:      	fmul.4s	v1, v1, v1
     1f8:      	fmul.4s	v0, v0, v0
     1fc:      	fadd.4s	v17, v17, v0
     200:      	fadd.4s	v16, v16, v1
     204:      	add	x8, x8, #0x4
     208:      	cmp	x8, #0x1fc
     20c:      	b.lo	0x1b0 <ltmp0+0x1b0>
     210:      	add	x0, sp, #0x3d0
     214:      	mov	x1, x22
     218:      	mov	w2, #0x4000             ; =16384
     21c:      	stp	q2, q5, [sp, #0x90]
     220:      	stp	q3, q7, [sp, #0xb0]
     224:      	stp	q4, q17, [sp, #0xd0]
     228:      	stp	q6, q16, [sp, #0xf0]
     22c:      	bl	0x22c <ltmp0+0x22c>
     230:      	mov	x8, #0x0                ; =0
     234:      	ldr	q0, [sp, #0x110]
     238:      	fmul.4s	v0, v0, v0
     23c:      	ldp	q1, q2, [sp, #0x90]
     240:      	fadd.4s	v0, v0, v1
     244:      	mov.s	v1[0], v0[0]
     248:      	ldr	q0, [sp, #0xb0]
     24c:      	fadd.4s	v0, v2, v0
     250:      	ldp	q2, q3, [sp, #0xc0]
     254:      	fadd.4s	v1, v3, v1
     258:      	fadd.4s	v1, v2, v1
     25c:      	ldp	q2, q3, [sp, #0xe0]
     260:      	fadd.4s	v0, v3, v0
     264:      	fadd.4s	v0, v2, v0
     268:      	ldr	q2, [sp, #0x100]
     26c:      	fadd.4s	v1, v2, v1
     270:      	rev64.4s	v2, v1
     274:      	rev64.4s	v3, v0
     278:      	fadd.4s	v1, v1, v2
     27c:      	dup.4s	v2, v1[2]
     280:      	fadd.4s	v0, v0, v3
     284:      	dup.4s	v3, v0[2]
     288:      	fadd.4s	v0, v0, v3
     28c:      	fadd.4s	v1, v1, v2
     290:      	fadd.4s	v0, v1, v0
     294:      	fadd	s0, s0, s8
     298:      	mov	w9, #0x800              ; =2048
     29c:      	movk	w9, #0x4580, lsl #16
     2a0:      	fmov	s1, w9
     2a4:      	fdiv	s0, s0, s1
     2a8:      	ldr	q6, [sp, #0x120]
     2ac:      	ld1.s	{ v6 }[0], [x23]
     2b0:      	str	q0, [sp, #0x43e0]
     2b4:      	str	q6, [sp, #0x43d0]
     2b8:      	mov	w9, #0xc5ac             ; =50604
     2bc:      	movk	w9, #0x3727, lsl #16
     2c0:      	fmov	s1, w9
     2c4:      	fadd	s0, s0, s1
     2c8:      	fsqrt	s0, s0
     2cc:      	dup.4s	v1, v0[0]
     2d0:      	add	x9, x26, x8
     2d4:      	ldp	q2, q3, [x9]
     2d8:      	fdiv.4s	v3, v3, v1
     2dc:      	fdiv.4s	v2, v2, v1
     2e0:      	add	x9, x19, x8
     2e4:      	ldp	q5, q4, [x9]
     2e8:      	fmul.4s	v2, v2, v5
     2ec:      	fmul.4s	v3, v3, v4
     2f0:      	add	x9, x24, x8
     2f4:      	stp	q2, q3, [x9]
     2f8:      	add	x8, x8, #0x20
     2fc:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     300:      	b.ne	0x2d0 <ltmp0+0x2d0>
     304:      	ldr	q1, [sp, #0x130]
     308:      	fdiv.4s	v0, v1, v0
     30c:      	str	q6, [sp, #0x120]
     310:      	fmul.4s	v0, v0, v6
     314:      	str	s0, [x21, x25]
     318:      	add	x20, x20, #0x1
     31c:      	mov	w8, #0x4004             ; =16388
     320:      	add	x24, x24, x8
     324:      	cmp	x20, #0x4
     328:      	b.ne	0x128 <ltmp0+0x128>
     32c:      	b	0x6c <ltmp0+0x6c>
     330:      	lsr	x8, x9, #3
     334:      	str	x8, [sp, #0xa0]
     338:      	str	x9, [sp, #0x90]
     33c:      	cmp	x9, #0x8
     340:      	b.lo	0x55c <ltmp0+0x55c>
     344:      	mov	x21, #0x0               ; =0
     348:      	ldr	x8, [sp, #0x60]
     34c:      	ldr	x23, [x8]
     350:      	ldr	x22, [x8, #0x10]
     354:      	ldr	x27, [x8, #0x30]
     358:      	add	x24, x22, #0x4, lsl #12 ; =0x4000
     35c:      	ldr	x8, [sp, #0x88]
     360:      	lsl	w25, w8, #2
     364:      	and	x8, x8, #0x7ffffff
     368:      	mov	w9, #0x10               ; =16
     36c:      	movk	w9, #0x1, lsl #16
     370:      	umaddl	x28, w8, w9, x27
     374:      	add	w8, w21, w25
     378:      	and	x8, x8, #0x1fffffff
     37c:      	add	x8, x8, x8, lsl #12
     380:      	lsl	x20, x8, #2
     384:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     388:      	add	x0, x0, #0x3f0
     38c:      	add	x1, x23, x20
     390:      	mov	w2, #0x4000             ; =16384
     394:      	bl	0x394 <ltmp0+0x394>
     398:      	mov	x8, #0x0                ; =0
     39c:      	add	x20, x20, #0x4, lsl #12 ; =0x4000
     3a0:      	ldr	s0, [x23, x20]
     3a4:      	str	q0, [sp, #0x130]
     3a8:      	str	q0, [sp, #0x83f0]
     3ac:      	ldr	q0, [sp, #0x43f0]
     3b0:      	ldr	q1, [sp, #0x4400]
     3b4:      	fmul.4s	v3, v1, v1
     3b8:      	fmul.4s	v2, v0, v0
     3bc:      	ldr	q0, [sp, #0x4410]
     3c0:      	ldr	q1, [sp, #0x4420]
     3c4:      	fmul.4s	v5, v1, v1
     3c8:      	fmul.4s	v4, v0, v0
     3cc:      	ldr	q0, [sp, #0x4430]
     3d0:      	ldr	q1, [sp, #0x4440]
     3d4:      	fmul.4s	v6, v1, v1
     3d8:      	fmul.4s	v7, v0, v0
     3dc:      	ldr	q0, [sp, #0x4450]
     3e0:      	ldr	q1, [sp, #0x4460]
     3e4:      	fmul.4s	v17, v1, v1
     3e8:      	fmul.4s	v16, v0, v0
     3ec:      	add	x9, x26, x8, lsl #5
     3f0:      	ldp	q1, q0, [x9, #0x80]
     3f4:      	fmul.4s	v1, v1, v1
     3f8:      	fmul.4s	v0, v0, v0
     3fc:      	fadd.4s	v3, v3, v0
     400:      	fadd.4s	v2, v2, v1
     404:      	ldp	q1, q0, [x9, #0xa0]
     408:      	fmul.4s	v1, v1, v1
     40c:      	fmul.4s	v0, v0, v0
     410:      	fadd.4s	v5, v5, v0
     414:      	fadd.4s	v4, v4, v1
     418:      	ldp	q1, q0, [x9, #0xc0]
     41c:      	fmul.4s	v1, v1, v1
     420:      	fmul.4s	v0, v0, v0
     424:      	fadd.4s	v6, v6, v0
     428:      	fadd.4s	v7, v7, v1
     42c:      	ldp	q1, q0, [x9, #0xe0]
     430:      	fmul.4s	v1, v1, v1
     434:      	fmul.4s	v0, v0, v0
     438:      	fadd.4s	v17, v17, v0
     43c:      	fadd.4s	v16, v16, v1
     440:      	add	x8, x8, #0x4
     444:      	cmp	x8, #0x1fc
     448:      	b.lo	0x3ec <ltmp0+0x3ec>
     44c:      	add	x0, sp, #0x3d0
     450:      	mov	x1, x22
     454:      	mov	w2, #0x4000             ; =16384
     458:      	stp	q2, q5, [sp, #0xb0]
     45c:      	stp	q3, q7, [sp, #0xd0]
     460:      	stp	q4, q17, [sp, #0xf0]
     464:      	stp	q6, q16, [sp, #0x110]
     468:      	bl	0x468 <ltmp0+0x468>
     46c:      	mov	x8, #0x0                ; =0
     470:      	ldr	q7, [sp, #0x130]
     474:      	fmul.4s	v0, v7, v7
     478:      	ldp	q1, q2, [sp, #0xb0]
     47c:      	fadd.4s	v0, v0, v1
     480:      	mov.s	v1[0], v0[0]
     484:      	ldr	q0, [sp, #0xd0]
     488:      	fadd.4s	v0, v2, v0
     48c:      	ldp	q2, q3, [sp, #0xe0]
     490:      	fadd.4s	v1, v3, v1
     494:      	fadd.4s	v1, v2, v1
     498:      	ldp	q2, q3, [sp, #0x100]
     49c:      	fadd.4s	v0, v3, v0
     4a0:      	fadd.4s	v0, v2, v0
     4a4:      	ldr	q2, [sp, #0x120]
     4a8:      	fadd.4s	v1, v2, v1
     4ac:      	rev64.4s	v2, v1
     4b0:      	rev64.4s	v3, v0
     4b4:      	fadd.4s	v0, v0, v3
     4b8:      	fadd.4s	v1, v1, v2
     4bc:      	dup.4s	v2, v1[2]
     4c0:      	dup.4s	v3, v0[2]
     4c4:      	fadd.4s	v0, v0, v3
     4c8:      	fadd.4s	v1, v1, v2
     4cc:      	fadd.4s	v0, v1, v0
     4d0:      	fadd	s0, s0, s8
     4d4:      	mov	w9, #0x800              ; =2048
     4d8:      	movk	w9, #0x4580, lsl #16
     4dc:      	fmov	s1, w9
     4e0:      	fdiv	s1, s0, s1
     4e4:      	ldr	s0, [x24]
     4e8:      	str	q0, [sp, #0x43d0]
     4ec:      	mov	w9, #0xc5ac             ; =50604
     4f0:      	movk	w9, #0x3727, lsl #16
     4f4:      	fmov	s2, w9
     4f8:      	fadd	s1, s1, s2
     4fc:      	fsqrt	s1, s1
     500:      	dup.4s	v2, v1[0]
     504:      	add	x9, x26, x8
     508:      	ldp	q3, q4, [x9]
     50c:      	fdiv.4s	v4, v4, v2
     510:      	fdiv.4s	v3, v3, v2
     514:      	add	x9, x19, x8
     518:      	ldp	q6, q5, [x9]
     51c:      	fmul.4s	v3, v3, v6
     520:      	fmul.4s	v4, v4, v5
     524:      	add	x9, x28, x8
     528:      	stp	q3, q4, [x9]
     52c:      	add	x8, x8, #0x20
     530:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     534:      	b.ne	0x504 <ltmp0+0x504>
     538:      	fdiv.4s	v1, v7, v1
     53c:      	fmul.4s	v0, v1, v0
     540:      	str	s0, [x27, x20]
     544:      	add	x21, x21, #0x1
     548:      	mov	w8, #0x4004             ; =16388
     54c:      	add	x28, x28, x8
     550:      	ldr	x8, [sp, #0xa0]
     554:      	cmp	x21, x8
     558:      	b.ne	0x374 <ltmp0+0x374>
     55c:      	ldr	x8, [sp, #0x90]
     560:      	and	w8, w8, #0x7
     564:      	cbz	w8, 0x6c <ltmp0+0x6c>
     568:      	dup.4s	v1, w8
     56c:      	adrp	x8, 0x0 <ltmp0>
     570:      	ldr	q2, [x8]
     574:      	adrp	x8, 0x0 <ltmp0>
     578:      	ldr	q0, [x8]
     57c:      	cmhi.4s	v0, v1, v0
     580:      	cmhi.4s	v1, v1, v2
     584:      	uzp1.8h	v3, v1, v0
     588:      	umaxv.8h	h2, v3
     58c:      	fmov	w8, s2
     590:      	tbz	w8, #0x0, 0x6c <ltmp0+0x6c>
     594:      	mov	x9, #0x0                ; =0
     598:      	ldr	x8, [sp, #0x60]
     59c:      	ldr	x12, [x8]
     5a0:      	ldr	x10, [x8, #0x10]
     5a4:      	ldr	x8, [x8, #0x30]
     5a8:      	adrp	x11, 0x0 <ltmp0>
     5ac:      	ldr	q2, [x11]
     5b0:      	str	q3, [sp, #0x90]
     5b4:      	and.16b	v2, v3, v2
     5b8:      	addv.8h	h2, v2
     5bc:      	ldr	x11, [sp, #0x88]
     5c0:      	ubfiz	w11, w11, #2, #27
     5c4:      	ldr	x13, [sp, #0xa0]
     5c8:      	orr	w13, w11, w13
     5cc:      	fmov	w11, s2
     5d0:      	and	w11, w11, #0xff
     5d4:      	dup.4s	v3, w13
     5d8:      	and.16b	v4, v1, v3
     5dc:      	and.16b	v3, v0, v3
     5e0:      	ushll2.2d	v7, v3, #0x0
     5e4:      	ushll2.2d	v16, v4, #0x0
     5e8:      	ushll.2d	v17, v3, #0x0
     5ec:      	ushll.2d	v3, v4, #0x0
     5f0:      	fmov	x13, d3
     5f4:      	mov	w14, #0x4004            ; =16388
     5f8:      	umaddl	x13, w13, w14, x12
     5fc:      	b	0x620 <ltmp0+0x620>
     600:      	add	x14, x26, x9
     604:      	ldp	q6, q18, [x14]
     608:      	bif.16b	v5, v18, v0
     60c:      	bif.16b	v4, v6, v1
     610:      	stp	q4, q5, [x14]
     614:      	add	x9, x9, #0x20
     618:      	cmp	x9, #0x4, lsl #12       ; =0x4000
     61c:      	b.eq	0x6b8 <ltmp0+0x6b8>
     620:      	fmov	w15, s2
     624:      	add	x14, x13, x9
     628:      	movi.2d	v4, #0000000000000000
     62c:      	movi.2d	v5, #0000000000000000
     630:      	tbnz	w15, #0x0, 0x658 <ltmp0+0x658>
     634:      	and	w15, w15, #0xff
     638:      	tbnz	w15, #0x1, 0x664 <ltmp0+0x664>
     63c:      	tbnz	w15, #0x2, 0x670 <ltmp0+0x670>
     640:      	tbnz	w15, #0x3, 0x67c <ltmp0+0x67c>
     644:      	tbnz	w15, #0x4, 0x688 <ltmp0+0x688>
     648:      	tbnz	w15, #0x5, 0x694 <ltmp0+0x694>
     64c:      	tbnz	w15, #0x6, 0x6a0 <ltmp0+0x6a0>
     650:      	tbz	w15, #0x7, 0x600 <ltmp0+0x600>
     654:      	b	0x6ac <ltmp0+0x6ac>
     658:      	ldr	s4, [x14]
     65c:      	and	w15, w15, #0xff
     660:      	tbz	w15, #0x1, 0x63c <ltmp0+0x63c>
     664:      	add	x16, x14, #0x4
     668:      	ld1.s	{ v4 }[1], [x16]
     66c:      	tbz	w15, #0x2, 0x640 <ltmp0+0x640>
     670:      	add	x16, x14, #0x8
     674:      	ld1.s	{ v4 }[2], [x16]
     678:      	tbz	w15, #0x3, 0x644 <ltmp0+0x644>
     67c:      	add	x16, x14, #0xc
     680:      	ld1.s	{ v4 }[3], [x16]
     684:      	tbz	w15, #0x4, 0x648 <ltmp0+0x648>
     688:      	add	x16, x14, #0x10
     68c:      	ld1.s	{ v5 }[0], [x16]
     690:      	tbz	w15, #0x5, 0x64c <ltmp0+0x64c>
     694:      	add	x16, x14, #0x14
     698:      	ld1.s	{ v5 }[1], [x16]
     69c:      	tbz	w15, #0x6, 0x650 <ltmp0+0x650>
     6a0:      	add	x16, x14, #0x18
     6a4:      	ld1.s	{ v5 }[2], [x16]
     6a8:      	tbz	w15, #0x7, 0x600 <ltmp0+0x600>
     6ac:      	add	x14, x14, #0x1c
     6b0:      	ld1.s	{ v5 }[3], [x14]
     6b4:      	b	0x600 <ltmp0+0x600>
     6b8:      	xtn.4h	v4, v1
     6bc:      	uzp1.8b	v4, v4, v0
     6c0:      	sshll.2d	v18, v1, #0x0
     6c4:      	adrp	x9, 0x0 <ltmp0>
     6c8:      	ldr	q5, [x9]
     6cc:      	and.16b	v19, v18, v5
     6d0:      	movi.2d	v6, #0000000000000000
     6d4:      	mov.b	v6[0], v4[0]
     6d8:      	adrp	x9, 0x0 <ltmp0>
     6dc:      	ldr	d5, [x9]
     6e0:      	str	d5, [sp, #0xc0]
     6e4:      	and.8b	v5, v6, v5
     6e8:      	addv.8b	b5, v5
     6ec:      	fmov	w13, s5
     6f0:      	umaxv.8b	b5, v6
     6f4:      	fmov	w14, s5
     6f8:      	rbit	w9, w13
     6fc:      	clz	w9, w9
     700:      	tst	w14, #0x1
     704:      	csel	w9, w9, wzr, ne
     708:      	mov	w15, #0x1000            ; =4096
     70c:      	dup.2d	v20, x15
     710:      	str	q19, [sp, #0x40]
     714:      	orr.16b	v5, v19, v20
     718:      	mov	w15, #0x1001            ; =4097
     71c:      	dup.2s	v19, w15
     720:      	xtn.2s	v23, v3
     724:      	str	q5, [sp, #0xd0]
     728:      	umlal.2d	v5, v23, v19
     72c:      	movi.2d	v3, #0000000000000000
     730:      	mov.b	v3[0], v4[0]
     734:      	ushll.2d	v3, v3, #0x0
     738:      	shl.2d	v3, v3, #0x3f
     73c:      	cmlt.2d	v3, v3, #0
     740:      	str	q5, [sp, #0x130]
     744:      	and.16b	v3, v3, v5
     748:      	movi.2d	v4, #0000000000000000
     74c:      	stp	q4, q4, [sp, #0x3a0]
     750:      	stp	q3, q4, [sp, #0x380]
     754:      	and	x15, x9, #0x7
     758:      	add	x16, sp, #0x380
     75c:      	ldr	x15, [x16, x15, lsl #3]
     760:      	sub	x15, x15, x9
     764:      	add	x12, x12, x15, lsl #2
     768:      	movi.2d	v5, #0000000000000000
     76c:      	movi.2d	v3, #0000000000000000
     770:      	tbnz	w14, #0x0, 0x10e4 <ltmp0+0x10e4>
     774:      	tbnz	w13, #0x1, 0x10ec <ltmp0+0x10ec>
     778:      	mov	w15, #0x4               ; =4
     77c:      	tbnz	w13, #0x2, 0x10fc <ltmp0+0x10fc>
     780:      	tbnz	w13, #0x3, 0x1108 <ltmp0+0x1108>
     784:      	tbnz	w13, #0x4, 0x1114 <ltmp0+0x1114>
     788:      	tbnz	w13, #0x5, 0x1120 <ltmp0+0x1120>
     78c:      	tbnz	w13, #0x6, 0x112c <ltmp0+0x112c>
     790:      	tbz	w13, #0x7, 0x79c <ltmp0+0x79c>
     794:      	add	x12, x12, #0x1c
     798:      	ld1.s	{ v3 }[3], [x12]
     79c:      	sshll.2d	v4, v0, #0x0
     7a0:      	sshll2.2d	v21, v1, #0x0
     7a4:      	sshll2.2d	v22, v0, #0x0
     7a8:      	adrp	x12, 0x0 <ltmp0>
     7ac:      	ldr	q24, [x12]
     7b0:      	and.16b	v29, v22, v24
     7b4:      	adrp	x12, 0x0 <ltmp0>
     7b8:      	ldr	q24, [x12]
     7bc:      	and.16b	v28, v21, v24
     7c0:      	adrp	x12, 0x0 <ltmp0>
     7c4:      	ldr	q24, [x12]
     7c8:      	and.16b	v26, v4, v24
     7cc:      	adrp	x12, 0x0 <ltmp0>
     7d0:      	ldr	q24, [x12]
     7d4:      	and.16b	v24, v22, v24
     7d8:      	adrp	x12, 0x0 <ltmp0>
     7dc:      	ldr	q25, [x12]
     7e0:      	and.16b	v25, v21, v25
     7e4:      	adrp	x12, 0x0 <ltmp0>
     7e8:      	ldr	q27, [x12]
     7ec:      	and.16b	v27, v4, v27
     7f0:      	adrp	x12, 0x0 <ltmp0>
     7f4:      	ldr	q4, [x12]
     7f8:      	and.16b	v4, v18, v4
     7fc:      	stp	q26, q28, [sp, #0x10]
     800:      	orr.16b	v26, v26, v20
     804:      	orr.16b	v28, v28, v20
     808:      	str	q29, [sp, #0x30]
     80c:      	orr.16b	v20, v29, v20
     810:      	umull.2d	v29, v23, v19
     814:      	xtn.2s	v16, v16
     818:      	xtn.2s	v17, v17
     81c:      	xtn.2s	v7, v7
     820:      	stp	q26, q20, [sp, #0xa0]
     824:      	mov.16b	v18, v20
     828:      	umlal.2d	v18, v7, v19
     82c:      	str	q28, [sp, #0x50]
     830:      	mov.16b	v7, v28
     834:      	umlal.2d	v7, v16, v19
     838:      	stp	q7, q18, [sp, #0x100]
     83c:      	mov.16b	v7, v26
     840:      	umlal.2d	v7, v17, v19
     844:      	stp	q29, q7, [sp, #0xe0]
     848:      	sshll.2d	v7, v1, #0x0
     84c:      	sshll.2d	v18, v0, #0x0
     850:      	stp	q4, q25, [sp, #0x340]
     854:      	stp	q27, q24, [sp, #0x360]
     858:      	and	x12, x9, #0x7
     85c:      	add	x14, sp, #0x340
     860:      	ldr	x12, [x14, x12, lsl #3]
     864:      	orr	x12, x12, #0x4000
     868:      	sub	x12, x12, x9, lsl #2
     86c:      	tst	w13, #0xff
     870:      	csel	x12, xzr, x12, eq
     874:      	add	x13, x26, x12
     878:      	ldp	q16, q17, [x13]
     87c:      	zip2.8b	v19, v6, v0
     880:      	ushll.4s	v19, v19, #0x0
     884:      	shl.4s	v19, v19, #0x1f
     888:      	cmlt.4s	v19, v19, #0
     88c:      	str	q3, [sp, #0x120]
     890:      	bit.16b	v17, v3, v19
     894:      	zip1.8b	v19, v6, v0
     898:      	ushll.4s	v19, v19, #0x0
     89c:      	shl.4s	v19, v19, #0x1f
     8a0:      	cmlt.4s	v19, v19, #0
     8a4:      	mov.16b	v3, v5
     8a8:      	bit.16b	v16, v5, v19
     8ac:      	stp	q16, q17, [x13]
     8b0:      	dup.2d	v19, x15
     8b4:      	and.16b	v16, v22, v19
     8b8:      	and.16b	v17, v21, v19
     8bc:      	and.16b	v23, v18, v19
     8c0:      	and.16b	v24, v7, v19
     8c4:      	fmov	x13, d24
     8c8:      	ldr	q7, [sp, #0x4460]
     8cc:      	ldr	q18, [sp, #0x4450]
     8d0:      	fmul.4s	v18, v18, v18
     8d4:      	fmul.4s	v7, v7, v7
     8d8:      	and.16b	v10, v0, v7
     8dc:      	and.16b	v11, v1, v18
     8e0:      	ldr	q7, [sp, #0x4440]
     8e4:      	ldr	q18, [sp, #0x4430]
     8e8:      	fmul.4s	v18, v18, v18
     8ec:      	fmul.4s	v7, v7, v7
     8f0:      	and.16b	v13, v0, v7
     8f4:      	and.16b	v12, v1, v18
     8f8:      	ldr	q7, [sp, #0x4420]
     8fc:      	ldr	q18, [sp, #0x4410]
     900:      	fmul.4s	v18, v18, v18
     904:      	fmul.4s	v7, v7, v7
     908:      	and.16b	v14, v0, v7
     90c:      	and.16b	v15, v1, v18
     910:      	fmov	x14, d4
     914:      	add	x14, x26, x14
     918:      	ldp	q7, q4, [x14]
     91c:      	fmul.4s	v7, v7, v7
     920:      	fmul.4s	v4, v4, v4
     924:      	and.16b	v19, v0, v4
     928:      	and.16b	v18, v1, v7
     92c:      	sshll.2d	v4, v1, #0x0
     930:      	sshll.2d	v25, v0, #0x0
     934:      	add	x13, x26, x13, lsl #5
     938:      	ldp	q20, q7, [x13]
     93c:      	and.16b	v20, v1, v20
     940:      	and.16b	v7, v0, v7
     944:      	fmul.4s	v7, v7, v7
     948:      	fmul.4s	v20, v20, v20
     94c:      	fadd.4s	v20, v18, v20
     950:      	fadd.4s	v7, v19, v7
     954:      	ldp	q28, q27, [x13, #0x20]
     958:      	and.16b	v28, v1, v28
     95c:      	and.16b	v27, v0, v27
     960:      	fmul.4s	v27, v27, v27
     964:      	fmul.4s	v28, v28, v28
     968:      	fadd.4s	v28, v15, v28
     96c:      	fadd.4s	v27, v14, v27
     970:      	ldp	q5, q29, [x13, #0x40]
     974:      	and.16b	v5, v1, v5
     978:      	and.16b	v29, v0, v29
     97c:      	fmul.4s	v29, v29, v29
     980:      	fmul.4s	v5, v5, v5
     984:      	fadd.4s	v5, v12, v5
     988:      	fadd.4s	v29, v13, v29
     98c:      	ldp	q31, q30, [x13, #0x60]
     990:      	and.16b	v31, v1, v31
     994:      	and.16b	v30, v0, v30
     998:      	fmul.4s	v30, v30, v30
     99c:      	fmul.4s	v31, v31, v31
     9a0:      	fadd.4s	v31, v11, v31
     9a4:      	fadd.4s	v30, v10, v30
     9a8:      	dup.2d	v9, x15
     9ac:      	and.16b	v26, v22, v9
     9b0:      	add.2d	v16, v16, v26
     9b4:      	and.16b	v26, v21, v9
     9b8:      	add.2d	v17, v17, v26
     9bc:      	and.16b	v25, v25, v9
     9c0:      	add.2d	v23, v23, v25
     9c4:      	and.16b	v4, v4, v9
     9c8:      	add.2d	v24, v24, v4
     9cc:      	bit.16b	v19, v7, v0
     9d0:      	bit.16b	v18, v20, v1
     9d4:      	bit.16b	v14, v27, v0
     9d8:      	bit.16b	v15, v28, v1
     9dc:      	bit.16b	v13, v29, v0
     9e0:      	bit.16b	v12, v5, v1
     9e4:      	bit.16b	v10, v30, v0
     9e8:      	bit.16b	v11, v31, v1
     9ec:      	fmov	x13, d24
     9f0:      	cmp	x13, #0x200
     9f4:      	b.lt	0x92c <ltmp0+0x92c>
     9f8:      	mov	x13, #0x0               ; =0
     9fc:      	mov	w14, #0x1               ; =1
     a00:      	dup.2d	v4, x14
     a04:      	ushll2.2d	v5, v0, #0x0
     a08:      	and.16b	v21, v5, v4
     a0c:      	ushll2.2d	v5, v1, #0x0
     a10:      	and.16b	v22, v5, v4
     a14:      	ushll.2d	v5, v0, #0x0
     a18:      	and.16b	v23, v5, v4
     a1c:      	ushll.2d	v5, v1, #0x0
     a20:      	and.16b	v24, v5, v4
     a24:      	movi.2d	v16, #0000000000000000
     a28:      	movi.2d	v17, #0000000000000000
     a2c:      	movi.2d	v25, #0000000000000000
     a30:      	movi.2d	v27, #0000000000000000
     a34:      	mov.16b	v29, v3
     a38:      	ldr	q3, [sp, #0x120]
     a3c:      	b	0xa70 <ltmp0+0xa70>
     a40:      	add	x13, x19, x13
     a44:      	ldp	q5, q26, [x13]
     a48:      	bif.16b	v4, v26, v0
     a4c:      	bit.16b	v5, v28, v1
     a50:      	stp	q5, q4, [x13]
     a54:      	add.2d	v17, v17, v22
     a58:      	add.2d	v25, v25, v23
     a5c:      	add.2d	v27, v27, v21
     a60:      	add.2d	v16, v16, v24
     a64:      	fmov	x13, d16
     a68:      	cmp	x13, #0x200
     a6c:      	b.ge	0xb0c <ltmp0+0xb0c>
     a70:      	fmov	w15, s2
     a74:      	lsl	x13, x13, #5
     a78:      	add	x14, x10, x13
     a7c:      	movi.2d	v28, #0000000000000000
     a80:      	movi.2d	v4, #0000000000000000
     a84:      	tbnz	w15, #0x0, 0xaac <ltmp0+0xaac>
     a88:      	and	w15, w15, #0xff
     a8c:      	tbnz	w15, #0x1, 0xab8 <ltmp0+0xab8>
     a90:      	tbnz	w15, #0x2, 0xac4 <ltmp0+0xac4>
     a94:      	tbnz	w15, #0x3, 0xad0 <ltmp0+0xad0>
     a98:      	tbnz	w15, #0x4, 0xadc <ltmp0+0xadc>
     a9c:      	tbnz	w15, #0x5, 0xae8 <ltmp0+0xae8>
     aa0:      	tbnz	w15, #0x6, 0xaf4 <ltmp0+0xaf4>
     aa4:      	tbz	w15, #0x7, 0xa40 <ltmp0+0xa40>
     aa8:      	b	0xb00 <ltmp0+0xb00>
     aac:      	ldr	s28, [x14]
     ab0:      	and	w15, w15, #0xff
     ab4:      	tbz	w15, #0x1, 0xa90 <ltmp0+0xa90>
     ab8:      	add	x16, x14, #0x4
     abc:      	ld1.s	{ v28 }[1], [x16]
     ac0:      	tbz	w15, #0x2, 0xa94 <ltmp0+0xa94>
     ac4:      	add	x16, x14, #0x8
     ac8:      	ld1.s	{ v28 }[2], [x16]
     acc:      	tbz	w15, #0x3, 0xa98 <ltmp0+0xa98>
     ad0:      	add	x16, x14, #0xc
     ad4:      	ld1.s	{ v28 }[3], [x16]
     ad8:      	tbz	w15, #0x4, 0xa9c <ltmp0+0xa9c>
     adc:      	add	x16, x14, #0x10
     ae0:      	ld1.s	{ v4 }[0], [x16]
     ae4:      	tbz	w15, #0x5, 0xaa0 <ltmp0+0xaa0>
     ae8:      	add	x16, x14, #0x14
     aec:      	ld1.s	{ v4 }[1], [x16]
     af0:      	tbz	w15, #0x6, 0xaa4 <ltmp0+0xaa4>
     af4:      	add	x16, x14, #0x18
     af8:      	ld1.s	{ v4 }[2], [x16]
     afc:      	tbz	w15, #0x7, 0xa40 <ltmp0+0xa40>
     b00:      	add	x14, x14, #0x1c
     b04:      	ld1.s	{ v4 }[3], [x14]
     b08:      	b	0xa40 <ltmp0+0xa40>
     b0c:      	ldr	q4, [sp, #0x90]
     b10:      	xtn.8b	v26, v4
     b14:      	fmul.4s	v4, v29, v29
     b18:      	fmul.4s	v5, v3, v3
     b1c:      	fadd.4s	v5, v5, v19
     b20:      	fadd.4s	v4, v4, v18
     b24:      	zip1.8b	v16, v6, v0
     b28:      	ushll.4s	v16, v16, #0x0
     b2c:      	shl.4s	v16, v16, #0x1f
     b30:      	cmlt.4s	v16, v16, #0
     b34:      	and.16b	v4, v16, v4
     b38:      	zip2.8b	v16, v6, v0
     b3c:      	ushll.4s	v16, v16, #0x0
     b40:      	shl.4s	v16, v16, #0x1f
     b44:      	cmlt.4s	v16, v16, #0
     b48:      	and.16b	v5, v16, v5
     b4c:      	zip2.8b	v16, v26, v0
     b50:      	ushll.4s	v16, v16, #0x0
     b54:      	shl.4s	v16, v16, #0x1f
     b58:      	cmlt.4s	v16, v16, #0
     b5c:      	movi.2d	v17, #0000000000000000
     b60:      	mov.b	v17[2], v26[1]
     b64:      	mov.b	v17[4], v26[2]
     b68:      	mov.b	v17[6], v26[3]
     b6c:      	bit.16b	v5, v7, v16
     b70:      	ushll.4s	v7, v17, #0x0
     b74:      	shl.4s	v7, v7, #0x1f
     b78:      	cmlt.4s	v7, v7, #0
     b7c:      	bit.16b	v4, v20, v7
     b80:      	fadd.4s	v4, v15, v4
     b84:      	fadd.4s	v5, v14, v5
     b88:      	fadd.4s	v5, v13, v5
     b8c:      	fadd.4s	v4, v12, v4
     b90:      	fadd.4s	v18, v11, v4
     b94:      	fadd.4s	v19, v10, v5
     b98:      	ldr	q4, [sp, #0x40]
     b9c:      	ldr	q5, [sp, #0x20]
     ba0:      	uzp1.4s	v7, v4, v5
     ba4:      	ldr	q4, [sp, #0x30]
     ba8:      	ldr	q5, [sp, #0x10]
     bac:      	uzp1.4s	v20, v5, v4
     bb0:      	movi.4s	v5, #0x1
     bb4:      	eor.16b	v4, v7, v5
     bb8:      	mov.s	w14, v4[1]
     bbc:      	mov.s	w17, v4[2]
     bc0:      	eor.16b	v25, v20, v5
     bc4:      	mov.s	w0, v4[3]
     bc8:      	fmov	w13, s4
     bcc:      	add	x15, sp, #0x188
     bd0:      	bfxil	x15, x13, #0, #3
     bd4:      	str	d26, [sp, #0x188]
     bd8:      	ldrb	w16, [x15]
     bdc:      	and	x15, x13, #0x7
     be0:      	umov.b	w13, v26[0]
     be4:      	stp	q18, q19, [sp, #0x290]
     be8:      	add	x1, sp, #0x290
     bec:      	ldr	s4, [x1, x15, lsl #2]
     bf0:      	ands	w15, w13, #0x1
     bf4:      	tst	w15, w16
     bf8:      	fcsel	s16, s4, s8, ne
     bfc:      	add	x16, sp, #0x188
     c00:      	bfxil	x16, x14, #0, #3
     c04:      	ldrb	w16, [x16]
     c08:      	and	x1, x14, #0x7
     c0c:      	umov.b	w14, v26[1]
     c10:      	stp	q18, q19, [sp, #0x270]
     c14:      	add	x2, sp, #0x270
     c18:      	ldr	s4, [x2, x1, lsl #2]
     c1c:      	ands	w1, w14, #0x1
     c20:      	tst	w1, w16
     c24:      	fcsel	s17, s4, s8, ne
     c28:      	add	x16, sp, #0x188
     c2c:      	bfxil	x16, x17, #0, #3
     c30:      	ldrb	w1, [x16]
     c34:      	umov.b	w16, v26[2]
     c38:      	and	x17, x17, #0x7
     c3c:      	stp	q18, q19, [sp, #0x250]
     c40:      	add	x2, sp, #0x250
     c44:      	ldr	s4, [x2, x17, lsl #2]
     c48:      	ands	w17, w16, #0x1
     c4c:      	tst	w17, w1
     c50:      	fcsel	s4, s4, s8, ne
     c54:      	add	x17, sp, #0x188
     c58:      	bfxil	x17, x0, #0, #3
     c5c:      	ldrb	w1, [x17]
     c60:      	and	x0, x0, #0x7
     c64:      	umov.b	w17, v26[3]
     c68:      	stp	q18, q19, [sp, #0x230]
     c6c:      	add	x2, sp, #0x230
     c70:      	ldr	s5, [x2, x0, lsl #2]
     c74:      	ands	w0, w17, #0x1
     c78:      	tst	w0, w1
     c7c:      	mov.s	w1, v25[1]
     c80:      	mov.s	w2, v25[2]
     c84:      	fcsel	s27, s5, s8, ne
     c88:      	mov.s	w4, v25[3]
     c8c:      	fmov	w0, s25
     c90:      	and	x3, x0, #0x7
     c94:      	add	x5, sp, #0x188
     c98:      	bfxil	x5, x0, #0, #3
     c9c:      	ldrb	w5, [x5]
     ca0:      	umov.b	w0, v26[4]
     ca4:      	and	w5, w0, w5
     ca8:      	stp	q18, q19, [sp, #0x310]
     cac:      	add	x6, sp, #0x310
     cb0:      	ldr	s5, [x6, x3, lsl #2]
     cb4:      	tst	w5, #0x1
     cb8:      	fcsel	s5, s5, s8, ne
     cbc:      	add	x3, sp, #0x188
     cc0:      	bfxil	x3, x1, #0, #3
     cc4:      	ldrb	w3, [x3]
     cc8:      	and	x5, x1, #0x7
     ccc:      	umov.b	w1, v26[5]
     cd0:      	stp	q18, q19, [sp, #0x2f0]
     cd4:      	add	x6, sp, #0x2f0
     cd8:      	ldr	s25, [x6, x5, lsl #2]
     cdc:      	ands	w5, w1, #0x1
     ce0:      	tst	w5, w3
     ce4:      	fcsel	s25, s25, s8, ne
     ce8:      	add	x3, sp, #0x188
     cec:      	bfxil	x3, x2, #0, #3
     cf0:      	ldrb	w3, [x3]
     cf4:      	and	x5, x2, #0x7
     cf8:      	umov.b	w2, v26[6]
     cfc:      	stp	q18, q19, [sp, #0x2d0]
     d00:      	add	x6, sp, #0x2d0
     d04:      	ldr	s28, [x6, x5, lsl #2]
     d08:      	ands	w5, w2, #0x1
     d0c:      	tst	w5, w3
     d10:      	fcsel	s28, s28, s8, ne
     d14:      	add	x3, sp, #0x188
     d18:      	bfxil	x3, x4, #0, #3
     d1c:      	ldrb	w5, [x3]
     d20:      	umov.b	w3, v26[7]
     d24:      	and	x4, x4, #0x7
     d28:      	stp	q18, q19, [sp, #0x2b0]
     d2c:      	add	x6, sp, #0x2b0
     d30:      	ldr	s26, [x6, x4, lsl #2]
     d34:      	ands	w4, w3, #0x1
     d38:      	tst	w4, w5
     d3c:      	fcsel	s26, s26, s8, ne
     d40:      	mov.s	v5[1], v25[0]
     d44:      	mov.s	v5[2], v28[0]
     d48:      	mov.s	v5[3], v26[0]
     d4c:      	mov.s	v16[1], v17[0]
     d50:      	mov.s	v16[2], v4[0]
     d54:      	mov.s	v16[3], v27[0]
     d58:      	fadd.4s	v4, v18, v16
     d5c:      	fadd.4s	v5, v19, v5
     d60:      	movi.4s	v17, #0x2
     d64:      	eor.16b	v16, v20, v17
     d68:      	eor.16b	v7, v7, v17
     d6c:      	fmov	w4, s7
     d70:      	add	x5, sp, #0x188
     d74:      	bfxil	x5, x4, #0, #3
     d78:      	ldrb	w5, [x5]
     d7c:      	and	x4, x4, #0x7
     d80:      	stp	q4, q5, [sp, #0x210]
     d84:      	add	x6, sp, #0x210
     d88:      	ldr	s7, [x6, x4, lsl #2]
     d8c:      	tst	w15, w5
     d90:      	fcsel	s7, s7, s8, ne
     d94:      	fmov	w4, s16
     d98:      	and	x5, x4, #0x7
     d9c:      	add	x6, sp, #0x188
     da0:      	bfxil	x6, x4, #0, #3
     da4:      	ldrb	w4, [x6]
     da8:      	and	w4, w0, w4
     dac:      	stp	q4, q5, [sp, #0x1f0]
     db0:      	add	x6, sp, #0x1f0
     db4:      	ldr	s16, [x6, x5, lsl #2]
     db8:      	tst	w4, #0x1
     dbc:      	fcsel	s16, s16, s8, ne
     dc0:      	fadd.4s	v5, v5, v16
     dc4:      	tst	w15, w0
     dc8:      	fcsel	s5, s5, s8, ne
     dcc:      	ands	w13, w13, #0x1
     dd0:      	fadd.4s	v4, v4, v7
     dd4:      	fadd	s4, s4, s5
     dd8:      	fcsel	s5, s4, s8, ne
     ddc:      	tst	w14, #0x1
     de0:      	fcsel	s7, s5, s8, ne
     de4:      	tst	w16, #0x1
     de8:      	fcsel	s16, s5, s8, ne
     dec:      	tst	w17, #0x1
     df0:      	fcsel	s17, s5, s8, ne
     df4:      	tst	w13, w0
     df8:      	fcsel	s4, s4, s8, ne
     dfc:      	tst	w1, #0x1
     e00:      	fcsel	s18, s5, s8, ne
     e04:      	tst	w2, #0x1
     e08:      	fcsel	s19, s5, s8, ne
     e0c:      	tst	w3, #0x1
     e10:      	shl.8b	v20, v6, #0x7
     e14:      	cmlt.8b	v20, v20, #0
     e18:      	ldr	d25, [sp, #0xc0]
     e1c:      	and.8b	v20, v20, v25
     e20:      	addv.8b	b20, v20
     e24:      	fmov	w13, s20
     e28:      	fcsel	s25, s5, s8, ne
     e2c:      	mov.s	v5[1], v7[0]
     e30:      	mov.s	v5[2], v16[0]
     e34:      	mov.s	v5[3], v17[0]
     e38:      	mov.s	v4[1], v18[0]
     e3c:      	mov.s	v4[2], v19[0]
     e40:      	mov.s	v4[3], v25[0]
     e44:      	rbit	w11, w11
     e48:      	clz	w11, w11
     e4c:      	stp	q5, q4, [sp, #0x1d0]
     e50:      	and	x11, x11, #0x7
     e54:      	add	x14, sp, #0x1d0
     e58:      	ldr	s19, [x14, x11, lsl #2]
     e5c:      	mov	b4, v6[0]
     e60:      	mov.b	v4[4], v6[1]
     e64:      	ushll.2d	v4, v4, #0x0
     e68:      	shl.2d	v4, v4, #0x3f
     e6c:      	cmlt.2d	v4, v4, #0
     e70:      	mov	b5, v6[2]
     e74:      	mov.b	v5[4], v6[3]
     e78:      	ldr	q7, [sp, #0xd0]
     e7c:      	and.16b	v4, v4, v7
     e80:      	ushll.2d	v5, v5, #0x0
     e84:      	shl.2d	v5, v5, #0x3f
     e88:      	cmlt.2d	v5, v5, #0
     e8c:      	ldr	q7, [sp, #0x50]
     e90:      	and.16b	v5, v5, v7
     e94:      	mov	b7, v6[4]
     e98:      	mov.b	v7[4], v6[5]
     e9c:      	ushll.2d	v7, v7, #0x0
     ea0:      	shl.2d	v7, v7, #0x3f
     ea4:      	cmlt.2d	v7, v7, #0
     ea8:      	ldp	q16, q17, [sp, #0xa0]
     eac:      	and.16b	v7, v7, v16
     eb0:      	mov	b16, v6[6]
     eb4:      	mov.b	v16[4], v6[7]
     eb8:      	ushll.2d	v16, v16, #0x0
     ebc:      	shl.2d	v16, v16, #0x3f
     ec0:      	cmlt.2d	v16, v16, #0
     ec4:      	and.16b	v16, v16, v17
     ec8:      	stp	q7, q16, [sp, #0x1b0]
     ecc:      	stp	q4, q5, [sp, #0x190]
     ed0:      	and	x11, x9, #0x7
     ed4:      	add	x14, sp, #0x190
     ed8:      	ldr	x11, [x14, x11, lsl #3]
     edc:      	sub	x11, x11, x9
     ee0:      	add	x10, x10, x11, lsl #2
     ee4:      	movi.2d	v7, #0000000000000000
     ee8:      	movi.2d	v18, #0000000000000000
     eec:      	tbnz	w13, #0x0, 0x113c <ltmp0+0x113c>
     ef0:      	tbnz	w13, #0x1, 0x1144 <ltmp0+0x1144>
     ef4:      	tbnz	w13, #0x2, 0x1150 <ltmp0+0x1150>
     ef8:      	tbnz	w13, #0x3, 0x115c <ltmp0+0x115c>
     efc:      	tbnz	w13, #0x4, 0x1168 <ltmp0+0x1168>
     f00:      	tbnz	w13, #0x5, 0x1174 <ltmp0+0x1174>
     f04:      	tbnz	w13, #0x6, 0x1180 <ltmp0+0x1180>
     f08:      	tbz	w13, #0x7, 0xf14 <ltmp0+0xf14>
     f0c:      	add	x10, x10, #0x1c
     f10:      	ld1.s	{ v18 }[3], [x10]
     f14:      	mov	x11, #0x0               ; =0
     f18:      	fadd	s4, s19, s8
     f1c:      	mov	w10, #0x800             ; =2048
     f20:      	movk	w10, #0x4580, lsl #16
     f24:      	fmov	s5, w10
     f28:      	fdiv	s4, s4, s5
     f2c:      	add	x10, x19, x12
     f30:      	ldp	q5, q16, [x10]
     f34:      	zip2.8b	v17, v6, v0
     f38:      	ushll.4s	v17, v17, #0x0
     f3c:      	shl.4s	v17, v17, #0x1f
     f40:      	cmlt.4s	v17, v17, #0
     f44:      	bit.16b	v16, v18, v17
     f48:      	zip1.8b	v6, v6, v0
     f4c:      	ushll.4s	v6, v6, #0x0
     f50:      	shl.4s	v6, v6, #0x1f
     f54:      	cmlt.4s	v6, v6, #0
     f58:      	bit.16b	v5, v7, v6
     f5c:      	stp	q5, q16, [x10]
     f60:      	mov	w10, #0xc5ac            ; =50604
     f64:      	movk	w10, #0x3727, lsl #16
     f68:      	fmov	s5, w10
     f6c:      	fadd	s4, s4, s5
     f70:      	fsqrt	s4, s4
     f74:      	dup.4s	v6, v4[0]
     f78:      	ldr	q4, [sp, #0xe0]
     f7c:      	fmov	x10, d4
     f80:      	add	x10, x8, x10, lsl #2
     f84:      	movi.2d	v4, #0000000000000000
     f88:      	movi.2d	v16, #0000000000000000
     f8c:      	movi.2d	v17, #0000000000000000
     f90:      	movi.2d	v19, #0000000000000000
     f94:      	b	0xfb4 <ltmp0+0xfb4>
     f98:      	add.2d	v16, v16, v22
     f9c:      	add.2d	v17, v17, v23
     fa0:      	add.2d	v19, v19, v21
     fa4:      	add.2d	v4, v4, v24
     fa8:      	fmov	x11, d4
     fac:      	cmp	x11, #0x200
     fb0:      	b.ge	0x1084 <ltmp0+0x1084>
     fb4:      	fmov	w12, s2
     fb8:      	lsl	x11, x11, #5
     fbc:      	add	x13, x26, x11
     fc0:      	ldp	q5, q25, [x13]
     fc4:      	and.16b	v5, v1, v5
     fc8:      	fdiv.4s	v5, v5, v6
     fcc:      	add	x13, x19, x11
     fd0:      	ldp	q27, q26, [x13]
     fd4:      	and.16b	v27, v1, v27
     fd8:      	fmul.4s	v27, v5, v27
     fdc:      	add	x11, x10, x11
     fe0:      	tbnz	w12, #0x0, 0x1018 <ltmp0+0x1018>
     fe4:      	and	w12, w12, #0xff
     fe8:      	tbnz	w12, #0x1, 0x1024 <ltmp0+0x1024>
     fec:      	tbnz	w12, #0x2, 0x1030 <ltmp0+0x1030>
     ff0:      	tbnz	w12, #0x3, 0x103c <ltmp0+0x103c>
     ff4:      	and.16b	v5, v0, v25
     ff8:      	fdiv.4s	v5, v5, v6
     ffc:      	and.16b	v25, v0, v26
    1000:      	fmul.4s	v25, v5, v25
    1004:      	tbnz	w12, #0x4, 0x1058 <ltmp0+0x1058>
    1008:      	tbnz	w12, #0x5, 0x1060 <ltmp0+0x1060>
    100c:      	tbnz	w12, #0x6, 0x106c <ltmp0+0x106c>
    1010:      	tbz	w12, #0x7, 0xf98 <ltmp0+0xf98>
    1014:      	b	0x1078 <ltmp0+0x1078>
    1018:      	str	s27, [x11]
    101c:      	and	w12, w12, #0xff
    1020:      	tbz	w12, #0x1, 0xfec <ltmp0+0xfec>
    1024:      	add	x13, x11, #0x4
    1028:      	st1.s	{ v27 }[1], [x13]
    102c:      	tbz	w12, #0x2, 0xff0 <ltmp0+0xff0>
    1030:      	add	x13, x11, #0x8
    1034:      	st1.s	{ v27 }[2], [x13]
    1038:      	tbz	w12, #0x3, 0xff4 <ltmp0+0xff4>
    103c:      	add	x13, x11, #0xc
    1040:      	st1.s	{ v27 }[3], [x13]
    1044:      	and.16b	v5, v0, v25
    1048:      	fdiv.4s	v5, v5, v6
    104c:      	and.16b	v25, v0, v26
    1050:      	fmul.4s	v25, v5, v25
    1054:      	tbz	w12, #0x4, 0x1008 <ltmp0+0x1008>
    1058:      	str	s25, [x11, #0x10]
    105c:      	tbz	w12, #0x5, 0x100c <ltmp0+0x100c>
    1060:      	add	x13, x11, #0x14
    1064:      	st1.s	{ v25 }[1], [x13]
    1068:      	tbz	w12, #0x6, 0x1010 <ltmp0+0x1010>
    106c:      	add	x13, x11, #0x18
    1070:      	st1.s	{ v25 }[2], [x13]
    1074:      	tbz	w12, #0x7, 0xf98 <ltmp0+0xf98>
    1078:      	add	x11, x11, #0x1c
    107c:      	st1.s	{ v25 }[3], [x11]
    1080:      	b	0xf98 <ltmp0+0xf98>
    1084:      	fdiv.4s	v0, v29, v6
    1088:      	fmul.4s	v0, v0, v7
    108c:      	ldr	q2, [sp, #0x130]
    1090:      	ldp	q5, q4, [sp, #0xf0]
    1094:      	stp	q2, q4, [sp, #0x140]
    1098:      	ldr	q1, [sp, #0x110]
    109c:      	stp	q5, q1, [sp, #0x160]
    10a0:      	and	x10, x9, #0x7
    10a4:      	add	x11, sp, #0x140
    10a8:      	ldr	x10, [x11, x10, lsl #3]
    10ac:      	sub	x9, x10, x9
    10b0:      	add	x8, x8, x9, lsl #2
    10b4:      	fmov	w9, s20
    10b8:      	tbnz	w9, #0x0, 0x1190 <ltmp0+0x1190>
    10bc:      	tbnz	w9, #0x1, 0x1198 <ltmp0+0x1198>
    10c0:      	tbnz	w9, #0x2, 0x11a4 <ltmp0+0x11a4>
    10c4:      	tbnz	w9, #0x3, 0x11b0 <ltmp0+0x11b0>
    10c8:      	fdiv.4s	v0, v3, v6
    10cc:      	fmul.4s	v0, v0, v18
    10d0:      	tbnz	w9, #0x4, 0x11c4 <ltmp0+0x11c4>
    10d4:      	tbnz	w9, #0x5, 0x11cc <ltmp0+0x11cc>
    10d8:      	tbnz	w9, #0x6, 0x11d8 <ltmp0+0x11d8>
    10dc:      	tbz	w9, #0x7, 0x6c <ltmp0+0x6c>
    10e0:      	b	0x11e4 <ltmp0+0x11e4>
    10e4:      	ldr	s5, [x12]
    10e8:      	tbz	w13, #0x1, 0x778 <ltmp0+0x778>
    10ec:      	add	x14, x12, #0x4
    10f0:      	ld1.s	{ v5 }[1], [x14]
    10f4:      	mov	w15, #0x4               ; =4
    10f8:      	tbz	w13, #0x2, 0x780 <ltmp0+0x780>
    10fc:      	add	x14, x12, #0x8
    1100:      	ld1.s	{ v5 }[2], [x14]
    1104:      	tbz	w13, #0x3, 0x784 <ltmp0+0x784>
    1108:      	add	x14, x12, #0xc
    110c:      	ld1.s	{ v5 }[3], [x14]
    1110:      	tbz	w13, #0x4, 0x788 <ltmp0+0x788>
    1114:      	add	x14, x12, #0x10
    1118:      	ld1.s	{ v3 }[0], [x14]
    111c:      	tbz	w13, #0x5, 0x78c <ltmp0+0x78c>
    1120:      	add	x14, x12, #0x14
    1124:      	ld1.s	{ v3 }[1], [x14]
    1128:      	tbz	w13, #0x6, 0x790 <ltmp0+0x790>
    112c:      	add	x14, x12, #0x18
    1130:      	ld1.s	{ v3 }[2], [x14]
    1134:      	tbnz	w13, #0x7, 0x794 <ltmp0+0x794>
    1138:      	b	0x79c <ltmp0+0x79c>
    113c:      	ldr	s7, [x10]
    1140:      	tbz	w13, #0x1, 0xef4 <ltmp0+0xef4>
    1144:      	add	x11, x10, #0x4
    1148:      	ld1.s	{ v7 }[1], [x11]
    114c:      	tbz	w13, #0x2, 0xef8 <ltmp0+0xef8>
    1150:      	add	x11, x10, #0x8
    1154:      	ld1.s	{ v7 }[2], [x11]
    1158:      	tbz	w13, #0x3, 0xefc <ltmp0+0xefc>
    115c:      	add	x11, x10, #0xc
    1160:      	ld1.s	{ v7 }[3], [x11]
    1164:      	tbz	w13, #0x4, 0xf00 <ltmp0+0xf00>
    1168:      	add	x11, x10, #0x10
    116c:      	ld1.s	{ v18 }[0], [x11]
    1170:      	tbz	w13, #0x5, 0xf04 <ltmp0+0xf04>
    1174:      	add	x11, x10, #0x14
    1178:      	ld1.s	{ v18 }[1], [x11]
    117c:      	tbz	w13, #0x6, 0xf08 <ltmp0+0xf08>
    1180:      	add	x11, x10, #0x18
    1184:      	ld1.s	{ v18 }[2], [x11]
    1188:      	tbnz	w13, #0x7, 0xf0c <ltmp0+0xf0c>
    118c:      	b	0xf14 <ltmp0+0xf14>
    1190:      	str	s0, [x8]
    1194:      	tbz	w9, #0x1, 0x10c0 <ltmp0+0x10c0>
    1198:      	add	x10, x8, #0x4
    119c:      	st1.s	{ v0 }[1], [x10]
    11a0:      	tbz	w9, #0x2, 0x10c4 <ltmp0+0x10c4>
    11a4:      	add	x10, x8, #0x8
    11a8:      	st1.s	{ v0 }[2], [x10]
    11ac:      	tbz	w9, #0x3, 0x10c8 <ltmp0+0x10c8>
    11b0:      	add	x10, x8, #0xc
    11b4:      	st1.s	{ v0 }[3], [x10]
    11b8:      	fdiv.4s	v0, v3, v6
    11bc:      	fmul.4s	v0, v0, v18
    11c0:      	tbz	w9, #0x4, 0x10d4 <ltmp0+0x10d4>
    11c4:      	str	s0, [x8, #0x10]
    11c8:      	tbz	w9, #0x5, 0x10d8 <ltmp0+0x10d8>
    11cc:      	add	x10, x8, #0x14
    11d0:      	st1.s	{ v0 }[1], [x10]
    11d4:      	tbz	w9, #0x6, 0x10dc <ltmp0+0x10dc>
    11d8:      	add	x10, x8, #0x18
    11dc:      	st1.s	{ v0 }[2], [x10]
    11e0:      	tbz	w9, #0x7, 0x6c <ltmp0+0x6c>
    11e4:      	add	x8, x8, #0x1c
    11e8:      	st1.s	{ v0 }[3], [x8]
    11ec:      	b	0x6c <ltmp0+0x6c>
    11f0:      	ldr	x9, [sp, #0x8]
    11f4:      	stp	w15, w14, [x9]
    11f8:      	str	w13, [x9, #0x8]
    11fc:      	mov	w8, #0x18               ; =24
    1200:      	str	w8, [x9, #0x24]
    1204:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    1208:      	add	sp, sp, #0x410
    120c:      	ldp	x29, x30, [sp, #0x90]
    1210:      	ldp	x20, x19, [sp, #0x80]
    1214:      	ldp	x22, x21, [sp, #0x70]
    1218:      	ldp	x24, x23, [sp, #0x60]
    121c:      	ldp	x26, x25, [sp, #0x50]
    1220:      	ldp	x28, x27, [sp, #0x40]
    1224:      	ldp	d9, d8, [sp, #0x30]
    1228:      	ldp	d11, d10, [sp, #0x20]
    122c:      	ldp	d13, d12, [sp, #0x10]
    1230:      	ldp	d15, d14, [sp], #0xa0
    1234:      	ret

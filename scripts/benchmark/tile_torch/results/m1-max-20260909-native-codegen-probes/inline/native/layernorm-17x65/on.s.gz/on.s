
/private/tmp/luisa-packet-inline.UY1lIE/capture/layernorm-17x65/on/object/tile_xir_w8_36312_1788935094065664_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x2280 <ltmp0+0x2280>
       4:      	stp	d15, d14, [sp, #-0xa0]!
       8:      	stp	d13, d12, [sp, #0x10]
       c:      	stp	d11, d10, [sp, #0x20]
      10:      	stp	d9, d8, [sp, #0x30]
      14:      	stp	x28, x27, [sp, #0x40]
      18:      	stp	x26, x25, [sp, #0x50]
      1c:      	stp	x24, x23, [sp, #0x60]
      20:      	stp	x22, x21, [sp, #0x70]
      24:      	stp	x20, x19, [sp, #0x80]
      28:      	stp	x29, x30, [sp, #0x90]
      2c:      	sub	sp, sp, #0xb20
      30:      	mov	w8, #0x0                ; =0
      34:      	mov	w27, #0x20              ; =32
      38:      	mov	w30, #0x450             ; =1104
      3c:      	ldp	w10, w9, [x2, #0x2c]
      40:      	str	w10, [sp, #0x188]
      44:      	str	w9, [sp, #0x184]
      48:      	mov	w14, #0x42820000        ; =1115815936
      4c:      	mov	w15, #0xc5ac            ; =50604
      50:      	movk	w15, #0x3727, lsl #16
      54:      	add	x16, sp, #0xa00
      58:      	add	x17, sp, #0x8e0
      5c:      	ldp	w9, w10, [x2]
      60:      	mov	w1, #0x1                ; =1
      64:      	ldp	w11, w7, [x2, #0x8]
      68:      	str	x2, [sp, #0x10]
      6c:      	mov	w20, #0x4               ; =4
      70:      	add	x21, sp, #0x7c0
      74:      	str	w3, [sp, #0x1c]
      78:      	b	0xbc <ltmp0+0xbc>
      7c:      	add	w9, w28, #0x1
      80:      	ldr	w10, [sp, #0x188]
      84:      	cmp	w9, w10
      88:      	cset	w10, eq
      8c:      	csinc	w9, wzr, w28, eq
      90:      	ldr	w13, [sp, #0x18c]
      94:      	cinc	w11, w13, eq
      98:      	ldr	w12, [sp, #0x184]
      9c:      	cmp	w11, w12
      a0:      	cset	w12, eq
      a4:      	ands	w12, w10, w12
      a8:      	csel	w10, wzr, w11, ne
      ac:      	add	w11, w25, w12
      b0:      	add	w8, w8, #0x1
      b4:      	cmp	w8, w3
      b8:      	b.eq	0x2240 <ltmp0+0x2240>
      bc:      	mov	x25, x11
      c0:      	mov	x12, x10
      c4:      	mov	x28, x9
      c8:      	ubfiz	x9, x9, #5, #32
      cc:      	cmp	x9, x7
      d0:      	csel	x10, x9, xzr, ls
      d4:      	subs	x11, x7, x10
      d8:      	cmp	x11, #0x20
      dc:      	csel	x11, x11, x27, lo
      e0:      	cmp	x7, x10
      e4:      	ccmp	x9, x7, #0x2, hi
      e8:      	csel	x10, x11, xzr, ls
      ec:      	cmp	x10, #0x20
      f0:      	str	w12, [sp, #0x18c]
      f4:      	b.lo	0x5f0 <ltmp0+0x5f0>
      f8:      	mov	x9, #0x0                ; =0
      fc:      	ldr	x10, [x0]
     100:      	ldr	x11, [x0, #0x10]
     104:      	ldr	x12, [x0, #0x20]
     108:      	ldr	x13, [x0, #0x30]
     10c:      	add	x2, x11, #0x100
     110:      	subs	x4, x12, x13
     114:      	lsr	x4, x4, #2
     118:      	ccmp	x4, x30, #0x0, hs
     11c:      	cset	w5, hi
     120:      	subs	x4, x13, x12
     124:      	mov	w6, #0x103              ; =259
     128:      	ccmp	x4, x6, #0x0, hs
     12c:      	csinc	w24, w5, wzr, ls
     130:      	add	x4, x12, #0x100
     134:      	lsl	w5, w28, #2
     138:      	b	0x2c8 <ltmp0+0x2c8>
     13c:      	ldp	q0, q9, [x12]
     140:      	ldp	q13, q14, [x12, #0x20]
     144:      	ldp	q15, q3, [x12, #0x40]
     148:      	ldp	q11, q12, [x12, #0x60]
     14c:      	ldp	q6, q5, [x12, #0x80]
     150:      	stp	q5, q6, [sp, #0x190]
     154:      	dup.4s	v30, v21[0]
     158:      	fdiv.4s	v29, v29, v30
     15c:      	ldr	q5, [sp, #0x8f0]
     160:      	ldr	q10, [sp, #0x8e0]
     164:      	fmul.4s	v6, v29, v10
     168:      	ldp	q29, q10, [x12, #0xa0]
     16c:      	fdiv.4s	v28, v28, v30
     170:      	fmul.4s	v5, v28, v5
     174:      	fadd.4s	v5, v9, v5
     178:      	fadd.4s	v0, v0, v6
     17c:      	fdiv.4s	v6, v27, v30
     180:      	ldr	q27, [sp, #0x910]
     184:      	ldr	q28, [sp, #0x900]
     188:      	fmul.4s	v6, v6, v28
     18c:      	ldp	q28, q9, [x12, #0xc0]
     190:      	fdiv.4s	v26, v26, v30
     194:      	fmul.4s	v26, v26, v27
     198:      	fadd.4s	v14, v14, v26
     19c:      	ldp	q26, q27, [x12, #0xe0]
     1a0:      	str	q7, [sp, #0x1b0]
     1a4:      	ldr	q7, [sp, #0x1c0]
     1a8:      	ld1.s	{ v7 }[0], [x4]
     1ac:      	add	x19, x13, x19
     1b0:      	stp	q0, q5, [x19]
     1b4:      	fadd.4s	v0, v13, v6
     1b8:      	fdiv.4s	v5, v25, v30
     1bc:      	ldr	q6, [sp, #0x920]
     1c0:      	fmul.4s	v5, v5, v6
     1c4:      	ldr	q6, [sp, #0x930]
     1c8:      	fdiv.4s	v24, v24, v30
     1cc:      	fmul.4s	v6, v24, v6
     1d0:      	fadd.4s	v3, v3, v6
     1d4:      	fadd.4s	v5, v15, v5
     1d8:      	stp	q0, q14, [x19, #0x20]
     1dc:      	stp	q5, q3, [x19, #0x40]
     1e0:      	fdiv.4s	v0, v23, v30
     1e4:      	ldr	q3, [sp, #0x940]
     1e8:      	fmul.4s	v0, v0, v3
     1ec:      	ldr	q3, [sp, #0x950]
     1f0:      	fdiv.4s	v5, v22, v30
     1f4:      	fmul.4s	v3, v5, v3
     1f8:      	fadd.4s	v3, v12, v3
     1fc:      	fadd.4s	v0, v11, v0
     200:      	fdiv.4s	v5, v20, v30
     204:      	ldr	q6, [sp, #0x960]
     208:      	fmul.4s	v5, v5, v6
     20c:      	ldr	q6, [sp, #0x970]
     210:      	fdiv.4s	v19, v19, v30
     214:      	fmul.4s	v6, v19, v6
     218:      	ldr	q19, [sp, #0x190]
     21c:      	fadd.4s	v6, v19, v6
     220:      	stp	q0, q3, [x19, #0x60]
     224:      	ldr	q0, [sp, #0x1a0]
     228:      	fadd.4s	v0, v0, v5
     22c:      	fdiv.4s	v3, v18, v30
     230:      	ldr	q5, [sp, #0x980]
     234:      	fmul.4s	v3, v3, v5
     238:      	ldr	q5, [sp, #0x990]
     23c:      	fdiv.4s	v17, v17, v30
     240:      	fmul.4s	v5, v17, v5
     244:      	fadd.4s	v5, v10, v5
     248:      	stp	q0, q6, [x19, #0x80]
     24c:      	fadd.4s	v0, v29, v3
     250:      	fdiv.4s	v3, v16, v30
     254:      	ldr	q6, [sp, #0x9a0]
     258:      	fmul.4s	v3, v3, v6
     25c:      	ldr	q6, [sp, #0x9b0]
     260:      	fdiv.4s	v4, v4, v30
     264:      	fmul.4s	v4, v4, v6
     268:      	fadd.4s	v4, v9, v4
     26c:      	stp	q0, q5, [x19, #0xa0]
     270:      	fadd.4s	v0, v28, v3
     274:      	fdiv.4s	v2, v2, v30
     278:      	fdiv.4s	v1, v1, v30
     27c:      	ldr	q3, [sp, #0x9c0]
     280:      	fmul.4s	v1, v1, v3
     284:      	ldr	q3, [sp, #0x9d0]
     288:      	fmul.4s	v2, v2, v3
     28c:      	fadd.4s	v2, v27, v2
     290:      	fadd.4s	v1, v26, v1
     294:      	stp	q0, q4, [x19, #0xc0]
     298:      	stp	q1, q2, [x19, #0xe0]
     29c:      	fdiv.4s	v0, v31, v21
     2a0:      	fmul.4s	v0, v8, v0
     2a4:      	str	q7, [sp, #0x1c0]
     2a8:      	fadd.4s	v1, v0, v7
     2ac:      	ldr	q7, [sp, #0x1b0]
     2b0:      	mov.16b	v5, v31
     2b4:      	mov.16b	v6, v8
     2b8:      	str	s1, [x13, x6]
     2bc:      	add	x9, x9, #0x1
     2c0:      	cmp	x9, #0x4
     2c4:      	b.eq	0x7c <ltmp0+0x7c>
     2c8:      	add	w6, w9, w5
     2cc:      	and	x6, x6, #0x1fffffff
     2d0:      	add	x6, x6, x6, lsl #6
     2d4:      	lsl	x19, x6, #2
     2d8:      	add	x6, x10, x19
     2dc:      	ldp	q17, q18, [x6]
     2e0:      	ldp	q20, q19, [x6, #0x20]
     2e4:      	ldp	q22, q23, [x6, #0x40]
     2e8:      	ldp	q8, q31, [x6, #0x60]
     2ec:      	ldp	q9, q10, [x6, #0x80]
     2f0:      	ldp	q11, q16, [x6, #0xa0]
     2f4:      	ldp	q4, q30, [x6, #0xc0]
     2f8:      	ldp	q1, q2, [x6, #0xe0]
     2fc:      	add	x6, x19, #0x100
     300:      	ldr	s21, [x10, x6]
     304:      	mov.s	v7[0], v21[0]
     308:      	fadd.4s	v24, v8, v1
     30c:      	fadd.4s	v25, v31, v2
     310:      	fadd.4s	v26, v23, v30
     314:      	fadd.4s	v27, v22, v4
     318:      	fadd.4s	v28, v20, v11
     31c:      	fadd.4s	v29, v19, v16
     320:      	fadd.4s	v12, v18, v10
     324:      	fadd.4s	v13, v17, v9
     328:      	fadd.4s	v21, v13, v21
     32c:      	mov.s	v13[0], v21[0]
     330:      	fadd.4s	v21, v29, v12
     334:      	fadd.4s	v28, v28, v13
     338:      	fadd.4s	v27, v27, v28
     33c:      	fadd.4s	v21, v26, v21
     340:      	fadd.4s	v21, v25, v21
     344:      	fadd.4s	v24, v24, v27
     348:      	rev64.4s	v25, v24
     34c:      	rev64.4s	v26, v21
     350:      	fadd.4s	v21, v21, v26
     354:      	fadd.4s	v24, v24, v25
     358:      	dup.4s	v25, v24[2]
     35c:      	dup.4s	v26, v21[2]
     360:      	fadd.4s	v21, v21, v26
     364:      	fadd.4s	v24, v24, v25
     368:      	fadd.4s	v21, v24, v21
     36c:      	movi	d3, #0000000000000000
     370:      	fadd	s24, s21, s3
     374:      	fmov	s21, w14
     378:      	fdiv	s12, s24, s21
     37c:      	dup.4s	v13, v12[0]
     380:      	fsub.4s	v29, v17, v13
     384:      	fsub.4s	v28, v18, v13
     388:      	str	q28, [sp, #0xa10]
     38c:      	str	q29, [sp, #0xa00]
     390:      	fsub.4s	v27, v20, v13
     394:      	fsub.4s	v26, v19, v13
     398:      	str	q26, [sp, #0xa30]
     39c:      	str	q27, [sp, #0xa20]
     3a0:      	fsub.4s	v25, v22, v13
     3a4:      	fsub.4s	v24, v23, v13
     3a8:      	str	q24, [sp, #0xa50]
     3ac:      	str	q25, [sp, #0xa40]
     3b0:      	fsub.4s	v23, v8, v13
     3b4:      	fsub.4s	v22, v31, v13
     3b8:      	str	q22, [sp, #0xa70]
     3bc:      	str	q23, [sp, #0xa60]
     3c0:      	fsub.4s	v20, v9, v13
     3c4:      	fsub.4s	v19, v10, v13
     3c8:      	str	q19, [sp, #0xa90]
     3cc:      	str	q20, [sp, #0xa80]
     3d0:      	fsub.4s	v18, v11, v13
     3d4:      	fsub.4s	v17, v16, v13
     3d8:      	str	q17, [sp, #0xab0]
     3dc:      	str	q18, [sp, #0xaa0]
     3e0:      	fsub.4s	v16, v4, v13
     3e4:      	fsub.4s	v4, v30, v13
     3e8:      	str	q4, [sp, #0xad0]
     3ec:      	str	q16, [sp, #0xac0]
     3f0:      	fsub.4s	v1, v1, v13
     3f4:      	fsub.4s	v2, v2, v13
     3f8:      	str	q2, [sp, #0xaf0]
     3fc:      	str	q1, [sp, #0xae0]
     400:      	fsub.4s	v30, v7, v12
     404:      	mov.s	v5[0], v30[0]
     408:      	str	q0, [sp, #0xb10]
     40c:      	str	q5, [sp, #0xb00]
     410:      	ldp	q31, q8, [x11, #0xc0]
     414:      	str	q31, [sp, #0x9a0]
     418:      	str	q8, [sp, #0x9b0]
     41c:      	ldp	q31, q8, [x11, #0xe0]
     420:      	str	q31, [sp, #0x9c0]
     424:      	str	q8, [sp, #0x9d0]
     428:      	ldp	q31, q8, [x11, #0x80]
     42c:      	str	q31, [sp, #0x960]
     430:      	str	q8, [sp, #0x970]
     434:      	ldp	q31, q8, [x11, #0xa0]
     438:      	str	q31, [sp, #0x980]
     43c:      	str	q8, [sp, #0x990]
     440:      	ldp	q31, q8, [x11, #0x40]
     444:      	str	q31, [sp, #0x920]
     448:      	str	q8, [sp, #0x930]
     44c:      	ldp	q31, q8, [x11, #0x60]
     450:      	str	q31, [sp, #0x940]
     454:      	str	q8, [sp, #0x950]
     458:      	ldp	q31, q8, [x11]
     45c:      	str	q31, [sp, #0x8e0]
     460:      	str	q8, [sp, #0x8f0]
     464:      	ldp	q31, q8, [x11, #0x20]
     468:      	str	q31, [sp, #0x900]
     46c:      	str	q8, [sp, #0x910]
     470:      	fmul.4s	v31, v29, v29
     474:      	fmul.4s	v8, v28, v28
     478:      	fmul.4s	v9, v26, v26
     47c:      	fmul.4s	v10, v27, v27
     480:      	fmul.4s	v11, v25, v25
     484:      	fmul.4s	v12, v24, v24
     488:      	fmul.4s	v13, v22, v22
     48c:      	fmul.4s	v14, v23, v23
     490:      	fmul.4s	v15, v2, v2
     494:      	fmul.4s	v0, v1, v1
     498:      	fadd.4s	v0, v14, v0
     49c:      	fadd.4s	v13, v13, v15
     4a0:      	fmul.4s	v14, v16, v16
     4a4:      	fmul.4s	v15, v4, v4
     4a8:      	fadd.4s	v12, v12, v15
     4ac:      	fadd.4s	v11, v11, v14
     4b0:      	fmul.4s	v14, v17, v17
     4b4:      	fmul.4s	v15, v18, v18
     4b8:      	fadd.4s	v10, v10, v15
     4bc:      	fadd.4s	v9, v9, v14
     4c0:      	fmul.4s	v14, v20, v20
     4c4:      	fmul.4s	v15, v19, v19
     4c8:      	fadd.4s	v8, v8, v15
     4cc:      	fadd.4s	v31, v31, v14
     4d0:      	fmul.4s	v30, v30, v30
     4d4:      	fadd.4s	v30, v30, v31
     4d8:      	mov.s	v31[0], v30[0]
     4dc:      	fadd.4s	v30, v9, v8
     4e0:      	fadd.4s	v31, v10, v31
     4e4:      	fadd.4s	v31, v11, v31
     4e8:      	fadd.4s	v30, v12, v30
     4ec:      	fadd.4s	v30, v13, v30
     4f0:      	fadd.4s	v0, v0, v31
     4f4:      	rev64.4s	v31, v0
     4f8:      	rev64.4s	v8, v30
     4fc:      	fadd.4s	v30, v30, v8
     500:      	fadd.4s	v0, v0, v31
     504:      	dup.4s	v31, v0[2]
     508:      	dup.4s	v8, v30[2]
     50c:      	fadd.4s	v30, v30, v8
     510:      	fadd.4s	v0, v0, v31
     514:      	fadd.4s	v0, v0, v30
     518:      	fadd	s0, s0, s3
     51c:      	ld1.s	{ v6 }[0], [x2]
     520:      	fdiv	s0, s0, s21
     524:      	str	q0, [sp, #0x9f0]
     528:      	str	q6, [sp, #0x9e0]
     52c:      	fmov	s21, w15
     530:      	fadd	s0, s0, s21
     534:      	fsqrt	s21, s0
     538:      	mov.16b	v31, v5
     53c:      	mov.16b	v8, v6
     540:      	tbz	w24, #0x0, 0x13c <ltmp0+0x13c>
     544:      	mov	x22, #0x0               ; =0
     548:      	dup.4s	v1, v21[0]
     54c:      	add	x19, x13, x19
     550:      	movi.2d	v2, #0000000000000000
     554:      	movi.2d	v4, #0000000000000000
     558:      	movi.2d	v16, #0000000000000000
     55c:      	movi.2d	v17, #0000000000000000
     560:      	lsl	x22, x22, #5
     564:      	add	x23, x16, x22
     568:      	ldp	q3, q0, [x23]
     56c:      	fdiv.4s	v3, v3, v1
     570:      	fdiv.4s	v0, v0, v1
     574:      	add	x22, x17, x22
     578:      	ldp	q5, q6, [x22]
     57c:      	fmul.4s	v0, v0, v6
     580:      	fmul.4s	v3, v3, v5
     584:      	fmov	x22, d2
     588:      	lsl	x22, x22, #5
     58c:      	add	x23, x12, x22
     590:      	ldp	q6, q5, [x23]
     594:      	fadd.4s	v3, v3, v6
     598:      	fadd.4s	v0, v0, v5
     59c:      	add	x22, x19, x22
     5a0:      	stp	q3, q0, [x22]
     5a4:      	dup.2d	v0, x1
     5a8:      	add.2d	v16, v16, v0
     5ac:      	add.2d	v4, v4, v0
     5b0:      	add.2d	v17, v17, v0
     5b4:      	add.2d	v2, v2, v0
     5b8:      	fmov	x22, d2
     5bc:      	cmp	x22, #0x8
     5c0:      	b.lt	0x560 <ltmp0+0x560>
     5c4:      	mov.16b	v5, v31
     5c8:      	fdiv.4s	v0, v31, v21
     5cc:      	mov.16b	v6, v8
     5d0:      	fmul.4s	v0, v8, v0
     5d4:      	ldr	s1, [x4]
     5d8:      	fadd.4s	v1, v0, v1
     5dc:      	str	s1, [x13, x6]
     5e0:      	add	x9, x9, #0x1
     5e4:      	cmp	x9, #0x4
     5e8:      	b.ne	0x2c8 <ltmp0+0x2c8>
     5ec:      	b	0x7c <ltmp0+0x7c>
     5f0:      	str	w25, [sp, #0x190]
     5f4:      	lsr	x9, x10, #3
     5f8:      	cmp	x10, #0x8
     5fc:      	b.lo	0xac8 <ltmp0+0xac8>
     600:      	mov	x11, #0x0               ; =0
     604:      	ldr	x12, [x0]
     608:      	ldr	x13, [x0, #0x10]
     60c:      	ldr	x2, [x0, #0x20]
     610:      	ldr	x25, [x0, #0x30]
     614:      	add	x4, x13, #0x100
     618:      	subs	x5, x2, x25
     61c:      	lsr	x5, x5, #2
     620:      	ccmp	x5, x30, #0x0, hs
     624:      	cset	w5, hi
     628:      	subs	x6, x25, x2
     62c:      	mov	w19, #0x103             ; =259
     630:      	ccmp	x6, x19, #0x0, hs
     634:      	csinc	w5, w5, wzr, ls
     638:      	add	x6, x2, #0x100
     63c:      	lsl	w19, w28, #2
     640:      	b	0x7c4 <ltmp0+0x7c4>
     644:      	ldp	q0, q8, [x2]
     648:      	ldp	q12, q13, [x2, #0x20]
     64c:      	ldp	q29, q15, [x2, #0x40]
     650:      	ldp	q10, q11, [x2, #0x60]
     654:      	ldp	q1, q30, [x2, #0x80]
     658:      	str	q1, [sp, #0x1a0]
     65c:      	dup.4s	v28, v18[0]
     660:      	fdiv.4s	v27, v27, v28
     664:      	fdiv.4s	v26, v26, v28
     668:      	ldr	q31, [sp, #0x8f0]
     66c:      	ldr	q9, [sp, #0x8e0]
     670:      	fmul.4s	v26, v26, v9
     674:      	fmul.4s	v27, v27, v31
     678:      	ldp	q31, q9, [x2, #0xa0]
     67c:      	fadd.4s	v27, v8, v27
     680:      	fadd.4s	v26, v0, v26
     684:      	fdiv.4s	v0, v25, v28
     688:      	fdiv.4s	v24, v24, v28
     68c:      	ldr	q25, [sp, #0x910]
     690:      	ldr	q8, [sp, #0x900]
     694:      	fmul.4s	v1, v24, v8
     698:      	fmul.4s	v24, v0, v25
     69c:      	ldp	q25, q8, [x2, #0xc0]
     6a0:      	add	x23, x25, x23
     6a4:      	fadd.4s	v0, v13, v24
     6a8:      	ldp	q24, q13, [x2, #0xe0]
     6ac:      	str	q24, [sp, #0x1b0]
     6b0:      	ldr	s24, [x6]
     6b4:      	str	q24, [sp, #0x1c0]
     6b8:      	stp	q26, q27, [x23]
     6bc:      	fadd.4s	v1, v12, v1
     6c0:      	fdiv.4s	v23, v23, v28
     6c4:      	ldr	q26, [sp, #0x920]
     6c8:      	fmul.4s	v23, v23, v26
     6cc:      	ldr	q26, [sp, #0x930]
     6d0:      	fdiv.4s	v22, v22, v28
     6d4:      	fmul.4s	v22, v22, v26
     6d8:      	fadd.4s	v22, v15, v22
     6dc:      	fadd.4s	v23, v29, v23
     6e0:      	stp	q1, q0, [x23, #0x20]
     6e4:      	stp	q23, q22, [x23, #0x40]
     6e8:      	fdiv.4s	v0, v21, v28
     6ec:      	ldr	q1, [sp, #0x940]
     6f0:      	fmul.4s	v0, v0, v1
     6f4:      	ldr	q1, [sp, #0x950]
     6f8:      	fdiv.4s	v20, v20, v28
     6fc:      	fmul.4s	v1, v20, v1
     700:      	fadd.4s	v1, v11, v1
     704:      	fadd.4s	v0, v10, v0
     708:      	fdiv.4s	v19, v19, v28
     70c:      	ldr	q20, [sp, #0x960]
     710:      	fmul.4s	v19, v19, v20
     714:      	ldr	q20, [sp, #0x970]
     718:      	fdiv.4s	v17, v17, v28
     71c:      	fmul.4s	v17, v17, v20
     720:      	fadd.4s	v17, v30, v17
     724:      	stp	q0, q1, [x23, #0x60]
     728:      	ldr	q0, [sp, #0x1a0]
     72c:      	fadd.4s	v0, v0, v19
     730:      	fdiv.4s	v1, v16, v28
     734:      	ldr	q16, [sp, #0x980]
     738:      	fmul.4s	v1, v1, v16
     73c:      	ldr	q16, [sp, #0x990]
     740:      	fdiv.4s	v6, v6, v28
     744:      	fmul.4s	v6, v6, v16
     748:      	fadd.4s	v6, v9, v6
     74c:      	stp	q0, q17, [x23, #0x80]
     750:      	fadd.4s	v0, v31, v1
     754:      	fdiv.4s	v1, v5, v28
     758:      	ldr	q5, [sp, #0x9a0]
     75c:      	fmul.4s	v1, v1, v5
     760:      	ldr	q5, [sp, #0x9b0]
     764:      	fdiv.4s	v4, v4, v28
     768:      	fmul.4s	v4, v4, v5
     76c:      	fadd.4s	v4, v8, v4
     770:      	stp	q0, q6, [x23, #0xa0]
     774:      	fadd.4s	v0, v25, v1
     778:      	fdiv.4s	v1, v3, v28
     77c:      	fdiv.4s	v2, v2, v28
     780:      	ldr	q3, [sp, #0x9c0]
     784:      	fmul.4s	v2, v2, v3
     788:      	ldr	q3, [sp, #0x9d0]
     78c:      	fmul.4s	v1, v1, v3
     790:      	fadd.4s	v3, v13, v1
     794:      	stp	q0, q4, [x23, #0xc0]
     798:      	ldr	q0, [sp, #0x1b0]
     79c:      	fadd.4s	v0, v0, v2
     7a0:      	fdiv.4s	v1, v14, v18
     7a4:      	fmul.4s	v1, v7, v1
     7a8:      	ldr	q2, [sp, #0x1c0]
     7ac:      	fadd.4s	v1, v1, v2
     7b0:      	stp	q0, q3, [x23, #0xe0]
     7b4:      	str	s1, [x25, x22]
     7b8:      	add	x11, x11, #0x1
     7bc:      	cmp	x11, x9
     7c0:      	b.eq	0xac8 <ltmp0+0xac8>
     7c4:      	add	w22, w11, w19
     7c8:      	and	x22, x22, #0x1fffffff
     7cc:      	add	x22, x22, x22, lsl #6
     7d0:      	lsl	x23, x22, #2
     7d4:      	add	x22, x12, x23
     7d8:      	ldp	q0, q3, [x22]
     7dc:      	ldp	q5, q4, [x22, #0x20]
     7e0:      	ldp	q6, q16, [x22, #0x40]
     7e4:      	ldp	q19, q17, [x22, #0x60]
     7e8:      	ldp	q28, q29, [x22, #0x80]
     7ec:      	ldp	q31, q30, [x22, #0xa0]
     7f0:      	ldp	q8, q9, [x22, #0xc0]
     7f4:      	ldp	q2, q1, [x22, #0xe0]
     7f8:      	add	x22, x23, #0x100
     7fc:      	ldr	s18, [x12, x22]
     800:      	fadd.4s	v7, v19, v2
     804:      	fadd.4s	v20, v17, v1
     808:      	fadd.4s	v21, v16, v9
     80c:      	fadd.4s	v22, v6, v8
     810:      	fadd.4s	v23, v5, v31
     814:      	fadd.4s	v24, v4, v30
     818:      	fadd.4s	v25, v3, v29
     81c:      	fadd.4s	v26, v0, v28
     820:      	fadd.4s	v27, v26, v18
     824:      	mov.s	v26[0], v27[0]
     828:      	fadd.4s	v24, v24, v25
     82c:      	fadd.4s	v23, v23, v26
     830:      	fadd.4s	v22, v22, v23
     834:      	fadd.4s	v21, v21, v24
     838:      	fadd.4s	v20, v20, v21
     83c:      	fadd.4s	v7, v7, v22
     840:      	rev64.4s	v21, v7
     844:      	rev64.4s	v22, v20
     848:      	fadd.4s	v20, v20, v22
     84c:      	fadd.4s	v7, v7, v21
     850:      	dup.4s	v21, v7[2]
     854:      	dup.4s	v22, v20[2]
     858:      	fadd.4s	v20, v20, v22
     85c:      	fadd.4s	v7, v7, v21
     860:      	fadd.4s	v7, v7, v20
     864:      	movi	d12, #0000000000000000
     868:      	fadd	s20, s7, s12
     86c:      	fmov	s7, w14
     870:      	fdiv	s10, s20, s7
     874:      	dup.4s	v11, v10[0]
     878:      	fsub.4s	v26, v0, v11
     87c:      	fsub.4s	v27, v3, v11
     880:      	str	q27, [sp, #0xa10]
     884:      	str	q26, [sp, #0xa00]
     888:      	fsub.4s	v24, v5, v11
     88c:      	fsub.4s	v25, v4, v11
     890:      	str	q25, [sp, #0xa30]
     894:      	str	q24, [sp, #0xa20]
     898:      	fsub.4s	v23, v6, v11
     89c:      	fsub.4s	v22, v16, v11
     8a0:      	str	q22, [sp, #0xa50]
     8a4:      	str	q23, [sp, #0xa40]
     8a8:      	fsub.4s	v21, v19, v11
     8ac:      	fsub.4s	v20, v17, v11
     8b0:      	str	q20, [sp, #0xa70]
     8b4:      	str	q21, [sp, #0xa60]
     8b8:      	fsub.4s	v19, v28, v11
     8bc:      	fsub.4s	v17, v29, v11
     8c0:      	str	q17, [sp, #0xa90]
     8c4:      	str	q19, [sp, #0xa80]
     8c8:      	fsub.4s	v16, v31, v11
     8cc:      	fsub.4s	v6, v30, v11
     8d0:      	str	q6, [sp, #0xab0]
     8d4:      	str	q16, [sp, #0xaa0]
     8d8:      	fsub.4s	v5, v8, v11
     8dc:      	fsub.4s	v4, v9, v11
     8e0:      	str	q4, [sp, #0xad0]
     8e4:      	str	q5, [sp, #0xac0]
     8e8:      	fsub.4s	v2, v2, v11
     8ec:      	fsub.4s	v3, v1, v11
     8f0:      	str	q3, [sp, #0xaf0]
     8f4:      	str	q2, [sp, #0xae0]
     8f8:      	fsub.4s	v14, v18, v10
     8fc:      	str	q14, [sp, #0xb00]
     900:      	ldp	q0, q18, [x13, #0xc0]
     904:      	str	q0, [sp, #0x9a0]
     908:      	str	q18, [sp, #0x9b0]
     90c:      	ldp	q0, q18, [x13, #0xe0]
     910:      	str	q0, [sp, #0x9c0]
     914:      	str	q18, [sp, #0x9d0]
     918:      	ldp	q0, q18, [x13, #0x80]
     91c:      	str	q0, [sp, #0x960]
     920:      	str	q18, [sp, #0x970]
     924:      	ldp	q0, q18, [x13, #0xa0]
     928:      	str	q0, [sp, #0x980]
     92c:      	str	q18, [sp, #0x990]
     930:      	ldp	q0, q18, [x13, #0x40]
     934:      	str	q0, [sp, #0x920]
     938:      	str	q18, [sp, #0x930]
     93c:      	ldp	q0, q18, [x13, #0x60]
     940:      	str	q0, [sp, #0x940]
     944:      	str	q18, [sp, #0x950]
     948:      	ldp	q0, q18, [x13]
     94c:      	str	q0, [sp, #0x8e0]
     950:      	str	q18, [sp, #0x8f0]
     954:      	ldp	q0, q18, [x13, #0x20]
     958:      	str	q0, [sp, #0x900]
     95c:      	str	q18, [sp, #0x910]
     960:      	fmul.4s	v0, v26, v26
     964:      	fmul.4s	v18, v27, v27
     968:      	fmul.4s	v28, v25, v25
     96c:      	fmul.4s	v29, v24, v24
     970:      	fmul.4s	v30, v23, v23
     974:      	fmul.4s	v31, v22, v22
     978:      	fmul.4s	v8, v20, v20
     97c:      	fmul.4s	v9, v21, v21
     980:      	fmul.4s	v10, v3, v3
     984:      	fmul.4s	v11, v2, v2
     988:      	fadd.4s	v9, v9, v11
     98c:      	fadd.4s	v8, v8, v10
     990:      	fmul.4s	v10, v5, v5
     994:      	fmul.4s	v11, v4, v4
     998:      	fadd.4s	v31, v31, v11
     99c:      	fadd.4s	v30, v30, v10
     9a0:      	fmul.4s	v10, v6, v6
     9a4:      	fmul.4s	v11, v16, v16
     9a8:      	fadd.4s	v29, v29, v11
     9ac:      	fadd.4s	v28, v28, v10
     9b0:      	fmul.4s	v10, v19, v19
     9b4:      	fmul.4s	v11, v17, v17
     9b8:      	fadd.4s	v18, v18, v11
     9bc:      	fadd.4s	v0, v0, v10
     9c0:      	fmul.4s	v10, v14, v14
     9c4:      	fadd.4s	v10, v10, v0
     9c8:      	mov.s	v0[0], v10[0]
     9cc:      	fadd.4s	v18, v28, v18
     9d0:      	fadd.4s	v0, v29, v0
     9d4:      	fadd.4s	v0, v30, v0
     9d8:      	fadd.4s	v18, v31, v18
     9dc:      	fadd.4s	v18, v8, v18
     9e0:      	fadd.4s	v0, v9, v0
     9e4:      	rev64.4s	v28, v0
     9e8:      	rev64.4s	v29, v18
     9ec:      	fadd.4s	v18, v18, v29
     9f0:      	fadd.4s	v0, v0, v28
     9f4:      	dup.4s	v28, v0[2]
     9f8:      	dup.4s	v29, v18[2]
     9fc:      	fadd.4s	v18, v18, v29
     a00:      	fadd.4s	v0, v0, v28
     a04:      	fadd.4s	v0, v0, v18
     a08:      	fadd	s0, s0, s12
     a0c:      	fdiv	s0, s0, s7
     a10:      	ldr	s7, [x4]
     a14:      	str	q7, [sp, #0x9e0]
     a18:      	fmov	s18, w15
     a1c:      	fadd	s0, s0, s18
     a20:      	fsqrt	s18, s0
     a24:      	tbz	w5, #0x0, 0x644 <ltmp0+0x644>
     a28:      	mov	x24, #0x0               ; =0
     a2c:      	dup.4s	v2, v18[0]
     a30:      	add	x23, x25, x23
     a34:      	movi.2d	v3, #0000000000000000
     a38:      	movi.2d	v4, #0000000000000000
     a3c:      	movi.2d	v5, #0000000000000000
     a40:      	movi.2d	v6, #0000000000000000
     a44:      	lsl	x24, x24, #5
     a48:      	add	x26, x16, x24
     a4c:      	ldp	q1, q0, [x26]
     a50:      	fdiv.4s	v1, v1, v2
     a54:      	fdiv.4s	v0, v0, v2
     a58:      	add	x24, x17, x24
     a5c:      	ldp	q16, q17, [x24]
     a60:      	fmul.4s	v0, v0, v17
     a64:      	fmul.4s	v1, v1, v16
     a68:      	fmov	x24, d3
     a6c:      	lsl	x24, x24, #5
     a70:      	add	x26, x2, x24
     a74:      	ldp	q17, q16, [x26]
     a78:      	fadd.4s	v1, v1, v17
     a7c:      	fadd.4s	v0, v0, v16
     a80:      	add	x24, x23, x24
     a84:      	stp	q1, q0, [x24]
     a88:      	dup.2d	v0, x1
     a8c:      	add.2d	v5, v5, v0
     a90:      	add.2d	v4, v4, v0
     a94:      	add.2d	v6, v6, v0
     a98:      	add.2d	v3, v3, v0
     a9c:      	fmov	x24, d3
     aa0:      	cmp	x24, #0x8
     aa4:      	b.lt	0xa44 <ltmp0+0xa44>
     aa8:      	fdiv.4s	v0, v14, v18
     aac:      	fmul.4s	v0, v7, v0
     ab0:      	ldr	s1, [x6]
     ab4:      	fadd.4s	v1, v0, v1
     ab8:      	str	s1, [x25, x22]
     abc:      	add	x11, x11, #0x1
     ac0:      	cmp	x11, x9
     ac4:      	b.ne	0x7c4 <ltmp0+0x7c4>
     ac8:      	and	w10, w10, #0x7
     acc:      	ldr	w25, [sp, #0x190]
     ad0:      	cbz	w10, 0x7c <ltmp0+0x7c>
     ad4:      	dup.4s	v0, w10
     ad8:      	adrp	x10, 0x0 <ltmp0>
     adc:      	ldr	q1, [x10]
     ae0:      	adrp	x10, 0x0 <ltmp0>
     ae4:      	ldr	q2, [x10]
     ae8:      	cmhi.4s	v6, v0, v2
     aec:      	cmhi.4s	v7, v0, v1
     af0:      	uzp1.8h	v1, v7, v6
     af4:      	umaxv.8h	h0, v1
     af8:      	fmov	w10, s0
     afc:      	tbz	w10, #0x0, 0x7c <ltmp0+0x7c>
     b00:      	mov	x11, #0x0               ; =0
     b04:      	ldr	x10, [x0]
     b08:      	ldr	x23, [x0, #0x10]
     b0c:      	ldr	x19, [x0, #0x20]
     b10:      	ldr	x30, [x0, #0x30]
     b14:      	adrp	x12, 0x0 <ltmp0>
     b18:      	ldr	q0, [x12]
     b1c:      	str	q1, [sp, #0xa0]
     b20:      	and.16b	v0, v1, v0
     b24:      	addv.8h	h16, v0
     b28:      	ubfiz	w12, w28, #2, #27
     b2c:      	orr	w9, w12, w9
     b30:      	fmov	w12, s16
     b34:      	and	w12, w12, #0xff
     b38:      	str	w12, [sp, #0xb8]
     b3c:      	dup.4s	v0, w9
     b40:      	and.16b	v1, v7, v0
     b44:      	and.16b	v0, v6, v0
     b48:      	ushll2.2d	v3, v0, #0x0
     b4c:      	ushll2.2d	v4, v1, #0x0
     b50:      	ushll.2d	v5, v0, #0x0
     b54:      	ushll.2d	v1, v1, #0x0
     b58:      	fmov	x9, d1
     b5c:      	mov	w12, #0x104             ; =260
     b60:      	umaddl	x9, w9, w12, x10
     b64:      	b	0xb88 <ltmp0+0xb88>
     b68:      	add	x12, x16, x11
     b6c:      	ldp	q0, q18, [x12]
     b70:      	bif.16b	v17, v18, v6
     b74:      	bit.16b	v0, v2, v7
     b78:      	stp	q0, q17, [x12]
     b7c:      	add	x11, x11, #0x20
     b80:      	cmp	x11, #0x100
     b84:      	b.eq	0xc20 <ltmp0+0xc20>
     b88:      	fmov	w13, s16
     b8c:      	add	x12, x9, x11
     b90:      	movi.2d	v2, #0000000000000000
     b94:      	movi.2d	v17, #0000000000000000
     b98:      	tbnz	w13, #0x0, 0xbc0 <ltmp0+0xbc0>
     b9c:      	and	w13, w13, #0xff
     ba0:      	tbnz	w13, #0x1, 0xbcc <ltmp0+0xbcc>
     ba4:      	tbnz	w13, #0x2, 0xbd8 <ltmp0+0xbd8>
     ba8:      	tbnz	w13, #0x3, 0xbe4 <ltmp0+0xbe4>
     bac:      	tbnz	w13, #0x4, 0xbf0 <ltmp0+0xbf0>
     bb0:      	tbnz	w13, #0x5, 0xbfc <ltmp0+0xbfc>
     bb4:      	tbnz	w13, #0x6, 0xc08 <ltmp0+0xc08>
     bb8:      	tbz	w13, #0x7, 0xb68 <ltmp0+0xb68>
     bbc:      	b	0xc14 <ltmp0+0xc14>
     bc0:      	ldr	s2, [x12]
     bc4:      	and	w13, w13, #0xff
     bc8:      	tbz	w13, #0x1, 0xba4 <ltmp0+0xba4>
     bcc:      	add	x2, x12, #0x4
     bd0:      	ld1.s	{ v2 }[1], [x2]
     bd4:      	tbz	w13, #0x2, 0xba8 <ltmp0+0xba8>
     bd8:      	add	x2, x12, #0x8
     bdc:      	ld1.s	{ v2 }[2], [x2]
     be0:      	tbz	w13, #0x3, 0xbac <ltmp0+0xbac>
     be4:      	add	x2, x12, #0xc
     be8:      	ld1.s	{ v2 }[3], [x2]
     bec:      	tbz	w13, #0x4, 0xbb0 <ltmp0+0xbb0>
     bf0:      	add	x2, x12, #0x10
     bf4:      	ld1.s	{ v17 }[0], [x2]
     bf8:      	tbz	w13, #0x5, 0xbb4 <ltmp0+0xbb4>
     bfc:      	add	x2, x12, #0x14
     c00:      	ld1.s	{ v17 }[1], [x2]
     c04:      	tbz	w13, #0x6, 0xbb8 <ltmp0+0xbb8>
     c08:      	add	x2, x12, #0x18
     c0c:      	ld1.s	{ v17 }[2], [x2]
     c10:      	tbz	w13, #0x7, 0xb68 <ltmp0+0xb68>
     c14:      	add	x12, x12, #0x1c
     c18:      	ld1.s	{ v17 }[3], [x12]
     c1c:      	b	0xb68 <ltmp0+0xb68>
     c20:      	xtn.4h	v0, v7
     c24:      	uzp1.8b	v0, v0, v0
     c28:      	sshll.2d	v18, v7, #0x0
     c2c:      	adrp	x9, 0x0 <ltmp0>
     c30:      	ldr	q2, [x9]
     c34:      	and.16b	v17, v18, v2
     c38:      	movi.2d	v21, #0000000000000000
     c3c:      	mov.b	v21[0], v0[0]
     c40:      	adrp	x9, 0x0 <ltmp0>
     c44:      	ldr	d2, [x9]
     c48:      	str	d2, [sp, #0xf8]
     c4c:      	and.8b	v2, v21, v2
     c50:      	addv.8b	b2, v2
     c54:      	fmov	w9, s2
     c58:      	umaxv.8b	b2, v21
     c5c:      	fmov	w11, s2
     c60:      	rbit	w12, w9
     c64:      	clz	w12, w12
     c68:      	tst	w11, #0x1
     c6c:      	csel	w2, w12, wzr, ne
     c70:      	mov	w12, #0x40              ; =64
     c74:      	dup.2d	v19, x12
     c78:      	orr.16b	v2, v17, v19
     c7c:      	xtn.2s	v20, v1
     c80:      	str	q2, [sp, #0x100]
     c84:      	movi.2s	v1, #0x41
     c88:      	umlal.2d	v2, v20, v1
     c8c:      	movi.2d	v1, #0000000000000000
     c90:      	mov.b	v1[0], v0[0]
     c94:      	ushll.2d	v0, v1, #0x0
     c98:      	shl.2d	v0, v0, #0x3f
     c9c:      	cmlt.2d	v0, v0, #0
     ca0:      	str	q2, [sp, #0x150]
     ca4:      	and.16b	v0, v0, v2
     ca8:      	movi.2d	v1, #0000000000000000
     cac:      	str	q1, [sp, #0x680]
     cb0:      	str	q1, [sp, #0x670]
     cb4:      	str	q1, [sp, #0x660]
     cb8:      	str	q0, [sp, #0x650]
     cbc:      	and	x12, x2, #0x7
     cc0:      	add	x13, sp, #0x650
     cc4:      	ldr	x12, [x13, x12, lsl #3]
     cc8:      	sub	x12, x12, x2
     ccc:      	add	x10, x10, x12, lsl #2
     cd0:      	movi.2d	v24, #0000000000000000
     cd4:      	movi.2d	v27, #0000000000000000
     cd8:      	tbnz	w11, #0x0, 0x1e88 <ltmp0+0x1e88>
     cdc:      	tbnz	w9, #0x1, 0x1e90 <ltmp0+0x1e90>
     ce0:      	tbnz	w9, #0x2, 0x1e9c <ltmp0+0x1e9c>
     ce4:      	tbnz	w9, #0x3, 0x1ea8 <ltmp0+0x1ea8>
     ce8:      	tbnz	w9, #0x4, 0x1eb4 <ltmp0+0x1eb4>
     cec:      	tbnz	w9, #0x5, 0x1ec0 <ltmp0+0x1ec0>
     cf0:      	tbnz	w9, #0x6, 0x1ecc <ltmp0+0x1ecc>
     cf4:      	str	q17, [sp, #0x1a0]
     cf8:      	str	q16, [sp, #0x170]
     cfc:      	tbz	w9, #0x7, 0xd08 <ltmp0+0xd08>
     d00:      	add	x10, x10, #0x1c
     d04:      	ld1.s	{ v27 }[3], [x10]
     d08:      	sshll.2d	v0, v6, #0x0
     d0c:      	sshll2.2d	v30, v7, #0x0
     d10:      	sshll2.2d	v31, v6, #0x0
     d14:      	adrp	x10, 0x0 <ltmp0>
     d18:      	ldr	q1, [x10]
     d1c:      	and.16b	v1, v31, v1
     d20:      	adrp	x10, 0x0 <ltmp0>
     d24:      	ldr	q2, [x10]
     d28:      	and.16b	v2, v30, v2
     d2c:      	adrp	x10, 0x0 <ltmp0>
     d30:      	ldr	q17, [x10]
     d34:      	and.16b	v16, v0, v17
     d38:      	adrp	x10, 0x0 <ltmp0>
     d3c:      	ldr	q23, [x10]
     d40:      	and.16b	v23, v31, v23
     d44:      	adrp	x10, 0x0 <ltmp0>
     d48:      	ldr	q25, [x10]
     d4c:      	and.16b	v25, v30, v25
     d50:      	adrp	x10, 0x0 <ltmp0>
     d54:      	ldr	q26, [x10]
     d58:      	and.16b	v0, v0, v26
     d5c:      	adrp	x10, 0x0 <ltmp0>
     d60:      	ldr	q26, [x10]
     d64:      	and.16b	v18, v18, v26
     d68:      	stp	q16, q2, [sp, #0x70]
     d6c:      	orr.16b	v17, v16, v19
     d70:      	orr.16b	v22, v2, v19
     d74:      	str	q1, [sp, #0x90]
     d78:      	orr.16b	v16, v1, v19
     d7c:      	movi.2s	v1, #0x41
     d80:      	umull.2d	v2, v20, v1
     d84:      	str	q2, [sp, #0x110]
     d88:      	xtn.2s	v4, v4
     d8c:      	xtn.2s	v5, v5
     d90:      	xtn.2s	v3, v3
     d94:      	stp	q17, q16, [sp, #0xd0]
     d98:      	mov.16b	v2, v16
     d9c:      	umlal.2d	v2, v3, v1
     da0:      	str	q2, [sp, #0x140]
     da4:      	str	q22, [sp, #0xc0]
     da8:      	mov.16b	v2, v22
     dac:      	umlal.2d	v2, v4, v1
     db0:      	str	q2, [sp, #0x130]
     db4:      	mov.16b	v2, v17
     db8:      	umlal.2d	v2, v5, v1
     dbc:      	str	q2, [sp, #0x120]
     dc0:      	sshll.2d	v3, v7, #0x0
     dc4:      	sshll.2d	v4, v6, #0x0
     dc8:      	str	q18, [sp, #0x610]
     dcc:      	str	q25, [sp, #0x620]
     dd0:      	str	q0, [sp, #0x630]
     dd4:      	str	q23, [sp, #0x640]
     dd8:      	and	x10, x2, #0x7
     ddc:      	add	x11, sp, #0x610
     de0:      	ldr	x10, [x11, x10, lsl #3]
     de4:      	orr	x10, x10, #0x100
     de8:      	str	x2, [sp, #0x168]
     dec:      	sub	x10, x10, x2, lsl #2
     df0:      	tst	w9, #0xff
     df4:      	csel	x9, xzr, x10, eq
     df8:      	str	x9, [sp, #0x1c0]
     dfc:      	add	x9, x16, x9
     e00:      	ldp	q0, q5, [x9]
     e04:      	zip2.8b	v19, v21, v0
     e08:      	ushll.4s	v19, v19, #0x0
     e0c:      	shl.4s	v19, v19, #0x1f
     e10:      	cmlt.4s	v19, v19, #0
     e14:      	stp	q27, q24, [sp, #0x30]
     e18:      	bit.16b	v5, v27, v19
     e1c:      	str	q21, [sp, #0x1b0]
     e20:      	zip1.8b	v19, v21, v0
     e24:      	ushll.4s	v19, v19, #0x0
     e28:      	shl.4s	v19, v19, #0x1f
     e2c:      	cmlt.4s	v19, v19, #0
     e30:      	bit.16b	v0, v24, v19
     e34:      	stp	q0, q5, [x9]
     e38:      	fmov	x26, d18
     e3c:      	dup.2d	v0, x20
     e40:      	and.16b	v9, v31, v0
     e44:      	and.16b	v15, v30, v0
     e48:      	and.16b	v5, v4, v0
     e4c:      	and.16b	v3, v3, v0
     e50:      	fmov	x22, d3
     e54:      	ldr	q0, [sp, #0xa60]
     e58:      	ldr	q4, [sp, #0xa70]
     e5c:      	and.16b	v18, v6, v4
     e60:      	and.16b	v4, v7, v0
     e64:      	ldr	q0, [sp, #0xa40]
     e68:      	ldr	q19, [sp, #0xa50]
     e6c:      	and.16b	v20, v6, v19
     e70:      	and.16b	v19, v7, v0
     e74:      	ldr	q0, [sp, #0xa20]
     e78:      	ldr	q23, [sp, #0xa30]
     e7c:      	and.16b	v23, v6, v23
     e80:      	and.16b	v25, v7, v0
     e84:      	add	x9, x16, x26
     e88:      	ldp	q0, q26, [x9]
     e8c:      	and.16b	v27, v6, v26
     e90:      	mov	x9, x22
     e94:      	and.16b	v28, v7, v0
     e98:      	mov.16b	v29, v3
     e9c:      	mov.16b	v8, v15
     ea0:      	mov.16b	v11, v5
     ea4:      	mov.16b	v14, v9
     ea8:      	sshll.2d	v0, v7, #0x0
     eac:      	sshll.2d	v24, v6, #0x0
     eb0:      	add	x9, x16, x9, lsl #5
     eb4:      	ldp	q26, q10, [x9]
     eb8:      	fadd.4s	v26, v28, v26
     ebc:      	fadd.4s	v10, v27, v10
     ec0:      	ldp	q12, q22, [x9, #0x20]
     ec4:      	fadd.4s	v12, v25, v12
     ec8:      	fadd.4s	v22, v23, v22
     ecc:      	ldp	q1, q13, [x9, #0x40]
     ed0:      	fadd.4s	v1, v19, v1
     ed4:      	fadd.4s	v13, v20, v13
     ed8:      	ldp	q2, q21, [x9, #0x60]
     edc:      	fadd.4s	v2, v4, v2
     ee0:      	fadd.4s	v21, v18, v21
     ee4:      	dup.2d	v17, x20
     ee8:      	and.16b	v16, v31, v17
     eec:      	add.2d	v14, v14, v16
     ef0:      	and.16b	v16, v30, v17
     ef4:      	add.2d	v8, v8, v16
     ef8:      	and.16b	v16, v24, v17
     efc:      	add.2d	v11, v11, v16
     f00:      	and.16b	v0, v0, v17
     f04:      	add.2d	v29, v29, v0
     f08:      	bit.16b	v27, v10, v6
     f0c:      	bit.16b	v28, v26, v7
     f10:      	bit.16b	v23, v22, v6
     f14:      	bit.16b	v25, v12, v7
     f18:      	bit.16b	v20, v13, v6
     f1c:      	bit.16b	v19, v1, v7
     f20:      	bit.16b	v18, v21, v6
     f24:      	bit.16b	v4, v2, v7
     f28:      	fmov	x9, d29
     f2c:      	cmp	x9, #0x8
     f30:      	b.lt	0xea8 <ltmp0+0xea8>
     f34:      	mov	x27, #0x0               ; =0
     f38:      	ldr	q0, [sp, #0xa0]
     f3c:      	xtn.8b	v29, v0
     f40:      	ldp	q11, q8, [sp, #0x30]
     f44:      	fadd.4s	v0, v11, v27
     f48:      	fadd.4s	v1, v8, v28
     f4c:      	ldr	q28, [sp, #0x1b0]
     f50:      	zip2.8b	v2, v28, v0
     f54:      	ushll.4s	v2, v2, #0x0
     f58:      	shl.4s	v2, v2, #0x1f
     f5c:      	cmlt.4s	v2, v2, #0
     f60:      	and.16b	v0, v2, v0
     f64:      	zip2.8b	v2, v29, v0
     f68:      	ushll.4s	v2, v2, #0x0
     f6c:      	shl.4s	v2, v2, #0x1f
     f70:      	cmlt.4s	v2, v2, #0
     f74:      	bit.16b	v0, v10, v2
     f78:      	zip1.8b	v2, v28, v0
     f7c:      	ushll.4s	v2, v2, #0x0
     f80:      	shl.4s	v2, v2, #0x1f
     f84:      	cmlt.4s	v2, v2, #0
     f88:      	movi.2d	v16, #0000000000000000
     f8c:      	mov.b	v16[2], v29[1]
     f90:      	mov.b	v16[4], v29[2]
     f94:      	and.16b	v1, v2, v1
     f98:      	mov.b	v16[6], v29[3]
     f9c:      	ushll.4s	v2, v16, #0x0
     fa0:      	shl.4s	v2, v2, #0x1f
     fa4:      	cmlt.4s	v2, v2, #0
     fa8:      	bit.16b	v1, v26, v2
     fac:      	fadd.4s	v1, v25, v1
     fb0:      	fadd.4s	v0, v23, v0
     fb4:      	fadd.4s	v0, v20, v0
     fb8:      	fadd.4s	v1, v19, v1
     fbc:      	fadd.4s	v4, v4, v1
     fc0:      	fadd.4s	v18, v18, v0
     fc4:      	ldr	q0, [sp, #0x1a0]
     fc8:      	ldr	q1, [sp, #0x80]
     fcc:      	uzp1.4s	v2, v0, v1
     fd0:      	ldr	q0, [sp, #0x90]
     fd4:      	ldr	q1, [sp, #0x70]
     fd8:      	uzp1.4s	v1, v1, v0
     fdc:      	movi.4s	v16, #0x1
     fe0:      	eor.16b	v0, v2, v16
     fe4:      	mov.s	w10, v0[1]
     fe8:      	eor.16b	v23, v1, v16
     fec:      	mov.s	w12, v0[2]
     ff0:      	mov.s	w13, v0[3]
     ff4:      	fmov	w9, s0
     ff8:      	add	x11, sp, #0x4a8
     ffc:      	bfxil	x11, x9, #0, #3
    1000:      	str	d29, [sp, #0x4a8]
    1004:      	ldrb	w11, [x11]
    1008:      	umov.b	w24, v29[0]
    100c:      	and	x9, x9, #0x7
    1010:      	str	q18, [sp, #0x580]
    1014:      	str	q4, [sp, #0x570]
    1018:      	add	x2, sp, #0x570
    101c:      	ldr	s0, [x2, x9, lsl #2]
    1020:      	ands	w9, w24, #0x1
    1024:      	tst	w9, w11
    1028:      	movi	d25, #0000000000000000
    102c:      	fcsel	s17, s0, s25, ne
    1030:      	and	x2, x10, #0x7
    1034:      	add	x11, sp, #0x4a8
    1038:      	bfxil	x11, x10, #0, #3
    103c:      	ldrb	w10, [x11]
    1040:      	umov.b	w11, v29[1]
    1044:      	str	q18, [sp, #0x560]
    1048:      	str	q4, [sp, #0x550]
    104c:      	add	x3, sp, #0x550
    1050:      	ldr	s0, [x3, x2, lsl #2]
    1054:      	and	w10, w11, w10
    1058:      	tst	w10, #0x1
    105c:      	fcsel	s19, s0, s25, ne
    1060:      	and	x2, x12, #0x7
    1064:      	add	x10, sp, #0x4a8
    1068:      	bfxil	x10, x12, #0, #3
    106c:      	ldrb	w12, [x10]
    1070:      	umov.b	w10, v29[2]
    1074:      	and	w12, w10, w12
    1078:      	str	q18, [sp, #0x540]
    107c:      	str	q4, [sp, #0x530]
    1080:      	add	x3, sp, #0x530
    1084:      	ldr	s0, [x3, x2, lsl #2]
    1088:      	tst	w12, #0x1
    108c:      	fcsel	s20, s0, s25, ne
    1090:      	and	x12, x13, #0x7
    1094:      	add	x2, sp, #0x4a8
    1098:      	bfxil	x2, x13, #0, #3
    109c:      	ldrb	w13, [x2]
    10a0:      	umov.b	w2, v29[3]
    10a4:      	and	w13, w2, w13
    10a8:      	str	q18, [sp, #0x520]
    10ac:      	str	q4, [sp, #0x510]
    10b0:      	add	x3, sp, #0x510
    10b4:      	ldr	s0, [x3, x12, lsl #2]
    10b8:      	tst	w13, #0x1
    10bc:      	mov.s	w12, v23[1]
    10c0:      	fcsel	s24, s0, s25, ne
    10c4:      	mov.s	w13, v23[2]
    10c8:      	mov.s	w6, v23[3]
    10cc:      	fmov	w3, s23
    10d0:      	and	x4, x3, #0x7
    10d4:      	add	x5, sp, #0x4a8
    10d8:      	bfxil	x5, x3, #0, #3
    10dc:      	ldrb	w3, [x5]
    10e0:      	umov.b	w5, v29[4]
    10e4:      	and	w3, w5, w3
    10e8:      	str	q18, [sp, #0x600]
    10ec:      	str	q4, [sp, #0x5f0]
    10f0:      	add	x25, sp, #0x5f0
    10f4:      	ldr	s0, [x25, x4, lsl #2]
    10f8:      	tst	w3, #0x1
    10fc:      	fcsel	s0, s0, s25, ne
    1100:      	and	x3, x12, #0x7
    1104:      	add	x25, sp, #0x4a8
    1108:      	bfxil	x25, x12, #0, #3
    110c:      	umov.b	w4, v29[5]
    1110:      	ldrb	w12, [x25]
    1114:      	and	w12, w4, w12
    1118:      	str	q18, [sp, #0x5e0]
    111c:      	str	q4, [sp, #0x5d0]
    1120:      	add	x25, sp, #0x5d0
    1124:      	ldr	s16, [x25, x3, lsl #2]
    1128:      	tst	w12, #0x1
    112c:      	fcsel	s16, s16, s25, ne
    1130:      	and	x12, x13, #0x7
    1134:      	add	x3, sp, #0x4a8
    1138:      	bfxil	x3, x13, #0, #3
    113c:      	ldrb	w13, [x3]
    1140:      	umov.b	w3, v29[6]
    1144:      	str	q18, [sp, #0x5c0]
    1148:      	str	q4, [sp, #0x5b0]
    114c:      	add	x25, sp, #0x5b0
    1150:      	ldr	s21, [x25, x12, lsl #2]
    1154:      	and	w12, w3, w13
    1158:      	tst	w12, #0x1
    115c:      	fcsel	s21, s21, s25, ne
    1160:      	and	x13, x6, #0x7
    1164:      	add	x12, sp, #0x4a8
    1168:      	bfxil	x12, x6, #0, #3
    116c:      	ldrb	w6, [x12]
    1170:      	umov.b	w12, v29[7]
    1174:      	and	w6, w12, w6
    1178:      	str	q18, [sp, #0x5a0]
    117c:      	str	q4, [sp, #0x590]
    1180:      	add	x25, sp, #0x590
    1184:      	ldr	s22, [x25, x13, lsl #2]
    1188:      	tst	w6, #0x1
    118c:      	fcsel	s22, s22, s25, ne
    1190:      	mov.s	v0[1], v16[0]
    1194:      	mov.s	v0[2], v21[0]
    1198:      	mov.s	v0[3], v22[0]
    119c:      	mov.s	v17[1], v19[0]
    11a0:      	mov.s	v17[2], v20[0]
    11a4:      	mov.s	v17[3], v24[0]
    11a8:      	fadd.4s	v4, v4, v17
    11ac:      	fadd.4s	v0, v18, v0
    11b0:      	movi.4s	v16, #0x2
    11b4:      	eor.16b	v1, v1, v16
    11b8:      	eor.16b	v2, v2, v16
    11bc:      	fmov	w13, s2
    11c0:      	add	x6, sp, #0x4a8
    11c4:      	bfxil	x6, x13, #0, #3
    11c8:      	ldrb	w6, [x6]
    11cc:      	and	x13, x13, #0x7
    11d0:      	str	q0, [sp, #0x500]
    11d4:      	str	q4, [sp, #0x4f0]
    11d8:      	add	x25, sp, #0x4f0
    11dc:      	ldr	s2, [x25, x13, lsl #2]
    11e0:      	tst	w9, w6
    11e4:      	fcsel	s2, s2, s25, ne
    11e8:      	fmov	w9, s1
    11ec:      	and	x13, x9, #0x7
    11f0:      	add	x6, sp, #0x4a8
    11f4:      	bfxil	x6, x9, #0, #3
    11f8:      	ldrb	w9, [x6]
    11fc:      	and	w9, w5, w9
    1200:      	str	q0, [sp, #0x4e0]
    1204:      	str	q4, [sp, #0x4d0]
    1208:      	add	x6, sp, #0x4d0
    120c:      	ldr	s1, [x6, x13, lsl #2]
    1210:      	tst	w9, #0x1
    1214:      	fcsel	s1, s1, s25, ne
    1218:      	fadd.4s	v0, v0, v1
    121c:      	and	w6, w24, w5
    1220:      	tst	w6, #0x1
    1224:      	fcsel	s0, s0, s25, ne
    1228:      	ands	w13, w24, #0x1
    122c:      	fadd.4s	v1, v4, v2
    1230:      	fadd	s0, s1, s0
    1234:      	fcsel	s1, s0, s25, ne
    1238:      	tst	w6, #0x1
    123c:      	and	w9, w11, w24
    1240:      	fcsel	s2, s0, s25, ne
    1244:      	str	w9, [sp, #0x70]
    1248:      	tst	w9, #0x1
    124c:      	and	w9, w10, w24
    1250:      	fcsel	s4, s0, s25, ne
    1254:      	str	w9, [sp, #0x6c]
    1258:      	tst	w9, #0x1
    125c:      	and	w9, w2, w24
    1260:      	fcsel	s16, s0, s25, ne
    1264:      	str	w9, [sp, #0x68]
    1268:      	tst	w9, #0x1
    126c:      	fcsel	s17, s0, s25, ne
    1270:      	and	w9, w4, w24
    1274:      	str	w9, [sp, #0x80]
    1278:      	tst	w9, #0x1
    127c:      	fcsel	s18, s0, s25, ne
    1280:      	and	w9, w3, w24
    1284:      	str	w9, [sp, #0x90]
    1288:      	tst	w9, #0x1
    128c:      	fcsel	s19, s0, s25, ne
    1290:      	and	w9, w12, w24
    1294:      	str	w9, [sp, #0xa0]
    1298:      	tst	w9, #0x1
    129c:      	fcsel	s0, s0, s25, ne
    12a0:      	mov.s	v1[1], v4[0]
    12a4:      	mov.s	v1[2], v16[0]
    12a8:      	mov.s	v1[3], v17[0]
    12ac:      	mov.s	v2[1], v18[0]
    12b0:      	mov.s	v2[2], v19[0]
    12b4:      	mov.s	v2[3], v0[0]
    12b8:      	ldr	w9, [sp, #0xb8]
    12bc:      	rbit	w25, w9
    12c0:      	clz	w9, w25
    12c4:      	str	q2, [sp, #0x4c0]
    12c8:      	str	q1, [sp, #0x4b0]
    12cc:      	str	x9, [sp, #0xb8]
    12d0:      	and	x25, x9, #0x7
    12d4:      	add	x9, sp, #0x4b0
    12d8:      	ldr	s0, [x9, x25, lsl #2]
    12dc:      	str	q29, [sp, #0x50]
    12e0:      	mov.b	v29[0], wzr
    12e4:      	str	q29, [sp, #0x20]
    12e8:      	fadd	s0, s0, s25
    12ec:      	fmov	s1, w14
    12f0:      	fdiv	s0, s0, s1
    12f4:      	dup.4s	v1, v0[0]
    12f8:      	dup.2d	v0, x1
    12fc:      	ushll2.2d	v2, v6, #0x0
    1300:      	and.16b	v24, v2, v0
    1304:      	ushll2.2d	v2, v7, #0x0
    1308:      	and.16b	v25, v2, v0
    130c:      	ushll.2d	v2, v6, #0x0
    1310:      	and.16b	v26, v2, v0
    1314:      	ushll.2d	v2, v7, #0x0
    1318:      	and.16b	v27, v2, v0
    131c:      	movi.2d	v2, #0000000000000000
    1320:      	movi.2d	v17, #0000000000000000
    1324:      	movi.2d	v18, #0000000000000000
    1328:      	movi.2d	v19, #0000000000000000
    132c:      	lsl	x25, x27, #5
    1330:      	add	x27, x16, x25
    1334:      	ldp	q16, q0, [x27]
    1338:      	fsub.4s	v16, v16, v1
    133c:      	fsub.4s	v0, v0, v1
    1340:      	add	x25, x17, x25
    1344:      	ldp	q20, q21, [x25]
    1348:      	bif.16b	v0, v21, v6
    134c:      	bif.16b	v16, v20, v7
    1350:      	stp	q16, q0, [x25]
    1354:      	add.2d	v17, v17, v25
    1358:      	add.2d	v18, v18, v26
    135c:      	add.2d	v19, v19, v24
    1360:      	add.2d	v2, v2, v27
    1364:      	fmov	x27, d2
    1368:      	cmp	x27, #0x8
    136c:      	b.lt	0x132c <ltmp0+0x132c>
    1370:      	fsub.4s	v4, v8, v1
    1374:      	fsub.4s	v16, v11, v1
    1378:      	ldr	x9, [sp, #0x1c0]
    137c:      	add	x25, x17, x9
    1380:      	ldp	q0, q1, [x25]
    1384:      	zip2.8b	v2, v28, v0
    1388:      	ushll.4s	v2, v2, #0x0
    138c:      	shl.4s	v2, v2, #0x1f
    1390:      	cmlt.4s	v2, v2, #0
    1394:      	stp	q16, q4, [sp, #0x30]
    1398:      	bit.16b	v1, v16, v2
    139c:      	zip1.8b	v2, v28, v0
    13a0:      	ushll.4s	v2, v2, #0x0
    13a4:      	shl.4s	v2, v2, #0x1f
    13a8:      	cmlt.4s	v2, v2, #0
    13ac:      	bit.16b	v0, v4, v2
    13b0:      	stp	q0, q1, [x25]
    13b4:      	ldr	q0, [sp, #0x950]
    13b8:      	ldr	q1, [sp, #0x940]
    13bc:      	fmul.4s	v1, v1, v1
    13c0:      	fmul.4s	v0, v0, v0
    13c4:      	and.16b	v13, v6, v0
    13c8:      	and.16b	v1, v7, v1
    13cc:      	ldr	q0, [sp, #0x930]
    13d0:      	ldr	q2, [sp, #0x920]
    13d4:      	fmul.4s	v2, v2, v2
    13d8:      	fmul.4s	v0, v0, v0
    13dc:      	and.16b	v23, v6, v0
    13e0:      	and.16b	v2, v7, v2
    13e4:      	ldr	q0, [sp, #0x910]
    13e8:      	ldr	q16, [sp, #0x900]
    13ec:      	fmul.4s	v16, v16, v16
    13f0:      	fmul.4s	v0, v0, v0
    13f4:      	and.16b	v19, v6, v0
    13f8:      	and.16b	v20, v7, v16
    13fc:      	add	x25, x17, x26
    1400:      	ldp	q16, q0, [x25]
    1404:      	fmul.4s	v16, v16, v16
    1408:      	fmul.4s	v0, v0, v0
    140c:      	and.16b	v17, v6, v0
    1410:      	and.16b	v29, v7, v16
    1414:      	sshll.2d	v0, v7, #0x0
    1418:      	sshll.2d	v16, v6, #0x0
    141c:      	add	x22, x17, x22, lsl #5
    1420:      	ldp	q22, q21, [x22]
    1424:      	and.16b	v22, v7, v22
    1428:      	and.16b	v21, v6, v21
    142c:      	fmul.4s	v21, v21, v21
    1430:      	fmul.4s	v22, v22, v22
    1434:      	fadd.4s	v28, v29, v22
    1438:      	fadd.4s	v8, v17, v21
    143c:      	ldp	q22, q21, [x22, #0x20]
    1440:      	and.16b	v22, v7, v22
    1444:      	and.16b	v21, v6, v21
    1448:      	fmul.4s	v21, v21, v21
    144c:      	fmul.4s	v22, v22, v22
    1450:      	fadd.4s	v22, v20, v22
    1454:      	fadd.4s	v21, v19, v21
    1458:      	ldp	q14, q10, [x22, #0x40]
    145c:      	and.16b	v14, v7, v14
    1460:      	and.16b	v10, v6, v10
    1464:      	fmul.4s	v10, v10, v10
    1468:      	fmul.4s	v14, v14, v14
    146c:      	fadd.4s	v14, v2, v14
    1470:      	fadd.4s	v10, v23, v10
    1474:      	ldp	q18, q12, [x22, #0x60]
    1478:      	and.16b	v18, v7, v18
    147c:      	and.16b	v12, v6, v12
    1480:      	fmul.4s	v12, v12, v12
    1484:      	fmul.4s	v18, v18, v18
    1488:      	fadd.4s	v18, v1, v18
    148c:      	fadd.4s	v12, v13, v12
    1490:      	dup.2d	v4, x20
    1494:      	and.16b	v11, v31, v4
    1498:      	add.2d	v9, v9, v11
    149c:      	and.16b	v11, v30, v4
    14a0:      	add.2d	v15, v15, v11
    14a4:      	and.16b	v16, v16, v4
    14a8:      	add.2d	v5, v5, v16
    14ac:      	and.16b	v0, v0, v4
    14b0:      	add.2d	v3, v3, v0
    14b4:      	bit.16b	v17, v8, v6
    14b8:      	bit.16b	v29, v28, v7
    14bc:      	bit.16b	v19, v21, v6
    14c0:      	bit.16b	v20, v22, v7
    14c4:      	bit.16b	v23, v10, v6
    14c8:      	bit.16b	v2, v14, v7
    14cc:      	bit.16b	v13, v12, v6
    14d0:      	bit.16b	v1, v18, v7
    14d4:      	fmov	x22, d3
    14d8:      	cmp	x22, #0x8
    14dc:      	b.lt	0x1414 <ltmp0+0x1414>
    14e0:      	mov	x22, #0x0               ; =0
    14e4:      	movi.2d	v3, #0000000000000000
    14e8:      	movi.2d	v5, #0000000000000000
    14ec:      	movi.2d	v30, #0000000000000000
    14f0:      	movi.2d	v31, #0000000000000000
    14f4:      	ldr	q9, [sp, #0x170]
    14f8:      	ldp	q22, q21, [sp, #0x1a0]
    14fc:      	b	0x1530 <ltmp0+0x1530>
    1500:      	add	x22, x21, x22
    1504:      	ldp	q0, q4, [x22]
    1508:      	bit.16b	v4, v15, v6
    150c:      	bit.16b	v0, v14, v7
    1510:      	stp	q0, q4, [x22]
    1514:      	add.2d	v5, v5, v25
    1518:      	add.2d	v30, v30, v26
    151c:      	add.2d	v31, v31, v24
    1520:      	add.2d	v3, v3, v27
    1524:      	fmov	x22, d3
    1528:      	cmp	x22, #0x8
    152c:      	b.ge	0x15cc <ltmp0+0x15cc>
    1530:      	fmov	w27, s9
    1534:      	lsl	x22, x22, #5
    1538:      	add	x26, x23, x22
    153c:      	movi.2d	v14, #0000000000000000
    1540:      	movi.2d	v15, #0000000000000000
    1544:      	tbnz	w27, #0x0, 0x156c <ltmp0+0x156c>
    1548:      	and	w27, w27, #0xff
    154c:      	tbnz	w27, #0x1, 0x1578 <ltmp0+0x1578>
    1550:      	tbnz	w27, #0x2, 0x1584 <ltmp0+0x1584>
    1554:      	tbnz	w27, #0x3, 0x1590 <ltmp0+0x1590>
    1558:      	tbnz	w27, #0x4, 0x159c <ltmp0+0x159c>
    155c:      	tbnz	w27, #0x5, 0x15a8 <ltmp0+0x15a8>
    1560:      	tbnz	w27, #0x6, 0x15b4 <ltmp0+0x15b4>
    1564:      	tbz	w27, #0x7, 0x1500 <ltmp0+0x1500>
    1568:      	b	0x15c0 <ltmp0+0x15c0>
    156c:      	ldr	s14, [x26]
    1570:      	and	w27, w27, #0xff
    1574:      	tbz	w27, #0x1, 0x1550 <ltmp0+0x1550>
    1578:      	add	x25, x26, #0x4
    157c:      	ld1.s	{ v14 }[1], [x25]
    1580:      	tbz	w27, #0x2, 0x1554 <ltmp0+0x1554>
    1584:      	add	x25, x26, #0x8
    1588:      	ld1.s	{ v14 }[2], [x25]
    158c:      	tbz	w27, #0x3, 0x1558 <ltmp0+0x1558>
    1590:      	add	x25, x26, #0xc
    1594:      	ld1.s	{ v14 }[3], [x25]
    1598:      	tbz	w27, #0x4, 0x155c <ltmp0+0x155c>
    159c:      	add	x25, x26, #0x10
    15a0:      	ld1.s	{ v15 }[0], [x25]
    15a4:      	tbz	w27, #0x5, 0x1560 <ltmp0+0x1560>
    15a8:      	add	x25, x26, #0x14
    15ac:      	ld1.s	{ v15 }[1], [x25]
    15b0:      	tbz	w27, #0x6, 0x1564 <ltmp0+0x1564>
    15b4:      	add	x25, x26, #0x18
    15b8:      	ld1.s	{ v15 }[2], [x25]
    15bc:      	tbz	w27, #0x7, 0x1500 <ltmp0+0x1500>
    15c0:      	add	x25, x26, #0x1c
    15c4:      	ld1.s	{ v15 }[3], [x25]
    15c8:      	b	0x1500 <ltmp0+0x1500>
    15cc:      	zip2.8b	v0, v21, v0
    15d0:      	ushll.4s	v0, v0, #0x0
    15d4:      	shl.4s	v0, v0, #0x1f
    15d8:      	cmlt.4s	v0, v0, #0
    15dc:      	ldp	q5, q3, [sp, #0x20]
    15e0:      	and.16b	v30, v0, v3
    15e4:      	fmul.4s	v3, v30, v30
    15e8:      	fadd.4s	v3, v3, v17
    15ec:      	and.16b	v0, v0, v3
    15f0:      	zip2.8b	v3, v5, v0
    15f4:      	ushll.4s	v3, v3, #0x0
    15f8:      	shl.4s	v3, v3, #0x1f
    15fc:      	cmlt.4s	v3, v3, #0
    1600:      	bit.16b	v0, v8, v3
    1604:      	zip1.8b	v3, v21, v0
    1608:      	ushll.4s	v3, v3, #0x0
    160c:      	shl.4s	v3, v3, #0x1f
    1610:      	cmlt.4s	v3, v3, #0
    1614:      	ldr	q4, [sp, #0x40]
    1618:      	and.16b	v31, v3, v4
    161c:      	fmul.4s	v4, v31, v31
    1620:      	fadd.4s	v4, v4, v29
    1624:      	and.16b	v3, v3, v4
    1628:      	zip1.8b	v4, v5, v0
    162c:      	ushll.4s	v4, v4, #0x0
    1630:      	shl.4s	v4, v4, #0x1f
    1634:      	cmlt.4s	v4, v4, #0
    1638:      	bit.16b	v3, v28, v4
    163c:      	fadd.4s	v3, v20, v3
    1640:      	fadd.4s	v0, v19, v0
    1644:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1648:      	ldr	q4, [x9]
    164c:      	and.16b	v18, v6, v4
    1650:      	fadd.4s	v0, v23, v0
    1654:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1658:      	ldr	q4, [x9]
    165c:      	and.16b	v16, v7, v4
    1660:      	fadd.4s	v2, v2, v3
    1664:      	fadd.4s	v1, v1, v2
    1668:      	fadd.4s	v2, v13, v0
    166c:      	fmov	w22, s16
    1670:      	add	x25, sp, #0x218
    1674:      	bfxil	x25, x22, #0, #3
    1678:      	ldr	q0, [sp, #0x50]
    167c:      	str	d0, [sp, #0x218]
    1680:      	ldrb	w25, [x25]
    1684:      	add	x9, sp, #0x480
    1688:      	orr	x22, x9, x22, lsl #2
    168c:      	str	q2, [sp, #0x490]
    1690:      	str	q1, [sp, #0x480]
    1694:      	ldr	s0, [x22]
    1698:      	tst	w13, w25
    169c:      	movi	d19, #0000000000000000
    16a0:      	fcsel	s3, s0, s19, ne
    16a4:      	mov.s	w22, v16[1]
    16a8:      	add	x25, sp, #0x218
    16ac:      	bfxil	x25, x22, #0, #3
    16b0:      	ldrb	w22, [x25]
    16b4:      	and	w22, w11, w22
    16b8:      	str	q1, [sp, #0x460]
    16bc:      	ldr	s0, [sp, #0x460]
    16c0:      	tst	w22, #0x1
    16c4:      	fcsel	s4, s0, s19, ne
    16c8:      	mov.s	w22, v16[2]
    16cc:      	add	x9, sp, #0x440
    16d0:      	orr	x25, x9, x22, lsl #2
    16d4:      	add	x26, sp, #0x218
    16d8:      	bfxil	x26, x22, #0, #3
    16dc:      	ldrb	w22, [x26]
    16e0:      	and	w22, w10, w22
    16e4:      	str	q2, [sp, #0x450]
    16e8:      	str	q1, [sp, #0x440]
    16ec:      	ldr	s0, [x25]
    16f0:      	tst	w22, #0x1
    16f4:      	fcsel	s5, s0, s19, ne
    16f8:      	mov.s	w22, v16[3]
    16fc:      	add	x9, sp, #0x420
    1700:      	orr	x25, x9, x22, lsl #2
    1704:      	add	x26, sp, #0x218
    1708:      	bfxil	x26, x22, #0, #3
    170c:      	ldrb	w22, [x26]
    1710:      	and	w22, w2, w22
    1714:      	str	q2, [sp, #0x430]
    1718:      	str	q1, [sp, #0x420]
    171c:      	ldr	s0, [x25]
    1720:      	tst	w22, #0x1
    1724:      	fcsel	s17, s0, s19, ne
    1728:      	fmov	w22, s18
    172c:      	add	x25, sp, #0x218
    1730:      	bfxil	x25, x22, #0, #3
    1734:      	ldrb	w25, [x25]
    1738:      	str	q2, [sp, #0x410]
    173c:      	str	q1, [sp, #0x400]
    1740:      	add	x9, sp, #0x400
    1744:      	ldr	s0, [x9, w22, uxtw #2]
    1748:      	and	w22, w5, w25
    174c:      	tst	w22, #0x1
    1750:      	mov.s	w22, v18[1]
    1754:      	add	x25, sp, #0x218
    1758:      	bfxil	x25, x22, #0, #3
    175c:      	ldrb	w25, [x25]
    1760:      	mov.s	w26, v18[2]
    1764:      	mov.s	w27, v18[3]
    1768:      	stp	q1, q2, [sp, #0x3e0]
    176c:      	add	x9, sp, #0x3e0
    1770:      	ldr	s16, [x9, w22, uxtw #2]
    1774:      	fcsel	s0, s0, s19, ne
    1778:      	and	w22, w4, w25
    177c:      	tst	w22, #0x1
    1780:      	fcsel	s16, s16, s19, ne
    1784:      	add	x22, sp, #0x218
    1788:      	bfxil	x22, x26, #0, #3
    178c:      	ldrb	w22, [x22]
    1790:      	stp	q1, q2, [sp, #0x3c0]
    1794:      	mov.s	v0[1], v16[0]
    1798:      	add	x9, sp, #0x3c0
    179c:      	ldr	s16, [x9, w26, uxtw #2]
    17a0:      	and	w22, w3, w22
    17a4:      	tst	w22, #0x1
    17a8:      	fcsel	s16, s16, s19, ne
    17ac:      	add	x22, sp, #0x218
    17b0:      	bfxil	x22, x27, #0, #3
    17b4:      	ldrb	w22, [x22]
    17b8:      	and	w22, w12, w22
    17bc:      	stp	q1, q2, [sp, #0x3a0]
    17c0:      	mov.s	v0[2], v16[0]
    17c4:      	add	x9, sp, #0x3a0
    17c8:      	ldr	s16, [x9, w27, uxtw #2]
    17cc:      	tst	w22, #0x1
    17d0:      	fcsel	s16, s16, s19, ne
    17d4:      	mov.s	v0[3], v16[0]
    17d8:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    17dc:      	ldr	q16, [x9]
    17e0:      	mov.s	v3[1], v4[0]
    17e4:      	and.16b	v16, v7, v16
    17e8:      	mov.s	v3[2], v5[0]
    17ec:      	mov.s	v3[3], v17[0]
    17f0:      	fadd.4s	v1, v1, v3
    17f4:      	fadd.4s	v2, v2, v0
    17f8:      	fmov	w22, s16
    17fc:      	add	x25, sp, #0x218
    1800:      	bfxil	x25, x22, #0, #3
    1804:      	ldrb	w25, [x25]
    1808:      	add	x9, sp, #0x380
    180c:      	orr	x22, x9, x22, lsl #2
    1810:      	stp	q1, q2, [sp, #0x380]
    1814:      	ldr	s0, [x22]
    1818:      	tst	w13, w25
    181c:      	mov.s	w22, v16[1]
    1820:      	add	x25, sp, #0x218
    1824:      	bfxil	x25, x22, #0, #3
    1828:      	ldrb	w25, [x25]
    182c:      	and	w11, w11, w25
    1830:      	fcsel	s3, s0, s19, ne
    1834:      	add	x9, sp, #0x360
    1838:      	orr	x22, x9, x22, lsl #2
    183c:      	stp	q1, q2, [sp, #0x360]
    1840:      	ldr	s0, [x22]
    1844:      	tst	w11, #0x1
    1848:      	mov.s	w11, v16[2]
    184c:      	add	x22, sp, #0x218
    1850:      	bfxil	x22, x11, #0, #3
    1854:      	fcsel	s4, s0, s19, ne
    1858:      	ldrb	w11, [x22]
    185c:      	and	w10, w10, w11
    1860:      	str	q1, [sp, #0x340]
    1864:      	tst	w10, #0x1
    1868:      	mov.s	w10, v16[3]
    186c:      	add	x11, sp, #0x218
    1870:      	bfxil	x11, x10, #0, #3
    1874:      	ldrb	w11, [x11]
    1878:      	and	w11, w2, w11
    187c:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1880:      	ldr	q0, [x9]
    1884:      	and.16b	v0, v6, v0
    1888:      	ldr	s5, [sp, #0x340]
    188c:      	fcsel	s5, s5, s19, ne
    1890:      	add	x9, sp, #0x320
    1894:      	orr	x10, x9, x10, lsl #2
    1898:      	stp	q1, q2, [sp, #0x320]
    189c:      	ldr	s16, [x10]
    18a0:      	tst	w11, #0x1
    18a4:      	fcsel	s17, s16, s19, ne
    18a8:      	fmov	w10, s0
    18ac:      	add	x11, sp, #0x218
    18b0:      	bfxil	x11, x10, #0, #3
    18b4:      	ldrb	w11, [x11]
    18b8:      	and	w11, w5, w11
    18bc:      	stp	q1, q2, [sp, #0x300]
    18c0:      	add	x9, sp, #0x300
    18c4:      	ldr	s16, [x9, w10, uxtw #2]
    18c8:      	tst	w11, #0x1
    18cc:      	mov.s	w10, v0[1]
    18d0:      	add	x11, sp, #0x218
    18d4:      	bfxil	x11, x10, #0, #3
    18d8:      	ldrb	w11, [x11]
    18dc:      	and	w11, w4, w11
    18e0:      	mov.s	w2, v0[2]
    18e4:      	stp	q1, q2, [sp, #0x2e0]
    18e8:      	mov.s	w4, v0[3]
    18ec:      	add	x9, sp, #0x2e0
    18f0:      	ldr	s0, [x9, w10, uxtw #2]
    18f4:      	fcsel	s16, s16, s19, ne
    18f8:      	tst	w11, #0x1
    18fc:      	add	x10, sp, #0x218
    1900:      	bfxil	x10, x2, #0, #3
    1904:      	ldrb	w10, [x10]
    1908:      	and	w10, w3, w10
    190c:      	fcsel	s0, s0, s19, ne
    1910:      	stp	q1, q2, [sp, #0x2c0]
    1914:      	mov.s	v16[1], v0[0]
    1918:      	add	x9, sp, #0x2c0
    191c:      	ldr	s0, [x9, w2, uxtw #2]
    1920:      	tst	w10, #0x1
    1924:      	add	x10, sp, #0x218
    1928:      	bfxil	x10, x4, #0, #3
    192c:      	ldrb	w10, [x10]
    1930:      	and	w10, w12, w10
    1934:      	fcsel	s0, s0, s19, ne
    1938:      	stp	q1, q2, [sp, #0x2a0]
    193c:      	mov.s	v16[2], v0[0]
    1940:      	add	x9, sp, #0x2a0
    1944:      	ldr	s0, [x9, w4, uxtw #2]
    1948:      	tst	w10, #0x1
    194c:      	fcsel	s0, s0, s19, ne
    1950:      	mov.s	v16[3], v0[0]
    1954:      	mov.s	v3[1], v4[0]
    1958:      	mov.s	v3[2], v5[0]
    195c:      	mov.s	v3[3], v17[0]
    1960:      	movi.4s	v0, #0x4
    1964:      	and.16b	v0, v7, v0
    1968:      	fmov	w10, s0
    196c:      	add	x9, sp, #0x218
    1970:      	orr	x11, x9, x10
    1974:      	ldrb	w11, [x11]
    1978:      	tst	w13, w11
    197c:      	fadd.4s	v0, v1, v3
    1980:      	fadd.4s	v1, v2, v16
    1984:      	stp	q0, q1, [sp, #0x280]
    1988:      	add	x9, sp, #0x280
    198c:      	ldr	s1, [x9, w10, uxtw #2]
    1990:      	fcsel	s1, s1, s19, ne
    1994:      	tst	w24, #0x1
    1998:      	fadd	s0, s0, s1
    199c:      	fcsel	s1, s0, s19, ne
    19a0:      	ldp	w9, w11, [sp, #0x6c]
    19a4:      	tst	w11, #0x1
    19a8:      	fcsel	s2, s0, s19, ne
    19ac:      	tst	w9, #0x1
    19b0:      	fcsel	s3, s0, s19, ne
    19b4:      	ldr	w9, [sp, #0x68]
    19b8:      	tst	w9, #0x1
    19bc:      	mov.s	v1[1], v2[0]
    19c0:      	fcsel	s2, s0, s19, ne
    19c4:      	mov.s	v1[2], v3[0]
    19c8:      	tst	w6, #0x1
    19cc:      	fcsel	s3, s0, s19, ne
    19d0:      	ldr	w9, [sp, #0x80]
    19d4:      	tst	w9, #0x1
    19d8:      	mov.s	v1[3], v2[0]
    19dc:      	fcsel	s2, s0, s19, ne
    19e0:      	ldr	w9, [sp, #0x90]
    19e4:      	tst	w9, #0x1
    19e8:      	mov.s	v3[1], v2[0]
    19ec:      	fcsel	s2, s0, s19, ne
    19f0:      	mov.s	v3[2], v2[0]
    19f4:      	ldr	w9, [sp, #0xa0]
    19f8:      	tst	w9, #0x1
    19fc:      	movi	d16, #0000000000000000
    1a00:      	fcsel	s0, s0, s19, ne
    1a04:      	mov.s	v3[3], v0[0]
    1a08:      	shl.8b	v0, v21, #0x7
    1a0c:      	cmlt.8b	v0, v0, #0
    1a10:      	ldr	d2, [sp, #0xf8]
    1a14:      	and.8b	v0, v0, v2
    1a18:      	stp	q1, q3, [sp, #0x260]
    1a1c:      	mov	b1, v21[0]
    1a20:      	mov.b	v1[4], v21[1]
    1a24:      	ldr	x9, [sp, #0xb8]
    1a28:      	and	x9, x9, #0x7
    1a2c:      	ushll.2d	v1, v1, #0x0
    1a30:      	shl.2d	v1, v1, #0x3f
    1a34:      	cmlt.2d	v1, v1, #0
    1a38:      	ldr	q2, [sp, #0x100]
    1a3c:      	and.16b	v2, v1, v2
    1a40:      	mov	b1, v21[2]
    1a44:      	mov.b	v1[4], v21[3]
    1a48:      	ushll.2d	v1, v1, #0x0
    1a4c:      	shl.2d	v1, v1, #0x3f
    1a50:      	cmlt.2d	v1, v1, #0
    1a54:      	ldp	q3, q4, [sp, #0xc0]
    1a58:      	and.16b	v3, v1, v3
    1a5c:      	mov	b1, v21[4]
    1a60:      	mov.b	v1[4], v21[5]
    1a64:      	ushll.2d	v1, v1, #0x0
    1a68:      	shl.2d	v1, v1, #0x3f
    1a6c:      	cmlt.2d	v1, v1, #0
    1a70:      	and.16b	v4, v1, v4
    1a74:      	mov	b1, v21[6]
    1a78:      	mov.b	v1[4], v21[7]
    1a7c:      	ushll.2d	v1, v1, #0x0
    1a80:      	shl.2d	v1, v1, #0x3f
    1a84:      	cmlt.2d	v1, v1, #0
    1a88:      	ldr	q5, [sp, #0xe0]
    1a8c:      	and.16b	v5, v1, v5
    1a90:      	add	x10, sp, #0x260
    1a94:      	ldr	s1, [x10, x9, lsl #2]
    1a98:      	stp	q4, q5, [sp, #0x240]
    1a9c:      	addv.8b	b28, v0
    1aa0:      	stp	q2, q3, [sp, #0x220]
    1aa4:      	ldr	x4, [sp, #0x168]
    1aa8:      	and	x9, x4, #0x7
    1aac:      	add	x10, sp, #0x220
    1ab0:      	ldr	x9, [x10, x9, lsl #3]
    1ab4:      	fmov	w10, s28
    1ab8:      	sub	x9, x9, x4
    1abc:      	lsl	x9, x9, #2
    1ac0:      	add	x11, x23, x9
    1ac4:      	movi.2d	v29, #0000000000000000
    1ac8:      	movi.2d	v8, #0000000000000000
    1acc:      	tbnz	w10, #0x0, 0x1ee4 <ltmp0+0x1ee4>
    1ad0:      	ldr	w3, [sp, #0x1c]
    1ad4:      	mov	w27, #0x20              ; =32
    1ad8:      	add	x2, sp, #0x6a0
    1adc:      	ldr	w25, [sp, #0x190]
    1ae0:      	tbnz	w10, #0x1, 0x1efc <ltmp0+0x1efc>
    1ae4:      	tbnz	w10, #0x2, 0x1f08 <ltmp0+0x1f08>
    1ae8:      	tbnz	w10, #0x3, 0x1f14 <ltmp0+0x1f14>
    1aec:      	tbnz	w10, #0x4, 0x1f20 <ltmp0+0x1f20>
    1af0:      	tbnz	w10, #0x5, 0x1f2c <ltmp0+0x1f2c>
    1af4:      	tbnz	w10, #0x6, 0x1f38 <ltmp0+0x1f38>
    1af8:      	tbz	w10, #0x7, 0x1b04 <ltmp0+0x1b04>
    1afc:      	add	x10, x11, #0x1c
    1b00:      	ld1.s	{ v8 }[3], [x10]
    1b04:      	fadd	s0, s1, s16
    1b08:      	fmov	s1, w14
    1b0c:      	fdiv	s0, s0, s1
    1b10:      	ldr	x10, [sp, #0x1c0]
    1b14:      	add	x10, x21, x10
    1b18:      	ldp	q1, q2, [x10]
    1b1c:      	zip2.8b	v3, v21, v0
    1b20:      	ushll.4s	v3, v3, #0x0
    1b24:      	shl.4s	v3, v3, #0x1f
    1b28:      	cmlt.4s	v3, v3, #0
    1b2c:      	bit.16b	v2, v8, v3
    1b30:      	zip1.8b	v3, v21, v0
    1b34:      	ushll.4s	v3, v3, #0x0
    1b38:      	shl.4s	v3, v3, #0x1f
    1b3c:      	cmlt.4s	v3, v3, #0
    1b40:      	bit.16b	v1, v29, v3
    1b44:      	stp	q1, q2, [x10]
    1b48:      	fmov	s1, w15
    1b4c:      	fadd	s0, s0, s1
    1b50:      	fsqrt	s1, s0
    1b54:      	sub	x10, x19, x30
    1b58:      	lsr	x11, x10, #2
    1b5c:      	subs	x10, x30, x19
    1b60:      	mov	w12, #0x103             ; =259
    1b64:      	ccmp	x10, x12, #0x0, hs
    1b68:      	cset	w10, hi
    1b6c:      	cmp	x11, #0x450
    1b70:      	ccmp	x19, x30, #0x0, hi
    1b74:      	b.hs	0x1c60 <ltmp0+0x1c60>
    1b78:      	tbnz	w10, #0x0, 0x1c60 <ltmp0+0x1c60>
    1b7c:      	mov	x10, #0x0               ; =0
    1b80:      	movi.2d	v2, #0000000000000000
    1b84:      	movi.2d	v3, #0000000000000000
    1b88:      	movi.2d	v4, #0000000000000000
    1b8c:      	movi.2d	v5, #0000000000000000
    1b90:      	b	0x1bc4 <ltmp0+0x1bc4>
    1b94:      	add	x10, x2, x10
    1b98:      	ldp	q0, q16, [x10]
    1b9c:      	bit.16b	v16, v18, v6
    1ba0:      	bit.16b	v0, v17, v7
    1ba4:      	stp	q0, q16, [x10]
    1ba8:      	add.2d	v3, v3, v25
    1bac:      	add.2d	v4, v4, v26
    1bb0:      	add.2d	v5, v5, v24
    1bb4:      	add.2d	v2, v2, v27
    1bb8:      	fmov	x10, d2
    1bbc:      	cmp	x10, #0x8
    1bc0:      	b.ge	0x1f48 <ltmp0+0x1f48>
    1bc4:      	fmov	w12, s9
    1bc8:      	lsl	x10, x10, #5
    1bcc:      	add	x11, x19, x10
    1bd0:      	movi.2d	v17, #0000000000000000
    1bd4:      	movi.2d	v18, #0000000000000000
    1bd8:      	tbnz	w12, #0x0, 0x1c00 <ltmp0+0x1c00>
    1bdc:      	and	w12, w12, #0xff
    1be0:      	tbnz	w12, #0x1, 0x1c0c <ltmp0+0x1c0c>
    1be4:      	tbnz	w12, #0x2, 0x1c18 <ltmp0+0x1c18>
    1be8:      	tbnz	w12, #0x3, 0x1c24 <ltmp0+0x1c24>
    1bec:      	tbnz	w12, #0x4, 0x1c30 <ltmp0+0x1c30>
    1bf0:      	tbnz	w12, #0x5, 0x1c3c <ltmp0+0x1c3c>
    1bf4:      	tbnz	w12, #0x6, 0x1c48 <ltmp0+0x1c48>
    1bf8:      	tbz	w12, #0x7, 0x1b94 <ltmp0+0x1b94>
    1bfc:      	b	0x1c54 <ltmp0+0x1c54>
    1c00:      	ldr	s17, [x11]
    1c04:      	and	w12, w12, #0xff
    1c08:      	tbz	w12, #0x1, 0x1be4 <ltmp0+0x1be4>
    1c0c:      	add	x13, x11, #0x4
    1c10:      	ld1.s	{ v17 }[1], [x13]
    1c14:      	tbz	w12, #0x2, 0x1be8 <ltmp0+0x1be8>
    1c18:      	add	x13, x11, #0x8
    1c1c:      	ld1.s	{ v17 }[2], [x13]
    1c20:      	tbz	w12, #0x3, 0x1bec <ltmp0+0x1bec>
    1c24:      	add	x13, x11, #0xc
    1c28:      	ld1.s	{ v17 }[3], [x13]
    1c2c:      	tbz	w12, #0x4, 0x1bf0 <ltmp0+0x1bf0>
    1c30:      	add	x13, x11, #0x10
    1c34:      	ld1.s	{ v18 }[0], [x13]
    1c38:      	tbz	w12, #0x5, 0x1bf4 <ltmp0+0x1bf4>
    1c3c:      	add	x13, x11, #0x14
    1c40:      	ld1.s	{ v18 }[1], [x13]
    1c44:      	tbz	w12, #0x6, 0x1bf8 <ltmp0+0x1bf8>
    1c48:      	add	x13, x11, #0x18
    1c4c:      	ld1.s	{ v18 }[2], [x13]
    1c50:      	tbz	w12, #0x7, 0x1b94 <ltmp0+0x1b94>
    1c54:      	add	x11, x11, #0x1c
    1c58:      	ld1.s	{ v18 }[3], [x11]
    1c5c:      	b	0x1b94 <ltmp0+0x1b94>
    1c60:      	mov	x10, #0x0               ; =0
    1c64:      	ldr	q0, [sp, #0x110]
    1c68:      	add.2d	v2, v0, v22
    1c6c:      	dup.4s	v3, v1[0]
    1c70:      	movi.2d	v1, #0000000000000000
    1c74:      	movi.2d	v4, #0000000000000000
    1c78:      	movi.2d	v5, #0000000000000000
    1c7c:      	movi.2d	v17, #0000000000000000
    1c80:      	b	0x1ca0 <ltmp0+0x1ca0>
    1c84:      	add.2d	v4, v4, v25
    1c88:      	add.2d	v5, v5, v26
    1c8c:      	add.2d	v17, v17, v24
    1c90:      	add.2d	v1, v1, v27
    1c94:      	fmov	x10, d1
    1c98:      	cmp	x10, #0x8
    1c9c:      	b.ge	0x1e34 <ltmp0+0x1e34>
    1ca0:      	fmov	w12, s9
    1ca4:      	shl.2d	v19, v1, #0x3
    1ca8:      	orr.16b	v0, v19, v22
    1cac:      	fmov	x11, d0
    1cb0:      	add	x11, x19, x11, lsl #2
    1cb4:      	movi.2d	v20, #0000000000000000
    1cb8:      	movi.2d	v18, #0000000000000000
    1cbc:      	tbnz	w12, #0x0, 0x1d64 <ltmp0+0x1d64>
    1cc0:      	and	w12, w12, #0xff
    1cc4:      	tbnz	w12, #0x1, 0x1d70 <ltmp0+0x1d70>
    1cc8:      	tbnz	w12, #0x2, 0x1d7c <ltmp0+0x1d7c>
    1ccc:      	tbnz	w12, #0x3, 0x1d88 <ltmp0+0x1d88>
    1cd0:      	tbnz	w12, #0x4, 0x1d94 <ltmp0+0x1d94>
    1cd4:      	tbnz	w12, #0x5, 0x1da0 <ltmp0+0x1da0>
    1cd8:      	tbnz	w12, #0x6, 0x1dac <ltmp0+0x1dac>
    1cdc:      	tbz	w12, #0x7, 0x1ce8 <ltmp0+0x1ce8>
    1ce0:      	add	x11, x11, #0x1c
    1ce4:      	ld1.s	{ v18 }[3], [x11]
    1ce8:      	lsl	x10, x10, #5
    1cec:      	add	x12, x17, x10
    1cf0:      	ldr	q0, [x12]
    1cf4:      	and.16b	v0, v7, v0
    1cf8:      	fdiv.4s	v0, v0, v3
    1cfc:      	add	x13, x21, x10
    1d00:      	ldr	q16, [x13]
    1d04:      	and.16b	v16, v7, v16
    1d08:      	fmul.4s	v0, v0, v16
    1d0c:      	fmov	w11, s9
    1d10:      	fadd.4s	v20, v20, v0
    1d14:      	add.2d	v0, v2, v19
    1d18:      	fmov	x10, d0
    1d1c:      	add	x10, x30, x10, lsl #2
    1d20:      	tbnz	w11, #0x0, 0x1dbc <ltmp0+0x1dbc>
    1d24:      	and	w11, w11, #0xff
    1d28:      	tbnz	w11, #0x1, 0x1dc8 <ltmp0+0x1dc8>
    1d2c:      	ldr	q21, [x12, #0x10]
    1d30:      	ldr	q19, [x13, #0x10]
    1d34:      	tbnz	w11, #0x2, 0x1ddc <ltmp0+0x1ddc>
    1d38:      	tbnz	w11, #0x3, 0x1de8 <ltmp0+0x1de8>
    1d3c:      	and.16b	v0, v6, v21
    1d40:      	fdiv.4s	v0, v0, v3
    1d44:      	and.16b	v16, v6, v19
    1d48:      	fmul.4s	v0, v0, v16
    1d4c:      	fadd.4s	v18, v18, v0
    1d50:      	tbnz	w11, #0x4, 0x1e08 <ltmp0+0x1e08>
    1d54:      	tbnz	w11, #0x5, 0x1e10 <ltmp0+0x1e10>
    1d58:      	tbnz	w11, #0x6, 0x1e1c <ltmp0+0x1e1c>
    1d5c:      	tbz	w11, #0x7, 0x1c84 <ltmp0+0x1c84>
    1d60:      	b	0x1e28 <ltmp0+0x1e28>
    1d64:      	ldr	s20, [x11]
    1d68:      	and	w12, w12, #0xff
    1d6c:      	tbz	w12, #0x1, 0x1cc8 <ltmp0+0x1cc8>
    1d70:      	add	x13, x11, #0x4
    1d74:      	ld1.s	{ v20 }[1], [x13]
    1d78:      	tbz	w12, #0x2, 0x1ccc <ltmp0+0x1ccc>
    1d7c:      	add	x13, x11, #0x8
    1d80:      	ld1.s	{ v20 }[2], [x13]
    1d84:      	tbz	w12, #0x3, 0x1cd0 <ltmp0+0x1cd0>
    1d88:      	add	x13, x11, #0xc
    1d8c:      	ld1.s	{ v20 }[3], [x13]
    1d90:      	tbz	w12, #0x4, 0x1cd4 <ltmp0+0x1cd4>
    1d94:      	add	x13, x11, #0x10
    1d98:      	ld1.s	{ v18 }[0], [x13]
    1d9c:      	tbz	w12, #0x5, 0x1cd8 <ltmp0+0x1cd8>
    1da0:      	add	x13, x11, #0x14
    1da4:      	ld1.s	{ v18 }[1], [x13]
    1da8:      	tbz	w12, #0x6, 0x1cdc <ltmp0+0x1cdc>
    1dac:      	add	x13, x11, #0x18
    1db0:      	ld1.s	{ v18 }[2], [x13]
    1db4:      	tbnz	w12, #0x7, 0x1ce0 <ltmp0+0x1ce0>
    1db8:      	b	0x1ce8 <ltmp0+0x1ce8>
    1dbc:      	str	s20, [x10]
    1dc0:      	and	w11, w11, #0xff
    1dc4:      	tbz	w11, #0x1, 0x1d2c <ltmp0+0x1d2c>
    1dc8:      	add	x2, x10, #0x4
    1dcc:      	st1.s	{ v20 }[1], [x2]
    1dd0:      	ldr	q21, [x12, #0x10]
    1dd4:      	ldr	q19, [x13, #0x10]
    1dd8:      	tbz	w11, #0x2, 0x1d38 <ltmp0+0x1d38>
    1ddc:      	add	x12, x10, #0x8
    1de0:      	st1.s	{ v20 }[2], [x12]
    1de4:      	tbz	w11, #0x3, 0x1d3c <ltmp0+0x1d3c>
    1de8:      	add	x12, x10, #0xc
    1dec:      	st1.s	{ v20 }[3], [x12]
    1df0:      	and.16b	v0, v6, v21
    1df4:      	fdiv.4s	v0, v0, v3
    1df8:      	and.16b	v16, v6, v19
    1dfc:      	fmul.4s	v0, v0, v16
    1e00:      	fadd.4s	v18, v18, v0
    1e04:      	tbz	w11, #0x4, 0x1d54 <ltmp0+0x1d54>
    1e08:      	str	s18, [x10, #0x10]
    1e0c:      	tbz	w11, #0x5, 0x1d58 <ltmp0+0x1d58>
    1e10:      	add	x12, x10, #0x14
    1e14:      	st1.s	{ v18 }[1], [x12]
    1e18:      	tbz	w11, #0x6, 0x1d5c <ltmp0+0x1d5c>
    1e1c:      	add	x12, x10, #0x18
    1e20:      	st1.s	{ v18 }[2], [x12]
    1e24:      	tbz	w11, #0x7, 0x1c84 <ltmp0+0x1c84>
    1e28:      	add	x10, x10, #0x1c
    1e2c:      	st1.s	{ v18 }[3], [x10]
    1e30:      	b	0x1c84 <ltmp0+0x1c84>
    1e34:      	add	x9, x19, x9
    1e38:      	fmov	w10, s28
    1e3c:      	movi.2d	v1, #0000000000000000
    1e40:      	movi.2d	v2, #0000000000000000
    1e44:      	tbnz	w10, #0x0, 0x2198 <ltmp0+0x2198>
    1e48:      	tbnz	w10, #0x1, 0x21a0 <ltmp0+0x21a0>
    1e4c:      	tbnz	w10, #0x2, 0x21ac <ltmp0+0x21ac>
    1e50:      	tbnz	w10, #0x3, 0x21b8 <ltmp0+0x21b8>
    1e54:      	tbnz	w10, #0x4, 0x21c4 <ltmp0+0x21c4>
    1e58:      	tbnz	w10, #0x5, 0x21d0 <ltmp0+0x21d0>
    1e5c:      	tbnz	w10, #0x6, 0x21dc <ltmp0+0x21dc>
    1e60:      	tbz	w10, #0x7, 0x1e6c <ltmp0+0x1e6c>
    1e64:      	add	x9, x9, #0x1c
    1e68:      	ld1.s	{ v2 }[3], [x9]
    1e6c:      	fdiv.4s	v0, v30, v3
    1e70:      	fdiv.4s	v3, v31, v3
    1e74:      	fmul.4s	v3, v3, v29
    1e78:      	fmul.4s	v0, v0, v8
    1e7c:      	fadd.4s	v4, v3, v1
    1e80:      	fadd.4s	v1, v0, v2
    1e84:      	b	0x20ec <ltmp0+0x20ec>
    1e88:      	ldr	s24, [x10]
    1e8c:      	tbz	w9, #0x1, 0xce0 <ltmp0+0xce0>
    1e90:      	add	x11, x10, #0x4
    1e94:      	ld1.s	{ v24 }[1], [x11]
    1e98:      	tbz	w9, #0x2, 0xce4 <ltmp0+0xce4>
    1e9c:      	add	x11, x10, #0x8
    1ea0:      	ld1.s	{ v24 }[2], [x11]
    1ea4:      	tbz	w9, #0x3, 0xce8 <ltmp0+0xce8>
    1ea8:      	add	x11, x10, #0xc
    1eac:      	ld1.s	{ v24 }[3], [x11]
    1eb0:      	tbz	w9, #0x4, 0xcec <ltmp0+0xcec>
    1eb4:      	add	x11, x10, #0x10
    1eb8:      	ld1.s	{ v27 }[0], [x11]
    1ebc:      	tbz	w9, #0x5, 0xcf0 <ltmp0+0xcf0>
    1ec0:      	add	x11, x10, #0x14
    1ec4:      	ld1.s	{ v27 }[1], [x11]
    1ec8:      	tbz	w9, #0x6, 0xcf4 <ltmp0+0xcf4>
    1ecc:      	add	x11, x10, #0x18
    1ed0:      	ld1.s	{ v27 }[2], [x11]
    1ed4:      	str	q17, [sp, #0x1a0]
    1ed8:      	str	q16, [sp, #0x170]
    1edc:      	tbnz	w9, #0x7, 0xd00 <ltmp0+0xd00>
    1ee0:      	b	0xd08 <ltmp0+0xd08>
    1ee4:      	ldr	s29, [x11]
    1ee8:      	ldr	w3, [sp, #0x1c]
    1eec:      	mov	w27, #0x20              ; =32
    1ef0:      	add	x2, sp, #0x6a0
    1ef4:      	ldr	w25, [sp, #0x190]
    1ef8:      	tbz	w10, #0x1, 0x1ae4 <ltmp0+0x1ae4>
    1efc:      	add	x12, x11, #0x4
    1f00:      	ld1.s	{ v29 }[1], [x12]
    1f04:      	tbz	w10, #0x2, 0x1ae8 <ltmp0+0x1ae8>
    1f08:      	add	x12, x11, #0x8
    1f0c:      	ld1.s	{ v29 }[2], [x12]
    1f10:      	tbz	w10, #0x3, 0x1aec <ltmp0+0x1aec>
    1f14:      	add	x12, x11, #0xc
    1f18:      	ld1.s	{ v29 }[3], [x12]
    1f1c:      	tbz	w10, #0x4, 0x1af0 <ltmp0+0x1af0>
    1f20:      	add	x12, x11, #0x10
    1f24:      	ld1.s	{ v8 }[0], [x12]
    1f28:      	tbz	w10, #0x5, 0x1af4 <ltmp0+0x1af4>
    1f2c:      	add	x12, x11, #0x14
    1f30:      	ld1.s	{ v8 }[1], [x12]
    1f34:      	tbz	w10, #0x6, 0x1af8 <ltmp0+0x1af8>
    1f38:      	add	x12, x11, #0x18
    1f3c:      	ld1.s	{ v8 }[2], [x12]
    1f40:      	tbnz	w10, #0x7, 0x1afc <ltmp0+0x1afc>
    1f44:      	b	0x1b04 <ltmp0+0x1b04>
    1f48:      	add	x9, x19, x9
    1f4c:      	fmov	w10, s28
    1f50:      	movi.2d	v2, #0000000000000000
    1f54:      	movi.2d	v3, #0000000000000000
    1f58:      	tbnz	w10, #0x0, 0x21ec <ltmp0+0x21ec>
    1f5c:      	tbnz	w10, #0x1, 0x21f4 <ltmp0+0x21f4>
    1f60:      	tbnz	w10, #0x2, 0x2200 <ltmp0+0x2200>
    1f64:      	tbnz	w10, #0x3, 0x220c <ltmp0+0x220c>
    1f68:      	tbnz	w10, #0x4, 0x2218 <ltmp0+0x2218>
    1f6c:      	tbnz	w10, #0x5, 0x2224 <ltmp0+0x2224>
    1f70:      	tbnz	w10, #0x6, 0x2230 <ltmp0+0x2230>
    1f74:      	tbz	w10, #0x7, 0x1f80 <ltmp0+0x1f80>
    1f78:      	add	x9, x9, #0x1c
    1f7c:      	ld1.s	{ v3 }[3], [x9]
    1f80:      	mov	x10, #0x0               ; =0
    1f84:      	ldr	x9, [sp, #0x1c0]
    1f88:      	add	x9, x2, x9
    1f8c:      	ldp	q0, q4, [x9]
    1f90:      	zip2.8b	v5, v21, v0
    1f94:      	ushll.4s	v5, v5, #0x0
    1f98:      	shl.4s	v5, v5, #0x1f
    1f9c:      	cmlt.4s	v5, v5, #0
    1fa0:      	bit.16b	v4, v3, v5
    1fa4:      	zip1.8b	v5, v21, v0
    1fa8:      	ushll.4s	v5, v5, #0x0
    1fac:      	shl.4s	v5, v5, #0x1f
    1fb0:      	cmlt.4s	v5, v5, #0
    1fb4:      	bit.16b	v0, v2, v5
    1fb8:      	stp	q0, q4, [x9]
    1fbc:      	dup.4s	v1, v1[0]
    1fc0:      	ldr	q0, [sp, #0x110]
    1fc4:      	fmov	x9, d0
    1fc8:      	add	x9, x30, x9, lsl #2
    1fcc:      	movi.2d	v4, #0000000000000000
    1fd0:      	movi.2d	v5, #0000000000000000
    1fd4:      	movi.2d	v17, #0000000000000000
    1fd8:      	movi.2d	v18, #0000000000000000
    1fdc:      	b	0x1ffc <ltmp0+0x1ffc>
    1fe0:      	add.2d	v5, v5, v25
    1fe4:      	add.2d	v17, v17, v26
    1fe8:      	add.2d	v18, v18, v24
    1fec:      	add.2d	v4, v4, v27
    1ff0:      	fmov	x10, d4
    1ff4:      	cmp	x10, #0x8
    1ff8:      	b.ge	0x20d4 <ltmp0+0x20d4>
    1ffc:      	fmov	w11, s9
    2000:      	lsl	x10, x10, #5
    2004:      	add	x12, x17, x10
    2008:      	ldp	q0, q19, [x12]
    200c:      	and.16b	v0, v7, v0
    2010:      	fdiv.4s	v0, v0, v1
    2014:      	add	x12, x21, x10
    2018:      	ldp	q16, q20, [x12]
    201c:      	and.16b	v16, v7, v16
    2020:      	fmul.4s	v0, v0, v16
    2024:      	add	x12, x2, x10
    2028:      	ldp	q16, q21, [x12]
    202c:      	and.16b	v16, v7, v16
    2030:      	fadd.4s	v22, v0, v16
    2034:      	add	x10, x9, x10
    2038:      	tbnz	w11, #0x0, 0x2080 <ltmp0+0x2080>
    203c:      	and	w11, w11, #0xff
    2040:      	tbnz	w11, #0x1, 0x208c <ltmp0+0x208c>
    2044:      	tbnz	w11, #0x2, 0x2098 <ltmp0+0x2098>
    2048:      	tbz	w11, #0x3, 0x2054 <ltmp0+0x2054>
    204c:      	add	x12, x10, #0xc
    2050:      	st1.s	{ v22 }[3], [x12]
    2054:      	and.16b	v0, v6, v19
    2058:      	fdiv.4s	v0, v0, v1
    205c:      	and.16b	v16, v6, v20
    2060:      	fmul.4s	v0, v0, v16
    2064:      	and.16b	v16, v6, v21
    2068:      	fadd.4s	v19, v0, v16
    206c:      	tbnz	w11, #0x4, 0x20a8 <ltmp0+0x20a8>
    2070:      	tbnz	w11, #0x5, 0x20b0 <ltmp0+0x20b0>
    2074:      	tbnz	w11, #0x6, 0x20bc <ltmp0+0x20bc>
    2078:      	tbz	w11, #0x7, 0x1fe0 <ltmp0+0x1fe0>
    207c:      	b	0x20c8 <ltmp0+0x20c8>
    2080:      	str	s22, [x10]
    2084:      	and	w11, w11, #0xff
    2088:      	tbz	w11, #0x1, 0x2044 <ltmp0+0x2044>
    208c:      	add	x12, x10, #0x4
    2090:      	st1.s	{ v22 }[1], [x12]
    2094:      	tbz	w11, #0x2, 0x2048 <ltmp0+0x2048>
    2098:      	add	x12, x10, #0x8
    209c:      	st1.s	{ v22 }[2], [x12]
    20a0:      	tbnz	w11, #0x3, 0x204c <ltmp0+0x204c>
    20a4:      	b	0x2054 <ltmp0+0x2054>
    20a8:      	str	s19, [x10, #0x10]
    20ac:      	tbz	w11, #0x5, 0x2074 <ltmp0+0x2074>
    20b0:      	add	x12, x10, #0x14
    20b4:      	st1.s	{ v19 }[1], [x12]
    20b8:      	tbz	w11, #0x6, 0x2078 <ltmp0+0x2078>
    20bc:      	add	x12, x10, #0x18
    20c0:      	st1.s	{ v19 }[2], [x12]
    20c4:      	tbz	w11, #0x7, 0x1fe0 <ltmp0+0x1fe0>
    20c8:      	add	x10, x10, #0x1c
    20cc:      	st1.s	{ v19 }[3], [x10]
    20d0:      	b	0x1fe0 <ltmp0+0x1fe0>
    20d4:      	fdiv.4s	v0, v31, v1
    20d8:      	fdiv.4s	v1, v30, v1
    20dc:      	fmul.4s	v1, v1, v8
    20e0:      	fmul.4s	v0, v0, v29
    20e4:      	fadd.4s	v4, v0, v2
    20e8:      	fadd.4s	v1, v1, v3
    20ec:      	ldp	q0, q2, [sp, #0x140]
    20f0:      	ldp	q5, q3, [sp, #0x120]
    20f4:      	stp	q2, q3, [sp, #0x1d0]
    20f8:      	stp	q5, q0, [sp, #0x1f0]
    20fc:      	and	x9, x4, #0x7
    2100:      	add	x10, sp, #0x1d0
    2104:      	ldr	x9, [x10, x9, lsl #3]
    2108:      	sub	x9, x9, x4
    210c:      	add	x9, x30, x9, lsl #2
    2110:      	fmov	w10, s28
    2114:      	tbnz	w10, #0x0, 0x213c <ltmp0+0x213c>
    2118:      	mov	w30, #0x450             ; =1104
    211c:      	tbnz	w10, #0x1, 0x2148 <ltmp0+0x2148>
    2120:      	tbnz	w10, #0x2, 0x2154 <ltmp0+0x2154>
    2124:      	tbnz	w10, #0x3, 0x2160 <ltmp0+0x2160>
    2128:      	tbnz	w10, #0x4, 0x216c <ltmp0+0x216c>
    212c:      	tbnz	w10, #0x5, 0x2174 <ltmp0+0x2174>
    2130:      	tbnz	w10, #0x6, 0x2180 <ltmp0+0x2180>
    2134:      	tbz	w10, #0x7, 0x7c <ltmp0+0x7c>
    2138:      	b	0x218c <ltmp0+0x218c>
    213c:      	str	s4, [x9]
    2140:      	mov	w30, #0x450             ; =1104
    2144:      	tbz	w10, #0x1, 0x2120 <ltmp0+0x2120>
    2148:      	add	x11, x9, #0x4
    214c:      	st1.s	{ v4 }[1], [x11]
    2150:      	tbz	w10, #0x2, 0x2124 <ltmp0+0x2124>
    2154:      	add	x11, x9, #0x8
    2158:      	st1.s	{ v4 }[2], [x11]
    215c:      	tbz	w10, #0x3, 0x2128 <ltmp0+0x2128>
    2160:      	add	x11, x9, #0xc
    2164:      	st1.s	{ v4 }[3], [x11]
    2168:      	tbz	w10, #0x4, 0x212c <ltmp0+0x212c>
    216c:      	str	s1, [x9, #0x10]
    2170:      	tbz	w10, #0x5, 0x2130 <ltmp0+0x2130>
    2174:      	add	x11, x9, #0x14
    2178:      	st1.s	{ v1 }[1], [x11]
    217c:      	tbz	w10, #0x6, 0x2134 <ltmp0+0x2134>
    2180:      	add	x11, x9, #0x18
    2184:      	st1.s	{ v1 }[2], [x11]
    2188:      	tbz	w10, #0x7, 0x7c <ltmp0+0x7c>
    218c:      	add	x9, x9, #0x1c
    2190:      	st1.s	{ v1 }[3], [x9]
    2194:      	b	0x7c <ltmp0+0x7c>
    2198:      	ldr	s1, [x9]
    219c:      	tbz	w10, #0x1, 0x1e4c <ltmp0+0x1e4c>
    21a0:      	add	x11, x9, #0x4
    21a4:      	ld1.s	{ v1 }[1], [x11]
    21a8:      	tbz	w10, #0x2, 0x1e50 <ltmp0+0x1e50>
    21ac:      	add	x11, x9, #0x8
    21b0:      	ld1.s	{ v1 }[2], [x11]
    21b4:      	tbz	w10, #0x3, 0x1e54 <ltmp0+0x1e54>
    21b8:      	add	x11, x9, #0xc
    21bc:      	ld1.s	{ v1 }[3], [x11]
    21c0:      	tbz	w10, #0x4, 0x1e58 <ltmp0+0x1e58>
    21c4:      	add	x11, x9, #0x10
    21c8:      	ld1.s	{ v2 }[0], [x11]
    21cc:      	tbz	w10, #0x5, 0x1e5c <ltmp0+0x1e5c>
    21d0:      	add	x11, x9, #0x14
    21d4:      	ld1.s	{ v2 }[1], [x11]
    21d8:      	tbz	w10, #0x6, 0x1e60 <ltmp0+0x1e60>
    21dc:      	add	x11, x9, #0x18
    21e0:      	ld1.s	{ v2 }[2], [x11]
    21e4:      	tbnz	w10, #0x7, 0x1e64 <ltmp0+0x1e64>
    21e8:      	b	0x1e6c <ltmp0+0x1e6c>
    21ec:      	ldr	s2, [x9]
    21f0:      	tbz	w10, #0x1, 0x1f60 <ltmp0+0x1f60>
    21f4:      	add	x11, x9, #0x4
    21f8:      	ld1.s	{ v2 }[1], [x11]
    21fc:      	tbz	w10, #0x2, 0x1f64 <ltmp0+0x1f64>
    2200:      	add	x11, x9, #0x8
    2204:      	ld1.s	{ v2 }[2], [x11]
    2208:      	tbz	w10, #0x3, 0x1f68 <ltmp0+0x1f68>
    220c:      	add	x11, x9, #0xc
    2210:      	ld1.s	{ v2 }[3], [x11]
    2214:      	tbz	w10, #0x4, 0x1f6c <ltmp0+0x1f6c>
    2218:      	add	x11, x9, #0x10
    221c:      	ld1.s	{ v3 }[0], [x11]
    2220:      	tbz	w10, #0x5, 0x1f70 <ltmp0+0x1f70>
    2224:      	add	x11, x9, #0x14
    2228:      	ld1.s	{ v3 }[1], [x11]
    222c:      	tbz	w10, #0x6, 0x1f74 <ltmp0+0x1f74>
    2230:      	add	x11, x9, #0x18
    2234:      	ld1.s	{ v3 }[2], [x11]
    2238:      	tbnz	w10, #0x7, 0x1f78 <ltmp0+0x1f78>
    223c:      	b	0x1f80 <ltmp0+0x1f80>
    2240:      	ldr	x9, [sp, #0x10]
    2244:      	stp	w28, w13, [x9]
    2248:      	str	w25, [x9, #0x8]
    224c:      	mov	w8, #0x18               ; =24
    2250:      	str	w8, [x9, #0x24]
    2254:      	add	sp, sp, #0xb20
    2258:      	ldp	x29, x30, [sp, #0x90]
    225c:      	ldp	x20, x19, [sp, #0x80]
    2260:      	ldp	x22, x21, [sp, #0x70]
    2264:      	ldp	x24, x23, [sp, #0x60]
    2268:      	ldp	x26, x25, [sp, #0x50]
    226c:      	ldp	x28, x27, [sp, #0x40]
    2270:      	ldp	d9, d8, [sp, #0x30]
    2274:      	ldp	d11, d10, [sp, #0x20]
    2278:      	ldp	d13, d12, [sp, #0x10]
    227c:      	ldp	d15, d14, [sp], #0xa0
    2280:      	ret

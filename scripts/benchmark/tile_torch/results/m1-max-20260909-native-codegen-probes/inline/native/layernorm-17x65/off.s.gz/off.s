
/private/tmp/luisa-packet-inline.UY1lIE/capture/layernorm-17x65/off/object/tile_xir_w8_36307_1788935093765834_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0x50]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	sub	sp, sp, #0x260
      18:      	ldr	x9, [x0]
      1c:      	ldr	x13, [x0, #0x10]
      20:      	ldr	x10, [x0, #0x20]
      24:      	ldr	w8, [x1]
      28:      	ldr	w11, [x1, #0x24]
      2c:      	add	w8, w11, w8, lsl #5
      30:      	lsr	w8, w8, #3
      34:      	fmov	s0, w8
      38:      	ushll.2d	v0, v0, #0x0
      3c:      	fmov	x12, d0
      40:      	add	x8, x12, x12, lsl #6
      44:      	lsl	x11, x8, #2
      48:      	add	x8, x9, x11
      4c:      	ldp	q7, q17, [x8]
      50:      	ldp	q19, q18, [x8, #0x20]
      54:      	ldp	q20, q21, [x8, #0x40]
      58:      	ldp	q29, q28, [x8, #0x60]
      5c:      	ldp	q30, q31, [x8, #0x80]
      60:      	ldp	q6, q4, [x8, #0xa0]
      64:      	ldp	q2, q3, [x8, #0xc0]
      68:      	ldp	q1, q0, [x8, #0xe0]
      6c:      	add	x8, x11, #0x100
      70:      	ldr	s27, [x9, x8]
      74:      	fadd.4s	v5, v29, v1
      78:      	fadd.4s	v16, v28, v0
      7c:      	fadd.4s	v22, v21, v3
      80:      	fadd.4s	v23, v20, v2
      84:      	fadd.4s	v24, v19, v6
      88:      	fadd.4s	v25, v18, v4
      8c:      	fadd.4s	v26, v17, v31
      90:      	fadd.4s	v8, v7, v30
      94:      	fadd.4s	v9, v27, v8
      98:      	mov.s	v8[0], v9[0]
      9c:      	fadd.4s	v25, v25, v26
      a0:      	fadd.4s	v24, v24, v8
      a4:      	fadd.4s	v23, v23, v24
      a8:      	fadd.4s	v22, v22, v25
      ac:      	fadd.4s	v16, v16, v22
      b0:      	fadd.4s	v5, v5, v23
      b4:      	rev64.4s	v22, v5
      b8:      	rev64.4s	v23, v16
      bc:      	fadd.4s	v16, v16, v23
      c0:      	fadd.4s	v5, v5, v22
      c4:      	dup.4s	v22, v5[2]
      c8:      	dup.4s	v23, v16[2]
      cc:      	ldr	x9, [x0, #0x30]
      d0:      	fadd.4s	v16, v16, v23
      d4:      	fadd.4s	v5, v5, v22
      d8:      	fadd.4s	v16, v5, v16
      dc:      	movi	d5, #0000000000000000
      e0:      	fadd	s22, s16, s5
      e4:      	mov	w14, #0x42820000        ; =1115815936
      e8:      	fmov	s16, w14
      ec:      	fdiv	s8, s22, s16
      f0:      	dup.4s	v9, v8[0]
      f4:      	fsub.4s	v25, v7, v9
      f8:      	fsub.4s	v26, v17, v9
      fc:      	stp	q25, q26, [sp, #0x140]
     100:      	fsub.4s	v23, v19, v9
     104:      	fsub.4s	v24, v18, v9
     108:      	stp	q23, q24, [sp, #0x160]
     10c:      	fsub.4s	v22, v20, v9
     110:      	fsub.4s	v21, v21, v9
     114:      	stp	q22, q21, [sp, #0x180]
     118:      	fsub.4s	v20, v29, v9
     11c:      	fsub.4s	v19, v28, v9
     120:      	stp	q20, q19, [sp, #0x1a0]
     124:      	fsub.4s	v18, v30, v9
     128:      	fsub.4s	v17, v31, v9
     12c:      	stp	q18, q17, [sp, #0x1c0]
     130:      	fsub.4s	v7, v6, v9
     134:      	fsub.4s	v6, v4, v9
     138:      	stp	q7, q6, [sp, #0x1e0]
     13c:      	fsub.4s	v4, v2, v9
     140:      	fsub.4s	v3, v3, v9
     144:      	stp	q4, q3, [sp, #0x200]
     148:      	fsub.4s	v1, v1, v9
     14c:      	fsub.4s	v2, v0, v9
     150:      	stp	q1, q2, [sp, #0x220]
     154:      	fsub.4s	v13, v27, v8
     158:      	str	q13, [sp, #0x240]
     15c:      	ldp	q27, q28, [x13, #0xc0]
     160:      	stp	q27, q28, [sp, #0xe0]
     164:      	ldp	q27, q28, [x13, #0xe0]
     168:      	stp	q27, q28, [sp, #0x100]
     16c:      	ldp	q27, q28, [x13, #0x80]
     170:      	stp	q27, q28, [sp, #0xa0]
     174:      	ldp	q27, q28, [x13, #0xa0]
     178:      	stp	q27, q28, [sp, #0xc0]
     17c:      	ldp	q27, q28, [x13, #0x40]
     180:      	stp	q27, q28, [sp, #0x60]
     184:      	ldp	q27, q28, [x13, #0x60]
     188:      	stp	q27, q28, [sp, #0x80]
     18c:      	ldp	q27, q28, [x13]
     190:      	stp	q27, q28, [sp, #0x20]
     194:      	ldp	q27, q28, [x13, #0x20]
     198:      	stp	q27, q28, [sp, #0x40]
     19c:      	fmul.4s	v27, v25, v25
     1a0:      	fmul.4s	v28, v26, v26
     1a4:      	fmul.4s	v29, v24, v24
     1a8:      	fmul.4s	v30, v23, v23
     1ac:      	fmul.4s	v31, v22, v22
     1b0:      	fmul.4s	v8, v21, v21
     1b4:      	fmul.4s	v9, v19, v19
     1b8:      	fmul.4s	v10, v20, v20
     1bc:      	fmul.4s	v11, v2, v2
     1c0:      	fmul.4s	v12, v1, v1
     1c4:      	fadd.4s	v10, v10, v12
     1c8:      	fadd.4s	v9, v9, v11
     1cc:      	fmul.4s	v11, v4, v4
     1d0:      	fmul.4s	v12, v3, v3
     1d4:      	fadd.4s	v8, v8, v12
     1d8:      	fadd.4s	v31, v31, v11
     1dc:      	fmul.4s	v11, v6, v6
     1e0:      	fmul.4s	v12, v7, v7
     1e4:      	fadd.4s	v30, v30, v12
     1e8:      	fadd.4s	v29, v29, v11
     1ec:      	fmul.4s	v11, v18, v18
     1f0:      	fmul.4s	v12, v17, v17
     1f4:      	fadd.4s	v28, v28, v12
     1f8:      	fadd.4s	v27, v27, v11
     1fc:      	fmul.4s	v11, v13, v13
     200:      	fadd.4s	v11, v11, v27
     204:      	mov.s	v27[0], v11[0]
     208:      	fadd.4s	v28, v29, v28
     20c:      	fadd.4s	v27, v30, v27
     210:      	fadd.4s	v27, v31, v27
     214:      	fadd.4s	v28, v8, v28
     218:      	fadd.4s	v28, v9, v28
     21c:      	fadd.4s	v27, v10, v27
     220:      	rev64.4s	v29, v27
     224:      	rev64.4s	v30, v28
     228:      	fadd.4s	v28, v28, v30
     22c:      	fadd.4s	v27, v27, v29
     230:      	dup.4s	v29, v27[2]
     234:      	dup.4s	v30, v28[2]
     238:      	fadd.4s	v28, v28, v30
     23c:      	fadd.4s	v27, v27, v29
     240:      	fadd.4s	v27, v27, v28
     244:      	fadd	s5, s27, s5
     248:      	fdiv	s16, s5, s16
     24c:      	ldr	s28, [x13, #0x100]
     250:      	str	q28, [sp, #0x120]
     254:      	mov	w13, #0xc5ac            ; =50604
     258:      	movk	w13, #0x3727, lsl #16
     25c:      	fmov	s27, w13
     260:      	fadd	s16, s16, s27
     264:      	fsqrt	s16, s16
     268:      	sub	x13, x10, x9
     26c:      	lsr	x14, x13, #2
     270:      	subs	x13, x9, x10
     274:      	mov	w15, #0x103             ; =259
     278:      	ccmp	x13, x15, #0x0, hs
     27c:      	cset	w13, hi
     280:      	cmp	x14, #0x450
     284:      	ccmp	x10, x9, #0x0, hi
     288:      	b.hs	0x3e8 <ltmp0+0x3e8>
     28c:      	tbnz	w13, #0x0, 0x3e8 <ltmp0+0x3e8>
     290:      	ldp	q31, q11, [x10]
     294:      	str	q13, [sp, #0x10]
     298:      	ldp	q12, q13, [x10, #0x20]
     29c:      	ldp	q14, q15, [x10, #0x40]
     2a0:      	ldp	q9, q10, [x10, #0x60]
     2a4:      	ldp	q0, q29, [x10, #0x80]
     2a8:      	str	q0, [sp]
     2ac:      	dup.4s	v27, v16[0]
     2b0:      	fdiv.4s	v26, v26, v27
     2b4:      	fdiv.4s	v25, v25, v27
     2b8:      	ldp	q8, q30, [sp, #0x20]
     2bc:      	fmul.4s	v25, v25, v8
     2c0:      	fmul.4s	v26, v26, v30
     2c4:      	ldp	q30, q8, [x10, #0xa0]
     2c8:      	fadd.4s	v11, v26, v11
     2cc:      	fadd.4s	v25, v25, v31
     2d0:      	fdiv.4s	v24, v24, v27
     2d4:      	fdiv.4s	v23, v23, v27
     2d8:      	ldp	q31, q26, [sp, #0x40]
     2dc:      	fmul.4s	v0, v23, v31
     2e0:      	fmul.4s	v23, v24, v26
     2e4:      	ldp	q26, q31, [x10, #0xc0]
     2e8:      	add	x11, x9, x11
     2ec:      	fadd.4s	v5, v23, v13
     2f0:      	ldp	q24, q13, [x10, #0xe0]
     2f4:      	ldr	s23, [x10, #0x100]
     2f8:      	stp	q25, q11, [x11]
     2fc:      	fadd.4s	v0, v0, v12
     300:      	fdiv.4s	v22, v22, v27
     304:      	ldr	q25, [sp, #0x60]
     308:      	fmul.4s	v22, v22, v25
     30c:      	ldr	q25, [sp, #0x70]
     310:      	fdiv.4s	v21, v21, v27
     314:      	fmul.4s	v21, v21, v25
     318:      	fadd.4s	v21, v21, v15
     31c:      	fadd.4s	v22, v22, v14
     320:      	stp	q0, q5, [x11, #0x20]
     324:      	stp	q22, q21, [x11, #0x40]
     328:      	fdiv.4s	v0, v20, v27
     32c:      	ldr	q5, [sp, #0x80]
     330:      	fmul.4s	v0, v0, v5
     334:      	ldr	q5, [sp, #0x90]
     338:      	fdiv.4s	v19, v19, v27
     33c:      	fmul.4s	v5, v19, v5
     340:      	fadd.4s	v5, v5, v10
     344:      	fadd.4s	v0, v0, v9
     348:      	fdiv.4s	v18, v18, v27
     34c:      	ldp	q20, q19, [sp, #0xa0]
     350:      	fmul.4s	v18, v18, v20
     354:      	fdiv.4s	v17, v17, v27
     358:      	fmul.4s	v17, v17, v19
     35c:      	fadd.4s	v17, v17, v29
     360:      	stp	q0, q5, [x11, #0x60]
     364:      	ldr	q0, [sp]
     368:      	fadd.4s	v0, v18, v0
     36c:      	fdiv.4s	v5, v7, v27
     370:      	ldr	q7, [sp, #0xc0]
     374:      	fmul.4s	v5, v5, v7
     378:      	ldr	q7, [sp, #0xd0]
     37c:      	fdiv.4s	v6, v6, v27
     380:      	fmul.4s	v6, v6, v7
     384:      	fadd.4s	v6, v6, v8
     388:      	stp	q0, q17, [x11, #0x80]
     38c:      	fadd.4s	v0, v5, v30
     390:      	fdiv.4s	v4, v4, v27
     394:      	ldp	q7, q5, [sp, #0xe0]
     398:      	fmul.4s	v4, v4, v7
     39c:      	fdiv.4s	v3, v3, v27
     3a0:      	fmul.4s	v3, v3, v5
     3a4:      	fadd.4s	v3, v3, v31
     3a8:      	stp	q0, q6, [x11, #0xa0]
     3ac:      	fadd.4s	v0, v4, v26
     3b0:      	fdiv.4s	v2, v2, v27
     3b4:      	fdiv.4s	v1, v1, v27
     3b8:      	ldp	q5, q4, [sp, #0x100]
     3bc:      	fmul.4s	v1, v1, v5
     3c0:      	fmul.4s	v2, v2, v4
     3c4:      	fadd.4s	v2, v2, v13
     3c8:      	stp	q0, q3, [x11, #0xc0]
     3cc:      	fadd.4s	v1, v1, v24
     3d0:      	ldr	q0, [sp, #0x10]
     3d4:      	fdiv.4s	v0, v0, v16
     3d8:      	fmul.4s	v0, v0, v28
     3dc:      	fadd.4s	v0, v0, v23
     3e0:      	stp	q1, q2, [x11, #0xe0]
     3e4:      	b	0x488 <ltmp0+0x488>
     3e8:      	mov	x14, #0x0               ; =0
     3ec:      	dup.4s	v1, v16[0]
     3f0:      	mov	w11, #0x104             ; =260
     3f4:      	umaddl	x11, w12, w11, x9
     3f8:      	movi.2d	v2, #0000000000000000
     3fc:      	add	x12, sp, #0x140
     400:      	add	x13, sp, #0x20
     404:      	mov	w15, #0x1               ; =1
     408:      	dup.2d	v3, x15
     40c:      	movi.2d	v4, #0000000000000000
     410:      	movi.2d	v6, #0000000000000000
     414:      	movi.2d	v7, #0000000000000000
     418:      	lsl	x14, x14, #5
     41c:      	add	x15, x12, x14
     420:      	ldp	q5, q0, [x15]
     424:      	fdiv.4s	v5, v5, v1
     428:      	fdiv.4s	v0, v0, v1
     42c:      	add	x14, x13, x14
     430:      	ldp	q17, q18, [x14]
     434:      	fmul.4s	v0, v0, v18
     438:      	fmul.4s	v5, v5, v17
     43c:      	fmov	x14, d2
     440:      	lsl	x14, x14, #5
     444:      	add	x15, x10, x14
     448:      	ldp	q18, q17, [x15]
     44c:      	fadd.4s	v5, v5, v18
     450:      	fadd.4s	v0, v0, v17
     454:      	add	x14, x11, x14
     458:      	stp	q5, q0, [x14]
     45c:      	add.2d	v6, v6, v3
     460:      	add.2d	v4, v4, v3
     464:      	add.2d	v7, v7, v3
     468:      	add.2d	v2, v2, v3
     46c:      	fmov	x14, d2
     470:      	cmp	x14, #0x8
     474:      	b.lt	0x418 <ltmp0+0x418>
     478:      	fdiv.4s	v0, v13, v16
     47c:      	fmul.4s	v0, v0, v28
     480:      	ldr	s1, [x10, #0x100]
     484:      	fadd.4s	v0, v0, v1
     488:      	str	s0, [x9, x8]
     48c:      	add	sp, sp, #0x260
     490:      	ldp	x28, x27, [sp, #0x40]
     494:      	ldp	d9, d8, [sp, #0x30]
     498:      	ldp	d11, d10, [sp, #0x20]
     49c:      	ldp	d13, d12, [sp, #0x10]
     4a0:      	ldp	d15, d14, [sp], #0x50
     4a4:      	ret

00000000000004a8 <_llm_rows.packet_batch.blocks>:
     4a8:      	stp	d15, d14, [sp, #-0xa0]!
     4ac:      	stp	d13, d12, [sp, #0x10]
     4b0:      	stp	d11, d10, [sp, #0x20]
     4b4:      	stp	d9, d8, [sp, #0x30]
     4b8:      	stp	x28, x27, [sp, #0x40]
     4bc:      	stp	x26, x25, [sp, #0x50]
     4c0:      	stp	x24, x23, [sp, #0x60]
     4c4:      	stp	x22, x21, [sp, #0x70]
     4c8:      	stp	x20, x19, [sp, #0x80]
     4cc:      	stp	x29, x30, [sp, #0x90]
     4d0:      	sub	sp, sp, #0xb20
     4d4:      	str	x0, [sp, #0x1c8]
     4d8:      	cbz	w3, 0x1dd4 <_llm_rows.packet_batch.blocks+0x192c>
     4dc:      	mov	x27, x3
     4e0:      	mov	x20, x2
     4e4:      	mov	w22, #0x0               ; =0
     4e8:      	ldp	w9, w8, [x2, #0x2c]
     4ec:      	str	w9, [sp, #0x1c4]
     4f0:      	str	w8, [sp, #0x1c0]
     4f4:      	add	x25, sp, #0xa00
     4f8:      	ldp	w24, w0, [x2]
     4fc:      	adrp	x8, 0x0 <ltmp0>
     500:      	ldr	q0, [x8]
     504:      	str	q0, [sp, #0x10]
     508:      	adrp	x8, 0x0 <ltmp0>
     50c:      	ldr	q0, [x8]
     510:      	str	q0, [sp, #0x30]
     514:      	adrp	x8, 0x0 <ltmp0>
     518:      	ldr	q0, [x8]
     51c:      	str	q0, [sp, #0x20]
     520:      	movi.2s	v8, #0x41
     524:      	ldp	w26, w8, [x2, #0x8]
     528:      	str	x8, [sp, #0x1b8]
     52c:      	add	x19, sp, #0x8e0
     530:      	add	x21, sp, #0x7c0
     534:      	str	w3, [sp, #0x18c]
     538:      	b	0x584 <_llm_rows.packet_batch.blocks+0xdc>
     53c:      	mov	w8, #0x18               ; =24
     540:      	str	w8, [x20, #0x24]
     544:      	ldr	w27, [sp, #0x18c]
     548:      	add	w8, w24, #0x1
     54c:      	ldr	w9, [sp, #0x1c4]
     550:      	cmp	w8, w9
     554:      	cset	w8, eq
     558:      	csinc	w24, wzr, w24, eq
     55c:      	cinc	w9, w0, eq
     560:      	ldr	w10, [sp, #0x1c0]
     564:      	cmp	w9, w10
     568:      	cset	w10, eq
     56c:      	ands	w8, w8, w10
     570:      	csel	w0, wzr, w9, ne
     574:      	add	w26, w26, w8
     578:      	add	w22, w22, #0x1
     57c:      	cmp	w22, w27
     580:      	b.eq	0x1dd4 <_llm_rows.packet_batch.blocks+0x192c>
     584:      	ubfiz	x8, x24, #5, #32
     588:      	ldr	x12, [sp, #0x1b8]
     58c:      	cmp	x8, x12
     590:      	csel	x9, x8, xzr, ls
     594:      	subs	x10, x12, x9
     598:      	cmp	x10, #0x20
     59c:      	mov	w11, #0x20              ; =32
     5a0:      	csel	x10, x10, x11, lo
     5a4:      	cmp	x12, x9
     5a8:      	stp	w24, w0, [x20]
     5ac:      	str	w26, [x20, #0x8]
     5b0:      	str	wzr, [x20, #0x24]
     5b4:      	ccmp	x8, x12, #0x2, hi
     5b8:      	csel	x23, x10, xzr, ls
     5bc:      	cmp	x23, #0x20
     5c0:      	b.lo	0x61c <_llm_rows.packet_batch.blocks+0x174>
     5c4:      	ldr	x23, [sp, #0x1c8]
     5c8:      	mov	x28, x0
     5cc:      	mov	x0, x23
     5d0:      	mov	x1, x20
     5d4:      	bl	0x5d4 <_llm_rows.packet_batch.blocks+0x12c>
     5d8:      	mov	w8, #0x8                ; =8
     5dc:      	str	w8, [x20, #0x24]
     5e0:      	mov	x0, x23
     5e4:      	mov	x1, x20
     5e8:      	bl	0x5e8 <_llm_rows.packet_batch.blocks+0x140>
     5ec:      	mov	w8, #0x10               ; =16
     5f0:      	str	w8, [x20, #0x24]
     5f4:      	mov	x0, x23
     5f8:      	mov	x1, x20
     5fc:      	bl	0x5fc <_llm_rows.packet_batch.blocks+0x154>
     600:      	mov	w8, #0x18               ; =24
     604:      	str	w8, [x20, #0x24]
     608:      	mov	x0, x23
     60c:      	mov	x1, x20
     610:      	bl	0x610 <_llm_rows.packet_batch.blocks+0x168>
     614:      	mov	x0, x28
     618:      	b	0x548 <_llm_rows.packet_batch.blocks+0xa0>
     61c:      	lsr	x27, x23, #3
     620:      	cmp	x23, #0x8
     624:      	b.lo	0x680 <_llm_rows.packet_batch.blocks+0x1d8>
     628:      	str	wzr, [x20, #0x24]
     62c:      	mov	x28, x0
     630:      	ldr	x0, [sp, #0x1c8]
     634:      	mov	x1, x20
     638:      	bl	0x638 <_llm_rows.packet_batch.blocks+0x190>
     63c:      	mov	x0, x28
     640:      	cmp	x27, #0x1
     644:      	b.eq	0x680 <_llm_rows.packet_batch.blocks+0x1d8>
     648:      	mov	w8, #0x8                ; =8
     64c:      	str	w8, [x20, #0x24]
     650:      	ldr	x0, [sp, #0x1c8]
     654:      	mov	x1, x20
     658:      	bl	0x658 <_llm_rows.packet_batch.blocks+0x1b0>
     65c:      	mov	x0, x28
     660:      	cmp	x27, #0x2
     664:      	b.eq	0x680 <_llm_rows.packet_batch.blocks+0x1d8>
     668:      	mov	w8, #0x10               ; =16
     66c:      	str	w8, [x20, #0x24]
     670:      	ldr	x0, [sp, #0x1c8]
     674:      	mov	x1, x20
     678:      	bl	0x678 <_llm_rows.packet_batch.blocks+0x1d0>
     67c:      	mov	x0, x28
     680:      	and	w8, w23, #0x7
     684:      	mov	w28, #0x4               ; =4
     688:      	cbz	w8, 0x53c <_llm_rows.packet_batch.blocks+0x94>
     68c:      	dup.4s	v1, w8
     690:      	ldp	q0, q2, [sp, #0x20]
     694:      	cmhi.4s	v0, v1, v0
     698:      	cmhi.4s	v1, v1, v2
     69c:      	uzp1.8h	v3, v1, v0
     6a0:      	umaxv.8h	h2, v3
     6a4:      	fmov	w8, s2
     6a8:      	tbz	w8, #0x0, 0x53c <_llm_rows.packet_batch.blocks+0x94>
     6ac:      	mov	x11, #0x0               ; =0
     6b0:      	ldr	x8, [sp, #0x1c8]
     6b4:      	ldr	x9, [x8]
     6b8:      	ldr	x12, [x8, #0x10]
     6bc:      	ldr	x10, [x8, #0x20]
     6c0:      	ldr	x8, [x8, #0x30]
     6c4:      	ldr	q2, [sp, #0x10]
     6c8:      	str	q3, [sp, #0xb0]
     6cc:      	and.16b	v2, v3, v2
     6d0:      	addv.8h	h18, v2
     6d4:      	fmov	w13, s18
     6d8:      	and	w23, w13, #0xff
     6dc:      	ubfiz	w13, w24, #2, #27
     6e0:      	orr	w13, w13, w27
     6e4:      	dup.4s	v3, w13
     6e8:      	and.16b	v7, v1, v3
     6ec:      	and.16b	v3, v0, v3
     6f0:      	ushll2.2d	v4, v3, #0x0
     6f4:      	ushll2.2d	v5, v7, #0x0
     6f8:      	ushll.2d	v6, v3, #0x0
     6fc:      	ushll.2d	v3, v7, #0x0
     700:      	fmov	x13, d3
     704:      	mov	w14, #0x104             ; =260
     708:      	umaddl	x13, w13, w14, x9
     70c:      	fmov	w14, s18
     710:      	b	0x734 <_llm_rows.packet_batch.blocks+0x28c>
     714:      	add	x15, x25, x11
     718:      	ldp	q17, q19, [x15]
     71c:      	bif.16b	v16, v19, v0
     720:      	bif.16b	v7, v17, v1
     724:      	stp	q7, q16, [x15]
     728:      	add	x11, x11, #0x20
     72c:      	cmp	x11, #0x100
     730:      	b.eq	0x7c8 <_llm_rows.packet_batch.blocks+0x320>
     734:      	add	x15, x13, x11
     738:      	movi.2d	v7, #0000000000000000
     73c:      	movi.2d	v16, #0000000000000000
     740:      	tbnz	w14, #0x0, 0x768 <_llm_rows.packet_batch.blocks+0x2c0>
     744:      	and	w16, w14, #0xff
     748:      	tbnz	w16, #0x1, 0x774 <_llm_rows.packet_batch.blocks+0x2cc>
     74c:      	tbnz	w16, #0x2, 0x780 <_llm_rows.packet_batch.blocks+0x2d8>
     750:      	tbnz	w16, #0x3, 0x78c <_llm_rows.packet_batch.blocks+0x2e4>
     754:      	tbnz	w16, #0x4, 0x798 <_llm_rows.packet_batch.blocks+0x2f0>
     758:      	tbnz	w16, #0x5, 0x7a4 <_llm_rows.packet_batch.blocks+0x2fc>
     75c:      	tbnz	w16, #0x6, 0x7b0 <_llm_rows.packet_batch.blocks+0x308>
     760:      	tbz	w16, #0x7, 0x714 <_llm_rows.packet_batch.blocks+0x26c>
     764:      	b	0x7bc <_llm_rows.packet_batch.blocks+0x314>
     768:      	ldr	s7, [x15]
     76c:      	and	w16, w14, #0xff
     770:      	tbz	w16, #0x1, 0x74c <_llm_rows.packet_batch.blocks+0x2a4>
     774:      	add	x17, x15, #0x4
     778:      	ld1.s	{ v7 }[1], [x17]
     77c:      	tbz	w16, #0x2, 0x750 <_llm_rows.packet_batch.blocks+0x2a8>
     780:      	add	x17, x15, #0x8
     784:      	ld1.s	{ v7 }[2], [x17]
     788:      	tbz	w16, #0x3, 0x754 <_llm_rows.packet_batch.blocks+0x2ac>
     78c:      	add	x17, x15, #0xc
     790:      	ld1.s	{ v7 }[3], [x17]
     794:      	tbz	w16, #0x4, 0x758 <_llm_rows.packet_batch.blocks+0x2b0>
     798:      	add	x17, x15, #0x10
     79c:      	ld1.s	{ v16 }[0], [x17]
     7a0:      	tbz	w16, #0x5, 0x75c <_llm_rows.packet_batch.blocks+0x2b4>
     7a4:      	add	x17, x15, #0x14
     7a8:      	ld1.s	{ v16 }[1], [x17]
     7ac:      	tbz	w16, #0x6, 0x760 <_llm_rows.packet_batch.blocks+0x2b8>
     7b0:      	add	x17, x15, #0x18
     7b4:      	ld1.s	{ v16 }[2], [x17]
     7b8:      	tbz	w16, #0x7, 0x714 <_llm_rows.packet_batch.blocks+0x26c>
     7bc:      	add	x15, x15, #0x1c
     7c0:      	ld1.s	{ v16 }[3], [x15]
     7c4:      	b	0x714 <_llm_rows.packet_batch.blocks+0x26c>
     7c8:      	xtn.4h	v7, v1
     7cc:      	uzp1.8b	v17, v7, v0
     7d0:      	sshll.2d	v20, v1, #0x0
     7d4:      	adrp	x11, 0x0 <ltmp0>
     7d8:      	ldr	q7, [x11]
     7dc:      	and.16b	v16, v20, v7
     7e0:      	movi.2d	v7, #0000000000000000
     7e4:      	mov.b	v7[0], v17[0]
     7e8:      	adrp	x11, 0x0 <ltmp0>
     7ec:      	ldr	d2, [x11]
     7f0:      	str	d2, [sp, #0xf8]
     7f4:      	and.8b	v19, v7, v2
     7f8:      	addv.8b	b19, v19
     7fc:      	fmov	w11, s19
     800:      	umaxv.8b	b19, v7
     804:      	fmov	w13, s19
     808:      	rbit	w14, w11
     80c:      	clz	w14, w14
     810:      	tst	w13, #0x1
     814:      	csel	w16, w14, wzr, ne
     818:      	mov	w14, #0x40              ; =64
     81c:      	dup.2d	v21, x14
     820:      	orr.16b	v2, v16, v21
     824:      	xtn.2s	v22, v3
     828:      	str	q2, [sp, #0x100]
     82c:      	umlal.2d	v2, v22, v8
     830:      	movi.2d	v3, #0000000000000000
     834:      	mov.b	v3[0], v17[0]
     838:      	ushll.2d	v3, v3, #0x0
     83c:      	shl.2d	v3, v3, #0x3f
     840:      	cmlt.2d	v3, v3, #0
     844:      	str	q2, [sp, #0x150]
     848:      	and.16b	v3, v3, v2
     84c:      	movi.2d	v2, #0000000000000000
     850:      	str	q2, [sp, #0x680]
     854:      	str	q2, [sp, #0x670]
     858:      	str	q2, [sp, #0x660]
     85c:      	str	q3, [sp, #0x650]
     860:      	and	x14, x16, #0x7
     864:      	add	x15, sp, #0x650
     868:      	ldr	x14, [x15, x14, lsl #3]
     86c:      	sub	x14, x14, x16
     870:      	add	x9, x9, x14, lsl #2
     874:      	movi.2d	v29, #0000000000000000
     878:      	movi.2d	v30, #0000000000000000
     87c:      	tbnz	w13, #0x0, 0x1a24 <_llm_rows.packet_batch.blocks+0x157c>
     880:      	tbnz	w11, #0x1, 0x1a2c <_llm_rows.packet_batch.blocks+0x1584>
     884:      	tbnz	w11, #0x2, 0x1a38 <_llm_rows.packet_batch.blocks+0x1590>
     888:      	tbnz	w11, #0x3, 0x1a44 <_llm_rows.packet_batch.blocks+0x159c>
     88c:      	tbnz	w11, #0x4, 0x1a50 <_llm_rows.packet_batch.blocks+0x15a8>
     890:      	tbnz	w11, #0x5, 0x1a5c <_llm_rows.packet_batch.blocks+0x15b4>
     894:      	tbnz	w11, #0x6, 0x1a68 <_llm_rows.packet_batch.blocks+0x15c0>
     898:      	str	q16, [sp, #0x190]
     89c:      	str	q18, [sp, #0x170]
     8a0:      	tbz	w11, #0x7, 0x8ac <_llm_rows.packet_batch.blocks+0x404>
     8a4:      	add	x9, x9, #0x1c
     8a8:      	ld1.s	{ v30 }[3], [x9]
     8ac:      	str	w0, [sp, #0x188]
     8b0:      	sshll.2d	v23, v0, #0x0
     8b4:      	sshll2.2d	v24, v1, #0x0
     8b8:      	sshll2.2d	v25, v0, #0x0
     8bc:      	adrp	x9, 0x0 <ltmp0>
     8c0:      	ldr	q3, [x9]
     8c4:      	and.16b	v2, v25, v3
     8c8:      	adrp	x9, 0x0 <ltmp0>
     8cc:      	ldr	q17, [x9]
     8d0:      	and.16b	v3, v24, v17
     8d4:      	adrp	x9, 0x0 <ltmp0>
     8d8:      	ldr	q19, [x9]
     8dc:      	and.16b	v16, v23, v19
     8e0:      	adrp	x9, 0x0 <ltmp0>
     8e4:      	ldr	q26, [x9]
     8e8:      	and.16b	v26, v25, v26
     8ec:      	adrp	x9, 0x0 <ltmp0>
     8f0:      	ldr	q27, [x9]
     8f4:      	and.16b	v27, v24, v27
     8f8:      	adrp	x9, 0x0 <ltmp0>
     8fc:      	ldr	q28, [x9]
     900:      	and.16b	v23, v23, v28
     904:      	adrp	x9, 0x0 <ltmp0>
     908:      	ldr	q28, [x9]
     90c:      	and.16b	v20, v20, v28
     910:      	stp	q16, q3, [sp, #0x80]
     914:      	orr.16b	v16, v16, v21
     918:      	orr.16b	v17, v3, v21
     91c:      	str	q2, [sp, #0xa0]
     920:      	orr.16b	v3, v2, v21
     924:      	umull.2d	v2, v22, v8
     928:      	str	q2, [sp, #0x110]
     92c:      	xtn.2s	v5, v5
     930:      	xtn.2s	v6, v6
     934:      	xtn.2s	v4, v4
     938:      	stp	q16, q3, [sp, #0xd0]
     93c:      	mov.16b	v2, v3
     940:      	umlal.2d	v2, v4, v8
     944:      	str	q2, [sp, #0x140]
     948:      	str	q17, [sp, #0xc0]
     94c:      	mov.16b	v2, v17
     950:      	umlal.2d	v2, v5, v8
     954:      	str	q2, [sp, #0x130]
     958:      	mov.16b	v2, v16
     95c:      	umlal.2d	v2, v6, v8
     960:      	str	q2, [sp, #0x120]
     964:      	sshll.2d	v4, v1, #0x0
     968:      	sshll.2d	v5, v0, #0x0
     96c:      	str	q20, [sp, #0x610]
     970:      	str	q27, [sp, #0x620]
     974:      	str	q23, [sp, #0x630]
     978:      	str	q26, [sp, #0x640]
     97c:      	and	x9, x16, #0x7
     980:      	add	x13, sp, #0x610
     984:      	ldr	x9, [x13, x9, lsl #3]
     988:      	orr	x9, x9, #0x100
     98c:      	str	x16, [sp, #0x168]
     990:      	sub	x9, x9, x16, lsl #2
     994:      	tst	w11, #0xff
     998:      	csel	x9, xzr, x9, eq
     99c:      	str	x9, [sp, #0x1b0]
     9a0:      	add	x9, x25, x9
     9a4:      	ldp	q6, q21, [x9]
     9a8:      	zip2.8b	v22, v7, v0
     9ac:      	ushll.4s	v22, v22, #0x0
     9b0:      	shl.4s	v22, v22, #0x1f
     9b4:      	cmlt.4s	v22, v22, #0
     9b8:      	stp	q30, q29, [sp, #0x50]
     9bc:      	bit.16b	v21, v30, v22
     9c0:      	str	q7, [sp, #0x1a0]
     9c4:      	zip1.8b	v22, v7, v0
     9c8:      	ushll.4s	v22, v22, #0x0
     9cc:      	shl.4s	v22, v22, #0x1f
     9d0:      	cmlt.4s	v22, v22, #0
     9d4:      	bit.16b	v6, v29, v22
     9d8:      	stp	q6, q21, [x9]
     9dc:      	fmov	x3, d20
     9e0:      	dup.2d	v6, x28
     9e4:      	and.16b	v27, v25, v6
     9e8:      	and.16b	v11, v24, v6
     9ec:      	and.16b	v12, v5, v6
     9f0:      	and.16b	v13, v4, v6
     9f4:      	fmov	x14, d13
     9f8:      	ldr	q5, [sp, #0xa60]
     9fc:      	ldr	q4, [sp, #0xa70]
     a00:      	and.16b	v4, v0, v4
     a04:      	and.16b	v5, v1, v5
     a08:      	ldr	q6, [sp, #0xa40]
     a0c:      	ldr	q20, [sp, #0xa50]
     a10:      	and.16b	v20, v0, v20
     a14:      	and.16b	v6, v1, v6
     a18:      	ldr	q22, [sp, #0xa20]
     a1c:      	ldr	q21, [sp, #0xa30]
     a20:      	and.16b	v21, v0, v21
     a24:      	and.16b	v22, v1, v22
     a28:      	add	x9, x25, x3
     a2c:      	ldp	q23, q26, [x9]
     a30:      	and.16b	v26, v0, v26
     a34:      	mov	x9, x14
     a38:      	and.16b	v8, v1, v23
     a3c:      	mov.16b	v29, v13
     a40:      	mov.16b	v14, v11
     a44:      	mov.16b	v15, v12
     a48:      	mov.16b	v10, v27
     a4c:      	sshll.2d	v9, v1, #0x0
     a50:      	sshll.2d	v18, v0, #0x0
     a54:      	add	x9, x25, x9, lsl #5
     a58:      	ldp	q23, q28, [x9]
     a5c:      	fadd.4s	v23, v8, v23
     a60:      	fadd.4s	v28, v26, v28
     a64:      	ldp	q30, q16, [x9, #0x20]
     a68:      	fadd.4s	v30, v22, v30
     a6c:      	fadd.4s	v16, v21, v16
     a70:      	ldp	q3, q31, [x9, #0x40]
     a74:      	fadd.4s	v3, v6, v3
     a78:      	fadd.4s	v31, v20, v31
     a7c:      	ldp	q17, q7, [x9, #0x60]
     a80:      	fadd.4s	v17, v5, v17
     a84:      	fadd.4s	v7, v4, v7
     a88:      	dup.2d	v19, x28
     a8c:      	and.16b	v2, v25, v19
     a90:      	add.2d	v10, v10, v2
     a94:      	and.16b	v2, v24, v19
     a98:      	add.2d	v14, v14, v2
     a9c:      	and.16b	v2, v18, v19
     aa0:      	add.2d	v15, v15, v2
     aa4:      	and.16b	v2, v9, v19
     aa8:      	add.2d	v29, v29, v2
     aac:      	bit.16b	v26, v28, v0
     ab0:      	bit.16b	v8, v23, v1
     ab4:      	bit.16b	v21, v16, v0
     ab8:      	bit.16b	v22, v30, v1
     abc:      	bit.16b	v20, v31, v0
     ac0:      	bit.16b	v6, v3, v1
     ac4:      	bit.16b	v4, v7, v0
     ac8:      	bit.16b	v5, v17, v1
     acc:      	fmov	x9, d29
     ad0:      	cmp	x9, #0x8
     ad4:      	b.lt	0xa4c <_llm_rows.packet_batch.blocks+0x5a4>
     ad8:      	mov	x4, #0x0                ; =0
     adc:      	ldr	q2, [sp, #0xb0]
     ae0:      	xtn.8b	v29, v2
     ae4:      	ldp	q31, q30, [sp, #0x50]
     ae8:      	fadd.4s	v2, v31, v26
     aec:      	fadd.4s	v3, v30, v8
     af0:      	ldr	q26, [sp, #0x1a0]
     af4:      	zip2.8b	v7, v26, v0
     af8:      	ushll.4s	v7, v7, #0x0
     afc:      	shl.4s	v7, v7, #0x1f
     b00:      	cmlt.4s	v7, v7, #0
     b04:      	and.16b	v2, v7, v2
     b08:      	zip2.8b	v7, v29, v0
     b0c:      	ushll.4s	v7, v7, #0x0
     b10:      	shl.4s	v7, v7, #0x1f
     b14:      	cmlt.4s	v7, v7, #0
     b18:      	bit.16b	v2, v28, v7
     b1c:      	zip1.8b	v7, v26, v0
     b20:      	ushll.4s	v7, v7, #0x0
     b24:      	shl.4s	v7, v7, #0x1f
     b28:      	cmlt.4s	v7, v7, #0
     b2c:      	movi.2d	v16, #0000000000000000
     b30:      	mov.b	v16[2], v29[1]
     b34:      	mov.b	v16[4], v29[2]
     b38:      	and.16b	v3, v7, v3
     b3c:      	mov.b	v16[6], v29[3]
     b40:      	ushll.4s	v7, v16, #0x0
     b44:      	shl.4s	v7, v7, #0x1f
     b48:      	cmlt.4s	v7, v7, #0
     b4c:      	bit.16b	v3, v23, v7
     b50:      	fadd.4s	v3, v22, v3
     b54:      	fadd.4s	v2, v21, v2
     b58:      	fadd.4s	v2, v20, v2
     b5c:      	fadd.4s	v3, v6, v3
     b60:      	fadd.4s	v5, v5, v3
     b64:      	fadd.4s	v6, v4, v2
     b68:      	ldr	q2, [sp, #0x190]
     b6c:      	ldp	q3, q7, [sp, #0x80]
     b70:      	uzp1.4s	v4, v2, v7
     b74:      	ldr	q2, [sp, #0xa0]
     b78:      	uzp1.4s	v3, v3, v2
     b7c:      	movi.4s	v7, #0x1
     b80:      	eor.16b	v2, v4, v7
     b84:      	mov.s	w11, v2[1]
     b88:      	eor.16b	v20, v3, v7
     b8c:      	mov.s	w15, v2[2]
     b90:      	mov.s	w17, v2[3]
     b94:      	fmov	w9, s2
     b98:      	add	x13, sp, #0x4a8
     b9c:      	bfxil	x13, x9, #0, #3
     ba0:      	str	d29, [sp, #0x4a8]
     ba4:      	ldrb	w16, [x13]
     ba8:      	umov.b	w13, v29[0]
     bac:      	and	x9, x9, #0x7
     bb0:      	str	q6, [sp, #0x580]
     bb4:      	str	q5, [sp, #0x570]
     bb8:      	add	x0, sp, #0x570
     bbc:      	ldr	s2, [x0, x9, lsl #2]
     bc0:      	ands	w9, w13, #0x1
     bc4:      	tst	w9, w16
     bc8:      	movi	d22, #0000000000000000
     bcc:      	fcsel	s17, s2, s22, ne
     bd0:      	and	x16, x11, #0x7
     bd4:      	add	x0, sp, #0x4a8
     bd8:      	bfxil	x0, x11, #0, #3
     bdc:      	ldrb	w11, [x0]
     be0:      	umov.b	w0, v29[1]
     be4:      	str	q6, [sp, #0x560]
     be8:      	str	q5, [sp, #0x550]
     bec:      	add	x1, sp, #0x550
     bf0:      	ldr	s2, [x1, x16, lsl #2]
     bf4:      	and	w11, w0, w11
     bf8:      	tst	w11, #0x1
     bfc:      	fcsel	s18, s2, s22, ne
     c00:      	and	x11, x15, #0x7
     c04:      	add	x16, sp, #0x4a8
     c08:      	bfxil	x16, x15, #0, #3
     c0c:      	ldrb	w15, [x16]
     c10:      	umov.b	w16, v29[2]
     c14:      	and	w15, w16, w15
     c18:      	str	q6, [sp, #0x540]
     c1c:      	str	q5, [sp, #0x530]
     c20:      	add	x1, sp, #0x530
     c24:      	ldr	s2, [x1, x11, lsl #2]
     c28:      	tst	w15, #0x1
     c2c:      	fcsel	s19, s2, s22, ne
     c30:      	and	x11, x17, #0x7
     c34:      	add	x15, sp, #0x4a8
     c38:      	bfxil	x15, x17, #0, #3
     c3c:      	ldrb	w15, [x15]
     c40:      	umov.b	w17, v29[3]
     c44:      	and	w15, w17, w15
     c48:      	str	q6, [sp, #0x520]
     c4c:      	str	q5, [sp, #0x510]
     c50:      	add	x1, sp, #0x510
     c54:      	ldr	s2, [x1, x11, lsl #2]
     c58:      	tst	w15, #0x1
     c5c:      	mov.s	w11, v20[1]
     c60:      	fcsel	s21, s2, s22, ne
     c64:      	mov.s	w15, v20[2]
     c68:      	mov.s	w2, v20[3]
     c6c:      	fmov	w1, s20
     c70:      	and	x5, x1, #0x7
     c74:      	add	x6, sp, #0x4a8
     c78:      	bfxil	x6, x1, #0, #3
     c7c:      	ldrb	w6, [x6]
     c80:      	umov.b	w1, v29[4]
     c84:      	and	w6, w1, w6
     c88:      	str	q6, [sp, #0x600]
     c8c:      	str	q5, [sp, #0x5f0]
     c90:      	add	x7, sp, #0x5f0
     c94:      	ldr	s2, [x7, x5, lsl #2]
     c98:      	tst	w6, #0x1
     c9c:      	fcsel	s2, s2, s22, ne
     ca0:      	and	x5, x11, #0x7
     ca4:      	add	x6, sp, #0x4a8
     ca8:      	bfxil	x6, x11, #0, #3
     cac:      	umov.b	w11, v29[5]
     cb0:      	ldrb	w6, [x6]
     cb4:      	and	w6, w11, w6
     cb8:      	str	q6, [sp, #0x5e0]
     cbc:      	str	q5, [sp, #0x5d0]
     cc0:      	add	x7, sp, #0x5d0
     cc4:      	ldr	s7, [x7, x5, lsl #2]
     cc8:      	tst	w6, #0x1
     ccc:      	fcsel	s7, s7, s22, ne
     cd0:      	and	x6, x15, #0x7
     cd4:      	add	x5, sp, #0x4a8
     cd8:      	bfxil	x5, x15, #0, #3
     cdc:      	ldrb	w15, [x5]
     ce0:      	umov.b	w5, v29[6]
     ce4:      	str	q6, [sp, #0x5c0]
     ce8:      	str	q5, [sp, #0x5b0]
     cec:      	add	x7, sp, #0x5b0
     cf0:      	ldr	s16, [x7, x6, lsl #2]
     cf4:      	and	w15, w5, w15
     cf8:      	tst	w15, #0x1
     cfc:      	fcsel	s16, s16, s22, ne
     d00:      	and	x15, x2, #0x7
     d04:      	add	x6, sp, #0x4a8
     d08:      	bfxil	x6, x2, #0, #3
     d0c:      	ldrb	w6, [x6]
     d10:      	umov.b	w2, v29[7]
     d14:      	and	w6, w2, w6
     d18:      	str	q6, [sp, #0x5a0]
     d1c:      	str	q5, [sp, #0x590]
     d20:      	add	x7, sp, #0x590
     d24:      	ldr	s20, [x7, x15, lsl #2]
     d28:      	tst	w6, #0x1
     d2c:      	fcsel	s20, s20, s22, ne
     d30:      	mov.s	v2[1], v7[0]
     d34:      	mov.s	v2[2], v16[0]
     d38:      	mov.s	v2[3], v20[0]
     d3c:      	mov.s	v17[1], v18[0]
     d40:      	mov.s	v17[2], v19[0]
     d44:      	mov.s	v17[3], v21[0]
     d48:      	fadd.4s	v5, v5, v17
     d4c:      	fadd.4s	v2, v6, v2
     d50:      	movi.4s	v6, #0x2
     d54:      	eor.16b	v3, v3, v6
     d58:      	eor.16b	v4, v4, v6
     d5c:      	fmov	w15, s4
     d60:      	add	x6, sp, #0x4a8
     d64:      	bfxil	x6, x15, #0, #3
     d68:      	ldrb	w6, [x6]
     d6c:      	and	x15, x15, #0x7
     d70:      	str	q2, [sp, #0x500]
     d74:      	str	q5, [sp, #0x4f0]
     d78:      	add	x7, sp, #0x4f0
     d7c:      	ldr	s4, [x7, x15, lsl #2]
     d80:      	tst	w9, w6
     d84:      	fcsel	s4, s4, s22, ne
     d88:      	fmov	w9, s3
     d8c:      	and	x15, x9, #0x7
     d90:      	add	x6, sp, #0x4a8
     d94:      	bfxil	x6, x9, #0, #3
     d98:      	ldrb	w9, [x6]
     d9c:      	and	w9, w1, w9
     da0:      	str	q2, [sp, #0x4e0]
     da4:      	str	q5, [sp, #0x4d0]
     da8:      	add	x6, sp, #0x4d0
     dac:      	ldr	s3, [x6, x15, lsl #2]
     db0:      	tst	w9, #0x1
     db4:      	fcsel	s3, s3, s22, ne
     db8:      	fadd.4s	v2, v2, v3
     dbc:      	and	w15, w13, w1
     dc0:      	tst	w15, #0x1
     dc4:      	fcsel	s2, s2, s22, ne
     dc8:      	ands	w9, w13, #0x1
     dcc:      	fadd.4s	v3, v5, v4
     dd0:      	fadd	s2, s3, s2
     dd4:      	fcsel	s3, s2, s22, ne
     dd8:      	tst	w15, #0x1
     ddc:      	and	w6, w0, w13
     de0:      	fcsel	s4, s2, s22, ne
     de4:      	tst	w6, #0x1
     de8:      	and	w7, w16, w13
     dec:      	fcsel	s5, s2, s22, ne
     df0:      	tst	w7, #0x1
     df4:      	and	w30, w17, w13
     df8:      	fcsel	s6, s2, s22, ne
     dfc:      	tst	w30, #0x1
     e00:      	fcsel	s7, s2, s22, ne
     e04:      	and	w27, w11, w13
     e08:      	str	w27, [sp, #0x80]
     e0c:      	tst	w27, #0x1
     e10:      	fcsel	s16, s2, s22, ne
     e14:      	and	w27, w5, w13
     e18:      	str	w27, [sp, #0x90]
     e1c:      	tst	w27, #0x1
     e20:      	fcsel	s17, s2, s22, ne
     e24:      	and	w27, w2, w13
     e28:      	str	w27, [sp, #0xb0]
     e2c:      	tst	w27, #0x1
     e30:      	fcsel	s2, s2, s22, ne
     e34:      	mov.s	v3[1], v5[0]
     e38:      	mov.s	v3[2], v6[0]
     e3c:      	mov.s	v3[3], v7[0]
     e40:      	mov.s	v4[1], v16[0]
     e44:      	mov.s	v4[2], v17[0]
     e48:      	mov.s	v4[3], v2[0]
     e4c:      	rbit	w23, w23
     e50:      	clz	w23, w23
     e54:      	str	q4, [sp, #0x4c0]
     e58:      	str	q3, [sp, #0x4b0]
     e5c:      	str	x23, [sp, #0xa0]
     e60:      	and	x23, x23, #0x7
     e64:      	add	x27, sp, #0x4b0
     e68:      	ldr	s2, [x27, x23, lsl #2]
     e6c:      	str	q29, [sp, #0x70]
     e70:      	mov.b	v29[0], wzr
     e74:      	str	q29, [sp, #0x40]
     e78:      	fadd	s2, s2, s22
     e7c:      	mov	w23, #0x42820000        ; =1115815936
     e80:      	fmov	s3, w23
     e84:      	fdiv	s2, s2, s3
     e88:      	dup.4s	v3, v2[0]
     e8c:      	mov	w23, #0x1               ; =1
     e90:      	dup.2d	v2, x23
     e94:      	ushll2.2d	v4, v0, #0x0
     e98:      	and.16b	v18, v4, v2
     e9c:      	ushll2.2d	v4, v1, #0x0
     ea0:      	and.16b	v19, v4, v2
     ea4:      	ushll.2d	v4, v0, #0x0
     ea8:      	and.16b	v20, v4, v2
     eac:      	ushll.2d	v4, v1, #0x0
     eb0:      	and.16b	v21, v4, v2
     eb4:      	movi.2d	v4, #0000000000000000
     eb8:      	movi.2d	v5, #0000000000000000
     ebc:      	movi.2d	v6, #0000000000000000
     ec0:      	movi.2d	v17, #0000000000000000
     ec4:      	lsl	x4, x4, #5
     ec8:      	add	x23, x25, x4
     ecc:      	ldp	q7, q2, [x23]
     ed0:      	fsub.4s	v7, v7, v3
     ed4:      	fsub.4s	v2, v2, v3
     ed8:      	add	x4, x19, x4
     edc:      	ldp	q16, q22, [x4]
     ee0:      	bif.16b	v2, v22, v0
     ee4:      	bif.16b	v7, v16, v1
     ee8:      	stp	q7, q2, [x4]
     eec:      	add.2d	v5, v5, v19
     ef0:      	add.2d	v6, v6, v20
     ef4:      	add.2d	v17, v17, v18
     ef8:      	add.2d	v4, v4, v21
     efc:      	fmov	x4, d4
     f00:      	cmp	x4, #0x8
     f04:      	b.lt	0xec4 <_llm_rows.packet_batch.blocks+0xa1c>
     f08:      	fsub.4s	v4, v30, v3
     f0c:      	fsub.4s	v6, v31, v3
     f10:      	ldr	x4, [sp, #0x1b0]
     f14:      	add	x4, x19, x4
     f18:      	ldp	q2, q3, [x4]
     f1c:      	zip2.8b	v5, v26, v0
     f20:      	ushll.4s	v5, v5, #0x0
     f24:      	shl.4s	v5, v5, #0x1f
     f28:      	cmlt.4s	v5, v5, #0
     f2c:      	stp	q6, q4, [sp, #0x50]
     f30:      	bit.16b	v3, v6, v5
     f34:      	zip1.8b	v5, v26, v0
     f38:      	ushll.4s	v5, v5, #0x0
     f3c:      	shl.4s	v5, v5, #0x1f
     f40:      	cmlt.4s	v5, v5, #0
     f44:      	bit.16b	v2, v4, v5
     f48:      	stp	q2, q3, [x4]
     f4c:      	ldr	q2, [sp, #0x950]
     f50:      	ldr	q3, [sp, #0x940]
     f54:      	fmul.4s	v3, v3, v3
     f58:      	fmul.4s	v2, v2, v2
     f5c:      	and.16b	v31, v0, v2
     f60:      	and.16b	v15, v1, v3
     f64:      	ldr	q2, [sp, #0x930]
     f68:      	ldr	q3, [sp, #0x920]
     f6c:      	fmul.4s	v3, v3, v3
     f70:      	fmul.4s	v2, v2, v2
     f74:      	and.16b	v17, v0, v2
     f78:      	and.16b	v8, v1, v3
     f7c:      	ldr	q2, [sp, #0x910]
     f80:      	ldr	q3, [sp, #0x900]
     f84:      	fmul.4s	v3, v3, v3
     f88:      	fmul.4s	v2, v2, v2
     f8c:      	and.16b	v5, v0, v2
     f90:      	and.16b	v6, v1, v3
     f94:      	add	x3, x19, x3
     f98:      	ldp	q3, q2, [x3]
     f9c:      	fmul.4s	v7, v3, v3
     fa0:      	fmul.4s	v2, v2, v2
     fa4:      	and.16b	v3, v0, v2
     fa8:      	and.16b	v23, v1, v7
     fac:      	sshll.2d	v2, v1, #0x0
     fb0:      	sshll.2d	v7, v0, #0x0
     fb4:      	add	x14, x19, x14, lsl #5
     fb8:      	ldp	q22, q16, [x14]
     fbc:      	and.16b	v22, v1, v22
     fc0:      	and.16b	v16, v0, v16
     fc4:      	fmul.4s	v16, v16, v16
     fc8:      	fmul.4s	v22, v22, v22
     fcc:      	fadd.4s	v22, v23, v22
     fd0:      	fadd.4s	v26, v3, v16
     fd4:      	ldp	q28, q16, [x14, #0x20]
     fd8:      	and.16b	v28, v1, v28
     fdc:      	and.16b	v16, v0, v16
     fe0:      	fmul.4s	v16, v16, v16
     fe4:      	fmul.4s	v28, v28, v28
     fe8:      	fadd.4s	v28, v6, v28
     fec:      	fadd.4s	v16, v5, v16
     ff0:      	ldp	q10, q9, [x14, #0x40]
     ff4:      	and.16b	v10, v1, v10
     ff8:      	and.16b	v9, v0, v9
     ffc:      	fmul.4s	v9, v9, v9
    1000:      	fmul.4s	v10, v10, v10
    1004:      	fadd.4s	v10, v8, v10
    1008:      	fadd.4s	v9, v17, v9
    100c:      	ldp	q4, q30, [x14, #0x60]
    1010:      	and.16b	v4, v1, v4
    1014:      	and.16b	v30, v0, v30
    1018:      	fmul.4s	v30, v30, v30
    101c:      	fmul.4s	v4, v4, v4
    1020:      	fadd.4s	v4, v15, v4
    1024:      	fadd.4s	v30, v31, v30
    1028:      	dup.2d	v14, x28
    102c:      	and.16b	v29, v25, v14
    1030:      	add.2d	v27, v27, v29
    1034:      	and.16b	v29, v24, v14
    1038:      	add.2d	v11, v11, v29
    103c:      	and.16b	v7, v7, v14
    1040:      	add.2d	v12, v12, v7
    1044:      	and.16b	v2, v2, v14
    1048:      	add.2d	v13, v13, v2
    104c:      	bit.16b	v3, v26, v0
    1050:      	bit.16b	v23, v22, v1
    1054:      	bit.16b	v5, v16, v0
    1058:      	bit.16b	v6, v28, v1
    105c:      	bit.16b	v17, v9, v0
    1060:      	bit.16b	v8, v10, v1
    1064:      	bit.16b	v31, v30, v0
    1068:      	bit.16b	v15, v4, v1
    106c:      	fmov	x14, d13
    1070:      	cmp	x14, #0x8
    1074:      	b.lt	0xfac <_llm_rows.packet_batch.blocks+0xb04>
    1078:      	mov	x14, #0x0               ; =0
    107c:      	movi.2d	v24, #0000000000000000
    1080:      	movi.2d	v25, #0000000000000000
    1084:      	movi.2d	v10, #0000000000000000
    1088:      	movi.2d	v11, #0000000000000000
    108c:      	ldr	q9, [sp, #0x170]
    1090:      	ldr	q28, [sp, #0x1a0]
    1094:      	b	0x10c8 <_llm_rows.packet_batch.blocks+0xc20>
    1098:      	add	x14, x21, x14
    109c:      	ldp	q2, q4, [x14]
    10a0:      	bit.16b	v4, v13, v0
    10a4:      	bit.16b	v2, v12, v1
    10a8:      	stp	q2, q4, [x14]
    10ac:      	add.2d	v25, v25, v19
    10b0:      	add.2d	v10, v10, v20
    10b4:      	add.2d	v11, v11, v18
    10b8:      	add.2d	v24, v24, v21
    10bc:      	fmov	x14, d24
    10c0:      	cmp	x14, #0x8
    10c4:      	b.ge	0x1164 <_llm_rows.packet_batch.blocks+0xcbc>
    10c8:      	fmov	w4, s9
    10cc:      	lsl	x14, x14, #5
    10d0:      	add	x3, x12, x14
    10d4:      	movi.2d	v12, #0000000000000000
    10d8:      	movi.2d	v13, #0000000000000000
    10dc:      	tbnz	w4, #0x0, 0x1104 <_llm_rows.packet_batch.blocks+0xc5c>
    10e0:      	and	w4, w4, #0xff
    10e4:      	tbnz	w4, #0x1, 0x1110 <_llm_rows.packet_batch.blocks+0xc68>
    10e8:      	tbnz	w4, #0x2, 0x111c <_llm_rows.packet_batch.blocks+0xc74>
    10ec:      	tbnz	w4, #0x3, 0x1128 <_llm_rows.packet_batch.blocks+0xc80>
    10f0:      	tbnz	w4, #0x4, 0x1134 <_llm_rows.packet_batch.blocks+0xc8c>
    10f4:      	tbnz	w4, #0x5, 0x1140 <_llm_rows.packet_batch.blocks+0xc98>
    10f8:      	tbnz	w4, #0x6, 0x114c <_llm_rows.packet_batch.blocks+0xca4>
    10fc:      	tbz	w4, #0x7, 0x1098 <_llm_rows.packet_batch.blocks+0xbf0>
    1100:      	b	0x1158 <_llm_rows.packet_batch.blocks+0xcb0>
    1104:      	ldr	s12, [x3]
    1108:      	and	w4, w4, #0xff
    110c:      	tbz	w4, #0x1, 0x10e8 <_llm_rows.packet_batch.blocks+0xc40>
    1110:      	add	x23, x3, #0x4
    1114:      	ld1.s	{ v12 }[1], [x23]
    1118:      	tbz	w4, #0x2, 0x10ec <_llm_rows.packet_batch.blocks+0xc44>
    111c:      	add	x23, x3, #0x8
    1120:      	ld1.s	{ v12 }[2], [x23]
    1124:      	tbz	w4, #0x3, 0x10f0 <_llm_rows.packet_batch.blocks+0xc48>
    1128:      	add	x23, x3, #0xc
    112c:      	ld1.s	{ v12 }[3], [x23]
    1130:      	tbz	w4, #0x4, 0x10f4 <_llm_rows.packet_batch.blocks+0xc4c>
    1134:      	add	x23, x3, #0x10
    1138:      	ld1.s	{ v13 }[0], [x23]
    113c:      	tbz	w4, #0x5, 0x10f8 <_llm_rows.packet_batch.blocks+0xc50>
    1140:      	add	x23, x3, #0x14
    1144:      	ld1.s	{ v13 }[1], [x23]
    1148:      	tbz	w4, #0x6, 0x10fc <_llm_rows.packet_batch.blocks+0xc54>
    114c:      	add	x23, x3, #0x18
    1150:      	ld1.s	{ v13 }[2], [x23]
    1154:      	tbz	w4, #0x7, 0x1098 <_llm_rows.packet_batch.blocks+0xbf0>
    1158:      	add	x3, x3, #0x1c
    115c:      	ld1.s	{ v13 }[3], [x3]
    1160:      	b	0x1098 <_llm_rows.packet_batch.blocks+0xbf0>
    1164:      	zip2.8b	v2, v28, v0
    1168:      	ushll.4s	v2, v2, #0x0
    116c:      	shl.4s	v2, v2, #0x1f
    1170:      	cmlt.4s	v2, v2, #0
    1174:      	ldp	q7, q4, [sp, #0x40]
    1178:      	and.16b	v24, v2, v4
    117c:      	fmul.4s	v4, v24, v24
    1180:      	fadd.4s	v3, v4, v3
    1184:      	and.16b	v2, v2, v3
    1188:      	zip2.8b	v3, v7, v0
    118c:      	ushll.4s	v3, v3, #0x0
    1190:      	shl.4s	v3, v3, #0x1f
    1194:      	cmlt.4s	v3, v3, #0
    1198:      	bit.16b	v2, v26, v3
    119c:      	zip1.8b	v3, v28, v0
    11a0:      	ushll.4s	v3, v3, #0x0
    11a4:      	shl.4s	v3, v3, #0x1f
    11a8:      	cmlt.4s	v3, v3, #0
    11ac:      	ldr	q4, [sp, #0x60]
    11b0:      	and.16b	v25, v3, v4
    11b4:      	fmul.4s	v4, v25, v25
    11b8:      	fadd.4s	v4, v4, v23
    11bc:      	and.16b	v3, v3, v4
    11c0:      	zip1.8b	v4, v7, v0
    11c4:      	ushll.4s	v4, v4, #0x0
    11c8:      	shl.4s	v4, v4, #0x1f
    11cc:      	cmlt.4s	v4, v4, #0
    11d0:      	bit.16b	v3, v22, v4
    11d4:      	fadd.4s	v3, v6, v3
    11d8:      	fadd.4s	v2, v5, v2
    11dc:      	adrp	x14, 0x1000 <_llm_rows.packet_batch.blocks+0xb58>
    11e0:      	ldr	q4, [x14]
    11e4:      	and.16b	v23, v0, v4
    11e8:      	fadd.4s	v2, v17, v2
    11ec:      	adrp	x14, 0x1000 <_llm_rows.packet_batch.blocks+0xb58>
    11f0:      	ldr	q4, [x14]
    11f4:      	and.16b	v7, v1, v4
    11f8:      	fadd.4s	v3, v8, v3
    11fc:      	fadd.4s	v3, v15, v3
    1200:      	fadd.4s	v4, v31, v2
    1204:      	fmov	w14, s7
    1208:      	add	x3, sp, #0x218
    120c:      	bfxil	x3, x14, #0, #3
    1210:      	ldr	q2, [sp, #0x70]
    1214:      	str	d2, [sp, #0x218]
    1218:      	ldrb	w3, [x3]
    121c:      	add	x4, sp, #0x480
    1220:      	orr	x14, x4, x14, lsl #2
    1224:      	str	q4, [sp, #0x490]
    1228:      	str	q3, [sp, #0x480]
    122c:      	ldr	s2, [x14]
    1230:      	tst	w9, w3
    1234:      	movi	d16, #0000000000000000
    1238:      	fcsel	s5, s2, s16, ne
    123c:      	mov.s	w14, v7[1]
    1240:      	add	x3, sp, #0x218
    1244:      	bfxil	x3, x14, #0, #3
    1248:      	ldrb	w14, [x3]
    124c:      	and	w14, w0, w14
    1250:      	str	q3, [sp, #0x460]
    1254:      	ldr	s2, [sp, #0x460]
    1258:      	tst	w14, #0x1
    125c:      	fcsel	s6, s2, s16, ne
    1260:      	mov.s	w14, v7[2]
    1264:      	add	x3, sp, #0x440
    1268:      	orr	x3, x3, x14, lsl #2
    126c:      	add	x4, sp, #0x218
    1270:      	bfxil	x4, x14, #0, #3
    1274:      	ldrb	w14, [x4]
    1278:      	and	w14, w16, w14
    127c:      	str	q4, [sp, #0x450]
    1280:      	str	q3, [sp, #0x440]
    1284:      	ldr	s2, [x3]
    1288:      	tst	w14, #0x1
    128c:      	fcsel	s17, s2, s16, ne
    1290:      	mov.s	w14, v7[3]
    1294:      	add	x3, sp, #0x420
    1298:      	orr	x3, x3, x14, lsl #2
    129c:      	add	x4, sp, #0x218
    12a0:      	bfxil	x4, x14, #0, #3
    12a4:      	ldrb	w14, [x4]
    12a8:      	and	w14, w17, w14
    12ac:      	str	q4, [sp, #0x430]
    12b0:      	str	q3, [sp, #0x420]
    12b4:      	ldr	s2, [x3]
    12b8:      	tst	w14, #0x1
    12bc:      	fcsel	s22, s2, s16, ne
    12c0:      	fmov	w14, s23
    12c4:      	add	x3, sp, #0x218
    12c8:      	bfxil	x3, x14, #0, #3
    12cc:      	ldrb	w3, [x3]
    12d0:      	str	q4, [sp, #0x410]
    12d4:      	str	q3, [sp, #0x400]
    12d8:      	add	x4, sp, #0x400
    12dc:      	ldr	s2, [x4, w14, uxtw #2]
    12e0:      	and	w14, w1, w3
    12e4:      	tst	w14, #0x1
    12e8:      	mov.s	w14, v23[1]
    12ec:      	add	x3, sp, #0x218
    12f0:      	bfxil	x3, x14, #0, #3
    12f4:      	ldrb	w3, [x3]
    12f8:      	mov.s	w4, v23[2]
    12fc:      	mov.s	w23, v23[3]
    1300:      	stp	q3, q4, [sp, #0x3e0]
    1304:      	add	x27, sp, #0x3e0
    1308:      	ldr	s7, [x27, w14, uxtw #2]
    130c:      	fcsel	s2, s2, s16, ne
    1310:      	and	w14, w11, w3
    1314:      	tst	w14, #0x1
    1318:      	fcsel	s7, s7, s16, ne
    131c:      	add	x14, sp, #0x218
    1320:      	bfxil	x14, x4, #0, #3
    1324:      	ldrb	w14, [x14]
    1328:      	stp	q3, q4, [sp, #0x3c0]
    132c:      	mov.s	v2[1], v7[0]
    1330:      	add	x3, sp, #0x3c0
    1334:      	ldr	s7, [x3, w4, uxtw #2]
    1338:      	and	w14, w5, w14
    133c:      	tst	w14, #0x1
    1340:      	fcsel	s7, s7, s16, ne
    1344:      	add	x14, sp, #0x218
    1348:      	bfxil	x14, x23, #0, #3
    134c:      	ldrb	w14, [x14]
    1350:      	and	w14, w2, w14
    1354:      	stp	q3, q4, [sp, #0x3a0]
    1358:      	mov.s	v2[2], v7[0]
    135c:      	add	x3, sp, #0x3a0
    1360:      	ldr	s7, [x3, w23, uxtw #2]
    1364:      	tst	w14, #0x1
    1368:      	fcsel	s7, s7, s16, ne
    136c:      	mov.s	v2[3], v7[0]
    1370:      	adrp	x14, 0x1000 <_llm_rows.packet_batch.blocks+0xb58>
    1374:      	ldr	q7, [x14]
    1378:      	mov.s	v5[1], v6[0]
    137c:      	and.16b	v7, v1, v7
    1380:      	mov.s	v5[2], v17[0]
    1384:      	mov.s	v5[3], v22[0]
    1388:      	fadd.4s	v3, v3, v5
    138c:      	fadd.4s	v4, v4, v2
    1390:      	fmov	w14, s7
    1394:      	add	x3, sp, #0x218
    1398:      	bfxil	x3, x14, #0, #3
    139c:      	ldrb	w3, [x3]
    13a0:      	add	x4, sp, #0x380
    13a4:      	orr	x14, x4, x14, lsl #2
    13a8:      	stp	q3, q4, [sp, #0x380]
    13ac:      	ldr	s2, [x14]
    13b0:      	tst	w9, w3
    13b4:      	mov.s	w14, v7[1]
    13b8:      	add	x3, sp, #0x218
    13bc:      	bfxil	x3, x14, #0, #3
    13c0:      	ldrb	w3, [x3]
    13c4:      	and	w0, w0, w3
    13c8:      	fcsel	s5, s2, s16, ne
    13cc:      	add	x3, sp, #0x360
    13d0:      	orr	x14, x3, x14, lsl #2
    13d4:      	stp	q3, q4, [sp, #0x360]
    13d8:      	ldr	s2, [x14]
    13dc:      	tst	w0, #0x1
    13e0:      	mov.s	w14, v7[2]
    13e4:      	add	x0, sp, #0x218
    13e8:      	bfxil	x0, x14, #0, #3
    13ec:      	fcsel	s6, s2, s16, ne
    13f0:      	ldrb	w14, [x0]
    13f4:      	and	w14, w16, w14
    13f8:      	str	q3, [sp, #0x340]
    13fc:      	tst	w14, #0x1
    1400:      	mov.s	w14, v7[3]
    1404:      	add	x16, sp, #0x218
    1408:      	bfxil	x16, x14, #0, #3
    140c:      	ldrb	w16, [x16]
    1410:      	and	w16, w17, w16
    1414:      	adrp	x17, 0x1000 <_llm_rows.packet_batch.blocks+0xb58>
    1418:      	ldr	q2, [x17]
    141c:      	and.16b	v2, v0, v2
    1420:      	ldr	s7, [sp, #0x340]
    1424:      	fcsel	s17, s7, s16, ne
    1428:      	add	x17, sp, #0x320
    142c:      	orr	x14, x17, x14, lsl #2
    1430:      	stp	q3, q4, [sp, #0x320]
    1434:      	ldr	s7, [x14]
    1438:      	tst	w16, #0x1
    143c:      	fcsel	s22, s7, s16, ne
    1440:      	fmov	w14, s2
    1444:      	add	x16, sp, #0x218
    1448:      	bfxil	x16, x14, #0, #3
    144c:      	ldrb	w16, [x16]
    1450:      	and	w16, w1, w16
    1454:      	stp	q3, q4, [sp, #0x300]
    1458:      	add	x17, sp, #0x300
    145c:      	ldr	s7, [x17, w14, uxtw #2]
    1460:      	tst	w16, #0x1
    1464:      	mov.s	w14, v2[1]
    1468:      	add	x16, sp, #0x218
    146c:      	bfxil	x16, x14, #0, #3
    1470:      	ldrb	w16, [x16]
    1474:      	and	w11, w11, w16
    1478:      	mov.s	w16, v2[2]
    147c:      	stp	q3, q4, [sp, #0x2e0]
    1480:      	mov.s	w17, v2[3]
    1484:      	add	x0, sp, #0x2e0
    1488:      	ldr	s2, [x0, w14, uxtw #2]
    148c:      	fcsel	s7, s7, s16, ne
    1490:      	tst	w11, #0x1
    1494:      	add	x11, sp, #0x218
    1498:      	bfxil	x11, x16, #0, #3
    149c:      	ldrb	w11, [x11]
    14a0:      	and	w11, w5, w11
    14a4:      	fcsel	s2, s2, s16, ne
    14a8:      	stp	q3, q4, [sp, #0x2c0]
    14ac:      	mov.s	v7[1], v2[0]
    14b0:      	add	x14, sp, #0x2c0
    14b4:      	ldr	s2, [x14, w16, uxtw #2]
    14b8:      	tst	w11, #0x1
    14bc:      	add	x11, sp, #0x218
    14c0:      	bfxil	x11, x17, #0, #3
    14c4:      	ldrb	w11, [x11]
    14c8:      	and	w11, w2, w11
    14cc:      	fcsel	s2, s2, s16, ne
    14d0:      	stp	q3, q4, [sp, #0x2a0]
    14d4:      	mov.s	v7[2], v2[0]
    14d8:      	add	x14, sp, #0x2a0
    14dc:      	ldr	s2, [x14, w17, uxtw #2]
    14e0:      	tst	w11, #0x1
    14e4:      	fcsel	s2, s2, s16, ne
    14e8:      	mov.s	v7[3], v2[0]
    14ec:      	mov.s	v5[1], v6[0]
    14f0:      	mov.s	v5[2], v17[0]
    14f4:      	mov.s	v5[3], v22[0]
    14f8:      	movi.4s	v2, #0x4
    14fc:      	and.16b	v2, v1, v2
    1500:      	fmov	w11, s2
    1504:      	add	x14, sp, #0x218
    1508:      	orr	x14, x14, x11
    150c:      	ldrb	w14, [x14]
    1510:      	tst	w9, w14
    1514:      	fadd.4s	v2, v3, v5
    1518:      	fadd.4s	v3, v4, v7
    151c:      	stp	q2, q3, [sp, #0x280]
    1520:      	add	x9, sp, #0x280
    1524:      	ldr	s3, [x9, w11, uxtw #2]
    1528:      	fcsel	s3, s3, s16, ne
    152c:      	tst	w13, #0x1
    1530:      	fadd	s2, s2, s3
    1534:      	fcsel	s3, s2, s16, ne
    1538:      	tst	w6, #0x1
    153c:      	fcsel	s4, s2, s16, ne
    1540:      	tst	w7, #0x1
    1544:      	fcsel	s5, s2, s16, ne
    1548:      	tst	w30, #0x1
    154c:      	mov.s	v3[1], v4[0]
    1550:      	fcsel	s4, s2, s16, ne
    1554:      	mov.s	v3[2], v5[0]
    1558:      	tst	w15, #0x1
    155c:      	fcsel	s5, s2, s16, ne
    1560:      	ldr	w9, [sp, #0x80]
    1564:      	tst	w9, #0x1
    1568:      	mov.s	v3[3], v4[0]
    156c:      	fcsel	s4, s2, s16, ne
    1570:      	ldr	w9, [sp, #0x90]
    1574:      	tst	w9, #0x1
    1578:      	mov.s	v5[1], v4[0]
    157c:      	fcsel	s4, s2, s16, ne
    1580:      	mov.s	v5[2], v4[0]
    1584:      	ldr	w9, [sp, #0xb0]
    1588:      	tst	w9, #0x1
    158c:      	movi	d17, #0000000000000000
    1590:      	fcsel	s2, s2, s16, ne
    1594:      	mov.s	v5[3], v2[0]
    1598:      	shl.8b	v2, v28, #0x7
    159c:      	cmlt.8b	v2, v2, #0
    15a0:      	ldr	d4, [sp, #0xf8]
    15a4:      	and.8b	v2, v2, v4
    15a8:      	stp	q3, q5, [sp, #0x260]
    15ac:      	mov	b3, v28[0]
    15b0:      	mov.b	v3[4], v28[1]
    15b4:      	ldr	x9, [sp, #0xa0]
    15b8:      	and	x9, x9, #0x7
    15bc:      	ushll.2d	v3, v3, #0x0
    15c0:      	shl.2d	v3, v3, #0x3f
    15c4:      	cmlt.2d	v3, v3, #0
    15c8:      	ldr	q4, [sp, #0x100]
    15cc:      	and.16b	v4, v3, v4
    15d0:      	mov	b3, v28[2]
    15d4:      	mov.b	v3[4], v28[3]
    15d8:      	ushll.2d	v3, v3, #0x0
    15dc:      	shl.2d	v3, v3, #0x3f
    15e0:      	cmlt.2d	v3, v3, #0
    15e4:      	ldp	q5, q6, [sp, #0xc0]
    15e8:      	and.16b	v5, v3, v5
    15ec:      	mov	b3, v28[4]
    15f0:      	mov.b	v3[4], v28[5]
    15f4:      	ushll.2d	v3, v3, #0x0
    15f8:      	shl.2d	v3, v3, #0x3f
    15fc:      	cmlt.2d	v3, v3, #0
    1600:      	and.16b	v6, v3, v6
    1604:      	mov	b3, v28[6]
    1608:      	mov.b	v3[4], v28[7]
    160c:      	ushll.2d	v3, v3, #0x0
    1610:      	shl.2d	v3, v3, #0x3f
    1614:      	cmlt.2d	v3, v3, #0
    1618:      	ldr	q7, [sp, #0xe0]
    161c:      	and.16b	v7, v3, v7
    1620:      	add	x11, sp, #0x260
    1624:      	ldr	s3, [x11, x9, lsl #2]
    1628:      	stp	q6, q7, [sp, #0x240]
    162c:      	addv.8b	b22, v2
    1630:      	stp	q4, q5, [sp, #0x220]
    1634:      	ldr	x16, [sp, #0x168]
    1638:      	and	x9, x16, #0x7
    163c:      	add	x11, sp, #0x220
    1640:      	ldr	x9, [x11, x9, lsl #3]
    1644:      	fmov	w11, s22
    1648:      	sub	x9, x9, x16
    164c:      	lsl	x9, x9, #2
    1650:      	add	x12, x12, x9
    1654:      	movi.2d	v23, #0000000000000000
    1658:      	movi.2d	v26, #0000000000000000
    165c:      	tbnz	w11, #0x0, 0x1a80 <_llm_rows.packet_batch.blocks+0x15d8>
    1660:      	ldr	w0, [sp, #0x188]
    1664:      	movi.2s	v8, #0x41
    1668:      	add	x15, sp, #0x6a0
    166c:      	ldr	q31, [sp, #0x190]
    1670:      	tbnz	w11, #0x1, 0x1a98 <_llm_rows.packet_batch.blocks+0x15f0>
    1674:      	tbnz	w11, #0x2, 0x1aa4 <_llm_rows.packet_batch.blocks+0x15fc>
    1678:      	tbnz	w11, #0x3, 0x1ab0 <_llm_rows.packet_batch.blocks+0x1608>
    167c:      	tbnz	w11, #0x4, 0x1abc <_llm_rows.packet_batch.blocks+0x1614>
    1680:      	tbnz	w11, #0x5, 0x1ac8 <_llm_rows.packet_batch.blocks+0x1620>
    1684:      	tbnz	w11, #0x6, 0x1ad4 <_llm_rows.packet_batch.blocks+0x162c>
    1688:      	tbz	w11, #0x7, 0x1694 <_llm_rows.packet_batch.blocks+0x11ec>
    168c:      	add	x11, x12, #0x1c
    1690:      	ld1.s	{ v26 }[3], [x11]
    1694:      	fadd	s2, s3, s17
    1698:      	mov	w11, #0x42820000        ; =1115815936
    169c:      	fmov	s3, w11
    16a0:      	fdiv	s2, s2, s3
    16a4:      	ldr	x11, [sp, #0x1b0]
    16a8:      	add	x11, x21, x11
    16ac:      	ldp	q3, q4, [x11]
    16b0:      	zip2.8b	v5, v28, v0
    16b4:      	ushll.4s	v5, v5, #0x0
    16b8:      	shl.4s	v5, v5, #0x1f
    16bc:      	cmlt.4s	v5, v5, #0
    16c0:      	bit.16b	v4, v26, v5
    16c4:      	zip1.8b	v5, v28, v0
    16c8:      	ushll.4s	v5, v5, #0x0
    16cc:      	shl.4s	v5, v5, #0x1f
    16d0:      	cmlt.4s	v5, v5, #0
    16d4:      	bit.16b	v3, v23, v5
    16d8:      	stp	q3, q4, [x11]
    16dc:      	mov	w11, #0xc5ac            ; =50604
    16e0:      	movk	w11, #0x3727, lsl #16
    16e4:      	fmov	s3, w11
    16e8:      	fadd	s2, s2, s3
    16ec:      	fsqrt	s17, s2
    16f0:      	sub	x11, x10, x8
    16f4:      	lsr	x12, x11, #2
    16f8:      	subs	x11, x8, x10
    16fc:      	mov	w13, #0x103             ; =259
    1700:      	ccmp	x11, x13, #0x0, hs
    1704:      	cset	w11, hi
    1708:      	cmp	x12, #0x450
    170c:      	ccmp	x10, x8, #0x0, hi
    1710:      	b.hs	0x17fc <_llm_rows.packet_batch.blocks+0x1354>
    1714:      	tbnz	w11, #0x0, 0x17fc <_llm_rows.packet_batch.blocks+0x1354>
    1718:      	mov	x11, #0x0               ; =0
    171c:      	movi.2d	v3, #0000000000000000
    1720:      	movi.2d	v4, #0000000000000000
    1724:      	movi.2d	v5, #0000000000000000
    1728:      	movi.2d	v6, #0000000000000000
    172c:      	b	0x1760 <_llm_rows.packet_batch.blocks+0x12b8>
    1730:      	add	x11, x15, x11
    1734:      	ldp	q2, q7, [x11]
    1738:      	bit.16b	v7, v27, v0
    173c:      	bit.16b	v2, v16, v1
    1740:      	stp	q2, q7, [x11]
    1744:      	add.2d	v4, v4, v19
    1748:      	add.2d	v5, v5, v20
    174c:      	add.2d	v6, v6, v18
    1750:      	add.2d	v3, v3, v21
    1754:      	fmov	x11, d3
    1758:      	cmp	x11, #0x8
    175c:      	b.ge	0x1ae4 <_llm_rows.packet_batch.blocks+0x163c>
    1760:      	fmov	w13, s9
    1764:      	lsl	x11, x11, #5
    1768:      	add	x12, x10, x11
    176c:      	movi.2d	v16, #0000000000000000
    1770:      	movi.2d	v27, #0000000000000000
    1774:      	tbnz	w13, #0x0, 0x179c <_llm_rows.packet_batch.blocks+0x12f4>
    1778:      	and	w13, w13, #0xff
    177c:      	tbnz	w13, #0x1, 0x17a8 <_llm_rows.packet_batch.blocks+0x1300>
    1780:      	tbnz	w13, #0x2, 0x17b4 <_llm_rows.packet_batch.blocks+0x130c>
    1784:      	tbnz	w13, #0x3, 0x17c0 <_llm_rows.packet_batch.blocks+0x1318>
    1788:      	tbnz	w13, #0x4, 0x17cc <_llm_rows.packet_batch.blocks+0x1324>
    178c:      	tbnz	w13, #0x5, 0x17d8 <_llm_rows.packet_batch.blocks+0x1330>
    1790:      	tbnz	w13, #0x6, 0x17e4 <_llm_rows.packet_batch.blocks+0x133c>
    1794:      	tbz	w13, #0x7, 0x1730 <_llm_rows.packet_batch.blocks+0x1288>
    1798:      	b	0x17f0 <_llm_rows.packet_batch.blocks+0x1348>
    179c:      	ldr	s16, [x12]
    17a0:      	and	w13, w13, #0xff
    17a4:      	tbz	w13, #0x1, 0x1780 <_llm_rows.packet_batch.blocks+0x12d8>
    17a8:      	add	x14, x12, #0x4
    17ac:      	ld1.s	{ v16 }[1], [x14]
    17b0:      	tbz	w13, #0x2, 0x1784 <_llm_rows.packet_batch.blocks+0x12dc>
    17b4:      	add	x14, x12, #0x8
    17b8:      	ld1.s	{ v16 }[2], [x14]
    17bc:      	tbz	w13, #0x3, 0x1788 <_llm_rows.packet_batch.blocks+0x12e0>
    17c0:      	add	x14, x12, #0xc
    17c4:      	ld1.s	{ v16 }[3], [x14]
    17c8:      	tbz	w13, #0x4, 0x178c <_llm_rows.packet_batch.blocks+0x12e4>
    17cc:      	add	x14, x12, #0x10
    17d0:      	ld1.s	{ v27 }[0], [x14]
    17d4:      	tbz	w13, #0x5, 0x1790 <_llm_rows.packet_batch.blocks+0x12e8>
    17d8:      	add	x14, x12, #0x14
    17dc:      	ld1.s	{ v27 }[1], [x14]
    17e0:      	tbz	w13, #0x6, 0x1794 <_llm_rows.packet_batch.blocks+0x12ec>
    17e4:      	add	x14, x12, #0x18
    17e8:      	ld1.s	{ v27 }[2], [x14]
    17ec:      	tbz	w13, #0x7, 0x1730 <_llm_rows.packet_batch.blocks+0x1288>
    17f0:      	add	x12, x12, #0x1c
    17f4:      	ld1.s	{ v27 }[3], [x12]
    17f8:      	b	0x1730 <_llm_rows.packet_batch.blocks+0x1288>
    17fc:      	mov	x11, #0x0               ; =0
    1800:      	ldr	q2, [sp, #0x110]
    1804:      	add.2d	v3, v2, v31
    1808:      	dup.4s	v7, v17[0]
    180c:      	movi.2d	v4, #0000000000000000
    1810:      	movi.2d	v5, #0000000000000000
    1814:      	movi.2d	v6, #0000000000000000
    1818:      	movi.2d	v17, #0000000000000000
    181c:      	b	0x183c <_llm_rows.packet_batch.blocks+0x1394>
    1820:      	add.2d	v5, v5, v19
    1824:      	add.2d	v6, v6, v20
    1828:      	add.2d	v17, v17, v18
    182c:      	add.2d	v4, v4, v21
    1830:      	fmov	x11, d4
    1834:      	cmp	x11, #0x8
    1838:      	b.ge	0x19d0 <_llm_rows.packet_batch.blocks+0x1528>
    183c:      	fmov	w13, s9
    1840:      	shl.2d	v28, v4, #0x3
    1844:      	orr.16b	v2, v28, v31
    1848:      	fmov	x12, d2
    184c:      	add	x12, x10, x12, lsl #2
    1850:      	movi.2d	v29, #0000000000000000
    1854:      	movi.2d	v27, #0000000000000000
    1858:      	tbnz	w13, #0x0, 0x1900 <_llm_rows.packet_batch.blocks+0x1458>
    185c:      	and	w13, w13, #0xff
    1860:      	tbnz	w13, #0x1, 0x190c <_llm_rows.packet_batch.blocks+0x1464>
    1864:      	tbnz	w13, #0x2, 0x1918 <_llm_rows.packet_batch.blocks+0x1470>
    1868:      	tbnz	w13, #0x3, 0x1924 <_llm_rows.packet_batch.blocks+0x147c>
    186c:      	tbnz	w13, #0x4, 0x1930 <_llm_rows.packet_batch.blocks+0x1488>
    1870:      	tbnz	w13, #0x5, 0x193c <_llm_rows.packet_batch.blocks+0x1494>
    1874:      	tbnz	w13, #0x6, 0x1948 <_llm_rows.packet_batch.blocks+0x14a0>
    1878:      	tbz	w13, #0x7, 0x1884 <_llm_rows.packet_batch.blocks+0x13dc>
    187c:      	add	x12, x12, #0x1c
    1880:      	ld1.s	{ v27 }[3], [x12]
    1884:      	lsl	x11, x11, #5
    1888:      	add	x13, x19, x11
    188c:      	ldr	q2, [x13]
    1890:      	and.16b	v2, v1, v2
    1894:      	fdiv.4s	v2, v2, v7
    1898:      	add	x14, x21, x11
    189c:      	ldr	q16, [x14]
    18a0:      	and.16b	v16, v1, v16
    18a4:      	fmul.4s	v2, v2, v16
    18a8:      	fmov	w12, s9
    18ac:      	fadd.4s	v29, v29, v2
    18b0:      	add.2d	v2, v3, v28
    18b4:      	fmov	x11, d2
    18b8:      	add	x11, x8, x11, lsl #2
    18bc:      	tbnz	w12, #0x0, 0x1958 <_llm_rows.packet_batch.blocks+0x14b0>
    18c0:      	and	w12, w12, #0xff
    18c4:      	tbnz	w12, #0x1, 0x1964 <_llm_rows.packet_batch.blocks+0x14bc>
    18c8:      	ldr	q30, [x13, #0x10]
    18cc:      	ldr	q28, [x14, #0x10]
    18d0:      	tbnz	w12, #0x2, 0x1978 <_llm_rows.packet_batch.blocks+0x14d0>
    18d4:      	tbnz	w12, #0x3, 0x1984 <_llm_rows.packet_batch.blocks+0x14dc>
    18d8:      	and.16b	v2, v0, v30
    18dc:      	fdiv.4s	v2, v2, v7
    18e0:      	and.16b	v16, v0, v28
    18e4:      	fmul.4s	v2, v2, v16
    18e8:      	fadd.4s	v27, v27, v2
    18ec:      	tbnz	w12, #0x4, 0x19a4 <_llm_rows.packet_batch.blocks+0x14fc>
    18f0:      	tbnz	w12, #0x5, 0x19ac <_llm_rows.packet_batch.blocks+0x1504>
    18f4:      	tbnz	w12, #0x6, 0x19b8 <_llm_rows.packet_batch.blocks+0x1510>
    18f8:      	tbz	w12, #0x7, 0x1820 <_llm_rows.packet_batch.blocks+0x1378>
    18fc:      	b	0x19c4 <_llm_rows.packet_batch.blocks+0x151c>
    1900:      	ldr	s29, [x12]
    1904:      	and	w13, w13, #0xff
    1908:      	tbz	w13, #0x1, 0x1864 <_llm_rows.packet_batch.blocks+0x13bc>
    190c:      	add	x14, x12, #0x4
    1910:      	ld1.s	{ v29 }[1], [x14]
    1914:      	tbz	w13, #0x2, 0x1868 <_llm_rows.packet_batch.blocks+0x13c0>
    1918:      	add	x14, x12, #0x8
    191c:      	ld1.s	{ v29 }[2], [x14]
    1920:      	tbz	w13, #0x3, 0x186c <_llm_rows.packet_batch.blocks+0x13c4>
    1924:      	add	x14, x12, #0xc
    1928:      	ld1.s	{ v29 }[3], [x14]
    192c:      	tbz	w13, #0x4, 0x1870 <_llm_rows.packet_batch.blocks+0x13c8>
    1930:      	add	x14, x12, #0x10
    1934:      	ld1.s	{ v27 }[0], [x14]
    1938:      	tbz	w13, #0x5, 0x1874 <_llm_rows.packet_batch.blocks+0x13cc>
    193c:      	add	x14, x12, #0x14
    1940:      	ld1.s	{ v27 }[1], [x14]
    1944:      	tbz	w13, #0x6, 0x1878 <_llm_rows.packet_batch.blocks+0x13d0>
    1948:      	add	x14, x12, #0x18
    194c:      	ld1.s	{ v27 }[2], [x14]
    1950:      	tbnz	w13, #0x7, 0x187c <_llm_rows.packet_batch.blocks+0x13d4>
    1954:      	b	0x1884 <_llm_rows.packet_batch.blocks+0x13dc>
    1958:      	str	s29, [x11]
    195c:      	and	w12, w12, #0xff
    1960:      	tbz	w12, #0x1, 0x18c8 <_llm_rows.packet_batch.blocks+0x1420>
    1964:      	add	x15, x11, #0x4
    1968:      	st1.s	{ v29 }[1], [x15]
    196c:      	ldr	q30, [x13, #0x10]
    1970:      	ldr	q28, [x14, #0x10]
    1974:      	tbz	w12, #0x2, 0x18d4 <_llm_rows.packet_batch.blocks+0x142c>
    1978:      	add	x13, x11, #0x8
    197c:      	st1.s	{ v29 }[2], [x13]
    1980:      	tbz	w12, #0x3, 0x18d8 <_llm_rows.packet_batch.blocks+0x1430>
    1984:      	add	x13, x11, #0xc
    1988:      	st1.s	{ v29 }[3], [x13]
    198c:      	and.16b	v2, v0, v30
    1990:      	fdiv.4s	v2, v2, v7
    1994:      	and.16b	v16, v0, v28
    1998:      	fmul.4s	v2, v2, v16
    199c:      	fadd.4s	v27, v27, v2
    19a0:      	tbz	w12, #0x4, 0x18f0 <_llm_rows.packet_batch.blocks+0x1448>
    19a4:      	str	s27, [x11, #0x10]
    19a8:      	tbz	w12, #0x5, 0x18f4 <_llm_rows.packet_batch.blocks+0x144c>
    19ac:      	add	x13, x11, #0x14
    19b0:      	st1.s	{ v27 }[1], [x13]
    19b4:      	tbz	w12, #0x6, 0x18f8 <_llm_rows.packet_batch.blocks+0x1450>
    19b8:      	add	x13, x11, #0x18
    19bc:      	st1.s	{ v27 }[2], [x13]
    19c0:      	tbz	w12, #0x7, 0x1820 <_llm_rows.packet_batch.blocks+0x1378>
    19c4:      	add	x11, x11, #0x1c
    19c8:      	st1.s	{ v27 }[3], [x11]
    19cc:      	b	0x1820 <_llm_rows.packet_batch.blocks+0x1378>
    19d0:      	add	x9, x10, x9
    19d4:      	fmov	w10, s22
    19d8:      	movi.2d	v0, #0000000000000000
    19dc:      	movi.2d	v1, #0000000000000000
    19e0:      	tbnz	w10, #0x0, 0x1d2c <_llm_rows.packet_batch.blocks+0x1884>
    19e4:      	tbnz	w10, #0x1, 0x1d34 <_llm_rows.packet_batch.blocks+0x188c>
    19e8:      	tbnz	w10, #0x2, 0x1d40 <_llm_rows.packet_batch.blocks+0x1898>
    19ec:      	tbnz	w10, #0x3, 0x1d4c <_llm_rows.packet_batch.blocks+0x18a4>
    19f0:      	tbnz	w10, #0x4, 0x1d58 <_llm_rows.packet_batch.blocks+0x18b0>
    19f4:      	tbnz	w10, #0x5, 0x1d64 <_llm_rows.packet_batch.blocks+0x18bc>
    19f8:      	tbnz	w10, #0x6, 0x1d70 <_llm_rows.packet_batch.blocks+0x18c8>
    19fc:      	tbz	w10, #0x7, 0x1a08 <_llm_rows.packet_batch.blocks+0x1560>
    1a00:      	add	x9, x9, #0x1c
    1a04:      	ld1.s	{ v1 }[3], [x9]
    1a08:      	fdiv.4s	v2, v24, v7
    1a0c:      	fdiv.4s	v3, v25, v7
    1a10:      	fmul.4s	v3, v3, v23
    1a14:      	fmul.4s	v4, v2, v26
    1a18:      	fadd.4s	v2, v3, v0
    1a1c:      	fadd.4s	v0, v4, v1
    1a20:      	b	0x1c88 <_llm_rows.packet_batch.blocks+0x17e0>
    1a24:      	ldr	s29, [x9]
    1a28:      	tbz	w11, #0x1, 0x884 <_llm_rows.packet_batch.blocks+0x3dc>
    1a2c:      	add	x13, x9, #0x4
    1a30:      	ld1.s	{ v29 }[1], [x13]
    1a34:      	tbz	w11, #0x2, 0x888 <_llm_rows.packet_batch.blocks+0x3e0>
    1a38:      	add	x13, x9, #0x8
    1a3c:      	ld1.s	{ v29 }[2], [x13]
    1a40:      	tbz	w11, #0x3, 0x88c <_llm_rows.packet_batch.blocks+0x3e4>
    1a44:      	add	x13, x9, #0xc
    1a48:      	ld1.s	{ v29 }[3], [x13]
    1a4c:      	tbz	w11, #0x4, 0x890 <_llm_rows.packet_batch.blocks+0x3e8>
    1a50:      	add	x13, x9, #0x10
    1a54:      	ld1.s	{ v30 }[0], [x13]
    1a58:      	tbz	w11, #0x5, 0x894 <_llm_rows.packet_batch.blocks+0x3ec>
    1a5c:      	add	x13, x9, #0x14
    1a60:      	ld1.s	{ v30 }[1], [x13]
    1a64:      	tbz	w11, #0x6, 0x898 <_llm_rows.packet_batch.blocks+0x3f0>
    1a68:      	add	x13, x9, #0x18
    1a6c:      	ld1.s	{ v30 }[2], [x13]
    1a70:      	str	q16, [sp, #0x190]
    1a74:      	str	q18, [sp, #0x170]
    1a78:      	tbnz	w11, #0x7, 0x8a4 <_llm_rows.packet_batch.blocks+0x3fc>
    1a7c:      	b	0x8ac <_llm_rows.packet_batch.blocks+0x404>
    1a80:      	ldr	s23, [x12]
    1a84:      	ldr	w0, [sp, #0x188]
    1a88:      	movi.2s	v8, #0x41
    1a8c:      	add	x15, sp, #0x6a0
    1a90:      	ldr	q31, [sp, #0x190]
    1a94:      	tbz	w11, #0x1, 0x1674 <_llm_rows.packet_batch.blocks+0x11cc>
    1a98:      	add	x13, x12, #0x4
    1a9c:      	ld1.s	{ v23 }[1], [x13]
    1aa0:      	tbz	w11, #0x2, 0x1678 <_llm_rows.packet_batch.blocks+0x11d0>
    1aa4:      	add	x13, x12, #0x8
    1aa8:      	ld1.s	{ v23 }[2], [x13]
    1aac:      	tbz	w11, #0x3, 0x167c <_llm_rows.packet_batch.blocks+0x11d4>
    1ab0:      	add	x13, x12, #0xc
    1ab4:      	ld1.s	{ v23 }[3], [x13]
    1ab8:      	tbz	w11, #0x4, 0x1680 <_llm_rows.packet_batch.blocks+0x11d8>
    1abc:      	add	x13, x12, #0x10
    1ac0:      	ld1.s	{ v26 }[0], [x13]
    1ac4:      	tbz	w11, #0x5, 0x1684 <_llm_rows.packet_batch.blocks+0x11dc>
    1ac8:      	add	x13, x12, #0x14
    1acc:      	ld1.s	{ v26 }[1], [x13]
    1ad0:      	tbz	w11, #0x6, 0x1688 <_llm_rows.packet_batch.blocks+0x11e0>
    1ad4:      	add	x13, x12, #0x18
    1ad8:      	ld1.s	{ v26 }[2], [x13]
    1adc:      	tbnz	w11, #0x7, 0x168c <_llm_rows.packet_batch.blocks+0x11e4>
    1ae0:      	b	0x1694 <_llm_rows.packet_batch.blocks+0x11ec>
    1ae4:      	add	x9, x10, x9
    1ae8:      	fmov	w10, s22
    1aec:      	movi.2d	v3, #0000000000000000
    1af0:      	movi.2d	v4, #0000000000000000
    1af4:      	tbnz	w10, #0x0, 0x1d80 <_llm_rows.packet_batch.blocks+0x18d8>
    1af8:      	tbnz	w10, #0x1, 0x1d88 <_llm_rows.packet_batch.blocks+0x18e0>
    1afc:      	tbnz	w10, #0x2, 0x1d94 <_llm_rows.packet_batch.blocks+0x18ec>
    1b00:      	tbnz	w10, #0x3, 0x1da0 <_llm_rows.packet_batch.blocks+0x18f8>
    1b04:      	tbnz	w10, #0x4, 0x1dac <_llm_rows.packet_batch.blocks+0x1904>
    1b08:      	tbnz	w10, #0x5, 0x1db8 <_llm_rows.packet_batch.blocks+0x1910>
    1b0c:      	tbnz	w10, #0x6, 0x1dc4 <_llm_rows.packet_batch.blocks+0x191c>
    1b10:      	tbz	w10, #0x7, 0x1b1c <_llm_rows.packet_batch.blocks+0x1674>
    1b14:      	add	x9, x9, #0x1c
    1b18:      	ld1.s	{ v4 }[3], [x9]
    1b1c:      	mov	x10, #0x0               ; =0
    1b20:      	ldr	x9, [sp, #0x1b0]
    1b24:      	add	x9, x15, x9
    1b28:      	ldp	q2, q5, [x9]
    1b2c:      	zip2.8b	v6, v28, v0
    1b30:      	ushll.4s	v6, v6, #0x0
    1b34:      	shl.4s	v6, v6, #0x1f
    1b38:      	cmlt.4s	v6, v6, #0
    1b3c:      	bit.16b	v5, v4, v6
    1b40:      	zip1.8b	v6, v28, v0
    1b44:      	ushll.4s	v6, v6, #0x0
    1b48:      	shl.4s	v6, v6, #0x1f
    1b4c:      	cmlt.4s	v6, v6, #0
    1b50:      	bit.16b	v2, v3, v6
    1b54:      	stp	q2, q5, [x9]
    1b58:      	dup.4s	v5, v17[0]
    1b5c:      	ldr	q2, [sp, #0x110]
    1b60:      	fmov	x9, d2
    1b64:      	add	x9, x8, x9, lsl #2
    1b68:      	movi.2d	v6, #0000000000000000
    1b6c:      	movi.2d	v7, #0000000000000000
    1b70:      	movi.2d	v16, #0000000000000000
    1b74:      	movi.2d	v17, #0000000000000000
    1b78:      	b	0x1b98 <_llm_rows.packet_batch.blocks+0x16f0>
    1b7c:      	add.2d	v7, v7, v19
    1b80:      	add.2d	v16, v16, v20
    1b84:      	add.2d	v17, v17, v18
    1b88:      	add.2d	v6, v6, v21
    1b8c:      	fmov	x10, d6
    1b90:      	cmp	x10, #0x8
    1b94:      	b.ge	0x1c70 <_llm_rows.packet_batch.blocks+0x17c8>
    1b98:      	fmov	w11, s9
    1b9c:      	lsl	x10, x10, #5
    1ba0:      	add	x12, x19, x10
    1ba4:      	ldp	q2, q27, [x12]
    1ba8:      	and.16b	v2, v1, v2
    1bac:      	fdiv.4s	v2, v2, v5
    1bb0:      	add	x12, x21, x10
    1bb4:      	ldp	q29, q28, [x12]
    1bb8:      	and.16b	v29, v1, v29
    1bbc:      	fmul.4s	v2, v2, v29
    1bc0:      	add	x12, x15, x10
    1bc4:      	ldp	q30, q29, [x12]
    1bc8:      	and.16b	v30, v1, v30
    1bcc:      	fadd.4s	v30, v2, v30
    1bd0:      	add	x10, x9, x10
    1bd4:      	tbnz	w11, #0x0, 0x1c1c <_llm_rows.packet_batch.blocks+0x1774>
    1bd8:      	and	w11, w11, #0xff
    1bdc:      	tbnz	w11, #0x1, 0x1c28 <_llm_rows.packet_batch.blocks+0x1780>
    1be0:      	tbnz	w11, #0x2, 0x1c34 <_llm_rows.packet_batch.blocks+0x178c>
    1be4:      	tbz	w11, #0x3, 0x1bf0 <_llm_rows.packet_batch.blocks+0x1748>
    1be8:      	add	x12, x10, #0xc
    1bec:      	st1.s	{ v30 }[3], [x12]
    1bf0:      	and.16b	v2, v0, v27
    1bf4:      	fdiv.4s	v2, v2, v5
    1bf8:      	and.16b	v27, v0, v28
    1bfc:      	fmul.4s	v2, v2, v27
    1c00:      	and.16b	v27, v0, v29
    1c04:      	fadd.4s	v27, v2, v27
    1c08:      	tbnz	w11, #0x4, 0x1c44 <_llm_rows.packet_batch.blocks+0x179c>
    1c0c:      	tbnz	w11, #0x5, 0x1c4c <_llm_rows.packet_batch.blocks+0x17a4>
    1c10:      	tbnz	w11, #0x6, 0x1c58 <_llm_rows.packet_batch.blocks+0x17b0>
    1c14:      	tbz	w11, #0x7, 0x1b7c <_llm_rows.packet_batch.blocks+0x16d4>
    1c18:      	b	0x1c64 <_llm_rows.packet_batch.blocks+0x17bc>
    1c1c:      	str	s30, [x10]
    1c20:      	and	w11, w11, #0xff
    1c24:      	tbz	w11, #0x1, 0x1be0 <_llm_rows.packet_batch.blocks+0x1738>
    1c28:      	add	x12, x10, #0x4
    1c2c:      	st1.s	{ v30 }[1], [x12]
    1c30:      	tbz	w11, #0x2, 0x1be4 <_llm_rows.packet_batch.blocks+0x173c>
    1c34:      	add	x12, x10, #0x8
    1c38:      	st1.s	{ v30 }[2], [x12]
    1c3c:      	tbnz	w11, #0x3, 0x1be8 <_llm_rows.packet_batch.blocks+0x1740>
    1c40:      	b	0x1bf0 <_llm_rows.packet_batch.blocks+0x1748>
    1c44:      	str	s27, [x10, #0x10]
    1c48:      	tbz	w11, #0x5, 0x1c10 <_llm_rows.packet_batch.blocks+0x1768>
    1c4c:      	add	x12, x10, #0x14
    1c50:      	st1.s	{ v27 }[1], [x12]
    1c54:      	tbz	w11, #0x6, 0x1c14 <_llm_rows.packet_batch.blocks+0x176c>
    1c58:      	add	x12, x10, #0x18
    1c5c:      	st1.s	{ v27 }[2], [x12]
    1c60:      	tbz	w11, #0x7, 0x1b7c <_llm_rows.packet_batch.blocks+0x16d4>
    1c64:      	add	x10, x10, #0x1c
    1c68:      	st1.s	{ v27 }[3], [x10]
    1c6c:      	b	0x1b7c <_llm_rows.packet_batch.blocks+0x16d4>
    1c70:      	fdiv.4s	v0, v25, v5
    1c74:      	fdiv.4s	v1, v24, v5
    1c78:      	fmul.4s	v1, v1, v26
    1c7c:      	fmul.4s	v0, v0, v23
    1c80:      	fadd.4s	v2, v0, v3
    1c84:      	fadd.4s	v0, v1, v4
    1c88:      	ldp	q1, q3, [sp, #0x140]
    1c8c:      	ldp	q5, q4, [sp, #0x120]
    1c90:      	stp	q3, q4, [sp, #0x1d0]
    1c94:      	stp	q5, q1, [sp, #0x1f0]
    1c98:      	and	x9, x16, #0x7
    1c9c:      	add	x10, sp, #0x1d0
    1ca0:      	ldr	x9, [x10, x9, lsl #3]
    1ca4:      	sub	x9, x9, x16
    1ca8:      	add	x8, x8, x9, lsl #2
    1cac:      	fmov	w9, s22
    1cb0:      	tbnz	w9, #0x0, 0x1cd4 <_llm_rows.packet_batch.blocks+0x182c>
    1cb4:      	tbnz	w9, #0x1, 0x1cdc <_llm_rows.packet_batch.blocks+0x1834>
    1cb8:      	tbnz	w9, #0x2, 0x1ce8 <_llm_rows.packet_batch.blocks+0x1840>
    1cbc:      	tbnz	w9, #0x3, 0x1cf4 <_llm_rows.packet_batch.blocks+0x184c>
    1cc0:      	tbnz	w9, #0x4, 0x1d00 <_llm_rows.packet_batch.blocks+0x1858>
    1cc4:      	tbnz	w9, #0x5, 0x1d08 <_llm_rows.packet_batch.blocks+0x1860>
    1cc8:      	tbnz	w9, #0x6, 0x1d14 <_llm_rows.packet_batch.blocks+0x186c>
    1ccc:      	tbz	w9, #0x7, 0x53c <_llm_rows.packet_batch.blocks+0x94>
    1cd0:      	b	0x1d20 <_llm_rows.packet_batch.blocks+0x1878>
    1cd4:      	str	s2, [x8]
    1cd8:      	tbz	w9, #0x1, 0x1cb8 <_llm_rows.packet_batch.blocks+0x1810>
    1cdc:      	add	x10, x8, #0x4
    1ce0:      	st1.s	{ v2 }[1], [x10]
    1ce4:      	tbz	w9, #0x2, 0x1cbc <_llm_rows.packet_batch.blocks+0x1814>
    1ce8:      	add	x10, x8, #0x8
    1cec:      	st1.s	{ v2 }[2], [x10]
    1cf0:      	tbz	w9, #0x3, 0x1cc0 <_llm_rows.packet_batch.blocks+0x1818>
    1cf4:      	add	x10, x8, #0xc
    1cf8:      	st1.s	{ v2 }[3], [x10]
    1cfc:      	tbz	w9, #0x4, 0x1cc4 <_llm_rows.packet_batch.blocks+0x181c>
    1d00:      	str	s0, [x8, #0x10]
    1d04:      	tbz	w9, #0x5, 0x1cc8 <_llm_rows.packet_batch.blocks+0x1820>
    1d08:      	add	x10, x8, #0x14
    1d0c:      	st1.s	{ v0 }[1], [x10]
    1d10:      	tbz	w9, #0x6, 0x1ccc <_llm_rows.packet_batch.blocks+0x1824>
    1d14:      	add	x10, x8, #0x18
    1d18:      	st1.s	{ v0 }[2], [x10]
    1d1c:      	tbz	w9, #0x7, 0x53c <_llm_rows.packet_batch.blocks+0x94>
    1d20:      	add	x8, x8, #0x1c
    1d24:      	st1.s	{ v0 }[3], [x8]
    1d28:      	b	0x53c <_llm_rows.packet_batch.blocks+0x94>
    1d2c:      	ldr	s0, [x9]
    1d30:      	tbz	w10, #0x1, 0x19e8 <_llm_rows.packet_batch.blocks+0x1540>
    1d34:      	add	x11, x9, #0x4
    1d38:      	ld1.s	{ v0 }[1], [x11]
    1d3c:      	tbz	w10, #0x2, 0x19ec <_llm_rows.packet_batch.blocks+0x1544>
    1d40:      	add	x11, x9, #0x8
    1d44:      	ld1.s	{ v0 }[2], [x11]
    1d48:      	tbz	w10, #0x3, 0x19f0 <_llm_rows.packet_batch.blocks+0x1548>
    1d4c:      	add	x11, x9, #0xc
    1d50:      	ld1.s	{ v0 }[3], [x11]
    1d54:      	tbz	w10, #0x4, 0x19f4 <_llm_rows.packet_batch.blocks+0x154c>
    1d58:      	add	x11, x9, #0x10
    1d5c:      	ld1.s	{ v1 }[0], [x11]
    1d60:      	tbz	w10, #0x5, 0x19f8 <_llm_rows.packet_batch.blocks+0x1550>
    1d64:      	add	x11, x9, #0x14
    1d68:      	ld1.s	{ v1 }[1], [x11]
    1d6c:      	tbz	w10, #0x6, 0x19fc <_llm_rows.packet_batch.blocks+0x1554>
    1d70:      	add	x11, x9, #0x18
    1d74:      	ld1.s	{ v1 }[2], [x11]
    1d78:      	tbnz	w10, #0x7, 0x1a00 <_llm_rows.packet_batch.blocks+0x1558>
    1d7c:      	b	0x1a08 <_llm_rows.packet_batch.blocks+0x1560>
    1d80:      	ldr	s3, [x9]
    1d84:      	tbz	w10, #0x1, 0x1afc <_llm_rows.packet_batch.blocks+0x1654>
    1d88:      	add	x11, x9, #0x4
    1d8c:      	ld1.s	{ v3 }[1], [x11]
    1d90:      	tbz	w10, #0x2, 0x1b00 <_llm_rows.packet_batch.blocks+0x1658>
    1d94:      	add	x11, x9, #0x8
    1d98:      	ld1.s	{ v3 }[2], [x11]
    1d9c:      	tbz	w10, #0x3, 0x1b04 <_llm_rows.packet_batch.blocks+0x165c>
    1da0:      	add	x11, x9, #0xc
    1da4:      	ld1.s	{ v3 }[3], [x11]
    1da8:      	tbz	w10, #0x4, 0x1b08 <_llm_rows.packet_batch.blocks+0x1660>
    1dac:      	add	x11, x9, #0x10
    1db0:      	ld1.s	{ v4 }[0], [x11]
    1db4:      	tbz	w10, #0x5, 0x1b0c <_llm_rows.packet_batch.blocks+0x1664>
    1db8:      	add	x11, x9, #0x14
    1dbc:      	ld1.s	{ v4 }[1], [x11]
    1dc0:      	tbz	w10, #0x6, 0x1b10 <_llm_rows.packet_batch.blocks+0x1668>
    1dc4:      	add	x11, x9, #0x18
    1dc8:      	ld1.s	{ v4 }[2], [x11]
    1dcc:      	tbnz	w10, #0x7, 0x1b14 <_llm_rows.packet_batch.blocks+0x166c>
    1dd0:      	b	0x1b1c <_llm_rows.packet_batch.blocks+0x1674>
    1dd4:      	add	sp, sp, #0xb20
    1dd8:      	ldp	x29, x30, [sp, #0x90]
    1ddc:      	ldp	x20, x19, [sp, #0x80]
    1de0:      	ldp	x22, x21, [sp, #0x70]
    1de4:      	ldp	x24, x23, [sp, #0x60]
    1de8:      	ldp	x26, x25, [sp, #0x50]
    1dec:      	ldp	x28, x27, [sp, #0x40]
    1df0:      	ldp	d9, d8, [sp, #0x30]
    1df4:      	ldp	d11, d10, [sp, #0x20]
    1df8:      	ldp	d13, d12, [sp, #0x10]
    1dfc:      	ldp	d15, d14, [sp], #0xa0
    1e00:      	ret

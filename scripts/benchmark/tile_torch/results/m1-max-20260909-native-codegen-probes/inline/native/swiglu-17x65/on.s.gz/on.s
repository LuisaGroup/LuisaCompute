
/private/tmp/luisa-packet-inline.UY1lIE/capture/swiglu-17x65/on/object/tile_xir_w8_36395_1788935100440246_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x2110 <ltmp0+0x2110>
       4:      	stp	d15, d14, [sp, #-0xa0]!
       8:      	stp	d13, d12, [sp, #0x10]
       c:      	stp	d11, d10, [sp, #0x20]
      10:      	stp	d9, d8, [sp, #0x30]
      14:      	stp	x28, x27, [sp, #0x40]
      18:      	stp	x26, x25, [sp, #0x50]
      1c:      	stp	x24, x23, [sp, #0x60]
      20:      	stp	x22, x21, [sp, #0x70]
      24:      	stp	x20, x19, [sp, #0x80]
      28:      	stp	x29, x30, [sp, #0x90]
      2c:      	sub	sp, sp, #0x4c0
      30:      	mov	w8, #0x0                ; =0
      34:      	mov	w22, #0x20              ; =32
      38:      	mov	w10, #0x450             ; =1104
      3c:      	mov	w9, #0x42d00000         ; =1120927744
      40:      	dup.4s	v0, w9
      44:      	mov	w9, #-0x3d380000        ; =-1027080192
      48:      	dup.4s	v1, w9
      4c:      	mov	w9, #0xaa3b             ; =43579
      50:      	movk	w9, #0x3fb8, lsl #16
      54:      	dup.4s	v2, w9
      58:      	ldp	w11, w12, [x2, #0x2c]
      5c:      	movi.4s	v3, #0x4b, lsl #24
      60:      	mvni.4s	v4, #0x80, lsl #24
      64:      	mov	w9, #0x7200             ; =29184
      68:      	movk	w9, #0xbf31, lsl #16
      6c:      	dup.4s	v5, w9
      70:      	mov	w9, #0xbe8e             ; =48782
      74:      	movk	w9, #0xb5bf, lsl #16
      78:      	dup.4s	v6, w9
      7c:      	mov	w9, #0x2bda             ; =11226
      80:      	movk	w9, #0x3950, lsl #16
      84:      	dup.4s	v7, w9
      88:      	mov	w9, #0x96c9             ; =38601
      8c:      	movk	w9, #0x3ab6, lsl #16
      90:      	dup.4s	v16, w9
      94:      	mov	w9, #0x88a6             ; =34982
      98:      	movk	w9, #0x3c08, lsl #16
      9c:      	dup.4s	v17, w9
      a0:      	mov	w9, #0xaa7a             ; =43642
      a4:      	movk	w9, #0x3d2a, lsl #16
      a8:      	dup.4s	v18, w9
      ac:      	mov	w5, #0xaaab             ; =43691
      b0:      	movk	w5, #0x3e2a, lsl #16
      b4:      	mov	w13, #-0x3d300000       ; =-1026555904
      b8:      	ldp	w9, w17, [x2]
      bc:      	mov	w14, #0x42c80000        ; =1120403456
      c0:      	add	x15, sp, #0x3a0
      c4:      	add	x16, sp, #0x280
      c8:      	ldp	w4, w1, [x2, #0x8]
      cc:      	str	x2, [sp, #0x10]
      d0:      	dup.4s	v19, w5
      d4:      	movi.4s	v20, #0x3f, lsl #24
      d8:      	fmov.4s	v21, #1.00000000
      dc:      	mvni.4s	v22, #0x7f, msl #16
      e0:      	fneg.4s	v22, v22
      e4:      	adrp	x20, 0x0 <ltmp0>
      e8:      	mvni.4s	v23, #0x3f, msl #16
      ec:      	fneg.4s	v23, v23
      f0:      	b	0x12c <ltmp0+0x12c>
      f4:      	st1.s	{ v24 }[3], [x9]
      f8:      	add	w9, w30, #0x1
      fc:      	cmp	w9, w11
     100:      	cset	w17, eq
     104:      	csinc	w9, wzr, w30, eq
     108:      	cinc	w2, w28, eq
     10c:      	cmp	w2, w12
     110:      	cset	w4, eq
     114:      	ands	w4, w17, w4
     118:      	csel	w17, wzr, w2, ne
     11c:      	add	w4, w27, w4
     120:      	add	w8, w8, #0x1
     124:      	cmp	w8, w3
     128:      	b.eq	0x20d0 <ltmp0+0x20d0>
     12c:      	mov	x27, x4
     130:      	mov	x28, x17
     134:      	mov	x30, x9
     138:      	ubfiz	x9, x9, #5, #32
     13c:      	cmp	x9, x1
     140:      	csel	x17, x9, xzr, ls
     144:      	subs	x4, x1, x17
     148:      	cmp	x4, #0x20
     14c:      	csel	x4, x4, x22, lo
     150:      	cmp	x1, x17
     154:      	ccmp	x9, x1, #0x2, hi
     158:      	csel	x23, x4, xzr, ls
     15c:      	dup.4s	v27, w13
     160:      	dup.4s	v26, w14
     164:      	cmp	x23, #0x20
     168:      	b.lo	0x7b0 <ltmp0+0x7b0>
     16c:      	mov	x23, #0x0               ; =0
     170:      	ldr	x24, [x0]
     174:      	ldr	x25, [x0, #0x10]
     178:      	ldr	x26, [x0, #0x30]
     17c:      	subs	x9, x24, x26
     180:      	lsr	x9, x9, #2
     184:      	ccmp	x9, x10, #0x0, hs
     188:      	cset	w9, hi
     18c:      	subs	x17, x26, x24
     190:      	lsr	x17, x17, #2
     194:      	ccmp	x17, x10, #0x0, hs
     198:      	csinc	w9, w9, wzr, ls
     19c:      	subs	x17, x25, x26
     1a0:      	lsr	x17, x17, #2
     1a4:      	ccmp	x17, x10, #0x0, hs
     1a8:      	cset	w17, hi
     1ac:      	subs	x4, x26, x25
     1b0:      	lsr	x4, x4, #2
     1b4:      	ccmp	x4, x10, #0x0, hs
     1b8:      	csinc	w17, w17, wzr, ls
     1bc:      	and	w5, w9, w17
     1c0:      	lsl	w6, w30, #2
     1c4:      	and	x9, x30, #0x7ffffff
     1c8:      	add	x9, x9, x9, lsl #6
     1cc:      	lsl	x9, x9, #4
     1d0:      	add	x7, x26, x9
     1d4:      	add	x19, x25, x9
     1d8:      	add	x21, x24, x9
     1dc:      	b	0x2c8 <ltmp0+0x2c8>
     1e0:      	movi.2d	v29, #0000000000000000
     1e4:      	mov.s	v29[0], v28[0]
     1e8:      	fneg.4s	v28, v29
     1ec:      	movi.2d	v30, #0000000000000000
     1f0:      	mov.s	v30[0], v28[0]
     1f4:      	fcmge.4s	v28, v30, v27
     1f8:      	fcmge.4s	v31, v26, v30
     1fc:      	and.16b	v28, v28, v31
     200:      	and.16b	v28, v28, v30
     204:      	fmul.4s	v31, v28, v2
     208:      	mov.16b	v8, v4
     20c:      	bsl.16b	v8, v3, v31
     210:      	fadd.4s	v31, v31, v8
     214:      	fsub.4s	v31, v31, v8
     218:      	fcvtzs.4s	v31, v31
     21c:      	scvtf.4s	v8, v31
     220:      	fmul.4s	v9, v8, v5
     224:      	fadd.4s	v28, v28, v9
     228:      	fmul.4s	v8, v8, v6
     22c:      	fadd.4s	v28, v28, v8
     230:      	fmul.4s	v8, v28, v7
     234:      	fadd.4s	v8, v8, v16
     238:      	fmul.4s	v8, v28, v8
     23c:      	fadd.4s	v8, v8, v17
     240:      	fmul.4s	v8, v28, v8
     244:      	fadd.4s	v8, v8, v18
     248:      	fmul.4s	v8, v28, v8
     24c:      	fadd.4s	v8, v8, v19
     250:      	fmul.4s	v8, v28, v8
     254:      	fadd.4s	v8, v8, v20
     258:      	fmul.4s	v9, v28, v28
     25c:      	fmul.4s	v8, v9, v8
     260:      	fadd.4s	v28, v28, v8
     264:      	fadd.4s	v28, v28, v21
     268:      	sshr.4s	v8, v31, #0x1
     26c:      	shl.4s	v9, v8, #0x17
     270:      	add.4s	v9, v9, v21
     274:      	fmul.4s	v28, v28, v9
     278:      	sub.4s	v31, v31, v8
     27c:      	shl.4s	v31, v31, #0x17
     280:      	add.4s	v31, v31, v21
     284:      	fmul.4s	v28, v28, v31
     288:      	fcmgt.4s	v31, v27, v30
     28c:      	fcmgt.4s	v8, v30, v26
     290:      	fcmeq.4s	v30, v30, v30
     294:      	fadd.4s	v28, v28, v21
     298:      	bit.16b	v28, v21, v31
     29c:      	bit.16b	v28, v22, v8
     2a0:      	bif.16b	v28, v23, v30
     2a4:      	fdiv.4s	v28, v29, v28
     2a8:      	fmul.4s	v28, v25, v28
     2ac:      	str	s28, [x26, x17]
     2b0:      	add	x23, x23, #0x1
     2b4:      	add	x7, x7, #0x104
     2b8:      	add	x19, x19, #0x104
     2bc:      	add	x21, x21, #0x104
     2c0:      	cmp	x23, #0x4
     2c4:      	b.eq	0xf8 <ltmp0+0xf8>
     2c8:      	add	w9, w23, w6
     2cc:      	and	x9, x9, #0x1fffffff
     2d0:      	add	x9, x9, x9, lsl #6
     2d4:      	lsl	x9, x9, #2
     2d8:      	cbz	w5, 0x550 <ltmp0+0x550>
     2dc:      	mov	x17, #0x0               ; =0
     2e0:      	add	x4, x21, x17
     2e4:      	ldp	q28, q29, [x4]
     2e8:      	fneg.4s	v30, v29
     2ec:      	fneg.4s	v31, v28
     2f0:      	fcmge.4s	v8, v0, v28
     2f4:      	fcmge.4s	v9, v0, v29
     2f8:      	fcmge.4s	v10, v28, v1
     2fc:      	fcmge.4s	v11, v29, v1
     300:      	and.16b	v9, v9, v11
     304:      	and.16b	v8, v8, v10
     308:      	and.16b	v31, v8, v31
     30c:      	and.16b	v30, v9, v30
     310:      	fmul.4s	v8, v30, v2
     314:      	fmul.4s	v9, v31, v2
     318:      	mov.16b	v10, v4
     31c:      	bsl.16b	v10, v3, v9
     320:      	mov.16b	v11, v4
     324:      	bsl.16b	v11, v3, v8
     328:      	fadd.4s	v8, v8, v11
     32c:      	fadd.4s	v9, v9, v10
     330:      	fsub.4s	v9, v9, v10
     334:      	fsub.4s	v8, v8, v11
     338:      	fcvtzs.4s	v8, v8
     33c:      	fcvtzs.4s	v9, v9
     340:      	scvtf.4s	v10, v9
     344:      	scvtf.4s	v11, v8
     348:      	fmul.4s	v12, v11, v5
     34c:      	fmul.4s	v13, v10, v5
     350:      	fadd.4s	v31, v31, v13
     354:      	fadd.4s	v30, v30, v12
     358:      	fmul.4s	v10, v10, v6
     35c:      	fmul.4s	v11, v11, v6
     360:      	fadd.4s	v30, v30, v11
     364:      	fadd.4s	v31, v31, v10
     368:      	fmul.4s	v10, v31, v7
     36c:      	fmul.4s	v11, v30, v7
     370:      	fadd.4s	v11, v11, v16
     374:      	fadd.4s	v10, v10, v16
     378:      	fmul.4s	v10, v31, v10
     37c:      	fmul.4s	v11, v30, v11
     380:      	fadd.4s	v11, v11, v17
     384:      	fadd.4s	v10, v10, v17
     388:      	fmul.4s	v10, v31, v10
     38c:      	fmul.4s	v11, v30, v11
     390:      	fadd.4s	v11, v11, v18
     394:      	fadd.4s	v10, v10, v18
     398:      	fmul.4s	v10, v31, v10
     39c:      	fmul.4s	v11, v30, v11
     3a0:      	fadd.4s	v11, v11, v19
     3a4:      	fadd.4s	v10, v10, v19
     3a8:      	fmul.4s	v10, v31, v10
     3ac:      	fmul.4s	v11, v30, v11
     3b0:      	fadd.4s	v11, v11, v20
     3b4:      	fadd.4s	v10, v10, v20
     3b8:      	fmul.4s	v12, v30, v30
     3bc:      	fmul.4s	v13, v31, v31
     3c0:      	fmul.4s	v10, v13, v10
     3c4:      	fmul.4s	v11, v12, v11
     3c8:      	fadd.4s	v30, v30, v11
     3cc:      	fadd.4s	v31, v31, v10
     3d0:      	sshr.4s	v10, v9, #0x1
     3d4:      	fadd.4s	v31, v31, v21
     3d8:      	sshr.4s	v11, v8, #0x1
     3dc:      	shl.4s	v12, v11, #0x17
     3e0:      	shl.4s	v13, v10, #0x17
     3e4:      	add.4s	v13, v13, v21
     3e8:      	add.4s	v12, v12, v21
     3ec:      	fadd.4s	v30, v30, v21
     3f0:      	fmul.4s	v30, v30, v12
     3f4:      	sub.4s	v8, v8, v11
     3f8:      	sub.4s	v9, v9, v10
     3fc:      	shl.4s	v9, v9, #0x17
     400:      	shl.4s	v8, v8, #0x17
     404:      	fmul.4s	v31, v31, v13
     408:      	add.4s	v8, v8, v21
     40c:      	add.4s	v9, v9, v21
     410:      	fmul.4s	v31, v31, v9
     414:      	fmul.4s	v30, v30, v8
     418:      	fcmgt.4s	v8, v29, v0
     41c:      	fcmgt.4s	v9, v28, v0
     420:      	fcmgt.4s	v10, v1, v28
     424:      	fcmgt.4s	v11, v1, v29
     428:      	fcmeq.4s	v12, v29, v29
     42c:      	fadd.4s	v30, v30, v21
     430:      	fadd.4s	v31, v31, v21
     434:      	fcmeq.4s	v13, v28, v28
     438:      	bit.16b	v31, v21, v9
     43c:      	bit.16b	v30, v21, v8
     440:      	bit.16b	v30, v22, v11
     444:      	bit.16b	v31, v22, v10
     448:      	bif.16b	v31, v23, v13
     44c:      	bif.16b	v30, v23, v12
     450:      	fdiv.4s	v29, v29, v30
     454:      	fdiv.4s	v28, v28, v31
     458:      	add	x4, x19, x17
     45c:      	ldp	q31, q30, [x4]
     460:      	fmul.4s	v28, v31, v28
     464:      	fmul.4s	v29, v30, v29
     468:      	add	x4, x7, x17
     46c:      	stp	q28, q29, [x4]
     470:      	add	x17, x17, #0x20
     474:      	cmp	x17, #0x100
     478:      	b.ne	0x2e0 <ltmp0+0x2e0>
     47c:      	add	x17, x9, #0x100
     480:      	ldr	s28, [x24, x17]
     484:      	fneg.4s	v29, v28
     488:      	movi.2d	v30, #0000000000000000
     48c:      	mov.s	v30[0], v29[0]
     490:      	fcmge.4s	v29, v30, v27
     494:      	fcmge.4s	v31, v26, v30
     498:      	and.16b	v29, v29, v31
     49c:      	and.16b	v29, v29, v30
     4a0:      	fmul.4s	v31, v29, v2
     4a4:      	mov.16b	v8, v4
     4a8:      	bsl.16b	v8, v3, v31
     4ac:      	fadd.4s	v31, v31, v8
     4b0:      	fsub.4s	v31, v31, v8
     4b4:      	fcvtzs.4s	v31, v31
     4b8:      	scvtf.4s	v8, v31
     4bc:      	fmul.4s	v9, v8, v5
     4c0:      	fadd.4s	v29, v29, v9
     4c4:      	fmul.4s	v8, v8, v6
     4c8:      	fadd.4s	v29, v29, v8
     4cc:      	fmul.4s	v8, v29, v7
     4d0:      	fadd.4s	v8, v8, v16
     4d4:      	fmul.4s	v8, v29, v8
     4d8:      	fadd.4s	v8, v8, v17
     4dc:      	fmul.4s	v8, v29, v8
     4e0:      	fadd.4s	v8, v8, v18
     4e4:      	fmul.4s	v8, v29, v8
     4e8:      	fadd.4s	v8, v8, v19
     4ec:      	fmul.4s	v8, v29, v8
     4f0:      	fadd.4s	v8, v8, v20
     4f4:      	fmul.4s	v9, v29, v29
     4f8:      	fmul.4s	v8, v9, v8
     4fc:      	fadd.4s	v29, v29, v8
     500:      	fadd.4s	v29, v29, v21
     504:      	sshr.4s	v8, v31, #0x1
     508:      	shl.4s	v9, v8, #0x17
     50c:      	add.4s	v9, v9, v21
     510:      	fmul.4s	v29, v29, v9
     514:      	sub.4s	v31, v31, v8
     518:      	shl.4s	v31, v31, #0x17
     51c:      	add.4s	v31, v31, v21
     520:      	fmul.4s	v29, v29, v31
     524:      	fcmgt.4s	v31, v27, v30
     528:      	fcmgt.4s	v8, v30, v26
     52c:      	fcmeq.4s	v30, v30, v30
     530:      	fadd.4s	v29, v29, v21
     534:      	bit.16b	v29, v21, v31
     538:      	bit.16b	v29, v22, v8
     53c:      	bif.16b	v29, v23, v30
     540:      	fdiv.4s	v28, v28, v29
     544:      	ldr	s29, [x25, x17]
     548:      	fmul.4s	v28, v29, v28
     54c:      	b	0x2ac <ltmp0+0x2ac>
     550:      	mov	x4, #0x0                ; =0
     554:      	add	x17, x24, x9
     558:      	ldp	q28, q29, [x17, #0xc0]
     55c:      	str	q28, [sp, #0x460]
     560:      	str	q29, [sp, #0x470]
     564:      	ldp	q28, q29, [x17, #0xe0]
     568:      	str	q28, [sp, #0x480]
     56c:      	str	q29, [sp, #0x490]
     570:      	ldp	q28, q29, [x17, #0x80]
     574:      	str	q28, [sp, #0x420]
     578:      	str	q29, [sp, #0x430]
     57c:      	ldp	q28, q29, [x17, #0xa0]
     580:      	str	q28, [sp, #0x440]
     584:      	str	q29, [sp, #0x450]
     588:      	ldp	q28, q29, [x17, #0x40]
     58c:      	stp	q28, q29, [sp, #0x3e0]
     590:      	ldp	q28, q29, [x17, #0x60]
     594:      	str	q28, [sp, #0x400]
     598:      	str	q29, [sp, #0x410]
     59c:      	ldp	q28, q29, [x17]
     5a0:      	stp	q28, q29, [sp, #0x3a0]
     5a4:      	ldp	q28, q29, [x17, #0x20]
     5a8:      	stp	q28, q29, [sp, #0x3c0]
     5ac:      	add	x17, x9, #0x100
     5b0:      	add	x9, x25, x9
     5b4:      	ldp	q28, q29, [x9, #0xc0]
     5b8:      	stp	q28, q29, [sp, #0x340]
     5bc:      	ldp	q28, q29, [x9, #0xe0]
     5c0:      	stp	q28, q29, [sp, #0x360]
     5c4:      	ldp	q28, q29, [x9, #0x80]
     5c8:      	stp	q28, q29, [sp, #0x300]
     5cc:      	ldp	q28, q29, [x9, #0xa0]
     5d0:      	stp	q28, q29, [sp, #0x320]
     5d4:      	ldp	q28, q29, [x9, #0x40]
     5d8:      	stp	q28, q29, [sp, #0x2c0]
     5dc:      	ldp	q28, q29, [x9, #0x60]
     5e0:      	stp	q28, q29, [sp, #0x2e0]
     5e4:      	ldp	q28, q29, [x9]
     5e8:      	ldp	q30, q31, [x9, #0x20]
     5ec:      	add	x9, x25, x17
     5f0:      	ld1.s	{ v25 }[0], [x9]
     5f4:      	stp	q28, q29, [sp, #0x280]
     5f8:      	ldr	s28, [x24, x17]
     5fc:      	mov.s	v24[0], v28[0]
     600:      	str	q0, [sp, #0x4b0]
     604:      	str	q24, [sp, #0x4a0]
     608:      	stp	q30, q31, [sp, #0x2a0]
     60c:      	stp	q25, q0, [sp, #0x380]
     610:      	add	x9, x15, x4
     614:      	ldp	q29, q30, [x9]
     618:      	fneg.4s	v31, v30
     61c:      	fneg.4s	v8, v29
     620:      	fcmge.4s	v9, v0, v29
     624:      	fcmge.4s	v10, v0, v30
     628:      	fcmge.4s	v11, v29, v1
     62c:      	fcmge.4s	v12, v30, v1
     630:      	and.16b	v10, v10, v12
     634:      	and.16b	v9, v9, v11
     638:      	and.16b	v8, v9, v8
     63c:      	and.16b	v31, v10, v31
     640:      	fmul.4s	v9, v31, v2
     644:      	fmul.4s	v10, v8, v2
     648:      	mov.16b	v11, v4
     64c:      	bsl.16b	v11, v3, v10
     650:      	mov.16b	v12, v4
     654:      	bsl.16b	v12, v3, v9
     658:      	fadd.4s	v9, v9, v12
     65c:      	fadd.4s	v10, v10, v11
     660:      	fsub.4s	v10, v10, v11
     664:      	fsub.4s	v9, v9, v12
     668:      	fcvtzs.4s	v9, v9
     66c:      	fcvtzs.4s	v10, v10
     670:      	scvtf.4s	v11, v10
     674:      	scvtf.4s	v12, v9
     678:      	fmul.4s	v13, v12, v5
     67c:      	fmul.4s	v14, v11, v5
     680:      	fadd.4s	v8, v8, v14
     684:      	fadd.4s	v31, v31, v13
     688:      	fmul.4s	v11, v11, v6
     68c:      	fmul.4s	v12, v12, v6
     690:      	fadd.4s	v31, v31, v12
     694:      	fadd.4s	v8, v8, v11
     698:      	fmul.4s	v11, v8, v7
     69c:      	fmul.4s	v12, v31, v7
     6a0:      	fadd.4s	v12, v12, v16
     6a4:      	fadd.4s	v11, v11, v16
     6a8:      	fmul.4s	v11, v8, v11
     6ac:      	fmul.4s	v12, v31, v12
     6b0:      	fadd.4s	v12, v12, v17
     6b4:      	fadd.4s	v11, v11, v17
     6b8:      	fmul.4s	v11, v8, v11
     6bc:      	fmul.4s	v12, v31, v12
     6c0:      	fadd.4s	v12, v12, v18
     6c4:      	fadd.4s	v11, v11, v18
     6c8:      	fmul.4s	v11, v8, v11
     6cc:      	fmul.4s	v12, v31, v12
     6d0:      	fadd.4s	v12, v12, v19
     6d4:      	fadd.4s	v11, v11, v19
     6d8:      	fmul.4s	v11, v8, v11
     6dc:      	fmul.4s	v12, v31, v12
     6e0:      	fadd.4s	v12, v12, v20
     6e4:      	fadd.4s	v11, v11, v20
     6e8:      	fmul.4s	v13, v31, v31
     6ec:      	fmul.4s	v14, v8, v8
     6f0:      	fmul.4s	v11, v14, v11
     6f4:      	fmul.4s	v12, v13, v12
     6f8:      	fadd.4s	v31, v31, v12
     6fc:      	fadd.4s	v8, v8, v11
     700:      	sshr.4s	v11, v10, #0x1
     704:      	fadd.4s	v8, v8, v21
     708:      	sshr.4s	v12, v9, #0x1
     70c:      	shl.4s	v13, v12, #0x17
     710:      	shl.4s	v14, v11, #0x17
     714:      	add.4s	v14, v14, v21
     718:      	add.4s	v13, v13, v21
     71c:      	fadd.4s	v31, v31, v21
     720:      	fmul.4s	v31, v31, v13
     724:      	sub.4s	v9, v9, v12
     728:      	sub.4s	v10, v10, v11
     72c:      	shl.4s	v10, v10, #0x17
     730:      	shl.4s	v9, v9, #0x17
     734:      	fmul.4s	v8, v8, v14
     738:      	add.4s	v9, v9, v21
     73c:      	add.4s	v10, v10, v21
     740:      	fmul.4s	v8, v8, v10
     744:      	fmul.4s	v31, v31, v9
     748:      	fcmgt.4s	v9, v30, v0
     74c:      	fcmgt.4s	v10, v29, v0
     750:      	fcmgt.4s	v11, v1, v29
     754:      	fcmgt.4s	v12, v1, v30
     758:      	fcmeq.4s	v13, v30, v30
     75c:      	fadd.4s	v31, v31, v21
     760:      	fadd.4s	v8, v8, v21
     764:      	fcmeq.4s	v14, v29, v29
     768:      	bit.16b	v8, v21, v10
     76c:      	bit.16b	v31, v21, v9
     770:      	bit.16b	v31, v22, v12
     774:      	bit.16b	v8, v22, v11
     778:      	bif.16b	v8, v23, v14
     77c:      	bif.16b	v31, v23, v13
     780:      	fdiv.4s	v30, v30, v31
     784:      	fdiv.4s	v29, v29, v8
     788:      	add	x9, x16, x4
     78c:      	ldp	q8, q31, [x9]
     790:      	fmul.4s	v29, v8, v29
     794:      	fmul.4s	v30, v31, v30
     798:      	add	x9, x7, x4
     79c:      	stp	q29, q30, [x9]
     7a0:      	add	x4, x4, #0x20
     7a4:      	cmp	x4, #0x100
     7a8:      	b.ne	0x610 <ltmp0+0x610>
     7ac:      	b	0x1e0 <ltmp0+0x1e0>
     7b0:      	lsr	x25, x23, #3
     7b4:      	cmp	x23, #0x8
     7b8:      	b.hs	0xc64 <ltmp0+0xc64>
     7bc:      	and	w9, w23, #0x7
     7c0:      	mov	w22, #0x20              ; =32
     7c4:      	cbz	w9, 0xf8 <ltmp0+0xf8>
     7c8:      	dup.4s	v24, w9
     7cc:      	adrp	x9, 0x0 <ltmp0>
     7d0:      	ldr	q25, [x9]
     7d4:      	adrp	x9, 0x0 <ltmp0>
     7d8:      	ldr	q28, [x9]
     7dc:      	cmhi.4s	v28, v24, v28
     7e0:      	cmhi.4s	v15, v24, v25
     7e4:      	uzp1.8h	v25, v15, v28
     7e8:      	umaxv.8h	h24, v25
     7ec:      	fmov	w9, s24
     7f0:      	tbz	w9, #0x0, 0xf8 <ltmp0+0xf8>
     7f4:      	ldr	x26, [x0]
     7f8:      	ldr	x24, [x0, #0x10]
     7fc:      	ldr	x23, [x0, #0x30]
     800:      	sshll.2d	v24, v15, #0x0
     804:      	sshll.2d	v30, v28, #0x0
     808:      	sshll2.2d	v10, v15, #0x0
     80c:      	sshll2.2d	v9, v28, #0x0
     810:      	adrp	x9, 0x0 <ltmp0>
     814:      	ldr	q31, [x9]
     818:      	and.16b	v31, v9, v31
     81c:      	str	q31, [sp, #0xe0]
     820:      	adrp	x9, 0x0 <ltmp0>
     824:      	ldr	q31, [x9]
     828:      	and.16b	v31, v10, v31
     82c:      	str	q31, [sp, #0xb0]
     830:      	adrp	x9, 0x0 <ltmp0>
     834:      	ldr	q31, [x9]
     838:      	and.16b	v30, v30, v31
     83c:      	str	q30, [sp, #0xc0]
     840:      	adrp	x9, 0x0 <ltmp0>
     844:      	ldr	q30, [x9]
     848:      	and.16b	v24, v24, v30
     84c:      	ubfiz	w9, w30, #2, #27
     850:      	orr	w9, w9, w25
     854:      	dup.4s	v30, w9
     858:      	and.16b	v12, v15, v30
     85c:      	and.16b	v30, v28, v30
     860:      	ushll.2d	v13, v12, #0x0
     864:      	subs	x9, x26, x23
     868:      	lsr	x9, x9, #2
     86c:      	ccmp	x9, x10, #0x0, hs
     870:      	cset	w9, hi
     874:      	subs	x17, x23, x26
     878:      	lsr	x17, x17, #2
     87c:      	ccmp	x17, x10, #0x0, hs
     880:      	csinc	w17, w9, wzr, ls
     884:      	subs	x9, x24, x23
     888:      	lsr	x9, x9, #2
     88c:      	ccmp	x9, x10, #0x0, hs
     890:      	cset	w9, hi
     894:      	subs	x2, x23, x24
     898:      	lsr	x2, x2, #2
     89c:      	ccmp	x2, x10, #0x0, hs
     8a0:      	xtn.2s	v31, v13
     8a4:      	str	d31, [sp, #0xf0]
     8a8:      	fmov	x2, d13
     8ac:      	ushll2.2d	v13, v30, #0x0
     8b0:      	ushll2.2d	v12, v12, #0x0
     8b4:      	ushll.2d	v30, v30, #0x0
     8b8:      	csinc	w9, w9, wzr, ls
     8bc:      	add	x2, x2, x2, lsl #6
     8c0:      	lsl	x4, x2, #2
     8c4:      	xtn.2s	v31, v13
     8c8:      	str	d31, [sp, #0x90]
     8cc:      	xtn.2s	v30, v30
     8d0:      	str	d30, [sp, #0x80]
     8d4:      	xtn.2s	v30, v12
     8d8:      	str	d30, [sp, #0x70]
     8dc:      	cmp	w17, #0x1
     8e0:      	str	q15, [sp, #0x100]
     8e4:      	b.ne	0x1298 <ltmp0+0x1298>
     8e8:      	cbz	w9, 0x1298 <ltmp0+0x1298>
     8ec:      	mov	x17, #0x0               ; =0
     8f0:      	add	x5, x23, x4
     8f4:      	add	x6, x24, x4
     8f8:      	add	x7, x26, x4
     8fc:      	b	0x90c <ltmp0+0x90c>
     900:      	add	x17, x17, #0x20
     904:      	cmp	x17, #0x100
     908:      	b.eq	0x1ba8 <ltmp0+0x1ba8>
     90c:      	ldr	q30, [x20]
     910:      	and.16b	v30, v25, v30
     914:      	addv.8h	h9, v30
     918:      	fmov	w4, s9
     91c:      	add	x9, x7, x17
     920:      	movi.2d	v10, #0000000000000000
     924:      	movi.2d	v30, #0000000000000000
     928:      	tbnz	w4, #0x0, 0xb44 <ltmp0+0xb44>
     92c:      	and	w4, w4, #0xff
     930:      	tbnz	w4, #0x1, 0xb50 <ltmp0+0xb50>
     934:      	tbnz	w4, #0x2, 0xb5c <ltmp0+0xb5c>
     938:      	tbnz	w4, #0x3, 0xb68 <ltmp0+0xb68>
     93c:      	tbnz	w4, #0x4, 0xb74 <ltmp0+0xb74>
     940:      	tbnz	w4, #0x5, 0xb80 <ltmp0+0xb80>
     944:      	tbnz	w4, #0x6, 0xb8c <ltmp0+0xb8c>
     948:      	tbnz	w4, #0x7, 0xb98 <ltmp0+0xb98>
     94c:      	fmov	w4, s9
     950:      	add	x9, x6, x17
     954:      	movi.2d	v13, #0000000000000000
     958:      	movi.2d	v12, #0000000000000000
     95c:      	tbnz	w4, #0x0, 0xbb4 <ltmp0+0xbb4>
     960:      	and	w4, w4, #0xff
     964:      	tbnz	w4, #0x1, 0xbc0 <ltmp0+0xbc0>
     968:      	tbnz	w4, #0x2, 0xbcc <ltmp0+0xbcc>
     96c:      	tbnz	w4, #0x3, 0xbd8 <ltmp0+0xbd8>
     970:      	tbnz	w4, #0x4, 0xbe4 <ltmp0+0xbe4>
     974:      	tbnz	w4, #0x5, 0xbf0 <ltmp0+0xbf0>
     978:      	tbnz	w4, #0x6, 0xbfc <ltmp0+0xbfc>
     97c:      	tbz	w4, #0x7, 0x988 <ltmp0+0x988>
     980:      	add	x9, x9, #0x1c
     984:      	ld1.s	{ v12 }[3], [x9]
     988:      	fneg.4s	v14, v10
     98c:      	and.16b	v14, v15, v14
     990:      	fcmge.4s	v15, v14, v27
     994:      	fcmge.4s	v11, v26, v14
     998:      	and.16b	v11, v15, v11
     99c:      	and.16b	v11, v11, v14
     9a0:      	fmul.4s	v15, v11, v2
     9a4:      	mov.16b	v31, v4
     9a8:      	bsl.16b	v31, v3, v15
     9ac:      	fadd.4s	v15, v15, v31
     9b0:      	fsub.4s	v31, v15, v31
     9b4:      	fcvtzs.4s	v31, v31
     9b8:      	scvtf.4s	v15, v31
     9bc:      	fmul.4s	v8, v15, v5
     9c0:      	fadd.4s	v8, v11, v8
     9c4:      	fmul.4s	v11, v15, v6
     9c8:      	fadd.4s	v8, v8, v11
     9cc:      	fmul.4s	v11, v8, v7
     9d0:      	fadd.4s	v11, v11, v16
     9d4:      	fmul.4s	v11, v8, v11
     9d8:      	fadd.4s	v11, v11, v17
     9dc:      	fmul.4s	v11, v8, v11
     9e0:      	fadd.4s	v11, v11, v18
     9e4:      	fmul.4s	v11, v8, v11
     9e8:      	fadd.4s	v11, v11, v19
     9ec:      	fmul.4s	v11, v8, v11
     9f0:      	fadd.4s	v11, v11, v20
     9f4:      	fmul.4s	v15, v8, v8
     9f8:      	fmul.4s	v11, v15, v11
     9fc:      	fadd.4s	v8, v8, v11
     a00:      	fadd.4s	v8, v8, v21
     a04:      	sshr.4s	v11, v31, #0x1
     a08:      	shl.4s	v15, v11, #0x17
     a0c:      	add.4s	v15, v15, v21
     a10:      	fmul.4s	v8, v8, v15
     a14:      	sub.4s	v31, v31, v11
     a18:      	shl.4s	v31, v31, #0x17
     a1c:      	add.4s	v31, v31, v21
     a20:      	fmul.4s	v31, v8, v31
     a24:      	fcmgt.4s	v8, v27, v14
     a28:      	fcmgt.4s	v11, v14, v26
     a2c:      	fcmeq.4s	v14, v14, v14
     a30:      	fadd.4s	v31, v31, v21
     a34:      	bit.16b	v31, v21, v8
     a38:      	bit.16b	v31, v22, v11
     a3c:      	bif.16b	v31, v23, v14
     a40:      	fdiv.4s	v31, v10, v31
     a44:      	fmov	w4, s9
     a48:      	fmul.4s	v9, v13, v31
     a4c:      	add	x9, x5, x17
     a50:      	tbnz	w4, #0x0, 0xc0c <ltmp0+0xc0c>
     a54:      	and	w4, w4, #0xff
     a58:      	tbnz	w4, #0x1, 0xc18 <ltmp0+0xc18>
     a5c:      	ldr	q15, [sp, #0x100]
     a60:      	tbnz	w4, #0x2, 0xc28 <ltmp0+0xc28>
     a64:      	tbz	w4, #0x3, 0xa70 <ltmp0+0xa70>
     a68:      	add	x2, x9, #0xc
     a6c:      	st1.s	{ v9 }[3], [x2]
     a70:      	fneg.4s	v31, v30
     a74:      	and.16b	v31, v28, v31
     a78:      	fcmge.4s	v8, v31, v27
     a7c:      	fcmge.4s	v9, v26, v31
     a80:      	and.16b	v8, v8, v9
     a84:      	and.16b	v8, v8, v31
     a88:      	fmul.4s	v9, v8, v2
     a8c:      	mov.16b	v10, v4
     a90:      	bsl.16b	v10, v3, v9
     a94:      	fadd.4s	v9, v9, v10
     a98:      	fsub.4s	v9, v9, v10
     a9c:      	fcvtzs.4s	v9, v9
     aa0:      	scvtf.4s	v10, v9
     aa4:      	fmul.4s	v11, v10, v5
     aa8:      	fadd.4s	v8, v8, v11
     aac:      	fmul.4s	v10, v10, v6
     ab0:      	fadd.4s	v8, v8, v10
     ab4:      	fmul.4s	v10, v8, v7
     ab8:      	fadd.4s	v10, v10, v16
     abc:      	fmul.4s	v10, v8, v10
     ac0:      	fadd.4s	v10, v10, v17
     ac4:      	fmul.4s	v10, v8, v10
     ac8:      	fadd.4s	v10, v10, v18
     acc:      	fmul.4s	v10, v8, v10
     ad0:      	fadd.4s	v10, v10, v19
     ad4:      	fmul.4s	v10, v8, v10
     ad8:      	fadd.4s	v10, v10, v20
     adc:      	fmul.4s	v11, v8, v8
     ae0:      	fmul.4s	v10, v11, v10
     ae4:      	fadd.4s	v8, v8, v10
     ae8:      	fadd.4s	v8, v8, v21
     aec:      	sshr.4s	v10, v9, #0x1
     af0:      	shl.4s	v11, v10, #0x17
     af4:      	add.4s	v11, v11, v21
     af8:      	fmul.4s	v8, v8, v11
     afc:      	sub.4s	v9, v9, v10
     b00:      	shl.4s	v9, v9, #0x17
     b04:      	add.4s	v9, v9, v21
     b08:      	fmul.4s	v8, v8, v9
     b0c:      	fcmgt.4s	v9, v27, v31
     b10:      	fcmgt.4s	v10, v31, v26
     b14:      	fcmeq.4s	v31, v31, v31
     b18:      	fadd.4s	v8, v8, v21
     b1c:      	bit.16b	v8, v21, v9
     b20:      	bit.16b	v8, v22, v10
     b24:      	bsl.16b	v31, v8, v23
     b28:      	fdiv.4s	v30, v30, v31
     b2c:      	fmul.4s	v30, v12, v30
     b30:      	tbnz	w4, #0x4, 0xc38 <ltmp0+0xc38>
     b34:      	tbnz	w4, #0x5, 0xc40 <ltmp0+0xc40>
     b38:      	tbnz	w4, #0x6, 0xc4c <ltmp0+0xc4c>
     b3c:      	tbz	w4, #0x7, 0x900 <ltmp0+0x900>
     b40:      	b	0xc58 <ltmp0+0xc58>
     b44:      	ldr	s10, [x9]
     b48:      	and	w4, w4, #0xff
     b4c:      	tbz	w4, #0x1, 0x934 <ltmp0+0x934>
     b50:      	add	x2, x9, #0x4
     b54:      	ld1.s	{ v10 }[1], [x2]
     b58:      	tbz	w4, #0x2, 0x938 <ltmp0+0x938>
     b5c:      	add	x2, x9, #0x8
     b60:      	ld1.s	{ v10 }[2], [x2]
     b64:      	tbz	w4, #0x3, 0x93c <ltmp0+0x93c>
     b68:      	add	x2, x9, #0xc
     b6c:      	ld1.s	{ v10 }[3], [x2]
     b70:      	tbz	w4, #0x4, 0x940 <ltmp0+0x940>
     b74:      	add	x2, x9, #0x10
     b78:      	ld1.s	{ v30 }[0], [x2]
     b7c:      	tbz	w4, #0x5, 0x944 <ltmp0+0x944>
     b80:      	add	x2, x9, #0x14
     b84:      	ld1.s	{ v30 }[1], [x2]
     b88:      	tbz	w4, #0x6, 0x948 <ltmp0+0x948>
     b8c:      	add	x2, x9, #0x18
     b90:      	ld1.s	{ v30 }[2], [x2]
     b94:      	tbz	w4, #0x7, 0x94c <ltmp0+0x94c>
     b98:      	add	x9, x9, #0x1c
     b9c:      	ld1.s	{ v30 }[3], [x9]
     ba0:      	fmov	w4, s9
     ba4:      	add	x9, x6, x17
     ba8:      	movi.2d	v13, #0000000000000000
     bac:      	movi.2d	v12, #0000000000000000
     bb0:      	tbz	w4, #0x0, 0x960 <ltmp0+0x960>
     bb4:      	ldr	s13, [x9]
     bb8:      	and	w4, w4, #0xff
     bbc:      	tbz	w4, #0x1, 0x968 <ltmp0+0x968>
     bc0:      	add	x2, x9, #0x4
     bc4:      	ld1.s	{ v13 }[1], [x2]
     bc8:      	tbz	w4, #0x2, 0x96c <ltmp0+0x96c>
     bcc:      	add	x2, x9, #0x8
     bd0:      	ld1.s	{ v13 }[2], [x2]
     bd4:      	tbz	w4, #0x3, 0x970 <ltmp0+0x970>
     bd8:      	add	x2, x9, #0xc
     bdc:      	ld1.s	{ v13 }[3], [x2]
     be0:      	tbz	w4, #0x4, 0x974 <ltmp0+0x974>
     be4:      	add	x2, x9, #0x10
     be8:      	ld1.s	{ v12 }[0], [x2]
     bec:      	tbz	w4, #0x5, 0x978 <ltmp0+0x978>
     bf0:      	add	x2, x9, #0x14
     bf4:      	ld1.s	{ v12 }[1], [x2]
     bf8:      	tbz	w4, #0x6, 0x97c <ltmp0+0x97c>
     bfc:      	add	x2, x9, #0x18
     c00:      	ld1.s	{ v12 }[2], [x2]
     c04:      	tbnz	w4, #0x7, 0x980 <ltmp0+0x980>
     c08:      	b	0x988 <ltmp0+0x988>
     c0c:      	str	s9, [x9]
     c10:      	and	w4, w4, #0xff
     c14:      	tbz	w4, #0x1, 0xa5c <ltmp0+0xa5c>
     c18:      	add	x2, x9, #0x4
     c1c:      	st1.s	{ v9 }[1], [x2]
     c20:      	ldr	q15, [sp, #0x100]
     c24:      	tbz	w4, #0x2, 0xa64 <ltmp0+0xa64>
     c28:      	add	x2, x9, #0x8
     c2c:      	st1.s	{ v9 }[2], [x2]
     c30:      	tbnz	w4, #0x3, 0xa68 <ltmp0+0xa68>
     c34:      	b	0xa70 <ltmp0+0xa70>
     c38:      	str	s30, [x9, #0x10]
     c3c:      	tbz	w4, #0x5, 0xb38 <ltmp0+0xb38>
     c40:      	add	x2, x9, #0x14
     c44:      	st1.s	{ v30 }[1], [x2]
     c48:      	tbz	w4, #0x6, 0xb3c <ltmp0+0xb3c>
     c4c:      	add	x2, x9, #0x18
     c50:      	st1.s	{ v30 }[2], [x2]
     c54:      	tbz	w4, #0x7, 0x900 <ltmp0+0x900>
     c58:      	add	x9, x9, #0x1c
     c5c:      	st1.s	{ v30 }[3], [x9]
     c60:      	b	0x900 <ltmp0+0x900>
     c64:      	mov	x24, #0x0               ; =0
     c68:      	ldr	x26, [x0]
     c6c:      	ldr	x5, [x0, #0x10]
     c70:      	ldr	x6, [x0, #0x30]
     c74:      	subs	x9, x26, x6
     c78:      	lsr	x9, x9, #2
     c7c:      	ccmp	x9, x10, #0x0, hs
     c80:      	cset	w9, hi
     c84:      	subs	x17, x6, x26
     c88:      	lsr	x17, x17, #2
     c8c:      	ccmp	x17, x10, #0x0, hs
     c90:      	csinc	w9, w9, wzr, ls
     c94:      	subs	x17, x5, x6
     c98:      	lsr	x17, x17, #2
     c9c:      	ccmp	x17, x10, #0x0, hs
     ca0:      	cset	w17, hi
     ca4:      	subs	x4, x6, x5
     ca8:      	lsr	x4, x4, #2
     cac:      	ccmp	x4, x10, #0x0, hs
     cb0:      	csinc	w17, w17, wzr, ls
     cb4:      	and	w7, w9, w17
     cb8:      	lsl	w19, w30, #2
     cbc:      	and	x9, x30, #0x7ffffff
     cc0:      	add	x9, x9, x9, lsl #6
     cc4:      	lsl	x9, x9, #4
     cc8:      	add	x21, x6, x9
     ccc:      	add	x22, x5, x9
     cd0:      	add	x17, x26, x9
     cd4:      	b	0xdc0 <ltmp0+0xdc0>
     cd8:      	movi.2d	v28, #0000000000000000
     cdc:      	mov.s	v28[0], v25[0]
     ce0:      	fneg.4s	v25, v28
     ce4:      	movi.2d	v29, #0000000000000000
     ce8:      	mov.s	v29[0], v25[0]
     cec:      	fcmge.4s	v25, v29, v27
     cf0:      	fcmge.4s	v30, v26, v29
     cf4:      	and.16b	v25, v25, v30
     cf8:      	and.16b	v25, v25, v29
     cfc:      	fmul.4s	v30, v25, v2
     d00:      	mov.16b	v31, v4
     d04:      	bsl.16b	v31, v3, v30
     d08:      	fadd.4s	v30, v30, v31
     d0c:      	fsub.4s	v30, v30, v31
     d10:      	fcvtzs.4s	v30, v30
     d14:      	scvtf.4s	v31, v30
     d18:      	fmul.4s	v8, v31, v5
     d1c:      	fadd.4s	v25, v25, v8
     d20:      	fmul.4s	v31, v31, v6
     d24:      	fadd.4s	v25, v25, v31
     d28:      	fmul.4s	v31, v25, v7
     d2c:      	fadd.4s	v31, v31, v16
     d30:      	fmul.4s	v31, v25, v31
     d34:      	fadd.4s	v31, v31, v17
     d38:      	fmul.4s	v31, v25, v31
     d3c:      	fadd.4s	v31, v31, v18
     d40:      	fmul.4s	v31, v25, v31
     d44:      	fadd.4s	v31, v31, v19
     d48:      	fmul.4s	v31, v25, v31
     d4c:      	fadd.4s	v31, v31, v20
     d50:      	fmul.4s	v8, v25, v25
     d54:      	fmul.4s	v31, v8, v31
     d58:      	fadd.4s	v25, v25, v31
     d5c:      	fadd.4s	v25, v25, v21
     d60:      	sshr.4s	v31, v30, #0x1
     d64:      	shl.4s	v8, v31, #0x17
     d68:      	add.4s	v8, v8, v21
     d6c:      	fmul.4s	v25, v25, v8
     d70:      	sub.4s	v30, v30, v31
     d74:      	shl.4s	v30, v30, #0x17
     d78:      	add.4s	v30, v30, v21
     d7c:      	fmul.4s	v25, v25, v30
     d80:      	fcmgt.4s	v30, v27, v29
     d84:      	fcmgt.4s	v31, v29, v26
     d88:      	fcmeq.4s	v29, v29, v29
     d8c:      	fadd.4s	v25, v25, v21
     d90:      	bit.16b	v25, v21, v30
     d94:      	bit.16b	v25, v22, v31
     d98:      	bif.16b	v25, v23, v29
     d9c:      	fdiv.4s	v25, v28, v25
     da0:      	fmul.4s	v24, v24, v25
     da4:      	str	s24, [x6, x4]
     da8:      	add	x24, x24, #0x1
     dac:      	add	x21, x21, #0x104
     db0:      	add	x22, x22, #0x104
     db4:      	add	x17, x17, #0x104
     db8:      	cmp	x24, x25
     dbc:      	b.eq	0x7bc <ltmp0+0x7bc>
     dc0:      	add	w9, w24, w19
     dc4:      	and	x9, x9, #0x1fffffff
     dc8:      	add	x9, x9, x9, lsl #6
     dcc:      	lsl	x4, x9, #2
     dd0:      	mov	x9, #0x0                ; =0
     dd4:      	cbz	w7, 0x1048 <ltmp0+0x1048>
     dd8:      	add	x2, x17, x9
     ddc:      	ldp	q24, q25, [x2]
     de0:      	fneg.4s	v28, v25
     de4:      	fneg.4s	v29, v24
     de8:      	fcmge.4s	v30, v0, v24
     dec:      	fcmge.4s	v31, v0, v25
     df0:      	fcmge.4s	v8, v24, v1
     df4:      	fcmge.4s	v9, v25, v1
     df8:      	and.16b	v31, v31, v9
     dfc:      	and.16b	v30, v30, v8
     e00:      	and.16b	v29, v30, v29
     e04:      	and.16b	v28, v31, v28
     e08:      	fmul.4s	v30, v28, v2
     e0c:      	fmul.4s	v31, v29, v2
     e10:      	mov.16b	v8, v4
     e14:      	bsl.16b	v8, v3, v31
     e18:      	mov.16b	v9, v4
     e1c:      	bsl.16b	v9, v3, v30
     e20:      	fadd.4s	v30, v30, v9
     e24:      	fadd.4s	v31, v31, v8
     e28:      	fsub.4s	v31, v31, v8
     e2c:      	fsub.4s	v30, v30, v9
     e30:      	fcvtzs.4s	v30, v30
     e34:      	fcvtzs.4s	v31, v31
     e38:      	scvtf.4s	v8, v31
     e3c:      	scvtf.4s	v9, v30
     e40:      	fmul.4s	v10, v9, v5
     e44:      	fmul.4s	v11, v8, v5
     e48:      	fadd.4s	v29, v29, v11
     e4c:      	fadd.4s	v28, v28, v10
     e50:      	fmul.4s	v8, v8, v6
     e54:      	fmul.4s	v9, v9, v6
     e58:      	fadd.4s	v28, v28, v9
     e5c:      	fadd.4s	v29, v29, v8
     e60:      	fmul.4s	v8, v29, v7
     e64:      	fmul.4s	v9, v28, v7
     e68:      	fadd.4s	v9, v9, v16
     e6c:      	fadd.4s	v8, v8, v16
     e70:      	fmul.4s	v8, v29, v8
     e74:      	fmul.4s	v9, v28, v9
     e78:      	fadd.4s	v9, v9, v17
     e7c:      	fadd.4s	v8, v8, v17
     e80:      	fmul.4s	v8, v29, v8
     e84:      	fmul.4s	v9, v28, v9
     e88:      	fadd.4s	v9, v9, v18
     e8c:      	fadd.4s	v8, v8, v18
     e90:      	fmul.4s	v8, v29, v8
     e94:      	fmul.4s	v9, v28, v9
     e98:      	fadd.4s	v9, v9, v19
     e9c:      	fadd.4s	v8, v8, v19
     ea0:      	fmul.4s	v8, v29, v8
     ea4:      	fmul.4s	v9, v28, v9
     ea8:      	fadd.4s	v9, v9, v20
     eac:      	fadd.4s	v8, v8, v20
     eb0:      	fmul.4s	v10, v28, v28
     eb4:      	fmul.4s	v11, v29, v29
     eb8:      	fmul.4s	v8, v11, v8
     ebc:      	fmul.4s	v9, v10, v9
     ec0:      	fadd.4s	v28, v28, v9
     ec4:      	fadd.4s	v29, v29, v8
     ec8:      	sshr.4s	v8, v31, #0x1
     ecc:      	fadd.4s	v29, v29, v21
     ed0:      	sshr.4s	v9, v30, #0x1
     ed4:      	shl.4s	v10, v9, #0x17
     ed8:      	shl.4s	v11, v8, #0x17
     edc:      	add.4s	v11, v11, v21
     ee0:      	add.4s	v10, v10, v21
     ee4:      	fadd.4s	v28, v28, v21
     ee8:      	fmul.4s	v28, v28, v10
     eec:      	sub.4s	v30, v30, v9
     ef0:      	sub.4s	v31, v31, v8
     ef4:      	shl.4s	v31, v31, #0x17
     ef8:      	shl.4s	v30, v30, #0x17
     efc:      	fmul.4s	v29, v29, v11
     f00:      	add.4s	v30, v30, v21
     f04:      	add.4s	v31, v31, v21
     f08:      	fmul.4s	v29, v29, v31
     f0c:      	fmul.4s	v28, v28, v30
     f10:      	fcmgt.4s	v30, v25, v0
     f14:      	fcmgt.4s	v31, v24, v0
     f18:      	fcmgt.4s	v8, v1, v24
     f1c:      	fcmgt.4s	v9, v1, v25
     f20:      	fcmeq.4s	v10, v25, v25
     f24:      	fadd.4s	v28, v28, v21
     f28:      	fadd.4s	v29, v29, v21
     f2c:      	fcmeq.4s	v11, v24, v24
     f30:      	bit.16b	v29, v21, v31
     f34:      	bit.16b	v28, v21, v30
     f38:      	bit.16b	v28, v22, v9
     f3c:      	bit.16b	v29, v22, v8
     f40:      	bif.16b	v29, v23, v11
     f44:      	bif.16b	v28, v23, v10
     f48:      	fdiv.4s	v25, v25, v28
     f4c:      	fdiv.4s	v24, v24, v29
     f50:      	add	x2, x22, x9
     f54:      	ldp	q29, q28, [x2]
     f58:      	fmul.4s	v24, v29, v24
     f5c:      	fmul.4s	v25, v28, v25
     f60:      	add	x2, x21, x9
     f64:      	stp	q24, q25, [x2]
     f68:      	add	x9, x9, #0x20
     f6c:      	cmp	x9, #0x100
     f70:      	b.ne	0xdd8 <ltmp0+0xdd8>
     f74:      	add	x4, x4, #0x100
     f78:      	ldr	s24, [x26, x4]
     f7c:      	fneg.4s	v25, v24
     f80:      	movi.2d	v28, #0000000000000000
     f84:      	mov.s	v28[0], v25[0]
     f88:      	fcmge.4s	v25, v28, v27
     f8c:      	fcmge.4s	v29, v26, v28
     f90:      	and.16b	v25, v25, v29
     f94:      	and.16b	v25, v25, v28
     f98:      	fmul.4s	v29, v25, v2
     f9c:      	mov.16b	v30, v4
     fa0:      	bsl.16b	v30, v3, v29
     fa4:      	fadd.4s	v29, v29, v30
     fa8:      	fsub.4s	v29, v29, v30
     fac:      	fcvtzs.4s	v29, v29
     fb0:      	scvtf.4s	v30, v29
     fb4:      	fmul.4s	v31, v30, v5
     fb8:      	fadd.4s	v25, v25, v31
     fbc:      	fmul.4s	v30, v30, v6
     fc0:      	fadd.4s	v25, v25, v30
     fc4:      	fmul.4s	v30, v25, v7
     fc8:      	fadd.4s	v30, v30, v16
     fcc:      	fmul.4s	v30, v25, v30
     fd0:      	fadd.4s	v30, v30, v17
     fd4:      	fmul.4s	v30, v25, v30
     fd8:      	fadd.4s	v30, v30, v18
     fdc:      	fmul.4s	v30, v25, v30
     fe0:      	fadd.4s	v30, v30, v19
     fe4:      	fmul.4s	v30, v25, v30
     fe8:      	fadd.4s	v30, v30, v20
     fec:      	fmul.4s	v31, v25, v25
     ff0:      	fmul.4s	v30, v31, v30
     ff4:      	fadd.4s	v25, v25, v30
     ff8:      	fadd.4s	v25, v25, v21
     ffc:      	sshr.4s	v30, v29, #0x1
    1000:      	shl.4s	v31, v30, #0x17
    1004:      	add.4s	v31, v31, v21
    1008:      	fmul.4s	v25, v25, v31
    100c:      	sub.4s	v29, v29, v30
    1010:      	shl.4s	v29, v29, #0x17
    1014:      	add.4s	v29, v29, v21
    1018:      	fmul.4s	v25, v25, v29
    101c:      	fcmgt.4s	v29, v27, v28
    1020:      	fcmgt.4s	v30, v28, v26
    1024:      	fcmeq.4s	v28, v28, v28
    1028:      	fadd.4s	v25, v25, v21
    102c:      	bit.16b	v25, v21, v29
    1030:      	bit.16b	v25, v22, v30
    1034:      	bif.16b	v25, v23, v28
    1038:      	fdiv.4s	v24, v24, v25
    103c:      	ldr	s25, [x5, x4]
    1040:      	fmul.4s	v24, v25, v24
    1044:      	b	0xda4 <ltmp0+0xda4>
    1048:      	add	x2, x26, x4
    104c:      	ldp	q24, q25, [x2, #0xc0]
    1050:      	str	q24, [sp, #0x460]
    1054:      	str	q25, [sp, #0x470]
    1058:      	ldp	q24, q25, [x2, #0xe0]
    105c:      	str	q24, [sp, #0x480]
    1060:      	str	q25, [sp, #0x490]
    1064:      	ldp	q24, q25, [x2, #0x80]
    1068:      	str	q24, [sp, #0x420]
    106c:      	str	q25, [sp, #0x430]
    1070:      	ldp	q24, q25, [x2, #0xa0]
    1074:      	str	q24, [sp, #0x440]
    1078:      	str	q25, [sp, #0x450]
    107c:      	ldp	q24, q25, [x2, #0x40]
    1080:      	stp	q24, q25, [sp, #0x3e0]
    1084:      	ldp	q24, q25, [x2, #0x60]
    1088:      	str	q24, [sp, #0x400]
    108c:      	str	q25, [sp, #0x410]
    1090:      	ldp	q24, q25, [x2]
    1094:      	stp	q24, q25, [sp, #0x3a0]
    1098:      	ldp	q24, q25, [x2, #0x20]
    109c:      	stp	q24, q25, [sp, #0x3c0]
    10a0:      	add	x2, x5, x4
    10a4:      	ldp	q24, q25, [x2, #0xc0]
    10a8:      	stp	q24, q25, [sp, #0x340]
    10ac:      	ldp	q24, q25, [x2, #0xe0]
    10b0:      	stp	q24, q25, [sp, #0x360]
    10b4:      	ldp	q24, q25, [x2, #0x80]
    10b8:      	stp	q24, q25, [sp, #0x300]
    10bc:      	ldp	q24, q25, [x2, #0xa0]
    10c0:      	stp	q24, q25, [sp, #0x320]
    10c4:      	ldp	q24, q25, [x2, #0x40]
    10c8:      	stp	q24, q25, [sp, #0x2c0]
    10cc:      	ldp	q24, q25, [x2, #0x60]
    10d0:      	stp	q24, q25, [sp, #0x2e0]
    10d4:      	ldp	q24, q25, [x2]
    10d8:      	ldp	q28, q29, [x2, #0x20]
    10dc:      	add	x4, x4, #0x100
    10e0:      	stp	q24, q25, [sp, #0x280]
    10e4:      	ldr	s25, [x26, x4]
    10e8:      	str	q25, [sp, #0x4a0]
    10ec:      	stp	q28, q29, [sp, #0x2a0]
    10f0:      	ldr	s24, [x5, x4]
    10f4:      	str	q24, [sp, #0x380]
    10f8:      	add	x2, x15, x9
    10fc:      	ldp	q28, q29, [x2]
    1100:      	fneg.4s	v30, v29
    1104:      	fneg.4s	v31, v28
    1108:      	fcmge.4s	v8, v0, v28
    110c:      	fcmge.4s	v9, v0, v29
    1110:      	fcmge.4s	v10, v28, v1
    1114:      	fcmge.4s	v11, v29, v1
    1118:      	and.16b	v9, v9, v11
    111c:      	and.16b	v8, v8, v10
    1120:      	and.16b	v31, v8, v31
    1124:      	and.16b	v30, v9, v30
    1128:      	fmul.4s	v8, v30, v2
    112c:      	fmul.4s	v9, v31, v2
    1130:      	mov.16b	v10, v4
    1134:      	bsl.16b	v10, v3, v9
    1138:      	mov.16b	v11, v4
    113c:      	bsl.16b	v11, v3, v8
    1140:      	fadd.4s	v8, v8, v11
    1144:      	fadd.4s	v9, v9, v10
    1148:      	fsub.4s	v9, v9, v10
    114c:      	fsub.4s	v8, v8, v11
    1150:      	fcvtzs.4s	v8, v8
    1154:      	fcvtzs.4s	v9, v9
    1158:      	scvtf.4s	v10, v9
    115c:      	scvtf.4s	v11, v8
    1160:      	fmul.4s	v12, v11, v5
    1164:      	fmul.4s	v13, v10, v5
    1168:      	fadd.4s	v31, v31, v13
    116c:      	fadd.4s	v30, v30, v12
    1170:      	fmul.4s	v10, v10, v6
    1174:      	fmul.4s	v11, v11, v6
    1178:      	fadd.4s	v30, v30, v11
    117c:      	fadd.4s	v31, v31, v10
    1180:      	fmul.4s	v10, v31, v7
    1184:      	fmul.4s	v11, v30, v7
    1188:      	fadd.4s	v11, v11, v16
    118c:      	fadd.4s	v10, v10, v16
    1190:      	fmul.4s	v10, v31, v10
    1194:      	fmul.4s	v11, v30, v11
    1198:      	fadd.4s	v11, v11, v17
    119c:      	fadd.4s	v10, v10, v17
    11a0:      	fmul.4s	v10, v31, v10
    11a4:      	fmul.4s	v11, v30, v11
    11a8:      	fadd.4s	v11, v11, v18
    11ac:      	fadd.4s	v10, v10, v18
    11b0:      	fmul.4s	v10, v31, v10
    11b4:      	fmul.4s	v11, v30, v11
    11b8:      	fadd.4s	v11, v11, v19
    11bc:      	fadd.4s	v10, v10, v19
    11c0:      	fmul.4s	v10, v31, v10
    11c4:      	fmul.4s	v11, v30, v11
    11c8:      	fadd.4s	v11, v11, v20
    11cc:      	fadd.4s	v10, v10, v20
    11d0:      	fmul.4s	v12, v30, v30
    11d4:      	fmul.4s	v13, v31, v31
    11d8:      	fmul.4s	v10, v13, v10
    11dc:      	fmul.4s	v11, v12, v11
    11e0:      	fadd.4s	v30, v30, v11
    11e4:      	fadd.4s	v31, v31, v10
    11e8:      	sshr.4s	v10, v9, #0x1
    11ec:      	fadd.4s	v31, v31, v21
    11f0:      	sshr.4s	v11, v8, #0x1
    11f4:      	shl.4s	v12, v11, #0x17
    11f8:      	shl.4s	v13, v10, #0x17
    11fc:      	add.4s	v13, v13, v21
    1200:      	add.4s	v12, v12, v21
    1204:      	fadd.4s	v30, v30, v21
    1208:      	fmul.4s	v30, v30, v12
    120c:      	sub.4s	v8, v8, v11
    1210:      	sub.4s	v9, v9, v10
    1214:      	shl.4s	v9, v9, #0x17
    1218:      	shl.4s	v8, v8, #0x17
    121c:      	fmul.4s	v31, v31, v13
    1220:      	add.4s	v8, v8, v21
    1224:      	add.4s	v9, v9, v21
    1228:      	fmul.4s	v31, v31, v9
    122c:      	fmul.4s	v30, v30, v8
    1230:      	fcmgt.4s	v8, v29, v0
    1234:      	fcmgt.4s	v9, v28, v0
    1238:      	fcmgt.4s	v10, v1, v28
    123c:      	fcmgt.4s	v11, v1, v29
    1240:      	fcmeq.4s	v12, v29, v29
    1244:      	fadd.4s	v30, v30, v21
    1248:      	fadd.4s	v31, v31, v21
    124c:      	fcmeq.4s	v13, v28, v28
    1250:      	bit.16b	v31, v21, v9
    1254:      	bit.16b	v30, v21, v8
    1258:      	bit.16b	v30, v22, v11
    125c:      	bit.16b	v31, v22, v10
    1260:      	bif.16b	v31, v23, v13
    1264:      	bif.16b	v30, v23, v12
    1268:      	fdiv.4s	v29, v29, v30
    126c:      	fdiv.4s	v28, v28, v31
    1270:      	add	x2, x16, x9
    1274:      	ldp	q31, q30, [x2]
    1278:      	fmul.4s	v28, v31, v28
    127c:      	fmul.4s	v29, v30, v29
    1280:      	add	x2, x21, x9
    1284:      	stp	q28, q29, [x2]
    1288:      	add	x9, x9, #0x20
    128c:      	cmp	x9, #0x100
    1290:      	b.ne	0x10f8 <ltmp0+0x10f8>
    1294:      	b	0xcd8 <ltmp0+0xcd8>
    1298:      	mov	x9, #0x0                ; =0
    129c:      	add	x17, x26, x4
    12a0:      	b	0x12c4 <ltmp0+0x12c4>
    12a4:      	add	x2, x15, x9
    12a8:      	ldp	q31, q8, [x2]
    12ac:      	bit.16b	v8, v13, v28
    12b0:      	bif.16b	v30, v31, v15
    12b4:      	stp	q30, q8, [x2]
    12b8:      	add	x9, x9, #0x20
    12bc:      	cmp	x9, #0x100
    12c0:      	b.eq	0x1368 <ltmp0+0x1368>
    12c4:      	ldr	q30, [x20]
    12c8:      	and.16b	v30, v25, v30
    12cc:      	addv.8h	h29, v30
    12d0:      	fmov	w5, s29
    12d4:      	add	x4, x17, x9
    12d8:      	movi.2d	v30, #0000000000000000
    12dc:      	movi.2d	v13, #0000000000000000
    12e0:      	tbnz	w5, #0x0, 0x1308 <ltmp0+0x1308>
    12e4:      	and	w5, w5, #0xff
    12e8:      	tbnz	w5, #0x1, 0x1314 <ltmp0+0x1314>
    12ec:      	tbnz	w5, #0x2, 0x1320 <ltmp0+0x1320>
    12f0:      	tbnz	w5, #0x3, 0x132c <ltmp0+0x132c>
    12f4:      	tbnz	w5, #0x4, 0x1338 <ltmp0+0x1338>
    12f8:      	tbnz	w5, #0x5, 0x1344 <ltmp0+0x1344>
    12fc:      	tbnz	w5, #0x6, 0x1350 <ltmp0+0x1350>
    1300:      	tbz	w5, #0x7, 0x12a4 <ltmp0+0x12a4>
    1304:      	b	0x135c <ltmp0+0x135c>
    1308:      	ldr	s30, [x4]
    130c:      	and	w5, w5, #0xff
    1310:      	tbz	w5, #0x1, 0x12ec <ltmp0+0x12ec>
    1314:      	add	x2, x4, #0x4
    1318:      	ld1.s	{ v30 }[1], [x2]
    131c:      	tbz	w5, #0x2, 0x12f0 <ltmp0+0x12f0>
    1320:      	add	x2, x4, #0x8
    1324:      	ld1.s	{ v30 }[2], [x2]
    1328:      	tbz	w5, #0x3, 0x12f4 <ltmp0+0x12f4>
    132c:      	add	x2, x4, #0xc
    1330:      	ld1.s	{ v30 }[3], [x2]
    1334:      	tbz	w5, #0x4, 0x12f8 <ltmp0+0x12f8>
    1338:      	add	x2, x4, #0x10
    133c:      	ld1.s	{ v13 }[0], [x2]
    1340:      	tbz	w5, #0x5, 0x12fc <ltmp0+0x12fc>
    1344:      	add	x2, x4, #0x14
    1348:      	ld1.s	{ v13 }[1], [x2]
    134c:      	tbz	w5, #0x6, 0x1300 <ltmp0+0x1300>
    1350:      	add	x2, x4, #0x18
    1354:      	ld1.s	{ v13 }[2], [x2]
    1358:      	tbz	w5, #0x7, 0x12a4 <ltmp0+0x12a4>
    135c:      	add	x2, x4, #0x1c
    1360:      	ld1.s	{ v13 }[3], [x2]
    1364:      	b	0x12a4 <ltmp0+0x12a4>
    1368:      	xtn.4h	v25, v15
    136c:      	uzp1.8b	v30, v25, v0
    1370:      	movi.2d	v31, #0000000000000000
    1374:      	mov.b	v31[0], v30[0]
    1378:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    137c:      	ldr	d25, [x9]
    1380:      	str	d25, [sp, #0x30]
    1384:      	and.8b	v25, v31, v25
    1388:      	addv.8b	b25, v25
    138c:      	fmov	w9, s25
    1390:      	str	q31, [sp, #0xa0]
    1394:      	umaxv.8b	b25, v31
    1398:      	fmov	w2, s25
    139c:      	rbit	w17, w9
    13a0:      	clz	w17, w17
    13a4:      	tst	w2, #0x1
    13a8:      	csel	w25, w17, wzr, ne
    13ac:      	mov	w17, #0x40              ; =64
    13b0:      	dup.2d	v25, x17
    13b4:      	movi.2s	v31, #0x41
    13b8:      	ldr	d8, [sp, #0xf0]
    13bc:      	umlal.2d	v24, v8, v31
    13c0:      	movi.2d	v31, #0000000000000000
    13c4:      	mov.b	v31[0], v30[0]
    13c8:      	add.2d	v30, v24, v25
    13cc:      	ushll.2d	v24, v31, #0x0
    13d0:      	shl.2d	v24, v24, #0x3f
    13d4:      	cmlt.2d	v24, v24, #0
    13d8:      	str	q30, [sp, #0x50]
    13dc:      	and.16b	v24, v24, v30
    13e0:      	movi.2d	v30, #0000000000000000
    13e4:      	stp	q30, q30, [sp, #0x250]
    13e8:      	stp	q24, q30, [sp, #0x230]
    13ec:      	and	x17, x25, #0x7
    13f0:      	add	x4, sp, #0x230
    13f4:      	ldr	x17, [x4, x17, lsl #3]
    13f8:      	sub	x17, x17, x25
    13fc:      	lsl	x17, x17, #2
    1400:      	add	x4, x26, x17
    1404:      	movi.2d	v24, #0000000000000000
    1408:      	tbnz	w2, #0x0, 0x1ed8 <ltmp0+0x1ed8>
    140c:      	tbnz	w9, #0x1, 0x1ee0 <ltmp0+0x1ee0>
    1410:      	tbnz	w9, #0x2, 0x1eec <ltmp0+0x1eec>
    1414:      	tbnz	w9, #0x3, 0x1ef8 <ltmp0+0x1ef8>
    1418:      	tbnz	w9, #0x4, 0x1f04 <ltmp0+0x1f04>
    141c:      	tbnz	w9, #0x5, 0x1f10 <ltmp0+0x1f10>
    1420:      	tbnz	w9, #0x6, 0x1f1c <ltmp0+0x1f1c>
    1424:      	str	q30, [sp, #0x60]
    1428:      	tbz	w9, #0x7, 0x1434 <ltmp0+0x1434>
    142c:      	add	x2, x4, #0x1c
    1430:      	ld1.s	{ v24 }[3], [x2]
    1434:      	mov.16b	v14, v24
    1438:      	mov	x4, #0x0                ; =0
    143c:      	movi.2s	v30, #0x41
    1440:      	ldr	d24, [sp, #0xf0]
    1444:      	umull.2d	v24, v24, v30
    1448:      	ldr	q31, [sp, #0xb0]
    144c:      	ldr	d8, [sp, #0x70]
    1450:      	umlal.2d	v31, v8, v30
    1454:      	add.2d	v31, v31, v25
    1458:      	str	q31, [sp, #0x70]
    145c:      	ldr	q31, [sp, #0xc0]
    1460:      	ldr	d8, [sp, #0x80]
    1464:      	umlal.2d	v31, v8, v30
    1468:      	add.2d	v31, v31, v25
    146c:      	str	q31, [sp, #0x80]
    1470:      	ldr	q13, [sp, #0xe0]
    1474:      	ldr	d31, [sp, #0x90]
    1478:      	umlal.2d	v13, v31, v30
    147c:      	adrp	x2, 0x1000 <ltmp0+0x1000>
    1480:      	ldr	q30, [x2]
    1484:      	mov	w2, #0x100              ; =256
    1488:      	dup.2d	v31, x2
    148c:      	sshll.2d	v8, v15, #0x0
    1490:      	bif.16b	v30, v31, v8
    1494:      	adrp	x2, 0x1000 <ltmp0+0x1000>
    1498:      	ldr	q8, [x2]
    149c:      	sshll.2d	v11, v28, #0x0
    14a0:      	bif.16b	v8, v31, v11
    14a4:      	adrp	x2, 0x1000 <ltmp0+0x1000>
    14a8:      	ldr	q11, [x2]
    14ac:      	bsl.16b	v10, v11, v31
    14b0:      	adrp	x2, 0x1000 <ltmp0+0x1000>
    14b4:      	ldr	q11, [x2]
    14b8:      	bit.16b	v31, v11, v9
    14bc:      	stp	q8, q31, [sp, #0x210]
    14c0:      	stp	q30, q10, [sp, #0x1f0]
    14c4:      	and	x2, x25, #0x7
    14c8:      	add	x5, sp, #0x1f0
    14cc:      	ldr	x2, [x5, x2, lsl #3]
    14d0:      	add.2d	v25, v13, v25
    14d4:      	str	q25, [sp, #0x40]
    14d8:      	sub	x2, x2, x25, lsl #2
    14dc:      	tst	w9, #0xff
    14e0:      	csel	x5, xzr, x2, eq
    14e4:      	add	x9, x15, x5
    14e8:      	ldp	q25, q30, [x9]
    14ec:      	ldr	q8, [sp, #0xa0]
    14f0:      	zip2.8b	v31, v8, v0
    14f4:      	ushll.4s	v31, v31, #0x0
    14f8:      	shl.4s	v31, v31, #0x1f
    14fc:      	cmlt.4s	v31, v31, #0
    1500:      	str	q14, [sp, #0x90]
    1504:      	bit.16b	v30, v14, v31
    1508:      	zip1.8b	v31, v8, v0
    150c:      	ushll.4s	v31, v31, #0x0
    1510:      	shl.4s	v31, v31, #0x1f
    1514:      	cmlt.4s	v31, v31, #0
    1518:      	ldr	q8, [sp, #0x60]
    151c:      	bit.16b	v25, v8, v31
    1520:      	stp	q25, q30, [x9]
    1524:      	fmov	x9, d24
    1528:      	lsl	x6, x9, #2
    152c:      	mov	w9, #0x1                ; =1
    1530:      	dup.2d	v24, x9
    1534:      	add	x9, x24, x6
    1538:      	ushll2.2d	v25, v28, #0x0
    153c:      	and.16b	v10, v25, v24
    1540:      	ushll2.2d	v25, v15, #0x0
    1544:      	and.16b	v11, v25, v24
    1548:      	ushll.2d	v25, v28, #0x0
    154c:      	and.16b	v12, v25, v24
    1550:      	ushll.2d	v25, v15, #0x0
    1554:      	and.16b	v24, v25, v24
    1558:      	str	q24, [sp, #0xe0]
    155c:      	movi.2d	v24, #0000000000000000
    1560:      	movi.2d	v25, #0000000000000000
    1564:      	movi.2d	v31, #0000000000000000
    1568:      	movi.2d	v8, #0000000000000000
    156c:      	b	0x15a8 <ltmp0+0x15a8>
    1570:      	add	x2, x16, x4
    1574:      	ldp	q14, q9, [x2]
    1578:      	bif.16b	v30, v9, v28
    157c:      	mov.16b	v9, v15
    1580:      	bsl.16b	v9, v13, v14
    1584:      	stp	q9, q30, [x2]
    1588:      	add.2d	v25, v25, v11
    158c:      	add.2d	v31, v31, v12
    1590:      	add.2d	v8, v8, v10
    1594:      	ldr	q30, [sp, #0xe0]
    1598:      	add.2d	v24, v24, v30
    159c:      	fmov	x4, d24
    15a0:      	cmp	x4, #0x8
    15a4:      	b.ge	0x1644 <ltmp0+0x1644>
    15a8:      	fmov	w19, s29
    15ac:      	lsl	x4, x4, #5
    15b0:      	add	x7, x9, x4
    15b4:      	movi.2d	v13, #0000000000000000
    15b8:      	movi.2d	v30, #0000000000000000
    15bc:      	tbnz	w19, #0x0, 0x15e4 <ltmp0+0x15e4>
    15c0:      	and	w19, w19, #0xff
    15c4:      	tbnz	w19, #0x1, 0x15f0 <ltmp0+0x15f0>
    15c8:      	tbnz	w19, #0x2, 0x15fc <ltmp0+0x15fc>
    15cc:      	tbnz	w19, #0x3, 0x1608 <ltmp0+0x1608>
    15d0:      	tbnz	w19, #0x4, 0x1614 <ltmp0+0x1614>
    15d4:      	tbnz	w19, #0x5, 0x1620 <ltmp0+0x1620>
    15d8:      	tbnz	w19, #0x6, 0x162c <ltmp0+0x162c>
    15dc:      	tbz	w19, #0x7, 0x1570 <ltmp0+0x1570>
    15e0:      	b	0x1638 <ltmp0+0x1638>
    15e4:      	ldr	s13, [x7]
    15e8:      	and	w19, w19, #0xff
    15ec:      	tbz	w19, #0x1, 0x15c8 <ltmp0+0x15c8>
    15f0:      	add	x2, x7, #0x4
    15f4:      	ld1.s	{ v13 }[1], [x2]
    15f8:      	tbz	w19, #0x2, 0x15cc <ltmp0+0x15cc>
    15fc:      	add	x2, x7, #0x8
    1600:      	ld1.s	{ v13 }[2], [x2]
    1604:      	tbz	w19, #0x3, 0x15d0 <ltmp0+0x15d0>
    1608:      	add	x2, x7, #0xc
    160c:      	ld1.s	{ v13 }[3], [x2]
    1610:      	tbz	w19, #0x4, 0x15d4 <ltmp0+0x15d4>
    1614:      	add	x2, x7, #0x10
    1618:      	ld1.s	{ v30 }[0], [x2]
    161c:      	tbz	w19, #0x5, 0x15d8 <ltmp0+0x15d8>
    1620:      	add	x2, x7, #0x14
    1624:      	ld1.s	{ v30 }[1], [x2]
    1628:      	tbz	w19, #0x6, 0x15dc <ltmp0+0x15dc>
    162c:      	add	x2, x7, #0x18
    1630:      	ld1.s	{ v30 }[2], [x2]
    1634:      	tbz	w19, #0x7, 0x1570 <ltmp0+0x1570>
    1638:      	add	x2, x7, #0x1c
    163c:      	ld1.s	{ v30 }[3], [x2]
    1640:      	b	0x1570 <ltmp0+0x1570>
    1644:      	add	x9, x24, x17
    1648:      	ldr	q24, [sp, #0xa0]
    164c:      	shl.8b	v24, v24, #0x7
    1650:      	cmlt.8b	v24, v24, #0
    1654:      	ldr	d25, [sp, #0x30]
    1658:      	and.8b	v24, v24, v25
    165c:      	addv.8b	b24, v24
    1660:      	str	d24, [sp, #0x18]
    1664:      	fmov	w17, s24
    1668:      	movi.2d	v9, #0000000000000000
    166c:      	movi.2d	v8, #0000000000000000
    1670:      	tbnz	w17, #0x0, 0x1f30 <ltmp0+0x1f30>
    1674:      	tbnz	w17, #0x1, 0x1f38 <ltmp0+0x1f38>
    1678:      	tbnz	w17, #0x2, 0x1f44 <ltmp0+0x1f44>
    167c:      	tbnz	w17, #0x3, 0x1f50 <ltmp0+0x1f50>
    1680:      	tbnz	w17, #0x4, 0x1f5c <ltmp0+0x1f5c>
    1684:      	tbnz	w17, #0x5, 0x1f68 <ltmp0+0x1f68>
    1688:      	tbnz	w17, #0x6, 0x1f74 <ltmp0+0x1f74>
    168c:      	str	q26, [sp, #0xf0]
    1690:      	tbz	w17, #0x7, 0x169c <ltmp0+0x169c>
    1694:      	add	x9, x9, #0x1c
    1698:      	ld1.s	{ v8 }[3], [x9]
    169c:      	mov	x17, #0x0               ; =0
    16a0:      	add	x9, x16, x5
    16a4:      	ldp	q24, q25, [x9]
    16a8:      	ldr	q31, [sp, #0xa0]
    16ac:      	zip2.8b	v30, v31, v0
    16b0:      	ushll.4s	v30, v30, #0x0
    16b4:      	shl.4s	v30, v30, #0x1f
    16b8:      	cmlt.4s	v30, v30, #0
    16bc:      	stp	q9, q8, [sp, #0x20]
    16c0:      	bit.16b	v25, v8, v30
    16c4:      	zip1.8b	v30, v31, v0
    16c8:      	ushll.4s	v30, v30, #0x0
    16cc:      	shl.4s	v30, v30, #0x1f
    16d0:      	cmlt.4s	v30, v30, #0
    16d4:      	bit.16b	v24, v9, v30
    16d8:      	stp	q24, q25, [x9]
    16dc:      	add	x9, x23, x6
    16e0:      	movi.2d	v24, #0000000000000000
    16e4:      	movi.2d	v31, #0000000000000000
    16e8:      	movi.2d	v25, #0000000000000000
    16ec:      	movi.2d	v13, #0000000000000000
    16f0:      	stp	q11, q29, [sp, #0xc0]
    16f4:      	str	q12, [sp, #0xb0]
    16f8:      	b	0x171c <ltmp0+0x171c>
    16fc:      	add.2d	v31, v31, v11
    1700:      	add.2d	v25, v25, v12
    1704:      	add.2d	v13, v13, v10
    1708:      	ldr	q26, [sp, #0xe0]
    170c:      	add.2d	v24, v24, v26
    1710:      	fmov	x17, d24
    1714:      	cmp	x17, #0x8
    1718:      	b.ge	0x1994 <ltmp0+0x1994>
    171c:      	mov.16b	v26, v28
    1720:      	mov.16b	v12, v10
    1724:      	fmov	w4, s29
    1728:      	lsl	x17, x17, #5
    172c:      	add	x2, x15, x17
    1730:      	ldp	q30, q14, [x2]
    1734:      	and.16b	v30, v15, v30
    1738:      	fneg.4s	v8, v30
    173c:      	and.16b	v8, v15, v8
    1740:      	fcmge.4s	v9, v8, v27
    1744:      	ldr	q29, [sp, #0xf0]
    1748:      	fcmge.4s	v10, v29, v8
    174c:      	and.16b	v9, v9, v10
    1750:      	and.16b	v9, v9, v8
    1754:      	fmul.4s	v10, v9, v2
    1758:      	mov.16b	v11, v4
    175c:      	bsl.16b	v11, v3, v10
    1760:      	fadd.4s	v10, v10, v11
    1764:      	fsub.4s	v10, v10, v11
    1768:      	fcvtzs.4s	v10, v10
    176c:      	scvtf.4s	v11, v10
    1770:      	fmul.4s	v15, v11, v5
    1774:      	fadd.4s	v9, v9, v15
    1778:      	fmul.4s	v11, v11, v6
    177c:      	fadd.4s	v9, v9, v11
    1780:      	fmul.4s	v11, v9, v7
    1784:      	fadd.4s	v11, v11, v16
    1788:      	fmul.4s	v11, v9, v11
    178c:      	fadd.4s	v11, v11, v17
    1790:      	fmul.4s	v11, v9, v11
    1794:      	fadd.4s	v11, v11, v18
    1798:      	fmul.4s	v11, v9, v11
    179c:      	fadd.4s	v11, v11, v19
    17a0:      	fmul.4s	v11, v9, v11
    17a4:      	fadd.4s	v11, v11, v20
    17a8:      	fmul.4s	v15, v9, v9
    17ac:      	fmul.4s	v11, v15, v11
    17b0:      	fadd.4s	v9, v9, v11
    17b4:      	fadd.4s	v9, v9, v21
    17b8:      	sshr.4s	v11, v10, #0x1
    17bc:      	shl.4s	v15, v11, #0x17
    17c0:      	add.4s	v15, v15, v21
    17c4:      	fmul.4s	v9, v9, v15
    17c8:      	sub.4s	v10, v10, v11
    17cc:      	shl.4s	v10, v10, #0x17
    17d0:      	add.4s	v10, v10, v21
    17d4:      	fmul.4s	v9, v9, v10
    17d8:      	fcmgt.4s	v10, v27, v8
    17dc:      	fcmgt.4s	v11, v8, v29
    17e0:      	fcmeq.4s	v8, v8, v8
    17e4:      	fadd.4s	v9, v9, v21
    17e8:      	bit.16b	v9, v21, v10
    17ec:      	bit.16b	v9, v22, v11
    17f0:      	bsl.16b	v8, v9, v23
    17f4:      	fdiv.4s	v30, v30, v8
    17f8:      	add	x2, x16, x17
    17fc:      	ldp	q9, q8, [x2]
    1800:      	ldr	q28, [sp, #0x100]
    1804:      	and.16b	v9, v28, v9
    1808:      	fmul.4s	v30, v9, v30
    180c:      	add	x17, x9, x17
    1810:      	tbnz	w4, #0x0, 0x1928 <ltmp0+0x1928>
    1814:      	and	w4, w4, #0xff
    1818:      	tbnz	w4, #0x1, 0x1934 <ltmp0+0x1934>
    181c:      	tbnz	w4, #0x2, 0x1940 <ltmp0+0x1940>
    1820:      	tbz	w4, #0x3, 0x182c <ltmp0+0x182c>
    1824:      	add	x2, x17, #0xc
    1828:      	st1.s	{ v30 }[3], [x2]
    182c:      	and.16b	v30, v26, v14
    1830:      	fneg.4s	v9, v30
    1834:      	and.16b	v9, v26, v9
    1838:      	fcmge.4s	v10, v9, v27
    183c:      	ldr	q28, [sp, #0xf0]
    1840:      	fcmge.4s	v11, v28, v9
    1844:      	and.16b	v10, v10, v11
    1848:      	and.16b	v10, v10, v9
    184c:      	fmul.4s	v11, v10, v2
    1850:      	mov.16b	v14, v4
    1854:      	bsl.16b	v14, v3, v11
    1858:      	fadd.4s	v11, v11, v14
    185c:      	fsub.4s	v11, v11, v14
    1860:      	fcvtzs.4s	v11, v11
    1864:      	scvtf.4s	v14, v11
    1868:      	fmul.4s	v15, v14, v5
    186c:      	fadd.4s	v10, v10, v15
    1870:      	fmul.4s	v14, v14, v6
    1874:      	fadd.4s	v10, v10, v14
    1878:      	fmul.4s	v14, v10, v7
    187c:      	fadd.4s	v14, v14, v16
    1880:      	fmul.4s	v14, v10, v14
    1884:      	fadd.4s	v14, v14, v17
    1888:      	fmul.4s	v14, v10, v14
    188c:      	fadd.4s	v14, v14, v18
    1890:      	fmul.4s	v14, v10, v14
    1894:      	fadd.4s	v14, v14, v19
    1898:      	fmul.4s	v14, v10, v14
    189c:      	fadd.4s	v14, v14, v20
    18a0:      	fmul.4s	v15, v10, v10
    18a4:      	fmul.4s	v14, v15, v14
    18a8:      	fadd.4s	v10, v10, v14
    18ac:      	fadd.4s	v10, v10, v21
    18b0:      	sshr.4s	v14, v11, #0x1
    18b4:      	shl.4s	v15, v14, #0x17
    18b8:      	add.4s	v15, v15, v21
    18bc:      	fmul.4s	v10, v10, v15
    18c0:      	sub.4s	v11, v11, v14
    18c4:      	shl.4s	v11, v11, #0x17
    18c8:      	add.4s	v11, v11, v21
    18cc:      	fmul.4s	v10, v10, v11
    18d0:      	mov.16b	v15, v27
    18d4:      	fcmgt.4s	v11, v27, v9
    18d8:      	fcmgt.4s	v14, v9, v28
    18dc:      	fcmeq.4s	v9, v9, v9
    18e0:      	fadd.4s	v10, v10, v21
    18e4:      	bit.16b	v10, v21, v11
    18e8:      	bit.16b	v10, v22, v14
    18ec:      	bsl.16b	v9, v10, v23
    18f0:      	fdiv.4s	v30, v30, v9
    18f4:      	and.16b	v8, v26, v8
    18f8:      	fmul.4s	v30, v8, v30
    18fc:      	tbnz	w4, #0x4, 0x1950 <ltmp0+0x1950>
    1900:      	mov.16b	v10, v12
    1904:      	ldp	q11, q29, [sp, #0xc0]
    1908:      	tbnz	w4, #0x5, 0x1960 <ltmp0+0x1960>
    190c:      	mov.16b	v28, v26
    1910:      	mov.16b	v27, v15
    1914:      	ldr	q12, [sp, #0xb0]
    1918:      	tbnz	w4, #0x6, 0x1978 <ltmp0+0x1978>
    191c:      	ldr	q15, [sp, #0x100]
    1920:      	tbz	w4, #0x7, 0x16fc <ltmp0+0x16fc>
    1924:      	b	0x1988 <ltmp0+0x1988>
    1928:      	str	s30, [x17]
    192c:      	and	w4, w4, #0xff
    1930:      	tbz	w4, #0x1, 0x181c <ltmp0+0x181c>
    1934:      	add	x2, x17, #0x4
    1938:      	st1.s	{ v30 }[1], [x2]
    193c:      	tbz	w4, #0x2, 0x1820 <ltmp0+0x1820>
    1940:      	add	x2, x17, #0x8
    1944:      	st1.s	{ v30 }[2], [x2]
    1948:      	tbnz	w4, #0x3, 0x1824 <ltmp0+0x1824>
    194c:      	b	0x182c <ltmp0+0x182c>
    1950:      	str	s30, [x17, #0x10]
    1954:      	mov.16b	v10, v12
    1958:      	ldp	q11, q29, [sp, #0xc0]
    195c:      	tbz	w4, #0x5, 0x190c <ltmp0+0x190c>
    1960:      	add	x2, x17, #0x14
    1964:      	st1.s	{ v30 }[1], [x2]
    1968:      	mov.16b	v28, v26
    196c:      	mov.16b	v27, v15
    1970:      	ldr	q12, [sp, #0xb0]
    1974:      	tbz	w4, #0x6, 0x191c <ltmp0+0x191c>
    1978:      	add	x2, x17, #0x18
    197c:      	st1.s	{ v30 }[2], [x2]
    1980:      	ldr	q15, [sp, #0x100]
    1984:      	tbz	w4, #0x7, 0x16fc <ltmp0+0x16fc>
    1988:      	add	x17, x17, #0x1c
    198c:      	st1.s	{ v30 }[3], [x17]
    1990:      	b	0x16fc <ltmp0+0x16fc>
    1994:      	ldr	q31, [sp, #0x60]
    1998:      	fneg.4s	v24, v31
    199c:      	ldr	d25, [sp, #0x18]
    19a0:      	fmov	w9, s25
    19a4:      	ldr	q25, [sp, #0xa0]
    19a8:      	zip1.8b	v25, v25, v0
    19ac:      	ushll.4s	v25, v25, #0x0
    19b0:      	shl.4s	v25, v25, #0x1f
    19b4:      	cmlt.4s	v25, v25, #0
    19b8:      	and.16b	v24, v25, v24
    19bc:      	fcmge.4s	v25, v24, v27
    19c0:      	ldr	q26, [sp, #0xf0]
    19c4:      	fcmge.4s	v28, v26, v24
    19c8:      	and.16b	v25, v25, v28
    19cc:      	and.16b	v25, v25, v24
    19d0:      	fmul.4s	v28, v25, v2
    19d4:      	mov.16b	v29, v4
    19d8:      	bsl.16b	v29, v3, v28
    19dc:      	fadd.4s	v28, v28, v29
    19e0:      	fsub.4s	v28, v28, v29
    19e4:      	fcvtzs.4s	v28, v28
    19e8:      	scvtf.4s	v29, v28
    19ec:      	fmul.4s	v30, v29, v5
    19f0:      	fadd.4s	v25, v25, v30
    19f4:      	fmul.4s	v29, v29, v6
    19f8:      	fadd.4s	v25, v25, v29
    19fc:      	fmul.4s	v29, v25, v7
    1a00:      	fadd.4s	v29, v29, v16
    1a04:      	fmul.4s	v29, v25, v29
    1a08:      	fadd.4s	v29, v29, v17
    1a0c:      	fmul.4s	v29, v25, v29
    1a10:      	fadd.4s	v29, v29, v18
    1a14:      	fmul.4s	v29, v25, v29
    1a18:      	fadd.4s	v29, v29, v19
    1a1c:      	fmul.4s	v29, v25, v29
    1a20:      	fadd.4s	v29, v29, v20
    1a24:      	fmul.4s	v30, v25, v25
    1a28:      	fmul.4s	v29, v30, v29
    1a2c:      	fadd.4s	v25, v25, v29
    1a30:      	fadd.4s	v25, v25, v21
    1a34:      	sshr.4s	v29, v28, #0x1
    1a38:      	shl.4s	v30, v29, #0x17
    1a3c:      	add.4s	v30, v30, v21
    1a40:      	fmul.4s	v25, v25, v30
    1a44:      	sub.4s	v28, v28, v29
    1a48:      	shl.4s	v28, v28, #0x17
    1a4c:      	add.4s	v28, v28, v21
    1a50:      	fmul.4s	v25, v25, v28
    1a54:      	fcmgt.4s	v28, v27, v24
    1a58:      	fcmgt.4s	v29, v24, v26
    1a5c:      	fcmeq.4s	v24, v24, v24
    1a60:      	fadd.4s	v25, v25, v21
    1a64:      	bit.16b	v25, v21, v28
    1a68:      	bit.16b	v25, v22, v29
    1a6c:      	bsl.16b	v24, v25, v23
    1a70:      	fdiv.4s	v24, v31, v24
    1a74:      	ldr	q25, [sp, #0x20]
    1a78:      	fmul.4s	v24, v24, v25
    1a7c:      	ldp	q25, q28, [sp, #0x40]
    1a80:      	ldp	q29, q30, [sp, #0x70]
    1a84:      	stp	q28, q29, [sp, #0x1a0]
    1a88:      	stp	q30, q25, [sp, #0x1c0]
    1a8c:      	and	x17, x25, #0x7
    1a90:      	add	x2, sp, #0x1a0
    1a94:      	ldr	x17, [x2, x17, lsl #3]
    1a98:      	sub	x17, x17, x25
    1a9c:      	add	x17, x23, x17, lsl #2
    1aa0:      	tbnz	w9, #0x0, 0x1f88 <ltmp0+0x1f88>
    1aa4:      	ldr	q31, [sp, #0x90]
    1aa8:      	ldr	q8, [sp, #0x30]
    1aac:      	tbnz	w9, #0x1, 0x1f98 <ltmp0+0x1f98>
    1ab0:      	tbnz	w9, #0x2, 0x1fa4 <ltmp0+0x1fa4>
    1ab4:      	tbz	w9, #0x3, 0x1ac0 <ltmp0+0x1ac0>
    1ab8:      	add	x2, x17, #0xc
    1abc:      	st1.s	{ v24 }[3], [x2]
    1ac0:      	fneg.4s	v24, v31
    1ac4:      	ldr	q25, [sp, #0xa0]
    1ac8:      	zip2.8b	v25, v25, v0
    1acc:      	ushll.4s	v25, v25, #0x0
    1ad0:      	shl.4s	v25, v25, #0x1f
    1ad4:      	cmlt.4s	v25, v25, #0
    1ad8:      	and.16b	v24, v25, v24
    1adc:      	fcmge.4s	v25, v24, v27
    1ae0:      	fcmge.4s	v28, v26, v24
    1ae4:      	and.16b	v25, v25, v28
    1ae8:      	and.16b	v25, v25, v24
    1aec:      	fmul.4s	v28, v25, v2
    1af0:      	mov.16b	v29, v4
    1af4:      	bsl.16b	v29, v3, v28
    1af8:      	fadd.4s	v28, v28, v29
    1afc:      	fsub.4s	v28, v28, v29
    1b00:      	fcvtzs.4s	v28, v28
    1b04:      	scvtf.4s	v29, v28
    1b08:      	fmul.4s	v30, v29, v5
    1b0c:      	fadd.4s	v25, v25, v30
    1b10:      	fmul.4s	v29, v29, v6
    1b14:      	fadd.4s	v25, v25, v29
    1b18:      	fmul.4s	v29, v25, v7
    1b1c:      	fadd.4s	v29, v29, v16
    1b20:      	fmul.4s	v29, v25, v29
    1b24:      	fadd.4s	v29, v29, v17
    1b28:      	fmul.4s	v29, v25, v29
    1b2c:      	fadd.4s	v29, v29, v18
    1b30:      	fmul.4s	v29, v25, v29
    1b34:      	fadd.4s	v29, v29, v19
    1b38:      	fmul.4s	v29, v25, v29
    1b3c:      	fadd.4s	v29, v29, v20
    1b40:      	fmul.4s	v30, v25, v25
    1b44:      	fmul.4s	v29, v30, v29
    1b48:      	fadd.4s	v25, v25, v29
    1b4c:      	fadd.4s	v25, v25, v21
    1b50:      	sshr.4s	v29, v28, #0x1
    1b54:      	shl.4s	v30, v29, #0x17
    1b58:      	add.4s	v30, v30, v21
    1b5c:      	fmul.4s	v25, v25, v30
    1b60:      	sub.4s	v28, v28, v29
    1b64:      	shl.4s	v28, v28, #0x17
    1b68:      	add.4s	v28, v28, v21
    1b6c:      	fmul.4s	v25, v25, v28
    1b70:      	fcmgt.4s	v27, v27, v24
    1b74:      	fcmgt.4s	v26, v24, v26
    1b78:      	fcmeq.4s	v24, v24, v24
    1b7c:      	fadd.4s	v25, v25, v21
    1b80:      	bit.16b	v25, v21, v27
    1b84:      	bit.16b	v25, v22, v26
    1b88:      	bsl.16b	v24, v25, v23
    1b8c:      	fdiv.4s	v24, v31, v24
    1b90:      	fmul.4s	v24, v24, v8
    1b94:      	tbnz	w9, #0x4, 0x1fb4 <ltmp0+0x1fb4>
    1b98:      	tbnz	w9, #0x5, 0x1fbc <ltmp0+0x1fbc>
    1b9c:      	tbnz	w9, #0x6, 0x1fc8 <ltmp0+0x1fc8>
    1ba0:      	tbz	w9, #0x7, 0xf8 <ltmp0+0xf8>
    1ba4:      	b	0x1fd4 <ltmp0+0x1fd4>
    1ba8:      	xtn.4h	v25, v15
    1bac:      	uzp1.8b	v28, v25, v0
    1bb0:      	movi.2d	v25, #0000000000000000
    1bb4:      	mov.b	v25[0], v28[0]
    1bb8:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1bbc:      	ldr	d9, [x9]
    1bc0:      	and.8b	v29, v25, v9
    1bc4:      	addv.8b	b29, v29
    1bc8:      	fmov	w9, s29
    1bcc:      	umaxv.8b	b29, v25
    1bd0:      	fmov	w2, s29
    1bd4:      	rbit	w17, w9
    1bd8:      	clz	w17, w17
    1bdc:      	tst	w2, #0x1
    1be0:      	csel	w17, w17, wzr, ne
    1be4:      	mov	w4, #0x40               ; =64
    1be8:      	dup.2d	v30, x4
    1bec:      	movi.2s	v29, #0x41
    1bf0:      	ldr	d31, [sp, #0xf0]
    1bf4:      	umlal.2d	v24, v31, v29
    1bf8:      	movi.2d	v29, #0000000000000000
    1bfc:      	mov.b	v29[0], v28[0]
    1c00:      	add.2d	v28, v24, v30
    1c04:      	ushll.2d	v24, v29, #0x0
    1c08:      	shl.2d	v24, v24, #0x3f
    1c0c:      	cmlt.2d	v24, v24, #0
    1c10:      	str	q28, [sp, #0x100]
    1c14:      	and.16b	v24, v24, v28
    1c18:      	movi.2d	v28, #0000000000000000
    1c1c:      	stp	q28, q28, [sp, #0x170]
    1c20:      	stp	q24, q28, [sp, #0x150]
    1c24:      	and	x4, x17, #0x7
    1c28:      	add	x5, sp, #0x150
    1c2c:      	ldr	x4, [x5, x4, lsl #3]
    1c30:      	sub	x4, x4, x17
    1c34:      	lsl	x4, x4, #2
    1c38:      	add	x5, x26, x4
    1c3c:      	movi.2d	v29, #0000000000000000
    1c40:      	movi.2d	v24, #0000000000000000
    1c44:      	tbnz	w2, #0x0, 0x1fdc <ltmp0+0x1fdc>
    1c48:      	tbnz	w9, #0x1, 0x1fe4 <ltmp0+0x1fe4>
    1c4c:      	tbnz	w9, #0x2, 0x1ff0 <ltmp0+0x1ff0>
    1c50:      	tbnz	w9, #0x3, 0x1ffc <ltmp0+0x1ffc>
    1c54:      	tbnz	w9, #0x4, 0x2008 <ltmp0+0x2008>
    1c58:      	tbnz	w9, #0x5, 0x2014 <ltmp0+0x2014>
    1c5c:      	tbnz	w9, #0x6, 0x2020 <ltmp0+0x2020>
    1c60:      	tbz	w9, #0x7, 0x1c6c <ltmp0+0x1c6c>
    1c64:      	add	x9, x5, #0x1c
    1c68:      	ld1.s	{ v24 }[3], [x9]
    1c6c:      	shl.8b	v31, v25, #0x7
    1c70:      	cmlt.8b	v31, v31, #0
    1c74:      	and.8b	v31, v31, v9
    1c78:      	addv.8b	b10, v31
    1c7c:      	fmov	w5, s10
    1c80:      	add	x9, x24, x4
    1c84:      	movi.2d	v12, #0000000000000000
    1c88:      	movi.2d	v9, #0000000000000000
    1c8c:      	tbnz	w5, #0x0, 0x2030 <ltmp0+0x2030>
    1c90:      	tbnz	w5, #0x1, 0x2038 <ltmp0+0x2038>
    1c94:      	tbnz	w5, #0x2, 0x2044 <ltmp0+0x2044>
    1c98:      	tbnz	w5, #0x3, 0x2050 <ltmp0+0x2050>
    1c9c:      	tbnz	w5, #0x4, 0x205c <ltmp0+0x205c>
    1ca0:      	tbnz	w5, #0x5, 0x2068 <ltmp0+0x2068>
    1ca4:      	tbnz	w5, #0x6, 0x2074 <ltmp0+0x2074>
    1ca8:      	tbz	w5, #0x7, 0x1cb4 <ltmp0+0x1cb4>
    1cac:      	add	x9, x9, #0x1c
    1cb0:      	ld1.s	{ v9 }[3], [x9]
    1cb4:      	movi.2s	v28, #0x41
    1cb8:      	ldr	q31, [sp, #0xb0]
    1cbc:      	ldr	d8, [sp, #0x70]
    1cc0:      	umlal.2d	v31, v8, v28
    1cc4:      	add.2d	v31, v31, v30
    1cc8:      	ldr	q8, [sp, #0xc0]
    1ccc:      	ldr	d11, [sp, #0x80]
    1cd0:      	umlal.2d	v8, v11, v28
    1cd4:      	add.2d	v8, v8, v30
    1cd8:      	ldr	q11, [sp, #0xe0]
    1cdc:      	ldr	d13, [sp, #0x90]
    1ce0:      	umlal.2d	v11, v13, v28
    1ce4:      	add.2d	v30, v11, v30
    1ce8:      	fneg.4s	v11, v29
    1cec:      	zip1.8b	v13, v25, v0
    1cf0:      	ushll.4s	v13, v13, #0x0
    1cf4:      	shl.4s	v13, v13, #0x1f
    1cf8:      	cmlt.4s	v13, v13, #0
    1cfc:      	and.16b	v11, v13, v11
    1d00:      	fcmge.4s	v13, v11, v27
    1d04:      	fcmge.4s	v14, v26, v11
    1d08:      	and.16b	v13, v13, v14
    1d0c:      	and.16b	v13, v13, v11
    1d10:      	fmul.4s	v14, v13, v2
    1d14:      	mov.16b	v15, v4
    1d18:      	bsl.16b	v15, v3, v14
    1d1c:      	fadd.4s	v14, v14, v15
    1d20:      	fsub.4s	v14, v14, v15
    1d24:      	fcvtzs.4s	v14, v14
    1d28:      	scvtf.4s	v15, v14
    1d2c:      	fmul.4s	v28, v15, v5
    1d30:      	fadd.4s	v28, v13, v28
    1d34:      	fmul.4s	v13, v15, v6
    1d38:      	fadd.4s	v28, v28, v13
    1d3c:      	fmul.4s	v13, v28, v7
    1d40:      	fadd.4s	v13, v13, v16
    1d44:      	fmul.4s	v13, v28, v13
    1d48:      	fadd.4s	v13, v13, v17
    1d4c:      	fmul.4s	v13, v28, v13
    1d50:      	fadd.4s	v13, v13, v18
    1d54:      	fmul.4s	v13, v28, v13
    1d58:      	fadd.4s	v13, v13, v19
    1d5c:      	fmul.4s	v13, v28, v13
    1d60:      	fadd.4s	v13, v13, v20
    1d64:      	fmul.4s	v15, v28, v28
    1d68:      	fmul.4s	v13, v15, v13
    1d6c:      	fadd.4s	v28, v28, v13
    1d70:      	fadd.4s	v28, v28, v21
    1d74:      	sshr.4s	v13, v14, #0x1
    1d78:      	shl.4s	v15, v13, #0x17
    1d7c:      	add.4s	v15, v15, v21
    1d80:      	fmul.4s	v28, v28, v15
    1d84:      	sub.4s	v13, v14, v13
    1d88:      	shl.4s	v13, v13, #0x17
    1d8c:      	add.4s	v13, v13, v21
    1d90:      	fmul.4s	v28, v28, v13
    1d94:      	fcmgt.4s	v13, v27, v11
    1d98:      	fcmgt.4s	v14, v11, v26
    1d9c:      	fcmeq.4s	v11, v11, v11
    1da0:      	fadd.4s	v28, v28, v21
    1da4:      	bit.16b	v28, v21, v13
    1da8:      	bit.16b	v28, v22, v14
    1dac:      	bif.16b	v28, v23, v11
    1db0:      	fdiv.4s	v28, v29, v28
    1db4:      	fmul.4s	v29, v12, v28
    1db8:      	ldr	q28, [sp, #0x100]
    1dbc:      	stp	q28, q31, [sp, #0x110]
    1dc0:      	stp	q8, q30, [sp, #0x130]
    1dc4:      	and	x9, x17, #0x7
    1dc8:      	add	x2, sp, #0x110
    1dcc:      	ldr	x9, [x2, x9, lsl #3]
    1dd0:      	sub	x9, x9, x17
    1dd4:      	add	x9, x23, x9, lsl #2
    1dd8:      	fmov	w17, s10
    1ddc:      	tbnz	w17, #0x0, 0x2084 <ltmp0+0x2084>
    1de0:      	tbnz	w17, #0x1, 0x208c <ltmp0+0x208c>
    1de4:      	tbnz	w17, #0x2, 0x2098 <ltmp0+0x2098>
    1de8:      	tbz	w17, #0x3, 0x1df4 <ltmp0+0x1df4>
    1dec:      	add	x2, x9, #0xc
    1df0:      	st1.s	{ v29 }[3], [x2]
    1df4:      	fneg.4s	v28, v24
    1df8:      	zip2.8b	v25, v25, v0
    1dfc:      	ushll.4s	v25, v25, #0x0
    1e00:      	shl.4s	v25, v25, #0x1f
    1e04:      	cmlt.4s	v25, v25, #0
    1e08:      	and.16b	v25, v25, v28
    1e0c:      	fcmge.4s	v28, v25, v27
    1e10:      	fcmge.4s	v29, v26, v25
    1e14:      	and.16b	v28, v28, v29
    1e18:      	and.16b	v28, v28, v25
    1e1c:      	fmul.4s	v29, v28, v2
    1e20:      	mov.16b	v30, v4
    1e24:      	bsl.16b	v30, v3, v29
    1e28:      	fadd.4s	v29, v29, v30
    1e2c:      	fsub.4s	v29, v29, v30
    1e30:      	fcvtzs.4s	v29, v29
    1e34:      	scvtf.4s	v30, v29
    1e38:      	fmul.4s	v31, v30, v5
    1e3c:      	fadd.4s	v28, v28, v31
    1e40:      	fmul.4s	v30, v30, v6
    1e44:      	fadd.4s	v28, v28, v30
    1e48:      	fmul.4s	v30, v28, v7
    1e4c:      	fadd.4s	v30, v30, v16
    1e50:      	fmul.4s	v30, v28, v30
    1e54:      	fadd.4s	v30, v30, v17
    1e58:      	fmul.4s	v30, v28, v30
    1e5c:      	fadd.4s	v30, v30, v18
    1e60:      	fmul.4s	v30, v28, v30
    1e64:      	fadd.4s	v30, v30, v19
    1e68:      	fmul.4s	v30, v28, v30
    1e6c:      	fadd.4s	v30, v30, v20
    1e70:      	fmul.4s	v31, v28, v28
    1e74:      	fmul.4s	v30, v31, v30
    1e78:      	fadd.4s	v28, v28, v30
    1e7c:      	fadd.4s	v28, v28, v21
    1e80:      	sshr.4s	v30, v29, #0x1
    1e84:      	shl.4s	v31, v30, #0x17
    1e88:      	add.4s	v31, v31, v21
    1e8c:      	fmul.4s	v28, v28, v31
    1e90:      	sub.4s	v29, v29, v30
    1e94:      	shl.4s	v29, v29, #0x17
    1e98:      	add.4s	v29, v29, v21
    1e9c:      	fmul.4s	v28, v28, v29
    1ea0:      	fcmgt.4s	v27, v27, v25
    1ea4:      	fcmgt.4s	v26, v25, v26
    1ea8:      	fcmeq.4s	v25, v25, v25
    1eac:      	fadd.4s	v28, v28, v21
    1eb0:      	bsl.16b	v27, v21, v28
    1eb4:      	bsl.16b	v26, v22, v27
    1eb8:      	bsl.16b	v25, v26, v23
    1ebc:      	fdiv.4s	v24, v24, v25
    1ec0:      	fmul.4s	v24, v9, v24
    1ec4:      	tbnz	w17, #0x4, 0x20a8 <ltmp0+0x20a8>
    1ec8:      	tbnz	w17, #0x5, 0x20b0 <ltmp0+0x20b0>
    1ecc:      	tbnz	w17, #0x6, 0x20bc <ltmp0+0x20bc>
    1ed0:      	tbz	w17, #0x7, 0xf8 <ltmp0+0xf8>
    1ed4:      	b	0x20c8 <ltmp0+0x20c8>
    1ed8:      	ldr	s30, [x4]
    1edc:      	tbz	w9, #0x1, 0x1410 <ltmp0+0x1410>
    1ee0:      	add	x2, x4, #0x4
    1ee4:      	ld1.s	{ v30 }[1], [x2]
    1ee8:      	tbz	w9, #0x2, 0x1414 <ltmp0+0x1414>
    1eec:      	add	x2, x4, #0x8
    1ef0:      	ld1.s	{ v30 }[2], [x2]
    1ef4:      	tbz	w9, #0x3, 0x1418 <ltmp0+0x1418>
    1ef8:      	add	x2, x4, #0xc
    1efc:      	ld1.s	{ v30 }[3], [x2]
    1f00:      	tbz	w9, #0x4, 0x141c <ltmp0+0x141c>
    1f04:      	add	x2, x4, #0x10
    1f08:      	ld1.s	{ v24 }[0], [x2]
    1f0c:      	tbz	w9, #0x5, 0x1420 <ltmp0+0x1420>
    1f10:      	add	x2, x4, #0x14
    1f14:      	ld1.s	{ v24 }[1], [x2]
    1f18:      	tbz	w9, #0x6, 0x1424 <ltmp0+0x1424>
    1f1c:      	add	x2, x4, #0x18
    1f20:      	ld1.s	{ v24 }[2], [x2]
    1f24:      	str	q30, [sp, #0x60]
    1f28:      	tbnz	w9, #0x7, 0x142c <ltmp0+0x142c>
    1f2c:      	b	0x1434 <ltmp0+0x1434>
    1f30:      	ldr	s9, [x9]
    1f34:      	tbz	w17, #0x1, 0x1678 <ltmp0+0x1678>
    1f38:      	add	x2, x9, #0x4
    1f3c:      	ld1.s	{ v9 }[1], [x2]
    1f40:      	tbz	w17, #0x2, 0x167c <ltmp0+0x167c>
    1f44:      	add	x2, x9, #0x8
    1f48:      	ld1.s	{ v9 }[2], [x2]
    1f4c:      	tbz	w17, #0x3, 0x1680 <ltmp0+0x1680>
    1f50:      	add	x2, x9, #0xc
    1f54:      	ld1.s	{ v9 }[3], [x2]
    1f58:      	tbz	w17, #0x4, 0x1684 <ltmp0+0x1684>
    1f5c:      	add	x2, x9, #0x10
    1f60:      	ld1.s	{ v8 }[0], [x2]
    1f64:      	tbz	w17, #0x5, 0x1688 <ltmp0+0x1688>
    1f68:      	add	x2, x9, #0x14
    1f6c:      	ld1.s	{ v8 }[1], [x2]
    1f70:      	tbz	w17, #0x6, 0x168c <ltmp0+0x168c>
    1f74:      	add	x2, x9, #0x18
    1f78:      	ld1.s	{ v8 }[2], [x2]
    1f7c:      	str	q26, [sp, #0xf0]
    1f80:      	tbnz	w17, #0x7, 0x1694 <ltmp0+0x1694>
    1f84:      	b	0x169c <ltmp0+0x169c>
    1f88:      	str	s24, [x17]
    1f8c:      	ldr	q31, [sp, #0x90]
    1f90:      	ldr	q8, [sp, #0x30]
    1f94:      	tbz	w9, #0x1, 0x1ab0 <ltmp0+0x1ab0>
    1f98:      	add	x2, x17, #0x4
    1f9c:      	st1.s	{ v24 }[1], [x2]
    1fa0:      	tbz	w9, #0x2, 0x1ab4 <ltmp0+0x1ab4>
    1fa4:      	add	x2, x17, #0x8
    1fa8:      	st1.s	{ v24 }[2], [x2]
    1fac:      	tbnz	w9, #0x3, 0x1ab8 <ltmp0+0x1ab8>
    1fb0:      	b	0x1ac0 <ltmp0+0x1ac0>
    1fb4:      	str	s24, [x17, #0x10]
    1fb8:      	tbz	w9, #0x5, 0x1b9c <ltmp0+0x1b9c>
    1fbc:      	add	x2, x17, #0x14
    1fc0:      	st1.s	{ v24 }[1], [x2]
    1fc4:      	tbz	w9, #0x6, 0x1ba0 <ltmp0+0x1ba0>
    1fc8:      	add	x2, x17, #0x18
    1fcc:      	st1.s	{ v24 }[2], [x2]
    1fd0:      	tbz	w9, #0x7, 0xf8 <ltmp0+0xf8>
    1fd4:      	add	x9, x17, #0x1c
    1fd8:      	b	0xf4 <ltmp0+0xf4>
    1fdc:      	ldr	s29, [x5]
    1fe0:      	tbz	w9, #0x1, 0x1c4c <ltmp0+0x1c4c>
    1fe4:      	add	x2, x5, #0x4
    1fe8:      	ld1.s	{ v29 }[1], [x2]
    1fec:      	tbz	w9, #0x2, 0x1c50 <ltmp0+0x1c50>
    1ff0:      	add	x2, x5, #0x8
    1ff4:      	ld1.s	{ v29 }[2], [x2]
    1ff8:      	tbz	w9, #0x3, 0x1c54 <ltmp0+0x1c54>
    1ffc:      	add	x2, x5, #0xc
    2000:      	ld1.s	{ v29 }[3], [x2]
    2004:      	tbz	w9, #0x4, 0x1c58 <ltmp0+0x1c58>
    2008:      	add	x2, x5, #0x10
    200c:      	ld1.s	{ v24 }[0], [x2]
    2010:      	tbz	w9, #0x5, 0x1c5c <ltmp0+0x1c5c>
    2014:      	add	x2, x5, #0x14
    2018:      	ld1.s	{ v24 }[1], [x2]
    201c:      	tbz	w9, #0x6, 0x1c60 <ltmp0+0x1c60>
    2020:      	add	x2, x5, #0x18
    2024:      	ld1.s	{ v24 }[2], [x2]
    2028:      	tbnz	w9, #0x7, 0x1c64 <ltmp0+0x1c64>
    202c:      	b	0x1c6c <ltmp0+0x1c6c>
    2030:      	ldr	s12, [x9]
    2034:      	tbz	w5, #0x1, 0x1c94 <ltmp0+0x1c94>
    2038:      	add	x2, x9, #0x4
    203c:      	ld1.s	{ v12 }[1], [x2]
    2040:      	tbz	w5, #0x2, 0x1c98 <ltmp0+0x1c98>
    2044:      	add	x2, x9, #0x8
    2048:      	ld1.s	{ v12 }[2], [x2]
    204c:      	tbz	w5, #0x3, 0x1c9c <ltmp0+0x1c9c>
    2050:      	add	x2, x9, #0xc
    2054:      	ld1.s	{ v12 }[3], [x2]
    2058:      	tbz	w5, #0x4, 0x1ca0 <ltmp0+0x1ca0>
    205c:      	add	x2, x9, #0x10
    2060:      	ld1.s	{ v9 }[0], [x2]
    2064:      	tbz	w5, #0x5, 0x1ca4 <ltmp0+0x1ca4>
    2068:      	add	x2, x9, #0x14
    206c:      	ld1.s	{ v9 }[1], [x2]
    2070:      	tbz	w5, #0x6, 0x1ca8 <ltmp0+0x1ca8>
    2074:      	add	x2, x9, #0x18
    2078:      	ld1.s	{ v9 }[2], [x2]
    207c:      	tbnz	w5, #0x7, 0x1cac <ltmp0+0x1cac>
    2080:      	b	0x1cb4 <ltmp0+0x1cb4>
    2084:      	str	s29, [x9]
    2088:      	tbz	w17, #0x1, 0x1de4 <ltmp0+0x1de4>
    208c:      	add	x2, x9, #0x4
    2090:      	st1.s	{ v29 }[1], [x2]
    2094:      	tbz	w17, #0x2, 0x1de8 <ltmp0+0x1de8>
    2098:      	add	x2, x9, #0x8
    209c:      	st1.s	{ v29 }[2], [x2]
    20a0:      	tbnz	w17, #0x3, 0x1dec <ltmp0+0x1dec>
    20a4:      	b	0x1df4 <ltmp0+0x1df4>
    20a8:      	str	s24, [x9, #0x10]
    20ac:      	tbz	w17, #0x5, 0x1ecc <ltmp0+0x1ecc>
    20b0:      	add	x2, x9, #0x14
    20b4:      	st1.s	{ v24 }[1], [x2]
    20b8:      	tbz	w17, #0x6, 0x1ed0 <ltmp0+0x1ed0>
    20bc:      	add	x2, x9, #0x18
    20c0:      	st1.s	{ v24 }[2], [x2]
    20c4:      	tbz	w17, #0x7, 0xf8 <ltmp0+0xf8>
    20c8:      	add	x9, x9, #0x1c
    20cc:      	b	0xf4 <ltmp0+0xf4>
    20d0:      	ldr	x9, [sp, #0x10]
    20d4:      	stp	w30, w28, [x9]
    20d8:      	str	w27, [x9, #0x8]
    20dc:      	mov	w8, #0x18               ; =24
    20e0:      	str	w8, [x9, #0x24]
    20e4:      	add	sp, sp, #0x4c0
    20e8:      	ldp	x29, x30, [sp, #0x90]
    20ec:      	ldp	x20, x19, [sp, #0x80]
    20f0:      	ldp	x22, x21, [sp, #0x70]
    20f4:      	ldp	x24, x23, [sp, #0x60]
    20f8:      	ldp	x26, x25, [sp, #0x50]
    20fc:      	ldp	x28, x27, [sp, #0x40]
    2100:      	ldp	d9, d8, [sp, #0x30]
    2104:      	ldp	d11, d10, [sp, #0x20]
    2108:      	ldp	d13, d12, [sp, #0x10]
    210c:      	ldp	d15, d14, [sp], #0xa0
    2110:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/capture/rope-257x1538/on/object/tile_xir_w8_36497_1788935108412062_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      2c:      	sub	sp, sp, #0x4b0
      30:      	str	x0, [sp, #0x50]
      34:      	str	w3, [sp, #0x68]
      38:      	cbz	w3, 0x20a8 <ltmp0+0x20a8>
      3c:      	mov	w12, #0x0               ; =0
      40:      	ldp	w9, w8, [x2, #0x2c]
      44:      	stp	w8, w9, [sp, #0x60]
      48:      	mov	w11, #0x602             ; =1538
      4c:      	mov	w3, #0x1808             ; =6152
      50:      	ldp	w8, w9, [x2]
      54:      	add	x4, sp, #0x2, lsl #12   ; =0x2000
      58:      	add	x4, x4, #0x890
      5c:      	add	x5, sp, #0x1, lsl #12   ; =0x1000
      60:      	add	x5, x5, #0xc70
      64:      	ldp	w10, w13, [x2, #0x8]
      68:      	str	x2, [sp, #0x8]
      6c:      	str	x13, [sp, #0x58]
      70:      	add	x6, sp, #0x1, lsl #12   ; =0x1000
      74:      	add	x6, x6, #0x50
      78:      	add	x7, sp, #0x430
      7c:      	dup.2s	v8, w11
      80:      	adrp	x11, 0x0 <ltmp0>
      84:      	ldr	q0, [x11]
      88:      	str	q0, [sp, #0x40]
      8c:      	adrp	x11, 0x0 <ltmp0>
      90:      	ldr	q0, [x11]
      94:      	str	q0, [sp, #0x30]
      98:      	adrp	x11, 0x0 <ltmp0>
      9c:      	ldr	q0, [x11]
      a0:      	str	q0, [sp, #0x20]
      a4:      	b	0xf0 <ltmp0+0xf0>
      a8:      	ldr	x15, [sp, #0x78]
      ac:      	add	w8, w15, #0x1
      b0:      	ldp	w11, w9, [sp, #0x60]
      b4:      	cmp	w8, w9
      b8:      	cset	w9, eq
      bc:      	csinc	w8, wzr, w15, eq
      c0:      	ldp	w14, w13, [sp, #0x6c]
      c4:      	cinc	w10, w14, eq
      c8:      	cmp	w10, w11
      cc:      	cset	w11, eq
      d0:      	ands	w11, w9, w11
      d4:      	csel	w9, wzr, w10, ne
      d8:      	add	w10, w13, w11
      dc:      	ldr	w12, [sp, #0x74]
      e0:      	add	w12, w12, #0x1
      e4:      	ldr	w11, [sp, #0x68]
      e8:      	cmp	w12, w11
      ec:      	b.eq	0x2094 <ltmp0+0x2094>
      f0:      	str	w12, [sp, #0x74]
      f4:      	mov	x13, x10
      f8:      	mov	x14, x9
      fc:      	mov	x15, x8
     100:      	ubfiz	x8, x8, #5, #32
     104:      	ldr	x12, [sp, #0x58]
     108:      	cmp	x8, x12
     10c:      	csel	x9, x8, xzr, ls
     110:      	subs	x10, x12, x9
     114:      	cmp	x10, #0x20
     118:      	mov	w11, #0x20              ; =32
     11c:      	csel	x10, x10, x11, lo
     120:      	cmp	x12, x9
     124:      	ccmp	x8, x12, #0x2, hi
     128:      	csel	x8, x10, xzr, ls
     12c:      	cmp	x8, #0x20
     130:      	stp	w14, w13, [sp, #0x6c]
     134:      	str	x15, [sp, #0x78]
     138:      	b.lo	0x4d4 <ltmp0+0x4d4>
     13c:      	mov	w19, #0x0               ; =0
     140:      	ldr	x8, [sp, #0x50]
     144:      	ldr	x22, [x8]
     148:      	ldr	x23, [x8, #0x10]
     14c:      	ldr	x25, [x8, #0x20]
     150:      	ldr	x27, [x8, #0x30]
     154:      	subs	x8, x22, x27
     158:      	mov	w11, #0x2007            ; =8199
     15c:      	movk	w11, #0x18, lsl #16
     160:      	ccmp	x8, x11, #0x0, hs
     164:      	cset	w8, hi
     168:      	subs	x9, x27, x22
     16c:      	ccmp	x9, x11, #0x0, hs
     170:      	csinc	w8, w8, wzr, ls
     174:      	subs	x9, x23, x27
     178:      	ccmp	x9, x11, #0x0, hs
     17c:      	cset	w9, hi
     180:      	subs	x10, x27, x23
     184:      	mov	w12, #0x1003            ; =4099
     188:      	movk	w12, #0xc, lsl #16
     18c:      	ccmp	x10, x12, #0x0, hs
     190:      	csinc	w9, w9, wzr, ls
     194:      	and	w8, w8, w9
     198:      	subs	x9, x25, x27
     19c:      	ccmp	x9, x11, #0x0, hs
     1a0:      	cset	w9, hi
     1a4:      	subs	x10, x27, x25
     1a8:      	ccmp	x10, x12, #0x0, hs
     1ac:      	csinc	w9, w9, wzr, ls
     1b0:      	and	w16, w9, w8
     1b4:      	add	x28, x22, #0xc04
     1b8:      	add	x17, x27, #0xc04
     1bc:      	lsl	w0, w15, #2
     1c0:      	str	w16, [sp, #0xb0]
     1c4:      	str	x28, [sp, #0xa0]
     1c8:      	str	x17, [sp, #0x90]
     1cc:      	str	w0, [sp, #0x80]
     1d0:      	add	w8, w19, w0
     1d4:      	and	w8, w8, #0x1fffffff
     1d8:      	dup.2s	v0, w8
     1dc:      	ushll.2d	v1, v0, #0x0
     1e0:      	tbz	w16, #0x0, 0x2e4 <ltmp0+0x2e4>
     1e4:      	mov	x9, #0x0                ; =0
     1e8:      	xtn.2s	v0, v1
     1ec:      	umull.2d	v0, v0, v8
     1f0:      	fmov	x11, d0
     1f4:      	fmov	x8, d1
     1f8:      	mov	w10, #0x301             ; =769
     1fc:      	umull	x10, w8, w10
     200:      	lsl	x12, x11, #2
     204:      	add	x11, x17, x12
     208:      	add	x12, x28, x12
     20c:      	fmov	d1, x9
     210:      	add.2d	v1, v1, v0
     214:      	fmov	x13, d1
     218:      	lsl	x13, x13, #2
     21c:      	add	x14, x22, x13
     220:      	ldp	q1, q2, [x14]
     224:      	ldp	q3, q4, [x12], #0x20
     228:      	add	x14, x9, x10
     22c:      	lsl	x14, x14, #2
     230:      	add	x15, x23, x14
     234:      	ldp	q5, q6, [x15]
     238:      	add	x14, x25, x14
     23c:      	ldp	q7, q16, [x14]
     240:      	fmul.4s	v17, v2, v6
     244:      	fmul.4s	v18, v1, v5
     248:      	fmul.4s	v19, v4, v16
     24c:      	fmul.4s	v20, v3, v7
     250:      	fsub.4s	v18, v18, v20
     254:      	fsub.4s	v17, v17, v19
     258:      	add	x13, x27, x13
     25c:      	stp	q18, q17, [x13]
     260:      	fmul.4s	v2, v2, v16
     264:      	fmul.4s	v1, v1, v7
     268:      	fmul.4s	v4, v4, v6
     26c:      	fmul.4s	v3, v3, v5
     270:      	fadd.4s	v1, v3, v1
     274:      	fadd.4s	v2, v4, v2
     278:      	stp	q1, q2, [x11], #0x20
     27c:      	add	x9, x9, #0x8
     280:      	cmp	x9, #0x300
     284:      	b.ne	0x20c <ltmp0+0x20c>
     288:      	umull	x9, w8, w3
     28c:      	add	x9, x9, #0xc00
     290:      	ldr	s0, [x22, x9]
     294:      	mov	w10, #0x1804            ; =6148
     298:      	umaddl	x26, w8, w3, x10
     29c:      	ldr	s1, [x22, x26]
     2a0:      	mov	w10, #0xc04             ; =3076
     2a4:      	umull	x8, w8, w10
     2a8:      	add	x8, x8, #0xc00
     2ac:      	ldr	s2, [x23, x8]
     2b0:      	ldr	s3, [x25, x8]
     2b4:      	fmul.4s	v4, v0, v2
     2b8:      	fmul.4s	v5, v1, v3
     2bc:      	fsub.4s	v4, v4, v5
     2c0:      	str	s4, [x27, x9]
     2c4:      	fmul.4s	v0, v0, v3
     2c8:      	fmul.4s	v1, v1, v2
     2cc:      	fadd.4s	v0, v1, v0
     2d0:      	str	s0, [x27, x26]
     2d4:      	add	w19, w19, #0x1
     2d8:      	cmp	w19, #0x4
     2dc:      	b.ne	0x1d0 <ltmp0+0x1d0>
     2e0:      	b	0xa8 <ltmp0+0xa8>
     2e4:      	fmov	x21, d1
     2e8:      	umull	x20, w21, w3
     2ec:      	umaddl	x1, w21, w3, x22
     2f0:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     2f4:      	add	x0, x0, #0x890
     2f8:      	mov	w2, #0xc00              ; =3072
     2fc:      	mov	w24, #0x1808            ; =6152
     300:      	str	q21, [sp, #0xd0]
     304:      	bl	0x304 <ltmp0+0x304>
     308:      	str	x20, [sp, #0xc0]
     30c:      	add	x20, x20, #0xc00
     310:      	add	x8, x22, x20
     314:      	ldr	q0, [sp, #0x100]
     318:      	ld1.s	{ v0 }[0], [x8]
     31c:      	str	q0, [sp, #0x34a0]
     320:      	str	q0, [sp, #0x100]
     324:      	str	q0, [sp, #0x3490]
     328:      	umaddl	x1, w21, w24, x28
     32c:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     330:      	add	x0, x0, #0xc70
     334:      	mov	w2, #0xc00              ; =3072
     338:      	bl	0x338 <ltmp0+0x338>
     33c:      	mov	w8, #0x1804             ; =6148
     340:      	umaddl	x26, w21, w24, x8
     344:      	add	x8, x22, x26
     348:      	ldr	q0, [sp, #0xf0]
     34c:      	ld1.s	{ v0 }[0], [x8]
     350:      	str	q0, [sp, #0x2880]
     354:      	str	q0, [sp, #0xf0]
     358:      	str	q0, [sp, #0x2870]
     35c:      	mov	w28, #0xc04             ; =3076
     360:      	umull	x24, w21, w28
     364:      	umaddl	x1, w21, w28, x23
     368:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     36c:      	add	x0, x0, #0x50
     370:      	mov	w2, #0xc00              ; =3072
     374:      	bl	0x374 <ltmp0+0x374>
     378:      	add	x24, x24, #0xc00
     37c:      	add	x8, x23, x24
     380:      	ldr	q0, [sp, #0xe0]
     384:      	ld1.s	{ v0 }[0], [x8]
     388:      	str	q0, [sp, #0x1c60]
     38c:      	str	q0, [sp, #0xe0]
     390:      	str	q0, [sp, #0x1c50]
     394:      	umaddl	x1, w21, w28, x25
     398:      	add	x0, sp, #0x430
     39c:      	mov	w2, #0xc00              ; =3072
     3a0:      	bl	0x3a0 <ltmp0+0x3a0>
     3a4:      	ldr	q21, [sp, #0xd0]
     3a8:      	add	x7, sp, #0x430
     3ac:      	add	x6, sp, #0x1, lsl #12   ; =0x1000
     3b0:      	add	x6, x6, #0x50
     3b4:      	add	x5, sp, #0x1, lsl #12   ; =0x1000
     3b8:      	add	x5, x5, #0xc70
     3bc:      	add	x4, sp, #0x2, lsl #12   ; =0x2000
     3c0:      	add	x4, x4, #0x890
     3c4:      	mov	w3, #0x1808             ; =6152
     3c8:      	mov	x8, #0x0                ; =0
     3cc:      	add	x9, x25, x24
     3d0:      	ld1.s	{ v21 }[0], [x9]
     3d4:      	str	q0, [sp, #0x1040]
     3d8:      	str	q21, [sp, #0x1030]
     3dc:      	umaddl	x9, w21, w3, x27
     3e0:      	add	x10, x4, x8
     3e4:      	ldp	q0, q1, [x10]
     3e8:      	add	x10, x6, x8
     3ec:      	ldp	q2, q3, [x10]
     3f0:      	fmul.4s	v1, v1, v3
     3f4:      	fmul.4s	v0, v0, v2
     3f8:      	add	x10, x5, x8
     3fc:      	ldp	q2, q3, [x10]
     400:      	add	x10, x7, x8
     404:      	ldp	q4, q5, [x10]
     408:      	fmul.4s	v3, v3, v5
     40c:      	fmul.4s	v2, v2, v4
     410:      	fsub.4s	v0, v0, v2
     414:      	fsub.4s	v1, v1, v3
     418:      	add	x10, x9, x8
     41c:      	stp	q0, q1, [x10]
     420:      	add	x8, x8, #0x20
     424:      	cmp	x8, #0xc00
     428:      	b.ne	0x3e0 <ltmp0+0x3e0>
     42c:      	mov	x8, #0x0                ; =0
     430:      	ldr	q0, [sp, #0x100]
     434:      	ldp	q2, q1, [sp, #0xe0]
     438:      	fmul.4s	v0, v0, v2
     43c:      	fmul.4s	v1, v1, v21
     440:      	fsub.4s	v0, v0, v1
     444:      	str	s0, [x27, x20]
     448:      	ldr	x17, [sp, #0x90]
     44c:      	ldr	x9, [sp, #0xc0]
     450:      	add	x9, x17, x9
     454:      	add	x10, x4, x8
     458:      	ldp	q0, q1, [x10]
     45c:      	add	x10, x7, x8
     460:      	ldp	q2, q3, [x10]
     464:      	fmul.4s	v1, v1, v3
     468:      	fmul.4s	v0, v0, v2
     46c:      	add	x10, x5, x8
     470:      	ldp	q2, q3, [x10]
     474:      	add	x10, x6, x8
     478:      	ldp	q4, q5, [x10]
     47c:      	fmul.4s	v3, v3, v5
     480:      	fmul.4s	v2, v2, v4
     484:      	fadd.4s	v0, v0, v2
     488:      	fadd.4s	v1, v1, v3
     48c:      	add	x10, x9, x8
     490:      	stp	q0, q1, [x10]
     494:      	add	x8, x8, #0x20
     498:      	cmp	x8, #0xc00
     49c:      	b.ne	0x454 <ltmp0+0x454>
     4a0:      	ldp	q1, q0, [sp, #0xf0]
     4a4:      	fmul.4s	v0, v0, v21
     4a8:      	ldr	q2, [sp, #0xe0]
     4ac:      	fmul.4s	v1, v1, v2
     4b0:      	fadd.4s	v0, v1, v0
     4b4:      	ldr	w16, [sp, #0xb0]
     4b8:      	ldr	x28, [sp, #0xa0]
     4bc:      	ldr	w0, [sp, #0x80]
     4c0:      	str	s0, [x27, x26]
     4c4:      	add	w19, w19, #0x1
     4c8:      	cmp	w19, #0x4
     4cc:      	b.ne	0x1d0 <ltmp0+0x1d0>
     4d0:      	b	0xa8 <ltmp0+0xa8>
     4d4:      	lsr	x16, x8, #3
     4d8:      	str	x8, [sp, #0x80]
     4dc:      	cmp	x8, #0x8
     4e0:      	b.lo	0x844 <ltmp0+0x844>
     4e4:      	mov	w25, #0x0               ; =0
     4e8:      	ldr	x8, [sp, #0x50]
     4ec:      	ldr	x27, [x8]
     4f0:      	ldr	x26, [x8, #0x10]
     4f4:      	ldr	x23, [x8, #0x20]
     4f8:      	ldr	x19, [x8, #0x30]
     4fc:      	subs	x8, x27, x19
     500:      	mov	w11, #0x2007            ; =8199
     504:      	movk	w11, #0x18, lsl #16
     508:      	ccmp	x8, x11, #0x0, hs
     50c:      	cset	w8, hi
     510:      	subs	x9, x19, x27
     514:      	ccmp	x9, x11, #0x0, hs
     518:      	csinc	w8, w8, wzr, ls
     51c:      	subs	x9, x26, x19
     520:      	ccmp	x9, x11, #0x0, hs
     524:      	cset	w9, hi
     528:      	subs	x10, x19, x26
     52c:      	mov	w12, #0x1003            ; =4099
     530:      	movk	w12, #0xc, lsl #16
     534:      	ccmp	x10, x12, #0x0, hs
     538:      	csinc	w9, w9, wzr, ls
     53c:      	and	w8, w8, w9
     540:      	subs	x9, x23, x19
     544:      	ccmp	x9, x11, #0x0, hs
     548:      	cset	w9, hi
     54c:      	subs	x10, x19, x23
     550:      	ccmp	x10, x12, #0x0, hs
     554:      	csinc	w9, w9, wzr, ls
     558:      	and	w17, w9, w8
     55c:      	ldr	x8, [sp, #0x78]
     560:      	lsl	w0, w8, #2
     564:      	add	x8, x19, #0xc04
     568:      	str	x8, [sp, #0xa0]
     56c:      	add	x8, x27, #0xc04
     570:      	str	x8, [sp, #0x90]
     574:      	str	x16, [sp, #0xd0]
     578:      	str	w17, [sp, #0xc0]
     57c:      	str	w0, [sp, #0xb0]
     580:      	add	w8, w25, w0
     584:      	and	w8, w8, #0x1fffffff
     588:      	dup.2s	v0, w8
     58c:      	ushll.2d	v1, v0, #0x0
     590:      	tbz	w17, #0x0, 0x69c <ltmp0+0x69c>
     594:      	mov	x9, #0x0                ; =0
     598:      	xtn.2s	v0, v1
     59c:      	umull.2d	v0, v0, v8
     5a0:      	fmov	x11, d0
     5a4:      	fmov	x8, d1
     5a8:      	mov	w10, #0x301             ; =769
     5ac:      	umull	x10, w8, w10
     5b0:      	lsl	x12, x11, #2
     5b4:      	ldr	x11, [sp, #0xa0]
     5b8:      	add	x11, x11, x12
     5bc:      	ldr	x13, [sp, #0x90]
     5c0:      	add	x12, x13, x12
     5c4:      	fmov	d1, x9
     5c8:      	add.2d	v1, v1, v0
     5cc:      	fmov	x13, d1
     5d0:      	lsl	x13, x13, #2
     5d4:      	add	x14, x27, x13
     5d8:      	ldp	q1, q2, [x14]
     5dc:      	ldp	q3, q4, [x12], #0x20
     5e0:      	add	x14, x9, x10
     5e4:      	lsl	x14, x14, #2
     5e8:      	add	x15, x26, x14
     5ec:      	ldp	q5, q6, [x15]
     5f0:      	add	x14, x23, x14
     5f4:      	ldp	q7, q16, [x14]
     5f8:      	fmul.4s	v17, v2, v6
     5fc:      	fmul.4s	v18, v1, v5
     600:      	fmul.4s	v19, v4, v16
     604:      	fmul.4s	v20, v3, v7
     608:      	fsub.4s	v18, v18, v20
     60c:      	fsub.4s	v17, v17, v19
     610:      	add	x13, x19, x13
     614:      	stp	q18, q17, [x13]
     618:      	fmul.4s	v2, v2, v16
     61c:      	fmul.4s	v1, v1, v7
     620:      	fmul.4s	v4, v4, v6
     624:      	fmul.4s	v3, v3, v5
     628:      	fadd.4s	v1, v3, v1
     62c:      	fadd.4s	v2, v4, v2
     630:      	stp	q1, q2, [x11], #0x20
     634:      	add	x9, x9, #0x8
     638:      	cmp	x9, #0x300
     63c:      	b.ne	0x5c4 <ltmp0+0x5c4>
     640:      	umull	x9, w8, w3
     644:      	add	x9, x9, #0xc00
     648:      	ldr	s0, [x27, x9]
     64c:      	mov	w10, #0x1804            ; =6148
     650:      	umaddl	x22, w8, w3, x10
     654:      	ldr	s1, [x27, x22]
     658:      	mov	w10, #0xc04             ; =3076
     65c:      	umull	x8, w8, w10
     660:      	add	x8, x8, #0xc00
     664:      	ldr	s2, [x26, x8]
     668:      	ldr	s3, [x23, x8]
     66c:      	fmul.4s	v4, v0, v2
     670:      	fmul.4s	v5, v1, v3
     674:      	fsub.4s	v4, v4, v5
     678:      	str	s4, [x19, x9]
     67c:      	fmul.4s	v0, v0, v3
     680:      	fmul.4s	v1, v1, v2
     684:      	fadd.4s	v0, v1, v0
     688:      	str	s0, [x19, x22]
     68c:      	add	w25, w25, #0x1
     690:      	cmp	w25, w16
     694:      	b.ne	0x580 <ltmp0+0x580>
     698:      	b	0x844 <ltmp0+0x844>
     69c:      	fmov	x21, d1
     6a0:      	umull	x20, w21, w3
     6a4:      	umaddl	x22, w21, w3, x27
     6a8:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     6ac:      	add	x0, x0, #0x890
     6b0:      	mov	x1, x22
     6b4:      	mov	w2, #0xc00              ; =3072
     6b8:      	mov	w24, #0x1808            ; =6152
     6bc:      	bl	0x6bc <ltmp0+0x6bc>
     6c0:      	add	x20, x20, #0xc00
     6c4:      	ldr	s0, [x27, x20]
     6c8:      	str	q0, [sp, #0x100]
     6cc:      	str	q0, [sp, #0x3490]
     6d0:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     6d4:      	add	x0, x0, #0xc70
     6d8:      	add	x1, x22, #0xc04
     6dc:      	mov	w2, #0xc00              ; =3072
     6e0:      	bl	0x6e0 <ltmp0+0x6e0>
     6e4:      	mov	w8, #0x1804             ; =6148
     6e8:      	umaddl	x22, w21, w24, x8
     6ec:      	ldr	s0, [x27, x22]
     6f0:      	str	q0, [sp, #0xf0]
     6f4:      	str	q0, [sp, #0x2870]
     6f8:      	mov	w28, #0xc04             ; =3076
     6fc:      	umull	x24, w21, w28
     700:      	umaddl	x1, w21, w28, x26
     704:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     708:      	add	x0, x0, #0x50
     70c:      	mov	w2, #0xc00              ; =3072
     710:      	bl	0x710 <ltmp0+0x710>
     714:      	add	x24, x24, #0xc00
     718:      	ldr	s0, [x26, x24]
     71c:      	str	q0, [sp, #0xe0]
     720:      	str	q0, [sp, #0x1c50]
     724:      	umaddl	x1, w21, w28, x23
     728:      	add	x0, sp, #0x430
     72c:      	mov	w2, #0xc00              ; =3072
     730:      	bl	0x730 <ltmp0+0x730>
     734:      	add	x7, sp, #0x430
     738:      	add	x6, sp, #0x1, lsl #12   ; =0x1000
     73c:      	add	x6, x6, #0x50
     740:      	add	x5, sp, #0x1, lsl #12   ; =0x1000
     744:      	add	x5, x5, #0xc70
     748:      	add	x4, sp, #0x2, lsl #12   ; =0x2000
     74c:      	add	x4, x4, #0x890
     750:      	mov	w3, #0x1808             ; =6152
     754:      	mov	x9, #0x0                ; =0
     758:      	ldr	s0, [x23, x24]
     75c:      	str	q0, [sp, #0x1030]
     760:      	umaddl	x8, w21, w3, x19
     764:      	add	x10, x4, x9
     768:      	ldp	q1, q2, [x10]
     76c:      	add	x10, x6, x9
     770:      	ldp	q3, q4, [x10]
     774:      	fmul.4s	v2, v2, v4
     778:      	fmul.4s	v1, v1, v3
     77c:      	add	x10, x5, x9
     780:      	ldp	q3, q4, [x10]
     784:      	add	x10, x7, x9
     788:      	ldp	q5, q6, [x10]
     78c:      	fmul.4s	v4, v4, v6
     790:      	fmul.4s	v3, v3, v5
     794:      	fsub.4s	v1, v1, v3
     798:      	fsub.4s	v2, v2, v4
     79c:      	add	x10, x8, x9
     7a0:      	stp	q1, q2, [x10]
     7a4:      	add	x9, x9, #0x20
     7a8:      	cmp	x9, #0xc00
     7ac:      	b.ne	0x764 <ltmp0+0x764>
     7b0:      	mov	x9, #0x0                ; =0
     7b4:      	ldp	q16, q7, [sp, #0xf0]
     7b8:      	ldr	q17, [sp, #0xe0]
     7bc:      	fmul.4s	v1, v7, v17
     7c0:      	fmul.4s	v2, v16, v0
     7c4:      	fsub.4s	v1, v1, v2
     7c8:      	str	s1, [x19, x20]
     7cc:      	add	x8, x8, #0xc04
     7d0:      	ldr	x16, [sp, #0xd0]
     7d4:      	add	x10, x4, x9
     7d8:      	ldp	q1, q2, [x10]
     7dc:      	add	x10, x7, x9
     7e0:      	ldp	q3, q4, [x10]
     7e4:      	fmul.4s	v2, v2, v4
     7e8:      	fmul.4s	v1, v1, v3
     7ec:      	add	x10, x5, x9
     7f0:      	ldp	q3, q4, [x10]
     7f4:      	add	x10, x6, x9
     7f8:      	ldp	q5, q6, [x10]
     7fc:      	fmul.4s	v4, v4, v6
     800:      	fmul.4s	v3, v3, v5
     804:      	fadd.4s	v1, v1, v3
     808:      	fadd.4s	v2, v2, v4
     80c:      	add	x10, x8, x9
     810:      	stp	q1, q2, [x10]
     814:      	add	x9, x9, #0x20
     818:      	cmp	x9, #0xc00
     81c:      	b.ne	0x7d4 <ltmp0+0x7d4>
     820:      	fmul.4s	v0, v7, v0
     824:      	fmul.4s	v1, v16, v17
     828:      	fadd.4s	v0, v1, v0
     82c:      	ldr	w17, [sp, #0xc0]
     830:      	ldr	w0, [sp, #0xb0]
     834:      	str	s0, [x19, x22]
     838:      	add	w25, w25, #0x1
     83c:      	cmp	w25, w16
     840:      	b.ne	0x580 <ltmp0+0x580>
     844:      	ldr	x8, [sp, #0x80]
     848:      	and	w8, w8, #0x7
     84c:      	cbz	w8, 0xa8 <ltmp0+0xa8>
     850:      	dup.4s	v0, w8
     854:      	ldp	q2, q1, [sp, #0x30]
     858:      	cmhi.4s	v6, v0, v2
     85c:      	cmhi.4s	v0, v0, v1
     860:      	uzp1.8h	v21, v0, v6
     864:      	umaxv.8h	h1, v21
     868:      	fmov	w8, s1
     86c:      	tbz	w8, #0x0, 0xa8 <ltmp0+0xa8>
     870:      	ldr	x8, [sp, #0x50]
     874:      	ldr	x11, [x8]
     878:      	ldr	x10, [x8, #0x10]
     87c:      	ldr	x9, [x8, #0x20]
     880:      	ldr	x8, [x8, #0x30]
     884:      	sshll.2d	v1, v0, #0x0
     888:      	sshll.2d	v2, v6, #0x0
     88c:      	sshll2.2d	v24, v0, #0x0
     890:      	sshll2.2d	v23, v6, #0x0
     894:      	ldr	q3, [sp, #0x20]
     898:      	and.16b	v16, v23, v3
     89c:      	adrp	x12, 0x0 <ltmp0>
     8a0:      	ldr	q3, [x12]
     8a4:      	and.16b	v14, v24, v3
     8a8:      	adrp	x12, 0x0 <ltmp0>
     8ac:      	ldr	q3, [x12]
     8b0:      	and.16b	v15, v2, v3
     8b4:      	adrp	x12, 0x0 <ltmp0>
     8b8:      	ldr	q2, [x12]
     8bc:      	and.16b	v20, v1, v2
     8c0:      	ldr	x12, [sp, #0x78]
     8c4:      	ubfiz	w12, w12, #2, #27
     8c8:      	orr	w12, w12, w16
     8cc:      	dup.4s	v1, w12
     8d0:      	and.16b	v2, v0, v1
     8d4:      	and.16b	v1, v6, v1
     8d8:      	ushll2.2d	v4, v1, #0x0
     8dc:      	ushll2.2d	v5, v2, #0x0
     8e0:      	ushll.2d	v1, v1, #0x0
     8e4:      	ushll.2d	v3, v2, #0x0
     8e8:      	subs	x12, x11, x8
     8ec:      	mov	w15, #0x2007            ; =8199
     8f0:      	movk	w15, #0x18, lsl #16
     8f4:      	ccmp	x12, x15, #0x0, hs
     8f8:      	cset	w12, hi
     8fc:      	subs	x13, x8, x11
     900:      	ccmp	x13, x15, #0x0, hs
     904:      	csinc	w12, w12, wzr, ls
     908:      	subs	x13, x10, x8
     90c:      	ccmp	x13, x15, #0x0, hs
     910:      	cset	w13, hi
     914:      	subs	x14, x8, x10
     918:      	mov	w16, #0x1003            ; =4099
     91c:      	movk	w16, #0xc, lsl #16
     920:      	ccmp	x14, x16, #0x0, hs
     924:      	csinc	w13, w13, wzr, ls
     928:      	subs	x14, x9, x8
     92c:      	ccmp	x14, x15, #0x0, hs
     930:      	cset	w14, hi
     934:      	subs	x15, x8, x9
     938:      	ccmp	x15, x16, #0x0, hs
     93c:      	csinc	w14, w14, wzr, ls
     940:      	xtn.2s	v10, v5
     944:      	xtn.2s	v5, v1
     948:      	xtn.2s	v11, v4
     94c:      	xtn.2s	v1, v3
     950:      	mov	w15, #0x301             ; =769
     954:      	dup.2s	v2, w15
     958:      	cmp	w14, #0x1
     95c:      	adrp	x19, 0x0 <ltmp0>
     960:      	b.ne	0x1338 <ltmp0+0x1338>
     964:      	cbz	w12, 0x1338 <ltmp0+0x1338>
     968:      	tbz	w13, #0x0, 0x1338 <ltmp0+0x1338>
     96c:      	mov	x12, #0x0               ; =0
     970:      	umull.2d	v6, v10, v8
     974:      	umull.2d	v19, v5, v8
     978:      	umull.2d	v7, v11, v8
     97c:      	umull.2d	v22, v1, v8
     980:      	fmov	x13, d22
     984:      	add	x13, x13, #0x301
     988:      	fmov	x14, d3
     98c:      	mov	w15, #0x301             ; =769
     990:      	umull	x14, w14, w15
     994:      	b	0x9a4 <ltmp0+0x9a4>
     998:      	add	x12, x12, #0x8
     99c:      	cmp	x12, #0x300
     9a0:      	b.eq	0xdbc <ltmp0+0xdbc>
     9a4:      	ldr	q3, [x19]
     9a8:      	and.16b	v3, v21, v3
     9ac:      	addv.8h	h24, v3
     9b0:      	fmov	w17, s24
     9b4:      	dup.2d	v3, x12
     9b8:      	orr.16b	v26, v3, v20
     9bc:      	add.2d	v3, v26, v22
     9c0:      	fmov	x15, d3
     9c4:      	lsl	x15, x15, #2
     9c8:      	add	x16, x11, x15
     9cc:      	movi.2d	v25, #0000000000000000
     9d0:      	movi.2d	v23, #0000000000000000
     9d4:      	tbz	w17, #0x0, 0xa18 <ltmp0+0xa18>
     9d8:      	ldr	s25, [x16]
     9dc:      	and	w17, w17, #0xff
     9e0:      	tbnz	w17, #0x1, 0xa20 <ltmp0+0xa20>
     9e4:      	tbz	w17, #0x2, 0xa2c <ltmp0+0xa2c>
     9e8:      	add	x0, x16, #0x8
     9ec:      	ld1.s	{ v25 }[2], [x0]
     9f0:      	tbnz	w17, #0x3, 0xa30 <ltmp0+0xa30>
     9f4:      	tbz	w17, #0x4, 0xa3c <ltmp0+0xa3c>
     9f8:      	add	x0, x16, #0x10
     9fc:      	ld1.s	{ v23 }[0], [x0]
     a00:      	tbnz	w17, #0x5, 0xa40 <ltmp0+0xa40>
     a04:      	tbz	w17, #0x6, 0xa4c <ltmp0+0xa4c>
     a08:      	add	x0, x16, #0x18
     a0c:      	ld1.s	{ v23 }[2], [x0]
     a10:      	tbnz	w17, #0x7, 0xa50 <ltmp0+0xa50>
     a14:      	b	0xa58 <ltmp0+0xa58>
     a18:      	and	w17, w17, #0xff
     a1c:      	tbz	w17, #0x1, 0x9e4 <ltmp0+0x9e4>
     a20:      	add	x0, x16, #0x4
     a24:      	ld1.s	{ v25 }[1], [x0]
     a28:      	tbnz	w17, #0x2, 0x9e8 <ltmp0+0x9e8>
     a2c:      	tbz	w17, #0x3, 0x9f4 <ltmp0+0x9f4>
     a30:      	add	x0, x16, #0xc
     a34:      	ld1.s	{ v25 }[3], [x0]
     a38:      	tbnz	w17, #0x4, 0x9f8 <ltmp0+0x9f8>
     a3c:      	tbz	w17, #0x5, 0xa04 <ltmp0+0xa04>
     a40:      	add	x0, x16, #0x14
     a44:      	ld1.s	{ v23 }[1], [x0]
     a48:      	tbnz	w17, #0x6, 0xa08 <ltmp0+0xa08>
     a4c:      	tbz	w17, #0x7, 0xa58 <ltmp0+0xa58>
     a50:      	add	x16, x16, #0x1c
     a54:      	ld1.s	{ v23 }[3], [x16]
     a58:      	fmov	w1, s24
     a5c:      	fmov	x17, d26
     a60:      	add	x16, x13, x17
     a64:      	lsl	x16, x16, #2
     a68:      	add	x0, x11, x16
     a6c:      	movi.2d	v27, #0000000000000000
     a70:      	movi.2d	v26, #0000000000000000
     a74:      	tbz	w1, #0x0, 0xab8 <ltmp0+0xab8>
     a78:      	ldr	s27, [x0]
     a7c:      	and	w1, w1, #0xff
     a80:      	tbnz	w1, #0x1, 0xac0 <ltmp0+0xac0>
     a84:      	tbz	w1, #0x2, 0xacc <ltmp0+0xacc>
     a88:      	add	x2, x0, #0x8
     a8c:      	ld1.s	{ v27 }[2], [x2]
     a90:      	tbnz	w1, #0x3, 0xad0 <ltmp0+0xad0>
     a94:      	tbz	w1, #0x4, 0xadc <ltmp0+0xadc>
     a98:      	add	x2, x0, #0x10
     a9c:      	ld1.s	{ v26 }[0], [x2]
     aa0:      	tbnz	w1, #0x5, 0xae0 <ltmp0+0xae0>
     aa4:      	tbz	w1, #0x6, 0xaec <ltmp0+0xaec>
     aa8:      	add	x2, x0, #0x18
     aac:      	ld1.s	{ v26 }[2], [x2]
     ab0:      	tbnz	w1, #0x7, 0xaf0 <ltmp0+0xaf0>
     ab4:      	b	0xaf8 <ltmp0+0xaf8>
     ab8:      	and	w1, w1, #0xff
     abc:      	tbz	w1, #0x1, 0xa84 <ltmp0+0xa84>
     ac0:      	add	x2, x0, #0x4
     ac4:      	ld1.s	{ v27 }[1], [x2]
     ac8:      	tbnz	w1, #0x2, 0xa88 <ltmp0+0xa88>
     acc:      	tbz	w1, #0x3, 0xa94 <ltmp0+0xa94>
     ad0:      	add	x2, x0, #0xc
     ad4:      	ld1.s	{ v27 }[3], [x2]
     ad8:      	tbnz	w1, #0x4, 0xa98 <ltmp0+0xa98>
     adc:      	tbz	w1, #0x5, 0xaa4 <ltmp0+0xaa4>
     ae0:      	add	x2, x0, #0x14
     ae4:      	ld1.s	{ v26 }[1], [x2]
     ae8:      	tbnz	w1, #0x6, 0xaa8 <ltmp0+0xaa8>
     aec:      	tbz	w1, #0x7, 0xaf8 <ltmp0+0xaf8>
     af0:      	add	x0, x0, #0x1c
     af4:      	ld1.s	{ v26 }[3], [x0]
     af8:      	fmov	w1, s24
     afc:      	add	x17, x17, x14
     b00:      	lsl	x17, x17, #2
     b04:      	add	x0, x10, x17
     b08:      	movi.2d	v29, #0000000000000000
     b0c:      	movi.2d	v28, #0000000000000000
     b10:      	tbz	w1, #0x0, 0xc5c <ltmp0+0xc5c>
     b14:      	ldr	s29, [x0]
     b18:      	and	w1, w1, #0xff
     b1c:      	tbnz	w1, #0x1, 0xc64 <ltmp0+0xc64>
     b20:      	tbz	w1, #0x2, 0xc70 <ltmp0+0xc70>
     b24:      	add	x2, x0, #0x8
     b28:      	ld1.s	{ v29 }[2], [x2]
     b2c:      	tbnz	w1, #0x3, 0xc74 <ltmp0+0xc74>
     b30:      	tbz	w1, #0x4, 0xc80 <ltmp0+0xc80>
     b34:      	add	x2, x0, #0x10
     b38:      	ld1.s	{ v28 }[0], [x2]
     b3c:      	tbnz	w1, #0x5, 0xc84 <ltmp0+0xc84>
     b40:      	tbz	w1, #0x6, 0xc90 <ltmp0+0xc90>
     b44:      	add	x2, x0, #0x18
     b48:      	ld1.s	{ v28 }[2], [x2]
     b4c:      	tbnz	w1, #0x7, 0xc94 <ltmp0+0xc94>
     b50:      	fmov	w0, s24
     b54:      	add	x17, x9, x17
     b58:      	movi.2d	v31, #0000000000000000
     b5c:      	movi.2d	v30, #0000000000000000
     b60:      	tbz	w0, #0x0, 0xcb0 <ltmp0+0xcb0>
     b64:      	ldr	s31, [x17]
     b68:      	and	w0, w0, #0xff
     b6c:      	tbnz	w0, #0x1, 0xcb8 <ltmp0+0xcb8>
     b70:      	tbz	w0, #0x2, 0xcc4 <ltmp0+0xcc4>
     b74:      	add	x1, x17, #0x8
     b78:      	ld1.s	{ v31 }[2], [x1]
     b7c:      	tbnz	w0, #0x3, 0xcc8 <ltmp0+0xcc8>
     b80:      	tbz	w0, #0x4, 0xcd4 <ltmp0+0xcd4>
     b84:      	add	x1, x17, #0x10
     b88:      	ld1.s	{ v30 }[0], [x1]
     b8c:      	tbnz	w0, #0x5, 0xcd8 <ltmp0+0xcd8>
     b90:      	tbz	w0, #0x6, 0xce4 <ltmp0+0xce4>
     b94:      	add	x1, x17, #0x18
     b98:      	ld1.s	{ v30 }[2], [x1]
     b9c:      	tbnz	w0, #0x7, 0xce8 <ltmp0+0xce8>
     ba0:      	fmov	w17, s24
     ba4:      	fmul.4s	v3, v25, v29
     ba8:      	fmul.4s	v4, v27, v31
     bac:      	fsub.4s	v3, v3, v4
     bb0:      	add	x15, x8, x15
     bb4:      	tbz	w17, #0x0, 0xd08 <ltmp0+0xd08>
     bb8:      	str	s3, [x15]
     bbc:      	and	w17, w17, #0xff
     bc0:      	tbnz	w17, #0x1, 0xd10 <ltmp0+0xd10>
     bc4:      	tbz	w17, #0x2, 0xd1c <ltmp0+0xd1c>
     bc8:      	add	x0, x15, #0x8
     bcc:      	st1.s	{ v3 }[2], [x0]
     bd0:      	tbnz	w17, #0x3, 0xd20 <ltmp0+0xd20>
     bd4:      	fmul.4s	v3, v23, v28
     bd8:      	fmul.4s	v4, v26, v30
     bdc:      	fsub.4s	v3, v3, v4
     be0:      	tbz	w17, #0x4, 0xd38 <ltmp0+0xd38>
     be4:      	str	s3, [x15, #0x10]
     be8:      	tbnz	w17, #0x5, 0xd3c <ltmp0+0xd3c>
     bec:      	tbz	w17, #0x6, 0xd48 <ltmp0+0xd48>
     bf0:      	add	x0, x15, #0x18
     bf4:      	st1.s	{ v3 }[2], [x0]
     bf8:      	tbnz	w17, #0x7, 0xd4c <ltmp0+0xd4c>
     bfc:      	fmov	w17, s24
     c00:      	fmul.4s	v3, v25, v31
     c04:      	fmul.4s	v4, v27, v29
     c08:      	fadd.4s	v3, v4, v3
     c0c:      	add	x15, x8, x16
     c10:      	tbz	w17, #0x0, 0xd6c <ltmp0+0xd6c>
     c14:      	str	s3, [x15]
     c18:      	and	w16, w17, #0xff
     c1c:      	tbnz	w16, #0x1, 0xd74 <ltmp0+0xd74>
     c20:      	tbz	w16, #0x2, 0xd80 <ltmp0+0xd80>
     c24:      	add	x17, x15, #0x8
     c28:      	st1.s	{ v3 }[2], [x17]
     c2c:      	tbnz	w16, #0x3, 0xd84 <ltmp0+0xd84>
     c30:      	fmul.4s	v3, v23, v30
     c34:      	fmul.4s	v4, v26, v28
     c38:      	fadd.4s	v3, v4, v3
     c3c:      	tbz	w16, #0x4, 0xd9c <ltmp0+0xd9c>
     c40:      	str	s3, [x15, #0x10]
     c44:      	tbnz	w16, #0x5, 0xda0 <ltmp0+0xda0>
     c48:      	tbz	w16, #0x6, 0xdac <ltmp0+0xdac>
     c4c:      	add	x17, x15, #0x18
     c50:      	st1.s	{ v3 }[2], [x17]
     c54:      	tbz	w16, #0x7, 0x998 <ltmp0+0x998>
     c58:      	b	0xdb0 <ltmp0+0xdb0>
     c5c:      	and	w1, w1, #0xff
     c60:      	tbz	w1, #0x1, 0xb20 <ltmp0+0xb20>
     c64:      	add	x2, x0, #0x4
     c68:      	ld1.s	{ v29 }[1], [x2]
     c6c:      	tbnz	w1, #0x2, 0xb24 <ltmp0+0xb24>
     c70:      	tbz	w1, #0x3, 0xb30 <ltmp0+0xb30>
     c74:      	add	x2, x0, #0xc
     c78:      	ld1.s	{ v29 }[3], [x2]
     c7c:      	tbnz	w1, #0x4, 0xb34 <ltmp0+0xb34>
     c80:      	tbz	w1, #0x5, 0xb40 <ltmp0+0xb40>
     c84:      	add	x2, x0, #0x14
     c88:      	ld1.s	{ v28 }[1], [x2]
     c8c:      	tbnz	w1, #0x6, 0xb44 <ltmp0+0xb44>
     c90:      	tbz	w1, #0x7, 0xb50 <ltmp0+0xb50>
     c94:      	add	x0, x0, #0x1c
     c98:      	ld1.s	{ v28 }[3], [x0]
     c9c:      	fmov	w0, s24
     ca0:      	add	x17, x9, x17
     ca4:      	movi.2d	v31, #0000000000000000
     ca8:      	movi.2d	v30, #0000000000000000
     cac:      	tbnz	w0, #0x0, 0xb64 <ltmp0+0xb64>
     cb0:      	and	w0, w0, #0xff
     cb4:      	tbz	w0, #0x1, 0xb70 <ltmp0+0xb70>
     cb8:      	add	x1, x17, #0x4
     cbc:      	ld1.s	{ v31 }[1], [x1]
     cc0:      	tbnz	w0, #0x2, 0xb74 <ltmp0+0xb74>
     cc4:      	tbz	w0, #0x3, 0xb80 <ltmp0+0xb80>
     cc8:      	add	x1, x17, #0xc
     ccc:      	ld1.s	{ v31 }[3], [x1]
     cd0:      	tbnz	w0, #0x4, 0xb84 <ltmp0+0xb84>
     cd4:      	tbz	w0, #0x5, 0xb90 <ltmp0+0xb90>
     cd8:      	add	x1, x17, #0x14
     cdc:      	ld1.s	{ v30 }[1], [x1]
     ce0:      	tbnz	w0, #0x6, 0xb94 <ltmp0+0xb94>
     ce4:      	tbz	w0, #0x7, 0xba0 <ltmp0+0xba0>
     ce8:      	add	x17, x17, #0x1c
     cec:      	ld1.s	{ v30 }[3], [x17]
     cf0:      	fmov	w17, s24
     cf4:      	fmul.4s	v3, v25, v29
     cf8:      	fmul.4s	v4, v27, v31
     cfc:      	fsub.4s	v3, v3, v4
     d00:      	add	x15, x8, x15
     d04:      	tbnz	w17, #0x0, 0xbb8 <ltmp0+0xbb8>
     d08:      	and	w17, w17, #0xff
     d0c:      	tbz	w17, #0x1, 0xbc4 <ltmp0+0xbc4>
     d10:      	add	x0, x15, #0x4
     d14:      	st1.s	{ v3 }[1], [x0]
     d18:      	tbnz	w17, #0x2, 0xbc8 <ltmp0+0xbc8>
     d1c:      	tbz	w17, #0x3, 0xbd4 <ltmp0+0xbd4>
     d20:      	add	x0, x15, #0xc
     d24:      	st1.s	{ v3 }[3], [x0]
     d28:      	fmul.4s	v3, v23, v28
     d2c:      	fmul.4s	v4, v26, v30
     d30:      	fsub.4s	v3, v3, v4
     d34:      	tbnz	w17, #0x4, 0xbe4 <ltmp0+0xbe4>
     d38:      	tbz	w17, #0x5, 0xbec <ltmp0+0xbec>
     d3c:      	add	x0, x15, #0x14
     d40:      	st1.s	{ v3 }[1], [x0]
     d44:      	tbnz	w17, #0x6, 0xbf0 <ltmp0+0xbf0>
     d48:      	tbz	w17, #0x7, 0xbfc <ltmp0+0xbfc>
     d4c:      	add	x15, x15, #0x1c
     d50:      	st1.s	{ v3 }[3], [x15]
     d54:      	fmov	w17, s24
     d58:      	fmul.4s	v3, v25, v31
     d5c:      	fmul.4s	v4, v27, v29
     d60:      	fadd.4s	v3, v4, v3
     d64:      	add	x15, x8, x16
     d68:      	tbnz	w17, #0x0, 0xc14 <ltmp0+0xc14>
     d6c:      	and	w16, w17, #0xff
     d70:      	tbz	w16, #0x1, 0xc20 <ltmp0+0xc20>
     d74:      	add	x17, x15, #0x4
     d78:      	st1.s	{ v3 }[1], [x17]
     d7c:      	tbnz	w16, #0x2, 0xc24 <ltmp0+0xc24>
     d80:      	tbz	w16, #0x3, 0xc30 <ltmp0+0xc30>
     d84:      	add	x17, x15, #0xc
     d88:      	st1.s	{ v3 }[3], [x17]
     d8c:      	fmul.4s	v3, v23, v30
     d90:      	fmul.4s	v4, v26, v28
     d94:      	fadd.4s	v3, v4, v3
     d98:      	tbnz	w16, #0x4, 0xc40 <ltmp0+0xc40>
     d9c:      	tbz	w16, #0x5, 0xc48 <ltmp0+0xc48>
     da0:      	add	x17, x15, #0x14
     da4:      	st1.s	{ v3 }[1], [x17]
     da8:      	tbnz	w16, #0x6, 0xc4c <ltmp0+0xc4c>
     dac:      	tbz	w16, #0x7, 0x998 <ltmp0+0x998>
     db0:      	add	x15, x15, #0x1c
     db4:      	st1.s	{ v3 }[3], [x15]
     db8:      	b	0x998 <ltmp0+0x998>
     dbc:      	xtn.4h	v0, v0
     dc0:      	uzp1.8b	v0, v0, v0
     dc4:      	movi.2d	v29, #0000000000000000
     dc8:      	mov.b	v29[0], v0[0]
     dcc:      	adrp	x12, 0x0 <ltmp0>
     dd0:      	ldr	d26, [x12]
     dd4:      	and.8b	v3, v29, v26
     dd8:      	addv.8b	b3, v3
     ddc:      	fmov	w13, s3
     de0:      	umaxv.8b	b3, v29
     de4:      	fmov	w15, s3
     de8:      	rbit	w12, w13
     dec:      	clz	w12, w12
     df0:      	tst	w15, #0x1
     df4:      	csel	w12, w12, wzr, ne
     df8:      	mov	w14, #0x300             ; =768
     dfc:      	dup.2d	v31, x14
     e00:      	orr.16b	v30, v20, v31
     e04:      	add.2d	v23, v22, v30
     e08:      	movi.2d	v3, #0000000000000000
     e0c:      	mov.b	v3[0], v0[0]
     e10:      	ushll.2d	v0, v3, #0x0
     e14:      	shl.2d	v0, v0, #0x3f
     e18:      	cmlt.2d	v0, v0, #0
     e1c:      	and.16b	v0, v0, v23
     e20:      	movi.2d	v3, #0000000000000000
     e24:      	stp	q3, q3, [sp, #0x230]
     e28:      	stp	q0, q3, [sp, #0x210]
     e2c:      	and	x14, x12, #0x7
     e30:      	add	x16, sp, #0x210
     e34:      	ldr	x14, [x16, x14, lsl #3]
     e38:      	sub	x14, x14, x12
     e3c:      	add	x14, x11, x14, lsl #2
     e40:      	movi.2d	v21, #0000000000000000
     e44:      	movi.2d	v0, #0000000000000000
     e48:      	tbz	w15, #0x0, 0xe88 <ltmp0+0xe88>
     e4c:      	ldr	s21, [x14]
     e50:      	tbnz	w13, #0x1, 0xe8c <ltmp0+0xe8c>
     e54:      	tbz	w13, #0x2, 0xe98 <ltmp0+0xe98>
     e58:      	add	x15, x14, #0x8
     e5c:      	ld1.s	{ v21 }[2], [x15]
     e60:      	tbnz	w13, #0x3, 0xe9c <ltmp0+0xe9c>
     e64:      	tbz	w13, #0x4, 0xea8 <ltmp0+0xea8>
     e68:      	add	x15, x14, #0x10
     e6c:      	ld1.s	{ v0 }[0], [x15]
     e70:      	tbnz	w13, #0x5, 0xeac <ltmp0+0xeac>
     e74:      	tbz	w13, #0x6, 0xeb8 <ltmp0+0xeb8>
     e78:      	add	x15, x14, #0x18
     e7c:      	ld1.s	{ v0 }[2], [x15]
     e80:      	tbnz	w13, #0x7, 0xebc <ltmp0+0xebc>
     e84:      	b	0xec4 <ltmp0+0xec4>
     e88:      	tbz	w13, #0x1, 0xe54 <ltmp0+0xe54>
     e8c:      	add	x15, x14, #0x4
     e90:      	ld1.s	{ v21 }[1], [x15]
     e94:      	tbnz	w13, #0x2, 0xe58 <ltmp0+0xe58>
     e98:      	tbz	w13, #0x3, 0xe64 <ltmp0+0xe64>
     e9c:      	add	x15, x14, #0xc
     ea0:      	ld1.s	{ v21 }[3], [x15]
     ea4:      	tbnz	w13, #0x4, 0xe68 <ltmp0+0xe68>
     ea8:      	tbz	w13, #0x5, 0xe74 <ltmp0+0xe74>
     eac:      	add	x15, x14, #0x14
     eb0:      	ld1.s	{ v0 }[1], [x15]
     eb4:      	tbnz	w13, #0x6, 0xe78 <ltmp0+0xe78>
     eb8:      	tbz	w13, #0x7, 0xec4 <ltmp0+0xec4>
     ebc:      	add	x13, x14, #0x1c
     ec0:      	ld1.s	{ v0 }[3], [x13]
     ec4:      	add.2d	v3, v20, v22
     ec8:      	add.2d	v4, v14, v6
     ecc:      	add.2d	v22, v15, v19
     ed0:      	add.2d	v20, v16, v7
     ed4:      	mov	w13, #0x601             ; =1537
     ed8:      	dup.2d	v25, x13
     edc:      	add.2d	v20, v20, v25
     ee0:      	add.2d	v22, v22, v25
     ee4:      	add.2d	v24, v4, v25
     ee8:      	mov	b4, v29[0]
     eec:      	mov.b	v4[4], v29[1]
     ef0:      	add.2d	v25, v3, v25
     ef4:      	ushll.2d	v3, v4, #0x0
     ef8:      	shl.2d	v3, v3, #0x3f
     efc:      	cmlt.2d	v3, v3, #0
     f00:      	and.16b	v3, v3, v25
     f04:      	mov	b4, v29[2]
     f08:      	mov.b	v4[4], v29[3]
     f0c:      	ushll.2d	v4, v4, #0x0
     f10:      	shl.2d	v4, v4, #0x3f
     f14:      	cmlt.2d	v4, v4, #0
     f18:      	and.16b	v4, v4, v24
     f1c:      	mov	b27, v29[4]
     f20:      	mov.b	v27[4], v29[5]
     f24:      	ushll.2d	v27, v27, #0x0
     f28:      	shl.2d	v27, v27, #0x3f
     f2c:      	cmlt.2d	v27, v27, #0
     f30:      	and.16b	v28, v27, v22
     f34:      	mov	b27, v29[6]
     f38:      	mov.b	v27[4], v29[7]
     f3c:      	ushll.2d	v27, v27, #0x0
     f40:      	shl.2d	v27, v27, #0x3f
     f44:      	cmlt.2d	v27, v27, #0
     f48:      	and.16b	v9, v27, v20
     f4c:      	shl.8b	v27, v29, #0x7
     f50:      	cmlt.8b	v27, v27, #0
     f54:      	and.8b	v26, v27, v26
     f58:      	addv.8b	b27, v26
     f5c:      	fmov	w13, s27
     f60:      	stp	q28, q9, [sp, #0x1f0]
     f64:      	stp	q3, q4, [sp, #0x1d0]
     f68:      	and	x14, x12, #0x7
     f6c:      	add	x15, sp, #0x1d0
     f70:      	ldr	x14, [x15, x14, lsl #3]
     f74:      	sub	x14, x14, x12
     f78:      	add	x11, x11, x14, lsl #2
     f7c:      	movi.2d	v28, #0000000000000000
     f80:      	movi.2d	v26, #0000000000000000
     f84:      	tbz	w13, #0x0, 0xfc4 <ltmp0+0xfc4>
     f88:      	ldr	s28, [x11]
     f8c:      	tbnz	w13, #0x1, 0xfc8 <ltmp0+0xfc8>
     f90:      	tbz	w13, #0x2, 0xfd4 <ltmp0+0xfd4>
     f94:      	add	x14, x11, #0x8
     f98:      	ld1.s	{ v28 }[2], [x14]
     f9c:      	tbnz	w13, #0x3, 0xfd8 <ltmp0+0xfd8>
     fa0:      	tbz	w13, #0x4, 0xfe4 <ltmp0+0xfe4>
     fa4:      	add	x14, x11, #0x10
     fa8:      	ld1.s	{ v26 }[0], [x14]
     fac:      	tbnz	w13, #0x5, 0xfe8 <ltmp0+0xfe8>
     fb0:      	tbz	w13, #0x6, 0xff4 <ltmp0+0xff4>
     fb4:      	add	x14, x11, #0x18
     fb8:      	ld1.s	{ v26 }[2], [x14]
     fbc:      	tbnz	w13, #0x7, 0xff8 <ltmp0+0xff8>
     fc0:      	b	0x1000 <ltmp0+0x1000>
     fc4:      	tbz	w13, #0x1, 0xf90 <ltmp0+0xf90>
     fc8:      	add	x14, x11, #0x4
     fcc:      	ld1.s	{ v28 }[1], [x14]
     fd0:      	tbnz	w13, #0x2, 0xf94 <ltmp0+0xf94>
     fd4:      	tbz	w13, #0x3, 0xfa0 <ltmp0+0xfa0>
     fd8:      	add	x14, x11, #0xc
     fdc:      	ld1.s	{ v28 }[3], [x14]
     fe0:      	tbnz	w13, #0x4, 0xfa4 <ltmp0+0xfa4>
     fe4:      	tbz	w13, #0x5, 0xfb0 <ltmp0+0xfb0>
     fe8:      	add	x14, x11, #0x14
     fec:      	ld1.s	{ v26 }[1], [x14]
     ff0:      	tbnz	w13, #0x6, 0xfb4 <ltmp0+0xfb4>
     ff4:      	tbz	w13, #0x7, 0x1000 <ltmp0+0x1000>
     ff8:      	add	x11, x11, #0x1c
     ffc:      	ld1.s	{ v26 }[3], [x11]
    1000:      	orr.16b	v16, v16, v31
    1004:      	orr.16b	v17, v14, v31
    1008:      	orr.16b	v18, v15, v31
    100c:      	mov.16b	v3, v16
    1010:      	umlal.2d	v3, v11, v2
    1014:      	mov.16b	v4, v18
    1018:      	umlal.2d	v4, v5, v2
    101c:      	mov.16b	v5, v17
    1020:      	umlal.2d	v5, v10, v2
    1024:      	umlal.2d	v30, v1, v2
    1028:      	mov	b1, v29[0]
    102c:      	mov.b	v1[4], v29[1]
    1030:      	ushll.2d	v1, v1, #0x0
    1034:      	shl.2d	v1, v1, #0x3f
    1038:      	cmlt.2d	v1, v1, #0
    103c:      	and.16b	v1, v1, v30
    1040:      	mov	b2, v29[2]
    1044:      	mov.b	v2[4], v29[3]
    1048:      	ushll.2d	v2, v2, #0x0
    104c:      	shl.2d	v2, v2, #0x3f
    1050:      	cmlt.2d	v2, v2, #0
    1054:      	and.16b	v2, v2, v5
    1058:      	mov	b5, v29[4]
    105c:      	mov.b	v5[4], v29[5]
    1060:      	ushll.2d	v5, v5, #0x0
    1064:      	shl.2d	v5, v5, #0x3f
    1068:      	cmlt.2d	v5, v5, #0
    106c:      	mov	b30, v29[6]
    1070:      	mov.b	v30[4], v29[7]
    1074:      	and.16b	v4, v5, v4
    1078:      	ushll.2d	v5, v30, #0x0
    107c:      	shl.2d	v5, v5, #0x3f
    1080:      	cmlt.2d	v5, v5, #0
    1084:      	and.16b	v3, v5, v3
    1088:      	stp	q4, q3, [sp, #0x1b0]
    108c:      	stp	q1, q2, [sp, #0x190]
    1090:      	and	x11, x12, #0x7
    1094:      	add	x13, sp, #0x190
    1098:      	ldr	x11, [x13, x11, lsl #3]
    109c:      	fmov	w13, s27
    10a0:      	sub	x11, x11, x12
    10a4:      	lsl	x11, x11, #2
    10a8:      	add	x10, x10, x11
    10ac:      	movi.2d	v2, #0000000000000000
    10b0:      	movi.2d	v1, #0000000000000000
    10b4:      	tbz	w13, #0x0, 0x1140 <ltmp0+0x1140>
    10b8:      	ldr	s2, [x10]
    10bc:      	tbnz	w13, #0x1, 0x1144 <ltmp0+0x1144>
    10c0:      	tbz	w13, #0x2, 0x1150 <ltmp0+0x1150>
    10c4:      	add	x14, x10, #0x8
    10c8:      	ld1.s	{ v2 }[2], [x14]
    10cc:      	tbnz	w13, #0x3, 0x1154 <ltmp0+0x1154>
    10d0:      	tbz	w13, #0x4, 0x1160 <ltmp0+0x1160>
    10d4:      	add	x14, x10, #0x10
    10d8:      	ld1.s	{ v1 }[0], [x14]
    10dc:      	tbnz	w13, #0x5, 0x1164 <ltmp0+0x1164>
    10e0:      	tbz	w13, #0x6, 0x1170 <ltmp0+0x1170>
    10e4:      	add	x14, x10, #0x18
    10e8:      	ld1.s	{ v1 }[2], [x14]
    10ec:      	tbnz	w13, #0x7, 0x1174 <ltmp0+0x1174>
    10f0:      	add	x9, x9, x11
    10f4:      	fmov	w10, s27
    10f8:      	movi.2d	v4, #0000000000000000
    10fc:      	movi.2d	v3, #0000000000000000
    1100:      	tbz	w10, #0x0, 0x1190 <ltmp0+0x1190>
    1104:      	ldr	s4, [x9]
    1108:      	tbnz	w10, #0x1, 0x1194 <ltmp0+0x1194>
    110c:      	tbz	w10, #0x2, 0x11a0 <ltmp0+0x11a0>
    1110:      	add	x11, x9, #0x8
    1114:      	ld1.s	{ v4 }[2], [x11]
    1118:      	tbnz	w10, #0x3, 0x11a4 <ltmp0+0x11a4>
    111c:      	tbz	w10, #0x4, 0x11b0 <ltmp0+0x11b0>
    1120:      	add	x11, x9, #0x10
    1124:      	ld1.s	{ v3 }[0], [x11]
    1128:      	tbnz	w10, #0x5, 0x11b4 <ltmp0+0x11b4>
    112c:      	tbz	w10, #0x6, 0x11c0 <ltmp0+0x11c0>
    1130:      	add	x11, x9, #0x18
    1134:      	ld1.s	{ v3 }[2], [x11]
    1138:      	tbnz	w10, #0x7, 0x11c4 <ltmp0+0x11c4>
    113c:      	b	0x11cc <ltmp0+0x11cc>
    1140:      	tbz	w13, #0x1, 0x10c0 <ltmp0+0x10c0>
    1144:      	add	x14, x10, #0x4
    1148:      	ld1.s	{ v2 }[1], [x14]
    114c:      	tbnz	w13, #0x2, 0x10c4 <ltmp0+0x10c4>
    1150:      	tbz	w13, #0x3, 0x10d0 <ltmp0+0x10d0>
    1154:      	add	x14, x10, #0xc
    1158:      	ld1.s	{ v2 }[3], [x14]
    115c:      	tbnz	w13, #0x4, 0x10d4 <ltmp0+0x10d4>
    1160:      	tbz	w13, #0x5, 0x10e0 <ltmp0+0x10e0>
    1164:      	add	x14, x10, #0x14
    1168:      	ld1.s	{ v1 }[1], [x14]
    116c:      	tbnz	w13, #0x6, 0x10e4 <ltmp0+0x10e4>
    1170:      	tbz	w13, #0x7, 0x10f0 <ltmp0+0x10f0>
    1174:      	add	x10, x10, #0x1c
    1178:      	ld1.s	{ v1 }[3], [x10]
    117c:      	add	x9, x9, x11
    1180:      	fmov	w10, s27
    1184:      	movi.2d	v4, #0000000000000000
    1188:      	movi.2d	v3, #0000000000000000
    118c:      	tbnz	w10, #0x0, 0x1104 <ltmp0+0x1104>
    1190:      	tbz	w10, #0x1, 0x110c <ltmp0+0x110c>
    1194:      	add	x11, x9, #0x4
    1198:      	ld1.s	{ v4 }[1], [x11]
    119c:      	tbnz	w10, #0x2, 0x1110 <ltmp0+0x1110>
    11a0:      	tbz	w10, #0x3, 0x111c <ltmp0+0x111c>
    11a4:      	add	x11, x9, #0xc
    11a8:      	ld1.s	{ v4 }[3], [x11]
    11ac:      	tbnz	w10, #0x4, 0x1120 <ltmp0+0x1120>
    11b0:      	tbz	w10, #0x5, 0x112c <ltmp0+0x112c>
    11b4:      	add	x11, x9, #0x14
    11b8:      	ld1.s	{ v3 }[1], [x11]
    11bc:      	tbnz	w10, #0x6, 0x1130 <ltmp0+0x1130>
    11c0:      	tbz	w10, #0x7, 0x11cc <ltmp0+0x11cc>
    11c4:      	add	x9, x9, #0x1c
    11c8:      	ld1.s	{ v3 }[3], [x9]
    11cc:      	add.2d	v18, v19, v18
    11d0:      	add.2d	v6, v6, v17
    11d4:      	add.2d	v7, v7, v16
    11d8:      	fmul.4s	v5, v21, v2
    11dc:      	fmul.4s	v16, v28, v4
    11e0:      	fsub.4s	v5, v5, v16
    11e4:      	stp	q23, q6, [sp, #0x150]
    11e8:      	stp	q18, q7, [sp, #0x170]
    11ec:      	and	x9, x12, #0x7
    11f0:      	add	x10, sp, #0x150
    11f4:      	ldr	x9, [x10, x9, lsl #3]
    11f8:      	sub	x9, x9, x12
    11fc:      	add	x9, x8, x9, lsl #2
    1200:      	fmov	w10, s27
    1204:      	tbz	w10, #0x0, 0x124c <ltmp0+0x124c>
    1208:      	str	s5, [x9]
    120c:      	tbnz	w10, #0x1, 0x1250 <ltmp0+0x1250>
    1210:      	tbz	w10, #0x2, 0x125c <ltmp0+0x125c>
    1214:      	add	x11, x9, #0x8
    1218:      	st1.s	{ v5 }[2], [x11]
    121c:      	tbnz	w10, #0x3, 0x1260 <ltmp0+0x1260>
    1220:      	fmul.4s	v5, v0, v1
    1224:      	fmul.4s	v6, v26, v3
    1228:      	fsub.4s	v5, v5, v6
    122c:      	tbz	w10, #0x4, 0x1278 <ltmp0+0x1278>
    1230:      	str	s5, [x9, #0x10]
    1234:      	tbnz	w10, #0x5, 0x127c <ltmp0+0x127c>
    1238:      	tbz	w10, #0x6, 0x1288 <ltmp0+0x1288>
    123c:      	add	x11, x9, #0x18
    1240:      	st1.s	{ v5 }[2], [x11]
    1244:      	tbnz	w10, #0x7, 0x128c <ltmp0+0x128c>
    1248:      	b	0x1294 <ltmp0+0x1294>
    124c:      	tbz	w10, #0x1, 0x1210 <ltmp0+0x1210>
    1250:      	add	x11, x9, #0x4
    1254:      	st1.s	{ v5 }[1], [x11]
    1258:      	tbnz	w10, #0x2, 0x1214 <ltmp0+0x1214>
    125c:      	tbz	w10, #0x3, 0x1220 <ltmp0+0x1220>
    1260:      	add	x11, x9, #0xc
    1264:      	st1.s	{ v5 }[3], [x11]
    1268:      	fmul.4s	v5, v0, v1
    126c:      	fmul.4s	v6, v26, v3
    1270:      	fsub.4s	v5, v5, v6
    1274:      	tbnz	w10, #0x4, 0x1230 <ltmp0+0x1230>
    1278:      	tbz	w10, #0x5, 0x1238 <ltmp0+0x1238>
    127c:      	add	x11, x9, #0x14
    1280:      	st1.s	{ v5 }[1], [x11]
    1284:      	tbnz	w10, #0x6, 0x123c <ltmp0+0x123c>
    1288:      	tbz	w10, #0x7, 0x1294 <ltmp0+0x1294>
    128c:      	add	x9, x9, #0x1c
    1290:      	st1.s	{ v5 }[3], [x9]
    1294:      	fmul.4s	v4, v21, v4
    1298:      	fmul.4s	v2, v28, v2
    129c:      	fadd.4s	v2, v2, v4
    12a0:      	stp	q25, q24, [sp, #0x110]
    12a4:      	stp	q22, q20, [sp, #0x130]
    12a8:      	and	x9, x12, #0x7
    12ac:      	add	x10, sp, #0x110
    12b0:      	ldr	x9, [x10, x9, lsl #3]
    12b4:      	sub	x9, x9, x12
    12b8:      	add	x8, x8, x9, lsl #2
    12bc:      	fmov	w9, s27
    12c0:      	tbz	w9, #0x0, 0x1308 <ltmp0+0x1308>
    12c4:      	str	s2, [x8]
    12c8:      	tbnz	w9, #0x1, 0x130c <ltmp0+0x130c>
    12cc:      	tbz	w9, #0x2, 0x1318 <ltmp0+0x1318>
    12d0:      	add	x10, x8, #0x8
    12d4:      	st1.s	{ v2 }[2], [x10]
    12d8:      	tbnz	w9, #0x3, 0x131c <ltmp0+0x131c>
    12dc:      	fmul.4s	v0, v0, v3
    12e0:      	fmul.4s	v1, v26, v1
    12e4:      	fadd.4s	v0, v1, v0
    12e8:      	tbz	w9, #0x4, 0x2074 <ltmp0+0x2074>
    12ec:      	str	s0, [x8, #0x10]
    12f0:      	tbnz	w9, #0x5, 0x2078 <ltmp0+0x2078>
    12f4:      	tbz	w9, #0x6, 0x2084 <ltmp0+0x2084>
    12f8:      	add	x10, x8, #0x18
    12fc:      	st1.s	{ v0 }[2], [x10]
    1300:      	tbnz	w9, #0x7, 0x2088 <ltmp0+0x2088>
    1304:      	b	0xa8 <ltmp0+0xa8>
    1308:      	tbz	w9, #0x1, 0x12cc <ltmp0+0x12cc>
    130c:      	add	x10, x8, #0x4
    1310:      	st1.s	{ v2 }[1], [x10]
    1314:      	tbnz	w9, #0x2, 0x12d0 <ltmp0+0x12d0>
    1318:      	tbz	w9, #0x3, 0x12dc <ltmp0+0x12dc>
    131c:      	add	x10, x8, #0xc
    1320:      	st1.s	{ v2 }[3], [x10]
    1324:      	fmul.4s	v0, v0, v3
    1328:      	fmul.4s	v1, v26, v1
    132c:      	fadd.4s	v0, v1, v0
    1330:      	tbz	w9, #0x4, 0x2074 <ltmp0+0x2074>
    1334:      	b	0x12ec <ltmp0+0x12ec>
    1338:      	mov	x12, #0x0               ; =0
    133c:      	fmov	x15, d3
    1340:      	umaddl	x13, w15, w3, x11
    1344:      	b	0x1368 <ltmp0+0x1368>
    1348:      	add	x14, x4, x12
    134c:      	ldp	q4, q22, [x14]
    1350:      	bif.16b	v3, v22, v6
    1354:      	bit.16b	v4, v19, v0
    1358:      	stp	q4, q3, [x14]
    135c:      	add	x12, x12, #0x20
    1360:      	cmp	x12, #0xc00
    1364:      	b.eq	0x140c <ltmp0+0x140c>
    1368:      	ldr	q3, [x19]
    136c:      	and.16b	v3, v21, v3
    1370:      	addv.8h	h7, v3
    1374:      	fmov	w16, s7
    1378:      	add	x14, x13, x12
    137c:      	movi.2d	v19, #0000000000000000
    1380:      	movi.2d	v3, #0000000000000000
    1384:      	tbz	w16, #0x0, 0x13c8 <ltmp0+0x13c8>
    1388:      	ldr	s19, [x14]
    138c:      	and	w16, w16, #0xff
    1390:      	tbnz	w16, #0x1, 0x13d0 <ltmp0+0x13d0>
    1394:      	tbz	w16, #0x2, 0x13dc <ltmp0+0x13dc>
    1398:      	add	x17, x14, #0x8
    139c:      	ld1.s	{ v19 }[2], [x17]
    13a0:      	tbnz	w16, #0x3, 0x13e0 <ltmp0+0x13e0>
    13a4:      	tbz	w16, #0x4, 0x13ec <ltmp0+0x13ec>
    13a8:      	add	x17, x14, #0x10
    13ac:      	ld1.s	{ v3 }[0], [x17]
    13b0:      	tbnz	w16, #0x5, 0x13f0 <ltmp0+0x13f0>
    13b4:      	tbz	w16, #0x6, 0x13fc <ltmp0+0x13fc>
    13b8:      	add	x17, x14, #0x18
    13bc:      	ld1.s	{ v3 }[2], [x17]
    13c0:      	tbz	w16, #0x7, 0x1348 <ltmp0+0x1348>
    13c4:      	b	0x1400 <ltmp0+0x1400>
    13c8:      	and	w16, w16, #0xff
    13cc:      	tbz	w16, #0x1, 0x1394 <ltmp0+0x1394>
    13d0:      	add	x17, x14, #0x4
    13d4:      	ld1.s	{ v19 }[1], [x17]
    13d8:      	tbnz	w16, #0x2, 0x1398 <ltmp0+0x1398>
    13dc:      	tbz	w16, #0x3, 0x13a4 <ltmp0+0x13a4>
    13e0:      	add	x17, x14, #0xc
    13e4:      	ld1.s	{ v19 }[3], [x17]
    13e8:      	tbnz	w16, #0x4, 0x13a8 <ltmp0+0x13a8>
    13ec:      	tbz	w16, #0x5, 0x13b4 <ltmp0+0x13b4>
    13f0:      	add	x17, x14, #0x14
    13f4:      	ld1.s	{ v3 }[1], [x17]
    13f8:      	tbnz	w16, #0x6, 0x13b8 <ltmp0+0x13b8>
    13fc:      	tbz	w16, #0x7, 0x1348 <ltmp0+0x1348>
    1400:      	add	x14, x14, #0x1c
    1404:      	ld1.s	{ v3 }[3], [x14]
    1408:      	b	0x1348 <ltmp0+0x1348>
    140c:      	str	d11, [sp, #0x100]
    1410:      	xtn.4h	v3, v0
    1414:      	uzp1.8b	v3, v3, v0
    1418:      	movi.2d	v19, #0000000000000000
    141c:      	mov.b	v19[0], v3[0]
    1420:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    1424:      	ldr	d31, [x12]
    1428:      	and.8b	v4, v19, v31
    142c:      	addv.8b	b4, v4
    1430:      	fmov	w13, s4
    1434:      	umaxv.8b	b4, v19
    1438:      	fmov	w16, s4
    143c:      	rbit	w12, w13
    1440:      	clz	w12, w12
    1444:      	tst	w16, #0x1
    1448:      	csel	w12, w12, wzr, ne
    144c:      	mov	w14, #0x300             ; =768
    1450:      	dup.2d	v21, x14
    1454:      	orr.16b	v11, v20, v21
    1458:      	mov.16b	v17, v11
    145c:      	umlal.2d	v17, v1, v8
    1460:      	movi.2d	v4, #0000000000000000
    1464:      	mov.b	v4[0], v3[0]
    1468:      	ushll.2d	v3, v4, #0x0
    146c:      	shl.2d	v3, v3, #0x3f
    1470:      	cmlt.2d	v3, v3, #0
    1474:      	str	q17, [sp, #0xb0]
    1478:      	and.16b	v3, v3, v17
    147c:      	movi.2d	v4, #0000000000000000
    1480:      	str	q4, [sp, #0x410]
    1484:      	stp	q4, q4, [sp, #0x3f0]
    1488:      	str	q3, [sp, #0x3e0]
    148c:      	and	x14, x12, #0x7
    1490:      	add	x17, sp, #0x3e0
    1494:      	ldr	x14, [x17, x14, lsl #3]
    1498:      	sub	x14, x14, x12
    149c:      	add	x14, x11, x14, lsl #2
    14a0:      	movi.2d	v25, #0000000000000000
    14a4:      	movi.2d	v26, #0000000000000000
    14a8:      	tbz	w16, #0x0, 0x14e8 <ltmp0+0x14e8>
    14ac:      	ldr	s25, [x14]
    14b0:      	tbnz	w13, #0x1, 0x14ec <ltmp0+0x14ec>
    14b4:      	tbz	w13, #0x2, 0x14f8 <ltmp0+0x14f8>
    14b8:      	add	x16, x14, #0x8
    14bc:      	ld1.s	{ v25 }[2], [x16]
    14c0:      	tbnz	w13, #0x3, 0x14fc <ltmp0+0x14fc>
    14c4:      	tbz	w13, #0x4, 0x1508 <ltmp0+0x1508>
    14c8:      	add	x16, x14, #0x10
    14cc:      	ld1.s	{ v26 }[0], [x16]
    14d0:      	tbnz	w13, #0x5, 0x150c <ltmp0+0x150c>
    14d4:      	tbz	w13, #0x6, 0x1518 <ltmp0+0x1518>
    14d8:      	add	x16, x14, #0x18
    14dc:      	ld1.s	{ v26 }[2], [x16]
    14e0:      	tbnz	w13, #0x7, 0x151c <ltmp0+0x151c>
    14e4:      	b	0x1524 <ltmp0+0x1524>
    14e8:      	tbz	w13, #0x1, 0x14b4 <ltmp0+0x14b4>
    14ec:      	add	x16, x14, #0x4
    14f0:      	ld1.s	{ v25 }[1], [x16]
    14f4:      	tbnz	w13, #0x2, 0x14b8 <ltmp0+0x14b8>
    14f8:      	tbz	w13, #0x3, 0x14c4 <ltmp0+0x14c4>
    14fc:      	add	x16, x14, #0xc
    1500:      	ld1.s	{ v25 }[3], [x16]
    1504:      	tbnz	w13, #0x4, 0x14c8 <ltmp0+0x14c8>
    1508:      	tbz	w13, #0x5, 0x14d4 <ltmp0+0x14d4>
    150c:      	add	x16, x14, #0x14
    1510:      	ld1.s	{ v26 }[1], [x16]
    1514:      	tbnz	w13, #0x6, 0x14d8 <ltmp0+0x14d8>
    1518:      	tbz	w13, #0x7, 0x1524 <ltmp0+0x1524>
    151c:      	add	x14, x14, #0x1c
    1520:      	ld1.s	{ v26 }[3], [x14]
    1524:      	mov	x17, #0x0               ; =0
    1528:      	orr.16b	v12, v16, v21
    152c:      	mov.16b	v13, v14
    1530:      	orr.16b	v14, v14, v21
    1534:      	mov.16b	v18, v15
    1538:      	orr.16b	v17, v15, v21
    153c:      	umull.2d	v9, v1, v8
    1540:      	fmov	d3, d10
    1544:      	umull.2d	v10, v10, v8
    1548:      	umull.2d	v15, v5, v8
    154c:      	ldr	d4, [sp, #0x100]
    1550:      	umull.2d	v21, v4, v8
    1554:      	mov.16b	v22, v17
    1558:      	str	d5, [sp, #0xd0]
    155c:      	umlal.2d	v22, v5, v8
    1560:      	mov.16b	v5, v14
    1564:      	str	d3, [sp, #0xe0]
    1568:      	umlal.2d	v5, v3, v8
    156c:      	stp	q5, q22, [sp, #0x90]
    1570:      	mov.16b	v3, v12
    1574:      	umlal.2d	v3, v4, v8
    1578:      	str	q3, [sp, #0x80]
    157c:      	adrp	x14, 0x1000 <ltmp0+0x1000>
    1580:      	ldr	q3, [x14]
    1584:      	mov	w14, #0xc00             ; =3072
    1588:      	dup.2d	v4, x14
    158c:      	sshll.2d	v27, v0, #0x0
    1590:      	bif.16b	v3, v4, v27
    1594:      	adrp	x14, 0x1000 <ltmp0+0x1000>
    1598:      	ldr	q27, [x14]
    159c:      	sshll.2d	v28, v6, #0x0
    15a0:      	bif.16b	v27, v4, v28
    15a4:      	adrp	x14, 0x1000 <ltmp0+0x1000>
    15a8:      	ldr	q28, [x14]
    15ac:      	bsl.16b	v24, v28, v4
    15b0:      	adrp	x14, 0x1000 <ltmp0+0x1000>
    15b4:      	ldr	q28, [x14]
    15b8:      	bit.16b	v4, v28, v23
    15bc:      	stp	q27, q4, [sp, #0x3c0]
    15c0:      	stp	q3, q24, [sp, #0x3a0]
    15c4:      	and	x14, x12, #0x7
    15c8:      	add	x16, sp, #0x3a0
    15cc:      	ldr	x14, [x16, x14, lsl #3]
    15d0:      	sub	x14, x14, x12, lsl #2
    15d4:      	tst	w13, #0xff
    15d8:      	csel	x13, xzr, x14, eq
    15dc:      	add	x14, x4, x13
    15e0:      	ldp	q3, q4, [x14]
    15e4:      	zip2.8b	v23, v19, v0
    15e8:      	ushll.4s	v23, v23, #0x0
    15ec:      	shl.4s	v23, v23, #0x1f
    15f0:      	cmlt.4s	v23, v23, #0
    15f4:      	mov.16b	v5, v23
    15f8:      	bsl.16b	v5, v26, v4
    15fc:      	zip1.8b	v4, v19, v0
    1600:      	ushll.4s	v4, v4, #0x0
    1604:      	shl.4s	v4, v4, #0x1f
    1608:      	cmlt.4s	v4, v4, #0
    160c:      	bit.16b	v3, v25, v4
    1610:      	str	q3, [sp, #0xf0]
    1614:      	stp	q3, q5, [x14]
    1618:      	str	q5, [sp, #0xc0]
    161c:      	fmov	x14, d9
    1620:      	ushll2.2d	v3, v6, #0x0
    1624:      	mov	w16, #0x1               ; =1
    1628:      	dup.2d	v4, x16
    162c:      	and.16b	v24, v3, v4
    1630:      	ushll2.2d	v3, v0, #0x0
    1634:      	and.16b	v25, v3, v4
    1638:      	ushll.2d	v3, v6, #0x0
    163c:      	and.16b	v26, v3, v4
    1640:      	ushll.2d	v3, v0, #0x0
    1644:      	and.16b	v27, v3, v4
    1648:      	lsl	x14, x14, #2
    164c:      	add	x16, x11, x14
    1650:      	add	x16, x16, #0xc04
    1654:      	movi.2d	v23, #0000000000000000
    1658:      	movi.2d	v28, #0000000000000000
    165c:      	movi.2d	v29, #0000000000000000
    1660:      	movi.2d	v30, #0000000000000000
    1664:      	b	0x1698 <ltmp0+0x1698>
    1668:      	add	x17, x5, x17
    166c:      	ldp	q5, q22, [x17]
    1670:      	bif.16b	v4, v22, v6
    1674:      	bif.16b	v3, v5, v0
    1678:      	stp	q3, q4, [x17]
    167c:      	add.2d	v28, v28, v25
    1680:      	add.2d	v29, v29, v26
    1684:      	add.2d	v30, v30, v24
    1688:      	add.2d	v23, v23, v27
    168c:      	fmov	x17, d23
    1690:      	cmp	x17, #0x60
    1694:      	b.ge	0x1734 <ltmp0+0x1734>
    1698:      	fmov	w1, s7
    169c:      	lsl	x17, x17, #5
    16a0:      	add	x0, x16, x17
    16a4:      	movi.2d	v3, #0000000000000000
    16a8:      	movi.2d	v4, #0000000000000000
    16ac:      	tbz	w1, #0x0, 0x16f0 <ltmp0+0x16f0>
    16b0:      	ldr	s3, [x0]
    16b4:      	and	w1, w1, #0xff
    16b8:      	tbnz	w1, #0x1, 0x16f8 <ltmp0+0x16f8>
    16bc:      	tbz	w1, #0x2, 0x1704 <ltmp0+0x1704>
    16c0:      	add	x2, x0, #0x8
    16c4:      	ld1.s	{ v3 }[2], [x2]
    16c8:      	tbnz	w1, #0x3, 0x1708 <ltmp0+0x1708>
    16cc:      	tbz	w1, #0x4, 0x1714 <ltmp0+0x1714>
    16d0:      	add	x2, x0, #0x10
    16d4:      	ld1.s	{ v4 }[0], [x2]
    16d8:      	tbnz	w1, #0x5, 0x1718 <ltmp0+0x1718>
    16dc:      	tbz	w1, #0x6, 0x1724 <ltmp0+0x1724>
    16e0:      	add	x2, x0, #0x18
    16e4:      	ld1.s	{ v4 }[2], [x2]
    16e8:      	tbz	w1, #0x7, 0x1668 <ltmp0+0x1668>
    16ec:      	b	0x1728 <ltmp0+0x1728>
    16f0:      	and	w1, w1, #0xff
    16f4:      	tbz	w1, #0x1, 0x16bc <ltmp0+0x16bc>
    16f8:      	add	x2, x0, #0x4
    16fc:      	ld1.s	{ v3 }[1], [x2]
    1700:      	tbnz	w1, #0x2, 0x16c0 <ltmp0+0x16c0>
    1704:      	tbz	w1, #0x3, 0x16cc <ltmp0+0x16cc>
    1708:      	add	x2, x0, #0xc
    170c:      	ld1.s	{ v3 }[3], [x2]
    1710:      	tbnz	w1, #0x4, 0x16d0 <ltmp0+0x16d0>
    1714:      	tbz	w1, #0x5, 0x16dc <ltmp0+0x16dc>
    1718:      	add	x2, x0, #0x14
    171c:      	ld1.s	{ v4 }[1], [x2]
    1720:      	tbnz	w1, #0x6, 0x16e0 <ltmp0+0x16e0>
    1724:      	tbz	w1, #0x7, 0x1668 <ltmp0+0x1668>
    1728:      	add	x0, x0, #0x1c
    172c:      	ld1.s	{ v4 }[3], [x0]
    1730:      	b	0x1668 <ltmp0+0x1668>
    1734:      	add.2d	v3, v20, v9
    1738:      	add.2d	v4, v13, v10
    173c:      	add.2d	v5, v18, v15
    1740:      	add.2d	v16, v16, v21
    1744:      	mov	w16, #0x601             ; =1537
    1748:      	dup.2d	v20, x16
    174c:      	add.2d	v18, v16, v20
    1750:      	add.2d	v15, v5, v20
    1754:      	add.2d	v16, v4, v20
    1758:      	mov	b4, v19[0]
    175c:      	mov.b	v4[4], v19[1]
    1760:      	add.2d	v20, v3, v20
    1764:      	ushll.2d	v3, v4, #0x0
    1768:      	shl.2d	v3, v3, #0x3f
    176c:      	cmlt.2d	v3, v3, #0
    1770:      	and.16b	v3, v3, v20
    1774:      	mov	b4, v19[2]
    1778:      	mov.b	v4[4], v19[3]
    177c:      	ushll.2d	v4, v4, #0x0
    1780:      	shl.2d	v4, v4, #0x3f
    1784:      	cmlt.2d	v4, v4, #0
    1788:      	and.16b	v4, v4, v16
    178c:      	mov	b5, v19[4]
    1790:      	mov.b	v5[4], v19[5]
    1794:      	ushll.2d	v5, v5, #0x0
    1798:      	shl.2d	v5, v5, #0x3f
    179c:      	cmlt.2d	v5, v5, #0
    17a0:      	and.16b	v5, v5, v15
    17a4:      	mov	b21, v19[6]
    17a8:      	mov.b	v21[4], v19[7]
    17ac:      	ushll.2d	v21, v21, #0x0
    17b0:      	shl.2d	v21, v21, #0x3f
    17b4:      	cmlt.2d	v21, v21, #0
    17b8:      	str	q18, [sp, #0x10]
    17bc:      	and.16b	v21, v21, v18
    17c0:      	shl.8b	v22, v19, #0x7
    17c4:      	cmlt.8b	v22, v22, #0
    17c8:      	and.8b	v22, v22, v31
    17cc:      	addv.8b	b31, v22
    17d0:      	fmov	w16, s31
    17d4:      	stp	q5, q21, [sp, #0x370]
    17d8:      	stp	q3, q4, [sp, #0x350]
    17dc:      	and	x17, x12, #0x7
    17e0:      	add	x0, sp, #0x350
    17e4:      	ldr	x17, [x0, x17, lsl #3]
    17e8:      	sub	x17, x17, x12
    17ec:      	add	x11, x11, x17, lsl #2
    17f0:      	movi.2d	v21, #0000000000000000
    17f4:      	movi.2d	v3, #0000000000000000
    17f8:      	tbz	w16, #0x0, 0x183c <ltmp0+0x183c>
    17fc:      	ldr	s21, [x11]
    1800:      	fmov	d18, d1
    1804:      	tbnz	w16, #0x1, 0x1844 <ltmp0+0x1844>
    1808:      	tbz	w16, #0x2, 0x1850 <ltmp0+0x1850>
    180c:      	add	x17, x11, #0x8
    1810:      	ld1.s	{ v21 }[2], [x17]
    1814:      	tbnz	w16, #0x3, 0x1854 <ltmp0+0x1854>
    1818:      	tbz	w16, #0x4, 0x1860 <ltmp0+0x1860>
    181c:      	add	x17, x11, #0x10
    1820:      	ld1.s	{ v3 }[0], [x17]
    1824:      	tbnz	w16, #0x5, 0x1864 <ltmp0+0x1864>
    1828:      	tbz	w16, #0x6, 0x1870 <ltmp0+0x1870>
    182c:      	add	x17, x11, #0x18
    1830:      	ld1.s	{ v3 }[2], [x17]
    1834:      	tbnz	w16, #0x7, 0x1874 <ltmp0+0x1874>
    1838:      	b	0x187c <ltmp0+0x187c>
    183c:      	fmov	d18, d1
    1840:      	tbz	w16, #0x1, 0x1808 <ltmp0+0x1808>
    1844:      	add	x17, x11, #0x4
    1848:      	ld1.s	{ v21 }[1], [x17]
    184c:      	tbnz	w16, #0x2, 0x180c <ltmp0+0x180c>
    1850:      	tbz	w16, #0x3, 0x1818 <ltmp0+0x1818>
    1854:      	add	x17, x11, #0xc
    1858:      	ld1.s	{ v21 }[3], [x17]
    185c:      	tbnz	w16, #0x4, 0x181c <ltmp0+0x181c>
    1860:      	tbz	w16, #0x5, 0x1828 <ltmp0+0x1828>
    1864:      	add	x17, x11, #0x14
    1868:      	ld1.s	{ v3 }[1], [x17]
    186c:      	tbnz	w16, #0x6, 0x182c <ltmp0+0x182c>
    1870:      	tbz	w16, #0x7, 0x187c <ltmp0+0x187c>
    1874:      	add	x11, x11, #0x1c
    1878:      	ld1.s	{ v3 }[3], [x11]
    187c:      	mov	x16, #0x0               ; =0
    1880:      	add	x11, x5, x13
    1884:      	ldp	q4, q5, [x11]
    1888:      	zip2.8b	v22, v19, v0
    188c:      	ushll.4s	v22, v22, #0x0
    1890:      	shl.4s	v22, v22, #0x1f
    1894:      	cmlt.4s	v22, v22, #0
    1898:      	mov.16b	v9, v22
    189c:      	bsl.16b	v9, v3, v5
    18a0:      	zip1.8b	v3, v19, v0
    18a4:      	ushll.4s	v3, v3, #0x0
    18a8:      	shl.4s	v3, v3, #0x1f
    18ac:      	cmlt.4s	v3, v3, #0
    18b0:      	mov.16b	v10, v3
    18b4:      	bsl.16b	v10, v21, v4
    18b8:      	stp	q10, q9, [x11]
    18bc:      	mov	w11, #0xc04             ; =3076
    18c0:      	umaddl	x11, w15, w11, x10
    18c4:      	movi.2d	v21, #0000000000000000
    18c8:      	movi.2d	v23, #0000000000000000
    18cc:      	movi.2d	v28, #0000000000000000
    18d0:      	movi.2d	v29, #0000000000000000
    18d4:      	b	0x1908 <ltmp0+0x1908>
    18d8:      	add	x15, x6, x15
    18dc:      	ldp	q5, q22, [x15]
    18e0:      	bif.16b	v4, v22, v6
    18e4:      	bif.16b	v3, v5, v0
    18e8:      	stp	q3, q4, [x15]
    18ec:      	add.2d	v23, v23, v25
    18f0:      	add.2d	v28, v28, v26
    18f4:      	add.2d	v29, v29, v24
    18f8:      	add.2d	v21, v21, v27
    18fc:      	fmov	x16, d21
    1900:      	cmp	x16, #0x60
    1904:      	b.ge	0x19a4 <ltmp0+0x19a4>
    1908:      	fmov	w17, s7
    190c:      	lsl	x15, x16, #5
    1910:      	add	x16, x11, x15
    1914:      	movi.2d	v3, #0000000000000000
    1918:      	movi.2d	v4, #0000000000000000
    191c:      	tbz	w17, #0x0, 0x1960 <ltmp0+0x1960>
    1920:      	ldr	s3, [x16]
    1924:      	and	w17, w17, #0xff
    1928:      	tbnz	w17, #0x1, 0x1968 <ltmp0+0x1968>
    192c:      	tbz	w17, #0x2, 0x1974 <ltmp0+0x1974>
    1930:      	add	x0, x16, #0x8
    1934:      	ld1.s	{ v3 }[2], [x0]
    1938:      	tbnz	w17, #0x3, 0x1978 <ltmp0+0x1978>
    193c:      	tbz	w17, #0x4, 0x1984 <ltmp0+0x1984>
    1940:      	add	x0, x16, #0x10
    1944:      	ld1.s	{ v4 }[0], [x0]
    1948:      	tbnz	w17, #0x5, 0x1988 <ltmp0+0x1988>
    194c:      	tbz	w17, #0x6, 0x1994 <ltmp0+0x1994>
    1950:      	add	x0, x16, #0x18
    1954:      	ld1.s	{ v4 }[2], [x0]
    1958:      	tbz	w17, #0x7, 0x18d8 <ltmp0+0x18d8>
    195c:      	b	0x1998 <ltmp0+0x1998>
    1960:      	and	w17, w17, #0xff
    1964:      	tbz	w17, #0x1, 0x192c <ltmp0+0x192c>
    1968:      	add	x0, x16, #0x4
    196c:      	ld1.s	{ v3 }[1], [x0]
    1970:      	tbnz	w17, #0x2, 0x1930 <ltmp0+0x1930>
    1974:      	tbz	w17, #0x3, 0x193c <ltmp0+0x193c>
    1978:      	add	x0, x16, #0xc
    197c:      	ld1.s	{ v3 }[3], [x0]
    1980:      	tbnz	w17, #0x4, 0x1940 <ltmp0+0x1940>
    1984:      	tbz	w17, #0x5, 0x194c <ltmp0+0x194c>
    1988:      	add	x0, x16, #0x14
    198c:      	ld1.s	{ v4 }[1], [x0]
    1990:      	tbnz	w17, #0x6, 0x1950 <ltmp0+0x1950>
    1994:      	tbz	w17, #0x7, 0x18d8 <ltmp0+0x18d8>
    1998:      	add	x16, x16, #0x1c
    199c:      	ld1.s	{ v4 }[3], [x16]
    19a0:      	b	0x18d8 <ltmp0+0x18d8>
    19a4:      	ldr	d1, [sp, #0x100]
    19a8:      	umlal.2d	v12, v1, v2
    19ac:      	ldr	d3, [sp, #0xd0]
    19b0:      	umlal.2d	v17, v3, v2
    19b4:      	ldr	d3, [sp, #0xe0]
    19b8:      	umlal.2d	v14, v3, v2
    19bc:      	umlal.2d	v11, v18, v2
    19c0:      	mov	b3, v19[0]
    19c4:      	mov.b	v3[4], v19[1]
    19c8:      	ushll.2d	v3, v3, #0x0
    19cc:      	shl.2d	v3, v3, #0x3f
    19d0:      	cmlt.2d	v3, v3, #0
    19d4:      	and.16b	v3, v3, v11
    19d8:      	mov	b4, v19[2]
    19dc:      	mov.b	v4[4], v19[3]
    19e0:      	ushll.2d	v4, v4, #0x0
    19e4:      	shl.2d	v4, v4, #0x3f
    19e8:      	cmlt.2d	v4, v4, #0
    19ec:      	and.16b	v4, v4, v14
    19f0:      	mov	b5, v19[4]
    19f4:      	mov.b	v5[4], v19[5]
    19f8:      	ushll.2d	v5, v5, #0x0
    19fc:      	shl.2d	v5, v5, #0x3f
    1a00:      	cmlt.2d	v5, v5, #0
    1a04:      	mov	b21, v19[6]
    1a08:      	mov.b	v21[4], v19[7]
    1a0c:      	and.16b	v5, v5, v17
    1a10:      	ushll.2d	v21, v21, #0x0
    1a14:      	shl.2d	v21, v21, #0x3f
    1a18:      	cmlt.2d	v21, v21, #0
    1a1c:      	and.16b	v21, v21, v12
    1a20:      	stp	q5, q21, [sp, #0x320]
    1a24:      	stp	q3, q4, [sp, #0x300]
    1a28:      	and	x11, x12, #0x7
    1a2c:      	add	x15, sp, #0x300
    1a30:      	ldr	x11, [x15, x11, lsl #3]
    1a34:      	fmov	w15, s31
    1a38:      	sub	x11, x11, x12
    1a3c:      	lsl	x11, x11, #2
    1a40:      	add	x10, x10, x11
    1a44:      	movi.2d	v3, #0000000000000000
    1a48:      	movi.2d	v4, #0000000000000000
    1a4c:      	tbz	w15, #0x0, 0x1a90 <ltmp0+0x1a90>
    1a50:      	ldr	s3, [x10]
    1a54:      	ldr	q17, [sp, #0xc0]
    1a58:      	tbnz	w15, #0x1, 0x1a98 <ltmp0+0x1a98>
    1a5c:      	tbz	w15, #0x2, 0x1aa4 <ltmp0+0x1aa4>
    1a60:      	add	x16, x10, #0x8
    1a64:      	ld1.s	{ v3 }[2], [x16]
    1a68:      	tbnz	w15, #0x3, 0x1aa8 <ltmp0+0x1aa8>
    1a6c:      	tbz	w15, #0x4, 0x1ab4 <ltmp0+0x1ab4>
    1a70:      	add	x16, x10, #0x10
    1a74:      	ld1.s	{ v4 }[0], [x16]
    1a78:      	tbnz	w15, #0x5, 0x1ab8 <ltmp0+0x1ab8>
    1a7c:      	tbz	w15, #0x6, 0x1ac4 <ltmp0+0x1ac4>
    1a80:      	add	x16, x10, #0x18
    1a84:      	ld1.s	{ v4 }[2], [x16]
    1a88:      	tbnz	w15, #0x7, 0x1ac8 <ltmp0+0x1ac8>
    1a8c:      	b	0x1ad0 <ltmp0+0x1ad0>
    1a90:      	ldr	q17, [sp, #0xc0]
    1a94:      	tbz	w15, #0x1, 0x1a5c <ltmp0+0x1a5c>
    1a98:      	add	x16, x10, #0x4
    1a9c:      	ld1.s	{ v3 }[1], [x16]
    1aa0:      	tbnz	w15, #0x2, 0x1a60 <ltmp0+0x1a60>
    1aa4:      	tbz	w15, #0x3, 0x1a6c <ltmp0+0x1a6c>
    1aa8:      	add	x16, x10, #0xc
    1aac:      	ld1.s	{ v3 }[3], [x16]
    1ab0:      	tbnz	w15, #0x4, 0x1a70 <ltmp0+0x1a70>
    1ab4:      	tbz	w15, #0x5, 0x1a7c <ltmp0+0x1a7c>
    1ab8:      	add	x16, x10, #0x14
    1abc:      	ld1.s	{ v4 }[1], [x16]
    1ac0:      	tbnz	w15, #0x6, 0x1a80 <ltmp0+0x1a80>
    1ac4:      	tbz	w15, #0x7, 0x1ad0 <ltmp0+0x1ad0>
    1ac8:      	add	x10, x10, #0x1c
    1acc:      	ld1.s	{ v4 }[3], [x10]
    1ad0:      	mov	x15, #0x0               ; =0
    1ad4:      	umull.2d	v5, v18, v2
    1ad8:      	add	x10, x6, x13
    1adc:      	ldp	q2, q1, [x10]
    1ae0:      	zip2.8b	v21, v19, v0
    1ae4:      	ushll.4s	v21, v21, #0x0
    1ae8:      	shl.4s	v21, v21, #0x1f
    1aec:      	cmlt.4s	v21, v21, #0
    1af0:      	bit.16b	v1, v4, v21
    1af4:      	zip1.8b	v4, v19, v0
    1af8:      	ushll.4s	v4, v4, #0x0
    1afc:      	shl.4s	v4, v4, #0x1f
    1b00:      	cmlt.4s	v4, v4, #0
    1b04:      	bit.16b	v2, v3, v4
    1b08:      	stp	q2, q1, [x10]
    1b0c:      	fmov	x10, d5
    1b10:      	add	x10, x9, x10, lsl #2
    1b14:      	movi.2d	v3, #0000000000000000
    1b18:      	movi.2d	v4, #0000000000000000
    1b1c:      	movi.2d	v5, #0000000000000000
    1b20:      	movi.2d	v21, #0000000000000000
    1b24:      	b	0x1b58 <ltmp0+0x1b58>
    1b28:      	add	x15, x7, x15
    1b2c:      	ldp	q22, q29, [x15]
    1b30:      	bif.16b	v28, v29, v6
    1b34:      	bit.16b	v22, v23, v0
    1b38:      	stp	q22, q28, [x15]
    1b3c:      	add.2d	v4, v4, v25
    1b40:      	add.2d	v5, v5, v26
    1b44:      	add.2d	v21, v21, v24
    1b48:      	add.2d	v3, v3, v27
    1b4c:      	fmov	x15, d3
    1b50:      	cmp	x15, #0x60
    1b54:      	b.ge	0x1bf4 <ltmp0+0x1bf4>
    1b58:      	fmov	w17, s7
    1b5c:      	lsl	x15, x15, #5
    1b60:      	add	x16, x10, x15
    1b64:      	movi.2d	v23, #0000000000000000
    1b68:      	movi.2d	v28, #0000000000000000
    1b6c:      	tbz	w17, #0x0, 0x1bb0 <ltmp0+0x1bb0>
    1b70:      	ldr	s23, [x16]
    1b74:      	and	w17, w17, #0xff
    1b78:      	tbnz	w17, #0x1, 0x1bb8 <ltmp0+0x1bb8>
    1b7c:      	tbz	w17, #0x2, 0x1bc4 <ltmp0+0x1bc4>
    1b80:      	add	x0, x16, #0x8
    1b84:      	ld1.s	{ v23 }[2], [x0]
    1b88:      	tbnz	w17, #0x3, 0x1bc8 <ltmp0+0x1bc8>
    1b8c:      	tbz	w17, #0x4, 0x1bd4 <ltmp0+0x1bd4>
    1b90:      	add	x0, x16, #0x10
    1b94:      	ld1.s	{ v28 }[0], [x0]
    1b98:      	tbnz	w17, #0x5, 0x1bd8 <ltmp0+0x1bd8>
    1b9c:      	tbz	w17, #0x6, 0x1be4 <ltmp0+0x1be4>
    1ba0:      	add	x0, x16, #0x18
    1ba4:      	ld1.s	{ v28 }[2], [x0]
    1ba8:      	tbz	w17, #0x7, 0x1b28 <ltmp0+0x1b28>
    1bac:      	b	0x1be8 <ltmp0+0x1be8>
    1bb0:      	and	w17, w17, #0xff
    1bb4:      	tbz	w17, #0x1, 0x1b7c <ltmp0+0x1b7c>
    1bb8:      	add	x0, x16, #0x4
    1bbc:      	ld1.s	{ v23 }[1], [x0]
    1bc0:      	tbnz	w17, #0x2, 0x1b80 <ltmp0+0x1b80>
    1bc4:      	tbz	w17, #0x3, 0x1b8c <ltmp0+0x1b8c>
    1bc8:      	add	x0, x16, #0xc
    1bcc:      	ld1.s	{ v23 }[3], [x0]
    1bd0:      	tbnz	w17, #0x4, 0x1b90 <ltmp0+0x1b90>
    1bd4:      	tbz	w17, #0x5, 0x1b9c <ltmp0+0x1b9c>
    1bd8:      	add	x0, x16, #0x14
    1bdc:      	ld1.s	{ v28 }[1], [x0]
    1be0:      	tbnz	w17, #0x6, 0x1ba0 <ltmp0+0x1ba0>
    1be4:      	tbz	w17, #0x7, 0x1b28 <ltmp0+0x1b28>
    1be8:      	add	x16, x16, #0x1c
    1bec:      	ld1.s	{ v28 }[3], [x16]
    1bf0:      	b	0x1b28 <ltmp0+0x1b28>
    1bf4:      	add	x9, x9, x11
    1bf8:      	fmov	w10, s31
    1bfc:      	movi.2d	v4, #0000000000000000
    1c00:      	movi.2d	v3, #0000000000000000
    1c04:      	tbz	w10, #0x0, 0x1c44 <ltmp0+0x1c44>
    1c08:      	ldr	s4, [x9]
    1c0c:      	tbnz	w10, #0x1, 0x1c48 <ltmp0+0x1c48>
    1c10:      	tbz	w10, #0x2, 0x1c54 <ltmp0+0x1c54>
    1c14:      	add	x11, x9, #0x8
    1c18:      	ld1.s	{ v4 }[2], [x11]
    1c1c:      	tbnz	w10, #0x3, 0x1c58 <ltmp0+0x1c58>
    1c20:      	tbz	w10, #0x4, 0x1c64 <ltmp0+0x1c64>
    1c24:      	add	x11, x9, #0x10
    1c28:      	ld1.s	{ v3 }[0], [x11]
    1c2c:      	tbnz	w10, #0x5, 0x1c68 <ltmp0+0x1c68>
    1c30:      	tbz	w10, #0x6, 0x1c74 <ltmp0+0x1c74>
    1c34:      	add	x11, x9, #0x18
    1c38:      	ld1.s	{ v3 }[2], [x11]
    1c3c:      	tbnz	w10, #0x7, 0x1c78 <ltmp0+0x1c78>
    1c40:      	b	0x1c80 <ltmp0+0x1c80>
    1c44:      	tbz	w10, #0x1, 0x1c10 <ltmp0+0x1c10>
    1c48:      	add	x11, x9, #0x4
    1c4c:      	ld1.s	{ v4 }[1], [x11]
    1c50:      	tbnz	w10, #0x2, 0x1c14 <ltmp0+0x1c14>
    1c54:      	tbz	w10, #0x3, 0x1c20 <ltmp0+0x1c20>
    1c58:      	add	x11, x9, #0xc
    1c5c:      	ld1.s	{ v4 }[3], [x11]
    1c60:      	tbnz	w10, #0x4, 0x1c24 <ltmp0+0x1c24>
    1c64:      	tbz	w10, #0x5, 0x1c30 <ltmp0+0x1c30>
    1c68:      	add	x11, x9, #0x14
    1c6c:      	ld1.s	{ v3 }[1], [x11]
    1c70:      	tbnz	w10, #0x6, 0x1c34 <ltmp0+0x1c34>
    1c74:      	tbz	w10, #0x7, 0x1c80 <ltmp0+0x1c80>
    1c78:      	add	x9, x9, #0x1c
    1c7c:      	ld1.s	{ v3 }[3], [x9]
    1c80:      	mov	x10, #0x0               ; =0
    1c84:      	add	x9, x7, x13
    1c88:      	ldp	q5, q21, [x9]
    1c8c:      	zip2.8b	v22, v19, v0
    1c90:      	ushll.4s	v22, v22, #0x0
    1c94:      	shl.4s	v22, v22, #0x1f
    1c98:      	cmlt.4s	v22, v22, #0
    1c9c:      	bif.16b	v3, v21, v22
    1ca0:      	zip1.8b	v21, v19, v0
    1ca4:      	ushll.4s	v21, v21, #0x0
    1ca8:      	shl.4s	v21, v21, #0x1f
    1cac:      	cmlt.4s	v21, v21, #0
    1cb0:      	bif.16b	v4, v5, v21
    1cb4:      	stp	q4, q3, [x9]
    1cb8:      	add	x9, x8, x14
    1cbc:      	movi.2d	v5, #0000000000000000
    1cc0:      	movi.2d	v21, #0000000000000000
    1cc4:      	movi.2d	v23, #0000000000000000
    1cc8:      	movi.2d	v28, #0000000000000000
    1ccc:      	b	0x1cec <ltmp0+0x1cec>
    1cd0:      	add.2d	v21, v21, v25
    1cd4:      	add.2d	v23, v23, v26
    1cd8:      	add.2d	v28, v28, v24
    1cdc:      	add.2d	v5, v5, v27
    1ce0:      	fmov	x10, d5
    1ce4:      	cmp	x10, #0x60
    1ce8:      	b.ge	0x1dcc <ltmp0+0x1dcc>
    1cec:      	fmov	w11, s7
    1cf0:      	lsl	x10, x10, #5
    1cf4:      	add	x13, x4, x10
    1cf8:      	ldp	q22, q29, [x13]
    1cfc:      	add	x13, x6, x10
    1d00:      	ldp	q11, q30, [x13]
    1d04:      	fmul.4s	v22, v22, v11
    1d08:      	add	x13, x5, x10
    1d0c:      	ldp	q13, q11, [x13]
    1d10:      	add	x13, x7, x10
    1d14:      	ldp	q14, q12, [x13]
    1d18:      	fmul.4s	v13, v13, v14
    1d1c:      	fsub.4s	v22, v22, v13
    1d20:      	and.16b	v13, v0, v22
    1d24:      	add	x10, x9, x10
    1d28:      	tbz	w11, #0x0, 0x1d78 <ltmp0+0x1d78>
    1d2c:      	str	s13, [x10]
    1d30:      	and	w11, w11, #0xff
    1d34:      	tbnz	w11, #0x1, 0x1d80 <ltmp0+0x1d80>
    1d38:      	tbz	w11, #0x2, 0x1d8c <ltmp0+0x1d8c>
    1d3c:      	add	x13, x10, #0x8
    1d40:      	st1.s	{ v13 }[2], [x13]
    1d44:      	tbnz	w11, #0x3, 0x1d90 <ltmp0+0x1d90>
    1d48:      	fmul.4s	v22, v29, v30
    1d4c:      	fmul.4s	v29, v11, v12
    1d50:      	fsub.4s	v22, v22, v29
    1d54:      	and.16b	v29, v6, v22
    1d58:      	tbz	w11, #0x4, 0x1dac <ltmp0+0x1dac>
    1d5c:      	str	s29, [x10, #0x10]
    1d60:      	tbnz	w11, #0x5, 0x1db0 <ltmp0+0x1db0>
    1d64:      	tbz	w11, #0x6, 0x1dbc <ltmp0+0x1dbc>
    1d68:      	add	x13, x10, #0x18
    1d6c:      	st1.s	{ v29 }[2], [x13]
    1d70:      	tbz	w11, #0x7, 0x1cd0 <ltmp0+0x1cd0>
    1d74:      	b	0x1dc0 <ltmp0+0x1dc0>
    1d78:      	and	w11, w11, #0xff
    1d7c:      	tbz	w11, #0x1, 0x1d38 <ltmp0+0x1d38>
    1d80:      	add	x13, x10, #0x4
    1d84:      	st1.s	{ v13 }[1], [x13]
    1d88:      	tbnz	w11, #0x2, 0x1d3c <ltmp0+0x1d3c>
    1d8c:      	tbz	w11, #0x3, 0x1d48 <ltmp0+0x1d48>
    1d90:      	add	x13, x10, #0xc
    1d94:      	st1.s	{ v13 }[3], [x13]
    1d98:      	fmul.4s	v22, v29, v30
    1d9c:      	fmul.4s	v29, v11, v12
    1da0:      	fsub.4s	v22, v22, v29
    1da4:      	and.16b	v29, v6, v22
    1da8:      	tbnz	w11, #0x4, 0x1d5c <ltmp0+0x1d5c>
    1dac:      	tbz	w11, #0x5, 0x1d64 <ltmp0+0x1d64>
    1db0:      	add	x13, x10, #0x14
    1db4:      	st1.s	{ v29 }[1], [x13]
    1db8:      	tbnz	w11, #0x6, 0x1d68 <ltmp0+0x1d68>
    1dbc:      	tbz	w11, #0x7, 0x1cd0 <ltmp0+0x1cd0>
    1dc0:      	add	x10, x10, #0x1c
    1dc4:      	st1.s	{ v29 }[3], [x10]
    1dc8:      	b	0x1cd0 <ltmp0+0x1cd0>
    1dcc:      	ldr	q5, [sp, #0xf0]
    1dd0:      	fmul.4s	v5, v5, v2
    1dd4:      	fmul.4s	v21, v10, v4
    1dd8:      	fsub.4s	v5, v5, v21
    1ddc:      	zip1.8b	v21, v19, v0
    1de0:      	ushll.4s	v21, v21, #0x0
    1de4:      	shl.4s	v21, v21, #0x1f
    1de8:      	cmlt.4s	v21, v21, #0
    1dec:      	and.16b	v5, v21, v5
    1df0:      	fmov	w10, s31
    1df4:      	ldr	q21, [sp, #0xb0]
    1df8:      	ldp	q22, q23, [sp, #0x90]
    1dfc:      	stp	q21, q22, [sp, #0x2b0]
    1e00:      	ldr	q18, [sp, #0x80]
    1e04:      	stp	q23, q18, [sp, #0x2d0]
    1e08:      	and	x11, x12, #0x7
    1e0c:      	add	x13, sp, #0x2b0
    1e10:      	ldr	x11, [x13, x11, lsl #3]
    1e14:      	sub	x11, x11, x12
    1e18:      	add	x11, x8, x11, lsl #2
    1e1c:      	tbz	w10, #0x0, 0x1e3c <ltmp0+0x1e3c>
    1e20:      	str	s5, [x11]
    1e24:      	tbnz	w10, #0x1, 0x1e40 <ltmp0+0x1e40>
    1e28:      	tbz	w10, #0x2, 0x1e4c <ltmp0+0x1e4c>
    1e2c:      	add	x13, x11, #0x8
    1e30:      	st1.s	{ v5 }[2], [x13]
    1e34:      	tbnz	w10, #0x3, 0x1e50 <ltmp0+0x1e50>
    1e38:      	b	0x1e58 <ltmp0+0x1e58>
    1e3c:      	tbz	w10, #0x1, 0x1e28 <ltmp0+0x1e28>
    1e40:      	add	x13, x11, #0x4
    1e44:      	st1.s	{ v5 }[1], [x13]
    1e48:      	tbnz	w10, #0x2, 0x1e2c <ltmp0+0x1e2c>
    1e4c:      	tbz	w10, #0x3, 0x1e58 <ltmp0+0x1e58>
    1e50:      	add	x13, x11, #0xc
    1e54:      	st1.s	{ v5 }[3], [x13]
    1e58:      	fmul.4s	v5, v17, v1
    1e5c:      	fmul.4s	v21, v9, v3
    1e60:      	fsub.4s	v5, v5, v21
    1e64:      	zip2.8b	v21, v19, v0
    1e68:      	ushll.4s	v21, v21, #0x0
    1e6c:      	shl.4s	v21, v21, #0x1f
    1e70:      	cmlt.4s	v21, v21, #0
    1e74:      	and.16b	v5, v21, v5
    1e78:      	tbz	w10, #0x4, 0x1e98 <ltmp0+0x1e98>
    1e7c:      	str	s5, [x11, #0x10]
    1e80:      	tbnz	w10, #0x5, 0x1e9c <ltmp0+0x1e9c>
    1e84:      	tbz	w10, #0x6, 0x1ea8 <ltmp0+0x1ea8>
    1e88:      	add	x13, x11, #0x18
    1e8c:      	st1.s	{ v5 }[2], [x13]
    1e90:      	tbnz	w10, #0x7, 0x1eac <ltmp0+0x1eac>
    1e94:      	b	0x1eb4 <ltmp0+0x1eb4>
    1e98:      	tbz	w10, #0x5, 0x1e84 <ltmp0+0x1e84>
    1e9c:      	add	x13, x11, #0x14
    1ea0:      	st1.s	{ v5 }[1], [x13]
    1ea4:      	tbnz	w10, #0x6, 0x1e88 <ltmp0+0x1e88>
    1ea8:      	tbz	w10, #0x7, 0x1eb4 <ltmp0+0x1eb4>
    1eac:      	add	x10, x11, #0x1c
    1eb0:      	st1.s	{ v5 }[3], [x10]
    1eb4:      	mov	x10, #0x0               ; =0
    1eb8:      	add	x9, x9, #0xc04
    1ebc:      	movi.2d	v5, #0000000000000000
    1ec0:      	movi.2d	v21, #0000000000000000
    1ec4:      	movi.2d	v22, #0000000000000000
    1ec8:      	movi.2d	v23, #0000000000000000
    1ecc:      	b	0x1eec <ltmp0+0x1eec>
    1ed0:      	add.2d	v21, v21, v25
    1ed4:      	add.2d	v22, v22, v26
    1ed8:      	add.2d	v23, v23, v24
    1edc:      	add.2d	v5, v5, v27
    1ee0:      	fmov	x10, d5
    1ee4:      	cmp	x10, #0x60
    1ee8:      	b.ge	0x1fcc <ltmp0+0x1fcc>
    1eec:      	fmov	w11, s7
    1ef0:      	lsl	x10, x10, #5
    1ef4:      	add	x13, x4, x10
    1ef8:      	ldp	q30, q28, [x13]
    1efc:      	add	x13, x7, x10
    1f00:      	ldp	q11, q29, [x13]
    1f04:      	fmul.4s	v12, v30, v11
    1f08:      	add	x13, x5, x10
    1f0c:      	ldp	q13, q30, [x13]
    1f10:      	add	x13, x6, x10
    1f14:      	ldp	q14, q11, [x13]
    1f18:      	fmul.4s	v13, v13, v14
    1f1c:      	fadd.4s	v12, v12, v13
    1f20:      	and.16b	v12, v0, v12
    1f24:      	add	x10, x9, x10
    1f28:      	tbz	w11, #0x0, 0x1f78 <ltmp0+0x1f78>
    1f2c:      	str	s12, [x10]
    1f30:      	and	w11, w11, #0xff
    1f34:      	tbnz	w11, #0x1, 0x1f80 <ltmp0+0x1f80>
    1f38:      	tbz	w11, #0x2, 0x1f8c <ltmp0+0x1f8c>
    1f3c:      	add	x13, x10, #0x8
    1f40:      	st1.s	{ v12 }[2], [x13]
    1f44:      	tbnz	w11, #0x3, 0x1f90 <ltmp0+0x1f90>
    1f48:      	fmul.4s	v28, v28, v29
    1f4c:      	fmul.4s	v29, v30, v11
    1f50:      	fadd.4s	v28, v28, v29
    1f54:      	and.16b	v28, v6, v28
    1f58:      	tbz	w11, #0x4, 0x1fac <ltmp0+0x1fac>
    1f5c:      	str	s28, [x10, #0x10]
    1f60:      	tbnz	w11, #0x5, 0x1fb0 <ltmp0+0x1fb0>
    1f64:      	tbz	w11, #0x6, 0x1fbc <ltmp0+0x1fbc>
    1f68:      	add	x13, x10, #0x18
    1f6c:      	st1.s	{ v28 }[2], [x13]
    1f70:      	tbz	w11, #0x7, 0x1ed0 <ltmp0+0x1ed0>
    1f74:      	b	0x1fc0 <ltmp0+0x1fc0>
    1f78:      	and	w11, w11, #0xff
    1f7c:      	tbz	w11, #0x1, 0x1f38 <ltmp0+0x1f38>
    1f80:      	add	x13, x10, #0x4
    1f84:      	st1.s	{ v12 }[1], [x13]
    1f88:      	tbnz	w11, #0x2, 0x1f3c <ltmp0+0x1f3c>
    1f8c:      	tbz	w11, #0x3, 0x1f48 <ltmp0+0x1f48>
    1f90:      	add	x13, x10, #0xc
    1f94:      	st1.s	{ v12 }[3], [x13]
    1f98:      	fmul.4s	v28, v28, v29
    1f9c:      	fmul.4s	v29, v30, v11
    1fa0:      	fadd.4s	v28, v28, v29
    1fa4:      	and.16b	v28, v6, v28
    1fa8:      	tbnz	w11, #0x4, 0x1f5c <ltmp0+0x1f5c>
    1fac:      	tbz	w11, #0x5, 0x1f64 <ltmp0+0x1f64>
    1fb0:      	add	x13, x10, #0x14
    1fb4:      	st1.s	{ v28 }[1], [x13]
    1fb8:      	tbnz	w11, #0x6, 0x1f68 <ltmp0+0x1f68>
    1fbc:      	tbz	w11, #0x7, 0x1ed0 <ltmp0+0x1ed0>
    1fc0:      	add	x10, x10, #0x1c
    1fc4:      	st1.s	{ v28 }[3], [x10]
    1fc8:      	b	0x1ed0 <ltmp0+0x1ed0>
    1fcc:      	ldr	q0, [sp, #0xf0]
    1fd0:      	fmul.4s	v0, v0, v4
    1fd4:      	fmul.4s	v2, v10, v2
    1fd8:      	fadd.4s	v0, v2, v0
    1fdc:      	zip1.8b	v2, v19, v0
    1fe0:      	ushll.4s	v2, v2, #0x0
    1fe4:      	shl.4s	v2, v2, #0x1f
    1fe8:      	cmlt.4s	v2, v2, #0
    1fec:      	and.16b	v0, v2, v0
    1ff0:      	fmov	w9, s31
    1ff4:      	stp	q20, q16, [sp, #0x260]
    1ff8:      	ldr	q2, [sp, #0x10]
    1ffc:      	stp	q15, q2, [sp, #0x280]
    2000:      	and	x10, x12, #0x7
    2004:      	add	x11, sp, #0x260
    2008:      	ldr	x10, [x11, x10, lsl #3]
    200c:      	sub	x10, x10, x12
    2010:      	add	x8, x8, x10, lsl #2
    2014:      	tbz	w9, #0x0, 0x2034 <ltmp0+0x2034>
    2018:      	str	s0, [x8]
    201c:      	tbnz	w9, #0x1, 0x2038 <ltmp0+0x2038>
    2020:      	tbz	w9, #0x2, 0x2044 <ltmp0+0x2044>
    2024:      	add	x10, x8, #0x8
    2028:      	st1.s	{ v0 }[2], [x10]
    202c:      	tbnz	w9, #0x3, 0x2048 <ltmp0+0x2048>
    2030:      	b	0x2050 <ltmp0+0x2050>
    2034:      	tbz	w9, #0x1, 0x2020 <ltmp0+0x2020>
    2038:      	add	x10, x8, #0x4
    203c:      	st1.s	{ v0 }[1], [x10]
    2040:      	tbnz	w9, #0x2, 0x2024 <ltmp0+0x2024>
    2044:      	tbz	w9, #0x3, 0x2050 <ltmp0+0x2050>
    2048:      	add	x10, x8, #0xc
    204c:      	st1.s	{ v0 }[3], [x10]
    2050:      	fmul.4s	v0, v17, v3
    2054:      	fmul.4s	v1, v9, v1
    2058:      	fadd.4s	v0, v1, v0
    205c:      	zip2.8b	v1, v19, v0
    2060:      	ushll.4s	v1, v1, #0x0
    2064:      	shl.4s	v1, v1, #0x1f
    2068:      	cmlt.4s	v1, v1, #0
    206c:      	and.16b	v0, v1, v0
    2070:      	tbnz	w9, #0x4, 0x12ec <ltmp0+0x12ec>
    2074:      	tbz	w9, #0x5, 0x12f4 <ltmp0+0x12f4>
    2078:      	add	x10, x8, #0x14
    207c:      	st1.s	{ v0 }[1], [x10]
    2080:      	tbnz	w9, #0x6, 0x12f8 <ltmp0+0x12f8>
    2084:      	tbz	w9, #0x7, 0xa8 <ltmp0+0xa8>
    2088:      	add	x8, x8, #0x1c
    208c:      	st1.s	{ v0 }[3], [x8]
    2090:      	b	0xa8 <ltmp0+0xa8>
    2094:      	ldr	x9, [sp, #0x8]
    2098:      	stp	w15, w14, [x9]
    209c:      	str	w13, [x9, #0x8]
    20a0:      	mov	w8, #0x18               ; =24
    20a4:      	str	w8, [x9, #0x24]
    20a8:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    20ac:      	add	sp, sp, #0x4b0
    20b0:      	ldp	x29, x30, [sp, #0x90]
    20b4:      	ldp	x20, x19, [sp, #0x80]
    20b8:      	ldp	x22, x21, [sp, #0x70]
    20bc:      	ldp	x24, x23, [sp, #0x60]
    20c0:      	ldp	x26, x25, [sp, #0x50]
    20c4:      	ldp	x28, x27, [sp, #0x40]
    20c8:      	ldp	d9, d8, [sp, #0x30]
    20cc:      	ldp	d11, d10, [sp, #0x20]
    20d0:      	ldp	d13, d12, [sp, #0x10]
    20d4:      	ldp	d15, d14, [sp], #0xa0
    20d8:      	ret

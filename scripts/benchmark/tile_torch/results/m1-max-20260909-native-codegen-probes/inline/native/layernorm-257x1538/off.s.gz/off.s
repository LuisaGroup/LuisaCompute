
/private/tmp/luisa-packet-inline.UY1lIE/capture/layernorm-257x1538/off/object/tile_xir_w8_36327_1788935094883250_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x28, x27, [sp, #-0x60]!
       4:      	stp	x26, x25, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	stp	x29, x30, [sp, #0x50]
      18:      	sub	sp, sp, #0x6, lsl #12   ; =0x6000
      1c:      	sub	sp, sp, #0x120
      20:      	ldr	x25, [x0]
      24:      	ldr	x20, [x0, #0x10]
      28:      	ldr	x19, [x0, #0x20]
      2c:      	ldr	x21, [x0, #0x30]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w8, w8, #3
      40:      	fmov	s0, w8
      44:      	ushll.2d	v0, v0, #0x0
      48:      	fmov	x24, d0
      4c:      	mov	w22, #0x1808            ; =6152
      50:      	umull	x23, w24, w22
      54:      	umaddl	x1, w24, w22, x25
      58:      	mov	w26, #0x1800            ; =6144
      5c:      	add	x27, sp, #0x4, lsl #12  ; =0x4000
      60:      	add	x27, x27, #0x900
      64:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
      68:      	add	x0, x0, #0x900
      6c:      	mov	w2, #0x1800             ; =6144
      70:      	bl	0x70 <ltmp0+0x70>
      74:      	umaddl	x22, w24, w22, x26
      78:      	add	x8, x25, x22
      7c:      	add	x9, x8, #0x4
      80:      	ldr	s0, [x8]
      84:      	ld1.s	{ v0 }[1], [x9]
      88:      	str	q0, [sp, #0x6100]
      8c:      	ldr	q1, [sp, #0x4910]
      90:      	ldr	q7, [sp, #0x4900]
      94:      	ldr	q6, [sp, #0x4930]
      98:      	ldr	q5, [sp, #0x4920]
      9c:      	ldr	q2, [sp, #0x4950]
      a0:      	ldr	q16, [sp, #0x4940]
      a4:      	ldr	q4, [sp, #0x4970]
      a8:      	ldr	q3, [sp, #0x4960]
      ac:      	add	x8, x27, #0xe0
      b0:      	mov	w9, #0x4                ; =4
      b4:      	ldp	q17, q18, [x8, #-0x60]
      b8:      	fadd.4s	v1, v1, v18
      bc:      	fadd.4s	v7, v7, v17
      c0:      	ldp	q17, q18, [x8, #-0x40]
      c4:      	fadd.4s	v6, v6, v18
      c8:      	fadd.4s	v5, v5, v17
      cc:      	ldp	q17, q18, [x8, #-0x20]
      d0:      	fadd.4s	v2, v2, v18
      d4:      	fadd.4s	v16, v16, v17
      d8:      	ldp	q17, q18, [x8], #0x80
      dc:      	fadd.4s	v4, v4, v18
      e0:      	fadd.4s	v3, v3, v17
      e4:      	cmp	x9, #0xbc
      e8:      	add	x9, x9, #0x4
      ec:      	b.lo	0xb4 <ltmp0+0xb4>
      f0:      	mov	x8, #0x0                ; =0
      f4:      	fadd.4s	v17, v0, v7
      f8:      	mov.d	v17[1], v7[1]
      fc:      	fadd.4s	v1, v6, v1
     100:      	fadd.4s	v5, v5, v17
     104:      	fadd.4s	v5, v16, v5
     108:      	fadd.4s	v1, v2, v1
     10c:      	fadd.4s	v1, v4, v1
     110:      	fadd.4s	v2, v3, v5
     114:      	rev64.4s	v3, v2
     118:      	rev64.4s	v4, v1
     11c:      	fadd.4s	v1, v1, v4
     120:      	fadd.4s	v2, v2, v3
     124:      	dup.4s	v3, v2[2]
     128:      	dup.4s	v4, v1[2]
     12c:      	fadd.4s	v1, v1, v4
     130:      	fadd.4s	v2, v2, v3
     134:      	fadd.4s	v1, v2, v1
     138:      	movi	d2, #0000000000000000
     13c:      	fadd	s1, s1, s2
     140:      	mov	w9, #0x4000             ; =16384
     144:      	movk	w9, #0x44c0, lsl #16
     148:      	fmov	s2, w9
     14c:      	fdiv	s1, s1, s2
     150:      	dup.4s	v2, v1[0]
     154:      	add	x9, sp, #0x4, lsl #12   ; =0x4000
     158:      	add	x9, x9, #0x900
     15c:      	add	x10, sp, #0x3, lsl #12  ; =0x3000
     160:      	add	x10, x10, #0xe0
     164:      	lsl	x11, x8, #5
     168:      	add	x12, x9, x11
     16c:      	ldp	q4, q3, [x12]
     170:      	fsub.4s	v4, v4, v2
     174:      	fsub.4s	v3, v3, v2
     178:      	add	x11, x10, x11
     17c:      	stp	q4, q3, [x11]
     180:      	add	x8, x8, #0x1
     184:      	cmp	x8, #0xc0
     188:      	b.ne	0x164 <ltmp0+0x164>
     18c:      	dup.4s	v1, v1[0]
     190:      	fsub.4s	v1, v0, v1
     194:      	ldr	q0, [sp, #0x48e0]
     198:      	str	q1, [sp, #0x80]
     19c:      	mov.d	v1[1], v0[1]
     1a0:      	str	q1, [sp, #0x90]
     1a4:      	str	q1, [sp, #0x48e0]
     1a8:      	ldr	q0, [sp, #0x30e0]
     1ac:      	ldr	q1, [sp, #0x30f0]
     1b0:      	fmul.4s	v2, v1, v1
     1b4:      	fmul.4s	v3, v0, v0
     1b8:      	ldr	q0, [sp, #0x3100]
     1bc:      	ldr	q1, [sp, #0x3110]
     1c0:      	fmul.4s	v5, v1, v1
     1c4:      	fmul.4s	v4, v0, v0
     1c8:      	ldr	q0, [sp, #0x3120]
     1cc:      	ldr	q1, [sp, #0x3130]
     1d0:      	fmul.4s	v6, v1, v1
     1d4:      	fmul.4s	v7, v0, v0
     1d8:      	ldr	q0, [sp, #0x3140]
     1dc:      	ldr	q1, [sp, #0x3150]
     1e0:      	fmul.4s	v17, v1, v1
     1e4:      	fmul.4s	v16, v0, v0
     1e8:      	add	x8, sp, #0x3, lsl #12   ; =0x3000
     1ec:      	add	x8, x8, #0xe0
     1f0:      	add	x8, x8, #0xe0
     1f4:      	mov	w9, #0x4                ; =4
     1f8:      	ldp	q1, q0, [x8, #-0x60]
     1fc:      	fmul.4s	v1, v1, v1
     200:      	fmul.4s	v0, v0, v0
     204:      	fadd.4s	v2, v2, v0
     208:      	fadd.4s	v3, v3, v1
     20c:      	ldp	q1, q0, [x8, #-0x40]
     210:      	fmul.4s	v1, v1, v1
     214:      	fmul.4s	v0, v0, v0
     218:      	fadd.4s	v5, v5, v0
     21c:      	fadd.4s	v4, v4, v1
     220:      	ldp	q1, q0, [x8, #-0x20]
     224:      	fmul.4s	v1, v1, v1
     228:      	fmul.4s	v0, v0, v0
     22c:      	fadd.4s	v6, v6, v0
     230:      	fadd.4s	v7, v7, v1
     234:      	ldp	q1, q0, [x8], #0x80
     238:      	fmul.4s	v1, v1, v1
     23c:      	fmul.4s	v0, v0, v0
     240:      	fadd.4s	v17, v17, v0
     244:      	fadd.4s	v16, v16, v1
     248:      	cmp	x9, #0xbc
     24c:      	add	x9, x9, #0x4
     250:      	b.lo	0x1f8 <ltmp0+0x1f8>
     254:      	add	x25, sp, #0x1, lsl #12  ; =0x1000
     258:      	add	x25, x25, #0x8c0
     25c:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     260:      	add	x0, x0, #0x8c0
     264:      	mov	x1, x20
     268:      	mov	w2, #0x1800             ; =6144
     26c:      	stp	q5, q2, [sp, #0x10]
     270:      	str	q3, [sp]
     274:      	stp	q7, q4, [sp, #0x30]
     278:      	stp	q6, q16, [sp, #0x60]
     27c:      	str	q17, [sp, #0x50]
     280:      	bl	0x280 <ltmp0+0x280>
     284:      	ldr	q0, [sp, #0x80]
     288:      	fmul.4s	v0, v0, v0
     28c:      	ldp	q1, q2, [sp]
     290:      	fadd.4s	v0, v0, v1
     294:      	mov.d	v0[1], v1[1]
     298:      	ldr	q1, [sp, #0x20]
     29c:      	fadd.4s	v1, v2, v1
     2a0:      	ldp	q2, q3, [sp, #0x30]
     2a4:      	fadd.4s	v0, v3, v0
     2a8:      	fadd.4s	v0, v2, v0
     2ac:      	ldp	q2, q3, [sp, #0x50]
     2b0:      	fadd.4s	v1, v3, v1
     2b4:      	fadd.4s	v1, v2, v1
     2b8:      	ldr	q2, [sp, #0x70]
     2bc:      	fadd.4s	v0, v2, v0
     2c0:      	rev64.4s	v2, v0
     2c4:      	rev64.4s	v3, v1
     2c8:      	fadd.4s	v0, v0, v2
     2cc:      	dup.4s	v2, v0[2]
     2d0:      	fadd.4s	v1, v1, v3
     2d4:      	dup.4s	v3, v1[2]
     2d8:      	fadd.4s	v1, v1, v3
     2dc:      	fadd.4s	v0, v0, v2
     2e0:      	fadd.4s	v0, v0, v1
     2e4:      	movi	d1, #0000000000000000
     2e8:      	fadd	s0, s0, s1
     2ec:      	mov	w8, #0x4000             ; =16384
     2f0:      	movk	w8, #0x44c0, lsl #16
     2f4:      	fmov	s1, w8
     2f8:      	fdiv	s0, s0, s1
     2fc:      	mov	w8, #0x1804             ; =6148
     300:      	add	x8, x20, x8
     304:      	ldr	s18, [x20, #0x1800]
     308:      	ld1.s	{ v18 }[1], [x8]
     30c:      	str	q18, [sp, #0x30c0]
     310:      	mov	w8, #0xc5ac             ; =50604
     314:      	movk	w8, #0x3727, lsl #16
     318:      	fmov	s1, w8
     31c:      	fadd	s0, s0, s1
     320:      	fsqrt	s19, s0
     324:      	subs	x8, x21, x19
     328:      	lsr	x8, x8, #3
     32c:      	mov	w9, #0x300              ; =768
     330:      	ccmp	x8, x9, #0x0, hs
     334:      	cset	w8, hi
     338:      	mov	w9, #0x2007             ; =8199
     33c:      	movk	w9, #0x18, lsl #16
     340:      	sub	x10, x19, x21
     344:      	cmp	x10, x9
     348:      	ccmp	x19, x21, #0x0, hi
     34c:      	b.hs	0x400 <ltmp0+0x400>
     350:      	tbnz	w8, #0x0, 0x400 <ltmp0+0x400>
     354:      	stp	q19, q18, [sp, #0x70]
     358:      	add	x20, sp, #0xa0
     35c:      	add	x0, sp, #0xa0
     360:      	mov	x1, x19
     364:      	mov	w2, #0x1800             ; =6144
     368:      	bl	0x368 <ltmp0+0x368>
     36c:      	ldr	q6, [sp, #0x70]
     370:      	mov	x8, #0x0                ; =0
     374:      	mov	w9, #0x1804             ; =6148
     378:      	add	x9, x19, x9
     37c:      	ldr	s0, [x19, #0x1800]
     380:      	ld1.s	{ v0 }[1], [x9]
     384:      	str	q0, [sp, #0x18a0]
     388:      	dup.4s	v1, v6[0]
     38c:      	add	x9, x21, x23
     390:      	add	x10, sp, #0x3, lsl #12  ; =0x3000
     394:      	add	x10, x10, #0xe0
     398:      	add	x11, sp, #0x1, lsl #12  ; =0x1000
     39c:      	add	x11, x11, #0x8c0
     3a0:      	lsl	x12, x8, #5
     3a4:      	add	x13, x10, x12
     3a8:      	ldp	q3, q2, [x13]
     3ac:      	fdiv.4s	v3, v3, v1
     3b0:      	fdiv.4s	v2, v2, v1
     3b4:      	add	x13, x11, x12
     3b8:      	ldp	q4, q5, [x13]
     3bc:      	fmul.4s	v2, v2, v5
     3c0:      	fmul.4s	v3, v3, v4
     3c4:      	add	x13, x20, x12
     3c8:      	ldp	q5, q4, [x13]
     3cc:      	fadd.4s	v3, v3, v5
     3d0:      	fadd.4s	v2, v2, v4
     3d4:      	add	x12, x9, x12
     3d8:      	stp	q3, q2, [x12]
     3dc:      	add	x8, x8, #0x1
     3e0:      	cmp	x8, #0xc0
     3e4:      	b.ne	0x3a0 <ltmp0+0x3a0>
     3e8:      	dup.4s	v1, v6[0]
     3ec:      	ldp	q2, q3, [sp, #0x80]
     3f0:      	fdiv.4s	v1, v3, v1
     3f4:      	fmul.4s	v1, v1, v2
     3f8:      	fadd.4s	v0, v1, v0
     3fc:      	b	0x4b4 <ltmp0+0x4b4>
     400:      	mov	x10, #0x0               ; =0
     404:      	dup.4s	v0, v19[0]
     408:      	mov	w8, #0x1808             ; =6152
     40c:      	umaddl	x8, w24, w8, x21
     410:      	movi.2d	v1, #0000000000000000
     414:      	add	x9, sp, #0x3, lsl #12   ; =0x3000
     418:      	add	x9, x9, #0xe0
     41c:      	mov	w11, #0x1               ; =1
     420:      	dup.2d	v2, x11
     424:      	movi.2d	v3, #0000000000000000
     428:      	movi.2d	v4, #0000000000000000
     42c:      	movi.2d	v5, #0000000000000000
     430:      	lsl	x10, x10, #5
     434:      	add	x11, x9, x10
     438:      	ldp	q7, q6, [x11]
     43c:      	fdiv.4s	v7, v7, v0
     440:      	fdiv.4s	v6, v6, v0
     444:      	add	x10, x25, x10
     448:      	ldp	q16, q17, [x10]
     44c:      	fmul.4s	v6, v6, v17
     450:      	fmul.4s	v7, v7, v16
     454:      	fmov	x10, d1
     458:      	lsl	x10, x10, #5
     45c:      	add	x11, x19, x10
     460:      	ldp	q17, q16, [x11]
     464:      	fadd.4s	v7, v7, v17
     468:      	fadd.4s	v6, v6, v16
     46c:      	add	x10, x8, x10
     470:      	stp	q7, q6, [x10]
     474:      	add.2d	v4, v4, v2
     478:      	add.2d	v3, v3, v2
     47c:      	add.2d	v5, v5, v2
     480:      	add.2d	v1, v1, v2
     484:      	fmov	x10, d1
     488:      	cmp	x10, #0xc0
     48c:      	b.lt	0x430 <ltmp0+0x430>
     490:      	dup.4s	v0, v19[0]
     494:      	ldr	q1, [sp, #0x90]
     498:      	fdiv.4s	v0, v1, v0
     49c:      	fmul.4s	v0, v0, v18
     4a0:      	mov	w8, #0x1804             ; =6148
     4a4:      	add	x8, x19, x8
     4a8:      	ldr	s1, [x19, #0x1800]
     4ac:      	ld1.s	{ v1 }[1], [x8]
     4b0:      	fadd.4s	v0, v0, v1
     4b4:      	str	d0, [x21, x22]
     4b8:      	add	sp, sp, #0x6, lsl #12   ; =0x6000
     4bc:      	add	sp, sp, #0x120
     4c0:      	ldp	x29, x30, [sp, #0x50]
     4c4:      	ldp	x20, x19, [sp, #0x40]
     4c8:      	ldp	x22, x21, [sp, #0x30]
     4cc:      	ldp	x24, x23, [sp, #0x20]
     4d0:      	ldp	x26, x25, [sp, #0x10]
     4d4:      	ldp	x28, x27, [sp], #0x60
     4d8:      	ret

00000000000004dc <_llm_rows.packet_batch.blocks>:
     4dc:      	stp	d15, d14, [sp, #-0xa0]!
     4e0:      	stp	d13, d12, [sp, #0x10]
     4e4:      	stp	d11, d10, [sp, #0x20]
     4e8:      	stp	d9, d8, [sp, #0x30]
     4ec:      	stp	x28, x27, [sp, #0x40]
     4f0:      	stp	x26, x25, [sp, #0x50]
     4f4:      	stp	x24, x23, [sp, #0x60]
     4f8:      	stp	x22, x21, [sp, #0x70]
     4fc:      	stp	x20, x19, [sp, #0x80]
     500:      	stp	x29, x30, [sp, #0x90]
     504:      	sub	sp, sp, #0x6, lsl #12   ; =0x6000
     508:      	sub	sp, sp, #0x700
     50c:      	str	x0, [sp, #0x1a8]
     510:      	cbz	w3, 0x1e04 <_llm_rows.packet_batch.blocks+0x1928>
     514:      	mov	x27, x3
     518:      	mov	x20, x2
     51c:      	mov	w22, #0x0               ; =0
     520:      	ldp	w9, w8, [x2, #0x2c]
     524:      	str	w9, [sp, #0x1a4]
     528:      	str	w8, [sp, #0x1a0]
     52c:      	add	x25, sp, #0x4, lsl #12  ; =0x4000
     530:      	add	x25, x25, #0xee0
     534:      	ldp	w24, w0, [x2]
     538:      	adrp	x8, 0x0 <ltmp0>
     53c:      	ldr	q0, [x8]
     540:      	str	q0, [sp, #0x10]
     544:      	adrp	x8, 0x0 <ltmp0>
     548:      	ldr	q0, [x8]
     54c:      	str	q0, [sp, #0x30]
     550:      	adrp	x8, 0x0 <ltmp0>
     554:      	ldr	q0, [x8]
     558:      	str	q0, [sp, #0x20]
     55c:      	ldp	w26, w8, [x2, #0x8]
     560:      	str	x8, [sp, #0x198]
     564:      	add	x19, sp, #0x3, lsl #12  ; =0x3000
     568:      	add	x19, x19, #0x6c0
     56c:      	add	x21, sp, #0x1, lsl #12  ; =0x1000
     570:      	add	x21, x21, #0xea0
     574:      	str	w3, [sp, #0x15c]
     578:      	b	0x5c4 <_llm_rows.packet_batch.blocks+0xe8>
     57c:      	mov	w8, #0x18               ; =24
     580:      	str	w8, [x20, #0x24]
     584:      	ldr	w27, [sp, #0x15c]
     588:      	add	w8, w24, #0x1
     58c:      	ldr	w9, [sp, #0x1a4]
     590:      	cmp	w8, w9
     594:      	cset	w8, eq
     598:      	csinc	w24, wzr, w24, eq
     59c:      	cinc	w9, w0, eq
     5a0:      	ldr	w10, [sp, #0x1a0]
     5a4:      	cmp	w9, w10
     5a8:      	cset	w10, eq
     5ac:      	ands	w8, w8, w10
     5b0:      	csel	w0, wzr, w9, ne
     5b4:      	add	w26, w26, w8
     5b8:      	add	w22, w22, #0x1
     5bc:      	cmp	w22, w27
     5c0:      	b.eq	0x1e04 <_llm_rows.packet_batch.blocks+0x1928>
     5c4:      	ubfiz	x8, x24, #5, #32
     5c8:      	ldr	x12, [sp, #0x198]
     5cc:      	cmp	x8, x12
     5d0:      	csel	x9, x8, xzr, ls
     5d4:      	subs	x10, x12, x9
     5d8:      	cmp	x10, #0x20
     5dc:      	mov	w11, #0x20              ; =32
     5e0:      	csel	x10, x10, x11, lo
     5e4:      	cmp	x12, x9
     5e8:      	stp	w24, w0, [x20]
     5ec:      	str	w26, [x20, #0x8]
     5f0:      	str	wzr, [x20, #0x24]
     5f4:      	ccmp	x8, x12, #0x2, hi
     5f8:      	csel	x23, x10, xzr, ls
     5fc:      	cmp	x23, #0x20
     600:      	b.lo	0x65c <_llm_rows.packet_batch.blocks+0x180>
     604:      	ldr	x23, [sp, #0x1a8]
     608:      	mov	x28, x0
     60c:      	mov	x0, x23
     610:      	mov	x1, x20
     614:      	bl	0x614 <_llm_rows.packet_batch.blocks+0x138>
     618:      	mov	w8, #0x8                ; =8
     61c:      	str	w8, [x20, #0x24]
     620:      	mov	x0, x23
     624:      	mov	x1, x20
     628:      	bl	0x628 <_llm_rows.packet_batch.blocks+0x14c>
     62c:      	mov	w8, #0x10               ; =16
     630:      	str	w8, [x20, #0x24]
     634:      	mov	x0, x23
     638:      	mov	x1, x20
     63c:      	bl	0x63c <_llm_rows.packet_batch.blocks+0x160>
     640:      	mov	w8, #0x18               ; =24
     644:      	str	w8, [x20, #0x24]
     648:      	mov	x0, x23
     64c:      	mov	x1, x20
     650:      	bl	0x650 <_llm_rows.packet_batch.blocks+0x174>
     654:      	mov	x0, x28
     658:      	b	0x588 <_llm_rows.packet_batch.blocks+0xac>
     65c:      	lsr	x27, x23, #3
     660:      	cmp	x23, #0x8
     664:      	b.lo	0x6c0 <_llm_rows.packet_batch.blocks+0x1e4>
     668:      	str	wzr, [x20, #0x24]
     66c:      	mov	x28, x0
     670:      	ldr	x0, [sp, #0x1a8]
     674:      	mov	x1, x20
     678:      	bl	0x678 <_llm_rows.packet_batch.blocks+0x19c>
     67c:      	mov	x0, x28
     680:      	cmp	x27, #0x1
     684:      	b.eq	0x6c0 <_llm_rows.packet_batch.blocks+0x1e4>
     688:      	mov	w8, #0x8                ; =8
     68c:      	str	w8, [x20, #0x24]
     690:      	ldr	x0, [sp, #0x1a8]
     694:      	mov	x1, x20
     698:      	bl	0x698 <_llm_rows.packet_batch.blocks+0x1bc>
     69c:      	mov	x0, x28
     6a0:      	cmp	x27, #0x2
     6a4:      	b.eq	0x6c0 <_llm_rows.packet_batch.blocks+0x1e4>
     6a8:      	mov	w8, #0x10               ; =16
     6ac:      	str	w8, [x20, #0x24]
     6b0:      	ldr	x0, [sp, #0x1a8]
     6b4:      	mov	x1, x20
     6b8:      	bl	0x6b8 <_llm_rows.packet_batch.blocks+0x1dc>
     6bc:      	mov	x0, x28
     6c0:      	and	w8, w23, #0x7
     6c4:      	mov	w28, #0x4               ; =4
     6c8:      	cbz	w8, 0x57c <_llm_rows.packet_batch.blocks+0xa0>
     6cc:      	dup.4s	v1, w8
     6d0:      	ldp	q0, q2, [sp, #0x20]
     6d4:      	cmhi.4s	v0, v1, v0
     6d8:      	cmhi.4s	v1, v1, v2
     6dc:      	uzp1.8h	v3, v1, v0
     6e0:      	umaxv.8h	h2, v3
     6e4:      	fmov	w8, s2
     6e8:      	tbz	w8, #0x0, 0x57c <_llm_rows.packet_batch.blocks+0xa0>
     6ec:      	mov	x11, #0x0               ; =0
     6f0:      	ldr	x8, [sp, #0x1a8]
     6f4:      	ldr	x9, [x8]
     6f8:      	ldr	x12, [x8, #0x10]
     6fc:      	ldr	x10, [x8, #0x20]
     700:      	ldr	x8, [x8, #0x30]
     704:      	ldr	q2, [sp, #0x10]
     708:      	and.16b	v2, v3, v2
     70c:      	addv.8h	h23, v2
     710:      	fmov	w13, s23
     714:      	and	w23, w13, #0xff
     718:      	ubfiz	w13, w24, #2, #27
     71c:      	orr	w13, w13, w27
     720:      	dup.4s	v4, w13
     724:      	and.16b	v7, v1, v4
     728:      	and.16b	v6, v0, v4
     72c:      	ushll2.2d	v4, v6, #0x0
     730:      	ushll2.2d	v5, v7, #0x0
     734:      	ushll.2d	v6, v6, #0x0
     738:      	ushll.2d	v17, v7, #0x0
     73c:      	fmov	x13, d17
     740:      	mov	w14, #0x1808            ; =6152
     744:      	umaddl	x13, w13, w14, x9
     748:      	fmov	w14, s23
     74c:      	b	0x770 <_llm_rows.packet_batch.blocks+0x294>
     750:      	add	x15, x25, x11, lsl #5
     754:      	ldp	q18, q19, [x15]
     758:      	bif.16b	v16, v19, v0
     75c:      	bif.16b	v7, v18, v1
     760:      	stp	q7, q16, [x15]
     764:      	add	x11, x11, #0x1
     768:      	cmp	x11, #0xc0
     76c:      	b.eq	0x804 <_llm_rows.packet_batch.blocks+0x328>
     770:      	add	x15, x13, x11, lsl #5
     774:      	movi.2d	v7, #0000000000000000
     778:      	movi.2d	v16, #0000000000000000
     77c:      	tbnz	w14, #0x0, 0x7a4 <_llm_rows.packet_batch.blocks+0x2c8>
     780:      	and	w16, w14, #0xff
     784:      	tbnz	w16, #0x1, 0x7b0 <_llm_rows.packet_batch.blocks+0x2d4>
     788:      	tbnz	w16, #0x2, 0x7bc <_llm_rows.packet_batch.blocks+0x2e0>
     78c:      	tbnz	w16, #0x3, 0x7c8 <_llm_rows.packet_batch.blocks+0x2ec>
     790:      	tbnz	w16, #0x4, 0x7d4 <_llm_rows.packet_batch.blocks+0x2f8>
     794:      	tbnz	w16, #0x5, 0x7e0 <_llm_rows.packet_batch.blocks+0x304>
     798:      	tbnz	w16, #0x6, 0x7ec <_llm_rows.packet_batch.blocks+0x310>
     79c:      	tbz	w16, #0x7, 0x750 <_llm_rows.packet_batch.blocks+0x274>
     7a0:      	b	0x7f8 <_llm_rows.packet_batch.blocks+0x31c>
     7a4:      	ldr	s7, [x15]
     7a8:      	and	w16, w14, #0xff
     7ac:      	tbz	w16, #0x1, 0x788 <_llm_rows.packet_batch.blocks+0x2ac>
     7b0:      	add	x17, x15, #0x4
     7b4:      	ld1.s	{ v7 }[1], [x17]
     7b8:      	tbz	w16, #0x2, 0x78c <_llm_rows.packet_batch.blocks+0x2b0>
     7bc:      	add	x17, x15, #0x8
     7c0:      	ld1.s	{ v7 }[2], [x17]
     7c4:      	tbz	w16, #0x3, 0x790 <_llm_rows.packet_batch.blocks+0x2b4>
     7c8:      	add	x17, x15, #0xc
     7cc:      	ld1.s	{ v7 }[3], [x17]
     7d0:      	tbz	w16, #0x4, 0x794 <_llm_rows.packet_batch.blocks+0x2b8>
     7d4:      	add	x17, x15, #0x10
     7d8:      	ld1.s	{ v16 }[0], [x17]
     7dc:      	tbz	w16, #0x5, 0x798 <_llm_rows.packet_batch.blocks+0x2bc>
     7e0:      	add	x17, x15, #0x14
     7e4:      	ld1.s	{ v16 }[1], [x17]
     7e8:      	tbz	w16, #0x6, 0x79c <_llm_rows.packet_batch.blocks+0x2c0>
     7ec:      	add	x17, x15, #0x18
     7f0:      	ld1.s	{ v16 }[2], [x17]
     7f4:      	tbz	w16, #0x7, 0x750 <_llm_rows.packet_batch.blocks+0x274>
     7f8:      	add	x15, x15, #0x1c
     7fc:      	ld1.s	{ v16 }[3], [x15]
     800:      	b	0x750 <_llm_rows.packet_batch.blocks+0x274>
     804:      	xtn.8b	v18, v3
     808:      	sshll.2d	v19, v1, #0x0
     80c:      	adrp	x11, 0x0 <ltmp0>
     810:      	ldr	q3, [x11]
     814:      	and.16b	v16, v19, v3
     818:      	movi	d2, #0x0000000000ffff
     81c:      	and.8b	v7, v18, v2
     820:      	adrp	x11, 0x0 <ltmp0>
     824:      	ldr	d3, [x11]
     828:      	str	q18, [sp, #0x160]
     82c:      	and.8b	v3, v18, v3
     830:      	addv.8b	b3, v3
     834:      	fmov	w11, s3
     838:      	umaxv.8b	b3, v7
     83c:      	fmov	w13, s3
     840:      	rbit	w14, w11
     844:      	clz	w14, w14
     848:      	tst	w13, #0x1
     84c:      	csel	w15, w14, wzr, ne
     850:      	mov	w13, #0x600             ; =1536
     854:      	dup.2d	v21, x13
     858:      	orr.16b	v2, v16, v21
     85c:      	mov	w13, #0x602             ; =1538
     860:      	dup.2s	v20, w13
     864:      	xtn.2s	v22, v17
     868:      	str	q2, [sp, #0xd0]
     86c:      	umlal.2d	v2, v22, v20
     870:      	mov	b3, v7[0]
     874:      	mov.b	v3[4], v7[1]
     878:      	ushll.2d	v3, v3, #0x0
     87c:      	shl.2d	v3, v3, #0x3f
     880:      	cmlt.2d	v3, v3, #0
     884:      	str	q2, [sp, #0x120]
     888:      	and.16b	v3, v3, v2
     88c:      	movi.2d	v2, #0000000000000000
     890:      	str	q2, [sp, #0x660]
     894:      	str	q2, [sp, #0x650]
     898:      	str	q2, [sp, #0x640]
     89c:      	str	q3, [sp, #0x630]
     8a0:      	and	x13, x15, #0x7
     8a4:      	add	x14, sp, #0x630
     8a8:      	ldr	x13, [x14, x13, lsl #3]
     8ac:      	sub	x13, x13, x15
     8b0:      	add	x9, x9, x13, lsl #2
     8b4:      	movi.2d	v28, #0000000000000000
     8b8:      	movi.2d	v30, #0000000000000000
     8bc:      	tbnz	w11, #0x0, 0x1a5c <_llm_rows.packet_batch.blocks+0x1580>
     8c0:      	tbnz	w11, #0x1, 0x1a64 <_llm_rows.packet_batch.blocks+0x1588>
     8c4:      	tbnz	w11, #0x2, 0x1a70 <_llm_rows.packet_batch.blocks+0x1594>
     8c8:      	tbnz	w11, #0x3, 0x1a7c <_llm_rows.packet_batch.blocks+0x15a0>
     8cc:      	tbnz	w11, #0x4, 0x1a88 <_llm_rows.packet_batch.blocks+0x15ac>
     8d0:      	tbnz	w11, #0x5, 0x1a94 <_llm_rows.packet_batch.blocks+0x15b8>
     8d4:      	tbnz	w11, #0x6, 0x1aa0 <_llm_rows.packet_batch.blocks+0x15c4>
     8d8:      	str	q16, [sp, #0x170]
     8dc:      	str	q23, [sp, #0x140]
     8e0:      	tbz	w11, #0x7, 0x8ec <_llm_rows.packet_batch.blocks+0x410>
     8e4:      	add	x9, x9, #0x1c
     8e8:      	ld1.s	{ v30 }[3], [x9]
     8ec:      	str	w0, [sp, #0x158]
     8f0:      	sshll.2d	v25, v0, #0x0
     8f4:      	sshll2.2d	v23, v1, #0x0
     8f8:      	sshll2.2d	v24, v0, #0x0
     8fc:      	adrp	x9, 0x0 <ltmp0>
     900:      	ldr	q3, [x9]
     904:      	and.16b	v2, v24, v3
     908:      	adrp	x9, 0x0 <ltmp0>
     90c:      	ldr	q3, [x9]
     910:      	and.16b	v3, v23, v3
     914:      	adrp	x9, 0x0 <ltmp0>
     918:      	ldr	q18, [x9]
     91c:      	and.16b	v16, v25, v18
     920:      	adrp	x9, 0x0 <ltmp0>
     924:      	ldr	q26, [x9]
     928:      	and.16b	v26, v24, v26
     92c:      	adrp	x9, 0x0 <ltmp0>
     930:      	ldr	q27, [x9]
     934:      	and.16b	v27, v23, v27
     938:      	adrp	x9, 0x0 <ltmp0>
     93c:      	ldr	q29, [x9]
     940:      	and.16b	v25, v25, v29
     944:      	adrp	x9, 0x0 <ltmp0>
     948:      	ldr	q29, [x9]
     94c:      	and.16b	v19, v19, v29
     950:      	stp	q16, q3, [sp, #0x70]
     954:      	orr.16b	v16, v16, v21
     958:      	orr.16b	v17, v3, v21
     95c:      	stp	q2, q17, [sp, #0x90]
     960:      	orr.16b	v3, v2, v21
     964:      	umull.2d	v2, v22, v20
     968:      	str	q2, [sp, #0xe0]
     96c:      	xtn.2s	v5, v5
     970:      	xtn.2s	v6, v6
     974:      	xtn.2s	v4, v4
     978:      	stp	q16, q3, [sp, #0xb0]
     97c:      	mov.16b	v2, v3
     980:      	umlal.2d	v2, v4, v20
     984:      	str	q2, [sp, #0x110]
     988:      	mov.16b	v2, v17
     98c:      	umlal.2d	v2, v5, v20
     990:      	str	q2, [sp, #0x100]
     994:      	mov.16b	v2, v16
     998:      	umlal.2d	v2, v6, v20
     99c:      	str	q2, [sp, #0xf0]
     9a0:      	sshll.2d	v4, v1, #0x0
     9a4:      	sshll.2d	v5, v0, #0x0
     9a8:      	str	q19, [sp, #0x5f0]
     9ac:      	str	q27, [sp, #0x600]
     9b0:      	str	q25, [sp, #0x610]
     9b4:      	str	q26, [sp, #0x620]
     9b8:      	and	x9, x15, #0x7
     9bc:      	add	x13, sp, #0x5f0
     9c0:      	ldr	x9, [x13, x9, lsl #3]
     9c4:      	orr	x9, x9, #0x1800
     9c8:      	str	x15, [sp, #0x138]
     9cc:      	sub	x9, x9, x15, lsl #2
     9d0:      	tst	w11, #0xff
     9d4:      	csel	x9, xzr, x9, eq
     9d8:      	str	x9, [sp, #0x190]
     9dc:      	add	x9, x25, x9
     9e0:      	ldp	q6, q20, [x9]
     9e4:      	zip2.8b	v21, v7, v0
     9e8:      	ushll.4s	v21, v21, #0x0
     9ec:      	shl.4s	v21, v21, #0x1f
     9f0:      	cmlt.4s	v21, v21, #0
     9f4:      	stp	q30, q28, [sp, #0x40]
     9f8:      	bit.16b	v20, v30, v21
     9fc:      	str	q7, [sp, #0x180]
     a00:      	zip1.8b	v21, v7, v0
     a04:      	ushll.4s	v21, v21, #0x0
     a08:      	shl.4s	v21, v21, #0x1f
     a0c:      	cmlt.4s	v21, v21, #0
     a10:      	bit.16b	v6, v28, v21
     a14:      	stp	q6, q20, [x9]
     a18:      	fmov	x6, d19
     a1c:      	dup.2d	v6, x28
     a20:      	and.16b	v26, v24, v6
     a24:      	and.16b	v12, v23, v6
     a28:      	and.16b	v13, v5, v6
     a2c:      	and.16b	v14, v4, v6
     a30:      	fmov	x5, d14
     a34:      	ldr	q4, [sp, #0x4f40]
     a38:      	ldr	q5, [sp, #0x4f50]
     a3c:      	and.16b	v5, v0, v5
     a40:      	and.16b	v4, v1, v4
     a44:      	ldr	q6, [sp, #0x4f20]
     a48:      	ldr	q19, [sp, #0x4f30]
     a4c:      	and.16b	v19, v0, v19
     a50:      	and.16b	v6, v1, v6
     a54:      	ldr	q21, [sp, #0x4f00]
     a58:      	ldr	q20, [sp, #0x4f10]
     a5c:      	and.16b	v20, v0, v20
     a60:      	and.16b	v21, v1, v21
     a64:      	add	x9, x25, x6
     a68:      	ldp	q25, q22, [x9]
     a6c:      	and.16b	v22, v0, v22
     a70:      	mov	x9, x5
     a74:      	and.16b	v25, v1, v25
     a78:      	mov.16b	v29, v14
     a7c:      	mov.16b	v9, v12
     a80:      	mov.16b	v15, v13
     a84:      	mov.16b	v11, v26
     a88:      	sshll.2d	v10, v1, #0x0
     a8c:      	sshll.2d	v16, v0, #0x0
     a90:      	add	x9, x25, x9, lsl #5
     a94:      	ldp	q8, q27, [x9]
     a98:      	fadd.4s	v8, v25, v8
     a9c:      	fadd.4s	v27, v22, v27
     aa0:      	ldp	q31, q30, [x9, #0x20]
     aa4:      	fadd.4s	v31, v21, v31
     aa8:      	fadd.4s	v30, v20, v30
     aac:      	ldp	q28, q7, [x9, #0x40]
     ab0:      	fadd.4s	v28, v6, v28
     ab4:      	fadd.4s	v7, v19, v7
     ab8:      	ldp	q3, q17, [x9, #0x60]
     abc:      	fadd.4s	v3, v4, v3
     ac0:      	fadd.4s	v17, v5, v17
     ac4:      	dup.2d	v18, x28
     ac8:      	and.16b	v2, v24, v18
     acc:      	add.2d	v11, v11, v2
     ad0:      	and.16b	v2, v23, v18
     ad4:      	add.2d	v9, v9, v2
     ad8:      	and.16b	v2, v16, v18
     adc:      	add.2d	v15, v15, v2
     ae0:      	and.16b	v2, v10, v18
     ae4:      	add.2d	v29, v29, v2
     ae8:      	bit.16b	v22, v27, v0
     aec:      	bit.16b	v25, v8, v1
     af0:      	bit.16b	v20, v30, v0
     af4:      	bit.16b	v21, v31, v1
     af8:      	bit.16b	v19, v7, v0
     afc:      	bit.16b	v6, v28, v1
     b00:      	bit.16b	v5, v17, v0
     b04:      	bit.16b	v4, v3, v1
     b08:      	fmov	x9, d29
     b0c:      	cmp	x9, #0xc0
     b10:      	b.lt	0xa88 <_llm_rows.packet_batch.blocks+0x5ac>
     b14:      	mov	x7, #0x0                ; =0
     b18:      	movi	d2, #0xffffffffffff0000
     b1c:      	ldr	q28, [sp, #0x160]
     b20:      	and.8b	v16, v28, v2
     b24:      	ldp	q30, q29, [sp, #0x40]
     b28:      	fadd.4s	v2, v30, v22
     b2c:      	fadd.4s	v3, v29, v25
     b30:      	ldr	q25, [sp, #0x180]
     b34:      	zip1.8b	v7, v25, v0
     b38:      	ushll.4s	v7, v7, #0x0
     b3c:      	shl.4s	v7, v7, #0x1f
     b40:      	cmlt.4s	v7, v7, #0
     b44:      	and.16b	v3, v7, v3
     b48:      	zip2.8b	v7, v25, v0
     b4c:      	ushll.4s	v7, v7, #0x0
     b50:      	shl.4s	v7, v7, #0x1f
     b54:      	cmlt.4s	v7, v7, #0
     b58:      	and.16b	v2, v7, v2
     b5c:      	zip2.8b	v7, v16, v0
     b60:      	ushll.4s	v7, v7, #0x0
     b64:      	shl.4s	v7, v7, #0x1f
     b68:      	cmlt.4s	v7, v7, #0
     b6c:      	bit.16b	v2, v27, v7
     b70:      	str	d16, [sp, #0x60]
     b74:      	zip1.8b	v7, v16, v0
     b78:      	ushll.4s	v7, v7, #0x0
     b7c:      	shl.4s	v7, v7, #0x1f
     b80:      	cmlt.4s	v7, v7, #0
     b84:      	bit.16b	v3, v8, v7
     b88:      	fadd.4s	v3, v21, v3
     b8c:      	fadd.4s	v2, v20, v2
     b90:      	fadd.4s	v2, v19, v2
     b94:      	fadd.4s	v3, v6, v3
     b98:      	fadd.4s	v4, v4, v3
     b9c:      	fadd.4s	v5, v5, v2
     ba0:      	ldr	q2, [sp, #0x170]
     ba4:      	ldp	q6, q3, [sp, #0x70]
     ba8:      	uzp1.4s	v3, v2, v3
     bac:      	ldr	q2, [sp, #0x90]
     bb0:      	uzp1.4s	v6, v6, v2
     bb4:      	movi.4s	v7, #0x1
     bb8:      	eor.16b	v2, v3, v7
     bbc:      	mov.s	w11, v2[1]
     bc0:      	mov.s	w14, v2[2]
     bc4:      	eor.16b	v20, v6, v7
     bc8:      	mov.s	w16, v2[3]
     bcc:      	fmov	w9, s2
     bd0:      	add	x13, sp, #0x488
     bd4:      	bfxil	x13, x9, #0, #3
     bd8:      	str	d28, [sp, #0x488]
     bdc:      	ldrb	w15, [x13]
     be0:      	and	x9, x9, #0x7
     be4:      	umov.b	w13, v28[0]
     be8:      	str	q5, [sp, #0x560]
     bec:      	str	q4, [sp, #0x550]
     bf0:      	add	x17, sp, #0x550
     bf4:      	ldr	s2, [x17, x9, lsl #2]
     bf8:      	ands	w9, w13, #0x1
     bfc:      	tst	w9, w15
     c00:      	movi	d22, #0000000000000000
     c04:      	fcsel	s17, s2, s22, ne
     c08:      	and	x15, x11, #0x7
     c0c:      	add	x17, sp, #0x488
     c10:      	bfxil	x17, x11, #0, #3
     c14:      	ldrb	w11, [x17]
     c18:      	umov.b	w17, v28[1]
     c1c:      	and	w11, w17, w11
     c20:      	str	q5, [sp, #0x540]
     c24:      	str	q4, [sp, #0x530]
     c28:      	add	x0, sp, #0x530
     c2c:      	ldr	s2, [x0, x15, lsl #2]
     c30:      	tst	w11, #0x1
     c34:      	fcsel	s18, s2, s22, ne
     c38:      	and	x11, x14, #0x7
     c3c:      	add	x0, sp, #0x488
     c40:      	bfxil	x0, x14, #0, #3
     c44:      	umov.b	w15, v28[2]
     c48:      	ldrb	w14, [x0]
     c4c:      	and	w14, w15, w14
     c50:      	str	q5, [sp, #0x520]
     c54:      	str	q4, [sp, #0x510]
     c58:      	add	x0, sp, #0x510
     c5c:      	ldr	s2, [x0, x11, lsl #2]
     c60:      	tst	w14, #0x1
     c64:      	fcsel	s19, s2, s22, ne
     c68:      	and	x11, x16, #0x7
     c6c:      	add	x14, sp, #0x488
     c70:      	bfxil	x14, x16, #0, #3
     c74:      	ldrb	w14, [x14]
     c78:      	umov.b	w16, v28[3]
     c7c:      	str	q5, [sp, #0x500]
     c80:      	str	q4, [sp, #0x4f0]
     c84:      	add	x0, sp, #0x4f0
     c88:      	ldr	s2, [x0, x11, lsl #2]
     c8c:      	and	w11, w16, w14
     c90:      	tst	w11, #0x1
     c94:      	mov.s	w11, v20[1]
     c98:      	mov.s	w14, v20[2]
     c9c:      	fcsel	s21, s2, s22, ne
     ca0:      	mov.s	w0, v20[3]
     ca4:      	fmov	w1, s20
     ca8:      	and	x2, x1, #0x7
     cac:      	add	x3, sp, #0x488
     cb0:      	bfxil	x3, x1, #0, #3
     cb4:      	ldrb	w1, [x3]
     cb8:      	umov.b	w4, v28[4]
     cbc:      	and	w1, w4, w1
     cc0:      	str	q5, [sp, #0x5e0]
     cc4:      	str	q4, [sp, #0x5d0]
     cc8:      	add	x3, sp, #0x5d0
     ccc:      	ldr	s2, [x3, x2, lsl #2]
     cd0:      	tst	w1, #0x1
     cd4:      	fcsel	s2, s2, s22, ne
     cd8:      	and	x1, x11, #0x7
     cdc:      	add	x2, sp, #0x488
     ce0:      	bfxil	x2, x11, #0, #3
     ce4:      	ldrb	w11, [x2]
     ce8:      	umov.b	w3, v28[5]
     cec:      	and	w11, w3, w11
     cf0:      	str	q5, [sp, #0x5c0]
     cf4:      	str	q4, [sp, #0x5b0]
     cf8:      	add	x2, sp, #0x5b0
     cfc:      	ldr	s7, [x2, x1, lsl #2]
     d00:      	tst	w11, #0x1
     d04:      	fcsel	s7, s7, s22, ne
     d08:      	and	x11, x14, #0x7
     d0c:      	add	x1, sp, #0x488
     d10:      	bfxil	x1, x14, #0, #3
     d14:      	ldrb	w14, [x1]
     d18:      	umov.b	w1, v28[6]
     d1c:      	and	w14, w1, w14
     d20:      	str	q5, [sp, #0x5a0]
     d24:      	str	q4, [sp, #0x590]
     d28:      	add	x2, sp, #0x590
     d2c:      	ldr	s16, [x2, x11, lsl #2]
     d30:      	tst	w14, #0x1
     d34:      	fcsel	s16, s16, s22, ne
     d38:      	and	x11, x0, #0x7
     d3c:      	add	x14, sp, #0x488
     d40:      	bfxil	x14, x0, #0, #3
     d44:      	umov.b	w2, v28[7]
     d48:      	ldrb	w14, [x14]
     d4c:      	and	w14, w2, w14
     d50:      	str	q5, [sp, #0x580]
     d54:      	str	q4, [sp, #0x570]
     d58:      	add	x0, sp, #0x570
     d5c:      	ldr	s20, [x0, x11, lsl #2]
     d60:      	tst	w14, #0x1
     d64:      	fcsel	s20, s20, s22, ne
     d68:      	mov.s	v2[1], v7[0]
     d6c:      	mov.s	v2[2], v16[0]
     d70:      	mov.s	v2[3], v20[0]
     d74:      	mov.s	v17[1], v18[0]
     d78:      	mov.s	v17[2], v19[0]
     d7c:      	mov.s	v17[3], v21[0]
     d80:      	fadd.4s	v4, v4, v17
     d84:      	fadd.4s	v2, v5, v2
     d88:      	movi.4s	v7, #0x2
     d8c:      	eor.16b	v5, v6, v7
     d90:      	eor.16b	v3, v3, v7
     d94:      	fmov	w11, s3
     d98:      	add	x14, sp, #0x488
     d9c:      	bfxil	x14, x11, #0, #3
     da0:      	ldrb	w14, [x14]
     da4:      	and	x11, x11, #0x7
     da8:      	str	q2, [sp, #0x4e0]
     dac:      	str	q4, [sp, #0x4d0]
     db0:      	add	x0, sp, #0x4d0
     db4:      	ldr	s3, [x0, x11, lsl #2]
     db8:      	tst	w9, w14
     dbc:      	fcsel	s3, s3, s22, ne
     dc0:      	fmov	w9, s5
     dc4:      	and	x11, x9, #0x7
     dc8:      	add	x14, sp, #0x488
     dcc:      	bfxil	x14, x9, #0, #3
     dd0:      	ldrb	w9, [x14]
     dd4:      	and	w9, w4, w9
     dd8:      	str	q2, [sp, #0x4c0]
     ddc:      	str	q4, [sp, #0x4b0]
     de0:      	add	x14, sp, #0x4b0
     de4:      	ldr	s5, [x14, x11, lsl #2]
     de8:      	tst	w9, #0x1
     dec:      	fcsel	s5, s5, s22, ne
     df0:      	fadd.4s	v2, v2, v5
     df4:      	and	w0, w13, w4
     df8:      	tst	w0, #0x1
     dfc:      	fcsel	s2, s2, s22, ne
     e00:      	ands	w14, w13, #0x1
     e04:      	fadd.4s	v3, v4, v3
     e08:      	fadd	s2, s3, s2
     e0c:      	fcsel	s3, s2, s22, ne
     e10:      	tst	w0, #0x1
     e14:      	and	w9, w17, w13
     e18:      	fcsel	s4, s2, s22, ne
     e1c:      	str	w9, [sp, #0x80]
     e20:      	tst	w9, #0x1
     e24:      	and	w9, w15, w13
     e28:      	fcsel	s5, s2, s22, ne
     e2c:      	str	w9, [sp, #0x70]
     e30:      	tst	w9, #0x1
     e34:      	and	w30, w16, w13
     e38:      	fcsel	s6, s2, s22, ne
     e3c:      	tst	w30, #0x1
     e40:      	fcsel	s7, s2, s22, ne
     e44:      	and	w11, w3, w13
     e48:      	tst	w11, #0x1
     e4c:      	fcsel	s16, s2, s22, ne
     e50:      	and	w9, w1, w13
     e54:      	tst	w9, #0x1
     e58:      	fcsel	s17, s2, s22, ne
     e5c:      	and	w27, w2, w13
     e60:      	str	w27, [sp, #0x6c]
     e64:      	tst	w27, #0x1
     e68:      	fcsel	s2, s2, s22, ne
     e6c:      	mov.s	v3[1], v5[0]
     e70:      	mov.s	v3[2], v6[0]
     e74:      	mov.s	v3[3], v7[0]
     e78:      	mov.s	v4[1], v16[0]
     e7c:      	mov.s	v4[2], v17[0]
     e80:      	mov.s	v4[3], v2[0]
     e84:      	rbit	w23, w23
     e88:      	clz	w23, w23
     e8c:      	str	q4, [sp, #0x4a0]
     e90:      	str	q3, [sp, #0x490]
     e94:      	str	x23, [sp, #0x90]
     e98:      	and	x23, x23, #0x7
     e9c:      	add	x27, sp, #0x490
     ea0:      	ldr	s2, [x27, x23, lsl #2]
     ea4:      	fadd	s2, s2, s22
     ea8:      	mov	w23, #0x4000            ; =16384
     eac:      	movk	w23, #0x44c0, lsl #16
     eb0:      	fmov	s3, w23
     eb4:      	fdiv	s2, s2, s3
     eb8:      	dup.4s	v3, v2[0]
     ebc:      	mov	w23, #0x1               ; =1
     ec0:      	dup.2d	v2, x23
     ec4:      	ushll2.2d	v4, v0, #0x0
     ec8:      	and.16b	v18, v4, v2
     ecc:      	ushll2.2d	v4, v1, #0x0
     ed0:      	and.16b	v19, v4, v2
     ed4:      	ushll.2d	v4, v0, #0x0
     ed8:      	and.16b	v20, v4, v2
     edc:      	ushll.2d	v4, v1, #0x0
     ee0:      	and.16b	v21, v4, v2
     ee4:      	movi.2d	v4, #0000000000000000
     ee8:      	movi.2d	v5, #0000000000000000
     eec:      	movi.2d	v6, #0000000000000000
     ef0:      	movi.2d	v17, #0000000000000000
     ef4:      	lsl	x7, x7, #5
     ef8:      	add	x23, x25, x7
     efc:      	ldp	q7, q2, [x23]
     f00:      	fsub.4s	v7, v7, v3
     f04:      	fsub.4s	v2, v2, v3
     f08:      	add	x7, x19, x7
     f0c:      	ldp	q16, q22, [x7]
     f10:      	bif.16b	v2, v22, v0
     f14:      	bif.16b	v7, v16, v1
     f18:      	stp	q7, q2, [x7]
     f1c:      	add.2d	v5, v5, v19
     f20:      	add.2d	v6, v6, v20
     f24:      	add.2d	v17, v17, v18
     f28:      	add.2d	v4, v4, v21
     f2c:      	fmov	x7, d4
     f30:      	cmp	x7, #0xc0
     f34:      	b.lt	0xef4 <_llm_rows.packet_batch.blocks+0xa18>
     f38:      	fsub.4s	v5, v29, v3
     f3c:      	fsub.4s	v6, v30, v3
     f40:      	ldr	x7, [sp, #0x190]
     f44:      	add	x7, x19, x7
     f48:      	ldp	q2, q3, [x7]
     f4c:      	zip2.8b	v4, v25, v0
     f50:      	ushll.4s	v4, v4, #0x0
     f54:      	shl.4s	v4, v4, #0x1f
     f58:      	cmlt.4s	v4, v4, #0
     f5c:      	stp	q6, q5, [sp, #0x40]
     f60:      	bit.16b	v3, v6, v4
     f64:      	zip1.8b	v4, v25, v0
     f68:      	ushll.4s	v4, v4, #0x0
     f6c:      	shl.4s	v4, v4, #0x1f
     f70:      	cmlt.4s	v4, v4, #0
     f74:      	bit.16b	v2, v5, v4
     f78:      	stp	q2, q3, [x7]
     f7c:      	ldr	q2, [sp, #0x3730]
     f80:      	ldr	q3, [sp, #0x3720]
     f84:      	fmul.4s	v3, v3, v3
     f88:      	fmul.4s	v2, v2, v2
     f8c:      	and.16b	v30, v0, v2
     f90:      	and.16b	v31, v1, v3
     f94:      	ldr	q2, [sp, #0x3710]
     f98:      	ldr	q3, [sp, #0x3700]
     f9c:      	fmul.4s	v3, v3, v3
     fa0:      	fmul.4s	v2, v2, v2
     fa4:      	and.16b	v17, v0, v2
     fa8:      	and.16b	v9, v1, v3
     fac:      	ldr	q2, [sp, #0x36f0]
     fb0:      	ldr	q3, [sp, #0x36e0]
     fb4:      	fmul.4s	v3, v3, v3
     fb8:      	fmul.4s	v2, v2, v2
     fbc:      	and.16b	v4, v0, v2
     fc0:      	and.16b	v5, v1, v3
     fc4:      	add	x6, x19, x6
     fc8:      	ldp	q3, q2, [x6]
     fcc:      	fmul.4s	v6, v3, v3
     fd0:      	fmul.4s	v2, v2, v2
     fd4:      	and.16b	v3, v0, v2
     fd8:      	and.16b	v6, v1, v6
     fdc:      	add	x27, sp, #0x680
     fe0:      	sshll.2d	v2, v1, #0x0
     fe4:      	sshll.2d	v7, v0, #0x0
     fe8:      	add	x5, x19, x5, lsl #5
     fec:      	ldp	q22, q16, [x5]
     ff0:      	and.16b	v22, v1, v22
     ff4:      	and.16b	v16, v0, v16
     ff8:      	fmul.4s	v16, v16, v16
     ffc:      	fmul.4s	v22, v22, v22
    1000:      	fadd.4s	v22, v6, v22
    1004:      	fadd.4s	v25, v3, v16
    1008:      	ldp	q27, q16, [x5, #0x20]
    100c:      	and.16b	v27, v1, v27
    1010:      	and.16b	v16, v0, v16
    1014:      	fmul.4s	v16, v16, v16
    1018:      	fmul.4s	v27, v27, v27
    101c:      	fadd.4s	v27, v5, v27
    1020:      	fadd.4s	v16, v4, v16
    1024:      	ldp	q10, q28, [x5, #0x40]
    1028:      	and.16b	v10, v1, v10
    102c:      	and.16b	v28, v0, v28
    1030:      	fmul.4s	v28, v28, v28
    1034:      	fmul.4s	v10, v10, v10
    1038:      	fadd.4s	v10, v9, v10
    103c:      	fadd.4s	v28, v17, v28
    1040:      	ldp	q29, q11, [x5, #0x60]
    1044:      	and.16b	v29, v1, v29
    1048:      	and.16b	v11, v0, v11
    104c:      	fmul.4s	v11, v11, v11
    1050:      	fmul.4s	v29, v29, v29
    1054:      	fadd.4s	v29, v31, v29
    1058:      	fadd.4s	v11, v30, v11
    105c:      	dup.2d	v15, x28
    1060:      	and.16b	v8, v24, v15
    1064:      	add.2d	v26, v26, v8
    1068:      	and.16b	v8, v23, v15
    106c:      	add.2d	v12, v12, v8
    1070:      	and.16b	v7, v7, v15
    1074:      	add.2d	v13, v13, v7
    1078:      	and.16b	v2, v2, v15
    107c:      	add.2d	v14, v14, v2
    1080:      	bit.16b	v3, v25, v0
    1084:      	bit.16b	v6, v22, v1
    1088:      	bit.16b	v4, v16, v0
    108c:      	bit.16b	v5, v27, v1
    1090:      	bit.16b	v17, v28, v0
    1094:      	bit.16b	v9, v10, v1
    1098:      	bit.16b	v30, v11, v0
    109c:      	bit.16b	v31, v29, v1
    10a0:      	fmov	x5, d14
    10a4:      	cmp	x5, #0xc0
    10a8:      	b.lt	0xfe0 <_llm_rows.packet_batch.blocks+0xb04>
    10ac:      	mov	x5, #0x0                ; =0
    10b0:      	movi.2d	v23, #0000000000000000
    10b4:      	movi.2d	v24, #0000000000000000
    10b8:      	movi.2d	v11, #0000000000000000
    10bc:      	movi.2d	v12, #0000000000000000
    10c0:      	ldr	q8, [sp, #0x140]
    10c4:      	ldr	q29, [sp, #0x180]
    10c8:      	b	0x10fc <_llm_rows.packet_batch.blocks+0xc20>
    10cc:      	add	x5, x21, x5
    10d0:      	ldp	q2, q7, [x5]
    10d4:      	bit.16b	v7, v14, v0
    10d8:      	bit.16b	v2, v13, v1
    10dc:      	stp	q2, q7, [x5]
    10e0:      	add.2d	v24, v24, v19
    10e4:      	add.2d	v11, v11, v20
    10e8:      	add.2d	v12, v12, v18
    10ec:      	add.2d	v23, v23, v21
    10f0:      	fmov	x5, d23
    10f4:      	cmp	x5, #0xc0
    10f8:      	b.ge	0x1198 <_llm_rows.packet_batch.blocks+0xcbc>
    10fc:      	fmov	w7, s8
    1100:      	lsl	x5, x5, #5
    1104:      	add	x6, x12, x5
    1108:      	movi.2d	v13, #0000000000000000
    110c:      	movi.2d	v14, #0000000000000000
    1110:      	tbnz	w7, #0x0, 0x1138 <_llm_rows.packet_batch.blocks+0xc5c>
    1114:      	and	w7, w7, #0xff
    1118:      	tbnz	w7, #0x1, 0x1144 <_llm_rows.packet_batch.blocks+0xc68>
    111c:      	tbnz	w7, #0x2, 0x1150 <_llm_rows.packet_batch.blocks+0xc74>
    1120:      	tbnz	w7, #0x3, 0x115c <_llm_rows.packet_batch.blocks+0xc80>
    1124:      	tbnz	w7, #0x4, 0x1168 <_llm_rows.packet_batch.blocks+0xc8c>
    1128:      	tbnz	w7, #0x5, 0x1174 <_llm_rows.packet_batch.blocks+0xc98>
    112c:      	tbnz	w7, #0x6, 0x1180 <_llm_rows.packet_batch.blocks+0xca4>
    1130:      	tbz	w7, #0x7, 0x10cc <_llm_rows.packet_batch.blocks+0xbf0>
    1134:      	b	0x118c <_llm_rows.packet_batch.blocks+0xcb0>
    1138:      	ldr	s13, [x6]
    113c:      	and	w7, w7, #0xff
    1140:      	tbz	w7, #0x1, 0x111c <_llm_rows.packet_batch.blocks+0xc40>
    1144:      	add	x23, x6, #0x4
    1148:      	ld1.s	{ v13 }[1], [x23]
    114c:      	tbz	w7, #0x2, 0x1120 <_llm_rows.packet_batch.blocks+0xc44>
    1150:      	add	x23, x6, #0x8
    1154:      	ld1.s	{ v13 }[2], [x23]
    1158:      	tbz	w7, #0x3, 0x1124 <_llm_rows.packet_batch.blocks+0xc48>
    115c:      	add	x23, x6, #0xc
    1160:      	ld1.s	{ v13 }[3], [x23]
    1164:      	tbz	w7, #0x4, 0x1128 <_llm_rows.packet_batch.blocks+0xc4c>
    1168:      	add	x23, x6, #0x10
    116c:      	ld1.s	{ v14 }[0], [x23]
    1170:      	tbz	w7, #0x5, 0x112c <_llm_rows.packet_batch.blocks+0xc50>
    1174:      	add	x23, x6, #0x14
    1178:      	ld1.s	{ v14 }[1], [x23]
    117c:      	tbz	w7, #0x6, 0x1130 <_llm_rows.packet_batch.blocks+0xc54>
    1180:      	add	x23, x6, #0x18
    1184:      	ld1.s	{ v14 }[2], [x23]
    1188:      	tbz	w7, #0x7, 0x10cc <_llm_rows.packet_batch.blocks+0xbf0>
    118c:      	add	x6, x6, #0x1c
    1190:      	ld1.s	{ v14 }[3], [x6]
    1194:      	b	0x10cc <_llm_rows.packet_batch.blocks+0xbf0>
    1198:      	adrp	x5, 0x1000 <_llm_rows.packet_batch.blocks+0xb24>
    119c:      	ldr	q2, [x5]
    11a0:      	and.16b	v12, v0, v2
    11a4:      	adrp	x5, 0x1000 <_llm_rows.packet_batch.blocks+0xb24>
    11a8:      	ldr	q2, [x5]
    11ac:      	and.16b	v13, v1, v2
    11b0:      	adrp	x5, 0x1000 <_llm_rows.packet_batch.blocks+0xb24>
    11b4:      	ldr	q11, [x5]
    11b8:      	zip2.8b	v2, v29, v0
    11bc:      	ushll.4s	v2, v2, #0x0
    11c0:      	shl.4s	v2, v2, #0x1f
    11c4:      	cmlt.4s	v2, v2, #0
    11c8:      	ldp	q7, q16, [sp, #0x40]
    11cc:      	and.16b	v23, v2, v7
    11d0:      	zip1.8b	v7, v29, v0
    11d4:      	ushll.4s	v7, v7, #0x0
    11d8:      	shl.4s	v7, v7, #0x1f
    11dc:      	cmlt.4s	v7, v7, #0
    11e0:      	and.16b	v24, v7, v16
    11e4:      	fmul.4s	v16, v24, v24
    11e8:      	fmul.4s	v26, v23, v23
    11ec:      	fadd.4s	v3, v26, v3
    11f0:      	fadd.4s	v6, v16, v6
    11f4:      	and.16b	v6, v7, v6
    11f8:      	and.16b	v2, v2, v3
    11fc:      	ldr	d7, [sp, #0x60]
    1200:      	zip2.8b	v3, v7, v0
    1204:      	ushll.4s	v3, v3, #0x0
    1208:      	shl.4s	v3, v3, #0x1f
    120c:      	cmlt.4s	v3, v3, #0
    1210:      	bit.16b	v2, v25, v3
    1214:      	zip1.8b	v3, v7, v0
    1218:      	ushll.4s	v3, v3, #0x0
    121c:      	shl.4s	v3, v3, #0x1f
    1220:      	cmlt.4s	v3, v3, #0
    1224:      	bsl.16b	v3, v22, v6
    1228:      	fadd.4s	v3, v5, v3
    122c:      	fadd.4s	v2, v4, v2
    1230:      	fadd.4s	v2, v17, v2
    1234:      	fadd.4s	v3, v9, v3
    1238:      	fadd.4s	v3, v31, v3
    123c:      	fadd.4s	v4, v30, v2
    1240:      	fmov	w5, s13
    1244:      	add	x6, sp, #0x1f8
    1248:      	bfxil	x6, x5, #0, #3
    124c:      	ldr	q2, [sp, #0x160]
    1250:      	str	d2, [sp, #0x1f8]
    1254:      	ldrb	w6, [x6]
    1258:      	add	x7, sp, #0x460
    125c:      	orr	x5, x7, x5, lsl #2
    1260:      	str	q4, [sp, #0x470]
    1264:      	str	q3, [sp, #0x460]
    1268:      	ldr	s2, [x5]
    126c:      	tst	w14, w6
    1270:      	movi	d26, #0000000000000000
    1274:      	fcsel	s5, s2, s26, ne
    1278:      	mov.s	w5, v13[1]
    127c:      	add	x6, sp, #0x1f8
    1280:      	bfxil	x6, x5, #0, #3
    1284:      	ldrb	w5, [x6]
    1288:      	and	w5, w17, w5
    128c:      	str	q3, [sp, #0x440]
    1290:      	ldr	s2, [sp, #0x440]
    1294:      	tst	w5, #0x1
    1298:      	mov.s	w5, v13[2]
    129c:      	fcsel	s6, s2, s26, ne
    12a0:      	add	x6, sp, #0x1f8
    12a4:      	bfxil	x6, x5, #0, #3
    12a8:      	add	x7, sp, #0x420
    12ac:      	orr	x5, x7, x5, lsl #2
    12b0:      	ldrb	w6, [x6]
    12b4:      	and	w6, w15, w6
    12b8:      	str	q4, [sp, #0x430]
    12bc:      	str	q3, [sp, #0x420]
    12c0:      	ldr	s2, [x5]
    12c4:      	tst	w6, #0x1
    12c8:      	mov.s	w5, v13[3]
    12cc:      	fcsel	s17, s2, s26, ne
    12d0:      	add	x6, sp, #0x1f8
    12d4:      	bfxil	x6, x5, #0, #3
    12d8:      	add	x7, sp, #0x400
    12dc:      	orr	x5, x7, x5, lsl #2
    12e0:      	ldrb	w6, [x6]
    12e4:      	and	w6, w16, w6
    12e8:      	str	q4, [sp, #0x410]
    12ec:      	str	q3, [sp, #0x400]
    12f0:      	ldr	s2, [x5]
    12f4:      	tst	w6, #0x1
    12f8:      	fcsel	s22, s2, s26, ne
    12fc:      	fmov	w5, s12
    1300:      	add	x6, sp, #0x1f8
    1304:      	bfxil	x6, x5, #0, #3
    1308:      	ldrb	w6, [x6]
    130c:      	and	w6, w4, w6
    1310:      	stp	q3, q4, [sp, #0x3e0]
    1314:      	add	x7, sp, #0x3e0
    1318:      	ldr	s2, [x7, w5, uxtw #2]
    131c:      	tst	w6, #0x1
    1320:      	fcsel	s2, s2, s26, ne
    1324:      	mov.s	w5, v12[1]
    1328:      	add	x6, sp, #0x1f8
    132c:      	bfxil	x6, x5, #0, #3
    1330:      	ldrb	w6, [x6]
    1334:      	and	w6, w3, w6
    1338:      	stp	q3, q4, [sp, #0x3c0]
    133c:      	add	x7, sp, #0x3c0
    1340:      	ldr	s7, [x7, w5, uxtw #2]
    1344:      	tst	w6, #0x1
    1348:      	fcsel	s7, s7, s26, ne
    134c:      	mov.s	w5, v12[2]
    1350:      	add	x6, sp, #0x1f8
    1354:      	bfxil	x6, x5, #0, #3
    1358:      	ldrb	w6, [x6]
    135c:      	and	w6, w1, w6
    1360:      	stp	q3, q4, [sp, #0x3a0]
    1364:      	add	x7, sp, #0x3a0
    1368:      	ldr	s16, [x7, w5, uxtw #2]
    136c:      	tst	w6, #0x1
    1370:      	fcsel	s16, s16, s26, ne
    1374:      	mov.s	w5, v12[3]
    1378:      	add	x6, sp, #0x1f8
    137c:      	bfxil	x6, x5, #0, #3
    1380:      	ldrb	w6, [x6]
    1384:      	and	w6, w2, w6
    1388:      	stp	q3, q4, [sp, #0x380]
    138c:      	add	x7, sp, #0x380
    1390:      	ldr	s25, [x7, w5, uxtw #2]
    1394:      	tst	w6, #0x1
    1398:      	fcsel	s25, s25, s26, ne
    139c:      	mov.s	v2[1], v7[0]
    13a0:      	mov.s	v2[2], v16[0]
    13a4:      	mov.s	v2[3], v25[0]
    13a8:      	mov.s	v5[1], v6[0]
    13ac:      	and.16b	v7, v1, v11
    13b0:      	mov.s	v5[2], v17[0]
    13b4:      	mov.s	v5[3], v22[0]
    13b8:      	fadd.4s	v3, v3, v5
    13bc:      	fadd.4s	v4, v4, v2
    13c0:      	fmov	w5, s7
    13c4:      	add	x6, sp, #0x1f8
    13c8:      	bfxil	x6, x5, #0, #3
    13cc:      	ldrb	w6, [x6]
    13d0:      	add	x7, sp, #0x360
    13d4:      	orr	x5, x7, x5, lsl #2
    13d8:      	stp	q3, q4, [sp, #0x360]
    13dc:      	ldr	s2, [x5]
    13e0:      	tst	w14, w6
    13e4:      	mov.s	w5, v7[1]
    13e8:      	add	x6, sp, #0x1f8
    13ec:      	bfxil	x6, x5, #0, #3
    13f0:      	ldrb	w6, [x6]
    13f4:      	and	w17, w17, w6
    13f8:      	fcsel	s5, s2, s26, ne
    13fc:      	add	x6, sp, #0x340
    1400:      	orr	x5, x6, x5, lsl #2
    1404:      	stp	q3, q4, [sp, #0x340]
    1408:      	ldr	s2, [x5]
    140c:      	tst	w17, #0x1
    1410:      	mov.s	w17, v7[2]
    1414:      	add	x5, sp, #0x1f8
    1418:      	bfxil	x5, x17, #0, #3
    141c:      	fcsel	s6, s2, s26, ne
    1420:      	ldrb	w17, [x5]
    1424:      	and	w15, w15, w17
    1428:      	str	q3, [sp, #0x320]
    142c:      	tst	w15, #0x1
    1430:      	mov.s	w15, v7[3]
    1434:      	add	x17, sp, #0x1f8
    1438:      	bfxil	x17, x15, #0, #3
    143c:      	ldrb	w17, [x17]
    1440:      	and	w16, w16, w17
    1444:      	adrp	x17, 0x1000 <_llm_rows.packet_batch.blocks+0xb24>
    1448:      	ldr	q2, [x17]
    144c:      	and.16b	v2, v0, v2
    1450:      	ldr	s7, [sp, #0x320]
    1454:      	fcsel	s22, s7, s26, ne
    1458:      	add	x17, sp, #0x300
    145c:      	orr	x15, x17, x15, lsl #2
    1460:      	stp	q3, q4, [sp, #0x300]
    1464:      	ldr	s7, [x15]
    1468:      	tst	w16, #0x1
    146c:      	fmov	w15, s2
    1470:      	add	x16, sp, #0x1f8
    1474:      	bfxil	x16, x15, #0, #3
    1478:      	ldrb	w16, [x16]
    147c:      	and	w16, w4, w16
    1480:      	fcsel	s17, s7, s26, ne
    1484:      	stp	q3, q4, [sp, #0x2e0]
    1488:      	add	x17, sp, #0x2e0
    148c:      	ldr	s7, [x17, w15, uxtw #2]
    1490:      	tst	w16, #0x1
    1494:      	mov.s	w15, v2[1]
    1498:      	add	x16, sp, #0x1f8
    149c:      	bfxil	x16, x15, #0, #3
    14a0:      	ldrb	w16, [x16]
    14a4:      	and	w16, w3, w16
    14a8:      	fcsel	s7, s7, s26, ne
    14ac:      	stp	q3, q4, [sp, #0x2c0]
    14b0:      	add	x17, sp, #0x2c0
    14b4:      	ldr	s16, [x17, w15, uxtw #2]
    14b8:      	tst	w16, #0x1
    14bc:      	mov.s	w15, v2[2]
    14c0:      	add	x16, sp, #0x1f8
    14c4:      	bfxil	x16, x15, #0, #3
    14c8:      	ldrb	w16, [x16]
    14cc:      	and	w16, w1, w16
    14d0:      	fcsel	s16, s16, s26, ne
    14d4:      	stp	q3, q4, [sp, #0x2a0]
    14d8:      	add	x17, sp, #0x2a0
    14dc:      	ldr	s25, [x17, w15, uxtw #2]
    14e0:      	tst	w16, #0x1
    14e4:      	mov.s	w15, v2[3]
    14e8:      	add	x16, sp, #0x1f8
    14ec:      	bfxil	x16, x15, #0, #3
    14f0:      	ldrb	w16, [x16]
    14f4:      	and	w16, w2, w16
    14f8:      	fcsel	s2, s25, s26, ne
    14fc:      	stp	q3, q4, [sp, #0x280]
    1500:      	add	x17, sp, #0x280
    1504:      	ldr	s25, [x17, w15, uxtw #2]
    1508:      	tst	w16, #0x1
    150c:      	fcsel	s25, s25, s26, ne
    1510:      	mov.s	v7[1], v16[0]
    1514:      	mov.s	v7[2], v2[0]
    1518:      	mov.s	v7[3], v25[0]
    151c:      	mov.s	v5[1], v6[0]
    1520:      	movi.4s	v2, #0x4
    1524:      	and.16b	v2, v1, v2
    1528:      	mov.s	v5[2], v22[0]
    152c:      	fmov	w15, s2
    1530:      	add	x16, sp, #0x1f8
    1534:      	orr	x16, x16, x15
    1538:      	ldrb	w16, [x16]
    153c:      	tst	w14, w16
    1540:      	mov.s	v5[3], v17[0]
    1544:      	fadd.4s	v2, v3, v5
    1548:      	fadd.4s	v3, v4, v7
    154c:      	stp	q2, q3, [sp, #0x260]
    1550:      	add	x14, sp, #0x260
    1554:      	ldr	s3, [x14, w15, uxtw #2]
    1558:      	fcsel	s3, s3, s26, ne
    155c:      	tst	w13, #0x1
    1560:      	fadd	s2, s2, s3
    1564:      	fcsel	s3, s2, s26, ne
    1568:      	ldr	w13, [sp, #0x80]
    156c:      	tst	w13, #0x1
    1570:      	fcsel	s4, s2, s26, ne
    1574:      	ldr	w13, [sp, #0x70]
    1578:      	tst	w13, #0x1
    157c:      	fcsel	s5, s2, s26, ne
    1580:      	tst	w30, #0x1
    1584:      	fcsel	s6, s2, s26, ne
    1588:      	tst	w0, #0x1
    158c:      	fcsel	s7, s2, s26, ne
    1590:      	tst	w11, #0x1
    1594:      	fcsel	s16, s2, s26, ne
    1598:      	tst	w9, #0x1
    159c:      	adrp	x9, 0x1000 <_llm_rows.packet_batch.blocks+0xb24>
    15a0:      	ldr	d17, [x9]
    15a4:      	shl.8b	v22, v29, #0x7
    15a8:      	cmlt.8b	v22, v22, #0
    15ac:      	fcsel	s25, s2, s26, ne
    15b0:      	ldr	w9, [sp, #0x6c]
    15b4:      	tst	w9, #0x1
    15b8:      	movi	d27, #0000000000000000
    15bc:      	fcsel	s2, s2, s26, ne
    15c0:      	mov.s	v3[1], v4[0]
    15c4:      	mov.s	v3[2], v5[0]
    15c8:      	mov.s	v3[3], v6[0]
    15cc:      	mov.s	v7[1], v16[0]
    15d0:      	mov.s	v7[2], v25[0]
    15d4:      	mov.s	v7[3], v2[0]
    15d8:      	and.8b	v2, v22, v17
    15dc:      	stp	q3, q7, [sp, #0x240]
    15e0:      	ldr	x9, [sp, #0x90]
    15e4:      	and	x9, x9, #0x7
    15e8:      	add	x11, sp, #0x240
    15ec:      	ldr	s3, [x11, x9, lsl #2]
    15f0:      	addv.8b	b28, v2
    15f4:      	mov	b2, v29[0]
    15f8:      	mov.b	v2[4], v29[1]
    15fc:      	ushll.2d	v2, v2, #0x0
    1600:      	shl.2d	v2, v2, #0x3f
    1604:      	cmlt.2d	v2, v2, #0
    1608:      	ldr	q4, [sp, #0xd0]
    160c:      	and.16b	v2, v2, v4
    1610:      	mov	b4, v29[2]
    1614:      	mov.b	v4[4], v29[3]
    1618:      	ushll.2d	v4, v4, #0x0
    161c:      	shl.2d	v4, v4, #0x3f
    1620:      	cmlt.2d	v4, v4, #0
    1624:      	ldp	q5, q7, [sp, #0xa0]
    1628:      	and.16b	v4, v4, v5
    162c:      	mov	b5, v29[4]
    1630:      	mov.b	v5[4], v29[5]
    1634:      	ushll.2d	v5, v5, #0x0
    1638:      	shl.2d	v5, v5, #0x3f
    163c:      	cmlt.2d	v5, v5, #0
    1640:      	mov	b6, v29[6]
    1644:      	mov.b	v6[4], v29[7]
    1648:      	and.16b	v5, v5, v7
    164c:      	ushll.2d	v6, v6, #0x0
    1650:      	shl.2d	v6, v6, #0x3f
    1654:      	cmlt.2d	v6, v6, #0
    1658:      	ldr	q7, [sp, #0xc0]
    165c:      	and.16b	v6, v6, v7
    1660:      	stp	q5, q6, [sp, #0x220]
    1664:      	stp	q2, q4, [sp, #0x200]
    1668:      	ldr	x16, [sp, #0x138]
    166c:      	and	x9, x16, #0x7
    1670:      	add	x11, sp, #0x200
    1674:      	ldr	x9, [x11, x9, lsl #3]
    1678:      	fmov	w11, s28
    167c:      	sub	x9, x9, x16
    1680:      	lsl	x9, x9, #2
    1684:      	add	x12, x12, x9
    1688:      	movi.2d	v22, #0000000000000000
    168c:      	movi.2d	v25, #0000000000000000
    1690:      	tbnz	w11, #0x0, 0x1ab8 <_llm_rows.packet_batch.blocks+0x15dc>
    1694:      	ldr	w0, [sp, #0x158]
    1698:      	ldr	q31, [sp, #0x170]
    169c:      	tbnz	w11, #0x1, 0x1ac8 <_llm_rows.packet_batch.blocks+0x15ec>
    16a0:      	tbnz	w11, #0x2, 0x1ad4 <_llm_rows.packet_batch.blocks+0x15f8>
    16a4:      	tbnz	w11, #0x3, 0x1ae0 <_llm_rows.packet_batch.blocks+0x1604>
    16a8:      	tbnz	w11, #0x4, 0x1aec <_llm_rows.packet_batch.blocks+0x1610>
    16ac:      	tbnz	w11, #0x5, 0x1af8 <_llm_rows.packet_batch.blocks+0x161c>
    16b0:      	tbnz	w11, #0x6, 0x1b04 <_llm_rows.packet_batch.blocks+0x1628>
    16b4:      	tbz	w11, #0x7, 0x16c0 <_llm_rows.packet_batch.blocks+0x11e4>
    16b8:      	add	x11, x12, #0x1c
    16bc:      	ld1.s	{ v25 }[3], [x11]
    16c0:      	fadd	s2, s3, s27
    16c4:      	mov	w11, #0x4000            ; =16384
    16c8:      	movk	w11, #0x44c0, lsl #16
    16cc:      	fmov	s3, w11
    16d0:      	fdiv	s2, s2, s3
    16d4:      	ldr	x11, [sp, #0x190]
    16d8:      	add	x11, x21, x11
    16dc:      	ldp	q3, q4, [x11]
    16e0:      	zip2.8b	v5, v29, v0
    16e4:      	ushll.4s	v5, v5, #0x0
    16e8:      	shl.4s	v5, v5, #0x1f
    16ec:      	cmlt.4s	v5, v5, #0
    16f0:      	bit.16b	v4, v25, v5
    16f4:      	zip1.8b	v5, v29, v0
    16f8:      	ushll.4s	v5, v5, #0x0
    16fc:      	shl.4s	v5, v5, #0x1f
    1700:      	cmlt.4s	v5, v5, #0
    1704:      	bit.16b	v3, v22, v5
    1708:      	stp	q3, q4, [x11]
    170c:      	mov	w11, #0xc5ac            ; =50604
    1710:      	movk	w11, #0x3727, lsl #16
    1714:      	fmov	s3, w11
    1718:      	fadd	s2, s2, s3
    171c:      	fsqrt	s26, s2
    1720:      	subs	x11, x8, x10
    1724:      	lsr	x11, x11, #3
    1728:      	mov	w12, #0x300             ; =768
    172c:      	ccmp	x11, x12, #0x0, hs
    1730:      	cset	w11, hi
    1734:      	sub	x12, x10, x8
    1738:      	mov	w13, #0x2007            ; =8199
    173c:      	movk	w13, #0x18, lsl #16
    1740:      	cmp	x12, x13
    1744:      	ccmp	x10, x8, #0x0, hi
    1748:      	b.hs	0x1834 <_llm_rows.packet_batch.blocks+0x1358>
    174c:      	tbnz	w11, #0x0, 0x1834 <_llm_rows.packet_batch.blocks+0x1358>
    1750:      	mov	x11, #0x0               ; =0
    1754:      	movi.2d	v3, #0000000000000000
    1758:      	movi.2d	v4, #0000000000000000
    175c:      	movi.2d	v5, #0000000000000000
    1760:      	movi.2d	v6, #0000000000000000
    1764:      	b	0x1798 <_llm_rows.packet_batch.blocks+0x12bc>
    1768:      	add	x11, x27, x11
    176c:      	ldp	q2, q7, [x11]
    1770:      	bit.16b	v7, v17, v0
    1774:      	bit.16b	v2, v16, v1
    1778:      	stp	q2, q7, [x11]
    177c:      	add.2d	v4, v4, v19
    1780:      	add.2d	v5, v5, v20
    1784:      	add.2d	v6, v6, v18
    1788:      	add.2d	v3, v3, v21
    178c:      	fmov	x11, d3
    1790:      	cmp	x11, #0xc0
    1794:      	b.ge	0x1b14 <_llm_rows.packet_batch.blocks+0x1638>
    1798:      	fmov	w13, s8
    179c:      	lsl	x11, x11, #5
    17a0:      	add	x12, x10, x11
    17a4:      	movi.2d	v16, #0000000000000000
    17a8:      	movi.2d	v17, #0000000000000000
    17ac:      	tbnz	w13, #0x0, 0x17d4 <_llm_rows.packet_batch.blocks+0x12f8>
    17b0:      	and	w13, w13, #0xff
    17b4:      	tbnz	w13, #0x1, 0x17e0 <_llm_rows.packet_batch.blocks+0x1304>
    17b8:      	tbnz	w13, #0x2, 0x17ec <_llm_rows.packet_batch.blocks+0x1310>
    17bc:      	tbnz	w13, #0x3, 0x17f8 <_llm_rows.packet_batch.blocks+0x131c>
    17c0:      	tbnz	w13, #0x4, 0x1804 <_llm_rows.packet_batch.blocks+0x1328>
    17c4:      	tbnz	w13, #0x5, 0x1810 <_llm_rows.packet_batch.blocks+0x1334>
    17c8:      	tbnz	w13, #0x6, 0x181c <_llm_rows.packet_batch.blocks+0x1340>
    17cc:      	tbz	w13, #0x7, 0x1768 <_llm_rows.packet_batch.blocks+0x128c>
    17d0:      	b	0x1828 <_llm_rows.packet_batch.blocks+0x134c>
    17d4:      	ldr	s16, [x12]
    17d8:      	and	w13, w13, #0xff
    17dc:      	tbz	w13, #0x1, 0x17b8 <_llm_rows.packet_batch.blocks+0x12dc>
    17e0:      	add	x14, x12, #0x4
    17e4:      	ld1.s	{ v16 }[1], [x14]
    17e8:      	tbz	w13, #0x2, 0x17bc <_llm_rows.packet_batch.blocks+0x12e0>
    17ec:      	add	x14, x12, #0x8
    17f0:      	ld1.s	{ v16 }[2], [x14]
    17f4:      	tbz	w13, #0x3, 0x17c0 <_llm_rows.packet_batch.blocks+0x12e4>
    17f8:      	add	x14, x12, #0xc
    17fc:      	ld1.s	{ v16 }[3], [x14]
    1800:      	tbz	w13, #0x4, 0x17c4 <_llm_rows.packet_batch.blocks+0x12e8>
    1804:      	add	x14, x12, #0x10
    1808:      	ld1.s	{ v17 }[0], [x14]
    180c:      	tbz	w13, #0x5, 0x17c8 <_llm_rows.packet_batch.blocks+0x12ec>
    1810:      	add	x14, x12, #0x14
    1814:      	ld1.s	{ v17 }[1], [x14]
    1818:      	tbz	w13, #0x6, 0x17cc <_llm_rows.packet_batch.blocks+0x12f0>
    181c:      	add	x14, x12, #0x18
    1820:      	ld1.s	{ v17 }[2], [x14]
    1824:      	tbz	w13, #0x7, 0x1768 <_llm_rows.packet_batch.blocks+0x128c>
    1828:      	add	x12, x12, #0x1c
    182c:      	ld1.s	{ v17 }[3], [x12]
    1830:      	b	0x1768 <_llm_rows.packet_batch.blocks+0x128c>
    1834:      	mov	x11, #0x0               ; =0
    1838:      	ldr	q2, [sp, #0xe0]
    183c:      	add.2d	v3, v2, v31
    1840:      	dup.4s	v7, v26[0]
    1844:      	movi.2d	v4, #0000000000000000
    1848:      	movi.2d	v5, #0000000000000000
    184c:      	movi.2d	v6, #0000000000000000
    1850:      	movi.2d	v17, #0000000000000000
    1854:      	b	0x1874 <_llm_rows.packet_batch.blocks+0x1398>
    1858:      	add.2d	v5, v5, v19
    185c:      	add.2d	v6, v6, v20
    1860:      	add.2d	v17, v17, v18
    1864:      	add.2d	v4, v4, v21
    1868:      	fmov	x11, d4
    186c:      	cmp	x11, #0xc0
    1870:      	b.ge	0x1a08 <_llm_rows.packet_batch.blocks+0x152c>
    1874:      	fmov	w13, s8
    1878:      	shl.2d	v27, v4, #0x3
    187c:      	orr.16b	v2, v27, v31
    1880:      	fmov	x12, d2
    1884:      	add	x12, x10, x12, lsl #2
    1888:      	movi.2d	v29, #0000000000000000
    188c:      	movi.2d	v26, #0000000000000000
    1890:      	tbnz	w13, #0x0, 0x1938 <_llm_rows.packet_batch.blocks+0x145c>
    1894:      	and	w13, w13, #0xff
    1898:      	tbnz	w13, #0x1, 0x1944 <_llm_rows.packet_batch.blocks+0x1468>
    189c:      	tbnz	w13, #0x2, 0x1950 <_llm_rows.packet_batch.blocks+0x1474>
    18a0:      	tbnz	w13, #0x3, 0x195c <_llm_rows.packet_batch.blocks+0x1480>
    18a4:      	tbnz	w13, #0x4, 0x1968 <_llm_rows.packet_batch.blocks+0x148c>
    18a8:      	tbnz	w13, #0x5, 0x1974 <_llm_rows.packet_batch.blocks+0x1498>
    18ac:      	tbnz	w13, #0x6, 0x1980 <_llm_rows.packet_batch.blocks+0x14a4>
    18b0:      	tbz	w13, #0x7, 0x18bc <_llm_rows.packet_batch.blocks+0x13e0>
    18b4:      	add	x12, x12, #0x1c
    18b8:      	ld1.s	{ v26 }[3], [x12]
    18bc:      	lsl	x11, x11, #5
    18c0:      	add	x13, x19, x11
    18c4:      	ldr	q2, [x13]
    18c8:      	and.16b	v2, v1, v2
    18cc:      	fdiv.4s	v2, v2, v7
    18d0:      	add	x14, x21, x11
    18d4:      	ldr	q16, [x14]
    18d8:      	and.16b	v16, v1, v16
    18dc:      	fmul.4s	v2, v2, v16
    18e0:      	fmov	w12, s8
    18e4:      	fadd.4s	v29, v29, v2
    18e8:      	add.2d	v2, v3, v27
    18ec:      	fmov	x11, d2
    18f0:      	add	x11, x8, x11, lsl #2
    18f4:      	tbnz	w12, #0x0, 0x1990 <_llm_rows.packet_batch.blocks+0x14b4>
    18f8:      	and	w12, w12, #0xff
    18fc:      	tbnz	w12, #0x1, 0x199c <_llm_rows.packet_batch.blocks+0x14c0>
    1900:      	ldr	q30, [x13, #0x10]
    1904:      	ldr	q27, [x14, #0x10]
    1908:      	tbnz	w12, #0x2, 0x19b0 <_llm_rows.packet_batch.blocks+0x14d4>
    190c:      	tbnz	w12, #0x3, 0x19bc <_llm_rows.packet_batch.blocks+0x14e0>
    1910:      	and.16b	v2, v0, v30
    1914:      	fdiv.4s	v2, v2, v7
    1918:      	and.16b	v16, v0, v27
    191c:      	fmul.4s	v2, v2, v16
    1920:      	fadd.4s	v26, v26, v2
    1924:      	tbnz	w12, #0x4, 0x19dc <_llm_rows.packet_batch.blocks+0x1500>
    1928:      	tbnz	w12, #0x5, 0x19e4 <_llm_rows.packet_batch.blocks+0x1508>
    192c:      	tbnz	w12, #0x6, 0x19f0 <_llm_rows.packet_batch.blocks+0x1514>
    1930:      	tbz	w12, #0x7, 0x1858 <_llm_rows.packet_batch.blocks+0x137c>
    1934:      	b	0x19fc <_llm_rows.packet_batch.blocks+0x1520>
    1938:      	ldr	s29, [x12]
    193c:      	and	w13, w13, #0xff
    1940:      	tbz	w13, #0x1, 0x189c <_llm_rows.packet_batch.blocks+0x13c0>
    1944:      	add	x14, x12, #0x4
    1948:      	ld1.s	{ v29 }[1], [x14]
    194c:      	tbz	w13, #0x2, 0x18a0 <_llm_rows.packet_batch.blocks+0x13c4>
    1950:      	add	x14, x12, #0x8
    1954:      	ld1.s	{ v29 }[2], [x14]
    1958:      	tbz	w13, #0x3, 0x18a4 <_llm_rows.packet_batch.blocks+0x13c8>
    195c:      	add	x14, x12, #0xc
    1960:      	ld1.s	{ v29 }[3], [x14]
    1964:      	tbz	w13, #0x4, 0x18a8 <_llm_rows.packet_batch.blocks+0x13cc>
    1968:      	add	x14, x12, #0x10
    196c:      	ld1.s	{ v26 }[0], [x14]
    1970:      	tbz	w13, #0x5, 0x18ac <_llm_rows.packet_batch.blocks+0x13d0>
    1974:      	add	x14, x12, #0x14
    1978:      	ld1.s	{ v26 }[1], [x14]
    197c:      	tbz	w13, #0x6, 0x18b0 <_llm_rows.packet_batch.blocks+0x13d4>
    1980:      	add	x14, x12, #0x18
    1984:      	ld1.s	{ v26 }[2], [x14]
    1988:      	tbnz	w13, #0x7, 0x18b4 <_llm_rows.packet_batch.blocks+0x13d8>
    198c:      	b	0x18bc <_llm_rows.packet_batch.blocks+0x13e0>
    1990:      	str	s29, [x11]
    1994:      	and	w12, w12, #0xff
    1998:      	tbz	w12, #0x1, 0x1900 <_llm_rows.packet_batch.blocks+0x1424>
    199c:      	add	x15, x11, #0x4
    19a0:      	st1.s	{ v29 }[1], [x15]
    19a4:      	ldr	q30, [x13, #0x10]
    19a8:      	ldr	q27, [x14, #0x10]
    19ac:      	tbz	w12, #0x2, 0x190c <_llm_rows.packet_batch.blocks+0x1430>
    19b0:      	add	x13, x11, #0x8
    19b4:      	st1.s	{ v29 }[2], [x13]
    19b8:      	tbz	w12, #0x3, 0x1910 <_llm_rows.packet_batch.blocks+0x1434>
    19bc:      	add	x13, x11, #0xc
    19c0:      	st1.s	{ v29 }[3], [x13]
    19c4:      	and.16b	v2, v0, v30
    19c8:      	fdiv.4s	v2, v2, v7
    19cc:      	and.16b	v16, v0, v27
    19d0:      	fmul.4s	v2, v2, v16
    19d4:      	fadd.4s	v26, v26, v2
    19d8:      	tbz	w12, #0x4, 0x1928 <_llm_rows.packet_batch.blocks+0x144c>
    19dc:      	str	s26, [x11, #0x10]
    19e0:      	tbz	w12, #0x5, 0x192c <_llm_rows.packet_batch.blocks+0x1450>
    19e4:      	add	x13, x11, #0x14
    19e8:      	st1.s	{ v26 }[1], [x13]
    19ec:      	tbz	w12, #0x6, 0x1930 <_llm_rows.packet_batch.blocks+0x1454>
    19f0:      	add	x13, x11, #0x18
    19f4:      	st1.s	{ v26 }[2], [x13]
    19f8:      	tbz	w12, #0x7, 0x1858 <_llm_rows.packet_batch.blocks+0x137c>
    19fc:      	add	x11, x11, #0x1c
    1a00:      	st1.s	{ v26 }[3], [x11]
    1a04:      	b	0x1858 <_llm_rows.packet_batch.blocks+0x137c>
    1a08:      	add	x9, x10, x9
    1a0c:      	fmov	w10, s28
    1a10:      	movi.2d	v0, #0000000000000000
    1a14:      	movi.2d	v1, #0000000000000000
    1a18:      	tbnz	w10, #0x0, 0x1d5c <_llm_rows.packet_batch.blocks+0x1880>
    1a1c:      	tbnz	w10, #0x1, 0x1d64 <_llm_rows.packet_batch.blocks+0x1888>
    1a20:      	tbnz	w10, #0x2, 0x1d70 <_llm_rows.packet_batch.blocks+0x1894>
    1a24:      	tbnz	w10, #0x3, 0x1d7c <_llm_rows.packet_batch.blocks+0x18a0>
    1a28:      	tbnz	w10, #0x4, 0x1d88 <_llm_rows.packet_batch.blocks+0x18ac>
    1a2c:      	tbnz	w10, #0x5, 0x1d94 <_llm_rows.packet_batch.blocks+0x18b8>
    1a30:      	tbnz	w10, #0x6, 0x1da0 <_llm_rows.packet_batch.blocks+0x18c4>
    1a34:      	tbz	w10, #0x7, 0x1a40 <_llm_rows.packet_batch.blocks+0x1564>
    1a38:      	add	x9, x9, #0x1c
    1a3c:      	ld1.s	{ v1 }[3], [x9]
    1a40:      	fdiv.4s	v2, v23, v7
    1a44:      	fdiv.4s	v3, v24, v7
    1a48:      	fmul.4s	v3, v3, v22
    1a4c:      	fmul.4s	v4, v2, v25
    1a50:      	fadd.4s	v2, v3, v0
    1a54:      	fadd.4s	v0, v4, v1
    1a58:      	b	0x1cb8 <_llm_rows.packet_batch.blocks+0x17dc>
    1a5c:      	ldr	s28, [x9]
    1a60:      	tbz	w11, #0x1, 0x8c4 <_llm_rows.packet_batch.blocks+0x3e8>
    1a64:      	add	x13, x9, #0x4
    1a68:      	ld1.s	{ v28 }[1], [x13]
    1a6c:      	tbz	w11, #0x2, 0x8c8 <_llm_rows.packet_batch.blocks+0x3ec>
    1a70:      	add	x13, x9, #0x8
    1a74:      	ld1.s	{ v28 }[2], [x13]
    1a78:      	tbz	w11, #0x3, 0x8cc <_llm_rows.packet_batch.blocks+0x3f0>
    1a7c:      	add	x13, x9, #0xc
    1a80:      	ld1.s	{ v28 }[3], [x13]
    1a84:      	tbz	w11, #0x4, 0x8d0 <_llm_rows.packet_batch.blocks+0x3f4>
    1a88:      	add	x13, x9, #0x10
    1a8c:      	ld1.s	{ v30 }[0], [x13]
    1a90:      	tbz	w11, #0x5, 0x8d4 <_llm_rows.packet_batch.blocks+0x3f8>
    1a94:      	add	x13, x9, #0x14
    1a98:      	ld1.s	{ v30 }[1], [x13]
    1a9c:      	tbz	w11, #0x6, 0x8d8 <_llm_rows.packet_batch.blocks+0x3fc>
    1aa0:      	add	x13, x9, #0x18
    1aa4:      	ld1.s	{ v30 }[2], [x13]
    1aa8:      	str	q16, [sp, #0x170]
    1aac:      	str	q23, [sp, #0x140]
    1ab0:      	tbnz	w11, #0x7, 0x8e4 <_llm_rows.packet_batch.blocks+0x408>
    1ab4:      	b	0x8ec <_llm_rows.packet_batch.blocks+0x410>
    1ab8:      	ldr	s22, [x12]
    1abc:      	ldr	w0, [sp, #0x158]
    1ac0:      	ldr	q31, [sp, #0x170]
    1ac4:      	tbz	w11, #0x1, 0x16a0 <_llm_rows.packet_batch.blocks+0x11c4>
    1ac8:      	add	x13, x12, #0x4
    1acc:      	ld1.s	{ v22 }[1], [x13]
    1ad0:      	tbz	w11, #0x2, 0x16a4 <_llm_rows.packet_batch.blocks+0x11c8>
    1ad4:      	add	x13, x12, #0x8
    1ad8:      	ld1.s	{ v22 }[2], [x13]
    1adc:      	tbz	w11, #0x3, 0x16a8 <_llm_rows.packet_batch.blocks+0x11cc>
    1ae0:      	add	x13, x12, #0xc
    1ae4:      	ld1.s	{ v22 }[3], [x13]
    1ae8:      	tbz	w11, #0x4, 0x16ac <_llm_rows.packet_batch.blocks+0x11d0>
    1aec:      	add	x13, x12, #0x10
    1af0:      	ld1.s	{ v25 }[0], [x13]
    1af4:      	tbz	w11, #0x5, 0x16b0 <_llm_rows.packet_batch.blocks+0x11d4>
    1af8:      	add	x13, x12, #0x14
    1afc:      	ld1.s	{ v25 }[1], [x13]
    1b00:      	tbz	w11, #0x6, 0x16b4 <_llm_rows.packet_batch.blocks+0x11d8>
    1b04:      	add	x13, x12, #0x18
    1b08:      	ld1.s	{ v25 }[2], [x13]
    1b0c:      	tbnz	w11, #0x7, 0x16b8 <_llm_rows.packet_batch.blocks+0x11dc>
    1b10:      	b	0x16c0 <_llm_rows.packet_batch.blocks+0x11e4>
    1b14:      	add	x9, x10, x9
    1b18:      	fmov	w10, s28
    1b1c:      	movi.2d	v3, #0000000000000000
    1b20:      	movi.2d	v4, #0000000000000000
    1b24:      	tbnz	w10, #0x0, 0x1db0 <_llm_rows.packet_batch.blocks+0x18d4>
    1b28:      	tbnz	w10, #0x1, 0x1db8 <_llm_rows.packet_batch.blocks+0x18dc>
    1b2c:      	tbnz	w10, #0x2, 0x1dc4 <_llm_rows.packet_batch.blocks+0x18e8>
    1b30:      	tbnz	w10, #0x3, 0x1dd0 <_llm_rows.packet_batch.blocks+0x18f4>
    1b34:      	tbnz	w10, #0x4, 0x1ddc <_llm_rows.packet_batch.blocks+0x1900>
    1b38:      	tbnz	w10, #0x5, 0x1de8 <_llm_rows.packet_batch.blocks+0x190c>
    1b3c:      	tbnz	w10, #0x6, 0x1df4 <_llm_rows.packet_batch.blocks+0x1918>
    1b40:      	tbz	w10, #0x7, 0x1b4c <_llm_rows.packet_batch.blocks+0x1670>
    1b44:      	add	x9, x9, #0x1c
    1b48:      	ld1.s	{ v4 }[3], [x9]
    1b4c:      	mov	x10, #0x0               ; =0
    1b50:      	ldr	x9, [sp, #0x190]
    1b54:      	add	x9, x27, x9
    1b58:      	ldp	q2, q5, [x9]
    1b5c:      	zip2.8b	v6, v29, v0
    1b60:      	ushll.4s	v6, v6, #0x0
    1b64:      	shl.4s	v6, v6, #0x1f
    1b68:      	cmlt.4s	v6, v6, #0
    1b6c:      	bit.16b	v5, v4, v6
    1b70:      	zip1.8b	v6, v29, v0
    1b74:      	ushll.4s	v6, v6, #0x0
    1b78:      	shl.4s	v6, v6, #0x1f
    1b7c:      	cmlt.4s	v6, v6, #0
    1b80:      	bit.16b	v2, v3, v6
    1b84:      	stp	q2, q5, [x9]
    1b88:      	dup.4s	v5, v26[0]
    1b8c:      	ldr	q2, [sp, #0xe0]
    1b90:      	fmov	x9, d2
    1b94:      	add	x9, x8, x9, lsl #2
    1b98:      	movi.2d	v6, #0000000000000000
    1b9c:      	movi.2d	v7, #0000000000000000
    1ba0:      	movi.2d	v16, #0000000000000000
    1ba4:      	movi.2d	v17, #0000000000000000
    1ba8:      	b	0x1bc8 <_llm_rows.packet_batch.blocks+0x16ec>
    1bac:      	add.2d	v7, v7, v19
    1bb0:      	add.2d	v16, v16, v20
    1bb4:      	add.2d	v17, v17, v18
    1bb8:      	add.2d	v6, v6, v21
    1bbc:      	fmov	x10, d6
    1bc0:      	cmp	x10, #0xc0
    1bc4:      	b.ge	0x1ca0 <_llm_rows.packet_batch.blocks+0x17c4>
    1bc8:      	fmov	w11, s8
    1bcc:      	lsl	x10, x10, #5
    1bd0:      	add	x12, x19, x10
    1bd4:      	ldp	q2, q26, [x12]
    1bd8:      	and.16b	v2, v1, v2
    1bdc:      	fdiv.4s	v2, v2, v5
    1be0:      	add	x12, x21, x10
    1be4:      	ldp	q29, q27, [x12]
    1be8:      	and.16b	v29, v1, v29
    1bec:      	fmul.4s	v2, v2, v29
    1bf0:      	add	x12, x27, x10
    1bf4:      	ldp	q30, q29, [x12]
    1bf8:      	and.16b	v30, v1, v30
    1bfc:      	fadd.4s	v30, v2, v30
    1c00:      	add	x10, x9, x10
    1c04:      	tbnz	w11, #0x0, 0x1c4c <_llm_rows.packet_batch.blocks+0x1770>
    1c08:      	and	w11, w11, #0xff
    1c0c:      	tbnz	w11, #0x1, 0x1c58 <_llm_rows.packet_batch.blocks+0x177c>
    1c10:      	tbnz	w11, #0x2, 0x1c64 <_llm_rows.packet_batch.blocks+0x1788>
    1c14:      	tbz	w11, #0x3, 0x1c20 <_llm_rows.packet_batch.blocks+0x1744>
    1c18:      	add	x12, x10, #0xc
    1c1c:      	st1.s	{ v30 }[3], [x12]
    1c20:      	and.16b	v2, v0, v26
    1c24:      	fdiv.4s	v2, v2, v5
    1c28:      	and.16b	v26, v0, v27
    1c2c:      	fmul.4s	v2, v2, v26
    1c30:      	and.16b	v26, v0, v29
    1c34:      	fadd.4s	v26, v2, v26
    1c38:      	tbnz	w11, #0x4, 0x1c74 <_llm_rows.packet_batch.blocks+0x1798>
    1c3c:      	tbnz	w11, #0x5, 0x1c7c <_llm_rows.packet_batch.blocks+0x17a0>
    1c40:      	tbnz	w11, #0x6, 0x1c88 <_llm_rows.packet_batch.blocks+0x17ac>
    1c44:      	tbz	w11, #0x7, 0x1bac <_llm_rows.packet_batch.blocks+0x16d0>
    1c48:      	b	0x1c94 <_llm_rows.packet_batch.blocks+0x17b8>
    1c4c:      	str	s30, [x10]
    1c50:      	and	w11, w11, #0xff
    1c54:      	tbz	w11, #0x1, 0x1c10 <_llm_rows.packet_batch.blocks+0x1734>
    1c58:      	add	x12, x10, #0x4
    1c5c:      	st1.s	{ v30 }[1], [x12]
    1c60:      	tbz	w11, #0x2, 0x1c14 <_llm_rows.packet_batch.blocks+0x1738>
    1c64:      	add	x12, x10, #0x8
    1c68:      	st1.s	{ v30 }[2], [x12]
    1c6c:      	tbnz	w11, #0x3, 0x1c18 <_llm_rows.packet_batch.blocks+0x173c>
    1c70:      	b	0x1c20 <_llm_rows.packet_batch.blocks+0x1744>
    1c74:      	str	s26, [x10, #0x10]
    1c78:      	tbz	w11, #0x5, 0x1c40 <_llm_rows.packet_batch.blocks+0x1764>
    1c7c:      	add	x12, x10, #0x14
    1c80:      	st1.s	{ v26 }[1], [x12]
    1c84:      	tbz	w11, #0x6, 0x1c44 <_llm_rows.packet_batch.blocks+0x1768>
    1c88:      	add	x12, x10, #0x18
    1c8c:      	st1.s	{ v26 }[2], [x12]
    1c90:      	tbz	w11, #0x7, 0x1bac <_llm_rows.packet_batch.blocks+0x16d0>
    1c94:      	add	x10, x10, #0x1c
    1c98:      	st1.s	{ v26 }[3], [x10]
    1c9c:      	b	0x1bac <_llm_rows.packet_batch.blocks+0x16d0>
    1ca0:      	fdiv.4s	v0, v24, v5
    1ca4:      	fdiv.4s	v1, v23, v5
    1ca8:      	fmul.4s	v1, v1, v25
    1cac:      	fmul.4s	v0, v0, v22
    1cb0:      	fadd.4s	v2, v0, v3
    1cb4:      	fadd.4s	v0, v1, v4
    1cb8:      	ldp	q1, q3, [sp, #0x110]
    1cbc:      	ldp	q5, q4, [sp, #0xf0]
    1cc0:      	stp	q3, q4, [sp, #0x1b0]
    1cc4:      	stp	q5, q1, [sp, #0x1d0]
    1cc8:      	and	x9, x16, #0x7
    1ccc:      	add	x10, sp, #0x1b0
    1cd0:      	ldr	x9, [x10, x9, lsl #3]
    1cd4:      	sub	x9, x9, x16
    1cd8:      	add	x8, x8, x9, lsl #2
    1cdc:      	fmov	w9, s28
    1ce0:      	tbnz	w9, #0x0, 0x1d04 <_llm_rows.packet_batch.blocks+0x1828>
    1ce4:      	tbnz	w9, #0x1, 0x1d0c <_llm_rows.packet_batch.blocks+0x1830>
    1ce8:      	tbnz	w9, #0x2, 0x1d18 <_llm_rows.packet_batch.blocks+0x183c>
    1cec:      	tbnz	w9, #0x3, 0x1d24 <_llm_rows.packet_batch.blocks+0x1848>
    1cf0:      	tbnz	w9, #0x4, 0x1d30 <_llm_rows.packet_batch.blocks+0x1854>
    1cf4:      	tbnz	w9, #0x5, 0x1d38 <_llm_rows.packet_batch.blocks+0x185c>
    1cf8:      	tbnz	w9, #0x6, 0x1d44 <_llm_rows.packet_batch.blocks+0x1868>
    1cfc:      	tbz	w9, #0x7, 0x57c <_llm_rows.packet_batch.blocks+0xa0>
    1d00:      	b	0x1d50 <_llm_rows.packet_batch.blocks+0x1874>
    1d04:      	str	s2, [x8]
    1d08:      	tbz	w9, #0x1, 0x1ce8 <_llm_rows.packet_batch.blocks+0x180c>
    1d0c:      	add	x10, x8, #0x4
    1d10:      	st1.s	{ v2 }[1], [x10]
    1d14:      	tbz	w9, #0x2, 0x1cec <_llm_rows.packet_batch.blocks+0x1810>
    1d18:      	add	x10, x8, #0x8
    1d1c:      	st1.s	{ v2 }[2], [x10]
    1d20:      	tbz	w9, #0x3, 0x1cf0 <_llm_rows.packet_batch.blocks+0x1814>
    1d24:      	add	x10, x8, #0xc
    1d28:      	st1.s	{ v2 }[3], [x10]
    1d2c:      	tbz	w9, #0x4, 0x1cf4 <_llm_rows.packet_batch.blocks+0x1818>
    1d30:      	str	s0, [x8, #0x10]
    1d34:      	tbz	w9, #0x5, 0x1cf8 <_llm_rows.packet_batch.blocks+0x181c>
    1d38:      	add	x10, x8, #0x14
    1d3c:      	st1.s	{ v0 }[1], [x10]
    1d40:      	tbz	w9, #0x6, 0x1cfc <_llm_rows.packet_batch.blocks+0x1820>
    1d44:      	add	x10, x8, #0x18
    1d48:      	st1.s	{ v0 }[2], [x10]
    1d4c:      	tbz	w9, #0x7, 0x57c <_llm_rows.packet_batch.blocks+0xa0>
    1d50:      	add	x8, x8, #0x1c
    1d54:      	st1.s	{ v0 }[3], [x8]
    1d58:      	b	0x57c <_llm_rows.packet_batch.blocks+0xa0>
    1d5c:      	ldr	s0, [x9]
    1d60:      	tbz	w10, #0x1, 0x1a20 <_llm_rows.packet_batch.blocks+0x1544>
    1d64:      	add	x11, x9, #0x4
    1d68:      	ld1.s	{ v0 }[1], [x11]
    1d6c:      	tbz	w10, #0x2, 0x1a24 <_llm_rows.packet_batch.blocks+0x1548>
    1d70:      	add	x11, x9, #0x8
    1d74:      	ld1.s	{ v0 }[2], [x11]
    1d78:      	tbz	w10, #0x3, 0x1a28 <_llm_rows.packet_batch.blocks+0x154c>
    1d7c:      	add	x11, x9, #0xc
    1d80:      	ld1.s	{ v0 }[3], [x11]
    1d84:      	tbz	w10, #0x4, 0x1a2c <_llm_rows.packet_batch.blocks+0x1550>
    1d88:      	add	x11, x9, #0x10
    1d8c:      	ld1.s	{ v1 }[0], [x11]
    1d90:      	tbz	w10, #0x5, 0x1a30 <_llm_rows.packet_batch.blocks+0x1554>
    1d94:      	add	x11, x9, #0x14
    1d98:      	ld1.s	{ v1 }[1], [x11]
    1d9c:      	tbz	w10, #0x6, 0x1a34 <_llm_rows.packet_batch.blocks+0x1558>
    1da0:      	add	x11, x9, #0x18
    1da4:      	ld1.s	{ v1 }[2], [x11]
    1da8:      	tbnz	w10, #0x7, 0x1a38 <_llm_rows.packet_batch.blocks+0x155c>
    1dac:      	b	0x1a40 <_llm_rows.packet_batch.blocks+0x1564>
    1db0:      	ldr	s3, [x9]
    1db4:      	tbz	w10, #0x1, 0x1b2c <_llm_rows.packet_batch.blocks+0x1650>
    1db8:      	add	x11, x9, #0x4
    1dbc:      	ld1.s	{ v3 }[1], [x11]
    1dc0:      	tbz	w10, #0x2, 0x1b30 <_llm_rows.packet_batch.blocks+0x1654>
    1dc4:      	add	x11, x9, #0x8
    1dc8:      	ld1.s	{ v3 }[2], [x11]
    1dcc:      	tbz	w10, #0x3, 0x1b34 <_llm_rows.packet_batch.blocks+0x1658>
    1dd0:      	add	x11, x9, #0xc
    1dd4:      	ld1.s	{ v3 }[3], [x11]
    1dd8:      	tbz	w10, #0x4, 0x1b38 <_llm_rows.packet_batch.blocks+0x165c>
    1ddc:      	add	x11, x9, #0x10
    1de0:      	ld1.s	{ v4 }[0], [x11]
    1de4:      	tbz	w10, #0x5, 0x1b3c <_llm_rows.packet_batch.blocks+0x1660>
    1de8:      	add	x11, x9, #0x14
    1dec:      	ld1.s	{ v4 }[1], [x11]
    1df0:      	tbz	w10, #0x6, 0x1b40 <_llm_rows.packet_batch.blocks+0x1664>
    1df4:      	add	x11, x9, #0x18
    1df8:      	ld1.s	{ v4 }[2], [x11]
    1dfc:      	tbnz	w10, #0x7, 0x1b44 <_llm_rows.packet_batch.blocks+0x1668>
    1e00:      	b	0x1b4c <_llm_rows.packet_batch.blocks+0x1670>
    1e04:      	add	sp, sp, #0x6, lsl #12   ; =0x6000
    1e08:      	add	sp, sp, #0x700
    1e0c:      	ldp	x29, x30, [sp, #0x90]
    1e10:      	ldp	x20, x19, [sp, #0x80]
    1e14:      	ldp	x22, x21, [sp, #0x70]
    1e18:      	ldp	x24, x23, [sp, #0x60]
    1e1c:      	ldp	x26, x25, [sp, #0x50]
    1e20:      	ldp	x28, x27, [sp, #0x40]
    1e24:      	ldp	d9, d8, [sp, #0x30]
    1e28:      	ldp	d11, d10, [sp, #0x20]
    1e2c:      	ldp	d13, d12, [sp, #0x10]
    1e30:      	ldp	d15, d14, [sp], #0xa0
    1e34:      	ret

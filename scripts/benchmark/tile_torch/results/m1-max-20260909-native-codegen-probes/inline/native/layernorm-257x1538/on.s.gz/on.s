
/private/tmp/luisa-packet-inline.UY1lIE/capture/layernorm-257x1538/on/object/tile_xir_w8_36332_1788935095212515_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x6, lsl #12   ; =0x6000
      2c:      	sub	sp, sp, #0x6d0
      30:      	str	x0, [sp, #0x10]
      34:      	str	w3, [sp, #0x28]
      38:      	cbz	w3, 0x21f8 <ltmp0+0x21f8>
      3c:      	mov	w12, #0x0               ; =0
      40:      	ldp	w9, w8, [x2, #0x2c]
      44:      	stp	w8, w9, [sp, #0x20]
      48:      	add	x26, sp, #0x4, lsl #12  ; =0x4000
      4c:      	add	x26, x26, #0xeb0
      50:      	ldp	w8, w9, [x2]
      54:      	add	x19, sp, #0x3, lsl #12  ; =0x3000
      58:      	add	x19, x19, #0x690
      5c:      	movi	d8, #0000000000000000
      60:      	add	x20, sp, #0x1, lsl #12  ; =0x1000
      64:      	add	x20, x20, #0xe70
      68:      	ldp	w10, w11, [x2, #0x8]
      6c:      	str	x2, [sp, #0x8]
      70:      	str	x11, [sp, #0x18]
      74:      	b	0xc0 <ltmp0+0xc0>
      78:      	ldr	x15, [sp, #0x38]
      7c:      	add	w8, w15, #0x1
      80:      	ldp	w11, w9, [sp, #0x20]
      84:      	cmp	w8, w9
      88:      	cset	w9, eq
      8c:      	csinc	w8, wzr, w15, eq
      90:      	ldp	w14, w13, [sp, #0x2c]
      94:      	cinc	w10, w14, eq
      98:      	cmp	w10, w11
      9c:      	cset	w11, eq
      a0:      	ands	w11, w9, w11
      a4:      	csel	w9, wzr, w10, ne
      a8:      	add	w10, w13, w11
      ac:      	ldr	w12, [sp, #0x34]
      b0:      	add	w12, w12, #0x1
      b4:      	ldr	w11, [sp, #0x28]
      b8:      	cmp	w12, w11
      bc:      	b.eq	0x21e4 <ltmp0+0x21e4>
      c0:      	str	w12, [sp, #0x34]
      c4:      	mov	x13, x10
      c8:      	mov	x14, x9
      cc:      	mov	x15, x8
      d0:      	ubfiz	x8, x8, #5, #32
      d4:      	ldr	x12, [sp, #0x18]
      d8:      	cmp	x8, x12
      dc:      	csel	x9, x8, xzr, ls
      e0:      	subs	x10, x12, x9
      e4:      	cmp	x10, #0x20
      e8:      	mov	w11, #0x20              ; =32
      ec:      	csel	x10, x10, x11, lo
      f0:      	cmp	x12, x9
      f4:      	ccmp	x8, x12, #0x2, hi
      f8:      	csel	x9, x10, xzr, ls
      fc:      	cmp	x9, #0x20
     100:      	stp	w14, w13, [sp, #0x2c]
     104:      	str	x15, [sp, #0x38]
     108:      	b.lo	0x5ec <ltmp0+0x5ec>
     10c:      	mov	x27, #0x0               ; =0
     110:      	ldr	x8, [sp, #0x10]
     114:      	mov	w12, #0x1804            ; =6148
     118:      	ldr	x28, [x8]
     11c:      	ldr	x13, [x8, #0x10]
     120:      	ldr	x23, [x8, #0x20]
     124:      	ldr	x14, [x8, #0x30]
     128:      	mov	w10, #0x1800            ; =6144
     12c:      	add	x8, x13, x10
     130:      	str	x8, [sp, #0x90]
     134:      	subs	x8, x23, x14
     138:      	mov	w9, #0x2007             ; =8199
     13c:      	movk	w9, #0x18, lsl #16
     140:      	ccmp	x8, x9, #0x0, hs
     144:      	cset	w8, hi
     148:      	subs	x9, x14, x23
     14c:      	lsr	x9, x9, #3
     150:      	mov	w11, #0x300             ; =768
     154:      	ccmp	x9, x11, #0x0, hs
     158:      	csinc	w8, w8, wzr, ls
     15c:      	str	w8, [sp, #0x88]
     160:      	add	x8, x23, x10
     164:      	str	x8, [sp, #0x70]
     168:      	lsl	w8, w15, #2
     16c:      	str	x8, [sp, #0x60]
     170:      	and	x8, x15, #0x7ffffff
     174:      	mov	w9, #0x6020             ; =24608
     178:      	str	x14, [sp, #0xb0]
     17c:      	umaddl	x21, w8, w9, x14
     180:      	str	x13, [sp, #0xa0]
     184:      	add	x8, x13, x12
     188:      	str	x8, [sp, #0x50]
     18c:      	mov	w9, #0x1808             ; =6152
     190:      	b	0x1b4 <ltmp0+0x1b4>
     194:      	ldr	q0, [sp, #0x170]
     198:      	ldr	x8, [sp, #0xb0]
     19c:      	str	d1, [x8, x24]
     1a0:      	add	x27, x27, #0x1
     1a4:      	mov	w9, #0x1808             ; =6152
     1a8:      	add	x21, x21, x9
     1ac:      	cmp	x27, #0x4
     1b0:      	b.eq	0x78 <ltmp0+0x78>
     1b4:      	stp	q17, q0, [sp, #0x160]
     1b8:      	ldr	x8, [sp, #0x60]
     1bc:      	add	w8, w27, w8
     1c0:      	and	x24, x8, #0x1fffffff
     1c4:      	umull	x22, w24, w9
     1c8:      	umaddl	x1, w24, w9, x28
     1cc:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     1d0:      	add	x0, x0, #0xeb0
     1d4:      	mov	w2, #0x1800             ; =6144
     1d8:      	mov	w25, #0x1808            ; =6152
     1dc:      	bl	0x1dc <ltmp0+0x1dc>
     1e0:      	mov	x8, #0x0                ; =0
     1e4:      	mov	w9, #0x1800             ; =6144
     1e8:      	umaddl	x24, w24, w25, x9
     1ec:      	add	x9, x28, x24
     1f0:      	ldr	s18, [x9], #0x4
     1f4:      	ld1.s	{ v18 }[1], [x9]
     1f8:      	ldr	q0, [sp, #0x170]
     1fc:      	mov.d	v18[1], v0[1]
     200:      	str	q0, [sp, #0x66c0]
     204:      	str	q18, [sp, #0x66b0]
     208:      	ldr	q0, [sp, #0x4ec0]
     20c:      	ldr	q4, [sp, #0x4eb0]
     210:      	ldr	q3, [sp, #0x4ee0]
     214:      	ldr	q2, [sp, #0x4ed0]
     218:      	ldr	q1, [sp, #0x4f00]
     21c:      	ldr	q5, [sp, #0x4ef0]
     220:      	ldr	q7, [sp, #0x4f20]
     224:      	ldr	q6, [sp, #0x4f10]
     228:      	add	x9, x26, x8, lsl #5
     22c:      	ldp	q16, q17, [x9, #0x80]
     230:      	fadd.4s	v0, v0, v17
     234:      	fadd.4s	v4, v4, v16
     238:      	ldp	q16, q17, [x9, #0xa0]
     23c:      	fadd.4s	v3, v3, v17
     240:      	fadd.4s	v2, v2, v16
     244:      	ldp	q16, q17, [x9, #0xc0]
     248:      	fadd.4s	v1, v1, v17
     24c:      	fadd.4s	v5, v5, v16
     250:      	ldp	q16, q17, [x9, #0xe0]
     254:      	fadd.4s	v7, v7, v17
     258:      	fadd.4s	v6, v6, v16
     25c:      	add	x8, x8, #0x4
     260:      	cmp	x8, #0xbc
     264:      	b.lo	0x228 <ltmp0+0x228>
     268:      	mov	x8, #0x0                ; =0
     26c:      	fadd.4s	v16, v18, v4
     270:      	mov.d	v16[1], v4[1]
     274:      	fadd.4s	v0, v3, v0
     278:      	fadd.4s	v2, v2, v16
     27c:      	fadd.4s	v2, v5, v2
     280:      	fadd.4s	v0, v1, v0
     284:      	fadd.4s	v0, v7, v0
     288:      	fadd.4s	v1, v6, v2
     28c:      	rev64.4s	v2, v1
     290:      	rev64.4s	v3, v0
     294:      	fadd.4s	v0, v0, v3
     298:      	fadd.4s	v1, v1, v2
     29c:      	dup.4s	v2, v1[2]
     2a0:      	dup.4s	v3, v0[2]
     2a4:      	fadd.4s	v0, v0, v3
     2a8:      	fadd.4s	v1, v1, v2
     2ac:      	fadd.4s	v0, v1, v0
     2b0:      	fadd	s0, s0, s8
     2b4:      	mov	w9, #0x4000             ; =16384
     2b8:      	movk	w9, #0x44c0, lsl #16
     2bc:      	fmov	s1, w9
     2c0:      	fdiv	s0, s0, s1
     2c4:      	dup.4s	v1, v0[0]
     2c8:      	lsl	x9, x8, #5
     2cc:      	add	x10, x26, x9
     2d0:      	ldp	q3, q2, [x10]
     2d4:      	fsub.4s	v3, v3, v1
     2d8:      	fsub.4s	v2, v2, v1
     2dc:      	add	x9, x19, x9
     2e0:      	stp	q3, q2, [x9]
     2e4:      	add	x8, x8, #0x1
     2e8:      	cmp	x8, #0xc0
     2ec:      	b.ne	0x2c8 <ltmp0+0x2c8>
     2f0:      	mov	x8, #0x0                ; =0
     2f4:      	dup.4s	v0, v0[0]
     2f8:      	str	q18, [sp, #0x170]
     2fc:      	fsub.4s	v1, v18, v0
     300:      	ldr	q0, [sp, #0x4e90]
     304:      	str	q1, [sp, #0x140]
     308:      	mov.d	v1[1], v0[1]
     30c:      	str	q1, [sp, #0x150]
     310:      	str	q1, [sp, #0x4e90]
     314:      	ldr	q0, [sp, #0x3690]
     318:      	ldr	q1, [sp, #0x36a0]
     31c:      	fmul.4s	v2, v1, v1
     320:      	fmul.4s	v3, v0, v0
     324:      	ldr	q0, [sp, #0x36b0]
     328:      	ldr	q1, [sp, #0x36c0]
     32c:      	fmul.4s	v5, v1, v1
     330:      	fmul.4s	v4, v0, v0
     334:      	ldr	q0, [sp, #0x36d0]
     338:      	ldr	q1, [sp, #0x36e0]
     33c:      	fmul.4s	v6, v1, v1
     340:      	fmul.4s	v7, v0, v0
     344:      	ldr	q0, [sp, #0x36f0]
     348:      	ldr	q1, [sp, #0x3700]
     34c:      	fmul.4s	v17, v1, v1
     350:      	fmul.4s	v16, v0, v0
     354:      	add	x9, x19, x8, lsl #5
     358:      	ldp	q1, q0, [x9, #0x80]
     35c:      	fmul.4s	v1, v1, v1
     360:      	fmul.4s	v0, v0, v0
     364:      	fadd.4s	v2, v2, v0
     368:      	fadd.4s	v3, v3, v1
     36c:      	ldp	q1, q0, [x9, #0xa0]
     370:      	fmul.4s	v1, v1, v1
     374:      	fmul.4s	v0, v0, v0
     378:      	fadd.4s	v5, v5, v0
     37c:      	fadd.4s	v4, v4, v1
     380:      	ldp	q1, q0, [x9, #0xc0]
     384:      	fmul.4s	v1, v1, v1
     388:      	fmul.4s	v0, v0, v0
     38c:      	fadd.4s	v6, v6, v0
     390:      	fadd.4s	v7, v7, v1
     394:      	ldp	q1, q0, [x9, #0xe0]
     398:      	fmul.4s	v1, v1, v1
     39c:      	fmul.4s	v0, v0, v0
     3a0:      	fadd.4s	v17, v17, v0
     3a4:      	fadd.4s	v16, v16, v1
     3a8:      	add	x8, x8, #0x4
     3ac:      	cmp	x8, #0xbc
     3b0:      	b.lo	0x354 <ltmp0+0x354>
     3b4:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     3b8:      	add	x0, x0, #0xe70
     3bc:      	ldr	x1, [sp, #0xa0]
     3c0:      	mov	w2, #0x1800             ; =6144
     3c4:      	stp	q5, q2, [sp, #0xd0]
     3c8:      	str	q3, [sp, #0xc0]
     3cc:      	stp	q7, q4, [sp, #0xf0]
     3d0:      	stp	q6, q16, [sp, #0x120]
     3d4:      	str	q17, [sp, #0x110]
     3d8:      	bl	0x3d8 <ltmp0+0x3d8>
     3dc:      	ldr	q0, [sp, #0x140]
     3e0:      	fmul.4s	v0, v0, v0
     3e4:      	ldp	q1, q2, [sp, #0xc0]
     3e8:      	fadd.4s	v0, v0, v1
     3ec:      	mov.d	v0[1], v1[1]
     3f0:      	ldr	q1, [sp, #0xe0]
     3f4:      	fadd.4s	v1, v2, v1
     3f8:      	ldp	q2, q3, [sp, #0xf0]
     3fc:      	fadd.4s	v0, v3, v0
     400:      	fadd.4s	v0, v2, v0
     404:      	ldp	q2, q3, [sp, #0x110]
     408:      	fadd.4s	v1, v3, v1
     40c:      	fadd.4s	v1, v2, v1
     410:      	ldr	q2, [sp, #0x130]
     414:      	fadd.4s	v0, v2, v0
     418:      	rev64.4s	v2, v0
     41c:      	rev64.4s	v3, v1
     420:      	fadd.4s	v1, v1, v3
     424:      	fadd.4s	v0, v0, v2
     428:      	dup.4s	v2, v0[2]
     42c:      	dup.4s	v3, v1[2]
     430:      	fadd.4s	v1, v1, v3
     434:      	fadd.4s	v0, v0, v2
     438:      	fadd.4s	v0, v0, v1
     43c:      	fadd	s0, s0, s8
     440:      	mov	w8, #0x4000             ; =16384
     444:      	movk	w8, #0x44c0, lsl #16
     448:      	fmov	s1, w8
     44c:      	ldr	x8, [sp, #0x90]
     450:      	ldr	s17, [x8]
     454:      	ldr	x8, [sp, #0x50]
     458:      	ld1.s	{ v17 }[1], [x8]
     45c:      	ldr	q2, [sp, #0x160]
     460:      	mov.d	v17[1], v2[1]
     464:      	fdiv	s0, s0, s1
     468:      	str	q0, [sp, #0x3680]
     46c:      	str	q17, [sp, #0x3670]
     470:      	mov	w8, #0xc5ac             ; =50604
     474:      	movk	w8, #0x3727, lsl #16
     478:      	fmov	s1, w8
     47c:      	fadd	s0, s0, s1
     480:      	fsqrt	s18, s0
     484:      	ldr	w8, [sp, #0x88]
     488:      	tbz	w8, #0x0, 0x53c <ltmp0+0x53c>
     48c:      	mov	x9, #0x0                ; =0
     490:      	dup.4s	v0, v18[0]
     494:      	ldr	x8, [sp, #0xb0]
     498:      	add	x8, x8, x22
     49c:      	movi.2d	v1, #0000000000000000
     4a0:      	movi.2d	v2, #0000000000000000
     4a4:      	movi.2d	v3, #0000000000000000
     4a8:      	movi.2d	v4, #0000000000000000
     4ac:      	mov	w11, #0x1               ; =1
     4b0:      	lsl	x9, x9, #5
     4b4:      	add	x10, x19, x9
     4b8:      	ldp	q6, q5, [x10]
     4bc:      	fdiv.4s	v6, v6, v0
     4c0:      	fdiv.4s	v5, v5, v0
     4c4:      	add	x9, x20, x9
     4c8:      	ldp	q7, q16, [x9]
     4cc:      	fmul.4s	v5, v5, v16
     4d0:      	fmul.4s	v6, v6, v7
     4d4:      	fmov	x9, d1
     4d8:      	lsl	x9, x9, #5
     4dc:      	add	x10, x23, x9
     4e0:      	ldp	q16, q7, [x10]
     4e4:      	fadd.4s	v6, v6, v16
     4e8:      	fadd.4s	v5, v5, v7
     4ec:      	add	x9, x8, x9
     4f0:      	stp	q6, q5, [x9]
     4f4:      	dup.2d	v5, x11
     4f8:      	add.2d	v3, v3, v5
     4fc:      	add.2d	v2, v2, v5
     500:      	add.2d	v4, v4, v5
     504:      	add.2d	v1, v1, v5
     508:      	fmov	x9, d1
     50c:      	cmp	x9, #0xc0
     510:      	b.lt	0x4b0 <ltmp0+0x4b0>
     514:      	dup.4s	v0, v18[0]
     518:      	ldr	q1, [sp, #0x150]
     51c:      	fdiv.4s	v0, v1, v0
     520:      	fmul.4s	v0, v0, v17
     524:      	ldr	x9, [sp, #0x70]
     528:      	add	x8, x9, #0x4
     52c:      	ldr	s1, [x9]
     530:      	ld1.s	{ v1 }[1], [x8]
     534:      	fadd.4s	v1, v0, v1
     538:      	b	0x194 <ltmp0+0x194>
     53c:      	str	q17, [sp, #0x160]
     540:      	add	x0, sp, #0x650
     544:      	mov	x1, x23
     548:      	mov	w2, #0x1800             ; =6144
     54c:      	str	q18, [sp, #0x140]
     550:      	bl	0x550 <ltmp0+0x550>
     554:      	ldr	q6, [sp, #0x140]
     558:      	mov	x8, #0x0                ; =0
     55c:      	mov	w9, #0x1804             ; =6148
     560:      	add	x9, x23, x9
     564:      	ldr	x10, [sp, #0x70]
     568:      	ldr	s0, [x10]
     56c:      	ld1.s	{ v0 }[1], [x9]
     570:      	ldr	q1, [sp, #0x40]
     574:      	mov.d	v0[1], v1[1]
     578:      	str	q0, [sp, #0x1e60]
     57c:      	str	q0, [sp, #0x1e50]
     580:      	dup.4s	v1, v6[0]
     584:      	add	x11, sp, #0x650
     588:      	lsl	x9, x8, #5
     58c:      	add	x10, x19, x9
     590:      	ldp	q3, q2, [x10]
     594:      	fdiv.4s	v3, v3, v1
     598:      	fdiv.4s	v2, v2, v1
     59c:      	add	x10, x20, x9
     5a0:      	ldp	q4, q5, [x10]
     5a4:      	fmul.4s	v2, v2, v5
     5a8:      	fmul.4s	v3, v3, v4
     5ac:      	add	x10, x11, x9
     5b0:      	ldp	q5, q4, [x10]
     5b4:      	fadd.4s	v3, v3, v5
     5b8:      	fadd.4s	v2, v2, v4
     5bc:      	add	x9, x21, x9
     5c0:      	stp	q3, q2, [x9]
     5c4:      	add	x8, x8, #0x1
     5c8:      	cmp	x8, #0xc0
     5cc:      	b.ne	0x588 <ltmp0+0x588>
     5d0:      	dup.4s	v1, v6[0]
     5d4:      	ldp	q2, q17, [sp, #0x150]
     5d8:      	fdiv.4s	v1, v2, v1
     5dc:      	fmul.4s	v1, v1, v17
     5e0:      	fadd.4s	v1, v1, v0
     5e4:      	str	q0, [sp, #0x40]
     5e8:      	b	0x194 <ltmp0+0x194>
     5ec:      	lsr	x8, x9, #3
     5f0:      	str	x8, [sp, #0xc0]
     5f4:      	str	x9, [sp, #0x50]
     5f8:      	cmp	x9, #0x8
     5fc:      	b.hs	0x75c <ltmp0+0x75c>
     600:      	ldr	x8, [sp, #0x50]
     604:      	and	w8, w8, #0x7
     608:      	cbz	w8, 0x78 <ltmp0+0x78>
     60c:      	mov	w15, #0x1808            ; =6152
     610:      	dup.4s	v1, w8
     614:      	adrp	x8, 0x0 <ltmp0>
     618:      	ldr	q2, [x8]
     61c:      	adrp	x8, 0x0 <ltmp0>
     620:      	ldr	q0, [x8]
     624:      	cmhi.4s	v0, v1, v0
     628:      	cmhi.4s	v1, v1, v2
     62c:      	uzp1.8h	v3, v1, v0
     630:      	umaxv.8h	h2, v3
     634:      	fmov	w8, s2
     638:      	tbz	w8, #0x0, 0x78 <ltmp0+0x78>
     63c:      	mov	x11, #0x0               ; =0
     640:      	ldr	x8, [sp, #0x10]
     644:      	ldr	x9, [x8]
     648:      	ldr	x12, [x8, #0x10]
     64c:      	ldr	x10, [x8, #0x20]
     650:      	ldr	x8, [x8, #0x30]
     654:      	adrp	x13, 0x0 <ltmp0>
     658:      	ldr	q2, [x13]
     65c:      	and.16b	v2, v3, v2
     660:      	addv.8h	h23, v2
     664:      	ldr	x13, [sp, #0x38]
     668:      	ubfiz	w13, w13, #2, #27
     66c:      	ldr	x14, [sp, #0xc0]
     670:      	orr	w13, w13, w14
     674:      	fmov	w14, s23
     678:      	and	w24, w14, #0xff
     67c:      	dup.4s	v4, w13
     680:      	and.16b	v7, v1, v4
     684:      	and.16b	v6, v0, v4
     688:      	ushll2.2d	v4, v6, #0x0
     68c:      	ushll2.2d	v5, v7, #0x0
     690:      	ushll.2d	v6, v6, #0x0
     694:      	ushll.2d	v17, v7, #0x0
     698:      	fmov	x13, d17
     69c:      	umaddl	x13, w13, w15, x9
     6a0:      	b	0x6c4 <ltmp0+0x6c4>
     6a4:      	add	x14, x26, x11, lsl #5
     6a8:      	ldp	q18, q19, [x14]
     6ac:      	bif.16b	v16, v19, v0
     6b0:      	bif.16b	v7, v18, v1
     6b4:      	stp	q7, q16, [x14]
     6b8:      	add	x11, x11, #0x1
     6bc:      	cmp	x11, #0xc0
     6c0:      	b.eq	0xc0c <ltmp0+0xc0c>
     6c4:      	fmov	w15, s23
     6c8:      	add	x14, x13, x11, lsl #5
     6cc:      	movi.2d	v7, #0000000000000000
     6d0:      	movi.2d	v16, #0000000000000000
     6d4:      	tbnz	w15, #0x0, 0x6fc <ltmp0+0x6fc>
     6d8:      	and	w15, w15, #0xff
     6dc:      	tbnz	w15, #0x1, 0x708 <ltmp0+0x708>
     6e0:      	tbnz	w15, #0x2, 0x714 <ltmp0+0x714>
     6e4:      	tbnz	w15, #0x3, 0x720 <ltmp0+0x720>
     6e8:      	tbnz	w15, #0x4, 0x72c <ltmp0+0x72c>
     6ec:      	tbnz	w15, #0x5, 0x738 <ltmp0+0x738>
     6f0:      	tbnz	w15, #0x6, 0x744 <ltmp0+0x744>
     6f4:      	tbz	w15, #0x7, 0x6a4 <ltmp0+0x6a4>
     6f8:      	b	0x750 <ltmp0+0x750>
     6fc:      	ldr	s7, [x14]
     700:      	and	w15, w15, #0xff
     704:      	tbz	w15, #0x1, 0x6e0 <ltmp0+0x6e0>
     708:      	add	x16, x14, #0x4
     70c:      	ld1.s	{ v7 }[1], [x16]
     710:      	tbz	w15, #0x2, 0x6e4 <ltmp0+0x6e4>
     714:      	add	x16, x14, #0x8
     718:      	ld1.s	{ v7 }[2], [x16]
     71c:      	tbz	w15, #0x3, 0x6e8 <ltmp0+0x6e8>
     720:      	add	x16, x14, #0xc
     724:      	ld1.s	{ v7 }[3], [x16]
     728:      	tbz	w15, #0x4, 0x6ec <ltmp0+0x6ec>
     72c:      	add	x16, x14, #0x10
     730:      	ld1.s	{ v16 }[0], [x16]
     734:      	tbz	w15, #0x5, 0x6f0 <ltmp0+0x6f0>
     738:      	add	x16, x14, #0x14
     73c:      	ld1.s	{ v16 }[1], [x16]
     740:      	tbz	w15, #0x6, 0x6f4 <ltmp0+0x6f4>
     744:      	add	x16, x14, #0x18
     748:      	ld1.s	{ v16 }[2], [x16]
     74c:      	tbz	w15, #0x7, 0x6a4 <ltmp0+0x6a4>
     750:      	add	x14, x14, #0x1c
     754:      	ld1.s	{ v16 }[3], [x14]
     758:      	b	0x6a4 <ltmp0+0x6a4>
     75c:      	mov	x25, #0x0               ; =0
     760:      	ldr	x8, [sp, #0x10]
     764:      	ldr	x9, [x8]
     768:      	str	x9, [sp, #0xb0]
     76c:      	ldr	x9, [x8, #0x10]
     770:      	ldr	x23, [x8, #0x20]
     774:      	ldr	x12, [x8, #0x30]
     778:      	mov	w10, #0x1800            ; =6144
     77c:      	str	x9, [sp, #0xa0]
     780:      	add	x8, x9, x10
     784:      	str	x8, [sp, #0x90]
     788:      	subs	x8, x23, x12
     78c:      	mov	w9, #0x2007             ; =8199
     790:      	movk	w9, #0x18, lsl #16
     794:      	ccmp	x8, x9, #0x0, hs
     798:      	cset	w8, hi
     79c:      	subs	x9, x12, x23
     7a0:      	lsr	x9, x9, #3
     7a4:      	mov	w11, #0x300             ; =768
     7a8:      	ccmp	x9, x11, #0x0, hs
     7ac:      	csinc	w8, w8, wzr, ls
     7b0:      	str	w8, [sp, #0x88]
     7b4:      	add	x8, x23, x10
     7b8:      	str	x8, [sp, #0x70]
     7bc:      	ldr	x8, [sp, #0x38]
     7c0:      	lsl	w9, w8, #2
     7c4:      	str	x9, [sp, #0x60]
     7c8:      	and	x8, x8, #0x7ffffff
     7cc:      	mov	w9, #0x6020             ; =24608
     7d0:      	str	x12, [sp, #0xd0]
     7d4:      	umaddl	x21, w8, w9, x12
     7d8:      	mov	w9, #0x1808             ; =6152
     7dc:      	b	0x814 <ltmp0+0x814>
     7e0:      	dup.4s	v1, v6[0]
     7e4:      	ldp	q2, q3, [sp, #0x160]
     7e8:      	fdiv.4s	v1, v3, v1
     7ec:      	fmul.4s	v1, v1, v2
     7f0:      	fadd.4s	v0, v1, v0
     7f4:      	ldr	x8, [sp, #0xd0]
     7f8:      	str	d0, [x8, x24]
     7fc:      	add	x25, x25, #0x1
     800:      	mov	w9, #0x1808             ; =6152
     804:      	add	x21, x21, x9
     808:      	ldr	x8, [sp, #0xc0]
     80c:      	cmp	x25, x8
     810:      	b.eq	0x600 <ltmp0+0x600>
     814:      	ldr	x8, [sp, #0x60]
     818:      	add	w8, w25, w8
     81c:      	and	x24, x8, #0x1fffffff
     820:      	umull	x27, w24, w9
     824:      	ldr	x22, [sp, #0xb0]
     828:      	umaddl	x1, w24, w9, x22
     82c:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     830:      	add	x0, x0, #0xeb0
     834:      	mov	w2, #0x1800             ; =6144
     838:      	mov	w28, #0x1808            ; =6152
     83c:      	bl	0x83c <ltmp0+0x83c>
     840:      	mov	x8, #0x0                ; =0
     844:      	mov	w9, #0x1800             ; =6144
     848:      	umaddl	x24, w24, w28, x9
     84c:      	add	x9, x22, x24
     850:      	ldr	s0, [x9], #0x4
     854:      	ld1.s	{ v0 }[1], [x9]
     858:      	str	q0, [sp, #0x66b0]
     85c:      	ldr	q1, [sp, #0x4ec0]
     860:      	ldr	q5, [sp, #0x4eb0]
     864:      	ldr	q4, [sp, #0x4ee0]
     868:      	ldr	q3, [sp, #0x4ed0]
     86c:      	ldr	q2, [sp, #0x4f00]
     870:      	ldr	q6, [sp, #0x4ef0]
     874:      	ldr	q16, [sp, #0x4f20]
     878:      	ldr	q7, [sp, #0x4f10]
     87c:      	add	x9, x26, x8, lsl #5
     880:      	ldp	q17, q18, [x9, #0x80]
     884:      	fadd.4s	v1, v1, v18
     888:      	fadd.4s	v5, v5, v17
     88c:      	ldp	q17, q18, [x9, #0xa0]
     890:      	fadd.4s	v4, v4, v18
     894:      	fadd.4s	v3, v3, v17
     898:      	ldp	q17, q18, [x9, #0xc0]
     89c:      	fadd.4s	v2, v2, v18
     8a0:      	fadd.4s	v6, v6, v17
     8a4:      	ldp	q17, q18, [x9, #0xe0]
     8a8:      	fadd.4s	v16, v16, v18
     8ac:      	fadd.4s	v7, v7, v17
     8b0:      	add	x8, x8, #0x4
     8b4:      	cmp	x8, #0xbc
     8b8:      	b.lo	0x87c <ltmp0+0x87c>
     8bc:      	mov	x8, #0x0                ; =0
     8c0:      	fadd.4s	v17, v0, v5
     8c4:      	mov.d	v17[1], v5[1]
     8c8:      	fadd.4s	v1, v4, v1
     8cc:      	fadd.4s	v3, v3, v17
     8d0:      	fadd.4s	v3, v6, v3
     8d4:      	fadd.4s	v1, v2, v1
     8d8:      	fadd.4s	v1, v16, v1
     8dc:      	fadd.4s	v2, v7, v3
     8e0:      	rev64.4s	v3, v2
     8e4:      	rev64.4s	v4, v1
     8e8:      	fadd.4s	v1, v1, v4
     8ec:      	fadd.4s	v2, v2, v3
     8f0:      	dup.4s	v3, v2[2]
     8f4:      	dup.4s	v4, v1[2]
     8f8:      	fadd.4s	v1, v1, v4
     8fc:      	fadd.4s	v2, v2, v3
     900:      	fadd.4s	v1, v2, v1
     904:      	fadd	s1, s1, s8
     908:      	mov	w9, #0x4000             ; =16384
     90c:      	movk	w9, #0x44c0, lsl #16
     910:      	fmov	s2, w9
     914:      	fdiv	s1, s1, s2
     918:      	dup.4s	v2, v1[0]
     91c:      	mov	w28, #0x1804            ; =6148
     920:      	lsl	x9, x8, #5
     924:      	add	x10, x26, x9
     928:      	ldp	q4, q3, [x10]
     92c:      	fsub.4s	v4, v4, v2
     930:      	fsub.4s	v3, v3, v2
     934:      	add	x9, x19, x9
     938:      	stp	q4, q3, [x9]
     93c:      	add	x8, x8, #0x1
     940:      	cmp	x8, #0xc0
     944:      	b.ne	0x920 <ltmp0+0x920>
     948:      	mov	x8, #0x0                ; =0
     94c:      	dup.4s	v1, v1[0]
     950:      	fsub.4s	v1, v0, v1
     954:      	ldr	q0, [sp, #0x4e90]
     958:      	str	q1, [sp, #0x160]
     95c:      	mov.d	v1[1], v0[1]
     960:      	str	q1, [sp, #0x170]
     964:      	str	q1, [sp, #0x4e90]
     968:      	ldr	q0, [sp, #0x3690]
     96c:      	ldr	q1, [sp, #0x36a0]
     970:      	fmul.4s	v2, v1, v1
     974:      	fmul.4s	v3, v0, v0
     978:      	ldr	q0, [sp, #0x36b0]
     97c:      	ldr	q1, [sp, #0x36c0]
     980:      	fmul.4s	v5, v1, v1
     984:      	fmul.4s	v4, v0, v0
     988:      	ldr	q0, [sp, #0x36d0]
     98c:      	ldr	q1, [sp, #0x36e0]
     990:      	fmul.4s	v6, v1, v1
     994:      	fmul.4s	v7, v0, v0
     998:      	ldr	q0, [sp, #0x36f0]
     99c:      	ldr	q1, [sp, #0x3700]
     9a0:      	fmul.4s	v17, v1, v1
     9a4:      	fmul.4s	v16, v0, v0
     9a8:      	add	x9, x19, x8, lsl #5
     9ac:      	ldp	q1, q0, [x9, #0x80]
     9b0:      	fmul.4s	v1, v1, v1
     9b4:      	fmul.4s	v0, v0, v0
     9b8:      	fadd.4s	v2, v2, v0
     9bc:      	fadd.4s	v3, v3, v1
     9c0:      	ldp	q1, q0, [x9, #0xa0]
     9c4:      	fmul.4s	v1, v1, v1
     9c8:      	fmul.4s	v0, v0, v0
     9cc:      	fadd.4s	v5, v5, v0
     9d0:      	fadd.4s	v4, v4, v1
     9d4:      	ldp	q1, q0, [x9, #0xc0]
     9d8:      	fmul.4s	v1, v1, v1
     9dc:      	fmul.4s	v0, v0, v0
     9e0:      	fadd.4s	v6, v6, v0
     9e4:      	fadd.4s	v7, v7, v1
     9e8:      	ldp	q1, q0, [x9, #0xe0]
     9ec:      	fmul.4s	v1, v1, v1
     9f0:      	fmul.4s	v0, v0, v0
     9f4:      	fadd.4s	v17, v17, v0
     9f8:      	fadd.4s	v16, v16, v1
     9fc:      	add	x8, x8, #0x4
     a00:      	cmp	x8, #0xbc
     a04:      	b.lo	0x9a8 <ltmp0+0x9a8>
     a08:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     a0c:      	add	x0, x0, #0xe70
     a10:      	ldr	x22, [sp, #0xa0]
     a14:      	mov	x1, x22
     a18:      	mov	w2, #0x1800             ; =6144
     a1c:      	stp	q5, q2, [sp, #0xf0]
     a20:      	str	q3, [sp, #0xe0]
     a24:      	stp	q7, q4, [sp, #0x110]
     a28:      	stp	q6, q16, [sp, #0x140]
     a2c:      	str	q17, [sp, #0x130]
     a30:      	bl	0xa30 <ltmp0+0xa30>
     a34:      	ldr	q0, [sp, #0x160]
     a38:      	fmul.4s	v0, v0, v0
     a3c:      	ldp	q1, q2, [sp, #0xe0]
     a40:      	fadd.4s	v0, v0, v1
     a44:      	mov.d	v0[1], v1[1]
     a48:      	ldr	q1, [sp, #0x100]
     a4c:      	fadd.4s	v1, v2, v1
     a50:      	ldp	q2, q3, [sp, #0x110]
     a54:      	fadd.4s	v0, v3, v0
     a58:      	fadd.4s	v0, v2, v0
     a5c:      	ldp	q2, q3, [sp, #0x130]
     a60:      	fadd.4s	v1, v3, v1
     a64:      	fadd.4s	v1, v2, v1
     a68:      	ldr	q2, [sp, #0x150]
     a6c:      	fadd.4s	v0, v2, v0
     a70:      	rev64.4s	v2, v0
     a74:      	rev64.4s	v3, v1
     a78:      	fadd.4s	v1, v1, v3
     a7c:      	fadd.4s	v0, v0, v2
     a80:      	dup.4s	v2, v0[2]
     a84:      	dup.4s	v3, v1[2]
     a88:      	fadd.4s	v1, v1, v3
     a8c:      	fadd.4s	v0, v0, v2
     a90:      	fadd.4s	v0, v0, v1
     a94:      	fadd	s0, s0, s8
     a98:      	mov	w8, #0x4000             ; =16384
     a9c:      	movk	w8, #0x44c0, lsl #16
     aa0:      	fmov	s1, w8
     aa4:      	fdiv	s0, s0, s1
     aa8:      	add	x8, x22, x28
     aac:      	ldr	x9, [sp, #0x90]
     ab0:      	ldr	s17, [x9]
     ab4:      	ld1.s	{ v17 }[1], [x8]
     ab8:      	str	q17, [sp, #0x3670]
     abc:      	mov	w8, #0xc5ac             ; =50604
     ac0:      	movk	w8, #0x3727, lsl #16
     ac4:      	fmov	s1, w8
     ac8:      	fadd	s0, s0, s1
     acc:      	fsqrt	s18, s0
     ad0:      	ldr	w8, [sp, #0x88]
     ad4:      	tbz	w8, #0x0, 0xb88 <ltmp0+0xb88>
     ad8:      	mov	x9, #0x0                ; =0
     adc:      	dup.4s	v0, v18[0]
     ae0:      	ldr	x8, [sp, #0xd0]
     ae4:      	add	x8, x8, x27
     ae8:      	movi.2d	v1, #0000000000000000
     aec:      	movi.2d	v2, #0000000000000000
     af0:      	movi.2d	v3, #0000000000000000
     af4:      	movi.2d	v4, #0000000000000000
     af8:      	mov	w11, #0x1               ; =1
     afc:      	lsl	x9, x9, #5
     b00:      	add	x10, x19, x9
     b04:      	ldp	q6, q5, [x10]
     b08:      	fdiv.4s	v6, v6, v0
     b0c:      	fdiv.4s	v5, v5, v0
     b10:      	add	x9, x20, x9
     b14:      	ldp	q7, q16, [x9]
     b18:      	fmul.4s	v5, v5, v16
     b1c:      	fmul.4s	v6, v6, v7
     b20:      	fmov	x9, d1
     b24:      	lsl	x9, x9, #5
     b28:      	add	x10, x23, x9
     b2c:      	ldp	q16, q7, [x10]
     b30:      	fadd.4s	v6, v6, v16
     b34:      	fadd.4s	v5, v5, v7
     b38:      	add	x9, x8, x9
     b3c:      	stp	q6, q5, [x9]
     b40:      	dup.2d	v5, x11
     b44:      	add.2d	v3, v3, v5
     b48:      	add.2d	v2, v2, v5
     b4c:      	add.2d	v4, v4, v5
     b50:      	add.2d	v1, v1, v5
     b54:      	fmov	x9, d1
     b58:      	cmp	x9, #0xc0
     b5c:      	b.lt	0xafc <ltmp0+0xafc>
     b60:      	dup.4s	v0, v18[0]
     b64:      	ldr	q1, [sp, #0x170]
     b68:      	fdiv.4s	v0, v1, v0
     b6c:      	fmul.4s	v0, v0, v17
     b70:      	ldr	x9, [sp, #0x70]
     b74:      	add	x8, x9, #0x4
     b78:      	ldr	s1, [x9]
     b7c:      	ld1.s	{ v1 }[1], [x8]
     b80:      	fadd.4s	v0, v0, v1
     b84:      	b	0x7f4 <ltmp0+0x7f4>
     b88:      	stp	q18, q17, [sp, #0x150]
     b8c:      	add	x0, sp, #0x650
     b90:      	mov	x1, x23
     b94:      	mov	w2, #0x1800             ; =6144
     b98:      	bl	0xb98 <ltmp0+0xb98>
     b9c:      	ldr	q6, [sp, #0x150]
     ba0:      	mov	x8, #0x0                ; =0
     ba4:      	add	x9, x23, x28
     ba8:      	ldr	x10, [sp, #0x70]
     bac:      	ldr	s0, [x10]
     bb0:      	ld1.s	{ v0 }[1], [x9]
     bb4:      	str	q0, [sp, #0x1e50]
     bb8:      	dup.4s	v1, v6[0]
     bbc:      	add	x11, sp, #0x650
     bc0:      	lsl	x9, x8, #5
     bc4:      	add	x10, x19, x9
     bc8:      	ldp	q3, q2, [x10]
     bcc:      	fdiv.4s	v3, v3, v1
     bd0:      	fdiv.4s	v2, v2, v1
     bd4:      	add	x10, x20, x9
     bd8:      	ldp	q4, q5, [x10]
     bdc:      	fmul.4s	v2, v2, v5
     be0:      	fmul.4s	v3, v3, v4
     be4:      	add	x10, x11, x9
     be8:      	ldp	q5, q4, [x10]
     bec:      	fadd.4s	v3, v3, v5
     bf0:      	fadd.4s	v2, v2, v4
     bf4:      	add	x9, x21, x9
     bf8:      	stp	q3, q2, [x9]
     bfc:      	add	x8, x8, #0x1
     c00:      	cmp	x8, #0xc0
     c04:      	b.ne	0xbc0 <ltmp0+0xbc0>
     c08:      	b	0x7e0 <ltmp0+0x7e0>
     c0c:      	xtn.8b	v18, v3
     c10:      	sshll.2d	v19, v1, #0x0
     c14:      	adrp	x11, 0x0 <ltmp0>
     c18:      	ldr	q3, [x11]
     c1c:      	and.16b	v16, v19, v3
     c20:      	movi	d2, #0x0000000000ffff
     c24:      	and.8b	v7, v18, v2
     c28:      	adrp	x11, 0x0 <ltmp0>
     c2c:      	ldr	d3, [x11]
     c30:      	str	q18, [sp, #0x150]
     c34:      	and.8b	v3, v18, v3
     c38:      	addv.8b	b3, v3
     c3c:      	fmov	w11, s3
     c40:      	umaxv.8b	b3, v7
     c44:      	fmov	w13, s3
     c48:      	rbit	w14, w11
     c4c:      	clz	w14, w14
     c50:      	tst	w13, #0x1
     c54:      	csel	w15, w14, wzr, ne
     c58:      	mov	w13, #0x600             ; =1536
     c5c:      	dup.2d	v21, x13
     c60:      	orr.16b	v2, v16, v21
     c64:      	mov	w13, #0x602             ; =1538
     c68:      	dup.2s	v20, w13
     c6c:      	xtn.2s	v22, v17
     c70:      	str	q2, [sp, #0xd0]
     c74:      	umlal.2d	v2, v22, v20
     c78:      	mov	b3, v7[0]
     c7c:      	mov.b	v3[4], v7[1]
     c80:      	ushll.2d	v3, v3, #0x0
     c84:      	shl.2d	v3, v3, #0x3f
     c88:      	cmlt.2d	v3, v3, #0
     c8c:      	str	q2, [sp, #0x130]
     c90:      	and.16b	v3, v3, v2
     c94:      	movi.2d	v2, #0000000000000000
     c98:      	str	q2, [sp, #0x630]
     c9c:      	str	q2, [sp, #0x620]
     ca0:      	str	q2, [sp, #0x610]
     ca4:      	str	q3, [sp, #0x600]
     ca8:      	and	x13, x15, #0x7
     cac:      	add	x14, sp, #0x600
     cb0:      	ldr	x13, [x14, x13, lsl #3]
     cb4:      	sub	x13, x13, x15
     cb8:      	add	x9, x9, x13, lsl #2
     cbc:      	movi.2d	v28, #0000000000000000
     cc0:      	movi.2d	v30, #0000000000000000
     cc4:      	tbnz	w11, #0x0, 0x1e34 <ltmp0+0x1e34>
     cc8:      	mov	w25, #0x4               ; =4
     ccc:      	tbnz	w11, #0x1, 0x1e40 <ltmp0+0x1e40>
     cd0:      	tbnz	w11, #0x2, 0x1e4c <ltmp0+0x1e4c>
     cd4:      	tbnz	w11, #0x3, 0x1e58 <ltmp0+0x1e58>
     cd8:      	tbnz	w11, #0x4, 0x1e64 <ltmp0+0x1e64>
     cdc:      	tbnz	w11, #0x5, 0x1e70 <ltmp0+0x1e70>
     ce0:      	tbnz	w11, #0x6, 0x1e7c <ltmp0+0x1e7c>
     ce4:      	str	q16, [sp, #0x160]
     ce8:      	str	q23, [sp, #0x140]
     cec:      	tbz	w11, #0x7, 0xcf8 <ltmp0+0xcf8>
     cf0:      	add	x9, x9, #0x1c
     cf4:      	ld1.s	{ v30 }[3], [x9]
     cf8:      	sshll.2d	v25, v0, #0x0
     cfc:      	sshll2.2d	v23, v1, #0x0
     d00:      	sshll2.2d	v24, v0, #0x0
     d04:      	adrp	x9, 0x0 <ltmp0>
     d08:      	ldr	q3, [x9]
     d0c:      	and.16b	v2, v24, v3
     d10:      	adrp	x9, 0x0 <ltmp0>
     d14:      	ldr	q3, [x9]
     d18:      	and.16b	v3, v23, v3
     d1c:      	adrp	x9, 0x0 <ltmp0>
     d20:      	ldr	q18, [x9]
     d24:      	and.16b	v16, v25, v18
     d28:      	adrp	x9, 0x0 <ltmp0>
     d2c:      	ldr	q26, [x9]
     d30:      	and.16b	v26, v24, v26
     d34:      	adrp	x9, 0x0 <ltmp0>
     d38:      	ldr	q27, [x9]
     d3c:      	and.16b	v27, v23, v27
     d40:      	adrp	x9, 0x0 <ltmp0>
     d44:      	ldr	q29, [x9]
     d48:      	and.16b	v25, v25, v29
     d4c:      	adrp	x9, 0x0 <ltmp0>
     d50:      	ldr	q29, [x9]
     d54:      	and.16b	v19, v19, v29
     d58:      	stp	q16, q3, [sp, #0x40]
     d5c:      	orr.16b	v16, v16, v21
     d60:      	orr.16b	v17, v3, v21
     d64:      	stp	q2, q17, [sp, #0x90]
     d68:      	orr.16b	v3, v2, v21
     d6c:      	umull.2d	v2, v22, v20
     d70:      	str	q2, [sp, #0xf0]
     d74:      	xtn.2s	v5, v5
     d78:      	xtn.2s	v6, v6
     d7c:      	xtn.2s	v4, v4
     d80:      	stp	q16, q3, [sp, #0xb0]
     d84:      	mov.16b	v2, v3
     d88:      	umlal.2d	v2, v4, v20
     d8c:      	str	q2, [sp, #0x120]
     d90:      	mov.16b	v2, v17
     d94:      	umlal.2d	v2, v5, v20
     d98:      	str	q2, [sp, #0x110]
     d9c:      	mov.16b	v2, v16
     da0:      	umlal.2d	v2, v6, v20
     da4:      	str	q2, [sp, #0x100]
     da8:      	sshll.2d	v4, v1, #0x0
     dac:      	sshll.2d	v5, v0, #0x0
     db0:      	str	q19, [sp, #0x5c0]
     db4:      	str	q27, [sp, #0x5d0]
     db8:      	str	q25, [sp, #0x5e0]
     dbc:      	str	q26, [sp, #0x5f0]
     dc0:      	and	x9, x15, #0x7
     dc4:      	add	x13, sp, #0x5c0
     dc8:      	ldr	x9, [x13, x9, lsl #3]
     dcc:      	orr	x9, x9, #0x1800
     dd0:      	str	x15, [sp, #0xe0]
     dd4:      	sub	x9, x9, x15, lsl #2
     dd8:      	tst	w11, #0xff
     ddc:      	csel	x9, xzr, x9, eq
     de0:      	mov	x28, x9
     de4:      	add	x9, x26, x9
     de8:      	ldp	q6, q20, [x9]
     dec:      	zip2.8b	v21, v7, v0
     df0:      	ushll.4s	v21, v21, #0x0
     df4:      	shl.4s	v21, v21, #0x1f
     df8:      	cmlt.4s	v21, v21, #0
     dfc:      	stp	q30, q28, [sp, #0x60]
     e00:      	bit.16b	v20, v30, v21
     e04:      	str	q7, [sp, #0x170]
     e08:      	zip1.8b	v21, v7, v0
     e0c:      	ushll.4s	v21, v21, #0x0
     e10:      	shl.4s	v21, v21, #0x1f
     e14:      	cmlt.4s	v21, v21, #0
     e18:      	bit.16b	v6, v28, v21
     e1c:      	stp	q6, q20, [x9]
     e20:      	fmov	x14, d19
     e24:      	dup.2d	v6, x25
     e28:      	and.16b	v26, v24, v6
     e2c:      	and.16b	v12, v23, v6
     e30:      	and.16b	v13, v5, v6
     e34:      	and.16b	v14, v4, v6
     e38:      	fmov	x9, d14
     e3c:      	ldr	q4, [sp, #0x4f10]
     e40:      	ldr	q5, [sp, #0x4f20]
     e44:      	and.16b	v5, v0, v5
     e48:      	and.16b	v4, v1, v4
     e4c:      	ldr	q6, [sp, #0x4ef0]
     e50:      	ldr	q19, [sp, #0x4f00]
     e54:      	and.16b	v19, v0, v19
     e58:      	and.16b	v6, v1, v6
     e5c:      	ldr	q21, [sp, #0x4ed0]
     e60:      	ldr	q20, [sp, #0x4ee0]
     e64:      	and.16b	v20, v0, v20
     e68:      	and.16b	v21, v1, v21
     e6c:      	add	x11, x26, x14
     e70:      	ldp	q25, q22, [x11]
     e74:      	and.16b	v22, v0, v22
     e78:      	mov	x11, x9
     e7c:      	and.16b	v25, v1, v25
     e80:      	mov.16b	v29, v14
     e84:      	mov.16b	v10, v12
     e88:      	mov.16b	v15, v13
     e8c:      	mov.16b	v11, v26
     e90:      	sshll.2d	v16, v1, #0x0
     e94:      	sshll.2d	v30, v0, #0x0
     e98:      	add	x11, x26, x11, lsl #5
     e9c:      	ldp	q9, q27, [x11]
     ea0:      	fadd.4s	v9, v25, v9
     ea4:      	fadd.4s	v27, v22, v27
     ea8:      	ldp	q7, q31, [x11, #0x20]
     eac:      	fadd.4s	v7, v21, v7
     eb0:      	fadd.4s	v31, v20, v31
     eb4:      	ldp	q17, q28, [x11, #0x40]
     eb8:      	fadd.4s	v17, v6, v17
     ebc:      	fadd.4s	v28, v19, v28
     ec0:      	ldp	q18, q3, [x11, #0x60]
     ec4:      	fadd.4s	v18, v4, v18
     ec8:      	fadd.4s	v3, v5, v3
     ecc:      	dup.2d	v8, x25
     ed0:      	and.16b	v2, v24, v8
     ed4:      	add.2d	v11, v11, v2
     ed8:      	and.16b	v2, v23, v8
     edc:      	add.2d	v10, v10, v2
     ee0:      	and.16b	v2, v30, v8
     ee4:      	add.2d	v15, v15, v2
     ee8:      	and.16b	v2, v16, v8
     eec:      	add.2d	v29, v29, v2
     ef0:      	bit.16b	v22, v27, v0
     ef4:      	bit.16b	v25, v9, v1
     ef8:      	bit.16b	v20, v31, v0
     efc:      	bit.16b	v21, v7, v1
     f00:      	bit.16b	v19, v28, v0
     f04:      	bit.16b	v6, v17, v1
     f08:      	bit.16b	v5, v3, v0
     f0c:      	bit.16b	v4, v18, v1
     f10:      	fmov	x11, d29
     f14:      	cmp	x11, #0xc0
     f18:      	b.lt	0xe90 <ltmp0+0xe90>
     f1c:      	mov	x21, #0x0               ; =0
     f20:      	movi	d2, #0xffffffffffff0000
     f24:      	ldr	q28, [sp, #0x150]
     f28:      	and.8b	v16, v28, v2
     f2c:      	ldp	q30, q29, [sp, #0x60]
     f30:      	fadd.4s	v2, v30, v22
     f34:      	fadd.4s	v3, v29, v25
     f38:      	ldr	q25, [sp, #0x170]
     f3c:      	zip1.8b	v7, v25, v0
     f40:      	ushll.4s	v7, v7, #0x0
     f44:      	shl.4s	v7, v7, #0x1f
     f48:      	cmlt.4s	v7, v7, #0
     f4c:      	and.16b	v3, v7, v3
     f50:      	zip2.8b	v7, v25, v0
     f54:      	ushll.4s	v7, v7, #0x0
     f58:      	shl.4s	v7, v7, #0x1f
     f5c:      	cmlt.4s	v7, v7, #0
     f60:      	and.16b	v2, v7, v2
     f64:      	zip2.8b	v7, v16, v0
     f68:      	ushll.4s	v7, v7, #0x0
     f6c:      	shl.4s	v7, v7, #0x1f
     f70:      	cmlt.4s	v7, v7, #0
     f74:      	bit.16b	v2, v27, v7
     f78:      	str	d16, [sp, #0x88]
     f7c:      	zip1.8b	v7, v16, v0
     f80:      	ushll.4s	v7, v7, #0x0
     f84:      	shl.4s	v7, v7, #0x1f
     f88:      	cmlt.4s	v7, v7, #0
     f8c:      	bit.16b	v3, v9, v7
     f90:      	fadd.4s	v3, v21, v3
     f94:      	fadd.4s	v2, v20, v2
     f98:      	fadd.4s	v2, v19, v2
     f9c:      	fadd.4s	v3, v6, v3
     fa0:      	fadd.4s	v4, v4, v3
     fa4:      	fadd.4s	v5, v5, v2
     fa8:      	ldr	q2, [sp, #0x160]
     fac:      	ldp	q6, q3, [sp, #0x40]
     fb0:      	uzp1.4s	v3, v2, v3
     fb4:      	ldr	q2, [sp, #0x90]
     fb8:      	uzp1.4s	v6, v6, v2
     fbc:      	movi.4s	v7, #0x1
     fc0:      	eor.16b	v2, v3, v7
     fc4:      	mov.s	w15, v2[1]
     fc8:      	mov.s	w16, v2[2]
     fcc:      	eor.16b	v20, v6, v7
     fd0:      	mov.s	w0, v2[3]
     fd4:      	fmov	w11, s2
     fd8:      	add	x13, sp, #0x458
     fdc:      	bfxil	x13, x11, #0, #3
     fe0:      	str	d28, [sp, #0x458]
     fe4:      	ldrb	w17, [x13]
     fe8:      	and	x11, x11, #0x7
     fec:      	umov.b	w13, v28[0]
     ff0:      	str	q5, [sp, #0x530]
     ff4:      	str	q4, [sp, #0x520]
     ff8:      	add	x1, sp, #0x520
     ffc:      	ldr	s2, [x1, x11, lsl #2]
    1000:      	ands	w11, w13, #0x1
    1004:      	tst	w11, w17
    1008:      	movi	d22, #0000000000000000
    100c:      	fcsel	s17, s2, s22, ne
    1010:      	and	x1, x15, #0x7
    1014:      	add	x17, sp, #0x458
    1018:      	bfxil	x17, x15, #0, #3
    101c:      	ldrb	w15, [x17]
    1020:      	umov.b	w17, v28[1]
    1024:      	and	w15, w17, w15
    1028:      	str	q5, [sp, #0x510]
    102c:      	str	q4, [sp, #0x500]
    1030:      	add	x2, sp, #0x500
    1034:      	ldr	s2, [x2, x1, lsl #2]
    1038:      	tst	w15, #0x1
    103c:      	fcsel	s18, s2, s22, ne
    1040:      	and	x1, x16, #0x7
    1044:      	add	x2, sp, #0x458
    1048:      	bfxil	x2, x16, #0, #3
    104c:      	umov.b	w15, v28[2]
    1050:      	ldrb	w16, [x2]
    1054:      	and	w16, w15, w16
    1058:      	str	q5, [sp, #0x4f0]
    105c:      	str	q4, [sp, #0x4e0]
    1060:      	add	x2, sp, #0x4e0
    1064:      	ldr	s2, [x2, x1, lsl #2]
    1068:      	tst	w16, #0x1
    106c:      	fcsel	s19, s2, s22, ne
    1070:      	and	x1, x0, #0x7
    1074:      	add	x16, sp, #0x458
    1078:      	bfxil	x16, x0, #0, #3
    107c:      	ldrb	w0, [x16]
    1080:      	umov.b	w16, v28[3]
    1084:      	str	q5, [sp, #0x4d0]
    1088:      	str	q4, [sp, #0x4c0]
    108c:      	add	x2, sp, #0x4c0
    1090:      	ldr	s2, [x2, x1, lsl #2]
    1094:      	and	w0, w16, w0
    1098:      	tst	w0, #0x1
    109c:      	mov.s	w0, v20[1]
    10a0:      	mov.s	w1, v20[2]
    10a4:      	fcsel	s21, s2, s22, ne
    10a8:      	mov.s	w2, v20[3]
    10ac:      	fmov	w3, s20
    10b0:      	and	x5, x3, #0x7
    10b4:      	add	x4, sp, #0x458
    10b8:      	bfxil	x4, x3, #0, #3
    10bc:      	ldrb	w3, [x4]
    10c0:      	umov.b	w4, v28[4]
    10c4:      	and	w3, w4, w3
    10c8:      	str	q5, [sp, #0x5b0]
    10cc:      	str	q4, [sp, #0x5a0]
    10d0:      	add	x6, sp, #0x5a0
    10d4:      	ldr	s2, [x6, x5, lsl #2]
    10d8:      	tst	w3, #0x1
    10dc:      	fcsel	s2, s2, s22, ne
    10e0:      	and	x5, x0, #0x7
    10e4:      	add	x3, sp, #0x458
    10e8:      	bfxil	x3, x0, #0, #3
    10ec:      	ldrb	w0, [x3]
    10f0:      	umov.b	w3, v28[5]
    10f4:      	and	w0, w3, w0
    10f8:      	str	q5, [sp, #0x590]
    10fc:      	str	q4, [sp, #0x580]
    1100:      	add	x6, sp, #0x580
    1104:      	ldr	s7, [x6, x5, lsl #2]
    1108:      	tst	w0, #0x1
    110c:      	fcsel	s7, s7, s22, ne
    1110:      	and	x0, x1, #0x7
    1114:      	add	x5, sp, #0x458
    1118:      	bfxil	x5, x1, #0, #3
    111c:      	ldrb	w5, [x5]
    1120:      	umov.b	w1, v28[6]
    1124:      	and	w5, w1, w5
    1128:      	str	q5, [sp, #0x570]
    112c:      	str	q4, [sp, #0x560]
    1130:      	add	x6, sp, #0x560
    1134:      	ldr	s16, [x6, x0, lsl #2]
    1138:      	tst	w5, #0x1
    113c:      	fcsel	s16, s16, s22, ne
    1140:      	and	x0, x2, #0x7
    1144:      	add	x5, sp, #0x458
    1148:      	bfxil	x5, x2, #0, #3
    114c:      	umov.b	w2, v28[7]
    1150:      	ldrb	w5, [x5]
    1154:      	and	w5, w2, w5
    1158:      	str	q5, [sp, #0x550]
    115c:      	str	q4, [sp, #0x540]
    1160:      	add	x6, sp, #0x540
    1164:      	ldr	s20, [x6, x0, lsl #2]
    1168:      	tst	w5, #0x1
    116c:      	fcsel	s20, s20, s22, ne
    1170:      	mov.s	v2[1], v7[0]
    1174:      	mov.s	v2[2], v16[0]
    1178:      	mov.s	v2[3], v20[0]
    117c:      	mov.s	v17[1], v18[0]
    1180:      	mov.s	v17[2], v19[0]
    1184:      	mov.s	v17[3], v21[0]
    1188:      	fadd.4s	v4, v4, v17
    118c:      	fadd.4s	v2, v5, v2
    1190:      	movi.4s	v7, #0x2
    1194:      	eor.16b	v5, v6, v7
    1198:      	eor.16b	v3, v3, v7
    119c:      	fmov	w0, s3
    11a0:      	add	x5, sp, #0x458
    11a4:      	bfxil	x5, x0, #0, #3
    11a8:      	ldrb	w5, [x5]
    11ac:      	and	x0, x0, #0x7
    11b0:      	str	q2, [sp, #0x4b0]
    11b4:      	str	q4, [sp, #0x4a0]
    11b8:      	add	x6, sp, #0x4a0
    11bc:      	ldr	s3, [x6, x0, lsl #2]
    11c0:      	tst	w11, w5
    11c4:      	fcsel	s3, s3, s22, ne
    11c8:      	fmov	w11, s5
    11cc:      	and	x0, x11, #0x7
    11d0:      	add	x5, sp, #0x458
    11d4:      	bfxil	x5, x11, #0, #3
    11d8:      	ldrb	w11, [x5]
    11dc:      	and	w11, w4, w11
    11e0:      	str	q2, [sp, #0x490]
    11e4:      	str	q4, [sp, #0x480]
    11e8:      	add	x5, sp, #0x480
    11ec:      	ldr	s5, [x5, x0, lsl #2]
    11f0:      	tst	w11, #0x1
    11f4:      	fcsel	s5, s5, s22, ne
    11f8:      	fadd.4s	v2, v2, v5
    11fc:      	and	w0, w13, w4
    1200:      	tst	w0, #0x1
    1204:      	fcsel	s2, s2, s22, ne
    1208:      	ands	w11, w13, #0x1
    120c:      	fadd.4s	v3, v4, v3
    1210:      	fadd	s2, s3, s2
    1214:      	fcsel	s3, s2, s22, ne
    1218:      	tst	w0, #0x1
    121c:      	and	w5, w17, w13
    1220:      	fcsel	s4, s2, s22, ne
    1224:      	tst	w5, #0x1
    1228:      	and	w6, w15, w13
    122c:      	fcsel	s5, s2, s22, ne
    1230:      	tst	w6, #0x1
    1234:      	and	w22, w16, w13
    1238:      	fcsel	s6, s2, s22, ne
    123c:      	tst	w22, #0x1
    1240:      	fcsel	s7, s2, s22, ne
    1244:      	and	w23, w3, w13
    1248:      	tst	w23, #0x1
    124c:      	fcsel	s16, s2, s22, ne
    1250:      	and	w30, w1, w13
    1254:      	tst	w30, #0x1
    1258:      	fcsel	s17, s2, s22, ne
    125c:      	and	w7, w2, w13
    1260:      	tst	w7, #0x1
    1264:      	fcsel	s2, s2, s22, ne
    1268:      	mov.s	v3[1], v5[0]
    126c:      	mov.s	v3[2], v6[0]
    1270:      	mov.s	v3[3], v7[0]
    1274:      	mov.s	v4[1], v16[0]
    1278:      	mov.s	v4[2], v17[0]
    127c:      	mov.s	v4[3], v2[0]
    1280:      	rbit	w24, w24
    1284:      	clz	w24, w24
    1288:      	str	q4, [sp, #0x470]
    128c:      	str	q3, [sp, #0x460]
    1290:      	str	x24, [sp, #0x90]
    1294:      	and	x24, x24, #0x7
    1298:      	add	x27, sp, #0x460
    129c:      	ldr	s2, [x27, x24, lsl #2]
    12a0:      	fadd	s2, s2, s22
    12a4:      	mov	w24, #0x4000            ; =16384
    12a8:      	movk	w24, #0x44c0, lsl #16
    12ac:      	fmov	s3, w24
    12b0:      	fdiv	s2, s2, s3
    12b4:      	dup.4s	v3, v2[0]
    12b8:      	mov	w24, #0x1               ; =1
    12bc:      	dup.2d	v2, x24
    12c0:      	ushll2.2d	v4, v0, #0x0
    12c4:      	and.16b	v18, v4, v2
    12c8:      	ushll2.2d	v4, v1, #0x0
    12cc:      	and.16b	v19, v4, v2
    12d0:      	ushll.2d	v4, v0, #0x0
    12d4:      	and.16b	v20, v4, v2
    12d8:      	ushll.2d	v4, v1, #0x0
    12dc:      	and.16b	v21, v4, v2
    12e0:      	movi.2d	v4, #0000000000000000
    12e4:      	movi.2d	v5, #0000000000000000
    12e8:      	movi.2d	v6, #0000000000000000
    12ec:      	movi.2d	v17, #0000000000000000
    12f0:      	lsl	x21, x21, #5
    12f4:      	add	x24, x26, x21
    12f8:      	ldp	q7, q2, [x24]
    12fc:      	fsub.4s	v7, v7, v3
    1300:      	fsub.4s	v2, v2, v3
    1304:      	add	x21, x19, x21
    1308:      	ldp	q16, q22, [x21]
    130c:      	bif.16b	v2, v22, v0
    1310:      	bif.16b	v7, v16, v1
    1314:      	stp	q7, q2, [x21]
    1318:      	add.2d	v5, v5, v19
    131c:      	add.2d	v6, v6, v20
    1320:      	add.2d	v17, v17, v18
    1324:      	add.2d	v4, v4, v21
    1328:      	fmov	x21, d4
    132c:      	cmp	x21, #0xc0
    1330:      	b.lt	0x12f0 <ltmp0+0x12f0>
    1334:      	fsub.4s	v5, v29, v3
    1338:      	fsub.4s	v6, v30, v3
    133c:      	add	x21, x19, x28
    1340:      	ldp	q2, q3, [x21]
    1344:      	zip2.8b	v4, v25, v0
    1348:      	ushll.4s	v4, v4, #0x0
    134c:      	shl.4s	v4, v4, #0x1f
    1350:      	cmlt.4s	v4, v4, #0
    1354:      	stp	q6, q5, [sp, #0x60]
    1358:      	bit.16b	v3, v6, v4
    135c:      	zip1.8b	v4, v25, v0
    1360:      	ushll.4s	v4, v4, #0x0
    1364:      	shl.4s	v4, v4, #0x1f
    1368:      	cmlt.4s	v4, v4, #0
    136c:      	bit.16b	v2, v5, v4
    1370:      	stp	q2, q3, [x21]
    1374:      	ldr	q2, [sp, #0x3700]
    1378:      	ldr	q3, [sp, #0x36f0]
    137c:      	fmul.4s	v3, v3, v3
    1380:      	fmul.4s	v2, v2, v2
    1384:      	and.16b	v30, v0, v2
    1388:      	and.16b	v31, v1, v3
    138c:      	ldr	q2, [sp, #0x36e0]
    1390:      	ldr	q3, [sp, #0x36d0]
    1394:      	fmul.4s	v3, v3, v3
    1398:      	fmul.4s	v2, v2, v2
    139c:      	and.16b	v17, v0, v2
    13a0:      	and.16b	v10, v1, v3
    13a4:      	ldr	q2, [sp, #0x36c0]
    13a8:      	ldr	q3, [sp, #0x36b0]
    13ac:      	fmul.4s	v3, v3, v3
    13b0:      	fmul.4s	v2, v2, v2
    13b4:      	and.16b	v4, v0, v2
    13b8:      	and.16b	v5, v1, v3
    13bc:      	add	x14, x19, x14
    13c0:      	ldp	q3, q2, [x14]
    13c4:      	fmul.4s	v6, v3, v3
    13c8:      	fmul.4s	v2, v2, v2
    13cc:      	and.16b	v3, v0, v2
    13d0:      	and.16b	v6, v1, v6
    13d4:      	sshll.2d	v2, v1, #0x0
    13d8:      	sshll.2d	v7, v0, #0x0
    13dc:      	add	x9, x19, x9, lsl #5
    13e0:      	ldp	q22, q16, [x9]
    13e4:      	and.16b	v22, v1, v22
    13e8:      	and.16b	v16, v0, v16
    13ec:      	fmul.4s	v16, v16, v16
    13f0:      	fmul.4s	v22, v22, v22
    13f4:      	fadd.4s	v22, v6, v22
    13f8:      	fadd.4s	v25, v3, v16
    13fc:      	ldp	q27, q16, [x9, #0x20]
    1400:      	and.16b	v27, v1, v27
    1404:      	and.16b	v16, v0, v16
    1408:      	fmul.4s	v16, v16, v16
    140c:      	fmul.4s	v27, v27, v27
    1410:      	fadd.4s	v27, v5, v27
    1414:      	fadd.4s	v16, v4, v16
    1418:      	ldp	q8, q28, [x9, #0x40]
    141c:      	and.16b	v8, v1, v8
    1420:      	and.16b	v28, v0, v28
    1424:      	fmul.4s	v28, v28, v28
    1428:      	fmul.4s	v8, v8, v8
    142c:      	fadd.4s	v8, v10, v8
    1430:      	fadd.4s	v28, v17, v28
    1434:      	ldp	q29, q11, [x9, #0x60]
    1438:      	and.16b	v29, v1, v29
    143c:      	and.16b	v11, v0, v11
    1440:      	fmul.4s	v11, v11, v11
    1444:      	fmul.4s	v29, v29, v29
    1448:      	fadd.4s	v29, v31, v29
    144c:      	fadd.4s	v11, v30, v11
    1450:      	dup.2d	v15, x25
    1454:      	and.16b	v9, v24, v15
    1458:      	add.2d	v26, v26, v9
    145c:      	and.16b	v9, v23, v15
    1460:      	add.2d	v12, v12, v9
    1464:      	and.16b	v7, v7, v15
    1468:      	add.2d	v13, v13, v7
    146c:      	and.16b	v2, v2, v15
    1470:      	add.2d	v14, v14, v2
    1474:      	bit.16b	v3, v25, v0
    1478:      	bit.16b	v6, v22, v1
    147c:      	bit.16b	v4, v16, v0
    1480:      	bit.16b	v5, v27, v1
    1484:      	bit.16b	v17, v28, v0
    1488:      	bit.16b	v10, v8, v1
    148c:      	bit.16b	v30, v11, v0
    1490:      	bit.16b	v31, v29, v1
    1494:      	fmov	x9, d14
    1498:      	cmp	x9, #0xc0
    149c:      	b.lt	0x13d4 <ltmp0+0x13d4>
    14a0:      	mov	x9, #0x0                ; =0
    14a4:      	movi.2d	v23, #0000000000000000
    14a8:      	movi.2d	v24, #0000000000000000
    14ac:      	movi.2d	v11, #0000000000000000
    14b0:      	movi.2d	v12, #0000000000000000
    14b4:      	movi	d8, #0000000000000000
    14b8:      	ldr	q9, [sp, #0x140]
    14bc:      	ldr	q27, [sp, #0x170]
    14c0:      	b	0x14f4 <ltmp0+0x14f4>
    14c4:      	add	x9, x20, x9
    14c8:      	ldp	q2, q7, [x9]
    14cc:      	bit.16b	v7, v14, v0
    14d0:      	bit.16b	v2, v13, v1
    14d4:      	stp	q2, q7, [x9]
    14d8:      	add.2d	v24, v24, v19
    14dc:      	add.2d	v11, v11, v20
    14e0:      	add.2d	v12, v12, v18
    14e4:      	add.2d	v23, v23, v21
    14e8:      	fmov	x9, d23
    14ec:      	cmp	x9, #0xc0
    14f0:      	b.ge	0x1590 <ltmp0+0x1590>
    14f4:      	fmov	w21, s9
    14f8:      	lsl	x9, x9, #5
    14fc:      	add	x14, x12, x9
    1500:      	movi.2d	v13, #0000000000000000
    1504:      	movi.2d	v14, #0000000000000000
    1508:      	tbnz	w21, #0x0, 0x1530 <ltmp0+0x1530>
    150c:      	and	w21, w21, #0xff
    1510:      	tbnz	w21, #0x1, 0x153c <ltmp0+0x153c>
    1514:      	tbnz	w21, #0x2, 0x1548 <ltmp0+0x1548>
    1518:      	tbnz	w21, #0x3, 0x1554 <ltmp0+0x1554>
    151c:      	tbnz	w21, #0x4, 0x1560 <ltmp0+0x1560>
    1520:      	tbnz	w21, #0x5, 0x156c <ltmp0+0x156c>
    1524:      	tbnz	w21, #0x6, 0x1578 <ltmp0+0x1578>
    1528:      	tbz	w21, #0x7, 0x14c4 <ltmp0+0x14c4>
    152c:      	b	0x1584 <ltmp0+0x1584>
    1530:      	ldr	s13, [x14]
    1534:      	and	w21, w21, #0xff
    1538:      	tbz	w21, #0x1, 0x1514 <ltmp0+0x1514>
    153c:      	add	x24, x14, #0x4
    1540:      	ld1.s	{ v13 }[1], [x24]
    1544:      	tbz	w21, #0x2, 0x1518 <ltmp0+0x1518>
    1548:      	add	x24, x14, #0x8
    154c:      	ld1.s	{ v13 }[2], [x24]
    1550:      	tbz	w21, #0x3, 0x151c <ltmp0+0x151c>
    1554:      	add	x24, x14, #0xc
    1558:      	ld1.s	{ v13 }[3], [x24]
    155c:      	tbz	w21, #0x4, 0x1520 <ltmp0+0x1520>
    1560:      	add	x24, x14, #0x10
    1564:      	ld1.s	{ v14 }[0], [x24]
    1568:      	tbz	w21, #0x5, 0x1524 <ltmp0+0x1524>
    156c:      	add	x24, x14, #0x14
    1570:      	ld1.s	{ v14 }[1], [x24]
    1574:      	tbz	w21, #0x6, 0x1528 <ltmp0+0x1528>
    1578:      	add	x24, x14, #0x18
    157c:      	ld1.s	{ v14 }[2], [x24]
    1580:      	tbz	w21, #0x7, 0x14c4 <ltmp0+0x14c4>
    1584:      	add	x14, x14, #0x1c
    1588:      	ld1.s	{ v14 }[3], [x14]
    158c:      	b	0x14c4 <ltmp0+0x14c4>
    1590:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1594:      	ldr	q2, [x9]
    1598:      	and.16b	v12, v0, v2
    159c:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    15a0:      	ldr	q2, [x9]
    15a4:      	and.16b	v13, v1, v2
    15a8:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    15ac:      	ldr	q11, [x9]
    15b0:      	zip2.8b	v2, v27, v0
    15b4:      	ushll.4s	v2, v2, #0x0
    15b8:      	shl.4s	v2, v2, #0x1f
    15bc:      	cmlt.4s	v2, v2, #0
    15c0:      	ldp	q7, q16, [sp, #0x60]
    15c4:      	and.16b	v23, v2, v7
    15c8:      	zip1.8b	v7, v27, v0
    15cc:      	ushll.4s	v7, v7, #0x0
    15d0:      	shl.4s	v7, v7, #0x1f
    15d4:      	cmlt.4s	v7, v7, #0
    15d8:      	and.16b	v24, v7, v16
    15dc:      	fmul.4s	v16, v24, v24
    15e0:      	fmul.4s	v26, v23, v23
    15e4:      	fadd.4s	v3, v26, v3
    15e8:      	fadd.4s	v6, v16, v6
    15ec:      	and.16b	v6, v7, v6
    15f0:      	and.16b	v2, v2, v3
    15f4:      	ldr	d7, [sp, #0x88]
    15f8:      	zip2.8b	v3, v7, v0
    15fc:      	ushll.4s	v3, v3, #0x0
    1600:      	shl.4s	v3, v3, #0x1f
    1604:      	cmlt.4s	v3, v3, #0
    1608:      	bit.16b	v2, v25, v3
    160c:      	zip1.8b	v3, v7, v0
    1610:      	ushll.4s	v3, v3, #0x0
    1614:      	shl.4s	v3, v3, #0x1f
    1618:      	cmlt.4s	v3, v3, #0
    161c:      	bsl.16b	v3, v22, v6
    1620:      	fadd.4s	v3, v5, v3
    1624:      	fadd.4s	v2, v4, v2
    1628:      	fadd.4s	v2, v17, v2
    162c:      	fadd.4s	v3, v10, v3
    1630:      	fadd.4s	v3, v31, v3
    1634:      	fadd.4s	v4, v30, v2
    1638:      	fmov	w9, s13
    163c:      	add	x14, sp, #0x1c8
    1640:      	bfxil	x14, x9, #0, #3
    1644:      	ldr	q2, [sp, #0x150]
    1648:      	str	d2, [sp, #0x1c8]
    164c:      	ldrb	w14, [x14]
    1650:      	add	x21, sp, #0x430
    1654:      	orr	x9, x21, x9, lsl #2
    1658:      	str	q4, [sp, #0x440]
    165c:      	str	q3, [sp, #0x430]
    1660:      	ldr	s2, [x9]
    1664:      	tst	w11, w14
    1668:      	fcsel	s5, s2, s8, ne
    166c:      	mov.s	w9, v13[1]
    1670:      	add	x14, sp, #0x1c8
    1674:      	bfxil	x14, x9, #0, #3
    1678:      	ldrb	w9, [x14]
    167c:      	and	w9, w17, w9
    1680:      	str	q3, [sp, #0x410]
    1684:      	ldr	s2, [sp, #0x410]
    1688:      	tst	w9, #0x1
    168c:      	mov.s	w9, v13[2]
    1690:      	fcsel	s6, s2, s8, ne
    1694:      	add	x14, sp, #0x1c8
    1698:      	bfxil	x14, x9, #0, #3
    169c:      	add	x21, sp, #0x3f0
    16a0:      	orr	x9, x21, x9, lsl #2
    16a4:      	ldrb	w14, [x14]
    16a8:      	and	w14, w15, w14
    16ac:      	stp	q3, q4, [sp, #0x3f0]
    16b0:      	ldr	s2, [x9]
    16b4:      	tst	w14, #0x1
    16b8:      	mov.s	w9, v13[3]
    16bc:      	fcsel	s17, s2, s8, ne
    16c0:      	add	x14, sp, #0x1c8
    16c4:      	bfxil	x14, x9, #0, #3
    16c8:      	add	x21, sp, #0x3d0
    16cc:      	orr	x9, x21, x9, lsl #2
    16d0:      	ldrb	w14, [x14]
    16d4:      	and	w14, w16, w14
    16d8:      	stp	q3, q4, [sp, #0x3d0]
    16dc:      	ldr	s2, [x9]
    16e0:      	tst	w14, #0x1
    16e4:      	fcsel	s22, s2, s8, ne
    16e8:      	fmov	w9, s12
    16ec:      	add	x14, sp, #0x1c8
    16f0:      	bfxil	x14, x9, #0, #3
    16f4:      	ldrb	w14, [x14]
    16f8:      	and	w14, w4, w14
    16fc:      	stp	q3, q4, [sp, #0x3b0]
    1700:      	add	x21, sp, #0x3b0
    1704:      	ldr	s2, [x21, w9, uxtw #2]
    1708:      	tst	w14, #0x1
    170c:      	fcsel	s2, s2, s8, ne
    1710:      	mov.s	w9, v12[1]
    1714:      	add	x14, sp, #0x1c8
    1718:      	bfxil	x14, x9, #0, #3
    171c:      	ldrb	w14, [x14]
    1720:      	and	w14, w3, w14
    1724:      	stp	q3, q4, [sp, #0x390]
    1728:      	add	x21, sp, #0x390
    172c:      	ldr	s7, [x21, w9, uxtw #2]
    1730:      	tst	w14, #0x1
    1734:      	fcsel	s7, s7, s8, ne
    1738:      	mov.s	w9, v12[2]
    173c:      	add	x14, sp, #0x1c8
    1740:      	bfxil	x14, x9, #0, #3
    1744:      	ldrb	w14, [x14]
    1748:      	and	w14, w1, w14
    174c:      	stp	q3, q4, [sp, #0x370]
    1750:      	add	x21, sp, #0x370
    1754:      	ldr	s16, [x21, w9, uxtw #2]
    1758:      	tst	w14, #0x1
    175c:      	fcsel	s16, s16, s8, ne
    1760:      	mov.s	w9, v12[3]
    1764:      	add	x14, sp, #0x1c8
    1768:      	bfxil	x14, x9, #0, #3
    176c:      	ldrb	w14, [x14]
    1770:      	and	w14, w2, w14
    1774:      	stp	q3, q4, [sp, #0x350]
    1778:      	add	x21, sp, #0x350
    177c:      	ldr	s25, [x21, w9, uxtw #2]
    1780:      	tst	w14, #0x1
    1784:      	fcsel	s25, s25, s8, ne
    1788:      	mov.s	v2[1], v7[0]
    178c:      	mov.s	v2[2], v16[0]
    1790:      	mov.s	v2[3], v25[0]
    1794:      	mov.s	v5[1], v6[0]
    1798:      	and.16b	v7, v1, v11
    179c:      	mov.s	v5[2], v17[0]
    17a0:      	mov.s	v5[3], v22[0]
    17a4:      	fadd.4s	v3, v3, v5
    17a8:      	fadd.4s	v4, v4, v2
    17ac:      	fmov	w9, s7
    17b0:      	add	x14, sp, #0x1c8
    17b4:      	bfxil	x14, x9, #0, #3
    17b8:      	ldrb	w14, [x14]
    17bc:      	add	x21, sp, #0x330
    17c0:      	orr	x9, x21, x9, lsl #2
    17c4:      	stp	q3, q4, [sp, #0x330]
    17c8:      	ldr	s2, [x9]
    17cc:      	tst	w11, w14
    17d0:      	mov.s	w9, v7[1]
    17d4:      	add	x14, sp, #0x1c8
    17d8:      	bfxil	x14, x9, #0, #3
    17dc:      	ldrb	w14, [x14]
    17e0:      	and	w14, w17, w14
    17e4:      	fcsel	s5, s2, s8, ne
    17e8:      	add	x17, sp, #0x310
    17ec:      	orr	x9, x17, x9, lsl #2
    17f0:      	stp	q3, q4, [sp, #0x310]
    17f4:      	ldr	s2, [x9]
    17f8:      	tst	w14, #0x1
    17fc:      	mov.s	w9, v7[2]
    1800:      	add	x14, sp, #0x1c8
    1804:      	bfxil	x14, x9, #0, #3
    1808:      	fcsel	s6, s2, s8, ne
    180c:      	ldrb	w9, [x14]
    1810:      	and	w9, w15, w9
    1814:      	str	q3, [sp, #0x2f0]
    1818:      	tst	w9, #0x1
    181c:      	mov.s	w9, v7[3]
    1820:      	add	x14, sp, #0x1c8
    1824:      	bfxil	x14, x9, #0, #3
    1828:      	ldrb	w14, [x14]
    182c:      	and	w14, w16, w14
    1830:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    1834:      	ldr	q2, [x15]
    1838:      	and.16b	v2, v0, v2
    183c:      	ldr	s7, [sp, #0x2f0]
    1840:      	fcsel	s22, s7, s8, ne
    1844:      	add	x15, sp, #0x2d0
    1848:      	orr	x9, x15, x9, lsl #2
    184c:      	stp	q3, q4, [sp, #0x2d0]
    1850:      	ldr	s7, [x9]
    1854:      	tst	w14, #0x1
    1858:      	fmov	w9, s2
    185c:      	add	x14, sp, #0x1c8
    1860:      	bfxil	x14, x9, #0, #3
    1864:      	ldrb	w14, [x14]
    1868:      	and	w14, w4, w14
    186c:      	fcsel	s17, s7, s8, ne
    1870:      	stp	q3, q4, [sp, #0x2b0]
    1874:      	add	x15, sp, #0x2b0
    1878:      	ldr	s7, [x15, w9, uxtw #2]
    187c:      	tst	w14, #0x1
    1880:      	mov.s	w9, v2[1]
    1884:      	add	x14, sp, #0x1c8
    1888:      	bfxil	x14, x9, #0, #3
    188c:      	ldrb	w14, [x14]
    1890:      	and	w14, w3, w14
    1894:      	fcsel	s7, s7, s8, ne
    1898:      	stp	q3, q4, [sp, #0x290]
    189c:      	add	x15, sp, #0x290
    18a0:      	ldr	s16, [x15, w9, uxtw #2]
    18a4:      	tst	w14, #0x1
    18a8:      	mov.s	w9, v2[2]
    18ac:      	add	x14, sp, #0x1c8
    18b0:      	bfxil	x14, x9, #0, #3
    18b4:      	ldrb	w14, [x14]
    18b8:      	and	w14, w1, w14
    18bc:      	fcsel	s16, s16, s8, ne
    18c0:      	stp	q3, q4, [sp, #0x270]
    18c4:      	add	x15, sp, #0x270
    18c8:      	ldr	s25, [x15, w9, uxtw #2]
    18cc:      	tst	w14, #0x1
    18d0:      	mov.s	w9, v2[3]
    18d4:      	add	x14, sp, #0x1c8
    18d8:      	bfxil	x14, x9, #0, #3
    18dc:      	ldrb	w14, [x14]
    18e0:      	and	w14, w2, w14
    18e4:      	fcsel	s2, s25, s8, ne
    18e8:      	stp	q3, q4, [sp, #0x250]
    18ec:      	add	x15, sp, #0x250
    18f0:      	ldr	s25, [x15, w9, uxtw #2]
    18f4:      	tst	w14, #0x1
    18f8:      	fcsel	s25, s25, s8, ne
    18fc:      	mov.s	v7[1], v16[0]
    1900:      	mov.s	v7[2], v2[0]
    1904:      	mov.s	v7[3], v25[0]
    1908:      	mov.s	v5[1], v6[0]
    190c:      	movi.4s	v2, #0x4
    1910:      	and.16b	v2, v1, v2
    1914:      	mov.s	v5[2], v22[0]
    1918:      	fmov	w9, s2
    191c:      	add	x14, sp, #0x1c8
    1920:      	orr	x14, x14, x9
    1924:      	ldrb	w14, [x14]
    1928:      	tst	w11, w14
    192c:      	mov.s	v5[3], v17[0]
    1930:      	fadd.4s	v2, v3, v5
    1934:      	fadd.4s	v3, v4, v7
    1938:      	stp	q2, q3, [sp, #0x230]
    193c:      	add	x11, sp, #0x230
    1940:      	ldr	s3, [x11, w9, uxtw #2]
    1944:      	fcsel	s3, s3, s8, ne
    1948:      	tst	w13, #0x1
    194c:      	fadd	s2, s2, s3
    1950:      	fcsel	s3, s2, s8, ne
    1954:      	tst	w5, #0x1
    1958:      	fcsel	s4, s2, s8, ne
    195c:      	tst	w6, #0x1
    1960:      	fcsel	s5, s2, s8, ne
    1964:      	tst	w22, #0x1
    1968:      	fcsel	s6, s2, s8, ne
    196c:      	tst	w0, #0x1
    1970:      	fcsel	s7, s2, s8, ne
    1974:      	tst	w23, #0x1
    1978:      	fcsel	s16, s2, s8, ne
    197c:      	tst	w30, #0x1
    1980:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1984:      	ldr	d17, [x9]
    1988:      	shl.8b	v22, v27, #0x7
    198c:      	cmlt.8b	v22, v22, #0
    1990:      	fcsel	s25, s2, s8, ne
    1994:      	tst	w7, #0x1
    1998:      	fcsel	s2, s2, s8, ne
    199c:      	mov.s	v3[1], v4[0]
    19a0:      	mov.s	v3[2], v5[0]
    19a4:      	mov.s	v3[3], v6[0]
    19a8:      	mov.s	v7[1], v16[0]
    19ac:      	mov.s	v7[2], v25[0]
    19b0:      	mov.s	v7[3], v2[0]
    19b4:      	and.8b	v2, v22, v17
    19b8:      	stp	q3, q7, [sp, #0x210]
    19bc:      	ldr	x9, [sp, #0x90]
    19c0:      	and	x9, x9, #0x7
    19c4:      	add	x11, sp, #0x210
    19c8:      	ldr	s3, [x11, x9, lsl #2]
    19cc:      	addv.8b	b28, v2
    19d0:      	mov	b2, v27[0]
    19d4:      	mov.b	v2[4], v27[1]
    19d8:      	ushll.2d	v2, v2, #0x0
    19dc:      	shl.2d	v2, v2, #0x3f
    19e0:      	cmlt.2d	v2, v2, #0
    19e4:      	ldr	q4, [sp, #0xd0]
    19e8:      	and.16b	v2, v2, v4
    19ec:      	mov	b4, v27[2]
    19f0:      	mov.b	v4[4], v27[3]
    19f4:      	ushll.2d	v4, v4, #0x0
    19f8:      	shl.2d	v4, v4, #0x3f
    19fc:      	cmlt.2d	v4, v4, #0
    1a00:      	ldp	q5, q7, [sp, #0xa0]
    1a04:      	and.16b	v4, v4, v5
    1a08:      	mov	b5, v27[4]
    1a0c:      	mov.b	v5[4], v27[5]
    1a10:      	ushll.2d	v5, v5, #0x0
    1a14:      	shl.2d	v5, v5, #0x3f
    1a18:      	cmlt.2d	v5, v5, #0
    1a1c:      	mov	b6, v27[6]
    1a20:      	mov.b	v6[4], v27[7]
    1a24:      	and.16b	v5, v5, v7
    1a28:      	ushll.2d	v6, v6, #0x0
    1a2c:      	shl.2d	v6, v6, #0x3f
    1a30:      	cmlt.2d	v6, v6, #0
    1a34:      	ldr	q7, [sp, #0xc0]
    1a38:      	and.16b	v6, v6, v7
    1a3c:      	stp	q5, q6, [sp, #0x1f0]
    1a40:      	stp	q2, q4, [sp, #0x1d0]
    1a44:      	ldr	x16, [sp, #0xe0]
    1a48:      	and	x9, x16, #0x7
    1a4c:      	add	x11, sp, #0x1d0
    1a50:      	ldr	x9, [x11, x9, lsl #3]
    1a54:      	fmov	w11, s28
    1a58:      	sub	x9, x9, x16
    1a5c:      	lsl	x9, x9, #2
    1a60:      	add	x12, x12, x9
    1a64:      	movi.2d	v22, #0000000000000000
    1a68:      	movi.2d	v25, #0000000000000000
    1a6c:      	tbnz	w11, #0x0, 0x1e94 <ltmp0+0x1e94>
    1a70:      	ldr	q31, [sp, #0x160]
    1a74:      	tbnz	w11, #0x1, 0x1ea0 <ltmp0+0x1ea0>
    1a78:      	tbnz	w11, #0x2, 0x1eac <ltmp0+0x1eac>
    1a7c:      	tbnz	w11, #0x3, 0x1eb8 <ltmp0+0x1eb8>
    1a80:      	tbnz	w11, #0x4, 0x1ec4 <ltmp0+0x1ec4>
    1a84:      	tbnz	w11, #0x5, 0x1ed0 <ltmp0+0x1ed0>
    1a88:      	tbnz	w11, #0x6, 0x1edc <ltmp0+0x1edc>
    1a8c:      	tbz	w11, #0x7, 0x1a98 <ltmp0+0x1a98>
    1a90:      	add	x11, x12, #0x1c
    1a94:      	ld1.s	{ v25 }[3], [x11]
    1a98:      	fadd	s2, s3, s8
    1a9c:      	mov	w11, #0x4000            ; =16384
    1aa0:      	movk	w11, #0x44c0, lsl #16
    1aa4:      	fmov	s3, w11
    1aa8:      	fdiv	s2, s2, s3
    1aac:      	add	x11, x20, x28
    1ab0:      	ldp	q3, q4, [x11]
    1ab4:      	zip2.8b	v5, v27, v0
    1ab8:      	ushll.4s	v5, v5, #0x0
    1abc:      	shl.4s	v5, v5, #0x1f
    1ac0:      	cmlt.4s	v5, v5, #0
    1ac4:      	bit.16b	v4, v25, v5
    1ac8:      	zip1.8b	v5, v27, v0
    1acc:      	ushll.4s	v5, v5, #0x0
    1ad0:      	shl.4s	v5, v5, #0x1f
    1ad4:      	cmlt.4s	v5, v5, #0
    1ad8:      	bit.16b	v3, v22, v5
    1adc:      	stp	q3, q4, [x11]
    1ae0:      	mov	w11, #0xc5ac            ; =50604
    1ae4:      	movk	w11, #0x3727, lsl #16
    1ae8:      	fmov	s3, w11
    1aec:      	fadd	s2, s2, s3
    1af0:      	fsqrt	s26, s2
    1af4:      	subs	x11, x8, x10
    1af8:      	lsr	x11, x11, #3
    1afc:      	mov	w12, #0x300             ; =768
    1b00:      	ccmp	x11, x12, #0x0, hs
    1b04:      	cset	w11, hi
    1b08:      	sub	x12, x10, x8
    1b0c:      	mov	w13, #0x2007            ; =8199
    1b10:      	movk	w13, #0x18, lsl #16
    1b14:      	cmp	x12, x13
    1b18:      	ccmp	x10, x8, #0x0, hi
    1b1c:      	b.hs	0x1c0c <ltmp0+0x1c0c>
    1b20:      	tbnz	w11, #0x0, 0x1c0c <ltmp0+0x1c0c>
    1b24:      	mov	x11, #0x0               ; =0
    1b28:      	movi.2d	v3, #0000000000000000
    1b2c:      	movi.2d	v4, #0000000000000000
    1b30:      	movi.2d	v5, #0000000000000000
    1b34:      	movi.2d	v6, #0000000000000000
    1b38:      	b	0x1b70 <ltmp0+0x1b70>
    1b3c:      	add	x12, sp, #0x650
    1b40:      	add	x11, x12, x11
    1b44:      	ldp	q2, q7, [x11]
    1b48:      	bit.16b	v7, v17, v0
    1b4c:      	bit.16b	v2, v16, v1
    1b50:      	stp	q2, q7, [x11]
    1b54:      	add.2d	v4, v4, v19
    1b58:      	add.2d	v5, v5, v20
    1b5c:      	add.2d	v6, v6, v18
    1b60:      	add.2d	v3, v3, v21
    1b64:      	fmov	x11, d3
    1b68:      	cmp	x11, #0xc0
    1b6c:      	b.ge	0x1eec <ltmp0+0x1eec>
    1b70:      	fmov	w13, s9
    1b74:      	lsl	x11, x11, #5
    1b78:      	add	x12, x10, x11
    1b7c:      	movi.2d	v16, #0000000000000000
    1b80:      	movi.2d	v17, #0000000000000000
    1b84:      	tbnz	w13, #0x0, 0x1bac <ltmp0+0x1bac>
    1b88:      	and	w13, w13, #0xff
    1b8c:      	tbnz	w13, #0x1, 0x1bb8 <ltmp0+0x1bb8>
    1b90:      	tbnz	w13, #0x2, 0x1bc4 <ltmp0+0x1bc4>
    1b94:      	tbnz	w13, #0x3, 0x1bd0 <ltmp0+0x1bd0>
    1b98:      	tbnz	w13, #0x4, 0x1bdc <ltmp0+0x1bdc>
    1b9c:      	tbnz	w13, #0x5, 0x1be8 <ltmp0+0x1be8>
    1ba0:      	tbnz	w13, #0x6, 0x1bf4 <ltmp0+0x1bf4>
    1ba4:      	tbz	w13, #0x7, 0x1b3c <ltmp0+0x1b3c>
    1ba8:      	b	0x1c00 <ltmp0+0x1c00>
    1bac:      	ldr	s16, [x12]
    1bb0:      	and	w13, w13, #0xff
    1bb4:      	tbz	w13, #0x1, 0x1b90 <ltmp0+0x1b90>
    1bb8:      	add	x14, x12, #0x4
    1bbc:      	ld1.s	{ v16 }[1], [x14]
    1bc0:      	tbz	w13, #0x2, 0x1b94 <ltmp0+0x1b94>
    1bc4:      	add	x14, x12, #0x8
    1bc8:      	ld1.s	{ v16 }[2], [x14]
    1bcc:      	tbz	w13, #0x3, 0x1b98 <ltmp0+0x1b98>
    1bd0:      	add	x14, x12, #0xc
    1bd4:      	ld1.s	{ v16 }[3], [x14]
    1bd8:      	tbz	w13, #0x4, 0x1b9c <ltmp0+0x1b9c>
    1bdc:      	add	x14, x12, #0x10
    1be0:      	ld1.s	{ v17 }[0], [x14]
    1be4:      	tbz	w13, #0x5, 0x1ba0 <ltmp0+0x1ba0>
    1be8:      	add	x14, x12, #0x14
    1bec:      	ld1.s	{ v17 }[1], [x14]
    1bf0:      	tbz	w13, #0x6, 0x1ba4 <ltmp0+0x1ba4>
    1bf4:      	add	x14, x12, #0x18
    1bf8:      	ld1.s	{ v17 }[2], [x14]
    1bfc:      	tbz	w13, #0x7, 0x1b3c <ltmp0+0x1b3c>
    1c00:      	add	x12, x12, #0x1c
    1c04:      	ld1.s	{ v17 }[3], [x12]
    1c08:      	b	0x1b3c <ltmp0+0x1b3c>
    1c0c:      	mov	x11, #0x0               ; =0
    1c10:      	ldr	q2, [sp, #0xf0]
    1c14:      	add.2d	v3, v2, v31
    1c18:      	dup.4s	v7, v26[0]
    1c1c:      	movi.2d	v4, #0000000000000000
    1c20:      	movi.2d	v5, #0000000000000000
    1c24:      	movi.2d	v6, #0000000000000000
    1c28:      	movi.2d	v17, #0000000000000000
    1c2c:      	b	0x1c4c <ltmp0+0x1c4c>
    1c30:      	add.2d	v5, v5, v19
    1c34:      	add.2d	v6, v6, v20
    1c38:      	add.2d	v17, v17, v18
    1c3c:      	add.2d	v4, v4, v21
    1c40:      	fmov	x11, d4
    1c44:      	cmp	x11, #0xc0
    1c48:      	b.ge	0x1de0 <ltmp0+0x1de0>
    1c4c:      	fmov	w13, s9
    1c50:      	shl.2d	v27, v4, #0x3
    1c54:      	orr.16b	v2, v27, v31
    1c58:      	fmov	x12, d2
    1c5c:      	add	x12, x10, x12, lsl #2
    1c60:      	movi.2d	v29, #0000000000000000
    1c64:      	movi.2d	v26, #0000000000000000
    1c68:      	tbnz	w13, #0x0, 0x1d10 <ltmp0+0x1d10>
    1c6c:      	and	w13, w13, #0xff
    1c70:      	tbnz	w13, #0x1, 0x1d1c <ltmp0+0x1d1c>
    1c74:      	tbnz	w13, #0x2, 0x1d28 <ltmp0+0x1d28>
    1c78:      	tbnz	w13, #0x3, 0x1d34 <ltmp0+0x1d34>
    1c7c:      	tbnz	w13, #0x4, 0x1d40 <ltmp0+0x1d40>
    1c80:      	tbnz	w13, #0x5, 0x1d4c <ltmp0+0x1d4c>
    1c84:      	tbnz	w13, #0x6, 0x1d58 <ltmp0+0x1d58>
    1c88:      	tbz	w13, #0x7, 0x1c94 <ltmp0+0x1c94>
    1c8c:      	add	x12, x12, #0x1c
    1c90:      	ld1.s	{ v26 }[3], [x12]
    1c94:      	lsl	x11, x11, #5
    1c98:      	add	x13, x19, x11
    1c9c:      	ldr	q2, [x13]
    1ca0:      	and.16b	v2, v1, v2
    1ca4:      	fdiv.4s	v2, v2, v7
    1ca8:      	add	x14, x20, x11
    1cac:      	ldr	q16, [x14]
    1cb0:      	and.16b	v16, v1, v16
    1cb4:      	fmul.4s	v2, v2, v16
    1cb8:      	fmov	w12, s9
    1cbc:      	fadd.4s	v29, v29, v2
    1cc0:      	add.2d	v2, v3, v27
    1cc4:      	fmov	x11, d2
    1cc8:      	add	x11, x8, x11, lsl #2
    1ccc:      	tbnz	w12, #0x0, 0x1d68 <ltmp0+0x1d68>
    1cd0:      	and	w12, w12, #0xff
    1cd4:      	tbnz	w12, #0x1, 0x1d74 <ltmp0+0x1d74>
    1cd8:      	ldr	q30, [x13, #0x10]
    1cdc:      	ldr	q27, [x14, #0x10]
    1ce0:      	tbnz	w12, #0x2, 0x1d88 <ltmp0+0x1d88>
    1ce4:      	tbnz	w12, #0x3, 0x1d94 <ltmp0+0x1d94>
    1ce8:      	and.16b	v2, v0, v30
    1cec:      	fdiv.4s	v2, v2, v7
    1cf0:      	and.16b	v16, v0, v27
    1cf4:      	fmul.4s	v2, v2, v16
    1cf8:      	fadd.4s	v26, v26, v2
    1cfc:      	tbnz	w12, #0x4, 0x1db4 <ltmp0+0x1db4>
    1d00:      	tbnz	w12, #0x5, 0x1dbc <ltmp0+0x1dbc>
    1d04:      	tbnz	w12, #0x6, 0x1dc8 <ltmp0+0x1dc8>
    1d08:      	tbz	w12, #0x7, 0x1c30 <ltmp0+0x1c30>
    1d0c:      	b	0x1dd4 <ltmp0+0x1dd4>
    1d10:      	ldr	s29, [x12]
    1d14:      	and	w13, w13, #0xff
    1d18:      	tbz	w13, #0x1, 0x1c74 <ltmp0+0x1c74>
    1d1c:      	add	x14, x12, #0x4
    1d20:      	ld1.s	{ v29 }[1], [x14]
    1d24:      	tbz	w13, #0x2, 0x1c78 <ltmp0+0x1c78>
    1d28:      	add	x14, x12, #0x8
    1d2c:      	ld1.s	{ v29 }[2], [x14]
    1d30:      	tbz	w13, #0x3, 0x1c7c <ltmp0+0x1c7c>
    1d34:      	add	x14, x12, #0xc
    1d38:      	ld1.s	{ v29 }[3], [x14]
    1d3c:      	tbz	w13, #0x4, 0x1c80 <ltmp0+0x1c80>
    1d40:      	add	x14, x12, #0x10
    1d44:      	ld1.s	{ v26 }[0], [x14]
    1d48:      	tbz	w13, #0x5, 0x1c84 <ltmp0+0x1c84>
    1d4c:      	add	x14, x12, #0x14
    1d50:      	ld1.s	{ v26 }[1], [x14]
    1d54:      	tbz	w13, #0x6, 0x1c88 <ltmp0+0x1c88>
    1d58:      	add	x14, x12, #0x18
    1d5c:      	ld1.s	{ v26 }[2], [x14]
    1d60:      	tbnz	w13, #0x7, 0x1c8c <ltmp0+0x1c8c>
    1d64:      	b	0x1c94 <ltmp0+0x1c94>
    1d68:      	str	s29, [x11]
    1d6c:      	and	w12, w12, #0xff
    1d70:      	tbz	w12, #0x1, 0x1cd8 <ltmp0+0x1cd8>
    1d74:      	add	x15, x11, #0x4
    1d78:      	st1.s	{ v29 }[1], [x15]
    1d7c:      	ldr	q30, [x13, #0x10]
    1d80:      	ldr	q27, [x14, #0x10]
    1d84:      	tbz	w12, #0x2, 0x1ce4 <ltmp0+0x1ce4>
    1d88:      	add	x13, x11, #0x8
    1d8c:      	st1.s	{ v29 }[2], [x13]
    1d90:      	tbz	w12, #0x3, 0x1ce8 <ltmp0+0x1ce8>
    1d94:      	add	x13, x11, #0xc
    1d98:      	st1.s	{ v29 }[3], [x13]
    1d9c:      	and.16b	v2, v0, v30
    1da0:      	fdiv.4s	v2, v2, v7
    1da4:      	and.16b	v16, v0, v27
    1da8:      	fmul.4s	v2, v2, v16
    1dac:      	fadd.4s	v26, v26, v2
    1db0:      	tbz	w12, #0x4, 0x1d00 <ltmp0+0x1d00>
    1db4:      	str	s26, [x11, #0x10]
    1db8:      	tbz	w12, #0x5, 0x1d04 <ltmp0+0x1d04>
    1dbc:      	add	x13, x11, #0x14
    1dc0:      	st1.s	{ v26 }[1], [x13]
    1dc4:      	tbz	w12, #0x6, 0x1d08 <ltmp0+0x1d08>
    1dc8:      	add	x13, x11, #0x18
    1dcc:      	st1.s	{ v26 }[2], [x13]
    1dd0:      	tbz	w12, #0x7, 0x1c30 <ltmp0+0x1c30>
    1dd4:      	add	x11, x11, #0x1c
    1dd8:      	st1.s	{ v26 }[3], [x11]
    1ddc:      	b	0x1c30 <ltmp0+0x1c30>
    1de0:      	add	x9, x10, x9
    1de4:      	fmov	w10, s28
    1de8:      	movi.2d	v0, #0000000000000000
    1dec:      	movi.2d	v1, #0000000000000000
    1df0:      	tbnz	w10, #0x0, 0x2138 <ltmp0+0x2138>
    1df4:      	tbnz	w10, #0x1, 0x2140 <ltmp0+0x2140>
    1df8:      	tbnz	w10, #0x2, 0x214c <ltmp0+0x214c>
    1dfc:      	tbnz	w10, #0x3, 0x2158 <ltmp0+0x2158>
    1e00:      	tbnz	w10, #0x4, 0x2164 <ltmp0+0x2164>
    1e04:      	tbnz	w10, #0x5, 0x2170 <ltmp0+0x2170>
    1e08:      	tbnz	w10, #0x6, 0x217c <ltmp0+0x217c>
    1e0c:      	tbz	w10, #0x7, 0x1e18 <ltmp0+0x1e18>
    1e10:      	add	x9, x9, #0x1c
    1e14:      	ld1.s	{ v1 }[3], [x9]
    1e18:      	fdiv.4s	v2, v23, v7
    1e1c:      	fdiv.4s	v3, v24, v7
    1e20:      	fmul.4s	v3, v3, v22
    1e24:      	fmul.4s	v4, v2, v25
    1e28:      	fadd.4s	v2, v3, v0
    1e2c:      	fadd.4s	v0, v4, v1
    1e30:      	b	0x2094 <ltmp0+0x2094>
    1e34:      	ldr	s28, [x9]
    1e38:      	mov	w25, #0x4               ; =4
    1e3c:      	tbz	w11, #0x1, 0xcd0 <ltmp0+0xcd0>
    1e40:      	add	x13, x9, #0x4
    1e44:      	ld1.s	{ v28 }[1], [x13]
    1e48:      	tbz	w11, #0x2, 0xcd4 <ltmp0+0xcd4>
    1e4c:      	add	x13, x9, #0x8
    1e50:      	ld1.s	{ v28 }[2], [x13]
    1e54:      	tbz	w11, #0x3, 0xcd8 <ltmp0+0xcd8>
    1e58:      	add	x13, x9, #0xc
    1e5c:      	ld1.s	{ v28 }[3], [x13]
    1e60:      	tbz	w11, #0x4, 0xcdc <ltmp0+0xcdc>
    1e64:      	add	x13, x9, #0x10
    1e68:      	ld1.s	{ v30 }[0], [x13]
    1e6c:      	tbz	w11, #0x5, 0xce0 <ltmp0+0xce0>
    1e70:      	add	x13, x9, #0x14
    1e74:      	ld1.s	{ v30 }[1], [x13]
    1e78:      	tbz	w11, #0x6, 0xce4 <ltmp0+0xce4>
    1e7c:      	add	x13, x9, #0x18
    1e80:      	ld1.s	{ v30 }[2], [x13]
    1e84:      	str	q16, [sp, #0x160]
    1e88:      	str	q23, [sp, #0x140]
    1e8c:      	tbnz	w11, #0x7, 0xcf0 <ltmp0+0xcf0>
    1e90:      	b	0xcf8 <ltmp0+0xcf8>
    1e94:      	ldr	s22, [x12]
    1e98:      	ldr	q31, [sp, #0x160]
    1e9c:      	tbz	w11, #0x1, 0x1a78 <ltmp0+0x1a78>
    1ea0:      	add	x13, x12, #0x4
    1ea4:      	ld1.s	{ v22 }[1], [x13]
    1ea8:      	tbz	w11, #0x2, 0x1a7c <ltmp0+0x1a7c>
    1eac:      	add	x13, x12, #0x8
    1eb0:      	ld1.s	{ v22 }[2], [x13]
    1eb4:      	tbz	w11, #0x3, 0x1a80 <ltmp0+0x1a80>
    1eb8:      	add	x13, x12, #0xc
    1ebc:      	ld1.s	{ v22 }[3], [x13]
    1ec0:      	tbz	w11, #0x4, 0x1a84 <ltmp0+0x1a84>
    1ec4:      	add	x13, x12, #0x10
    1ec8:      	ld1.s	{ v25 }[0], [x13]
    1ecc:      	tbz	w11, #0x5, 0x1a88 <ltmp0+0x1a88>
    1ed0:      	add	x13, x12, #0x14
    1ed4:      	ld1.s	{ v25 }[1], [x13]
    1ed8:      	tbz	w11, #0x6, 0x1a8c <ltmp0+0x1a8c>
    1edc:      	add	x13, x12, #0x18
    1ee0:      	ld1.s	{ v25 }[2], [x13]
    1ee4:      	tbnz	w11, #0x7, 0x1a90 <ltmp0+0x1a90>
    1ee8:      	b	0x1a98 <ltmp0+0x1a98>
    1eec:      	add	x9, x10, x9
    1ef0:      	fmov	w10, s28
    1ef4:      	movi.2d	v3, #0000000000000000
    1ef8:      	movi.2d	v4, #0000000000000000
    1efc:      	tbnz	w10, #0x0, 0x218c <ltmp0+0x218c>
    1f00:      	tbnz	w10, #0x1, 0x2194 <ltmp0+0x2194>
    1f04:      	tbnz	w10, #0x2, 0x21a0 <ltmp0+0x21a0>
    1f08:      	tbnz	w10, #0x3, 0x21ac <ltmp0+0x21ac>
    1f0c:      	tbnz	w10, #0x4, 0x21b8 <ltmp0+0x21b8>
    1f10:      	tbnz	w10, #0x5, 0x21c4 <ltmp0+0x21c4>
    1f14:      	tbnz	w10, #0x6, 0x21d0 <ltmp0+0x21d0>
    1f18:      	add	x11, sp, #0x650
    1f1c:      	tbz	w10, #0x7, 0x1f28 <ltmp0+0x1f28>
    1f20:      	add	x9, x9, #0x1c
    1f24:      	ld1.s	{ v4 }[3], [x9]
    1f28:      	mov	x10, #0x0               ; =0
    1f2c:      	add	x9, x11, x28
    1f30:      	ldp	q2, q5, [x9]
    1f34:      	zip2.8b	v6, v27, v0
    1f38:      	ushll.4s	v6, v6, #0x0
    1f3c:      	shl.4s	v6, v6, #0x1f
    1f40:      	cmlt.4s	v6, v6, #0
    1f44:      	bit.16b	v5, v4, v6
    1f48:      	zip1.8b	v6, v27, v0
    1f4c:      	ushll.4s	v6, v6, #0x0
    1f50:      	shl.4s	v6, v6, #0x1f
    1f54:      	cmlt.4s	v6, v6, #0
    1f58:      	bit.16b	v2, v3, v6
    1f5c:      	stp	q2, q5, [x9]
    1f60:      	dup.4s	v5, v26[0]
    1f64:      	ldr	q2, [sp, #0xf0]
    1f68:      	fmov	x9, d2
    1f6c:      	add	x9, x8, x9, lsl #2
    1f70:      	movi.2d	v6, #0000000000000000
    1f74:      	movi.2d	v7, #0000000000000000
    1f78:      	movi.2d	v16, #0000000000000000
    1f7c:      	movi.2d	v17, #0000000000000000
    1f80:      	b	0x1fa0 <ltmp0+0x1fa0>
    1f84:      	add.2d	v7, v7, v19
    1f88:      	add.2d	v16, v16, v20
    1f8c:      	add.2d	v17, v17, v18
    1f90:      	add.2d	v6, v6, v21
    1f94:      	fmov	x10, d6
    1f98:      	cmp	x10, #0xc0
    1f9c:      	b.ge	0x207c <ltmp0+0x207c>
    1fa0:      	fmov	w11, s9
    1fa4:      	lsl	x10, x10, #5
    1fa8:      	add	x12, x19, x10
    1fac:      	ldp	q2, q26, [x12]
    1fb0:      	and.16b	v2, v1, v2
    1fb4:      	fdiv.4s	v2, v2, v5
    1fb8:      	add	x12, x20, x10
    1fbc:      	ldp	q29, q27, [x12]
    1fc0:      	and.16b	v29, v1, v29
    1fc4:      	fmul.4s	v2, v2, v29
    1fc8:      	add	x12, sp, #0x650
    1fcc:      	add	x12, x12, x10
    1fd0:      	ldp	q30, q29, [x12]
    1fd4:      	and.16b	v30, v1, v30
    1fd8:      	fadd.4s	v30, v2, v30
    1fdc:      	add	x10, x9, x10
    1fe0:      	tbnz	w11, #0x0, 0x2028 <ltmp0+0x2028>
    1fe4:      	and	w11, w11, #0xff
    1fe8:      	tbnz	w11, #0x1, 0x2034 <ltmp0+0x2034>
    1fec:      	tbnz	w11, #0x2, 0x2040 <ltmp0+0x2040>
    1ff0:      	tbz	w11, #0x3, 0x1ffc <ltmp0+0x1ffc>
    1ff4:      	add	x12, x10, #0xc
    1ff8:      	st1.s	{ v30 }[3], [x12]
    1ffc:      	and.16b	v2, v0, v26
    2000:      	fdiv.4s	v2, v2, v5
    2004:      	and.16b	v26, v0, v27
    2008:      	fmul.4s	v2, v2, v26
    200c:      	and.16b	v26, v0, v29
    2010:      	fadd.4s	v26, v2, v26
    2014:      	tbnz	w11, #0x4, 0x2050 <ltmp0+0x2050>
    2018:      	tbnz	w11, #0x5, 0x2058 <ltmp0+0x2058>
    201c:      	tbnz	w11, #0x6, 0x2064 <ltmp0+0x2064>
    2020:      	tbz	w11, #0x7, 0x1f84 <ltmp0+0x1f84>
    2024:      	b	0x2070 <ltmp0+0x2070>
    2028:      	str	s30, [x10]
    202c:      	and	w11, w11, #0xff
    2030:      	tbz	w11, #0x1, 0x1fec <ltmp0+0x1fec>
    2034:      	add	x12, x10, #0x4
    2038:      	st1.s	{ v30 }[1], [x12]
    203c:      	tbz	w11, #0x2, 0x1ff0 <ltmp0+0x1ff0>
    2040:      	add	x12, x10, #0x8
    2044:      	st1.s	{ v30 }[2], [x12]
    2048:      	tbnz	w11, #0x3, 0x1ff4 <ltmp0+0x1ff4>
    204c:      	b	0x1ffc <ltmp0+0x1ffc>
    2050:      	str	s26, [x10, #0x10]
    2054:      	tbz	w11, #0x5, 0x201c <ltmp0+0x201c>
    2058:      	add	x12, x10, #0x14
    205c:      	st1.s	{ v26 }[1], [x12]
    2060:      	tbz	w11, #0x6, 0x2020 <ltmp0+0x2020>
    2064:      	add	x12, x10, #0x18
    2068:      	st1.s	{ v26 }[2], [x12]
    206c:      	tbz	w11, #0x7, 0x1f84 <ltmp0+0x1f84>
    2070:      	add	x10, x10, #0x1c
    2074:      	st1.s	{ v26 }[3], [x10]
    2078:      	b	0x1f84 <ltmp0+0x1f84>
    207c:      	fdiv.4s	v0, v24, v5
    2080:      	fdiv.4s	v1, v23, v5
    2084:      	fmul.4s	v1, v1, v25
    2088:      	fmul.4s	v0, v0, v22
    208c:      	fadd.4s	v2, v0, v3
    2090:      	fadd.4s	v0, v1, v4
    2094:      	ldp	q1, q3, [sp, #0x120]
    2098:      	ldp	q5, q4, [sp, #0x100]
    209c:      	stp	q3, q4, [sp, #0x180]
    20a0:      	stp	q5, q1, [sp, #0x1a0]
    20a4:      	and	x9, x16, #0x7
    20a8:      	add	x10, sp, #0x180
    20ac:      	ldr	x9, [x10, x9, lsl #3]
    20b0:      	sub	x9, x9, x16
    20b4:      	add	x8, x8, x9, lsl #2
    20b8:      	fmov	w9, s28
    20bc:      	tbnz	w9, #0x0, 0x20e0 <ltmp0+0x20e0>
    20c0:      	tbnz	w9, #0x1, 0x20e8 <ltmp0+0x20e8>
    20c4:      	tbnz	w9, #0x2, 0x20f4 <ltmp0+0x20f4>
    20c8:      	tbnz	w9, #0x3, 0x2100 <ltmp0+0x2100>
    20cc:      	tbnz	w9, #0x4, 0x210c <ltmp0+0x210c>
    20d0:      	tbnz	w9, #0x5, 0x2114 <ltmp0+0x2114>
    20d4:      	tbnz	w9, #0x6, 0x2120 <ltmp0+0x2120>
    20d8:      	tbz	w9, #0x7, 0x78 <ltmp0+0x78>
    20dc:      	b	0x212c <ltmp0+0x212c>
    20e0:      	str	s2, [x8]
    20e4:      	tbz	w9, #0x1, 0x20c4 <ltmp0+0x20c4>
    20e8:      	add	x10, x8, #0x4
    20ec:      	st1.s	{ v2 }[1], [x10]
    20f0:      	tbz	w9, #0x2, 0x20c8 <ltmp0+0x20c8>
    20f4:      	add	x10, x8, #0x8
    20f8:      	st1.s	{ v2 }[2], [x10]
    20fc:      	tbz	w9, #0x3, 0x20cc <ltmp0+0x20cc>
    2100:      	add	x10, x8, #0xc
    2104:      	st1.s	{ v2 }[3], [x10]
    2108:      	tbz	w9, #0x4, 0x20d0 <ltmp0+0x20d0>
    210c:      	str	s0, [x8, #0x10]
    2110:      	tbz	w9, #0x5, 0x20d4 <ltmp0+0x20d4>
    2114:      	add	x10, x8, #0x14
    2118:      	st1.s	{ v0 }[1], [x10]
    211c:      	tbz	w9, #0x6, 0x20d8 <ltmp0+0x20d8>
    2120:      	add	x10, x8, #0x18
    2124:      	st1.s	{ v0 }[2], [x10]
    2128:      	tbz	w9, #0x7, 0x78 <ltmp0+0x78>
    212c:      	add	x8, x8, #0x1c
    2130:      	st1.s	{ v0 }[3], [x8]
    2134:      	b	0x78 <ltmp0+0x78>
    2138:      	ldr	s0, [x9]
    213c:      	tbz	w10, #0x1, 0x1df8 <ltmp0+0x1df8>
    2140:      	add	x11, x9, #0x4
    2144:      	ld1.s	{ v0 }[1], [x11]
    2148:      	tbz	w10, #0x2, 0x1dfc <ltmp0+0x1dfc>
    214c:      	add	x11, x9, #0x8
    2150:      	ld1.s	{ v0 }[2], [x11]
    2154:      	tbz	w10, #0x3, 0x1e00 <ltmp0+0x1e00>
    2158:      	add	x11, x9, #0xc
    215c:      	ld1.s	{ v0 }[3], [x11]
    2160:      	tbz	w10, #0x4, 0x1e04 <ltmp0+0x1e04>
    2164:      	add	x11, x9, #0x10
    2168:      	ld1.s	{ v1 }[0], [x11]
    216c:      	tbz	w10, #0x5, 0x1e08 <ltmp0+0x1e08>
    2170:      	add	x11, x9, #0x14
    2174:      	ld1.s	{ v1 }[1], [x11]
    2178:      	tbz	w10, #0x6, 0x1e0c <ltmp0+0x1e0c>
    217c:      	add	x11, x9, #0x18
    2180:      	ld1.s	{ v1 }[2], [x11]
    2184:      	tbnz	w10, #0x7, 0x1e10 <ltmp0+0x1e10>
    2188:      	b	0x1e18 <ltmp0+0x1e18>
    218c:      	ldr	s3, [x9]
    2190:      	tbz	w10, #0x1, 0x1f04 <ltmp0+0x1f04>
    2194:      	add	x11, x9, #0x4
    2198:      	ld1.s	{ v3 }[1], [x11]
    219c:      	tbz	w10, #0x2, 0x1f08 <ltmp0+0x1f08>
    21a0:      	add	x11, x9, #0x8
    21a4:      	ld1.s	{ v3 }[2], [x11]
    21a8:      	tbz	w10, #0x3, 0x1f0c <ltmp0+0x1f0c>
    21ac:      	add	x11, x9, #0xc
    21b0:      	ld1.s	{ v3 }[3], [x11]
    21b4:      	tbz	w10, #0x4, 0x1f10 <ltmp0+0x1f10>
    21b8:      	add	x11, x9, #0x10
    21bc:      	ld1.s	{ v4 }[0], [x11]
    21c0:      	tbz	w10, #0x5, 0x1f14 <ltmp0+0x1f14>
    21c4:      	add	x11, x9, #0x14
    21c8:      	ld1.s	{ v4 }[1], [x11]
    21cc:      	tbz	w10, #0x6, 0x1f18 <ltmp0+0x1f18>
    21d0:      	add	x11, x9, #0x18
    21d4:      	ld1.s	{ v4 }[2], [x11]
    21d8:      	add	x11, sp, #0x650
    21dc:      	tbnz	w10, #0x7, 0x1f20 <ltmp0+0x1f20>
    21e0:      	b	0x1f28 <ltmp0+0x1f28>
    21e4:      	ldr	x9, [sp, #0x8]
    21e8:      	stp	w15, w14, [x9]
    21ec:      	str	w13, [x9, #0x8]
    21f0:      	mov	w8, #0x18               ; =24
    21f4:      	str	w8, [x9, #0x24]
    21f8:      	add	sp, sp, #0x6, lsl #12   ; =0x6000
    21fc:      	add	sp, sp, #0x6d0
    2200:      	ldp	x29, x30, [sp, #0x90]
    2204:      	ldp	x20, x19, [sp, #0x80]
    2208:      	ldp	x22, x21, [sp, #0x70]
    220c:      	ldp	x24, x23, [sp, #0x60]
    2210:      	ldp	x26, x25, [sp, #0x50]
    2214:      	ldp	x28, x27, [sp, #0x40]
    2218:      	ldp	d9, d8, [sp, #0x30]
    221c:      	ldp	d11, d10, [sp, #0x20]
    2220:      	ldp	d13, d12, [sp, #0x10]
    2224:      	ldp	d15, d14, [sp], #0xa0
    2228:      	ret

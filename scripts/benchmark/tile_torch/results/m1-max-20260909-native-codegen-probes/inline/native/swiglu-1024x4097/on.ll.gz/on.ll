; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [16416 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [16416 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot6 = alloca i64, align 8
  store i64 0, ptr %.slot6, align 4
  %.spill7 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill7, align 1
  %tile_snapshot.spill8 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill8, align 64
  %.slot9 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot9, align 64
  %.slot10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot10, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat12, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat14, %41
  %44 = mul i32 %32, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat16, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat18, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat20
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  store float 1.000000e+00, ptr %.spill5, align 4
  %66 = extractvalue { ptr, i64 } %9, 1
  %67 = extractvalue { ptr, i64 } %9, 0
  %68 = ptrtoint ptr %67 to i64
  %69 = extractvalue { ptr, i64 } %27, 1
  %70 = extractvalue { ptr, i64 } %27, 0
  %71 = ptrtoint ptr %70 to i64
  %72 = icmp uge i64 %68, %71
  %73 = sub i64 %68, %71
  %74 = icmp uge i64 %73, 16781312
  %75 = and i1 %72, %74
  %76 = icmp uge i64 %71, %68
  %77 = sub i64 %71, %68
  %78 = icmp uge i64 %77, 16781312
  %79 = and i1 %76, %78
  %80 = or i1 %75, %79
  %81 = and i1 true, %80
  %82 = extractvalue { ptr, i64 } %15, 1
  %83 = extractvalue { ptr, i64 } %15, 0
  %84 = ptrtoint ptr %83 to i64
  %85 = icmp uge i64 %84, %71
  %86 = sub i64 %84, %71
  %87 = icmp uge i64 %86, 16781312
  %88 = and i1 %85, %87
  %89 = icmp uge i64 %71, %84
  %90 = sub i64 %71, %84
  %91 = icmp uge i64 %90, 16781312
  %92 = and i1 %89, %91
  %93 = or i1 %88, %92
  %94 = and i1 %81, %93
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.1:                                ; preds = %direct.true
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.2:                                ; preds = %direct.schedule.3, %direct.schedule.1
  %.state = load i64, ptr %.slot, align 4
  %95 = icmp slt i64 %.state, 512
  br i1 %95, label %direct.true21, label %direct.false22

direct.schedule.3:                                ; preds = %direct.true21
  %.state23 = load i64, ptr %.slot, align 4
  %96 = mul i64 %.state23, 8
  %.splatinsert24 = insertelement <8 x i64> poison, i64 %96, i64 0
  %.splat25 = shufflevector <8 x i64> %.splatinsert24, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %97 = add <8 x i64> %.splat25, %.spill.load
  %.spill.load26 = load <8 x i64>, ptr %.spill4, align 64
  %98 = add <8 x i64> %.spill.load26, zeroinitializer
  %99 = add <8 x i64> zeroinitializer, %98
  %100 = add <8 x i64> zeroinitializer, %97
  %101 = mul <8 x i64> %99, splat (i64 4097)
  %102 = add <8 x i64> %101, %100
  %103 = extractvalue { ptr, i64 } %9, 0
  %104 = extractelement <8 x i64> %102, i32 0
  %105 = sub i64 %104, 0
  %106 = mul i64 %105, 4
  %buffer.contiguous.address = getelementptr i8, ptr %103, i64 %106
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %107 = fneg <8 x float> %buffer.contiguous.load
  %108 = select <8 x i1> %51, <8 x float> %107, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %108)
  %.spill.load27 = load float, ptr %.spill5, align 4
  %.splatinsert28 = insertelement <8 x float> poison, float %.spill.load27, i64 0
  %.splat29 = shufflevector <8 x float> %.splatinsert28, <8 x float> poison, <8 x i32> zeroinitializer
  %109 = fadd <8 x float> %.splat29, %native.exp
  %110 = fdiv <8 x float> %buffer.contiguous.load, %109
  %111 = extractvalue { ptr, i64 } %15, 0
  %112 = extractelement <8 x i64> %102, i32 0
  %113 = sub i64 %112, 0
  %114 = mul i64 %113, 4
  %buffer.contiguous.address30 = getelementptr i8, ptr %111, i64 %114
  %buffer.contiguous.load31 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address30, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %115 = fmul <8 x float> %110, %buffer.contiguous.load31
  %116 = extractvalue { ptr, i64 } %27, 0
  %117 = extractelement <8 x i64> %102, i32 0
  %118 = sub i64 %117, 0
  %119 = mul i64 %118, 4
  %buffer.contiguous.address32 = getelementptr i8, ptr %116, i64 %119
  call void @llvm.masked.store.v8f32.p0(<8 x float> %115, ptr %buffer.contiguous.address32, i32 1, <8 x i1> %51)
  %.state33 = load i64, ptr %.slot, align 4
  %120 = add i64 %.state33, 1
  store i64 %120, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.4:                                ; preds = %direct.false22
  %.spill.load34 = load <8 x i64>, ptr %.spill, align 64
  %121 = icmp slt <8 x i64> %.spill.load34, splat (i64 1)
  %122 = and <8 x i1> %51, %121
  %123 = xor <8 x i1> %121, splat (i1 true)
  %124 = and <8 x i1> %51, %123
  %125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %122)
  %126 = bitcast <8 x i1> %122 to i8
  %127 = call i8 @llvm.cttz.i8(i8 %126, i1 false)
  %128 = zext i8 %127 to i32
  %129 = select i1 %125, i32 %128, i32 0
  %.spill.load35 = load <8 x i64>, ptr %.spill, align 64
  %130 = add <8 x i64> splat (i64 4096), %.spill.load35
  %.spill.load36 = load <8 x i64>, ptr %.spill4, align 64
  %131 = add <8 x i64> %.spill.load36, zeroinitializer
  %132 = add <8 x i64> zeroinitializer, %131
  %133 = add <8 x i64> zeroinitializer, %130
  %134 = mul <8 x i64> %132, splat (i64 4097)
  %135 = add <8 x i64> %134, %133
  %136 = extractvalue { ptr, i64 } %9, 0
  %137 = select <8 x i1> %122, <8 x i64> %135, <8 x i64> zeroinitializer
  %138 = extractelement <8 x i64> %137, i32 %129
  %139 = zext i32 %129 to i64
  %140 = sub i64 %138, %139
  %141 = mul i64 %140, 4
  %buffer.contiguous.address37 = getelementptr i8, ptr %136, i64 %141
  %buffer.contiguous.load38 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address37, i32 1, <8 x i1> %122, <8 x float> zeroinitializer)
  %142 = fneg <8 x float> %buffer.contiguous.load38
  %143 = select <8 x i1> %122, <8 x float> %142, <8 x float> zeroinitializer
  %native.exp39 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %143)
  %.spill.load40 = load float, ptr %.spill5, align 4
  %.splatinsert41 = insertelement <8 x float> poison, float %.spill.load40, i64 0
  %.splat42 = shufflevector <8 x float> %.splatinsert41, <8 x float> poison, <8 x i32> zeroinitializer
  %144 = fadd <8 x float> %.splat42, %native.exp39
  %145 = fdiv <8 x float> %buffer.contiguous.load38, %144
  %146 = extractvalue { ptr, i64 } %15, 0
  %147 = select <8 x i1> %122, <8 x i64> %135, <8 x i64> zeroinitializer
  %148 = extractelement <8 x i64> %147, i32 %129
  %149 = zext i32 %129 to i64
  %150 = sub i64 %148, %149
  %151 = mul i64 %150, 4
  %buffer.contiguous.address43 = getelementptr i8, ptr %146, i64 %151
  %buffer.contiguous.load44 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address43, i32 1, <8 x i1> %122, <8 x float> zeroinitializer)
  %152 = fmul <8 x float> %145, %buffer.contiguous.load44
  %153 = extractvalue { ptr, i64 } %27, 0
  %154 = extractelement <8 x i64> %135, i32 %129
  %155 = zext i32 %129 to i64
  %156 = sub i64 %154, %155
  %157 = mul i64 %156, 4
  %buffer.contiguous.address45 = getelementptr i8, ptr %153, i64 %157
  call void @llvm.masked.store.v8f32.p0(<8 x float> %152, ptr %buffer.contiguous.address45, i32 1, <8 x i1> %122)
  %158 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %124)
  %159 = bitcast <8 x i1> %124 to i8
  %160 = call i8 @llvm.cttz.i8(i8 %159, i1 false)
  %161 = zext i8 %160 to i32
  %162 = select i1 %158, i32 %161, i32 0
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.20, %direct.schedule.4
  ret void

direct.schedule.7:                                ; preds = %direct.false
  %163 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %163, 0
  %166 = select <8 x i1> %51, <8 x ptr> %164, <8 x ptr> %165
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %163, 1
  %169 = select <8 x i1> %51, <8 x i64> %167, <8 x i64> %168
  %170 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %166, 0
  %171 = insertvalue { <8 x ptr>, <8 x i64> } %170, <8 x i64> %169, 1
  store { <8 x ptr>, <8 x i64> } %171, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot6, align 4
  br label %direct.schedule.8

direct.schedule.8:                                ; preds = %direct.schedule.9, %direct.schedule.7
  %.state46 = load i64, ptr %.slot6, align 4
  %172 = icmp slt i64 %.state46, 512
  br i1 %172, label %direct.true47, label %direct.false48

direct.schedule.9:                                ; preds = %direct.true47
  %.state49 = load i64, ptr %.slot6, align 4
  %173 = mul i64 %.state49, 8
  %.splatinsert50 = insertelement <8 x i64> poison, i64 %173, i64 0
  %.splat51 = shufflevector <8 x i64> %.splatinsert50, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load52 = load <8 x i64>, ptr %.spill, align 64
  %174 = add <8 x i64> %.splat51, %.spill.load52
  %.spill.load53 = load <8 x i64>, ptr %.spill4, align 64
  %175 = add <8 x i64> %.spill.load53, zeroinitializer
  %176 = add <8 x i64> zeroinitializer, %175
  %177 = add <8 x i64> zeroinitializer, %174
  %178 = mul <8 x i64> %176, splat (i64 4097)
  %179 = add <8 x i64> %178, %177
  %180 = extractvalue { ptr, i64 } %9, 0
  %181 = extractelement <8 x i64> %179, i32 0
  %182 = sub i64 %181, 0
  %183 = mul i64 %182, 4
  %buffer.contiguous.address54 = getelementptr i8, ptr %180, i64 %183
  %buffer.contiguous.load55 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address54, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state56 = load i64, ptr %.slot6, align 4
  %.splatinsert57 = insertelement <8 x i64> poison, i64 %.state56, i64 0
  %.splat58 = shufflevector <8 x i64> %.splatinsert57, <8 x i64> poison, <8 x i32> zeroinitializer
  %186 = mul <8 x i64> %.splat58, splat (i64 32)
  %187 = add <8 x i64> %185, %186
  %188 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %184, 0
  %189 = insertvalue { <8 x ptr>, <8 x i64> } %188, <8 x i64> %187, 1
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %189, 1
  %192 = extractelement <8 x ptr> %190, i32 0
  %193 = extractelement <8 x i64> %191, i32 0
  %194 = sub i64 %193, 0
  %195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %196 = select i1 %195, i64 %194, i64 0
  %private.contiguous.address = getelementptr i8, ptr %192, i64 %196
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %197 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load55, <8 x float> %private.contiguous.preserve
  store <8 x float> %197, ptr %private.contiguous.address, align 4
  %.state59 = load i64, ptr %.slot6, align 4
  %198 = add i64 %.state59, 1
  store i64 %198, ptr %.slot6, align 4
  br label %direct.schedule.8

direct.schedule.10:                               ; preds = %direct.false48
  %.spill.load60 = load <8 x i64>, ptr %.spill, align 64
  %199 = icmp slt <8 x i64> %.spill.load60, splat (i64 1)
  %200 = load <8 x i1>, ptr %.spill7, align 1
  %201 = select <8 x i1> %51, <8 x i1> %199, <8 x i1> %200
  store <8 x i1> %201, ptr %.spill7, align 1
  %202 = and <8 x i1> %51, %199
  %203 = xor <8 x i1> %199, splat (i1 true)
  %204 = and <8 x i1> %51, %203
  %205 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %202)
  %206 = bitcast <8 x i1> %202 to i8
  %207 = call i8 @llvm.cttz.i8(i8 %206, i1 false)
  %208 = zext i8 %207 to i32
  %209 = select i1 %205, i32 %208, i32 0
  %.spill.load61 = load <8 x i64>, ptr %.spill, align 64
  %210 = add <8 x i64> splat (i64 4096), %.spill.load61
  %.spill.load62 = load <8 x i64>, ptr %.spill4, align 64
  %211 = add <8 x i64> %.spill.load62, zeroinitializer
  %212 = add <8 x i64> zeroinitializer, %211
  %213 = add <8 x i64> zeroinitializer, %210
  %214 = mul <8 x i64> %212, splat (i64 4097)
  %215 = add <8 x i64> %214, %213
  %216 = extractvalue { ptr, i64 } %9, 0
  %217 = select <8 x i1> %202, <8 x i64> %215, <8 x i64> zeroinitializer
  %218 = extractelement <8 x i64> %217, i32 %209
  %219 = zext i32 %209 to i64
  %220 = sub i64 %218, %219
  %221 = mul i64 %220, 4
  %buffer.contiguous.address63 = getelementptr i8, ptr %216, i64 %221
  %buffer.contiguous.load64 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address63, i32 1, <8 x i1> %202, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %224 = add <8 x i64> %223, splat (i64 16384)
  %225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %226 = insertvalue { <8 x ptr>, <8 x i64> } %225, <8 x i64> %224, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %226, 1
  %229 = extractelement <8 x ptr> %227, i32 0
  %230 = extractelement <8 x i64> %228, i32 %209
  %231 = zext i32 %209 to i64
  %232 = mul i64 %231, 4
  %233 = sub i64 %230, %232
  %234 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %202)
  %235 = select i1 %234, i64 %233, i64 0
  %private.contiguous.address66 = getelementptr i8, ptr %229, i64 %235
  %private.contiguous.preserve67 = load <8 x float>, ptr %private.contiguous.address66, align 4
  %236 = select <8 x i1> %202, <8 x float> %buffer.contiguous.load64, <8 x float> %private.contiguous.preserve67
  store <8 x float> %236, ptr %private.contiguous.address66, align 4
  %237 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %204)
  %238 = bitcast <8 x i1> %204 to i8
  %239 = call i8 @llvm.cttz.i8(i8 %238, i1 false)
  %240 = zext i8 %239 to i32
  %241 = select i1 %237, i32 %240, i32 0
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.10
  %242 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %242, 0
  %245 = select <8 x i1> %51, <8 x ptr> %243, <8 x ptr> %244
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %242, 1
  %248 = select <8 x i1> %51, <8 x i64> %246, <8 x i64> %247
  %249 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %245, 0
  %250 = insertvalue { <8 x ptr>, <8 x i64> } %249, <8 x i64> %248, 1
  store { <8 x ptr>, <8 x i64> } %250, ptr %tile_snapshot.spill8, align 64
  %251 = load <8 x i64>, ptr %.slot9, align 64
  %252 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %251
  store <8 x i64> %252, ptr %.slot9, align 64
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state68 = load <8 x i64>, ptr %.slot9, align 64
  %253 = icmp slt <8 x i64> %.state68, splat (i64 512)
  %254 = extractelement <8 x i1> %253, i32 0
  br i1 %254, label %direct.true69, label %direct.false70

direct.schedule.14:                               ; preds = %direct.true69
  %.state71 = load <8 x i64>, ptr %.slot9, align 64
  %255 = mul <8 x i64> %.state71, splat (i64 8)
  %.spill.load72 = load <8 x i64>, ptr %.spill, align 64
  %256 = add <8 x i64> %255, %.spill.load72
  %.spill.load73 = load <8 x i64>, ptr %.spill4, align 64
  %257 = add <8 x i64> %.spill.load73, zeroinitializer
  %258 = add <8 x i64> zeroinitializer, %257
  %259 = add <8 x i64> zeroinitializer, %256
  %260 = mul <8 x i64> %258, splat (i64 4097)
  %261 = add <8 x i64> %260, %259
  %262 = extractvalue { ptr, i64 } %15, 0
  %263 = extractelement <8 x i64> %261, i32 0
  %264 = sub i64 %263, 0
  %265 = mul i64 %264, 4
  %buffer.contiguous.address74 = getelementptr i8, ptr %262, i64 %265
  %buffer.contiguous.load75 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address74, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load76 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 1
  %.state77 = load <8 x i64>, ptr %.slot9, align 64
  %268 = mul <8 x i64> %.state77, splat (i64 32)
  %269 = add <8 x i64> %267, %268
  %270 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %266, 0
  %271 = insertvalue { <8 x ptr>, <8 x i64> } %270, <8 x i64> %269, 1
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %271, 1
  %274 = extractelement <8 x ptr> %272, i32 0
  %275 = extractelement <8 x i64> %273, i32 0
  %276 = sub i64 %275, 0
  %277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %278 = select i1 %277, i64 %276, i64 0
  %private.contiguous.address78 = getelementptr i8, ptr %274, i64 %278
  %private.contiguous.preserve79 = load <8 x float>, ptr %private.contiguous.address78, align 4
  %279 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load75, <8 x float> %private.contiguous.preserve79
  store <8 x float> %279, ptr %private.contiguous.address78, align 4
  %.state80 = load <8 x i64>, ptr %.slot9, align 64
  %280 = add <8 x i64> %.state80, splat (i64 1)
  %281 = load <8 x i64>, ptr %.slot9, align 64
  %282 = select <8 x i1> %51, <8 x i64> %280, <8 x i64> %281
  store <8 x i64> %282, ptr %.slot9, align 64
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false70
  %.spill.load81 = load <8 x i1>, ptr %.spill7, align 1
  %283 = and <8 x i1> %51, %.spill.load81
  %284 = xor <8 x i1> %.spill.load81, splat (i1 true)
  %285 = and <8 x i1> %51, %284
  %286 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %283)
  %287 = bitcast <8 x i1> %283 to i8
  %288 = call i8 @llvm.cttz.i8(i8 %287, i1 false)
  %289 = zext i8 %288 to i32
  %290 = select i1 %286, i32 %289, i32 0
  %.spill.load82 = load <8 x i64>, ptr %.spill, align 64
  %291 = add <8 x i64> splat (i64 4096), %.spill.load82
  %.spill.load83 = load <8 x i64>, ptr %.spill4, align 64
  %292 = add <8 x i64> %.spill.load83, zeroinitializer
  %293 = add <8 x i64> zeroinitializer, %292
  %294 = add <8 x i64> zeroinitializer, %291
  %295 = mul <8 x i64> %293, splat (i64 4097)
  %296 = add <8 x i64> %295, %294
  %297 = extractvalue { ptr, i64 } %15, 0
  %298 = select <8 x i1> %283, <8 x i64> %296, <8 x i64> zeroinitializer
  %299 = extractelement <8 x i64> %298, i32 %290
  %300 = zext i32 %290 to i64
  %301 = sub i64 %299, %300
  %302 = mul i64 %301, 4
  %buffer.contiguous.address84 = getelementptr i8, ptr %297, i64 %302
  %buffer.contiguous.load85 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address84, i32 1, <8 x i1> %283, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load86 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 0
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 1
  %305 = add <8 x i64> %304, splat (i64 16384)
  %306 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %303, 0
  %307 = insertvalue { <8 x ptr>, <8 x i64> } %306, <8 x i64> %305, 1
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %307, 1
  %310 = extractelement <8 x ptr> %308, i32 0
  %311 = extractelement <8 x i64> %309, i32 %290
  %312 = zext i32 %290 to i64
  %313 = mul i64 %312, 4
  %314 = sub i64 %311, %313
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %283)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address87 = getelementptr i8, ptr %310, i64 %316
  %private.contiguous.preserve88 = load <8 x float>, ptr %private.contiguous.address87, align 4
  %317 = select <8 x i1> %283, <8 x float> %buffer.contiguous.load85, <8 x float> %private.contiguous.preserve88
  store <8 x float> %317, ptr %private.contiguous.address87, align 4
  %318 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %285)
  %319 = bitcast <8 x i1> %285 to i8
  %320 = call i8 @llvm.cttz.i8(i8 %319, i1 false)
  %321 = zext i8 %320 to i32
  %322 = select i1 %318, i32 %321, i32 0
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.15
  %323 = load <8 x i64>, ptr %.slot10, align 64
  %324 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %323
  store <8 x i64> %324, ptr %.slot10, align 64
  br label %direct.schedule.18

direct.schedule.18:                               ; preds = %direct.schedule.19, %direct.schedule.17
  %.state89 = load <8 x i64>, ptr %.slot10, align 64
  %325 = icmp slt <8 x i64> %.state89, splat (i64 512)
  %326 = extractelement <8 x i1> %325, i32 0
  br i1 %326, label %direct.true90, label %direct.false91

direct.schedule.19:                               ; preds = %direct.true90
  %.state92 = load <8 x i64>, ptr %.slot10, align 64
  %327 = mul <8 x i64> %.state92, splat (i64 8)
  %.spill.load93 = load <8 x i64>, ptr %.spill, align 64
  %328 = add <8 x i64> %327, %.spill.load93
  %.spill.load94 = load <8 x i64>, ptr %.spill4, align 64
  %329 = add <8 x i64> %.spill.load94, zeroinitializer
  %330 = add <8 x i64> zeroinitializer, %329
  %331 = add <8 x i64> zeroinitializer, %328
  %332 = mul <8 x i64> %330, splat (i64 4097)
  %333 = add <8 x i64> %332, %331
  %tile_snapshot.spill.load95 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 0
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 1
  %.state96 = load <8 x i64>, ptr %.slot10, align 64
  %336 = mul <8 x i64> %.state96, splat (i64 32)
  %337 = add <8 x i64> %335, %336
  %338 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %334, 0
  %339 = insertvalue { <8 x ptr>, <8 x i64> } %338, <8 x i64> %337, 1
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %339, 1
  %342 = extractelement <8 x ptr> %340, i32 0
  %343 = extractelement <8 x i64> %341, i32 0
  %344 = sub i64 %343, 0
  %345 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %346 = select i1 %345, i64 %344, i64 0
  %private.contiguous.address97 = getelementptr i8, ptr %342, i64 %346
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address97, align 4
  %347 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %348 = fneg <8 x float> %347
  %349 = select <8 x i1> %51, <8 x float> %348, <8 x float> zeroinitializer
  %native.exp98 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %349)
  %.spill.load99 = load float, ptr %.spill5, align 4
  %.splatinsert100 = insertelement <8 x float> poison, float %.spill.load99, i64 0
  %.splat101 = shufflevector <8 x float> %.splatinsert100, <8 x float> poison, <8 x i32> zeroinitializer
  %350 = fadd <8 x float> %.splat101, %native.exp98
  %351 = fdiv <8 x float> %347, %350
  %tile_snapshot.spill.load102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %352 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 0
  %353 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 1
  %.state103 = load <8 x i64>, ptr %.slot10, align 64
  %354 = mul <8 x i64> %.state103, splat (i64 32)
  %355 = add <8 x i64> %353, %354
  %356 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %352, 0
  %357 = insertvalue { <8 x ptr>, <8 x i64> } %356, <8 x i64> %355, 1
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %357, 1
  %360 = extractelement <8 x ptr> %358, i32 0
  %361 = extractelement <8 x i64> %359, i32 0
  %362 = sub i64 %361, 0
  %363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %364 = select i1 %363, i64 %362, i64 0
  %private.contiguous.address104 = getelementptr i8, ptr %360, i64 %364
  %private.contiguous.load105 = load <8 x float>, ptr %private.contiguous.address104, align 4
  %365 = select <8 x i1> %51, <8 x float> %private.contiguous.load105, <8 x float> zeroinitializer
  %366 = fmul <8 x float> %351, %365
  %367 = extractvalue { ptr, i64 } %27, 0
  %368 = extractelement <8 x i64> %333, i32 0
  %369 = sub i64 %368, 0
  %370 = mul i64 %369, 4
  %buffer.contiguous.address106 = getelementptr i8, ptr %367, i64 %370
  call void @llvm.masked.store.v8f32.p0(<8 x float> %366, ptr %buffer.contiguous.address106, i32 1, <8 x i1> %51)
  %.state107 = load <8 x i64>, ptr %.slot10, align 64
  %371 = add <8 x i64> %.state107, splat (i64 1)
  %372 = load <8 x i64>, ptr %.slot10, align 64
  %373 = select <8 x i1> %51, <8 x i64> %371, <8 x i64> %372
  store <8 x i64> %373, ptr %.slot10, align 64
  br label %direct.schedule.18

direct.schedule.20:                               ; preds = %direct.false91
  %.spill.load108 = load <8 x i1>, ptr %.spill7, align 1
  %374 = and <8 x i1> %51, %.spill.load108
  %375 = xor <8 x i1> %.spill.load108, splat (i1 true)
  %376 = and <8 x i1> %51, %375
  %377 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %374)
  %378 = bitcast <8 x i1> %374 to i8
  %379 = call i8 @llvm.cttz.i8(i8 %378, i1 false)
  %380 = zext i8 %379 to i32
  %381 = select i1 %377, i32 %380, i32 0
  %.spill.load109 = load <8 x i64>, ptr %.spill, align 64
  %382 = add <8 x i64> splat (i64 4096), %.spill.load109
  %.spill.load110 = load <8 x i64>, ptr %.spill4, align 64
  %383 = add <8 x i64> %.spill.load110, zeroinitializer
  %384 = add <8 x i64> zeroinitializer, %383
  %385 = add <8 x i64> zeroinitializer, %382
  %386 = mul <8 x i64> %384, splat (i64 4097)
  %387 = add <8 x i64> %386, %385
  %tile_snapshot.spill.load111 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %388 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 0
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 1
  %390 = add <8 x i64> %389, splat (i64 16384)
  %391 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %388, 0
  %392 = insertvalue { <8 x ptr>, <8 x i64> } %391, <8 x i64> %390, 1
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %392, 1
  %395 = extractelement <8 x ptr> %393, i32 0
  %396 = extractelement <8 x i64> %394, i32 %381
  %397 = zext i32 %381 to i64
  %398 = mul i64 %397, 4
  %399 = sub i64 %396, %398
  %400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %374)
  %401 = select i1 %400, i64 %399, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %395, i64 %401
  %private.contiguous.load113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %402 = select <8 x i1> %374, <8 x float> %private.contiguous.load113, <8 x float> zeroinitializer
  %403 = fneg <8 x float> %402
  %404 = select <8 x i1> %374, <8 x float> %403, <8 x float> zeroinitializer
  %native.exp114 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %404)
  %.spill.load115 = load float, ptr %.spill5, align 4
  %.splatinsert116 = insertelement <8 x float> poison, float %.spill.load115, i64 0
  %.splat117 = shufflevector <8 x float> %.splatinsert116, <8 x float> poison, <8 x i32> zeroinitializer
  %405 = fadd <8 x float> %.splat117, %native.exp114
  %406 = fdiv <8 x float> %402, %405
  %tile_snapshot.spill.load118 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 0
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 1
  %409 = add <8 x i64> %408, splat (i64 16384)
  %410 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %407, 0
  %411 = insertvalue { <8 x ptr>, <8 x i64> } %410, <8 x i64> %409, 1
  %412 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %413 = extractvalue { <8 x ptr>, <8 x i64> } %411, 1
  %414 = extractelement <8 x ptr> %412, i32 0
  %415 = extractelement <8 x i64> %413, i32 %381
  %416 = zext i32 %381 to i64
  %417 = mul i64 %416, 4
  %418 = sub i64 %415, %417
  %419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %374)
  %420 = select i1 %419, i64 %418, i64 0
  %private.contiguous.address119 = getelementptr i8, ptr %414, i64 %420
  %private.contiguous.load120 = load <8 x float>, ptr %private.contiguous.address119, align 4
  %421 = select <8 x i1> %374, <8 x float> %private.contiguous.load120, <8 x float> zeroinitializer
  %422 = fmul <8 x float> %406, %421
  %423 = extractvalue { ptr, i64 } %27, 0
  %424 = extractelement <8 x i64> %387, i32 %381
  %425 = zext i32 %381 to i64
  %426 = sub i64 %424, %425
  %427 = mul i64 %426, 4
  %buffer.contiguous.address121 = getelementptr i8, ptr %423, i64 %427
  call void @llvm.masked.store.v8f32.p0(<8 x float> %422, ptr %buffer.contiguous.address121, i32 1, <8 x i1> %374)
  %428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %376)
  %429 = bitcast <8 x i1> %376 to i8
  %430 = call i8 @llvm.cttz.i8(i8 %429, i1 false)
  %431 = zext i8 %430 to i32
  %432 = select i1 %428, i32 %431, i32 0
  br label %direct.schedule.6

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.0
  br label %direct.schedule.1

direct.false:                                     ; preds = %direct.schedule.0
  br label %direct.schedule.7

direct.true21:                                    ; preds = %direct.schedule.2
  br label %direct.schedule.3

direct.false22:                                   ; preds = %direct.schedule.2
  br label %direct.schedule.4

direct.true47:                                    ; preds = %direct.schedule.8
  br label %direct.schedule.9

direct.false48:                                   ; preds = %direct.schedule.8
  br label %direct.schedule.10

direct.true69:                                    ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false70:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true90:                                    ; preds = %direct.schedule.18
  br label %direct.schedule.19

direct.false91:                                   ; preds = %direct.schedule.18
  br label %direct.schedule.20
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #2 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [16416 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [16416 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot6 = alloca i64, align 8
  store i64 0, ptr %.slot6, align 4
  %.spill7 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill7, align 1
  %tile_snapshot.spill8 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill8, align 64
  %.slot9 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot9, align 64
  %.slot10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot10, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat12, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat14, %41
  %44 = mul i32 %32, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat16, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat18, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert19 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat20
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  store float 1.000000e+00, ptr %.spill5, align 4
  %66 = extractvalue { ptr, i64 } %9, 1
  %67 = extractvalue { ptr, i64 } %9, 0
  %68 = ptrtoint ptr %67 to i64
  %69 = extractvalue { ptr, i64 } %27, 1
  %70 = extractvalue { ptr, i64 } %27, 0
  %71 = ptrtoint ptr %70 to i64
  %72 = icmp uge i64 %68, %71
  %73 = sub i64 %68, %71
  %74 = icmp uge i64 %73, 16781312
  %75 = and i1 %72, %74
  %76 = icmp uge i64 %71, %68
  %77 = sub i64 %71, %68
  %78 = icmp uge i64 %77, 16781312
  %79 = and i1 %76, %78
  %80 = or i1 %75, %79
  %81 = and i1 true, %80
  %82 = extractvalue { ptr, i64 } %15, 1
  %83 = extractvalue { ptr, i64 } %15, 0
  %84 = ptrtoint ptr %83 to i64
  %85 = icmp uge i64 %84, %71
  %86 = sub i64 %84, %71
  %87 = icmp uge i64 %86, 16781312
  %88 = and i1 %85, %87
  %89 = icmp uge i64 %71, %84
  %90 = sub i64 %71, %84
  %91 = icmp uge i64 %90, 16781312
  %92 = and i1 %89, %91
  %93 = or i1 %88, %92
  %94 = and i1 %81, %93
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.1:                                ; preds = %direct.true
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.2:                                ; preds = %direct.schedule.3, %direct.schedule.1
  %.state = load i64, ptr %.slot, align 4
  %95 = icmp slt i64 %.state, 512
  br i1 %95, label %direct.true21, label %direct.false22

direct.schedule.3:                                ; preds = %direct.true21
  %.state23 = load i64, ptr %.slot, align 4
  %96 = mul i64 %.state23, 8
  %.splatinsert24 = insertelement <8 x i64> poison, i64 %96, i64 0
  %.splat25 = shufflevector <8 x i64> %.splatinsert24, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %97 = add <8 x i64> %.splat25, %.spill.load
  %.spill.load26 = load <8 x i64>, ptr %.spill4, align 64
  %98 = add <8 x i64> %.spill.load26, zeroinitializer
  %99 = add <8 x i64> zeroinitializer, %98
  %100 = add <8 x i64> zeroinitializer, %97
  %101 = mul <8 x i64> %99, splat (i64 4097)
  %102 = add <8 x i64> %101, %100
  %103 = extractvalue { ptr, i64 } %9, 0
  %104 = extractelement <8 x i64> %102, i32 0
  %105 = sub i64 %104, 0
  %106 = mul i64 %105, 4
  %buffer.contiguous.address = getelementptr i8, ptr %103, i64 %106
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %107 = fneg <8 x float> %buffer.contiguous.load
  %108 = select <8 x i1> %51, <8 x float> %107, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %108)
  %.spill.load27 = load float, ptr %.spill5, align 4
  %.splatinsert28 = insertelement <8 x float> poison, float %.spill.load27, i64 0
  %.splat29 = shufflevector <8 x float> %.splatinsert28, <8 x float> poison, <8 x i32> zeroinitializer
  %109 = fadd <8 x float> %.splat29, %native.exp
  %110 = fdiv <8 x float> %buffer.contiguous.load, %109
  %111 = extractvalue { ptr, i64 } %15, 0
  %112 = extractelement <8 x i64> %102, i32 0
  %113 = sub i64 %112, 0
  %114 = mul i64 %113, 4
  %buffer.contiguous.address30 = getelementptr i8, ptr %111, i64 %114
  %buffer.contiguous.load31 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address30, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %115 = fmul <8 x float> %110, %buffer.contiguous.load31
  %116 = extractvalue { ptr, i64 } %27, 0
  %117 = extractelement <8 x i64> %102, i32 0
  %118 = sub i64 %117, 0
  %119 = mul i64 %118, 4
  %buffer.contiguous.address32 = getelementptr i8, ptr %116, i64 %119
  call void @llvm.masked.store.v8f32.p0(<8 x float> %115, ptr %buffer.contiguous.address32, i32 1, <8 x i1> %51)
  %.state33 = load i64, ptr %.slot, align 4
  %120 = add i64 %.state33, 1
  store i64 %120, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.4:                                ; preds = %direct.false22
  %.spill.load34 = load <8 x i64>, ptr %.spill, align 64
  %121 = icmp slt <8 x i64> %.spill.load34, splat (i64 1)
  %122 = and <8 x i1> %51, %121
  %123 = xor <8 x i1> %121, splat (i1 true)
  %124 = and <8 x i1> %51, %123
  %125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %122)
  %126 = bitcast <8 x i1> %122 to i8
  %127 = call i8 @llvm.cttz.i8(i8 %126, i1 false)
  %128 = zext i8 %127 to i32
  %129 = select i1 %125, i32 %128, i32 0
  %.spill.load35 = load <8 x i64>, ptr %.spill, align 64
  %130 = add <8 x i64> splat (i64 4096), %.spill.load35
  %.spill.load36 = load <8 x i64>, ptr %.spill4, align 64
  %131 = add <8 x i64> %.spill.load36, zeroinitializer
  %132 = add <8 x i64> zeroinitializer, %131
  %133 = add <8 x i64> zeroinitializer, %130
  %134 = mul <8 x i64> %132, splat (i64 4097)
  %135 = add <8 x i64> %134, %133
  %136 = extractvalue { ptr, i64 } %9, 0
  %137 = select <8 x i1> %122, <8 x i64> %135, <8 x i64> zeroinitializer
  %138 = extractelement <8 x i64> %137, i32 %129
  %139 = zext i32 %129 to i64
  %140 = sub i64 %138, %139
  %141 = mul i64 %140, 4
  %buffer.contiguous.address37 = getelementptr i8, ptr %136, i64 %141
  %buffer.contiguous.load38 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address37, i32 1, <8 x i1> %122, <8 x float> zeroinitializer)
  %142 = fneg <8 x float> %buffer.contiguous.load38
  %143 = select <8 x i1> %122, <8 x float> %142, <8 x float> zeroinitializer
  %native.exp39 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %143)
  %.spill.load40 = load float, ptr %.spill5, align 4
  %.splatinsert41 = insertelement <8 x float> poison, float %.spill.load40, i64 0
  %.splat42 = shufflevector <8 x float> %.splatinsert41, <8 x float> poison, <8 x i32> zeroinitializer
  %144 = fadd <8 x float> %.splat42, %native.exp39
  %145 = fdiv <8 x float> %buffer.contiguous.load38, %144
  %146 = extractvalue { ptr, i64 } %15, 0
  %147 = select <8 x i1> %122, <8 x i64> %135, <8 x i64> zeroinitializer
  %148 = extractelement <8 x i64> %147, i32 %129
  %149 = zext i32 %129 to i64
  %150 = sub i64 %148, %149
  %151 = mul i64 %150, 4
  %buffer.contiguous.address43 = getelementptr i8, ptr %146, i64 %151
  %buffer.contiguous.load44 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address43, i32 1, <8 x i1> %122, <8 x float> zeroinitializer)
  %152 = fmul <8 x float> %145, %buffer.contiguous.load44
  %153 = extractvalue { ptr, i64 } %27, 0
  %154 = extractelement <8 x i64> %135, i32 %129
  %155 = zext i32 %129 to i64
  %156 = sub i64 %154, %155
  %157 = mul i64 %156, 4
  %buffer.contiguous.address45 = getelementptr i8, ptr %153, i64 %157
  call void @llvm.masked.store.v8f32.p0(<8 x float> %152, ptr %buffer.contiguous.address45, i32 1, <8 x i1> %122)
  %158 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %124)
  %159 = bitcast <8 x i1> %124 to i8
  %160 = call i8 @llvm.cttz.i8(i8 %159, i1 false)
  %161 = zext i8 %160 to i32
  %162 = select i1 %158, i32 %161, i32 0
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.20, %direct.schedule.4
  ret void

direct.schedule.7:                                ; preds = %direct.false
  %163 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %163, 0
  %166 = select <8 x i1> %51, <8 x ptr> %164, <8 x ptr> %165
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %163, 1
  %169 = select <8 x i1> %51, <8 x i64> %167, <8 x i64> %168
  %170 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %166, 0
  %171 = insertvalue { <8 x ptr>, <8 x i64> } %170, <8 x i64> %169, 1
  store { <8 x ptr>, <8 x i64> } %171, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot6, align 4
  br label %direct.schedule.8

direct.schedule.8:                                ; preds = %direct.schedule.9, %direct.schedule.7
  %.state46 = load i64, ptr %.slot6, align 4
  %172 = icmp slt i64 %.state46, 512
  br i1 %172, label %direct.true47, label %direct.false48

direct.schedule.9:                                ; preds = %direct.true47
  %.state49 = load i64, ptr %.slot6, align 4
  %173 = mul i64 %.state49, 8
  %.splatinsert50 = insertelement <8 x i64> poison, i64 %173, i64 0
  %.splat51 = shufflevector <8 x i64> %.splatinsert50, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load52 = load <8 x i64>, ptr %.spill, align 64
  %174 = add <8 x i64> %.splat51, %.spill.load52
  %.spill.load53 = load <8 x i64>, ptr %.spill4, align 64
  %175 = add <8 x i64> %.spill.load53, zeroinitializer
  %176 = add <8 x i64> zeroinitializer, %175
  %177 = add <8 x i64> zeroinitializer, %174
  %178 = mul <8 x i64> %176, splat (i64 4097)
  %179 = add <8 x i64> %178, %177
  %180 = extractvalue { ptr, i64 } %9, 0
  %181 = extractelement <8 x i64> %179, i32 0
  %182 = sub i64 %181, 0
  %183 = mul i64 %182, 4
  %buffer.contiguous.address54 = getelementptr i8, ptr %180, i64 %183
  %buffer.contiguous.load55 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address54, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state56 = load i64, ptr %.slot6, align 4
  %.splatinsert57 = insertelement <8 x i64> poison, i64 %.state56, i64 0
  %.splat58 = shufflevector <8 x i64> %.splatinsert57, <8 x i64> poison, <8 x i32> zeroinitializer
  %186 = mul <8 x i64> %.splat58, splat (i64 32)
  %187 = add <8 x i64> %185, %186
  %188 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %184, 0
  %189 = insertvalue { <8 x ptr>, <8 x i64> } %188, <8 x i64> %187, 1
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %189, 1
  %192 = extractelement <8 x ptr> %190, i32 0
  %193 = extractelement <8 x i64> %191, i32 0
  %194 = sub i64 %193, 0
  %195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %196 = select i1 %195, i64 %194, i64 0
  %private.contiguous.address = getelementptr i8, ptr %192, i64 %196
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %197 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load55, <8 x float> %private.contiguous.preserve
  store <8 x float> %197, ptr %private.contiguous.address, align 4
  %.state59 = load i64, ptr %.slot6, align 4
  %198 = add i64 %.state59, 1
  store i64 %198, ptr %.slot6, align 4
  br label %direct.schedule.8

direct.schedule.10:                               ; preds = %direct.false48
  %.spill.load60 = load <8 x i64>, ptr %.spill, align 64
  %199 = icmp slt <8 x i64> %.spill.load60, splat (i64 1)
  %200 = load <8 x i1>, ptr %.spill7, align 1
  %201 = select <8 x i1> %51, <8 x i1> %199, <8 x i1> %200
  store <8 x i1> %201, ptr %.spill7, align 1
  %202 = and <8 x i1> %51, %199
  %203 = xor <8 x i1> %199, splat (i1 true)
  %204 = and <8 x i1> %51, %203
  %205 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %202)
  %206 = bitcast <8 x i1> %202 to i8
  %207 = call i8 @llvm.cttz.i8(i8 %206, i1 false)
  %208 = zext i8 %207 to i32
  %209 = select i1 %205, i32 %208, i32 0
  %.spill.load61 = load <8 x i64>, ptr %.spill, align 64
  %210 = add <8 x i64> splat (i64 4096), %.spill.load61
  %.spill.load62 = load <8 x i64>, ptr %.spill4, align 64
  %211 = add <8 x i64> %.spill.load62, zeroinitializer
  %212 = add <8 x i64> zeroinitializer, %211
  %213 = add <8 x i64> zeroinitializer, %210
  %214 = mul <8 x i64> %212, splat (i64 4097)
  %215 = add <8 x i64> %214, %213
  %216 = extractvalue { ptr, i64 } %9, 0
  %217 = select <8 x i1> %202, <8 x i64> %215, <8 x i64> zeroinitializer
  %218 = extractelement <8 x i64> %217, i32 %209
  %219 = zext i32 %209 to i64
  %220 = sub i64 %218, %219
  %221 = mul i64 %220, 4
  %buffer.contiguous.address63 = getelementptr i8, ptr %216, i64 %221
  %buffer.contiguous.load64 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address63, i32 1, <8 x i1> %202, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %224 = add <8 x i64> %223, splat (i64 16384)
  %225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %226 = insertvalue { <8 x ptr>, <8 x i64> } %225, <8 x i64> %224, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %226, 1
  %229 = extractelement <8 x ptr> %227, i32 0
  %230 = extractelement <8 x i64> %228, i32 %209
  %231 = zext i32 %209 to i64
  %232 = mul i64 %231, 4
  %233 = sub i64 %230, %232
  %234 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %202)
  %235 = select i1 %234, i64 %233, i64 0
  %private.contiguous.address66 = getelementptr i8, ptr %229, i64 %235
  %private.contiguous.preserve67 = load <8 x float>, ptr %private.contiguous.address66, align 4
  %236 = select <8 x i1> %202, <8 x float> %buffer.contiguous.load64, <8 x float> %private.contiguous.preserve67
  store <8 x float> %236, ptr %private.contiguous.address66, align 4
  %237 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %204)
  %238 = bitcast <8 x i1> %204 to i8
  %239 = call i8 @llvm.cttz.i8(i8 %238, i1 false)
  %240 = zext i8 %239 to i32
  %241 = select i1 %237, i32 %240, i32 0
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.10
  %242 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %242, 0
  %245 = select <8 x i1> %51, <8 x ptr> %243, <8 x ptr> %244
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %242, 1
  %248 = select <8 x i1> %51, <8 x i64> %246, <8 x i64> %247
  %249 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %245, 0
  %250 = insertvalue { <8 x ptr>, <8 x i64> } %249, <8 x i64> %248, 1
  store { <8 x ptr>, <8 x i64> } %250, ptr %tile_snapshot.spill8, align 64
  %251 = load <8 x i64>, ptr %.slot9, align 64
  %252 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %251
  store <8 x i64> %252, ptr %.slot9, align 64
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state68 = load <8 x i64>, ptr %.slot9, align 64
  %253 = icmp slt <8 x i64> %.state68, splat (i64 512)
  %254 = extractelement <8 x i1> %253, i32 0
  br i1 %254, label %direct.true69, label %direct.false70

direct.schedule.14:                               ; preds = %direct.true69
  %.state71 = load <8 x i64>, ptr %.slot9, align 64
  %255 = mul <8 x i64> %.state71, splat (i64 8)
  %.spill.load72 = load <8 x i64>, ptr %.spill, align 64
  %256 = add <8 x i64> %255, %.spill.load72
  %.spill.load73 = load <8 x i64>, ptr %.spill4, align 64
  %257 = add <8 x i64> %.spill.load73, zeroinitializer
  %258 = add <8 x i64> zeroinitializer, %257
  %259 = add <8 x i64> zeroinitializer, %256
  %260 = mul <8 x i64> %258, splat (i64 4097)
  %261 = add <8 x i64> %260, %259
  %262 = extractvalue { ptr, i64 } %15, 0
  %263 = extractelement <8 x i64> %261, i32 0
  %264 = sub i64 %263, 0
  %265 = mul i64 %264, 4
  %buffer.contiguous.address74 = getelementptr i8, ptr %262, i64 %265
  %buffer.contiguous.load75 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address74, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load76 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 1
  %.state77 = load <8 x i64>, ptr %.slot9, align 64
  %268 = mul <8 x i64> %.state77, splat (i64 32)
  %269 = add <8 x i64> %267, %268
  %270 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %266, 0
  %271 = insertvalue { <8 x ptr>, <8 x i64> } %270, <8 x i64> %269, 1
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %271, 1
  %274 = extractelement <8 x ptr> %272, i32 0
  %275 = extractelement <8 x i64> %273, i32 0
  %276 = sub i64 %275, 0
  %277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %278 = select i1 %277, i64 %276, i64 0
  %private.contiguous.address78 = getelementptr i8, ptr %274, i64 %278
  %private.contiguous.preserve79 = load <8 x float>, ptr %private.contiguous.address78, align 4
  %279 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load75, <8 x float> %private.contiguous.preserve79
  store <8 x float> %279, ptr %private.contiguous.address78, align 4
  %.state80 = load <8 x i64>, ptr %.slot9, align 64
  %280 = add <8 x i64> %.state80, splat (i64 1)
  %281 = load <8 x i64>, ptr %.slot9, align 64
  %282 = select <8 x i1> %51, <8 x i64> %280, <8 x i64> %281
  store <8 x i64> %282, ptr %.slot9, align 64
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false70
  %.spill.load81 = load <8 x i1>, ptr %.spill7, align 1
  %283 = and <8 x i1> %51, %.spill.load81
  %284 = xor <8 x i1> %.spill.load81, splat (i1 true)
  %285 = and <8 x i1> %51, %284
  %286 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %283)
  %287 = bitcast <8 x i1> %283 to i8
  %288 = call i8 @llvm.cttz.i8(i8 %287, i1 false)
  %289 = zext i8 %288 to i32
  %290 = select i1 %286, i32 %289, i32 0
  %.spill.load82 = load <8 x i64>, ptr %.spill, align 64
  %291 = add <8 x i64> splat (i64 4096), %.spill.load82
  %.spill.load83 = load <8 x i64>, ptr %.spill4, align 64
  %292 = add <8 x i64> %.spill.load83, zeroinitializer
  %293 = add <8 x i64> zeroinitializer, %292
  %294 = add <8 x i64> zeroinitializer, %291
  %295 = mul <8 x i64> %293, splat (i64 4097)
  %296 = add <8 x i64> %295, %294
  %297 = extractvalue { ptr, i64 } %15, 0
  %298 = select <8 x i1> %283, <8 x i64> %296, <8 x i64> zeroinitializer
  %299 = extractelement <8 x i64> %298, i32 %290
  %300 = zext i32 %290 to i64
  %301 = sub i64 %299, %300
  %302 = mul i64 %301, 4
  %buffer.contiguous.address84 = getelementptr i8, ptr %297, i64 %302
  %buffer.contiguous.load85 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address84, i32 1, <8 x i1> %283, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load86 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 0
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 1
  %305 = add <8 x i64> %304, splat (i64 16384)
  %306 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %303, 0
  %307 = insertvalue { <8 x ptr>, <8 x i64> } %306, <8 x i64> %305, 1
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %307, 1
  %310 = extractelement <8 x ptr> %308, i32 0
  %311 = extractelement <8 x i64> %309, i32 %290
  %312 = zext i32 %290 to i64
  %313 = mul i64 %312, 4
  %314 = sub i64 %311, %313
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %283)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address87 = getelementptr i8, ptr %310, i64 %316
  %private.contiguous.preserve88 = load <8 x float>, ptr %private.contiguous.address87, align 4
  %317 = select <8 x i1> %283, <8 x float> %buffer.contiguous.load85, <8 x float> %private.contiguous.preserve88
  store <8 x float> %317, ptr %private.contiguous.address87, align 4
  %318 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %285)
  %319 = bitcast <8 x i1> %285 to i8
  %320 = call i8 @llvm.cttz.i8(i8 %319, i1 false)
  %321 = zext i8 %320 to i32
  %322 = select i1 %318, i32 %321, i32 0
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.15
  %323 = load <8 x i64>, ptr %.slot10, align 64
  %324 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %323
  store <8 x i64> %324, ptr %.slot10, align 64
  br label %direct.schedule.18

direct.schedule.18:                               ; preds = %direct.schedule.19, %direct.schedule.17
  %.state89 = load <8 x i64>, ptr %.slot10, align 64
  %325 = icmp slt <8 x i64> %.state89, splat (i64 512)
  %326 = extractelement <8 x i1> %325, i32 0
  br i1 %326, label %direct.true90, label %direct.false91

direct.schedule.19:                               ; preds = %direct.true90
  %.state92 = load <8 x i64>, ptr %.slot10, align 64
  %327 = mul <8 x i64> %.state92, splat (i64 8)
  %.spill.load93 = load <8 x i64>, ptr %.spill, align 64
  %328 = add <8 x i64> %327, %.spill.load93
  %.spill.load94 = load <8 x i64>, ptr %.spill4, align 64
  %329 = add <8 x i64> %.spill.load94, zeroinitializer
  %330 = add <8 x i64> zeroinitializer, %329
  %331 = add <8 x i64> zeroinitializer, %328
  %332 = mul <8 x i64> %330, splat (i64 4097)
  %333 = add <8 x i64> %332, %331
  %tile_snapshot.spill.load95 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 0
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 1
  %.state96 = load <8 x i64>, ptr %.slot10, align 64
  %336 = mul <8 x i64> %.state96, splat (i64 32)
  %337 = add <8 x i64> %335, %336
  %338 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %334, 0
  %339 = insertvalue { <8 x ptr>, <8 x i64> } %338, <8 x i64> %337, 1
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %339, 1
  %342 = extractelement <8 x ptr> %340, i32 0
  %343 = extractelement <8 x i64> %341, i32 0
  %344 = sub i64 %343, 0
  %345 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %346 = select i1 %345, i64 %344, i64 0
  %private.contiguous.address97 = getelementptr i8, ptr %342, i64 %346
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address97, align 4
  %347 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %348 = fneg <8 x float> %347
  %349 = select <8 x i1> %51, <8 x float> %348, <8 x float> zeroinitializer
  %native.exp98 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %349)
  %.spill.load99 = load float, ptr %.spill5, align 4
  %.splatinsert100 = insertelement <8 x float> poison, float %.spill.load99, i64 0
  %.splat101 = shufflevector <8 x float> %.splatinsert100, <8 x float> poison, <8 x i32> zeroinitializer
  %350 = fadd <8 x float> %.splat101, %native.exp98
  %351 = fdiv <8 x float> %347, %350
  %tile_snapshot.spill.load102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %352 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 0
  %353 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 1
  %.state103 = load <8 x i64>, ptr %.slot10, align 64
  %354 = mul <8 x i64> %.state103, splat (i64 32)
  %355 = add <8 x i64> %353, %354
  %356 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %352, 0
  %357 = insertvalue { <8 x ptr>, <8 x i64> } %356, <8 x i64> %355, 1
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %357, 1
  %360 = extractelement <8 x ptr> %358, i32 0
  %361 = extractelement <8 x i64> %359, i32 0
  %362 = sub i64 %361, 0
  %363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %364 = select i1 %363, i64 %362, i64 0
  %private.contiguous.address104 = getelementptr i8, ptr %360, i64 %364
  %private.contiguous.load105 = load <8 x float>, ptr %private.contiguous.address104, align 4
  %365 = select <8 x i1> %51, <8 x float> %private.contiguous.load105, <8 x float> zeroinitializer
  %366 = fmul <8 x float> %351, %365
  %367 = extractvalue { ptr, i64 } %27, 0
  %368 = extractelement <8 x i64> %333, i32 0
  %369 = sub i64 %368, 0
  %370 = mul i64 %369, 4
  %buffer.contiguous.address106 = getelementptr i8, ptr %367, i64 %370
  call void @llvm.masked.store.v8f32.p0(<8 x float> %366, ptr %buffer.contiguous.address106, i32 1, <8 x i1> %51)
  %.state107 = load <8 x i64>, ptr %.slot10, align 64
  %371 = add <8 x i64> %.state107, splat (i64 1)
  %372 = load <8 x i64>, ptr %.slot10, align 64
  %373 = select <8 x i1> %51, <8 x i64> %371, <8 x i64> %372
  store <8 x i64> %373, ptr %.slot10, align 64
  br label %direct.schedule.18

direct.schedule.20:                               ; preds = %direct.false91
  %.spill.load108 = load <8 x i1>, ptr %.spill7, align 1
  %374 = and <8 x i1> %51, %.spill.load108
  %375 = xor <8 x i1> %.spill.load108, splat (i1 true)
  %376 = and <8 x i1> %51, %375
  %377 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %374)
  %378 = bitcast <8 x i1> %374 to i8
  %379 = call i8 @llvm.cttz.i8(i8 %378, i1 false)
  %380 = zext i8 %379 to i32
  %381 = select i1 %377, i32 %380, i32 0
  %.spill.load109 = load <8 x i64>, ptr %.spill, align 64
  %382 = add <8 x i64> splat (i64 4096), %.spill.load109
  %.spill.load110 = load <8 x i64>, ptr %.spill4, align 64
  %383 = add <8 x i64> %.spill.load110, zeroinitializer
  %384 = add <8 x i64> zeroinitializer, %383
  %385 = add <8 x i64> zeroinitializer, %382
  %386 = mul <8 x i64> %384, splat (i64 4097)
  %387 = add <8 x i64> %386, %385
  %tile_snapshot.spill.load111 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %388 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 0
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 1
  %390 = add <8 x i64> %389, splat (i64 16384)
  %391 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %388, 0
  %392 = insertvalue { <8 x ptr>, <8 x i64> } %391, <8 x i64> %390, 1
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %392, 1
  %395 = extractelement <8 x ptr> %393, i32 0
  %396 = extractelement <8 x i64> %394, i32 %381
  %397 = zext i32 %381 to i64
  %398 = mul i64 %397, 4
  %399 = sub i64 %396, %398
  %400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %374)
  %401 = select i1 %400, i64 %399, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %395, i64 %401
  %private.contiguous.load113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %402 = select <8 x i1> %374, <8 x float> %private.contiguous.load113, <8 x float> zeroinitializer
  %403 = fneg <8 x float> %402
  %404 = select <8 x i1> %374, <8 x float> %403, <8 x float> zeroinitializer
  %native.exp114 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %404)
  %.spill.load115 = load float, ptr %.spill5, align 4
  %.splatinsert116 = insertelement <8 x float> poison, float %.spill.load115, i64 0
  %.splat117 = shufflevector <8 x float> %.splatinsert116, <8 x float> poison, <8 x i32> zeroinitializer
  %405 = fadd <8 x float> %.splat117, %native.exp114
  %406 = fdiv <8 x float> %402, %405
  %tile_snapshot.spill.load118 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill8, align 64
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 0
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 1
  %409 = add <8 x i64> %408, splat (i64 16384)
  %410 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %407, 0
  %411 = insertvalue { <8 x ptr>, <8 x i64> } %410, <8 x i64> %409, 1
  %412 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %413 = extractvalue { <8 x ptr>, <8 x i64> } %411, 1
  %414 = extractelement <8 x ptr> %412, i32 0
  %415 = extractelement <8 x i64> %413, i32 %381
  %416 = zext i32 %381 to i64
  %417 = mul i64 %416, 4
  %418 = sub i64 %415, %417
  %419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %374)
  %420 = select i1 %419, i64 %418, i64 0
  %private.contiguous.address119 = getelementptr i8, ptr %414, i64 %420
  %private.contiguous.load120 = load <8 x float>, ptr %private.contiguous.address119, align 4
  %421 = select <8 x i1> %374, <8 x float> %private.contiguous.load120, <8 x float> zeroinitializer
  %422 = fmul <8 x float> %406, %421
  %423 = extractvalue { ptr, i64 } %27, 0
  %424 = extractelement <8 x i64> %387, i32 %381
  %425 = zext i32 %381 to i64
  %426 = sub i64 %424, %425
  %427 = mul i64 %426, 4
  %buffer.contiguous.address121 = getelementptr i8, ptr %423, i64 %427
  call void @llvm.masked.store.v8f32.p0(<8 x float> %422, ptr %buffer.contiguous.address121, i32 1, <8 x i1> %374)
  %428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %376)
  %429 = bitcast <8 x i1> %376 to i8
  %430 = call i8 @llvm.cttz.i8(i8 %429, i1 false)
  %431 = zext i8 %430 to i32
  %432 = select i1 %428, i32 %431, i32 0
  br label %direct.schedule.6

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.0
  br label %direct.schedule.1

direct.false:                                     ; preds = %direct.schedule.0
  br label %direct.schedule.7

direct.true21:                                    ; preds = %direct.schedule.2
  br label %direct.schedule.3

direct.false22:                                   ; preds = %direct.schedule.2
  br label %direct.schedule.4

direct.true47:                                    ; preds = %direct.schedule.8
  br label %direct.schedule.9

direct.false48:                                   ; preds = %direct.schedule.8
  br label %direct.schedule.10

direct.true69:                                    ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false70:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true90:                                    ; preds = %direct.schedule.18
  br label %direct.schedule.19

direct.false91:                                   ; preds = %direct.schedule.18
  br label %direct.schedule.20
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  br label %packet.batch.full.loop

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full.loop
  ret void

packet.batch.full.loop:                           ; preds = %packet.batch.full.loop, %packet.batch.full
  %packet.index = phi i32 [ 0, %packet.batch.full ], [ %packet.index.next, %packet.batch.full.loop ]
  %packet.thread.offset = mul i32 %packet.index, 8
  %packet.thread.index = add i32 %base.thread.index, %packet.thread.offset
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config) #4
  %packet.index.next = add i32 %packet.index, 1
  %packet.batch.has.more = icmp ult i32 %packet.index.next, %packet_count
  br i1 %packet.batch.has.more, label %packet.batch.full.loop, label %packet.batch.exit

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #4 = { alwaysinline }

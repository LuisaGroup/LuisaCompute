
/private/tmp/luisa-packet-inline.UY1lIE/capture/swiglu-1024x4097/on/object/tile_xir_w8_36426_1788935102624464_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      2c:      	sub	sp, sp, #0x330
      30:      	str	x0, [sp, #0x10]
      34:      	str	w3, [sp, #0x30]
      38:      	cbz	w3, 0x20bc <ltmp0+0x20bc>
      3c:      	mov	w13, #0x0               ; =0
      40:      	ldp	w9, w8, [x2, #0x2c]
      44:      	stp	w8, w9, [sp, #0x28]
      48:      	mov	w10, #0x42d00000        ; =1120927744
      4c:      	ldp	w8, w9, [x2]
      50:      	mov	w11, #-0x3d380000       ; =-1027080192
      54:      	mov	w12, #0xaa3b            ; =43579
      58:      	movk	w12, #0x3fb8, lsl #16
      5c:      	movi.4s	v12, #0x4b, lsl #24
      60:      	dup.4s	v13, w10
      64:      	mov	w10, #0x7200            ; =29184
      68:      	movk	w10, #0xbf31, lsl #16
      6c:      	dup.4s	v14, w11
      70:      	mov	w11, #0xbe8e            ; =48782
      74:      	movk	w11, #0xb5bf, lsl #16
      78:      	dup.4s	v15, w12
      7c:      	mov	w12, #0x2bda            ; =11226
      80:      	movk	w12, #0x3950, lsl #16
      84:      	dup.4s	v11, w10
      88:      	mov	w10, #0x96c9            ; =38601
      8c:      	movk	w10, #0x3ab6, lsl #16
      90:      	dup.4s	v30, w11
      94:      	mov	w11, #0x88a6            ; =34982
      98:      	movk	w11, #0x3c08, lsl #16
      9c:      	dup.4s	v31, w12
      a0:      	mov	w12, #0xaa7a            ; =43642
      a4:      	movk	w12, #0x3d2a, lsl #16
      a8:      	dup.4s	v8, w10
      ac:      	mov	w10, #0xaaab            ; =43691
      b0:      	movk	w10, #0x3e2a, lsl #16
      b4:      	dup.4s	v9, w11
      b8:      	dup.4s	v10, w12
      bc:      	dup.4s	v27, w10
      c0:      	mov	w1, #0x4004             ; =16388
      c4:      	add	x28, sp, #0x4, lsl #12  ; =0x4000
      c8:      	add	x28, x28, #0x310
      cc:      	add	x3, sp, #0x2f0
      d0:      	mvni.4s	v28, #0x80, lsl #24
      d4:      	movi.4s	v21, #0x3f, lsl #24
      d8:      	fmov.4s	v22, #1.00000000
      dc:      	mvni.4s	v0, #0x7f, msl #16
      e0:      	fneg.4s	v24, v0
      e4:      	mvni.4s	v0, #0x3f, msl #16
      e8:      	fneg.4s	v25, v0
      ec:      	ldp	w10, w11, [x2, #0x8]
      f0:      	str	x2, [sp, #0x8]
      f4:      	str	x11, [sp, #0x20]
      f8:      	stp	q14, q13, [sp, #0x60]
      fc:      	str	q15, [sp, #0x50]
     100:      	stp	q11, q10, [sp, #0xc0]
     104:      	stp	q31, q30, [sp, #0x100]
     108:      	stp	q9, q8, [sp, #0xe0]
     10c:      	stp	q27, q22, [sp, #0x140]
     110:      	stp	q25, q24, [sp, #0x120]
     114:      	b	0x160 <ltmp0+0x160>
     118:      	ldr	x15, [sp, #0x40]
     11c:      	add	w8, w15, #0x1
     120:      	ldp	w11, w9, [sp, #0x28]
     124:      	cmp	w8, w9
     128:      	cset	w9, eq
     12c:      	csinc	w8, wzr, w15, eq
     130:      	ldp	w14, w12, [sp, #0x34]
     134:      	cinc	w10, w14, eq
     138:      	cmp	w10, w11
     13c:      	cset	w11, eq
     140:      	ands	w11, w9, w11
     144:      	csel	w9, wzr, w10, ne
     148:      	add	w10, w12, w11
     14c:      	ldr	w13, [sp, #0x3c]
     150:      	add	w13, w13, #0x1
     154:      	ldr	w11, [sp, #0x30]
     158:      	cmp	w13, w11
     15c:      	b.eq	0x20a8 <ltmp0+0x20a8>
     160:      	str	w13, [sp, #0x3c]
     164:      	mov	x13, x10
     168:      	mov	x14, x9
     16c:      	mov	x15, x8
     170:      	ubfiz	x8, x8, #5, #32
     174:      	ldr	x12, [sp, #0x20]
     178:      	cmp	x8, x12
     17c:      	csel	x9, x8, xzr, ls
     180:      	subs	x10, x12, x9
     184:      	cmp	x10, #0x20
     188:      	mov	w11, #0x20              ; =32
     18c:      	csel	x10, x10, x11, lo
     190:      	cmp	x12, x9
     194:      	ccmp	x8, x12, #0x2, hi
     198:      	csel	x9, x10, xzr, ls
     19c:      	mov	w8, #-0x3d300000        ; =-1026555904
     1a0:      	dup.4s	v1, w8
     1a4:      	mov	w8, #0x42c80000         ; =1120403456
     1a8:      	dup.4s	v0, w8
     1ac:      	stp	q1, q0, [sp, #0x160]
     1b0:      	cmp	x9, #0x20
     1b4:      	stp	w14, w13, [sp, #0x34]
     1b8:      	str	x15, [sp, #0x40]
     1bc:      	b.lo	0x804 <ltmp0+0x804>
     1c0:      	mov	x20, #0x0               ; =0
     1c4:      	ldr	x8, [sp, #0x10]
     1c8:      	ldr	x13, [x8]
     1cc:      	ldr	x21, [x8, #0x10]
     1d0:      	ldr	x26, [x8, #0x30]
     1d4:      	subs	x8, x13, x26
     1d8:      	mov	w11, #0xfff             ; =4095
     1dc:      	movk	w11, #0x100, lsl #16
     1e0:      	ccmp	x8, x11, #0x0, hs
     1e4:      	cset	w8, hi
     1e8:      	subs	x9, x26, x13
     1ec:      	ccmp	x9, x11, #0x0, hs
     1f0:      	csinc	w8, w8, wzr, ls
     1f4:      	subs	x9, x21, x26
     1f8:      	ccmp	x9, x11, #0x0, hs
     1fc:      	cset	w9, hi
     200:      	subs	x10, x26, x21
     204:      	ccmp	x10, x11, #0x0, hs
     208:      	csinc	w9, w9, wzr, ls
     20c:      	and	w19, w8, w9
     210:      	lsl	w11, w15, #2
     214:      	and	x8, x15, #0x7ffffff
     218:      	mov	w9, #0x10               ; =16
     21c:      	movk	w9, #0x1, lsl #16
     220:      	umaddl	x22, w8, w9, x26
     224:      	umaddl	x27, w8, w9, x21
     228:      	str	x13, [sp, #0xb0]
     22c:      	umaddl	x24, w8, w9, x13
     230:      	str	x11, [sp, #0x48]
     234:      	b	0x330 <ltmp0+0x330>
     238:      	movi.2d	v0, #0000000000000000
     23c:      	ldr	q1, [sp, #0x80]
     240:      	mov.s	v0[0], v1[0]
     244:      	fneg.4s	v1, v0
     248:      	movi.2d	v2, #0000000000000000
     24c:      	mov.s	v2[0], v1[0]
     250:      	ldp	q7, q6, [sp, #0x160]
     254:      	fcmge.4s	v1, v2, v7
     258:      	fcmge.4s	v3, v6, v2
     25c:      	and.16b	v1, v1, v3
     260:      	and.16b	v1, v1, v2
     264:      	fmul.4s	v3, v1, v15
     268:      	mov.16b	v4, v28
     26c:      	bsl.16b	v4, v12, v3
     270:      	fadd.4s	v3, v3, v4
     274:      	fsub.4s	v3, v3, v4
     278:      	fcvtzs.4s	v3, v3
     27c:      	scvtf.4s	v4, v3
     280:      	fmul.4s	v5, v4, v11
     284:      	fadd.4s	v1, v1, v5
     288:      	fmul.4s	v4, v4, v30
     28c:      	fadd.4s	v1, v1, v4
     290:      	fmul.4s	v4, v1, v31
     294:      	fadd.4s	v4, v4, v8
     298:      	fmul.4s	v4, v1, v4
     29c:      	fadd.4s	v4, v4, v9
     2a0:      	fmul.4s	v4, v1, v4
     2a4:      	fadd.4s	v4, v4, v10
     2a8:      	fmul.4s	v4, v1, v4
     2ac:      	fadd.4s	v4, v4, v27
     2b0:      	fmul.4s	v4, v1, v4
     2b4:      	fadd.4s	v4, v4, v21
     2b8:      	fmul.4s	v5, v1, v1
     2bc:      	fmul.4s	v4, v5, v4
     2c0:      	fadd.4s	v1, v1, v4
     2c4:      	fadd.4s	v1, v1, v22
     2c8:      	sshr.4s	v4, v3, #0x1
     2cc:      	shl.4s	v5, v4, #0x17
     2d0:      	add.4s	v5, v5, v22
     2d4:      	fmul.4s	v1, v1, v5
     2d8:      	sub.4s	v3, v3, v4
     2dc:      	shl.4s	v3, v3, #0x17
     2e0:      	add.4s	v3, v3, v22
     2e4:      	fmul.4s	v1, v1, v3
     2e8:      	fcmgt.4s	v3, v7, v2
     2ec:      	fcmgt.4s	v4, v2, v6
     2f0:      	fcmeq.4s	v2, v2, v2
     2f4:      	fadd.4s	v1, v1, v22
     2f8:      	bit.16b	v1, v22, v3
     2fc:      	bit.16b	v1, v24, v4
     300:      	bif.16b	v1, v25, v2
     304:      	fdiv.4s	v0, v0, v1
     308:      	fmul.4s	v0, v18, v0
     30c:      	mov	w1, #0x4004             ; =16388
     310:      	ldr	x11, [sp, #0x48]
     314:      	str	s0, [x26, x25]
     318:      	add	x20, x20, #0x1
     31c:      	add	x22, x22, x1
     320:      	add	x27, x27, x1
     324:      	add	x24, x24, x1
     328:      	cmp	x20, #0x4
     32c:      	b.eq	0x118 <ltmp0+0x118>
     330:      	add	w8, w20, w11
     334:      	and	x8, x8, #0x1fffffff
     338:      	add	x8, x8, x8, lsl #12
     33c:      	lsl	x23, x8, #2
     340:      	cbz	w19, 0x5c0 <ltmp0+0x5c0>
     344:      	mov	x8, #0x0                ; =0
     348:      	add	x9, x24, x8
     34c:      	ldp	q0, q1, [x9]
     350:      	fneg.4s	v2, v1
     354:      	fneg.4s	v3, v0
     358:      	fcmge.4s	v4, v13, v0
     35c:      	fcmge.4s	v5, v13, v1
     360:      	fcmge.4s	v6, v0, v14
     364:      	fcmge.4s	v7, v1, v14
     368:      	and.16b	v5, v5, v7
     36c:      	and.16b	v4, v4, v6
     370:      	and.16b	v3, v4, v3
     374:      	and.16b	v2, v5, v2
     378:      	fmul.4s	v4, v2, v15
     37c:      	fmul.4s	v5, v3, v15
     380:      	mov.16b	v6, v28
     384:      	bsl.16b	v6, v12, v5
     388:      	mov.16b	v7, v28
     38c:      	bsl.16b	v7, v12, v4
     390:      	fadd.4s	v4, v4, v7
     394:      	fadd.4s	v5, v5, v6
     398:      	fsub.4s	v5, v5, v6
     39c:      	fsub.4s	v4, v4, v7
     3a0:      	fcvtzs.4s	v4, v4
     3a4:      	fcvtzs.4s	v5, v5
     3a8:      	scvtf.4s	v6, v5
     3ac:      	scvtf.4s	v7, v4
     3b0:      	fmul.4s	v16, v7, v11
     3b4:      	fmul.4s	v17, v6, v11
     3b8:      	fadd.4s	v3, v3, v17
     3bc:      	fadd.4s	v2, v2, v16
     3c0:      	fmul.4s	v6, v6, v30
     3c4:      	fmul.4s	v7, v7, v30
     3c8:      	fadd.4s	v2, v2, v7
     3cc:      	fadd.4s	v3, v3, v6
     3d0:      	fmul.4s	v6, v3, v31
     3d4:      	fmul.4s	v7, v2, v31
     3d8:      	fadd.4s	v7, v7, v8
     3dc:      	fadd.4s	v6, v6, v8
     3e0:      	fmul.4s	v6, v3, v6
     3e4:      	fmul.4s	v7, v2, v7
     3e8:      	fadd.4s	v7, v7, v9
     3ec:      	fadd.4s	v6, v6, v9
     3f0:      	fmul.4s	v6, v3, v6
     3f4:      	fmul.4s	v7, v2, v7
     3f8:      	fadd.4s	v7, v7, v10
     3fc:      	fadd.4s	v6, v6, v10
     400:      	fmul.4s	v6, v3, v6
     404:      	fmul.4s	v7, v2, v7
     408:      	fadd.4s	v7, v7, v27
     40c:      	fadd.4s	v6, v6, v27
     410:      	fmul.4s	v6, v3, v6
     414:      	fmul.4s	v7, v2, v7
     418:      	fadd.4s	v7, v7, v21
     41c:      	fadd.4s	v6, v6, v21
     420:      	fmul.4s	v16, v2, v2
     424:      	fmul.4s	v17, v3, v3
     428:      	fmul.4s	v6, v17, v6
     42c:      	fmul.4s	v7, v16, v7
     430:      	fadd.4s	v2, v2, v7
     434:      	fadd.4s	v3, v3, v6
     438:      	sshr.4s	v6, v5, #0x1
     43c:      	fadd.4s	v3, v3, v22
     440:      	sshr.4s	v7, v4, #0x1
     444:      	shl.4s	v16, v7, #0x17
     448:      	shl.4s	v17, v6, #0x17
     44c:      	add.4s	v17, v17, v22
     450:      	add.4s	v16, v16, v22
     454:      	fadd.4s	v2, v2, v22
     458:      	fmul.4s	v2, v2, v16
     45c:      	sub.4s	v4, v4, v7
     460:      	sub.4s	v5, v5, v6
     464:      	shl.4s	v5, v5, #0x17
     468:      	shl.4s	v4, v4, #0x17
     46c:      	fmul.4s	v3, v3, v17
     470:      	add.4s	v4, v4, v22
     474:      	add.4s	v5, v5, v22
     478:      	fmul.4s	v3, v3, v5
     47c:      	fmul.4s	v2, v2, v4
     480:      	fcmgt.4s	v4, v1, v13
     484:      	fcmgt.4s	v5, v0, v13
     488:      	fcmgt.4s	v6, v14, v0
     48c:      	fcmgt.4s	v7, v14, v1
     490:      	fcmeq.4s	v16, v1, v1
     494:      	fadd.4s	v2, v2, v22
     498:      	fadd.4s	v3, v3, v22
     49c:      	fcmeq.4s	v17, v0, v0
     4a0:      	bit.16b	v3, v22, v5
     4a4:      	bit.16b	v2, v22, v4
     4a8:      	bit.16b	v2, v24, v7
     4ac:      	bit.16b	v3, v24, v6
     4b0:      	bif.16b	v3, v25, v17
     4b4:      	bif.16b	v2, v25, v16
     4b8:      	fdiv.4s	v1, v1, v2
     4bc:      	fdiv.4s	v0, v0, v3
     4c0:      	add	x9, x27, x8
     4c4:      	ldp	q3, q2, [x9]
     4c8:      	fmul.4s	v0, v3, v0
     4cc:      	fmul.4s	v1, v2, v1
     4d0:      	add	x9, x22, x8
     4d4:      	stp	q0, q1, [x9]
     4d8:      	add	x8, x8, #0x20
     4dc:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     4e0:      	b.ne	0x348 <ltmp0+0x348>
     4e4:      	add	x25, x23, #0x4, lsl #12 ; =0x4000
     4e8:      	ldr	x8, [sp, #0xb0]
     4ec:      	ldr	s0, [x8, x25]
     4f0:      	fneg.4s	v1, v0
     4f4:      	movi.2d	v2, #0000000000000000
     4f8:      	mov.s	v2[0], v1[0]
     4fc:      	ldp	q7, q6, [sp, #0x160]
     500:      	fcmge.4s	v1, v2, v7
     504:      	fcmge.4s	v3, v6, v2
     508:      	and.16b	v1, v1, v3
     50c:      	and.16b	v1, v1, v2
     510:      	fmul.4s	v3, v1, v15
     514:      	mov.16b	v4, v28
     518:      	bsl.16b	v4, v12, v3
     51c:      	fadd.4s	v3, v3, v4
     520:      	fsub.4s	v3, v3, v4
     524:      	fcvtzs.4s	v3, v3
     528:      	scvtf.4s	v4, v3
     52c:      	fmul.4s	v5, v4, v11
     530:      	fadd.4s	v1, v1, v5
     534:      	fmul.4s	v4, v4, v30
     538:      	fadd.4s	v1, v1, v4
     53c:      	fmul.4s	v4, v1, v31
     540:      	fadd.4s	v4, v4, v8
     544:      	fmul.4s	v4, v1, v4
     548:      	fadd.4s	v4, v4, v9
     54c:      	fmul.4s	v4, v1, v4
     550:      	fadd.4s	v4, v4, v10
     554:      	fmul.4s	v4, v1, v4
     558:      	fadd.4s	v4, v4, v27
     55c:      	fmul.4s	v4, v1, v4
     560:      	fadd.4s	v4, v4, v21
     564:      	fmul.4s	v5, v1, v1
     568:      	fmul.4s	v4, v5, v4
     56c:      	fadd.4s	v1, v1, v4
     570:      	fadd.4s	v1, v1, v22
     574:      	sshr.4s	v4, v3, #0x1
     578:      	shl.4s	v5, v4, #0x17
     57c:      	add.4s	v5, v5, v22
     580:      	fmul.4s	v1, v1, v5
     584:      	sub.4s	v3, v3, v4
     588:      	shl.4s	v3, v3, #0x17
     58c:      	add.4s	v3, v3, v22
     590:      	fmul.4s	v1, v1, v3
     594:      	fcmgt.4s	v3, v7, v2
     598:      	fcmgt.4s	v4, v2, v6
     59c:      	fcmeq.4s	v2, v2, v2
     5a0:      	fadd.4s	v1, v1, v22
     5a4:      	bit.16b	v1, v22, v3
     5a8:      	bit.16b	v1, v24, v4
     5ac:      	bif.16b	v1, v25, v2
     5b0:      	fdiv.4s	v0, v0, v1
     5b4:      	ldr	s1, [x21, x25]
     5b8:      	fmul.4s	v0, v1, v0
     5bc:      	b	0x314 <ltmp0+0x314>
     5c0:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     5c4:      	add	x0, x0, #0x310
     5c8:      	mov	x28, x21
     5cc:      	ldr	x21, [sp, #0xb0]
     5d0:      	add	x1, x21, x23
     5d4:      	mov	w2, #0x4000             ; =16384
     5d8:      	str	q18, [sp, #0x90]
     5dc:      	bl	0x5dc <ltmp0+0x5dc>
     5e0:      	add	x25, x23, #0x4, lsl #12 ; =0x4000
     5e4:      	ldr	s1, [x21, x25]
     5e8:      	mov	x21, x28
     5ec:      	add	x28, sp, #0x4, lsl #12  ; =0x4000
     5f0:      	add	x28, x28, #0x310
     5f4:      	ldr	q0, [sp, #0xa0]
     5f8:      	str	q1, [sp, #0x80]
     5fc:      	mov.s	v0[0], v1[0]
     600:      	str	q0, [sp, #0x8320]
     604:      	str	q0, [sp, #0xa0]
     608:      	str	q0, [sp, #0x8310]
     60c:      	add	x0, sp, #0x2f0
     610:      	add	x1, x21, x23
     614:      	mov	w2, #0x4000             ; =16384
     618:      	bl	0x618 <ltmp0+0x618>
     61c:      	ldr	q18, [sp, #0x90]
     620:      	add	x3, sp, #0x2f0
     624:      	ldp	q25, q24, [sp, #0x120]
     628:      	ldp	q27, q22, [sp, #0x140]
     62c:      	movi.4s	v21, #0x3f, lsl #24
     630:      	mvni.4s	v28, #0x80, lsl #24
     634:      	ldp	q10, q9, [sp, #0xd0]
     638:      	ldp	q8, q31, [sp, #0xf0]
     63c:      	ldr	q30, [sp, #0x110]
     640:      	ldr	q11, [sp, #0xc0]
     644:      	ldp	q15, q14, [sp, #0x50]
     648:      	ldr	q13, [sp, #0x70]
     64c:      	movi.4s	v12, #0x4b, lsl #24
     650:      	mov	x8, #0x0                ; =0
     654:      	add	x9, x21, x25
     658:      	ld1.s	{ v18 }[0], [x9]
     65c:      	str	q0, [sp, #0x4300]
     660:      	str	q18, [sp, #0x42f0]
     664:      	add	x9, x28, x8
     668:      	ldp	q0, q1, [x9]
     66c:      	fneg.4s	v2, v1
     670:      	fneg.4s	v3, v0
     674:      	fcmge.4s	v4, v13, v0
     678:      	fcmge.4s	v5, v13, v1
     67c:      	fcmge.4s	v6, v0, v14
     680:      	fcmge.4s	v7, v1, v14
     684:      	and.16b	v5, v5, v7
     688:      	and.16b	v4, v4, v6
     68c:      	and.16b	v3, v4, v3
     690:      	and.16b	v2, v5, v2
     694:      	fmul.4s	v4, v2, v15
     698:      	fmul.4s	v5, v3, v15
     69c:      	mov.16b	v6, v28
     6a0:      	bsl.16b	v6, v12, v5
     6a4:      	mov.16b	v7, v28
     6a8:      	bsl.16b	v7, v12, v4
     6ac:      	fadd.4s	v4, v4, v7
     6b0:      	fadd.4s	v5, v5, v6
     6b4:      	fsub.4s	v5, v5, v6
     6b8:      	fsub.4s	v4, v4, v7
     6bc:      	fcvtzs.4s	v4, v4
     6c0:      	fcvtzs.4s	v5, v5
     6c4:      	scvtf.4s	v6, v5
     6c8:      	scvtf.4s	v7, v4
     6cc:      	fmul.4s	v16, v7, v11
     6d0:      	fmul.4s	v17, v6, v11
     6d4:      	fadd.4s	v3, v3, v17
     6d8:      	fadd.4s	v2, v2, v16
     6dc:      	fmul.4s	v6, v6, v30
     6e0:      	fmul.4s	v7, v7, v30
     6e4:      	fadd.4s	v2, v2, v7
     6e8:      	fadd.4s	v3, v3, v6
     6ec:      	fmul.4s	v6, v3, v31
     6f0:      	fmul.4s	v7, v2, v31
     6f4:      	fadd.4s	v7, v7, v8
     6f8:      	fadd.4s	v6, v6, v8
     6fc:      	fmul.4s	v6, v3, v6
     700:      	fmul.4s	v7, v2, v7
     704:      	fadd.4s	v7, v7, v9
     708:      	fadd.4s	v6, v6, v9
     70c:      	fmul.4s	v6, v3, v6
     710:      	fmul.4s	v7, v2, v7
     714:      	fadd.4s	v7, v7, v10
     718:      	fadd.4s	v6, v6, v10
     71c:      	fmul.4s	v6, v3, v6
     720:      	fmul.4s	v7, v2, v7
     724:      	fadd.4s	v7, v7, v27
     728:      	fadd.4s	v6, v6, v27
     72c:      	fmul.4s	v6, v3, v6
     730:      	fmul.4s	v7, v2, v7
     734:      	fadd.4s	v7, v7, v21
     738:      	fadd.4s	v6, v6, v21
     73c:      	fmul.4s	v16, v2, v2
     740:      	fmul.4s	v17, v3, v3
     744:      	fmul.4s	v6, v17, v6
     748:      	fmul.4s	v7, v16, v7
     74c:      	fadd.4s	v2, v2, v7
     750:      	fadd.4s	v3, v3, v6
     754:      	sshr.4s	v6, v5, #0x1
     758:      	fadd.4s	v3, v3, v22
     75c:      	sshr.4s	v7, v4, #0x1
     760:      	shl.4s	v16, v7, #0x17
     764:      	shl.4s	v17, v6, #0x17
     768:      	add.4s	v17, v17, v22
     76c:      	add.4s	v16, v16, v22
     770:      	fadd.4s	v2, v2, v22
     774:      	fmul.4s	v2, v2, v16
     778:      	sub.4s	v4, v4, v7
     77c:      	sub.4s	v5, v5, v6
     780:      	shl.4s	v5, v5, #0x17
     784:      	shl.4s	v4, v4, #0x17
     788:      	fmul.4s	v3, v3, v17
     78c:      	add.4s	v4, v4, v22
     790:      	add.4s	v5, v5, v22
     794:      	fmul.4s	v3, v3, v5
     798:      	fmul.4s	v2, v2, v4
     79c:      	fcmgt.4s	v4, v1, v13
     7a0:      	fcmgt.4s	v5, v0, v13
     7a4:      	fcmgt.4s	v6, v14, v0
     7a8:      	fcmgt.4s	v7, v14, v1
     7ac:      	fcmeq.4s	v16, v1, v1
     7b0:      	fadd.4s	v2, v2, v22
     7b4:      	fadd.4s	v3, v3, v22
     7b8:      	fcmeq.4s	v17, v0, v0
     7bc:      	bit.16b	v3, v22, v5
     7c0:      	bit.16b	v2, v22, v4
     7c4:      	bit.16b	v2, v24, v7
     7c8:      	bit.16b	v3, v24, v6
     7cc:      	bif.16b	v3, v25, v17
     7d0:      	bif.16b	v2, v25, v16
     7d4:      	fdiv.4s	v1, v1, v2
     7d8:      	fdiv.4s	v0, v0, v3
     7dc:      	add	x9, x3, x8
     7e0:      	ldp	q3, q2, [x9]
     7e4:      	fmul.4s	v0, v3, v0
     7e8:      	fmul.4s	v1, v2, v1
     7ec:      	add	x9, x22, x8
     7f0:      	stp	q0, q1, [x9]
     7f4:      	add	x8, x8, #0x20
     7f8:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     7fc:      	b.ne	0x664 <ltmp0+0x664>
     800:      	b	0x238 <ltmp0+0x238>
     804:      	lsr	x12, x9, #3
     808:      	str	x9, [sp, #0x18]
     80c:      	cmp	x9, #0x8
     810:      	b.hs	0xcdc <ltmp0+0xcdc>
     814:      	ldr	x8, [sp, #0x18]
     818:      	and	w8, w8, #0x7
     81c:      	cbz	w8, 0x118 <ltmp0+0x118>
     820:      	dup.4s	v0, w8
     824:      	adrp	x8, 0x0 <ltmp0>
     828:      	ldr	q2, [x8]
     82c:      	adrp	x8, 0x0 <ltmp0>
     830:      	ldr	q1, [x8]
     834:      	cmhi.4s	v1, v0, v1
     838:      	cmhi.4s	v0, v0, v2
     83c:      	uzp1.8h	v19, v0, v1
     840:      	umaxv.8h	h2, v19
     844:      	fmov	w8, s2
     848:      	tbz	w8, #0x0, 0x118 <ltmp0+0x118>
     84c:      	ldr	x8, [sp, #0x10]
     850:      	ldr	x11, [x8]
     854:      	ldr	x9, [x8, #0x10]
     858:      	ldr	x8, [x8, #0x30]
     85c:      	sshll.2d	v5, v0, #0x0
     860:      	sshll.2d	v3, v1, #0x0
     864:      	sshll2.2d	v24, v0, #0x0
     868:      	sshll2.2d	v23, v1, #0x0
     86c:      	adrp	x10, 0x0 <ltmp0>
     870:      	ldr	q2, [x10]
     874:      	and.16b	v27, v23, v2
     878:      	adrp	x10, 0x0 <ltmp0>
     87c:      	ldr	q4, [x10]
     880:      	and.16b	v4, v24, v4
     884:      	adrp	x10, 0x0 <ltmp0>
     888:      	ldr	q6, [x10]
     88c:      	and.16b	v28, v3, v6
     890:      	adrp	x10, 0x0 <ltmp0>
     894:      	ldr	q6, [x10]
     898:      	and.16b	v3, v5, v6
     89c:      	ldr	x10, [sp, #0x40]
     8a0:      	ubfiz	w10, w10, #2, #27
     8a4:      	orr	w10, w10, w12
     8a8:      	dup.4s	v5, w10
     8ac:      	and.16b	v6, v0, v5
     8b0:      	and.16b	v5, v1, v5
     8b4:      	ushll2.2d	v7, v5, #0x0
     8b8:      	ushll2.2d	v16, v6, #0x0
     8bc:      	ushll.2d	v17, v5, #0x0
     8c0:      	ushll.2d	v5, v6, #0x0
     8c4:      	subs	x10, x11, x8
     8c8:      	mov	w14, #0xfff             ; =4095
     8cc:      	movk	w14, #0x100, lsl #16
     8d0:      	ccmp	x10, x14, #0x0, hs
     8d4:      	cset	w10, hi
     8d8:      	subs	x12, x8, x11
     8dc:      	ccmp	x12, x14, #0x0, hs
     8e0:      	csinc	w12, w10, wzr, ls
     8e4:      	subs	x10, x9, x8
     8e8:      	ccmp	x10, x14, #0x0, hs
     8ec:      	cset	w10, hi
     8f0:      	subs	x13, x8, x9
     8f4:      	ccmp	x13, x14, #0x0, hs
     8f8:      	csinc	w10, w10, wzr, ls
     8fc:      	xtn.2s	v20, v5
     900:      	fmov	x13, d5
     904:      	add	x13, x13, x13, lsl #12
     908:      	lsl	x14, x13, #2
     90c:      	xtn.2s	v2, v7
     910:      	str	d2, [sp, #0xb0]
     914:      	xtn.2s	v2, v17
     918:      	str	d2, [sp, #0xa0]
     91c:      	mov	w13, #0x1001            ; =4097
     920:      	dup.2s	v6, w13
     924:      	xtn.2s	v16, v16
     928:      	cmp	w12, #0x1
     92c:      	adrp	x0, 0x0 <ltmp0>
     930:      	b.ne	0x1304 <ltmp0+0x1304>
     934:      	cbz	w10, 0x1304 <ltmp0+0x1304>
     938:      	stp	q28, q27, [sp, #0x80]
     93c:      	movi.4s	v18, #0x3f, lsl #24
     940:      	mov	x10, #0x0               ; =0
     944:      	add	x12, x8, x14
     948:      	add	x13, x9, x14
     94c:      	add	x14, x11, x14
     950:      	b	0x960 <ltmp0+0x960>
     954:      	add	x10, x10, #0x20
     958:      	cmp	x10, #0x4, lsl #12      ; =0x4000
     95c:      	b.eq	0x1c9c <ltmp0+0x1c9c>
     960:      	ldr	q17, [x0]
     964:      	and.16b	v17, v19, v17
     968:      	addv.8h	h21, v17
     96c:      	fmov	w16, s21
     970:      	add	x15, x14, x10
     974:      	movi.2d	v22, #0000000000000000
     978:      	movi.2d	v17, #0000000000000000
     97c:      	tbz	w16, #0x0, 0xa10 <ltmp0+0xa10>
     980:      	ldr	s22, [x15]
     984:      	and	w16, w16, #0xff
     988:      	tbnz	w16, #0x1, 0xa18 <ltmp0+0xa18>
     98c:      	tbz	w16, #0x2, 0xa24 <ltmp0+0xa24>
     990:      	add	x17, x15, #0x8
     994:      	ld1.s	{ v22 }[2], [x17]
     998:      	tbnz	w16, #0x3, 0xa28 <ltmp0+0xa28>
     99c:      	tbz	w16, #0x4, 0xa34 <ltmp0+0xa34>
     9a0:      	add	x17, x15, #0x10
     9a4:      	ld1.s	{ v17 }[0], [x17]
     9a8:      	tbnz	w16, #0x5, 0xa38 <ltmp0+0xa38>
     9ac:      	tbz	w16, #0x6, 0xa44 <ltmp0+0xa44>
     9b0:      	add	x17, x15, #0x18
     9b4:      	ld1.s	{ v17 }[2], [x17]
     9b8:      	tbnz	w16, #0x7, 0xa48 <ltmp0+0xa48>
     9bc:      	fmov	w16, s21
     9c0:      	add	x15, x13, x10
     9c4:      	movi.2d	v24, #0000000000000000
     9c8:      	movi.2d	v23, #0000000000000000
     9cc:      	tbz	w16, #0x0, 0xa64 <ltmp0+0xa64>
     9d0:      	ldr	s24, [x15]
     9d4:      	and	w16, w16, #0xff
     9d8:      	tbnz	w16, #0x1, 0xa6c <ltmp0+0xa6c>
     9dc:      	tbz	w16, #0x2, 0xa78 <ltmp0+0xa78>
     9e0:      	add	x17, x15, #0x8
     9e4:      	ld1.s	{ v24 }[2], [x17]
     9e8:      	tbnz	w16, #0x3, 0xa7c <ltmp0+0xa7c>
     9ec:      	tbz	w16, #0x4, 0xa88 <ltmp0+0xa88>
     9f0:      	add	x17, x15, #0x10
     9f4:      	ld1.s	{ v23 }[0], [x17]
     9f8:      	tbnz	w16, #0x5, 0xa8c <ltmp0+0xa8c>
     9fc:      	tbz	w16, #0x6, 0xa98 <ltmp0+0xa98>
     a00:      	add	x17, x15, #0x18
     a04:      	ld1.s	{ v23 }[2], [x17]
     a08:      	tbnz	w16, #0x7, 0xa9c <ltmp0+0xa9c>
     a0c:      	b	0xaa4 <ltmp0+0xaa4>
     a10:      	and	w16, w16, #0xff
     a14:      	tbz	w16, #0x1, 0x98c <ltmp0+0x98c>
     a18:      	add	x17, x15, #0x4
     a1c:      	ld1.s	{ v22 }[1], [x17]
     a20:      	tbnz	w16, #0x2, 0x990 <ltmp0+0x990>
     a24:      	tbz	w16, #0x3, 0x99c <ltmp0+0x99c>
     a28:      	add	x17, x15, #0xc
     a2c:      	ld1.s	{ v22 }[3], [x17]
     a30:      	tbnz	w16, #0x4, 0x9a0 <ltmp0+0x9a0>
     a34:      	tbz	w16, #0x5, 0x9ac <ltmp0+0x9ac>
     a38:      	add	x17, x15, #0x14
     a3c:      	ld1.s	{ v17 }[1], [x17]
     a40:      	tbnz	w16, #0x6, 0x9b0 <ltmp0+0x9b0>
     a44:      	tbz	w16, #0x7, 0x9bc <ltmp0+0x9bc>
     a48:      	add	x15, x15, #0x1c
     a4c:      	ld1.s	{ v17 }[3], [x15]
     a50:      	fmov	w16, s21
     a54:      	add	x15, x13, x10
     a58:      	movi.2d	v24, #0000000000000000
     a5c:      	movi.2d	v23, #0000000000000000
     a60:      	tbnz	w16, #0x0, 0x9d0 <ltmp0+0x9d0>
     a64:      	and	w16, w16, #0xff
     a68:      	tbz	w16, #0x1, 0x9dc <ltmp0+0x9dc>
     a6c:      	add	x17, x15, #0x4
     a70:      	ld1.s	{ v24 }[1], [x17]
     a74:      	tbnz	w16, #0x2, 0x9e0 <ltmp0+0x9e0>
     a78:      	tbz	w16, #0x3, 0x9ec <ltmp0+0x9ec>
     a7c:      	add	x17, x15, #0xc
     a80:      	ld1.s	{ v24 }[3], [x17]
     a84:      	tbnz	w16, #0x4, 0x9f0 <ltmp0+0x9f0>
     a88:      	tbz	w16, #0x5, 0x9fc <ltmp0+0x9fc>
     a8c:      	add	x17, x15, #0x14
     a90:      	ld1.s	{ v23 }[1], [x17]
     a94:      	tbnz	w16, #0x6, 0xa00 <ltmp0+0xa00>
     a98:      	tbz	w16, #0x7, 0xaa4 <ltmp0+0xaa4>
     a9c:      	add	x15, x15, #0x1c
     aa0:      	ld1.s	{ v23 }[3], [x15]
     aa4:      	fneg.4s	v25, v22
     aa8:      	and.16b	v25, v0, v25
     aac:      	ldp	q7, q5, [sp, #0x160]
     ab0:      	fcmge.4s	v26, v25, v7
     ab4:      	fcmge.4s	v27, v5, v25
     ab8:      	and.16b	v26, v26, v27
     abc:      	and.16b	v26, v26, v25
     ac0:      	fmul.4s	v27, v26, v15
     ac4:      	mvni.4s	v28, #0x80, lsl #24
     ac8:      	bsl.16b	v28, v12, v27
     acc:      	fadd.4s	v27, v27, v28
     ad0:      	fsub.4s	v27, v27, v28
     ad4:      	fcvtzs.4s	v27, v27
     ad8:      	scvtf.4s	v28, v27
     adc:      	fmul.4s	v29, v28, v11
     ae0:      	fadd.4s	v26, v26, v29
     ae4:      	fmul.4s	v28, v28, v30
     ae8:      	fadd.4s	v26, v26, v28
     aec:      	fmul.4s	v28, v26, v31
     af0:      	fadd.4s	v28, v28, v8
     af4:      	fmul.4s	v28, v26, v28
     af8:      	fadd.4s	v28, v28, v9
     afc:      	fmul.4s	v28, v26, v28
     b00:      	fadd.4s	v28, v28, v10
     b04:      	fmul.4s	v28, v26, v28
     b08:      	ldp	q29, q2, [sp, #0x140]
     b0c:      	fadd.4s	v28, v28, v29
     b10:      	fmul.4s	v28, v26, v28
     b14:      	fadd.4s	v28, v28, v18
     b18:      	fmul.4s	v29, v26, v26
     b1c:      	fmul.4s	v28, v29, v28
     b20:      	fadd.4s	v26, v26, v28
     b24:      	fadd.4s	v26, v26, v2
     b28:      	sshr.4s	v28, v27, #0x1
     b2c:      	shl.4s	v29, v28, #0x17
     b30:      	add.4s	v29, v29, v2
     b34:      	fmul.4s	v26, v26, v29
     b38:      	sub.4s	v27, v27, v28
     b3c:      	shl.4s	v27, v27, #0x17
     b40:      	add.4s	v27, v27, v2
     b44:      	fmul.4s	v26, v26, v27
     b48:      	fcmgt.4s	v27, v7, v25
     b4c:      	fcmgt.4s	v28, v25, v5
     b50:      	fcmeq.4s	v25, v25, v25
     b54:      	fadd.4s	v26, v26, v2
     b58:      	bit.16b	v26, v2, v27
     b5c:      	ldp	q2, q5, [sp, #0x120]
     b60:      	bit.16b	v26, v5, v28
     b64:      	bsl.16b	v25, v26, v2
     b68:      	fdiv.4s	v22, v22, v25
     b6c:      	fmov	w16, s21
     b70:      	fmul.4s	v21, v24, v22
     b74:      	add	x15, x12, x10
     b78:      	tbz	w16, #0x0, 0xba4 <ltmp0+0xba4>
     b7c:      	str	s21, [x15]
     b80:      	and	w16, w16, #0xff
     b84:      	tbnz	w16, #0x1, 0xbac <ltmp0+0xbac>
     b88:      	ldr	q27, [sp, #0x140]
     b8c:      	mvni.4s	v28, #0x80, lsl #24
     b90:      	tbz	w16, #0x2, 0xbc0 <ltmp0+0xbc0>
     b94:      	add	x17, x15, #0x8
     b98:      	st1.s	{ v21 }[2], [x17]
     b9c:      	tbnz	w16, #0x3, 0xbc4 <ltmp0+0xbc4>
     ba0:      	b	0xbcc <ltmp0+0xbcc>
     ba4:      	and	w16, w16, #0xff
     ba8:      	tbz	w16, #0x1, 0xb88 <ltmp0+0xb88>
     bac:      	add	x17, x15, #0x4
     bb0:      	st1.s	{ v21 }[1], [x17]
     bb4:      	ldr	q27, [sp, #0x140]
     bb8:      	mvni.4s	v28, #0x80, lsl #24
     bbc:      	tbnz	w16, #0x2, 0xb94 <ltmp0+0xb94>
     bc0:      	tbz	w16, #0x3, 0xbcc <ltmp0+0xbcc>
     bc4:      	add	x17, x15, #0xc
     bc8:      	st1.s	{ v21 }[3], [x17]
     bcc:      	fneg.4s	v21, v17
     bd0:      	and.16b	v21, v1, v21
     bd4:      	ldp	q7, q5, [sp, #0x160]
     bd8:      	fcmge.4s	v22, v21, v7
     bdc:      	fcmge.4s	v24, v5, v21
     be0:      	and.16b	v22, v22, v24
     be4:      	and.16b	v22, v22, v21
     be8:      	fmul.4s	v24, v22, v15
     bec:      	mov.16b	v25, v28
     bf0:      	bsl.16b	v25, v12, v24
     bf4:      	fadd.4s	v24, v24, v25
     bf8:      	fsub.4s	v24, v24, v25
     bfc:      	fcvtzs.4s	v24, v24
     c00:      	scvtf.4s	v25, v24
     c04:      	fmul.4s	v26, v25, v11
     c08:      	fadd.4s	v22, v22, v26
     c0c:      	fmul.4s	v25, v25, v30
     c10:      	fadd.4s	v22, v22, v25
     c14:      	fmul.4s	v25, v22, v31
     c18:      	fadd.4s	v25, v25, v8
     c1c:      	fmul.4s	v25, v22, v25
     c20:      	fadd.4s	v25, v25, v9
     c24:      	fmul.4s	v25, v22, v25
     c28:      	fadd.4s	v25, v25, v10
     c2c:      	fmul.4s	v25, v22, v25
     c30:      	fadd.4s	v25, v25, v27
     c34:      	fmul.4s	v25, v22, v25
     c38:      	fadd.4s	v25, v25, v18
     c3c:      	fmul.4s	v26, v22, v22
     c40:      	fmul.4s	v25, v26, v25
     c44:      	fadd.4s	v22, v22, v25
     c48:      	ldr	q2, [sp, #0x150]
     c4c:      	fadd.4s	v22, v22, v2
     c50:      	sshr.4s	v25, v24, #0x1
     c54:      	shl.4s	v26, v25, #0x17
     c58:      	add.4s	v26, v26, v2
     c5c:      	fmul.4s	v22, v22, v26
     c60:      	sub.4s	v24, v24, v25
     c64:      	shl.4s	v24, v24, #0x17
     c68:      	add.4s	v24, v24, v2
     c6c:      	fmul.4s	v22, v22, v24
     c70:      	fcmgt.4s	v24, v7, v21
     c74:      	fcmgt.4s	v25, v21, v5
     c78:      	fcmeq.4s	v21, v21, v21
     c7c:      	fadd.4s	v22, v22, v2
     c80:      	bit.16b	v22, v2, v24
     c84:      	ldr	q24, [sp, #0x130]
     c88:      	bit.16b	v22, v24, v25
     c8c:      	ldr	q25, [sp, #0x120]
     c90:      	bsl.16b	v21, v22, v25
     c94:      	fdiv.4s	v17, v17, v21
     c98:      	fmul.4s	v17, v23, v17
     c9c:      	tbz	w16, #0x4, 0xcbc <ltmp0+0xcbc>
     ca0:      	str	s17, [x15, #0x10]
     ca4:      	tbnz	w16, #0x5, 0xcc0 <ltmp0+0xcc0>
     ca8:      	tbz	w16, #0x6, 0xccc <ltmp0+0xccc>
     cac:      	add	x17, x15, #0x18
     cb0:      	st1.s	{ v17 }[2], [x17]
     cb4:      	tbz	w16, #0x7, 0x954 <ltmp0+0x954>
     cb8:      	b	0xcd0 <ltmp0+0xcd0>
     cbc:      	tbz	w16, #0x5, 0xca8 <ltmp0+0xca8>
     cc0:      	add	x17, x15, #0x14
     cc4:      	st1.s	{ v17 }[1], [x17]
     cc8:      	tbnz	w16, #0x6, 0xcac <ltmp0+0xcac>
     ccc:      	tbz	w16, #0x7, 0x954 <ltmp0+0x954>
     cd0:      	add	x15, x15, #0x1c
     cd4:      	st1.s	{ v17 }[3], [x15]
     cd8:      	b	0x954 <ltmp0+0x954>
     cdc:      	mov	x21, #0x0               ; =0
     ce0:      	ldr	x8, [sp, #0x10]
     ce4:      	ldr	x13, [x8]
     ce8:      	ldr	x23, [x8, #0x10]
     cec:      	ldr	x14, [x8, #0x30]
     cf0:      	subs	x8, x13, x14
     cf4:      	mov	w11, #0xfff             ; =4095
     cf8:      	movk	w11, #0x100, lsl #16
     cfc:      	ccmp	x8, x11, #0x0, hs
     d00:      	cset	w8, hi
     d04:      	subs	x9, x14, x13
     d08:      	ccmp	x9, x11, #0x0, hs
     d0c:      	csinc	w8, w8, wzr, ls
     d10:      	subs	x9, x23, x14
     d14:      	ccmp	x9, x11, #0x0, hs
     d18:      	cset	w9, hi
     d1c:      	subs	x10, x14, x23
     d20:      	ccmp	x10, x11, #0x0, hs
     d24:      	csinc	w9, w9, wzr, ls
     d28:      	and	w19, w8, w9
     d2c:      	ldr	x8, [sp, #0x40]
     d30:      	lsl	w11, w8, #2
     d34:      	and	x8, x8, #0x7ffffff
     d38:      	mov	w9, #0x10               ; =16
     d3c:      	movk	w9, #0x1, lsl #16
     d40:      	umaddl	x26, w8, w9, x14
     d44:      	umaddl	x20, w8, w9, x23
     d48:      	str	x13, [sp, #0xb0]
     d4c:      	umaddl	x22, w8, w9, x13
     d50:      	str	x12, [sp, #0x90]
     d54:      	str	x14, [sp, #0x80]
     d58:      	str	x11, [sp, #0x48]
     d5c:      	b	0xe60 <ltmp0+0xe60>
     d60:      	movi.2d	v1, #0000000000000000
     d64:      	ldr	q2, [sp, #0xa0]
     d68:      	mov.s	v1[0], v2[0]
     d6c:      	fneg.4s	v2, v1
     d70:      	movi.2d	v3, #0000000000000000
     d74:      	mov.s	v3[0], v2[0]
     d78:      	ldp	q16, q7, [sp, #0x160]
     d7c:      	fcmge.4s	v2, v3, v16
     d80:      	fcmge.4s	v4, v7, v3
     d84:      	and.16b	v2, v2, v4
     d88:      	and.16b	v2, v2, v3
     d8c:      	fmul.4s	v4, v2, v15
     d90:      	mov.16b	v5, v28
     d94:      	bsl.16b	v5, v12, v4
     d98:      	fadd.4s	v4, v4, v5
     d9c:      	fsub.4s	v4, v4, v5
     da0:      	fcvtzs.4s	v4, v4
     da4:      	scvtf.4s	v5, v4
     da8:      	fmul.4s	v6, v5, v11
     dac:      	fadd.4s	v2, v2, v6
     db0:      	fmul.4s	v5, v5, v30
     db4:      	fadd.4s	v2, v2, v5
     db8:      	fmul.4s	v5, v2, v31
     dbc:      	fadd.4s	v5, v5, v8
     dc0:      	fmul.4s	v5, v2, v5
     dc4:      	fadd.4s	v5, v5, v9
     dc8:      	fmul.4s	v5, v2, v5
     dcc:      	fadd.4s	v5, v5, v10
     dd0:      	fmul.4s	v5, v2, v5
     dd4:      	fadd.4s	v5, v5, v27
     dd8:      	fmul.4s	v5, v2, v5
     ddc:      	fadd.4s	v5, v5, v21
     de0:      	fmul.4s	v6, v2, v2
     de4:      	fmul.4s	v5, v6, v5
     de8:      	fadd.4s	v2, v2, v5
     dec:      	fadd.4s	v2, v2, v22
     df0:      	sshr.4s	v5, v4, #0x1
     df4:      	shl.4s	v6, v5, #0x17
     df8:      	add.4s	v6, v6, v22
     dfc:      	fmul.4s	v2, v2, v6
     e00:      	sub.4s	v4, v4, v5
     e04:      	shl.4s	v4, v4, #0x17
     e08:      	add.4s	v4, v4, v22
     e0c:      	fmul.4s	v2, v2, v4
     e10:      	fcmgt.4s	v4, v16, v3
     e14:      	fcmgt.4s	v5, v3, v7
     e18:      	fcmeq.4s	v3, v3, v3
     e1c:      	fadd.4s	v2, v2, v22
     e20:      	bit.16b	v2, v22, v4
     e24:      	bit.16b	v2, v24, v5
     e28:      	bif.16b	v2, v25, v3
     e2c:      	fdiv.4s	v1, v1, v2
     e30:      	fmul.4s	v0, v0, v1
     e34:      	mov	w1, #0x4004             ; =16388
     e38:      	ldr	x12, [sp, #0x90]
     e3c:      	ldr	x14, [sp, #0x80]
     e40:      	ldr	x11, [sp, #0x48]
     e44:      	str	s0, [x14, x27]
     e48:      	add	x21, x21, #0x1
     e4c:      	add	x26, x26, x1
     e50:      	add	x20, x20, x1
     e54:      	add	x22, x22, x1
     e58:      	cmp	x21, x12
     e5c:      	b.eq	0x814 <ltmp0+0x814>
     e60:      	add	w8, w21, w11
     e64:      	and	x8, x8, #0x1fffffff
     e68:      	add	x8, x8, x8, lsl #12
     e6c:      	lsl	x25, x8, #2
     e70:      	cbz	w19, 0x10f0 <ltmp0+0x10f0>
     e74:      	mov	x8, #0x0                ; =0
     e78:      	add	x9, x22, x8
     e7c:      	ldp	q0, q1, [x9]
     e80:      	fneg.4s	v2, v1
     e84:      	fneg.4s	v3, v0
     e88:      	fcmge.4s	v4, v13, v0
     e8c:      	fcmge.4s	v5, v13, v1
     e90:      	fcmge.4s	v6, v0, v14
     e94:      	fcmge.4s	v7, v1, v14
     e98:      	and.16b	v5, v5, v7
     e9c:      	and.16b	v4, v4, v6
     ea0:      	and.16b	v3, v4, v3
     ea4:      	and.16b	v2, v5, v2
     ea8:      	fmul.4s	v4, v2, v15
     eac:      	fmul.4s	v5, v3, v15
     eb0:      	mov.16b	v6, v28
     eb4:      	bsl.16b	v6, v12, v5
     eb8:      	mov.16b	v7, v28
     ebc:      	bsl.16b	v7, v12, v4
     ec0:      	fadd.4s	v4, v4, v7
     ec4:      	fadd.4s	v5, v5, v6
     ec8:      	fsub.4s	v5, v5, v6
     ecc:      	fsub.4s	v4, v4, v7
     ed0:      	fcvtzs.4s	v4, v4
     ed4:      	fcvtzs.4s	v5, v5
     ed8:      	scvtf.4s	v6, v5
     edc:      	scvtf.4s	v7, v4
     ee0:      	fmul.4s	v16, v7, v11
     ee4:      	fmul.4s	v17, v6, v11
     ee8:      	fadd.4s	v3, v3, v17
     eec:      	fadd.4s	v2, v2, v16
     ef0:      	fmul.4s	v6, v6, v30
     ef4:      	fmul.4s	v7, v7, v30
     ef8:      	fadd.4s	v2, v2, v7
     efc:      	fadd.4s	v3, v3, v6
     f00:      	fmul.4s	v6, v3, v31
     f04:      	fmul.4s	v7, v2, v31
     f08:      	fadd.4s	v7, v7, v8
     f0c:      	fadd.4s	v6, v6, v8
     f10:      	fmul.4s	v6, v3, v6
     f14:      	fmul.4s	v7, v2, v7
     f18:      	fadd.4s	v7, v7, v9
     f1c:      	fadd.4s	v6, v6, v9
     f20:      	fmul.4s	v6, v3, v6
     f24:      	fmul.4s	v7, v2, v7
     f28:      	fadd.4s	v7, v7, v10
     f2c:      	fadd.4s	v6, v6, v10
     f30:      	fmul.4s	v6, v3, v6
     f34:      	fmul.4s	v7, v2, v7
     f38:      	fadd.4s	v7, v7, v27
     f3c:      	fadd.4s	v6, v6, v27
     f40:      	fmul.4s	v6, v3, v6
     f44:      	fmul.4s	v7, v2, v7
     f48:      	fadd.4s	v7, v7, v21
     f4c:      	fadd.4s	v6, v6, v21
     f50:      	fmul.4s	v16, v2, v2
     f54:      	fmul.4s	v17, v3, v3
     f58:      	fmul.4s	v6, v17, v6
     f5c:      	fmul.4s	v7, v16, v7
     f60:      	fadd.4s	v2, v2, v7
     f64:      	fadd.4s	v3, v3, v6
     f68:      	sshr.4s	v6, v5, #0x1
     f6c:      	fadd.4s	v3, v3, v22
     f70:      	sshr.4s	v7, v4, #0x1
     f74:      	shl.4s	v16, v7, #0x17
     f78:      	shl.4s	v17, v6, #0x17
     f7c:      	add.4s	v17, v17, v22
     f80:      	add.4s	v16, v16, v22
     f84:      	fadd.4s	v2, v2, v22
     f88:      	fmul.4s	v2, v2, v16
     f8c:      	sub.4s	v4, v4, v7
     f90:      	sub.4s	v5, v5, v6
     f94:      	shl.4s	v5, v5, #0x17
     f98:      	shl.4s	v4, v4, #0x17
     f9c:      	fmul.4s	v3, v3, v17
     fa0:      	add.4s	v4, v4, v22
     fa4:      	add.4s	v5, v5, v22
     fa8:      	fmul.4s	v3, v3, v5
     fac:      	fmul.4s	v2, v2, v4
     fb0:      	fcmgt.4s	v4, v1, v13
     fb4:      	fcmgt.4s	v5, v0, v13
     fb8:      	fcmgt.4s	v6, v14, v0
     fbc:      	fcmgt.4s	v7, v14, v1
     fc0:      	fcmeq.4s	v16, v1, v1
     fc4:      	fadd.4s	v2, v2, v22
     fc8:      	fadd.4s	v3, v3, v22
     fcc:      	fcmeq.4s	v17, v0, v0
     fd0:      	bit.16b	v3, v22, v5
     fd4:      	bit.16b	v2, v22, v4
     fd8:      	bit.16b	v2, v24, v7
     fdc:      	bit.16b	v3, v24, v6
     fe0:      	bif.16b	v3, v25, v17
     fe4:      	bif.16b	v2, v25, v16
     fe8:      	fdiv.4s	v1, v1, v2
     fec:      	fdiv.4s	v0, v0, v3
     ff0:      	add	x9, x20, x8
     ff4:      	ldp	q3, q2, [x9]
     ff8:      	fmul.4s	v0, v3, v0
     ffc:      	fmul.4s	v1, v2, v1
    1000:      	add	x9, x26, x8
    1004:      	stp	q0, q1, [x9]
    1008:      	add	x8, x8, #0x20
    100c:      	cmp	x8, #0x4, lsl #12       ; =0x4000
    1010:      	b.ne	0xe78 <ltmp0+0xe78>
    1014:      	add	x27, x25, #0x4, lsl #12 ; =0x4000
    1018:      	ldr	x8, [sp, #0xb0]
    101c:      	ldr	s0, [x8, x27]
    1020:      	fneg.4s	v1, v0
    1024:      	movi.2d	v2, #0000000000000000
    1028:      	mov.s	v2[0], v1[0]
    102c:      	ldp	q7, q6, [sp, #0x160]
    1030:      	fcmge.4s	v1, v2, v7
    1034:      	fcmge.4s	v3, v6, v2
    1038:      	and.16b	v1, v1, v3
    103c:      	and.16b	v1, v1, v2
    1040:      	fmul.4s	v3, v1, v15
    1044:      	mov.16b	v4, v28
    1048:      	bsl.16b	v4, v12, v3
    104c:      	fadd.4s	v3, v3, v4
    1050:      	fsub.4s	v3, v3, v4
    1054:      	fcvtzs.4s	v3, v3
    1058:      	scvtf.4s	v4, v3
    105c:      	fmul.4s	v5, v4, v11
    1060:      	fadd.4s	v1, v1, v5
    1064:      	fmul.4s	v4, v4, v30
    1068:      	fadd.4s	v1, v1, v4
    106c:      	fmul.4s	v4, v1, v31
    1070:      	fadd.4s	v4, v4, v8
    1074:      	fmul.4s	v4, v1, v4
    1078:      	fadd.4s	v4, v4, v9
    107c:      	fmul.4s	v4, v1, v4
    1080:      	fadd.4s	v4, v4, v10
    1084:      	fmul.4s	v4, v1, v4
    1088:      	fadd.4s	v4, v4, v27
    108c:      	fmul.4s	v4, v1, v4
    1090:      	fadd.4s	v4, v4, v21
    1094:      	fmul.4s	v5, v1, v1
    1098:      	fmul.4s	v4, v5, v4
    109c:      	fadd.4s	v1, v1, v4
    10a0:      	fadd.4s	v1, v1, v22
    10a4:      	sshr.4s	v4, v3, #0x1
    10a8:      	shl.4s	v5, v4, #0x17
    10ac:      	add.4s	v5, v5, v22
    10b0:      	fmul.4s	v1, v1, v5
    10b4:      	sub.4s	v3, v3, v4
    10b8:      	shl.4s	v3, v3, #0x17
    10bc:      	add.4s	v3, v3, v22
    10c0:      	fmul.4s	v1, v1, v3
    10c4:      	fcmgt.4s	v3, v7, v2
    10c8:      	fcmgt.4s	v4, v2, v6
    10cc:      	fcmeq.4s	v2, v2, v2
    10d0:      	fadd.4s	v1, v1, v22
    10d4:      	bit.16b	v1, v22, v3
    10d8:      	bit.16b	v1, v24, v4
    10dc:      	bif.16b	v1, v25, v2
    10e0:      	fdiv.4s	v0, v0, v1
    10e4:      	ldr	s1, [x23, x27]
    10e8:      	fmul.4s	v0, v1, v0
    10ec:      	b	0xe44 <ltmp0+0xe44>
    10f0:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
    10f4:      	add	x0, x0, #0x310
    10f8:      	ldr	x24, [sp, #0xb0]
    10fc:      	add	x1, x24, x25
    1100:      	mov	w2, #0x4000             ; =16384
    1104:      	bl	0x1104 <ltmp0+0x1104>
    1108:      	add	x27, x25, #0x4, lsl #12 ; =0x4000
    110c:      	ldr	s0, [x24, x27]
    1110:      	str	q0, [sp, #0xa0]
    1114:      	str	q0, [sp, #0x8310]
    1118:      	add	x0, sp, #0x2f0
    111c:      	add	x1, x23, x25
    1120:      	mov	w2, #0x4000             ; =16384
    1124:      	bl	0x1124 <ltmp0+0x1124>
    1128:      	add	x3, sp, #0x2f0
    112c:      	ldp	q25, q24, [sp, #0x120]
    1130:      	ldp	q27, q22, [sp, #0x140]
    1134:      	movi.4s	v21, #0x3f, lsl #24
    1138:      	mvni.4s	v28, #0x80, lsl #24
    113c:      	ldp	q10, q9, [sp, #0xd0]
    1140:      	ldp	q8, q31, [sp, #0xf0]
    1144:      	ldr	q30, [sp, #0x110]
    1148:      	ldr	q11, [sp, #0xc0]
    114c:      	ldp	q15, q14, [sp, #0x50]
    1150:      	ldr	q13, [sp, #0x70]
    1154:      	movi.4s	v12, #0x4b, lsl #24
    1158:      	mov	x8, #0x0                ; =0
    115c:      	ldr	s0, [x23, x27]
    1160:      	str	q0, [sp, #0x42f0]
    1164:      	add	x9, x28, x8
    1168:      	ldp	q1, q2, [x9]
    116c:      	fneg.4s	v3, v2
    1170:      	fneg.4s	v4, v1
    1174:      	fcmge.4s	v5, v13, v1
    1178:      	fcmge.4s	v6, v13, v2
    117c:      	fcmge.4s	v7, v1, v14
    1180:      	fcmge.4s	v16, v2, v14
    1184:      	and.16b	v6, v6, v16
    1188:      	and.16b	v5, v5, v7
    118c:      	and.16b	v4, v5, v4
    1190:      	and.16b	v3, v6, v3
    1194:      	fmul.4s	v5, v3, v15
    1198:      	fmul.4s	v6, v4, v15
    119c:      	mov.16b	v7, v28
    11a0:      	bsl.16b	v7, v12, v6
    11a4:      	mov.16b	v16, v28
    11a8:      	bsl.16b	v16, v12, v5
    11ac:      	fadd.4s	v5, v5, v16
    11b0:      	fadd.4s	v6, v6, v7
    11b4:      	fsub.4s	v6, v6, v7
    11b8:      	fsub.4s	v5, v5, v16
    11bc:      	fcvtzs.4s	v5, v5
    11c0:      	fcvtzs.4s	v6, v6
    11c4:      	scvtf.4s	v7, v6
    11c8:      	scvtf.4s	v16, v5
    11cc:      	fmul.4s	v17, v16, v11
    11d0:      	fmul.4s	v18, v7, v11
    11d4:      	fadd.4s	v4, v4, v18
    11d8:      	fadd.4s	v3, v3, v17
    11dc:      	fmul.4s	v7, v7, v30
    11e0:      	fmul.4s	v16, v16, v30
    11e4:      	fadd.4s	v3, v3, v16
    11e8:      	fadd.4s	v4, v4, v7
    11ec:      	fmul.4s	v7, v4, v31
    11f0:      	fmul.4s	v16, v3, v31
    11f4:      	fadd.4s	v16, v16, v8
    11f8:      	fadd.4s	v7, v7, v8
    11fc:      	fmul.4s	v7, v4, v7
    1200:      	fmul.4s	v16, v3, v16
    1204:      	fadd.4s	v16, v16, v9
    1208:      	fadd.4s	v7, v7, v9
    120c:      	fmul.4s	v7, v4, v7
    1210:      	fmul.4s	v16, v3, v16
    1214:      	fadd.4s	v16, v16, v10
    1218:      	fadd.4s	v7, v7, v10
    121c:      	fmul.4s	v7, v4, v7
    1220:      	fmul.4s	v16, v3, v16
    1224:      	fadd.4s	v16, v16, v27
    1228:      	fadd.4s	v7, v7, v27
    122c:      	fmul.4s	v7, v4, v7
    1230:      	fmul.4s	v16, v3, v16
    1234:      	fadd.4s	v16, v16, v21
    1238:      	fadd.4s	v7, v7, v21
    123c:      	fmul.4s	v17, v3, v3
    1240:      	fmul.4s	v18, v4, v4
    1244:      	fmul.4s	v7, v18, v7
    1248:      	fmul.4s	v16, v17, v16
    124c:      	fadd.4s	v3, v3, v16
    1250:      	fadd.4s	v4, v4, v7
    1254:      	sshr.4s	v7, v6, #0x1
    1258:      	fadd.4s	v4, v4, v22
    125c:      	sshr.4s	v16, v5, #0x1
    1260:      	shl.4s	v17, v16, #0x17
    1264:      	shl.4s	v18, v7, #0x17
    1268:      	add.4s	v18, v18, v22
    126c:      	add.4s	v17, v17, v22
    1270:      	fadd.4s	v3, v3, v22
    1274:      	fmul.4s	v3, v3, v17
    1278:      	sub.4s	v5, v5, v16
    127c:      	sub.4s	v6, v6, v7
    1280:      	shl.4s	v6, v6, #0x17
    1284:      	shl.4s	v5, v5, #0x17
    1288:      	fmul.4s	v4, v4, v18
    128c:      	add.4s	v5, v5, v22
    1290:      	add.4s	v6, v6, v22
    1294:      	fmul.4s	v4, v4, v6
    1298:      	fmul.4s	v3, v3, v5
    129c:      	fcmgt.4s	v5, v2, v13
    12a0:      	fcmgt.4s	v6, v1, v13
    12a4:      	fcmgt.4s	v7, v14, v1
    12a8:      	fcmgt.4s	v16, v14, v2
    12ac:      	fcmeq.4s	v17, v2, v2
    12b0:      	fadd.4s	v3, v3, v22
    12b4:      	fadd.4s	v4, v4, v22
    12b8:      	fcmeq.4s	v18, v1, v1
    12bc:      	bit.16b	v4, v22, v6
    12c0:      	bit.16b	v3, v22, v5
    12c4:      	bit.16b	v3, v24, v16
    12c8:      	bit.16b	v4, v24, v7
    12cc:      	bif.16b	v4, v25, v18
    12d0:      	bif.16b	v3, v25, v17
    12d4:      	fdiv.4s	v2, v2, v3
    12d8:      	fdiv.4s	v1, v1, v4
    12dc:      	add	x9, x3, x8
    12e0:      	ldp	q4, q3, [x9]
    12e4:      	fmul.4s	v1, v4, v1
    12e8:      	fmul.4s	v2, v3, v2
    12ec:      	add	x9, x26, x8
    12f0:      	stp	q1, q2, [x9]
    12f4:      	add	x8, x8, #0x20
    12f8:      	cmp	x8, #0x4, lsl #12       ; =0x4000
    12fc:      	b.ne	0x1164 <ltmp0+0x1164>
    1300:      	b	0xd60 <ltmp0+0xd60>
    1304:      	movi.4s	v2, #0x3f, lsl #24
    1308:      	mov	x10, #0x0               ; =0
    130c:      	add	x12, x11, x14
    1310:      	b	0x1334 <ltmp0+0x1334>
    1314:      	add	x13, x28, x10
    1318:      	ldp	q25, q26, [x13]
    131c:      	bif.16b	v22, v26, v1
    1320:      	bif.16b	v21, v25, v0
    1324:      	stp	q21, q22, [x13]
    1328:      	add	x10, x10, #0x20
    132c:      	cmp	x10, #0x4, lsl #12      ; =0x4000
    1330:      	b.eq	0x13d8 <ltmp0+0x13d8>
    1334:      	ldr	q17, [x0]
    1338:      	and.16b	v17, v19, v17
    133c:      	addv.8h	h17, v17
    1340:      	fmov	w14, s17
    1344:      	add	x13, x12, x10
    1348:      	movi.2d	v21, #0000000000000000
    134c:      	movi.2d	v22, #0000000000000000
    1350:      	tbz	w14, #0x0, 0x1394 <ltmp0+0x1394>
    1354:      	ldr	s21, [x13]
    1358:      	and	w14, w14, #0xff
    135c:      	tbnz	w14, #0x1, 0x139c <ltmp0+0x139c>
    1360:      	tbz	w14, #0x2, 0x13a8 <ltmp0+0x13a8>
    1364:      	add	x15, x13, #0x8
    1368:      	ld1.s	{ v21 }[2], [x15]
    136c:      	tbnz	w14, #0x3, 0x13ac <ltmp0+0x13ac>
    1370:      	tbz	w14, #0x4, 0x13b8 <ltmp0+0x13b8>
    1374:      	add	x15, x13, #0x10
    1378:      	ld1.s	{ v22 }[0], [x15]
    137c:      	tbnz	w14, #0x5, 0x13bc <ltmp0+0x13bc>
    1380:      	tbz	w14, #0x6, 0x13c8 <ltmp0+0x13c8>
    1384:      	add	x15, x13, #0x18
    1388:      	ld1.s	{ v22 }[2], [x15]
    138c:      	tbz	w14, #0x7, 0x1314 <ltmp0+0x1314>
    1390:      	b	0x13cc <ltmp0+0x13cc>
    1394:      	and	w14, w14, #0xff
    1398:      	tbz	w14, #0x1, 0x1360 <ltmp0+0x1360>
    139c:      	add	x15, x13, #0x4
    13a0:      	ld1.s	{ v21 }[1], [x15]
    13a4:      	tbnz	w14, #0x2, 0x1364 <ltmp0+0x1364>
    13a8:      	tbz	w14, #0x3, 0x1370 <ltmp0+0x1370>
    13ac:      	add	x15, x13, #0xc
    13b0:      	ld1.s	{ v21 }[3], [x15]
    13b4:      	tbnz	w14, #0x4, 0x1374 <ltmp0+0x1374>
    13b8:      	tbz	w14, #0x5, 0x1380 <ltmp0+0x1380>
    13bc:      	add	x15, x13, #0x14
    13c0:      	ld1.s	{ v22 }[1], [x15]
    13c4:      	tbnz	w14, #0x6, 0x1384 <ltmp0+0x1384>
    13c8:      	tbz	w14, #0x7, 0x1314 <ltmp0+0x1314>
    13cc:      	add	x13, x13, #0x1c
    13d0:      	ld1.s	{ v22 }[3], [x13]
    13d4:      	b	0x1314 <ltmp0+0x1314>
    13d8:      	xtn.4h	v19, v0
    13dc:      	uzp1.8b	v21, v19, v0
    13e0:      	movi.2d	v19, #0000000000000000
    13e4:      	mov.b	v19[0], v21[0]
    13e8:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    13ec:      	ldr	d25, [x10]
    13f0:      	and.8b	v22, v19, v25
    13f4:      	addv.8b	b22, v22
    13f8:      	fmov	w13, s22
    13fc:      	umaxv.8b	b22, v19
    1400:      	fmov	w14, s22
    1404:      	rbit	w10, w13
    1408:      	clz	w10, w10
    140c:      	tst	w14, #0x1
    1410:      	csel	w10, w10, wzr, ne
    1414:      	mov	w12, #0x1000            ; =4096
    1418:      	dup.2d	v26, x12
    141c:      	umlal.2d	v3, v20, v6
    1420:      	movi.2d	v22, #0000000000000000
    1424:      	mov.b	v22[0], v21[0]
    1428:      	add.2d	v3, v3, v26
    142c:      	ushll.2d	v18, v22, #0x0
    1430:      	shl.2d	v18, v18, #0x3f
    1434:      	cmlt.2d	v18, v18, #0
    1438:      	str	q3, [sp, #0x90]
    143c:      	and.16b	v18, v18, v3
    1440:      	movi.2d	v3, #0000000000000000
    1444:      	stp	q3, q3, [sp, #0x2c0]
    1448:      	stp	q18, q3, [sp, #0x2a0]
    144c:      	and	x12, x10, #0x7
    1450:      	add	x15, sp, #0x2a0
    1454:      	ldr	x12, [x15, x12, lsl #3]
    1458:      	sub	x12, x12, x10
    145c:      	lsl	x12, x12, #2
    1460:      	add	x11, x11, x12
    1464:      	movi.2d	v22, #0000000000000000
    1468:      	movi.2d	v18, #0000000000000000
    146c:      	tbz	w14, #0x0, 0x14b0 <ltmp0+0x14b0>
    1470:      	ldr	s22, [x11]
    1474:      	tbnz	w13, #0x1, 0x14b4 <ltmp0+0x14b4>
    1478:      	tbz	w13, #0x2, 0x14c0 <ltmp0+0x14c0>
    147c:      	add	x14, x11, #0x8
    1480:      	ld1.s	{ v22 }[2], [x14]
    1484:      	tbnz	w13, #0x3, 0x14c4 <ltmp0+0x14c4>
    1488:      	tbz	w13, #0x4, 0x14d0 <ltmp0+0x14d0>
    148c:      	add	x14, x11, #0x10
    1490:      	ld1.s	{ v18 }[0], [x14]
    1494:      	tbnz	w13, #0x5, 0x14d4 <ltmp0+0x14d4>
    1498:      	tbz	w13, #0x6, 0x14e0 <ltmp0+0x14e0>
    149c:      	add	x14, x11, #0x18
    14a0:      	ld1.s	{ v18 }[2], [x14]
    14a4:      	mvni.4s	v21, #0x80, lsl #24
    14a8:      	tbnz	w13, #0x7, 0x14e8 <ltmp0+0x14e8>
    14ac:      	b	0x14f0 <ltmp0+0x14f0>
    14b0:      	tbz	w13, #0x1, 0x1478 <ltmp0+0x1478>
    14b4:      	add	x14, x11, #0x4
    14b8:      	ld1.s	{ v22 }[1], [x14]
    14bc:      	tbnz	w13, #0x2, 0x147c <ltmp0+0x147c>
    14c0:      	tbz	w13, #0x3, 0x1488 <ltmp0+0x1488>
    14c4:      	add	x14, x11, #0xc
    14c8:      	ld1.s	{ v22 }[3], [x14]
    14cc:      	tbnz	w13, #0x4, 0x148c <ltmp0+0x148c>
    14d0:      	tbz	w13, #0x5, 0x1498 <ltmp0+0x1498>
    14d4:      	add	x14, x11, #0x14
    14d8:      	ld1.s	{ v18 }[1], [x14]
    14dc:      	tbnz	w13, #0x6, 0x149c <ltmp0+0x149c>
    14e0:      	mvni.4s	v21, #0x80, lsl #24
    14e4:      	tbz	w13, #0x7, 0x14f0 <ltmp0+0x14f0>
    14e8:      	add	x11, x11, #0x1c
    14ec:      	ld1.s	{ v18 }[3], [x11]
    14f0:      	mov	x15, #0x0               ; =0
    14f4:      	umull.2d	v20, v20, v6
    14f8:      	umlal.2d	v4, v16, v6
    14fc:      	add.2d	v3, v4, v26
    1500:      	str	q3, [sp, #0x80]
    1504:      	ldr	d3, [sp, #0xa0]
    1508:      	umlal.2d	v28, v3, v6
    150c:      	add.2d	v3, v28, v26
    1510:      	str	q3, [sp, #0xa0]
    1514:      	ldr	d3, [sp, #0xb0]
    1518:      	umlal.2d	v27, v3, v6
    151c:      	adrp	x11, 0x1000 <ltmp0+0x1000>
    1520:      	ldr	q5, [x11]
    1524:      	mov	w11, #0x4000            ; =16384
    1528:      	dup.2d	v6, x11
    152c:      	sshll.2d	v7, v0, #0x0
    1530:      	bif.16b	v5, v6, v7
    1534:      	adrp	x11, 0x1000 <ltmp0+0x1000>
    1538:      	ldr	q7, [x11]
    153c:      	sshll.2d	v16, v1, #0x0
    1540:      	bif.16b	v7, v6, v16
    1544:      	adrp	x11, 0x1000 <ltmp0+0x1000>
    1548:      	ldr	q16, [x11]
    154c:      	bif.16b	v16, v6, v24
    1550:      	adrp	x11, 0x1000 <ltmp0+0x1000>
    1554:      	ldr	q24, [x11]
    1558:      	bit.16b	v6, v24, v23
    155c:      	stp	q7, q6, [sp, #0x280]
    1560:      	stp	q5, q16, [sp, #0x260]
    1564:      	and	x11, x10, #0x7
    1568:      	add	x14, sp, #0x260
    156c:      	ldr	x11, [x14, x11, lsl #3]
    1570:      	add.2d	v3, v27, v26
    1574:      	str	q3, [sp, #0xb0]
    1578:      	sub	x11, x11, x10, lsl #2
    157c:      	tst	w13, #0xff
    1580:      	csel	x11, xzr, x11, eq
    1584:      	add	x13, x28, x11
    1588:      	ldp	q5, q6, [x13]
    158c:      	zip2.8b	v7, v19, v0
    1590:      	ushll.4s	v7, v7, #0x0
    1594:      	shl.4s	v7, v7, #0x1f
    1598:      	cmlt.4s	v7, v7, #0
    159c:      	bit.16b	v6, v18, v7
    15a0:      	zip1.8b	v7, v19, v0
    15a4:      	ushll.4s	v7, v7, #0x0
    15a8:      	shl.4s	v7, v7, #0x1f
    15ac:      	cmlt.4s	v7, v7, #0
    15b0:      	bit.16b	v5, v22, v7
    15b4:      	stp	q5, q6, [x13]
    15b8:      	fmov	x13, d20
    15bc:      	lsl	x13, x13, #2
    15c0:      	mov	w14, #0x1               ; =1
    15c4:      	dup.2d	v16, x14
    15c8:      	add	x14, x9, x13
    15cc:      	ushll2.2d	v5, v1, #0x0
    15d0:      	and.16b	v5, v5, v16
    15d4:      	ushll2.2d	v6, v0, #0x0
    15d8:      	and.16b	v6, v6, v16
    15dc:      	ushll.2d	v7, v1, #0x0
    15e0:      	and.16b	v7, v7, v16
    15e4:      	ushll.2d	v20, v0, #0x0
    15e8:      	and.16b	v16, v20, v16
    15ec:      	movi.2d	v20, #0000000000000000
    15f0:      	movi.2d	v23, #0000000000000000
    15f4:      	movi.2d	v24, #0000000000000000
    15f8:      	movi.2d	v26, #0000000000000000
    15fc:      	b	0x1630 <ltmp0+0x1630>
    1600:      	add	x15, x3, x15
    1604:      	ldp	q29, q30, [x15]
    1608:      	bif.16b	v28, v30, v1
    160c:      	bif.16b	v27, v29, v0
    1610:      	stp	q27, q28, [x15]
    1614:      	add.2d	v23, v23, v6
    1618:      	add.2d	v24, v24, v7
    161c:      	add.2d	v26, v26, v5
    1620:      	add.2d	v20, v20, v16
    1624:      	fmov	x15, d20
    1628:      	cmp	x15, #0x200
    162c:      	b.ge	0x16cc <ltmp0+0x16cc>
    1630:      	fmov	w17, s17
    1634:      	lsl	x15, x15, #5
    1638:      	add	x16, x14, x15
    163c:      	movi.2d	v27, #0000000000000000
    1640:      	movi.2d	v28, #0000000000000000
    1644:      	tbz	w17, #0x0, 0x1688 <ltmp0+0x1688>
    1648:      	ldr	s27, [x16]
    164c:      	and	w17, w17, #0xff
    1650:      	tbnz	w17, #0x1, 0x1690 <ltmp0+0x1690>
    1654:      	tbz	w17, #0x2, 0x169c <ltmp0+0x169c>
    1658:      	add	x0, x16, #0x8
    165c:      	ld1.s	{ v27 }[2], [x0]
    1660:      	tbnz	w17, #0x3, 0x16a0 <ltmp0+0x16a0>
    1664:      	tbz	w17, #0x4, 0x16ac <ltmp0+0x16ac>
    1668:      	add	x0, x16, #0x10
    166c:      	ld1.s	{ v28 }[0], [x0]
    1670:      	tbnz	w17, #0x5, 0x16b0 <ltmp0+0x16b0>
    1674:      	tbz	w17, #0x6, 0x16bc <ltmp0+0x16bc>
    1678:      	add	x0, x16, #0x18
    167c:      	ld1.s	{ v28 }[2], [x0]
    1680:      	tbz	w17, #0x7, 0x1600 <ltmp0+0x1600>
    1684:      	b	0x16c0 <ltmp0+0x16c0>
    1688:      	and	w17, w17, #0xff
    168c:      	tbz	w17, #0x1, 0x1654 <ltmp0+0x1654>
    1690:      	add	x0, x16, #0x4
    1694:      	ld1.s	{ v27 }[1], [x0]
    1698:      	tbnz	w17, #0x2, 0x1658 <ltmp0+0x1658>
    169c:      	tbz	w17, #0x3, 0x1664 <ltmp0+0x1664>
    16a0:      	add	x0, x16, #0xc
    16a4:      	ld1.s	{ v27 }[3], [x0]
    16a8:      	tbnz	w17, #0x4, 0x1668 <ltmp0+0x1668>
    16ac:      	tbz	w17, #0x5, 0x1674 <ltmp0+0x1674>
    16b0:      	add	x0, x16, #0x14
    16b4:      	ld1.s	{ v28 }[1], [x0]
    16b8:      	tbnz	w17, #0x6, 0x1678 <ltmp0+0x1678>
    16bc:      	tbz	w17, #0x7, 0x1600 <ltmp0+0x1600>
    16c0:      	add	x16, x16, #0x1c
    16c4:      	ld1.s	{ v28 }[3], [x16]
    16c8:      	b	0x1600 <ltmp0+0x1600>
    16cc:      	add	x9, x9, x12
    16d0:      	shl.8b	v20, v19, #0x7
    16d4:      	cmlt.8b	v20, v20, #0
    16d8:      	and.8b	v20, v20, v25
    16dc:      	addv.8b	b3, v20
    16e0:      	str	d3, [sp, #0x48]
    16e4:      	fmov	w12, s3
    16e8:      	movi.2d	v23, #0000000000000000
    16ec:      	movi.2d	v20, #0000000000000000
    16f0:      	tbz	w12, #0x0, 0x1730 <ltmp0+0x1730>
    16f4:      	ldr	s23, [x9]
    16f8:      	tbnz	w12, #0x1, 0x1734 <ltmp0+0x1734>
    16fc:      	tbz	w12, #0x2, 0x1740 <ltmp0+0x1740>
    1700:      	add	x14, x9, #0x8
    1704:      	ld1.s	{ v23 }[2], [x14]
    1708:      	tbnz	w12, #0x3, 0x1744 <ltmp0+0x1744>
    170c:      	tbz	w12, #0x4, 0x1750 <ltmp0+0x1750>
    1710:      	add	x14, x9, #0x10
    1714:      	ld1.s	{ v20 }[0], [x14]
    1718:      	tbnz	w12, #0x5, 0x1754 <ltmp0+0x1754>
    171c:      	tbz	w12, #0x6, 0x1760 <ltmp0+0x1760>
    1720:      	add	x14, x9, #0x18
    1724:      	ld1.s	{ v20 }[2], [x14]
    1728:      	tbnz	w12, #0x7, 0x1764 <ltmp0+0x1764>
    172c:      	b	0x176c <ltmp0+0x176c>
    1730:      	tbz	w12, #0x1, 0x16fc <ltmp0+0x16fc>
    1734:      	add	x14, x9, #0x4
    1738:      	ld1.s	{ v23 }[1], [x14]
    173c:      	tbnz	w12, #0x2, 0x1700 <ltmp0+0x1700>
    1740:      	tbz	w12, #0x3, 0x170c <ltmp0+0x170c>
    1744:      	add	x14, x9, #0xc
    1748:      	ld1.s	{ v23 }[3], [x14]
    174c:      	tbnz	w12, #0x4, 0x1710 <ltmp0+0x1710>
    1750:      	tbz	w12, #0x5, 0x171c <ltmp0+0x171c>
    1754:      	add	x14, x9, #0x14
    1758:      	ld1.s	{ v20 }[1], [x14]
    175c:      	tbnz	w12, #0x6, 0x1720 <ltmp0+0x1720>
    1760:      	tbz	w12, #0x7, 0x176c <ltmp0+0x176c>
    1764:      	add	x9, x9, #0x1c
    1768:      	ld1.s	{ v20 }[3], [x9]
    176c:      	mov	x14, #0x0               ; =0
    1770:      	add	x9, x3, x11
    1774:      	ldp	q25, q26, [x9]
    1778:      	zip2.8b	v27, v19, v0
    177c:      	ushll.4s	v27, v27, #0x0
    1780:      	shl.4s	v27, v27, #0x1f
    1784:      	cmlt.4s	v27, v27, #0
    1788:      	bit.16b	v26, v20, v27
    178c:      	zip1.8b	v27, v19, v0
    1790:      	ushll.4s	v27, v27, #0x0
    1794:      	shl.4s	v27, v27, #0x1f
    1798:      	cmlt.4s	v27, v27, #0
    179c:      	bit.16b	v25, v23, v27
    17a0:      	stp	q25, q26, [x9]
    17a4:      	add	x9, x8, x13
    17a8:      	movi.2d	v25, #0000000000000000
    17ac:      	movi.2d	v26, #0000000000000000
    17b0:      	movi.2d	v27, #0000000000000000
    17b4:      	movi.2d	v28, #0000000000000000
    17b8:      	b	0x17d8 <ltmp0+0x17d8>
    17bc:      	add.2d	v26, v26, v6
    17c0:      	add.2d	v27, v27, v7
    17c4:      	add.2d	v28, v28, v5
    17c8:      	add.2d	v25, v25, v16
    17cc:      	fmov	x14, d25
    17d0:      	cmp	x14, #0x200
    17d4:      	b.ge	0x1a48 <ltmp0+0x1a48>
    17d8:      	fmov	w12, s17
    17dc:      	lsl	x11, x14, #5
    17e0:      	add	x13, x28, x11
    17e4:      	ldp	q30, q29, [x13]
    17e8:      	and.16b	v30, v0, v30
    17ec:      	fneg.4s	v31, v30
    17f0:      	and.16b	v31, v0, v31
    17f4:      	ldp	q24, q4, [sp, #0x160]
    17f8:      	fcmge.4s	v8, v31, v24
    17fc:      	fcmge.4s	v9, v4, v31
    1800:      	and.16b	v8, v8, v9
    1804:      	and.16b	v8, v8, v31
    1808:      	fmul.4s	v9, v8, v15
    180c:      	mov.16b	v10, v21
    1810:      	bsl.16b	v10, v12, v9
    1814:      	fadd.4s	v9, v9, v10
    1818:      	fsub.4s	v9, v9, v10
    181c:      	fcvtzs.4s	v9, v9
    1820:      	scvtf.4s	v10, v9
    1824:      	fmul.4s	v11, v10, v11
    1828:      	fadd.4s	v8, v8, v11
    182c:      	ldr	q11, [sp, #0x110]
    1830:      	fmul.4s	v10, v10, v11
    1834:      	fadd.4s	v8, v8, v10
    1838:      	ldp	q11, q10, [sp, #0xf0]
    183c:      	fmul.4s	v10, v8, v10
    1840:      	fadd.4s	v10, v10, v11
    1844:      	fmul.4s	v10, v8, v10
    1848:      	ldp	q11, q3, [sp, #0xd0]
    184c:      	fadd.4s	v10, v10, v3
    1850:      	fmul.4s	v10, v8, v10
    1854:      	fadd.4s	v10, v10, v11
    1858:      	fmul.4s	v10, v8, v10
    185c:      	ldp	q11, q3, [sp, #0x140]
    1860:      	fadd.4s	v10, v10, v11
    1864:      	fmul.4s	v10, v8, v10
    1868:      	fadd.4s	v10, v10, v2
    186c:      	fmul.4s	v11, v8, v8
    1870:      	fmul.4s	v10, v11, v10
    1874:      	fadd.4s	v8, v8, v10
    1878:      	fadd.4s	v8, v8, v3
    187c:      	sshr.4s	v10, v9, #0x1
    1880:      	shl.4s	v11, v10, #0x17
    1884:      	add.4s	v11, v11, v3
    1888:      	fmul.4s	v8, v8, v11
    188c:      	sub.4s	v9, v9, v10
    1890:      	shl.4s	v9, v9, #0x17
    1894:      	add.4s	v9, v9, v3
    1898:      	fmul.4s	v8, v8, v9
    189c:      	fcmgt.4s	v9, v24, v31
    18a0:      	fcmgt.4s	v10, v31, v4
    18a4:      	fcmeq.4s	v31, v31, v31
    18a8:      	fadd.4s	v8, v8, v3
    18ac:      	bit.16b	v8, v3, v9
    18b0:      	ldp	q3, q4, [sp, #0x120]
    18b4:      	bit.16b	v8, v4, v10
    18b8:      	bsl.16b	v31, v8, v3
    18bc:      	fdiv.4s	v31, v30, v31
    18c0:      	add	x13, x3, x11
    18c4:      	ldp	q8, q30, [x13]
    18c8:      	and.16b	v8, v0, v8
    18cc:      	fmul.4s	v31, v8, v31
    18d0:      	add	x11, x9, x11
    18d4:      	tbz	w12, #0x0, 0x18fc <ltmp0+0x18fc>
    18d8:      	str	s31, [x11]
    18dc:      	and	w12, w12, #0xff
    18e0:      	tbnz	w12, #0x1, 0x1904 <ltmp0+0x1904>
    18e4:      	ldr	q11, [sp, #0xc0]
    18e8:      	tbz	w12, #0x2, 0x1914 <ltmp0+0x1914>
    18ec:      	add	x13, x11, #0x8
    18f0:      	st1.s	{ v31 }[2], [x13]
    18f4:      	tbnz	w12, #0x3, 0x1918 <ltmp0+0x1918>
    18f8:      	b	0x1920 <ltmp0+0x1920>
    18fc:      	and	w12, w12, #0xff
    1900:      	tbz	w12, #0x1, 0x18e4 <ltmp0+0x18e4>
    1904:      	add	x13, x11, #0x4
    1908:      	st1.s	{ v31 }[1], [x13]
    190c:      	ldr	q11, [sp, #0xc0]
    1910:      	tbnz	w12, #0x2, 0x18ec <ltmp0+0x18ec>
    1914:      	tbz	w12, #0x3, 0x1920 <ltmp0+0x1920>
    1918:      	add	x13, x11, #0xc
    191c:      	st1.s	{ v31 }[3], [x13]
    1920:      	and.16b	v29, v1, v29
    1924:      	fneg.4s	v31, v29
    1928:      	and.16b	v31, v1, v31
    192c:      	ldp	q24, q4, [sp, #0x160]
    1930:      	fcmge.4s	v8, v31, v24
    1934:      	fcmge.4s	v9, v4, v31
    1938:      	and.16b	v8, v8, v9
    193c:      	and.16b	v8, v8, v31
    1940:      	fmul.4s	v9, v8, v15
    1944:      	mov.16b	v10, v21
    1948:      	bsl.16b	v10, v12, v9
    194c:      	fadd.4s	v9, v9, v10
    1950:      	fsub.4s	v9, v9, v10
    1954:      	fcvtzs.4s	v9, v9
    1958:      	scvtf.4s	v10, v9
    195c:      	fmul.4s	v11, v10, v11
    1960:      	fadd.4s	v8, v8, v11
    1964:      	ldr	q11, [sp, #0x110]
    1968:      	fmul.4s	v10, v10, v11
    196c:      	fadd.4s	v8, v8, v10
    1970:      	ldp	q11, q10, [sp, #0xf0]
    1974:      	fmul.4s	v10, v8, v10
    1978:      	fadd.4s	v10, v10, v11
    197c:      	fmul.4s	v10, v8, v10
    1980:      	ldp	q11, q3, [sp, #0xd0]
    1984:      	fadd.4s	v10, v10, v3
    1988:      	fmul.4s	v10, v8, v10
    198c:      	fadd.4s	v10, v10, v11
    1990:      	fmul.4s	v10, v8, v10
    1994:      	ldp	q11, q3, [sp, #0x140]
    1998:      	fadd.4s	v10, v10, v11
    199c:      	fmul.4s	v10, v8, v10
    19a0:      	fadd.4s	v10, v10, v2
    19a4:      	fmul.4s	v11, v8, v8
    19a8:      	fmul.4s	v10, v11, v10
    19ac:      	fadd.4s	v8, v8, v10
    19b0:      	fadd.4s	v8, v8, v3
    19b4:      	sshr.4s	v10, v9, #0x1
    19b8:      	shl.4s	v11, v10, #0x17
    19bc:      	add.4s	v11, v11, v3
    19c0:      	fmul.4s	v8, v8, v11
    19c4:      	sub.4s	v9, v9, v10
    19c8:      	shl.4s	v9, v9, #0x17
    19cc:      	add.4s	v9, v9, v3
    19d0:      	fmul.4s	v8, v8, v9
    19d4:      	fcmgt.4s	v9, v24, v31
    19d8:      	fcmgt.4s	v10, v31, v4
    19dc:      	fcmeq.4s	v31, v31, v31
    19e0:      	fadd.4s	v8, v8, v3
    19e4:      	bit.16b	v8, v3, v9
    19e8:      	ldp	q3, q4, [sp, #0x120]
    19ec:      	bit.16b	v8, v4, v10
    19f0:      	bsl.16b	v31, v8, v3
    19f4:      	fdiv.4s	v29, v29, v31
    19f8:      	and.16b	v30, v1, v30
    19fc:      	fmul.4s	v29, v30, v29
    1a00:      	tbz	w12, #0x4, 0x1a24 <ltmp0+0x1a24>
    1a04:      	str	s29, [x11, #0x10]
    1a08:      	tbnz	w12, #0x5, 0x1a28 <ltmp0+0x1a28>
    1a0c:      	ldr	q11, [sp, #0xc0]
    1a10:      	tbz	w12, #0x6, 0x1a38 <ltmp0+0x1a38>
    1a14:      	add	x13, x11, #0x18
    1a18:      	st1.s	{ v29 }[2], [x13]
    1a1c:      	tbz	w12, #0x7, 0x17bc <ltmp0+0x17bc>
    1a20:      	b	0x1a3c <ltmp0+0x1a3c>
    1a24:      	tbz	w12, #0x5, 0x1a0c <ltmp0+0x1a0c>
    1a28:      	add	x13, x11, #0x14
    1a2c:      	st1.s	{ v29 }[1], [x13]
    1a30:      	ldr	q11, [sp, #0xc0]
    1a34:      	tbnz	w12, #0x6, 0x1a14 <ltmp0+0x1a14>
    1a38:      	tbz	w12, #0x7, 0x17bc <ltmp0+0x17bc>
    1a3c:      	add	x11, x11, #0x1c
    1a40:      	st1.s	{ v29 }[3], [x11]
    1a44:      	b	0x17bc <ltmp0+0x17bc>
    1a48:      	fneg.4s	v0, v22
    1a4c:      	ldr	d1, [sp, #0x48]
    1a50:      	fmov	w9, s1
    1a54:      	zip1.8b	v1, v19, v0
    1a58:      	ushll.4s	v1, v1, #0x0
    1a5c:      	shl.4s	v1, v1, #0x1f
    1a60:      	cmlt.4s	v1, v1, #0
    1a64:      	and.16b	v0, v1, v0
    1a68:      	ldp	q4, q3, [sp, #0x160]
    1a6c:      	fcmge.4s	v1, v0, v4
    1a70:      	fcmge.4s	v5, v3, v0
    1a74:      	and.16b	v1, v1, v5
    1a78:      	and.16b	v1, v1, v0
    1a7c:      	fmul.4s	v5, v1, v15
    1a80:      	mvni.4s	v28, #0x80, lsl #24
    1a84:      	mov.16b	v6, v28
    1a88:      	bsl.16b	v6, v12, v5
    1a8c:      	fadd.4s	v5, v5, v6
    1a90:      	fsub.4s	v5, v5, v6
    1a94:      	fcvtzs.4s	v5, v5
    1a98:      	scvtf.4s	v6, v5
    1a9c:      	fmul.4s	v7, v6, v11
    1aa0:      	fadd.4s	v1, v1, v7
    1aa4:      	ldp	q31, q30, [sp, #0x100]
    1aa8:      	fmul.4s	v6, v6, v30
    1aac:      	fadd.4s	v1, v1, v6
    1ab0:      	fmul.4s	v6, v1, v31
    1ab4:      	ldp	q9, q8, [sp, #0xe0]
    1ab8:      	fadd.4s	v6, v6, v8
    1abc:      	fmul.4s	v6, v1, v6
    1ac0:      	fadd.4s	v6, v6, v9
    1ac4:      	fmul.4s	v6, v1, v6
    1ac8:      	ldr	q10, [sp, #0xd0]
    1acc:      	fadd.4s	v6, v6, v10
    1ad0:      	fmul.4s	v6, v1, v6
    1ad4:      	ldp	q27, q2, [sp, #0x140]
    1ad8:      	fadd.4s	v6, v6, v27
    1adc:      	fmul.4s	v6, v1, v6
    1ae0:      	movi.4s	v21, #0x3f, lsl #24
    1ae4:      	fadd.4s	v6, v6, v21
    1ae8:      	fmul.4s	v7, v1, v1
    1aec:      	fmul.4s	v6, v7, v6
    1af0:      	fadd.4s	v1, v1, v6
    1af4:      	fadd.4s	v1, v1, v2
    1af8:      	sshr.4s	v6, v5, #0x1
    1afc:      	shl.4s	v7, v6, #0x17
    1b00:      	add.4s	v7, v7, v2
    1b04:      	fmul.4s	v1, v1, v7
    1b08:      	sub.4s	v5, v5, v6
    1b0c:      	shl.4s	v5, v5, #0x17
    1b10:      	add.4s	v5, v5, v2
    1b14:      	fmul.4s	v1, v1, v5
    1b18:      	fcmgt.4s	v5, v4, v0
    1b1c:      	fcmgt.4s	v6, v0, v3
    1b20:      	fcmeq.4s	v0, v0, v0
    1b24:      	fadd.4s	v1, v1, v2
    1b28:      	bit.16b	v1, v2, v5
    1b2c:      	ldp	q25, q24, [sp, #0x120]
    1b30:      	bit.16b	v1, v24, v6
    1b34:      	bsl.16b	v0, v1, v25
    1b38:      	fdiv.4s	v0, v22, v0
    1b3c:      	fmul.4s	v0, v0, v23
    1b40:      	ldp	q1, q2, [sp, #0x80]
    1b44:      	stp	q2, q1, [sp, #0x210]
    1b48:      	ldp	q2, q1, [sp, #0xa0]
    1b4c:      	stp	q2, q1, [sp, #0x230]
    1b50:      	and	x11, x10, #0x7
    1b54:      	add	x12, sp, #0x210
    1b58:      	ldr	x11, [x12, x11, lsl #3]
    1b5c:      	sub	x10, x11, x10
    1b60:      	add	x8, x8, x10, lsl #2
    1b64:      	tbz	w9, #0x0, 0x1b88 <ltmp0+0x1b88>
    1b68:      	str	s0, [x8]
    1b6c:      	tbnz	w9, #0x1, 0x1b8c <ltmp0+0x1b8c>
    1b70:      	ldr	q22, [sp, #0x150]
    1b74:      	tbz	w9, #0x2, 0x1b9c <ltmp0+0x1b9c>
    1b78:      	add	x10, x8, #0x8
    1b7c:      	st1.s	{ v0 }[2], [x10]
    1b80:      	tbnz	w9, #0x3, 0x1ba0 <ltmp0+0x1ba0>
    1b84:      	b	0x1ba8 <ltmp0+0x1ba8>
    1b88:      	tbz	w9, #0x1, 0x1b70 <ltmp0+0x1b70>
    1b8c:      	add	x10, x8, #0x4
    1b90:      	st1.s	{ v0 }[1], [x10]
    1b94:      	ldr	q22, [sp, #0x150]
    1b98:      	tbnz	w9, #0x2, 0x1b78 <ltmp0+0x1b78>
    1b9c:      	tbz	w9, #0x3, 0x1ba8 <ltmp0+0x1ba8>
    1ba0:      	add	x10, x8, #0xc
    1ba4:      	st1.s	{ v0 }[3], [x10]
    1ba8:      	fneg.4s	v0, v18
    1bac:      	zip2.8b	v1, v19, v0
    1bb0:      	ushll.4s	v1, v1, #0x0
    1bb4:      	shl.4s	v1, v1, #0x1f
    1bb8:      	cmlt.4s	v1, v1, #0
    1bbc:      	and.16b	v0, v1, v0
    1bc0:      	ldp	q6, q5, [sp, #0x160]
    1bc4:      	fcmge.4s	v1, v0, v6
    1bc8:      	fcmge.4s	v2, v5, v0
    1bcc:      	and.16b	v1, v1, v2
    1bd0:      	and.16b	v1, v1, v0
    1bd4:      	fmul.4s	v2, v1, v15
    1bd8:      	mov.16b	v3, v28
    1bdc:      	bsl.16b	v3, v12, v2
    1be0:      	fadd.4s	v2, v2, v3
    1be4:      	fsub.4s	v2, v2, v3
    1be8:      	fcvtzs.4s	v2, v2
    1bec:      	scvtf.4s	v3, v2
    1bf0:      	fmul.4s	v4, v3, v11
    1bf4:      	fadd.4s	v1, v1, v4
    1bf8:      	fmul.4s	v3, v3, v30
    1bfc:      	fadd.4s	v1, v1, v3
    1c00:      	fmul.4s	v3, v1, v31
    1c04:      	fadd.4s	v3, v3, v8
    1c08:      	fmul.4s	v3, v1, v3
    1c0c:      	fadd.4s	v3, v3, v9
    1c10:      	fmul.4s	v3, v1, v3
    1c14:      	fadd.4s	v3, v3, v10
    1c18:      	fmul.4s	v3, v1, v3
    1c1c:      	fadd.4s	v3, v3, v27
    1c20:      	fmul.4s	v3, v1, v3
    1c24:      	fadd.4s	v3, v3, v21
    1c28:      	fmul.4s	v4, v1, v1
    1c2c:      	fmul.4s	v3, v4, v3
    1c30:      	fadd.4s	v1, v1, v3
    1c34:      	fadd.4s	v1, v1, v22
    1c38:      	sshr.4s	v3, v2, #0x1
    1c3c:      	shl.4s	v4, v3, #0x17
    1c40:      	add.4s	v4, v4, v22
    1c44:      	fmul.4s	v1, v1, v4
    1c48:      	sub.4s	v2, v2, v3
    1c4c:      	shl.4s	v2, v2, #0x17
    1c50:      	add.4s	v2, v2, v22
    1c54:      	fmul.4s	v1, v1, v2
    1c58:      	fcmgt.4s	v2, v6, v0
    1c5c:      	fcmgt.4s	v3, v0, v5
    1c60:      	fcmeq.4s	v0, v0, v0
    1c64:      	fadd.4s	v1, v1, v22
    1c68:      	bit.16b	v1, v22, v2
    1c6c:      	bit.16b	v1, v24, v3
    1c70:      	bsl.16b	v0, v1, v25
    1c74:      	fdiv.4s	v0, v18, v0
    1c78:      	fmul.4s	v0, v0, v20
    1c7c:      	tbz	w9, #0x4, 0x2088 <ltmp0+0x2088>
    1c80:      	str	s0, [x8, #0x10]
    1c84:      	tbnz	w9, #0x5, 0x208c <ltmp0+0x208c>
    1c88:      	tbz	w9, #0x6, 0x2098 <ltmp0+0x2098>
    1c8c:      	add	x10, x8, #0x18
    1c90:      	st1.s	{ v0 }[2], [x10]
    1c94:      	tbnz	w9, #0x7, 0x209c <ltmp0+0x209c>
    1c98:      	b	0x118 <ltmp0+0x118>
    1c9c:      	xtn.4h	v0, v0
    1ca0:      	uzp1.8b	v0, v0, v0
    1ca4:      	movi.2d	v1, #0000000000000000
    1ca8:      	mov.b	v1[0], v0[0]
    1cac:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1cb0:      	ldr	d21, [x10]
    1cb4:      	and.8b	v17, v1, v21
    1cb8:      	addv.8b	b17, v17
    1cbc:      	fmov	w12, s17
    1cc0:      	umaxv.8b	b17, v1
    1cc4:      	fmov	w14, s17
    1cc8:      	rbit	w10, w12
    1ccc:      	clz	w10, w10
    1cd0:      	tst	w14, #0x1
    1cd4:      	csel	w10, w10, wzr, ne
    1cd8:      	mov	w13, #0x1000            ; =4096
    1cdc:      	dup.2d	v19, x13
    1ce0:      	umlal.2d	v3, v20, v6
    1ce4:      	movi.2d	v20, #0000000000000000
    1ce8:      	mov.b	v20[0], v0[0]
    1cec:      	add.2d	v17, v3, v19
    1cf0:      	ushll.2d	v0, v20, #0x0
    1cf4:      	shl.2d	v0, v0, #0x3f
    1cf8:      	cmlt.2d	v0, v0, #0
    1cfc:      	and.16b	v0, v0, v17
    1d00:      	movi.2d	v2, #0000000000000000
    1d04:      	stp	q2, q2, [sp, #0x1e0]
    1d08:      	stp	q0, q2, [sp, #0x1c0]
    1d0c:      	and	x13, x10, #0x7
    1d10:      	add	x15, sp, #0x1c0
    1d14:      	ldr	x13, [x15, x13, lsl #3]
    1d18:      	sub	x13, x13, x10
    1d1c:      	lsl	x13, x13, #2
    1d20:      	add	x11, x11, x13
    1d24:      	movi.2d	v23, #0000000000000000
    1d28:      	movi.2d	v0, #0000000000000000
    1d2c:      	tbz	w14, #0x0, 0x1d6c <ltmp0+0x1d6c>
    1d30:      	ldr	s23, [x11]
    1d34:      	tbnz	w12, #0x1, 0x1d70 <ltmp0+0x1d70>
    1d38:      	tbz	w12, #0x2, 0x1d7c <ltmp0+0x1d7c>
    1d3c:      	add	x14, x11, #0x8
    1d40:      	ld1.s	{ v23 }[2], [x14]
    1d44:      	tbnz	w12, #0x3, 0x1d80 <ltmp0+0x1d80>
    1d48:      	tbz	w12, #0x4, 0x1d8c <ltmp0+0x1d8c>
    1d4c:      	add	x14, x11, #0x10
    1d50:      	ld1.s	{ v0 }[0], [x14]
    1d54:      	tbnz	w12, #0x5, 0x1d90 <ltmp0+0x1d90>
    1d58:      	tbz	w12, #0x6, 0x1d9c <ltmp0+0x1d9c>
    1d5c:      	add	x14, x11, #0x18
    1d60:      	ld1.s	{ v0 }[2], [x14]
    1d64:      	tbnz	w12, #0x7, 0x1da0 <ltmp0+0x1da0>
    1d68:      	b	0x1da8 <ltmp0+0x1da8>
    1d6c:      	tbz	w12, #0x1, 0x1d38 <ltmp0+0x1d38>
    1d70:      	add	x14, x11, #0x4
    1d74:      	ld1.s	{ v23 }[1], [x14]
    1d78:      	tbnz	w12, #0x2, 0x1d3c <ltmp0+0x1d3c>
    1d7c:      	tbz	w12, #0x3, 0x1d48 <ltmp0+0x1d48>
    1d80:      	add	x14, x11, #0xc
    1d84:      	ld1.s	{ v23 }[3], [x14]
    1d88:      	tbnz	w12, #0x4, 0x1d4c <ltmp0+0x1d4c>
    1d8c:      	tbz	w12, #0x5, 0x1d58 <ltmp0+0x1d58>
    1d90:      	add	x14, x11, #0x14
    1d94:      	ld1.s	{ v0 }[1], [x14]
    1d98:      	tbnz	w12, #0x6, 0x1d5c <ltmp0+0x1d5c>
    1d9c:      	tbz	w12, #0x7, 0x1da8 <ltmp0+0x1da8>
    1da0:      	add	x11, x11, #0x1c
    1da4:      	ld1.s	{ v0 }[3], [x11]
    1da8:      	shl.8b	v20, v1, #0x7
    1dac:      	cmlt.8b	v20, v20, #0
    1db0:      	and.8b	v20, v20, v21
    1db4:      	addv.8b	b21, v20
    1db8:      	fmov	w11, s21
    1dbc:      	add	x9, x9, x13
    1dc0:      	movi.2d	v22, #0000000000000000
    1dc4:      	movi.2d	v20, #0000000000000000
    1dc8:      	tbz	w11, #0x0, 0x1e08 <ltmp0+0x1e08>
    1dcc:      	ldr	s22, [x9]
    1dd0:      	tbnz	w11, #0x1, 0x1e0c <ltmp0+0x1e0c>
    1dd4:      	tbz	w11, #0x2, 0x1e18 <ltmp0+0x1e18>
    1dd8:      	add	x12, x9, #0x8
    1ddc:      	ld1.s	{ v22 }[2], [x12]
    1de0:      	tbnz	w11, #0x3, 0x1e1c <ltmp0+0x1e1c>
    1de4:      	tbz	w11, #0x4, 0x1e28 <ltmp0+0x1e28>
    1de8:      	add	x12, x9, #0x10
    1dec:      	ld1.s	{ v20 }[0], [x12]
    1df0:      	tbnz	w11, #0x5, 0x1e2c <ltmp0+0x1e2c>
    1df4:      	tbz	w11, #0x6, 0x1e38 <ltmp0+0x1e38>
    1df8:      	add	x12, x9, #0x18
    1dfc:      	ld1.s	{ v20 }[2], [x12]
    1e00:      	tbnz	w11, #0x7, 0x1e3c <ltmp0+0x1e3c>
    1e04:      	b	0x1e44 <ltmp0+0x1e44>
    1e08:      	tbz	w11, #0x1, 0x1dd4 <ltmp0+0x1dd4>
    1e0c:      	add	x12, x9, #0x4
    1e10:      	ld1.s	{ v22 }[1], [x12]
    1e14:      	tbnz	w11, #0x2, 0x1dd8 <ltmp0+0x1dd8>
    1e18:      	tbz	w11, #0x3, 0x1de4 <ltmp0+0x1de4>
    1e1c:      	add	x12, x9, #0xc
    1e20:      	ld1.s	{ v22 }[3], [x12]
    1e24:      	tbnz	w11, #0x4, 0x1de8 <ltmp0+0x1de8>
    1e28:      	tbz	w11, #0x5, 0x1df4 <ltmp0+0x1df4>
    1e2c:      	add	x12, x9, #0x14
    1e30:      	ld1.s	{ v20 }[1], [x12]
    1e34:      	tbnz	w11, #0x6, 0x1df8 <ltmp0+0x1df8>
    1e38:      	tbz	w11, #0x7, 0x1e44 <ltmp0+0x1e44>
    1e3c:      	add	x9, x9, #0x1c
    1e40:      	ld1.s	{ v20 }[3], [x9]
    1e44:      	umlal.2d	v4, v16, v6
    1e48:      	add.2d	v4, v4, v19
    1e4c:      	ldr	q2, [sp, #0x80]
    1e50:      	ldr	d3, [sp, #0xa0]
    1e54:      	umlal.2d	v2, v3, v6
    1e58:      	add.2d	v3, v2, v19
    1e5c:      	ldr	q2, [sp, #0x90]
    1e60:      	ldr	d5, [sp, #0xb0]
    1e64:      	umlal.2d	v2, v5, v6
    1e68:      	add.2d	v5, v2, v19
    1e6c:      	fneg.4s	v2, v23
    1e70:      	zip1.8b	v6, v1, v0
    1e74:      	ushll.4s	v6, v6, #0x0
    1e78:      	shl.4s	v6, v6, #0x1f
    1e7c:      	cmlt.4s	v6, v6, #0
    1e80:      	and.16b	v2, v6, v2
    1e84:      	ldp	q29, q26, [sp, #0x160]
    1e88:      	fcmge.4s	v6, v2, v29
    1e8c:      	fcmge.4s	v7, v26, v2
    1e90:      	and.16b	v6, v6, v7
    1e94:      	and.16b	v6, v6, v2
    1e98:      	fmul.4s	v7, v6, v15
    1e9c:      	mov.16b	v16, v28
    1ea0:      	bsl.16b	v16, v12, v7
    1ea4:      	fadd.4s	v7, v7, v16
    1ea8:      	fsub.4s	v7, v7, v16
    1eac:      	fcvtzs.4s	v7, v7
    1eb0:      	scvtf.4s	v16, v7
    1eb4:      	fmul.4s	v19, v16, v11
    1eb8:      	fadd.4s	v6, v6, v19
    1ebc:      	fmul.4s	v16, v16, v30
    1ec0:      	fadd.4s	v6, v6, v16
    1ec4:      	fmul.4s	v16, v6, v31
    1ec8:      	fadd.4s	v16, v16, v8
    1ecc:      	fmul.4s	v16, v6, v16
    1ed0:      	fadd.4s	v16, v16, v9
    1ed4:      	fmul.4s	v16, v6, v16
    1ed8:      	fadd.4s	v16, v16, v10
    1edc:      	fmul.4s	v16, v6, v16
    1ee0:      	fadd.4s	v16, v16, v27
    1ee4:      	fmul.4s	v16, v6, v16
    1ee8:      	fadd.4s	v16, v16, v18
    1eec:      	fmul.4s	v19, v6, v6
    1ef0:      	fmul.4s	v16, v19, v16
    1ef4:      	fadd.4s	v6, v6, v16
    1ef8:      	ldr	q18, [sp, #0x150]
    1efc:      	fadd.4s	v6, v6, v18
    1f00:      	sshr.4s	v16, v7, #0x1
    1f04:      	shl.4s	v19, v16, #0x17
    1f08:      	add.4s	v19, v19, v18
    1f0c:      	fmul.4s	v6, v6, v19
    1f10:      	sub.4s	v7, v7, v16
    1f14:      	shl.4s	v7, v7, #0x17
    1f18:      	add.4s	v7, v7, v18
    1f1c:      	fmul.4s	v6, v6, v7
    1f20:      	fcmgt.4s	v7, v29, v2
    1f24:      	fcmgt.4s	v16, v2, v26
    1f28:      	fcmeq.4s	v2, v2, v2
    1f2c:      	fadd.4s	v6, v6, v18
    1f30:      	bit.16b	v6, v18, v7
    1f34:      	bit.16b	v6, v24, v16
    1f38:      	bsl.16b	v2, v6, v25
    1f3c:      	fdiv.4s	v2, v23, v2
    1f40:      	fmul.4s	v2, v22, v2
    1f44:      	stp	q17, q4, [sp, #0x180]
    1f48:      	stp	q3, q5, [sp, #0x1a0]
    1f4c:      	and	x9, x10, #0x7
    1f50:      	add	x11, sp, #0x180
    1f54:      	ldr	x9, [x11, x9, lsl #3]
    1f58:      	sub	x9, x9, x10
    1f5c:      	add	x8, x8, x9, lsl #2
    1f60:      	fmov	w9, s21
    1f64:      	tbz	w9, #0x0, 0x1f8c <ltmp0+0x1f8c>
    1f68:      	str	s2, [x8]
    1f6c:      	tbnz	w9, #0x1, 0x1f90 <ltmp0+0x1f90>
    1f70:      	movi.4s	v21, #0x3f, lsl #24
    1f74:      	ldr	q22, [sp, #0x150]
    1f78:      	tbz	w9, #0x2, 0x1fa4 <ltmp0+0x1fa4>
    1f7c:      	add	x10, x8, #0x8
    1f80:      	st1.s	{ v2 }[2], [x10]
    1f84:      	tbnz	w9, #0x3, 0x1fa8 <ltmp0+0x1fa8>
    1f88:      	b	0x1fb0 <ltmp0+0x1fb0>
    1f8c:      	tbz	w9, #0x1, 0x1f70 <ltmp0+0x1f70>
    1f90:      	add	x10, x8, #0x4
    1f94:      	st1.s	{ v2 }[1], [x10]
    1f98:      	movi.4s	v21, #0x3f, lsl #24
    1f9c:      	ldr	q22, [sp, #0x150]
    1fa0:      	tbnz	w9, #0x2, 0x1f7c <ltmp0+0x1f7c>
    1fa4:      	tbz	w9, #0x3, 0x1fb0 <ltmp0+0x1fb0>
    1fa8:      	add	x10, x8, #0xc
    1fac:      	st1.s	{ v2 }[3], [x10]
    1fb0:      	fneg.4s	v2, v0
    1fb4:      	zip2.8b	v1, v1, v0
    1fb8:      	ushll.4s	v1, v1, #0x0
    1fbc:      	shl.4s	v1, v1, #0x1f
    1fc0:      	cmlt.4s	v1, v1, #0
    1fc4:      	and.16b	v1, v1, v2
    1fc8:      	ldp	q7, q6, [sp, #0x160]
    1fcc:      	fcmge.4s	v2, v1, v7
    1fd0:      	fcmge.4s	v3, v6, v1
    1fd4:      	and.16b	v2, v2, v3
    1fd8:      	and.16b	v2, v2, v1
    1fdc:      	fmul.4s	v3, v2, v15
    1fe0:      	mov.16b	v4, v28
    1fe4:      	bsl.16b	v4, v12, v3
    1fe8:      	fadd.4s	v3, v3, v4
    1fec:      	fsub.4s	v3, v3, v4
    1ff0:      	fcvtzs.4s	v3, v3
    1ff4:      	scvtf.4s	v4, v3
    1ff8:      	fmul.4s	v5, v4, v11
    1ffc:      	fadd.4s	v2, v2, v5
    2000:      	fmul.4s	v4, v4, v30
    2004:      	fadd.4s	v2, v2, v4
    2008:      	fmul.4s	v4, v2, v31
    200c:      	fadd.4s	v4, v4, v8
    2010:      	fmul.4s	v4, v2, v4
    2014:      	fadd.4s	v4, v4, v9
    2018:      	fmul.4s	v4, v2, v4
    201c:      	fadd.4s	v4, v4, v10
    2020:      	fmul.4s	v4, v2, v4
    2024:      	fadd.4s	v4, v4, v27
    2028:      	fmul.4s	v4, v2, v4
    202c:      	fadd.4s	v4, v4, v21
    2030:      	fmul.4s	v5, v2, v2
    2034:      	fmul.4s	v4, v5, v4
    2038:      	fadd.4s	v2, v2, v4
    203c:      	fadd.4s	v2, v2, v22
    2040:      	sshr.4s	v4, v3, #0x1
    2044:      	shl.4s	v5, v4, #0x17
    2048:      	add.4s	v5, v5, v22
    204c:      	fmul.4s	v2, v2, v5
    2050:      	sub.4s	v3, v3, v4
    2054:      	shl.4s	v3, v3, #0x17
    2058:      	add.4s	v3, v3, v22
    205c:      	fmul.4s	v2, v2, v3
    2060:      	fcmgt.4s	v3, v7, v1
    2064:      	fcmgt.4s	v4, v1, v6
    2068:      	fcmeq.4s	v1, v1, v1
    206c:      	fadd.4s	v2, v2, v22
    2070:      	bit.16b	v2, v22, v3
    2074:      	bit.16b	v2, v24, v4
    2078:      	bsl.16b	v1, v2, v25
    207c:      	fdiv.4s	v0, v0, v1
    2080:      	fmul.4s	v0, v20, v0
    2084:      	tbnz	w9, #0x4, 0x1c80 <ltmp0+0x1c80>
    2088:      	tbz	w9, #0x5, 0x1c88 <ltmp0+0x1c88>
    208c:      	add	x10, x8, #0x14
    2090:      	st1.s	{ v0 }[1], [x10]
    2094:      	tbnz	w9, #0x6, 0x1c8c <ltmp0+0x1c8c>
    2098:      	tbz	w9, #0x7, 0x118 <ltmp0+0x118>
    209c:      	add	x8, x8, #0x1c
    20a0:      	st1.s	{ v0 }[3], [x8]
    20a4:      	b	0x118 <ltmp0+0x118>
    20a8:      	ldr	x9, [sp, #0x8]
    20ac:      	stp	w15, w14, [x9]
    20b0:      	str	w12, [x9, #0x8]
    20b4:      	mov	w8, #0x18               ; =24
    20b8:      	str	w8, [x9, #0x24]
    20bc:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    20c0:      	add	sp, sp, #0x330
    20c4:      	ldp	x29, x30, [sp, #0x90]
    20c8:      	ldp	x20, x19, [sp, #0x80]
    20cc:      	ldp	x22, x21, [sp, #0x70]
    20d0:      	ldp	x24, x23, [sp, #0x60]
    20d4:      	ldp	x26, x25, [sp, #0x50]
    20d8:      	ldp	x28, x27, [sp, #0x40]
    20dc:      	ldp	d9, d8, [sp, #0x30]
    20e0:      	ldp	d11, d10, [sp, #0x20]
    20e4:      	ldp	d13, d12, [sp, #0x10]
    20e8:      	ldp	d15, d14, [sp], #0xa0
    20ec:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/capture/swiglu-1024x4097/off/object/tile_xir_w8_36421_1788935102003538_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d11, d10, [sp, #-0x70]!
       4:      	stp	d9, d8, [sp, #0x10]
       8:      	stp	x28, x27, [sp, #0x20]
       c:      	stp	x24, x23, [sp, #0x30]
      10:      	stp	x22, x21, [sp, #0x40]
      14:      	stp	x20, x19, [sp, #0x50]
      18:      	stp	x29, x30, [sp, #0x60]
      1c:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      20:      	sub	sp, sp, #0x50
      24:      	ldr	x22, [x0]
      28:      	ldr	x21, [x0, #0x10]
      2c:      	ldr	x19, [x0, #0x30]
      30:      	ldr	w8, [x1]
      34:      	ldr	w9, [x1, #0x24]
      38:      	add	w8, w9, w8, lsl #5
      3c:      	lsr	w8, w8, #3
      40:      	dup.2s	v0, w8
      44:      	ushll.2d	v0, v0, #0x0
      48:      	subs	x8, x22, x19
      4c:      	mov	w9, #0xfff              ; =4095
      50:      	movk	w9, #0x100, lsl #16
      54:      	ccmp	x8, x9, #0x0, hs
      58:      	cset	w8, hi
      5c:      	subs	x10, x19, x22
      60:      	ccmp	x10, x9, #0x0, hs
      64:      	csinc	w10, w8, wzr, ls
      68:      	subs	x8, x21, x19
      6c:      	ccmp	x8, x9, #0x0, hs
      70:      	cset	w8, hi
      74:      	subs	x11, x19, x21
      78:      	ccmp	x11, x9, #0x0, hs
      7c:      	csinc	w9, w8, wzr, ls
      80:      	fmov	x8, d0
      84:      	add	x8, x8, x8, lsl #12
      88:      	lsl	x8, x8, #2
      8c:      	cmp	w10, #0x1
      90:      	ccmp	w9, #0x0, #0x4, eq
      94:      	b.ne	0x480 <ltmp0+0x480>
      98:      	add	x23, sp, #0x4, lsl #12  ; =0x4000
      9c:      	add	x23, x23, #0x30
      a0:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
      a4:      	add	x0, x0, #0x30
      a8:      	add	x1, x22, x8
      ac:      	mov	w2, #0x4000             ; =16384
      b0:      	str	q0, [sp]
      b4:      	bl	0xb4 <ltmp0+0xb4>
      b8:      	ldr	q0, [sp]
      bc:      	fmov	x8, d0
      c0:      	add	x8, x8, x8, lsl #12
      c4:      	lsl	x24, x8, #2
      c8:      	add	x20, x24, #0x4, lsl #12 ; =0x4000
      cc:      	ldr	s0, [x22, x20]
      d0:      	str	q0, [sp]
      d4:      	str	q0, [sp, #0x8030]
      d8:      	add	x22, sp, #0x10
      dc:      	add	x0, sp, #0x10
      e0:      	add	x1, x21, x24
      e4:      	mov	w2, #0x4000             ; =16384
      e8:      	bl	0xe8 <ltmp0+0xe8>
      ec:      	mov	x8, #0x0                ; =0
      f0:      	ldr	s0, [x21, x20]
      f4:      	mov	w9, #0x42d00000         ; =1120927744
      f8:      	dup.4s	v2, w9
      fc:      	mov	w9, #-0x3d380000        ; =-1027080192
     100:      	dup.4s	v3, w9
     104:      	mov	w9, #0xaa3b             ; =43579
     108:      	movk	w9, #0x3fb8, lsl #16
     10c:      	dup.4s	v4, w9
     110:      	mov	w9, #0x7200             ; =29184
     114:      	movk	w9, #0xbf31, lsl #16
     118:      	dup.4s	v5, w9
     11c:      	mov	w9, #0xbe8e             ; =48782
     120:      	movk	w9, #0xb5bf, lsl #16
     124:      	dup.4s	v6, w9
     128:      	mov	w9, #0x2bda             ; =11226
     12c:      	movk	w9, #0x3950, lsl #16
     130:      	dup.4s	v7, w9
     134:      	mov	w9, #0x96c9             ; =38601
     138:      	movk	w9, #0x3ab6, lsl #16
     13c:      	dup.4s	v16, w9
     140:      	mov	w9, #0x88a6             ; =34982
     144:      	movk	w9, #0x3c08, lsl #16
     148:      	dup.4s	v17, w9
     14c:      	mov	w9, #0xaa7a             ; =43642
     150:      	movk	w9, #0x3d2a, lsl #16
     154:      	dup.4s	v18, w9
     158:      	mov	w9, #0xaaab             ; =43691
     15c:      	movk	w9, #0x3e2a, lsl #16
     160:      	dup.4s	v19, w9
     164:      	str	q0, [sp, #0x4010]
     168:      	add	x9, x19, x24
     16c:      	movi.4s	v20, #0x4b, lsl #24
     170:      	mvni.4s	v21, #0x80, lsl #24
     174:      	movi.4s	v22, #0x3f, lsl #24
     178:      	fmov.4s	v1, #1.00000000
     17c:      	mvni.4s	v23, #0x7f, msl #16
     180:      	fneg.4s	v23, v23
     184:      	mvni.4s	v24, #0x3f, msl #16
     188:      	fneg.4s	v24, v24
     18c:      	add	x10, x23, x8
     190:      	ldp	q25, q26, [x10]
     194:      	fneg.4s	v27, v26
     198:      	fneg.4s	v28, v25
     19c:      	fcmge.4s	v29, v2, v25
     1a0:      	fcmge.4s	v30, v2, v26
     1a4:      	fcmge.4s	v31, v25, v3
     1a8:      	fcmge.4s	v8, v26, v3
     1ac:      	and.16b	v30, v30, v8
     1b0:      	and.16b	v29, v29, v31
     1b4:      	and.16b	v28, v29, v28
     1b8:      	and.16b	v27, v30, v27
     1bc:      	fmul.4s	v29, v27, v4
     1c0:      	fmul.4s	v30, v28, v4
     1c4:      	mov.16b	v31, v21
     1c8:      	bsl.16b	v31, v20, v30
     1cc:      	mov.16b	v8, v21
     1d0:      	bsl.16b	v8, v20, v29
     1d4:      	fadd.4s	v29, v29, v8
     1d8:      	fadd.4s	v30, v30, v31
     1dc:      	fsub.4s	v30, v30, v31
     1e0:      	fsub.4s	v29, v29, v8
     1e4:      	fcvtzs.4s	v29, v29
     1e8:      	fcvtzs.4s	v30, v30
     1ec:      	scvtf.4s	v31, v30
     1f0:      	scvtf.4s	v8, v29
     1f4:      	fmul.4s	v9, v8, v5
     1f8:      	fmul.4s	v10, v31, v5
     1fc:      	fadd.4s	v28, v28, v10
     200:      	fadd.4s	v27, v27, v9
     204:      	fmul.4s	v31, v31, v6
     208:      	fmul.4s	v8, v8, v6
     20c:      	fadd.4s	v27, v27, v8
     210:      	fadd.4s	v28, v28, v31
     214:      	fmul.4s	v31, v28, v7
     218:      	fmul.4s	v8, v27, v7
     21c:      	fadd.4s	v8, v8, v16
     220:      	fadd.4s	v31, v31, v16
     224:      	fmul.4s	v31, v28, v31
     228:      	fmul.4s	v8, v27, v8
     22c:      	fadd.4s	v8, v8, v17
     230:      	fadd.4s	v31, v31, v17
     234:      	fmul.4s	v31, v28, v31
     238:      	fmul.4s	v8, v27, v8
     23c:      	fadd.4s	v8, v8, v18
     240:      	fadd.4s	v31, v31, v18
     244:      	fmul.4s	v31, v28, v31
     248:      	fmul.4s	v8, v27, v8
     24c:      	fadd.4s	v8, v8, v19
     250:      	fadd.4s	v31, v31, v19
     254:      	fmul.4s	v31, v28, v31
     258:      	fmul.4s	v8, v27, v8
     25c:      	fadd.4s	v8, v8, v22
     260:      	fadd.4s	v31, v31, v22
     264:      	fmul.4s	v9, v27, v27
     268:      	fmul.4s	v10, v28, v28
     26c:      	fmul.4s	v31, v10, v31
     270:      	fmul.4s	v8, v9, v8
     274:      	fadd.4s	v27, v27, v8
     278:      	fadd.4s	v28, v28, v31
     27c:      	sshr.4s	v31, v30, #0x1
     280:      	fadd.4s	v28, v28, v1
     284:      	sshr.4s	v8, v29, #0x1
     288:      	shl.4s	v9, v8, #0x17
     28c:      	shl.4s	v10, v31, #0x17
     290:      	add.4s	v10, v10, v1
     294:      	add.4s	v9, v9, v1
     298:      	fadd.4s	v27, v27, v1
     29c:      	fmul.4s	v27, v27, v9
     2a0:      	sub.4s	v29, v29, v8
     2a4:      	sub.4s	v30, v30, v31
     2a8:      	shl.4s	v30, v30, #0x17
     2ac:      	shl.4s	v29, v29, #0x17
     2b0:      	fmul.4s	v28, v28, v10
     2b4:      	add.4s	v29, v29, v1
     2b8:      	add.4s	v30, v30, v1
     2bc:      	fmul.4s	v28, v28, v30
     2c0:      	fmul.4s	v27, v27, v29
     2c4:      	fcmgt.4s	v29, v26, v2
     2c8:      	fcmgt.4s	v30, v25, v2
     2cc:      	fcmgt.4s	v31, v3, v25
     2d0:      	fcmgt.4s	v8, v3, v26
     2d4:      	fcmeq.4s	v9, v26, v26
     2d8:      	fadd.4s	v27, v27, v1
     2dc:      	fadd.4s	v28, v28, v1
     2e0:      	fcmeq.4s	v10, v25, v25
     2e4:      	bit.16b	v28, v1, v30
     2e8:      	bit.16b	v27, v1, v29
     2ec:      	bit.16b	v27, v23, v8
     2f0:      	bit.16b	v28, v23, v31
     2f4:      	bif.16b	v28, v24, v10
     2f8:      	bif.16b	v27, v24, v9
     2fc:      	fdiv.4s	v26, v26, v27
     300:      	fdiv.4s	v25, v25, v28
     304:      	add	x10, x22, x8
     308:      	ldp	q28, q27, [x10]
     30c:      	fmul.4s	v25, v28, v25
     310:      	fmul.4s	v26, v27, v26
     314:      	add	x10, x9, x8
     318:      	stp	q25, q26, [x10]
     31c:      	add	x8, x8, #0x20
     320:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     324:      	b.ne	0x18c <ltmp0+0x18c>
     328:      	movi.2d	v3, #0000000000000000
     32c:      	movi.2d	v2, #0000000000000000
     330:      	ldr	q4, [sp]
     334:      	mov.s	v2[0], v4[0]
     338:      	fneg.4s	v4, v2
     33c:      	mov.s	v3[0], v4[0]
     340:      	mov	w8, #-0x3d300000        ; =-1026555904
     344:      	dup.4s	v4, w8
     348:      	fcmge.4s	v5, v3, v4
     34c:      	mov	w8, #0x42c80000         ; =1120403456
     350:      	dup.4s	v6, w8
     354:      	fcmge.4s	v7, v6, v3
     358:      	and.16b	v5, v5, v7
     35c:      	and.16b	v5, v5, v3
     360:      	mov	w8, #0xaa3b             ; =43579
     364:      	movk	w8, #0x3fb8, lsl #16
     368:      	dup.4s	v7, w8
     36c:      	fmul.4s	v7, v5, v7
     370:      	movi.4s	v16, #0x4b, lsl #24
     374:      	mvni.4s	v17, #0x80, lsl #24
     378:      	bif.16b	v16, v7, v17
     37c:      	fadd.4s	v7, v7, v16
     380:      	fsub.4s	v7, v7, v16
     384:      	fcvtzs.4s	v7, v7
     388:      	scvtf.4s	v16, v7
     38c:      	mov	w8, #0x7200             ; =29184
     390:      	movk	w8, #0xbf31, lsl #16
     394:      	dup.4s	v17, w8
     398:      	fmul.4s	v17, v16, v17
     39c:      	mov	w8, #0xbe8e             ; =48782
     3a0:      	movk	w8, #0xb5bf, lsl #16
     3a4:      	dup.4s	v18, w8
     3a8:      	fadd.4s	v5, v5, v17
     3ac:      	fmul.4s	v16, v16, v18
     3b0:      	fadd.4s	v5, v5, v16
     3b4:      	mov	w8, #0x2bda             ; =11226
     3b8:      	movk	w8, #0x3950, lsl #16
     3bc:      	dup.4s	v16, w8
     3c0:      	fmul.4s	v16, v5, v16
     3c4:      	mov	w8, #0x96c9             ; =38601
     3c8:      	movk	w8, #0x3ab6, lsl #16
     3cc:      	dup.4s	v17, w8
     3d0:      	fadd.4s	v16, v16, v17
     3d4:      	fmul.4s	v16, v5, v16
     3d8:      	mov	w8, #0x88a6             ; =34982
     3dc:      	movk	w8, #0x3c08, lsl #16
     3e0:      	dup.4s	v17, w8
     3e4:      	fadd.4s	v16, v16, v17
     3e8:      	fmul.4s	v16, v5, v16
     3ec:      	mov	w8, #0xaa7a             ; =43642
     3f0:      	movk	w8, #0x3d2a, lsl #16
     3f4:      	dup.4s	v17, w8
     3f8:      	fadd.4s	v16, v16, v17
     3fc:      	mov	w8, #0xaaab             ; =43691
     400:      	movk	w8, #0x3e2a, lsl #16
     404:      	dup.4s	v17, w8
     408:      	fmul.4s	v16, v5, v16
     40c:      	fadd.4s	v16, v16, v17
     410:      	fmul.4s	v16, v5, v16
     414:      	movi.4s	v17, #0x3f, lsl #24
     418:      	fadd.4s	v16, v16, v17
     41c:      	fmul.4s	v17, v5, v5
     420:      	fmul.4s	v16, v17, v16
     424:      	fadd.4s	v5, v5, v16
     428:      	fadd.4s	v5, v5, v1
     42c:      	sshr.4s	v16, v7, #0x1
     430:      	shl.4s	v17, v16, #0x17
     434:      	add.4s	v17, v17, v1
     438:      	fmul.4s	v5, v5, v17
     43c:      	sub.4s	v7, v7, v16
     440:      	shl.4s	v7, v7, #0x17
     444:      	add.4s	v7, v7, v1
     448:      	fmul.4s	v5, v5, v7
     44c:      	fcmgt.4s	v4, v4, v3
     450:      	fcmgt.4s	v6, v3, v6
     454:      	fcmeq.4s	v3, v3, v3
     458:      	fadd.4s	v5, v5, v1
     45c:      	bif.16b	v1, v5, v4
     460:      	mvni.4s	v4, #0x7f, msl #16
     464:      	fneg.4s	v4, v4
     468:      	bit.16b	v1, v4, v6
     46c:      	mvni.4s	v4, #0x3f, msl #16
     470:      	fneg.4s	v4, v4
     474:      	bif.16b	v1, v4, v3
     478:      	fdiv.4s	v1, v2, v1
     47c:      	b	0x810 <ltmp0+0x810>
     480:      	mov	x9, #0x0                ; =0
     484:      	add	x10, x19, x8
     488:      	add	x11, x21, x8
     48c:      	mov	w12, #0x42d00000        ; =1120927744
     490:      	dup.4s	v1, w12
     494:      	mov	w12, #-0x3d380000       ; =-1027080192
     498:      	dup.4s	v2, w12
     49c:      	mov	w12, #0xaa3b            ; =43579
     4a0:      	movk	w12, #0x3fb8, lsl #16
     4a4:      	dup.4s	v3, w12
     4a8:      	mov	w12, #0x7200            ; =29184
     4ac:      	movk	w12, #0xbf31, lsl #16
     4b0:      	dup.4s	v4, w12
     4b4:      	mov	w12, #0xbe8e            ; =48782
     4b8:      	movk	w12, #0xb5bf, lsl #16
     4bc:      	dup.4s	v5, w12
     4c0:      	mov	w12, #0x2bda            ; =11226
     4c4:      	movk	w12, #0x3950, lsl #16
     4c8:      	dup.4s	v6, w12
     4cc:      	mov	w12, #0x96c9            ; =38601
     4d0:      	movk	w12, #0x3ab6, lsl #16
     4d4:      	dup.4s	v7, w12
     4d8:      	mov	w12, #0x88a6            ; =34982
     4dc:      	movk	w12, #0x3c08, lsl #16
     4e0:      	dup.4s	v16, w12
     4e4:      	mov	w12, #0xaa7a            ; =43642
     4e8:      	movk	w12, #0x3d2a, lsl #16
     4ec:      	dup.4s	v17, w12
     4f0:      	mov	w12, #0xaaab            ; =43691
     4f4:      	movk	w12, #0x3e2a, lsl #16
     4f8:      	dup.4s	v18, w12
     4fc:      	add	x12, x22, x8
     500:      	movi.4s	v19, #0x4b, lsl #24
     504:      	mvni.4s	v20, #0x80, lsl #24
     508:      	movi.4s	v21, #0x3f, lsl #24
     50c:      	fmov.4s	v0, #1.00000000
     510:      	mvni.4s	v22, #0x7f, msl #16
     514:      	fneg.4s	v22, v22
     518:      	mvni.4s	v23, #0x3f, msl #16
     51c:      	fneg.4s	v23, v23
     520:      	add	x13, x12, x9
     524:      	ldp	q24, q25, [x13]
     528:      	fneg.4s	v26, v25
     52c:      	fneg.4s	v27, v24
     530:      	fcmge.4s	v28, v1, v24
     534:      	fcmge.4s	v29, v1, v25
     538:      	fcmge.4s	v30, v24, v2
     53c:      	fcmge.4s	v31, v25, v2
     540:      	and.16b	v29, v29, v31
     544:      	and.16b	v28, v28, v30
     548:      	and.16b	v27, v28, v27
     54c:      	and.16b	v26, v29, v26
     550:      	fmul.4s	v28, v26, v3
     554:      	fmul.4s	v29, v27, v3
     558:      	mov.16b	v30, v20
     55c:      	bsl.16b	v30, v19, v29
     560:      	mov.16b	v31, v20
     564:      	bsl.16b	v31, v19, v28
     568:      	fadd.4s	v28, v28, v31
     56c:      	fadd.4s	v29, v29, v30
     570:      	fsub.4s	v29, v29, v30
     574:      	fsub.4s	v28, v28, v31
     578:      	fcvtzs.4s	v28, v28
     57c:      	fcvtzs.4s	v29, v29
     580:      	scvtf.4s	v30, v29
     584:      	scvtf.4s	v31, v28
     588:      	fmul.4s	v8, v31, v4
     58c:      	fmul.4s	v9, v30, v4
     590:      	fadd.4s	v27, v27, v9
     594:      	fadd.4s	v26, v26, v8
     598:      	fmul.4s	v30, v30, v5
     59c:      	fmul.4s	v31, v31, v5
     5a0:      	fadd.4s	v26, v26, v31
     5a4:      	fadd.4s	v27, v27, v30
     5a8:      	fmul.4s	v30, v27, v6
     5ac:      	fmul.4s	v31, v26, v6
     5b0:      	fadd.4s	v31, v31, v7
     5b4:      	fadd.4s	v30, v30, v7
     5b8:      	fmul.4s	v30, v27, v30
     5bc:      	fmul.4s	v31, v26, v31
     5c0:      	fadd.4s	v31, v31, v16
     5c4:      	fadd.4s	v30, v30, v16
     5c8:      	fmul.4s	v30, v27, v30
     5cc:      	fmul.4s	v31, v26, v31
     5d0:      	fadd.4s	v31, v31, v17
     5d4:      	fadd.4s	v30, v30, v17
     5d8:      	fmul.4s	v30, v27, v30
     5dc:      	fmul.4s	v31, v26, v31
     5e0:      	fadd.4s	v31, v31, v18
     5e4:      	fadd.4s	v30, v30, v18
     5e8:      	fmul.4s	v30, v27, v30
     5ec:      	fmul.4s	v31, v26, v31
     5f0:      	fadd.4s	v31, v31, v21
     5f4:      	fadd.4s	v30, v30, v21
     5f8:      	fmul.4s	v8, v26, v26
     5fc:      	fmul.4s	v9, v27, v27
     600:      	fmul.4s	v30, v9, v30
     604:      	fmul.4s	v31, v8, v31
     608:      	fadd.4s	v26, v26, v31
     60c:      	fadd.4s	v27, v27, v30
     610:      	sshr.4s	v30, v29, #0x1
     614:      	fadd.4s	v27, v27, v0
     618:      	sshr.4s	v31, v28, #0x1
     61c:      	shl.4s	v8, v31, #0x17
     620:      	shl.4s	v9, v30, #0x17
     624:      	add.4s	v9, v9, v0
     628:      	add.4s	v8, v8, v0
     62c:      	fadd.4s	v26, v26, v0
     630:      	fmul.4s	v26, v26, v8
     634:      	sub.4s	v28, v28, v31
     638:      	sub.4s	v29, v29, v30
     63c:      	shl.4s	v29, v29, #0x17
     640:      	shl.4s	v28, v28, #0x17
     644:      	fmul.4s	v27, v27, v9
     648:      	add.4s	v28, v28, v0
     64c:      	add.4s	v29, v29, v0
     650:      	fmul.4s	v27, v27, v29
     654:      	fmul.4s	v26, v26, v28
     658:      	fcmgt.4s	v28, v25, v1
     65c:      	fcmgt.4s	v29, v24, v1
     660:      	fcmgt.4s	v30, v2, v24
     664:      	fcmgt.4s	v31, v2, v25
     668:      	fcmeq.4s	v8, v25, v25
     66c:      	fadd.4s	v26, v26, v0
     670:      	fadd.4s	v27, v27, v0
     674:      	fcmeq.4s	v9, v24, v24
     678:      	bit.16b	v27, v0, v29
     67c:      	bit.16b	v26, v0, v28
     680:      	bit.16b	v26, v22, v31
     684:      	bit.16b	v27, v22, v30
     688:      	bif.16b	v27, v23, v9
     68c:      	bif.16b	v26, v23, v8
     690:      	fdiv.4s	v25, v25, v26
     694:      	fdiv.4s	v24, v24, v27
     698:      	add	x13, x11, x9
     69c:      	ldp	q27, q26, [x13]
     6a0:      	fmul.4s	v24, v27, v24
     6a4:      	fmul.4s	v25, v26, v25
     6a8:      	add	x13, x10, x9
     6ac:      	stp	q24, q25, [x13]
     6b0:      	add	x9, x9, #0x20
     6b4:      	cmp	x9, #0x4, lsl #12       ; =0x4000
     6b8:      	b.ne	0x520 <ltmp0+0x520>
     6bc:      	add	x20, x8, #0x4, lsl #12  ; =0x4000
     6c0:      	ldr	s1, [x22, x20]
     6c4:      	movi.2d	v2, #0000000000000000
     6c8:      	fneg.4s	v3, v1
     6cc:      	mov.s	v2[0], v3[0]
     6d0:      	mov	w8, #-0x3d300000        ; =-1026555904
     6d4:      	dup.4s	v3, w8
     6d8:      	mov	w8, #0x42c80000         ; =1120403456
     6dc:      	dup.4s	v4, w8
     6e0:      	fcmge.4s	v5, v2, v3
     6e4:      	fcmge.4s	v6, v4, v2
     6e8:      	and.16b	v5, v5, v6
     6ec:      	mov	w8, #0xaa3b             ; =43579
     6f0:      	movk	w8, #0x3fb8, lsl #16
     6f4:      	dup.4s	v6, w8
     6f8:      	and.16b	v5, v5, v2
     6fc:      	fmul.4s	v6, v5, v6
     700:      	movi.4s	v7, #0x4b, lsl #24
     704:      	mvni.4s	v16, #0x80, lsl #24
     708:      	bif.16b	v7, v6, v16
     70c:      	fadd.4s	v6, v6, v7
     710:      	fsub.4s	v6, v6, v7
     714:      	fcvtzs.4s	v6, v6
     718:      	scvtf.4s	v7, v6
     71c:      	mov	w8, #0x7200             ; =29184
     720:      	movk	w8, #0xbf31, lsl #16
     724:      	dup.4s	v16, w8
     728:      	fmul.4s	v16, v7, v16
     72c:      	fadd.4s	v5, v5, v16
     730:      	mov	w8, #0xbe8e             ; =48782
     734:      	movk	w8, #0xb5bf, lsl #16
     738:      	dup.4s	v16, w8
     73c:      	fmul.4s	v7, v7, v16
     740:      	fadd.4s	v5, v5, v7
     744:      	mov	w8, #0x2bda             ; =11226
     748:      	movk	w8, #0x3950, lsl #16
     74c:      	dup.4s	v7, w8
     750:      	fmul.4s	v7, v5, v7
     754:      	mov	w8, #0x96c9             ; =38601
     758:      	movk	w8, #0x3ab6, lsl #16
     75c:      	dup.4s	v16, w8
     760:      	fadd.4s	v7, v7, v16
     764:      	mov	w8, #0x88a6             ; =34982
     768:      	movk	w8, #0x3c08, lsl #16
     76c:      	dup.4s	v16, w8
     770:      	fmul.4s	v7, v5, v7
     774:      	fadd.4s	v7, v7, v16
     778:      	fmul.4s	v7, v5, v7
     77c:      	mov	w8, #0xaa7a             ; =43642
     780:      	movk	w8, #0x3d2a, lsl #16
     784:      	dup.4s	v16, w8
     788:      	fadd.4s	v7, v7, v16
     78c:      	fmul.4s	v7, v5, v7
     790:      	mov	w8, #0xaaab             ; =43691
     794:      	movk	w8, #0x3e2a, lsl #16
     798:      	dup.4s	v16, w8
     79c:      	fadd.4s	v7, v7, v16
     7a0:      	fmul.4s	v7, v5, v7
     7a4:      	movi.4s	v16, #0x3f, lsl #24
     7a8:      	fadd.4s	v7, v7, v16
     7ac:      	fmul.4s	v16, v5, v5
     7b0:      	fmul.4s	v7, v16, v7
     7b4:      	fadd.4s	v5, v5, v7
     7b8:      	fadd.4s	v5, v5, v0
     7bc:      	sshr.4s	v7, v6, #0x1
     7c0:      	shl.4s	v16, v7, #0x17
     7c4:      	add.4s	v16, v16, v0
     7c8:      	fmul.4s	v5, v5, v16
     7cc:      	sub.4s	v6, v6, v7
     7d0:      	shl.4s	v6, v6, #0x17
     7d4:      	add.4s	v6, v6, v0
     7d8:      	fmul.4s	v5, v5, v6
     7dc:      	fcmgt.4s	v3, v3, v2
     7e0:      	fcmgt.4s	v4, v2, v4
     7e4:      	fcmeq.4s	v2, v2, v2
     7e8:      	fadd.4s	v5, v5, v0
     7ec:      	bif.16b	v0, v5, v3
     7f0:      	mvni.4s	v3, #0x7f, msl #16
     7f4:      	fneg.4s	v3, v3
     7f8:      	bit.16b	v0, v3, v4
     7fc:      	mvni.4s	v3, #0x3f, msl #16
     800:      	fneg.4s	v3, v3
     804:      	bif.16b	v0, v3, v2
     808:      	fdiv.4s	v0, v1, v0
     80c:      	ldr	s1, [x21, x20]
     810:      	fmul.4s	v0, v1, v0
     814:      	str	s0, [x19, x20]
     818:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
     81c:      	add	sp, sp, #0x50
     820:      	ldp	x29, x30, [sp, #0x60]
     824:      	ldp	x20, x19, [sp, #0x50]
     828:      	ldp	x22, x21, [sp, #0x40]
     82c:      	ldp	x24, x23, [sp, #0x30]
     830:      	ldp	x28, x27, [sp, #0x20]
     834:      	ldp	d9, d8, [sp, #0x10]
     838:      	ldp	d11, d10, [sp], #0x70
     83c:      	ret

0000000000000840 <_llm_rows.packet_batch.blocks>:
     840:      	stp	d15, d14, [sp, #-0xa0]!
     844:      	stp	d13, d12, [sp, #0x10]
     848:      	stp	d11, d10, [sp, #0x20]
     84c:      	stp	d9, d8, [sp, #0x30]
     850:      	stp	x28, x27, [sp, #0x40]
     854:      	stp	x26, x25, [sp, #0x50]
     858:      	stp	x24, x23, [sp, #0x60]
     85c:      	stp	x22, x21, [sp, #0x70]
     860:      	stp	x20, x19, [sp, #0x80]
     864:      	stp	x29, x30, [sp, #0x90]
     868:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
     86c:      	sub	sp, sp, #0x2d0
     870:      	str	x0, [sp, #0xe8]
     874:      	cbz	w3, 0x1c84 <_llm_rows.packet_batch.blocks+0x1444>
     878:      	mov	x19, x3
     87c:      	mov	x20, x2
     880:      	mov	w22, #0x0               ; =0
     884:      	ldp	w9, w8, [x2, #0x2c]
     888:      	stp	w8, w9, [sp, #0xe0]
     88c:      	ldp	w27, w25, [x2]
     890:      	adrp	x8, 0x0 <ltmp0>
     894:      	ldr	q0, [x8]
     898:      	str	q0, [sp, #0xc0]
     89c:      	adrp	x8, 0x0 <ltmp0>
     8a0:      	ldr	q0, [x8]
     8a4:      	str	q0, [sp, #0xb0]
     8a8:      	adrp	x8, 0x0 <ltmp0>
     8ac:      	ldr	q0, [x8]
     8b0:      	str	q0, [sp, #0xa0]
     8b4:      	adrp	x8, 0x0 <ltmp0>
     8b8:      	ldr	q0, [x8]
     8bc:      	str	q0, [sp, #0x90]
     8c0:      	adrp	x8, 0x0 <ltmp0>
     8c4:      	ldr	q0, [x8]
     8c8:      	str	q0, [sp, #0x80]
     8cc:      	adrp	x8, 0x0 <ltmp0>
     8d0:      	ldr	q0, [x8]
     8d4:      	str	q0, [sp, #0x70]
     8d8:      	adrp	x8, 0x0 <ltmp0>
     8dc:      	ldr	q1, [x8]
     8e0:      	mvni.4s	v0, #0x7f, msl #16
     8e4:      	fneg.4s	v0, v0
     8e8:      	str	q0, [sp, #0x110]
     8ec:      	mvni.4s	v0, #0x3f, msl #16
     8f0:      	fneg.4s	v0, v0
     8f4:      	stp	q1, q0, [sp, #0xf0]
     8f8:      	add	x26, sp, #0x4, lsl #12  ; =0x4000
     8fc:      	add	x26, x26, #0x2b0
     900:      	ldp	w28, w23, [x2, #0x8]
     904:      	add	x24, sp, #0x290
     908:      	str	w3, [sp, #0xdc]
     90c:      	b	0x954 <_llm_rows.packet_batch.blocks+0x114>
     910:      	mov	w8, #0x18               ; =24
     914:      	str	w8, [x20, #0x24]
     918:      	ldr	w19, [sp, #0xdc]
     91c:      	add	w8, w27, #0x1
     920:      	ldp	w10, w9, [sp, #0xe0]
     924:      	cmp	w8, w9
     928:      	cset	w8, eq
     92c:      	csinc	w27, wzr, w27, eq
     930:      	cinc	w9, w25, eq
     934:      	cmp	w9, w10
     938:      	cset	w10, eq
     93c:      	ands	w8, w8, w10
     940:      	csel	w25, wzr, w9, ne
     944:      	add	w28, w28, w8
     948:      	add	w22, w22, #0x1
     94c:      	cmp	w22, w19
     950:      	b.eq	0x1c84 <_llm_rows.packet_batch.blocks+0x1444>
     954:      	ubfiz	x8, x27, #5, #32
     958:      	cmp	x8, x23
     95c:      	csel	x9, x8, xzr, ls
     960:      	subs	x10, x23, x9
     964:      	cmp	x10, #0x20
     968:      	mov	w11, #0x20              ; =32
     96c:      	csel	x10, x10, x11, lo
     970:      	cmp	x23, x9
     974:      	stp	w27, w25, [x20]
     978:      	str	w28, [x20, #0x8]
     97c:      	str	wzr, [x20, #0x24]
     980:      	ccmp	x8, x23, #0x2, hi
     984:      	csel	x21, x10, xzr, ls
     988:      	cmp	x21, #0x20
     98c:      	b.lo	0x9e0 <_llm_rows.packet_batch.blocks+0x1a0>
     990:      	ldr	x21, [sp, #0xe8]
     994:      	mov	x0, x21
     998:      	mov	x1, x20
     99c:      	bl	0x99c <_llm_rows.packet_batch.blocks+0x15c>
     9a0:      	mov	w8, #0x8                ; =8
     9a4:      	str	w8, [x20, #0x24]
     9a8:      	mov	x0, x21
     9ac:      	mov	x1, x20
     9b0:      	bl	0x9b0 <_llm_rows.packet_batch.blocks+0x170>
     9b4:      	mov	w8, #0x10               ; =16
     9b8:      	str	w8, [x20, #0x24]
     9bc:      	mov	x0, x21
     9c0:      	mov	x1, x20
     9c4:      	bl	0x9c4 <_llm_rows.packet_batch.blocks+0x184>
     9c8:      	mov	w8, #0x18               ; =24
     9cc:      	str	w8, [x20, #0x24]
     9d0:      	mov	x0, x21
     9d4:      	mov	x1, x20
     9d8:      	bl	0x9d8 <_llm_rows.packet_batch.blocks+0x198>
     9dc:      	b	0x91c <_llm_rows.packet_batch.blocks+0xdc>
     9e0:      	lsr	x19, x21, #3
     9e4:      	cmp	x21, #0x8
     9e8:      	b.lo	0xa34 <_llm_rows.packet_batch.blocks+0x1f4>
     9ec:      	str	wzr, [x20, #0x24]
     9f0:      	ldr	x0, [sp, #0xe8]
     9f4:      	mov	x1, x20
     9f8:      	bl	0x9f8 <_llm_rows.packet_batch.blocks+0x1b8>
     9fc:      	cmp	x19, #0x1
     a00:      	b.eq	0xa34 <_llm_rows.packet_batch.blocks+0x1f4>
     a04:      	mov	w8, #0x8                ; =8
     a08:      	str	w8, [x20, #0x24]
     a0c:      	ldr	x0, [sp, #0xe8]
     a10:      	mov	x1, x20
     a14:      	bl	0xa14 <_llm_rows.packet_batch.blocks+0x1d4>
     a18:      	cmp	x19, #0x2
     a1c:      	b.eq	0xa34 <_llm_rows.packet_batch.blocks+0x1f4>
     a20:      	mov	w8, #0x10               ; =16
     a24:      	str	w8, [x20, #0x24]
     a28:      	ldr	x0, [sp, #0xe8]
     a2c:      	mov	x1, x20
     a30:      	bl	0xa30 <_llm_rows.packet_batch.blocks+0x1f0>
     a34:      	and	w8, w21, #0x7
     a38:      	cbz	w8, 0x910 <_llm_rows.packet_batch.blocks+0xd0>
     a3c:      	dup.4s	v0, w8
     a40:      	ldp	q2, q1, [sp, #0xb0]
     a44:      	cmhi.4s	v20, v0, v2
     a48:      	cmhi.4s	v19, v0, v1
     a4c:      	uzp1.8h	v30, v19, v20
     a50:      	umaxv.8h	h0, v30
     a54:      	fmov	w8, s0
     a58:      	tbz	w8, #0x0, 0x910 <_llm_rows.packet_batch.blocks+0xd0>
     a5c:      	ldr	x8, [sp, #0xe8]
     a60:      	ldr	x11, [x8]
     a64:      	ldr	x9, [x8, #0x10]
     a68:      	ldr	x8, [x8, #0x30]
     a6c:      	sshll.2d	v0, v19, #0x0
     a70:      	sshll.2d	v1, v20, #0x0
     a74:      	sshll2.2d	v11, v19, #0x0
     a78:      	sshll2.2d	v10, v20, #0x0
     a7c:      	ldp	q2, q3, [sp, #0x90]
     a80:      	and.16b	v21, v10, v3
     a84:      	and.16b	v23, v11, v2
     a88:      	ldr	q2, [sp, #0x80]
     a8c:      	and.16b	v22, v1, v2
     a90:      	ldr	q1, [sp, #0x70]
     a94:      	and.16b	v29, v0, v1
     a98:      	ubfiz	w10, w27, #2, #27
     a9c:      	orr	w10, w10, w19
     aa0:      	dup.4s	v0, w10
     aa4:      	and.16b	v1, v19, v0
     aa8:      	and.16b	v0, v20, v0
     aac:      	ushll2.2d	v24, v0, #0x0
     ab0:      	ushll2.2d	v27, v1, #0x0
     ab4:      	ushll.2d	v25, v0, #0x0
     ab8:      	ushll.2d	v0, v1, #0x0
     abc:      	subs	x10, x11, x8
     ac0:      	mov	w14, #0xfff             ; =4095
     ac4:      	movk	w14, #0x100, lsl #16
     ac8:      	ccmp	x10, x14, #0x0, hs
     acc:      	cset	w10, hi
     ad0:      	subs	x12, x8, x11
     ad4:      	ccmp	x12, x14, #0x0, hs
     ad8:      	csinc	w12, w10, wzr, ls
     adc:      	subs	x10, x9, x8
     ae0:      	ccmp	x10, x14, #0x0, hs
     ae4:      	cset	w10, hi
     ae8:      	subs	x13, x8, x9
     aec:      	ccmp	x13, x14, #0x0, hs
     af0:      	csinc	w10, w10, wzr, ls
     af4:      	xtn.2s	v31, v0
     af8:      	fmov	x13, d0
     afc:      	add	x13, x13, x13, lsl #12
     b00:      	mov	w14, #-0x3d300000       ; =-1026555904
     b04:      	dup.4s	v1, w14
     b08:      	mov	w14, #0x42c80000        ; =1120403456
     b0c:      	dup.4s	v0, w14
     b10:      	mov	w14, #0xaa3b            ; =43579
     b14:      	movk	w14, #0x3fb8, lsl #16
     b18:      	dup.4s	v18, w14
     b1c:      	mov	w14, #0x7200            ; =29184
     b20:      	movk	w14, #0xbf31, lsl #16
     b24:      	dup.4s	v17, w14
     b28:      	mov	w14, #0xbe8e            ; =48782
     b2c:      	movk	w14, #0xb5bf, lsl #16
     b30:      	dup.4s	v16, w14
     b34:      	mov	w14, #0x2bda            ; =11226
     b38:      	movk	w14, #0x3950, lsl #16
     b3c:      	dup.4s	v7, w14
     b40:      	mov	w14, #0x96c9            ; =38601
     b44:      	movk	w14, #0x3ab6, lsl #16
     b48:      	dup.4s	v6, w14
     b4c:      	mov	w14, #0x88a6            ; =34982
     b50:      	movk	w14, #0x3c08, lsl #16
     b54:      	dup.4s	v5, w14
     b58:      	lsl	x14, x13, #2
     b5c:      	mov	w13, #0xaa7a            ; =43642
     b60:      	movk	w13, #0x3d2a, lsl #16
     b64:      	dup.4s	v4, w13
     b68:      	mov	w13, #0xaaab            ; =43691
     b6c:      	movk	w13, #0x3e2a, lsl #16
     b70:      	dup.4s	v3, w13
     b74:      	fmov.4s	v2, #1.00000000
     b78:      	xtn.2s	v24, v24
     b7c:      	xtn.2s	v26, v25
     b80:      	mov	w13, #0x1001            ; =4097
     b84:      	dup.2s	v25, w13
     b88:      	xtn.2s	v27, v27
     b8c:      	cmp	w12, #0x1
     b90:      	b.ne	0xf28 <_llm_rows.packet_batch.blocks+0x6e8>
     b94:      	cbz	w10, 0xf28 <_llm_rows.packet_batch.blocks+0x6e8>
     b98:      	mov	x10, #0x0               ; =0
     b9c:      	add	x12, x8, x14
     ba0:      	add	x13, x9, x14
     ba4:      	add	x14, x11, x14
     ba8:      	ldr	q28, [sp, #0xf0]
     bac:      	and.16b	v28, v30, v28
     bb0:      	addv.8h	h28, v28
     bb4:      	fmov	w15, s28
     bb8:      	b	0xbc8 <_llm_rows.packet_batch.blocks+0x388>
     bbc:      	add	x10, x10, #0x20
     bc0:      	cmp	x10, #0x4, lsl #12      ; =0x4000
     bc4:      	b.eq	0x188c <_llm_rows.packet_batch.blocks+0x104c>
     bc8:      	add	x16, x14, x10
     bcc:      	movi.2d	v8, #0000000000000000
     bd0:      	movi.2d	v30, #0000000000000000
     bd4:      	tbz	w15, #0x0, 0xc68 <_llm_rows.packet_batch.blocks+0x428>
     bd8:      	ldr	s8, [x16]
     bdc:      	and	w17, w15, #0xff
     be0:      	tbnz	w17, #0x1, 0xc70 <_llm_rows.packet_batch.blocks+0x430>
     be4:      	tbz	w17, #0x2, 0xc7c <_llm_rows.packet_batch.blocks+0x43c>
     be8:      	add	x0, x16, #0x8
     bec:      	ld1.s	{ v8 }[2], [x0]
     bf0:      	tbnz	w17, #0x3, 0xc80 <_llm_rows.packet_batch.blocks+0x440>
     bf4:      	tbz	w17, #0x4, 0xc8c <_llm_rows.packet_batch.blocks+0x44c>
     bf8:      	add	x0, x16, #0x10
     bfc:      	ld1.s	{ v30 }[0], [x0]
     c00:      	tbnz	w17, #0x5, 0xc90 <_llm_rows.packet_batch.blocks+0x450>
     c04:      	tbz	w17, #0x6, 0xc9c <_llm_rows.packet_batch.blocks+0x45c>
     c08:      	add	x0, x16, #0x18
     c0c:      	ld1.s	{ v30 }[2], [x0]
     c10:      	tbnz	w17, #0x7, 0xca0 <_llm_rows.packet_batch.blocks+0x460>
     c14:      	fmov	w17, s28
     c18:      	add	x16, x13, x10
     c1c:      	movi.2d	v10, #0000000000000000
     c20:      	movi.2d	v9, #0000000000000000
     c24:      	tbz	w17, #0x0, 0xcbc <_llm_rows.packet_batch.blocks+0x47c>
     c28:      	ldr	s10, [x16]
     c2c:      	and	w17, w17, #0xff
     c30:      	tbnz	w17, #0x1, 0xcc4 <_llm_rows.packet_batch.blocks+0x484>
     c34:      	tbz	w17, #0x2, 0xcd0 <_llm_rows.packet_batch.blocks+0x490>
     c38:      	add	x0, x16, #0x8
     c3c:      	ld1.s	{ v10 }[2], [x0]
     c40:      	tbnz	w17, #0x3, 0xcd4 <_llm_rows.packet_batch.blocks+0x494>
     c44:      	tbz	w17, #0x4, 0xce0 <_llm_rows.packet_batch.blocks+0x4a0>
     c48:      	add	x0, x16, #0x10
     c4c:      	ld1.s	{ v9 }[0], [x0]
     c50:      	tbnz	w17, #0x5, 0xce4 <_llm_rows.packet_batch.blocks+0x4a4>
     c54:      	tbz	w17, #0x6, 0xcf0 <_llm_rows.packet_batch.blocks+0x4b0>
     c58:      	add	x0, x16, #0x18
     c5c:      	ld1.s	{ v9 }[2], [x0]
     c60:      	tbnz	w17, #0x7, 0xcf4 <_llm_rows.packet_batch.blocks+0x4b4>
     c64:      	b	0xcfc <_llm_rows.packet_batch.blocks+0x4bc>
     c68:      	and	w17, w15, #0xff
     c6c:      	tbz	w17, #0x1, 0xbe4 <_llm_rows.packet_batch.blocks+0x3a4>
     c70:      	add	x0, x16, #0x4
     c74:      	ld1.s	{ v8 }[1], [x0]
     c78:      	tbnz	w17, #0x2, 0xbe8 <_llm_rows.packet_batch.blocks+0x3a8>
     c7c:      	tbz	w17, #0x3, 0xbf4 <_llm_rows.packet_batch.blocks+0x3b4>
     c80:      	add	x0, x16, #0xc
     c84:      	ld1.s	{ v8 }[3], [x0]
     c88:      	tbnz	w17, #0x4, 0xbf8 <_llm_rows.packet_batch.blocks+0x3b8>
     c8c:      	tbz	w17, #0x5, 0xc04 <_llm_rows.packet_batch.blocks+0x3c4>
     c90:      	add	x0, x16, #0x14
     c94:      	ld1.s	{ v30 }[1], [x0]
     c98:      	tbnz	w17, #0x6, 0xc08 <_llm_rows.packet_batch.blocks+0x3c8>
     c9c:      	tbz	w17, #0x7, 0xc14 <_llm_rows.packet_batch.blocks+0x3d4>
     ca0:      	add	x16, x16, #0x1c
     ca4:      	ld1.s	{ v30 }[3], [x16]
     ca8:      	fmov	w17, s28
     cac:      	add	x16, x13, x10
     cb0:      	movi.2d	v10, #0000000000000000
     cb4:      	movi.2d	v9, #0000000000000000
     cb8:      	tbnz	w17, #0x0, 0xc28 <_llm_rows.packet_batch.blocks+0x3e8>
     cbc:      	and	w17, w17, #0xff
     cc0:      	tbz	w17, #0x1, 0xc34 <_llm_rows.packet_batch.blocks+0x3f4>
     cc4:      	add	x0, x16, #0x4
     cc8:      	ld1.s	{ v10 }[1], [x0]
     ccc:      	tbnz	w17, #0x2, 0xc38 <_llm_rows.packet_batch.blocks+0x3f8>
     cd0:      	tbz	w17, #0x3, 0xc44 <_llm_rows.packet_batch.blocks+0x404>
     cd4:      	add	x0, x16, #0xc
     cd8:      	ld1.s	{ v10 }[3], [x0]
     cdc:      	tbnz	w17, #0x4, 0xc48 <_llm_rows.packet_batch.blocks+0x408>
     ce0:      	tbz	w17, #0x5, 0xc54 <_llm_rows.packet_batch.blocks+0x414>
     ce4:      	add	x0, x16, #0x14
     ce8:      	ld1.s	{ v9 }[1], [x0]
     cec:      	tbnz	w17, #0x6, 0xc58 <_llm_rows.packet_batch.blocks+0x418>
     cf0:      	tbz	w17, #0x7, 0xcfc <_llm_rows.packet_batch.blocks+0x4bc>
     cf4:      	add	x16, x16, #0x1c
     cf8:      	ld1.s	{ v9 }[3], [x16]
     cfc:      	fneg.4s	v11, v8
     d00:      	and.16b	v11, v19, v11
     d04:      	fcmge.4s	v12, v11, v1
     d08:      	fcmge.4s	v13, v0, v11
     d0c:      	and.16b	v12, v12, v13
     d10:      	and.16b	v12, v12, v11
     d14:      	fmul.4s	v13, v12, v18
     d18:      	movi.4s	v14, #0x4b, lsl #24
     d1c:      	mvni.4s	v15, #0x80, lsl #24
     d20:      	bif.16b	v14, v13, v15
     d24:      	fadd.4s	v13, v13, v14
     d28:      	fsub.4s	v13, v13, v14
     d2c:      	fcvtzs.4s	v13, v13
     d30:      	scvtf.4s	v14, v13
     d34:      	fmul.4s	v15, v14, v17
     d38:      	fadd.4s	v12, v12, v15
     d3c:      	fmul.4s	v14, v14, v16
     d40:      	fadd.4s	v12, v12, v14
     d44:      	fmul.4s	v14, v12, v7
     d48:      	fadd.4s	v14, v14, v6
     d4c:      	fmul.4s	v14, v12, v14
     d50:      	fadd.4s	v14, v14, v5
     d54:      	fmul.4s	v14, v12, v14
     d58:      	fadd.4s	v14, v14, v4
     d5c:      	fmul.4s	v14, v12, v14
     d60:      	fadd.4s	v14, v14, v3
     d64:      	fmul.4s	v14, v12, v14
     d68:      	movi.4s	v15, #0x3f, lsl #24
     d6c:      	fadd.4s	v14, v14, v15
     d70:      	fmul.4s	v15, v12, v12
     d74:      	fmul.4s	v14, v15, v14
     d78:      	fadd.4s	v12, v12, v14
     d7c:      	fadd.4s	v12, v12, v2
     d80:      	sshr.4s	v14, v13, #0x1
     d84:      	shl.4s	v15, v14, #0x17
     d88:      	add.4s	v15, v15, v2
     d8c:      	fmul.4s	v12, v12, v15
     d90:      	sub.4s	v13, v13, v14
     d94:      	shl.4s	v13, v13, #0x17
     d98:      	add.4s	v13, v13, v2
     d9c:      	fmul.4s	v12, v12, v13
     da0:      	fcmgt.4s	v13, v1, v11
     da4:      	fcmgt.4s	v14, v11, v0
     da8:      	fcmeq.4s	v11, v11, v11
     dac:      	fadd.4s	v12, v12, v2
     db0:      	bit.16b	v12, v2, v13
     db4:      	ldr	q13, [sp, #0x110]
     db8:      	bit.16b	v12, v13, v14
     dbc:      	ldr	q13, [sp, #0x100]
     dc0:      	bsl.16b	v11, v12, v13
     dc4:      	fdiv.4s	v8, v8, v11
     dc8:      	fmov	w17, s28
     dcc:      	fmul.4s	v8, v10, v8
     dd0:      	add	x16, x12, x10
     dd4:      	tbz	w17, #0x0, 0xdf8 <_llm_rows.packet_batch.blocks+0x5b8>
     dd8:      	str	s8, [x16]
     ddc:      	and	w17, w17, #0xff
     de0:      	tbnz	w17, #0x1, 0xe00 <_llm_rows.packet_batch.blocks+0x5c0>
     de4:      	tbz	w17, #0x2, 0xe0c <_llm_rows.packet_batch.blocks+0x5cc>
     de8:      	add	x0, x16, #0x8
     dec:      	st1.s	{ v8 }[2], [x0]
     df0:      	tbnz	w17, #0x3, 0xe10 <_llm_rows.packet_batch.blocks+0x5d0>
     df4:      	b	0xe18 <_llm_rows.packet_batch.blocks+0x5d8>
     df8:      	and	w17, w17, #0xff
     dfc:      	tbz	w17, #0x1, 0xde4 <_llm_rows.packet_batch.blocks+0x5a4>
     e00:      	add	x0, x16, #0x4
     e04:      	st1.s	{ v8 }[1], [x0]
     e08:      	tbnz	w17, #0x2, 0xde8 <_llm_rows.packet_batch.blocks+0x5a8>
     e0c:      	tbz	w17, #0x3, 0xe18 <_llm_rows.packet_batch.blocks+0x5d8>
     e10:      	add	x0, x16, #0xc
     e14:      	st1.s	{ v8 }[3], [x0]
     e18:      	fneg.4s	v8, v30
     e1c:      	and.16b	v8, v20, v8
     e20:      	fcmge.4s	v10, v8, v1
     e24:      	fcmge.4s	v11, v0, v8
     e28:      	and.16b	v10, v10, v11
     e2c:      	and.16b	v10, v10, v8
     e30:      	fmul.4s	v11, v10, v18
     e34:      	movi.4s	v12, #0x4b, lsl #24
     e38:      	mvni.4s	v13, #0x80, lsl #24
     e3c:      	bif.16b	v12, v11, v13
     e40:      	fadd.4s	v11, v11, v12
     e44:      	fsub.4s	v11, v11, v12
     e48:      	fcvtzs.4s	v11, v11
     e4c:      	scvtf.4s	v12, v11
     e50:      	fmul.4s	v13, v12, v17
     e54:      	fadd.4s	v10, v10, v13
     e58:      	fmul.4s	v12, v12, v16
     e5c:      	fadd.4s	v10, v10, v12
     e60:      	fmul.4s	v12, v10, v7
     e64:      	fadd.4s	v12, v12, v6
     e68:      	fmul.4s	v12, v10, v12
     e6c:      	fadd.4s	v12, v12, v5
     e70:      	fmul.4s	v12, v10, v12
     e74:      	fadd.4s	v12, v12, v4
     e78:      	fmul.4s	v12, v10, v12
     e7c:      	fadd.4s	v12, v12, v3
     e80:      	fmul.4s	v12, v10, v12
     e84:      	movi.4s	v13, #0x3f, lsl #24
     e88:      	fadd.4s	v12, v12, v13
     e8c:      	fmul.4s	v13, v10, v10
     e90:      	fmul.4s	v12, v13, v12
     e94:      	fadd.4s	v10, v10, v12
     e98:      	fadd.4s	v10, v10, v2
     e9c:      	sshr.4s	v12, v11, #0x1
     ea0:      	shl.4s	v13, v12, #0x17
     ea4:      	add.4s	v13, v13, v2
     ea8:      	fmul.4s	v10, v10, v13
     eac:      	sub.4s	v11, v11, v12
     eb0:      	shl.4s	v11, v11, #0x17
     eb4:      	add.4s	v11, v11, v2
     eb8:      	fmul.4s	v10, v10, v11
     ebc:      	fcmgt.4s	v11, v1, v8
     ec0:      	fcmgt.4s	v12, v8, v0
     ec4:      	fcmeq.4s	v8, v8, v8
     ec8:      	fadd.4s	v10, v10, v2
     ecc:      	bit.16b	v10, v2, v11
     ed0:      	ldr	q11, [sp, #0x110]
     ed4:      	bit.16b	v10, v11, v12
     ed8:      	ldr	q11, [sp, #0x100]
     edc:      	bsl.16b	v8, v10, v11
     ee0:      	fdiv.4s	v30, v30, v8
     ee4:      	fmul.4s	v30, v9, v30
     ee8:      	tbz	w17, #0x4, 0xf08 <_llm_rows.packet_batch.blocks+0x6c8>
     eec:      	str	s30, [x16, #0x10]
     ef0:      	tbnz	w17, #0x5, 0xf0c <_llm_rows.packet_batch.blocks+0x6cc>
     ef4:      	tbz	w17, #0x6, 0xf18 <_llm_rows.packet_batch.blocks+0x6d8>
     ef8:      	add	x0, x16, #0x18
     efc:      	st1.s	{ v30 }[2], [x0]
     f00:      	tbz	w17, #0x7, 0xbbc <_llm_rows.packet_batch.blocks+0x37c>
     f04:      	b	0xf1c <_llm_rows.packet_batch.blocks+0x6dc>
     f08:      	tbz	w17, #0x5, 0xef4 <_llm_rows.packet_batch.blocks+0x6b4>
     f0c:      	add	x0, x16, #0x14
     f10:      	st1.s	{ v30 }[1], [x0]
     f14:      	tbnz	w17, #0x6, 0xef8 <_llm_rows.packet_batch.blocks+0x6b8>
     f18:      	tbz	w17, #0x7, 0xbbc <_llm_rows.packet_batch.blocks+0x37c>
     f1c:      	add	x16, x16, #0x1c
     f20:      	st1.s	{ v30 }[3], [x16]
     f24:      	b	0xbbc <_llm_rows.packet_batch.blocks+0x37c>
     f28:      	mov	x10, #0x0               ; =0
     f2c:      	add	x12, x11, x14
     f30:      	b	0xf54 <_llm_rows.packet_batch.blocks+0x714>
     f34:      	add	x13, x26, x10
     f38:      	ldp	q12, q13, [x13]
     f3c:      	bif.16b	v9, v13, v20
     f40:      	bif.16b	v8, v12, v19
     f44:      	stp	q8, q9, [x13]
     f48:      	add	x10, x10, #0x20
     f4c:      	cmp	x10, #0x4, lsl #12      ; =0x4000
     f50:      	b.eq	0xff8 <_llm_rows.packet_batch.blocks+0x7b8>
     f54:      	ldr	q28, [sp, #0xf0]
     f58:      	and.16b	v28, v30, v28
     f5c:      	addv.8h	h28, v28
     f60:      	fmov	w14, s28
     f64:      	add	x13, x12, x10
     f68:      	movi.2d	v8, #0000000000000000
     f6c:      	movi.2d	v9, #0000000000000000
     f70:      	tbz	w14, #0x0, 0xfb4 <_llm_rows.packet_batch.blocks+0x774>
     f74:      	ldr	s8, [x13]
     f78:      	and	w14, w14, #0xff
     f7c:      	tbnz	w14, #0x1, 0xfbc <_llm_rows.packet_batch.blocks+0x77c>
     f80:      	tbz	w14, #0x2, 0xfc8 <_llm_rows.packet_batch.blocks+0x788>
     f84:      	add	x15, x13, #0x8
     f88:      	ld1.s	{ v8 }[2], [x15]
     f8c:      	tbnz	w14, #0x3, 0xfcc <_llm_rows.packet_batch.blocks+0x78c>
     f90:      	tbz	w14, #0x4, 0xfd8 <_llm_rows.packet_batch.blocks+0x798>
     f94:      	add	x15, x13, #0x10
     f98:      	ld1.s	{ v9 }[0], [x15]
     f9c:      	tbnz	w14, #0x5, 0xfdc <_llm_rows.packet_batch.blocks+0x79c>
     fa0:      	tbz	w14, #0x6, 0xfe8 <_llm_rows.packet_batch.blocks+0x7a8>
     fa4:      	add	x15, x13, #0x18
     fa8:      	ld1.s	{ v9 }[2], [x15]
     fac:      	tbz	w14, #0x7, 0xf34 <_llm_rows.packet_batch.blocks+0x6f4>
     fb0:      	b	0xfec <_llm_rows.packet_batch.blocks+0x7ac>
     fb4:      	and	w14, w14, #0xff
     fb8:      	tbz	w14, #0x1, 0xf80 <_llm_rows.packet_batch.blocks+0x740>
     fbc:      	add	x15, x13, #0x4
     fc0:      	ld1.s	{ v8 }[1], [x15]
     fc4:      	tbnz	w14, #0x2, 0xf84 <_llm_rows.packet_batch.blocks+0x744>
     fc8:      	tbz	w14, #0x3, 0xf90 <_llm_rows.packet_batch.blocks+0x750>
     fcc:      	add	x15, x13, #0xc
     fd0:      	ld1.s	{ v8 }[3], [x15]
     fd4:      	tbnz	w14, #0x4, 0xf94 <_llm_rows.packet_batch.blocks+0x754>
     fd8:      	tbz	w14, #0x5, 0xfa0 <_llm_rows.packet_batch.blocks+0x760>
     fdc:      	add	x15, x13, #0x14
     fe0:      	ld1.s	{ v9 }[1], [x15]
     fe4:      	tbnz	w14, #0x6, 0xfa4 <_llm_rows.packet_batch.blocks+0x764>
     fe8:      	tbz	w14, #0x7, 0xf34 <_llm_rows.packet_batch.blocks+0x6f4>
     fec:      	add	x13, x13, #0x1c
     ff0:      	ld1.s	{ v9 }[3], [x13]
     ff4:      	b	0xf34 <_llm_rows.packet_batch.blocks+0x6f4>
     ff8:      	xtn.4h	v30, v19
     ffc:      	uzp1.8b	v8, v30, v0
    1000:      	movi.2d	v30, #0000000000000000
    1004:      	mov.b	v30[0], v8[0]
    1008:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x7c0>
    100c:      	ldr	d12, [x10]
    1010:      	and.8b	v9, v30, v12
    1014:      	addv.8b	b9, v9
    1018:      	fmov	w13, s9
    101c:      	umaxv.8b	b9, v30
    1020:      	fmov	w14, s9
    1024:      	rbit	w10, w13
    1028:      	clz	w10, w10
    102c:      	tst	w14, #0x1
    1030:      	csel	w10, w10, wzr, ne
    1034:      	mov	w12, #0x1000            ; =4096
    1038:      	dup.2d	v13, x12
    103c:      	umlal.2d	v29, v31, v25
    1040:      	movi.2d	v9, #0000000000000000
    1044:      	mov.b	v9[0], v8[0]
    1048:      	add.2d	v8, v29, v13
    104c:      	ushll.2d	v29, v9, #0x0
    1050:      	shl.2d	v29, v29, #0x3f
    1054:      	cmlt.2d	v29, v29, #0
    1058:      	str	q8, [sp, #0x50]
    105c:      	and.16b	v29, v29, v8
    1060:      	movi.2d	v8, #0000000000000000
    1064:      	stp	q8, q8, [sp, #0x260]
    1068:      	stp	q29, q8, [sp, #0x240]
    106c:      	and	x12, x10, #0x7
    1070:      	add	x15, sp, #0x240
    1074:      	ldr	x12, [x15, x12, lsl #3]
    1078:      	sub	x12, x12, x10
    107c:      	lsl	x12, x12, #2
    1080:      	add	x11, x11, x12
    1084:      	movi.2d	v29, #0000000000000000
    1088:      	tbz	w14, #0x0, 0x10c8 <_llm_rows.packet_batch.blocks+0x888>
    108c:      	ldr	s8, [x11]
    1090:      	tbnz	w13, #0x1, 0x10cc <_llm_rows.packet_batch.blocks+0x88c>
    1094:      	tbz	w13, #0x2, 0x10d8 <_llm_rows.packet_batch.blocks+0x898>
    1098:      	add	x14, x11, #0x8
    109c:      	ld1.s	{ v8 }[2], [x14]
    10a0:      	tbnz	w13, #0x3, 0x10dc <_llm_rows.packet_batch.blocks+0x89c>
    10a4:      	tbz	w13, #0x4, 0x10e8 <_llm_rows.packet_batch.blocks+0x8a8>
    10a8:      	add	x14, x11, #0x10
    10ac:      	ld1.s	{ v29 }[0], [x14]
    10b0:      	tbnz	w13, #0x5, 0x10ec <_llm_rows.packet_batch.blocks+0x8ac>
    10b4:      	tbz	w13, #0x6, 0x10f8 <_llm_rows.packet_batch.blocks+0x8b8>
    10b8:      	add	x14, x11, #0x18
    10bc:      	ld1.s	{ v29 }[2], [x14]
    10c0:      	tbnz	w13, #0x7, 0x10fc <_llm_rows.packet_batch.blocks+0x8bc>
    10c4:      	b	0x1104 <_llm_rows.packet_batch.blocks+0x8c4>
    10c8:      	tbz	w13, #0x1, 0x1094 <_llm_rows.packet_batch.blocks+0x854>
    10cc:      	add	x14, x11, #0x4
    10d0:      	ld1.s	{ v8 }[1], [x14]
    10d4:      	tbnz	w13, #0x2, 0x1098 <_llm_rows.packet_batch.blocks+0x858>
    10d8:      	tbz	w13, #0x3, 0x10a4 <_llm_rows.packet_batch.blocks+0x864>
    10dc:      	add	x14, x11, #0xc
    10e0:      	ld1.s	{ v8 }[3], [x14]
    10e4:      	tbnz	w13, #0x4, 0x10a8 <_llm_rows.packet_batch.blocks+0x868>
    10e8:      	tbz	w13, #0x5, 0x10b4 <_llm_rows.packet_batch.blocks+0x874>
    10ec:      	add	x14, x11, #0x14
    10f0:      	ld1.s	{ v29 }[1], [x14]
    10f4:      	tbnz	w13, #0x6, 0x10b8 <_llm_rows.packet_batch.blocks+0x878>
    10f8:      	tbz	w13, #0x7, 0x1104 <_llm_rows.packet_batch.blocks+0x8c4>
    10fc:      	add	x11, x11, #0x1c
    1100:      	ld1.s	{ v29 }[3], [x11]
    1104:      	mov	x15, #0x0               ; =0
    1108:      	umull.2d	v31, v31, v25
    110c:      	umlal.2d	v23, v27, v25
    1110:      	add.2d	v23, v23, v13
    1114:      	umlal.2d	v22, v26, v25
    1118:      	add.2d	v22, v22, v13
    111c:      	stp	q22, q23, [sp, #0x20]
    1120:      	umlal.2d	v21, v24, v25
    1124:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7c0>
    1128:      	ldr	q22, [x11]
    112c:      	mov	w11, #0x4000            ; =16384
    1130:      	dup.2d	v23, x11
    1134:      	sshll.2d	v24, v19, #0x0
    1138:      	bif.16b	v22, v23, v24
    113c:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7c0>
    1140:      	ldr	q24, [x11]
    1144:      	sshll.2d	v25, v20, #0x0
    1148:      	bif.16b	v24, v23, v25
    114c:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7c0>
    1150:      	ldr	q25, [x11]
    1154:      	bif.16b	v25, v23, v11
    1158:      	adrp	x11, 0x1000 <_llm_rows.packet_batch.blocks+0x7c0>
    115c:      	ldr	q26, [x11]
    1160:      	bit.16b	v23, v26, v10
    1164:      	stp	q24, q23, [sp, #0x220]
    1168:      	stp	q22, q25, [sp, #0x200]
    116c:      	and	x11, x10, #0x7
    1170:      	add	x14, sp, #0x200
    1174:      	ldr	x11, [x14, x11, lsl #3]
    1178:      	add.2d	v21, v21, v13
    117c:      	str	q21, [sp, #0x10]
    1180:      	sub	x11, x11, x10, lsl #2
    1184:      	tst	w13, #0xff
    1188:      	csel	x11, xzr, x11, eq
    118c:      	add	x13, x26, x11
    1190:      	ldp	q21, q22, [x13]
    1194:      	zip2.8b	v23, v30, v0
    1198:      	ushll.4s	v23, v23, #0x0
    119c:      	shl.4s	v23, v23, #0x1f
    11a0:      	cmlt.4s	v23, v23, #0
    11a4:      	str	q29, [sp, #0x60]
    11a8:      	bit.16b	v22, v29, v23
    11ac:      	zip1.8b	v23, v30, v0
    11b0:      	ushll.4s	v23, v23, #0x0
    11b4:      	shl.4s	v23, v23, #0x1f
    11b8:      	cmlt.4s	v23, v23, #0
    11bc:      	str	q8, [sp, #0x40]
    11c0:      	bit.16b	v21, v8, v23
    11c4:      	stp	q21, q22, [x13]
    11c8:      	fmov	x13, d31
    11cc:      	lsl	x13, x13, #2
    11d0:      	mov	w14, #0x1               ; =1
    11d4:      	dup.2d	v21, x14
    11d8:      	add	x14, x9, x13
    11dc:      	ushll2.2d	v22, v20, #0x0
    11e0:      	and.16b	v24, v22, v21
    11e4:      	ushll2.2d	v22, v19, #0x0
    11e8:      	and.16b	v25, v22, v21
    11ec:      	ushll.2d	v22, v20, #0x0
    11f0:      	and.16b	v26, v22, v21
    11f4:      	ushll.2d	v22, v19, #0x0
    11f8:      	and.16b	v27, v22, v21
    11fc:      	movi.2d	v31, #0000000000000000
    1200:      	movi.2d	v10, #0000000000000000
    1204:      	movi.2d	v11, #0000000000000000
    1208:      	movi.2d	v13, #0000000000000000
    120c:      	b	0x1240 <_llm_rows.packet_batch.blocks+0xa00>
    1210:      	add	x15, x24, x15
    1214:      	ldp	q21, q22, [x15]
    1218:      	bit.16b	v22, v15, v20
    121c:      	bit.16b	v21, v14, v19
    1220:      	stp	q21, q22, [x15]
    1224:      	add.2d	v10, v10, v25
    1228:      	add.2d	v11, v11, v26
    122c:      	add.2d	v13, v13, v24
    1230:      	add.2d	v31, v31, v27
    1234:      	fmov	x15, d31
    1238:      	cmp	x15, #0x200
    123c:      	b.ge	0x12dc <_llm_rows.packet_batch.blocks+0xa9c>
    1240:      	fmov	w17, s28
    1244:      	lsl	x15, x15, #5
    1248:      	add	x16, x14, x15
    124c:      	movi.2d	v14, #0000000000000000
    1250:      	movi.2d	v15, #0000000000000000
    1254:      	tbz	w17, #0x0, 0x1298 <_llm_rows.packet_batch.blocks+0xa58>
    1258:      	ldr	s14, [x16]
    125c:      	and	w17, w17, #0xff
    1260:      	tbnz	w17, #0x1, 0x12a0 <_llm_rows.packet_batch.blocks+0xa60>
    1264:      	tbz	w17, #0x2, 0x12ac <_llm_rows.packet_batch.blocks+0xa6c>
    1268:      	add	x0, x16, #0x8
    126c:      	ld1.s	{ v14 }[2], [x0]
    1270:      	tbnz	w17, #0x3, 0x12b0 <_llm_rows.packet_batch.blocks+0xa70>
    1274:      	tbz	w17, #0x4, 0x12bc <_llm_rows.packet_batch.blocks+0xa7c>
    1278:      	add	x0, x16, #0x10
    127c:      	ld1.s	{ v15 }[0], [x0]
    1280:      	tbnz	w17, #0x5, 0x12c0 <_llm_rows.packet_batch.blocks+0xa80>
    1284:      	tbz	w17, #0x6, 0x12cc <_llm_rows.packet_batch.blocks+0xa8c>
    1288:      	add	x0, x16, #0x18
    128c:      	ld1.s	{ v15 }[2], [x0]
    1290:      	tbz	w17, #0x7, 0x1210 <_llm_rows.packet_batch.blocks+0x9d0>
    1294:      	b	0x12d0 <_llm_rows.packet_batch.blocks+0xa90>
    1298:      	and	w17, w17, #0xff
    129c:      	tbz	w17, #0x1, 0x1264 <_llm_rows.packet_batch.blocks+0xa24>
    12a0:      	add	x0, x16, #0x4
    12a4:      	ld1.s	{ v14 }[1], [x0]
    12a8:      	tbnz	w17, #0x2, 0x1268 <_llm_rows.packet_batch.blocks+0xa28>
    12ac:      	tbz	w17, #0x3, 0x1274 <_llm_rows.packet_batch.blocks+0xa34>
    12b0:      	add	x0, x16, #0xc
    12b4:      	ld1.s	{ v14 }[3], [x0]
    12b8:      	tbnz	w17, #0x4, 0x1278 <_llm_rows.packet_batch.blocks+0xa38>
    12bc:      	tbz	w17, #0x5, 0x1284 <_llm_rows.packet_batch.blocks+0xa44>
    12c0:      	add	x0, x16, #0x14
    12c4:      	ld1.s	{ v15 }[1], [x0]
    12c8:      	tbnz	w17, #0x6, 0x1288 <_llm_rows.packet_batch.blocks+0xa48>
    12cc:      	tbz	w17, #0x7, 0x1210 <_llm_rows.packet_batch.blocks+0x9d0>
    12d0:      	add	x16, x16, #0x1c
    12d4:      	ld1.s	{ v15 }[3], [x16]
    12d8:      	b	0x1210 <_llm_rows.packet_batch.blocks+0x9d0>
    12dc:      	add	x9, x9, x12
    12e0:      	shl.8b	v21, v30, #0x7
    12e4:      	cmlt.8b	v21, v21, #0
    12e8:      	and.8b	v21, v21, v12
    12ec:      	addv.8b	b21, v21
    12f0:      	str	d21, [sp, #0x8]
    12f4:      	fmov	w12, s21
    12f8:      	movi.2d	v10, #0000000000000000
    12fc:      	movi.2d	v31, #0000000000000000
    1300:      	tbz	w12, #0x0, 0x1340 <_llm_rows.packet_batch.blocks+0xb00>
    1304:      	ldr	s10, [x9]
    1308:      	tbnz	w12, #0x1, 0x1344 <_llm_rows.packet_batch.blocks+0xb04>
    130c:      	tbz	w12, #0x2, 0x1350 <_llm_rows.packet_batch.blocks+0xb10>
    1310:      	add	x14, x9, #0x8
    1314:      	ld1.s	{ v10 }[2], [x14]
    1318:      	tbnz	w12, #0x3, 0x1354 <_llm_rows.packet_batch.blocks+0xb14>
    131c:      	tbz	w12, #0x4, 0x1360 <_llm_rows.packet_batch.blocks+0xb20>
    1320:      	add	x14, x9, #0x10
    1324:      	ld1.s	{ v31 }[0], [x14]
    1328:      	tbnz	w12, #0x5, 0x1364 <_llm_rows.packet_batch.blocks+0xb24>
    132c:      	tbz	w12, #0x6, 0x1370 <_llm_rows.packet_batch.blocks+0xb30>
    1330:      	add	x14, x9, #0x18
    1334:      	ld1.s	{ v31 }[2], [x14]
    1338:      	tbnz	w12, #0x7, 0x1374 <_llm_rows.packet_batch.blocks+0xb34>
    133c:      	b	0x137c <_llm_rows.packet_batch.blocks+0xb3c>
    1340:      	tbz	w12, #0x1, 0x130c <_llm_rows.packet_batch.blocks+0xacc>
    1344:      	add	x14, x9, #0x4
    1348:      	ld1.s	{ v10 }[1], [x14]
    134c:      	tbnz	w12, #0x2, 0x1310 <_llm_rows.packet_batch.blocks+0xad0>
    1350:      	tbz	w12, #0x3, 0x131c <_llm_rows.packet_batch.blocks+0xadc>
    1354:      	add	x14, x9, #0xc
    1358:      	ld1.s	{ v10 }[3], [x14]
    135c:      	tbnz	w12, #0x4, 0x1320 <_llm_rows.packet_batch.blocks+0xae0>
    1360:      	tbz	w12, #0x5, 0x132c <_llm_rows.packet_batch.blocks+0xaec>
    1364:      	add	x14, x9, #0x14
    1368:      	ld1.s	{ v31 }[1], [x14]
    136c:      	tbnz	w12, #0x6, 0x1330 <_llm_rows.packet_batch.blocks+0xaf0>
    1370:      	tbz	w12, #0x7, 0x137c <_llm_rows.packet_batch.blocks+0xb3c>
    1374:      	add	x9, x9, #0x1c
    1378:      	ld1.s	{ v31 }[3], [x9]
    137c:      	mov	x14, #0x0               ; =0
    1380:      	add	x9, x24, x11
    1384:      	ldp	q21, q22, [x9]
    1388:      	zip2.8b	v23, v30, v0
    138c:      	ushll.4s	v23, v23, #0x0
    1390:      	shl.4s	v23, v23, #0x1f
    1394:      	cmlt.4s	v23, v23, #0
    1398:      	bit.16b	v22, v31, v23
    139c:      	zip1.8b	v23, v30, v0
    13a0:      	ushll.4s	v23, v23, #0x0
    13a4:      	shl.4s	v23, v23, #0x1f
    13a8:      	cmlt.4s	v23, v23, #0
    13ac:      	bit.16b	v21, v10, v23
    13b0:      	stp	q21, q22, [x9]
    13b4:      	add	x9, x8, x13
    13b8:      	movi.2d	v12, #0000000000000000
    13bc:      	movi.2d	v13, #0000000000000000
    13c0:      	movi.2d	v14, #0000000000000000
    13c4:      	movi.2d	v15, #0000000000000000
    13c8:      	b	0x13e8 <_llm_rows.packet_batch.blocks+0xba8>
    13cc:      	add.2d	v13, v13, v25
    13d0:      	add.2d	v14, v14, v26
    13d4:      	add.2d	v15, v15, v24
    13d8:      	add.2d	v12, v12, v27
    13dc:      	fmov	x14, d12
    13e0:      	cmp	x14, #0x200
    13e4:      	b.ge	0x1638 <_llm_rows.packet_batch.blocks+0xdf8>
    13e8:      	fmov	w12, s28
    13ec:      	lsl	x11, x14, #5
    13f0:      	add	x13, x26, x11
    13f4:      	ldp	q21, q23, [x13]
    13f8:      	and.16b	v21, v19, v21
    13fc:      	fneg.4s	v22, v21
    1400:      	and.16b	v22, v19, v22
    1404:      	fcmge.4s	v8, v22, v1
    1408:      	fcmge.4s	v11, v0, v22
    140c:      	and.16b	v8, v8, v11
    1410:      	and.16b	v8, v8, v22
    1414:      	fmul.4s	v11, v8, v18
    1418:      	movi.4s	v29, #0x4b, lsl #24
    141c:      	mvni.4s	v9, #0x80, lsl #24
    1420:      	bsl.16b	v9, v29, v11
    1424:      	fadd.4s	v11, v11, v9
    1428:      	fsub.4s	v9, v11, v9
    142c:      	fcvtzs.4s	v9, v9
    1430:      	scvtf.4s	v11, v9
    1434:      	fmul.4s	v29, v11, v17
    1438:      	fadd.4s	v29, v8, v29
    143c:      	fmul.4s	v8, v11, v16
    1440:      	fadd.4s	v29, v29, v8
    1444:      	fmul.4s	v8, v29, v7
    1448:      	fadd.4s	v8, v8, v6
    144c:      	fmul.4s	v8, v29, v8
    1450:      	fadd.4s	v8, v8, v5
    1454:      	fmul.4s	v8, v29, v8
    1458:      	fadd.4s	v8, v8, v4
    145c:      	fmul.4s	v8, v29, v8
    1460:      	fadd.4s	v8, v8, v3
    1464:      	fmul.4s	v8, v29, v8
    1468:      	movi.4s	v11, #0x3f, lsl #24
    146c:      	fadd.4s	v8, v8, v11
    1470:      	fmul.4s	v11, v29, v29
    1474:      	fmul.4s	v8, v11, v8
    1478:      	fadd.4s	v29, v29, v8
    147c:      	fadd.4s	v29, v29, v2
    1480:      	sshr.4s	v8, v9, #0x1
    1484:      	shl.4s	v11, v8, #0x17
    1488:      	add.4s	v11, v11, v2
    148c:      	fmul.4s	v29, v29, v11
    1490:      	sub.4s	v8, v9, v8
    1494:      	shl.4s	v8, v8, #0x17
    1498:      	add.4s	v8, v8, v2
    149c:      	fmul.4s	v29, v29, v8
    14a0:      	fcmgt.4s	v8, v1, v22
    14a4:      	fcmgt.4s	v9, v22, v0
    14a8:      	fcmeq.4s	v22, v22, v22
    14ac:      	fadd.4s	v29, v29, v2
    14b0:      	bit.16b	v29, v2, v8
    14b4:      	ldr	q8, [sp, #0x110]
    14b8:      	bit.16b	v29, v8, v9
    14bc:      	ldr	q8, [sp, #0x100]
    14c0:      	bsl.16b	v22, v29, v8
    14c4:      	fdiv.4s	v21, v21, v22
    14c8:      	add	x13, x24, x11
    14cc:      	ldp	q29, q22, [x13]
    14d0:      	and.16b	v29, v19, v29
    14d4:      	fmul.4s	v21, v29, v21
    14d8:      	add	x11, x9, x11
    14dc:      	tbz	w12, #0x0, 0x1500 <_llm_rows.packet_batch.blocks+0xcc0>
    14e0:      	str	s21, [x11]
    14e4:      	and	w12, w12, #0xff
    14e8:      	tbnz	w12, #0x1, 0x1508 <_llm_rows.packet_batch.blocks+0xcc8>
    14ec:      	tbz	w12, #0x2, 0x1514 <_llm_rows.packet_batch.blocks+0xcd4>
    14f0:      	add	x13, x11, #0x8
    14f4:      	st1.s	{ v21 }[2], [x13]
    14f8:      	tbnz	w12, #0x3, 0x1518 <_llm_rows.packet_batch.blocks+0xcd8>
    14fc:      	b	0x1520 <_llm_rows.packet_batch.blocks+0xce0>
    1500:      	and	w12, w12, #0xff
    1504:      	tbz	w12, #0x1, 0x14ec <_llm_rows.packet_batch.blocks+0xcac>
    1508:      	add	x13, x11, #0x4
    150c:      	st1.s	{ v21 }[1], [x13]
    1510:      	tbnz	w12, #0x2, 0x14f0 <_llm_rows.packet_batch.blocks+0xcb0>
    1514:      	tbz	w12, #0x3, 0x1520 <_llm_rows.packet_batch.blocks+0xce0>
    1518:      	add	x13, x11, #0xc
    151c:      	st1.s	{ v21 }[3], [x13]
    1520:      	and.16b	v21, v20, v23
    1524:      	fneg.4s	v23, v21
    1528:      	and.16b	v23, v20, v23
    152c:      	fcmge.4s	v29, v23, v1
    1530:      	fcmge.4s	v8, v0, v23
    1534:      	and.16b	v29, v29, v8
    1538:      	and.16b	v29, v29, v23
    153c:      	fmul.4s	v8, v29, v18
    1540:      	movi.4s	v9, #0x4b, lsl #24
    1544:      	mvni.4s	v11, #0x80, lsl #24
    1548:      	bif.16b	v9, v8, v11
    154c:      	fadd.4s	v8, v8, v9
    1550:      	fsub.4s	v8, v8, v9
    1554:      	fcvtzs.4s	v8, v8
    1558:      	scvtf.4s	v9, v8
    155c:      	fmul.4s	v11, v9, v17
    1560:      	fadd.4s	v29, v29, v11
    1564:      	fmul.4s	v9, v9, v16
    1568:      	fadd.4s	v29, v29, v9
    156c:      	fmul.4s	v9, v29, v7
    1570:      	fadd.4s	v9, v9, v6
    1574:      	fmul.4s	v9, v29, v9
    1578:      	fadd.4s	v9, v9, v5
    157c:      	fmul.4s	v9, v29, v9
    1580:      	fadd.4s	v9, v9, v4
    1584:      	fmul.4s	v9, v29, v9
    1588:      	fadd.4s	v9, v9, v3
    158c:      	fmul.4s	v9, v29, v9
    1590:      	movi.4s	v11, #0x3f, lsl #24
    1594:      	fadd.4s	v9, v9, v11
    1598:      	fmul.4s	v11, v29, v29
    159c:      	fmul.4s	v9, v11, v9
    15a0:      	fadd.4s	v29, v29, v9
    15a4:      	fadd.4s	v29, v29, v2
    15a8:      	sshr.4s	v9, v8, #0x1
    15ac:      	shl.4s	v11, v9, #0x17
    15b0:      	add.4s	v11, v11, v2
    15b4:      	fmul.4s	v29, v29, v11
    15b8:      	sub.4s	v8, v8, v9
    15bc:      	shl.4s	v8, v8, #0x17
    15c0:      	add.4s	v8, v8, v2
    15c4:      	fmul.4s	v29, v29, v8
    15c8:      	fcmgt.4s	v8, v1, v23
    15cc:      	fcmgt.4s	v9, v23, v0
    15d0:      	fcmeq.4s	v23, v23, v23
    15d4:      	fadd.4s	v29, v29, v2
    15d8:      	bit.16b	v29, v2, v8
    15dc:      	ldr	q8, [sp, #0x110]
    15e0:      	bit.16b	v29, v8, v9
    15e4:      	ldr	q8, [sp, #0x100]
    15e8:      	bsl.16b	v23, v29, v8
    15ec:      	fdiv.4s	v21, v21, v23
    15f0:      	and.16b	v22, v20, v22
    15f4:      	fmul.4s	v21, v22, v21
    15f8:      	tbz	w12, #0x4, 0x1618 <_llm_rows.packet_batch.blocks+0xdd8>
    15fc:      	str	s21, [x11, #0x10]
    1600:      	tbnz	w12, #0x5, 0x161c <_llm_rows.packet_batch.blocks+0xddc>
    1604:      	tbz	w12, #0x6, 0x1628 <_llm_rows.packet_batch.blocks+0xde8>
    1608:      	add	x13, x11, #0x18
    160c:      	st1.s	{ v21 }[2], [x13]
    1610:      	tbz	w12, #0x7, 0x13cc <_llm_rows.packet_batch.blocks+0xb8c>
    1614:      	b	0x162c <_llm_rows.packet_batch.blocks+0xdec>
    1618:      	tbz	w12, #0x5, 0x1604 <_llm_rows.packet_batch.blocks+0xdc4>
    161c:      	add	x13, x11, #0x14
    1620:      	st1.s	{ v21 }[1], [x13]
    1624:      	tbnz	w12, #0x6, 0x1608 <_llm_rows.packet_batch.blocks+0xdc8>
    1628:      	tbz	w12, #0x7, 0x13cc <_llm_rows.packet_batch.blocks+0xb8c>
    162c:      	add	x11, x11, #0x1c
    1630:      	st1.s	{ v21 }[3], [x11]
    1634:      	b	0x13cc <_llm_rows.packet_batch.blocks+0xb8c>
    1638:      	ldr	q24, [sp, #0x40]
    163c:      	fneg.4s	v19, v24
    1640:      	ldr	d20, [sp, #0x8]
    1644:      	fmov	w9, s20
    1648:      	zip1.8b	v20, v30, v0
    164c:      	ushll.4s	v20, v20, #0x0
    1650:      	shl.4s	v20, v20, #0x1f
    1654:      	cmlt.4s	v20, v20, #0
    1658:      	and.16b	v19, v20, v19
    165c:      	fcmge.4s	v20, v19, v1
    1660:      	fcmge.4s	v21, v0, v19
    1664:      	and.16b	v20, v20, v21
    1668:      	and.16b	v20, v20, v19
    166c:      	fmul.4s	v21, v20, v18
    1670:      	movi.4s	v22, #0x4b, lsl #24
    1674:      	mvni.4s	v23, #0x80, lsl #24
    1678:      	bif.16b	v22, v21, v23
    167c:      	fadd.4s	v21, v21, v22
    1680:      	fsub.4s	v21, v21, v22
    1684:      	fcvtzs.4s	v21, v21
    1688:      	scvtf.4s	v22, v21
    168c:      	fmul.4s	v23, v22, v17
    1690:      	fadd.4s	v20, v20, v23
    1694:      	fmul.4s	v22, v22, v16
    1698:      	fadd.4s	v20, v20, v22
    169c:      	fmul.4s	v22, v20, v7
    16a0:      	fadd.4s	v22, v22, v6
    16a4:      	fmul.4s	v22, v20, v22
    16a8:      	fadd.4s	v22, v22, v5
    16ac:      	fmul.4s	v22, v20, v22
    16b0:      	fadd.4s	v22, v22, v4
    16b4:      	fmul.4s	v22, v20, v22
    16b8:      	fadd.4s	v22, v22, v3
    16bc:      	fmul.4s	v22, v20, v22
    16c0:      	movi.4s	v23, #0x3f, lsl #24
    16c4:      	fadd.4s	v22, v22, v23
    16c8:      	fmul.4s	v23, v20, v20
    16cc:      	fmul.4s	v22, v23, v22
    16d0:      	fadd.4s	v20, v20, v22
    16d4:      	fadd.4s	v20, v20, v2
    16d8:      	sshr.4s	v22, v21, #0x1
    16dc:      	shl.4s	v23, v22, #0x17
    16e0:      	add.4s	v23, v23, v2
    16e4:      	fmul.4s	v20, v20, v23
    16e8:      	sub.4s	v21, v21, v22
    16ec:      	shl.4s	v21, v21, #0x17
    16f0:      	add.4s	v21, v21, v2
    16f4:      	fmul.4s	v20, v20, v21
    16f8:      	fcmgt.4s	v21, v1, v19
    16fc:      	fcmgt.4s	v22, v19, v0
    1700:      	fcmeq.4s	v19, v19, v19
    1704:      	fadd.4s	v20, v20, v2
    1708:      	bit.16b	v20, v2, v21
    170c:      	ldp	q21, q23, [sp, #0x100]
    1710:      	bit.16b	v20, v23, v22
    1714:      	bsl.16b	v19, v20, v21
    1718:      	fdiv.4s	v19, v24, v19
    171c:      	fmul.4s	v19, v19, v10
    1720:      	ldr	q21, [sp, #0x50]
    1724:      	ldp	q23, q22, [sp, #0x20]
    1728:      	stp	q21, q22, [sp, #0x1b0]
    172c:      	ldr	q20, [sp, #0x10]
    1730:      	stp	q23, q20, [sp, #0x1d0]
    1734:      	and	x11, x10, #0x7
    1738:      	add	x12, sp, #0x1b0
    173c:      	ldr	x11, [x12, x11, lsl #3]
    1740:      	sub	x10, x11, x10
    1744:      	add	x8, x8, x10, lsl #2
    1748:      	tbz	w9, #0x0, 0x176c <_llm_rows.packet_batch.blocks+0xf2c>
    174c:      	str	s19, [x8]
    1750:      	ldr	q23, [sp, #0x60]
    1754:      	tbnz	w9, #0x1, 0x1774 <_llm_rows.packet_batch.blocks+0xf34>
    1758:      	tbz	w9, #0x2, 0x1780 <_llm_rows.packet_batch.blocks+0xf40>
    175c:      	add	x10, x8, #0x8
    1760:      	st1.s	{ v19 }[2], [x10]
    1764:      	tbnz	w9, #0x3, 0x1784 <_llm_rows.packet_batch.blocks+0xf44>
    1768:      	b	0x178c <_llm_rows.packet_batch.blocks+0xf4c>
    176c:      	ldr	q23, [sp, #0x60]
    1770:      	tbz	w9, #0x1, 0x1758 <_llm_rows.packet_batch.blocks+0xf18>
    1774:      	add	x10, x8, #0x4
    1778:      	st1.s	{ v19 }[1], [x10]
    177c:      	tbnz	w9, #0x2, 0x175c <_llm_rows.packet_batch.blocks+0xf1c>
    1780:      	tbz	w9, #0x3, 0x178c <_llm_rows.packet_batch.blocks+0xf4c>
    1784:      	add	x10, x8, #0xc
    1788:      	st1.s	{ v19 }[3], [x10]
    178c:      	fneg.4s	v19, v23
    1790:      	zip2.8b	v20, v30, v0
    1794:      	ushll.4s	v20, v20, #0x0
    1798:      	shl.4s	v20, v20, #0x1f
    179c:      	cmlt.4s	v20, v20, #0
    17a0:      	and.16b	v19, v20, v19
    17a4:      	fcmge.4s	v20, v19, v1
    17a8:      	fcmge.4s	v21, v0, v19
    17ac:      	and.16b	v20, v20, v21
    17b0:      	and.16b	v20, v20, v19
    17b4:      	fmul.4s	v18, v20, v18
    17b8:      	movi.4s	v21, #0x4b, lsl #24
    17bc:      	mvni.4s	v22, #0x80, lsl #24
    17c0:      	bif.16b	v21, v18, v22
    17c4:      	fadd.4s	v18, v18, v21
    17c8:      	fsub.4s	v18, v18, v21
    17cc:      	fcvtzs.4s	v18, v18
    17d0:      	scvtf.4s	v21, v18
    17d4:      	fmul.4s	v17, v21, v17
    17d8:      	fadd.4s	v17, v20, v17
    17dc:      	fmul.4s	v16, v21, v16
    17e0:      	fadd.4s	v16, v17, v16
    17e4:      	fmul.4s	v7, v16, v7
    17e8:      	fadd.4s	v6, v7, v6
    17ec:      	fmul.4s	v6, v16, v6
    17f0:      	fadd.4s	v5, v6, v5
    17f4:      	fmul.4s	v5, v16, v5
    17f8:      	fadd.4s	v4, v5, v4
    17fc:      	fmul.4s	v4, v16, v4
    1800:      	fadd.4s	v3, v4, v3
    1804:      	fmul.4s	v3, v16, v3
    1808:      	movi.4s	v4, #0x3f, lsl #24
    180c:      	fadd.4s	v3, v3, v4
    1810:      	fmul.4s	v4, v16, v16
    1814:      	fmul.4s	v3, v4, v3
    1818:      	fadd.4s	v3, v16, v3
    181c:      	fadd.4s	v3, v3, v2
    1820:      	sshr.4s	v4, v18, #0x1
    1824:      	shl.4s	v5, v4, #0x17
    1828:      	add.4s	v5, v5, v2
    182c:      	fmul.4s	v3, v3, v5
    1830:      	sub.4s	v4, v18, v4
    1834:      	shl.4s	v4, v4, #0x17
    1838:      	add.4s	v4, v4, v2
    183c:      	fmul.4s	v3, v3, v4
    1840:      	fcmgt.4s	v1, v1, v19
    1844:      	fcmgt.4s	v0, v19, v0
    1848:      	fcmeq.4s	v4, v19, v19
    184c:      	fadd.4s	v3, v3, v2
    1850:      	bsl.16b	v1, v2, v3
    1854:      	ldr	q2, [sp, #0x110]
    1858:      	bsl.16b	v0, v2, v1
    185c:      	ldr	q1, [sp, #0x100]
    1860:      	bif.16b	v0, v1, v4
    1864:      	fdiv.4s	v0, v23, v0
    1868:      	fmul.4s	v0, v0, v31
    186c:      	tbz	w9, #0x4, 0x1c64 <_llm_rows.packet_batch.blocks+0x1424>
    1870:      	str	s0, [x8, #0x10]
    1874:      	tbnz	w9, #0x5, 0x1c68 <_llm_rows.packet_batch.blocks+0x1428>
    1878:      	tbz	w9, #0x6, 0x1c74 <_llm_rows.packet_batch.blocks+0x1434>
    187c:      	add	x10, x8, #0x18
    1880:      	st1.s	{ v0 }[2], [x10]
    1884:      	tbnz	w9, #0x7, 0x1c78 <_llm_rows.packet_batch.blocks+0x1438>
    1888:      	b	0x910 <_llm_rows.packet_batch.blocks+0xd0>
    188c:      	xtn.4h	v19, v19
    1890:      	uzp1.8b	v19, v19, v0
    1894:      	movi.2d	v20, #0000000000000000
    1898:      	mov.b	v20[0], v19[0]
    189c:      	adrp	x10, 0x1000 <_llm_rows.packet_batch.blocks+0x7c0>
    18a0:      	ldr	d8, [x10]
    18a4:      	and.8b	v28, v20, v8
    18a8:      	addv.8b	b28, v28
    18ac:      	fmov	w12, s28
    18b0:      	umaxv.8b	b28, v20
    18b4:      	fmov	w14, s28
    18b8:      	rbit	w10, w12
    18bc:      	clz	w10, w10
    18c0:      	tst	w14, #0x1
    18c4:      	csel	w10, w10, wzr, ne
    18c8:      	mov	w13, #0x1000            ; =4096
    18cc:      	dup.2d	v30, x13
    18d0:      	umlal.2d	v29, v31, v25
    18d4:      	movi.2d	v31, #0000000000000000
    18d8:      	mov.b	v31[0], v19[0]
    18dc:      	add.2d	v28, v29, v30
    18e0:      	ushll.2d	v19, v31, #0x0
    18e4:      	shl.2d	v19, v19, #0x3f
    18e8:      	cmlt.2d	v19, v19, #0
    18ec:      	and.16b	v19, v19, v28
    18f0:      	movi.2d	v29, #0000000000000000
    18f4:      	stp	q29, q29, [sp, #0x180]
    18f8:      	stp	q19, q29, [sp, #0x160]
    18fc:      	and	x13, x10, #0x7
    1900:      	add	x15, sp, #0x160
    1904:      	ldr	x13, [x15, x13, lsl #3]
    1908:      	sub	x13, x13, x10
    190c:      	lsl	x13, x13, #2
    1910:      	add	x11, x11, x13
    1914:      	movi.2d	v19, #0000000000000000
    1918:      	tbz	w14, #0x0, 0x1958 <_llm_rows.packet_batch.blocks+0x1118>
    191c:      	ldr	s29, [x11]
    1920:      	tbnz	w12, #0x1, 0x195c <_llm_rows.packet_batch.blocks+0x111c>
    1924:      	tbz	w12, #0x2, 0x1968 <_llm_rows.packet_batch.blocks+0x1128>
    1928:      	add	x14, x11, #0x8
    192c:      	ld1.s	{ v29 }[2], [x14]
    1930:      	tbnz	w12, #0x3, 0x196c <_llm_rows.packet_batch.blocks+0x112c>
    1934:      	tbz	w12, #0x4, 0x1978 <_llm_rows.packet_batch.blocks+0x1138>
    1938:      	add	x14, x11, #0x10
    193c:      	ld1.s	{ v19 }[0], [x14]
    1940:      	tbnz	w12, #0x5, 0x197c <_llm_rows.packet_batch.blocks+0x113c>
    1944:      	tbz	w12, #0x6, 0x1988 <_llm_rows.packet_batch.blocks+0x1148>
    1948:      	add	x14, x11, #0x18
    194c:      	ld1.s	{ v19 }[2], [x14]
    1950:      	tbnz	w12, #0x7, 0x198c <_llm_rows.packet_batch.blocks+0x114c>
    1954:      	b	0x1994 <_llm_rows.packet_batch.blocks+0x1154>
    1958:      	tbz	w12, #0x1, 0x1924 <_llm_rows.packet_batch.blocks+0x10e4>
    195c:      	add	x14, x11, #0x4
    1960:      	ld1.s	{ v29 }[1], [x14]
    1964:      	tbnz	w12, #0x2, 0x1928 <_llm_rows.packet_batch.blocks+0x10e8>
    1968:      	tbz	w12, #0x3, 0x1934 <_llm_rows.packet_batch.blocks+0x10f4>
    196c:      	add	x14, x11, #0xc
    1970:      	ld1.s	{ v29 }[3], [x14]
    1974:      	tbnz	w12, #0x4, 0x1938 <_llm_rows.packet_batch.blocks+0x10f8>
    1978:      	tbz	w12, #0x5, 0x1944 <_llm_rows.packet_batch.blocks+0x1104>
    197c:      	add	x14, x11, #0x14
    1980:      	ld1.s	{ v19 }[1], [x14]
    1984:      	tbnz	w12, #0x6, 0x1948 <_llm_rows.packet_batch.blocks+0x1108>
    1988:      	tbz	w12, #0x7, 0x1994 <_llm_rows.packet_batch.blocks+0x1154>
    198c:      	add	x11, x11, #0x1c
    1990:      	ld1.s	{ v19 }[3], [x11]
    1994:      	shl.8b	v31, v20, #0x7
    1998:      	cmlt.8b	v31, v31, #0
    199c:      	and.8b	v31, v31, v8
    19a0:      	addv.8b	b8, v31
    19a4:      	fmov	w11, s8
    19a8:      	add	x9, x9, x13
    19ac:      	movi.2d	v9, #0000000000000000
    19b0:      	movi.2d	v31, #0000000000000000
    19b4:      	tbz	w11, #0x0, 0x19f4 <_llm_rows.packet_batch.blocks+0x11b4>
    19b8:      	ldr	s9, [x9]
    19bc:      	tbnz	w11, #0x1, 0x19f8 <_llm_rows.packet_batch.blocks+0x11b8>
    19c0:      	tbz	w11, #0x2, 0x1a04 <_llm_rows.packet_batch.blocks+0x11c4>
    19c4:      	add	x12, x9, #0x8
    19c8:      	ld1.s	{ v9 }[2], [x12]
    19cc:      	tbnz	w11, #0x3, 0x1a08 <_llm_rows.packet_batch.blocks+0x11c8>
    19d0:      	tbz	w11, #0x4, 0x1a14 <_llm_rows.packet_batch.blocks+0x11d4>
    19d4:      	add	x12, x9, #0x10
    19d8:      	ld1.s	{ v31 }[0], [x12]
    19dc:      	tbnz	w11, #0x5, 0x1a18 <_llm_rows.packet_batch.blocks+0x11d8>
    19e0:      	tbz	w11, #0x6, 0x1a24 <_llm_rows.packet_batch.blocks+0x11e4>
    19e4:      	add	x12, x9, #0x18
    19e8:      	ld1.s	{ v31 }[2], [x12]
    19ec:      	tbnz	w11, #0x7, 0x1a28 <_llm_rows.packet_batch.blocks+0x11e8>
    19f0:      	b	0x1a30 <_llm_rows.packet_batch.blocks+0x11f0>
    19f4:      	tbz	w11, #0x1, 0x19c0 <_llm_rows.packet_batch.blocks+0x1180>
    19f8:      	add	x12, x9, #0x4
    19fc:      	ld1.s	{ v9 }[1], [x12]
    1a00:      	tbnz	w11, #0x2, 0x19c4 <_llm_rows.packet_batch.blocks+0x1184>
    1a04:      	tbz	w11, #0x3, 0x19d0 <_llm_rows.packet_batch.blocks+0x1190>
    1a08:      	add	x12, x9, #0xc
    1a0c:      	ld1.s	{ v9 }[3], [x12]
    1a10:      	tbnz	w11, #0x4, 0x19d4 <_llm_rows.packet_batch.blocks+0x1194>
    1a14:      	tbz	w11, #0x5, 0x19e0 <_llm_rows.packet_batch.blocks+0x11a0>
    1a18:      	add	x12, x9, #0x14
    1a1c:      	ld1.s	{ v31 }[1], [x12]
    1a20:      	tbnz	w11, #0x6, 0x19e4 <_llm_rows.packet_batch.blocks+0x11a4>
    1a24:      	tbz	w11, #0x7, 0x1a30 <_llm_rows.packet_batch.blocks+0x11f0>
    1a28:      	add	x9, x9, #0x1c
    1a2c:      	ld1.s	{ v31 }[3], [x9]
    1a30:      	umlal.2d	v23, v27, v25
    1a34:      	add.2d	v23, v23, v30
    1a38:      	umlal.2d	v22, v26, v25
    1a3c:      	add.2d	v22, v22, v30
    1a40:      	umlal.2d	v21, v24, v25
    1a44:      	add.2d	v24, v21, v30
    1a48:      	fneg.4s	v21, v29
    1a4c:      	zip1.8b	v25, v20, v0
    1a50:      	ushll.4s	v25, v25, #0x0
    1a54:      	shl.4s	v25, v25, #0x1f
    1a58:      	cmlt.4s	v25, v25, #0
    1a5c:      	and.16b	v21, v25, v21
    1a60:      	fcmge.4s	v25, v21, v1
    1a64:      	fcmge.4s	v26, v0, v21
    1a68:      	and.16b	v25, v25, v26
    1a6c:      	and.16b	v25, v25, v21
    1a70:      	fmul.4s	v26, v25, v18
    1a74:      	movi.4s	v27, #0x4b, lsl #24
    1a78:      	mvni.4s	v30, #0x80, lsl #24
    1a7c:      	bif.16b	v27, v26, v30
    1a80:      	fadd.4s	v26, v26, v27
    1a84:      	fsub.4s	v26, v26, v27
    1a88:      	fcvtzs.4s	v26, v26
    1a8c:      	scvtf.4s	v27, v26
    1a90:      	fmul.4s	v30, v27, v17
    1a94:      	fadd.4s	v25, v25, v30
    1a98:      	fmul.4s	v27, v27, v16
    1a9c:      	fadd.4s	v25, v25, v27
    1aa0:      	fmul.4s	v27, v25, v7
    1aa4:      	fadd.4s	v27, v27, v6
    1aa8:      	fmul.4s	v27, v25, v27
    1aac:      	fadd.4s	v27, v27, v5
    1ab0:      	fmul.4s	v27, v25, v27
    1ab4:      	fadd.4s	v27, v27, v4
    1ab8:      	fmul.4s	v27, v25, v27
    1abc:      	fadd.4s	v27, v27, v3
    1ac0:      	fmul.4s	v27, v25, v27
    1ac4:      	movi.4s	v30, #0x3f, lsl #24
    1ac8:      	fadd.4s	v27, v27, v30
    1acc:      	fmul.4s	v30, v25, v25
    1ad0:      	fmul.4s	v27, v30, v27
    1ad4:      	fadd.4s	v25, v25, v27
    1ad8:      	fadd.4s	v25, v25, v2
    1adc:      	sshr.4s	v27, v26, #0x1
    1ae0:      	shl.4s	v30, v27, #0x17
    1ae4:      	add.4s	v30, v30, v2
    1ae8:      	fmul.4s	v25, v25, v30
    1aec:      	sub.4s	v26, v26, v27
    1af0:      	shl.4s	v26, v26, #0x17
    1af4:      	add.4s	v26, v26, v2
    1af8:      	fmul.4s	v25, v25, v26
    1afc:      	fcmgt.4s	v26, v1, v21
    1b00:      	fcmgt.4s	v27, v21, v0
    1b04:      	fcmeq.4s	v21, v21, v21
    1b08:      	fadd.4s	v25, v25, v2
    1b0c:      	bit.16b	v25, v2, v26
    1b10:      	ldp	q26, q30, [sp, #0x100]
    1b14:      	bit.16b	v25, v30, v27
    1b18:      	bsl.16b	v21, v25, v26
    1b1c:      	fdiv.4s	v21, v29, v21
    1b20:      	fmul.4s	v21, v9, v21
    1b24:      	stp	q28, q23, [sp, #0x120]
    1b28:      	stp	q22, q24, [sp, #0x140]
    1b2c:      	and	x9, x10, #0x7
    1b30:      	add	x11, sp, #0x120
    1b34:      	ldr	x9, [x11, x9, lsl #3]
    1b38:      	sub	x9, x9, x10
    1b3c:      	add	x8, x8, x9, lsl #2
    1b40:      	fmov	w9, s8
    1b44:      	tbz	w9, #0x0, 0x1b64 <_llm_rows.packet_batch.blocks+0x1324>
    1b48:      	str	s21, [x8]
    1b4c:      	tbnz	w9, #0x1, 0x1b68 <_llm_rows.packet_batch.blocks+0x1328>
    1b50:      	tbz	w9, #0x2, 0x1b74 <_llm_rows.packet_batch.blocks+0x1334>
    1b54:      	add	x10, x8, #0x8
    1b58:      	st1.s	{ v21 }[2], [x10]
    1b5c:      	tbnz	w9, #0x3, 0x1b78 <_llm_rows.packet_batch.blocks+0x1338>
    1b60:      	b	0x1b80 <_llm_rows.packet_batch.blocks+0x1340>
    1b64:      	tbz	w9, #0x1, 0x1b50 <_llm_rows.packet_batch.blocks+0x1310>
    1b68:      	add	x10, x8, #0x4
    1b6c:      	st1.s	{ v21 }[1], [x10]
    1b70:      	tbnz	w9, #0x2, 0x1b54 <_llm_rows.packet_batch.blocks+0x1314>
    1b74:      	tbz	w9, #0x3, 0x1b80 <_llm_rows.packet_batch.blocks+0x1340>
    1b78:      	add	x10, x8, #0xc
    1b7c:      	st1.s	{ v21 }[3], [x10]
    1b80:      	fneg.4s	v21, v19
    1b84:      	zip2.8b	v20, v20, v0
    1b88:      	ushll.4s	v20, v20, #0x0
    1b8c:      	shl.4s	v20, v20, #0x1f
    1b90:      	cmlt.4s	v20, v20, #0
    1b94:      	and.16b	v20, v20, v21
    1b98:      	fcmge.4s	v21, v20, v1
    1b9c:      	fcmge.4s	v22, v0, v20
    1ba0:      	and.16b	v21, v21, v22
    1ba4:      	and.16b	v21, v21, v20
    1ba8:      	fmul.4s	v18, v21, v18
    1bac:      	movi.4s	v22, #0x4b, lsl #24
    1bb0:      	mvni.4s	v23, #0x80, lsl #24
    1bb4:      	bif.16b	v22, v18, v23
    1bb8:      	fadd.4s	v18, v18, v22
    1bbc:      	fsub.4s	v18, v18, v22
    1bc0:      	fcvtzs.4s	v18, v18
    1bc4:      	scvtf.4s	v22, v18
    1bc8:      	fmul.4s	v17, v22, v17
    1bcc:      	fadd.4s	v17, v21, v17
    1bd0:      	fmul.4s	v16, v22, v16
    1bd4:      	fadd.4s	v16, v17, v16
    1bd8:      	fmul.4s	v7, v16, v7
    1bdc:      	fadd.4s	v6, v7, v6
    1be0:      	fmul.4s	v6, v16, v6
    1be4:      	fadd.4s	v5, v6, v5
    1be8:      	fmul.4s	v5, v16, v5
    1bec:      	fadd.4s	v4, v5, v4
    1bf0:      	fmul.4s	v4, v16, v4
    1bf4:      	fadd.4s	v3, v4, v3
    1bf8:      	fmul.4s	v3, v16, v3
    1bfc:      	movi.4s	v4, #0x3f, lsl #24
    1c00:      	fadd.4s	v3, v3, v4
    1c04:      	fmul.4s	v4, v16, v16
    1c08:      	fmul.4s	v3, v4, v3
    1c0c:      	fadd.4s	v3, v16, v3
    1c10:      	fadd.4s	v3, v3, v2
    1c14:      	sshr.4s	v4, v18, #0x1
    1c18:      	shl.4s	v5, v4, #0x17
    1c1c:      	add.4s	v5, v5, v2
    1c20:      	fmul.4s	v3, v3, v5
    1c24:      	sub.4s	v4, v18, v4
    1c28:      	shl.4s	v4, v4, #0x17
    1c2c:      	add.4s	v4, v4, v2
    1c30:      	fmul.4s	v3, v3, v4
    1c34:      	fcmgt.4s	v1, v1, v20
    1c38:      	fcmgt.4s	v0, v20, v0
    1c3c:      	fcmeq.4s	v4, v20, v20
    1c40:      	fadd.4s	v3, v3, v2
    1c44:      	bsl.16b	v1, v2, v3
    1c48:      	ldr	q2, [sp, #0x110]
    1c4c:      	bsl.16b	v0, v2, v1
    1c50:      	ldr	q1, [sp, #0x100]
    1c54:      	bif.16b	v0, v1, v4
    1c58:      	fdiv.4s	v0, v19, v0
    1c5c:      	fmul.4s	v0, v31, v0
    1c60:      	tbnz	w9, #0x4, 0x1870 <_llm_rows.packet_batch.blocks+0x1030>
    1c64:      	tbz	w9, #0x5, 0x1878 <_llm_rows.packet_batch.blocks+0x1038>
    1c68:      	add	x10, x8, #0x14
    1c6c:      	st1.s	{ v0 }[1], [x10]
    1c70:      	tbnz	w9, #0x6, 0x187c <_llm_rows.packet_batch.blocks+0x103c>
    1c74:      	tbz	w9, #0x7, 0x910 <_llm_rows.packet_batch.blocks+0xd0>
    1c78:      	add	x8, x8, #0x1c
    1c7c:      	st1.s	{ v0 }[3], [x8]
    1c80:      	b	0x910 <_llm_rows.packet_batch.blocks+0xd0>
    1c84:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    1c88:      	add	sp, sp, #0x2d0
    1c8c:      	ldp	x29, x30, [sp, #0x90]
    1c90:      	ldp	x20, x19, [sp, #0x80]
    1c94:      	ldp	x22, x21, [sp, #0x70]
    1c98:      	ldp	x24, x23, [sp, #0x60]
    1c9c:      	ldp	x26, x25, [sp, #0x50]
    1ca0:      	ldp	x28, x27, [sp, #0x40]
    1ca4:      	ldp	d9, d8, [sp, #0x30]
    1ca8:      	ldp	d11, d10, [sp, #0x20]
    1cac:      	ldp	d13, d12, [sp, #0x10]
    1cb0:      	ldp	d15, d14, [sp], #0xa0
    1cb4:      	ret

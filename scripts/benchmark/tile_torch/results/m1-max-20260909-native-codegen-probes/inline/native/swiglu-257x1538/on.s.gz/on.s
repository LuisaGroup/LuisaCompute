
/private/tmp/luisa-packet-inline.UY1lIE/capture/swiglu-257x1538/on/object/tile_xir_w8_36416_1788935101551462_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      2c:      	sub	sp, sp, #0x330
      30:      	str	x0, [sp, #0x10]
      34:      	str	w3, [sp, #0x30]
      38:      	cbz	w3, 0x2160 <ltmp0+0x2160>
      3c:      	mov	w13, #0x0               ; =0
      40:      	ldp	w9, w8, [x2, #0x2c]
      44:      	stp	w8, w9, [sp, #0x28]
      48:      	mov	w1, #0x1808             ; =6152
      4c:      	mov	w10, #0x42d00000        ; =1120927744
      50:      	mov	w11, #-0x3d380000       ; =-1027080192
      54:      	ldp	w8, w9, [x2]
      58:      	mov	w12, #0xaa3b            ; =43579
      5c:      	movk	w12, #0x3fb8, lsl #16
      60:      	dup.4s	v13, w10
      64:      	movi.4s	v14, #0x4b, lsl #24
      68:      	dup.4s	v15, w11
      6c:      	mvni.4s	v30, #0x80, lsl #24
      70:      	dup.4s	v11, w12
      74:      	mov	w10, #0x7200            ; =29184
      78:      	movk	w10, #0xbf31, lsl #16
      7c:      	dup.4s	v12, w10
      80:      	mov	w10, #0xbe8e            ; =48782
      84:      	movk	w10, #0xb5bf, lsl #16
      88:      	dup.4s	v31, w10
      8c:      	mov	w10, #0x2bda            ; =11226
      90:      	movk	w10, #0x3950, lsl #16
      94:      	dup.4s	v9, w10
      98:      	mov	w10, #0x96c9            ; =38601
      9c:      	movk	w10, #0x3ab6, lsl #16
      a0:      	dup.4s	v10, w10
      a4:      	mov	w10, #0x88a6            ; =34982
      a8:      	movk	w10, #0x3c08, lsl #16
      ac:      	dup.4s	v27, w10
      b0:      	mov	w10, #0xaa7a            ; =43642
      b4:      	movk	w10, #0x3d2a, lsl #16
      b8:      	dup.4s	v21, w10
      bc:      	mov	w10, #0xaaab            ; =43691
      c0:      	movk	w10, #0x3e2a, lsl #16
      c4:      	dup.4s	v20, w10
      c8:      	add	x26, sp, #0x1, lsl #12  ; =0x1000
      cc:      	add	x26, x26, #0xb10
      d0:      	add	x3, sp, #0x2f0
      d4:      	movi.4s	v19, #0x3f, lsl #24
      d8:      	fmov.4s	v22, #1.00000000
      dc:      	mvni.4s	v0, #0x7f, msl #16
      e0:      	fneg.4s	v24, v0
      e4:      	mvni.4s	v0, #0x3f, msl #16
      e8:      	fneg.4s	v25, v0
      ec:      	ldp	w10, w11, [x2, #0x8]
      f0:      	str	x2, [sp, #0x8]
      f4:      	str	x11, [sp, #0x20]
      f8:      	stp	q15, q13, [sp, #0x50]
      fc:      	stp	q12, q11, [sp, #0xb0]
     100:      	stp	q9, q31, [sp, #0xe0]
     104:      	str	q10, [sp, #0xd0]
     108:      	stp	q27, q22, [sp, #0x120]
     10c:      	stp	q21, q20, [sp, #0x140]
     110:      	stp	q25, q24, [sp, #0x100]
     114:      	b	0x160 <ltmp0+0x160>
     118:      	ldr	x15, [sp, #0x40]
     11c:      	add	w8, w15, #0x1
     120:      	ldp	w11, w9, [sp, #0x28]
     124:      	cmp	w8, w9
     128:      	cset	w9, eq
     12c:      	csinc	w8, wzr, w15, eq
     130:      	ldp	w14, w12, [sp, #0x34]
     134:      	cinc	w10, w14, eq
     138:      	cmp	w10, w11
     13c:      	cset	w11, eq
     140:      	ands	w11, w9, w11
     144:      	csel	w9, wzr, w10, ne
     148:      	add	w10, w12, w11
     14c:      	ldr	w13, [sp, #0x3c]
     150:      	add	w13, w13, #0x1
     154:      	ldr	w11, [sp, #0x30]
     158:      	cmp	w13, w11
     15c:      	b.eq	0x214c <ltmp0+0x214c>
     160:      	str	w13, [sp, #0x3c]
     164:      	mov	x13, x10
     168:      	mov	x14, x9
     16c:      	mov	x15, x8
     170:      	ubfiz	x8, x8, #5, #32
     174:      	ldr	x12, [sp, #0x20]
     178:      	cmp	x8, x12
     17c:      	csel	x9, x8, xzr, ls
     180:      	subs	x10, x12, x9
     184:      	cmp	x10, #0x20
     188:      	mov	w11, #0x20              ; =32
     18c:      	csel	x10, x10, x11, lo
     190:      	cmp	x12, x9
     194:      	ccmp	x8, x12, #0x2, hi
     198:      	csel	x9, x10, xzr, ls
     19c:      	mov	w8, #-0x3d300000        ; =-1026555904
     1a0:      	dup.4s	v1, w8
     1a4:      	mov	w8, #0x42c80000         ; =1120403456
     1a8:      	dup.4s	v0, w8
     1ac:      	stp	q1, q0, [sp, #0x160]
     1b0:      	cmp	x9, #0x20
     1b4:      	stp	w14, w13, [sp, #0x34]
     1b8:      	str	x15, [sp, #0x40]
     1bc:      	b.lo	0x83c <ltmp0+0x83c>
     1c0:      	mov	x21, #0x0               ; =0
     1c4:      	ldr	x8, [sp, #0x10]
     1c8:      	ldr	x13, [x8]
     1cc:      	ldr	x24, [x8, #0x10]
     1d0:      	ldr	x25, [x8, #0x30]
     1d4:      	subs	x8, x13, x25
     1d8:      	mov	w11, #0x2007            ; =8199
     1dc:      	movk	w11, #0x18, lsl #16
     1e0:      	ccmp	x8, x11, #0x0, hs
     1e4:      	cset	w8, hi
     1e8:      	subs	x9, x25, x13
     1ec:      	ccmp	x9, x11, #0x0, hs
     1f0:      	csinc	w8, w8, wzr, ls
     1f4:      	subs	x9, x24, x25
     1f8:      	ccmp	x9, x11, #0x0, hs
     1fc:      	cset	w9, hi
     200:      	subs	x10, x25, x24
     204:      	ccmp	x10, x11, #0x0, hs
     208:      	csinc	w9, w9, wzr, ls
     20c:      	and	w23, w8, w9
     210:      	lsl	w14, w15, #2
     214:      	and	x8, x15, #0x7ffffff
     218:      	mov	w9, #0x6020             ; =24608
     21c:      	umaddl	x19, w8, w9, x25
     220:      	umaddl	x28, w8, w9, x24
     224:      	str	x13, [sp, #0xa0]
     228:      	umaddl	x22, w8, w9, x13
     22c:      	str	x14, [sp, #0x48]
     230:      	b	0x330 <ltmp0+0x330>
     234:      	movi.2d	v1, #0000000000000000
     238:      	ldr	q2, [sp, #0x70]
     23c:      	mov.d	v1[0], v2[0]
     240:      	fneg.4s	v2, v1
     244:      	movi.2d	v3, #0000000000000000
     248:      	mov.d	v3[0], v2[0]
     24c:      	ldp	q16, q7, [sp, #0x160]
     250:      	fcmge.4s	v2, v3, v16
     254:      	fcmge.4s	v4, v7, v3
     258:      	and.16b	v2, v2, v4
     25c:      	and.16b	v2, v2, v3
     260:      	fmul.4s	v4, v2, v11
     264:      	mov.16b	v5, v30
     268:      	bsl.16b	v5, v14, v4
     26c:      	fadd.4s	v4, v4, v5
     270:      	fsub.4s	v4, v4, v5
     274:      	fcvtzs.4s	v4, v4
     278:      	scvtf.4s	v5, v4
     27c:      	fmul.4s	v6, v5, v12
     280:      	fadd.4s	v2, v2, v6
     284:      	fmul.4s	v5, v5, v31
     288:      	fadd.4s	v2, v2, v5
     28c:      	fmul.4s	v5, v2, v9
     290:      	fadd.4s	v5, v5, v10
     294:      	fmul.4s	v5, v2, v5
     298:      	fadd.4s	v5, v5, v27
     29c:      	fmul.4s	v5, v2, v5
     2a0:      	fadd.4s	v5, v5, v21
     2a4:      	fmul.4s	v5, v2, v5
     2a8:      	fadd.4s	v5, v5, v20
     2ac:      	fmul.4s	v5, v2, v5
     2b0:      	fadd.4s	v5, v5, v19
     2b4:      	fmul.4s	v6, v2, v2
     2b8:      	fmul.4s	v5, v6, v5
     2bc:      	fadd.4s	v2, v2, v5
     2c0:      	fadd.4s	v2, v2, v22
     2c4:      	sshr.4s	v5, v4, #0x1
     2c8:      	shl.4s	v6, v5, #0x17
     2cc:      	add.4s	v6, v6, v22
     2d0:      	fmul.4s	v2, v2, v6
     2d4:      	sub.4s	v4, v4, v5
     2d8:      	shl.4s	v4, v4, #0x17
     2dc:      	add.4s	v4, v4, v22
     2e0:      	fmul.4s	v2, v2, v4
     2e4:      	fcmgt.4s	v4, v16, v3
     2e8:      	fcmgt.4s	v5, v3, v7
     2ec:      	fcmeq.4s	v3, v3, v3
     2f0:      	fadd.4s	v2, v2, v22
     2f4:      	bit.16b	v2, v22, v4
     2f8:      	bit.16b	v2, v24, v5
     2fc:      	bif.16b	v2, v25, v3
     300:      	fdiv.4s	v1, v1, v2
     304:      	fmul.4s	v1, v0, v1
     308:      	str	q0, [sp, #0x90]
     30c:      	mov	w1, #0x1808             ; =6152
     310:      	ldr	x14, [sp, #0x48]
     314:      	str	d1, [x25, x27]
     318:      	add	x21, x21, #0x1
     31c:      	add	x19, x19, x1
     320:      	add	x28, x28, x1
     324:      	add	x22, x22, x1
     328:      	cmp	x21, #0x4
     32c:      	b.eq	0x118 <ltmp0+0x118>
     330:      	add	w8, w21, w14
     334:      	and	x8, x8, #0x1fffffff
     338:      	umull	x20, w8, w1
     33c:      	cbz	w23, 0x5dc <ltmp0+0x5dc>
     340:      	mov	x8, #0x0                ; =0
     344:      	lsl	x9, x8, #5
     348:      	add	x10, x22, x9
     34c:      	ldp	q0, q1, [x10]
     350:      	fneg.4s	v2, v1
     354:      	fneg.4s	v3, v0
     358:      	fcmge.4s	v4, v13, v0
     35c:      	fcmge.4s	v5, v13, v1
     360:      	fcmge.4s	v6, v0, v15
     364:      	fcmge.4s	v7, v1, v15
     368:      	and.16b	v5, v5, v7
     36c:      	and.16b	v4, v4, v6
     370:      	and.16b	v3, v4, v3
     374:      	and.16b	v2, v5, v2
     378:      	fmul.4s	v4, v2, v11
     37c:      	fmul.4s	v5, v3, v11
     380:      	mov.16b	v6, v30
     384:      	bsl.16b	v6, v14, v5
     388:      	mov.16b	v7, v30
     38c:      	bsl.16b	v7, v14, v4
     390:      	fadd.4s	v4, v4, v7
     394:      	fadd.4s	v5, v5, v6
     398:      	fsub.4s	v5, v5, v6
     39c:      	fsub.4s	v4, v4, v7
     3a0:      	fcvtzs.4s	v4, v4
     3a4:      	fcvtzs.4s	v5, v5
     3a8:      	scvtf.4s	v6, v5
     3ac:      	scvtf.4s	v7, v4
     3b0:      	fmul.4s	v16, v7, v12
     3b4:      	fmul.4s	v17, v6, v12
     3b8:      	fadd.4s	v3, v3, v17
     3bc:      	fadd.4s	v2, v2, v16
     3c0:      	fmul.4s	v6, v6, v31
     3c4:      	fmul.4s	v7, v7, v31
     3c8:      	fadd.4s	v2, v2, v7
     3cc:      	fadd.4s	v3, v3, v6
     3d0:      	fmul.4s	v6, v3, v9
     3d4:      	fmul.4s	v7, v2, v9
     3d8:      	fadd.4s	v7, v7, v10
     3dc:      	fadd.4s	v6, v6, v10
     3e0:      	fmul.4s	v6, v3, v6
     3e4:      	fmul.4s	v7, v2, v7
     3e8:      	fadd.4s	v7, v7, v27
     3ec:      	fadd.4s	v6, v6, v27
     3f0:      	fmul.4s	v6, v3, v6
     3f4:      	fmul.4s	v7, v2, v7
     3f8:      	fadd.4s	v7, v7, v21
     3fc:      	fadd.4s	v6, v6, v21
     400:      	fmul.4s	v6, v3, v6
     404:      	fmul.4s	v7, v2, v7
     408:      	fadd.4s	v7, v7, v20
     40c:      	fadd.4s	v6, v6, v20
     410:      	fmul.4s	v6, v3, v6
     414:      	fmul.4s	v7, v2, v7
     418:      	fadd.4s	v7, v7, v19
     41c:      	fadd.4s	v6, v6, v19
     420:      	fmul.4s	v16, v2, v2
     424:      	fmul.4s	v17, v3, v3
     428:      	fmul.4s	v6, v17, v6
     42c:      	fmul.4s	v7, v16, v7
     430:      	fadd.4s	v2, v2, v7
     434:      	fadd.4s	v3, v3, v6
     438:      	sshr.4s	v6, v5, #0x1
     43c:      	fadd.4s	v3, v3, v22
     440:      	sshr.4s	v7, v4, #0x1
     444:      	shl.4s	v16, v7, #0x17
     448:      	shl.4s	v17, v6, #0x17
     44c:      	add.4s	v17, v17, v22
     450:      	add.4s	v16, v16, v22
     454:      	fadd.4s	v2, v2, v22
     458:      	fmul.4s	v2, v2, v16
     45c:      	sub.4s	v4, v4, v7
     460:      	sub.4s	v5, v5, v6
     464:      	shl.4s	v5, v5, #0x17
     468:      	shl.4s	v4, v4, #0x17
     46c:      	fmul.4s	v3, v3, v17
     470:      	add.4s	v4, v4, v22
     474:      	add.4s	v5, v5, v22
     478:      	fmul.4s	v3, v3, v5
     47c:      	fmul.4s	v2, v2, v4
     480:      	fcmgt.4s	v4, v1, v13
     484:      	fcmgt.4s	v5, v0, v13
     488:      	fcmgt.4s	v6, v15, v0
     48c:      	fcmgt.4s	v7, v15, v1
     490:      	fcmeq.4s	v16, v1, v1
     494:      	fadd.4s	v2, v2, v22
     498:      	fadd.4s	v3, v3, v22
     49c:      	fcmeq.4s	v17, v0, v0
     4a0:      	bit.16b	v3, v22, v5
     4a4:      	bit.16b	v2, v22, v4
     4a8:      	bit.16b	v2, v24, v7
     4ac:      	bit.16b	v3, v24, v6
     4b0:      	bif.16b	v3, v25, v17
     4b4:      	bif.16b	v2, v25, v16
     4b8:      	fdiv.4s	v1, v1, v2
     4bc:      	fdiv.4s	v0, v0, v3
     4c0:      	add	x10, x28, x9
     4c4:      	ldp	q3, q2, [x10]
     4c8:      	fmul.4s	v0, v3, v0
     4cc:      	fmul.4s	v1, v2, v1
     4d0:      	add	x9, x19, x9
     4d4:      	stp	q0, q1, [x9]
     4d8:      	add	x8, x8, #0x1
     4dc:      	cmp	x8, #0xc0
     4e0:      	b.ne	0x344 <ltmp0+0x344>
     4e4:      	mov	w8, #0x1800             ; =6144
     4e8:      	add	x27, x20, x8
     4ec:      	ldr	x8, [sp, #0xa0]
     4f0:      	add	x8, x8, x27
     4f4:      	movi.2d	v0, #0000000000000000
     4f8:      	ld1.s	{ v0 }[0], [x8], #4
     4fc:      	ld1.s	{ v0 }[1], [x8]
     500:      	fneg.4s	v1, v0
     504:      	movi.2d	v2, #0000000000000000
     508:      	mov.d	v2[0], v1[0]
     50c:      	ldp	q7, q6, [sp, #0x160]
     510:      	fcmge.4s	v1, v2, v7
     514:      	fcmge.4s	v3, v6, v2
     518:      	and.16b	v1, v1, v3
     51c:      	and.16b	v1, v1, v2
     520:      	fmul.4s	v3, v1, v11
     524:      	mov.16b	v4, v30
     528:      	bsl.16b	v4, v14, v3
     52c:      	fadd.4s	v3, v3, v4
     530:      	fsub.4s	v3, v3, v4
     534:      	fcvtzs.4s	v3, v3
     538:      	scvtf.4s	v4, v3
     53c:      	fmul.4s	v5, v4, v12
     540:      	fadd.4s	v1, v1, v5
     544:      	fmul.4s	v4, v4, v31
     548:      	fadd.4s	v1, v1, v4
     54c:      	fmul.4s	v4, v1, v9
     550:      	fadd.4s	v4, v4, v10
     554:      	fmul.4s	v4, v1, v4
     558:      	fadd.4s	v4, v4, v27
     55c:      	fmul.4s	v4, v1, v4
     560:      	fadd.4s	v4, v4, v21
     564:      	fmul.4s	v4, v1, v4
     568:      	fadd.4s	v4, v4, v20
     56c:      	fmul.4s	v4, v1, v4
     570:      	fadd.4s	v4, v4, v19
     574:      	fmul.4s	v5, v1, v1
     578:      	fmul.4s	v4, v5, v4
     57c:      	fadd.4s	v1, v1, v4
     580:      	fadd.4s	v1, v1, v22
     584:      	sshr.4s	v4, v3, #0x1
     588:      	shl.4s	v5, v4, #0x17
     58c:      	add.4s	v5, v5, v22
     590:      	fmul.4s	v1, v1, v5
     594:      	sub.4s	v3, v3, v4
     598:      	shl.4s	v3, v3, #0x17
     59c:      	add.4s	v3, v3, v22
     5a0:      	fmul.4s	v1, v1, v3
     5a4:      	fcmgt.4s	v3, v7, v2
     5a8:      	fcmgt.4s	v4, v2, v6
     5ac:      	fcmeq.4s	v2, v2, v2
     5b0:      	fadd.4s	v1, v1, v22
     5b4:      	bit.16b	v1, v22, v3
     5b8:      	bit.16b	v1, v24, v4
     5bc:      	bif.16b	v1, v25, v2
     5c0:      	fdiv.4s	v0, v0, v1
     5c4:      	add	x8, x24, x27
     5c8:      	add	x9, x8, #0x4
     5cc:      	ldr	s1, [x8]
     5d0:      	ld1.s	{ v1 }[1], [x9]
     5d4:      	fmul.4s	v1, v1, v0
     5d8:      	b	0x314 <ltmp0+0x314>
     5dc:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     5e0:      	add	x0, x0, #0xb10
     5e4:      	mov	x26, x24
     5e8:      	ldr	x24, [sp, #0xa0]
     5ec:      	add	x1, x24, x20
     5f0:      	mov	w2, #0x1800             ; =6144
     5f4:      	bl	0x5f4 <ltmp0+0x5f4>
     5f8:      	mov	w8, #0x1800             ; =6144
     5fc:      	add	x27, x20, x8
     600:      	add	x8, x24, x27
     604:      	mov	x24, x26
     608:      	add	x26, sp, #0x1, lsl #12  ; =0x1000
     60c:      	add	x26, x26, #0xb10
     610:      	add	x9, x8, #0x4
     614:      	ldr	s1, [x8]
     618:      	ld1.s	{ v1 }[1], [x9]
     61c:      	str	q1, [sp, #0x70]
     620:      	ldr	q0, [sp, #0x80]
     624:      	mov.d	v1[1], v0[1]
     628:      	str	q0, [sp, #0x3320]
     62c:      	str	q1, [sp, #0x80]
     630:      	str	q1, [sp, #0x3310]
     634:      	add	x0, sp, #0x2f0
     638:      	add	x1, x24, x20
     63c:      	mov	w2, #0x1800             ; =6144
     640:      	bl	0x640 <ltmp0+0x640>
     644:      	add	x3, sp, #0x2f0
     648:      	ldp	q25, q24, [sp, #0x100]
     64c:      	ldp	q22, q21, [sp, #0x130]
     650:      	movi.4s	v19, #0x3f, lsl #24
     654:      	ldr	q20, [sp, #0x150]
     658:      	ldr	q27, [sp, #0x120]
     65c:      	ldp	q10, q9, [sp, #0xd0]
     660:      	ldr	q31, [sp, #0xf0]
     664:      	ldp	q12, q11, [sp, #0xb0]
     668:      	mvni.4s	v30, #0x80, lsl #24
     66c:      	ldp	q15, q13, [sp, #0x50]
     670:      	movi.4s	v14, #0x4b, lsl #24
     674:      	mov	x8, #0x0                ; =0
     678:      	add	x9, x24, x27
     67c:      	add	x10, x9, #0x4
     680:      	ldr	s0, [x9]
     684:      	ld1.s	{ v0 }[1], [x10]
     688:      	ldr	q1, [sp, #0x90]
     68c:      	mov.d	v0[1], v1[1]
     690:      	str	q0, [sp, #0x1b00]
     694:      	str	q0, [sp, #0x1af0]
     698:      	lsl	x9, x8, #5
     69c:      	add	x10, x26, x9
     6a0:      	ldp	q1, q2, [x10]
     6a4:      	fneg.4s	v3, v2
     6a8:      	fneg.4s	v4, v1
     6ac:      	fcmge.4s	v5, v13, v1
     6b0:      	fcmge.4s	v6, v13, v2
     6b4:      	fcmge.4s	v7, v1, v15
     6b8:      	fcmge.4s	v16, v2, v15
     6bc:      	and.16b	v6, v6, v16
     6c0:      	and.16b	v5, v5, v7
     6c4:      	and.16b	v4, v5, v4
     6c8:      	and.16b	v3, v6, v3
     6cc:      	fmul.4s	v5, v3, v11
     6d0:      	fmul.4s	v6, v4, v11
     6d4:      	mov.16b	v7, v30
     6d8:      	bsl.16b	v7, v14, v6
     6dc:      	mov.16b	v16, v30
     6e0:      	bsl.16b	v16, v14, v5
     6e4:      	fadd.4s	v5, v5, v16
     6e8:      	fadd.4s	v6, v6, v7
     6ec:      	fsub.4s	v6, v6, v7
     6f0:      	fsub.4s	v5, v5, v16
     6f4:      	fcvtzs.4s	v5, v5
     6f8:      	fcvtzs.4s	v6, v6
     6fc:      	scvtf.4s	v7, v6
     700:      	scvtf.4s	v16, v5
     704:      	fmul.4s	v17, v16, v12
     708:      	fmul.4s	v18, v7, v12
     70c:      	fadd.4s	v4, v4, v18
     710:      	fadd.4s	v3, v3, v17
     714:      	fmul.4s	v7, v7, v31
     718:      	fmul.4s	v16, v16, v31
     71c:      	fadd.4s	v3, v3, v16
     720:      	fadd.4s	v4, v4, v7
     724:      	fmul.4s	v7, v4, v9
     728:      	fmul.4s	v16, v3, v9
     72c:      	fadd.4s	v16, v16, v10
     730:      	fadd.4s	v7, v7, v10
     734:      	fmul.4s	v7, v4, v7
     738:      	fmul.4s	v16, v3, v16
     73c:      	fadd.4s	v16, v16, v27
     740:      	fadd.4s	v7, v7, v27
     744:      	fmul.4s	v7, v4, v7
     748:      	fmul.4s	v16, v3, v16
     74c:      	fadd.4s	v16, v16, v21
     750:      	fadd.4s	v7, v7, v21
     754:      	fmul.4s	v7, v4, v7
     758:      	fmul.4s	v16, v3, v16
     75c:      	fadd.4s	v16, v16, v20
     760:      	fadd.4s	v7, v7, v20
     764:      	fmul.4s	v7, v4, v7
     768:      	fmul.4s	v16, v3, v16
     76c:      	fadd.4s	v16, v16, v19
     770:      	fadd.4s	v7, v7, v19
     774:      	fmul.4s	v17, v3, v3
     778:      	fmul.4s	v18, v4, v4
     77c:      	fmul.4s	v7, v18, v7
     780:      	fmul.4s	v16, v17, v16
     784:      	fadd.4s	v3, v3, v16
     788:      	fadd.4s	v4, v4, v7
     78c:      	sshr.4s	v7, v6, #0x1
     790:      	fadd.4s	v4, v4, v22
     794:      	sshr.4s	v16, v5, #0x1
     798:      	shl.4s	v17, v16, #0x17
     79c:      	shl.4s	v18, v7, #0x17
     7a0:      	add.4s	v18, v18, v22
     7a4:      	add.4s	v17, v17, v22
     7a8:      	fadd.4s	v3, v3, v22
     7ac:      	fmul.4s	v3, v3, v17
     7b0:      	sub.4s	v5, v5, v16
     7b4:      	sub.4s	v6, v6, v7
     7b8:      	shl.4s	v6, v6, #0x17
     7bc:      	shl.4s	v5, v5, #0x17
     7c0:      	fmul.4s	v4, v4, v18
     7c4:      	add.4s	v5, v5, v22
     7c8:      	add.4s	v6, v6, v22
     7cc:      	fmul.4s	v4, v4, v6
     7d0:      	fmul.4s	v3, v3, v5
     7d4:      	fcmgt.4s	v5, v2, v13
     7d8:      	fcmgt.4s	v6, v1, v13
     7dc:      	fcmgt.4s	v7, v15, v1
     7e0:      	fcmgt.4s	v16, v15, v2
     7e4:      	fcmeq.4s	v17, v2, v2
     7e8:      	fadd.4s	v3, v3, v22
     7ec:      	fadd.4s	v4, v4, v22
     7f0:      	fcmeq.4s	v18, v1, v1
     7f4:      	bit.16b	v4, v22, v6
     7f8:      	bit.16b	v3, v22, v5
     7fc:      	bit.16b	v3, v24, v16
     800:      	bit.16b	v4, v24, v7
     804:      	bif.16b	v4, v25, v18
     808:      	bif.16b	v3, v25, v17
     80c:      	fdiv.4s	v2, v2, v3
     810:      	fdiv.4s	v1, v1, v4
     814:      	add	x10, x3, x9
     818:      	ldp	q4, q3, [x10]
     81c:      	fmul.4s	v1, v4, v1
     820:      	fmul.4s	v2, v3, v2
     824:      	add	x9, x19, x9
     828:      	stp	q1, q2, [x9]
     82c:      	add	x8, x8, #0x1
     830:      	cmp	x8, #0xc0
     834:      	b.ne	0x698 <ltmp0+0x698>
     838:      	b	0x234 <ltmp0+0x234>
     83c:      	lsr	x12, x9, #3
     840:      	str	x9, [sp, #0x18]
     844:      	cmp	x9, #0x8
     848:      	b.hs	0xd14 <ltmp0+0xd14>
     84c:      	ldr	x8, [sp, #0x18]
     850:      	and	w8, w8, #0x7
     854:      	cbz	w8, 0x118 <ltmp0+0x118>
     858:      	dup.4s	v1, w8
     85c:      	adrp	x8, 0x0 <ltmp0>
     860:      	ldr	q2, [x8]
     864:      	adrp	x8, 0x0 <ltmp0>
     868:      	ldr	q0, [x8]
     86c:      	cmhi.4s	v0, v1, v0
     870:      	cmhi.4s	v1, v1, v2
     874:      	uzp1.8h	v18, v1, v0
     878:      	umaxv.8h	h2, v18
     87c:      	fmov	w8, s2
     880:      	tbz	w8, #0x0, 0x118 <ltmp0+0x118>
     884:      	movi.4s	v8, #0x3f, lsl #24
     888:      	ldr	x8, [sp, #0x10]
     88c:      	ldr	x11, [x8]
     890:      	ldr	x9, [x8, #0x10]
     894:      	ldr	x8, [x8, #0x30]
     898:      	sshll.2d	v5, v1, #0x0
     89c:      	sshll.2d	v3, v0, #0x0
     8a0:      	sshll2.2d	v24, v1, #0x0
     8a4:      	sshll2.2d	v23, v0, #0x0
     8a8:      	adrp	x10, 0x0 <ltmp0>
     8ac:      	ldr	q2, [x10]
     8b0:      	and.16b	v2, v23, v2
     8b4:      	adrp	x10, 0x0 <ltmp0>
     8b8:      	ldr	q4, [x10]
     8bc:      	and.16b	v4, v24, v4
     8c0:      	adrp	x10, 0x0 <ltmp0>
     8c4:      	ldr	q6, [x10]
     8c8:      	and.16b	v3, v3, v6
     8cc:      	adrp	x10, 0x0 <ltmp0>
     8d0:      	ldr	q6, [x10]
     8d4:      	and.16b	v19, v5, v6
     8d8:      	ldr	x10, [sp, #0x40]
     8dc:      	ubfiz	w10, w10, #2, #27
     8e0:      	orr	w10, w10, w12
     8e4:      	dup.4s	v5, w10
     8e8:      	and.16b	v6, v1, v5
     8ec:      	and.16b	v5, v0, v5
     8f0:      	ushll2.2d	v7, v5, #0x0
     8f4:      	ushll2.2d	v16, v6, #0x0
     8f8:      	ushll.2d	v17, v5, #0x0
     8fc:      	ushll.2d	v5, v6, #0x0
     900:      	subs	x10, x11, x8
     904:      	mov	w14, #0x2007            ; =8199
     908:      	movk	w14, #0x18, lsl #16
     90c:      	ccmp	x10, x14, #0x0, hs
     910:      	cset	w10, hi
     914:      	subs	x12, x8, x11
     918:      	ccmp	x12, x14, #0x0, hs
     91c:      	csinc	w12, w10, wzr, ls
     920:      	subs	x10, x9, x8
     924:      	ccmp	x10, x14, #0x0, hs
     928:      	cset	w10, hi
     92c:      	subs	x13, x8, x9
     930:      	ccmp	x13, x14, #0x0, hs
     934:      	csinc	w10, w10, wzr, ls
     938:      	xtn.2s	v20, v5
     93c:      	fmov	x13, d5
     940:      	umull	x14, w13, w1
     944:      	xtn.2s	v7, v7
     948:      	xtn.2s	v27, v17
     94c:      	mov	w13, #0x602             ; =1538
     950:      	dup.2s	v6, w13
     954:      	xtn.2s	v5, v16
     958:      	str	d5, [sp, #0xa0]
     95c:      	cmp	w12, #0x1
     960:      	adrp	x0, 0x0 <ltmp0>
     964:      	b.ne	0x1374 <ltmp0+0x1374>
     968:      	cbz	w10, 0x1374 <ltmp0+0x1374>
     96c:      	str	d27, [sp, #0x80]
     970:      	str	d7, [sp, #0x90]
     974:      	mov	x10, #0x0               ; =0
     978:      	add	x12, x8, x14
     97c:      	add	x13, x9, x14
     980:      	add	x14, x11, x14
     984:      	b	0x994 <ltmp0+0x994>
     988:      	add	x10, x10, #0x1
     98c:      	cmp	x10, #0xc0
     990:      	b.eq	0x1d28 <ltmp0+0x1d28>
     994:      	ldr	q17, [x0]
     998:      	and.16b	v17, v18, v17
     99c:      	addv.8h	h21, v17
     9a0:      	fmov	w16, s21
     9a4:      	add	x15, x14, x10, lsl #5
     9a8:      	movi.2d	v22, #0000000000000000
     9ac:      	movi.2d	v17, #0000000000000000
     9b0:      	tbz	w16, #0x0, 0xa44 <ltmp0+0xa44>
     9b4:      	ldr	s22, [x15]
     9b8:      	and	w16, w16, #0xff
     9bc:      	tbnz	w16, #0x1, 0xa4c <ltmp0+0xa4c>
     9c0:      	tbz	w16, #0x2, 0xa58 <ltmp0+0xa58>
     9c4:      	add	x17, x15, #0x8
     9c8:      	ld1.s	{ v22 }[2], [x17]
     9cc:      	tbnz	w16, #0x3, 0xa5c <ltmp0+0xa5c>
     9d0:      	tbz	w16, #0x4, 0xa68 <ltmp0+0xa68>
     9d4:      	add	x17, x15, #0x10
     9d8:      	ld1.s	{ v17 }[0], [x17]
     9dc:      	tbnz	w16, #0x5, 0xa6c <ltmp0+0xa6c>
     9e0:      	tbz	w16, #0x6, 0xa78 <ltmp0+0xa78>
     9e4:      	add	x17, x15, #0x18
     9e8:      	ld1.s	{ v17 }[2], [x17]
     9ec:      	tbnz	w16, #0x7, 0xa7c <ltmp0+0xa7c>
     9f0:      	fmov	w16, s21
     9f4:      	add	x15, x13, x10, lsl #5
     9f8:      	movi.2d	v24, #0000000000000000
     9fc:      	movi.2d	v23, #0000000000000000
     a00:      	tbz	w16, #0x0, 0xa98 <ltmp0+0xa98>
     a04:      	ldr	s24, [x15]
     a08:      	and	w16, w16, #0xff
     a0c:      	tbnz	w16, #0x1, 0xaa0 <ltmp0+0xaa0>
     a10:      	tbz	w16, #0x2, 0xaac <ltmp0+0xaac>
     a14:      	add	x17, x15, #0x8
     a18:      	ld1.s	{ v24 }[2], [x17]
     a1c:      	tbnz	w16, #0x3, 0xab0 <ltmp0+0xab0>
     a20:      	tbz	w16, #0x4, 0xabc <ltmp0+0xabc>
     a24:      	add	x17, x15, #0x10
     a28:      	ld1.s	{ v23 }[0], [x17]
     a2c:      	tbnz	w16, #0x5, 0xac0 <ltmp0+0xac0>
     a30:      	tbz	w16, #0x6, 0xacc <ltmp0+0xacc>
     a34:      	add	x17, x15, #0x18
     a38:      	ld1.s	{ v23 }[2], [x17]
     a3c:      	tbnz	w16, #0x7, 0xad0 <ltmp0+0xad0>
     a40:      	b	0xad8 <ltmp0+0xad8>
     a44:      	and	w16, w16, #0xff
     a48:      	tbz	w16, #0x1, 0x9c0 <ltmp0+0x9c0>
     a4c:      	add	x17, x15, #0x4
     a50:      	ld1.s	{ v22 }[1], [x17]
     a54:      	tbnz	w16, #0x2, 0x9c4 <ltmp0+0x9c4>
     a58:      	tbz	w16, #0x3, 0x9d0 <ltmp0+0x9d0>
     a5c:      	add	x17, x15, #0xc
     a60:      	ld1.s	{ v22 }[3], [x17]
     a64:      	tbnz	w16, #0x4, 0x9d4 <ltmp0+0x9d4>
     a68:      	tbz	w16, #0x5, 0x9e0 <ltmp0+0x9e0>
     a6c:      	add	x17, x15, #0x14
     a70:      	ld1.s	{ v17 }[1], [x17]
     a74:      	tbnz	w16, #0x6, 0x9e4 <ltmp0+0x9e4>
     a78:      	tbz	w16, #0x7, 0x9f0 <ltmp0+0x9f0>
     a7c:      	add	x15, x15, #0x1c
     a80:      	ld1.s	{ v17 }[3], [x15]
     a84:      	fmov	w16, s21
     a88:      	add	x15, x13, x10, lsl #5
     a8c:      	movi.2d	v24, #0000000000000000
     a90:      	movi.2d	v23, #0000000000000000
     a94:      	tbnz	w16, #0x0, 0xa04 <ltmp0+0xa04>
     a98:      	and	w16, w16, #0xff
     a9c:      	tbz	w16, #0x1, 0xa10 <ltmp0+0xa10>
     aa0:      	add	x17, x15, #0x4
     aa4:      	ld1.s	{ v24 }[1], [x17]
     aa8:      	tbnz	w16, #0x2, 0xa14 <ltmp0+0xa14>
     aac:      	tbz	w16, #0x3, 0xa20 <ltmp0+0xa20>
     ab0:      	add	x17, x15, #0xc
     ab4:      	ld1.s	{ v24 }[3], [x17]
     ab8:      	tbnz	w16, #0x4, 0xa24 <ltmp0+0xa24>
     abc:      	tbz	w16, #0x5, 0xa30 <ltmp0+0xa30>
     ac0:      	add	x17, x15, #0x14
     ac4:      	ld1.s	{ v23 }[1], [x17]
     ac8:      	tbnz	w16, #0x6, 0xa34 <ltmp0+0xa34>
     acc:      	tbz	w16, #0x7, 0xad8 <ltmp0+0xad8>
     ad0:      	add	x15, x15, #0x1c
     ad4:      	ld1.s	{ v23 }[3], [x15]
     ad8:      	fneg.4s	v25, v22
     adc:      	and.16b	v25, v1, v25
     ae0:      	ldp	q16, q7, [sp, #0x160]
     ae4:      	fcmge.4s	v26, v25, v16
     ae8:      	fcmge.4s	v27, v7, v25
     aec:      	and.16b	v26, v26, v27
     af0:      	and.16b	v26, v26, v25
     af4:      	fmul.4s	v27, v26, v11
     af8:      	mov.16b	v28, v30
     afc:      	bsl.16b	v28, v14, v27
     b00:      	fadd.4s	v27, v27, v28
     b04:      	fsub.4s	v27, v27, v28
     b08:      	fcvtzs.4s	v27, v27
     b0c:      	scvtf.4s	v28, v27
     b10:      	fmul.4s	v29, v28, v12
     b14:      	fadd.4s	v26, v26, v29
     b18:      	fmul.4s	v28, v28, v31
     b1c:      	fadd.4s	v26, v26, v28
     b20:      	fmul.4s	v28, v26, v9
     b24:      	fadd.4s	v28, v28, v10
     b28:      	fmul.4s	v28, v26, v28
     b2c:      	ldp	q29, q5, [sp, #0x120]
     b30:      	fadd.4s	v28, v28, v29
     b34:      	fmul.4s	v28, v26, v28
     b38:      	ldr	q29, [sp, #0x140]
     b3c:      	fadd.4s	v28, v28, v29
     b40:      	fmul.4s	v28, v26, v28
     b44:      	ldr	q29, [sp, #0x150]
     b48:      	fadd.4s	v28, v28, v29
     b4c:      	fmul.4s	v28, v26, v28
     b50:      	fadd.4s	v28, v28, v8
     b54:      	fmul.4s	v29, v26, v26
     b58:      	fmul.4s	v28, v29, v28
     b5c:      	fadd.4s	v26, v26, v28
     b60:      	fadd.4s	v26, v26, v5
     b64:      	sshr.4s	v28, v27, #0x1
     b68:      	shl.4s	v29, v28, #0x17
     b6c:      	add.4s	v29, v29, v5
     b70:      	fmul.4s	v26, v26, v29
     b74:      	sub.4s	v27, v27, v28
     b78:      	shl.4s	v27, v27, #0x17
     b7c:      	add.4s	v27, v27, v5
     b80:      	fmul.4s	v26, v26, v27
     b84:      	fcmgt.4s	v27, v16, v25
     b88:      	fcmgt.4s	v28, v25, v7
     b8c:      	fcmeq.4s	v25, v25, v25
     b90:      	fadd.4s	v26, v26, v5
     b94:      	bit.16b	v26, v5, v27
     b98:      	ldp	q5, q7, [sp, #0x100]
     b9c:      	bit.16b	v26, v7, v28
     ba0:      	bsl.16b	v25, v26, v5
     ba4:      	fdiv.4s	v22, v22, v25
     ba8:      	fmov	w16, s21
     bac:      	fmul.4s	v21, v24, v22
     bb0:      	add	x15, x12, x10, lsl #5
     bb4:      	tbz	w16, #0x0, 0xbdc <ltmp0+0xbdc>
     bb8:      	str	s21, [x15]
     bbc:      	and	w16, w16, #0xff
     bc0:      	tbnz	w16, #0x1, 0xbe4 <ltmp0+0xbe4>
     bc4:      	ldr	q27, [sp, #0x120]
     bc8:      	tbz	w16, #0x2, 0xbf4 <ltmp0+0xbf4>
     bcc:      	add	x17, x15, #0x8
     bd0:      	st1.s	{ v21 }[2], [x17]
     bd4:      	tbnz	w16, #0x3, 0xbf8 <ltmp0+0xbf8>
     bd8:      	b	0xc00 <ltmp0+0xc00>
     bdc:      	and	w16, w16, #0xff
     be0:      	tbz	w16, #0x1, 0xbc4 <ltmp0+0xbc4>
     be4:      	add	x17, x15, #0x4
     be8:      	st1.s	{ v21 }[1], [x17]
     bec:      	ldr	q27, [sp, #0x120]
     bf0:      	tbnz	w16, #0x2, 0xbcc <ltmp0+0xbcc>
     bf4:      	tbz	w16, #0x3, 0xc00 <ltmp0+0xc00>
     bf8:      	add	x17, x15, #0xc
     bfc:      	st1.s	{ v21 }[3], [x17]
     c00:      	fneg.4s	v21, v17
     c04:      	and.16b	v21, v0, v21
     c08:      	ldp	q16, q7, [sp, #0x160]
     c0c:      	fcmge.4s	v22, v21, v16
     c10:      	fcmge.4s	v24, v7, v21
     c14:      	and.16b	v22, v22, v24
     c18:      	and.16b	v22, v22, v21
     c1c:      	fmul.4s	v24, v22, v11
     c20:      	mov.16b	v25, v30
     c24:      	bsl.16b	v25, v14, v24
     c28:      	fadd.4s	v24, v24, v25
     c2c:      	fsub.4s	v24, v24, v25
     c30:      	fcvtzs.4s	v24, v24
     c34:      	scvtf.4s	v25, v24
     c38:      	fmul.4s	v26, v25, v12
     c3c:      	fadd.4s	v22, v22, v26
     c40:      	fmul.4s	v25, v25, v31
     c44:      	fadd.4s	v22, v22, v25
     c48:      	fmul.4s	v25, v22, v9
     c4c:      	fadd.4s	v25, v25, v10
     c50:      	fmul.4s	v25, v22, v25
     c54:      	fadd.4s	v25, v25, v27
     c58:      	fmul.4s	v25, v22, v25
     c5c:      	ldp	q5, q26, [sp, #0x140]
     c60:      	fadd.4s	v25, v25, v5
     c64:      	fmul.4s	v25, v22, v25
     c68:      	fadd.4s	v25, v25, v26
     c6c:      	fmul.4s	v25, v22, v25
     c70:      	fadd.4s	v25, v25, v8
     c74:      	fmul.4s	v26, v22, v22
     c78:      	fmul.4s	v25, v26, v25
     c7c:      	fadd.4s	v22, v22, v25
     c80:      	ldr	q5, [sp, #0x130]
     c84:      	fadd.4s	v22, v22, v5
     c88:      	sshr.4s	v25, v24, #0x1
     c8c:      	shl.4s	v26, v25, #0x17
     c90:      	add.4s	v26, v26, v5
     c94:      	fmul.4s	v22, v22, v26
     c98:      	sub.4s	v24, v24, v25
     c9c:      	shl.4s	v24, v24, #0x17
     ca0:      	add.4s	v24, v24, v5
     ca4:      	fmul.4s	v22, v22, v24
     ca8:      	fcmgt.4s	v24, v16, v21
     cac:      	fcmgt.4s	v25, v21, v7
     cb0:      	fcmeq.4s	v21, v21, v21
     cb4:      	fadd.4s	v22, v22, v5
     cb8:      	bit.16b	v22, v5, v24
     cbc:      	ldr	q24, [sp, #0x110]
     cc0:      	bit.16b	v22, v24, v25
     cc4:      	ldr	q25, [sp, #0x100]
     cc8:      	bsl.16b	v21, v22, v25
     ccc:      	fdiv.4s	v17, v17, v21
     cd0:      	fmul.4s	v17, v23, v17
     cd4:      	tbz	w16, #0x4, 0xcf4 <ltmp0+0xcf4>
     cd8:      	str	s17, [x15, #0x10]
     cdc:      	tbnz	w16, #0x5, 0xcf8 <ltmp0+0xcf8>
     ce0:      	tbz	w16, #0x6, 0xd04 <ltmp0+0xd04>
     ce4:      	add	x17, x15, #0x18
     ce8:      	st1.s	{ v17 }[2], [x17]
     cec:      	tbz	w16, #0x7, 0x988 <ltmp0+0x988>
     cf0:      	b	0xd08 <ltmp0+0xd08>
     cf4:      	tbz	w16, #0x5, 0xce0 <ltmp0+0xce0>
     cf8:      	add	x17, x15, #0x14
     cfc:      	st1.s	{ v17 }[1], [x17]
     d00:      	tbnz	w16, #0x6, 0xce4 <ltmp0+0xce4>
     d04:      	tbz	w16, #0x7, 0x988 <ltmp0+0x988>
     d08:      	add	x15, x15, #0x1c
     d0c:      	st1.s	{ v17 }[3], [x15]
     d10:      	b	0x988 <ltmp0+0x988>
     d14:      	mov	x20, #0x0               ; =0
     d18:      	ldr	x8, [sp, #0x10]
     d1c:      	ldr	x13, [x8]
     d20:      	ldr	x24, [x8, #0x10]
     d24:      	ldr	x14, [x8, #0x30]
     d28:      	subs	x8, x13, x14
     d2c:      	mov	w11, #0x2007            ; =8199
     d30:      	movk	w11, #0x18, lsl #16
     d34:      	ccmp	x8, x11, #0x0, hs
     d38:      	cset	w8, hi
     d3c:      	subs	x9, x14, x13
     d40:      	ccmp	x9, x11, #0x0, hs
     d44:      	csinc	w8, w8, wzr, ls
     d48:      	subs	x9, x24, x14
     d4c:      	ccmp	x9, x11, #0x0, hs
     d50:      	cset	w9, hi
     d54:      	subs	x10, x14, x24
     d58:      	ccmp	x10, x11, #0x0, hs
     d5c:      	csinc	w9, w9, wzr, ls
     d60:      	and	w15, w8, w9
     d64:      	ldr	x8, [sp, #0x40]
     d68:      	lsl	w23, w8, #2
     d6c:      	and	x8, x8, #0x7ffffff
     d70:      	mov	w9, #0x6020             ; =24608
     d74:      	umaddl	x21, w8, w9, x14
     d78:      	umaddl	x25, w8, w9, x24
     d7c:      	str	x13, [sp, #0xa0]
     d80:      	umaddl	x19, w8, w9, x13
     d84:      	str	x12, [sp, #0x80]
     d88:      	str	x14, [sp, #0x70]
     d8c:      	str	w15, [sp, #0x48]
     d90:      	b	0xe94 <ltmp0+0xe94>
     d94:      	movi.2d	v1, #0000000000000000
     d98:      	ldr	q2, [sp, #0x90]
     d9c:      	mov.d	v1[0], v2[0]
     da0:      	fneg.4s	v2, v1
     da4:      	movi.2d	v3, #0000000000000000
     da8:      	mov.d	v3[0], v2[0]
     dac:      	ldp	q16, q7, [sp, #0x160]
     db0:      	fcmge.4s	v2, v3, v16
     db4:      	fcmge.4s	v4, v7, v3
     db8:      	and.16b	v2, v2, v4
     dbc:      	and.16b	v2, v2, v3
     dc0:      	fmul.4s	v4, v2, v11
     dc4:      	mov.16b	v5, v30
     dc8:      	bsl.16b	v5, v14, v4
     dcc:      	fadd.4s	v4, v4, v5
     dd0:      	fsub.4s	v4, v4, v5
     dd4:      	fcvtzs.4s	v4, v4
     dd8:      	scvtf.4s	v5, v4
     ddc:      	fmul.4s	v6, v5, v12
     de0:      	fadd.4s	v2, v2, v6
     de4:      	fmul.4s	v5, v5, v31
     de8:      	fadd.4s	v2, v2, v5
     dec:      	fmul.4s	v5, v2, v9
     df0:      	fadd.4s	v5, v5, v10
     df4:      	fmul.4s	v5, v2, v5
     df8:      	fadd.4s	v5, v5, v27
     dfc:      	fmul.4s	v5, v2, v5
     e00:      	fadd.4s	v5, v5, v21
     e04:      	fmul.4s	v5, v2, v5
     e08:      	fadd.4s	v5, v5, v20
     e0c:      	fmul.4s	v5, v2, v5
     e10:      	fadd.4s	v5, v5, v19
     e14:      	fmul.4s	v6, v2, v2
     e18:      	fmul.4s	v5, v6, v5
     e1c:      	fadd.4s	v2, v2, v5
     e20:      	fadd.4s	v2, v2, v22
     e24:      	sshr.4s	v5, v4, #0x1
     e28:      	shl.4s	v6, v5, #0x17
     e2c:      	add.4s	v6, v6, v22
     e30:      	fmul.4s	v2, v2, v6
     e34:      	sub.4s	v4, v4, v5
     e38:      	shl.4s	v4, v4, #0x17
     e3c:      	add.4s	v4, v4, v22
     e40:      	fmul.4s	v2, v2, v4
     e44:      	fcmgt.4s	v4, v16, v3
     e48:      	fcmgt.4s	v5, v3, v7
     e4c:      	fcmeq.4s	v3, v3, v3
     e50:      	fadd.4s	v2, v2, v22
     e54:      	bit.16b	v2, v22, v4
     e58:      	bit.16b	v2, v24, v5
     e5c:      	bif.16b	v2, v25, v3
     e60:      	fdiv.4s	v1, v1, v2
     e64:      	fmul.4s	v0, v0, v1
     e68:      	mov	w1, #0x1808             ; =6152
     e6c:      	ldr	x12, [sp, #0x80]
     e70:      	ldr	x14, [sp, #0x70]
     e74:      	ldr	w15, [sp, #0x48]
     e78:      	str	d0, [x14, x28]
     e7c:      	add	x20, x20, #0x1
     e80:      	add	x21, x21, x1
     e84:      	add	x25, x25, x1
     e88:      	add	x19, x19, x1
     e8c:      	cmp	x20, x12
     e90:      	b.eq	0x84c <ltmp0+0x84c>
     e94:      	add	w8, w20, w23
     e98:      	and	x8, x8, #0x1fffffff
     e9c:      	umull	x22, w8, w1
     ea0:      	cbz	w15, 0x1140 <ltmp0+0x1140>
     ea4:      	mov	x8, #0x0                ; =0
     ea8:      	lsl	x9, x8, #5
     eac:      	add	x10, x19, x9
     eb0:      	ldp	q0, q1, [x10]
     eb4:      	fneg.4s	v2, v1
     eb8:      	fneg.4s	v3, v0
     ebc:      	fcmge.4s	v4, v13, v0
     ec0:      	fcmge.4s	v5, v13, v1
     ec4:      	fcmge.4s	v6, v0, v15
     ec8:      	fcmge.4s	v7, v1, v15
     ecc:      	and.16b	v5, v5, v7
     ed0:      	and.16b	v4, v4, v6
     ed4:      	and.16b	v3, v4, v3
     ed8:      	and.16b	v2, v5, v2
     edc:      	fmul.4s	v4, v2, v11
     ee0:      	fmul.4s	v5, v3, v11
     ee4:      	mov.16b	v6, v30
     ee8:      	bsl.16b	v6, v14, v5
     eec:      	mov.16b	v7, v30
     ef0:      	bsl.16b	v7, v14, v4
     ef4:      	fadd.4s	v4, v4, v7
     ef8:      	fadd.4s	v5, v5, v6
     efc:      	fsub.4s	v5, v5, v6
     f00:      	fsub.4s	v4, v4, v7
     f04:      	fcvtzs.4s	v4, v4
     f08:      	fcvtzs.4s	v5, v5
     f0c:      	scvtf.4s	v6, v5
     f10:      	scvtf.4s	v7, v4
     f14:      	fmul.4s	v16, v7, v12
     f18:      	fmul.4s	v17, v6, v12
     f1c:      	fadd.4s	v3, v3, v17
     f20:      	fadd.4s	v2, v2, v16
     f24:      	fmul.4s	v6, v6, v31
     f28:      	fmul.4s	v7, v7, v31
     f2c:      	fadd.4s	v2, v2, v7
     f30:      	fadd.4s	v3, v3, v6
     f34:      	fmul.4s	v6, v3, v9
     f38:      	fmul.4s	v7, v2, v9
     f3c:      	fadd.4s	v7, v7, v10
     f40:      	fadd.4s	v6, v6, v10
     f44:      	fmul.4s	v6, v3, v6
     f48:      	fmul.4s	v7, v2, v7
     f4c:      	fadd.4s	v7, v7, v27
     f50:      	fadd.4s	v6, v6, v27
     f54:      	fmul.4s	v6, v3, v6
     f58:      	fmul.4s	v7, v2, v7
     f5c:      	fadd.4s	v7, v7, v21
     f60:      	fadd.4s	v6, v6, v21
     f64:      	fmul.4s	v6, v3, v6
     f68:      	fmul.4s	v7, v2, v7
     f6c:      	fadd.4s	v7, v7, v20
     f70:      	fadd.4s	v6, v6, v20
     f74:      	fmul.4s	v6, v3, v6
     f78:      	fmul.4s	v7, v2, v7
     f7c:      	fadd.4s	v7, v7, v19
     f80:      	fadd.4s	v6, v6, v19
     f84:      	fmul.4s	v16, v2, v2
     f88:      	fmul.4s	v17, v3, v3
     f8c:      	fmul.4s	v6, v17, v6
     f90:      	fmul.4s	v7, v16, v7
     f94:      	fadd.4s	v2, v2, v7
     f98:      	fadd.4s	v3, v3, v6
     f9c:      	sshr.4s	v6, v5, #0x1
     fa0:      	fadd.4s	v3, v3, v22
     fa4:      	sshr.4s	v7, v4, #0x1
     fa8:      	shl.4s	v16, v7, #0x17
     fac:      	shl.4s	v17, v6, #0x17
     fb0:      	add.4s	v17, v17, v22
     fb4:      	add.4s	v16, v16, v22
     fb8:      	fadd.4s	v2, v2, v22
     fbc:      	fmul.4s	v2, v2, v16
     fc0:      	sub.4s	v4, v4, v7
     fc4:      	sub.4s	v5, v5, v6
     fc8:      	shl.4s	v5, v5, #0x17
     fcc:      	shl.4s	v4, v4, #0x17
     fd0:      	fmul.4s	v3, v3, v17
     fd4:      	add.4s	v4, v4, v22
     fd8:      	add.4s	v5, v5, v22
     fdc:      	fmul.4s	v3, v3, v5
     fe0:      	fmul.4s	v2, v2, v4
     fe4:      	fcmgt.4s	v4, v1, v13
     fe8:      	fcmgt.4s	v5, v0, v13
     fec:      	fcmgt.4s	v6, v15, v0
     ff0:      	fcmgt.4s	v7, v15, v1
     ff4:      	fcmeq.4s	v16, v1, v1
     ff8:      	fadd.4s	v2, v2, v22
     ffc:      	fadd.4s	v3, v3, v22
    1000:      	fcmeq.4s	v17, v0, v0
    1004:      	bit.16b	v3, v22, v5
    1008:      	bit.16b	v2, v22, v4
    100c:      	bit.16b	v2, v24, v7
    1010:      	bit.16b	v3, v24, v6
    1014:      	bif.16b	v3, v25, v17
    1018:      	bif.16b	v2, v25, v16
    101c:      	fdiv.4s	v1, v1, v2
    1020:      	fdiv.4s	v0, v0, v3
    1024:      	add	x10, x25, x9
    1028:      	ldp	q3, q2, [x10]
    102c:      	fmul.4s	v0, v3, v0
    1030:      	fmul.4s	v1, v2, v1
    1034:      	add	x9, x21, x9
    1038:      	stp	q0, q1, [x9]
    103c:      	add	x8, x8, #0x1
    1040:      	cmp	x8, #0xc0
    1044:      	b.ne	0xea8 <ltmp0+0xea8>
    1048:      	mov	w8, #0x1800             ; =6144
    104c:      	add	x28, x22, x8
    1050:      	ldr	x8, [sp, #0xa0]
    1054:      	add	x8, x8, x28
    1058:      	movi.2d	v0, #0000000000000000
    105c:      	ld1.s	{ v0 }[0], [x8], #4
    1060:      	ld1.s	{ v0 }[1], [x8]
    1064:      	fneg.4s	v1, v0
    1068:      	movi.2d	v2, #0000000000000000
    106c:      	mov.d	v2[0], v1[0]
    1070:      	ldp	q7, q6, [sp, #0x160]
    1074:      	fcmge.4s	v1, v2, v7
    1078:      	fcmge.4s	v3, v6, v2
    107c:      	and.16b	v1, v1, v3
    1080:      	and.16b	v1, v1, v2
    1084:      	fmul.4s	v3, v1, v11
    1088:      	mov.16b	v4, v30
    108c:      	bsl.16b	v4, v14, v3
    1090:      	fadd.4s	v3, v3, v4
    1094:      	fsub.4s	v3, v3, v4
    1098:      	fcvtzs.4s	v3, v3
    109c:      	scvtf.4s	v4, v3
    10a0:      	fmul.4s	v5, v4, v12
    10a4:      	fadd.4s	v1, v1, v5
    10a8:      	fmul.4s	v4, v4, v31
    10ac:      	fadd.4s	v1, v1, v4
    10b0:      	fmul.4s	v4, v1, v9
    10b4:      	fadd.4s	v4, v4, v10
    10b8:      	fmul.4s	v4, v1, v4
    10bc:      	fadd.4s	v4, v4, v27
    10c0:      	fmul.4s	v4, v1, v4
    10c4:      	fadd.4s	v4, v4, v21
    10c8:      	fmul.4s	v4, v1, v4
    10cc:      	fadd.4s	v4, v4, v20
    10d0:      	fmul.4s	v4, v1, v4
    10d4:      	fadd.4s	v4, v4, v19
    10d8:      	fmul.4s	v5, v1, v1
    10dc:      	fmul.4s	v4, v5, v4
    10e0:      	fadd.4s	v1, v1, v4
    10e4:      	fadd.4s	v1, v1, v22
    10e8:      	sshr.4s	v4, v3, #0x1
    10ec:      	shl.4s	v5, v4, #0x17
    10f0:      	add.4s	v5, v5, v22
    10f4:      	fmul.4s	v1, v1, v5
    10f8:      	sub.4s	v3, v3, v4
    10fc:      	shl.4s	v3, v3, #0x17
    1100:      	add.4s	v3, v3, v22
    1104:      	fmul.4s	v1, v1, v3
    1108:      	fcmgt.4s	v3, v7, v2
    110c:      	fcmgt.4s	v4, v2, v6
    1110:      	fcmeq.4s	v2, v2, v2
    1114:      	fadd.4s	v1, v1, v22
    1118:      	bit.16b	v1, v22, v3
    111c:      	bit.16b	v1, v24, v4
    1120:      	bif.16b	v1, v25, v2
    1124:      	fdiv.4s	v0, v0, v1
    1128:      	add	x8, x24, x28
    112c:      	add	x9, x8, #0x4
    1130:      	ldr	s1, [x8]
    1134:      	ld1.s	{ v1 }[1], [x9]
    1138:      	fmul.4s	v0, v1, v0
    113c:      	b	0xe78 <ltmp0+0xe78>
    1140:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
    1144:      	add	x0, x0, #0xb10
    1148:      	ldr	x27, [sp, #0xa0]
    114c:      	add	x1, x27, x22
    1150:      	mov	w2, #0x1800             ; =6144
    1154:      	bl	0x1154 <ltmp0+0x1154>
    1158:      	mov	w8, #0x1800             ; =6144
    115c:      	add	x28, x22, x8
    1160:      	add	x8, x27, x28
    1164:      	add	x9, x8, #0x4
    1168:      	ldr	s0, [x8]
    116c:      	ld1.s	{ v0 }[1], [x9]
    1170:      	str	q0, [sp, #0x90]
    1174:      	str	q0, [sp, #0x3310]
    1178:      	add	x0, sp, #0x2f0
    117c:      	add	x1, x24, x22
    1180:      	mov	w2, #0x1800             ; =6144
    1184:      	bl	0x1184 <ltmp0+0x1184>
    1188:      	add	x3, sp, #0x2f0
    118c:      	ldp	q25, q24, [sp, #0x100]
    1190:      	ldp	q22, q21, [sp, #0x130]
    1194:      	movi.4s	v19, #0x3f, lsl #24
    1198:      	ldr	q20, [sp, #0x150]
    119c:      	ldr	q27, [sp, #0x120]
    11a0:      	ldp	q10, q9, [sp, #0xd0]
    11a4:      	ldr	q31, [sp, #0xf0]
    11a8:      	ldp	q12, q11, [sp, #0xb0]
    11ac:      	mvni.4s	v30, #0x80, lsl #24
    11b0:      	ldp	q15, q13, [sp, #0x50]
    11b4:      	movi.4s	v14, #0x4b, lsl #24
    11b8:      	mov	x8, #0x0                ; =0
    11bc:      	add	x9, x24, x28
    11c0:      	add	x10, x9, #0x4
    11c4:      	ldr	s0, [x9]
    11c8:      	ld1.s	{ v0 }[1], [x10]
    11cc:      	str	q0, [sp, #0x1af0]
    11d0:      	lsl	x9, x8, #5
    11d4:      	add	x10, x26, x9
    11d8:      	ldp	q1, q2, [x10]
    11dc:      	fneg.4s	v3, v2
    11e0:      	fneg.4s	v4, v1
    11e4:      	fcmge.4s	v5, v13, v1
    11e8:      	fcmge.4s	v6, v13, v2
    11ec:      	fcmge.4s	v7, v1, v15
    11f0:      	fcmge.4s	v16, v2, v15
    11f4:      	and.16b	v6, v6, v16
    11f8:      	and.16b	v5, v5, v7
    11fc:      	and.16b	v4, v5, v4
    1200:      	and.16b	v3, v6, v3
    1204:      	fmul.4s	v5, v3, v11
    1208:      	fmul.4s	v6, v4, v11
    120c:      	mov.16b	v7, v30
    1210:      	bsl.16b	v7, v14, v6
    1214:      	mov.16b	v16, v30
    1218:      	bsl.16b	v16, v14, v5
    121c:      	fadd.4s	v5, v5, v16
    1220:      	fadd.4s	v6, v6, v7
    1224:      	fsub.4s	v6, v6, v7
    1228:      	fsub.4s	v5, v5, v16
    122c:      	fcvtzs.4s	v5, v5
    1230:      	fcvtzs.4s	v6, v6
    1234:      	scvtf.4s	v7, v6
    1238:      	scvtf.4s	v16, v5
    123c:      	fmul.4s	v17, v16, v12
    1240:      	fmul.4s	v18, v7, v12
    1244:      	fadd.4s	v4, v4, v18
    1248:      	fadd.4s	v3, v3, v17
    124c:      	fmul.4s	v7, v7, v31
    1250:      	fmul.4s	v16, v16, v31
    1254:      	fadd.4s	v3, v3, v16
    1258:      	fadd.4s	v4, v4, v7
    125c:      	fmul.4s	v7, v4, v9
    1260:      	fmul.4s	v16, v3, v9
    1264:      	fadd.4s	v16, v16, v10
    1268:      	fadd.4s	v7, v7, v10
    126c:      	fmul.4s	v7, v4, v7
    1270:      	fmul.4s	v16, v3, v16
    1274:      	fadd.4s	v16, v16, v27
    1278:      	fadd.4s	v7, v7, v27
    127c:      	fmul.4s	v7, v4, v7
    1280:      	fmul.4s	v16, v3, v16
    1284:      	fadd.4s	v16, v16, v21
    1288:      	fadd.4s	v7, v7, v21
    128c:      	fmul.4s	v7, v4, v7
    1290:      	fmul.4s	v16, v3, v16
    1294:      	fadd.4s	v16, v16, v20
    1298:      	fadd.4s	v7, v7, v20
    129c:      	fmul.4s	v7, v4, v7
    12a0:      	fmul.4s	v16, v3, v16
    12a4:      	fadd.4s	v16, v16, v19
    12a8:      	fadd.4s	v7, v7, v19
    12ac:      	fmul.4s	v17, v3, v3
    12b0:      	fmul.4s	v18, v4, v4
    12b4:      	fmul.4s	v7, v18, v7
    12b8:      	fmul.4s	v16, v17, v16
    12bc:      	fadd.4s	v3, v3, v16
    12c0:      	fadd.4s	v4, v4, v7
    12c4:      	sshr.4s	v7, v6, #0x1
    12c8:      	fadd.4s	v4, v4, v22
    12cc:      	sshr.4s	v16, v5, #0x1
    12d0:      	shl.4s	v17, v16, #0x17
    12d4:      	shl.4s	v18, v7, #0x17
    12d8:      	add.4s	v18, v18, v22
    12dc:      	add.4s	v17, v17, v22
    12e0:      	fadd.4s	v3, v3, v22
    12e4:      	fmul.4s	v3, v3, v17
    12e8:      	sub.4s	v5, v5, v16
    12ec:      	sub.4s	v6, v6, v7
    12f0:      	shl.4s	v6, v6, #0x17
    12f4:      	shl.4s	v5, v5, #0x17
    12f8:      	fmul.4s	v4, v4, v18
    12fc:      	add.4s	v5, v5, v22
    1300:      	add.4s	v6, v6, v22
    1304:      	fmul.4s	v4, v4, v6
    1308:      	fmul.4s	v3, v3, v5
    130c:      	fcmgt.4s	v5, v2, v13
    1310:      	fcmgt.4s	v6, v1, v13
    1314:      	fcmgt.4s	v7, v15, v1
    1318:      	fcmgt.4s	v16, v15, v2
    131c:      	fcmeq.4s	v17, v2, v2
    1320:      	fadd.4s	v3, v3, v22
    1324:      	fadd.4s	v4, v4, v22
    1328:      	fcmeq.4s	v18, v1, v1
    132c:      	bit.16b	v4, v22, v6
    1330:      	bit.16b	v3, v22, v5
    1334:      	bit.16b	v3, v24, v16
    1338:      	bit.16b	v4, v24, v7
    133c:      	bif.16b	v4, v25, v18
    1340:      	bif.16b	v3, v25, v17
    1344:      	fdiv.4s	v2, v2, v3
    1348:      	fdiv.4s	v1, v1, v4
    134c:      	add	x10, x3, x9
    1350:      	ldp	q4, q3, [x10]
    1354:      	fmul.4s	v1, v4, v1
    1358:      	fmul.4s	v2, v3, v2
    135c:      	add	x9, x21, x9
    1360:      	stp	q1, q2, [x9]
    1364:      	add	x8, x8, #0x1
    1368:      	cmp	x8, #0xc0
    136c:      	b.ne	0x11d0 <ltmp0+0x11d0>
    1370:      	b	0xd94 <ltmp0+0xd94>
    1374:      	mov	x10, #0x0               ; =0
    1378:      	add	x12, x11, x14
    137c:      	b	0x13a0 <ltmp0+0x13a0>
    1380:      	add	x13, x26, x10, lsl #5
    1384:      	ldp	q25, q26, [x13]
    1388:      	bif.16b	v22, v26, v0
    138c:      	bif.16b	v21, v25, v1
    1390:      	stp	q21, q22, [x13]
    1394:      	add	x10, x10, #0x1
    1398:      	cmp	x10, #0xc0
    139c:      	b.eq	0x1444 <ltmp0+0x1444>
    13a0:      	ldr	q17, [x0]
    13a4:      	and.16b	v17, v18, v17
    13a8:      	addv.8h	h17, v17
    13ac:      	fmov	w14, s17
    13b0:      	add	x13, x12, x10, lsl #5
    13b4:      	movi.2d	v21, #0000000000000000
    13b8:      	movi.2d	v22, #0000000000000000
    13bc:      	tbz	w14, #0x0, 0x1400 <ltmp0+0x1400>
    13c0:      	ldr	s21, [x13]
    13c4:      	and	w14, w14, #0xff
    13c8:      	tbnz	w14, #0x1, 0x1408 <ltmp0+0x1408>
    13cc:      	tbz	w14, #0x2, 0x1414 <ltmp0+0x1414>
    13d0:      	add	x15, x13, #0x8
    13d4:      	ld1.s	{ v21 }[2], [x15]
    13d8:      	tbnz	w14, #0x3, 0x1418 <ltmp0+0x1418>
    13dc:      	tbz	w14, #0x4, 0x1424 <ltmp0+0x1424>
    13e0:      	add	x15, x13, #0x10
    13e4:      	ld1.s	{ v22 }[0], [x15]
    13e8:      	tbnz	w14, #0x5, 0x1428 <ltmp0+0x1428>
    13ec:      	tbz	w14, #0x6, 0x1434 <ltmp0+0x1434>
    13f0:      	add	x15, x13, #0x18
    13f4:      	ld1.s	{ v22 }[2], [x15]
    13f8:      	tbz	w14, #0x7, 0x1380 <ltmp0+0x1380>
    13fc:      	b	0x1438 <ltmp0+0x1438>
    1400:      	and	w14, w14, #0xff
    1404:      	tbz	w14, #0x1, 0x13cc <ltmp0+0x13cc>
    1408:      	add	x15, x13, #0x4
    140c:      	ld1.s	{ v21 }[1], [x15]
    1410:      	tbnz	w14, #0x2, 0x13d0 <ltmp0+0x13d0>
    1414:      	tbz	w14, #0x3, 0x13dc <ltmp0+0x13dc>
    1418:      	add	x15, x13, #0xc
    141c:      	ld1.s	{ v21 }[3], [x15]
    1420:      	tbnz	w14, #0x4, 0x13e0 <ltmp0+0x13e0>
    1424:      	tbz	w14, #0x5, 0x13ec <ltmp0+0x13ec>
    1428:      	add	x15, x13, #0x14
    142c:      	ld1.s	{ v22 }[1], [x15]
    1430:      	tbnz	w14, #0x6, 0x13f0 <ltmp0+0x13f0>
    1434:      	tbz	w14, #0x7, 0x1380 <ltmp0+0x1380>
    1438:      	add	x13, x13, #0x1c
    143c:      	ld1.s	{ v22 }[3], [x13]
    1440:      	b	0x1380 <ltmp0+0x1380>
    1444:      	xtn.8b	v21, v18
    1448:      	movi	d5, #0x0000000000ffff
    144c:      	and.8b	v18, v21, v5
    1450:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1454:      	ldr	d22, [x10]
    1458:      	and.8b	v21, v21, v22
    145c:      	addv.8b	b21, v21
    1460:      	fmov	w13, s21
    1464:      	umaxv.8b	b21, v18
    1468:      	fmov	w10, s21
    146c:      	rbit	w12, w13
    1470:      	clz	w12, w12
    1474:      	tst	w10, #0x1
    1478:      	csel	w10, w12, wzr, ne
    147c:      	mov	w12, #0x600             ; =1536
    1480:      	dup.2d	v25, x12
    1484:      	umlal.2d	v19, v20, v6
    1488:      	mov	b22, v18[0]
    148c:      	mov.b	v22[4], v18[1]
    1490:      	add.2d	v21, v19, v25
    1494:      	ushll.2d	v19, v22, #0x0
    1498:      	shl.2d	v19, v19, #0x3f
    149c:      	cmlt.2d	v19, v19, #0
    14a0:      	and.16b	v19, v19, v21
    14a4:      	movi.2d	v5, #0000000000000000
    14a8:      	stp	q5, q5, [sp, #0x2c0]
    14ac:      	stp	q19, q5, [sp, #0x2a0]
    14b0:      	and	x12, x10, #0x7
    14b4:      	add	x14, sp, #0x2a0
    14b8:      	ldr	x12, [x14, x12, lsl #3]
    14bc:      	sub	x12, x12, x10
    14c0:      	lsl	x12, x12, #2
    14c4:      	add	x11, x11, x12
    14c8:      	movi.2d	v22, #0000000000000000
    14cc:      	movi.2d	v19, #0000000000000000
    14d0:      	tbz	w13, #0x0, 0x1510 <ltmp0+0x1510>
    14d4:      	ldr	s22, [x11]
    14d8:      	tbnz	w13, #0x1, 0x1514 <ltmp0+0x1514>
    14dc:      	tbz	w13, #0x2, 0x1520 <ltmp0+0x1520>
    14e0:      	add	x14, x11, #0x8
    14e4:      	ld1.s	{ v22 }[2], [x14]
    14e8:      	tbnz	w13, #0x3, 0x1524 <ltmp0+0x1524>
    14ec:      	tbz	w13, #0x4, 0x1530 <ltmp0+0x1530>
    14f0:      	add	x14, x11, #0x10
    14f4:      	ld1.s	{ v19 }[0], [x14]
    14f8:      	tbnz	w13, #0x5, 0x1534 <ltmp0+0x1534>
    14fc:      	tbz	w13, #0x6, 0x1540 <ltmp0+0x1540>
    1500:      	add	x14, x11, #0x18
    1504:      	ld1.s	{ v19 }[2], [x14]
    1508:      	tbnz	w13, #0x7, 0x1544 <ltmp0+0x1544>
    150c:      	b	0x154c <ltmp0+0x154c>
    1510:      	tbz	w13, #0x1, 0x14dc <ltmp0+0x14dc>
    1514:      	add	x14, x11, #0x4
    1518:      	ld1.s	{ v22 }[1], [x14]
    151c:      	tbnz	w13, #0x2, 0x14e0 <ltmp0+0x14e0>
    1520:      	tbz	w13, #0x3, 0x14ec <ltmp0+0x14ec>
    1524:      	add	x14, x11, #0xc
    1528:      	ld1.s	{ v22 }[3], [x14]
    152c:      	tbnz	w13, #0x4, 0x14f0 <ltmp0+0x14f0>
    1530:      	tbz	w13, #0x5, 0x14fc <ltmp0+0x14fc>
    1534:      	add	x14, x11, #0x14
    1538:      	ld1.s	{ v19 }[1], [x14]
    153c:      	tbnz	w13, #0x6, 0x1500 <ltmp0+0x1500>
    1540:      	tbz	w13, #0x7, 0x154c <ltmp0+0x154c>
    1544:      	add	x11, x11, #0x1c
    1548:      	ld1.s	{ v19 }[3], [x11]
    154c:      	mov	x15, #0x0               ; =0
    1550:      	umull.2d	v20, v20, v6
    1554:      	ldr	d5, [sp, #0xa0]
    1558:      	umlal.2d	v4, v5, v6
    155c:      	add.2d	v4, v4, v25
    1560:      	umlal.2d	v3, v27, v6
    1564:      	add.2d	v3, v3, v25
    1568:      	stp	q3, q4, [sp, #0x90]
    156c:      	umlal.2d	v2, v7, v6
    1570:      	adrp	x11, 0x1000 <ltmp0+0x1000>
    1574:      	ldr	q5, [x11]
    1578:      	mov	w11, #0x1800            ; =6144
    157c:      	dup.2d	v6, x11
    1580:      	sshll.2d	v7, v1, #0x0
    1584:      	bif.16b	v5, v6, v7
    1588:      	adrp	x11, 0x1000 <ltmp0+0x1000>
    158c:      	ldr	q7, [x11]
    1590:      	sshll.2d	v16, v0, #0x0
    1594:      	bif.16b	v7, v6, v16
    1598:      	adrp	x11, 0x1000 <ltmp0+0x1000>
    159c:      	ldr	q16, [x11]
    15a0:      	bif.16b	v16, v6, v24
    15a4:      	adrp	x11, 0x1000 <ltmp0+0x1000>
    15a8:      	ldr	q24, [x11]
    15ac:      	bit.16b	v6, v24, v23
    15b0:      	stp	q7, q6, [sp, #0x280]
    15b4:      	stp	q5, q16, [sp, #0x260]
    15b8:      	and	x11, x10, #0x7
    15bc:      	add	x14, sp, #0x260
    15c0:      	ldr	x11, [x14, x11, lsl #3]
    15c4:      	add.2d	v2, v2, v25
    15c8:      	str	q2, [sp, #0x80]
    15cc:      	sub	x11, x11, x10, lsl #2
    15d0:      	tst	w13, #0xff
    15d4:      	csel	x11, xzr, x11, eq
    15d8:      	add	x13, x26, x11
    15dc:      	ldp	q5, q6, [x13]
    15e0:      	zip2.8b	v7, v18, v0
    15e4:      	ushll.4s	v7, v7, #0x0
    15e8:      	shl.4s	v7, v7, #0x1f
    15ec:      	cmlt.4s	v7, v7, #0
    15f0:      	bit.16b	v6, v19, v7
    15f4:      	zip1.8b	v7, v18, v0
    15f8:      	ushll.4s	v7, v7, #0x0
    15fc:      	shl.4s	v7, v7, #0x1f
    1600:      	cmlt.4s	v7, v7, #0
    1604:      	bit.16b	v5, v22, v7
    1608:      	stp	q5, q6, [x13]
    160c:      	fmov	x13, d20
    1610:      	lsl	x13, x13, #2
    1614:      	mov	w14, #0x1               ; =1
    1618:      	dup.2d	v16, x14
    161c:      	add	x14, x9, x13
    1620:      	ushll2.2d	v5, v0, #0x0
    1624:      	and.16b	v5, v5, v16
    1628:      	ushll2.2d	v6, v1, #0x0
    162c:      	and.16b	v6, v6, v16
    1630:      	ushll.2d	v7, v0, #0x0
    1634:      	and.16b	v7, v7, v16
    1638:      	ushll.2d	v20, v1, #0x0
    163c:      	and.16b	v16, v20, v16
    1640:      	movi.2d	v20, #0000000000000000
    1644:      	movi.2d	v23, #0000000000000000
    1648:      	movi.2d	v24, #0000000000000000
    164c:      	movi.2d	v25, #0000000000000000
    1650:      	b	0x1684 <ltmp0+0x1684>
    1654:      	add	x15, x3, x15
    1658:      	ldp	q28, q29, [x15]
    165c:      	bif.16b	v27, v29, v0
    1660:      	bif.16b	v26, v28, v1
    1664:      	stp	q26, q27, [x15]
    1668:      	add.2d	v23, v23, v6
    166c:      	add.2d	v24, v24, v7
    1670:      	add.2d	v25, v25, v5
    1674:      	add.2d	v20, v20, v16
    1678:      	fmov	x15, d20
    167c:      	cmp	x15, #0xc0
    1680:      	b.ge	0x1720 <ltmp0+0x1720>
    1684:      	fmov	w17, s17
    1688:      	lsl	x15, x15, #5
    168c:      	add	x16, x14, x15
    1690:      	movi.2d	v26, #0000000000000000
    1694:      	movi.2d	v27, #0000000000000000
    1698:      	tbz	w17, #0x0, 0x16dc <ltmp0+0x16dc>
    169c:      	ldr	s26, [x16]
    16a0:      	and	w17, w17, #0xff
    16a4:      	tbnz	w17, #0x1, 0x16e4 <ltmp0+0x16e4>
    16a8:      	tbz	w17, #0x2, 0x16f0 <ltmp0+0x16f0>
    16ac:      	add	x0, x16, #0x8
    16b0:      	ld1.s	{ v26 }[2], [x0]
    16b4:      	tbnz	w17, #0x3, 0x16f4 <ltmp0+0x16f4>
    16b8:      	tbz	w17, #0x4, 0x1700 <ltmp0+0x1700>
    16bc:      	add	x0, x16, #0x10
    16c0:      	ld1.s	{ v27 }[0], [x0]
    16c4:      	tbnz	w17, #0x5, 0x1704 <ltmp0+0x1704>
    16c8:      	tbz	w17, #0x6, 0x1710 <ltmp0+0x1710>
    16cc:      	add	x0, x16, #0x18
    16d0:      	ld1.s	{ v27 }[2], [x0]
    16d4:      	tbz	w17, #0x7, 0x1654 <ltmp0+0x1654>
    16d8:      	b	0x1714 <ltmp0+0x1714>
    16dc:      	and	w17, w17, #0xff
    16e0:      	tbz	w17, #0x1, 0x16a8 <ltmp0+0x16a8>
    16e4:      	add	x0, x16, #0x4
    16e8:      	ld1.s	{ v26 }[1], [x0]
    16ec:      	tbnz	w17, #0x2, 0x16ac <ltmp0+0x16ac>
    16f0:      	tbz	w17, #0x3, 0x16b8 <ltmp0+0x16b8>
    16f4:      	add	x0, x16, #0xc
    16f8:      	ld1.s	{ v26 }[3], [x0]
    16fc:      	tbnz	w17, #0x4, 0x16bc <ltmp0+0x16bc>
    1700:      	tbz	w17, #0x5, 0x16c8 <ltmp0+0x16c8>
    1704:      	add	x0, x16, #0x14
    1708:      	ld1.s	{ v27 }[1], [x0]
    170c:      	tbnz	w17, #0x6, 0x16cc <ltmp0+0x16cc>
    1710:      	tbz	w17, #0x7, 0x1654 <ltmp0+0x1654>
    1714:      	add	x16, x16, #0x1c
    1718:      	ld1.s	{ v27 }[3], [x16]
    171c:      	b	0x1654 <ltmp0+0x1654>
    1720:      	add	x9, x9, x12
    1724:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    1728:      	ldr	d20, [x12]
    172c:      	shl.8b	v23, v18, #0x7
    1730:      	cmlt.8b	v23, v23, #0
    1734:      	and.8b	v20, v23, v20
    1738:      	addv.8b	b24, v20
    173c:      	fmov	w12, s24
    1740:      	movi.2d	v23, #0000000000000000
    1744:      	movi.2d	v20, #0000000000000000
    1748:      	tbz	w12, #0x0, 0x1788 <ltmp0+0x1788>
    174c:      	ldr	s23, [x9]
    1750:      	tbnz	w12, #0x1, 0x178c <ltmp0+0x178c>
    1754:      	tbz	w12, #0x2, 0x1798 <ltmp0+0x1798>
    1758:      	add	x14, x9, #0x8
    175c:      	ld1.s	{ v23 }[2], [x14]
    1760:      	tbnz	w12, #0x3, 0x179c <ltmp0+0x179c>
    1764:      	tbz	w12, #0x4, 0x17a8 <ltmp0+0x17a8>
    1768:      	add	x14, x9, #0x10
    176c:      	ld1.s	{ v20 }[0], [x14]
    1770:      	tbnz	w12, #0x5, 0x17ac <ltmp0+0x17ac>
    1774:      	tbz	w12, #0x6, 0x17b8 <ltmp0+0x17b8>
    1778:      	add	x14, x9, #0x18
    177c:      	ld1.s	{ v20 }[2], [x14]
    1780:      	tbnz	w12, #0x7, 0x17bc <ltmp0+0x17bc>
    1784:      	b	0x17c4 <ltmp0+0x17c4>
    1788:      	tbz	w12, #0x1, 0x1754 <ltmp0+0x1754>
    178c:      	add	x14, x9, #0x4
    1790:      	ld1.s	{ v23 }[1], [x14]
    1794:      	tbnz	w12, #0x2, 0x1758 <ltmp0+0x1758>
    1798:      	tbz	w12, #0x3, 0x1764 <ltmp0+0x1764>
    179c:      	add	x14, x9, #0xc
    17a0:      	ld1.s	{ v23 }[3], [x14]
    17a4:      	tbnz	w12, #0x4, 0x1768 <ltmp0+0x1768>
    17a8:      	tbz	w12, #0x5, 0x1774 <ltmp0+0x1774>
    17ac:      	add	x14, x9, #0x14
    17b0:      	ld1.s	{ v20 }[1], [x14]
    17b4:      	tbnz	w12, #0x6, 0x1778 <ltmp0+0x1778>
    17b8:      	tbz	w12, #0x7, 0x17c4 <ltmp0+0x17c4>
    17bc:      	add	x9, x9, #0x1c
    17c0:      	ld1.s	{ v20 }[3], [x9]
    17c4:      	mov	x14, #0x0               ; =0
    17c8:      	add	x9, x3, x11
    17cc:      	ldp	q25, q26, [x9]
    17d0:      	zip2.8b	v27, v18, v0
    17d4:      	ushll.4s	v27, v27, #0x0
    17d8:      	shl.4s	v27, v27, #0x1f
    17dc:      	cmlt.4s	v27, v27, #0
    17e0:      	bit.16b	v26, v20, v27
    17e4:      	zip1.8b	v27, v18, v0
    17e8:      	ushll.4s	v27, v27, #0x0
    17ec:      	shl.4s	v27, v27, #0x1f
    17f0:      	cmlt.4s	v27, v27, #0
    17f4:      	bit.16b	v25, v23, v27
    17f8:      	stp	q25, q26, [x9]
    17fc:      	add	x9, x8, x13
    1800:      	movi.2d	v25, #0000000000000000
    1804:      	movi.2d	v26, #0000000000000000
    1808:      	movi.2d	v27, #0000000000000000
    180c:      	movi.2d	v28, #0000000000000000
    1810:      	b	0x1830 <ltmp0+0x1830>
    1814:      	add.2d	v26, v26, v6
    1818:      	add.2d	v27, v27, v7
    181c:      	add.2d	v28, v28, v5
    1820:      	add.2d	v25, v25, v16
    1824:      	fmov	x14, d25
    1828:      	cmp	x14, #0xc0
    182c:      	b.ge	0x1ab0 <ltmp0+0x1ab0>
    1830:      	fmov	w12, s17
    1834:      	lsl	x11, x14, #5
    1838:      	add	x13, x26, x11
    183c:      	ldp	q30, q29, [x13]
    1840:      	and.16b	v30, v1, v30
    1844:      	fneg.4s	v31, v30
    1848:      	and.16b	v31, v1, v31
    184c:      	ldp	q2, q3, [sp, #0x160]
    1850:      	fcmge.4s	v9, v31, v2
    1854:      	fcmge.4s	v10, v3, v31
    1858:      	and.16b	v9, v9, v10
    185c:      	and.16b	v9, v9, v31
    1860:      	fmul.4s	v10, v9, v11
    1864:      	mvni.4s	v11, #0x80, lsl #24
    1868:      	bsl.16b	v11, v14, v10
    186c:      	fadd.4s	v10, v10, v11
    1870:      	fsub.4s	v10, v10, v11
    1874:      	fcvtzs.4s	v10, v10
    1878:      	scvtf.4s	v11, v10
    187c:      	fmul.4s	v12, v11, v12
    1880:      	fadd.4s	v9, v9, v12
    1884:      	ldr	q12, [sp, #0xf0]
    1888:      	fmul.4s	v11, v11, v12
    188c:      	fadd.4s	v9, v9, v11
    1890:      	ldp	q12, q11, [sp, #0xd0]
    1894:      	fmul.4s	v11, v9, v11
    1898:      	fadd.4s	v11, v11, v12
    189c:      	fmul.4s	v11, v9, v11
    18a0:      	ldp	q12, q4, [sp, #0x120]
    18a4:      	fadd.4s	v11, v11, v12
    18a8:      	fmul.4s	v11, v9, v11
    18ac:      	ldr	q12, [sp, #0x140]
    18b0:      	fadd.4s	v11, v11, v12
    18b4:      	fmul.4s	v11, v9, v11
    18b8:      	ldr	q12, [sp, #0x150]
    18bc:      	fadd.4s	v11, v11, v12
    18c0:      	fmul.4s	v11, v9, v11
    18c4:      	fadd.4s	v11, v11, v8
    18c8:      	fmul.4s	v12, v9, v9
    18cc:      	fmul.4s	v11, v12, v11
    18d0:      	fadd.4s	v9, v9, v11
    18d4:      	fadd.4s	v9, v9, v4
    18d8:      	sshr.4s	v11, v10, #0x1
    18dc:      	shl.4s	v12, v11, #0x17
    18e0:      	add.4s	v12, v12, v4
    18e4:      	fmul.4s	v9, v9, v12
    18e8:      	sub.4s	v10, v10, v11
    18ec:      	shl.4s	v10, v10, #0x17
    18f0:      	add.4s	v10, v10, v4
    18f4:      	fmul.4s	v9, v9, v10
    18f8:      	fcmgt.4s	v10, v2, v31
    18fc:      	fcmgt.4s	v11, v31, v3
    1900:      	fcmeq.4s	v31, v31, v31
    1904:      	fadd.4s	v9, v9, v4
    1908:      	bit.16b	v9, v4, v10
    190c:      	ldp	q4, q2, [sp, #0x100]
    1910:      	bit.16b	v9, v2, v11
    1914:      	bsl.16b	v31, v9, v4
    1918:      	fdiv.4s	v31, v30, v31
    191c:      	add	x13, x3, x11
    1920:      	ldp	q9, q30, [x13]
    1924:      	and.16b	v9, v1, v9
    1928:      	fmul.4s	v31, v9, v31
    192c:      	add	x11, x9, x11
    1930:      	tbz	w12, #0x0, 0x1958 <ltmp0+0x1958>
    1934:      	str	s31, [x11]
    1938:      	and	w12, w12, #0xff
    193c:      	tbnz	w12, #0x1, 0x1960 <ltmp0+0x1960>
    1940:      	ldp	q12, q11, [sp, #0xb0]
    1944:      	tbz	w12, #0x2, 0x1970 <ltmp0+0x1970>
    1948:      	add	x13, x11, #0x8
    194c:      	st1.s	{ v31 }[2], [x13]
    1950:      	tbnz	w12, #0x3, 0x1974 <ltmp0+0x1974>
    1954:      	b	0x197c <ltmp0+0x197c>
    1958:      	and	w12, w12, #0xff
    195c:      	tbz	w12, #0x1, 0x1940 <ltmp0+0x1940>
    1960:      	add	x13, x11, #0x4
    1964:      	st1.s	{ v31 }[1], [x13]
    1968:      	ldp	q12, q11, [sp, #0xb0]
    196c:      	tbnz	w12, #0x2, 0x1948 <ltmp0+0x1948>
    1970:      	tbz	w12, #0x3, 0x197c <ltmp0+0x197c>
    1974:      	add	x13, x11, #0xc
    1978:      	st1.s	{ v31 }[3], [x13]
    197c:      	and.16b	v29, v0, v29
    1980:      	fneg.4s	v31, v29
    1984:      	and.16b	v31, v0, v31
    1988:      	ldp	q2, q3, [sp, #0x160]
    198c:      	fcmge.4s	v9, v31, v2
    1990:      	fcmge.4s	v10, v3, v31
    1994:      	and.16b	v9, v9, v10
    1998:      	and.16b	v9, v9, v31
    199c:      	fmul.4s	v10, v9, v11
    19a0:      	mvni.4s	v11, #0x80, lsl #24
    19a4:      	bsl.16b	v11, v14, v10
    19a8:      	fadd.4s	v10, v10, v11
    19ac:      	fsub.4s	v10, v10, v11
    19b0:      	fcvtzs.4s	v10, v10
    19b4:      	scvtf.4s	v11, v10
    19b8:      	fmul.4s	v12, v11, v12
    19bc:      	fadd.4s	v9, v9, v12
    19c0:      	ldr	q12, [sp, #0xf0]
    19c4:      	fmul.4s	v11, v11, v12
    19c8:      	fadd.4s	v9, v9, v11
    19cc:      	ldp	q12, q11, [sp, #0xd0]
    19d0:      	fmul.4s	v11, v9, v11
    19d4:      	fadd.4s	v11, v11, v12
    19d8:      	fmul.4s	v11, v9, v11
    19dc:      	ldp	q12, q4, [sp, #0x120]
    19e0:      	fadd.4s	v11, v11, v12
    19e4:      	fmul.4s	v11, v9, v11
    19e8:      	ldr	q12, [sp, #0x140]
    19ec:      	fadd.4s	v11, v11, v12
    19f0:      	fmul.4s	v11, v9, v11
    19f4:      	ldr	q12, [sp, #0x150]
    19f8:      	fadd.4s	v11, v11, v12
    19fc:      	fmul.4s	v11, v9, v11
    1a00:      	fadd.4s	v11, v11, v8
    1a04:      	fmul.4s	v12, v9, v9
    1a08:      	fmul.4s	v11, v12, v11
    1a0c:      	fadd.4s	v9, v9, v11
    1a10:      	fadd.4s	v9, v9, v4
    1a14:      	sshr.4s	v11, v10, #0x1
    1a18:      	shl.4s	v12, v11, #0x17
    1a1c:      	add.4s	v12, v12, v4
    1a20:      	fmul.4s	v9, v9, v12
    1a24:      	sub.4s	v10, v10, v11
    1a28:      	shl.4s	v10, v10, #0x17
    1a2c:      	add.4s	v10, v10, v4
    1a30:      	fmul.4s	v9, v9, v10
    1a34:      	fcmgt.4s	v10, v2, v31
    1a38:      	fcmgt.4s	v11, v31, v3
    1a3c:      	fcmeq.4s	v31, v31, v31
    1a40:      	fadd.4s	v9, v9, v4
    1a44:      	bit.16b	v9, v4, v10
    1a48:      	ldp	q4, q2, [sp, #0x100]
    1a4c:      	bit.16b	v9, v2, v11
    1a50:      	bsl.16b	v31, v9, v4
    1a54:      	fdiv.4s	v29, v29, v31
    1a58:      	and.16b	v30, v0, v30
    1a5c:      	fmul.4s	v29, v30, v29
    1a60:      	tbz	w12, #0x4, 0x1a88 <ltmp0+0x1a88>
    1a64:      	str	s29, [x11, #0x10]
    1a68:      	tbnz	w12, #0x5, 0x1a8c <ltmp0+0x1a8c>
    1a6c:      	mvni.4s	v30, #0x80, lsl #24
    1a70:      	ldp	q12, q11, [sp, #0xb0]
    1a74:      	tbz	w12, #0x6, 0x1aa0 <ltmp0+0x1aa0>
    1a78:      	add	x13, x11, #0x18
    1a7c:      	st1.s	{ v29 }[2], [x13]
    1a80:      	tbz	w12, #0x7, 0x1814 <ltmp0+0x1814>
    1a84:      	b	0x1aa4 <ltmp0+0x1aa4>
    1a88:      	tbz	w12, #0x5, 0x1a6c <ltmp0+0x1a6c>
    1a8c:      	add	x13, x11, #0x14
    1a90:      	st1.s	{ v29 }[1], [x13]
    1a94:      	mvni.4s	v30, #0x80, lsl #24
    1a98:      	ldp	q12, q11, [sp, #0xb0]
    1a9c:      	tbnz	w12, #0x6, 0x1a78 <ltmp0+0x1a78>
    1aa0:      	tbz	w12, #0x7, 0x1814 <ltmp0+0x1814>
    1aa4:      	add	x11, x11, #0x1c
    1aa8:      	st1.s	{ v29 }[3], [x11]
    1aac:      	b	0x1814 <ltmp0+0x1814>
    1ab0:      	fneg.4s	v0, v22
    1ab4:      	fmov	w9, s24
    1ab8:      	zip1.8b	v1, v18, v0
    1abc:      	ushll.4s	v1, v1, #0x0
    1ac0:      	shl.4s	v1, v1, #0x1f
    1ac4:      	cmlt.4s	v1, v1, #0
    1ac8:      	and.16b	v0, v1, v0
    1acc:      	ldp	q2, q3, [sp, #0x160]
    1ad0:      	fcmge.4s	v1, v0, v2
    1ad4:      	fcmge.4s	v5, v3, v0
    1ad8:      	and.16b	v1, v1, v5
    1adc:      	and.16b	v1, v1, v0
    1ae0:      	fmul.4s	v5, v1, v11
    1ae4:      	mov.16b	v6, v30
    1ae8:      	bsl.16b	v6, v14, v5
    1aec:      	fadd.4s	v5, v5, v6
    1af0:      	fsub.4s	v5, v5, v6
    1af4:      	fcvtzs.4s	v5, v5
    1af8:      	scvtf.4s	v6, v5
    1afc:      	fmul.4s	v7, v6, v12
    1b00:      	fadd.4s	v1, v1, v7
    1b04:      	ldp	q9, q31, [sp, #0xe0]
    1b08:      	fmul.4s	v6, v6, v31
    1b0c:      	fadd.4s	v1, v1, v6
    1b10:      	fmul.4s	v6, v1, v9
    1b14:      	ldr	q10, [sp, #0xd0]
    1b18:      	fadd.4s	v6, v6, v10
    1b1c:      	fmul.4s	v6, v1, v6
    1b20:      	ldp	q27, q4, [sp, #0x120]
    1b24:      	fadd.4s	v6, v6, v27
    1b28:      	fmul.4s	v6, v1, v6
    1b2c:      	ldr	q7, [sp, #0x140]
    1b30:      	fadd.4s	v6, v6, v7
    1b34:      	fmul.4s	v6, v1, v6
    1b38:      	ldr	q7, [sp, #0x150]
    1b3c:      	fadd.4s	v6, v6, v7
    1b40:      	fmul.4s	v6, v1, v6
    1b44:      	fadd.4s	v6, v6, v8
    1b48:      	fmul.4s	v7, v1, v1
    1b4c:      	fmul.4s	v6, v7, v6
    1b50:      	fadd.4s	v1, v1, v6
    1b54:      	fadd.4s	v1, v1, v4
    1b58:      	sshr.4s	v6, v5, #0x1
    1b5c:      	shl.4s	v7, v6, #0x17
    1b60:      	add.4s	v7, v7, v4
    1b64:      	fmul.4s	v1, v1, v7
    1b68:      	sub.4s	v5, v5, v6
    1b6c:      	shl.4s	v5, v5, #0x17
    1b70:      	add.4s	v5, v5, v4
    1b74:      	fmul.4s	v1, v1, v5
    1b78:      	fcmgt.4s	v5, v2, v0
    1b7c:      	fcmgt.4s	v6, v0, v3
    1b80:      	fcmeq.4s	v0, v0, v0
    1b84:      	fadd.4s	v1, v1, v4
    1b88:      	bit.16b	v1, v4, v5
    1b8c:      	ldp	q25, q24, [sp, #0x100]
    1b90:      	bit.16b	v1, v24, v6
    1b94:      	bsl.16b	v0, v1, v25
    1b98:      	fdiv.4s	v0, v22, v0
    1b9c:      	fmul.4s	v0, v0, v23
    1ba0:      	ldp	q3, q2, [sp, #0x90]
    1ba4:      	stp	q21, q2, [sp, #0x210]
    1ba8:      	ldr	q1, [sp, #0x80]
    1bac:      	stp	q3, q1, [sp, #0x230]
    1bb0:      	and	x11, x10, #0x7
    1bb4:      	add	x12, sp, #0x210
    1bb8:      	ldr	x11, [x12, x11, lsl #3]
    1bbc:      	sub	x10, x11, x10
    1bc0:      	add	x8, x8, x10, lsl #2
    1bc4:      	tbz	w9, #0x0, 0x1be8 <ltmp0+0x1be8>
    1bc8:      	str	s0, [x8]
    1bcc:      	tbnz	w9, #0x1, 0x1bec <ltmp0+0x1bec>
    1bd0:      	ldr	q21, [sp, #0x140]
    1bd4:      	tbz	w9, #0x2, 0x1bfc <ltmp0+0x1bfc>
    1bd8:      	add	x10, x8, #0x8
    1bdc:      	st1.s	{ v0 }[2], [x10]
    1be0:      	tbnz	w9, #0x3, 0x1c00 <ltmp0+0x1c00>
    1be4:      	b	0x1c08 <ltmp0+0x1c08>
    1be8:      	tbz	w9, #0x1, 0x1bd0 <ltmp0+0x1bd0>
    1bec:      	add	x10, x8, #0x4
    1bf0:      	st1.s	{ v0 }[1], [x10]
    1bf4:      	ldr	q21, [sp, #0x140]
    1bf8:      	tbnz	w9, #0x2, 0x1bd8 <ltmp0+0x1bd8>
    1bfc:      	tbz	w9, #0x3, 0x1c08 <ltmp0+0x1c08>
    1c00:      	add	x10, x8, #0xc
    1c04:      	st1.s	{ v0 }[3], [x10]
    1c08:      	fneg.4s	v0, v19
    1c0c:      	zip2.8b	v1, v18, v0
    1c10:      	ushll.4s	v1, v1, #0x0
    1c14:      	shl.4s	v1, v1, #0x1f
    1c18:      	cmlt.4s	v1, v1, #0
    1c1c:      	and.16b	v0, v1, v0
    1c20:      	ldp	q6, q5, [sp, #0x160]
    1c24:      	fcmge.4s	v1, v0, v6
    1c28:      	fcmge.4s	v2, v5, v0
    1c2c:      	and.16b	v1, v1, v2
    1c30:      	and.16b	v1, v1, v0
    1c34:      	fmul.4s	v2, v1, v11
    1c38:      	mov.16b	v3, v30
    1c3c:      	bsl.16b	v3, v14, v2
    1c40:      	fadd.4s	v2, v2, v3
    1c44:      	fsub.4s	v2, v2, v3
    1c48:      	fcvtzs.4s	v2, v2
    1c4c:      	scvtf.4s	v3, v2
    1c50:      	fmul.4s	v4, v3, v12
    1c54:      	fadd.4s	v1, v1, v4
    1c58:      	fmul.4s	v3, v3, v31
    1c5c:      	fadd.4s	v1, v1, v3
    1c60:      	fmul.4s	v3, v1, v9
    1c64:      	fadd.4s	v3, v3, v10
    1c68:      	fmul.4s	v3, v1, v3
    1c6c:      	fadd.4s	v3, v3, v27
    1c70:      	fmul.4s	v3, v1, v3
    1c74:      	fadd.4s	v3, v3, v21
    1c78:      	fmul.4s	v3, v1, v3
    1c7c:      	ldr	q4, [sp, #0x150]
    1c80:      	fadd.4s	v3, v3, v4
    1c84:      	fmul.4s	v3, v1, v3
    1c88:      	fadd.4s	v3, v3, v8
    1c8c:      	fmul.4s	v4, v1, v1
    1c90:      	fmul.4s	v3, v4, v3
    1c94:      	fadd.4s	v1, v1, v3
    1c98:      	ldr	q22, [sp, #0x130]
    1c9c:      	fadd.4s	v1, v1, v22
    1ca0:      	sshr.4s	v3, v2, #0x1
    1ca4:      	shl.4s	v4, v3, #0x17
    1ca8:      	add.4s	v4, v4, v22
    1cac:      	fmul.4s	v1, v1, v4
    1cb0:      	sub.4s	v2, v2, v3
    1cb4:      	shl.4s	v2, v2, #0x17
    1cb8:      	add.4s	v2, v2, v22
    1cbc:      	fmul.4s	v1, v1, v2
    1cc0:      	fcmgt.4s	v2, v6, v0
    1cc4:      	fcmgt.4s	v3, v0, v5
    1cc8:      	fcmeq.4s	v0, v0, v0
    1ccc:      	fadd.4s	v1, v1, v22
    1cd0:      	bit.16b	v1, v22, v2
    1cd4:      	bit.16b	v1, v24, v3
    1cd8:      	bsl.16b	v0, v1, v25
    1cdc:      	fdiv.4s	v0, v19, v0
    1ce0:      	fmul.4s	v0, v0, v20
    1ce4:      	tbz	w9, #0x4, 0x1d0c <ltmp0+0x1d0c>
    1ce8:      	str	s0, [x8, #0x10]
    1cec:      	tbnz	w9, #0x5, 0x1d10 <ltmp0+0x1d10>
    1cf0:      	ldr	q20, [sp, #0x150]
    1cf4:      	movi.4s	v19, #0x3f, lsl #24
    1cf8:      	tbz	w9, #0x6, 0x2124 <ltmp0+0x2124>
    1cfc:      	add	x10, x8, #0x18
    1d00:      	st1.s	{ v0 }[2], [x10]
    1d04:      	tbnz	w9, #0x7, 0x2128 <ltmp0+0x2128>
    1d08:      	b	0x118 <ltmp0+0x118>
    1d0c:      	tbz	w9, #0x5, 0x1cf0 <ltmp0+0x1cf0>
    1d10:      	add	x10, x8, #0x14
    1d14:      	st1.s	{ v0 }[1], [x10]
    1d18:      	ldr	q20, [sp, #0x150]
    1d1c:      	movi.4s	v19, #0x3f, lsl #24
    1d20:      	tbz	w9, #0x6, 0x2124 <ltmp0+0x2124>
    1d24:      	b	0x1cfc <ltmp0+0x1cfc>
    1d28:      	xtn.8b	v1, v18
    1d2c:      	movi	d0, #0x0000000000ffff
    1d30:      	and.8b	v0, v1, v0
    1d34:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1d38:      	ldr	d17, [x10]
    1d3c:      	and.8b	v1, v1, v17
    1d40:      	addv.8b	b1, v1
    1d44:      	fmov	w12, s1
    1d48:      	umaxv.8b	b1, v0
    1d4c:      	fmov	w10, s1
    1d50:      	rbit	w13, w12
    1d54:      	clz	w13, w13
    1d58:      	tst	w10, #0x1
    1d5c:      	csel	w10, w13, wzr, ne
    1d60:      	mov	w13, #0x600             ; =1536
    1d64:      	dup.2d	v21, x13
    1d68:      	umlal.2d	v19, v20, v6
    1d6c:      	mov	b1, v0[0]
    1d70:      	mov.b	v1[4], v0[1]
    1d74:      	add.2d	v17, v19, v21
    1d78:      	ushll.2d	v1, v1, #0x0
    1d7c:      	shl.2d	v1, v1, #0x3f
    1d80:      	cmlt.2d	v1, v1, #0
    1d84:      	and.16b	v1, v1, v17
    1d88:      	movi.2d	v5, #0000000000000000
    1d8c:      	stp	q5, q5, [sp, #0x1e0]
    1d90:      	stp	q1, q5, [sp, #0x1c0]
    1d94:      	and	x13, x10, #0x7
    1d98:      	add	x14, sp, #0x1c0
    1d9c:      	ldr	x13, [x14, x13, lsl #3]
    1da0:      	sub	x13, x13, x10
    1da4:      	lsl	x13, x13, #2
    1da8:      	add	x11, x11, x13
    1dac:      	movi.2d	v18, #0000000000000000
    1db0:      	movi.2d	v1, #0000000000000000
    1db4:      	tbz	w12, #0x0, 0x1df4 <ltmp0+0x1df4>
    1db8:      	ldr	s18, [x11]
    1dbc:      	tbnz	w12, #0x1, 0x1df8 <ltmp0+0x1df8>
    1dc0:      	tbz	w12, #0x2, 0x1e04 <ltmp0+0x1e04>
    1dc4:      	add	x14, x11, #0x8
    1dc8:      	ld1.s	{ v18 }[2], [x14]
    1dcc:      	tbnz	w12, #0x3, 0x1e08 <ltmp0+0x1e08>
    1dd0:      	tbz	w12, #0x4, 0x1e14 <ltmp0+0x1e14>
    1dd4:      	add	x14, x11, #0x10
    1dd8:      	ld1.s	{ v1 }[0], [x14]
    1ddc:      	tbnz	w12, #0x5, 0x1e18 <ltmp0+0x1e18>
    1de0:      	tbz	w12, #0x6, 0x1e24 <ltmp0+0x1e24>
    1de4:      	add	x14, x11, #0x18
    1de8:      	ld1.s	{ v1 }[2], [x14]
    1dec:      	tbnz	w12, #0x7, 0x1e28 <ltmp0+0x1e28>
    1df0:      	b	0x1e30 <ltmp0+0x1e30>
    1df4:      	tbz	w12, #0x1, 0x1dc0 <ltmp0+0x1dc0>
    1df8:      	add	x14, x11, #0x4
    1dfc:      	ld1.s	{ v18 }[1], [x14]
    1e00:      	tbnz	w12, #0x2, 0x1dc4 <ltmp0+0x1dc4>
    1e04:      	tbz	w12, #0x3, 0x1dd0 <ltmp0+0x1dd0>
    1e08:      	add	x14, x11, #0xc
    1e0c:      	ld1.s	{ v18 }[3], [x14]
    1e10:      	tbnz	w12, #0x4, 0x1dd4 <ltmp0+0x1dd4>
    1e14:      	tbz	w12, #0x5, 0x1de0 <ltmp0+0x1de0>
    1e18:      	add	x14, x11, #0x14
    1e1c:      	ld1.s	{ v1 }[1], [x14]
    1e20:      	tbnz	w12, #0x6, 0x1de4 <ltmp0+0x1de4>
    1e24:      	tbz	w12, #0x7, 0x1e30 <ltmp0+0x1e30>
    1e28:      	add	x11, x11, #0x1c
    1e2c:      	ld1.s	{ v1 }[3], [x11]
    1e30:      	adrp	x11, 0x1000 <ltmp0+0x1000>
    1e34:      	ldr	d19, [x11]
    1e38:      	shl.8b	v20, v0, #0x7
    1e3c:      	cmlt.8b	v20, v20, #0
    1e40:      	and.8b	v19, v20, v19
    1e44:      	addv.8b	b20, v19
    1e48:      	fmov	w11, s20
    1e4c:      	add	x9, x9, x13
    1e50:      	movi.2d	v22, #0000000000000000
    1e54:      	movi.2d	v19, #0000000000000000
    1e58:      	tbz	w11, #0x0, 0x1e98 <ltmp0+0x1e98>
    1e5c:      	ldr	s22, [x9]
    1e60:      	tbnz	w11, #0x1, 0x1e9c <ltmp0+0x1e9c>
    1e64:      	tbz	w11, #0x2, 0x1ea8 <ltmp0+0x1ea8>
    1e68:      	add	x12, x9, #0x8
    1e6c:      	ld1.s	{ v22 }[2], [x12]
    1e70:      	tbnz	w11, #0x3, 0x1eac <ltmp0+0x1eac>
    1e74:      	tbz	w11, #0x4, 0x1eb8 <ltmp0+0x1eb8>
    1e78:      	add	x12, x9, #0x10
    1e7c:      	ld1.s	{ v19 }[0], [x12]
    1e80:      	tbnz	w11, #0x5, 0x1ebc <ltmp0+0x1ebc>
    1e84:      	tbz	w11, #0x6, 0x1ec8 <ltmp0+0x1ec8>
    1e88:      	add	x12, x9, #0x18
    1e8c:      	ld1.s	{ v19 }[2], [x12]
    1e90:      	tbnz	w11, #0x7, 0x1ecc <ltmp0+0x1ecc>
    1e94:      	b	0x1ed4 <ltmp0+0x1ed4>
    1e98:      	tbz	w11, #0x1, 0x1e64 <ltmp0+0x1e64>
    1e9c:      	add	x12, x9, #0x4
    1ea0:      	ld1.s	{ v22 }[1], [x12]
    1ea4:      	tbnz	w11, #0x2, 0x1e68 <ltmp0+0x1e68>
    1ea8:      	tbz	w11, #0x3, 0x1e74 <ltmp0+0x1e74>
    1eac:      	add	x12, x9, #0xc
    1eb0:      	ld1.s	{ v22 }[3], [x12]
    1eb4:      	tbnz	w11, #0x4, 0x1e78 <ltmp0+0x1e78>
    1eb8:      	tbz	w11, #0x5, 0x1e84 <ltmp0+0x1e84>
    1ebc:      	add	x12, x9, #0x14
    1ec0:      	ld1.s	{ v19 }[1], [x12]
    1ec4:      	tbnz	w11, #0x6, 0x1e88 <ltmp0+0x1e88>
    1ec8:      	tbz	w11, #0x7, 0x1ed4 <ltmp0+0x1ed4>
    1ecc:      	add	x9, x9, #0x1c
    1ed0:      	ld1.s	{ v19 }[3], [x9]
    1ed4:      	ldr	d5, [sp, #0xa0]
    1ed8:      	umlal.2d	v4, v5, v6
    1edc:      	add.2d	v4, v4, v21
    1ee0:      	ldr	d5, [sp, #0x80]
    1ee4:      	umlal.2d	v3, v5, v6
    1ee8:      	add.2d	v3, v3, v21
    1eec:      	ldr	d5, [sp, #0x90]
    1ef0:      	umlal.2d	v2, v5, v6
    1ef4:      	add.2d	v5, v2, v21
    1ef8:      	fneg.4s	v2, v18
    1efc:      	zip1.8b	v6, v0, v0
    1f00:      	ushll.4s	v6, v6, #0x0
    1f04:      	shl.4s	v6, v6, #0x1f
    1f08:      	cmlt.4s	v6, v6, #0
    1f0c:      	and.16b	v2, v6, v2
    1f10:      	ldp	q28, q26, [sp, #0x160]
    1f14:      	fcmge.4s	v6, v2, v28
    1f18:      	fcmge.4s	v7, v26, v2
    1f1c:      	and.16b	v6, v6, v7
    1f20:      	and.16b	v6, v6, v2
    1f24:      	fmul.4s	v7, v6, v11
    1f28:      	mov.16b	v16, v30
    1f2c:      	bsl.16b	v16, v14, v7
    1f30:      	fadd.4s	v7, v7, v16
    1f34:      	fsub.4s	v7, v7, v16
    1f38:      	fcvtzs.4s	v7, v7
    1f3c:      	scvtf.4s	v16, v7
    1f40:      	fmul.4s	v21, v16, v12
    1f44:      	fadd.4s	v6, v6, v21
    1f48:      	fmul.4s	v16, v16, v31
    1f4c:      	fadd.4s	v6, v6, v16
    1f50:      	fmul.4s	v16, v6, v9
    1f54:      	fadd.4s	v16, v16, v10
    1f58:      	fmul.4s	v16, v6, v16
    1f5c:      	fadd.4s	v16, v16, v27
    1f60:      	fmul.4s	v16, v6, v16
    1f64:      	ldp	q23, q21, [sp, #0x140]
    1f68:      	fadd.4s	v16, v16, v23
    1f6c:      	fmul.4s	v16, v6, v16
    1f70:      	fadd.4s	v16, v16, v21
    1f74:      	fmul.4s	v16, v6, v16
    1f78:      	fadd.4s	v16, v16, v8
    1f7c:      	fmul.4s	v21, v6, v6
    1f80:      	fmul.4s	v16, v21, v16
    1f84:      	fadd.4s	v6, v6, v16
    1f88:      	ldr	q23, [sp, #0x130]
    1f8c:      	fadd.4s	v6, v6, v23
    1f90:      	sshr.4s	v16, v7, #0x1
    1f94:      	shl.4s	v21, v16, #0x17
    1f98:      	add.4s	v21, v21, v23
    1f9c:      	fmul.4s	v6, v6, v21
    1fa0:      	sub.4s	v7, v7, v16
    1fa4:      	shl.4s	v7, v7, #0x17
    1fa8:      	add.4s	v7, v7, v23
    1fac:      	fmul.4s	v6, v6, v7
    1fb0:      	fcmgt.4s	v7, v28, v2
    1fb4:      	fcmgt.4s	v16, v2, v26
    1fb8:      	fcmeq.4s	v2, v2, v2
    1fbc:      	fadd.4s	v6, v6, v23
    1fc0:      	bit.16b	v6, v23, v7
    1fc4:      	bit.16b	v6, v24, v16
    1fc8:      	bsl.16b	v2, v6, v25
    1fcc:      	fdiv.4s	v2, v18, v2
    1fd0:      	fmul.4s	v2, v22, v2
    1fd4:      	stp	q17, q4, [sp, #0x180]
    1fd8:      	stp	q3, q5, [sp, #0x1a0]
    1fdc:      	and	x9, x10, #0x7
    1fe0:      	add	x11, sp, #0x180
    1fe4:      	ldr	x9, [x11, x9, lsl #3]
    1fe8:      	sub	x9, x9, x10
    1fec:      	add	x8, x8, x9, lsl #2
    1ff0:      	fmov	w9, s20
    1ff4:      	tbz	w9, #0x0, 0x2018 <ltmp0+0x2018>
    1ff8:      	str	s2, [x8]
    1ffc:      	tbnz	w9, #0x1, 0x201c <ltmp0+0x201c>
    2000:      	ldp	q21, q20, [sp, #0x140]
    2004:      	tbz	w9, #0x2, 0x202c <ltmp0+0x202c>
    2008:      	add	x10, x8, #0x8
    200c:      	st1.s	{ v2 }[2], [x10]
    2010:      	tbnz	w9, #0x3, 0x2030 <ltmp0+0x2030>
    2014:      	b	0x2038 <ltmp0+0x2038>
    2018:      	tbz	w9, #0x1, 0x2000 <ltmp0+0x2000>
    201c:      	add	x10, x8, #0x4
    2020:      	st1.s	{ v2 }[1], [x10]
    2024:      	ldp	q21, q20, [sp, #0x140]
    2028:      	tbnz	w9, #0x2, 0x2008 <ltmp0+0x2008>
    202c:      	tbz	w9, #0x3, 0x2038 <ltmp0+0x2038>
    2030:      	add	x10, x8, #0xc
    2034:      	st1.s	{ v2 }[3], [x10]
    2038:      	fneg.4s	v2, v1
    203c:      	zip2.8b	v0, v0, v0
    2040:      	ushll.4s	v0, v0, #0x0
    2044:      	shl.4s	v0, v0, #0x1f
    2048:      	cmlt.4s	v0, v0, #0
    204c:      	and.16b	v0, v0, v2
    2050:      	ldp	q7, q6, [sp, #0x160]
    2054:      	fcmge.4s	v2, v0, v7
    2058:      	fcmge.4s	v3, v6, v0
    205c:      	and.16b	v2, v2, v3
    2060:      	and.16b	v2, v2, v0
    2064:      	fmul.4s	v3, v2, v11
    2068:      	mov.16b	v4, v30
    206c:      	bsl.16b	v4, v14, v3
    2070:      	fadd.4s	v3, v3, v4
    2074:      	fsub.4s	v3, v3, v4
    2078:      	fcvtzs.4s	v3, v3
    207c:      	scvtf.4s	v4, v3
    2080:      	fmul.4s	v5, v4, v12
    2084:      	fadd.4s	v2, v2, v5
    2088:      	fmul.4s	v4, v4, v31
    208c:      	fadd.4s	v2, v2, v4
    2090:      	fmul.4s	v4, v2, v9
    2094:      	fadd.4s	v4, v4, v10
    2098:      	fmul.4s	v4, v2, v4
    209c:      	fadd.4s	v4, v4, v27
    20a0:      	fmul.4s	v4, v2, v4
    20a4:      	fadd.4s	v4, v4, v21
    20a8:      	fmul.4s	v4, v2, v4
    20ac:      	fadd.4s	v4, v4, v20
    20b0:      	fmul.4s	v4, v2, v4
    20b4:      	fadd.4s	v4, v4, v8
    20b8:      	fmul.4s	v5, v2, v2
    20bc:      	fmul.4s	v4, v5, v4
    20c0:      	fadd.4s	v2, v2, v4
    20c4:      	ldr	q22, [sp, #0x130]
    20c8:      	fadd.4s	v2, v2, v22
    20cc:      	sshr.4s	v4, v3, #0x1
    20d0:      	shl.4s	v5, v4, #0x17
    20d4:      	add.4s	v5, v5, v22
    20d8:      	fmul.4s	v2, v2, v5
    20dc:      	sub.4s	v3, v3, v4
    20e0:      	shl.4s	v3, v3, #0x17
    20e4:      	add.4s	v3, v3, v22
    20e8:      	fmul.4s	v2, v2, v3
    20ec:      	fcmgt.4s	v3, v7, v0
    20f0:      	fcmgt.4s	v4, v0, v6
    20f4:      	fcmeq.4s	v0, v0, v0
    20f8:      	fadd.4s	v2, v2, v22
    20fc:      	bit.16b	v2, v22, v3
    2100:      	bit.16b	v2, v24, v4
    2104:      	bsl.16b	v0, v2, v25
    2108:      	fdiv.4s	v0, v1, v0
    210c:      	fmul.4s	v0, v19, v0
    2110:      	tbz	w9, #0x4, 0x2134 <ltmp0+0x2134>
    2114:      	str	s0, [x8, #0x10]
    2118:      	tbnz	w9, #0x5, 0x2138 <ltmp0+0x2138>
    211c:      	movi.4s	v19, #0x3f, lsl #24
    2120:      	tbnz	w9, #0x6, 0x1cfc <ltmp0+0x1cfc>
    2124:      	tbz	w9, #0x7, 0x118 <ltmp0+0x118>
    2128:      	add	x8, x8, #0x1c
    212c:      	st1.s	{ v0 }[3], [x8]
    2130:      	b	0x118 <ltmp0+0x118>
    2134:      	tbz	w9, #0x5, 0x211c <ltmp0+0x211c>
    2138:      	add	x10, x8, #0x14
    213c:      	st1.s	{ v0 }[1], [x10]
    2140:      	movi.4s	v19, #0x3f, lsl #24
    2144:      	tbz	w9, #0x6, 0x2124 <ltmp0+0x2124>
    2148:      	b	0x1cfc <ltmp0+0x1cfc>
    214c:      	ldr	x9, [sp, #0x8]
    2150:      	stp	w15, w14, [x9]
    2154:      	str	w12, [x9, #0x8]
    2158:      	mov	w8, #0x18               ; =24
    215c:      	str	w8, [x9, #0x24]
    2160:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    2164:      	add	sp, sp, #0x330
    2168:      	ldp	x29, x30, [sp, #0x90]
    216c:      	ldp	x20, x19, [sp, #0x80]
    2170:      	ldp	x22, x21, [sp, #0x70]
    2174:      	ldp	x24, x23, [sp, #0x60]
    2178:      	ldp	x26, x25, [sp, #0x50]
    217c:      	ldp	x28, x27, [sp, #0x40]
    2180:      	ldp	d9, d8, [sp, #0x30]
    2184:      	ldp	d11, d10, [sp, #0x20]
    2188:      	ldp	d13, d12, [sp, #0x10]
    218c:      	ldp	d15, d14, [sp], #0xa0
    2190:      	ret

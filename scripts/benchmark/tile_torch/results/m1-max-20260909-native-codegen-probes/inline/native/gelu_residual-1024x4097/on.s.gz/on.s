
/private/tmp/luisa-packet-inline.UY1lIE/capture/gelu_residual-1024x4097/on/object/tile_xir_w8_36467_1788935106078398_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      2c:      	sub	sp, sp, #0x410
      30:      	str	x0, [sp, #0x18]
      34:      	str	w3, [sp, #0x38]
      38:      	cbz	w3, 0x32b4 <ltmp0+0x32b4>
      3c:      	mov	w12, #0x0               ; =0
      40:      	ldp	w9, w8, [x2, #0x2c]
      44:      	stp	w8, w9, [sp, #0x30]
      48:      	mov	w1, #0x2713             ; =10003
      4c:      	movk	w1, #0x3d37, lsl #16
      50:      	dup.4s	v19, w1
      54:      	mov	w3, #0x422a             ; =16938
      58:      	movk	w3, #0x3f4c, lsl #16
      5c:      	dup.4s	v21, w3
      60:      	mov	w8, #0x9231             ; =37425
      64:      	movk	w8, #0x2f30, lsl #16
      68:      	dup.4s	v1, w8
      6c:      	mov	w8, #0x322b             ; =12843
      70:      	movk	w8, #0x32d7, lsl #16
      74:      	dup.4s	v0, w8
      78:      	stp	q0, q1, [sp, #0x120]
      7c:      	mov	w8, #0xef1d             ; =61213
      80:      	movk	w8, #0x3638, lsl #16
      84:      	dup.4s	v23, w8
      88:      	mov	w8, #0xd01              ; =3329
      8c:      	movk	w8, #0x3950, lsl #16
      90:      	dup.4s	v30, w8
      94:      	mov	w8, #0x8889             ; =34953
      98:      	movk	w8, #0x3c08, lsl #16
      9c:      	dup.4s	v9, w8
      a0:      	mov	w8, #0xaaab             ; =43691
      a4:      	movk	w8, #0x3e2a, lsl #16
      a8:      	dup.4s	v0, w8
      ac:      	str	q0, [sp, #0xf0]
      b0:      	mov	w8, #0x76c7             ; =30407
      b4:      	movk	w8, #0x310f, lsl #16
      b8:      	dup.4s	v1, w8
      bc:      	mov	w8, #0xf27e             ; =62078
      c0:      	movk	w8, #0x3493, lsl #16
      c4:      	dup.4s	v20, w8
      c8:      	mov	w8, #0xd01              ; =3329
      cc:      	movk	w8, #0x37d0, lsl #16
      d0:      	dup.4s	v28, w8
      d4:      	mov	w8, #0xb61              ; =2913
      d8:      	movk	w8, #0x3ab6, lsl #16
      dc:      	dup.4s	v27, w8
      e0:      	mov	w8, #0xaaab             ; =43691
      e4:      	movk	w8, #0x3d2a, lsl #16
      e8:      	dup.4s	v25, w8
      ec:      	fmov.4s	v26, #1.00000000
      f0:      	fmov.4s	v29, #9.00000000
      f4:      	mov	w8, #-0x3d300000        ; =-1026555904
      f8:      	dup.4s	v0, w8
      fc:      	stp	q0, q1, [sp, #0x220]
     100:      	mov	w8, #0x42c80000         ; =1120403456
     104:      	dup.4s	v11, w8
     108:      	mov	w8, #0xaa3b             ; =43579
     10c:      	movk	w8, #0x3fb8, lsl #16
     110:      	dup.4s	v10, w8
     114:      	ldp	w8, w9, [x2]
     118:      	mov	w10, #0x7200            ; =29184
     11c:      	movk	w10, #0xbf31, lsl #16
     120:      	dup.4s	v12, w10
     124:      	mov	w10, #0xbe8e            ; =48782
     128:      	movk	w10, #0xb5bf, lsl #16
     12c:      	dup.4s	v13, w10
     130:      	mov	w10, #0x2bda            ; =11226
     134:      	movk	w10, #0x3950, lsl #16
     138:      	dup.4s	v1, w10
     13c:      	mov	w10, #0x96c9            ; =38601
     140:      	movk	w10, #0x3ab6, lsl #16
     144:      	dup.4s	v0, w10
     148:      	stp	q0, q1, [sp, #0x200]
     14c:      	mov	w10, #0x88a6            ; =34982
     150:      	movk	w10, #0x3c08, lsl #16
     154:      	dup.4s	v0, w10
     158:      	stp	q27, q0, [sp, #0x1e0]
     15c:      	mov	w10, #0xaa7a            ; =43642
     160:      	movk	w10, #0x3d2a, lsl #16
     164:      	dup.4s	v15, w10
     168:      	mov	w4, #0x4004             ; =16388
     16c:      	add	x23, sp, #0x4, lsl #12  ; =0x4000
     170:      	add	x23, x23, #0x3f0
     174:      	add	x24, sp, #0x3d0
     178:      	mvni.4s	v0, #0x7f, msl #16
     17c:      	fneg.4s	v22, v0
     180:      	mvni.4s	v0, #0x3f, msl #16
     184:      	fneg.4s	v18, v0
     188:      	ldp	w10, w11, [x2, #0x8]
     18c:      	str	x2, [sp, #0x10]
     190:      	str	x11, [sp, #0x28]
     194:      	stp	q21, q19, [sp, #0xb0]
     198:      	stp	q23, q11, [sp, #0xd0]
     19c:      	stp	q9, q30, [sp, #0x100]
     1a0:      	stp	q20, q26, [sp, #0x240]
     1a4:      	stp	q25, q28, [sp, #0x160]
     1a8:      	stp	q29, q15, [sp, #0x180]
     1ac:      	stp	q12, q10, [sp, #0x1b0]
     1b0:      	str	q13, [sp, #0x1a0]
     1b4:      	stp	q18, q22, [sp, #0x140]
     1b8:      	b	0x208 <ltmp0+0x208>
     1bc:      	ldr	q19, [sp, #0xc0]
     1c0:      	ldr	x15, [sp, #0x48]
     1c4:      	add	w8, w15, #0x1
     1c8:      	ldp	w11, w9, [sp, #0x30]
     1cc:      	cmp	w8, w9
     1d0:      	cset	w9, eq
     1d4:      	csinc	w8, wzr, w15, eq
     1d8:      	ldp	w14, w13, [sp, #0x3c]
     1dc:      	cinc	w10, w14, eq
     1e0:      	cmp	w10, w11
     1e4:      	cset	w11, eq
     1e8:      	ands	w11, w9, w11
     1ec:      	csel	w9, wzr, w10, ne
     1f0:      	add	w10, w13, w11
     1f4:      	ldr	w12, [sp, #0x44]
     1f8:      	add	w12, w12, #0x1
     1fc:      	ldr	w11, [sp, #0x38]
     200:      	cmp	w12, w11
     204:      	b.eq	0x32a0 <ltmp0+0x32a0>
     208:      	str	w12, [sp, #0x44]
     20c:      	mov	x13, x10
     210:      	mov	x14, x9
     214:      	mov	x15, x8
     218:      	ubfiz	x8, x8, #5, #32
     21c:      	ldr	x12, [sp, #0x28]
     220:      	cmp	x8, x12
     224:      	csel	x9, x8, xzr, ls
     228:      	subs	x10, x12, x9
     22c:      	cmp	x10, #0x20
     230:      	mov	w11, #0x20              ; =32
     234:      	csel	x10, x10, x11, lo
     238:      	cmp	x12, x9
     23c:      	ccmp	x8, x12, #0x2, hi
     240:      	csel	x8, x10, xzr, ls
     244:      	fmov.4s	v0, #0.25000000
     248:      	str	q0, [sp, #0x1d0]
     24c:      	cmp	x8, #0x20
     250:      	stp	w14, w13, [sp, #0x3c]
     254:      	str	x15, [sp, #0x48]
     258:      	b.lo	0xdd8 <ltmp0+0xdd8>
     25c:      	mov	x20, #0x0               ; =0
     260:      	ldr	x8, [sp, #0x18]
     264:      	ldr	x13, [x8]
     268:      	ldr	x21, [x8, #0x10]
     26c:      	ldr	x12, [x8, #0x30]
     270:      	subs	x8, x13, x12
     274:      	mov	w11, #0xfff             ; =4095
     278:      	movk	w11, #0x100, lsl #16
     27c:      	ccmp	x8, x11, #0x0, hs
     280:      	cset	w8, hi
     284:      	subs	x9, x12, x13
     288:      	ccmp	x9, x11, #0x0, hs
     28c:      	csinc	w8, w8, wzr, ls
     290:      	subs	x9, x21, x12
     294:      	ccmp	x9, x11, #0x0, hs
     298:      	cset	w9, hi
     29c:      	subs	x10, x12, x21
     2a0:      	ccmp	x10, x11, #0x0, hs
     2a4:      	csinc	w9, w9, wzr, ls
     2a8:      	and	w10, w8, w9
     2ac:      	lsl	w11, w15, #2
     2b0:      	and	x8, x15, #0x7ffffff
     2b4:      	mov	w9, #0x10               ; =16
     2b8:      	movk	w9, #0x1, lsl #16
     2bc:      	umaddl	x19, w8, w9, x12
     2c0:      	umaddl	x27, w8, w9, x21
     2c4:      	str	x13, [sp, #0x90]
     2c8:      	umaddl	x22, w8, w9, x13
     2cc:      	str	x12, [sp, #0x60]
     2d0:      	str	w10, [sp, #0x5c]
     2d4:      	str	x11, [sp, #0x50]
     2d8:      	b	0x4d0 <ltmp0+0x4d0>
     2dc:      	movi.2d	v0, #0000000000000000
     2e0:      	ldr	q2, [sp, #0x70]
     2e4:      	mov.s	v0[0], v2[0]
     2e8:      	mov	w1, #0x2713             ; =10003
     2ec:      	movk	w1, #0x3d37, lsl #16
     2f0:      	fmov	s1, w1
     2f4:      	fmul.4s	v1, v0, v1
     2f8:      	fmul.4s	v1, v2, v1
     2fc:      	fmul.4s	v1, v2, v1
     300:      	fadd.4s	v1, v2, v1
     304:      	mov	w3, #0x422a             ; =16938
     308:      	movk	w3, #0x3f4c, lsl #16
     30c:      	fmov	s2, w3
     310:      	fmul.4s	v2, v1, v2
     314:      	movi.2d	v1, #0000000000000000
     318:      	mov.s	v1[0], v2[0]
     31c:      	fabs.4s	v2, v1
     320:      	fmul.4s	v3, v1, v1
     324:      	mov.16b	v4, v28
     328:      	fmla.4s	v4, v3, v18
     32c:      	mov.16b	v5, v23
     330:      	fmla.4s	v5, v3, v4
     334:      	mov.16b	v4, v30
     338:      	fmla.4s	v4, v3, v5
     33c:      	mov.16b	v5, v9
     340:      	fmla.4s	v5, v3, v4
     344:      	mov.16b	v4, v14
     348:      	fmla.4s	v4, v3, v5
     34c:      	mov.16b	v5, v26
     350:      	fmla.4s	v5, v3, v4
     354:      	fmul.4s	v4, v2, v5
     358:      	ldr	q20, [sp, #0x240]
     35c:      	mov.16b	v5, v20
     360:      	fmla.4s	v5, v3, v25
     364:      	ldp	q25, q28, [sp, #0x160]
     368:      	mov.16b	v6, v28
     36c:      	fmla.4s	v6, v3, v5
     370:      	ldr	q5, [sp, #0x1e0]
     374:      	fmla.4s	v5, v3, v6
     378:      	mov.16b	v6, v25
     37c:      	fmla.4s	v6, v3, v5
     380:      	movi.4s	v5, #0x3f, lsl #24
     384:      	fmla.4s	v5, v3, v6
     388:      	mov.16b	v6, v26
     38c:      	fmla.4s	v6, v3, v5
     390:      	fdiv.4s	v18, v4, v6
     394:      	ldr	q24, [sp, #0x180]
     398:      	fcmge.4s	v4, v24, v2
     39c:      	and.16b	v5, v4, v2
     3a0:      	ldr	q3, [sp, #0x220]
     3a4:      	fcmge.4s	v6, v5, v3
     3a8:      	fcmge.4s	v7, v11, v5
     3ac:      	and.16b	v6, v6, v7
     3b0:      	and.16b	v6, v6, v5
     3b4:      	ldp	q13, q3, [sp, #0x1b0]
     3b8:      	fmul.4s	v7, v6, v3
     3bc:      	fadd.4s	v7, v7, v10
     3c0:      	fadd.4s	v7, v7, v31
     3c4:      	fcvtzs.4s	v7, v7
     3c8:      	scvtf.4s	v16, v7
     3cc:      	fmul.4s	v17, v16, v13
     3d0:      	fadd.4s	v6, v6, v17
     3d4:      	ldp	q15, q8, [sp, #0x190]
     3d8:      	fmul.4s	v16, v16, v8
     3dc:      	fadd.4s	v6, v6, v16
     3e0:      	ldp	q17, q16, [sp, #0x200]
     3e4:      	fmul.4s	v16, v6, v16
     3e8:      	fadd.4s	v16, v16, v17
     3ec:      	fmul.4s	v16, v6, v16
     3f0:      	ldr	q17, [sp, #0x1f0]
     3f4:      	fadd.4s	v16, v16, v17
     3f8:      	fmul.4s	v16, v6, v16
     3fc:      	fadd.4s	v16, v16, v15
     400:      	fmul.4s	v16, v6, v16
     404:      	fadd.4s	v16, v16, v14
     408:      	fmul.4s	v16, v6, v16
     40c:      	fadd.4s	v16, v16, v29
     410:      	fmul.4s	v17, v6, v6
     414:      	fmul.4s	v16, v17, v16
     418:      	fadd.4s	v6, v6, v16
     41c:      	fadd.4s	v6, v6, v26
     420:      	add.4s	v7, v7, v27
     424:      	sshr.4s	v16, v7, #0x1
     428:      	shl.4s	v17, v16, #0x17
     42c:      	add.4s	v17, v17, v26
     430:      	fmul.4s	v6, v6, v17
     434:      	sub.4s	v7, v7, v16
     438:      	shl.4s	v7, v7, #0x17
     43c:      	add.4s	v7, v7, v26
     440:      	fmul.4s	v6, v6, v7
     444:      	fcmgt.4s	v5, v5, v11
     448:      	ldr	q22, [sp, #0x150]
     44c:      	bsl.16b	v5, v22, v6
     450:      	ldp	q6, q27, [sp, #0x1d0]
     454:      	fdiv.4s	v6, v6, v5
     458:      	fsub.4s	v7, v5, v6
     45c:      	fadd.4s	v5, v5, v6
     460:      	fdiv.4s	v5, v7, v5
     464:      	bsl.16b	v4, v5, v26
     468:      	fcmge.4s	v2, v26, v2
     46c:      	bsl.16b	v2, v18, v4
     470:      	bif.16b	v2, v1, v12
     474:      	fcmeq.4s	v1, v1, v1
     478:      	fadd.4s	v2, v2, v26
     47c:      	ldr	q18, [sp, #0x140]
     480:      	bsl.16b	v1, v2, v18
     484:      	fmul.4s	v0, v0, v29
     488:      	fmul.4s	v0, v0, v1
     48c:      	ldr	q1, [sp, #0xa0]
     490:      	fadd.4s	v0, v1, v0
     494:      	mov.16b	v29, v24
     498:      	mov.16b	v10, v3
     49c:      	mov.16b	v12, v13
     4a0:      	mov.16b	v13, v8
     4a4:      	mov	w4, #0x4004             ; =16388
     4a8:      	ldr	x12, [sp, #0x60]
     4ac:      	ldr	w10, [sp, #0x5c]
     4b0:      	ldr	x11, [sp, #0x50]
     4b4:      	str	s0, [x12, x28]
     4b8:      	add	x20, x20, #0x1
     4bc:      	add	x19, x19, x4
     4c0:      	add	x27, x27, x4
     4c4:      	add	x22, x22, x4
     4c8:      	cmp	x20, #0x4
     4cc:      	b.eq	0x1c0 <ltmp0+0x1c0>
     4d0:      	add	w8, w20, w11
     4d4:      	and	x8, x8, #0x1fffffff
     4d8:      	add	x8, x8, x8, lsl #12
     4dc:      	lsl	x25, x8, #2
     4e0:      	cbz	w10, 0x9e4 <ltmp0+0x9e4>
     4e4:      	mov	x8, #0x0                ; =0
     4e8:      	ldp	q11, q15, [sp, #0xe0]
     4ec:      	ldp	q30, q13, [sp, #0x120]
     4f0:      	add	x9, x22, x8
     4f4:      	ldp	q0, q1, [x9]
     4f8:      	fmul.4s	v2, v0, v19
     4fc:      	fmul.4s	v3, v1, v19
     500:      	fmul.4s	v3, v1, v3
     504:      	fmul.4s	v2, v0, v2
     508:      	fmul.4s	v2, v0, v2
     50c:      	fmul.4s	v3, v1, v3
     510:      	fadd.4s	v4, v1, v3
     514:      	fadd.4s	v2, v0, v2
     518:      	fmul.4s	v3, v2, v21
     51c:      	fmul.4s	v2, v4, v21
     520:      	fabs.4s	v5, v2
     524:      	fabs.4s	v4, v3
     528:      	mov.16b	v12, v19
     52c:      	fmul.4s	v19, v3, v3
     530:      	mov.16b	v9, v21
     534:      	fmul.4s	v21, v2, v2
     538:      	mov.16b	v6, v30
     53c:      	fmla.4s	v6, v19, v13
     540:      	mov.16b	v7, v30
     544:      	fmla.4s	v7, v21, v13
     548:      	mov.16b	v16, v23
     54c:      	fmla.4s	v16, v19, v6
     550:      	mov.16b	v6, v23
     554:      	fmla.4s	v6, v21, v7
     558:      	ldp	q18, q17, [sp, #0x100]
     55c:      	mov.16b	v7, v17
     560:      	fmla.4s	v7, v19, v16
     564:      	mov.16b	v16, v17
     568:      	fmla.4s	v16, v21, v6
     56c:      	mov.16b	v17, v18
     570:      	mov.16b	v22, v15
     574:      	mov.16b	v14, v23
     578:      	mov.16b	v23, v15
     57c:      	mov.16b	v6, v26
     580:      	fmla.4s	v17, v19, v7
     584:      	mov.16b	v7, v20
     588:      	ldp	q24, q20, [sp, #0x230]
     58c:      	fmla.4s	v7, v21, v24
     590:      	fmla.4s	v20, v19, v24
     594:      	mov.16b	v24, v28
     598:      	fmla.4s	v18, v21, v16
     59c:      	fmla.4s	v24, v21, v7
     5a0:      	fmla.4s	v28, v19, v20
     5a4:      	mov.16b	v16, v27
     5a8:      	fmla.4s	v16, v21, v24
     5ac:      	fmla.4s	v22, v19, v17
     5b0:      	fmla.4s	v27, v19, v28
     5b4:      	mov.16b	v20, v25
     5b8:      	fmla.4s	v20, v21, v16
     5bc:      	mov.16b	v24, v25
     5c0:      	fmla.4s	v23, v21, v18
     5c4:      	fmla.4s	v24, v19, v27
     5c8:      	movi.4s	v25, #0x3f, lsl #24
     5cc:      	movi.4s	v26, #0x3f, lsl #24
     5d0:      	ldr	q17, [sp, #0x250]
     5d4:      	fcmge.4s	v7, v29, v4
     5d8:      	fmla.4s	v25, v21, v20
     5dc:      	fcmge.4s	v16, v29, v5
     5e0:      	and.16b	v18, v16, v5
     5e4:      	and.16b	v20, v7, v4
     5e8:      	ldr	q28, [sp, #0x220]
     5ec:      	fcmge.4s	v27, v20, v28
     5f0:      	fcmge.4s	v28, v18, v28
     5f4:      	fcmge.4s	v29, v11, v18
     5f8:      	and.16b	v28, v28, v29
     5fc:      	fcmge.4s	v29, v11, v20
     600:      	and.16b	v27, v27, v29
     604:      	and.16b	v27, v27, v20
     608:      	and.16b	v28, v28, v18
     60c:      	fmla.4s	v6, v21, v23
     610:      	ldp	q8, q29, [sp, #0x1b0]
     614:      	fmul.4s	v23, v28, v29
     618:      	fmul.4s	v29, v27, v29
     61c:      	movi.4s	v31, #0x4b, lsl #24
     620:      	fadd.4s	v29, v29, v31
     624:      	fadd.4s	v23, v23, v31
     628:      	movi.4s	v31, #0xcb, lsl #24
     62c:      	fadd.4s	v23, v23, v31
     630:      	fmla.4s	v17, v21, v25
     634:      	fadd.4s	v21, v29, v31
     638:      	fcvtzs.4s	v21, v21
     63c:      	fcvtzs.4s	v23, v23
     640:      	scvtf.4s	v25, v23
     644:      	scvtf.4s	v29, v21
     648:      	fmla.4s	v26, v19, v24
     64c:      	fmul.4s	v24, v25, v8
     650:      	fadd.4s	v24, v28, v24
     654:      	fmul.4s	v28, v29, v8
     658:      	fadd.4s	v27, v27, v28
     65c:      	ldr	q28, [sp, #0x250]
     660:      	fmla.4s	v28, v19, v22
     664:      	ldr	q8, [sp, #0x1a0]
     668:      	fmul.4s	v22, v29, v8
     66c:      	fadd.4s	v22, v27, v22
     670:      	fmul.4s	v25, v25, v8
     674:      	fadd.4s	v24, v24, v25
     678:      	ldr	q25, [sp, #0x250]
     67c:      	fmla.4s	v25, v19, v26
     680:      	ldp	q27, q26, [sp, #0x200]
     684:      	fmul.4s	v19, v24, v26
     688:      	fmul.4s	v26, v22, v26
     68c:      	fadd.4s	v26, v26, v27
     690:      	fadd.4s	v19, v19, v27
     694:      	fmul.4s	v19, v24, v19
     698:      	fmul.4s	v27, v4, v28
     69c:      	fmul.4s	v26, v22, v26
     6a0:      	ldr	q28, [sp, #0x1f0]
     6a4:      	fadd.4s	v26, v26, v28
     6a8:      	fadd.4s	v19, v19, v28
     6ac:      	fmul.4s	v19, v24, v19
     6b0:      	fmul.4s	v26, v22, v26
     6b4:      	ldr	q28, [sp, #0x190]
     6b8:      	fadd.4s	v26, v26, v28
     6bc:      	fadd.4s	v19, v19, v28
     6c0:      	fmul.4s	v19, v24, v19
     6c4:      	fmul.4s	v26, v22, v26
     6c8:      	fadd.4s	v26, v26, v15
     6cc:      	fadd.4s	v28, v19, v15
     6d0:      	fdiv.4s	v19, v27, v25
     6d4:      	fmul.4s	v25, v24, v28
     6d8:      	fmul.4s	v26, v22, v26
     6dc:      	movi.4s	v8, #0x3f, lsl #24
     6e0:      	fadd.4s	v26, v26, v8
     6e4:      	fadd.4s	v25, v25, v8
     6e8:      	fmul.4s	v27, v24, v24
     6ec:      	fmul.4s	v25, v27, v25
     6f0:      	fmul.4s	v27, v22, v22
     6f4:      	fmul.4s	v26, v27, v26
     6f8:      	ldr	q27, [sp, #0x1e0]
     6fc:      	fadd.4s	v22, v22, v26
     700:      	fadd.4s	v24, v24, v25
     704:      	movi.2d	v10, #0xffffffffffffffff
     708:      	add.4s	v21, v21, v10
     70c:      	ldr	q25, [sp, #0x250]
     710:      	fadd.4s	v22, v22, v25
     714:      	sshr.4s	v25, v21, #0x1
     718:      	shl.4s	v26, v25, #0x17
     71c:      	ldr	q29, [sp, #0x250]
     720:      	add.4s	v26, v26, v29
     724:      	ldp	q28, q29, [sp, #0x170]
     728:      	fmul.4s	v22, v22, v26
     72c:      	ldr	q26, [sp, #0x250]
     730:      	movi.2d	v31, #0xffffffffffffffff
     734:      	add.4s	v23, v23, v10
     738:      	fadd.4s	v24, v24, v26
     73c:      	sub.4s	v21, v21, v25
     740:      	sshr.4s	v25, v23, #0x1
     744:      	sub.4s	v23, v23, v25
     748:      	shl.4s	v25, v25, #0x17
     74c:      	add.4s	v25, v25, v26
     750:      	fmul.4s	v24, v24, v25
     754:      	shl.4s	v23, v23, #0x17
     758:      	add.4s	v23, v23, v26
     75c:      	fmul.4s	v23, v24, v23
     760:      	mvni.4s	v24, #0x80, lsl #24
     764:      	shl.4s	v21, v21, #0x17
     768:      	add.4s	v21, v21, v26
     76c:      	fmul.4s	v21, v22, v21
     770:      	ldp	q22, q25, [sp, #0x150]
     774:      	fcmgt.4s	v20, v20, v11
     778:      	bsl.16b	v20, v22, v21
     77c:      	fmul.4s	v6, v5, v6
     780:      	fcmgt.4s	v18, v18, v11
     784:      	bsl.16b	v18, v22, v23
     788:      	mov.16b	v23, v14
     78c:      	fdiv.4s	v6, v6, v17
     790:      	ldr	q14, [sp, #0x1d0]
     794:      	fdiv.4s	v17, v14, v18
     798:      	fsub.4s	v21, v18, v17
     79c:      	fadd.4s	v17, v18, v17
     7a0:      	ldr	q18, [sp, #0x140]
     7a4:      	fdiv.4s	v17, v21, v17
     7a8:      	mov.16b	v21, v9
     7ac:      	bsl.16b	v16, v17, v26
     7b0:      	fcmge.4s	v5, v26, v5
     7b4:      	bsl.16b	v5, v6, v16
     7b8:      	fdiv.4s	v6, v14, v20
     7bc:      	fsub.4s	v16, v20, v6
     7c0:      	fadd.4s	v6, v20, v6
     7c4:      	ldr	q20, [sp, #0x240]
     7c8:      	fdiv.4s	v6, v16, v6
     7cc:      	bif.16b	v6, v26, v7
     7d0:      	fcmge.4s	v4, v26, v4
     7d4:      	bsl.16b	v4, v19, v6
     7d8:      	mov.16b	v19, v12
     7dc:      	bif.16b	v4, v3, v24
     7e0:      	fcmeq.4s	v3, v3, v3
     7e4:      	fadd.4s	v4, v4, v26
     7e8:      	bsl.16b	v3, v4, v18
     7ec:      	mov.16b	v4, v24
     7f0:      	bsl.16b	v4, v5, v2
     7f4:      	fcmeq.4s	v2, v2, v2
     7f8:      	fadd.4s	v4, v4, v26
     7fc:      	bsl.16b	v2, v4, v18
     800:      	fmul.4s	v1, v1, v8
     804:      	fmul.4s	v1, v1, v2
     808:      	fmul.4s	v0, v0, v8
     80c:      	fmul.4s	v0, v0, v3
     810:      	add	x9, x27, x8
     814:      	ldp	q3, q2, [x9]
     818:      	fadd.4s	v0, v3, v0
     81c:      	fadd.4s	v1, v2, v1
     820:      	add	x9, x19, x8
     824:      	stp	q0, q1, [x9]
     828:      	add	x8, x8, #0x20
     82c:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     830:      	b.ne	0x4f0 <ltmp0+0x4f0>
     834:      	add	x28, x25, #0x4, lsl #12 ; =0x4000
     838:      	ldr	x8, [sp, #0x90]
     83c:      	ldr	s0, [x8, x28]
     840:      	fmov	s1, w1
     844:      	fmul.4s	v1, v0, v1
     848:      	fmul.4s	v1, v0, v1
     84c:      	fmul.4s	v1, v0, v1
     850:      	fadd.4s	v1, v0, v1
     854:      	fmov	s2, w3
     858:      	fmul.4s	v2, v1, v2
     85c:      	movi.2d	v1, #0000000000000000
     860:      	mov.s	v1[0], v2[0]
     864:      	fabs.4s	v2, v1
     868:      	fmul.4s	v3, v1, v1
     86c:      	fmla.4s	v30, v3, v13
     870:      	mov.16b	v5, v23
     874:      	fmla.4s	v5, v3, v30
     878:      	ldp	q9, q8, [sp, #0x100]
     87c:      	mov.16b	v4, v8
     880:      	fmla.4s	v4, v3, v5
     884:      	mov.16b	v5, v9
     888:      	fmla.4s	v5, v3, v4
     88c:      	mov.16b	v4, v15
     890:      	fmla.4s	v4, v3, v5
     894:      	mov.16b	v5, v26
     898:      	fmla.4s	v5, v3, v4
     89c:      	fmul.4s	v4, v2, v5
     8a0:      	mov.16b	v5, v20
     8a4:      	ldr	q6, [sp, #0x230]
     8a8:      	fmla.4s	v5, v3, v6
     8ac:      	mov.16b	v6, v28
     8b0:      	fmla.4s	v6, v3, v5
     8b4:      	mov.16b	v5, v27
     8b8:      	fmla.4s	v5, v3, v6
     8bc:      	mov.16b	v6, v25
     8c0:      	fmla.4s	v6, v3, v5
     8c4:      	movi.4s	v5, #0x3f, lsl #24
     8c8:      	fmla.4s	v5, v3, v6
     8cc:      	mov.16b	v6, v26
     8d0:      	fmla.4s	v6, v3, v5
     8d4:      	fdiv.4s	v3, v4, v6
     8d8:      	fcmge.4s	v4, v29, v2
     8dc:      	and.16b	v5, v4, v2
     8e0:      	ldr	q6, [sp, #0x220]
     8e4:      	fcmge.4s	v6, v5, v6
     8e8:      	fcmge.4s	v7, v11, v5
     8ec:      	and.16b	v6, v6, v7
     8f0:      	and.16b	v6, v6, v5
     8f4:      	ldp	q12, q10, [sp, #0x1b0]
     8f8:      	fmul.4s	v7, v6, v10
     8fc:      	movi.4s	v16, #0x4b, lsl #24
     900:      	fadd.4s	v7, v7, v16
     904:      	movi.4s	v16, #0xcb, lsl #24
     908:      	fadd.4s	v7, v7, v16
     90c:      	fcvtzs.4s	v7, v7
     910:      	scvtf.4s	v16, v7
     914:      	fmul.4s	v17, v16, v12
     918:      	fadd.4s	v6, v6, v17
     91c:      	ldp	q30, q13, [sp, #0x190]
     920:      	fmul.4s	v16, v16, v13
     924:      	fadd.4s	v6, v6, v16
     928:      	ldp	q17, q16, [sp, #0x200]
     92c:      	fmul.4s	v16, v6, v16
     930:      	fadd.4s	v16, v16, v17
     934:      	fmul.4s	v16, v6, v16
     938:      	ldr	q17, [sp, #0x1f0]
     93c:      	fadd.4s	v16, v16, v17
     940:      	fmul.4s	v16, v6, v16
     944:      	fadd.4s	v16, v16, v30
     948:      	fmul.4s	v16, v6, v16
     94c:      	fadd.4s	v16, v16, v15
     950:      	fmul.4s	v16, v6, v16
     954:      	movi.4s	v14, #0x3f, lsl #24
     958:      	fadd.4s	v16, v16, v14
     95c:      	fmul.4s	v17, v6, v6
     960:      	fmul.4s	v16, v17, v16
     964:      	fadd.4s	v6, v6, v16
     968:      	fadd.4s	v6, v6, v26
     96c:      	add.4s	v7, v7, v31
     970:      	sshr.4s	v16, v7, #0x1
     974:      	shl.4s	v17, v16, #0x17
     978:      	add.4s	v17, v17, v26
     97c:      	fmul.4s	v6, v6, v17
     980:      	sub.4s	v7, v7, v16
     984:      	shl.4s	v7, v7, #0x17
     988:      	add.4s	v7, v7, v26
     98c:      	fmul.4s	v6, v6, v7
     990:      	fcmgt.4s	v5, v5, v11
     994:      	bsl.16b	v5, v22, v6
     998:      	ldr	q6, [sp, #0x1d0]
     99c:      	fdiv.4s	v6, v6, v5
     9a0:      	fsub.4s	v7, v5, v6
     9a4:      	fadd.4s	v5, v5, v6
     9a8:      	fdiv.4s	v5, v7, v5
     9ac:      	bsl.16b	v4, v5, v26
     9b0:      	fcmge.4s	v2, v26, v2
     9b4:      	bsl.16b	v2, v3, v4
     9b8:      	bif.16b	v2, v1, v24
     9bc:      	fcmeq.4s	v1, v1, v1
     9c0:      	fadd.4s	v2, v2, v26
     9c4:      	bsl.16b	v1, v2, v18
     9c8:      	fmul.4s	v0, v0, v14
     9cc:      	fmul.4s	v0, v0, v1
     9d0:      	ldr	s1, [x21, x28]
     9d4:      	fadd.4s	v0, v1, v0
     9d8:      	mov.16b	v15, v30
     9dc:      	mov.16b	v30, v8
     9e0:      	b	0x4b4 <ltmp0+0x4b4>
     9e4:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     9e8:      	add	x0, x0, #0x3f0
     9ec:      	ldr	x26, [sp, #0x90]
     9f0:      	add	x1, x26, x25
     9f4:      	mov	w2, #0x4000             ; =16384
     9f8:      	bl	0x9f8 <ltmp0+0x9f8>
     9fc:      	add	x28, x25, #0x4, lsl #12 ; =0x4000
     a00:      	ldr	s1, [x26, x28]
     a04:      	ldr	q0, [sp, #0x80]
     a08:      	mov.s	v0[0], v1[0]
     a0c:      	str	q0, [sp, #0x8400]
     a10:      	stp	q1, q0, [sp, #0x70]
     a14:      	str	q0, [sp, #0x83f0]
     a18:      	add	x0, sp, #0x3d0
     a1c:      	add	x1, x21, x25
     a20:      	mov	w2, #0x4000             ; =16384
     a24:      	bl	0xa24 <ltmp0+0xa24>
     a28:      	ldr	q26, [sp, #0x250]
     a2c:      	ldr	q25, [sp, #0x230]
     a30:      	ldp	q14, q9, [sp, #0xf0]
     a34:      	ldp	q30, q28, [sp, #0x110]
     a38:      	ldp	q19, q23, [sp, #0xc0]
     a3c:      	ldr	q18, [sp, #0x130]
     a40:      	ldp	q0, q21, [sp, #0xa0]
     a44:      	mov	x8, #0x0                ; =0
     a48:      	add	x9, x21, x28
     a4c:      	ld1.s	{ v0 }[0], [x9]
     a50:      	str	q0, [sp, #0x43e0]
     a54:      	str	q0, [sp, #0xa0]
     a58:      	str	q0, [sp, #0x43d0]
     a5c:      	ldr	q11, [sp, #0xe0]
     a60:      	add	x9, x23, x8
     a64:      	ldp	q0, q1, [x9]
     a68:      	fmul.4s	v2, v0, v19
     a6c:      	fmul.4s	v3, v1, v19
     a70:      	fmul.4s	v3, v1, v3
     a74:      	fmul.4s	v2, v0, v2
     a78:      	fmul.4s	v2, v0, v2
     a7c:      	fmul.4s	v3, v1, v3
     a80:      	fadd.4s	v4, v1, v3
     a84:      	fadd.4s	v2, v0, v2
     a88:      	fmul.4s	v3, v2, v21
     a8c:      	fmul.4s	v2, v4, v21
     a90:      	fabs.4s	v5, v2
     a94:      	fabs.4s	v4, v3
     a98:      	mov.16b	v12, v19
     a9c:      	fmul.4s	v19, v3, v3
     aa0:      	mov.16b	v13, v21
     aa4:      	fmul.4s	v21, v2, v2
     aa8:      	mov.16b	v6, v28
     aac:      	fmla.4s	v6, v19, v18
     ab0:      	mov.16b	v7, v28
     ab4:      	fmla.4s	v7, v21, v18
     ab8:      	mov.16b	v16, v23
     abc:      	fmla.4s	v16, v19, v6
     ac0:      	mov.16b	v6, v23
     ac4:      	fmla.4s	v6, v21, v7
     ac8:      	mov.16b	v7, v30
     acc:      	fmla.4s	v7, v19, v16
     ad0:      	mov.16b	v16, v30
     ad4:      	fmla.4s	v16, v21, v6
     ad8:      	mov.16b	v17, v9
     adc:      	mov.16b	v18, v9
     ae0:      	mov.16b	v22, v14
     ae4:      	mov.16b	v15, v9
     ae8:      	mov.16b	v9, v30
     aec:      	mov.16b	v30, v23
     af0:      	mov.16b	v23, v14
     af4:      	mov.16b	v6, v26
     af8:      	fmla.4s	v17, v19, v7
     afc:      	ldr	q20, [sp, #0x240]
     b00:      	mov.16b	v7, v20
     b04:      	fmla.4s	v7, v21, v25
     b08:      	fmla.4s	v20, v19, v25
     b0c:      	ldr	q25, [sp, #0x170]
     b10:      	mov.16b	v24, v25
     b14:      	fmla.4s	v18, v21, v16
     b18:      	fmla.4s	v24, v21, v7
     b1c:      	mov.16b	v7, v25
     b20:      	fmla.4s	v7, v19, v20
     b24:      	ldr	q20, [sp, #0x1e0]
     b28:      	mov.16b	v16, v20
     b2c:      	fmla.4s	v16, v21, v24
     b30:      	fmla.4s	v22, v19, v17
     b34:      	mov.16b	v17, v20
     b38:      	fmla.4s	v17, v19, v7
     b3c:      	ldr	q24, [sp, #0x160]
     b40:      	mov.16b	v20, v24
     b44:      	fmla.4s	v20, v21, v16
     b48:      	fmla.4s	v23, v21, v18
     b4c:      	fmla.4s	v24, v19, v17
     b50:      	movi.4s	v25, #0x3f, lsl #24
     b54:      	movi.4s	v26, #0x3f, lsl #24
     b58:      	ldr	q17, [sp, #0x250]
     b5c:      	ldr	q16, [sp, #0x180]
     b60:      	fcmge.4s	v7, v16, v4
     b64:      	fmla.4s	v25, v21, v20
     b68:      	fcmge.4s	v16, v16, v5
     b6c:      	and.16b	v18, v16, v5
     b70:      	and.16b	v20, v7, v4
     b74:      	ldr	q28, [sp, #0x220]
     b78:      	fcmge.4s	v27, v20, v28
     b7c:      	fcmge.4s	v28, v18, v28
     b80:      	fcmge.4s	v29, v11, v18
     b84:      	and.16b	v28, v28, v29
     b88:      	fcmge.4s	v29, v11, v20
     b8c:      	and.16b	v27, v27, v29
     b90:      	and.16b	v27, v27, v20
     b94:      	and.16b	v28, v28, v18
     b98:      	fmla.4s	v6, v21, v23
     b9c:      	ldr	q29, [sp, #0x1c0]
     ba0:      	fmul.4s	v23, v28, v29
     ba4:      	fmul.4s	v29, v27, v29
     ba8:      	movi.4s	v8, #0x4b, lsl #24
     bac:      	fadd.4s	v29, v29, v8
     bb0:      	movi.4s	v10, #0x4b, lsl #24
     bb4:      	fadd.4s	v23, v23, v8
     bb8:      	movi.4s	v8, #0xcb, lsl #24
     bbc:      	fadd.4s	v23, v23, v8
     bc0:      	fmla.4s	v17, v21, v25
     bc4:      	movi.4s	v31, #0xcb, lsl #24
     bc8:      	fadd.4s	v21, v29, v8
     bcc:      	fcvtzs.4s	v21, v21
     bd0:      	fcvtzs.4s	v23, v23
     bd4:      	scvtf.4s	v25, v23
     bd8:      	scvtf.4s	v29, v21
     bdc:      	fmla.4s	v26, v19, v24
     be0:      	ldr	q8, [sp, #0x1b0]
     be4:      	fmul.4s	v24, v25, v8
     be8:      	fadd.4s	v24, v28, v24
     bec:      	fmul.4s	v28, v29, v8
     bf0:      	fadd.4s	v27, v27, v28
     bf4:      	ldr	q28, [sp, #0x250]
     bf8:      	fmla.4s	v28, v19, v22
     bfc:      	ldr	q8, [sp, #0x1a0]
     c00:      	fmul.4s	v22, v29, v8
     c04:      	movi.4s	v29, #0x3f, lsl #24
     c08:      	fadd.4s	v22, v27, v22
     c0c:      	fmul.4s	v25, v25, v8
     c10:      	fadd.4s	v24, v24, v25
     c14:      	ldr	q25, [sp, #0x250]
     c18:      	fmla.4s	v25, v19, v26
     c1c:      	ldp	q27, q26, [sp, #0x200]
     c20:      	fmul.4s	v19, v24, v26
     c24:      	fmul.4s	v26, v22, v26
     c28:      	fadd.4s	v26, v26, v27
     c2c:      	fadd.4s	v19, v19, v27
     c30:      	fmul.4s	v19, v24, v19
     c34:      	fmul.4s	v27, v4, v28
     c38:      	fmul.4s	v26, v22, v26
     c3c:      	ldr	q28, [sp, #0x1f0]
     c40:      	fadd.4s	v26, v26, v28
     c44:      	fadd.4s	v19, v19, v28
     c48:      	fmul.4s	v19, v24, v19
     c4c:      	fmul.4s	v26, v22, v26
     c50:      	ldr	q28, [sp, #0x190]
     c54:      	fadd.4s	v26, v26, v28
     c58:      	fadd.4s	v19, v19, v28
     c5c:      	fmul.4s	v19, v24, v19
     c60:      	fmul.4s	v26, v22, v26
     c64:      	fadd.4s	v26, v26, v14
     c68:      	fadd.4s	v28, v19, v14
     c6c:      	fdiv.4s	v19, v27, v25
     c70:      	fmul.4s	v25, v24, v28
     c74:      	ldr	q28, [sp, #0x120]
     c78:      	fmul.4s	v26, v22, v26
     c7c:      	fadd.4s	v26, v26, v29
     c80:      	fadd.4s	v25, v25, v29
     c84:      	fmul.4s	v27, v24, v24
     c88:      	fmul.4s	v25, v27, v25
     c8c:      	fmul.4s	v27, v22, v22
     c90:      	fmul.4s	v26, v27, v26
     c94:      	fadd.4s	v22, v22, v26
     c98:      	fadd.4s	v24, v24, v25
     c9c:      	movi.2d	v8, #0xffffffffffffffff
     ca0:      	add.4s	v21, v21, v8
     ca4:      	ldr	q25, [sp, #0x250]
     ca8:      	fadd.4s	v22, v22, v25
     cac:      	sshr.4s	v25, v21, #0x1
     cb0:      	shl.4s	v26, v25, #0x17
     cb4:      	ldr	q27, [sp, #0x250]
     cb8:      	add.4s	v26, v26, v27
     cbc:      	fmul.4s	v22, v22, v26
     cc0:      	ldr	q26, [sp, #0x250]
     cc4:      	movi.2d	v27, #0xffffffffffffffff
     cc8:      	add.4s	v23, v23, v8
     ccc:      	fadd.4s	v24, v24, v26
     cd0:      	sub.4s	v21, v21, v25
     cd4:      	sshr.4s	v25, v23, #0x1
     cd8:      	sub.4s	v23, v23, v25
     cdc:      	shl.4s	v25, v25, #0x17
     ce0:      	add.4s	v25, v25, v26
     ce4:      	fmul.4s	v24, v24, v25
     ce8:      	ldr	q25, [sp, #0x230]
     cec:      	shl.4s	v23, v23, #0x17
     cf0:      	add.4s	v23, v23, v26
     cf4:      	fmul.4s	v23, v24, v23
     cf8:      	shl.4s	v21, v21, #0x17
     cfc:      	add.4s	v21, v21, v26
     d00:      	fmul.4s	v21, v22, v21
     d04:      	fcmgt.4s	v20, v20, v11
     d08:      	ldr	q22, [sp, #0x150]
     d0c:      	bsl.16b	v20, v22, v21
     d10:      	fmul.4s	v6, v5, v6
     d14:      	fcmgt.4s	v18, v18, v11
     d18:      	bsl.16b	v18, v22, v23
     d1c:      	mov.16b	v23, v30
     d20:      	mov.16b	v30, v9
     d24:      	mov.16b	v9, v15
     d28:      	fdiv.4s	v6, v6, v17
     d2c:      	ldr	q22, [sp, #0x1d0]
     d30:      	fdiv.4s	v17, v22, v18
     d34:      	fsub.4s	v21, v18, v17
     d38:      	fadd.4s	v17, v18, v17
     d3c:      	fdiv.4s	v17, v21, v17
     d40:      	mov.16b	v21, v13
     d44:      	bsl.16b	v16, v17, v26
     d48:      	fcmge.4s	v5, v26, v5
     d4c:      	bsl.16b	v5, v6, v16
     d50:      	fdiv.4s	v6, v22, v20
     d54:      	fsub.4s	v16, v20, v6
     d58:      	fadd.4s	v6, v20, v6
     d5c:      	fdiv.4s	v6, v16, v6
     d60:      	bif.16b	v6, v26, v7
     d64:      	fcmge.4s	v4, v26, v4
     d68:      	bsl.16b	v4, v19, v6
     d6c:      	mov.16b	v19, v12
     d70:      	mvni.4s	v7, #0x80, lsl #24
     d74:      	bif.16b	v4, v3, v7
     d78:      	fcmeq.4s	v3, v3, v3
     d7c:      	fadd.4s	v4, v4, v26
     d80:      	ldp	q18, q6, [sp, #0x130]
     d84:      	bsl.16b	v3, v4, v6
     d88:      	mvni.4s	v12, #0x80, lsl #24
     d8c:      	mov.16b	v4, v7
     d90:      	bsl.16b	v4, v5, v2
     d94:      	fcmeq.4s	v2, v2, v2
     d98:      	fadd.4s	v4, v4, v26
     d9c:      	bsl.16b	v2, v4, v6
     da0:      	fmul.4s	v1, v1, v29
     da4:      	fmul.4s	v1, v1, v2
     da8:      	fmul.4s	v0, v0, v29
     dac:      	fmul.4s	v0, v0, v3
     db0:      	add	x9, x24, x8
     db4:      	ldp	q3, q2, [x9]
     db8:      	fadd.4s	v0, v3, v0
     dbc:      	fadd.4s	v1, v2, v1
     dc0:      	add	x9, x19, x8
     dc4:      	stp	q0, q1, [x9]
     dc8:      	add	x8, x8, #0x20
     dcc:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     dd0:      	b.ne	0xa60 <ltmp0+0xa60>
     dd4:      	b	0x2dc <ltmp0+0x2dc>
     dd8:      	lsr	x12, x8, #3
     ddc:      	str	x8, [sp, #0x20]
     de0:      	cmp	x8, #0x8
     de4:      	b.hs	0x1488 <ltmp0+0x1488>
     de8:      	ldr	x8, [sp, #0x20]
     dec:      	and	w8, w8, #0x7
     df0:      	cbz	w8, 0x1c0 <ltmp0+0x1c0>
     df4:      	dup.4s	v0, w8
     df8:      	adrp	x8, 0x0 <ltmp0>
     dfc:      	ldr	q2, [x8]
     e00:      	adrp	x8, 0x0 <ltmp0>
     e04:      	ldr	q1, [x8]
     e08:      	cmhi.4s	v1, v0, v1
     e0c:      	cmhi.4s	v0, v0, v2
     e10:      	uzp1.8h	v19, v0, v1
     e14:      	umaxv.8h	h2, v19
     e18:      	fmov	w8, s2
     e1c:      	tbz	w8, #0x0, 0x1bc <ltmp0+0x1bc>
     e20:      	ldr	x8, [sp, #0x18]
     e24:      	ldr	x11, [x8]
     e28:      	ldr	x9, [x8, #0x10]
     e2c:      	ldr	x8, [x8, #0x30]
     e30:      	sshll.2d	v5, v0, #0x0
     e34:      	sshll.2d	v3, v1, #0x0
     e38:      	sshll2.2d	v24, v0, #0x0
     e3c:      	sshll2.2d	v23, v1, #0x0
     e40:      	adrp	x10, 0x0 <ltmp0>
     e44:      	ldr	q2, [x10]
     e48:      	and.16b	v2, v23, v2
     e4c:      	adrp	x10, 0x0 <ltmp0>
     e50:      	ldr	q4, [x10]
     e54:      	and.16b	v4, v24, v4
     e58:      	adrp	x10, 0x0 <ltmp0>
     e5c:      	ldr	q6, [x10]
     e60:      	and.16b	v3, v3, v6
     e64:      	adrp	x10, 0x0 <ltmp0>
     e68:      	ldr	q6, [x10]
     e6c:      	and.16b	v21, v5, v6
     e70:      	ldr	x10, [sp, #0x48]
     e74:      	ubfiz	w10, w10, #2, #27
     e78:      	orr	w10, w10, w12
     e7c:      	dup.4s	v5, w10
     e80:      	and.16b	v6, v0, v5
     e84:      	and.16b	v5, v1, v5
     e88:      	ushll2.2d	v7, v5, #0x0
     e8c:      	ushll2.2d	v16, v6, #0x0
     e90:      	ushll.2d	v18, v5, #0x0
     e94:      	ushll.2d	v5, v6, #0x0
     e98:      	subs	x10, x11, x8
     e9c:      	mov	w14, #0xfff             ; =4095
     ea0:      	movk	w14, #0x100, lsl #16
     ea4:      	ccmp	x10, x14, #0x0, hs
     ea8:      	cset	w10, hi
     eac:      	subs	x12, x8, x11
     eb0:      	ccmp	x12, x14, #0x0, hs
     eb4:      	csinc	w12, w10, wzr, ls
     eb8:      	subs	x10, x9, x8
     ebc:      	ccmp	x10, x14, #0x0, hs
     ec0:      	cset	w10, hi
     ec4:      	subs	x13, x8, x9
     ec8:      	ccmp	x13, x14, #0x0, hs
     ecc:      	csinc	w10, w10, wzr, ls
     ed0:      	xtn.2s	v28, v5
     ed4:      	fmov	x13, d5
     ed8:      	add	x13, x13, x13, lsl #12
     edc:      	lsl	x14, x13, #2
     ee0:      	xtn.2s	v7, v7
     ee4:      	xtn.2s	v27, v18
     ee8:      	mov	w13, #0x1001            ; =4097
     eec:      	dup.2s	v6, w13
     ef0:      	xtn.2s	v16, v16
     ef4:      	cmp	w12, #0x1
     ef8:      	adrp	x0, 0x0 <ltmp0>
     efc:      	b.ne	0x1ffc <ltmp0+0x1ffc>
     f00:      	cbz	w10, 0x1ffc <ltmp0+0x1ffc>
     f04:      	str	d28, [sp, #0x60]
     f08:      	str	d16, [sp, #0x70]
     f0c:      	str	d27, [sp, #0x80]
     f10:      	str	d7, [sp, #0x90]
     f14:      	str	q2, [sp, #0xa0]
     f18:      	mov.16b	v14, v9
     f1c:      	movi.2d	v2, #0xffffffffffffffff
     f20:      	mov	x10, #0x0               ; =0
     f24:      	add	x12, x8, x14
     f28:      	add	x13, x9, x14
     f2c:      	add	x14, x11, x14
     f30:      	b	0xf40 <ltmp0+0xf40>
     f34:      	add	x10, x10, #0x20
     f38:      	cmp	x10, #0x4, lsl #12      ; =0x4000
     f3c:      	b.eq	0x2cd8 <ltmp0+0x2cd8>
     f40:      	ldr	q18, [x0]
     f44:      	and.16b	v18, v19, v18
     f48:      	addv.8h	h20, v18
     f4c:      	fmov	w16, s20
     f50:      	add	x15, x14, x10
     f54:      	movi.2d	v22, #0000000000000000
     f58:      	movi.2d	v18, #0000000000000000
     f5c:      	tbz	w16, #0x0, 0xff8 <ltmp0+0xff8>
     f60:      	ldr	s22, [x15]
     f64:      	and	w16, w16, #0xff
     f68:      	ldr	q28, [sp, #0x120]
     f6c:      	tbnz	w16, #0x1, 0x1004 <ltmp0+0x1004>
     f70:      	tbz	w16, #0x2, 0x1010 <ltmp0+0x1010>
     f74:      	add	x17, x15, #0x8
     f78:      	ld1.s	{ v22 }[2], [x17]
     f7c:      	tbnz	w16, #0x3, 0x1014 <ltmp0+0x1014>
     f80:      	tbz	w16, #0x4, 0x1020 <ltmp0+0x1020>
     f84:      	add	x17, x15, #0x10
     f88:      	ld1.s	{ v18 }[0], [x17]
     f8c:      	tbnz	w16, #0x5, 0x1024 <ltmp0+0x1024>
     f90:      	tbz	w16, #0x6, 0x1030 <ltmp0+0x1030>
     f94:      	add	x17, x15, #0x18
     f98:      	ld1.s	{ v18 }[2], [x17]
     f9c:      	mvni.4s	v16, #0x80, lsl #24
     fa0:      	tbnz	w16, #0x7, 0x1038 <ltmp0+0x1038>
     fa4:      	fmov	w16, s20
     fa8:      	add	x15, x13, x10
     fac:      	movi.2d	v24, #0000000000000000
     fb0:      	movi.2d	v23, #0000000000000000
     fb4:      	tbz	w16, #0x0, 0x1054 <ltmp0+0x1054>
     fb8:      	ldr	s24, [x15]
     fbc:      	and	w16, w16, #0xff
     fc0:      	tbnz	w16, #0x1, 0x105c <ltmp0+0x105c>
     fc4:      	tbz	w16, #0x2, 0x1068 <ltmp0+0x1068>
     fc8:      	add	x17, x15, #0x8
     fcc:      	ld1.s	{ v24 }[2], [x17]
     fd0:      	tbnz	w16, #0x3, 0x106c <ltmp0+0x106c>
     fd4:      	tbz	w16, #0x4, 0x1078 <ltmp0+0x1078>
     fd8:      	add	x17, x15, #0x10
     fdc:      	ld1.s	{ v23 }[0], [x17]
     fe0:      	tbnz	w16, #0x5, 0x107c <ltmp0+0x107c>
     fe4:      	tbz	w16, #0x6, 0x1088 <ltmp0+0x1088>
     fe8:      	add	x17, x15, #0x18
     fec:      	ld1.s	{ v23 }[2], [x17]
     ff0:      	tbnz	w16, #0x7, 0x108c <ltmp0+0x108c>
     ff4:      	b	0x1094 <ltmp0+0x1094>
     ff8:      	and	w16, w16, #0xff
     ffc:      	ldr	q28, [sp, #0x120]
    1000:      	tbz	w16, #0x1, 0xf70 <ltmp0+0xf70>
    1004:      	add	x17, x15, #0x4
    1008:      	ld1.s	{ v22 }[1], [x17]
    100c:      	tbnz	w16, #0x2, 0xf74 <ltmp0+0xf74>
    1010:      	tbz	w16, #0x3, 0xf80 <ltmp0+0xf80>
    1014:      	add	x17, x15, #0xc
    1018:      	ld1.s	{ v22 }[3], [x17]
    101c:      	tbnz	w16, #0x4, 0xf84 <ltmp0+0xf84>
    1020:      	tbz	w16, #0x5, 0xf90 <ltmp0+0xf90>
    1024:      	add	x17, x15, #0x14
    1028:      	ld1.s	{ v18 }[1], [x17]
    102c:      	tbnz	w16, #0x6, 0xf94 <ltmp0+0xf94>
    1030:      	mvni.4s	v16, #0x80, lsl #24
    1034:      	tbz	w16, #0x7, 0xfa4 <ltmp0+0xfa4>
    1038:      	add	x15, x15, #0x1c
    103c:      	ld1.s	{ v18 }[3], [x15]
    1040:      	fmov	w16, s20
    1044:      	add	x15, x13, x10
    1048:      	movi.2d	v24, #0000000000000000
    104c:      	movi.2d	v23, #0000000000000000
    1050:      	tbnz	w16, #0x0, 0xfb8 <ltmp0+0xfb8>
    1054:      	and	w16, w16, #0xff
    1058:      	tbz	w16, #0x1, 0xfc4 <ltmp0+0xfc4>
    105c:      	add	x17, x15, #0x4
    1060:      	ld1.s	{ v24 }[1], [x17]
    1064:      	tbnz	w16, #0x2, 0xfc8 <ltmp0+0xfc8>
    1068:      	tbz	w16, #0x3, 0xfd4 <ltmp0+0xfd4>
    106c:      	add	x17, x15, #0xc
    1070:      	ld1.s	{ v24 }[3], [x17]
    1074:      	tbnz	w16, #0x4, 0xfd8 <ltmp0+0xfd8>
    1078:      	tbz	w16, #0x5, 0xfe4 <ltmp0+0xfe4>
    107c:      	add	x17, x15, #0x14
    1080:      	ld1.s	{ v23 }[1], [x17]
    1084:      	tbnz	w16, #0x6, 0xfe8 <ltmp0+0xfe8>
    1088:      	tbz	w16, #0x7, 0x1094 <ltmp0+0x1094>
    108c:      	add	x15, x15, #0x1c
    1090:      	ld1.s	{ v23 }[3], [x15]
    1094:      	ldp	q5, q7, [sp, #0xb0]
    1098:      	fmul.4s	v25, v22, v7
    109c:      	fmul.4s	v25, v22, v25
    10a0:      	fmul.4s	v25, v22, v25
    10a4:      	fadd.4s	v25, v22, v25
    10a8:      	fmul.4s	v25, v25, v5
    10ac:      	and.16b	v25, v0, v25
    10b0:      	fabs.4s	v26, v25
    10b4:      	fmul.4s	v27, v25, v25
    10b8:      	ldr	q5, [sp, #0x130]
    10bc:      	fmla.4s	v28, v27, v5
    10c0:      	ldr	q29, [sp, #0xd0]
    10c4:      	fmla.4s	v29, v27, v28
    10c8:      	mov.16b	v28, v30
    10cc:      	fmla.4s	v28, v27, v29
    10d0:      	fmla.4s	v14, v27, v28
    10d4:      	ldr	q9, [sp, #0xf0]
    10d8:      	mov.16b	v28, v9
    10dc:      	fmla.4s	v28, v27, v14
    10e0:      	ldr	q7, [sp, #0x250]
    10e4:      	mov.16b	v29, v7
    10e8:      	fmla.4s	v29, v27, v28
    10ec:      	fmul.4s	v28, v26, v29
    10f0:      	ldp	q5, q29, [sp, #0x230]
    10f4:      	fmla.4s	v29, v27, v5
    10f8:      	ldp	q30, q5, [sp, #0x170]
    10fc:      	fmla.4s	v30, v27, v29
    1100:      	ldr	q29, [sp, #0x1e0]
    1104:      	fmla.4s	v29, v27, v30
    1108:      	ldr	q30, [sp, #0x160]
    110c:      	fmla.4s	v30, v27, v29
    1110:      	movi.4s	v29, #0x3f, lsl #24
    1114:      	fmla.4s	v29, v27, v30
    1118:      	mov.16b	v30, v7
    111c:      	fmla.4s	v30, v27, v29
    1120:      	fdiv.4s	v27, v28, v30
    1124:      	fcmge.4s	v28, v5, v26
    1128:      	and.16b	v29, v28, v26
    112c:      	ldr	q5, [sp, #0x220]
    1130:      	fcmge.4s	v30, v29, v5
    1134:      	fcmge.4s	v31, v11, v29
    1138:      	and.16b	v30, v30, v31
    113c:      	and.16b	v30, v30, v29
    1140:      	fmul.4s	v31, v30, v10
    1144:      	movi.4s	v5, #0x4b, lsl #24
    1148:      	fadd.4s	v31, v31, v5
    114c:      	movi.4s	v5, #0xcb, lsl #24
    1150:      	fadd.4s	v31, v31, v5
    1154:      	fcvtzs.4s	v31, v31
    1158:      	scvtf.4s	v8, v31
    115c:      	mov.16b	v5, v9
    1160:      	fmul.4s	v9, v8, v12
    1164:      	fadd.4s	v30, v30, v9
    1168:      	fmul.4s	v8, v8, v13
    116c:      	fadd.4s	v30, v30, v8
    1170:      	ldp	q9, q8, [sp, #0x200]
    1174:      	fmul.4s	v8, v30, v8
    1178:      	fadd.4s	v8, v8, v9
    117c:      	fmul.4s	v8, v30, v8
    1180:      	ldr	q9, [sp, #0x1f0]
    1184:      	fadd.4s	v8, v8, v9
    1188:      	fmul.4s	v8, v30, v8
    118c:      	fadd.4s	v8, v8, v15
    1190:      	fmul.4s	v8, v30, v8
    1194:      	fadd.4s	v8, v8, v5
    1198:      	fmul.4s	v8, v30, v8
    119c:      	movi.4s	v5, #0x3f, lsl #24
    11a0:      	fadd.4s	v8, v8, v5
    11a4:      	fmul.4s	v9, v30, v30
    11a8:      	fmul.4s	v8, v9, v8
    11ac:      	fadd.4s	v30, v30, v8
    11b0:      	fadd.4s	v30, v30, v7
    11b4:      	add.4s	v31, v31, v2
    11b8:      	sshr.4s	v8, v31, #0x1
    11bc:      	shl.4s	v9, v8, #0x17
    11c0:      	add.4s	v9, v9, v7
    11c4:      	fmul.4s	v30, v30, v9
    11c8:      	sub.4s	v31, v31, v8
    11cc:      	shl.4s	v31, v31, #0x17
    11d0:      	add.4s	v31, v31, v7
    11d4:      	fmul.4s	v30, v30, v31
    11d8:      	fcmgt.4s	v29, v29, v11
    11dc:      	ldr	q5, [sp, #0x150]
    11e0:      	bsl.16b	v29, v5, v30
    11e4:      	ldr	q9, [sp, #0x1d0]
    11e8:      	fdiv.4s	v30, v9, v29
    11ec:      	fsub.4s	v31, v29, v30
    11f0:      	fadd.4s	v29, v29, v30
    11f4:      	fdiv.4s	v29, v31, v29
    11f8:      	bsl.16b	v28, v29, v7
    11fc:      	movi.4s	v29, #0x3f, lsl #24
    1200:      	fcmge.4s	v26, v7, v26
    1204:      	bsl.16b	v26, v27, v28
    1208:      	bif.16b	v26, v25, v16
    120c:      	fcmeq.4s	v25, v25, v25
    1210:      	fadd.4s	v26, v26, v7
    1214:      	ldr	q5, [sp, #0x140]
    1218:      	bsl.16b	v25, v26, v5
    121c:      	fmul.4s	v22, v22, v29
    1220:      	fmul.4s	v22, v22, v25
    1224:      	fmov	w16, s20
    1228:      	fadd.4s	v20, v24, v22
    122c:      	add	x15, x12, x10
    1230:      	tbz	w16, #0x0, 0x1264 <ltmp0+0x1264>
    1234:      	str	s20, [x15]
    1238:      	and	w16, w16, #0xff
    123c:      	tbnz	w16, #0x1, 0x126c <ltmp0+0x126c>
    1240:      	ldp	q14, q16, [sp, #0x100]
    1244:      	ldr	q5, [sp, #0x230]
    1248:      	ldp	q27, q28, [sp, #0x170]
    124c:      	ldp	q8, q31, [sp, #0x1f0]
    1250:      	tbz	w16, #0x2, 0x1288 <ltmp0+0x1288>
    1254:      	add	x17, x15, #0x8
    1258:      	st1.s	{ v20 }[2], [x17]
    125c:      	tbnz	w16, #0x3, 0x128c <ltmp0+0x128c>
    1260:      	b	0x1294 <ltmp0+0x1294>
    1264:      	and	w16, w16, #0xff
    1268:      	tbz	w16, #0x1, 0x1240 <ltmp0+0x1240>
    126c:      	add	x17, x15, #0x4
    1270:      	st1.s	{ v20 }[1], [x17]
    1274:      	ldp	q14, q16, [sp, #0x100]
    1278:      	ldr	q5, [sp, #0x230]
    127c:      	ldp	q27, q28, [sp, #0x170]
    1280:      	ldp	q8, q31, [sp, #0x1f0]
    1284:      	tbnz	w16, #0x2, 0x1254 <ltmp0+0x1254>
    1288:      	tbz	w16, #0x3, 0x1294 <ltmp0+0x1294>
    128c:      	add	x17, x15, #0xc
    1290:      	st1.s	{ v20 }[3], [x17]
    1294:      	ldp	q7, q26, [sp, #0xc0]
    1298:      	fmul.4s	v20, v18, v7
    129c:      	fmul.4s	v20, v18, v20
    12a0:      	fmul.4s	v20, v18, v20
    12a4:      	fadd.4s	v20, v18, v20
    12a8:      	ldr	q7, [sp, #0xb0]
    12ac:      	fmul.4s	v20, v20, v7
    12b0:      	and.16b	v20, v1, v20
    12b4:      	fabs.4s	v22, v20
    12b8:      	fmul.4s	v24, v20, v20
    12bc:      	ldp	q25, q7, [sp, #0x120]
    12c0:      	fmla.4s	v25, v24, v7
    12c4:      	fmla.4s	v26, v24, v25
    12c8:      	mov.16b	v17, v16
    12cc:      	mov.16b	v25, v16
    12d0:      	fmla.4s	v25, v24, v26
    12d4:      	mov.16b	v26, v14
    12d8:      	fmla.4s	v26, v24, v25
    12dc:      	ldr	q16, [sp, #0xf0]
    12e0:      	mov.16b	v25, v16
    12e4:      	fmla.4s	v25, v24, v26
    12e8:      	ldr	q7, [sp, #0x250]
    12ec:      	mov.16b	v26, v7
    12f0:      	fmla.4s	v26, v24, v25
    12f4:      	fmul.4s	v25, v22, v26
    12f8:      	ldr	q26, [sp, #0x240]
    12fc:      	fmla.4s	v26, v24, v5
    1300:      	fmla.4s	v27, v24, v26
    1304:      	ldr	q26, [sp, #0x1e0]
    1308:      	fmla.4s	v26, v24, v27
    130c:      	ldr	q27, [sp, #0x160]
    1310:      	fmla.4s	v27, v24, v26
    1314:      	movi.4s	v26, #0x3f, lsl #24
    1318:      	fmla.4s	v26, v24, v27
    131c:      	mov.16b	v27, v7
    1320:      	fmla.4s	v27, v24, v26
    1324:      	fdiv.4s	v24, v25, v27
    1328:      	fcmge.4s	v25, v28, v22
    132c:      	and.16b	v26, v25, v22
    1330:      	ldr	q5, [sp, #0x220]
    1334:      	fcmge.4s	v27, v26, v5
    1338:      	fcmge.4s	v28, v11, v26
    133c:      	and.16b	v27, v27, v28
    1340:      	and.16b	v27, v27, v26
    1344:      	fmul.4s	v28, v27, v10
    1348:      	movi.4s	v5, #0x4b, lsl #24
    134c:      	fadd.4s	v28, v28, v5
    1350:      	movi.4s	v5, #0xcb, lsl #24
    1354:      	fadd.4s	v28, v28, v5
    1358:      	fcvtzs.4s	v28, v28
    135c:      	scvtf.4s	v29, v28
    1360:      	fmul.4s	v30, v29, v12
    1364:      	fadd.4s	v27, v27, v30
    1368:      	fmul.4s	v29, v29, v13
    136c:      	fadd.4s	v27, v27, v29
    1370:      	ldr	q5, [sp, #0x210]
    1374:      	fmul.4s	v29, v27, v5
    1378:      	fadd.4s	v29, v29, v31
    137c:      	fmul.4s	v29, v27, v29
    1380:      	fadd.4s	v29, v29, v8
    1384:      	fmul.4s	v29, v27, v29
    1388:      	fadd.4s	v29, v29, v15
    138c:      	fmul.4s	v29, v27, v29
    1390:      	fadd.4s	v29, v29, v16
    1394:      	fmul.4s	v29, v27, v29
    1398:      	movi.4s	v5, #0x3f, lsl #24
    139c:      	fadd.4s	v29, v29, v5
    13a0:      	fmul.4s	v30, v27, v27
    13a4:      	fmul.4s	v29, v30, v29
    13a8:      	fadd.4s	v27, v27, v29
    13ac:      	fadd.4s	v27, v27, v7
    13b0:      	add.4s	v28, v28, v2
    13b4:      	sshr.4s	v29, v28, #0x1
    13b8:      	shl.4s	v30, v29, #0x17
    13bc:      	add.4s	v30, v30, v7
    13c0:      	fmul.4s	v27, v27, v30
    13c4:      	sub.4s	v28, v28, v29
    13c8:      	movi.4s	v29, #0x3f, lsl #24
    13cc:      	shl.4s	v28, v28, #0x17
    13d0:      	add.4s	v28, v28, v7
    13d4:      	fmul.4s	v27, v27, v28
    13d8:      	fcmgt.4s	v26, v26, v11
    13dc:      	ldr	q5, [sp, #0x150]
    13e0:      	bsl.16b	v26, v5, v27
    13e4:      	fdiv.4s	v27, v9, v26
    13e8:      	fsub.4s	v28, v26, v27
    13ec:      	fadd.4s	v26, v26, v27
    13f0:      	fdiv.4s	v26, v28, v26
    13f4:      	bsl.16b	v25, v26, v7
    13f8:      	mov.16b	v26, v7
    13fc:      	fcmge.4s	v22, v7, v22
    1400:      	bsl.16b	v22, v24, v25
    1404:      	mvni.4s	v5, #0x80, lsl #24
    1408:      	bif.16b	v22, v20, v5
    140c:      	fcmeq.4s	v20, v20, v20
    1410:      	fadd.4s	v22, v22, v7
    1414:      	ldr	q5, [sp, #0x140]
    1418:      	bsl.16b	v20, v22, v5
    141c:      	fmul.4s	v18, v18, v29
    1420:      	fmul.4s	v18, v18, v20
    1424:      	fadd.4s	v18, v23, v18
    1428:      	tbz	w16, #0x4, 0x1458 <ltmp0+0x1458>
    142c:      	str	s18, [x15, #0x10]
    1430:      	tbnz	w16, #0x5, 0x145c <ltmp0+0x145c>
    1434:      	ldp	q28, q27, [sp, #0x170]
    1438:      	ldr	q25, [sp, #0x1e0]
    143c:      	ldr	q23, [sp, #0xd0]
    1440:      	mov.16b	v30, v17
    1444:      	tbz	w16, #0x6, 0x1478 <ltmp0+0x1478>
    1448:      	add	x17, x15, #0x18
    144c:      	st1.s	{ v18 }[2], [x17]
    1450:      	tbz	w16, #0x7, 0xf34 <ltmp0+0xf34>
    1454:      	b	0x147c <ltmp0+0x147c>
    1458:      	tbz	w16, #0x5, 0x1434 <ltmp0+0x1434>
    145c:      	add	x17, x15, #0x14
    1460:      	st1.s	{ v18 }[1], [x17]
    1464:      	ldp	q28, q27, [sp, #0x170]
    1468:      	ldr	q25, [sp, #0x1e0]
    146c:      	ldr	q23, [sp, #0xd0]
    1470:      	mov.16b	v30, v17
    1474:      	tbnz	w16, #0x6, 0x1448 <ltmp0+0x1448>
    1478:      	tbz	w16, #0x7, 0xf34 <ltmp0+0xf34>
    147c:      	add	x15, x15, #0x1c
    1480:      	st1.s	{ v18 }[3], [x15]
    1484:      	b	0xf34 <ltmp0+0xf34>
    1488:      	mov	x25, #0x0               ; =0
    148c:      	ldr	x8, [sp, #0x18]
    1490:      	ldr	x13, [x8]
    1494:      	ldr	x26, [x8, #0x10]
    1498:      	ldr	x14, [x8, #0x30]
    149c:      	subs	x8, x13, x14
    14a0:      	mov	w11, #0xfff             ; =4095
    14a4:      	movk	w11, #0x100, lsl #16
    14a8:      	ccmp	x8, x11, #0x0, hs
    14ac:      	cset	w8, hi
    14b0:      	subs	x9, x14, x13
    14b4:      	ccmp	x9, x11, #0x0, hs
    14b8:      	csinc	w8, w8, wzr, ls
    14bc:      	subs	x9, x26, x14
    14c0:      	ccmp	x9, x11, #0x0, hs
    14c4:      	cset	w9, hi
    14c8:      	subs	x10, x14, x26
    14cc:      	ccmp	x10, x11, #0x0, hs
    14d0:      	csinc	w9, w9, wzr, ls
    14d4:      	and	w10, w8, w9
    14d8:      	ldr	x8, [sp, #0x48]
    14dc:      	lsl	w11, w8, #2
    14e0:      	and	x8, x8, #0x7ffffff
    14e4:      	mov	w9, #0x10               ; =16
    14e8:      	movk	w9, #0x1, lsl #16
    14ec:      	umaddl	x20, w8, w9, x14
    14f0:      	umaddl	x21, w8, w9, x26
    14f4:      	str	x13, [sp, #0xa0]
    14f8:      	umaddl	x19, w8, w9, x13
    14fc:      	str	x12, [sp, #0x70]
    1500:      	str	x14, [sp, #0x60]
    1504:      	str	w10, [sp, #0x5c]
    1508:      	str	x11, [sp, #0x50]
    150c:      	b	0x1708 <ltmp0+0x1708>
    1510:      	movi.2d	v1, #0000000000000000
    1514:      	ldr	q3, [sp, #0x80]
    1518:      	mov.s	v1[0], v3[0]
    151c:      	mov	w1, #0x2713             ; =10003
    1520:      	movk	w1, #0x3d37, lsl #16
    1524:      	fmov	s2, w1
    1528:      	fmul.4s	v2, v1, v2
    152c:      	fmul.4s	v2, v3, v2
    1530:      	fmul.4s	v2, v3, v2
    1534:      	fadd.4s	v2, v3, v2
    1538:      	mov	w3, #0x422a             ; =16938
    153c:      	movk	w3, #0x3f4c, lsl #16
    1540:      	fmov	s3, w3
    1544:      	fmul.4s	v3, v2, v3
    1548:      	movi.2d	v2, #0000000000000000
    154c:      	mov.s	v2[0], v3[0]
    1550:      	fabs.4s	v3, v2
    1554:      	fmul.4s	v4, v2, v2
    1558:      	mov.16b	v5, v28
    155c:      	fmla.4s	v5, v4, v0
    1560:      	mov.16b	v6, v23
    1564:      	fmla.4s	v6, v4, v5
    1568:      	mov.16b	v5, v30
    156c:      	fmla.4s	v5, v4, v6
    1570:      	mov.16b	v6, v9
    1574:      	fmla.4s	v6, v4, v5
    1578:      	mov.16b	v5, v14
    157c:      	fmla.4s	v5, v4, v6
    1580:      	mov.16b	v6, v26
    1584:      	fmla.4s	v6, v4, v5
    1588:      	fmul.4s	v5, v3, v6
    158c:      	ldp	q0, q20, [sp, #0x230]
    1590:      	mov.16b	v6, v20
    1594:      	fmla.4s	v6, v4, v0
    1598:      	ldp	q25, q28, [sp, #0x160]
    159c:      	mov.16b	v7, v28
    15a0:      	fmla.4s	v7, v4, v6
    15a4:      	ldr	q27, [sp, #0x1e0]
    15a8:      	mov.16b	v6, v27
    15ac:      	fmla.4s	v6, v4, v7
    15b0:      	mov.16b	v7, v25
    15b4:      	fmla.4s	v7, v4, v6
    15b8:      	movi.4s	v6, #0x3f, lsl #24
    15bc:      	fmla.4s	v6, v4, v7
    15c0:      	mov.16b	v7, v26
    15c4:      	fmla.4s	v7, v4, v6
    15c8:      	fdiv.4s	v0, v5, v7
    15cc:      	str	q0, [sp, #0x80]
    15d0:      	ldr	q4, [sp, #0x180]
    15d4:      	fcmge.4s	v5, v4, v3
    15d8:      	and.16b	v6, v5, v3
    15dc:      	ldr	q0, [sp, #0x220]
    15e0:      	fcmge.4s	v7, v6, v0
    15e4:      	fcmge.4s	v16, v11, v6
    15e8:      	and.16b	v7, v7, v16
    15ec:      	and.16b	v7, v7, v6
    15f0:      	ldp	q12, q0, [sp, #0x1b0]
    15f4:      	fmul.4s	v16, v7, v0
    15f8:      	fadd.4s	v16, v16, v10
    15fc:      	fadd.4s	v16, v16, v31
    1600:      	fcvtzs.4s	v16, v16
    1604:      	scvtf.4s	v17, v16
    1608:      	fmul.4s	v18, v17, v12
    160c:      	fadd.4s	v7, v7, v18
    1610:      	ldp	q15, q13, [sp, #0x190]
    1614:      	fmul.4s	v17, v17, v13
    1618:      	fadd.4s	v7, v7, v17
    161c:      	ldp	q18, q17, [sp, #0x200]
    1620:      	fmul.4s	v17, v7, v17
    1624:      	fadd.4s	v17, v17, v18
    1628:      	fmul.4s	v17, v7, v17
    162c:      	ldr	q18, [sp, #0x1f0]
    1630:      	fadd.4s	v17, v17, v18
    1634:      	fmul.4s	v17, v7, v17
    1638:      	fadd.4s	v17, v17, v15
    163c:      	fmul.4s	v17, v7, v17
    1640:      	fadd.4s	v17, v17, v14
    1644:      	fmul.4s	v17, v7, v17
    1648:      	fadd.4s	v17, v17, v29
    164c:      	fmul.4s	v18, v7, v7
    1650:      	fmul.4s	v17, v18, v17
    1654:      	fadd.4s	v7, v7, v17
    1658:      	fadd.4s	v7, v7, v26
    165c:      	add.4s	v16, v16, v8
    1660:      	sshr.4s	v17, v16, #0x1
    1664:      	shl.4s	v18, v17, #0x17
    1668:      	add.4s	v18, v18, v26
    166c:      	fmul.4s	v7, v7, v18
    1670:      	sub.4s	v16, v16, v17
    1674:      	shl.4s	v16, v16, #0x17
    1678:      	add.4s	v16, v16, v26
    167c:      	fmul.4s	v7, v7, v16
    1680:      	fcmgt.4s	v6, v6, v11
    1684:      	ldp	q18, q22, [sp, #0x140]
    1688:      	bsl.16b	v6, v22, v7
    168c:      	ldr	q7, [sp, #0x1d0]
    1690:      	fdiv.4s	v7, v7, v6
    1694:      	fsub.4s	v16, v6, v7
    1698:      	fadd.4s	v6, v6, v7
    169c:      	fdiv.4s	v6, v16, v6
    16a0:      	bsl.16b	v5, v6, v26
    16a4:      	fcmge.4s	v3, v26, v3
    16a8:      	ldr	q6, [sp, #0x80]
    16ac:      	bsl.16b	v3, v6, v5
    16b0:      	bif.16b	v3, v2, v24
    16b4:      	fcmeq.4s	v2, v2, v2
    16b8:      	fadd.4s	v3, v3, v26
    16bc:      	bsl.16b	v2, v3, v18
    16c0:      	fmul.4s	v1, v1, v29
    16c4:      	fmul.4s	v1, v1, v2
    16c8:      	ldr	q2, [sp, #0x90]
    16cc:      	fadd.4s	v1, v2, v1
    16d0:      	mov.16b	v29, v4
    16d4:      	mov.16b	v10, v0
    16d8:      	mov	w4, #0x4004             ; =16388
    16dc:      	ldr	x12, [sp, #0x70]
    16e0:      	ldr	x14, [sp, #0x60]
    16e4:      	ldr	w10, [sp, #0x5c]
    16e8:      	ldr	x11, [sp, #0x50]
    16ec:      	str	s1, [x14, x27]
    16f0:      	add	x25, x25, #0x1
    16f4:      	add	x20, x20, x4
    16f8:      	add	x21, x21, x4
    16fc:      	add	x19, x19, x4
    1700:      	cmp	x25, x12
    1704:      	b.eq	0xde8 <ltmp0+0xde8>
    1708:      	add	w8, w25, w11
    170c:      	and	x8, x8, #0x1fffffff
    1710:      	add	x8, x8, x8, lsl #12
    1714:      	lsl	x28, x8, #2
    1718:      	cbz	w10, 0x1c18 <ltmp0+0x1c18>
    171c:      	mov	x8, #0x0                ; =0
    1720:      	ldp	q11, q30, [sp, #0xe0]
    1724:      	ldp	q31, q13, [sp, #0x120]
    1728:      	add	x9, x19, x8
    172c:      	ldp	q0, q1, [x9]
    1730:      	fmul.4s	v2, v0, v19
    1734:      	fmul.4s	v3, v1, v19
    1738:      	fmul.4s	v3, v1, v3
    173c:      	fmul.4s	v2, v0, v2
    1740:      	fmul.4s	v2, v0, v2
    1744:      	fmul.4s	v3, v1, v3
    1748:      	fadd.4s	v4, v1, v3
    174c:      	fadd.4s	v2, v0, v2
    1750:      	fmul.4s	v3, v2, v21
    1754:      	fmul.4s	v2, v4, v21
    1758:      	fabs.4s	v5, v2
    175c:      	fabs.4s	v4, v3
    1760:      	mov.16b	v14, v19
    1764:      	fmul.4s	v19, v3, v3
    1768:      	mov.16b	v9, v21
    176c:      	fmul.4s	v21, v2, v2
    1770:      	mov.16b	v6, v31
    1774:      	fmla.4s	v6, v19, v13
    1778:      	mov.16b	v7, v31
    177c:      	fmla.4s	v7, v21, v13
    1780:      	mov.16b	v16, v23
    1784:      	fmla.4s	v16, v19, v6
    1788:      	mov.16b	v6, v23
    178c:      	fmla.4s	v6, v21, v7
    1790:      	ldp	q18, q17, [sp, #0x100]
    1794:      	mov.16b	v7, v17
    1798:      	fmla.4s	v7, v19, v16
    179c:      	mov.16b	v16, v17
    17a0:      	fmla.4s	v16, v21, v6
    17a4:      	mov.16b	v17, v18
    17a8:      	mov.16b	v22, v30
    17ac:      	mov.16b	v12, v23
    17b0:      	mov.16b	v23, v30
    17b4:      	mov.16b	v6, v26
    17b8:      	fmla.4s	v17, v19, v7
    17bc:      	mov.16b	v7, v20
    17c0:      	ldp	q24, q20, [sp, #0x230]
    17c4:      	fmla.4s	v7, v21, v24
    17c8:      	fmla.4s	v20, v19, v24
    17cc:      	mov.16b	v24, v28
    17d0:      	fmla.4s	v18, v21, v16
    17d4:      	fmla.4s	v24, v21, v7
    17d8:      	fmla.4s	v28, v19, v20
    17dc:      	mov.16b	v16, v27
    17e0:      	fmla.4s	v16, v21, v24
    17e4:      	fmla.4s	v22, v19, v17
    17e8:      	fmla.4s	v27, v19, v28
    17ec:      	mov.16b	v20, v25
    17f0:      	fmla.4s	v20, v21, v16
    17f4:      	mov.16b	v24, v25
    17f8:      	fmla.4s	v23, v21, v18
    17fc:      	fmla.4s	v24, v19, v27
    1800:      	movi.4s	v25, #0x3f, lsl #24
    1804:      	movi.4s	v26, #0x3f, lsl #24
    1808:      	ldr	q17, [sp, #0x250]
    180c:      	fcmge.4s	v7, v29, v4
    1810:      	fmla.4s	v25, v21, v20
    1814:      	fcmge.4s	v16, v29, v5
    1818:      	and.16b	v18, v16, v5
    181c:      	and.16b	v20, v7, v4
    1820:      	ldr	q28, [sp, #0x220]
    1824:      	fcmge.4s	v27, v20, v28
    1828:      	fcmge.4s	v28, v18, v28
    182c:      	fcmge.4s	v29, v11, v18
    1830:      	and.16b	v28, v28, v29
    1834:      	fcmge.4s	v29, v11, v20
    1838:      	and.16b	v27, v27, v29
    183c:      	and.16b	v27, v27, v20
    1840:      	and.16b	v28, v28, v18
    1844:      	fmla.4s	v6, v21, v23
    1848:      	ldp	q15, q29, [sp, #0x1b0]
    184c:      	fmul.4s	v23, v28, v29
    1850:      	fmul.4s	v29, v27, v29
    1854:      	movi.4s	v8, #0x4b, lsl #24
    1858:      	fadd.4s	v29, v29, v8
    185c:      	fadd.4s	v23, v23, v8
    1860:      	movi.4s	v8, #0xcb, lsl #24
    1864:      	fadd.4s	v23, v23, v8
    1868:      	fmla.4s	v17, v21, v25
    186c:      	fadd.4s	v21, v29, v8
    1870:      	fcvtzs.4s	v21, v21
    1874:      	fcvtzs.4s	v23, v23
    1878:      	scvtf.4s	v25, v23
    187c:      	scvtf.4s	v29, v21
    1880:      	fmla.4s	v26, v19, v24
    1884:      	fmul.4s	v24, v25, v15
    1888:      	fadd.4s	v24, v28, v24
    188c:      	fmul.4s	v28, v29, v15
    1890:      	fadd.4s	v27, v27, v28
    1894:      	ldr	q28, [sp, #0x250]
    1898:      	fmla.4s	v28, v19, v22
    189c:      	ldr	q15, [sp, #0x1a0]
    18a0:      	fmul.4s	v22, v29, v15
    18a4:      	fadd.4s	v22, v27, v22
    18a8:      	fmul.4s	v25, v25, v15
    18ac:      	fadd.4s	v24, v24, v25
    18b0:      	ldr	q25, [sp, #0x250]
    18b4:      	fmla.4s	v25, v19, v26
    18b8:      	ldp	q27, q26, [sp, #0x200]
    18bc:      	fmul.4s	v19, v24, v26
    18c0:      	fmul.4s	v26, v22, v26
    18c4:      	fadd.4s	v26, v26, v27
    18c8:      	fadd.4s	v19, v19, v27
    18cc:      	fmul.4s	v19, v24, v19
    18d0:      	fmul.4s	v27, v4, v28
    18d4:      	fmul.4s	v26, v22, v26
    18d8:      	ldr	q28, [sp, #0x1f0]
    18dc:      	fadd.4s	v26, v26, v28
    18e0:      	fadd.4s	v19, v19, v28
    18e4:      	fmul.4s	v19, v24, v19
    18e8:      	fmul.4s	v26, v22, v26
    18ec:      	ldr	q28, [sp, #0x190]
    18f0:      	fadd.4s	v26, v26, v28
    18f4:      	fadd.4s	v19, v19, v28
    18f8:      	fmul.4s	v19, v24, v19
    18fc:      	fmul.4s	v26, v22, v26
    1900:      	fadd.4s	v26, v26, v30
    1904:      	fadd.4s	v28, v19, v30
    1908:      	fdiv.4s	v19, v27, v25
    190c:      	fmul.4s	v25, v24, v28
    1910:      	fmul.4s	v26, v22, v26
    1914:      	movi.4s	v15, #0x3f, lsl #24
    1918:      	fadd.4s	v26, v26, v15
    191c:      	fadd.4s	v25, v25, v15
    1920:      	fmul.4s	v27, v24, v24
    1924:      	fmul.4s	v25, v27, v25
    1928:      	fmul.4s	v27, v22, v22
    192c:      	fmul.4s	v26, v27, v26
    1930:      	ldr	q27, [sp, #0x1e0]
    1934:      	fadd.4s	v22, v22, v26
    1938:      	fadd.4s	v24, v24, v25
    193c:      	movi.2d	v10, #0xffffffffffffffff
    1940:      	add.4s	v21, v21, v10
    1944:      	ldr	q25, [sp, #0x250]
    1948:      	fadd.4s	v22, v22, v25
    194c:      	sshr.4s	v25, v21, #0x1
    1950:      	shl.4s	v26, v25, #0x17
    1954:      	ldr	q29, [sp, #0x250]
    1958:      	add.4s	v26, v26, v29
    195c:      	ldp	q28, q29, [sp, #0x170]
    1960:      	fmul.4s	v22, v22, v26
    1964:      	ldr	q26, [sp, #0x250]
    1968:      	movi.2d	v8, #0xffffffffffffffff
    196c:      	add.4s	v23, v23, v10
    1970:      	fadd.4s	v24, v24, v26
    1974:      	sub.4s	v21, v21, v25
    1978:      	sshr.4s	v25, v23, #0x1
    197c:      	sub.4s	v23, v23, v25
    1980:      	shl.4s	v25, v25, #0x17
    1984:      	add.4s	v25, v25, v26
    1988:      	fmul.4s	v24, v24, v25
    198c:      	shl.4s	v23, v23, #0x17
    1990:      	add.4s	v23, v23, v26
    1994:      	fmul.4s	v23, v24, v23
    1998:      	mvni.4s	v24, #0x80, lsl #24
    199c:      	shl.4s	v21, v21, #0x17
    19a0:      	add.4s	v21, v21, v26
    19a4:      	fmul.4s	v21, v22, v21
    19a8:      	ldp	q22, q25, [sp, #0x150]
    19ac:      	fcmgt.4s	v20, v20, v11
    19b0:      	bsl.16b	v20, v22, v21
    19b4:      	fmul.4s	v6, v5, v6
    19b8:      	fcmgt.4s	v18, v18, v11
    19bc:      	bsl.16b	v18, v22, v23
    19c0:      	mov.16b	v23, v12
    19c4:      	fdiv.4s	v6, v6, v17
    19c8:      	ldr	q12, [sp, #0x1d0]
    19cc:      	fdiv.4s	v17, v12, v18
    19d0:      	fsub.4s	v21, v18, v17
    19d4:      	fadd.4s	v17, v18, v17
    19d8:      	ldr	q18, [sp, #0x140]
    19dc:      	fdiv.4s	v17, v21, v17
    19e0:      	mov.16b	v21, v9
    19e4:      	bsl.16b	v16, v17, v26
    19e8:      	fcmge.4s	v5, v26, v5
    19ec:      	bsl.16b	v5, v6, v16
    19f0:      	fdiv.4s	v6, v12, v20
    19f4:      	fsub.4s	v16, v20, v6
    19f8:      	fadd.4s	v6, v20, v6
    19fc:      	ldr	q20, [sp, #0x240]
    1a00:      	fdiv.4s	v6, v16, v6
    1a04:      	bif.16b	v6, v26, v7
    1a08:      	fcmge.4s	v4, v26, v4
    1a0c:      	bsl.16b	v4, v19, v6
    1a10:      	mov.16b	v19, v14
    1a14:      	bif.16b	v4, v3, v24
    1a18:      	fcmeq.4s	v3, v3, v3
    1a1c:      	fadd.4s	v4, v4, v26
    1a20:      	bsl.16b	v3, v4, v18
    1a24:      	mov.16b	v4, v24
    1a28:      	bsl.16b	v4, v5, v2
    1a2c:      	fcmeq.4s	v2, v2, v2
    1a30:      	fadd.4s	v4, v4, v26
    1a34:      	bsl.16b	v2, v4, v18
    1a38:      	fmul.4s	v1, v1, v15
    1a3c:      	fmul.4s	v1, v1, v2
    1a40:      	fmul.4s	v0, v0, v15
    1a44:      	fmul.4s	v0, v0, v3
    1a48:      	add	x9, x21, x8
    1a4c:      	ldp	q3, q2, [x9]
    1a50:      	fadd.4s	v0, v3, v0
    1a54:      	fadd.4s	v1, v2, v1
    1a58:      	add	x9, x20, x8
    1a5c:      	stp	q0, q1, [x9]
    1a60:      	add	x8, x8, #0x20
    1a64:      	cmp	x8, #0x4, lsl #12       ; =0x4000
    1a68:      	b.ne	0x1728 <ltmp0+0x1728>
    1a6c:      	add	x27, x28, #0x4, lsl #12 ; =0x4000
    1a70:      	ldr	x8, [sp, #0xa0]
    1a74:      	ldr	s0, [x8, x27]
    1a78:      	fmov	s1, w1
    1a7c:      	fmul.4s	v1, v0, v1
    1a80:      	fmul.4s	v1, v0, v1
    1a84:      	fmul.4s	v1, v0, v1
    1a88:      	fadd.4s	v1, v0, v1
    1a8c:      	fmov	s2, w3
    1a90:      	fmul.4s	v2, v1, v2
    1a94:      	movi.2d	v1, #0000000000000000
    1a98:      	mov.s	v1[0], v2[0]
    1a9c:      	fabs.4s	v2, v1
    1aa0:      	fmul.4s	v3, v1, v1
    1aa4:      	fmla.4s	v31, v3, v13
    1aa8:      	mov.16b	v5, v23
    1aac:      	fmla.4s	v5, v3, v31
    1ab0:      	ldp	q9, q31, [sp, #0x100]
    1ab4:      	mov.16b	v4, v31
    1ab8:      	fmla.4s	v4, v3, v5
    1abc:      	mov.16b	v5, v9
    1ac0:      	fmla.4s	v5, v3, v4
    1ac4:      	mov.16b	v4, v30
    1ac8:      	fmla.4s	v4, v3, v5
    1acc:      	mov.16b	v5, v26
    1ad0:      	fmla.4s	v5, v3, v4
    1ad4:      	fmul.4s	v4, v2, v5
    1ad8:      	mov.16b	v5, v20
    1adc:      	ldr	q6, [sp, #0x230]
    1ae0:      	fmla.4s	v5, v3, v6
    1ae4:      	mov.16b	v6, v28
    1ae8:      	fmla.4s	v6, v3, v5
    1aec:      	mov.16b	v5, v27
    1af0:      	fmla.4s	v5, v3, v6
    1af4:      	mov.16b	v6, v25
    1af8:      	fmla.4s	v6, v3, v5
    1afc:      	movi.4s	v5, #0x3f, lsl #24
    1b00:      	fmla.4s	v5, v3, v6
    1b04:      	mov.16b	v6, v26
    1b08:      	fmla.4s	v6, v3, v5
    1b0c:      	fdiv.4s	v3, v4, v6
    1b10:      	fcmge.4s	v4, v29, v2
    1b14:      	and.16b	v5, v4, v2
    1b18:      	ldr	q6, [sp, #0x220]
    1b1c:      	fcmge.4s	v6, v5, v6
    1b20:      	fcmge.4s	v7, v11, v5
    1b24:      	and.16b	v6, v6, v7
    1b28:      	and.16b	v6, v6, v5
    1b2c:      	ldp	q12, q10, [sp, #0x1b0]
    1b30:      	fmul.4s	v7, v6, v10
    1b34:      	movi.4s	v16, #0x4b, lsl #24
    1b38:      	fadd.4s	v7, v7, v16
    1b3c:      	movi.4s	v16, #0xcb, lsl #24
    1b40:      	fadd.4s	v7, v7, v16
    1b44:      	fcvtzs.4s	v7, v7
    1b48:      	scvtf.4s	v16, v7
    1b4c:      	fmul.4s	v17, v16, v12
    1b50:      	fadd.4s	v6, v6, v17
    1b54:      	ldp	q15, q13, [sp, #0x190]
    1b58:      	fmul.4s	v16, v16, v13
    1b5c:      	fadd.4s	v6, v6, v16
    1b60:      	ldp	q17, q16, [sp, #0x200]
    1b64:      	fmul.4s	v16, v6, v16
    1b68:      	fadd.4s	v16, v16, v17
    1b6c:      	fmul.4s	v16, v6, v16
    1b70:      	ldr	q17, [sp, #0x1f0]
    1b74:      	fadd.4s	v16, v16, v17
    1b78:      	fmul.4s	v16, v6, v16
    1b7c:      	fadd.4s	v16, v16, v15
    1b80:      	fmul.4s	v16, v6, v16
    1b84:      	fadd.4s	v16, v16, v30
    1b88:      	fmul.4s	v16, v6, v16
    1b8c:      	movi.4s	v30, #0x3f, lsl #24
    1b90:      	fadd.4s	v16, v16, v30
    1b94:      	fmul.4s	v17, v6, v6
    1b98:      	fmul.4s	v16, v17, v16
    1b9c:      	fadd.4s	v6, v6, v16
    1ba0:      	fadd.4s	v6, v6, v26
    1ba4:      	add.4s	v7, v7, v8
    1ba8:      	sshr.4s	v16, v7, #0x1
    1bac:      	shl.4s	v17, v16, #0x17
    1bb0:      	add.4s	v17, v17, v26
    1bb4:      	fmul.4s	v6, v6, v17
    1bb8:      	sub.4s	v7, v7, v16
    1bbc:      	shl.4s	v7, v7, #0x17
    1bc0:      	add.4s	v7, v7, v26
    1bc4:      	fmul.4s	v6, v6, v7
    1bc8:      	fcmgt.4s	v5, v5, v11
    1bcc:      	bsl.16b	v5, v22, v6
    1bd0:      	ldr	q6, [sp, #0x1d0]
    1bd4:      	fdiv.4s	v6, v6, v5
    1bd8:      	fsub.4s	v7, v5, v6
    1bdc:      	fadd.4s	v5, v5, v6
    1be0:      	fdiv.4s	v5, v7, v5
    1be4:      	bsl.16b	v4, v5, v26
    1be8:      	fcmge.4s	v2, v26, v2
    1bec:      	bsl.16b	v2, v3, v4
    1bf0:      	bif.16b	v2, v1, v24
    1bf4:      	fcmeq.4s	v1, v1, v1
    1bf8:      	fadd.4s	v2, v2, v26
    1bfc:      	bsl.16b	v1, v2, v18
    1c00:      	fmul.4s	v0, v0, v30
    1c04:      	fmul.4s	v0, v0, v1
    1c08:      	ldr	s1, [x26, x27]
    1c0c:      	fadd.4s	v1, v1, v0
    1c10:      	mov.16b	v30, v31
    1c14:      	b	0x16ec <ltmp0+0x16ec>
    1c18:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
    1c1c:      	add	x0, x0, #0x3f0
    1c20:      	ldr	x22, [sp, #0xa0]
    1c24:      	add	x1, x22, x28
    1c28:      	mov	w2, #0x4000             ; =16384
    1c2c:      	bl	0x1c2c <ltmp0+0x1c2c>
    1c30:      	add	x27, x28, #0x4, lsl #12 ; =0x4000
    1c34:      	ldr	s0, [x22, x27]
    1c38:      	str	q0, [sp, #0x80]
    1c3c:      	str	q0, [sp, #0x83f0]
    1c40:      	add	x0, sp, #0x3d0
    1c44:      	add	x1, x26, x28
    1c48:      	mov	w2, #0x4000             ; =16384
    1c4c:      	bl	0x1c4c <ltmp0+0x1c4c>
    1c50:      	ldr	q26, [sp, #0x250]
    1c54:      	ldp	q14, q9, [sp, #0xf0]
    1c58:      	ldp	q30, q28, [sp, #0x110]
    1c5c:      	ldp	q19, q23, [sp, #0xc0]
    1c60:      	ldr	q0, [sp, #0x130]
    1c64:      	ldr	q21, [sp, #0xb0]
    1c68:      	mov	x8, #0x0                ; =0
    1c6c:      	ldr	s1, [x26, x27]
    1c70:      	str	q1, [sp, #0x90]
    1c74:      	str	q1, [sp, #0x43d0]
    1c78:      	ldr	q11, [sp, #0xe0]
    1c7c:      	add	x9, x23, x8
    1c80:      	ldp	q1, q2, [x9]
    1c84:      	fmul.4s	v3, v1, v19
    1c88:      	fmul.4s	v4, v2, v19
    1c8c:      	fmul.4s	v4, v2, v4
    1c90:      	fmul.4s	v3, v1, v3
    1c94:      	fmul.4s	v3, v1, v3
    1c98:      	fmul.4s	v4, v2, v4
    1c9c:      	fadd.4s	v5, v2, v4
    1ca0:      	fadd.4s	v3, v1, v3
    1ca4:      	fmul.4s	v4, v3, v21
    1ca8:      	fmul.4s	v3, v5, v21
    1cac:      	fabs.4s	v6, v3
    1cb0:      	fabs.4s	v5, v4
    1cb4:      	fmul.4s	v20, v4, v4
    1cb8:      	fmul.4s	v22, v3, v3
    1cbc:      	mov.16b	v7, v28
    1cc0:      	fmla.4s	v7, v20, v0
    1cc4:      	mov.16b	v16, v28
    1cc8:      	fmla.4s	v16, v22, v0
    1ccc:      	mov.16b	v17, v23
    1cd0:      	fmla.4s	v17, v20, v7
    1cd4:      	mov.16b	v7, v23
    1cd8:      	fmla.4s	v7, v22, v16
    1cdc:      	mov.16b	v16, v30
    1ce0:      	fmla.4s	v16, v20, v17
    1ce4:      	mov.16b	v17, v30
    1ce8:      	fmla.4s	v17, v22, v7
    1cec:      	mov.16b	v18, v9
    1cf0:      	mov.16b	v12, v19
    1cf4:      	mov.16b	v19, v9
    1cf8:      	mov.16b	v0, v23
    1cfc:      	mov.16b	v23, v14
    1d00:      	mov.16b	v24, v14
    1d04:      	mov.16b	v7, v26
    1d08:      	fmla.4s	v18, v20, v16
    1d0c:      	ldp	q25, q26, [sp, #0x230]
    1d10:      	mov.16b	v16, v26
    1d14:      	fmla.4s	v16, v22, v25
    1d18:      	mov.16b	v13, v21
    1d1c:      	mov.16b	v21, v26
    1d20:      	fmla.4s	v21, v20, v25
    1d24:      	ldr	q26, [sp, #0x170]
    1d28:      	mov.16b	v25, v26
    1d2c:      	fmla.4s	v19, v22, v17
    1d30:      	fmla.4s	v25, v22, v16
    1d34:      	mov.16b	v16, v26
    1d38:      	fmla.4s	v16, v20, v21
    1d3c:      	ldr	q21, [sp, #0x1e0]
    1d40:      	mov.16b	v17, v21
    1d44:      	fmla.4s	v17, v22, v25
    1d48:      	fmla.4s	v23, v20, v18
    1d4c:      	mov.16b	v18, v21
    1d50:      	fmla.4s	v18, v20, v16
    1d54:      	ldr	q25, [sp, #0x160]
    1d58:      	mov.16b	v21, v25
    1d5c:      	fmla.4s	v21, v22, v17
    1d60:      	fmla.4s	v24, v22, v19
    1d64:      	fmla.4s	v25, v20, v18
    1d68:      	movi.4s	v26, #0x3f, lsl #24
    1d6c:      	movi.4s	v27, #0x3f, lsl #24
    1d70:      	ldr	q18, [sp, #0x250]
    1d74:      	ldr	q17, [sp, #0x180]
    1d78:      	fcmge.4s	v16, v17, v5
    1d7c:      	fmla.4s	v26, v22, v21
    1d80:      	fcmge.4s	v17, v17, v6
    1d84:      	and.16b	v19, v17, v6
    1d88:      	and.16b	v21, v16, v5
    1d8c:      	ldr	q29, [sp, #0x220]
    1d90:      	fcmge.4s	v28, v21, v29
    1d94:      	fcmge.4s	v29, v19, v29
    1d98:      	mov.16b	v15, v9
    1d9c:      	mov.16b	v9, v30
    1da0:      	fcmge.4s	v30, v11, v19
    1da4:      	and.16b	v29, v29, v30
    1da8:      	fcmge.4s	v30, v11, v21
    1dac:      	and.16b	v28, v28, v30
    1db0:      	and.16b	v28, v28, v21
    1db4:      	and.16b	v29, v29, v19
    1db8:      	fmla.4s	v7, v22, v24
    1dbc:      	ldr	q30, [sp, #0x1c0]
    1dc0:      	fmul.4s	v24, v29, v30
    1dc4:      	fmul.4s	v30, v28, v30
    1dc8:      	movi.4s	v8, #0x4b, lsl #24
    1dcc:      	fadd.4s	v30, v30, v8
    1dd0:      	movi.4s	v10, #0x4b, lsl #24
    1dd4:      	fadd.4s	v24, v24, v8
    1dd8:      	movi.4s	v8, #0xcb, lsl #24
    1ddc:      	fadd.4s	v24, v24, v8
    1de0:      	fmla.4s	v18, v22, v26
    1de4:      	movi.4s	v31, #0xcb, lsl #24
    1de8:      	fadd.4s	v22, v30, v8
    1dec:      	fcvtzs.4s	v22, v22
    1df0:      	fcvtzs.4s	v24, v24
    1df4:      	scvtf.4s	v26, v24
    1df8:      	scvtf.4s	v30, v22
    1dfc:      	fmla.4s	v27, v20, v25
    1e00:      	ldr	q8, [sp, #0x1b0]
    1e04:      	fmul.4s	v25, v26, v8
    1e08:      	fadd.4s	v25, v29, v25
    1e0c:      	fmul.4s	v29, v30, v8
    1e10:      	fadd.4s	v28, v28, v29
    1e14:      	ldr	q29, [sp, #0x250]
    1e18:      	fmla.4s	v29, v20, v23
    1e1c:      	ldr	q8, [sp, #0x1a0]
    1e20:      	fmul.4s	v23, v30, v8
    1e24:      	mov.16b	v30, v9
    1e28:      	mov.16b	v9, v15
    1e2c:      	fadd.4s	v23, v28, v23
    1e30:      	fmul.4s	v26, v26, v8
    1e34:      	fadd.4s	v25, v25, v26
    1e38:      	ldr	q26, [sp, #0x250]
    1e3c:      	fmla.4s	v26, v20, v27
    1e40:      	ldp	q28, q27, [sp, #0x200]
    1e44:      	fmul.4s	v20, v25, v27
    1e48:      	fmul.4s	v27, v23, v27
    1e4c:      	fadd.4s	v27, v27, v28
    1e50:      	fadd.4s	v20, v20, v28
    1e54:      	fmul.4s	v20, v25, v20
    1e58:      	fmul.4s	v28, v5, v29
    1e5c:      	fmul.4s	v27, v23, v27
    1e60:      	ldr	q29, [sp, #0x1f0]
    1e64:      	fadd.4s	v27, v27, v29
    1e68:      	fadd.4s	v20, v20, v29
    1e6c:      	fmul.4s	v20, v25, v20
    1e70:      	fmul.4s	v27, v23, v27
    1e74:      	ldr	q29, [sp, #0x190]
    1e78:      	fadd.4s	v27, v27, v29
    1e7c:      	fadd.4s	v20, v20, v29
    1e80:      	fmul.4s	v20, v25, v20
    1e84:      	fmul.4s	v27, v23, v27
    1e88:      	fadd.4s	v27, v27, v14
    1e8c:      	fadd.4s	v29, v20, v14
    1e90:      	fdiv.4s	v20, v28, v26
    1e94:      	fmul.4s	v26, v25, v29
    1e98:      	movi.4s	v29, #0x3f, lsl #24
    1e9c:      	fmul.4s	v27, v23, v27
    1ea0:      	fadd.4s	v27, v27, v29
    1ea4:      	fadd.4s	v26, v26, v29
    1ea8:      	fmul.4s	v28, v25, v25
    1eac:      	fmul.4s	v26, v28, v26
    1eb0:      	fmul.4s	v28, v23, v23
    1eb4:      	fmul.4s	v27, v28, v27
    1eb8:      	fadd.4s	v23, v23, v27
    1ebc:      	fadd.4s	v25, v25, v26
    1ec0:      	movi.2d	v15, #0xffffffffffffffff
    1ec4:      	add.4s	v22, v22, v15
    1ec8:      	ldr	q26, [sp, #0x250]
    1ecc:      	fadd.4s	v23, v23, v26
    1ed0:      	sshr.4s	v26, v22, #0x1
    1ed4:      	shl.4s	v27, v26, #0x17
    1ed8:      	ldr	q28, [sp, #0x250]
    1edc:      	add.4s	v27, v27, v28
    1ee0:      	ldr	q28, [sp, #0x120]
    1ee4:      	fmul.4s	v23, v23, v27
    1ee8:      	movi.2d	v8, #0xffffffffffffffff
    1eec:      	add.4s	v24, v24, v15
    1ef0:      	ldr	q27, [sp, #0x250]
    1ef4:      	fadd.4s	v25, v25, v27
    1ef8:      	sub.4s	v22, v22, v26
    1efc:      	sshr.4s	v26, v24, #0x1
    1f00:      	sub.4s	v24, v24, v26
    1f04:      	shl.4s	v26, v26, #0x17
    1f08:      	ldr	q27, [sp, #0x250]
    1f0c:      	add.4s	v26, v26, v27
    1f10:      	fmul.4s	v25, v25, v26
    1f14:      	ldr	q26, [sp, #0x250]
    1f18:      	shl.4s	v24, v24, #0x17
    1f1c:      	add.4s	v24, v24, v26
    1f20:      	fmul.4s	v24, v25, v24
    1f24:      	shl.4s	v22, v22, #0x17
    1f28:      	add.4s	v22, v22, v26
    1f2c:      	fmul.4s	v22, v23, v22
    1f30:      	mov.16b	v23, v0
    1f34:      	fcmgt.4s	v21, v21, v11
    1f38:      	ldr	q0, [sp, #0x150]
    1f3c:      	bsl.16b	v21, v0, v22
    1f40:      	fmul.4s	v7, v6, v7
    1f44:      	fcmgt.4s	v19, v19, v11
    1f48:      	bsl.16b	v19, v0, v24
    1f4c:      	fdiv.4s	v7, v7, v18
    1f50:      	ldr	q24, [sp, #0x1d0]
    1f54:      	fdiv.4s	v18, v24, v19
    1f58:      	fsub.4s	v22, v19, v18
    1f5c:      	fadd.4s	v18, v19, v18
    1f60:      	mov.16b	v19, v12
    1f64:      	fdiv.4s	v18, v22, v18
    1f68:      	bsl.16b	v17, v18, v26
    1f6c:      	fcmge.4s	v6, v26, v6
    1f70:      	bsl.16b	v6, v7, v17
    1f74:      	fdiv.4s	v7, v24, v21
    1f78:      	fsub.4s	v17, v21, v7
    1f7c:      	fadd.4s	v7, v21, v7
    1f80:      	mov.16b	v21, v13
    1f84:      	fdiv.4s	v7, v17, v7
    1f88:      	bif.16b	v7, v26, v16
    1f8c:      	fcmge.4s	v5, v26, v5
    1f90:      	bsl.16b	v5, v20, v7
    1f94:      	mvni.4s	v16, #0x80, lsl #24
    1f98:      	bif.16b	v5, v4, v16
    1f9c:      	fcmeq.4s	v4, v4, v4
    1fa0:      	fadd.4s	v5, v5, v26
    1fa4:      	ldp	q0, q7, [sp, #0x130]
    1fa8:      	bsl.16b	v4, v5, v7
    1fac:      	mvni.4s	v24, #0x80, lsl #24
    1fb0:      	mov.16b	v5, v16
    1fb4:      	bsl.16b	v5, v6, v3
    1fb8:      	fcmeq.4s	v3, v3, v3
    1fbc:      	fadd.4s	v5, v5, v26
    1fc0:      	bsl.16b	v3, v5, v7
    1fc4:      	fmul.4s	v2, v2, v29
    1fc8:      	fmul.4s	v2, v2, v3
    1fcc:      	fmul.4s	v1, v1, v29
    1fd0:      	fmul.4s	v1, v1, v4
    1fd4:      	add	x9, x24, x8
    1fd8:      	ldp	q4, q3, [x9]
    1fdc:      	fadd.4s	v1, v4, v1
    1fe0:      	fadd.4s	v2, v3, v2
    1fe4:      	add	x9, x20, x8
    1fe8:      	stp	q1, q2, [x9]
    1fec:      	add	x8, x8, #0x20
    1ff0:      	cmp	x8, #0x4, lsl #12       ; =0x4000
    1ff4:      	b.ne	0x1c7c <ltmp0+0x1c7c>
    1ff8:      	b	0x1510 <ltmp0+0x1510>
    1ffc:      	mov	x10, #0x0               ; =0
    2000:      	add	x12, x11, x14
    2004:      	b	0x2028 <ltmp0+0x2028>
    2008:      	add	x13, x23, x10
    200c:      	ldp	q25, q26, [x13]
    2010:      	bif.16b	v22, v26, v1
    2014:      	bif.16b	v20, v25, v0
    2018:      	stp	q20, q22, [x13]
    201c:      	add	x10, x10, #0x20
    2020:      	cmp	x10, #0x4, lsl #12      ; =0x4000
    2024:      	b.eq	0x20cc <ltmp0+0x20cc>
    2028:      	ldr	q18, [x0]
    202c:      	and.16b	v18, v19, v18
    2030:      	addv.8h	h18, v18
    2034:      	fmov	w14, s18
    2038:      	add	x13, x12, x10
    203c:      	movi.2d	v20, #0000000000000000
    2040:      	movi.2d	v22, #0000000000000000
    2044:      	tbz	w14, #0x0, 0x2088 <ltmp0+0x2088>
    2048:      	ldr	s20, [x13]
    204c:      	and	w14, w14, #0xff
    2050:      	tbnz	w14, #0x1, 0x2090 <ltmp0+0x2090>
    2054:      	tbz	w14, #0x2, 0x209c <ltmp0+0x209c>
    2058:      	add	x15, x13, #0x8
    205c:      	ld1.s	{ v20 }[2], [x15]
    2060:      	tbnz	w14, #0x3, 0x20a0 <ltmp0+0x20a0>
    2064:      	tbz	w14, #0x4, 0x20ac <ltmp0+0x20ac>
    2068:      	add	x15, x13, #0x10
    206c:      	ld1.s	{ v22 }[0], [x15]
    2070:      	tbnz	w14, #0x5, 0x20b0 <ltmp0+0x20b0>
    2074:      	tbz	w14, #0x6, 0x20bc <ltmp0+0x20bc>
    2078:      	add	x15, x13, #0x18
    207c:      	ld1.s	{ v22 }[2], [x15]
    2080:      	tbz	w14, #0x7, 0x2008 <ltmp0+0x2008>
    2084:      	b	0x20c0 <ltmp0+0x20c0>
    2088:      	and	w14, w14, #0xff
    208c:      	tbz	w14, #0x1, 0x2054 <ltmp0+0x2054>
    2090:      	add	x15, x13, #0x4
    2094:      	ld1.s	{ v20 }[1], [x15]
    2098:      	tbnz	w14, #0x2, 0x2058 <ltmp0+0x2058>
    209c:      	tbz	w14, #0x3, 0x2064 <ltmp0+0x2064>
    20a0:      	add	x15, x13, #0xc
    20a4:      	ld1.s	{ v20 }[3], [x15]
    20a8:      	tbnz	w14, #0x4, 0x2068 <ltmp0+0x2068>
    20ac:      	tbz	w14, #0x5, 0x2074 <ltmp0+0x2074>
    20b0:      	add	x15, x13, #0x14
    20b4:      	ld1.s	{ v22 }[1], [x15]
    20b8:      	tbnz	w14, #0x6, 0x2078 <ltmp0+0x2078>
    20bc:      	tbz	w14, #0x7, 0x2008 <ltmp0+0x2008>
    20c0:      	add	x13, x13, #0x1c
    20c4:      	ld1.s	{ v22 }[3], [x13]
    20c8:      	b	0x2008 <ltmp0+0x2008>
    20cc:      	xtn.4h	v19, v0
    20d0:      	uzp1.8b	v20, v19, v0
    20d4:      	movi.2d	v19, #0000000000000000
    20d8:      	mov.b	v19[0], v20[0]
    20dc:      	adrp	x10, 0x2000 <ltmp0+0x2000>
    20e0:      	ldr	d25, [x10]
    20e4:      	and.8b	v22, v19, v25
    20e8:      	addv.8b	b22, v22
    20ec:      	fmov	w13, s22
    20f0:      	umaxv.8b	b22, v19
    20f4:      	fmov	w14, s22
    20f8:      	rbit	w10, w13
    20fc:      	clz	w10, w10
    2100:      	tst	w14, #0x1
    2104:      	csel	w10, w10, wzr, ne
    2108:      	mov	w12, #0x1000            ; =4096
    210c:      	dup.2d	v26, x12
    2110:      	umlal.2d	v21, v28, v6
    2114:      	movi.2d	v22, #0000000000000000
    2118:      	mov.b	v22[0], v20[0]
    211c:      	add.2d	v5, v21, v26
    2120:      	ushll.2d	v17, v22, #0x0
    2124:      	shl.2d	v17, v17, #0x3f
    2128:      	cmlt.2d	v17, v17, #0
    212c:      	str	q5, [sp, #0xa0]
    2130:      	and.16b	v17, v17, v5
    2134:      	movi.2d	v5, #0000000000000000
    2138:      	stp	q5, q5, [sp, #0x3a0]
    213c:      	stp	q17, q5, [sp, #0x380]
    2140:      	and	x12, x10, #0x7
    2144:      	add	x15, sp, #0x380
    2148:      	ldr	x12, [x15, x12, lsl #3]
    214c:      	sub	x12, x12, x10
    2150:      	lsl	x12, x12, #2
    2154:      	add	x11, x11, x12
    2158:      	movi.2d	v22, #0000000000000000
    215c:      	movi.2d	v17, #0000000000000000
    2160:      	tbz	w14, #0x0, 0x21a0 <ltmp0+0x21a0>
    2164:      	ldr	s22, [x11]
    2168:      	tbnz	w13, #0x1, 0x21a4 <ltmp0+0x21a4>
    216c:      	tbz	w13, #0x2, 0x21b0 <ltmp0+0x21b0>
    2170:      	add	x14, x11, #0x8
    2174:      	ld1.s	{ v22 }[2], [x14]
    2178:      	tbnz	w13, #0x3, 0x21b4 <ltmp0+0x21b4>
    217c:      	tbz	w13, #0x4, 0x21c0 <ltmp0+0x21c0>
    2180:      	add	x14, x11, #0x10
    2184:      	ld1.s	{ v17 }[0], [x14]
    2188:      	tbnz	w13, #0x5, 0x21c4 <ltmp0+0x21c4>
    218c:      	tbz	w13, #0x6, 0x21d0 <ltmp0+0x21d0>
    2190:      	add	x14, x11, #0x18
    2194:      	ld1.s	{ v17 }[2], [x14]
    2198:      	tbnz	w13, #0x7, 0x21d4 <ltmp0+0x21d4>
    219c:      	b	0x21dc <ltmp0+0x21dc>
    21a0:      	tbz	w13, #0x1, 0x216c <ltmp0+0x216c>
    21a4:      	add	x14, x11, #0x4
    21a8:      	ld1.s	{ v22 }[1], [x14]
    21ac:      	tbnz	w13, #0x2, 0x2170 <ltmp0+0x2170>
    21b0:      	tbz	w13, #0x3, 0x217c <ltmp0+0x217c>
    21b4:      	add	x14, x11, #0xc
    21b8:      	ld1.s	{ v22 }[3], [x14]
    21bc:      	tbnz	w13, #0x4, 0x2180 <ltmp0+0x2180>
    21c0:      	tbz	w13, #0x5, 0x218c <ltmp0+0x218c>
    21c4:      	add	x14, x11, #0x14
    21c8:      	ld1.s	{ v17 }[1], [x14]
    21cc:      	tbnz	w13, #0x6, 0x2190 <ltmp0+0x2190>
    21d0:      	tbz	w13, #0x7, 0x21dc <ltmp0+0x21dc>
    21d4:      	add	x11, x11, #0x1c
    21d8:      	ld1.s	{ v17 }[3], [x11]
    21dc:      	mov	x15, #0x0               ; =0
    21e0:      	umull.2d	v21, v28, v6
    21e4:      	umlal.2d	v4, v16, v6
    21e8:      	add.2d	v4, v4, v26
    21ec:      	umlal.2d	v3, v27, v6
    21f0:      	add.2d	v3, v3, v26
    21f4:      	stp	q3, q4, [sp, #0x80]
    21f8:      	umlal.2d	v2, v7, v6
    21fc:      	adrp	x11, 0x2000 <ltmp0+0x2000>
    2200:      	ldr	q5, [x11]
    2204:      	mov	w11, #0x4000            ; =16384
    2208:      	dup.2d	v6, x11
    220c:      	sshll.2d	v7, v0, #0x0
    2210:      	bif.16b	v5, v6, v7
    2214:      	adrp	x11, 0x2000 <ltmp0+0x2000>
    2218:      	ldr	q7, [x11]
    221c:      	sshll.2d	v16, v1, #0x0
    2220:      	bif.16b	v7, v6, v16
    2224:      	adrp	x11, 0x2000 <ltmp0+0x2000>
    2228:      	ldr	q16, [x11]
    222c:      	bif.16b	v16, v6, v24
    2230:      	adrp	x11, 0x2000 <ltmp0+0x2000>
    2234:      	ldr	q24, [x11]
    2238:      	bit.16b	v6, v24, v23
    223c:      	stp	q7, q6, [sp, #0x360]
    2240:      	stp	q5, q16, [sp, #0x340]
    2244:      	and	x11, x10, #0x7
    2248:      	add	x14, sp, #0x340
    224c:      	ldr	x11, [x14, x11, lsl #3]
    2250:      	add.2d	v2, v2, v26
    2254:      	str	q2, [sp, #0x70]
    2258:      	sub	x11, x11, x10, lsl #2
    225c:      	tst	w13, #0xff
    2260:      	csel	x11, xzr, x11, eq
    2264:      	add	x13, x23, x11
    2268:      	ldp	q5, q6, [x13]
    226c:      	zip2.8b	v7, v19, v0
    2270:      	ushll.4s	v7, v7, #0x0
    2274:      	shl.4s	v7, v7, #0x1f
    2278:      	cmlt.4s	v7, v7, #0
    227c:      	bit.16b	v6, v17, v7
    2280:      	zip1.8b	v7, v19, v0
    2284:      	ushll.4s	v7, v7, #0x0
    2288:      	shl.4s	v7, v7, #0x1f
    228c:      	cmlt.4s	v7, v7, #0
    2290:      	bit.16b	v5, v22, v7
    2294:      	stp	q5, q6, [x13]
    2298:      	fmov	x13, d21
    229c:      	lsl	x13, x13, #2
    22a0:      	mov	w14, #0x1               ; =1
    22a4:      	dup.2d	v5, x14
    22a8:      	add	x14, x9, x13
    22ac:      	ushll2.2d	v6, v1, #0x0
    22b0:      	and.16b	v6, v6, v5
    22b4:      	ushll2.2d	v7, v0, #0x0
    22b8:      	and.16b	v7, v7, v5
    22bc:      	ushll.2d	v16, v1, #0x0
    22c0:      	and.16b	v16, v16, v5
    22c4:      	ushll.2d	v21, v0, #0x0
    22c8:      	and.16b	v21, v21, v5
    22cc:      	movi.2d	v5, #0000000000000000
    22d0:      	movi.2d	v23, #0000000000000000
    22d4:      	movi.2d	v24, #0000000000000000
    22d8:      	movi.2d	v26, #0000000000000000
    22dc:      	b	0x2310 <ltmp0+0x2310>
    22e0:      	add	x15, x24, x15
    22e4:      	ldp	q29, q30, [x15]
    22e8:      	bif.16b	v28, v30, v1
    22ec:      	bif.16b	v27, v29, v0
    22f0:      	stp	q27, q28, [x15]
    22f4:      	add.2d	v23, v23, v7
    22f8:      	add.2d	v24, v24, v16
    22fc:      	add.2d	v26, v26, v6
    2300:      	add.2d	v5, v5, v21
    2304:      	fmov	x15, d5
    2308:      	cmp	x15, #0x200
    230c:      	b.ge	0x23ac <ltmp0+0x23ac>
    2310:      	fmov	w17, s18
    2314:      	lsl	x15, x15, #5
    2318:      	add	x16, x14, x15
    231c:      	movi.2d	v27, #0000000000000000
    2320:      	movi.2d	v28, #0000000000000000
    2324:      	tbz	w17, #0x0, 0x2368 <ltmp0+0x2368>
    2328:      	ldr	s27, [x16]
    232c:      	and	w17, w17, #0xff
    2330:      	tbnz	w17, #0x1, 0x2370 <ltmp0+0x2370>
    2334:      	tbz	w17, #0x2, 0x237c <ltmp0+0x237c>
    2338:      	add	x0, x16, #0x8
    233c:      	ld1.s	{ v27 }[2], [x0]
    2340:      	tbnz	w17, #0x3, 0x2380 <ltmp0+0x2380>
    2344:      	tbz	w17, #0x4, 0x238c <ltmp0+0x238c>
    2348:      	add	x0, x16, #0x10
    234c:      	ld1.s	{ v28 }[0], [x0]
    2350:      	tbnz	w17, #0x5, 0x2390 <ltmp0+0x2390>
    2354:      	tbz	w17, #0x6, 0x239c <ltmp0+0x239c>
    2358:      	add	x0, x16, #0x18
    235c:      	ld1.s	{ v28 }[2], [x0]
    2360:      	tbz	w17, #0x7, 0x22e0 <ltmp0+0x22e0>
    2364:      	b	0x23a0 <ltmp0+0x23a0>
    2368:      	and	w17, w17, #0xff
    236c:      	tbz	w17, #0x1, 0x2334 <ltmp0+0x2334>
    2370:      	add	x0, x16, #0x4
    2374:      	ld1.s	{ v27 }[1], [x0]
    2378:      	tbnz	w17, #0x2, 0x2338 <ltmp0+0x2338>
    237c:      	tbz	w17, #0x3, 0x2344 <ltmp0+0x2344>
    2380:      	add	x0, x16, #0xc
    2384:      	ld1.s	{ v27 }[3], [x0]
    2388:      	tbnz	w17, #0x4, 0x2348 <ltmp0+0x2348>
    238c:      	tbz	w17, #0x5, 0x2354 <ltmp0+0x2354>
    2390:      	add	x0, x16, #0x14
    2394:      	ld1.s	{ v28 }[1], [x0]
    2398:      	tbnz	w17, #0x6, 0x2358 <ltmp0+0x2358>
    239c:      	tbz	w17, #0x7, 0x22e0 <ltmp0+0x22e0>
    23a0:      	add	x16, x16, #0x1c
    23a4:      	ld1.s	{ v28 }[3], [x16]
    23a8:      	b	0x22e0 <ltmp0+0x22e0>
    23ac:      	add	x9, x9, x12
    23b0:      	shl.8b	v5, v19, #0x7
    23b4:      	cmlt.8b	v5, v5, #0
    23b8:      	and.8b	v5, v5, v25
    23bc:      	addv.8b	b24, v5
    23c0:      	fmov	w12, s24
    23c4:      	movi.2d	v23, #0000000000000000
    23c8:      	movi.2d	v5, #0000000000000000
    23cc:      	tbz	w12, #0x0, 0x2410 <ltmp0+0x2410>
    23d0:      	ldr	s23, [x9]
    23d4:      	tbnz	w12, #0x1, 0x2414 <ltmp0+0x2414>
    23d8:      	tbz	w12, #0x2, 0x2420 <ltmp0+0x2420>
    23dc:      	add	x14, x9, #0x8
    23e0:      	ld1.s	{ v23 }[2], [x14]
    23e4:      	tbnz	w12, #0x3, 0x2424 <ltmp0+0x2424>
    23e8:      	tbz	w12, #0x4, 0x2430 <ltmp0+0x2430>
    23ec:      	add	x14, x9, #0x10
    23f0:      	ld1.s	{ v5 }[0], [x14]
    23f4:      	tbnz	w12, #0x5, 0x2434 <ltmp0+0x2434>
    23f8:      	tbz	w12, #0x6, 0x2440 <ltmp0+0x2440>
    23fc:      	add	x14, x9, #0x18
    2400:      	ld1.s	{ v5 }[2], [x14]
    2404:      	movi.2d	v20, #0xffffffffffffffff
    2408:      	tbnz	w12, #0x7, 0x2448 <ltmp0+0x2448>
    240c:      	b	0x2450 <ltmp0+0x2450>
    2410:      	tbz	w12, #0x1, 0x23d8 <ltmp0+0x23d8>
    2414:      	add	x14, x9, #0x4
    2418:      	ld1.s	{ v23 }[1], [x14]
    241c:      	tbnz	w12, #0x2, 0x23dc <ltmp0+0x23dc>
    2420:      	tbz	w12, #0x3, 0x23e8 <ltmp0+0x23e8>
    2424:      	add	x14, x9, #0xc
    2428:      	ld1.s	{ v23 }[3], [x14]
    242c:      	tbnz	w12, #0x4, 0x23ec <ltmp0+0x23ec>
    2430:      	tbz	w12, #0x5, 0x23f8 <ltmp0+0x23f8>
    2434:      	add	x14, x9, #0x14
    2438:      	ld1.s	{ v5 }[1], [x14]
    243c:      	tbnz	w12, #0x6, 0x23fc <ltmp0+0x23fc>
    2440:      	movi.2d	v20, #0xffffffffffffffff
    2444:      	tbz	w12, #0x7, 0x2450 <ltmp0+0x2450>
    2448:      	add	x9, x9, #0x1c
    244c:      	ld1.s	{ v5 }[3], [x9]
    2450:      	mov	x12, #0x0               ; =0
    2454:      	add	x9, x24, x11
    2458:      	ldp	q25, q26, [x9]
    245c:      	zip2.8b	v27, v19, v0
    2460:      	ushll.4s	v27, v27, #0x0
    2464:      	shl.4s	v27, v27, #0x1f
    2468:      	cmlt.4s	v27, v27, #0
    246c:      	bit.16b	v26, v5, v27
    2470:      	zip1.8b	v27, v19, v0
    2474:      	ushll.4s	v27, v27, #0x0
    2478:      	shl.4s	v27, v27, #0x1f
    247c:      	cmlt.4s	v27, v27, #0
    2480:      	bit.16b	v25, v23, v27
    2484:      	stp	q25, q26, [x9]
    2488:      	add	x9, x8, x13
    248c:      	movi.2d	v25, #0000000000000000
    2490:      	movi.2d	v26, #0000000000000000
    2494:      	movi.2d	v27, #0000000000000000
    2498:      	movi.2d	v28, #0000000000000000
    249c:      	b	0x24bc <ltmp0+0x24bc>
    24a0:      	add.2d	v26, v26, v7
    24a4:      	add.2d	v27, v27, v16
    24a8:      	add.2d	v28, v28, v6
    24ac:      	add.2d	v25, v25, v21
    24b0:      	fmov	x12, d25
    24b4:      	cmp	x12, #0x200
    24b8:      	b.ge	0x28d4 <ltmp0+0x28d4>
    24bc:      	lsl	x11, x12, #5
    24c0:      	add	x12, x23, x11
    24c4:      	ldr	q29, [x12]
    24c8:      	and.16b	v29, v0, v29
    24cc:      	ldp	q2, q3, [sp, #0xb0]
    24d0:      	fmul.4s	v30, v29, v3
    24d4:      	fmul.4s	v30, v29, v30
    24d8:      	fmul.4s	v30, v29, v30
    24dc:      	fadd.4s	v30, v29, v30
    24e0:      	fmul.4s	v30, v30, v2
    24e4:      	and.16b	v30, v0, v30
    24e8:      	fabs.4s	v31, v30
    24ec:      	fmul.4s	v8, v30, v30
    24f0:      	ldp	q9, q2, [sp, #0x120]
    24f4:      	fmla.4s	v9, v8, v2
    24f8:      	ldr	q10, [sp, #0xd0]
    24fc:      	fmla.4s	v10, v8, v9
    2500:      	ldr	q9, [sp, #0x110]
    2504:      	fmla.4s	v9, v8, v10
    2508:      	ldp	q4, q10, [sp, #0xf0]
    250c:      	fmla.4s	v10, v8, v9
    2510:      	mov.16b	v9, v4
    2514:      	fmla.4s	v9, v8, v10
    2518:      	ldr	q3, [sp, #0x250]
    251c:      	mov.16b	v10, v3
    2520:      	fmla.4s	v10, v8, v9
    2524:      	fmul.4s	v9, v31, v10
    2528:      	ldp	q11, q10, [sp, #0x230]
    252c:      	fmla.4s	v10, v8, v11
    2530:      	ldr	q11, [sp, #0x170]
    2534:      	fmla.4s	v11, v8, v10
    2538:      	ldr	q10, [sp, #0x1e0]
    253c:      	fmla.4s	v10, v8, v11
    2540:      	ldr	q11, [sp, #0x160]
    2544:      	fmla.4s	v11, v8, v10
    2548:      	movi.4s	v10, #0x3f, lsl #24
    254c:      	fmla.4s	v10, v8, v11
    2550:      	mov.16b	v11, v3
    2554:      	fmla.4s	v11, v8, v10
    2558:      	fdiv.4s	v8, v9, v11
    255c:      	ldr	q9, [sp, #0x180]
    2560:      	fcmge.4s	v9, v9, v31
    2564:      	and.16b	v10, v9, v31
    2568:      	ldr	q11, [sp, #0x220]
    256c:      	fcmge.4s	v11, v10, v11
    2570:      	ldr	q2, [sp, #0xe0]
    2574:      	fcmge.4s	v12, v2, v10
    2578:      	and.16b	v11, v11, v12
    257c:      	and.16b	v11, v11, v10
    2580:      	ldp	q14, q12, [sp, #0x1b0]
    2584:      	fmul.4s	v12, v11, v12
    2588:      	movi.4s	v13, #0x4b, lsl #24
    258c:      	fadd.4s	v12, v12, v13
    2590:      	movi.4s	v13, #0xcb, lsl #24
    2594:      	fadd.4s	v12, v12, v13
    2598:      	fcvtzs.4s	v12, v12
    259c:      	scvtf.4s	v13, v12
    25a0:      	fmul.4s	v14, v13, v14
    25a4:      	fadd.4s	v11, v11, v14
    25a8:      	ldr	q14, [sp, #0x1a0]
    25ac:      	fmul.4s	v13, v13, v14
    25b0:      	fadd.4s	v11, v11, v13
    25b4:      	ldp	q14, q13, [sp, #0x200]
    25b8:      	fmul.4s	v13, v11, v13
    25bc:      	fadd.4s	v13, v13, v14
    25c0:      	fmul.4s	v13, v11, v13
    25c4:      	ldr	q14, [sp, #0x1f0]
    25c8:      	fadd.4s	v13, v13, v14
    25cc:      	fmul.4s	v13, v11, v13
    25d0:      	fadd.4s	v13, v13, v15
    25d4:      	fmul.4s	v13, v11, v13
    25d8:      	fadd.4s	v13, v13, v4
    25dc:      	fmul.4s	v13, v11, v13
    25e0:      	movi.4s	v4, #0x3f, lsl #24
    25e4:      	fadd.4s	v13, v13, v4
    25e8:      	fmul.4s	v14, v11, v11
    25ec:      	fmul.4s	v13, v14, v13
    25f0:      	fadd.4s	v11, v11, v13
    25f4:      	fadd.4s	v11, v11, v3
    25f8:      	add.4s	v12, v12, v20
    25fc:      	sshr.4s	v13, v12, #0x1
    2600:      	shl.4s	v14, v13, #0x17
    2604:      	add.4s	v14, v14, v3
    2608:      	fmul.4s	v11, v11, v14
    260c:      	sub.4s	v12, v12, v13
    2610:      	shl.4s	v12, v12, #0x17
    2614:      	add.4s	v12, v12, v3
    2618:      	fmul.4s	v11, v11, v12
    261c:      	fcmgt.4s	v10, v10, v2
    2620:      	ldr	q2, [sp, #0x150]
    2624:      	bsl.16b	v10, v2, v11
    2628:      	ldr	q2, [sp, #0x1d0]
    262c:      	fdiv.4s	v11, v2, v10
    2630:      	fsub.4s	v12, v10, v11
    2634:      	fadd.4s	v10, v10, v11
    2638:      	fdiv.4s	v10, v12, v10
    263c:      	bsl.16b	v9, v10, v3
    2640:      	fcmge.4s	v31, v3, v31
    2644:      	bsl.16b	v31, v8, v9
    2648:      	mvni.4s	v2, #0x80, lsl #24
    264c:      	bif.16b	v31, v30, v2
    2650:      	fcmeq.4s	v30, v30, v30
    2654:      	fadd.4s	v31, v31, v3
    2658:      	ldr	q2, [sp, #0x140]
    265c:      	bif.16b	v31, v2, v30
    2660:      	ldr	q30, [x12, #0x10]
    2664:      	fmul.4s	v29, v29, v4
    2668:      	fmul.4s	v29, v29, v31
    266c:      	add	x12, x24, x11
    2670:      	ldr	q31, [x12]
    2674:      	and.16b	v31, v0, v31
    2678:      	fadd.4s	v31, v31, v29
    267c:      	ldr	q29, [x12, #0x10]
    2680:      	fmov	w12, s18
    2684:      	add	x11, x9, x11
    2688:      	tbz	w12, #0x0, 0x26b8 <ltmp0+0x26b8>
    268c:      	str	s31, [x11]
    2690:      	and	w12, w12, #0xff
    2694:      	tbnz	w12, #0x1, 0x26c0 <ltmp0+0x26c0>
    2698:      	ldp	q9, q8, [sp, #0xb0]
    269c:      	ldp	q10, q11, [sp, #0x120]
    26a0:      	ldr	q12, [sp, #0xd0]
    26a4:      	tbz	w12, #0x2, 0x26d8 <ltmp0+0x26d8>
    26a8:      	add	x13, x11, #0x8
    26ac:      	st1.s	{ v31 }[2], [x13]
    26b0:      	tbnz	w12, #0x3, 0x26dc <ltmp0+0x26dc>
    26b4:      	b	0x26e4 <ltmp0+0x26e4>
    26b8:      	and	w12, w12, #0xff
    26bc:      	tbz	w12, #0x1, 0x2698 <ltmp0+0x2698>
    26c0:      	add	x13, x11, #0x4
    26c4:      	st1.s	{ v31 }[1], [x13]
    26c8:      	ldp	q9, q8, [sp, #0xb0]
    26cc:      	ldp	q10, q11, [sp, #0x120]
    26d0:      	ldr	q12, [sp, #0xd0]
    26d4:      	tbnz	w12, #0x2, 0x26a8 <ltmp0+0x26a8>
    26d8:      	tbz	w12, #0x3, 0x26e4 <ltmp0+0x26e4>
    26dc:      	add	x13, x11, #0xc
    26e0:      	st1.s	{ v31 }[3], [x13]
    26e4:      	and.16b	v30, v1, v30
    26e8:      	fmul.4s	v31, v30, v8
    26ec:      	fmul.4s	v31, v30, v31
    26f0:      	fmul.4s	v31, v30, v31
    26f4:      	fadd.4s	v31, v30, v31
    26f8:      	fmul.4s	v31, v31, v9
    26fc:      	and.16b	v31, v1, v31
    2700:      	fabs.4s	v8, v31
    2704:      	fmul.4s	v9, v31, v31
    2708:      	fmla.4s	v10, v9, v11
    270c:      	mov.16b	v11, v12
    2710:      	fmla.4s	v11, v9, v10
    2714:      	ldr	q10, [sp, #0x110]
    2718:      	fmla.4s	v10, v9, v11
    271c:      	ldp	q4, q11, [sp, #0xf0]
    2720:      	fmla.4s	v11, v9, v10
    2724:      	mov.16b	v10, v4
    2728:      	fmla.4s	v10, v9, v11
    272c:      	ldr	q3, [sp, #0x250]
    2730:      	mov.16b	v11, v3
    2734:      	fmla.4s	v11, v9, v10
    2738:      	fmul.4s	v10, v8, v11
    273c:      	ldp	q12, q11, [sp, #0x230]
    2740:      	fmla.4s	v11, v9, v12
    2744:      	ldr	q12, [sp, #0x170]
    2748:      	fmla.4s	v12, v9, v11
    274c:      	ldr	q11, [sp, #0x1e0]
    2750:      	fmla.4s	v11, v9, v12
    2754:      	ldr	q12, [sp, #0x160]
    2758:      	fmla.4s	v12, v9, v11
    275c:      	movi.4s	v11, #0x3f, lsl #24
    2760:      	fmla.4s	v11, v9, v12
    2764:      	mov.16b	v12, v3
    2768:      	fmla.4s	v12, v9, v11
    276c:      	fdiv.4s	v9, v10, v12
    2770:      	ldr	q10, [sp, #0x180]
    2774:      	fcmge.4s	v10, v10, v8
    2778:      	and.16b	v11, v10, v8
    277c:      	ldr	q12, [sp, #0x220]
    2780:      	fcmge.4s	v12, v11, v12
    2784:      	ldr	q2, [sp, #0xe0]
    2788:      	fcmge.4s	v13, v2, v11
    278c:      	and.16b	v12, v12, v13
    2790:      	and.16b	v12, v12, v11
    2794:      	ldp	q15, q13, [sp, #0x1b0]
    2798:      	fmul.4s	v13, v12, v13
    279c:      	movi.4s	v14, #0x4b, lsl #24
    27a0:      	fadd.4s	v13, v13, v14
    27a4:      	movi.4s	v14, #0xcb, lsl #24
    27a8:      	fadd.4s	v13, v13, v14
    27ac:      	fcvtzs.4s	v13, v13
    27b0:      	scvtf.4s	v14, v13
    27b4:      	fmul.4s	v15, v14, v15
    27b8:      	fadd.4s	v12, v12, v15
    27bc:      	ldr	q15, [sp, #0x1a0]
    27c0:      	fmul.4s	v14, v14, v15
    27c4:      	fadd.4s	v12, v12, v14
    27c8:      	ldp	q15, q14, [sp, #0x200]
    27cc:      	fmul.4s	v14, v12, v14
    27d0:      	fadd.4s	v14, v14, v15
    27d4:      	fmul.4s	v14, v12, v14
    27d8:      	ldr	q15, [sp, #0x1f0]
    27dc:      	fadd.4s	v14, v14, v15
    27e0:      	fmul.4s	v14, v12, v14
    27e4:      	ldr	q15, [sp, #0x190]
    27e8:      	fadd.4s	v14, v14, v15
    27ec:      	fmul.4s	v14, v12, v14
    27f0:      	fadd.4s	v14, v14, v4
    27f4:      	fmul.4s	v14, v12, v14
    27f8:      	movi.4s	v15, #0x3f, lsl #24
    27fc:      	fadd.4s	v14, v14, v15
    2800:      	fmul.4s	v15, v12, v12
    2804:      	fmul.4s	v14, v15, v14
    2808:      	fadd.4s	v12, v12, v14
    280c:      	fadd.4s	v12, v12, v3
    2810:      	add.4s	v13, v13, v20
    2814:      	sshr.4s	v14, v13, #0x1
    2818:      	shl.4s	v15, v14, #0x17
    281c:      	add.4s	v15, v15, v3
    2820:      	fmul.4s	v12, v12, v15
    2824:      	movi.4s	v4, #0x3f, lsl #24
    2828:      	sub.4s	v13, v13, v14
    282c:      	shl.4s	v13, v13, #0x17
    2830:      	add.4s	v13, v13, v3
    2834:      	fmul.4s	v12, v12, v13
    2838:      	fcmgt.4s	v11, v11, v2
    283c:      	ldr	q2, [sp, #0x150]
    2840:      	bsl.16b	v11, v2, v12
    2844:      	ldr	q2, [sp, #0x1d0]
    2848:      	fdiv.4s	v12, v2, v11
    284c:      	fsub.4s	v13, v11, v12
    2850:      	fadd.4s	v11, v11, v12
    2854:      	fdiv.4s	v11, v13, v11
    2858:      	bsl.16b	v10, v11, v3
    285c:      	fcmge.4s	v8, v3, v8
    2860:      	bsl.16b	v8, v9, v10
    2864:      	mvni.4s	v2, #0x80, lsl #24
    2868:      	bif.16b	v8, v31, v2
    286c:      	fcmeq.4s	v31, v31, v31
    2870:      	fadd.4s	v8, v8, v3
    2874:      	ldr	q2, [sp, #0x140]
    2878:      	bsl.16b	v31, v8, v2
    287c:      	fmul.4s	v30, v30, v4
    2880:      	fmul.4s	v30, v30, v31
    2884:      	and.16b	v29, v1, v29
    2888:      	fadd.4s	v29, v29, v30
    288c:      	tbz	w12, #0x4, 0x28b0 <ltmp0+0x28b0>
    2890:      	str	s29, [x11, #0x10]
    2894:      	tbnz	w12, #0x5, 0x28b4 <ltmp0+0x28b4>
    2898:      	ldr	q15, [sp, #0x190]
    289c:      	tbz	w12, #0x6, 0x28c4 <ltmp0+0x28c4>
    28a0:      	add	x13, x11, #0x18
    28a4:      	st1.s	{ v29 }[2], [x13]
    28a8:      	tbz	w12, #0x7, 0x24a0 <ltmp0+0x24a0>
    28ac:      	b	0x28c8 <ltmp0+0x28c8>
    28b0:      	tbz	w12, #0x5, 0x2898 <ltmp0+0x2898>
    28b4:      	add	x13, x11, #0x14
    28b8:      	st1.s	{ v29 }[1], [x13]
    28bc:      	ldr	q15, [sp, #0x190]
    28c0:      	tbnz	w12, #0x6, 0x28a0 <ltmp0+0x28a0>
    28c4:      	tbz	w12, #0x7, 0x24a0 <ltmp0+0x24a0>
    28c8:      	add	x11, x11, #0x1c
    28cc:      	st1.s	{ v29 }[3], [x11]
    28d0:      	b	0x24a0 <ltmp0+0x24a0>
    28d4:      	ldp	q1, q0, [sp, #0xb0]
    28d8:      	fmul.4s	v0, v22, v0
    28dc:      	fmul.4s	v0, v22, v0
    28e0:      	fmul.4s	v0, v22, v0
    28e4:      	fadd.4s	v0, v22, v0
    28e8:      	fmul.4s	v0, v0, v1
    28ec:      	zip1.8b	v1, v19, v0
    28f0:      	ushll.4s	v1, v1, #0x0
    28f4:      	shl.4s	v1, v1, #0x1f
    28f8:      	cmlt.4s	v1, v1, #0
    28fc:      	and.16b	v0, v1, v0
    2900:      	fabs.4s	v1, v0
    2904:      	fmul.4s	v6, v0, v0
    2908:      	ldp	q7, q2, [sp, #0x120]
    290c:      	fmla.4s	v7, v6, v2
    2910:      	ldr	q16, [sp, #0xd0]
    2914:      	fmla.4s	v16, v6, v7
    2918:      	ldr	q7, [sp, #0x110]
    291c:      	mov.16b	v8, v7
    2920:      	fmla.4s	v7, v6, v16
    2924:      	ldp	q20, q16, [sp, #0xf0]
    2928:      	mov.16b	v14, v16
    292c:      	fmla.4s	v16, v6, v7
    2930:      	mov.16b	v7, v20
    2934:      	fmla.4s	v7, v6, v16
    2938:      	ldr	q3, [sp, #0x250]
    293c:      	mov.16b	v16, v3
    2940:      	fmla.4s	v16, v6, v7
    2944:      	fmul.4s	v7, v1, v16
    2948:      	ldp	q2, q16, [sp, #0x230]
    294c:      	fmla.4s	v16, v6, v2
    2950:      	ldp	q18, q29, [sp, #0x170]
    2954:      	mov.16b	v28, v18
    2958:      	fmla.4s	v18, v6, v16
    295c:      	ldr	q27, [sp, #0x1e0]
    2960:      	mov.16b	v16, v27
    2964:      	fmla.4s	v16, v6, v18
    2968:      	ldr	q18, [sp, #0x160]
    296c:      	fmla.4s	v18, v6, v16
    2970:      	movi.4s	v16, #0x3f, lsl #24
    2974:      	fmla.4s	v16, v6, v18
    2978:      	mov.16b	v18, v3
    297c:      	fmla.4s	v18, v6, v16
    2980:      	fdiv.4s	v6, v7, v18
    2984:      	fcmge.4s	v7, v29, v1
    2988:      	and.16b	v16, v7, v1
    298c:      	ldr	q4, [sp, #0x220]
    2990:      	fcmge.4s	v18, v16, v4
    2994:      	ldr	q11, [sp, #0xe0]
    2998:      	fcmge.4s	v21, v11, v16
    299c:      	and.16b	v18, v18, v21
    29a0:      	and.16b	v18, v18, v16
    29a4:      	ldp	q12, q10, [sp, #0x1b0]
    29a8:      	fmul.4s	v21, v18, v10
    29ac:      	movi.4s	v2, #0x4b, lsl #24
    29b0:      	fadd.4s	v21, v21, v2
    29b4:      	movi.4s	v2, #0xcb, lsl #24
    29b8:      	fadd.4s	v21, v21, v2
    29bc:      	fcvtzs.4s	v21, v21
    29c0:      	scvtf.4s	v25, v21
    29c4:      	fmul.4s	v26, v25, v12
    29c8:      	fadd.4s	v18, v18, v26
    29cc:      	ldr	q13, [sp, #0x1a0]
    29d0:      	fmul.4s	v25, v25, v13
    29d4:      	fadd.4s	v18, v18, v25
    29d8:      	ldp	q30, q2, [sp, #0x200]
    29dc:      	fmul.4s	v25, v18, v2
    29e0:      	fadd.4s	v25, v25, v30
    29e4:      	fmul.4s	v25, v18, v25
    29e8:      	ldr	q31, [sp, #0x1f0]
    29ec:      	fadd.4s	v25, v25, v31
    29f0:      	fmul.4s	v25, v18, v25
    29f4:      	fadd.4s	v25, v25, v15
    29f8:      	fmul.4s	v25, v18, v25
    29fc:      	fadd.4s	v25, v25, v20
    2a00:      	fmul.4s	v25, v18, v25
    2a04:      	movi.4s	v4, #0x3f, lsl #24
    2a08:      	fadd.4s	v25, v25, v4
    2a0c:      	fmul.4s	v26, v18, v18
    2a10:      	fmul.4s	v25, v26, v25
    2a14:      	fadd.4s	v18, v18, v25
    2a18:      	fadd.4s	v18, v18, v3
    2a1c:      	movi.2d	v2, #0xffffffffffffffff
    2a20:      	add.4s	v21, v21, v2
    2a24:      	sshr.4s	v25, v21, #0x1
    2a28:      	shl.4s	v26, v25, #0x17
    2a2c:      	add.4s	v26, v26, v3
    2a30:      	fmul.4s	v18, v18, v26
    2a34:      	mov.16b	v26, v3
    2a38:      	sub.4s	v21, v21, v25
    2a3c:      	shl.4s	v21, v21, #0x17
    2a40:      	add.4s	v21, v21, v3
    2a44:      	fmul.4s	v18, v18, v21
    2a48:      	fcmgt.4s	v16, v16, v11
    2a4c:      	ldr	q2, [sp, #0x150]
    2a50:      	bsl.16b	v16, v2, v18
    2a54:      	ldr	q9, [sp, #0x1d0]
    2a58:      	fdiv.4s	v18, v9, v16
    2a5c:      	fsub.4s	v21, v16, v18
    2a60:      	fadd.4s	v16, v16, v18
    2a64:      	fdiv.4s	v16, v21, v16
    2a68:      	bsl.16b	v7, v16, v3
    2a6c:      	fcmge.4s	v1, v3, v1
    2a70:      	bsl.16b	v1, v6, v7
    2a74:      	fmov	w9, s24
    2a78:      	mvni.4s	v24, #0x80, lsl #24
    2a7c:      	bif.16b	v1, v0, v24
    2a80:      	fcmeq.4s	v0, v0, v0
    2a84:      	fadd.4s	v1, v1, v3
    2a88:      	ldr	q2, [sp, #0x140]
    2a8c:      	bsl.16b	v0, v1, v2
    2a90:      	fmul.4s	v1, v22, v4
    2a94:      	fmul.4s	v0, v1, v0
    2a98:      	fadd.4s	v0, v0, v23
    2a9c:      	ldp	q1, q2, [sp, #0x90]
    2aa0:      	stp	q2, q1, [sp, #0x2f0]
    2aa4:      	ldp	q1, q2, [sp, #0x70]
    2aa8:      	stp	q2, q1, [sp, #0x310]
    2aac:      	and	x11, x10, #0x7
    2ab0:      	add	x12, sp, #0x2f0
    2ab4:      	ldr	x11, [x12, x11, lsl #3]
    2ab8:      	sub	x10, x11, x10
    2abc:      	add	x8, x8, x10, lsl #2
    2ac0:      	tbz	w9, #0x0, 0x2ac8 <ltmp0+0x2ac8>
    2ac4:      	str	s0, [x8]
    2ac8:      	tbz	w9, #0x1, 0x2ad4 <ltmp0+0x2ad4>
    2acc:      	add	x10, x8, #0x4
    2ad0:      	st1.s	{ v0 }[1], [x10]
    2ad4:      	ldr	q20, [sp, #0x240]
    2ad8:      	ldp	q22, q25, [sp, #0x150]
    2adc:      	ldp	q21, q7, [sp, #0x210]
    2ae0:      	movi.4s	v16, #0x4b, lsl #24
    2ae4:      	movi.4s	v18, #0xcb, lsl #24
    2ae8:      	ldr	q23, [sp, #0xd0]
    2aec:      	tbz	w9, #0x2, 0x2af8 <ltmp0+0x2af8>
    2af0:      	add	x10, x8, #0x8
    2af4:      	st1.s	{ v0 }[2], [x10]
    2af8:      	tbz	w9, #0x3, 0x2b04 <ltmp0+0x2b04>
    2afc:      	add	x10, x8, #0xc
    2b00:      	st1.s	{ v0 }[3], [x10]
    2b04:      	ldp	q1, q0, [sp, #0xb0]
    2b08:      	fmul.4s	v0, v17, v0
    2b0c:      	fmul.4s	v0, v17, v0
    2b10:      	fmul.4s	v0, v17, v0
    2b14:      	fadd.4s	v0, v17, v0
    2b18:      	fmul.4s	v0, v0, v1
    2b1c:      	zip2.8b	v1, v19, v0
    2b20:      	ushll.4s	v1, v1, #0x0
    2b24:      	shl.4s	v1, v1, #0x1f
    2b28:      	cmlt.4s	v1, v1, #0
    2b2c:      	and.16b	v0, v1, v0
    2b30:      	fabs.4s	v1, v0
    2b34:      	fmul.4s	v2, v0, v0
    2b38:      	ldp	q3, q4, [sp, #0x120]
    2b3c:      	fmla.4s	v3, v2, v4
    2b40:      	mov.16b	v4, v23
    2b44:      	fmla.4s	v4, v2, v3
    2b48:      	mov.16b	v3, v8
    2b4c:      	fmla.4s	v3, v2, v4
    2b50:      	mov.16b	v4, v14
    2b54:      	fmla.4s	v4, v2, v3
    2b58:      	ldr	q19, [sp, #0xf0]
    2b5c:      	mov.16b	v3, v19
    2b60:      	fmla.4s	v3, v2, v4
    2b64:      	mov.16b	v4, v26
    2b68:      	fmla.4s	v4, v2, v3
    2b6c:      	fmul.4s	v3, v1, v4
    2b70:      	mov.16b	v4, v20
    2b74:      	ldr	q6, [sp, #0x230]
    2b78:      	fmla.4s	v4, v2, v6
    2b7c:      	mov.16b	v6, v28
    2b80:      	fmla.4s	v6, v2, v4
    2b84:      	mov.16b	v4, v27
    2b88:      	fmla.4s	v4, v2, v6
    2b8c:      	mov.16b	v6, v25
    2b90:      	fmla.4s	v6, v2, v4
    2b94:      	movi.4s	v4, #0x3f, lsl #24
    2b98:      	fmla.4s	v4, v2, v6
    2b9c:      	mov.16b	v6, v26
    2ba0:      	fmla.4s	v6, v2, v4
    2ba4:      	fdiv.4s	v2, v3, v6
    2ba8:      	fcmge.4s	v3, v29, v1
    2bac:      	and.16b	v4, v3, v1
    2bb0:      	fcmge.4s	v6, v4, v7
    2bb4:      	fcmge.4s	v7, v11, v4
    2bb8:      	and.16b	v6, v6, v7
    2bbc:      	and.16b	v6, v6, v4
    2bc0:      	fmul.4s	v7, v6, v10
    2bc4:      	fadd.4s	v7, v7, v16
    2bc8:      	fadd.4s	v7, v7, v18
    2bcc:      	fcvtzs.4s	v7, v7
    2bd0:      	scvtf.4s	v16, v7
    2bd4:      	fmul.4s	v18, v16, v12
    2bd8:      	fadd.4s	v6, v6, v18
    2bdc:      	fmul.4s	v16, v16, v13
    2be0:      	fadd.4s	v6, v6, v16
    2be4:      	fmul.4s	v16, v6, v21
    2be8:      	fadd.4s	v16, v16, v30
    2bec:      	fmul.4s	v16, v6, v16
    2bf0:      	fadd.4s	v16, v16, v31
    2bf4:      	fmul.4s	v16, v6, v16
    2bf8:      	fadd.4s	v16, v16, v15
    2bfc:      	fmul.4s	v16, v6, v16
    2c00:      	fadd.4s	v16, v16, v19
    2c04:      	fmul.4s	v16, v6, v16
    2c08:      	movi.4s	v19, #0x3f, lsl #24
    2c0c:      	fadd.4s	v16, v16, v19
    2c10:      	fmul.4s	v18, v6, v6
    2c14:      	fmul.4s	v16, v18, v16
    2c18:      	fadd.4s	v6, v6, v16
    2c1c:      	fadd.4s	v6, v6, v26
    2c20:      	movi.2d	v16, #0xffffffffffffffff
    2c24:      	add.4s	v7, v7, v16
    2c28:      	sshr.4s	v16, v7, #0x1
    2c2c:      	shl.4s	v18, v16, #0x17
    2c30:      	add.4s	v18, v18, v26
    2c34:      	fmul.4s	v6, v6, v18
    2c38:      	sub.4s	v7, v7, v16
    2c3c:      	shl.4s	v7, v7, #0x17
    2c40:      	add.4s	v7, v7, v26
    2c44:      	fmul.4s	v6, v6, v7
    2c48:      	fcmgt.4s	v4, v4, v11
    2c4c:      	bsl.16b	v4, v22, v6
    2c50:      	fdiv.4s	v6, v9, v4
    2c54:      	fsub.4s	v7, v4, v6
    2c58:      	fadd.4s	v4, v4, v6
    2c5c:      	fdiv.4s	v4, v7, v4
    2c60:      	bsl.16b	v3, v4, v26
    2c64:      	fcmge.4s	v1, v26, v1
    2c68:      	bsl.16b	v1, v2, v3
    2c6c:      	bif.16b	v1, v0, v24
    2c70:      	fcmeq.4s	v0, v0, v0
    2c74:      	fadd.4s	v1, v1, v26
    2c78:      	ldr	q18, [sp, #0x140]
    2c7c:      	bsl.16b	v0, v1, v18
    2c80:      	fmul.4s	v1, v17, v19
    2c84:      	fmul.4s	v0, v1, v0
    2c88:      	fadd.4s	v0, v0, v5
    2c8c:      	tbz	w9, #0x4, 0x2cb8 <ltmp0+0x2cb8>
    2c90:      	str	s0, [x8, #0x10]
    2c94:      	tbnz	w9, #0x5, 0x2cbc <ltmp0+0x2cbc>
    2c98:      	ldr	q21, [sp, #0xb0]
    2c9c:      	mov.16b	v30, v8
    2ca0:      	mov.16b	v9, v14
    2ca4:      	tbz	w9, #0x6, 0x323c <ltmp0+0x323c>
    2ca8:      	add	x10, x8, #0x18
    2cac:      	st1.s	{ v0 }[2], [x10]
    2cb0:      	tbnz	w9, #0x7, 0x3240 <ltmp0+0x3240>
    2cb4:      	b	0x1bc <ltmp0+0x1bc>
    2cb8:      	tbz	w9, #0x5, 0x2c98 <ltmp0+0x2c98>
    2cbc:      	add	x10, x8, #0x14
    2cc0:      	st1.s	{ v0 }[1], [x10]
    2cc4:      	ldr	q21, [sp, #0xb0]
    2cc8:      	mov.16b	v30, v8
    2ccc:      	mov.16b	v9, v14
    2cd0:      	tbz	w9, #0x6, 0x323c <ltmp0+0x323c>
    2cd4:      	b	0x2ca8 <ltmp0+0x2ca8>
    2cd8:      	xtn.4h	v0, v0
    2cdc:      	uzp1.8b	v0, v0, v0
    2ce0:      	movi.2d	v1, #0000000000000000
    2ce4:      	mov.b	v1[0], v0[0]
    2ce8:      	adrp	x10, 0x2000 <ltmp0+0x2000>
    2cec:      	ldr	d19, [x10]
    2cf0:      	and.8b	v18, v1, v19
    2cf4:      	addv.8b	b18, v18
    2cf8:      	fmov	w12, s18
    2cfc:      	umaxv.8b	b18, v1
    2d00:      	fmov	w14, s18
    2d04:      	rbit	w10, w12
    2d08:      	clz	w10, w10
    2d0c:      	tst	w14, #0x1
    2d10:      	csel	w10, w10, wzr, ne
    2d14:      	mov	w13, #0x1000            ; =4096
    2d18:      	dup.2d	v18, x13
    2d1c:      	ldr	d5, [sp, #0x60]
    2d20:      	umlal.2d	v21, v5, v6
    2d24:      	movi.2d	v20, #0000000000000000
    2d28:      	mov.b	v20[0], v0[0]
    2d2c:      	add.2d	v5, v21, v18
    2d30:      	ushll.2d	v0, v20, #0x0
    2d34:      	shl.2d	v0, v0, #0x3f
    2d38:      	cmlt.2d	v0, v0, #0
    2d3c:      	str	q5, [sp, #0x60]
    2d40:      	and.16b	v0, v0, v5
    2d44:      	movi.2d	v5, #0000000000000000
    2d48:      	stp	q5, q5, [sp, #0x2c0]
    2d4c:      	stp	q0, q5, [sp, #0x2a0]
    2d50:      	and	x13, x10, #0x7
    2d54:      	add	x15, sp, #0x2a0
    2d58:      	ldr	x13, [x15, x13, lsl #3]
    2d5c:      	sub	x13, x13, x10
    2d60:      	lsl	x13, x13, #2
    2d64:      	add	x11, x11, x13
    2d68:      	movi.2d	v20, #0000000000000000
    2d6c:      	movi.2d	v0, #0000000000000000
    2d70:      	tbz	w14, #0x0, 0x2db0 <ltmp0+0x2db0>
    2d74:      	ldr	s20, [x11]
    2d78:      	tbnz	w12, #0x1, 0x2db4 <ltmp0+0x2db4>
    2d7c:      	tbz	w12, #0x2, 0x2dc0 <ltmp0+0x2dc0>
    2d80:      	add	x14, x11, #0x8
    2d84:      	ld1.s	{ v20 }[2], [x14]
    2d88:      	tbnz	w12, #0x3, 0x2dc4 <ltmp0+0x2dc4>
    2d8c:      	tbz	w12, #0x4, 0x2dd0 <ltmp0+0x2dd0>
    2d90:      	add	x14, x11, #0x10
    2d94:      	ld1.s	{ v0 }[0], [x14]
    2d98:      	tbnz	w12, #0x5, 0x2dd4 <ltmp0+0x2dd4>
    2d9c:      	tbz	w12, #0x6, 0x2de0 <ltmp0+0x2de0>
    2da0:      	add	x14, x11, #0x18
    2da4:      	ld1.s	{ v0 }[2], [x14]
    2da8:      	tbnz	w12, #0x7, 0x2de4 <ltmp0+0x2de4>
    2dac:      	b	0x2dec <ltmp0+0x2dec>
    2db0:      	tbz	w12, #0x1, 0x2d7c <ltmp0+0x2d7c>
    2db4:      	add	x14, x11, #0x4
    2db8:      	ld1.s	{ v20 }[1], [x14]
    2dbc:      	tbnz	w12, #0x2, 0x2d80 <ltmp0+0x2d80>
    2dc0:      	tbz	w12, #0x3, 0x2d8c <ltmp0+0x2d8c>
    2dc4:      	add	x14, x11, #0xc
    2dc8:      	ld1.s	{ v20 }[3], [x14]
    2dcc:      	tbnz	w12, #0x4, 0x2d90 <ltmp0+0x2d90>
    2dd0:      	tbz	w12, #0x5, 0x2d9c <ltmp0+0x2d9c>
    2dd4:      	add	x14, x11, #0x14
    2dd8:      	ld1.s	{ v0 }[1], [x14]
    2ddc:      	tbnz	w12, #0x6, 0x2da0 <ltmp0+0x2da0>
    2de0:      	tbz	w12, #0x7, 0x2dec <ltmp0+0x2dec>
    2de4:      	add	x11, x11, #0x1c
    2de8:      	ld1.s	{ v0 }[3], [x11]
    2dec:      	shl.8b	v21, v1, #0x7
    2df0:      	cmlt.8b	v21, v21, #0
    2df4:      	and.8b	v19, v21, v19
    2df8:      	addv.8b	b21, v19
    2dfc:      	fmov	w11, s21
    2e00:      	add	x9, x9, x13
    2e04:      	movi.2d	v22, #0000000000000000
    2e08:      	movi.2d	v19, #0000000000000000
    2e0c:      	tbz	w11, #0x0, 0x324c <ltmp0+0x324c>
    2e10:      	ldr	s22, [x9]
    2e14:      	tbnz	w11, #0x1, 0x3250 <ltmp0+0x3250>
    2e18:      	tbz	w11, #0x2, 0x325c <ltmp0+0x325c>
    2e1c:      	add	x12, x9, #0x8
    2e20:      	ld1.s	{ v22 }[2], [x12]
    2e24:      	tbnz	w11, #0x3, 0x3260 <ltmp0+0x3260>
    2e28:      	tbz	w11, #0x4, 0x326c <ltmp0+0x326c>
    2e2c:      	add	x12, x9, #0x10
    2e30:      	ld1.s	{ v19 }[0], [x12]
    2e34:      	tbnz	w11, #0x5, 0x3270 <ltmp0+0x3270>
    2e38:      	tbz	w11, #0x6, 0x2e44 <ltmp0+0x2e44>
    2e3c:      	add	x12, x9, #0x18
    2e40:      	ld1.s	{ v19 }[2], [x12]
    2e44:      	ldr	d5, [sp, #0x70]
    2e48:      	umlal.2d	v4, v5, v6
    2e4c:      	ldr	d5, [sp, #0x80]
    2e50:      	umlal.2d	v3, v5, v6
    2e54:      	ldr	q5, [sp, #0xa0]
    2e58:      	ldr	d7, [sp, #0x90]
    2e5c:      	umlal.2d	v5, v7, v6
    2e60:      	str	q5, [sp, #0xa0]
    2e64:      	tbz	w11, #0x7, 0x2e70 <ltmp0+0x2e70>
    2e68:      	add	x9, x9, #0x1c
    2e6c:      	ld1.s	{ v19 }[3], [x9]
    2e70:      	ldp	q6, q5, [sp, #0xb0]
    2e74:      	fmul.4s	v5, v20, v5
    2e78:      	fmul.4s	v5, v20, v5
    2e7c:      	fmul.4s	v5, v20, v5
    2e80:      	fadd.4s	v5, v20, v5
    2e84:      	fmul.4s	v5, v5, v6
    2e88:      	zip1.8b	v6, v1, v0
    2e8c:      	ushll.4s	v6, v6, #0x0
    2e90:      	shl.4s	v6, v6, #0x1f
    2e94:      	cmlt.4s	v6, v6, #0
    2e98:      	and.16b	v5, v6, v5
    2e9c:      	fabs.4s	v6, v5
    2ea0:      	fmul.4s	v7, v5, v5
    2ea4:      	ldp	q16, q24, [sp, #0x120]
    2ea8:      	fmla.4s	v16, v7, v24
    2eac:      	fmla.4s	v23, v7, v16
    2eb0:      	mov.16b	v16, v30
    2eb4:      	fmla.4s	v16, v7, v23
    2eb8:      	mov.16b	v23, v14
    2ebc:      	fmla.4s	v23, v7, v16
    2ec0:      	ldr	q30, [sp, #0xf0]
    2ec4:      	mov.16b	v16, v30
    2ec8:      	fmla.4s	v16, v7, v23
    2ecc:      	mov.16b	v23, v26
    2ed0:      	fmla.4s	v23, v7, v16
    2ed4:      	fmul.4s	v16, v6, v23
    2ed8:      	ldp	q24, q23, [sp, #0x230]
    2edc:      	fmla.4s	v23, v7, v24
    2ee0:      	mov.16b	v24, v28
    2ee4:      	fmla.4s	v24, v7, v23
    2ee8:      	mov.16b	v23, v25
    2eec:      	fmla.4s	v23, v7, v24
    2ef0:      	ldr	q24, [sp, #0x160]
    2ef4:      	fmla.4s	v24, v7, v23
    2ef8:      	movi.4s	v23, #0x3f, lsl #24
    2efc:      	fmla.4s	v23, v7, v24
    2f00:      	mov.16b	v24, v26
    2f04:      	fmla.4s	v24, v7, v23
    2f08:      	fdiv.4s	v7, v16, v24
    2f0c:      	fcmge.4s	v16, v27, v6
    2f10:      	and.16b	v23, v16, v6
    2f14:      	ldr	q24, [sp, #0x220]
    2f18:      	fcmge.4s	v24, v23, v24
    2f1c:      	fcmge.4s	v25, v11, v23
    2f20:      	and.16b	v24, v24, v25
    2f24:      	and.16b	v24, v24, v23
    2f28:      	fmul.4s	v25, v24, v10
    2f2c:      	movi.4s	v26, #0x4b, lsl #24
    2f30:      	fadd.4s	v25, v25, v26
    2f34:      	movi.4s	v26, #0xcb, lsl #24
    2f38:      	fadd.4s	v25, v25, v26
    2f3c:      	fcvtzs.4s	v25, v25
    2f40:      	scvtf.4s	v26, v25
    2f44:      	fmul.4s	v27, v26, v12
    2f48:      	fadd.4s	v24, v24, v27
    2f4c:      	fmul.4s	v26, v26, v13
    2f50:      	fadd.4s	v24, v24, v26
    2f54:      	ldr	q26, [sp, #0x210]
    2f58:      	fmul.4s	v26, v24, v26
    2f5c:      	fadd.4s	v26, v26, v31
    2f60:      	fmul.4s	v26, v24, v26
    2f64:      	fadd.4s	v26, v26, v8
    2f68:      	fmul.4s	v26, v24, v26
    2f6c:      	fadd.4s	v26, v26, v15
    2f70:      	fmul.4s	v26, v24, v26
    2f74:      	fadd.4s	v26, v26, v30
    2f78:      	fmul.4s	v26, v24, v26
    2f7c:      	fadd.4s	v26, v26, v29
    2f80:      	fmul.4s	v27, v24, v24
    2f84:      	fmul.4s	v26, v27, v26
    2f88:      	fadd.4s	v24, v24, v26
    2f8c:      	ldr	q26, [sp, #0x250]
    2f90:      	fadd.4s	v24, v24, v26
    2f94:      	add.4s	v25, v25, v2
    2f98:      	sshr.4s	v26, v25, #0x1
    2f9c:      	shl.4s	v27, v26, #0x17
    2fa0:      	ldr	q29, [sp, #0x250]
    2fa4:      	add.4s	v27, v27, v29
    2fa8:      	movi.4s	v29, #0x3f, lsl #24
    2fac:      	fmul.4s	v24, v24, v27
    2fb0:      	sub.4s	v25, v25, v26
    2fb4:      	ldr	q26, [sp, #0x250]
    2fb8:      	shl.4s	v25, v25, #0x17
    2fbc:      	add.4s	v25, v25, v26
    2fc0:      	fmul.4s	v24, v24, v25
    2fc4:      	fcmgt.4s	v23, v23, v11
    2fc8:      	ldr	q25, [sp, #0x150]
    2fcc:      	bsl.16b	v23, v25, v24
    2fd0:      	fdiv.4s	v24, v9, v23
    2fd4:      	fsub.4s	v25, v23, v24
    2fd8:      	fadd.4s	v23, v23, v24
    2fdc:      	fdiv.4s	v23, v25, v23
    2fe0:      	bsl.16b	v16, v23, v26
    2fe4:      	fcmge.4s	v6, v26, v6
    2fe8:      	bsl.16b	v6, v7, v16
    2fec:      	add.2d	v4, v4, v18
    2ff0:      	add.2d	v3, v3, v18
    2ff4:      	ldr	q2, [sp, #0xa0]
    2ff8:      	add.2d	v7, v2, v18
    2ffc:      	mvni.4s	v23, #0x80, lsl #24
    3000:      	mov.16b	v2, v23
    3004:      	bsl.16b	v2, v6, v5
    3008:      	fcmeq.4s	v5, v5, v5
    300c:      	fadd.4s	v2, v2, v26
    3010:      	ldr	q6, [sp, #0x140]
    3014:      	bif.16b	v2, v6, v5
    3018:      	fmul.4s	v5, v20, v29
    301c:      	fmul.4s	v2, v5, v2
    3020:      	fadd.4s	v2, v22, v2
    3024:      	ldr	q5, [sp, #0x60]
    3028:      	stp	q5, q4, [sp, #0x260]
    302c:      	stp	q3, q7, [sp, #0x280]
    3030:      	fmov	w9, s21
    3034:      	and	x11, x10, #0x7
    3038:      	add	x12, sp, #0x260
    303c:      	ldr	x11, [x12, x11, lsl #3]
    3040:      	sub	x10, x11, x10
    3044:      	add	x8, x8, x10, lsl #2
    3048:      	tbz	w9, #0x0, 0x3050 <ltmp0+0x3050>
    304c:      	str	s2, [x8]
    3050:      	tbz	w9, #0x1, 0x305c <ltmp0+0x305c>
    3054:      	add	x10, x8, #0x4
    3058:      	st1.s	{ v2 }[1], [x10]
    305c:      	ldr	q20, [sp, #0x240]
    3060:      	ldr	q27, [sp, #0x1e0]
    3064:      	ldp	q22, q25, [sp, #0x150]
    3068:      	ldr	q29, [sp, #0x180]
    306c:      	ldp	q18, q7, [sp, #0x210]
    3070:      	movi.4s	v16, #0x4b, lsl #24
    3074:      	movi.4s	v24, #0xcb, lsl #24
    3078:      	ldr	q3, [sp, #0xb0]
    307c:      	mov.16b	v30, v17
    3080:      	tbz	w9, #0x2, 0x308c <ltmp0+0x308c>
    3084:      	add	x10, x8, #0x8
    3088:      	st1.s	{ v2 }[2], [x10]
    308c:      	tbz	w9, #0x3, 0x3098 <ltmp0+0x3098>
    3090:      	add	x10, x8, #0xc
    3094:      	st1.s	{ v2 }[3], [x10]
    3098:      	ldr	q2, [sp, #0xc0]
    309c:      	fmul.4s	v2, v0, v2
    30a0:      	fmul.4s	v2, v0, v2
    30a4:      	fmul.4s	v2, v0, v2
    30a8:      	fadd.4s	v2, v0, v2
    30ac:      	fmul.4s	v2, v2, v3
    30b0:      	zip2.8b	v1, v1, v0
    30b4:      	ushll.4s	v1, v1, #0x0
    30b8:      	shl.4s	v1, v1, #0x1f
    30bc:      	cmlt.4s	v1, v1, #0
    30c0:      	and.16b	v1, v1, v2
    30c4:      	fabs.4s	v2, v1
    30c8:      	fmul.4s	v3, v1, v1
    30cc:      	ldp	q4, q5, [sp, #0x120]
    30d0:      	fmla.4s	v4, v3, v5
    30d4:      	ldr	q5, [sp, #0xd0]
    30d8:      	fmla.4s	v5, v3, v4
    30dc:      	mov.16b	v4, v30
    30e0:      	fmla.4s	v4, v3, v5
    30e4:      	mov.16b	v5, v14
    30e8:      	fmla.4s	v5, v3, v4
    30ec:      	ldr	q21, [sp, #0xf0]
    30f0:      	mov.16b	v4, v21
    30f4:      	fmla.4s	v4, v3, v5
    30f8:      	mov.16b	v5, v26
    30fc:      	fmla.4s	v5, v3, v4
    3100:      	fmul.4s	v4, v2, v5
    3104:      	mov.16b	v5, v20
    3108:      	ldr	q6, [sp, #0x230]
    310c:      	fmla.4s	v5, v3, v6
    3110:      	mov.16b	v6, v28
    3114:      	fmla.4s	v6, v3, v5
    3118:      	mov.16b	v5, v27
    311c:      	fmla.4s	v5, v3, v6
    3120:      	mov.16b	v6, v25
    3124:      	fmla.4s	v6, v3, v5
    3128:      	movi.4s	v5, #0x3f, lsl #24
    312c:      	fmla.4s	v5, v3, v6
    3130:      	mov.16b	v6, v26
    3134:      	fmla.4s	v6, v3, v5
    3138:      	fdiv.4s	v3, v4, v6
    313c:      	fcmge.4s	v4, v29, v2
    3140:      	and.16b	v5, v4, v2
    3144:      	fcmge.4s	v6, v5, v7
    3148:      	fcmge.4s	v7, v11, v5
    314c:      	and.16b	v6, v6, v7
    3150:      	and.16b	v6, v6, v5
    3154:      	fmul.4s	v7, v6, v10
    3158:      	fadd.4s	v7, v7, v16
    315c:      	fadd.4s	v7, v7, v24
    3160:      	fcvtzs.4s	v7, v7
    3164:      	scvtf.4s	v16, v7
    3168:      	fmul.4s	v17, v16, v12
    316c:      	fadd.4s	v6, v6, v17
    3170:      	fmul.4s	v16, v16, v13
    3174:      	fadd.4s	v6, v6, v16
    3178:      	fmul.4s	v16, v6, v18
    317c:      	fadd.4s	v16, v16, v31
    3180:      	fmul.4s	v16, v6, v16
    3184:      	fadd.4s	v16, v16, v8
    3188:      	fmul.4s	v16, v6, v16
    318c:      	fadd.4s	v16, v16, v15
    3190:      	fmul.4s	v16, v6, v16
    3194:      	fadd.4s	v16, v16, v21
    3198:      	fmul.4s	v16, v6, v16
    319c:      	movi.4s	v21, #0x3f, lsl #24
    31a0:      	fadd.4s	v16, v16, v21
    31a4:      	fmul.4s	v17, v6, v6
    31a8:      	fmul.4s	v16, v17, v16
    31ac:      	fadd.4s	v6, v6, v16
    31b0:      	fadd.4s	v6, v6, v26
    31b4:      	movi.2d	v16, #0xffffffffffffffff
    31b8:      	add.4s	v7, v7, v16
    31bc:      	sshr.4s	v16, v7, #0x1
    31c0:      	shl.4s	v17, v16, #0x17
    31c4:      	add.4s	v17, v17, v26
    31c8:      	fmul.4s	v6, v6, v17
    31cc:      	sub.4s	v7, v7, v16
    31d0:      	shl.4s	v7, v7, #0x17
    31d4:      	add.4s	v7, v7, v26
    31d8:      	fmul.4s	v6, v6, v7
    31dc:      	fcmgt.4s	v5, v5, v11
    31e0:      	bsl.16b	v5, v22, v6
    31e4:      	fdiv.4s	v6, v9, v5
    31e8:      	fsub.4s	v7, v5, v6
    31ec:      	fadd.4s	v5, v5, v6
    31f0:      	fdiv.4s	v5, v7, v5
    31f4:      	bsl.16b	v4, v5, v26
    31f8:      	fcmge.4s	v2, v26, v2
    31fc:      	bsl.16b	v2, v3, v4
    3200:      	bif.16b	v2, v1, v23
    3204:      	fcmeq.4s	v1, v1, v1
    3208:      	fadd.4s	v2, v2, v26
    320c:      	ldr	q18, [sp, #0x140]
    3210:      	bsl.16b	v1, v2, v18
    3214:      	fmul.4s	v0, v0, v21
    3218:      	fmul.4s	v0, v0, v1
    321c:      	fadd.4s	v0, v19, v0
    3220:      	tbz	w9, #0x4, 0x3280 <ltmp0+0x3280>
    3224:      	str	s0, [x8, #0x10]
    3228:      	tbnz	w9, #0x5, 0x3284 <ltmp0+0x3284>
    322c:      	ldr	q23, [sp, #0xd0]
    3230:      	ldr	q21, [sp, #0xb0]
    3234:      	mov.16b	v9, v14
    3238:      	tbnz	w9, #0x6, 0x2ca8 <ltmp0+0x2ca8>
    323c:      	tbz	w9, #0x7, 0x1bc <ltmp0+0x1bc>
    3240:      	add	x8, x8, #0x1c
    3244:      	st1.s	{ v0 }[3], [x8]
    3248:      	b	0x1bc <ltmp0+0x1bc>
    324c:      	tbz	w11, #0x1, 0x2e18 <ltmp0+0x2e18>
    3250:      	add	x12, x9, #0x4
    3254:      	ld1.s	{ v22 }[1], [x12]
    3258:      	tbnz	w11, #0x2, 0x2e1c <ltmp0+0x2e1c>
    325c:      	tbz	w11, #0x3, 0x2e28 <ltmp0+0x2e28>
    3260:      	add	x12, x9, #0xc
    3264:      	ld1.s	{ v22 }[3], [x12]
    3268:      	tbnz	w11, #0x4, 0x2e2c <ltmp0+0x2e2c>
    326c:      	tbz	w11, #0x5, 0x2e38 <ltmp0+0x2e38>
    3270:      	add	x12, x9, #0x14
    3274:      	ld1.s	{ v19 }[1], [x12]
    3278:      	tbnz	w11, #0x6, 0x2e3c <ltmp0+0x2e3c>
    327c:      	b	0x2e44 <ltmp0+0x2e44>
    3280:      	tbz	w9, #0x5, 0x322c <ltmp0+0x322c>
    3284:      	add	x10, x8, #0x14
    3288:      	st1.s	{ v0 }[1], [x10]
    328c:      	ldr	q23, [sp, #0xd0]
    3290:      	ldr	q21, [sp, #0xb0]
    3294:      	mov.16b	v9, v14
    3298:      	tbz	w9, #0x6, 0x323c <ltmp0+0x323c>
    329c:      	b	0x2ca8 <ltmp0+0x2ca8>
    32a0:      	ldr	x9, [sp, #0x10]
    32a4:      	stp	w15, w14, [x9]
    32a8:      	str	w13, [x9, #0x8]
    32ac:      	mov	w8, #0x18               ; =24
    32b0:      	str	w8, [x9, #0x24]
    32b4:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    32b8:      	add	sp, sp, #0x410
    32bc:      	ldp	x29, x30, [sp, #0x90]
    32c0:      	ldp	x20, x19, [sp, #0x80]
    32c4:      	ldp	x22, x21, [sp, #0x70]
    32c8:      	ldp	x24, x23, [sp, #0x60]
    32cc:      	ldp	x26, x25, [sp, #0x50]
    32d0:      	ldp	x28, x27, [sp, #0x40]
    32d4:      	ldp	d9, d8, [sp, #0x30]
    32d8:      	ldp	d11, d10, [sp, #0x20]
    32dc:      	ldp	d13, d12, [sp, #0x10]
    32e0:      	ldp	d15, d14, [sp], #0xa0
    32e4:      	ret


/private/tmp/luisa-packet-inline.UY1lIE/capture/rmsnorm-17x65/on/object/tile_xir_w8_36272_1788935091635605_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	w3, 0x11b8 <ltmp0+0x11b8>
       4:      	stp	d15, d14, [sp, #-0xa0]!
       8:      	stp	d13, d12, [sp, #0x10]
       c:      	stp	d11, d10, [sp, #0x20]
      10:      	stp	d9, d8, [sp, #0x30]
      14:      	stp	x28, x27, [sp, #0x40]
      18:      	stp	x26, x25, [sp, #0x50]
      1c:      	stp	x24, x23, [sp, #0x60]
      20:      	stp	x22, x21, [sp, #0x70]
      24:      	stp	x20, x19, [sp, #0x80]
      28:      	stp	x29, x30, [sp, #0x90]
      2c:      	sub	sp, sp, #0x620
      30:      	mov	w8, #0x0                ; =0
      34:      	mov	w19, #0x20              ; =32
      38:      	mov	w10, #0x4               ; =4
      3c:      	mov	w11, #0x42820000        ; =1115815936
      40:      	ldp	w12, w13, [x2, #0x2c]
      44:      	mov	w14, #0xc5ac            ; =50604
      48:      	movk	w14, #0x3727, lsl #16
      4c:      	add	x16, sp, #0x500
      50:      	ldp	w9, w15, [x2]
      54:      	ldp	w17, w7, [x2, #0x8]
      58:      	str	x2, [sp, #0x10]
      5c:      	movi	d15, #0000000000000000
      60:      	adrp	x1, 0x0 <ltmp0>
      64:      	ldr	q0, [x1]
      68:      	str	q0, [sp, #0x20]
      6c:      	adrp	x1, 0x0 <ltmp0>
      70:      	ldr	q0, [x1]
      74:      	str	q0, [sp, #0x40]
      78:      	adrp	x1, 0x0 <ltmp0>
      7c:      	ldr	q0, [x1]
      80:      	str	q0, [sp, #0x30]
      84:      	add	x27, sp, #0x3e0
      88:      	str	w12, [sp, #0x1c]
      8c:      	b	0xc8 <ltmp0+0xc8>
      90:      	add	w9, w26, #0x1
      94:      	cmp	w9, w12
      98:      	cset	w15, eq
      9c:      	csinc	w9, wzr, w26, eq
      a0:      	cinc	w17, w25, eq
      a4:      	cmp	w17, w13
      a8:      	cset	w1, eq
      ac:      	ands	w1, w15, w1
      b0:      	csel	w15, wzr, w17, ne
      b4:      	add	w17, w24, w1
      b8:      	add	w8, w8, #0x1
      bc:      	cmp	w8, w3
      c0:      	movi	d15, #0000000000000000
      c4:      	b.eq	0x1178 <ltmp0+0x1178>
      c8:      	mov	x24, x17
      cc:      	mov	x25, x15
      d0:      	mov	x26, x9
      d4:      	ubfiz	x9, x9, #5, #32
      d8:      	cmp	x9, x7
      dc:      	csel	x15, x9, xzr, ls
      e0:      	subs	x17, x7, x15
      e4:      	cmp	x17, #0x20
      e8:      	csel	x17, x17, x19, lo
      ec:      	cmp	x7, x15
      f0:      	ccmp	x9, x7, #0x2, hi
      f4:      	csel	x15, x17, xzr, ls
      f8:      	cmp	x15, #0x20
      fc:      	b.lo	0x310 <ltmp0+0x310>
     100:      	ldr	x9, [x0]
     104:      	ldr	x15, [x0, #0x10]
     108:      	ldr	x4, [x0, #0x30]
     10c:      	add	x17, x15, #0x100
     110:      	and	x1, x26, #0x7ffffff
     114:      	add	x1, x1, x1, lsl #6
     118:      	lsl	x5, x1, #4
     11c:      	add	x9, x9, x5
     120:      	add	x1, x9, #0x80
     124:      	add	x9, x4, x5
     128:      	add	x28, x9, #0x80
     12c:      	mov	w30, #0x4               ; =4
     130:      	ldp	q27, q26, [x1, #-0x80]
     134:      	ldp	q25, q24, [x1, #-0x60]
     138:      	ldp	q23, q22, [x1, #-0x40]
     13c:      	ldp	q21, q20, [x1, #-0x20]
     140:      	ldp	q19, q18, [x1]
     144:      	ldp	q17, q16, [x1, #0x20]
     148:      	ldp	q7, q6, [x1, #0x40]
     14c:      	ldp	q0, q3, [x1, #0x60]
     150:      	stp	q3, q0, [sp, #0x130]
     154:      	ldr	s5, [x1, #0x80]
     158:      	ldp	q29, q28, [x15]
     15c:      	fmul.4s	v30, v27, v27
     160:      	fmul.4s	v31, v26, v26
     164:      	fmul.4s	v8, v24, v24
     168:      	fmul.4s	v9, v25, v25
     16c:      	fmul.4s	v10, v23, v23
     170:      	fmul.4s	v11, v22, v22
     174:      	fmul.4s	v12, v20, v20
     178:      	fmul.4s	v13, v21, v21
     17c:      	fmul.4s	v14, v3, v3
     180:      	fmul.4s	v15, v0, v0
     184:      	fmul.4s	v0, v7, v7
     188:      	fadd.4s	v13, v13, v15
     18c:      	fmul.4s	v15, v6, v6
     190:      	fadd.4s	v11, v11, v15
     194:      	fadd.4s	v0, v10, v0
     198:      	fmul.4s	v10, v16, v16
     19c:      	fmul.4s	v15, v17, v17
     1a0:      	fadd.4s	v9, v9, v15
     1a4:      	fadd.4s	v8, v8, v10
     1a8:      	fmul.4s	v10, v19, v19
     1ac:      	fmul.4s	v15, v18, v18
     1b0:      	fadd.4s	v30, v30, v10
     1b4:      	fmul.4s	v10, v5, v5
     1b8:      	fadd.4s	v31, v31, v15
     1bc:      	fadd.4s	v10, v30, v10
     1c0:      	mov.s	v30[0], v10[0]
     1c4:      	fadd.4s	v31, v8, v31
     1c8:      	fadd.4s	v30, v9, v30
     1cc:      	fadd.4s	v8, v12, v14
     1d0:      	fadd.4s	v0, v0, v30
     1d4:      	fadd.4s	v30, v11, v31
     1d8:      	fadd.4s	v30, v8, v30
     1dc:      	fadd.4s	v0, v13, v0
     1e0:      	ldp	q9, q8, [x15, #0x20]
     1e4:      	rev64.4s	v31, v0
     1e8:      	rev64.4s	v10, v30
     1ec:      	fadd.4s	v30, v30, v10
     1f0:      	fadd.4s	v0, v0, v31
     1f4:      	ldp	q11, q10, [x15, #0x40]
     1f8:      	dup.4s	v31, v0[2]
     1fc:      	dup.4s	v12, v30[2]
     200:      	ldp	q14, q13, [x15, #0x60]
     204:      	fadd.4s	v30, v30, v12
     208:      	fadd.4s	v0, v0, v31
     20c:      	fadd.4s	v0, v0, v30
     210:      	movi	d3, #0000000000000000
     214:      	fadd	s0, s0, s3
     218:      	ldp	q15, q12, [x15, #0x80]
     21c:      	fmov	s30, w11
     220:      	fdiv	s0, s0, s30
     224:      	fmov	s30, w14
     228:      	fadd	s0, s0, s30
     22c:      	ldp	q3, q4, [x15, #0xa0]
     230:      	fsqrt	s30, s0
     234:      	dup.4s	v31, v30[0]
     238:      	fdiv.4s	v0, v27, v31
     23c:      	fmul.4s	v0, v29, v0
     240:      	ldr	s27, [x17]
     244:      	fdiv.4s	v26, v26, v31
     248:      	fmul.4s	v26, v28, v26
     24c:      	fdiv.4s	v25, v25, v31
     250:      	fmul.4s	v25, v9, v25
     254:      	ldp	q29, q28, [x15, #0xc0]
     258:      	fdiv.4s	v24, v24, v31
     25c:      	fmul.4s	v24, v8, v24
     260:      	fdiv.4s	v23, v23, v31
     264:      	fmul.4s	v23, v11, v23
     268:      	ldp	q9, q8, [x15, #0xe0]
     26c:      	stp	q0, q26, [x28, #-0x80]
     270:      	fdiv.4s	v0, v22, v31
     274:      	fmul.4s	v0, v10, v0
     278:      	stp	q25, q24, [x28, #-0x60]
     27c:      	fdiv.4s	v21, v21, v31
     280:      	fmul.4s	v21, v14, v21
     284:      	fdiv.4s	v20, v20, v31
     288:      	fmul.4s	v20, v13, v20
     28c:      	stp	q23, q0, [x28, #-0x40]
     290:      	fdiv.4s	v0, v19, v31
     294:      	fmul.4s	v0, v15, v0
     298:      	fdiv.4s	v18, v18, v31
     29c:      	fmul.4s	v18, v12, v18
     2a0:      	stp	q21, q20, [x28, #-0x20]
     2a4:      	fdiv.4s	v17, v17, v31
     2a8:      	fmul.4s	v3, v3, v17
     2ac:      	fdiv.4s	v16, v16, v31
     2b0:      	fmul.4s	v4, v4, v16
     2b4:      	stp	q0, q18, [x28]
     2b8:      	fdiv.4s	v0, v7, v31
     2bc:      	fmul.4s	v0, v29, v0
     2c0:      	fdiv.4s	v6, v6, v31
     2c4:      	fmul.4s	v6, v28, v6
     2c8:      	stp	q3, q4, [x28, #0x20]
     2cc:      	ldp	q3, q4, [sp, #0x130]
     2d0:      	fdiv.4s	v3, v3, v31
     2d4:      	fdiv.4s	v4, v4, v31
     2d8:      	fmul.4s	v4, v9, v4
     2dc:      	fmul.4s	v3, v8, v3
     2e0:      	stp	q0, q6, [x28, #0x40]
     2e4:      	stp	q4, q3, [x28, #0x60]
     2e8:      	mov.s	v2[0], v5[0]
     2ec:      	mov.s	v1[0], v27[0]
     2f0:      	fdiv.4s	v0, v5, v30
     2f4:      	fmul.4s	v0, v27, v0
     2f8:      	str	s0, [x28, #0x80]
     2fc:      	add	x1, x1, #0x104
     300:      	add	x28, x28, #0x104
     304:      	subs	x30, x30, #0x1
     308:      	b.ne	0x130 <ltmp0+0x130>
     30c:      	b	0x90 <ltmp0+0x90>
     310:      	lsr	x5, x15, #3
     314:      	cmp	x15, #0x8
     318:      	b.lo	0x514 <ltmp0+0x514>
     31c:      	ldr	x9, [x0]
     320:      	ldr	x1, [x0, #0x10]
     324:      	ldr	x17, [x0, #0x30]
     328:      	add	x28, x1, #0x100
     32c:      	and	x4, x26, #0x7ffffff
     330:      	add	x4, x4, x4, lsl #6
     334:      	lsl	x6, x4, #4
     338:      	add	x9, x9, x6
     33c:      	add	x4, x9, #0x80
     340:      	add	x9, x17, x6
     344:      	add	x30, x9, #0x80
     348:      	mov	x17, x5
     34c:      	ldp	q25, q24, [x4, #-0x80]
     350:      	ldp	q23, q22, [x4, #-0x60]
     354:      	ldp	q21, q20, [x4, #-0x40]
     358:      	ldp	q19, q18, [x4, #-0x20]
     35c:      	ldp	q17, q16, [x4]
     360:      	ldp	q7, q6, [x4, #0x20]
     364:      	ldp	q5, q4, [x4, #0x40]
     368:      	ldp	q2, q3, [x4, #0x60]
     36c:      	ldr	s1, [x4, #0x80]
     370:      	ldp	q29, q28, [x1]
     374:      	ldp	q27, q26, [x1, #0x20]
     378:      	fmul.4s	v0, v25, v25
     37c:      	fmul.4s	v30, v24, v24
     380:      	fmul.4s	v31, v22, v22
     384:      	fmul.4s	v8, v23, v23
     388:      	fmul.4s	v9, v21, v21
     38c:      	fmul.4s	v10, v20, v20
     390:      	fmul.4s	v11, v18, v18
     394:      	fmul.4s	v12, v19, v19
     398:      	fmul.4s	v13, v2, v2
     39c:      	fadd.4s	v12, v12, v13
     3a0:      	fmul.4s	v13, v5, v5
     3a4:      	fmul.4s	v14, v4, v4
     3a8:      	fadd.4s	v10, v10, v14
     3ac:      	fadd.4s	v9, v9, v13
     3b0:      	fmul.4s	v13, v6, v6
     3b4:      	fmul.4s	v14, v7, v7
     3b8:      	fadd.4s	v8, v8, v14
     3bc:      	fadd.4s	v31, v31, v13
     3c0:      	fmul.4s	v13, v17, v17
     3c4:      	fmul.4s	v14, v16, v16
     3c8:      	fadd.4s	v30, v30, v14
     3cc:      	fadd.4s	v0, v0, v13
     3d0:      	fmul.4s	v13, v1, v1
     3d4:      	fmul.4s	v14, v3, v3
     3d8:      	fadd.4s	v13, v0, v13
     3dc:      	mov.s	v0[0], v13[0]
     3e0:      	fadd.4s	v30, v31, v30
     3e4:      	fadd.4s	v0, v8, v0
     3e8:      	fadd.4s	v31, v11, v14
     3ec:      	fadd.4s	v0, v9, v0
     3f0:      	fadd.4s	v30, v10, v30
     3f4:      	fadd.4s	v30, v31, v30
     3f8:      	fadd.4s	v0, v12, v0
     3fc:      	ldp	q9, q8, [x1, #0x40]
     400:      	rev64.4s	v31, v0
     404:      	rev64.4s	v10, v30
     408:      	fadd.4s	v30, v30, v10
     40c:      	fadd.4s	v0, v0, v31
     410:      	dup.4s	v31, v0[2]
     414:      	dup.4s	v10, v30[2]
     418:      	fadd.4s	v30, v30, v10
     41c:      	fadd.4s	v0, v0, v31
     420:      	ldp	q11, q10, [x1, #0x60]
     424:      	fadd.4s	v0, v0, v30
     428:      	fadd	s0, s0, s15
     42c:      	fmov	s30, w11
     430:      	fdiv	s0, s0, s30
     434:      	ldp	q13, q12, [x1, #0x80]
     438:      	fmov	s30, w14
     43c:      	fadd	s0, s0, s30
     440:      	fsqrt	s30, s0
     444:      	dup.4s	v31, v30[0]
     448:      	ldp	q14, q0, [x1, #0xa0]
     44c:      	fdiv.4s	v25, v25, v31
     450:      	fmul.4s	v25, v29, v25
     454:      	fdiv.4s	v24, v24, v31
     458:      	fmul.4s	v24, v28, v24
     45c:      	ldp	q28, q29, [x1, #0xc0]
     460:      	fdiv.4s	v23, v23, v31
     464:      	fmul.4s	v23, v27, v23
     468:      	fdiv.4s	v22, v22, v31
     46c:      	fmul.4s	v22, v26, v22
     470:      	ldp	q26, q27, [x1, #0xe0]
     474:      	fdiv.4s	v21, v21, v31
     478:      	fmul.4s	v21, v9, v21
     47c:      	ldr	s9, [x28]
     480:      	stp	q25, q24, [x30, #-0x80]
     484:      	fdiv.4s	v20, v20, v31
     488:      	fmul.4s	v20, v8, v20
     48c:      	fdiv.4s	v19, v19, v31
     490:      	fmul.4s	v19, v11, v19
     494:      	stp	q23, q22, [x30, #-0x60]
     498:      	fdiv.4s	v18, v18, v31
     49c:      	fmul.4s	v18, v10, v18
     4a0:      	fdiv.4s	v17, v17, v31
     4a4:      	fmul.4s	v17, v13, v17
     4a8:      	stp	q21, q20, [x30, #-0x40]
     4ac:      	stp	q19, q18, [x30, #-0x20]
     4b0:      	fdiv.4s	v16, v16, v31
     4b4:      	fmul.4s	v16, v12, v16
     4b8:      	stp	q17, q16, [x30]
     4bc:      	fdiv.4s	v7, v7, v31
     4c0:      	fmul.4s	v7, v14, v7
     4c4:      	fdiv.4s	v6, v6, v31
     4c8:      	fmul.4s	v0, v0, v6
     4cc:      	stp	q7, q0, [x30, #0x20]
     4d0:      	fdiv.4s	v0, v5, v31
     4d4:      	fmul.4s	v0, v28, v0
     4d8:      	fdiv.4s	v4, v4, v31
     4dc:      	fmul.4s	v4, v29, v4
     4e0:      	stp	q0, q4, [x30, #0x40]
     4e4:      	fdiv.4s	v0, v3, v31
     4e8:      	fdiv.4s	v2, v2, v31
     4ec:      	fmul.4s	v2, v26, v2
     4f0:      	fmul.4s	v0, v27, v0
     4f4:      	stp	q2, q0, [x30, #0x60]
     4f8:      	fdiv.4s	v0, v1, v30
     4fc:      	fmul.4s	v0, v9, v0
     500:      	str	s0, [x30, #0x80]
     504:      	add	x4, x4, #0x104
     508:      	add	x30, x30, #0x104
     50c:      	subs	x17, x17, #0x1
     510:      	b.ne	0x34c <ltmp0+0x34c>
     514:      	and	w9, w15, #0x7
     518:      	cbz	w9, 0x90 <ltmp0+0x90>
     51c:      	dup.4s	v0, w9
     520:      	ldp	q2, q1, [sp, #0x30]
     524:      	cmhi.4s	v16, v0, v2
     528:      	cmhi.4s	v17, v0, v1
     52c:      	uzp1.8h	v11, v17, v16
     530:      	umaxv.8h	h0, v11
     534:      	fmov	w9, s0
     538:      	tbz	w9, #0x0, 0x90 <ltmp0+0x90>
     53c:      	mov	x4, #0x0                ; =0
     540:      	ldr	x1, [x0]
     544:      	ldr	x15, [x0, #0x10]
     548:      	ldr	x12, [x0, #0x30]
     54c:      	ldr	q0, [sp, #0x20]
     550:      	and.16b	v0, v11, v0
     554:      	addv.8h	h18, v0
     558:      	ubfiz	w9, w26, #2, #27
     55c:      	orr	w9, w9, w5
     560:      	fmov	w17, s18
     564:      	and	w17, w17, #0xff
     568:      	str	w17, [sp, #0x12c]
     56c:      	dup.4s	v0, w9
     570:      	and.16b	v1, v17, v0
     574:      	and.16b	v0, v16, v0
     578:      	ushll2.2d	v23, v0, #0x0
     57c:      	ushll2.2d	v24, v1, #0x0
     580:      	ushll.2d	v25, v0, #0x0
     584:      	ushll.2d	v2, v1, #0x0
     588:      	fmov	x9, d2
     58c:      	mov	w17, #0x104             ; =260
     590:      	umaddl	x5, w9, w17, x1
     594:      	b	0x5b8 <ltmp0+0x5b8>
     598:      	add	x9, x16, x4
     59c:      	ldp	q0, q4, [x9]
     5a0:      	bif.16b	v3, v4, v16
     5a4:      	bit.16b	v0, v1, v17
     5a8:      	stp	q0, q3, [x9]
     5ac:      	add	x4, x4, #0x20
     5b0:      	cmp	x4, #0x100
     5b4:      	b.eq	0x650 <ltmp0+0x650>
     5b8:      	fmov	w9, s18
     5bc:      	add	x6, x5, x4
     5c0:      	movi.2d	v1, #0000000000000000
     5c4:      	movi.2d	v3, #0000000000000000
     5c8:      	tbnz	w9, #0x0, 0x5f0 <ltmp0+0x5f0>
     5cc:      	and	w19, w9, #0xff
     5d0:      	tbnz	w19, #0x1, 0x5fc <ltmp0+0x5fc>
     5d4:      	tbnz	w19, #0x2, 0x608 <ltmp0+0x608>
     5d8:      	tbnz	w19, #0x3, 0x614 <ltmp0+0x614>
     5dc:      	tbnz	w19, #0x4, 0x620 <ltmp0+0x620>
     5e0:      	tbnz	w19, #0x5, 0x62c <ltmp0+0x62c>
     5e4:      	tbnz	w19, #0x6, 0x638 <ltmp0+0x638>
     5e8:      	tbz	w19, #0x7, 0x598 <ltmp0+0x598>
     5ec:      	b	0x644 <ltmp0+0x644>
     5f0:      	ldr	s1, [x6]
     5f4:      	and	w19, w9, #0xff
     5f8:      	tbz	w19, #0x1, 0x5d4 <ltmp0+0x5d4>
     5fc:      	add	x9, x6, #0x4
     600:      	ld1.s	{ v1 }[1], [x9]
     604:      	tbz	w19, #0x2, 0x5d8 <ltmp0+0x5d8>
     608:      	add	x9, x6, #0x8
     60c:      	ld1.s	{ v1 }[2], [x9]
     610:      	tbz	w19, #0x3, 0x5dc <ltmp0+0x5dc>
     614:      	add	x9, x6, #0xc
     618:      	ld1.s	{ v1 }[3], [x9]
     61c:      	tbz	w19, #0x4, 0x5e0 <ltmp0+0x5e0>
     620:      	add	x9, x6, #0x10
     624:      	ld1.s	{ v3 }[0], [x9]
     628:      	tbz	w19, #0x5, 0x5e4 <ltmp0+0x5e4>
     62c:      	add	x9, x6, #0x14
     630:      	ld1.s	{ v3 }[1], [x9]
     634:      	tbz	w19, #0x6, 0x5e8 <ltmp0+0x5e8>
     638:      	add	x9, x6, #0x18
     63c:      	ld1.s	{ v3 }[2], [x9]
     640:      	tbz	w19, #0x7, 0x598 <ltmp0+0x598>
     644:      	add	x9, x6, #0x1c
     648:      	ld1.s	{ v3 }[3], [x9]
     64c:      	b	0x598 <ltmp0+0x598>
     650:      	xtn.4h	v0, v17
     654:      	uzp1.8b	v0, v0, v0
     658:      	sshll.2d	v1, v17, #0x0
     65c:      	adrp	x9, 0x0 <ltmp0>
     660:      	ldr	q3, [x9]
     664:      	and.16b	v4, v1, v3
     668:      	movi.2d	v22, #0000000000000000
     66c:      	mov.b	v22[0], v0[0]
     670:      	adrp	x9, 0x0 <ltmp0>
     674:      	ldr	d3, [x9]
     678:      	str	d3, [sp, #0xc8]
     67c:      	and.8b	v3, v22, v3
     680:      	addv.8b	b3, v3
     684:      	fmov	w4, s3
     688:      	umaxv.8b	b3, v22
     68c:      	fmov	w9, s3
     690:      	rbit	w5, w4
     694:      	clz	w5, w5
     698:      	tst	w9, #0x1
     69c:      	csel	w30, w5, wzr, ne
     6a0:      	mov	w17, #0x40              ; =64
     6a4:      	dup.2d	v3, x17
     6a8:      	str	q4, [sp, #0x80]
     6ac:      	orr.16b	v5, v4, v3
     6b0:      	xtn.2s	v2, v2
     6b4:      	str	q5, [sp, #0xd0]
     6b8:      	movi.2s	v4, #0x41
     6bc:      	umlal.2d	v5, v2, v4
     6c0:      	movi.2d	v4, #0000000000000000
     6c4:      	mov.b	v4[0], v0[0]
     6c8:      	ushll.2d	v0, v4, #0x0
     6cc:      	shl.2d	v0, v0, #0x3f
     6d0:      	cmlt.2d	v0, v0, #0
     6d4:      	str	q5, [sp, #0x140]
     6d8:      	and.16b	v0, v0, v5
     6dc:      	movi.2d	v4, #0000000000000000
     6e0:      	stp	q4, q4, [sp, #0x3b0]
     6e4:      	stp	q0, q4, [sp, #0x390]
     6e8:      	and	x5, x30, #0x7
     6ec:      	add	x17, sp, #0x390
     6f0:      	ldr	x5, [x17, x5, lsl #3]
     6f4:      	sub	x5, x5, x30
     6f8:      	add	x1, x1, x5, lsl #2
     6fc:      	movi.2d	v21, #0000000000000000
     700:      	movi.2d	v19, #0000000000000000
     704:      	tbnz	w9, #0x0, 0x1068 <ltmp0+0x1068>
     708:      	tbnz	w4, #0x1, 0x1070 <ltmp0+0x1070>
     70c:      	tbnz	w4, #0x2, 0x107c <ltmp0+0x107c>
     710:      	tbnz	w4, #0x3, 0x1088 <ltmp0+0x1088>
     714:      	tbnz	w4, #0x4, 0x1094 <ltmp0+0x1094>
     718:      	tbnz	w4, #0x5, 0x10a0 <ltmp0+0x10a0>
     71c:      	tbnz	w4, #0x6, 0x10ac <ltmp0+0x10ac>
     720:      	tbz	w4, #0x7, 0x72c <ltmp0+0x72c>
     724:      	add	x9, x1, #0x1c
     728:      	ld1.s	{ v19 }[3], [x9]
     72c:      	sshll.2d	v0, v16, #0x0
     730:      	sshll2.2d	v29, v17, #0x0
     734:      	sshll2.2d	v30, v16, #0x0
     738:      	adrp	x9, 0x0 <ltmp0>
     73c:      	ldr	q4, [x9]
     740:      	and.16b	v6, v30, v4
     744:      	adrp	x9, 0x0 <ltmp0>
     748:      	ldr	q4, [x9]
     74c:      	and.16b	v27, v29, v4
     750:      	adrp	x9, 0x0 <ltmp0>
     754:      	ldr	q4, [x9]
     758:      	and.16b	v26, v0, v4
     75c:      	adrp	x9, 0x0 <ltmp0>
     760:      	ldr	q4, [x9]
     764:      	and.16b	v4, v30, v4
     768:      	adrp	x9, 0x0 <ltmp0>
     76c:      	ldr	q5, [x9]
     770:      	and.16b	v5, v29, v5
     774:      	adrp	x9, 0x0 <ltmp0>
     778:      	ldr	q7, [x9]
     77c:      	and.16b	v0, v0, v7
     780:      	adrp	x9, 0x0 <ltmp0>
     784:      	ldr	q7, [x9]
     788:      	and.16b	v20, v1, v7
     78c:      	stp	q26, q27, [sp, #0x50]
     790:      	orr.16b	v26, v26, v3
     794:      	orr.16b	v27, v27, v3
     798:      	str	q6, [sp, #0x70]
     79c:      	orr.16b	v7, v6, v3
     7a0:      	movi.2s	v6, #0x41
     7a4:      	umull.2d	v1, v2, v6
     7a8:      	str	q1, [sp, #0xe0]
     7ac:      	xtn.2s	v1, v24
     7b0:      	xtn.2s	v2, v25
     7b4:      	xtn.2s	v3, v23
     7b8:      	stp	q26, q7, [sp, #0xa0]
     7bc:      	umlal.2d	v7, v3, v6
     7c0:      	str	q27, [sp, #0x90]
     7c4:      	mov.16b	v3, v27
     7c8:      	umlal.2d	v3, v1, v6
     7cc:      	stp	q3, q7, [sp, #0x100]
     7d0:      	mov.16b	v1, v26
     7d4:      	umlal.2d	v1, v2, v6
     7d8:      	str	q1, [sp, #0xf0]
     7dc:      	sshll.2d	v1, v17, #0x0
     7e0:      	sshll.2d	v2, v16, #0x0
     7e4:      	stp	q20, q5, [sp, #0x350]
     7e8:      	stp	q0, q4, [sp, #0x370]
     7ec:      	and	x9, x30, #0x7
     7f0:      	add	x17, sp, #0x350
     7f4:      	ldr	x9, [x17, x9, lsl #3]
     7f8:      	orr	x9, x9, #0x100
     7fc:      	sub	x9, x9, x30, lsl #2
     800:      	tst	w4, #0xff
     804:      	csel	x1, xzr, x9, eq
     808:      	add	x9, x16, x1
     80c:      	ldp	q0, q3, [x9]
     810:      	zip2.8b	v4, v22, v0
     814:      	ushll.4s	v4, v4, #0x0
     818:      	shl.4s	v4, v4, #0x1f
     81c:      	cmlt.4s	v4, v4, #0
     820:      	bit.16b	v3, v19, v4
     824:      	zip1.8b	v4, v22, v0
     828:      	ushll.4s	v4, v4, #0x0
     82c:      	shl.4s	v4, v4, #0x1f
     830:      	cmlt.4s	v4, v4, #0
     834:      	str	q21, [sp, #0x130]
     838:      	bit.16b	v0, v21, v4
     83c:      	stp	q0, q3, [x9]
     840:      	dup.2d	v0, x10
     844:      	and.16b	v24, v30, v0
     848:      	and.16b	v25, v29, v0
     84c:      	and.16b	v31, v2, v0
     850:      	and.16b	v8, v1, v0
     854:      	fmov	x9, d8
     858:      	ldr	q0, [sp, #0x570]
     85c:      	ldr	q1, [sp, #0x560]
     860:      	fmul.4s	v1, v1, v1
     864:      	fmul.4s	v0, v0, v0
     868:      	and.16b	v7, v16, v0
     86c:      	and.16b	v1, v17, v1
     870:      	ldr	q0, [sp, #0x550]
     874:      	ldr	q2, [sp, #0x540]
     878:      	fmul.4s	v3, v2, v2
     87c:      	fmul.4s	v0, v0, v0
     880:      	and.16b	v2, v16, v0
     884:      	and.16b	v4, v17, v3
     888:      	ldr	q0, [sp, #0x530]
     88c:      	ldr	q3, [sp, #0x520]
     890:      	fmul.4s	v5, v3, v3
     894:      	fmul.4s	v0, v0, v0
     898:      	and.16b	v3, v16, v0
     89c:      	and.16b	v5, v17, v5
     8a0:      	fmov	x4, d20
     8a4:      	add	x4, x16, x4
     8a8:      	ldp	q20, q0, [x4]
     8ac:      	fmul.4s	v20, v20, v20
     8b0:      	fmul.4s	v0, v0, v0
     8b4:      	and.16b	v27, v16, v0
     8b8:      	and.16b	v26, v17, v20
     8bc:      	sshll.2d	v0, v17, #0x0
     8c0:      	sshll.2d	v20, v16, #0x0
     8c4:      	add	x9, x16, x9, lsl #5
     8c8:      	ldp	q28, q23, [x9]
     8cc:      	and.16b	v28, v17, v28
     8d0:      	and.16b	v23, v16, v23
     8d4:      	fmul.4s	v23, v23, v23
     8d8:      	fmul.4s	v28, v28, v28
     8dc:      	fadd.4s	v28, v26, v28
     8e0:      	fadd.4s	v23, v27, v23
     8e4:      	ldp	q10, q9, [x9, #0x20]
     8e8:      	and.16b	v10, v17, v10
     8ec:      	and.16b	v9, v16, v9
     8f0:      	fmul.4s	v9, v9, v9
     8f4:      	fmul.4s	v10, v10, v10
     8f8:      	fadd.4s	v10, v5, v10
     8fc:      	fadd.4s	v9, v3, v9
     900:      	ldp	q13, q12, [x9, #0x40]
     904:      	and.16b	v13, v17, v13
     908:      	and.16b	v12, v16, v12
     90c:      	fmul.4s	v12, v12, v12
     910:      	fmul.4s	v13, v13, v13
     914:      	fadd.4s	v13, v4, v13
     918:      	fadd.4s	v12, v2, v12
     91c:      	ldp	q14, q21, [x9, #0x60]
     920:      	and.16b	v14, v17, v14
     924:      	and.16b	v21, v16, v21
     928:      	fmul.4s	v21, v21, v21
     92c:      	fmul.4s	v14, v14, v14
     930:      	fadd.4s	v14, v1, v14
     934:      	fadd.4s	v21, v7, v21
     938:      	dup.2d	v15, x10
     93c:      	and.16b	v6, v30, v15
     940:      	add.2d	v24, v24, v6
     944:      	and.16b	v6, v29, v15
     948:      	add.2d	v25, v25, v6
     94c:      	and.16b	v6, v20, v15
     950:      	add.2d	v31, v31, v6
     954:      	and.16b	v0, v0, v15
     958:      	add.2d	v8, v8, v0
     95c:      	bit.16b	v27, v23, v16
     960:      	bit.16b	v26, v28, v17
     964:      	bit.16b	v3, v9, v16
     968:      	bit.16b	v5, v10, v17
     96c:      	bit.16b	v2, v12, v16
     970:      	bit.16b	v4, v13, v17
     974:      	bit.16b	v7, v21, v16
     978:      	bit.16b	v1, v14, v17
     97c:      	fmov	x9, d8
     980:      	cmp	x9, #0x8
     984:      	b.lt	0x8bc <ltmp0+0x8bc>
     988:      	mov	x9, #0x0                ; =0
     98c:      	mov	w17, #0x1               ; =1
     990:      	dup.2d	v0, x17
     994:      	ushll2.2d	v6, v16, #0x0
     998:      	and.16b	v29, v6, v0
     99c:      	ushll2.2d	v6, v17, #0x0
     9a0:      	and.16b	v30, v6, v0
     9a4:      	ushll.2d	v6, v16, #0x0
     9a8:      	and.16b	v31, v6, v0
     9ac:      	ushll.2d	v6, v17, #0x0
     9b0:      	and.16b	v8, v6, v0
     9b4:      	movi.2d	v24, #0000000000000000
     9b8:      	movi.2d	v25, #0000000000000000
     9bc:      	movi.2d	v9, #0000000000000000
     9c0:      	movi.2d	v10, #0000000000000000
     9c4:      	movi	d13, #0000000000000000
     9c8:      	b	0x9fc <ltmp0+0x9fc>
     9cc:      	add	x9, x27, x4
     9d0:      	ldp	q0, q6, [x9]
     9d4:      	bit.16b	v6, v20, v16
     9d8:      	bit.16b	v0, v12, v17
     9dc:      	stp	q0, q6, [x9]
     9e0:      	add.2d	v25, v25, v30
     9e4:      	add.2d	v9, v9, v31
     9e8:      	add.2d	v10, v10, v29
     9ec:      	add.2d	v24, v24, v8
     9f0:      	fmov	x9, d24
     9f4:      	cmp	x9, #0x8
     9f8:      	b.ge	0xa98 <ltmp0+0xa98>
     9fc:      	fmov	w6, s18
     a00:      	lsl	x4, x9, #5
     a04:      	add	x5, x15, x4
     a08:      	movi.2d	v12, #0000000000000000
     a0c:      	movi.2d	v20, #0000000000000000
     a10:      	tbnz	w6, #0x0, 0xa38 <ltmp0+0xa38>
     a14:      	and	w6, w6, #0xff
     a18:      	tbnz	w6, #0x1, 0xa44 <ltmp0+0xa44>
     a1c:      	tbnz	w6, #0x2, 0xa50 <ltmp0+0xa50>
     a20:      	tbnz	w6, #0x3, 0xa5c <ltmp0+0xa5c>
     a24:      	tbnz	w6, #0x4, 0xa68 <ltmp0+0xa68>
     a28:      	tbnz	w6, #0x5, 0xa74 <ltmp0+0xa74>
     a2c:      	tbnz	w6, #0x6, 0xa80 <ltmp0+0xa80>
     a30:      	tbz	w6, #0x7, 0x9cc <ltmp0+0x9cc>
     a34:      	b	0xa8c <ltmp0+0xa8c>
     a38:      	ldr	s12, [x5]
     a3c:      	and	w6, w6, #0xff
     a40:      	tbz	w6, #0x1, 0xa1c <ltmp0+0xa1c>
     a44:      	add	x9, x5, #0x4
     a48:      	ld1.s	{ v12 }[1], [x9]
     a4c:      	tbz	w6, #0x2, 0xa20 <ltmp0+0xa20>
     a50:      	add	x9, x5, #0x8
     a54:      	ld1.s	{ v12 }[2], [x9]
     a58:      	tbz	w6, #0x3, 0xa24 <ltmp0+0xa24>
     a5c:      	add	x9, x5, #0xc
     a60:      	ld1.s	{ v12 }[3], [x9]
     a64:      	tbz	w6, #0x4, 0xa28 <ltmp0+0xa28>
     a68:      	add	x9, x5, #0x10
     a6c:      	ld1.s	{ v20 }[0], [x9]
     a70:      	tbz	w6, #0x5, 0xa2c <ltmp0+0xa2c>
     a74:      	add	x9, x5, #0x14
     a78:      	ld1.s	{ v20 }[1], [x9]
     a7c:      	tbz	w6, #0x6, 0xa30 <ltmp0+0xa30>
     a80:      	add	x9, x5, #0x18
     a84:      	ld1.s	{ v20 }[2], [x9]
     a88:      	tbz	w6, #0x7, 0x9cc <ltmp0+0x9cc>
     a8c:      	add	x9, x5, #0x1c
     a90:      	ld1.s	{ v20 }[3], [x9]
     a94:      	b	0x9cc <ltmp0+0x9cc>
     a98:      	xtn.8b	v11, v11
     a9c:      	ldr	q25, [sp, #0x130]
     aa0:      	fmul.4s	v0, v25, v25
     aa4:      	fmul.4s	v6, v19, v19
     aa8:      	fadd.4s	v6, v6, v27
     aac:      	fadd.4s	v0, v0, v26
     ab0:      	zip1.8b	v20, v22, v0
     ab4:      	ushll.4s	v20, v20, #0x0
     ab8:      	shl.4s	v20, v20, #0x1f
     abc:      	cmlt.4s	v20, v20, #0
     ac0:      	and.16b	v0, v20, v0
     ac4:      	zip2.8b	v20, v22, v0
     ac8:      	ushll.4s	v20, v20, #0x0
     acc:      	shl.4s	v20, v20, #0x1f
     ad0:      	cmlt.4s	v20, v20, #0
     ad4:      	and.16b	v6, v20, v6
     ad8:      	zip2.8b	v20, v11, v0
     adc:      	ushll.4s	v20, v20, #0x0
     ae0:      	shl.4s	v20, v20, #0x1f
     ae4:      	cmlt.4s	v20, v20, #0
     ae8:      	movi.2d	v21, #0000000000000000
     aec:      	mov.b	v21[2], v11[1]
     af0:      	mov.b	v21[4], v11[2]
     af4:      	mov.b	v21[6], v11[3]
     af8:      	bit.16b	v6, v23, v20
     afc:      	ushll.4s	v20, v21, #0x0
     b00:      	shl.4s	v20, v20, #0x1f
     b04:      	cmlt.4s	v20, v20, #0
     b08:      	bit.16b	v0, v28, v20
     b0c:      	fadd.4s	v0, v5, v0
     b10:      	fadd.4s	v3, v3, v6
     b14:      	fadd.4s	v3, v2, v3
     b18:      	fadd.4s	v0, v4, v0
     b1c:      	fadd.4s	v2, v1, v0
     b20:      	fadd.4s	v3, v7, v3
     b24:      	ldp	q0, q4, [sp, #0x70]
     b28:      	ldr	q1, [sp, #0x60]
     b2c:      	uzp1.4s	v1, v4, v1
     b30:      	ldr	q4, [sp, #0x50]
     b34:      	uzp1.4s	v4, v4, v0
     b38:      	movi.4s	v5, #0x1
     b3c:      	eor.16b	v0, v1, v5
     b40:      	mov.s	w9, v0[1]
     b44:      	mov.s	w20, v0[2]
     b48:      	eor.16b	v20, v4, v5
     b4c:      	mov.s	w21, v0[3]
     b50:      	fmov	w4, s0
     b54:      	add	x5, sp, #0x198
     b58:      	bfxil	x5, x4, #0, #3
     b5c:      	str	d11, [sp, #0x198]
     b60:      	ldrb	w5, [x5]
     b64:      	and	x6, x4, #0x7
     b68:      	umov.b	w4, v11[0]
     b6c:      	stp	q2, q3, [sp, #0x2a0]
     b70:      	add	x17, sp, #0x2a0
     b74:      	ldr	s0, [x17, x6, lsl #2]
     b78:      	ands	w6, w4, #0x1
     b7c:      	tst	w6, w5
     b80:      	fcsel	s5, s0, s13, ne
     b84:      	add	x5, sp, #0x198
     b88:      	bfxil	x5, x9, #0, #3
     b8c:      	ldrb	w19, [x5]
     b90:      	and	x9, x9, #0x7
     b94:      	umov.b	w5, v11[1]
     b98:      	stp	q2, q3, [sp, #0x280]
     b9c:      	add	x17, sp, #0x280
     ba0:      	ldr	s0, [x17, x9, lsl #2]
     ba4:      	ands	w9, w5, #0x1
     ba8:      	tst	w9, w19
     bac:      	fcsel	s6, s0, s13, ne
     bb0:      	add	x9, sp, #0x198
     bb4:      	bfxil	x9, x20, #0, #3
     bb8:      	ldrb	w9, [x9]
     bbc:      	umov.b	w19, v11[2]
     bc0:      	and	x20, x20, #0x7
     bc4:      	stp	q2, q3, [sp, #0x260]
     bc8:      	add	x17, sp, #0x260
     bcc:      	ldr	s0, [x17, x20, lsl #2]
     bd0:      	ands	w20, w19, #0x1
     bd4:      	tst	w20, w9
     bd8:      	fcsel	s7, s0, s13, ne
     bdc:      	add	x9, sp, #0x198
     be0:      	bfxil	x9, x21, #0, #3
     be4:      	ldrb	w9, [x9]
     be8:      	and	x21, x21, #0x7
     bec:      	umov.b	w20, v11[3]
     bf0:      	stp	q2, q3, [sp, #0x240]
     bf4:      	add	x17, sp, #0x240
     bf8:      	ldr	s0, [x17, x21, lsl #2]
     bfc:      	ands	w21, w20, #0x1
     c00:      	tst	w21, w9
     c04:      	mov.s	w9, v20[1]
     c08:      	mov.s	w23, v20[2]
     c0c:      	fcsel	s23, s0, s13, ne
     c10:      	mov.s	w2, v20[3]
     c14:      	fmov	w21, s20
     c18:      	and	x22, x21, #0x7
     c1c:      	add	x17, sp, #0x198
     c20:      	bfxil	x17, x21, #0, #3
     c24:      	ldrb	w17, [x17]
     c28:      	umov.b	w21, v11[4]
     c2c:      	and	w17, w21, w17
     c30:      	stp	q2, q3, [sp, #0x320]
     c34:      	add	x28, sp, #0x320
     c38:      	ldr	s0, [x28, x22, lsl #2]
     c3c:      	tst	w17, #0x1
     c40:      	fcsel	s0, s0, s13, ne
     c44:      	add	x17, sp, #0x198
     c48:      	bfxil	x17, x9, #0, #3
     c4c:      	ldrb	w17, [x17]
     c50:      	and	x9, x9, #0x7
     c54:      	umov.b	w22, v11[5]
     c58:      	stp	q2, q3, [sp, #0x300]
     c5c:      	add	x28, sp, #0x300
     c60:      	ldr	s20, [x28, x9, lsl #2]
     c64:      	ands	w9, w22, #0x1
     c68:      	tst	w9, w17
     c6c:      	fcsel	s20, s20, s13, ne
     c70:      	add	x9, sp, #0x198
     c74:      	bfxil	x9, x23, #0, #3
     c78:      	ldrb	w9, [x9]
     c7c:      	and	x17, x23, #0x7
     c80:      	umov.b	w23, v11[6]
     c84:      	stp	q2, q3, [sp, #0x2e0]
     c88:      	add	x28, sp, #0x2e0
     c8c:      	ldr	s21, [x28, x17, lsl #2]
     c90:      	ands	w17, w23, #0x1
     c94:      	tst	w17, w9
     c98:      	fcsel	s21, s21, s13, ne
     c9c:      	add	x9, sp, #0x198
     ca0:      	bfxil	x9, x2, #0, #3
     ca4:      	ldrb	w17, [x9]
     ca8:      	umov.b	w9, v11[7]
     cac:      	and	x2, x2, #0x7
     cb0:      	stp	q2, q3, [sp, #0x2c0]
     cb4:      	add	x28, sp, #0x2c0
     cb8:      	ldr	s24, [x28, x2, lsl #2]
     cbc:      	ands	w2, w9, #0x1
     cc0:      	tst	w2, w17
     cc4:      	fcsel	s24, s24, s13, ne
     cc8:      	mov.s	v0[1], v20[0]
     ccc:      	mov.s	v0[2], v21[0]
     cd0:      	mov.s	v0[3], v24[0]
     cd4:      	mov.s	v5[1], v6[0]
     cd8:      	mov.s	v5[2], v7[0]
     cdc:      	mov.s	v5[3], v23[0]
     ce0:      	fadd.4s	v2, v2, v5
     ce4:      	fadd.4s	v0, v3, v0
     ce8:      	movi.4s	v5, #0x2
     cec:      	eor.16b	v3, v4, v5
     cf0:      	eor.16b	v1, v1, v5
     cf4:      	fmov	w17, s1
     cf8:      	add	x2, sp, #0x198
     cfc:      	bfxil	x2, x17, #0, #3
     d00:      	ldrb	w2, [x2]
     d04:      	and	x17, x17, #0x7
     d08:      	stp	q2, q0, [sp, #0x220]
     d0c:      	add	x28, sp, #0x220
     d10:      	ldr	s1, [x28, x17, lsl #2]
     d14:      	tst	w6, w2
     d18:      	fcsel	s1, s1, s13, ne
     d1c:      	fmov	w17, s3
     d20:      	and	x2, x17, #0x7
     d24:      	add	x28, sp, #0x198
     d28:      	bfxil	x28, x17, #0, #3
     d2c:      	ldrb	w17, [x28]
     d30:      	and	w17, w21, w17
     d34:      	stp	q2, q0, [sp, #0x200]
     d38:      	add	x28, sp, #0x200
     d3c:      	ldr	s3, [x28, x2, lsl #2]
     d40:      	tst	w17, #0x1
     d44:      	fcsel	s3, s3, s13, ne
     d48:      	fadd.4s	v0, v0, v3
     d4c:      	tst	w6, w21
     d50:      	fcsel	s0, s0, s13, ne
     d54:      	ands	w17, w4, #0x1
     d58:      	fadd.4s	v1, v2, v1
     d5c:      	fadd	s0, s1, s0
     d60:      	fcsel	s1, s0, s13, ne
     d64:      	tst	w5, #0x1
     d68:      	fcsel	s2, s1, s13, ne
     d6c:      	tst	w19, #0x1
     d70:      	fcsel	s3, s1, s13, ne
     d74:      	tst	w20, #0x1
     d78:      	fcsel	s4, s1, s13, ne
     d7c:      	tst	w17, w21
     d80:      	fcsel	s0, s0, s13, ne
     d84:      	tst	w22, #0x1
     d88:      	fcsel	s5, s1, s13, ne
     d8c:      	tst	w23, #0x1
     d90:      	fcsel	s7, s1, s13, ne
     d94:      	tst	w9, #0x1
     d98:      	shl.8b	v6, v22, #0x7
     d9c:      	cmlt.8b	v6, v6, #0
     da0:      	ldr	d20, [sp, #0xc8]
     da4:      	and.8b	v6, v6, v20
     da8:      	addv.8b	b6, v6
     dac:      	fmov	w4, s6
     db0:      	fcsel	s20, s1, s13, ne
     db4:      	mov.s	v1[1], v2[0]
     db8:      	mov.s	v1[2], v3[0]
     dbc:      	mov.s	v1[3], v4[0]
     dc0:      	mov.s	v0[1], v5[0]
     dc4:      	mov.s	v0[2], v7[0]
     dc8:      	mov.s	v0[3], v20[0]
     dcc:      	ldr	w9, [sp, #0x12c]
     dd0:      	rbit	w9, w9
     dd4:      	clz	w9, w9
     dd8:      	stp	q1, q0, [sp, #0x1e0]
     ddc:      	and	x9, x9, #0x7
     de0:      	add	x17, sp, #0x1e0
     de4:      	ldr	s3, [x17, x9, lsl #2]
     de8:      	mov	b0, v22[0]
     dec:      	mov.b	v0[4], v22[1]
     df0:      	ushll.2d	v0, v0, #0x0
     df4:      	shl.2d	v0, v0, #0x3f
     df8:      	cmlt.2d	v0, v0, #0
     dfc:      	mov	b1, v22[2]
     e00:      	mov.b	v1[4], v22[3]
     e04:      	ldr	q2, [sp, #0xd0]
     e08:      	and.16b	v0, v0, v2
     e0c:      	ushll.2d	v1, v1, #0x0
     e10:      	shl.2d	v1, v1, #0x3f
     e14:      	cmlt.2d	v1, v1, #0
     e18:      	ldp	q2, q4, [sp, #0x90]
     e1c:      	and.16b	v1, v1, v2
     e20:      	mov	b2, v22[4]
     e24:      	mov.b	v2[4], v22[5]
     e28:      	ushll.2d	v2, v2, #0x0
     e2c:      	shl.2d	v2, v2, #0x3f
     e30:      	cmlt.2d	v2, v2, #0
     e34:      	and.16b	v2, v2, v4
     e38:      	mov	b4, v22[6]
     e3c:      	mov.b	v4[4], v22[7]
     e40:      	ushll.2d	v4, v4, #0x0
     e44:      	shl.2d	v4, v4, #0x3f
     e48:      	cmlt.2d	v4, v4, #0
     e4c:      	ldr	q5, [sp, #0xb0]
     e50:      	and.16b	v4, v4, v5
     e54:      	stp	q2, q4, [sp, #0x1c0]
     e58:      	stp	q0, q1, [sp, #0x1a0]
     e5c:      	and	x9, x30, #0x7
     e60:      	add	x17, sp, #0x1a0
     e64:      	ldr	x9, [x17, x9, lsl #3]
     e68:      	sub	x9, x9, x30
     e6c:      	add	x15, x15, x9, lsl #2
     e70:      	movi.2d	v2, #0000000000000000
     e74:      	movi.2d	v1, #0000000000000000
     e78:      	tbnz	w4, #0x0, 0x10bc <ltmp0+0x10bc>
     e7c:      	tbnz	w4, #0x1, 0x10c4 <ltmp0+0x10c4>
     e80:      	mov	w19, #0x20              ; =32
     e84:      	tbnz	w4, #0x2, 0x10d4 <ltmp0+0x10d4>
     e88:      	tbnz	w4, #0x3, 0x10e0 <ltmp0+0x10e0>
     e8c:      	tbnz	w4, #0x4, 0x10ec <ltmp0+0x10ec>
     e90:      	tbnz	w4, #0x5, 0x10f8 <ltmp0+0x10f8>
     e94:      	tbnz	w4, #0x6, 0x1104 <ltmp0+0x1104>
     e98:      	tbz	w4, #0x7, 0xea4 <ltmp0+0xea4>
     e9c:      	add	x9, x15, #0x1c
     ea0:      	ld1.s	{ v1 }[3], [x9]
     ea4:      	mov	x9, #0x0                ; =0
     ea8:      	fadd	s0, s3, s13
     eac:      	fmov	s3, w11
     eb0:      	fdiv	s0, s0, s3
     eb4:      	add	x15, x27, x1
     eb8:      	ldp	q3, q4, [x15]
     ebc:      	zip2.8b	v5, v22, v0
     ec0:      	ushll.4s	v5, v5, #0x0
     ec4:      	shl.4s	v5, v5, #0x1f
     ec8:      	cmlt.4s	v5, v5, #0
     ecc:      	bit.16b	v4, v1, v5
     ed0:      	zip1.8b	v5, v22, v0
     ed4:      	ushll.4s	v5, v5, #0x0
     ed8:      	shl.4s	v5, v5, #0x1f
     edc:      	cmlt.4s	v5, v5, #0
     ee0:      	bit.16b	v3, v2, v5
     ee4:      	stp	q3, q4, [x15]
     ee8:      	fmov	s3, w14
     eec:      	fadd	s0, s0, s3
     ef0:      	fsqrt	s0, s0
     ef4:      	dup.4s	v3, v0[0]
     ef8:      	ldr	q0, [sp, #0xe0]
     efc:      	fmov	x15, d0
     f00:      	add	x15, x12, x15, lsl #2
     f04:      	movi.2d	v4, #0000000000000000
     f08:      	movi.2d	v5, #0000000000000000
     f0c:      	movi.2d	v7, #0000000000000000
     f10:      	movi.2d	v20, #0000000000000000
     f14:      	b	0xf34 <ltmp0+0xf34>
     f18:      	add.2d	v5, v5, v30
     f1c:      	add.2d	v7, v7, v31
     f20:      	add.2d	v20, v20, v29
     f24:      	add.2d	v4, v4, v8
     f28:      	fmov	x9, d4
     f2c:      	cmp	x9, #0x8
     f30:      	b.ge	0x1004 <ltmp0+0x1004>
     f34:      	fmov	w17, s18
     f38:      	lsl	x9, x9, #5
     f3c:      	add	x1, x16, x9
     f40:      	ldp	q0, q22, [x1]
     f44:      	and.16b	v0, v17, v0
     f48:      	fdiv.4s	v0, v0, v3
     f4c:      	add	x1, x27, x9
     f50:      	ldp	q21, q23, [x1]
     f54:      	and.16b	v21, v17, v21
     f58:      	fmul.4s	v24, v0, v21
     f5c:      	add	x9, x15, x9
     f60:      	tbnz	w17, #0x0, 0xf98 <ltmp0+0xf98>
     f64:      	and	w17, w17, #0xff
     f68:      	tbnz	w17, #0x1, 0xfa4 <ltmp0+0xfa4>
     f6c:      	tbnz	w17, #0x2, 0xfb0 <ltmp0+0xfb0>
     f70:      	tbnz	w17, #0x3, 0xfbc <ltmp0+0xfbc>
     f74:      	and.16b	v0, v16, v22
     f78:      	fdiv.4s	v0, v0, v3
     f7c:      	and.16b	v21, v16, v23
     f80:      	fmul.4s	v22, v0, v21
     f84:      	tbnz	w17, #0x4, 0xfd8 <ltmp0+0xfd8>
     f88:      	tbnz	w17, #0x5, 0xfe0 <ltmp0+0xfe0>
     f8c:      	tbnz	w17, #0x6, 0xfec <ltmp0+0xfec>
     f90:      	tbz	w17, #0x7, 0xf18 <ltmp0+0xf18>
     f94:      	b	0xff8 <ltmp0+0xff8>
     f98:      	str	s24, [x9]
     f9c:      	and	w17, w17, #0xff
     fa0:      	tbz	w17, #0x1, 0xf6c <ltmp0+0xf6c>
     fa4:      	add	x1, x9, #0x4
     fa8:      	st1.s	{ v24 }[1], [x1]
     fac:      	tbz	w17, #0x2, 0xf70 <ltmp0+0xf70>
     fb0:      	add	x1, x9, #0x8
     fb4:      	st1.s	{ v24 }[2], [x1]
     fb8:      	tbz	w17, #0x3, 0xf74 <ltmp0+0xf74>
     fbc:      	add	x1, x9, #0xc
     fc0:      	st1.s	{ v24 }[3], [x1]
     fc4:      	and.16b	v0, v16, v22
     fc8:      	fdiv.4s	v0, v0, v3
     fcc:      	and.16b	v21, v16, v23
     fd0:      	fmul.4s	v22, v0, v21
     fd4:      	tbz	w17, #0x4, 0xf88 <ltmp0+0xf88>
     fd8:      	str	s22, [x9, #0x10]
     fdc:      	tbz	w17, #0x5, 0xf8c <ltmp0+0xf8c>
     fe0:      	add	x1, x9, #0x14
     fe4:      	st1.s	{ v22 }[1], [x1]
     fe8:      	tbz	w17, #0x6, 0xf90 <ltmp0+0xf90>
     fec:      	add	x1, x9, #0x18
     ff0:      	st1.s	{ v22 }[2], [x1]
     ff4:      	tbz	w17, #0x7, 0xf18 <ltmp0+0xf18>
     ff8:      	add	x9, x9, #0x1c
     ffc:      	st1.s	{ v22 }[3], [x9]
    1000:      	b	0xf18 <ltmp0+0xf18>
    1004:      	fdiv.4s	v0, v25, v3
    1008:      	fmul.4s	v2, v0, v2
    100c:      	ldr	q4, [sp, #0x140]
    1010:      	ldp	q7, q5, [sp, #0xf0]
    1014:      	stp	q4, q5, [sp, #0x150]
    1018:      	ldr	q0, [sp, #0x110]
    101c:      	stp	q7, q0, [sp, #0x170]
    1020:      	and	x9, x30, #0x7
    1024:      	add	x15, sp, #0x150
    1028:      	ldr	x9, [x15, x9, lsl #3]
    102c:      	sub	x9, x9, x30
    1030:      	add	x9, x12, x9, lsl #2
    1034:      	fmov	w15, s6
    1038:      	tbnz	w15, #0x0, 0x1114 <ltmp0+0x1114>
    103c:      	ldr	w12, [sp, #0x1c]
    1040:      	tbnz	w15, #0x1, 0x1120 <ltmp0+0x1120>
    1044:      	tbnz	w15, #0x2, 0x112c <ltmp0+0x112c>
    1048:      	tbnz	w15, #0x3, 0x1138 <ltmp0+0x1138>
    104c:      	fdiv.4s	v0, v19, v3
    1050:      	fmul.4s	v1, v0, v1
    1054:      	tbnz	w15, #0x4, 0x114c <ltmp0+0x114c>
    1058:      	tbnz	w15, #0x5, 0x1154 <ltmp0+0x1154>
    105c:      	tbnz	w15, #0x6, 0x1160 <ltmp0+0x1160>
    1060:      	tbz	w15, #0x7, 0x90 <ltmp0+0x90>
    1064:      	b	0x116c <ltmp0+0x116c>
    1068:      	ldr	s21, [x1]
    106c:      	tbz	w4, #0x1, 0x70c <ltmp0+0x70c>
    1070:      	add	x9, x1, #0x4
    1074:      	ld1.s	{ v21 }[1], [x9]
    1078:      	tbz	w4, #0x2, 0x710 <ltmp0+0x710>
    107c:      	add	x9, x1, #0x8
    1080:      	ld1.s	{ v21 }[2], [x9]
    1084:      	tbz	w4, #0x3, 0x714 <ltmp0+0x714>
    1088:      	add	x9, x1, #0xc
    108c:      	ld1.s	{ v21 }[3], [x9]
    1090:      	tbz	w4, #0x4, 0x718 <ltmp0+0x718>
    1094:      	add	x9, x1, #0x10
    1098:      	ld1.s	{ v19 }[0], [x9]
    109c:      	tbz	w4, #0x5, 0x71c <ltmp0+0x71c>
    10a0:      	add	x9, x1, #0x14
    10a4:      	ld1.s	{ v19 }[1], [x9]
    10a8:      	tbz	w4, #0x6, 0x720 <ltmp0+0x720>
    10ac:      	add	x9, x1, #0x18
    10b0:      	ld1.s	{ v19 }[2], [x9]
    10b4:      	tbnz	w4, #0x7, 0x724 <ltmp0+0x724>
    10b8:      	b	0x72c <ltmp0+0x72c>
    10bc:      	ldr	s2, [x15]
    10c0:      	tbz	w4, #0x1, 0xe80 <ltmp0+0xe80>
    10c4:      	add	x9, x15, #0x4
    10c8:      	ld1.s	{ v2 }[1], [x9]
    10cc:      	mov	w19, #0x20              ; =32
    10d0:      	tbz	w4, #0x2, 0xe88 <ltmp0+0xe88>
    10d4:      	add	x9, x15, #0x8
    10d8:      	ld1.s	{ v2 }[2], [x9]
    10dc:      	tbz	w4, #0x3, 0xe8c <ltmp0+0xe8c>
    10e0:      	add	x9, x15, #0xc
    10e4:      	ld1.s	{ v2 }[3], [x9]
    10e8:      	tbz	w4, #0x4, 0xe90 <ltmp0+0xe90>
    10ec:      	add	x9, x15, #0x10
    10f0:      	ld1.s	{ v1 }[0], [x9]
    10f4:      	tbz	w4, #0x5, 0xe94 <ltmp0+0xe94>
    10f8:      	add	x9, x15, #0x14
    10fc:      	ld1.s	{ v1 }[1], [x9]
    1100:      	tbz	w4, #0x6, 0xe98 <ltmp0+0xe98>
    1104:      	add	x9, x15, #0x18
    1108:      	ld1.s	{ v1 }[2], [x9]
    110c:      	tbnz	w4, #0x7, 0xe9c <ltmp0+0xe9c>
    1110:      	b	0xea4 <ltmp0+0xea4>
    1114:      	str	s2, [x9]
    1118:      	ldr	w12, [sp, #0x1c]
    111c:      	tbz	w15, #0x1, 0x1044 <ltmp0+0x1044>
    1120:      	add	x17, x9, #0x4
    1124:      	st1.s	{ v2 }[1], [x17]
    1128:      	tbz	w15, #0x2, 0x1048 <ltmp0+0x1048>
    112c:      	add	x17, x9, #0x8
    1130:      	st1.s	{ v2 }[2], [x17]
    1134:      	tbz	w15, #0x3, 0x104c <ltmp0+0x104c>
    1138:      	add	x17, x9, #0xc
    113c:      	st1.s	{ v2 }[3], [x17]
    1140:      	fdiv.4s	v0, v19, v3
    1144:      	fmul.4s	v1, v0, v1
    1148:      	tbz	w15, #0x4, 0x1058 <ltmp0+0x1058>
    114c:      	str	s1, [x9, #0x10]
    1150:      	tbz	w15, #0x5, 0x105c <ltmp0+0x105c>
    1154:      	add	x17, x9, #0x14
    1158:      	st1.s	{ v1 }[1], [x17]
    115c:      	tbz	w15, #0x6, 0x1060 <ltmp0+0x1060>
    1160:      	add	x17, x9, #0x18
    1164:      	st1.s	{ v1 }[2], [x17]
    1168:      	tbz	w15, #0x7, 0x90 <ltmp0+0x90>
    116c:      	add	x9, x9, #0x1c
    1170:      	st1.s	{ v1 }[3], [x9]
    1174:      	b	0x90 <ltmp0+0x90>
    1178:      	ldr	x9, [sp, #0x10]
    117c:      	stp	w26, w25, [x9]
    1180:      	str	w24, [x9, #0x8]
    1184:      	mov	w8, #0x18               ; =24
    1188:      	str	w8, [x9, #0x24]
    118c:      	add	sp, sp, #0x620
    1190:      	ldp	x29, x30, [sp, #0x90]
    1194:      	ldp	x20, x19, [sp, #0x80]
    1198:      	ldp	x22, x21, [sp, #0x70]
    119c:      	ldp	x24, x23, [sp, #0x60]
    11a0:      	ldp	x26, x25, [sp, #0x50]
    11a4:      	ldp	x28, x27, [sp, #0x40]
    11a8:      	ldp	d9, d8, [sp, #0x30]
    11ac:      	ldp	d11, d10, [sp, #0x20]
    11b0:      	ldp	d13, d12, [sp, #0x10]
    11b4:      	ldp	d15, d14, [sp], #0xa0
    11b8:      	ret

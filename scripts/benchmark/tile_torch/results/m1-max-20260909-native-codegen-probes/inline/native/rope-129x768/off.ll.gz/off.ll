; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [1536 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [1536 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [1536 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [1536 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot11 = alloca i64, align 8
  store i64 0, ptr %.slot11, align 4
  %tile_snapshot.spill12 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill12, align 64
  %.slot13 = alloca i64, align 8
  store i64 0, ptr %.slot13, align 4
  %tile_snapshot.spill14 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill14, align 64
  %.slot15 = alloca i64, align 8
  store i64 0, ptr %.slot15, align 4
  %tile_snapshot.spill16 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill16, align 64
  %.slot17 = alloca i64, align 8
  store i64 0, ptr %.slot17, align 4
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %.slot19 = alloca i64, align 8
  store i64 0, ptr %.slot19, align 4
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert20 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat21, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert22 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat23 = shufflevector <8 x i32> %.splatinsert22, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat23, %45
  %48 = mul i32 %36, 1
  %.splatinsert24 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat25 = shufflevector <8 x i32> %.splatinsert24, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat25, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert26 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat27 = shufflevector <8 x i32> %.splatinsert26, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat27, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert28 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat29 = shufflevector <8 x i32> %.splatinsert28, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat29
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %55, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = sub <8 x i32> %57, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %61 = select <8 x i1> %55, <8 x i32> %60, <8 x i32> zeroinitializer
  %62 = select <8 x i1> %55, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %63 = lshr <8 x i32> %61, %62
  %64 = zext <8 x i32> %63 to <8 x i64>
  %65 = select <8 x i1> %55, <8 x i64> %64, <8 x i64> zeroinitializer
  %66 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %67 = sdiv <8 x i64> %65, %66
  %68 = load <8 x i64>, ptr %.spill10, align 64
  %69 = select <8 x i1> %55, <8 x i64> %67, <8 x i64> %68
  store <8 x i64> %69, ptr %.spill10, align 64
  %70 = extractvalue { ptr, i64 } %13, 1
  %71 = extractvalue { ptr, i64 } %13, 0
  %72 = ptrtoint ptr %71 to i64
  %73 = extractvalue { ptr, i64 } %31, 1
  %74 = extractvalue { ptr, i64 } %31, 0
  %75 = ptrtoint ptr %74 to i64
  %76 = icmp uge i64 %72, %75
  %77 = sub i64 %72, %75
  %78 = icmp uge i64 %77, 396288
  %79 = and i1 %76, %78
  %80 = icmp uge i64 %75, %72
  %81 = sub i64 %75, %72
  %82 = icmp uge i64 %81, 396288
  %83 = and i1 %80, %82
  %84 = or i1 %79, %83
  %85 = and i1 true, %84
  %86 = extractvalue { ptr, i64 } %19, 1
  %87 = extractvalue { ptr, i64 } %19, 0
  %88 = ptrtoint ptr %87 to i64
  %89 = icmp uge i64 %88, %75
  %90 = sub i64 %88, %75
  %91 = icmp uge i64 %90, 396288
  %92 = and i1 %89, %91
  %93 = icmp uge i64 %75, %88
  %94 = sub i64 %75, %88
  %95 = icmp uge i64 %94, 198144
  %96 = and i1 %93, %95
  %97 = or i1 %92, %96
  %98 = and i1 %85, %97
  %99 = extractvalue { ptr, i64 } %25, 1
  %100 = extractvalue { ptr, i64 } %25, 0
  %101 = ptrtoint ptr %100 to i64
  %102 = icmp uge i64 %101, %75
  %103 = sub i64 %101, %75
  %104 = icmp uge i64 %103, 396288
  %105 = and i1 %102, %104
  %106 = icmp uge i64 %75, %101
  %107 = sub i64 %75, %101
  %108 = icmp uge i64 %107, 198144
  %109 = and i1 %106, %108
  %110 = or i1 %105, %109
  %111 = and i1 %98, %110
  br i1 %111, label %direct.true, label %direct.false

direct.schedule.1:                                ; preds = %direct.true
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.2:                                ; preds = %direct.schedule.3, %direct.schedule.1
  %.state = load i64, ptr %.slot, align 4
  %112 = icmp slt i64 %.state, 48
  br i1 %112, label %direct.true30, label %direct.false31

direct.schedule.3:                                ; preds = %direct.true30
  %.state32 = load i64, ptr %.slot, align 4
  %113 = mul i64 %.state32, 8
  %.splatinsert33 = insertelement <8 x i64> poison, i64 %113, i64 0
  %.splat34 = shufflevector <8 x i64> %.splatinsert33, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %114 = add <8 x i64> %.splat34, %.spill.load
  %.spill.load35 = load <8 x i64>, ptr %.spill10, align 64
  %115 = add <8 x i64> %.spill.load35, zeroinitializer
  %116 = add <8 x i64> zeroinitializer, %115
  %117 = add <8 x i64> zeroinitializer, %114
  %118 = mul <8 x i64> %116, splat (i64 768)
  %119 = add <8 x i64> %118, %117
  %120 = extractvalue { ptr, i64 } %13, 0
  %121 = extractelement <8 x i64> %119, i32 0
  %122 = sub i64 %121, 0
  %123 = mul i64 %122, 4
  %buffer.contiguous.address = getelementptr i8, ptr %120, i64 %123
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %124 = add <8 x i64> splat (i64 384), %114
  %125 = add <8 x i64> %118, %124
  %126 = extractvalue { ptr, i64 } %13, 0
  %127 = extractelement <8 x i64> %125, i32 0
  %128 = sub i64 %127, 0
  %129 = mul i64 %128, 4
  %buffer.contiguous.address36 = getelementptr i8, ptr %126, i64 %129
  %buffer.contiguous.load37 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address36, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %130 = mul <8 x i64> %116, splat (i64 384)
  %131 = add <8 x i64> %130, %117
  %132 = extractvalue { ptr, i64 } %19, 0
  %133 = extractelement <8 x i64> %131, i32 0
  %134 = sub i64 %133, 0
  %135 = mul i64 %134, 4
  %buffer.contiguous.address38 = getelementptr i8, ptr %132, i64 %135
  %buffer.contiguous.load39 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address38, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %136 = extractvalue { ptr, i64 } %25, 0
  %137 = extractelement <8 x i64> %131, i32 0
  %138 = sub i64 %137, 0
  %139 = mul i64 %138, 4
  %buffer.contiguous.address40 = getelementptr i8, ptr %136, i64 %139
  %buffer.contiguous.load41 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address40, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %140 = fmul <8 x float> %buffer.contiguous.load, %buffer.contiguous.load39
  %141 = fmul <8 x float> %buffer.contiguous.load37, %buffer.contiguous.load41
  %142 = fsub <8 x float> %140, %141
  %143 = extractvalue { ptr, i64 } %31, 0
  %144 = extractelement <8 x i64> %119, i32 0
  %145 = sub i64 %144, 0
  %146 = mul i64 %145, 4
  %buffer.contiguous.address42 = getelementptr i8, ptr %143, i64 %146
  call void @llvm.masked.store.v8f32.p0(<8 x float> %142, ptr %buffer.contiguous.address42, i32 1, <8 x i1> %55)
  %147 = fmul <8 x float> %buffer.contiguous.load, %buffer.contiguous.load41
  %148 = fmul <8 x float> %buffer.contiguous.load37, %buffer.contiguous.load39
  %149 = fadd <8 x float> %147, %148
  %150 = extractvalue { ptr, i64 } %31, 0
  %151 = extractelement <8 x i64> %125, i32 0
  %152 = sub i64 %151, 0
  %153 = mul i64 %152, 4
  %buffer.contiguous.address43 = getelementptr i8, ptr %150, i64 %153
  call void @llvm.masked.store.v8f32.p0(<8 x float> %149, ptr %buffer.contiguous.address43, i32 1, <8 x i1> %55)
  %.state44 = load i64, ptr %.slot, align 4
  %154 = add i64 %.state44, 1
  store i64 %154, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.4:                                ; preds = %direct.false145, %direct.false31
  ret void

direct.schedule.5:                                ; preds = %direct.false
  %155 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %155, 0
  %158 = select <8 x i1> %55, <8 x ptr> %156, <8 x ptr> %157
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %155, 1
  %161 = select <8 x i1> %55, <8 x i64> %159, <8 x i64> %160
  %162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %158, 0
  %163 = insertvalue { <8 x ptr>, <8 x i64> } %162, <8 x i64> %161, 1
  store { <8 x ptr>, <8 x i64> } %163, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot11, align 4
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state45 = load i64, ptr %.slot11, align 4
  %164 = icmp slt i64 %.state45, 48
  br i1 %164, label %direct.true46, label %direct.false47

direct.schedule.7:                                ; preds = %direct.true46
  %.state48 = load i64, ptr %.slot11, align 4
  %165 = mul i64 %.state48, 8
  %.splatinsert49 = insertelement <8 x i64> poison, i64 %165, i64 0
  %.splat50 = shufflevector <8 x i64> %.splatinsert49, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load51 = load <8 x i64>, ptr %.spill, align 64
  %166 = add <8 x i64> %.splat50, %.spill.load51
  %.spill.load52 = load <8 x i64>, ptr %.spill10, align 64
  %167 = add <8 x i64> %.spill.load52, zeroinitializer
  %168 = add <8 x i64> zeroinitializer, %167
  %169 = add <8 x i64> zeroinitializer, %166
  %170 = mul <8 x i64> %168, splat (i64 768)
  %171 = add <8 x i64> %170, %169
  %172 = extractvalue { ptr, i64 } %13, 0
  %173 = extractelement <8 x i64> %171, i32 0
  %174 = sub i64 %173, 0
  %175 = mul i64 %174, 4
  %buffer.contiguous.address53 = getelementptr i8, ptr %172, i64 %175
  %buffer.contiguous.load54 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address53, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state55 = load i64, ptr %.slot11, align 4
  %.splatinsert56 = insertelement <8 x i64> poison, i64 %.state55, i64 0
  %.splat57 = shufflevector <8 x i64> %.splatinsert56, <8 x i64> poison, <8 x i32> zeroinitializer
  %178 = mul <8 x i64> %.splat57, splat (i64 32)
  %179 = add <8 x i64> %177, %178
  %180 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %176, 0
  %181 = insertvalue { <8 x ptr>, <8 x i64> } %180, <8 x i64> %179, 1
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %181, 1
  %184 = extractelement <8 x ptr> %182, i32 0
  %185 = extractelement <8 x i64> %183, i32 0
  %186 = sub i64 %185, 0
  %187 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %188 = select i1 %187, i64 %186, i64 0
  %private.contiguous.address = getelementptr i8, ptr %184, i64 %188
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %189 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load54, <8 x float> %private.contiguous.preserve
  store <8 x float> %189, ptr %private.contiguous.address, align 4
  %.state58 = load i64, ptr %.slot11, align 4
  %190 = add i64 %.state58, 1
  store i64 %190, ptr %.slot11, align 4
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false47
  %191 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %191, 0
  %194 = select <8 x i1> %55, <8 x ptr> %192, <8 x ptr> %193
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %191, 1
  %197 = select <8 x i1> %55, <8 x i64> %195, <8 x i64> %196
  %198 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %194, 0
  %199 = insertvalue { <8 x ptr>, <8 x i64> } %198, <8 x i64> %197, 1
  store { <8 x ptr>, <8 x i64> } %199, ptr %tile_snapshot.spill12, align 64
  store i64 0, ptr %.slot13, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.10, %direct.schedule.8
  %.state59 = load i64, ptr %.slot13, align 4
  %200 = icmp slt i64 %.state59, 48
  br i1 %200, label %direct.true60, label %direct.false61

direct.schedule.10:                               ; preds = %direct.true60
  %.state62 = load i64, ptr %.slot13, align 4
  %201 = mul i64 %.state62, 8
  %.splatinsert63 = insertelement <8 x i64> poison, i64 %201, i64 0
  %.splat64 = shufflevector <8 x i64> %.splatinsert63, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load65 = load <8 x i64>, ptr %.spill, align 64
  %202 = add <8 x i64> %.splat64, %.spill.load65
  %.spill.load66 = load <8 x i64>, ptr %.spill10, align 64
  %203 = add <8 x i64> %.spill.load66, zeroinitializer
  %204 = add <8 x i64> zeroinitializer, %203
  %205 = add <8 x i64> splat (i64 384), %202
  %206 = mul <8 x i64> %204, splat (i64 768)
  %207 = add <8 x i64> %206, %205
  %208 = extractvalue { ptr, i64 } %13, 0
  %209 = extractelement <8 x i64> %207, i32 0
  %210 = sub i64 %209, 0
  %211 = mul i64 %210, 4
  %buffer.contiguous.address67 = getelementptr i8, ptr %208, i64 %211
  %buffer.contiguous.load68 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address67, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load69 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 0
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 1
  %.state70 = load i64, ptr %.slot13, align 4
  %.splatinsert71 = insertelement <8 x i64> poison, i64 %.state70, i64 0
  %.splat72 = shufflevector <8 x i64> %.splatinsert71, <8 x i64> poison, <8 x i32> zeroinitializer
  %214 = mul <8 x i64> %.splat72, splat (i64 32)
  %215 = add <8 x i64> %213, %214
  %216 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %212, 0
  %217 = insertvalue { <8 x ptr>, <8 x i64> } %216, <8 x i64> %215, 1
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %217, 1
  %220 = extractelement <8 x ptr> %218, i32 0
  %221 = extractelement <8 x i64> %219, i32 0
  %222 = sub i64 %221, 0
  %223 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %224 = select i1 %223, i64 %222, i64 0
  %private.contiguous.address73 = getelementptr i8, ptr %220, i64 %224
  %private.contiguous.preserve74 = load <8 x float>, ptr %private.contiguous.address73, align 4
  %225 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load68, <8 x float> %private.contiguous.preserve74
  store <8 x float> %225, ptr %private.contiguous.address73, align 4
  %.state75 = load i64, ptr %.slot13, align 4
  %226 = add i64 %.state75, 1
  store i64 %226, ptr %.slot13, align 4
  br label %direct.schedule.9

direct.schedule.11:                               ; preds = %direct.false61
  %227 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %227, 0
  %230 = select <8 x i1> %55, <8 x ptr> %228, <8 x ptr> %229
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %227, 1
  %233 = select <8 x i1> %55, <8 x i64> %231, <8 x i64> %232
  %234 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %230, 0
  %235 = insertvalue { <8 x ptr>, <8 x i64> } %234, <8 x i64> %233, 1
  store { <8 x ptr>, <8 x i64> } %235, ptr %tile_snapshot.spill14, align 64
  store i64 0, ptr %.slot15, align 4
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.13, %direct.schedule.11
  %.state76 = load i64, ptr %.slot15, align 4
  %236 = icmp slt i64 %.state76, 48
  br i1 %236, label %direct.true77, label %direct.false78

direct.schedule.13:                               ; preds = %direct.true77
  %.state79 = load i64, ptr %.slot15, align 4
  %237 = mul i64 %.state79, 8
  %.splatinsert80 = insertelement <8 x i64> poison, i64 %237, i64 0
  %.splat81 = shufflevector <8 x i64> %.splatinsert80, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load82 = load <8 x i64>, ptr %.spill, align 64
  %238 = add <8 x i64> %.splat81, %.spill.load82
  %.spill.load83 = load <8 x i64>, ptr %.spill10, align 64
  %239 = add <8 x i64> %.spill.load83, zeroinitializer
  %240 = add <8 x i64> zeroinitializer, %239
  %241 = add <8 x i64> zeroinitializer, %238
  %242 = mul <8 x i64> %240, splat (i64 384)
  %243 = add <8 x i64> %242, %241
  %244 = extractvalue { ptr, i64 } %19, 0
  %245 = extractelement <8 x i64> %243, i32 0
  %246 = sub i64 %245, 0
  %247 = mul i64 %246, 4
  %buffer.contiguous.address84 = getelementptr i8, ptr %244, i64 %247
  %buffer.contiguous.load85 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address84, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load86 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 1
  %.state87 = load i64, ptr %.slot15, align 4
  %.splatinsert88 = insertelement <8 x i64> poison, i64 %.state87, i64 0
  %.splat89 = shufflevector <8 x i64> %.splatinsert88, <8 x i64> poison, <8 x i32> zeroinitializer
  %250 = mul <8 x i64> %.splat89, splat (i64 32)
  %251 = add <8 x i64> %249, %250
  %252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %253 = insertvalue { <8 x ptr>, <8 x i64> } %252, <8 x i64> %251, 1
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %253, 1
  %256 = extractelement <8 x ptr> %254, i32 0
  %257 = extractelement <8 x i64> %255, i32 0
  %258 = sub i64 %257, 0
  %259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %260 = select i1 %259, i64 %258, i64 0
  %private.contiguous.address90 = getelementptr i8, ptr %256, i64 %260
  %private.contiguous.preserve91 = load <8 x float>, ptr %private.contiguous.address90, align 4
  %261 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load85, <8 x float> %private.contiguous.preserve91
  store <8 x float> %261, ptr %private.contiguous.address90, align 4
  %.state92 = load i64, ptr %.slot15, align 4
  %262 = add i64 %.state92, 1
  store i64 %262, ptr %.slot15, align 4
  br label %direct.schedule.12

direct.schedule.14:                               ; preds = %direct.false78
  %263 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %264 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %263, 0
  %266 = select <8 x i1> %55, <8 x ptr> %264, <8 x ptr> %265
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %263, 1
  %269 = select <8 x i1> %55, <8 x i64> %267, <8 x i64> %268
  %270 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %266, 0
  %271 = insertvalue { <8 x ptr>, <8 x i64> } %270, <8 x i64> %269, 1
  store { <8 x ptr>, <8 x i64> } %271, ptr %tile_snapshot.spill16, align 64
  store i64 0, ptr %.slot17, align 4
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.16, %direct.schedule.14
  %.state93 = load i64, ptr %.slot17, align 4
  %272 = icmp slt i64 %.state93, 48
  br i1 %272, label %direct.true94, label %direct.false95

direct.schedule.16:                               ; preds = %direct.true94
  %.state96 = load i64, ptr %.slot17, align 4
  %273 = mul i64 %.state96, 8
  %.splatinsert97 = insertelement <8 x i64> poison, i64 %273, i64 0
  %.splat98 = shufflevector <8 x i64> %.splatinsert97, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load99 = load <8 x i64>, ptr %.spill, align 64
  %274 = add <8 x i64> %.splat98, %.spill.load99
  %.spill.load100 = load <8 x i64>, ptr %.spill10, align 64
  %275 = add <8 x i64> %.spill.load100, zeroinitializer
  %276 = add <8 x i64> zeroinitializer, %275
  %277 = add <8 x i64> zeroinitializer, %274
  %278 = mul <8 x i64> %276, splat (i64 384)
  %279 = add <8 x i64> %278, %277
  %280 = extractvalue { ptr, i64 } %25, 0
  %281 = extractelement <8 x i64> %279, i32 0
  %282 = sub i64 %281, 0
  %283 = mul i64 %282, 4
  %buffer.contiguous.address101 = getelementptr i8, ptr %280, i64 %283
  %buffer.contiguous.load102 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address101, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load103 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load103, 0
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load103, 1
  %.state104 = load i64, ptr %.slot17, align 4
  %.splatinsert105 = insertelement <8 x i64> poison, i64 %.state104, i64 0
  %.splat106 = shufflevector <8 x i64> %.splatinsert105, <8 x i64> poison, <8 x i32> zeroinitializer
  %286 = mul <8 x i64> %.splat106, splat (i64 32)
  %287 = add <8 x i64> %285, %286
  %288 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %284, 0
  %289 = insertvalue { <8 x ptr>, <8 x i64> } %288, <8 x i64> %287, 1
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %289, 1
  %292 = extractelement <8 x ptr> %290, i32 0
  %293 = extractelement <8 x i64> %291, i32 0
  %294 = sub i64 %293, 0
  %295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %296 = select i1 %295, i64 %294, i64 0
  %private.contiguous.address107 = getelementptr i8, ptr %292, i64 %296
  %private.contiguous.preserve108 = load <8 x float>, ptr %private.contiguous.address107, align 4
  %297 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load102, <8 x float> %private.contiguous.preserve108
  store <8 x float> %297, ptr %private.contiguous.address107, align 4
  %.state109 = load i64, ptr %.slot17, align 4
  %298 = add i64 %.state109, 1
  store i64 %298, ptr %.slot17, align 4
  br label %direct.schedule.15

direct.schedule.17:                               ; preds = %direct.false95
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.18

direct.schedule.18:                               ; preds = %direct.schedule.19, %direct.schedule.17
  %.state110 = load i64, ptr %.slot18, align 4
  %299 = icmp slt i64 %.state110, 48
  br i1 %299, label %direct.true111, label %direct.false112

direct.schedule.19:                               ; preds = %direct.true111
  %.state113 = load i64, ptr %.slot18, align 4
  %300 = mul i64 %.state113, 8
  %.splatinsert114 = insertelement <8 x i64> poison, i64 %300, i64 0
  %.splat115 = shufflevector <8 x i64> %.splatinsert114, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load116 = load <8 x i64>, ptr %.spill, align 64
  %301 = add <8 x i64> %.splat115, %.spill.load116
  %.spill.load117 = load <8 x i64>, ptr %.spill10, align 64
  %302 = add <8 x i64> %.spill.load117, zeroinitializer
  %303 = add <8 x i64> zeroinitializer, %302
  %304 = add <8 x i64> zeroinitializer, %301
  %305 = mul <8 x i64> %303, splat (i64 768)
  %306 = add <8 x i64> %305, %304
  %tile_snapshot.spill.load118 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %307 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 0
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 1
  %.state119 = load i64, ptr %.slot18, align 4
  %.splatinsert120 = insertelement <8 x i64> poison, i64 %.state119, i64 0
  %.splat121 = shufflevector <8 x i64> %.splatinsert120, <8 x i64> poison, <8 x i32> zeroinitializer
  %309 = mul <8 x i64> %.splat121, splat (i64 32)
  %310 = add <8 x i64> %308, %309
  %311 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %307, 0
  %312 = insertvalue { <8 x ptr>, <8 x i64> } %311, <8 x i64> %310, 1
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %312, 1
  %315 = extractelement <8 x ptr> %313, i32 0
  %316 = extractelement <8 x i64> %314, i32 0
  %317 = sub i64 %316, 0
  %318 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %319 = select i1 %318, i64 %317, i64 0
  %private.contiguous.address122 = getelementptr i8, ptr %315, i64 %319
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address122, align 4
  %320 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load123 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 0
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 1
  %.state124 = load i64, ptr %.slot18, align 4
  %.splatinsert125 = insertelement <8 x i64> poison, i64 %.state124, i64 0
  %.splat126 = shufflevector <8 x i64> %.splatinsert125, <8 x i64> poison, <8 x i32> zeroinitializer
  %323 = mul <8 x i64> %.splat126, splat (i64 32)
  %324 = add <8 x i64> %322, %323
  %325 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %321, 0
  %326 = insertvalue { <8 x ptr>, <8 x i64> } %325, <8 x i64> %324, 1
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %326, 1
  %329 = extractelement <8 x ptr> %327, i32 0
  %330 = extractelement <8 x i64> %328, i32 0
  %331 = sub i64 %330, 0
  %332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %333 = select i1 %332, i64 %331, i64 0
  %private.contiguous.address127 = getelementptr i8, ptr %329, i64 %333
  %private.contiguous.load128 = load <8 x float>, ptr %private.contiguous.address127, align 4
  %334 = select <8 x i1> %55, <8 x float> %private.contiguous.load128, <8 x float> zeroinitializer
  %335 = fmul <8 x float> %320, %334
  %tile_snapshot.spill.load129 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %336 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load129, 0
  %337 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load129, 1
  %.state130 = load i64, ptr %.slot18, align 4
  %.splatinsert131 = insertelement <8 x i64> poison, i64 %.state130, i64 0
  %.splat132 = shufflevector <8 x i64> %.splatinsert131, <8 x i64> poison, <8 x i32> zeroinitializer
  %338 = mul <8 x i64> %.splat132, splat (i64 32)
  %339 = add <8 x i64> %337, %338
  %340 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %336, 0
  %341 = insertvalue { <8 x ptr>, <8 x i64> } %340, <8 x i64> %339, 1
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %341, 1
  %344 = extractelement <8 x ptr> %342, i32 0
  %345 = extractelement <8 x i64> %343, i32 0
  %346 = sub i64 %345, 0
  %347 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %348 = select i1 %347, i64 %346, i64 0
  %private.contiguous.address133 = getelementptr i8, ptr %344, i64 %348
  %private.contiguous.load134 = load <8 x float>, ptr %private.contiguous.address133, align 4
  %349 = select <8 x i1> %55, <8 x float> %private.contiguous.load134, <8 x float> zeroinitializer
  %tile_snapshot.spill.load135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 0
  %351 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 1
  %.state136 = load i64, ptr %.slot18, align 4
  %.splatinsert137 = insertelement <8 x i64> poison, i64 %.state136, i64 0
  %.splat138 = shufflevector <8 x i64> %.splatinsert137, <8 x i64> poison, <8 x i32> zeroinitializer
  %352 = mul <8 x i64> %.splat138, splat (i64 32)
  %353 = add <8 x i64> %351, %352
  %354 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %350, 0
  %355 = insertvalue { <8 x ptr>, <8 x i64> } %354, <8 x i64> %353, 1
  %356 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %355, 1
  %358 = extractelement <8 x ptr> %356, i32 0
  %359 = extractelement <8 x i64> %357, i32 0
  %360 = sub i64 %359, 0
  %361 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %362 = select i1 %361, i64 %360, i64 0
  %private.contiguous.address139 = getelementptr i8, ptr %358, i64 %362
  %private.contiguous.load140 = load <8 x float>, ptr %private.contiguous.address139, align 4
  %363 = select <8 x i1> %55, <8 x float> %private.contiguous.load140, <8 x float> zeroinitializer
  %364 = fmul <8 x float> %349, %363
  %365 = fsub <8 x float> %335, %364
  %366 = extractvalue { ptr, i64 } %31, 0
  %367 = extractelement <8 x i64> %306, i32 0
  %368 = sub i64 %367, 0
  %369 = mul i64 %368, 4
  %buffer.contiguous.address141 = getelementptr i8, ptr %366, i64 %369
  call void @llvm.masked.store.v8f32.p0(<8 x float> %365, ptr %buffer.contiguous.address141, i32 1, <8 x i1> %55)
  %.state142 = load i64, ptr %.slot18, align 4
  %370 = add i64 %.state142, 1
  store i64 %370, ptr %.slot18, align 4
  br label %direct.schedule.18

direct.schedule.20:                               ; preds = %direct.false112
  store i64 0, ptr %.slot19, align 4
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.22, %direct.schedule.20
  %.state143 = load i64, ptr %.slot19, align 4
  %371 = icmp slt i64 %.state143, 48
  br i1 %371, label %direct.true144, label %direct.false145

direct.schedule.22:                               ; preds = %direct.true144
  %.state146 = load i64, ptr %.slot19, align 4
  %372 = mul i64 %.state146, 8
  %.splatinsert147 = insertelement <8 x i64> poison, i64 %372, i64 0
  %.splat148 = shufflevector <8 x i64> %.splatinsert147, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load149 = load <8 x i64>, ptr %.spill, align 64
  %373 = add <8 x i64> %.splat148, %.spill.load149
  %.spill.load150 = load <8 x i64>, ptr %.spill10, align 64
  %374 = add <8 x i64> %.spill.load150, zeroinitializer
  %375 = add <8 x i64> zeroinitializer, %374
  %376 = add <8 x i64> splat (i64 384), %373
  %377 = mul <8 x i64> %375, splat (i64 768)
  %378 = add <8 x i64> %377, %376
  %tile_snapshot.spill.load151 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %379 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load151, 0
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load151, 1
  %.state152 = load i64, ptr %.slot19, align 4
  %.splatinsert153 = insertelement <8 x i64> poison, i64 %.state152, i64 0
  %.splat154 = shufflevector <8 x i64> %.splatinsert153, <8 x i64> poison, <8 x i32> zeroinitializer
  %381 = mul <8 x i64> %.splat154, splat (i64 32)
  %382 = add <8 x i64> %380, %381
  %383 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %379, 0
  %384 = insertvalue { <8 x ptr>, <8 x i64> } %383, <8 x i64> %382, 1
  %385 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %384, 1
  %387 = extractelement <8 x ptr> %385, i32 0
  %388 = extractelement <8 x i64> %386, i32 0
  %389 = sub i64 %388, 0
  %390 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %391 = select i1 %390, i64 %389, i64 0
  %private.contiguous.address155 = getelementptr i8, ptr %387, i64 %391
  %private.contiguous.load156 = load <8 x float>, ptr %private.contiguous.address155, align 4
  %392 = select <8 x i1> %55, <8 x float> %private.contiguous.load156, <8 x float> zeroinitializer
  %tile_snapshot.spill.load157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 0
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 1
  %.state158 = load i64, ptr %.slot19, align 4
  %.splatinsert159 = insertelement <8 x i64> poison, i64 %.state158, i64 0
  %.splat160 = shufflevector <8 x i64> %.splatinsert159, <8 x i64> poison, <8 x i32> zeroinitializer
  %395 = mul <8 x i64> %.splat160, splat (i64 32)
  %396 = add <8 x i64> %394, %395
  %397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %393, 0
  %398 = insertvalue { <8 x ptr>, <8 x i64> } %397, <8 x i64> %396, 1
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %398, 1
  %401 = extractelement <8 x ptr> %399, i32 0
  %402 = extractelement <8 x i64> %400, i32 0
  %403 = sub i64 %402, 0
  %404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %405 = select i1 %404, i64 %403, i64 0
  %private.contiguous.address161 = getelementptr i8, ptr %401, i64 %405
  %private.contiguous.load162 = load <8 x float>, ptr %private.contiguous.address161, align 4
  %406 = select <8 x i1> %55, <8 x float> %private.contiguous.load162, <8 x float> zeroinitializer
  %407 = fmul <8 x float> %392, %406
  %tile_snapshot.spill.load163 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %.state164 = load i64, ptr %.slot19, align 4
  %.splatinsert165 = insertelement <8 x i64> poison, i64 %.state164, i64 0
  %.splat166 = shufflevector <8 x i64> %.splatinsert165, <8 x i64> poison, <8 x i32> zeroinitializer
  %410 = mul <8 x i64> %.splat166, splat (i64 32)
  %411 = add <8 x i64> %409, %410
  %412 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %408, 0
  %413 = insertvalue { <8 x ptr>, <8 x i64> } %412, <8 x i64> %411, 1
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %413, 1
  %416 = extractelement <8 x ptr> %414, i32 0
  %417 = extractelement <8 x i64> %415, i32 0
  %418 = sub i64 %417, 0
  %419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %420 = select i1 %419, i64 %418, i64 0
  %private.contiguous.address167 = getelementptr i8, ptr %416, i64 %420
  %private.contiguous.load168 = load <8 x float>, ptr %private.contiguous.address167, align 4
  %421 = select <8 x i1> %55, <8 x float> %private.contiguous.load168, <8 x float> zeroinitializer
  %tile_snapshot.spill.load169 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 1
  %.state170 = load i64, ptr %.slot19, align 4
  %.splatinsert171 = insertelement <8 x i64> poison, i64 %.state170, i64 0
  %.splat172 = shufflevector <8 x i64> %.splatinsert171, <8 x i64> poison, <8 x i32> zeroinitializer
  %424 = mul <8 x i64> %.splat172, splat (i64 32)
  %425 = add <8 x i64> %423, %424
  %426 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %422, 0
  %427 = insertvalue { <8 x ptr>, <8 x i64> } %426, <8 x i64> %425, 1
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %429 = extractvalue { <8 x ptr>, <8 x i64> } %427, 1
  %430 = extractelement <8 x ptr> %428, i32 0
  %431 = extractelement <8 x i64> %429, i32 0
  %432 = sub i64 %431, 0
  %433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %434 = select i1 %433, i64 %432, i64 0
  %private.contiguous.address173 = getelementptr i8, ptr %430, i64 %434
  %private.contiguous.load174 = load <8 x float>, ptr %private.contiguous.address173, align 4
  %435 = select <8 x i1> %55, <8 x float> %private.contiguous.load174, <8 x float> zeroinitializer
  %436 = fmul <8 x float> %421, %435
  %437 = fadd <8 x float> %407, %436
  %438 = extractvalue { ptr, i64 } %31, 0
  %439 = extractelement <8 x i64> %378, i32 0
  %440 = sub i64 %439, 0
  %441 = mul i64 %440, 4
  %buffer.contiguous.address175 = getelementptr i8, ptr %438, i64 %441
  call void @llvm.masked.store.v8f32.p0(<8 x float> %437, ptr %buffer.contiguous.address175, i32 1, <8 x i1> %55)
  %.state176 = load i64, ptr %.slot19, align 4
  %442 = add i64 %.state176, 1
  store i64 %442, ptr %.slot19, align 4
  br label %direct.schedule.21

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.0
  br label %direct.schedule.1

direct.false:                                     ; preds = %direct.schedule.0
  br label %direct.schedule.5

direct.true30:                                    ; preds = %direct.schedule.2
  br label %direct.schedule.3

direct.false31:                                   ; preds = %direct.schedule.2
  br label %direct.schedule.4

direct.true46:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false47:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true60:                                    ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false61:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.11

direct.true77:                                    ; preds = %direct.schedule.12
  br label %direct.schedule.13

direct.false78:                                   ; preds = %direct.schedule.12
  br label %direct.schedule.14

direct.true94:                                    ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false95:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.17

direct.true111:                                   ; preds = %direct.schedule.18
  br label %direct.schedule.19

direct.false112:                                  ; preds = %direct.schedule.18
  br label %direct.schedule.20

direct.true144:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false145:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.4
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [1536 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [1536 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [1536 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [1536 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot11 = alloca i64, align 8
  store i64 0, ptr %.slot11, align 4
  %tile_snapshot.spill12 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill12, align 64
  %.slot13 = alloca i64, align 8
  store i64 0, ptr %.slot13, align 4
  %tile_snapshot.spill14 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill14, align 64
  %.slot15 = alloca i64, align 8
  store i64 0, ptr %.slot15, align 4
  %tile_snapshot.spill16 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill16, align 64
  %.slot17 = alloca i64, align 8
  store i64 0, ptr %.slot17, align 4
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %.slot19 = alloca i64, align 8
  store i64 0, ptr %.slot19, align 4
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert20 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat21, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert22 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat23 = shufflevector <8 x i32> %.splatinsert22, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat23, %45
  %48 = mul i32 %36, 1
  %.splatinsert24 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat25 = shufflevector <8 x i32> %.splatinsert24, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat25, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert26 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat27 = shufflevector <8 x i32> %.splatinsert26, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat27, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert28 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat29 = shufflevector <8 x i32> %.splatinsert28, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat29
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %55, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = sub <8 x i32> %57, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %61 = select <8 x i1> %55, <8 x i32> %60, <8 x i32> zeroinitializer
  %62 = select <8 x i1> %55, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %63 = lshr <8 x i32> %61, %62
  %64 = zext <8 x i32> %63 to <8 x i64>
  %65 = select <8 x i1> %55, <8 x i64> %64, <8 x i64> zeroinitializer
  %66 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %67 = sdiv <8 x i64> %65, %66
  %68 = load <8 x i64>, ptr %.spill10, align 64
  %69 = select <8 x i1> %55, <8 x i64> %67, <8 x i64> %68
  store <8 x i64> %69, ptr %.spill10, align 64
  %70 = extractvalue { ptr, i64 } %13, 1
  %71 = extractvalue { ptr, i64 } %13, 0
  %72 = ptrtoint ptr %71 to i64
  %73 = extractvalue { ptr, i64 } %31, 1
  %74 = extractvalue { ptr, i64 } %31, 0
  %75 = ptrtoint ptr %74 to i64
  %76 = icmp uge i64 %72, %75
  %77 = sub i64 %72, %75
  %78 = icmp uge i64 %77, 396288
  %79 = and i1 %76, %78
  %80 = icmp uge i64 %75, %72
  %81 = sub i64 %75, %72
  %82 = icmp uge i64 %81, 396288
  %83 = and i1 %80, %82
  %84 = or i1 %79, %83
  %85 = and i1 true, %84
  %86 = extractvalue { ptr, i64 } %19, 1
  %87 = extractvalue { ptr, i64 } %19, 0
  %88 = ptrtoint ptr %87 to i64
  %89 = icmp uge i64 %88, %75
  %90 = sub i64 %88, %75
  %91 = icmp uge i64 %90, 396288
  %92 = and i1 %89, %91
  %93 = icmp uge i64 %75, %88
  %94 = sub i64 %75, %88
  %95 = icmp uge i64 %94, 198144
  %96 = and i1 %93, %95
  %97 = or i1 %92, %96
  %98 = and i1 %85, %97
  %99 = extractvalue { ptr, i64 } %25, 1
  %100 = extractvalue { ptr, i64 } %25, 0
  %101 = ptrtoint ptr %100 to i64
  %102 = icmp uge i64 %101, %75
  %103 = sub i64 %101, %75
  %104 = icmp uge i64 %103, 396288
  %105 = and i1 %102, %104
  %106 = icmp uge i64 %75, %101
  %107 = sub i64 %75, %101
  %108 = icmp uge i64 %107, 198144
  %109 = and i1 %106, %108
  %110 = or i1 %105, %109
  %111 = and i1 %98, %110
  br i1 %111, label %direct.true, label %direct.false

direct.schedule.1:                                ; preds = %direct.true
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.2:                                ; preds = %direct.schedule.3, %direct.schedule.1
  %.state = load i64, ptr %.slot, align 4
  %112 = icmp slt i64 %.state, 48
  br i1 %112, label %direct.true30, label %direct.false31

direct.schedule.3:                                ; preds = %direct.true30
  %.state32 = load i64, ptr %.slot, align 4
  %113 = mul i64 %.state32, 8
  %.splatinsert33 = insertelement <8 x i64> poison, i64 %113, i64 0
  %.splat34 = shufflevector <8 x i64> %.splatinsert33, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %114 = add <8 x i64> %.splat34, %.spill.load
  %.spill.load35 = load <8 x i64>, ptr %.spill10, align 64
  %115 = add <8 x i64> %.spill.load35, zeroinitializer
  %116 = add <8 x i64> zeroinitializer, %115
  %117 = add <8 x i64> zeroinitializer, %114
  %118 = mul <8 x i64> %116, splat (i64 768)
  %119 = add <8 x i64> %118, %117
  %120 = extractvalue { ptr, i64 } %13, 0
  %121 = extractelement <8 x i64> %119, i32 0
  %122 = sub i64 %121, 0
  %123 = mul i64 %122, 4
  %buffer.contiguous.address = getelementptr i8, ptr %120, i64 %123
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %124 = add <8 x i64> splat (i64 384), %114
  %125 = add <8 x i64> %118, %124
  %126 = extractvalue { ptr, i64 } %13, 0
  %127 = extractelement <8 x i64> %125, i32 0
  %128 = sub i64 %127, 0
  %129 = mul i64 %128, 4
  %buffer.contiguous.address36 = getelementptr i8, ptr %126, i64 %129
  %buffer.contiguous.load37 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address36, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %130 = mul <8 x i64> %116, splat (i64 384)
  %131 = add <8 x i64> %130, %117
  %132 = extractvalue { ptr, i64 } %19, 0
  %133 = extractelement <8 x i64> %131, i32 0
  %134 = sub i64 %133, 0
  %135 = mul i64 %134, 4
  %buffer.contiguous.address38 = getelementptr i8, ptr %132, i64 %135
  %buffer.contiguous.load39 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address38, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %136 = extractvalue { ptr, i64 } %25, 0
  %137 = extractelement <8 x i64> %131, i32 0
  %138 = sub i64 %137, 0
  %139 = mul i64 %138, 4
  %buffer.contiguous.address40 = getelementptr i8, ptr %136, i64 %139
  %buffer.contiguous.load41 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address40, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %140 = fmul <8 x float> %buffer.contiguous.load, %buffer.contiguous.load39
  %141 = fmul <8 x float> %buffer.contiguous.load37, %buffer.contiguous.load41
  %142 = fsub <8 x float> %140, %141
  %143 = extractvalue { ptr, i64 } %31, 0
  %144 = extractelement <8 x i64> %119, i32 0
  %145 = sub i64 %144, 0
  %146 = mul i64 %145, 4
  %buffer.contiguous.address42 = getelementptr i8, ptr %143, i64 %146
  call void @llvm.masked.store.v8f32.p0(<8 x float> %142, ptr %buffer.contiguous.address42, i32 1, <8 x i1> %55)
  %147 = fmul <8 x float> %buffer.contiguous.load, %buffer.contiguous.load41
  %148 = fmul <8 x float> %buffer.contiguous.load37, %buffer.contiguous.load39
  %149 = fadd <8 x float> %147, %148
  %150 = extractvalue { ptr, i64 } %31, 0
  %151 = extractelement <8 x i64> %125, i32 0
  %152 = sub i64 %151, 0
  %153 = mul i64 %152, 4
  %buffer.contiguous.address43 = getelementptr i8, ptr %150, i64 %153
  call void @llvm.masked.store.v8f32.p0(<8 x float> %149, ptr %buffer.contiguous.address43, i32 1, <8 x i1> %55)
  %.state44 = load i64, ptr %.slot, align 4
  %154 = add i64 %.state44, 1
  store i64 %154, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.4:                                ; preds = %direct.false145, %direct.false31
  ret void

direct.schedule.5:                                ; preds = %direct.false
  %155 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %155, 0
  %158 = select <8 x i1> %55, <8 x ptr> %156, <8 x ptr> %157
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %155, 1
  %161 = select <8 x i1> %55, <8 x i64> %159, <8 x i64> %160
  %162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %158, 0
  %163 = insertvalue { <8 x ptr>, <8 x i64> } %162, <8 x i64> %161, 1
  store { <8 x ptr>, <8 x i64> } %163, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot11, align 4
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state45 = load i64, ptr %.slot11, align 4
  %164 = icmp slt i64 %.state45, 48
  br i1 %164, label %direct.true46, label %direct.false47

direct.schedule.7:                                ; preds = %direct.true46
  %.state48 = load i64, ptr %.slot11, align 4
  %165 = mul i64 %.state48, 8
  %.splatinsert49 = insertelement <8 x i64> poison, i64 %165, i64 0
  %.splat50 = shufflevector <8 x i64> %.splatinsert49, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load51 = load <8 x i64>, ptr %.spill, align 64
  %166 = add <8 x i64> %.splat50, %.spill.load51
  %.spill.load52 = load <8 x i64>, ptr %.spill10, align 64
  %167 = add <8 x i64> %.spill.load52, zeroinitializer
  %168 = add <8 x i64> zeroinitializer, %167
  %169 = add <8 x i64> zeroinitializer, %166
  %170 = mul <8 x i64> %168, splat (i64 768)
  %171 = add <8 x i64> %170, %169
  %172 = extractvalue { ptr, i64 } %13, 0
  %173 = extractelement <8 x i64> %171, i32 0
  %174 = sub i64 %173, 0
  %175 = mul i64 %174, 4
  %buffer.contiguous.address53 = getelementptr i8, ptr %172, i64 %175
  %buffer.contiguous.load54 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address53, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state55 = load i64, ptr %.slot11, align 4
  %.splatinsert56 = insertelement <8 x i64> poison, i64 %.state55, i64 0
  %.splat57 = shufflevector <8 x i64> %.splatinsert56, <8 x i64> poison, <8 x i32> zeroinitializer
  %178 = mul <8 x i64> %.splat57, splat (i64 32)
  %179 = add <8 x i64> %177, %178
  %180 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %176, 0
  %181 = insertvalue { <8 x ptr>, <8 x i64> } %180, <8 x i64> %179, 1
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %181, 1
  %184 = extractelement <8 x ptr> %182, i32 0
  %185 = extractelement <8 x i64> %183, i32 0
  %186 = sub i64 %185, 0
  %187 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %188 = select i1 %187, i64 %186, i64 0
  %private.contiguous.address = getelementptr i8, ptr %184, i64 %188
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %189 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load54, <8 x float> %private.contiguous.preserve
  store <8 x float> %189, ptr %private.contiguous.address, align 4
  %.state58 = load i64, ptr %.slot11, align 4
  %190 = add i64 %.state58, 1
  store i64 %190, ptr %.slot11, align 4
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false47
  %191 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %191, 0
  %194 = select <8 x i1> %55, <8 x ptr> %192, <8 x ptr> %193
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %191, 1
  %197 = select <8 x i1> %55, <8 x i64> %195, <8 x i64> %196
  %198 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %194, 0
  %199 = insertvalue { <8 x ptr>, <8 x i64> } %198, <8 x i64> %197, 1
  store { <8 x ptr>, <8 x i64> } %199, ptr %tile_snapshot.spill12, align 64
  store i64 0, ptr %.slot13, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.10, %direct.schedule.8
  %.state59 = load i64, ptr %.slot13, align 4
  %200 = icmp slt i64 %.state59, 48
  br i1 %200, label %direct.true60, label %direct.false61

direct.schedule.10:                               ; preds = %direct.true60
  %.state62 = load i64, ptr %.slot13, align 4
  %201 = mul i64 %.state62, 8
  %.splatinsert63 = insertelement <8 x i64> poison, i64 %201, i64 0
  %.splat64 = shufflevector <8 x i64> %.splatinsert63, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load65 = load <8 x i64>, ptr %.spill, align 64
  %202 = add <8 x i64> %.splat64, %.spill.load65
  %.spill.load66 = load <8 x i64>, ptr %.spill10, align 64
  %203 = add <8 x i64> %.spill.load66, zeroinitializer
  %204 = add <8 x i64> zeroinitializer, %203
  %205 = add <8 x i64> splat (i64 384), %202
  %206 = mul <8 x i64> %204, splat (i64 768)
  %207 = add <8 x i64> %206, %205
  %208 = extractvalue { ptr, i64 } %13, 0
  %209 = extractelement <8 x i64> %207, i32 0
  %210 = sub i64 %209, 0
  %211 = mul i64 %210, 4
  %buffer.contiguous.address67 = getelementptr i8, ptr %208, i64 %211
  %buffer.contiguous.load68 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address67, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load69 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 0
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 1
  %.state70 = load i64, ptr %.slot13, align 4
  %.splatinsert71 = insertelement <8 x i64> poison, i64 %.state70, i64 0
  %.splat72 = shufflevector <8 x i64> %.splatinsert71, <8 x i64> poison, <8 x i32> zeroinitializer
  %214 = mul <8 x i64> %.splat72, splat (i64 32)
  %215 = add <8 x i64> %213, %214
  %216 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %212, 0
  %217 = insertvalue { <8 x ptr>, <8 x i64> } %216, <8 x i64> %215, 1
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %217, 1
  %220 = extractelement <8 x ptr> %218, i32 0
  %221 = extractelement <8 x i64> %219, i32 0
  %222 = sub i64 %221, 0
  %223 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %224 = select i1 %223, i64 %222, i64 0
  %private.contiguous.address73 = getelementptr i8, ptr %220, i64 %224
  %private.contiguous.preserve74 = load <8 x float>, ptr %private.contiguous.address73, align 4
  %225 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load68, <8 x float> %private.contiguous.preserve74
  store <8 x float> %225, ptr %private.contiguous.address73, align 4
  %.state75 = load i64, ptr %.slot13, align 4
  %226 = add i64 %.state75, 1
  store i64 %226, ptr %.slot13, align 4
  br label %direct.schedule.9

direct.schedule.11:                               ; preds = %direct.false61
  %227 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %227, 0
  %230 = select <8 x i1> %55, <8 x ptr> %228, <8 x ptr> %229
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %227, 1
  %233 = select <8 x i1> %55, <8 x i64> %231, <8 x i64> %232
  %234 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %230, 0
  %235 = insertvalue { <8 x ptr>, <8 x i64> } %234, <8 x i64> %233, 1
  store { <8 x ptr>, <8 x i64> } %235, ptr %tile_snapshot.spill14, align 64
  store i64 0, ptr %.slot15, align 4
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.13, %direct.schedule.11
  %.state76 = load i64, ptr %.slot15, align 4
  %236 = icmp slt i64 %.state76, 48
  br i1 %236, label %direct.true77, label %direct.false78

direct.schedule.13:                               ; preds = %direct.true77
  %.state79 = load i64, ptr %.slot15, align 4
  %237 = mul i64 %.state79, 8
  %.splatinsert80 = insertelement <8 x i64> poison, i64 %237, i64 0
  %.splat81 = shufflevector <8 x i64> %.splatinsert80, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load82 = load <8 x i64>, ptr %.spill, align 64
  %238 = add <8 x i64> %.splat81, %.spill.load82
  %.spill.load83 = load <8 x i64>, ptr %.spill10, align 64
  %239 = add <8 x i64> %.spill.load83, zeroinitializer
  %240 = add <8 x i64> zeroinitializer, %239
  %241 = add <8 x i64> zeroinitializer, %238
  %242 = mul <8 x i64> %240, splat (i64 384)
  %243 = add <8 x i64> %242, %241
  %244 = extractvalue { ptr, i64 } %19, 0
  %245 = extractelement <8 x i64> %243, i32 0
  %246 = sub i64 %245, 0
  %247 = mul i64 %246, 4
  %buffer.contiguous.address84 = getelementptr i8, ptr %244, i64 %247
  %buffer.contiguous.load85 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address84, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load86 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 1
  %.state87 = load i64, ptr %.slot15, align 4
  %.splatinsert88 = insertelement <8 x i64> poison, i64 %.state87, i64 0
  %.splat89 = shufflevector <8 x i64> %.splatinsert88, <8 x i64> poison, <8 x i32> zeroinitializer
  %250 = mul <8 x i64> %.splat89, splat (i64 32)
  %251 = add <8 x i64> %249, %250
  %252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %253 = insertvalue { <8 x ptr>, <8 x i64> } %252, <8 x i64> %251, 1
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %253, 1
  %256 = extractelement <8 x ptr> %254, i32 0
  %257 = extractelement <8 x i64> %255, i32 0
  %258 = sub i64 %257, 0
  %259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %260 = select i1 %259, i64 %258, i64 0
  %private.contiguous.address90 = getelementptr i8, ptr %256, i64 %260
  %private.contiguous.preserve91 = load <8 x float>, ptr %private.contiguous.address90, align 4
  %261 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load85, <8 x float> %private.contiguous.preserve91
  store <8 x float> %261, ptr %private.contiguous.address90, align 4
  %.state92 = load i64, ptr %.slot15, align 4
  %262 = add i64 %.state92, 1
  store i64 %262, ptr %.slot15, align 4
  br label %direct.schedule.12

direct.schedule.14:                               ; preds = %direct.false78
  %263 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %264 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %263, 0
  %266 = select <8 x i1> %55, <8 x ptr> %264, <8 x ptr> %265
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %263, 1
  %269 = select <8 x i1> %55, <8 x i64> %267, <8 x i64> %268
  %270 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %266, 0
  %271 = insertvalue { <8 x ptr>, <8 x i64> } %270, <8 x i64> %269, 1
  store { <8 x ptr>, <8 x i64> } %271, ptr %tile_snapshot.spill16, align 64
  store i64 0, ptr %.slot17, align 4
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.16, %direct.schedule.14
  %.state93 = load i64, ptr %.slot17, align 4
  %272 = icmp slt i64 %.state93, 48
  br i1 %272, label %direct.true94, label %direct.false95

direct.schedule.16:                               ; preds = %direct.true94
  %.state96 = load i64, ptr %.slot17, align 4
  %273 = mul i64 %.state96, 8
  %.splatinsert97 = insertelement <8 x i64> poison, i64 %273, i64 0
  %.splat98 = shufflevector <8 x i64> %.splatinsert97, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load99 = load <8 x i64>, ptr %.spill, align 64
  %274 = add <8 x i64> %.splat98, %.spill.load99
  %.spill.load100 = load <8 x i64>, ptr %.spill10, align 64
  %275 = add <8 x i64> %.spill.load100, zeroinitializer
  %276 = add <8 x i64> zeroinitializer, %275
  %277 = add <8 x i64> zeroinitializer, %274
  %278 = mul <8 x i64> %276, splat (i64 384)
  %279 = add <8 x i64> %278, %277
  %280 = extractvalue { ptr, i64 } %25, 0
  %281 = extractelement <8 x i64> %279, i32 0
  %282 = sub i64 %281, 0
  %283 = mul i64 %282, 4
  %buffer.contiguous.address101 = getelementptr i8, ptr %280, i64 %283
  %buffer.contiguous.load102 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address101, i32 1, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load103 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load103, 0
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load103, 1
  %.state104 = load i64, ptr %.slot17, align 4
  %.splatinsert105 = insertelement <8 x i64> poison, i64 %.state104, i64 0
  %.splat106 = shufflevector <8 x i64> %.splatinsert105, <8 x i64> poison, <8 x i32> zeroinitializer
  %286 = mul <8 x i64> %.splat106, splat (i64 32)
  %287 = add <8 x i64> %285, %286
  %288 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %284, 0
  %289 = insertvalue { <8 x ptr>, <8 x i64> } %288, <8 x i64> %287, 1
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %289, 1
  %292 = extractelement <8 x ptr> %290, i32 0
  %293 = extractelement <8 x i64> %291, i32 0
  %294 = sub i64 %293, 0
  %295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %296 = select i1 %295, i64 %294, i64 0
  %private.contiguous.address107 = getelementptr i8, ptr %292, i64 %296
  %private.contiguous.preserve108 = load <8 x float>, ptr %private.contiguous.address107, align 4
  %297 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load102, <8 x float> %private.contiguous.preserve108
  store <8 x float> %297, ptr %private.contiguous.address107, align 4
  %.state109 = load i64, ptr %.slot17, align 4
  %298 = add i64 %.state109, 1
  store i64 %298, ptr %.slot17, align 4
  br label %direct.schedule.15

direct.schedule.17:                               ; preds = %direct.false95
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.18

direct.schedule.18:                               ; preds = %direct.schedule.19, %direct.schedule.17
  %.state110 = load i64, ptr %.slot18, align 4
  %299 = icmp slt i64 %.state110, 48
  br i1 %299, label %direct.true111, label %direct.false112

direct.schedule.19:                               ; preds = %direct.true111
  %.state113 = load i64, ptr %.slot18, align 4
  %300 = mul i64 %.state113, 8
  %.splatinsert114 = insertelement <8 x i64> poison, i64 %300, i64 0
  %.splat115 = shufflevector <8 x i64> %.splatinsert114, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load116 = load <8 x i64>, ptr %.spill, align 64
  %301 = add <8 x i64> %.splat115, %.spill.load116
  %.spill.load117 = load <8 x i64>, ptr %.spill10, align 64
  %302 = add <8 x i64> %.spill.load117, zeroinitializer
  %303 = add <8 x i64> zeroinitializer, %302
  %304 = add <8 x i64> zeroinitializer, %301
  %305 = mul <8 x i64> %303, splat (i64 768)
  %306 = add <8 x i64> %305, %304
  %tile_snapshot.spill.load118 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %307 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 0
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 1
  %.state119 = load i64, ptr %.slot18, align 4
  %.splatinsert120 = insertelement <8 x i64> poison, i64 %.state119, i64 0
  %.splat121 = shufflevector <8 x i64> %.splatinsert120, <8 x i64> poison, <8 x i32> zeroinitializer
  %309 = mul <8 x i64> %.splat121, splat (i64 32)
  %310 = add <8 x i64> %308, %309
  %311 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %307, 0
  %312 = insertvalue { <8 x ptr>, <8 x i64> } %311, <8 x i64> %310, 1
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %312, 1
  %315 = extractelement <8 x ptr> %313, i32 0
  %316 = extractelement <8 x i64> %314, i32 0
  %317 = sub i64 %316, 0
  %318 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %319 = select i1 %318, i64 %317, i64 0
  %private.contiguous.address122 = getelementptr i8, ptr %315, i64 %319
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address122, align 4
  %320 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load123 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 0
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 1
  %.state124 = load i64, ptr %.slot18, align 4
  %.splatinsert125 = insertelement <8 x i64> poison, i64 %.state124, i64 0
  %.splat126 = shufflevector <8 x i64> %.splatinsert125, <8 x i64> poison, <8 x i32> zeroinitializer
  %323 = mul <8 x i64> %.splat126, splat (i64 32)
  %324 = add <8 x i64> %322, %323
  %325 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %321, 0
  %326 = insertvalue { <8 x ptr>, <8 x i64> } %325, <8 x i64> %324, 1
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %326, 1
  %329 = extractelement <8 x ptr> %327, i32 0
  %330 = extractelement <8 x i64> %328, i32 0
  %331 = sub i64 %330, 0
  %332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %333 = select i1 %332, i64 %331, i64 0
  %private.contiguous.address127 = getelementptr i8, ptr %329, i64 %333
  %private.contiguous.load128 = load <8 x float>, ptr %private.contiguous.address127, align 4
  %334 = select <8 x i1> %55, <8 x float> %private.contiguous.load128, <8 x float> zeroinitializer
  %335 = fmul <8 x float> %320, %334
  %tile_snapshot.spill.load129 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %336 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load129, 0
  %337 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load129, 1
  %.state130 = load i64, ptr %.slot18, align 4
  %.splatinsert131 = insertelement <8 x i64> poison, i64 %.state130, i64 0
  %.splat132 = shufflevector <8 x i64> %.splatinsert131, <8 x i64> poison, <8 x i32> zeroinitializer
  %338 = mul <8 x i64> %.splat132, splat (i64 32)
  %339 = add <8 x i64> %337, %338
  %340 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %336, 0
  %341 = insertvalue { <8 x ptr>, <8 x i64> } %340, <8 x i64> %339, 1
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %341, 1
  %344 = extractelement <8 x ptr> %342, i32 0
  %345 = extractelement <8 x i64> %343, i32 0
  %346 = sub i64 %345, 0
  %347 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %348 = select i1 %347, i64 %346, i64 0
  %private.contiguous.address133 = getelementptr i8, ptr %344, i64 %348
  %private.contiguous.load134 = load <8 x float>, ptr %private.contiguous.address133, align 4
  %349 = select <8 x i1> %55, <8 x float> %private.contiguous.load134, <8 x float> zeroinitializer
  %tile_snapshot.spill.load135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 0
  %351 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 1
  %.state136 = load i64, ptr %.slot18, align 4
  %.splatinsert137 = insertelement <8 x i64> poison, i64 %.state136, i64 0
  %.splat138 = shufflevector <8 x i64> %.splatinsert137, <8 x i64> poison, <8 x i32> zeroinitializer
  %352 = mul <8 x i64> %.splat138, splat (i64 32)
  %353 = add <8 x i64> %351, %352
  %354 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %350, 0
  %355 = insertvalue { <8 x ptr>, <8 x i64> } %354, <8 x i64> %353, 1
  %356 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %355, 1
  %358 = extractelement <8 x ptr> %356, i32 0
  %359 = extractelement <8 x i64> %357, i32 0
  %360 = sub i64 %359, 0
  %361 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %362 = select i1 %361, i64 %360, i64 0
  %private.contiguous.address139 = getelementptr i8, ptr %358, i64 %362
  %private.contiguous.load140 = load <8 x float>, ptr %private.contiguous.address139, align 4
  %363 = select <8 x i1> %55, <8 x float> %private.contiguous.load140, <8 x float> zeroinitializer
  %364 = fmul <8 x float> %349, %363
  %365 = fsub <8 x float> %335, %364
  %366 = extractvalue { ptr, i64 } %31, 0
  %367 = extractelement <8 x i64> %306, i32 0
  %368 = sub i64 %367, 0
  %369 = mul i64 %368, 4
  %buffer.contiguous.address141 = getelementptr i8, ptr %366, i64 %369
  call void @llvm.masked.store.v8f32.p0(<8 x float> %365, ptr %buffer.contiguous.address141, i32 1, <8 x i1> %55)
  %.state142 = load i64, ptr %.slot18, align 4
  %370 = add i64 %.state142, 1
  store i64 %370, ptr %.slot18, align 4
  br label %direct.schedule.18

direct.schedule.20:                               ; preds = %direct.false112
  store i64 0, ptr %.slot19, align 4
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.22, %direct.schedule.20
  %.state143 = load i64, ptr %.slot19, align 4
  %371 = icmp slt i64 %.state143, 48
  br i1 %371, label %direct.true144, label %direct.false145

direct.schedule.22:                               ; preds = %direct.true144
  %.state146 = load i64, ptr %.slot19, align 4
  %372 = mul i64 %.state146, 8
  %.splatinsert147 = insertelement <8 x i64> poison, i64 %372, i64 0
  %.splat148 = shufflevector <8 x i64> %.splatinsert147, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load149 = load <8 x i64>, ptr %.spill, align 64
  %373 = add <8 x i64> %.splat148, %.spill.load149
  %.spill.load150 = load <8 x i64>, ptr %.spill10, align 64
  %374 = add <8 x i64> %.spill.load150, zeroinitializer
  %375 = add <8 x i64> zeroinitializer, %374
  %376 = add <8 x i64> splat (i64 384), %373
  %377 = mul <8 x i64> %375, splat (i64 768)
  %378 = add <8 x i64> %377, %376
  %tile_snapshot.spill.load151 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %379 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load151, 0
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load151, 1
  %.state152 = load i64, ptr %.slot19, align 4
  %.splatinsert153 = insertelement <8 x i64> poison, i64 %.state152, i64 0
  %.splat154 = shufflevector <8 x i64> %.splatinsert153, <8 x i64> poison, <8 x i32> zeroinitializer
  %381 = mul <8 x i64> %.splat154, splat (i64 32)
  %382 = add <8 x i64> %380, %381
  %383 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %379, 0
  %384 = insertvalue { <8 x ptr>, <8 x i64> } %383, <8 x i64> %382, 1
  %385 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %384, 1
  %387 = extractelement <8 x ptr> %385, i32 0
  %388 = extractelement <8 x i64> %386, i32 0
  %389 = sub i64 %388, 0
  %390 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %391 = select i1 %390, i64 %389, i64 0
  %private.contiguous.address155 = getelementptr i8, ptr %387, i64 %391
  %private.contiguous.load156 = load <8 x float>, ptr %private.contiguous.address155, align 4
  %392 = select <8 x i1> %55, <8 x float> %private.contiguous.load156, <8 x float> zeroinitializer
  %tile_snapshot.spill.load157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 0
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 1
  %.state158 = load i64, ptr %.slot19, align 4
  %.splatinsert159 = insertelement <8 x i64> poison, i64 %.state158, i64 0
  %.splat160 = shufflevector <8 x i64> %.splatinsert159, <8 x i64> poison, <8 x i32> zeroinitializer
  %395 = mul <8 x i64> %.splat160, splat (i64 32)
  %396 = add <8 x i64> %394, %395
  %397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %393, 0
  %398 = insertvalue { <8 x ptr>, <8 x i64> } %397, <8 x i64> %396, 1
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %398, 1
  %401 = extractelement <8 x ptr> %399, i32 0
  %402 = extractelement <8 x i64> %400, i32 0
  %403 = sub i64 %402, 0
  %404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %405 = select i1 %404, i64 %403, i64 0
  %private.contiguous.address161 = getelementptr i8, ptr %401, i64 %405
  %private.contiguous.load162 = load <8 x float>, ptr %private.contiguous.address161, align 4
  %406 = select <8 x i1> %55, <8 x float> %private.contiguous.load162, <8 x float> zeroinitializer
  %407 = fmul <8 x float> %392, %406
  %tile_snapshot.spill.load163 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %408 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %.state164 = load i64, ptr %.slot19, align 4
  %.splatinsert165 = insertelement <8 x i64> poison, i64 %.state164, i64 0
  %.splat166 = shufflevector <8 x i64> %.splatinsert165, <8 x i64> poison, <8 x i32> zeroinitializer
  %410 = mul <8 x i64> %.splat166, splat (i64 32)
  %411 = add <8 x i64> %409, %410
  %412 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %408, 0
  %413 = insertvalue { <8 x ptr>, <8 x i64> } %412, <8 x i64> %411, 1
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %413, 1
  %416 = extractelement <8 x ptr> %414, i32 0
  %417 = extractelement <8 x i64> %415, i32 0
  %418 = sub i64 %417, 0
  %419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %420 = select i1 %419, i64 %418, i64 0
  %private.contiguous.address167 = getelementptr i8, ptr %416, i64 %420
  %private.contiguous.load168 = load <8 x float>, ptr %private.contiguous.address167, align 4
  %421 = select <8 x i1> %55, <8 x float> %private.contiguous.load168, <8 x float> zeroinitializer
  %tile_snapshot.spill.load169 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load169, 1
  %.state170 = load i64, ptr %.slot19, align 4
  %.splatinsert171 = insertelement <8 x i64> poison, i64 %.state170, i64 0
  %.splat172 = shufflevector <8 x i64> %.splatinsert171, <8 x i64> poison, <8 x i32> zeroinitializer
  %424 = mul <8 x i64> %.splat172, splat (i64 32)
  %425 = add <8 x i64> %423, %424
  %426 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %422, 0
  %427 = insertvalue { <8 x ptr>, <8 x i64> } %426, <8 x i64> %425, 1
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %429 = extractvalue { <8 x ptr>, <8 x i64> } %427, 1
  %430 = extractelement <8 x ptr> %428, i32 0
  %431 = extractelement <8 x i64> %429, i32 0
  %432 = sub i64 %431, 0
  %433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %434 = select i1 %433, i64 %432, i64 0
  %private.contiguous.address173 = getelementptr i8, ptr %430, i64 %434
  %private.contiguous.load174 = load <8 x float>, ptr %private.contiguous.address173, align 4
  %435 = select <8 x i1> %55, <8 x float> %private.contiguous.load174, <8 x float> zeroinitializer
  %436 = fmul <8 x float> %421, %435
  %437 = fadd <8 x float> %407, %436
  %438 = extractvalue { ptr, i64 } %31, 0
  %439 = extractelement <8 x i64> %378, i32 0
  %440 = sub i64 %439, 0
  %441 = mul i64 %440, 4
  %buffer.contiguous.address175 = getelementptr i8, ptr %438, i64 %441
  call void @llvm.masked.store.v8f32.p0(<8 x float> %437, ptr %buffer.contiguous.address175, i32 1, <8 x i1> %55)
  %.state176 = load i64, ptr %.slot19, align 4
  %442 = add i64 %.state176, 1
  store i64 %442, ptr %.slot19, align 4
  br label %direct.schedule.21

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.0
  br label %direct.schedule.1

direct.false:                                     ; preds = %direct.schedule.0
  br label %direct.schedule.5

direct.true30:                                    ; preds = %direct.schedule.2
  br label %direct.schedule.3

direct.false31:                                   ; preds = %direct.schedule.2
  br label %direct.schedule.4

direct.true46:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false47:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true60:                                    ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false61:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.11

direct.true77:                                    ; preds = %direct.schedule.12
  br label %direct.schedule.13

direct.false78:                                   ; preds = %direct.schedule.12
  br label %direct.schedule.14

direct.true94:                                    ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false95:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.17

direct.true111:                                   ; preds = %direct.schedule.18
  br label %direct.schedule.19

direct.false112:                                  ; preds = %direct.schedule.18
  br label %direct.schedule.20

direct.true144:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false145:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.4
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

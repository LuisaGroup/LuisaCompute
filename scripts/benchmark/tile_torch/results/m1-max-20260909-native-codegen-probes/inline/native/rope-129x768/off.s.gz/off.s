
/private/tmp/luisa-packet-inline.UY1lIE/capture/rope-129x768/off/object/tile_xir_w8_36482_1788935107506127_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	x28, x27, [sp, #-0x60]!
       4:      	stp	x26, x25, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	stp	x29, x30, [sp, #0x50]
      18:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      1c:      	sub	sp, sp, #0x800
      20:      	ldr	x8, [x0]
      24:      	ldr	x22, [x0, #0x10]
      28:      	ldr	x21, [x0, #0x20]
      2c:      	ldr	x20, [x0, #0x30]
      30:      	ldr	w9, [x1]
      34:      	ldr	w10, [x1, #0x24]
      38:      	add	w9, w10, w9, lsl #5
      3c:      	lsr	w9, w9, #3
      40:      	dup.2s	v0, w9
      44:      	ushll.2d	v1, v0, #0x0
      48:      	subs	x9, x8, x20
      4c:      	lsr	x9, x9, #10
      50:      	mov	w10, #0x182             ; =386
      54:      	ccmp	x9, x10, #0x0, hs
      58:      	cset	w9, hi
      5c:      	subs	x11, x20, x8
      60:      	lsr	x11, x11, #10
      64:      	ccmp	x11, x10, #0x0, hs
      68:      	csinc	w11, w9, wzr, ls
      6c:      	subs	x9, x22, x20
      70:      	lsr	x9, x9, #10
      74:      	ccmp	x9, x10, #0x0, hs
      78:      	cset	w9, hi
      7c:      	subs	x12, x20, x22
      80:      	lsr	x12, x12, #9
      84:      	ccmp	x12, x10, #0x0, hs
      88:      	csinc	w9, w9, wzr, ls
      8c:      	subs	x12, x21, x20
      90:      	lsr	x12, x12, #10
      94:      	ccmp	x12, x10, #0x0, hs
      98:      	cset	w12, hi
      9c:      	subs	x13, x20, x21
      a0:      	lsr	x13, x13, #9
      a4:      	ccmp	x13, x10, #0x0, hs
      a8:      	csinc	w10, w12, wzr, ls
      ac:      	cmp	w10, #0x1
      b0:      	ccmp	w11, #0x0, #0x4, eq
      b4:      	b.eq	0x16c <ltmp0+0x16c>
      b8:      	tbz	w9, #0x0, 0x16c <ltmp0+0x16c>
      bc:      	mov	x9, #0x0                ; =0
      c0:      	movi.2s	v0, #0x3, lsl #8
      c4:      	xtn.2s	v2, v1
      c8:      	umull.2d	v0, v2, v0
      cc:      	fmov	x11, d0
      d0:      	fmov	x10, d1
      d4:      	add	x10, x10, x10, lsl #1
      d8:      	lsl	x10, x10, #7
      dc:      	lsl	x11, x11, #2
      e0:      	add	x12, x11, #0x600
      e4:      	add	x11, x8, x12
      e8:      	add	x12, x20, x12
      ec:      	fmov	d1, x9
      f0:      	add.2d	v1, v1, v0
      f4:      	fmov	x13, d1
      f8:      	lsl	x13, x13, #2
      fc:      	add	x14, x8, x13
     100:      	ldp	q1, q2, [x14]
     104:      	ldp	q3, q4, [x11], #0x20
     108:      	add	x14, x9, x10
     10c:      	lsl	x14, x14, #2
     110:      	add	x15, x22, x14
     114:      	ldp	q5, q6, [x15]
     118:      	add	x14, x21, x14
     11c:      	ldp	q7, q16, [x14]
     120:      	fmul.4s	v17, v2, v6
     124:      	fmul.4s	v18, v1, v5
     128:      	fmul.4s	v19, v4, v16
     12c:      	fmul.4s	v20, v3, v7
     130:      	fsub.4s	v18, v18, v20
     134:      	fsub.4s	v17, v17, v19
     138:      	add	x13, x20, x13
     13c:      	stp	q18, q17, [x13]
     140:      	fmul.4s	v2, v2, v16
     144:      	fmul.4s	v1, v1, v7
     148:      	fmul.4s	v4, v4, v6
     14c:      	fmul.4s	v3, v3, v5
     150:      	fadd.4s	v1, v3, v1
     154:      	fadd.4s	v2, v4, v2
     158:      	stp	q1, q2, [x12], #0x20
     15c:      	add	x9, x9, #0x8
     160:      	cmp	x9, #0x180
     164:      	b.ne	0xec <ltmp0+0xec>
     168:      	b	0x298 <ltmp0+0x298>
     16c:      	fmov	x9, d1
     170:      	add	x26, x9, x9, lsl #1
     174:      	lsl	x23, x26, #10
     178:      	add	x19, x8, x23
     17c:      	add	x24, sp, #0x1, lsl #12  ; =0x1000
     180:      	add	x24, x24, #0x200
     184:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     188:      	add	x0, x0, #0x200
     18c:      	mov	x1, x19
     190:      	mov	w2, #0x600              ; =1536
     194:      	bl	0x194 <ltmp0+0x194>
     198:      	add	x25, sp, #0xc00
     19c:      	add	x0, sp, #0xc00
     1a0:      	add	x1, x19, #0x600
     1a4:      	mov	w2, #0x600              ; =1536
     1a8:      	bl	0x1a8 <ltmp0+0x1a8>
     1ac:      	lsl	x26, x26, #9
     1b0:      	add	x19, sp, #0x600
     1b4:      	add	x0, sp, #0x600
     1b8:      	add	x1, x22, x26
     1bc:      	mov	w2, #0x600              ; =1536
     1c0:      	bl	0x1c0 <ltmp0+0x1c0>
     1c4:      	mov	x22, sp
     1c8:      	mov	x0, sp
     1cc:      	add	x1, x21, x26
     1d0:      	mov	w2, #0x600              ; =1536
     1d4:      	bl	0x1d4 <ltmp0+0x1d4>
     1d8:      	mov	x8, #0x0                ; =0
     1dc:      	add	x9, x20, x23
     1e0:      	add	x10, x24, x8
     1e4:      	ldp	q0, q1, [x10]
     1e8:      	add	x10, x19, x8
     1ec:      	ldp	q2, q3, [x10]
     1f0:      	fmul.4s	v1, v1, v3
     1f4:      	fmul.4s	v0, v0, v2
     1f8:      	add	x10, x25, x8
     1fc:      	ldp	q2, q3, [x10]
     200:      	add	x10, x22, x8
     204:      	ldp	q4, q5, [x10]
     208:      	fmul.4s	v3, v3, v5
     20c:      	fmul.4s	v2, v2, v4
     210:      	fsub.4s	v0, v0, v2
     214:      	fsub.4s	v1, v1, v3
     218:      	add	x10, x9, x8
     21c:      	stp	q0, q1, [x10]
     220:      	add	x8, x8, #0x20
     224:      	cmp	x8, #0x600
     228:      	b.ne	0x1e0 <ltmp0+0x1e0>
     22c:      	mov	x8, #0x0                ; =0
     230:      	add	x9, x20, x23
     234:      	add	x9, x9, #0x600
     238:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
     23c:      	add	x10, x10, #0x200
     240:      	mov	x11, sp
     244:      	add	x12, sp, #0xc00
     248:      	add	x13, sp, #0x600
     24c:      	add	x14, x10, x8
     250:      	ldp	q0, q1, [x14]
     254:      	add	x14, x11, x8
     258:      	ldp	q2, q3, [x14]
     25c:      	fmul.4s	v1, v1, v3
     260:      	fmul.4s	v0, v0, v2
     264:      	add	x14, x12, x8
     268:      	ldp	q2, q3, [x14]
     26c:      	add	x14, x13, x8
     270:      	ldp	q4, q5, [x14]
     274:      	fmul.4s	v3, v3, v5
     278:      	fmul.4s	v2, v2, v4
     27c:      	fadd.4s	v0, v0, v2
     280:      	fadd.4s	v1, v1, v3
     284:      	add	x14, x9, x8
     288:      	stp	q0, q1, [x14]
     28c:      	add	x8, x8, #0x20
     290:      	cmp	x8, #0x600
     294:      	b.ne	0x24c <ltmp0+0x24c>
     298:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
     29c:      	add	sp, sp, #0x800
     2a0:      	ldp	x29, x30, [sp, #0x50]
     2a4:      	ldp	x20, x19, [sp, #0x40]
     2a8:      	ldp	x22, x21, [sp, #0x30]
     2ac:      	ldp	x24, x23, [sp, #0x20]
     2b0:      	ldp	x26, x25, [sp, #0x10]
     2b4:      	ldp	x28, x27, [sp], #0x60
     2b8:      	ret

00000000000002bc <_llm_rows.packet_batch.blocks>:
     2bc:      	stp	d9, d8, [sp, #-0x70]!
     2c0:      	stp	x28, x27, [sp, #0x10]
     2c4:      	stp	x26, x25, [sp, #0x20]
     2c8:      	stp	x24, x23, [sp, #0x30]
     2cc:      	stp	x22, x21, [sp, #0x40]
     2d0:      	stp	x20, x19, [sp, #0x50]
     2d4:      	stp	x29, x30, [sp, #0x60]
     2d8:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
     2dc:      	sub	sp, sp, #0x890
     2e0:      	str	x0, [sp, #0x78]
     2e4:      	cbz	w3, 0xec8 <_llm_rows.packet_batch.blocks+0xc0c>
     2e8:      	mov	x21, x3
     2ec:      	mov	x20, x2
     2f0:      	mov	w22, #0x0               ; =0
     2f4:      	ldp	w9, w8, [x2, #0x2c]
     2f8:      	stp	w8, w9, [sp, #0x70]
     2fc:      	ldp	w27, w28, [x2]
     300:      	adrp	x8, 0x0 <ltmp0>
     304:      	ldr	q0, [x8]
     308:      	str	q0, [sp, #0x30]
     30c:      	adrp	x8, 0x0 <ltmp0>
     310:      	ldr	q0, [x8]
     314:      	str	q0, [sp, #0x20]
     318:      	adrp	x8, 0x0 <ltmp0>
     31c:      	ldr	q0, [x8]
     320:      	str	q0, [sp, #0x10]
     324:      	movi.2s	v8, #0x3, lsl #8
     328:      	adrp	x8, 0x0 <ltmp0>
     32c:      	ldr	q21, [x8]
     330:      	add	x4, sp, #0x1, lsl #12   ; =0x1000
     334:      	add	x4, x4, #0x290
     338:      	add	x25, sp, #0xc90
     33c:      	add	x23, sp, #0x690
     340:      	add	x24, sp, #0x90
     344:      	ldp	w19, w8, [x2, #0x8]
     348:      	str	x8, [sp, #0x68]
     34c:      	str	q21, [sp, #0x50]
     350:      	str	w3, [sp, #0x4c]
     354:      	b	0x39c <_llm_rows.packet_batch.blocks+0xe0>
     358:      	mov	w8, #0x18               ; =24
     35c:      	str	w8, [x20, #0x24]
     360:      	ldr	w21, [sp, #0x4c]
     364:      	add	w8, w27, #0x1
     368:      	ldp	w10, w9, [sp, #0x70]
     36c:      	cmp	w8, w9
     370:      	cset	w8, eq
     374:      	csinc	w27, wzr, w27, eq
     378:      	cinc	w9, w28, eq
     37c:      	cmp	w9, w10
     380:      	cset	w10, eq
     384:      	ands	w8, w8, w10
     388:      	csel	w28, wzr, w9, ne
     38c:      	add	w19, w19, w8
     390:      	add	w22, w22, #0x1
     394:      	cmp	w22, w21
     398:      	b.eq	0xec8 <_llm_rows.packet_batch.blocks+0xc0c>
     39c:      	ubfiz	x8, x27, #5, #32
     3a0:      	ldr	x12, [sp, #0x68]
     3a4:      	cmp	x8, x12
     3a8:      	csel	x9, x8, xzr, ls
     3ac:      	subs	x10, x12, x9
     3b0:      	cmp	x10, #0x20
     3b4:      	mov	w11, #0x20              ; =32
     3b8:      	csel	x10, x10, x11, lo
     3bc:      	cmp	x12, x9
     3c0:      	stp	w27, w28, [x20]
     3c4:      	str	w19, [x20, #0x8]
     3c8:      	str	wzr, [x20, #0x24]
     3cc:      	ccmp	x8, x12, #0x2, hi
     3d0:      	csel	x26, x10, xzr, ls
     3d4:      	cmp	x26, #0x20
     3d8:      	b.lo	0x438 <_llm_rows.packet_batch.blocks+0x17c>
     3dc:      	ldr	x26, [sp, #0x78]
     3e0:      	mov	x0, x26
     3e4:      	mov	x1, x20
     3e8:      	bl	0x3e8 <_llm_rows.packet_batch.blocks+0x12c>
     3ec:      	mov	w8, #0x8                ; =8
     3f0:      	str	w8, [x20, #0x24]
     3f4:      	mov	x0, x26
     3f8:      	mov	x1, x20
     3fc:      	bl	0x3fc <_llm_rows.packet_batch.blocks+0x140>
     400:      	mov	w8, #0x10               ; =16
     404:      	str	w8, [x20, #0x24]
     408:      	mov	x0, x26
     40c:      	mov	x1, x20
     410:      	bl	0x410 <_llm_rows.packet_batch.blocks+0x154>
     414:      	mov	w8, #0x18               ; =24
     418:      	str	w8, [x20, #0x24]
     41c:      	mov	x0, x26
     420:      	mov	x1, x20
     424:      	bl	0x424 <_llm_rows.packet_batch.blocks+0x168>
     428:      	add	x4, sp, #0x1, lsl #12   ; =0x1000
     42c:      	add	x4, x4, #0x290
     430:      	ldr	q21, [sp, #0x50]
     434:      	b	0x364 <_llm_rows.packet_batch.blocks+0xa8>
     438:      	lsr	x21, x26, #3
     43c:      	cmp	x26, #0x8
     440:      	b.lo	0x4b0 <_llm_rows.packet_batch.blocks+0x1f4>
     444:      	str	wzr, [x20, #0x24]
     448:      	ldr	x0, [sp, #0x78]
     44c:      	mov	x1, x20
     450:      	bl	0x450 <_llm_rows.packet_batch.blocks+0x194>
     454:      	add	x4, sp, #0x1, lsl #12   ; =0x1000
     458:      	add	x4, x4, #0x290
     45c:      	ldr	q21, [sp, #0x50]
     460:      	cmp	x21, #0x1
     464:      	b.eq	0x4b0 <_llm_rows.packet_batch.blocks+0x1f4>
     468:      	mov	w8, #0x8                ; =8
     46c:      	str	w8, [x20, #0x24]
     470:      	ldr	x0, [sp, #0x78]
     474:      	mov	x1, x20
     478:      	bl	0x478 <_llm_rows.packet_batch.blocks+0x1bc>
     47c:      	add	x4, sp, #0x1, lsl #12   ; =0x1000
     480:      	add	x4, x4, #0x290
     484:      	ldr	q21, [sp, #0x50]
     488:      	cmp	x21, #0x2
     48c:      	b.eq	0x4b0 <_llm_rows.packet_batch.blocks+0x1f4>
     490:      	mov	w8, #0x10               ; =16
     494:      	str	w8, [x20, #0x24]
     498:      	ldr	x0, [sp, #0x78]
     49c:      	mov	x1, x20
     4a0:      	bl	0x4a0 <_llm_rows.packet_batch.blocks+0x1e4>
     4a4:      	add	x4, sp, #0x1, lsl #12   ; =0x1000
     4a8:      	add	x4, x4, #0x290
     4ac:      	ldr	q21, [sp, #0x50]
     4b0:      	and	w8, w26, #0x7
     4b4:      	cbz	w8, 0x358 <_llm_rows.packet_batch.blocks+0x9c>
     4b8:      	dup.4s	v0, w8
     4bc:      	ldp	q1, q2, [sp, #0x20]
     4c0:      	cmhi.4s	v1, v0, v1
     4c4:      	cmhi.4s	v0, v0, v2
     4c8:      	uzp1.8h	v3, v0, v1
     4cc:      	umaxv.8h	h2, v3
     4d0:      	fmov	w8, s2
     4d4:      	tbz	w8, #0x0, 0x358 <_llm_rows.packet_batch.blocks+0x9c>
     4d8:      	ldr	x8, [sp, #0x78]
     4dc:      	ldr	x11, [x8]
     4e0:      	ldr	x10, [x8, #0x10]
     4e4:      	ldr	x9, [x8, #0x20]
     4e8:      	ldr	x8, [x8, #0x30]
     4ec:      	ubfiz	w12, w27, #2, #27
     4f0:      	orr	w12, w12, w21
     4f4:      	dup.4s	v2, w12
     4f8:      	and.16b	v2, v0, v2
     4fc:      	ushll.2d	v2, v2, #0x0
     500:      	subs	x12, x11, x8
     504:      	mov	w15, #0xbff             ; =3071
     508:      	movk	w15, #0x6, lsl #16
     50c:      	ccmp	x12, x15, #0x0, hs
     510:      	cset	w12, hi
     514:      	subs	x13, x8, x11
     518:      	ccmp	x13, x15, #0x0, hs
     51c:      	csinc	w12, w12, wzr, ls
     520:      	subs	x13, x10, x8
     524:      	ccmp	x13, x15, #0x0, hs
     528:      	cset	w13, hi
     52c:      	subs	x14, x8, x10
     530:      	mov	w16, #0x5ff             ; =1535
     534:      	movk	w16, #0x3, lsl #16
     538:      	ccmp	x14, x16, #0x0, hs
     53c:      	csinc	w13, w13, wzr, ls
     540:      	subs	x14, x9, x8
     544:      	ccmp	x14, x15, #0x0, hs
     548:      	cset	w14, hi
     54c:      	subs	x15, x8, x9
     550:      	ccmp	x15, x16, #0x0, hs
     554:      	csinc	w14, w14, wzr, ls
     558:      	cmp	w14, #0x1
     55c:      	b.ne	0x9b8 <_llm_rows.packet_batch.blocks+0x6fc>
     560:      	cbz	w12, 0x9b8 <_llm_rows.packet_batch.blocks+0x6fc>
     564:      	tbz	w13, #0x0, 0x9b8 <_llm_rows.packet_batch.blocks+0x6fc>
     568:      	mov	x12, #0x0               ; =0
     56c:      	sshll.2d	v0, v0, #0x0
     570:      	ldr	q1, [sp, #0x10]
     574:      	and.16b	v0, v0, v1
     578:      	xtn.2s	v1, v2
     57c:      	umull.2d	v1, v1, v8
     580:      	fmov	x13, d1
     584:      	add	x13, x13, #0x180
     588:      	fmov	x14, d2
     58c:      	add	x14, x14, x14, lsl #1
     590:      	lsl	x14, x14, #7
     594:      	and.16b	v2, v3, v21
     598:      	addv.8h	h2, v2
     59c:      	fmov	w15, s2
     5a0:      	b	0x5b0 <_llm_rows.packet_batch.blocks+0x2f4>
     5a4:      	add	x12, x12, #0x8
     5a8:      	cmp	x12, #0x180
     5ac:      	b.eq	0x358 <_llm_rows.packet_batch.blocks+0x9c>
     5b0:      	dup.2d	v3, x12
     5b4:      	orr.16b	v5, v3, v0
     5b8:      	add.2d	v3, v5, v1
     5bc:      	fmov	x16, d3
     5c0:      	lsl	x16, x16, #2
     5c4:      	add	x17, x11, x16
     5c8:      	movi.2d	v4, #0000000000000000
     5cc:      	movi.2d	v3, #0000000000000000
     5d0:      	tbnz	w15, #0x0, 0x740 <_llm_rows.packet_batch.blocks+0x484>
     5d4:      	and	w0, w15, #0xff
     5d8:      	tbnz	w0, #0x1, 0x74c <_llm_rows.packet_batch.blocks+0x490>
     5dc:      	tbnz	w0, #0x2, 0x758 <_llm_rows.packet_batch.blocks+0x49c>
     5e0:      	tbnz	w0, #0x3, 0x764 <_llm_rows.packet_batch.blocks+0x4a8>
     5e4:      	tbnz	w0, #0x4, 0x770 <_llm_rows.packet_batch.blocks+0x4b4>
     5e8:      	tbnz	w0, #0x5, 0x77c <_llm_rows.packet_batch.blocks+0x4c0>
     5ec:      	tbnz	w0, #0x6, 0x788 <_llm_rows.packet_batch.blocks+0x4cc>
     5f0:      	tbz	w0, #0x7, 0x5fc <_llm_rows.packet_batch.blocks+0x340>
     5f4:      	add	x17, x17, #0x1c
     5f8:      	ld1.s	{ v3 }[3], [x17]
     5fc:      	fmov	w2, s2
     600:      	fmov	x0, d5
     604:      	add	x17, x13, x0
     608:      	lsl	x17, x17, #2
     60c:      	add	x1, x11, x17
     610:      	movi.2d	v6, #0000000000000000
     614:      	movi.2d	v5, #0000000000000000
     618:      	tbnz	w2, #0x0, 0x798 <_llm_rows.packet_batch.blocks+0x4dc>
     61c:      	and	w2, w2, #0xff
     620:      	tbnz	w2, #0x1, 0x7a4 <_llm_rows.packet_batch.blocks+0x4e8>
     624:      	tbnz	w2, #0x2, 0x7b0 <_llm_rows.packet_batch.blocks+0x4f4>
     628:      	tbnz	w2, #0x3, 0x7bc <_llm_rows.packet_batch.blocks+0x500>
     62c:      	tbnz	w2, #0x4, 0x7c8 <_llm_rows.packet_batch.blocks+0x50c>
     630:      	tbnz	w2, #0x5, 0x7d4 <_llm_rows.packet_batch.blocks+0x518>
     634:      	tbnz	w2, #0x6, 0x7e0 <_llm_rows.packet_batch.blocks+0x524>
     638:      	tbz	w2, #0x7, 0x644 <_llm_rows.packet_batch.blocks+0x388>
     63c:      	add	x1, x1, #0x1c
     640:      	ld1.s	{ v5 }[3], [x1]
     644:      	fmov	w2, s2
     648:      	add	x0, x0, x14
     64c:      	lsl	x0, x0, #2
     650:      	add	x1, x10, x0
     654:      	movi.2d	v16, #0000000000000000
     658:      	movi.2d	v7, #0000000000000000
     65c:      	tbnz	w2, #0x0, 0x7f0 <_llm_rows.packet_batch.blocks+0x534>
     660:      	and	w2, w2, #0xff
     664:      	tbnz	w2, #0x1, 0x7fc <_llm_rows.packet_batch.blocks+0x540>
     668:      	tbnz	w2, #0x2, 0x808 <_llm_rows.packet_batch.blocks+0x54c>
     66c:      	tbnz	w2, #0x3, 0x814 <_llm_rows.packet_batch.blocks+0x558>
     670:      	tbnz	w2, #0x4, 0x820 <_llm_rows.packet_batch.blocks+0x564>
     674:      	tbnz	w2, #0x5, 0x82c <_llm_rows.packet_batch.blocks+0x570>
     678:      	tbnz	w2, #0x6, 0x838 <_llm_rows.packet_batch.blocks+0x57c>
     67c:      	tbnz	w2, #0x7, 0x844 <_llm_rows.packet_batch.blocks+0x588>
     680:      	fmov	w1, s2
     684:      	add	x0, x9, x0
     688:      	movi.2d	v18, #0000000000000000
     68c:      	movi.2d	v17, #0000000000000000
     690:      	tbnz	w1, #0x0, 0x860 <_llm_rows.packet_batch.blocks+0x5a4>
     694:      	and	w1, w1, #0xff
     698:      	tbnz	w1, #0x1, 0x86c <_llm_rows.packet_batch.blocks+0x5b0>
     69c:      	tbnz	w1, #0x2, 0x878 <_llm_rows.packet_batch.blocks+0x5bc>
     6a0:      	tbnz	w1, #0x3, 0x884 <_llm_rows.packet_batch.blocks+0x5c8>
     6a4:      	tbnz	w1, #0x4, 0x890 <_llm_rows.packet_batch.blocks+0x5d4>
     6a8:      	tbnz	w1, #0x5, 0x89c <_llm_rows.packet_batch.blocks+0x5e0>
     6ac:      	tbnz	w1, #0x6, 0x8a8 <_llm_rows.packet_batch.blocks+0x5ec>
     6b0:      	tbnz	w1, #0x7, 0x8b4 <_llm_rows.packet_batch.blocks+0x5f8>
     6b4:      	fmov	w0, s2
     6b8:      	fmul.4s	v19, v4, v16
     6bc:      	fmul.4s	v20, v6, v18
     6c0:      	fsub.4s	v19, v19, v20
     6c4:      	add	x16, x8, x16
     6c8:      	tbnz	w0, #0x0, 0x8d4 <_llm_rows.packet_batch.blocks+0x618>
     6cc:      	and	w0, w0, #0xff
     6d0:      	tbnz	w0, #0x1, 0x8e0 <_llm_rows.packet_batch.blocks+0x624>
     6d4:      	tbnz	w0, #0x2, 0x8ec <_llm_rows.packet_batch.blocks+0x630>
     6d8:      	tbnz	w0, #0x3, 0x8f8 <_llm_rows.packet_batch.blocks+0x63c>
     6dc:      	fmul.4s	v19, v3, v7
     6e0:      	fmul.4s	v20, v5, v17
     6e4:      	fsub.4s	v19, v19, v20
     6e8:      	tbnz	w0, #0x4, 0x910 <_llm_rows.packet_batch.blocks+0x654>
     6ec:      	tbnz	w0, #0x5, 0x918 <_llm_rows.packet_batch.blocks+0x65c>
     6f0:      	tbnz	w0, #0x6, 0x924 <_llm_rows.packet_batch.blocks+0x668>
     6f4:      	tbnz	w0, #0x7, 0x930 <_llm_rows.packet_batch.blocks+0x674>
     6f8:      	fmov	w0, s2
     6fc:      	fmul.4s	v4, v4, v18
     700:      	fmul.4s	v6, v6, v16
     704:      	fadd.4s	v4, v6, v4
     708:      	add	x16, x8, x17
     70c:      	tbnz	w0, #0x0, 0x950 <_llm_rows.packet_batch.blocks+0x694>
     710:      	and	w17, w0, #0xff
     714:      	tbnz	w17, #0x1, 0x95c <_llm_rows.packet_batch.blocks+0x6a0>
     718:      	tbnz	w17, #0x2, 0x968 <_llm_rows.packet_batch.blocks+0x6ac>
     71c:      	tbnz	w17, #0x3, 0x974 <_llm_rows.packet_batch.blocks+0x6b8>
     720:      	fmul.4s	v3, v3, v17
     724:      	fmul.4s	v4, v5, v7
     728:      	fadd.4s	v3, v4, v3
     72c:      	tbnz	w17, #0x4, 0x98c <_llm_rows.packet_batch.blocks+0x6d0>
     730:      	tbnz	w17, #0x5, 0x994 <_llm_rows.packet_batch.blocks+0x6d8>
     734:      	tbnz	w17, #0x6, 0x9a0 <_llm_rows.packet_batch.blocks+0x6e4>
     738:      	tbz	w17, #0x7, 0x5a4 <_llm_rows.packet_batch.blocks+0x2e8>
     73c:      	b	0x9ac <_llm_rows.packet_batch.blocks+0x6f0>
     740:      	ldr	s4, [x17]
     744:      	and	w0, w15, #0xff
     748:      	tbz	w0, #0x1, 0x5dc <_llm_rows.packet_batch.blocks+0x320>
     74c:      	add	x1, x17, #0x4
     750:      	ld1.s	{ v4 }[1], [x1]
     754:      	tbz	w0, #0x2, 0x5e0 <_llm_rows.packet_batch.blocks+0x324>
     758:      	add	x1, x17, #0x8
     75c:      	ld1.s	{ v4 }[2], [x1]
     760:      	tbz	w0, #0x3, 0x5e4 <_llm_rows.packet_batch.blocks+0x328>
     764:      	add	x1, x17, #0xc
     768:      	ld1.s	{ v4 }[3], [x1]
     76c:      	tbz	w0, #0x4, 0x5e8 <_llm_rows.packet_batch.blocks+0x32c>
     770:      	add	x1, x17, #0x10
     774:      	ld1.s	{ v3 }[0], [x1]
     778:      	tbz	w0, #0x5, 0x5ec <_llm_rows.packet_batch.blocks+0x330>
     77c:      	add	x1, x17, #0x14
     780:      	ld1.s	{ v3 }[1], [x1]
     784:      	tbz	w0, #0x6, 0x5f0 <_llm_rows.packet_batch.blocks+0x334>
     788:      	add	x1, x17, #0x18
     78c:      	ld1.s	{ v3 }[2], [x1]
     790:      	tbnz	w0, #0x7, 0x5f4 <_llm_rows.packet_batch.blocks+0x338>
     794:      	b	0x5fc <_llm_rows.packet_batch.blocks+0x340>
     798:      	ldr	s6, [x1]
     79c:      	and	w2, w2, #0xff
     7a0:      	tbz	w2, #0x1, 0x624 <_llm_rows.packet_batch.blocks+0x368>
     7a4:      	add	x3, x1, #0x4
     7a8:      	ld1.s	{ v6 }[1], [x3]
     7ac:      	tbz	w2, #0x2, 0x628 <_llm_rows.packet_batch.blocks+0x36c>
     7b0:      	add	x3, x1, #0x8
     7b4:      	ld1.s	{ v6 }[2], [x3]
     7b8:      	tbz	w2, #0x3, 0x62c <_llm_rows.packet_batch.blocks+0x370>
     7bc:      	add	x3, x1, #0xc
     7c0:      	ld1.s	{ v6 }[3], [x3]
     7c4:      	tbz	w2, #0x4, 0x630 <_llm_rows.packet_batch.blocks+0x374>
     7c8:      	add	x3, x1, #0x10
     7cc:      	ld1.s	{ v5 }[0], [x3]
     7d0:      	tbz	w2, #0x5, 0x634 <_llm_rows.packet_batch.blocks+0x378>
     7d4:      	add	x3, x1, #0x14
     7d8:      	ld1.s	{ v5 }[1], [x3]
     7dc:      	tbz	w2, #0x6, 0x638 <_llm_rows.packet_batch.blocks+0x37c>
     7e0:      	add	x3, x1, #0x18
     7e4:      	ld1.s	{ v5 }[2], [x3]
     7e8:      	tbnz	w2, #0x7, 0x63c <_llm_rows.packet_batch.blocks+0x380>
     7ec:      	b	0x644 <_llm_rows.packet_batch.blocks+0x388>
     7f0:      	ldr	s16, [x1]
     7f4:      	and	w2, w2, #0xff
     7f8:      	tbz	w2, #0x1, 0x668 <_llm_rows.packet_batch.blocks+0x3ac>
     7fc:      	add	x3, x1, #0x4
     800:      	ld1.s	{ v16 }[1], [x3]
     804:      	tbz	w2, #0x2, 0x66c <_llm_rows.packet_batch.blocks+0x3b0>
     808:      	add	x3, x1, #0x8
     80c:      	ld1.s	{ v16 }[2], [x3]
     810:      	tbz	w2, #0x3, 0x670 <_llm_rows.packet_batch.blocks+0x3b4>
     814:      	add	x3, x1, #0xc
     818:      	ld1.s	{ v16 }[3], [x3]
     81c:      	tbz	w2, #0x4, 0x674 <_llm_rows.packet_batch.blocks+0x3b8>
     820:      	add	x3, x1, #0x10
     824:      	ld1.s	{ v7 }[0], [x3]
     828:      	tbz	w2, #0x5, 0x678 <_llm_rows.packet_batch.blocks+0x3bc>
     82c:      	add	x3, x1, #0x14
     830:      	ld1.s	{ v7 }[1], [x3]
     834:      	tbz	w2, #0x6, 0x67c <_llm_rows.packet_batch.blocks+0x3c0>
     838:      	add	x3, x1, #0x18
     83c:      	ld1.s	{ v7 }[2], [x3]
     840:      	tbz	w2, #0x7, 0x680 <_llm_rows.packet_batch.blocks+0x3c4>
     844:      	add	x1, x1, #0x1c
     848:      	ld1.s	{ v7 }[3], [x1]
     84c:      	fmov	w1, s2
     850:      	add	x0, x9, x0
     854:      	movi.2d	v18, #0000000000000000
     858:      	movi.2d	v17, #0000000000000000
     85c:      	tbz	w1, #0x0, 0x694 <_llm_rows.packet_batch.blocks+0x3d8>
     860:      	ldr	s18, [x0]
     864:      	and	w1, w1, #0xff
     868:      	tbz	w1, #0x1, 0x69c <_llm_rows.packet_batch.blocks+0x3e0>
     86c:      	add	x2, x0, #0x4
     870:      	ld1.s	{ v18 }[1], [x2]
     874:      	tbz	w1, #0x2, 0x6a0 <_llm_rows.packet_batch.blocks+0x3e4>
     878:      	add	x2, x0, #0x8
     87c:      	ld1.s	{ v18 }[2], [x2]
     880:      	tbz	w1, #0x3, 0x6a4 <_llm_rows.packet_batch.blocks+0x3e8>
     884:      	add	x2, x0, #0xc
     888:      	ld1.s	{ v18 }[3], [x2]
     88c:      	tbz	w1, #0x4, 0x6a8 <_llm_rows.packet_batch.blocks+0x3ec>
     890:      	add	x2, x0, #0x10
     894:      	ld1.s	{ v17 }[0], [x2]
     898:      	tbz	w1, #0x5, 0x6ac <_llm_rows.packet_batch.blocks+0x3f0>
     89c:      	add	x2, x0, #0x14
     8a0:      	ld1.s	{ v17 }[1], [x2]
     8a4:      	tbz	w1, #0x6, 0x6b0 <_llm_rows.packet_batch.blocks+0x3f4>
     8a8:      	add	x2, x0, #0x18
     8ac:      	ld1.s	{ v17 }[2], [x2]
     8b0:      	tbz	w1, #0x7, 0x6b4 <_llm_rows.packet_batch.blocks+0x3f8>
     8b4:      	add	x0, x0, #0x1c
     8b8:      	ld1.s	{ v17 }[3], [x0]
     8bc:      	fmov	w0, s2
     8c0:      	fmul.4s	v19, v4, v16
     8c4:      	fmul.4s	v20, v6, v18
     8c8:      	fsub.4s	v19, v19, v20
     8cc:      	add	x16, x8, x16
     8d0:      	tbz	w0, #0x0, 0x6cc <_llm_rows.packet_batch.blocks+0x410>
     8d4:      	str	s19, [x16]
     8d8:      	and	w0, w0, #0xff
     8dc:      	tbz	w0, #0x1, 0x6d4 <_llm_rows.packet_batch.blocks+0x418>
     8e0:      	add	x1, x16, #0x4
     8e4:      	st1.s	{ v19 }[1], [x1]
     8e8:      	tbz	w0, #0x2, 0x6d8 <_llm_rows.packet_batch.blocks+0x41c>
     8ec:      	add	x1, x16, #0x8
     8f0:      	st1.s	{ v19 }[2], [x1]
     8f4:      	tbz	w0, #0x3, 0x6dc <_llm_rows.packet_batch.blocks+0x420>
     8f8:      	add	x1, x16, #0xc
     8fc:      	st1.s	{ v19 }[3], [x1]
     900:      	fmul.4s	v19, v3, v7
     904:      	fmul.4s	v20, v5, v17
     908:      	fsub.4s	v19, v19, v20
     90c:      	tbz	w0, #0x4, 0x6ec <_llm_rows.packet_batch.blocks+0x430>
     910:      	str	s19, [x16, #0x10]
     914:      	tbz	w0, #0x5, 0x6f0 <_llm_rows.packet_batch.blocks+0x434>
     918:      	add	x1, x16, #0x14
     91c:      	st1.s	{ v19 }[1], [x1]
     920:      	tbz	w0, #0x6, 0x6f4 <_llm_rows.packet_batch.blocks+0x438>
     924:      	add	x1, x16, #0x18
     928:      	st1.s	{ v19 }[2], [x1]
     92c:      	tbz	w0, #0x7, 0x6f8 <_llm_rows.packet_batch.blocks+0x43c>
     930:      	add	x16, x16, #0x1c
     934:      	st1.s	{ v19 }[3], [x16]
     938:      	fmov	w0, s2
     93c:      	fmul.4s	v4, v4, v18
     940:      	fmul.4s	v6, v6, v16
     944:      	fadd.4s	v4, v6, v4
     948:      	add	x16, x8, x17
     94c:      	tbz	w0, #0x0, 0x710 <_llm_rows.packet_batch.blocks+0x454>
     950:      	str	s4, [x16]
     954:      	and	w17, w0, #0xff
     958:      	tbz	w17, #0x1, 0x718 <_llm_rows.packet_batch.blocks+0x45c>
     95c:      	add	x0, x16, #0x4
     960:      	st1.s	{ v4 }[1], [x0]
     964:      	tbz	w17, #0x2, 0x71c <_llm_rows.packet_batch.blocks+0x460>
     968:      	add	x0, x16, #0x8
     96c:      	st1.s	{ v4 }[2], [x0]
     970:      	tbz	w17, #0x3, 0x720 <_llm_rows.packet_batch.blocks+0x464>
     974:      	add	x0, x16, #0xc
     978:      	st1.s	{ v4 }[3], [x0]
     97c:      	fmul.4s	v3, v3, v17
     980:      	fmul.4s	v4, v5, v7
     984:      	fadd.4s	v3, v4, v3
     988:      	tbz	w17, #0x4, 0x730 <_llm_rows.packet_batch.blocks+0x474>
     98c:      	str	s3, [x16, #0x10]
     990:      	tbz	w17, #0x5, 0x734 <_llm_rows.packet_batch.blocks+0x478>
     994:      	add	x0, x16, #0x14
     998:      	st1.s	{ v3 }[1], [x0]
     99c:      	tbz	w17, #0x6, 0x738 <_llm_rows.packet_batch.blocks+0x47c>
     9a0:      	add	x0, x16, #0x18
     9a4:      	st1.s	{ v3 }[2], [x0]
     9a8:      	tbz	w17, #0x7, 0x5a4 <_llm_rows.packet_batch.blocks+0x2e8>
     9ac:      	add	x16, x16, #0x1c
     9b0:      	st1.s	{ v3 }[3], [x16]
     9b4:      	b	0x5a4 <_llm_rows.packet_batch.blocks+0x2e8>
     9b8:      	mov	x14, #0x0               ; =0
     9bc:      	fmov	x12, d2
     9c0:      	add	x13, x12, x12, lsl #1
     9c4:      	lsl	x12, x13, #10
     9c8:      	add	x11, x11, x12
     9cc:      	b	0x9f0 <_llm_rows.packet_batch.blocks+0x734>
     9d0:      	add	x15, x4, x14
     9d4:      	ldp	q6, q7, [x15]
     9d8:      	bif.16b	v5, v7, v1
     9dc:      	bif.16b	v4, v6, v0
     9e0:      	stp	q4, q5, [x15]
     9e4:      	add	x14, x14, #0x20
     9e8:      	cmp	x14, #0x600
     9ec:      	b.eq	0xa90 <_llm_rows.packet_batch.blocks+0x7d4>
     9f0:      	and.16b	v2, v3, v21
     9f4:      	addv.8h	h2, v2
     9f8:      	fmov	w16, s2
     9fc:      	add	x15, x11, x14
     a00:      	movi.2d	v4, #0000000000000000
     a04:      	movi.2d	v5, #0000000000000000
     a08:      	tbnz	w16, #0x0, 0xa30 <_llm_rows.packet_batch.blocks+0x774>
     a0c:      	and	w16, w16, #0xff
     a10:      	tbnz	w16, #0x1, 0xa3c <_llm_rows.packet_batch.blocks+0x780>
     a14:      	tbnz	w16, #0x2, 0xa48 <_llm_rows.packet_batch.blocks+0x78c>
     a18:      	tbnz	w16, #0x3, 0xa54 <_llm_rows.packet_batch.blocks+0x798>
     a1c:      	tbnz	w16, #0x4, 0xa60 <_llm_rows.packet_batch.blocks+0x7a4>
     a20:      	tbnz	w16, #0x5, 0xa6c <_llm_rows.packet_batch.blocks+0x7b0>
     a24:      	tbnz	w16, #0x6, 0xa78 <_llm_rows.packet_batch.blocks+0x7bc>
     a28:      	tbz	w16, #0x7, 0x9d0 <_llm_rows.packet_batch.blocks+0x714>
     a2c:      	b	0xa84 <_llm_rows.packet_batch.blocks+0x7c8>
     a30:      	ldr	s4, [x15]
     a34:      	and	w16, w16, #0xff
     a38:      	tbz	w16, #0x1, 0xa14 <_llm_rows.packet_batch.blocks+0x758>
     a3c:      	add	x17, x15, #0x4
     a40:      	ld1.s	{ v4 }[1], [x17]
     a44:      	tbz	w16, #0x2, 0xa18 <_llm_rows.packet_batch.blocks+0x75c>
     a48:      	add	x17, x15, #0x8
     a4c:      	ld1.s	{ v4 }[2], [x17]
     a50:      	tbz	w16, #0x3, 0xa1c <_llm_rows.packet_batch.blocks+0x760>
     a54:      	add	x17, x15, #0xc
     a58:      	ld1.s	{ v4 }[3], [x17]
     a5c:      	tbz	w16, #0x4, 0xa20 <_llm_rows.packet_batch.blocks+0x764>
     a60:      	add	x17, x15, #0x10
     a64:      	ld1.s	{ v5 }[0], [x17]
     a68:      	tbz	w16, #0x5, 0xa24 <_llm_rows.packet_batch.blocks+0x768>
     a6c:      	add	x17, x15, #0x14
     a70:      	ld1.s	{ v5 }[1], [x17]
     a74:      	tbz	w16, #0x6, 0xa28 <_llm_rows.packet_batch.blocks+0x76c>
     a78:      	add	x17, x15, #0x18
     a7c:      	ld1.s	{ v5 }[2], [x17]
     a80:      	tbz	w16, #0x7, 0x9d0 <_llm_rows.packet_batch.blocks+0x714>
     a84:      	add	x15, x15, #0x1c
     a88:      	ld1.s	{ v5 }[3], [x15]
     a8c:      	b	0x9d0 <_llm_rows.packet_batch.blocks+0x714>
     a90:      	mov	x14, #0x0               ; =0
     a94:      	add	x11, x11, #0x600
     a98:      	b	0xabc <_llm_rows.packet_batch.blocks+0x800>
     a9c:      	add	x15, x25, x14
     aa0:      	ldp	q5, q6, [x15]
     aa4:      	bif.16b	v4, v6, v1
     aa8:      	bif.16b	v3, v5, v0
     aac:      	stp	q3, q4, [x15]
     ab0:      	add	x14, x14, #0x20
     ab4:      	cmp	x14, #0x600
     ab8:      	b.eq	0xb54 <_llm_rows.packet_batch.blocks+0x898>
     abc:      	fmov	w16, s2
     ac0:      	add	x15, x11, x14
     ac4:      	movi.2d	v3, #0000000000000000
     ac8:      	movi.2d	v4, #0000000000000000
     acc:      	tbnz	w16, #0x0, 0xaf4 <_llm_rows.packet_batch.blocks+0x838>
     ad0:      	and	w16, w16, #0xff
     ad4:      	tbnz	w16, #0x1, 0xb00 <_llm_rows.packet_batch.blocks+0x844>
     ad8:      	tbnz	w16, #0x2, 0xb0c <_llm_rows.packet_batch.blocks+0x850>
     adc:      	tbnz	w16, #0x3, 0xb18 <_llm_rows.packet_batch.blocks+0x85c>
     ae0:      	tbnz	w16, #0x4, 0xb24 <_llm_rows.packet_batch.blocks+0x868>
     ae4:      	tbnz	w16, #0x5, 0xb30 <_llm_rows.packet_batch.blocks+0x874>
     ae8:      	tbnz	w16, #0x6, 0xb3c <_llm_rows.packet_batch.blocks+0x880>
     aec:      	tbz	w16, #0x7, 0xa9c <_llm_rows.packet_batch.blocks+0x7e0>
     af0:      	b	0xb48 <_llm_rows.packet_batch.blocks+0x88c>
     af4:      	ldr	s3, [x15]
     af8:      	and	w16, w16, #0xff
     afc:      	tbz	w16, #0x1, 0xad8 <_llm_rows.packet_batch.blocks+0x81c>
     b00:      	add	x17, x15, #0x4
     b04:      	ld1.s	{ v3 }[1], [x17]
     b08:      	tbz	w16, #0x2, 0xadc <_llm_rows.packet_batch.blocks+0x820>
     b0c:      	add	x17, x15, #0x8
     b10:      	ld1.s	{ v3 }[2], [x17]
     b14:      	tbz	w16, #0x3, 0xae0 <_llm_rows.packet_batch.blocks+0x824>
     b18:      	add	x17, x15, #0xc
     b1c:      	ld1.s	{ v3 }[3], [x17]
     b20:      	tbz	w16, #0x4, 0xae4 <_llm_rows.packet_batch.blocks+0x828>
     b24:      	add	x17, x15, #0x10
     b28:      	ld1.s	{ v4 }[0], [x17]
     b2c:      	tbz	w16, #0x5, 0xae8 <_llm_rows.packet_batch.blocks+0x82c>
     b30:      	add	x17, x15, #0x14
     b34:      	ld1.s	{ v4 }[1], [x17]
     b38:      	tbz	w16, #0x6, 0xaec <_llm_rows.packet_batch.blocks+0x830>
     b3c:      	add	x17, x15, #0x18
     b40:      	ld1.s	{ v4 }[2], [x17]
     b44:      	tbz	w16, #0x7, 0xa9c <_llm_rows.packet_batch.blocks+0x7e0>
     b48:      	add	x15, x15, #0x1c
     b4c:      	ld1.s	{ v4 }[3], [x15]
     b50:      	b	0xa9c <_llm_rows.packet_batch.blocks+0x7e0>
     b54:      	mov	x14, #0x0               ; =0
     b58:      	lsl	x11, x13, #9
     b5c:      	add	x10, x10, x11
     b60:      	b	0xb84 <_llm_rows.packet_batch.blocks+0x8c8>
     b64:      	add	x13, x23, x14
     b68:      	ldp	q5, q6, [x13]
     b6c:      	bif.16b	v4, v6, v1
     b70:      	bif.16b	v3, v5, v0
     b74:      	stp	q3, q4, [x13]
     b78:      	add	x14, x14, #0x20
     b7c:      	cmp	x14, #0x600
     b80:      	b.eq	0xc1c <_llm_rows.packet_batch.blocks+0x960>
     b84:      	fmov	w15, s2
     b88:      	add	x13, x10, x14
     b8c:      	movi.2d	v3, #0000000000000000
     b90:      	movi.2d	v4, #0000000000000000
     b94:      	tbnz	w15, #0x0, 0xbbc <_llm_rows.packet_batch.blocks+0x900>
     b98:      	and	w15, w15, #0xff
     b9c:      	tbnz	w15, #0x1, 0xbc8 <_llm_rows.packet_batch.blocks+0x90c>
     ba0:      	tbnz	w15, #0x2, 0xbd4 <_llm_rows.packet_batch.blocks+0x918>
     ba4:      	tbnz	w15, #0x3, 0xbe0 <_llm_rows.packet_batch.blocks+0x924>
     ba8:      	tbnz	w15, #0x4, 0xbec <_llm_rows.packet_batch.blocks+0x930>
     bac:      	tbnz	w15, #0x5, 0xbf8 <_llm_rows.packet_batch.blocks+0x93c>
     bb0:      	tbnz	w15, #0x6, 0xc04 <_llm_rows.packet_batch.blocks+0x948>
     bb4:      	tbz	w15, #0x7, 0xb64 <_llm_rows.packet_batch.blocks+0x8a8>
     bb8:      	b	0xc10 <_llm_rows.packet_batch.blocks+0x954>
     bbc:      	ldr	s3, [x13]
     bc0:      	and	w15, w15, #0xff
     bc4:      	tbz	w15, #0x1, 0xba0 <_llm_rows.packet_batch.blocks+0x8e4>
     bc8:      	add	x16, x13, #0x4
     bcc:      	ld1.s	{ v3 }[1], [x16]
     bd0:      	tbz	w15, #0x2, 0xba4 <_llm_rows.packet_batch.blocks+0x8e8>
     bd4:      	add	x16, x13, #0x8
     bd8:      	ld1.s	{ v3 }[2], [x16]
     bdc:      	tbz	w15, #0x3, 0xba8 <_llm_rows.packet_batch.blocks+0x8ec>
     be0:      	add	x16, x13, #0xc
     be4:      	ld1.s	{ v3 }[3], [x16]
     be8:      	tbz	w15, #0x4, 0xbac <_llm_rows.packet_batch.blocks+0x8f0>
     bec:      	add	x16, x13, #0x10
     bf0:      	ld1.s	{ v4 }[0], [x16]
     bf4:      	tbz	w15, #0x5, 0xbb0 <_llm_rows.packet_batch.blocks+0x8f4>
     bf8:      	add	x16, x13, #0x14
     bfc:      	ld1.s	{ v4 }[1], [x16]
     c00:      	tbz	w15, #0x6, 0xbb4 <_llm_rows.packet_batch.blocks+0x8f8>
     c04:      	add	x16, x13, #0x18
     c08:      	ld1.s	{ v4 }[2], [x16]
     c0c:      	tbz	w15, #0x7, 0xb64 <_llm_rows.packet_batch.blocks+0x8a8>
     c10:      	add	x13, x13, #0x1c
     c14:      	ld1.s	{ v4 }[3], [x13]
     c18:      	b	0xb64 <_llm_rows.packet_batch.blocks+0x8a8>
     c1c:      	mov	x10, #0x0               ; =0
     c20:      	add	x9, x9, x11
     c24:      	b	0xc48 <_llm_rows.packet_batch.blocks+0x98c>
     c28:      	add	x11, x24, x10
     c2c:      	ldp	q5, q6, [x11]
     c30:      	bif.16b	v4, v6, v1
     c34:      	bif.16b	v3, v5, v0
     c38:      	stp	q3, q4, [x11]
     c3c:      	add	x10, x10, #0x20
     c40:      	cmp	x10, #0x600
     c44:      	b.eq	0xce0 <_llm_rows.packet_batch.blocks+0xa24>
     c48:      	fmov	w13, s2
     c4c:      	add	x11, x9, x10
     c50:      	movi.2d	v3, #0000000000000000
     c54:      	movi.2d	v4, #0000000000000000
     c58:      	tbnz	w13, #0x0, 0xc80 <_llm_rows.packet_batch.blocks+0x9c4>
     c5c:      	and	w13, w13, #0xff
     c60:      	tbnz	w13, #0x1, 0xc8c <_llm_rows.packet_batch.blocks+0x9d0>
     c64:      	tbnz	w13, #0x2, 0xc98 <_llm_rows.packet_batch.blocks+0x9dc>
     c68:      	tbnz	w13, #0x3, 0xca4 <_llm_rows.packet_batch.blocks+0x9e8>
     c6c:      	tbnz	w13, #0x4, 0xcb0 <_llm_rows.packet_batch.blocks+0x9f4>
     c70:      	tbnz	w13, #0x5, 0xcbc <_llm_rows.packet_batch.blocks+0xa00>
     c74:      	tbnz	w13, #0x6, 0xcc8 <_llm_rows.packet_batch.blocks+0xa0c>
     c78:      	tbz	w13, #0x7, 0xc28 <_llm_rows.packet_batch.blocks+0x96c>
     c7c:      	b	0xcd4 <_llm_rows.packet_batch.blocks+0xa18>
     c80:      	ldr	s3, [x11]
     c84:      	and	w13, w13, #0xff
     c88:      	tbz	w13, #0x1, 0xc64 <_llm_rows.packet_batch.blocks+0x9a8>
     c8c:      	add	x14, x11, #0x4
     c90:      	ld1.s	{ v3 }[1], [x14]
     c94:      	tbz	w13, #0x2, 0xc68 <_llm_rows.packet_batch.blocks+0x9ac>
     c98:      	add	x14, x11, #0x8
     c9c:      	ld1.s	{ v3 }[2], [x14]
     ca0:      	tbz	w13, #0x3, 0xc6c <_llm_rows.packet_batch.blocks+0x9b0>
     ca4:      	add	x14, x11, #0xc
     ca8:      	ld1.s	{ v3 }[3], [x14]
     cac:      	tbz	w13, #0x4, 0xc70 <_llm_rows.packet_batch.blocks+0x9b4>
     cb0:      	add	x14, x11, #0x10
     cb4:      	ld1.s	{ v4 }[0], [x14]
     cb8:      	tbz	w13, #0x5, 0xc74 <_llm_rows.packet_batch.blocks+0x9b8>
     cbc:      	add	x14, x11, #0x14
     cc0:      	ld1.s	{ v4 }[1], [x14]
     cc4:      	tbz	w13, #0x6, 0xc78 <_llm_rows.packet_batch.blocks+0x9bc>
     cc8:      	add	x14, x11, #0x18
     ccc:      	ld1.s	{ v4 }[2], [x14]
     cd0:      	tbz	w13, #0x7, 0xc28 <_llm_rows.packet_batch.blocks+0x96c>
     cd4:      	add	x11, x11, #0x1c
     cd8:      	ld1.s	{ v4 }[3], [x11]
     cdc:      	b	0xc28 <_llm_rows.packet_batch.blocks+0x96c>
     ce0:      	mov	x9, #0x0                ; =0
     ce4:      	add	x8, x8, x12
     ce8:      	b	0xcf8 <_llm_rows.packet_batch.blocks+0xa3c>
     cec:      	add	x9, x9, #0x20
     cf0:      	cmp	x9, #0x600
     cf4:      	b.eq	0xdd4 <_llm_rows.packet_batch.blocks+0xb18>
     cf8:      	fmov	w11, s2
     cfc:      	add	x10, x4, x9
     d00:      	ldp	q5, q3, [x10]
     d04:      	add	x10, x23, x9
     d08:      	ldp	q6, q4, [x10]
     d0c:      	fmul.4s	v7, v5, v6
     d10:      	add	x10, x25, x9
     d14:      	ldp	q16, q5, [x10]
     d18:      	add	x10, x24, x9
     d1c:      	ldp	q17, q6, [x10]
     d20:      	fmul.4s	v16, v16, v17
     d24:      	fsub.4s	v7, v7, v16
     d28:      	and.16b	v7, v0, v7
     d2c:      	add	x10, x8, x9
     d30:      	tbnz	w11, #0x0, 0xd68 <_llm_rows.packet_batch.blocks+0xaac>
     d34:      	and	w11, w11, #0xff
     d38:      	tbnz	w11, #0x1, 0xd74 <_llm_rows.packet_batch.blocks+0xab8>
     d3c:      	tbnz	w11, #0x2, 0xd80 <_llm_rows.packet_batch.blocks+0xac4>
     d40:      	tbnz	w11, #0x3, 0xd8c <_llm_rows.packet_batch.blocks+0xad0>
     d44:      	fmul.4s	v3, v3, v4
     d48:      	fmul.4s	v4, v5, v6
     d4c:      	fsub.4s	v3, v3, v4
     d50:      	and.16b	v3, v1, v3
     d54:      	tbnz	w11, #0x4, 0xda8 <_llm_rows.packet_batch.blocks+0xaec>
     d58:      	tbnz	w11, #0x5, 0xdb0 <_llm_rows.packet_batch.blocks+0xaf4>
     d5c:      	tbnz	w11, #0x6, 0xdbc <_llm_rows.packet_batch.blocks+0xb00>
     d60:      	tbz	w11, #0x7, 0xcec <_llm_rows.packet_batch.blocks+0xa30>
     d64:      	b	0xdc8 <_llm_rows.packet_batch.blocks+0xb0c>
     d68:      	str	s7, [x10]
     d6c:      	and	w11, w11, #0xff
     d70:      	tbz	w11, #0x1, 0xd3c <_llm_rows.packet_batch.blocks+0xa80>
     d74:      	add	x12, x10, #0x4
     d78:      	st1.s	{ v7 }[1], [x12]
     d7c:      	tbz	w11, #0x2, 0xd40 <_llm_rows.packet_batch.blocks+0xa84>
     d80:      	add	x12, x10, #0x8
     d84:      	st1.s	{ v7 }[2], [x12]
     d88:      	tbz	w11, #0x3, 0xd44 <_llm_rows.packet_batch.blocks+0xa88>
     d8c:      	add	x12, x10, #0xc
     d90:      	st1.s	{ v7 }[3], [x12]
     d94:      	fmul.4s	v3, v3, v4
     d98:      	fmul.4s	v4, v5, v6
     d9c:      	fsub.4s	v3, v3, v4
     da0:      	and.16b	v3, v1, v3
     da4:      	tbz	w11, #0x4, 0xd58 <_llm_rows.packet_batch.blocks+0xa9c>
     da8:      	str	s3, [x10, #0x10]
     dac:      	tbz	w11, #0x5, 0xd5c <_llm_rows.packet_batch.blocks+0xaa0>
     db0:      	add	x12, x10, #0x14
     db4:      	st1.s	{ v3 }[1], [x12]
     db8:      	tbz	w11, #0x6, 0xd60 <_llm_rows.packet_batch.blocks+0xaa4>
     dbc:      	add	x12, x10, #0x18
     dc0:      	st1.s	{ v3 }[2], [x12]
     dc4:      	tbz	w11, #0x7, 0xcec <_llm_rows.packet_batch.blocks+0xa30>
     dc8:      	add	x10, x10, #0x1c
     dcc:      	st1.s	{ v3 }[3], [x10]
     dd0:      	b	0xcec <_llm_rows.packet_batch.blocks+0xa30>
     dd4:      	mov	x9, #0x0                ; =0
     dd8:      	add	x8, x8, #0x600
     ddc:      	b	0xdec <_llm_rows.packet_batch.blocks+0xb30>
     de0:      	add	x9, x9, #0x20
     de4:      	cmp	x9, #0x600
     de8:      	b.eq	0x358 <_llm_rows.packet_batch.blocks+0x9c>
     dec:      	fmov	w11, s2
     df0:      	add	x10, x4, x9
     df4:      	ldp	q5, q3, [x10]
     df8:      	add	x10, x24, x9
     dfc:      	ldp	q6, q4, [x10]
     e00:      	fmul.4s	v7, v5, v6
     e04:      	add	x10, x25, x9
     e08:      	ldp	q16, q5, [x10]
     e0c:      	add	x10, x23, x9
     e10:      	ldp	q17, q6, [x10]
     e14:      	fmul.4s	v16, v16, v17
     e18:      	fadd.4s	v7, v7, v16
     e1c:      	and.16b	v7, v0, v7
     e20:      	add	x10, x8, x9
     e24:      	tbnz	w11, #0x0, 0xe5c <_llm_rows.packet_batch.blocks+0xba0>
     e28:      	and	w11, w11, #0xff
     e2c:      	tbnz	w11, #0x1, 0xe68 <_llm_rows.packet_batch.blocks+0xbac>
     e30:      	tbnz	w11, #0x2, 0xe74 <_llm_rows.packet_batch.blocks+0xbb8>
     e34:      	tbnz	w11, #0x3, 0xe80 <_llm_rows.packet_batch.blocks+0xbc4>
     e38:      	fmul.4s	v3, v3, v4
     e3c:      	fmul.4s	v4, v5, v6
     e40:      	fadd.4s	v3, v3, v4
     e44:      	and.16b	v3, v1, v3
     e48:      	tbnz	w11, #0x4, 0xe9c <_llm_rows.packet_batch.blocks+0xbe0>
     e4c:      	tbnz	w11, #0x5, 0xea4 <_llm_rows.packet_batch.blocks+0xbe8>
     e50:      	tbnz	w11, #0x6, 0xeb0 <_llm_rows.packet_batch.blocks+0xbf4>
     e54:      	tbz	w11, #0x7, 0xde0 <_llm_rows.packet_batch.blocks+0xb24>
     e58:      	b	0xebc <_llm_rows.packet_batch.blocks+0xc00>
     e5c:      	str	s7, [x10]
     e60:      	and	w11, w11, #0xff
     e64:      	tbz	w11, #0x1, 0xe30 <_llm_rows.packet_batch.blocks+0xb74>
     e68:      	add	x12, x10, #0x4
     e6c:      	st1.s	{ v7 }[1], [x12]
     e70:      	tbz	w11, #0x2, 0xe34 <_llm_rows.packet_batch.blocks+0xb78>
     e74:      	add	x12, x10, #0x8
     e78:      	st1.s	{ v7 }[2], [x12]
     e7c:      	tbz	w11, #0x3, 0xe38 <_llm_rows.packet_batch.blocks+0xb7c>
     e80:      	add	x12, x10, #0xc
     e84:      	st1.s	{ v7 }[3], [x12]
     e88:      	fmul.4s	v3, v3, v4
     e8c:      	fmul.4s	v4, v5, v6
     e90:      	fadd.4s	v3, v3, v4
     e94:      	and.16b	v3, v1, v3
     e98:      	tbz	w11, #0x4, 0xe4c <_llm_rows.packet_batch.blocks+0xb90>
     e9c:      	str	s3, [x10, #0x10]
     ea0:      	tbz	w11, #0x5, 0xe50 <_llm_rows.packet_batch.blocks+0xb94>
     ea4:      	add	x12, x10, #0x14
     ea8:      	st1.s	{ v3 }[1], [x12]
     eac:      	tbz	w11, #0x6, 0xe54 <_llm_rows.packet_batch.blocks+0xb98>
     eb0:      	add	x12, x10, #0x18
     eb4:      	st1.s	{ v3 }[2], [x12]
     eb8:      	tbz	w11, #0x7, 0xde0 <_llm_rows.packet_batch.blocks+0xb24>
     ebc:      	add	x10, x10, #0x1c
     ec0:      	st1.s	{ v3 }[3], [x10]
     ec4:      	b	0xde0 <_llm_rows.packet_batch.blocks+0xb24>
     ec8:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
     ecc:      	add	sp, sp, #0x890
     ed0:      	ldp	x29, x30, [sp, #0x60]
     ed4:      	ldp	x20, x19, [sp, #0x50]
     ed8:      	ldp	x22, x21, [sp, #0x40]
     edc:      	ldp	x24, x23, [sp, #0x30]
     ee0:      	ldp	x26, x25, [sp, #0x20]
     ee4:      	ldp	x28, x27, [sp, #0x10]
     ee8:      	ldp	d9, d8, [sp], #0x70
     eec:      	ret

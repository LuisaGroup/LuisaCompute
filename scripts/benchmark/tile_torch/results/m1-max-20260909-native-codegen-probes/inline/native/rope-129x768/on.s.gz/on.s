
/private/tmp/luisa-packet-inline.UY1lIE/capture/rope-129x768/on/object/tile_xir_w8_36487_1788935107750517_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d9, d8, [sp, #-0x70]!
       4:      	stp	x28, x27, [sp, #0x10]
       8:      	stp	x26, x25, [sp, #0x20]
       c:      	stp	x24, x23, [sp, #0x30]
      10:      	stp	x22, x21, [sp, #0x40]
      14:      	stp	x20, x19, [sp, #0x50]
      18:      	stp	x29, x30, [sp, #0x60]
      1c:      	sub	sp, sp, #0x1, lsl #12   ; =0x1000
      20:      	sub	sp, sp, #0x8d0
      24:      	str	x0, [sp, #0x48]
      28:      	str	w3, [sp, #0x68]
      2c:      	cbz	w3, 0x106c <ltmp0+0x106c>
      30:      	mov	w12, #0x0               ; =0
      34:      	ldp	w9, w8, [x2, #0x2c]
      38:      	stp	w8, w9, [sp, #0x60]
      3c:      	ldp	w8, w9, [x2]
      40:      	movi.2s	v8, #0x3, lsl #8
      44:      	add	x28, sp, #0x1, lsl #12  ; =0x1000
      48:      	add	x28, x28, #0x2d0
      4c:      	add	x4, sp, #0xcd0
      50:      	add	x27, sp, #0x6d0
      54:      	add	x24, sp, #0xd0
      58:      	adrp	x10, 0x0 <ltmp0>
      5c:      	ldr	q0, [x10]
      60:      	str	q0, [sp, #0x30]
      64:      	adrp	x10, 0x0 <ltmp0>
      68:      	ldr	q0, [x10]
      6c:      	str	q0, [sp, #0x20]
      70:      	adrp	x10, 0x0 <ltmp0>
      74:      	ldr	q0, [x10]
      78:      	str	q0, [sp, #0x10]
      7c:      	adrp	x10, 0x0 <ltmp0>
      80:      	ldr	q0, [x10]
      84:      	str	q0, [sp, #0x80]
      88:      	ldp	w10, w11, [x2, #0x8]
      8c:      	str	x2, [sp, #0x8]
      90:      	str	x11, [sp, #0x58]
      94:      	b	0xe0 <ltmp0+0xe0>
      98:      	ldr	x15, [sp, #0x78]
      9c:      	add	w8, w15, #0x1
      a0:      	ldp	w11, w9, [sp, #0x60]
      a4:      	cmp	w8, w9
      a8:      	cset	w9, eq
      ac:      	csinc	w8, wzr, w15, eq
      b0:      	ldp	w14, w13, [sp, #0x6c]
      b4:      	cinc	w10, w14, eq
      b8:      	cmp	w10, w11
      bc:      	cset	w11, eq
      c0:      	ands	w11, w9, w11
      c4:      	csel	w9, wzr, w10, ne
      c8:      	add	w10, w13, w11
      cc:      	ldr	w12, [sp, #0x74]
      d0:      	add	w12, w12, #0x1
      d4:      	ldr	w11, [sp, #0x68]
      d8:      	cmp	w12, w11
      dc:      	b.eq	0x1058 <ltmp0+0x1058>
      e0:      	stp	w10, w12, [sp, #0x70]
      e4:      	str	w9, [sp, #0x6c]
      e8:      	mov	x13, x8
      ec:      	ubfiz	x8, x8, #5, #32
      f0:      	ldr	x12, [sp, #0x58]
      f4:      	cmp	x8, x12
      f8:      	csel	x9, x8, xzr, ls
      fc:      	subs	x10, x12, x9
     100:      	cmp	x10, #0x20
     104:      	mov	w11, #0x20              ; =32
     108:      	csel	x10, x10, x11, lo
     10c:      	cmp	x12, x9
     110:      	ccmp	x8, x12, #0x2, hi
     114:      	csel	x8, x10, xzr, ls
     118:      	cmp	x8, #0x20
     11c:      	str	x13, [sp, #0x78]
     120:      	b.lo	0x39c <ltmp0+0x39c>
     124:      	mov	w20, #0x0               ; =0
     128:      	ldr	x8, [sp, #0x48]
     12c:      	ldr	x21, [x8]
     130:      	ldr	x22, [x8, #0x10]
     134:      	ldr	x23, [x8, #0x20]
     138:      	ldr	x25, [x8, #0x30]
     13c:      	subs	x8, x21, x25
     140:      	mov	w11, #0xbff             ; =3071
     144:      	movk	w11, #0x6, lsl #16
     148:      	ccmp	x8, x11, #0x0, hs
     14c:      	cset	w8, hi
     150:      	subs	x9, x25, x21
     154:      	ccmp	x9, x11, #0x0, hs
     158:      	csinc	w8, w8, wzr, ls
     15c:      	subs	x9, x22, x25
     160:      	ccmp	x9, x11, #0x0, hs
     164:      	cset	w9, hi
     168:      	subs	x10, x25, x22
     16c:      	mov	w12, #0x5ff             ; =1535
     170:      	movk	w12, #0x3, lsl #16
     174:      	ccmp	x10, x12, #0x0, hs
     178:      	csinc	w9, w9, wzr, ls
     17c:      	and	w8, w8, w9
     180:      	subs	x9, x23, x25
     184:      	ccmp	x9, x11, #0x0, hs
     188:      	cset	w9, hi
     18c:      	subs	x10, x25, x23
     190:      	ccmp	x10, x12, #0x0, hs
     194:      	csinc	w9, w9, wzr, ls
     198:      	and	w15, w9, w8
     19c:      	add	x8, x21, #0x600
     1a0:      	str	x8, [sp, #0xb8]
     1a4:      	add	x16, x25, #0x600
     1a8:      	lsl	w17, w13, #2
     1ac:      	str	w15, [sp, #0xb4]
     1b0:      	str	x16, [sp, #0xa8]
     1b4:      	str	w17, [sp, #0xa0]
     1b8:      	b	0x1c8 <ltmp0+0x1c8>
     1bc:      	add	w20, w20, #0x1
     1c0:      	cmp	w20, #0x4
     1c4:      	b.eq	0x98 <ltmp0+0x98>
     1c8:      	add	w8, w20, w17
     1cc:      	and	w8, w8, #0x1fffffff
     1d0:      	dup.2s	v0, w8
     1d4:      	ushll.2d	v1, v0, #0x0
     1d8:      	tbz	w15, #0x0, 0x288 <ltmp0+0x288>
     1dc:      	mov	x8, #0x0                ; =0
     1e0:      	xtn.2s	v0, v1
     1e4:      	umull.2d	v0, v0, v8
     1e8:      	fmov	x10, d0
     1ec:      	fmov	x9, d1
     1f0:      	add	x9, x9, x9, lsl #1
     1f4:      	lsl	x9, x9, #7
     1f8:      	lsl	x11, x10, #2
     1fc:      	add	x10, x16, x11
     200:      	ldr	x12, [sp, #0xb8]
     204:      	add	x11, x12, x11
     208:      	fmov	d1, x8
     20c:      	add.2d	v1, v1, v0
     210:      	fmov	x12, d1
     214:      	lsl	x12, x12, #2
     218:      	add	x13, x21, x12
     21c:      	ldp	q1, q2, [x13]
     220:      	ldp	q3, q4, [x11], #0x20
     224:      	add	x13, x8, x9
     228:      	lsl	x13, x13, #2
     22c:      	add	x14, x22, x13
     230:      	ldp	q5, q6, [x14]
     234:      	add	x13, x23, x13
     238:      	ldp	q7, q16, [x13]
     23c:      	fmul.4s	v17, v2, v6
     240:      	fmul.4s	v18, v1, v5
     244:      	fmul.4s	v19, v4, v16
     248:      	fmul.4s	v20, v3, v7
     24c:      	fsub.4s	v18, v18, v20
     250:      	fsub.4s	v17, v17, v19
     254:      	add	x12, x25, x12
     258:      	stp	q18, q17, [x12]
     25c:      	fmul.4s	v2, v2, v16
     260:      	fmul.4s	v1, v1, v7
     264:      	fmul.4s	v4, v4, v6
     268:      	fmul.4s	v3, v3, v5
     26c:      	fadd.4s	v1, v3, v1
     270:      	fadd.4s	v2, v4, v2
     274:      	stp	q1, q2, [x10], #0x20
     278:      	add	x8, x8, #0x8
     27c:      	cmp	x8, #0x180
     280:      	b.ne	0x208 <ltmp0+0x208>
     284:      	b	0x1bc <ltmp0+0x1bc>
     288:      	fmov	x8, d1
     28c:      	add	x19, x8, x8, lsl #1
     290:      	lsl	x26, x19, #10
     294:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     298:      	add	x0, x0, #0x2d0
     29c:      	add	x1, x21, x26
     2a0:      	mov	w2, #0x600              ; =1536
     2a4:      	bl	0x2a4 <ltmp0+0x2a4>
     2a8:      	add	x0, sp, #0xcd0
     2ac:      	ldr	x8, [sp, #0xb8]
     2b0:      	add	x1, x8, x26
     2b4:      	mov	w2, #0x600              ; =1536
     2b8:      	bl	0x2b8 <ltmp0+0x2b8>
     2bc:      	lsl	x19, x19, #9
     2c0:      	add	x0, sp, #0x6d0
     2c4:      	add	x1, x22, x19
     2c8:      	mov	w2, #0x600              ; =1536
     2cc:      	bl	0x2cc <ltmp0+0x2cc>
     2d0:      	add	x0, sp, #0xd0
     2d4:      	add	x1, x23, x19
     2d8:      	mov	w2, #0x600              ; =1536
     2dc:      	bl	0x2dc <ltmp0+0x2dc>
     2e0:      	add	x4, sp, #0xcd0
     2e4:      	mov	x8, #0x0                ; =0
     2e8:      	add	x9, x25, x26
     2ec:      	add	x10, x28, x8
     2f0:      	ldp	q0, q1, [x10]
     2f4:      	add	x10, x27, x8
     2f8:      	ldp	q2, q3, [x10]
     2fc:      	fmul.4s	v1, v1, v3
     300:      	fmul.4s	v0, v0, v2
     304:      	add	x10, x4, x8
     308:      	ldp	q2, q3, [x10]
     30c:      	add	x10, x24, x8
     310:      	ldp	q4, q5, [x10]
     314:      	fmul.4s	v3, v3, v5
     318:      	fmul.4s	v2, v2, v4
     31c:      	fsub.4s	v0, v0, v2
     320:      	fsub.4s	v1, v1, v3
     324:      	add	x10, x9, x8
     328:      	stp	q0, q1, [x10]
     32c:      	add	x8, x8, #0x20
     330:      	cmp	x8, #0x600
     334:      	b.ne	0x2ec <ltmp0+0x2ec>
     338:      	mov	x8, #0x0                ; =0
     33c:      	ldr	x16, [sp, #0xa8]
     340:      	add	x9, x16, x26
     344:      	ldr	w15, [sp, #0xb4]
     348:      	ldr	w17, [sp, #0xa0]
     34c:      	add	x10, x28, x8
     350:      	ldp	q0, q1, [x10]
     354:      	add	x10, x24, x8
     358:      	ldp	q2, q3, [x10]
     35c:      	fmul.4s	v1, v1, v3
     360:      	fmul.4s	v0, v0, v2
     364:      	add	x10, x4, x8
     368:      	ldp	q2, q3, [x10]
     36c:      	add	x10, x27, x8
     370:      	ldp	q4, q5, [x10]
     374:      	fmul.4s	v3, v3, v5
     378:      	fmul.4s	v2, v2, v4
     37c:      	fadd.4s	v0, v0, v2
     380:      	fadd.4s	v1, v1, v3
     384:      	add	x10, x9, x8
     388:      	stp	q0, q1, [x10]
     38c:      	add	x8, x8, #0x20
     390:      	cmp	x8, #0x600
     394:      	b.ne	0x34c <ltmp0+0x34c>
     398:      	b	0x1bc <ltmp0+0x1bc>
     39c:      	lsr	x15, x8, #3
     3a0:      	str	x8, [sp, #0x50]
     3a4:      	cmp	x8, #0x8
     3a8:      	b.hs	0x8c0 <ltmp0+0x8c0>
     3ac:      	ldr	x8, [sp, #0x50]
     3b0:      	and	w8, w8, #0x7
     3b4:      	cbz	w8, 0x98 <ltmp0+0x98>
     3b8:      	dup.4s	v0, w8
     3bc:      	ldp	q1, q2, [sp, #0x20]
     3c0:      	cmhi.4s	v1, v0, v1
     3c4:      	cmhi.4s	v0, v0, v2
     3c8:      	uzp1.8h	v3, v0, v1
     3cc:      	umaxv.8h	h2, v3
     3d0:      	fmov	w8, s2
     3d4:      	tbz	w8, #0x0, 0x98 <ltmp0+0x98>
     3d8:      	ldr	x8, [sp, #0x48]
     3dc:      	ldr	x11, [x8]
     3e0:      	ldr	x10, [x8, #0x10]
     3e4:      	ldr	x9, [x8, #0x20]
     3e8:      	ldr	x8, [x8, #0x30]
     3ec:      	ldr	x12, [sp, #0x78]
     3f0:      	ubfiz	w12, w12, #2, #27
     3f4:      	orr	w12, w12, w15
     3f8:      	dup.4s	v2, w12
     3fc:      	and.16b	v2, v0, v2
     400:      	ushll.2d	v2, v2, #0x0
     404:      	subs	x12, x11, x8
     408:      	mov	w15, #0xbff             ; =3071
     40c:      	movk	w15, #0x6, lsl #16
     410:      	ccmp	x12, x15, #0x0, hs
     414:      	cset	w12, hi
     418:      	subs	x13, x8, x11
     41c:      	ccmp	x13, x15, #0x0, hs
     420:      	csinc	w12, w12, wzr, ls
     424:      	subs	x13, x10, x8
     428:      	ccmp	x13, x15, #0x0, hs
     42c:      	cset	w13, hi
     430:      	subs	x14, x8, x10
     434:      	mov	w16, #0x5ff             ; =1535
     438:      	movk	w16, #0x3, lsl #16
     43c:      	ccmp	x14, x16, #0x0, hs
     440:      	csinc	w13, w13, wzr, ls
     444:      	subs	x14, x9, x8
     448:      	ccmp	x14, x15, #0x0, hs
     44c:      	cset	w14, hi
     450:      	subs	x15, x8, x9
     454:      	ccmp	x15, x16, #0x0, hs
     458:      	csinc	w14, w14, wzr, ls
     45c:      	cmp	w14, #0x1
     460:      	b.ne	0xb44 <ltmp0+0xb44>
     464:      	cbz	w12, 0xb44 <ltmp0+0xb44>
     468:      	tbz	w13, #0x0, 0xb44 <ltmp0+0xb44>
     46c:      	mov	x12, #0x0               ; =0
     470:      	sshll.2d	v0, v0, #0x0
     474:      	ldr	q1, [sp, #0x10]
     478:      	and.16b	v0, v0, v1
     47c:      	xtn.2s	v1, v2
     480:      	umull.2d	v1, v1, v8
     484:      	fmov	x13, d1
     488:      	add	x13, x13, #0x180
     48c:      	fmov	x14, d2
     490:      	add	x14, x14, x14, lsl #1
     494:      	lsl	x14, x14, #7
     498:      	ldr	q2, [sp, #0x80]
     49c:      	and.16b	v2, v3, v2
     4a0:      	addv.8h	h2, v2
     4a4:      	fmov	w15, s2
     4a8:      	b	0x4b8 <ltmp0+0x4b8>
     4ac:      	add	x12, x12, #0x8
     4b0:      	cmp	x12, #0x180
     4b4:      	b.eq	0x98 <ltmp0+0x98>
     4b8:      	dup.2d	v3, x12
     4bc:      	orr.16b	v5, v3, v0
     4c0:      	add.2d	v3, v5, v1
     4c4:      	fmov	x16, d3
     4c8:      	lsl	x16, x16, #2
     4cc:      	add	x17, x11, x16
     4d0:      	movi.2d	v4, #0000000000000000
     4d4:      	movi.2d	v3, #0000000000000000
     4d8:      	tbnz	w15, #0x0, 0x648 <ltmp0+0x648>
     4dc:      	and	w0, w15, #0xff
     4e0:      	tbnz	w0, #0x1, 0x654 <ltmp0+0x654>
     4e4:      	tbnz	w0, #0x2, 0x660 <ltmp0+0x660>
     4e8:      	tbnz	w0, #0x3, 0x66c <ltmp0+0x66c>
     4ec:      	tbnz	w0, #0x4, 0x678 <ltmp0+0x678>
     4f0:      	tbnz	w0, #0x5, 0x684 <ltmp0+0x684>
     4f4:      	tbnz	w0, #0x6, 0x690 <ltmp0+0x690>
     4f8:      	tbz	w0, #0x7, 0x504 <ltmp0+0x504>
     4fc:      	add	x17, x17, #0x1c
     500:      	ld1.s	{ v3 }[3], [x17]
     504:      	fmov	w2, s2
     508:      	fmov	x0, d5
     50c:      	add	x17, x13, x0
     510:      	lsl	x17, x17, #2
     514:      	add	x1, x11, x17
     518:      	movi.2d	v6, #0000000000000000
     51c:      	movi.2d	v5, #0000000000000000
     520:      	tbnz	w2, #0x0, 0x6a0 <ltmp0+0x6a0>
     524:      	and	w2, w2, #0xff
     528:      	tbnz	w2, #0x1, 0x6ac <ltmp0+0x6ac>
     52c:      	tbnz	w2, #0x2, 0x6b8 <ltmp0+0x6b8>
     530:      	tbnz	w2, #0x3, 0x6c4 <ltmp0+0x6c4>
     534:      	tbnz	w2, #0x4, 0x6d0 <ltmp0+0x6d0>
     538:      	tbnz	w2, #0x5, 0x6dc <ltmp0+0x6dc>
     53c:      	tbnz	w2, #0x6, 0x6e8 <ltmp0+0x6e8>
     540:      	tbz	w2, #0x7, 0x54c <ltmp0+0x54c>
     544:      	add	x1, x1, #0x1c
     548:      	ld1.s	{ v5 }[3], [x1]
     54c:      	fmov	w2, s2
     550:      	add	x0, x0, x14
     554:      	lsl	x0, x0, #2
     558:      	add	x1, x10, x0
     55c:      	movi.2d	v16, #0000000000000000
     560:      	movi.2d	v7, #0000000000000000
     564:      	tbnz	w2, #0x0, 0x6f8 <ltmp0+0x6f8>
     568:      	and	w2, w2, #0xff
     56c:      	tbnz	w2, #0x1, 0x704 <ltmp0+0x704>
     570:      	tbnz	w2, #0x2, 0x710 <ltmp0+0x710>
     574:      	tbnz	w2, #0x3, 0x71c <ltmp0+0x71c>
     578:      	tbnz	w2, #0x4, 0x728 <ltmp0+0x728>
     57c:      	tbnz	w2, #0x5, 0x734 <ltmp0+0x734>
     580:      	tbnz	w2, #0x6, 0x740 <ltmp0+0x740>
     584:      	tbnz	w2, #0x7, 0x74c <ltmp0+0x74c>
     588:      	fmov	w1, s2
     58c:      	add	x0, x9, x0
     590:      	movi.2d	v18, #0000000000000000
     594:      	movi.2d	v17, #0000000000000000
     598:      	tbnz	w1, #0x0, 0x768 <ltmp0+0x768>
     59c:      	and	w1, w1, #0xff
     5a0:      	tbnz	w1, #0x1, 0x774 <ltmp0+0x774>
     5a4:      	tbnz	w1, #0x2, 0x780 <ltmp0+0x780>
     5a8:      	tbnz	w1, #0x3, 0x78c <ltmp0+0x78c>
     5ac:      	tbnz	w1, #0x4, 0x798 <ltmp0+0x798>
     5b0:      	tbnz	w1, #0x5, 0x7a4 <ltmp0+0x7a4>
     5b4:      	tbnz	w1, #0x6, 0x7b0 <ltmp0+0x7b0>
     5b8:      	tbnz	w1, #0x7, 0x7bc <ltmp0+0x7bc>
     5bc:      	fmov	w0, s2
     5c0:      	fmul.4s	v19, v4, v16
     5c4:      	fmul.4s	v20, v6, v18
     5c8:      	fsub.4s	v19, v19, v20
     5cc:      	add	x16, x8, x16
     5d0:      	tbnz	w0, #0x0, 0x7dc <ltmp0+0x7dc>
     5d4:      	and	w0, w0, #0xff
     5d8:      	tbnz	w0, #0x1, 0x7e8 <ltmp0+0x7e8>
     5dc:      	tbnz	w0, #0x2, 0x7f4 <ltmp0+0x7f4>
     5e0:      	tbnz	w0, #0x3, 0x800 <ltmp0+0x800>
     5e4:      	fmul.4s	v19, v3, v7
     5e8:      	fmul.4s	v20, v5, v17
     5ec:      	fsub.4s	v19, v19, v20
     5f0:      	tbnz	w0, #0x4, 0x818 <ltmp0+0x818>
     5f4:      	tbnz	w0, #0x5, 0x820 <ltmp0+0x820>
     5f8:      	tbnz	w0, #0x6, 0x82c <ltmp0+0x82c>
     5fc:      	tbnz	w0, #0x7, 0x838 <ltmp0+0x838>
     600:      	fmov	w0, s2
     604:      	fmul.4s	v4, v4, v18
     608:      	fmul.4s	v6, v6, v16
     60c:      	fadd.4s	v4, v6, v4
     610:      	add	x16, x8, x17
     614:      	tbnz	w0, #0x0, 0x858 <ltmp0+0x858>
     618:      	and	w17, w0, #0xff
     61c:      	tbnz	w17, #0x1, 0x864 <ltmp0+0x864>
     620:      	tbnz	w17, #0x2, 0x870 <ltmp0+0x870>
     624:      	tbnz	w17, #0x3, 0x87c <ltmp0+0x87c>
     628:      	fmul.4s	v3, v3, v17
     62c:      	fmul.4s	v4, v5, v7
     630:      	fadd.4s	v3, v4, v3
     634:      	tbnz	w17, #0x4, 0x894 <ltmp0+0x894>
     638:      	tbnz	w17, #0x5, 0x89c <ltmp0+0x89c>
     63c:      	tbnz	w17, #0x6, 0x8a8 <ltmp0+0x8a8>
     640:      	tbz	w17, #0x7, 0x4ac <ltmp0+0x4ac>
     644:      	b	0x8b4 <ltmp0+0x8b4>
     648:      	ldr	s4, [x17]
     64c:      	and	w0, w15, #0xff
     650:      	tbz	w0, #0x1, 0x4e4 <ltmp0+0x4e4>
     654:      	add	x1, x17, #0x4
     658:      	ld1.s	{ v4 }[1], [x1]
     65c:      	tbz	w0, #0x2, 0x4e8 <ltmp0+0x4e8>
     660:      	add	x1, x17, #0x8
     664:      	ld1.s	{ v4 }[2], [x1]
     668:      	tbz	w0, #0x3, 0x4ec <ltmp0+0x4ec>
     66c:      	add	x1, x17, #0xc
     670:      	ld1.s	{ v4 }[3], [x1]
     674:      	tbz	w0, #0x4, 0x4f0 <ltmp0+0x4f0>
     678:      	add	x1, x17, #0x10
     67c:      	ld1.s	{ v3 }[0], [x1]
     680:      	tbz	w0, #0x5, 0x4f4 <ltmp0+0x4f4>
     684:      	add	x1, x17, #0x14
     688:      	ld1.s	{ v3 }[1], [x1]
     68c:      	tbz	w0, #0x6, 0x4f8 <ltmp0+0x4f8>
     690:      	add	x1, x17, #0x18
     694:      	ld1.s	{ v3 }[2], [x1]
     698:      	tbnz	w0, #0x7, 0x4fc <ltmp0+0x4fc>
     69c:      	b	0x504 <ltmp0+0x504>
     6a0:      	ldr	s6, [x1]
     6a4:      	and	w2, w2, #0xff
     6a8:      	tbz	w2, #0x1, 0x52c <ltmp0+0x52c>
     6ac:      	add	x3, x1, #0x4
     6b0:      	ld1.s	{ v6 }[1], [x3]
     6b4:      	tbz	w2, #0x2, 0x530 <ltmp0+0x530>
     6b8:      	add	x3, x1, #0x8
     6bc:      	ld1.s	{ v6 }[2], [x3]
     6c0:      	tbz	w2, #0x3, 0x534 <ltmp0+0x534>
     6c4:      	add	x3, x1, #0xc
     6c8:      	ld1.s	{ v6 }[3], [x3]
     6cc:      	tbz	w2, #0x4, 0x538 <ltmp0+0x538>
     6d0:      	add	x3, x1, #0x10
     6d4:      	ld1.s	{ v5 }[0], [x3]
     6d8:      	tbz	w2, #0x5, 0x53c <ltmp0+0x53c>
     6dc:      	add	x3, x1, #0x14
     6e0:      	ld1.s	{ v5 }[1], [x3]
     6e4:      	tbz	w2, #0x6, 0x540 <ltmp0+0x540>
     6e8:      	add	x3, x1, #0x18
     6ec:      	ld1.s	{ v5 }[2], [x3]
     6f0:      	tbnz	w2, #0x7, 0x544 <ltmp0+0x544>
     6f4:      	b	0x54c <ltmp0+0x54c>
     6f8:      	ldr	s16, [x1]
     6fc:      	and	w2, w2, #0xff
     700:      	tbz	w2, #0x1, 0x570 <ltmp0+0x570>
     704:      	add	x3, x1, #0x4
     708:      	ld1.s	{ v16 }[1], [x3]
     70c:      	tbz	w2, #0x2, 0x574 <ltmp0+0x574>
     710:      	add	x3, x1, #0x8
     714:      	ld1.s	{ v16 }[2], [x3]
     718:      	tbz	w2, #0x3, 0x578 <ltmp0+0x578>
     71c:      	add	x3, x1, #0xc
     720:      	ld1.s	{ v16 }[3], [x3]
     724:      	tbz	w2, #0x4, 0x57c <ltmp0+0x57c>
     728:      	add	x3, x1, #0x10
     72c:      	ld1.s	{ v7 }[0], [x3]
     730:      	tbz	w2, #0x5, 0x580 <ltmp0+0x580>
     734:      	add	x3, x1, #0x14
     738:      	ld1.s	{ v7 }[1], [x3]
     73c:      	tbz	w2, #0x6, 0x584 <ltmp0+0x584>
     740:      	add	x3, x1, #0x18
     744:      	ld1.s	{ v7 }[2], [x3]
     748:      	tbz	w2, #0x7, 0x588 <ltmp0+0x588>
     74c:      	add	x1, x1, #0x1c
     750:      	ld1.s	{ v7 }[3], [x1]
     754:      	fmov	w1, s2
     758:      	add	x0, x9, x0
     75c:      	movi.2d	v18, #0000000000000000
     760:      	movi.2d	v17, #0000000000000000
     764:      	tbz	w1, #0x0, 0x59c <ltmp0+0x59c>
     768:      	ldr	s18, [x0]
     76c:      	and	w1, w1, #0xff
     770:      	tbz	w1, #0x1, 0x5a4 <ltmp0+0x5a4>
     774:      	add	x2, x0, #0x4
     778:      	ld1.s	{ v18 }[1], [x2]
     77c:      	tbz	w1, #0x2, 0x5a8 <ltmp0+0x5a8>
     780:      	add	x2, x0, #0x8
     784:      	ld1.s	{ v18 }[2], [x2]
     788:      	tbz	w1, #0x3, 0x5ac <ltmp0+0x5ac>
     78c:      	add	x2, x0, #0xc
     790:      	ld1.s	{ v18 }[3], [x2]
     794:      	tbz	w1, #0x4, 0x5b0 <ltmp0+0x5b0>
     798:      	add	x2, x0, #0x10
     79c:      	ld1.s	{ v17 }[0], [x2]
     7a0:      	tbz	w1, #0x5, 0x5b4 <ltmp0+0x5b4>
     7a4:      	add	x2, x0, #0x14
     7a8:      	ld1.s	{ v17 }[1], [x2]
     7ac:      	tbz	w1, #0x6, 0x5b8 <ltmp0+0x5b8>
     7b0:      	add	x2, x0, #0x18
     7b4:      	ld1.s	{ v17 }[2], [x2]
     7b8:      	tbz	w1, #0x7, 0x5bc <ltmp0+0x5bc>
     7bc:      	add	x0, x0, #0x1c
     7c0:      	ld1.s	{ v17 }[3], [x0]
     7c4:      	fmov	w0, s2
     7c8:      	fmul.4s	v19, v4, v16
     7cc:      	fmul.4s	v20, v6, v18
     7d0:      	fsub.4s	v19, v19, v20
     7d4:      	add	x16, x8, x16
     7d8:      	tbz	w0, #0x0, 0x5d4 <ltmp0+0x5d4>
     7dc:      	str	s19, [x16]
     7e0:      	and	w0, w0, #0xff
     7e4:      	tbz	w0, #0x1, 0x5dc <ltmp0+0x5dc>
     7e8:      	add	x1, x16, #0x4
     7ec:      	st1.s	{ v19 }[1], [x1]
     7f0:      	tbz	w0, #0x2, 0x5e0 <ltmp0+0x5e0>
     7f4:      	add	x1, x16, #0x8
     7f8:      	st1.s	{ v19 }[2], [x1]
     7fc:      	tbz	w0, #0x3, 0x5e4 <ltmp0+0x5e4>
     800:      	add	x1, x16, #0xc
     804:      	st1.s	{ v19 }[3], [x1]
     808:      	fmul.4s	v19, v3, v7
     80c:      	fmul.4s	v20, v5, v17
     810:      	fsub.4s	v19, v19, v20
     814:      	tbz	w0, #0x4, 0x5f4 <ltmp0+0x5f4>
     818:      	str	s19, [x16, #0x10]
     81c:      	tbz	w0, #0x5, 0x5f8 <ltmp0+0x5f8>
     820:      	add	x1, x16, #0x14
     824:      	st1.s	{ v19 }[1], [x1]
     828:      	tbz	w0, #0x6, 0x5fc <ltmp0+0x5fc>
     82c:      	add	x1, x16, #0x18
     830:      	st1.s	{ v19 }[2], [x1]
     834:      	tbz	w0, #0x7, 0x600 <ltmp0+0x600>
     838:      	add	x16, x16, #0x1c
     83c:      	st1.s	{ v19 }[3], [x16]
     840:      	fmov	w0, s2
     844:      	fmul.4s	v4, v4, v18
     848:      	fmul.4s	v6, v6, v16
     84c:      	fadd.4s	v4, v6, v4
     850:      	add	x16, x8, x17
     854:      	tbz	w0, #0x0, 0x618 <ltmp0+0x618>
     858:      	str	s4, [x16]
     85c:      	and	w17, w0, #0xff
     860:      	tbz	w17, #0x1, 0x620 <ltmp0+0x620>
     864:      	add	x0, x16, #0x4
     868:      	st1.s	{ v4 }[1], [x0]
     86c:      	tbz	w17, #0x2, 0x624 <ltmp0+0x624>
     870:      	add	x0, x16, #0x8
     874:      	st1.s	{ v4 }[2], [x0]
     878:      	tbz	w17, #0x3, 0x628 <ltmp0+0x628>
     87c:      	add	x0, x16, #0xc
     880:      	st1.s	{ v4 }[3], [x0]
     884:      	fmul.4s	v3, v3, v17
     888:      	fmul.4s	v4, v5, v7
     88c:      	fadd.4s	v3, v4, v3
     890:      	tbz	w17, #0x4, 0x638 <ltmp0+0x638>
     894:      	str	s3, [x16, #0x10]
     898:      	tbz	w17, #0x5, 0x63c <ltmp0+0x63c>
     89c:      	add	x0, x16, #0x14
     8a0:      	st1.s	{ v3 }[1], [x0]
     8a4:      	tbz	w17, #0x6, 0x640 <ltmp0+0x640>
     8a8:      	add	x0, x16, #0x18
     8ac:      	st1.s	{ v3 }[2], [x0]
     8b0:      	tbz	w17, #0x7, 0x4ac <ltmp0+0x4ac>
     8b4:      	add	x16, x16, #0x1c
     8b8:      	st1.s	{ v3 }[3], [x16]
     8bc:      	b	0x4ac <ltmp0+0x4ac>
     8c0:      	mov	w25, #0x0               ; =0
     8c4:      	ldr	x8, [sp, #0x48]
     8c8:      	ldr	x20, [x8]
     8cc:      	ldr	x23, [x8, #0x10]
     8d0:      	ldr	x21, [x8, #0x20]
     8d4:      	ldr	x26, [x8, #0x30]
     8d8:      	subs	x8, x20, x26
     8dc:      	mov	w11, #0xbff             ; =3071
     8e0:      	movk	w11, #0x6, lsl #16
     8e4:      	ccmp	x8, x11, #0x0, hs
     8e8:      	cset	w8, hi
     8ec:      	subs	x9, x26, x20
     8f0:      	ccmp	x9, x11, #0x0, hs
     8f4:      	csinc	w8, w8, wzr, ls
     8f8:      	subs	x9, x23, x26
     8fc:      	ccmp	x9, x11, #0x0, hs
     900:      	cset	w9, hi
     904:      	subs	x10, x26, x23
     908:      	mov	w12, #0x5ff             ; =1535
     90c:      	movk	w12, #0x3, lsl #16
     910:      	ccmp	x10, x12, #0x0, hs
     914:      	csinc	w9, w9, wzr, ls
     918:      	and	w8, w8, w9
     91c:      	subs	x9, x21, x26
     920:      	ccmp	x9, x11, #0x0, hs
     924:      	cset	w9, hi
     928:      	subs	x10, x26, x21
     92c:      	ccmp	x10, x12, #0x0, hs
     930:      	csinc	w9, w9, wzr, ls
     934:      	and	w16, w9, w8
     938:      	ldr	x8, [sp, #0x78]
     93c:      	lsl	w17, w8, #2
     940:      	add	x9, x26, #0x600
     944:      	add	x8, x20, #0x600
     948:      	stp	x8, x9, [sp, #0x98]
     94c:      	str	x15, [sp, #0xb8]
     950:      	str	w16, [sp, #0xb4]
     954:      	str	w17, [sp, #0xa8]
     958:      	b	0x968 <ltmp0+0x968>
     95c:      	add	w25, w25, #0x1
     960:      	cmp	w25, w15
     964:      	b.eq	0x3ac <ltmp0+0x3ac>
     968:      	add	w8, w25, w17
     96c:      	and	w8, w8, #0x1fffffff
     970:      	dup.2s	v0, w8
     974:      	ushll.2d	v1, v0, #0x0
     978:      	tbz	w16, #0x0, 0xa28 <ltmp0+0xa28>
     97c:      	mov	x8, #0x0                ; =0
     980:      	xtn.2s	v0, v1
     984:      	umull.2d	v0, v0, v8
     988:      	fmov	x10, d0
     98c:      	fmov	x9, d1
     990:      	add	x9, x9, x9, lsl #1
     994:      	lsl	x9, x9, #7
     998:      	lsl	x11, x10, #2
     99c:      	ldp	x12, x10, [sp, #0x98]
     9a0:      	add	x10, x10, x11
     9a4:      	add	x11, x12, x11
     9a8:      	fmov	d1, x8
     9ac:      	add.2d	v1, v1, v0
     9b0:      	fmov	x12, d1
     9b4:      	lsl	x12, x12, #2
     9b8:      	add	x13, x20, x12
     9bc:      	ldp	q1, q2, [x13]
     9c0:      	ldp	q3, q4, [x11], #0x20
     9c4:      	add	x13, x8, x9
     9c8:      	lsl	x13, x13, #2
     9cc:      	add	x14, x23, x13
     9d0:      	ldp	q5, q6, [x14]
     9d4:      	add	x13, x21, x13
     9d8:      	ldp	q7, q16, [x13]
     9dc:      	fmul.4s	v17, v2, v6
     9e0:      	fmul.4s	v18, v1, v5
     9e4:      	fmul.4s	v19, v4, v16
     9e8:      	fmul.4s	v20, v3, v7
     9ec:      	fsub.4s	v18, v18, v20
     9f0:      	fsub.4s	v17, v17, v19
     9f4:      	add	x12, x26, x12
     9f8:      	stp	q18, q17, [x12]
     9fc:      	fmul.4s	v2, v2, v16
     a00:      	fmul.4s	v1, v1, v7
     a04:      	fmul.4s	v4, v4, v6
     a08:      	fmul.4s	v3, v3, v5
     a0c:      	fadd.4s	v1, v3, v1
     a10:      	fadd.4s	v2, v4, v2
     a14:      	stp	q1, q2, [x10], #0x20
     a18:      	add	x8, x8, #0x8
     a1c:      	cmp	x8, #0x180
     a20:      	b.ne	0x9a8 <ltmp0+0x9a8>
     a24:      	b	0x95c <ltmp0+0x95c>
     a28:      	fmov	x8, d1
     a2c:      	add	x19, x8, x8, lsl #1
     a30:      	lsl	x28, x19, #10
     a34:      	add	x22, x20, x28
     a38:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     a3c:      	add	x0, x0, #0x2d0
     a40:      	mov	x1, x22
     a44:      	mov	w2, #0x600              ; =1536
     a48:      	bl	0xa48 <ltmp0+0xa48>
     a4c:      	add	x0, sp, #0xcd0
     a50:      	add	x1, x22, #0x600
     a54:      	mov	w2, #0x600              ; =1536
     a58:      	bl	0xa58 <ltmp0+0xa58>
     a5c:      	lsl	x19, x19, #9
     a60:      	add	x0, sp, #0x6d0
     a64:      	add	x1, x23, x19
     a68:      	mov	w2, #0x600              ; =1536
     a6c:      	bl	0xa6c <ltmp0+0xa6c>
     a70:      	add	x0, sp, #0xd0
     a74:      	add	x1, x21, x19
     a78:      	mov	w2, #0x600              ; =1536
     a7c:      	bl	0xa7c <ltmp0+0xa7c>
     a80:      	add	x4, sp, #0xcd0
     a84:      	mov	x9, #0x0                ; =0
     a88:      	add	x8, x26, x28
     a8c:      	add	x28, sp, #0x1, lsl #12  ; =0x1000
     a90:      	add	x28, x28, #0x2d0
     a94:      	add	x10, x28, x9
     a98:      	ldp	q0, q1, [x10]
     a9c:      	add	x10, x27, x9
     aa0:      	ldp	q2, q3, [x10]
     aa4:      	fmul.4s	v1, v1, v3
     aa8:      	fmul.4s	v0, v0, v2
     aac:      	add	x10, x4, x9
     ab0:      	ldp	q2, q3, [x10]
     ab4:      	add	x10, x24, x9
     ab8:      	ldp	q4, q5, [x10]
     abc:      	fmul.4s	v3, v3, v5
     ac0:      	fmul.4s	v2, v2, v4
     ac4:      	fsub.4s	v0, v0, v2
     ac8:      	fsub.4s	v1, v1, v3
     acc:      	add	x10, x8, x9
     ad0:      	stp	q0, q1, [x10]
     ad4:      	add	x9, x9, #0x20
     ad8:      	cmp	x9, #0x600
     adc:      	b.ne	0xa94 <ltmp0+0xa94>
     ae0:      	mov	x9, #0x0                ; =0
     ae4:      	add	x8, x8, #0x600
     ae8:      	ldr	x15, [sp, #0xb8]
     aec:      	ldr	w16, [sp, #0xb4]
     af0:      	ldr	w17, [sp, #0xa8]
     af4:      	add	x10, x28, x9
     af8:      	ldp	q0, q1, [x10]
     afc:      	add	x10, x24, x9
     b00:      	ldp	q2, q3, [x10]
     b04:      	fmul.4s	v1, v1, v3
     b08:      	fmul.4s	v0, v0, v2
     b0c:      	add	x10, x4, x9
     b10:      	ldp	q2, q3, [x10]
     b14:      	add	x10, x27, x9
     b18:      	ldp	q4, q5, [x10]
     b1c:      	fmul.4s	v3, v3, v5
     b20:      	fmul.4s	v2, v2, v4
     b24:      	fadd.4s	v0, v0, v2
     b28:      	fadd.4s	v1, v1, v3
     b2c:      	add	x10, x8, x9
     b30:      	stp	q0, q1, [x10]
     b34:      	add	x9, x9, #0x20
     b38:      	cmp	x9, #0x600
     b3c:      	b.ne	0xaf4 <ltmp0+0xaf4>
     b40:      	b	0x95c <ltmp0+0x95c>
     b44:      	mov	x14, #0x0               ; =0
     b48:      	fmov	x12, d2
     b4c:      	add	x13, x12, x12, lsl #1
     b50:      	lsl	x12, x13, #10
     b54:      	add	x11, x11, x12
     b58:      	b	0xb7c <ltmp0+0xb7c>
     b5c:      	add	x15, x28, x14
     b60:      	ldp	q6, q7, [x15]
     b64:      	bif.16b	v5, v7, v1
     b68:      	bif.16b	v4, v6, v0
     b6c:      	stp	q4, q5, [x15]
     b70:      	add	x14, x14, #0x20
     b74:      	cmp	x14, #0x600
     b78:      	b.eq	0xc20 <ltmp0+0xc20>
     b7c:      	ldr	q2, [sp, #0x80]
     b80:      	and.16b	v2, v3, v2
     b84:      	addv.8h	h2, v2
     b88:      	fmov	w16, s2
     b8c:      	add	x15, x11, x14
     b90:      	movi.2d	v4, #0000000000000000
     b94:      	movi.2d	v5, #0000000000000000
     b98:      	tbnz	w16, #0x0, 0xbc0 <ltmp0+0xbc0>
     b9c:      	and	w16, w16, #0xff
     ba0:      	tbnz	w16, #0x1, 0xbcc <ltmp0+0xbcc>
     ba4:      	tbnz	w16, #0x2, 0xbd8 <ltmp0+0xbd8>
     ba8:      	tbnz	w16, #0x3, 0xbe4 <ltmp0+0xbe4>
     bac:      	tbnz	w16, #0x4, 0xbf0 <ltmp0+0xbf0>
     bb0:      	tbnz	w16, #0x5, 0xbfc <ltmp0+0xbfc>
     bb4:      	tbnz	w16, #0x6, 0xc08 <ltmp0+0xc08>
     bb8:      	tbz	w16, #0x7, 0xb5c <ltmp0+0xb5c>
     bbc:      	b	0xc14 <ltmp0+0xc14>
     bc0:      	ldr	s4, [x15]
     bc4:      	and	w16, w16, #0xff
     bc8:      	tbz	w16, #0x1, 0xba4 <ltmp0+0xba4>
     bcc:      	add	x17, x15, #0x4
     bd0:      	ld1.s	{ v4 }[1], [x17]
     bd4:      	tbz	w16, #0x2, 0xba8 <ltmp0+0xba8>
     bd8:      	add	x17, x15, #0x8
     bdc:      	ld1.s	{ v4 }[2], [x17]
     be0:      	tbz	w16, #0x3, 0xbac <ltmp0+0xbac>
     be4:      	add	x17, x15, #0xc
     be8:      	ld1.s	{ v4 }[3], [x17]
     bec:      	tbz	w16, #0x4, 0xbb0 <ltmp0+0xbb0>
     bf0:      	add	x17, x15, #0x10
     bf4:      	ld1.s	{ v5 }[0], [x17]
     bf8:      	tbz	w16, #0x5, 0xbb4 <ltmp0+0xbb4>
     bfc:      	add	x17, x15, #0x14
     c00:      	ld1.s	{ v5 }[1], [x17]
     c04:      	tbz	w16, #0x6, 0xbb8 <ltmp0+0xbb8>
     c08:      	add	x17, x15, #0x18
     c0c:      	ld1.s	{ v5 }[2], [x17]
     c10:      	tbz	w16, #0x7, 0xb5c <ltmp0+0xb5c>
     c14:      	add	x15, x15, #0x1c
     c18:      	ld1.s	{ v5 }[3], [x15]
     c1c:      	b	0xb5c <ltmp0+0xb5c>
     c20:      	mov	x14, #0x0               ; =0
     c24:      	add	x11, x11, #0x600
     c28:      	b	0xc4c <ltmp0+0xc4c>
     c2c:      	add	x15, x4, x14
     c30:      	ldp	q5, q6, [x15]
     c34:      	bif.16b	v4, v6, v1
     c38:      	bif.16b	v3, v5, v0
     c3c:      	stp	q3, q4, [x15]
     c40:      	add	x14, x14, #0x20
     c44:      	cmp	x14, #0x600
     c48:      	b.eq	0xce4 <ltmp0+0xce4>
     c4c:      	fmov	w16, s2
     c50:      	add	x15, x11, x14
     c54:      	movi.2d	v3, #0000000000000000
     c58:      	movi.2d	v4, #0000000000000000
     c5c:      	tbnz	w16, #0x0, 0xc84 <ltmp0+0xc84>
     c60:      	and	w16, w16, #0xff
     c64:      	tbnz	w16, #0x1, 0xc90 <ltmp0+0xc90>
     c68:      	tbnz	w16, #0x2, 0xc9c <ltmp0+0xc9c>
     c6c:      	tbnz	w16, #0x3, 0xca8 <ltmp0+0xca8>
     c70:      	tbnz	w16, #0x4, 0xcb4 <ltmp0+0xcb4>
     c74:      	tbnz	w16, #0x5, 0xcc0 <ltmp0+0xcc0>
     c78:      	tbnz	w16, #0x6, 0xccc <ltmp0+0xccc>
     c7c:      	tbz	w16, #0x7, 0xc2c <ltmp0+0xc2c>
     c80:      	b	0xcd8 <ltmp0+0xcd8>
     c84:      	ldr	s3, [x15]
     c88:      	and	w16, w16, #0xff
     c8c:      	tbz	w16, #0x1, 0xc68 <ltmp0+0xc68>
     c90:      	add	x17, x15, #0x4
     c94:      	ld1.s	{ v3 }[1], [x17]
     c98:      	tbz	w16, #0x2, 0xc6c <ltmp0+0xc6c>
     c9c:      	add	x17, x15, #0x8
     ca0:      	ld1.s	{ v3 }[2], [x17]
     ca4:      	tbz	w16, #0x3, 0xc70 <ltmp0+0xc70>
     ca8:      	add	x17, x15, #0xc
     cac:      	ld1.s	{ v3 }[3], [x17]
     cb0:      	tbz	w16, #0x4, 0xc74 <ltmp0+0xc74>
     cb4:      	add	x17, x15, #0x10
     cb8:      	ld1.s	{ v4 }[0], [x17]
     cbc:      	tbz	w16, #0x5, 0xc78 <ltmp0+0xc78>
     cc0:      	add	x17, x15, #0x14
     cc4:      	ld1.s	{ v4 }[1], [x17]
     cc8:      	tbz	w16, #0x6, 0xc7c <ltmp0+0xc7c>
     ccc:      	add	x17, x15, #0x18
     cd0:      	ld1.s	{ v4 }[2], [x17]
     cd4:      	tbz	w16, #0x7, 0xc2c <ltmp0+0xc2c>
     cd8:      	add	x15, x15, #0x1c
     cdc:      	ld1.s	{ v4 }[3], [x15]
     ce0:      	b	0xc2c <ltmp0+0xc2c>
     ce4:      	mov	x14, #0x0               ; =0
     ce8:      	lsl	x11, x13, #9
     cec:      	add	x10, x10, x11
     cf0:      	b	0xd14 <ltmp0+0xd14>
     cf4:      	add	x13, x27, x14
     cf8:      	ldp	q5, q6, [x13]
     cfc:      	bif.16b	v4, v6, v1
     d00:      	bif.16b	v3, v5, v0
     d04:      	stp	q3, q4, [x13]
     d08:      	add	x14, x14, #0x20
     d0c:      	cmp	x14, #0x600
     d10:      	b.eq	0xdac <ltmp0+0xdac>
     d14:      	fmov	w15, s2
     d18:      	add	x13, x10, x14
     d1c:      	movi.2d	v3, #0000000000000000
     d20:      	movi.2d	v4, #0000000000000000
     d24:      	tbnz	w15, #0x0, 0xd4c <ltmp0+0xd4c>
     d28:      	and	w15, w15, #0xff
     d2c:      	tbnz	w15, #0x1, 0xd58 <ltmp0+0xd58>
     d30:      	tbnz	w15, #0x2, 0xd64 <ltmp0+0xd64>
     d34:      	tbnz	w15, #0x3, 0xd70 <ltmp0+0xd70>
     d38:      	tbnz	w15, #0x4, 0xd7c <ltmp0+0xd7c>
     d3c:      	tbnz	w15, #0x5, 0xd88 <ltmp0+0xd88>
     d40:      	tbnz	w15, #0x6, 0xd94 <ltmp0+0xd94>
     d44:      	tbz	w15, #0x7, 0xcf4 <ltmp0+0xcf4>
     d48:      	b	0xda0 <ltmp0+0xda0>
     d4c:      	ldr	s3, [x13]
     d50:      	and	w15, w15, #0xff
     d54:      	tbz	w15, #0x1, 0xd30 <ltmp0+0xd30>
     d58:      	add	x16, x13, #0x4
     d5c:      	ld1.s	{ v3 }[1], [x16]
     d60:      	tbz	w15, #0x2, 0xd34 <ltmp0+0xd34>
     d64:      	add	x16, x13, #0x8
     d68:      	ld1.s	{ v3 }[2], [x16]
     d6c:      	tbz	w15, #0x3, 0xd38 <ltmp0+0xd38>
     d70:      	add	x16, x13, #0xc
     d74:      	ld1.s	{ v3 }[3], [x16]
     d78:      	tbz	w15, #0x4, 0xd3c <ltmp0+0xd3c>
     d7c:      	add	x16, x13, #0x10
     d80:      	ld1.s	{ v4 }[0], [x16]
     d84:      	tbz	w15, #0x5, 0xd40 <ltmp0+0xd40>
     d88:      	add	x16, x13, #0x14
     d8c:      	ld1.s	{ v4 }[1], [x16]
     d90:      	tbz	w15, #0x6, 0xd44 <ltmp0+0xd44>
     d94:      	add	x16, x13, #0x18
     d98:      	ld1.s	{ v4 }[2], [x16]
     d9c:      	tbz	w15, #0x7, 0xcf4 <ltmp0+0xcf4>
     da0:      	add	x13, x13, #0x1c
     da4:      	ld1.s	{ v4 }[3], [x13]
     da8:      	b	0xcf4 <ltmp0+0xcf4>
     dac:      	mov	x10, #0x0               ; =0
     db0:      	add	x9, x9, x11
     db4:      	b	0xdd8 <ltmp0+0xdd8>
     db8:      	add	x11, x24, x10
     dbc:      	ldp	q5, q6, [x11]
     dc0:      	bif.16b	v4, v6, v1
     dc4:      	bif.16b	v3, v5, v0
     dc8:      	stp	q3, q4, [x11]
     dcc:      	add	x10, x10, #0x20
     dd0:      	cmp	x10, #0x600
     dd4:      	b.eq	0xe70 <ltmp0+0xe70>
     dd8:      	fmov	w13, s2
     ddc:      	add	x11, x9, x10
     de0:      	movi.2d	v3, #0000000000000000
     de4:      	movi.2d	v4, #0000000000000000
     de8:      	tbnz	w13, #0x0, 0xe10 <ltmp0+0xe10>
     dec:      	and	w13, w13, #0xff
     df0:      	tbnz	w13, #0x1, 0xe1c <ltmp0+0xe1c>
     df4:      	tbnz	w13, #0x2, 0xe28 <ltmp0+0xe28>
     df8:      	tbnz	w13, #0x3, 0xe34 <ltmp0+0xe34>
     dfc:      	tbnz	w13, #0x4, 0xe40 <ltmp0+0xe40>
     e00:      	tbnz	w13, #0x5, 0xe4c <ltmp0+0xe4c>
     e04:      	tbnz	w13, #0x6, 0xe58 <ltmp0+0xe58>
     e08:      	tbz	w13, #0x7, 0xdb8 <ltmp0+0xdb8>
     e0c:      	b	0xe64 <ltmp0+0xe64>
     e10:      	ldr	s3, [x11]
     e14:      	and	w13, w13, #0xff
     e18:      	tbz	w13, #0x1, 0xdf4 <ltmp0+0xdf4>
     e1c:      	add	x14, x11, #0x4
     e20:      	ld1.s	{ v3 }[1], [x14]
     e24:      	tbz	w13, #0x2, 0xdf8 <ltmp0+0xdf8>
     e28:      	add	x14, x11, #0x8
     e2c:      	ld1.s	{ v3 }[2], [x14]
     e30:      	tbz	w13, #0x3, 0xdfc <ltmp0+0xdfc>
     e34:      	add	x14, x11, #0xc
     e38:      	ld1.s	{ v3 }[3], [x14]
     e3c:      	tbz	w13, #0x4, 0xe00 <ltmp0+0xe00>
     e40:      	add	x14, x11, #0x10
     e44:      	ld1.s	{ v4 }[0], [x14]
     e48:      	tbz	w13, #0x5, 0xe04 <ltmp0+0xe04>
     e4c:      	add	x14, x11, #0x14
     e50:      	ld1.s	{ v4 }[1], [x14]
     e54:      	tbz	w13, #0x6, 0xe08 <ltmp0+0xe08>
     e58:      	add	x14, x11, #0x18
     e5c:      	ld1.s	{ v4 }[2], [x14]
     e60:      	tbz	w13, #0x7, 0xdb8 <ltmp0+0xdb8>
     e64:      	add	x11, x11, #0x1c
     e68:      	ld1.s	{ v4 }[3], [x11]
     e6c:      	b	0xdb8 <ltmp0+0xdb8>
     e70:      	mov	x9, #0x0                ; =0
     e74:      	add	x8, x8, x12
     e78:      	b	0xe88 <ltmp0+0xe88>
     e7c:      	add	x9, x9, #0x20
     e80:      	cmp	x9, #0x600
     e84:      	b.eq	0xf64 <ltmp0+0xf64>
     e88:      	fmov	w11, s2
     e8c:      	add	x10, x28, x9
     e90:      	ldp	q5, q3, [x10]
     e94:      	add	x10, x27, x9
     e98:      	ldp	q6, q4, [x10]
     e9c:      	fmul.4s	v7, v5, v6
     ea0:      	add	x10, x4, x9
     ea4:      	ldp	q16, q5, [x10]
     ea8:      	add	x10, x24, x9
     eac:      	ldp	q17, q6, [x10]
     eb0:      	fmul.4s	v16, v16, v17
     eb4:      	fsub.4s	v7, v7, v16
     eb8:      	and.16b	v7, v0, v7
     ebc:      	add	x10, x8, x9
     ec0:      	tbnz	w11, #0x0, 0xef8 <ltmp0+0xef8>
     ec4:      	and	w11, w11, #0xff
     ec8:      	tbnz	w11, #0x1, 0xf04 <ltmp0+0xf04>
     ecc:      	tbnz	w11, #0x2, 0xf10 <ltmp0+0xf10>
     ed0:      	tbnz	w11, #0x3, 0xf1c <ltmp0+0xf1c>
     ed4:      	fmul.4s	v3, v3, v4
     ed8:      	fmul.4s	v4, v5, v6
     edc:      	fsub.4s	v3, v3, v4
     ee0:      	and.16b	v3, v1, v3
     ee4:      	tbnz	w11, #0x4, 0xf38 <ltmp0+0xf38>
     ee8:      	tbnz	w11, #0x5, 0xf40 <ltmp0+0xf40>
     eec:      	tbnz	w11, #0x6, 0xf4c <ltmp0+0xf4c>
     ef0:      	tbz	w11, #0x7, 0xe7c <ltmp0+0xe7c>
     ef4:      	b	0xf58 <ltmp0+0xf58>
     ef8:      	str	s7, [x10]
     efc:      	and	w11, w11, #0xff
     f00:      	tbz	w11, #0x1, 0xecc <ltmp0+0xecc>
     f04:      	add	x12, x10, #0x4
     f08:      	st1.s	{ v7 }[1], [x12]
     f0c:      	tbz	w11, #0x2, 0xed0 <ltmp0+0xed0>
     f10:      	add	x12, x10, #0x8
     f14:      	st1.s	{ v7 }[2], [x12]
     f18:      	tbz	w11, #0x3, 0xed4 <ltmp0+0xed4>
     f1c:      	add	x12, x10, #0xc
     f20:      	st1.s	{ v7 }[3], [x12]
     f24:      	fmul.4s	v3, v3, v4
     f28:      	fmul.4s	v4, v5, v6
     f2c:      	fsub.4s	v3, v3, v4
     f30:      	and.16b	v3, v1, v3
     f34:      	tbz	w11, #0x4, 0xee8 <ltmp0+0xee8>
     f38:      	str	s3, [x10, #0x10]
     f3c:      	tbz	w11, #0x5, 0xeec <ltmp0+0xeec>
     f40:      	add	x12, x10, #0x14
     f44:      	st1.s	{ v3 }[1], [x12]
     f48:      	tbz	w11, #0x6, 0xef0 <ltmp0+0xef0>
     f4c:      	add	x12, x10, #0x18
     f50:      	st1.s	{ v3 }[2], [x12]
     f54:      	tbz	w11, #0x7, 0xe7c <ltmp0+0xe7c>
     f58:      	add	x10, x10, #0x1c
     f5c:      	st1.s	{ v3 }[3], [x10]
     f60:      	b	0xe7c <ltmp0+0xe7c>
     f64:      	mov	x9, #0x0                ; =0
     f68:      	add	x8, x8, #0x600
     f6c:      	b	0xf7c <ltmp0+0xf7c>
     f70:      	add	x9, x9, #0x20
     f74:      	cmp	x9, #0x600
     f78:      	b.eq	0x98 <ltmp0+0x98>
     f7c:      	fmov	w11, s2
     f80:      	add	x10, x28, x9
     f84:      	ldp	q5, q3, [x10]
     f88:      	add	x10, x24, x9
     f8c:      	ldp	q6, q4, [x10]
     f90:      	fmul.4s	v7, v5, v6
     f94:      	add	x10, x4, x9
     f98:      	ldp	q16, q5, [x10]
     f9c:      	add	x10, x27, x9
     fa0:      	ldp	q17, q6, [x10]
     fa4:      	fmul.4s	v16, v16, v17
     fa8:      	fadd.4s	v7, v7, v16
     fac:      	and.16b	v7, v0, v7
     fb0:      	add	x10, x8, x9
     fb4:      	tbnz	w11, #0x0, 0xfec <ltmp0+0xfec>
     fb8:      	and	w11, w11, #0xff
     fbc:      	tbnz	w11, #0x1, 0xff8 <ltmp0+0xff8>
     fc0:      	tbnz	w11, #0x2, 0x1004 <ltmp0+0x1004>
     fc4:      	tbnz	w11, #0x3, 0x1010 <ltmp0+0x1010>
     fc8:      	fmul.4s	v3, v3, v4
     fcc:      	fmul.4s	v4, v5, v6
     fd0:      	fadd.4s	v3, v3, v4
     fd4:      	and.16b	v3, v1, v3
     fd8:      	tbnz	w11, #0x4, 0x102c <ltmp0+0x102c>
     fdc:      	tbnz	w11, #0x5, 0x1034 <ltmp0+0x1034>
     fe0:      	tbnz	w11, #0x6, 0x1040 <ltmp0+0x1040>
     fe4:      	tbz	w11, #0x7, 0xf70 <ltmp0+0xf70>
     fe8:      	b	0x104c <ltmp0+0x104c>
     fec:      	str	s7, [x10]
     ff0:      	and	w11, w11, #0xff
     ff4:      	tbz	w11, #0x1, 0xfc0 <ltmp0+0xfc0>
     ff8:      	add	x12, x10, #0x4
     ffc:      	st1.s	{ v7 }[1], [x12]
    1000:      	tbz	w11, #0x2, 0xfc4 <ltmp0+0xfc4>
    1004:      	add	x12, x10, #0x8
    1008:      	st1.s	{ v7 }[2], [x12]
    100c:      	tbz	w11, #0x3, 0xfc8 <ltmp0+0xfc8>
    1010:      	add	x12, x10, #0xc
    1014:      	st1.s	{ v7 }[3], [x12]
    1018:      	fmul.4s	v3, v3, v4
    101c:      	fmul.4s	v4, v5, v6
    1020:      	fadd.4s	v3, v3, v4
    1024:      	and.16b	v3, v1, v3
    1028:      	tbz	w11, #0x4, 0xfdc <ltmp0+0xfdc>
    102c:      	str	s3, [x10, #0x10]
    1030:      	tbz	w11, #0x5, 0xfe0 <ltmp0+0xfe0>
    1034:      	add	x12, x10, #0x14
    1038:      	st1.s	{ v3 }[1], [x12]
    103c:      	tbz	w11, #0x6, 0xfe4 <ltmp0+0xfe4>
    1040:      	add	x12, x10, #0x18
    1044:      	st1.s	{ v3 }[2], [x12]
    1048:      	tbz	w11, #0x7, 0xf70 <ltmp0+0xf70>
    104c:      	add	x10, x10, #0x1c
    1050:      	st1.s	{ v3 }[3], [x10]
    1054:      	b	0xf70 <ltmp0+0xf70>
    1058:      	ldr	x9, [sp, #0x8]
    105c:      	stp	w15, w14, [x9]
    1060:      	str	w13, [x9, #0x8]
    1064:      	mov	w8, #0x18               ; =24
    1068:      	str	w8, [x9, #0x24]
    106c:      	add	sp, sp, #0x1, lsl #12   ; =0x1000
    1070:      	add	sp, sp, #0x8d0
    1074:      	ldp	x29, x30, [sp, #0x60]
    1078:      	ldp	x20, x19, [sp, #0x50]
    107c:      	ldp	x22, x21, [sp, #0x40]
    1080:      	ldp	x24, x23, [sp, #0x30]
    1084:      	ldp	x26, x25, [sp, #0x20]
    1088:      	ldp	x28, x27, [sp, #0x10]
    108c:      	ldp	d9, d8, [sp], #0x70
    1090:      	ret

"""Pinned full11 + two-file bool/i8 candidate; never invoke the old freeze.

self-check is read-only with respect to ROOT/SELECTED/BUILD/parent RAW.
freeze, build, diagnostic, and test require separate explicit invocations.
All new metadata uses exclusive creation; no automatic retries or rollback.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
CANDIDATE_PATHS = {
    'src/backends/simd/llvm/llvm_schedule_emitter_memory.cpp',
    'src/tests/unit/simd/test_llvm_schedule_codegen.cpp',
}
FREEZE = HERE / 'source-freeze-byte-private.json'


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def relative_path(name):
    path = Path(name)
    need(name and not path.is_absolute() and '..' not in path.parts and str(path) == name,
         'invalid explicit relative path: ' + name)
    return path


def source_path(tree, name):
    path = tree / relative_path(name)
    need(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(tree.resolve()),
         'source must be a regular in-tree file: ' + str(path))
    return path


def source_hashes(tree, names):
    return {name: sha(source_path(tree, name)) for name in names}


def contract():
    plan = read(HERE / 'plan.json')
    parent = Path(plan['parent_raw'])
    for name, digest in plan['parent_pins'].items():
        need(sha(parent / relative_path(name)) == digest, 'parent receipt drift: ' + name)
    old_freeze = read(parent / plan['baseline_freeze'])
    old_names = read(parent / 'owned.json')
    names = read(HERE / 'owned.json')
    need(len(old_names) == 26 and len(set(old_names)) == 26, 'baseline must own exactly 26 files')
    need(set(old_freeze['source_sha256']) == set(old_names), 'baseline freeze/owned mismatch')
    need(old_freeze['owned_sha256'] == plan['parent_pins']['owned.json'] and
         old_freeze['toolchain_sha256'] == plan['parent_pins']['toolchain.json'] and
         old_freeze['baseline_clone_sha256'] == plan['parent_pins']['source-clone.json'], 'baseline metadata mismatch')
    need(set(plan['candidate']) == CANDIDATE_PATHS, 'candidate must contain exactly the two approved paths')
    need(len(names) == 27 and len(set(names)) == 27 and
         set(names) == set(old_names) | CANDIDATE_PATHS, 'new owned list must add only memory.cpp')
    for name in names:
        relative_path(name)
    baseline = dict(old_freeze['source_sha256'])
    for name, entry in plan['candidate'].items():
        need(name not in baseline or baseline[name] == entry['baseline_sha256'], 'candidate baseline mismatch: ' + name)
        baseline[name] = entry['baseline_sha256']
    expected = dict(baseline)
    expected.update({name: entry['candidate_sha256'] for name, entry in plan['candidate'].items()})
    selected = Path(plan['selected'])
    build = Path(plan['build'])
    need(str(selected) == old_freeze['selected_source'] and build == selected.parent / 'build', 'selected/build path mismatch')
    build_command = ['/opt/homebrew/bin/cmake', '--build', str(build), '-j', '6']
    for name in ('build-full-11', 'test-full11-unit-simd', 'test-full11-tile-simd', 'test-full11-host-plan'):
        receipt = read(parent / name / 'result.json')
        need(receipt['status'] == 'passed' and receipt['exit_code'] == 0 and
             receipt['source_freeze_sha256'] == plan['parent_pins'][plan['baseline_freeze']] and
             receipt['source_sha256'] == old_freeze['source_sha256'] and
             receipt['harness_sha256'] == plan['parent_pins']['run.py'] and
             receipt['owned_sha256'] == plan['parent_pins']['owned.json'] and
             receipt['toolchain_sha256'] == plan['parent_pins']['toolchain.json'], 'invalid full11 gate: ' + name)
        if name == 'build-full-11':
            need(receipt['command'] == build_command, 'baseline was not the required complete build')
    identity = dict(runner_sha256=sha(__file__), plan_sha256=sha(HERE / 'plan.json'),
                    owned_sha256=sha(HERE / 'owned.json'),
                    original_harness=str(parent / 'run.py'), original_harness_sha256=plan['parent_pins']['run.py'],
                    parent_pins=plan['parent_pins'], toolchain_sha256=plan['parent_pins']['toolchain.json'])
    return plan, names, baseline, expected, identity, build_command


def check_baseline():
    data = contract()
    plan, names, baseline, expected, identity, command = data
    need(source_hashes(Path(plan['selected']), names) == baseline, 'SELECTED no longer matches full11 + explicit memory baseline')
    candidate = {name: expected[name] for name in CANDIDATE_PATHS}
    need(source_hashes(Path(plan['root']), sorted(CANDIDATE_PATHS)) == candidate, 'ROOT candidate hashes differ from approved pair')
    return data


def check_frozen():
    data = contract()
    plan, names, baseline, expected, identity, command = data
    frozen = read(FREEZE)
    need(frozen['identity'] == identity and frozen['source_sha256'] == expected and
         frozen['baseline_source_sha256'] == baseline and frozen['overlaid_files'] == sorted(CANDIDATE_PATHS),
         'explicit candidate freeze does not match this runner/ledger/plan')
    need(source_hashes(Path(plan['selected']), names) == expected, 'candidate SELECTED drift')
    need(source_hashes(HERE / 'frozen-source', names) == expected, 'immutable candidate overlay drift')
    return data, frozen


def copy_exact(source, destination, digest):
    need(sha(source) == digest, 'copy source drift: ' + str(source))
    destination.parent.mkdir(parents=True, exist_ok=True)
    with Path(source).open('rb') as src, destination.open('xb') as dst:
        shutil.copyfileobj(src, dst)
    need(sha(source) == sha(destination) == digest, 'copy changed: ' + str(source))


def self_check():
    plan, names, baseline, expected, identity, command = check_baseline()
    result = dict(status='passed', finished=time.time(), identity=identity,
                  baseline_source_sha256=baseline,
                  candidate_sha256={name: expected[name] for name in sorted(CANDIDATE_PATHS)},
                  inherited_file_count=25, selected_writes=0, build_executed=False, native_executed=False,
                  scope=plan['boundary'])
    save(HERE / 'self-check.json', result)
    print(json.dumps(dict(status='passed', receipt=str(HERE / 'self-check.json'),
                         receipt_sha256=sha(HERE / 'self-check.json'), selected_writes=0)), flush=True)


def freeze():
    need(not FREEZE.exists(), 'candidate freeze already exists; do not retry or overwrite')
    plan, names, baseline, expected, identity, command = check_baseline()
    need(read(HERE / 'self-check.json')['identity'] == identity, 'runner/plan/owned changed since reviewed self-check')
    selected = Path(plan['selected'])
    root = Path(plan['root'])
    # First retain both pre-overlay files and exact ROOT candidate bytes.
    # Never reread arbitrary ROOT owned files or call the old freeze().
    for name in sorted(CANDIDATE_PATHS):
        copy_exact(source_path(selected, name), HERE / 'baseline-source' / name, baseline[name])
        copy_exact(source_path(root, name), HERE / 'candidate-source' / name, expected[name])
    check_baseline()
    for name in sorted(CANDIDATE_PATHS):
        target = source_path(selected, name)
        descriptor, temporary_name = tempfile.mkstemp(prefix='.byte-private-overlay-', dir=target.parent)
        os.close(descriptor)
        temporary = Path(temporary_name)
        try:
            shutil.copy2(HERE / 'candidate-source' / name, temporary)
            need(sha(temporary) == expected[name], 'staged candidate hash mismatch')
            os.replace(temporary, target)
        finally:
            if temporary.exists():
                temporary.unlink()
    need(source_hashes(selected, names) == expected, 'selected overlay or inherited source drift; stop before build')
    need(source_hashes(root, sorted(CANDIDATE_PATHS)) == {n: expected[n] for n in CANDIDATE_PATHS}, 'ROOT changed during freeze')
    for name in names:
        copy_exact(source_path(selected, name), HERE / 'frozen-source' / name, expected[name])
    need(contract()[4] == identity and source_hashes(selected, names) == expected, 'freeze identity drift')
    save(FREEZE, dict(status='passed', finished=time.time(), tag='full11-plus-byte-private', identity=identity,
                      selected_source=str(selected), baseline_source_sha256=baseline, source_sha256=expected,
                      overlaid_files=sorted(CANDIDATE_PATHS),
                      inherited_files=[name for name in names if name not in CANDIDATE_PATHS],
                      scope=plan['boundary']))
    check_frozen()
    print(json.dumps(dict(status='passed', receipt=str(FREEZE), receipt_sha256=sha(FREEZE),
                         overlaid_files=sorted(CANDIDATE_PATHS))), flush=True)


def run(name, command, timeout, kind):
    need(name and all(c.isalnum() or c in '-_' for c in name), 'command name must be a fresh simple identifier')
    data, frozen = check_frozen()
    plan, names, baseline, expected, identity, build_command = data
    pinned_freeze = sha(FREEZE)
    if kind == 'test':
        full_builds = [read(path) for path in HERE.glob('build-*/result.json')]
        need(any(row.get('status') == 'passed' and row.get('exit_code') == 0 and
                 row.get('kind') == 'build' and row.get('command') == build_command and
                 row.get('identity') == identity and row.get('source_freeze_sha256') == pinned_freeze and
                 row.get('source_sha256') == expected and
                 frozen['finished'] <= row['started'] <= row['finished'] <= time.time()
                 for row in full_builds), 'test requires a new successful complete build of this exact freeze')
    folder = HERE / name
    folder.mkdir()
    env = {key: value for key, value in os.environ.items() if not key.startswith(('LUISA_', 'MTL_', 'DYLD_'))}
    env.update(OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1', PYTORCH_ENABLE_MPS_FALLBACK='0')
    receipt = dict(command=command, cwd=plan['selected'], started=time.time(), timeout_seconds=timeout,
                   kind=kind, native=kind == 'test', identity=identity,
                   source_freeze_receipt=str(FREEZE), source_freeze_sha256=pinned_freeze,
                   source_sha256=expected,
                   environment={key: value for key, value in env.items()
                                if key.startswith(('LUISA_', 'MTL_', 'DYLD_', 'OMP_', 'VECLIB_', 'PYTORCH_'))})
    save(folder / 'command.json', receipt)
    process = None
    error = None
    try:
        with (folder / 'stdout.txt').open('xb') as stdout, (folder / 'stderr.txt').open('xb') as stderr:
            process = subprocess.Popen(command, cwd=plan['selected'], env=env, stdout=stdout, stderr=stderr,
                                       start_new_session=True)
            try:
                process.wait(timeout=timeout)
            except BaseException:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait()
                raise
        need(process.returncode == 0, 'command exited ' + str(process.returncode))
        receipt['status'] = 'passed'
    except BaseException as caught:
        error = caught
        receipt.update(status='failed', error=f'{type(caught).__name__}: {caught}',
                       timed_out=isinstance(caught, subprocess.TimeoutExpired))
    finally:
        try:
            after, after_freeze = check_frozen()
            need(after[4] == identity and after_freeze == frozen and sha(FREEZE) == pinned_freeze,
                 'the exact starting freeze changed while the command ran')
            receipt['source_unchanged'] = True
        except BaseException as caught:
            error = caught
            receipt.update(status='failed', source_unchanged=False, source_error=f'{type(caught).__name__}: {caught}')
        receipt.update(finished=time.time(), exit_code=process.returncode if process is not None else None,
                       child_exited=process is not None and process.poll() is not None)
        for channel in ('stdout', 'stderr'):
            path = folder / f'{channel}.txt'
            if path.exists():
                receipt[channel + '_sha256'] = sha(path)
        save(folder / 'result.json', receipt)
        print(json.dumps(dict(status=receipt['status'], exit_code=receipt['exit_code'],
                             result=str(folder / 'result.json'), result_sha256=sha(folder / 'result.json'))), flush=True)
    if error is not None:
        raise SystemExit(1)


def main():
    need(len(sys.argv) >= 2, 'expected self-check, freeze, build, diagnostic, or test')
    mode = sys.argv[1]
    if mode == 'self-check':
        need(len(sys.argv) == 2, 'self-check takes no arguments')
        self_check()
    elif mode == 'freeze':
        need(len(sys.argv) == 2, 'freeze takes no arguments')
        freeze()
    elif mode == 'build':
        need(len(sys.argv) == 3, 'build requires a fresh label')
        run('build-' + sys.argv[2], contract()[5], 1800, 'build')
    elif mode in ('diagnostic', 'test'):
        need(len(sys.argv) >= 4, mode + ' requires a fresh label and exact command')
        run(sys.argv[2], sys.argv[3:], 600, mode)
    else:
        raise ValueError('unsupported mode: ' + mode)


if __name__ == '__main__':
    main()

"""Fresh program-team preparation and explicit build/test receipts.

Only `clone` and `configure --pre-freeze` are authorized during preparation.
Root must finalize owned.json and producer sources before `freeze <tag>` and
a full `build`. Previous source/build/raw trees are read-only inputs.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path('/Users/mike/CLionProjects/luisa')
OUT = Path(__file__).resolve().parent
PREVIOUS_RAW = Path('/tmp/luisa-metal-short-reduce.JdDz9f')
PREVIOUS = Path('/Users/mike/.cache/luisa-tile/metal-short-reduce.rq8Wsn/source')
SELECTED = Path('/Users/mike/.cache/luisa-tile/metal-program-team.xIQgCS/source')
BUILD = SELECTED.parent / 'build'


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def owned():
    paths = json.loads((OUT / 'owned.json').read_text())
    if not paths or len(paths) != len(set(paths)) or any(Path(p).is_absolute() or '..' in Path(p).parts for p in paths):
        raise ValueError('owned.json must contain unique explicit repository-relative paths')
    return paths


def current_sources():
    return {p: digest(SELECTED / p) for p in owned()}


def check_freeze():
    actual = current_sources()
    matches = []
    for path in OUT.glob('source-freeze-*.json'):
        frozen = json.loads(path.read_text())
        if frozen['owned_sha256'] == digest(OUT / 'owned.json') and frozen['source_sha256'] == actual:
            frozen.update(receipt=str(path), receipt_sha256=digest(path))
            matches.append(frozen)
    if not matches:
        raise ValueError('selected source/owned list does not match any immutable freeze')
    return max(matches, key=lambda frozen: frozen['finished'])


def run(name, command, timeout=1800, native=False, require_freeze=True):
    frozen = check_freeze() if require_freeze else None
    folder = OUT / name
    folder.mkdir()
    env = {key: value for key, value in os.environ.items() if not key.startswith(('LUISA_', 'MTL_', 'DYLD_'))}
    env.update(OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1', PYTORCH_ENABLE_MPS_FALLBACK='0')
    receipt = dict(command=command, cwd=str(SELECTED if SELECTED.exists() else SELECTED.parent),
                   started=time.time(), timeout_seconds=timeout, native=native,
                   harness_sha256=digest(__file__), owned_sha256=digest(OUT / 'owned.json'),
                   source_sha256=frozen['source_sha256'] if frozen else None,
                   source_freeze_receipt=frozen['receipt'] if frozen else None,
                   source_freeze_sha256=frozen['receipt_sha256'] if frozen else None,
                   toolchain_sha256=digest(OUT / 'toolchain.json') if (OUT / 'toolchain.json').exists() else None,
                   environment={key: value for key, value in env.items()
                                if key.startswith(('LUISA_', 'MTL_', 'DYLD_', 'OMP_', 'VECLIB_', 'PYTORCH_'))})
    save(folder / 'command.json', receipt)
    process = None
    error = None
    try:
        with (folder / 'stdout.txt').open('xb') as stdout, (folder / 'stderr.txt').open('xb') as stderr:
            process = subprocess.Popen(command, cwd=receipt['cwd'], env=env, stdout=stdout, stderr=stderr,
                                       start_new_session=True)
            try:
                process.wait(timeout=timeout)
            except BaseException:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait()
                raise
        if process.returncode != 0:
            raise RuntimeError(f'command exited {process.returncode}')
        if require_freeze:
            check_freeze()
        receipt['status'] = 'passed'
    except BaseException as caught:
        error = caught
        receipt.update(status='failed', error=f'{type(caught).__name__}: {caught}',
                       timed_out=isinstance(caught, subprocess.TimeoutExpired),
                       termination_reason='timeout' if isinstance(caught, subprocess.TimeoutExpired) else type(caught).__name__)
        if native:
            receipt['queue_health'] = 'Unestablished after failure; root inspection is required before more native/GPU work.'
    finally:
        receipt.update(finished=time.time(), exit_code=process.returncode if process is not None else None)
        for channel in ('stdout', 'stderr'):
            path = folder / f'{channel}.txt'
            if path.exists():
                receipt[f'{channel}_sha256'] = digest(path)
        save(folder / 'result.json', receipt)
        print(json.dumps(receipt), flush=True)
    if error is not None:
        raise SystemExit(1)
    return receipt


def clone():
    if SELECTED.exists() or BUILD.exists():
        raise ValueError('clone destination must be fresh; no merge or overwrite')
    identity_path = PREVIOUS_RAW / 'source-namespace-fix.json'
    identity = json.loads(identity_path.read_text())
    expected = identity['overlay_sha256']
    before = {p: digest(PREVIOUS / p) for p in expected}
    if before != expected:
        raise ValueError('previous selected source no longer matches its retained freeze')
    # APFS clone-on-write: the new files are independent, not writable hardlinks
    # into the previous source. No build tree or old benchmark data is copied.
    result = run('clone', ['/bin/cp', '-cRp', str(PREVIOUS), str(SELECTED)], 300, require_freeze=False)
    after = {p: digest(PREVIOUS / p) for p in expected}
    selected = {p: digest(SELECTED / p) for p in expected}
    if before != after or selected != before:
        raise ValueError('previous source changed or explicit baseline overlay clone mismatched')
    save(OUT / 'source-clone.json', dict(previous_source=str(PREVIOUS), selected_source=str(SELECTED),
        previous_source_receipt=str(identity_path), previous_source_receipt_sha256=digest(identity_path),
        previous_source_identity=identity, retained_overlay_sha256=before, previous_source_unchanged=True,
        clone_command_receipt=str(OUT / 'clone/result.json'), clone_finished=result['finished'],
        copied='Source tree only; no previous build outputs, state or performance data.',
        verification='Completed cp -cRp plus exact retained overlay hashes before/after/on-copy. '
                     'External files inherit the previous pinned export provenance; no new all-file hash claim.'))


def freeze(tag):
    if not tag or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for c in tag):
        raise ValueError('freeze tag must be a nonempty simple identifier')
    receipt_path = OUT / f'source-freeze-{tag}.json'
    if not (OUT / 'source-clone.json').is_file() or receipt_path.exists():
        raise ValueError('requires one successful clone and a fresh freeze tag')
    paths = owned()
    for p in paths:
        if not (ROOT / p).is_file():
            raise ValueError(f'missing explicitly owned source: {p}')
    initial = {p: digest(ROOT / p) for p in paths}
    for p in paths:
        target = SELECTED / p
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / p, target)
    if initial != {p: digest(ROOT / p) for p in paths} or initial != current_sources():
        raise ValueError('source changed while freezing; do not build')
    save(receipt_path, dict(finished=time.time(), tag=tag, selected_source=str(SELECTED),
        repository_head=subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip(),
        source_sha256=initial, owned_sha256=digest(OUT / 'owned.json'),
        toolchain_sha256=digest(OUT / 'toolchain.json') if (OUT / 'toolchain.json').exists() else None,
        baseline_clone_sha256=digest(OUT / 'source-clone.json'),
        scope='Only this explicit owned list overlays the previous exact selected source; unrelated root WIP excluded.'))


def toolchain():
    path = OUT / 'toolchain.json'
    if path.exists():
        return json.loads(path.read_text())
    commands = {
        'cmake': [shutil.which('cmake'), '--version'],
        'ninja': [shutil.which('ninja'), '--version'],
        'cc': ['/usr/bin/cc', '--version'],
        'cxx': ['/usr/bin/c++', '--version'],
        'xcode': ['/usr/bin/xcode-select', '-p'],
        'sdk_path': ['/usr/bin/xcrun', '--sdk', 'macosx', '--show-sdk-path'],
        'sdk_version': ['/usr/bin/xcrun', '--sdk', 'macosx', '--show-sdk-version'],
        'clang_path': ['/usr/bin/xcrun', '--sdk', 'macosx', '--find', 'clang'],
        'metal_path': ['/usr/bin/xcrun', '--sdk', 'macosx', '--find', 'metal'],
        'metallib_path': ['/usr/bin/xcrun', '--sdk', 'macosx', '--find', 'metallib'],
        'llvm_version': ['/opt/homebrew/opt/llvm@22/bin/llvm-config', '--version'],
    }
    information = {}
    for key, command in commands.items():
        if not command[0]:
            raise ValueError(f'required tool unavailable: {key}')
        run('tool-' + key, command, 30, require_freeze=False)
        information[key] = dict(command=command, executable_resolved=str(Path(command[0]).resolve()),
                                output=(OUT / ('tool-' + key) / 'stdout.txt').read_text().strip(),
                                receipt=str(OUT / ('tool-' + key) / 'result.json'))
    result = dict(schema_version=1, tools=information, sdk_path=information['sdk_path']['output'],
                  sdk_version=information['sdk_version']['output'],
                  llvm_cmake_dir='/opt/homebrew/opt/llvm@22/lib/cmake/llvm',
                  xcode_developer_directory=information['xcode']['output'],
                  note='Exact path/version receipts; no whole-binary hashing or native kernel execution.')
    save(path, result)
    return result


def main():
    mode = sys.argv[1]
    if mode == 'clone':
        clone()
    elif mode == 'freeze':
        freeze(sys.argv[2])
    elif mode == 'configure':
        pre_freeze = sys.argv[2:] == ['--pre-freeze']
        if pre_freeze and (not (OUT / 'source-clone.json').exists() or list(OUT.glob('source-freeze-*.json'))):
            raise ValueError('pre-freeze configure requires a clone and no source freeze')
        if not pre_freeze:
            check_freeze()
        tools = toolchain()
        old = json.loads((PREVIOUS_RAW / 'configure/result.json').read_text())['command']
        command = [str(SELECTED) if word == str(PREVIOUS) else str(BUILD) if word == str(PREVIOUS.parent / 'build') else word
                   for word in old]
        command[0] = tools['tools']['cmake']['command'][0]
        command.append('-DCMAKE_MAKE_PROGRAM=' + tools['tools']['ninja']['command'][0])
        command.append('-DCMAKE_OSX_SYSROOT=' + tools['sdk_path'])
        command.append('-DLUISA_COMPUTE_TILE_XIR_TEST_TIRX_COMPARISON=OFF')
        run('configure', command, 300, require_freeze=not pre_freeze)
    elif mode == 'build':
        run('build-' + sys.argv[2], [toolchain()['tools']['cmake']['command'][0], '--build', str(BUILD), '-j', '6'], 1800)
    elif mode == 'diagnostic':
        run(sys.argv[2], sys.argv[3:], 600)
    elif mode == 'test':
        frozen = check_freeze()
        expected_build_command = [toolchain()['tools']['cmake']['command'][0], '--build', str(BUILD), '-j', '6']
        completed = []
        for path in OUT.glob('build-*/result.json'):
            receipt = json.loads(path.read_text())
            if (receipt.get('status') == 'passed' and receipt.get('exit_code') == 0
                    and receipt.get('command') == expected_build_command
                    and receipt.get('source_sha256') == frozen['source_sha256']
                    and receipt.get('source_freeze_sha256') == frozen['receipt_sha256']
                    and frozen['finished'] <= receipt['started'] <= receipt['finished'] <= time.time()):
                completed.append(receipt)
        if not completed:
            raise ValueError('test requires a successful complete frozen-source build first')
        run(sys.argv[2], sys.argv[3:], 600, native=True)
    else:
        raise ValueError(mode)


if __name__ == '__main__':
    main()

// Bounded Metal4 Runtime copy-only progress diagnostic; no Tile/SIMT kernel.
// V3 adds one native shared-event signal after the first four uploads. It does
// not submit another command buffer or use Luisa's host-callback event state.

#include <luisa/core/logging.h>
#include <luisa/core/stl/vector.h>
#include <luisa/runtime/buffer.h>
#include <luisa/runtime/context.h>
#include <luisa/runtime/device.h>
#include <luisa/runtime/rhi/device_interface.h>
#include <luisa/runtime/stream.h>
#include <objc/message.h>
#include <objc/runtime.h>
#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <mutex>
#include <thread>

using namespace luisa;
using namespace luisa::compute;

namespace {

constexpr size_t kBuffers = 8u;
constexpr size_t kPadding = 17u;
constexpr size_t kPayload = 119u;
constexpr size_t kElements = kPayload + 2u * kPadding;
using Clock = std::chrono::steady_clock;

[[nodiscard]] uint32_t expected_word(size_t buffer, size_t index) noexcept {
    if (index < kPadding || index >= kPadding + kPayload) {
        return 0x7bad0000u + static_cast<uint32_t>(buffer);
    }
    return ((static_cast<uint32_t>(buffer) + 1u) * 0x1f123bb5u) ^
           (static_cast<uint32_t>(index) * 0x9e3779b9u);
}

void marker(const char *phase, size_t ordinal) noexcept {
    std::printf("COPY_PROBE %s ordinal=%zu\n", phase, ordinal);
    std::fflush(stdout);
}

// These are the exact Objective-C ABI signatures from the current system
// Metal SDK. No metal-cpp implementation symbols or backend rebuild is needed.
template<typename R, typename... Args>
R message(id receiver, SEL selector, Args... args) noexcept {
    return reinterpret_cast<R (*)(id, SEL, Args...)>(objc_msgSend)(receiver, selector, args...);
}

[[nodiscard]] SEL checked_selector(id receiver, const char *name) noexcept {
    LUISA_ASSERT(receiver != nullptr, "Null Objective-C receiver for {}", name);
    auto selector = sel_registerName(name);
    LUISA_ASSERT(class_respondsToSelector(object_getClass(receiver), selector),
                 "Native Metal object does not respond to {}", name);
    return selector;
}

class GpuOnlyObserver {
private:
    id _queue = nullptr;// Borrowed only for signal(), while the Stream lives.
    id _event = nullptr;// newSharedEvent returns an owned reference.
    SEL _signal = nullptr;
    SEL _value = nullptr;
    SEL _release = nullptr;
    std::atomic_bool _signal_enqueued{false};
    std::mutex _mutex;
    std::condition_variable _cv;
    bool _stop = false;
    std::thread _watchdog;

public:
    GpuOnlyObserver() noexcept = default;
    GpuOnlyObserver(const GpuOnlyObserver &) = delete;
    GpuOnlyObserver &operator=(const GpuOnlyObserver &) = delete;
    ~GpuOnlyObserver() noexcept {
        stop();
        // No thread may read the event after its sole owned reference goes.
        if (_event != nullptr) { message<void>(_event, _release); }
    }

    void start(void *native_queue, Clock::time_point begin) noexcept {
        LUISA_ASSERT(_event == nullptr && !_watchdog.joinable(), "Observer already started");
        _queue = static_cast<id>(native_queue);
        _signal = checked_selector(_queue, "signalEvent:value:");
        auto native_device = message<id>(_queue, checked_selector(_queue, "device"));
        marker("gpu_event_create_before", 0u);
        _event = message<id>(native_device, checked_selector(native_device, "newSharedEvent"));
        _value = checked_selector(_event, "signaledValue");
        _release = checked_selector(_event, "release");
        LUISA_ASSERT(message<uint64_t>(_event, _value) == 0u, "Fresh shared event must start at zero");
        marker("gpu_event_create_after", 0u);
        _watchdog = std::thread{[this, begin]() noexcept {
            for (auto deadline : {8u, 20u}) {
                std::unique_lock lock{_mutex};
                if (_cv.wait_until(lock, begin + std::chrono::seconds{deadline},
                                   [this]() noexcept { return _stop; })) {
                    return;
                }
                lock.unlock();
                auto value = message<uint64_t>(_event, _value);
                std::printf("COPY_PROBE gpu_only_observation deadline_seconds=%u signal_enqueued=%u signaled_value=%llu\n",
                            deadline, static_cast<uint32_t>(_signal_enqueued.load(std::memory_order_acquire)),
                            static_cast<unsigned long long>(value));
                std::fflush(stdout);
            }
        }};
    }

    void signal_after_four_uploads() noexcept {
        LUISA_ASSERT(!_signal_enqueued.load(std::memory_order_relaxed), "Shared event already signaled");
        marker("gpu_signal_before", 3u);
        // Direct queue operation, not Luisa Event::signal or another CB.
        message<void>(_queue, _signal, _event, uint64_t{1u});
        _signal_enqueued.store(true, std::memory_order_release);
        marker("gpu_signal_after", 3u);
    }

    void stop() noexcept {
        {
            std::scoped_lock lock{_mutex};
            _stop = true;
        }
        _cv.notify_all();
        if (_watchdog.joinable()) { _watchdog.join(); }
    }

    void finish() noexcept {
        marker("gpu_watchdog_stop_before", 0u);
        stop();
        marker("gpu_watchdog_stop_after", 0u);
        auto value = message<uint64_t>(_event, _value);
        std::printf("COPY_PROBE gpu_only_final signaled_value=%llu\n", static_cast<unsigned long long>(value));
        LUISA_ASSERT(value >= 1u, "GPU-only signal did not complete despite successful stream synchronization");
    }
};

}// namespace

int main(int argc, char *argv[]) {
    auto begin = Clock::now();
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    LUISA_ASSERT(argc == 2, "Usage: {} <frozen-runtime-program-path>", argv[0]);
    std::printf("COPY_PROBE begin buffers=%zu elements=%zu submissions=16 inqueue_buffer_limit=true\n",
                kBuffers, kElements);
    GpuOnlyObserver observer;
    {
        Context context{argv[1]};
        DeviceConfig config{};
        config.inqueue_buffer_limit = true;
        marker("device_create_before", 0u);
        auto device = context.create_device("metal4", &config);
        marker("device_create_after", 0u);
        LUISA_ASSERT(device.backend_name() == "metal4", "Expected the native Metal4 backend");
        marker("stream_create_before", 0u);
        auto stream = device.create_stream(StreamTag::COMPUTE);
        marker("stream_create_after", 0u);
        observer.start(stream.native_handle(), begin);

        std::array<vector<uint32_t>, kBuffers> inputs;
        std::array<vector<uint32_t>, kBuffers> outputs;
        vector<Buffer<uint32_t>> buffers;
        buffers.reserve(kBuffers);
        for (size_t i = 0u; i < kBuffers; i++) {
            inputs[i].resize(kElements);
            outputs[i].resize(kElements, 0xdeadbeefu);
            for (size_t j = 0u; j < kElements; j++) { inputs[i][j] = expected_word(i, j); }
            buffers.emplace_back(device.create_buffer<uint32_t>(kElements));
        }
        for (size_t i = 0u; i < kBuffers; i++) {
            marker("upload_submit_before", i);
            stream << buffers[i].copy_from(span{inputs[i]});
            marker("upload_submit_after", i);
            if (i == 3u) { observer.signal_after_four_uploads(); }
        }
        for (size_t i = 0u; i < kBuffers; i++) {
            marker("download_submit_before", i);
            stream << buffers[i].copy_to(span{outputs[i]});
            marker("download_submit_after", i);
        }
        marker("synchronize_before", 0u);
        stream << synchronize();
        marker("synchronize_after", 0u);
        for (size_t i = 0u; i < kBuffers; i++) {
            for (size_t j = 0u; j < kElements; j++) {
                auto expected = expected_word(i, j);
                LUISA_ASSERT(outputs[i][j] == expected,
                             "Copy output mismatch: buffer={} element={} actual={} expected={}",
                             i, j, outputs[i][j], expected);
                LUISA_ASSERT(inputs[i][j] == expected,
                             "Host input changed: buffer={} element={} actual={} expected={}",
                             i, j, inputs[i][j], expected);
            }
        }
        std::printf("COPY_PROBE checks_passed words=%zu\n", 2u * kBuffers * kElements);
        marker("teardown_before", 0u);
    }
    // Keep the GPU-only observer alive through Runtime destruction as well.
    observer.finish();
    std::printf("COPY_PROBE PASS buffers=8 elements=153 checks=2448 submissions=16\n");
    return 0;
}

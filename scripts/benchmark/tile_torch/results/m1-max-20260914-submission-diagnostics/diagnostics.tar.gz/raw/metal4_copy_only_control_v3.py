"""Root-invoked copy-only control: prepare, build-probe, then explicit native run.

Never compiles or starts a device on import/prepare. No automatic retries.
Selected production sources/libraries are read-only; outputs stay in one new
raw child directory. A stopped process does not establish GPU queue recovery.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import signal
import subprocess
import time

RAW = Path(__file__).resolve().parent
SOURCE = RAW / 'metal4_copy_only_control_v3.cpp'
WORK = RAW / 'metal4-copy-only-control-v3'
FULL_BUILD = RAW / 'build-full-6/result.json'
TIMEOUT = 30.0
SAMPLE_AT = (8.0, 20.0)
SPEC = importlib.util.spec_from_file_location('copy_control_receipts', RAW / 'run.py')
RUN = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUN)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def save(path, payload):
    with path.open('x') as stream:
        json.dump(payload, stream, indent=2, allow_nan=False)
        stream.write('\n')


def load(path):
    return json.loads(path.read_text())


def fingerprints(paths):
    return {str(path): dict(resolved=str(path.resolve(strict=True)), sha256=RUN.digest(path))
            for path in sorted(set(map(Path, paths)))}


def full6_gate():
    frozen = RUN.check_freeze()
    result = load(FULL_BUILD)
    command = load(FULL_BUILD.parent / 'command.json')
    expected = [load(RAW / 'toolchain.json')['tools']['cmake']['command'][0],
                '--build', str(RUN.BUILD), '-j', '6']
    require(result.get('status') == 'passed' and result.get('exit_code') == 0
            and result.get('native') is False and not result.get('timed_out'), 'full6 did not pass')
    require(result.get('command') == command.get('command') == expected, 'not the complete full6 build')
    for key, value in [('source_sha256', frozen['source_sha256']),
                       ('source_freeze_sha256', frozen['receipt_sha256']),
                       ('owned_sha256', RUN.digest(RAW / 'owned.json')),
                       ('harness_sha256', RUN.digest(RAW / 'run.py')),
                       ('toolchain_sha256', RUN.digest(RAW / 'toolchain.json')),
                       ('cwd', str(RUN.SELECTED))]:
        require(result.get(key) == command.get(key) == value, 'full6 mismatch: ' + key)
    require(frozen['finished'] <= result['started'] <= result['finished'] <= time.time(), 'invalid full6 chronology')
    for channel in ('stdout', 'stderr'):
        require(RUN.digest(FULL_BUILD.parent / (channel + '.txt')) == result[channel + '_sha256'], 'full6 log changed')
    return frozen, result


def library_paths():
    # Include plugins (.so), not just dylibs. New/removed library paths are drift.
    return sorted(path for path in (RUN.BUILD / 'bin').iterdir()
                  if path.is_file() and path.suffix in ('.dylib', '.so'))


def closure(paths):
    """Read Mach-O load commands only; never dlopen or execute inspected files."""
    pending, checked, system = list(paths), {}, set()
    while pending:
        path = pending.pop().resolve(strict=True)
        if str(path) in checked:
            continue
        result = subprocess.run(['/usr/bin/otool', '-L', str(path)], capture_output=True, text=True, timeout=5)
        require(result.returncode == 0, 'otool failed: ' + str(path))
        checked[str(path)] = dict(sha256=RUN.digest(path), otool=result.stdout)
        details = subprocess.run(['/usr/bin/otool', '-l', str(path)], capture_output=True, text=True, timeout=5)
        require(details.returncode == 0, 'otool rpath failed: ' + str(path))
        rpaths = re.findall(r'cmd LC_RPATH\n\s*cmdsize \d+\n\s*path (.+?) \(offset', details.stdout)
        self_ids = re.findall(r'cmd LC_ID_DYLIB\n\s*cmdsize \d+\n\s*name (.+?) \(offset', details.stdout)
        require(len(self_ids) <= 1, 'multiple LC_ID_DYLIB commands are unsupported: ' + str(path))
        for index, line in enumerate(result.stdout.splitlines()[1:]):
            name = line.strip().split(' (compatibility version', 1)[0]
            # otool -L prints a dylib's own LC_ID_DYLIB first. Skip exactly
            # that one declared entry, not every dependency with its name.
            if self_ids and index == 0:
                require(name == self_ids[0], 'otool self-ID ordering mismatch: ' + str(path))
                continue
            if name.startswith(('/System/Library/', '/usr/lib/')):
                system.add(name)
                continue
            def expand(value):
                return Path(value.replace('@loader_path', str(path.parent))
                            .replace('@executable_path', str(RUN.BUILD / 'bin')))
            if name.startswith('@rpath/'):
                candidates = [expand(item) / name[len('@rpath/'):] for item in rpaths]
                candidates.append(RUN.BUILD / 'bin' / name[len('@rpath/'):])
            else:
                candidates = [expand(name)]
            found = next((item for item in candidates if item.is_file()), None)
            require(found is not None, f'unresolved non-system dependency: {path}: {name}')
            pending.append(found)
    return dict(non_system=checked, system_install_names=sorted(system),
                system_scope='Apple dyld shared-cache/framework install names retained, not byte-hashed')


def prepare():
    require(not WORK.exists(), 'fresh work directory required; no overwrite/retry')
    frozen, build = full6_gate()
    binary = RUN.BUILD / 'bin/test_tile_xir_metal'
    libraries = library_paths()
    require((RUN.BUILD / 'bin/libluisa-backend-metal4.so') in libraries, 'missing Metal4 plugin')
    paths = [SOURCE, Path(__file__).resolve(), RAW / 'metal4_copy_only_control_v2.py', RAW / 'metal4_copy_only_control_v1.cpp', RAW / 'run.py', RAW / 'owned.json', RAW / 'toolchain.json',
             RAW / 'source-clone.json', Path(frozen['receipt']), binary, *libraries,
             *(RUN.SELECTED / item for item in frozen['source_sha256']),
             *(RUN.BUILD / item for item in ['CMakeCache.txt', 'build.ninja', 'compile_commands.json']),
             *(FULL_BUILD.parent / item for item in ['command.json', 'result.json', 'stdout.txt', 'stderr.txt'])]
    require(all(path.stat().st_mtime <= build['finished'] + 1.0 for path in [binary, *libraries]),
            'a selected build binary/library is newer than the completed full6 receipt')
    identity = fingerprints(paths)
    native_closure = closure([binary, *libraries])
    for path in native_closure['non_system']:
        identity.update(fingerprints([Path(path)]))
    entries = load(RUN.BUILD / 'compile_commands.json')
    entry = next(item for item in entries if item['file'].endswith('/src/tests/unit/runtime/test_copy.cpp'))
    argv = entry.get('arguments') or shlex.split(entry['command'])
    flags, index = [], 1
    while index < len(argv):
        if argv[index] in ('-o', '-c'):
            index += 2
        else:
            flags.append(argv[index])
            index += 1
    obj, executable = WORK / 'copy-control.o', WORK / 'copy-control'
    compile_command = [argv[0], *flags, '-c', str(SOURCE), '-o', str(obj)]
    sdk = load(RAW / 'toolchain.json')['sdk_path']
    link_command = [argv[0], '-arch', 'arm64', '-isysroot', sdk, '-mmacosx-version-min=13',
                    str(obj), '-o', str(executable),
                    *(str(RUN.BUILD / 'bin' / name) for name in
                      ['libluisa-runtime.dylib', 'libluisa-core.dylib', 'libluisa-ast.dylib']),
                    '-Wl,-rpath,' + str(RUN.BUILD / 'bin'), '-lobjc']
    require(identity == fingerprints(identity), 'identity drift during preparation')
    WORK.mkdir()
    save(WORK / 'plan.json', dict(prepared=time.time(), source_freeze=frozen,
         full6_receipt=str(FULL_BUILD), full6_finished=build['finished'], identity=identity,
         library_inventory=[str(path) for path in libraries], native_closure=native_closure,
         compile_command=compile_command, link_command=link_command,
         native_command=[str(executable), str(binary)], timeout_seconds=TIMEOUT, sample_at_seconds=SAMPLE_AT,
         diagnostic='v3: one direct native shared-event signal after upload ordinal=3; GPU-only reads at 8/20 seconds; '
                    'no Luisa Event, extra command buffer, cap change, or timing profiler; watchdog stops promptly on success.',
         scope='Current full6 source/receipt and currently selected binary closure are pinned before the isolated probe build. '
               'Full6 itself did not record binary hashes; this is not a retrospective build-output hash attestation.',
         policy='No production source/library changes; separate compile and native invocations; no automatic retries. '
                'Copy-only progress/correctness, not a performance sample and not proof that a failed prior kernel recovered.'))
    print('Prepared only:', WORK / 'plan.json')


def recheck():
    plan = load(WORK / 'plan.json')
    frozen, _ = full6_gate()
    require(frozen['receipt_sha256'] == plan['source_freeze']['receipt_sha256'], 'source freeze changed')
    require([str(path) for path in library_paths()] == plan['library_inventory'], 'library inventory changed')
    require(fingerprints(plan['identity']) == plan['identity'], 'source/receipt/binary closure changed')
    return plan


def clean_environment():
    return {key: value for key, value in os.environ.items()
            if not key.startswith(('LUISA_', 'MTL_', 'DYLD_'))}


def build_probe():
    plan = recheck()
    require(not (WORK / 'probe-build.json').exists() and not (WORK / 'copy-control').exists(), 'no probe rebuild/retry')
    records = []
    try:
        for name in ['compile', 'link']:
            with (WORK / (name + '.stdout.txt')).open('xb') as stdout, (WORK / (name + '.stderr.txt')).open('xb') as stderr:
                started = time.time()
                command = plan[name + '_command']
                result = subprocess.run(command, cwd=RUN.BUILD, env=clean_environment(), stdout=stdout, stderr=stderr, timeout=120)
            records.append(dict(name=name, command=command, started=started, finished=time.time(), exit_code=result.returncode))
            require(result.returncode == 0, name + ' failed')
        recheck()
        artifacts = fingerprints([WORK / 'copy-control.o', WORK / 'copy-control'])
        save(WORK / 'probe-build.json', dict(status='passed', native=False, records=records,
             artifacts=artifacts, closure=closure([WORK / 'copy-control']), plan_sha256=RUN.digest(WORK / 'plan.json')))
        print('Built only; no native execution:', WORK / 'copy-control')
    except BaseException as error:
        save(WORK / 'probe-build.json', dict(status='failed', native=False, records=records, error=repr(error)))
        raise


def stop_owned_child(process):
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        process.wait(timeout=2)
        return
    try:
        process.wait(timeout=2)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=2)


def native_run(authorized):
    require(authorized, 'native execution requires root explicit --root-authorized-native')
    plan = recheck()
    build = load(WORK / 'probe-build.json')
    require(build.get('status') == 'passed' and build['plan_sha256'] == RUN.digest(WORK / 'plan.json'), 'probe build not accepted')
    require(fingerprints(build['artifacts']) == build['artifacts'], 'probe binary/object changed')
    folder = WORK / 'native'
    folder.mkdir()  # Existing attempts are never overwritten or retried.
    command = plan['native_command']
    env = clean_environment()
    env.update(OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1', PYTORCH_ENABLE_MPS_FALLBACK='0')
    receipt = dict(started=time.time(), command=command, cwd=str(RUN.SELECTED), native=True,
                   timeout_seconds=TIMEOUT, sample_at_seconds=SAMPLE_AT, retries=0,
                   plan_sha256=RUN.digest(WORK / 'plan.json'), probe_build_sha256=RUN.digest(WORK / 'probe-build.json'),
                   environment={key: value for key, value in env.items() if key.startswith(('OMP_', 'VECLIB_', 'PYTORCH_'))},
                   samples=[])
    save(folder / 'command.json', receipt)
    process = None
    failure = None
    def interrupted(signum, _frame):
        raise InterruptedError(f'runner received signal {signum}')
    previous_term = signal.signal(signal.SIGTERM, interrupted)
    try:
        with (folder / 'stdout.txt').open('xb') as stdout, (folder / 'stderr.txt').open('xb') as stderr:
            process = subprocess.Popen(command, cwd=RUN.SELECTED, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            receipt['pid'] = process.pid
            started = time.monotonic()
            sampled = set()
            while process.poll() is None:
                elapsed = time.monotonic() - started
                if elapsed >= TIMEOUT:
                    receipt['timed_out'] = True
                    raise TimeoutError('30-second native progress limit reached')
                for index, deadline in enumerate(SAMPLE_AT):
                    if elapsed >= deadline and index not in sampled and process.poll() is None:
                        sampled.add(index)
                        sample_command = ['/usr/bin/sample', str(process.pid), '1', '10', '-file', str(folder / f'sample-{index + 1}.txt')]
                        item = dict(at_seconds=elapsed, command=sample_command)
                        try:
                            ps = subprocess.run(['/bin/ps', '-p', str(process.pid), '-o', 'pid=,ppid=,%cpu=,stat=,etime=,command='], capture_output=True, text=True, timeout=2)
                            item['ps'] = ps.stdout
                            result = subprocess.run(sample_command, capture_output=True, text=True, timeout=3)
                            item.update(exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr)
                        except subprocess.TimeoutExpired as error:
                            item['sample_error'] = repr(error)
                        receipt['samples'].append(item)
                        save(folder / f'sample-{index + 1}-receipt.json', item)
                time.sleep(0.05)
        require(process.returncode == 0, f'probe exited {process.returncode}')
        text = (folder / 'stdout.txt').read_text()
        for phase in ['upload_submit_before', 'upload_submit_after', 'download_submit_before', 'download_submit_after']:
            require(re.findall(r'^COPY_PROBE ' + phase + r' ordinal=(\d+)$', text, re.MULTILINE) == [str(i) for i in range(8)], 'missing/duplicate submit markers: ' + phase)
        require(text.count('COPY_PROBE PASS buffers=8 elements=153 checks=2448 submissions=16') == 1,
                'missing exact completed-check and teardown success marker')
        require(re.findall(r'^COPY_PROBE gpu_signal_(before|after) ordinal=3$', text, re.MULTILINE) == ['before', 'after'],
                'missing/duplicate native GPU signal markers')
        require(text.index('COPY_PROBE upload_submit_after ordinal=3\n') < text.index('COPY_PROBE gpu_signal_before ordinal=3\n')
                < text.index('COPY_PROBE gpu_signal_after ordinal=3\n') < text.index('COPY_PROBE upload_submit_before ordinal=4\n'),
                'native GPU signal is not exactly between the fourth and fifth uploads')
        require(re.findall(r'^COPY_PROBE gpu_only_final signaled_value=(\d+)$', text, re.MULTILINE) == ['1'],
                'missing exact GPU-only final completion')
        require(text.count('COPY_PROBE gpu_watchdog_stop_after ordinal=0\n') == 1,
                'watchdog did not confirm a completed join')
        recheck()
        receipt['status'] = 'passed'
        receipt['queue_health'] = 'This fresh copy-only control completed; prior failing Tile work is not thereby qualified.'
    except BaseException as error:
        failure = error
        receipt.update(status='failed', error=repr(error), termination_reason=type(error).__name__,
                       interrupted=isinstance(error, (KeyboardInterrupt, InterruptedError)),
                       queue_health='Unestablished after failure; no further native work without root inspection.')
        if process is not None:
            stop_owned_child(process)
    finally:
        signal.signal(signal.SIGTERM, previous_term)
        receipt.update(finished=time.time(), exit_code=process.returncode if process else None,
                       child_exited=process is not None and process.poll() is not None)
        receipt['artifacts'] = fingerprints(path for path in folder.iterdir() if path.is_file())
        save(folder / 'result.json', receipt)
        print(json.dumps(dict(status=receipt['status'], result=str(folder / 'result.json'), exit_code=receipt['exit_code'])))
    if failure:
        raise SystemExit(1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['prepare', 'build-probe', 'run'])
    parser.add_argument('--root-authorized-native', action='store_true')
    args = parser.parse_args()
    if args.mode == 'prepare':
        prepare()
    elif args.mode == 'build-probe':
        build_probe()
    else:
        native_run(args.root_authorized_native)


if __name__ == '__main__':
    main()

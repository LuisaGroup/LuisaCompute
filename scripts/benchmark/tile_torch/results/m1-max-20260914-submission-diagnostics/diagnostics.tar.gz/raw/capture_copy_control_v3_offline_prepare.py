"""Capture only offline preparation; never compile, dlopen, or run native code."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

raw = Path(__file__).resolve().parent
version = 'v3'
script = raw / f'metal4_copy_only_control_{version}.py'
folder = raw / f'metal4-copy-only-control-{version}-offline-prepare'
folder.mkdir()

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def save(name, payload):
    with (folder / name).open('x') as stream:
        json.dump(payload, stream, indent=2)
        stream.write('\n')

record = dict(command=[sys.executable, str(script), 'prepare'], started=time.time(),
              native=False, compile=False, version=version, runner_sha256=sha(script),
              full6_sha256=sha(raw / 'build-full-6/result.json'), timeout_seconds=120,
              scope='v3 offline prepare only: no compile, dlopen, native process, or device execution.')
save('command.json', record)
try:
    with (folder / 'stdout.txt').open('xb') as stdout, (folder / 'stderr.txt').open('xb') as stderr:
        result = subprocess.run(record['command'], cwd=raw, stdout=stdout, stderr=stderr, timeout=120)
    record.update(exit_code=result.returncode, status='passed' if result.returncode == 0 else 'failed')
except BaseException as error:
    record.update(exit_code=None, status='failed', error=repr(error))
finally:
    record.update(finished=time.time(), runner_unchanged=sha(script) == record['runner_sha256'])
    for channel in ('stdout', 'stderr'):
        record[channel + '_sha256'] = sha(folder / (channel + '.txt'))
    save('result.json', record)
    print(json.dumps(dict(version=version, status=record['status'], exit_code=record['exit_code'], receipt=str(folder / 'result.json'))))

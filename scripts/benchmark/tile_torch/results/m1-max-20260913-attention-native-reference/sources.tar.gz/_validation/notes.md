# Validation scope

This is the selected isolated producer build, not every test in the dirty main
worktree. The producer source and its ABI are unchanged from the preceding
two-dimensional MMA checkpoint; this change adds standalone benchmark probes.
The main/probe ABI header and actual isolated producer ABI have equal hashes.

- Full selected build: `cmake --build /tmp/luisa-next-integration.roZbN8/build --parallel 6`.
  Preliminary, final, and post-runner-driver-correction invocations completed
  with exit 0; all three raw logs are retained. The last correction preserves
  the `clang++` driver filename when resolving the compiler directory.
- Pure Python tests: from `scripts/benchmark/tile_torch`,
  `/opt/homebrew/bin/python3 -m unittest test_native_attention_probe test_native_tile`.
  Both recorded invocations passed 29 tests; `python-tests-final.log` uses the
  final frozen runner. These tests do not compile or invoke a native operator.
- Native `selftest`: 4 shapes × 3 input patterns × 2 implementations = 24
  validation-only checks. The common helper receives sample count, warmup and
  target duration all zero: no timing/calibration loops. Full independent FP64
  output, immutable inputs, output/scratch guards pass. Every native compiler
  command/output, input/output and result is under `native-selftest/`.
- CTest scope: exactly `test_simd_llvm_schedule_codegen`,
  `test_tile_xir_target_info`, `test_tile_xir_runtime`, `test_tile_xir_llm`.
  The final status/count/durations are recorded in `ctest.log`, not inferred
  from a test-name glob or a compilation pass.
- LLVM22 clang-format `--dry-run --Werror` passes for the new standalone C++
  probe. It is outside the project compile database; its direct compiler
  diagnostics are retained in every selftest/prepared probe bundle.

There are no producer/LLVM implementation changes in this checkpoint. No
Metal/TIRx/MPS, GPU capture, Torch, full-model or low-precision run is included.
The host has unrelated user/system activity; it is not a quiescent isolated
machine. Our builds and regression tests complete before competitive replay.
The large structural comparisons are diagnostic, not fine-grained cost fitting.

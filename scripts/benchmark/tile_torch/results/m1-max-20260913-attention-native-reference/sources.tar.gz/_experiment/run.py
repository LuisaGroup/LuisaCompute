"""Predeclared native attention references, not automatic Tile lowering gains.

Run freeze only after the selected full build and validation have passed. All
capture/preparation finishes before competitive replay. Existing evidence is
never overwritten. No Torch import, GPU invocation, or producer rebuild here.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT = Path('/Users/mike/CLionProjects/luisa')
OUT = Path(__file__).resolve().parent
BUILD = Path('/tmp/luisa-next-integration.roZbN8/build')
PRODUCER = BUILD / 'bin/benchmark_tile_xir'
SCRIPTS = ROOT / 'scripts/benchmark/tile_torch'
LLVM = Path('/opt/homebrew/opt/llvm/bin')
CASES = [
    ('decode-mha-d64', (1, 8, 8, 1, 2048, 64, 64), (1, 16), 0, False),
    ('decode-gqa-d80', (1, 8, 2, 1, 2053, 80, 96), (1, 16), 8, False),
    ('decode-long-kv', (1, 16, 4, 1, 8193, 128, 128), (1, 16), 8, False),
    ('prefill-q4', (1, 4, 2, 32, 65, 32, 32), (4, 16), 0, True),
    ('prefill-q8', (1, 4, 2, 64, 129, 32, 48), (8, 16), 0, True),
    ('batch-gqa-q4', (2, 6, 2, 17, 67, 40, 48), (4, 16), 8, True),
]
VARIANTS = ('online_neon', 'dense_accelerate')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def load(path):
    return json.loads(path.read_text())


def clean_env():
    env = {k: v for k, v in os.environ.items() if not k.startswith(('LUISA_', 'MTL_'))}
    env.update(OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    return env


def freeze(create):
    paths = [Path(__file__).resolve(), OUT / 'freeze.py', PRODUCER,
             SCRIPTS / 'native_tile.py', SCRIPTS / 'native_tile_replay.cpp',
             SCRIPTS / 'native_attention_probe.cpp', SCRIPTS / 'native_attention_probe.py',
             SCRIPTS / 'test_native_attention_probe.py',
             ROOT / 'src/backends/simd/llvm/llvm_schedule_codegen.h']
    expected = dict(cases=[dict(name=n, dimensions=d, block=b, cap=c, two_dimensional=t)
                           for n, d, b, c, t in CASES], variants=list(VARIANTS),
                    cycles=3, samples=7, warmup_ms=30, target_ms=15,
                    capture_timeout_s=180, replay_timeout_s=120,
                    identities={str(p): sha(p) for p in paths},
                    python=str(Path(sys.executable).resolve()), llvm=str(LLVM),
                    comparison='Actual Tile native entry versus hand native reference; not a compiler improvement.',
                    metric='single-thread native-entry host wall; includes entry/traversal/helpers and library internals',
                    math='FP32 inputs/outputs; independent dense FP64 bottom-right causal GQA oracle; atol=rtol=5e-5')
    # Normalize tuples so in-memory controls match their JSON representation.
    expected = json.loads(json.dumps(expected))
    if create:
        require(not (OUT / 'plan.json').exists(), 'plan exists; use a new directory')
        save(OUT / 'plan.json', dict(**expected, frozen_unix=time.time()))
    else:
        plan = load(OUT / 'plan.json')
        require(all(plan.get(k) == v for k, v in expected.items()), 'frozen plan/source changed')
    return sha(OUT / 'plan.json')


def run(command, folder, stem, env=None, timeout=180):
    require(not (folder / (stem + '.command.json')).exists(), 'command already recorded')
    record = dict(command=command, started=time.time(), timeout_s=timeout,
                  process_group_isolated=True,
                  environment={k: v for k, v in (env or {}).items()
                               if k.startswith('LUISA_') or k in ('OMP_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'OPENBLAS_NUM_THREADS')})
    save(folder / (stem + '.command.json'), record)
    process = subprocess.Popen(command, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, start_new_session=True)
    try:
        stdout, stderr = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        stdout, stderr = process.communicate()
        record['error'] = 'timeout: isolated process group killed'
    (folder / (stem + '.stdout')).write_bytes(stdout)
    (folder / (stem + '.stderr')).write_bytes(stderr)
    record.update(returncode=process.returncode, finished=time.time())
    save(folder / (stem + '.command.json'), record)
    require(process.returncode == 0 and 'error' not in record, f'{stem}: failed, see raw logs')
    require(not stderr, f'{stem}: stderr requires review before admission')
    return stdout


def field(text, name, boolean=False):
    values = re.findall(r'\b' + re.escape(name) + '=' + ('(true|false)' if boolean else r'(\d+)') + r'\b', text)
    require(len(values) == 1, 'missing/duplicate metadata ' + name)
    return values[0] == 'true' if boolean else int(values[0])


def capture():
    plan_hash = freeze(False)
    require((OUT / 'provenance.json').is_file() and (OUT / 'sources.tar.gz').is_file(), 'freeze actual sources before capture')
    summary = dict(started=time.time(), plan_sha256=plan_hash, cases=[])
    for name, dims, block, cap, two_d in CASES:
        row = dict(case=name, status='Error')
        summary['cases'].append(row)
        folder = OUT / name
        folder.mkdir()
        try:
            prefix = folder / 'output.f32'
            env = clean_env()
            env.update(LUISA_TILE_BENCH_XIR_BACKEND='simd', LUISA_TILE_BENCH_ATTENTION_QK='mma',
                       LUISA_TILE_BENCH_ATTENTION_PV='mma', LUISA_TILE_BENCH_XIR_MMA_OUTPUT_BLOCK='4',
                       LUISA_TILE_BENCH_XIR_MMA_UNROLL_TERMS=str(cap),
                       LUISA_TILE_BENCH_XIR_MMA_2D_BLOCKING='1' if two_d else '0',
                       LUISA_TILE_BENCH_XIR_BLOCK_SIZE='32', LUISA_TILE_BENCH_XIR_LOCAL_LANES='1',
                       LUISA_TILE_BENCH_XIR_REGION_WORK='4096',
                       LUISA_TILE_BENCH_DUMP_SOURCE=str(prefix) + '.source.txt',
                       LUISA_SIMD_DUMP_ASSEMBLY_DIR=str(folder / 'objects'),
                       LUISA_SIMD_ENABLE_FULL_PACKET_SPECIALIZATION='1')
            metadata = json.loads(run([str(PRODUCER), 'llm', 'attention', ','.join(map(str, dims)),
                                       *map(str, block), '3', '1', '1', str(prefix)], folder, 'capture', env))
            require(metadata['dimensions'] == list(dims) and metadata['attention_block'] == list(block), 'capture shape drift')
            require(metadata['attention_qk'] == metadata['attention_pv'] == 'mma', 'decomposition drift')
            require(metadata['fast_math'] is False and metadata['precision'] == 'fp32', 'precision drift')
            text = metadata['realization']
            require(re.findall(r'\bW(\d+), (\d+) workers/block\b', text) == [('8', '32')], 'packet controls drift')
            for key, value in dict(local_lanes=1, max_unrolled_tile_elements=64,
                                   max_unrolled_region_work=4096, requested_mma_output_block=4,
                                   requested_max_unrolled_mma_terms=cap).items():
                require(field(text, key) == value, key + ' drift')
            require(field(text, 'requested_mma_2d_blocking', True) is two_d, '2D request drift')
            row['two_dimensional_mmas'] = field(text, 'two_dimensional_mmas')
            run([sys.executable, str(SCRIPTS / 'native_tile.py'), 'prepare', '--capture-kind', 'llm',
                 '--llvm', str(LLVM), '--prefix', str(prefix), '--log', str(folder / 'capture.stdout'),
                 '--objects', str(folder / 'objects'), '--output', str(folder / 'tile'), '--name', name],
                folder, 'prepare-tile', clean_env())
            run([sys.executable, str(SCRIPTS / 'native_attention_probe.py'), 'prepare',
                 '--tile', str(folder / 'tile/prepared.json'), '--output', str(folder / 'probe'),
                 '--llvm', str(LLVM)],
                folder, 'prepare-probe', clean_env())
            row.update(status='prepared', probe_sha256=sha(folder / 'probe/probe.json'))
        except Exception as error:
            row['error'] = str(error)
        save(OUT / 'capture-summary.json', summary)
        print(row, flush=True)
    summary['finished'] = time.time()
    save(OUT / 'capture-summary.json', summary)
    freeze(False)
    require(all(r['status'] == 'prepared' for r in summary['cases']), 'capture failures retained')


def replay():
    plan_hash = freeze(False)
    captures = load(OUT / 'capture-summary.json')
    require(all(r['status'] == 'prepared' for r in captures['cases']), 'all captures must pass first')
    summary = dict(started=time.time(), plan_sha256=plan_hash, comparisons=[])
    require(not (OUT / 'replay-summary.json').exists(), 'replay already attempted')
    for name, *_ in CASES:
        folder = OUT / name
        for variant in VARIANTS:
            row = dict(case=name, variant=variant, status='Error')
            summary['comparisons'].append(row)
            try:
                run([sys.executable, str(SCRIPTS / 'native_attention_probe.py'), 'replay',
                     '--bundle', str(folder / 'probe/probe.json'), '--variant', variant,
                     '--output', str(folder / variant), '--cycles', '3', '--samples', '7',
                     '--warmup-ms', '30', '--target-ms', '15'],
                    folder, 'replay-' + variant, clean_env(), timeout=120)
                row.update(status='ok', results_sha256=sha(folder / variant / 'results.json'))
            except Exception as error:
                row['error'] = str(error)
            save(OUT / 'replay-summary.json', summary)
            print(row, flush=True)
    summary['finished'] = time.time()
    save(OUT / 'replay-summary.json', summary)
    freeze(False)
    require(all(r['status'] == 'ok' for r in summary['comparisons']), 'replay failures retained')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('freeze', 'capture', 'replay'))
    args = parser.parse_args()
    if args.phase == 'freeze':
        print(freeze(True))
    elif args.phase == 'capture':
        capture()
    else:
        replay()

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_4:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_5:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #3280
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q3, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v1, v3
	cmhi.4s	v1, v1, v2
	str	q0, [sp, #11296]                ; 16-byte Spill
	str	q1, [sp, #11312]                ; 16-byte Spill
	uzp1.8h	v4, v1, v0
	umaxv.8h	h5, v4
	fmov	w8, s5
	tbnz	w8, #0, LBB0_1
	b	LBB0_1194
LBB0_1:                                 ; %direct.activate
	ldr	x9, [x0]
Lloh4:
	adrp	x8, lCPI0_2@PAGE
Lloh5:
	ldr	q5, [x8, lCPI0_2@PAGEOFF]
	and.16b	v4, v4, v5
	addv.8h	h0, v4
	fmov	w10, s0
	and	w8, w10, #0xff
	ldr	w11, [x1]
	ldr	w12, [x1, #36]
	add	w11, w12, w11, lsl #5
	dup.4s	v4, w11
	add.4s	v3, v4, v3
	add.4s	v2, v4, v2
	ldr	q1, [sp, #11312]                ; 16-byte Reload
	and.16b	v2, v1, v2
	ushll.2d	v7, v2, #8
	dup.2d	v4, x9
	add.2d	v5, v4, v7
	movi.2d	v6, #0000000000000000
	str	q6, [sp, #9136]                 ; 16-byte Spill
	str	q6, [sp, #10912]                ; 16-byte Spill
	tbz	w10, #0, LBB0_2
	b	LBB0_1195
LBB0_2:                                 ; %else
	ldr	q1, [sp, #11296]                ; 16-byte Reload
	and.16b	v3, v1, v3
	ushll2.2d	v16, v2, #8
	tbz	w8, #1, LBB0_3
	b	LBB0_1196
LBB0_3:                                 ; %else203
	add.2d	v5, v4, v16
	tbz	w8, #2, LBB0_4
	b	LBB0_1197
LBB0_4:                                 ; %else206
	ushll.2d	v18, v3, #8
	tbz	w8, #3, LBB0_5
	b	LBB0_1198
LBB0_5:                                 ; %else209
	add.2d	v5, v4, v18
	tbz	w8, #4, LBB0_6
	b	LBB0_1199
LBB0_6:                                 ; %else212
	ushll2.2d	v22, v3, #8
	tbz	w8, #5, LBB0_7
	b	LBB0_1200
LBB0_7:                                 ; %else215
	add.2d	v5, v4, v22
	tbz	w8, #6, LBB0_8
	b	LBB0_1201
LBB0_8:                                 ; %else218
	tbz	w8, #7, LBB0_10
LBB0_9:                                 ; %cond.load220
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10912]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10912]                ; 16-byte Spill
LBB0_10:                                ; %else221
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #4                         ; =0x4
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #2016]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #8736]                ; 16-byte Spill
	str	q19, [sp, #10896]               ; 16-byte Spill
	tbz	w9, #0, LBB0_11
	b	LBB0_1202
LBB0_11:                                ; %else228
	orr.16b	v19, v16, v5
	str	q19, [sp, #4064]                ; 16-byte Spill
	tbz	w8, #1, LBB0_12
	b	LBB0_1203
LBB0_12:                                ; %else234
	ldr	q6, [sp, #4064]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_13
	b	LBB0_1204
LBB0_13:                                ; %else240
	orr.16b	v19, v18, v5
	str	q19, [sp, #4048]                ; 16-byte Spill
	tbz	w8, #3, LBB0_14
	b	LBB0_1205
LBB0_14:                                ; %else246
	ldr	q6, [sp, #4048]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_15
	b	LBB0_1206
LBB0_15:                                ; %else252
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_16
	b	LBB0_1207
LBB0_16:                                ; %else258
	str	q5, [sp, #2000]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_17
	b	LBB0_1208
LBB0_17:                                ; %else264
	tbz	w8, #7, LBB0_19
LBB0_18:                                ; %cond.load266
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10896]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10896]                ; 16-byte Spill
LBB0_19:                                ; %else270
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #8                         ; =0x8
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1984]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9120]                ; 16-byte Spill
	str	q19, [sp, #10880]               ; 16-byte Spill
	tbz	w9, #0, LBB0_20
	b	LBB0_1209
LBB0_20:                                ; %else277
	orr.16b	v19, v16, v5
	str	q19, [sp, #4032]                ; 16-byte Spill
	tbz	w8, #1, LBB0_21
	b	LBB0_1210
LBB0_21:                                ; %else283
	ldr	q6, [sp, #4032]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_22
	b	LBB0_1211
LBB0_22:                                ; %else289
	orr.16b	v19, v18, v5
	str	q19, [sp, #4016]                ; 16-byte Spill
	tbz	w8, #3, LBB0_23
	b	LBB0_1212
LBB0_23:                                ; %else295
	ldr	q6, [sp, #4016]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_24
	b	LBB0_1213
LBB0_24:                                ; %else301
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_25
	b	LBB0_1214
LBB0_25:                                ; %else307
	str	q5, [sp, #1968]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_26
	b	LBB0_1215
LBB0_26:                                ; %else313
	tbz	w8, #7, LBB0_28
LBB0_27:                                ; %cond.load315
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10880]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10880]                ; 16-byte Spill
LBB0_28:                                ; %else319
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #12                        ; =0xc
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1952]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9104]                ; 16-byte Spill
	str	q19, [sp, #10864]               ; 16-byte Spill
	tbz	w9, #0, LBB0_29
	b	LBB0_1216
LBB0_29:                                ; %else326
	orr.16b	v19, v16, v5
	str	q19, [sp, #4000]                ; 16-byte Spill
	tbz	w8, #1, LBB0_30
	b	LBB0_1217
LBB0_30:                                ; %else332
	ldr	q6, [sp, #4000]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_31
	b	LBB0_1218
LBB0_31:                                ; %else338
	orr.16b	v19, v18, v5
	str	q19, [sp, #3984]                ; 16-byte Spill
	tbz	w8, #3, LBB0_32
	b	LBB0_1219
LBB0_32:                                ; %else344
	ldr	q6, [sp, #3984]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_33
	b	LBB0_1220
LBB0_33:                                ; %else350
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_34
	b	LBB0_1221
LBB0_34:                                ; %else356
	str	q5, [sp, #1936]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_35
	b	LBB0_1222
LBB0_35:                                ; %else362
	tbz	w8, #7, LBB0_37
LBB0_36:                                ; %cond.load364
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10864]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10864]                ; 16-byte Spill
LBB0_37:                                ; %else368
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #16                        ; =0x10
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1920]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10112]               ; 16-byte Spill
	str	q19, [sp, #10848]               ; 16-byte Spill
	tbz	w9, #0, LBB0_38
	b	LBB0_1223
LBB0_38:                                ; %else375
	orr.16b	v19, v16, v5
	str	q19, [sp, #3968]                ; 16-byte Spill
	tbz	w8, #1, LBB0_39
	b	LBB0_1224
LBB0_39:                                ; %else381
	ldr	q6, [sp, #3968]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_40
	b	LBB0_1225
LBB0_40:                                ; %else387
	orr.16b	v19, v18, v5
	str	q19, [sp, #3952]                ; 16-byte Spill
	tbz	w8, #3, LBB0_41
	b	LBB0_1226
LBB0_41:                                ; %else393
	ldr	q6, [sp, #3952]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_42
	b	LBB0_1227
LBB0_42:                                ; %else399
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_43
	b	LBB0_1228
LBB0_43:                                ; %else405
	str	q5, [sp, #1904]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_44
	b	LBB0_1229
LBB0_44:                                ; %else411
	tbz	w8, #7, LBB0_46
LBB0_45:                                ; %cond.load413
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10848]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10848]                ; 16-byte Spill
LBB0_46:                                ; %else417
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #20                        ; =0x14
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1888]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9088]                ; 16-byte Spill
	str	q19, [sp, #10832]               ; 16-byte Spill
	tbz	w9, #0, LBB0_47
	b	LBB0_1230
LBB0_47:                                ; %else424
	orr.16b	v19, v16, v5
	str	q19, [sp, #3936]                ; 16-byte Spill
	tbz	w8, #1, LBB0_48
	b	LBB0_1231
LBB0_48:                                ; %else430
	ldr	q6, [sp, #3936]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_49
	b	LBB0_1232
LBB0_49:                                ; %else436
	orr.16b	v19, v18, v5
	str	q19, [sp, #3920]                ; 16-byte Spill
	tbz	w8, #3, LBB0_50
	b	LBB0_1233
LBB0_50:                                ; %else442
	ldr	q6, [sp, #3920]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_51
	b	LBB0_1234
LBB0_51:                                ; %else448
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_52
	b	LBB0_1235
LBB0_52:                                ; %else454
	str	q5, [sp, #1872]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_53
	b	LBB0_1236
LBB0_53:                                ; %else460
	tbz	w8, #7, LBB0_55
LBB0_54:                                ; %cond.load462
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10832]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10832]                ; 16-byte Spill
LBB0_55:                                ; %else466
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #24                        ; =0x18
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1856]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10096]               ; 16-byte Spill
	str	q19, [sp, #10816]               ; 16-byte Spill
	tbz	w9, #0, LBB0_56
	b	LBB0_1237
LBB0_56:                                ; %else473
	orr.16b	v19, v16, v5
	str	q19, [sp, #3904]                ; 16-byte Spill
	tbz	w8, #1, LBB0_57
	b	LBB0_1238
LBB0_57:                                ; %else479
	ldr	q6, [sp, #3904]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_58
	b	LBB0_1239
LBB0_58:                                ; %else485
	orr.16b	v19, v18, v5
	str	q19, [sp, #3888]                ; 16-byte Spill
	tbz	w8, #3, LBB0_59
	b	LBB0_1240
LBB0_59:                                ; %else491
	ldr	q6, [sp, #3888]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_60
	b	LBB0_1241
LBB0_60:                                ; %else497
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_61
	b	LBB0_1242
LBB0_61:                                ; %else503
	str	q5, [sp, #1840]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_62
	b	LBB0_1243
LBB0_62:                                ; %else509
	tbz	w8, #7, LBB0_64
LBB0_63:                                ; %cond.load511
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10816]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10816]                ; 16-byte Spill
LBB0_64:                                ; %else515
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #28                        ; =0x1c
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1824]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10080]               ; 16-byte Spill
	str	q19, [sp, #10800]               ; 16-byte Spill
	tbz	w9, #0, LBB0_65
	b	LBB0_1244
LBB0_65:                                ; %else522
	orr.16b	v19, v16, v5
	str	q19, [sp, #3872]                ; 16-byte Spill
	tbz	w8, #1, LBB0_66
	b	LBB0_1245
LBB0_66:                                ; %else528
	ldr	q6, [sp, #3872]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_67
	b	LBB0_1246
LBB0_67:                                ; %else534
	orr.16b	v19, v18, v5
	str	q19, [sp, #3856]                ; 16-byte Spill
	tbz	w8, #3, LBB0_68
	b	LBB0_1247
LBB0_68:                                ; %else540
	ldr	q6, [sp, #3856]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_69
	b	LBB0_1248
LBB0_69:                                ; %else546
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_70
	b	LBB0_1249
LBB0_70:                                ; %else552
	str	q5, [sp, #1808]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_71
	b	LBB0_1250
LBB0_71:                                ; %else558
	tbz	w8, #7, LBB0_73
LBB0_72:                                ; %cond.load560
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10800]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10800]                ; 16-byte Spill
LBB0_73:                                ; %else564
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #32                        ; =0x20
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1792]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10064]               ; 16-byte Spill
	str	q19, [sp, #10784]               ; 16-byte Spill
	tbz	w9, #0, LBB0_74
	b	LBB0_1251
LBB0_74:                                ; %else571
	orr.16b	v19, v16, v5
	str	q19, [sp, #3840]                ; 16-byte Spill
	tbz	w8, #1, LBB0_75
	b	LBB0_1252
LBB0_75:                                ; %else577
	ldr	q6, [sp, #3840]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_76
	b	LBB0_1253
LBB0_76:                                ; %else583
	orr.16b	v19, v18, v5
	str	q19, [sp, #3824]                ; 16-byte Spill
	tbz	w8, #3, LBB0_77
	b	LBB0_1254
LBB0_77:                                ; %else589
	ldr	q6, [sp, #3824]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_78
	b	LBB0_1255
LBB0_78:                                ; %else595
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_79
	b	LBB0_1256
LBB0_79:                                ; %else601
	str	q5, [sp, #1776]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_80
	b	LBB0_1257
LBB0_80:                                ; %else607
	tbz	w8, #7, LBB0_82
LBB0_81:                                ; %cond.load609
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10784]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10784]                ; 16-byte Spill
LBB0_82:                                ; %else613
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #36                        ; =0x24
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1760]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10048]               ; 16-byte Spill
	str	q19, [sp, #10768]               ; 16-byte Spill
	tbz	w9, #0, LBB0_83
	b	LBB0_1258
LBB0_83:                                ; %else620
	orr.16b	v19, v16, v5
	str	q19, [sp, #3808]                ; 16-byte Spill
	tbz	w8, #1, LBB0_84
	b	LBB0_1259
LBB0_84:                                ; %else626
	ldr	q6, [sp, #3808]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_85
	b	LBB0_1260
LBB0_85:                                ; %else632
	orr.16b	v19, v18, v5
	str	q19, [sp, #3792]                ; 16-byte Spill
	tbz	w8, #3, LBB0_86
	b	LBB0_1261
LBB0_86:                                ; %else638
	ldr	q6, [sp, #3792]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_87
	b	LBB0_1262
LBB0_87:                                ; %else644
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_88
	b	LBB0_1263
LBB0_88:                                ; %else650
	str	q5, [sp, #1744]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_89
	b	LBB0_1264
LBB0_89:                                ; %else656
	tbz	w8, #7, LBB0_91
LBB0_90:                                ; %cond.load658
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10768]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10768]                ; 16-byte Spill
LBB0_91:                                ; %else662
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #40                        ; =0x28
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1728]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9072]                ; 16-byte Spill
	str	q19, [sp, #9360]                ; 16-byte Spill
	tbz	w9, #0, LBB0_92
	b	LBB0_1265
LBB0_92:                                ; %else669
	orr.16b	v19, v16, v5
	str	q19, [sp, #3776]                ; 16-byte Spill
	tbz	w8, #1, LBB0_93
	b	LBB0_1266
LBB0_93:                                ; %else675
	ldr	q6, [sp, #3776]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_94
	b	LBB0_1267
LBB0_94:                                ; %else681
	orr.16b	v19, v18, v5
	str	q19, [sp, #3760]                ; 16-byte Spill
	tbz	w8, #3, LBB0_95
	b	LBB0_1268
LBB0_95:                                ; %else687
	ldr	q6, [sp, #3760]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_96
	b	LBB0_1269
LBB0_96:                                ; %else693
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_97
	b	LBB0_1270
LBB0_97:                                ; %else699
	str	q5, [sp, #1712]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_98
	b	LBB0_1271
LBB0_98:                                ; %else705
	tbz	w8, #7, LBB0_100
LBB0_99:                                ; %cond.load707
	mov.d	x8, v5[1]
	ldr	q5, [sp, #9360]                 ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #9360]                 ; 16-byte Spill
LBB0_100:                               ; %else711
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #44                        ; =0x2c
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1696]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10032]               ; 16-byte Spill
	str	q19, [sp, #9344]                ; 16-byte Spill
	tbz	w9, #0, LBB0_101
	b	LBB0_1272
LBB0_101:                               ; %else718
	orr.16b	v19, v16, v5
	str	q19, [sp, #3744]                ; 16-byte Spill
	tbz	w8, #1, LBB0_102
	b	LBB0_1273
LBB0_102:                               ; %else724
	ldr	q6, [sp, #3744]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_103
	b	LBB0_1274
LBB0_103:                               ; %else730
	orr.16b	v19, v18, v5
	str	q19, [sp, #3728]                ; 16-byte Spill
	tbz	w8, #3, LBB0_104
	b	LBB0_1275
LBB0_104:                               ; %else736
	ldr	q6, [sp, #3728]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_105
	b	LBB0_1276
LBB0_105:                               ; %else742
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_106
	b	LBB0_1277
LBB0_106:                               ; %else748
	str	q5, [sp, #1680]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_107
	b	LBB0_1278
LBB0_107:                               ; %else754
	tbz	w8, #7, LBB0_109
LBB0_108:                               ; %cond.load756
	mov.d	x8, v5[1]
	ldr	q5, [sp, #9344]                 ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #9344]                 ; 16-byte Spill
LBB0_109:                               ; %else760
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #48                        ; =0x30
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1664]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9056]                ; 16-byte Spill
	str	q19, [sp, #9328]                ; 16-byte Spill
	tbz	w9, #0, LBB0_110
	b	LBB0_1279
LBB0_110:                               ; %else767
	orr.16b	v19, v16, v5
	str	q19, [sp, #3712]                ; 16-byte Spill
	tbz	w8, #1, LBB0_111
	b	LBB0_1280
LBB0_111:                               ; %else773
	ldr	q6, [sp, #3712]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_112
	b	LBB0_1281
LBB0_112:                               ; %else779
	orr.16b	v19, v18, v5
	str	q19, [sp, #3696]                ; 16-byte Spill
	tbz	w8, #3, LBB0_113
	b	LBB0_1282
LBB0_113:                               ; %else785
	ldr	q6, [sp, #3696]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_114
	b	LBB0_1283
LBB0_114:                               ; %else791
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_115
	b	LBB0_1284
LBB0_115:                               ; %else797
	str	q5, [sp, #1648]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_116
	b	LBB0_1285
LBB0_116:                               ; %else803
	tbz	w8, #7, LBB0_118
LBB0_117:                               ; %cond.load805
	mov.d	x8, v5[1]
	ldr	q5, [sp, #9328]                 ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #9328]                 ; 16-byte Spill
LBB0_118:                               ; %else809
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #52                        ; =0x34
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1632]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9040]                ; 16-byte Spill
	str	q19, [sp, #9312]                ; 16-byte Spill
	tbz	w9, #0, LBB0_119
	b	LBB0_1286
LBB0_119:                               ; %else816
	orr.16b	v19, v16, v5
	str	q19, [sp, #3680]                ; 16-byte Spill
	tbz	w8, #1, LBB0_120
	b	LBB0_1287
LBB0_120:                               ; %else822
	ldr	q6, [sp, #3680]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_121
	b	LBB0_1288
LBB0_121:                               ; %else828
	orr.16b	v19, v18, v5
	str	q19, [sp, #3664]                ; 16-byte Spill
	tbz	w8, #3, LBB0_122
	b	LBB0_1289
LBB0_122:                               ; %else834
	ldr	q6, [sp, #3664]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_123
	b	LBB0_1290
LBB0_123:                               ; %else840
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_124
	b	LBB0_1291
LBB0_124:                               ; %else846
	str	q5, [sp, #1616]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_125
	b	LBB0_1292
LBB0_125:                               ; %else852
	tbz	w8, #7, LBB0_127
LBB0_126:                               ; %cond.load854
	mov.d	x8, v5[1]
	ldr	q5, [sp, #9312]                 ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #9312]                 ; 16-byte Spill
LBB0_127:                               ; %else858
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #56                        ; =0x38
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1600]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9024]                ; 16-byte Spill
	str	q19, [sp, #9296]                ; 16-byte Spill
	tbz	w9, #0, LBB0_128
	b	LBB0_1293
LBB0_128:                               ; %else865
	orr.16b	v19, v16, v5
	str	q19, [sp, #3648]                ; 16-byte Spill
	tbz	w8, #1, LBB0_129
	b	LBB0_1294
LBB0_129:                               ; %else871
	ldr	q6, [sp, #3648]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_130
	b	LBB0_1295
LBB0_130:                               ; %else877
	orr.16b	v19, v18, v5
	str	q19, [sp, #3632]                ; 16-byte Spill
	tbz	w8, #3, LBB0_131
	b	LBB0_1296
LBB0_131:                               ; %else883
	ldr	q6, [sp, #3632]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_132
	b	LBB0_1297
LBB0_132:                               ; %else889
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_133
	b	LBB0_1298
LBB0_133:                               ; %else895
	str	q5, [sp, #1584]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_134
	b	LBB0_1299
LBB0_134:                               ; %else901
	tbz	w8, #7, LBB0_136
LBB0_135:                               ; %cond.load903
	mov.d	x8, v5[1]
	ldr	q5, [sp, #9296]                 ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #9296]                 ; 16-byte Spill
LBB0_136:                               ; %else907
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #60                        ; =0x3c
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1568]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9008]                ; 16-byte Spill
	str	q19, [sp, #9280]                ; 16-byte Spill
	tbz	w9, #0, LBB0_137
	b	LBB0_1300
LBB0_137:                               ; %else914
	orr.16b	v19, v16, v5
	str	q19, [sp, #3616]                ; 16-byte Spill
	tbz	w8, #1, LBB0_138
	b	LBB0_1301
LBB0_138:                               ; %else920
	ldr	q6, [sp, #3616]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_139
	b	LBB0_1302
LBB0_139:                               ; %else926
	orr.16b	v19, v18, v5
	str	q19, [sp, #3600]                ; 16-byte Spill
	tbz	w8, #3, LBB0_140
	b	LBB0_1303
LBB0_140:                               ; %else932
	ldr	q6, [sp, #3600]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_141
	b	LBB0_1304
LBB0_141:                               ; %else938
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_142
	b	LBB0_1305
LBB0_142:                               ; %else944
	str	q5, [sp, #1552]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_143
	b	LBB0_1306
LBB0_143:                               ; %else950
	tbz	w8, #7, LBB0_145
LBB0_144:                               ; %cond.load952
	mov.d	x8, v5[1]
	ldr	q5, [sp, #9280]                 ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #9280]                 ; 16-byte Spill
LBB0_145:                               ; %else956
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #64                        ; =0x40
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1536]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #8992]                ; 16-byte Spill
	str	q19, [sp, #9264]                ; 16-byte Spill
	tbz	w9, #0, LBB0_146
	b	LBB0_1307
LBB0_146:                               ; %else963
	orr.16b	v19, v16, v5
	str	q19, [sp, #3584]                ; 16-byte Spill
	tbz	w8, #1, LBB0_147
	b	LBB0_1308
LBB0_147:                               ; %else969
	ldr	q6, [sp, #3584]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_148
	b	LBB0_1309
LBB0_148:                               ; %else975
	orr.16b	v19, v18, v5
	str	q19, [sp, #3568]                ; 16-byte Spill
	tbz	w8, #3, LBB0_149
	b	LBB0_1310
LBB0_149:                               ; %else981
	ldr	q6, [sp, #3568]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_150
	b	LBB0_1311
LBB0_150:                               ; %else987
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_151
	b	LBB0_1312
LBB0_151:                               ; %else993
	str	q5, [sp, #1520]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_152
	b	LBB0_1313
LBB0_152:                               ; %else999
	tbz	w8, #7, LBB0_154
LBB0_153:                               ; %cond.load1001
	mov.d	x8, v5[1]
	ldr	q5, [sp, #9264]                 ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #9264]                 ; 16-byte Spill
LBB0_154:                               ; %else1005
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #68                        ; =0x44
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1504]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #8976]                ; 16-byte Spill
	str	q19, [sp, #9248]                ; 16-byte Spill
	tbz	w9, #0, LBB0_155
	b	LBB0_1314
LBB0_155:                               ; %else1012
	orr.16b	v19, v16, v5
	str	q19, [sp, #3552]                ; 16-byte Spill
	tbz	w8, #1, LBB0_156
	b	LBB0_1315
LBB0_156:                               ; %else1018
	ldr	q6, [sp, #3552]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_157
	b	LBB0_1316
LBB0_157:                               ; %else1024
	orr.16b	v19, v18, v5
	str	q19, [sp, #3536]                ; 16-byte Spill
	tbz	w8, #3, LBB0_158
	b	LBB0_1317
LBB0_158:                               ; %else1030
	ldr	q6, [sp, #3536]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_159
	b	LBB0_1318
LBB0_159:                               ; %else1036
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_160
	b	LBB0_1319
LBB0_160:                               ; %else1042
	str	q5, [sp, #1488]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_161
	b	LBB0_1320
LBB0_161:                               ; %else1048
	tbz	w8, #7, LBB0_163
LBB0_162:                               ; %cond.load1050
	mov.d	x8, v5[1]
	ldr	q5, [sp, #9248]                 ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #9248]                 ; 16-byte Spill
LBB0_163:                               ; %else1054
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #72                        ; =0x48
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1472]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #8960]                ; 16-byte Spill
	str	q19, [sp, #9232]                ; 16-byte Spill
	tbz	w9, #0, LBB0_164
	b	LBB0_1321
LBB0_164:                               ; %else1061
	orr.16b	v19, v16, v5
	str	q19, [sp, #3520]                ; 16-byte Spill
	tbz	w8, #1, LBB0_165
	b	LBB0_1322
LBB0_165:                               ; %else1067
	ldr	q6, [sp, #3520]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_166
	b	LBB0_1323
LBB0_166:                               ; %else1073
	orr.16b	v19, v18, v5
	str	q19, [sp, #3504]                ; 16-byte Spill
	tbz	w8, #3, LBB0_167
	b	LBB0_1324
LBB0_167:                               ; %else1079
	ldr	q6, [sp, #3504]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_168
	b	LBB0_1325
LBB0_168:                               ; %else1085
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_169
	b	LBB0_1326
LBB0_169:                               ; %else1091
	str	q5, [sp, #1456]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_170
	b	LBB0_1327
LBB0_170:                               ; %else1097
	tbz	w8, #7, LBB0_172
LBB0_171:                               ; %cond.load1099
	mov.d	x8, v5[1]
	ldr	q5, [sp, #9232]                 ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #9232]                 ; 16-byte Spill
LBB0_172:                               ; %else1103
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #76                        ; =0x4c
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1440]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #8944]                ; 16-byte Spill
	str	q19, [sp, #9216]                ; 16-byte Spill
	tbz	w9, #0, LBB0_173
	b	LBB0_1328
LBB0_173:                               ; %else1110
	orr.16b	v19, v16, v5
	str	q19, [sp, #3488]                ; 16-byte Spill
	tbz	w8, #1, LBB0_174
	b	LBB0_1329
LBB0_174:                               ; %else1116
	ldr	q6, [sp, #3488]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_175
	b	LBB0_1330
LBB0_175:                               ; %else1122
	orr.16b	v19, v18, v5
	str	q19, [sp, #3472]                ; 16-byte Spill
	tbz	w8, #3, LBB0_176
	b	LBB0_1331
LBB0_176:                               ; %else1128
	ldr	q6, [sp, #3472]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_177
	b	LBB0_1332
LBB0_177:                               ; %else1134
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_178
	b	LBB0_1333
LBB0_178:                               ; %else1140
	str	q5, [sp, #1424]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_179
	b	LBB0_1334
LBB0_179:                               ; %else1146
	tbz	w8, #7, LBB0_181
LBB0_180:                               ; %cond.load1148
	mov.d	x8, v5[1]
	ldr	q5, [sp, #9216]                 ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #9216]                 ; 16-byte Spill
LBB0_181:                               ; %else1152
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #80                        ; =0x50
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1408]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #8720]                ; 16-byte Spill
	str	q19, [sp, #9200]                ; 16-byte Spill
	tbz	w9, #0, LBB0_182
	b	LBB0_1335
LBB0_182:                               ; %else1159
	orr.16b	v19, v16, v5
	str	q19, [sp, #3456]                ; 16-byte Spill
	tbz	w8, #1, LBB0_183
	b	LBB0_1336
LBB0_183:                               ; %else1165
	ldr	q6, [sp, #3456]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_184
	b	LBB0_1337
LBB0_184:                               ; %else1171
	orr.16b	v19, v18, v5
	str	q19, [sp, #3440]                ; 16-byte Spill
	tbz	w8, #3, LBB0_185
	b	LBB0_1338
LBB0_185:                               ; %else1177
	ldr	q6, [sp, #3440]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_186
	b	LBB0_1339
LBB0_186:                               ; %else1183
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_187
	b	LBB0_1340
LBB0_187:                               ; %else1189
	str	q5, [sp, #1392]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_188
	b	LBB0_1341
LBB0_188:                               ; %else1195
	tbz	w8, #7, LBB0_190
LBB0_189:                               ; %cond.load1197
	mov.d	x8, v5[1]
	ldr	q5, [sp, #9200]                 ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #9200]                 ; 16-byte Spill
LBB0_190:                               ; %else1201
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #84                        ; =0x54
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1376]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10016]               ; 16-byte Spill
	str	q19, [sp, #9184]                ; 16-byte Spill
	tbz	w9, #0, LBB0_191
	b	LBB0_1342
LBB0_191:                               ; %else1208
	orr.16b	v19, v16, v5
	str	q19, [sp, #3424]                ; 16-byte Spill
	tbz	w8, #1, LBB0_192
	b	LBB0_1343
LBB0_192:                               ; %else1214
	ldr	q6, [sp, #3424]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_193
	b	LBB0_1344
LBB0_193:                               ; %else1220
	orr.16b	v19, v18, v5
	str	q19, [sp, #3408]                ; 16-byte Spill
	tbz	w8, #3, LBB0_194
	b	LBB0_1345
LBB0_194:                               ; %else1226
	ldr	q6, [sp, #3408]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_195
	b	LBB0_1346
LBB0_195:                               ; %else1232
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_196
	b	LBB0_1347
LBB0_196:                               ; %else1238
	str	q5, [sp, #1360]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_197
	b	LBB0_1348
LBB0_197:                               ; %else1244
	tbz	w8, #7, LBB0_199
LBB0_198:                               ; %cond.load1246
	mov.d	x8, v5[1]
	ldr	q5, [sp, #9184]                 ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #9184]                 ; 16-byte Spill
LBB0_199:                               ; %else1250
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #88                        ; =0x58
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1344]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #8928]                ; 16-byte Spill
	str	q19, [sp, #10752]               ; 16-byte Spill
	tbz	w9, #0, LBB0_200
	b	LBB0_1349
LBB0_200:                               ; %else1257
	orr.16b	v19, v16, v5
	str	q19, [sp, #3392]                ; 16-byte Spill
	tbz	w8, #1, LBB0_201
	b	LBB0_1350
LBB0_201:                               ; %else1263
	ldr	q6, [sp, #3392]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_202
	b	LBB0_1351
LBB0_202:                               ; %else1269
	orr.16b	v19, v18, v5
	str	q19, [sp, #3376]                ; 16-byte Spill
	tbz	w8, #3, LBB0_203
	b	LBB0_1352
LBB0_203:                               ; %else1275
	ldr	q6, [sp, #3376]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_204
	b	LBB0_1353
LBB0_204:                               ; %else1281
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_205
	b	LBB0_1354
LBB0_205:                               ; %else1287
	str	q5, [sp, #1328]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_206
	b	LBB0_1355
LBB0_206:                               ; %else1293
	tbz	w8, #7, LBB0_208
LBB0_207:                               ; %cond.load1295
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10752]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10752]                ; 16-byte Spill
LBB0_208:                               ; %else1299
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #92                        ; =0x5c
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1312]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10000]               ; 16-byte Spill
	str	q19, [sp, #9168]                ; 16-byte Spill
	tbz	w9, #0, LBB0_209
	b	LBB0_1356
LBB0_209:                               ; %else1306
	orr.16b	v19, v16, v5
	str	q19, [sp, #3360]                ; 16-byte Spill
	tbz	w8, #1, LBB0_210
	b	LBB0_1357
LBB0_210:                               ; %else1312
	ldr	q6, [sp, #3360]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_211
	b	LBB0_1358
LBB0_211:                               ; %else1318
	orr.16b	v19, v18, v5
	str	q19, [sp, #3344]                ; 16-byte Spill
	tbz	w8, #3, LBB0_212
	b	LBB0_1359
LBB0_212:                               ; %else1324
	ldr	q6, [sp, #3344]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_213
	b	LBB0_1360
LBB0_213:                               ; %else1330
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_214
	b	LBB0_1361
LBB0_214:                               ; %else1336
	str	q5, [sp, #1296]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_215
	b	LBB0_1362
LBB0_215:                               ; %else1342
	tbz	w8, #7, LBB0_217
LBB0_216:                               ; %cond.load1344
	mov.d	x8, v5[1]
	ldr	q5, [sp, #9168]                 ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #9168]                 ; 16-byte Spill
LBB0_217:                               ; %else1348
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #96                        ; =0x60
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1280]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #8912]                ; 16-byte Spill
	str	q19, [sp, #10736]               ; 16-byte Spill
	tbz	w9, #0, LBB0_218
	b	LBB0_1363
LBB0_218:                               ; %else1355
	orr.16b	v19, v16, v5
	str	q19, [sp, #3328]                ; 16-byte Spill
	tbz	w8, #1, LBB0_219
	b	LBB0_1364
LBB0_219:                               ; %else1361
	ldr	q6, [sp, #3328]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_220
	b	LBB0_1365
LBB0_220:                               ; %else1367
	orr.16b	v19, v18, v5
	str	q19, [sp, #3312]                ; 16-byte Spill
	tbz	w8, #3, LBB0_221
	b	LBB0_1366
LBB0_221:                               ; %else1373
	ldr	q6, [sp, #3312]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_222
	b	LBB0_1367
LBB0_222:                               ; %else1379
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_223
	b	LBB0_1368
LBB0_223:                               ; %else1385
	str	q5, [sp, #1264]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_224
	b	LBB0_1369
LBB0_224:                               ; %else1391
	tbz	w8, #7, LBB0_226
LBB0_225:                               ; %cond.load1393
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10736]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10736]                ; 16-byte Spill
LBB0_226:                               ; %else1397
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #100                       ; =0x64
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1248]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9984]                ; 16-byte Spill
	str	q19, [sp, #10720]               ; 16-byte Spill
	tbz	w9, #0, LBB0_227
	b	LBB0_1370
LBB0_227:                               ; %else1404
	orr.16b	v19, v16, v5
	str	q19, [sp, #3296]                ; 16-byte Spill
	tbz	w8, #1, LBB0_228
	b	LBB0_1371
LBB0_228:                               ; %else1410
	ldr	q6, [sp, #3296]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_229
	b	LBB0_1372
LBB0_229:                               ; %else1416
	orr.16b	v19, v18, v5
	str	q19, [sp, #3280]                ; 16-byte Spill
	tbz	w8, #3, LBB0_230
	b	LBB0_1373
LBB0_230:                               ; %else1422
	ldr	q6, [sp, #3280]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_231
	b	LBB0_1374
LBB0_231:                               ; %else1428
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_232
	b	LBB0_1375
LBB0_232:                               ; %else1434
	str	q5, [sp, #1232]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_233
	b	LBB0_1376
LBB0_233:                               ; %else1440
	tbz	w8, #7, LBB0_235
LBB0_234:                               ; %cond.load1442
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10720]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10720]                ; 16-byte Spill
LBB0_235:                               ; %else1446
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #104                       ; =0x68
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1216]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9968]                ; 16-byte Spill
	str	q19, [sp, #10704]               ; 16-byte Spill
	tbz	w9, #0, LBB0_236
	b	LBB0_1377
LBB0_236:                               ; %else1453
	orr.16b	v19, v16, v5
	str	q19, [sp, #3264]                ; 16-byte Spill
	tbz	w8, #1, LBB0_237
	b	LBB0_1378
LBB0_237:                               ; %else1459
	ldr	q6, [sp, #3264]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_238
	b	LBB0_1379
LBB0_238:                               ; %else1465
	orr.16b	v19, v18, v5
	str	q19, [sp, #3248]                ; 16-byte Spill
	tbz	w8, #3, LBB0_239
	b	LBB0_1380
LBB0_239:                               ; %else1471
	ldr	q6, [sp, #3248]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_240
	b	LBB0_1381
LBB0_240:                               ; %else1477
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_241
	b	LBB0_1382
LBB0_241:                               ; %else1483
	str	q5, [sp, #1200]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_242
	b	LBB0_1383
LBB0_242:                               ; %else1489
	tbz	w8, #7, LBB0_244
LBB0_243:                               ; %cond.load1491
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10704]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10704]                ; 16-byte Spill
LBB0_244:                               ; %else1495
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #108                       ; =0x6c
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1184]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9952]                ; 16-byte Spill
	str	q19, [sp, #10688]               ; 16-byte Spill
	tbz	w9, #0, LBB0_245
	b	LBB0_1384
LBB0_245:                               ; %else1502
	orr.16b	v19, v16, v5
	str	q19, [sp, #3232]                ; 16-byte Spill
	tbz	w8, #1, LBB0_246
	b	LBB0_1385
LBB0_246:                               ; %else1508
	ldr	q6, [sp, #3232]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_247
	b	LBB0_1386
LBB0_247:                               ; %else1514
	orr.16b	v19, v18, v5
	str	q19, [sp, #3216]                ; 16-byte Spill
	tbz	w8, #3, LBB0_248
	b	LBB0_1387
LBB0_248:                               ; %else1520
	ldr	q6, [sp, #3216]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_249
	b	LBB0_1388
LBB0_249:                               ; %else1526
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_250
	b	LBB0_1389
LBB0_250:                               ; %else1532
	str	q5, [sp, #1168]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_251
	b	LBB0_1390
LBB0_251:                               ; %else1538
	tbz	w8, #7, LBB0_253
LBB0_252:                               ; %cond.load1540
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10688]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10688]                ; 16-byte Spill
LBB0_253:                               ; %else1544
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #112                       ; =0x70
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1152]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9936]                ; 16-byte Spill
	str	q19, [sp, #10672]               ; 16-byte Spill
	tbz	w9, #0, LBB0_254
	b	LBB0_1391
LBB0_254:                               ; %else1551
	orr.16b	v19, v16, v5
	str	q19, [sp, #3200]                ; 16-byte Spill
	tbz	w8, #1, LBB0_255
	b	LBB0_1392
LBB0_255:                               ; %else1557
	ldr	q6, [sp, #3200]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_256
	b	LBB0_1393
LBB0_256:                               ; %else1563
	orr.16b	v19, v18, v5
	str	q19, [sp, #3184]                ; 16-byte Spill
	tbz	w8, #3, LBB0_257
	b	LBB0_1394
LBB0_257:                               ; %else1569
	ldr	q6, [sp, #3184]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_258
	b	LBB0_1395
LBB0_258:                               ; %else1575
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_259
	b	LBB0_1396
LBB0_259:                               ; %else1581
	str	q5, [sp, #1136]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_260
	b	LBB0_1397
LBB0_260:                               ; %else1587
	tbz	w8, #7, LBB0_262
LBB0_261:                               ; %cond.load1589
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10672]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10672]                ; 16-byte Spill
LBB0_262:                               ; %else1593
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #116                       ; =0x74
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1120]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9920]                ; 16-byte Spill
	str	q19, [sp, #10656]               ; 16-byte Spill
	tbz	w9, #0, LBB0_263
	b	LBB0_1398
LBB0_263:                               ; %else1600
	orr.16b	v19, v16, v5
	str	q19, [sp, #3168]                ; 16-byte Spill
	tbz	w8, #1, LBB0_264
	b	LBB0_1399
LBB0_264:                               ; %else1606
	ldr	q6, [sp, #3168]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_265
	b	LBB0_1400
LBB0_265:                               ; %else1612
	orr.16b	v19, v18, v5
	str	q19, [sp, #3152]                ; 16-byte Spill
	tbz	w8, #3, LBB0_266
	b	LBB0_1401
LBB0_266:                               ; %else1618
	ldr	q6, [sp, #3152]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_267
	b	LBB0_1402
LBB0_267:                               ; %else1624
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_268
	b	LBB0_1403
LBB0_268:                               ; %else1630
	str	q5, [sp, #1104]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_269
	b	LBB0_1404
LBB0_269:                               ; %else1636
	tbz	w8, #7, LBB0_271
LBB0_270:                               ; %cond.load1638
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10656]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10656]                ; 16-byte Spill
LBB0_271:                               ; %else1642
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #120                       ; =0x78
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1088]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9904]                ; 16-byte Spill
	str	q19, [sp, #10640]               ; 16-byte Spill
	tbz	w9, #0, LBB0_272
	b	LBB0_1405
LBB0_272:                               ; %else1649
	orr.16b	v19, v16, v5
	str	q19, [sp, #3136]                ; 16-byte Spill
	tbz	w8, #1, LBB0_273
	b	LBB0_1406
LBB0_273:                               ; %else1655
	ldr	q6, [sp, #3136]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_274
	b	LBB0_1407
LBB0_274:                               ; %else1661
	orr.16b	v19, v18, v5
	str	q19, [sp, #3120]                ; 16-byte Spill
	tbz	w8, #3, LBB0_275
	b	LBB0_1408
LBB0_275:                               ; %else1667
	ldr	q6, [sp, #3120]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_276
	b	LBB0_1409
LBB0_276:                               ; %else1673
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_277
	b	LBB0_1410
LBB0_277:                               ; %else1679
	str	q5, [sp, #1072]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_278
	b	LBB0_1411
LBB0_278:                               ; %else1685
	tbz	w8, #7, LBB0_280
LBB0_279:                               ; %cond.load1687
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10640]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10640]                ; 16-byte Spill
LBB0_280:                               ; %else1691
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #124                       ; =0x7c
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1056]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9888]                ; 16-byte Spill
	str	q19, [sp, #10624]               ; 16-byte Spill
	tbz	w9, #0, LBB0_281
	b	LBB0_1412
LBB0_281:                               ; %else1698
	orr.16b	v19, v16, v5
	str	q19, [sp, #3104]                ; 16-byte Spill
	tbz	w8, #1, LBB0_282
	b	LBB0_1413
LBB0_282:                               ; %else1704
	ldr	q6, [sp, #3104]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_283
	b	LBB0_1414
LBB0_283:                               ; %else1710
	orr.16b	v19, v18, v5
	str	q19, [sp, #3088]                ; 16-byte Spill
	tbz	w8, #3, LBB0_284
	b	LBB0_1415
LBB0_284:                               ; %else1716
	ldr	q6, [sp, #3088]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_285
	b	LBB0_1416
LBB0_285:                               ; %else1722
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_286
	b	LBB0_1417
LBB0_286:                               ; %else1728
	str	q5, [sp, #1040]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_287
	b	LBB0_1418
LBB0_287:                               ; %else1734
	tbz	w8, #7, LBB0_289
LBB0_288:                               ; %cond.load1736
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10624]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10624]                ; 16-byte Spill
LBB0_289:                               ; %else1740
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #128                       ; =0x80
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #1024]                 ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9872]                ; 16-byte Spill
	str	q19, [sp, #10608]               ; 16-byte Spill
	tbz	w9, #0, LBB0_290
	b	LBB0_1419
LBB0_290:                               ; %else1747
	orr.16b	v19, v16, v5
	str	q19, [sp, #3072]                ; 16-byte Spill
	tbz	w8, #1, LBB0_291
	b	LBB0_1420
LBB0_291:                               ; %else1753
	ldr	q6, [sp, #3072]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_292
	b	LBB0_1421
LBB0_292:                               ; %else1759
	orr.16b	v19, v18, v5
	str	q19, [sp, #3056]                ; 16-byte Spill
	tbz	w8, #3, LBB0_293
	b	LBB0_1422
LBB0_293:                               ; %else1765
	ldr	q6, [sp, #3056]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_294
	b	LBB0_1423
LBB0_294:                               ; %else1771
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_295
	b	LBB0_1424
LBB0_295:                               ; %else1777
	str	q5, [sp, #1008]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_296
	b	LBB0_1425
LBB0_296:                               ; %else1783
	tbz	w8, #7, LBB0_298
LBB0_297:                               ; %cond.load1785
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10608]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10608]                ; 16-byte Spill
LBB0_298:                               ; %else1789
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #132                       ; =0x84
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #992]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9856]                ; 16-byte Spill
	str	q19, [sp, #10592]               ; 16-byte Spill
	tbz	w9, #0, LBB0_299
	b	LBB0_1426
LBB0_299:                               ; %else1796
	orr.16b	v19, v16, v5
	str	q19, [sp, #3040]                ; 16-byte Spill
	tbz	w8, #1, LBB0_300
	b	LBB0_1427
LBB0_300:                               ; %else1802
	ldr	q6, [sp, #3040]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_301
	b	LBB0_1428
LBB0_301:                               ; %else1808
	orr.16b	v19, v18, v5
	str	q19, [sp, #3024]                ; 16-byte Spill
	tbz	w8, #3, LBB0_302
	b	LBB0_1429
LBB0_302:                               ; %else1814
	ldr	q6, [sp, #3024]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_303
	b	LBB0_1430
LBB0_303:                               ; %else1820
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_304
	b	LBB0_1431
LBB0_304:                               ; %else1826
	str	q5, [sp, #976]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_305
	b	LBB0_1432
LBB0_305:                               ; %else1832
	tbz	w8, #7, LBB0_307
LBB0_306:                               ; %cond.load1834
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10592]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10592]                ; 16-byte Spill
LBB0_307:                               ; %else1838
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #136                       ; =0x88
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #960]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9840]                ; 16-byte Spill
	str	q19, [sp, #10576]               ; 16-byte Spill
	tbz	w9, #0, LBB0_308
	b	LBB0_1433
LBB0_308:                               ; %else1845
	orr.16b	v19, v16, v5
	str	q19, [sp, #3008]                ; 16-byte Spill
	tbz	w8, #1, LBB0_309
	b	LBB0_1434
LBB0_309:                               ; %else1851
	ldr	q6, [sp, #3008]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_310
	b	LBB0_1435
LBB0_310:                               ; %else1857
	orr.16b	v19, v18, v5
	str	q19, [sp, #2992]                ; 16-byte Spill
	tbz	w8, #3, LBB0_311
	b	LBB0_1436
LBB0_311:                               ; %else1863
	ldr	q6, [sp, #2992]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_312
	b	LBB0_1437
LBB0_312:                               ; %else1869
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_313
	b	LBB0_1438
LBB0_313:                               ; %else1875
	str	q5, [sp, #944]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_314
	b	LBB0_1439
LBB0_314:                               ; %else1881
	tbz	w8, #7, LBB0_316
LBB0_315:                               ; %cond.load1883
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10576]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10576]                ; 16-byte Spill
LBB0_316:                               ; %else1887
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #140                       ; =0x8c
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #928]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9824]                ; 16-byte Spill
	str	q17, [sp, #10560]               ; 16-byte Spill
	tbz	w9, #0, LBB0_317
	b	LBB0_1440
LBB0_317:                               ; %else1894
	orr.16b	v19, v16, v5
	str	q19, [sp, #2976]                ; 16-byte Spill
	tbz	w8, #1, LBB0_318
	b	LBB0_1441
LBB0_318:                               ; %else1900
	ldr	q6, [sp, #2976]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_319
	b	LBB0_1442
LBB0_319:                               ; %else1906
	orr.16b	v19, v18, v5
	str	q19, [sp, #2960]                ; 16-byte Spill
	tbz	w8, #3, LBB0_320
	b	LBB0_1443
LBB0_320:                               ; %else1912
	ldr	q6, [sp, #2960]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_321
	b	LBB0_1444
LBB0_321:                               ; %else1918
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_322
	b	LBB0_1445
LBB0_322:                               ; %else1924
	str	q5, [sp, #912]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_323
	b	LBB0_1446
LBB0_323:                               ; %else1930
	tbz	w8, #7, LBB0_325
LBB0_324:                               ; %cond.load1932
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10560]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10560]                ; 16-byte Spill
LBB0_325:                               ; %else1936
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #144                       ; =0x90
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #896]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9808]                ; 16-byte Spill
	str	q17, [sp, #10544]               ; 16-byte Spill
	tbz	w9, #0, LBB0_326
	b	LBB0_1447
LBB0_326:                               ; %else1943
	orr.16b	v19, v16, v5
	str	q19, [sp, #2944]                ; 16-byte Spill
	tbz	w8, #1, LBB0_327
	b	LBB0_1448
LBB0_327:                               ; %else1949
	ldr	q6, [sp, #2944]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_328
	b	LBB0_1449
LBB0_328:                               ; %else1955
	orr.16b	v19, v18, v5
	str	q19, [sp, #2928]                ; 16-byte Spill
	tbz	w8, #3, LBB0_329
	b	LBB0_1450
LBB0_329:                               ; %else1961
	ldr	q6, [sp, #2928]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_330
	b	LBB0_1451
LBB0_330:                               ; %else1967
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_331
	b	LBB0_1452
LBB0_331:                               ; %else1973
	str	q5, [sp, #880]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_332
	b	LBB0_1453
LBB0_332:                               ; %else1979
	tbz	w8, #7, LBB0_334
LBB0_333:                               ; %cond.load1981
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10544]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10544]                ; 16-byte Spill
LBB0_334:                               ; %else1985
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #148                       ; =0x94
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #864]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9792]                ; 16-byte Spill
	str	q17, [sp, #10528]               ; 16-byte Spill
	tbz	w9, #0, LBB0_335
	b	LBB0_1454
LBB0_335:                               ; %else1992
	orr.16b	v19, v16, v5
	str	q19, [sp, #2912]                ; 16-byte Spill
	tbz	w8, #1, LBB0_336
	b	LBB0_1455
LBB0_336:                               ; %else1998
	ldr	q6, [sp, #2912]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_337
	b	LBB0_1456
LBB0_337:                               ; %else2004
	orr.16b	v19, v18, v5
	str	q19, [sp, #2896]                ; 16-byte Spill
	tbz	w8, #3, LBB0_338
	b	LBB0_1457
LBB0_338:                               ; %else2010
	ldr	q6, [sp, #2896]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_339
	b	LBB0_1458
LBB0_339:                               ; %else2016
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_340
	b	LBB0_1459
LBB0_340:                               ; %else2022
	str	q5, [sp, #848]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_341
	b	LBB0_1460
LBB0_341:                               ; %else2028
	tbz	w8, #7, LBB0_343
LBB0_342:                               ; %cond.load2030
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10528]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10528]                ; 16-byte Spill
LBB0_343:                               ; %else2034
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #152                       ; =0x98
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #832]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9776]                ; 16-byte Spill
	str	q17, [sp, #10512]               ; 16-byte Spill
	tbz	w9, #0, LBB0_344
	b	LBB0_1461
LBB0_344:                               ; %else2041
	orr.16b	v19, v16, v5
	str	q19, [sp, #2880]                ; 16-byte Spill
	tbz	w8, #1, LBB0_345
	b	LBB0_1462
LBB0_345:                               ; %else2047
	ldr	q6, [sp, #2880]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_346
	b	LBB0_1463
LBB0_346:                               ; %else2053
	orr.16b	v19, v18, v5
	str	q19, [sp, #2864]                ; 16-byte Spill
	tbz	w8, #3, LBB0_347
	b	LBB0_1464
LBB0_347:                               ; %else2059
	ldr	q6, [sp, #2864]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_348
	b	LBB0_1465
LBB0_348:                               ; %else2065
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_349
	b	LBB0_1466
LBB0_349:                               ; %else2071
	str	q5, [sp, #816]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_350
	b	LBB0_1467
LBB0_350:                               ; %else2077
	tbz	w8, #7, LBB0_352
LBB0_351:                               ; %cond.load2079
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10512]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10512]                ; 16-byte Spill
LBB0_352:                               ; %else2083
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #156                       ; =0x9c
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #800]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9760]                ; 16-byte Spill
	str	q17, [sp, #10496]               ; 16-byte Spill
	tbz	w9, #0, LBB0_353
	b	LBB0_1468
LBB0_353:                               ; %else2090
	orr.16b	v19, v16, v5
	str	q19, [sp, #2848]                ; 16-byte Spill
	tbz	w8, #1, LBB0_354
	b	LBB0_1469
LBB0_354:                               ; %else2096
	ldr	q6, [sp, #2848]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_355
	b	LBB0_1470
LBB0_355:                               ; %else2102
	orr.16b	v19, v18, v5
	str	q19, [sp, #2832]                ; 16-byte Spill
	tbz	w8, #3, LBB0_356
	b	LBB0_1471
LBB0_356:                               ; %else2108
	ldr	q6, [sp, #2832]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_357
	b	LBB0_1472
LBB0_357:                               ; %else2114
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_358
	b	LBB0_1473
LBB0_358:                               ; %else2120
	str	q5, [sp, #784]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_359
	b	LBB0_1474
LBB0_359:                               ; %else2126
	tbz	w8, #7, LBB0_361
LBB0_360:                               ; %cond.load2128
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10496]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10496]                ; 16-byte Spill
LBB0_361:                               ; %else2132
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #160                       ; =0xa0
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #768]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9744]                ; 16-byte Spill
	str	q17, [sp, #10480]               ; 16-byte Spill
	tbz	w9, #0, LBB0_362
	b	LBB0_1475
LBB0_362:                               ; %else2139
	orr.16b	v19, v16, v5
	str	q19, [sp, #2816]                ; 16-byte Spill
	tbz	w8, #1, LBB0_363
	b	LBB0_1476
LBB0_363:                               ; %else2145
	ldr	q6, [sp, #2816]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_364
	b	LBB0_1477
LBB0_364:                               ; %else2151
	orr.16b	v19, v18, v5
	str	q19, [sp, #2800]                ; 16-byte Spill
	tbz	w8, #3, LBB0_365
	b	LBB0_1478
LBB0_365:                               ; %else2157
	ldr	q6, [sp, #2800]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_366
	b	LBB0_1479
LBB0_366:                               ; %else2163
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_367
	b	LBB0_1480
LBB0_367:                               ; %else2169
	str	q5, [sp, #752]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_368
	b	LBB0_1481
LBB0_368:                               ; %else2175
	tbz	w8, #7, LBB0_370
LBB0_369:                               ; %cond.load2177
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10480]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10480]                ; 16-byte Spill
LBB0_370:                               ; %else2181
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #164                       ; =0xa4
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #736]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9728]                ; 16-byte Spill
	str	q17, [sp, #10464]               ; 16-byte Spill
	tbz	w9, #0, LBB0_371
	b	LBB0_1482
LBB0_371:                               ; %else2188
	orr.16b	v19, v16, v5
	str	q19, [sp, #2784]                ; 16-byte Spill
	tbz	w8, #1, LBB0_372
	b	LBB0_1483
LBB0_372:                               ; %else2194
	ldr	q6, [sp, #2784]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_373
	b	LBB0_1484
LBB0_373:                               ; %else2200
	orr.16b	v19, v18, v5
	str	q19, [sp, #2768]                ; 16-byte Spill
	tbz	w8, #3, LBB0_374
	b	LBB0_1485
LBB0_374:                               ; %else2206
	ldr	q6, [sp, #2768]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_375
	b	LBB0_1486
LBB0_375:                               ; %else2212
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_376
	b	LBB0_1487
LBB0_376:                               ; %else2218
	str	q5, [sp, #720]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_377
	b	LBB0_1488
LBB0_377:                               ; %else2224
	tbz	w8, #7, LBB0_379
LBB0_378:                               ; %cond.load2226
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10464]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10464]                ; 16-byte Spill
LBB0_379:                               ; %else2230
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #168                       ; =0xa8
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #704]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9712]                ; 16-byte Spill
	str	q17, [sp, #10448]               ; 16-byte Spill
	tbz	w9, #0, LBB0_380
	b	LBB0_1489
LBB0_380:                               ; %else2237
	orr.16b	v19, v16, v5
	str	q19, [sp, #2752]                ; 16-byte Spill
	tbz	w8, #1, LBB0_381
	b	LBB0_1490
LBB0_381:                               ; %else2243
	ldr	q6, [sp, #2752]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_382
	b	LBB0_1491
LBB0_382:                               ; %else2249
	orr.16b	v19, v18, v5
	str	q19, [sp, #2736]                ; 16-byte Spill
	tbz	w8, #3, LBB0_383
	b	LBB0_1492
LBB0_383:                               ; %else2255
	ldr	q6, [sp, #2736]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_384
	b	LBB0_1493
LBB0_384:                               ; %else2261
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_385
	b	LBB0_1494
LBB0_385:                               ; %else2267
	str	q5, [sp, #688]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_386
	b	LBB0_1495
LBB0_386:                               ; %else2273
	tbz	w8, #7, LBB0_388
LBB0_387:                               ; %cond.load2275
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10448]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10448]                ; 16-byte Spill
LBB0_388:                               ; %else2279
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #172                       ; =0xac
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #672]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9696]                ; 16-byte Spill
	str	q17, [sp, #10432]               ; 16-byte Spill
	tbz	w9, #0, LBB0_389
	b	LBB0_1496
LBB0_389:                               ; %else2286
	orr.16b	v19, v16, v5
	str	q19, [sp, #2720]                ; 16-byte Spill
	tbz	w8, #1, LBB0_390
	b	LBB0_1497
LBB0_390:                               ; %else2292
	ldr	q6, [sp, #2720]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_391
	b	LBB0_1498
LBB0_391:                               ; %else2298
	orr.16b	v19, v18, v5
	str	q19, [sp, #2704]                ; 16-byte Spill
	tbz	w8, #3, LBB0_392
	b	LBB0_1499
LBB0_392:                               ; %else2304
	ldr	q6, [sp, #2704]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_393
	b	LBB0_1500
LBB0_393:                               ; %else2310
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_394
	b	LBB0_1501
LBB0_394:                               ; %else2316
	str	q5, [sp, #656]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_395
	b	LBB0_1502
LBB0_395:                               ; %else2322
	tbz	w8, #7, LBB0_397
LBB0_396:                               ; %cond.load2324
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10432]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10432]                ; 16-byte Spill
LBB0_397:                               ; %else2328
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #176                       ; =0xb0
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #640]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9680]                ; 16-byte Spill
	str	q17, [sp, #10416]               ; 16-byte Spill
	tbz	w9, #0, LBB0_398
	b	LBB0_1503
LBB0_398:                               ; %else2335
	orr.16b	v19, v16, v5
	str	q19, [sp, #2688]                ; 16-byte Spill
	tbz	w8, #1, LBB0_399
	b	LBB0_1504
LBB0_399:                               ; %else2341
	ldr	q6, [sp, #2688]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_400
	b	LBB0_1505
LBB0_400:                               ; %else2347
	orr.16b	v19, v18, v5
	str	q19, [sp, #2672]                ; 16-byte Spill
	tbz	w8, #3, LBB0_401
	b	LBB0_1506
LBB0_401:                               ; %else2353
	ldr	q6, [sp, #2672]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_402
	b	LBB0_1507
LBB0_402:                               ; %else2359
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_403
	b	LBB0_1508
LBB0_403:                               ; %else2365
	str	q5, [sp, #624]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_404
	b	LBB0_1509
LBB0_404:                               ; %else2371
	tbz	w8, #7, LBB0_406
LBB0_405:                               ; %cond.load2373
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10416]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10416]                ; 16-byte Spill
LBB0_406:                               ; %else2377
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #180                       ; =0xb4
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #608]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9664]                ; 16-byte Spill
	str	q17, [sp, #10400]               ; 16-byte Spill
	tbz	w9, #0, LBB0_407
	b	LBB0_1510
LBB0_407:                               ; %else2384
	orr.16b	v19, v16, v5
	str	q19, [sp, #2656]                ; 16-byte Spill
	tbz	w8, #1, LBB0_408
	b	LBB0_1511
LBB0_408:                               ; %else2390
	ldr	q6, [sp, #2656]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_409
	b	LBB0_1512
LBB0_409:                               ; %else2396
	orr.16b	v19, v18, v5
	str	q19, [sp, #2640]                ; 16-byte Spill
	tbz	w8, #3, LBB0_410
	b	LBB0_1513
LBB0_410:                               ; %else2402
	ldr	q6, [sp, #2640]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_411
	b	LBB0_1514
LBB0_411:                               ; %else2408
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_412
	b	LBB0_1515
LBB0_412:                               ; %else2414
	str	q5, [sp, #592]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_413
	b	LBB0_1516
LBB0_413:                               ; %else2420
	tbz	w8, #7, LBB0_415
LBB0_414:                               ; %cond.load2422
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10400]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10400]                ; 16-byte Spill
LBB0_415:                               ; %else2426
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #184                       ; =0xb8
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #576]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9648]                ; 16-byte Spill
	str	q17, [sp, #10384]               ; 16-byte Spill
	tbz	w9, #0, LBB0_416
	b	LBB0_1517
LBB0_416:                               ; %else2433
	orr.16b	v19, v16, v5
	str	q19, [sp, #2624]                ; 16-byte Spill
	tbz	w8, #1, LBB0_417
	b	LBB0_1518
LBB0_417:                               ; %else2439
	ldr	q6, [sp, #2624]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_418
	b	LBB0_1519
LBB0_418:                               ; %else2445
	orr.16b	v19, v18, v5
	str	q19, [sp, #2608]                ; 16-byte Spill
	tbz	w8, #3, LBB0_419
	b	LBB0_1520
LBB0_419:                               ; %else2451
	ldr	q6, [sp, #2608]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_420
	b	LBB0_1521
LBB0_420:                               ; %else2457
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_421
	b	LBB0_1522
LBB0_421:                               ; %else2463
	str	q5, [sp, #560]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_422
	b	LBB0_1523
LBB0_422:                               ; %else2469
	tbz	w8, #7, LBB0_424
LBB0_423:                               ; %cond.load2471
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10384]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10384]                ; 16-byte Spill
LBB0_424:                               ; %else2475
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #188                       ; =0xbc
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #544]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9632]                ; 16-byte Spill
	str	q17, [sp, #10368]               ; 16-byte Spill
	tbz	w9, #0, LBB0_425
	b	LBB0_1524
LBB0_425:                               ; %else2482
	orr.16b	v19, v16, v5
	str	q19, [sp, #2592]                ; 16-byte Spill
	tbz	w8, #1, LBB0_426
	b	LBB0_1525
LBB0_426:                               ; %else2488
	ldr	q6, [sp, #2592]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_427
	b	LBB0_1526
LBB0_427:                               ; %else2494
	orr.16b	v19, v18, v5
	str	q19, [sp, #2576]                ; 16-byte Spill
	tbz	w8, #3, LBB0_428
	b	LBB0_1527
LBB0_428:                               ; %else2500
	ldr	q6, [sp, #2576]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_429
	b	LBB0_1528
LBB0_429:                               ; %else2506
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_430
	b	LBB0_1529
LBB0_430:                               ; %else2512
	str	q5, [sp, #528]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_431
	b	LBB0_1530
LBB0_431:                               ; %else2518
	tbz	w8, #7, LBB0_433
LBB0_432:                               ; %cond.load2520
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10368]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10368]                ; 16-byte Spill
LBB0_433:                               ; %else2524
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #192                       ; =0xc0
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #512]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9616]                ; 16-byte Spill
	str	q17, [sp, #10352]               ; 16-byte Spill
	tbz	w9, #0, LBB0_434
	b	LBB0_1531
LBB0_434:                               ; %else2531
	orr.16b	v19, v16, v5
	str	q19, [sp, #2560]                ; 16-byte Spill
	tbz	w8, #1, LBB0_435
	b	LBB0_1532
LBB0_435:                               ; %else2537
	ldr	q6, [sp, #2560]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_436
	b	LBB0_1533
LBB0_436:                               ; %else2543
	orr.16b	v19, v18, v5
	str	q19, [sp, #2544]                ; 16-byte Spill
	tbz	w8, #3, LBB0_437
	b	LBB0_1534
LBB0_437:                               ; %else2549
	ldr	q6, [sp, #2544]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_438
	b	LBB0_1535
LBB0_438:                               ; %else2555
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_439
	b	LBB0_1536
LBB0_439:                               ; %else2561
	str	q5, [sp, #496]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_440
	b	LBB0_1537
LBB0_440:                               ; %else2567
	tbz	w8, #7, LBB0_442
LBB0_441:                               ; %cond.load2569
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10352]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10352]                ; 16-byte Spill
LBB0_442:                               ; %else2573
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #196                       ; =0xc4
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #480]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9600]                ; 16-byte Spill
	str	q17, [sp, #10336]               ; 16-byte Spill
	tbz	w9, #0, LBB0_443
	b	LBB0_1538
LBB0_443:                               ; %else2580
	orr.16b	v19, v16, v5
	str	q19, [sp, #2528]                ; 16-byte Spill
	tbz	w8, #1, LBB0_444
	b	LBB0_1539
LBB0_444:                               ; %else2586
	ldr	q6, [sp, #2528]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_445
	b	LBB0_1540
LBB0_445:                               ; %else2592
	orr.16b	v19, v18, v5
	str	q19, [sp, #2512]                ; 16-byte Spill
	tbz	w8, #3, LBB0_446
	b	LBB0_1541
LBB0_446:                               ; %else2598
	ldr	q6, [sp, #2512]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_447
	b	LBB0_1542
LBB0_447:                               ; %else2604
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_448
	b	LBB0_1543
LBB0_448:                               ; %else2610
	str	q5, [sp, #464]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_449
	b	LBB0_1544
LBB0_449:                               ; %else2616
	tbz	w8, #7, LBB0_451
LBB0_450:                               ; %cond.load2618
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10336]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10336]                ; 16-byte Spill
LBB0_451:                               ; %else2622
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #200                       ; =0xc8
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #448]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9584]                ; 16-byte Spill
	str	q17, [sp, #10320]               ; 16-byte Spill
	tbz	w9, #0, LBB0_452
	b	LBB0_1545
LBB0_452:                               ; %else2629
	orr.16b	v19, v16, v5
	str	q19, [sp, #2496]                ; 16-byte Spill
	tbz	w8, #1, LBB0_453
	b	LBB0_1546
LBB0_453:                               ; %else2635
	ldr	q6, [sp, #2496]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_454
	b	LBB0_1547
LBB0_454:                               ; %else2641
	orr.16b	v19, v18, v5
	str	q19, [sp, #2480]                ; 16-byte Spill
	tbz	w8, #3, LBB0_455
	b	LBB0_1548
LBB0_455:                               ; %else2647
	ldr	q6, [sp, #2480]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_456
	b	LBB0_1549
LBB0_456:                               ; %else2653
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_457
	b	LBB0_1550
LBB0_457:                               ; %else2659
	str	q5, [sp, #432]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_458
	b	LBB0_1551
LBB0_458:                               ; %else2665
	tbz	w8, #7, LBB0_460
LBB0_459:                               ; %cond.load2667
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10320]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10320]                ; 16-byte Spill
LBB0_460:                               ; %else2671
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #204                       ; =0xcc
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #416]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9568]                ; 16-byte Spill
	str	q17, [sp, #10304]               ; 16-byte Spill
	tbz	w9, #0, LBB0_461
	b	LBB0_1552
LBB0_461:                               ; %else2678
	orr.16b	v19, v16, v5
	str	q19, [sp, #2464]                ; 16-byte Spill
	tbz	w8, #1, LBB0_462
	b	LBB0_1553
LBB0_462:                               ; %else2684
	ldr	q6, [sp, #2464]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_463
	b	LBB0_1554
LBB0_463:                               ; %else2690
	orr.16b	v19, v18, v5
	str	q19, [sp, #2448]                ; 16-byte Spill
	tbz	w8, #3, LBB0_464
	b	LBB0_1555
LBB0_464:                               ; %else2696
	ldr	q6, [sp, #2448]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_465
	b	LBB0_1556
LBB0_465:                               ; %else2702
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_466
	b	LBB0_1557
LBB0_466:                               ; %else2708
	str	q5, [sp, #400]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_467
	b	LBB0_1558
LBB0_467:                               ; %else2714
	tbz	w8, #7, LBB0_469
LBB0_468:                               ; %cond.load2716
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10304]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10304]                ; 16-byte Spill
LBB0_469:                               ; %else2720
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #208                       ; =0xd0
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #384]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9552]                ; 16-byte Spill
	str	q17, [sp, #10288]               ; 16-byte Spill
	tbz	w9, #0, LBB0_470
	b	LBB0_1559
LBB0_470:                               ; %else2727
	orr.16b	v19, v16, v5
	str	q19, [sp, #2432]                ; 16-byte Spill
	tbz	w8, #1, LBB0_471
	b	LBB0_1560
LBB0_471:                               ; %else2733
	ldr	q6, [sp, #2432]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_472
	b	LBB0_1561
LBB0_472:                               ; %else2739
	orr.16b	v19, v18, v5
	str	q19, [sp, #2416]                ; 16-byte Spill
	tbz	w8, #3, LBB0_473
	b	LBB0_1562
LBB0_473:                               ; %else2745
	ldr	q6, [sp, #2416]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_474
	b	LBB0_1563
LBB0_474:                               ; %else2751
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_475
	b	LBB0_1564
LBB0_475:                               ; %else2757
	str	q5, [sp, #368]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_476
	b	LBB0_1565
LBB0_476:                               ; %else2763
	tbz	w8, #7, LBB0_478
LBB0_477:                               ; %cond.load2765
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10288]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10288]                ; 16-byte Spill
LBB0_478:                               ; %else2769
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #212                       ; =0xd4
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #352]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9536]                ; 16-byte Spill
	str	q17, [sp, #10272]               ; 16-byte Spill
	tbz	w9, #0, LBB0_479
	b	LBB0_1566
LBB0_479:                               ; %else2776
	orr.16b	v19, v16, v5
	str	q19, [sp, #2400]                ; 16-byte Spill
	tbz	w8, #1, LBB0_480
	b	LBB0_1567
LBB0_480:                               ; %else2782
	ldr	q6, [sp, #2400]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_481
	b	LBB0_1568
LBB0_481:                               ; %else2788
	orr.16b	v19, v18, v5
	str	q19, [sp, #2384]                ; 16-byte Spill
	tbz	w8, #3, LBB0_482
	b	LBB0_1569
LBB0_482:                               ; %else2794
	ldr	q6, [sp, #2384]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_483
	b	LBB0_1570
LBB0_483:                               ; %else2800
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_484
	b	LBB0_1571
LBB0_484:                               ; %else2806
	str	q5, [sp, #336]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_485
	b	LBB0_1572
LBB0_485:                               ; %else2812
	tbz	w8, #7, LBB0_487
LBB0_486:                               ; %cond.load2814
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10272]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10272]                ; 16-byte Spill
LBB0_487:                               ; %else2818
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #216                       ; =0xd8
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #320]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9520]                ; 16-byte Spill
	str	q17, [sp, #10256]               ; 16-byte Spill
	tbz	w9, #0, LBB0_488
	b	LBB0_1573
LBB0_488:                               ; %else2825
	orr.16b	v19, v16, v5
	str	q19, [sp, #2368]                ; 16-byte Spill
	tbz	w8, #1, LBB0_489
	b	LBB0_1574
LBB0_489:                               ; %else2831
	ldr	q6, [sp, #2368]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_490
	b	LBB0_1575
LBB0_490:                               ; %else2837
	orr.16b	v19, v18, v5
	str	q19, [sp, #2352]                ; 16-byte Spill
	tbz	w8, #3, LBB0_491
	b	LBB0_1576
LBB0_491:                               ; %else2843
	ldr	q6, [sp, #2352]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_492
	b	LBB0_1577
LBB0_492:                               ; %else2849
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_493
	b	LBB0_1578
LBB0_493:                               ; %else2855
	str	q5, [sp, #304]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_494
	b	LBB0_1579
LBB0_494:                               ; %else2861
	tbz	w8, #7, LBB0_496
LBB0_495:                               ; %cond.load2863
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10256]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10256]                ; 16-byte Spill
LBB0_496:                               ; %else2867
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #220                       ; =0xdc
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #288]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9504]                ; 16-byte Spill
	str	q17, [sp, #10240]               ; 16-byte Spill
	tbz	w9, #0, LBB0_497
	b	LBB0_1580
LBB0_497:                               ; %else2874
	orr.16b	v19, v16, v5
	str	q19, [sp, #2336]                ; 16-byte Spill
	tbz	w8, #1, LBB0_498
	b	LBB0_1581
LBB0_498:                               ; %else2880
	ldr	q6, [sp, #2336]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_499
	b	LBB0_1582
LBB0_499:                               ; %else2886
	orr.16b	v19, v18, v5
	str	q19, [sp, #2320]                ; 16-byte Spill
	tbz	w8, #3, LBB0_500
	b	LBB0_1583
LBB0_500:                               ; %else2892
	ldr	q6, [sp, #2320]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_501
	b	LBB0_1584
LBB0_501:                               ; %else2898
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_502
	b	LBB0_1585
LBB0_502:                               ; %else2904
	str	q5, [sp, #272]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_503
	b	LBB0_1586
LBB0_503:                               ; %else2910
	tbz	w8, #7, LBB0_505
LBB0_504:                               ; %cond.load2912
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10240]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10240]                ; 16-byte Spill
LBB0_505:                               ; %else2916
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #224                       ; =0xe0
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #256]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9488]                ; 16-byte Spill
	str	q17, [sp, #10224]               ; 16-byte Spill
	tbz	w9, #0, LBB0_506
	b	LBB0_1587
LBB0_506:                               ; %else2923
	orr.16b	v19, v16, v5
	str	q19, [sp, #2304]                ; 16-byte Spill
	tbz	w8, #1, LBB0_507
	b	LBB0_1588
LBB0_507:                               ; %else2929
	ldr	q6, [sp, #2304]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_508
	b	LBB0_1589
LBB0_508:                               ; %else2935
	orr.16b	v19, v18, v5
	str	q19, [sp, #2288]                ; 16-byte Spill
	tbz	w8, #3, LBB0_509
	b	LBB0_1590
LBB0_509:                               ; %else2941
	ldr	q6, [sp, #2288]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_510
	b	LBB0_1591
LBB0_510:                               ; %else2947
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_511
	b	LBB0_1592
LBB0_511:                               ; %else2953
	str	q5, [sp, #240]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_512
	b	LBB0_1593
LBB0_512:                               ; %else2959
	tbz	w8, #7, LBB0_514
LBB0_513:                               ; %cond.load2961
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10224]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10224]                ; 16-byte Spill
LBB0_514:                               ; %else2965
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #228                       ; =0xe4
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #224]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9472]                ; 16-byte Spill
	str	q17, [sp, #10208]               ; 16-byte Spill
	tbz	w9, #0, LBB0_515
	b	LBB0_1594
LBB0_515:                               ; %else2972
	orr.16b	v19, v16, v5
	str	q19, [sp, #2272]                ; 16-byte Spill
	tbz	w8, #1, LBB0_516
	b	LBB0_1595
LBB0_516:                               ; %else2978
	ldr	q6, [sp, #2272]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_517
	b	LBB0_1596
LBB0_517:                               ; %else2984
	orr.16b	v19, v18, v5
	str	q19, [sp, #2256]                ; 16-byte Spill
	tbz	w8, #3, LBB0_518
	b	LBB0_1597
LBB0_518:                               ; %else2990
	ldr	q6, [sp, #2256]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_519
	b	LBB0_1598
LBB0_519:                               ; %else2996
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_520
	b	LBB0_1599
LBB0_520:                               ; %else3002
	str	q5, [sp, #208]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_521
	b	LBB0_1600
LBB0_521:                               ; %else3008
	tbz	w8, #7, LBB0_523
LBB0_522:                               ; %cond.load3010
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10208]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10208]                ; 16-byte Spill
LBB0_523:                               ; %else3014
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #232                       ; =0xe8
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #192]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9456]                ; 16-byte Spill
	str	q17, [sp, #10192]               ; 16-byte Spill
	tbz	w9, #0, LBB0_524
	b	LBB0_1601
LBB0_524:                               ; %else3021
	orr.16b	v19, v16, v5
	str	q19, [sp, #2240]                ; 16-byte Spill
	tbz	w8, #1, LBB0_525
	b	LBB0_1602
LBB0_525:                               ; %else3027
	ldr	q6, [sp, #2240]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_526
	b	LBB0_1603
LBB0_526:                               ; %else3033
	orr.16b	v19, v18, v5
	str	q19, [sp, #2224]                ; 16-byte Spill
	tbz	w8, #3, LBB0_527
	b	LBB0_1604
LBB0_527:                               ; %else3039
	ldr	q6, [sp, #2224]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_528
	b	LBB0_1605
LBB0_528:                               ; %else3045
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_529
	b	LBB0_1606
LBB0_529:                               ; %else3051
	str	q5, [sp, #176]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_530
	b	LBB0_1607
LBB0_530:                               ; %else3057
	tbz	w8, #7, LBB0_532
LBB0_531:                               ; %cond.load3059
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10192]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10192]                ; 16-byte Spill
LBB0_532:                               ; %else3063
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #236                       ; =0xec
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #160]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9440]                ; 16-byte Spill
	str	q17, [sp, #10176]               ; 16-byte Spill
	tbz	w9, #0, LBB0_533
	b	LBB0_1608
LBB0_533:                               ; %else3070
	orr.16b	v19, v16, v5
	str	q19, [sp, #2208]                ; 16-byte Spill
	tbz	w8, #1, LBB0_534
	b	LBB0_1609
LBB0_534:                               ; %else3076
	ldr	q6, [sp, #2208]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_535
	b	LBB0_1610
LBB0_535:                               ; %else3082
	orr.16b	v19, v18, v5
	str	q19, [sp, #2192]                ; 16-byte Spill
	tbz	w8, #3, LBB0_536
	b	LBB0_1611
LBB0_536:                               ; %else3088
	ldr	q6, [sp, #2192]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_537
	b	LBB0_1612
LBB0_537:                               ; %else3094
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_538
	b	LBB0_1613
LBB0_538:                               ; %else3100
	str	q5, [sp, #144]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_539
	b	LBB0_1614
LBB0_539:                               ; %else3106
	tbz	w8, #7, LBB0_541
LBB0_540:                               ; %cond.load3108
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10176]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10176]                ; 16-byte Spill
LBB0_541:                               ; %else3112
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #240                       ; =0xf0
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #128]                  ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9424]                ; 16-byte Spill
	str	q17, [sp, #10160]               ; 16-byte Spill
	tbz	w9, #0, LBB0_542
	b	LBB0_1615
LBB0_542:                               ; %else3119
	orr.16b	v19, v16, v5
	str	q19, [sp, #2176]                ; 16-byte Spill
	tbz	w8, #1, LBB0_543
	b	LBB0_1616
LBB0_543:                               ; %else3125
	ldr	q6, [sp, #2176]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_544
	b	LBB0_1617
LBB0_544:                               ; %else3131
	orr.16b	v19, v18, v5
	str	q19, [sp, #2160]                ; 16-byte Spill
	tbz	w8, #3, LBB0_545
	b	LBB0_1618
LBB0_545:                               ; %else3137
	ldr	q6, [sp, #2160]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_546
	b	LBB0_1619
LBB0_546:                               ; %else3143
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_547
	b	LBB0_1620
LBB0_547:                               ; %else3149
	str	q5, [sp, #112]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_548
	b	LBB0_1621
LBB0_548:                               ; %else3155
	tbz	w8, #7, LBB0_550
LBB0_549:                               ; %cond.load3157
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10160]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10160]                ; 16-byte Spill
LBB0_550:                               ; %else3161
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #244                       ; =0xf4
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #96]                   ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9408]                ; 16-byte Spill
	str	q17, [sp, #10144]               ; 16-byte Spill
	tbz	w9, #0, LBB0_551
	b	LBB0_1622
LBB0_551:                               ; %else3168
	orr.16b	v19, v16, v5
	str	q19, [sp, #2144]                ; 16-byte Spill
	tbz	w8, #1, LBB0_552
	b	LBB0_1623
LBB0_552:                               ; %else3174
	ldr	q6, [sp, #2144]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_553
	b	LBB0_1624
LBB0_553:                               ; %else3180
	orr.16b	v19, v18, v5
	str	q19, [sp, #2128]                ; 16-byte Spill
	tbz	w8, #3, LBB0_554
	b	LBB0_1625
LBB0_554:                               ; %else3186
	ldr	q6, [sp, #2128]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_555
	b	LBB0_1626
LBB0_555:                               ; %else3192
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_556
	b	LBB0_1627
LBB0_556:                               ; %else3198
	str	q5, [sp, #80]                   ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_557
	b	LBB0_1628
LBB0_557:                               ; %else3204
	tbz	w8, #7, LBB0_559
LBB0_558:                               ; %cond.load3206
	mov.d	x8, v5[1]
	ldr	q5, [sp, #10144]                ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #10144]                ; 16-byte Spill
LBB0_559:                               ; %else3210
	fmov	w9, s0
	and	w8, w9, #0xff
	mov	w10, #248                       ; =0xf8
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #64]                   ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #8704]                ; 16-byte Spill
	str	q17, [sp, #9152]                ; 16-byte Spill
	tbz	w9, #0, LBB0_560
	b	LBB0_1629
LBB0_560:                               ; %else3217
	orr.16b	v19, v16, v5
	str	q19, [sp, #2112]                ; 16-byte Spill
	tbz	w8, #1, LBB0_561
	b	LBB0_1630
LBB0_561:                               ; %else3223
	ldr	q6, [sp, #2112]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #2, LBB0_562
	b	LBB0_1631
LBB0_562:                               ; %else3229
	orr.16b	v19, v18, v5
	str	q19, [sp, #2096]                ; 16-byte Spill
	tbz	w8, #3, LBB0_563
	b	LBB0_1632
LBB0_563:                               ; %else3235
	ldr	q6, [sp, #2096]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w8, #4, LBB0_564
	b	LBB0_1633
LBB0_564:                               ; %else3241
	orr.16b	v5, v22, v5
	tbz	w8, #5, LBB0_565
	b	LBB0_1634
LBB0_565:                               ; %else3247
	str	q5, [sp, #48]                   ; 16-byte Spill
	add.2d	v5, v4, v5
	tbz	w8, #6, LBB0_566
	b	LBB0_1635
LBB0_566:                               ; %else3253
	tbz	w8, #7, LBB0_568
LBB0_567:                               ; %cond.load3255
	mov.d	x8, v5[1]
	ldr	q5, [sp, #9152]                 ; 16-byte Reload
	ld1.s	{ v5 }[3], [x8]
	str	q5, [sp, #9152]                 ; 16-byte Spill
LBB0_568:                               ; %else3259
	fmov	w8, s0
	and	w9, w8, #0xff
	mov	w10, #252                       ; =0xfc
	dup.2d	v5, x10
	orr.16b	v6, v7, v5
	str	q6, [sp, #32]                   ; 16-byte Spill
	add.2d	v6, v4, v6
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #8896]                ; 16-byte Spill
	str	q17, [sp, #10128]               ; 16-byte Spill
	tbz	w8, #0, LBB0_569
	b	LBB0_1636
LBB0_569:                               ; %else3266
	orr.16b	v19, v16, v5
	str	q19, [sp, #2080]                ; 16-byte Spill
	tbz	w9, #1, LBB0_570
	b	LBB0_1637
LBB0_570:                               ; %else3272
	ldr	q6, [sp, #2080]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w9, #2, LBB0_571
	b	LBB0_1638
LBB0_571:                               ; %else3278
	orr.16b	v19, v18, v5
	str	q19, [sp, #2064]                ; 16-byte Spill
	tbz	w9, #3, LBB0_572
	b	LBB0_1639
LBB0_572:                               ; %else3284
	ldr	q6, [sp, #2064]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbz	w9, #4, LBB0_573
	b	LBB0_1640
LBB0_573:                               ; %else3290
	orr.16b	v5, v22, v5
	tbz	w9, #5, LBB0_574
	b	LBB0_1641
LBB0_574:                               ; %else3296
	add.2d	v6, v4, v5
	str	q5, [sp, #16]                   ; 16-byte Spill
	tbz	w9, #6, LBB0_576
LBB0_575:                               ; %cond.load3298
	fmov	x8, d6
	ldr	q4, [sp, #10128]                ; 16-byte Reload
	ld1.s	{ v4 }[2], [x8]
	str	q4, [sp, #10128]                ; 16-byte Spill
LBB0_576:                               ; %else3302
	ldr	x8, [x1, #136]
	ushll2.2d	v5, v3, #0
	ushll2.2d	v4, v2, #0
	ushll.2d	v3, v3, #0
	ushll.2d	v2, v2, #0
	str	q7, [sp, #2048]                 ; 16-byte Spill
	str	q16, [sp, #2032]                ; 16-byte Spill
	tbz	w9, #7, LBB0_578
; %bb.577:                              ; %cond.load3304
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10128]                ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #10128]                ; 16-byte Spill
LBB0_578:                               ; %else3308
	mov	x9, #0                          ; =0x0
	ldr	q17, [sp, #11296]               ; 16-byte Reload
	sshll2.2d	v19, v17, #0
	ldr	q1, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v6, v1, #0
	ldr	x11, [x0, #16]
	sshll.2d	v7, v17, #0
	sshll2.2d	v20, v1, #0
	mov	w10, #62154                     ; =0xf2ca
	movk	w10, #61769, lsl #16
	dup.4s	v16, w10
	ldr	x12, [x0, #32]
	and.16b	v17, v17, v16
	str	q17, [sp, #8880]                ; 16-byte Spill
	ldr	x10, [x0, #48]
	str	x10, [sp, #8]                   ; 8-byte Spill
	and.16b	v16, v1, v16
	str	q16, [sp, #8864]                ; 16-byte Spill
	shl.2d	v5, v5, #19
	shl.2d	v2, v2, #19
	shl.2d	v3, v3, #19
	shl.2d	v4, v4, #19
	str	q20, [sp, #4320]                ; 16-byte Spill
	and.16b	v16, v20, v4
	and.16b	v7, v7, v3
	and.16b	v17, v6, v2
	str	q19, [sp, #4336]                ; 16-byte Spill
	and.16b	v19, v19, v5
Lloh6:
	adrp	x10, lCPI0_3@PAGE
Lloh7:
	ldr	q2, [x10, lCPI0_3@PAGEOFF]
	str	q2, [sp, #6496]                 ; 16-byte Spill
Lloh8:
	adrp	x10, lCPI0_4@PAGE
Lloh9:
	ldr	q2, [x10, lCPI0_4@PAGEOFF]
	str	q2, [sp, #6480]                 ; 16-byte Spill
Lloh10:
	adrp	x10, lCPI0_5@PAGE
Lloh11:
	ldr	q2, [x10, lCPI0_5@PAGEOFF]
	str	q2, [sp, #6464]                 ; 16-byte Spill
Lloh12:
	adrp	x10, lCPI0_6@PAGE
Lloh13:
	ldr	q2, [x10, lCPI0_6@PAGEOFF]
	str	q2, [sp, #6448]                 ; 16-byte Spill
	add	x10, x8, #16, lsl #12           ; =65536
	add	x10, x10, #32
	str	x10, [sp, #4200]                ; 8-byte Spill
	add	x10, x8, #16, lsl #12           ; =65536
	add	x10, x10, #64
	str	x10, [sp, #4192]                ; 8-byte Spill
	add	x10, x8, #16, lsl #12           ; =65536
	add	x10, x10, #96
	str	x10, [sp, #4184]                ; 8-byte Spill
	add	x10, x8, #16, lsl #12           ; =65536
	add	x10, x10, #128
	str	x10, [sp, #4176]                ; 8-byte Spill
	mvni.4s	v2, #63, msl #16
	add	x10, x8, #16, lsl #12           ; =65536
	fneg.4s	v2, v2
	str	q2, [sp, #4160]                 ; 16-byte Spill
	add	x10, x10, #160
	str	x10, [sp, #4152]                ; 8-byte Spill
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #6432]                 ; 16-byte Spill
	add	x10, x8, #16, lsl #12           ; =65536
	str	q2, [sp, #6416]                 ; 16-byte Spill
	add	x10, x10, #192
	str	x10, [sp, #4144]                ; 8-byte Spill
	str	q2, [sp, #10992]                ; 16-byte Spill
	add	x10, x8, #16, lsl #12           ; =65536
	str	q2, [sp, #8848]                 ; 16-byte Spill
	add	x10, x10, #224
	str	x10, [sp, #4136]                ; 8-byte Spill
	str	q2, [sp, #6736]                 ; 16-byte Spill
	add	x10, x8, #16, lsl #12           ; =65536
	str	q2, [sp, #8832]                 ; 16-byte Spill
	add	x10, x10, #256
	str	x10, [sp, #4128]                ; 8-byte Spill
	str	q2, [sp, #9392]                 ; 16-byte Spill
	add	x10, x8, #16, lsl #12           ; =65536
	str	q2, [sp, #8816]                 ; 16-byte Spill
	add	x10, x10, #288
	str	x10, [sp, #4120]                ; 8-byte Spill
	str	q2, [sp, #8800]                 ; 16-byte Spill
	add	x10, x8, #16, lsl #12           ; =65536
	str	q2, [sp, #10960]                ; 16-byte Spill
	add	x10, x10, #320
	str	x10, [sp, #4112]                ; 8-byte Spill
	str	q2, [sp, #8784]                 ; 16-byte Spill
	add	x10, x8, #16, lsl #12           ; =65536
	str	q2, [sp, #8768]                 ; 16-byte Spill
	add	x10, x10, #352
	str	x10, [sp, #4104]                ; 8-byte Spill
	add	x10, x8, #16, lsl #12           ; =65536
	add	x10, x10, #384
	str	x10, [sp, #4096]                ; 8-byte Spill
	add	x10, x8, #16, lsl #12           ; =65536
	add	x10, x10, #416
	str	x10, [sp, #4088]                ; 8-byte Spill
	add	x10, x8, #16, lsl #12           ; =65536
	add	x10, x10, #448
	str	x10, [sp, #4080]                ; 8-byte Spill
	add	x10, x8, #16, lsl #12           ; =65536
	add	x20, x10, #480
	add	x10, x8, #16, lsl #12           ; =65536
	add	x21, x10, #512
	add	x10, x8, #16, lsl #12           ; =65536
	add	x22, x10, #544
	add	x10, x8, #16, lsl #12           ; =65536
	add	x23, x10, #576
	add	x10, x8, #16, lsl #12           ; =65536
	add	x24, x10, #608
	add	x10, x8, #16, lsl #12           ; =65536
	add	x25, x10, #640
	add	x10, x8, #16, lsl #12           ; =65536
	add	x26, x10, #672
	add	x10, x8, #16, lsl #12           ; =65536
	add	x27, x10, #704
	add	x10, x8, #16, lsl #12           ; =65536
	add	x28, x10, #736
	add	x10, x8, #16, lsl #12           ; =65536
	add	x30, x10, #768
	add	x10, x8, #16, lsl #12           ; =65536
	add	x10, x10, #800
	add	x13, x8, #16, lsl #12           ; =65536
	add	x13, x13, #832
	add	x14, x8, #16, lsl #12           ; =65536
	add	x14, x14, #864
	add	x15, x8, #16, lsl #12           ; =65536
	add	x15, x15, #896
	add	x16, x8, #16, lsl #12           ; =65536
	add	x16, x16, #928
	add	x17, x8, #16, lsl #12           ; =65536
	add	x17, x17, #960
	add	x0, x8, #16, lsl #12            ; =65536
	add	x0, x0, #992
	add	x1, x8, #8, lsl #12             ; =32768
	add	x2, x8, #16, lsl #12            ; =65536
	str	q2, [sp, #10976]                ; 16-byte Spill
	str	q2, [sp, #11072]                ; 16-byte Spill
	str	q2, [sp, #11104]                ; 16-byte Spill
	str	q2, [sp, #9376]                 ; 16-byte Spill
	str	q2, [sp, #8752]                 ; 16-byte Spill
	str	q2, [sp, #11040]                ; 16-byte Spill
	str	q2, [sp, #11152]                ; 16-byte Spill
	str	q2, [sp, #11024]                ; 16-byte Spill
	str	q2, [sp, #11088]                ; 16-byte Spill
	str	q2, [sp, #11136]                ; 16-byte Spill
	str	q2, [sp, #11216]                ; 16-byte Spill
	str	q2, [sp, #11120]                ; 16-byte Spill
	str	q2, [sp, #11280]                ; 16-byte Spill
	str	q2, [sp, #11200]                ; 16-byte Spill
	str	q2, [sp, #11056]                ; 16-byte Spill
	str	q2, [sp, #11264]                ; 16-byte Spill
	str	q2, [sp, #11184]                ; 16-byte Spill
	str	q2, [sp, #11248]                ; 16-byte Spill
	str	q2, [sp, #11168]                ; 16-byte Spill
	str	q2, [sp, #11232]                ; 16-byte Spill
	str	q2, [sp, #11008]                ; 16-byte Spill
	str	q2, [sp, #6720]                 ; 16-byte Spill
	str	q2, [sp, #10928]                ; 16-byte Spill
	str	q2, [sp, #10944]                ; 16-byte Spill
	str	q2, [sp, #6400]                 ; 16-byte Spill
	str	q2, [sp, #6384]                 ; 16-byte Spill
	movi.2d	v3, #0000000000000000
	str	q2, [sp, #6368]                 ; 16-byte Spill
	str	q2, [sp, #6352]                 ; 16-byte Spill
	str	q2, [sp, #6336]                 ; 16-byte Spill
	movi.2d	v21, #0000000000000000
	str	q2, [sp, #6320]                 ; 16-byte Spill
	movi.2d	v20, #0000000000000000
	str	q2, [sp, #6304]                 ; 16-byte Spill
	movi.2d	v1, #0000000000000000
	movi.2d	v27, #0000000000000000
	str	q2, [sp, #6576]                 ; 16-byte Spill
	movi.2d	v10, #0000000000000000
	str	q2, [sp, #6544]                 ; 16-byte Spill
	str	q2, [sp, #6560]                 ; 16-byte Spill
	str	q2, [sp, #6512]                 ; 16-byte Spill
	str	q2, [sp, #6528]                 ; 16-byte Spill
	str	q2, [sp, #8640]                 ; 16-byte Spill
	str	q2, [sp, #8656]                 ; 16-byte Spill
	str	q2, [sp, #8608]                 ; 16-byte Spill
	str	q2, [sp, #8624]                 ; 16-byte Spill
	str	q2, [sp, #8576]                 ; 16-byte Spill
	str	q2, [sp, #8592]                 ; 16-byte Spill
	str	q2, [sp, #8544]                 ; 16-byte Spill
	str	q2, [sp, #8560]                 ; 16-byte Spill
	str	q2, [sp, #8512]                 ; 16-byte Spill
	str	q2, [sp, #8528]                 ; 16-byte Spill
	str	q2, [sp, #8480]                 ; 16-byte Spill
	str	q2, [sp, #8496]                 ; 16-byte Spill
	str	q2, [sp, #8448]                 ; 16-byte Spill
	str	q2, [sp, #8464]                 ; 16-byte Spill
	str	q2, [sp, #8416]                 ; 16-byte Spill
	str	q2, [sp, #8432]                 ; 16-byte Spill
	str	q2, [sp, #8384]                 ; 16-byte Spill
	str	q2, [sp, #8400]                 ; 16-byte Spill
	str	q2, [sp, #8352]                 ; 16-byte Spill
	str	q2, [sp, #8368]                 ; 16-byte Spill
	str	q2, [sp, #8320]                 ; 16-byte Spill
	str	q2, [sp, #8336]                 ; 16-byte Spill
	str	q2, [sp, #8288]                 ; 16-byte Spill
	str	q2, [sp, #8304]                 ; 16-byte Spill
	str	q2, [sp, #8256]                 ; 16-byte Spill
	str	q2, [sp, #8272]                 ; 16-byte Spill
	str	q2, [sp, #8224]                 ; 16-byte Spill
	str	q2, [sp, #8240]                 ; 16-byte Spill
	str	q2, [sp, #8192]                 ; 16-byte Spill
	str	q2, [sp, #8208]                 ; 16-byte Spill
	str	q2, [sp, #8160]                 ; 16-byte Spill
	str	q2, [sp, #8176]                 ; 16-byte Spill
	str	q2, [sp, #8128]                 ; 16-byte Spill
	str	q2, [sp, #8144]                 ; 16-byte Spill
	str	q2, [sp, #8096]                 ; 16-byte Spill
	str	q2, [sp, #8112]                 ; 16-byte Spill
	str	q2, [sp, #8064]                 ; 16-byte Spill
	str	q2, [sp, #8080]                 ; 16-byte Spill
	str	q2, [sp, #8032]                 ; 16-byte Spill
	str	q2, [sp, #8048]                 ; 16-byte Spill
	str	q2, [sp, #8000]                 ; 16-byte Spill
	str	q2, [sp, #8016]                 ; 16-byte Spill
	str	q2, [sp, #7968]                 ; 16-byte Spill
	str	q2, [sp, #7984]                 ; 16-byte Spill
	str	q2, [sp, #7936]                 ; 16-byte Spill
	str	q2, [sp, #7952]                 ; 16-byte Spill
	str	q2, [sp, #7904]                 ; 16-byte Spill
	str	q2, [sp, #7920]                 ; 16-byte Spill
	str	q2, [sp, #7872]                 ; 16-byte Spill
	str	q2, [sp, #7888]                 ; 16-byte Spill
	str	q2, [sp, #7840]                 ; 16-byte Spill
	str	q2, [sp, #7856]                 ; 16-byte Spill
	str	q2, [sp, #7808]                 ; 16-byte Spill
	str	q2, [sp, #7824]                 ; 16-byte Spill
	str	q2, [sp, #7776]                 ; 16-byte Spill
	str	q2, [sp, #7792]                 ; 16-byte Spill
	str	q2, [sp, #7744]                 ; 16-byte Spill
	str	q2, [sp, #7760]                 ; 16-byte Spill
	str	q2, [sp, #7712]                 ; 16-byte Spill
	str	q2, [sp, #7728]                 ; 16-byte Spill
	str	q2, [sp, #7680]                 ; 16-byte Spill
	str	q2, [sp, #7696]                 ; 16-byte Spill
	str	q2, [sp, #7648]                 ; 16-byte Spill
	str	q2, [sp, #7664]                 ; 16-byte Spill
	str	q2, [sp, #7616]                 ; 16-byte Spill
	str	q2, [sp, #7632]                 ; 16-byte Spill
	str	q2, [sp, #7584]                 ; 16-byte Spill
	str	q2, [sp, #7600]                 ; 16-byte Spill
	str	q2, [sp, #7552]                 ; 16-byte Spill
	str	q2, [sp, #7568]                 ; 16-byte Spill
	str	q2, [sp, #7520]                 ; 16-byte Spill
	str	q2, [sp, #7536]                 ; 16-byte Spill
	str	q2, [sp, #7488]                 ; 16-byte Spill
	str	q2, [sp, #7504]                 ; 16-byte Spill
	str	q2, [sp, #7456]                 ; 16-byte Spill
	str	q2, [sp, #7472]                 ; 16-byte Spill
	str	q2, [sp, #7424]                 ; 16-byte Spill
	str	q2, [sp, #7440]                 ; 16-byte Spill
	str	q2, [sp, #7392]                 ; 16-byte Spill
	str	q2, [sp, #7408]                 ; 16-byte Spill
	str	q2, [sp, #7360]                 ; 16-byte Spill
	str	q2, [sp, #7376]                 ; 16-byte Spill
	str	q2, [sp, #7328]                 ; 16-byte Spill
	str	q2, [sp, #7344]                 ; 16-byte Spill
	str	q2, [sp, #7296]                 ; 16-byte Spill
	str	q2, [sp, #7312]                 ; 16-byte Spill
	str	q2, [sp, #7264]                 ; 16-byte Spill
	str	q2, [sp, #7280]                 ; 16-byte Spill
	str	q2, [sp, #7232]                 ; 16-byte Spill
	str	q2, [sp, #7248]                 ; 16-byte Spill
	str	q2, [sp, #7200]                 ; 16-byte Spill
	str	q2, [sp, #7216]                 ; 16-byte Spill
	str	q2, [sp, #7168]                 ; 16-byte Spill
	str	q2, [sp, #7184]                 ; 16-byte Spill
	str	q2, [sp, #7136]                 ; 16-byte Spill
	str	q2, [sp, #7152]                 ; 16-byte Spill
	str	q2, [sp, #7104]                 ; 16-byte Spill
	str	q2, [sp, #7120]                 ; 16-byte Spill
	str	q2, [sp, #7072]                 ; 16-byte Spill
	str	q2, [sp, #7088]                 ; 16-byte Spill
	str	q2, [sp, #7040]                 ; 16-byte Spill
	str	q2, [sp, #7056]                 ; 16-byte Spill
	str	q2, [sp, #7008]                 ; 16-byte Spill
	str	q2, [sp, #7024]                 ; 16-byte Spill
	str	q2, [sp, #6976]                 ; 16-byte Spill
	str	q2, [sp, #6992]                 ; 16-byte Spill
	str	q2, [sp, #6944]                 ; 16-byte Spill
	str	q2, [sp, #6960]                 ; 16-byte Spill
	str	q2, [sp, #6912]                 ; 16-byte Spill
	str	q2, [sp, #6928]                 ; 16-byte Spill
	str	q2, [sp, #6880]                 ; 16-byte Spill
	str	q2, [sp, #6896]                 ; 16-byte Spill
	str	q2, [sp, #6848]                 ; 16-byte Spill
	str	q2, [sp, #6864]                 ; 16-byte Spill
	str	q2, [sp, #6816]                 ; 16-byte Spill
	str	q2, [sp, #6832]                 ; 16-byte Spill
	str	q2, [sp, #6784]                 ; 16-byte Spill
	str	q2, [sp, #6800]                 ; 16-byte Spill
	str	q2, [sp, #6752]                 ; 16-byte Spill
	str	q2, [sp, #6768]                 ; 16-byte Spill
	str	q2, [sp, #8672]                 ; 16-byte Spill
	str	q2, [sp, #8688]                 ; 16-byte Spill
	str	q0, [sp, #4304]                 ; 16-byte Spill
	str	q18, [sp, #4288]                ; 16-byte Spill
	str	q22, [sp, #4272]                ; 16-byte Spill
	str	q16, [sp, #4256]                ; 16-byte Spill
	str	q7, [sp, #4240]                 ; 16-byte Spill
	str	q17, [sp, #4224]                ; 16-byte Spill
	str	q19, [sp, #4208]                ; 16-byte Spill
LBB0_579:                               ; %direct.true
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_581 Depth 2
                                        ;     Child Loop BB0_599 Depth 2
                                        ;     Child Loop BB0_616 Depth 2
	str	q3, [sp, #6240]                 ; 16-byte Spill
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	lsl	x5, x9, #4
	b	LBB0_581
LBB0_580:                               ; %else5460
                                        ;   in Loop: Header=BB0_581 Depth=2
	add	x6, x8, x4, lsl #5
	ldp	q4, q5, [x6]
	ldr	q6, [sp, #11296]                ; 16-byte Reload
	bif.16b	v3, v5, v6
	ldr	q5, [sp, #11312]                ; 16-byte Reload
	bif.16b	v2, v4, v5
	stp	q2, q3, [x6]
	add	x4, x4, #1
	add	x3, x3, #4
	cmp	x3, #1, lsl #12                 ; =4096
	b.eq	LBB0_597
LBB0_581:                               ; %direct.true282
                                        ;   Parent Loop BB0_579 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w6, s0
	orr	x7, x5, x4, lsr #6
	and	x19, x3, #0xfc
	orr	x7, x19, x7, lsl #8
	dup.2d	v4, x7
	orr.16b	v2, v4, v17
	dup.2d	v5, x11
	add.2d	v6, v5, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w6, #0, LBB0_589
; %bb.582:                              ; %else5418
                                        ;   in Loop: Header=BB0_581 Depth=2
	and	w6, w6, #0xff
	tbnz	w6, #1, LBB0_590
LBB0_583:                               ; %else5424
                                        ;   in Loop: Header=BB0_581 Depth=2
	orr.16b	v6, v4, v16
	add.2d	v6, v5, v6
	tbnz	w6, #2, LBB0_591
LBB0_584:                               ; %else5430
                                        ;   in Loop: Header=BB0_581 Depth=2
	tbnz	w6, #3, LBB0_592
LBB0_585:                               ; %else5436
                                        ;   in Loop: Header=BB0_581 Depth=2
	orr.16b	v6, v4, v7
	add.2d	v6, v5, v6
	tbnz	w6, #4, LBB0_593
LBB0_586:                               ; %else5442
                                        ;   in Loop: Header=BB0_581 Depth=2
	tbnz	w6, #5, LBB0_594
LBB0_587:                               ; %else5448
                                        ;   in Loop: Header=BB0_581 Depth=2
	orr.16b	v4, v4, v19
	add.2d	v4, v5, v4
	tbnz	w6, #6, LBB0_595
LBB0_588:                               ; %else5454
                                        ;   in Loop: Header=BB0_581 Depth=2
	tbz	w6, #7, LBB0_580
	b	LBB0_596
LBB0_589:                               ; %cond.load5414
                                        ;   in Loop: Header=BB0_581 Depth=2
	fmov	x7, d6
	ldr	s2, [x7]
	and	w6, w6, #0xff
	tbz	w6, #1, LBB0_583
LBB0_590:                               ; %cond.load5420
                                        ;   in Loop: Header=BB0_581 Depth=2
	mov.d	x7, v6[1]
	ld1.s	{ v2 }[1], [x7]
	orr.16b	v6, v4, v16
	add.2d	v6, v5, v6
	tbz	w6, #2, LBB0_584
LBB0_591:                               ; %cond.load5426
                                        ;   in Loop: Header=BB0_581 Depth=2
	fmov	x7, d6
	ld1.s	{ v2 }[2], [x7]
	tbz	w6, #3, LBB0_585
LBB0_592:                               ; %cond.load5432
                                        ;   in Loop: Header=BB0_581 Depth=2
	mov.d	x7, v6[1]
	ld1.s	{ v2 }[3], [x7]
	orr.16b	v6, v4, v7
	add.2d	v6, v5, v6
	tbz	w6, #4, LBB0_586
LBB0_593:                               ; %cond.load5438
                                        ;   in Loop: Header=BB0_581 Depth=2
	fmov	x7, d6
	ld1.s	{ v3 }[0], [x7]
	tbz	w6, #5, LBB0_587
LBB0_594:                               ; %cond.load5444
                                        ;   in Loop: Header=BB0_581 Depth=2
	mov.d	x7, v6[1]
	ld1.s	{ v3 }[1], [x7]
	orr.16b	v4, v4, v19
	add.2d	v4, v5, v4
	tbz	w6, #6, LBB0_588
LBB0_595:                               ; %cond.load5450
                                        ;   in Loop: Header=BB0_581 Depth=2
	fmov	x7, d4
	ld1.s	{ v3 }[2], [x7]
	tbz	w6, #7, LBB0_580
LBB0_596:                               ; %cond.load5456
                                        ;   in Loop: Header=BB0_581 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v3 }[3], [x6]
	b	LBB0_580
LBB0_597:                               ; %direct.true299.preheader
                                        ;   in Loop: Header=BB0_579 Depth=1
	mov	x3, #0                          ; =0x0
	mov	x4, #0                          ; =0x0
	b	LBB0_599
LBB0_598:                               ; %else5509
                                        ;   in Loop: Header=BB0_599 Depth=2
	add	x6, x1, x4, lsl #5
	ldp	q4, q5, [x6]
	ldr	q6, [sp, #11296]                ; 16-byte Reload
	bif.16b	v3, v5, v6
	ldr	q5, [sp, #11312]                ; 16-byte Reload
	bif.16b	v2, v4, v5
	stp	q2, q3, [x6]
	add	x4, x4, #1
	add	x3, x3, #4
	cmp	x3, #1, lsl #12                 ; =4096
	b.eq	LBB0_615
LBB0_599:                               ; %direct.true299
                                        ;   Parent Loop BB0_579 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w6, s0
	orr	x7, x5, x4, lsr #6
	and	x19, x3, #0xfc
	orr	x7, x19, x7, lsl #8
	dup.2d	v4, x7
	orr.16b	v2, v4, v17
	dup.2d	v5, x12
	add.2d	v6, v5, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w6, #0, LBB0_607
; %bb.600:                              ; %else5467
                                        ;   in Loop: Header=BB0_599 Depth=2
	and	w6, w6, #0xff
	tbnz	w6, #1, LBB0_608
LBB0_601:                               ; %else5473
                                        ;   in Loop: Header=BB0_599 Depth=2
	orr.16b	v6, v4, v16
	add.2d	v6, v5, v6
	tbnz	w6, #2, LBB0_609
LBB0_602:                               ; %else5479
                                        ;   in Loop: Header=BB0_599 Depth=2
	tbnz	w6, #3, LBB0_610
LBB0_603:                               ; %else5485
                                        ;   in Loop: Header=BB0_599 Depth=2
	orr.16b	v6, v4, v7
	add.2d	v6, v5, v6
	tbnz	w6, #4, LBB0_611
LBB0_604:                               ; %else5491
                                        ;   in Loop: Header=BB0_599 Depth=2
	tbnz	w6, #5, LBB0_612
LBB0_605:                               ; %else5497
                                        ;   in Loop: Header=BB0_599 Depth=2
	orr.16b	v4, v4, v19
	add.2d	v4, v5, v4
	tbnz	w6, #6, LBB0_613
LBB0_606:                               ; %else5503
                                        ;   in Loop: Header=BB0_599 Depth=2
	tbz	w6, #7, LBB0_598
	b	LBB0_614
LBB0_607:                               ; %cond.load5463
                                        ;   in Loop: Header=BB0_599 Depth=2
	fmov	x7, d6
	ldr	s2, [x7]
	and	w6, w6, #0xff
	tbz	w6, #1, LBB0_601
LBB0_608:                               ; %cond.load5469
                                        ;   in Loop: Header=BB0_599 Depth=2
	mov.d	x7, v6[1]
	ld1.s	{ v2 }[1], [x7]
	orr.16b	v6, v4, v16
	add.2d	v6, v5, v6
	tbz	w6, #2, LBB0_602
LBB0_609:                               ; %cond.load5475
                                        ;   in Loop: Header=BB0_599 Depth=2
	fmov	x7, d6
	ld1.s	{ v2 }[2], [x7]
	tbz	w6, #3, LBB0_603
LBB0_610:                               ; %cond.load5481
                                        ;   in Loop: Header=BB0_599 Depth=2
	mov.d	x7, v6[1]
	ld1.s	{ v2 }[3], [x7]
	orr.16b	v6, v4, v7
	add.2d	v6, v5, v6
	tbz	w6, #4, LBB0_604
LBB0_611:                               ; %cond.load5487
                                        ;   in Loop: Header=BB0_599 Depth=2
	fmov	x7, d6
	ld1.s	{ v3 }[0], [x7]
	tbz	w6, #5, LBB0_605
LBB0_612:                               ; %cond.load5493
                                        ;   in Loop: Header=BB0_599 Depth=2
	mov.d	x7, v6[1]
	ld1.s	{ v3 }[1], [x7]
	orr.16b	v4, v4, v19
	add.2d	v4, v5, v4
	tbz	w6, #6, LBB0_606
LBB0_613:                               ; %cond.load5499
                                        ;   in Loop: Header=BB0_599 Depth=2
	fmov	x7, d4
	ld1.s	{ v3 }[2], [x7]
	tbz	w6, #7, LBB0_598
LBB0_614:                               ; %cond.load5505
                                        ;   in Loop: Header=BB0_599 Depth=2
	mov.d	x6, v4[1]
	ld1.s	{ v3 }[3], [x6]
	b	LBB0_598
LBB0_615:                               ; %direct.false300
                                        ;   in Loop: Header=BB0_579 Depth=1
	str	q10, [sp, #6688]                ; 16-byte Spill
	str	q1, [sp, #6288]                 ; 16-byte Spill
	str	q27, [sp, #6704]                ; 16-byte Spill
	ldr	q1, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v3, v1, #0
	mov	x3, #0                          ; =0x0
	ldr	q14, [sp, #11296]               ; 16-byte Reload
	sshll.2d	v2, v14, #0
	ldr	q0, [sp, #6464]                 ; 16-byte Reload
	bit.16b	v20, v0, v2
	str	q20, [sp, #6272]                ; 16-byte Spill
	ldr	q0, [sp, #6448]                 ; 16-byte Reload
	bif.16b	v0, v21, v3
	str	q0, [sp, #6256]                 ; 16-byte Spill
	bic.16b	v2, v21, v3
	fmov	x4, d2
	add	x4, x8, x4
	ldp	q2, q3, [x4]
	and.16b	v3, v14, v3
	and.16b	v2, v1, v2
	ldr	q11, [sp, #9136]                ; 16-byte Reload
	fmul.4s	v2, v11, v2
	ldr	q0, [sp, #10912]                ; 16-byte Reload
	fmul.4s	v3, v0, v3
	movi.2d	v18, #0000000000000000
	fadd.4s	v3, v3, v18
	fadd.4s	v2, v2, v18
	ldr	q4, [x8, #2064]
	ldr	q5, [x8, #2048]
	and.16b	v5, v1, v5
	and.16b	v4, v14, v4
	fmul.4s	v4, v0, v4
	fmul.4s	v5, v11, v5
	fadd.4s	v5, v5, v18
	fadd.4s	v4, v4, v18
	ldr	q6, [x8, #4112]
	ldr	q7, [x8, #4096]
	and.16b	v7, v1, v7
	and.16b	v6, v14, v6
	fmul.4s	v6, v0, v6
	fmul.4s	v7, v11, v7
	fadd.4s	v7, v7, v18
	fadd.4s	v6, v6, v18
	ldr	q16, [x8, #6160]
	ldr	q17, [x8, #6144]
	and.16b	v17, v1, v17
	and.16b	v16, v14, v16
	fmul.4s	v16, v0, v16
	fmul.4s	v17, v11, v17
	fadd.4s	v17, v17, v18
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #32]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10896]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q20, [sp, #8736]                ; 16-byte Reload
	fmul.4s	v19, v20, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #2080]
	ldr	q19, [x8, #2096]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #4128]
	ldr	q19, [x8, #4144]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #6176]
	ldr	q19, [x8, #6192]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldp	q18, q19, [x8, #64]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q15, [sp, #9120]                ; 16-byte Reload
	fmul.4s	v18, v15, v18
	ldr	q0, [sp, #10880]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #2128]
	ldr	q19, [x8, #2112]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v15, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #4176]
	ldr	q19, [x8, #4160]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v15, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #6224]
	ldr	q19, [x8, #6208]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v15, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #96]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10864]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9104]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #2144]
	ldr	q19, [x8, #2160]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #4192]
	ldr	q19, [x8, #4208]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #6240]
	ldr	q19, [x8, #6256]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldp	q18, q19, [x8, #128]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #10112]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10848]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #2192]
	ldr	q19, [x8, #2176]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #4240]
	ldr	q19, [x8, #4224]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #6288]
	ldr	q19, [x8, #6272]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #160]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10832]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9088]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #2208]
	ldr	q19, [x8, #2224]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #4256]
	ldr	q19, [x8, #4272]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #6304]
	ldr	q19, [x8, #6320]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldp	q18, q19, [x8, #192]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #10096]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10816]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #2256]
	ldr	q19, [x8, #2240]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #4304]
	ldr	q19, [x8, #4288]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #6352]
	ldr	q19, [x8, #6336]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #224]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10800]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10080]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #2272]
	ldr	q19, [x8, #2288]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #4320]
	ldr	q19, [x8, #4336]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #6368]
	ldr	q19, [x8, #6384]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldp	q18, q19, [x8, #256]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #10064]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10784]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #2320]
	ldr	q19, [x8, #2304]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #4368]
	ldr	q19, [x8, #4352]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #6416]
	ldr	q19, [x8, #6400]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #288]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10768]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10048]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #2336]
	ldr	q19, [x8, #2352]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #4384]
	ldr	q19, [x8, #4400]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #6432]
	ldr	q19, [x8, #6448]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldp	q18, q19, [x8, #320]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9072]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9360]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #2384]
	ldr	q19, [x8, #2368]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #4432]
	ldr	q19, [x8, #4416]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #6480]
	ldr	q19, [x8, #6464]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #352]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q23, [sp, #9344]                ; 16-byte Reload
	fmul.4s	v18, v23, v18
	ldr	q0, [sp, #10032]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #2400]
	ldr	q19, [x8, #2416]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v23, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #4448]
	ldr	q19, [x8, #4464]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v23, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #6496]
	ldr	q19, [x8, #6512]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v23, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldp	q18, q19, [x8, #384]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q24, [sp, #9056]                ; 16-byte Reload
	fmul.4s	v18, v24, v18
	ldr	q0, [sp, #9328]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #2448]
	ldr	q19, [x8, #2432]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v24, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #4496]
	ldr	q19, [x8, #4480]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v24, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #6544]
	ldr	q19, [x8, #6528]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v24, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #416]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q25, [sp, #9312]                ; 16-byte Reload
	fmul.4s	v18, v25, v18
	ldr	q0, [sp, #9040]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #2464]
	ldr	q19, [x8, #2480]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v25, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #4512]
	ldr	q19, [x8, #4528]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v25, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #6560]
	ldr	q19, [x8, #6576]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v25, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldp	q18, q19, [x8, #448]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q26, [sp, #9024]                ; 16-byte Reload
	fmul.4s	v18, v26, v18
	ldr	q0, [sp, #9296]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #2512]
	ldr	q19, [x8, #2496]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v26, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #4560]
	ldr	q19, [x8, #4544]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v26, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #6608]
	ldr	q19, [x8, #6592]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v26, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #480]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q27, [sp, #9280]                ; 16-byte Reload
	fmul.4s	v18, v27, v18
	ldr	q0, [sp, #9008]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #2528]
	ldr	q19, [x8, #2544]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v27, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #4576]
	ldr	q19, [x8, #4592]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v27, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #6624]
	ldr	q19, [x8, #6640]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v27, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldp	q18, q19, [x8, #512]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q28, [sp, #8992]                ; 16-byte Reload
	fmul.4s	v18, v28, v18
	ldr	q0, [sp, #9264]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #2576]
	ldr	q19, [x8, #2560]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v28, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #4624]
	ldr	q19, [x8, #4608]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v28, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #6672]
	ldr	q19, [x8, #6656]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v28, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #544]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q29, [sp, #9248]                ; 16-byte Reload
	fmul.4s	v18, v29, v18
	ldr	q0, [sp, #8976]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #2592]
	ldr	q19, [x8, #2608]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v29, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #4640]
	ldr	q19, [x8, #4656]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v29, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #6688]
	ldr	q19, [x8, #6704]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v29, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldp	q18, q19, [x8, #576]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q30, [sp, #8960]                ; 16-byte Reload
	fmul.4s	v18, v30, v18
	ldr	q0, [sp, #9232]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #2640]
	ldr	q19, [x8, #2624]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v30, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #4688]
	ldr	q19, [x8, #4672]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v30, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #6736]
	ldr	q19, [x8, #6720]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v30, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #608]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q31, [sp, #9216]                ; 16-byte Reload
	fmul.4s	v18, v31, v18
	ldr	q0, [sp, #8944]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #2656]
	ldr	q19, [x8, #2672]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v31, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #4704]
	ldr	q19, [x8, #4720]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v31, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #6752]
	ldr	q19, [x8, #6768]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v31, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldp	q18, q19, [x8, #640]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q8, [sp, #8720]                 ; 16-byte Reload
	fmul.4s	v18, v8, v18
	ldr	q0, [sp, #9200]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #2704]
	ldr	q19, [x8, #2688]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v8, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #4752]
	ldr	q19, [x8, #4736]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v8, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #6800]
	ldr	q19, [x8, #6784]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v8, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #672]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q9, [sp, #9184]                 ; 16-byte Reload
	fmul.4s	v18, v9, v18
	ldr	q0, [sp, #10016]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #2720]
	ldr	q19, [x8, #2736]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v9, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #4768]
	ldr	q19, [x8, #4784]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v9, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #6816]
	ldr	q19, [x8, #6832]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v9, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldp	q18, q19, [x8, #704]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q10, [sp, #8928]                ; 16-byte Reload
	fmul.4s	v18, v10, v18
	ldr	q0, [sp, #10752]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #2768]
	ldr	q19, [x8, #2752]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v10, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #4816]
	ldr	q19, [x8, #4800]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v10, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #6864]
	ldr	q19, [x8, #6848]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v10, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #736]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q12, [sp, #9168]                ; 16-byte Reload
	fmul.4s	v18, v12, v18
	ldr	q0, [sp, #10000]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #2784]
	ldr	q19, [x8, #2800]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v12, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #4832]
	ldr	q19, [x8, #4848]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v12, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #6880]
	ldr	q19, [x8, #6896]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v12, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldp	q18, q19, [x8, #768]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q13, [sp, #8912]                ; 16-byte Reload
	fmul.4s	v18, v13, v18
	ldr	q0, [sp, #10736]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #2832]
	ldr	q19, [x8, #2816]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v13, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #4880]
	ldr	q19, [x8, #4864]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v13, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #6928]
	ldr	q19, [x8, #6912]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v13, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #800]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10720]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9984]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #2848]
	ldr	q19, [x8, #2864]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #4896]
	ldr	q19, [x8, #4912]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #6944]
	ldr	q19, [x8, #6960]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldp	q18, q19, [x8, #832]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9968]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10704]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #2896]
	ldr	q19, [x8, #2880]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #4944]
	ldr	q19, [x8, #4928]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #6992]
	ldr	q19, [x8, #6976]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #864]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10688]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9952]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #2912]
	ldr	q19, [x8, #2928]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #4960]
	ldr	q19, [x8, #4976]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7008]
	ldr	q19, [x8, #7024]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldp	q18, q19, [x8, #896]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9936]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10672]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #2960]
	ldr	q19, [x8, #2944]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5008]
	ldr	q19, [x8, #4992]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #7056]
	ldr	q19, [x8, #7040]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #928]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10656]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9920]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #2976]
	ldr	q19, [x8, #2992]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5024]
	ldr	q19, [x8, #5040]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7072]
	ldr	q19, [x8, #7088]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldp	q18, q19, [x8, #960]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9904]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10640]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3024]
	ldr	q19, [x8, #3008]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5072]
	ldr	q19, [x8, #5056]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #7120]
	ldr	q19, [x8, #7104]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldp	q19, q18, [x8, #992]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10624]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9888]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #3040]
	ldr	q19, [x8, #3056]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5088]
	ldr	q19, [x8, #5104]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7136]
	ldr	q19, [x8, #7152]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1024]
	ldr	q19, [x8, #1040]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9872]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10608]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3088]
	ldr	q19, [x8, #3072]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5136]
	ldr	q19, [x8, #5120]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #7184]
	ldr	q19, [x8, #7168]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #1072]
	ldr	q19, [x8, #1056]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10592]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9856]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #3104]
	ldr	q19, [x8, #3120]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5152]
	ldr	q19, [x8, #5168]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7200]
	ldr	q19, [x8, #7216]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1088]
	ldr	q19, [x8, #1104]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9840]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10576]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3152]
	ldr	q19, [x8, #3136]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5200]
	ldr	q19, [x8, #5184]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #7248]
	ldr	q19, [x8, #7232]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #1136]
	ldr	q19, [x8, #1120]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10560]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9824]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #3168]
	ldr	q19, [x8, #3184]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5216]
	ldr	q19, [x8, #5232]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7264]
	ldr	q19, [x8, #7280]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1152]
	ldr	q19, [x8, #1168]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9808]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10544]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3216]
	ldr	q19, [x8, #3200]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5264]
	ldr	q19, [x8, #5248]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #7312]
	ldr	q19, [x8, #7296]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #1200]
	ldr	q19, [x8, #1184]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10528]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9792]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #3232]
	ldr	q19, [x8, #3248]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5280]
	ldr	q19, [x8, #5296]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7328]
	ldr	q19, [x8, #7344]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1216]
	ldr	q19, [x8, #1232]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9776]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10512]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3280]
	ldr	q19, [x8, #3264]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5328]
	ldr	q19, [x8, #5312]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #7376]
	ldr	q19, [x8, #7360]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #1264]
	ldr	q19, [x8, #1248]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10496]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9760]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #3296]
	ldr	q19, [x8, #3312]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5344]
	ldr	q19, [x8, #5360]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7392]
	ldr	q19, [x8, #7408]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1280]
	ldr	q19, [x8, #1296]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9744]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10480]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3344]
	ldr	q19, [x8, #3328]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5392]
	ldr	q19, [x8, #5376]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #7440]
	ldr	q19, [x8, #7424]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #1328]
	ldr	q19, [x8, #1312]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10464]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9728]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #3360]
	ldr	q19, [x8, #3376]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5408]
	ldr	q19, [x8, #5424]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7456]
	ldr	q19, [x8, #7472]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1344]
	ldr	q19, [x8, #1360]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9712]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10448]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3408]
	ldr	q19, [x8, #3392]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5456]
	ldr	q19, [x8, #5440]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #7504]
	ldr	q19, [x8, #7488]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #1392]
	ldr	q19, [x8, #1376]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10432]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9696]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #3424]
	ldr	q19, [x8, #3440]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5472]
	ldr	q19, [x8, #5488]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7520]
	ldr	q19, [x8, #7536]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1408]
	ldr	q19, [x8, #1424]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9680]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10416]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3472]
	ldr	q19, [x8, #3456]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5520]
	ldr	q19, [x8, #5504]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #7568]
	ldr	q19, [x8, #7552]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #1456]
	ldr	q19, [x8, #1440]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10400]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9664]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #3488]
	ldr	q19, [x8, #3504]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5536]
	ldr	q19, [x8, #5552]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7584]
	ldr	q19, [x8, #7600]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1472]
	ldr	q19, [x8, #1488]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9648]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10384]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3536]
	ldr	q19, [x8, #3520]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5584]
	ldr	q19, [x8, #5568]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #7632]
	ldr	q19, [x8, #7616]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #1520]
	ldr	q19, [x8, #1504]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10368]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9632]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #3552]
	ldr	q19, [x8, #3568]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5600]
	ldr	q19, [x8, #5616]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7648]
	ldr	q19, [x8, #7664]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1536]
	ldr	q19, [x8, #1552]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9616]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10352]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3600]
	ldr	q19, [x8, #3584]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5648]
	ldr	q19, [x8, #5632]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #7696]
	ldr	q19, [x8, #7680]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #1584]
	ldr	q19, [x8, #1568]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10336]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9600]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #3616]
	ldr	q19, [x8, #3632]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5664]
	ldr	q19, [x8, #5680]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7712]
	ldr	q19, [x8, #7728]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1600]
	ldr	q19, [x8, #1616]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9584]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10320]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3664]
	ldr	q19, [x8, #3648]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5712]
	ldr	q19, [x8, #5696]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #7760]
	ldr	q19, [x8, #7744]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #1648]
	ldr	q19, [x8, #1632]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10304]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9568]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #3680]
	ldr	q19, [x8, #3696]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5728]
	ldr	q19, [x8, #5744]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7776]
	ldr	q19, [x8, #7792]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1664]
	ldr	q19, [x8, #1680]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9552]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10288]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3728]
	ldr	q19, [x8, #3712]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5776]
	ldr	q19, [x8, #5760]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #7824]
	ldr	q19, [x8, #7808]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #1712]
	ldr	q19, [x8, #1696]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10272]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9536]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #3744]
	ldr	q19, [x8, #3760]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5792]
	ldr	q19, [x8, #5808]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7840]
	ldr	q19, [x8, #7856]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1728]
	ldr	q19, [x8, #1744]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9520]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10256]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3792]
	ldr	q19, [x8, #3776]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5840]
	ldr	q19, [x8, #5824]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #7888]
	ldr	q19, [x8, #7872]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #1776]
	ldr	q19, [x8, #1760]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10240]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9504]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #3808]
	ldr	q19, [x8, #3824]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5856]
	ldr	q19, [x8, #5872]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7904]
	ldr	q19, [x8, #7920]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1792]
	ldr	q19, [x8, #1808]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9488]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10224]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3856]
	ldr	q19, [x8, #3840]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5904]
	ldr	q19, [x8, #5888]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #7952]
	ldr	q19, [x8, #7936]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #1840]
	ldr	q19, [x8, #1824]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10208]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9472]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #3872]
	ldr	q19, [x8, #3888]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5920]
	ldr	q19, [x8, #5936]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #7968]
	ldr	q19, [x8, #7984]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1856]
	ldr	q19, [x8, #1872]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9456]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10192]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3920]
	ldr	q19, [x8, #3904]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #5968]
	ldr	q19, [x8, #5952]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #8016]
	ldr	q19, [x8, #8000]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #1904]
	ldr	q19, [x8, #1888]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10176]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9440]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #3936]
	ldr	q19, [x8, #3952]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #5984]
	ldr	q19, [x8, #6000]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #8032]
	ldr	q19, [x8, #8048]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1920]
	ldr	q19, [x8, #1936]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q21, [sp, #9424]                ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #10160]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #3984]
	ldr	q19, [x8, #3968]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #6032]
	ldr	q19, [x8, #6016]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #8080]
	ldr	q19, [x8, #8064]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #1968]
	ldr	q19, [x8, #1952]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10144]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #9408]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #4000]
	ldr	q19, [x8, #4016]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #6048]
	ldr	q19, [x8, #6064]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #8096]
	ldr	q19, [x8, #8112]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v21, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #1984]
	ldr	q19, [x8, #2000]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q22, [sp, #8704]                ; 16-byte Reload
	fmul.4s	v18, v22, v18
	ldr	q0, [sp, #9152]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #4048]
	ldr	q19, [x8, #4032]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v22, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #6096]
	ldr	q19, [x8, #6080]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v22, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #8144]
	ldr	q19, [x8, #8128]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v22, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #2032]
	ldr	q19, [x8, #2016]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q21, [sp, #10128]               ; 16-byte Reload
	fmul.4s	v18, v21, v18
	ldr	q0, [sp, #8896]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	str	q2, [sp, #6096]                 ; 16-byte Spill
	fadd.4s	v2, v3, v18
	str	q2, [sp, #6080]                 ; 16-byte Spill
	ldr	q2, [x8, #4064]
	ldr	q3, [x8, #4080]
	and.16b	v3, v14, v3
	and.16b	v2, v1, v2
	fmul.4s	v2, v0, v2
	fmul.4s	v3, v21, v3
	fadd.4s	v3, v4, v3
	str	q3, [sp, #6608]                 ; 16-byte Spill
	fadd.4s	v2, v5, v2
	str	q2, [sp, #6592]                 ; 16-byte Spill
	ldr	q2, [x8, #6112]
	ldr	q3, [x8, #6128]
	and.16b	v3, v14, v3
	and.16b	v2, v1, v2
	fmul.4s	v2, v0, v2
	fmul.4s	v3, v21, v3
	fadd.4s	v3, v6, v3
	str	q3, [sp, #6640]                 ; 16-byte Spill
	fadd.4s	v2, v7, v2
	str	q2, [sp, #6624]                 ; 16-byte Spill
	ldr	q2, [x8, #8160]
	ldr	q3, [x8, #8176]
	and.16b	v3, v14, v3
	and.16b	v2, v1, v2
	fmul.4s	v2, v0, v2
	fmul.4s	v3, v21, v3
	fadd.4s	v0, v16, v3
	str	q0, [sp, #6672]                 ; 16-byte Spill
	fadd.4s	v0, v17, v2
	str	q0, [sp, #6656]                 ; 16-byte Spill
	ldr	q2, [x8, #8208]
	ldr	q3, [x8, #8192]
	and.16b	v3, v1, v3
	and.16b	v2, v14, v2
	ldr	q18, [sp, #10912]               ; 16-byte Reload
	fmul.4s	v2, v18, v2
	str	q11, [sp, #9136]                ; 16-byte Spill
	fmul.4s	v3, v11, v3
	movi.2d	v0, #0000000000000000
	fadd.4s	v3, v3, v0
	fadd.4s	v2, v2, v0
	ldr	q4, [x8, #10256]
	ldr	q5, [x8, #10240]
	and.16b	v5, v1, v5
	and.16b	v4, v14, v4
	fmul.4s	v4, v18, v4
	fmul.4s	v5, v11, v5
	fadd.4s	v5, v5, v0
	fadd.4s	v4, v4, v0
	ldr	q6, [x8, #12304]
	ldr	q7, [x8, #12288]
	and.16b	v7, v1, v7
	and.16b	v6, v14, v6
	fmul.4s	v6, v18, v6
	fmul.4s	v7, v11, v7
	fadd.4s	v7, v7, v0
	fadd.4s	v6, v6, v0
	ldr	q16, [x8, #14352]
	ldr	q17, [x8, #14336]
	and.16b	v17, v1, v17
	and.16b	v16, v14, v16
	fmul.4s	v16, v18, v16
	fmul.4s	v17, v11, v17
	fadd.4s	v17, v17, v0
	fadd.4s	v16, v16, v0
	ldr	q18, [x8, #8224]
	ldr	q19, [x8, #8240]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	str	q20, [sp, #8736]                ; 16-byte Spill
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10896]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #10272]
	ldr	q19, [x8, #10288]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #12320]
	ldr	q19, [x8, #12336]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #14368]
	ldr	q19, [x8, #14384]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #8272]
	ldr	q19, [x8, #8256]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q0, [sp, #10880]                ; 16-byte Reload
	fmul.4s	v18, v0, v18
	str	q15, [sp, #9120]                ; 16-byte Spill
	fmul.4s	v19, v15, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #10320]
	ldr	q19, [x8, #10304]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v15, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #12368]
	ldr	q19, [x8, #12352]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v15, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #14416]
	ldr	q19, [x8, #14400]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v15, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #8288]
	ldr	q19, [x8, #8304]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q11, [sp, #9104]                ; 16-byte Reload
	fmul.4s	v18, v11, v18
	ldr	q0, [sp, #10864]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #10336]
	ldr	q19, [x8, #10352]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v11, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #12384]
	ldr	q19, [x8, #12400]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v11, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #14432]
	ldr	q19, [x8, #14448]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v11, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #8336]
	ldr	q19, [x8, #8320]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10848]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10112]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #10384]
	ldr	q19, [x8, #10368]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #12432]
	ldr	q19, [x8, #12416]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #14480]
	ldr	q19, [x8, #14464]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #8352]
	ldr	q19, [x8, #8368]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q15, [sp, #9088]                ; 16-byte Reload
	fmul.4s	v18, v15, v18
	ldr	q0, [sp, #10832]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v20, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #10400]
	ldr	q19, [x8, #10416]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v15, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #12448]
	ldr	q19, [x8, #12464]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v15, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #14496]
	ldr	q19, [x8, #14512]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v15, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #8400]
	ldr	q19, [x8, #8384]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q2, [sp, #10816]                ; 16-byte Reload
	fmul.4s	v18, v2, v18
	ldr	q0, [sp, #10096]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v20, v20, v18
	ldr	q18, [x8, #10448]
	ldr	q19, [x8, #10432]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v2, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #12496]
	ldr	q19, [x8, #12480]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v2, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #14544]
	ldr	q19, [x8, #14528]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v2, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #8416]
	ldr	q19, [x8, #8432]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q2, [sp, #10080]                ; 16-byte Reload
	fmul.4s	v18, v2, v18
	ldr	q0, [sp, #10800]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v20, v20, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #10464]
	ldr	q19, [x8, #10480]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v2, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #12512]
	ldr	q19, [x8, #12528]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v2, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #14560]
	ldr	q19, [x8, #14576]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v2, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #8464]
	ldr	q19, [x8, #8448]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q2, [sp, #10784]                ; 16-byte Reload
	fmul.4s	v18, v2, v18
	ldr	q0, [sp, #10064]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v20, v20, v18
	ldr	q18, [x8, #10512]
	ldr	q19, [x8, #10496]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v2, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #12560]
	ldr	q19, [x8, #12544]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v2, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #14608]
	ldr	q19, [x8, #14592]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v2, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #8480]
	ldr	q19, [x8, #8496]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q2, [sp, #10048]                ; 16-byte Reload
	fmul.4s	v18, v2, v18
	ldr	q0, [sp, #10768]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v21, v20, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #10528]
	ldr	q19, [x8, #10544]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v2, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #12576]
	ldr	q19, [x8, #12592]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v2, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #14624]
	ldr	q19, [x8, #14640]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v2, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #8528]
	ldr	q19, [x8, #8512]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q0, [sp, #9360]                 ; 16-byte Reload
	fmul.4s	v18, v0, v18
	ldr	q20, [sp, #9072]                ; 16-byte Reload
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v21, v18
	ldr	q18, [x8, #10576]
	ldr	q19, [x8, #10560]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v20, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #12624]
	ldr	q19, [x8, #12608]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v20, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #14672]
	ldr	q19, [x8, #14656]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v20, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #8544]
	ldr	q19, [x8, #8560]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q0, [sp, #10032]                ; 16-byte Reload
	fmul.4s	v18, v0, v18
	str	q23, [sp, #9344]                ; 16-byte Spill
	fmul.4s	v19, v23, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #10592]
	ldr	q19, [x8, #10608]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v23, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #12640]
	ldr	q19, [x8, #12656]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v23, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #14688]
	ldr	q19, [x8, #14704]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v23, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #8592]
	ldr	q19, [x8, #8576]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q0, [sp, #9328]                 ; 16-byte Reload
	fmul.4s	v18, v0, v18
	str	q24, [sp, #9056]                ; 16-byte Spill
	fmul.4s	v19, v24, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #10640]
	ldr	q19, [x8, #10624]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v24, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #12688]
	ldr	q19, [x8, #12672]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v24, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #14736]
	ldr	q19, [x8, #14720]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v24, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #8608]
	ldr	q19, [x8, #8624]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q0, [sp, #9040]                 ; 16-byte Reload
	fmul.4s	v18, v0, v18
	str	q25, [sp, #9312]                ; 16-byte Spill
	fmul.4s	v19, v25, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #10656]
	ldr	q19, [x8, #10672]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v25, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #12704]
	ldr	q19, [x8, #12720]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v25, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #14752]
	ldr	q19, [x8, #14768]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v25, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #8656]
	ldr	q19, [x8, #8640]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q0, [sp, #9296]                 ; 16-byte Reload
	fmul.4s	v18, v0, v18
	str	q26, [sp, #9024]                ; 16-byte Spill
	fmul.4s	v19, v26, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #10704]
	ldr	q19, [x8, #10688]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v26, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #12752]
	ldr	q19, [x8, #12736]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v26, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #14800]
	ldr	q19, [x8, #14784]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v26, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #8672]
	ldr	q19, [x8, #8688]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q0, [sp, #9008]                 ; 16-byte Reload
	fmul.4s	v18, v0, v18
	str	q27, [sp, #9280]                ; 16-byte Spill
	fmul.4s	v19, v27, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #10720]
	ldr	q19, [x8, #10736]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v27, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #12768]
	ldr	q19, [x8, #12784]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v27, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #14816]
	ldr	q19, [x8, #14832]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v27, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #8720]
	ldr	q19, [x8, #8704]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q0, [sp, #9264]                 ; 16-byte Reload
	fmul.4s	v18, v0, v18
	str	q28, [sp, #8992]                ; 16-byte Spill
	fmul.4s	v19, v28, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #10768]
	ldr	q19, [x8, #10752]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v28, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #12816]
	ldr	q19, [x8, #12800]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v28, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #14864]
	ldr	q19, [x8, #14848]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v28, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #8736]
	ldr	q19, [x8, #8752]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q0, [sp, #8976]                 ; 16-byte Reload
	fmul.4s	v18, v0, v18
	str	q29, [sp, #9248]                ; 16-byte Spill
	fmul.4s	v19, v29, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #10784]
	ldr	q19, [x8, #10800]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v29, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #12832]
	ldr	q19, [x8, #12848]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v29, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #14880]
	ldr	q19, [x8, #14896]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v29, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #8784]
	ldr	q19, [x8, #8768]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q0, [sp, #9232]                 ; 16-byte Reload
	fmul.4s	v18, v0, v18
	str	q30, [sp, #8960]                ; 16-byte Spill
	fmul.4s	v19, v30, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #10832]
	ldr	q19, [x8, #10816]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v30, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #12880]
	ldr	q19, [x8, #12864]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v30, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #14928]
	ldr	q19, [x8, #14912]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v30, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #8800]
	ldr	q19, [x8, #8816]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q0, [sp, #8944]                 ; 16-byte Reload
	fmul.4s	v18, v0, v18
	str	q31, [sp, #9216]                ; 16-byte Spill
	fmul.4s	v19, v31, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #10848]
	ldr	q19, [x8, #10864]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v31, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #12896]
	ldr	q19, [x8, #12912]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v31, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #14944]
	ldr	q19, [x8, #14960]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v31, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #8848]
	ldr	q19, [x8, #8832]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q0, [sp, #9200]                 ; 16-byte Reload
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v8, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #10896]
	ldr	q19, [x8, #10880]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v8, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #12944]
	ldr	q19, [x8, #12928]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v8, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #14992]
	ldr	q19, [x8, #14976]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v8, v19
	mov.16b	v31, v8
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #8864]
	ldr	q19, [x8, #8880]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q0, [sp, #10016]                ; 16-byte Reload
	fmul.4s	v18, v0, v18
	str	q9, [sp, #9184]                 ; 16-byte Spill
	fmul.4s	v19, v9, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #10912]
	ldr	q19, [x8, #10928]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v9, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #12960]
	ldr	q19, [x8, #12976]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v9, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15008]
	ldr	q19, [x8, #15024]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v9, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #8912]
	ldr	q19, [x8, #8896]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q0, [sp, #10752]                ; 16-byte Reload
	fmul.4s	v18, v0, v18
	str	q10, [sp, #8928]                ; 16-byte Spill
	fmul.4s	v19, v10, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #10960]
	ldr	q19, [x8, #10944]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v10, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13008]
	ldr	q19, [x8, #12992]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v10, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #15056]
	ldr	q19, [x8, #15040]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v10, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #8928]
	ldr	q19, [x8, #8944]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q0, [sp, #10000]                ; 16-byte Reload
	fmul.4s	v18, v0, v18
	str	q12, [sp, #9168]                ; 16-byte Spill
	fmul.4s	v19, v12, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #10976]
	ldr	q19, [x8, #10992]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v12, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13024]
	ldr	q19, [x8, #13040]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v12, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15072]
	ldr	q19, [x8, #15088]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v12, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #8976]
	ldr	q19, [x8, #8960]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q0, [sp, #10736]                ; 16-byte Reload
	fmul.4s	v18, v0, v18
	str	q13, [sp, #8912]                ; 16-byte Spill
	fmul.4s	v19, v13, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11024]
	ldr	q19, [x8, #11008]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v13, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13072]
	ldr	q19, [x8, #13056]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v13, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #15120]
	ldr	q19, [x8, #15104]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v13, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #8992]
	ldr	q19, [x8, #9008]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9984]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10720]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #11040]
	ldr	q19, [x8, #11056]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13088]
	ldr	q19, [x8, #13104]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15136]
	ldr	q19, [x8, #15152]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #9040]
	ldr	q19, [x8, #9024]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10704]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9968]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11088]
	ldr	q19, [x8, #11072]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13136]
	ldr	q19, [x8, #13120]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #15184]
	ldr	q19, [x8, #15168]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #9056]
	ldr	q19, [x8, #9072]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9952]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10688]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #11104]
	ldr	q19, [x8, #11120]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13152]
	ldr	q19, [x8, #13168]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15200]
	ldr	q19, [x8, #15216]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #9104]
	ldr	q19, [x8, #9088]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10672]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9936]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11152]
	ldr	q19, [x8, #11136]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13200]
	ldr	q19, [x8, #13184]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #15248]
	ldr	q19, [x8, #15232]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #9120]
	ldr	q19, [x8, #9136]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9920]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10656]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #11168]
	ldr	q19, [x8, #11184]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13216]
	ldr	q19, [x8, #13232]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15264]
	ldr	q19, [x8, #15280]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #9168]
	ldr	q19, [x8, #9152]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10640]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9904]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11216]
	ldr	q19, [x8, #11200]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13264]
	ldr	q19, [x8, #13248]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #15312]
	ldr	q19, [x8, #15296]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #9184]
	ldr	q19, [x8, #9200]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9888]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10624]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #11232]
	ldr	q19, [x8, #11248]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13280]
	ldr	q19, [x8, #13296]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15328]
	ldr	q19, [x8, #15344]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #9232]
	ldr	q19, [x8, #9216]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10608]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9872]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11280]
	ldr	q19, [x8, #11264]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13328]
	ldr	q19, [x8, #13312]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #15376]
	ldr	q19, [x8, #15360]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #9248]
	ldr	q19, [x8, #9264]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9856]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10592]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #11296]
	ldr	q19, [x8, #11312]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13344]
	ldr	q19, [x8, #13360]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15392]
	ldr	q19, [x8, #15408]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #9296]
	ldr	q19, [x8, #9280]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10576]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9840]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11344]
	ldr	q19, [x8, #11328]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13392]
	ldr	q19, [x8, #13376]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #15440]
	ldr	q19, [x8, #15424]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #9312]
	ldr	q19, [x8, #9328]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9824]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10560]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #11360]
	ldr	q19, [x8, #11376]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13408]
	ldr	q19, [x8, #13424]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15456]
	ldr	q19, [x8, #15472]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #9360]
	ldr	q19, [x8, #9344]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10544]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9808]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11408]
	ldr	q19, [x8, #11392]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13456]
	ldr	q19, [x8, #13440]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #15504]
	ldr	q19, [x8, #15488]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #9376]
	ldr	q19, [x8, #9392]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9792]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10528]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #11424]
	ldr	q19, [x8, #11440]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13472]
	ldr	q19, [x8, #13488]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15520]
	ldr	q19, [x8, #15536]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #9424]
	ldr	q19, [x8, #9408]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10512]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9776]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11472]
	ldr	q19, [x8, #11456]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13520]
	ldr	q19, [x8, #13504]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #15568]
	ldr	q19, [x8, #15552]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #9440]
	ldr	q19, [x8, #9456]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9760]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10496]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #11488]
	ldr	q19, [x8, #11504]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13536]
	ldr	q19, [x8, #13552]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15584]
	ldr	q19, [x8, #15600]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #9488]
	ldr	q19, [x8, #9472]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10480]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9744]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11536]
	ldr	q19, [x8, #11520]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13584]
	ldr	q19, [x8, #13568]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #15632]
	ldr	q19, [x8, #15616]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #9504]
	ldr	q19, [x8, #9520]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9728]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10464]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #11552]
	ldr	q19, [x8, #11568]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13600]
	ldr	q19, [x8, #13616]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15648]
	ldr	q19, [x8, #15664]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #9552]
	ldr	q19, [x8, #9536]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10448]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9712]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11600]
	ldr	q19, [x8, #11584]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13648]
	ldr	q19, [x8, #13632]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #15696]
	ldr	q19, [x8, #15680]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #9568]
	ldr	q19, [x8, #9584]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9696]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10432]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #11616]
	ldr	q19, [x8, #11632]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13664]
	ldr	q19, [x8, #13680]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15712]
	ldr	q19, [x8, #15728]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #9616]
	ldr	q19, [x8, #9600]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10416]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9680]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11664]
	ldr	q19, [x8, #11648]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13712]
	ldr	q19, [x8, #13696]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #15760]
	ldr	q19, [x8, #15744]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #9632]
	ldr	q19, [x8, #9648]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9664]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10400]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #11680]
	ldr	q19, [x8, #11696]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13728]
	ldr	q19, [x8, #13744]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15776]
	ldr	q19, [x8, #15792]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #9680]
	ldr	q19, [x8, #9664]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10384]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9648]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11728]
	ldr	q19, [x8, #11712]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13776]
	ldr	q19, [x8, #13760]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #15824]
	ldr	q19, [x8, #15808]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #9696]
	ldr	q19, [x8, #9712]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9632]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10368]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #11744]
	ldr	q19, [x8, #11760]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13792]
	ldr	q19, [x8, #13808]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15840]
	ldr	q19, [x8, #15856]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #9744]
	ldr	q19, [x8, #9728]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10352]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9616]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11792]
	ldr	q19, [x8, #11776]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13840]
	ldr	q19, [x8, #13824]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #15888]
	ldr	q19, [x8, #15872]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #9760]
	ldr	q19, [x8, #9776]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9600]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10336]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #11808]
	ldr	q19, [x8, #11824]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13856]
	ldr	q19, [x8, #13872]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15904]
	ldr	q19, [x8, #15920]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #9808]
	ldr	q19, [x8, #9792]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10320]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9584]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11856]
	ldr	q19, [x8, #11840]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13904]
	ldr	q19, [x8, #13888]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #15952]
	ldr	q19, [x8, #15936]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #9824]
	ldr	q19, [x8, #9840]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9568]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10304]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #11872]
	ldr	q19, [x8, #11888]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13920]
	ldr	q19, [x8, #13936]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #15968]
	ldr	q19, [x8, #15984]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #9872]
	ldr	q19, [x8, #9856]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10288]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9552]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11920]
	ldr	q19, [x8, #11904]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #13968]
	ldr	q19, [x8, #13952]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #16016]
	ldr	q19, [x8, #16000]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #9888]
	ldr	q19, [x8, #9904]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9536]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10272]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #11936]
	ldr	q19, [x8, #11952]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #13984]
	ldr	q19, [x8, #14000]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #16032]
	ldr	q19, [x8, #16048]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #9936]
	ldr	q19, [x8, #9920]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10256]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9520]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #11984]
	ldr	q19, [x8, #11968]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #14032]
	ldr	q19, [x8, #14016]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #16080]
	ldr	q19, [x8, #16064]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #9952]
	ldr	q19, [x8, #9968]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9504]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10240]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #12000]
	ldr	q19, [x8, #12016]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #14048]
	ldr	q19, [x8, #14064]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #16096]
	ldr	q19, [x8, #16112]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #10000]
	ldr	q19, [x8, #9984]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10224]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9488]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #12048]
	ldr	q19, [x8, #12032]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #14096]
	ldr	q19, [x8, #14080]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #16144]
	ldr	q19, [x8, #16128]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #10016]
	ldr	q19, [x8, #10032]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9472]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10208]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #12064]
	ldr	q19, [x8, #12080]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #14112]
	ldr	q19, [x8, #14128]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #16160]
	ldr	q19, [x8, #16176]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #10064]
	ldr	q19, [x8, #10048]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10192]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9456]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #12112]
	ldr	q19, [x8, #12096]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #14160]
	ldr	q19, [x8, #14144]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #16208]
	ldr	q19, [x8, #16192]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #10080]
	ldr	q19, [x8, #10096]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9440]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10176]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #12128]
	ldr	q19, [x8, #12144]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #14176]
	ldr	q19, [x8, #14192]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #16224]
	ldr	q19, [x8, #16240]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #10128]
	ldr	q19, [x8, #10112]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q20, [sp, #10160]               ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #9424]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #12176]
	ldr	q19, [x8, #12160]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #14224]
	ldr	q19, [x8, #14208]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #16272]
	ldr	q19, [x8, #16256]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #10144]
	ldr	q19, [x8, #10160]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #9408]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q0, [sp, #10144]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #12192]
	ldr	q19, [x8, #12208]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #14240]
	ldr	q19, [x8, #14256]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #16288]
	ldr	q19, [x8, #16304]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #10192]
	ldr	q19, [x8, #10176]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q0, [sp, #9152]                 ; 16-byte Reload
	fmul.4s	v18, v0, v18
	str	q22, [sp, #8704]                ; 16-byte Spill
	fmul.4s	v19, v22, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #12240]
	ldr	q19, [x8, #12224]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v22, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #14288]
	ldr	q19, [x8, #14272]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v22, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #16336]
	ldr	q19, [x8, #16320]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v22, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #10208]
	ldr	q19, [x8, #10224]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q20, [sp, #8896]                ; 16-byte Reload
	fmul.4s	v18, v20, v18
	ldr	q21, [sp, #10128]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	fadd.4s	v0, v2, v19
	str	q0, [sp, #6128]                 ; 16-byte Spill
	fadd.4s	v0, v3, v18
	str	q0, [sp, #6112]                 ; 16-byte Spill
	ldr	q2, [x8, #12256]
	ldr	q3, [x8, #12272]
	and.16b	v3, v14, v3
	and.16b	v2, v1, v2
	fmul.4s	v2, v20, v2
	fmul.4s	v3, v21, v3
	fadd.4s	v0, v4, v3
	str	q0, [sp, #6160]                 ; 16-byte Spill
	fadd.4s	v0, v5, v2
	str	q0, [sp, #6144]                 ; 16-byte Spill
	ldr	q2, [x8, #14304]
	ldr	q3, [x8, #14320]
	and.16b	v3, v14, v3
	and.16b	v2, v1, v2
	fmul.4s	v2, v20, v2
	fmul.4s	v3, v21, v3
	fadd.4s	v0, v6, v3
	str	q0, [sp, #6192]                 ; 16-byte Spill
	fadd.4s	v0, v7, v2
	str	q0, [sp, #6176]                 ; 16-byte Spill
	ldr	q2, [x8, #16352]
	ldr	q3, [x8, #16368]
	and.16b	v3, v14, v3
	and.16b	v2, v1, v2
	fmul.4s	v2, v20, v2
	fmul.4s	v3, v21, v3
	fadd.4s	v0, v16, v3
	str	q0, [sp, #6224]                 ; 16-byte Spill
	fadd.4s	v0, v17, v2
	str	q0, [sp, #6208]                 ; 16-byte Spill
	ldr	q2, [x8, #16400]
	ldr	q3, [x8, #16384]
	and.16b	v3, v1, v3
	and.16b	v2, v14, v2
	ldr	q0, [sp, #10912]                ; 16-byte Reload
	fmul.4s	v2, v0, v2
	ldr	q19, [sp, #9136]                ; 16-byte Reload
	fmul.4s	v3, v19, v3
	movi.2d	v18, #0000000000000000
	fadd.4s	v3, v3, v18
	fadd.4s	v2, v2, v18
	ldr	q4, [x8, #18448]
	ldr	q5, [x8, #18432]
	and.16b	v5, v1, v5
	and.16b	v4, v14, v4
	fmul.4s	v4, v0, v4
	fmul.4s	v5, v19, v5
	fadd.4s	v5, v5, v18
	fadd.4s	v4, v4, v18
	ldr	q6, [x8, #20480]
	ldr	q7, [x8, #20496]
	and.16b	v7, v14, v7
	and.16b	v6, v1, v6
	fmul.4s	v6, v19, v6
	fmul.4s	v7, v0, v7
	fadd.4s	v7, v7, v18
	fadd.4s	v6, v6, v18
	ldr	q16, [x8, #22528]
	ldr	q17, [x8, #22544]
	and.16b	v17, v14, v17
	and.16b	v16, v1, v16
	fmul.4s	v16, v19, v16
	fmul.4s	v17, v0, v17
	fadd.4s	v17, v17, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #16416]
	ldr	q19, [x8, #16432]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q13, [sp, #8736]                ; 16-byte Reload
	fmul.4s	v18, v13, v18
	ldr	q0, [sp, #10896]                ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #18464]
	ldr	q19, [x8, #18480]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v13, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #20528]
	ldr	q19, [x8, #20512]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v13, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #22576]
	ldr	q19, [x8, #22560]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v13, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #16464]
	ldr	q19, [x8, #16448]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q0, [sp, #10880]                ; 16-byte Reload
	fmul.4s	v18, v0, v18
	ldr	q20, [sp, #9120]                ; 16-byte Reload
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #18512]
	ldr	q19, [x8, #18496]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v20, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #20544]
	ldr	q19, [x8, #20560]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #22592]
	ldr	q19, [x8, #22608]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #16480]
	ldr	q19, [x8, #16496]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v11, v18
	ldr	q20, [sp, #10864]               ; 16-byte Reload
	fmul.4s	v19, v20, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #18528]
	ldr	q19, [x8, #18544]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v11, v18
	fmul.4s	v19, v20, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #20592]
	ldr	q19, [x8, #20576]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v11, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #22640]
	ldr	q19, [x8, #22624]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v11, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #16528]
	ldr	q19, [x8, #16512]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q0, [sp, #10848]                ; 16-byte Reload
	fmul.4s	v18, v0, v18
	ldr	q20, [sp, #10112]               ; 16-byte Reload
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #18576]
	ldr	q19, [x8, #18560]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v20, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #20608]
	ldr	q19, [x8, #20624]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #22656]
	ldr	q19, [x8, #22672]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #16544]
	ldr	q19, [x8, #16560]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v15, v18
	ldr	q20, [sp, #10832]               ; 16-byte Reload
	fmul.4s	v19, v20, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #18592]
	ldr	q19, [x8, #18608]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v15, v18
	fmul.4s	v19, v20, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #20656]
	ldr	q19, [x8, #20640]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v15, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #22704]
	ldr	q19, [x8, #22688]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v15, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #16592]
	ldr	q19, [x8, #16576]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q0, [sp, #10816]                ; 16-byte Reload
	fmul.4s	v18, v0, v18
	ldr	q20, [sp, #10096]               ; 16-byte Reload
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #18640]
	ldr	q19, [x8, #18624]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v20, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #20672]
	ldr	q19, [x8, #20688]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #22720]
	ldr	q19, [x8, #22736]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #16608]
	ldr	q19, [x8, #16624]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q0, [sp, #10080]                ; 16-byte Reload
	fmul.4s	v18, v0, v18
	ldr	q20, [sp, #10800]               ; 16-byte Reload
	fmul.4s	v19, v20, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #18656]
	ldr	q19, [x8, #18672]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v20, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #20720]
	ldr	q19, [x8, #20704]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #22768]
	ldr	q19, [x8, #22752]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v16, v16, v19
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #16656]
	ldr	q19, [x8, #16640]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	ldr	q0, [sp, #10784]                ; 16-byte Reload
	fmul.4s	v18, v0, v18
	ldr	q20, [sp, #10064]               ; 16-byte Reload
	fmul.4s	v19, v20, v19
	fadd.4s	v3, v3, v19
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #18704]
	ldr	q19, [x8, #18688]
	and.16b	v19, v1, v19
	and.16b	v18, v14, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v20, v19
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #20736]
	ldr	q19, [x8, #20752]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #22784]
	ldr	q19, [x8, #22800]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v20, v18
	fmul.4s	v19, v0, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #16672]
	ldr	q19, [x8, #16688]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	ldr	q0, [sp, #10048]                ; 16-byte Reload
	fmul.4s	v18, v0, v18
	ldr	q20, [sp, #10768]               ; 16-byte Reload
	fmul.4s	v19, v20, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #18720]
	ldr	q19, [x8, #18736]
	and.16b	v19, v14, v19
	and.16b	v18, v1, v18
	fmul.4s	v18, v0, v18
	fmul.4s	v19, v20, v19
	fadd.4s	v19, v4, v19
	fadd.4s	v5, v5, v18
	ldr	q4, [x8, #20784]
	ldr	q18, [x8, #20768]
	and.16b	v18, v1, v18
	and.16b	v4, v14, v4
	fmul.4s	v4, v20, v4
	fmul.4s	v18, v0, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v7, v7, v4
	ldr	q4, [x8, #22832]
	ldr	q18, [x8, #22816]
	and.16b	v18, v1, v18
	and.16b	v4, v14, v4
	fmul.4s	v4, v20, v4
	fmul.4s	v18, v0, v18
	fadd.4s	v16, v16, v18
	fadd.4s	v17, v17, v4
	ldr	q18, [x8, #16720]
	ldr	q20, [x8, #16704]
	ldr	q21, [x8, #18768]
	ldr	q22, [x8, #18752]
	ldr	q23, [x8, #20800]
	ldr	q24, [x8, #20816]
	ldr	q25, [x8, #22848]
	movi.4s	v11, #62, lsl #24
	ldr	q4, [sp, #6080]                 ; 16-byte Reload
	fmul.4s	v30, v4, v11
	ldr	q4, [sp, #6096]                 ; 16-byte Reload
	fmul.4s	v29, v4, v11
	add	x4, x8, #16, lsl #12            ; =65536
	ldr	q26, [x8, #22864]
	ldr	q27, [x8, #16736]
	ldr	q4, [x8, #28976]
	ldr	q28, [x4]
	str	q29, [sp, #5968]                ; 16-byte Spill
	bit.16b	v28, v29, v1
	ldr	q29, [x4, #16]
	str	q30, [sp, #6096]                ; 16-byte Spill
	bit.16b	v29, v30, v14
	stp	q28, q29, [x4]
	and.16b	v20, v1, v20
	ldr	q28, [sp, #9072]                ; 16-byte Reload
	fmul.4s	v20, v28, v20
	fadd.4s	v3, v3, v20
	and.16b	v18, v14, v18
	ldr	q30, [sp, #9360]                ; 16-byte Reload
	fmul.4s	v18, v30, v18
	fadd.4s	v2, v2, v18
	and.16b	v18, v1, v22
	fmul.4s	v18, v28, v18
	fadd.4s	v5, v5, v18
	and.16b	v18, v14, v21
	fmul.4s	v18, v30, v18
	fadd.4s	v18, v19, v18
	and.16b	v19, v14, v24
	and.16b	v20, v1, v23
	fmul.4s	v20, v28, v20
	fmul.4s	v19, v30, v19
	fadd.4s	v7, v7, v19
	fadd.4s	v6, v6, v20
	and.16b	v19, v14, v26
	and.16b	v20, v1, v25
	fmul.4s	v20, v28, v20
	mov.16b	v23, v28
	fmul.4s	v19, v30, v19
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v20
	ldr	q19, [x8, #16752]
	and.16b	v19, v14, v19
	and.16b	v20, v1, v27
	ldr	q21, [sp, #10032]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	ldr	q0, [sp, #9344]                 ; 16-byte Reload
	fmul.4s	v19, v0, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v20
	ldr	q19, [x8, #18784]
	ldr	q20, [x8, #18800]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #20848]
	ldr	q20, [x8, #20832]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #22896]
	ldr	q20, [x8, #22880]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #16784]
	ldr	q20, [x8, #16768]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q8, [sp, #9328]                 ; 16-byte Reload
	fmul.4s	v19, v8, v19
	ldr	q0, [sp, #9056]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #18832]
	ldr	q20, [x8, #18816]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v8, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #20864]
	ldr	q20, [x8, #20880]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v8, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #22912]
	ldr	q20, [x8, #22928]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v8, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #16800]
	ldr	q20, [x8, #16816]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q9, [sp, #9040]                 ; 16-byte Reload
	fmul.4s	v19, v9, v19
	ldr	q0, [sp, #9312]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #18848]
	ldr	q20, [x8, #18864]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v9, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #20912]
	ldr	q20, [x8, #20896]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v9, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #22960]
	ldr	q20, [x8, #22944]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v9, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #16848]
	ldr	q20, [x8, #16832]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q10, [sp, #9296]                ; 16-byte Reload
	fmul.4s	v19, v10, v19
	ldr	q0, [sp, #9024]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #18896]
	ldr	q20, [x8, #18880]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v10, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #20928]
	ldr	q20, [x8, #20944]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v10, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #22976]
	ldr	q20, [x8, #22992]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v10, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #16864]
	ldr	q20, [x8, #16880]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q12, [sp, #9008]                ; 16-byte Reload
	fmul.4s	v19, v12, v19
	ldr	q0, [sp, #9280]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #18912]
	ldr	q20, [x8, #18928]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v12, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #20976]
	ldr	q20, [x8, #20960]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v12, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23024]
	ldr	q20, [x8, #23008]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v12, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #16912]
	ldr	q20, [x8, #16896]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q25, [sp, #9264]                ; 16-byte Reload
	fmul.4s	v19, v25, v19
	ldr	q0, [sp, #8992]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #18960]
	ldr	q20, [x8, #18944]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v25, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #20992]
	ldr	q20, [x8, #21008]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v25, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #23040]
	ldr	q20, [x8, #23056]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v25, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #16928]
	ldr	q20, [x8, #16944]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q26, [sp, #8976]                ; 16-byte Reload
	fmul.4s	v19, v26, v19
	ldr	q0, [sp, #9248]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #18976]
	ldr	q20, [x8, #18992]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v26, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #21040]
	ldr	q20, [x8, #21024]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v26, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23088]
	ldr	q20, [x8, #23072]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v26, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #16976]
	ldr	q20, [x8, #16960]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q27, [sp, #9232]                ; 16-byte Reload
	fmul.4s	v19, v27, v19
	ldr	q0, [sp, #8960]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19024]
	ldr	q20, [x8, #19008]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v27, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #21056]
	ldr	q20, [x8, #21072]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v27, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #23104]
	ldr	q20, [x8, #23120]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v27, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #16992]
	ldr	q20, [x8, #17008]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q28, [sp, #8944]                ; 16-byte Reload
	fmul.4s	v19, v28, v19
	ldr	q0, [sp, #9216]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #19040]
	ldr	q20, [x8, #19056]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v28, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #21104]
	ldr	q20, [x8, #21088]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v28, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23152]
	ldr	q20, [x8, #23136]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v28, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #17040]
	ldr	q20, [x8, #17024]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q29, [sp, #9200]                ; 16-byte Reload
	fmul.4s	v19, v29, v19
	str	q31, [sp, #8720]                ; 16-byte Spill
	fmul.4s	v20, v31, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19088]
	ldr	q20, [x8, #19072]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v29, v19
	fmul.4s	v20, v31, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #21120]
	ldr	q20, [x8, #21136]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v31, v19
	fmul.4s	v20, v29, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #23168]
	ldr	q20, [x8, #23184]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v31, v19
	fmul.4s	v20, v29, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #17056]
	ldr	q20, [x8, #17072]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #10016]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9184]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #19104]
	ldr	q20, [x8, #19120]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #21168]
	ldr	q20, [x8, #21152]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23216]
	ldr	q20, [x8, #23200]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #17104]
	ldr	q20, [x8, #17088]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10752]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #8928]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19152]
	ldr	q20, [x8, #19136]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #21184]
	ldr	q20, [x8, #21200]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #23232]
	ldr	q20, [x8, #23248]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #17120]
	ldr	q20, [x8, #17136]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #10000]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9168]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #19168]
	ldr	q20, [x8, #19184]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #21232]
	ldr	q20, [x8, #21216]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23280]
	ldr	q20, [x8, #23264]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #17168]
	ldr	q20, [x8, #17152]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10736]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #8912]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19216]
	ldr	q20, [x8, #19200]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #21248]
	ldr	q20, [x8, #21264]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #23296]
	ldr	q20, [x8, #23312]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #17184]
	ldr	q20, [x8, #17200]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9984]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10720]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #19232]
	ldr	q20, [x8, #19248]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #21296]
	ldr	q20, [x8, #21280]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23344]
	ldr	q20, [x8, #23328]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #17232]
	ldr	q20, [x8, #17216]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10704]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9968]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19280]
	ldr	q20, [x8, #19264]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #21312]
	ldr	q20, [x8, #21328]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #23360]
	ldr	q20, [x8, #23376]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #17248]
	ldr	q20, [x8, #17264]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9952]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10688]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #19296]
	ldr	q20, [x8, #19312]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #21360]
	ldr	q20, [x8, #21344]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23408]
	ldr	q20, [x8, #23392]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #17296]
	ldr	q20, [x8, #17280]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10672]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9936]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19344]
	ldr	q20, [x8, #19328]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #21376]
	ldr	q20, [x8, #21392]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #23424]
	ldr	q20, [x8, #23440]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #17312]
	ldr	q20, [x8, #17328]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9920]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10656]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #19360]
	ldr	q20, [x8, #19376]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #21424]
	ldr	q20, [x8, #21408]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23472]
	ldr	q20, [x8, #23456]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #17360]
	ldr	q20, [x8, #17344]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10640]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9904]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19408]
	ldr	q20, [x8, #19392]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #21440]
	ldr	q20, [x8, #21456]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #23488]
	ldr	q20, [x8, #23504]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #17376]
	ldr	q20, [x8, #17392]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9888]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10624]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #19424]
	ldr	q20, [x8, #19440]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #21488]
	ldr	q20, [x8, #21472]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23536]
	ldr	q20, [x8, #23520]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #17424]
	ldr	q20, [x8, #17408]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10608]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9872]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19472]
	ldr	q20, [x8, #19456]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #21504]
	ldr	q20, [x8, #21520]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #23552]
	ldr	q20, [x8, #23568]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #17440]
	ldr	q20, [x8, #17456]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9856]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10592]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #19488]
	ldr	q20, [x8, #19504]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #21552]
	ldr	q20, [x8, #21536]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23600]
	ldr	q20, [x8, #23584]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #17488]
	ldr	q20, [x8, #17472]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10576]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9840]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19536]
	ldr	q20, [x8, #19520]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #21568]
	ldr	q20, [x8, #21584]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #23616]
	ldr	q20, [x8, #23632]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #17504]
	ldr	q20, [x8, #17520]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9824]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10560]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #19552]
	ldr	q20, [x8, #19568]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #21616]
	ldr	q20, [x8, #21600]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23664]
	ldr	q20, [x8, #23648]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #17552]
	ldr	q20, [x8, #17536]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10544]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9808]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19600]
	ldr	q20, [x8, #19584]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #21632]
	ldr	q20, [x8, #21648]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #23680]
	ldr	q20, [x8, #23696]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #17568]
	ldr	q20, [x8, #17584]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9792]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10528]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #19616]
	ldr	q20, [x8, #19632]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #21680]
	ldr	q20, [x8, #21664]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23728]
	ldr	q20, [x8, #23712]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #17616]
	ldr	q20, [x8, #17600]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10512]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9776]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19664]
	ldr	q20, [x8, #19648]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #21696]
	ldr	q20, [x8, #21712]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #23744]
	ldr	q20, [x8, #23760]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #17632]
	ldr	q20, [x8, #17648]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9760]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10496]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #19680]
	ldr	q20, [x8, #19696]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #21744]
	ldr	q20, [x8, #21728]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23792]
	ldr	q20, [x8, #23776]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #17680]
	ldr	q20, [x8, #17664]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10480]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9744]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19728]
	ldr	q20, [x8, #19712]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #21760]
	ldr	q20, [x8, #21776]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #23808]
	ldr	q20, [x8, #23824]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #17696]
	ldr	q20, [x8, #17712]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9728]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10464]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #19744]
	ldr	q20, [x8, #19760]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #21808]
	ldr	q20, [x8, #21792]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23856]
	ldr	q20, [x8, #23840]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #17744]
	ldr	q20, [x8, #17728]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10448]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9712]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19792]
	ldr	q20, [x8, #19776]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #21824]
	ldr	q20, [x8, #21840]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #23872]
	ldr	q20, [x8, #23888]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #17760]
	ldr	q20, [x8, #17776]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9696]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10432]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #19808]
	ldr	q20, [x8, #19824]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #21872]
	ldr	q20, [x8, #21856]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23920]
	ldr	q20, [x8, #23904]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #17808]
	ldr	q20, [x8, #17792]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10416]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9680]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19856]
	ldr	q20, [x8, #19840]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #21888]
	ldr	q20, [x8, #21904]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #23936]
	ldr	q20, [x8, #23952]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #17824]
	ldr	q20, [x8, #17840]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9664]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10400]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #19872]
	ldr	q20, [x8, #19888]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #21936]
	ldr	q20, [x8, #21920]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #23984]
	ldr	q20, [x8, #23968]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #17872]
	ldr	q20, [x8, #17856]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10384]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9648]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19920]
	ldr	q20, [x8, #19904]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #21952]
	ldr	q20, [x8, #21968]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #24000]
	ldr	q20, [x8, #24016]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #17888]
	ldr	q20, [x8, #17904]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9632]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10368]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #19936]
	ldr	q20, [x8, #19952]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #22000]
	ldr	q20, [x8, #21984]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #24048]
	ldr	q20, [x8, #24032]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #17936]
	ldr	q20, [x8, #17920]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10352]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9616]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #19984]
	ldr	q20, [x8, #19968]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #22016]
	ldr	q20, [x8, #22032]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #24064]
	ldr	q20, [x8, #24080]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #17952]
	ldr	q20, [x8, #17968]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9600]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10336]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #20000]
	ldr	q20, [x8, #20016]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #22064]
	ldr	q20, [x8, #22048]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #24112]
	ldr	q20, [x8, #24096]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #18000]
	ldr	q20, [x8, #17984]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10320]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9584]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #20048]
	ldr	q20, [x8, #20032]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #22080]
	ldr	q20, [x8, #22096]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #24128]
	ldr	q20, [x8, #24144]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #18016]
	ldr	q20, [x8, #18032]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9568]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10304]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #20064]
	ldr	q20, [x8, #20080]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #22128]
	ldr	q20, [x8, #22112]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #24176]
	ldr	q20, [x8, #24160]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #18064]
	ldr	q20, [x8, #18048]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10288]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9552]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #20112]
	ldr	q20, [x8, #20096]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #22144]
	ldr	q20, [x8, #22160]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #24192]
	ldr	q20, [x8, #24208]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #18080]
	ldr	q20, [x8, #18096]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9536]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10272]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #20128]
	ldr	q20, [x8, #20144]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #22192]
	ldr	q20, [x8, #22176]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #24240]
	ldr	q20, [x8, #24224]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #18128]
	ldr	q20, [x8, #18112]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10256]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9520]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #20176]
	ldr	q20, [x8, #20160]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #22208]
	ldr	q20, [x8, #22224]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #24256]
	ldr	q20, [x8, #24272]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #18144]
	ldr	q20, [x8, #18160]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9504]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10240]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #20192]
	ldr	q20, [x8, #20208]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #22256]
	ldr	q20, [x8, #22240]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #24304]
	ldr	q20, [x8, #24288]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #18192]
	ldr	q20, [x8, #18176]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10224]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9488]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #20240]
	ldr	q20, [x8, #20224]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #22272]
	ldr	q20, [x8, #22288]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #24320]
	ldr	q20, [x8, #24336]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #18208]
	ldr	q20, [x8, #18224]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9472]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10208]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #20256]
	ldr	q20, [x8, #20272]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #22320]
	ldr	q20, [x8, #22304]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #24368]
	ldr	q20, [x8, #24352]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #18256]
	ldr	q20, [x8, #18240]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10192]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9456]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #20304]
	ldr	q20, [x8, #20288]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #22336]
	ldr	q20, [x8, #22352]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #24384]
	ldr	q20, [x8, #24400]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #18272]
	ldr	q20, [x8, #18288]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9440]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10176]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #20320]
	ldr	q20, [x8, #20336]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #22384]
	ldr	q20, [x8, #22368]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #24432]
	ldr	q20, [x8, #24416]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #18320]
	ldr	q20, [x8, #18304]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q21, [sp, #10160]               ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #9424]                 ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #20368]
	ldr	q20, [x8, #20352]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #22400]
	ldr	q20, [x8, #22416]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v6, v6, v19
	ldr	q19, [x8, #24448]
	ldr	q20, [x8, #24464]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v19
	ldr	q19, [x8, #18336]
	ldr	q20, [x8, #18352]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	ldr	q21, [sp, #9408]                ; 16-byte Reload
	fmul.4s	v19, v21, v19
	ldr	q0, [sp, #10144]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v3, v3, v19
	ldr	q19, [x8, #20384]
	ldr	q20, [x8, #20400]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v21, v19
	fmul.4s	v20, v0, v20
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	ldr	q19, [x8, #22448]
	ldr	q20, [x8, #22432]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q19, [x8, #24496]
	ldr	q20, [x8, #24480]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v0, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	ldr	q19, [x8, #18384]
	ldr	q20, [x8, #18368]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	ldr	q24, [sp, #9152]                ; 16-byte Reload
	fmul.4s	v19, v24, v19
	ldr	q15, [sp, #8704]                ; 16-byte Reload
	fmul.4s	v20, v15, v20
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v19
	ldr	q19, [x8, #20432]
	ldr	q20, [x8, #20416]
	and.16b	v20, v1, v20
	and.16b	v19, v14, v19
	fmul.4s	v19, v24, v19
	fmul.4s	v20, v15, v20
	fadd.4s	v5, v5, v20
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #22464]
	ldr	q20, [x8, #22480]
	and.16b	v20, v14, v20
	and.16b	v19, v1, v19
	fmul.4s	v19, v15, v19
	fmul.4s	v20, v24, v20
	fadd.4s	v7, v7, v20
	fadd.4s	v19, v6, v19
	ldr	q6, [x8, #24512]
	ldr	q20, [x8, #24528]
	and.16b	v20, v14, v20
	and.16b	v6, v1, v6
	fmul.4s	v6, v15, v6
	fmul.4s	v20, v24, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v6
	ldr	q6, [x8, #18400]
	ldr	q20, [x8, #18416]
	and.16b	v20, v14, v20
	and.16b	v6, v1, v6
	ldr	q22, [sp, #8896]                ; 16-byte Reload
	fmul.4s	v6, v22, v6
	ldr	q0, [sp, #10128]                ; 16-byte Reload
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v2, v20
	str	q2, [sp, #5984]                 ; 16-byte Spill
	fadd.4s	v6, v3, v6
	ldr	q3, [x8, #20448]
	ldr	q20, [x8, #20464]
	and.16b	v20, v14, v20
	and.16b	v3, v1, v3
	fmul.4s	v3, v22, v3
	fmul.4s	v20, v0, v20
	fadd.4s	v2, v18, v20
	str	q2, [sp, #6016]                 ; 16-byte Spill
	fadd.4s	v2, v5, v3
	str	q2, [sp, #6000]                 ; 16-byte Spill
	ldr	q3, [x8, #22512]
	ldr	q5, [x8, #22496]
	and.16b	v5, v1, v5
	and.16b	v3, v14, v3
	fmul.4s	v3, v0, v3
	fmul.4s	v5, v22, v5
	fadd.4s	v2, v19, v5
	str	q2, [sp, #6048]                 ; 16-byte Spill
	fadd.4s	v2, v7, v3
	str	q2, [sp, #6032]                 ; 16-byte Spill
	ldr	q3, [x8, #24560]
	ldr	q5, [x8, #24544]
	and.16b	v5, v1, v5
	and.16b	v3, v14, v3
	fmul.4s	v3, v0, v3
	fmul.4s	v5, v22, v5
	mov.16b	v2, v22
	fadd.4s	v5, v16, v5
	str	q5, [sp, #6080]                 ; 16-byte Spill
	fadd.4s	v3, v17, v3
	str	q3, [sp, #6064]                 ; 16-byte Spill
	ldr	q3, [x8, #24576]
	ldr	q5, [x8, #24592]
	and.16b	v5, v14, v5
	and.16b	v3, v1, v3
	ldr	q20, [sp, #9136]                ; 16-byte Reload
	fmul.4s	v3, v20, v3
	ldr	q21, [sp, #10912]               ; 16-byte Reload
	fmul.4s	v5, v21, v5
	movi.2d	v19, #0000000000000000
	fadd.4s	v5, v5, v19
	fadd.4s	v3, v3, v19
	ldr	q7, [x8, #26640]
	ldr	q16, [x8, #26624]
	and.16b	v16, v1, v16
	and.16b	v7, v14, v7
	fmul.4s	v7, v21, v7
	fmul.4s	v16, v20, v16
	fadd.4s	v16, v16, v19
	fadd.4s	v7, v7, v19
	ldr	q17, [x8, #28672]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v17, v17, v19
	movi.2d	v0, #0000000000000000
	ldr	q18, [x8, #24608]
	and.16b	v18, v1, v18
	fmul.4s	v18, v13, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #24624]
	and.16b	v18, v14, v18
	ldr	q22, [sp, #10896]               ; 16-byte Reload
	fmul.4s	v18, v22, v18
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #26672]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #26656]
	and.16b	v18, v1, v18
	fmul.4s	v18, v13, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #28704]
	and.16b	v18, v1, v18
	fmul.4s	v18, v13, v18
	fadd.4s	v17, v17, v18
	ldr	q18, [x8, #28688]
	and.16b	v18, v14, v18
	fmul.4s	v18, v21, v18
	fadd.4s	v18, v18, v0
	ldr	q19, [x8, #28720]
	and.16b	v19, v14, v19
	fmul.4s	v19, v22, v19
	fadd.4s	v18, v18, v19
	ldr	q19, [x8, #30720]
	and.16b	v19, v1, v19
	fmul.4s	v19, v20, v19
	fadd.4s	v19, v19, v0
	ldr	q20, [x8, #30752]
	and.16b	v20, v1, v20
	fmul.4s	v20, v13, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #30736]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v20, v20, v0
	ldr	q21, [x8, #30768]
	and.16b	v21, v14, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v20, v20, v21
	ldr	q21, [x8, #24656]
	and.16b	v21, v14, v21
	ldr	q31, [sp, #10880]               ; 16-byte Reload
	fmul.4s	v21, v31, v21
	fadd.4s	v5, v5, v21
	ldr	q21, [x8, #24640]
	and.16b	v21, v1, v21
	ldr	q22, [sp, #9120]                ; 16-byte Reload
	fmul.4s	v21, v22, v21
	fadd.4s	v3, v3, v21
	ldr	q21, [x8, #26688]
	and.16b	v21, v1, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x8, #26704]
	and.16b	v21, v14, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x8, #28752]
	and.16b	v21, v14, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x8, #28736]
	and.16b	v21, v1, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x8, #30800]
	and.16b	v21, v14, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v20, v20, v21
	ldr	q21, [x8, #30784]
	and.16b	v21, v1, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v19, v19, v21
	ldr	q21, [x8, #24672]
	and.16b	v21, v1, v21
	ldr	q31, [sp, #9104]                ; 16-byte Reload
	fmul.4s	v21, v31, v21
	fadd.4s	v3, v3, v21
	ldr	q21, [x8, #24688]
	and.16b	v21, v14, v21
	ldr	q22, [sp, #10864]               ; 16-byte Reload
	fmul.4s	v21, v22, v21
	fadd.4s	v5, v5, v21
	ldr	q21, [x8, #26736]
	and.16b	v21, v14, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x8, #26720]
	and.16b	v21, v1, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x8, #28768]
	and.16b	v21, v1, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x8, #28784]
	and.16b	v21, v14, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x8, #30816]
	and.16b	v21, v1, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v19, v19, v21
	ldr	q21, [x8, #30832]
	and.16b	v21, v14, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v20, v20, v21
	ldr	q21, [x8, #24720]
	and.16b	v21, v14, v21
	ldr	q31, [sp, #10848]               ; 16-byte Reload
	fmul.4s	v21, v31, v21
	fadd.4s	v5, v5, v21
	ldr	q21, [x8, #24704]
	and.16b	v21, v1, v21
	ldr	q22, [sp, #10112]               ; 16-byte Reload
	fmul.4s	v21, v22, v21
	fadd.4s	v3, v3, v21
	ldr	q21, [x8, #26752]
	and.16b	v21, v1, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x8, #26768]
	and.16b	v21, v14, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x8, #28816]
	and.16b	v21, v14, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x8, #28800]
	and.16b	v21, v1, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x8, #30864]
	and.16b	v21, v14, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v20, v20, v21
	ldr	q21, [x8, #30848]
	and.16b	v21, v1, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v19, v19, v21
	ldr	q21, [x8, #24736]
	and.16b	v21, v1, v21
	ldr	q31, [sp, #9088]                ; 16-byte Reload
	fmul.4s	v21, v31, v21
	fadd.4s	v3, v3, v21
	ldr	q21, [x8, #24752]
	and.16b	v21, v14, v21
	ldr	q22, [sp, #10832]               ; 16-byte Reload
	fmul.4s	v21, v22, v21
	fadd.4s	v5, v5, v21
	ldr	q21, [x8, #26800]
	and.16b	v21, v14, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x8, #26784]
	and.16b	v21, v1, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x8, #28832]
	and.16b	v21, v1, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x8, #28848]
	and.16b	v21, v14, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x8, #30880]
	and.16b	v21, v1, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v19, v19, v21
	ldr	q21, [x8, #30896]
	and.16b	v21, v14, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v20, v20, v21
	ldr	q21, [x8, #24784]
	and.16b	v21, v14, v21
	ldr	q31, [sp, #10816]               ; 16-byte Reload
	fmul.4s	v21, v31, v21
	fadd.4s	v5, v5, v21
	ldr	q21, [x8, #24768]
	and.16b	v21, v1, v21
	ldr	q22, [sp, #10096]               ; 16-byte Reload
	fmul.4s	v21, v22, v21
	fadd.4s	v3, v3, v21
	ldr	q21, [x8, #26816]
	and.16b	v21, v1, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x8, #26832]
	and.16b	v21, v14, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x8, #28880]
	and.16b	v21, v14, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x8, #28864]
	and.16b	v21, v1, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x8, #30928]
	and.16b	v21, v14, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v20, v20, v21
	ldr	q21, [x8, #30912]
	and.16b	v21, v1, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v19, v19, v21
	ldr	q21, [x8, #24800]
	and.16b	v21, v1, v21
	ldr	q31, [sp, #10080]               ; 16-byte Reload
	fmul.4s	v21, v31, v21
	fadd.4s	v3, v3, v21
	ldr	q21, [x8, #24816]
	and.16b	v21, v14, v21
	ldr	q22, [sp, #10800]               ; 16-byte Reload
	fmul.4s	v21, v22, v21
	fadd.4s	v5, v5, v21
	ldr	q21, [x8, #26864]
	and.16b	v21, v14, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x8, #26848]
	and.16b	v21, v1, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x8, #28896]
	and.16b	v21, v1, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x8, #28912]
	and.16b	v21, v14, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x8, #30944]
	and.16b	v21, v1, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v19, v19, v21
	ldr	q21, [x8, #30960]
	and.16b	v21, v14, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v20, v20, v21
	ldr	q21, [x8, #24848]
	and.16b	v21, v14, v21
	ldr	q31, [sp, #10784]               ; 16-byte Reload
	fmul.4s	v21, v31, v21
	fadd.4s	v5, v5, v21
	ldr	q21, [x8, #24832]
	and.16b	v21, v1, v21
	ldr	q22, [sp, #10064]               ; 16-byte Reload
	fmul.4s	v21, v22, v21
	fadd.4s	v3, v3, v21
	ldr	q21, [x8, #26880]
	and.16b	v21, v1, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x8, #26896]
	and.16b	v21, v14, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x8, #28944]
	and.16b	v21, v14, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x8, #28928]
	and.16b	v21, v1, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x8, #30992]
	and.16b	v21, v14, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v20, v20, v21
	ldr	q21, [x8, #30976]
	and.16b	v21, v1, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v19, v19, v21
	ldr	q21, [x8, #24864]
	and.16b	v21, v1, v21
	ldr	q31, [sp, #10048]               ; 16-byte Reload
	fmul.4s	v21, v31, v21
	fadd.4s	v3, v3, v21
	ldr	q21, [x8, #24880]
	and.16b	v21, v14, v21
	ldr	q22, [sp, #10768]               ; 16-byte Reload
	fmul.4s	v21, v22, v21
	fadd.4s	v5, v5, v21
	ldr	q21, [x8, #26928]
	and.16b	v21, v14, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x8, #26912]
	and.16b	v21, v1, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x8, #28960]
	and.16b	v21, v1, v21
	fmul.4s	v21, v31, v21
	fadd.4s	v17, v17, v21
	and.16b	v4, v14, v4
	fmul.4s	v4, v22, v4
	fadd.4s	v4, v18, v4
	ldr	q18, [x8, #31008]
	and.16b	v18, v1, v18
	fmul.4s	v18, v31, v18
	fadd.4s	v18, v19, v18
	ldr	q19, [x8, #31024]
	and.16b	v19, v14, v19
	fmul.4s	v19, v22, v19
	fadd.4s	v19, v20, v19
	ldr	q20, [x8, #24912]
	and.16b	v20, v14, v20
	fmul.4s	v20, v30, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #24896]
	and.16b	v20, v1, v20
	fmul.4s	v20, v23, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #26944]
	and.16b	v20, v1, v20
	fmul.4s	v20, v23, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #26960]
	and.16b	v20, v14, v20
	fmul.4s	v20, v30, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29008]
	and.16b	v20, v14, v20
	fmul.4s	v20, v30, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #28992]
	and.16b	v20, v1, v20
	fmul.4s	v20, v23, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #31056]
	and.16b	v20, v14, v20
	fmul.4s	v20, v30, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #31040]
	and.16b	v20, v1, v20
	fmul.4s	v20, v23, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #24928]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #10032]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #24944]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #9344]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #26992]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #26976]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29024]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #29040]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #31072]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #31088]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #24976]
	and.16b	v20, v14, v20
	fmul.4s	v20, v8, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #24960]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9056]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27008]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27024]
	and.16b	v20, v14, v20
	fmul.4s	v20, v8, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29072]
	and.16b	v20, v14, v20
	fmul.4s	v20, v8, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #29056]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #31120]
	and.16b	v20, v14, v20
	fmul.4s	v20, v8, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #31104]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #24992]
	and.16b	v20, v1, v20
	fmul.4s	v20, v9, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25008]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #9312]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #27056]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #27040]
	and.16b	v20, v1, v20
	fmul.4s	v20, v9, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29088]
	and.16b	v20, v1, v20
	fmul.4s	v20, v9, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #29104]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #31136]
	and.16b	v20, v1, v20
	fmul.4s	v20, v9, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #31152]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #25040]
	and.16b	v20, v14, v20
	fmul.4s	v20, v10, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25024]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9024]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27072]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27088]
	and.16b	v20, v14, v20
	fmul.4s	v20, v10, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29136]
	and.16b	v20, v14, v20
	fmul.4s	v20, v10, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #29120]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #31184]
	and.16b	v20, v14, v20
	fmul.4s	v20, v10, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #31168]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #25056]
	and.16b	v20, v1, v20
	fmul.4s	v20, v12, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25072]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #9280]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #27120]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #27104]
	and.16b	v20, v1, v20
	fmul.4s	v20, v12, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29152]
	and.16b	v20, v1, v20
	fmul.4s	v20, v12, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #29168]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #31200]
	and.16b	v20, v1, v20
	fmul.4s	v20, v12, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #31216]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #25104]
	and.16b	v20, v14, v20
	fmul.4s	v20, v25, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25088]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #8992]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27136]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27152]
	and.16b	v20, v14, v20
	fmul.4s	v20, v25, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29200]
	and.16b	v20, v14, v20
	fmul.4s	v20, v25, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #29184]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #31248]
	and.16b	v20, v14, v20
	fmul.4s	v20, v25, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #31232]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #25120]
	and.16b	v20, v1, v20
	fmul.4s	v20, v26, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25136]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #9248]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #27184]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #27168]
	and.16b	v20, v1, v20
	fmul.4s	v20, v26, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29216]
	and.16b	v20, v1, v20
	fmul.4s	v20, v26, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #29232]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #31264]
	and.16b	v20, v1, v20
	fmul.4s	v20, v26, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #31280]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #25168]
	and.16b	v20, v14, v20
	fmul.4s	v20, v27, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25152]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #8960]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27200]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27216]
	and.16b	v20, v14, v20
	fmul.4s	v20, v27, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29264]
	and.16b	v20, v14, v20
	fmul.4s	v20, v27, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #29248]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #31312]
	and.16b	v20, v14, v20
	fmul.4s	v20, v27, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #31296]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #25184]
	and.16b	v20, v1, v20
	fmul.4s	v20, v28, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25200]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #9216]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #27248]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #27232]
	and.16b	v20, v1, v20
	fmul.4s	v20, v28, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29280]
	and.16b	v20, v1, v20
	fmul.4s	v20, v28, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #29296]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #31328]
	and.16b	v20, v1, v20
	fmul.4s	v20, v28, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #31344]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #25232]
	and.16b	v20, v14, v20
	fmul.4s	v20, v29, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25216]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #8720]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27264]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27280]
	and.16b	v20, v14, v20
	fmul.4s	v20, v29, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29328]
	and.16b	v20, v14, v20
	fmul.4s	v20, v29, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #29312]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #31376]
	and.16b	v20, v14, v20
	fmul.4s	v20, v29, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #31360]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #25248]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #10016]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25264]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #9184]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #27312]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #27296]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29344]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #29360]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #31392]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #31408]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #25296]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10752]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25280]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #8928]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27328]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27344]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29392]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #29376]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #31440]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #31424]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #25312]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #10000]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25328]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #9168]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #27376]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #27360]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29408]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #29424]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #31456]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #31472]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #25360]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10736]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25344]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #8912]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27392]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27408]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29456]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #29440]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #31504]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #31488]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #25376]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9984]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25392]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10720]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #27440]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #27424]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29472]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #29488]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #31520]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #31536]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #25424]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10704]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25408]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9968]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27456]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27472]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29520]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #29504]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #31568]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #31552]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #25440]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9952]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25456]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10688]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #27504]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #27488]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29536]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #29552]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #31584]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #31600]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #25488]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10672]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25472]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9936]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27520]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27536]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29584]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #29568]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #31632]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #31616]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #25504]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9920]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25520]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10656]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #27568]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #27552]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29600]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #29616]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #31648]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #31664]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #25552]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10640]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25536]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9904]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27584]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27600]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29648]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #29632]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #31696]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #31680]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #25568]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9888]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25584]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10624]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #27632]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #27616]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29664]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #29680]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #31712]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #31728]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #25616]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10608]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25600]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9872]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27648]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27664]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29712]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #29696]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #31760]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #31744]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #25632]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9856]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25648]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10592]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #27696]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #27680]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29728]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #29744]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #31776]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #31792]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #25680]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10576]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25664]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9840]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27712]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27728]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29776]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #29760]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #31824]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #31808]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #25696]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9824]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25712]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10560]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #27760]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #27744]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29792]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #29808]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #31840]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #31856]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #25744]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10544]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25728]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9808]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27776]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27792]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29840]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #29824]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #31888]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #31872]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #25760]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9792]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25776]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10528]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #27824]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #27808]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29856]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #29872]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #31904]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #31920]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #25808]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10512]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25792]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9776]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27840]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27856]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29904]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #29888]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #31952]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #31936]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #25824]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9760]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25840]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10496]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #27888]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #27872]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29920]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #29936]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #31968]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #31984]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #25872]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10480]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25856]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9744]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27904]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27920]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #29968]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #29952]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #32016]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #32000]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #25888]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9728]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25904]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10464]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #27952]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #27936]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #29984]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #30000]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #32032]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #32048]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #25936]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10448]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25920]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9712]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #27968]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #27984]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #30032]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #30016]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #32080]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #32064]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #25952]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9696]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #25968]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10432]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #28016]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #28000]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #30048]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #30064]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #32096]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #32112]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #26000]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10416]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #25984]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9680]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #28032]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #28048]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #30096]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #30080]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #32144]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #32128]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #26016]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9664]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #26032]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10400]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #28080]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #28064]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #30112]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #30128]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #32160]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #32176]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #26064]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10384]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #26048]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9648]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #28096]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #28112]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #30160]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #30144]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #32208]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #32192]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #26080]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9632]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #26096]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10368]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #28144]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #28128]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #30176]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #30192]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #32224]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #32240]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #26128]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10352]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #26112]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9616]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #28160]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #28176]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #30224]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #30208]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #32272]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #32256]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #26144]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9600]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #26160]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10336]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #28208]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #28192]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #30240]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #30256]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #32288]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #32304]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #26192]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10320]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #26176]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9584]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #28224]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #28240]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #30288]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #30272]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #32336]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #32320]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #26208]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9568]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #26224]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10304]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #28272]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #28256]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #30304]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #30320]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #32352]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #32368]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #26256]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10288]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #26240]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9552]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #28288]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #28304]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #30352]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #30336]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #32400]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #32384]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #26272]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9536]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #26288]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10272]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #28336]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #28320]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #30368]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #30384]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #32416]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #32432]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #26320]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10256]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #26304]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9520]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #28352]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #28368]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #30416]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #30400]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #32464]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #32448]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #26336]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9504]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #26352]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10240]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #28400]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #28384]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #30432]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #30448]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #32480]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #32496]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #26384]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10224]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #26368]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9488]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #28416]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #28432]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #30480]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #30464]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #32528]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #32512]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #26400]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9472]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #26416]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10208]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #28464]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #28448]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #30496]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #30512]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #32544]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #32560]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #26448]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10192]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #26432]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9456]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #28480]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #28496]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #30544]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #30528]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #32592]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #32576]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #26464]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9440]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #26480]
	and.16b	v20, v14, v20
	ldr	q21, [sp, #10176]               ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #28528]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #28512]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #30560]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #30576]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #32608]
	and.16b	v20, v1, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #32624]
	and.16b	v20, v14, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #26512]
	and.16b	v20, v14, v20
	ldr	q22, [sp, #10160]               ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v5, v5, v20
	ldr	q20, [x8, #26496]
	and.16b	v20, v1, v20
	ldr	q21, [sp, #9424]                ; 16-byte Reload
	fmul.4s	v20, v21, v20
	fadd.4s	v3, v3, v20
	ldr	q20, [x8, #28544]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v16, v16, v20
	ldr	q20, [x8, #28560]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v7, v7, v20
	ldr	q20, [x8, #30608]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v4, v4, v20
	ldr	q20, [x8, #30592]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v17, v17, v20
	ldr	q20, [x8, #32656]
	and.16b	v20, v14, v20
	fmul.4s	v20, v22, v20
	fadd.4s	v19, v19, v20
	ldr	q20, [x8, #32640]
	and.16b	v20, v1, v20
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	ldr	q20, [x8, #26528]
	and.16b	v20, v1, v20
	ldr	q22, [sp, #9408]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	fadd.4s	v21, v3, v20
	ldr	q3, [x8, #26544]
	and.16b	v3, v14, v3
	ldr	q20, [sp, #10144]               ; 16-byte Reload
	fmul.4s	v3, v20, v3
	fadd.4s	v3, v5, v3
	ldr	q5, [x8, #28592]
	and.16b	v5, v14, v5
	fmul.4s	v5, v20, v5
	fadd.4s	v7, v7, v5
	ldr	q5, [x8, #28576]
	and.16b	v5, v1, v5
	fmul.4s	v5, v22, v5
	fadd.4s	v16, v16, v5
	ldr	q5, [x8, #30624]
	and.16b	v5, v1, v5
	fmul.4s	v5, v22, v5
	fadd.4s	v5, v17, v5
	ldr	q17, [x8, #30640]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v17, v4, v17
	ldr	q4, [x8, #32672]
	and.16b	v4, v1, v4
	fmul.4s	v4, v22, v4
	fadd.4s	v4, v18, v4
	ldr	q18, [x8, #32688]
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fadd.4s	v20, v19, v18
	ldr	q18, [sp, #6592]                ; 16-byte Reload
	fmul.4s	v13, v18, v11
	ldr	q18, [sp, #6608]                ; 16-byte Reload
	fmul.4s	v12, v18, v11
	ldr	x4, [sp, #4200]                 ; 8-byte Reload
	ldp	q19, q18, [x4]
	bit.16b	v18, v12, v14
	bit.16b	v19, v13, v1
	stp	q19, q18, [x4]
	ldr	q18, [x8, #26576]
	and.16b	v18, v14, v18
	fmul.4s	v18, v24, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [sp, #6624]                ; 16-byte Reload
	fmul.4s	v30, v18, v11
	ldr	q18, [sp, #6640]                ; 16-byte Reload
	fmul.4s	v23, v18, v11
	ldr	x4, [sp, #4192]                 ; 8-byte Reload
	ldp	q19, q18, [x4]
	bit.16b	v18, v23, v14
	bit.16b	v19, v30, v1
	stp	q19, q18, [x4]
	ldr	q18, [x8, #26560]
	and.16b	v18, v1, v18
	fmul.4s	v18, v15, v18
	fadd.4s	v22, v21, v18
	ldr	q18, [sp, #6656]                ; 16-byte Reload
	fmul.4s	v29, v18, v11
	ldr	q18, [sp, #6672]                ; 16-byte Reload
	fmul.4s	v0, v18, v11
	ldr	x4, [sp, #4184]                 ; 8-byte Reload
	ldp	q19, q18, [x4]
	str	q0, [sp, #5824]                 ; 16-byte Spill
	bit.16b	v18, v0, v14
	bit.16b	v19, v29, v1
	stp	q19, q18, [x4]
	ldr	q18, [x8, #28608]
	and.16b	v18, v1, v18
	fmul.4s	v18, v15, v18
	fadd.4s	v21, v16, v18
	ldr	q16, [x8, #28624]
	and.16b	v16, v14, v16
	fmul.4s	v16, v24, v16
	fadd.4s	v25, v7, v16
	ldr	q7, [sp, #6112]                 ; 16-byte Reload
	fmul.4s	v18, v7, v11
	ldr	q7, [sp, #6128]                 ; 16-byte Reload
	fmul.4s	v0, v7, v11
	ldr	x4, [sp, #4176]                 ; 8-byte Reload
	ldp	q16, q7, [x4]
	str	q0, [sp, #5936]                 ; 16-byte Spill
	bit.16b	v7, v0, v14
	str	q18, [sp, #5920]                ; 16-byte Spill
	bit.16b	v16, v18, v1
	stp	q16, q7, [x4]
	ldr	q7, [x8, #30672]
	and.16b	v7, v14, v7
	fmul.4s	v7, v24, v7
	fadd.4s	v16, v17, v7
	ldr	q7, [sp, #6144]                 ; 16-byte Reload
	fmul.4s	v7, v7, v11
	ldr	q17, [sp, #6160]                ; 16-byte Reload
	fmul.4s	v0, v17, v11
	ldr	x4, [sp, #4152]                 ; 8-byte Reload
	ldp	q18, q17, [x4]
	str	q0, [sp, #5872]                 ; 16-byte Spill
	bit.16b	v17, v0, v14
	str	q7, [sp, #5856]                 ; 16-byte Spill
	bit.16b	v18, v7, v1
	stp	q18, q17, [x4]
	ldr	q17, [x8, #30656]
	and.16b	v17, v1, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v8, v5, v17
	ldr	q5, [sp, #6176]                 ; 16-byte Reload
	fmul.4s	v7, v5, v11
	ldr	q5, [sp, #6192]                 ; 16-byte Reload
	fmul.4s	v0, v5, v11
	ldr	x4, [sp, #4144]                 ; 8-byte Reload
	ldp	q26, q5, [x4]
	str	q0, [sp, #5776]                 ; 16-byte Spill
	bit.16b	v5, v0, v14
	str	q7, [sp, #5760]                 ; 16-byte Spill
	bit.16b	v26, v7, v1
	stp	q26, q5, [x4]
	ldr	q5, [x8, #32720]
	and.16b	v5, v14, v5
	fmul.4s	v5, v24, v5
	fadd.4s	v20, v20, v5
	ldr	q5, [x8, #32704]
	and.16b	v5, v1, v5
	fmul.4s	v5, v15, v5
	fadd.4s	v26, v4, v5
	ldr	q4, [sp, #6208]                 ; 16-byte Reload
	fmul.4s	v5, v4, v11
	ldr	q4, [sp, #6224]                 ; 16-byte Reload
	fmul.4s	v0, v4, v11
	ldr	x4, [sp, #4136]                 ; 8-byte Reload
	ldp	q10, q9, [x4]
	str	q0, [sp, #5664]                 ; 16-byte Spill
	bit.16b	v9, v0, v14
	str	q5, [sp, #5648]                 ; 16-byte Spill
	bit.16b	v10, v5, v1
	stp	q10, q9, [x4]
	ldr	q9, [x8, #26592]
	and.16b	v9, v1, v9
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v22, v9
	fmul.4s	v5, v6, v11
	ldr	q4, [sp, #5984]                 ; 16-byte Reload
	fmul.4s	v0, v4, v11
	ldr	x4, [sp, #4128]                 ; 8-byte Reload
	ldp	q10, q6, [x4]
	str	q0, [sp, #5584]                 ; 16-byte Spill
	bit.16b	v6, v0, v14
	str	q5, [sp, #5568]                 ; 16-byte Spill
	bit.16b	v10, v5, v1
	stp	q10, q6, [x4]
	ldr	q6, [x8, #26608]
	and.16b	v6, v14, v6
	ldr	q11, [sp, #10128]               ; 16-byte Reload
	fmul.4s	v6, v11, v6
	fadd.4s	v3, v3, v6
	ldr	q4, [sp, #6000]                 ; 16-byte Reload
	movi.4s	v0, #62, lsl #24
	fmul.4s	v5, v4, v0
	ldr	q4, [sp, #6016]                 ; 16-byte Reload
	fmul.4s	v4, v4, v0
	ldr	x4, [sp, #4120]                 ; 8-byte Reload
	ldp	q24, q6, [x4]
	str	q4, [sp, #5632]                 ; 16-byte Spill
	bit.16b	v6, v4, v14
	str	q5, [sp, #5680]                 ; 16-byte Spill
	bit.16b	v24, v5, v1
	stp	q24, q6, [x4]
	ldr	q6, [x8, #28656]
	and.16b	v6, v14, v6
	fmul.4s	v6, v11, v6
	fadd.4s	v6, v25, v6
	ldr	q24, [x8, #28640]
	and.16b	v24, v1, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v21, v21, v24
	ldr	q4, [sp, #6032]                 ; 16-byte Reload
	fmul.4s	v5, v4, v0
	ldr	q4, [sp, #6048]                 ; 16-byte Reload
	fmul.4s	v4, v4, v0
	ldr	x4, [sp, #4112]                 ; 8-byte Reload
	ldp	q24, q25, [x4]
	str	q4, [sp, #5744]                 ; 16-byte Spill
	bit.16b	v24, v4, v1
	str	q5, [sp, #5696]                 ; 16-byte Spill
	bit.16b	v25, v5, v14
	stp	q24, q25, [x4]
	ldr	q24, [x8, #30688]
	and.16b	v24, v1, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v24, v8, v24
	ldr	q4, [sp, #6064]                 ; 16-byte Reload
	fmul.4s	v5, v4, v0
	ldr	q4, [sp, #6080]                 ; 16-byte Reload
	fmul.4s	v4, v4, v0
	ldr	x4, [sp, #4104]                 ; 8-byte Reload
	ldp	q25, q8, [x4]
	str	q4, [sp, #5808]                 ; 16-byte Spill
	bit.16b	v25, v4, v1
	str	q5, [sp, #5792]                 ; 16-byte Spill
	bit.16b	v8, v5, v14
	stp	q25, q8, [x4]
	ldr	q25, [x8, #30704]
	and.16b	v25, v14, v25
	fmul.4s	v25, v11, v25
	fadd.4s	v16, v16, v25
	fmul.4s	v5, v3, v0
	fmul.4s	v4, v9, v0
	ldr	x4, [sp, #4096]                 ; 8-byte Reload
	ldp	q3, q25, [x4]
	str	q4, [sp, #5904]                 ; 16-byte Spill
	bit.16b	v3, v4, v1
	str	q5, [sp, #5888]                 ; 16-byte Spill
	bit.16b	v25, v5, v14
	stp	q3, q25, [x4]
	ldr	q3, [x8, #32736]
	and.16b	v3, v1, v3
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v26, v3
	fmul.4s	v4, v21, v0
	fmul.4s	v2, v6, v0
	ldr	x4, [sp, #4088]                 ; 8-byte Reload
	ldp	q21, q6, [x4]
	str	q2, [sp, #5984]                 ; 16-byte Spill
	bit.16b	v6, v2, v14
	str	q4, [sp, #5952]                 ; 16-byte Spill
	bit.16b	v21, v4, v1
	stp	q21, q6, [x4]
	ldr	q6, [x8, #32752]
	and.16b	v6, v14, v6
	fmul.4s	v6, v11, v6
	fadd.4s	v6, v20, v6
	fmul.4s	v4, v16, v0
	fmul.4s	v2, v24, v0
	ldr	x4, [sp, #4080]                 ; 8-byte Reload
	ldp	q16, q20, [x4]
	str	q2, [sp, #6064]                 ; 16-byte Spill
	bit.16b	v16, v2, v1
	str	q4, [sp, #6048]                 ; 16-byte Spill
	bit.16b	v20, v4, v14
	stp	q16, q20, [x4]
	fmul.4s	v2, v6, v0
	fmul.4s	v0, v3, v0
	ldp	q3, q6, [x20]
	str	q0, [sp, #6160]                 ; 16-byte Spill
	bit.16b	v3, v0, v1
	str	q2, [sp, #6144]                 ; 16-byte Spill
	bit.16b	v6, v2, v14
	stp	q3, q6, [x20]
	ldr	q0, [sp, #4336]                 ; 16-byte Reload
	ldr	q2, [sp, #6496]                 ; 16-byte Reload
	ldr	q3, [sp, #6304]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #6304]                 ; 16-byte Spill
	ldr	q2, [sp, #4320]                 ; 16-byte Reload
	ldr	q3, [sp, #6480]                 ; 16-byte Reload
	ldr	q4, [sp, #6320]                 ; 16-byte Reload
	bit.16b	v4, v3, v2
	str	q4, [sp, #6320]                 ; 16-byte Spill
	mvni.4s	v3, #127, msl #16
	ldr	q20, [sp, #6384]                ; 16-byte Reload
	bit.16b	v20, v3, v14
	mvni.4s	v5, #127, msl #16
	ldr	q4, [sp, #6400]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
LBB0_616:                               ; %direct.true4496
                                        ;   Parent Loop BB0_579 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x4, x2, x3
	ldp	q3, q6, [x4]
	ldr	q16, [sp, #11296]               ; 16-byte Reload
	and.16b	v6, v16, v6
	ldr	q1, [sp, #11312]                ; 16-byte Reload
	and.16b	v3, v1, v3
	fmaxnm.4s	v3, v4, v3
	fmaxnm.4s	v6, v20, v6
	bit.16b	v20, v6, v16
	bit.16b	v4, v3, v1
	add	x3, x3, #32
	cmp	x3, #512
	b.ne	LBB0_616
; %bb.617:                              ; %direct.false4497
                                        ;   in Loop: Header=BB0_579 Depth=1
	ldr	q3, [sp, #6496]                 ; 16-byte Reload
	ldr	q6, [sp, #6336]                 ; 16-byte Reload
	bit.16b	v6, v3, v0
	str	q6, [sp, #6336]                 ; 16-byte Spill
	ldr	q0, [sp, #6480]                 ; 16-byte Reload
	ldr	q3, [sp, #6368]                 ; 16-byte Reload
	bit.16b	v3, v0, v2
	str	q3, [sp, #6368]                 ; 16-byte Spill
	str	q4, [sp, #6400]                 ; 16-byte Spill
	ldr	q0, [sp, #8864]                 ; 16-byte Reload
	fmaxnm.4s	v17, v0, v4
	ldr	q1, [sp, #5968]                 ; 16-byte Reload
	fsub.4s	v3, v1, v17
	ldr	q14, [sp, #11312]               ; 16-byte Reload
	and.16b	v7, v14, v3
	mov	w3, #-1026555904                ; =0xc2d00000
	dup.4s	v24, w3
	fcmge.4s	v3, v7, v24
	mov	w3, #1120403456                 ; =0x42c80000
	dup.4s	v6, w3
	fcmge.4s	v16, v6, v7
	and.16b	v3, v3, v16
	str	q20, [sp, #6384]                ; 16-byte Spill
	ldr	q0, [sp, #8880]                 ; 16-byte Reload
	fmaxnm.4s	v18, v0, v20
	ldr	q2, [sp, #6096]                 ; 16-byte Reload
	fsub.4s	v16, v2, v18
	ldr	q1, [sp, #11296]                ; 16-byte Reload
	and.16b	v19, v1, v16
	fcmge.4s	v16, v19, v24
	fcmge.4s	v20, v6, v19
	and.16b	v16, v16, v20
	mov	w3, #43579                      ; =0xaa3b
	movk	w3, #16312, lsl #16
	dup.4s	v9, w3
	and.16b	v16, v16, v19
	fmul.4s	v20, v16, v9
	movi.4s	v0, #75, lsl #24
	mvni.4s	v2, #128, lsl #24
	mov.16b	v21, v2
	bsl.16b	v21, v0, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v20, v20, v21
	and.16b	v21, v3, v7
	fmul.4s	v3, v21, v9
	mov.16b	v25, v2
	bsl.16b	v25, v0, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v20
	scvtf.4s	v26, v3
	mov	w3, #29184                      ; =0x7200
	movk	w3, #16177, lsl #16
	dup.4s	v10, w3
	fmul.4s	v20, v26, v10
	fsub.4s	v8, v16, v20
	fcvtzs.4s	v16, v25
	scvtf.4s	v25, v16
	fmul.4s	v20, v25, v10
	fsub.4s	v21, v21, v20
	mov	w3, #48782                      ; =0xbe8e
	movk	w3, #13759, lsl #16
	dup.4s	v31, w3
	fmul.4s	v25, v25, v31
	fsub.4s	v15, v21, v25
	fmul.4s	v21, v26, v31
	fsub.4s	v26, v8, v21
	mov	w3, #11226                      ; =0x2bda
	movk	w3, #14672, lsl #16
	dup.4s	v21, w3
	mov	w3, #38601                      ; =0x96c9
	movk	w3, #15030, lsl #16
	dup.4s	v8, w3
	fmul.4s	v25, v26, v21
	fadd.4s	v25, v25, v8
	fmul.4s	v25, v26, v25
	mov	w3, #34982                      ; =0x88a6
	movk	w3, #15368, lsl #16
	dup.4s	v11, w3
	fadd.4s	v25, v25, v11
	fmul.4s	v25, v26, v25
	mov	w3, #43642                      ; =0xaa7a
	movk	w3, #15658, lsl #16
	dup.4s	v20, w3
	fadd.4s	v2, v25, v20
	mov	w3, #43691                      ; =0xaaab
	movk	w3, #15914, lsl #16
	dup.4s	v25, w3
	fmul.4s	v2, v26, v2
	fadd.4s	v2, v2, v25
	fmul.4s	v2, v26, v2
	movi.4s	v0, #63, lsl #24
	fadd.4s	v2, v2, v0
	movi.4s	v27, #63, lsl #24
	fmul.4s	v22, v26, v26
	fmul.4s	v2, v22, v2
	fmul.4s	v22, v15, v21
	fadd.4s	v22, v22, v8
	fmul.4s	v22, v15, v22
	fadd.4s	v22, v22, v11
	fmul.4s	v22, v15, v22
	fadd.4s	v22, v22, v20
	fmul.4s	v22, v15, v22
	fadd.4s	v22, v22, v25
	fmul.4s	v22, v15, v22
	fadd.4s	v22, v22, v27
	fmul.4s	v4, v15, v15
	fmul.4s	v4, v4, v22
	fadd.4s	v4, v15, v4
	fadd.4s	v2, v26, v2
	fmov.4s	v0, #1.00000000
	fadd.4s	v4, v4, v0
	sshr.4s	v22, v16, #1
	shl.4s	v26, v22, #23
	add.4s	v26, v26, v0
	fmul.4s	v4, v4, v26
	fadd.4s	v2, v2, v0
	sshr.4s	v26, v3, #1
	shl.4s	v15, v26, #23
	add.4s	v15, v15, v0
	fmul.4s	v2, v2, v15
	sub.4s	v16, v16, v22
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v0
	fmul.4s	v2, v2, v3
	shl.4s	v3, v16, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	str	q7, [sp, #6624]                 ; 16-byte Spill
	fcmgt.4s	v4, v24, v7
	bic.16b	v3, v3, v4
	str	q19, [sp, #6672]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v19
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v19, v6
	fneg.4s	v15, v5
	bit.16b	v2, v15, v4
	str	q2, [sp, #6656]                 ; 16-byte Spill
	fcmgt.4s	v2, v7, v6
	bsl.16b	v2, v15, v3
	str	q2, [sp, #6640]                 ; 16-byte Spill
	fsub.4s	v2, v13, v17
	and.16b	v19, v14, v2
	fcmge.4s	v2, v19, v24
	fcmge.4s	v3, v6, v19
	and.16b	v2, v2, v3
	fsub.4s	v3, v12, v18
	and.16b	v28, v1, v3
	fcmge.4s	v3, v28, v24
	fcmge.4s	v4, v6, v28
	and.16b	v3, v3, v4
	and.16b	v4, v3, v28
	fmul.4s	v3, v4, v9
	mvni.4s	v5, #128, lsl #24
	movi.4s	v7, #75, lsl #24
	mov.16b	v16, v5
	bsl.16b	v16, v7, v3
	fadd.4s	v3, v3, v16
	fsub.4s	v3, v3, v16
	and.16b	v2, v2, v19
	fmul.4s	v16, v2, v9
	mov.16b	v22, v5
	bsl.16b	v22, v7, v16
	fadd.4s	v16, v16, v22
	fsub.4s	v16, v16, v22
	fcvtzs.4s	v3, v3
	scvtf.4s	v22, v3
	fmul.4s	v12, v22, v10
	fsub.4s	v4, v4, v12
	fcvtzs.4s	v16, v16
	scvtf.4s	v12, v16
	fmul.4s	v13, v12, v10
	fsub.4s	v2, v2, v13
	fmul.4s	v12, v12, v31
	fsub.4s	v2, v2, v12
	fmul.4s	v22, v22, v31
	fsub.4s	v4, v4, v22
	fmul.4s	v22, v4, v21
	fadd.4s	v22, v22, v8
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v11
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v20
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v25
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v27
	fmul.4s	v12, v4, v4
	fmul.4s	v22, v12, v22
	fmul.4s	v12, v2, v21
	fadd.4s	v12, v12, v8
	fmul.4s	v12, v2, v12
	fadd.4s	v12, v12, v11
	fmul.4s	v12, v2, v12
	fadd.4s	v12, v12, v20
	fmul.4s	v12, v2, v12
	fadd.4s	v12, v12, v25
	fmul.4s	v12, v2, v12
	fadd.4s	v12, v12, v27
	fmul.4s	v13, v2, v2
	fmul.4s	v12, v13, v12
	fadd.4s	v2, v2, v12
	fadd.4s	v4, v4, v22
	fadd.4s	v2, v2, v0
	sshr.4s	v22, v16, #1
	shl.4s	v12, v22, #23
	add.4s	v12, v12, v0
	fmul.4s	v2, v2, v12
	fadd.4s	v4, v4, v0
	sshr.4s	v12, v3, #1
	shl.4s	v13, v12, #23
	add.4s	v13, v13, v0
	fmul.4s	v4, v4, v13
	sub.4s	v16, v16, v22
	sub.4s	v3, v3, v12
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	shl.4s	v4, v16, #23
	add.4s	v4, v4, v0
	fmul.4s	v2, v2, v4
	str	q19, [sp, #6176]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v19
	bic.16b	v2, v2, v4
	str	q28, [sp, #6592]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v28
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v28, v6
	bit.16b	v3, v15, v4
	str	q3, [sp, #6608]                 ; 16-byte Spill
	fcmgt.4s	v3, v19, v6
	bit.16b	v2, v15, v3
	str	q2, [sp, #6192]                 ; 16-byte Spill
	fsub.4s	v2, v30, v17
	and.16b	v7, v14, v2
	fcmge.4s	v2, v7, v24
	fcmge.4s	v3, v6, v7
	and.16b	v2, v2, v3
	fsub.4s	v3, v23, v18
	and.16b	v19, v1, v3
	fcmge.4s	v3, v19, v24
	fcmge.4s	v4, v6, v19
	and.16b	v3, v3, v4
	and.16b	v4, v3, v19
	fmul.4s	v3, v4, v9
	movi.4s	v5, #75, lsl #24
	mvni.4s	v22, #128, lsl #24
	mov.16b	v16, v22
	bsl.16b	v16, v5, v3
	fadd.4s	v3, v3, v16
	fsub.4s	v3, v3, v16
	and.16b	v2, v2, v7
	fmul.4s	v16, v2, v9
	bsl.16b	v22, v5, v16
	mvni.4s	v28, #128, lsl #24
	movi.4s	v27, #75, lsl #24
	fadd.4s	v16, v16, v22
	fsub.4s	v16, v16, v22
	fcvtzs.4s	v3, v3
	scvtf.4s	v22, v3
	fmul.4s	v23, v22, v10
	fsub.4s	v4, v4, v23
	fcvtzs.4s	v16, v16
	scvtf.4s	v23, v16
	fmul.4s	v30, v23, v10
	fsub.4s	v2, v2, v30
	fmul.4s	v23, v23, v31
	fsub.4s	v2, v2, v23
	fmul.4s	v22, v22, v31
	fsub.4s	v4, v4, v22
	fmul.4s	v22, v4, v21
	fadd.4s	v22, v22, v8
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v11
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v20
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v25
	fmul.4s	v22, v4, v22
	movi.4s	v5, #63, lsl #24
	fadd.4s	v22, v22, v5
	fmul.4s	v23, v4, v4
	fmul.4s	v22, v23, v22
	fmul.4s	v23, v2, v21
	fadd.4s	v23, v23, v8
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v20
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v25
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v5
	movi.4s	v26, #63, lsl #24
	fmul.4s	v30, v2, v2
	fmul.4s	v23, v30, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v4, v4, v22
	fadd.4s	v2, v2, v0
	sshr.4s	v22, v16, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v0
	fmul.4s	v2, v2, v23
	fadd.4s	v4, v4, v0
	sshr.4s	v23, v3, #1
	shl.4s	v30, v23, #23
	add.4s	v30, v30, v0
	fmul.4s	v4, v4, v30
	sub.4s	v16, v16, v22
	sub.4s	v3, v3, v23
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	shl.4s	v4, v16, #23
	add.4s	v4, v4, v0
	fmul.4s	v2, v2, v4
	str	q7, [sp, #6080]                 ; 16-byte Spill
	fcmgt.4s	v4, v24, v7
	bic.16b	v2, v2, v4
	str	q19, [sp, #6112]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v19
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v19, v6
	bit.16b	v3, v15, v4
	str	q3, [sp, #6128]                 ; 16-byte Spill
	fcmgt.4s	v3, v7, v6
	bit.16b	v2, v15, v3
	str	q2, [sp, #6096]                 ; 16-byte Spill
	fsub.4s	v2, v29, v17
	and.16b	v30, v14, v2
	fcmge.4s	v2, v30, v24
	fcmge.4s	v3, v6, v30
	and.16b	v2, v2, v3
	ldr	q3, [sp, #5824]                 ; 16-byte Reload
	fsub.4s	v3, v3, v18
	and.16b	v5, v1, v3
	fcmge.4s	v3, v5, v24
	fcmge.4s	v4, v6, v5
	and.16b	v3, v3, v4
	and.16b	v4, v3, v5
	fmul.4s	v3, v4, v9
	mov.16b	v16, v28
	bsl.16b	v16, v27, v3
	fadd.4s	v3, v3, v16
	fsub.4s	v3, v3, v16
	and.16b	v2, v2, v30
	fmul.4s	v16, v2, v9
	mov.16b	v22, v28
	bsl.16b	v22, v27, v16
	fadd.4s	v16, v16, v22
	fsub.4s	v16, v16, v22
	fcvtzs.4s	v3, v3
	scvtf.4s	v22, v3
	fmul.4s	v23, v22, v10
	fsub.4s	v4, v4, v23
	fcvtzs.4s	v16, v16
	scvtf.4s	v23, v16
	fmul.4s	v29, v23, v10
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v31
	fsub.4s	v2, v2, v23
	fmul.4s	v22, v22, v31
	fsub.4s	v4, v4, v22
	fmul.4s	v22, v4, v21
	fadd.4s	v22, v22, v8
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v11
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v20
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v25
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v26
	fmul.4s	v23, v4, v4
	fmul.4s	v22, v23, v22
	fmul.4s	v23, v2, v21
	fadd.4s	v23, v23, v8
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v20
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v25
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v26
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v4, v4, v22
	fadd.4s	v2, v2, v0
	sshr.4s	v22, v16, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v0
	fmul.4s	v2, v2, v23
	fadd.4s	v4, v4, v0
	sshr.4s	v23, v3, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v0
	fmul.4s	v4, v4, v29
	sub.4s	v16, v16, v22
	sub.4s	v3, v3, v23
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	shl.4s	v4, v16, #23
	add.4s	v4, v4, v0
	fmul.4s	v2, v2, v4
	str	q30, [sp, #5840]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v30
	bic.16b	v2, v2, v4
	str	q5, [sp, #6000]                 ; 16-byte Spill
	fcmgt.4s	v4, v24, v5
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v5, v6
	bit.16b	v3, v15, v4
	str	q3, [sp, #6032]                 ; 16-byte Spill
	fcmgt.4s	v3, v30, v6
	bit.16b	v2, v15, v3
	str	q2, [sp, #6016]                 ; 16-byte Spill
	ldr	q2, [sp, #5920]                 ; 16-byte Reload
	fsub.4s	v2, v2, v17
	and.16b	v29, v14, v2
	fcmge.4s	v2, v29, v24
	fcmge.4s	v3, v6, v29
	and.16b	v2, v2, v3
	ldr	q3, [sp, #5936]                 ; 16-byte Reload
	fsub.4s	v3, v3, v18
	and.16b	v5, v1, v3
	fcmge.4s	v3, v5, v24
	fcmge.4s	v4, v6, v5
	and.16b	v3, v3, v4
	and.16b	v4, v3, v5
	fmul.4s	v3, v4, v9
	movi.4s	v7, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	mov.16b	v16, v19
	bsl.16b	v16, v7, v3
	fadd.4s	v3, v3, v16
	fsub.4s	v3, v3, v16
	and.16b	v2, v2, v29
	fmul.4s	v16, v2, v9
	mov.16b	v22, v19
	bsl.16b	v22, v7, v16
	mvni.4s	v30, #128, lsl #24
	fadd.4s	v16, v16, v22
	fsub.4s	v16, v16, v22
	fcvtzs.4s	v3, v3
	scvtf.4s	v22, v3
	fmul.4s	v23, v22, v10
	fsub.4s	v4, v4, v23
	fcvtzs.4s	v16, v16
	scvtf.4s	v23, v16
	fmul.4s	v27, v23, v10
	fsub.4s	v2, v2, v27
	fmul.4s	v23, v23, v31
	fsub.4s	v2, v2, v23
	fmul.4s	v22, v22, v31
	fsub.4s	v4, v4, v22
	fmul.4s	v22, v4, v21
	fadd.4s	v22, v22, v8
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v11
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v20
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v25
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v26
	fmul.4s	v23, v4, v4
	fmul.4s	v22, v23, v22
	fmul.4s	v23, v2, v21
	fadd.4s	v23, v23, v8
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v20
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v25
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v26
	fmul.4s	v27, v2, v2
	fmul.4s	v23, v27, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v4, v4, v22
	fadd.4s	v2, v2, v0
	sshr.4s	v22, v16, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v0
	fmul.4s	v2, v2, v23
	fadd.4s	v4, v4, v0
	sshr.4s	v23, v3, #1
	shl.4s	v27, v23, #23
	add.4s	v27, v27, v0
	fmul.4s	v4, v4, v27
	sub.4s	v16, v16, v22
	sub.4s	v3, v3, v23
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	shl.4s	v4, v16, #23
	add.4s	v4, v4, v0
	fmul.4s	v2, v2, v4
	str	q29, [sp, #5728]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v29
	bic.16b	v2, v2, v4
	str	q5, [sp, #5920]                 ; 16-byte Spill
	fcmgt.4s	v4, v24, v5
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v5, v6
	bit.16b	v3, v15, v4
	str	q3, [sp, #5936]                 ; 16-byte Spill
	fcmgt.4s	v3, v29, v6
	bit.16b	v2, v15, v3
	str	q2, [sp, #5968]                 ; 16-byte Spill
	ldr	q2, [sp, #5856]                 ; 16-byte Reload
	fsub.4s	v2, v2, v17
	and.16b	v23, v14, v2
	fcmge.4s	v2, v23, v24
	fcmge.4s	v3, v6, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #5872]                 ; 16-byte Reload
	fsub.4s	v3, v3, v18
	and.16b	v27, v1, v3
	fcmge.4s	v3, v27, v24
	fcmge.4s	v4, v6, v27
	and.16b	v3, v3, v4
	and.16b	v4, v3, v27
	fmul.4s	v3, v4, v9
	movi.4s	v5, #75, lsl #24
	mov.16b	v7, v30
	bsl.16b	v7, v5, v3
	fadd.4s	v3, v3, v7
	fsub.4s	v3, v3, v7
	and.16b	v2, v2, v23
	fmul.4s	v7, v2, v9
	mov.16b	v16, v30
	bsl.16b	v16, v5, v7
	fadd.4s	v7, v7, v16
	fsub.4s	v7, v7, v16
	fcvtzs.4s	v3, v3
	scvtf.4s	v16, v3
	fmul.4s	v19, v16, v10
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v22, v19, v10
	fsub.4s	v2, v2, v22
	fmul.4s	v19, v19, v31
	fsub.4s	v2, v2, v19
	fmul.4s	v16, v16, v31
	fsub.4s	v4, v4, v16
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v11
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v20
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v19, v4, v4
	fmul.4s	v16, v19, v16
	fmul.4s	v19, v2, v21
	fadd.4s	v19, v19, v8
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v11
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v26
	fmul.4s	v22, v2, v2
	fmul.4s	v19, v22, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v4, v4, v16
	fadd.4s	v2, v2, v0
	sshr.4s	v16, v7, #1
	shl.4s	v19, v16, #23
	add.4s	v19, v19, v0
	fmul.4s	v2, v2, v19
	fadd.4s	v4, v4, v0
	sshr.4s	v19, v3, #1
	shl.4s	v22, v19, #23
	add.4s	v22, v22, v0
	fmul.4s	v4, v4, v22
	sub.4s	v7, v7, v16
	sub.4s	v3, v3, v19
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	shl.4s	v4, v7, #23
	add.4s	v4, v4, v0
	fmul.4s	v2, v2, v4
	str	q23, [sp, #5616]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v23
	bic.16b	v2, v2, v4
	str	q27, [sp, #5824]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v27
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v27, v6
	bit.16b	v3, v15, v4
	str	q3, [sp, #5872]                 ; 16-byte Spill
	fcmgt.4s	v3, v23, v6
	bit.16b	v2, v15, v3
	str	q2, [sp, #5856]                 ; 16-byte Spill
	ldr	q2, [sp, #5760]                 ; 16-byte Reload
	fsub.4s	v2, v2, v17
	mov.16b	v5, v17
	and.16b	v23, v14, v2
	mov.16b	v29, v14
	fcmge.4s	v2, v23, v24
	fcmge.4s	v3, v6, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #5776]                 ; 16-byte Reload
	fsub.4s	v3, v3, v18
	mov.16b	v19, v18
	and.16b	v27, v1, v3
	fcmge.4s	v3, v27, v24
	fcmge.4s	v4, v6, v27
	and.16b	v3, v3, v4
	and.16b	v4, v3, v27
	fmul.4s	v3, v4, v9
	movi.4s	v16, #75, lsl #24
	mov.16b	v7, v30
	bsl.16b	v7, v16, v3
	fadd.4s	v3, v3, v7
	fsub.4s	v3, v3, v7
	and.16b	v2, v2, v23
	fmul.4s	v7, v2, v9
	bif.16b	v16, v7, v30
	movi.4s	v14, #75, lsl #24
	fadd.4s	v7, v7, v16
	fsub.4s	v7, v7, v16
	fcvtzs.4s	v3, v3
	scvtf.4s	v16, v3
	fmul.4s	v17, v16, v10
	fsub.4s	v4, v4, v17
	fcvtzs.4s	v7, v7
	scvtf.4s	v17, v7
	fmul.4s	v18, v17, v10
	fsub.4s	v2, v2, v18
	fmul.4s	v17, v17, v31
	fsub.4s	v2, v2, v17
	fmul.4s	v16, v16, v31
	fsub.4s	v4, v4, v16
	fmul.4s	v16, v4, v21
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v11
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v20
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v4, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v17, v4, v4
	fmul.4s	v16, v17, v16
	fmul.4s	v17, v2, v21
	fadd.4s	v17, v17, v8
	fmul.4s	v17, v2, v17
	fadd.4s	v17, v17, v11
	fmul.4s	v17, v2, v17
	fadd.4s	v17, v17, v20
	fmul.4s	v17, v2, v17
	fadd.4s	v17, v17, v25
	fmul.4s	v17, v2, v17
	fadd.4s	v17, v17, v26
	fmul.4s	v18, v2, v2
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	fadd.4s	v4, v4, v16
	fadd.4s	v2, v2, v0
	sshr.4s	v16, v7, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v0
	fmul.4s	v2, v2, v17
	fadd.4s	v4, v4, v0
	sshr.4s	v17, v3, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v0
	fmul.4s	v4, v4, v18
	sub.4s	v7, v7, v16
	sub.4s	v3, v3, v17
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	shl.4s	v4, v7, #23
	add.4s	v4, v4, v0
	fmul.4s	v2, v2, v4
	str	q23, [sp, #5552]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v23
	bic.16b	v2, v2, v4
	str	q27, [sp, #5712]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v27
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v27, v6
	bit.16b	v3, v15, v4
	str	q3, [sp, #5776]                 ; 16-byte Spill
	fcmgt.4s	v3, v23, v6
	bit.16b	v2, v15, v3
	str	q2, [sp, #5760]                 ; 16-byte Spill
	mov.16b	v18, v5
	ldr	q2, [sp, #5648]                 ; 16-byte Reload
	fsub.4s	v2, v2, v5
	and.16b	v23, v29, v2
	fcmge.4s	v2, v23, v24
	fcmge.4s	v3, v6, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #5664]                 ; 16-byte Reload
	fsub.4s	v3, v3, v19
	and.16b	v27, v1, v3
	fcmge.4s	v3, v27, v24
	fcmge.4s	v4, v6, v27
	and.16b	v3, v3, v4
	and.16b	v4, v3, v27
	fmul.4s	v3, v4, v9
	mov.16b	v5, v30
	bsl.16b	v5, v14, v3
	fadd.4s	v3, v3, v5
	fsub.4s	v3, v3, v5
	and.16b	v2, v2, v23
	fmul.4s	v5, v2, v9
	mov.16b	v7, v30
	bsl.16b	v7, v14, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	fcvtzs.4s	v3, v3
	scvtf.4s	v7, v3
	fmul.4s	v16, v7, v10
	fsub.4s	v4, v4, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v17, v16, v10
	fsub.4s	v2, v2, v17
	fmul.4s	v16, v16, v31
	fsub.4s	v2, v2, v16
	fmul.4s	v7, v7, v31
	fsub.4s	v4, v4, v7
	fmul.4s	v7, v4, v21
	fadd.4s	v7, v7, v8
	fmul.4s	v7, v4, v7
	fadd.4s	v7, v7, v11
	fmul.4s	v7, v4, v7
	fadd.4s	v7, v7, v20
	fmul.4s	v7, v4, v7
	fadd.4s	v7, v7, v25
	fmul.4s	v7, v4, v7
	fadd.4s	v7, v7, v26
	fmul.4s	v16, v4, v4
	fmul.4s	v7, v16, v7
	fmul.4s	v16, v2, v21
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v2, v16
	fadd.4s	v16, v16, v11
	fmul.4s	v16, v2, v16
	fadd.4s	v16, v16, v20
	fmul.4s	v16, v2, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v2, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v17, v2, v2
	fmul.4s	v16, v17, v16
	fadd.4s	v2, v2, v16
	fadd.4s	v4, v4, v7
	fadd.4s	v2, v2, v0
	sshr.4s	v7, v5, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v0
	fmul.4s	v2, v2, v16
	fadd.4s	v4, v4, v0
	sshr.4s	v16, v3, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v0
	fmul.4s	v4, v4, v17
	sub.4s	v5, v5, v7
	sub.4s	v3, v3, v16
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	shl.4s	v4, v5, #23
	add.4s	v4, v4, v0
	fmul.4s	v2, v2, v4
	str	q23, [sp, #5392]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v23
	bic.16b	v2, v2, v4
	str	q27, [sp, #5600]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v27
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v27, v6
	bit.16b	v3, v15, v4
	str	q3, [sp, #5664]                 ; 16-byte Spill
	fcmgt.4s	v3, v23, v6
	bit.16b	v2, v15, v3
	str	q2, [sp, #5648]                 ; 16-byte Spill
	ldr	q2, [sp, #5568]                 ; 16-byte Reload
	fsub.4s	v2, v2, v18
	and.16b	v23, v29, v2
	fcmge.4s	v2, v23, v24
	fcmge.4s	v3, v6, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #5584]                 ; 16-byte Reload
	fsub.4s	v3, v3, v19
	and.16b	v27, v1, v3
	fcmge.4s	v3, v27, v24
	fcmge.4s	v4, v6, v27
	and.16b	v3, v3, v4
	and.16b	v3, v3, v27
	fmul.4s	v4, v3, v9
	mov.16b	v5, v30
	bsl.16b	v5, v14, v4
	fadd.4s	v4, v4, v5
	fsub.4s	v4, v4, v5
	and.16b	v5, v2, v23
	fmul.4s	v2, v5, v9
	mov.16b	v7, v30
	bsl.16b	v7, v14, v2
	fadd.4s	v2, v2, v7
	fsub.4s	v7, v2, v7
	fcvtzs.4s	v2, v4
	scvtf.4s	v4, v2
	fmul.4s	v16, v4, v10
	fsub.4s	v3, v3, v16
	fcvtzs.4s	v7, v7
	scvtf.4s	v16, v7
	fmul.4s	v17, v16, v10
	fsub.4s	v5, v5, v17
	fmul.4s	v16, v16, v31
	fsub.4s	v5, v5, v16
	fmul.4s	v4, v4, v31
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v3, v21
	fadd.4s	v4, v4, v8
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v11
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v20
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v25
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v26
	fmul.4s	v16, v3, v3
	fmul.4s	v4, v16, v4
	fmul.4s	v16, v5, v21
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v11
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v20
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v3, v3, v4
	fadd.4s	v4, v5, v0
	sshr.4s	v5, v7, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v0
	fmul.4s	v4, v4, v16
	fadd.4s	v3, v3, v0
	sshr.4s	v16, v2, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v0
	fmul.4s	v3, v3, v17
	sub.4s	v5, v7, v5
	sub.4s	v2, v2, v16
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v0
	fmul.4s	v2, v3, v2
	shl.4s	v3, v5, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	str	q23, [sp, #5296]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v23
	bic.16b	v3, v3, v4
	str	q27, [sp, #5520]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v27
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v27, v6
	bit.16b	v2, v15, v4
	str	q2, [sp, #5584]                 ; 16-byte Spill
	fcmgt.4s	v2, v23, v6
	bsl.16b	v2, v15, v3
	str	q2, [sp, #5568]                 ; 16-byte Spill
	ldr	q2, [sp, #5632]                 ; 16-byte Reload
	fsub.4s	v2, v2, v19
	and.16b	v23, v1, v2
	fcmge.4s	v2, v23, v24
	fcmge.4s	v3, v6, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #5680]                 ; 16-byte Reload
	fsub.4s	v3, v3, v18
	and.16b	v22, v29, v3
	fcmge.4s	v3, v22, v24
	fcmge.4s	v4, v6, v22
	and.16b	v3, v3, v4
	and.16b	v3, v3, v22
	fmul.4s	v4, v3, v9
	mov.16b	v5, v30
	bsl.16b	v5, v14, v4
	fadd.4s	v4, v4, v5
	fsub.4s	v4, v4, v5
	and.16b	v5, v2, v23
	fmul.4s	v2, v5, v9
	mov.16b	v7, v30
	bsl.16b	v7, v14, v2
	fadd.4s	v2, v2, v7
	fsub.4s	v7, v2, v7
	fcvtzs.4s	v2, v4
	scvtf.4s	v4, v2
	fmul.4s	v16, v4, v10
	fsub.4s	v3, v3, v16
	fcvtzs.4s	v7, v7
	scvtf.4s	v16, v7
	fmul.4s	v17, v16, v10
	fsub.4s	v5, v5, v17
	fmul.4s	v16, v16, v31
	fsub.4s	v5, v5, v16
	fmul.4s	v4, v4, v31
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v3, v21
	fadd.4s	v4, v4, v8
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v11
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v20
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v25
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v26
	fmul.4s	v16, v3, v3
	fmul.4s	v4, v16, v4
	fmul.4s	v16, v5, v21
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v11
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v20
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v3, v3, v4
	fadd.4s	v4, v5, v0
	sshr.4s	v5, v7, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v0
	fmul.4s	v4, v4, v16
	fadd.4s	v3, v3, v0
	sshr.4s	v16, v2, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v0
	fmul.4s	v3, v3, v17
	sub.4s	v5, v7, v5
	sub.4s	v2, v2, v16
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v0
	fmul.4s	v2, v3, v2
	shl.4s	v3, v5, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	str	q23, [sp, #5280]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v23
	bic.16b	v3, v3, v4
	str	q22, [sp, #5632]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v22
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v22, v6
	bit.16b	v2, v15, v4
	str	q2, [sp, #5680]                 ; 16-byte Spill
	fcmgt.4s	v2, v23, v6
	bsl.16b	v2, v15, v3
	str	q2, [sp, #5536]                 ; 16-byte Spill
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	fsub.4s	v2, v2, v19
	and.16b	v23, v1, v2
	fcmge.4s	v2, v23, v24
	fcmge.4s	v3, v6, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #5744]                 ; 16-byte Reload
	fsub.4s	v3, v3, v18
	and.16b	v22, v29, v3
	fcmge.4s	v3, v22, v24
	fcmge.4s	v4, v6, v22
	and.16b	v3, v3, v4
	and.16b	v3, v3, v22
	fmul.4s	v4, v3, v9
	mov.16b	v5, v30
	bsl.16b	v5, v14, v4
	fadd.4s	v4, v4, v5
	fsub.4s	v4, v4, v5
	and.16b	v5, v2, v23
	fmul.4s	v2, v5, v9
	mov.16b	v7, v30
	bsl.16b	v7, v14, v2
	fadd.4s	v2, v2, v7
	fsub.4s	v7, v2, v7
	fcvtzs.4s	v2, v4
	scvtf.4s	v4, v2
	fmul.4s	v16, v4, v10
	fsub.4s	v3, v3, v16
	fcvtzs.4s	v7, v7
	scvtf.4s	v16, v7
	fmul.4s	v17, v16, v10
	fsub.4s	v5, v5, v17
	fmul.4s	v16, v16, v31
	fsub.4s	v5, v5, v16
	fmul.4s	v4, v4, v31
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v3, v21
	fadd.4s	v4, v4, v8
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v11
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v20
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v25
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v26
	fmul.4s	v16, v3, v3
	fmul.4s	v4, v16, v4
	fmul.4s	v16, v5, v21
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v11
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v20
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v3, v3, v4
	fadd.4s	v4, v5, v0
	sshr.4s	v5, v7, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v0
	fmul.4s	v4, v4, v16
	fadd.4s	v3, v3, v0
	sshr.4s	v16, v2, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v0
	fmul.4s	v3, v3, v17
	sub.4s	v5, v7, v5
	sub.4s	v2, v2, v16
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v0
	fmul.4s	v2, v3, v2
	shl.4s	v3, v5, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	str	q23, [sp, #5264]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v23
	bic.16b	v3, v3, v4
	str	q22, [sp, #5696]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v22
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v22, v6
	bit.16b	v2, v15, v4
	str	q2, [sp, #5744]                 ; 16-byte Spill
	fcmgt.4s	v2, v23, v6
	bsl.16b	v2, v15, v3
	str	q2, [sp, #5504]                 ; 16-byte Spill
	ldr	q2, [sp, #5792]                 ; 16-byte Reload
	fsub.4s	v2, v2, v19
	and.16b	v22, v1, v2
	fcmge.4s	v2, v22, v24
	fcmge.4s	v3, v6, v22
	and.16b	v2, v2, v3
	ldr	q3, [sp, #5808]                 ; 16-byte Reload
	fsub.4s	v3, v3, v18
	and.16b	v28, v29, v3
	fcmge.4s	v3, v28, v24
	fcmge.4s	v4, v6, v28
	and.16b	v3, v3, v4
	and.16b	v3, v3, v28
	fmul.4s	v4, v3, v9
	mov.16b	v5, v30
	bsl.16b	v5, v14, v4
	fadd.4s	v4, v4, v5
	fsub.4s	v4, v4, v5
	and.16b	v5, v2, v22
	fmul.4s	v2, v5, v9
	mov.16b	v7, v30
	bsl.16b	v7, v14, v2
	fadd.4s	v2, v2, v7
	fsub.4s	v7, v2, v7
	fcvtzs.4s	v2, v4
	scvtf.4s	v4, v2
	fmul.4s	v16, v4, v10
	fsub.4s	v3, v3, v16
	fcvtzs.4s	v7, v7
	scvtf.4s	v16, v7
	fmul.4s	v17, v16, v10
	fsub.4s	v5, v5, v17
	fmul.4s	v16, v16, v31
	fsub.4s	v5, v5, v16
	fmul.4s	v4, v4, v31
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v3, v21
	fadd.4s	v4, v4, v8
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v11
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v20
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v25
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v26
	fmul.4s	v16, v3, v3
	fmul.4s	v4, v16, v4
	fmul.4s	v16, v5, v21
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v11
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v20
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v3, v3, v4
	fadd.4s	v4, v5, v0
	sshr.4s	v5, v7, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v0
	fmul.4s	v4, v4, v16
	fadd.4s	v3, v3, v0
	sshr.4s	v16, v2, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v0
	fmul.4s	v3, v3, v17
	sub.4s	v5, v7, v5
	sub.4s	v2, v2, v16
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v0
	fmul.4s	v2, v3, v2
	shl.4s	v3, v5, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	str	q22, [sp, #5472]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v22
	bic.16b	v3, v3, v4
	str	q28, [sp, #5792]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v28
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v28, v6
	bit.16b	v2, v15, v4
	str	q2, [sp, #5808]                 ; 16-byte Spill
	fcmgt.4s	v2, v22, v6
	bsl.16b	v2, v15, v3
	str	q2, [sp, #5488]                 ; 16-byte Spill
	ldr	q2, [sp, #5888]                 ; 16-byte Reload
	fsub.4s	v2, v2, v19
	and.16b	v22, v1, v2
	fcmge.4s	v2, v22, v24
	fcmge.4s	v3, v6, v22
	and.16b	v2, v2, v3
	ldr	q3, [sp, #5904]                 ; 16-byte Reload
	fsub.4s	v3, v3, v18
	and.16b	v28, v29, v3
	fcmge.4s	v3, v28, v24
	fcmge.4s	v4, v6, v28
	and.16b	v3, v3, v4
	and.16b	v3, v3, v28
	fmul.4s	v4, v3, v9
	mov.16b	v5, v30
	bsl.16b	v5, v14, v4
	fadd.4s	v4, v4, v5
	fsub.4s	v4, v4, v5
	and.16b	v5, v2, v22
	fmul.4s	v2, v5, v9
	mov.16b	v7, v30
	bsl.16b	v7, v14, v2
	fadd.4s	v2, v2, v7
	fsub.4s	v7, v2, v7
	fcvtzs.4s	v2, v4
	scvtf.4s	v4, v2
	fmul.4s	v16, v4, v10
	fsub.4s	v3, v3, v16
	fcvtzs.4s	v7, v7
	scvtf.4s	v16, v7
	fmul.4s	v17, v16, v10
	fsub.4s	v5, v5, v17
	fmul.4s	v16, v16, v31
	fsub.4s	v5, v5, v16
	fmul.4s	v4, v4, v31
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v3, v21
	fadd.4s	v4, v4, v8
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v11
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v20
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v25
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v26
	fmul.4s	v16, v3, v3
	fmul.4s	v4, v16, v4
	fmul.4s	v16, v5, v21
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v11
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v20
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v3, v3, v4
	fadd.4s	v4, v5, v0
	sshr.4s	v5, v7, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v0
	fmul.4s	v4, v4, v16
	fadd.4s	v3, v3, v0
	sshr.4s	v16, v2, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v0
	fmul.4s	v3, v3, v17
	sub.4s	v5, v7, v5
	sub.4s	v2, v2, v16
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v0
	fmul.4s	v2, v3, v2
	shl.4s	v3, v5, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	str	q22, [sp, #5440]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v22
	bic.16b	v3, v3, v4
	str	q28, [sp, #5888]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v28
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v28, v6
	bit.16b	v2, v15, v4
	str	q2, [sp, #5904]                 ; 16-byte Spill
	fcmgt.4s	v2, v22, v6
	bsl.16b	v2, v15, v3
	str	q2, [sp, #5456]                 ; 16-byte Spill
	ldr	q2, [sp, #5952]                 ; 16-byte Reload
	fsub.4s	v2, v2, v18
	and.16b	v22, v29, v2
	fcmge.4s	v2, v22, v24
	fcmge.4s	v3, v6, v22
	and.16b	v2, v2, v3
	ldr	q3, [sp, #5984]                 ; 16-byte Reload
	fsub.4s	v3, v3, v19
	and.16b	v28, v1, v3
	fcmge.4s	v3, v28, v24
	fcmge.4s	v4, v6, v28
	and.16b	v3, v3, v4
	and.16b	v3, v3, v28
	fmul.4s	v4, v3, v9
	mov.16b	v5, v30
	bsl.16b	v5, v14, v4
	fadd.4s	v4, v4, v5
	fsub.4s	v4, v4, v5
	and.16b	v5, v2, v22
	fmul.4s	v2, v5, v9
	mov.16b	v7, v30
	bsl.16b	v7, v14, v2
	fadd.4s	v2, v2, v7
	fsub.4s	v7, v2, v7
	fcvtzs.4s	v2, v4
	scvtf.4s	v4, v2
	fmul.4s	v16, v4, v10
	fsub.4s	v3, v3, v16
	fcvtzs.4s	v7, v7
	scvtf.4s	v16, v7
	fmul.4s	v17, v16, v10
	fsub.4s	v5, v5, v17
	fmul.4s	v16, v16, v31
	fsub.4s	v5, v5, v16
	fmul.4s	v4, v4, v31
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v3, v21
	fadd.4s	v4, v4, v8
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v11
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v20
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v25
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v26
	fmul.4s	v16, v3, v3
	fmul.4s	v4, v16, v4
	fmul.4s	v16, v5, v21
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v11
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v20
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v3, v3, v4
	fadd.4s	v4, v5, v0
	sshr.4s	v5, v7, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v0
	fmul.4s	v4, v4, v16
	fadd.4s	v3, v3, v0
	sshr.4s	v16, v2, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v0
	fmul.4s	v3, v3, v17
	sub.4s	v5, v7, v5
	sub.4s	v2, v2, v16
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v0
	fmul.4s	v2, v3, v2
	shl.4s	v3, v5, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	str	q22, [sp, #5408]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v22
	bic.16b	v3, v3, v4
	str	q28, [sp, #5952]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v28
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v28, v6
	bit.16b	v2, v15, v4
	str	q2, [sp, #5984]                 ; 16-byte Spill
	fcmgt.4s	v2, v22, v6
	bsl.16b	v2, v15, v3
	str	q2, [sp, #5424]                 ; 16-byte Spill
	ldr	q2, [sp, #6048]                 ; 16-byte Reload
	fsub.4s	v2, v2, v19
	and.16b	v12, v1, v2
	fcmge.4s	v2, v12, v24
	fcmge.4s	v3, v6, v12
	and.16b	v2, v2, v3
	ldr	q3, [sp, #6064]                 ; 16-byte Reload
	fsub.4s	v3, v3, v18
	and.16b	v22, v29, v3
	fcmge.4s	v3, v22, v24
	fcmge.4s	v4, v6, v22
	and.16b	v3, v3, v4
	and.16b	v3, v3, v22
	fmul.4s	v4, v3, v9
	mov.16b	v5, v30
	bsl.16b	v5, v14, v4
	fadd.4s	v4, v4, v5
	fsub.4s	v4, v4, v5
	and.16b	v5, v2, v12
	fmul.4s	v2, v5, v9
	mov.16b	v7, v30
	bsl.16b	v7, v14, v2
	fadd.4s	v2, v2, v7
	fsub.4s	v7, v2, v7
	fcvtzs.4s	v2, v4
	scvtf.4s	v4, v2
	fmul.4s	v16, v4, v10
	fsub.4s	v3, v3, v16
	fcvtzs.4s	v7, v7
	scvtf.4s	v16, v7
	fmul.4s	v17, v16, v10
	fsub.4s	v5, v5, v17
	fmul.4s	v16, v16, v31
	fsub.4s	v5, v5, v16
	fmul.4s	v4, v4, v31
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v3, v21
	fadd.4s	v4, v4, v8
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v11
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v20
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v25
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v26
	fmul.4s	v16, v3, v3
	fmul.4s	v4, v16, v4
	fmul.4s	v16, v5, v21
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v11
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v20
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v3, v3, v4
	fadd.4s	v4, v5, v0
	sshr.4s	v5, v7, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v0
	fmul.4s	v4, v4, v16
	fadd.4s	v3, v3, v0
	sshr.4s	v16, v2, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v0
	fmul.4s	v3, v3, v17
	sub.4s	v5, v7, v5
	sub.4s	v2, v2, v16
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v0
	fmul.4s	v2, v3, v2
	shl.4s	v3, v5, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	str	q12, [sp, #5360]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v12
	bic.16b	v3, v3, v4
	str	q22, [sp, #6048]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v22
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v22, v6
	bit.16b	v2, v15, v4
	str	q2, [sp, #6064]                 ; 16-byte Spill
	fcmgt.4s	v2, v12, v6
	bsl.16b	v2, v15, v3
	str	q2, [sp, #5376]                 ; 16-byte Spill
	ldr	q2, [sp, #6144]                 ; 16-byte Reload
	fsub.4s	v2, v2, v19
	str	q19, [sp, #6208]                ; 16-byte Spill
	and.16b	v12, v1, v2
	fcmge.4s	v2, v12, v24
	fcmge.4s	v3, v6, v12
	and.16b	v2, v2, v3
	ldr	q3, [sp, #6160]                 ; 16-byte Reload
	fsub.4s	v3, v3, v18
	str	q18, [sp, #6224]                ; 16-byte Spill
	and.16b	v22, v29, v3
	fcmge.4s	v3, v22, v24
	fcmge.4s	v4, v6, v22
	and.16b	v3, v3, v4
	and.16b	v3, v3, v22
	fmul.4s	v4, v3, v9
	mov.16b	v5, v30
	bsl.16b	v5, v14, v4
	fadd.4s	v4, v4, v5
	fsub.4s	v4, v4, v5
	and.16b	v5, v2, v12
	fmul.4s	v2, v5, v9
	mov.16b	v7, v30
	bsl.16b	v7, v14, v2
	fadd.4s	v2, v2, v7
	fsub.4s	v7, v2, v7
	fcvtzs.4s	v2, v4
	scvtf.4s	v4, v2
	fmul.4s	v16, v4, v10
	fsub.4s	v3, v3, v16
	fcvtzs.4s	v7, v7
	scvtf.4s	v16, v7
	fmul.4s	v17, v16, v10
	fsub.4s	v5, v5, v17
	fmul.4s	v16, v16, v31
	fsub.4s	v5, v5, v16
	fmul.4s	v4, v4, v31
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v3, v21
	fadd.4s	v4, v4, v8
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v11
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v20
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v25
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v26
	fmul.4s	v16, v3, v3
	fmul.4s	v4, v16, v4
	fmul.4s	v16, v5, v21
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v11
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v20
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v25
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v3, v3, v4
	fadd.4s	v4, v5, v0
	sshr.4s	v5, v7, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v0
	fmul.4s	v4, v4, v16
	fadd.4s	v3, v3, v0
	sshr.4s	v16, v2, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v0
	fmul.4s	v3, v3, v17
	sub.4s	v5, v7, v5
	sub.4s	v2, v2, v16
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v0
	fmul.4s	v2, v3, v2
	shl.4s	v3, v5, #23
	add.4s	v3, v3, v0
	fmul.4s	v3, v4, v3
	fcmgt.4s	v4, v24, v12
	bic.16b	v3, v3, v4
	str	q22, [sp, #6144]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v22
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v22, v6
	bit.16b	v2, v15, v4
	str	q2, [sp, #6160]                 ; 16-byte Spill
	fcmgt.4s	v2, v12, v6
	bsl.16b	v2, v15, v3
	str	q2, [sp, #5344]                 ; 16-byte Spill
	ldr	q2, [sp, #8864]                 ; 16-byte Reload
	fsub.4s	v2, v2, v18
	and.16b	v18, v29, v2
	fcmge.4s	v2, v18, v24
	fcmge.4s	v3, v6, v18
	and.16b	v2, v2, v3
	ldr	q3, [sp, #8880]                 ; 16-byte Reload
	fsub.4s	v3, v3, v19
	and.16b	v19, v1, v3
	fcmge.4s	v3, v19, v24
	fcmge.4s	v4, v6, v19
	and.16b	v3, v3, v4
	and.16b	v3, v3, v19
	fmul.4s	v4, v3, v9
	mov.16b	v5, v30
	bsl.16b	v5, v14, v4
	fadd.4s	v4, v4, v5
	fsub.4s	v4, v4, v5
	and.16b	v2, v2, v18
	fmul.4s	v5, v2, v9
	mov.16b	v7, v30
	bsl.16b	v7, v14, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	fcvtzs.4s	v4, v4
	scvtf.4s	v7, v4
	fmul.4s	v16, v7, v10
	fsub.4s	v3, v3, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v17, v16, v10
	fsub.4s	v2, v2, v17
	fmul.4s	v7, v7, v31
	fmul.4s	v16, v16, v31
	fsub.4s	v2, v2, v16
	fsub.4s	v3, v3, v7
	fmul.4s	v7, v3, v21
	fmul.4s	v16, v2, v21
	fadd.4s	v16, v16, v8
	fadd.4s	v7, v7, v8
	fmul.4s	v7, v3, v7
	fmul.4s	v16, v2, v16
	fadd.4s	v16, v16, v11
	fadd.4s	v7, v7, v11
	fmul.4s	v7, v3, v7
	fmul.4s	v16, v2, v16
	fadd.4s	v16, v16, v20
	fadd.4s	v7, v7, v20
	fmul.4s	v7, v3, v7
	fmul.4s	v16, v2, v16
	fadd.4s	v16, v16, v25
	fadd.4s	v7, v7, v25
	fmul.4s	v7, v3, v7
	fadd.4s	v7, v7, v26
	fmul.4s	v17, v3, v3
	fmul.4s	v7, v17, v7
	fmul.4s	v16, v2, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v17, v2, v2
	fmul.4s	v16, v17, v16
	fadd.4s	v2, v2, v16
	fadd.4s	v3, v3, v7
	fadd.4s	v2, v2, v0
	sshr.4s	v7, v5, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v0
	fmul.4s	v2, v2, v16
	fadd.4s	v3, v3, v0
	sshr.4s	v16, v4, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v0
	fmul.4s	v3, v3, v17
	sub.4s	v5, v5, v7
	sub.4s	v4, v4, v16
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v0
	fmul.4s	v3, v3, v4
	shl.4s	v4, v5, #23
	add.4s	v4, v4, v0
	fmul.4s	v2, v2, v4
	str	q18, [sp, #5232]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v18
	bic.16b	v2, v2, v4
	str	q19, [sp, #5248]                ; 16-byte Spill
	fcmgt.4s	v4, v24, v19
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v19, v6
	mov.16b	v0, v4
	bsl.16b	v0, v15, v3
	str	q0, [sp, #5328]                 ; 16-byte Spill
	fcmgt.4s	v3, v18, v6
	mov.16b	v0, v3
	bsl.16b	v0, v15, v2
	str	q0, [sp, #5312]                 ; 16-byte Spill
	ldr	q0, [sp, #6624]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q11, [sp, #4160]                ; 16-byte Reload
	ldr	q0, [sp, #6640]                 ; 16-byte Reload
	mov.16b	v3, v2
	bsl.16b	v3, v0, v11
	str	q3, [sp, #5216]                 ; 16-byte Spill
	ldr	q0, [sp, #6672]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #6656]                 ; 16-byte Reload
	mov.16b	v17, v2
	bsl.16b	v17, v0, v11
	str	q17, [sp, #5184]                ; 16-byte Spill
	ldr	q0, [sp, #6176]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #6192]                 ; 16-byte Reload
	mov.16b	v5, v2
	bsl.16b	v5, v0, v11
	str	q5, [sp, #5200]                 ; 16-byte Spill
	ldr	q0, [sp, #6592]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #6608]                 ; 16-byte Reload
	mov.16b	v8, v2
	bsl.16b	v8, v0, v11
	ldr	q0, [sp, #6080]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #6096]                 ; 16-byte Reload
	mov.16b	v6, v2
	bsl.16b	v6, v0, v11
	str	q6, [sp, #6096]                 ; 16-byte Spill
	ldr	q0, [sp, #6112]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #6128]                 ; 16-byte Reload
	mov.16b	v20, v2
	bsl.16b	v20, v0, v11
	ldr	q0, [sp, #5840]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #6016]                 ; 16-byte Reload
	mov.16b	v16, v2
	bsl.16b	v16, v0, v11
	str	q16, [sp, #6112]                ; 16-byte Spill
	ldr	q0, [sp, #6000]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #6032]                 ; 16-byte Reload
	mov.16b	v31, v2
	bsl.16b	v31, v0, v11
	ldr	q0, [sp, #5728]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5968]                 ; 16-byte Reload
	mov.16b	v19, v2
	bsl.16b	v19, v0, v11
	str	q19, [sp, #6032]                ; 16-byte Spill
	ldr	q0, [sp, #5920]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5936]                 ; 16-byte Reload
	mov.16b	v28, v2
	bsl.16b	v28, v0, v11
	ldr	q0, [sp, #5616]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5856]                 ; 16-byte Reload
	mov.16b	v22, v2
	bsl.16b	v22, v0, v11
	ldr	q0, [sp, #5824]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5872]                 ; 16-byte Reload
	mov.16b	v25, v2
	bsl.16b	v25, v0, v11
	ldr	q0, [sp, #5552]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5760]                 ; 16-byte Reload
	mov.16b	v9, v2
	bsl.16b	v9, v0, v11
	ldr	q0, [sp, #5712]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5776]                 ; 16-byte Reload
	mov.16b	v23, v2
	bsl.16b	v23, v0, v11
	ldr	q0, [sp, #5392]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5648]                 ; 16-byte Reload
	mov.16b	v29, v2
	bsl.16b	v29, v0, v11
	str	q29, [sp, #5920]                ; 16-byte Spill
	ldr	q0, [sp, #5600]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5664]                 ; 16-byte Reload
	mov.16b	v27, v2
	bsl.16b	v27, v0, v11
	ldr	q0, [sp, #5296]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5568]                 ; 16-byte Reload
	mov.16b	v18, v2
	bsl.16b	v18, v0, v11
	ldr	q0, [sp, #5520]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5584]                 ; 16-byte Reload
	mov.16b	v24, v2
	bsl.16b	v24, v0, v11
	ldr	q0, [sp, #5280]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5536]                 ; 16-byte Reload
	bif.16b	v0, v11, v2
	str	q0, [sp, #6592]                 ; 16-byte Spill
	ldr	q0, [sp, #5632]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5680]                 ; 16-byte Reload
	mov.16b	v10, v2
	bsl.16b	v10, v0, v11
	ldr	q0, [sp, #5264]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5504]                 ; 16-byte Reload
	bif.16b	v0, v11, v2
	str	q0, [sp, #6608]                 ; 16-byte Spill
	ldr	q0, [sp, #5696]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5744]                 ; 16-byte Reload
	mov.16b	v14, v2
	bsl.16b	v14, v0, v11
	ldr	q0, [sp, #5472]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5488]                 ; 16-byte Reload
	bif.16b	v0, v11, v2
	str	q0, [sp, #6624]                 ; 16-byte Spill
	ldr	q0, [sp, #5792]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5808]                 ; 16-byte Reload
	bif.16b	v0, v11, v2
	str	q0, [sp, #6000]                 ; 16-byte Spill
	ldr	q0, [sp, #5440]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5456]                 ; 16-byte Reload
	bif.16b	v0, v11, v2
	str	q0, [sp, #6640]                 ; 16-byte Spill
	ldr	q0, [sp, #5888]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5904]                 ; 16-byte Reload
	bif.16b	v0, v11, v2
	str	q0, [sp, #6016]                 ; 16-byte Spill
	ldr	q0, [sp, #5408]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5424]                 ; 16-byte Reload
	bif.16b	v0, v11, v2
	str	q0, [sp, #6080]                 ; 16-byte Spill
	ldr	q0, [sp, #5952]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5984]                 ; 16-byte Reload
	bif.16b	v0, v11, v2
	str	q0, [sp, #6656]                 ; 16-byte Spill
	ldr	q0, [sp, #5360]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #5376]                 ; 16-byte Reload
	bif.16b	v0, v11, v2
	str	q0, [sp, #6672]                 ; 16-byte Spill
	ldr	q0, [sp, #6048]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #6064]                 ; 16-byte Reload
	mov.16b	v15, v2
	bsl.16b	v15, v0, v11
	fcmeq.4s	v2, v12, v12
	ldr	q0, [sp, #5344]                 ; 16-byte Reload
	mov.16b	v13, v2
	bsl.16b	v13, v0, v11
	str	q13, [sp, #6128]                ; 16-byte Spill
	ldr	q0, [sp, #6144]                 ; 16-byte Reload
	fcmeq.4s	v2, v0, v0
	ldr	q0, [sp, #6160]                 ; 16-byte Reload
	mov.16b	v26, v2
	bsl.16b	v26, v0, v11
	str	q26, [sp, #6176]                ; 16-byte Spill
	ldp	q12, q2, [x21]
	mov.16b	v0, v1
	bit.16b	v2, v17, v1
	ldr	q1, [sp, #11312]                ; 16-byte Reload
	bit.16b	v12, v3, v1
	stp	q12, q2, [x21]
	ldp	q12, q2, [x22]
	bit.16b	v2, v8, v0
	bit.16b	v12, v5, v1
	stp	q12, q2, [x22]
	ldp	q12, q2, [x23]
	bit.16b	v2, v20, v0
	bit.16b	v12, v6, v1
	stp	q12, q2, [x23]
	ldp	q12, q2, [x24]
	bit.16b	v2, v31, v0
	bit.16b	v12, v16, v1
	stp	q12, q2, [x24]
	ldp	q12, q2, [x25]
	bit.16b	v2, v28, v0
	str	q28, [sp, #5840]                ; 16-byte Spill
	bit.16b	v12, v19, v1
	stp	q12, q2, [x25]
	ldp	q12, q2, [x26]
	bit.16b	v2, v25, v0
	str	q25, [sp, #5872]                ; 16-byte Spill
	bit.16b	v12, v22, v1
	stp	q12, q2, [x26]
	ldp	q12, q2, [x27]
	mov.16b	v5, v23
	bit.16b	v2, v23, v0
	mov.16b	v19, v9
	bit.16b	v12, v9, v1
	stp	q12, q2, [x27]
	ldp	q12, q2, [x28]
	mov.16b	v16, v27
	str	q27, [sp, #5936]                ; 16-byte Spill
	bit.16b	v2, v27, v0
	bit.16b	v12, v29, v1
	stp	q12, q2, [x28]
	ldp	q12, q2, [x30]
	str	q24, [sp, #5968]                ; 16-byte Spill
	bit.16b	v2, v24, v0
	bit.16b	v12, v18, v1
	mov.16b	v29, v18
	stp	q12, q2, [x30]
	ldp	q2, q12, [x10]
	mov.16b	v17, v10
	bit.16b	v2, v10, v1
	ldr	q4, [sp, #6592]                 ; 16-byte Reload
	bit.16b	v12, v4, v0
	stp	q2, q12, [x10]
	ldp	q2, q12, [x13]
	mov.16b	v23, v14
	bit.16b	v2, v14, v1
	ldr	q14, [sp, #6608]                ; 16-byte Reload
	bit.16b	v12, v14, v0
	stp	q2, q12, [x13]
	ldp	q2, q12, [x14]
	ldr	q21, [sp, #6000]                ; 16-byte Reload
	bit.16b	v2, v21, v1
	ldr	q7, [sp, #6624]                 ; 16-byte Reload
	bit.16b	v12, v7, v0
	stp	q2, q12, [x14]
	ldp	q2, q12, [x15]
	ldr	q9, [sp, #6016]                 ; 16-byte Reload
	bit.16b	v2, v9, v1
	ldr	q18, [sp, #6640]                ; 16-byte Reload
	bit.16b	v12, v18, v0
	stp	q2, q12, [x15]
	ldp	q12, q2, [x16]
	ldr	q30, [sp, #6656]                ; 16-byte Reload
	bit.16b	v2, v30, v0
	ldr	q27, [sp, #6080]                ; 16-byte Reload
	bit.16b	v12, v27, v1
	stp	q12, q2, [x16]
	ldp	q2, q12, [x17]
	mov.16b	v3, v15
	bit.16b	v2, v15, v1
	ldr	q15, [sp, #6672]                ; 16-byte Reload
	bit.16b	v12, v15, v0
	mov.16b	v10, v0
	stp	q2, q12, [x17]
	ldp	q6, q2, [x0]
	mov.16b	v12, v1
	bsl.16b	v12, v26, v6
	bsl.16b	v0, v13, v2
	movi.2d	v6, #0000000000000000
	ldr	q26, [sp, #5184]                ; 16-byte Reload
	fadd.4s	v2, v26, v6
	fadd.4s	v2, v2, v8
	fadd.4s	v2, v2, v20
	mov.16b	v13, v20
	fadd.4s	v2, v2, v31
	fadd.4s	v2, v2, v28
	fadd.4s	v2, v2, v25
	fadd.4s	v2, v2, v5
	mov.16b	v25, v5
	fadd.4s	v2, v2, v16
	fadd.4s	v2, v2, v24
	fadd.4s	v2, v2, v4
	fadd.4s	v2, v2, v14
	fadd.4s	v2, v2, v7
	fadd.4s	v2, v2, v18
	fadd.4s	v2, v2, v30
	fadd.4s	v2, v2, v15
	ldr	q4, [sp, #6416]                 ; 16-byte Reload
	bif.16b	v2, v4, v10
	fadd.4s	v20, v2, v0
	stp	q12, q0, [x0]
	ldr	q5, [sp, #5216]                 ; 16-byte Reload
	fadd.4s	v0, v5, v6
	ldr	q6, [sp, #5200]                 ; 16-byte Reload
	fadd.4s	v0, v0, v6
	ldr	q7, [sp, #6096]                 ; 16-byte Reload
	fadd.4s	v0, v0, v7
	ldr	q16, [sp, #6112]                ; 16-byte Reload
	fadd.4s	v0, v0, v16
	ldr	q15, [sp, #6032]                ; 16-byte Reload
	fadd.4s	v0, v0, v15
	mov.16b	v18, v22
	fadd.4s	v0, v0, v22
	fadd.4s	v0, v0, v19
	ldr	q30, [sp, #5920]                ; 16-byte Reload
	fadd.4s	v0, v0, v30
	fadd.4s	v0, v0, v29
	fadd.4s	v0, v0, v17
	mov.16b	v24, v17
	fadd.4s	v0, v0, v23
	fadd.4s	v0, v0, v21
	fadd.4s	v0, v0, v9
	fadd.4s	v0, v0, v27
	fadd.4s	v0, v0, v3
	mov.16b	v17, v3
	mov.16b	v14, v10
	ldr	q2, [sp, #6432]                 ; 16-byte Reload
	bif.16b	v0, v2, v1
	fadd.4s	v0, v0, v12
	sshll.2d	v12, v14, #0
	ldr	q3, [sp, #6464]                 ; 16-byte Reload
	ldr	q10, [sp, #6352]                ; 16-byte Reload
	bit.16b	v10, v3, v12
	str	q10, [sp, #6352]                ; 16-byte Spill
	sshll.2d	v12, v1, #0
	ldr	q10, [sp, #6240]                ; 16-byte Reload
	bic.16b	v3, v10, v12
	str	q3, [sp, #6192]                 ; 16-byte Spill
	ldr	q3, [sp, #6448]                 ; 16-byte Reload
	bif.16b	v3, v10, v12
	str	q3, [sp, #6240]                 ; 16-byte Spill
	ldr	q3, [sp, #5232]                 ; 16-byte Reload
	fcmeq.4s	v22, v3, v3
	ldr	q3, [sp, #5312]                 ; 16-byte Reload
	bsl.16b	v22, v3, v11
	ldr	q3, [sp, #5248]                 ; 16-byte Reload
	fcmeq.4s	v28, v3, v3
	ldr	q3, [sp, #5328]                 ; 16-byte Reload
	bsl.16b	v28, v3, v11
	ldr	q12, [sp, #6720]                ; 16-byte Reload
	bit.16b	v12, v26, v14
	ldr	q3, [sp, #11008]                ; 16-byte Reload
	bit.16b	v3, v5, v1
	str	q3, [sp, #11008]                ; 16-byte Spill
	ldr	q3, [sp, #11168]                ; 16-byte Reload
	bit.16b	v3, v6, v1
	str	q3, [sp, #11168]                ; 16-byte Spill
	ldr	q3, [sp, #11232]                ; 16-byte Reload
	bit.16b	v3, v8, v14
	str	q3, [sp, #11232]                ; 16-byte Spill
	ldr	q3, [sp, #11248]                ; 16-byte Reload
	bit.16b	v3, v13, v14
	str	q3, [sp, #11248]                ; 16-byte Spill
	ldr	q3, [sp, #11184]                ; 16-byte Reload
	bit.16b	v3, v7, v1
	str	q3, [sp, #11184]                ; 16-byte Spill
	ldr	q11, [sp, #11056]               ; 16-byte Reload
	bit.16b	v11, v16, v1
	ldr	q3, [sp, #11264]                ; 16-byte Reload
	bit.16b	v3, v31, v14
	str	q3, [sp, #11264]                ; 16-byte Spill
	ldr	q3, [sp, #11200]                ; 16-byte Reload
	ldr	q5, [sp, #5840]                 ; 16-byte Reload
	bit.16b	v3, v5, v14
	str	q3, [sp, #11200]                ; 16-byte Spill
	bit.16b	v2, v0, v1
	str	q2, [sp, #6432]                 ; 16-byte Spill
	bit.16b	v4, v20, v14
	str	q4, [sp, #6416]                 ; 16-byte Spill
	ldr	q10, [sp, #10944]               ; 16-byte Reload
	mov.16b	v13, v14
	bsl.16b	v13, v28, v10
	ldr	q31, [sp, #10928]               ; 16-byte Reload
	bit.16b	v31, v22, v1
	ldr	q2, [sp, #11280]                ; 16-byte Reload
	bit.16b	v2, v15, v1
	str	q2, [sp, #11280]                ; 16-byte Spill
	ldr	q2, [sp, #11216]                ; 16-byte Reload
	bit.16b	v2, v18, v1
	str	q2, [sp, #11216]                ; 16-byte Spill
	ldr	q2, [sp, #11120]                ; 16-byte Reload
	ldr	q3, [sp, #5872]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #11120]                ; 16-byte Spill
	ldr	q2, [sp, #11136]                ; 16-byte Reload
	bit.16b	v2, v25, v14
	str	q2, [sp, #11136]                ; 16-byte Spill
	ldr	q2, [sp, #11088]                ; 16-byte Reload
	bit.16b	v2, v19, v1
	str	q2, [sp, #11088]                ; 16-byte Spill
	ldr	q2, [sp, #11152]                ; 16-byte Reload
	bit.16b	v2, v30, v1
	str	q2, [sp, #11152]                ; 16-byte Spill
	ldr	q2, [sp, #11024]                ; 16-byte Reload
	ldr	q3, [sp, #5936]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #11024]                ; 16-byte Spill
	ldr	q2, [sp, #11040]                ; 16-byte Reload
	ldr	q3, [sp, #5968]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #11040]                ; 16-byte Spill
	ldr	q2, [sp, #8752]                 ; 16-byte Reload
	bit.16b	v2, v29, v1
	str	q2, [sp, #8752]                 ; 16-byte Spill
	ldr	q7, [sp, #11104]                ; 16-byte Reload
	bit.16b	v7, v24, v1
	ldr	q25, [sp, #9376]                ; 16-byte Reload
	ldr	q3, [sp, #6592]                 ; 16-byte Reload
	bit.16b	v25, v3, v14
	ldr	q2, [sp, #11072]                ; 16-byte Reload
	ldr	q3, [sp, #6608]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #11072]                ; 16-byte Spill
	ldr	q2, [sp, #10976]                ; 16-byte Reload
	bit.16b	v2, v23, v1
	str	q2, [sp, #10976]                ; 16-byte Spill
	ldr	q2, [sp, #8784]                 ; 16-byte Reload
	bit.16b	v2, v21, v1
	str	q2, [sp, #8784]                 ; 16-byte Spill
	ldr	q2, [sp, #8768]                 ; 16-byte Reload
	ldr	q3, [sp, #6624]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #8768]                 ; 16-byte Spill
	ldr	q2, [sp, #10960]                ; 16-byte Reload
	ldr	q3, [sp, #6640]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #10960]                ; 16-byte Spill
	ldr	q2, [sp, #8800]                 ; 16-byte Reload
	bit.16b	v2, v9, v1
	str	q2, [sp, #8800]                 ; 16-byte Spill
	ldr	q2, [sp, #9392]                 ; 16-byte Reload
	bit.16b	v2, v27, v1
	str	q2, [sp, #9392]                 ; 16-byte Spill
	ldr	q2, [sp, #8816]                 ; 16-byte Reload
	ldr	q3, [sp, #6656]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #8816]                 ; 16-byte Spill
	ldr	q2, [sp, #8832]                 ; 16-byte Reload
	ldr	q3, [sp, #6672]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #8832]                 ; 16-byte Spill
	ldr	q2, [sp, #6736]                 ; 16-byte Reload
	bit.16b	v2, v17, v1
	str	q2, [sp, #6736]                 ; 16-byte Spill
	ldr	q2, [sp, #10992]                ; 16-byte Reload
	ldr	q3, [sp, #6176]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #10992]                ; 16-byte Spill
	ldr	q2, [sp, #8848]                 ; 16-byte Reload
	ldr	q3, [sp, #6128]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #8848]                 ; 16-byte Spill
	ldr	q2, [sp, #8672]                 ; 16-byte Reload
	fmul.4s	v3, v2, v22
	ldr	q2, [sp, #8688]                 ; 16-byte Reload
	fmul.4s	v4, v2, v28
	fadd.4s	v2, v4, v20
	str	q2, [sp, #6672]                 ; 16-byte Spill
	fadd.4s	v0, v3, v0
	str	q0, [sp, #6656]                 ; 16-byte Spill
	ldr	q0, [sp, #6752]                 ; 16-byte Reload
	mov.16b	v2, v31
	str	q31, [sp, #10928]               ; 16-byte Spill
	fmul.4s	v9, v0, v31
	ldr	q0, [sp, #6768]                 ; 16-byte Reload
	fmul.4s	v17, v0, v13
	ldr	q0, [sp, #6784]                 ; 16-byte Reload
	fmul.4s	v31, v0, v31
	ldr	q0, [sp, #6800]                 ; 16-byte Reload
	fmul.4s	v8, v0, v13
	ldr	q0, [sp, #6816]                 ; 16-byte Reload
	fmul.4s	v29, v0, v2
	ldr	q0, [sp, #6832]                 ; 16-byte Reload
	fmul.4s	v30, v0, v13
	ldr	q0, [sp, #6848]                 ; 16-byte Reload
	fmul.4s	v3, v0, v2
	ldr	q0, [sp, #6864]                 ; 16-byte Reload
	fmul.4s	v16, v0, v13
	ldr	q0, [sp, #6880]                 ; 16-byte Reload
	fmul.4s	v0, v0, v2
	str	q0, [sp, #6032]                 ; 16-byte Spill
	ldr	q0, [sp, #6896]                 ; 16-byte Reload
	fmul.4s	v22, v0, v13
	ldr	q0, [sp, #6912]                 ; 16-byte Reload
	fmul.4s	v0, v0, v2
	str	q0, [sp, #6064]                 ; 16-byte Spill
	ldr	q0, [sp, #6928]                 ; 16-byte Reload
	fmul.4s	v0, v0, v13
	str	q0, [sp, #6048]                 ; 16-byte Spill
	ldr	q0, [sp, #6944]                 ; 16-byte Reload
	fmul.4s	v0, v0, v2
	str	q0, [sp, #6096]                 ; 16-byte Spill
	ldr	q0, [sp, #6960]                 ; 16-byte Reload
	fmul.4s	v0, v0, v13
	str	q0, [sp, #6080]                 ; 16-byte Spill
	ldr	q0, [sp, #6976]                 ; 16-byte Reload
	fmul.4s	v0, v0, v2
	str	q0, [sp, #6128]                 ; 16-byte Spill
	ldr	q0, [sp, #6992]                 ; 16-byte Reload
	fmul.4s	v0, v0, v13
	str	q0, [sp, #6112]                 ; 16-byte Spill
	ldr	q0, [sp, #7008]                 ; 16-byte Reload
	fmul.4s	v0, v0, v2
	str	q0, [sp, #5904]                 ; 16-byte Spill
	ldr	q0, [sp, #7024]                 ; 16-byte Reload
	fmul.4s	v0, v0, v13
	str	q0, [sp, #5888]                 ; 16-byte Spill
	ldr	q0, [sp, #7040]                 ; 16-byte Reload
	fmul.4s	v0, v0, v2
	str	q0, [sp, #5936]                 ; 16-byte Spill
	ldr	q0, [sp, #7056]                 ; 16-byte Reload
	fmul.4s	v0, v0, v13
	str	q0, [sp, #5920]                 ; 16-byte Spill
	ldr	q0, [sp, #7072]                 ; 16-byte Reload
	fmul.4s	v0, v0, v2
	str	q0, [sp, #5968]                 ; 16-byte Spill
	ldr	q0, [sp, #7088]                 ; 16-byte Reload
	fmul.4s	v0, v0, v13
	str	q0, [sp, #5952]                 ; 16-byte Spill
	ldr	q0, [sp, #7104]                 ; 16-byte Reload
	fmul.4s	v0, v0, v2
	str	q0, [sp, #6000]                 ; 16-byte Spill
	ldr	q0, [sp, #7120]                 ; 16-byte Reload
	fmul.4s	v0, v0, v13
	str	q0, [sp, #5984]                 ; 16-byte Spill
	str	q13, [sp, #10944]               ; 16-byte Spill
	ldr	q0, [sp, #6192]                 ; 16-byte Reload
	fmov	x3, d0
	add	x3, x1, x3
	ldp	q2, q10, [x3]
	and.16b	v10, v14, v10
	fmul.4s	v10, v12, v10
	fadd.4s	v10, v17, v10
	ldr	q0, [sp, #7152]                 ; 16-byte Reload
	fmul.4s	v0, v0, v13
	str	q0, [sp, #5872]                 ; 16-byte Spill
	and.16b	v0, v1, v2
	ldr	q4, [sp, #11008]                ; 16-byte Reload
	fmul.4s	v0, v4, v0
	fadd.4s	v0, v9, v0
	ldr	q9, [x8, #32816]
	and.16b	v9, v14, v9
	fmul.4s	v9, v12, v9
	fadd.4s	v8, v8, v9
	ldr	q9, [x8, #32800]
	and.16b	v9, v1, v9
	fmul.4s	v9, v4, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x8, #32848]
	and.16b	v9, v14, v9
	fmul.4s	v9, v12, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x8, #32832]
	and.16b	v9, v1, v9
	fmul.4s	v9, v4, v9
	fadd.4s	v29, v29, v9
	ldr	q9, [x8, #32880]
	and.16b	v9, v14, v9
	fmul.4s	v9, v12, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x8, #32864]
	and.16b	v9, v1, v9
	fmul.4s	v9, v4, v9
	fadd.4s	v3, v3, v9
	ldr	q9, [x8, #34816]
	and.16b	v9, v1, v9
	ldr	q17, [sp, #11168]               ; 16-byte Reload
	fmul.4s	v9, v17, v9
	fadd.4s	v0, v0, v9
	ldr	q9, [x8, #34832]
	and.16b	v9, v14, v9
	ldr	q2, [sp, #11232]                ; 16-byte Reload
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v10, v9
	ldr	q10, [x8, #34848]
	and.16b	v10, v1, v10
	fmul.4s	v10, v17, v10
	fadd.4s	v31, v31, v10
	ldr	q10, [x8, #34864]
	and.16b	v10, v14, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v8, v8, v10
	ldr	q10, [x8, #34880]
	and.16b	v10, v1, v10
	fmul.4s	v10, v17, v10
	fadd.4s	v29, v29, v10
	ldr	q10, [x8, #34896]
	and.16b	v10, v14, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v30, v30, v10
	ldr	q10, [x8, #34912]
	and.16b	v10, v1, v10
	fmul.4s	v10, v17, v10
	fadd.4s	v3, v3, v10
	ldr	q10, [x8, #34928]
	and.16b	v10, v14, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v16, v16, v10
	ldr	q10, [x8, #36880]
	and.16b	v10, v14, v10
	ldr	q17, [sp, #11248]               ; 16-byte Reload
	fmul.4s	v10, v17, v10
	fadd.4s	v9, v9, v10
	ldr	q10, [x8, #36864]
	and.16b	v10, v1, v10
	ldr	q2, [sp, #11184]                ; 16-byte Reload
	fmul.4s	v10, v2, v10
	fadd.4s	v0, v0, v10
	ldr	q10, [x8, #36912]
	and.16b	v10, v14, v10
	fmul.4s	v10, v17, v10
	fadd.4s	v8, v8, v10
	ldr	q10, [x8, #36896]
	and.16b	v10, v1, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v31, v31, v10
	ldr	q10, [x8, #36944]
	and.16b	v10, v14, v10
	fmul.4s	v10, v17, v10
	fadd.4s	v30, v30, v10
	ldr	q10, [x8, #36928]
	and.16b	v10, v1, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v29, v29, v10
	ldr	q10, [x8, #36976]
	and.16b	v10, v14, v10
	fmul.4s	v10, v17, v10
	fadd.4s	v16, v16, v10
	ldr	q10, [x8, #36960]
	and.16b	v10, v1, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v3, v3, v10
	ldr	q10, [x8, #38912]
	and.16b	v10, v1, v10
	fmul.4s	v10, v11, v10
	fadd.4s	v0, v0, v10
	ldr	q10, [x8, #38928]
	and.16b	v10, v14, v10
	ldr	q15, [sp, #11264]               ; 16-byte Reload
	fmul.4s	v10, v15, v10
	fadd.4s	v9, v9, v10
	ldr	q10, [x8, #38944]
	and.16b	v10, v1, v10
	fmul.4s	v10, v11, v10
	fadd.4s	v31, v31, v10
	ldr	q10, [x8, #38960]
	and.16b	v10, v14, v10
	fmul.4s	v10, v15, v10
	fadd.4s	v8, v8, v10
	ldr	q10, [x8, #38976]
	and.16b	v10, v1, v10
	str	q11, [sp, #11056]               ; 16-byte Spill
	fmul.4s	v10, v11, v10
	fadd.4s	v29, v29, v10
	ldr	q10, [x8, #38992]
	and.16b	v10, v14, v10
	fmul.4s	v10, v15, v10
	fadd.4s	v30, v30, v10
	ldr	q10, [x8, #39008]
	and.16b	v10, v1, v10
	fmul.4s	v10, v11, v10
	fadd.4s	v3, v3, v10
	ldr	q10, [x8, #39024]
	and.16b	v10, v14, v10
	fmul.4s	v10, v15, v10
	fadd.4s	v16, v16, v10
	ldr	q10, [x8, #40976]
	and.16b	v10, v14, v10
	ldr	q15, [sp, #11200]               ; 16-byte Reload
	fmul.4s	v10, v15, v10
	fadd.4s	v9, v9, v10
	ldr	q10, [x8, #40960]
	and.16b	v10, v1, v10
	ldr	q11, [sp, #11280]               ; 16-byte Reload
	fmul.4s	v10, v11, v10
	fadd.4s	v0, v0, v10
	ldr	q10, [x8, #41008]
	and.16b	v10, v14, v10
	fmul.4s	v10, v15, v10
	fadd.4s	v8, v8, v10
	ldr	q10, [x8, #40992]
	and.16b	v10, v1, v10
	fmul.4s	v10, v11, v10
	fadd.4s	v31, v31, v10
	ldr	q10, [x8, #41040]
	and.16b	v10, v14, v10
	fmul.4s	v10, v15, v10
	fadd.4s	v30, v30, v10
	ldr	q10, [x8, #41024]
	and.16b	v10, v1, v10
	fmul.4s	v10, v11, v10
	fadd.4s	v29, v29, v10
	ldr	q10, [x8, #41072]
	and.16b	v10, v14, v10
	fmul.4s	v10, v15, v10
	fadd.4s	v16, v16, v10
	ldr	q10, [x8, #41056]
	and.16b	v10, v1, v10
	fmul.4s	v10, v11, v10
	fadd.4s	v3, v3, v10
	ldr	q10, [x8, #43008]
	and.16b	v10, v1, v10
	ldr	q2, [sp, #11216]                ; 16-byte Reload
	fmul.4s	v10, v2, v10
	fadd.4s	v0, v0, v10
	ldr	q10, [x8, #43024]
	and.16b	v10, v14, v10
	ldr	q15, [sp, #11120]               ; 16-byte Reload
	fmul.4s	v10, v15, v10
	fadd.4s	v9, v9, v10
	ldr	q10, [x8, #43040]
	and.16b	v10, v1, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v31, v31, v10
	ldr	q10, [x8, #43056]
	and.16b	v10, v14, v10
	fmul.4s	v10, v15, v10
	fadd.4s	v8, v8, v10
	ldr	q10, [x8, #43072]
	and.16b	v10, v1, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v29, v29, v10
	ldr	q10, [x8, #43088]
	and.16b	v10, v14, v10
	fmul.4s	v10, v15, v10
	fadd.4s	v30, v30, v10
	ldr	q10, [x8, #43104]
	and.16b	v10, v1, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v3, v3, v10
	ldr	q10, [x8, #43120]
	and.16b	v10, v14, v10
	fmul.4s	v10, v15, v10
	fadd.4s	v16, v16, v10
	ldr	q10, [x8, #45072]
	and.16b	v10, v14, v10
	ldr	q17, [sp, #11136]               ; 16-byte Reload
	fmul.4s	v10, v17, v10
	fadd.4s	v9, v9, v10
	ldr	q10, [x8, #45056]
	and.16b	v10, v1, v10
	ldr	q2, [sp, #11088]                ; 16-byte Reload
	fmul.4s	v10, v2, v10
	fadd.4s	v0, v0, v10
	ldr	q10, [x8, #45104]
	and.16b	v10, v14, v10
	fmul.4s	v10, v17, v10
	fadd.4s	v8, v8, v10
	ldr	q10, [x8, #45088]
	and.16b	v10, v1, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v31, v31, v10
	ldr	q10, [x8, #45136]
	and.16b	v10, v14, v10
	fmul.4s	v10, v17, v10
	fadd.4s	v30, v30, v10
	ldr	q10, [x8, #45120]
	and.16b	v10, v1, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v29, v29, v10
	ldr	q10, [x8, #45168]
	and.16b	v10, v14, v10
	fmul.4s	v10, v17, v10
	fadd.4s	v16, v16, v10
	ldr	q10, [x8, #45152]
	and.16b	v10, v1, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v3, v3, v10
	ldr	q10, [x8, #47104]
	and.16b	v10, v1, v10
	ldr	q2, [sp, #11152]                ; 16-byte Reload
	fmul.4s	v10, v2, v10
	fadd.4s	v0, v0, v10
	ldr	q10, [x8, #47120]
	and.16b	v10, v14, v10
	ldr	q26, [sp, #11024]               ; 16-byte Reload
	fmul.4s	v10, v26, v10
	fadd.4s	v9, v9, v10
	ldr	q10, [x8, #47136]
	and.16b	v10, v1, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v31, v31, v10
	ldr	q10, [x8, #47152]
	and.16b	v10, v14, v10
	fmul.4s	v10, v26, v10
	fadd.4s	v8, v8, v10
	ldr	q10, [x8, #47168]
	and.16b	v10, v1, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v29, v29, v10
	ldr	q10, [x8, #47184]
	and.16b	v10, v14, v10
	fmul.4s	v10, v26, v10
	fadd.4s	v30, v30, v10
	ldr	q10, [x8, #47200]
	and.16b	v10, v1, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v3, v3, v10
	ldr	q10, [x8, #47216]
	and.16b	v10, v14, v10
	fmul.4s	v10, v26, v10
	fadd.4s	v16, v16, v10
	ldr	q10, [x8, #49168]
	and.16b	v10, v14, v10
	ldr	q2, [sp, #11040]                ; 16-byte Reload
	fmul.4s	v10, v2, v10
	fadd.4s	v9, v9, v10
	ldr	q10, [x8, #49152]
	and.16b	v10, v1, v10
	ldr	q17, [sp, #8752]                ; 16-byte Reload
	fmul.4s	v10, v17, v10
	fadd.4s	v0, v0, v10
	ldr	q10, [x8, #49200]
	and.16b	v10, v14, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v8, v8, v10
	ldr	q10, [x8, #49184]
	and.16b	v10, v1, v10
	fmul.4s	v10, v17, v10
	fadd.4s	v31, v31, v10
	ldr	q10, [x8, #49232]
	and.16b	v10, v14, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v30, v30, v10
	ldr	q10, [x8, #49216]
	and.16b	v10, v1, v10
	fmul.4s	v10, v17, v10
	fadd.4s	v29, v29, v10
	ldr	q10, [x8, #49264]
	and.16b	v10, v14, v10
	fmul.4s	v10, v2, v10
	fadd.4s	v16, v16, v10
	ldr	q10, [x8, #49248]
	and.16b	v10, v1, v10
	fmul.4s	v10, v17, v10
	fadd.4s	v3, v3, v10
	ldr	q10, [x8, #51200]
	and.16b	v10, v1, v10
	fmul.4s	v10, v7, v10
	fadd.4s	v0, v0, v10
	ldr	q10, [x8, #51216]
	and.16b	v10, v14, v10
	fmul.4s	v10, v25, v10
	fadd.4s	v9, v9, v10
	ldr	q10, [x8, #51232]
	and.16b	v10, v1, v10
	fmul.4s	v10, v7, v10
	mov.16b	v27, v7
	fadd.4s	v31, v31, v10
	ldr	q10, [x8, #51248]
	and.16b	v10, v14, v10
	fmul.4s	v10, v25, v10
	fadd.4s	v8, v8, v10
	ldr	q10, [x8, #51264]
	and.16b	v10, v1, v10
	fmul.4s	v10, v7, v10
	fadd.4s	v29, v29, v10
	ldr	q10, [x8, #51280]
	and.16b	v10, v14, v10
	fmul.4s	v10, v25, v10
	fadd.4s	v30, v30, v10
	ldr	q10, [x8, #51296]
	and.16b	v10, v1, v10
	fmul.4s	v10, v7, v10
	fadd.4s	v3, v3, v10
	ldr	q10, [x8, #51312]
	and.16b	v10, v14, v10
	fmul.4s	v10, v25, v10
	fadd.4s	v16, v16, v10
	ldr	q10, [x8, #53264]
	and.16b	v10, v14, v10
	ldr	q24, [sp, #11072]               ; 16-byte Reload
	fmul.4s	v10, v24, v10
	fadd.4s	v9, v9, v10
	ldr	q10, [x8, #53248]
	and.16b	v10, v1, v10
	ldr	q19, [sp, #10976]               ; 16-byte Reload
	fmul.4s	v10, v19, v10
	fadd.4s	v0, v0, v10
	ldr	q10, [x8, #53296]
	and.16b	v10, v14, v10
	fmul.4s	v10, v24, v10
	fadd.4s	v8, v8, v10
	ldr	q10, [x8, #53280]
	and.16b	v10, v1, v10
	fmul.4s	v10, v19, v10
	fadd.4s	v31, v31, v10
	ldr	q10, [x8, #53328]
	and.16b	v10, v14, v10
	fmul.4s	v10, v24, v10
	fadd.4s	v30, v30, v10
	ldr	q10, [x8, #53312]
	and.16b	v10, v1, v10
	fmul.4s	v10, v19, v10
	fadd.4s	v29, v29, v10
	ldr	q10, [x8, #53360]
	and.16b	v10, v14, v10
	fmul.4s	v10, v24, v10
	fadd.4s	v16, v16, v10
	ldr	q10, [x8, #53344]
	and.16b	v10, v1, v10
	fmul.4s	v10, v19, v10
	fadd.4s	v3, v3, v10
	ldr	q10, [x8, #55296]
	and.16b	v10, v1, v10
	ldr	q18, [sp, #8784]                ; 16-byte Reload
	fmul.4s	v10, v18, v10
	fadd.4s	v0, v0, v10
	ldr	q10, [x8, #55312]
	and.16b	v10, v14, v10
	ldr	q20, [sp, #8768]                ; 16-byte Reload
	fmul.4s	v10, v20, v10
	fadd.4s	v9, v9, v10
	ldr	q10, [x8, #55328]
	and.16b	v10, v1, v10
	fmul.4s	v10, v18, v10
	fadd.4s	v31, v31, v10
	ldr	q10, [x8, #55344]
	and.16b	v10, v14, v10
	fmul.4s	v10, v20, v10
	fadd.4s	v8, v8, v10
	ldr	q10, [x8, #55360]
	and.16b	v10, v1, v10
	fmul.4s	v10, v18, v10
	fadd.4s	v29, v29, v10
	ldr	q10, [x8, #55376]
	and.16b	v10, v14, v10
	fmul.4s	v10, v20, v10
	fadd.4s	v30, v30, v10
	ldr	q10, [x8, #55392]
	and.16b	v10, v1, v10
	fmul.4s	v10, v18, v10
	fadd.4s	v3, v3, v10
	ldr	q10, [x8, #55408]
	and.16b	v10, v14, v10
	fmul.4s	v10, v20, v10
	fadd.4s	v16, v16, v10
	ldr	q10, [x8, #57360]
	and.16b	v10, v14, v10
	ldr	q24, [sp, #10960]               ; 16-byte Reload
	fmul.4s	v10, v24, v10
	fadd.4s	v9, v9, v10
	ldr	q10, [x8, #57344]
	and.16b	v10, v1, v10
	ldr	q23, [sp, #8800]                ; 16-byte Reload
	fmul.4s	v10, v23, v10
	fadd.4s	v0, v0, v10
	ldr	q10, [x8, #57392]
	and.16b	v10, v14, v10
	fmul.4s	v10, v24, v10
	fadd.4s	v8, v8, v10
	ldr	q10, [x8, #57376]
	and.16b	v10, v1, v10
	fmul.4s	v10, v23, v10
	fadd.4s	v31, v31, v10
	ldr	q10, [x8, #57424]
	and.16b	v10, v14, v10
	fmul.4s	v10, v24, v10
	fadd.4s	v30, v30, v10
	ldr	q10, [x8, #57408]
	and.16b	v10, v1, v10
	fmul.4s	v10, v23, v10
	fadd.4s	v29, v29, v10
	ldr	q10, [x8, #57456]
	and.16b	v10, v14, v10
	fmul.4s	v10, v24, v10
	fadd.4s	v16, v16, v10
	ldr	q10, [x8, #57440]
	and.16b	v10, v1, v10
	fmul.4s	v10, v23, v10
	fadd.4s	v3, v3, v10
	ldr	q10, [x8, #59392]
	and.16b	v10, v1, v10
	ldr	q28, [sp, #9392]                ; 16-byte Reload
	fmul.4s	v10, v28, v10
	fadd.4s	v0, v0, v10
	ldr	q10, [x8, #59408]
	and.16b	v10, v14, v10
	ldr	q21, [sp, #8816]                ; 16-byte Reload
	fmul.4s	v10, v21, v10
	fadd.4s	v9, v9, v10
	ldr	q10, [x8, #59424]
	and.16b	v10, v1, v10
	fmul.4s	v10, v28, v10
	fadd.4s	v31, v31, v10
	ldr	q10, [x8, #59440]
	and.16b	v10, v14, v10
	fmul.4s	v10, v21, v10
	fadd.4s	v8, v8, v10
	ldr	q10, [x8, #59456]
	and.16b	v10, v1, v10
	fmul.4s	v10, v28, v10
	fadd.4s	v29, v29, v10
	ldr	q10, [x8, #59472]
	and.16b	v10, v14, v10
	fmul.4s	v10, v21, v10
	fadd.4s	v30, v30, v10
	ldr	q10, [x8, #59488]
	and.16b	v10, v1, v10
	fmul.4s	v10, v28, v10
	fadd.4s	v3, v3, v10
	ldr	q10, [x8, #59504]
	and.16b	v10, v14, v10
	fmul.4s	v10, v21, v10
	fadd.4s	v16, v16, v10
	ldr	q10, [x8, #61456]
	and.16b	v10, v14, v10
	ldr	q23, [sp, #8832]                ; 16-byte Reload
	fmul.4s	v10, v23, v10
	fadd.4s	v9, v9, v10
	ldr	q10, [x8, #61440]
	and.16b	v10, v1, v10
	ldr	q13, [sp, #6736]                ; 16-byte Reload
	fmul.4s	v10, v13, v10
	fadd.4s	v0, v0, v10
	ldr	q10, [x8, #61488]
	and.16b	v10, v14, v10
	fmul.4s	v10, v23, v10
	fadd.4s	v8, v8, v10
	ldr	q10, [x8, #61472]
	and.16b	v10, v1, v10
	fmul.4s	v10, v13, v10
	fadd.4s	v31, v31, v10
	ldr	q10, [x8, #61520]
	and.16b	v10, v14, v10
	fmul.4s	v10, v23, v10
	fadd.4s	v30, v30, v10
	ldr	q10, [x8, #61504]
	and.16b	v10, v1, v10
	fmul.4s	v10, v13, v10
	fadd.4s	v29, v29, v10
	ldr	q10, [x8, #61552]
	and.16b	v10, v14, v10
	fmul.4s	v10, v23, v10
	fadd.4s	v16, v16, v10
	ldr	q10, [x8, #61536]
	and.16b	v10, v1, v10
	fmul.4s	v10, v13, v10
	fadd.4s	v3, v3, v10
	ldr	q10, [x8, #63488]
	and.16b	v10, v1, v10
	ldr	q2, [sp, #10992]                ; 16-byte Reload
	fmul.4s	v10, v2, v10
	fadd.4s	v0, v0, v10
	str	q0, [sp, #6640]                 ; 16-byte Spill
	ldr	q0, [x8, #63504]
	and.16b	v0, v14, v0
	ldr	q6, [sp, #8848]                 ; 16-byte Reload
	fmul.4s	v0, v6, v0
	fadd.4s	v0, v9, v0
	str	q0, [sp, #6624]                 ; 16-byte Spill
	ldr	q0, [x8, #63520]
	and.16b	v0, v1, v0
	fmul.4s	v0, v2, v0
	fadd.4s	v0, v31, v0
	str	q0, [sp, #6608]                 ; 16-byte Spill
	ldr	q0, [x8, #63536]
	and.16b	v0, v14, v0
	fmul.4s	v0, v6, v0
	fadd.4s	v0, v8, v0
	str	q0, [sp, #6592]                 ; 16-byte Spill
	ldr	q0, [x8, #63552]
	and.16b	v0, v1, v0
	fmul.4s	v0, v2, v0
	mov.16b	v31, v2
	fadd.4s	v0, v29, v0
	str	q0, [sp, #6192]                 ; 16-byte Spill
	ldr	q0, [x8, #63568]
	and.16b	v0, v14, v0
	fmul.4s	v0, v6, v0
	fadd.4s	v0, v30, v0
	str	q0, [sp, #6176]                 ; 16-byte Spill
	ldr	q0, [x8, #63584]
	and.16b	v0, v1, v0
	fmul.4s	v0, v2, v0
	fadd.4s	v0, v3, v0
	str	q0, [sp, #6160]                 ; 16-byte Spill
	ldr	q0, [x8, #63600]
	and.16b	v0, v14, v0
	fmul.4s	v0, v6, v0
	mov.16b	v29, v6
	fadd.4s	v0, v16, v0
	str	q0, [sp, #6144]                 ; 16-byte Spill
	ldr	q0, [x8, #32912]
	and.16b	v0, v14, v0
	fmul.4s	v0, v12, v0
	fadd.4s	v0, v22, v0
	ldr	q3, [x8, #32896]
	and.16b	v3, v1, v3
	fmul.4s	v3, v4, v3
	ldr	q2, [sp, #6032]                 ; 16-byte Reload
	fadd.4s	v3, v2, v3
	ldr	q16, [x8, #32944]
	and.16b	v16, v14, v16
	fmul.4s	v16, v12, v16
	ldr	q2, [sp, #6048]                 ; 16-byte Reload
	fadd.4s	v16, v2, v16
	ldr	q23, [x8, #32928]
	and.16b	v23, v1, v23
	fmul.4s	v23, v4, v23
	mov.16b	v9, v4
	ldr	q2, [sp, #6064]                 ; 16-byte Reload
	fadd.4s	v23, v2, v23
	ldr	q24, [x8, #32976]
	and.16b	v24, v14, v24
	fmul.4s	v24, v12, v24
	ldr	q2, [sp, #6080]                 ; 16-byte Reload
	fadd.4s	v22, v2, v24
	ldr	q24, [x8, #32960]
	and.16b	v24, v1, v24
	fmul.4s	v24, v4, v24
	ldr	q2, [sp, #6096]                 ; 16-byte Reload
	fadd.4s	v7, v2, v24
	ldr	q24, [x8, #33008]
	and.16b	v24, v14, v24
	fmul.4s	v24, v12, v24
	mov.16b	v8, v12
	ldr	q2, [sp, #6112]                 ; 16-byte Reload
	fadd.4s	v5, v2, v24
	ldr	q24, [x8, #32992]
	and.16b	v24, v1, v24
	fmul.4s	v24, v4, v24
	ldr	q2, [sp, #6128]                 ; 16-byte Reload
	fadd.4s	v4, v2, v24
	ldr	q24, [x8, #34944]
	and.16b	v24, v1, v24
	ldr	q2, [sp, #11168]                ; 16-byte Reload
	fmul.4s	v24, v2, v24
	fadd.4s	v3, v3, v24
	ldr	q24, [x8, #34960]
	and.16b	v24, v14, v24
	ldr	q11, [sp, #11232]               ; 16-byte Reload
	fmul.4s	v24, v11, v24
	fadd.4s	v0, v0, v24
	ldr	q24, [x8, #34976]
	and.16b	v24, v1, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v23, v23, v24
	ldr	q24, [x8, #34992]
	and.16b	v24, v14, v24
	fmul.4s	v24, v11, v24
	fadd.4s	v16, v16, v24
	ldr	q24, [x8, #35008]
	and.16b	v24, v1, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v7, v7, v24
	ldr	q24, [x8, #35024]
	and.16b	v24, v14, v24
	fmul.4s	v24, v11, v24
	fadd.4s	v22, v22, v24
	ldr	q24, [x8, #35040]
	and.16b	v24, v1, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v4, v4, v24
	ldr	q24, [x8, #35056]
	and.16b	v24, v14, v24
	fmul.4s	v24, v11, v24
	fadd.4s	v5, v5, v24
	ldr	q24, [x8, #37008]
	and.16b	v24, v14, v24
	ldr	q6, [sp, #11248]                ; 16-byte Reload
	fmul.4s	v24, v6, v24
	fadd.4s	v0, v0, v24
	ldr	q24, [x8, #36992]
	and.16b	v24, v1, v24
	ldr	q2, [sp, #11184]                ; 16-byte Reload
	fmul.4s	v24, v2, v24
	fadd.4s	v3, v3, v24
	ldr	q24, [x8, #37040]
	and.16b	v24, v14, v24
	fmul.4s	v24, v6, v24
	fadd.4s	v16, v16, v24
	ldr	q24, [x8, #37024]
	and.16b	v24, v1, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v23, v23, v24
	ldr	q24, [x8, #37072]
	and.16b	v24, v14, v24
	fmul.4s	v24, v6, v24
	fadd.4s	v22, v22, v24
	ldr	q24, [x8, #37056]
	and.16b	v24, v1, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v7, v7, v24
	ldr	q24, [x8, #37104]
	and.16b	v24, v14, v24
	fmul.4s	v24, v6, v24
	fadd.4s	v5, v5, v24
	ldr	q24, [x8, #37088]
	and.16b	v24, v1, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v4, v4, v24
	ldr	q24, [x8, #39040]
	and.16b	v24, v1, v24
	ldr	q6, [sp, #11056]                ; 16-byte Reload
	fmul.4s	v24, v6, v24
	fadd.4s	v3, v3, v24
	ldr	q24, [x8, #39056]
	and.16b	v24, v14, v24
	ldr	q2, [sp, #11264]                ; 16-byte Reload
	fmul.4s	v24, v2, v24
	fadd.4s	v0, v0, v24
	ldr	q24, [x8, #39072]
	and.16b	v24, v1, v24
	fmul.4s	v24, v6, v24
	fadd.4s	v23, v23, v24
	ldr	q24, [x8, #39088]
	and.16b	v24, v14, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v16, v16, v24
	ldr	q24, [x8, #39104]
	and.16b	v24, v1, v24
	fmul.4s	v24, v6, v24
	fadd.4s	v7, v7, v24
	ldr	q24, [x8, #39120]
	and.16b	v24, v14, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v22, v22, v24
	ldr	q24, [x8, #39136]
	and.16b	v24, v1, v24
	fmul.4s	v24, v6, v24
	fadd.4s	v4, v4, v24
	ldr	q24, [x8, #39152]
	and.16b	v24, v14, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v5, v5, v24
	ldr	q24, [x8, #41104]
	and.16b	v24, v14, v24
	ldr	q2, [sp, #11200]                ; 16-byte Reload
	fmul.4s	v24, v2, v24
	fadd.4s	v0, v0, v24
	ldr	q24, [x8, #41088]
	and.16b	v24, v1, v24
	ldr	q6, [sp, #11280]                ; 16-byte Reload
	fmul.4s	v24, v6, v24
	fadd.4s	v3, v3, v24
	ldr	q24, [x8, #41136]
	and.16b	v24, v14, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v16, v16, v24
	ldr	q24, [x8, #41120]
	and.16b	v24, v1, v24
	fmul.4s	v24, v6, v24
	fadd.4s	v23, v23, v24
	ldr	q24, [x8, #41168]
	and.16b	v24, v14, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v22, v22, v24
	ldr	q24, [x8, #41152]
	and.16b	v24, v1, v24
	fmul.4s	v24, v6, v24
	fadd.4s	v7, v7, v24
	ldr	q24, [x8, #41200]
	and.16b	v24, v14, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v5, v5, v24
	ldr	q24, [x8, #41184]
	and.16b	v24, v1, v24
	fmul.4s	v24, v6, v24
	fadd.4s	v4, v4, v24
	ldr	q24, [x8, #43136]
	and.16b	v24, v1, v24
	ldr	q6, [sp, #11216]                ; 16-byte Reload
	fmul.4s	v24, v6, v24
	fadd.4s	v3, v3, v24
	ldr	q24, [x8, #43152]
	and.16b	v24, v14, v24
	fmul.4s	v24, v15, v24
	fadd.4s	v0, v0, v24
	ldr	q24, [x8, #43168]
	and.16b	v24, v1, v24
	fmul.4s	v24, v6, v24
	fadd.4s	v23, v23, v24
	ldr	q24, [x8, #43184]
	and.16b	v24, v14, v24
	fmul.4s	v24, v15, v24
	fadd.4s	v16, v16, v24
	ldr	q24, [x8, #43200]
	and.16b	v24, v1, v24
	fmul.4s	v24, v6, v24
	fadd.4s	v7, v7, v24
	ldr	q24, [x8, #43216]
	and.16b	v24, v14, v24
	fmul.4s	v24, v15, v24
	fadd.4s	v22, v22, v24
	ldr	q24, [x8, #43232]
	and.16b	v24, v1, v24
	fmul.4s	v24, v6, v24
	fadd.4s	v4, v4, v24
	ldr	q24, [x8, #43248]
	and.16b	v24, v14, v24
	fmul.4s	v24, v15, v24
	fadd.4s	v5, v5, v24
	ldr	q24, [x8, #45200]
	and.16b	v24, v14, v24
	ldr	q15, [sp, #11136]               ; 16-byte Reload
	fmul.4s	v24, v15, v24
	fadd.4s	v0, v0, v24
	ldr	q24, [x8, #45184]
	and.16b	v24, v1, v24
	ldr	q2, [sp, #11088]                ; 16-byte Reload
	fmul.4s	v24, v2, v24
	fadd.4s	v3, v3, v24
	ldr	q24, [x8, #45232]
	and.16b	v24, v14, v24
	fmul.4s	v24, v15, v24
	fadd.4s	v16, v16, v24
	ldr	q24, [x8, #45216]
	and.16b	v24, v1, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v23, v23, v24
	ldr	q24, [x8, #45264]
	and.16b	v24, v14, v24
	fmul.4s	v24, v15, v24
	fadd.4s	v22, v22, v24
	ldr	q24, [x8, #45248]
	and.16b	v24, v1, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v7, v7, v24
	ldr	q24, [x8, #45296]
	and.16b	v24, v14, v24
	fmul.4s	v24, v15, v24
	fadd.4s	v5, v5, v24
	ldr	q24, [x8, #45280]
	and.16b	v24, v1, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v4, v4, v24
	ldr	q24, [x8, #47232]
	and.16b	v24, v1, v24
	ldr	q6, [sp, #11152]                ; 16-byte Reload
	fmul.4s	v24, v6, v24
	fadd.4s	v3, v3, v24
	ldr	q24, [x8, #47248]
	and.16b	v24, v14, v24
	fmul.4s	v24, v26, v24
	fadd.4s	v0, v0, v24
	ldr	q24, [x8, #47264]
	and.16b	v24, v1, v24
	fmul.4s	v24, v6, v24
	fadd.4s	v23, v23, v24
	ldr	q24, [x8, #47280]
	and.16b	v24, v14, v24
	fmul.4s	v24, v26, v24
	fadd.4s	v16, v16, v24
	ldr	q24, [x8, #47296]
	and.16b	v24, v1, v24
	fmul.4s	v24, v6, v24
	fadd.4s	v7, v7, v24
	ldr	q24, [x8, #47312]
	and.16b	v24, v14, v24
	fmul.4s	v24, v26, v24
	fadd.4s	v22, v22, v24
	ldr	q24, [x8, #47328]
	and.16b	v24, v1, v24
	fmul.4s	v24, v6, v24
	fadd.4s	v4, v4, v24
	ldr	q24, [x8, #47344]
	and.16b	v24, v14, v24
	fmul.4s	v24, v26, v24
	fadd.4s	v5, v5, v24
	ldr	q24, [x8, #49296]
	and.16b	v24, v14, v24
	ldr	q2, [sp, #11040]                ; 16-byte Reload
	fmul.4s	v24, v2, v24
	fadd.4s	v0, v0, v24
	ldr	q24, [x8, #49280]
	and.16b	v24, v1, v24
	fmul.4s	v24, v17, v24
	fadd.4s	v3, v3, v24
	ldr	q24, [x8, #49328]
	and.16b	v24, v14, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v16, v16, v24
	ldr	q24, [x8, #49312]
	and.16b	v24, v1, v24
	fmul.4s	v24, v17, v24
	fadd.4s	v23, v23, v24
	ldr	q24, [x8, #49360]
	and.16b	v24, v14, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v22, v22, v24
	ldr	q24, [x8, #49344]
	and.16b	v24, v1, v24
	fmul.4s	v24, v17, v24
	fadd.4s	v7, v7, v24
	ldr	q24, [x8, #49392]
	and.16b	v24, v14, v24
	fmul.4s	v24, v2, v24
	fadd.4s	v5, v5, v24
	ldr	q24, [x8, #49376]
	and.16b	v24, v1, v24
	fmul.4s	v24, v17, v24
	fadd.4s	v4, v4, v24
	ldr	q24, [x8, #51328]
	and.16b	v24, v1, v24
	fmul.4s	v24, v27, v24
	fadd.4s	v3, v3, v24
	ldr	q24, [x8, #51344]
	and.16b	v24, v14, v24
	fmul.4s	v24, v25, v24
	fadd.4s	v0, v0, v24
	ldr	q24, [x8, #51360]
	and.16b	v24, v1, v24
	fmul.4s	v24, v27, v24
	mov.16b	v12, v27
	fadd.4s	v23, v23, v24
	ldr	q24, [x8, #51376]
	and.16b	v24, v14, v24
	fmul.4s	v24, v25, v24
	mov.16b	v11, v25
	fadd.4s	v16, v16, v24
	ldr	q24, [x8, #51392]
	and.16b	v24, v1, v24
	fmul.4s	v24, v27, v24
	fadd.4s	v7, v7, v24
	ldr	q24, [x8, #51408]
	and.16b	v24, v14, v24
	fmul.4s	v24, v25, v24
	fadd.4s	v22, v22, v24
	ldr	q24, [x8, #51424]
	and.16b	v24, v1, v24
	fmul.4s	v24, v27, v24
	fadd.4s	v4, v4, v24
	ldr	q24, [x8, #51440]
	and.16b	v24, v14, v24
	fmul.4s	v24, v25, v24
	fadd.4s	v5, v5, v24
	ldr	q24, [x8, #53392]
	and.16b	v24, v14, v24
	ldr	q27, [sp, #11072]               ; 16-byte Reload
	fmul.4s	v24, v27, v24
	fadd.4s	v0, v0, v24
	ldr	q24, [x8, #53376]
	and.16b	v24, v1, v24
	fmul.4s	v24, v19, v24
	fadd.4s	v3, v3, v24
	ldr	q24, [x8, #53424]
	and.16b	v24, v14, v24
	fmul.4s	v24, v27, v24
	fadd.4s	v16, v16, v24
	ldr	q24, [x8, #53408]
	and.16b	v24, v1, v24
	fmul.4s	v24, v19, v24
	fadd.4s	v23, v23, v24
	ldr	q24, [x8, #53456]
	and.16b	v24, v14, v24
	fmul.4s	v24, v27, v24
	fadd.4s	v22, v22, v24
	ldr	q24, [x8, #53440]
	and.16b	v24, v1, v24
	fmul.4s	v24, v19, v24
	fadd.4s	v7, v7, v24
	ldr	q24, [x8, #53488]
	and.16b	v24, v14, v24
	fmul.4s	v24, v27, v24
	fadd.4s	v5, v5, v24
	ldr	q24, [x8, #53472]
	and.16b	v24, v1, v24
	fmul.4s	v24, v19, v24
	fadd.4s	v4, v4, v24
	ldr	q24, [x8, #55424]
	and.16b	v24, v1, v24
	fmul.4s	v24, v18, v24
	fadd.4s	v3, v3, v24
	ldr	q24, [x8, #55440]
	and.16b	v24, v14, v24
	fmul.4s	v24, v20, v24
	fadd.4s	v0, v0, v24
	ldr	q24, [x8, #55456]
	and.16b	v24, v1, v24
	fmul.4s	v24, v18, v24
	mov.16b	v30, v18
	fadd.4s	v23, v23, v24
	ldr	q24, [x8, #55472]
	and.16b	v24, v14, v24
	fmul.4s	v24, v20, v24
	mov.16b	v27, v20
	fadd.4s	v16, v16, v24
	ldr	q24, [x8, #55488]
	and.16b	v24, v1, v24
	fmul.4s	v24, v18, v24
	fadd.4s	v7, v7, v24
	ldr	q24, [x8, #55504]
	and.16b	v24, v14, v24
	fmul.4s	v24, v20, v24
	fadd.4s	v22, v22, v24
	ldr	q24, [x8, #55520]
	and.16b	v24, v1, v24
	fmul.4s	v24, v18, v24
	fadd.4s	v4, v4, v24
	ldr	q24, [x8, #55536]
	and.16b	v24, v14, v24
	fmul.4s	v24, v20, v24
	fadd.4s	v5, v5, v24
	ldr	q24, [x8, #57488]
	and.16b	v24, v14, v24
	ldr	q26, [sp, #10960]               ; 16-byte Reload
	fmul.4s	v24, v26, v24
	fadd.4s	v0, v0, v24
	ldr	q24, [x8, #57472]
	and.16b	v24, v1, v24
	ldr	q25, [sp, #8800]                ; 16-byte Reload
	fmul.4s	v24, v25, v24
	fadd.4s	v3, v3, v24
	ldr	q24, [x8, #57520]
	and.16b	v24, v14, v24
	fmul.4s	v24, v26, v24
	fadd.4s	v16, v16, v24
	ldr	q24, [x8, #57504]
	and.16b	v24, v1, v24
	fmul.4s	v24, v25, v24
	fadd.4s	v23, v23, v24
	ldr	q24, [x8, #57552]
	and.16b	v24, v14, v24
	fmul.4s	v24, v26, v24
	fadd.4s	v22, v22, v24
	ldr	q24, [x8, #57536]
	and.16b	v24, v1, v24
	fmul.4s	v24, v25, v24
	fadd.4s	v7, v7, v24
	ldr	q24, [x8, #57584]
	and.16b	v24, v14, v24
	fmul.4s	v24, v26, v24
	fadd.4s	v5, v5, v24
	ldr	q24, [x8, #57568]
	and.16b	v24, v1, v24
	fmul.4s	v24, v25, v24
	fadd.4s	v4, v4, v24
	ldr	q24, [x8, #59520]
	and.16b	v24, v1, v24
	fmul.4s	v24, v28, v24
	fadd.4s	v3, v3, v24
	ldr	q24, [x8, #59536]
	and.16b	v24, v14, v24
	mov.16b	v20, v21
	fmul.4s	v24, v21, v24
	fadd.4s	v0, v0, v24
	ldr	q24, [x8, #59552]
	and.16b	v24, v1, v24
	fmul.4s	v24, v28, v24
	mov.16b	v21, v28
	fadd.4s	v23, v23, v24
	ldr	q24, [x8, #59568]
	and.16b	v24, v14, v24
	fmul.4s	v24, v20, v24
	mov.16b	v28, v20
	fadd.4s	v16, v16, v24
	ldr	q24, [x8, #59584]
	and.16b	v24, v1, v24
	fmul.4s	v24, v21, v24
	fadd.4s	v7, v7, v24
	ldr	q24, [x8, #59600]
	and.16b	v24, v14, v24
	fmul.4s	v24, v20, v24
	fadd.4s	v22, v22, v24
	ldr	q24, [x8, #59616]
	and.16b	v24, v1, v24
	fmul.4s	v24, v21, v24
	fadd.4s	v4, v4, v24
	ldr	q24, [x8, #59632]
	and.16b	v24, v14, v24
	fmul.4s	v24, v20, v24
	fadd.4s	v5, v5, v24
	ldr	q24, [x8, #61584]
	and.16b	v24, v14, v24
	ldr	q20, [sp, #8832]                ; 16-byte Reload
	fmul.4s	v24, v20, v24
	fadd.4s	v0, v0, v24
	ldr	q24, [x8, #61568]
	and.16b	v24, v1, v24
	fmul.4s	v24, v13, v24
	fadd.4s	v3, v3, v24
	ldr	q24, [x8, #61616]
	and.16b	v24, v14, v24
	fmul.4s	v24, v20, v24
	fadd.4s	v16, v16, v24
	ldr	q24, [x8, #61600]
	and.16b	v24, v1, v24
	fmul.4s	v24, v13, v24
	fadd.4s	v23, v23, v24
	ldr	q24, [x8, #61648]
	and.16b	v24, v14, v24
	fmul.4s	v24, v20, v24
	fadd.4s	v22, v22, v24
	ldr	q24, [x8, #61632]
	and.16b	v24, v1, v24
	fmul.4s	v24, v13, v24
	fadd.4s	v7, v7, v24
	ldr	q24, [x8, #61680]
	and.16b	v24, v14, v24
	fmul.4s	v24, v20, v24
	fadd.4s	v5, v5, v24
	ldr	q24, [x8, #61664]
	and.16b	v24, v1, v24
	fmul.4s	v24, v13, v24
	fadd.4s	v4, v4, v24
	ldr	q24, [x8, #63616]
	and.16b	v24, v1, v24
	fmul.4s	v24, v31, v24
	fadd.4s	v2, v3, v24
	str	q2, [sp, #6128]                 ; 16-byte Spill
	ldr	q3, [x8, #63632]
	and.16b	v3, v14, v3
	fmul.4s	v3, v29, v3
	fadd.4s	v0, v0, v3
	str	q0, [sp, #6112]                 ; 16-byte Spill
	ldr	q0, [x8, #63648]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v23, v0
	str	q0, [sp, #6096]                 ; 16-byte Spill
	ldr	q0, [x8, #63664]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v16, v0
	str	q0, [sp, #6080]                 ; 16-byte Spill
	ldr	q0, [x8, #63680]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v7, v0
	str	q0, [sp, #6064]                 ; 16-byte Spill
	ldr	q0, [x8, #63696]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v22, v0
	str	q0, [sp, #6048]                 ; 16-byte Spill
	ldr	q0, [x8, #63712]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v4, v0
	str	q0, [sp, #6032]                 ; 16-byte Spill
	ldr	q0, [x8, #63728]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v5, v0
	str	q0, [sp, #6016]                 ; 16-byte Spill
	ldr	q0, [x8, #33040]
	and.16b	v0, v14, v0
	fmul.4s	v0, v8, v0
	ldr	q2, [sp, #5888]                 ; 16-byte Reload
	fadd.4s	v0, v2, v0
	ldr	q3, [x8, #33024]
	and.16b	v3, v1, v3
	fmul.4s	v3, v9, v3
	ldr	q2, [sp, #5904]                 ; 16-byte Reload
	fadd.4s	v3, v2, v3
	ldr	q4, [x8, #33072]
	and.16b	v4, v14, v4
	fmul.4s	v4, v8, v4
	ldr	q2, [sp, #5920]                 ; 16-byte Reload
	fadd.4s	v4, v2, v4
	ldr	q5, [x8, #33056]
	and.16b	v5, v1, v5
	fmul.4s	v5, v9, v5
	ldr	q2, [sp, #5936]                 ; 16-byte Reload
	fadd.4s	v5, v2, v5
	ldr	q7, [x8, #33104]
	and.16b	v7, v14, v7
	fmul.4s	v7, v8, v7
	ldr	q2, [sp, #5952]                 ; 16-byte Reload
	fadd.4s	v7, v2, v7
	ldr	q16, [x8, #33088]
	and.16b	v16, v1, v16
	fmul.4s	v16, v9, v16
	ldr	q2, [sp, #5968]                 ; 16-byte Reload
	fadd.4s	v16, v2, v16
	ldr	q18, [x8, #33136]
	and.16b	v18, v14, v18
	fmul.4s	v18, v8, v18
	ldr	q2, [sp, #5984]                 ; 16-byte Reload
	fadd.4s	v6, v2, v18
	ldr	q18, [x8, #33120]
	and.16b	v18, v1, v18
	fmul.4s	v18, v9, v18
	ldr	q2, [sp, #6000]                 ; 16-byte Reload
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #35072]
	and.16b	v18, v1, v18
	ldr	q23, [sp, #11168]               ; 16-byte Reload
	fmul.4s	v18, v23, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #35088]
	and.16b	v18, v14, v18
	ldr	q22, [sp, #11232]               ; 16-byte Reload
	fmul.4s	v18, v22, v18
	fadd.4s	v0, v0, v18
	ldr	q18, [x8, #35104]
	and.16b	v18, v1, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #35120]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #35136]
	and.16b	v18, v1, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #35152]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #35168]
	and.16b	v18, v1, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #35184]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #37136]
	and.16b	v18, v14, v18
	ldr	q23, [sp, #11248]               ; 16-byte Reload
	fmul.4s	v18, v23, v18
	fadd.4s	v0, v0, v18
	ldr	q18, [x8, #37120]
	and.16b	v18, v1, v18
	ldr	q22, [sp, #11184]               ; 16-byte Reload
	fmul.4s	v18, v22, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #37168]
	and.16b	v18, v14, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #37152]
	and.16b	v18, v1, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #37200]
	and.16b	v18, v14, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #37184]
	and.16b	v18, v1, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #37232]
	and.16b	v18, v14, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #37216]
	and.16b	v18, v1, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #39168]
	and.16b	v18, v1, v18
	ldr	q23, [sp, #11056]               ; 16-byte Reload
	fmul.4s	v18, v23, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #39184]
	and.16b	v18, v14, v18
	ldr	q22, [sp, #11264]               ; 16-byte Reload
	fmul.4s	v18, v22, v18
	fadd.4s	v0, v0, v18
	ldr	q18, [x8, #39200]
	and.16b	v18, v1, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #39216]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #39232]
	and.16b	v18, v1, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #39248]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #39264]
	and.16b	v18, v1, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #39280]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #41232]
	and.16b	v18, v14, v18
	ldr	q22, [sp, #11200]               ; 16-byte Reload
	fmul.4s	v18, v22, v18
	fadd.4s	v0, v0, v18
	ldr	q18, [x8, #41216]
	and.16b	v18, v1, v18
	ldr	q23, [sp, #11280]               ; 16-byte Reload
	fmul.4s	v18, v23, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #41264]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #41248]
	and.16b	v18, v1, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #41296]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #41280]
	and.16b	v18, v1, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #41328]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #41312]
	and.16b	v18, v1, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #43264]
	and.16b	v18, v1, v18
	ldr	q23, [sp, #11216]               ; 16-byte Reload
	fmul.4s	v18, v23, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #43280]
	and.16b	v18, v14, v18
	ldr	q22, [sp, #11120]               ; 16-byte Reload
	fmul.4s	v18, v22, v18
	fadd.4s	v0, v0, v18
	ldr	q18, [x8, #43296]
	and.16b	v18, v1, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #43312]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #43328]
	and.16b	v18, v1, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #43344]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #43360]
	and.16b	v18, v1, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #43376]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #45328]
	and.16b	v18, v14, v18
	fmul.4s	v18, v15, v18
	fadd.4s	v0, v0, v18
	ldr	q18, [x8, #45312]
	and.16b	v18, v1, v18
	ldr	q22, [sp, #11088]               ; 16-byte Reload
	fmul.4s	v18, v22, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #45360]
	and.16b	v18, v14, v18
	fmul.4s	v18, v15, v18
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #45344]
	and.16b	v18, v1, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #45392]
	and.16b	v18, v14, v18
	fmul.4s	v18, v15, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #45376]
	and.16b	v18, v1, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #45424]
	and.16b	v18, v14, v18
	fmul.4s	v18, v15, v18
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #45408]
	and.16b	v18, v1, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #47360]
	and.16b	v18, v1, v18
	ldr	q23, [sp, #11152]               ; 16-byte Reload
	fmul.4s	v18, v23, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #47376]
	and.16b	v18, v14, v18
	ldr	q22, [sp, #11024]               ; 16-byte Reload
	fmul.4s	v18, v22, v18
	fadd.4s	v0, v0, v18
	ldr	q18, [x8, #47392]
	and.16b	v18, v1, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #47408]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #47424]
	and.16b	v18, v1, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #47440]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #47456]
	and.16b	v18, v1, v18
	fmul.4s	v18, v23, v18
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #47472]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #49424]
	and.16b	v18, v14, v18
	ldr	q22, [sp, #11040]               ; 16-byte Reload
	fmul.4s	v18, v22, v18
	fadd.4s	v0, v0, v18
	ldr	q18, [x8, #49408]
	and.16b	v18, v1, v18
	fmul.4s	v18, v17, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #49456]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #49440]
	and.16b	v18, v1, v18
	fmul.4s	v18, v17, v18
	mov.16b	v24, v17
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #49488]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #49472]
	and.16b	v18, v1, v18
	fmul.4s	v18, v17, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #49520]
	and.16b	v18, v14, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #49504]
	and.16b	v18, v1, v18
	fmul.4s	v18, v17, v18
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #51456]
	and.16b	v18, v1, v18
	fmul.4s	v18, v12, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #51472]
	and.16b	v18, v14, v18
	fmul.4s	v18, v11, v18
	fadd.4s	v0, v0, v18
	ldr	q18, [x8, #51488]
	and.16b	v18, v1, v18
	fmul.4s	v18, v12, v18
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #51504]
	and.16b	v18, v14, v18
	fmul.4s	v18, v11, v18
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #51520]
	and.16b	v18, v1, v18
	str	q12, [sp, #11104]               ; 16-byte Spill
	fmul.4s	v18, v12, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #51536]
	and.16b	v18, v14, v18
	fmul.4s	v18, v11, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #51552]
	and.16b	v18, v1, v18
	fmul.4s	v18, v12, v18
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #51568]
	and.16b	v18, v14, v18
	fmul.4s	v18, v11, v18
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #53520]
	and.16b	v18, v14, v18
	ldr	q12, [sp, #11072]               ; 16-byte Reload
	fmul.4s	v18, v12, v18
	fadd.4s	v0, v0, v18
	ldr	q18, [x8, #53504]
	and.16b	v18, v1, v18
	fmul.4s	v18, v19, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #53552]
	and.16b	v18, v14, v18
	fmul.4s	v18, v12, v18
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #53536]
	and.16b	v18, v1, v18
	fmul.4s	v18, v19, v18
	mov.16b	v22, v19
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #53584]
	and.16b	v18, v14, v18
	fmul.4s	v18, v12, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #53568]
	and.16b	v18, v1, v18
	fmul.4s	v18, v19, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #53616]
	and.16b	v18, v14, v18
	fmul.4s	v18, v12, v18
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #53600]
	and.16b	v18, v1, v18
	fmul.4s	v18, v19, v18
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #55552]
	and.16b	v18, v1, v18
	fmul.4s	v18, v30, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #55568]
	and.16b	v18, v14, v18
	fmul.4s	v18, v27, v18
	fadd.4s	v0, v0, v18
	ldr	q18, [x8, #55584]
	and.16b	v18, v1, v18
	fmul.4s	v18, v30, v18
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #55600]
	and.16b	v18, v14, v18
	fmul.4s	v18, v27, v18
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #55616]
	and.16b	v18, v1, v18
	fmul.4s	v18, v30, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #55632]
	and.16b	v18, v14, v18
	fmul.4s	v18, v27, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #55648]
	and.16b	v18, v1, v18
	fmul.4s	v18, v30, v18
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #55664]
	and.16b	v18, v14, v18
	fmul.4s	v18, v27, v18
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #57616]
	and.16b	v18, v14, v18
	fmul.4s	v18, v26, v18
	fadd.4s	v0, v0, v18
	ldr	q18, [x8, #57600]
	and.16b	v18, v1, v18
	fmul.4s	v18, v25, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #57648]
	and.16b	v18, v14, v18
	fmul.4s	v18, v26, v18
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #57632]
	and.16b	v18, v1, v18
	fmul.4s	v18, v25, v18
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #57680]
	and.16b	v18, v14, v18
	fmul.4s	v18, v26, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #57664]
	and.16b	v18, v1, v18
	fmul.4s	v18, v25, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #57712]
	and.16b	v18, v14, v18
	fmul.4s	v18, v26, v18
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #57696]
	and.16b	v18, v1, v18
	fmul.4s	v18, v25, v18
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #59648]
	and.16b	v18, v1, v18
	fmul.4s	v18, v21, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #59664]
	and.16b	v18, v14, v18
	fmul.4s	v18, v28, v18
	fadd.4s	v0, v0, v18
	ldr	q18, [x8, #59680]
	and.16b	v18, v1, v18
	fmul.4s	v18, v21, v18
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #59696]
	and.16b	v18, v14, v18
	fmul.4s	v18, v28, v18
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #59712]
	and.16b	v18, v1, v18
	fmul.4s	v18, v21, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #59728]
	and.16b	v18, v14, v18
	fmul.4s	v18, v28, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #59744]
	and.16b	v18, v1, v18
	fmul.4s	v18, v21, v18
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #59760]
	and.16b	v18, v14, v18
	fmul.4s	v18, v28, v18
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #61712]
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fadd.4s	v0, v0, v18
	ldr	q18, [x8, #61696]
	and.16b	v18, v1, v18
	fmul.4s	v18, v13, v18
	fadd.4s	v3, v3, v18
	ldr	q18, [x8, #61744]
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fadd.4s	v4, v4, v18
	ldr	q18, [x8, #61728]
	and.16b	v18, v1, v18
	fmul.4s	v18, v13, v18
	mov.16b	v23, v13
	fadd.4s	v5, v5, v18
	ldr	q18, [x8, #61776]
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [x8, #61760]
	and.16b	v18, v1, v18
	fmul.4s	v18, v13, v18
	fadd.4s	v16, v16, v18
	ldr	q18, [x8, #61808]
	and.16b	v18, v14, v18
	fmul.4s	v18, v20, v18
	fadd.4s	v6, v6, v18
	ldr	q18, [x8, #61792]
	and.16b	v18, v1, v18
	fmul.4s	v18, v13, v18
	fadd.4s	v2, v2, v18
	ldr	q18, [x8, #63744]
	and.16b	v18, v1, v18
	fmul.4s	v18, v31, v18
	fadd.4s	v3, v3, v18
	str	q3, [sp, #6000]                 ; 16-byte Spill
	ldr	q3, [x8, #63760]
	and.16b	v3, v14, v3
	fmul.4s	v3, v29, v3
	fadd.4s	v0, v0, v3
	str	q0, [sp, #5984]                 ; 16-byte Spill
	ldr	q0, [x8, #63776]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v5, v0
	str	q0, [sp, #5968]                 ; 16-byte Spill
	ldr	q0, [x8, #63792]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v4, v0
	str	q0, [sp, #5952]                 ; 16-byte Spill
	ldr	q0, [x8, #63808]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v16, v0
	str	q0, [sp, #5936]                 ; 16-byte Spill
	ldr	q0, [x8, #63824]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v7, v0
	str	q0, [sp, #5920]                 ; 16-byte Spill
	ldr	q0, [x8, #63840]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v2, v0
	str	q0, [sp, #5904]                 ; 16-byte Spill
	ldr	q0, [x8, #63856]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v6, v0
	str	q0, [sp, #5888]                 ; 16-byte Spill
	ldr	q0, [x8, #33168]
	and.16b	v0, v14, v0
	fmul.4s	v0, v8, v0
	ldr	q2, [sp, #5872]                 ; 16-byte Reload
	fadd.4s	v0, v2, v0
	ldr	q2, [x8, #33152]
	and.16b	v2, v1, v2
	fmul.4s	v2, v9, v2
	ldr	q19, [sp, #10928]               ; 16-byte Reload
	ldr	q3, [sp, #7136]                 ; 16-byte Reload
	fmul.4s	v3, v3, v19
	fadd.4s	v2, v3, v2
	ldr	q3, [x8, #33200]
	and.16b	v3, v14, v3
	fmul.4s	v3, v8, v3
	ldr	q4, [sp, #7184]                 ; 16-byte Reload
	ldr	q13, [sp, #10944]               ; 16-byte Reload
	fmul.4s	v4, v4, v13
	fadd.4s	v3, v4, v3
	ldr	q4, [x8, #33184]
	and.16b	v4, v1, v4
	fmul.4s	v4, v9, v4
	mov.16b	v16, v9
	ldr	q5, [sp, #7168]                 ; 16-byte Reload
	fmul.4s	v5, v5, v19
	mov.16b	v9, v19
	fadd.4s	v4, v5, v4
	ldr	q5, [x8, #33232]
	and.16b	v5, v14, v5
	fmul.4s	v5, v8, v5
	ldr	q6, [sp, #7216]                 ; 16-byte Reload
	fmul.4s	v6, v6, v13
	fadd.4s	v5, v6, v5
	ldr	q6, [x8, #33216]
	and.16b	v6, v1, v6
	mov.16b	v17, v16
	fmul.4s	v6, v16, v6
	ldr	q7, [sp, #7200]                 ; 16-byte Reload
	fmul.4s	v7, v7, v19
	fadd.4s	v6, v7, v6
	ldr	q7, [x8, #33264]
	and.16b	v7, v14, v7
	fmul.4s	v7, v8, v7
	ldr	q16, [sp, #7248]                ; 16-byte Reload
	fmul.4s	v16, v16, v13
	fadd.4s	v7, v16, v7
	ldr	q16, [x8, #33248]
	and.16b	v16, v1, v16
	fmul.4s	v16, v17, v16
	ldr	q17, [sp, #7232]                ; 16-byte Reload
	fmul.4s	v17, v17, v19
	fadd.4s	v16, v17, v16
	ldr	q17, [x8, #35200]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11168]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #35216]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11232]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #35232]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #35248]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #35264]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #35280]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #35296]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #35312]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #37264]
	and.16b	v17, v14, v17
	ldr	q19, [sp, #11248]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #37248]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11184]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #37296]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #37280]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #37328]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #37312]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #37360]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #37344]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #39296]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11056]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #39312]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11264]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #39328]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #39344]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #39360]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #39376]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #39392]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #39408]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #41360]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11200]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #41344]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11280]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #41392]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #41376]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #41424]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #41408]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #41456]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #41440]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #43392]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11216]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #43408]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11120]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #43424]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #43440]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #43456]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #43472]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #43488]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #43504]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #45456]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #45440]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11088]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #45488]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #45472]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #45520]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #45504]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #45552]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #45536]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #47488]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11152]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #47504]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11024]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #47520]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #47536]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #47552]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #47568]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #47584]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #47600]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #49552]
	and.16b	v17, v14, v17
	ldr	q10, [sp, #11040]               ; 16-byte Reload
	fmul.4s	v17, v10, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #49536]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #49584]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #49568]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #49616]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #49600]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #49648]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #49632]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #51584]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11104]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #51600]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #51616]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #51632]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #51648]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #51664]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #51680]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #51696]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #53648]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #53632]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #53680]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #53664]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #53712]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #53696]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #53744]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #53728]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #55680]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #55696]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #55712]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #55728]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #55744]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #55760]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #55776]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #55792]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #57744]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #57728]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #57776]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #57760]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #57808]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #57792]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #57840]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #57824]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #59776]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #59792]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #59808]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #59824]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #59840]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #59856]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #59872]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #59888]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #61840]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #61824]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #61872]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #61856]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #61904]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #61888]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #61936]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #61920]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #63872]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v2, v2, v17
	str	q2, [sp, #5872]                 ; 16-byte Spill
	ldr	q2, [x8, #63888]
	and.16b	v2, v14, v2
	fmul.4s	v2, v29, v2
	fadd.4s	v0, v0, v2
	str	q0, [sp, #5856]                 ; 16-byte Spill
	ldr	q0, [x8, #63904]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v4, v0
	str	q0, [sp, #5840]                 ; 16-byte Spill
	ldr	q0, [x8, #63920]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v3, v0
	str	q0, [sp, #5824]                 ; 16-byte Spill
	ldr	q0, [x8, #63936]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v6, v0
	str	q0, [sp, #5808]                 ; 16-byte Spill
	ldr	q0, [x8, #63952]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v5, v0
	str	q0, [sp, #5792]                 ; 16-byte Spill
	ldr	q0, [x8, #63968]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v16, v0
	str	q0, [sp, #5776]                 ; 16-byte Spill
	ldr	q0, [x8, #63984]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v7, v0
	str	q0, [sp, #5760]                 ; 16-byte Spill
	ldr	q0, [x8, #33296]
	and.16b	v0, v14, v0
	fmul.4s	v0, v8, v0
	ldr	q2, [sp, #7280]                 ; 16-byte Reload
	mov.16b	v15, v13
	fmul.4s	v2, v2, v13
	fadd.4s	v0, v2, v0
	ldr	q2, [x8, #33280]
	and.16b	v2, v1, v2
	ldr	q19, [sp, #11008]               ; 16-byte Reload
	fmul.4s	v2, v19, v2
	ldr	q3, [sp, #7264]                 ; 16-byte Reload
	fmul.4s	v3, v3, v9
	fadd.4s	v2, v3, v2
	ldr	q3, [x8, #33328]
	and.16b	v3, v14, v3
	fmul.4s	v3, v8, v3
	ldr	q4, [sp, #7312]                 ; 16-byte Reload
	fmul.4s	v4, v4, v13
	fadd.4s	v3, v4, v3
	ldr	q4, [x8, #33312]
	and.16b	v4, v1, v4
	fmul.4s	v4, v19, v4
	ldr	q5, [sp, #7296]                 ; 16-byte Reload
	fmul.4s	v5, v5, v9
	fadd.4s	v4, v5, v4
	ldr	q5, [x8, #33360]
	and.16b	v5, v14, v5
	fmul.4s	v5, v8, v5
	ldr	q6, [sp, #7344]                 ; 16-byte Reload
	fmul.4s	v6, v6, v13
	fadd.4s	v5, v6, v5
	ldr	q6, [x8, #33344]
	and.16b	v6, v1, v6
	fmul.4s	v6, v19, v6
	ldr	q7, [sp, #7328]                 ; 16-byte Reload
	fmul.4s	v7, v7, v9
	fadd.4s	v6, v7, v6
	ldr	q7, [x8, #33392]
	and.16b	v7, v14, v7
	fmul.4s	v7, v8, v7
	ldr	q16, [sp, #7376]                ; 16-byte Reload
	fmul.4s	v16, v16, v13
	fadd.4s	v7, v16, v7
	ldr	q16, [x8, #33376]
	and.16b	v16, v1, v16
	fmul.4s	v16, v19, v16
	ldr	q17, [sp, #7360]                ; 16-byte Reload
	fmul.4s	v17, v17, v9
	fadd.4s	v16, v17, v16
	ldr	q17, [x8, #35328]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11168]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #35344]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11232]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #35360]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #35376]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #35392]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #35408]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #35424]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #35440]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #37392]
	and.16b	v17, v14, v17
	ldr	q19, [sp, #11248]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #37376]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11184]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #37424]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #37408]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #37456]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #37440]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #37488]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #37472]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #39424]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11056]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #39440]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11264]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #39456]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #39472]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #39488]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #39504]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #39520]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #39536]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #41488]
	and.16b	v17, v14, v17
	ldr	q12, [sp, #11200]               ; 16-byte Reload
	fmul.4s	v17, v12, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #41472]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11280]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #41520]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #41504]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #41536]
	ldr	q18, [x8, #41552]
	and.16b	v18, v14, v18
	fmul.4s	v18, v12, v18
	fadd.4s	v5, v5, v18
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #41584]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #41568]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #43520]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11216]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #43536]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11120]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #43552]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #43568]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #43584]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #43600]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #43616]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #43632]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #45584]
	and.16b	v17, v14, v17
	ldr	q13, [sp, #11136]               ; 16-byte Reload
	fmul.4s	v17, v13, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #45568]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11088]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #45616]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #45600]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #45648]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #45632]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #45680]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #45664]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #47616]
	and.16b	v17, v1, v17
	ldr	q13, [sp, #11152]               ; 16-byte Reload
	fmul.4s	v17, v13, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #47632]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11024]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #47648]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #47664]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #47680]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #47696]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #47712]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #47728]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #49680]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #49664]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #49712]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #49696]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #49744]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #49728]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #49776]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #49760]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #51712]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11104]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #51728]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #51744]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #51760]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #51776]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #51792]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #51808]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #51824]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #53776]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11072]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #53760]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #53808]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #53792]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #53840]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #53824]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #53872]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #53856]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #55808]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #55824]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #55840]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #55856]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #55872]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #55888]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #55904]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #55920]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #57872]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #57856]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #57904]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #57888]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #57936]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #57920]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #57968]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #57952]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #59904]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #59920]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #59936]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #59952]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #59968]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #59984]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #60000]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60016]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #61968]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #61952]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #62000]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #61984]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #62032]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #62016]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #62064]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62048]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #64000]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v2, v2, v17
	str	q2, [sp, #5744]                 ; 16-byte Spill
	ldr	q2, [x8, #64016]
	and.16b	v2, v14, v2
	fmul.4s	v2, v29, v2
	fadd.4s	v0, v0, v2
	str	q0, [sp, #5728]                 ; 16-byte Spill
	ldr	q0, [x8, #64032]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v4, v0
	str	q0, [sp, #5712]                 ; 16-byte Spill
	ldr	q0, [x8, #64048]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v3, v0
	str	q0, [sp, #5696]                 ; 16-byte Spill
	ldr	q0, [x8, #64064]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v6, v0
	str	q0, [sp, #5680]                 ; 16-byte Spill
	ldr	q0, [x8, #64080]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v5, v0
	str	q0, [sp, #5664]                 ; 16-byte Spill
	ldr	q0, [x8, #64096]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v16, v0
	str	q0, [sp, #5648]                 ; 16-byte Spill
	ldr	q0, [x8, #64112]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v7, v0
	str	q0, [sp, #5632]                 ; 16-byte Spill
	ldr	q0, [x8, #33424]
	and.16b	v0, v14, v0
	fmul.4s	v0, v8, v0
	ldr	q2, [sp, #7408]                 ; 16-byte Reload
	fmul.4s	v2, v2, v15
	fadd.4s	v0, v2, v0
	ldr	q2, [x8, #33408]
	and.16b	v2, v1, v2
	ldr	q19, [sp, #11008]               ; 16-byte Reload
	fmul.4s	v2, v19, v2
	ldr	q3, [sp, #7392]                 ; 16-byte Reload
	fmul.4s	v3, v3, v9
	fadd.4s	v2, v3, v2
	ldr	q3, [x8, #33456]
	and.16b	v3, v14, v3
	fmul.4s	v3, v8, v3
	ldr	q4, [sp, #7440]                 ; 16-byte Reload
	fmul.4s	v4, v4, v15
	fadd.4s	v3, v4, v3
	ldr	q4, [x8, #33440]
	and.16b	v4, v1, v4
	fmul.4s	v4, v19, v4
	ldr	q5, [sp, #7424]                 ; 16-byte Reload
	fmul.4s	v5, v5, v9
	fadd.4s	v4, v5, v4
	ldr	q5, [x8, #33488]
	and.16b	v5, v14, v5
	fmul.4s	v5, v8, v5
	ldr	q6, [sp, #7472]                 ; 16-byte Reload
	fmul.4s	v6, v6, v15
	fadd.4s	v5, v6, v5
	ldr	q6, [x8, #33472]
	and.16b	v6, v1, v6
	fmul.4s	v6, v19, v6
	ldr	q7, [sp, #7456]                 ; 16-byte Reload
	fmul.4s	v7, v7, v9
	fadd.4s	v6, v7, v6
	ldr	q7, [x8, #33520]
	and.16b	v7, v14, v7
	fmul.4s	v7, v8, v7
	ldr	q16, [sp, #7504]                ; 16-byte Reload
	fmul.4s	v16, v16, v15
	fadd.4s	v7, v16, v7
	ldr	q16, [x8, #33504]
	and.16b	v16, v1, v16
	fmul.4s	v16, v19, v16
	ldr	q17, [sp, #7488]                ; 16-byte Reload
	fmul.4s	v17, v17, v9
	fadd.4s	v16, v17, v16
	ldr	q17, [x8, #35456]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11168]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #35472]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11232]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #35488]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #35504]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #35520]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #35536]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #35552]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #35568]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #37520]
	and.16b	v17, v14, v17
	ldr	q19, [sp, #11248]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #37504]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11184]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #37552]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #37536]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #37584]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #37568]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #37616]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #37600]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #39552]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11056]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #39568]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11264]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #39584]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #39600]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #39616]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #39632]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #39648]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #39664]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #41616]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #41600]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11280]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #41648]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #41632]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #41680]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #41664]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #41712]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #41696]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #43648]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11216]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #43664]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11120]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #43680]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #43696]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #43712]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #43728]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #43744]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #43760]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #45712]
	and.16b	v17, v14, v17
	ldr	q19, [sp, #11136]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #45696]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11088]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #45744]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #45728]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #45776]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #45760]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #45808]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #45792]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #47744]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #47760]
	and.16b	v17, v14, v17
	ldr	q12, [sp, #11024]               ; 16-byte Reload
	fmul.4s	v17, v12, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #47776]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #47792]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #47808]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #47824]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #47840]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #47856]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #49808]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #49792]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #49840]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	mov.16b	v12, v10
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #49824]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	mov.16b	v10, v24
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #49872]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #49856]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #49904]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #49888]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #51840]
	and.16b	v17, v1, v17
	ldr	q13, [sp, #11104]               ; 16-byte Reload
	fmul.4s	v17, v13, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #51856]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #51872]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #51888]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	mov.16b	v24, v11
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #51904]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #51920]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #51936]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #51952]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #53904]
	and.16b	v17, v14, v17
	ldr	q11, [sp, #11072]               ; 16-byte Reload
	fmul.4s	v17, v11, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #53888]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #53936]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #53920]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #53968]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #53952]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #54000]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #53984]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #55936]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #55952]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #55968]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #55984]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #56000]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #56016]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #56032]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56048]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58000]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #57984]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #58032]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #58016]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #58064]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #58048]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #58096]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58080]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60032]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #60048]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #60064]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #60080]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #60096]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #60112]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #60128]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60144]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62096]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #62080]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #62128]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #62112]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #62160]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #62144]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #62192]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62176]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #64128]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v2, v2, v17
	str	q2, [sp, #5616]                 ; 16-byte Spill
	ldr	q2, [x8, #64144]
	and.16b	v2, v14, v2
	fmul.4s	v2, v29, v2
	fadd.4s	v0, v0, v2
	str	q0, [sp, #5600]                 ; 16-byte Spill
	ldr	q0, [x8, #64160]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v4, v0
	str	q0, [sp, #5584]                 ; 16-byte Spill
	ldr	q0, [x8, #64176]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v3, v0
	str	q0, [sp, #5568]                 ; 16-byte Spill
	ldr	q0, [x8, #64192]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v6, v0
	str	q0, [sp, #5552]                 ; 16-byte Spill
	ldr	q0, [x8, #64208]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v5, v0
	str	q0, [sp, #5536]                 ; 16-byte Spill
	ldr	q0, [x8, #64224]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v16, v0
	str	q0, [sp, #5520]                 ; 16-byte Spill
	ldr	q0, [x8, #64240]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v7, v0
	str	q0, [sp, #5504]                 ; 16-byte Spill
	ldr	q0, [x8, #33552]
	and.16b	v0, v14, v0
	fmul.4s	v0, v8, v0
	ldr	q2, [sp, #7536]                 ; 16-byte Reload
	fmul.4s	v2, v2, v15
	fadd.4s	v0, v2, v0
	ldr	q2, [x8, #33536]
	and.16b	v2, v1, v2
	ldr	q19, [sp, #11008]               ; 16-byte Reload
	fmul.4s	v2, v19, v2
	ldr	q3, [sp, #7520]                 ; 16-byte Reload
	mov.16b	v16, v9
	fmul.4s	v3, v3, v9
	fadd.4s	v2, v3, v2
	ldr	q3, [x8, #33584]
	and.16b	v3, v14, v3
	fmul.4s	v3, v8, v3
	ldr	q4, [sp, #7568]                 ; 16-byte Reload
	fmul.4s	v4, v4, v15
	fadd.4s	v3, v4, v3
	ldr	q4, [x8, #33568]
	and.16b	v4, v1, v4
	fmul.4s	v4, v19, v4
	mov.16b	v9, v19
	ldr	q5, [sp, #7552]                 ; 16-byte Reload
	fmul.4s	v5, v5, v16
	fadd.4s	v4, v5, v4
	ldr	q5, [x8, #33616]
	and.16b	v5, v14, v5
	fmul.4s	v5, v8, v5
	ldr	q6, [sp, #7600]                 ; 16-byte Reload
	mov.16b	v19, v15
	fmul.4s	v6, v6, v15
	fadd.4s	v5, v6, v5
	ldr	q6, [x8, #33600]
	and.16b	v6, v1, v6
	fmul.4s	v6, v9, v6
	ldr	q7, [sp, #7584]                 ; 16-byte Reload
	fmul.4s	v7, v7, v16
	mov.16b	v18, v16
	fadd.4s	v6, v7, v6
	ldr	q7, [x8, #33648]
	and.16b	v7, v14, v7
	fmul.4s	v7, v8, v7
	mov.16b	v15, v8
	ldr	q16, [sp, #7632]                ; 16-byte Reload
	fmul.4s	v16, v16, v19
	fadd.4s	v7, v16, v7
	ldr	q16, [x8, #33632]
	and.16b	v16, v1, v16
	fmul.4s	v16, v9, v16
	ldr	q17, [sp, #7616]                ; 16-byte Reload
	fmul.4s	v17, v17, v18
	fadd.4s	v16, v17, v16
	ldr	q17, [x8, #35584]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11168]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #35600]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11232]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #35616]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #35632]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #35648]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #35664]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #35680]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #35696]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #37648]
	and.16b	v17, v14, v17
	ldr	q19, [sp, #11248]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #37632]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11184]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #37680]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #37664]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #37712]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #37696]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #37744]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #37728]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #39680]
	and.16b	v17, v1, v17
	ldr	q8, [sp, #11056]                ; 16-byte Reload
	fmul.4s	v17, v8, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #39696]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11264]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #39712]
	and.16b	v17, v1, v17
	fmul.4s	v17, v8, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #39728]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #39744]
	and.16b	v17, v1, v17
	fmul.4s	v17, v8, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #39760]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #39776]
	and.16b	v17, v1, v17
	fmul.4s	v17, v8, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #39792]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #41744]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11200]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #41728]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11280]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #41776]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #41760]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #41808]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #41792]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #41840]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #41824]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #43776]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11216]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #43792]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11120]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #43808]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #43824]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #43840]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #43856]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #43872]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #43888]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #45840]
	and.16b	v17, v14, v17
	ldr	q19, [sp, #11136]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #45824]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11088]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #45872]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #45856]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #45904]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #45888]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #45936]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #45920]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #47872]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11152]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #47888]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11024]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #47904]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #47920]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #47936]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #47952]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #47968]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #47984]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #49936]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #49920]
	and.16b	v17, v1, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #49968]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #49952]
	and.16b	v17, v1, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #50000]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #49984]
	and.16b	v17, v1, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #50032]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #50016]
	and.16b	v17, v1, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #51968]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #51984]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #52000]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #52016]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #52032]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #52048]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #52064]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #52080]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #54032]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #54016]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #54064]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	mov.16b	v13, v11
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #54048]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	mov.16b	v19, v22
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #54096]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #54080]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #54128]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #54112]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56064]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #56080]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #56096]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #56112]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	mov.16b	v18, v27
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #56128]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #56144]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #56160]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56176]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58128]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #58112]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #58160]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #58144]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #58192]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #58176]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #58224]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58208]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60160]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #60176]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #60192]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	mov.16b	v22, v21
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #60208]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #60224]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #60240]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #60256]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60272]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62224]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #62208]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #62256]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	mov.16b	v21, v20
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #62240]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #62288]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #62272]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #62320]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62304]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #64256]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v2, v2, v17
	str	q2, [sp, #5488]                 ; 16-byte Spill
	ldr	q2, [x8, #64272]
	and.16b	v2, v14, v2
	fmul.4s	v2, v29, v2
	fadd.4s	v0, v0, v2
	str	q0, [sp, #5472]                 ; 16-byte Spill
	ldr	q0, [x8, #64288]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v4, v0
	str	q0, [sp, #5456]                 ; 16-byte Spill
	ldr	q0, [x8, #64304]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v3, v0
	str	q0, [sp, #5440]                 ; 16-byte Spill
	ldr	q0, [x8, #64320]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v6, v0
	str	q0, [sp, #5424]                 ; 16-byte Spill
	ldr	q0, [x8, #64336]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v5, v0
	str	q0, [sp, #5408]                 ; 16-byte Spill
	ldr	q0, [x8, #64352]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v16, v0
	str	q0, [sp, #5392]                 ; 16-byte Spill
	ldr	q0, [x8, #64368]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v7, v0
	str	q0, [sp, #5376]                 ; 16-byte Spill
	ldr	q0, [x8, #33680]
	and.16b	v0, v14, v0
	mov.16b	v16, v15
	fmul.4s	v0, v15, v0
	ldr	q2, [sp, #7664]                 ; 16-byte Reload
	ldr	q15, [sp, #10944]               ; 16-byte Reload
	fmul.4s	v2, v2, v15
	fadd.4s	v0, v2, v0
	ldr	q2, [x8, #33664]
	and.16b	v2, v1, v2
	fmul.4s	v2, v9, v2
	ldr	q3, [sp, #7648]                 ; 16-byte Reload
	ldr	q20, [sp, #10928]               ; 16-byte Reload
	fmul.4s	v3, v3, v20
	fadd.4s	v2, v3, v2
	ldr	q3, [x8, #33712]
	and.16b	v3, v14, v3
	fmul.4s	v3, v16, v3
	ldr	q4, [sp, #7696]                 ; 16-byte Reload
	fmul.4s	v4, v4, v15
	fadd.4s	v3, v4, v3
	ldr	q4, [x8, #33696]
	and.16b	v4, v1, v4
	fmul.4s	v4, v9, v4
	ldr	q5, [sp, #7680]                 ; 16-byte Reload
	fmul.4s	v5, v5, v20
	fadd.4s	v4, v5, v4
	ldr	q5, [x8, #33744]
	and.16b	v5, v14, v5
	str	q16, [sp, #6720]                ; 16-byte Spill
	fmul.4s	v5, v16, v5
	ldr	q6, [sp, #7728]                 ; 16-byte Reload
	fmul.4s	v6, v6, v15
	fadd.4s	v5, v6, v5
	ldr	q6, [x8, #33728]
	and.16b	v6, v1, v6
	fmul.4s	v6, v9, v6
	ldr	q7, [sp, #7712]                 ; 16-byte Reload
	fmul.4s	v7, v7, v20
	fadd.4s	v6, v7, v6
	ldr	q7, [x8, #33776]
	and.16b	v7, v14, v7
	fmul.4s	v7, v16, v7
	ldr	q16, [sp, #7760]                ; 16-byte Reload
	fmul.4s	v16, v16, v15
	fadd.4s	v7, v16, v7
	ldr	q16, [x8, #33760]
	and.16b	v16, v1, v16
	fmul.4s	v16, v9, v16
	ldr	q17, [sp, #7744]                ; 16-byte Reload
	fmul.4s	v17, v17, v20
	fadd.4s	v16, v17, v16
	ldr	q17, [x8, #35712]
	and.16b	v17, v1, v17
	ldr	q27, [sp, #11168]               ; 16-byte Reload
	fmul.4s	v17, v27, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #35728]
	and.16b	v17, v14, v17
	ldr	q20, [sp, #11232]               ; 16-byte Reload
	fmul.4s	v17, v20, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #35744]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #35760]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #35776]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #35792]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #35808]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #35824]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #37776]
	and.16b	v17, v14, v17
	ldr	q27, [sp, #11248]               ; 16-byte Reload
	fmul.4s	v17, v27, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #37760]
	and.16b	v17, v1, v17
	ldr	q20, [sp, #11184]               ; 16-byte Reload
	fmul.4s	v17, v20, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #37808]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #37792]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #37840]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #37824]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #37872]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #37856]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #39808]
	and.16b	v17, v1, v17
	fmul.4s	v17, v8, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #39824]
	and.16b	v17, v14, v17
	ldr	q20, [sp, #11264]               ; 16-byte Reload
	fmul.4s	v17, v20, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #39840]
	and.16b	v17, v1, v17
	fmul.4s	v17, v8, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #39856]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #39872]
	and.16b	v17, v1, v17
	fmul.4s	v17, v8, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #39888]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #39904]
	and.16b	v17, v1, v17
	fmul.4s	v17, v8, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #39920]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #41872]
	and.16b	v17, v14, v17
	ldr	q20, [sp, #11200]               ; 16-byte Reload
	fmul.4s	v17, v20, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #41856]
	and.16b	v17, v1, v17
	ldr	q27, [sp, #11280]               ; 16-byte Reload
	fmul.4s	v17, v27, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #41904]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #41888]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #41936]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #41920]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #41968]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #41952]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #43904]
	and.16b	v17, v1, v17
	ldr	q27, [sp, #11216]               ; 16-byte Reload
	fmul.4s	v17, v27, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #43920]
	and.16b	v17, v14, v17
	ldr	q20, [sp, #11120]               ; 16-byte Reload
	fmul.4s	v17, v20, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #43936]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #43952]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #43968]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #43984]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #44000]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #44016]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #45968]
	and.16b	v17, v14, v17
	ldr	q27, [sp, #11136]               ; 16-byte Reload
	fmul.4s	v17, v27, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #45952]
	and.16b	v17, v1, v17
	ldr	q20, [sp, #11088]               ; 16-byte Reload
	fmul.4s	v17, v20, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #46000]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #45984]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #46032]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #46016]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #46064]
	and.16b	v17, v14, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #46048]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #48000]
	and.16b	v17, v1, v17
	ldr	q27, [sp, #11152]               ; 16-byte Reload
	fmul.4s	v17, v27, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #48016]
	and.16b	v17, v14, v17
	ldr	q20, [sp, #11024]               ; 16-byte Reload
	fmul.4s	v17, v20, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #48032]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #48048]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #48064]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #48080]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #48096]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #48112]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #50064]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #50048]
	and.16b	v17, v1, v17
	mov.16b	v11, v10
	fmul.4s	v17, v10, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #50096]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #50080]
	and.16b	v17, v1, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #50128]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #50112]
	and.16b	v17, v1, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #50160]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #50144]
	and.16b	v17, v1, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #52096]
	and.16b	v17, v1, v17
	ldr	q8, [sp, #11104]                ; 16-byte Reload
	fmul.4s	v17, v8, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #52112]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #52128]
	and.16b	v17, v1, v17
	fmul.4s	v17, v8, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #52144]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	mov.16b	v20, v24
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #52160]
	and.16b	v17, v1, v17
	fmul.4s	v17, v8, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #52176]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #52192]
	and.16b	v17, v1, v17
	fmul.4s	v17, v8, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #52208]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #54160]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #54144]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #54192]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #54176]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #54224]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #54208]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #54256]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #54240]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56192]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #56208]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #56224]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #56240]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	mov.16b	v24, v18
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #56256]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #56272]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #56288]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56304]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58256]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #58240]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #58288]
	and.16b	v17, v14, v17
	fmul.4s	v17, v26, v17
	mov.16b	v10, v26
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #58272]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	mov.16b	v26, v25
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #58320]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #58304]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #58352]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58336]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60288]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #60304]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #60320]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	mov.16b	v25, v22
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #60336]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #60352]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #60368]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #60384]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60400]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62352]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #62336]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #62384]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	mov.16b	v22, v21
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #62368]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #62416]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #62400]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #62448]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62432]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #64384]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v2, v2, v17
	str	q2, [sp, #5360]                 ; 16-byte Spill
	ldr	q2, [x8, #64400]
	and.16b	v2, v14, v2
	fmul.4s	v2, v29, v2
	fadd.4s	v0, v0, v2
	str	q0, [sp, #5344]                 ; 16-byte Spill
	ldr	q0, [x8, #64416]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v4, v0
	str	q0, [sp, #5328]                 ; 16-byte Spill
	ldr	q0, [x8, #64432]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v3, v0
	str	q0, [sp, #5312]                 ; 16-byte Spill
	ldr	q0, [x8, #64448]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v6, v0
	str	q0, [sp, #5296]                 ; 16-byte Spill
	ldr	q0, [x8, #64464]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v5, v0
	str	q0, [sp, #5280]                 ; 16-byte Spill
	ldr	q0, [x8, #64480]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v16, v0
	str	q0, [sp, #5264]                 ; 16-byte Spill
	ldr	q0, [x8, #64496]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v7, v0
	str	q0, [sp, #5248]                 ; 16-byte Spill
	ldr	q0, [x8, #33808]
	and.16b	v0, v14, v0
	ldr	q8, [sp, #6720]                 ; 16-byte Reload
	fmul.4s	v0, v8, v0
	ldr	q2, [sp, #7792]                 ; 16-byte Reload
	fmul.4s	v2, v2, v15
	fadd.4s	v0, v2, v0
	ldr	q2, [x8, #33792]
	and.16b	v2, v1, v2
	mov.16b	v5, v9
	fmul.4s	v2, v9, v2
	ldr	q3, [sp, #7776]                 ; 16-byte Reload
	ldr	q9, [sp, #10928]                ; 16-byte Reload
	fmul.4s	v3, v3, v9
	fadd.4s	v2, v3, v2
	ldr	q3, [x8, #33840]
	and.16b	v3, v14, v3
	fmul.4s	v3, v8, v3
	ldr	q4, [sp, #7824]                 ; 16-byte Reload
	fmul.4s	v4, v4, v15
	fadd.4s	v3, v4, v3
	ldr	q4, [x8, #33824]
	and.16b	v4, v1, v4
	fmul.4s	v4, v5, v4
	mov.16b	v7, v5
	ldr	q5, [sp, #7808]                 ; 16-byte Reload
	fmul.4s	v5, v5, v9
	fadd.4s	v4, v5, v4
	ldr	q5, [x8, #33872]
	and.16b	v5, v14, v5
	fmul.4s	v5, v8, v5
	ldr	q6, [sp, #7856]                 ; 16-byte Reload
	fmul.4s	v6, v6, v15
	fadd.4s	v5, v6, v5
	ldr	q6, [x8, #33856]
	and.16b	v6, v1, v6
	mov.16b	v17, v7
	fmul.4s	v6, v7, v6
	ldr	q7, [sp, #7840]                 ; 16-byte Reload
	fmul.4s	v7, v7, v9
	fadd.4s	v6, v7, v6
	ldr	q7, [x8, #33904]
	and.16b	v7, v14, v7
	fmul.4s	v7, v8, v7
	ldr	q16, [sp, #7888]                ; 16-byte Reload
	fmul.4s	v16, v16, v15
	fadd.4s	v7, v16, v7
	ldr	q16, [x8, #33888]
	and.16b	v16, v1, v16
	fmul.4s	v16, v17, v16
	ldr	q17, [sp, #7872]                ; 16-byte Reload
	fmul.4s	v17, v17, v9
	fadd.4s	v16, v17, v16
	ldr	q17, [x8, #35840]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11168]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #35856]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11232]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #35872]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #35888]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #35904]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #35920]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #35936]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #35952]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #37904]
	and.16b	v17, v14, v17
	ldr	q19, [sp, #11248]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #37888]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11184]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #37936]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #37920]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #37968]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #37952]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #38000]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #37984]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #39952]
	ldr	q18, [x8, #39936]
	and.16b	v18, v1, v18
	ldr	q19, [sp, #11056]               ; 16-byte Reload
	fmul.4s	v18, v19, v18
	fadd.4s	v2, v2, v18
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11264]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #39968]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #39984]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #40000]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #40016]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #40032]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #40048]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #42000]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11200]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #41984]
	and.16b	v17, v1, v17
	ldr	q21, [sp, #11280]               ; 16-byte Reload
	fmul.4s	v17, v21, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #42032]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #42016]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #42064]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #42048]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #42096]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #42080]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #44032]
	and.16b	v17, v1, v17
	ldr	q21, [sp, #11216]               ; 16-byte Reload
	fmul.4s	v17, v21, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #44048]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11120]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #44064]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #44080]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #44096]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #44112]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #44128]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #44144]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #46096]
	and.16b	v17, v14, v17
	ldr	q21, [sp, #11136]               ; 16-byte Reload
	fmul.4s	v17, v21, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #46080]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11088]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #46128]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #46112]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #46160]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #46144]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #46192]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #46176]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #48128]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #48144]
	and.16b	v17, v14, v17
	ldr	q15, [sp, #11024]               ; 16-byte Reload
	fmul.4s	v17, v15, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #48160]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #48176]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #48192]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #48208]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #48224]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #48240]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #50192]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #50176]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #50224]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #50208]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #50256]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #50240]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #50288]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #50272]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #52224]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11104]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #52240]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #52256]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #52272]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	mov.16b	v21, v20
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #52288]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #52304]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #52320]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #52336]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #54288]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #54272]
	and.16b	v17, v1, v17
	ldr	q27, [sp, #10976]               ; 16-byte Reload
	fmul.4s	v17, v27, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #54320]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #54304]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #54352]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #54336]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #54384]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #54368]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56320]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #56336]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #56352]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #56368]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #56384]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #56400]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #56416]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56432]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58384]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #58368]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #58416]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #58400]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #58448]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #58432]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #58480]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58464]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60416]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #60432]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #60448]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #60464]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #60480]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #60496]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #60512]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60528]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62480]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #62464]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #62512]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	mov.16b	v18, v22
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #62496]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #62544]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #62528]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #62576]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62560]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #64512]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v2, v2, v17
	str	q2, [sp, #5232]                 ; 16-byte Spill
	ldr	q2, [x8, #64528]
	and.16b	v2, v14, v2
	fmul.4s	v2, v29, v2
	fadd.4s	v0, v0, v2
	str	q0, [sp, #5216]                 ; 16-byte Spill
	ldr	q0, [x8, #64544]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v4, v0
	str	q0, [sp, #5200]                 ; 16-byte Spill
	ldr	q0, [x8, #64560]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v3, v0
	str	q0, [sp, #5184]                 ; 16-byte Spill
	ldr	q0, [x8, #64576]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v6, v0
	str	q0, [sp, #5168]                 ; 16-byte Spill
	ldr	q0, [x8, #64592]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v5, v0
	str	q0, [sp, #5152]                 ; 16-byte Spill
	ldr	q0, [x8, #64608]
	and.16b	v0, v1, v0
	fmul.4s	v0, v31, v0
	fadd.4s	v0, v16, v0
	str	q0, [sp, #5136]                 ; 16-byte Spill
	ldr	q0, [x8, #64624]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v7, v0
	str	q0, [sp, #5120]                 ; 16-byte Spill
	ldr	q0, [x8, #33936]
	and.16b	v0, v14, v0
	fmul.4s	v0, v8, v0
	ldr	q13, [sp, #10944]               ; 16-byte Reload
	ldr	q2, [sp, #7920]                 ; 16-byte Reload
	fmul.4s	v2, v2, v13
	fadd.4s	v0, v2, v0
	ldr	q2, [x8, #33920]
	and.16b	v2, v1, v2
	ldr	q5, [sp, #11008]                ; 16-byte Reload
	fmul.4s	v2, v5, v2
	ldr	q3, [sp, #7904]                 ; 16-byte Reload
	mov.16b	v16, v9
	fmul.4s	v3, v3, v9
	fadd.4s	v2, v3, v2
	ldr	q3, [x8, #33968]
	and.16b	v3, v14, v3
	fmul.4s	v3, v8, v3
	mov.16b	v9, v8
	ldr	q4, [sp, #7952]                 ; 16-byte Reload
	fmul.4s	v4, v4, v13
	fadd.4s	v3, v4, v3
	ldr	q4, [x8, #33952]
	and.16b	v4, v1, v4
	fmul.4s	v4, v5, v4
	mov.16b	v8, v5
	ldr	q5, [sp, #7936]                 ; 16-byte Reload
	fmul.4s	v5, v5, v16
	fadd.4s	v4, v5, v4
	ldr	q5, [x8, #34000]
	and.16b	v5, v14, v5
	fmul.4s	v5, v9, v5
	ldr	q6, [sp, #7984]                 ; 16-byte Reload
	fmul.4s	v6, v6, v13
	fadd.4s	v5, v6, v5
	ldr	q6, [x8, #33984]
	and.16b	v6, v1, v6
	fmul.4s	v6, v8, v6
	ldr	q7, [sp, #7968]                 ; 16-byte Reload
	fmul.4s	v7, v7, v16
	mov.16b	v20, v16
	fadd.4s	v6, v7, v6
	ldr	q7, [x8, #34032]
	and.16b	v7, v14, v7
	fmul.4s	v7, v9, v7
	ldr	q16, [sp, #8016]                ; 16-byte Reload
	fmul.4s	v16, v16, v13
	fadd.4s	v7, v16, v7
	ldr	q16, [x8, #34016]
	and.16b	v16, v1, v16
	fmul.4s	v16, v8, v16
	ldr	q17, [sp, #8000]                ; 16-byte Reload
	fmul.4s	v17, v17, v20
	fadd.4s	v16, v17, v16
	ldr	q17, [x8, #35968]
	and.16b	v17, v1, v17
	ldr	q22, [sp, #11168]               ; 16-byte Reload
	fmul.4s	v17, v22, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #35984]
	and.16b	v17, v14, v17
	ldr	q20, [sp, #11232]               ; 16-byte Reload
	fmul.4s	v17, v20, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #36000]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #36016]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #36032]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #36048]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #36064]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #36080]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #38032]
	and.16b	v17, v14, v17
	ldr	q22, [sp, #11248]               ; 16-byte Reload
	fmul.4s	v17, v22, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #38016]
	and.16b	v17, v1, v17
	ldr	q20, [sp, #11184]               ; 16-byte Reload
	fmul.4s	v17, v20, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #38064]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #38048]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #38096]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #38080]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #38128]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #38112]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #40064]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #40080]
	and.16b	v17, v14, v17
	ldr	q22, [sp, #11264]               ; 16-byte Reload
	fmul.4s	v17, v22, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #40096]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	mov.16b	v20, v19
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #40112]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #40128]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #40144]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #40160]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #40176]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #42128]
	and.16b	v17, v14, v17
	ldr	q19, [sp, #11200]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #42112]
	and.16b	v17, v1, v17
	ldr	q22, [sp, #11280]               ; 16-byte Reload
	fmul.4s	v17, v22, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #42160]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #42144]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #42192]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #42176]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #42224]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #42208]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #44160]
	and.16b	v17, v1, v17
	ldr	q31, [sp, #11216]               ; 16-byte Reload
	fmul.4s	v17, v31, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #44176]
	and.16b	v17, v14, v17
	ldr	q19, [sp, #11120]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #44192]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #44208]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #44224]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #44240]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #44256]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #44272]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #46224]
	and.16b	v17, v14, v17
	ldr	q22, [sp, #11136]               ; 16-byte Reload
	fmul.4s	v17, v22, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #46208]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11088]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #46256]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #46240]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #46288]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #46272]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #46320]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #46304]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	mov.16b	v22, v19
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #48256]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11152]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #48272]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #48288]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #48304]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #48320]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #48336]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #48352]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #48368]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #50320]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #50304]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #50352]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #50336]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #50384]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #50368]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #50416]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #50400]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #52352]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11104]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #52368]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #52384]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #52400]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	str	q21, [sp, #9376]                ; 16-byte Spill
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #52416]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #52432]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #52448]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #52464]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #54416]
	and.16b	v17, v14, v17
	ldr	q21, [sp, #11072]               ; 16-byte Reload
	fmul.4s	v17, v21, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #54400]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #54448]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #54432]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #54480]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #54464]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #54512]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #54496]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56448]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #56464]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #56480]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #56496]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	mov.16b	v19, v24
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #56512]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #56528]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #56544]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56560]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58512]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #58496]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #58544]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	mov.16b	v24, v10
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #58528]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	mov.16b	v10, v26
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #58576]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #58560]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #58608]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58592]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60544]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #60560]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #60576]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	mov.16b	v26, v25
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #60592]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #60608]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #60624]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #60640]
	and.16b	v17, v1, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60656]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62608]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #62592]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #62640]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	mov.16b	v25, v18
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #62624]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #62672]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #62656]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #62704]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62688]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #64640]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #10992]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	str	q2, [sp, #5104]                 ; 16-byte Spill
	ldr	q2, [x8, #64656]
	and.16b	v2, v14, v2
	fmul.4s	v2, v29, v2
	fadd.4s	v0, v0, v2
	str	q0, [sp, #5088]                 ; 16-byte Spill
	ldr	q0, [x8, #64672]
	and.16b	v0, v1, v0
	fmul.4s	v0, v18, v0
	fadd.4s	v0, v4, v0
	str	q0, [sp, #5072]                 ; 16-byte Spill
	ldr	q0, [x8, #64688]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v3, v0
	str	q0, [sp, #5056]                 ; 16-byte Spill
	ldr	q0, [x8, #64704]
	and.16b	v0, v1, v0
	fmul.4s	v0, v18, v0
	fadd.4s	v0, v6, v0
	str	q0, [sp, #5040]                 ; 16-byte Spill
	ldr	q0, [x8, #64720]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v5, v0
	str	q0, [sp, #5024]                 ; 16-byte Spill
	ldr	q0, [x8, #64736]
	and.16b	v0, v1, v0
	fmul.4s	v0, v18, v0
	fadd.4s	v0, v16, v0
	str	q0, [sp, #5008]                 ; 16-byte Spill
	ldr	q0, [x8, #64752]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v7, v0
	str	q0, [sp, #4992]                 ; 16-byte Spill
	ldr	q0, [x8, #34064]
	and.16b	v0, v14, v0
	fmul.4s	v0, v9, v0
	ldr	q2, [sp, #8048]                 ; 16-byte Reload
	fmul.4s	v2, v2, v13
	fadd.4s	v0, v2, v0
	ldr	q2, [x8, #34048]
	and.16b	v2, v1, v2
	fmul.4s	v2, v8, v2
	ldr	q3, [sp, #8032]                 ; 16-byte Reload
	ldr	q17, [sp, #10928]               ; 16-byte Reload
	fmul.4s	v3, v3, v17
	fadd.4s	v2, v3, v2
	ldr	q3, [x8, #34096]
	and.16b	v3, v14, v3
	fmul.4s	v3, v9, v3
	ldr	q4, [sp, #8080]                 ; 16-byte Reload
	fmul.4s	v4, v4, v13
	fadd.4s	v3, v4, v3
	ldr	q4, [x8, #34080]
	and.16b	v4, v1, v4
	fmul.4s	v4, v8, v4
	ldr	q5, [sp, #8064]                 ; 16-byte Reload
	fmul.4s	v5, v5, v17
	fadd.4s	v4, v5, v4
	ldr	q5, [x8, #34128]
	and.16b	v5, v14, v5
	mov.16b	v16, v9
	fmul.4s	v5, v9, v5
	ldr	q6, [sp, #8112]                 ; 16-byte Reload
	fmul.4s	v6, v6, v13
	fadd.4s	v5, v6, v5
	ldr	q6, [x8, #34112]
	and.16b	v6, v1, v6
	fmul.4s	v6, v8, v6
	mov.16b	v18, v8
	ldr	q7, [sp, #8096]                 ; 16-byte Reload
	mov.16b	v9, v17
	fmul.4s	v7, v7, v17
	fadd.4s	v6, v7, v6
	ldr	q7, [x8, #34160]
	and.16b	v7, v14, v7
	fmul.4s	v7, v16, v7
	mov.16b	v8, v16
	ldr	q16, [sp, #8144]                ; 16-byte Reload
	fmul.4s	v16, v16, v13
	fadd.4s	v7, v16, v7
	ldr	q16, [x8, #34144]
	and.16b	v16, v1, v16
	fmul.4s	v16, v18, v16
	ldr	q17, [sp, #8128]                ; 16-byte Reload
	fmul.4s	v17, v17, v9
	fadd.4s	v16, v17, v16
	ldr	q17, [x8, #36096]
	and.16b	v17, v1, v17
	ldr	q27, [sp, #11168]               ; 16-byte Reload
	fmul.4s	v17, v27, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #36112]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11232]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #36128]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #36144]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #36160]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #36176]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #36192]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #36208]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #38160]
	and.16b	v17, v14, v17
	ldr	q13, [sp, #11248]               ; 16-byte Reload
	fmul.4s	v17, v13, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #38144]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11184]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #38192]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #38176]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	mov.16b	v27, v18
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #38224]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #38208]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #38256]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #38240]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #40192]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #40208]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11264]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #40224]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #40240]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #40256]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #40272]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #40288]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #40304]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #42256]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11200]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #42240]
	and.16b	v17, v1, v17
	ldr	q20, [sp, #11280]               ; 16-byte Reload
	fmul.4s	v17, v20, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #42288]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #42272]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #42320]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #42304]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #42352]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #42336]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #44288]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #44304]
	and.16b	v17, v14, v17
	ldr	q13, [sp, #11120]               ; 16-byte Reload
	fmul.4s	v17, v13, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #44320]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #44336]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #44352]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #44368]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #44384]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #44400]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #46352]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11136]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #46336]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #46384]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #46368]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	mov.16b	v20, v22
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #46416]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #46400]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #46448]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #46432]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #48384]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11152]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #48400]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #48416]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #48432]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #48448]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #48464]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #48480]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #48496]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #50448]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #50432]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #50480]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #50464]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #50512]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #50496]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #50544]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #50528]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #52480]
	and.16b	v17, v1, v17
	ldr	q11, [sp, #11104]               ; 16-byte Reload
	fmul.4s	v17, v11, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #52496]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #9376]                ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #52512]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #52528]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #52544]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #52560]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #52576]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #52592]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #54544]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #54528]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #10976]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #54576]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	mov.16b	v11, v21
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #54560]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #54608]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #54592]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #54640]
	and.16b	v17, v14, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #54624]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56576]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #56592]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #56608]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #56624]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	mov.16b	v22, v19
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #56640]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #56656]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #56672]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56688]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58640]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #58624]
	and.16b	v17, v1, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #58672]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #58656]
	and.16b	v17, v1, v17
	fmul.4s	v17, v10, v17
	mov.16b	v12, v10
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #58704]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #58688]
	and.16b	v17, v1, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #58736]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58720]
	and.16b	v17, v1, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60672]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #60688]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #60704]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #60720]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #60736]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #60752]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #60768]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60784]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62736]
	and.16b	v17, v14, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #62720]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #62768]
	and.16b	v17, v14, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #62752]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #62800]
	and.16b	v17, v14, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #62784]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #62832]
	and.16b	v17, v14, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62816]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #64768]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #10992]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	str	q2, [sp, #4976]                 ; 16-byte Spill
	ldr	q2, [x8, #64784]
	and.16b	v2, v14, v2
	fmul.4s	v2, v29, v2
	fadd.4s	v0, v0, v2
	str	q0, [sp, #4960]                 ; 16-byte Spill
	ldr	q0, [x8, #64800]
	and.16b	v0, v1, v0
	fmul.4s	v0, v18, v0
	fadd.4s	v0, v4, v0
	str	q0, [sp, #4944]                 ; 16-byte Spill
	ldr	q0, [x8, #64816]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v3, v0
	str	q0, [sp, #4928]                 ; 16-byte Spill
	ldr	q0, [x8, #64832]
	and.16b	v0, v1, v0
	fmul.4s	v0, v18, v0
	fadd.4s	v0, v6, v0
	str	q0, [sp, #4912]                 ; 16-byte Spill
	ldr	q0, [x8, #64848]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v5, v0
	str	q0, [sp, #4896]                 ; 16-byte Spill
	ldr	q0, [x8, #64864]
	and.16b	v0, v1, v0
	fmul.4s	v0, v18, v0
	fadd.4s	v0, v16, v0
	str	q0, [sp, #4880]                 ; 16-byte Spill
	ldr	q0, [x8, #64880]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v7, v0
	str	q0, [sp, #4864]                 ; 16-byte Spill
	ldr	q0, [x8, #34192]
	and.16b	v0, v14, v0
	fmul.4s	v0, v8, v0
	ldr	q10, [sp, #10944]               ; 16-byte Reload
	ldr	q2, [sp, #8176]                 ; 16-byte Reload
	fmul.4s	v2, v2, v10
	fadd.4s	v0, v2, v0
	ldr	q2, [x8, #34176]
	and.16b	v2, v1, v2
	ldr	q17, [sp, #11008]               ; 16-byte Reload
	fmul.4s	v2, v17, v2
	ldr	q3, [sp, #8160]                 ; 16-byte Reload
	fmul.4s	v3, v3, v9
	fadd.4s	v2, v3, v2
	ldr	q3, [x8, #34224]
	and.16b	v3, v14, v3
	fmul.4s	v3, v8, v3
	ldr	q4, [sp, #8208]                 ; 16-byte Reload
	fmul.4s	v4, v4, v10
	fadd.4s	v3, v4, v3
	ldr	q4, [x8, #34208]
	and.16b	v4, v1, v4
	fmul.4s	v4, v17, v4
	ldr	q5, [sp, #8192]                 ; 16-byte Reload
	fmul.4s	v5, v5, v9
	fadd.4s	v4, v5, v4
	ldr	q5, [x8, #34256]
	and.16b	v5, v14, v5
	fmul.4s	v5, v8, v5
	ldr	q6, [sp, #8240]                 ; 16-byte Reload
	fmul.4s	v6, v6, v10
	fadd.4s	v5, v6, v5
	ldr	q6, [x8, #34240]
	and.16b	v6, v1, v6
	fmul.4s	v6, v17, v6
	ldr	q7, [sp, #8224]                 ; 16-byte Reload
	fmul.4s	v7, v7, v9
	fadd.4s	v6, v7, v6
	ldr	q7, [x8, #34288]
	and.16b	v7, v14, v7
	fmul.4s	v7, v8, v7
	ldr	q16, [sp, #8272]                ; 16-byte Reload
	fmul.4s	v16, v16, v10
	fadd.4s	v7, v16, v7
	ldr	q16, [x8, #34272]
	and.16b	v16, v1, v16
	fmul.4s	v16, v17, v16
	ldr	q17, [sp, #8256]                ; 16-byte Reload
	fmul.4s	v17, v17, v9
	fadd.4s	v16, v17, v16
	ldr	q17, [x8, #36224]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11168]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #36240]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11232]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #36256]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #36272]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #36288]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #36304]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #36320]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #36336]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #38288]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11248]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #38272]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #38320]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #38304]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #38352]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #38336]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #38384]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #38368]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #40320]
	and.16b	v17, v1, v17
	ldr	q27, [sp, #11056]               ; 16-byte Reload
	fmul.4s	v17, v27, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #40336]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11264]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #40352]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #40368]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #40384]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #40400]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #40416]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #40432]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #42384]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11200]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #42368]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11280]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #42416]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #42400]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #42448]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #42432]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #42480]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #42464]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #44416]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11216]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #44432]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #44448]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #44464]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #44480]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #44496]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #44512]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #44528]
	and.16b	v17, v14, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #46480]
	and.16b	v17, v14, v17
	ldr	q31, [sp, #11136]               ; 16-byte Reload
	fmul.4s	v17, v31, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #46464]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #46512]
	and.16b	v17, v14, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #46496]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	mov.16b	v13, v20
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #46544]
	and.16b	v17, v14, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #46528]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #46576]
	and.16b	v17, v14, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #46560]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #48512]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11152]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #48528]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #48544]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #48560]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #48576]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #48592]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #48608]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #48624]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #50576]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11040]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #50560]
	and.16b	v17, v1, v17
	ldr	q21, [sp, #8752]                ; 16-byte Reload
	fmul.4s	v17, v21, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #50608]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #50592]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #50640]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #50624]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #50672]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #50656]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #52608]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11104]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #52624]
	and.16b	v17, v14, v17
	ldr	q19, [sp, #9376]                ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #52640]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #52656]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #52672]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #52688]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #52704]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #52720]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #54672]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #54656]
	and.16b	v17, v1, v17
	ldr	q20, [sp, #10976]               ; 16-byte Reload
	fmul.4s	v17, v20, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #54704]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #54688]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #54736]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #54720]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #54768]
	and.16b	v17, v14, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #54752]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56704]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #56720]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #56736]
	and.16b	v17, v1, v17
	fmul.4s	v17, v30, v17
	mov.16b	v11, v30
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #56752]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	mov.16b	v30, v22
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #56768]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #56784]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #56800]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56816]
	and.16b	v17, v14, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58768]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #58752]
	and.16b	v17, v1, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #58800]
	and.16b	v17, v14, v17
	fmul.4s	v17, v24, v17
	mov.16b	v18, v24
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #58784]
	and.16b	v17, v1, v17
	fmul.4s	v17, v12, v17
	mov.16b	v24, v12
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #58832]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #58816]
	and.16b	v17, v1, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #58864]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58848]
	and.16b	v17, v1, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60800]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #60816]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #60832]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #60848]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #60864]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #60880]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #60896]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60912]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62864]
	and.16b	v17, v14, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #62848]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #62896]
	and.16b	v17, v14, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #62880]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #62928]
	and.16b	v17, v14, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #62912]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #62960]
	and.16b	v17, v14, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62944]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #64896]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #10992]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	str	q2, [sp, #4848]                 ; 16-byte Spill
	ldr	q2, [x8, #64912]
	and.16b	v2, v14, v2
	fmul.4s	v2, v29, v2
	fadd.4s	v0, v0, v2
	str	q0, [sp, #4832]                 ; 16-byte Spill
	ldr	q0, [x8, #64928]
	and.16b	v0, v1, v0
	fmul.4s	v0, v18, v0
	fadd.4s	v0, v4, v0
	str	q0, [sp, #4816]                 ; 16-byte Spill
	ldr	q0, [x8, #64944]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v3, v0
	str	q0, [sp, #4800]                 ; 16-byte Spill
	ldr	q0, [x8, #64960]
	and.16b	v0, v1, v0
	fmul.4s	v0, v18, v0
	fadd.4s	v0, v6, v0
	str	q0, [sp, #4784]                 ; 16-byte Spill
	ldr	q0, [x8, #64976]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v5, v0
	str	q0, [sp, #4768]                 ; 16-byte Spill
	ldr	q0, [x8, #64992]
	and.16b	v0, v1, v0
	fmul.4s	v0, v18, v0
	fadd.4s	v0, v16, v0
	str	q0, [sp, #4752]                 ; 16-byte Spill
	ldr	q0, [x8, #65008]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v7, v0
	str	q0, [sp, #4736]                 ; 16-byte Spill
	ldr	q0, [x8, #34320]
	and.16b	v0, v14, v0
	fmul.4s	v0, v8, v0
	ldr	q2, [sp, #8304]                 ; 16-byte Reload
	fmul.4s	v2, v2, v10
	fadd.4s	v0, v2, v0
	ldr	q2, [x8, #34304]
	and.16b	v2, v1, v2
	ldr	q12, [sp, #11008]               ; 16-byte Reload
	fmul.4s	v2, v12, v2
	ldr	q3, [sp, #8288]                 ; 16-byte Reload
	fmul.4s	v3, v3, v9
	fadd.4s	v2, v3, v2
	ldr	q3, [x8, #34352]
	and.16b	v3, v14, v3
	fmul.4s	v3, v8, v3
	ldr	q4, [sp, #8336]                 ; 16-byte Reload
	fmul.4s	v4, v4, v10
	fadd.4s	v3, v4, v3
	ldr	q4, [x8, #34336]
	and.16b	v4, v1, v4
	fmul.4s	v4, v12, v4
	ldr	q5, [sp, #8320]                 ; 16-byte Reload
	fmul.4s	v5, v5, v9
	fadd.4s	v4, v5, v4
	ldr	q5, [x8, #34384]
	and.16b	v5, v14, v5
	fmul.4s	v5, v8, v5
	ldr	q6, [sp, #8368]                 ; 16-byte Reload
	fmul.4s	v6, v6, v10
	fadd.4s	v5, v6, v5
	ldr	q6, [x8, #34368]
	and.16b	v6, v1, v6
	fmul.4s	v6, v12, v6
	ldr	q7, [sp, #8352]                 ; 16-byte Reload
	fmul.4s	v7, v7, v9
	fadd.4s	v6, v7, v6
	ldr	q7, [x8, #34416]
	and.16b	v7, v14, v7
	fmul.4s	v7, v8, v7
	ldr	q16, [sp, #8400]                ; 16-byte Reload
	fmul.4s	v16, v16, v10
	fadd.4s	v7, v16, v7
	ldr	q16, [x8, #34400]
	and.16b	v16, v1, v16
	fmul.4s	v16, v12, v16
	ldr	q17, [sp, #8384]                ; 16-byte Reload
	fmul.4s	v17, v17, v9
	fadd.4s	v16, v17, v16
	ldr	q17, [x8, #36352]
	and.16b	v17, v1, v17
	ldr	q22, [sp, #11168]               ; 16-byte Reload
	fmul.4s	v17, v22, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #36368]
	and.16b	v17, v14, v17
	ldr	q20, [sp, #11232]               ; 16-byte Reload
	fmul.4s	v17, v20, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #36384]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #36400]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #36432]
	ldr	q18, [x8, #36416]
	and.16b	v18, v1, v18
	fmul.4s	v18, v22, v18
	fadd.4s	v6, v6, v18
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #36448]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #36464]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #38416]
	and.16b	v17, v14, v17
	ldr	q20, [sp, #11248]               ; 16-byte Reload
	fmul.4s	v17, v20, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #38400]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11184]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #38448]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #38432]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #38480]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #38464]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #38512]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #38496]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #40448]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #40464]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11264]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #40480]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #40496]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #40512]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #40528]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #40544]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #40560]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #42512]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11200]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #42496]
	and.16b	v17, v1, v17
	ldr	q20, [sp, #11280]               ; 16-byte Reload
	fmul.4s	v17, v20, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #42544]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #42528]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #42576]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #42560]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #42608]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #42592]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #44544]
	and.16b	v17, v1, v17
	ldr	q20, [sp, #11216]               ; 16-byte Reload
	fmul.4s	v17, v20, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #44560]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11120]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #44576]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #44592]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #44608]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #44624]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #44640]
	and.16b	v17, v1, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #44656]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #46608]
	and.16b	v17, v14, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #46592]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #46640]
	and.16b	v17, v14, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #46624]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #46672]
	and.16b	v17, v14, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #46656]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #46704]
	and.16b	v17, v14, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #46688]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #48640]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11152]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #48656]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #48672]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #48688]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #48704]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #48720]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #48736]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #48752]
	and.16b	v17, v14, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #50704]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11040]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #50688]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #50736]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #50720]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	mov.16b	v31, v21
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #50768]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #50752]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #50800]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #50784]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #52736]
	and.16b	v17, v1, v17
	ldr	q15, [sp, #11104]               ; 16-byte Reload
	fmul.4s	v17, v15, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #52752]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #52768]
	and.16b	v17, v1, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #52784]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	mov.16b	v20, v19
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #52800]
	and.16b	v17, v1, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #52816]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #52832]
	and.16b	v17, v1, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #52848]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #54800]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11072]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #54784]
	and.16b	v17, v1, v17
	ldr	q21, [sp, #10976]               ; 16-byte Reload
	fmul.4s	v17, v21, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #54832]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #54816]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #54864]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #54848]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #54896]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #54880]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56832]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #56848]
	and.16b	v17, v14, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #56864]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	mov.16b	v27, v11
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #56880]
	and.16b	v17, v14, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #56896]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #56912]
	and.16b	v17, v14, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #56928]
	and.16b	v17, v1, v17
	fmul.4s	v17, v11, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56944]
	and.16b	v17, v14, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58896]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #10960]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #58880]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #58928]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #58912]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #58960]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #58944]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #58992]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #58976]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #60928]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #60944]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #60960]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #60976]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #60992]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #61008]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #61024]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #61040]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #62992]
	and.16b	v17, v14, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #62976]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #63024]
	and.16b	v17, v14, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #63008]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #63056]
	and.16b	v17, v14, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #63040]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #63088]
	and.16b	v17, v14, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #63072]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #65024]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #10992]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	str	q2, [sp, #4720]                 ; 16-byte Spill
	ldr	q2, [x8, #65040]
	and.16b	v2, v14, v2
	fmul.4s	v2, v29, v2
	fadd.4s	v0, v0, v2
	str	q0, [sp, #4704]                 ; 16-byte Spill
	ldr	q0, [x8, #65056]
	and.16b	v0, v1, v0
	fmul.4s	v0, v18, v0
	fadd.4s	v0, v4, v0
	str	q0, [sp, #4688]                 ; 16-byte Spill
	ldr	q0, [x8, #65072]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v3, v0
	str	q0, [sp, #4672]                 ; 16-byte Spill
	ldr	q0, [x8, #65088]
	and.16b	v0, v1, v0
	fmul.4s	v0, v18, v0
	fadd.4s	v0, v6, v0
	str	q0, [sp, #4656]                 ; 16-byte Spill
	ldr	q0, [x8, #65104]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v5, v0
	str	q0, [sp, #4640]                 ; 16-byte Spill
	ldr	q0, [x8, #65120]
	and.16b	v0, v1, v0
	fmul.4s	v0, v18, v0
	fadd.4s	v0, v16, v0
	str	q0, [sp, #4624]                 ; 16-byte Spill
	ldr	q0, [x8, #65136]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v7, v0
	str	q0, [sp, #4608]                 ; 16-byte Spill
	ldr	q0, [x8, #34448]
	and.16b	v0, v14, v0
	fmul.4s	v0, v8, v0
	ldr	q2, [sp, #8432]                 ; 16-byte Reload
	mov.16b	v11, v10
	fmul.4s	v2, v2, v10
	fadd.4s	v0, v2, v0
	ldr	q2, [x8, #34432]
	and.16b	v2, v1, v2
	fmul.4s	v2, v12, v2
	ldr	q3, [sp, #8416]                 ; 16-byte Reload
	fmul.4s	v3, v3, v9
	fadd.4s	v2, v3, v2
	ldr	q3, [x8, #34480]
	and.16b	v3, v14, v3
	fmul.4s	v3, v8, v3
	ldr	q4, [sp, #8464]                 ; 16-byte Reload
	fmul.4s	v4, v4, v10
	fadd.4s	v3, v4, v3
	ldr	q4, [x8, #34464]
	and.16b	v4, v1, v4
	fmul.4s	v4, v12, v4
	ldr	q5, [sp, #8448]                 ; 16-byte Reload
	fmul.4s	v5, v5, v9
	fadd.4s	v4, v5, v4
	ldr	q5, [x8, #34512]
	and.16b	v5, v14, v5
	fmul.4s	v5, v8, v5
	ldr	q6, [sp, #8496]                 ; 16-byte Reload
	fmul.4s	v6, v6, v10
	fadd.4s	v5, v6, v5
	ldr	q6, [x8, #34496]
	and.16b	v6, v1, v6
	fmul.4s	v6, v12, v6
	ldr	q7, [sp, #8480]                 ; 16-byte Reload
	fmul.4s	v7, v7, v9
	fadd.4s	v6, v7, v6
	ldr	q7, [x8, #34544]
	and.16b	v7, v14, v7
	fmul.4s	v7, v8, v7
	ldr	q16, [sp, #8528]                ; 16-byte Reload
	fmul.4s	v16, v16, v10
	fadd.4s	v7, v16, v7
	ldr	q16, [x8, #34528]
	and.16b	v16, v1, v16
	fmul.4s	v16, v12, v16
	ldr	q17, [sp, #8512]                ; 16-byte Reload
	fmul.4s	v17, v17, v9
	fadd.4s	v16, v17, v16
	ldr	q17, [x8, #36480]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #36496]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11232]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #36512]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #36528]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #36544]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #36560]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #36576]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #36592]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #38544]
	and.16b	v17, v14, v17
	ldr	q19, [sp, #11248]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #38528]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11184]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #38576]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #38560]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #38608]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #38592]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #38640]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #38624]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #40576]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11056]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #40592]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11264]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #40608]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #40624]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #40640]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #40656]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #40672]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #40688]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #42640]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11200]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #42624]
	and.16b	v17, v1, v17
	ldr	q19, [sp, #11280]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #42672]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #42656]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #42704]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #42688]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #42736]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #42720]
	and.16b	v17, v1, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #44672]
	and.16b	v17, v1, v17
	ldr	q18, [sp, #11216]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #44688]
	and.16b	v17, v14, v17
	ldr	q19, [sp, #11120]               ; 16-byte Reload
	fmul.4s	v17, v19, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #44704]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #44720]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #44736]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #44752]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #44768]
	and.16b	v17, v1, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #44784]
	and.16b	v17, v14, v17
	fmul.4s	v17, v19, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #46736]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11136]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #46720]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #46768]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #46752]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	mov.16b	v21, v13
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #46800]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #46784]
	and.16b	v17, v1, v17
	fmul.4s	v17, v13, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #46832]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	mov.16b	v13, v18
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #46816]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #48768]
	and.16b	v17, v1, v17
	ldr	q21, [sp, #11152]               ; 16-byte Reload
	fmul.4s	v17, v21, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #48784]
	and.16b	v17, v14, v17
	ldr	q10, [sp, #11024]               ; 16-byte Reload
	fmul.4s	v17, v10, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #48800]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #48816]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #48832]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #48848]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #48864]
	and.16b	v17, v1, v17
	fmul.4s	v17, v21, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #48880]
	and.16b	v17, v14, v17
	fmul.4s	v17, v10, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #50832]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #11040]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #50816]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #50864]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #50848]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #50896]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #50880]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #50928]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #50912]
	and.16b	v17, v1, v17
	fmul.4s	v17, v31, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #52864]
	and.16b	v17, v1, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #52880]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #52896]
	and.16b	v17, v1, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #52912]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #52928]
	and.16b	v17, v1, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #52944]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #52960]
	and.16b	v17, v1, v17
	fmul.4s	v17, v15, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #52976]
	and.16b	v17, v14, v17
	fmul.4s	v17, v20, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #54928]
	and.16b	v17, v14, v17
	ldr	q12, [sp, #11072]               ; 16-byte Reload
	fmul.4s	v17, v12, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #54912]
	and.16b	v17, v1, v17
	ldr	q22, [sp, #10976]               ; 16-byte Reload
	fmul.4s	v17, v22, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #54960]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #54944]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #54992]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #54976]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #55024]
	and.16b	v17, v14, v17
	fmul.4s	v17, v12, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #55008]
	and.16b	v17, v1, v17
	fmul.4s	v17, v22, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #56960]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #56976]
	and.16b	v17, v14, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #56992]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #57008]
	and.16b	v17, v14, v17
	fmul.4s	v17, v30, v17
	mov.16b	v12, v30
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #57024]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #57040]
	and.16b	v17, v14, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #57056]
	and.16b	v17, v1, v17
	fmul.4s	v17, v27, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #57072]
	and.16b	v17, v14, v17
	fmul.4s	v17, v30, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #59024]
	and.16b	v17, v14, v17
	ldr	q18, [sp, #10960]               ; 16-byte Reload
	fmul.4s	v17, v18, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #59008]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #59056]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #59040]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	mov.16b	v30, v24
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #59088]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #59072]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #59120]
	and.16b	v17, v14, v17
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #59104]
	and.16b	v17, v1, v17
	fmul.4s	v17, v24, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #61056]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #61072]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #61088]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #61104]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #61120]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [x8, #61136]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #61152]
	and.16b	v17, v1, v17
	fmul.4s	v17, v26, v17
	fadd.4s	v16, v16, v17
	ldr	q17, [x8, #61168]
	and.16b	v17, v14, v17
	fmul.4s	v17, v28, v17
	fadd.4s	v7, v7, v17
	ldr	q17, [x8, #63120]
	and.16b	v17, v14, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v0, v0, v17
	ldr	q17, [x8, #63104]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v2, v2, v17
	ldr	q17, [x8, #63152]
	and.16b	v17, v14, v17
	fmul.4s	v17, v25, v17
	mov.16b	v28, v25
	fadd.4s	v3, v3, v17
	ldr	q17, [x8, #63136]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	mov.16b	v26, v23
	fadd.4s	v4, v4, v17
	ldr	q17, [x8, #63184]
	and.16b	v17, v14, v17
	fmul.4s	v17, v25, v17
	fadd.4s	v5, v5, v17
	ldr	q17, [x8, #63168]
	and.16b	v17, v1, v17
	fmul.4s	v17, v23, v17
	fadd.4s	v18, v6, v17
	ldr	q6, [x8, #63216]
	and.16b	v6, v14, v6
	fmul.4s	v6, v25, v6
	fadd.4s	v7, v7, v6
	ldr	q6, [x8, #63200]
	and.16b	v6, v1, v6
	fmul.4s	v6, v23, v6
	fadd.4s	v16, v16, v6
	ldr	q6, [x8, #65152]
	and.16b	v6, v1, v6
	ldr	q17, [sp, #10992]               ; 16-byte Reload
	fmul.4s	v6, v17, v6
	fadd.4s	v2, v2, v6
	str	q2, [sp, #4592]                 ; 16-byte Spill
	ldr	q6, [x8, #65168]
	and.16b	v6, v14, v6
	fmul.4s	v6, v29, v6
	fadd.4s	v0, v0, v6
	str	q0, [sp, #4576]                 ; 16-byte Spill
	ldr	q0, [x8, #65184]
	and.16b	v0, v1, v0
	fmul.4s	v0, v17, v0
	fadd.4s	v0, v4, v0
	str	q0, [sp, #4560]                 ; 16-byte Spill
	ldr	q0, [x8, #65200]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v3, v0
	str	q0, [sp, #4544]                 ; 16-byte Spill
	ldr	q0, [x8, #65216]
	and.16b	v0, v1, v0
	fmul.4s	v0, v17, v0
	fadd.4s	v0, v18, v0
	str	q0, [sp, #4528]                 ; 16-byte Spill
	ldr	q0, [x8, #65232]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v5, v0
	str	q0, [sp, #4512]                 ; 16-byte Spill
	ldr	q0, [x8, #65248]
	and.16b	v0, v1, v0
	fmul.4s	v0, v17, v0
	fadd.4s	v0, v16, v0
	str	q0, [sp, #4496]                 ; 16-byte Spill
	ldr	q0, [x8, #65264]
	and.16b	v0, v14, v0
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v7, v0
	str	q0, [sp, #4480]                 ; 16-byte Spill
	ldr	q0, [x8, #34576]
	and.16b	v0, v14, v0
	fmul.4s	v0, v8, v0
	ldr	q2, [sp, #8560]                 ; 16-byte Reload
	fmul.4s	v3, v2, v11
	fadd.4s	v0, v3, v0
	ldr	q3, [x8, #34560]
	and.16b	v3, v1, v3
	ldr	q6, [sp, #11008]                ; 16-byte Reload
	fmul.4s	v3, v6, v3
	ldr	q2, [sp, #8544]                 ; 16-byte Reload
	fmul.4s	v4, v2, v9
	fadd.4s	v3, v4, v3
	ldr	q4, [x8, #34608]
	and.16b	v4, v14, v4
	fmul.4s	v4, v8, v4
	ldr	q2, [sp, #8592]                 ; 16-byte Reload
	fmul.4s	v5, v2, v11
	fadd.4s	v4, v5, v4
	ldr	q5, [x8, #34592]
	and.16b	v5, v1, v5
	fmul.4s	v5, v6, v5
	ldr	q2, [sp, #8576]                 ; 16-byte Reload
	fmul.4s	v7, v2, v9
	fadd.4s	v5, v7, v5
	ldr	q7, [x8, #34640]
	and.16b	v7, v14, v7
	fmul.4s	v7, v8, v7
	ldr	q2, [sp, #8624]                 ; 16-byte Reload
	fmul.4s	v16, v2, v11
	fadd.4s	v7, v16, v7
	ldr	q16, [x8, #34624]
	and.16b	v16, v1, v16
	fmul.4s	v16, v6, v16
	ldr	q2, [sp, #8608]                 ; 16-byte Reload
	fmul.4s	v23, v2, v9
	fadd.4s	v16, v23, v16
	ldr	q23, [x8, #34672]
	and.16b	v23, v14, v23
	fmul.4s	v23, v8, v23
	ldr	q2, [sp, #8656]                 ; 16-byte Reload
	fmul.4s	v24, v2, v11
	fadd.4s	v23, v24, v23
	ldr	q24, [x8, #34656]
	and.16b	v24, v1, v24
	fmul.4s	v24, v6, v24
	ldr	q2, [sp, #8640]                 ; 16-byte Reload
	fmul.4s	v25, v2, v9
	fadd.4s	v24, v25, v24
	ldr	q25, [x8, #36608]
	and.16b	v25, v1, v25
	ldr	q2, [sp, #11168]                ; 16-byte Reload
	fmul.4s	v25, v2, v25
	fadd.4s	v3, v3, v25
	ldr	q25, [x8, #36624]
	and.16b	v25, v14, v25
	ldr	q6, [sp, #11232]                ; 16-byte Reload
	fmul.4s	v25, v6, v25
	fadd.4s	v0, v0, v25
	ldr	q25, [x8, #36640]
	and.16b	v25, v1, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x8, #36656]
	and.16b	v25, v14, v25
	fmul.4s	v25, v6, v25
	fadd.4s	v4, v4, v25
	ldr	q25, [x8, #36672]
	and.16b	v25, v1, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v16, v16, v25
	ldr	q25, [x8, #36688]
	and.16b	v25, v14, v25
	fmul.4s	v25, v6, v25
	fadd.4s	v7, v7, v25
	ldr	q25, [x8, #36704]
	and.16b	v25, v1, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v24, v24, v25
	ldr	q25, [x8, #36720]
	and.16b	v25, v14, v25
	fmul.4s	v25, v6, v25
	fadd.4s	v23, v23, v25
	ldr	q25, [x8, #38672]
	and.16b	v25, v14, v25
	ldr	q6, [sp, #11248]                ; 16-byte Reload
	fmul.4s	v25, v6, v25
	fadd.4s	v0, v0, v25
	ldr	q25, [x8, #38656]
	and.16b	v25, v1, v25
	ldr	q2, [sp, #11184]                ; 16-byte Reload
	fmul.4s	v25, v2, v25
	fadd.4s	v3, v3, v25
	ldr	q25, [x8, #38704]
	and.16b	v25, v14, v25
	fmul.4s	v25, v6, v25
	fadd.4s	v4, v4, v25
	ldr	q25, [x8, #38688]
	and.16b	v25, v1, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x8, #38736]
	and.16b	v25, v14, v25
	fmul.4s	v25, v6, v25
	fadd.4s	v7, v7, v25
	ldr	q25, [x8, #38720]
	and.16b	v25, v1, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v16, v16, v25
	ldr	q25, [x8, #38768]
	and.16b	v25, v14, v25
	fmul.4s	v25, v6, v25
	fadd.4s	v23, v23, v25
	ldr	q25, [x8, #38752]
	and.16b	v25, v1, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v24, v24, v25
	ldr	q25, [x8, #40704]
	and.16b	v25, v1, v25
	ldr	q6, [sp, #11056]                ; 16-byte Reload
	fmul.4s	v25, v6, v25
	fadd.4s	v3, v3, v25
	ldr	q25, [x8, #40720]
	and.16b	v25, v14, v25
	ldr	q2, [sp, #11264]                ; 16-byte Reload
	fmul.4s	v25, v2, v25
	fadd.4s	v0, v0, v25
	ldr	q25, [x8, #40736]
	and.16b	v25, v1, v25
	fmul.4s	v25, v6, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x8, #40752]
	and.16b	v25, v14, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v4, v4, v25
	ldr	q25, [x8, #40768]
	and.16b	v25, v1, v25
	fmul.4s	v25, v6, v25
	fadd.4s	v16, v16, v25
	ldr	q25, [x8, #40784]
	and.16b	v25, v14, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v7, v7, v25
	ldr	q25, [x8, #40800]
	and.16b	v25, v1, v25
	fmul.4s	v25, v6, v25
	fadd.4s	v24, v24, v25
	ldr	q25, [x8, #40816]
	and.16b	v25, v14, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v23, v23, v25
	ldr	q25, [x8, #42768]
	and.16b	v25, v14, v25
	ldr	q2, [sp, #11200]                ; 16-byte Reload
	fmul.4s	v25, v2, v25
	fadd.4s	v0, v0, v25
	ldr	q25, [x8, #42752]
	and.16b	v25, v1, v25
	ldr	q17, [sp, #11280]               ; 16-byte Reload
	fmul.4s	v25, v17, v25
	fadd.4s	v3, v3, v25
	ldr	q25, [x8, #42800]
	and.16b	v25, v14, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v4, v4, v25
	ldr	q25, [x8, #42784]
	and.16b	v25, v1, v25
	fmul.4s	v25, v17, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x8, #42832]
	and.16b	v25, v14, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v7, v7, v25
	ldr	q25, [x8, #42816]
	and.16b	v25, v1, v25
	fmul.4s	v25, v17, v25
	fadd.4s	v16, v16, v25
	ldr	q25, [x8, #42864]
	and.16b	v25, v14, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v23, v23, v25
	ldr	q25, [x8, #42848]
	and.16b	v25, v1, v25
	fmul.4s	v25, v17, v25
	fadd.4s	v24, v24, v25
	ldr	q25, [x8, #44800]
	and.16b	v25, v1, v25
	ldr	q2, [sp, #11216]                ; 16-byte Reload
	fmul.4s	v25, v2, v25
	fadd.4s	v3, v3, v25
	ldr	q25, [x8, #44816]
	and.16b	v25, v14, v25
	mov.16b	v15, v19
	fmul.4s	v25, v19, v25
	fadd.4s	v0, v0, v25
	ldr	q25, [x8, #44832]
	and.16b	v25, v1, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x8, #44848]
	and.16b	v25, v14, v25
	fmul.4s	v25, v19, v25
	fadd.4s	v4, v4, v25
	ldr	q25, [x8, #44864]
	and.16b	v25, v1, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v16, v16, v25
	ldr	q25, [x8, #44880]
	and.16b	v25, v14, v25
	fmul.4s	v25, v19, v25
	fadd.4s	v7, v7, v25
	ldr	q25, [x8, #44896]
	and.16b	v25, v1, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v24, v24, v25
	ldr	q25, [x8, #44912]
	and.16b	v25, v14, v25
	fmul.4s	v25, v19, v25
	fadd.4s	v23, v23, v25
	ldr	q25, [x8, #46864]
	and.16b	v25, v14, v25
	fmul.4s	v25, v13, v25
	fadd.4s	v0, v0, v25
	ldr	q25, [x8, #46848]
	and.16b	v25, v1, v25
	ldr	q19, [sp, #11088]               ; 16-byte Reload
	fmul.4s	v25, v19, v25
	fadd.4s	v3, v3, v25
	ldr	q25, [x8, #46896]
	and.16b	v25, v14, v25
	fmul.4s	v25, v13, v25
	fadd.4s	v4, v4, v25
	ldr	q25, [x8, #46880]
	and.16b	v25, v1, v25
	fmul.4s	v25, v19, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x8, #46928]
	and.16b	v25, v14, v25
	fmul.4s	v25, v13, v25
	fadd.4s	v7, v7, v25
	ldr	q25, [x8, #46912]
	and.16b	v25, v1, v25
	fmul.4s	v25, v19, v25
	fadd.4s	v16, v16, v25
	ldr	q25, [x8, #46960]
	and.16b	v25, v14, v25
	fmul.4s	v25, v13, v25
	fadd.4s	v23, v23, v25
	ldr	q25, [x8, #46944]
	and.16b	v25, v1, v25
	fmul.4s	v25, v19, v25
	fadd.4s	v24, v24, v25
	ldr	q25, [x8, #48896]
	and.16b	v25, v1, v25
	fmul.4s	v25, v21, v25
	fadd.4s	v3, v3, v25
	ldr	q25, [x8, #48912]
	and.16b	v25, v14, v25
	mov.16b	v13, v10
	fmul.4s	v25, v10, v25
	fadd.4s	v0, v0, v25
	ldr	q25, [x8, #48928]
	and.16b	v25, v1, v25
	fmul.4s	v25, v21, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x8, #48944]
	and.16b	v25, v14, v25
	fmul.4s	v25, v10, v25
	fadd.4s	v4, v4, v25
	ldr	q25, [x8, #48960]
	and.16b	v25, v1, v25
	fmul.4s	v25, v21, v25
	fadd.4s	v16, v16, v25
	ldr	q25, [x8, #48976]
	and.16b	v25, v14, v25
	fmul.4s	v25, v10, v25
	fadd.4s	v7, v7, v25
	ldr	q25, [x8, #48992]
	and.16b	v25, v1, v25
	fmul.4s	v25, v21, v25
	fadd.4s	v24, v24, v25
	ldr	q25, [x8, #49008]
	and.16b	v25, v14, v25
	fmul.4s	v25, v10, v25
	fadd.4s	v23, v23, v25
	ldr	q25, [x8, #50960]
	and.16b	v25, v14, v25
	ldr	q2, [sp, #11040]                ; 16-byte Reload
	fmul.4s	v25, v2, v25
	fadd.4s	v0, v0, v25
	ldr	q25, [x8, #50944]
	and.16b	v25, v1, v25
	mov.16b	v20, v31
	fmul.4s	v25, v31, v25
	fadd.4s	v3, v3, v25
	ldr	q25, [x8, #50992]
	and.16b	v25, v14, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v4, v4, v25
	ldr	q25, [x8, #50976]
	and.16b	v25, v1, v25
	fmul.4s	v25, v31, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x8, #51024]
	and.16b	v25, v14, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v7, v7, v25
	ldr	q25, [x8, #51008]
	and.16b	v25, v1, v25
	fmul.4s	v25, v31, v25
	fadd.4s	v16, v16, v25
	ldr	q25, [x8, #51056]
	and.16b	v25, v14, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v23, v23, v25
	ldr	q25, [x8, #51040]
	and.16b	v25, v1, v25
	fmul.4s	v25, v31, v25
	fadd.4s	v24, v24, v25
	ldr	q25, [x8, #52992]
	and.16b	v25, v1, v25
	ldr	q2, [sp, #11104]                ; 16-byte Reload
	fmul.4s	v25, v2, v25
	fadd.4s	v3, v3, v25
	ldr	q25, [x8, #53008]
	and.16b	v25, v14, v25
	ldr	q22, [sp, #9376]                ; 16-byte Reload
	fmul.4s	v25, v22, v25
	fadd.4s	v0, v0, v25
	ldr	q25, [x8, #53024]
	and.16b	v25, v1, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x8, #53040]
	and.16b	v25, v14, v25
	fmul.4s	v25, v22, v25
	fadd.4s	v4, v4, v25
	ldr	q25, [x8, #53056]
	and.16b	v25, v1, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v16, v16, v25
	ldr	q25, [x8, #53072]
	and.16b	v25, v14, v25
	fmul.4s	v25, v22, v25
	fadd.4s	v7, v7, v25
	ldr	q25, [x8, #53088]
	and.16b	v25, v1, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v24, v24, v25
	ldr	q25, [x8, #53104]
	and.16b	v25, v14, v25
	fmul.4s	v25, v22, v25
	fadd.4s	v23, v23, v25
	ldr	q25, [x8, #55056]
	and.16b	v25, v14, v25
	ldr	q2, [sp, #11072]                ; 16-byte Reload
	fmul.4s	v25, v2, v25
	fadd.4s	v0, v0, v25
	ldr	q25, [x8, #55040]
	and.16b	v25, v1, v25
	ldr	q27, [sp, #10976]               ; 16-byte Reload
	fmul.4s	v25, v27, v25
	fadd.4s	v3, v3, v25
	ldr	q25, [x8, #55088]
	and.16b	v25, v14, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v4, v4, v25
	ldr	q25, [x8, #55072]
	and.16b	v25, v1, v25
	fmul.4s	v25, v27, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x8, #55120]
	and.16b	v25, v14, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v7, v7, v25
	ldr	q25, [x8, #55104]
	and.16b	v25, v1, v25
	fmul.4s	v25, v27, v25
	fadd.4s	v16, v16, v25
	ldr	q25, [x8, #55152]
	and.16b	v25, v14, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v23, v23, v25
	ldr	q25, [x8, #55136]
	and.16b	v25, v1, v25
	fmul.4s	v25, v27, v25
	fadd.4s	v24, v24, v25
	ldr	q25, [x8, #57088]
	and.16b	v25, v1, v25
	ldr	q10, [sp, #8784]                ; 16-byte Reload
	fmul.4s	v25, v10, v25
	fadd.4s	v3, v3, v25
	ldr	q25, [x8, #57104]
	and.16b	v25, v14, v25
	fmul.4s	v25, v12, v25
	fadd.4s	v0, v0, v25
	ldr	q25, [x8, #57120]
	and.16b	v25, v1, v25
	fmul.4s	v25, v10, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x8, #57136]
	and.16b	v25, v14, v25
	fmul.4s	v25, v12, v25
	fadd.4s	v4, v4, v25
	ldr	q25, [x8, #57152]
	and.16b	v25, v1, v25
	fmul.4s	v25, v10, v25
	fadd.4s	v16, v16, v25
	ldr	q25, [x8, #57168]
	and.16b	v25, v14, v25
	fmul.4s	v25, v12, v25
	fadd.4s	v7, v7, v25
	ldr	q25, [x8, #57184]
	and.16b	v25, v1, v25
	fmul.4s	v25, v10, v25
	fadd.4s	v24, v24, v25
	ldr	q25, [x8, #57200]
	and.16b	v25, v14, v25
	fmul.4s	v25, v12, v25
	fadd.4s	v23, v23, v25
	ldr	q25, [x8, #59152]
	and.16b	v25, v14, v25
	ldr	q2, [sp, #10960]                ; 16-byte Reload
	fmul.4s	v25, v2, v25
	fadd.4s	v0, v0, v25
	ldr	q25, [x8, #59136]
	and.16b	v25, v1, v25
	mov.16b	v21, v30
	fmul.4s	v25, v30, v25
	fadd.4s	v3, v3, v25
	ldr	q25, [x8, #59184]
	and.16b	v25, v14, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v4, v4, v25
	ldr	q25, [x8, #59168]
	and.16b	v25, v1, v25
	fmul.4s	v25, v30, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x8, #59216]
	and.16b	v25, v14, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v7, v7, v25
	ldr	q25, [x8, #59200]
	and.16b	v25, v1, v25
	fmul.4s	v25, v30, v25
	fadd.4s	v16, v16, v25
	ldr	q25, [x8, #59248]
	and.16b	v25, v14, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v23, v23, v25
	ldr	q25, [x8, #59232]
	and.16b	v25, v1, v25
	fmul.4s	v25, v30, v25
	fadd.4s	v24, v24, v25
	ldr	q25, [x8, #61184]
	and.16b	v25, v1, v25
	ldr	q2, [sp, #9392]                 ; 16-byte Reload
	fmul.4s	v25, v2, v25
	fadd.4s	v3, v3, v25
	ldr	q25, [x8, #61200]
	and.16b	v25, v14, v25
	ldr	q12, [sp, #8816]                ; 16-byte Reload
	fmul.4s	v25, v12, v25
	fadd.4s	v0, v0, v25
	ldr	q25, [x8, #61216]
	and.16b	v25, v1, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x8, #61232]
	and.16b	v25, v14, v25
	fmul.4s	v25, v12, v25
	fadd.4s	v4, v4, v25
	ldr	q25, [x8, #61248]
	and.16b	v25, v1, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v16, v16, v25
	ldr	q25, [x8, #61264]
	and.16b	v25, v14, v25
	fmul.4s	v25, v12, v25
	fadd.4s	v7, v7, v25
	ldr	q25, [x8, #61280]
	and.16b	v25, v1, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v24, v24, v25
	ldr	q25, [x8, #61296]
	and.16b	v25, v14, v25
	fmul.4s	v25, v12, v25
	fadd.4s	v23, v23, v25
	ldr	q25, [x8, #63248]
	and.16b	v25, v14, v25
	mov.16b	v11, v28
	fmul.4s	v25, v28, v25
	fadd.4s	v0, v0, v25
	ldr	q25, [x8, #63232]
	and.16b	v25, v1, v25
	mov.16b	v18, v26
	fmul.4s	v25, v26, v25
	fadd.4s	v3, v3, v25
	ldr	q25, [x8, #63280]
	and.16b	v25, v14, v25
	fmul.4s	v25, v28, v25
	fadd.4s	v25, v4, v25
	ldr	q4, [x8, #63264]
	and.16b	v4, v1, v4
	fmul.4s	v4, v26, v4
	fadd.4s	v26, v5, v4
	ldr	q4, [x8, #63312]
	and.16b	v4, v14, v4
	fmul.4s	v4, v28, v4
	fadd.4s	v28, v7, v4
	ldr	q4, [x8, #63296]
	and.16b	v4, v1, v4
	fmul.4s	v4, v18, v4
	fadd.4s	v16, v16, v4
	ldr	q4, [x8, #63344]
	and.16b	v4, v14, v4
	fmul.4s	v4, v11, v4
	fadd.4s	v29, v23, v4
	ldr	q4, [x8, #63328]
	and.16b	v4, v1, v4
	fmul.4s	v4, v18, v4
	fadd.4s	v30, v24, v4
	ldr	q4, [x8, #65280]
	and.16b	v4, v1, v4
	ldr	q2, [sp, #10992]                ; 16-byte Reload
	fmul.4s	v4, v2, v4
	fadd.4s	v3, v3, v4
	str	q3, [sp, #4384]                 ; 16-byte Spill
	ldr	q3, [x8, #65296]
	and.16b	v3, v14, v3
	ldr	q4, [sp, #8848]                 ; 16-byte Reload
	fmul.4s	v3, v4, v3
	fadd.4s	v0, v0, v3
	str	q0, [sp, #4368]                 ; 16-byte Spill
	ldr	q0, [x8, #65312]
	and.16b	v0, v1, v0
	fmul.4s	v0, v2, v0
	fadd.4s	v0, v26, v0
	str	q0, [sp, #4352]                 ; 16-byte Spill
	ldr	q0, [x8, #65328]
	and.16b	v0, v14, v0
	fmul.4s	v0, v4, v0
	mov.16b	v26, v4
	fadd.4s	v0, v25, v0
	str	q0, [sp, #4432]                 ; 16-byte Spill
	ldr	q0, [x8, #65344]
	and.16b	v0, v1, v0
	fmul.4s	v0, v2, v0
	fadd.4s	v0, v16, v0
	str	q0, [sp, #4416]                 ; 16-byte Spill
	ldr	q0, [x8, #65360]
	and.16b	v0, v14, v0
	fmul.4s	v0, v4, v0
	fadd.4s	v0, v28, v0
	str	q0, [sp, #4400]                 ; 16-byte Spill
	ldr	q0, [x8, #65376]
	and.16b	v0, v1, v0
	fmul.4s	v0, v2, v0
	fadd.4s	v0, v30, v0
	str	q0, [sp, #4464]                 ; 16-byte Spill
	ldr	q0, [x8, #65392]
	and.16b	v0, v14, v0
	fmul.4s	v0, v4, v0
	fadd.4s	v0, v29, v0
	str	q0, [sp, #4448]                 ; 16-byte Spill
	ldr	q0, [x8, #34704]
	and.16b	v0, v14, v0
	fmul.4s	v0, v8, v0
	ldr	q25, [sp, #6528]                ; 16-byte Reload
	ldr	q7, [sp, #10944]                ; 16-byte Reload
	fmul.4s	v3, v25, v7
	fadd.4s	v4, v3, v0
	ldr	q3, [x8, #34688]
	and.16b	v3, v1, v3
	ldr	q17, [sp, #11008]               ; 16-byte Reload
	fmul.4s	v3, v17, v3
	ldr	q24, [sp, #6512]                ; 16-byte Reload
	fmul.4s	v16, v24, v9
	fadd.4s	v3, v16, v3
	ldr	q16, [x8, #34736]
	and.16b	v16, v14, v16
	fmul.4s	v16, v8, v16
	ldr	q23, [sp, #6560]                ; 16-byte Reload
	fmul.4s	v28, v23, v7
	fadd.4s	v16, v28, v16
	ldr	q28, [x8, #34720]
	and.16b	v28, v1, v28
	fmul.4s	v28, v17, v28
	ldr	q5, [sp, #6544]                 ; 16-byte Reload
	fmul.4s	v29, v5, v9
	fadd.4s	v28, v29, v28
	ldr	q29, [x8, #34768]
	and.16b	v29, v14, v29
	fmul.4s	v29, v8, v29
	ldr	q2, [sp, #6688]                 ; 16-byte Reload
	fmul.4s	v30, v2, v7
	fadd.4s	v29, v30, v29
	ldr	q30, [x8, #34752]
	and.16b	v30, v1, v30
	fmul.4s	v30, v17, v30
	ldr	q2, [sp, #6576]                 ; 16-byte Reload
	fmul.4s	v31, v2, v9
	fadd.4s	v30, v31, v30
	ldr	q31, [x8, #34800]
	and.16b	v31, v14, v31
	fmul.4s	v31, v8, v31
	ldr	q0, [sp, #6704]                 ; 16-byte Reload
	fmul.4s	v8, v0, v7
	fadd.4s	v31, v8, v31
	ldr	q8, [x8, #34784]
	and.16b	v8, v1, v8
	fmul.4s	v8, v17, v8
	ldr	q7, [sp, #6288]                 ; 16-byte Reload
	fmul.4s	v9, v7, v9
	fadd.4s	v8, v9, v8
	ldr	q9, [x8, #36736]
	and.16b	v9, v1, v9
	ldr	q17, [sp, #11168]               ; 16-byte Reload
	fmul.4s	v9, v17, v9
	fadd.4s	v3, v3, v9
	ldr	q9, [x8, #36752]
	and.16b	v9, v14, v9
	ldr	q0, [sp, #11232]                ; 16-byte Reload
	fmul.4s	v9, v0, v9
	fadd.4s	v4, v4, v9
	ldr	q9, [x8, #36768]
	and.16b	v9, v1, v9
	fmul.4s	v9, v17, v9
	fadd.4s	v28, v28, v9
	ldr	q9, [x8, #36784]
	and.16b	v9, v14, v9
	fmul.4s	v9, v0, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x8, #36800]
	and.16b	v9, v1, v9
	fmul.4s	v9, v17, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x8, #36816]
	and.16b	v9, v14, v9
	fmul.4s	v9, v0, v9
	fadd.4s	v29, v29, v9
	ldr	q9, [x8, #36832]
	and.16b	v9, v1, v9
	fmul.4s	v9, v17, v9
	fadd.4s	v8, v8, v9
	ldr	q9, [x8, #36848]
	and.16b	v9, v14, v9
	fmul.4s	v9, v0, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x8, #38800]
	and.16b	v9, v14, v9
	ldr	q0, [sp, #11248]                ; 16-byte Reload
	fmul.4s	v9, v0, v9
	fadd.4s	v4, v4, v9
	ldr	q9, [x8, #38784]
	and.16b	v9, v1, v9
	ldr	q17, [sp, #11184]               ; 16-byte Reload
	fmul.4s	v9, v17, v9
	fadd.4s	v3, v3, v9
	ldr	q9, [x8, #38832]
	and.16b	v9, v14, v9
	fmul.4s	v9, v0, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x8, #38816]
	and.16b	v9, v1, v9
	fmul.4s	v9, v17, v9
	fadd.4s	v28, v28, v9
	ldr	q9, [x8, #38864]
	and.16b	v9, v14, v9
	fmul.4s	v9, v0, v9
	fadd.4s	v29, v29, v9
	ldr	q9, [x8, #38848]
	and.16b	v9, v1, v9
	fmul.4s	v9, v17, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x8, #38896]
	and.16b	v9, v14, v9
	fmul.4s	v9, v0, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x8, #38880]
	and.16b	v9, v1, v9
	fmul.4s	v9, v17, v9
	fadd.4s	v8, v8, v9
	ldr	q9, [x8, #40832]
	and.16b	v9, v1, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v3, v3, v9
	ldr	q9, [x8, #40848]
	and.16b	v9, v14, v9
	ldr	q17, [sp, #11264]               ; 16-byte Reload
	fmul.4s	v9, v17, v9
	fadd.4s	v0, v4, v9
	ldr	q9, [x8, #40864]
	and.16b	v9, v1, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v28, v28, v9
	ldr	q9, [x8, #40880]
	and.16b	v9, v14, v9
	fmul.4s	v9, v17, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x8, #40896]
	and.16b	v9, v1, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x8, #40912]
	and.16b	v9, v14, v9
	fmul.4s	v9, v17, v9
	fadd.4s	v29, v29, v9
	ldr	q9, [x8, #40928]
	and.16b	v9, v1, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v8, v8, v9
	ldr	q9, [x8, #40944]
	and.16b	v9, v14, v9
	fmul.4s	v9, v17, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x8, #42896]
	and.16b	v9, v14, v9
	ldr	q6, [sp, #11200]                ; 16-byte Reload
	fmul.4s	v9, v6, v9
	fadd.4s	v0, v0, v9
	ldr	q9, [x8, #42880]
	and.16b	v9, v1, v9
	ldr	q17, [sp, #11280]               ; 16-byte Reload
	fmul.4s	v9, v17, v9
	fadd.4s	v3, v3, v9
	ldr	q9, [x8, #42928]
	and.16b	v9, v14, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x8, #42912]
	and.16b	v9, v1, v9
	fmul.4s	v9, v17, v9
	fadd.4s	v28, v28, v9
	ldr	q9, [x8, #42960]
	and.16b	v9, v14, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v29, v29, v9
	ldr	q9, [x8, #42944]
	and.16b	v9, v1, v9
	fmul.4s	v9, v17, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x8, #42992]
	and.16b	v9, v14, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x8, #42976]
	and.16b	v9, v1, v9
	fmul.4s	v9, v17, v9
	fadd.4s	v8, v8, v9
	ldr	q9, [x8, #44928]
	and.16b	v9, v1, v9
	ldr	q4, [sp, #11216]                ; 16-byte Reload
	fmul.4s	v9, v4, v9
	fadd.4s	v3, v3, v9
	ldr	q9, [x8, #44944]
	and.16b	v9, v14, v9
	fmul.4s	v9, v15, v9
	fadd.4s	v0, v0, v9
	ldr	q9, [x8, #44960]
	and.16b	v9, v1, v9
	fmul.4s	v9, v4, v9
	fadd.4s	v28, v28, v9
	ldr	q9, [x8, #44976]
	and.16b	v9, v14, v9
	fmul.4s	v9, v15, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x8, #44992]
	and.16b	v9, v1, v9
	fmul.4s	v9, v4, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x8, #45008]
	and.16b	v9, v14, v9
	fmul.4s	v9, v15, v9
	fadd.4s	v29, v29, v9
	ldr	q9, [x8, #45024]
	and.16b	v9, v1, v9
	fmul.4s	v9, v4, v9
	fadd.4s	v8, v8, v9
	ldr	q9, [x8, #45040]
	and.16b	v9, v14, v9
	fmul.4s	v9, v15, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x8, #46992]
	and.16b	v9, v14, v9
	ldr	q6, [sp, #11136]                ; 16-byte Reload
	fmul.4s	v9, v6, v9
	fadd.4s	v0, v0, v9
	ldr	q9, [x8, #46976]
	and.16b	v9, v1, v9
	fmul.4s	v9, v19, v9
	fadd.4s	v3, v3, v9
	ldr	q9, [x8, #47024]
	and.16b	v9, v14, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x8, #47008]
	and.16b	v9, v1, v9
	fmul.4s	v9, v19, v9
	fadd.4s	v28, v28, v9
	ldr	q9, [x8, #47056]
	and.16b	v9, v14, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v29, v29, v9
	ldr	q9, [x8, #47040]
	and.16b	v9, v1, v9
	fmul.4s	v9, v19, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x8, #47088]
	and.16b	v9, v14, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x8, #47072]
	and.16b	v9, v1, v9
	fmul.4s	v9, v19, v9
	fadd.4s	v8, v8, v9
	ldr	q9, [x8, #49024]
	and.16b	v9, v1, v9
	ldr	q6, [sp, #11152]                ; 16-byte Reload
	fmul.4s	v9, v6, v9
	fadd.4s	v3, v3, v9
	ldr	q9, [x8, #49040]
	and.16b	v9, v14, v9
	fmul.4s	v9, v13, v9
	fadd.4s	v0, v0, v9
	ldr	q9, [x8, #49056]
	and.16b	v9, v1, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v28, v28, v9
	ldr	q9, [x8, #49072]
	and.16b	v9, v14, v9
	fmul.4s	v9, v13, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x8, #49088]
	and.16b	v9, v1, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x8, #49104]
	and.16b	v9, v14, v9
	fmul.4s	v9, v13, v9
	fadd.4s	v29, v29, v9
	ldr	q9, [x8, #49120]
	and.16b	v9, v1, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v8, v8, v9
	ldr	q9, [x8, #49136]
	and.16b	v9, v14, v9
	fmul.4s	v9, v13, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x8, #51088]
	and.16b	v9, v14, v9
	ldr	q6, [sp, #11040]                ; 16-byte Reload
	fmul.4s	v9, v6, v9
	fadd.4s	v0, v0, v9
	ldr	q9, [x8, #51072]
	and.16b	v9, v1, v9
	fmul.4s	v9, v20, v9
	fadd.4s	v3, v3, v9
	ldr	q9, [x8, #51120]
	and.16b	v9, v14, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x8, #51104]
	and.16b	v9, v1, v9
	fmul.4s	v9, v20, v9
	fadd.4s	v28, v28, v9
	ldr	q9, [x8, #51152]
	and.16b	v9, v14, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v29, v29, v9
	ldr	q9, [x8, #51136]
	and.16b	v9, v1, v9
	fmul.4s	v9, v20, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x8, #51184]
	and.16b	v9, v14, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x8, #51168]
	and.16b	v9, v1, v9
	fmul.4s	v9, v20, v9
	fadd.4s	v8, v8, v9
	ldr	q9, [x8, #53120]
	and.16b	v9, v1, v9
	ldr	q6, [sp, #11104]                ; 16-byte Reload
	fmul.4s	v9, v6, v9
	fadd.4s	v3, v3, v9
	ldr	q9, [x8, #53136]
	and.16b	v9, v14, v9
	fmul.4s	v9, v22, v9
	fadd.4s	v0, v0, v9
	ldr	q9, [x8, #53152]
	and.16b	v9, v1, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v28, v28, v9
	ldr	q9, [x8, #53168]
	and.16b	v9, v14, v9
	fmul.4s	v9, v22, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x8, #53184]
	and.16b	v9, v1, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x8, #53200]
	and.16b	v9, v14, v9
	fmul.4s	v9, v22, v9
	fadd.4s	v29, v29, v9
	ldr	q9, [x8, #53216]
	and.16b	v9, v1, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v8, v8, v9
	ldr	q9, [x8, #53232]
	and.16b	v9, v14, v9
	fmul.4s	v9, v22, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x8, #55184]
	and.16b	v9, v14, v9
	ldr	q6, [sp, #11072]                ; 16-byte Reload
	fmul.4s	v9, v6, v9
	fadd.4s	v0, v0, v9
	ldr	q9, [x8, #55168]
	and.16b	v9, v1, v9
	fmul.4s	v9, v27, v9
	fadd.4s	v3, v3, v9
	ldr	q9, [x8, #55216]
	and.16b	v9, v14, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x8, #55200]
	and.16b	v9, v1, v9
	fmul.4s	v9, v27, v9
	fadd.4s	v28, v28, v9
	ldr	q9, [x8, #55248]
	and.16b	v9, v14, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v29, v29, v9
	ldr	q9, [x8, #55232]
	and.16b	v9, v1, v9
	fmul.4s	v9, v27, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x8, #55280]
	and.16b	v9, v14, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x8, #55264]
	and.16b	v9, v1, v9
	fmul.4s	v9, v27, v9
	fadd.4s	v8, v8, v9
	ldr	q9, [x8, #57216]
	and.16b	v9, v1, v9
	fmul.4s	v9, v10, v9
	fadd.4s	v3, v3, v9
	ldr	q9, [x8, #57232]
	and.16b	v9, v14, v9
	ldr	q4, [sp, #8768]                 ; 16-byte Reload
	fmul.4s	v9, v4, v9
	fadd.4s	v0, v0, v9
	ldr	q9, [x8, #57248]
	and.16b	v9, v1, v9
	fmul.4s	v9, v10, v9
	fadd.4s	v28, v28, v9
	ldr	q9, [x8, #57264]
	and.16b	v9, v14, v9
	fmul.4s	v9, v4, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x8, #57280]
	and.16b	v9, v1, v9
	fmul.4s	v9, v10, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x8, #57296]
	and.16b	v9, v14, v9
	fmul.4s	v9, v4, v9
	fadd.4s	v29, v29, v9
	ldr	q9, [x8, #57312]
	and.16b	v9, v1, v9
	fmul.4s	v9, v10, v9
	fadd.4s	v8, v8, v9
	ldr	q9, [x8, #57328]
	and.16b	v9, v14, v9
	fmul.4s	v9, v4, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x8, #59280]
	and.16b	v9, v14, v9
	ldr	q6, [sp, #10960]                ; 16-byte Reload
	fmul.4s	v9, v6, v9
	fadd.4s	v0, v0, v9
	ldr	q9, [x8, #59264]
	and.16b	v9, v1, v9
	fmul.4s	v9, v21, v9
	fadd.4s	v3, v3, v9
	ldr	q9, [x8, #59312]
	and.16b	v9, v14, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x8, #59296]
	and.16b	v9, v1, v9
	fmul.4s	v9, v21, v9
	fadd.4s	v28, v28, v9
	ldr	q9, [x8, #59344]
	and.16b	v9, v14, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v29, v29, v9
	ldr	q9, [x8, #59328]
	and.16b	v9, v1, v9
	fmul.4s	v9, v21, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x8, #59376]
	and.16b	v9, v14, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x8, #59360]
	and.16b	v9, v1, v9
	fmul.4s	v9, v21, v9
	fadd.4s	v8, v8, v9
	ldr	q9, [x8, #61312]
	and.16b	v9, v1, v9
	ldr	q6, [sp, #9392]                 ; 16-byte Reload
	fmul.4s	v9, v6, v9
	fadd.4s	v3, v3, v9
	ldr	q9, [x8, #61328]
	and.16b	v9, v14, v9
	fmul.4s	v9, v12, v9
	fadd.4s	v0, v0, v9
	ldr	q9, [x8, #61344]
	and.16b	v9, v1, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v28, v28, v9
	ldr	q9, [x8, #61360]
	and.16b	v9, v14, v9
	fmul.4s	v9, v12, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x8, #61376]
	and.16b	v9, v1, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x8, #61392]
	and.16b	v9, v14, v9
	fmul.4s	v9, v12, v9
	fadd.4s	v29, v29, v9
	ldr	q9, [x8, #61408]
	and.16b	v9, v1, v9
	fmul.4s	v9, v6, v9
	fadd.4s	v8, v8, v9
	ldr	q9, [x8, #61424]
	and.16b	v9, v14, v9
	fmul.4s	v9, v12, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x8, #63376]
	and.16b	v9, v14, v9
	fmul.4s	v9, v11, v9
	fadd.4s	v0, v0, v9
	ldr	q9, [x8, #63360]
	and.16b	v9, v1, v9
	fmul.4s	v9, v18, v9
	fadd.4s	v3, v3, v9
	ldr	q9, [x8, #63408]
	and.16b	v9, v14, v9
	fmul.4s	v9, v11, v9
	fadd.4s	v9, v16, v9
	ldr	q16, [x8, #63392]
	and.16b	v16, v1, v16
	fmul.4s	v16, v18, v16
	fadd.4s	v28, v28, v16
	ldr	q16, [x8, #63440]
	and.16b	v16, v14, v16
	fmul.4s	v16, v11, v16
	fadd.4s	v10, v29, v16
	ldr	q16, [x8, #63424]
	and.16b	v16, v1, v16
	fmul.4s	v16, v18, v16
	fadd.4s	v30, v30, v16
	ldr	q16, [x8, #63472]
	and.16b	v16, v14, v16
	fmul.4s	v16, v11, v16
	fadd.4s	v12, v31, v16
	ldr	q16, [x8, #63456]
	and.16b	v16, v1, v16
	fmul.4s	v16, v18, v16
	fadd.4s	v8, v8, v16
	ldr	q16, [x8, #65408]
	and.16b	v16, v1, v16
	ldr	q19, [sp, #10992]               ; 16-byte Reload
	fmul.4s	v16, v19, v16
	fadd.4s	v3, v3, v16
	ldr	q16, [x8, #65424]
	and.16b	v16, v14, v16
	fmul.4s	v16, v26, v16
	fadd.4s	v16, v0, v16
	ldr	q0, [x8, #65440]
	and.16b	v0, v1, v0
	fmul.4s	v0, v19, v0
	fadd.4s	v28, v28, v0
	ldr	q0, [x8, #65456]
	and.16b	v0, v14, v0
	fmul.4s	v0, v26, v0
	fadd.4s	v29, v9, v0
	ldr	q0, [x8, #65472]
	and.16b	v0, v1, v0
	fmul.4s	v0, v19, v0
	fadd.4s	v30, v30, v0
	ldr	q0, [x8, #65488]
	and.16b	v0, v14, v0
	fmul.4s	v0, v26, v0
	fadd.4s	v31, v10, v0
	ldr	q0, [x8, #65504]
	and.16b	v0, v1, v0
	fmul.4s	v0, v19, v0
	fadd.4s	v8, v8, v0
	ldr	q0, [x8, #65520]
	and.16b	v0, v14, v0
	fmul.4s	v0, v26, v0
	fadd.4s	v9, v12, v0
	ldr	q0, [sp, #8864]                 ; 16-byte Reload
	ldr	q19, [sp, #6224]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #8864]                 ; 16-byte Spill
	ldr	q0, [sp, #8880]                 ; 16-byte Reload
	ldr	q19, [sp, #6208]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #8880]                 ; 16-byte Spill
	ldr	q0, [sp, #8672]                 ; 16-byte Reload
	ldr	q19, [sp, #6656]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #8672]                 ; 16-byte Spill
	ldr	q0, [sp, #8688]                 ; 16-byte Reload
	ldr	q19, [sp, #6672]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #8688]                 ; 16-byte Spill
	ldr	q0, [sp, #6768]                 ; 16-byte Reload
	ldr	q19, [sp, #6624]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #6768]                 ; 16-byte Spill
	ldr	q0, [sp, #6752]                 ; 16-byte Reload
	ldr	q19, [sp, #6640]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #6752]                 ; 16-byte Spill
	ldr	q0, [sp, #6800]                 ; 16-byte Reload
	ldr	q19, [sp, #6592]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #6800]                 ; 16-byte Spill
	ldr	q0, [sp, #6784]                 ; 16-byte Reload
	ldr	q19, [sp, #6608]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #6784]                 ; 16-byte Spill
	ldr	q0, [sp, #6832]                 ; 16-byte Reload
	ldr	q19, [sp, #6176]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #6832]                 ; 16-byte Spill
	ldr	q0, [sp, #6816]                 ; 16-byte Reload
	ldr	q19, [sp, #6192]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #6816]                 ; 16-byte Spill
	ldr	q0, [sp, #6864]                 ; 16-byte Reload
	ldr	q19, [sp, #6144]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #6864]                 ; 16-byte Spill
	ldr	q0, [sp, #6848]                 ; 16-byte Reload
	ldr	q19, [sp, #6160]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #6848]                 ; 16-byte Spill
	ldr	q0, [sp, #6896]                 ; 16-byte Reload
	ldr	q19, [sp, #6112]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #6896]                 ; 16-byte Spill
	ldr	q0, [sp, #6880]                 ; 16-byte Reload
	ldr	q19, [sp, #6128]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #6880]                 ; 16-byte Spill
	ldr	q0, [sp, #6928]                 ; 16-byte Reload
	ldr	q19, [sp, #6080]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #6928]                 ; 16-byte Spill
	ldr	q0, [sp, #6912]                 ; 16-byte Reload
	ldr	q19, [sp, #6096]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #6912]                 ; 16-byte Spill
	ldr	q0, [sp, #6960]                 ; 16-byte Reload
	ldr	q19, [sp, #6048]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #6960]                 ; 16-byte Spill
	ldr	q0, [sp, #6944]                 ; 16-byte Reload
	ldr	q19, [sp, #6064]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #6944]                 ; 16-byte Spill
	ldr	q0, [sp, #6992]                 ; 16-byte Reload
	ldr	q19, [sp, #6016]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #6992]                 ; 16-byte Spill
	ldr	q0, [sp, #6976]                 ; 16-byte Reload
	ldr	q19, [sp, #6032]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #6976]                 ; 16-byte Spill
	ldr	q0, [sp, #7024]                 ; 16-byte Reload
	ldr	q19, [sp, #5984]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7024]                 ; 16-byte Spill
	ldr	q0, [sp, #7008]                 ; 16-byte Reload
	ldr	q19, [sp, #6000]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7008]                 ; 16-byte Spill
	ldr	q0, [sp, #7056]                 ; 16-byte Reload
	ldr	q19, [sp, #5952]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7056]                 ; 16-byte Spill
	ldr	q0, [sp, #7040]                 ; 16-byte Reload
	ldr	q19, [sp, #5968]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7040]                 ; 16-byte Spill
	ldr	q0, [sp, #7088]                 ; 16-byte Reload
	ldr	q19, [sp, #5920]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7088]                 ; 16-byte Spill
	ldr	q0, [sp, #7072]                 ; 16-byte Reload
	ldr	q19, [sp, #5936]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7072]                 ; 16-byte Spill
	ldr	q0, [sp, #7120]                 ; 16-byte Reload
	ldr	q19, [sp, #5888]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7120]                 ; 16-byte Spill
	ldr	q0, [sp, #7104]                 ; 16-byte Reload
	ldr	q19, [sp, #5904]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7104]                 ; 16-byte Spill
	ldr	q0, [sp, #7152]                 ; 16-byte Reload
	ldr	q19, [sp, #5856]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7152]                 ; 16-byte Spill
	ldr	q0, [sp, #7136]                 ; 16-byte Reload
	ldr	q19, [sp, #5872]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7136]                 ; 16-byte Spill
	ldr	q0, [sp, #7184]                 ; 16-byte Reload
	ldr	q19, [sp, #5824]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7184]                 ; 16-byte Spill
	ldr	q0, [sp, #7168]                 ; 16-byte Reload
	ldr	q19, [sp, #5840]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7168]                 ; 16-byte Spill
	ldr	q0, [sp, #7216]                 ; 16-byte Reload
	ldr	q19, [sp, #5792]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7216]                 ; 16-byte Spill
	ldr	q0, [sp, #7200]                 ; 16-byte Reload
	ldr	q19, [sp, #5808]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7200]                 ; 16-byte Spill
	ldr	q0, [sp, #7248]                 ; 16-byte Reload
	ldr	q19, [sp, #5760]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7248]                 ; 16-byte Spill
	ldr	q0, [sp, #7232]                 ; 16-byte Reload
	ldr	q19, [sp, #5776]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7232]                 ; 16-byte Spill
	ldr	q0, [sp, #7280]                 ; 16-byte Reload
	ldr	q19, [sp, #5728]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7280]                 ; 16-byte Spill
	ldr	q0, [sp, #7264]                 ; 16-byte Reload
	ldr	q19, [sp, #5744]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7264]                 ; 16-byte Spill
	ldr	q0, [sp, #7312]                 ; 16-byte Reload
	ldr	q19, [sp, #5696]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7312]                 ; 16-byte Spill
	ldr	q0, [sp, #7296]                 ; 16-byte Reload
	ldr	q19, [sp, #5712]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7296]                 ; 16-byte Spill
	ldr	q0, [sp, #7344]                 ; 16-byte Reload
	ldr	q19, [sp, #5664]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7344]                 ; 16-byte Spill
	ldr	q0, [sp, #7328]                 ; 16-byte Reload
	ldr	q19, [sp, #5680]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7328]                 ; 16-byte Spill
	ldr	q0, [sp, #7376]                 ; 16-byte Reload
	ldr	q19, [sp, #5632]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7376]                 ; 16-byte Spill
	ldr	q0, [sp, #7360]                 ; 16-byte Reload
	ldr	q19, [sp, #5648]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7360]                 ; 16-byte Spill
	ldr	q0, [sp, #7408]                 ; 16-byte Reload
	ldr	q19, [sp, #5600]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7408]                 ; 16-byte Spill
	ldr	q0, [sp, #7392]                 ; 16-byte Reload
	ldr	q19, [sp, #5616]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7392]                 ; 16-byte Spill
	ldr	q0, [sp, #7440]                 ; 16-byte Reload
	ldr	q19, [sp, #5568]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7440]                 ; 16-byte Spill
	ldr	q0, [sp, #7424]                 ; 16-byte Reload
	ldr	q19, [sp, #5584]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7424]                 ; 16-byte Spill
	ldr	q0, [sp, #7472]                 ; 16-byte Reload
	ldr	q19, [sp, #5536]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7472]                 ; 16-byte Spill
	ldr	q0, [sp, #7456]                 ; 16-byte Reload
	ldr	q19, [sp, #5552]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7456]                 ; 16-byte Spill
	ldr	q0, [sp, #7504]                 ; 16-byte Reload
	ldr	q19, [sp, #5504]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7504]                 ; 16-byte Spill
	ldr	q0, [sp, #7488]                 ; 16-byte Reload
	ldr	q19, [sp, #5520]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7488]                 ; 16-byte Spill
	ldr	q0, [sp, #7536]                 ; 16-byte Reload
	ldr	q19, [sp, #5472]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7536]                 ; 16-byte Spill
	ldr	q0, [sp, #7520]                 ; 16-byte Reload
	ldr	q19, [sp, #5488]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7520]                 ; 16-byte Spill
	ldr	q0, [sp, #7568]                 ; 16-byte Reload
	ldr	q19, [sp, #5440]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7568]                 ; 16-byte Spill
	ldr	q0, [sp, #7552]                 ; 16-byte Reload
	ldr	q19, [sp, #5456]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7552]                 ; 16-byte Spill
	ldr	q0, [sp, #7600]                 ; 16-byte Reload
	ldr	q19, [sp, #5408]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7600]                 ; 16-byte Spill
	ldr	q0, [sp, #7584]                 ; 16-byte Reload
	ldr	q19, [sp, #5424]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7584]                 ; 16-byte Spill
	ldr	q0, [sp, #7632]                 ; 16-byte Reload
	ldr	q19, [sp, #5376]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7632]                 ; 16-byte Spill
	ldr	q0, [sp, #7616]                 ; 16-byte Reload
	ldr	q19, [sp, #5392]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7616]                 ; 16-byte Spill
	ldr	q0, [sp, #7664]                 ; 16-byte Reload
	ldr	q19, [sp, #5344]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7664]                 ; 16-byte Spill
	ldr	q0, [sp, #7648]                 ; 16-byte Reload
	ldr	q19, [sp, #5360]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7648]                 ; 16-byte Spill
	ldr	q0, [sp, #7696]                 ; 16-byte Reload
	ldr	q19, [sp, #5312]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7696]                 ; 16-byte Spill
	ldr	q0, [sp, #7680]                 ; 16-byte Reload
	ldr	q19, [sp, #5328]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7680]                 ; 16-byte Spill
	ldr	q0, [sp, #7728]                 ; 16-byte Reload
	ldr	q19, [sp, #5280]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7728]                 ; 16-byte Spill
	ldr	q0, [sp, #7712]                 ; 16-byte Reload
	ldr	q19, [sp, #5296]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7712]                 ; 16-byte Spill
	ldr	q0, [sp, #7760]                 ; 16-byte Reload
	ldr	q19, [sp, #5248]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7760]                 ; 16-byte Spill
	ldr	q0, [sp, #7744]                 ; 16-byte Reload
	ldr	q19, [sp, #5264]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7744]                 ; 16-byte Spill
	ldr	q0, [sp, #7792]                 ; 16-byte Reload
	ldr	q19, [sp, #5216]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7792]                 ; 16-byte Spill
	ldr	q0, [sp, #7776]                 ; 16-byte Reload
	ldr	q19, [sp, #5232]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7776]                 ; 16-byte Spill
	ldr	q0, [sp, #7824]                 ; 16-byte Reload
	ldr	q19, [sp, #5184]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7824]                 ; 16-byte Spill
	ldr	q0, [sp, #7808]                 ; 16-byte Reload
	ldr	q19, [sp, #5200]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7808]                 ; 16-byte Spill
	ldr	q0, [sp, #7856]                 ; 16-byte Reload
	ldr	q19, [sp, #5152]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7856]                 ; 16-byte Spill
	ldr	q0, [sp, #7840]                 ; 16-byte Reload
	ldr	q19, [sp, #5168]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7840]                 ; 16-byte Spill
	ldr	q0, [sp, #7888]                 ; 16-byte Reload
	ldr	q19, [sp, #5120]                ; 16-byte Reload
	bit.16b	v0, v19, v14
	str	q0, [sp, #7888]                 ; 16-byte Spill
	ldr	q0, [sp, #7872]                 ; 16-byte Reload
	ldr	q19, [sp, #5136]                ; 16-byte Reload
	bit.16b	v0, v19, v1
	str	q0, [sp, #7872]                 ; 16-byte Spill
	ldr	q0, [sp, #7920]                 ; 16-byte Reload
	ldr	q17, [sp, #5088]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #7920]                 ; 16-byte Spill
	ldr	q0, [sp, #7904]                 ; 16-byte Reload
	ldr	q17, [sp, #5104]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #7904]                 ; 16-byte Spill
	ldr	q0, [sp, #7952]                 ; 16-byte Reload
	ldr	q17, [sp, #5056]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #7952]                 ; 16-byte Spill
	ldr	q0, [sp, #7936]                 ; 16-byte Reload
	ldr	q17, [sp, #5072]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #7936]                 ; 16-byte Spill
	ldr	q0, [sp, #7984]                 ; 16-byte Reload
	ldr	q17, [sp, #5024]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #7984]                 ; 16-byte Spill
	ldr	q0, [sp, #7968]                 ; 16-byte Reload
	ldr	q17, [sp, #5040]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #7968]                 ; 16-byte Spill
	ldr	q0, [sp, #8016]                 ; 16-byte Reload
	ldr	q17, [sp, #4992]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #8016]                 ; 16-byte Spill
	ldr	q0, [sp, #8000]                 ; 16-byte Reload
	ldr	q17, [sp, #5008]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #8000]                 ; 16-byte Spill
	ldr	q0, [sp, #8048]                 ; 16-byte Reload
	ldr	q17, [sp, #4960]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #8048]                 ; 16-byte Spill
	ldr	q0, [sp, #8032]                 ; 16-byte Reload
	ldr	q17, [sp, #4976]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #8032]                 ; 16-byte Spill
	ldr	q0, [sp, #8080]                 ; 16-byte Reload
	ldr	q17, [sp, #4928]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #8080]                 ; 16-byte Spill
	ldr	q0, [sp, #8064]                 ; 16-byte Reload
	ldr	q17, [sp, #4944]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #8064]                 ; 16-byte Spill
	ldr	q0, [sp, #8112]                 ; 16-byte Reload
	ldr	q17, [sp, #4896]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #8112]                 ; 16-byte Spill
	ldr	q0, [sp, #8096]                 ; 16-byte Reload
	ldr	q17, [sp, #4912]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #8096]                 ; 16-byte Spill
	ldr	q0, [sp, #8144]                 ; 16-byte Reload
	ldr	q17, [sp, #4864]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #8144]                 ; 16-byte Spill
	ldr	q0, [sp, #8128]                 ; 16-byte Reload
	ldr	q17, [sp, #4880]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #8128]                 ; 16-byte Spill
	ldr	q0, [sp, #8176]                 ; 16-byte Reload
	ldr	q17, [sp, #4832]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #8176]                 ; 16-byte Spill
	ldr	q0, [sp, #8160]                 ; 16-byte Reload
	ldr	q17, [sp, #4848]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #8160]                 ; 16-byte Spill
	ldr	q0, [sp, #8208]                 ; 16-byte Reload
	ldr	q17, [sp, #4800]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #8208]                 ; 16-byte Spill
	ldr	q0, [sp, #8192]                 ; 16-byte Reload
	ldr	q17, [sp, #4816]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #8192]                 ; 16-byte Spill
	ldr	q0, [sp, #8240]                 ; 16-byte Reload
	ldr	q17, [sp, #4768]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #8240]                 ; 16-byte Spill
	ldr	q0, [sp, #8224]                 ; 16-byte Reload
	ldr	q17, [sp, #4784]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #8224]                 ; 16-byte Spill
	ldr	q0, [sp, #8272]                 ; 16-byte Reload
	ldr	q17, [sp, #4736]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #8272]                 ; 16-byte Spill
	ldr	q0, [sp, #8256]                 ; 16-byte Reload
	ldr	q17, [sp, #4752]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #8256]                 ; 16-byte Spill
	ldr	q0, [sp, #8304]                 ; 16-byte Reload
	ldr	q17, [sp, #4704]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #8304]                 ; 16-byte Spill
	ldr	q0, [sp, #8288]                 ; 16-byte Reload
	ldr	q17, [sp, #4720]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #8288]                 ; 16-byte Spill
	ldr	q0, [sp, #8336]                 ; 16-byte Reload
	ldr	q17, [sp, #4672]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #8336]                 ; 16-byte Spill
	ldr	q0, [sp, #8320]                 ; 16-byte Reload
	ldr	q17, [sp, #4688]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #8320]                 ; 16-byte Spill
	ldr	q0, [sp, #8368]                 ; 16-byte Reload
	ldr	q17, [sp, #4640]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #8368]                 ; 16-byte Spill
	ldr	q0, [sp, #8352]                 ; 16-byte Reload
	ldr	q17, [sp, #4656]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #8352]                 ; 16-byte Spill
	ldr	q0, [sp, #8400]                 ; 16-byte Reload
	ldr	q17, [sp, #4608]                ; 16-byte Reload
	bit.16b	v0, v17, v14
	str	q0, [sp, #8400]                 ; 16-byte Spill
	ldr	q0, [sp, #8384]                 ; 16-byte Reload
	ldr	q17, [sp, #4624]                ; 16-byte Reload
	bit.16b	v0, v17, v1
	str	q0, [sp, #8384]                 ; 16-byte Spill
	ldr	q0, [sp, #8432]                 ; 16-byte Reload
	ldr	q6, [sp, #4576]                 ; 16-byte Reload
	bit.16b	v0, v6, v14
	str	q0, [sp, #8432]                 ; 16-byte Spill
	ldr	q0, [sp, #8416]                 ; 16-byte Reload
	ldr	q6, [sp, #4592]                 ; 16-byte Reload
	bit.16b	v0, v6, v1
	str	q0, [sp, #8416]                 ; 16-byte Spill
	ldr	q0, [sp, #8464]                 ; 16-byte Reload
	ldr	q6, [sp, #4544]                 ; 16-byte Reload
	bit.16b	v0, v6, v14
	str	q0, [sp, #8464]                 ; 16-byte Spill
	ldr	q0, [sp, #8448]                 ; 16-byte Reload
	ldr	q6, [sp, #4560]                 ; 16-byte Reload
	bit.16b	v0, v6, v1
	str	q0, [sp, #8448]                 ; 16-byte Spill
	ldr	q0, [sp, #8496]                 ; 16-byte Reload
	ldr	q6, [sp, #4512]                 ; 16-byte Reload
	bit.16b	v0, v6, v14
	str	q0, [sp, #8496]                 ; 16-byte Spill
	ldr	q0, [sp, #8480]                 ; 16-byte Reload
	ldr	q6, [sp, #4528]                 ; 16-byte Reload
	bit.16b	v0, v6, v1
	str	q0, [sp, #8480]                 ; 16-byte Spill
	ldr	q0, [sp, #8528]                 ; 16-byte Reload
	ldr	q6, [sp, #4480]                 ; 16-byte Reload
	bit.16b	v0, v6, v14
	str	q0, [sp, #8528]                 ; 16-byte Spill
	ldr	q0, [sp, #8512]                 ; 16-byte Reload
	ldr	q6, [sp, #4496]                 ; 16-byte Reload
	bit.16b	v0, v6, v1
	str	q0, [sp, #8512]                 ; 16-byte Spill
	ldr	q0, [sp, #8560]                 ; 16-byte Reload
	ldr	q6, [sp, #4368]                 ; 16-byte Reload
	bit.16b	v0, v6, v14
	str	q0, [sp, #8560]                 ; 16-byte Spill
	ldr	q0, [sp, #8544]                 ; 16-byte Reload
	ldr	q6, [sp, #4384]                 ; 16-byte Reload
	bit.16b	v0, v6, v1
	str	q0, [sp, #8544]                 ; 16-byte Spill
	ldr	q0, [sp, #8592]                 ; 16-byte Reload
	ldr	q6, [sp, #4432]                 ; 16-byte Reload
	bit.16b	v0, v6, v14
	str	q0, [sp, #8592]                 ; 16-byte Spill
	ldr	q0, [sp, #8576]                 ; 16-byte Reload
	ldr	q6, [sp, #4352]                 ; 16-byte Reload
	bit.16b	v0, v6, v1
	str	q0, [sp, #8576]                 ; 16-byte Spill
	ldr	q0, [sp, #8624]                 ; 16-byte Reload
	ldr	q6, [sp, #4400]                 ; 16-byte Reload
	bit.16b	v0, v6, v14
	str	q0, [sp, #8624]                 ; 16-byte Spill
	ldr	q10, [sp, #6688]                ; 16-byte Reload
	ldr	q0, [sp, #8608]                 ; 16-byte Reload
	ldr	q6, [sp, #4416]                 ; 16-byte Reload
	bit.16b	v0, v6, v1
	str	q0, [sp, #8608]                 ; 16-byte Spill
	ldr	q27, [sp, #6704]                ; 16-byte Reload
	ldr	q0, [sp, #8656]                 ; 16-byte Reload
	ldr	q6, [sp, #4448]                 ; 16-byte Reload
	bit.16b	v0, v6, v14
	str	q0, [sp, #8656]                 ; 16-byte Spill
	ldr	q0, [sp, #8640]                 ; 16-byte Reload
	ldr	q6, [sp, #4464]                 ; 16-byte Reload
	bit.16b	v0, v6, v1
	str	q0, [sp, #8640]                 ; 16-byte Spill
	bit.16b	v25, v16, v14
	str	q25, [sp, #6528]                ; 16-byte Spill
	bit.16b	v24, v3, v1
	str	q24, [sp, #6512]                ; 16-byte Spill
	bit.16b	v23, v29, v14
	str	q23, [sp, #6560]                ; 16-byte Spill
	bit.16b	v5, v28, v1
	str	q5, [sp, #6544]                 ; 16-byte Spill
	bit.16b	v10, v31, v14
	bit.16b	v2, v30, v1
	str	q2, [sp, #6576]                 ; 16-byte Spill
	bit.16b	v27, v9, v14
	bsl.16b	v1, v8, v7
	add	x9, x9, #1
	ldr	q3, [sp, #6240]                 ; 16-byte Reload
	ldr	q21, [sp, #6256]                ; 16-byte Reload
	cmp	x9, #128
	ldr	q0, [sp, #4304]                 ; 16-byte Reload
	ldr	q18, [sp, #4288]                ; 16-byte Reload
	ldr	q22, [sp, #4272]                ; 16-byte Reload
	ldr	q16, [sp, #4256]                ; 16-byte Reload
	ldr	q7, [sp, #4240]                 ; 16-byte Reload
	ldr	q17, [sp, #4224]                ; 16-byte Reload
	ldr	q19, [sp, #4208]                ; 16-byte Reload
	ldr	q20, [sp, #6272]                ; 16-byte Reload
	b.ne	LBB0_579
; %bb.618:                              ; %direct.false
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q2, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v2, v2, #0
	ldr	q19, [sp, #8672]                ; 16-byte Reload
	ldr	q3, [sp, #6752]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	ldr	q4, [sp, #2048]                 ; 16-byte Reload
	and.16b	v4, v2, v4
	ldr	x10, [sp, #8]                   ; 8-byte Reload
	dup.2d	v2, x10
	add.2d	v4, v2, v4
	ldr	q5, [sp, #2032]                 ; 16-byte Reload
	tbnz	w9, #0, LBB0_1642
; %bb.619:                              ; %else3312
	ldr	q16, [sp, #4320]                ; 16-byte Reload
	and.16b	v6, v16, v5
	ldr	q7, [sp, #4336]                 ; 16-byte Reload
	tbnz	w8, #1, LBB0_1643
LBB0_620:                               ; %else3315
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1644
LBB0_621:                               ; %else3318
	and.16b	v5, v5, v18
	tbnz	w8, #3, LBB0_1645
LBB0_622:                               ; %else3321
	ldr	q17, [sp, #8688]                ; 16-byte Reload
	ldr	q3, [sp, #6768]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1646
LBB0_623:                               ; %else3324
	and.16b	v5, v7, v22
	tbnz	w8, #5, LBB0_1647
LBB0_624:                               ; %else3327
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1648
LBB0_625:                               ; %else3330
	tbz	w8, #7, LBB0_627
LBB0_626:                               ; %cond.store3331
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_627:                               ; %else3333
	ldr	q3, [sp, #6784]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #2016]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1649
; %bb.628:                              ; %else3338
	ldr	q5, [sp, #4064]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1650
LBB0_629:                               ; %else3342
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1651
LBB0_630:                               ; %else3346
	ldr	q6, [sp, #4048]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1652
LBB0_631:                               ; %else3350
	ldr	q3, [sp, #6800]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1653
LBB0_632:                               ; %else3354
	ldr	q5, [sp, #2000]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1654
LBB0_633:                               ; %else3358
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1655
LBB0_634:                               ; %else3362
	tbz	w8, #7, LBB0_636
LBB0_635:                               ; %cond.store3363
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_636:                               ; %else3366
	ldr	q3, [sp, #6816]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1984]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1656
; %bb.637:                              ; %else3371
	ldr	q5, [sp, #4032]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1657
LBB0_638:                               ; %else3375
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1658
LBB0_639:                               ; %else3379
	ldr	q6, [sp, #4016]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1659
LBB0_640:                               ; %else3383
	ldr	q3, [sp, #6832]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1660
LBB0_641:                               ; %else3387
	ldr	q5, [sp, #1968]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1661
LBB0_642:                               ; %else3391
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1662
LBB0_643:                               ; %else3395
	tbz	w8, #7, LBB0_645
LBB0_644:                               ; %cond.store3396
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_645:                               ; %else3399
	ldr	q3, [sp, #6848]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1952]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1663
; %bb.646:                              ; %else3404
	ldr	q5, [sp, #4000]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1664
LBB0_647:                               ; %else3408
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1665
LBB0_648:                               ; %else3412
	ldr	q6, [sp, #3984]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1666
LBB0_649:                               ; %else3416
	ldr	q3, [sp, #6864]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1667
LBB0_650:                               ; %else3420
	ldr	q5, [sp, #1936]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1668
LBB0_651:                               ; %else3424
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1669
LBB0_652:                               ; %else3428
	tbz	w8, #7, LBB0_654
LBB0_653:                               ; %cond.store3429
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_654:                               ; %else3432
	ldr	q3, [sp, #6880]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1920]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1670
; %bb.655:                              ; %else3437
	ldr	q5, [sp, #3968]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1671
LBB0_656:                               ; %else3441
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1672
LBB0_657:                               ; %else3445
	ldr	q6, [sp, #3952]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1673
LBB0_658:                               ; %else3449
	ldr	q3, [sp, #6896]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1674
LBB0_659:                               ; %else3453
	ldr	q5, [sp, #1904]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1675
LBB0_660:                               ; %else3457
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1676
LBB0_661:                               ; %else3461
	tbz	w8, #7, LBB0_663
LBB0_662:                               ; %cond.store3462
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_663:                               ; %else3465
	ldr	q3, [sp, #6912]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1888]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1677
; %bb.664:                              ; %else3470
	ldr	q5, [sp, #3936]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1678
LBB0_665:                               ; %else3474
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1679
LBB0_666:                               ; %else3478
	ldr	q6, [sp, #3920]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1680
LBB0_667:                               ; %else3482
	ldr	q3, [sp, #6928]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1681
LBB0_668:                               ; %else3486
	ldr	q5, [sp, #1872]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1682
LBB0_669:                               ; %else3490
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1683
LBB0_670:                               ; %else3494
	tbz	w8, #7, LBB0_672
LBB0_671:                               ; %cond.store3495
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_672:                               ; %else3498
	ldr	q3, [sp, #6944]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1856]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1684
; %bb.673:                              ; %else3503
	ldr	q5, [sp, #3904]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1685
LBB0_674:                               ; %else3507
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1686
LBB0_675:                               ; %else3511
	ldr	q6, [sp, #3888]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1687
LBB0_676:                               ; %else3515
	ldr	q3, [sp, #6960]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1688
LBB0_677:                               ; %else3519
	ldr	q5, [sp, #1840]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1689
LBB0_678:                               ; %else3523
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1690
LBB0_679:                               ; %else3527
	tbz	w8, #7, LBB0_681
LBB0_680:                               ; %cond.store3528
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_681:                               ; %else3531
	ldr	q3, [sp, #6976]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1824]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1691
; %bb.682:                              ; %else3536
	ldr	q5, [sp, #3872]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1692
LBB0_683:                               ; %else3540
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1693
LBB0_684:                               ; %else3544
	ldr	q6, [sp, #3856]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1694
LBB0_685:                               ; %else3548
	ldr	q3, [sp, #6992]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1695
LBB0_686:                               ; %else3552
	ldr	q5, [sp, #1808]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1696
LBB0_687:                               ; %else3556
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1697
LBB0_688:                               ; %else3560
	tbz	w8, #7, LBB0_690
LBB0_689:                               ; %cond.store3561
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_690:                               ; %else3564
	ldr	q3, [sp, #7008]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1792]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1698
; %bb.691:                              ; %else3569
	ldr	q5, [sp, #3840]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1699
LBB0_692:                               ; %else3573
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1700
LBB0_693:                               ; %else3577
	ldr	q6, [sp, #3824]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1701
LBB0_694:                               ; %else3581
	ldr	q3, [sp, #7024]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1702
LBB0_695:                               ; %else3585
	ldr	q5, [sp, #1776]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1703
LBB0_696:                               ; %else3589
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1704
LBB0_697:                               ; %else3593
	tbz	w8, #7, LBB0_699
LBB0_698:                               ; %cond.store3594
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_699:                               ; %else3597
	ldr	q3, [sp, #7040]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1760]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1705
; %bb.700:                              ; %else3602
	ldr	q5, [sp, #3808]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1706
LBB0_701:                               ; %else3606
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1707
LBB0_702:                               ; %else3610
	ldr	q6, [sp, #3792]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1708
LBB0_703:                               ; %else3614
	ldr	q3, [sp, #7056]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1709
LBB0_704:                               ; %else3618
	ldr	q5, [sp, #1744]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1710
LBB0_705:                               ; %else3622
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1711
LBB0_706:                               ; %else3626
	tbz	w8, #7, LBB0_708
LBB0_707:                               ; %cond.store3627
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_708:                               ; %else3630
	ldr	q3, [sp, #7072]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1728]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1712
; %bb.709:                              ; %else3635
	ldr	q5, [sp, #3776]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1713
LBB0_710:                               ; %else3639
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1714
LBB0_711:                               ; %else3643
	ldr	q6, [sp, #3760]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1715
LBB0_712:                               ; %else3647
	ldr	q3, [sp, #7088]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1716
LBB0_713:                               ; %else3651
	ldr	q5, [sp, #1712]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1717
LBB0_714:                               ; %else3655
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1718
LBB0_715:                               ; %else3659
	tbz	w8, #7, LBB0_717
LBB0_716:                               ; %cond.store3660
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_717:                               ; %else3663
	ldr	q3, [sp, #7104]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1696]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1719
; %bb.718:                              ; %else3668
	ldr	q5, [sp, #3744]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1720
LBB0_719:                               ; %else3672
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1721
LBB0_720:                               ; %else3676
	ldr	q6, [sp, #3728]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1722
LBB0_721:                               ; %else3680
	ldr	q3, [sp, #7120]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1723
LBB0_722:                               ; %else3684
	ldr	q5, [sp, #1680]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1724
LBB0_723:                               ; %else3688
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1725
LBB0_724:                               ; %else3692
	tbz	w8, #7, LBB0_726
LBB0_725:                               ; %cond.store3693
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_726:                               ; %else3696
	ldr	q3, [sp, #7136]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1664]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1726
; %bb.727:                              ; %else3701
	ldr	q5, [sp, #3712]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1727
LBB0_728:                               ; %else3705
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1728
LBB0_729:                               ; %else3709
	ldr	q6, [sp, #3696]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1729
LBB0_730:                               ; %else3713
	ldr	q3, [sp, #7152]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1730
LBB0_731:                               ; %else3717
	ldr	q5, [sp, #1648]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1731
LBB0_732:                               ; %else3721
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1732
LBB0_733:                               ; %else3725
	tbz	w8, #7, LBB0_735
LBB0_734:                               ; %cond.store3726
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_735:                               ; %else3729
	ldr	q3, [sp, #7168]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1632]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1733
; %bb.736:                              ; %else3734
	ldr	q5, [sp, #3680]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1734
LBB0_737:                               ; %else3738
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1735
LBB0_738:                               ; %else3742
	ldr	q6, [sp, #3664]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1736
LBB0_739:                               ; %else3746
	ldr	q3, [sp, #7184]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1737
LBB0_740:                               ; %else3750
	ldr	q5, [sp, #1616]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1738
LBB0_741:                               ; %else3754
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1739
LBB0_742:                               ; %else3758
	tbz	w8, #7, LBB0_744
LBB0_743:                               ; %cond.store3759
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_744:                               ; %else3762
	ldr	q3, [sp, #7200]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1600]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1740
; %bb.745:                              ; %else3767
	ldr	q5, [sp, #3648]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1741
LBB0_746:                               ; %else3771
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1742
LBB0_747:                               ; %else3775
	ldr	q6, [sp, #3632]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1743
LBB0_748:                               ; %else3779
	ldr	q3, [sp, #7216]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1744
LBB0_749:                               ; %else3783
	ldr	q5, [sp, #1584]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1745
LBB0_750:                               ; %else3787
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1746
LBB0_751:                               ; %else3791
	tbz	w8, #7, LBB0_753
LBB0_752:                               ; %cond.store3792
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_753:                               ; %else3795
	ldr	q3, [sp, #7232]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1568]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1747
; %bb.754:                              ; %else3800
	ldr	q5, [sp, #3616]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1748
LBB0_755:                               ; %else3804
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1749
LBB0_756:                               ; %else3808
	ldr	q6, [sp, #3600]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1750
LBB0_757:                               ; %else3812
	ldr	q3, [sp, #7248]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1751
LBB0_758:                               ; %else3816
	ldr	q5, [sp, #1552]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1752
LBB0_759:                               ; %else3820
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1753
LBB0_760:                               ; %else3824
	tbz	w8, #7, LBB0_762
LBB0_761:                               ; %cond.store3825
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_762:                               ; %else3828
	ldr	q3, [sp, #7264]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1536]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1754
; %bb.763:                              ; %else3833
	ldr	q5, [sp, #3584]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1755
LBB0_764:                               ; %else3837
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1756
LBB0_765:                               ; %else3841
	ldr	q6, [sp, #3568]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1757
LBB0_766:                               ; %else3845
	ldr	q3, [sp, #7280]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1758
LBB0_767:                               ; %else3849
	ldr	q5, [sp, #1520]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1759
LBB0_768:                               ; %else3853
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1760
LBB0_769:                               ; %else3857
	tbz	w8, #7, LBB0_771
LBB0_770:                               ; %cond.store3858
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_771:                               ; %else3861
	ldr	q3, [sp, #7296]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1504]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1761
; %bb.772:                              ; %else3866
	ldr	q5, [sp, #3552]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1762
LBB0_773:                               ; %else3870
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1763
LBB0_774:                               ; %else3874
	ldr	q6, [sp, #3536]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1764
LBB0_775:                               ; %else3878
	ldr	q3, [sp, #7312]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1765
LBB0_776:                               ; %else3882
	ldr	q5, [sp, #1488]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1766
LBB0_777:                               ; %else3886
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1767
LBB0_778:                               ; %else3890
	tbz	w8, #7, LBB0_780
LBB0_779:                               ; %cond.store3891
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_780:                               ; %else3894
	ldr	q3, [sp, #7328]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1472]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1768
; %bb.781:                              ; %else3899
	ldr	q5, [sp, #3520]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1769
LBB0_782:                               ; %else3903
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1770
LBB0_783:                               ; %else3907
	ldr	q6, [sp, #3504]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1771
LBB0_784:                               ; %else3911
	ldr	q3, [sp, #7344]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1772
LBB0_785:                               ; %else3915
	ldr	q5, [sp, #1456]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1773
LBB0_786:                               ; %else3919
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1774
LBB0_787:                               ; %else3923
	tbz	w8, #7, LBB0_789
LBB0_788:                               ; %cond.store3924
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_789:                               ; %else3927
	ldr	q3, [sp, #7360]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1440]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1775
; %bb.790:                              ; %else3932
	ldr	q5, [sp, #3488]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1776
LBB0_791:                               ; %else3936
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1777
LBB0_792:                               ; %else3940
	ldr	q6, [sp, #3472]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1778
LBB0_793:                               ; %else3944
	ldr	q3, [sp, #7376]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1779
LBB0_794:                               ; %else3948
	ldr	q5, [sp, #1424]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1780
LBB0_795:                               ; %else3952
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1781
LBB0_796:                               ; %else3956
	tbz	w8, #7, LBB0_798
LBB0_797:                               ; %cond.store3957
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_798:                               ; %else3960
	ldr	q3, [sp, #7392]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1408]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1782
; %bb.799:                              ; %else3965
	ldr	q5, [sp, #3456]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1783
LBB0_800:                               ; %else3969
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1784
LBB0_801:                               ; %else3973
	ldr	q6, [sp, #3440]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1785
LBB0_802:                               ; %else3977
	ldr	q3, [sp, #7408]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1786
LBB0_803:                               ; %else3981
	ldr	q5, [sp, #1392]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1787
LBB0_804:                               ; %else3985
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1788
LBB0_805:                               ; %else3989
	tbz	w8, #7, LBB0_807
LBB0_806:                               ; %cond.store3990
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_807:                               ; %else3993
	ldr	q3, [sp, #7424]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1376]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1789
; %bb.808:                              ; %else3998
	ldr	q5, [sp, #3424]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1790
LBB0_809:                               ; %else4002
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1791
LBB0_810:                               ; %else4006
	ldr	q6, [sp, #3408]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1792
LBB0_811:                               ; %else4010
	ldr	q3, [sp, #7440]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1793
LBB0_812:                               ; %else4014
	ldr	q5, [sp, #1360]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1794
LBB0_813:                               ; %else4018
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1795
LBB0_814:                               ; %else4022
	tbz	w8, #7, LBB0_816
LBB0_815:                               ; %cond.store4023
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_816:                               ; %else4026
	ldr	q3, [sp, #7456]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1344]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1796
; %bb.817:                              ; %else4031
	ldr	q5, [sp, #3392]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1797
LBB0_818:                               ; %else4035
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1798
LBB0_819:                               ; %else4039
	ldr	q6, [sp, #3376]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1799
LBB0_820:                               ; %else4043
	ldr	q3, [sp, #7472]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1800
LBB0_821:                               ; %else4047
	ldr	q5, [sp, #1328]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1801
LBB0_822:                               ; %else4051
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1802
LBB0_823:                               ; %else4055
	tbz	w8, #7, LBB0_825
LBB0_824:                               ; %cond.store4056
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_825:                               ; %else4059
	ldr	q3, [sp, #7488]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1312]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1803
; %bb.826:                              ; %else4064
	ldr	q5, [sp, #3360]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1804
LBB0_827:                               ; %else4068
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1805
LBB0_828:                               ; %else4072
	ldr	q6, [sp, #3344]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1806
LBB0_829:                               ; %else4076
	ldr	q3, [sp, #7504]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1807
LBB0_830:                               ; %else4080
	ldr	q5, [sp, #1296]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1808
LBB0_831:                               ; %else4084
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1809
LBB0_832:                               ; %else4088
	tbz	w8, #7, LBB0_834
LBB0_833:                               ; %cond.store4089
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_834:                               ; %else4092
	ldr	q3, [sp, #7520]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1280]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1810
; %bb.835:                              ; %else4097
	ldr	q5, [sp, #3328]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1811
LBB0_836:                               ; %else4101
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1812
LBB0_837:                               ; %else4105
	ldr	q6, [sp, #3312]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1813
LBB0_838:                               ; %else4109
	ldr	q3, [sp, #7536]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1814
LBB0_839:                               ; %else4113
	ldr	q5, [sp, #1264]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1815
LBB0_840:                               ; %else4117
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1816
LBB0_841:                               ; %else4121
	tbz	w8, #7, LBB0_843
LBB0_842:                               ; %cond.store4122
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_843:                               ; %else4125
	ldr	q3, [sp, #7552]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1248]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1817
; %bb.844:                              ; %else4130
	ldr	q5, [sp, #3296]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1818
LBB0_845:                               ; %else4134
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1819
LBB0_846:                               ; %else4138
	ldr	q6, [sp, #3280]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1820
LBB0_847:                               ; %else4142
	ldr	q3, [sp, #7568]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1821
LBB0_848:                               ; %else4146
	ldr	q5, [sp, #1232]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1822
LBB0_849:                               ; %else4150
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1823
LBB0_850:                               ; %else4154
	tbz	w8, #7, LBB0_852
LBB0_851:                               ; %cond.store4155
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_852:                               ; %else4158
	ldr	q3, [sp, #7584]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1216]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1824
; %bb.853:                              ; %else4163
	ldr	q5, [sp, #3264]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1825
LBB0_854:                               ; %else4167
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1826
LBB0_855:                               ; %else4171
	ldr	q6, [sp, #3248]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1827
LBB0_856:                               ; %else4175
	ldr	q3, [sp, #7600]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1828
LBB0_857:                               ; %else4179
	ldr	q5, [sp, #1200]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1829
LBB0_858:                               ; %else4183
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1830
LBB0_859:                               ; %else4187
	tbz	w8, #7, LBB0_861
LBB0_860:                               ; %cond.store4188
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_861:                               ; %else4191
	ldr	q3, [sp, #7616]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1184]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1831
; %bb.862:                              ; %else4196
	ldr	q5, [sp, #3232]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1832
LBB0_863:                               ; %else4200
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1833
LBB0_864:                               ; %else4204
	ldr	q6, [sp, #3216]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1834
LBB0_865:                               ; %else4208
	ldr	q3, [sp, #7632]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1835
LBB0_866:                               ; %else4212
	ldr	q5, [sp, #1168]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1836
LBB0_867:                               ; %else4216
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1837
LBB0_868:                               ; %else4220
	tbz	w8, #7, LBB0_870
LBB0_869:                               ; %cond.store4221
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_870:                               ; %else4224
	ldr	q3, [sp, #7648]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1152]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1838
; %bb.871:                              ; %else4229
	ldr	q5, [sp, #3200]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1839
LBB0_872:                               ; %else4233
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1840
LBB0_873:                               ; %else4237
	ldr	q6, [sp, #3184]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1841
LBB0_874:                               ; %else4241
	ldr	q3, [sp, #7664]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1842
LBB0_875:                               ; %else4245
	ldr	q5, [sp, #1136]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1843
LBB0_876:                               ; %else4249
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1844
LBB0_877:                               ; %else4253
	tbz	w8, #7, LBB0_879
LBB0_878:                               ; %cond.store4254
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_879:                               ; %else4257
	ldr	q3, [sp, #7680]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1120]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1845
; %bb.880:                              ; %else4262
	ldr	q5, [sp, #3168]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1846
LBB0_881:                               ; %else4266
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1847
LBB0_882:                               ; %else4270
	ldr	q6, [sp, #3152]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1848
LBB0_883:                               ; %else4274
	ldr	q3, [sp, #7696]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1849
LBB0_884:                               ; %else4278
	ldr	q5, [sp, #1104]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1850
LBB0_885:                               ; %else4282
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1851
LBB0_886:                               ; %else4286
	tbz	w8, #7, LBB0_888
LBB0_887:                               ; %cond.store4287
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_888:                               ; %else4290
	ldr	q3, [sp, #7712]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1088]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1852
; %bb.889:                              ; %else4295
	ldr	q5, [sp, #3136]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1853
LBB0_890:                               ; %else4299
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1854
LBB0_891:                               ; %else4303
	ldr	q6, [sp, #3120]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1855
LBB0_892:                               ; %else4307
	ldr	q3, [sp, #7728]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1856
LBB0_893:                               ; %else4311
	ldr	q5, [sp, #1072]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1857
LBB0_894:                               ; %else4315
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1858
LBB0_895:                               ; %else4319
	tbz	w8, #7, LBB0_897
LBB0_896:                               ; %cond.store4320
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_897:                               ; %else4323
	ldr	q3, [sp, #7744]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1056]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1859
; %bb.898:                              ; %else4328
	ldr	q5, [sp, #3104]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1860
LBB0_899:                               ; %else4332
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1861
LBB0_900:                               ; %else4336
	ldr	q6, [sp, #3088]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1862
LBB0_901:                               ; %else4340
	ldr	q3, [sp, #7760]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1863
LBB0_902:                               ; %else4344
	ldr	q5, [sp, #1040]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1864
LBB0_903:                               ; %else4348
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1865
LBB0_904:                               ; %else4352
	tbz	w8, #7, LBB0_906
LBB0_905:                               ; %cond.store4353
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_906:                               ; %else4356
	ldr	q3, [sp, #7776]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #1024]                 ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1866
; %bb.907:                              ; %else4361
	ldr	q5, [sp, #3072]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1867
LBB0_908:                               ; %else4365
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1868
LBB0_909:                               ; %else4369
	ldr	q6, [sp, #3056]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1869
LBB0_910:                               ; %else4373
	ldr	q3, [sp, #7792]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1870
LBB0_911:                               ; %else4377
	ldr	q5, [sp, #1008]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1871
LBB0_912:                               ; %else4381
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1872
LBB0_913:                               ; %else4385
	tbz	w8, #7, LBB0_915
LBB0_914:                               ; %cond.store4386
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_915:                               ; %else4389
	ldr	q3, [sp, #7808]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #992]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1873
; %bb.916:                              ; %else4394
	ldr	q5, [sp, #3040]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1874
LBB0_917:                               ; %else4398
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1875
LBB0_918:                               ; %else4402
	ldr	q6, [sp, #3024]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1876
LBB0_919:                               ; %else4406
	ldr	q3, [sp, #7824]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1877
LBB0_920:                               ; %else4410
	ldr	q5, [sp, #976]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1878
LBB0_921:                               ; %else4414
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1879
LBB0_922:                               ; %else4418
	tbz	w8, #7, LBB0_924
LBB0_923:                               ; %cond.store4419
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_924:                               ; %else4422
	ldr	q3, [sp, #7840]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #960]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1880
; %bb.925:                              ; %else4427
	ldr	q5, [sp, #3008]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1881
LBB0_926:                               ; %else4431
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1882
LBB0_927:                               ; %else4435
	ldr	q6, [sp, #2992]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1883
LBB0_928:                               ; %else4439
	ldr	q3, [sp, #7856]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1884
LBB0_929:                               ; %else4443
	ldr	q5, [sp, #944]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1885
LBB0_930:                               ; %else4447
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1886
LBB0_931:                               ; %else4451
	tbz	w8, #7, LBB0_933
LBB0_932:                               ; %cond.store4452
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_933:                               ; %else4455
	ldr	q3, [sp, #7872]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #928]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1887
; %bb.934:                              ; %else4460
	ldr	q5, [sp, #2976]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1888
LBB0_935:                               ; %else4464
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1889
LBB0_936:                               ; %else4468
	ldr	q6, [sp, #2960]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1890
LBB0_937:                               ; %else4472
	ldr	q3, [sp, #7888]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1891
LBB0_938:                               ; %else4476
	ldr	q5, [sp, #912]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1892
LBB0_939:                               ; %else4480
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1893
LBB0_940:                               ; %else4484
	tbz	w8, #7, LBB0_942
LBB0_941:                               ; %cond.store4485
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_942:                               ; %else4488
	ldr	q3, [sp, #7904]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #896]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1894
; %bb.943:                              ; %else4493
	ldr	q5, [sp, #2944]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1895
LBB0_944:                               ; %else4497
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1896
LBB0_945:                               ; %else4501
	ldr	q6, [sp, #2928]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1897
LBB0_946:                               ; %else4505
	ldr	q3, [sp, #7920]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1898
LBB0_947:                               ; %else4509
	ldr	q5, [sp, #880]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1899
LBB0_948:                               ; %else4513
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1900
LBB0_949:                               ; %else4517
	tbz	w8, #7, LBB0_951
LBB0_950:                               ; %cond.store4518
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_951:                               ; %else4521
	ldr	q3, [sp, #7936]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #864]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1901
; %bb.952:                              ; %else4526
	ldr	q5, [sp, #2912]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1902
LBB0_953:                               ; %else4530
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1903
LBB0_954:                               ; %else4534
	ldr	q6, [sp, #2896]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1904
LBB0_955:                               ; %else4538
	ldr	q3, [sp, #7952]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1905
LBB0_956:                               ; %else4542
	ldr	q5, [sp, #848]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1906
LBB0_957:                               ; %else4546
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1907
LBB0_958:                               ; %else4550
	tbz	w8, #7, LBB0_960
LBB0_959:                               ; %cond.store4551
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_960:                               ; %else4554
	ldr	q3, [sp, #7968]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #832]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1908
; %bb.961:                              ; %else4559
	ldr	q5, [sp, #2880]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1909
LBB0_962:                               ; %else4563
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1910
LBB0_963:                               ; %else4567
	ldr	q6, [sp, #2864]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1911
LBB0_964:                               ; %else4571
	ldr	q3, [sp, #7984]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1912
LBB0_965:                               ; %else4575
	ldr	q5, [sp, #816]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1913
LBB0_966:                               ; %else4579
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1914
LBB0_967:                               ; %else4583
	tbz	w8, #7, LBB0_969
LBB0_968:                               ; %cond.store4584
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_969:                               ; %else4587
	ldr	q3, [sp, #8000]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #800]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1915
; %bb.970:                              ; %else4592
	ldr	q5, [sp, #2848]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1916
LBB0_971:                               ; %else4596
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1917
LBB0_972:                               ; %else4600
	ldr	q6, [sp, #2832]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1918
LBB0_973:                               ; %else4604
	ldr	q3, [sp, #8016]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1919
LBB0_974:                               ; %else4608
	ldr	q5, [sp, #784]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1920
LBB0_975:                               ; %else4612
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1921
LBB0_976:                               ; %else4616
	tbz	w8, #7, LBB0_978
LBB0_977:                               ; %cond.store4617
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_978:                               ; %else4620
	ldr	q3, [sp, #8032]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #768]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1922
; %bb.979:                              ; %else4625
	ldr	q5, [sp, #2816]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1923
LBB0_980:                               ; %else4629
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1924
LBB0_981:                               ; %else4633
	ldr	q6, [sp, #2800]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1925
LBB0_982:                               ; %else4637
	ldr	q3, [sp, #8048]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1926
LBB0_983:                               ; %else4641
	ldr	q5, [sp, #752]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1927
LBB0_984:                               ; %else4645
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1928
LBB0_985:                               ; %else4649
	tbz	w8, #7, LBB0_987
LBB0_986:                               ; %cond.store4650
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_987:                               ; %else4653
	ldr	q3, [sp, #8064]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #736]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1929
; %bb.988:                              ; %else4658
	ldr	q5, [sp, #2784]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1930
LBB0_989:                               ; %else4662
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1931
LBB0_990:                               ; %else4666
	ldr	q6, [sp, #2768]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1932
LBB0_991:                               ; %else4670
	ldr	q3, [sp, #8080]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1933
LBB0_992:                               ; %else4674
	ldr	q5, [sp, #720]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1934
LBB0_993:                               ; %else4678
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1935
LBB0_994:                               ; %else4682
	tbz	w8, #7, LBB0_996
LBB0_995:                               ; %cond.store4683
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_996:                               ; %else4686
	ldr	q3, [sp, #8096]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #704]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1936
; %bb.997:                              ; %else4691
	ldr	q5, [sp, #2752]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1937
LBB0_998:                               ; %else4695
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1938
LBB0_999:                               ; %else4699
	ldr	q6, [sp, #2736]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1939
LBB0_1000:                              ; %else4703
	ldr	q3, [sp, #8112]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1940
LBB0_1001:                              ; %else4707
	ldr	q5, [sp, #688]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1941
LBB0_1002:                              ; %else4711
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1942
LBB0_1003:                              ; %else4715
	tbz	w8, #7, LBB0_1005
LBB0_1004:                              ; %cond.store4716
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1005:                              ; %else4719
	ldr	q3, [sp, #8128]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #672]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1943
; %bb.1006:                             ; %else4724
	ldr	q5, [sp, #2720]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1944
LBB0_1007:                              ; %else4728
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1945
LBB0_1008:                              ; %else4732
	ldr	q6, [sp, #2704]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1946
LBB0_1009:                              ; %else4736
	ldr	q3, [sp, #8144]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1947
LBB0_1010:                              ; %else4740
	ldr	q5, [sp, #656]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1948
LBB0_1011:                              ; %else4744
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1949
LBB0_1012:                              ; %else4748
	tbz	w8, #7, LBB0_1014
LBB0_1013:                              ; %cond.store4749
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1014:                              ; %else4752
	ldr	q3, [sp, #8160]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #640]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1950
; %bb.1015:                             ; %else4757
	ldr	q5, [sp, #2688]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1951
LBB0_1016:                              ; %else4761
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1952
LBB0_1017:                              ; %else4765
	ldr	q6, [sp, #2672]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1953
LBB0_1018:                              ; %else4769
	ldr	q3, [sp, #8176]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1954
LBB0_1019:                              ; %else4773
	ldr	q5, [sp, #624]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1955
LBB0_1020:                              ; %else4777
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1956
LBB0_1021:                              ; %else4781
	tbz	w8, #7, LBB0_1023
LBB0_1022:                              ; %cond.store4782
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1023:                              ; %else4785
	ldr	q3, [sp, #8192]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #608]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1957
; %bb.1024:                             ; %else4790
	ldr	q5, [sp, #2656]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1958
LBB0_1025:                              ; %else4794
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1959
LBB0_1026:                              ; %else4798
	ldr	q6, [sp, #2640]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1960
LBB0_1027:                              ; %else4802
	ldr	q3, [sp, #8208]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1961
LBB0_1028:                              ; %else4806
	ldr	q5, [sp, #592]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1962
LBB0_1029:                              ; %else4810
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1963
LBB0_1030:                              ; %else4814
	tbz	w8, #7, LBB0_1032
LBB0_1031:                              ; %cond.store4815
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1032:                              ; %else4818
	ldr	q3, [sp, #8224]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #576]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1964
; %bb.1033:                             ; %else4823
	ldr	q5, [sp, #2624]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1965
LBB0_1034:                              ; %else4827
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1966
LBB0_1035:                              ; %else4831
	ldr	q6, [sp, #2608]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1967
LBB0_1036:                              ; %else4835
	ldr	q3, [sp, #8240]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1968
LBB0_1037:                              ; %else4839
	ldr	q5, [sp, #560]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1969
LBB0_1038:                              ; %else4843
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1970
LBB0_1039:                              ; %else4847
	tbz	w8, #7, LBB0_1041
LBB0_1040:                              ; %cond.store4848
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1041:                              ; %else4851
	ldr	q3, [sp, #8256]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #544]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1971
; %bb.1042:                             ; %else4856
	ldr	q5, [sp, #2592]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1972
LBB0_1043:                              ; %else4860
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1973
LBB0_1044:                              ; %else4864
	ldr	q6, [sp, #2576]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1974
LBB0_1045:                              ; %else4868
	ldr	q3, [sp, #8272]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1975
LBB0_1046:                              ; %else4872
	ldr	q5, [sp, #528]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1976
LBB0_1047:                              ; %else4876
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1977
LBB0_1048:                              ; %else4880
	tbz	w8, #7, LBB0_1050
LBB0_1049:                              ; %cond.store4881
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1050:                              ; %else4884
	ldr	q3, [sp, #8288]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #512]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1978
; %bb.1051:                             ; %else4889
	ldr	q5, [sp, #2560]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1979
LBB0_1052:                              ; %else4893
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1980
LBB0_1053:                              ; %else4897
	ldr	q6, [sp, #2544]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1981
LBB0_1054:                              ; %else4901
	ldr	q3, [sp, #8304]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1982
LBB0_1055:                              ; %else4905
	ldr	q5, [sp, #496]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1983
LBB0_1056:                              ; %else4909
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1984
LBB0_1057:                              ; %else4913
	tbz	w8, #7, LBB0_1059
LBB0_1058:                              ; %cond.store4914
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1059:                              ; %else4917
	ldr	q3, [sp, #8320]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #480]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1985
; %bb.1060:                             ; %else4922
	ldr	q5, [sp, #2528]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1986
LBB0_1061:                              ; %else4926
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1987
LBB0_1062:                              ; %else4930
	ldr	q6, [sp, #2512]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1988
LBB0_1063:                              ; %else4934
	ldr	q3, [sp, #8336]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1989
LBB0_1064:                              ; %else4938
	ldr	q5, [sp, #464]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1990
LBB0_1065:                              ; %else4942
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1991
LBB0_1066:                              ; %else4946
	tbz	w8, #7, LBB0_1068
LBB0_1067:                              ; %cond.store4947
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1068:                              ; %else4950
	ldr	q3, [sp, #8352]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #448]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1992
; %bb.1069:                             ; %else4955
	ldr	q5, [sp, #2496]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_1993
LBB0_1070:                              ; %else4959
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_1994
LBB0_1071:                              ; %else4963
	ldr	q6, [sp, #2480]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_1995
LBB0_1072:                              ; %else4967
	ldr	q3, [sp, #8368]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_1996
LBB0_1073:                              ; %else4971
	ldr	q5, [sp, #432]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_1997
LBB0_1074:                              ; %else4975
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_1998
LBB0_1075:                              ; %else4979
	tbz	w8, #7, LBB0_1077
LBB0_1076:                              ; %cond.store4980
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1077:                              ; %else4983
	ldr	q3, [sp, #8384]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #416]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_1999
; %bb.1078:                             ; %else4988
	ldr	q5, [sp, #2464]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_2000
LBB0_1079:                              ; %else4992
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_2001
LBB0_1080:                              ; %else4996
	ldr	q6, [sp, #2448]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_2002
LBB0_1081:                              ; %else5000
	ldr	q3, [sp, #8400]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_2003
LBB0_1082:                              ; %else5004
	ldr	q5, [sp, #400]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_2004
LBB0_1083:                              ; %else5008
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_2005
LBB0_1084:                              ; %else5012
	tbz	w8, #7, LBB0_1086
LBB0_1085:                              ; %cond.store5013
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1086:                              ; %else5016
	ldr	q3, [sp, #8416]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #384]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_2006
; %bb.1087:                             ; %else5021
	ldr	q5, [sp, #2432]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_2007
LBB0_1088:                              ; %else5025
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_2008
LBB0_1089:                              ; %else5029
	ldr	q6, [sp, #2416]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_2009
LBB0_1090:                              ; %else5033
	ldr	q3, [sp, #8432]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_2010
LBB0_1091:                              ; %else5037
	ldr	q5, [sp, #368]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_2011
LBB0_1092:                              ; %else5041
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_2012
LBB0_1093:                              ; %else5045
	tbz	w8, #7, LBB0_1095
LBB0_1094:                              ; %cond.store5046
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1095:                              ; %else5049
	ldr	q3, [sp, #8448]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #352]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_2013
; %bb.1096:                             ; %else5054
	ldr	q5, [sp, #2400]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_2014
LBB0_1097:                              ; %else5058
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_2015
LBB0_1098:                              ; %else5062
	ldr	q6, [sp, #2384]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_2016
LBB0_1099:                              ; %else5066
	ldr	q3, [sp, #8464]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_2017
LBB0_1100:                              ; %else5070
	ldr	q5, [sp, #336]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_2018
LBB0_1101:                              ; %else5074
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_2019
LBB0_1102:                              ; %else5078
	tbz	w8, #7, LBB0_1104
LBB0_1103:                              ; %cond.store5079
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1104:                              ; %else5082
	ldr	q3, [sp, #8480]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #320]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_2020
; %bb.1105:                             ; %else5087
	ldr	q5, [sp, #2368]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_2021
LBB0_1106:                              ; %else5091
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_2022
LBB0_1107:                              ; %else5095
	ldr	q6, [sp, #2352]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_2023
LBB0_1108:                              ; %else5099
	ldr	q3, [sp, #8496]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_2024
LBB0_1109:                              ; %else5103
	ldr	q5, [sp, #304]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_2025
LBB0_1110:                              ; %else5107
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_2026
LBB0_1111:                              ; %else5111
	tbz	w8, #7, LBB0_1113
LBB0_1112:                              ; %cond.store5112
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1113:                              ; %else5115
	ldr	q3, [sp, #8512]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #288]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_2027
; %bb.1114:                             ; %else5120
	ldr	q5, [sp, #2336]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_2028
LBB0_1115:                              ; %else5124
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_2029
LBB0_1116:                              ; %else5128
	ldr	q6, [sp, #2320]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_2030
LBB0_1117:                              ; %else5132
	ldr	q3, [sp, #8528]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_2031
LBB0_1118:                              ; %else5136
	ldr	q5, [sp, #272]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_2032
LBB0_1119:                              ; %else5140
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_2033
LBB0_1120:                              ; %else5144
	tbz	w8, #7, LBB0_1122
LBB0_1121:                              ; %cond.store5145
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1122:                              ; %else5148
	ldr	q3, [sp, #8544]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #256]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_2034
; %bb.1123:                             ; %else5153
	ldr	q5, [sp, #2304]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_2035
LBB0_1124:                              ; %else5157
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_2036
LBB0_1125:                              ; %else5161
	ldr	q6, [sp, #2288]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_2037
LBB0_1126:                              ; %else5165
	ldr	q3, [sp, #8560]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_2038
LBB0_1127:                              ; %else5169
	ldr	q5, [sp, #240]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_2039
LBB0_1128:                              ; %else5173
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_2040
LBB0_1129:                              ; %else5177
	tbz	w8, #7, LBB0_1131
LBB0_1130:                              ; %cond.store5178
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1131:                              ; %else5181
	ldr	q3, [sp, #8576]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #224]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_2041
; %bb.1132:                             ; %else5186
	ldr	q5, [sp, #2272]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_2042
LBB0_1133:                              ; %else5190
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_2043
LBB0_1134:                              ; %else5194
	ldr	q6, [sp, #2256]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_2044
LBB0_1135:                              ; %else5198
	ldr	q3, [sp, #8592]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_2045
LBB0_1136:                              ; %else5202
	ldr	q5, [sp, #208]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_2046
LBB0_1137:                              ; %else5206
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_2047
LBB0_1138:                              ; %else5210
	tbz	w8, #7, LBB0_1140
LBB0_1139:                              ; %cond.store5211
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1140:                              ; %else5214
	ldr	q3, [sp, #8608]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #192]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_2048
; %bb.1141:                             ; %else5219
	ldr	q5, [sp, #2240]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_2049
LBB0_1142:                              ; %else5223
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_2050
LBB0_1143:                              ; %else5227
	ldr	q6, [sp, #2224]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_2051
LBB0_1144:                              ; %else5231
	ldr	q3, [sp, #8624]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_2052
LBB0_1145:                              ; %else5235
	ldr	q5, [sp, #176]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_2053
LBB0_1146:                              ; %else5239
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_2054
LBB0_1147:                              ; %else5243
	tbz	w8, #7, LBB0_1149
LBB0_1148:                              ; %cond.store5244
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1149:                              ; %else5247
	ldr	q3, [sp, #8640]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #160]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_2055
; %bb.1150:                             ; %else5252
	ldr	q5, [sp, #2208]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_2056
LBB0_1151:                              ; %else5256
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_2057
LBB0_1152:                              ; %else5260
	ldr	q6, [sp, #2192]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_2058
LBB0_1153:                              ; %else5264
	ldr	q3, [sp, #8656]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_2059
LBB0_1154:                              ; %else5268
	ldr	q5, [sp, #144]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_2060
LBB0_1155:                              ; %else5272
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_2061
LBB0_1156:                              ; %else5276
	tbz	w8, #7, LBB0_1158
LBB0_1157:                              ; %cond.store5277
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1158:                              ; %else5280
	ldr	q3, [sp, #6512]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #128]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_2062
; %bb.1159:                             ; %else5285
	ldr	q5, [sp, #2176]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_2063
LBB0_1160:                              ; %else5289
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_2064
LBB0_1161:                              ; %else5293
	ldr	q6, [sp, #2160]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_2065
LBB0_1162:                              ; %else5297
	ldr	q3, [sp, #6528]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_2066
LBB0_1163:                              ; %else5301
	ldr	q5, [sp, #112]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_2067
LBB0_1164:                              ; %else5305
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_2068
LBB0_1165:                              ; %else5309
	tbz	w8, #7, LBB0_1167
LBB0_1166:                              ; %cond.store5310
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1167:                              ; %else5313
	ldr	q3, [sp, #6544]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #96]                   ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_2069
; %bb.1168:                             ; %else5318
	ldr	q5, [sp, #2144]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_2070
LBB0_1169:                              ; %else5322
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_2071
LBB0_1170:                              ; %else5326
	ldr	q6, [sp, #2128]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_2072
LBB0_1171:                              ; %else5330
	ldr	q3, [sp, #6560]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_2073
LBB0_1172:                              ; %else5334
	ldr	q5, [sp, #80]                   ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_2074
LBB0_1173:                              ; %else5338
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_2075
LBB0_1174:                              ; %else5342
	tbz	w8, #7, LBB0_1176
LBB0_1175:                              ; %cond.store5343
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1176:                              ; %else5346
	ldr	q3, [sp, #6576]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v4, v4, #0
	ldr	q5, [sp, #64]                   ; 16-byte Reload
	and.16b	v4, v4, v5
	add.2d	v4, v2, v4
	tbnz	w9, #0, LBB0_2076
; %bb.1177:                             ; %else5351
	ldr	q5, [sp, #2112]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbnz	w8, #1, LBB0_2077
LBB0_1178:                              ; %else5355
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbnz	w8, #2, LBB0_2078
LBB0_1179:                              ; %else5359
	ldr	q6, [sp, #2096]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbnz	w8, #3, LBB0_2079
LBB0_1180:                              ; %else5363
	fdiv.4s	v3, v10, v17
	add.2d	v4, v2, v5
	tbnz	w8, #4, LBB0_2080
LBB0_1181:                              ; %else5367
	ldr	q5, [sp, #48]                   ; 16-byte Reload
	and.16b	v5, v7, v5
	tbnz	w8, #5, LBB0_2081
LBB0_1182:                              ; %else5371
	add.2d	v4, v2, v5
	tbnz	w8, #6, LBB0_2082
LBB0_1183:                              ; %else5375
	ldr	q5, [sp, #16]                   ; 16-byte Reload
	tbz	w8, #7, LBB0_1185
LBB0_1184:                              ; %cond.store5376
	mov.d	x8, v4[1]
	st1.s	{ v3 }[3], [x8]
LBB0_1185:                              ; %else5379
	fdiv.4s	v3, v1, v19
	fmov	w9, s0
	and	w8, w9, #0xff
	ldr	q0, [sp, #11312]                ; 16-byte Reload
	sshll.2d	v1, v0, #0
	ldr	q0, [sp, #32]                   ; 16-byte Reload
	and.16b	v1, v1, v0
	add.2d	v1, v2, v1
	tbnz	w9, #0, LBB0_2083
; %bb.1186:                             ; %else5384
	ldr	q0, [sp, #2080]                 ; 16-byte Reload
	and.16b	v4, v16, v0
	tbnz	w8, #1, LBB0_2084
LBB0_1187:                              ; %else5388
	ldr	q0, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v1, v0, #0
	add.2d	v0, v2, v4
	tbnz	w8, #2, LBB0_2085
LBB0_1188:                              ; %else5392
	ldr	q4, [sp, #2064]                 ; 16-byte Reload
	and.16b	v1, v1, v4
	tbnz	w8, #3, LBB0_2086
LBB0_1189:                              ; %else5396
	fdiv.4s	v0, v27, v17
	add.2d	v1, v2, v1
	tbnz	w8, #4, LBB0_2087
LBB0_1190:                              ; %else5400
	and.16b	v3, v7, v5
	tbnz	w8, #5, LBB0_2088
LBB0_1191:                              ; %else5404
	add.2d	v1, v2, v3
	tbnz	w8, #6, LBB0_2089
LBB0_1192:                              ; %else5408
	tbz	w8, #7, LBB0_1194
LBB0_1193:                              ; %cond.store5409
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
LBB0_1194:                              ; %common.ret
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #3280
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB0_1195:                              ; %cond.load
	fmov	x9, d5
	ldr	s6, [x9]
	str	q6, [sp, #9136]                 ; 16-byte Spill
	movi.2d	v6, #0000000000000000
	str	q6, [sp, #10912]                ; 16-byte Spill
	ldr	q1, [sp, #11296]                ; 16-byte Reload
	and.16b	v3, v1, v3
	ushll2.2d	v16, v2, #8
	tbnz	w8, #1, LBB0_1196
	b	LBB0_3
LBB0_1196:                              ; %cond.load202
	mov.d	x9, v5[1]
	ldr	q5, [sp, #9136]                 ; 16-byte Reload
	ld1.s	{ v5 }[1], [x9]
	str	q5, [sp, #9136]                 ; 16-byte Spill
	add.2d	v5, v4, v16
	tbnz	w8, #2, LBB0_1197
	b	LBB0_4
LBB0_1197:                              ; %cond.load205
	fmov	x9, d5
	ldr	q6, [sp, #9136]                 ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #9136]                 ; 16-byte Spill
	ushll.2d	v18, v3, #8
	tbnz	w8, #3, LBB0_1198
	b	LBB0_5
LBB0_1198:                              ; %cond.load208
	mov.d	x9, v5[1]
	ldr	q5, [sp, #9136]                 ; 16-byte Reload
	ld1.s	{ v5 }[3], [x9]
	str	q5, [sp, #9136]                 ; 16-byte Spill
	add.2d	v5, v4, v18
	tbnz	w8, #4, LBB0_1199
	b	LBB0_6
LBB0_1199:                              ; %cond.load211
	fmov	x9, d5
	ldr	q6, [sp, #10912]                ; 16-byte Reload
	ld1.s	{ v6 }[0], [x9]
	str	q6, [sp, #10912]                ; 16-byte Spill
	ushll2.2d	v22, v3, #8
	tbnz	w8, #5, LBB0_1200
	b	LBB0_7
LBB0_1200:                              ; %cond.load214
	mov.d	x9, v5[1]
	ldr	q5, [sp, #10912]                ; 16-byte Reload
	ld1.s	{ v5 }[1], [x9]
	str	q5, [sp, #10912]                ; 16-byte Spill
	add.2d	v5, v4, v22
	tbnz	w8, #6, LBB0_1201
	b	LBB0_8
LBB0_1201:                              ; %cond.load217
	fmov	x9, d5
	ldr	q6, [sp, #10912]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10912]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2090
	b	LBB0_9
LBB0_2090:                              ; %cond.load217
	b	LBB0_10
LBB0_1202:                              ; %cond.load224
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #8736]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10896]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #4064]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1203
	b	LBB0_12
LBB0_1203:                              ; %cond.load230
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8736]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #8736]                 ; 16-byte Spill
	ldr	q6, [sp, #4064]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1204
	b	LBB0_13
LBB0_1204:                              ; %cond.load236
	fmov	x9, d6
	ldr	q19, [sp, #8736]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #8736]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #4048]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1205
	b	LBB0_14
LBB0_1205:                              ; %cond.load242
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8736]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #8736]                 ; 16-byte Spill
	ldr	q6, [sp, #4048]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1206
	b	LBB0_15
LBB0_1206:                              ; %cond.load248
	fmov	x9, d6
	ldr	q19, [sp, #10896]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10896]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1207
	b	LBB0_16
LBB0_1207:                              ; %cond.load254
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10896]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10896]                ; 16-byte Spill
	str	q5, [sp, #2000]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1208
	b	LBB0_17
LBB0_1208:                              ; %cond.load260
	fmov	x9, d5
	ldr	q6, [sp, #10896]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10896]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2091
	b	LBB0_18
LBB0_2091:                              ; %cond.load260
	b	LBB0_19
LBB0_1209:                              ; %cond.load273
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9120]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10880]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #4032]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1210
	b	LBB0_21
LBB0_1210:                              ; %cond.load279
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9120]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9120]                 ; 16-byte Spill
	ldr	q6, [sp, #4032]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1211
	b	LBB0_22
LBB0_1211:                              ; %cond.load285
	fmov	x9, d6
	ldr	q19, [sp, #9120]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9120]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #4016]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1212
	b	LBB0_23
LBB0_1212:                              ; %cond.load291
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9120]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9120]                 ; 16-byte Spill
	ldr	q6, [sp, #4016]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1213
	b	LBB0_24
LBB0_1213:                              ; %cond.load297
	fmov	x9, d6
	ldr	q19, [sp, #10880]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10880]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1214
	b	LBB0_25
LBB0_1214:                              ; %cond.load303
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10880]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10880]                ; 16-byte Spill
	str	q5, [sp, #1968]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1215
	b	LBB0_26
LBB0_1215:                              ; %cond.load309
	fmov	x9, d5
	ldr	q6, [sp, #10880]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10880]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2092
	b	LBB0_27
LBB0_2092:                              ; %cond.load309
	b	LBB0_28
LBB0_1216:                              ; %cond.load322
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9104]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10864]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #4000]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1217
	b	LBB0_30
LBB0_1217:                              ; %cond.load328
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9104]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9104]                 ; 16-byte Spill
	ldr	q6, [sp, #4000]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1218
	b	LBB0_31
LBB0_1218:                              ; %cond.load334
	fmov	x9, d6
	ldr	q19, [sp, #9104]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9104]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3984]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1219
	b	LBB0_32
LBB0_1219:                              ; %cond.load340
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9104]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9104]                 ; 16-byte Spill
	ldr	q6, [sp, #3984]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1220
	b	LBB0_33
LBB0_1220:                              ; %cond.load346
	fmov	x9, d6
	ldr	q19, [sp, #10864]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10864]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1221
	b	LBB0_34
LBB0_1221:                              ; %cond.load352
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10864]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10864]                ; 16-byte Spill
	str	q5, [sp, #1936]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1222
	b	LBB0_35
LBB0_1222:                              ; %cond.load358
	fmov	x9, d5
	ldr	q6, [sp, #10864]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10864]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2093
	b	LBB0_36
LBB0_2093:                              ; %cond.load358
	b	LBB0_37
LBB0_1223:                              ; %cond.load371
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #10112]               ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10848]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3968]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1224
	b	LBB0_39
LBB0_1224:                              ; %cond.load377
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10112]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10112]                ; 16-byte Spill
	ldr	q6, [sp, #3968]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1225
	b	LBB0_40
LBB0_1225:                              ; %cond.load383
	fmov	x9, d6
	ldr	q19, [sp, #10112]               ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #10112]               ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3952]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1226
	b	LBB0_41
LBB0_1226:                              ; %cond.load389
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10112]                ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #10112]                ; 16-byte Spill
	ldr	q6, [sp, #3952]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1227
	b	LBB0_42
LBB0_1227:                              ; %cond.load395
	fmov	x9, d6
	ldr	q19, [sp, #10848]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10848]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1228
	b	LBB0_43
LBB0_1228:                              ; %cond.load401
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10848]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10848]                ; 16-byte Spill
	str	q5, [sp, #1904]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1229
	b	LBB0_44
LBB0_1229:                              ; %cond.load407
	fmov	x9, d5
	ldr	q6, [sp, #10848]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10848]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2094
	b	LBB0_45
LBB0_2094:                              ; %cond.load407
	b	LBB0_46
LBB0_1230:                              ; %cond.load420
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9088]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10832]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3936]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1231
	b	LBB0_48
LBB0_1231:                              ; %cond.load426
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9088]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9088]                 ; 16-byte Spill
	ldr	q6, [sp, #3936]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1232
	b	LBB0_49
LBB0_1232:                              ; %cond.load432
	fmov	x9, d6
	ldr	q19, [sp, #9088]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9088]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3920]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1233
	b	LBB0_50
LBB0_1233:                              ; %cond.load438
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9088]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9088]                 ; 16-byte Spill
	ldr	q6, [sp, #3920]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1234
	b	LBB0_51
LBB0_1234:                              ; %cond.load444
	fmov	x9, d6
	ldr	q19, [sp, #10832]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10832]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1235
	b	LBB0_52
LBB0_1235:                              ; %cond.load450
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10832]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10832]                ; 16-byte Spill
	str	q5, [sp, #1872]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1236
	b	LBB0_53
LBB0_1236:                              ; %cond.load456
	fmov	x9, d5
	ldr	q6, [sp, #10832]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10832]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2095
	b	LBB0_54
LBB0_2095:                              ; %cond.load456
	b	LBB0_55
LBB0_1237:                              ; %cond.load469
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #10096]               ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10816]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3904]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1238
	b	LBB0_57
LBB0_1238:                              ; %cond.load475
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10096]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10096]                ; 16-byte Spill
	ldr	q6, [sp, #3904]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1239
	b	LBB0_58
LBB0_1239:                              ; %cond.load481
	fmov	x9, d6
	ldr	q19, [sp, #10096]               ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #10096]               ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3888]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1240
	b	LBB0_59
LBB0_1240:                              ; %cond.load487
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10096]                ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #10096]                ; 16-byte Spill
	ldr	q6, [sp, #3888]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1241
	b	LBB0_60
LBB0_1241:                              ; %cond.load493
	fmov	x9, d6
	ldr	q19, [sp, #10816]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10816]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1242
	b	LBB0_61
LBB0_1242:                              ; %cond.load499
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10816]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10816]                ; 16-byte Spill
	str	q5, [sp, #1840]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1243
	b	LBB0_62
LBB0_1243:                              ; %cond.load505
	fmov	x9, d5
	ldr	q6, [sp, #10816]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10816]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2096
	b	LBB0_63
LBB0_2096:                              ; %cond.load505
	b	LBB0_64
LBB0_1244:                              ; %cond.load518
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #10080]               ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10800]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3872]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1245
	b	LBB0_66
LBB0_1245:                              ; %cond.load524
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10080]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10080]                ; 16-byte Spill
	ldr	q6, [sp, #3872]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1246
	b	LBB0_67
LBB0_1246:                              ; %cond.load530
	fmov	x9, d6
	ldr	q19, [sp, #10080]               ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #10080]               ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3856]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1247
	b	LBB0_68
LBB0_1247:                              ; %cond.load536
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10080]                ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #10080]                ; 16-byte Spill
	ldr	q6, [sp, #3856]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1248
	b	LBB0_69
LBB0_1248:                              ; %cond.load542
	fmov	x9, d6
	ldr	q19, [sp, #10800]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10800]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1249
	b	LBB0_70
LBB0_1249:                              ; %cond.load548
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10800]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10800]                ; 16-byte Spill
	str	q5, [sp, #1808]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1250
	b	LBB0_71
LBB0_1250:                              ; %cond.load554
	fmov	x9, d5
	ldr	q6, [sp, #10800]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10800]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2097
	b	LBB0_72
LBB0_2097:                              ; %cond.load554
	b	LBB0_73
LBB0_1251:                              ; %cond.load567
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #10064]               ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10784]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3840]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1252
	b	LBB0_75
LBB0_1252:                              ; %cond.load573
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10064]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10064]                ; 16-byte Spill
	ldr	q6, [sp, #3840]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1253
	b	LBB0_76
LBB0_1253:                              ; %cond.load579
	fmov	x9, d6
	ldr	q19, [sp, #10064]               ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #10064]               ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3824]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1254
	b	LBB0_77
LBB0_1254:                              ; %cond.load585
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10064]                ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #10064]                ; 16-byte Spill
	ldr	q6, [sp, #3824]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1255
	b	LBB0_78
LBB0_1255:                              ; %cond.load591
	fmov	x9, d6
	ldr	q19, [sp, #10784]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10784]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1256
	b	LBB0_79
LBB0_1256:                              ; %cond.load597
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10784]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10784]                ; 16-byte Spill
	str	q5, [sp, #1776]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1257
	b	LBB0_80
LBB0_1257:                              ; %cond.load603
	fmov	x9, d5
	ldr	q6, [sp, #10784]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10784]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2098
	b	LBB0_81
LBB0_2098:                              ; %cond.load603
	b	LBB0_82
LBB0_1258:                              ; %cond.load616
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #10048]               ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10768]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3808]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1259
	b	LBB0_84
LBB0_1259:                              ; %cond.load622
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10048]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10048]                ; 16-byte Spill
	ldr	q6, [sp, #3808]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1260
	b	LBB0_85
LBB0_1260:                              ; %cond.load628
	fmov	x9, d6
	ldr	q19, [sp, #10048]               ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #10048]               ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3792]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1261
	b	LBB0_86
LBB0_1261:                              ; %cond.load634
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10048]                ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #10048]                ; 16-byte Spill
	ldr	q6, [sp, #3792]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1262
	b	LBB0_87
LBB0_1262:                              ; %cond.load640
	fmov	x9, d6
	ldr	q19, [sp, #10768]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10768]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1263
	b	LBB0_88
LBB0_1263:                              ; %cond.load646
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10768]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10768]                ; 16-byte Spill
	str	q5, [sp, #1744]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1264
	b	LBB0_89
LBB0_1264:                              ; %cond.load652
	fmov	x9, d5
	ldr	q6, [sp, #10768]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10768]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2099
	b	LBB0_90
LBB0_2099:                              ; %cond.load652
	b	LBB0_91
LBB0_1265:                              ; %cond.load665
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9072]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9360]                ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3776]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1266
	b	LBB0_93
LBB0_1266:                              ; %cond.load671
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9072]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9072]                 ; 16-byte Spill
	ldr	q6, [sp, #3776]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1267
	b	LBB0_94
LBB0_1267:                              ; %cond.load677
	fmov	x9, d6
	ldr	q19, [sp, #9072]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9072]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3760]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1268
	b	LBB0_95
LBB0_1268:                              ; %cond.load683
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9072]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9072]                 ; 16-byte Spill
	ldr	q6, [sp, #3760]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1269
	b	LBB0_96
LBB0_1269:                              ; %cond.load689
	fmov	x9, d6
	ldr	q19, [sp, #9360]                ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #9360]                ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1270
	b	LBB0_97
LBB0_1270:                              ; %cond.load695
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9360]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9360]                 ; 16-byte Spill
	str	q5, [sp, #1712]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1271
	b	LBB0_98
LBB0_1271:                              ; %cond.load701
	fmov	x9, d5
	ldr	q6, [sp, #9360]                 ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #9360]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_2100
	b	LBB0_99
LBB0_2100:                              ; %cond.load701
	b	LBB0_100
LBB0_1272:                              ; %cond.load714
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #10032]               ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9344]                ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3744]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1273
	b	LBB0_102
LBB0_1273:                              ; %cond.load720
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10032]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10032]                ; 16-byte Spill
	ldr	q6, [sp, #3744]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1274
	b	LBB0_103
LBB0_1274:                              ; %cond.load726
	fmov	x9, d6
	ldr	q19, [sp, #10032]               ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #10032]               ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3728]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1275
	b	LBB0_104
LBB0_1275:                              ; %cond.load732
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10032]                ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #10032]                ; 16-byte Spill
	ldr	q6, [sp, #3728]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1276
	b	LBB0_105
LBB0_1276:                              ; %cond.load738
	fmov	x9, d6
	ldr	q19, [sp, #9344]                ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #9344]                ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1277
	b	LBB0_106
LBB0_1277:                              ; %cond.load744
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9344]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9344]                 ; 16-byte Spill
	str	q5, [sp, #1680]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1278
	b	LBB0_107
LBB0_1278:                              ; %cond.load750
	fmov	x9, d5
	ldr	q6, [sp, #9344]                 ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #9344]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_2101
	b	LBB0_108
LBB0_2101:                              ; %cond.load750
	b	LBB0_109
LBB0_1279:                              ; %cond.load763
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9056]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9328]                ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3712]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1280
	b	LBB0_111
LBB0_1280:                              ; %cond.load769
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9056]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9056]                 ; 16-byte Spill
	ldr	q6, [sp, #3712]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1281
	b	LBB0_112
LBB0_1281:                              ; %cond.load775
	fmov	x9, d6
	ldr	q19, [sp, #9056]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9056]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3696]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1282
	b	LBB0_113
LBB0_1282:                              ; %cond.load781
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9056]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9056]                 ; 16-byte Spill
	ldr	q6, [sp, #3696]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1283
	b	LBB0_114
LBB0_1283:                              ; %cond.load787
	fmov	x9, d6
	ldr	q19, [sp, #9328]                ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #9328]                ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1284
	b	LBB0_115
LBB0_1284:                              ; %cond.load793
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9328]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9328]                 ; 16-byte Spill
	str	q5, [sp, #1648]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1285
	b	LBB0_116
LBB0_1285:                              ; %cond.load799
	fmov	x9, d5
	ldr	q6, [sp, #9328]                 ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #9328]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_2102
	b	LBB0_117
LBB0_2102:                              ; %cond.load799
	b	LBB0_118
LBB0_1286:                              ; %cond.load812
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9040]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9312]                ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3680]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1287
	b	LBB0_120
LBB0_1287:                              ; %cond.load818
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9040]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9040]                 ; 16-byte Spill
	ldr	q6, [sp, #3680]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1288
	b	LBB0_121
LBB0_1288:                              ; %cond.load824
	fmov	x9, d6
	ldr	q19, [sp, #9040]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9040]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3664]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1289
	b	LBB0_122
LBB0_1289:                              ; %cond.load830
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9040]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9040]                 ; 16-byte Spill
	ldr	q6, [sp, #3664]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1290
	b	LBB0_123
LBB0_1290:                              ; %cond.load836
	fmov	x9, d6
	ldr	q19, [sp, #9312]                ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #9312]                ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1291
	b	LBB0_124
LBB0_1291:                              ; %cond.load842
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9312]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9312]                 ; 16-byte Spill
	str	q5, [sp, #1616]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1292
	b	LBB0_125
LBB0_1292:                              ; %cond.load848
	fmov	x9, d5
	ldr	q6, [sp, #9312]                 ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #9312]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_2103
	b	LBB0_126
LBB0_2103:                              ; %cond.load848
	b	LBB0_127
LBB0_1293:                              ; %cond.load861
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9024]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9296]                ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3648]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1294
	b	LBB0_129
LBB0_1294:                              ; %cond.load867
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9024]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9024]                 ; 16-byte Spill
	ldr	q6, [sp, #3648]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1295
	b	LBB0_130
LBB0_1295:                              ; %cond.load873
	fmov	x9, d6
	ldr	q19, [sp, #9024]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9024]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3632]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1296
	b	LBB0_131
LBB0_1296:                              ; %cond.load879
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9024]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9024]                 ; 16-byte Spill
	ldr	q6, [sp, #3632]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1297
	b	LBB0_132
LBB0_1297:                              ; %cond.load885
	fmov	x9, d6
	ldr	q19, [sp, #9296]                ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #9296]                ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1298
	b	LBB0_133
LBB0_1298:                              ; %cond.load891
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9296]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9296]                 ; 16-byte Spill
	str	q5, [sp, #1584]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1299
	b	LBB0_134
LBB0_1299:                              ; %cond.load897
	fmov	x9, d5
	ldr	q6, [sp, #9296]                 ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #9296]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_2104
	b	LBB0_135
LBB0_2104:                              ; %cond.load897
	b	LBB0_136
LBB0_1300:                              ; %cond.load910
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9008]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9280]                ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3616]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1301
	b	LBB0_138
LBB0_1301:                              ; %cond.load916
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9008]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9008]                 ; 16-byte Spill
	ldr	q6, [sp, #3616]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1302
	b	LBB0_139
LBB0_1302:                              ; %cond.load922
	fmov	x9, d6
	ldr	q19, [sp, #9008]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9008]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3600]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1303
	b	LBB0_140
LBB0_1303:                              ; %cond.load928
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9008]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9008]                 ; 16-byte Spill
	ldr	q6, [sp, #3600]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1304
	b	LBB0_141
LBB0_1304:                              ; %cond.load934
	fmov	x9, d6
	ldr	q19, [sp, #9280]                ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #9280]                ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1305
	b	LBB0_142
LBB0_1305:                              ; %cond.load940
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9280]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9280]                 ; 16-byte Spill
	str	q5, [sp, #1552]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1306
	b	LBB0_143
LBB0_1306:                              ; %cond.load946
	fmov	x9, d5
	ldr	q6, [sp, #9280]                 ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #9280]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_2105
	b	LBB0_144
LBB0_2105:                              ; %cond.load946
	b	LBB0_145
LBB0_1307:                              ; %cond.load959
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #8992]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9264]                ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3584]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1308
	b	LBB0_147
LBB0_1308:                              ; %cond.load965
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8992]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #8992]                 ; 16-byte Spill
	ldr	q6, [sp, #3584]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1309
	b	LBB0_148
LBB0_1309:                              ; %cond.load971
	fmov	x9, d6
	ldr	q19, [sp, #8992]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #8992]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3568]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1310
	b	LBB0_149
LBB0_1310:                              ; %cond.load977
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8992]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #8992]                 ; 16-byte Spill
	ldr	q6, [sp, #3568]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1311
	b	LBB0_150
LBB0_1311:                              ; %cond.load983
	fmov	x9, d6
	ldr	q19, [sp, #9264]                ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #9264]                ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1312
	b	LBB0_151
LBB0_1312:                              ; %cond.load989
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9264]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9264]                 ; 16-byte Spill
	str	q5, [sp, #1520]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1313
	b	LBB0_152
LBB0_1313:                              ; %cond.load995
	fmov	x9, d5
	ldr	q6, [sp, #9264]                 ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #9264]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_2106
	b	LBB0_153
LBB0_2106:                              ; %cond.load995
	b	LBB0_154
LBB0_1314:                              ; %cond.load1008
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #8976]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9248]                ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3552]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1315
	b	LBB0_156
LBB0_1315:                              ; %cond.load1014
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8976]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #8976]                 ; 16-byte Spill
	ldr	q6, [sp, #3552]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1316
	b	LBB0_157
LBB0_1316:                              ; %cond.load1020
	fmov	x9, d6
	ldr	q19, [sp, #8976]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #8976]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3536]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1317
	b	LBB0_158
LBB0_1317:                              ; %cond.load1026
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8976]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #8976]                 ; 16-byte Spill
	ldr	q6, [sp, #3536]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1318
	b	LBB0_159
LBB0_1318:                              ; %cond.load1032
	fmov	x9, d6
	ldr	q19, [sp, #9248]                ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #9248]                ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1319
	b	LBB0_160
LBB0_1319:                              ; %cond.load1038
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9248]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9248]                 ; 16-byte Spill
	str	q5, [sp, #1488]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1320
	b	LBB0_161
LBB0_1320:                              ; %cond.load1044
	fmov	x9, d5
	ldr	q6, [sp, #9248]                 ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #9248]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_2107
	b	LBB0_162
LBB0_2107:                              ; %cond.load1044
	b	LBB0_163
LBB0_1321:                              ; %cond.load1057
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #8960]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9232]                ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3520]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1322
	b	LBB0_165
LBB0_1322:                              ; %cond.load1063
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8960]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #8960]                 ; 16-byte Spill
	ldr	q6, [sp, #3520]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1323
	b	LBB0_166
LBB0_1323:                              ; %cond.load1069
	fmov	x9, d6
	ldr	q19, [sp, #8960]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #8960]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3504]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1324
	b	LBB0_167
LBB0_1324:                              ; %cond.load1075
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8960]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #8960]                 ; 16-byte Spill
	ldr	q6, [sp, #3504]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1325
	b	LBB0_168
LBB0_1325:                              ; %cond.load1081
	fmov	x9, d6
	ldr	q19, [sp, #9232]                ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #9232]                ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1326
	b	LBB0_169
LBB0_1326:                              ; %cond.load1087
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9232]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9232]                 ; 16-byte Spill
	str	q5, [sp, #1456]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1327
	b	LBB0_170
LBB0_1327:                              ; %cond.load1093
	fmov	x9, d5
	ldr	q6, [sp, #9232]                 ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #9232]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_2108
	b	LBB0_171
LBB0_2108:                              ; %cond.load1093
	b	LBB0_172
LBB0_1328:                              ; %cond.load1106
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #8944]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9216]                ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3488]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1329
	b	LBB0_174
LBB0_1329:                              ; %cond.load1112
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8944]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #8944]                 ; 16-byte Spill
	ldr	q6, [sp, #3488]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1330
	b	LBB0_175
LBB0_1330:                              ; %cond.load1118
	fmov	x9, d6
	ldr	q19, [sp, #8944]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #8944]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3472]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1331
	b	LBB0_176
LBB0_1331:                              ; %cond.load1124
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8944]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #8944]                 ; 16-byte Spill
	ldr	q6, [sp, #3472]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1332
	b	LBB0_177
LBB0_1332:                              ; %cond.load1130
	fmov	x9, d6
	ldr	q19, [sp, #9216]                ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #9216]                ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1333
	b	LBB0_178
LBB0_1333:                              ; %cond.load1136
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9216]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9216]                 ; 16-byte Spill
	str	q5, [sp, #1424]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1334
	b	LBB0_179
LBB0_1334:                              ; %cond.load1142
	fmov	x9, d5
	ldr	q6, [sp, #9216]                 ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #9216]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_2109
	b	LBB0_180
LBB0_2109:                              ; %cond.load1142
	b	LBB0_181
LBB0_1335:                              ; %cond.load1155
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #8720]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9200]                ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3456]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1336
	b	LBB0_183
LBB0_1336:                              ; %cond.load1161
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8720]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #8720]                 ; 16-byte Spill
	ldr	q6, [sp, #3456]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1337
	b	LBB0_184
LBB0_1337:                              ; %cond.load1167
	fmov	x9, d6
	ldr	q19, [sp, #8720]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #8720]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3440]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1338
	b	LBB0_185
LBB0_1338:                              ; %cond.load1173
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8720]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #8720]                 ; 16-byte Spill
	ldr	q6, [sp, #3440]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1339
	b	LBB0_186
LBB0_1339:                              ; %cond.load1179
	fmov	x9, d6
	ldr	q19, [sp, #9200]                ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #9200]                ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1340
	b	LBB0_187
LBB0_1340:                              ; %cond.load1185
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9200]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9200]                 ; 16-byte Spill
	str	q5, [sp, #1392]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1341
	b	LBB0_188
LBB0_1341:                              ; %cond.load1191
	fmov	x9, d5
	ldr	q6, [sp, #9200]                 ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #9200]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_2110
	b	LBB0_189
LBB0_2110:                              ; %cond.load1191
	b	LBB0_190
LBB0_1342:                              ; %cond.load1204
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #10016]               ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9184]                ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3424]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1343
	b	LBB0_192
LBB0_1343:                              ; %cond.load1210
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10016]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10016]                ; 16-byte Spill
	ldr	q6, [sp, #3424]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1344
	b	LBB0_193
LBB0_1344:                              ; %cond.load1216
	fmov	x9, d6
	ldr	q19, [sp, #10016]               ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #10016]               ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3408]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1345
	b	LBB0_194
LBB0_1345:                              ; %cond.load1222
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10016]                ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #10016]                ; 16-byte Spill
	ldr	q6, [sp, #3408]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1346
	b	LBB0_195
LBB0_1346:                              ; %cond.load1228
	fmov	x9, d6
	ldr	q19, [sp, #9184]                ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #9184]                ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1347
	b	LBB0_196
LBB0_1347:                              ; %cond.load1234
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9184]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9184]                 ; 16-byte Spill
	str	q5, [sp, #1360]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1348
	b	LBB0_197
LBB0_1348:                              ; %cond.load1240
	fmov	x9, d5
	ldr	q6, [sp, #9184]                 ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #9184]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_2111
	b	LBB0_198
LBB0_2111:                              ; %cond.load1240
	b	LBB0_199
LBB0_1349:                              ; %cond.load1253
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #8928]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10752]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3392]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1350
	b	LBB0_201
LBB0_1350:                              ; %cond.load1259
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8928]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #8928]                 ; 16-byte Spill
	ldr	q6, [sp, #3392]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1351
	b	LBB0_202
LBB0_1351:                              ; %cond.load1265
	fmov	x9, d6
	ldr	q19, [sp, #8928]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #8928]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3376]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1352
	b	LBB0_203
LBB0_1352:                              ; %cond.load1271
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8928]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #8928]                 ; 16-byte Spill
	ldr	q6, [sp, #3376]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1353
	b	LBB0_204
LBB0_1353:                              ; %cond.load1277
	fmov	x9, d6
	ldr	q19, [sp, #10752]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10752]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1354
	b	LBB0_205
LBB0_1354:                              ; %cond.load1283
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10752]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10752]                ; 16-byte Spill
	str	q5, [sp, #1328]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1355
	b	LBB0_206
LBB0_1355:                              ; %cond.load1289
	fmov	x9, d5
	ldr	q6, [sp, #10752]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10752]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2112
	b	LBB0_207
LBB0_2112:                              ; %cond.load1289
	b	LBB0_208
LBB0_1356:                              ; %cond.load1302
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #10000]               ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #9168]                ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3360]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1357
	b	LBB0_210
LBB0_1357:                              ; %cond.load1308
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10000]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10000]                ; 16-byte Spill
	ldr	q6, [sp, #3360]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1358
	b	LBB0_211
LBB0_1358:                              ; %cond.load1314
	fmov	x9, d6
	ldr	q19, [sp, #10000]               ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #10000]               ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3344]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1359
	b	LBB0_212
LBB0_1359:                              ; %cond.load1320
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10000]                ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #10000]                ; 16-byte Spill
	ldr	q6, [sp, #3344]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1360
	b	LBB0_213
LBB0_1360:                              ; %cond.load1326
	fmov	x9, d6
	ldr	q19, [sp, #9168]                ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #9168]                ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1361
	b	LBB0_214
LBB0_1361:                              ; %cond.load1332
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9168]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9168]                 ; 16-byte Spill
	str	q5, [sp, #1296]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1362
	b	LBB0_215
LBB0_1362:                              ; %cond.load1338
	fmov	x9, d5
	ldr	q6, [sp, #9168]                 ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #9168]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_2113
	b	LBB0_216
LBB0_2113:                              ; %cond.load1338
	b	LBB0_217
LBB0_1363:                              ; %cond.load1351
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #8912]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10736]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3328]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1364
	b	LBB0_219
LBB0_1364:                              ; %cond.load1357
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8912]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #8912]                 ; 16-byte Spill
	ldr	q6, [sp, #3328]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1365
	b	LBB0_220
LBB0_1365:                              ; %cond.load1363
	fmov	x9, d6
	ldr	q19, [sp, #8912]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #8912]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3312]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1366
	b	LBB0_221
LBB0_1366:                              ; %cond.load1369
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8912]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #8912]                 ; 16-byte Spill
	ldr	q6, [sp, #3312]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1367
	b	LBB0_222
LBB0_1367:                              ; %cond.load1375
	fmov	x9, d6
	ldr	q19, [sp, #10736]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10736]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1368
	b	LBB0_223
LBB0_1368:                              ; %cond.load1381
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10736]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10736]                ; 16-byte Spill
	str	q5, [sp, #1264]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1369
	b	LBB0_224
LBB0_1369:                              ; %cond.load1387
	fmov	x9, d5
	ldr	q6, [sp, #10736]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10736]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2114
	b	LBB0_225
LBB0_2114:                              ; %cond.load1387
	b	LBB0_226
LBB0_1370:                              ; %cond.load1400
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9984]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10720]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3296]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1371
	b	LBB0_228
LBB0_1371:                              ; %cond.load1406
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9984]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9984]                 ; 16-byte Spill
	ldr	q6, [sp, #3296]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1372
	b	LBB0_229
LBB0_1372:                              ; %cond.load1412
	fmov	x9, d6
	ldr	q19, [sp, #9984]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9984]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3280]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1373
	b	LBB0_230
LBB0_1373:                              ; %cond.load1418
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9984]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9984]                 ; 16-byte Spill
	ldr	q6, [sp, #3280]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1374
	b	LBB0_231
LBB0_1374:                              ; %cond.load1424
	fmov	x9, d6
	ldr	q19, [sp, #10720]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10720]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1375
	b	LBB0_232
LBB0_1375:                              ; %cond.load1430
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10720]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10720]                ; 16-byte Spill
	str	q5, [sp, #1232]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1376
	b	LBB0_233
LBB0_1376:                              ; %cond.load1436
	fmov	x9, d5
	ldr	q6, [sp, #10720]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10720]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2115
	b	LBB0_234
LBB0_2115:                              ; %cond.load1436
	b	LBB0_235
LBB0_1377:                              ; %cond.load1449
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9968]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10704]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3264]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1378
	b	LBB0_237
LBB0_1378:                              ; %cond.load1455
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9968]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9968]                 ; 16-byte Spill
	ldr	q6, [sp, #3264]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1379
	b	LBB0_238
LBB0_1379:                              ; %cond.load1461
	fmov	x9, d6
	ldr	q19, [sp, #9968]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9968]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3248]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1380
	b	LBB0_239
LBB0_1380:                              ; %cond.load1467
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9968]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9968]                 ; 16-byte Spill
	ldr	q6, [sp, #3248]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1381
	b	LBB0_240
LBB0_1381:                              ; %cond.load1473
	fmov	x9, d6
	ldr	q19, [sp, #10704]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10704]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1382
	b	LBB0_241
LBB0_1382:                              ; %cond.load1479
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10704]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10704]                ; 16-byte Spill
	str	q5, [sp, #1200]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1383
	b	LBB0_242
LBB0_1383:                              ; %cond.load1485
	fmov	x9, d5
	ldr	q6, [sp, #10704]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10704]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2116
	b	LBB0_243
LBB0_2116:                              ; %cond.load1485
	b	LBB0_244
LBB0_1384:                              ; %cond.load1498
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9952]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10688]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3232]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1385
	b	LBB0_246
LBB0_1385:                              ; %cond.load1504
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9952]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9952]                 ; 16-byte Spill
	ldr	q6, [sp, #3232]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1386
	b	LBB0_247
LBB0_1386:                              ; %cond.load1510
	fmov	x9, d6
	ldr	q19, [sp, #9952]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9952]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3216]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1387
	b	LBB0_248
LBB0_1387:                              ; %cond.load1516
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9952]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9952]                 ; 16-byte Spill
	ldr	q6, [sp, #3216]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1388
	b	LBB0_249
LBB0_1388:                              ; %cond.load1522
	fmov	x9, d6
	ldr	q19, [sp, #10688]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10688]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1389
	b	LBB0_250
LBB0_1389:                              ; %cond.load1528
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10688]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10688]                ; 16-byte Spill
	str	q5, [sp, #1168]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1390
	b	LBB0_251
LBB0_1390:                              ; %cond.load1534
	fmov	x9, d5
	ldr	q6, [sp, #10688]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10688]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2117
	b	LBB0_252
LBB0_2117:                              ; %cond.load1534
	b	LBB0_253
LBB0_1391:                              ; %cond.load1547
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9936]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10672]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3200]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1392
	b	LBB0_255
LBB0_1392:                              ; %cond.load1553
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9936]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9936]                 ; 16-byte Spill
	ldr	q6, [sp, #3200]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1393
	b	LBB0_256
LBB0_1393:                              ; %cond.load1559
	fmov	x9, d6
	ldr	q19, [sp, #9936]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9936]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3184]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1394
	b	LBB0_257
LBB0_1394:                              ; %cond.load1565
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9936]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9936]                 ; 16-byte Spill
	ldr	q6, [sp, #3184]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1395
	b	LBB0_258
LBB0_1395:                              ; %cond.load1571
	fmov	x9, d6
	ldr	q19, [sp, #10672]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10672]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1396
	b	LBB0_259
LBB0_1396:                              ; %cond.load1577
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10672]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10672]                ; 16-byte Spill
	str	q5, [sp, #1136]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1397
	b	LBB0_260
LBB0_1397:                              ; %cond.load1583
	fmov	x9, d5
	ldr	q6, [sp, #10672]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10672]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2118
	b	LBB0_261
LBB0_2118:                              ; %cond.load1583
	b	LBB0_262
LBB0_1398:                              ; %cond.load1596
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9920]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10656]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3168]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1399
	b	LBB0_264
LBB0_1399:                              ; %cond.load1602
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9920]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9920]                 ; 16-byte Spill
	ldr	q6, [sp, #3168]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1400
	b	LBB0_265
LBB0_1400:                              ; %cond.load1608
	fmov	x9, d6
	ldr	q19, [sp, #9920]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9920]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3152]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1401
	b	LBB0_266
LBB0_1401:                              ; %cond.load1614
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9920]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9920]                 ; 16-byte Spill
	ldr	q6, [sp, #3152]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1402
	b	LBB0_267
LBB0_1402:                              ; %cond.load1620
	fmov	x9, d6
	ldr	q19, [sp, #10656]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10656]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1403
	b	LBB0_268
LBB0_1403:                              ; %cond.load1626
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10656]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10656]                ; 16-byte Spill
	str	q5, [sp, #1104]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1404
	b	LBB0_269
LBB0_1404:                              ; %cond.load1632
	fmov	x9, d5
	ldr	q6, [sp, #10656]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10656]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2119
	b	LBB0_270
LBB0_2119:                              ; %cond.load1632
	b	LBB0_271
LBB0_1405:                              ; %cond.load1645
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9904]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10640]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3136]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1406
	b	LBB0_273
LBB0_1406:                              ; %cond.load1651
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9904]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9904]                 ; 16-byte Spill
	ldr	q6, [sp, #3136]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1407
	b	LBB0_274
LBB0_1407:                              ; %cond.load1657
	fmov	x9, d6
	ldr	q19, [sp, #9904]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9904]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3120]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1408
	b	LBB0_275
LBB0_1408:                              ; %cond.load1663
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9904]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9904]                 ; 16-byte Spill
	ldr	q6, [sp, #3120]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1409
	b	LBB0_276
LBB0_1409:                              ; %cond.load1669
	fmov	x9, d6
	ldr	q19, [sp, #10640]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10640]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1410
	b	LBB0_277
LBB0_1410:                              ; %cond.load1675
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10640]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10640]                ; 16-byte Spill
	str	q5, [sp, #1072]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1411
	b	LBB0_278
LBB0_1411:                              ; %cond.load1681
	fmov	x9, d5
	ldr	q6, [sp, #10640]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10640]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2120
	b	LBB0_279
LBB0_2120:                              ; %cond.load1681
	b	LBB0_280
LBB0_1412:                              ; %cond.load1694
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9888]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10624]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3104]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1413
	b	LBB0_282
LBB0_1413:                              ; %cond.load1700
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9888]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9888]                 ; 16-byte Spill
	ldr	q6, [sp, #3104]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1414
	b	LBB0_283
LBB0_1414:                              ; %cond.load1706
	fmov	x9, d6
	ldr	q19, [sp, #9888]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9888]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3088]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1415
	b	LBB0_284
LBB0_1415:                              ; %cond.load1712
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9888]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9888]                 ; 16-byte Spill
	ldr	q6, [sp, #3088]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1416
	b	LBB0_285
LBB0_1416:                              ; %cond.load1718
	fmov	x9, d6
	ldr	q19, [sp, #10624]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10624]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1417
	b	LBB0_286
LBB0_1417:                              ; %cond.load1724
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10624]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10624]                ; 16-byte Spill
	str	q5, [sp, #1040]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1418
	b	LBB0_287
LBB0_1418:                              ; %cond.load1730
	fmov	x9, d5
	ldr	q6, [sp, #10624]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10624]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2121
	b	LBB0_288
LBB0_2121:                              ; %cond.load1730
	b	LBB0_289
LBB0_1419:                              ; %cond.load1743
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9872]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10608]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3072]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1420
	b	LBB0_291
LBB0_1420:                              ; %cond.load1749
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9872]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9872]                 ; 16-byte Spill
	ldr	q6, [sp, #3072]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1421
	b	LBB0_292
LBB0_1421:                              ; %cond.load1755
	fmov	x9, d6
	ldr	q19, [sp, #9872]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9872]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3056]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1422
	b	LBB0_293
LBB0_1422:                              ; %cond.load1761
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9872]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9872]                 ; 16-byte Spill
	ldr	q6, [sp, #3056]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1423
	b	LBB0_294
LBB0_1423:                              ; %cond.load1767
	fmov	x9, d6
	ldr	q19, [sp, #10608]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10608]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1424
	b	LBB0_295
LBB0_1424:                              ; %cond.load1773
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10608]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10608]                ; 16-byte Spill
	str	q5, [sp, #1008]                 ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1425
	b	LBB0_296
LBB0_1425:                              ; %cond.load1779
	fmov	x9, d5
	ldr	q6, [sp, #10608]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10608]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2122
	b	LBB0_297
LBB0_2122:                              ; %cond.load1779
	b	LBB0_298
LBB0_1426:                              ; %cond.load1792
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9856]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10592]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3040]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1427
	b	LBB0_300
LBB0_1427:                              ; %cond.load1798
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9856]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9856]                 ; 16-byte Spill
	ldr	q6, [sp, #3040]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1428
	b	LBB0_301
LBB0_1428:                              ; %cond.load1804
	fmov	x9, d6
	ldr	q19, [sp, #9856]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9856]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #3024]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1429
	b	LBB0_302
LBB0_1429:                              ; %cond.load1810
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9856]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9856]                 ; 16-byte Spill
	ldr	q6, [sp, #3024]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1430
	b	LBB0_303
LBB0_1430:                              ; %cond.load1816
	fmov	x9, d6
	ldr	q19, [sp, #10592]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10592]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1431
	b	LBB0_304
LBB0_1431:                              ; %cond.load1822
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10592]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10592]                ; 16-byte Spill
	str	q5, [sp, #976]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1432
	b	LBB0_305
LBB0_1432:                              ; %cond.load1828
	fmov	x9, d5
	ldr	q6, [sp, #10592]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10592]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2123
	b	LBB0_306
LBB0_2123:                              ; %cond.load1828
	b	LBB0_307
LBB0_1433:                              ; %cond.load1841
	fmov	x9, d6
	ldr	s19, [x9]
	str	q19, [sp, #9840]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #10576]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #3008]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1434
	b	LBB0_309
LBB0_1434:                              ; %cond.load1847
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9840]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9840]                 ; 16-byte Spill
	ldr	q6, [sp, #3008]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1435
	b	LBB0_310
LBB0_1435:                              ; %cond.load1853
	fmov	x9, d6
	ldr	q19, [sp, #9840]                ; 16-byte Reload
	ld1.s	{ v19 }[2], [x9]
	str	q19, [sp, #9840]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2992]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1436
	b	LBB0_311
LBB0_1436:                              ; %cond.load1859
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9840]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9840]                 ; 16-byte Spill
	ldr	q6, [sp, #2992]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1437
	b	LBB0_312
LBB0_1437:                              ; %cond.load1865
	fmov	x9, d6
	ldr	q19, [sp, #10576]               ; 16-byte Reload
	ld1.s	{ v19 }[0], [x9]
	str	q19, [sp, #10576]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1438
	b	LBB0_313
LBB0_1438:                              ; %cond.load1871
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10576]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10576]                ; 16-byte Spill
	str	q5, [sp, #944]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1439
	b	LBB0_314
LBB0_1439:                              ; %cond.load1877
	fmov	x9, d5
	ldr	q6, [sp, #10576]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10576]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2124
	b	LBB0_315
LBB0_2124:                              ; %cond.load1877
	b	LBB0_316
LBB0_1440:                              ; %cond.load1890
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9824]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10560]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2976]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1441
	b	LBB0_318
LBB0_1441:                              ; %cond.load1896
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9824]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9824]                 ; 16-byte Spill
	ldr	q6, [sp, #2976]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1442
	b	LBB0_319
LBB0_1442:                              ; %cond.load1902
	fmov	x9, d6
	ldr	q17, [sp, #9824]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9824]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2960]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1443
	b	LBB0_320
LBB0_1443:                              ; %cond.load1908
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9824]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9824]                 ; 16-byte Spill
	ldr	q6, [sp, #2960]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1444
	b	LBB0_321
LBB0_1444:                              ; %cond.load1914
	fmov	x9, d6
	ldr	q17, [sp, #10560]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10560]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1445
	b	LBB0_322
LBB0_1445:                              ; %cond.load1920
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10560]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10560]                ; 16-byte Spill
	str	q5, [sp, #912]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1446
	b	LBB0_323
LBB0_1446:                              ; %cond.load1926
	fmov	x9, d5
	ldr	q6, [sp, #10560]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10560]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2125
	b	LBB0_324
LBB0_2125:                              ; %cond.load1926
	b	LBB0_325
LBB0_1447:                              ; %cond.load1939
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9808]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10544]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2944]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1448
	b	LBB0_327
LBB0_1448:                              ; %cond.load1945
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9808]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9808]                 ; 16-byte Spill
	ldr	q6, [sp, #2944]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1449
	b	LBB0_328
LBB0_1449:                              ; %cond.load1951
	fmov	x9, d6
	ldr	q17, [sp, #9808]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9808]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2928]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1450
	b	LBB0_329
LBB0_1450:                              ; %cond.load1957
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9808]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9808]                 ; 16-byte Spill
	ldr	q6, [sp, #2928]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1451
	b	LBB0_330
LBB0_1451:                              ; %cond.load1963
	fmov	x9, d6
	ldr	q17, [sp, #10544]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10544]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1452
	b	LBB0_331
LBB0_1452:                              ; %cond.load1969
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10544]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10544]                ; 16-byte Spill
	str	q5, [sp, #880]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1453
	b	LBB0_332
LBB0_1453:                              ; %cond.load1975
	fmov	x9, d5
	ldr	q6, [sp, #10544]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10544]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2126
	b	LBB0_333
LBB0_2126:                              ; %cond.load1975
	b	LBB0_334
LBB0_1454:                              ; %cond.load1988
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9792]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10528]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2912]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1455
	b	LBB0_336
LBB0_1455:                              ; %cond.load1994
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9792]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9792]                 ; 16-byte Spill
	ldr	q6, [sp, #2912]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1456
	b	LBB0_337
LBB0_1456:                              ; %cond.load2000
	fmov	x9, d6
	ldr	q17, [sp, #9792]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9792]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2896]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1457
	b	LBB0_338
LBB0_1457:                              ; %cond.load2006
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9792]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9792]                 ; 16-byte Spill
	ldr	q6, [sp, #2896]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1458
	b	LBB0_339
LBB0_1458:                              ; %cond.load2012
	fmov	x9, d6
	ldr	q17, [sp, #10528]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10528]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1459
	b	LBB0_340
LBB0_1459:                              ; %cond.load2018
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10528]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10528]                ; 16-byte Spill
	str	q5, [sp, #848]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1460
	b	LBB0_341
LBB0_1460:                              ; %cond.load2024
	fmov	x9, d5
	ldr	q6, [sp, #10528]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10528]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2127
	b	LBB0_342
LBB0_2127:                              ; %cond.load2024
	b	LBB0_343
LBB0_1461:                              ; %cond.load2037
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9776]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10512]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2880]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1462
	b	LBB0_345
LBB0_1462:                              ; %cond.load2043
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9776]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9776]                 ; 16-byte Spill
	ldr	q6, [sp, #2880]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1463
	b	LBB0_346
LBB0_1463:                              ; %cond.load2049
	fmov	x9, d6
	ldr	q17, [sp, #9776]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9776]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2864]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1464
	b	LBB0_347
LBB0_1464:                              ; %cond.load2055
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9776]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9776]                 ; 16-byte Spill
	ldr	q6, [sp, #2864]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1465
	b	LBB0_348
LBB0_1465:                              ; %cond.load2061
	fmov	x9, d6
	ldr	q17, [sp, #10512]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10512]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1466
	b	LBB0_349
LBB0_1466:                              ; %cond.load2067
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10512]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10512]                ; 16-byte Spill
	str	q5, [sp, #816]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1467
	b	LBB0_350
LBB0_1467:                              ; %cond.load2073
	fmov	x9, d5
	ldr	q6, [sp, #10512]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10512]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2128
	b	LBB0_351
LBB0_2128:                              ; %cond.load2073
	b	LBB0_352
LBB0_1468:                              ; %cond.load2086
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9760]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10496]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2848]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1469
	b	LBB0_354
LBB0_1469:                              ; %cond.load2092
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9760]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9760]                 ; 16-byte Spill
	ldr	q6, [sp, #2848]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1470
	b	LBB0_355
LBB0_1470:                              ; %cond.load2098
	fmov	x9, d6
	ldr	q17, [sp, #9760]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9760]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2832]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1471
	b	LBB0_356
LBB0_1471:                              ; %cond.load2104
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9760]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9760]                 ; 16-byte Spill
	ldr	q6, [sp, #2832]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1472
	b	LBB0_357
LBB0_1472:                              ; %cond.load2110
	fmov	x9, d6
	ldr	q17, [sp, #10496]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10496]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1473
	b	LBB0_358
LBB0_1473:                              ; %cond.load2116
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10496]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10496]                ; 16-byte Spill
	str	q5, [sp, #784]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1474
	b	LBB0_359
LBB0_1474:                              ; %cond.load2122
	fmov	x9, d5
	ldr	q6, [sp, #10496]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10496]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2129
	b	LBB0_360
LBB0_2129:                              ; %cond.load2122
	b	LBB0_361
LBB0_1475:                              ; %cond.load2135
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9744]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10480]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2816]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1476
	b	LBB0_363
LBB0_1476:                              ; %cond.load2141
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9744]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9744]                 ; 16-byte Spill
	ldr	q6, [sp, #2816]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1477
	b	LBB0_364
LBB0_1477:                              ; %cond.load2147
	fmov	x9, d6
	ldr	q17, [sp, #9744]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9744]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2800]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1478
	b	LBB0_365
LBB0_1478:                              ; %cond.load2153
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9744]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9744]                 ; 16-byte Spill
	ldr	q6, [sp, #2800]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1479
	b	LBB0_366
LBB0_1479:                              ; %cond.load2159
	fmov	x9, d6
	ldr	q17, [sp, #10480]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10480]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1480
	b	LBB0_367
LBB0_1480:                              ; %cond.load2165
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10480]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10480]                ; 16-byte Spill
	str	q5, [sp, #752]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1481
	b	LBB0_368
LBB0_1481:                              ; %cond.load2171
	fmov	x9, d5
	ldr	q6, [sp, #10480]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10480]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2130
	b	LBB0_369
LBB0_2130:                              ; %cond.load2171
	b	LBB0_370
LBB0_1482:                              ; %cond.load2184
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9728]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10464]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2784]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1483
	b	LBB0_372
LBB0_1483:                              ; %cond.load2190
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9728]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9728]                 ; 16-byte Spill
	ldr	q6, [sp, #2784]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1484
	b	LBB0_373
LBB0_1484:                              ; %cond.load2196
	fmov	x9, d6
	ldr	q17, [sp, #9728]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9728]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2768]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1485
	b	LBB0_374
LBB0_1485:                              ; %cond.load2202
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9728]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9728]                 ; 16-byte Spill
	ldr	q6, [sp, #2768]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1486
	b	LBB0_375
LBB0_1486:                              ; %cond.load2208
	fmov	x9, d6
	ldr	q17, [sp, #10464]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10464]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1487
	b	LBB0_376
LBB0_1487:                              ; %cond.load2214
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10464]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10464]                ; 16-byte Spill
	str	q5, [sp, #720]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1488
	b	LBB0_377
LBB0_1488:                              ; %cond.load2220
	fmov	x9, d5
	ldr	q6, [sp, #10464]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10464]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2131
	b	LBB0_378
LBB0_2131:                              ; %cond.load2220
	b	LBB0_379
LBB0_1489:                              ; %cond.load2233
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9712]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10448]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2752]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1490
	b	LBB0_381
LBB0_1490:                              ; %cond.load2239
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9712]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9712]                 ; 16-byte Spill
	ldr	q6, [sp, #2752]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1491
	b	LBB0_382
LBB0_1491:                              ; %cond.load2245
	fmov	x9, d6
	ldr	q17, [sp, #9712]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9712]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2736]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1492
	b	LBB0_383
LBB0_1492:                              ; %cond.load2251
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9712]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9712]                 ; 16-byte Spill
	ldr	q6, [sp, #2736]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1493
	b	LBB0_384
LBB0_1493:                              ; %cond.load2257
	fmov	x9, d6
	ldr	q17, [sp, #10448]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10448]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1494
	b	LBB0_385
LBB0_1494:                              ; %cond.load2263
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10448]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10448]                ; 16-byte Spill
	str	q5, [sp, #688]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1495
	b	LBB0_386
LBB0_1495:                              ; %cond.load2269
	fmov	x9, d5
	ldr	q6, [sp, #10448]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10448]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2132
	b	LBB0_387
LBB0_2132:                              ; %cond.load2269
	b	LBB0_388
LBB0_1496:                              ; %cond.load2282
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9696]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10432]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2720]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1497
	b	LBB0_390
LBB0_1497:                              ; %cond.load2288
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9696]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9696]                 ; 16-byte Spill
	ldr	q6, [sp, #2720]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1498
	b	LBB0_391
LBB0_1498:                              ; %cond.load2294
	fmov	x9, d6
	ldr	q17, [sp, #9696]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9696]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2704]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1499
	b	LBB0_392
LBB0_1499:                              ; %cond.load2300
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9696]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9696]                 ; 16-byte Spill
	ldr	q6, [sp, #2704]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1500
	b	LBB0_393
LBB0_1500:                              ; %cond.load2306
	fmov	x9, d6
	ldr	q17, [sp, #10432]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10432]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1501
	b	LBB0_394
LBB0_1501:                              ; %cond.load2312
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10432]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10432]                ; 16-byte Spill
	str	q5, [sp, #656]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1502
	b	LBB0_395
LBB0_1502:                              ; %cond.load2318
	fmov	x9, d5
	ldr	q6, [sp, #10432]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10432]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2133
	b	LBB0_396
LBB0_2133:                              ; %cond.load2318
	b	LBB0_397
LBB0_1503:                              ; %cond.load2331
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9680]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10416]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2688]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1504
	b	LBB0_399
LBB0_1504:                              ; %cond.load2337
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9680]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9680]                 ; 16-byte Spill
	ldr	q6, [sp, #2688]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1505
	b	LBB0_400
LBB0_1505:                              ; %cond.load2343
	fmov	x9, d6
	ldr	q17, [sp, #9680]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9680]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2672]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1506
	b	LBB0_401
LBB0_1506:                              ; %cond.load2349
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9680]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9680]                 ; 16-byte Spill
	ldr	q6, [sp, #2672]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1507
	b	LBB0_402
LBB0_1507:                              ; %cond.load2355
	fmov	x9, d6
	ldr	q17, [sp, #10416]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10416]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1508
	b	LBB0_403
LBB0_1508:                              ; %cond.load2361
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10416]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10416]                ; 16-byte Spill
	str	q5, [sp, #624]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1509
	b	LBB0_404
LBB0_1509:                              ; %cond.load2367
	fmov	x9, d5
	ldr	q6, [sp, #10416]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10416]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2134
	b	LBB0_405
LBB0_2134:                              ; %cond.load2367
	b	LBB0_406
LBB0_1510:                              ; %cond.load2380
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9664]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10400]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2656]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1511
	b	LBB0_408
LBB0_1511:                              ; %cond.load2386
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9664]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9664]                 ; 16-byte Spill
	ldr	q6, [sp, #2656]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1512
	b	LBB0_409
LBB0_1512:                              ; %cond.load2392
	fmov	x9, d6
	ldr	q17, [sp, #9664]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9664]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2640]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1513
	b	LBB0_410
LBB0_1513:                              ; %cond.load2398
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9664]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9664]                 ; 16-byte Spill
	ldr	q6, [sp, #2640]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1514
	b	LBB0_411
LBB0_1514:                              ; %cond.load2404
	fmov	x9, d6
	ldr	q17, [sp, #10400]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10400]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1515
	b	LBB0_412
LBB0_1515:                              ; %cond.load2410
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10400]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10400]                ; 16-byte Spill
	str	q5, [sp, #592]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1516
	b	LBB0_413
LBB0_1516:                              ; %cond.load2416
	fmov	x9, d5
	ldr	q6, [sp, #10400]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10400]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2135
	b	LBB0_414
LBB0_2135:                              ; %cond.load2416
	b	LBB0_415
LBB0_1517:                              ; %cond.load2429
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9648]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10384]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2624]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1518
	b	LBB0_417
LBB0_1518:                              ; %cond.load2435
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9648]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9648]                 ; 16-byte Spill
	ldr	q6, [sp, #2624]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1519
	b	LBB0_418
LBB0_1519:                              ; %cond.load2441
	fmov	x9, d6
	ldr	q17, [sp, #9648]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9648]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2608]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1520
	b	LBB0_419
LBB0_1520:                              ; %cond.load2447
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9648]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9648]                 ; 16-byte Spill
	ldr	q6, [sp, #2608]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1521
	b	LBB0_420
LBB0_1521:                              ; %cond.load2453
	fmov	x9, d6
	ldr	q17, [sp, #10384]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10384]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1522
	b	LBB0_421
LBB0_1522:                              ; %cond.load2459
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10384]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10384]                ; 16-byte Spill
	str	q5, [sp, #560]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1523
	b	LBB0_422
LBB0_1523:                              ; %cond.load2465
	fmov	x9, d5
	ldr	q6, [sp, #10384]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10384]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2136
	b	LBB0_423
LBB0_2136:                              ; %cond.load2465
	b	LBB0_424
LBB0_1524:                              ; %cond.load2478
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9632]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10368]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2592]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1525
	b	LBB0_426
LBB0_1525:                              ; %cond.load2484
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9632]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9632]                 ; 16-byte Spill
	ldr	q6, [sp, #2592]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1526
	b	LBB0_427
LBB0_1526:                              ; %cond.load2490
	fmov	x9, d6
	ldr	q17, [sp, #9632]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9632]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2576]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1527
	b	LBB0_428
LBB0_1527:                              ; %cond.load2496
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9632]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9632]                 ; 16-byte Spill
	ldr	q6, [sp, #2576]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1528
	b	LBB0_429
LBB0_1528:                              ; %cond.load2502
	fmov	x9, d6
	ldr	q17, [sp, #10368]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10368]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1529
	b	LBB0_430
LBB0_1529:                              ; %cond.load2508
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10368]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10368]                ; 16-byte Spill
	str	q5, [sp, #528]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1530
	b	LBB0_431
LBB0_1530:                              ; %cond.load2514
	fmov	x9, d5
	ldr	q6, [sp, #10368]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10368]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2137
	b	LBB0_432
LBB0_2137:                              ; %cond.load2514
	b	LBB0_433
LBB0_1531:                              ; %cond.load2527
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9616]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10352]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2560]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1532
	b	LBB0_435
LBB0_1532:                              ; %cond.load2533
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9616]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9616]                 ; 16-byte Spill
	ldr	q6, [sp, #2560]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1533
	b	LBB0_436
LBB0_1533:                              ; %cond.load2539
	fmov	x9, d6
	ldr	q17, [sp, #9616]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9616]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2544]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1534
	b	LBB0_437
LBB0_1534:                              ; %cond.load2545
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9616]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9616]                 ; 16-byte Spill
	ldr	q6, [sp, #2544]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1535
	b	LBB0_438
LBB0_1535:                              ; %cond.load2551
	fmov	x9, d6
	ldr	q17, [sp, #10352]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10352]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1536
	b	LBB0_439
LBB0_1536:                              ; %cond.load2557
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10352]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10352]                ; 16-byte Spill
	str	q5, [sp, #496]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1537
	b	LBB0_440
LBB0_1537:                              ; %cond.load2563
	fmov	x9, d5
	ldr	q6, [sp, #10352]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10352]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2138
	b	LBB0_441
LBB0_2138:                              ; %cond.load2563
	b	LBB0_442
LBB0_1538:                              ; %cond.load2576
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9600]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10336]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2528]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1539
	b	LBB0_444
LBB0_1539:                              ; %cond.load2582
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9600]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9600]                 ; 16-byte Spill
	ldr	q6, [sp, #2528]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1540
	b	LBB0_445
LBB0_1540:                              ; %cond.load2588
	fmov	x9, d6
	ldr	q17, [sp, #9600]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9600]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2512]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1541
	b	LBB0_446
LBB0_1541:                              ; %cond.load2594
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9600]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9600]                 ; 16-byte Spill
	ldr	q6, [sp, #2512]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1542
	b	LBB0_447
LBB0_1542:                              ; %cond.load2600
	fmov	x9, d6
	ldr	q17, [sp, #10336]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10336]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1543
	b	LBB0_448
LBB0_1543:                              ; %cond.load2606
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10336]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10336]                ; 16-byte Spill
	str	q5, [sp, #464]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1544
	b	LBB0_449
LBB0_1544:                              ; %cond.load2612
	fmov	x9, d5
	ldr	q6, [sp, #10336]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10336]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2139
	b	LBB0_450
LBB0_2139:                              ; %cond.load2612
	b	LBB0_451
LBB0_1545:                              ; %cond.load2625
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9584]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10320]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2496]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1546
	b	LBB0_453
LBB0_1546:                              ; %cond.load2631
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9584]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9584]                 ; 16-byte Spill
	ldr	q6, [sp, #2496]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1547
	b	LBB0_454
LBB0_1547:                              ; %cond.load2637
	fmov	x9, d6
	ldr	q17, [sp, #9584]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9584]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2480]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1548
	b	LBB0_455
LBB0_1548:                              ; %cond.load2643
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9584]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9584]                 ; 16-byte Spill
	ldr	q6, [sp, #2480]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1549
	b	LBB0_456
LBB0_1549:                              ; %cond.load2649
	fmov	x9, d6
	ldr	q17, [sp, #10320]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10320]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1550
	b	LBB0_457
LBB0_1550:                              ; %cond.load2655
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10320]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10320]                ; 16-byte Spill
	str	q5, [sp, #432]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1551
	b	LBB0_458
LBB0_1551:                              ; %cond.load2661
	fmov	x9, d5
	ldr	q6, [sp, #10320]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10320]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2140
	b	LBB0_459
LBB0_2140:                              ; %cond.load2661
	b	LBB0_460
LBB0_1552:                              ; %cond.load2674
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9568]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10304]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2464]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1553
	b	LBB0_462
LBB0_1553:                              ; %cond.load2680
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9568]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9568]                 ; 16-byte Spill
	ldr	q6, [sp, #2464]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1554
	b	LBB0_463
LBB0_1554:                              ; %cond.load2686
	fmov	x9, d6
	ldr	q17, [sp, #9568]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9568]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2448]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1555
	b	LBB0_464
LBB0_1555:                              ; %cond.load2692
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9568]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9568]                 ; 16-byte Spill
	ldr	q6, [sp, #2448]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1556
	b	LBB0_465
LBB0_1556:                              ; %cond.load2698
	fmov	x9, d6
	ldr	q17, [sp, #10304]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10304]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1557
	b	LBB0_466
LBB0_1557:                              ; %cond.load2704
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10304]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10304]                ; 16-byte Spill
	str	q5, [sp, #400]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1558
	b	LBB0_467
LBB0_1558:                              ; %cond.load2710
	fmov	x9, d5
	ldr	q6, [sp, #10304]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10304]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2141
	b	LBB0_468
LBB0_2141:                              ; %cond.load2710
	b	LBB0_469
LBB0_1559:                              ; %cond.load2723
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9552]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10288]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2432]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1560
	b	LBB0_471
LBB0_1560:                              ; %cond.load2729
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9552]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9552]                 ; 16-byte Spill
	ldr	q6, [sp, #2432]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1561
	b	LBB0_472
LBB0_1561:                              ; %cond.load2735
	fmov	x9, d6
	ldr	q17, [sp, #9552]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9552]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2416]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1562
	b	LBB0_473
LBB0_1562:                              ; %cond.load2741
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9552]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9552]                 ; 16-byte Spill
	ldr	q6, [sp, #2416]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1563
	b	LBB0_474
LBB0_1563:                              ; %cond.load2747
	fmov	x9, d6
	ldr	q17, [sp, #10288]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10288]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1564
	b	LBB0_475
LBB0_1564:                              ; %cond.load2753
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10288]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10288]                ; 16-byte Spill
	str	q5, [sp, #368]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1565
	b	LBB0_476
LBB0_1565:                              ; %cond.load2759
	fmov	x9, d5
	ldr	q6, [sp, #10288]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10288]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2142
	b	LBB0_477
LBB0_2142:                              ; %cond.load2759
	b	LBB0_478
LBB0_1566:                              ; %cond.load2772
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9536]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10272]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2400]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1567
	b	LBB0_480
LBB0_1567:                              ; %cond.load2778
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9536]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9536]                 ; 16-byte Spill
	ldr	q6, [sp, #2400]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1568
	b	LBB0_481
LBB0_1568:                              ; %cond.load2784
	fmov	x9, d6
	ldr	q17, [sp, #9536]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9536]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2384]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1569
	b	LBB0_482
LBB0_1569:                              ; %cond.load2790
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9536]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9536]                 ; 16-byte Spill
	ldr	q6, [sp, #2384]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1570
	b	LBB0_483
LBB0_1570:                              ; %cond.load2796
	fmov	x9, d6
	ldr	q17, [sp, #10272]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10272]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1571
	b	LBB0_484
LBB0_1571:                              ; %cond.load2802
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10272]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10272]                ; 16-byte Spill
	str	q5, [sp, #336]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1572
	b	LBB0_485
LBB0_1572:                              ; %cond.load2808
	fmov	x9, d5
	ldr	q6, [sp, #10272]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10272]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2143
	b	LBB0_486
LBB0_2143:                              ; %cond.load2808
	b	LBB0_487
LBB0_1573:                              ; %cond.load2821
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9520]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10256]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2368]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1574
	b	LBB0_489
LBB0_1574:                              ; %cond.load2827
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9520]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9520]                 ; 16-byte Spill
	ldr	q6, [sp, #2368]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1575
	b	LBB0_490
LBB0_1575:                              ; %cond.load2833
	fmov	x9, d6
	ldr	q17, [sp, #9520]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9520]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2352]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1576
	b	LBB0_491
LBB0_1576:                              ; %cond.load2839
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9520]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9520]                 ; 16-byte Spill
	ldr	q6, [sp, #2352]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1577
	b	LBB0_492
LBB0_1577:                              ; %cond.load2845
	fmov	x9, d6
	ldr	q17, [sp, #10256]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10256]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1578
	b	LBB0_493
LBB0_1578:                              ; %cond.load2851
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10256]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10256]                ; 16-byte Spill
	str	q5, [sp, #304]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1579
	b	LBB0_494
LBB0_1579:                              ; %cond.load2857
	fmov	x9, d5
	ldr	q6, [sp, #10256]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10256]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2144
	b	LBB0_495
LBB0_2144:                              ; %cond.load2857
	b	LBB0_496
LBB0_1580:                              ; %cond.load2870
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9504]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10240]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2336]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1581
	b	LBB0_498
LBB0_1581:                              ; %cond.load2876
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9504]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9504]                 ; 16-byte Spill
	ldr	q6, [sp, #2336]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1582
	b	LBB0_499
LBB0_1582:                              ; %cond.load2882
	fmov	x9, d6
	ldr	q17, [sp, #9504]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9504]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2320]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1583
	b	LBB0_500
LBB0_1583:                              ; %cond.load2888
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9504]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9504]                 ; 16-byte Spill
	ldr	q6, [sp, #2320]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1584
	b	LBB0_501
LBB0_1584:                              ; %cond.load2894
	fmov	x9, d6
	ldr	q17, [sp, #10240]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10240]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1585
	b	LBB0_502
LBB0_1585:                              ; %cond.load2900
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10240]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10240]                ; 16-byte Spill
	str	q5, [sp, #272]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1586
	b	LBB0_503
LBB0_1586:                              ; %cond.load2906
	fmov	x9, d5
	ldr	q6, [sp, #10240]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10240]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2145
	b	LBB0_504
LBB0_2145:                              ; %cond.load2906
	b	LBB0_505
LBB0_1587:                              ; %cond.load2919
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9488]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10224]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2304]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1588
	b	LBB0_507
LBB0_1588:                              ; %cond.load2925
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9488]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9488]                 ; 16-byte Spill
	ldr	q6, [sp, #2304]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1589
	b	LBB0_508
LBB0_1589:                              ; %cond.load2931
	fmov	x9, d6
	ldr	q17, [sp, #9488]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9488]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2288]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1590
	b	LBB0_509
LBB0_1590:                              ; %cond.load2937
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9488]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9488]                 ; 16-byte Spill
	ldr	q6, [sp, #2288]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1591
	b	LBB0_510
LBB0_1591:                              ; %cond.load2943
	fmov	x9, d6
	ldr	q17, [sp, #10224]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10224]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1592
	b	LBB0_511
LBB0_1592:                              ; %cond.load2949
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10224]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10224]                ; 16-byte Spill
	str	q5, [sp, #240]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1593
	b	LBB0_512
LBB0_1593:                              ; %cond.load2955
	fmov	x9, d5
	ldr	q6, [sp, #10224]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10224]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2146
	b	LBB0_513
LBB0_2146:                              ; %cond.load2955
	b	LBB0_514
LBB0_1594:                              ; %cond.load2968
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9472]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10208]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2272]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1595
	b	LBB0_516
LBB0_1595:                              ; %cond.load2974
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9472]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9472]                 ; 16-byte Spill
	ldr	q6, [sp, #2272]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1596
	b	LBB0_517
LBB0_1596:                              ; %cond.load2980
	fmov	x9, d6
	ldr	q17, [sp, #9472]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9472]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2256]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1597
	b	LBB0_518
LBB0_1597:                              ; %cond.load2986
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9472]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9472]                 ; 16-byte Spill
	ldr	q6, [sp, #2256]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1598
	b	LBB0_519
LBB0_1598:                              ; %cond.load2992
	fmov	x9, d6
	ldr	q17, [sp, #10208]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10208]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1599
	b	LBB0_520
LBB0_1599:                              ; %cond.load2998
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10208]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10208]                ; 16-byte Spill
	str	q5, [sp, #208]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1600
	b	LBB0_521
LBB0_1600:                              ; %cond.load3004
	fmov	x9, d5
	ldr	q6, [sp, #10208]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10208]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2147
	b	LBB0_522
LBB0_2147:                              ; %cond.load3004
	b	LBB0_523
LBB0_1601:                              ; %cond.load3017
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9456]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10192]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2240]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1602
	b	LBB0_525
LBB0_1602:                              ; %cond.load3023
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9456]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9456]                 ; 16-byte Spill
	ldr	q6, [sp, #2240]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1603
	b	LBB0_526
LBB0_1603:                              ; %cond.load3029
	fmov	x9, d6
	ldr	q17, [sp, #9456]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9456]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2224]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1604
	b	LBB0_527
LBB0_1604:                              ; %cond.load3035
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9456]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9456]                 ; 16-byte Spill
	ldr	q6, [sp, #2224]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1605
	b	LBB0_528
LBB0_1605:                              ; %cond.load3041
	fmov	x9, d6
	ldr	q17, [sp, #10192]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10192]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1606
	b	LBB0_529
LBB0_1606:                              ; %cond.load3047
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10192]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10192]                ; 16-byte Spill
	str	q5, [sp, #176]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1607
	b	LBB0_530
LBB0_1607:                              ; %cond.load3053
	fmov	x9, d5
	ldr	q6, [sp, #10192]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10192]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2148
	b	LBB0_531
LBB0_2148:                              ; %cond.load3053
	b	LBB0_532
LBB0_1608:                              ; %cond.load3066
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9440]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10176]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2208]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1609
	b	LBB0_534
LBB0_1609:                              ; %cond.load3072
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9440]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9440]                 ; 16-byte Spill
	ldr	q6, [sp, #2208]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1610
	b	LBB0_535
LBB0_1610:                              ; %cond.load3078
	fmov	x9, d6
	ldr	q17, [sp, #9440]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9440]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2192]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1611
	b	LBB0_536
LBB0_1611:                              ; %cond.load3084
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9440]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9440]                 ; 16-byte Spill
	ldr	q6, [sp, #2192]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1612
	b	LBB0_537
LBB0_1612:                              ; %cond.load3090
	fmov	x9, d6
	ldr	q17, [sp, #10176]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10176]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1613
	b	LBB0_538
LBB0_1613:                              ; %cond.load3096
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10176]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10176]                ; 16-byte Spill
	str	q5, [sp, #144]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1614
	b	LBB0_539
LBB0_1614:                              ; %cond.load3102
	fmov	x9, d5
	ldr	q6, [sp, #10176]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10176]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2149
	b	LBB0_540
LBB0_2149:                              ; %cond.load3102
	b	LBB0_541
LBB0_1615:                              ; %cond.load3115
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9424]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10160]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2176]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1616
	b	LBB0_543
LBB0_1616:                              ; %cond.load3121
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9424]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9424]                 ; 16-byte Spill
	ldr	q6, [sp, #2176]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1617
	b	LBB0_544
LBB0_1617:                              ; %cond.load3127
	fmov	x9, d6
	ldr	q17, [sp, #9424]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9424]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2160]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1618
	b	LBB0_545
LBB0_1618:                              ; %cond.load3133
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9424]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9424]                 ; 16-byte Spill
	ldr	q6, [sp, #2160]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1619
	b	LBB0_546
LBB0_1619:                              ; %cond.load3139
	fmov	x9, d6
	ldr	q17, [sp, #10160]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10160]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1620
	b	LBB0_547
LBB0_1620:                              ; %cond.load3145
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10160]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10160]                ; 16-byte Spill
	str	q5, [sp, #112]                  ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1621
	b	LBB0_548
LBB0_1621:                              ; %cond.load3151
	fmov	x9, d5
	ldr	q6, [sp, #10160]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10160]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2150
	b	LBB0_549
LBB0_2150:                              ; %cond.load3151
	b	LBB0_550
LBB0_1622:                              ; %cond.load3164
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #9408]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10144]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2144]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1623
	b	LBB0_552
LBB0_1623:                              ; %cond.load3170
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9408]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9408]                 ; 16-byte Spill
	ldr	q6, [sp, #2144]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1624
	b	LBB0_553
LBB0_1624:                              ; %cond.load3176
	fmov	x9, d6
	ldr	q17, [sp, #9408]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #9408]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2128]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1625
	b	LBB0_554
LBB0_1625:                              ; %cond.load3182
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9408]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #9408]                 ; 16-byte Spill
	ldr	q6, [sp, #2128]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1626
	b	LBB0_555
LBB0_1626:                              ; %cond.load3188
	fmov	x9, d6
	ldr	q17, [sp, #10144]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #10144]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1627
	b	LBB0_556
LBB0_1627:                              ; %cond.load3194
	mov.d	x9, v6[1]
	ldr	q6, [sp, #10144]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #10144]                ; 16-byte Spill
	str	q5, [sp, #80]                   ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1628
	b	LBB0_557
LBB0_1628:                              ; %cond.load3200
	fmov	x9, d5
	ldr	q6, [sp, #10144]                ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #10144]                ; 16-byte Spill
	tbz	w8, #7, LBB0_2151
	b	LBB0_558
LBB0_2151:                              ; %cond.load3200
	b	LBB0_559
LBB0_1629:                              ; %cond.load3213
	fmov	x9, d6
	ldr	s17, [x9]
	str	q17, [sp, #8704]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #9152]                ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2112]                ; 16-byte Spill
	tbnz	w8, #1, LBB0_1630
	b	LBB0_561
LBB0_1630:                              ; %cond.load3219
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8704]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #8704]                 ; 16-byte Spill
	ldr	q6, [sp, #2112]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #2, LBB0_1631
	b	LBB0_562
LBB0_1631:                              ; %cond.load3225
	fmov	x9, d6
	ldr	q17, [sp, #8704]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x9]
	str	q17, [sp, #8704]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2096]                ; 16-byte Spill
	tbnz	w8, #3, LBB0_1632
	b	LBB0_563
LBB0_1632:                              ; %cond.load3231
	mov.d	x9, v6[1]
	ldr	q6, [sp, #8704]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x9]
	str	q6, [sp, #8704]                 ; 16-byte Spill
	ldr	q6, [sp, #2096]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w8, #4, LBB0_1633
	b	LBB0_564
LBB0_1633:                              ; %cond.load3237
	fmov	x9, d6
	ldr	q17, [sp, #9152]                ; 16-byte Reload
	ld1.s	{ v17 }[0], [x9]
	str	q17, [sp, #9152]                ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w8, #5, LBB0_1634
	b	LBB0_565
LBB0_1634:                              ; %cond.load3243
	mov.d	x9, v6[1]
	ldr	q6, [sp, #9152]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x9]
	str	q6, [sp, #9152]                 ; 16-byte Spill
	str	q5, [sp, #48]                   ; 16-byte Spill
	add.2d	v5, v4, v5
	tbnz	w8, #6, LBB0_1635
	b	LBB0_566
LBB0_1635:                              ; %cond.load3249
	fmov	x9, d5
	ldr	q6, [sp, #9152]                 ; 16-byte Reload
	ld1.s	{ v6 }[2], [x9]
	str	q6, [sp, #9152]                 ; 16-byte Spill
	tbz	w8, #7, LBB0_2152
	b	LBB0_567
LBB0_2152:                              ; %cond.load3249
	b	LBB0_568
LBB0_1636:                              ; %cond.load3262
	fmov	x8, d6
	ldr	s17, [x8]
	str	q17, [sp, #8896]                ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	str	q17, [sp, #10128]               ; 16-byte Spill
	orr.16b	v19, v16, v5
	str	q19, [sp, #2080]                ; 16-byte Spill
	tbnz	w9, #1, LBB0_1637
	b	LBB0_570
LBB0_1637:                              ; %cond.load3268
	mov.d	x8, v6[1]
	ldr	q6, [sp, #8896]                 ; 16-byte Reload
	ld1.s	{ v6 }[1], [x8]
	str	q6, [sp, #8896]                 ; 16-byte Spill
	ldr	q6, [sp, #2080]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w9, #2, LBB0_1638
	b	LBB0_571
LBB0_1638:                              ; %cond.load3274
	fmov	x8, d6
	ldr	q17, [sp, #8896]                ; 16-byte Reload
	ld1.s	{ v17 }[2], [x8]
	str	q17, [sp, #8896]                ; 16-byte Spill
	orr.16b	v19, v18, v5
	str	q19, [sp, #2064]                ; 16-byte Spill
	tbnz	w9, #3, LBB0_1639
	b	LBB0_572
LBB0_1639:                              ; %cond.load3280
	mov.d	x8, v6[1]
	ldr	q6, [sp, #8896]                 ; 16-byte Reload
	ld1.s	{ v6 }[3], [x8]
	str	q6, [sp, #8896]                 ; 16-byte Spill
	ldr	q6, [sp, #2064]                 ; 16-byte Reload
	add.2d	v6, v4, v6
	tbnz	w9, #4, LBB0_1640
	b	LBB0_573
LBB0_1640:                              ; %cond.load3286
	fmov	x8, d6
	ldr	q17, [sp, #10128]               ; 16-byte Reload
	ld1.s	{ v17 }[0], [x8]
	str	q17, [sp, #10128]               ; 16-byte Spill
	orr.16b	v5, v22, v5
	tbnz	w9, #5, LBB0_1641
	b	LBB0_574
LBB0_1641:                              ; %cond.load3292
	mov.d	x8, v6[1]
	ldr	q6, [sp, #10128]                ; 16-byte Reload
	ld1.s	{ v6 }[1], [x8]
	str	q6, [sp, #10128]                ; 16-byte Spill
	add.2d	v6, v4, v5
	str	q5, [sp, #16]                   ; 16-byte Spill
	tbz	w9, #6, LBB0_2153
	b	LBB0_575
LBB0_2153:                              ; %cond.load3292
	b	LBB0_576
LBB0_1642:                              ; %cond.store
	fmov	x9, d4
	str	s3, [x9]
	ldr	q16, [sp, #4320]                ; 16-byte Reload
	and.16b	v6, v16, v5
	ldr	q7, [sp, #4336]                 ; 16-byte Reload
	tbz	w8, #1, LBB0_620
LBB0_1643:                              ; %cond.store3313
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_621
LBB0_1644:                              ; %cond.store3316
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	and.16b	v5, v5, v18
	tbz	w8, #3, LBB0_622
LBB0_1645:                              ; %cond.store3319
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q17, [sp, #8688]                ; 16-byte Reload
	ldr	q3, [sp, #6768]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_623
LBB0_1646:                              ; %cond.store3322
	fmov	x9, d4
	str	s3, [x9]
	and.16b	v5, v7, v22
	tbz	w8, #5, LBB0_624
LBB0_1647:                              ; %cond.store3325
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_625
LBB0_1648:                              ; %cond.store3328
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_626
	b	LBB0_627
LBB0_1649:                              ; %cond.store3335
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #4064]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_629
LBB0_1650:                              ; %cond.store3339
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_630
LBB0_1651:                              ; %cond.store3343
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #4048]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_631
LBB0_1652:                              ; %cond.store3347
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #6800]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_632
LBB0_1653:                              ; %cond.store3351
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2000]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_633
LBB0_1654:                              ; %cond.store3355
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_634
LBB0_1655:                              ; %cond.store3359
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_635
	b	LBB0_636
LBB0_1656:                              ; %cond.store3368
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #4032]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_638
LBB0_1657:                              ; %cond.store3372
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_639
LBB0_1658:                              ; %cond.store3376
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #4016]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_640
LBB0_1659:                              ; %cond.store3380
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #6832]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_641
LBB0_1660:                              ; %cond.store3384
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1968]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_642
LBB0_1661:                              ; %cond.store3388
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_643
LBB0_1662:                              ; %cond.store3392
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_644
	b	LBB0_645
LBB0_1663:                              ; %cond.store3401
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #4000]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_647
LBB0_1664:                              ; %cond.store3405
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_648
LBB0_1665:                              ; %cond.store3409
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3984]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_649
LBB0_1666:                              ; %cond.store3413
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #6864]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_650
LBB0_1667:                              ; %cond.store3417
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1936]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_651
LBB0_1668:                              ; %cond.store3421
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_652
LBB0_1669:                              ; %cond.store3425
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_653
	b	LBB0_654
LBB0_1670:                              ; %cond.store3434
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3968]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_656
LBB0_1671:                              ; %cond.store3438
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_657
LBB0_1672:                              ; %cond.store3442
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3952]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_658
LBB0_1673:                              ; %cond.store3446
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #6896]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_659
LBB0_1674:                              ; %cond.store3450
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1904]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_660
LBB0_1675:                              ; %cond.store3454
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_661
LBB0_1676:                              ; %cond.store3458
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_662
	b	LBB0_663
LBB0_1677:                              ; %cond.store3467
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3936]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_665
LBB0_1678:                              ; %cond.store3471
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_666
LBB0_1679:                              ; %cond.store3475
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3920]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_667
LBB0_1680:                              ; %cond.store3479
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #6928]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_668
LBB0_1681:                              ; %cond.store3483
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1872]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_669
LBB0_1682:                              ; %cond.store3487
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_670
LBB0_1683:                              ; %cond.store3491
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_671
	b	LBB0_672
LBB0_1684:                              ; %cond.store3500
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3904]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_674
LBB0_1685:                              ; %cond.store3504
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_675
LBB0_1686:                              ; %cond.store3508
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3888]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_676
LBB0_1687:                              ; %cond.store3512
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #6960]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_677
LBB0_1688:                              ; %cond.store3516
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1840]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_678
LBB0_1689:                              ; %cond.store3520
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_679
LBB0_1690:                              ; %cond.store3524
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_680
	b	LBB0_681
LBB0_1691:                              ; %cond.store3533
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3872]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_683
LBB0_1692:                              ; %cond.store3537
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_684
LBB0_1693:                              ; %cond.store3541
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3856]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_685
LBB0_1694:                              ; %cond.store3545
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #6992]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_686
LBB0_1695:                              ; %cond.store3549
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1808]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_687
LBB0_1696:                              ; %cond.store3553
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_688
LBB0_1697:                              ; %cond.store3557
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_689
	b	LBB0_690
LBB0_1698:                              ; %cond.store3566
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3840]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_692
LBB0_1699:                              ; %cond.store3570
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_693
LBB0_1700:                              ; %cond.store3574
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3824]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_694
LBB0_1701:                              ; %cond.store3578
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7024]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_695
LBB0_1702:                              ; %cond.store3582
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1776]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_696
LBB0_1703:                              ; %cond.store3586
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_697
LBB0_1704:                              ; %cond.store3590
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_698
	b	LBB0_699
LBB0_1705:                              ; %cond.store3599
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3808]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_701
LBB0_1706:                              ; %cond.store3603
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_702
LBB0_1707:                              ; %cond.store3607
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3792]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_703
LBB0_1708:                              ; %cond.store3611
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7056]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_704
LBB0_1709:                              ; %cond.store3615
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1744]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_705
LBB0_1710:                              ; %cond.store3619
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_706
LBB0_1711:                              ; %cond.store3623
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_707
	b	LBB0_708
LBB0_1712:                              ; %cond.store3632
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3776]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_710
LBB0_1713:                              ; %cond.store3636
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_711
LBB0_1714:                              ; %cond.store3640
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3760]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_712
LBB0_1715:                              ; %cond.store3644
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7088]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_713
LBB0_1716:                              ; %cond.store3648
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1712]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_714
LBB0_1717:                              ; %cond.store3652
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_715
LBB0_1718:                              ; %cond.store3656
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_716
	b	LBB0_717
LBB0_1719:                              ; %cond.store3665
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3744]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_719
LBB0_1720:                              ; %cond.store3669
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_720
LBB0_1721:                              ; %cond.store3673
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3728]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_721
LBB0_1722:                              ; %cond.store3677
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7120]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_722
LBB0_1723:                              ; %cond.store3681
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1680]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_723
LBB0_1724:                              ; %cond.store3685
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_724
LBB0_1725:                              ; %cond.store3689
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_725
	b	LBB0_726
LBB0_1726:                              ; %cond.store3698
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3712]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_728
LBB0_1727:                              ; %cond.store3702
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_729
LBB0_1728:                              ; %cond.store3706
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3696]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_730
LBB0_1729:                              ; %cond.store3710
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7152]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_731
LBB0_1730:                              ; %cond.store3714
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1648]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_732
LBB0_1731:                              ; %cond.store3718
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_733
LBB0_1732:                              ; %cond.store3722
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_734
	b	LBB0_735
LBB0_1733:                              ; %cond.store3731
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3680]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_737
LBB0_1734:                              ; %cond.store3735
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_738
LBB0_1735:                              ; %cond.store3739
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3664]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_739
LBB0_1736:                              ; %cond.store3743
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7184]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_740
LBB0_1737:                              ; %cond.store3747
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1616]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_741
LBB0_1738:                              ; %cond.store3751
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_742
LBB0_1739:                              ; %cond.store3755
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_743
	b	LBB0_744
LBB0_1740:                              ; %cond.store3764
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3648]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_746
LBB0_1741:                              ; %cond.store3768
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_747
LBB0_1742:                              ; %cond.store3772
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3632]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_748
LBB0_1743:                              ; %cond.store3776
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7216]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_749
LBB0_1744:                              ; %cond.store3780
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1584]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_750
LBB0_1745:                              ; %cond.store3784
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_751
LBB0_1746:                              ; %cond.store3788
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_752
	b	LBB0_753
LBB0_1747:                              ; %cond.store3797
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3616]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_755
LBB0_1748:                              ; %cond.store3801
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_756
LBB0_1749:                              ; %cond.store3805
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3600]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_757
LBB0_1750:                              ; %cond.store3809
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7248]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_758
LBB0_1751:                              ; %cond.store3813
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1552]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_759
LBB0_1752:                              ; %cond.store3817
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_760
LBB0_1753:                              ; %cond.store3821
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_761
	b	LBB0_762
LBB0_1754:                              ; %cond.store3830
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3584]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_764
LBB0_1755:                              ; %cond.store3834
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_765
LBB0_1756:                              ; %cond.store3838
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3568]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_766
LBB0_1757:                              ; %cond.store3842
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7280]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_767
LBB0_1758:                              ; %cond.store3846
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1520]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_768
LBB0_1759:                              ; %cond.store3850
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_769
LBB0_1760:                              ; %cond.store3854
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_770
	b	LBB0_771
LBB0_1761:                              ; %cond.store3863
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3552]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_773
LBB0_1762:                              ; %cond.store3867
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_774
LBB0_1763:                              ; %cond.store3871
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3536]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_775
LBB0_1764:                              ; %cond.store3875
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7312]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_776
LBB0_1765:                              ; %cond.store3879
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1488]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_777
LBB0_1766:                              ; %cond.store3883
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_778
LBB0_1767:                              ; %cond.store3887
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_779
	b	LBB0_780
LBB0_1768:                              ; %cond.store3896
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3520]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_782
LBB0_1769:                              ; %cond.store3900
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_783
LBB0_1770:                              ; %cond.store3904
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3504]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_784
LBB0_1771:                              ; %cond.store3908
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7344]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_785
LBB0_1772:                              ; %cond.store3912
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1456]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_786
LBB0_1773:                              ; %cond.store3916
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_787
LBB0_1774:                              ; %cond.store3920
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_788
	b	LBB0_789
LBB0_1775:                              ; %cond.store3929
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3488]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_791
LBB0_1776:                              ; %cond.store3933
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_792
LBB0_1777:                              ; %cond.store3937
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3472]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_793
LBB0_1778:                              ; %cond.store3941
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7376]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_794
LBB0_1779:                              ; %cond.store3945
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1424]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_795
LBB0_1780:                              ; %cond.store3949
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_796
LBB0_1781:                              ; %cond.store3953
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_797
	b	LBB0_798
LBB0_1782:                              ; %cond.store3962
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3456]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_800
LBB0_1783:                              ; %cond.store3966
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_801
LBB0_1784:                              ; %cond.store3970
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3440]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_802
LBB0_1785:                              ; %cond.store3974
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7408]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_803
LBB0_1786:                              ; %cond.store3978
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1392]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_804
LBB0_1787:                              ; %cond.store3982
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_805
LBB0_1788:                              ; %cond.store3986
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_806
	b	LBB0_807
LBB0_1789:                              ; %cond.store3995
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3424]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_809
LBB0_1790:                              ; %cond.store3999
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_810
LBB0_1791:                              ; %cond.store4003
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3408]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_811
LBB0_1792:                              ; %cond.store4007
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7440]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_812
LBB0_1793:                              ; %cond.store4011
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1360]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_813
LBB0_1794:                              ; %cond.store4015
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_814
LBB0_1795:                              ; %cond.store4019
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_815
	b	LBB0_816
LBB0_1796:                              ; %cond.store4028
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3392]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_818
LBB0_1797:                              ; %cond.store4032
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_819
LBB0_1798:                              ; %cond.store4036
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3376]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_820
LBB0_1799:                              ; %cond.store4040
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7472]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_821
LBB0_1800:                              ; %cond.store4044
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1328]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_822
LBB0_1801:                              ; %cond.store4048
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_823
LBB0_1802:                              ; %cond.store4052
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_824
	b	LBB0_825
LBB0_1803:                              ; %cond.store4061
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3360]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_827
LBB0_1804:                              ; %cond.store4065
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_828
LBB0_1805:                              ; %cond.store4069
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3344]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_829
LBB0_1806:                              ; %cond.store4073
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7504]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_830
LBB0_1807:                              ; %cond.store4077
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1296]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_831
LBB0_1808:                              ; %cond.store4081
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_832
LBB0_1809:                              ; %cond.store4085
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_833
	b	LBB0_834
LBB0_1810:                              ; %cond.store4094
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3328]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_836
LBB0_1811:                              ; %cond.store4098
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_837
LBB0_1812:                              ; %cond.store4102
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3312]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_838
LBB0_1813:                              ; %cond.store4106
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7536]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_839
LBB0_1814:                              ; %cond.store4110
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1264]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_840
LBB0_1815:                              ; %cond.store4114
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_841
LBB0_1816:                              ; %cond.store4118
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_842
	b	LBB0_843
LBB0_1817:                              ; %cond.store4127
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3296]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_845
LBB0_1818:                              ; %cond.store4131
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_846
LBB0_1819:                              ; %cond.store4135
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3280]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_847
LBB0_1820:                              ; %cond.store4139
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7568]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_848
LBB0_1821:                              ; %cond.store4143
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1232]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_849
LBB0_1822:                              ; %cond.store4147
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_850
LBB0_1823:                              ; %cond.store4151
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_851
	b	LBB0_852
LBB0_1824:                              ; %cond.store4160
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3264]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_854
LBB0_1825:                              ; %cond.store4164
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_855
LBB0_1826:                              ; %cond.store4168
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3248]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_856
LBB0_1827:                              ; %cond.store4172
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7600]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_857
LBB0_1828:                              ; %cond.store4176
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1200]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_858
LBB0_1829:                              ; %cond.store4180
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_859
LBB0_1830:                              ; %cond.store4184
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_860
	b	LBB0_861
LBB0_1831:                              ; %cond.store4193
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3232]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_863
LBB0_1832:                              ; %cond.store4197
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_864
LBB0_1833:                              ; %cond.store4201
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3216]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_865
LBB0_1834:                              ; %cond.store4205
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7632]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_866
LBB0_1835:                              ; %cond.store4209
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1168]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_867
LBB0_1836:                              ; %cond.store4213
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_868
LBB0_1837:                              ; %cond.store4217
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_869
	b	LBB0_870
LBB0_1838:                              ; %cond.store4226
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3200]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_872
LBB0_1839:                              ; %cond.store4230
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_873
LBB0_1840:                              ; %cond.store4234
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3184]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_874
LBB0_1841:                              ; %cond.store4238
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7664]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_875
LBB0_1842:                              ; %cond.store4242
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1136]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_876
LBB0_1843:                              ; %cond.store4246
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_877
LBB0_1844:                              ; %cond.store4250
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_878
	b	LBB0_879
LBB0_1845:                              ; %cond.store4259
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3168]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_881
LBB0_1846:                              ; %cond.store4263
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_882
LBB0_1847:                              ; %cond.store4267
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3152]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_883
LBB0_1848:                              ; %cond.store4271
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7696]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_884
LBB0_1849:                              ; %cond.store4275
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1104]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_885
LBB0_1850:                              ; %cond.store4279
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_886
LBB0_1851:                              ; %cond.store4283
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_887
	b	LBB0_888
LBB0_1852:                              ; %cond.store4292
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3136]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_890
LBB0_1853:                              ; %cond.store4296
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_891
LBB0_1854:                              ; %cond.store4300
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3120]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_892
LBB0_1855:                              ; %cond.store4304
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7728]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_893
LBB0_1856:                              ; %cond.store4308
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1072]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_894
LBB0_1857:                              ; %cond.store4312
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_895
LBB0_1858:                              ; %cond.store4316
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_896
	b	LBB0_897
LBB0_1859:                              ; %cond.store4325
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3104]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_899
LBB0_1860:                              ; %cond.store4329
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_900
LBB0_1861:                              ; %cond.store4333
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3088]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_901
LBB0_1862:                              ; %cond.store4337
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7760]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_902
LBB0_1863:                              ; %cond.store4341
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1040]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_903
LBB0_1864:                              ; %cond.store4345
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_904
LBB0_1865:                              ; %cond.store4349
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_905
	b	LBB0_906
LBB0_1866:                              ; %cond.store4358
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3072]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_908
LBB0_1867:                              ; %cond.store4362
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_909
LBB0_1868:                              ; %cond.store4366
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3056]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_910
LBB0_1869:                              ; %cond.store4370
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7792]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_911
LBB0_1870:                              ; %cond.store4374
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #1008]                 ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_912
LBB0_1871:                              ; %cond.store4378
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_913
LBB0_1872:                              ; %cond.store4382
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_914
	b	LBB0_915
LBB0_1873:                              ; %cond.store4391
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3040]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_917
LBB0_1874:                              ; %cond.store4395
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_918
LBB0_1875:                              ; %cond.store4399
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #3024]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_919
LBB0_1876:                              ; %cond.store4403
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7824]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_920
LBB0_1877:                              ; %cond.store4407
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #976]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_921
LBB0_1878:                              ; %cond.store4411
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_922
LBB0_1879:                              ; %cond.store4415
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_923
	b	LBB0_924
LBB0_1880:                              ; %cond.store4424
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #3008]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_926
LBB0_1881:                              ; %cond.store4428
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_927
LBB0_1882:                              ; %cond.store4432
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2992]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_928
LBB0_1883:                              ; %cond.store4436
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7856]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_929
LBB0_1884:                              ; %cond.store4440
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #944]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_930
LBB0_1885:                              ; %cond.store4444
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_931
LBB0_1886:                              ; %cond.store4448
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_932
	b	LBB0_933
LBB0_1887:                              ; %cond.store4457
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2976]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_935
LBB0_1888:                              ; %cond.store4461
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_936
LBB0_1889:                              ; %cond.store4465
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2960]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_937
LBB0_1890:                              ; %cond.store4469
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7888]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_938
LBB0_1891:                              ; %cond.store4473
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #912]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_939
LBB0_1892:                              ; %cond.store4477
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_940
LBB0_1893:                              ; %cond.store4481
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_941
	b	LBB0_942
LBB0_1894:                              ; %cond.store4490
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2944]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_944
LBB0_1895:                              ; %cond.store4494
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_945
LBB0_1896:                              ; %cond.store4498
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2928]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_946
LBB0_1897:                              ; %cond.store4502
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7920]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_947
LBB0_1898:                              ; %cond.store4506
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #880]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_948
LBB0_1899:                              ; %cond.store4510
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_949
LBB0_1900:                              ; %cond.store4514
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_950
	b	LBB0_951
LBB0_1901:                              ; %cond.store4523
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2912]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_953
LBB0_1902:                              ; %cond.store4527
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_954
LBB0_1903:                              ; %cond.store4531
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2896]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_955
LBB0_1904:                              ; %cond.store4535
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7952]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_956
LBB0_1905:                              ; %cond.store4539
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #848]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_957
LBB0_1906:                              ; %cond.store4543
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_958
LBB0_1907:                              ; %cond.store4547
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_959
	b	LBB0_960
LBB0_1908:                              ; %cond.store4556
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2880]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_962
LBB0_1909:                              ; %cond.store4560
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_963
LBB0_1910:                              ; %cond.store4564
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2864]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_964
LBB0_1911:                              ; %cond.store4568
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #7984]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_965
LBB0_1912:                              ; %cond.store4572
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #816]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_966
LBB0_1913:                              ; %cond.store4576
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_967
LBB0_1914:                              ; %cond.store4580
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_968
	b	LBB0_969
LBB0_1915:                              ; %cond.store4589
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2848]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_971
LBB0_1916:                              ; %cond.store4593
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_972
LBB0_1917:                              ; %cond.store4597
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2832]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_973
LBB0_1918:                              ; %cond.store4601
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8016]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_974
LBB0_1919:                              ; %cond.store4605
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #784]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_975
LBB0_1920:                              ; %cond.store4609
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_976
LBB0_1921:                              ; %cond.store4613
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_977
	b	LBB0_978
LBB0_1922:                              ; %cond.store4622
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2816]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_980
LBB0_1923:                              ; %cond.store4626
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_981
LBB0_1924:                              ; %cond.store4630
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2800]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_982
LBB0_1925:                              ; %cond.store4634
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8048]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_983
LBB0_1926:                              ; %cond.store4638
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #752]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_984
LBB0_1927:                              ; %cond.store4642
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_985
LBB0_1928:                              ; %cond.store4646
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_986
	b	LBB0_987
LBB0_1929:                              ; %cond.store4655
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2784]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_989
LBB0_1930:                              ; %cond.store4659
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_990
LBB0_1931:                              ; %cond.store4663
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2768]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_991
LBB0_1932:                              ; %cond.store4667
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8080]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_992
LBB0_1933:                              ; %cond.store4671
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #720]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_993
LBB0_1934:                              ; %cond.store4675
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_994
LBB0_1935:                              ; %cond.store4679
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_995
	b	LBB0_996
LBB0_1936:                              ; %cond.store4688
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2752]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_998
LBB0_1937:                              ; %cond.store4692
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_999
LBB0_1938:                              ; %cond.store4696
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2736]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1000
LBB0_1939:                              ; %cond.store4700
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8112]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1001
LBB0_1940:                              ; %cond.store4704
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #688]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1002
LBB0_1941:                              ; %cond.store4708
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1003
LBB0_1942:                              ; %cond.store4712
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1004
	b	LBB0_1005
LBB0_1943:                              ; %cond.store4721
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2720]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1007
LBB0_1944:                              ; %cond.store4725
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1008
LBB0_1945:                              ; %cond.store4729
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2704]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1009
LBB0_1946:                              ; %cond.store4733
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8144]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1010
LBB0_1947:                              ; %cond.store4737
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #656]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1011
LBB0_1948:                              ; %cond.store4741
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1012
LBB0_1949:                              ; %cond.store4745
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1013
	b	LBB0_1014
LBB0_1950:                              ; %cond.store4754
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2688]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1016
LBB0_1951:                              ; %cond.store4758
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1017
LBB0_1952:                              ; %cond.store4762
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2672]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1018
LBB0_1953:                              ; %cond.store4766
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8176]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1019
LBB0_1954:                              ; %cond.store4770
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #624]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1020
LBB0_1955:                              ; %cond.store4774
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1021
LBB0_1956:                              ; %cond.store4778
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1022
	b	LBB0_1023
LBB0_1957:                              ; %cond.store4787
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2656]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1025
LBB0_1958:                              ; %cond.store4791
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1026
LBB0_1959:                              ; %cond.store4795
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2640]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1027
LBB0_1960:                              ; %cond.store4799
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8208]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1028
LBB0_1961:                              ; %cond.store4803
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #592]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1029
LBB0_1962:                              ; %cond.store4807
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1030
LBB0_1963:                              ; %cond.store4811
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1031
	b	LBB0_1032
LBB0_1964:                              ; %cond.store4820
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2624]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1034
LBB0_1965:                              ; %cond.store4824
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1035
LBB0_1966:                              ; %cond.store4828
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2608]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1036
LBB0_1967:                              ; %cond.store4832
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8240]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1037
LBB0_1968:                              ; %cond.store4836
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #560]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1038
LBB0_1969:                              ; %cond.store4840
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1039
LBB0_1970:                              ; %cond.store4844
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1040
	b	LBB0_1041
LBB0_1971:                              ; %cond.store4853
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2592]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1043
LBB0_1972:                              ; %cond.store4857
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1044
LBB0_1973:                              ; %cond.store4861
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2576]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1045
LBB0_1974:                              ; %cond.store4865
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8272]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1046
LBB0_1975:                              ; %cond.store4869
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #528]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1047
LBB0_1976:                              ; %cond.store4873
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1048
LBB0_1977:                              ; %cond.store4877
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1049
	b	LBB0_1050
LBB0_1978:                              ; %cond.store4886
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2560]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1052
LBB0_1979:                              ; %cond.store4890
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1053
LBB0_1980:                              ; %cond.store4894
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2544]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1054
LBB0_1981:                              ; %cond.store4898
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8304]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1055
LBB0_1982:                              ; %cond.store4902
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #496]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1056
LBB0_1983:                              ; %cond.store4906
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1057
LBB0_1984:                              ; %cond.store4910
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1058
	b	LBB0_1059
LBB0_1985:                              ; %cond.store4919
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2528]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1061
LBB0_1986:                              ; %cond.store4923
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1062
LBB0_1987:                              ; %cond.store4927
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2512]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1063
LBB0_1988:                              ; %cond.store4931
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8336]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1064
LBB0_1989:                              ; %cond.store4935
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #464]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1065
LBB0_1990:                              ; %cond.store4939
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1066
LBB0_1991:                              ; %cond.store4943
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1067
	b	LBB0_1068
LBB0_1992:                              ; %cond.store4952
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2496]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1070
LBB0_1993:                              ; %cond.store4956
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1071
LBB0_1994:                              ; %cond.store4960
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2480]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1072
LBB0_1995:                              ; %cond.store4964
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8368]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1073
LBB0_1996:                              ; %cond.store4968
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #432]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1074
LBB0_1997:                              ; %cond.store4972
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1075
LBB0_1998:                              ; %cond.store4976
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1076
	b	LBB0_1077
LBB0_1999:                              ; %cond.store4985
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2464]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1079
LBB0_2000:                              ; %cond.store4989
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1080
LBB0_2001:                              ; %cond.store4993
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2448]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1081
LBB0_2002:                              ; %cond.store4997
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8400]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1082
LBB0_2003:                              ; %cond.store5001
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #400]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1083
LBB0_2004:                              ; %cond.store5005
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1084
LBB0_2005:                              ; %cond.store5009
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1085
	b	LBB0_1086
LBB0_2006:                              ; %cond.store5018
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2432]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1088
LBB0_2007:                              ; %cond.store5022
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1089
LBB0_2008:                              ; %cond.store5026
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2416]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1090
LBB0_2009:                              ; %cond.store5030
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8432]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1091
LBB0_2010:                              ; %cond.store5034
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #368]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1092
LBB0_2011:                              ; %cond.store5038
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1093
LBB0_2012:                              ; %cond.store5042
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1094
	b	LBB0_1095
LBB0_2013:                              ; %cond.store5051
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2400]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1097
LBB0_2014:                              ; %cond.store5055
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1098
LBB0_2015:                              ; %cond.store5059
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2384]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1099
LBB0_2016:                              ; %cond.store5063
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8464]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1100
LBB0_2017:                              ; %cond.store5067
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #336]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1101
LBB0_2018:                              ; %cond.store5071
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1102
LBB0_2019:                              ; %cond.store5075
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1103
	b	LBB0_1104
LBB0_2020:                              ; %cond.store5084
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2368]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1106
LBB0_2021:                              ; %cond.store5088
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1107
LBB0_2022:                              ; %cond.store5092
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2352]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1108
LBB0_2023:                              ; %cond.store5096
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8496]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1109
LBB0_2024:                              ; %cond.store5100
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #304]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1110
LBB0_2025:                              ; %cond.store5104
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1111
LBB0_2026:                              ; %cond.store5108
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1112
	b	LBB0_1113
LBB0_2027:                              ; %cond.store5117
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2336]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1115
LBB0_2028:                              ; %cond.store5121
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1116
LBB0_2029:                              ; %cond.store5125
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2320]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1117
LBB0_2030:                              ; %cond.store5129
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8528]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1118
LBB0_2031:                              ; %cond.store5133
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #272]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1119
LBB0_2032:                              ; %cond.store5137
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1120
LBB0_2033:                              ; %cond.store5141
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1121
	b	LBB0_1122
LBB0_2034:                              ; %cond.store5150
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2304]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1124
LBB0_2035:                              ; %cond.store5154
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1125
LBB0_2036:                              ; %cond.store5158
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2288]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1126
LBB0_2037:                              ; %cond.store5162
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8560]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1127
LBB0_2038:                              ; %cond.store5166
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #240]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1128
LBB0_2039:                              ; %cond.store5170
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1129
LBB0_2040:                              ; %cond.store5174
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1130
	b	LBB0_1131
LBB0_2041:                              ; %cond.store5183
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2272]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1133
LBB0_2042:                              ; %cond.store5187
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1134
LBB0_2043:                              ; %cond.store5191
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2256]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1135
LBB0_2044:                              ; %cond.store5195
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8592]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1136
LBB0_2045:                              ; %cond.store5199
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #208]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1137
LBB0_2046:                              ; %cond.store5203
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1138
LBB0_2047:                              ; %cond.store5207
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1139
	b	LBB0_1140
LBB0_2048:                              ; %cond.store5216
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2240]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1142
LBB0_2049:                              ; %cond.store5220
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1143
LBB0_2050:                              ; %cond.store5224
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2224]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1144
LBB0_2051:                              ; %cond.store5228
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8624]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1145
LBB0_2052:                              ; %cond.store5232
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #176]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1146
LBB0_2053:                              ; %cond.store5236
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1147
LBB0_2054:                              ; %cond.store5240
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1148
	b	LBB0_1149
LBB0_2055:                              ; %cond.store5249
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2208]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1151
LBB0_2056:                              ; %cond.store5253
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1152
LBB0_2057:                              ; %cond.store5257
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2192]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1153
LBB0_2058:                              ; %cond.store5261
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #8656]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1154
LBB0_2059:                              ; %cond.store5265
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #144]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1155
LBB0_2060:                              ; %cond.store5269
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1156
LBB0_2061:                              ; %cond.store5273
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1157
	b	LBB0_1158
LBB0_2062:                              ; %cond.store5282
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2176]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1160
LBB0_2063:                              ; %cond.store5286
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1161
LBB0_2064:                              ; %cond.store5290
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2160]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1162
LBB0_2065:                              ; %cond.store5294
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #6528]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1163
LBB0_2066:                              ; %cond.store5298
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #112]                  ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1164
LBB0_2067:                              ; %cond.store5302
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1165
LBB0_2068:                              ; %cond.store5306
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1166
	b	LBB0_1167
LBB0_2069:                              ; %cond.store5315
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2144]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1169
LBB0_2070:                              ; %cond.store5319
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1170
LBB0_2071:                              ; %cond.store5323
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2128]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1171
LBB0_2072:                              ; %cond.store5327
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	ldr	q3, [sp, #6560]                 ; 16-byte Reload
	fdiv.4s	v3, v3, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1172
LBB0_2073:                              ; %cond.store5331
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #80]                   ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1173
LBB0_2074:                              ; %cond.store5335
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1174
LBB0_2075:                              ; %cond.store5339
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #7, LBB0_1175
	b	LBB0_1176
LBB0_2076:                              ; %cond.store5348
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #2112]                 ; 16-byte Reload
	and.16b	v6, v16, v5
	tbz	w8, #1, LBB0_1178
LBB0_2077:                              ; %cond.store5352
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q4, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v5, v4, #0
	add.2d	v4, v2, v6
	tbz	w8, #2, LBB0_1179
LBB0_2078:                              ; %cond.store5356
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #2096]                 ; 16-byte Reload
	and.16b	v5, v5, v6
	tbz	w8, #3, LBB0_1180
LBB0_2079:                              ; %cond.store5360
	mov.d	x9, v4[1]
	st1.s	{ v3 }[3], [x9]
	fdiv.4s	v3, v10, v17
	add.2d	v4, v2, v5
	tbz	w8, #4, LBB0_1181
LBB0_2080:                              ; %cond.store5364
	fmov	x9, d4
	str	s3, [x9]
	ldr	q5, [sp, #48]                   ; 16-byte Reload
	and.16b	v5, v7, v5
	tbz	w8, #5, LBB0_1182
LBB0_2081:                              ; %cond.store5368
	mov.d	x9, v4[1]
	st1.s	{ v3 }[1], [x9]
	add.2d	v4, v2, v5
	tbz	w8, #6, LBB0_1183
LBB0_2082:                              ; %cond.store5372
	fmov	x9, d4
	st1.s	{ v3 }[2], [x9]
	ldr	q5, [sp, #16]                   ; 16-byte Reload
	tbnz	w8, #7, LBB0_1184
	b	LBB0_1185
LBB0_2083:                              ; %cond.store5381
	fmov	x9, d1
	str	s3, [x9]
	ldr	q0, [sp, #2080]                 ; 16-byte Reload
	and.16b	v4, v16, v0
	tbz	w8, #1, LBB0_1187
LBB0_2084:                              ; %cond.store5385
	mov.d	x9, v1[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q0, [sp, #11296]                ; 16-byte Reload
	sshll.2d	v1, v0, #0
	add.2d	v0, v2, v4
	tbz	w8, #2, LBB0_1188
LBB0_2085:                              ; %cond.store5389
	fmov	x9, d0
	st1.s	{ v3 }[2], [x9]
	ldr	q4, [sp, #2064]                 ; 16-byte Reload
	and.16b	v1, v1, v4
	tbz	w8, #3, LBB0_1189
LBB0_2086:                              ; %cond.store5393
	mov.d	x9, v0[1]
	st1.s	{ v3 }[3], [x9]
	fdiv.4s	v0, v27, v17
	add.2d	v1, v2, v1
	tbz	w8, #4, LBB0_1190
LBB0_2087:                              ; %cond.store5397
	fmov	x9, d1
	str	s0, [x9]
	and.16b	v3, v7, v5
	tbz	w8, #5, LBB0_1191
LBB0_2088:                              ; %cond.store5401
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	add.2d	v1, v2, v3
	tbz	w8, #6, LBB0_1192
LBB0_2089:                              ; %cond.store5405
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1193
	b	LBB0_1194
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

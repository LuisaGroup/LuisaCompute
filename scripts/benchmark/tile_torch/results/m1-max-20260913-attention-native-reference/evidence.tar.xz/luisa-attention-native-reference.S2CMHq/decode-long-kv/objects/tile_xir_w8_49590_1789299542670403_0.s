	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.full_packet
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention.full_packet:             ; @llm_attention.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1904
	mov	x8, #0                          ; =0x0
	ldr	x21, [x1, #136]
	add	x22, x21, #35, lsl #12          ; =143360
	ldr	x9, [x0]
	ldr	x20, [x0, #16]
	ldr	w10, [x1]
	ldr	w11, [x1, #36]
	add	w10, w11, w10, lsl #5
	ldr	x23, [x0, #32]
	dup.4s	v0, w10
	ldr	x10, [x0, #48]
	str	x10, [sp, #88]                  ; 8-byte Spill
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x10, lCPI0_0@PAGEOFF]
	add.4s	v1, v0, v1
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q2, [x10, lCPI0_1@PAGEOFF]
	add.4s	v0, v0, v2
	ushll2.2d	v2, v0, #0
	str	q2, [sp, #1872]                 ; 16-byte Spill
	ushll2.2d	v2, v1, #0
	str	q2, [sp, #1888]                 ; 16-byte Spill
	ushll.2d	v2, v0, #0
	str	q2, [sp, #1840]                 ; 16-byte Spill
	ushll.2d	v2, v1, #0
	str	q2, [sp, #1856]                 ; 16-byte Spill
	ushll2.2d	v5, v0, #9
	ushll2.2d	v6, v1, #9
	ushll.2d	v7, v0, #9
	ushll.2d	v16, v1, #9
	dup.2d	v0, x9
	mov	x9, x21
LBB0_1:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v1, x8
	add.2d	v2, v1, v16
	add.2d	v3, v1, v6
	add.2d	v4, v1, v7
	add.2d	v1, v1, v5
	add.2d	v1, v0, v1
	add.2d	v4, v0, v4
	add.2d	v3, v0, v3
	add.2d	v2, v0, v2
	mov.d	x10, v2[1]
	fmov	x11, d2
	mov.d	x12, v3[1]
	fmov	x13, d3
	mov.d	x14, v4[1]
	fmov	x15, d4
	mov.d	x16, v1[1]
	ldr	s2, [x11]
	ld1.s	{ v2 }[1], [x10]
	fmov	x10, d1
	ld1.s	{ v2 }[2], [x13]
	ld1.s	{ v2 }[3], [x12]
	ldr	s1, [x15]
	ld1.s	{ v1 }[1], [x14]
	ld1.s	{ v1 }[2], [x10]
	ld1.s	{ v1 }[3], [x16]
	stp	q2, q1, [x9], #32
	add	x8, x8, #4
	cmp	x8, #512
	b.ne	LBB0_1
; %bb.2:                                ; %direct.true147.preheader
	stp	q16, q7, [sp, #16]              ; 32-byte Folded Spill
	stp	q6, q5, [sp, #48]               ; 32-byte Folded Spill
	add	x24, x21, #1, lsl #12           ; =4096
	add	x0, x21, #1, lsl #12            ; =4096
	mov	w1, #4096                       ; =0x1000
	bl	_bzero
	mov	x25, #0                         ; =0x0
	add	x26, x21, #3, lsl #12           ; =12288
	add	x27, x21, #19, lsl #12          ; =77824
	add	x28, x22, #512
	add	x8, x21, #35, lsl #12           ; =143360
	add	x19, x8, #1024
	ldr	q0, [sp, #1872]                 ; 16-byte Reload
	shrn.2s	v0, v0, #2
	ldr	q1, [sp, #1840]                 ; 16-byte Reload
	shrn.2s	v1, v1, #2
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	shrn.2s	v2, v2, #2
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	shrn.2s	v3, v3, #2
	mov	w8, #8193                       ; =0x2001
	dup.2s	v4, w8
	umull.2d	v6, v3, v4
	umull.2d	v7, v2, v4
	umull.2d	v16, v1, v4
	umull.2d	v17, v0, v4
	add	x8, x21, #19, lsl #12           ; =77824
	add	x8, x8, #96
	str	x8, [sp, #136]                  ; 8-byte Spill
	mov	w8, #62154                      ; =0xf2ca
	movk	w8, #61769, lsl #16
	dup.4s	v1, w8
	dup.2d	v18, x20
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	stp	q0, q18, [sp, #96]              ; 32-byte Folded Spill
	mov	w20, #3                         ; =0x3
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	mov.16b	v0, v1
	stp	q7, q6, [sp, #176]              ; 32-byte Folded Spill
	stp	q17, q16, [sp, #144]            ; 32-byte Folded Spill
LBB0_3:                                 ; %direct.true157
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_12 Depth 2
                                        ;     Child Loop BB0_14 Depth 2
                                        ;     Child Loop BB0_16 Depth 2
                                        ;     Child Loop BB0_18 Depth 2
                                        ;     Child Loop BB0_20 Depth 2
                                        ;       Child Loop BB0_21 Depth 3
	str	q0, [sp, #1872]                 ; 16-byte Spill
	str	q1, [sp, #1888]                 ; 16-byte Spill
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	lsl	x8, x25, #4
	b	LBB0_5
LBB0_4:                                 ; %direct.schedule.12
                                        ;   in Loop: Header=BB0_5 Depth=2
	add	x11, x26, x10, lsl #5
	stp	q0, q1, [x11]
	add	x10, x10, #1
	add	x9, x9, #4
	cmp	x9, #2, lsl #12                 ; =8192
	b.eq	LBB0_7
LBB0_5:                                 ; %direct.true161
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	orr	x11, x8, x10, lsr #7
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	cmp	x11, #2, lsl #12                ; =8192
	b.hi	LBB0_4
; %bb.6:                                ; %direct.true174
                                        ;   in Loop: Header=BB0_5 Depth=2
	dup.2d	v0, x11
	add.2d	v1, v0, v6
	add.2d	v2, v0, v7
	add.2d	v3, v0, v16
	add.2d	v0, v0, v17
	shl.2d	v0, v0, #9
	shl.2d	v3, v3, #9
	shl.2d	v2, v2, #9
	shl.2d	v1, v1, #9
	and	x11, x9, #0x1fc
	dup.2d	v4, x11
	orr.16b	v1, v1, v4
	orr.16b	v2, v2, v4
	orr.16b	v3, v3, v4
	orr.16b	v0, v0, v4
	add.2d	v4, v18, v0
	add.2d	v0, v18, v3
	add.2d	v2, v18, v2
	add.2d	v1, v18, v1
	mov.d	x11, v1[1]
	fmov	x12, d1
	mov.d	x13, v2[1]
	fmov	x14, d2
	mov.d	x15, v0[1]
	fmov	x16, d0
	mov.d	x17, v4[1]
	ldr	s0, [x12]
	ld1.s	{ v0 }[1], [x11]
	fmov	x11, d4
	ld1.s	{ v0 }[2], [x14]
	ld1.s	{ v0 }[3], [x13]
	ldr	s1, [x16]
	ld1.s	{ v1 }[1], [x15]
	ld1.s	{ v1 }[2], [x11]
	ld1.s	{ v1 }[3], [x17]
	b	LBB0_4
LBB0_7:                                 ; %direct.true186.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	b	LBB0_9
LBB0_8:                                 ; %direct.schedule.17
                                        ;   in Loop: Header=BB0_9 Depth=2
	add	x11, x27, x10, lsl #5
	stp	q0, q1, [x11]
	add	x10, x10, #1
	add	x9, x9, #4
	cmp	x9, #2, lsl #12                 ; =8192
	b.eq	LBB0_11
LBB0_9:                                 ; %direct.true186
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	orr	x11, x8, x10, lsr #7
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	cmp	x11, #2, lsl #12                ; =8192
	b.hi	LBB0_8
; %bb.10:                               ; %direct.true199
                                        ;   in Loop: Header=BB0_9 Depth=2
	dup.2d	v0, x11
	add.2d	v1, v0, v6
	add.2d	v2, v0, v7
	add.2d	v3, v0, v16
	add.2d	v0, v0, v17
	shl.2d	v0, v0, #9
	shl.2d	v3, v3, #9
	shl.2d	v2, v2, #9
	shl.2d	v1, v1, #9
	and	x11, x9, #0x1fc
	dup.2d	v4, x11
	orr.16b	v1, v1, v4
	orr.16b	v2, v2, v4
	orr.16b	v3, v3, v4
	orr.16b	v0, v0, v4
	dup.2d	v4, x23
	add.2d	v5, v4, v0
	add.2d	v0, v4, v3
	add.2d	v2, v4, v2
	add.2d	v1, v4, v1
	mov.d	x11, v1[1]
	fmov	x12, d1
	mov.d	x13, v2[1]
	fmov	x14, d2
	mov.d	x15, v0[1]
	fmov	x16, d0
	mov.d	x17, v5[1]
	ldr	s0, [x12]
	ld1.s	{ v0 }[1], [x11]
	fmov	x11, d5
	ld1.s	{ v0 }[2], [x14]
	ld1.s	{ v0 }[3], [x13]
	ldr	s1, [x16]
	ld1.s	{ v1 }[1], [x15]
	ld1.s	{ v1 }[2], [x11]
	ld1.s	{ v1 }[3], [x17]
	b	LBB0_8
LBB0_11:                                ; %direct.true211.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q20, [sp, #1456]                ; 16-byte Spill
	str	q19, [sp, #1472]                ; 16-byte Spill
	movi.2d	v1, #0000000000000000
	mov	x8, x21
	movi.2d	v0, #0000000000000000
	mov	w9, #128                        ; =0x80
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
LBB0_12:                                ; %direct.true211
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q16, [x8]
	ldr	q18, [x8, #12304]
	ldr	q19, [x8, #12288]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v1, v1, v18
	fadd.4s	v7, v7, v19
	ldr	q18, [x8, #16400]
	ldr	q19, [x8, #16384]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v6, v6, v18
	fadd.4s	v5, v5, v19
	ldr	q18, [x8, #20496]
	ldr	q19, [x8, #20480]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v19
	ldr	q18, [x8, #24592]
	ldr	q19, [x8, #24576]
	fmul.4s	v17, v17, v19
	fmul.4s	v16, v16, v18
	fadd.4s	v2, v2, v16
	fadd.4s	v0, v0, v17
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_12
; %bb.13:                               ; %direct.true247.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v17, #0000000000000000
	mov	x8, x21
	movi.2d	v16, #0000000000000000
	mov	w9, #128                        ; =0x80
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
LBB0_14:                                ; %direct.true247
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q25, q24, [x8]
	ldr	q26, [x8, #28688]
	ldr	q27, [x8, #28672]
	fmul.4s	v27, v25, v27
	fmul.4s	v26, v24, v26
	fadd.4s	v17, v17, v26
	fadd.4s	v23, v23, v27
	ldr	q26, [x8, #32784]
	ldr	q27, [x8, #32768]
	fmul.4s	v27, v25, v27
	fmul.4s	v26, v24, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v21, v21, v27
	ldr	q26, [x8, #36880]
	ldr	q27, [x8, #36864]
	fmul.4s	v27, v25, v27
	fmul.4s	v26, v24, v26
	fadd.4s	v20, v20, v26
	fadd.4s	v19, v19, v27
	ldr	q26, [x8, #40976]
	ldr	q27, [x8, #40960]
	fmul.4s	v25, v25, v27
	fmul.4s	v24, v24, v26
	fadd.4s	v18, v18, v24
	fadd.4s	v16, v16, v25
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_14
; %bb.15:                               ; %direct.true285.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q3, [sp, #1808]                 ; 16-byte Spill
	str	q1, [sp, #1840]                 ; 16-byte Spill
	movi.2d	v25, #0000000000000000
	mov	x8, x21
	movi.2d	v24, #0000000000000000
	mov	w9, #128                        ; =0x80
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
LBB0_16:                                ; %direct.true285
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q9, q8, [x8]
	ldr	q10, [x8, #45072]
	ldr	q11, [x8, #45056]
	fmul.4s	v11, v9, v11
	fmul.4s	v10, v8, v10
	fadd.4s	v25, v25, v10
	fadd.4s	v31, v31, v11
	ldr	q10, [x8, #49168]
	ldr	q11, [x8, #49152]
	fmul.4s	v11, v9, v11
	fmul.4s	v10, v8, v10
	fadd.4s	v30, v30, v10
	fadd.4s	v29, v29, v11
	ldr	q10, [x8, #53264]
	ldr	q11, [x8, #53248]
	fmul.4s	v11, v9, v11
	fmul.4s	v10, v8, v10
	fadd.4s	v28, v28, v10
	fadd.4s	v27, v27, v11
	ldr	q10, [x8, #57360]
	ldr	q11, [x8, #57344]
	fmul.4s	v9, v9, v11
	fmul.4s	v8, v8, v10
	fadd.4s	v26, v26, v8
	fadd.4s	v24, v24, v9
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_16
; %bb.17:                               ; %direct.true323.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q2, [sp, #1824]                 ; 16-byte Spill
	str	q0, [sp, #1856]                 ; 16-byte Spill
	movi.2d	v9, #0000000000000000
	mov	x8, x21
	movi.2d	v8, #0000000000000000
	mov	w9, #128                        ; =0x80
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v15, #0000000000000000
LBB0_18:                                ; %direct.true323
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8]
	ldr	q2, [x8, #61456]
	ldr	q3, [x8, #61440]
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fadd.4s	v9, v9, v2
	fadd.4s	v15, v15, v3
	add	x10, x8, #16, lsl #12           ; =65536
	ldp	q3, q2, [x10]
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fadd.4s	v14, v14, v2
	fadd.4s	v13, v13, v3
	add	x10, x8, #17, lsl #12           ; =69632
	ldp	q3, q2, [x10]
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fadd.4s	v12, v12, v2
	fadd.4s	v11, v11, v3
	add	x10, x8, #18, lsl #12           ; =73728
	ldp	q3, q2, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v10, v10, v0
	fadd.4s	v8, v8, v1
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_18
; %bb.19:                               ; %direct.false324
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	mov	w9, #1267                       ; =0x4f3
	movk	w9, #15797, lsl #16
	dup.4s	v2, w9
	fmul.4s	v0, v7, v2
	str	q0, [sp, #1712]                 ; 16-byte Spill
	ldr	q0, [sp, #1840]                 ; 16-byte Reload
	fmul.4s	v0, v0, v2
	str	q0, [sp, #1552]                 ; 16-byte Spill
	fmul.4s	v6, v6, v2
	fmul.4s	v5, v5, v2
	fmul.4s	v4, v4, v2
	ldr	q0, [sp, #1808]                 ; 16-byte Reload
	fmul.4s	v7, v0, v2
	ldr	q0, [sp, #1824]                 ; 16-byte Reload
	fmul.4s	v0, v0, v2
	ldr	q1, [sp, #1856]                 ; 16-byte Reload
	fmul.4s	v1, v1, v2
	fmul.4s	v17, v17, v2
	fmul.4s	v23, v23, v2
	fmul.4s	v22, v22, v2
	fmul.4s	v21, v21, v2
	fmul.4s	v20, v20, v2
	fmul.4s	v19, v19, v2
	fmul.4s	v3, v18, v2
	fmul.4s	v16, v16, v2
	fmul.4s	v25, v25, v2
	fmul.4s	v31, v31, v2
	fmul.4s	v30, v30, v2
	fmul.4s	v29, v29, v2
	fmul.4s	v28, v28, v2
	fmul.4s	v27, v27, v2
	fmul.4s	v26, v26, v2
	fmul.4s	v24, v24, v2
	fmul.4s	v9, v9, v2
	fmul.4s	v15, v15, v2
	fmul.4s	v14, v14, v2
	fmul.4s	v13, v13, v2
	fmul.4s	v12, v12, v2
	fmul.4s	v11, v11, v2
	fmul.4s	v18, v10, v2
	str	q18, [sp, #1440]                ; 16-byte Spill
	fmul.4s	v10, v8, v2
	cmp	x25, #512
	cset	w9, lo
	dup.4h	v2, w9
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	str	q2, [sp, #1408]                 ; 16-byte Spill
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v8, w9
	bif.16b	v5, v8, v2
	bif.16b	v6, v8, v2
	str	q6, [sp, #1536]                 ; 16-byte Spill
	mov.16b	v6, v2
	bsl.16b	v6, v7, v8
	str	q6, [sp, #1808]                 ; 16-byte Spill
	bif.16b	v4, v8, v2
	str	q4, [sp, #1520]                 ; 16-byte Spill
	mov.16b	v4, v2
	bsl.16b	v4, v1, v8
	str	q4, [sp, #1856]                 ; 16-byte Spill
	bif.16b	v0, v8, v2
	str	q0, [sp, #1504]                 ; 16-byte Spill
	mov.16b	v7, v2
	bsl.16b	v7, v23, v8
	str	q7, [sp, #1792]                 ; 16-byte Spill
	mov.16b	v23, v2
	bsl.16b	v23, v17, v8
	str	q23, [sp, #1568]                ; 16-byte Spill
	mov.16b	v17, v2
	bsl.16b	v17, v21, v8
	str	q17, [sp, #1840]                ; 16-byte Spill
	mov.16b	v21, v2
	bsl.16b	v21, v22, v8
	str	q21, [sp, #1584]                ; 16-byte Spill
	bif.16b	v19, v8, v2
	str	q19, [sp, #1776]                ; 16-byte Spill
	bif.16b	v20, v8, v2
	str	q20, [sp, #1600]                ; 16-byte Spill
	bif.16b	v16, v8, v2
	str	q16, [sp, #1824]                ; 16-byte Spill
	mov.16b	v22, v2
	bsl.16b	v22, v3, v8
	str	q22, [sp, #1616]                ; 16-byte Spill
	mov.16b	v3, v2
	bsl.16b	v3, v31, v8
	str	q3, [sp, #1760]                 ; 16-byte Spill
	mov.16b	v31, v2
	bsl.16b	v31, v25, v8
	str	q31, [sp, #1632]                ; 16-byte Spill
	mov.16b	v25, v2
	bsl.16b	v25, v29, v8
	str	q25, [sp, #1744]                ; 16-byte Spill
	mov.16b	v29, v2
	bsl.16b	v29, v30, v8
	str	q29, [sp, #1648]                ; 16-byte Spill
	bif.16b	v27, v8, v2
	str	q27, [sp, #1728]                ; 16-byte Spill
	bif.16b	v28, v8, v2
	str	q28, [sp, #1664]                ; 16-byte Spill
	mov.16b	v18, v2
	bsl.16b	v18, v24, v8
	str	q18, [sp, #1696]                ; 16-byte Spill
	mov.16b	v24, v2
	bsl.16b	v24, v26, v8
	str	q24, [sp, #1680]                ; 16-byte Spill
	mov.16b	v26, v2
	bsl.16b	v26, v15, v8
	str	q26, [sp, #1488]                ; 16-byte Spill
	mov.16b	v15, v2
	bsl.16b	v15, v9, v8
	mov.16b	v9, v2
	bsl.16b	v9, v13, v8
	str	q9, [sp, #1056]                 ; 16-byte Spill
	bif.16b	v14, v8, v2
	bif.16b	v11, v8, v2
	str	q11, [sp, #1152]                ; 16-byte Spill
	bif.16b	v12, v8, v2
	str	q12, [sp, #1136]                ; 16-byte Spill
	mov.16b	v30, v2
	bsl.16b	v30, v10, v8
	str	q30, [sp, #1248]                ; 16-byte Spill
	ldr	q0, [sp, #1440]                 ; 16-byte Reload
	bsl.16b	v2, v0, v8
	str	q2, [sp, #1232]                 ; 16-byte Spill
	mvni.4s	v0, #127, msl #16
	ldr	q1, [sp, #1712]                 ; 16-byte Reload
	fmaxnm.4s	v0, v1, v0
	mvni.4s	v10, #127, msl #16
	fmaxnm.4s	v0, v0, v5
	mov.16b	v8, v5
	str	q5, [sp, #1328]                 ; 16-byte Spill
	fmaxnm.4s	v0, v0, v6
	fmaxnm.4s	v0, v0, v4
	fmaxnm.4s	v0, v0, v7
	fmaxnm.4s	v0, v0, v17
	fmaxnm.4s	v0, v0, v19
	fmaxnm.4s	v0, v0, v16
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v0, v0, v25
	fmaxnm.4s	v0, v0, v27
	fmaxnm.4s	v0, v0, v18
	fmaxnm.4s	v0, v0, v26
	fmaxnm.4s	v0, v0, v9
	fmaxnm.4s	v0, v0, v11
	fmaxnm.4s	v0, v0, v30
	ldr	q3, [sp, #1888]                 ; 16-byte Reload
	fmaxnm.4s	v9, v3, v0
	fsub.4s	v27, v1, v9
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v16, w9
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v7, w9
	fcmge.4s	v0, v27, v16
	fcmge.4s	v1, v7, v27
	and.16b	v0, v0, v1
	ldr	q3, [sp, #1552]                 ; 16-byte Reload
	fmaxnm.4s	v1, v3, v10
	ldr	q10, [sp, #1536]                ; 16-byte Reload
	fmaxnm.4s	v1, v1, v10
	ldr	q11, [sp, #1520]                ; 16-byte Reload
	fmaxnm.4s	v1, v1, v11
	ldr	q13, [sp, #1504]                ; 16-byte Reload
	fmaxnm.4s	v1, v1, v13
	fmaxnm.4s	v1, v1, v23
	fmaxnm.4s	v1, v1, v21
	fmaxnm.4s	v1, v1, v20
	fmaxnm.4s	v1, v1, v22
	fmaxnm.4s	v1, v1, v31
	fmaxnm.4s	v1, v1, v29
	fmaxnm.4s	v1, v1, v28
	fmaxnm.4s	v1, v1, v24
	fmaxnm.4s	v1, v1, v15
	str	q15, [sp, #544]                 ; 16-byte Spill
	fmaxnm.4s	v1, v1, v14
	fmaxnm.4s	v1, v1, v12
	fmaxnm.4s	v1, v1, v2
	ldr	q2, [sp, #1872]                 ; 16-byte Reload
	fmaxnm.4s	v12, v2, v1
	fsub.4s	v18, v3, v12
	fcmge.4s	v1, v18, v16
	fcmge.4s	v3, v7, v18
	and.16b	v1, v1, v3
	and.16b	v1, v1, v18
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v19, w9
	fmul.4s	v3, v1, v19
	movi.4s	v28, #75, lsl #24
	mvni.4s	v29, #128, lsl #24
	mov.16b	v4, v29
	bsl.16b	v4, v28, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v27
	fmul.4s	v0, v4, v19
	mov.16b	v5, v29
	bsl.16b	v5, v28, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	mov	w9, #29184                      ; =0x7200
	movk	w9, #16177, lsl #16
	dup.4s	v20, w9
	fmul.4s	v6, v3, v20
	fsub.4s	v6, v1, v6
	fcvtzs.4s	v1, v5
	scvtf.4s	v5, v1
	fmul.4s	v17, v5, v20
	fsub.4s	v4, v4, v17
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #13759, lsl #16
	dup.4s	v21, w9
	fmul.4s	v5, v5, v21
	fsub.4s	v4, v4, v5
	fmul.4s	v3, v3, v21
	fsub.4s	v3, v6, v3
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v22, w9
	fmul.4s	v5, v3, v22
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v23, w9
	fadd.4s	v5, v5, v23
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v24, w9
	fmul.4s	v5, v3, v5
	fadd.4s	v5, v5, v24
	fmul.4s	v5, v3, v5
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v25, w9
	fadd.4s	v5, v5, v25
	fmul.4s	v5, v3, v5
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v26, w9
	fadd.4s	v5, v5, v26
	fmul.4s	v5, v3, v5
	movi.4s	v30, #63, lsl #24
	fadd.4s	v5, v5, v30
	fmul.4s	v6, v3, v3
	fmul.4s	v5, v6, v5
	fmul.4s	v6, v4, v22
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v25
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v17, v4, v4
	fmul.4s	v6, v17, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v3, v3, v5
	fmov.4s	v31, #1.00000000
	fadd.4s	v4, v4, v31
	sshr.4s	v5, v1, #1
	shl.4s	v6, v5, #23
	add.4s	v6, v6, v31
	fmul.4s	v4, v4, v6
	fadd.4s	v3, v3, v31
	sshr.4s	v6, v0, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v31
	fmul.4s	v3, v3, v17
	sub.4s	v1, v1, v5
	sub.4s	v0, v0, v6
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v3, v0
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v4, v1
	mov.16b	v2, v27
	str	q27, [sp, #1344]                ; 16-byte Spill
	fcmgt.4s	v3, v16, v27
	bic.16b	v1, v1, v3
	str	q18, [sp, #1392]                ; 16-byte Spill
	fcmgt.4s	v3, v16, v18
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v18, v7
	mvni.4s	v4, #127, msl #16
	fneg.4s	v27, v4
	bit.16b	v0, v27, v3
	str	q0, [sp, #1376]                 ; 16-byte Spill
	fcmgt.4s	v0, v2, v7
	bsl.16b	v0, v27, v1
	str	q0, [sp, #1360]                 ; 16-byte Spill
	fsub.4s	v18, v10, v12
	fcmge.4s	v0, v18, v16
	fcmge.4s	v1, v7, v18
	and.16b	v0, v0, v1
	fsub.4s	v2, v8, v9
	fcmge.4s	v1, v2, v16
	fcmge.4s	v3, v7, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v19
	mov.16b	v4, v29
	bsl.16b	v4, v28, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v18
	fmul.4s	v0, v4, v19
	mov.16b	v5, v29
	bsl.16b	v5, v28, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v6, v3, v20
	fsub.4s	v1, v1, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	fmul.4s	v17, v6, v20
	fsub.4s	v4, v4, v17
	fmul.4s	v6, v6, v21
	fsub.4s	v4, v4, v6
	fmul.4s	v3, v3, v21
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v22
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v24
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v26
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v30
	fmul.4s	v6, v1, v1
	fmul.4s	v3, v6, v3
	fmul.4s	v6, v4, v22
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v25
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v17, v4, v4
	fmul.4s	v6, v17, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v31
	sshr.4s	v4, v5, #1
	shl.4s	v6, v4, #23
	add.4s	v6, v6, v31
	fmul.4s	v3, v3, v6
	fadd.4s	v1, v1, v31
	sshr.4s	v6, v0, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v31
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v6
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v3, v1
	str	q18, [sp, #1264]                ; 16-byte Spill
	fcmgt.4s	v3, v16, v18
	bic.16b	v1, v1, v3
	str	q2, [sp, #1296]                 ; 16-byte Spill
	fcmgt.4s	v3, v16, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v7
	bit.16b	v0, v27, v3
	str	q0, [sp, #1312]                 ; 16-byte Spill
	fcmgt.4s	v0, v18, v7
	bsl.16b	v0, v27, v1
	str	q0, [sp, #1280]                 ; 16-byte Spill
	fsub.4s	v18, v11, v12
	fcmge.4s	v0, v18, v16
	fcmge.4s	v1, v7, v18
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1808]                 ; 16-byte Reload
	fsub.4s	v2, v1, v9
	fcmge.4s	v1, v2, v16
	fcmge.4s	v3, v7, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v19
	mov.16b	v4, v29
	bsl.16b	v4, v28, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v18
	fmul.4s	v0, v4, v19
	mov.16b	v5, v29
	bsl.16b	v5, v28, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v6, v3, v20
	fsub.4s	v1, v1, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	fmul.4s	v17, v6, v20
	fsub.4s	v4, v4, v17
	fmul.4s	v6, v6, v21
	fsub.4s	v4, v4, v6
	fmul.4s	v3, v3, v21
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v22
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v24
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v26
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v30
	fmul.4s	v6, v1, v1
	fmul.4s	v3, v6, v3
	fmul.4s	v6, v4, v22
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v25
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v17, v4, v4
	fmul.4s	v6, v17, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v31
	sshr.4s	v4, v5, #1
	shl.4s	v6, v4, #23
	add.4s	v6, v6, v31
	fmul.4s	v3, v3, v6
	fadd.4s	v1, v1, v31
	sshr.4s	v6, v0, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v31
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v6
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v3, v1
	str	q18, [sp, #1168]                ; 16-byte Spill
	fcmgt.4s	v3, v16, v18
	bic.16b	v1, v1, v3
	str	q2, [sp, #1200]                 ; 16-byte Spill
	fcmgt.4s	v3, v16, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v7
	bit.16b	v0, v27, v3
	str	q0, [sp, #1216]                 ; 16-byte Spill
	fcmgt.4s	v0, v18, v7
	bsl.16b	v0, v27, v1
	str	q0, [sp, #1184]                 ; 16-byte Spill
	fsub.4s	v18, v13, v12
	fcmge.4s	v0, v18, v16
	fcmge.4s	v1, v7, v18
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1856]                 ; 16-byte Reload
	fsub.4s	v2, v1, v9
	fcmge.4s	v1, v2, v16
	fcmge.4s	v3, v7, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v19
	mov.16b	v4, v29
	bsl.16b	v4, v28, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v18
	fmul.4s	v0, v4, v19
	mov.16b	v5, v29
	bsl.16b	v5, v28, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v6, v3, v20
	fsub.4s	v1, v1, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	fmul.4s	v17, v6, v20
	fsub.4s	v4, v4, v17
	fmul.4s	v6, v6, v21
	fsub.4s	v4, v4, v6
	fmul.4s	v3, v3, v21
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v22
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v24
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v26
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v30
	fmul.4s	v6, v1, v1
	fmul.4s	v3, v6, v3
	fmul.4s	v6, v4, v22
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v25
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v17, v4, v4
	fmul.4s	v6, v17, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v31
	sshr.4s	v4, v5, #1
	shl.4s	v6, v4, #23
	add.4s	v6, v6, v31
	fmul.4s	v3, v3, v6
	fadd.4s	v1, v1, v31
	sshr.4s	v6, v0, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v31
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v6
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v3, v1
	str	q18, [sp, #1072]                ; 16-byte Spill
	fcmgt.4s	v3, v16, v18
	bic.16b	v1, v1, v3
	str	q2, [sp, #1104]                 ; 16-byte Spill
	fcmgt.4s	v3, v16, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v7
	bit.16b	v0, v27, v3
	str	q0, [sp, #1120]                 ; 16-byte Spill
	fcmgt.4s	v0, v18, v7
	bsl.16b	v0, v27, v1
	str	q0, [sp, #1088]                 ; 16-byte Spill
	ldr	q0, [sp, #1568]                 ; 16-byte Reload
	fsub.4s	v18, v0, v12
	fcmge.4s	v0, v18, v16
	fcmge.4s	v1, v7, v18
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	fsub.4s	v2, v1, v9
	fcmge.4s	v1, v2, v16
	fcmge.4s	v3, v7, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v19
	mov.16b	v4, v29
	bsl.16b	v4, v28, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v18
	fmul.4s	v0, v4, v19
	mov.16b	v5, v29
	bsl.16b	v5, v28, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v6, v3, v20
	fsub.4s	v1, v1, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	fmul.4s	v17, v6, v20
	fsub.4s	v4, v4, v17
	fmul.4s	v6, v6, v21
	fsub.4s	v4, v4, v6
	fmul.4s	v3, v3, v21
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v22
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v24
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v26
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v30
	fmul.4s	v6, v1, v1
	fmul.4s	v3, v6, v3
	fmul.4s	v6, v4, v22
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v25
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v17, v4, v4
	fmul.4s	v6, v17, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v31
	sshr.4s	v4, v5, #1
	shl.4s	v6, v4, #23
	add.4s	v6, v6, v31
	fmul.4s	v3, v3, v6
	fadd.4s	v1, v1, v31
	sshr.4s	v6, v0, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v31
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v6
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v16, v18
	bic.16b	v1, v1, v3
	str	q2, [sp, #1024]                 ; 16-byte Spill
	fcmgt.4s	v3, v16, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v7
	bit.16b	v0, v27, v3
	str	q0, [sp, #1040]                 ; 16-byte Spill
	fcmgt.4s	v0, v18, v7
	bsl.16b	v0, v27, v1
	stp	q18, q0, [sp, #992]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1584]                 ; 16-byte Reload
	fsub.4s	v18, v0, v12
	fcmge.4s	v0, v18, v16
	fcmge.4s	v1, v7, v18
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1840]                 ; 16-byte Reload
	fsub.4s	v2, v1, v9
	fcmge.4s	v1, v2, v16
	fcmge.4s	v3, v7, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v19
	mov.16b	v4, v29
	bsl.16b	v4, v28, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v18
	fmul.4s	v0, v4, v19
	mov.16b	v5, v29
	bsl.16b	v5, v28, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v6, v3, v20
	fsub.4s	v1, v1, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	fmul.4s	v17, v6, v20
	fsub.4s	v4, v4, v17
	fmul.4s	v6, v6, v21
	fsub.4s	v4, v4, v6
	fmul.4s	v3, v3, v21
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v22
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v24
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v26
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v30
	fmul.4s	v6, v1, v1
	fmul.4s	v3, v6, v3
	fmul.4s	v6, v4, v22
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v25
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v17, v4, v4
	fmul.4s	v6, v17, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v31
	sshr.4s	v4, v5, #1
	shl.4s	v6, v4, #23
	add.4s	v6, v6, v31
	fmul.4s	v3, v3, v6
	fadd.4s	v1, v1, v31
	sshr.4s	v6, v0, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v31
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v6
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v16, v18
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v16, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v7
	bit.16b	v0, v27, v3
	stp	q2, q0, [sp, #960]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v18, v7
	bsl.16b	v0, v27, v1
	stp	q18, q0, [sp, #928]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1600]                 ; 16-byte Reload
	fsub.4s	v18, v0, v12
	fcmge.4s	v0, v18, v16
	fcmge.4s	v1, v7, v18
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1776]                 ; 16-byte Reload
	fsub.4s	v2, v1, v9
	fcmge.4s	v1, v2, v16
	fcmge.4s	v3, v7, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v19
	mov.16b	v4, v29
	bsl.16b	v4, v28, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v18
	fmul.4s	v0, v4, v19
	mov.16b	v5, v29
	bsl.16b	v5, v28, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v6, v3, v20
	fsub.4s	v1, v1, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	fmul.4s	v17, v6, v20
	fsub.4s	v4, v4, v17
	fmul.4s	v6, v6, v21
	fsub.4s	v4, v4, v6
	fmul.4s	v3, v3, v21
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v22
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v24
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v26
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v30
	fmul.4s	v6, v1, v1
	fmul.4s	v3, v6, v3
	fmul.4s	v6, v4, v22
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v25
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v17, v4, v4
	fmul.4s	v6, v17, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v31
	sshr.4s	v4, v5, #1
	shl.4s	v6, v4, #23
	add.4s	v6, v6, v31
	fmul.4s	v3, v3, v6
	fadd.4s	v1, v1, v31
	sshr.4s	v6, v0, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v31
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v6
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v16, v18
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v16, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v7
	bit.16b	v0, v27, v3
	stp	q2, q0, [sp, #896]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v18, v7
	bsl.16b	v0, v27, v1
	stp	q18, q0, [sp, #864]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1616]                 ; 16-byte Reload
	fsub.4s	v18, v0, v12
	fcmge.4s	v0, v18, v16
	fcmge.4s	v1, v7, v18
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1824]                 ; 16-byte Reload
	fsub.4s	v2, v1, v9
	fcmge.4s	v1, v2, v16
	fcmge.4s	v3, v7, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v19
	mov.16b	v4, v29
	bsl.16b	v4, v28, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v18
	fmul.4s	v0, v4, v19
	mov.16b	v5, v29
	bsl.16b	v5, v28, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v6, v3, v20
	fsub.4s	v1, v1, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	fmul.4s	v17, v6, v20
	fsub.4s	v4, v4, v17
	fmul.4s	v6, v6, v21
	fsub.4s	v4, v4, v6
	fmul.4s	v3, v3, v21
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v22
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v24
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v26
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v30
	fmul.4s	v6, v1, v1
	fmul.4s	v3, v6, v3
	fmul.4s	v6, v4, v22
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v25
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v17, v4, v4
	fmul.4s	v6, v17, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v31
	sshr.4s	v4, v5, #1
	shl.4s	v6, v4, #23
	add.4s	v6, v6, v31
	fmul.4s	v3, v3, v6
	fadd.4s	v1, v1, v31
	sshr.4s	v6, v0, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v31
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v6
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v16, v18
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v16, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v7
	bit.16b	v0, v27, v3
	stp	q2, q0, [sp, #832]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v18, v7
	bsl.16b	v0, v27, v1
	stp	q18, q0, [sp, #800]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1632]                 ; 16-byte Reload
	fsub.4s	v18, v0, v12
	fcmge.4s	v0, v18, v16
	fcmge.4s	v1, v7, v18
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1760]                 ; 16-byte Reload
	fsub.4s	v2, v1, v9
	fcmge.4s	v1, v2, v16
	fcmge.4s	v3, v7, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v19
	mov.16b	v4, v29
	bsl.16b	v4, v28, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v18
	fmul.4s	v0, v4, v19
	mov.16b	v5, v29
	bsl.16b	v5, v28, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v6, v3, v20
	fsub.4s	v1, v1, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	fmul.4s	v17, v6, v20
	fsub.4s	v4, v4, v17
	fmul.4s	v6, v6, v21
	fsub.4s	v4, v4, v6
	fmul.4s	v3, v3, v21
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v22
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v24
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v26
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v30
	fmul.4s	v6, v1, v1
	fmul.4s	v3, v6, v3
	fmul.4s	v6, v4, v22
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v25
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v17, v4, v4
	fmul.4s	v6, v17, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v31
	sshr.4s	v4, v5, #1
	shl.4s	v6, v4, #23
	add.4s	v6, v6, v31
	fmul.4s	v3, v3, v6
	fadd.4s	v1, v1, v31
	sshr.4s	v6, v0, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v31
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v6
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v16, v18
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v16, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v7
	bit.16b	v0, v27, v3
	stp	q2, q0, [sp, #768]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v18, v7
	bsl.16b	v0, v27, v1
	stp	q18, q0, [sp, #736]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1648]                 ; 16-byte Reload
	fsub.4s	v8, v0, v12
	fcmge.4s	v0, v8, v16
	fcmge.4s	v1, v7, v8
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1744]                 ; 16-byte Reload
	fsub.4s	v2, v1, v9
	fcmge.4s	v1, v2, v16
	fcmge.4s	v3, v7, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v19
	mov.16b	v4, v29
	bsl.16b	v4, v28, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v8
	fmul.4s	v0, v4, v19
	mov.16b	v5, v29
	bsl.16b	v5, v28, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v6, v3, v20
	fsub.4s	v1, v1, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	fmul.4s	v17, v6, v20
	fsub.4s	v4, v4, v17
	fmul.4s	v6, v6, v21
	fsub.4s	v4, v4, v6
	fmul.4s	v3, v3, v21
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v22
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v24
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v26
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v30
	fmul.4s	v6, v1, v1
	fmul.4s	v3, v6, v3
	fmul.4s	v6, v4, v22
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v25
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v17, v4, v4
	fmul.4s	v6, v17, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v31
	sshr.4s	v4, v5, #1
	shl.4s	v6, v4, #23
	add.4s	v6, v6, v31
	fmul.4s	v3, v3, v6
	fadd.4s	v1, v1, v31
	sshr.4s	v6, v0, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v31
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v6
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v3, v1
	str	q8, [sp, #336]                  ; 16-byte Spill
	fcmgt.4s	v3, v16, v8
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v16, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v7
	bit.16b	v0, v27, v3
	stp	q2, q0, [sp, #704]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v8, v7
	bsl.16b	v0, v27, v1
	str	q0, [sp, #688]                  ; 16-byte Spill
	ldr	q0, [sp, #1664]                 ; 16-byte Reload
	fsub.4s	v18, v0, v12
	fcmge.4s	v0, v18, v16
	fcmge.4s	v1, v7, v18
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1728]                 ; 16-byte Reload
	fsub.4s	v2, v1, v9
	fcmge.4s	v1, v2, v16
	fcmge.4s	v3, v7, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v19
	mov.16b	v4, v29
	bsl.16b	v4, v28, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v18
	fmul.4s	v0, v4, v19
	mov.16b	v5, v29
	bsl.16b	v5, v28, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v6, v3, v20
	fsub.4s	v1, v1, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	fmul.4s	v17, v6, v20
	fsub.4s	v4, v4, v17
	fmul.4s	v6, v6, v21
	fsub.4s	v4, v4, v6
	fmul.4s	v3, v3, v21
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v22
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v24
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v26
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v30
	fmul.4s	v6, v1, v1
	fmul.4s	v3, v6, v3
	fmul.4s	v6, v4, v22
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v25
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v17, v4, v4
	fmul.4s	v6, v17, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v31
	sshr.4s	v4, v5, #1
	shl.4s	v6, v4, #23
	add.4s	v6, v6, v31
	fmul.4s	v3, v3, v6
	fadd.4s	v1, v1, v31
	sshr.4s	v6, v0, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v31
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v6
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v16, v18
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v16, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v7
	bit.16b	v0, v27, v3
	stp	q2, q0, [sp, #656]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v18, v7
	bsl.16b	v0, v27, v1
	stp	q18, q0, [sp, #624]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1680]                 ; 16-byte Reload
	fsub.4s	v18, v0, v12
	fcmge.4s	v0, v18, v16
	fcmge.4s	v1, v7, v18
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1696]                 ; 16-byte Reload
	fsub.4s	v2, v1, v9
	fcmge.4s	v1, v2, v16
	fcmge.4s	v3, v7, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v19
	mov.16b	v4, v29
	bsl.16b	v4, v28, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v18
	fmul.4s	v0, v4, v19
	mov.16b	v5, v29
	bsl.16b	v5, v28, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v6, v3, v20
	fsub.4s	v1, v1, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	fmul.4s	v17, v6, v20
	fsub.4s	v4, v4, v17
	fmul.4s	v6, v6, v21
	fsub.4s	v4, v4, v6
	fmul.4s	v3, v3, v21
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v22
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v24
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v26
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v30
	fmul.4s	v6, v1, v1
	fmul.4s	v3, v6, v3
	fmul.4s	v6, v4, v22
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v25
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v17, v4, v4
	fmul.4s	v6, v17, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v31
	sshr.4s	v4, v5, #1
	shl.4s	v6, v4, #23
	add.4s	v6, v6, v31
	fmul.4s	v3, v3, v6
	fadd.4s	v1, v1, v31
	sshr.4s	v6, v0, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v31
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v6
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v16, v18
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v16, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v7
	bit.16b	v0, v27, v3
	stp	q2, q0, [sp, #592]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v18, v7
	bsl.16b	v0, v27, v1
	stp	q18, q0, [sp, #560]             ; 32-byte Folded Spill
	fsub.4s	v18, v15, v12
	fcmge.4s	v0, v18, v16
	fcmge.4s	v1, v7, v18
	and.16b	v0, v0, v1
	ldr	q1, [sp, #1488]                 ; 16-byte Reload
	fsub.4s	v2, v1, v9
	fcmge.4s	v1, v2, v16
	fcmge.4s	v3, v7, v2
	and.16b	v1, v1, v3
	and.16b	v1, v1, v2
	fmul.4s	v3, v1, v19
	mov.16b	v4, v29
	bsl.16b	v4, v28, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v18
	fmul.4s	v0, v4, v19
	mov.16b	v5, v29
	bsl.16b	v5, v28, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v6, v3, v20
	fsub.4s	v1, v1, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	fmul.4s	v17, v6, v20
	fsub.4s	v4, v4, v17
	fmul.4s	v6, v6, v21
	fsub.4s	v4, v4, v6
	fmul.4s	v3, v3, v21
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v22
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v24
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v26
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v30
	fmul.4s	v6, v1, v1
	fmul.4s	v3, v6, v3
	fmul.4s	v6, v4, v22
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v25
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v17, v4, v4
	fmul.4s	v6, v17, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v31
	sshr.4s	v4, v5, #1
	shl.4s	v6, v4, #23
	add.4s	v6, v6, v31
	fmul.4s	v3, v3, v6
	fadd.4s	v1, v1, v31
	sshr.4s	v6, v0, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v31
	fmul.4s	v1, v1, v17
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v6
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v16, v18
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v16, v2
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v2, v7
	bit.16b	v0, v27, v3
	stp	q2, q0, [sp, #512]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v18, v7
	bsl.16b	v0, v27, v1
	stp	q18, q0, [sp, #480]             ; 32-byte Folded Spill
	mov.16b	v8, v14
	fsub.4s	v18, v14, v12
	fcmge.4s	v0, v18, v16
	fcmge.4s	v1, v7, v18
	and.16b	v0, v0, v1
	ldr	q17, [sp, #1056]                ; 16-byte Reload
	fsub.4s	v11, v17, v9
	fcmge.4s	v1, v11, v16
	fcmge.4s	v3, v7, v11
	and.16b	v1, v1, v3
	and.16b	v1, v1, v11
	fmul.4s	v3, v1, v19
	mov.16b	v4, v29
	bsl.16b	v4, v28, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v18
	fmul.4s	v0, v4, v19
	mov.16b	v5, v29
	bsl.16b	v5, v28, v0
	fadd.4s	v0, v0, v5
	fsub.4s	v5, v0, v5
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v6, v3, v20
	fsub.4s	v1, v1, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	fmul.4s	v10, v6, v20
	fsub.4s	v4, v4, v10
	fmul.4s	v6, v6, v21
	fsub.4s	v4, v4, v6
	fmul.4s	v3, v3, v21
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v22
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v24
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v26
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v30
	fmul.4s	v6, v1, v1
	fmul.4s	v3, v6, v3
	fmul.4s	v6, v4, v22
	fadd.4s	v6, v6, v23
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v24
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v25
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v26
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v10, v4, v4
	fmul.4s	v6, v10, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v31
	sshr.4s	v4, v5, #1
	shl.4s	v6, v4, #23
	add.4s	v6, v6, v31
	fmul.4s	v3, v3, v6
	fadd.4s	v1, v1, v31
	sshr.4s	v6, v0, #1
	shl.4s	v10, v6, #23
	add.4s	v10, v10, v31
	fmul.4s	v1, v1, v10
	sub.4s	v4, v5, v4
	sub.4s	v0, v0, v6
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v16, v18
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v16, v11
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v11, v7
	bit.16b	v0, v27, v3
	stp	q11, q0, [sp, #448]             ; 32-byte Folded Spill
	fcmgt.4s	v0, v18, v7
	bsl.16b	v0, v27, v1
	stp	q18, q0, [sp, #416]             ; 32-byte Folded Spill
	ldr	q6, [sp, #1136]                 ; 16-byte Reload
	fsub.4s	v18, v6, v12
	fcmge.4s	v0, v18, v16
	fcmge.4s	v1, v7, v18
	and.16b	v0, v0, v1
	ldr	q5, [sp, #1152]                 ; 16-byte Reload
	fsub.4s	v13, v5, v9
	fcmge.4s	v1, v13, v16
	fcmge.4s	v3, v7, v13
	and.16b	v1, v1, v3
	and.16b	v1, v1, v13
	fmul.4s	v3, v1, v19
	mov.16b	v4, v29
	bsl.16b	v4, v28, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v0, v18
	fmul.4s	v0, v4, v19
	mov.16b	v10, v29
	bsl.16b	v10, v28, v0
	fadd.4s	v0, v0, v10
	fsub.4s	v10, v0, v10
	fcvtzs.4s	v0, v3
	scvtf.4s	v3, v0
	fmul.4s	v11, v3, v20
	fsub.4s	v1, v1, v11
	fcvtzs.4s	v10, v10
	scvtf.4s	v11, v10
	fmul.4s	v15, v11, v20
	fsub.4s	v4, v4, v15
	fmul.4s	v11, v11, v21
	fsub.4s	v4, v4, v11
	fmul.4s	v3, v3, v21
	fsub.4s	v1, v1, v3
	fmul.4s	v3, v1, v22
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v24
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v25
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v26
	fmul.4s	v3, v1, v3
	fadd.4s	v3, v3, v30
	fmul.4s	v11, v1, v1
	fmul.4s	v3, v11, v3
	fmul.4s	v11, v4, v22
	fadd.4s	v11, v11, v23
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v24
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v25
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v26
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v30
	fmul.4s	v15, v4, v4
	fmul.4s	v11, v15, v11
	fadd.4s	v4, v4, v11
	fadd.4s	v1, v1, v3
	fadd.4s	v3, v4, v31
	sshr.4s	v4, v10, #1
	shl.4s	v11, v4, #23
	add.4s	v11, v11, v31
	fmul.4s	v3, v3, v11
	fadd.4s	v1, v1, v31
	sshr.4s	v11, v0, #1
	shl.4s	v15, v11, #23
	add.4s	v15, v15, v31
	fmul.4s	v1, v1, v15
	sub.4s	v4, v10, v4
	sub.4s	v0, v0, v11
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v1, v0
	shl.4s	v1, v4, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v3, v1
	fcmgt.4s	v3, v16, v18
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v16, v13
	bic.16b	v0, v0, v3
	fcmgt.4s	v3, v13, v7
	bit.16b	v0, v27, v3
	stp	q13, q0, [sp, #384]             ; 32-byte Folded Spill
	fcmgt.4s	v0, v18, v7
	bsl.16b	v0, v27, v1
	stp	q18, q0, [sp, #352]             ; 32-byte Folded Spill
	ldr	q4, [sp, #1232]                 ; 16-byte Reload
	fsub.4s	v18, v4, v12
	fcmge.4s	v0, v18, v16
	fcmge.4s	v1, v7, v18
	and.16b	v0, v0, v1
	ldr	q3, [sp, #1248]                 ; 16-byte Reload
	fsub.4s	v2, v3, v9
	fcmge.4s	v1, v2, v16
	fcmge.4s	v10, v7, v2
	and.16b	v1, v1, v10
	and.16b	v1, v1, v2
	fmul.4s	v10, v1, v19
	mov.16b	v11, v29
	bsl.16b	v11, v28, v10
	fadd.4s	v10, v10, v11
	fsub.4s	v10, v10, v11
	and.16b	v11, v0, v18
	fmul.4s	v0, v11, v19
	mov.16b	v15, v29
	bsl.16b	v15, v28, v0
	fadd.4s	v0, v0, v15
	fsub.4s	v15, v0, v15
	fcvtzs.4s	v0, v10
	scvtf.4s	v10, v0
	fmul.4s	v14, v10, v20
	fsub.4s	v1, v1, v14
	fcvtzs.4s	v14, v15
	scvtf.4s	v15, v14
	fmul.4s	v13, v15, v20
	fsub.4s	v11, v11, v13
	fmul.4s	v13, v15, v21
	fsub.4s	v11, v11, v13
	fmul.4s	v10, v10, v21
	fsub.4s	v1, v1, v10
	fmul.4s	v10, v1, v22
	fadd.4s	v10, v10, v23
	fmul.4s	v10, v1, v10
	fadd.4s	v10, v10, v24
	fmul.4s	v10, v1, v10
	fadd.4s	v10, v10, v25
	fmul.4s	v10, v1, v10
	fadd.4s	v10, v10, v26
	fmul.4s	v10, v1, v10
	fadd.4s	v10, v10, v30
	fmul.4s	v13, v1, v1
	fmul.4s	v10, v13, v10
	fmul.4s	v13, v11, v22
	fadd.4s	v13, v13, v23
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v24
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v25
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v26
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v30
	fmul.4s	v15, v11, v11
	fmul.4s	v13, v15, v13
	fadd.4s	v11, v11, v13
	fadd.4s	v1, v1, v10
	fadd.4s	v10, v11, v31
	sshr.4s	v11, v14, #1
	shl.4s	v13, v11, #23
	add.4s	v13, v13, v31
	fmul.4s	v10, v10, v13
	fadd.4s	v1, v1, v31
	sshr.4s	v13, v0, #1
	shl.4s	v15, v13, #23
	add.4s	v15, v15, v31
	fmul.4s	v1, v1, v15
	sub.4s	v11, v14, v11
	sub.4s	v0, v0, v13
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v1, v0
	shl.4s	v1, v11, #23
	add.4s	v1, v1, v31
	fmul.4s	v1, v10, v1
	fcmgt.4s	v10, v16, v18
	bic.16b	v1, v1, v10
	fcmgt.4s	v10, v16, v2
	bic.16b	v0, v0, v10
	fcmgt.4s	v10, v2, v7
	bit.16b	v0, v27, v10
	stp	q2, q0, [sp, #304]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v18, v7
	bsl.16b	v0, v27, v1
	stp	q18, q0, [sp, #272]             ; 32-byte Folded Spill
	str	q12, [sp, #1424]                ; 16-byte Spill
	ldr	q0, [sp, #1872]                 ; 16-byte Reload
	fsub.4s	v1, v0, v12
	fcmge.4s	v0, v1, v16
	fcmge.4s	v13, v7, v1
	and.16b	v13, v0, v13
	str	q9, [sp, #1440]                 ; 16-byte Spill
	ldr	q0, [sp, #1888]                 ; 16-byte Reload
	fsub.4s	v2, v0, v9
	fcmge.4s	v14, v2, v16
	fcmge.4s	v15, v7, v2
	and.16b	v14, v14, v15
	and.16b	v14, v14, v2
	fmul.4s	v15, v14, v19
	mov.16b	v0, v29
	bsl.16b	v0, v28, v15
	fadd.4s	v15, v15, v0
	fsub.4s	v0, v15, v0
	and.16b	v13, v13, v1
	fmul.4s	v19, v13, v19
	mov.16b	v15, v29
	bsl.16b	v15, v28, v19
	fadd.4s	v19, v19, v15
	fsub.4s	v19, v19, v15
	fcvtzs.4s	v0, v0
	scvtf.4s	v15, v0
	fmul.4s	v11, v15, v20
	fsub.4s	v11, v14, v11
	fcvtzs.4s	v19, v19
	scvtf.4s	v14, v19
	fmul.4s	v20, v14, v20
	fsub.4s	v20, v13, v20
	fmul.4s	v13, v15, v21
	fmul.4s	v21, v14, v21
	fsub.4s	v20, v20, v21
	fsub.4s	v21, v11, v13
	fmul.4s	v11, v21, v22
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v23
	fadd.4s	v23, v11, v23
	fmul.4s	v23, v21, v23
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v24
	fadd.4s	v23, v23, v24
	fmul.4s	v23, v21, v23
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v25
	fadd.4s	v23, v23, v25
	fmul.4s	v23, v21, v23
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v26
	fadd.4s	v23, v23, v26
	fmul.4s	v23, v21, v23
	fadd.4s	v23, v23, v30
	fmul.4s	v24, v21, v21
	fmul.4s	v23, v24, v23
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v24, v20, v20
	fmul.4s	v22, v24, v22
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v23
	fadd.4s	v20, v20, v31
	sshr.4s	v22, v19, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v31
	fmul.4s	v20, v20, v23
	fadd.4s	v21, v21, v31
	sshr.4s	v23, v0, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v31
	fmul.4s	v21, v21, v24
	sub.4s	v19, v19, v22
	sub.4s	v0, v0, v23
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v31
	fmul.4s	v0, v21, v0
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v31
	fmul.4s	v19, v20, v19
	fcmgt.4s	v20, v16, v1
	bic.16b	v19, v19, v20
	fcmgt.4s	v16, v16, v2
	bic.16b	v0, v0, v16
	fcmgt.4s	v16, v2, v7
	bit.16b	v0, v27, v16
	stp	q2, q0, [sp, #240]              ; 32-byte Folded Spill
	fcmgt.4s	v0, v1, v7
	bsl.16b	v0, v27, v19
	stp	q1, q0, [sp, #208]              ; 32-byte Folded Spill
	ldr	q7, [sp, #1552]                 ; 16-byte Reload
	ldr	q0, [sp, #1712]                 ; 16-byte Reload
	stp	q0, q7, [x22]
	ldr	q7, [sp, #1536]                 ; 16-byte Reload
	ldr	q0, [sp, #1328]                 ; 16-byte Reload
	stp	q0, q7, [x22, #32]
	ldr	q7, [sp, #1520]                 ; 16-byte Reload
	ldr	q0, [sp, #1808]                 ; 16-byte Reload
	stp	q0, q7, [x22, #64]
	ldr	q7, [sp, #1504]                 ; 16-byte Reload
	ldr	q0, [sp, #1856]                 ; 16-byte Reload
	stp	q0, q7, [x22, #96]
	ldr	q7, [sp, #1568]                 ; 16-byte Reload
	ldr	q0, [sp, #1792]                 ; 16-byte Reload
	stp	q0, q7, [x22, #128]
	ldr	q7, [sp, #1584]                 ; 16-byte Reload
	ldr	q0, [sp, #1840]                 ; 16-byte Reload
	stp	q0, q7, [x22, #160]
	ldr	q7, [sp, #1600]                 ; 16-byte Reload
	ldr	q0, [sp, #1776]                 ; 16-byte Reload
	stp	q0, q7, [x22, #192]
	ldr	q7, [sp, #1616]                 ; 16-byte Reload
	ldr	q0, [sp, #1824]                 ; 16-byte Reload
	stp	q0, q7, [x22, #224]
	ldr	q7, [sp, #1632]                 ; 16-byte Reload
	ldr	q0, [sp, #1760]                 ; 16-byte Reload
	stp	q0, q7, [x22, #256]
	ldr	q7, [sp, #1648]                 ; 16-byte Reload
	ldr	q0, [sp, #1744]                 ; 16-byte Reload
	stp	q0, q7, [x22, #288]
	ldr	q7, [sp, #1664]                 ; 16-byte Reload
	ldr	q0, [sp, #1728]                 ; 16-byte Reload
	stp	q0, q7, [x22, #320]
	ldr	q7, [sp, #1680]                 ; 16-byte Reload
	ldr	q0, [sp, #1696]                 ; 16-byte Reload
	stp	q0, q7, [x22, #352]
	ldr	q7, [sp, #544]                  ; 16-byte Reload
	ldr	q0, [sp, #1488]                 ; 16-byte Reload
	stp	q0, q7, [x22, #384]
	stp	q17, q8, [x22, #416]
	stp	q5, q6, [x22, #448]
	stp	q3, q4, [x22, #480]
	ldr	q0, [sp, #1344]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q1, [sp, #96]                   ; 16-byte Reload
	ldr	q2, [sp, #1360]                 ; 16-byte Reload
	bsl.16b	v0, v2, v1
	str	q0, [sp, #1888]                 ; 16-byte Spill
	ldr	q0, [sp, #1392]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q2, [sp, #1376]                 ; 16-byte Reload
	bsl.16b	v0, v2, v1
	str	q0, [sp, #1872]                 ; 16-byte Spill
	ldr	q0, [sp, #1264]                 ; 16-byte Reload
	fcmeq.4s	v0, v0, v0
	ldr	q2, [sp, #1280]                 ; 16-byte Reload
	bsl.16b	v0, v2, v1
	str	q0, [sp, #1856]                 ; 16-byte Spill
	ldr	q0, [sp, #1296]                 ; 16-byte Reload
	fcmeq.4s	v19, v0, v0
	ldr	q0, [sp, #1312]                 ; 16-byte Reload
	bsl.16b	v19, v0, v1
	ldr	q0, [sp, #1168]                 ; 16-byte Reload
	fcmeq.4s	v20, v0, v0
	ldr	q0, [sp, #1184]                 ; 16-byte Reload
	bif.16b	v0, v1, v20
	str	q0, [sp, #1824]                 ; 16-byte Spill
	ldr	q0, [sp, #1200]                 ; 16-byte Reload
	fcmeq.4s	v21, v0, v0
	ldr	q0, [sp, #1216]                 ; 16-byte Reload
	bif.16b	v0, v1, v21
	str	q0, [sp, #1840]                 ; 16-byte Spill
	ldr	q0, [sp, #1072]                 ; 16-byte Reload
	fcmeq.4s	v22, v0, v0
	ldr	q0, [sp, #1088]                 ; 16-byte Reload
	bif.16b	v0, v1, v22
	str	q0, [sp, #1808]                 ; 16-byte Spill
	ldr	q0, [sp, #1104]                 ; 16-byte Reload
	fcmeq.4s	v23, v0, v0
	ldr	q0, [sp, #1120]                 ; 16-byte Reload
	mov.16b	v20, v23
	bsl.16b	v20, v0, v1
	ldp	q2, q0, [sp, #992]              ; 32-byte Folded Reload
	fcmeq.4s	v24, v2, v2
	bif.16b	v0, v1, v24
	str	q0, [sp, #1792]                 ; 16-byte Spill
	ldr	q0, [sp, #1024]                 ; 16-byte Reload
	fcmeq.4s	v25, v0, v0
	ldr	q0, [sp, #1040]                 ; 16-byte Reload
	bif.16b	v0, v1, v25
	str	q0, [sp, #1760]                 ; 16-byte Spill
	ldp	q3, q0, [sp, #928]              ; 32-byte Folded Reload
	fcmeq.4s	v26, v3, v3
	bif.16b	v0, v1, v26
	str	q0, [sp, #1776]                 ; 16-byte Spill
	ldp	q4, q0, [sp, #960]              ; 32-byte Folded Reload
	fcmeq.4s	v27, v4, v4
	mov.16b	v21, v27
	bsl.16b	v21, v0, v1
	ldp	q5, q0, [sp, #864]              ; 32-byte Folded Reload
	fcmeq.4s	v11, v5, v5
	bsl.16b	v11, v0, v1
	ldp	q6, q0, [sp, #896]              ; 32-byte Folded Reload
	fcmeq.4s	v13, v6, v6
	bsl.16b	v13, v0, v1
	ldp	q7, q0, [sp, #800]              ; 32-byte Folded Reload
	fcmeq.4s	v14, v7, v7
	bsl.16b	v14, v0, v1
	ldr	q0, [sp, #832]                  ; 16-byte Reload
	fcmeq.4s	v15, v0, v0
	ldr	q0, [sp, #848]                  ; 16-byte Reload
	mov.16b	v22, v15
	bsl.16b	v22, v0, v1
	ldr	q0, [sp, #736]                  ; 16-byte Reload
	fcmeq.4s	v10, v0, v0
	ldr	q0, [sp, #752]                  ; 16-byte Reload
	bsl.16b	v10, v0, v1
	ldr	q0, [sp, #768]                  ; 16-byte Reload
	fcmeq.4s	v12, v0, v0
	ldr	q0, [sp, #784]                  ; 16-byte Reload
	bsl.16b	v12, v0, v1
	ldr	q0, [sp, #336]                  ; 16-byte Reload
	fcmeq.4s	v9, v0, v0
	ldr	q0, [sp, #688]                  ; 16-byte Reload
	bsl.16b	v9, v0, v1
	ldr	q0, [sp, #704]                  ; 16-byte Reload
	fcmeq.4s	v8, v0, v0
	ldr	q0, [sp, #720]                  ; 16-byte Reload
	mov.16b	v23, v8
	bsl.16b	v23, v0, v1
	ldr	q0, [sp, #624]                  ; 16-byte Reload
	fcmeq.4s	v31, v0, v0
	ldr	q0, [sp, #640]                  ; 16-byte Reload
	bsl.16b	v31, v0, v1
	ldr	q0, [sp, #656]                  ; 16-byte Reload
	fcmeq.4s	v30, v0, v0
	ldr	q0, [sp, #672]                  ; 16-byte Reload
	bsl.16b	v30, v0, v1
	ldr	q0, [sp, #560]                  ; 16-byte Reload
	fcmeq.4s	v29, v0, v0
	ldr	q0, [sp, #576]                  ; 16-byte Reload
	mov.16b	v8, v29
	bsl.16b	v8, v0, v1
	ldr	q0, [sp, #592]                  ; 16-byte Reload
	fcmeq.4s	v28, v0, v0
	ldr	q0, [sp, #608]                  ; 16-byte Reload
	mov.16b	v24, v28
	bsl.16b	v24, v0, v1
	ldr	q0, [sp, #480]                  ; 16-byte Reload
	fcmeq.4s	v17, v0, v0
	ldr	q0, [sp, #496]                  ; 16-byte Reload
	mov.16b	v27, v17
	bsl.16b	v27, v0, v1
	ldr	q0, [sp, #512]                  ; 16-byte Reload
	fcmeq.4s	v16, v0, v0
	ldr	q0, [sp, #528]                  ; 16-byte Reload
	mov.16b	v25, v16
	bsl.16b	v25, v0, v1
	ldr	q0, [sp, #416]                  ; 16-byte Reload
	fcmeq.4s	v7, v0, v0
	ldr	q0, [sp, #432]                  ; 16-byte Reload
	mov.16b	v29, v7
	bsl.16b	v29, v0, v1
	ldp	q7, q0, [sp, #448]              ; 32-byte Folded Reload
	fcmeq.4s	v6, v7, v7
	mov.16b	v18, v6
	bsl.16b	v18, v0, v1
	ldp	q6, q0, [sp, #352]              ; 32-byte Folded Reload
	fcmeq.4s	v5, v6, v6
	mov.16b	v15, v5
	bsl.16b	v15, v0, v1
	ldp	q5, q0, [sp, #384]              ; 32-byte Folded Reload
	fcmeq.4s	v4, v5, v5
	mov.16b	v16, v4
	bsl.16b	v16, v0, v1
	ldp	q4, q0, [sp, #272]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v4, v4
	mov.16b	v28, v3
	bsl.16b	v28, v0, v1
	ldp	q0, q2, [sp, #304]              ; 32-byte Folded Reload
	fcmeq.4s	v0, v0, v0
	mov.16b	v17, v0
	bsl.16b	v17, v2, v1
	ldr	q0, [sp, #1408]                 ; 16-byte Reload
	and.16b	v19, v0, v19
	ldr	q2, [sp, #1856]                 ; 16-byte Reload
	and.16b	v6, v0, v2
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	and.16b	v2, v0, v2
	str	q2, [sp, #1840]                 ; 16-byte Spill
	ldr	q2, [sp, #1824]                 ; 16-byte Reload
	and.16b	v2, v0, v2
	and.16b	v20, v0, v20
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	and.16b	v4, v0, v3
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	and.16b	v26, v0, v3
	ldr	q3, [sp, #1792]                 ; 16-byte Reload
	and.16b	v3, v0, v3
	and.16b	v21, v0, v21
	ldr	q5, [sp, #1776]                 ; 16-byte Reload
	and.16b	v5, v0, v5
	and.16b	v13, v0, v13
	and.16b	v11, v0, v11
	and.16b	v22, v0, v22
	and.16b	v14, v0, v14
	and.16b	v12, v0, v12
	and.16b	v10, v0, v10
	and.16b	v23, v0, v23
	and.16b	v9, v0, v9
	and.16b	v30, v0, v30
	and.16b	v31, v0, v31
	and.16b	v24, v0, v24
	and.16b	v8, v0, v8
	and.16b	v25, v0, v25
	and.16b	v27, v0, v27
	and.16b	v7, v0, v18
	str	q7, [sp, #1856]                 ; 16-byte Spill
	and.16b	v29, v0, v29
	and.16b	v16, v0, v16
	and.16b	v18, v0, v15
	and.16b	v17, v0, v17
	and.16b	v28, v0, v28
	ldp	q0, q7, [sp, #208]              ; 32-byte Folded Reload
	fcmeq.4s	v0, v0, v0
	mov.16b	v15, v0
	bsl.16b	v15, v7, v1
	ldp	q0, q7, [sp, #240]              ; 32-byte Folded Reload
	fcmeq.4s	v0, v0, v0
	bsl.16b	v0, v7, v1
	ldr	q7, [sp, #1872]                 ; 16-byte Reload
	ldr	q1, [sp, #1888]                 ; 16-byte Reload
	stp	q1, q7, [x22, #512]
	str	q6, [sp, #1328]                 ; 16-byte Spill
	stp	q19, q6, [x22, #544]
	str	q19, [sp, #1824]                ; 16-byte Spill
	str	q2, [sp, #1712]                 ; 16-byte Spill
	ldr	q1, [sp, #1840]                 ; 16-byte Reload
	stp	q1, q2, [x22, #576]
	str	q4, [sp, #1504]                 ; 16-byte Spill
	stp	q20, q4, [x22, #608]
	str	q20, [sp, #1808]                ; 16-byte Spill
	mov.16b	v20, v0
	str	q3, [sp, #1680]                 ; 16-byte Spill
	stp	q26, q3, [x22, #640]
	str	q26, [sp, #1696]                ; 16-byte Spill
	str	q5, [sp, #1488]                 ; 16-byte Spill
	stp	q21, q5, [x22, #672]
	str	q21, [sp, #1792]                ; 16-byte Spill
	str	q11, [sp, #1648]                ; 16-byte Spill
	stp	q13, q11, [x22, #704]
	str	q13, [sp, #1664]                ; 16-byte Spill
	str	q14, [sp, #1408]                ; 16-byte Spill
	stp	q22, q14, [x22, #736]
	str	q22, [sp, #1776]                ; 16-byte Spill
	str	q10, [sp, #1616]                ; 16-byte Spill
	stp	q12, q10, [x22, #768]
	str	q12, [sp, #1632]                ; 16-byte Spill
	str	q9, [sp, #1392]                 ; 16-byte Spill
	stp	q23, q9, [x22, #800]
	str	q23, [sp, #1760]                ; 16-byte Spill
	str	q31, [sp, #1584]                ; 16-byte Spill
	stp	q30, q31, [x22, #832]
	str	q30, [sp, #1600]                ; 16-byte Spill
	str	q8, [sp, #1376]                 ; 16-byte Spill
	stp	q24, q8, [x22, #864]
	str	q24, [sp, #1744]                ; 16-byte Spill
	str	q27, [sp, #1552]                ; 16-byte Spill
	stp	q25, q27, [x22, #896]
	str	q25, [sp, #1568]                ; 16-byte Spill
	str	q29, [sp, #1360]                ; 16-byte Spill
	ldr	q0, [sp, #1856]                 ; 16-byte Reload
	stp	q0, q29, [x22, #928]
	str	q18, [sp, #1520]                ; 16-byte Spill
	stp	q16, q18, [x22, #960]
	str	q16, [sp, #1536]                ; 16-byte Spill
	str	q28, [sp, #1344]                ; 16-byte Spill
	stp	q17, q28, [x22, #992]
	str	q17, [sp, #1728]                ; 16-byte Spill
	ldr	x9, [sp, #136]                  ; 8-byte Reload
LBB0_20:                                ; %direct.true600
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_21 Depth 3
	mov	x10, #0                         ; =0x0
	lsl	x11, x8, #7
	add	x12, x24, x11
	ldp	q0, q1, [x12]
	fmul.4s	v1, v15, v1
	fmul.4s	v0, v20, v0
	mov	w12, #1                         ; =0x1
	bfi	x12, x8, #2, #61
	add	x13, x24, x12, lsl #5
	ldp	q2, q3, [x13]
	fmul.4s	v3, v15, v3
	fmul.4s	v2, v20, v2
	mov	w13, #2                         ; =0x2
	bfi	x13, x8, #2, #61
	add	x14, x24, x13, lsl #5
	ldp	q4, q5, [x14]
	fmul.4s	v7, v15, v5
	fmul.4s	v6, v20, v4
	orr	x14, x20, x8, lsl #2
	add	x15, x24, x14, lsl #5
	ldp	q4, q5, [x15]
	fmul.4s	v5, v15, v5
	fmul.4s	v4, v20, v4
	mov	x15, x9
LBB0_21:                                ; %direct.true628
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_20 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x16, x28, x10
	ldp	q17, q16, [x16]
	ldp	q19, q18, [x15, #-96]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v1, v1, v18
	fadd.4s	v0, v0, v19
	ldp	q19, q18, [x15, #-64]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v3, v3, v18
	fadd.4s	v2, v2, v19
	ldp	q19, q18, [x15, #-32]
	fmul.4s	v19, v17, v19
	fmul.4s	v18, v16, v18
	fadd.4s	v7, v7, v18
	fadd.4s	v6, v6, v19
	ldp	q19, q18, [x15]
	fmul.4s	v17, v17, v19
	fmul.4s	v16, v16, v18
	fadd.4s	v5, v5, v16
	fadd.4s	v4, v4, v17
	add	x10, x10, #32
	add	x15, x15, #1, lsl #12           ; =4096
	cmp	x10, #512
	b.ne	LBB0_21
; %bb.22:                               ; %direct.false629
                                        ;   in Loop: Header=BB0_20 Depth=2
	add	x10, x19, x11
	stp	q0, q1, [x10]
	add	x10, x19, x12, lsl #5
	stp	q2, q3, [x10]
	add	x10, x19, x13, lsl #5
	stp	q6, q7, [x10]
	add	x10, x19, x14, lsl #5
	add	x8, x8, #1
	add	x9, x9, #128
	stp	q4, q5, [x10]
	cmp	x8, #32
	b.ne	LBB0_20
; %bb.23:                               ; %direct.true695.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x21, #2, lsl #12            ; =8192
	mov	x1, x19
	mov	w2, #4096                       ; =0x1000
	str	q15, [sp, #1296]                ; 16-byte Spill
	str	q20, [sp, #1312]                ; 16-byte Spill
	bl	_memcpy
	add	x0, x21, #1, lsl #12            ; =4096
	mov	x1, x19
	mov	w2, #4096                       ; =0x1000
	bl	_memcpy
	ldr	q0, [sp, #1456]                 ; 16-byte Reload
	ldr	q1, [sp, #1296]                 ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #1472]                 ; 16-byte Reload
	ldr	q2, [sp, #1312]                 ; 16-byte Reload
	fmul.4s	v1, v1, v2
	movi.2d	v3, #0000000000000000
	ldr	q2, [sp, #1872]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q4, [sp, #1328]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	fadd.4s	v3, v4, v3
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1840]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1712]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1504]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1808]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1696]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1680]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1488]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1792]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1664]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1648]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1408]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1776]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1632]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1616]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1392]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1760]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1600]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1584]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1376]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1744]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1568]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1552]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1360]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1856]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1536]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1520]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1344]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1728]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	fadd.4s	v19, v1, v3
	fadd.4s	v20, v0, v2
	add	x25, x25, #1
	ldr	q1, [sp, #1440]                 ; 16-byte Reload
	ldr	q0, [sp, #1424]                 ; 16-byte Reload
	cmp	x25, #513
	ldp	q7, q6, [sp, #176]              ; 32-byte Folded Reload
	ldp	q17, q16, [sp, #144]            ; 32-byte Folded Reload
	ldr	q18, [sp, #112]                 ; 16-byte Reload
	b.ne	LBB0_3
; %bb.24:                               ; %direct.true730.preheader
	mov	x8, #0                          ; =0x0
	ldr	x11, [sp, #88]                  ; 8-byte Reload
	ldp	q16, q7, [sp, #48]              ; 32-byte Folded Reload
	ldp	q18, q17, [sp, #16]             ; 32-byte Folded Reload
LBB0_25:                                ; %direct.true730
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q0, q1, [x24], #32
	fdiv.4s	v1, v1, v20
	fdiv.4s	v0, v0, v19
	dup.2d	v2, x8
	add.2d	v3, v2, v18
	add.2d	v4, v2, v16
	add.2d	v5, v2, v17
	add.2d	v2, v2, v7
	dup.2d	v6, x11
	add.2d	v4, v6, v4
	add.2d	v3, v6, v3
	mov.d	x9, v3[1]
	fmov	x10, d3
	str	s0, [x10]
	st1.s	{ v0 }[1], [x9]
	mov.d	x9, v4[1]
	add.2d	v3, v6, v5
	fmov	x10, d4
	st1.s	{ v0 }[2], [x10]
	st1.s	{ v0 }[3], [x9]
	mov.d	x9, v3[1]
	fmov	x10, d3
	str	s1, [x10]
	st1.s	{ v1 }[1], [x9]
	add.2d	v0, v6, v2
	mov.d	x9, v0[1]
	fmov	x10, d0
	st1.s	{ v1 }[2], [x10]
	st1.s	{ v1 }[3], [x9]
	add	x8, x8, #4
	cmp	x8, #512
	b.ne	LBB0_25
; %bb.26:                               ; %common.ret
	add	sp, sp, #1904
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_4:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_5:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_6:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2512
	str	x0, [sp, #136]                  ; 8-byte Spill
	cbz	w3, LBB1_109
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x25, x3
	mov	x20, x2
	mov	w22, #0                         ; =0x0
	ldp	w9, w8, [x2, #44]
	stp	w8, w9, [sp, #128]              ; 8-byte Folded Spill
	ldp	w27, w26, [x2]
	ldp	w23, w24, [x2, #8]
	adrp	x28, lCPI1_4@PAGE
Lloh4:
	adrp	x8, lCPI1_0@PAGE
Lloh5:
	ldr	q20, [x8, lCPI1_0@PAGEOFF]
	adrp	x19, lCPI1_5@PAGE
Lloh6:
	adrp	x8, lCPI1_1@PAGE
Lloh7:
	ldr	q19, [x8, lCPI1_1@PAGEOFF]
Lloh8:
	adrp	x8, lCPI1_2@PAGE
Lloh9:
	ldr	q17, [x8, lCPI1_2@PAGEOFF]
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #144]                  ; 16-byte Spill
	str	w3, [sp, #108]                  ; 4-byte Spill
	str	q20, [sp, #224]                 ; 16-byte Spill
	str	q19, [sp, #80]                  ; 16-byte Spill
	str	q17, [sp, #112]                 ; 16-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w25, [sp, #108]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w27, #1
	ldp	w10, w9, [sp, #128]             ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w27, wzr, w27, eq
	cinc	w9, w26, eq
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w26, wzr, w9, ne
	add	w23, w23, w8
	add	w22, w22, #1
	cmp	w22, w25
	b.eq	LBB1_109
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_32 Depth 2
                                        ;     Child Loop BB1_34 Depth 2
                                        ;       Child Loop BB1_36 Depth 3
                                        ;       Child Loop BB1_55 Depth 3
                                        ;       Child Loop BB1_73 Depth 3
                                        ;       Child Loop BB1_75 Depth 3
                                        ;       Child Loop BB1_77 Depth 3
                                        ;       Child Loop BB1_79 Depth 3
                                        ;       Child Loop BB1_81 Depth 3
                                        ;       Child Loop BB1_83 Depth 3
                                        ;         Child Loop BB1_84 Depth 4
                                        ;       Child Loop BB1_87 Depth 3
                                        ;       Child Loop BB1_89 Depth 3
                                        ;     Child Loop BB1_93 Depth 2
	mov	x21, x19
	mov	x19, x28
	ubfiz	x8, x27, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w27, w26, [x20]
	str	w23, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x28, x10, xzr, ls
	cmp	x28, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x28, [sp, #136]                 ; 8-byte Reload
	mov	x0, x28
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x28
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x28
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x28
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	x28, x19
	mov	x19, x21
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x25, x28, #3
	cbz	x25, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #136]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_attention.full_packet
	cmp	x25, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #136]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_attention.full_packet
	cmp	x25, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #136]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_attention.full_packet
	cmp	x25, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	str	w23, [sp, #2480]                ; 4-byte Spill
	mov	x23, x22
	mov	x22, x26
	mov	x26, x24
	ldr	x24, [sp, #136]                 ; 8-byte Reload
	mov	x0, x24
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x24
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x24
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x24
	mov	x24, x26
	mov	x26, x22
	mov	x22, x23
	ldr	w23, [sp, #2480]                ; 4-byte Reload
	mov	x1, x20
	bl	_llm_attention.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w28, #0x7
	mov	x28, x19
	ldr	q20, [sp, #224]                 ; 16-byte Reload
	mov	x19, x21
	ldr	q19, [sp, #80]                  ; 16-byte Reload
	mov	w21, #1267                      ; =0x4f3
	movk	w21, #15797, lsl #16
	ldr	q17, [sp, #112]                 ; 16-byte Reload
	mov	w30, #-1026555904               ; =0xc2d00000
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v26, w8
	cmhi.4s	v0, v26, v19
	cmhi.4s	v6, v26, v20
	uzp1.8h	v5, v6, v0
	umaxv.8h	h1, v5
	fmov	w8, s1
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x1, #0                          ; =0x0
	ldr	x10, [x20, #136]
	add	x11, x10, #35, lsl #12          ; =143360
	add	x8, x10, #1, lsl #12            ; =4096
	add	x12, x10, #2, lsl #12           ; =8192
	add	x13, x10, #3, lsl #12           ; =12288
	add	x14, x10, #19, lsl #12          ; =77824
	mov	w9, #12800                      ; =0x3200
	movk	w9, #2, lsl #16
	add	x15, x10, x9
	mov	w9, #13312                      ; =0x3400
	movk	w9, #2, lsl #16
	add	x16, x10, x9
	ldr	x9, [sp, #136]                  ; 8-byte Reload
	ldr	x3, [x9]
	ldr	x17, [x9, #16]
	ldr	x0, [x9, #32]
	ldr	x9, [x9, #48]
	lsl	w2, w25, #3
	orr	w2, w2, w27, lsl #5
	dup.4s	v1, w2
	orr.16b	v2, v1, v19
	orr.16b	v1, v1, v20
	and.16b	v7, v6, v1
	and.16b	v16, v0, v2
	ushll2.2d	v1, v16, #0
	ushll2.2d	v2, v7, #0
	ushll.2d	v3, v16, #0
	ushll.2d	v4, v7, #0
	ushll2.2d	v21, v16, #9
	ushll2.2d	v22, v7, #9
	ushll.2d	v23, v16, #9
	ushll.2d	v24, v7, #9
	and.16b	v5, v5, v17
	addv.8h	h25, v5
	fmov	w2, s25
	dup.2d	v5, x3
	mov	x3, x10
	b	LBB1_15
LBB1_14:                                ; %else247
                                        ;   in Loop: Header=BB1_15 Depth=2
	ldp	q17, q18, [x3]
	bif.16b	v16, v18, v0
	bif.16b	v7, v17, v6
	stp	q7, q16, [x3], #32
	add	x1, x1, #4
	cmp	x1, #512
	b.eq	LBB1_31
LBB1_15:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v17, x1
	add.2d	v7, v17, v24
	add.2d	v18, v5, v7
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w2, #0, LBB1_23
; %bb.16:                               ; %else
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w4, w2, #0xff
	tbnz	w4, #1, LBB1_24
LBB1_17:                                ; %else229
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v18, v17, v22
	add.2d	v18, v5, v18
	tbnz	w4, #2, LBB1_25
LBB1_18:                                ; %else232
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w4, #3, LBB1_26
LBB1_19:                                ; %else235
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v18, v17, v23
	add.2d	v18, v5, v18
	tbnz	w4, #4, LBB1_27
LBB1_20:                                ; %else238
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w4, #5, LBB1_28
LBB1_21:                                ; %else241
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v17, v17, v21
	add.2d	v17, v5, v17
	tbnz	w4, #6, LBB1_29
LBB1_22:                                ; %else244
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbz	w4, #7, LBB1_14
	b	LBB1_30
LBB1_23:                                ; %cond.load
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x4, d18
	ldr	s7, [x4]
	and	w4, w2, #0xff
	tbz	w4, #1, LBB1_17
LBB1_24:                                ; %cond.load228
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x5, v18[1]
	ld1.s	{ v7 }[1], [x5]
	add.2d	v18, v17, v22
	add.2d	v18, v5, v18
	tbz	w4, #2, LBB1_18
LBB1_25:                                ; %cond.load231
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x5, d18
	ld1.s	{ v7 }[2], [x5]
	tbz	w4, #3, LBB1_19
LBB1_26:                                ; %cond.load234
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x5, v18[1]
	ld1.s	{ v7 }[3], [x5]
	add.2d	v18, v17, v23
	add.2d	v18, v5, v18
	tbz	w4, #4, LBB1_20
LBB1_27:                                ; %cond.load237
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x5, d18
	ld1.s	{ v16 }[0], [x5]
	tbz	w4, #5, LBB1_21
LBB1_28:                                ; %cond.load240
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x5, v18[1]
	ld1.s	{ v16 }[1], [x5]
	add.2d	v17, v17, v21
	add.2d	v17, v5, v17
	tbz	w4, #6, LBB1_22
LBB1_29:                                ; %cond.load243
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x5, d17
	ld1.s	{ v16 }[2], [x5]
	tbz	w4, #7, LBB1_14
LBB1_30:                                ; %cond.load246
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x4, v17[1]
	ld1.s	{ v16 }[3], [x4]
	b	LBB1_14
LBB1_31:                                ; %direct.true147.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	stp	q24, q23, [sp, #16]             ; 32-byte Folded Spill
	stp	q22, q21, [sp, #48]             ; 32-byte Folded Spill
	mov	x1, #0                          ; =0x0
	mov	w7, #12384                      ; =0x3060
	movk	w7, #1, lsl #16
	adrp	x25, lCPI1_3@PAGE
LBB1_32:                                ; %direct.true147.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x2, x8, x1
	ldp	q5, q7, [x2]
	cmhs.4s	v16, v19, v26
	and.16b	v7, v16, v7
	cmhs.4s	v16, v20, v26
	and.16b	v5, v16, v5
	stp	q5, q7, [x2]
	add	x1, x1, #32
	cmp	x1, #1, lsl #12                 ; =4096
	b.ne	LBB1_32
; %bb.33:                               ; %direct.false148.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q26, [sp, #208]                 ; 16-byte Spill
	mov	x1, #0                          ; =0x0
	ushr.2d	v4, v4, #2
	ushr.2d	v2, v2, #2
	ushr.2d	v3, v3, #2
	ushr.2d	v1, v1, #2
	mov.d	x2, v1[1]
	fmov	x3, d1
	add	x3, x3, x3, lsl #13
	fmov	d1, x3
	add	x2, x2, x2, lsl #13
	mov.d	v1[1], x2
	mov.d	x2, v3[1]
	fmov	x3, d3
	add	x3, x3, x3, lsl #13
	fmov	d3, x3
	add	x2, x2, x2, lsl #13
	mov.d	v3[1], x2
	mov.d	x2, v2[1]
	fmov	x3, d2
	add	x3, x3, x3, lsl #13
	fmov	d2, x3
	add	x2, x2, x2, lsl #13
	mov.d	v2[1], x2
	mov.d	x2, v4[1]
	fmov	x3, d4
	add	x3, x3, x3, lsl #13
	fmov	d4, x3
	add	x2, x2, x2, lsl #13
	mov.d	v4[1], x2
	sshll.2d	v5, v6, #0
	sshll.2d	v7, v0, #0
	sshll2.2d	v19, v6, #0
	sshll2.2d	v18, v0, #0
Lloh10:
	adrp	x2, lCPI1_6@PAGE
Lloh11:
	ldr	q20, [x2, lCPI1_6@PAGEOFF]
	and.16b	v16, v5, v20
	str	q16, [sp, #1408]                ; 16-byte Spill
	mov	w2, #62154                      ; =0xf2ca
	movk	w2, #61769, lsl #16
	dup.4s	v16, w2
	and.16b	v17, v0, v16
	str	q17, [sp, #2016]                ; 16-byte Spill
	str	q16, [sp, #176]                 ; 16-byte Spill
	and.16b	v16, v6, v16
	str	q16, [sp, #2000]                ; 16-byte Spill
	and.16b	v4, v5, v4
	str	q4, [sp, #160]                  ; 16-byte Spill
	str	q19, [sp, #2400]                ; 16-byte Spill
	and.16b	v2, v19, v2
	str	q2, [sp, #2384]                 ; 16-byte Spill
	and.16b	v2, v7, v3
	str	q2, [sp, #2368]                 ; 16-byte Spill
	str	q18, [sp, #2432]                ; 16-byte Spill
	and.16b	v1, v18, v1
	str	q1, [sp, #2352]                 ; 16-byte Spill
	movi.2d	v21, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v1, #0000000000000000
	str	q1, [sp, #2240]                 ; 16-byte Spill
	str	q1, [sp, #1632]                 ; 16-byte Spill
	str	q1, [sp, #1616]                 ; 16-byte Spill
	str	q1, [sp, #1600]                 ; 16-byte Spill
	str	q1, [sp, #1584]                 ; 16-byte Spill
	str	q1, [sp, #1568]                 ; 16-byte Spill
	str	q1, [sp, #1552]                 ; 16-byte Spill
	str	q1, [sp, #1536]                 ; 16-byte Spill
	str	q1, [sp, #1520]                 ; 16-byte Spill
	str	q1, [sp, #1504]                 ; 16-byte Spill
	str	q1, [sp, #1488]                 ; 16-byte Spill
	str	q1, [sp, #1472]                 ; 16-byte Spill
	movi.2d	v13, #0000000000000000
	str	q1, [sp, #2480]                 ; 16-byte Spill
	str	q1, [sp, #1984]                 ; 16-byte Spill
	str	q1, [sp, #1968]                 ; 16-byte Spill
	str	q1, [sp, #2464]                 ; 16-byte Spill
	str	q1, [sp, #2448]                 ; 16-byte Spill
	movi.2d	v28, #0000000000000000
	str	q1, [sp, #1952]                 ; 16-byte Spill
	movi.2d	v15, #0000000000000000
	str	q1, [sp, #1936]                 ; 16-byte Spill
	str	q1, [sp, #1920]                 ; 16-byte Spill
	movi.2d	v18, #0000000000000000
	str	q1, [sp, #1904]                 ; 16-byte Spill
	str	q1, [sp, #1888]                 ; 16-byte Spill
	str	q1, [sp, #1872]                 ; 16-byte Spill
	str	q1, [sp, #1856]                 ; 16-byte Spill
	str	q1, [sp, #1840]                 ; 16-byte Spill
	str	q1, [sp, #1824]                 ; 16-byte Spill
	movi.2d	v27, #0000000000000000
	str	q1, [sp, #1808]                 ; 16-byte Spill
	str	q1, [sp, #1792]                 ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v14, #0000000000000000
	str	q1, [sp, #2336]                 ; 16-byte Spill
	str	q1, [sp, #2320]                 ; 16-byte Spill
	str	q1, [sp, #2304]                 ; 16-byte Spill
	str	q1, [sp, #2288]                 ; 16-byte Spill
	str	q1, [sp, #2272]                 ; 16-byte Spill
	str	q1, [sp, #2256]                 ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q1, [sp, #2224]                 ; 16-byte Spill
	str	q1, [sp, #1456]                 ; 16-byte Spill
	str	q1, [sp, #1440]                 ; 16-byte Spill
	str	q1, [sp, #1424]                 ; 16-byte Spill
	movi.2d	v26, #0000000000000000
	str	q25, [sp, #192]                 ; 16-byte Spill
	str	q20, [sp, #1648]                ; 16-byte Spill
LBB1_34:                                ; %direct.true157.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_36 Depth 3
                                        ;       Child Loop BB1_55 Depth 3
                                        ;       Child Loop BB1_73 Depth 3
                                        ;       Child Loop BB1_75 Depth 3
                                        ;       Child Loop BB1_77 Depth 3
                                        ;       Child Loop BB1_79 Depth 3
                                        ;       Child Loop BB1_81 Depth 3
                                        ;       Child Loop BB1_83 Depth 3
                                        ;         Child Loop BB1_84 Depth 4
                                        ;       Child Loop BB1_87 Depth 3
                                        ;       Child Loop BB1_89 Depth 3
	str	q19, [sp, #2416]                ; 16-byte Spill
	str	q18, [sp, #2032]                ; 16-byte Spill
	str	q21, [sp, #1392]                ; 16-byte Spill
	mov	x3, #0                          ; =0x0
	lsl	x2, x1, #4
	ldr	q1, [sp, #160]                  ; 16-byte Reload
	b	LBB1_36
LBB1_35:                                ; %direct.schedule.12.i.i
                                        ;   in Loop: Header=BB1_36 Depth=3
	str	q19, [sp, #2416]                ; 16-byte Spill
	str	q21, [sp, #2256]                ; 16-byte Spill
	str	q4, [sp, #2272]                 ; 16-byte Spill
	str	q3, [sp, #2288]                 ; 16-byte Spill
	add	x4, x13, x3, lsl #5
	ldp	q2, q3, [x4]
	bit.16b	v3, v22, v0
	bit.16b	v2, v7, v6
	stp	q2, q3, [x4]
	add	x3, x3, #1
	cmp	x3, #2048
	b.eq	LBB1_53
LBB1_36:                                ; %direct.true161.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v2, v6, #0
	sshll.2d	v3, v0, #0
	and	x4, x3, #0x7f
	orr	x5, x2, x3, lsr #7
	dup.2d	v4, x5
	ldr	q7, [sp, #2352]                 ; 16-byte Reload
	add.2d	v7, v4, v7
	add.2d	v18, v4, v1
	ldr	q19, [sp, #2384]                ; 16-byte Reload
	add.2d	v19, v4, v19
	ldr	q21, [sp, #2368]                ; 16-byte Reload
	add.2d	v4, v4, v21
	shl.2d	v4, v4, #7
	shl.2d	v19, v19, #7
	shl.2d	v18, v18, #7
	dup.2d	v21, x4
	shl.2d	v7, v7, #7
	orr.16b	v7, v7, v21
	orr.16b	v18, v18, v21
	orr.16b	v19, v19, v21
	orr.16b	v4, v4, v21
	ldr	q21, [sp, #2256]                ; 16-byte Reload
	bit.16b	v21, v4, v3
	ldr	q4, [sp, #2272]                 ; 16-byte Reload
	ldr	q3, [sp, #2400]                 ; 16-byte Reload
	bit.16b	v4, v19, v3
	ldr	q3, [sp, #2288]                 ; 16-byte Reload
	bit.16b	v3, v18, v2
	ldr	q19, [sp, #2416]                ; 16-byte Reload
	ldr	q2, [sp, #2432]                 ; 16-byte Reload
	bit.16b	v19, v7, v2
	movi.2d	v7, #0000000000000000
	movi.2d	v22, #0000000000000000
	cmp	x5, #2, lsl #12                 ; =8192
	b.hi	LBB1_35
; %bb.37:                               ; %direct.true174.i.i
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	w4, s25
	shl.2d	v2, v3, #2
	dup.2d	v18, x17
	add.2d	v2, v18, v2
	tbnz	w4, #0, LBB1_45
; %bb.38:                               ; %else254
                                        ;   in Loop: Header=BB1_36 Depth=3
	and	w4, w4, #0xff
	tbnz	w4, #1, LBB1_46
LBB1_39:                                ; %else260
                                        ;   in Loop: Header=BB1_36 Depth=3
	shl.2d	v2, v4, #2
	add.2d	v2, v18, v2
	tbnz	w4, #2, LBB1_47
LBB1_40:                                ; %else266
                                        ;   in Loop: Header=BB1_36 Depth=3
	tbnz	w4, #3, LBB1_48
LBB1_41:                                ; %else272
                                        ;   in Loop: Header=BB1_36 Depth=3
	shl.2d	v2, v21, #2
	add.2d	v2, v18, v2
	tbnz	w4, #4, LBB1_49
LBB1_42:                                ; %else278
                                        ;   in Loop: Header=BB1_36 Depth=3
	tbnz	w4, #5, LBB1_50
LBB1_43:                                ; %else284
                                        ;   in Loop: Header=BB1_36 Depth=3
	shl.2d	v2, v19, #2
	add.2d	v2, v18, v2
	tbnz	w4, #6, LBB1_51
LBB1_44:                                ; %else290
                                        ;   in Loop: Header=BB1_36 Depth=3
	tbz	w4, #7, LBB1_35
	b	LBB1_52
LBB1_45:                                ; %cond.load250
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x5, d2
	ldr	s7, [x5]
	and	w4, w4, #0xff
	tbz	w4, #1, LBB1_39
LBB1_46:                                ; %cond.load256
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x5, v2[1]
	ld1.s	{ v7 }[1], [x5]
	shl.2d	v2, v4, #2
	add.2d	v2, v18, v2
	tbz	w4, #2, LBB1_40
LBB1_47:                                ; %cond.load262
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x5, d2
	ld1.s	{ v7 }[2], [x5]
	tbz	w4, #3, LBB1_41
LBB1_48:                                ; %cond.load268
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x5, v2[1]
	ld1.s	{ v7 }[3], [x5]
	shl.2d	v2, v21, #2
	add.2d	v2, v18, v2
	tbz	w4, #4, LBB1_42
LBB1_49:                                ; %cond.load274
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x5, d2
	ld1.s	{ v22 }[0], [x5]
	tbz	w4, #5, LBB1_43
LBB1_50:                                ; %cond.load280
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x5, v2[1]
	ld1.s	{ v22 }[1], [x5]
	shl.2d	v2, v19, #2
	add.2d	v2, v18, v2
	tbz	w4, #6, LBB1_44
LBB1_51:                                ; %cond.load286
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x5, d2
	ld1.s	{ v22 }[2], [x5]
	tbz	w4, #7, LBB1_35
LBB1_52:                                ; %cond.load292
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x4, v2[1]
	ld1.s	{ v22 }[3], [x4]
	b	LBB1_35
LBB1_53:                                ; %direct.true186.i.i.preheader
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x3, #0                          ; =0x0
	b	LBB1_55
LBB1_54:                                ; %direct.schedule.17.i.i
                                        ;   in Loop: Header=BB1_55 Depth=3
	str	q19, [sp, #2304]                ; 16-byte Spill
	str	q4, [sp, #2320]                 ; 16-byte Spill
	str	q3, [sp, #2336]                 ; 16-byte Spill
	add	x4, x14, x3, lsl #5
	ldp	q2, q3, [x4]
	bit.16b	v3, v22, v0
	bit.16b	v2, v7, v6
	stp	q2, q3, [x4]
	add	x3, x3, #1
	cmp	x3, #2048
	b.eq	LBB1_72
LBB1_55:                                ; %direct.true186.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v2, v6, #0
	sshll.2d	v3, v0, #0
	and	x4, x3, #0x7f
	orr	x5, x2, x3, lsr #7
	dup.2d	v4, x5
	ldr	q7, [sp, #2352]                 ; 16-byte Reload
	add.2d	v7, v4, v7
	add.2d	v18, v4, v1
	ldr	q19, [sp, #2384]                ; 16-byte Reload
	add.2d	v19, v4, v19
	ldr	q21, [sp, #2368]                ; 16-byte Reload
	add.2d	v4, v4, v21
	shl.2d	v4, v4, #7
	shl.2d	v19, v19, #7
	shl.2d	v18, v18, #7
	dup.2d	v21, x4
	shl.2d	v7, v7, #7
	orr.16b	v7, v7, v21
	orr.16b	v18, v18, v21
	orr.16b	v19, v19, v21
	orr.16b	v4, v4, v21
	ldr	q21, [sp, #2320]                ; 16-byte Reload
	bif.16b	v4, v21, v3
	ldr	q3, [sp, #2336]                 ; 16-byte Reload
	ldr	q21, [sp, #2400]                ; 16-byte Reload
	bit.16b	v3, v19, v21
	bit.16b	v14, v18, v2
	ldr	q19, [sp, #2304]                ; 16-byte Reload
	ldr	q2, [sp, #2432]                 ; 16-byte Reload
	bit.16b	v19, v7, v2
	movi.2d	v7, #0000000000000000
	movi.2d	v22, #0000000000000000
	cmp	x5, #2, lsl #12                 ; =8192
	b.hi	LBB1_54
; %bb.56:                               ; %direct.true199.i.i
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	w4, s25
	shl.2d	v2, v14, #2
	dup.2d	v18, x0
	add.2d	v2, v18, v2
	tbnz	w4, #0, LBB1_64
; %bb.57:                               ; %else303
                                        ;   in Loop: Header=BB1_55 Depth=3
	and	w4, w4, #0xff
	tbnz	w4, #1, LBB1_65
LBB1_58:                                ; %else309
                                        ;   in Loop: Header=BB1_55 Depth=3
	shl.2d	v2, v3, #2
	add.2d	v2, v18, v2
	tbnz	w4, #2, LBB1_66
LBB1_59:                                ; %else315
                                        ;   in Loop: Header=BB1_55 Depth=3
	tbnz	w4, #3, LBB1_67
LBB1_60:                                ; %else321
                                        ;   in Loop: Header=BB1_55 Depth=3
	shl.2d	v2, v4, #2
	add.2d	v2, v18, v2
	tbnz	w4, #4, LBB1_68
LBB1_61:                                ; %else327
                                        ;   in Loop: Header=BB1_55 Depth=3
	tbnz	w4, #5, LBB1_69
LBB1_62:                                ; %else333
                                        ;   in Loop: Header=BB1_55 Depth=3
	shl.2d	v2, v19, #2
	add.2d	v2, v18, v2
	tbnz	w4, #6, LBB1_70
LBB1_63:                                ; %else339
                                        ;   in Loop: Header=BB1_55 Depth=3
	tbz	w4, #7, LBB1_54
	b	LBB1_71
LBB1_64:                                ; %cond.load299
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x5, d2
	ldr	s7, [x5]
	and	w4, w4, #0xff
	tbz	w4, #1, LBB1_58
LBB1_65:                                ; %cond.load305
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x5, v2[1]
	ld1.s	{ v7 }[1], [x5]
	shl.2d	v2, v3, #2
	add.2d	v2, v18, v2
	tbz	w4, #2, LBB1_59
LBB1_66:                                ; %cond.load311
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x5, d2
	ld1.s	{ v7 }[2], [x5]
	tbz	w4, #3, LBB1_60
LBB1_67:                                ; %cond.load317
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x5, v2[1]
	ld1.s	{ v7 }[3], [x5]
	shl.2d	v2, v4, #2
	add.2d	v2, v18, v2
	tbz	w4, #4, LBB1_61
LBB1_68:                                ; %cond.load323
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x5, d2
	ld1.s	{ v22 }[0], [x5]
	tbz	w4, #5, LBB1_62
LBB1_69:                                ; %cond.load329
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x5, v2[1]
	ld1.s	{ v22 }[1], [x5]
	shl.2d	v2, v19, #2
	add.2d	v2, v18, v2
	tbz	w4, #6, LBB1_63
LBB1_70:                                ; %cond.load335
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x5, d2
	ld1.s	{ v22 }[2], [x5]
	tbz	w4, #7, LBB1_54
LBB1_71:                                ; %cond.load341
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x4, v2[1]
	ld1.s	{ v22 }[3], [x4]
	b	LBB1_54
LBB1_72:                                ; %direct.false187.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q14, [sp, #1248]                ; 16-byte Spill
	str	q26, [sp, #1376]                ; 16-byte Spill
	sshll.2d	v2, v6, #0
	sshll.2d	v3, v0, #0
	ldr	q7, [x25, lCPI1_3@PAGEOFF]
	ldr	q1, [sp, #1424]                 ; 16-byte Reload
	ldr	q4, [sp, #2432]                 ; 16-byte Reload
	str	q7, [sp, #2208]                 ; 16-byte Spill
	bit.16b	v1, v7, v4
	str	q1, [sp, #1424]                 ; 16-byte Spill
	ldr	q4, [x28, lCPI1_4@PAGEOFF]
	ldr	q1, [sp, #1456]                 ; 16-byte Reload
	str	q4, [sp, #1216]                 ; 16-byte Spill
	ldr	q7, [sp, #2400]                 ; 16-byte Reload
	bit.16b	v1, v4, v7
	str	q1, [sp, #1456]                 ; 16-byte Spill
	ldr	q4, [x19, lCPI1_5@PAGEOFF]
	ldr	q1, [sp, #1440]                 ; 16-byte Reload
	str	q4, [sp, #1232]                 ; 16-byte Spill
	bit.16b	v1, v4, v3
	str	q1, [sp, #1440]                 ; 16-byte Spill
	ldr	q1, [sp, #2224]                 ; 16-byte Reload
	bit.16b	v1, v20, v2
	str	q1, [sp, #2224]                 ; 16-byte Spill
	bic.16b	v5, v5, v0
	bic.16b	v23, v23, v6
	bic.16b	v24, v24, v0
	bic.16b	v16, v16, v6
	bic.16b	v17, v17, v0
	ldr	q25, [sp, #1792]                ; 16-byte Reload
	bic.16b	v25, v25, v6
	ldr	q1, [sp, #1808]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	bic.16b	v27, v27, v6
	add	x2, x10, #4, lsl #12            ; =16384
	mov	w3, #16384                      ; =0x4000
	ldr	q20, [sp, #1408]                ; 16-byte Reload
LBB1_73:                                ; %direct.true211.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sub	x4, x3, #4, lsl #12             ; =16384
	fmov	d2, x4
	orr.16b	v3, v2, v20
	fmov	x4, d3
	add	x4, x10, x4
	ldp	q4, q3, [x4]
	and.16b	v4, v6, v4
	and.16b	v3, v0, v3
	ldr	q7, [sp, #2224]                 ; 16-byte Reload
	orr.16b	v2, v2, v7
	fmov	x4, d2
	add	x4, x13, x4
	ldp	q7, q2, [x4]
	and.16b	v7, v6, v7
	and.16b	v2, v0, v2
	fmul.4s	v2, v3, v2
	fmul.4s	v7, v4, v7
	fadd.4s	v7, v23, v7
	fadd.4s	v2, v5, v2
	ldp	q19, q18, [x2]
	and.16b	v19, v6, v19
	and.16b	v18, v0, v18
	fmul.4s	v18, v3, v18
	fmul.4s	v19, v4, v19
	fadd.4s	v19, v16, v19
	fadd.4s	v18, v24, v18
	ldr	q21, [x2, #4112]
	ldr	q22, [x2, #4096]
	and.16b	v22, v6, v22
	and.16b	v21, v0, v21
	fmul.4s	v21, v3, v21
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v25, v22
	fadd.4s	v21, v17, v21
	mov.16b	v14, v5
	mov.16b	v5, v23
	mov.16b	v23, v24
	mov.16b	v24, v16
	mov.16b	v16, v17
	mov.16b	v17, v25
	ldr	q25, [x2, #8208]
	ldr	q26, [x2, #8192]
	and.16b	v26, v6, v26
	and.16b	v25, v0, v25
	fmul.4s	v3, v3, v25
	mov.16b	v25, v17
	mov.16b	v17, v16
	mov.16b	v16, v24
	mov.16b	v24, v23
	mov.16b	v23, v5
	fmul.4s	v4, v4, v26
	fadd.4s	v4, v27, v4
	fadd.4s	v3, v1, v3
	mov.16b	v5, v0
	bsl.16b	v5, v2, v14
	bit.16b	v23, v7, v6
	bit.16b	v24, v18, v0
	bit.16b	v16, v19, v6
	bit.16b	v17, v21, v0
	bit.16b	v25, v22, v6
	bit.16b	v1, v3, v0
	bit.16b	v27, v4, v6
	add	x3, x3, #32
	add	x2, x2, #32
	cmp	x3, #5, lsl #12                 ; =20480
	b.ne	LBB1_73
; %bb.74:                               ; %direct.false212.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q5, [sp, #1760]                 ; 16-byte Spill
	str	q23, [sp, #1264]                ; 16-byte Spill
	str	q24, [sp, #1280]                ; 16-byte Spill
	str	q16, [sp, #1296]                ; 16-byte Spill
	str	q17, [sp, #1312]                ; 16-byte Spill
	str	q25, [sp, #1792]                ; 16-byte Spill
	str	q1, [sp, #1808]                 ; 16-byte Spill
	str	q27, [sp, #1776]                ; 16-byte Spill
	ldr	q14, [sp, #1824]                ; 16-byte Reload
	bic.16b	v14, v14, v0
	ldr	q5, [sp, #1840]                 ; 16-byte Reload
	bic.16b	v5, v5, v6
	ldr	q17, [sp, #1856]                ; 16-byte Reload
	bic.16b	v17, v17, v0
	ldr	q16, [sp, #1872]                ; 16-byte Reload
	bic.16b	v16, v16, v6
	ldr	q24, [sp, #1888]                ; 16-byte Reload
	bic.16b	v24, v24, v0
	ldr	q27, [sp, #1904]                ; 16-byte Reload
	bic.16b	v27, v27, v6
	ldr	q23, [sp, #2032]                ; 16-byte Reload
	bic.16b	v23, v23, v0
	mov	x2, x10
	mov	w3, #128                        ; =0x80
	ldr	q20, [sp, #1920]                ; 16-byte Reload
	bic.16b	v20, v20, v6
	ldr	q1, [sp, #1552]                 ; 16-byte Reload
LBB1_75:                                ; %direct.true247.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q3, q2, [x2]
	and.16b	v3, v6, v3
	and.16b	v2, v0, v2
	ldr	q4, [x2, #28688]
	ldr	q7, [x2, #28672]
	and.16b	v7, v6, v7
	and.16b	v4, v0, v4
	fmul.4s	v4, v2, v4
	fmul.4s	v7, v3, v7
	fadd.4s	v7, v5, v7
	fadd.4s	v4, v14, v4
	ldr	q18, [x2, #32784]
	ldr	q19, [x2, #32768]
	and.16b	v19, v6, v19
	and.16b	v18, v0, v18
	fmul.4s	v18, v2, v18
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v16, v19
	fadd.4s	v18, v17, v18
	ldr	q21, [x2, #36880]
	ldr	q22, [x2, #36864]
	and.16b	v22, v6, v22
	and.16b	v21, v0, v21
	fmul.4s	v21, v2, v21
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v27, v22
	fadd.4s	v21, v24, v21
	ldr	q25, [x2, #40976]
	ldr	q26, [x2, #40960]
	and.16b	v26, v6, v26
	and.16b	v25, v0, v25
	fmul.4s	v2, v2, v25
	fmul.4s	v3, v3, v26
	fadd.4s	v3, v20, v3
	fadd.4s	v2, v23, v2
	bit.16b	v14, v4, v0
	bit.16b	v5, v7, v6
	bit.16b	v17, v18, v0
	bit.16b	v16, v19, v6
	bit.16b	v24, v21, v0
	bit.16b	v27, v22, v6
	bit.16b	v23, v2, v0
	bit.16b	v20, v3, v6
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB1_75
; %bb.76:                               ; %direct.false248.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q14, [sp, #1824]                ; 16-byte Spill
	str	q5, [sp, #1840]                 ; 16-byte Spill
	str	q17, [sp, #1856]                ; 16-byte Spill
	str	q16, [sp, #1872]                ; 16-byte Spill
	str	q24, [sp, #1888]                ; 16-byte Spill
	str	q27, [sp, #1904]                ; 16-byte Spill
	str	q23, [sp, #2032]                ; 16-byte Spill
	str	q20, [sp, #1920]                ; 16-byte Spill
	ldr	q5, [sp, #1936]                 ; 16-byte Reload
	bic.16b	v5, v5, v0
	bic.16b	v15, v15, v6
	ldr	q17, [sp, #1952]                ; 16-byte Reload
	bic.16b	v17, v17, v0
	bic.16b	v28, v28, v6
	ldr	q2, [sp, #2448]                 ; 16-byte Reload
	bic.16b	v2, v2, v0
	str	q2, [sp, #2448]                 ; 16-byte Spill
	ldr	q2, [sp, #2464]                 ; 16-byte Reload
	bic.16b	v2, v2, v6
	str	q2, [sp, #2464]                 ; 16-byte Spill
	ldr	q25, [sp, #1968]                ; 16-byte Reload
	bic.16b	v25, v25, v0
	mov	x2, x10
	mov	w3, #128                        ; =0x80
	ldr	q20, [sp, #1984]                ; 16-byte Reload
	bic.16b	v20, v20, v6
LBB1_77:                                ; %direct.true285.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q3, q2, [x2]
	and.16b	v3, v6, v3
	and.16b	v2, v0, v2
	ldr	q4, [x2, #45072]
	ldr	q7, [x2, #45056]
	and.16b	v7, v6, v7
	and.16b	v4, v0, v4
	fmul.4s	v4, v2, v4
	fmul.4s	v7, v3, v7
	fadd.4s	v7, v15, v7
	fadd.4s	v4, v5, v4
	ldr	q18, [x2, #49168]
	ldr	q19, [x2, #49152]
	and.16b	v19, v6, v19
	and.16b	v18, v0, v18
	fmul.4s	v18, v2, v18
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v28, v19
	fadd.4s	v18, v17, v18
	ldr	q21, [x2, #53264]
	ldr	q22, [x2, #53248]
	and.16b	v22, v6, v22
	and.16b	v21, v0, v21
	fmul.4s	v21, v2, v21
	fmul.4s	v22, v3, v22
	ldr	q23, [sp, #2464]                ; 16-byte Reload
	fadd.4s	v22, v23, v22
	ldr	q24, [sp, #2448]                ; 16-byte Reload
	fadd.4s	v21, v24, v21
	mov.16b	v16, v15
	mov.16b	v15, v17
	mov.16b	v17, v28
	mov.16b	v28, v24
	mov.16b	v24, v23
	mov.16b	v23, v25
	ldr	q25, [x2, #57360]
	ldr	q26, [x2, #57344]
	and.16b	v26, v6, v26
	and.16b	v25, v0, v25
	fmul.4s	v2, v2, v25
	mov.16b	v25, v23
	mov.16b	v23, v24
	mov.16b	v24, v28
	mov.16b	v28, v17
	mov.16b	v17, v15
	fmul.4s	v3, v3, v26
	fadd.4s	v3, v20, v3
	fadd.4s	v2, v25, v2
	bit.16b	v5, v4, v0
	mov.16b	v15, v6
	bsl.16b	v15, v7, v16
	bit.16b	v17, v18, v0
	bit.16b	v28, v19, v6
	bit.16b	v24, v21, v0
	str	q24, [sp, #2448]                ; 16-byte Spill
	bit.16b	v23, v22, v6
	str	q23, [sp, #2464]                ; 16-byte Spill
	bit.16b	v25, v2, v0
	bit.16b	v20, v3, v6
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB1_77
; %bb.78:                               ; %direct.false286.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q5, [sp, #1936]                 ; 16-byte Spill
	str	q17, [sp, #1952]                ; 16-byte Spill
	str	q25, [sp, #1968]                ; 16-byte Spill
	str	q20, [sp, #1984]                ; 16-byte Spill
	ldr	q2, [sp, #2480]                 ; 16-byte Reload
	bic.16b	v2, v2, v0
	str	q2, [sp, #2480]                 ; 16-byte Spill
	bic.16b	v13, v13, v6
	ldr	q5, [sp, #1472]                 ; 16-byte Reload
	bic.16b	v5, v5, v0
	ldr	q20, [sp, #1488]                ; 16-byte Reload
	bic.16b	v20, v20, v6
	ldr	q27, [sp, #1504]                ; 16-byte Reload
	bic.16b	v27, v27, v0
	ldr	q14, [sp, #1520]                ; 16-byte Reload
	bic.16b	v14, v14, v6
	ldr	q26, [sp, #1536]                ; 16-byte Reload
	bic.16b	v26, v26, v0
	mov	x2, x10
	mov	w3, #128                        ; =0x80
	bic.16b	v1, v1, v6
LBB1_79:                                ; %direct.true323.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q3, q2, [x2]
	and.16b	v3, v6, v3
	and.16b	v2, v0, v2
	ldr	q4, [x2, #61456]
	ldr	q7, [x2, #61440]
	and.16b	v7, v6, v7
	and.16b	v4, v0, v4
	fmul.4s	v4, v2, v4
	fmul.4s	v7, v3, v7
	fadd.4s	v7, v13, v7
	ldr	q17, [sp, #2480]                ; 16-byte Reload
	fadd.4s	v4, v17, v4
	add	x4, x2, #16, lsl #12            ; =65536
	ldp	q19, q18, [x4]
	and.16b	v19, v6, v19
	and.16b	v18, v0, v18
	fmul.4s	v18, v2, v18
	fmul.4s	v19, v3, v19
	fadd.4s	v19, v20, v19
	fadd.4s	v18, v5, v18
	add	x4, x2, #17, lsl #12            ; =69632
	ldp	q22, q21, [x4]
	and.16b	v22, v6, v22
	and.16b	v21, v0, v21
	fmul.4s	v21, v2, v21
	fmul.4s	v22, v3, v22
	fadd.4s	v22, v14, v22
	fadd.4s	v21, v27, v21
	add	x4, x2, #18, lsl #12            ; =73728
	mov.16b	v16, v13
	mov.16b	v13, v5
	mov.16b	v5, v14
	mov.16b	v14, v26
	ldp	q26, q25, [x4]
	and.16b	v26, v6, v26
	and.16b	v25, v0, v25
	fmul.4s	v2, v2, v25
	fmul.4s	v3, v3, v26
	mov.16b	v26, v14
	mov.16b	v14, v5
	mov.16b	v5, v13
	fadd.4s	v3, v1, v3
	fadd.4s	v2, v26, v2
	bit.16b	v17, v4, v0
	str	q17, [sp, #2480]                ; 16-byte Spill
	mov.16b	v13, v6
	bsl.16b	v13, v7, v16
	bit.16b	v5, v18, v0
	bit.16b	v20, v19, v6
	bit.16b	v27, v21, v0
	bit.16b	v14, v22, v6
	bit.16b	v26, v2, v0
	bit.16b	v1, v3, v6
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB1_79
; %bb.80:                               ; %direct.false324.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x2, #0                          ; =0x0
	dup.4s	v25, w21
	ldr	q23, [sp, #1264]                ; 16-byte Reload
	fmul.4s	v7, v23, v25
	ldr	q2, [sp, #1760]                 ; 16-byte Reload
	fmul.4s	v22, v2, v25
	cmp	x1, #512
	cset	w3, lo
	dup.4h	v2, w3
	ldr	q24, [sp, #1280]                ; 16-byte Reload
	fmul.4s	v3, v24, v25
	ldr	q16, [sp, #1296]                ; 16-byte Reload
	fmul.4s	v4, v16, v25
	ldr	q17, [sp, #1312]                ; 16-byte Reload
	fmul.4s	v18, v17, v25
	ldp	q19, q21, [x11]
	ushll.4s	v2, v2, #0
	str	q22, [sp, #2192]                ; 16-byte Spill
	bit.16b	v21, v22, v0
	bit.16b	v19, v7, v6
	stp	q19, q21, [x11]
	shl.4s	v2, v2, #31
	cmlt.4s	v22, v2, #0
	mov.16b	v19, v1
	ldr	q1, [sp, #176]                  ; 16-byte Reload
	mov.16b	v21, v22
	bsl.16b	v21, v4, v1
	ldp	q2, q4, [x11, #32]
	bif.16b	v3, v1, v22
	str	q3, [sp, #1104]                 ; 16-byte Spill
	bif.16b	v3, v4, v0
	str	q21, [sp, #1120]                ; 16-byte Spill
	bit.16b	v2, v21, v6
	stp	q2, q3, [x11, #32]
	ldr	q2, [sp, #1792]                 ; 16-byte Reload
	fmul.4s	v2, v2, v25
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	fmul.4s	v3, v3, v25
	mov.16b	v21, v22
	bsl.16b	v21, v2, v1
	ldp	q2, q4, [x11, #64]
	bif.16b	v18, v1, v22
	str	q18, [sp, #1024]                ; 16-byte Spill
	bit.16b	v4, v18, v0
	str	q21, [sp, #1040]                ; 16-byte Spill
	bit.16b	v2, v21, v6
	stp	q2, q4, [x11, #64]
	ldr	q2, [sp, #1776]                 ; 16-byte Reload
	fmul.4s	v2, v2, v25
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	fmul.4s	v4, v4, v25
	mov.16b	v21, v22
	bsl.16b	v21, v2, v1
	ldp	q2, q18, [x11, #96]
	bif.16b	v3, v1, v22
	stp	q3, q21, [sp, #928]             ; 32-byte Folded Spill
	bif.16b	v3, v18, v0
	bit.16b	v2, v21, v6
	stp	q2, q3, [x11, #96]
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	fmul.4s	v2, v2, v25
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	fmul.4s	v3, v3, v25
	mov.16b	v21, v22
	bsl.16b	v21, v2, v1
	ldp	q2, q18, [x11, #128]
	bif.16b	v4, v1, v22
	stp	q4, q21, [sp, #832]             ; 32-byte Folded Spill
	bif.16b	v4, v18, v0
	bit.16b	v2, v21, v6
	stp	q2, q4, [x11, #128]
	ldr	q2, [sp, #1872]                 ; 16-byte Reload
	fmul.4s	v2, v2, v25
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	fmul.4s	v4, v4, v25
	mov.16b	v21, v22
	bsl.16b	v21, v2, v1
	ldp	q2, q18, [x11, #160]
	bif.16b	v3, v1, v22
	str	q3, [sp, #752]                  ; 16-byte Spill
	bif.16b	v3, v18, v0
	str	q21, [sp, #1744]                ; 16-byte Spill
	bit.16b	v2, v21, v6
	stp	q2, q3, [x11, #160]
	ldr	q2, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v2, v2, v25
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	fmul.4s	v3, v3, v25
	mov.16b	v21, v22
	bsl.16b	v21, v2, v1
	ldp	q2, q18, [x11, #192]
	bif.16b	v4, v1, v22
	str	q4, [sp, #688]                  ; 16-byte Spill
	bif.16b	v4, v18, v0
	str	q21, [sp, #1728]                ; 16-byte Spill
	bit.16b	v2, v21, v6
	stp	q2, q4, [x11, #192]
	ldr	q2, [sp, #1920]                 ; 16-byte Reload
	fmul.4s	v2, v2, v25
	ldr	q4, [sp, #1936]                 ; 16-byte Reload
	fmul.4s	v4, v4, v25
	mov.16b	v21, v22
	bsl.16b	v21, v2, v1
	ldp	q2, q18, [x11, #224]
	bif.16b	v3, v1, v22
	stp	q3, q21, [sp, #608]             ; 32-byte Folded Spill
	bif.16b	v3, v18, v0
	bit.16b	v2, v21, v6
	stp	q2, q3, [x11, #224]
	str	q15, [sp, #1328]                ; 16-byte Spill
	fmul.4s	v2, v15, v25
	str	q28, [sp, #1344]                ; 16-byte Spill
	fmul.4s	v3, v28, v25
	mov.16b	v21, v22
	bsl.16b	v21, v2, v1
	ldp	q2, q18, [x11, #256]
	bif.16b	v4, v1, v22
	str	q4, [sp, #528]                  ; 16-byte Spill
	bif.16b	v4, v18, v0
	str	q21, [sp, #1712]                ; 16-byte Spill
	bit.16b	v2, v21, v6
	stp	q2, q4, [x11, #256]
	ldr	q2, [sp, #1952]                 ; 16-byte Reload
	fmul.4s	v2, v2, v25
	ldr	q4, [sp, #2464]                 ; 16-byte Reload
	fmul.4s	v4, v4, v25
	mov.16b	v21, v22
	bsl.16b	v21, v2, v1
	ldp	q18, q2, [x11, #288]
	bif.16b	v3, v1, v22
	stp	q3, q21, [sp, #544]             ; 32-byte Folded Spill
	bif.16b	v3, v18, v6
	bit.16b	v2, v21, v0
	stp	q3, q2, [x11, #288]
	ldr	q2, [sp, #2448]                 ; 16-byte Reload
	fmul.4s	v2, v2, v25
	ldr	q3, [sp, #1984]                 ; 16-byte Reload
	fmul.4s	v3, v3, v25
	mov.16b	v21, v5
	mov.16b	v5, v22
	bsl.16b	v5, v2, v1
	ldp	q18, q2, [x11, #320]
	bif.16b	v4, v1, v22
	str	q4, [sp, #640]                  ; 16-byte Spill
	bif.16b	v4, v18, v6
	str	q5, [sp, #1696]                 ; 16-byte Spill
	bit.16b	v2, v5, v0
	stp	q4, q2, [x11, #320]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	fmul.4s	v2, v2, v25
	str	q13, [sp, #1360]                ; 16-byte Spill
	fmul.4s	v4, v13, v25
	mov.16b	v5, v22
	bsl.16b	v5, v2, v1
	ldp	q18, q2, [x11, #352]
	bif.16b	v3, v1, v22
	str	q3, [sp, #704]                  ; 16-byte Spill
	bif.16b	v3, v18, v6
	str	q5, [sp, #1680]                 ; 16-byte Spill
	bit.16b	v2, v5, v0
	stp	q3, q2, [x11, #352]
	ldr	q2, [sp, #2480]                 ; 16-byte Reload
	fmul.4s	v2, v2, v25
	str	q21, [sp, #1472]                ; 16-byte Spill
	fmul.4s	v3, v21, v25
	mov.16b	v5, v22
	bsl.16b	v5, v2, v1
	ldp	q18, q2, [x11, #384]
	bif.16b	v4, v1, v22
	stp	q4, q5, [sp, #768]              ; 32-byte Folded Spill
	bif.16b	v4, v18, v6
	bit.16b	v2, v5, v0
	stp	q4, q2, [x11, #384]
	str	q20, [sp, #1488]                ; 16-byte Spill
	fmul.4s	v2, v20, v25
	mov.16b	v4, v22
	bsl.16b	v4, v2, v1
	mov.16b	v5, v22
	bsl.16b	v5, v3, v1
	ldp	q2, q3, [x11, #416]
	stp	q5, q4, [sp, #864]              ; 32-byte Folded Spill
	bit.16b	v3, v5, v0
	bit.16b	v2, v4, v6
	stp	q2, q3, [x11, #416]
	str	q14, [sp, #1520]                ; 16-byte Spill
	fmul.4s	v2, v14, v25
	str	q27, [sp, #1504]                ; 16-byte Spill
	fmul.4s	v3, v27, v25
	mov.16b	v4, v22
	bsl.16b	v4, v3, v1
	mov.16b	v3, v22
	bsl.16b	v3, v2, v1
	ldr	q2, [x11, #448]
	stp	q3, q4, [sp, #960]              ; 32-byte Folded Spill
	bit.16b	v2, v3, v6
	ldr	q3, [x11, #464]
	bit.16b	v3, v4, v0
	stp	q2, q3, [x11, #448]
	str	q19, [sp, #1552]                ; 16-byte Spill
	fmul.4s	v2, v19, v25
	str	q26, [sp, #1536]                ; 16-byte Spill
	fmul.4s	v3, v26, v25
	mov.16b	v4, v22
	bsl.16b	v4, v3, v1
	bit.16b	v1, v2, v22
	ldp	q2, q3, [x11, #480]
	str	q1, [sp, #1056]                 ; 16-byte Spill
	bit.16b	v2, v1, v6
	str	q4, [sp, #1664]                 ; 16-byte Spill
	bit.16b	v3, v4, v0
	stp	q2, q3, [x11, #480]
	mvni.4s	v2, #127, msl #16
	ldr	q18, [sp, #1568]                ; 16-byte Reload
	bit.16b	v18, v2, v0
	ldr	q4, [sp, #1584]                 ; 16-byte Reload
	bit.16b	v4, v2, v6
	dup.8b	v2, w3
	str	d2, [sp, #1200]                 ; 8-byte Spill
LBB1_81:                                ; %direct.true458.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x3, x11, x2
	ldp	q2, q3, [x3]
	and.16b	v3, v0, v3
	and.16b	v2, v6, v2
	fmaxnm.4s	v2, v4, v2
	fmaxnm.4s	v3, v18, v3
	bit.16b	v18, v3, v0
	bit.16b	v4, v2, v6
	add	x2, x2, #32
	cmp	x2, #512
	b.ne	LBB1_81
; %bb.82:                               ; %direct.false459.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x2, #0                          ; =0x0
	ldr	q2, [sp, #1600]                 ; 16-byte Reload
	ldr	q1, [sp, #2432]                 ; 16-byte Reload
	ldr	q3, [sp, #2208]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #1600]                 ; 16-byte Spill
	str	q4, [sp, #1584]                 ; 16-byte Spill
	ldr	q1, [sp, #2000]                 ; 16-byte Reload
	fmaxnm.4s	v1, v1, v4
	str	q1, [sp, #2128]                 ; 16-byte Spill
	fsub.4s	v2, v7, v1
	ldp	q3, q1, [sp, #208]              ; 32-byte Folded Reload
	cmhi.4s	v22, v3, v1
	dup.4s	v25, w30
	and.16b	v15, v22, v2
	fcmge.4s	v2, v15, v25
	mov	w3, #1120403456                 ; =0x42c80000
	dup.4s	v26, w3
	fcmge.4s	v3, v26, v15
	and.16b	v2, v2, v3
	str	q18, [sp, #1568]                ; 16-byte Spill
	ldr	q3, [sp, #2016]                 ; 16-byte Reload
	fmaxnm.4s	v4, v3, v18
	str	q4, [sp, #2064]                 ; 16-byte Spill
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	fsub.4s	v3, v3, v4
	and.16b	v28, v0, v3
	fcmge.4s	v3, v28, v25
	fcmge.4s	v4, v26, v28
	and.16b	v3, v3, v4
	and.16b	v3, v3, v28
	mov	w3, #43579                      ; =0xaa3b
	movk	w3, #16312, lsl #16
	dup.4s	v1, w3
	str	q1, [sp, #2208]                 ; 16-byte Spill
	fmul.4s	v4, v3, v1
	movi.4s	v18, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	mov.16b	v7, v19
	bsl.16b	v7, v18, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v15
	fmul.4s	v7, v2, v1
	bif.16b	v18, v7, v19
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v20, v4
	scvtf.4s	v4, v20
	mov	w3, #29184                      ; =0x7200
	movk	w3, #16177, lsl #16
	dup.4s	v1, w3
	str	q1, [sp, #2160]                 ; 16-byte Spill
	fmul.4s	v19, v4, v1
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v1
	fsub.4s	v2, v2, v21
	mov	w3, #48782                      ; =0xbe8e
	movk	w3, #13759, lsl #16
	dup.4s	v14, w3
	fmul.4s	v19, v19, v14
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v14
	fsub.4s	v3, v3, v4
	mov	w3, #11226                      ; =0x2bda
	movk	w3, #14672, lsl #16
	dup.4s	v13, w3
	fmul.4s	v4, v3, v13
	mov	w3, #38601                      ; =0x96c9
	movk	w3, #15030, lsl #16
	dup.4s	v27, w3
	fadd.4s	v4, v4, v27
	str	q27, [sp, #2176]                ; 16-byte Spill
	mov	w3, #34982                      ; =0x88a6
	movk	w3, #15368, lsl #16
	dup.4s	v7, w3
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v7
	str	q7, [sp, #2192]                 ; 16-byte Spill
	fmul.4s	v4, v3, v4
	mov	w3, #43642                      ; =0xaa7a
	movk	w3, #15658, lsl #16
	dup.4s	v5, w3
	fadd.4s	v4, v4, v5
	str	q5, [sp, #2096]                 ; 16-byte Spill
	fmul.4s	v4, v3, v4
	mov	w3, #43691                      ; =0xaaab
	movk	w3, #15914, lsl #16
	dup.4s	v1, w3
	fadd.4s	v4, v4, v1
	str	q1, [sp, #2112]                 ; 16-byte Spill
	fmul.4s	v4, v3, v4
	movi.4s	v19, #63, lsl #24
	fadd.4s	v4, v4, v19
	movi.4s	v21, #63, lsl #24
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v13
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v7
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v1
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v21
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fmov.4s	v27, #1.00000000
	fadd.4s	v2, v2, v27
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v27
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v27
	sshr.4s	v19, v20, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v27
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v20, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v27
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v27
	fmul.4s	v2, v2, v4
	str	q15, [sp, #1136]                ; 16-byte Spill
	fcmgt.4s	v4, v25, v15
	bic.16b	v2, v2, v4
	str	q28, [sp, #1184]                ; 16-byte Spill
	fcmgt.4s	v4, v25, v28
	mov.16b	v5, v25
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v28, v26
	mvni.4s	v7, #127, msl #16
	fneg.4s	v27, v7
	bit.16b	v3, v27, v4
	str	q3, [sp, #1168]                 ; 16-byte Spill
	fcmgt.4s	v3, v15, v26
	mov.16b	v1, v26
	bit.16b	v2, v27, v3
	str	q2, [sp, #1152]                 ; 16-byte Spill
	ldr	q2, [sp, #1104]                 ; 16-byte Reload
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v28, v0, v2
	fcmge.4s	v2, v28, v25
	fcmge.4s	v3, v26, v28
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1120]                 ; 16-byte Reload
	ldr	q4, [sp, #2128]                 ; 16-byte Reload
	fsub.4s	v3, v3, v4
	and.16b	v15, v22, v3
	fcmge.4s	v3, v15, v25
	fcmge.4s	v4, v26, v15
	and.16b	v3, v3, v4
	and.16b	v3, v3, v15
	ldr	q20, [sp, #2208]                ; 16-byte Reload
	fmul.4s	v4, v3, v20
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v28
	fmul.4s	v7, v2, v20
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v7, v4
	scvtf.4s	v4, v7
	ldr	q20, [sp, #2160]                ; 16-byte Reload
	fmul.4s	v19, v4, v20
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v20
	fsub.4s	v2, v2, v21
	str	q14, [sp, #2144]                ; 16-byte Spill
	fmul.4s	v19, v19, v14
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v14
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v3, v13
	ldr	q26, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v4, v4, v26
	fmul.4s	v4, v3, v4
	ldr	q14, [sp, #2192]                ; 16-byte Reload
	fadd.4s	v4, v4, v14
	fmul.4s	v4, v3, v4
	ldr	q21, [sp, #2096]                ; 16-byte Reload
	fadd.4s	v4, v4, v21
	fmul.4s	v4, v3, v4
	ldr	q25, [sp, #2112]                ; 16-byte Reload
	fadd.4s	v4, v4, v25
	fmul.4s	v4, v3, v4
	movi.4s	v20, #63, lsl #24
	fadd.4s	v4, v4, v20
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v13
	fadd.4s	v19, v19, v26
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v14
	mov.16b	v26, v14
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v21
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fmov.4s	v20, #1.00000000
	fadd.4s	v2, v2, v20
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v20
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v20
	sshr.4s	v19, v7, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v20
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v7, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v20
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v20
	fmul.4s	v2, v2, v4
	str	q28, [sp, #1072]                ; 16-byte Spill
	mov.16b	v14, v5
	fcmgt.4s	v4, v5, v28
	bic.16b	v2, v2, v4
	str	q15, [sp, #1104]                ; 16-byte Spill
	fcmgt.4s	v4, v5, v15
	bic.16b	v3, v3, v4
	mov.16b	v25, v1
	fcmgt.4s	v4, v15, v1
	str	q27, [sp, #2080]                ; 16-byte Spill
	bit.16b	v3, v27, v4
	str	q3, [sp, #1120]                 ; 16-byte Spill
	fcmgt.4s	v3, v28, v1
	bit.16b	v2, v27, v3
	str	q2, [sp, #1088]                 ; 16-byte Spill
	ldr	q15, [sp, #2064]                ; 16-byte Reload
	ldr	q2, [sp, #1024]                 ; 16-byte Reload
	fsub.4s	v2, v2, v15
	and.16b	v20, v0, v2
	fcmge.4s	v2, v20, v5
	fcmge.4s	v3, v1, v20
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1040]                 ; 16-byte Reload
	ldr	q1, [sp, #2128]                 ; 16-byte Reload
	fsub.4s	v3, v3, v1
	and.16b	v28, v22, v3
	fcmge.4s	v3, v28, v5
	fcmge.4s	v4, v25, v28
	and.16b	v3, v3, v4
	and.16b	v3, v3, v28
	ldr	q1, [sp, #2208]                 ; 16-byte Reload
	fmul.4s	v4, v3, v1
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v20
	fmul.4s	v7, v2, v1
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v7, v4
	scvtf.4s	v4, v7
	ldr	q1, [sp, #2160]                 ; 16-byte Reload
	fmul.4s	v19, v4, v1
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v1
	fsub.4s	v2, v2, v21
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	fmul.4s	v19, v19, v1
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v1
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v3, v13
	ldr	q1, [sp, #2176]                 ; 16-byte Reload
	fadd.4s	v4, v4, v1
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v26
	fmul.4s	v4, v3, v4
	ldr	q21, [sp, #2096]                ; 16-byte Reload
	fadd.4s	v4, v4, v21
	fmul.4s	v4, v3, v4
	ldr	q27, [sp, #2112]                ; 16-byte Reload
	fadd.4s	v4, v4, v27
	fmul.4s	v4, v3, v4
	movi.4s	v5, #63, lsl #24
	fadd.4s	v4, v4, v5
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v13
	fadd.4s	v19, v19, v1
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v26
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v21
	mov.16b	v26, v21
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fmov.4s	v1, #1.00000000
	fadd.4s	v2, v2, v1
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v1
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v1
	sshr.4s	v19, v7, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v1
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v7, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v1
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v1
	fmul.4s	v2, v2, v4
	fcmgt.4s	v4, v14, v20
	bic.16b	v2, v2, v4
	str	q28, [sp, #1024]                ; 16-byte Spill
	fcmgt.4s	v4, v14, v28
	bic.16b	v3, v3, v4
	mov.16b	v1, v25
	fcmgt.4s	v4, v28, v25
	ldr	q25, [sp, #2080]                ; 16-byte Reload
	bit.16b	v3, v25, v4
	str	q3, [sp, #1040]                 ; 16-byte Spill
	fcmgt.4s	v3, v20, v1
	bit.16b	v2, v25, v3
	stp	q20, q2, [sp, #992]             ; 32-byte Folded Spill
	ldr	q2, [sp, #928]                  ; 16-byte Reload
	fsub.4s	v2, v2, v15
	and.16b	v15, v0, v2
	fcmge.4s	v2, v15, v14
	fcmge.4s	v3, v1, v15
	and.16b	v2, v2, v3
	ldr	q3, [sp, #944]                  ; 16-byte Reload
	ldr	q4, [sp, #2128]                 ; 16-byte Reload
	fsub.4s	v3, v3, v4
	and.16b	v5, v22, v3
	fcmge.4s	v3, v5, v14
	fcmge.4s	v4, v1, v5
	and.16b	v3, v3, v4
	and.16b	v3, v3, v5
	ldr	q18, [sp, #2208]                ; 16-byte Reload
	fmul.4s	v4, v3, v18
	movi.4s	v19, #75, lsl #24
	mvni.4s	v20, #128, lsl #24
	mov.16b	v7, v20
	bsl.16b	v7, v19, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v15
	fmul.4s	v7, v2, v18
	mov.16b	v18, v20
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v7, v4
	scvtf.4s	v4, v7
	ldr	q20, [sp, #2160]                ; 16-byte Reload
	fmul.4s	v19, v4, v20
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v20
	fsub.4s	v2, v2, v21
	ldr	q20, [sp, #2144]                ; 16-byte Reload
	fmul.4s	v19, v19, v20
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v20
	fsub.4s	v3, v3, v4
	mov.16b	v21, v13
	str	q13, [sp, #2048]                ; 16-byte Spill
	fmul.4s	v4, v3, v13
	ldr	q28, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v4, v4, v28
	fmul.4s	v4, v3, v4
	ldr	q20, [sp, #2192]                ; 16-byte Reload
	fadd.4s	v4, v4, v20
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v26
	fmul.4s	v4, v3, v4
	mov.16b	v13, v27
	fadd.4s	v4, v4, v27
	fmul.4s	v4, v3, v4
	movi.4s	v27, #63, lsl #24
	fadd.4s	v4, v4, v27
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v21
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v26
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v13
	mov.16b	v28, v13
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v27
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fmov.4s	v20, #1.00000000
	fadd.4s	v2, v2, v20
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v20
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v20
	sshr.4s	v19, v7, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v20
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v7, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v20
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v20
	fmul.4s	v2, v2, v4
	mov.16b	v7, v14
	fcmgt.4s	v4, v14, v15
	bic.16b	v2, v2, v4
	mov.16b	v14, v5
	str	q5, [sp, #928]                  ; 16-byte Spill
	fcmgt.4s	v4, v7, v5
	mov.16b	v5, v7
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v14, v1
	bit.16b	v3, v25, v4
	str	q3, [sp, #944]                  ; 16-byte Spill
	fcmgt.4s	v3, v15, v1
	bit.16b	v2, v25, v3
	stp	q15, q2, [sp, #896]             ; 32-byte Folded Spill
	ldr	q13, [sp, #2064]                ; 16-byte Reload
	ldr	q2, [sp, #832]                  ; 16-byte Reload
	fsub.4s	v2, v2, v13
	and.16b	v25, v0, v2
	fcmge.4s	v2, v25, v7
	fcmge.4s	v3, v1, v25
	and.16b	v2, v2, v3
	ldr	q3, [sp, #848]                  ; 16-byte Reload
	ldr	q4, [sp, #2128]                 ; 16-byte Reload
	fsub.4s	v3, v3, v4
	and.16b	v27, v22, v3
	fcmge.4s	v3, v27, v7
	fcmge.4s	v4, v1, v27
	and.16b	v3, v3, v4
	and.16b	v3, v3, v27
	ldr	q20, [sp, #2208]                ; 16-byte Reload
	fmul.4s	v4, v3, v20
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v25
	fmul.4s	v7, v2, v20
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v7, v4
	scvtf.4s	v4, v7
	ldr	q20, [sp, #2160]                ; 16-byte Reload
	fmul.4s	v19, v4, v20
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v20
	fsub.4s	v2, v2, v21
	ldr	q20, [sp, #2144]                ; 16-byte Reload
	fmul.4s	v19, v19, v20
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v20
	fsub.4s	v3, v3, v4
	ldr	q20, [sp, #2048]                ; 16-byte Reload
	fmul.4s	v4, v3, v20
	ldr	q21, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v4, v4, v21
	fmul.4s	v4, v3, v4
	ldr	q15, [sp, #2192]                ; 16-byte Reload
	fadd.4s	v4, v4, v15
	fmul.4s	v4, v3, v4
	mov.16b	v14, v26
	fadd.4s	v4, v4, v26
	fmul.4s	v4, v3, v4
	mov.16b	v26, v28
	fadd.4s	v4, v4, v28
	fmul.4s	v4, v3, v4
	movi.4s	v28, #63, lsl #24
	fadd.4s	v4, v4, v28
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v20
	fadd.4s	v19, v19, v21
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v15
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v14
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v26
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v28
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fmov.4s	v20, #1.00000000
	fadd.4s	v2, v2, v20
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v20
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v20
	sshr.4s	v19, v7, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v20
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v7, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v20
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v20
	fmul.4s	v2, v2, v4
	mov.16b	v28, v5
	fcmgt.4s	v4, v5, v25
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v5, v27
	bic.16b	v3, v3, v4
	mov.16b	v26, v1
	fcmgt.4s	v4, v27, v1
	ldr	q5, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v3, v5, v4
	stp	q27, q3, [sp, #832]             ; 32-byte Folded Spill
	fcmgt.4s	v3, v25, v1
	bit.16b	v2, v5, v3
	stp	q25, q2, [sp, #800]             ; 32-byte Folded Spill
	ldr	q2, [sp, #752]                  ; 16-byte Reload
	fsub.4s	v2, v2, v13
	and.16b	v13, v0, v2
	fcmge.4s	v2, v13, v28
	fcmge.4s	v3, v1, v13
	and.16b	v2, v2, v3
	ldr	q14, [sp, #2128]                ; 16-byte Reload
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	fsub.4s	v3, v3, v14
	and.16b	v1, v22, v3
	str	q1, [sp, #1744]                 ; 16-byte Spill
	fcmge.4s	v3, v1, v28
	fcmge.4s	v4, v26, v1
	and.16b	v3, v3, v4
	and.16b	v3, v3, v1
	ldr	q1, [sp, #2208]                 ; 16-byte Reload
	fmul.4s	v4, v3, v1
	movi.4s	v5, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v5, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v13
	fmul.4s	v7, v2, v1
	bsl.16b	v18, v5, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v20, v4
	scvtf.4s	v4, v20
	ldr	q1, [sp, #2160]                 ; 16-byte Reload
	fmul.4s	v19, v4, v1
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v1
	fsub.4s	v2, v2, v21
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	fmul.4s	v19, v19, v1
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v1
	fsub.4s	v3, v3, v4
	ldr	q27, [sp, #2048]                ; 16-byte Reload
	fmul.4s	v4, v3, v27
	ldr	q7, [sp, #2176]                 ; 16-byte Reload
	fadd.4s	v4, v4, v7
	fmul.4s	v4, v3, v4
	ldr	q5, [sp, #2192]                 ; 16-byte Reload
	fadd.4s	v4, v4, v5
	fmul.4s	v4, v3, v4
	ldr	q1, [sp, #2096]                 ; 16-byte Reload
	fadd.4s	v4, v4, v1
	fmul.4s	v4, v3, v4
	ldr	q25, [sp, #2112]                ; 16-byte Reload
	fadd.4s	v4, v4, v25
	fmul.4s	v4, v3, v4
	movi.4s	v21, #63, lsl #24
	fadd.4s	v4, v4, v21
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v27
	fadd.4s	v19, v19, v7
	mov.16b	v27, v7
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v1
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v21
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fmov.4s	v1, #1.00000000
	fadd.4s	v2, v2, v1
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v1
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v1
	sshr.4s	v19, v20, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v1
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v20, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v1
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v1
	fmov.4s	v15, #1.00000000
	fmul.4s	v2, v2, v4
	mov.16b	v25, v28
	fcmgt.4s	v4, v28, v13
	bic.16b	v2, v2, v4
	ldr	q20, [sp, #1744]                ; 16-byte Reload
	fcmgt.4s	v4, v28, v20
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v20, v26
	ldr	q1, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v3, v1, v4
	str	q3, [sp, #752]                  ; 16-byte Spill
	fcmgt.4s	v3, v13, v26
	bit.16b	v2, v1, v3
	stp	q13, q2, [sp, #720]             ; 32-byte Folded Spill
	ldr	q2, [sp, #688]                  ; 16-byte Reload
	ldr	q1, [sp, #2064]                 ; 16-byte Reload
	fsub.4s	v2, v2, v1
	and.16b	v20, v0, v2
	fcmge.4s	v2, v20, v28
	fcmge.4s	v3, v26, v20
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1728]                 ; 16-byte Reload
	fsub.4s	v3, v3, v14
	mov.16b	v28, v14
	and.16b	v1, v22, v3
	str	q1, [sp, #1728]                 ; 16-byte Spill
	fcmge.4s	v3, v1, v25
	fcmge.4s	v4, v26, v1
	and.16b	v3, v3, v4
	and.16b	v3, v3, v1
	ldr	q1, [sp, #2208]                 ; 16-byte Reload
	fmul.4s	v4, v3, v1
	mvni.4s	v18, #128, lsl #24
	movi.4s	v21, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v21, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v20
	fmul.4s	v7, v2, v1
	bsl.16b	v18, v21, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v7, v4
	scvtf.4s	v4, v7
	ldr	q1, [sp, #2160]                 ; 16-byte Reload
	fmul.4s	v19, v4, v1
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v1
	fsub.4s	v2, v2, v21
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	fmul.4s	v19, v19, v1
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v1
	fsub.4s	v3, v3, v4
	ldr	q5, [sp, #2048]                 ; 16-byte Reload
	fmul.4s	v4, v3, v5
	fadd.4s	v4, v4, v27
	fmul.4s	v4, v3, v4
	ldr	q1, [sp, #2192]                 ; 16-byte Reload
	fadd.4s	v4, v4, v1
	fmul.4s	v4, v3, v4
	ldr	q13, [sp, #2096]                ; 16-byte Reload
	fadd.4s	v4, v4, v13
	fmul.4s	v4, v3, v4
	ldr	q14, [sp, #2112]                ; 16-byte Reload
	fadd.4s	v4, v4, v14
	fmul.4s	v4, v3, v4
	movi.4s	v21, #63, lsl #24
	fadd.4s	v4, v4, v21
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v5
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v1
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v13
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v14
	mov.16b	v1, v14
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v21
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fadd.4s	v2, v2, v15
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v15
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v15
	sshr.4s	v19, v7, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v15
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v7, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v15
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v15
	fmul.4s	v2, v2, v4
	str	q20, [sp, #656]                 ; 16-byte Spill
	mov.16b	v5, v25
	fcmgt.4s	v4, v25, v20
	bic.16b	v2, v2, v4
	ldr	q25, [sp, #1728]                ; 16-byte Reload
	fcmgt.4s	v4, v5, v25
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v25, v26
	ldr	q7, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v3, v7, v4
	str	q3, [sp, #688]                  ; 16-byte Spill
	fcmgt.4s	v3, v20, v26
	mov.16b	v20, v26
	bit.16b	v2, v7, v3
	str	q2, [sp, #672]                  ; 16-byte Spill
	ldr	q14, [sp, #2064]                ; 16-byte Reload
	ldr	q2, [sp, #608]                  ; 16-byte Reload
	fsub.4s	v2, v2, v14
	and.16b	v25, v0, v2
	fcmge.4s	v2, v25, v5
	fcmge.4s	v3, v26, v25
	and.16b	v2, v2, v3
	ldr	q3, [sp, #624]                  ; 16-byte Reload
	fsub.4s	v3, v3, v28
	and.16b	v13, v22, v3
	fcmge.4s	v3, v13, v5
	fcmge.4s	v4, v26, v13
	and.16b	v3, v3, v4
	and.16b	v3, v3, v13
	ldr	q18, [sp, #2208]                ; 16-byte Reload
	fmul.4s	v4, v3, v18
	movi.4s	v19, #75, lsl #24
	mvni.4s	v21, #128, lsl #24
	mov.16b	v7, v21
	bsl.16b	v7, v19, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v25
	fmul.4s	v7, v2, v18
	mov.16b	v18, v21
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v7, v4
	scvtf.4s	v4, v7
	ldr	q21, [sp, #2160]                ; 16-byte Reload
	fmul.4s	v19, v4, v21
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v21
	fsub.4s	v2, v2, v21
	ldr	q21, [sp, #2144]                ; 16-byte Reload
	fmul.4s	v19, v19, v21
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v21
	fsub.4s	v3, v3, v4
	ldr	q28, [sp, #2048]                ; 16-byte Reload
	fmul.4s	v4, v3, v28
	fadd.4s	v4, v4, v27
	fmul.4s	v4, v3, v4
	ldr	q15, [sp, #2192]                ; 16-byte Reload
	fadd.4s	v4, v4, v15
	fmul.4s	v4, v3, v4
	ldr	q21, [sp, #2096]                ; 16-byte Reload
	fadd.4s	v4, v4, v21
	fmul.4s	v4, v3, v4
	mov.16b	v26, v1
	fadd.4s	v4, v4, v1
	fmul.4s	v4, v3, v4
	movi.4s	v1, #63, lsl #24
	fadd.4s	v4, v4, v1
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v28
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v15
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v21
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v26
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v1
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fmov.4s	v26, #1.00000000
	fadd.4s	v2, v2, v26
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v26
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v26
	sshr.4s	v19, v7, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v26
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v7, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v26
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v26
	fmul.4s	v2, v2, v4
	mov.16b	v27, v5
	fcmgt.4s	v4, v5, v25
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v5, v13
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v13, v20
	ldr	q18, [sp, #2080]                ; 16-byte Reload
	bit.16b	v3, v18, v4
	stp	q13, q3, [sp, #608]             ; 32-byte Folded Spill
	fcmgt.4s	v3, v25, v20
	mov.16b	v5, v20
	bit.16b	v2, v18, v3
	stp	q25, q2, [sp, #576]             ; 32-byte Folded Spill
	ldr	q2, [sp, #528]                  ; 16-byte Reload
	fsub.4s	v2, v2, v14
	mov.16b	v28, v14
	and.16b	v26, v0, v2
	fcmge.4s	v2, v26, v27
	fcmge.4s	v3, v20, v26
	and.16b	v2, v2, v3
	ldr	q20, [sp, #2128]                ; 16-byte Reload
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	fsub.4s	v3, v3, v20
	and.16b	v1, v22, v3
	str	q1, [sp, #1712]                 ; 16-byte Spill
	fcmge.4s	v3, v1, v27
	fcmge.4s	v4, v5, v1
	and.16b	v3, v3, v4
	and.16b	v3, v3, v1
	ldr	q1, [sp, #2208]                 ; 16-byte Reload
	fmul.4s	v4, v3, v1
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v26
	fmul.4s	v7, v2, v1
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v7, v4
	scvtf.4s	v4, v7
	ldr	q1, [sp, #2160]                 ; 16-byte Reload
	fmul.4s	v19, v4, v1
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v1
	fsub.4s	v2, v2, v21
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	fmul.4s	v19, v19, v1
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v1
	fsub.4s	v3, v3, v4
	ldr	q15, [sp, #2048]                ; 16-byte Reload
	fmul.4s	v4, v3, v15
	ldr	q25, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v4, v4, v25
	fmul.4s	v4, v3, v4
	ldr	q1, [sp, #2192]                 ; 16-byte Reload
	fadd.4s	v4, v4, v1
	fmul.4s	v4, v3, v4
	ldr	q13, [sp, #2096]                ; 16-byte Reload
	fadd.4s	v4, v4, v13
	fmul.4s	v4, v3, v4
	ldr	q14, [sp, #2112]                ; 16-byte Reload
	fadd.4s	v4, v4, v14
	fmul.4s	v4, v3, v4
	movi.4s	v21, #63, lsl #24
	fadd.4s	v4, v4, v21
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v15
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v1
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v13
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v14
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v21
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fmov.4s	v25, #1.00000000
	fadd.4s	v2, v2, v25
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v25
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v25
	sshr.4s	v19, v7, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v25
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v7, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v25
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v25
	fmul.4s	v2, v2, v4
	mov.16b	v15, v27
	fcmgt.4s	v4, v27, v26
	bic.16b	v2, v2, v4
	ldr	q27, [sp, #1712]                ; 16-byte Reload
	fcmgt.4s	v4, v15, v27
	mov.16b	v1, v15
	bic.16b	v3, v3, v4
	mov.16b	v15, v5
	fcmgt.4s	v4, v27, v5
	ldr	q7, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v3, v7, v4
	str	q3, [sp, #528]                  ; 16-byte Spill
	fcmgt.4s	v3, v26, v5
	bit.16b	v2, v7, v3
	stp	q26, q2, [sp, #496]             ; 32-byte Folded Spill
	ldr	q2, [sp, #544]                  ; 16-byte Reload
	fsub.4s	v2, v2, v20
	and.16b	v25, v22, v2
	fcmge.4s	v2, v25, v1
	fcmge.4s	v3, v5, v25
	and.16b	v2, v2, v3
	ldr	q3, [sp, #560]                  ; 16-byte Reload
	fsub.4s	v3, v3, v28
	and.16b	v13, v0, v3
	fcmge.4s	v3, v13, v1
	fcmge.4s	v4, v5, v13
	and.16b	v3, v3, v4
	and.16b	v3, v3, v13
	ldr	q5, [sp, #2208]                 ; 16-byte Reload
	fmul.4s	v4, v3, v5
	mvni.4s	v18, #128, lsl #24
	movi.4s	v20, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v20, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v25
	fmul.4s	v7, v2, v5
	bsl.16b	v18, v20, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v7, v4
	scvtf.4s	v4, v7
	ldr	q5, [sp, #2160]                 ; 16-byte Reload
	fmul.4s	v19, v4, v5
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v5
	fsub.4s	v2, v2, v21
	ldr	q5, [sp, #2144]                 ; 16-byte Reload
	fmul.4s	v19, v19, v5
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v5
	fsub.4s	v3, v3, v4
	ldr	q28, [sp, #2048]                ; 16-byte Reload
	fmul.4s	v4, v3, v28
	ldr	q20, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v4, v4, v20
	fmul.4s	v4, v3, v4
	ldr	q26, [sp, #2192]                ; 16-byte Reload
	fadd.4s	v4, v4, v26
	fmul.4s	v4, v3, v4
	ldr	q27, [sp, #2096]                ; 16-byte Reload
	fadd.4s	v4, v4, v27
	fmul.4s	v4, v3, v4
	mov.16b	v5, v14
	fadd.4s	v4, v4, v14
	fmul.4s	v4, v3, v4
	movi.4s	v21, #63, lsl #24
	fadd.4s	v4, v4, v21
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v28
	mov.16b	v14, v28
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v26
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v21
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fmov.4s	v5, #1.00000000
	fadd.4s	v2, v2, v5
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v5
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v5
	sshr.4s	v19, v7, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v5
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v7, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v5
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v5
	fmul.4s	v2, v2, v4
	mov.16b	v26, v1
	fcmgt.4s	v4, v1, v25
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v1, v13
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v13, v15
	ldr	q28, [sp, #2080]                ; 16-byte Reload
	bit.16b	v3, v28, v4
	stp	q13, q3, [sp, #544]             ; 32-byte Folded Spill
	fcmgt.4s	v3, v25, v15
	bit.16b	v2, v28, v3
	stp	q25, q2, [sp, #464]             ; 32-byte Folded Spill
	ldr	q2, [sp, #640]                  ; 16-byte Reload
	ldr	q1, [sp, #2128]                 ; 16-byte Reload
	fsub.4s	v2, v2, v1
	and.16b	v20, v22, v2
	fcmge.4s	v2, v20, v26
	fcmge.4s	v3, v15, v20
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1696]                 ; 16-byte Reload
	ldr	q13, [sp, #2064]                ; 16-byte Reload
	fsub.4s	v3, v3, v13
	and.16b	v1, v0, v3
	str	q1, [sp, #1696]                 ; 16-byte Spill
	fcmge.4s	v3, v1, v26
	fcmge.4s	v4, v15, v1
	and.16b	v3, v3, v4
	and.16b	v3, v3, v1
	ldr	q5, [sp, #2208]                 ; 16-byte Reload
	fmul.4s	v4, v3, v5
	movi.4s	v19, #75, lsl #24
	mvni.4s	v1, #128, lsl #24
	mov.16b	v7, v1
	bsl.16b	v7, v19, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v20
	fmul.4s	v7, v2, v5
	mov.16b	v18, v1
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v7, v4
	scvtf.4s	v4, v7
	ldr	q1, [sp, #2160]                 ; 16-byte Reload
	fmul.4s	v19, v4, v1
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v1
	fsub.4s	v2, v2, v21
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	fmul.4s	v19, v19, v1
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v1
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v3, v14
	ldr	q5, [sp, #2176]                 ; 16-byte Reload
	fadd.4s	v4, v4, v5
	fmul.4s	v4, v3, v4
	ldr	q1, [sp, #2192]                 ; 16-byte Reload
	fadd.4s	v4, v4, v1
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v27
	fmul.4s	v4, v3, v4
	ldr	q25, [sp, #2112]                ; 16-byte Reload
	fadd.4s	v4, v4, v25
	fmul.4s	v4, v3, v4
	movi.4s	v21, #63, lsl #24
	fadd.4s	v4, v4, v21
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v14
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v1
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v21
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fmov.4s	v1, #1.00000000
	fadd.4s	v2, v2, v1
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v1
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v1
	sshr.4s	v19, v7, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v1
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v7, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v1
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v1
	fmul.4s	v2, v2, v4
	mov.16b	v27, v26
	fcmgt.4s	v4, v26, v20
	bic.16b	v2, v2, v4
	ldr	q26, [sp, #1696]                ; 16-byte Reload
	fcmgt.4s	v4, v27, v26
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v26, v15
	bit.16b	v3, v28, v4
	str	q3, [sp, #640]                  ; 16-byte Spill
	fcmgt.4s	v3, v20, v15
	bit.16b	v2, v28, v3
	stp	q20, q2, [sp, #432]             ; 32-byte Folded Spill
	ldr	q2, [sp, #704]                  ; 16-byte Reload
	ldr	q28, [sp, #2128]                ; 16-byte Reload
	fsub.4s	v2, v2, v28
	and.16b	v14, v22, v2
	fcmge.4s	v2, v14, v27
	fcmge.4s	v3, v15, v14
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1680]                 ; 16-byte Reload
	fsub.4s	v3, v3, v13
	and.16b	v1, v0, v3
	str	q1, [sp, #1680]                 ; 16-byte Spill
	fcmge.4s	v3, v1, v27
	fcmge.4s	v4, v15, v1
	and.16b	v3, v3, v4
	and.16b	v3, v3, v1
	ldr	q5, [sp, #2208]                 ; 16-byte Reload
	fmul.4s	v4, v3, v5
	mvni.4s	v18, #128, lsl #24
	movi.4s	v1, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v1, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v14
	fmul.4s	v7, v2, v5
	bsl.16b	v18, v1, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v25, v4
	scvtf.4s	v4, v25
	ldr	q13, [sp, #2160]                ; 16-byte Reload
	fmul.4s	v19, v4, v13
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v13
	fsub.4s	v2, v2, v21
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	fmul.4s	v19, v19, v1
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v1
	fsub.4s	v3, v3, v4
	ldr	q7, [sp, #2048]                 ; 16-byte Reload
	fmul.4s	v4, v3, v7
	ldr	q5, [sp, #2176]                 ; 16-byte Reload
	fadd.4s	v4, v4, v5
	fmul.4s	v4, v3, v4
	ldr	q20, [sp, #2192]                ; 16-byte Reload
	fadd.4s	v4, v4, v20
	fmul.4s	v4, v3, v4
	ldr	q21, [sp, #2096]                ; 16-byte Reload
	fadd.4s	v4, v4, v21
	fmul.4s	v4, v3, v4
	ldr	q1, [sp, #2112]                 ; 16-byte Reload
	fadd.4s	v4, v4, v1
	fmul.4s	v4, v3, v4
	movi.4s	v26, #63, lsl #24
	fadd.4s	v4, v4, v26
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v7
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v21
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v1
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v26
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fmov.4s	v1, #1.00000000
	fadd.4s	v2, v2, v1
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v1
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v1
	sshr.4s	v19, v25, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v1
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v25, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v1
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v1
	fmul.4s	v2, v2, v4
	mov.16b	v5, v27
	fcmgt.4s	v4, v27, v14
	bic.16b	v2, v2, v4
	ldr	q27, [sp, #1680]                ; 16-byte Reload
	fcmgt.4s	v4, v5, v27
	mov.16b	v1, v5
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v27, v15
	ldr	q5, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v3, v5, v4
	str	q3, [sp, #704]                  ; 16-byte Spill
	fcmgt.4s	v3, v14, v15
	bit.16b	v2, v5, v3
	stp	q14, q2, [sp, #400]             ; 32-byte Folded Spill
	ldr	q2, [sp, #768]                  ; 16-byte Reload
	fsub.4s	v2, v2, v28
	and.16b	v26, v22, v2
	fcmge.4s	v2, v26, v1
	fcmge.4s	v3, v15, v26
	and.16b	v2, v2, v3
	ldr	q3, [sp, #784]                  ; 16-byte Reload
	ldr	q4, [sp, #2064]                 ; 16-byte Reload
	fsub.4s	v3, v3, v4
	and.16b	v25, v0, v3
	fcmge.4s	v3, v25, v1
	fcmge.4s	v4, v15, v25
	and.16b	v3, v3, v4
	and.16b	v3, v3, v25
	ldr	q5, [sp, #2208]                 ; 16-byte Reload
	fmul.4s	v4, v3, v5
	mvni.4s	v18, #128, lsl #24
	movi.4s	v20, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v20, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v26
	fmul.4s	v7, v2, v5
	bsl.16b	v18, v20, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v7, v4
	scvtf.4s	v4, v7
	fmul.4s	v19, v4, v13
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v13
	fsub.4s	v2, v2, v21
	ldr	q5, [sp, #2144]                 ; 16-byte Reload
	fmul.4s	v19, v19, v5
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v5
	fsub.4s	v3, v3, v4
	ldr	q13, [sp, #2048]                ; 16-byte Reload
	fmul.4s	v4, v3, v13
	ldr	q28, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v4, v4, v28
	fmul.4s	v4, v3, v4
	ldr	q21, [sp, #2192]                ; 16-byte Reload
	fadd.4s	v4, v4, v21
	fmul.4s	v4, v3, v4
	ldr	q27, [sp, #2096]                ; 16-byte Reload
	fadd.4s	v4, v4, v27
	fmul.4s	v4, v3, v4
	ldr	q5, [sp, #2112]                 ; 16-byte Reload
	fadd.4s	v4, v4, v5
	fmul.4s	v4, v3, v4
	movi.4s	v20, #63, lsl #24
	fadd.4s	v4, v4, v20
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v13
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v21
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fmov.4s	v5, #1.00000000
	fadd.4s	v2, v2, v5
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v5
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v5
	sshr.4s	v19, v7, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v5
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v7, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v5
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v5
	fmov.4s	v27, #1.00000000
	fmul.4s	v2, v2, v4
	mov.16b	v28, v1
	fcmgt.4s	v4, v1, v26
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v1, v25
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v25, v15
	ldr	q1, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v3, v1, v4
	stp	q25, q3, [sp, #768]             ; 32-byte Folded Spill
	fcmgt.4s	v3, v26, v15
	bit.16b	v2, v1, v3
	stp	q26, q2, [sp, #368]             ; 32-byte Folded Spill
	ldr	q2, [sp, #864]                  ; 16-byte Reload
	ldr	q1, [sp, #2064]                 ; 16-byte Reload
	fsub.4s	v2, v2, v1
	and.16b	v25, v0, v2
	fcmge.4s	v2, v25, v28
	fcmge.4s	v3, v15, v25
	and.16b	v2, v2, v3
	ldr	q3, [sp, #880]                  ; 16-byte Reload
	ldr	q1, [sp, #2128]                 ; 16-byte Reload
	fsub.4s	v3, v3, v1
	and.16b	v14, v22, v3
	fcmge.4s	v3, v14, v28
	fcmge.4s	v4, v15, v14
	and.16b	v3, v3, v4
	and.16b	v3, v3, v14
	ldr	q5, [sp, #2208]                 ; 16-byte Reload
	fmul.4s	v4, v3, v5
	movi.4s	v18, #75, lsl #24
	mvni.4s	v1, #128, lsl #24
	mov.16b	v7, v1
	bsl.16b	v7, v18, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v25
	fmul.4s	v7, v2, v5
	bif.16b	v18, v7, v1
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v20, v4
	scvtf.4s	v4, v20
	ldr	q1, [sp, #2160]                 ; 16-byte Reload
	fmul.4s	v19, v4, v1
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v1
	fsub.4s	v2, v2, v21
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	fmul.4s	v19, v19, v1
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v1
	fsub.4s	v3, v3, v4
	mov.16b	v7, v13
	fmul.4s	v4, v3, v13
	ldr	q5, [sp, #2176]                 ; 16-byte Reload
	fadd.4s	v4, v4, v5
	fmul.4s	v4, v3, v4
	ldr	q1, [sp, #2192]                 ; 16-byte Reload
	fadd.4s	v4, v4, v1
	fmul.4s	v4, v3, v4
	ldr	q13, [sp, #2096]                ; 16-byte Reload
	fadd.4s	v4, v4, v13
	fmul.4s	v4, v3, v4
	ldr	q26, [sp, #2112]                ; 16-byte Reload
	fadd.4s	v4, v4, v26
	fmul.4s	v4, v3, v4
	movi.4s	v21, #63, lsl #24
	fadd.4s	v4, v4, v21
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v7
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v1
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v13
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v26
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v21
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fadd.4s	v2, v2, v27
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v27
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v27
	sshr.4s	v19, v20, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v27
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v20, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v27
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v27
	fmul.4s	v2, v2, v4
	fcmgt.4s	v4, v28, v25
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v28, v14
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v14, v15
	ldr	q1, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v3, v1, v4
	stp	q14, q3, [sp, #864]             ; 32-byte Folded Spill
	fcmgt.4s	v3, v25, v15
	bit.16b	v2, v1, v3
	stp	q25, q2, [sp, #336]             ; 32-byte Folded Spill
	ldr	q2, [sp, #960]                  ; 16-byte Reload
	ldr	q1, [sp, #2128]                 ; 16-byte Reload
	fsub.4s	v2, v2, v1
	and.16b	v25, v22, v2
	fcmge.4s	v2, v25, v28
	fcmge.4s	v3, v15, v25
	and.16b	v2, v2, v3
	ldr	q3, [sp, #976]                  ; 16-byte Reload
	ldr	q14, [sp, #2064]                ; 16-byte Reload
	fsub.4s	v3, v3, v14
	and.16b	v20, v0, v3
	fcmge.4s	v3, v20, v28
	fcmge.4s	v4, v15, v20
	and.16b	v3, v3, v4
	and.16b	v3, v3, v20
	ldr	q1, [sp, #2208]                 ; 16-byte Reload
	fmul.4s	v4, v3, v1
	mvni.4s	v18, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v19, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v25
	fmul.4s	v7, v2, v1
	bsl.16b	v18, v19, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v7, v4
	scvtf.4s	v4, v7
	ldr	q1, [sp, #2160]                 ; 16-byte Reload
	fmul.4s	v19, v4, v1
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v1
	fsub.4s	v2, v2, v21
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	fmul.4s	v19, v19, v1
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v1
	fsub.4s	v3, v3, v4
	ldr	q1, [sp, #2048]                 ; 16-byte Reload
	fmul.4s	v4, v3, v1
	ldr	q21, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v4, v4, v21
	fmul.4s	v4, v3, v4
	ldr	q27, [sp, #2192]                ; 16-byte Reload
	fadd.4s	v4, v4, v27
	fmul.4s	v4, v3, v4
	mov.16b	v26, v13
	fadd.4s	v4, v4, v13
	fmul.4s	v4, v3, v4
	ldr	q13, [sp, #2112]                ; 16-byte Reload
	fadd.4s	v4, v4, v13
	fmul.4s	v4, v3, v4
	movi.4s	v5, #63, lsl #24
	fadd.4s	v4, v4, v5
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v1
	fadd.4s	v19, v19, v21
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v26
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v13
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v5
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fmov.4s	v1, #1.00000000
	fadd.4s	v2, v2, v1
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v1
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v1
	sshr.4s	v19, v7, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v1
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v7, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v1
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v1
	fmul.4s	v2, v2, v4
	fcmgt.4s	v4, v28, v25
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v28, v20
	mov.16b	v13, v28
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v20, v15
	ldr	q1, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v3, v1, v4
	stp	q20, q3, [sp, #960]             ; 32-byte Folded Spill
	fcmgt.4s	v3, v25, v15
	bit.16b	v2, v1, v3
	stp	q25, q2, [sp, #304]             ; 32-byte Folded Spill
	ldr	q2, [sp, #1056]                 ; 16-byte Reload
	ldr	q1, [sp, #2128]                 ; 16-byte Reload
	fsub.4s	v2, v2, v1
	and.16b	v26, v22, v2
	fcmge.4s	v2, v26, v28
	fcmge.4s	v3, v15, v26
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	fsub.4s	v3, v3, v14
	and.16b	v1, v0, v3
	str	q1, [sp, #1664]                 ; 16-byte Spill
	fcmge.4s	v3, v1, v28
	fcmge.4s	v4, v15, v1
	and.16b	v3, v3, v4
	and.16b	v3, v3, v1
	ldr	q1, [sp, #2208]                 ; 16-byte Reload
	fmul.4s	v4, v3, v1
	movi.4s	v18, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	mov.16b	v7, v19
	bsl.16b	v7, v18, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v26
	fmul.4s	v7, v2, v1
	bif.16b	v18, v7, v19
	fadd.4s	v7, v7, v18
	fsub.4s	v18, v7, v18
	fcvtzs.4s	v7, v4
	scvtf.4s	v4, v7
	ldr	q28, [sp, #2160]                ; 16-byte Reload
	fmul.4s	v19, v4, v28
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	fmul.4s	v21, v19, v28
	fsub.4s	v2, v2, v21
	ldr	q20, [sp, #2144]                ; 16-byte Reload
	fmul.4s	v19, v19, v20
	fsub.4s	v2, v2, v19
	fmul.4s	v4, v4, v20
	fsub.4s	v3, v3, v4
	ldr	q21, [sp, #2048]                ; 16-byte Reload
	fmul.4s	v4, v3, v21
	ldr	q5, [sp, #2176]                 ; 16-byte Reload
	fadd.4s	v4, v4, v5
	fmul.4s	v4, v3, v4
	mov.16b	v1, v27
	fadd.4s	v4, v4, v27
	fmul.4s	v4, v3, v4
	ldr	q14, [sp, #2096]                ; 16-byte Reload
	fadd.4s	v4, v4, v14
	fmul.4s	v4, v3, v4
	ldr	q27, [sp, #2112]                ; 16-byte Reload
	fadd.4s	v4, v4, v27
	fmul.4s	v4, v3, v4
	movi.4s	v25, #63, lsl #24
	fadd.4s	v4, v4, v25
	fmul.4s	v19, v3, v3
	fmul.4s	v4, v19, v4
	fmul.4s	v19, v2, v21
	fadd.4s	v19, v19, v5
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v1
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v14
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v25
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v4
	fmov.4s	v1, #1.00000000
	fadd.4s	v2, v2, v1
	sshr.4s	v4, v18, #1
	shl.4s	v19, v4, #23
	add.4s	v19, v19, v1
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v1
	sshr.4s	v19, v7, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v1
	fmul.4s	v3, v3, v21
	sub.4s	v4, v18, v4
	sub.4s	v7, v7, v19
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v1
	fmul.4s	v3, v3, v7
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v1
	fmov.4s	v27, #1.00000000
	fmul.4s	v2, v2, v4
	mov.16b	v5, v13
	fcmgt.4s	v4, v13, v26
	bic.16b	v2, v2, v4
	ldr	q13, [sp, #1664]                ; 16-byte Reload
	fcmgt.4s	v4, v5, v13
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v13, v15
	ldr	q25, [sp, #2080]                ; 16-byte Reload
	bit.16b	v3, v25, v4
	str	q3, [sp, #1056]                 ; 16-byte Spill
	fcmgt.4s	v3, v26, v15
	mov.16b	v1, v15
	bit.16b	v2, v25, v3
	stp	q26, q2, [sp, #272]             ; 32-byte Folded Spill
	ldr	q3, [sp, #2128]                 ; 16-byte Reload
	ldr	q2, [sp, #2000]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v15, v22, v2
	fcmge.4s	v2, v15, v5
	fcmge.4s	v3, v1, v15
	and.16b	v2, v2, v3
	ldr	q3, [sp, #2016]                 ; 16-byte Reload
	ldr	q4, [sp, #2064]                 ; 16-byte Reload
	fsub.4s	v3, v3, v4
	and.16b	v14, v0, v3
	fcmge.4s	v3, v14, v5
	fcmge.4s	v4, v1, v14
	and.16b	v3, v3, v4
	and.16b	v3, v3, v14
	ldr	q19, [sp, #2208]                ; 16-byte Reload
	fmul.4s	v4, v3, v19
	mvni.4s	v18, #128, lsl #24
	movi.4s	v21, #75, lsl #24
	mov.16b	v7, v18
	bsl.16b	v7, v21, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v2, v2, v15
	fmul.4s	v7, v2, v19
	bsl.16b	v18, v21, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v4, v4
	scvtf.4s	v18, v4
	fmul.4s	v19, v18, v28
	fsub.4s	v3, v3, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v21, v19, v28
	fsub.4s	v2, v2, v21
	fmul.4s	v18, v18, v20
	fmul.4s	v19, v19, v20
	fsub.4s	v2, v2, v19
	fsub.4s	v3, v3, v18
	ldr	q19, [sp, #2048]                ; 16-byte Reload
	fmul.4s	v18, v3, v19
	fmul.4s	v19, v2, v19
	ldr	q13, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v19, v19, v13
	fadd.4s	v18, v18, v13
	fmul.4s	v18, v3, v18
	fmul.4s	v19, v2, v19
	ldr	q20, [sp, #2192]                ; 16-byte Reload
	fadd.4s	v19, v19, v20
	fadd.4s	v18, v18, v20
	fmul.4s	v18, v3, v18
	fmul.4s	v19, v2, v19
	ldr	q20, [sp, #2096]                ; 16-byte Reload
	fadd.4s	v19, v19, v20
	fadd.4s	v18, v18, v20
	fmul.4s	v18, v3, v18
	fmul.4s	v19, v2, v19
	ldr	q20, [sp, #2112]                ; 16-byte Reload
	fadd.4s	v19, v19, v20
	fadd.4s	v18, v18, v20
	fmul.4s	v18, v3, v18
	movi.4s	v20, #63, lsl #24
	fadd.4s	v18, v18, v20
	fmul.4s	v21, v3, v3
	fmul.4s	v18, v21, v18
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v21, v2, v2
	fmul.4s	v19, v21, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	fadd.4s	v2, v2, v27
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v27
	fmul.4s	v2, v2, v19
	fadd.4s	v3, v3, v27
	sshr.4s	v19, v4, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v27
	fmul.4s	v3, v3, v21
	sub.4s	v7, v7, v18
	sub.4s	v4, v4, v19
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v27
	fmul.4s	v3, v3, v4
	shl.4s	v4, v7, #23
	add.4s	v4, v4, v27
	fmul.4s	v2, v2, v4
	fcmgt.4s	v4, v5, v15
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v5, v14
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v14, v1
	bit.16b	v3, v25, v4
	str	q3, [sp, #256]                  ; 16-byte Spill
	fcmgt.4s	v3, v15, v1
	mov.16b	v1, v3
	bsl.16b	v1, v25, v2
	str	q1, [sp, #240]                  ; 16-byte Spill
	sshll2.2d	v2, v22, #0
	ldr	q1, [sp, #1632]                 ; 16-byte Reload
	ldr	q3, [sp, #1216]                 ; 16-byte Reload
	bit.16b	v1, v3, v2
	str	q1, [sp, #1632]                 ; 16-byte Spill
	sshll.2d	v2, v0, #0
	ldr	q1, [sp, #1616]                 ; 16-byte Reload
	ldr	q3, [sp, #1232]                 ; 16-byte Reload
	bit.16b	v1, v3, v2
	str	q1, [sp, #1616]                 ; 16-byte Spill
	ldr	q1, [sp, #1136]                 ; 16-byte Reload
	fcmeq.4s	v2, v1, v1
	ldr	q1, [sp, #144]                  ; 16-byte Reload
	ldr	q3, [sp, #1152]                 ; 16-byte Reload
	mov.16b	v20, v2
	bsl.16b	v20, v3, v1
	ldr	q2, [sp, #1184]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #1168]                 ; 16-byte Reload
	mov.16b	v26, v2
	bsl.16b	v26, v3, v1
	ldr	q2, [sp, #1072]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #1088]                 ; 16-byte Reload
	bsl.16b	v2, v3, v1
	ldr	q3, [sp, #1104]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q4, [sp, #1120]                 ; 16-byte Reload
	bsl.16b	v3, v4, v1
	ldp	q4, q5, [sp, #992]              ; 32-byte Folded Reload
	fcmeq.4s	v4, v4, v4
	bsl.16b	v4, v5, v1
	ldr	q5, [sp, #1024]                 ; 16-byte Reload
	fcmeq.4s	v7, v5, v5
	ldr	q5, [sp, #1040]                 ; 16-byte Reload
	mov.16b	v19, v7
	bsl.16b	v19, v5, v1
	ldr	q5, [sp, #896]                  ; 16-byte Reload
	fcmeq.4s	v7, v5, v5
	ldr	q5, [sp, #912]                  ; 16-byte Reload
	mov.16b	v21, v7
	bsl.16b	v21, v5, v1
	ldr	q5, [sp, #928]                  ; 16-byte Reload
	fcmeq.4s	v7, v5, v5
	ldr	q5, [sp, #944]                  ; 16-byte Reload
	mov.16b	v13, v7
	bsl.16b	v13, v5, v1
	ldr	q5, [sp, #800]                  ; 16-byte Reload
	fcmeq.4s	v7, v5, v5
	ldr	q5, [sp, #816]                  ; 16-byte Reload
	mov.16b	v25, v7
	bsl.16b	v25, v5, v1
	ldr	q5, [sp, #832]                  ; 16-byte Reload
	fcmeq.4s	v7, v5, v5
	ldr	q5, [sp, #848]                  ; 16-byte Reload
	bsl.16b	v7, v5, v1
	ldr	q5, [sp, #720]                  ; 16-byte Reload
	fcmeq.4s	v18, v5, v5
	ldr	q5, [sp, #736]                  ; 16-byte Reload
	bif.16b	v5, v1, v18
	str	q5, [sp, #1072]                 ; 16-byte Spill
	ldr	q5, [sp, #1744]                 ; 16-byte Reload
	fcmeq.4s	v18, v5, v5
	ldr	q5, [sp, #752]                  ; 16-byte Reload
	mov.16b	v27, v18
	bsl.16b	v27, v5, v1
	ldr	q5, [sp, #656]                  ; 16-byte Reload
	fcmeq.4s	v18, v5, v5
	ldr	q5, [sp, #672]                  ; 16-byte Reload
	bif.16b	v5, v1, v18
	str	q5, [sp, #1104]                 ; 16-byte Spill
	ldr	q5, [sp, #1728]                 ; 16-byte Reload
	fcmeq.4s	v18, v5, v5
	ldr	q5, [sp, #688]                  ; 16-byte Reload
	bif.16b	v5, v1, v18
	str	q5, [sp, #1088]                 ; 16-byte Spill
	ldr	q5, [sp, #576]                  ; 16-byte Reload
	fcmeq.4s	v18, v5, v5
	ldr	q5, [sp, #592]                  ; 16-byte Reload
	bif.16b	v5, v1, v18
	str	q5, [sp, #1232]                 ; 16-byte Spill
	ldr	q5, [sp, #608]                  ; 16-byte Reload
	fcmeq.4s	v18, v5, v5
	ldr	q5, [sp, #624]                  ; 16-byte Reload
	bif.16b	v5, v1, v18
	str	q5, [sp, #1216]                 ; 16-byte Spill
	ldr	q5, [sp, #496]                  ; 16-byte Reload
	fcmeq.4s	v18, v5, v5
	ldr	q5, [sp, #512]                  ; 16-byte Reload
	bif.16b	v5, v1, v18
	str	q5, [sp, #1184]                 ; 16-byte Spill
	ldr	q5, [sp, #1712]                 ; 16-byte Reload
	fcmeq.4s	v18, v5, v5
	ldr	q5, [sp, #528]                  ; 16-byte Reload
	bif.16b	v5, v1, v18
	str	q5, [sp, #1136]                 ; 16-byte Spill
	ldr	q5, [sp, #464]                  ; 16-byte Reload
	fcmeq.4s	v18, v5, v5
	ldr	q5, [sp, #480]                  ; 16-byte Reload
	bif.16b	v5, v1, v18
	str	q5, [sp, #1168]                 ; 16-byte Spill
	ldr	q5, [sp, #544]                  ; 16-byte Reload
	fcmeq.4s	v18, v5, v5
	ldr	q5, [sp, #560]                  ; 16-byte Reload
	bif.16b	v5, v1, v18
	str	q5, [sp, #1152]                 ; 16-byte Spill
	ldr	q18, [x11, #528]
	str	q26, [sp, #2192]                ; 16-byte Spill
	bit.16b	v18, v26, v0
	ldr	q26, [x11, #512]
	str	q20, [sp, #2208]                ; 16-byte Spill
	bit.16b	v26, v20, v22
	stp	q26, q18, [x11, #512]
	ldr	d5, [sp, #1200]                 ; 8-byte Reload
	zip1.8b	v18, v5, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v26, v18, #0
	and.16b	v20, v26, v3
	zip2.8b	v3, v5, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v18, v3, #0
	and.16b	v3, v18, v2
	ldr	q2, [x11, #560]
	str	q3, [sp, #2160]                 ; 16-byte Spill
	bit.16b	v2, v3, v0
	ldr	q3, [x11, #544]
	str	q20, [sp, #2176]                ; 16-byte Spill
	bit.16b	v3, v20, v22
	stp	q3, q2, [x11, #544]
	ldp	q2, q3, [sp, #432]              ; 32-byte Folded Reload
	fcmeq.4s	v2, v2, v2
	bsl.16b	v2, v3, v1
	str	q2, [sp, #1120]                 ; 16-byte Spill
	and.16b	v5, v26, v19
	and.16b	v3, v18, v4
	ldr	q2, [x11, #592]
	str	q3, [sp, #2112]                 ; 16-byte Spill
	bit.16b	v2, v3, v0
	ldr	q3, [x11, #576]
	str	q5, [sp, #2144]                 ; 16-byte Spill
	bit.16b	v3, v5, v22
	stp	q3, q2, [x11, #576]
	ldr	q2, [sp, #1696]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #640]                  ; 16-byte Reload
	mov.16b	v28, v2
	bsl.16b	v28, v3, v1
	and.16b	v4, v26, v13
	and.16b	v3, v18, v21
	ldr	q2, [x11, #624]
	str	q3, [sp, #2080]                 ; 16-byte Spill
	bit.16b	v2, v3, v0
	ldr	q3, [x11, #608]
	str	q4, [sp, #2096]                 ; 16-byte Spill
	bit.16b	v3, v4, v22
	stp	q3, q2, [x11, #608]
	ldp	q2, q3, [sp, #400]              ; 32-byte Folded Reload
	fcmeq.4s	v2, v2, v2
	mov.16b	v13, v2
	bsl.16b	v13, v3, v1
	and.16b	v4, v26, v7
	and.16b	v3, v18, v25
	ldr	q2, [x11, #656]
	str	q3, [sp, #1744]                 ; 16-byte Spill
	bit.16b	v2, v3, v0
	ldr	q3, [x11, #640]
	str	q4, [sp, #2048]                 ; 16-byte Spill
	bit.16b	v3, v4, v22
	stp	q3, q2, [x11, #640]
	ldr	q2, [sp, #1680]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #704]                  ; 16-byte Reload
	bsl.16b	v2, v3, v1
	and.16b	v5, v26, v27
	ldr	q3, [sp, #1072]                 ; 16-byte Reload
	and.16b	v4, v18, v3
	ldr	q3, [x11, #688]
	str	q4, [sp, #1712]                 ; 16-byte Spill
	bit.16b	v3, v4, v0
	ldr	q4, [x11, #672]
	str	q5, [sp, #1728]                 ; 16-byte Spill
	bit.16b	v4, v5, v22
	stp	q4, q3, [x11, #672]
	ldp	q3, q4, [sp, #368]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v4, v1
	ldr	q4, [sp, #1088]                 ; 16-byte Reload
	and.16b	v5, v26, v4
	ldr	q4, [sp, #1104]                 ; 16-byte Reload
	and.16b	v7, v18, v4
	ldr	q4, [x11, #720]
	str	q7, [sp, #1680]                 ; 16-byte Spill
	bit.16b	v4, v7, v0
	ldr	q7, [x11, #704]
	str	q5, [sp, #1696]                 ; 16-byte Spill
	bit.16b	v7, v5, v22
	stp	q7, q4, [x11, #704]
	ldp	q4, q5, [sp, #768]              ; 32-byte Folded Reload
	fcmeq.4s	v4, v4, v4
	bsl.16b	v4, v5, v1
	ldr	q5, [sp, #1216]                 ; 16-byte Reload
	and.16b	v5, v26, v5
	ldr	q7, [sp, #1232]                 ; 16-byte Reload
	and.16b	v19, v18, v7
	ldp	q7, q21, [x11, #752]
	str	q19, [sp, #1216]                ; 16-byte Spill
	bit.16b	v7, v19, v0
	ldr	q19, [x11, #736]
	str	q5, [sp, #1232]                 ; 16-byte Spill
	bit.16b	v19, v5, v22
	stp	q19, q7, [x11, #736]
	ldr	q5, [sp, #336]                  ; 16-byte Reload
	fcmeq.4s	v7, v5, v5
	ldr	q5, [sp, #352]                  ; 16-byte Reload
	bsl.16b	v7, v5, v1
	ldr	q5, [sp, #1136]                 ; 16-byte Reload
	and.16b	v5, v26, v5
	ldr	q19, [sp, #1184]                ; 16-byte Reload
	and.16b	v20, v18, v19
	ldr	q19, [x11, #784]
	str	q20, [sp, #1184]                ; 16-byte Spill
	bit.16b	v19, v20, v0
	str	q5, [sp, #1200]                 ; 16-byte Spill
	bit.16b	v21, v5, v22
	stp	q21, q19, [x11, #768]
	ldr	q5, [sp, #864]                  ; 16-byte Reload
	fcmeq.4s	v19, v5, v5
	ldr	q5, [sp, #880]                  ; 16-byte Reload
	bsl.16b	v19, v5, v1
	ldr	q5, [sp, #1152]                 ; 16-byte Reload
	and.16b	v5, v18, v5
	ldr	q20, [sp, #1168]                ; 16-byte Reload
	and.16b	v20, v26, v20
	ldp	q21, q25, [x11, #800]
	str	q20, [sp, #1152]                ; 16-byte Spill
	bit.16b	v21, v20, v22
	str	q5, [sp, #1168]                 ; 16-byte Spill
	bit.16b	v25, v5, v0
	stp	q21, q25, [x11, #800]
	ldr	q5, [sp, #304]                  ; 16-byte Reload
	fcmeq.4s	v21, v5, v5
	ldr	q5, [sp, #320]                  ; 16-byte Reload
	bsl.16b	v21, v5, v1
	and.16b	v20, v18, v28
	ldr	q5, [sp, #1120]                 ; 16-byte Reload
	and.16b	v5, v26, v5
	ldp	q25, q27, [x11, #832]
	str	q5, [sp, #1136]                 ; 16-byte Spill
	bit.16b	v25, v5, v22
	str	q20, [sp, #1120]                ; 16-byte Spill
	bit.16b	v27, v20, v0
	stp	q25, q27, [x11, #832]
	ldr	q5, [sp, #960]                  ; 16-byte Reload
	fcmeq.4s	v25, v5, v5
	ldr	q5, [sp, #976]                  ; 16-byte Reload
	bsl.16b	v25, v5, v1
	and.16b	v5, v18, v2
	and.16b	v20, v26, v13
	ldp	q2, q27, [x11, #864]
	str	q20, [sp, #1088]                ; 16-byte Spill
	bit.16b	v2, v20, v22
	str	q5, [sp, #1104]                 ; 16-byte Spill
	bit.16b	v27, v5, v0
	stp	q2, q27, [x11, #864]
	ldp	q2, q5, [sp, #272]              ; 32-byte Folded Reload
	fcmeq.4s	v2, v2, v2
	bsl.16b	v2, v5, v1
	and.16b	v5, v18, v4
	and.16b	v4, v26, v3
	ldr	q3, [x11, #896]
	str	q4, [sp, #1072]                 ; 16-byte Spill
	bit.16b	v3, v4, v22
	ldr	q4, [x11, #912]
	str	q5, [sp, #1040]                 ; 16-byte Spill
	bit.16b	v4, v5, v0
	stp	q3, q4, [x11, #896]
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	fcmeq.4s	v3, v3, v3
	ldr	q4, [sp, #1056]                 ; 16-byte Reload
	bsl.16b	v3, v4, v1
	and.16b	v5, v26, v19
	and.16b	v7, v18, v7
	ldr	q4, [x11, #944]
	str	q7, [sp, #1056]                 ; 16-byte Spill
	bit.16b	v4, v7, v0
	ldr	q7, [x11, #928]
	str	q5, [sp, #1664]                 ; 16-byte Spill
	bit.16b	v7, v5, v22
	stp	q7, q4, [x11, #928]
	and.16b	v5, v18, v25
	and.16b	v4, v18, v3
	and.16b	v3, v26, v21
	and.16b	v7, v26, v2
	ldr	q2, [x11, #960]
	stp	q3, q5, [sp, #992]              ; 32-byte Folded Spill
	bit.16b	v2, v3, v22
	ldr	q3, [x11, #976]
	bit.16b	v3, v5, v0
	stp	q2, q3, [x11, #960]
	ldp	q2, q3, [x11, #992]
	str	q7, [sp, #976]                  ; 16-byte Spill
	bit.16b	v2, v7, v22
	str	q4, [sp, #1024]                 ; 16-byte Spill
	bit.16b	v3, v4, v0
	stp	q2, q3, [x11, #992]
	fcmeq.4s	v2, v15, v15
	ldp	q4, q3, [sp, #240]              ; 32-byte Folded Reload
	mov.16b	v7, v2
	bsl.16b	v7, v4, v1
	fcmeq.4s	v2, v14, v14
	mov.16b	v25, v2
	bsl.16b	v25, v3, v1
	sshll.2d	v2, v22, #0
	ldr	q26, [sp, #2240]                ; 16-byte Reload
	ldr	q1, [sp, #1648]                 ; 16-byte Reload
	bit.16b	v26, v1, v2
	add	x3, x10, x7
	ldr	q20, [sp, #1408]                ; 16-byte Reload
	str	q26, [sp, #2240]                ; 16-byte Spill
LBB1_83:                                ; %direct.true600.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_84 Depth 4
	mov	x4, #0                          ; =0x0
	lsl	x5, x2, #7
	dup.2d	v26, x5
	orr.16b	v2, v26, v20
	fmov	x5, d2
	add	x5, x8, x5
	ldp	q3, q2, [x5]
	fmul.4s	v3, v7, v3
	fmul.4s	v2, v25, v2
	mov	w5, #32                         ; =0x20
	bfi	x5, x2, #7, #57
	dup.2d	v27, x5
	orr.16b	v4, v27, v20
	fmov	x5, d4
	add	x5, x8, x5
	ldp	q18, q4, [x5]
	fmul.4s	v19, v7, v18
	fmul.4s	v4, v25, v4
	mov	w5, #64                         ; =0x40
	bfi	x5, x2, #7, #57
	dup.2d	v28, x5
	orr.16b	v18, v28, v20
	fmov	x5, d18
	add	x5, x8, x5
	ldp	q21, q18, [x5]
	fmul.4s	v21, v7, v21
	fmul.4s	v13, v25, v18
	mov	w5, #96                         ; =0x60
	bfi	x5, x2, #7, #57
	dup.2d	v18, x5
	mov.16b	v5, v20
	orr.16b	v14, v18, v20
	fmov	x5, d14
	add	x5, x8, x5
	ldp	q15, q14, [x5]
	fmul.4s	v15, v7, v15
	fmul.4s	v14, v25, v14
	bit.16b	v12, v2, v0
	bit.16b	v11, v3, v22
	bit.16b	v10, v4, v0
	bit.16b	v9, v19, v22
	bit.16b	v8, v13, v0
	bit.16b	v31, v21, v22
	bit.16b	v30, v14, v0
	bit.16b	v29, v15, v22
	mov	x5, x3
LBB1_84:                                ; %direct.true628.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ;       Parent Loop BB1_83 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	add	x6, x15, x4
	ldp	q3, q2, [x6]
	and.16b	v19, v22, v3
	and.16b	v2, v0, v2
	ldp	q4, q3, [x5, #-96]
	and.16b	v4, v22, v4
	and.16b	v3, v0, v3
	fmul.4s	v21, v2, v3
	fmul.4s	v3, v19, v4
	fadd.4s	v3, v11, v3
	fadd.4s	v15, v12, v21
	ldp	q21, q4, [x5, #-64]
	and.16b	v21, v22, v21
	and.16b	v4, v0, v4
	fmul.4s	v4, v2, v4
	fmul.4s	v21, v19, v21
	fadd.4s	v21, v9, v21
	fadd.4s	v14, v10, v4
	ldp	q13, q4, [x5, #-32]
	and.16b	v13, v22, v13
	and.16b	v4, v0, v4
	fmul.4s	v4, v2, v4
	fmul.4s	v13, v19, v13
	fadd.4s	v13, v31, v13
	fadd.4s	v4, v8, v4
	ldp	q20, q1, [x5]
	and.16b	v20, v22, v20
	and.16b	v1, v0, v1
	fmul.4s	v1, v2, v1
	fmul.4s	v2, v19, v20
	fadd.4s	v19, v29, v2
	fadd.4s	v2, v30, v1
	bit.16b	v12, v15, v0
	bit.16b	v11, v3, v22
	bit.16b	v10, v14, v0
	bit.16b	v9, v21, v22
	bit.16b	v8, v4, v0
	bit.16b	v31, v13, v22
	bit.16b	v30, v2, v0
	bit.16b	v29, v19, v22
	add	x4, x4, #32
	add	x5, x5, #1, lsl #12             ; =4096
	cmp	x4, #512
	b.ne	LBB1_84
; %bb.85:                               ; %direct.false629.i.i
                                        ;   in Loop: Header=BB1_83 Depth=3
	ldr	q20, [sp, #2240]                ; 16-byte Reload
	orr.16b	v1, v26, v20
	mov.16b	v26, v20
	fmov	x4, d1
	add	x4, x16, x4
	ldp	q1, q20, [x4]
	bit.16b	v20, v15, v0
	bit.16b	v1, v3, v22
	stp	q1, q20, [x4]
	orr.16b	v1, v27, v26
	fmov	x4, d1
	add	x4, x16, x4
	ldp	q1, q3, [x4]
	bit.16b	v3, v14, v0
	bit.16b	v1, v21, v22
	stp	q1, q3, [x4]
	orr.16b	v1, v28, v26
	fmov	x4, d1
	add	x4, x16, x4
	ldp	q1, q3, [x4]
	bit.16b	v3, v4, v0
	bit.16b	v1, v13, v22
	stp	q1, q3, [x4]
	orr.16b	v1, v18, v26
	fmov	x4, d1
	add	x4, x16, x4
	ldp	q1, q3, [x4]
	bif.16b	v2, v3, v0
	bit.16b	v1, v19, v22
	stp	q1, q2, [x4]
	add	x2, x2, #1
	add	x3, x3, #128
	cmp	x2, #32
	mov.16b	v20, v5
	b.ne	LBB1_83
; %bb.86:                               ; %direct.true695.i.i.preheader
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x2, #0                          ; =0x0
LBB1_87:                                ; %direct.true695.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d1, x2
	orr.16b	v2, v1, v26
	fmov	x3, d2
	add	x3, x16, x3
	ldp	q2, q3, [x3]
	orr.16b	v1, v1, v20
	fmov	x3, d1
	add	x3, x12, x3
	ldp	q1, q4, [x3]
	bif.16b	v3, v4, v0
	bit.16b	v1, v2, v22
	stp	q1, q3, [x3]
	add	x2, x2, #32
	cmp	x2, #1, lsl #12                 ; =4096
	b.ne	LBB1_87
; %bb.88:                               ; %direct.true711.i.i.preheader
                                        ;   in Loop: Header=BB1_34 Depth=2
	add	x2, x10, #1, lsl #12            ; =4096
	mov	w3, #128                        ; =0x80
	ldr	q21, [sp, #1392]                ; 16-byte Reload
	ldr	q26, [sp, #1376]                ; 16-byte Reload
	ldr	q20, [sp, #2016]                ; 16-byte Reload
	ldr	q13, [sp, #1360]                ; 16-byte Reload
	ldr	q28, [sp, #1344]                ; 16-byte Reload
	ldr	q15, [sp, #1328]                ; 16-byte Reload
	ldr	q18, [sp, #2032]                ; 16-byte Reload
	ldr	q27, [sp, #1776]                ; 16-byte Reload
	ldr	q5, [sp, #1760]                 ; 16-byte Reload
	ldr	q14, [sp, #1248]                ; 16-byte Reload
	ldr	q19, [sp, #2416]                ; 16-byte Reload
LBB1_89:                                ; %direct.true711.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q1, [x2, #4096]
	ldr	q2, [x2, #4112]
	ldp	q3, q4, [x2]
	bif.16b	v2, v4, v0
	bif.16b	v1, v3, v22
	stp	q1, q2, [x2], #32
	subs	x3, x3, #1
	b.ne	LBB1_89
; %bb.90:                               ; %direct.false712.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	ldr	q1, [sp, #2064]                 ; 16-byte Reload
	bit.16b	v20, v1, v0
	str	q20, [sp, #2016]                ; 16-byte Spill
	ldr	q1, [sp, #2000]                 ; 16-byte Reload
	ldr	q2, [sp, #2128]                 ; 16-byte Reload
	bit.16b	v1, v2, v22
	str	q1, [sp, #2000]                 ; 16-byte Spill
	movi.2d	v2, #0000000000000000
	ldr	q1, [sp, #2208]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q3, [sp, #2176]                 ; 16-byte Reload
	fadd.4s	v1, v1, v3
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #2160]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #2112]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #2144]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #2096]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1728]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1680]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1696]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1232]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1216]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1184]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1200]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1152]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1168]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1120]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1136]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1088]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1104]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1040]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1072]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1056]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldp	q3, q4, [sp, #992]              ; 32-byte Folded Reload
	fadd.4s	v2, v4, v2
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #976]                  ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1024]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	fmul.4s	v3, v26, v7
	fmul.4s	v4, v21, v25
	fadd.4s	v2, v4, v2
	fadd.4s	v1, v3, v1
	bit.16b	v26, v1, v22
	bit.16b	v21, v2, v0
	add	x1, x1, #1
	cmp	x1, #513
	ldr	q25, [sp, #192]                 ; 16-byte Reload
	ldr	q20, [sp, #1648]                ; 16-byte Reload
	b.ne	LBB1_34
; %bb.91:                               ; %direct.true730.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	ldr	q17, [sp, #112]                 ; 16-byte Reload
	ldp	q7, q6, [sp, #48]               ; 32-byte Folded Reload
	ldp	q18, q16, [sp, #16]             ; 32-byte Folded Reload
	b	LBB1_93
LBB1_92:                                ; %else370
                                        ;   in Loop: Header=BB1_93 Depth=2
	add	x10, x10, #4
	add	x8, x8, #32
	cmp	x10, #512
	b.eq	LBB1_2
LBB1_93:                                ; %direct.true730.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	uzp1.8h	v1, v22, v0
	and.16b	v1, v1, v17
	addv.8h	h1, v1
	fmov	w11, s1
	ldp	q1, q3, [x8]
	and.16b	v1, v22, v1
	fdiv.4s	v4, v1, v26
	dup.2d	v1, x10
	add.2d	v5, v1, v18
	dup.2d	v2, x9
	add.2d	v5, v2, v5
	tbnz	w11, #0, LBB1_101
; %bb.94:                               ; %else349
                                        ;   in Loop: Header=BB1_93 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_102
LBB1_95:                                ; %else352
                                        ;   in Loop: Header=BB1_93 Depth=2
	add.2d	v5, v1, v7
	add.2d	v5, v2, v5
	tbnz	w11, #2, LBB1_103
LBB1_96:                                ; %else355
                                        ;   in Loop: Header=BB1_93 Depth=2
	tbnz	w11, #3, LBB1_104
LBB1_97:                                ; %else358
                                        ;   in Loop: Header=BB1_93 Depth=2
	and.16b	v3, v0, v3
	fdiv.4s	v3, v3, v21
	add.2d	v4, v1, v16
	add.2d	v4, v2, v4
	tbnz	w11, #4, LBB1_105
LBB1_98:                                ; %else361
                                        ;   in Loop: Header=BB1_93 Depth=2
	tbnz	w11, #5, LBB1_106
LBB1_99:                                ; %else364
                                        ;   in Loop: Header=BB1_93 Depth=2
	add.2d	v1, v1, v6
	add.2d	v1, v2, v1
	tbnz	w11, #6, LBB1_107
LBB1_100:                               ; %else367
                                        ;   in Loop: Header=BB1_93 Depth=2
	tbz	w11, #7, LBB1_92
	b	LBB1_108
LBB1_101:                               ; %cond.store
                                        ;   in Loop: Header=BB1_93 Depth=2
	fmov	x12, d5
	str	s4, [x12]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_95
LBB1_102:                               ; %cond.store350
                                        ;   in Loop: Header=BB1_93 Depth=2
	mov.d	x12, v5[1]
	st1.s	{ v4 }[1], [x12]
	add.2d	v5, v1, v7
	add.2d	v5, v2, v5
	tbz	w11, #2, LBB1_96
LBB1_103:                               ; %cond.store353
                                        ;   in Loop: Header=BB1_93 Depth=2
	fmov	x12, d5
	st1.s	{ v4 }[2], [x12]
	tbz	w11, #3, LBB1_97
LBB1_104:                               ; %cond.store356
                                        ;   in Loop: Header=BB1_93 Depth=2
	mov.d	x12, v5[1]
	st1.s	{ v4 }[3], [x12]
	and.16b	v3, v0, v3
	fdiv.4s	v3, v3, v21
	add.2d	v4, v1, v16
	add.2d	v4, v2, v4
	tbz	w11, #4, LBB1_98
LBB1_105:                               ; %cond.store359
                                        ;   in Loop: Header=BB1_93 Depth=2
	fmov	x12, d4
	str	s3, [x12]
	tbz	w11, #5, LBB1_99
LBB1_106:                               ; %cond.store362
                                        ;   in Loop: Header=BB1_93 Depth=2
	mov.d	x12, v4[1]
	st1.s	{ v3 }[1], [x12]
	add.2d	v1, v1, v6
	add.2d	v1, v2, v1
	tbz	w11, #6, LBB1_100
LBB1_107:                               ; %cond.store365
                                        ;   in Loop: Header=BB1_93 Depth=2
	fmov	x12, d1
	st1.s	{ v3 }[2], [x12]
	tbz	w11, #7, LBB1_92
LBB1_108:                               ; %cond.store368
                                        ;   in Loop: Header=BB1_93 Depth=2
	mov.d	x11, v1[1]
	st1.s	{ v3 }[3], [x11]
	b	LBB1_92
LBB1_109:                               ; %block.batch.exit
	add	sp, sp, #2512
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh10, Lloh11
                                        ; -- End function
.subsections_via_symbols

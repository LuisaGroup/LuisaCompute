; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [4096 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [4096 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill5, align 1
  %.spill6 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill6, align 4
  %.spill7 = alloca i64, align 8
  store i64 0, ptr %.spill7, align 4
  %.slot8 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot8, align 64
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.spill13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill13, align 32
  %.spill14 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill14, align 32
  %.slot15 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot15, align 32
  %.spill16 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill16, align 4
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot18, align 64
  %.spill19 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill19, align 4
  %.slot20 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot20, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat22, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat24, %41
  %44 = mul i32 %32, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat26, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert27 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat28, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert29 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat30 = shufflevector <8 x i32> %.splatinsert29, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat30
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 127
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state31 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state31, 8
  %.splatinsert32 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat33 = shufflevector <8 x i64> %.splatinsert32, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat33, %.spill.load
  %.spill.load34 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load34, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 1023)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state35 = load i64, ptr %.slot, align 4
  %.splatinsert36 = insertelement <8 x i64> poison, i64 %.state35, i64 0
  %.splat37 = shufflevector <8 x i64> %.splatinsert36, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat37, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state38 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state38, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load39 = load <8 x i64>, ptr %.spill, align 64
  %102 = icmp slt <8 x i64> %.spill.load39, splat (i64 7)
  %103 = load <8 x i1>, ptr %.spill5, align 1
  %104 = select <8 x i1> %51, <8 x i1> %102, <8 x i1> %103
  store <8 x i1> %104, ptr %.spill5, align 1
  %105 = and <8 x i1> %51, %102
  %106 = xor <8 x i1> %102, splat (i1 true)
  %107 = and <8 x i1> %51, %106
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %109 = bitcast <8 x i1> %105 to i8
  %110 = call i8 @llvm.cttz.i8(i8 %109, i1 false)
  %111 = zext i8 %110 to i32
  %112 = select i1 %108, i32 %111, i32 0
  %.spill.load40 = load <8 x i64>, ptr %.spill, align 64
  %113 = add <8 x i64> splat (i64 1016), %.spill.load40
  %.spill.load41 = load <8 x i64>, ptr %.spill4, align 64
  %114 = add <8 x i64> %.spill.load41, zeroinitializer
  %115 = add <8 x i64> zeroinitializer, %114
  %116 = add <8 x i64> zeroinitializer, %113
  %117 = mul <8 x i64> %115, splat (i64 1023)
  %118 = add <8 x i64> %117, %116
  %119 = extractvalue { ptr, i64 } %9, 0
  %120 = select <8 x i1> %105, <8 x i64> %118, <8 x i64> zeroinitializer
  %121 = extractelement <8 x i64> %120, i32 %112
  %122 = zext i32 %112 to i64
  %123 = sub i64 %121, %122
  %124 = mul i64 %123, 4
  %buffer.contiguous.address42 = getelementptr i8, ptr %119, i64 %124
  %buffer.contiguous.load43 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address42, i32 1, <8 x i1> %105, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load44 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 1
  %127 = add <8 x i64> %126, splat (i64 4064)
  %128 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %125, 0
  %129 = insertvalue { <8 x ptr>, <8 x i64> } %128, <8 x i64> %127, 1
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %129, 1
  %132 = extractelement <8 x ptr> %130, i32 0
  %133 = extractelement <8 x i64> %131, i32 %112
  %134 = zext i32 %112 to i64
  %135 = mul i64 %134, 4
  %136 = sub i64 %133, %135
  %137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %138 = select i1 %137, i64 %136, i64 0
  %private.contiguous.address45 = getelementptr i8, ptr %132, i64 %138
  %private.contiguous.preserve46 = load <8 x float>, ptr %private.contiguous.address45, align 4
  %139 = select <8 x i1> %105, <8 x float> %buffer.contiguous.load43, <8 x float> %private.contiguous.preserve46
  store <8 x float> %139, ptr %private.contiguous.address45, align 4
  %140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %107)
  %141 = bitcast <8 x i1> %107 to i8
  %142 = call i8 @llvm.cttz.i8(i8 %141, i1 false)
  %143 = zext i8 %142 to i32
  %144 = select i1 %140, i32 %143, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  store float 0.000000e+00, ptr %.spill6, align 4
  store i64 0, ptr %.spill7, align 4
  %tile_snapshot.spill.load47 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 0
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 1
  %147 = add <8 x i64> %146, zeroinitializer
  %148 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %145, 0
  %149 = insertvalue { <8 x ptr>, <8 x i64> } %148, <8 x i64> %147, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %149, 1
  %152 = extractelement <8 x ptr> %150, i32 0
  %153 = extractelement <8 x i64> %151, i32 0
  %154 = sub i64 %153, 0
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %156 = select i1 %155, i64 %154, i64 0
  %private.contiguous.address48 = getelementptr i8, ptr %152, i64 %156
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address48, align 4
  %157 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %158 = fmul <8 x float> %157, %157
  %tile_snapshot.spill.load49 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load49, 0
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load49, 1
  %161 = add <8 x i64> %160, splat (i64 32)
  %162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %159, 0
  %163 = insertvalue { <8 x ptr>, <8 x i64> } %162, <8 x i64> %161, 1
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %163, 1
  %166 = extractelement <8 x ptr> %164, i32 0
  %167 = extractelement <8 x i64> %165, i32 0
  %168 = sub i64 %167, 0
  %169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %170 = select i1 %169, i64 %168, i64 0
  %private.contiguous.address50 = getelementptr i8, ptr %166, i64 %170
  %private.contiguous.load51 = load <8 x float>, ptr %private.contiguous.address50, align 4
  %171 = select <8 x i1> %51, <8 x float> %private.contiguous.load51, <8 x float> zeroinitializer
  %172 = fmul <8 x float> %171, %171
  %tile_snapshot.spill.load52 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 0
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 1
  %175 = add <8 x i64> %174, splat (i64 64)
  %176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %173, 0
  %177 = insertvalue { <8 x ptr>, <8 x i64> } %176, <8 x i64> %175, 1
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %177, 1
  %180 = extractelement <8 x ptr> %178, i32 0
  %181 = extractelement <8 x i64> %179, i32 0
  %182 = sub i64 %181, 0
  %183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %184 = select i1 %183, i64 %182, i64 0
  %private.contiguous.address53 = getelementptr i8, ptr %180, i64 %184
  %private.contiguous.load54 = load <8 x float>, ptr %private.contiguous.address53, align 4
  %185 = select <8 x i1> %51, <8 x float> %private.contiguous.load54, <8 x float> zeroinitializer
  %186 = fmul <8 x float> %185, %185
  %tile_snapshot.spill.load55 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load55, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load55, 1
  %189 = add <8 x i64> %188, splat (i64 96)
  %190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %187, 0
  %191 = insertvalue { <8 x ptr>, <8 x i64> } %190, <8 x i64> %189, 1
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %191, 1
  %194 = extractelement <8 x ptr> %192, i32 0
  %195 = extractelement <8 x i64> %193, i32 0
  %196 = sub i64 %195, 0
  %197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %198 = select i1 %197, i64 %196, i64 0
  %private.contiguous.address56 = getelementptr i8, ptr %194, i64 %198
  %private.contiguous.load57 = load <8 x float>, ptr %private.contiguous.address56, align 4
  %199 = select <8 x i1> %51, <8 x float> %private.contiguous.load57, <8 x float> zeroinitializer
  %200 = fmul <8 x float> %199, %199
  %201 = load <8 x i64>, ptr %.slot8, align 64
  %202 = select <8 x i1> %51, <8 x i64> splat (i64 4), <8 x i64> %201
  store <8 x i64> %202, ptr %.slot8, align 64
  %203 = load <8 x float>, ptr %.slot9, align 32
  %204 = select <8 x i1> %51, <8 x float> %158, <8 x float> %203
  store <8 x float> %204, ptr %.slot9, align 32
  %205 = load <8 x float>, ptr %.slot10, align 32
  %206 = select <8 x i1> %51, <8 x float> %172, <8 x float> %205
  store <8 x float> %206, ptr %.slot10, align 32
  %207 = load <8 x float>, ptr %.slot11, align 32
  %208 = select <8 x i1> %51, <8 x float> %186, <8 x float> %207
  store <8 x float> %208, ptr %.slot11, align 32
  %209 = load <8 x float>, ptr %.slot12, align 32
  %210 = select <8 x i1> %51, <8 x float> %200, <8 x float> %209
  store <8 x float> %210, ptr %.slot12, align 32
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state58 = load <8 x i64>, ptr %.slot8, align 64
  %211 = icmp slt <8 x i64> %.state58, splat (i64 124)
  %212 = extractelement <8 x i1> %211, i32 0
  br i1 %212, label %direct.true59, label %direct.false60

direct.schedule.7:                                ; preds = %direct.true59
  %.state61 = load <8 x i64>, ptr %.slot8, align 64
  %213 = add <8 x i64> %.state61, zeroinitializer
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %216 = mul <8 x i64> %213, splat (i64 32)
  %217 = add <8 x i64> %215, %216
  %218 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %214, 0
  %219 = insertvalue { <8 x ptr>, <8 x i64> } %218, <8 x i64> %217, 1
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %219, 1
  %222 = extractelement <8 x ptr> %220, i32 0
  %223 = extractelement <8 x i64> %221, i32 0
  %224 = sub i64 %223, 0
  %225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %226 = select i1 %225, i64 %224, i64 0
  %private.contiguous.address63 = getelementptr i8, ptr %222, i64 %226
  %private.contiguous.load64 = load <8 x float>, ptr %private.contiguous.address63, align 4
  %227 = select <8 x i1> %51, <8 x float> %private.contiguous.load64, <8 x float> zeroinitializer
  %228 = fmul <8 x float> %227, %227
  %.state65 = load <8 x float>, ptr %.slot9, align 32
  %229 = fadd <8 x float> %.state65, %228
  %.state66 = load <8 x i64>, ptr %.slot8, align 64
  %230 = add <8 x i64> %.state66, splat (i64 1)
  %tile_snapshot.spill.load67 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 0
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 1
  %233 = mul <8 x i64> %230, splat (i64 32)
  %234 = add <8 x i64> %232, %233
  %235 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %231, 0
  %236 = insertvalue { <8 x ptr>, <8 x i64> } %235, <8 x i64> %234, 1
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %236, 1
  %239 = extractelement <8 x ptr> %237, i32 0
  %240 = extractelement <8 x i64> %238, i32 0
  %241 = sub i64 %240, 0
  %242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %243 = select i1 %242, i64 %241, i64 0
  %private.contiguous.address68 = getelementptr i8, ptr %239, i64 %243
  %private.contiguous.load69 = load <8 x float>, ptr %private.contiguous.address68, align 4
  %244 = select <8 x i1> %51, <8 x float> %private.contiguous.load69, <8 x float> zeroinitializer
  %245 = fmul <8 x float> %244, %244
  %.state70 = load <8 x float>, ptr %.slot10, align 32
  %246 = fadd <8 x float> %.state70, %245
  %.state71 = load <8 x i64>, ptr %.slot8, align 64
  %247 = add <8 x i64> %.state71, splat (i64 2)
  %tile_snapshot.spill.load72 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load72, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load72, 1
  %250 = mul <8 x i64> %247, splat (i64 32)
  %251 = add <8 x i64> %249, %250
  %252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %253 = insertvalue { <8 x ptr>, <8 x i64> } %252, <8 x i64> %251, 1
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %253, 1
  %256 = extractelement <8 x ptr> %254, i32 0
  %257 = extractelement <8 x i64> %255, i32 0
  %258 = sub i64 %257, 0
  %259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %260 = select i1 %259, i64 %258, i64 0
  %private.contiguous.address73 = getelementptr i8, ptr %256, i64 %260
  %private.contiguous.load74 = load <8 x float>, ptr %private.contiguous.address73, align 4
  %261 = select <8 x i1> %51, <8 x float> %private.contiguous.load74, <8 x float> zeroinitializer
  %262 = fmul <8 x float> %261, %261
  %.state75 = load <8 x float>, ptr %.slot11, align 32
  %263 = fadd <8 x float> %.state75, %262
  %.state76 = load <8 x i64>, ptr %.slot8, align 64
  %264 = add <8 x i64> %.state76, splat (i64 3)
  %tile_snapshot.spill.load77 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load77, 0
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load77, 1
  %267 = mul <8 x i64> %264, splat (i64 32)
  %268 = add <8 x i64> %266, %267
  %269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %265, 0
  %270 = insertvalue { <8 x ptr>, <8 x i64> } %269, <8 x i64> %268, 1
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %270, 1
  %273 = extractelement <8 x ptr> %271, i32 0
  %274 = extractelement <8 x i64> %272, i32 0
  %275 = sub i64 %274, 0
  %276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %277 = select i1 %276, i64 %275, i64 0
  %private.contiguous.address78 = getelementptr i8, ptr %273, i64 %277
  %private.contiguous.load79 = load <8 x float>, ptr %private.contiguous.address78, align 4
  %278 = select <8 x i1> %51, <8 x float> %private.contiguous.load79, <8 x float> zeroinitializer
  %279 = fmul <8 x float> %278, %278
  %.state80 = load <8 x float>, ptr %.slot12, align 32
  %280 = fadd <8 x float> %.state80, %279
  %.state81 = load <8 x i64>, ptr %.slot8, align 64
  %281 = add <8 x i64> %.state81, splat (i64 4)
  %282 = load <8 x i64>, ptr %.slot8, align 64
  %283 = select <8 x i1> %51, <8 x i64> %281, <8 x i64> %282
  store <8 x i64> %283, ptr %.slot8, align 64
  %284 = load <8 x float>, ptr %.slot9, align 32
  %285 = select <8 x i1> %51, <8 x float> %229, <8 x float> %284
  store <8 x float> %285, ptr %.slot9, align 32
  %286 = load <8 x float>, ptr %.slot10, align 32
  %287 = select <8 x i1> %51, <8 x float> %246, <8 x float> %286
  store <8 x float> %287, ptr %.slot10, align 32
  %288 = load <8 x float>, ptr %.slot11, align 32
  %289 = select <8 x i1> %51, <8 x float> %263, <8 x float> %288
  store <8 x float> %289, ptr %.slot11, align 32
  %290 = load <8 x float>, ptr %.slot12, align 32
  %291 = select <8 x i1> %51, <8 x float> %280, <8 x float> %290
  store <8 x float> %291, ptr %.slot12, align 32
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false60
  %tile_snapshot.spill.load82 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 0
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 1
  %294 = add <8 x i64> %293, splat (i64 3968)
  %295 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %292, 0
  %296 = insertvalue { <8 x ptr>, <8 x i64> } %295, <8 x i64> %294, 1
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %298 = extractvalue { <8 x ptr>, <8 x i64> } %296, 1
  %299 = extractelement <8 x ptr> %297, i32 0
  %300 = extractelement <8 x i64> %298, i32 0
  %301 = sub i64 %300, 0
  %302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %303 = select i1 %302, i64 %301, i64 0
  %private.contiguous.address83 = getelementptr i8, ptr %299, i64 %303
  %private.contiguous.load84 = load <8 x float>, ptr %private.contiguous.address83, align 4
  %304 = select <8 x i1> %51, <8 x float> %private.contiguous.load84, <8 x float> zeroinitializer
  %305 = fmul <8 x float> %304, %304
  %.state85 = load <8 x float>, ptr %.slot9, align 32
  %306 = fadd <8 x float> %.state85, %305
  %tile_snapshot.spill.load86 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %307 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 0
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 1
  %309 = add <8 x i64> %308, splat (i64 4000)
  %310 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %307, 0
  %311 = insertvalue { <8 x ptr>, <8 x i64> } %310, <8 x i64> %309, 1
  %312 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %311, 1
  %314 = extractelement <8 x ptr> %312, i32 0
  %315 = extractelement <8 x i64> %313, i32 0
  %316 = sub i64 %315, 0
  %317 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %318 = select i1 %317, i64 %316, i64 0
  %private.contiguous.address87 = getelementptr i8, ptr %314, i64 %318
  %private.contiguous.load88 = load <8 x float>, ptr %private.contiguous.address87, align 4
  %319 = select <8 x i1> %51, <8 x float> %private.contiguous.load88, <8 x float> zeroinitializer
  %320 = fmul <8 x float> %319, %319
  %.state89 = load <8 x float>, ptr %.slot10, align 32
  %321 = fadd <8 x float> %.state89, %320
  %322 = load <8 x float>, ptr %.spill13, align 32
  %323 = select <8 x i1> %51, <8 x float> %321, <8 x float> %322
  store <8 x float> %323, ptr %.spill13, align 32
  %tile_snapshot.spill.load90 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load90, 0
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load90, 1
  %326 = add <8 x i64> %325, splat (i64 4032)
  %327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %324, 0
  %328 = insertvalue { <8 x ptr>, <8 x i64> } %327, <8 x i64> %326, 1
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %328, 1
  %331 = extractelement <8 x ptr> %329, i32 0
  %332 = extractelement <8 x i64> %330, i32 0
  %333 = sub i64 %332, 0
  %334 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %335 = select i1 %334, i64 %333, i64 0
  %private.contiguous.address91 = getelementptr i8, ptr %331, i64 %335
  %private.contiguous.load92 = load <8 x float>, ptr %private.contiguous.address91, align 4
  %336 = select <8 x i1> %51, <8 x float> %private.contiguous.load92, <8 x float> zeroinitializer
  %337 = fmul <8 x float> %336, %336
  %.state93 = load <8 x float>, ptr %.slot11, align 32
  %338 = fadd <8 x float> %.state93, %337
  %339 = load <8 x float>, ptr %.spill14, align 32
  %340 = select <8 x i1> %51, <8 x float> %338, <8 x float> %339
  store <8 x float> %340, ptr %.spill14, align 32
  %.spill.load94 = load <8 x i1>, ptr %.spill5, align 1
  %341 = and <8 x i1> %51, %.spill.load94
  %342 = xor <8 x i1> %.spill.load94, splat (i1 true)
  %343 = and <8 x i1> %51, %342
  %344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %341)
  %345 = bitcast <8 x i1> %341 to i8
  %346 = call i8 @llvm.cttz.i8(i8 %345, i1 false)
  %347 = zext i8 %346 to i32
  %348 = select i1 %344, i32 %347, i32 0
  %tile_snapshot.spill.load95 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 0
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 1
  %351 = add <8 x i64> %350, splat (i64 4064)
  %352 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %349, 0
  %353 = insertvalue { <8 x ptr>, <8 x i64> } %352, <8 x i64> %351, 1
  %354 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %355 = extractvalue { <8 x ptr>, <8 x i64> } %353, 1
  %356 = extractelement <8 x ptr> %354, i32 0
  %357 = extractelement <8 x i64> %355, i32 %348
  %358 = zext i32 %348 to i64
  %359 = mul i64 %358, 4
  %360 = sub i64 %357, %359
  %361 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %341)
  %362 = select i1 %361, i64 %360, i64 0
  %private.contiguous.address96 = getelementptr i8, ptr %356, i64 %362
  %private.contiguous.load97 = load <8 x float>, ptr %private.contiguous.address96, align 4
  %363 = select <8 x i1> %341, <8 x float> %private.contiguous.load97, <8 x float> zeroinitializer
  %364 = fmul <8 x float> %363, %363
  %365 = fadd <8 x float> %306, %364
  %366 = load <8 x float>, ptr %.slot15, align 32
  %367 = select <8 x i1> %341, <8 x float> %365, <8 x float> %366
  store <8 x float> %367, ptr %.slot15, align 32
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %343)
  %369 = bitcast <8 x i1> %343 to i8
  %370 = call i8 @llvm.cttz.i8(i8 %369, i1 false)
  %371 = zext i8 %370 to i32
  %372 = select i1 %368, i32 %371, i32 0
  %373 = load <8 x float>, ptr %.slot15, align 32
  %374 = select <8 x i1> %343, <8 x float> %306, <8 x float> %373
  store <8 x float> %374, ptr %.slot15, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %.state98 = load <8 x float>, ptr %.slot15, align 32
  %.spill.load99 = load <8 x float>, ptr %.spill13, align 32
  %375 = fadd <8 x float> %.state98, %.spill.load99
  %.spill.load100 = load <8 x float>, ptr %.spill14, align 32
  %376 = fadd <8 x float> %375, %.spill.load100
  %.state101 = load <8 x float>, ptr %.slot12, align 32
  %377 = fadd <8 x float> %376, %.state101
  %.spill.load102 = load <8 x i64>, ptr %.spill, align 64
  %378 = trunc <8 x i64> %.spill.load102 to <8 x i32>
  %379 = xor <8 x i32> %378, splat (i32 1)
  %380 = extractelement <8 x i32> %379, i64 0
  %381 = icmp ult i32 %380, 8
  %382 = select i1 %381, i32 %380, i32 0
  %383 = extractelement <8 x i1> %51, i32 %382
  %384 = extractelement <8 x i1> %51, i64 0
  %385 = and i1 %381, %383
  %386 = and i1 %384, %385
  %387 = extractelement <8 x float> %377, i32 %382
  %388 = select i1 %386, float %387, float 0.000000e+00
  %389 = insertelement <8 x float> poison, float %388, i64 0
  %390 = xor i1 %386, true
  %391 = and i1 %384, %390
  %392 = insertelement <8 x i1> poison, i1 %391, i64 0
  %393 = extractelement <8 x i32> %379, i64 1
  %394 = icmp ult i32 %393, 8
  %395 = select i1 %394, i32 %393, i32 0
  %396 = extractelement <8 x i1> %51, i32 %395
  %397 = extractelement <8 x i1> %51, i64 1
  %398 = and i1 %394, %396
  %399 = and i1 %397, %398
  %400 = extractelement <8 x float> %377, i32 %395
  %401 = select i1 %399, float %400, float 0.000000e+00
  %402 = insertelement <8 x float> %389, float %401, i64 1
  %403 = xor i1 %399, true
  %404 = and i1 %397, %403
  %405 = insertelement <8 x i1> %392, i1 %404, i64 1
  %406 = extractelement <8 x i32> %379, i64 2
  %407 = icmp ult i32 %406, 8
  %408 = select i1 %407, i32 %406, i32 0
  %409 = extractelement <8 x i1> %51, i32 %408
  %410 = extractelement <8 x i1> %51, i64 2
  %411 = and i1 %407, %409
  %412 = and i1 %410, %411
  %413 = extractelement <8 x float> %377, i32 %408
  %414 = select i1 %412, float %413, float 0.000000e+00
  %415 = insertelement <8 x float> %402, float %414, i64 2
  %416 = xor i1 %412, true
  %417 = and i1 %410, %416
  %418 = insertelement <8 x i1> %405, i1 %417, i64 2
  %419 = extractelement <8 x i32> %379, i64 3
  %420 = icmp ult i32 %419, 8
  %421 = select i1 %420, i32 %419, i32 0
  %422 = extractelement <8 x i1> %51, i32 %421
  %423 = extractelement <8 x i1> %51, i64 3
  %424 = and i1 %420, %422
  %425 = and i1 %423, %424
  %426 = extractelement <8 x float> %377, i32 %421
  %427 = select i1 %425, float %426, float 0.000000e+00
  %428 = insertelement <8 x float> %415, float %427, i64 3
  %429 = xor i1 %425, true
  %430 = and i1 %423, %429
  %431 = insertelement <8 x i1> %418, i1 %430, i64 3
  %432 = extractelement <8 x i32> %379, i64 4
  %433 = icmp ult i32 %432, 8
  %434 = select i1 %433, i32 %432, i32 0
  %435 = extractelement <8 x i1> %51, i32 %434
  %436 = extractelement <8 x i1> %51, i64 4
  %437 = and i1 %433, %435
  %438 = and i1 %436, %437
  %439 = extractelement <8 x float> %377, i32 %434
  %440 = select i1 %438, float %439, float 0.000000e+00
  %441 = insertelement <8 x float> %428, float %440, i64 4
  %442 = xor i1 %438, true
  %443 = and i1 %436, %442
  %444 = insertelement <8 x i1> %431, i1 %443, i64 4
  %445 = extractelement <8 x i32> %379, i64 5
  %446 = icmp ult i32 %445, 8
  %447 = select i1 %446, i32 %445, i32 0
  %448 = extractelement <8 x i1> %51, i32 %447
  %449 = extractelement <8 x i1> %51, i64 5
  %450 = and i1 %446, %448
  %451 = and i1 %449, %450
  %452 = extractelement <8 x float> %377, i32 %447
  %453 = select i1 %451, float %452, float 0.000000e+00
  %454 = insertelement <8 x float> %441, float %453, i64 5
  %455 = xor i1 %451, true
  %456 = and i1 %449, %455
  %457 = insertelement <8 x i1> %444, i1 %456, i64 5
  %458 = extractelement <8 x i32> %379, i64 6
  %459 = icmp ult i32 %458, 8
  %460 = select i1 %459, i32 %458, i32 0
  %461 = extractelement <8 x i1> %51, i32 %460
  %462 = extractelement <8 x i1> %51, i64 6
  %463 = and i1 %459, %461
  %464 = and i1 %462, %463
  %465 = extractelement <8 x float> %377, i32 %460
  %466 = select i1 %464, float %465, float 0.000000e+00
  %467 = insertelement <8 x float> %454, float %466, i64 6
  %468 = xor i1 %464, true
  %469 = and i1 %462, %468
  %470 = insertelement <8 x i1> %457, i1 %469, i64 6
  %471 = extractelement <8 x i32> %379, i64 7
  %472 = icmp ult i32 %471, 8
  %473 = select i1 %472, i32 %471, i32 0
  %474 = extractelement <8 x i1> %51, i32 %473
  %475 = extractelement <8 x i1> %51, i64 7
  %476 = and i1 %472, %474
  %477 = and i1 %475, %476
  %478 = extractelement <8 x float> %377, i32 %473
  %479 = select i1 %477, float %478, float 0.000000e+00
  %480 = insertelement <8 x float> %467, float %479, i64 7
  %481 = xor i1 %477, true
  %482 = and i1 %475, %481
  %483 = insertelement <8 x i1> %470, i1 %482, i64 7
  %484 = fadd <8 x float> %377, %480
  %485 = xor <8 x i32> %378, splat (i32 2)
  %486 = extractelement <8 x i32> %485, i64 0
  %487 = icmp ult i32 %486, 8
  %488 = select i1 %487, i32 %486, i32 0
  %489 = extractelement <8 x i1> %51, i32 %488
  %490 = extractelement <8 x i1> %51, i64 0
  %491 = and i1 %487, %489
  %492 = and i1 %490, %491
  %493 = extractelement <8 x float> %484, i32 %488
  %494 = select i1 %492, float %493, float 0.000000e+00
  %495 = insertelement <8 x float> poison, float %494, i64 0
  %496 = xor i1 %492, true
  %497 = and i1 %490, %496
  %498 = insertelement <8 x i1> poison, i1 %497, i64 0
  %499 = extractelement <8 x i32> %485, i64 1
  %500 = icmp ult i32 %499, 8
  %501 = select i1 %500, i32 %499, i32 0
  %502 = extractelement <8 x i1> %51, i32 %501
  %503 = extractelement <8 x i1> %51, i64 1
  %504 = and i1 %500, %502
  %505 = and i1 %503, %504
  %506 = extractelement <8 x float> %484, i32 %501
  %507 = select i1 %505, float %506, float 0.000000e+00
  %508 = insertelement <8 x float> %495, float %507, i64 1
  %509 = xor i1 %505, true
  %510 = and i1 %503, %509
  %511 = insertelement <8 x i1> %498, i1 %510, i64 1
  %512 = extractelement <8 x i32> %485, i64 2
  %513 = icmp ult i32 %512, 8
  %514 = select i1 %513, i32 %512, i32 0
  %515 = extractelement <8 x i1> %51, i32 %514
  %516 = extractelement <8 x i1> %51, i64 2
  %517 = and i1 %513, %515
  %518 = and i1 %516, %517
  %519 = extractelement <8 x float> %484, i32 %514
  %520 = select i1 %518, float %519, float 0.000000e+00
  %521 = insertelement <8 x float> %508, float %520, i64 2
  %522 = xor i1 %518, true
  %523 = and i1 %516, %522
  %524 = insertelement <8 x i1> %511, i1 %523, i64 2
  %525 = extractelement <8 x i32> %485, i64 3
  %526 = icmp ult i32 %525, 8
  %527 = select i1 %526, i32 %525, i32 0
  %528 = extractelement <8 x i1> %51, i32 %527
  %529 = extractelement <8 x i1> %51, i64 3
  %530 = and i1 %526, %528
  %531 = and i1 %529, %530
  %532 = extractelement <8 x float> %484, i32 %527
  %533 = select i1 %531, float %532, float 0.000000e+00
  %534 = insertelement <8 x float> %521, float %533, i64 3
  %535 = xor i1 %531, true
  %536 = and i1 %529, %535
  %537 = insertelement <8 x i1> %524, i1 %536, i64 3
  %538 = extractelement <8 x i32> %485, i64 4
  %539 = icmp ult i32 %538, 8
  %540 = select i1 %539, i32 %538, i32 0
  %541 = extractelement <8 x i1> %51, i32 %540
  %542 = extractelement <8 x i1> %51, i64 4
  %543 = and i1 %539, %541
  %544 = and i1 %542, %543
  %545 = extractelement <8 x float> %484, i32 %540
  %546 = select i1 %544, float %545, float 0.000000e+00
  %547 = insertelement <8 x float> %534, float %546, i64 4
  %548 = xor i1 %544, true
  %549 = and i1 %542, %548
  %550 = insertelement <8 x i1> %537, i1 %549, i64 4
  %551 = extractelement <8 x i32> %485, i64 5
  %552 = icmp ult i32 %551, 8
  %553 = select i1 %552, i32 %551, i32 0
  %554 = extractelement <8 x i1> %51, i32 %553
  %555 = extractelement <8 x i1> %51, i64 5
  %556 = and i1 %552, %554
  %557 = and i1 %555, %556
  %558 = extractelement <8 x float> %484, i32 %553
  %559 = select i1 %557, float %558, float 0.000000e+00
  %560 = insertelement <8 x float> %547, float %559, i64 5
  %561 = xor i1 %557, true
  %562 = and i1 %555, %561
  %563 = insertelement <8 x i1> %550, i1 %562, i64 5
  %564 = extractelement <8 x i32> %485, i64 6
  %565 = icmp ult i32 %564, 8
  %566 = select i1 %565, i32 %564, i32 0
  %567 = extractelement <8 x i1> %51, i32 %566
  %568 = extractelement <8 x i1> %51, i64 6
  %569 = and i1 %565, %567
  %570 = and i1 %568, %569
  %571 = extractelement <8 x float> %484, i32 %566
  %572 = select i1 %570, float %571, float 0.000000e+00
  %573 = insertelement <8 x float> %560, float %572, i64 6
  %574 = xor i1 %570, true
  %575 = and i1 %568, %574
  %576 = insertelement <8 x i1> %563, i1 %575, i64 6
  %577 = extractelement <8 x i32> %485, i64 7
  %578 = icmp ult i32 %577, 8
  %579 = select i1 %578, i32 %577, i32 0
  %580 = extractelement <8 x i1> %51, i32 %579
  %581 = extractelement <8 x i1> %51, i64 7
  %582 = and i1 %578, %580
  %583 = and i1 %581, %582
  %584 = extractelement <8 x float> %484, i32 %579
  %585 = select i1 %583, float %584, float 0.000000e+00
  %586 = insertelement <8 x float> %573, float %585, i64 7
  %587 = xor i1 %583, true
  %588 = and i1 %581, %587
  %589 = insertelement <8 x i1> %576, i1 %588, i64 7
  %590 = fadd <8 x float> %484, %586
  %591 = xor <8 x i32> %378, splat (i32 4)
  %592 = extractelement <8 x i32> %591, i64 0
  %593 = icmp ult i32 %592, 8
  %594 = select i1 %593, i32 %592, i32 0
  %595 = extractelement <8 x i1> %51, i32 %594
  %596 = extractelement <8 x i1> %51, i64 0
  %597 = and i1 %593, %595
  %598 = and i1 %596, %597
  %599 = extractelement <8 x float> %590, i32 %594
  %600 = select i1 %598, float %599, float 0.000000e+00
  %601 = insertelement <8 x float> poison, float %600, i64 0
  %602 = xor i1 %598, true
  %603 = and i1 %596, %602
  %604 = insertelement <8 x i1> poison, i1 %603, i64 0
  %605 = extractelement <8 x i32> %591, i64 1
  %606 = icmp ult i32 %605, 8
  %607 = select i1 %606, i32 %605, i32 0
  %608 = extractelement <8 x i1> %51, i32 %607
  %609 = extractelement <8 x i1> %51, i64 1
  %610 = and i1 %606, %608
  %611 = and i1 %609, %610
  %612 = extractelement <8 x float> %590, i32 %607
  %613 = select i1 %611, float %612, float 0.000000e+00
  %614 = insertelement <8 x float> %601, float %613, i64 1
  %615 = xor i1 %611, true
  %616 = and i1 %609, %615
  %617 = insertelement <8 x i1> %604, i1 %616, i64 1
  %618 = extractelement <8 x i32> %591, i64 2
  %619 = icmp ult i32 %618, 8
  %620 = select i1 %619, i32 %618, i32 0
  %621 = extractelement <8 x i1> %51, i32 %620
  %622 = extractelement <8 x i1> %51, i64 2
  %623 = and i1 %619, %621
  %624 = and i1 %622, %623
  %625 = extractelement <8 x float> %590, i32 %620
  %626 = select i1 %624, float %625, float 0.000000e+00
  %627 = insertelement <8 x float> %614, float %626, i64 2
  %628 = xor i1 %624, true
  %629 = and i1 %622, %628
  %630 = insertelement <8 x i1> %617, i1 %629, i64 2
  %631 = extractelement <8 x i32> %591, i64 3
  %632 = icmp ult i32 %631, 8
  %633 = select i1 %632, i32 %631, i32 0
  %634 = extractelement <8 x i1> %51, i32 %633
  %635 = extractelement <8 x i1> %51, i64 3
  %636 = and i1 %632, %634
  %637 = and i1 %635, %636
  %638 = extractelement <8 x float> %590, i32 %633
  %639 = select i1 %637, float %638, float 0.000000e+00
  %640 = insertelement <8 x float> %627, float %639, i64 3
  %641 = xor i1 %637, true
  %642 = and i1 %635, %641
  %643 = insertelement <8 x i1> %630, i1 %642, i64 3
  %644 = extractelement <8 x i32> %591, i64 4
  %645 = icmp ult i32 %644, 8
  %646 = select i1 %645, i32 %644, i32 0
  %647 = extractelement <8 x i1> %51, i32 %646
  %648 = extractelement <8 x i1> %51, i64 4
  %649 = and i1 %645, %647
  %650 = and i1 %648, %649
  %651 = extractelement <8 x float> %590, i32 %646
  %652 = select i1 %650, float %651, float 0.000000e+00
  %653 = insertelement <8 x float> %640, float %652, i64 4
  %654 = xor i1 %650, true
  %655 = and i1 %648, %654
  %656 = insertelement <8 x i1> %643, i1 %655, i64 4
  %657 = extractelement <8 x i32> %591, i64 5
  %658 = icmp ult i32 %657, 8
  %659 = select i1 %658, i32 %657, i32 0
  %660 = extractelement <8 x i1> %51, i32 %659
  %661 = extractelement <8 x i1> %51, i64 5
  %662 = and i1 %658, %660
  %663 = and i1 %661, %662
  %664 = extractelement <8 x float> %590, i32 %659
  %665 = select i1 %663, float %664, float 0.000000e+00
  %666 = insertelement <8 x float> %653, float %665, i64 5
  %667 = xor i1 %663, true
  %668 = and i1 %661, %667
  %669 = insertelement <8 x i1> %656, i1 %668, i64 5
  %670 = extractelement <8 x i32> %591, i64 6
  %671 = icmp ult i32 %670, 8
  %672 = select i1 %671, i32 %670, i32 0
  %673 = extractelement <8 x i1> %51, i32 %672
  %674 = extractelement <8 x i1> %51, i64 6
  %675 = and i1 %671, %673
  %676 = and i1 %674, %675
  %677 = extractelement <8 x float> %590, i32 %672
  %678 = select i1 %676, float %677, float 0.000000e+00
  %679 = insertelement <8 x float> %666, float %678, i64 6
  %680 = xor i1 %676, true
  %681 = and i1 %674, %680
  %682 = insertelement <8 x i1> %669, i1 %681, i64 6
  %683 = extractelement <8 x i32> %591, i64 7
  %684 = icmp ult i32 %683, 8
  %685 = select i1 %684, i32 %683, i32 0
  %686 = extractelement <8 x i1> %51, i32 %685
  %687 = extractelement <8 x i1> %51, i64 7
  %688 = and i1 %684, %686
  %689 = and i1 %687, %688
  %690 = extractelement <8 x float> %590, i32 %685
  %691 = select i1 %689, float %690, float 0.000000e+00
  %692 = insertelement <8 x float> %679, float %691, i64 7
  %693 = xor i1 %689, true
  %694 = and i1 %687, %693
  %695 = insertelement <8 x i1> %682, i1 %694, i64 7
  %696 = fadd <8 x float> %590, %692
  %697 = extractelement <8 x i1> %51, i32 0
  %698 = extractelement <8 x i1> %51, i64 0
  %699 = and i1 true, %697
  %700 = and i1 %698, %699
  %701 = extractelement <8 x float> %696, i32 0
  %702 = select i1 %700, float %701, float 0.000000e+00
  %703 = insertelement <8 x float> poison, float %702, i64 0
  %704 = xor i1 %700, true
  %705 = and i1 %698, %704
  %706 = insertelement <8 x i1> poison, i1 %705, i64 0
  %707 = extractelement <8 x i1> %51, i32 0
  %708 = extractelement <8 x i1> %51, i64 1
  %709 = and i1 true, %707
  %710 = and i1 %708, %709
  %711 = extractelement <8 x float> %696, i32 0
  %712 = select i1 %710, float %711, float 0.000000e+00
  %713 = insertelement <8 x float> %703, float %712, i64 1
  %714 = xor i1 %710, true
  %715 = and i1 %708, %714
  %716 = insertelement <8 x i1> %706, i1 %715, i64 1
  %717 = extractelement <8 x i1> %51, i32 0
  %718 = extractelement <8 x i1> %51, i64 2
  %719 = and i1 true, %717
  %720 = and i1 %718, %719
  %721 = extractelement <8 x float> %696, i32 0
  %722 = select i1 %720, float %721, float 0.000000e+00
  %723 = insertelement <8 x float> %713, float %722, i64 2
  %724 = xor i1 %720, true
  %725 = and i1 %718, %724
  %726 = insertelement <8 x i1> %716, i1 %725, i64 2
  %727 = extractelement <8 x i1> %51, i32 0
  %728 = extractelement <8 x i1> %51, i64 3
  %729 = and i1 true, %727
  %730 = and i1 %728, %729
  %731 = extractelement <8 x float> %696, i32 0
  %732 = select i1 %730, float %731, float 0.000000e+00
  %733 = insertelement <8 x float> %723, float %732, i64 3
  %734 = xor i1 %730, true
  %735 = and i1 %728, %734
  %736 = insertelement <8 x i1> %726, i1 %735, i64 3
  %737 = extractelement <8 x i1> %51, i32 0
  %738 = extractelement <8 x i1> %51, i64 4
  %739 = and i1 true, %737
  %740 = and i1 %738, %739
  %741 = extractelement <8 x float> %696, i32 0
  %742 = select i1 %740, float %741, float 0.000000e+00
  %743 = insertelement <8 x float> %733, float %742, i64 4
  %744 = xor i1 %740, true
  %745 = and i1 %738, %744
  %746 = insertelement <8 x i1> %736, i1 %745, i64 4
  %747 = extractelement <8 x i1> %51, i32 0
  %748 = extractelement <8 x i1> %51, i64 5
  %749 = and i1 true, %747
  %750 = and i1 %748, %749
  %751 = extractelement <8 x float> %696, i32 0
  %752 = select i1 %750, float %751, float 0.000000e+00
  %753 = insertelement <8 x float> %743, float %752, i64 5
  %754 = xor i1 %750, true
  %755 = and i1 %748, %754
  %756 = insertelement <8 x i1> %746, i1 %755, i64 5
  %757 = extractelement <8 x i1> %51, i32 0
  %758 = extractelement <8 x i1> %51, i64 6
  %759 = and i1 true, %757
  %760 = and i1 %758, %759
  %761 = extractelement <8 x float> %696, i32 0
  %762 = select i1 %760, float %761, float 0.000000e+00
  %763 = insertelement <8 x float> %753, float %762, i64 6
  %764 = xor i1 %760, true
  %765 = and i1 %758, %764
  %766 = insertelement <8 x i1> %756, i1 %765, i64 6
  %767 = extractelement <8 x i1> %51, i32 0
  %768 = extractelement <8 x i1> %51, i64 7
  %769 = and i1 true, %767
  %770 = and i1 %768, %769
  %771 = extractelement <8 x float> %696, i32 0
  %772 = select i1 %770, float %771, float 0.000000e+00
  %773 = insertelement <8 x float> %763, float %772, i64 7
  %774 = xor i1 %770, true
  %775 = and i1 %768, %774
  %776 = insertelement <8 x i1> %766, i1 %775, i64 7
  %777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %778 = bitcast <8 x i1> %51 to i8
  %779 = call i8 @llvm.cttz.i8(i8 %778, i1 false)
  %780 = zext i8 %779 to i32
  %781 = select i1 %777, i32 %780, i32 0
  %782 = extractelement <8 x float> %773, i32 %781
  %.spill.load103 = load float, ptr %.spill6, align 4
  %783 = fadd float %.spill.load103, %782
  %784 = fdiv float %783, 1.023000e+03
  store float %784, ptr %.spill16, align 4
  %785 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %786 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %787 = extractvalue { <8 x ptr>, <8 x i64> } %785, 0
  %788 = select <8 x i1> %51, <8 x ptr> %786, <8 x ptr> %787
  %789 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %790 = extractvalue { <8 x ptr>, <8 x i64> } %785, 1
  %791 = select <8 x i1> %51, <8 x i64> %789, <8 x i64> %790
  %792 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %788, 0
  %793 = insertvalue { <8 x ptr>, <8 x i64> } %792, <8 x i64> %791, 1
  store { <8 x ptr>, <8 x i64> } %793, ptr %tile_snapshot.spill17, align 64
  %794 = load <8 x i64>, ptr %.slot18, align 64
  %795 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %794
  store <8 x i64> %795, ptr %.slot18, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state104 = load <8 x i64>, ptr %.slot18, align 64
  %796 = icmp slt <8 x i64> %.state104, splat (i64 127)
  %797 = extractelement <8 x i1> %796, i32 0
  br i1 %797, label %direct.true105, label %direct.false106

direct.schedule.12:                               ; preds = %direct.true105
  %.state107 = load <8 x i64>, ptr %.slot18, align 64
  %798 = mul <8 x i64> %.state107, splat (i64 8)
  %.spill.load108 = load <8 x i64>, ptr %.spill, align 64
  %799 = add <8 x i64> %798, %.spill.load108
  %.spill.load109 = load i64, ptr %.spill7, align 4
  %800 = add i64 %.spill.load109, 0
  %801 = add <8 x i64> zeroinitializer, %799
  %802 = mul i64 %800, 1023
  %.splatinsert110 = insertelement <8 x i64> poison, i64 %802, i64 0
  %.splat111 = shufflevector <8 x i64> %.splatinsert110, <8 x i64> poison, <8 x i32> zeroinitializer
  %803 = add <8 x i64> %.splat111, %801
  %804 = extractvalue { ptr, i64 } %15, 0
  %805 = extractelement <8 x i64> %803, i32 0
  %806 = sub i64 %805, 0
  %807 = mul i64 %806, 4
  %buffer.contiguous.address112 = getelementptr i8, ptr %804, i64 %807
  %buffer.contiguous.load113 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address112, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load114 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %808 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 0
  %809 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 1
  %.state115 = load <8 x i64>, ptr %.slot18, align 64
  %810 = mul <8 x i64> %.state115, splat (i64 32)
  %811 = add <8 x i64> %809, %810
  %812 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %808, 0
  %813 = insertvalue { <8 x ptr>, <8 x i64> } %812, <8 x i64> %811, 1
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %815 = extractvalue { <8 x ptr>, <8 x i64> } %813, 1
  %816 = extractelement <8 x ptr> %814, i32 0
  %817 = extractelement <8 x i64> %815, i32 0
  %818 = sub i64 %817, 0
  %819 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %820 = select i1 %819, i64 %818, i64 0
  %private.contiguous.address116 = getelementptr i8, ptr %816, i64 %820
  %private.contiguous.preserve117 = load <8 x float>, ptr %private.contiguous.address116, align 4
  %821 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load113, <8 x float> %private.contiguous.preserve117
  store <8 x float> %821, ptr %private.contiguous.address116, align 4
  %.state118 = load <8 x i64>, ptr %.slot18, align 64
  %822 = add <8 x i64> %.state118, splat (i64 1)
  %823 = load <8 x i64>, ptr %.slot18, align 64
  %824 = select <8 x i1> %51, <8 x i64> %822, <8 x i64> %823
  store <8 x i64> %824, ptr %.slot18, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false106
  %.spill.load119 = load <8 x i1>, ptr %.spill5, align 1
  %825 = and <8 x i1> %51, %.spill.load119
  %826 = xor <8 x i1> %.spill.load119, splat (i1 true)
  %827 = and <8 x i1> %51, %826
  %828 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %825)
  %829 = bitcast <8 x i1> %825 to i8
  %830 = call i8 @llvm.cttz.i8(i8 %829, i1 false)
  %831 = zext i8 %830 to i32
  %832 = select i1 %828, i32 %831, i32 0
  %.spill.load120 = load <8 x i64>, ptr %.spill, align 64
  %833 = add <8 x i64> splat (i64 1016), %.spill.load120
  %.spill.load121 = load i64, ptr %.spill7, align 4
  %834 = add i64 %.spill.load121, 0
  %835 = add <8 x i64> zeroinitializer, %833
  %836 = mul i64 %834, 1023
  %.splatinsert122 = insertelement <8 x i64> poison, i64 %836, i64 0
  %.splat123 = shufflevector <8 x i64> %.splatinsert122, <8 x i64> poison, <8 x i32> zeroinitializer
  %837 = add <8 x i64> %.splat123, %835
  %838 = extractvalue { ptr, i64 } %15, 0
  %839 = select <8 x i1> %825, <8 x i64> %837, <8 x i64> zeroinitializer
  %840 = extractelement <8 x i64> %839, i32 %832
  %841 = zext i32 %832 to i64
  %842 = sub i64 %840, %841
  %843 = mul i64 %842, 4
  %buffer.contiguous.address124 = getelementptr i8, ptr %838, i64 %843
  %buffer.contiguous.load125 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address124, i32 1, <8 x i1> %825, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %844 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 0
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 1
  %846 = add <8 x i64> %845, splat (i64 4064)
  %847 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %844, 0
  %848 = insertvalue { <8 x ptr>, <8 x i64> } %847, <8 x i64> %846, 1
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %850 = extractvalue { <8 x ptr>, <8 x i64> } %848, 1
  %851 = extractelement <8 x ptr> %849, i32 0
  %852 = extractelement <8 x i64> %850, i32 %832
  %853 = zext i32 %832 to i64
  %854 = mul i64 %853, 4
  %855 = sub i64 %852, %854
  %856 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %825)
  %857 = select i1 %856, i64 %855, i64 0
  %private.contiguous.address127 = getelementptr i8, ptr %851, i64 %857
  %private.contiguous.preserve128 = load <8 x float>, ptr %private.contiguous.address127, align 4
  %858 = select <8 x i1> %825, <8 x float> %buffer.contiguous.load125, <8 x float> %private.contiguous.preserve128
  store <8 x float> %858, ptr %private.contiguous.address127, align 4
  %859 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %827)
  %860 = bitcast <8 x i1> %827 to i8
  %861 = call i8 @llvm.cttz.i8(i8 %860, i1 false)
  %862 = zext i8 %861 to i32
  %863 = select i1 %859, i32 %862, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  %.spill.load129 = load float, ptr %.spill16, align 4
  %864 = fadd float %.spill.load129, 0x3EE4F8B580000000
  %865 = call float @llvm.sqrt.f32(float %864)
  store float %865, ptr %.spill19, align 4
  %866 = load <8 x i64>, ptr %.slot20, align 64
  %867 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %866
  store <8 x i64> %867, ptr %.slot20, align 64
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state130 = load <8 x i64>, ptr %.slot20, align 64
  %868 = icmp slt <8 x i64> %.state130, splat (i64 127)
  %869 = extractelement <8 x i1> %868, i32 0
  br i1 %869, label %direct.true131, label %direct.false132

direct.schedule.17:                               ; preds = %direct.true131
  %.state133 = load <8 x i64>, ptr %.slot20, align 64
  %870 = mul <8 x i64> %.state133, splat (i64 8)
  %.spill.load134 = load <8 x i64>, ptr %.spill, align 64
  %871 = add <8 x i64> %870, %.spill.load134
  %.spill.load135 = load <8 x i64>, ptr %.spill4, align 64
  %872 = add <8 x i64> %.spill.load135, zeroinitializer
  %873 = add <8 x i64> zeroinitializer, %872
  %874 = add <8 x i64> zeroinitializer, %871
  %875 = mul <8 x i64> %873, splat (i64 1023)
  %876 = add <8 x i64> %875, %874
  %tile_snapshot.spill.load136 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %877 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 0
  %878 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 1
  %.state137 = load <8 x i64>, ptr %.slot20, align 64
  %879 = mul <8 x i64> %.state137, splat (i64 32)
  %880 = add <8 x i64> %878, %879
  %881 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %877, 0
  %882 = insertvalue { <8 x ptr>, <8 x i64> } %881, <8 x i64> %880, 1
  %883 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %884 = extractvalue { <8 x ptr>, <8 x i64> } %882, 1
  %885 = extractelement <8 x ptr> %883, i32 0
  %886 = extractelement <8 x i64> %884, i32 0
  %887 = sub i64 %886, 0
  %888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %889 = select i1 %888, i64 %887, i64 0
  %private.contiguous.address138 = getelementptr i8, ptr %885, i64 %889
  %private.contiguous.load139 = load <8 x float>, ptr %private.contiguous.address138, align 4
  %890 = select <8 x i1> %51, <8 x float> %private.contiguous.load139, <8 x float> zeroinitializer
  %.spill.load140 = load float, ptr %.spill19, align 4
  %.splatinsert141 = insertelement <8 x float> poison, float %.spill.load140, i64 0
  %.splat142 = shufflevector <8 x float> %.splatinsert141, <8 x float> poison, <8 x i32> zeroinitializer
  %891 = fdiv <8 x float> %890, %.splat142
  %tile_snapshot.spill.load143 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %892 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 0
  %893 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 1
  %.state144 = load <8 x i64>, ptr %.slot20, align 64
  %894 = mul <8 x i64> %.state144, splat (i64 32)
  %895 = add <8 x i64> %893, %894
  %896 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %892, 0
  %897 = insertvalue { <8 x ptr>, <8 x i64> } %896, <8 x i64> %895, 1
  %898 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %899 = extractvalue { <8 x ptr>, <8 x i64> } %897, 1
  %900 = extractelement <8 x ptr> %898, i32 0
  %901 = extractelement <8 x i64> %899, i32 0
  %902 = sub i64 %901, 0
  %903 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %904 = select i1 %903, i64 %902, i64 0
  %private.contiguous.address145 = getelementptr i8, ptr %900, i64 %904
  %private.contiguous.load146 = load <8 x float>, ptr %private.contiguous.address145, align 4
  %905 = select <8 x i1> %51, <8 x float> %private.contiguous.load146, <8 x float> zeroinitializer
  %906 = fmul <8 x float> %891, %905
  %907 = extractvalue { ptr, i64 } %27, 0
  %908 = extractelement <8 x i64> %876, i32 0
  %909 = sub i64 %908, 0
  %910 = mul i64 %909, 4
  %buffer.contiguous.address147 = getelementptr i8, ptr %907, i64 %910
  call void @llvm.masked.store.v8f32.p0(<8 x float> %906, ptr %buffer.contiguous.address147, i32 1, <8 x i1> %51)
  %.state148 = load <8 x i64>, ptr %.slot20, align 64
  %911 = add <8 x i64> %.state148, splat (i64 1)
  %912 = load <8 x i64>, ptr %.slot20, align 64
  %913 = select <8 x i1> %51, <8 x i64> %911, <8 x i64> %912
  store <8 x i64> %913, ptr %.slot20, align 64
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false132
  %.spill.load149 = load <8 x i1>, ptr %.spill5, align 1
  %914 = and <8 x i1> %51, %.spill.load149
  %915 = xor <8 x i1> %.spill.load149, splat (i1 true)
  %916 = and <8 x i1> %51, %915
  %917 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %914)
  %918 = bitcast <8 x i1> %914 to i8
  %919 = call i8 @llvm.cttz.i8(i8 %918, i1 false)
  %920 = zext i8 %919 to i32
  %921 = select i1 %917, i32 %920, i32 0
  %.spill.load150 = load <8 x i64>, ptr %.spill, align 64
  %922 = add <8 x i64> splat (i64 1016), %.spill.load150
  %.spill.load151 = load <8 x i64>, ptr %.spill4, align 64
  %923 = add <8 x i64> %.spill.load151, zeroinitializer
  %924 = add <8 x i64> zeroinitializer, %923
  %925 = add <8 x i64> zeroinitializer, %922
  %926 = mul <8 x i64> %924, splat (i64 1023)
  %927 = add <8 x i64> %926, %925
  %tile_snapshot.spill.load152 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %928 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load152, 0
  %929 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load152, 1
  %930 = add <8 x i64> %929, splat (i64 4064)
  %931 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %928, 0
  %932 = insertvalue { <8 x ptr>, <8 x i64> } %931, <8 x i64> %930, 1
  %933 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %934 = extractvalue { <8 x ptr>, <8 x i64> } %932, 1
  %935 = extractelement <8 x ptr> %933, i32 0
  %936 = extractelement <8 x i64> %934, i32 %921
  %937 = zext i32 %921 to i64
  %938 = mul i64 %937, 4
  %939 = sub i64 %936, %938
  %940 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %914)
  %941 = select i1 %940, i64 %939, i64 0
  %private.contiguous.address153 = getelementptr i8, ptr %935, i64 %941
  %private.contiguous.load154 = load <8 x float>, ptr %private.contiguous.address153, align 4
  %942 = select <8 x i1> %914, <8 x float> %private.contiguous.load154, <8 x float> zeroinitializer
  %.spill.load155 = load float, ptr %.spill19, align 4
  %.splatinsert156 = insertelement <8 x float> poison, float %.spill.load155, i64 0
  %.splat157 = shufflevector <8 x float> %.splatinsert156, <8 x float> poison, <8 x i32> zeroinitializer
  %943 = fdiv <8 x float> %942, %.splat157
  %tile_snapshot.spill.load158 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %944 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load158, 0
  %945 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load158, 1
  %946 = add <8 x i64> %945, splat (i64 4064)
  %947 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %944, 0
  %948 = insertvalue { <8 x ptr>, <8 x i64> } %947, <8 x i64> %946, 1
  %949 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %950 = extractvalue { <8 x ptr>, <8 x i64> } %948, 1
  %951 = extractelement <8 x ptr> %949, i32 0
  %952 = extractelement <8 x i64> %950, i32 %921
  %953 = zext i32 %921 to i64
  %954 = mul i64 %953, 4
  %955 = sub i64 %952, %954
  %956 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %914)
  %957 = select i1 %956, i64 %955, i64 0
  %private.contiguous.address159 = getelementptr i8, ptr %951, i64 %957
  %private.contiguous.load160 = load <8 x float>, ptr %private.contiguous.address159, align 4
  %958 = select <8 x i1> %914, <8 x float> %private.contiguous.load160, <8 x float> zeroinitializer
  %959 = fmul <8 x float> %943, %958
  %960 = extractvalue { ptr, i64 } %27, 0
  %961 = extractelement <8 x i64> %927, i32 %921
  %962 = zext i32 %921 to i64
  %963 = sub i64 %961, %962
  %964 = mul i64 %963, 4
  %buffer.contiguous.address161 = getelementptr i8, ptr %960, i64 %964
  call void @llvm.masked.store.v8f32.p0(<8 x float> %959, ptr %buffer.contiguous.address161, i32 1, <8 x i1> %914)
  %965 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %916)
  %966 = bitcast <8 x i1> %916 to i8
  %967 = call i8 @llvm.cttz.i8(i8 %966, i1 false)
  %968 = zext i8 %967 to i32
  %969 = select i1 %965, i32 %968, i32 0
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true59:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false60:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true105:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false106:                                  ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true131:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false132:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [4096 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [4096 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill5, align 1
  %.spill6 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill6, align 4
  %.spill7 = alloca i64, align 8
  store i64 0, ptr %.spill7, align 4
  %.slot8 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot8, align 64
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.spill13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill13, align 32
  %.spill14 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill14, align 32
  %.slot15 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot15, align 32
  %.spill16 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill16, align 4
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot18, align 64
  %.spill19 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill19, align 4
  %.slot20 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot20, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat22, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat24, %41
  %44 = mul i32 %32, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat26, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert27 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat28, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert29 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat30 = shufflevector <8 x i32> %.splatinsert29, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat30
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 127
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state31 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state31, 8
  %.splatinsert32 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat33 = shufflevector <8 x i64> %.splatinsert32, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat33, %.spill.load
  %.spill.load34 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load34, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 1023)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state35 = load i64, ptr %.slot, align 4
  %.splatinsert36 = insertelement <8 x i64> poison, i64 %.state35, i64 0
  %.splat37 = shufflevector <8 x i64> %.splatinsert36, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat37, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state38 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state38, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load39 = load <8 x i64>, ptr %.spill, align 64
  %102 = icmp slt <8 x i64> %.spill.load39, splat (i64 7)
  %103 = load <8 x i1>, ptr %.spill5, align 1
  %104 = select <8 x i1> %51, <8 x i1> %102, <8 x i1> %103
  store <8 x i1> %104, ptr %.spill5, align 1
  %105 = and <8 x i1> %51, %102
  %106 = xor <8 x i1> %102, splat (i1 true)
  %107 = and <8 x i1> %51, %106
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %109 = bitcast <8 x i1> %105 to i8
  %110 = call i8 @llvm.cttz.i8(i8 %109, i1 false)
  %111 = zext i8 %110 to i32
  %112 = select i1 %108, i32 %111, i32 0
  %.spill.load40 = load <8 x i64>, ptr %.spill, align 64
  %113 = add <8 x i64> splat (i64 1016), %.spill.load40
  %.spill.load41 = load <8 x i64>, ptr %.spill4, align 64
  %114 = add <8 x i64> %.spill.load41, zeroinitializer
  %115 = add <8 x i64> zeroinitializer, %114
  %116 = add <8 x i64> zeroinitializer, %113
  %117 = mul <8 x i64> %115, splat (i64 1023)
  %118 = add <8 x i64> %117, %116
  %119 = extractvalue { ptr, i64 } %9, 0
  %120 = select <8 x i1> %105, <8 x i64> %118, <8 x i64> zeroinitializer
  %121 = extractelement <8 x i64> %120, i32 %112
  %122 = zext i32 %112 to i64
  %123 = sub i64 %121, %122
  %124 = mul i64 %123, 4
  %buffer.contiguous.address42 = getelementptr i8, ptr %119, i64 %124
  %buffer.contiguous.load43 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address42, i32 1, <8 x i1> %105, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load44 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 1
  %127 = add <8 x i64> %126, splat (i64 4064)
  %128 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %125, 0
  %129 = insertvalue { <8 x ptr>, <8 x i64> } %128, <8 x i64> %127, 1
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %129, 1
  %132 = extractelement <8 x ptr> %130, i32 0
  %133 = extractelement <8 x i64> %131, i32 %112
  %134 = zext i32 %112 to i64
  %135 = mul i64 %134, 4
  %136 = sub i64 %133, %135
  %137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %138 = select i1 %137, i64 %136, i64 0
  %private.contiguous.address45 = getelementptr i8, ptr %132, i64 %138
  %private.contiguous.preserve46 = load <8 x float>, ptr %private.contiguous.address45, align 4
  %139 = select <8 x i1> %105, <8 x float> %buffer.contiguous.load43, <8 x float> %private.contiguous.preserve46
  store <8 x float> %139, ptr %private.contiguous.address45, align 4
  %140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %107)
  %141 = bitcast <8 x i1> %107 to i8
  %142 = call i8 @llvm.cttz.i8(i8 %141, i1 false)
  %143 = zext i8 %142 to i32
  %144 = select i1 %140, i32 %143, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  store float 0.000000e+00, ptr %.spill6, align 4
  store i64 0, ptr %.spill7, align 4
  %tile_snapshot.spill.load47 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 0
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 1
  %147 = add <8 x i64> %146, zeroinitializer
  %148 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %145, 0
  %149 = insertvalue { <8 x ptr>, <8 x i64> } %148, <8 x i64> %147, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %149, 1
  %152 = extractelement <8 x ptr> %150, i32 0
  %153 = extractelement <8 x i64> %151, i32 0
  %154 = sub i64 %153, 0
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %156 = select i1 %155, i64 %154, i64 0
  %private.contiguous.address48 = getelementptr i8, ptr %152, i64 %156
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address48, align 4
  %157 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %158 = fmul <8 x float> %157, %157
  %tile_snapshot.spill.load49 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load49, 0
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load49, 1
  %161 = add <8 x i64> %160, splat (i64 32)
  %162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %159, 0
  %163 = insertvalue { <8 x ptr>, <8 x i64> } %162, <8 x i64> %161, 1
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %163, 1
  %166 = extractelement <8 x ptr> %164, i32 0
  %167 = extractelement <8 x i64> %165, i32 0
  %168 = sub i64 %167, 0
  %169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %170 = select i1 %169, i64 %168, i64 0
  %private.contiguous.address50 = getelementptr i8, ptr %166, i64 %170
  %private.contiguous.load51 = load <8 x float>, ptr %private.contiguous.address50, align 4
  %171 = select <8 x i1> %51, <8 x float> %private.contiguous.load51, <8 x float> zeroinitializer
  %172 = fmul <8 x float> %171, %171
  %tile_snapshot.spill.load52 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 0
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 1
  %175 = add <8 x i64> %174, splat (i64 64)
  %176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %173, 0
  %177 = insertvalue { <8 x ptr>, <8 x i64> } %176, <8 x i64> %175, 1
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %177, 1
  %180 = extractelement <8 x ptr> %178, i32 0
  %181 = extractelement <8 x i64> %179, i32 0
  %182 = sub i64 %181, 0
  %183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %184 = select i1 %183, i64 %182, i64 0
  %private.contiguous.address53 = getelementptr i8, ptr %180, i64 %184
  %private.contiguous.load54 = load <8 x float>, ptr %private.contiguous.address53, align 4
  %185 = select <8 x i1> %51, <8 x float> %private.contiguous.load54, <8 x float> zeroinitializer
  %186 = fmul <8 x float> %185, %185
  %tile_snapshot.spill.load55 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load55, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load55, 1
  %189 = add <8 x i64> %188, splat (i64 96)
  %190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %187, 0
  %191 = insertvalue { <8 x ptr>, <8 x i64> } %190, <8 x i64> %189, 1
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %191, 1
  %194 = extractelement <8 x ptr> %192, i32 0
  %195 = extractelement <8 x i64> %193, i32 0
  %196 = sub i64 %195, 0
  %197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %198 = select i1 %197, i64 %196, i64 0
  %private.contiguous.address56 = getelementptr i8, ptr %194, i64 %198
  %private.contiguous.load57 = load <8 x float>, ptr %private.contiguous.address56, align 4
  %199 = select <8 x i1> %51, <8 x float> %private.contiguous.load57, <8 x float> zeroinitializer
  %200 = fmul <8 x float> %199, %199
  %201 = load <8 x i64>, ptr %.slot8, align 64
  %202 = select <8 x i1> %51, <8 x i64> splat (i64 4), <8 x i64> %201
  store <8 x i64> %202, ptr %.slot8, align 64
  %203 = load <8 x float>, ptr %.slot9, align 32
  %204 = select <8 x i1> %51, <8 x float> %158, <8 x float> %203
  store <8 x float> %204, ptr %.slot9, align 32
  %205 = load <8 x float>, ptr %.slot10, align 32
  %206 = select <8 x i1> %51, <8 x float> %172, <8 x float> %205
  store <8 x float> %206, ptr %.slot10, align 32
  %207 = load <8 x float>, ptr %.slot11, align 32
  %208 = select <8 x i1> %51, <8 x float> %186, <8 x float> %207
  store <8 x float> %208, ptr %.slot11, align 32
  %209 = load <8 x float>, ptr %.slot12, align 32
  %210 = select <8 x i1> %51, <8 x float> %200, <8 x float> %209
  store <8 x float> %210, ptr %.slot12, align 32
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state58 = load <8 x i64>, ptr %.slot8, align 64
  %211 = icmp slt <8 x i64> %.state58, splat (i64 124)
  %212 = extractelement <8 x i1> %211, i32 0
  br i1 %212, label %direct.true59, label %direct.false60

direct.schedule.7:                                ; preds = %direct.true59
  %.state61 = load <8 x i64>, ptr %.slot8, align 64
  %213 = add <8 x i64> %.state61, zeroinitializer
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %216 = mul <8 x i64> %213, splat (i64 32)
  %217 = add <8 x i64> %215, %216
  %218 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %214, 0
  %219 = insertvalue { <8 x ptr>, <8 x i64> } %218, <8 x i64> %217, 1
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %219, 1
  %222 = extractelement <8 x ptr> %220, i32 0
  %223 = extractelement <8 x i64> %221, i32 0
  %224 = sub i64 %223, 0
  %225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %226 = select i1 %225, i64 %224, i64 0
  %private.contiguous.address63 = getelementptr i8, ptr %222, i64 %226
  %private.contiguous.load64 = load <8 x float>, ptr %private.contiguous.address63, align 4
  %227 = select <8 x i1> %51, <8 x float> %private.contiguous.load64, <8 x float> zeroinitializer
  %228 = fmul <8 x float> %227, %227
  %.state65 = load <8 x float>, ptr %.slot9, align 32
  %229 = fadd <8 x float> %.state65, %228
  %.state66 = load <8 x i64>, ptr %.slot8, align 64
  %230 = add <8 x i64> %.state66, splat (i64 1)
  %tile_snapshot.spill.load67 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 0
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 1
  %233 = mul <8 x i64> %230, splat (i64 32)
  %234 = add <8 x i64> %232, %233
  %235 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %231, 0
  %236 = insertvalue { <8 x ptr>, <8 x i64> } %235, <8 x i64> %234, 1
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %236, 1
  %239 = extractelement <8 x ptr> %237, i32 0
  %240 = extractelement <8 x i64> %238, i32 0
  %241 = sub i64 %240, 0
  %242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %243 = select i1 %242, i64 %241, i64 0
  %private.contiguous.address68 = getelementptr i8, ptr %239, i64 %243
  %private.contiguous.load69 = load <8 x float>, ptr %private.contiguous.address68, align 4
  %244 = select <8 x i1> %51, <8 x float> %private.contiguous.load69, <8 x float> zeroinitializer
  %245 = fmul <8 x float> %244, %244
  %.state70 = load <8 x float>, ptr %.slot10, align 32
  %246 = fadd <8 x float> %.state70, %245
  %.state71 = load <8 x i64>, ptr %.slot8, align 64
  %247 = add <8 x i64> %.state71, splat (i64 2)
  %tile_snapshot.spill.load72 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load72, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load72, 1
  %250 = mul <8 x i64> %247, splat (i64 32)
  %251 = add <8 x i64> %249, %250
  %252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %253 = insertvalue { <8 x ptr>, <8 x i64> } %252, <8 x i64> %251, 1
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %253, 1
  %256 = extractelement <8 x ptr> %254, i32 0
  %257 = extractelement <8 x i64> %255, i32 0
  %258 = sub i64 %257, 0
  %259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %260 = select i1 %259, i64 %258, i64 0
  %private.contiguous.address73 = getelementptr i8, ptr %256, i64 %260
  %private.contiguous.load74 = load <8 x float>, ptr %private.contiguous.address73, align 4
  %261 = select <8 x i1> %51, <8 x float> %private.contiguous.load74, <8 x float> zeroinitializer
  %262 = fmul <8 x float> %261, %261
  %.state75 = load <8 x float>, ptr %.slot11, align 32
  %263 = fadd <8 x float> %.state75, %262
  %.state76 = load <8 x i64>, ptr %.slot8, align 64
  %264 = add <8 x i64> %.state76, splat (i64 3)
  %tile_snapshot.spill.load77 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load77, 0
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load77, 1
  %267 = mul <8 x i64> %264, splat (i64 32)
  %268 = add <8 x i64> %266, %267
  %269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %265, 0
  %270 = insertvalue { <8 x ptr>, <8 x i64> } %269, <8 x i64> %268, 1
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %270, 1
  %273 = extractelement <8 x ptr> %271, i32 0
  %274 = extractelement <8 x i64> %272, i32 0
  %275 = sub i64 %274, 0
  %276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %277 = select i1 %276, i64 %275, i64 0
  %private.contiguous.address78 = getelementptr i8, ptr %273, i64 %277
  %private.contiguous.load79 = load <8 x float>, ptr %private.contiguous.address78, align 4
  %278 = select <8 x i1> %51, <8 x float> %private.contiguous.load79, <8 x float> zeroinitializer
  %279 = fmul <8 x float> %278, %278
  %.state80 = load <8 x float>, ptr %.slot12, align 32
  %280 = fadd <8 x float> %.state80, %279
  %.state81 = load <8 x i64>, ptr %.slot8, align 64
  %281 = add <8 x i64> %.state81, splat (i64 4)
  %282 = load <8 x i64>, ptr %.slot8, align 64
  %283 = select <8 x i1> %51, <8 x i64> %281, <8 x i64> %282
  store <8 x i64> %283, ptr %.slot8, align 64
  %284 = load <8 x float>, ptr %.slot9, align 32
  %285 = select <8 x i1> %51, <8 x float> %229, <8 x float> %284
  store <8 x float> %285, ptr %.slot9, align 32
  %286 = load <8 x float>, ptr %.slot10, align 32
  %287 = select <8 x i1> %51, <8 x float> %246, <8 x float> %286
  store <8 x float> %287, ptr %.slot10, align 32
  %288 = load <8 x float>, ptr %.slot11, align 32
  %289 = select <8 x i1> %51, <8 x float> %263, <8 x float> %288
  store <8 x float> %289, ptr %.slot11, align 32
  %290 = load <8 x float>, ptr %.slot12, align 32
  %291 = select <8 x i1> %51, <8 x float> %280, <8 x float> %290
  store <8 x float> %291, ptr %.slot12, align 32
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false60
  %tile_snapshot.spill.load82 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 0
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 1
  %294 = add <8 x i64> %293, splat (i64 3968)
  %295 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %292, 0
  %296 = insertvalue { <8 x ptr>, <8 x i64> } %295, <8 x i64> %294, 1
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %298 = extractvalue { <8 x ptr>, <8 x i64> } %296, 1
  %299 = extractelement <8 x ptr> %297, i32 0
  %300 = extractelement <8 x i64> %298, i32 0
  %301 = sub i64 %300, 0
  %302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %303 = select i1 %302, i64 %301, i64 0
  %private.contiguous.address83 = getelementptr i8, ptr %299, i64 %303
  %private.contiguous.load84 = load <8 x float>, ptr %private.contiguous.address83, align 4
  %304 = select <8 x i1> %51, <8 x float> %private.contiguous.load84, <8 x float> zeroinitializer
  %305 = fmul <8 x float> %304, %304
  %.state85 = load <8 x float>, ptr %.slot9, align 32
  %306 = fadd <8 x float> %.state85, %305
  %tile_snapshot.spill.load86 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %307 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 0
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load86, 1
  %309 = add <8 x i64> %308, splat (i64 4000)
  %310 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %307, 0
  %311 = insertvalue { <8 x ptr>, <8 x i64> } %310, <8 x i64> %309, 1
  %312 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %311, 1
  %314 = extractelement <8 x ptr> %312, i32 0
  %315 = extractelement <8 x i64> %313, i32 0
  %316 = sub i64 %315, 0
  %317 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %318 = select i1 %317, i64 %316, i64 0
  %private.contiguous.address87 = getelementptr i8, ptr %314, i64 %318
  %private.contiguous.load88 = load <8 x float>, ptr %private.contiguous.address87, align 4
  %319 = select <8 x i1> %51, <8 x float> %private.contiguous.load88, <8 x float> zeroinitializer
  %320 = fmul <8 x float> %319, %319
  %.state89 = load <8 x float>, ptr %.slot10, align 32
  %321 = fadd <8 x float> %.state89, %320
  %322 = load <8 x float>, ptr %.spill13, align 32
  %323 = select <8 x i1> %51, <8 x float> %321, <8 x float> %322
  store <8 x float> %323, ptr %.spill13, align 32
  %tile_snapshot.spill.load90 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load90, 0
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load90, 1
  %326 = add <8 x i64> %325, splat (i64 4032)
  %327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %324, 0
  %328 = insertvalue { <8 x ptr>, <8 x i64> } %327, <8 x i64> %326, 1
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %328, 1
  %331 = extractelement <8 x ptr> %329, i32 0
  %332 = extractelement <8 x i64> %330, i32 0
  %333 = sub i64 %332, 0
  %334 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %335 = select i1 %334, i64 %333, i64 0
  %private.contiguous.address91 = getelementptr i8, ptr %331, i64 %335
  %private.contiguous.load92 = load <8 x float>, ptr %private.contiguous.address91, align 4
  %336 = select <8 x i1> %51, <8 x float> %private.contiguous.load92, <8 x float> zeroinitializer
  %337 = fmul <8 x float> %336, %336
  %.state93 = load <8 x float>, ptr %.slot11, align 32
  %338 = fadd <8 x float> %.state93, %337
  %339 = load <8 x float>, ptr %.spill14, align 32
  %340 = select <8 x i1> %51, <8 x float> %338, <8 x float> %339
  store <8 x float> %340, ptr %.spill14, align 32
  %.spill.load94 = load <8 x i1>, ptr %.spill5, align 1
  %341 = and <8 x i1> %51, %.spill.load94
  %342 = xor <8 x i1> %.spill.load94, splat (i1 true)
  %343 = and <8 x i1> %51, %342
  %344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %341)
  %345 = bitcast <8 x i1> %341 to i8
  %346 = call i8 @llvm.cttz.i8(i8 %345, i1 false)
  %347 = zext i8 %346 to i32
  %348 = select i1 %344, i32 %347, i32 0
  %tile_snapshot.spill.load95 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 0
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 1
  %351 = add <8 x i64> %350, splat (i64 4064)
  %352 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %349, 0
  %353 = insertvalue { <8 x ptr>, <8 x i64> } %352, <8 x i64> %351, 1
  %354 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %355 = extractvalue { <8 x ptr>, <8 x i64> } %353, 1
  %356 = extractelement <8 x ptr> %354, i32 0
  %357 = extractelement <8 x i64> %355, i32 %348
  %358 = zext i32 %348 to i64
  %359 = mul i64 %358, 4
  %360 = sub i64 %357, %359
  %361 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %341)
  %362 = select i1 %361, i64 %360, i64 0
  %private.contiguous.address96 = getelementptr i8, ptr %356, i64 %362
  %private.contiguous.load97 = load <8 x float>, ptr %private.contiguous.address96, align 4
  %363 = select <8 x i1> %341, <8 x float> %private.contiguous.load97, <8 x float> zeroinitializer
  %364 = fmul <8 x float> %363, %363
  %365 = fadd <8 x float> %306, %364
  %366 = load <8 x float>, ptr %.slot15, align 32
  %367 = select <8 x i1> %341, <8 x float> %365, <8 x float> %366
  store <8 x float> %367, ptr %.slot15, align 32
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %343)
  %369 = bitcast <8 x i1> %343 to i8
  %370 = call i8 @llvm.cttz.i8(i8 %369, i1 false)
  %371 = zext i8 %370 to i32
  %372 = select i1 %368, i32 %371, i32 0
  %373 = load <8 x float>, ptr %.slot15, align 32
  %374 = select <8 x i1> %343, <8 x float> %306, <8 x float> %373
  store <8 x float> %374, ptr %.slot15, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %.state98 = load <8 x float>, ptr %.slot15, align 32
  %.spill.load99 = load <8 x float>, ptr %.spill13, align 32
  %375 = fadd <8 x float> %.state98, %.spill.load99
  %.spill.load100 = load <8 x float>, ptr %.spill14, align 32
  %376 = fadd <8 x float> %375, %.spill.load100
  %.state101 = load <8 x float>, ptr %.slot12, align 32
  %377 = fadd <8 x float> %376, %.state101
  %.spill.load102 = load <8 x i64>, ptr %.spill, align 64
  %378 = trunc <8 x i64> %.spill.load102 to <8 x i32>
  %379 = xor <8 x i32> %378, splat (i32 1)
  %380 = extractelement <8 x i32> %379, i64 0
  %381 = icmp ult i32 %380, 8
  %382 = select i1 %381, i32 %380, i32 0
  %383 = extractelement <8 x i1> %51, i32 %382
  %384 = extractelement <8 x i1> %51, i64 0
  %385 = and i1 %381, %383
  %386 = and i1 %384, %385
  %387 = extractelement <8 x float> %377, i32 %382
  %388 = select i1 %386, float %387, float 0.000000e+00
  %389 = insertelement <8 x float> poison, float %388, i64 0
  %390 = xor i1 %386, true
  %391 = and i1 %384, %390
  %392 = insertelement <8 x i1> poison, i1 %391, i64 0
  %393 = extractelement <8 x i32> %379, i64 1
  %394 = icmp ult i32 %393, 8
  %395 = select i1 %394, i32 %393, i32 0
  %396 = extractelement <8 x i1> %51, i32 %395
  %397 = extractelement <8 x i1> %51, i64 1
  %398 = and i1 %394, %396
  %399 = and i1 %397, %398
  %400 = extractelement <8 x float> %377, i32 %395
  %401 = select i1 %399, float %400, float 0.000000e+00
  %402 = insertelement <8 x float> %389, float %401, i64 1
  %403 = xor i1 %399, true
  %404 = and i1 %397, %403
  %405 = insertelement <8 x i1> %392, i1 %404, i64 1
  %406 = extractelement <8 x i32> %379, i64 2
  %407 = icmp ult i32 %406, 8
  %408 = select i1 %407, i32 %406, i32 0
  %409 = extractelement <8 x i1> %51, i32 %408
  %410 = extractelement <8 x i1> %51, i64 2
  %411 = and i1 %407, %409
  %412 = and i1 %410, %411
  %413 = extractelement <8 x float> %377, i32 %408
  %414 = select i1 %412, float %413, float 0.000000e+00
  %415 = insertelement <8 x float> %402, float %414, i64 2
  %416 = xor i1 %412, true
  %417 = and i1 %410, %416
  %418 = insertelement <8 x i1> %405, i1 %417, i64 2
  %419 = extractelement <8 x i32> %379, i64 3
  %420 = icmp ult i32 %419, 8
  %421 = select i1 %420, i32 %419, i32 0
  %422 = extractelement <8 x i1> %51, i32 %421
  %423 = extractelement <8 x i1> %51, i64 3
  %424 = and i1 %420, %422
  %425 = and i1 %423, %424
  %426 = extractelement <8 x float> %377, i32 %421
  %427 = select i1 %425, float %426, float 0.000000e+00
  %428 = insertelement <8 x float> %415, float %427, i64 3
  %429 = xor i1 %425, true
  %430 = and i1 %423, %429
  %431 = insertelement <8 x i1> %418, i1 %430, i64 3
  %432 = extractelement <8 x i32> %379, i64 4
  %433 = icmp ult i32 %432, 8
  %434 = select i1 %433, i32 %432, i32 0
  %435 = extractelement <8 x i1> %51, i32 %434
  %436 = extractelement <8 x i1> %51, i64 4
  %437 = and i1 %433, %435
  %438 = and i1 %436, %437
  %439 = extractelement <8 x float> %377, i32 %434
  %440 = select i1 %438, float %439, float 0.000000e+00
  %441 = insertelement <8 x float> %428, float %440, i64 4
  %442 = xor i1 %438, true
  %443 = and i1 %436, %442
  %444 = insertelement <8 x i1> %431, i1 %443, i64 4
  %445 = extractelement <8 x i32> %379, i64 5
  %446 = icmp ult i32 %445, 8
  %447 = select i1 %446, i32 %445, i32 0
  %448 = extractelement <8 x i1> %51, i32 %447
  %449 = extractelement <8 x i1> %51, i64 5
  %450 = and i1 %446, %448
  %451 = and i1 %449, %450
  %452 = extractelement <8 x float> %377, i32 %447
  %453 = select i1 %451, float %452, float 0.000000e+00
  %454 = insertelement <8 x float> %441, float %453, i64 5
  %455 = xor i1 %451, true
  %456 = and i1 %449, %455
  %457 = insertelement <8 x i1> %444, i1 %456, i64 5
  %458 = extractelement <8 x i32> %379, i64 6
  %459 = icmp ult i32 %458, 8
  %460 = select i1 %459, i32 %458, i32 0
  %461 = extractelement <8 x i1> %51, i32 %460
  %462 = extractelement <8 x i1> %51, i64 6
  %463 = and i1 %459, %461
  %464 = and i1 %462, %463
  %465 = extractelement <8 x float> %377, i32 %460
  %466 = select i1 %464, float %465, float 0.000000e+00
  %467 = insertelement <8 x float> %454, float %466, i64 6
  %468 = xor i1 %464, true
  %469 = and i1 %462, %468
  %470 = insertelement <8 x i1> %457, i1 %469, i64 6
  %471 = extractelement <8 x i32> %379, i64 7
  %472 = icmp ult i32 %471, 8
  %473 = select i1 %472, i32 %471, i32 0
  %474 = extractelement <8 x i1> %51, i32 %473
  %475 = extractelement <8 x i1> %51, i64 7
  %476 = and i1 %472, %474
  %477 = and i1 %475, %476
  %478 = extractelement <8 x float> %377, i32 %473
  %479 = select i1 %477, float %478, float 0.000000e+00
  %480 = insertelement <8 x float> %467, float %479, i64 7
  %481 = xor i1 %477, true
  %482 = and i1 %475, %481
  %483 = insertelement <8 x i1> %470, i1 %482, i64 7
  %484 = fadd <8 x float> %377, %480
  %485 = xor <8 x i32> %378, splat (i32 2)
  %486 = extractelement <8 x i32> %485, i64 0
  %487 = icmp ult i32 %486, 8
  %488 = select i1 %487, i32 %486, i32 0
  %489 = extractelement <8 x i1> %51, i32 %488
  %490 = extractelement <8 x i1> %51, i64 0
  %491 = and i1 %487, %489
  %492 = and i1 %490, %491
  %493 = extractelement <8 x float> %484, i32 %488
  %494 = select i1 %492, float %493, float 0.000000e+00
  %495 = insertelement <8 x float> poison, float %494, i64 0
  %496 = xor i1 %492, true
  %497 = and i1 %490, %496
  %498 = insertelement <8 x i1> poison, i1 %497, i64 0
  %499 = extractelement <8 x i32> %485, i64 1
  %500 = icmp ult i32 %499, 8
  %501 = select i1 %500, i32 %499, i32 0
  %502 = extractelement <8 x i1> %51, i32 %501
  %503 = extractelement <8 x i1> %51, i64 1
  %504 = and i1 %500, %502
  %505 = and i1 %503, %504
  %506 = extractelement <8 x float> %484, i32 %501
  %507 = select i1 %505, float %506, float 0.000000e+00
  %508 = insertelement <8 x float> %495, float %507, i64 1
  %509 = xor i1 %505, true
  %510 = and i1 %503, %509
  %511 = insertelement <8 x i1> %498, i1 %510, i64 1
  %512 = extractelement <8 x i32> %485, i64 2
  %513 = icmp ult i32 %512, 8
  %514 = select i1 %513, i32 %512, i32 0
  %515 = extractelement <8 x i1> %51, i32 %514
  %516 = extractelement <8 x i1> %51, i64 2
  %517 = and i1 %513, %515
  %518 = and i1 %516, %517
  %519 = extractelement <8 x float> %484, i32 %514
  %520 = select i1 %518, float %519, float 0.000000e+00
  %521 = insertelement <8 x float> %508, float %520, i64 2
  %522 = xor i1 %518, true
  %523 = and i1 %516, %522
  %524 = insertelement <8 x i1> %511, i1 %523, i64 2
  %525 = extractelement <8 x i32> %485, i64 3
  %526 = icmp ult i32 %525, 8
  %527 = select i1 %526, i32 %525, i32 0
  %528 = extractelement <8 x i1> %51, i32 %527
  %529 = extractelement <8 x i1> %51, i64 3
  %530 = and i1 %526, %528
  %531 = and i1 %529, %530
  %532 = extractelement <8 x float> %484, i32 %527
  %533 = select i1 %531, float %532, float 0.000000e+00
  %534 = insertelement <8 x float> %521, float %533, i64 3
  %535 = xor i1 %531, true
  %536 = and i1 %529, %535
  %537 = insertelement <8 x i1> %524, i1 %536, i64 3
  %538 = extractelement <8 x i32> %485, i64 4
  %539 = icmp ult i32 %538, 8
  %540 = select i1 %539, i32 %538, i32 0
  %541 = extractelement <8 x i1> %51, i32 %540
  %542 = extractelement <8 x i1> %51, i64 4
  %543 = and i1 %539, %541
  %544 = and i1 %542, %543
  %545 = extractelement <8 x float> %484, i32 %540
  %546 = select i1 %544, float %545, float 0.000000e+00
  %547 = insertelement <8 x float> %534, float %546, i64 4
  %548 = xor i1 %544, true
  %549 = and i1 %542, %548
  %550 = insertelement <8 x i1> %537, i1 %549, i64 4
  %551 = extractelement <8 x i32> %485, i64 5
  %552 = icmp ult i32 %551, 8
  %553 = select i1 %552, i32 %551, i32 0
  %554 = extractelement <8 x i1> %51, i32 %553
  %555 = extractelement <8 x i1> %51, i64 5
  %556 = and i1 %552, %554
  %557 = and i1 %555, %556
  %558 = extractelement <8 x float> %484, i32 %553
  %559 = select i1 %557, float %558, float 0.000000e+00
  %560 = insertelement <8 x float> %547, float %559, i64 5
  %561 = xor i1 %557, true
  %562 = and i1 %555, %561
  %563 = insertelement <8 x i1> %550, i1 %562, i64 5
  %564 = extractelement <8 x i32> %485, i64 6
  %565 = icmp ult i32 %564, 8
  %566 = select i1 %565, i32 %564, i32 0
  %567 = extractelement <8 x i1> %51, i32 %566
  %568 = extractelement <8 x i1> %51, i64 6
  %569 = and i1 %565, %567
  %570 = and i1 %568, %569
  %571 = extractelement <8 x float> %484, i32 %566
  %572 = select i1 %570, float %571, float 0.000000e+00
  %573 = insertelement <8 x float> %560, float %572, i64 6
  %574 = xor i1 %570, true
  %575 = and i1 %568, %574
  %576 = insertelement <8 x i1> %563, i1 %575, i64 6
  %577 = extractelement <8 x i32> %485, i64 7
  %578 = icmp ult i32 %577, 8
  %579 = select i1 %578, i32 %577, i32 0
  %580 = extractelement <8 x i1> %51, i32 %579
  %581 = extractelement <8 x i1> %51, i64 7
  %582 = and i1 %578, %580
  %583 = and i1 %581, %582
  %584 = extractelement <8 x float> %484, i32 %579
  %585 = select i1 %583, float %584, float 0.000000e+00
  %586 = insertelement <8 x float> %573, float %585, i64 7
  %587 = xor i1 %583, true
  %588 = and i1 %581, %587
  %589 = insertelement <8 x i1> %576, i1 %588, i64 7
  %590 = fadd <8 x float> %484, %586
  %591 = xor <8 x i32> %378, splat (i32 4)
  %592 = extractelement <8 x i32> %591, i64 0
  %593 = icmp ult i32 %592, 8
  %594 = select i1 %593, i32 %592, i32 0
  %595 = extractelement <8 x i1> %51, i32 %594
  %596 = extractelement <8 x i1> %51, i64 0
  %597 = and i1 %593, %595
  %598 = and i1 %596, %597
  %599 = extractelement <8 x float> %590, i32 %594
  %600 = select i1 %598, float %599, float 0.000000e+00
  %601 = insertelement <8 x float> poison, float %600, i64 0
  %602 = xor i1 %598, true
  %603 = and i1 %596, %602
  %604 = insertelement <8 x i1> poison, i1 %603, i64 0
  %605 = extractelement <8 x i32> %591, i64 1
  %606 = icmp ult i32 %605, 8
  %607 = select i1 %606, i32 %605, i32 0
  %608 = extractelement <8 x i1> %51, i32 %607
  %609 = extractelement <8 x i1> %51, i64 1
  %610 = and i1 %606, %608
  %611 = and i1 %609, %610
  %612 = extractelement <8 x float> %590, i32 %607
  %613 = select i1 %611, float %612, float 0.000000e+00
  %614 = insertelement <8 x float> %601, float %613, i64 1
  %615 = xor i1 %611, true
  %616 = and i1 %609, %615
  %617 = insertelement <8 x i1> %604, i1 %616, i64 1
  %618 = extractelement <8 x i32> %591, i64 2
  %619 = icmp ult i32 %618, 8
  %620 = select i1 %619, i32 %618, i32 0
  %621 = extractelement <8 x i1> %51, i32 %620
  %622 = extractelement <8 x i1> %51, i64 2
  %623 = and i1 %619, %621
  %624 = and i1 %622, %623
  %625 = extractelement <8 x float> %590, i32 %620
  %626 = select i1 %624, float %625, float 0.000000e+00
  %627 = insertelement <8 x float> %614, float %626, i64 2
  %628 = xor i1 %624, true
  %629 = and i1 %622, %628
  %630 = insertelement <8 x i1> %617, i1 %629, i64 2
  %631 = extractelement <8 x i32> %591, i64 3
  %632 = icmp ult i32 %631, 8
  %633 = select i1 %632, i32 %631, i32 0
  %634 = extractelement <8 x i1> %51, i32 %633
  %635 = extractelement <8 x i1> %51, i64 3
  %636 = and i1 %632, %634
  %637 = and i1 %635, %636
  %638 = extractelement <8 x float> %590, i32 %633
  %639 = select i1 %637, float %638, float 0.000000e+00
  %640 = insertelement <8 x float> %627, float %639, i64 3
  %641 = xor i1 %637, true
  %642 = and i1 %635, %641
  %643 = insertelement <8 x i1> %630, i1 %642, i64 3
  %644 = extractelement <8 x i32> %591, i64 4
  %645 = icmp ult i32 %644, 8
  %646 = select i1 %645, i32 %644, i32 0
  %647 = extractelement <8 x i1> %51, i32 %646
  %648 = extractelement <8 x i1> %51, i64 4
  %649 = and i1 %645, %647
  %650 = and i1 %648, %649
  %651 = extractelement <8 x float> %590, i32 %646
  %652 = select i1 %650, float %651, float 0.000000e+00
  %653 = insertelement <8 x float> %640, float %652, i64 4
  %654 = xor i1 %650, true
  %655 = and i1 %648, %654
  %656 = insertelement <8 x i1> %643, i1 %655, i64 4
  %657 = extractelement <8 x i32> %591, i64 5
  %658 = icmp ult i32 %657, 8
  %659 = select i1 %658, i32 %657, i32 0
  %660 = extractelement <8 x i1> %51, i32 %659
  %661 = extractelement <8 x i1> %51, i64 5
  %662 = and i1 %658, %660
  %663 = and i1 %661, %662
  %664 = extractelement <8 x float> %590, i32 %659
  %665 = select i1 %663, float %664, float 0.000000e+00
  %666 = insertelement <8 x float> %653, float %665, i64 5
  %667 = xor i1 %663, true
  %668 = and i1 %661, %667
  %669 = insertelement <8 x i1> %656, i1 %668, i64 5
  %670 = extractelement <8 x i32> %591, i64 6
  %671 = icmp ult i32 %670, 8
  %672 = select i1 %671, i32 %670, i32 0
  %673 = extractelement <8 x i1> %51, i32 %672
  %674 = extractelement <8 x i1> %51, i64 6
  %675 = and i1 %671, %673
  %676 = and i1 %674, %675
  %677 = extractelement <8 x float> %590, i32 %672
  %678 = select i1 %676, float %677, float 0.000000e+00
  %679 = insertelement <8 x float> %666, float %678, i64 6
  %680 = xor i1 %676, true
  %681 = and i1 %674, %680
  %682 = insertelement <8 x i1> %669, i1 %681, i64 6
  %683 = extractelement <8 x i32> %591, i64 7
  %684 = icmp ult i32 %683, 8
  %685 = select i1 %684, i32 %683, i32 0
  %686 = extractelement <8 x i1> %51, i32 %685
  %687 = extractelement <8 x i1> %51, i64 7
  %688 = and i1 %684, %686
  %689 = and i1 %687, %688
  %690 = extractelement <8 x float> %590, i32 %685
  %691 = select i1 %689, float %690, float 0.000000e+00
  %692 = insertelement <8 x float> %679, float %691, i64 7
  %693 = xor i1 %689, true
  %694 = and i1 %687, %693
  %695 = insertelement <8 x i1> %682, i1 %694, i64 7
  %696 = fadd <8 x float> %590, %692
  %697 = extractelement <8 x i1> %51, i32 0
  %698 = extractelement <8 x i1> %51, i64 0
  %699 = and i1 true, %697
  %700 = and i1 %698, %699
  %701 = extractelement <8 x float> %696, i32 0
  %702 = select i1 %700, float %701, float 0.000000e+00
  %703 = insertelement <8 x float> poison, float %702, i64 0
  %704 = xor i1 %700, true
  %705 = and i1 %698, %704
  %706 = insertelement <8 x i1> poison, i1 %705, i64 0
  %707 = extractelement <8 x i1> %51, i32 0
  %708 = extractelement <8 x i1> %51, i64 1
  %709 = and i1 true, %707
  %710 = and i1 %708, %709
  %711 = extractelement <8 x float> %696, i32 0
  %712 = select i1 %710, float %711, float 0.000000e+00
  %713 = insertelement <8 x float> %703, float %712, i64 1
  %714 = xor i1 %710, true
  %715 = and i1 %708, %714
  %716 = insertelement <8 x i1> %706, i1 %715, i64 1
  %717 = extractelement <8 x i1> %51, i32 0
  %718 = extractelement <8 x i1> %51, i64 2
  %719 = and i1 true, %717
  %720 = and i1 %718, %719
  %721 = extractelement <8 x float> %696, i32 0
  %722 = select i1 %720, float %721, float 0.000000e+00
  %723 = insertelement <8 x float> %713, float %722, i64 2
  %724 = xor i1 %720, true
  %725 = and i1 %718, %724
  %726 = insertelement <8 x i1> %716, i1 %725, i64 2
  %727 = extractelement <8 x i1> %51, i32 0
  %728 = extractelement <8 x i1> %51, i64 3
  %729 = and i1 true, %727
  %730 = and i1 %728, %729
  %731 = extractelement <8 x float> %696, i32 0
  %732 = select i1 %730, float %731, float 0.000000e+00
  %733 = insertelement <8 x float> %723, float %732, i64 3
  %734 = xor i1 %730, true
  %735 = and i1 %728, %734
  %736 = insertelement <8 x i1> %726, i1 %735, i64 3
  %737 = extractelement <8 x i1> %51, i32 0
  %738 = extractelement <8 x i1> %51, i64 4
  %739 = and i1 true, %737
  %740 = and i1 %738, %739
  %741 = extractelement <8 x float> %696, i32 0
  %742 = select i1 %740, float %741, float 0.000000e+00
  %743 = insertelement <8 x float> %733, float %742, i64 4
  %744 = xor i1 %740, true
  %745 = and i1 %738, %744
  %746 = insertelement <8 x i1> %736, i1 %745, i64 4
  %747 = extractelement <8 x i1> %51, i32 0
  %748 = extractelement <8 x i1> %51, i64 5
  %749 = and i1 true, %747
  %750 = and i1 %748, %749
  %751 = extractelement <8 x float> %696, i32 0
  %752 = select i1 %750, float %751, float 0.000000e+00
  %753 = insertelement <8 x float> %743, float %752, i64 5
  %754 = xor i1 %750, true
  %755 = and i1 %748, %754
  %756 = insertelement <8 x i1> %746, i1 %755, i64 5
  %757 = extractelement <8 x i1> %51, i32 0
  %758 = extractelement <8 x i1> %51, i64 6
  %759 = and i1 true, %757
  %760 = and i1 %758, %759
  %761 = extractelement <8 x float> %696, i32 0
  %762 = select i1 %760, float %761, float 0.000000e+00
  %763 = insertelement <8 x float> %753, float %762, i64 6
  %764 = xor i1 %760, true
  %765 = and i1 %758, %764
  %766 = insertelement <8 x i1> %756, i1 %765, i64 6
  %767 = extractelement <8 x i1> %51, i32 0
  %768 = extractelement <8 x i1> %51, i64 7
  %769 = and i1 true, %767
  %770 = and i1 %768, %769
  %771 = extractelement <8 x float> %696, i32 0
  %772 = select i1 %770, float %771, float 0.000000e+00
  %773 = insertelement <8 x float> %763, float %772, i64 7
  %774 = xor i1 %770, true
  %775 = and i1 %768, %774
  %776 = insertelement <8 x i1> %766, i1 %775, i64 7
  %777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %778 = bitcast <8 x i1> %51 to i8
  %779 = call i8 @llvm.cttz.i8(i8 %778, i1 false)
  %780 = zext i8 %779 to i32
  %781 = select i1 %777, i32 %780, i32 0
  %782 = extractelement <8 x float> %773, i32 %781
  %.spill.load103 = load float, ptr %.spill6, align 4
  %783 = fadd float %.spill.load103, %782
  %784 = fdiv float %783, 1.023000e+03
  store float %784, ptr %.spill16, align 4
  %785 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %786 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %787 = extractvalue { <8 x ptr>, <8 x i64> } %785, 0
  %788 = select <8 x i1> %51, <8 x ptr> %786, <8 x ptr> %787
  %789 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %790 = extractvalue { <8 x ptr>, <8 x i64> } %785, 1
  %791 = select <8 x i1> %51, <8 x i64> %789, <8 x i64> %790
  %792 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %788, 0
  %793 = insertvalue { <8 x ptr>, <8 x i64> } %792, <8 x i64> %791, 1
  store { <8 x ptr>, <8 x i64> } %793, ptr %tile_snapshot.spill17, align 64
  %794 = load <8 x i64>, ptr %.slot18, align 64
  %795 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %794
  store <8 x i64> %795, ptr %.slot18, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state104 = load <8 x i64>, ptr %.slot18, align 64
  %796 = icmp slt <8 x i64> %.state104, splat (i64 127)
  %797 = extractelement <8 x i1> %796, i32 0
  br i1 %797, label %direct.true105, label %direct.false106

direct.schedule.12:                               ; preds = %direct.true105
  %.state107 = load <8 x i64>, ptr %.slot18, align 64
  %798 = mul <8 x i64> %.state107, splat (i64 8)
  %.spill.load108 = load <8 x i64>, ptr %.spill, align 64
  %799 = add <8 x i64> %798, %.spill.load108
  %.spill.load109 = load i64, ptr %.spill7, align 4
  %800 = add i64 %.spill.load109, 0
  %801 = add <8 x i64> zeroinitializer, %799
  %802 = mul i64 %800, 1023
  %.splatinsert110 = insertelement <8 x i64> poison, i64 %802, i64 0
  %.splat111 = shufflevector <8 x i64> %.splatinsert110, <8 x i64> poison, <8 x i32> zeroinitializer
  %803 = add <8 x i64> %.splat111, %801
  %804 = extractvalue { ptr, i64 } %15, 0
  %805 = extractelement <8 x i64> %803, i32 0
  %806 = sub i64 %805, 0
  %807 = mul i64 %806, 4
  %buffer.contiguous.address112 = getelementptr i8, ptr %804, i64 %807
  %buffer.contiguous.load113 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address112, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load114 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %808 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 0
  %809 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 1
  %.state115 = load <8 x i64>, ptr %.slot18, align 64
  %810 = mul <8 x i64> %.state115, splat (i64 32)
  %811 = add <8 x i64> %809, %810
  %812 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %808, 0
  %813 = insertvalue { <8 x ptr>, <8 x i64> } %812, <8 x i64> %811, 1
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %815 = extractvalue { <8 x ptr>, <8 x i64> } %813, 1
  %816 = extractelement <8 x ptr> %814, i32 0
  %817 = extractelement <8 x i64> %815, i32 0
  %818 = sub i64 %817, 0
  %819 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %820 = select i1 %819, i64 %818, i64 0
  %private.contiguous.address116 = getelementptr i8, ptr %816, i64 %820
  %private.contiguous.preserve117 = load <8 x float>, ptr %private.contiguous.address116, align 4
  %821 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load113, <8 x float> %private.contiguous.preserve117
  store <8 x float> %821, ptr %private.contiguous.address116, align 4
  %.state118 = load <8 x i64>, ptr %.slot18, align 64
  %822 = add <8 x i64> %.state118, splat (i64 1)
  %823 = load <8 x i64>, ptr %.slot18, align 64
  %824 = select <8 x i1> %51, <8 x i64> %822, <8 x i64> %823
  store <8 x i64> %824, ptr %.slot18, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false106
  %.spill.load119 = load <8 x i1>, ptr %.spill5, align 1
  %825 = and <8 x i1> %51, %.spill.load119
  %826 = xor <8 x i1> %.spill.load119, splat (i1 true)
  %827 = and <8 x i1> %51, %826
  %828 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %825)
  %829 = bitcast <8 x i1> %825 to i8
  %830 = call i8 @llvm.cttz.i8(i8 %829, i1 false)
  %831 = zext i8 %830 to i32
  %832 = select i1 %828, i32 %831, i32 0
  %.spill.load120 = load <8 x i64>, ptr %.spill, align 64
  %833 = add <8 x i64> splat (i64 1016), %.spill.load120
  %.spill.load121 = load i64, ptr %.spill7, align 4
  %834 = add i64 %.spill.load121, 0
  %835 = add <8 x i64> zeroinitializer, %833
  %836 = mul i64 %834, 1023
  %.splatinsert122 = insertelement <8 x i64> poison, i64 %836, i64 0
  %.splat123 = shufflevector <8 x i64> %.splatinsert122, <8 x i64> poison, <8 x i32> zeroinitializer
  %837 = add <8 x i64> %.splat123, %835
  %838 = extractvalue { ptr, i64 } %15, 0
  %839 = select <8 x i1> %825, <8 x i64> %837, <8 x i64> zeroinitializer
  %840 = extractelement <8 x i64> %839, i32 %832
  %841 = zext i32 %832 to i64
  %842 = sub i64 %840, %841
  %843 = mul i64 %842, 4
  %buffer.contiguous.address124 = getelementptr i8, ptr %838, i64 %843
  %buffer.contiguous.load125 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address124, i32 1, <8 x i1> %825, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %844 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 0
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 1
  %846 = add <8 x i64> %845, splat (i64 4064)
  %847 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %844, 0
  %848 = insertvalue { <8 x ptr>, <8 x i64> } %847, <8 x i64> %846, 1
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %850 = extractvalue { <8 x ptr>, <8 x i64> } %848, 1
  %851 = extractelement <8 x ptr> %849, i32 0
  %852 = extractelement <8 x i64> %850, i32 %832
  %853 = zext i32 %832 to i64
  %854 = mul i64 %853, 4
  %855 = sub i64 %852, %854
  %856 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %825)
  %857 = select i1 %856, i64 %855, i64 0
  %private.contiguous.address127 = getelementptr i8, ptr %851, i64 %857
  %private.contiguous.preserve128 = load <8 x float>, ptr %private.contiguous.address127, align 4
  %858 = select <8 x i1> %825, <8 x float> %buffer.contiguous.load125, <8 x float> %private.contiguous.preserve128
  store <8 x float> %858, ptr %private.contiguous.address127, align 4
  %859 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %827)
  %860 = bitcast <8 x i1> %827 to i8
  %861 = call i8 @llvm.cttz.i8(i8 %860, i1 false)
  %862 = zext i8 %861 to i32
  %863 = select i1 %859, i32 %862, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  %.spill.load129 = load float, ptr %.spill16, align 4
  %864 = fadd float %.spill.load129, 0x3EE4F8B580000000
  %865 = call float @llvm.sqrt.f32(float %864)
  store float %865, ptr %.spill19, align 4
  %866 = load <8 x i64>, ptr %.slot20, align 64
  %867 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %866
  store <8 x i64> %867, ptr %.slot20, align 64
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state130 = load <8 x i64>, ptr %.slot20, align 64
  %868 = icmp slt <8 x i64> %.state130, splat (i64 127)
  %869 = extractelement <8 x i1> %868, i32 0
  br i1 %869, label %direct.true131, label %direct.false132

direct.schedule.17:                               ; preds = %direct.true131
  %.state133 = load <8 x i64>, ptr %.slot20, align 64
  %870 = mul <8 x i64> %.state133, splat (i64 8)
  %.spill.load134 = load <8 x i64>, ptr %.spill, align 64
  %871 = add <8 x i64> %870, %.spill.load134
  %.spill.load135 = load <8 x i64>, ptr %.spill4, align 64
  %872 = add <8 x i64> %.spill.load135, zeroinitializer
  %873 = add <8 x i64> zeroinitializer, %872
  %874 = add <8 x i64> zeroinitializer, %871
  %875 = mul <8 x i64> %873, splat (i64 1023)
  %876 = add <8 x i64> %875, %874
  %tile_snapshot.spill.load136 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %877 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 0
  %878 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 1
  %.state137 = load <8 x i64>, ptr %.slot20, align 64
  %879 = mul <8 x i64> %.state137, splat (i64 32)
  %880 = add <8 x i64> %878, %879
  %881 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %877, 0
  %882 = insertvalue { <8 x ptr>, <8 x i64> } %881, <8 x i64> %880, 1
  %883 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %884 = extractvalue { <8 x ptr>, <8 x i64> } %882, 1
  %885 = extractelement <8 x ptr> %883, i32 0
  %886 = extractelement <8 x i64> %884, i32 0
  %887 = sub i64 %886, 0
  %888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %889 = select i1 %888, i64 %887, i64 0
  %private.contiguous.address138 = getelementptr i8, ptr %885, i64 %889
  %private.contiguous.load139 = load <8 x float>, ptr %private.contiguous.address138, align 4
  %890 = select <8 x i1> %51, <8 x float> %private.contiguous.load139, <8 x float> zeroinitializer
  %.spill.load140 = load float, ptr %.spill19, align 4
  %.splatinsert141 = insertelement <8 x float> poison, float %.spill.load140, i64 0
  %.splat142 = shufflevector <8 x float> %.splatinsert141, <8 x float> poison, <8 x i32> zeroinitializer
  %891 = fdiv <8 x float> %890, %.splat142
  %tile_snapshot.spill.load143 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %892 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 0
  %893 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 1
  %.state144 = load <8 x i64>, ptr %.slot20, align 64
  %894 = mul <8 x i64> %.state144, splat (i64 32)
  %895 = add <8 x i64> %893, %894
  %896 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %892, 0
  %897 = insertvalue { <8 x ptr>, <8 x i64> } %896, <8 x i64> %895, 1
  %898 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %899 = extractvalue { <8 x ptr>, <8 x i64> } %897, 1
  %900 = extractelement <8 x ptr> %898, i32 0
  %901 = extractelement <8 x i64> %899, i32 0
  %902 = sub i64 %901, 0
  %903 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %904 = select i1 %903, i64 %902, i64 0
  %private.contiguous.address145 = getelementptr i8, ptr %900, i64 %904
  %private.contiguous.load146 = load <8 x float>, ptr %private.contiguous.address145, align 4
  %905 = select <8 x i1> %51, <8 x float> %private.contiguous.load146, <8 x float> zeroinitializer
  %906 = fmul <8 x float> %891, %905
  %907 = extractvalue { ptr, i64 } %27, 0
  %908 = extractelement <8 x i64> %876, i32 0
  %909 = sub i64 %908, 0
  %910 = mul i64 %909, 4
  %buffer.contiguous.address147 = getelementptr i8, ptr %907, i64 %910
  call void @llvm.masked.store.v8f32.p0(<8 x float> %906, ptr %buffer.contiguous.address147, i32 1, <8 x i1> %51)
  %.state148 = load <8 x i64>, ptr %.slot20, align 64
  %911 = add <8 x i64> %.state148, splat (i64 1)
  %912 = load <8 x i64>, ptr %.slot20, align 64
  %913 = select <8 x i1> %51, <8 x i64> %911, <8 x i64> %912
  store <8 x i64> %913, ptr %.slot20, align 64
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false132
  %.spill.load149 = load <8 x i1>, ptr %.spill5, align 1
  %914 = and <8 x i1> %51, %.spill.load149
  %915 = xor <8 x i1> %.spill.load149, splat (i1 true)
  %916 = and <8 x i1> %51, %915
  %917 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %914)
  %918 = bitcast <8 x i1> %914 to i8
  %919 = call i8 @llvm.cttz.i8(i8 %918, i1 false)
  %920 = zext i8 %919 to i32
  %921 = select i1 %917, i32 %920, i32 0
  %.spill.load150 = load <8 x i64>, ptr %.spill, align 64
  %922 = add <8 x i64> splat (i64 1016), %.spill.load150
  %.spill.load151 = load <8 x i64>, ptr %.spill4, align 64
  %923 = add <8 x i64> %.spill.load151, zeroinitializer
  %924 = add <8 x i64> zeroinitializer, %923
  %925 = add <8 x i64> zeroinitializer, %922
  %926 = mul <8 x i64> %924, splat (i64 1023)
  %927 = add <8 x i64> %926, %925
  %tile_snapshot.spill.load152 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %928 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load152, 0
  %929 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load152, 1
  %930 = add <8 x i64> %929, splat (i64 4064)
  %931 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %928, 0
  %932 = insertvalue { <8 x ptr>, <8 x i64> } %931, <8 x i64> %930, 1
  %933 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %934 = extractvalue { <8 x ptr>, <8 x i64> } %932, 1
  %935 = extractelement <8 x ptr> %933, i32 0
  %936 = extractelement <8 x i64> %934, i32 %921
  %937 = zext i32 %921 to i64
  %938 = mul i64 %937, 4
  %939 = sub i64 %936, %938
  %940 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %914)
  %941 = select i1 %940, i64 %939, i64 0
  %private.contiguous.address153 = getelementptr i8, ptr %935, i64 %941
  %private.contiguous.load154 = load <8 x float>, ptr %private.contiguous.address153, align 4
  %942 = select <8 x i1> %914, <8 x float> %private.contiguous.load154, <8 x float> zeroinitializer
  %.spill.load155 = load float, ptr %.spill19, align 4
  %.splatinsert156 = insertelement <8 x float> poison, float %.spill.load155, i64 0
  %.splat157 = shufflevector <8 x float> %.splatinsert156, <8 x float> poison, <8 x i32> zeroinitializer
  %943 = fdiv <8 x float> %942, %.splat157
  %tile_snapshot.spill.load158 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %944 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load158, 0
  %945 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load158, 1
  %946 = add <8 x i64> %945, splat (i64 4064)
  %947 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %944, 0
  %948 = insertvalue { <8 x ptr>, <8 x i64> } %947, <8 x i64> %946, 1
  %949 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %950 = extractvalue { <8 x ptr>, <8 x i64> } %948, 1
  %951 = extractelement <8 x ptr> %949, i32 0
  %952 = extractelement <8 x i64> %950, i32 %921
  %953 = zext i32 %921 to i64
  %954 = mul i64 %953, 4
  %955 = sub i64 %952, %954
  %956 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %914)
  %957 = select i1 %956, i64 %955, i64 0
  %private.contiguous.address159 = getelementptr i8, ptr %951, i64 %957
  %private.contiguous.load160 = load <8 x float>, ptr %private.contiguous.address159, align 4
  %958 = select <8 x i1> %914, <8 x float> %private.contiguous.load160, <8 x float> zeroinitializer
  %959 = fmul <8 x float> %943, %958
  %960 = extractvalue { ptr, i64 } %27, 0
  %961 = extractelement <8 x i64> %927, i32 %921
  %962 = zext i32 %921 to i64
  %963 = sub i64 %961, %962
  %964 = mul i64 %963, 4
  %buffer.contiguous.address161 = getelementptr i8, ptr %960, i64 %964
  call void @llvm.masked.store.v8f32.p0(<8 x float> %959, ptr %buffer.contiguous.address161, i32 1, <8 x i1> %914)
  %965 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %916)
  %966 = bitcast <8 x i1> %916 to i8
  %967 = call i8 @llvm.cttz.i8(i8 %966, i1 false)
  %968 = zext i8 %967 to i32
  %969 = select i1 %965, i32 %968, i32 0
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true59:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false60:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true105:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false106:                                  ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true131:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false132:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

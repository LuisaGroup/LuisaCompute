
/tmp/luisa-cohort-private.qfZvpM/capture/rmsnorm-137x1023-r0-l8-p1/object/tile_xir_w8_77316_1788916371513487_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x2, lsl #12   ; =0x2000
      2c:      	sub	sp, sp, #0x3e0
      30:      	str	x0, [sp, #0x10]
      34:      	cbz	w3, 0x1c38 <ltmp0+0x1c38>
      38:      	mov	w27, #0x0               ; =0
      3c:      	add	x26, sp, #0x1, lsl #12  ; =0x1000
      40:      	add	x26, x26, #0x3e0
      44:      	ldp	w9, w8, [x2, #0x2c]
      48:      	stp	w8, w9, [sp, #0x28]
      4c:      	add	x19, sp, #0x3e0
      50:      	ldp	w8, w9, [x2]
      54:      	ldp	w10, w11, [x2, #0x8]
      58:      	str	x2, [sp, #0x8]
      5c:      	str	x11, [sp, #0x20]
      60:      	movi	d8, #0000000000000000
      64:      	movi.2s	v9, #0x3, msl #8
      68:      	str	w3, [sp, #0x30]
      6c:      	b	0xb0 <ltmp0+0xb0>
      70:      	ldr	w27, [sp, #0x34]
      74:      	add	w8, w7, #0x1
      78:      	ldp	w11, w9, [sp, #0x28]
      7c:      	cmp	w8, w9
      80:      	cset	w9, eq
      84:      	csinc	w8, wzr, w7, eq
      88:      	ldp	w13, w12, [sp, #0x38]
      8c:      	cinc	w10, w13, eq
      90:      	cmp	w10, w11
      94:      	cset	w11, eq
      98:      	ands	w11, w9, w11
      9c:      	csel	w9, wzr, w10, ne
      a0:      	add	w10, w12, w11
      a4:      	add	w27, w27, #0x1
      a8:      	cmp	w27, w3
      ac:      	b.eq	0x1c24 <ltmp0+0x1c24>
      b0:      	stp	w9, w10, [sp, #0x38]
      b4:      	mov	x13, x8
      b8:      	ubfiz	x8, x8, #5, #32
      bc:      	ldr	x12, [sp, #0x20]
      c0:      	cmp	x8, x12
      c4:      	csel	x9, x8, xzr, ls
      c8:      	subs	x10, x12, x9
      cc:      	cmp	x10, #0x20
      d0:      	mov	w11, #0x20              ; =32
      d4:      	csel	x10, x10, x11, lo
      d8:      	cmp	x12, x9
      dc:      	ccmp	x8, x12, #0x2, hi
      e0:      	csel	x9, x10, xzr, ls
      e4:      	cmp	x9, #0x20
      e8:      	str	x13, [sp, #0x40]
      ec:      	b.lo	0xc10 <ltmp0+0xc10>
      f0:      	ldr	x8, [sp, #0x10]
      f4:      	ldr	x20, [x8]
      f8:      	ldr	x22, [x8, #0x10]
      fc:      	ldr	x21, [x8, #0x30]
     100:      	ubfiz	w24, w13, #2, #27
     104:      	mov	w8, #0xffc              ; =4092
     108:      	umull	x25, w24, w8
     10c:      	umaddl	x1, w24, w8, x20
     110:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     114:      	add	x0, x0, #0x3e0
     118:      	mov	w2, #0xfe0              ; =4064
     11c:      	bl	0x11c <ltmp0+0x11c>
     120:      	mov	x8, #0x0                ; =0
     124:      	add	x23, x25, #0xfe0
     128:      	add	x9, x20, x23
     12c:      	add	x10, x9, #0x4
     130:      	add	x11, x9, #0x8
     134:      	add	x12, x9, #0xc
     138:      	add	x13, x9, #0x14
     13c:      	ldr	s0, [x9]
     140:      	ld1.s	{ v0 }[1], [x10]
     144:      	ld1.s	{ v0 }[2], [x11]
     148:      	ld1.s	{ v0 }[3], [x12]
     14c:      	add	x10, x9, #0x18
     150:      	ldr	s1, [x9, #0x10]
     154:      	ld1.s	{ v1 }[1], [x13]
     158:      	ld1.s	{ v1 }[2], [x10]
     15c:      	stp	q1, q0, [sp, #0x130]
     160:      	str	q1, [sp, #0x23d0]
     164:      	str	q0, [sp, #0x23c0]
     168:      	ldr	q0, [sp, #0x13e0]
     16c:      	ldr	q1, [sp, #0x13f0]
     170:      	fmul.4s	v16, v1, v1
     174:      	fmul.4s	v7, v0, v0
     178:      	ldr	q0, [sp, #0x1400]
     17c:      	ldr	q1, [sp, #0x1410]
     180:      	fmul.4s	v6, v1, v1
     184:      	fmul.4s	v5, v0, v0
     188:      	ldr	q0, [sp, #0x1420]
     18c:      	ldr	q1, [sp, #0x1430]
     190:      	fmul.4s	v4, v1, v1
     194:      	fmul.4s	v17, v0, v0
     198:      	ldr	q0, [sp, #0x1440]
     19c:      	ldr	q1, [sp, #0x1450]
     1a0:      	fmul.4s	v2, v1, v1
     1a4:      	fmul.4s	v3, v0, v0
     1a8:      	add	x9, x26, x8, lsl #5
     1ac:      	ldp	q1, q0, [x9, #0x80]
     1b0:      	fmul.4s	v1, v1, v1
     1b4:      	fmul.4s	v0, v0, v0
     1b8:      	fadd.4s	v16, v16, v0
     1bc:      	fadd.4s	v7, v7, v1
     1c0:      	ldp	q1, q0, [x9, #0xa0]
     1c4:      	fmul.4s	v1, v1, v1
     1c8:      	fmul.4s	v0, v0, v0
     1cc:      	fadd.4s	v6, v6, v0
     1d0:      	fadd.4s	v5, v5, v1
     1d4:      	ldp	q1, q0, [x9, #0xc0]
     1d8:      	fmul.4s	v1, v1, v1
     1dc:      	fmul.4s	v0, v0, v0
     1e0:      	fadd.4s	v4, v4, v0
     1e4:      	fadd.4s	v17, v17, v1
     1e8:      	ldp	q1, q0, [x9, #0xe0]
     1ec:      	fmul.4s	v1, v1, v1
     1f0:      	fmul.4s	v0, v0, v0
     1f4:      	fadd.4s	v2, v2, v0
     1f8:      	fadd.4s	v3, v3, v1
     1fc:      	add	x8, x8, #0x4
     200:      	cmp	x8, #0x78
     204:      	b.lo	0x1a8 <ltmp0+0x1a8>
     208:      	ldr	q1, [sp, #0x2370]
     20c:      	ldr	q0, [sp, #0x2360]
     210:      	stp	q0, q4, [sp, #0xa0]
     214:      	ldr	q4, [sp, #0x2390]
     218:      	ldr	q0, [sp, #0x2380]
     21c:      	stp	q0, q1, [sp, #0xc0]
     220:      	ldr	q0, [sp, #0x23a0]
     224:      	stp	q4, q0, [sp, #0xf0]
     228:      	ldr	q0, [sp, #0x23b0]
     22c:      	str	q0, [sp, #0xe0]
     230:      	add	x0, sp, #0x3e0
     234:      	mov	x1, x22
     238:      	mov	w2, #0xfe0              ; =4064
     23c:      	stp	q3, q2, [sp, #0x110]
     240:      	stp	q6, q5, [sp, #0x70]
     244:      	stp	q16, q7, [sp, #0x50]
     248:      	str	q17, [sp, #0x90]
     24c:      	bl	0x24c <ltmp0+0x24c>
     250:      	mov	x8, #0x0                ; =0
     254:      	ldp	q6, q0, [sp, #0x90]
     258:      	fmul.4s	v0, v0, v0
     25c:      	ldr	q1, [sp, #0xd0]
     260:      	fmul.4s	v1, v1, v1
     264:      	ldp	q3, q2, [sp, #0x50]
     268:      	fadd.4s	v1, v3, v1
     26c:      	fadd.4s	v0, v2, v0
     270:      	ldr	q2, [sp, #0xc0]
     274:      	fmul.4s	v2, v2, v2
     278:      	ldp	q3, q5, [sp, #0xf0]
     27c:      	fmul.4s	v3, v3, v3
     280:      	ldp	q7, q4, [sp, #0x70]
     284:      	fadd.4s	v3, v7, v3
     288:      	fadd.4s	v2, v4, v2
     28c:      	ldr	q4, [sp, #0xe0]
     290:      	fmul.4s	v4, v4, v4
     294:      	fmul.4s	v5, v5, v5
     298:      	fadd.4s	v5, v6, v5
     29c:      	ldr	q6, [sp, #0xb0]
     2a0:      	fadd.4s	v4, v6, v4
     2a4:      	ldp	q17, q16, [sp, #0x130]
     2a8:      	fmul.4s	v6, v17, v17
     2ac:      	fmul.4s	v7, v16, v16
     2b0:      	fadd.4s	v0, v7, v0
     2b4:      	fadd.4s	v6, v6, v1
     2b8:      	mov.s	v6[3], v1[3]
     2bc:      	fadd.4s	v0, v2, v0
     2c0:      	fadd.4s	v1, v3, v6
     2c4:      	fadd.4s	v1, v4, v1
     2c8:      	fadd.4s	v0, v5, v0
     2cc:      	ldp	q3, q2, [sp, #0x110]
     2d0:      	fadd.4s	v0, v3, v0
     2d4:      	fadd.4s	v1, v2, v1
     2d8:      	rev64.4s	v2, v1
     2dc:      	rev64.4s	v3, v0
     2e0:      	fadd.4s	v0, v0, v3
     2e4:      	fadd.4s	v1, v1, v2
     2e8:      	dup.4s	v2, v1[2]
     2ec:      	dup.4s	v3, v0[2]
     2f0:      	fadd.4s	v0, v0, v3
     2f4:      	fadd.4s	v1, v1, v2
     2f8:      	fadd.4s	v0, v0, v1
     2fc:      	fadd	s0, s0, s8
     300:      	mov	w9, #0xc000             ; =49152
     304:      	movk	w9, #0x447f, lsl #16
     308:      	fmov	s1, w9
     30c:      	fdiv	s2, s0, s1
     310:      	add	x28, x22, #0xfe0
     314:      	add	x9, x22, #0xfe4
     318:      	add	x10, x22, #0xfe8
     31c:      	add	x11, x22, #0xfec
     320:      	add	x12, x22, #0xff4
     324:      	ldr	s0, [x22, #0xfe0]
     328:      	ld1.s	{ v0 }[1], [x9]
     32c:      	add	x9, x22, #0xff8
     330:      	ld1.s	{ v0 }[2], [x10]
     334:      	ld1.s	{ v0 }[3], [x11]
     338:      	ldr	s1, [x22, #0xff0]
     33c:      	ld1.s	{ v1 }[1], [x12]
     340:      	ld1.s	{ v1 }[2], [x9]
     344:      	str	q1, [sp, #0x13d0]
     348:      	str	q0, [sp, #0x13c0]
     34c:      	mov	w9, #0xc5ac             ; =50604
     350:      	movk	w9, #0x3727, lsl #16
     354:      	fmov	s3, w9
     358:      	fadd	s2, s2, s3
     35c:      	fsqrt	s2, s2
     360:      	dup.4s	v3, v2[0]
     364:      	add	x9, x21, x25
     368:      	add	x10, x26, x8
     36c:      	ldp	q4, q5, [x10]
     370:      	fdiv.4s	v5, v5, v3
     374:      	fdiv.4s	v4, v4, v3
     378:      	add	x10, x19, x8
     37c:      	ldp	q7, q6, [x10]
     380:      	fmul.4s	v4, v4, v7
     384:      	fmul.4s	v5, v5, v6
     388:      	add	x10, x9, x8
     38c:      	stp	q4, q5, [x10]
     390:      	add	x8, x8, #0x20
     394:      	cmp	x8, #0xfe0
     398:      	b.ne	0x368 <ltmp0+0x368>
     39c:      	dup.4s	v2, v2[0]
     3a0:      	fdiv.4s	v3, v16, v2
     3a4:      	fdiv.4s	v2, v17, v2
     3a8:      	fmul.4s	v1, v1, v2
     3ac:      	fmul.4s	v0, v0, v3
     3b0:      	add	x8, x21, x23
     3b4:      	str	q0, [x8]
     3b8:      	str	d1, [x8, #0x10]
     3bc:      	add	x8, x8, #0x18
     3c0:      	st1.s	{ v1 }[2], [x8]
     3c4:      	orr	w8, w24, #0x1
     3c8:      	mov	w9, #0xffc              ; =4092
     3cc:      	umull	x25, w8, w9
     3d0:      	umaddl	x1, w8, w9, x20
     3d4:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     3d8:      	add	x0, x0, #0x3e0
     3dc:      	mov	w2, #0xfe0              ; =4064
     3e0:      	bl	0x3e0 <ltmp0+0x3e0>
     3e4:      	mov	x8, #0x0                ; =0
     3e8:      	add	x23, x25, #0xfe0
     3ec:      	add	x9, x20, x23
     3f0:      	add	x10, x9, #0x4
     3f4:      	add	x11, x9, #0x8
     3f8:      	add	x12, x9, #0xc
     3fc:      	add	x13, x9, #0x14
     400:      	ldr	s0, [x9]
     404:      	ld1.s	{ v0 }[1], [x10]
     408:      	ld1.s	{ v0 }[2], [x11]
     40c:      	ld1.s	{ v0 }[3], [x12]
     410:      	add	x10, x9, #0x18
     414:      	ldr	s1, [x9, #0x10]
     418:      	ld1.s	{ v1 }[1], [x13]
     41c:      	ld1.s	{ v1 }[2], [x10]
     420:      	stp	q1, q0, [sp, #0x130]
     424:      	str	q1, [sp, #0x23d0]
     428:      	str	q0, [sp, #0x23c0]
     42c:      	ldr	q0, [sp, #0x13e0]
     430:      	ldr	q1, [sp, #0x13f0]
     434:      	fmul.4s	v16, v1, v1
     438:      	fmul.4s	v7, v0, v0
     43c:      	ldr	q0, [sp, #0x1400]
     440:      	ldr	q1, [sp, #0x1410]
     444:      	fmul.4s	v6, v1, v1
     448:      	fmul.4s	v5, v0, v0
     44c:      	ldr	q0, [sp, #0x1420]
     450:      	ldr	q1, [sp, #0x1430]
     454:      	fmul.4s	v4, v1, v1
     458:      	fmul.4s	v17, v0, v0
     45c:      	ldr	q0, [sp, #0x1440]
     460:      	ldr	q1, [sp, #0x1450]
     464:      	fmul.4s	v2, v1, v1
     468:      	fmul.4s	v3, v0, v0
     46c:      	add	x9, x26, x8, lsl #5
     470:      	ldp	q1, q0, [x9, #0x80]
     474:      	fmul.4s	v1, v1, v1
     478:      	fmul.4s	v0, v0, v0
     47c:      	fadd.4s	v16, v16, v0
     480:      	fadd.4s	v7, v7, v1
     484:      	ldp	q1, q0, [x9, #0xa0]
     488:      	fmul.4s	v1, v1, v1
     48c:      	fmul.4s	v0, v0, v0
     490:      	fadd.4s	v6, v6, v0
     494:      	fadd.4s	v5, v5, v1
     498:      	ldp	q1, q0, [x9, #0xc0]
     49c:      	fmul.4s	v1, v1, v1
     4a0:      	fmul.4s	v0, v0, v0
     4a4:      	fadd.4s	v4, v4, v0
     4a8:      	fadd.4s	v17, v17, v1
     4ac:      	ldp	q1, q0, [x9, #0xe0]
     4b0:      	fmul.4s	v1, v1, v1
     4b4:      	fmul.4s	v0, v0, v0
     4b8:      	fadd.4s	v2, v2, v0
     4bc:      	fadd.4s	v3, v3, v1
     4c0:      	add	x8, x8, #0x4
     4c4:      	cmp	x8, #0x78
     4c8:      	b.lo	0x46c <ltmp0+0x46c>
     4cc:      	ldr	q1, [sp, #0x2370]
     4d0:      	ldr	q0, [sp, #0x2360]
     4d4:      	stp	q0, q4, [sp, #0xa0]
     4d8:      	ldr	q4, [sp, #0x2390]
     4dc:      	ldr	q0, [sp, #0x2380]
     4e0:      	stp	q0, q1, [sp, #0xc0]
     4e4:      	ldr	q0, [sp, #0x23a0]
     4e8:      	stp	q4, q0, [sp, #0xf0]
     4ec:      	ldr	q0, [sp, #0x23b0]
     4f0:      	str	q0, [sp, #0xe0]
     4f4:      	add	x0, sp, #0x3e0
     4f8:      	mov	x1, x22
     4fc:      	mov	w2, #0xfe0              ; =4064
     500:      	stp	q3, q2, [sp, #0x110]
     504:      	stp	q6, q5, [sp, #0x70]
     508:      	stp	q16, q7, [sp, #0x50]
     50c:      	str	q17, [sp, #0x90]
     510:      	bl	0x510 <ltmp0+0x510>
     514:      	mov	x8, #0x0                ; =0
     518:      	ldp	q6, q0, [sp, #0x90]
     51c:      	fmul.4s	v0, v0, v0
     520:      	ldr	q1, [sp, #0xd0]
     524:      	fmul.4s	v1, v1, v1
     528:      	ldp	q3, q2, [sp, #0x50]
     52c:      	fadd.4s	v1, v3, v1
     530:      	fadd.4s	v0, v2, v0
     534:      	ldr	q2, [sp, #0xc0]
     538:      	fmul.4s	v2, v2, v2
     53c:      	ldp	q3, q5, [sp, #0xf0]
     540:      	fmul.4s	v3, v3, v3
     544:      	ldp	q7, q4, [sp, #0x70]
     548:      	fadd.4s	v3, v7, v3
     54c:      	fadd.4s	v2, v4, v2
     550:      	ldr	q4, [sp, #0xe0]
     554:      	fmul.4s	v4, v4, v4
     558:      	fmul.4s	v5, v5, v5
     55c:      	fadd.4s	v5, v6, v5
     560:      	ldr	q6, [sp, #0xb0]
     564:      	fadd.4s	v4, v6, v4
     568:      	ldp	q17, q16, [sp, #0x130]
     56c:      	fmul.4s	v6, v17, v17
     570:      	fmul.4s	v7, v16, v16
     574:      	fadd.4s	v0, v7, v0
     578:      	fadd.4s	v6, v6, v1
     57c:      	mov.s	v6[3], v1[3]
     580:      	fadd.4s	v0, v2, v0
     584:      	fadd.4s	v1, v3, v6
     588:      	fadd.4s	v1, v4, v1
     58c:      	fadd.4s	v0, v5, v0
     590:      	ldp	q3, q2, [sp, #0x110]
     594:      	fadd.4s	v0, v3, v0
     598:      	fadd.4s	v1, v2, v1
     59c:      	rev64.4s	v2, v1
     5a0:      	rev64.4s	v3, v0
     5a4:      	fadd.4s	v0, v0, v3
     5a8:      	fadd.4s	v1, v1, v2
     5ac:      	dup.4s	v2, v1[2]
     5b0:      	dup.4s	v3, v0[2]
     5b4:      	fadd.4s	v0, v0, v3
     5b8:      	fadd.4s	v1, v1, v2
     5bc:      	fadd.4s	v0, v0, v1
     5c0:      	fadd	s0, s0, s8
     5c4:      	mov	w9, #0xc000             ; =49152
     5c8:      	movk	w9, #0x447f, lsl #16
     5cc:      	fmov	s1, w9
     5d0:      	fdiv	s2, s0, s1
     5d4:      	add	x9, x22, #0xfe4
     5d8:      	add	x10, x22, #0xfe8
     5dc:      	add	x11, x22, #0xfec
     5e0:      	add	x12, x22, #0xff4
     5e4:      	ldr	s0, [x28]
     5e8:      	ld1.s	{ v0 }[1], [x9]
     5ec:      	add	x9, x22, #0xff8
     5f0:      	ld1.s	{ v0 }[2], [x10]
     5f4:      	ld1.s	{ v0 }[3], [x11]
     5f8:      	ldr	s1, [x22, #0xff0]
     5fc:      	ld1.s	{ v1 }[1], [x12]
     600:      	ld1.s	{ v1 }[2], [x9]
     604:      	str	q1, [sp, #0x13d0]
     608:      	str	q0, [sp, #0x13c0]
     60c:      	mov	w9, #0xc5ac             ; =50604
     610:      	movk	w9, #0x3727, lsl #16
     614:      	fmov	s3, w9
     618:      	fadd	s2, s2, s3
     61c:      	fsqrt	s2, s2
     620:      	dup.4s	v3, v2[0]
     624:      	add	x9, x21, x25
     628:      	add	x10, x26, x8
     62c:      	ldp	q4, q5, [x10]
     630:      	fdiv.4s	v5, v5, v3
     634:      	fdiv.4s	v4, v4, v3
     638:      	add	x10, x19, x8
     63c:      	ldp	q7, q6, [x10]
     640:      	fmul.4s	v4, v4, v7
     644:      	fmul.4s	v5, v5, v6
     648:      	add	x10, x9, x8
     64c:      	stp	q4, q5, [x10]
     650:      	add	x8, x8, #0x20
     654:      	cmp	x8, #0xfe0
     658:      	b.ne	0x628 <ltmp0+0x628>
     65c:      	dup.4s	v2, v2[0]
     660:      	fdiv.4s	v3, v16, v2
     664:      	fdiv.4s	v2, v17, v2
     668:      	fmul.4s	v1, v1, v2
     66c:      	fmul.4s	v0, v0, v3
     670:      	add	x8, x21, x23
     674:      	str	q0, [x8]
     678:      	str	d1, [x8, #0x10]
     67c:      	add	x8, x8, #0x18
     680:      	st1.s	{ v1 }[2], [x8]
     684:      	orr	w8, w24, #0x2
     688:      	mov	w9, #0xffc              ; =4092
     68c:      	umull	x25, w8, w9
     690:      	umaddl	x1, w8, w9, x20
     694:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     698:      	add	x0, x0, #0x3e0
     69c:      	mov	w2, #0xfe0              ; =4064
     6a0:      	bl	0x6a0 <ltmp0+0x6a0>
     6a4:      	mov	x8, #0x0                ; =0
     6a8:      	add	x23, x25, #0xfe0
     6ac:      	add	x9, x20, x23
     6b0:      	add	x10, x9, #0x4
     6b4:      	add	x11, x9, #0x8
     6b8:      	add	x12, x9, #0xc
     6bc:      	add	x13, x9, #0x14
     6c0:      	ldr	s0, [x9]
     6c4:      	ld1.s	{ v0 }[1], [x10]
     6c8:      	ld1.s	{ v0 }[2], [x11]
     6cc:      	ld1.s	{ v0 }[3], [x12]
     6d0:      	add	x10, x9, #0x18
     6d4:      	ldr	s1, [x9, #0x10]
     6d8:      	ld1.s	{ v1 }[1], [x13]
     6dc:      	ld1.s	{ v1 }[2], [x10]
     6e0:      	stp	q1, q0, [sp, #0x130]
     6e4:      	str	q1, [sp, #0x23d0]
     6e8:      	str	q0, [sp, #0x23c0]
     6ec:      	ldr	q0, [sp, #0x13e0]
     6f0:      	ldr	q1, [sp, #0x13f0]
     6f4:      	fmul.4s	v16, v1, v1
     6f8:      	fmul.4s	v7, v0, v0
     6fc:      	ldr	q0, [sp, #0x1400]
     700:      	ldr	q1, [sp, #0x1410]
     704:      	fmul.4s	v6, v1, v1
     708:      	fmul.4s	v5, v0, v0
     70c:      	ldr	q0, [sp, #0x1420]
     710:      	ldr	q1, [sp, #0x1430]
     714:      	fmul.4s	v4, v1, v1
     718:      	fmul.4s	v17, v0, v0
     71c:      	ldr	q0, [sp, #0x1440]
     720:      	ldr	q1, [sp, #0x1450]
     724:      	fmul.4s	v2, v1, v1
     728:      	fmul.4s	v3, v0, v0
     72c:      	add	x9, x26, x8, lsl #5
     730:      	ldp	q1, q0, [x9, #0x80]
     734:      	fmul.4s	v1, v1, v1
     738:      	fmul.4s	v0, v0, v0
     73c:      	fadd.4s	v16, v16, v0
     740:      	fadd.4s	v7, v7, v1
     744:      	ldp	q1, q0, [x9, #0xa0]
     748:      	fmul.4s	v1, v1, v1
     74c:      	fmul.4s	v0, v0, v0
     750:      	fadd.4s	v6, v6, v0
     754:      	fadd.4s	v5, v5, v1
     758:      	ldp	q1, q0, [x9, #0xc0]
     75c:      	fmul.4s	v1, v1, v1
     760:      	fmul.4s	v0, v0, v0
     764:      	fadd.4s	v4, v4, v0
     768:      	fadd.4s	v17, v17, v1
     76c:      	ldp	q1, q0, [x9, #0xe0]
     770:      	fmul.4s	v1, v1, v1
     774:      	fmul.4s	v0, v0, v0
     778:      	fadd.4s	v2, v2, v0
     77c:      	fadd.4s	v3, v3, v1
     780:      	add	x8, x8, #0x4
     784:      	cmp	x8, #0x78
     788:      	b.lo	0x72c <ltmp0+0x72c>
     78c:      	ldr	q1, [sp, #0x2370]
     790:      	ldr	q0, [sp, #0x2360]
     794:      	stp	q0, q4, [sp, #0xa0]
     798:      	ldr	q4, [sp, #0x2390]
     79c:      	ldr	q0, [sp, #0x2380]
     7a0:      	stp	q0, q1, [sp, #0xc0]
     7a4:      	ldr	q0, [sp, #0x23a0]
     7a8:      	stp	q4, q0, [sp, #0xf0]
     7ac:      	ldr	q0, [sp, #0x23b0]
     7b0:      	str	q0, [sp, #0xe0]
     7b4:      	add	x0, sp, #0x3e0
     7b8:      	mov	x1, x22
     7bc:      	mov	w2, #0xfe0              ; =4064
     7c0:      	stp	q3, q2, [sp, #0x110]
     7c4:      	stp	q6, q5, [sp, #0x70]
     7c8:      	stp	q16, q7, [sp, #0x50]
     7cc:      	str	q17, [sp, #0x90]
     7d0:      	bl	0x7d0 <ltmp0+0x7d0>
     7d4:      	mov	x8, #0x0                ; =0
     7d8:      	ldp	q6, q0, [sp, #0x90]
     7dc:      	fmul.4s	v0, v0, v0
     7e0:      	ldr	q1, [sp, #0xd0]
     7e4:      	fmul.4s	v1, v1, v1
     7e8:      	ldp	q3, q2, [sp, #0x50]
     7ec:      	fadd.4s	v1, v3, v1
     7f0:      	fadd.4s	v0, v2, v0
     7f4:      	ldr	q2, [sp, #0xc0]
     7f8:      	fmul.4s	v2, v2, v2
     7fc:      	ldp	q3, q5, [sp, #0xf0]
     800:      	fmul.4s	v3, v3, v3
     804:      	ldp	q7, q4, [sp, #0x70]
     808:      	fadd.4s	v3, v7, v3
     80c:      	fadd.4s	v2, v4, v2
     810:      	ldr	q4, [sp, #0xe0]
     814:      	fmul.4s	v4, v4, v4
     818:      	fmul.4s	v5, v5, v5
     81c:      	fadd.4s	v5, v6, v5
     820:      	ldr	q6, [sp, #0xb0]
     824:      	fadd.4s	v4, v6, v4
     828:      	ldp	q17, q16, [sp, #0x130]
     82c:      	fmul.4s	v6, v17, v17
     830:      	fmul.4s	v7, v16, v16
     834:      	fadd.4s	v0, v7, v0
     838:      	fadd.4s	v6, v6, v1
     83c:      	mov.s	v6[3], v1[3]
     840:      	fadd.4s	v0, v2, v0
     844:      	fadd.4s	v1, v3, v6
     848:      	fadd.4s	v1, v4, v1
     84c:      	fadd.4s	v0, v5, v0
     850:      	ldp	q3, q2, [sp, #0x110]
     854:      	fadd.4s	v0, v3, v0
     858:      	fadd.4s	v1, v2, v1
     85c:      	rev64.4s	v2, v1
     860:      	rev64.4s	v3, v0
     864:      	fadd.4s	v0, v0, v3
     868:      	fadd.4s	v1, v1, v2
     86c:      	dup.4s	v2, v1[2]
     870:      	dup.4s	v3, v0[2]
     874:      	fadd.4s	v0, v0, v3
     878:      	fadd.4s	v1, v1, v2
     87c:      	fadd.4s	v0, v0, v1
     880:      	fadd	s0, s0, s8
     884:      	mov	w9, #0xc000             ; =49152
     888:      	movk	w9, #0x447f, lsl #16
     88c:      	fmov	s1, w9
     890:      	fdiv	s2, s0, s1
     894:      	add	x9, x22, #0xfe4
     898:      	add	x10, x22, #0xfe8
     89c:      	add	x11, x22, #0xfec
     8a0:      	add	x12, x22, #0xff4
     8a4:      	ldr	s0, [x28]
     8a8:      	ld1.s	{ v0 }[1], [x9]
     8ac:      	add	x9, x22, #0xff8
     8b0:      	ld1.s	{ v0 }[2], [x10]
     8b4:      	ld1.s	{ v0 }[3], [x11]
     8b8:      	ldr	s1, [x22, #0xff0]
     8bc:      	ld1.s	{ v1 }[1], [x12]
     8c0:      	ld1.s	{ v1 }[2], [x9]
     8c4:      	str	q1, [sp, #0x13d0]
     8c8:      	str	q0, [sp, #0x13c0]
     8cc:      	mov	w9, #0xc5ac             ; =50604
     8d0:      	movk	w9, #0x3727, lsl #16
     8d4:      	fmov	s3, w9
     8d8:      	fadd	s2, s2, s3
     8dc:      	fsqrt	s2, s2
     8e0:      	dup.4s	v3, v2[0]
     8e4:      	add	x9, x21, x25
     8e8:      	add	x10, x26, x8
     8ec:      	ldp	q4, q5, [x10]
     8f0:      	fdiv.4s	v5, v5, v3
     8f4:      	fdiv.4s	v4, v4, v3
     8f8:      	add	x10, x19, x8
     8fc:      	ldp	q7, q6, [x10]
     900:      	fmul.4s	v4, v4, v7
     904:      	fmul.4s	v5, v5, v6
     908:      	add	x10, x9, x8
     90c:      	stp	q4, q5, [x10]
     910:      	add	x8, x8, #0x20
     914:      	cmp	x8, #0xfe0
     918:      	b.ne	0x8e8 <ltmp0+0x8e8>
     91c:      	dup.4s	v2, v2[0]
     920:      	fdiv.4s	v3, v16, v2
     924:      	fdiv.4s	v2, v17, v2
     928:      	fmul.4s	v1, v1, v2
     92c:      	fmul.4s	v0, v0, v3
     930:      	add	x8, x21, x23
     934:      	str	q0, [x8]
     938:      	str	d1, [x8, #0x10]
     93c:      	add	x8, x8, #0x18
     940:      	st1.s	{ v1 }[2], [x8]
     944:      	orr	w8, w24, #0x3
     948:      	mov	w9, #0xffc              ; =4092
     94c:      	umull	x24, w8, w9
     950:      	umaddl	x1, w8, w9, x20
     954:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     958:      	add	x0, x0, #0x3e0
     95c:      	mov	w2, #0xfe0              ; =4064
     960:      	bl	0x960 <ltmp0+0x960>
     964:      	mov	x8, #0x0                ; =0
     968:      	add	x23, x24, #0xfe0
     96c:      	add	x9, x20, x23
     970:      	add	x10, x9, #0x4
     974:      	add	x11, x9, #0x8
     978:      	add	x12, x9, #0xc
     97c:      	add	x13, x9, #0x14
     980:      	ldr	s0, [x9]
     984:      	ld1.s	{ v0 }[1], [x10]
     988:      	ld1.s	{ v0 }[2], [x11]
     98c:      	ld1.s	{ v0 }[3], [x12]
     990:      	add	x10, x9, #0x18
     994:      	ldr	s1, [x9, #0x10]
     998:      	ld1.s	{ v1 }[1], [x13]
     99c:      	ld1.s	{ v1 }[2], [x10]
     9a0:      	stp	q1, q0, [sp, #0x130]
     9a4:      	str	q1, [sp, #0x23d0]
     9a8:      	str	q0, [sp, #0x23c0]
     9ac:      	ldr	q0, [sp, #0x13e0]
     9b0:      	ldr	q1, [sp, #0x13f0]
     9b4:      	fmul.4s	v16, v1, v1
     9b8:      	fmul.4s	v7, v0, v0
     9bc:      	ldr	q0, [sp, #0x1400]
     9c0:      	ldr	q1, [sp, #0x1410]
     9c4:      	fmul.4s	v6, v1, v1
     9c8:      	fmul.4s	v5, v0, v0
     9cc:      	ldr	q0, [sp, #0x1420]
     9d0:      	ldr	q1, [sp, #0x1430]
     9d4:      	fmul.4s	v4, v1, v1
     9d8:      	fmul.4s	v17, v0, v0
     9dc:      	ldr	q0, [sp, #0x1440]
     9e0:      	ldr	q1, [sp, #0x1450]
     9e4:      	fmul.4s	v2, v1, v1
     9e8:      	fmul.4s	v3, v0, v0
     9ec:      	add	x9, x26, x8, lsl #5
     9f0:      	ldp	q1, q0, [x9, #0x80]
     9f4:      	fmul.4s	v1, v1, v1
     9f8:      	fmul.4s	v0, v0, v0
     9fc:      	fadd.4s	v16, v16, v0
     a00:      	fadd.4s	v7, v7, v1
     a04:      	ldp	q1, q0, [x9, #0xa0]
     a08:      	fmul.4s	v1, v1, v1
     a0c:      	fmul.4s	v0, v0, v0
     a10:      	fadd.4s	v6, v6, v0
     a14:      	fadd.4s	v5, v5, v1
     a18:      	ldp	q1, q0, [x9, #0xc0]
     a1c:      	fmul.4s	v1, v1, v1
     a20:      	fmul.4s	v0, v0, v0
     a24:      	fadd.4s	v4, v4, v0
     a28:      	fadd.4s	v17, v17, v1
     a2c:      	ldp	q1, q0, [x9, #0xe0]
     a30:      	fmul.4s	v1, v1, v1
     a34:      	fmul.4s	v0, v0, v0
     a38:      	fadd.4s	v2, v2, v0
     a3c:      	fadd.4s	v3, v3, v1
     a40:      	add	x8, x8, #0x4
     a44:      	cmp	x8, #0x78
     a48:      	b.lo	0x9ec <ltmp0+0x9ec>
     a4c:      	ldr	q1, [sp, #0x2370]
     a50:      	ldr	q0, [sp, #0x2360]
     a54:      	stp	q0, q4, [sp, #0xa0]
     a58:      	ldr	q4, [sp, #0x2390]
     a5c:      	ldr	q0, [sp, #0x2380]
     a60:      	stp	q0, q1, [sp, #0xc0]
     a64:      	ldr	q0, [sp, #0x23a0]
     a68:      	stp	q4, q0, [sp, #0xf0]
     a6c:      	ldr	q0, [sp, #0x23b0]
     a70:      	str	q0, [sp, #0xe0]
     a74:      	add	x0, sp, #0x3e0
     a78:      	mov	x1, x22
     a7c:      	mov	w2, #0xfe0              ; =4064
     a80:      	stp	q3, q2, [sp, #0x110]
     a84:      	stp	q6, q5, [sp, #0x70]
     a88:      	stp	q16, q7, [sp, #0x50]
     a8c:      	str	q17, [sp, #0x90]
     a90:      	bl	0xa90 <ltmp0+0xa90>
     a94:      	mov	x8, #0x0                ; =0
     a98:      	ldp	q6, q0, [sp, #0x90]
     a9c:      	fmul.4s	v0, v0, v0
     aa0:      	ldr	q1, [sp, #0xd0]
     aa4:      	fmul.4s	v1, v1, v1
     aa8:      	ldp	q3, q2, [sp, #0x50]
     aac:      	fadd.4s	v1, v3, v1
     ab0:      	fadd.4s	v0, v2, v0
     ab4:      	ldr	q2, [sp, #0xc0]
     ab8:      	fmul.4s	v2, v2, v2
     abc:      	ldp	q3, q5, [sp, #0xf0]
     ac0:      	fmul.4s	v3, v3, v3
     ac4:      	ldp	q7, q4, [sp, #0x70]
     ac8:      	fadd.4s	v3, v7, v3
     acc:      	fadd.4s	v2, v4, v2
     ad0:      	ldr	q4, [sp, #0xe0]
     ad4:      	fmul.4s	v4, v4, v4
     ad8:      	fmul.4s	v5, v5, v5
     adc:      	fadd.4s	v5, v6, v5
     ae0:      	ldr	q6, [sp, #0xb0]
     ae4:      	fadd.4s	v4, v6, v4
     ae8:      	ldp	q17, q16, [sp, #0x130]
     aec:      	fmul.4s	v6, v17, v17
     af0:      	fmul.4s	v7, v16, v16
     af4:      	fadd.4s	v0, v7, v0
     af8:      	fadd.4s	v6, v6, v1
     afc:      	mov.s	v6[3], v1[3]
     b00:      	fadd.4s	v0, v2, v0
     b04:      	fadd.4s	v1, v3, v6
     b08:      	fadd.4s	v1, v4, v1
     b0c:      	fadd.4s	v0, v5, v0
     b10:      	ldp	q3, q2, [sp, #0x110]
     b14:      	fadd.4s	v0, v3, v0
     b18:      	fadd.4s	v1, v2, v1
     b1c:      	rev64.4s	v2, v1
     b20:      	rev64.4s	v3, v0
     b24:      	fadd.4s	v0, v0, v3
     b28:      	fadd.4s	v1, v1, v2
     b2c:      	dup.4s	v2, v1[2]
     b30:      	dup.4s	v3, v0[2]
     b34:      	fadd.4s	v0, v0, v3
     b38:      	fadd.4s	v1, v1, v2
     b3c:      	fadd.4s	v0, v0, v1
     b40:      	fadd	s0, s0, s8
     b44:      	mov	w9, #0xc000             ; =49152
     b48:      	movk	w9, #0x447f, lsl #16
     b4c:      	fmov	s1, w9
     b50:      	fdiv	s2, s0, s1
     b54:      	add	x9, x22, #0xfe4
     b58:      	add	x10, x22, #0xfe8
     b5c:      	add	x11, x22, #0xfec
     b60:      	add	x12, x22, #0xff4
     b64:      	ldr	s0, [x28]
     b68:      	ld1.s	{ v0 }[1], [x9]
     b6c:      	add	x9, x22, #0xff8
     b70:      	ld1.s	{ v0 }[2], [x10]
     b74:      	ld1.s	{ v0 }[3], [x11]
     b78:      	ldr	s1, [x22, #0xff0]
     b7c:      	ld1.s	{ v1 }[1], [x12]
     b80:      	ld1.s	{ v1 }[2], [x9]
     b84:      	str	q1, [sp, #0x13d0]
     b88:      	str	q0, [sp, #0x13c0]
     b8c:      	mov	w9, #0xc5ac             ; =50604
     b90:      	movk	w9, #0x3727, lsl #16
     b94:      	fmov	s3, w9
     b98:      	fadd	s2, s2, s3
     b9c:      	fsqrt	s2, s2
     ba0:      	dup.4s	v3, v2[0]
     ba4:      	add	x9, x21, x24
     ba8:      	ldr	w3, [sp, #0x30]
     bac:      	add	x10, x26, x8
     bb0:      	ldp	q4, q5, [x10]
     bb4:      	fdiv.4s	v5, v5, v3
     bb8:      	fdiv.4s	v4, v4, v3
     bbc:      	add	x10, x19, x8
     bc0:      	ldp	q7, q6, [x10]
     bc4:      	fmul.4s	v4, v4, v7
     bc8:      	fmul.4s	v5, v5, v6
     bcc:      	add	x10, x9, x8
     bd0:      	stp	q4, q5, [x10]
     bd4:      	add	x8, x8, #0x20
     bd8:      	cmp	x8, #0xfe0
     bdc:      	b.ne	0xbac <ltmp0+0xbac>
     be0:      	dup.4s	v2, v2[0]
     be4:      	fdiv.4s	v3, v16, v2
     be8:      	fdiv.4s	v2, v17, v2
     bec:      	fmul.4s	v1, v1, v2
     bf0:      	fmul.4s	v0, v0, v3
     bf4:      	add	x8, x21, x23
     bf8:      	str	q0, [x8]
     bfc:      	str	d1, [x8, #0x10]
     c00:      	add	x8, x8, #0x18
     c04:      	st1.s	{ v1 }[2], [x8]
     c08:      	ldr	x7, [sp, #0x40]
     c0c:      	b	0x74 <ltmp0+0x74>
     c10:      	str	w27, [sp, #0x34]
     c14:      	lsr	x8, x9, #3
     c18:      	str	x8, [sp, #0x48]
     c1c:      	str	x9, [sp, #0x18]
     c20:      	cmp	x9, #0x8
     c24:      	b.lo	0xf28 <ltmp0+0xf28>
     c28:      	mov	x24, #0x0               ; =0
     c2c:      	ldr	x8, [sp, #0x10]
     c30:      	ldr	x28, [x8]
     c34:      	ldr	x22, [x8, #0x10]
     c38:      	ldr	x27, [x8, #0x30]
     c3c:      	add	x25, x22, #0xfe0
     c40:      	ldr	x8, [sp, #0x40]
     c44:      	lsl	w23, w8, #2
     c48:      	and	x8, x8, #0x7ffffff
     c4c:      	mov	w9, #0x3ff0             ; =16368
     c50:      	umaddl	x21, w8, w9, x27
     c54:      	add	w8, w24, w23
     c58:      	and	x8, x8, #0x1fffffff
     c5c:      	lsl	x9, x8, #12
     c60:      	sub	x20, x9, x8, lsl #2
     c64:      	add	x0, sp, #0x1, lsl #12   ; =0x1000
     c68:      	add	x0, x0, #0x3e0
     c6c:      	add	x1, x28, x20
     c70:      	mov	w2, #0xfe0              ; =4064
     c74:      	bl	0xc74 <ltmp0+0xc74>
     c78:      	mov	x8, #0x0                ; =0
     c7c:      	add	x20, x20, #0xfe0
     c80:      	add	x9, x28, x20
     c84:      	add	x10, x9, #0x4
     c88:      	add	x11, x9, #0x8
     c8c:      	add	x12, x9, #0xc
     c90:      	add	x13, x9, #0x14
     c94:      	ldr	s0, [x9]
     c98:      	ld1.s	{ v0 }[1], [x10]
     c9c:      	ld1.s	{ v0 }[2], [x11]
     ca0:      	ld1.s	{ v0 }[3], [x12]
     ca4:      	add	x10, x9, #0x18
     ca8:      	ldr	s1, [x9, #0x10]
     cac:      	ld1.s	{ v1 }[1], [x13]
     cb0:      	ld1.s	{ v1 }[2], [x10]
     cb4:      	stp	q1, q0, [sp, #0x130]
     cb8:      	str	q1, [sp, #0x23d0]
     cbc:      	str	q0, [sp, #0x23c0]
     cc0:      	ldr	q0, [sp, #0x13e0]
     cc4:      	ldr	q1, [sp, #0x13f0]
     cc8:      	fmul.4s	v16, v1, v1
     ccc:      	fmul.4s	v7, v0, v0
     cd0:      	ldr	q0, [sp, #0x1400]
     cd4:      	ldr	q1, [sp, #0x1410]
     cd8:      	fmul.4s	v6, v1, v1
     cdc:      	fmul.4s	v5, v0, v0
     ce0:      	ldr	q0, [sp, #0x1420]
     ce4:      	ldr	q1, [sp, #0x1430]
     ce8:      	fmul.4s	v4, v1, v1
     cec:      	fmul.4s	v17, v0, v0
     cf0:      	ldr	q0, [sp, #0x1440]
     cf4:      	ldr	q1, [sp, #0x1450]
     cf8:      	fmul.4s	v2, v1, v1
     cfc:      	fmul.4s	v3, v0, v0
     d00:      	add	x9, x26, x8, lsl #5
     d04:      	ldp	q1, q0, [x9, #0x80]
     d08:      	fmul.4s	v1, v1, v1
     d0c:      	fmul.4s	v0, v0, v0
     d10:      	fadd.4s	v16, v16, v0
     d14:      	fadd.4s	v7, v7, v1
     d18:      	ldp	q1, q0, [x9, #0xa0]
     d1c:      	fmul.4s	v1, v1, v1
     d20:      	fmul.4s	v0, v0, v0
     d24:      	fadd.4s	v6, v6, v0
     d28:      	fadd.4s	v5, v5, v1
     d2c:      	ldp	q1, q0, [x9, #0xc0]
     d30:      	fmul.4s	v1, v1, v1
     d34:      	fmul.4s	v0, v0, v0
     d38:      	fadd.4s	v4, v4, v0
     d3c:      	fadd.4s	v17, v17, v1
     d40:      	ldp	q1, q0, [x9, #0xe0]
     d44:      	fmul.4s	v1, v1, v1
     d48:      	fmul.4s	v0, v0, v0
     d4c:      	fadd.4s	v2, v2, v0
     d50:      	fadd.4s	v3, v3, v1
     d54:      	add	x8, x8, #0x4
     d58:      	cmp	x8, #0x78
     d5c:      	b.lo	0xd00 <ltmp0+0xd00>
     d60:      	ldr	q1, [sp, #0x2370]
     d64:      	ldr	q0, [sp, #0x2360]
     d68:      	stp	q0, q4, [sp, #0xa0]
     d6c:      	ldr	q4, [sp, #0x2390]
     d70:      	ldr	q0, [sp, #0x2380]
     d74:      	stp	q0, q1, [sp, #0xc0]
     d78:      	ldr	q0, [sp, #0x23a0]
     d7c:      	stp	q4, q0, [sp, #0xf0]
     d80:      	ldr	q0, [sp, #0x23b0]
     d84:      	str	q0, [sp, #0xe0]
     d88:      	add	x0, sp, #0x3e0
     d8c:      	mov	x1, x22
     d90:      	mov	w2, #0xfe0              ; =4064
     d94:      	stp	q3, q2, [sp, #0x110]
     d98:      	stp	q6, q5, [sp, #0x70]
     d9c:      	stp	q16, q7, [sp, #0x50]
     da0:      	str	q17, [sp, #0x90]
     da4:      	bl	0xda4 <ltmp0+0xda4>
     da8:      	mov	x8, #0x0                ; =0
     dac:      	ldp	q6, q0, [sp, #0x90]
     db0:      	fmul.4s	v0, v0, v0
     db4:      	ldr	q1, [sp, #0xd0]
     db8:      	fmul.4s	v1, v1, v1
     dbc:      	ldp	q3, q2, [sp, #0x50]
     dc0:      	fadd.4s	v1, v3, v1
     dc4:      	fadd.4s	v0, v2, v0
     dc8:      	ldr	q2, [sp, #0xc0]
     dcc:      	fmul.4s	v2, v2, v2
     dd0:      	ldp	q3, q5, [sp, #0xf0]
     dd4:      	fmul.4s	v3, v3, v3
     dd8:      	ldp	q7, q4, [sp, #0x70]
     ddc:      	fadd.4s	v3, v7, v3
     de0:      	fadd.4s	v2, v4, v2
     de4:      	ldr	q4, [sp, #0xe0]
     de8:      	fmul.4s	v4, v4, v4
     dec:      	fmul.4s	v5, v5, v5
     df0:      	fadd.4s	v5, v6, v5
     df4:      	ldr	q6, [sp, #0xb0]
     df8:      	fadd.4s	v4, v6, v4
     dfc:      	ldp	q17, q16, [sp, #0x130]
     e00:      	fmul.4s	v6, v17, v17
     e04:      	fmul.4s	v7, v16, v16
     e08:      	fadd.4s	v0, v7, v0
     e0c:      	fadd.4s	v6, v6, v1
     e10:      	mov.s	v6[3], v1[3]
     e14:      	fadd.4s	v0, v2, v0
     e18:      	fadd.4s	v1, v3, v6
     e1c:      	fadd.4s	v1, v4, v1
     e20:      	fadd.4s	v0, v5, v0
     e24:      	ldp	q3, q2, [sp, #0x110]
     e28:      	fadd.4s	v0, v3, v0
     e2c:      	fadd.4s	v1, v2, v1
     e30:      	rev64.4s	v2, v1
     e34:      	rev64.4s	v3, v0
     e38:      	fadd.4s	v0, v0, v3
     e3c:      	fadd.4s	v1, v1, v2
     e40:      	dup.4s	v2, v1[2]
     e44:      	dup.4s	v3, v0[2]
     e48:      	fadd.4s	v0, v0, v3
     e4c:      	fadd.4s	v1, v1, v2
     e50:      	fadd.4s	v0, v0, v1
     e54:      	fadd	s0, s0, s8
     e58:      	mov	w9, #0xc000             ; =49152
     e5c:      	movk	w9, #0x447f, lsl #16
     e60:      	fmov	s1, w9
     e64:      	fdiv	s2, s0, s1
     e68:      	add	x9, x22, #0xfe4
     e6c:      	add	x10, x22, #0xfe8
     e70:      	add	x11, x22, #0xfec
     e74:      	ldr	s0, [x25]
     e78:      	ld1.s	{ v0 }[1], [x9]
     e7c:      	add	x9, x22, #0xff4
     e80:      	add	x12, x22, #0xff8
     e84:      	ld1.s	{ v0 }[2], [x10]
     e88:      	ld1.s	{ v0 }[3], [x11]
     e8c:      	ldr	s1, [x22, #0xff0]
     e90:      	ld1.s	{ v1 }[1], [x9]
     e94:      	ld1.s	{ v1 }[2], [x12]
     e98:      	str	q1, [sp, #0x13d0]
     e9c:      	str	q0, [sp, #0x13c0]
     ea0:      	mov	w9, #0xc5ac             ; =50604
     ea4:      	movk	w9, #0x3727, lsl #16
     ea8:      	fmov	s3, w9
     eac:      	fadd	s2, s2, s3
     eb0:      	fsqrt	s2, s2
     eb4:      	dup.4s	v3, v2[0]
     eb8:      	add	x9, x26, x8
     ebc:      	ldp	q4, q5, [x9]
     ec0:      	fdiv.4s	v5, v5, v3
     ec4:      	fdiv.4s	v4, v4, v3
     ec8:      	add	x9, x19, x8
     ecc:      	ldp	q7, q6, [x9]
     ed0:      	fmul.4s	v4, v4, v7
     ed4:      	fmul.4s	v5, v5, v6
     ed8:      	add	x9, x21, x8
     edc:      	stp	q4, q5, [x9]
     ee0:      	add	x8, x8, #0x20
     ee4:      	cmp	x8, #0xfe0
     ee8:      	b.ne	0xeb8 <ltmp0+0xeb8>
     eec:      	dup.4s	v2, v2[0]
     ef0:      	fdiv.4s	v3, v16, v2
     ef4:      	fdiv.4s	v2, v17, v2
     ef8:      	fmul.4s	v1, v1, v2
     efc:      	fmul.4s	v0, v0, v3
     f00:      	add	x8, x27, x20
     f04:      	str	q0, [x8]
     f08:      	str	d1, [x8, #0x10]
     f0c:      	add	x8, x8, #0x18
     f10:      	st1.s	{ v1 }[2], [x8]
     f14:      	add	x24, x24, #0x1
     f18:      	add	x21, x21, #0xffc
     f1c:      	ldr	x8, [sp, #0x48]
     f20:      	cmp	x24, x8
     f24:      	b.ne	0xc54 <ltmp0+0xc54>
     f28:      	ldr	x8, [sp, #0x18]
     f2c:      	and	w8, w8, #0x7
     f30:      	ldp	w3, w27, [sp, #0x30]
     f34:      	ldr	x7, [sp, #0x40]
     f38:      	cbz	w8, 0x74 <ltmp0+0x74>
     f3c:      	dup.4s	v1, w8
     f40:      	adrp	x8, 0x0 <ltmp0>
     f44:      	ldr	q2, [x8]
     f48:      	adrp	x8, 0x0 <ltmp0>
     f4c:      	ldr	q0, [x8]
     f50:      	cmhi.4s	v0, v1, v0
     f54:      	cmhi.4s	v1, v1, v2
     f58:      	uzp1.8h	v7, v1, v0
     f5c:      	umaxv.8h	h2, v7
     f60:      	fmov	w8, s2
     f64:      	mov	w17, #0x4               ; =4
     f68:      	tbz	w8, #0x0, 0x70 <ltmp0+0x70>
     f6c:      	mov	x9, #0x0                ; =0
     f70:      	ldr	x8, [sp, #0x10]
     f74:      	ldr	x12, [x8]
     f78:      	ldr	x10, [x8, #0x10]
     f7c:      	ldr	x8, [x8, #0x30]
     f80:      	adrp	x11, 0x0 <ltmp0>
     f84:      	ldr	q2, [x11]
     f88:      	and.16b	v2, v7, v2
     f8c:      	addv.8h	h2, v2
     f90:      	ubfiz	w11, w7, #2, #27
     f94:      	ldr	x13, [sp, #0x48]
     f98:      	orr	w13, w11, w13
     f9c:      	fmov	w11, s2
     fa0:      	and	w11, w11, #0xff
     fa4:      	dup.4s	v3, w13
     fa8:      	and.16b	v6, v1, v3
     fac:      	and.16b	v5, v0, v3
     fb0:      	ushll2.2d	v3, v5, #0x0
     fb4:      	ushll2.2d	v4, v6, #0x0
     fb8:      	ushll.2d	v5, v5, #0x0
     fbc:      	ushll.2d	v6, v6, #0x0
     fc0:      	fmov	x13, d6
     fc4:      	mov	w14, #0xffc             ; =4092
     fc8:      	umaddl	x13, w13, w14, x12
     fcc:      	b	0xff0 <ltmp0+0xff0>
     fd0:      	add	x14, x26, x9
     fd4:      	ldp	q18, q19, [x14]
     fd8:      	bif.16b	v17, v19, v0
     fdc:      	bif.16b	v16, v18, v1
     fe0:      	stp	q16, q17, [x14]
     fe4:      	add	x9, x9, #0x20
     fe8:      	cmp	x9, #0xfe0
     fec:      	b.eq	0x1088 <ltmp0+0x1088>
     ff0:      	fmov	w15, s2
     ff4:      	add	x14, x13, x9
     ff8:      	movi.2d	v16, #0000000000000000
     ffc:      	movi.2d	v17, #0000000000000000
    1000:      	tbnz	w15, #0x0, 0x1028 <ltmp0+0x1028>
    1004:      	and	w15, w15, #0xff
    1008:      	tbnz	w15, #0x1, 0x1034 <ltmp0+0x1034>
    100c:      	tbnz	w15, #0x2, 0x1040 <ltmp0+0x1040>
    1010:      	tbnz	w15, #0x3, 0x104c <ltmp0+0x104c>
    1014:      	tbnz	w15, #0x4, 0x1058 <ltmp0+0x1058>
    1018:      	tbnz	w15, #0x5, 0x1064 <ltmp0+0x1064>
    101c:      	tbnz	w15, #0x6, 0x1070 <ltmp0+0x1070>
    1020:      	tbz	w15, #0x7, 0xfd0 <ltmp0+0xfd0>
    1024:      	b	0x107c <ltmp0+0x107c>
    1028:      	ldr	s16, [x14]
    102c:      	and	w15, w15, #0xff
    1030:      	tbz	w15, #0x1, 0x100c <ltmp0+0x100c>
    1034:      	add	x16, x14, #0x4
    1038:      	ld1.s	{ v16 }[1], [x16]
    103c:      	tbz	w15, #0x2, 0x1010 <ltmp0+0x1010>
    1040:      	add	x16, x14, #0x8
    1044:      	ld1.s	{ v16 }[2], [x16]
    1048:      	tbz	w15, #0x3, 0x1014 <ltmp0+0x1014>
    104c:      	add	x16, x14, #0xc
    1050:      	ld1.s	{ v16 }[3], [x16]
    1054:      	tbz	w15, #0x4, 0x1018 <ltmp0+0x1018>
    1058:      	add	x16, x14, #0x10
    105c:      	ld1.s	{ v17 }[0], [x16]
    1060:      	tbz	w15, #0x5, 0x101c <ltmp0+0x101c>
    1064:      	add	x16, x14, #0x14
    1068:      	ld1.s	{ v17 }[1], [x16]
    106c:      	tbz	w15, #0x6, 0x1020 <ltmp0+0x1020>
    1070:      	add	x16, x14, #0x18
    1074:      	ld1.s	{ v17 }[2], [x16]
    1078:      	tbz	w15, #0x7, 0xfd0 <ltmp0+0xfd0>
    107c:      	add	x14, x14, #0x1c
    1080:      	ld1.s	{ v17 }[3], [x14]
    1084:      	b	0xfd0 <ltmp0+0xfd0>
    1088:      	xtn.8b	v26, v7
    108c:      	sshll.2d	v18, v1, #0x0
    1090:      	sshll2.2d	v24, v1, #0x0
    1094:      	sshll.2d	v22, v0, #0x0
    1098:      	sshll2.2d	v25, v0, #0x0
    109c:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    10a0:      	ldr	q7, [x9]
    10a4:      	and.16b	v21, v25, v7
    10a8:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    10ac:      	ldr	q7, [x9]
    10b0:      	and.16b	v16, v22, v7
    10b4:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    10b8:      	ldr	q7, [x9]
    10bc:      	and.16b	v19, v24, v7
    10c0:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    10c4:      	ldr	q7, [x9]
    10c8:      	and.16b	v20, v18, v7
    10cc:      	mov.16b	v17, v26
    10d0:      	mov.b	v17[7], wzr
    10d4:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    10d8:      	ldr	d7, [x9]
    10dc:      	str	d7, [sp, #0x90]
    10e0:      	and.8b	v7, v17, v7
    10e4:      	addv.8b	b7, v7
    10e8:      	fmov	w13, s7
    10ec:      	umaxv.8b	b7, v17
    10f0:      	fmov	w9, s7
    10f4:      	rbit	w14, w13
    10f8:      	clz	w14, w14
    10fc:      	tst	w9, #0x1
    1100:      	csel	w9, w14, wzr, ne
    1104:      	mov	w14, #0x3f8             ; =1016
    1108:      	dup.2d	v7, x14
    110c:      	stp	q20, q19, [sp, #0x50]
    1110:      	orr.16b	v20, v20, v7
    1114:      	orr.16b	v19, v19, v7
    1118:      	stp	q16, q21, [sp, #0x70]
    111c:      	orr.16b	v16, v16, v7
    1120:      	orr.16b	v7, v21, v7
    1124:      	xtn.2s	v27, v6
    1128:      	xtn.2s	v4, v4
    112c:      	xtn.2s	v5, v5
    1130:      	xtn.2s	v3, v3
    1134:      	stp	q16, q7, [sp, #0xd0]
    1138:      	umlal.2d	v7, v3, v9
    113c:      	mov.16b	v6, v16
    1140:      	umlal.2d	v6, v5, v9
    1144:      	stp	q20, q19, [sp, #0xb0]
    1148:      	mov.16b	v5, v19
    114c:      	umlal.2d	v5, v4, v9
    1150:      	mov.16b	v16, v20
    1154:      	umlal.2d	v16, v27, v9
    1158:      	mov	b3, v26[0]
    115c:      	mov.b	v3[4], v26[1]
    1160:      	ushll.2d	v3, v3, #0x0
    1164:      	shl.2d	v3, v3, #0x3f
    1168:      	cmlt.2d	v3, v3, #0
    116c:      	mov	b4, v26[2]
    1170:      	mov.b	v4[4], v26[3]
    1174:      	stp	q16, q5, [sp, #0x110]
    1178:      	and.16b	v3, v3, v16
    117c:      	ushll.2d	v4, v4, #0x0
    1180:      	shl.2d	v4, v4, #0x3f
    1184:      	cmlt.2d	v4, v4, #0
    1188:      	and.16b	v4, v4, v5
    118c:      	mov	b5, v26[4]
    1190:      	mov.b	v5[4], v26[5]
    1194:      	ushll.2d	v5, v5, #0x0
    1198:      	shl.2d	v5, v5, #0x3f
    119c:      	cmlt.2d	v5, v5, #0
    11a0:      	stp	q6, q7, [sp, #0x130]
    11a4:      	and.16b	v5, v5, v6
    11a8:      	movi.2d	v6, #0000000000000000
    11ac:      	mov.b	v6[0], v26[6]
    11b0:      	ushll.2d	v6, v6, #0x0
    11b4:      	shl.2d	v6, v6, #0x3f
    11b8:      	cmlt.2d	v6, v6, #0
    11bc:      	and.16b	v6, v6, v7
    11c0:      	stp	q5, q6, [sp, #0x3b0]
    11c4:      	stp	q3, q4, [sp, #0x390]
    11c8:      	and	x14, x9, #0x7
    11cc:      	add	x15, sp, #0x390
    11d0:      	ldr	x14, [x15, x14, lsl #3]
    11d4:      	sub	x14, x14, x9
    11d8:      	add	x12, x12, x14, lsl #2
    11dc:      	movi.2d	v16, #0000000000000000
    11e0:      	movi.2d	v7, #0000000000000000
    11e4:      	tbnz	w13, #0x0, 0x1b18 <ltmp0+0x1b18>
    11e8:      	tbnz	w13, #0x1, 0x1b20 <ltmp0+0x1b20>
    11ec:      	tbnz	w13, #0x2, 0x1b2c <ltmp0+0x1b2c>
    11f0:      	tbnz	w13, #0x3, 0x1b38 <ltmp0+0x1b38>
    11f4:      	tbnz	w13, #0x4, 0x1b44 <ltmp0+0x1b44>
    11f8:      	tbnz	w13, #0x5, 0x1b50 <ltmp0+0x1b50>
    11fc:      	tbnz	w13, #0x6, 0x1b5c <ltmp0+0x1b5c>
    1200:      	tbz	w13, #0x7, 0x120c <ltmp0+0x120c>
    1204:      	add	x12, x12, #0x1c
    1208:      	ld1.s	{ v7 }[3], [x12]
    120c:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    1210:      	ldr	q3, [x12]
    1214:      	and.16b	v3, v25, v3
    1218:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    121c:      	ldr	q4, [x12]
    1220:      	and.16b	v4, v24, v4
    1224:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    1228:      	ldr	q5, [x12]
    122c:      	and.16b	v5, v22, v5
    1230:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    1234:      	ldr	q6, [x12]
    1238:      	and.16b	v18, v18, v6
    123c:      	umull.2d	v6, v27, v9
    1240:      	str	q6, [sp, #0xa0]
    1244:      	sshll.2d	v6, v1, #0x0
    1248:      	sshll.2d	v19, v0, #0x0
    124c:      	stp	q18, q4, [sp, #0x350]
    1250:      	stp	q5, q3, [sp, #0x370]
    1254:      	and	x12, x9, #0x7
    1258:      	add	x14, sp, #0x350
    125c:      	ldr	x12, [x14, x12, lsl #3]
    1260:      	orr	x12, x12, #0xfe0
    1264:      	sub	x12, x12, x9, lsl #2
    1268:      	tst	w13, #0xff
    126c:      	csel	x12, xzr, x12, eq
    1270:      	add	x13, x26, x12
    1274:      	ldp	q3, q4, [x13]
    1278:      	zip2.8b	v5, v17, v0
    127c:      	ushll.4s	v5, v5, #0x0
    1280:      	shl.4s	v5, v5, #0x1f
    1284:      	cmlt.4s	v5, v5, #0
    1288:      	stp	q16, q7, [sp, #0xf0]
    128c:      	bit.16b	v4, v7, v5
    1290:      	zip1.8b	v5, v17, v0
    1294:      	ushll.4s	v5, v5, #0x0
    1298:      	shl.4s	v5, v5, #0x1f
    129c:      	cmlt.4s	v5, v5, #0
    12a0:      	bit.16b	v3, v16, v5
    12a4:      	stp	q3, q4, [x13]
    12a8:      	dup.2d	v20, x17
    12ac:      	and.16b	v3, v25, v20
    12b0:      	and.16b	v4, v24, v20
    12b4:      	and.16b	v5, v19, v20
    12b8:      	and.16b	v6, v6, v20
    12bc:      	fmov	x13, d6
    12c0:      	ldr	q19, [sp, #0x1450]
    12c4:      	ldr	q20, [sp, #0x1440]
    12c8:      	fmul.4s	v20, v20, v20
    12cc:      	fmul.4s	v19, v19, v19
    12d0:      	and.16b	v12, v0, v19
    12d4:      	and.16b	v11, v1, v20
    12d8:      	ldr	q19, [sp, #0x1430]
    12dc:      	ldr	q20, [sp, #0x1420]
    12e0:      	fmul.4s	v20, v20, v20
    12e4:      	fmul.4s	v19, v19, v19
    12e8:      	and.16b	v19, v0, v19
    12ec:      	and.16b	v20, v1, v20
    12f0:      	ldr	q21, [sp, #0x1410]
    12f4:      	ldr	q22, [sp, #0x1400]
    12f8:      	fmul.4s	v22, v22, v22
    12fc:      	fmul.4s	v21, v21, v21
    1300:      	and.16b	v21, v0, v21
    1304:      	and.16b	v23, v1, v22
    1308:      	fmov	x14, d18
    130c:      	add	x14, x26, x14
    1310:      	ldp	q22, q18, [x14]
    1314:      	fmul.4s	v22, v22, v22
    1318:      	fmul.4s	v18, v18, v18
    131c:      	and.16b	v13, v0, v18
    1320:      	and.16b	v14, v1, v22
    1324:      	sshll.2d	v27, v1, #0x0
    1328:      	sshll.2d	v28, v0, #0x0
    132c:      	add	x13, x26, x13, lsl #5
    1330:      	ldp	q22, q18, [x13]
    1334:      	and.16b	v22, v1, v22
    1338:      	and.16b	v18, v0, v18
    133c:      	fmul.4s	v18, v18, v18
    1340:      	fmul.4s	v22, v22, v22
    1344:      	fadd.4s	v29, v14, v22
    1348:      	fadd.4s	v30, v13, v18
    134c:      	ldp	q22, q18, [x13, #0x20]
    1350:      	and.16b	v22, v1, v22
    1354:      	and.16b	v18, v0, v18
    1358:      	fmul.4s	v18, v18, v18
    135c:      	fmul.4s	v22, v22, v22
    1360:      	fadd.4s	v15, v23, v22
    1364:      	fadd.4s	v18, v21, v18
    1368:      	ldp	q31, q22, [x13, #0x40]
    136c:      	and.16b	v31, v1, v31
    1370:      	and.16b	v22, v0, v22
    1374:      	fmul.4s	v22, v22, v22
    1378:      	fmul.4s	v31, v31, v31
    137c:      	fadd.4s	v9, v20, v31
    1380:      	fadd.4s	v22, v19, v22
    1384:      	ldp	q10, q31, [x13, #0x60]
    1388:      	and.16b	v10, v1, v10
    138c:      	and.16b	v31, v0, v31
    1390:      	fmul.4s	v31, v31, v31
    1394:      	fmul.4s	v10, v10, v10
    1398:      	fadd.4s	v10, v11, v10
    139c:      	fadd.4s	v31, v12, v31
    13a0:      	dup.2d	v16, x17
    13a4:      	and.16b	v7, v25, v16
    13a8:      	add.2d	v3, v3, v7
    13ac:      	and.16b	v7, v24, v16
    13b0:      	add.2d	v4, v4, v7
    13b4:      	and.16b	v7, v28, v16
    13b8:      	add.2d	v5, v5, v7
    13bc:      	and.16b	v7, v27, v16
    13c0:      	add.2d	v6, v6, v7
    13c4:      	bit.16b	v13, v30, v0
    13c8:      	bit.16b	v14, v29, v1
    13cc:      	bit.16b	v21, v18, v0
    13d0:      	bit.16b	v23, v15, v1
    13d4:      	bit.16b	v19, v22, v0
    13d8:      	bit.16b	v20, v9, v1
    13dc:      	bit.16b	v12, v31, v0
    13e0:      	bit.16b	v11, v10, v1
    13e4:      	fmov	x13, d6
    13e8:      	cmp	x13, #0x7c
    13ec:      	b.lt	0x1324 <ltmp0+0x1324>
    13f0:      	mov	x13, #0x0               ; =0
    13f4:      	mov	w14, #0x1               ; =1
    13f8:      	dup.2d	v5, x14
    13fc:      	ldr	q3, [sp, #0x2370]
    1400:      	ldr	q4, [sp, #0x2360]
    1404:      	ldr	q23, [sp, #0x2390]
    1408:      	ldr	q21, [sp, #0x2380]
    140c:      	ldr	q19, [sp, #0x23b0]
    1410:      	ldr	q20, [sp, #0x23a0]
    1414:      	ushll2.2d	v6, v0, #0x0
    1418:      	and.16b	v24, v6, v5
    141c:      	ushll2.2d	v6, v1, #0x0
    1420:      	and.16b	v25, v6, v5
    1424:      	ushll.2d	v6, v0, #0x0
    1428:      	and.16b	v27, v6, v5
    142c:      	ushll.2d	v6, v1, #0x0
    1430:      	and.16b	v28, v6, v5
    1434:      	movi.2d	v5, #0000000000000000
    1438:      	movi.2d	v6, #0000000000000000
    143c:      	movi.2d	v29, #0000000000000000
    1440:      	movi.2d	v30, #0000000000000000
    1444:      	b	0x1478 <ltmp0+0x1478>
    1448:      	add	x13, x19, x13
    144c:      	ldp	q7, q16, [x13]
    1450:      	bit.16b	v16, v10, v0
    1454:      	bit.16b	v7, v31, v1
    1458:      	stp	q7, q16, [x13]
    145c:      	add.2d	v6, v6, v25
    1460:      	add.2d	v29, v29, v27
    1464:      	add.2d	v30, v30, v24
    1468:      	add.2d	v5, v5, v28
    146c:      	fmov	x13, d5
    1470:      	cmp	x13, #0x7f
    1474:      	b.ge	0x1514 <ltmp0+0x1514>
    1478:      	fmov	w15, s2
    147c:      	lsl	x13, x13, #5
    1480:      	add	x14, x10, x13
    1484:      	movi.2d	v31, #0000000000000000
    1488:      	movi.2d	v10, #0000000000000000
    148c:      	tbnz	w15, #0x0, 0x14b4 <ltmp0+0x14b4>
    1490:      	and	w15, w15, #0xff
    1494:      	tbnz	w15, #0x1, 0x14c0 <ltmp0+0x14c0>
    1498:      	tbnz	w15, #0x2, 0x14cc <ltmp0+0x14cc>
    149c:      	tbnz	w15, #0x3, 0x14d8 <ltmp0+0x14d8>
    14a0:      	tbnz	w15, #0x4, 0x14e4 <ltmp0+0x14e4>
    14a4:      	tbnz	w15, #0x5, 0x14f0 <ltmp0+0x14f0>
    14a8:      	tbnz	w15, #0x6, 0x14fc <ltmp0+0x14fc>
    14ac:      	tbz	w15, #0x7, 0x1448 <ltmp0+0x1448>
    14b0:      	b	0x1508 <ltmp0+0x1508>
    14b4:      	ldr	s31, [x14]
    14b8:      	and	w15, w15, #0xff
    14bc:      	tbz	w15, #0x1, 0x1498 <ltmp0+0x1498>
    14c0:      	add	x16, x14, #0x4
    14c4:      	ld1.s	{ v31 }[1], [x16]
    14c8:      	tbz	w15, #0x2, 0x149c <ltmp0+0x149c>
    14cc:      	add	x16, x14, #0x8
    14d0:      	ld1.s	{ v31 }[2], [x16]
    14d4:      	tbz	w15, #0x3, 0x14a0 <ltmp0+0x14a0>
    14d8:      	add	x16, x14, #0xc
    14dc:      	ld1.s	{ v31 }[3], [x16]
    14e0:      	tbz	w15, #0x4, 0x14a4 <ltmp0+0x14a4>
    14e4:      	add	x16, x14, #0x10
    14e8:      	ld1.s	{ v10 }[0], [x16]
    14ec:      	tbz	w15, #0x5, 0x14a8 <ltmp0+0x14a8>
    14f0:      	add	x16, x14, #0x14
    14f4:      	ld1.s	{ v10 }[1], [x16]
    14f8:      	tbz	w15, #0x6, 0x14ac <ltmp0+0x14ac>
    14fc:      	add	x16, x14, #0x18
    1500:      	ld1.s	{ v10 }[2], [x16]
    1504:      	tbz	w15, #0x7, 0x1448 <ltmp0+0x1448>
    1508:      	add	x14, x14, #0x1c
    150c:      	ld1.s	{ v10 }[3], [x14]
    1510:      	b	0x1448 <ltmp0+0x1448>
    1514:      	and.16b	v4, v1, v4
    1518:      	and.16b	v3, v0, v3
    151c:      	fmul.4s	v3, v3, v3
    1520:      	fmul.4s	v4, v4, v4
    1524:      	fadd.4s	v4, v14, v4
    1528:      	fadd.4s	v3, v13, v3
    152c:      	and.16b	v5, v0, v23
    1530:      	and.16b	v6, v1, v21
    1534:      	fmul.4s	v6, v6, v6
    1538:      	fmul.4s	v5, v5, v5
    153c:      	fadd.4s	v5, v18, v5
    1540:      	fadd.4s	v6, v15, v6
    1544:      	and.16b	v6, v1, v6
    1548:      	and.16b	v5, v0, v5
    154c:      	and.16b	v7, v1, v20
    1550:      	and.16b	v16, v0, v19
    1554:      	fmul.4s	v16, v16, v16
    1558:      	fmul.4s	v7, v7, v7
    155c:      	fadd.4s	v7, v9, v7
    1560:      	fadd.4s	v16, v22, v16
    1564:      	and.16b	v16, v0, v16
    1568:      	and.16b	v7, v1, v7
    156c:      	ldp	q31, q30, [sp, #0xf0]
    1570:      	fmul.4s	v18, v31, v31
    1574:      	fmul.4s	v19, v30, v30
    1578:      	fadd.4s	v19, v19, v3
    157c:      	fadd.4s	v4, v18, v4
    1580:      	zip1.8b	v18, v17, v0
    1584:      	ushll.4s	v18, v18, #0x0
    1588:      	shl.4s	v18, v18, #0x1f
    158c:      	cmlt.4s	v18, v18, #0
    1590:      	and.16b	v4, v18, v4
    1594:      	zip2.8b	v18, v17, v0
    1598:      	ushll.4s	v18, v18, #0x0
    159c:      	shl.4s	v18, v18, #0x1f
    15a0:      	cmlt.4s	v18, v18, #0
    15a4:      	movi.2d	v20, #0000000000000000
    15a8:      	mov.b	v20[6], v26[7]
    15ac:      	and.16b	v18, v18, v19
    15b0:      	ushll.4s	v19, v20, #0x0
    15b4:      	shl.4s	v19, v19, #0x1f
    15b8:      	cmlt.4s	v19, v19, #0
    15bc:      	bif.16b	v3, v18, v19
    15c0:      	fadd.4s	v3, v5, v3
    15c4:      	fadd.4s	v4, v6, v4
    15c8:      	fadd.4s	v4, v7, v4
    15cc:      	fadd.4s	v3, v16, v3
    15d0:      	fadd.4s	v18, v12, v3
    15d4:      	fadd.4s	v9, v11, v4
    15d8:      	ldp	q4, q3, [sp, #0x50]
    15dc:      	uzp1.4s	v22, v4, v3
    15e0:      	ldp	q4, q3, [sp, #0x70]
    15e4:      	uzp1.4s	v29, v4, v3
    15e8:      	movi.4s	v4, #0x1
    15ec:      	eor.16b	v3, v22, v4
    15f0:      	mov.s	w14, v3[1]
    15f4:      	mov.s	w17, v3[2]
    15f8:      	eor.16b	v6, v29, v4
    15fc:      	mov.s	w0, v3[3]
    1600:      	fmov	w13, s3
    1604:      	add	x15, sp, #0x198
    1608:      	bfxil	x15, x13, #0, #3
    160c:      	str	d26, [sp, #0x198]
    1610:      	ldrb	w16, [x15]
    1614:      	and	x15, x13, #0x7
    1618:      	umov.b	w13, v26[0]
    161c:      	stp	q9, q18, [sp, #0x2a0]
    1620:      	add	x1, sp, #0x2a0
    1624:      	ldr	s3, [x1, x15, lsl #2]
    1628:      	ands	w15, w13, #0x1
    162c:      	tst	w15, w16
    1630:      	fcsel	s3, s3, s8, ne
    1634:      	add	x16, sp, #0x198
    1638:      	bfxil	x16, x14, #0, #3
    163c:      	ldrb	w16, [x16]
    1640:      	and	x1, x14, #0x7
    1644:      	umov.b	w14, v26[1]
    1648:      	stp	q9, q18, [sp, #0x280]
    164c:      	add	x2, sp, #0x280
    1650:      	ldr	s4, [x2, x1, lsl #2]
    1654:      	ands	w1, w14, #0x1
    1658:      	tst	w1, w16
    165c:      	fcsel	s4, s4, s8, ne
    1660:      	add	x16, sp, #0x198
    1664:      	bfxil	x16, x17, #0, #3
    1668:      	ldrb	w1, [x16]
    166c:      	umov.b	w16, v26[2]
    1670:      	and	x17, x17, #0x7
    1674:      	stp	q9, q18, [sp, #0x260]
    1678:      	add	x2, sp, #0x260
    167c:      	ldr	s5, [x2, x17, lsl #2]
    1680:      	ands	w17, w16, #0x1
    1684:      	tst	w17, w1
    1688:      	fcsel	s5, s5, s8, ne
    168c:      	add	x17, sp, #0x198
    1690:      	bfxil	x17, x0, #0, #3
    1694:      	ldrb	w1, [x17]
    1698:      	and	x0, x0, #0x7
    169c:      	umov.b	w17, v26[3]
    16a0:      	stp	q9, q18, [sp, #0x240]
    16a4:      	add	x2, sp, #0x240
    16a8:      	ldr	s7, [x2, x0, lsl #2]
    16ac:      	ands	w0, w17, #0x1
    16b0:      	tst	w0, w1
    16b4:      	mov.s	w1, v6[1]
    16b8:      	mov.s	w2, v6[2]
    16bc:      	fcsel	s19, s7, s8, ne
    16c0:      	mov.s	w4, v6[3]
    16c4:      	fmov	w0, s6
    16c8:      	and	x20, x0, #0x7
    16cc:      	add	x5, sp, #0x198
    16d0:      	bfxil	x5, x0, #0, #3
    16d4:      	ldrb	w5, [x5]
    16d8:      	umov.b	w0, v26[4]
    16dc:      	and	w5, w0, w5
    16e0:      	stp	q9, q18, [sp, #0x320]
    16e4:      	add	x6, sp, #0x320
    16e8:      	ldr	s6, [x6, x20, lsl #2]
    16ec:      	tst	w5, #0x1
    16f0:      	fcsel	s6, s6, s8, ne
    16f4:      	add	x5, sp, #0x198
    16f8:      	bfxil	x5, x1, #0, #3
    16fc:      	ldrb	w20, [x5]
    1700:      	and	x5, x1, #0x7
    1704:      	umov.b	w1, v26[5]
    1708:      	stp	q9, q18, [sp, #0x300]
    170c:      	add	x6, sp, #0x300
    1710:      	ldr	s7, [x6, x5, lsl #2]
    1714:      	ands	w5, w1, #0x1
    1718:      	tst	w5, w20
    171c:      	fcsel	s7, s7, s8, ne
    1720:      	add	x5, sp, #0x198
    1724:      	bfxil	x5, x2, #0, #3
    1728:      	ldrb	w20, [x5]
    172c:      	and	x5, x2, #0x7
    1730:      	umov.b	w2, v26[6]
    1734:      	stp	q9, q18, [sp, #0x2e0]
    1738:      	add	x6, sp, #0x2e0
    173c:      	ldr	s16, [x6, x5, lsl #2]
    1740:      	ands	w5, w2, #0x1
    1744:      	tst	w5, w20
    1748:      	fcsel	s16, s16, s8, ne
    174c:      	add	x5, sp, #0x198
    1750:      	bfxil	x5, x4, #0, #3
    1754:      	ldrb	w5, [x5]
    1758:      	umov.b	w20, v26[7]
    175c:      	and	x4, x4, #0x7
    1760:      	stp	q9, q18, [sp, #0x2c0]
    1764:      	add	x6, sp, #0x2c0
    1768:      	ldr	s20, [x6, x4, lsl #2]
    176c:      	ands	w4, w20, #0x1
    1770:      	tst	w4, w5
    1774:      	fcsel	s20, s20, s8, ne
    1778:      	mov.s	v6[1], v7[0]
    177c:      	mov.s	v6[2], v16[0]
    1780:      	mov.s	v6[3], v20[0]
    1784:      	mov.s	v3[1], v4[0]
    1788:      	mov.s	v3[2], v5[0]
    178c:      	mov.s	v3[3], v19[0]
    1790:      	fadd.4s	v3, v9, v3
    1794:      	fadd.4s	v4, v18, v6
    1798:      	movi.4s	v6, #0x2
    179c:      	eor.16b	v5, v29, v6
    17a0:      	eor.16b	v6, v22, v6
    17a4:      	fmov	w4, s6
    17a8:      	add	x5, sp, #0x198
    17ac:      	bfxil	x5, x4, #0, #3
    17b0:      	ldrb	w5, [x5]
    17b4:      	and	x4, x4, #0x7
    17b8:      	stp	q3, q4, [sp, #0x220]
    17bc:      	add	x6, sp, #0x220
    17c0:      	ldr	s6, [x6, x4, lsl #2]
    17c4:      	tst	w15, w5
    17c8:      	fcsel	s6, s6, s8, ne
    17cc:      	fmov	w4, s5
    17d0:      	and	x5, x4, #0x7
    17d4:      	add	x6, sp, #0x198
    17d8:      	bfxil	x6, x4, #0, #3
    17dc:      	ldrb	w4, [x6]
    17e0:      	and	w4, w0, w4
    17e4:      	stp	q3, q4, [sp, #0x200]
    17e8:      	add	x6, sp, #0x200
    17ec:      	ldr	s5, [x6, x5, lsl #2]
    17f0:      	tst	w4, #0x1
    17f4:      	fcsel	s5, s5, s8, ne
    17f8:      	fadd.4s	v4, v4, v5
    17fc:      	tst	w15, w0
    1800:      	fcsel	s4, s4, s8, ne
    1804:      	ands	w13, w13, #0x1
    1808:      	fadd.4s	v3, v3, v6
    180c:      	fadd	s3, s3, s4
    1810:      	fcsel	s4, s3, s8, ne
    1814:      	tst	w14, #0x1
    1818:      	fcsel	s5, s4, s8, ne
    181c:      	tst	w16, #0x1
    1820:      	fcsel	s6, s4, s8, ne
    1824:      	tst	w17, #0x1
    1828:      	fcsel	s7, s4, s8, ne
    182c:      	tst	w13, w0
    1830:      	fcsel	s3, s3, s8, ne
    1834:      	tst	w1, #0x1
    1838:      	fcsel	s16, s4, s8, ne
    183c:      	tst	w2, #0x1
    1840:      	fcsel	s18, s4, s8, ne
    1844:      	tst	w20, #0x1
    1848:      	shl.8b	v19, v17, #0x7
    184c:      	cmlt.8b	v19, v19, #0
    1850:      	ldr	d20, [sp, #0x90]
    1854:      	and.8b	v19, v19, v20
    1858:      	addv.8b	b23, v19
    185c:      	fmov	w13, s23
    1860:      	fcsel	s19, s4, s8, ne
    1864:      	mov.s	v4[1], v5[0]
    1868:      	mov.s	v4[2], v6[0]
    186c:      	mov.s	v4[3], v7[0]
    1870:      	mov.s	v3[1], v16[0]
    1874:      	mov.s	v3[2], v18[0]
    1878:      	mov.s	v3[3], v19[0]
    187c:      	rbit	w11, w11
    1880:      	clz	w11, w11
    1884:      	stp	q4, q3, [sp, #0x1e0]
    1888:      	and	x11, x11, #0x7
    188c:      	add	x14, sp, #0x1e0
    1890:      	ldr	s3, [x14, x11, lsl #2]
    1894:      	mov	b4, v17[0]
    1898:      	mov.b	v4[4], v17[1]
    189c:      	ushll.2d	v4, v4, #0x0
    18a0:      	shl.2d	v4, v4, #0x3f
    18a4:      	cmlt.2d	v4, v4, #0
    18a8:      	mov	b5, v17[2]
    18ac:      	mov.b	v5[4], v17[3]
    18b0:      	ldp	q7, q6, [sp, #0xb0]
    18b4:      	and.16b	v4, v4, v7
    18b8:      	ushll.2d	v5, v5, #0x0
    18bc:      	shl.2d	v5, v5, #0x3f
    18c0:      	cmlt.2d	v5, v5, #0
    18c4:      	and.16b	v5, v5, v6
    18c8:      	mov	b6, v17[4]
    18cc:      	mov.b	v6[4], v17[5]
    18d0:      	ushll.2d	v6, v6, #0x0
    18d4:      	shl.2d	v6, v6, #0x3f
    18d8:      	cmlt.2d	v6, v6, #0
    18dc:      	ldp	q7, q16, [sp, #0xd0]
    18e0:      	and.16b	v6, v6, v7
    18e4:      	mov	b7, v17[6]
    18e8:      	mov.b	v7[4], v17[7]
    18ec:      	ushll.2d	v7, v7, #0x0
    18f0:      	shl.2d	v7, v7, #0x3f
    18f4:      	cmlt.2d	v7, v7, #0
    18f8:      	and.16b	v7, v7, v16
    18fc:      	stp	q6, q7, [sp, #0x1c0]
    1900:      	stp	q4, q5, [sp, #0x1a0]
    1904:      	and	x11, x9, #0x7
    1908:      	add	x14, sp, #0x1a0
    190c:      	ldr	x11, [x14, x11, lsl #3]
    1910:      	sub	x11, x11, x9
    1914:      	add	x10, x10, x11, lsl #2
    1918:      	movi.2d	v19, #0000000000000000
    191c:      	movi.2d	v18, #0000000000000000
    1920:      	tbnz	w13, #0x0, 0x1b6c <ltmp0+0x1b6c>
    1924:      	movi.2s	v9, #0x3, msl #8
    1928:      	tbnz	w13, #0x1, 0x1b78 <ltmp0+0x1b78>
    192c:      	tbnz	w13, #0x2, 0x1b84 <ltmp0+0x1b84>
    1930:      	tbnz	w13, #0x3, 0x1b90 <ltmp0+0x1b90>
    1934:      	tbnz	w13, #0x4, 0x1b9c <ltmp0+0x1b9c>
    1938:      	tbnz	w13, #0x5, 0x1ba8 <ltmp0+0x1ba8>
    193c:      	tbnz	w13, #0x6, 0x1bb4 <ltmp0+0x1bb4>
    1940:      	tbz	w13, #0x7, 0x194c <ltmp0+0x194c>
    1944:      	add	x10, x10, #0x1c
    1948:      	ld1.s	{ v18 }[3], [x10]
    194c:      	mov	x11, #0x0               ; =0
    1950:      	fadd	s3, s3, s8
    1954:      	mov	w10, #0xc000            ; =49152
    1958:      	movk	w10, #0x447f, lsl #16
    195c:      	fmov	s4, w10
    1960:      	fdiv	s3, s3, s4
    1964:      	add	x10, x19, x12
    1968:      	ldp	q4, q5, [x10]
    196c:      	zip2.8b	v6, v17, v0
    1970:      	ushll.4s	v6, v6, #0x0
    1974:      	shl.4s	v6, v6, #0x1f
    1978:      	cmlt.4s	v6, v6, #0
    197c:      	bit.16b	v5, v18, v6
    1980:      	zip1.8b	v6, v17, v0
    1984:      	ushll.4s	v6, v6, #0x0
    1988:      	shl.4s	v6, v6, #0x1f
    198c:      	cmlt.4s	v6, v6, #0
    1990:      	bit.16b	v4, v19, v6
    1994:      	stp	q4, q5, [x10]
    1998:      	mov	w10, #0xc5ac            ; =50604
    199c:      	movk	w10, #0x3727, lsl #16
    19a0:      	fmov	s4, w10
    19a4:      	fadd	s3, s3, s4
    19a8:      	fsqrt	s3, s3
    19ac:      	dup.4s	v3, v3[0]
    19b0:      	ldr	q4, [sp, #0xa0]
    19b4:      	fmov	x10, d4
    19b8:      	add	x10, x8, x10, lsl #2
    19bc:      	movi.2d	v4, #0000000000000000
    19c0:      	movi.2d	v5, #0000000000000000
    19c4:      	movi.2d	v6, #0000000000000000
    19c8:      	movi.2d	v17, #0000000000000000
    19cc:      	b	0x19ec <ltmp0+0x19ec>
    19d0:      	add.2d	v5, v5, v25
    19d4:      	add.2d	v6, v6, v27
    19d8:      	add.2d	v17, v17, v24
    19dc:      	add.2d	v4, v4, v28
    19e0:      	fmov	x11, d4
    19e4:      	cmp	x11, #0x7f
    19e8:      	b.ge	0x1abc <ltmp0+0x1abc>
    19ec:      	fmov	w12, s2
    19f0:      	lsl	x11, x11, #5
    19f4:      	add	x13, x26, x11
    19f8:      	ldp	q7, q20, [x13]
    19fc:      	and.16b	v7, v1, v7
    1a00:      	fdiv.4s	v7, v7, v3
    1a04:      	add	x13, x19, x11
    1a08:      	ldp	q16, q21, [x13]
    1a0c:      	and.16b	v16, v1, v16
    1a10:      	fmul.4s	v22, v7, v16
    1a14:      	add	x11, x10, x11
    1a18:      	tbnz	w12, #0x0, 0x1a50 <ltmp0+0x1a50>
    1a1c:      	and	w12, w12, #0xff
    1a20:      	tbnz	w12, #0x1, 0x1a5c <ltmp0+0x1a5c>
    1a24:      	tbnz	w12, #0x2, 0x1a68 <ltmp0+0x1a68>
    1a28:      	tbnz	w12, #0x3, 0x1a74 <ltmp0+0x1a74>
    1a2c:      	and.16b	v7, v0, v20
    1a30:      	fdiv.4s	v7, v7, v3
    1a34:      	and.16b	v16, v0, v21
    1a38:      	fmul.4s	v20, v7, v16
    1a3c:      	tbnz	w12, #0x4, 0x1a90 <ltmp0+0x1a90>
    1a40:      	tbnz	w12, #0x5, 0x1a98 <ltmp0+0x1a98>
    1a44:      	tbnz	w12, #0x6, 0x1aa4 <ltmp0+0x1aa4>
    1a48:      	tbz	w12, #0x7, 0x19d0 <ltmp0+0x19d0>
    1a4c:      	b	0x1ab0 <ltmp0+0x1ab0>
    1a50:      	str	s22, [x11]
    1a54:      	and	w12, w12, #0xff
    1a58:      	tbz	w12, #0x1, 0x1a24 <ltmp0+0x1a24>
    1a5c:      	add	x13, x11, #0x4
    1a60:      	st1.s	{ v22 }[1], [x13]
    1a64:      	tbz	w12, #0x2, 0x1a28 <ltmp0+0x1a28>
    1a68:      	add	x13, x11, #0x8
    1a6c:      	st1.s	{ v22 }[2], [x13]
    1a70:      	tbz	w12, #0x3, 0x1a2c <ltmp0+0x1a2c>
    1a74:      	add	x13, x11, #0xc
    1a78:      	st1.s	{ v22 }[3], [x13]
    1a7c:      	and.16b	v7, v0, v20
    1a80:      	fdiv.4s	v7, v7, v3
    1a84:      	and.16b	v16, v0, v21
    1a88:      	fmul.4s	v20, v7, v16
    1a8c:      	tbz	w12, #0x4, 0x1a40 <ltmp0+0x1a40>
    1a90:      	str	s20, [x11, #0x10]
    1a94:      	tbz	w12, #0x5, 0x1a44 <ltmp0+0x1a44>
    1a98:      	add	x13, x11, #0x14
    1a9c:      	st1.s	{ v20 }[1], [x13]
    1aa0:      	tbz	w12, #0x6, 0x1a48 <ltmp0+0x1a48>
    1aa4:      	add	x13, x11, #0x18
    1aa8:      	st1.s	{ v20 }[2], [x13]
    1aac:      	tbz	w12, #0x7, 0x19d0 <ltmp0+0x19d0>
    1ab0:      	add	x11, x11, #0x1c
    1ab4:      	st1.s	{ v20 }[3], [x11]
    1ab8:      	b	0x19d0 <ltmp0+0x19d0>
    1abc:      	fdiv.4s	v0, v31, v3
    1ac0:      	fmul.4s	v0, v0, v19
    1ac4:      	ldp	q2, q1, [sp, #0x110]
    1ac8:      	stp	q2, q1, [sp, #0x150]
    1acc:      	ldp	q2, q1, [sp, #0x130]
    1ad0:      	stp	q2, q1, [sp, #0x170]
    1ad4:      	and	x10, x9, #0x7
    1ad8:      	add	x11, sp, #0x150
    1adc:      	ldr	x10, [x11, x10, lsl #3]
    1ae0:      	sub	x9, x10, x9
    1ae4:      	add	x8, x8, x9, lsl #2
    1ae8:      	fmov	w9, s23
    1aec:      	tbnz	w9, #0x0, 0x1bc4 <ltmp0+0x1bc4>
    1af0:      	tbnz	w9, #0x1, 0x1bcc <ltmp0+0x1bcc>
    1af4:      	tbnz	w9, #0x2, 0x1bd8 <ltmp0+0x1bd8>
    1af8:      	tbnz	w9, #0x3, 0x1be4 <ltmp0+0x1be4>
    1afc:      	fdiv.4s	v0, v30, v3
    1b00:      	fmul.4s	v0, v0, v18
    1b04:      	tbnz	w9, #0x4, 0x1bf8 <ltmp0+0x1bf8>
    1b08:      	tbnz	w9, #0x5, 0x1c00 <ltmp0+0x1c00>
    1b0c:      	tbnz	w9, #0x6, 0x1c0c <ltmp0+0x1c0c>
    1b10:      	tbz	w9, #0x7, 0x70 <ltmp0+0x70>
    1b14:      	b	0x1c18 <ltmp0+0x1c18>
    1b18:      	ldr	s16, [x12]
    1b1c:      	tbz	w13, #0x1, 0x11ec <ltmp0+0x11ec>
    1b20:      	add	x14, x12, #0x4
    1b24:      	ld1.s	{ v16 }[1], [x14]
    1b28:      	tbz	w13, #0x2, 0x11f0 <ltmp0+0x11f0>
    1b2c:      	add	x14, x12, #0x8
    1b30:      	ld1.s	{ v16 }[2], [x14]
    1b34:      	tbz	w13, #0x3, 0x11f4 <ltmp0+0x11f4>
    1b38:      	add	x14, x12, #0xc
    1b3c:      	ld1.s	{ v16 }[3], [x14]
    1b40:      	tbz	w13, #0x4, 0x11f8 <ltmp0+0x11f8>
    1b44:      	add	x14, x12, #0x10
    1b48:      	ld1.s	{ v7 }[0], [x14]
    1b4c:      	tbz	w13, #0x5, 0x11fc <ltmp0+0x11fc>
    1b50:      	add	x14, x12, #0x14
    1b54:      	ld1.s	{ v7 }[1], [x14]
    1b58:      	tbz	w13, #0x6, 0x1200 <ltmp0+0x1200>
    1b5c:      	add	x14, x12, #0x18
    1b60:      	ld1.s	{ v7 }[2], [x14]
    1b64:      	tbnz	w13, #0x7, 0x1204 <ltmp0+0x1204>
    1b68:      	b	0x120c <ltmp0+0x120c>
    1b6c:      	ldr	s19, [x10]
    1b70:      	movi.2s	v9, #0x3, msl #8
    1b74:      	tbz	w13, #0x1, 0x192c <ltmp0+0x192c>
    1b78:      	add	x11, x10, #0x4
    1b7c:      	ld1.s	{ v19 }[1], [x11]
    1b80:      	tbz	w13, #0x2, 0x1930 <ltmp0+0x1930>
    1b84:      	add	x11, x10, #0x8
    1b88:      	ld1.s	{ v19 }[2], [x11]
    1b8c:      	tbz	w13, #0x3, 0x1934 <ltmp0+0x1934>
    1b90:      	add	x11, x10, #0xc
    1b94:      	ld1.s	{ v19 }[3], [x11]
    1b98:      	tbz	w13, #0x4, 0x1938 <ltmp0+0x1938>
    1b9c:      	add	x11, x10, #0x10
    1ba0:      	ld1.s	{ v18 }[0], [x11]
    1ba4:      	tbz	w13, #0x5, 0x193c <ltmp0+0x193c>
    1ba8:      	add	x11, x10, #0x14
    1bac:      	ld1.s	{ v18 }[1], [x11]
    1bb0:      	tbz	w13, #0x6, 0x1940 <ltmp0+0x1940>
    1bb4:      	add	x11, x10, #0x18
    1bb8:      	ld1.s	{ v18 }[2], [x11]
    1bbc:      	tbnz	w13, #0x7, 0x1944 <ltmp0+0x1944>
    1bc0:      	b	0x194c <ltmp0+0x194c>
    1bc4:      	str	s0, [x8]
    1bc8:      	tbz	w9, #0x1, 0x1af4 <ltmp0+0x1af4>
    1bcc:      	add	x10, x8, #0x4
    1bd0:      	st1.s	{ v0 }[1], [x10]
    1bd4:      	tbz	w9, #0x2, 0x1af8 <ltmp0+0x1af8>
    1bd8:      	add	x10, x8, #0x8
    1bdc:      	st1.s	{ v0 }[2], [x10]
    1be0:      	tbz	w9, #0x3, 0x1afc <ltmp0+0x1afc>
    1be4:      	add	x10, x8, #0xc
    1be8:      	st1.s	{ v0 }[3], [x10]
    1bec:      	fdiv.4s	v0, v30, v3
    1bf0:      	fmul.4s	v0, v0, v18
    1bf4:      	tbz	w9, #0x4, 0x1b08 <ltmp0+0x1b08>
    1bf8:      	str	s0, [x8, #0x10]
    1bfc:      	tbz	w9, #0x5, 0x1b0c <ltmp0+0x1b0c>
    1c00:      	add	x10, x8, #0x14
    1c04:      	st1.s	{ v0 }[1], [x10]
    1c08:      	tbz	w9, #0x6, 0x1b10 <ltmp0+0x1b10>
    1c0c:      	add	x10, x8, #0x18
    1c10:      	st1.s	{ v0 }[2], [x10]
    1c14:      	tbz	w9, #0x7, 0x70 <ltmp0+0x70>
    1c18:      	add	x8, x8, #0x1c
    1c1c:      	st1.s	{ v0 }[3], [x8]
    1c20:      	b	0x70 <ltmp0+0x70>
    1c24:      	ldr	x9, [sp, #0x8]
    1c28:      	stp	w7, w13, [x9]
    1c2c:      	str	w12, [x9, #0x8]
    1c30:      	mov	w8, #0x18               ; =24
    1c34:      	str	w8, [x9, #0x24]
    1c38:      	add	sp, sp, #0x2, lsl #12   ; =0x2000
    1c3c:      	add	sp, sp, #0x3e0
    1c40:      	ldp	x29, x30, [sp, #0x90]
    1c44:      	ldp	x20, x19, [sp, #0x80]
    1c48:      	ldp	x22, x21, [sp, #0x70]
    1c4c:      	ldp	x24, x23, [sp, #0x60]
    1c50:      	ldp	x26, x25, [sp, #0x50]
    1c54:      	ldp	x28, x27, [sp, #0x40]
    1c58:      	ldp	d9, d8, [sp, #0x30]
    1c5c:      	ldp	d11, d10, [sp, #0x20]
    1c60:      	ldp	d13, d12, [sp, #0x10]
    1c64:      	ldp	d15, d14, [sp], #0xa0
    1c68:      	ret

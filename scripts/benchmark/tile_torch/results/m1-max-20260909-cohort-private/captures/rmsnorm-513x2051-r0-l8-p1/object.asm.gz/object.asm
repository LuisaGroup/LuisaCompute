
/tmp/luisa-cohort-private.qfZvpM/capture/rmsnorm-513x2051-r0-l8-p1/object/tile_xir_w8_77318_1788916372439921_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x4, lsl #12   ; =0x4000
      2c:      	sub	sp, sp, #0x410
      30:      	str	x0, [sp, #0x58]
      34:      	cbz	w3, 0x1824 <ltmp0+0x1824>
      38:      	mov	w25, #0x0               ; =0
      3c:      	mov	w7, #0x200c             ; =8204
      40:      	add	x26, sp, #0x2, lsl #12  ; =0x2000
      44:      	add	x26, x26, #0x3f0
      48:      	ldp	w9, w8, [x2, #0x2c]
      4c:      	stp	w8, w9, [sp, #0x80]
      50:      	add	x19, sp, #0x3d0
      54:      	ldp	w8, w9, [x2]
      58:      	ldp	w10, w11, [x2, #0x8]
      5c:      	str	x2, [sp, #0x8]
      60:      	str	x11, [sp, #0x78]
      64:      	movi	d8, #0000000000000000
      68:      	str	w3, [sp, #0x88]
      6c:      	b	0xb0 <ltmp0+0xb0>
      70:      	ldr	w25, [sp, #0x8c]
      74:      	add	w8, w20, #0x1
      78:      	ldp	w11, w9, [sp, #0x80]
      7c:      	cmp	w8, w9
      80:      	cset	w9, eq
      84:      	csinc	w8, wzr, w20, eq
      88:      	ldp	w13, w12, [sp, #0x90]
      8c:      	cinc	w10, w13, eq
      90:      	cmp	w10, w11
      94:      	cset	w11, eq
      98:      	ands	w11, w9, w11
      9c:      	csel	w9, wzr, w10, ne
      a0:      	add	w10, w12, w11
      a4:      	add	w25, w25, #0x1
      a8:      	cmp	w25, w3
      ac:      	b.eq	0x1810 <ltmp0+0x1810>
      b0:      	stp	w9, w10, [sp, #0x90]
      b4:      	mov	x13, x8
      b8:      	ubfiz	x8, x8, #5, #32
      bc:      	ldr	x12, [sp, #0x78]
      c0:      	cmp	x8, x12
      c4:      	csel	x9, x8, xzr, ls
      c8:      	subs	x10, x12, x9
      cc:      	cmp	x10, #0x20
      d0:      	mov	w11, #0x20              ; =32
      d4:      	csel	x10, x10, x11, lo
      d8:      	cmp	x12, x9
      dc:      	ccmp	x8, x12, #0x2, hi
      e0:      	csel	x9, x10, xzr, ls
      e4:      	cmp	x9, #0x20
      e8:      	str	x13, [sp, #0x98]
      ec:      	b.lo	0x930 <ltmp0+0x930>
      f0:      	ldr	x8, [sp, #0x58]
      f4:      	ldr	x28, [x8]
      f8:      	ldr	x22, [x8, #0x10]
      fc:      	ldr	x27, [x8, #0x30]
     100:      	ubfiz	w20, w13, #2, #27
     104:      	umull	x23, w20, w7
     108:      	umaddl	x1, w20, w7, x28
     10c:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     110:      	add	x0, x0, #0x3f0
     114:      	mov	w2, #0x2000             ; =8192
     118:      	bl	0x118 <ltmp0+0x118>
     11c:      	mov	x8, #0x0                ; =0
     120:      	add	x21, x23, #0x2, lsl #12 ; =0x2000
     124:      	add	x9, x28, x21
     128:      	add	x10, x9, #0x4
     12c:      	ldr	s0, [x9], #0x8
     130:      	ld1.s	{ v0 }[1], [x10]
     134:      	ld1.s	{ v0 }[2], [x9]
     138:      	str	q0, [sp, #0x130]
     13c:      	str	q0, [sp, #0x43f0]
     140:      	ldr	q0, [sp, #0x23f0]
     144:      	ldr	q1, [sp, #0x2400]
     148:      	fmul.4s	v2, v1, v1
     14c:      	fmul.4s	v3, v0, v0
     150:      	ldr	q0, [sp, #0x2410]
     154:      	ldr	q1, [sp, #0x2420]
     158:      	fmul.4s	v5, v1, v1
     15c:      	fmul.4s	v4, v0, v0
     160:      	ldr	q0, [sp, #0x2430]
     164:      	ldr	q1, [sp, #0x2440]
     168:      	fmul.4s	v6, v1, v1
     16c:      	fmul.4s	v7, v0, v0
     170:      	ldr	q0, [sp, #0x2450]
     174:      	ldr	q1, [sp, #0x2460]
     178:      	fmul.4s	v17, v1, v1
     17c:      	fmul.4s	v16, v0, v0
     180:      	add	x9, x26, x8, lsl #5
     184:      	ldp	q1, q0, [x9, #0x80]
     188:      	fmul.4s	v1, v1, v1
     18c:      	fmul.4s	v0, v0, v0
     190:      	fadd.4s	v2, v2, v0
     194:      	fadd.4s	v3, v3, v1
     198:      	ldp	q1, q0, [x9, #0xa0]
     19c:      	fmul.4s	v1, v1, v1
     1a0:      	fmul.4s	v0, v0, v0
     1a4:      	fadd.4s	v5, v5, v0
     1a8:      	fadd.4s	v4, v4, v1
     1ac:      	ldp	q1, q0, [x9, #0xc0]
     1b0:      	fmul.4s	v1, v1, v1
     1b4:      	fmul.4s	v0, v0, v0
     1b8:      	fadd.4s	v6, v6, v0
     1bc:      	fadd.4s	v7, v7, v1
     1c0:      	ldp	q1, q0, [x9, #0xe0]
     1c4:      	fmul.4s	v1, v1, v1
     1c8:      	fmul.4s	v0, v0, v0
     1cc:      	fadd.4s	v17, v17, v0
     1d0:      	fadd.4s	v16, v16, v1
     1d4:      	add	x8, x8, #0x4
     1d8:      	cmp	x8, #0xfc
     1dc:      	b.lo	0x180 <ltmp0+0x180>
     1e0:      	add	x0, sp, #0x3d0
     1e4:      	mov	x1, x22
     1e8:      	mov	w2, #0x2000             ; =8192
     1ec:      	stp	q5, q2, [sp, #0xc0]
     1f0:      	str	q3, [sp, #0xb0]
     1f4:      	stp	q7, q4, [sp, #0xe0]
     1f8:      	stp	q6, q16, [sp, #0x110]
     1fc:      	str	q17, [sp, #0x100]
     200:      	bl	0x200 <ltmp0+0x200>
     204:      	mov	x8, #0x0                ; =0
     208:      	ldr	q7, [sp, #0x130]
     20c:      	fmul.4s	v0, v7, v7
     210:      	ldp	q1, q2, [sp, #0xb0]
     214:      	fadd.4s	v0, v0, v1
     218:      	mov.s	v0[3], v1[3]
     21c:      	ldr	q1, [sp, #0xd0]
     220:      	fadd.4s	v1, v2, v1
     224:      	ldp	q2, q3, [sp, #0xe0]
     228:      	fadd.4s	v0, v3, v0
     22c:      	fadd.4s	v0, v2, v0
     230:      	ldp	q2, q3, [sp, #0x100]
     234:      	fadd.4s	v1, v3, v1
     238:      	fadd.4s	v1, v2, v1
     23c:      	ldr	q2, [sp, #0x120]
     240:      	fadd.4s	v0, v2, v0
     244:      	rev64.4s	v2, v0
     248:      	rev64.4s	v3, v1
     24c:      	fadd.4s	v0, v0, v2
     250:      	dup.4s	v2, v0[2]
     254:      	fadd.4s	v1, v1, v3
     258:      	dup.4s	v3, v1[2]
     25c:      	fadd.4s	v1, v1, v3
     260:      	fadd.4s	v0, v0, v2
     264:      	fadd.4s	v0, v0, v1
     268:      	fadd	s0, s0, s8
     26c:      	mov	w9, #0x3000             ; =12288
     270:      	movk	w9, #0x4500, lsl #16
     274:      	fmov	s1, w9
     278:      	fdiv	s1, s0, s1
     27c:      	add	x24, x22, #0x2, lsl #12 ; =0x2000
     280:      	mov	w9, #0x2004             ; =8196
     284:      	add	x9, x22, x9
     288:      	ldr	s0, [x22, #0x2000]
     28c:      	ld1.s	{ v0 }[1], [x9]
     290:      	mov	w9, #0x2008             ; =8200
     294:      	add	x9, x22, x9
     298:      	ld1.s	{ v0 }[2], [x9]
     29c:      	str	q0, [sp, #0x23d0]
     2a0:      	mov	w9, #0xc5ac             ; =50604
     2a4:      	movk	w9, #0x3727, lsl #16
     2a8:      	fmov	s2, w9
     2ac:      	fadd	s1, s1, s2
     2b0:      	fsqrt	s1, s1
     2b4:      	dup.4s	v2, v1[0]
     2b8:      	add	x9, x27, x23
     2bc:      	add	x10, x26, x8
     2c0:      	ldp	q3, q4, [x10]
     2c4:      	fdiv.4s	v4, v4, v2
     2c8:      	fdiv.4s	v3, v3, v2
     2cc:      	add	x10, x19, x8
     2d0:      	ldp	q6, q5, [x10]
     2d4:      	fmul.4s	v3, v3, v6
     2d8:      	fmul.4s	v4, v4, v5
     2dc:      	add	x10, x9, x8
     2e0:      	stp	q3, q4, [x10]
     2e4:      	add	x8, x8, #0x20
     2e8:      	cmp	x8, #0x2, lsl #12       ; =0x2000
     2ec:      	b.ne	0x2bc <ltmp0+0x2bc>
     2f0:      	dup.4s	v1, v1[0]
     2f4:      	fdiv.4s	v1, v7, v1
     2f8:      	fmul.4s	v0, v1, v0
     2fc:      	add	x8, x27, x21
     300:      	str	d0, [x8], #0x8
     304:      	st1.s	{ v0 }[2], [x8]
     308:      	orr	w8, w20, #0x1
     30c:      	mov	w9, #0x200c             ; =8204
     310:      	umull	x23, w8, w9
     314:      	umaddl	x1, w8, w9, x28
     318:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     31c:      	add	x0, x0, #0x3f0
     320:      	mov	w2, #0x2000             ; =8192
     324:      	bl	0x324 <ltmp0+0x324>
     328:      	mov	x8, #0x0                ; =0
     32c:      	add	x21, x23, #0x2, lsl #12 ; =0x2000
     330:      	add	x9, x28, x21
     334:      	add	x10, x9, #0x4
     338:      	ldr	s0, [x9], #0x8
     33c:      	ld1.s	{ v0 }[1], [x10]
     340:      	ld1.s	{ v0 }[2], [x9]
     344:      	str	q0, [sp, #0x130]
     348:      	str	q0, [sp, #0x43f0]
     34c:      	ldr	q0, [sp, #0x23f0]
     350:      	ldr	q1, [sp, #0x2400]
     354:      	fmul.4s	v2, v1, v1
     358:      	fmul.4s	v3, v0, v0
     35c:      	ldr	q0, [sp, #0x2410]
     360:      	ldr	q1, [sp, #0x2420]
     364:      	fmul.4s	v5, v1, v1
     368:      	fmul.4s	v4, v0, v0
     36c:      	ldr	q0, [sp, #0x2430]
     370:      	ldr	q1, [sp, #0x2440]
     374:      	fmul.4s	v6, v1, v1
     378:      	fmul.4s	v7, v0, v0
     37c:      	ldr	q0, [sp, #0x2450]
     380:      	ldr	q1, [sp, #0x2460]
     384:      	fmul.4s	v17, v1, v1
     388:      	fmul.4s	v16, v0, v0
     38c:      	add	x9, x26, x8, lsl #5
     390:      	ldp	q1, q0, [x9, #0x80]
     394:      	fmul.4s	v1, v1, v1
     398:      	fmul.4s	v0, v0, v0
     39c:      	fadd.4s	v2, v2, v0
     3a0:      	fadd.4s	v3, v3, v1
     3a4:      	ldp	q1, q0, [x9, #0xa0]
     3a8:      	fmul.4s	v1, v1, v1
     3ac:      	fmul.4s	v0, v0, v0
     3b0:      	fadd.4s	v5, v5, v0
     3b4:      	fadd.4s	v4, v4, v1
     3b8:      	ldp	q1, q0, [x9, #0xc0]
     3bc:      	fmul.4s	v1, v1, v1
     3c0:      	fmul.4s	v0, v0, v0
     3c4:      	fadd.4s	v6, v6, v0
     3c8:      	fadd.4s	v7, v7, v1
     3cc:      	ldp	q1, q0, [x9, #0xe0]
     3d0:      	fmul.4s	v1, v1, v1
     3d4:      	fmul.4s	v0, v0, v0
     3d8:      	fadd.4s	v17, v17, v0
     3dc:      	fadd.4s	v16, v16, v1
     3e0:      	add	x8, x8, #0x4
     3e4:      	cmp	x8, #0xfc
     3e8:      	b.lo	0x38c <ltmp0+0x38c>
     3ec:      	add	x0, sp, #0x3d0
     3f0:      	mov	x1, x22
     3f4:      	mov	w2, #0x2000             ; =8192
     3f8:      	stp	q5, q2, [sp, #0xc0]
     3fc:      	str	q3, [sp, #0xb0]
     400:      	stp	q7, q4, [sp, #0xe0]
     404:      	stp	q6, q16, [sp, #0x110]
     408:      	str	q17, [sp, #0x100]
     40c:      	bl	0x40c <ltmp0+0x40c>
     410:      	mov	x8, #0x0                ; =0
     414:      	ldr	q7, [sp, #0x130]
     418:      	fmul.4s	v0, v7, v7
     41c:      	ldp	q1, q2, [sp, #0xb0]
     420:      	fadd.4s	v0, v0, v1
     424:      	mov.s	v0[3], v1[3]
     428:      	ldr	q1, [sp, #0xd0]
     42c:      	fadd.4s	v1, v2, v1
     430:      	ldp	q2, q3, [sp, #0xe0]
     434:      	fadd.4s	v0, v3, v0
     438:      	fadd.4s	v0, v2, v0
     43c:      	ldp	q2, q3, [sp, #0x100]
     440:      	fadd.4s	v1, v3, v1
     444:      	fadd.4s	v1, v2, v1
     448:      	ldr	q2, [sp, #0x120]
     44c:      	fadd.4s	v0, v2, v0
     450:      	rev64.4s	v2, v0
     454:      	rev64.4s	v3, v1
     458:      	fadd.4s	v1, v1, v3
     45c:      	fadd.4s	v0, v0, v2
     460:      	dup.4s	v2, v0[2]
     464:      	dup.4s	v3, v1[2]
     468:      	fadd.4s	v1, v1, v3
     46c:      	fadd.4s	v0, v0, v2
     470:      	fadd.4s	v0, v0, v1
     474:      	fadd	s0, s0, s8
     478:      	mov	w9, #0x3000             ; =12288
     47c:      	movk	w9, #0x4500, lsl #16
     480:      	fmov	s1, w9
     484:      	fdiv	s1, s0, s1
     488:      	mov	w9, #0x2004             ; =8196
     48c:      	add	x9, x22, x9
     490:      	ldr	s0, [x24]
     494:      	ld1.s	{ v0 }[1], [x9]
     498:      	mov	w9, #0x2008             ; =8200
     49c:      	add	x9, x22, x9
     4a0:      	ld1.s	{ v0 }[2], [x9]
     4a4:      	str	q0, [sp, #0x23d0]
     4a8:      	mov	w9, #0xc5ac             ; =50604
     4ac:      	movk	w9, #0x3727, lsl #16
     4b0:      	fmov	s2, w9
     4b4:      	fadd	s1, s1, s2
     4b8:      	fsqrt	s1, s1
     4bc:      	dup.4s	v2, v1[0]
     4c0:      	add	x9, x27, x23
     4c4:      	add	x10, x26, x8
     4c8:      	ldp	q3, q4, [x10]
     4cc:      	fdiv.4s	v4, v4, v2
     4d0:      	fdiv.4s	v3, v3, v2
     4d4:      	add	x10, x19, x8
     4d8:      	ldp	q6, q5, [x10]
     4dc:      	fmul.4s	v3, v3, v6
     4e0:      	fmul.4s	v4, v4, v5
     4e4:      	add	x10, x9, x8
     4e8:      	stp	q3, q4, [x10]
     4ec:      	add	x8, x8, #0x20
     4f0:      	cmp	x8, #0x2, lsl #12       ; =0x2000
     4f4:      	b.ne	0x4c4 <ltmp0+0x4c4>
     4f8:      	dup.4s	v1, v1[0]
     4fc:      	fdiv.4s	v1, v7, v1
     500:      	fmul.4s	v0, v1, v0
     504:      	add	x8, x27, x21
     508:      	str	d0, [x8], #0x8
     50c:      	st1.s	{ v0 }[2], [x8]
     510:      	orr	w8, w20, #0x2
     514:      	mov	w9, #0x200c             ; =8204
     518:      	umull	x23, w8, w9
     51c:      	umaddl	x1, w8, w9, x28
     520:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     524:      	add	x0, x0, #0x3f0
     528:      	mov	w2, #0x2000             ; =8192
     52c:      	bl	0x52c <ltmp0+0x52c>
     530:      	mov	x8, #0x0                ; =0
     534:      	add	x21, x23, #0x2, lsl #12 ; =0x2000
     538:      	add	x9, x28, x21
     53c:      	add	x10, x9, #0x4
     540:      	ldr	s0, [x9], #0x8
     544:      	ld1.s	{ v0 }[1], [x10]
     548:      	ld1.s	{ v0 }[2], [x9]
     54c:      	str	q0, [sp, #0x130]
     550:      	str	q0, [sp, #0x43f0]
     554:      	ldr	q0, [sp, #0x23f0]
     558:      	ldr	q1, [sp, #0x2400]
     55c:      	fmul.4s	v2, v1, v1
     560:      	fmul.4s	v3, v0, v0
     564:      	ldr	q0, [sp, #0x2410]
     568:      	ldr	q1, [sp, #0x2420]
     56c:      	fmul.4s	v5, v1, v1
     570:      	fmul.4s	v4, v0, v0
     574:      	ldr	q0, [sp, #0x2430]
     578:      	ldr	q1, [sp, #0x2440]
     57c:      	fmul.4s	v6, v1, v1
     580:      	fmul.4s	v7, v0, v0
     584:      	ldr	q0, [sp, #0x2450]
     588:      	ldr	q1, [sp, #0x2460]
     58c:      	fmul.4s	v17, v1, v1
     590:      	fmul.4s	v16, v0, v0
     594:      	add	x9, x26, x8, lsl #5
     598:      	ldp	q1, q0, [x9, #0x80]
     59c:      	fmul.4s	v1, v1, v1
     5a0:      	fmul.4s	v0, v0, v0
     5a4:      	fadd.4s	v2, v2, v0
     5a8:      	fadd.4s	v3, v3, v1
     5ac:      	ldp	q1, q0, [x9, #0xa0]
     5b0:      	fmul.4s	v1, v1, v1
     5b4:      	fmul.4s	v0, v0, v0
     5b8:      	fadd.4s	v5, v5, v0
     5bc:      	fadd.4s	v4, v4, v1
     5c0:      	ldp	q1, q0, [x9, #0xc0]
     5c4:      	fmul.4s	v1, v1, v1
     5c8:      	fmul.4s	v0, v0, v0
     5cc:      	fadd.4s	v6, v6, v0
     5d0:      	fadd.4s	v7, v7, v1
     5d4:      	ldp	q1, q0, [x9, #0xe0]
     5d8:      	fmul.4s	v1, v1, v1
     5dc:      	fmul.4s	v0, v0, v0
     5e0:      	fadd.4s	v17, v17, v0
     5e4:      	fadd.4s	v16, v16, v1
     5e8:      	add	x8, x8, #0x4
     5ec:      	cmp	x8, #0xfc
     5f0:      	b.lo	0x594 <ltmp0+0x594>
     5f4:      	add	x0, sp, #0x3d0
     5f8:      	mov	x1, x22
     5fc:      	mov	w2, #0x2000             ; =8192
     600:      	stp	q5, q2, [sp, #0xc0]
     604:      	str	q3, [sp, #0xb0]
     608:      	stp	q7, q4, [sp, #0xe0]
     60c:      	stp	q6, q16, [sp, #0x110]
     610:      	str	q17, [sp, #0x100]
     614:      	bl	0x614 <ltmp0+0x614>
     618:      	mov	x8, #0x0                ; =0
     61c:      	ldr	q7, [sp, #0x130]
     620:      	fmul.4s	v0, v7, v7
     624:      	ldp	q1, q2, [sp, #0xb0]
     628:      	fadd.4s	v0, v0, v1
     62c:      	mov.s	v0[3], v1[3]
     630:      	ldr	q1, [sp, #0xd0]
     634:      	fadd.4s	v1, v2, v1
     638:      	ldp	q2, q3, [sp, #0xe0]
     63c:      	fadd.4s	v0, v3, v0
     640:      	fadd.4s	v0, v2, v0
     644:      	ldp	q2, q3, [sp, #0x100]
     648:      	fadd.4s	v1, v3, v1
     64c:      	fadd.4s	v1, v2, v1
     650:      	ldr	q2, [sp, #0x120]
     654:      	fadd.4s	v0, v2, v0
     658:      	rev64.4s	v2, v0
     65c:      	rev64.4s	v3, v1
     660:      	fadd.4s	v1, v1, v3
     664:      	fadd.4s	v0, v0, v2
     668:      	dup.4s	v2, v0[2]
     66c:      	dup.4s	v3, v1[2]
     670:      	fadd.4s	v1, v1, v3
     674:      	fadd.4s	v0, v0, v2
     678:      	fadd.4s	v0, v0, v1
     67c:      	fadd	s0, s0, s8
     680:      	mov	w9, #0x3000             ; =12288
     684:      	movk	w9, #0x4500, lsl #16
     688:      	fmov	s1, w9
     68c:      	fdiv	s1, s0, s1
     690:      	mov	w9, #0x2004             ; =8196
     694:      	add	x9, x22, x9
     698:      	ldr	s0, [x24]
     69c:      	ld1.s	{ v0 }[1], [x9]
     6a0:      	mov	w9, #0x2008             ; =8200
     6a4:      	add	x9, x22, x9
     6a8:      	ld1.s	{ v0 }[2], [x9]
     6ac:      	str	q0, [sp, #0x23d0]
     6b0:      	mov	w9, #0xc5ac             ; =50604
     6b4:      	movk	w9, #0x3727, lsl #16
     6b8:      	fmov	s2, w9
     6bc:      	fadd	s1, s1, s2
     6c0:      	fsqrt	s1, s1
     6c4:      	dup.4s	v2, v1[0]
     6c8:      	add	x9, x27, x23
     6cc:      	add	x10, x26, x8
     6d0:      	ldp	q3, q4, [x10]
     6d4:      	fdiv.4s	v4, v4, v2
     6d8:      	fdiv.4s	v3, v3, v2
     6dc:      	add	x10, x19, x8
     6e0:      	ldp	q6, q5, [x10]
     6e4:      	fmul.4s	v3, v3, v6
     6e8:      	fmul.4s	v4, v4, v5
     6ec:      	add	x10, x9, x8
     6f0:      	stp	q3, q4, [x10]
     6f4:      	add	x8, x8, #0x20
     6f8:      	cmp	x8, #0x2, lsl #12       ; =0x2000
     6fc:      	b.ne	0x6cc <ltmp0+0x6cc>
     700:      	dup.4s	v1, v1[0]
     704:      	fdiv.4s	v1, v7, v1
     708:      	fmul.4s	v0, v1, v0
     70c:      	add	x8, x27, x21
     710:      	str	d0, [x8], #0x8
     714:      	st1.s	{ v0 }[2], [x8]
     718:      	orr	w8, w20, #0x3
     71c:      	mov	w9, #0x200c             ; =8204
     720:      	umull	x21, w8, w9
     724:      	umaddl	x1, w8, w9, x28
     728:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     72c:      	add	x0, x0, #0x3f0
     730:      	mov	w2, #0x2000             ; =8192
     734:      	bl	0x734 <ltmp0+0x734>
     738:      	mov	x8, #0x0                ; =0
     73c:      	add	x20, x21, #0x2, lsl #12 ; =0x2000
     740:      	add	x9, x28, x20
     744:      	add	x10, x9, #0x4
     748:      	ldr	s0, [x9], #0x8
     74c:      	ld1.s	{ v0 }[1], [x10]
     750:      	ld1.s	{ v0 }[2], [x9]
     754:      	str	q0, [sp, #0x130]
     758:      	str	q0, [sp, #0x43f0]
     75c:      	ldr	q0, [sp, #0x23f0]
     760:      	ldr	q1, [sp, #0x2400]
     764:      	fmul.4s	v2, v1, v1
     768:      	fmul.4s	v3, v0, v0
     76c:      	ldr	q0, [sp, #0x2410]
     770:      	ldr	q1, [sp, #0x2420]
     774:      	fmul.4s	v5, v1, v1
     778:      	fmul.4s	v4, v0, v0
     77c:      	ldr	q0, [sp, #0x2430]
     780:      	ldr	q1, [sp, #0x2440]
     784:      	fmul.4s	v6, v1, v1
     788:      	fmul.4s	v7, v0, v0
     78c:      	ldr	q0, [sp, #0x2450]
     790:      	ldr	q1, [sp, #0x2460]
     794:      	fmul.4s	v17, v1, v1
     798:      	fmul.4s	v16, v0, v0
     79c:      	add	x9, x26, x8, lsl #5
     7a0:      	ldp	q1, q0, [x9, #0x80]
     7a4:      	fmul.4s	v1, v1, v1
     7a8:      	fmul.4s	v0, v0, v0
     7ac:      	fadd.4s	v2, v2, v0
     7b0:      	fadd.4s	v3, v3, v1
     7b4:      	ldp	q1, q0, [x9, #0xa0]
     7b8:      	fmul.4s	v1, v1, v1
     7bc:      	fmul.4s	v0, v0, v0
     7c0:      	fadd.4s	v5, v5, v0
     7c4:      	fadd.4s	v4, v4, v1
     7c8:      	ldp	q1, q0, [x9, #0xc0]
     7cc:      	fmul.4s	v1, v1, v1
     7d0:      	fmul.4s	v0, v0, v0
     7d4:      	fadd.4s	v6, v6, v0
     7d8:      	fadd.4s	v7, v7, v1
     7dc:      	ldp	q1, q0, [x9, #0xe0]
     7e0:      	fmul.4s	v1, v1, v1
     7e4:      	fmul.4s	v0, v0, v0
     7e8:      	fadd.4s	v17, v17, v0
     7ec:      	fadd.4s	v16, v16, v1
     7f0:      	add	x8, x8, #0x4
     7f4:      	cmp	x8, #0xfc
     7f8:      	b.lo	0x79c <ltmp0+0x79c>
     7fc:      	add	x0, sp, #0x3d0
     800:      	mov	x1, x22
     804:      	mov	w2, #0x2000             ; =8192
     808:      	stp	q5, q2, [sp, #0xc0]
     80c:      	str	q3, [sp, #0xb0]
     810:      	stp	q7, q4, [sp, #0xe0]
     814:      	stp	q6, q16, [sp, #0x110]
     818:      	str	q17, [sp, #0x100]
     81c:      	bl	0x81c <ltmp0+0x81c>
     820:      	mov	x8, #0x0                ; =0
     824:      	ldr	q7, [sp, #0x130]
     828:      	fmul.4s	v0, v7, v7
     82c:      	ldp	q1, q2, [sp, #0xb0]
     830:      	fadd.4s	v0, v0, v1
     834:      	mov.s	v0[3], v1[3]
     838:      	ldr	q1, [sp, #0xd0]
     83c:      	fadd.4s	v1, v2, v1
     840:      	ldp	q2, q3, [sp, #0xe0]
     844:      	fadd.4s	v0, v3, v0
     848:      	fadd.4s	v0, v2, v0
     84c:      	ldp	q2, q3, [sp, #0x100]
     850:      	fadd.4s	v1, v3, v1
     854:      	fadd.4s	v1, v2, v1
     858:      	ldr	q2, [sp, #0x120]
     85c:      	fadd.4s	v0, v2, v0
     860:      	rev64.4s	v2, v0
     864:      	rev64.4s	v3, v1
     868:      	fadd.4s	v1, v1, v3
     86c:      	fadd.4s	v0, v0, v2
     870:      	dup.4s	v2, v0[2]
     874:      	dup.4s	v3, v1[2]
     878:      	fadd.4s	v1, v1, v3
     87c:      	fadd.4s	v0, v0, v2
     880:      	fadd.4s	v0, v0, v1
     884:      	fadd	s0, s0, s8
     888:      	mov	w9, #0x3000             ; =12288
     88c:      	movk	w9, #0x4500, lsl #16
     890:      	fmov	s1, w9
     894:      	fdiv	s1, s0, s1
     898:      	ldr	s0, [x24]
     89c:      	mov	w9, #0x2004             ; =8196
     8a0:      	add	x9, x22, x9
     8a4:      	mov	w10, #0x2008            ; =8200
     8a8:      	add	x10, x22, x10
     8ac:      	ld1.s	{ v0 }[1], [x9]
     8b0:      	ld1.s	{ v0 }[2], [x10]
     8b4:      	str	q0, [sp, #0x23d0]
     8b8:      	mov	w9, #0xc5ac             ; =50604
     8bc:      	movk	w9, #0x3727, lsl #16
     8c0:      	fmov	s2, w9
     8c4:      	fadd	s1, s1, s2
     8c8:      	fsqrt	s1, s1
     8cc:      	dup.4s	v2, v1[0]
     8d0:      	add	x9, x27, x21
     8d4:      	add	x10, x26, x8
     8d8:      	ldp	q3, q4, [x10]
     8dc:      	fdiv.4s	v4, v4, v2
     8e0:      	fdiv.4s	v3, v3, v2
     8e4:      	add	x10, x19, x8
     8e8:      	ldp	q6, q5, [x10]
     8ec:      	fmul.4s	v3, v3, v6
     8f0:      	fmul.4s	v4, v4, v5
     8f4:      	add	x10, x9, x8
     8f8:      	stp	q3, q4, [x10]
     8fc:      	add	x8, x8, #0x20
     900:      	cmp	x8, #0x2, lsl #12       ; =0x2000
     904:      	b.ne	0x8d4 <ltmp0+0x8d4>
     908:      	dup.4s	v1, v1[0]
     90c:      	fdiv.4s	v1, v7, v1
     910:      	fmul.4s	v0, v1, v0
     914:      	add	x8, x27, x20
     918:      	str	d0, [x8], #0x8
     91c:      	st1.s	{ v0 }[2], [x8]
     920:      	mov	w7, #0x200c             ; =8204
     924:      	ldr	x20, [sp, #0x98]
     928:      	ldr	w3, [sp, #0x88]
     92c:      	b	0x74 <ltmp0+0x74>
     930:      	str	w25, [sp, #0x8c]
     934:      	lsr	x8, x9, #3
     938:      	str	x8, [sp, #0xa0]
     93c:      	str	x9, [sp, #0x60]
     940:      	cmp	x9, #0x8
     944:      	b.lo	0xb90 <ltmp0+0xb90>
     948:      	mov	x27, #0x0               ; =0
     94c:      	ldr	x8, [sp, #0x58]
     950:      	ldr	x28, [x8]
     954:      	ldr	x22, [x8, #0x10]
     958:      	ldr	x21, [x8, #0x30]
     95c:      	add	x23, x22, #0x2, lsl #12 ; =0x2000
     960:      	ldr	x8, [sp, #0x98]
     964:      	lsl	w25, w8, #2
     968:      	and	x8, x8, #0x7ffffff
     96c:      	mov	w9, #0x8030             ; =32816
     970:      	umaddl	x24, w8, w9, x21
     974:      	add	w8, w27, w25
     978:      	and	x8, x8, #0x1fffffff
     97c:      	umull	x20, w8, w7
     980:      	umaddl	x1, w8, w7, x28
     984:      	add	x0, sp, #0x2, lsl #12   ; =0x2000
     988:      	add	x0, x0, #0x3f0
     98c:      	mov	w2, #0x2000             ; =8192
     990:      	bl	0x990 <ltmp0+0x990>
     994:      	mov	x8, #0x0                ; =0
     998:      	add	x20, x20, #0x2, lsl #12 ; =0x2000
     99c:      	add	x9, x28, x20
     9a0:      	add	x10, x9, #0x4
     9a4:      	ldr	s0, [x9], #0x8
     9a8:      	ld1.s	{ v0 }[1], [x10]
     9ac:      	ld1.s	{ v0 }[2], [x9]
     9b0:      	str	q0, [sp, #0x130]
     9b4:      	str	q0, [sp, #0x43f0]
     9b8:      	ldr	q0, [sp, #0x23f0]
     9bc:      	ldr	q1, [sp, #0x2400]
     9c0:      	fmul.4s	v2, v1, v1
     9c4:      	fmul.4s	v3, v0, v0
     9c8:      	ldr	q0, [sp, #0x2410]
     9cc:      	ldr	q1, [sp, #0x2420]
     9d0:      	fmul.4s	v5, v1, v1
     9d4:      	fmul.4s	v4, v0, v0
     9d8:      	ldr	q0, [sp, #0x2430]
     9dc:      	ldr	q1, [sp, #0x2440]
     9e0:      	fmul.4s	v6, v1, v1
     9e4:      	fmul.4s	v7, v0, v0
     9e8:      	ldr	q0, [sp, #0x2450]
     9ec:      	ldr	q1, [sp, #0x2460]
     9f0:      	fmul.4s	v17, v1, v1
     9f4:      	fmul.4s	v16, v0, v0
     9f8:      	add	x9, x26, x8, lsl #5
     9fc:      	ldp	q1, q0, [x9, #0x80]
     a00:      	fmul.4s	v1, v1, v1
     a04:      	fmul.4s	v0, v0, v0
     a08:      	fadd.4s	v2, v2, v0
     a0c:      	fadd.4s	v3, v3, v1
     a10:      	ldp	q1, q0, [x9, #0xa0]
     a14:      	fmul.4s	v1, v1, v1
     a18:      	fmul.4s	v0, v0, v0
     a1c:      	fadd.4s	v5, v5, v0
     a20:      	fadd.4s	v4, v4, v1
     a24:      	ldp	q1, q0, [x9, #0xc0]
     a28:      	fmul.4s	v1, v1, v1
     a2c:      	fmul.4s	v0, v0, v0
     a30:      	fadd.4s	v6, v6, v0
     a34:      	fadd.4s	v7, v7, v1
     a38:      	ldp	q1, q0, [x9, #0xe0]
     a3c:      	fmul.4s	v1, v1, v1
     a40:      	fmul.4s	v0, v0, v0
     a44:      	fadd.4s	v17, v17, v0
     a48:      	fadd.4s	v16, v16, v1
     a4c:      	add	x8, x8, #0x4
     a50:      	cmp	x8, #0xfc
     a54:      	b.lo	0x9f8 <ltmp0+0x9f8>
     a58:      	add	x0, sp, #0x3d0
     a5c:      	mov	x1, x22
     a60:      	mov	w2, #0x2000             ; =8192
     a64:      	stp	q5, q2, [sp, #0xc0]
     a68:      	str	q3, [sp, #0xb0]
     a6c:      	stp	q7, q4, [sp, #0xe0]
     a70:      	stp	q6, q16, [sp, #0x110]
     a74:      	str	q17, [sp, #0x100]
     a78:      	bl	0xa78 <ltmp0+0xa78>
     a7c:      	mov	x8, #0x0                ; =0
     a80:      	ldr	q7, [sp, #0x130]
     a84:      	fmul.4s	v0, v7, v7
     a88:      	ldp	q1, q2, [sp, #0xb0]
     a8c:      	fadd.4s	v0, v0, v1
     a90:      	mov.s	v0[3], v1[3]
     a94:      	ldr	q1, [sp, #0xd0]
     a98:      	fadd.4s	v1, v2, v1
     a9c:      	ldp	q2, q3, [sp, #0xe0]
     aa0:      	fadd.4s	v0, v3, v0
     aa4:      	fadd.4s	v0, v2, v0
     aa8:      	ldp	q2, q3, [sp, #0x100]
     aac:      	fadd.4s	v1, v3, v1
     ab0:      	fadd.4s	v1, v2, v1
     ab4:      	ldr	q2, [sp, #0x120]
     ab8:      	fadd.4s	v0, v2, v0
     abc:      	rev64.4s	v2, v0
     ac0:      	rev64.4s	v3, v1
     ac4:      	fadd.4s	v1, v1, v3
     ac8:      	fadd.4s	v0, v0, v2
     acc:      	dup.4s	v2, v0[2]
     ad0:      	dup.4s	v3, v1[2]
     ad4:      	fadd.4s	v1, v1, v3
     ad8:      	fadd.4s	v0, v0, v2
     adc:      	fadd.4s	v0, v0, v1
     ae0:      	fadd	s0, s0, s8
     ae4:      	mov	w9, #0x3000             ; =12288
     ae8:      	movk	w9, #0x4500, lsl #16
     aec:      	fmov	s1, w9
     af0:      	fdiv	s1, s0, s1
     af4:      	mov	w9, #0x2004             ; =8196
     af8:      	add	x9, x22, x9
     afc:      	ldr	s0, [x23]
     b00:      	ld1.s	{ v0 }[1], [x9]
     b04:      	mov	w9, #0x2008             ; =8200
     b08:      	add	x9, x22, x9
     b0c:      	ld1.s	{ v0 }[2], [x9]
     b10:      	str	q0, [sp, #0x23d0]
     b14:      	mov	w9, #0xc5ac             ; =50604
     b18:      	movk	w9, #0x3727, lsl #16
     b1c:      	fmov	s2, w9
     b20:      	fadd	s1, s1, s2
     b24:      	fsqrt	s1, s1
     b28:      	dup.4s	v2, v1[0]
     b2c:      	add	x9, x26, x8
     b30:      	ldp	q3, q4, [x9]
     b34:      	fdiv.4s	v4, v4, v2
     b38:      	fdiv.4s	v3, v3, v2
     b3c:      	add	x9, x19, x8
     b40:      	ldp	q6, q5, [x9]
     b44:      	fmul.4s	v3, v3, v6
     b48:      	fmul.4s	v4, v4, v5
     b4c:      	add	x9, x24, x8
     b50:      	stp	q3, q4, [x9]
     b54:      	add	x8, x8, #0x20
     b58:      	cmp	x8, #0x2, lsl #12       ; =0x2000
     b5c:      	b.ne	0xb2c <ltmp0+0xb2c>
     b60:      	dup.4s	v1, v1[0]
     b64:      	fdiv.4s	v1, v7, v1
     b68:      	fmul.4s	v0, v1, v0
     b6c:      	add	x8, x21, x20
     b70:      	str	d0, [x8], #0x8
     b74:      	st1.s	{ v0 }[2], [x8]
     b78:      	add	x27, x27, #0x1
     b7c:      	mov	w7, #0x200c             ; =8204
     b80:      	add	x24, x24, x7
     b84:      	ldr	x8, [sp, #0xa0]
     b88:      	cmp	x27, x8
     b8c:      	b.ne	0x974 <ltmp0+0x974>
     b90:      	ldr	x8, [sp, #0x60]
     b94:      	and	w8, w8, #0x7
     b98:      	ldp	w3, w25, [sp, #0x88]
     b9c:      	ldr	x20, [sp, #0x98]
     ba0:      	cbz	w8, 0x74 <ltmp0+0x74>
     ba4:      	dup.4s	v1, w8
     ba8:      	adrp	x8, 0x0 <ltmp0>
     bac:      	ldr	q2, [x8]
     bb0:      	adrp	x8, 0x0 <ltmp0>
     bb4:      	ldr	q0, [x8]
     bb8:      	cmhi.4s	v0, v1, v0
     bbc:      	cmhi.4s	v1, v1, v2
     bc0:      	uzp1.8h	v4, v1, v0
     bc4:      	umaxv.8h	h2, v4
     bc8:      	fmov	w8, s2
     bcc:      	mov	w17, #0x4               ; =4
     bd0:      	tbz	w8, #0x0, 0x70 <ltmp0+0x70>
     bd4:      	mov	x9, #0x0                ; =0
     bd8:      	ldr	x8, [sp, #0x58]
     bdc:      	ldr	x12, [x8]
     be0:      	ldr	x10, [x8, #0x10]
     be4:      	ldr	x8, [x8, #0x30]
     be8:      	adrp	x11, 0x0 <ltmp0>
     bec:      	ldr	q2, [x11]
     bf0:      	and.16b	v2, v4, v2
     bf4:      	addv.8h	h2, v2
     bf8:      	ubfiz	w11, w20, #2, #27
     bfc:      	ldr	x13, [sp, #0xa0]
     c00:      	orr	w13, w11, w13
     c04:      	fmov	w11, s2
     c08:      	and	w11, w11, #0xff
     c0c:      	dup.4s	v3, w13
     c10:      	and.16b	v5, v1, v3
     c14:      	and.16b	v6, v0, v3
     c18:      	ushll2.2d	v16, v6, #0x0
     c1c:      	ushll2.2d	v3, v5, #0x0
     c20:      	ushll.2d	v17, v6, #0x0
     c24:      	ushll.2d	v5, v5, #0x0
     c28:      	fmov	x13, d5
     c2c:      	umaddl	x13, w13, w7, x12
     c30:      	b	0xc54 <ltmp0+0xc54>
     c34:      	add	x14, x26, x9
     c38:      	ldp	q18, q19, [x14]
     c3c:      	bif.16b	v7, v19, v0
     c40:      	bif.16b	v6, v18, v1
     c44:      	stp	q6, q7, [x14]
     c48:      	add	x9, x9, #0x20
     c4c:      	cmp	x9, #0x2, lsl #12       ; =0x2000
     c50:      	b.eq	0xcec <ltmp0+0xcec>
     c54:      	fmov	w15, s2
     c58:      	add	x14, x13, x9
     c5c:      	movi.2d	v6, #0000000000000000
     c60:      	movi.2d	v7, #0000000000000000
     c64:      	tbnz	w15, #0x0, 0xc8c <ltmp0+0xc8c>
     c68:      	and	w15, w15, #0xff
     c6c:      	tbnz	w15, #0x1, 0xc98 <ltmp0+0xc98>
     c70:      	tbnz	w15, #0x2, 0xca4 <ltmp0+0xca4>
     c74:      	tbnz	w15, #0x3, 0xcb0 <ltmp0+0xcb0>
     c78:      	tbnz	w15, #0x4, 0xcbc <ltmp0+0xcbc>
     c7c:      	tbnz	w15, #0x5, 0xcc8 <ltmp0+0xcc8>
     c80:      	tbnz	w15, #0x6, 0xcd4 <ltmp0+0xcd4>
     c84:      	tbz	w15, #0x7, 0xc34 <ltmp0+0xc34>
     c88:      	b	0xce0 <ltmp0+0xce0>
     c8c:      	ldr	s6, [x14]
     c90:      	and	w15, w15, #0xff
     c94:      	tbz	w15, #0x1, 0xc70 <ltmp0+0xc70>
     c98:      	add	x16, x14, #0x4
     c9c:      	ld1.s	{ v6 }[1], [x16]
     ca0:      	tbz	w15, #0x2, 0xc74 <ltmp0+0xc74>
     ca4:      	add	x16, x14, #0x8
     ca8:      	ld1.s	{ v6 }[2], [x16]
     cac:      	tbz	w15, #0x3, 0xc78 <ltmp0+0xc78>
     cb0:      	add	x16, x14, #0xc
     cb4:      	ld1.s	{ v6 }[3], [x16]
     cb8:      	tbz	w15, #0x4, 0xc7c <ltmp0+0xc7c>
     cbc:      	add	x16, x14, #0x10
     cc0:      	ld1.s	{ v7 }[0], [x16]
     cc4:      	tbz	w15, #0x5, 0xc80 <ltmp0+0xc80>
     cc8:      	add	x16, x14, #0x14
     ccc:      	ld1.s	{ v7 }[1], [x16]
     cd0:      	tbz	w15, #0x6, 0xc84 <ltmp0+0xc84>
     cd4:      	add	x16, x14, #0x18
     cd8:      	ld1.s	{ v7 }[2], [x16]
     cdc:      	tbz	w15, #0x7, 0xc34 <ltmp0+0xc34>
     ce0:      	add	x14, x14, #0x1c
     ce4:      	ld1.s	{ v7 }[3], [x14]
     ce8:      	b	0xc34 <ltmp0+0xc34>
     cec:      	xtn.8b	v25, v4
     cf0:      	sshll.2d	v18, v1, #0x0
     cf4:      	sshll2.2d	v21, v1, #0x0
     cf8:      	adrp	x9, 0x0 <ltmp0>
     cfc:      	ldr	q4, [x9]
     d00:      	and.16b	v19, v21, v4
     d04:      	adrp	x9, 0x0 <ltmp0>
     d08:      	ldr	q4, [x9]
     d0c:      	and.16b	v6, v18, v4
     d10:      	movi	d4, #0x00000000ffffff
     d14:      	and.8b	v7, v25, v4
     d18:      	adrp	x9, 0x0 <ltmp0>
     d1c:      	ldr	d4, [x9]
     d20:      	and.8b	v4, v25, v4
     d24:      	addv.8b	b4, v4
     d28:      	fmov	w13, s4
     d2c:      	umaxv.8b	b4, v7
     d30:      	fmov	w9, s4
     d34:      	rbit	w14, w13
     d38:      	clz	w14, w14
     d3c:      	tst	w9, #0x1
     d40:      	mov	w9, #0x800              ; =2048
     d44:      	dup.2d	v20, x9
     d48:      	csel	w9, w14, wzr, ne
     d4c:      	stp	q6, q19, [sp, #0x30]
     d50:      	orr.16b	v6, v6, v20
     d54:      	orr.16b	v4, v19, v20
     d58:      	mov	w14, #0x803             ; =2051
     d5c:      	dup.2s	v19, w14
     d60:      	xtn.2s	v23, v5
     d64:      	xtn.2s	v3, v3
     d68:      	str	q4, [sp, #0xd0]
     d6c:      	mov.16b	v5, v4
     d70:      	umlal.2d	v5, v3, v19
     d74:      	str	q6, [sp, #0xb0]
     d78:      	mov.16b	v4, v6
     d7c:      	umlal.2d	v4, v23, v19
     d80:      	mov	b3, v7[0]
     d84:      	mov.b	v3[4], v7[1]
     d88:      	ushll.2d	v3, v3, #0x0
     d8c:      	shl.2d	v3, v3, #0x3f
     d90:      	cmlt.2d	v3, v3, #0
     d94:      	stp	q4, q5, [sp, #0x120]
     d98:      	and.16b	v3, v3, v4
     d9c:      	mov	b4, v7[2]
     da0:      	mov.b	v4[4], v7[3]
     da4:      	ushll.2d	v4, v4, #0x0
     da8:      	shl.2d	v4, v4, #0x3f
     dac:      	cmlt.2d	v4, v4, #0
     db0:      	and.16b	v4, v4, v5
     db4:      	movi.2d	v5, #0000000000000000
     db8:      	stp	q5, q5, [sp, #0x3a0]
     dbc:      	stp	q3, q4, [sp, #0x380]
     dc0:      	and	x14, x9, #0x7
     dc4:      	add	x15, sp, #0x380
     dc8:      	ldr	x14, [x15, x14, lsl #3]
     dcc:      	sub	x14, x14, x9
     dd0:      	add	x12, x12, x14, lsl #2
     dd4:      	movi.2d	v6, #0000000000000000
     dd8:      	tbnz	w13, #0x0, 0x1708 <ltmp0+0x1708>
     ddc:      	tbnz	w13, #0x1, 0x1710 <ltmp0+0x1710>
     de0:      	tbnz	w13, #0x2, 0x171c <ltmp0+0x171c>
     de4:      	tbnz	w13, #0x3, 0x1728 <ltmp0+0x1728>
     de8:      	tbnz	w13, #0x4, 0x1734 <ltmp0+0x1734>
     dec:      	tbnz	w13, #0x5, 0x1740 <ltmp0+0x1740>
     df0:      	tbnz	w13, #0x6, 0x174c <ltmp0+0x174c>
     df4:      	tbz	w13, #0x7, 0xe00 <ltmp0+0xe00>
     df8:      	add	x12, x12, #0x1c
     dfc:      	ld1.s	{ v5 }[3], [x12]
     e00:      	sshll.2d	v3, v0, #0x0
     e04:      	sshll2.2d	v22, v0, #0x0
     e08:      	adrp	x12, 0x0 <ltmp0>
     e0c:      	ldr	q4, [x12]
     e10:      	and.16b	v28, v22, v4
     e14:      	adrp	x12, 0x0 <ltmp0>
     e18:      	ldr	q4, [x12]
     e1c:      	and.16b	v27, v3, v4
     e20:      	adrp	x12, 0x0 <ltmp0>
     e24:      	ldr	q4, [x12]
     e28:      	and.16b	v4, v22, v4
     e2c:      	adrp	x12, 0x0 <ltmp0>
     e30:      	ldr	q24, [x12]
     e34:      	and.16b	v24, v21, v24
     e38:      	adrp	x12, 0x0 <ltmp0>
     e3c:      	ldr	q26, [x12]
     e40:      	and.16b	v3, v3, v26
     e44:      	adrp	x12, 0x0 <ltmp0>
     e48:      	ldr	q26, [x12]
     e4c:      	and.16b	v18, v18, v26
     e50:      	stp	q27, q28, [sp, #0x10]
     e54:      	orr.16b	v27, v27, v20
     e58:      	orr.16b	v26, v28, v20
     e5c:      	umull.2d	v20, v23, v19
     e60:      	str	q20, [sp, #0xc0]
     e64:      	xtn.2s	v17, v17
     e68:      	xtn.2s	v16, v16
     e6c:      	str	q26, [sp, #0xa0]
     e70:      	mov.16b	v20, v26
     e74:      	umlal.2d	v20, v16, v19
     e78:      	str	q27, [sp, #0x60]
     e7c:      	mov.16b	v16, v27
     e80:      	umlal.2d	v16, v17, v19
     e84:      	stp	q16, q20, [sp, #0xe0]
     e88:      	sshll.2d	v19, v1, #0x0
     e8c:      	sshll.2d	v20, v0, #0x0
     e90:      	stp	q18, q24, [sp, #0x340]
     e94:      	stp	q3, q4, [sp, #0x360]
     e98:      	and	x12, x9, #0x7
     e9c:      	add	x14, sp, #0x340
     ea0:      	ldr	x12, [x14, x12, lsl #3]
     ea4:      	orr	x12, x12, #0x2000
     ea8:      	sub	x12, x12, x9, lsl #2
     eac:      	tst	w13, #0xff
     eb0:      	csel	x12, xzr, x12, eq
     eb4:      	add	x13, x26, x12
     eb8:      	ldp	q3, q4, [x13]
     ebc:      	zip2.8b	v16, v7, v0
     ec0:      	ushll.4s	v16, v16, #0x0
     ec4:      	shl.4s	v16, v16, #0x1f
     ec8:      	cmlt.4s	v16, v16, #0
     ecc:      	stp	q6, q5, [sp, #0x100]
     ed0:      	bit.16b	v4, v5, v16
     ed4:      	zip1.8b	v16, v7, v0
     ed8:      	ushll.4s	v16, v16, #0x0
     edc:      	shl.4s	v16, v16, #0x1f
     ee0:      	cmlt.4s	v16, v16, #0
     ee4:      	bit.16b	v3, v6, v16
     ee8:      	stp	q3, q4, [x13]
     eec:      	dup.2d	v3, x17
     ef0:      	and.16b	v16, v22, v3
     ef4:      	and.16b	v17, v21, v3
     ef8:      	and.16b	v23, v20, v3
     efc:      	and.16b	v24, v19, v3
     f00:      	fmov	x13, d24
     f04:      	ldr	q3, [sp, #0x2460]
     f08:      	ldr	q4, [sp, #0x2450]
     f0c:      	fmul.4s	v4, v4, v4
     f10:      	fmul.4s	v3, v3, v3
     f14:      	and.16b	v11, v0, v3
     f18:      	and.16b	v12, v1, v4
     f1c:      	ldr	q3, [sp, #0x2440]
     f20:      	ldr	q4, [sp, #0x2430]
     f24:      	fmul.4s	v4, v4, v4
     f28:      	fmul.4s	v3, v3, v3
     f2c:      	and.16b	v14, v0, v3
     f30:      	and.16b	v13, v1, v4
     f34:      	ldr	q3, [sp, #0x2420]
     f38:      	ldr	q4, [sp, #0x2410]
     f3c:      	fmul.4s	v4, v4, v4
     f40:      	fmul.4s	v3, v3, v3
     f44:      	and.16b	v15, v0, v3
     f48:      	and.16b	v9, v1, v4
     f4c:      	fmov	x14, d18
     f50:      	add	x14, x26, x14
     f54:      	ldp	q4, q3, [x14]
     f58:      	fmul.4s	v4, v4, v4
     f5c:      	fmul.4s	v3, v3, v3
     f60:      	and.16b	v19, v0, v3
     f64:      	and.16b	v10, v1, v4
     f68:      	sshll.2d	v3, v1, #0x0
     f6c:      	sshll.2d	v4, v0, #0x0
     f70:      	add	x13, x26, x13, lsl #5
     f74:      	ldp	q20, q18, [x13]
     f78:      	and.16b	v20, v1, v20
     f7c:      	and.16b	v18, v0, v18
     f80:      	fmul.4s	v26, v18, v18
     f84:      	fmul.4s	v18, v20, v20
     f88:      	fadd.4s	v18, v10, v18
     f8c:      	fadd.4s	v20, v19, v26
     f90:      	ldp	q27, q26, [x13, #0x20]
     f94:      	and.16b	v27, v1, v27
     f98:      	and.16b	v26, v0, v26
     f9c:      	fmul.4s	v26, v26, v26
     fa0:      	fmul.4s	v27, v27, v27
     fa4:      	fadd.4s	v27, v9, v27
     fa8:      	fadd.4s	v26, v15, v26
     fac:      	ldp	q29, q28, [x13, #0x40]
     fb0:      	and.16b	v29, v1, v29
     fb4:      	and.16b	v28, v0, v28
     fb8:      	fmul.4s	v28, v28, v28
     fbc:      	fmul.4s	v29, v29, v29
     fc0:      	fadd.4s	v29, v13, v29
     fc4:      	fadd.4s	v28, v14, v28
     fc8:      	ldp	q30, q6, [x13, #0x60]
     fcc:      	and.16b	v30, v1, v30
     fd0:      	and.16b	v6, v0, v6
     fd4:      	fmul.4s	v6, v6, v6
     fd8:      	fmul.4s	v30, v30, v30
     fdc:      	fadd.4s	v30, v12, v30
     fe0:      	fadd.4s	v6, v11, v6
     fe4:      	dup.2d	v31, x17
     fe8:      	and.16b	v5, v22, v31
     fec:      	add.2d	v16, v16, v5
     ff0:      	and.16b	v5, v21, v31
     ff4:      	add.2d	v17, v17, v5
     ff8:      	and.16b	v4, v4, v31
     ffc:      	add.2d	v23, v23, v4
    1000:      	and.16b	v3, v3, v31
    1004:      	add.2d	v24, v24, v3
    1008:      	bit.16b	v19, v20, v0
    100c:      	bit.16b	v10, v18, v1
    1010:      	bit.16b	v15, v26, v0
    1014:      	bit.16b	v9, v27, v1
    1018:      	bit.16b	v14, v28, v0
    101c:      	bit.16b	v13, v29, v1
    1020:      	bit.16b	v11, v6, v0
    1024:      	bit.16b	v12, v30, v1
    1028:      	fmov	x13, d24
    102c:      	cmp	x13, #0x100
    1030:      	b.lt	0xf68 <ltmp0+0xf68>
    1034:      	mov	x13, #0x0               ; =0
    1038:      	mov	w14, #0x1               ; =1
    103c:      	dup.2d	v3, x14
    1040:      	ushll2.2d	v4, v0, #0x0
    1044:      	and.16b	v21, v4, v3
    1048:      	ushll2.2d	v4, v1, #0x0
    104c:      	and.16b	v22, v4, v3
    1050:      	ushll.2d	v4, v0, #0x0
    1054:      	and.16b	v23, v4, v3
    1058:      	ushll.2d	v4, v1, #0x0
    105c:      	and.16b	v24, v4, v3
    1060:      	movi.2d	v16, #0000000000000000
    1064:      	movi.2d	v17, #0000000000000000
    1068:      	movi.2d	v26, #0000000000000000
    106c:      	movi.2d	v27, #0000000000000000
    1070:      	ldp	q30, q29, [sp, #0x100]
    1074:      	b	0x10a8 <ltmp0+0x10a8>
    1078:      	add	x13, x19, x13
    107c:      	ldp	q5, q6, [x13]
    1080:      	bif.16b	v4, v6, v0
    1084:      	bif.16b	v3, v5, v1
    1088:      	stp	q3, q4, [x13]
    108c:      	add.2d	v17, v17, v22
    1090:      	add.2d	v26, v26, v23
    1094:      	add.2d	v27, v27, v21
    1098:      	add.2d	v16, v16, v24
    109c:      	fmov	x13, d16
    10a0:      	cmp	x13, #0x100
    10a4:      	b.ge	0x1144 <ltmp0+0x1144>
    10a8:      	fmov	w15, s2
    10ac:      	lsl	x13, x13, #5
    10b0:      	add	x14, x10, x13
    10b4:      	movi.2d	v3, #0000000000000000
    10b8:      	movi.2d	v4, #0000000000000000
    10bc:      	tbnz	w15, #0x0, 0x10e4 <ltmp0+0x10e4>
    10c0:      	and	w15, w15, #0xff
    10c4:      	tbnz	w15, #0x1, 0x10f0 <ltmp0+0x10f0>
    10c8:      	tbnz	w15, #0x2, 0x10fc <ltmp0+0x10fc>
    10cc:      	tbnz	w15, #0x3, 0x1108 <ltmp0+0x1108>
    10d0:      	tbnz	w15, #0x4, 0x1114 <ltmp0+0x1114>
    10d4:      	tbnz	w15, #0x5, 0x1120 <ltmp0+0x1120>
    10d8:      	tbnz	w15, #0x6, 0x112c <ltmp0+0x112c>
    10dc:      	tbz	w15, #0x7, 0x1078 <ltmp0+0x1078>
    10e0:      	b	0x1138 <ltmp0+0x1138>
    10e4:      	ldr	s3, [x14]
    10e8:      	and	w15, w15, #0xff
    10ec:      	tbz	w15, #0x1, 0x10c8 <ltmp0+0x10c8>
    10f0:      	add	x16, x14, #0x4
    10f4:      	ld1.s	{ v3 }[1], [x16]
    10f8:      	tbz	w15, #0x2, 0x10cc <ltmp0+0x10cc>
    10fc:      	add	x16, x14, #0x8
    1100:      	ld1.s	{ v3 }[2], [x16]
    1104:      	tbz	w15, #0x3, 0x10d0 <ltmp0+0x10d0>
    1108:      	add	x16, x14, #0xc
    110c:      	ld1.s	{ v3 }[3], [x16]
    1110:      	tbz	w15, #0x4, 0x10d4 <ltmp0+0x10d4>
    1114:      	add	x16, x14, #0x10
    1118:      	ld1.s	{ v4 }[0], [x16]
    111c:      	tbz	w15, #0x5, 0x10d8 <ltmp0+0x10d8>
    1120:      	add	x16, x14, #0x14
    1124:      	ld1.s	{ v4 }[1], [x16]
    1128:      	tbz	w15, #0x6, 0x10dc <ltmp0+0x10dc>
    112c:      	add	x16, x14, #0x18
    1130:      	ld1.s	{ v4 }[2], [x16]
    1134:      	tbz	w15, #0x7, 0x1078 <ltmp0+0x1078>
    1138:      	add	x14, x14, #0x1c
    113c:      	ld1.s	{ v4 }[3], [x14]
    1140:      	b	0x1078 <ltmp0+0x1078>
    1144:      	movi	d3, #0xffffffffff000000
    1148:      	and.8b	v3, v25, v3
    114c:      	fmul.4s	v4, v30, v30
    1150:      	fmul.4s	v5, v29, v29
    1154:      	fadd.4s	v5, v5, v19
    1158:      	fadd.4s	v4, v4, v10
    115c:      	zip1.8b	v6, v7, v0
    1160:      	ushll.4s	v6, v6, #0x0
    1164:      	shl.4s	v6, v6, #0x1f
    1168:      	cmlt.4s	v6, v6, #0
    116c:      	and.16b	v4, v6, v4
    1170:      	zip2.8b	v6, v7, v0
    1174:      	ushll.4s	v6, v6, #0x0
    1178:      	shl.4s	v6, v6, #0x1f
    117c:      	cmlt.4s	v6, v6, #0
    1180:      	and.16b	v5, v6, v5
    1184:      	zip2.8b	v6, v3, v0
    1188:      	ushll.4s	v6, v6, #0x0
    118c:      	shl.4s	v6, v6, #0x1f
    1190:      	cmlt.4s	v6, v6, #0
    1194:      	bit.16b	v5, v20, v6
    1198:      	zip1.8b	v3, v3, v0
    119c:      	ushll.4s	v3, v3, #0x0
    11a0:      	shl.4s	v3, v3, #0x1f
    11a4:      	cmlt.4s	v3, v3, #0
    11a8:      	bsl.16b	v3, v18, v4
    11ac:      	fadd.4s	v3, v9, v3
    11b0:      	fadd.4s	v4, v15, v5
    11b4:      	fadd.4s	v4, v14, v4
    11b8:      	fadd.4s	v3, v13, v3
    11bc:      	fadd.4s	v19, v12, v3
    11c0:      	fadd.4s	v20, v11, v4
    11c4:      	ldp	q4, q3, [sp, #0x30]
    11c8:      	uzp1.4s	v18, v4, v3
    11cc:      	ldp	q4, q3, [sp, #0x10]
    11d0:      	uzp1.4s	v28, v4, v3
    11d4:      	movi.4s	v4, #0x1
    11d8:      	eor.16b	v3, v18, v4
    11dc:      	mov.s	w14, v3[1]
    11e0:      	mov.s	w17, v3[2]
    11e4:      	eor.16b	v4, v28, v4
    11e8:      	mov.s	w0, v3[3]
    11ec:      	fmov	w13, s3
    11f0:      	add	x15, sp, #0x188
    11f4:      	bfxil	x15, x13, #0, #3
    11f8:      	str	d25, [sp, #0x188]
    11fc:      	ldrb	w16, [x15]
    1200:      	and	x15, x13, #0x7
    1204:      	umov.b	w13, v25[0]
    1208:      	stp	q19, q20, [sp, #0x290]
    120c:      	add	x1, sp, #0x290
    1210:      	ldr	s3, [x1, x15, lsl #2]
    1214:      	ands	w15, w13, #0x1
    1218:      	tst	w15, w16
    121c:      	fcsel	s16, s3, s8, ne
    1220:      	add	x16, sp, #0x188
    1224:      	bfxil	x16, x14, #0, #3
    1228:      	ldrb	w16, [x16]
    122c:      	and	x1, x14, #0x7
    1230:      	umov.b	w14, v25[1]
    1234:      	stp	q19, q20, [sp, #0x270]
    1238:      	add	x2, sp, #0x270
    123c:      	ldr	s3, [x2, x1, lsl #2]
    1240:      	ands	w1, w14, #0x1
    1244:      	tst	w1, w16
    1248:      	fcsel	s17, s3, s8, ne
    124c:      	add	x16, sp, #0x188
    1250:      	bfxil	x16, x17, #0, #3
    1254:      	ldrb	w1, [x16]
    1258:      	umov.b	w16, v25[2]
    125c:      	and	x17, x17, #0x7
    1260:      	stp	q19, q20, [sp, #0x250]
    1264:      	add	x2, sp, #0x250
    1268:      	ldr	s3, [x2, x17, lsl #2]
    126c:      	ands	w17, w16, #0x1
    1270:      	tst	w17, w1
    1274:      	fcsel	s3, s3, s8, ne
    1278:      	add	x17, sp, #0x188
    127c:      	bfxil	x17, x0, #0, #3
    1280:      	ldrb	w1, [x17]
    1284:      	and	x0, x0, #0x7
    1288:      	umov.b	w17, v25[3]
    128c:      	stp	q19, q20, [sp, #0x230]
    1290:      	add	x2, sp, #0x230
    1294:      	ldr	s5, [x2, x0, lsl #2]
    1298:      	ands	w0, w17, #0x1
    129c:      	tst	w0, w1
    12a0:      	mov.s	w1, v4[1]
    12a4:      	mov.s	w2, v4[2]
    12a8:      	fcsel	s26, s5, s8, ne
    12ac:      	mov.s	w4, v4[3]
    12b0:      	fmov	w0, s4
    12b4:      	and	x21, x0, #0x7
    12b8:      	add	x5, sp, #0x188
    12bc:      	bfxil	x5, x0, #0, #3
    12c0:      	ldrb	w5, [x5]
    12c4:      	umov.b	w0, v25[4]
    12c8:      	and	w5, w0, w5
    12cc:      	stp	q19, q20, [sp, #0x310]
    12d0:      	add	x6, sp, #0x310
    12d4:      	ldr	s4, [x6, x21, lsl #2]
    12d8:      	tst	w5, #0x1
    12dc:      	fcsel	s4, s4, s8, ne
    12e0:      	add	x5, sp, #0x188
    12e4:      	bfxil	x5, x1, #0, #3
    12e8:      	ldrb	w21, [x5]
    12ec:      	and	x5, x1, #0x7
    12f0:      	umov.b	w1, v25[5]
    12f4:      	stp	q19, q20, [sp, #0x2f0]
    12f8:      	add	x6, sp, #0x2f0
    12fc:      	ldr	s5, [x6, x5, lsl #2]
    1300:      	ands	w5, w1, #0x1
    1304:      	tst	w5, w21
    1308:      	fcsel	s5, s5, s8, ne
    130c:      	add	x5, sp, #0x188
    1310:      	bfxil	x5, x2, #0, #3
    1314:      	ldrb	w21, [x5]
    1318:      	and	x5, x2, #0x7
    131c:      	umov.b	w2, v25[6]
    1320:      	stp	q19, q20, [sp, #0x2d0]
    1324:      	add	x6, sp, #0x2d0
    1328:      	ldr	s6, [x6, x5, lsl #2]
    132c:      	ands	w5, w2, #0x1
    1330:      	tst	w5, w21
    1334:      	fcsel	s6, s6, s8, ne
    1338:      	add	x5, sp, #0x188
    133c:      	bfxil	x5, x4, #0, #3
    1340:      	ldrb	w5, [x5]
    1344:      	umov.b	w21, v25[7]
    1348:      	and	x4, x4, #0x7
    134c:      	stp	q19, q20, [sp, #0x2b0]
    1350:      	add	x6, sp, #0x2b0
    1354:      	ldr	s25, [x6, x4, lsl #2]
    1358:      	ands	w4, w21, #0x1
    135c:      	tst	w4, w5
    1360:      	fcsel	s25, s25, s8, ne
    1364:      	mov.s	v4[1], v5[0]
    1368:      	mov.s	v4[2], v6[0]
    136c:      	mov.s	v4[3], v25[0]
    1370:      	mov.s	v16[1], v17[0]
    1374:      	mov.s	v16[2], v3[0]
    1378:      	mov.s	v16[3], v26[0]
    137c:      	fadd.4s	v3, v19, v16
    1380:      	fadd.4s	v4, v20, v4
    1384:      	movi.4s	v6, #0x2
    1388:      	eor.16b	v5, v28, v6
    138c:      	eor.16b	v6, v18, v6
    1390:      	fmov	w4, s6
    1394:      	add	x5, sp, #0x188
    1398:      	bfxil	x5, x4, #0, #3
    139c:      	ldrb	w5, [x5]
    13a0:      	and	x4, x4, #0x7
    13a4:      	stp	q3, q4, [sp, #0x210]
    13a8:      	add	x6, sp, #0x210
    13ac:      	ldr	s6, [x6, x4, lsl #2]
    13b0:      	tst	w15, w5
    13b4:      	fcsel	s6, s6, s8, ne
    13b8:      	fmov	w4, s5
    13bc:      	and	x5, x4, #0x7
    13c0:      	add	x6, sp, #0x188
    13c4:      	bfxil	x6, x4, #0, #3
    13c8:      	ldrb	w4, [x6]
    13cc:      	and	w4, w0, w4
    13d0:      	stp	q3, q4, [sp, #0x1f0]
    13d4:      	add	x6, sp, #0x1f0
    13d8:      	ldr	s5, [x6, x5, lsl #2]
    13dc:      	tst	w4, #0x1
    13e0:      	fcsel	s5, s5, s8, ne
    13e4:      	fadd.4s	v4, v4, v5
    13e8:      	tst	w15, w0
    13ec:      	fcsel	s4, s4, s8, ne
    13f0:      	ands	w13, w13, #0x1
    13f4:      	fadd.4s	v3, v3, v6
    13f8:      	fadd	s3, s3, s4
    13fc:      	fcsel	s4, s3, s8, ne
    1400:      	tst	w14, #0x1
    1404:      	fcsel	s5, s4, s8, ne
    1408:      	tst	w16, #0x1
    140c:      	fcsel	s6, s4, s8, ne
    1410:      	tst	w17, #0x1
    1414:      	fcsel	s16, s4, s8, ne
    1418:      	tst	w13, w0
    141c:      	fcsel	s3, s3, s8, ne
    1420:      	tst	w1, #0x1
    1424:      	fcsel	s17, s4, s8, ne
    1428:      	tst	w2, #0x1
    142c:      	fcsel	s18, s4, s8, ne
    1430:      	tst	w21, #0x1
    1434:      	adrp	x13, 0x1000 <ltmp0+0x1000>
    1438:      	ldr	d19, [x13]
    143c:      	shl.8b	v20, v7, #0x7
    1440:      	cmlt.8b	v20, v20, #0
    1444:      	and.8b	v19, v20, v19
    1448:      	addv.8b	b25, v19
    144c:      	fmov	w13, s25
    1450:      	fcsel	s19, s4, s8, ne
    1454:      	mov.s	v4[1], v5[0]
    1458:      	mov.s	v4[2], v6[0]
    145c:      	mov.s	v4[3], v16[0]
    1460:      	mov.s	v3[1], v17[0]
    1464:      	mov.s	v3[2], v18[0]
    1468:      	mov.s	v3[3], v19[0]
    146c:      	rbit	w11, w11
    1470:      	clz	w11, w11
    1474:      	stp	q4, q3, [sp, #0x1d0]
    1478:      	and	x11, x11, #0x7
    147c:      	add	x14, sp, #0x1d0
    1480:      	ldr	s20, [x14, x11, lsl #2]
    1484:      	mov	b3, v7[0]
    1488:      	mov.b	v3[4], v7[1]
    148c:      	ushll.2d	v3, v3, #0x0
    1490:      	shl.2d	v3, v3, #0x3f
    1494:      	cmlt.2d	v3, v3, #0
    1498:      	mov	b4, v7[2]
    149c:      	mov.b	v4[4], v7[3]
    14a0:      	ldp	q16, q5, [sp, #0xa0]
    14a4:      	and.16b	v3, v3, v5
    14a8:      	ushll.2d	v4, v4, #0x0
    14ac:      	shl.2d	v4, v4, #0x3f
    14b0:      	cmlt.2d	v4, v4, #0
    14b4:      	ldr	q5, [sp, #0xd0]
    14b8:      	and.16b	v4, v4, v5
    14bc:      	mov	b5, v7[4]
    14c0:      	mov.b	v5[4], v7[5]
    14c4:      	ushll.2d	v5, v5, #0x0
    14c8:      	shl.2d	v5, v5, #0x3f
    14cc:      	cmlt.2d	v5, v5, #0
    14d0:      	ldr	q6, [sp, #0x60]
    14d4:      	and.16b	v5, v5, v6
    14d8:      	mov	b6, v7[6]
    14dc:      	mov.b	v6[4], v7[7]
    14e0:      	ushll.2d	v6, v6, #0x0
    14e4:      	shl.2d	v6, v6, #0x3f
    14e8:      	cmlt.2d	v6, v6, #0
    14ec:      	and.16b	v6, v6, v16
    14f0:      	stp	q5, q6, [sp, #0x1b0]
    14f4:      	stp	q3, q4, [sp, #0x190]
    14f8:      	and	x11, x9, #0x7
    14fc:      	add	x14, sp, #0x190
    1500:      	ldr	x11, [x14, x11, lsl #3]
    1504:      	sub	x11, x11, x9
    1508:      	add	x10, x10, x11, lsl #2
    150c:      	movi.2d	v19, #0000000000000000
    1510:      	movi.2d	v18, #0000000000000000
    1514:      	tbnz	w13, #0x0, 0x175c <ltmp0+0x175c>
    1518:      	tbnz	w13, #0x1, 0x1764 <ltmp0+0x1764>
    151c:      	tbnz	w13, #0x2, 0x1770 <ltmp0+0x1770>
    1520:      	tbnz	w13, #0x3, 0x177c <ltmp0+0x177c>
    1524:      	tbnz	w13, #0x4, 0x1788 <ltmp0+0x1788>
    1528:      	tbnz	w13, #0x5, 0x1794 <ltmp0+0x1794>
    152c:      	tbnz	w13, #0x6, 0x17a0 <ltmp0+0x17a0>
    1530:      	tbz	w13, #0x7, 0x153c <ltmp0+0x153c>
    1534:      	add	x10, x10, #0x1c
    1538:      	ld1.s	{ v18 }[3], [x10]
    153c:      	mov	x11, #0x0               ; =0
    1540:      	fadd	s3, s20, s8
    1544:      	mov	w10, #0x3000            ; =12288
    1548:      	movk	w10, #0x4500, lsl #16
    154c:      	fmov	s4, w10
    1550:      	fdiv	s3, s3, s4
    1554:      	add	x10, x19, x12
    1558:      	ldp	q4, q5, [x10]
    155c:      	zip2.8b	v6, v7, v0
    1560:      	ushll.4s	v6, v6, #0x0
    1564:      	shl.4s	v6, v6, #0x1f
    1568:      	cmlt.4s	v6, v6, #0
    156c:      	bit.16b	v5, v18, v6
    1570:      	zip1.8b	v6, v7, v0
    1574:      	ushll.4s	v6, v6, #0x0
    1578:      	shl.4s	v6, v6, #0x1f
    157c:      	cmlt.4s	v6, v6, #0
    1580:      	bit.16b	v4, v19, v6
    1584:      	stp	q4, q5, [x10]
    1588:      	mov	w10, #0xc5ac            ; =50604
    158c:      	movk	w10, #0x3727, lsl #16
    1590:      	fmov	s4, w10
    1594:      	fadd	s3, s3, s4
    1598:      	fsqrt	s3, s3
    159c:      	dup.4s	v7, v3[0]
    15a0:      	ldr	q3, [sp, #0xc0]
    15a4:      	fmov	x10, d3
    15a8:      	add	x10, x8, x10, lsl #2
    15ac:      	movi.2d	v3, #0000000000000000
    15b0:      	movi.2d	v4, #0000000000000000
    15b4:      	movi.2d	v16, #0000000000000000
    15b8:      	movi.2d	v17, #0000000000000000
    15bc:      	b	0x15dc <ltmp0+0x15dc>
    15c0:      	add.2d	v4, v4, v22
    15c4:      	add.2d	v16, v16, v23
    15c8:      	add.2d	v17, v17, v21
    15cc:      	add.2d	v3, v3, v24
    15d0:      	fmov	x11, d3
    15d4:      	cmp	x11, #0x100
    15d8:      	b.ge	0x16ac <ltmp0+0x16ac>
    15dc:      	fmov	w12, s2
    15e0:      	lsl	x11, x11, #5
    15e4:      	add	x13, x26, x11
    15e8:      	ldp	q5, q20, [x13]
    15ec:      	and.16b	v5, v1, v5
    15f0:      	fdiv.4s	v5, v5, v7
    15f4:      	add	x13, x19, x11
    15f8:      	ldp	q6, q26, [x13]
    15fc:      	and.16b	v6, v1, v6
    1600:      	fmul.4s	v27, v5, v6
    1604:      	add	x11, x10, x11
    1608:      	tbnz	w12, #0x0, 0x1640 <ltmp0+0x1640>
    160c:      	and	w12, w12, #0xff
    1610:      	tbnz	w12, #0x1, 0x164c <ltmp0+0x164c>
    1614:      	tbnz	w12, #0x2, 0x1658 <ltmp0+0x1658>
    1618:      	tbnz	w12, #0x3, 0x1664 <ltmp0+0x1664>
    161c:      	and.16b	v5, v0, v20
    1620:      	fdiv.4s	v5, v5, v7
    1624:      	and.16b	v6, v0, v26
    1628:      	fmul.4s	v20, v5, v6
    162c:      	tbnz	w12, #0x4, 0x1680 <ltmp0+0x1680>
    1630:      	tbnz	w12, #0x5, 0x1688 <ltmp0+0x1688>
    1634:      	tbnz	w12, #0x6, 0x1694 <ltmp0+0x1694>
    1638:      	tbz	w12, #0x7, 0x15c0 <ltmp0+0x15c0>
    163c:      	b	0x16a0 <ltmp0+0x16a0>
    1640:      	str	s27, [x11]
    1644:      	and	w12, w12, #0xff
    1648:      	tbz	w12, #0x1, 0x1614 <ltmp0+0x1614>
    164c:      	add	x13, x11, #0x4
    1650:      	st1.s	{ v27 }[1], [x13]
    1654:      	tbz	w12, #0x2, 0x1618 <ltmp0+0x1618>
    1658:      	add	x13, x11, #0x8
    165c:      	st1.s	{ v27 }[2], [x13]
    1660:      	tbz	w12, #0x3, 0x161c <ltmp0+0x161c>
    1664:      	add	x13, x11, #0xc
    1668:      	st1.s	{ v27 }[3], [x13]
    166c:      	and.16b	v5, v0, v20
    1670:      	fdiv.4s	v5, v5, v7
    1674:      	and.16b	v6, v0, v26
    1678:      	fmul.4s	v20, v5, v6
    167c:      	tbz	w12, #0x4, 0x1630 <ltmp0+0x1630>
    1680:      	str	s20, [x11, #0x10]
    1684:      	tbz	w12, #0x5, 0x1634 <ltmp0+0x1634>
    1688:      	add	x13, x11, #0x14
    168c:      	st1.s	{ v20 }[1], [x13]
    1690:      	tbz	w12, #0x6, 0x1638 <ltmp0+0x1638>
    1694:      	add	x13, x11, #0x18
    1698:      	st1.s	{ v20 }[2], [x13]
    169c:      	tbz	w12, #0x7, 0x15c0 <ltmp0+0x15c0>
    16a0:      	add	x11, x11, #0x1c
    16a4:      	st1.s	{ v20 }[3], [x11]
    16a8:      	b	0x15c0 <ltmp0+0x15c0>
    16ac:      	fdiv.4s	v0, v30, v7
    16b0:      	fmul.4s	v0, v0, v19
    16b4:      	ldp	q2, q1, [sp, #0x120]
    16b8:      	stp	q2, q1, [sp, #0x140]
    16bc:      	ldp	q2, q1, [sp, #0xe0]
    16c0:      	stp	q2, q1, [sp, #0x160]
    16c4:      	and	x10, x9, #0x7
    16c8:      	add	x11, sp, #0x140
    16cc:      	ldr	x10, [x11, x10, lsl #3]
    16d0:      	sub	x9, x10, x9
    16d4:      	add	x8, x8, x9, lsl #2
    16d8:      	fmov	w9, s25
    16dc:      	tbnz	w9, #0x0, 0x17b0 <ltmp0+0x17b0>
    16e0:      	tbnz	w9, #0x1, 0x17b8 <ltmp0+0x17b8>
    16e4:      	tbnz	w9, #0x2, 0x17c4 <ltmp0+0x17c4>
    16e8:      	tbnz	w9, #0x3, 0x17d0 <ltmp0+0x17d0>
    16ec:      	fdiv.4s	v0, v29, v7
    16f0:      	fmul.4s	v0, v0, v18
    16f4:      	tbnz	w9, #0x4, 0x17e4 <ltmp0+0x17e4>
    16f8:      	tbnz	w9, #0x5, 0x17ec <ltmp0+0x17ec>
    16fc:      	tbnz	w9, #0x6, 0x17f8 <ltmp0+0x17f8>
    1700:      	tbz	w9, #0x7, 0x70 <ltmp0+0x70>
    1704:      	b	0x1804 <ltmp0+0x1804>
    1708:      	ldr	s6, [x12]
    170c:      	tbz	w13, #0x1, 0xde0 <ltmp0+0xde0>
    1710:      	add	x14, x12, #0x4
    1714:      	ld1.s	{ v6 }[1], [x14]
    1718:      	tbz	w13, #0x2, 0xde4 <ltmp0+0xde4>
    171c:      	add	x14, x12, #0x8
    1720:      	ld1.s	{ v6 }[2], [x14]
    1724:      	tbz	w13, #0x3, 0xde8 <ltmp0+0xde8>
    1728:      	add	x14, x12, #0xc
    172c:      	ld1.s	{ v6 }[3], [x14]
    1730:      	tbz	w13, #0x4, 0xdec <ltmp0+0xdec>
    1734:      	add	x14, x12, #0x10
    1738:      	ld1.s	{ v5 }[0], [x14]
    173c:      	tbz	w13, #0x5, 0xdf0 <ltmp0+0xdf0>
    1740:      	add	x14, x12, #0x14
    1744:      	ld1.s	{ v5 }[1], [x14]
    1748:      	tbz	w13, #0x6, 0xdf4 <ltmp0+0xdf4>
    174c:      	add	x14, x12, #0x18
    1750:      	ld1.s	{ v5 }[2], [x14]
    1754:      	tbnz	w13, #0x7, 0xdf8 <ltmp0+0xdf8>
    1758:      	b	0xe00 <ltmp0+0xe00>
    175c:      	ldr	s19, [x10]
    1760:      	tbz	w13, #0x1, 0x151c <ltmp0+0x151c>
    1764:      	add	x11, x10, #0x4
    1768:      	ld1.s	{ v19 }[1], [x11]
    176c:      	tbz	w13, #0x2, 0x1520 <ltmp0+0x1520>
    1770:      	add	x11, x10, #0x8
    1774:      	ld1.s	{ v19 }[2], [x11]
    1778:      	tbz	w13, #0x3, 0x1524 <ltmp0+0x1524>
    177c:      	add	x11, x10, #0xc
    1780:      	ld1.s	{ v19 }[3], [x11]
    1784:      	tbz	w13, #0x4, 0x1528 <ltmp0+0x1528>
    1788:      	add	x11, x10, #0x10
    178c:      	ld1.s	{ v18 }[0], [x11]
    1790:      	tbz	w13, #0x5, 0x152c <ltmp0+0x152c>
    1794:      	add	x11, x10, #0x14
    1798:      	ld1.s	{ v18 }[1], [x11]
    179c:      	tbz	w13, #0x6, 0x1530 <ltmp0+0x1530>
    17a0:      	add	x11, x10, #0x18
    17a4:      	ld1.s	{ v18 }[2], [x11]
    17a8:      	tbnz	w13, #0x7, 0x1534 <ltmp0+0x1534>
    17ac:      	b	0x153c <ltmp0+0x153c>
    17b0:      	str	s0, [x8]
    17b4:      	tbz	w9, #0x1, 0x16e4 <ltmp0+0x16e4>
    17b8:      	add	x10, x8, #0x4
    17bc:      	st1.s	{ v0 }[1], [x10]
    17c0:      	tbz	w9, #0x2, 0x16e8 <ltmp0+0x16e8>
    17c4:      	add	x10, x8, #0x8
    17c8:      	st1.s	{ v0 }[2], [x10]
    17cc:      	tbz	w9, #0x3, 0x16ec <ltmp0+0x16ec>
    17d0:      	add	x10, x8, #0xc
    17d4:      	st1.s	{ v0 }[3], [x10]
    17d8:      	fdiv.4s	v0, v29, v7
    17dc:      	fmul.4s	v0, v0, v18
    17e0:      	tbz	w9, #0x4, 0x16f8 <ltmp0+0x16f8>
    17e4:      	str	s0, [x8, #0x10]
    17e8:      	tbz	w9, #0x5, 0x16fc <ltmp0+0x16fc>
    17ec:      	add	x10, x8, #0x14
    17f0:      	st1.s	{ v0 }[1], [x10]
    17f4:      	tbz	w9, #0x6, 0x1700 <ltmp0+0x1700>
    17f8:      	add	x10, x8, #0x18
    17fc:      	st1.s	{ v0 }[2], [x10]
    1800:      	tbz	w9, #0x7, 0x70 <ltmp0+0x70>
    1804:      	add	x8, x8, #0x1c
    1808:      	st1.s	{ v0 }[3], [x8]
    180c:      	b	0x70 <ltmp0+0x70>
    1810:      	ldr	x9, [sp, #0x8]
    1814:      	stp	w20, w13, [x9]
    1818:      	str	w12, [x9, #0x8]
    181c:      	mov	w8, #0x18               ; =24
    1820:      	str	w8, [x9, #0x24]
    1824:      	add	sp, sp, #0x4, lsl #12   ; =0x4000
    1828:      	add	sp, sp, #0x410
    182c:      	ldp	x29, x30, [sp, #0x90]
    1830:      	ldp	x20, x19, [sp, #0x80]
    1834:      	ldp	x22, x21, [sp, #0x70]
    1838:      	ldp	x24, x23, [sp, #0x60]
    183c:      	ldp	x26, x25, [sp, #0x50]
    1840:      	ldp	x28, x27, [sp, #0x40]
    1844:      	ldp	d9, d8, [sp, #0x30]
    1848:      	ldp	d11, d10, [sp, #0x20]
    184c:      	ldp	d13, d12, [sp, #0x10]
    1850:      	ldp	d15, d14, [sp], #0xa0
    1854:      	ret

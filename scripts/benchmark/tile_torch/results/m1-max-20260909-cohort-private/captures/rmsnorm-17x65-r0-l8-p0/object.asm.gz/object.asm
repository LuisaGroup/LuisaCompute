
/tmp/luisa-cohort-private.qfZvpM/capture/rmsnorm-17x65-r0-l8-p0/object/tile_xir_w8_77306_1788916367403824_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x7b0
      2c:      	str	x0, [sp, #0x150]
      30:      	str	w3, [sp, #0x168]
      34:      	cbz	w3, 0x2f44 <ltmp0+0x2f44>
      38:      	mov	w12, #0x0               ; =0
      3c:      	add	x8, sp, #0x570
      40:      	add	x9, sp, #0x690
      44:      	ldp	w11, w10, [x2, #0x2c]
      48:      	str	w11, [sp, #0x15c]
      4c:      	str	w10, [sp, #0x158]
      50:      	mov	w15, #0x4               ; =4
      54:      	adrp	x16, 0x0 <ltmp0>
      58:      	adrp	x17, 0x0 <ltmp0>
      5c:      	dup.2d	v0, x8
      60:      	adrp	x1, 0x0 <ltmp0>
      64:      	adrp	x4, 0x0 <ltmp0>
      68:      	adrp	x5, 0x0 <ltmp0>
      6c:      	adrp	x6, 0x0 <ltmp0>
      70:      	dup.2d	v1, x9
      74:      	adrp	x7, 0x0 <ltmp0>
      78:      	adrp	x19, 0x0 <ltmp0>
      7c:      	adrp	x20, 0x0 <ltmp0>
      80:      	adrp	x21, 0x0 <ltmp0>
      84:      	dup.2d	v2, x15
      88:      	str	q2, [sp, #0x140]
      8c:      	adrp	x22, 0x0 <ltmp0>
      90:      	adrp	x9, 0x0 <ltmp0>
      94:      	ldr	q3, [x9]
      98:      	adrp	x23, 0x0 <ltmp0>
      9c:      	adrp	x9, 0x0 <ltmp0>
      a0:      	ldr	q4, [x9]
      a4:      	adrp	x24, 0x0 <ltmp0>
      a8:      	adrp	x25, 0x0 <ltmp0>
      ac:      	mov	w26, #0x1               ; =1
      b0:      	movi	d12, #0000000000000000
      b4:      	ldp	w11, w10, [x2, #0x4]
      b8:      	ldr	w9, [x2]
      bc:      	str	x2, [sp, #0x160]
      c0:      	str	q3, [sp, #0x260]
      c4:      	b	0x10c <ltmp0+0x10c>
      c8:      	add	w8, w0, #0x1
      cc:      	ldr	w9, [sp, #0x15c]
      d0:      	cmp	w8, w9
      d4:      	cset	w8, eq
      d8:      	csinc	w9, wzr, w0, eq
      dc:      	cinc	w10, w14, eq
      e0:      	ldr	w11, [sp, #0x158]
      e4:      	cmp	w10, w11
      e8:      	cset	w11, eq
      ec:      	ands	w8, w8, w11
      f0:      	csel	w11, wzr, w10, ne
      f4:      	add	w10, w13, w8
      f8:      	add	w12, w12, #0x1
      fc:      	ldr	w8, [sp, #0x168]
     100:      	cmp	w12, w8
     104:      	ldr	x2, [sp, #0x160]
     108:      	b.eq	0x2f34 <ltmp0+0x2f34>
     10c:      	str	w12, [sp, #0x174]
     110:      	str	w10, [sp, #0x170]
     114:      	str	w11, [sp, #0x16c]
     118:      	mov	x14, x9
     11c:      	ldr	w9, [x2, #0xc]
     120:      	ubfiz	x10, x14, #5, #32
     124:      	cmp	x10, x9
     128:      	csel	x11, x10, xzr, ls
     12c:      	subs	x12, x9, x11
     130:      	cmp	x12, #0x20
     134:      	mov	w8, #0x20               ; =32
     138:      	csel	x12, x12, x8, lo
     13c:      	cmp	x9, x11
     140:      	ccmp	x10, x9, #0x2, hi
     144:      	csel	x9, x12, xzr, ls
     148:      	cmp	x9, #0x20
     14c:      	str	x14, [sp, #0x178]
     150:      	b.lo	0x1570 <ltmp0+0x1570>
     154:      	ldr	x8, [sp, #0x150]
     158:      	ldr	x3, [x8]
     15c:      	ldr	x13, [x8, #0x10]
     160:      	ubfiz	w11, w14, #2, #27
     164:      	mov	w9, #0x104              ; =260
     168:      	umull	x10, w11, w9
     16c:      	str	w11, [sp, #0x200]
     170:      	umaddl	x9, w11, w9, x3
     174:      	ldp	q2, q5, [x9]
     178:      	str	q5, [sp, #0x6a0]
     17c:      	str	q2, [sp, #0x690]
     180:      	ldp	q6, q7, [x9, #0x20]
     184:      	str	q7, [sp, #0x6c0]
     188:      	str	q6, [sp, #0x6b0]
     18c:      	ldp	q16, q17, [x9, #0x40]
     190:      	str	q17, [sp, #0x6e0]
     194:      	str	q16, [sp, #0x6d0]
     198:      	ldp	q18, q19, [x9, #0x60]
     19c:      	str	q19, [sp, #0x700]
     1a0:      	str	q18, [sp, #0x6f0]
     1a4:      	ldp	q20, q21, [x9, #0x80]
     1a8:      	str	q21, [sp, #0x720]
     1ac:      	str	q20, [sp, #0x710]
     1b0:      	ldp	q20, q21, [x9, #0xa0]
     1b4:      	str	q21, [sp, #0x740]
     1b8:      	str	q20, [sp, #0x730]
     1bc:      	ldp	q20, q21, [x9, #0xc0]
     1c0:      	str	q21, [sp, #0x760]
     1c4:      	str	q20, [sp, #0x750]
     1c8:      	ldp	q20, q21, [x9, #0xe0]
     1cc:      	str	q21, [sp, #0x780]
     1d0:      	str	q20, [sp, #0x770]
     1d4:      	add	x9, x10, #0x100
     1d8:      	ldr	s20, [x3, x9]
     1dc:      	fmul.4s	v5, v5, v5
     1e0:      	fmul.4s	v2, v2, v2
     1e4:      	ldr	x12, [x8, #0x30]
     1e8:      	str	q20, [sp, #0x290]
     1ec:      	str	q20, [sp, #0x790]
     1f0:      	fmul.4s	v9, v7, v7
     1f4:      	fmul.4s	v8, v6, v6
     1f8:      	fmul.4s	v7, v17, v17
     1fc:      	fmul.4s	v10, v16, v16
     200:      	fmul.4s	v17, v19, v19
     204:      	fmul.4s	v16, v18, v18
     208:      	ldr	q14, [sp, #0x140]
     20c:      	mov.16b	v11, v14
     210:      	mov.16b	v12, v14
     214:      	mov.16b	v13, v14
     218:      	shl.2d	v6, v11, #0x5
     21c:      	add.2d	v29, v1, v6
     220:      	ldr	q3, [sp, #0x260]
     224:      	add.2d	v20, v29, v3
     228:      	mov.d	x11, v20[1]
     22c:      	shl.2d	v6, v12, #0x5
     230:      	add.2d	v18, v1, v6
     234:      	add.2d	v21, v18, v4
     238:      	mov.d	x14, v21[1]
     23c:      	ldr	q3, [x16]
     240:      	shl.2d	v6, v13, #0x5
     244:      	add.2d	v15, v1, v6
     248:      	add.2d	v22, v15, v3
     24c:      	mov.d	x0, v22[1]
     250:      	ldr	q19, [x17]
     254:      	shl.2d	v6, v14, #0x5
     258:      	add.2d	v6, v1, v6
     25c:      	add.2d	v23, v6, v19
     260:      	mov.d	x2, v23[1]
     264:      	fmov	x27, d20
     268:      	ldr	s20, [x27]
     26c:      	fmov	x27, d21
     270:      	fmov	x28, d22
     274:      	ld1.s	{ v20 }[1], [x11]
     278:      	fmov	x11, d23
     27c:      	ld1.s	{ v20 }[2], [x27]
     280:      	ld1.s	{ v20 }[3], [x14]
     284:      	ldr	s21, [x28]
     288:      	ld1.s	{ v21 }[1], [x0]
     28c:      	ld1.s	{ v21 }[2], [x11]
     290:      	ld1.s	{ v21 }[3], [x2]
     294:      	fmul.4s	v21, v21, v21
     298:      	fmul.4s	v20, v20, v20
     29c:      	fadd.4s	v2, v2, v20
     2a0:      	fadd.4s	v5, v5, v21
     2a4:      	ldr	q22, [x1]
     2a8:      	ldr	q23, [x4]
     2ac:      	ldr	q26, [x5]
     2b0:      	ldr	q27, [x6]
     2b4:      	add.2d	v20, v6, v27
     2b8:      	add.2d	v21, v15, v26
     2bc:      	add.2d	v24, v18, v23
     2c0:      	add.2d	v25, v29, v22
     2c4:      	mov.d	x11, v25[1]
     2c8:      	fmov	x14, d25
     2cc:      	mov.d	x0, v24[1]
     2d0:      	fmov	x2, d24
     2d4:      	mov.d	x27, v21[1]
     2d8:      	fmov	x28, d21
     2dc:      	mov.d	x8, v20[1]
     2e0:      	ldr	s21, [x14]
     2e4:      	ld1.s	{ v21 }[1], [x11]
     2e8:      	ld1.s	{ v21 }[2], [x2]
     2ec:      	ld1.s	{ v21 }[3], [x0]
     2f0:      	fmov	x11, d20
     2f4:      	ldr	s20, [x28]
     2f8:      	ld1.s	{ v20 }[1], [x27]
     2fc:      	ld1.s	{ v20 }[2], [x11]
     300:      	ld1.s	{ v20 }[3], [x8]
     304:      	fmul.4s	v20, v20, v20
     308:      	fmul.4s	v21, v21, v21
     30c:      	fadd.4s	v8, v8, v21
     310:      	fadd.4s	v9, v9, v20
     314:      	ldr	q24, [x7]
     318:      	ldr	q25, [x19]
     31c:      	ldr	q28, [x20]
     320:      	ldr	q30, [x21]
     324:      	add.2d	v20, v6, v30
     328:      	add.2d	v21, v29, v24
     32c:      	mov.d	x8, v21[1]
     330:      	fmov	x11, d21
     334:      	add.2d	v21, v18, v25
     338:      	mov.d	x14, v21[1]
     33c:      	fmov	x0, d21
     340:      	add.2d	v21, v15, v28
     344:      	mov.d	x2, v21[1]
     348:      	mov.d	x27, v20[1]
     34c:      	fmov	x28, d21
     350:      	ldr	s21, [x11]
     354:      	ld1.s	{ v21 }[1], [x8]
     358:      	ld1.s	{ v21 }[2], [x0]
     35c:      	fmov	x8, d20
     360:      	ld1.s	{ v21 }[3], [x14]
     364:      	ldr	s20, [x28]
     368:      	ld1.s	{ v20 }[1], [x2]
     36c:      	ld1.s	{ v20 }[2], [x8]
     370:      	ld1.s	{ v20 }[3], [x27]
     374:      	fmul.4s	v20, v20, v20
     378:      	fmul.4s	v21, v21, v21
     37c:      	fadd.4s	v10, v10, v21
     380:      	fadd.4s	v7, v7, v20
     384:      	ldr	q21, [x22]
     388:      	add.2d	v20, v29, v21
     38c:      	mov.d	x8, v20[1]
     390:      	ldr	q29, [x23]
     394:      	fmov	x11, d20
     398:      	ldr	q31, [x24]
     39c:      	add.2d	v20, v18, v29
     3a0:      	mov.d	x14, v20[1]
     3a4:      	fmov	x0, d20
     3a8:      	ldr	q18, [x25]
     3ac:      	add.2d	v6, v6, v18
     3b0:      	add.2d	v20, v15, v31
     3b4:      	mov.d	x2, v20[1]
     3b8:      	fmov	x27, d20
     3bc:      	mov.d	x28, v6[1]
     3c0:      	ldr	s20, [x11]
     3c4:      	ld1.s	{ v20 }[1], [x8]
     3c8:      	fmov	x8, d6
     3cc:      	ld1.s	{ v20 }[2], [x0]
     3d0:      	ld1.s	{ v20 }[3], [x14]
     3d4:      	fmul.4s	v6, v20, v20
     3d8:      	fadd.4s	v16, v16, v6
     3dc:      	ldr	s6, [x27]
     3e0:      	ld1.s	{ v6 }[1], [x2]
     3e4:      	ld1.s	{ v6 }[2], [x8]
     3e8:      	ld1.s	{ v6 }[3], [x28]
     3ec:      	fmul.4s	v6, v6, v6
     3f0:      	fadd.4s	v17, v17, v6
     3f4:      	dup.2d	v6, x15
     3f8:      	add.2d	v13, v13, v6
     3fc:      	add.2d	v12, v12, v6
     400:      	add.2d	v14, v14, v6
     404:      	add.2d	v11, v11, v6
     408:      	fmov	x8, d11
     40c:      	cmp	x8, #0x8
     410:      	b.lt	0x218 <ltmp0+0x218>
     414:      	str	q18, [sp, #0x210]
     418:      	str	q21, [sp, #0x240]
     41c:      	stp	q23, q22, [sp, #0x2c0]
     420:      	mov	x11, #0x0               ; =0
     424:      	movi.2d	v6, #0000000000000000
     428:      	movi.2d	v20, #0000000000000000
     42c:      	movi.2d	v21, #0000000000000000
     430:      	movi.2d	v11, #0000000000000000
     434:      	mov.16b	v18, v3
     438:      	ldr	q3, [sp, #0x260]
     43c:      	add	x8, x13, x11, lsl #5
     440:      	ldp	q13, q12, [x8]
     444:      	shl.2d	v14, v6, #0x5
     448:      	shl.2d	v15, v20, #0x5
     44c:      	shl.2d	v22, v21, #0x5
     450:      	shl.2d	v23, v11, #0x5
     454:      	add.2d	v23, v23, v19
     458:      	add.2d	v23, v0, v23
     45c:      	add.2d	v22, v22, v18
     460:      	add.2d	v15, v15, v4
     464:      	add.2d	v14, v14, v3
     468:      	add.2d	v14, v0, v14
     46c:      	mov.d	x8, v14[1]
     470:      	fmov	x11, d14
     474:      	str	s13, [x11]
     478:      	st1.s	{ v13 }[1], [x8]
     47c:      	add.2d	v14, v0, v15
     480:      	mov.d	x8, v14[1]
     484:      	fmov	x11, d14
     488:      	st1.s	{ v13 }[2], [x11]
     48c:      	add.2d	v22, v0, v22
     490:      	st1.s	{ v13 }[3], [x8]
     494:      	mov.d	x8, v22[1]
     498:      	fmov	x11, d22
     49c:      	str	s12, [x11]
     4a0:      	st1.s	{ v12 }[1], [x8]
     4a4:      	mov.d	x8, v23[1]
     4a8:      	fmov	x11, d23
     4ac:      	st1.s	{ v12 }[2], [x11]
     4b0:      	st1.s	{ v12 }[3], [x8]
     4b4:      	dup.2d	v22, x26
     4b8:      	add.2d	v21, v21, v22
     4bc:      	add.2d	v20, v20, v22
     4c0:      	add.2d	v11, v11, v22
     4c4:      	add.2d	v6, v6, v22
     4c8:      	fmov	x11, d6
     4cc:      	cmp	x11, #0x8
     4d0:      	b.lt	0x43c <ltmp0+0x43c>
     4d4:      	stp	q31, q29, [sp, #0x220]
     4d8:      	str	q30, [sp, #0x250]
     4dc:      	stp	q28, q25, [sp, #0x270]
     4e0:      	stp	q27, q26, [sp, #0x2a0]
     4e4:      	mov	x11, #0x0               ; =0
     4e8:      	ldr	q6, [sp, #0x290]
     4ec:      	fmul.4s	v6, v6, v6
     4f0:      	fadd.4s	v6, v6, v2
     4f4:      	mov.s	v2[0], v6[0]
     4f8:      	fadd.4s	v5, v9, v5
     4fc:      	fadd.4s	v2, v8, v2
     500:      	fadd.4s	v2, v10, v2
     504:      	fadd.4s	v5, v7, v5
     508:      	fadd.4s	v5, v17, v5
     50c:      	fadd.4s	v2, v16, v2
     510:      	rev64.4s	v6, v2
     514:      	rev64.4s	v7, v5
     518:      	fadd.4s	v2, v2, v6
     51c:      	dup.4s	v6, v2[2]
     520:      	fadd.4s	v5, v5, v7
     524:      	dup.4s	v7, v5[2]
     528:      	fadd.4s	v5, v5, v7
     52c:      	fadd.4s	v2, v2, v6
     530:      	fadd.4s	v2, v2, v5
     534:      	movi	d5, #0000000000000000
     538:      	fadd	s5, s2, s5
     53c:      	mov	w8, #0x42820000         ; =1115815936
     540:      	fmov	s6, w8
     544:      	add	x8, x13, #0x100
     548:      	ldr	q2, [sp, #0x670]
     54c:      	str	x8, [sp, #0x1f0]
     550:      	ld1.s	{ v2 }[0], [x8]
     554:      	fdiv	s5, s5, s6
     558:      	mov	w8, #0xc5ac             ; =50604
     55c:      	movk	w8, #0x3727, lsl #16
     560:      	fmov	s6, w8
     564:      	fadd	s5, s5, s6
     568:      	fsqrt	s5, s5
     56c:      	dup.4s	v6, v5[0]
     570:      	str	q2, [sp, #0x670]
     574:      	add	x10, x12, x10
     578:      	movi.2d	v7, #0000000000000000
     57c:      	movi.2d	v16, #0000000000000000
     580:      	movi.2d	v17, #0000000000000000
     584:      	movi.2d	v20, #0000000000000000
     588:      	shl.2d	v21, v20, #0x5
     58c:      	shl.2d	v22, v17, #0x5
     590:      	shl.2d	v23, v16, #0x5
     594:      	shl.2d	v8, v7, #0x5
     598:      	orr.16b	v8, v8, v3
     59c:      	orr.16b	v23, v23, v4
     5a0:      	orr.16b	v22, v22, v18
     5a4:      	orr.16b	v21, v21, v19
     5a8:      	add.2d	v9, v1, v21
     5ac:      	add.2d	v10, v1, v22
     5b0:      	add.2d	v11, v1, v23
     5b4:      	add.2d	v12, v1, v8
     5b8:      	mov.d	x8, v12[1]
     5bc:      	mov.d	x14, v11[1]
     5c0:      	mov.d	x0, v10[1]
     5c4:      	fmov	x27, d12
     5c8:      	fmov	x28, d10
     5cc:      	mov.d	x2, v9[1]
     5d0:      	fmov	x30, d9
     5d4:      	ldr	s9, [x28]
     5d8:      	ld1.s	{ v9 }[1], [x0]
     5dc:      	ld1.s	{ v9 }[2], [x30]
     5e0:      	ld1.s	{ v9 }[3], [x2]
     5e4:      	fmov	x0, d11
     5e8:      	ldr	s10, [x27]
     5ec:      	ld1.s	{ v10 }[1], [x8]
     5f0:      	ld1.s	{ v10 }[2], [x0]
     5f4:      	ld1.s	{ v10 }[3], [x14]
     5f8:      	fdiv.4s	v10, v10, v6
     5fc:      	fdiv.4s	v9, v9, v6
     600:      	add.2d	v21, v0, v21
     604:      	add.2d	v22, v0, v22
     608:      	add.2d	v23, v0, v23
     60c:      	add.2d	v8, v0, v8
     610:      	mov.d	x8, v8[1]
     614:      	fmov	x14, d8
     618:      	mov.d	x0, v23[1]
     61c:      	mov.d	x2, v22[1]
     620:      	mov.d	x27, v21[1]
     624:      	fmov	x28, d23
     628:      	ldr	s23, [x14]
     62c:      	ld1.s	{ v23 }[1], [x8]
     630:      	ld1.s	{ v23 }[2], [x28]
     634:      	fmov	x8, d22
     638:      	ld1.s	{ v23 }[3], [x0]
     63c:      	ldr	s22, [x8]
     640:      	ld1.s	{ v22 }[1], [x2]
     644:      	fmov	x8, d21
     648:      	ld1.s	{ v22 }[2], [x8]
     64c:      	ld1.s	{ v22 }[3], [x27]
     650:      	fmul.4s	v21, v9, v22
     654:      	fmul.4s	v22, v10, v23
     658:      	add	x8, x10, x11, lsl #5
     65c:      	stp	q22, q21, [x8]
     660:      	dup.2d	v21, x26
     664:      	add.2d	v17, v17, v21
     668:      	add.2d	v16, v16, v21
     66c:      	add.2d	v20, v20, v21
     670:      	add.2d	v7, v7, v21
     674:      	fmov	x11, d7
     678:      	cmp	x11, #0x8
     67c:      	b.lt	0x588 <ltmp0+0x588>
     680:      	ldr	q6, [sp, #0x790]
     684:      	fdiv.4s	v5, v6, v5
     688:      	fmul.4s	v2, v2, v5
     68c:      	str	s2, [x12, x9]
     690:      	ldr	w8, [sp, #0x200]
     694:      	orr	w8, w8, #0x1
     698:      	mov	w9, #0x104              ; =260
     69c:      	umull	x10, w8, w9
     6a0:      	umaddl	x8, w8, w9, x3
     6a4:      	ldp	q2, q5, [x8]
     6a8:      	str	q5, [sp, #0x6a0]
     6ac:      	str	q2, [sp, #0x690]
     6b0:      	ldp	q6, q7, [x8, #0x20]
     6b4:      	str	q7, [sp, #0x6c0]
     6b8:      	str	q6, [sp, #0x6b0]
     6bc:      	ldp	q16, q17, [x8, #0x40]
     6c0:      	str	q17, [sp, #0x6e0]
     6c4:      	str	q16, [sp, #0x6d0]
     6c8:      	ldp	q20, q21, [x8, #0x60]
     6cc:      	str	q21, [sp, #0x700]
     6d0:      	str	q20, [sp, #0x6f0]
     6d4:      	ldp	q22, q23, [x8, #0x80]
     6d8:      	str	q23, [sp, #0x720]
     6dc:      	str	q22, [sp, #0x710]
     6e0:      	ldp	q22, q23, [x8, #0xa0]
     6e4:      	str	q23, [sp, #0x740]
     6e8:      	str	q22, [sp, #0x730]
     6ec:      	ldp	q22, q23, [x8, #0xc0]
     6f0:      	str	q23, [sp, #0x760]
     6f4:      	str	q22, [sp, #0x750]
     6f8:      	ldp	q22, q23, [x8, #0xe0]
     6fc:      	str	q23, [sp, #0x780]
     700:      	str	q22, [sp, #0x770]
     704:      	add	x9, x10, #0x100
     708:      	ldr	s22, [x3, x9]
     70c:      	str	q22, [sp, #0x1e0]
     710:      	str	q22, [sp, #0x790]
     714:      	fmul.4s	v5, v5, v5
     718:      	fmul.4s	v2, v2, v2
     71c:      	fmul.4s	v9, v7, v7
     720:      	fmul.4s	v8, v6, v6
     724:      	fmul.4s	v7, v17, v17
     728:      	fmul.4s	v10, v16, v16
     72c:      	fmul.4s	v17, v21, v21
     730:      	fmul.4s	v16, v20, v20
     734:      	dup.2d	v11, x15
     738:      	mov.16b	v12, v11
     73c:      	mov.16b	v13, v11
     740:      	mov.16b	v14, v11
     744:      	mov.16b	v29, v24
     748:      	ldr	q31, [sp, #0x270]
     74c:      	ldp	q26, q25, [sp, #0x240]
     750:      	ldp	q28, q27, [sp, #0x220]
     754:      	ldr	q30, [sp, #0x210]
     758:      	shl.2d	v6, v11, #0x5
     75c:      	shl.2d	v21, v12, #0x5
     760:      	shl.2d	v22, v13, #0x5
     764:      	shl.2d	v20, v14, #0x5
     768:      	add.2d	v15, v1, v20
     76c:      	add.2d	v23, v15, v19
     770:      	add.2d	v20, v1, v6
     774:      	add.2d	v24, v20, v3
     778:      	mov.d	x8, v24[1]
     77c:      	add.2d	v6, v1, v22
     780:      	add.2d	v21, v1, v21
     784:      	fmov	x11, d24
     788:      	add.2d	v22, v21, v4
     78c:      	mov.d	x14, v22[1]
     790:      	fmov	x0, d22
     794:      	add.2d	v22, v6, v18
     798:      	mov.d	x2, v22[1]
     79c:      	fmov	x27, d22
     7a0:      	mov.d	x28, v23[1]
     7a4:      	ldr	s22, [x11]
     7a8:      	ld1.s	{ v22 }[1], [x8]
     7ac:      	fmov	x8, d23
     7b0:      	ld1.s	{ v22 }[2], [x0]
     7b4:      	ld1.s	{ v22 }[3], [x14]
     7b8:      	ldr	s23, [x27]
     7bc:      	ld1.s	{ v23 }[1], [x2]
     7c0:      	ld1.s	{ v23 }[2], [x8]
     7c4:      	ld1.s	{ v23 }[3], [x28]
     7c8:      	fmul.4s	v23, v23, v23
     7cc:      	fmul.4s	v22, v22, v22
     7d0:      	fadd.4s	v2, v2, v22
     7d4:      	fadd.4s	v5, v5, v23
     7d8:      	ldr	q22, [sp, #0x2a0]
     7dc:      	add.2d	v22, v15, v22
     7e0:      	ldr	q23, [sp, #0x2d0]
     7e4:      	add.2d	v23, v20, v23
     7e8:      	mov.d	x8, v23[1]
     7ec:      	fmov	x11, d23
     7f0:      	ldr	q23, [sp, #0x2c0]
     7f4:      	add.2d	v23, v21, v23
     7f8:      	mov.d	x14, v23[1]
     7fc:      	fmov	x0, d23
     800:      	ldr	q23, [sp, #0x2b0]
     804:      	add.2d	v23, v6, v23
     808:      	mov.d	x2, v23[1]
     80c:      	mov.d	x27, v22[1]
     810:      	fmov	x28, d23
     814:      	ldr	s23, [x11]
     818:      	ld1.s	{ v23 }[1], [x8]
     81c:      	ld1.s	{ v23 }[2], [x0]
     820:      	fmov	x8, d22
     824:      	ld1.s	{ v23 }[3], [x14]
     828:      	ldr	s22, [x28]
     82c:      	ld1.s	{ v22 }[1], [x2]
     830:      	ld1.s	{ v22 }[2], [x8]
     834:      	ld1.s	{ v22 }[3], [x27]
     838:      	fmul.4s	v22, v22, v22
     83c:      	fmul.4s	v23, v23, v23
     840:      	fadd.4s	v8, v8, v23
     844:      	fadd.4s	v9, v9, v22
     848:      	add.2d	v22, v15, v25
     84c:      	add.2d	v23, v20, v29
     850:      	mov.d	x8, v23[1]
     854:      	fmov	x11, d23
     858:      	ldr	q23, [sp, #0x280]
     85c:      	add.2d	v23, v21, v23
     860:      	mov.d	x14, v23[1]
     864:      	fmov	x0, d23
     868:      	add.2d	v23, v6, v31
     86c:      	mov.d	x2, v23[1]
     870:      	fmov	x27, d23
     874:      	mov.d	x28, v22[1]
     878:      	ldr	s23, [x11]
     87c:      	ld1.s	{ v23 }[1], [x8]
     880:      	ld1.s	{ v23 }[2], [x0]
     884:      	ld1.s	{ v23 }[3], [x14]
     888:      	fmov	x8, d22
     88c:      	fmul.4s	v22, v23, v23
     890:      	fadd.4s	v10, v10, v22
     894:      	ldr	s22, [x27]
     898:      	ld1.s	{ v22 }[1], [x2]
     89c:      	ld1.s	{ v22 }[2], [x8]
     8a0:      	ld1.s	{ v22 }[3], [x28]
     8a4:      	fmul.4s	v22, v22, v22
     8a8:      	fadd.4s	v7, v7, v22
     8ac:      	add.2d	v21, v21, v27
     8b0:      	add.2d	v20, v20, v26
     8b4:      	mov.d	x8, v20[1]
     8b8:      	mov.d	x11, v21[1]
     8bc:      	fmov	x14, d20
     8c0:      	fmov	x0, d21
     8c4:      	add.2d	v20, v15, v30
     8c8:      	add.2d	v6, v6, v28
     8cc:      	mov.d	x2, v6[1]
     8d0:      	fmov	x27, d6
     8d4:      	mov.d	x28, v20[1]
     8d8:      	ldr	s6, [x14]
     8dc:      	ld1.s	{ v6 }[1], [x8]
     8e0:      	fmov	x8, d20
     8e4:      	ld1.s	{ v6 }[2], [x0]
     8e8:      	ld1.s	{ v6 }[3], [x11]
     8ec:      	fmul.4s	v6, v6, v6
     8f0:      	fadd.4s	v16, v16, v6
     8f4:      	ldr	s6, [x27]
     8f8:      	ld1.s	{ v6 }[1], [x2]
     8fc:      	ld1.s	{ v6 }[2], [x8]
     900:      	ld1.s	{ v6 }[3], [x28]
     904:      	fmul.4s	v6, v6, v6
     908:      	fadd.4s	v17, v17, v6
     90c:      	dup.2d	v6, x15
     910:      	add.2d	v13, v13, v6
     914:      	add.2d	v12, v12, v6
     918:      	add.2d	v14, v14, v6
     91c:      	add.2d	v11, v11, v6
     920:      	fmov	x8, d11
     924:      	cmp	x8, #0x8
     928:      	b.lt	0x758 <ltmp0+0x758>
     92c:      	str	q29, [sp, #0x290]
     930:      	mov	x11, #0x0               ; =0
     934:      	movi.2d	v6, #0000000000000000
     938:      	movi.2d	v20, #0000000000000000
     93c:      	movi.2d	v21, #0000000000000000
     940:      	movi.2d	v11, #0000000000000000
     944:      	add	x8, x13, x11, lsl #5
     948:      	ldp	q23, q22, [x8]
     94c:      	shl.2d	v24, v6, #0x5
     950:      	shl.2d	v12, v20, #0x5
     954:      	shl.2d	v13, v21, #0x5
     958:      	shl.2d	v14, v11, #0x5
     95c:      	add.2d	v14, v14, v19
     960:      	add.2d	v14, v0, v14
     964:      	add.2d	v13, v13, v18
     968:      	add.2d	v12, v12, v4
     96c:      	add.2d	v24, v24, v3
     970:      	add.2d	v24, v0, v24
     974:      	mov.d	x8, v24[1]
     978:      	fmov	x11, d24
     97c:      	str	s23, [x11]
     980:      	st1.s	{ v23 }[1], [x8]
     984:      	add.2d	v24, v0, v12
     988:      	mov.d	x8, v24[1]
     98c:      	fmov	x11, d24
     990:      	st1.s	{ v23 }[2], [x11]
     994:      	add.2d	v24, v0, v13
     998:      	st1.s	{ v23 }[3], [x8]
     99c:      	mov.d	x8, v24[1]
     9a0:      	fmov	x11, d24
     9a4:      	str	s22, [x11]
     9a8:      	st1.s	{ v22 }[1], [x8]
     9ac:      	mov.d	x8, v14[1]
     9b0:      	fmov	x11, d14
     9b4:      	st1.s	{ v22 }[2], [x11]
     9b8:      	st1.s	{ v22 }[3], [x8]
     9bc:      	dup.2d	v22, x26
     9c0:      	add.2d	v21, v21, v22
     9c4:      	add.2d	v20, v20, v22
     9c8:      	add.2d	v11, v11, v22
     9cc:      	add.2d	v6, v6, v22
     9d0:      	fmov	x11, d6
     9d4:      	cmp	x11, #0x8
     9d8:      	b.lt	0x944 <ltmp0+0x944>
     9dc:      	mov	x11, #0x0               ; =0
     9e0:      	ldr	q6, [sp, #0x1e0]
     9e4:      	fmul.4s	v6, v6, v6
     9e8:      	fadd.4s	v6, v6, v2
     9ec:      	mov.s	v2[0], v6[0]
     9f0:      	fadd.4s	v5, v9, v5
     9f4:      	fadd.4s	v2, v8, v2
     9f8:      	fadd.4s	v2, v10, v2
     9fc:      	fadd.4s	v5, v7, v5
     a00:      	fadd.4s	v5, v17, v5
     a04:      	fadd.4s	v2, v16, v2
     a08:      	rev64.4s	v6, v2
     a0c:      	rev64.4s	v7, v5
     a10:      	fadd.4s	v5, v5, v7
     a14:      	fadd.4s	v2, v2, v6
     a18:      	dup.4s	v6, v2[2]
     a1c:      	dup.4s	v7, v5[2]
     a20:      	fadd.4s	v5, v5, v7
     a24:      	fadd.4s	v2, v2, v6
     a28:      	fadd.4s	v2, v2, v5
     a2c:      	movi	d5, #0000000000000000
     a30:      	fadd	s5, s2, s5
     a34:      	mov	w8, #0x42820000         ; =1115815936
     a38:      	fmov	s6, w8
     a3c:      	ldr	q2, [sp, #0x670]
     a40:      	ldr	x8, [sp, #0x1f0]
     a44:      	ld1.s	{ v2 }[0], [x8]
     a48:      	fdiv	s5, s5, s6
     a4c:      	mov	w8, #0xc5ac             ; =50604
     a50:      	movk	w8, #0x3727, lsl #16
     a54:      	fmov	s6, w8
     a58:      	fadd	s5, s5, s6
     a5c:      	fsqrt	s5, s5
     a60:      	dup.4s	v6, v5[0]
     a64:      	str	q2, [sp, #0x670]
     a68:      	add	x10, x12, x10
     a6c:      	movi.2d	v7, #0000000000000000
     a70:      	movi.2d	v16, #0000000000000000
     a74:      	movi.2d	v17, #0000000000000000
     a78:      	movi.2d	v20, #0000000000000000
     a7c:      	shl.2d	v21, v20, #0x5
     a80:      	shl.2d	v22, v17, #0x5
     a84:      	shl.2d	v23, v16, #0x5
     a88:      	shl.2d	v24, v7, #0x5
     a8c:      	orr.16b	v24, v24, v3
     a90:      	orr.16b	v23, v23, v4
     a94:      	orr.16b	v22, v22, v18
     a98:      	orr.16b	v21, v21, v19
     a9c:      	add.2d	v8, v1, v21
     aa0:      	add.2d	v9, v1, v22
     aa4:      	add.2d	v10, v1, v23
     aa8:      	add.2d	v11, v1, v24
     aac:      	mov.d	x8, v11[1]
     ab0:      	mov.d	x14, v10[1]
     ab4:      	mov.d	x0, v9[1]
     ab8:      	fmov	x2, d11
     abc:      	fmov	x27, d9
     ac0:      	mov.d	x28, v8[1]
     ac4:      	fmov	x30, d8
     ac8:      	ldr	s8, [x27]
     acc:      	ld1.s	{ v8 }[1], [x0]
     ad0:      	ld1.s	{ v8 }[2], [x30]
     ad4:      	ld1.s	{ v8 }[3], [x28]
     ad8:      	fmov	x0, d10
     adc:      	ldr	s9, [x2]
     ae0:      	ld1.s	{ v9 }[1], [x8]
     ae4:      	ld1.s	{ v9 }[2], [x0]
     ae8:      	ld1.s	{ v9 }[3], [x14]
     aec:      	fdiv.4s	v9, v9, v6
     af0:      	fdiv.4s	v8, v8, v6
     af4:      	add.2d	v21, v0, v21
     af8:      	add.2d	v22, v0, v22
     afc:      	add.2d	v23, v0, v23
     b00:      	add.2d	v24, v0, v24
     b04:      	mov.d	x8, v24[1]
     b08:      	fmov	x14, d24
     b0c:      	mov.d	x0, v23[1]
     b10:      	mov.d	x2, v22[1]
     b14:      	mov.d	x27, v21[1]
     b18:      	fmov	x28, d23
     b1c:      	ldr	s23, [x14]
     b20:      	ld1.s	{ v23 }[1], [x8]
     b24:      	ld1.s	{ v23 }[2], [x28]
     b28:      	fmov	x8, d22
     b2c:      	ld1.s	{ v23 }[3], [x0]
     b30:      	ldr	s22, [x8]
     b34:      	ld1.s	{ v22 }[1], [x2]
     b38:      	fmov	x8, d21
     b3c:      	ld1.s	{ v22 }[2], [x8]
     b40:      	ld1.s	{ v22 }[3], [x27]
     b44:      	fmul.4s	v21, v8, v22
     b48:      	fmul.4s	v22, v9, v23
     b4c:      	add	x8, x10, x11, lsl #5
     b50:      	stp	q22, q21, [x8]
     b54:      	dup.2d	v21, x26
     b58:      	add.2d	v17, v17, v21
     b5c:      	add.2d	v16, v16, v21
     b60:      	add.2d	v20, v20, v21
     b64:      	add.2d	v7, v7, v21
     b68:      	fmov	x11, d7
     b6c:      	cmp	x11, #0x8
     b70:      	b.lt	0xa7c <ltmp0+0xa7c>
     b74:      	ldr	q6, [sp, #0x790]
     b78:      	fdiv.4s	v5, v6, v5
     b7c:      	fmul.4s	v2, v2, v5
     b80:      	str	s2, [x12, x9]
     b84:      	ldr	w8, [sp, #0x200]
     b88:      	orr	w8, w8, #0x2
     b8c:      	mov	w9, #0x104              ; =260
     b90:      	umull	x10, w8, w9
     b94:      	umaddl	x8, w8, w9, x3
     b98:      	ldp	q2, q5, [x8]
     b9c:      	str	q5, [sp, #0x6a0]
     ba0:      	str	q2, [sp, #0x690]
     ba4:      	ldp	q6, q7, [x8, #0x20]
     ba8:      	str	q7, [sp, #0x6c0]
     bac:      	str	q6, [sp, #0x6b0]
     bb0:      	ldp	q16, q17, [x8, #0x40]
     bb4:      	str	q17, [sp, #0x6e0]
     bb8:      	str	q16, [sp, #0x6d0]
     bbc:      	ldp	q20, q21, [x8, #0x60]
     bc0:      	str	q21, [sp, #0x700]
     bc4:      	str	q20, [sp, #0x6f0]
     bc8:      	ldp	q22, q23, [x8, #0x80]
     bcc:      	str	q23, [sp, #0x720]
     bd0:      	str	q22, [sp, #0x710]
     bd4:      	ldp	q22, q23, [x8, #0xa0]
     bd8:      	str	q23, [sp, #0x740]
     bdc:      	str	q22, [sp, #0x730]
     be0:      	ldp	q22, q23, [x8, #0xc0]
     be4:      	str	q23, [sp, #0x760]
     be8:      	str	q22, [sp, #0x750]
     bec:      	ldp	q22, q23, [x8, #0xe0]
     bf0:      	str	q23, [sp, #0x780]
     bf4:      	str	q22, [sp, #0x770]
     bf8:      	add	x9, x10, #0x100
     bfc:      	ldr	s22, [x3, x9]
     c00:      	str	q22, [sp, #0x1e0]
     c04:      	str	q22, [sp, #0x790]
     c08:      	fmul.4s	v5, v5, v5
     c0c:      	fmul.4s	v2, v2, v2
     c10:      	fmul.4s	v9, v7, v7
     c14:      	fmul.4s	v8, v6, v6
     c18:      	fmul.4s	v7, v17, v17
     c1c:      	fmul.4s	v10, v16, v16
     c20:      	fmul.4s	v17, v21, v21
     c24:      	fmul.4s	v16, v20, v20
     c28:      	dup.2d	v11, x15
     c2c:      	mov.16b	v12, v11
     c30:      	mov.16b	v13, v11
     c34:      	mov.16b	v14, v11
     c38:      	ldp	q31, q30, [sp, #0x270]
     c3c:      	ldp	q26, q25, [sp, #0x240]
     c40:      	ldp	q28, q27, [sp, #0x220]
     c44:      	ldr	q29, [sp, #0x210]
     c48:      	shl.2d	v6, v11, #0x5
     c4c:      	shl.2d	v21, v12, #0x5
     c50:      	shl.2d	v22, v13, #0x5
     c54:      	shl.2d	v20, v14, #0x5
     c58:      	add.2d	v15, v1, v20
     c5c:      	add.2d	v23, v15, v19
     c60:      	add.2d	v20, v1, v6
     c64:      	add.2d	v24, v20, v3
     c68:      	mov.d	x8, v24[1]
     c6c:      	add.2d	v6, v1, v22
     c70:      	add.2d	v21, v1, v21
     c74:      	fmov	x11, d24
     c78:      	add.2d	v22, v21, v4
     c7c:      	mov.d	x14, v22[1]
     c80:      	fmov	x0, d22
     c84:      	add.2d	v22, v6, v18
     c88:      	mov.d	x2, v22[1]
     c8c:      	fmov	x27, d22
     c90:      	mov.d	x28, v23[1]
     c94:      	ldr	s22, [x11]
     c98:      	ld1.s	{ v22 }[1], [x8]
     c9c:      	fmov	x8, d23
     ca0:      	ld1.s	{ v22 }[2], [x0]
     ca4:      	ld1.s	{ v22 }[3], [x14]
     ca8:      	ldr	s23, [x27]
     cac:      	ld1.s	{ v23 }[1], [x2]
     cb0:      	ld1.s	{ v23 }[2], [x8]
     cb4:      	ld1.s	{ v23 }[3], [x28]
     cb8:      	fmul.4s	v23, v23, v23
     cbc:      	fmul.4s	v22, v22, v22
     cc0:      	fadd.4s	v2, v2, v22
     cc4:      	fadd.4s	v5, v5, v23
     cc8:      	ldr	q22, [sp, #0x2a0]
     ccc:      	add.2d	v22, v15, v22
     cd0:      	ldr	q23, [sp, #0x2d0]
     cd4:      	add.2d	v23, v20, v23
     cd8:      	mov.d	x8, v23[1]
     cdc:      	fmov	x11, d23
     ce0:      	ldr	q23, [sp, #0x2c0]
     ce4:      	add.2d	v23, v21, v23
     ce8:      	mov.d	x14, v23[1]
     cec:      	fmov	x0, d23
     cf0:      	ldr	q23, [sp, #0x2b0]
     cf4:      	add.2d	v23, v6, v23
     cf8:      	mov.d	x2, v23[1]
     cfc:      	mov.d	x27, v22[1]
     d00:      	fmov	x28, d23
     d04:      	ldr	s23, [x11]
     d08:      	ld1.s	{ v23 }[1], [x8]
     d0c:      	ld1.s	{ v23 }[2], [x0]
     d10:      	fmov	x8, d22
     d14:      	ld1.s	{ v23 }[3], [x14]
     d18:      	ldr	s22, [x28]
     d1c:      	ld1.s	{ v22 }[1], [x2]
     d20:      	ld1.s	{ v22 }[2], [x8]
     d24:      	ld1.s	{ v22 }[3], [x27]
     d28:      	fmul.4s	v22, v22, v22
     d2c:      	fmul.4s	v23, v23, v23
     d30:      	fadd.4s	v8, v8, v23
     d34:      	fadd.4s	v9, v9, v22
     d38:      	add.2d	v22, v15, v25
     d3c:      	ldr	q23, [sp, #0x290]
     d40:      	add.2d	v23, v20, v23
     d44:      	mov.d	x8, v23[1]
     d48:      	fmov	x11, d23
     d4c:      	add.2d	v23, v21, v30
     d50:      	mov.d	x14, v23[1]
     d54:      	fmov	x0, d23
     d58:      	add.2d	v23, v6, v31
     d5c:      	mov.d	x2, v23[1]
     d60:      	fmov	x27, d23
     d64:      	mov.d	x28, v22[1]
     d68:      	ldr	s23, [x11]
     d6c:      	ld1.s	{ v23 }[1], [x8]
     d70:      	ld1.s	{ v23 }[2], [x0]
     d74:      	ld1.s	{ v23 }[3], [x14]
     d78:      	fmov	x8, d22
     d7c:      	fmul.4s	v22, v23, v23
     d80:      	fadd.4s	v10, v10, v22
     d84:      	ldr	s22, [x27]
     d88:      	ld1.s	{ v22 }[1], [x2]
     d8c:      	ld1.s	{ v22 }[2], [x8]
     d90:      	ld1.s	{ v22 }[3], [x28]
     d94:      	fmul.4s	v22, v22, v22
     d98:      	fadd.4s	v7, v7, v22
     d9c:      	add.2d	v21, v21, v27
     da0:      	add.2d	v20, v20, v26
     da4:      	mov.d	x8, v20[1]
     da8:      	mov.d	x11, v21[1]
     dac:      	fmov	x14, d20
     db0:      	fmov	x0, d21
     db4:      	add.2d	v20, v15, v29
     db8:      	add.2d	v6, v6, v28
     dbc:      	mov.d	x2, v6[1]
     dc0:      	fmov	x27, d6
     dc4:      	mov.d	x28, v20[1]
     dc8:      	ldr	s6, [x14]
     dcc:      	ld1.s	{ v6 }[1], [x8]
     dd0:      	fmov	x8, d20
     dd4:      	ld1.s	{ v6 }[2], [x0]
     dd8:      	ld1.s	{ v6 }[3], [x11]
     ddc:      	fmul.4s	v6, v6, v6
     de0:      	fadd.4s	v16, v16, v6
     de4:      	ldr	s6, [x27]
     de8:      	ld1.s	{ v6 }[1], [x2]
     dec:      	ld1.s	{ v6 }[2], [x8]
     df0:      	ld1.s	{ v6 }[3], [x28]
     df4:      	fmul.4s	v6, v6, v6
     df8:      	fadd.4s	v17, v17, v6
     dfc:      	dup.2d	v6, x15
     e00:      	add.2d	v13, v13, v6
     e04:      	add.2d	v12, v12, v6
     e08:      	add.2d	v14, v14, v6
     e0c:      	add.2d	v11, v11, v6
     e10:      	fmov	x8, d11
     e14:      	cmp	x8, #0x8
     e18:      	b.lt	0xc48 <ltmp0+0xc48>
     e1c:      	mov	x11, #0x0               ; =0
     e20:      	movi.2d	v6, #0000000000000000
     e24:      	movi.2d	v20, #0000000000000000
     e28:      	movi.2d	v21, #0000000000000000
     e2c:      	movi.2d	v11, #0000000000000000
     e30:      	add	x8, x13, x11, lsl #5
     e34:      	ldp	q23, q22, [x8]
     e38:      	shl.2d	v24, v6, #0x5
     e3c:      	shl.2d	v12, v20, #0x5
     e40:      	shl.2d	v13, v21, #0x5
     e44:      	shl.2d	v14, v11, #0x5
     e48:      	add.2d	v14, v14, v19
     e4c:      	add.2d	v14, v0, v14
     e50:      	add.2d	v13, v13, v18
     e54:      	add.2d	v12, v12, v4
     e58:      	add.2d	v24, v24, v3
     e5c:      	add.2d	v24, v0, v24
     e60:      	mov.d	x8, v24[1]
     e64:      	fmov	x11, d24
     e68:      	str	s23, [x11]
     e6c:      	st1.s	{ v23 }[1], [x8]
     e70:      	add.2d	v24, v0, v12
     e74:      	mov.d	x8, v24[1]
     e78:      	fmov	x11, d24
     e7c:      	st1.s	{ v23 }[2], [x11]
     e80:      	add.2d	v24, v0, v13
     e84:      	st1.s	{ v23 }[3], [x8]
     e88:      	mov.d	x8, v24[1]
     e8c:      	fmov	x11, d24
     e90:      	str	s22, [x11]
     e94:      	st1.s	{ v22 }[1], [x8]
     e98:      	mov.d	x8, v14[1]
     e9c:      	fmov	x11, d14
     ea0:      	st1.s	{ v22 }[2], [x11]
     ea4:      	st1.s	{ v22 }[3], [x8]
     ea8:      	dup.2d	v22, x26
     eac:      	add.2d	v21, v21, v22
     eb0:      	add.2d	v20, v20, v22
     eb4:      	add.2d	v11, v11, v22
     eb8:      	add.2d	v6, v6, v22
     ebc:      	fmov	x11, d6
     ec0:      	cmp	x11, #0x8
     ec4:      	b.lt	0xe30 <ltmp0+0xe30>
     ec8:      	mov	x11, #0x0               ; =0
     ecc:      	ldr	q6, [sp, #0x1e0]
     ed0:      	fmul.4s	v6, v6, v6
     ed4:      	fadd.4s	v6, v6, v2
     ed8:      	mov.s	v2[0], v6[0]
     edc:      	fadd.4s	v5, v9, v5
     ee0:      	fadd.4s	v2, v8, v2
     ee4:      	fadd.4s	v2, v10, v2
     ee8:      	fadd.4s	v5, v7, v5
     eec:      	fadd.4s	v5, v17, v5
     ef0:      	fadd.4s	v2, v16, v2
     ef4:      	rev64.4s	v6, v2
     ef8:      	rev64.4s	v7, v5
     efc:      	fadd.4s	v5, v5, v7
     f00:      	fadd.4s	v2, v2, v6
     f04:      	dup.4s	v6, v2[2]
     f08:      	dup.4s	v7, v5[2]
     f0c:      	fadd.4s	v5, v5, v7
     f10:      	fadd.4s	v2, v2, v6
     f14:      	fadd.4s	v2, v2, v5
     f18:      	movi	d5, #0000000000000000
     f1c:      	fadd	s5, s2, s5
     f20:      	mov	w8, #0x42820000         ; =1115815936
     f24:      	fmov	s6, w8
     f28:      	ldr	q2, [sp, #0x670]
     f2c:      	ldr	x8, [sp, #0x1f0]
     f30:      	ld1.s	{ v2 }[0], [x8]
     f34:      	fdiv	s5, s5, s6
     f38:      	mov	w8, #0xc5ac             ; =50604
     f3c:      	movk	w8, #0x3727, lsl #16
     f40:      	fmov	s6, w8
     f44:      	fadd	s5, s5, s6
     f48:      	fsqrt	s5, s5
     f4c:      	dup.4s	v6, v5[0]
     f50:      	str	q2, [sp, #0x670]
     f54:      	add	x10, x12, x10
     f58:      	movi.2d	v7, #0000000000000000
     f5c:      	movi.2d	v16, #0000000000000000
     f60:      	movi.2d	v17, #0000000000000000
     f64:      	movi.2d	v20, #0000000000000000
     f68:      	shl.2d	v21, v20, #0x5
     f6c:      	shl.2d	v22, v17, #0x5
     f70:      	shl.2d	v23, v16, #0x5
     f74:      	shl.2d	v24, v7, #0x5
     f78:      	orr.16b	v24, v24, v3
     f7c:      	orr.16b	v23, v23, v4
     f80:      	orr.16b	v22, v22, v18
     f84:      	orr.16b	v21, v21, v19
     f88:      	add.2d	v8, v1, v21
     f8c:      	add.2d	v9, v1, v22
     f90:      	add.2d	v10, v1, v23
     f94:      	add.2d	v11, v1, v24
     f98:      	mov.d	x8, v11[1]
     f9c:      	mov.d	x14, v10[1]
     fa0:      	mov.d	x0, v9[1]
     fa4:      	fmov	x2, d11
     fa8:      	fmov	x27, d9
     fac:      	mov.d	x28, v8[1]
     fb0:      	fmov	x30, d8
     fb4:      	ldr	s8, [x27]
     fb8:      	ld1.s	{ v8 }[1], [x0]
     fbc:      	ld1.s	{ v8 }[2], [x30]
     fc0:      	ld1.s	{ v8 }[3], [x28]
     fc4:      	fmov	x0, d10
     fc8:      	ldr	s9, [x2]
     fcc:      	ld1.s	{ v9 }[1], [x8]
     fd0:      	ld1.s	{ v9 }[2], [x0]
     fd4:      	ld1.s	{ v9 }[3], [x14]
     fd8:      	fdiv.4s	v9, v9, v6
     fdc:      	fdiv.4s	v8, v8, v6
     fe0:      	add.2d	v21, v0, v21
     fe4:      	add.2d	v22, v0, v22
     fe8:      	add.2d	v23, v0, v23
     fec:      	add.2d	v24, v0, v24
     ff0:      	mov.d	x8, v24[1]
     ff4:      	fmov	x14, d24
     ff8:      	mov.d	x0, v23[1]
     ffc:      	mov.d	x2, v22[1]
    1000:      	mov.d	x27, v21[1]
    1004:      	fmov	x28, d23
    1008:      	ldr	s23, [x14]
    100c:      	ld1.s	{ v23 }[1], [x8]
    1010:      	ld1.s	{ v23 }[2], [x28]
    1014:      	fmov	x8, d22
    1018:      	ld1.s	{ v23 }[3], [x0]
    101c:      	ldr	s22, [x8]
    1020:      	ld1.s	{ v22 }[1], [x2]
    1024:      	fmov	x8, d21
    1028:      	ld1.s	{ v22 }[2], [x8]
    102c:      	ld1.s	{ v22 }[3], [x27]
    1030:      	fmul.4s	v21, v8, v22
    1034:      	fmul.4s	v22, v9, v23
    1038:      	add	x8, x10, x11, lsl #5
    103c:      	stp	q22, q21, [x8]
    1040:      	dup.2d	v21, x26
    1044:      	add.2d	v17, v17, v21
    1048:      	add.2d	v16, v16, v21
    104c:      	add.2d	v20, v20, v21
    1050:      	add.2d	v7, v7, v21
    1054:      	fmov	x11, d7
    1058:      	cmp	x11, #0x8
    105c:      	b.lt	0xf68 <ltmp0+0xf68>
    1060:      	ldr	q6, [sp, #0x790]
    1064:      	fdiv.4s	v5, v6, v5
    1068:      	fmul.4s	v2, v2, v5
    106c:      	str	s2, [x12, x9]
    1070:      	ldr	w8, [sp, #0x200]
    1074:      	orr	w8, w8, #0x3
    1078:      	mov	w9, #0x104              ; =260
    107c:      	umull	x10, w8, w9
    1080:      	umaddl	x8, w8, w9, x3
    1084:      	ldp	q2, q5, [x8]
    1088:      	str	q5, [sp, #0x6a0]
    108c:      	str	q2, [sp, #0x690]
    1090:      	ldp	q6, q7, [x8, #0x20]
    1094:      	str	q7, [sp, #0x6c0]
    1098:      	str	q6, [sp, #0x6b0]
    109c:      	ldp	q16, q20, [x8, #0x40]
    10a0:      	str	q20, [sp, #0x6e0]
    10a4:      	str	q16, [sp, #0x6d0]
    10a8:      	ldp	q21, q22, [x8, #0x60]
    10ac:      	str	q22, [sp, #0x700]
    10b0:      	str	q21, [sp, #0x6f0]
    10b4:      	ldp	q17, q23, [x8, #0x80]
    10b8:      	str	q23, [sp, #0x720]
    10bc:      	str	q17, [sp, #0x710]
    10c0:      	ldp	q17, q23, [x8, #0xa0]
    10c4:      	str	q23, [sp, #0x740]
    10c8:      	str	q17, [sp, #0x730]
    10cc:      	ldp	q17, q23, [x8, #0xc0]
    10d0:      	str	q23, [sp, #0x760]
    10d4:      	str	q17, [sp, #0x750]
    10d8:      	ldp	q17, q23, [x8, #0xe0]
    10dc:      	str	q23, [sp, #0x780]
    10e0:      	str	q17, [sp, #0x770]
    10e4:      	add	x9, x10, #0x100
    10e8:      	ldr	s17, [x3, x9]
    10ec:      	str	q17, [sp, #0x200]
    10f0:      	str	q17, [sp, #0x790]
    10f4:      	fmul.4s	v5, v5, v5
    10f8:      	fmul.4s	v2, v2, v2
    10fc:      	fmul.4s	v8, v7, v7
    1100:      	fmul.4s	v17, v6, v6
    1104:      	fmul.4s	v6, v20, v20
    1108:      	fmul.4s	v9, v16, v16
    110c:      	fmul.4s	v16, v22, v22
    1110:      	fmul.4s	v7, v21, v21
    1114:      	dup.2d	v11, x15
    1118:      	mov.16b	v12, v11
    111c:      	mov.16b	v13, v11
    1120:      	mov.16b	v14, v11
    1124:      	ldp	q31, q30, [sp, #0x270]
    1128:      	ldp	q26, q25, [sp, #0x240]
    112c:      	ldp	q28, q27, [sp, #0x220]
    1130:      	ldr	q29, [sp, #0x210]
    1134:      	shl.2d	v20, v11, #0x5
    1138:      	shl.2d	v21, v12, #0x5
    113c:      	shl.2d	v22, v13, #0x5
    1140:      	shl.2d	v23, v14, #0x5
    1144:      	add.2d	v15, v1, v23
    1148:      	add.2d	v23, v15, v19
    114c:      	add.2d	v20, v1, v20
    1150:      	add.2d	v24, v20, v3
    1154:      	mov.d	x8, v24[1]
    1158:      	add.2d	v10, v1, v22
    115c:      	add.2d	v21, v1, v21
    1160:      	fmov	x11, d24
    1164:      	add.2d	v22, v21, v4
    1168:      	mov.d	x14, v22[1]
    116c:      	fmov	x0, d22
    1170:      	add.2d	v22, v10, v18
    1174:      	mov.d	x2, v22[1]
    1178:      	fmov	x3, d22
    117c:      	mov.d	x27, v23[1]
    1180:      	ldr	s22, [x11]
    1184:      	ld1.s	{ v22 }[1], [x8]
    1188:      	fmov	x8, d23
    118c:      	ld1.s	{ v22 }[2], [x0]
    1190:      	ld1.s	{ v22 }[3], [x14]
    1194:      	ldr	s23, [x3]
    1198:      	ld1.s	{ v23 }[1], [x2]
    119c:      	ld1.s	{ v23 }[2], [x8]
    11a0:      	ld1.s	{ v23 }[3], [x27]
    11a4:      	fmul.4s	v23, v23, v23
    11a8:      	fmul.4s	v22, v22, v22
    11ac:      	fadd.4s	v2, v2, v22
    11b0:      	fadd.4s	v5, v5, v23
    11b4:      	ldr	q22, [sp, #0x2a0]
    11b8:      	add.2d	v22, v15, v22
    11bc:      	ldr	q23, [sp, #0x2d0]
    11c0:      	add.2d	v23, v20, v23
    11c4:      	mov.d	x8, v23[1]
    11c8:      	fmov	x11, d23
    11cc:      	ldr	q23, [sp, #0x2c0]
    11d0:      	add.2d	v23, v21, v23
    11d4:      	mov.d	x14, v23[1]
    11d8:      	fmov	x0, d23
    11dc:      	ldr	q23, [sp, #0x2b0]
    11e0:      	add.2d	v23, v10, v23
    11e4:      	mov.d	x2, v23[1]
    11e8:      	mov.d	x3, v22[1]
    11ec:      	fmov	x27, d23
    11f0:      	ldr	s23, [x11]
    11f4:      	ld1.s	{ v23 }[1], [x8]
    11f8:      	ld1.s	{ v23 }[2], [x0]
    11fc:      	fmov	x8, d22
    1200:      	ld1.s	{ v23 }[3], [x14]
    1204:      	ldr	s22, [x27]
    1208:      	ld1.s	{ v22 }[1], [x2]
    120c:      	ld1.s	{ v22 }[2], [x8]
    1210:      	ld1.s	{ v22 }[3], [x3]
    1214:      	fmul.4s	v22, v22, v22
    1218:      	fmul.4s	v23, v23, v23
    121c:      	fadd.4s	v17, v17, v23
    1220:      	fadd.4s	v8, v8, v22
    1224:      	add.2d	v22, v15, v25
    1228:      	ldr	q23, [sp, #0x290]
    122c:      	add.2d	v23, v20, v23
    1230:      	mov.d	x8, v23[1]
    1234:      	fmov	x11, d23
    1238:      	add.2d	v23, v21, v30
    123c:      	mov.d	x14, v23[1]
    1240:      	fmov	x0, d23
    1244:      	add.2d	v23, v10, v31
    1248:      	mov.d	x2, v23[1]
    124c:      	fmov	x3, d23
    1250:      	mov.d	x27, v22[1]
    1254:      	ldr	s23, [x11]
    1258:      	ld1.s	{ v23 }[1], [x8]
    125c:      	ld1.s	{ v23 }[2], [x0]
    1260:      	ld1.s	{ v23 }[3], [x14]
    1264:      	fmov	x8, d22
    1268:      	fmul.4s	v22, v23, v23
    126c:      	fadd.4s	v9, v9, v22
    1270:      	ldr	s22, [x3]
    1274:      	ld1.s	{ v22 }[1], [x2]
    1278:      	ld1.s	{ v22 }[2], [x8]
    127c:      	ld1.s	{ v22 }[3], [x27]
    1280:      	fmul.4s	v22, v22, v22
    1284:      	fadd.4s	v6, v6, v22
    1288:      	add.2d	v21, v21, v27
    128c:      	add.2d	v20, v20, v26
    1290:      	mov.d	x8, v20[1]
    1294:      	mov.d	x11, v21[1]
    1298:      	fmov	x14, d20
    129c:      	fmov	x0, d21
    12a0:      	add.2d	v20, v15, v29
    12a4:      	add.2d	v21, v10, v28
    12a8:      	mov.d	x2, v21[1]
    12ac:      	fmov	x3, d21
    12b0:      	mov.d	x27, v20[1]
    12b4:      	ldr	s21, [x14]
    12b8:      	ld1.s	{ v21 }[1], [x8]
    12bc:      	fmov	x8, d20
    12c0:      	ld1.s	{ v21 }[2], [x0]
    12c4:      	ld1.s	{ v21 }[3], [x11]
    12c8:      	fmul.4s	v20, v21, v21
    12cc:      	fadd.4s	v7, v7, v20
    12d0:      	ldr	s20, [x3]
    12d4:      	ld1.s	{ v20 }[1], [x2]
    12d8:      	ld1.s	{ v20 }[2], [x8]
    12dc:      	ld1.s	{ v20 }[3], [x27]
    12e0:      	fmul.4s	v20, v20, v20
    12e4:      	fadd.4s	v16, v16, v20
    12e8:      	dup.2d	v20, x15
    12ec:      	add.2d	v13, v13, v20
    12f0:      	add.2d	v12, v12, v20
    12f4:      	add.2d	v14, v14, v20
    12f8:      	add.2d	v11, v11, v20
    12fc:      	fmov	x8, d11
    1300:      	cmp	x8, #0x8
    1304:      	b.lt	0x1134 <ltmp0+0x1134>
    1308:      	mov	x11, #0x0               ; =0
    130c:      	movi.2d	v20, #0000000000000000
    1310:      	movi.2d	v21, #0000000000000000
    1314:      	movi.2d	v22, #0000000000000000
    1318:      	movi.2d	v23, #0000000000000000
    131c:      	add	x8, x13, x11, lsl #5
    1320:      	ldp	q25, q24, [x8]
    1324:      	shl.2d	v26, v20, #0x5
    1328:      	shl.2d	v27, v21, #0x5
    132c:      	shl.2d	v28, v22, #0x5
    1330:      	shl.2d	v29, v23, #0x5
    1334:      	add.2d	v29, v29, v19
    1338:      	add.2d	v29, v0, v29
    133c:      	add.2d	v28, v28, v18
    1340:      	add.2d	v27, v27, v4
    1344:      	add.2d	v26, v26, v3
    1348:      	add.2d	v26, v0, v26
    134c:      	mov.d	x8, v26[1]
    1350:      	fmov	x11, d26
    1354:      	str	s25, [x11]
    1358:      	st1.s	{ v25 }[1], [x8]
    135c:      	add.2d	v26, v0, v27
    1360:      	mov.d	x8, v26[1]
    1364:      	fmov	x11, d26
    1368:      	st1.s	{ v25 }[2], [x11]
    136c:      	add.2d	v26, v0, v28
    1370:      	st1.s	{ v25 }[3], [x8]
    1374:      	mov.d	x8, v26[1]
    1378:      	fmov	x11, d26
    137c:      	str	s24, [x11]
    1380:      	st1.s	{ v24 }[1], [x8]
    1384:      	mov.d	x8, v29[1]
    1388:      	fmov	x11, d29
    138c:      	st1.s	{ v24 }[2], [x11]
    1390:      	st1.s	{ v24 }[3], [x8]
    1394:      	dup.2d	v24, x26
    1398:      	add.2d	v22, v22, v24
    139c:      	add.2d	v21, v21, v24
    13a0:      	add.2d	v23, v23, v24
    13a4:      	add.2d	v20, v20, v24
    13a8:      	fmov	x11, d20
    13ac:      	cmp	x11, #0x8
    13b0:      	b.lt	0x131c <ltmp0+0x131c>
    13b4:      	mov	x11, #0x0               ; =0
    13b8:      	ldr	q20, [sp, #0x200]
    13bc:      	fmul.4s	v20, v20, v20
    13c0:      	fadd.4s	v20, v20, v2
    13c4:      	mov.s	v2[0], v20[0]
    13c8:      	ldr	q20, [sp, #0x670]
    13cc:      	ldr	x8, [sp, #0x1f0]
    13d0:      	ld1.s	{ v20 }[0], [x8]
    13d4:      	fadd.4s	v5, v8, v5
    13d8:      	fadd.4s	v2, v17, v2
    13dc:      	fadd.4s	v2, v9, v2
    13e0:      	fadd.4s	v5, v6, v5
    13e4:      	fadd.4s	v5, v16, v5
    13e8:      	fadd.4s	v2, v7, v2
    13ec:      	rev64.4s	v6, v2
    13f0:      	rev64.4s	v7, v5
    13f4:      	fadd.4s	v5, v5, v7
    13f8:      	fadd.4s	v2, v2, v6
    13fc:      	dup.4s	v6, v2[2]
    1400:      	dup.4s	v7, v5[2]
    1404:      	fadd.4s	v5, v5, v7
    1408:      	fadd.4s	v2, v2, v6
    140c:      	fadd.4s	v2, v2, v5
    1410:      	movi	d12, #0000000000000000
    1414:      	fadd	s2, s2, s12
    1418:      	mov	w8, #0x42820000         ; =1115815936
    141c:      	fmov	s5, w8
    1420:      	fdiv	s2, s2, s5
    1424:      	mov	w8, #0xc5ac             ; =50604
    1428:      	movk	w8, #0x3727, lsl #16
    142c:      	fmov	s5, w8
    1430:      	fadd	s2, s2, s5
    1434:      	fsqrt	s2, s2
    1438:      	dup.4s	v5, v2[0]
    143c:      	str	q20, [sp, #0x670]
    1440:      	add	x10, x12, x10
    1444:      	movi.2d	v6, #0000000000000000
    1448:      	movi.2d	v7, #0000000000000000
    144c:      	movi.2d	v16, #0000000000000000
    1450:      	movi.2d	v17, #0000000000000000
    1454:      	shl.2d	v21, v17, #0x5
    1458:      	shl.2d	v22, v16, #0x5
    145c:      	shl.2d	v23, v7, #0x5
    1460:      	shl.2d	v24, v6, #0x5
    1464:      	orr.16b	v24, v24, v3
    1468:      	orr.16b	v23, v23, v4
    146c:      	orr.16b	v22, v22, v18
    1470:      	orr.16b	v21, v21, v19
    1474:      	add.2d	v25, v1, v21
    1478:      	add.2d	v26, v1, v22
    147c:      	add.2d	v27, v1, v23
    1480:      	add.2d	v28, v1, v24
    1484:      	mov.d	x8, v28[1]
    1488:      	mov.d	x13, v27[1]
    148c:      	mov.d	x14, v26[1]
    1490:      	fmov	x0, d28
    1494:      	fmov	x2, d26
    1498:      	mov.d	x3, v25[1]
    149c:      	fmov	x27, d25
    14a0:      	ldr	s25, [x2]
    14a4:      	ld1.s	{ v25 }[1], [x14]
    14a8:      	ld1.s	{ v25 }[2], [x27]
    14ac:      	ld1.s	{ v25 }[3], [x3]
    14b0:      	fmov	x14, d27
    14b4:      	ldr	s26, [x0]
    14b8:      	ld1.s	{ v26 }[1], [x8]
    14bc:      	ld1.s	{ v26 }[2], [x14]
    14c0:      	ld1.s	{ v26 }[3], [x13]
    14c4:      	fdiv.4s	v26, v26, v5
    14c8:      	fdiv.4s	v25, v25, v5
    14cc:      	add.2d	v21, v0, v21
    14d0:      	add.2d	v22, v0, v22
    14d4:      	add.2d	v23, v0, v23
    14d8:      	add.2d	v24, v0, v24
    14dc:      	mov.d	x8, v24[1]
    14e0:      	fmov	x13, d24
    14e4:      	mov.d	x14, v23[1]
    14e8:      	mov.d	x0, v22[1]
    14ec:      	mov.d	x2, v21[1]
    14f0:      	fmov	x3, d23
    14f4:      	ldr	s23, [x13]
    14f8:      	ld1.s	{ v23 }[1], [x8]
    14fc:      	ld1.s	{ v23 }[2], [x3]
    1500:      	fmov	x8, d22
    1504:      	ld1.s	{ v23 }[3], [x14]
    1508:      	ldr	s22, [x8]
    150c:      	ld1.s	{ v22 }[1], [x0]
    1510:      	fmov	x8, d21
    1514:      	ld1.s	{ v22 }[2], [x8]
    1518:      	ld1.s	{ v22 }[3], [x2]
    151c:      	fmul.4s	v21, v25, v22
    1520:      	fmul.4s	v22, v26, v23
    1524:      	add	x8, x10, x11, lsl #5
    1528:      	stp	q22, q21, [x8]
    152c:      	dup.2d	v21, x26
    1530:      	add.2d	v16, v16, v21
    1534:      	add.2d	v7, v7, v21
    1538:      	add.2d	v17, v17, v21
    153c:      	add.2d	v6, v6, v21
    1540:      	fmov	x11, d6
    1544:      	cmp	x11, #0x8
    1548:      	b.lt	0x1454 <ltmp0+0x1454>
    154c:      	ldr	q5, [sp, #0x790]
    1550:      	fdiv.4s	v2, v5, v2
    1554:      	fmul.4s	v2, v20, v2
    1558:      	str	s2, [x12, x9]
    155c:      	ldr	w12, [sp, #0x174]
    1560:      	ldr	w13, [sp, #0x170]
    1564:      	ldr	w14, [sp, #0x16c]
    1568:      	ldr	x0, [sp, #0x178]
    156c:      	b	0xc8 <ltmp0+0xc8>
    1570:      	lsr	x8, x9, #3
    1574:      	str	x8, [sp, #0x2d0]
    1578:      	str	x9, [sp, #0x2a0]
    157c:      	cmp	x9, #0x8
    1580:      	b.lo	0x1ab8 <ltmp0+0x1ab8>
    1584:      	mov	x2, #0x0                ; =0
    1588:      	ldr	x8, [sp, #0x150]
    158c:      	ldr	x3, [x8]
    1590:      	ldr	x30, [x8, #0x10]
    1594:      	ldr	x9, [x8, #0x30]
    1598:      	add	x8, x30, #0x100
    159c:      	str	x8, [sp, #0x2c0]
    15a0:      	ldr	x8, [sp, #0x178]
    15a4:      	lsl	w8, w8, #2
    15a8:      	str	x8, [sp, #0x2b0]
    15ac:      	ldr	x8, [sp, #0x2b0]
    15b0:      	add	w8, w2, w8
    15b4:      	and	x8, x8, #0x1fffffff
    15b8:      	add	x8, x8, x8, lsl #6
    15bc:      	lsl	x11, x8, #2
    15c0:      	add	x8, x3, x11
    15c4:      	ldp	q2, q5, [x8]
    15c8:      	str	q5, [sp, #0x6a0]
    15cc:      	str	q2, [sp, #0x690]
    15d0:      	ldp	q17, q18, [x8, #0x20]
    15d4:      	str	q18, [sp, #0x6c0]
    15d8:      	str	q17, [sp, #0x6b0]
    15dc:      	ldp	q19, q22, [x8, #0x40]
    15e0:      	str	q22, [sp, #0x6e0]
    15e4:      	str	q19, [sp, #0x6d0]
    15e8:      	ldp	q23, q24, [x8, #0x60]
    15ec:      	str	q24, [sp, #0x700]
    15f0:      	str	q23, [sp, #0x6f0]
    15f4:      	ldp	q6, q7, [x8, #0x80]
    15f8:      	str	q7, [sp, #0x720]
    15fc:      	str	q6, [sp, #0x710]
    1600:      	ldp	q6, q7, [x8, #0xa0]
    1604:      	str	q7, [sp, #0x740]
    1608:      	str	q6, [sp, #0x730]
    160c:      	ldp	q6, q7, [x8, #0xc0]
    1610:      	str	q7, [sp, #0x760]
    1614:      	str	q6, [sp, #0x750]
    1618:      	ldp	q6, q7, [x8, #0xe0]
    161c:      	str	q7, [sp, #0x780]
    1620:      	str	q6, [sp, #0x770]
    1624:      	add	x0, x11, #0x100
    1628:      	ldr	s16, [x3, x0]
    162c:      	str	q16, [sp, #0x790]
    1630:      	fmul.4s	v7, v5, v5
    1634:      	fmul.4s	v6, v2, v2
    1638:      	fmul.4s	v21, v18, v18
    163c:      	fmul.4s	v20, v17, v17
    1640:      	fmul.4s	v17, v22, v22
    1644:      	fmul.4s	v22, v19, v19
    1648:      	fmul.4s	v19, v24, v24
    164c:      	fmul.4s	v18, v23, v23
    1650:      	dup.2d	v23, x15
    1654:      	mov.16b	v24, v23
    1658:      	mov.16b	v25, v23
    165c:      	mov.16b	v26, v23
    1660:      	shl.2d	v2, v23, #0x5
    1664:      	add.2d	v27, v1, v2
    1668:      	add.2d	v31, v27, v3
    166c:      	mov.d	x8, v31[1]
    1670:      	shl.2d	v2, v24, #0x5
    1674:      	add.2d	v28, v1, v2
    1678:      	add.2d	v8, v28, v4
    167c:      	mov.d	x27, v8[1]
    1680:      	ldr	q2, [x16]
    1684:      	shl.2d	v5, v25, #0x5
    1688:      	add.2d	v29, v1, v5
    168c:      	add.2d	v9, v29, v2
    1690:      	mov.d	x28, v9[1]
    1694:      	ldr	q5, [x17]
    1698:      	shl.2d	v30, v26, #0x5
    169c:      	add.2d	v30, v1, v30
    16a0:      	add.2d	v10, v30, v5
    16a4:      	mov.d	x13, v10[1]
    16a8:      	fmov	x12, d31
    16ac:      	ldr	s31, [x12]
    16b0:      	fmov	x12, d8
    16b4:      	fmov	x14, d9
    16b8:      	ld1.s	{ v31 }[1], [x8]
    16bc:      	fmov	x8, d10
    16c0:      	ld1.s	{ v31 }[2], [x12]
    16c4:      	ld1.s	{ v31 }[3], [x27]
    16c8:      	ldr	s8, [x14]
    16cc:      	ld1.s	{ v8 }[1], [x28]
    16d0:      	ld1.s	{ v8 }[2], [x8]
    16d4:      	ld1.s	{ v8 }[3], [x13]
    16d8:      	fmul.4s	v8, v8, v8
    16dc:      	fmul.4s	v31, v31, v31
    16e0:      	fadd.4s	v6, v6, v31
    16e4:      	fadd.4s	v7, v7, v8
    16e8:      	ldr	q31, [x1]
    16ec:      	ldr	q8, [x4]
    16f0:      	ldr	q9, [x5]
    16f4:      	ldr	q10, [x6]
    16f8:      	add.2d	v10, v30, v10
    16fc:      	add.2d	v9, v29, v9
    1700:      	add.2d	v8, v28, v8
    1704:      	add.2d	v31, v27, v31
    1708:      	mov.d	x8, v31[1]
    170c:      	fmov	x12, d31
    1710:      	mov.d	x13, v8[1]
    1714:      	fmov	x14, d8
    1718:      	mov.d	x27, v9[1]
    171c:      	fmov	x28, d9
    1720:      	mov.d	x10, v10[1]
    1724:      	ldr	s31, [x12]
    1728:      	ld1.s	{ v31 }[1], [x8]
    172c:      	ld1.s	{ v31 }[2], [x14]
    1730:      	ld1.s	{ v31 }[3], [x13]
    1734:      	fmov	x8, d10
    1738:      	ldr	s8, [x28]
    173c:      	ld1.s	{ v8 }[1], [x27]
    1740:      	ld1.s	{ v8 }[2], [x8]
    1744:      	ld1.s	{ v8 }[3], [x10]
    1748:      	fmul.4s	v8, v8, v8
    174c:      	fmul.4s	v31, v31, v31
    1750:      	fadd.4s	v20, v20, v31
    1754:      	fadd.4s	v21, v21, v8
    1758:      	ldr	q31, [x7]
    175c:      	ldr	q8, [x19]
    1760:      	ldr	q9, [x20]
    1764:      	ldr	q10, [x21]
    1768:      	add.2d	v10, v30, v10
    176c:      	add.2d	v9, v29, v9
    1770:      	add.2d	v8, v28, v8
    1774:      	add.2d	v31, v27, v31
    1778:      	mov.d	x8, v31[1]
    177c:      	mov.d	x10, v8[1]
    1780:      	fmov	x12, d31
    1784:      	fmov	x13, d8
    1788:      	mov.d	x14, v9[1]
    178c:      	mov.d	x27, v10[1]
    1790:      	fmov	x28, d9
    1794:      	ldr	s31, [x12]
    1798:      	ld1.s	{ v31 }[1], [x8]
    179c:      	ld1.s	{ v31 }[2], [x13]
    17a0:      	fmov	x8, d10
    17a4:      	ld1.s	{ v31 }[3], [x10]
    17a8:      	ldr	s8, [x28]
    17ac:      	ld1.s	{ v8 }[1], [x14]
    17b0:      	ld1.s	{ v8 }[2], [x8]
    17b4:      	ld1.s	{ v8 }[3], [x27]
    17b8:      	fmul.4s	v8, v8, v8
    17bc:      	fmul.4s	v31, v31, v31
    17c0:      	fadd.4s	v22, v22, v31
    17c4:      	fadd.4s	v17, v17, v8
    17c8:      	ldr	q31, [x22]
    17cc:      	ldr	q8, [x23]
    17d0:      	ldr	q9, [x24]
    17d4:      	ldr	q10, [x25]
    17d8:      	add.2d	v30, v30, v10
    17dc:      	add.2d	v29, v29, v9
    17e0:      	add.2d	v28, v28, v8
    17e4:      	add.2d	v27, v27, v31
    17e8:      	mov.d	x8, v27[1]
    17ec:      	fmov	x10, d27
    17f0:      	mov.d	x12, v28[1]
    17f4:      	fmov	x13, d28
    17f8:      	mov.d	x14, v29[1]
    17fc:      	fmov	x27, d29
    1800:      	mov.d	x28, v30[1]
    1804:      	ldr	s27, [x10]
    1808:      	ld1.s	{ v27 }[1], [x8]
    180c:      	fmov	x8, d30
    1810:      	ld1.s	{ v27 }[2], [x13]
    1814:      	ld1.s	{ v27 }[3], [x12]
    1818:      	ldr	s28, [x27]
    181c:      	ld1.s	{ v28 }[1], [x14]
    1820:      	ld1.s	{ v28 }[2], [x8]
    1824:      	ld1.s	{ v28 }[3], [x28]
    1828:      	fmul.4s	v28, v28, v28
    182c:      	fmul.4s	v27, v27, v27
    1830:      	fadd.4s	v18, v18, v27
    1834:      	fadd.4s	v19, v19, v28
    1838:      	dup.2d	v27, x15
    183c:      	add.2d	v25, v25, v27
    1840:      	add.2d	v24, v24, v27
    1844:      	add.2d	v26, v26, v27
    1848:      	add.2d	v23, v23, v27
    184c:      	fmov	x8, d23
    1850:      	cmp	x8, #0x8
    1854:      	b.lt	0x1660 <ltmp0+0x1660>
    1858:      	mov	x27, #0x0               ; =0
    185c:      	movi.2d	v23, #0000000000000000
    1860:      	movi.2d	v24, #0000000000000000
    1864:      	movi.2d	v25, #0000000000000000
    1868:      	movi.2d	v26, #0000000000000000
    186c:      	add	x8, x30, x27, lsl #5
    1870:      	ldp	q28, q27, [x8]
    1874:      	shl.2d	v29, v23, #0x5
    1878:      	shl.2d	v30, v24, #0x5
    187c:      	shl.2d	v31, v25, #0x5
    1880:      	shl.2d	v8, v26, #0x5
    1884:      	add.2d	v8, v8, v5
    1888:      	add.2d	v8, v0, v8
    188c:      	add.2d	v31, v31, v2
    1890:      	add.2d	v30, v30, v4
    1894:      	add.2d	v29, v29, v3
    1898:      	add.2d	v29, v0, v29
    189c:      	mov.d	x8, v29[1]
    18a0:      	fmov	x10, d29
    18a4:      	str	s28, [x10]
    18a8:      	st1.s	{ v28 }[1], [x8]
    18ac:      	add.2d	v29, v0, v30
    18b0:      	mov.d	x8, v29[1]
    18b4:      	fmov	x10, d29
    18b8:      	st1.s	{ v28 }[2], [x10]
    18bc:      	add.2d	v29, v0, v31
    18c0:      	st1.s	{ v28 }[3], [x8]
    18c4:      	mov.d	x8, v29[1]
    18c8:      	fmov	x10, d29
    18cc:      	str	s27, [x10]
    18d0:      	st1.s	{ v27 }[1], [x8]
    18d4:      	mov.d	x8, v8[1]
    18d8:      	fmov	x10, d8
    18dc:      	st1.s	{ v27 }[2], [x10]
    18e0:      	st1.s	{ v27 }[3], [x8]
    18e4:      	dup.2d	v27, x26
    18e8:      	add.2d	v25, v25, v27
    18ec:      	add.2d	v24, v24, v27
    18f0:      	add.2d	v26, v26, v27
    18f4:      	add.2d	v23, v23, v27
    18f8:      	fmov	x27, d23
    18fc:      	cmp	x27, #0x8
    1900:      	b.lt	0x186c <ltmp0+0x186c>
    1904:      	mov	x27, #0x0               ; =0
    1908:      	fmul.4s	v16, v16, v16
    190c:      	fadd.4s	v16, v16, v6
    1910:      	mov.s	v6[0], v16[0]
    1914:      	fadd.4s	v7, v21, v7
    1918:      	fadd.4s	v6, v20, v6
    191c:      	fadd.4s	v6, v22, v6
    1920:      	fadd.4s	v7, v17, v7
    1924:      	fadd.4s	v7, v19, v7
    1928:      	fadd.4s	v6, v18, v6
    192c:      	rev64.4s	v16, v6
    1930:      	rev64.4s	v17, v7
    1934:      	fadd.4s	v7, v7, v17
    1938:      	fadd.4s	v6, v6, v16
    193c:      	dup.4s	v16, v6[2]
    1940:      	dup.4s	v17, v7[2]
    1944:      	fadd.4s	v7, v7, v17
    1948:      	fadd.4s	v6, v6, v16
    194c:      	fadd.4s	v6, v6, v7
    1950:      	fadd	s7, s6, s12
    1954:      	mov	w8, #0x42820000         ; =1115815936
    1958:      	fmov	s16, w8
    195c:      	ldr	q6, [sp, #0x670]
    1960:      	ldr	x8, [sp, #0x2c0]
    1964:      	ld1.s	{ v6 }[0], [x8]
    1968:      	fdiv	s7, s7, s16
    196c:      	mov	w8, #0xc5ac             ; =50604
    1970:      	movk	w8, #0x3727, lsl #16
    1974:      	fmov	s16, w8
    1978:      	fadd	s7, s7, s16
    197c:      	fsqrt	s7, s7
    1980:      	dup.4s	v16, v7[0]
    1984:      	str	q6, [sp, #0x670]
    1988:      	add	x11, x9, x11
    198c:      	movi.2d	v17, #0000000000000000
    1990:      	movi.2d	v18, #0000000000000000
    1994:      	movi.2d	v19, #0000000000000000
    1998:      	movi.2d	v20, #0000000000000000
    199c:      	shl.2d	v21, v20, #0x5
    19a0:      	shl.2d	v22, v19, #0x5
    19a4:      	shl.2d	v23, v18, #0x5
    19a8:      	shl.2d	v24, v17, #0x5
    19ac:      	orr.16b	v24, v24, v3
    19b0:      	orr.16b	v23, v23, v4
    19b4:      	orr.16b	v22, v22, v2
    19b8:      	orr.16b	v21, v21, v5
    19bc:      	add.2d	v25, v1, v21
    19c0:      	add.2d	v26, v1, v22
    19c4:      	add.2d	v27, v1, v23
    19c8:      	add.2d	v28, v1, v24
    19cc:      	mov.d	x8, v28[1]
    19d0:      	mov.d	x10, v27[1]
    19d4:      	mov.d	x12, v26[1]
    19d8:      	fmov	x13, d28
    19dc:      	fmov	x14, d26
    19e0:      	mov.d	x28, v25[1]
    19e4:      	fmov	x1, d25
    19e8:      	ldr	s25, [x14]
    19ec:      	ld1.s	{ v25 }[1], [x12]
    19f0:      	ld1.s	{ v25 }[2], [x1]
    19f4:      	ld1.s	{ v25 }[3], [x28]
    19f8:      	fmov	x12, d27
    19fc:      	ldr	s26, [x13]
    1a00:      	ld1.s	{ v26 }[1], [x8]
    1a04:      	ld1.s	{ v26 }[2], [x12]
    1a08:      	ld1.s	{ v26 }[3], [x10]
    1a0c:      	fdiv.4s	v26, v26, v16
    1a10:      	fdiv.4s	v25, v25, v16
    1a14:      	add.2d	v21, v0, v21
    1a18:      	add.2d	v22, v0, v22
    1a1c:      	add.2d	v23, v0, v23
    1a20:      	add.2d	v24, v0, v24
    1a24:      	mov.d	x8, v24[1]
    1a28:      	fmov	x10, d24
    1a2c:      	mov.d	x12, v23[1]
    1a30:      	mov.d	x13, v22[1]
    1a34:      	mov.d	x14, v21[1]
    1a38:      	fmov	x1, d23
    1a3c:      	ldr	s23, [x10]
    1a40:      	ld1.s	{ v23 }[1], [x8]
    1a44:      	ld1.s	{ v23 }[2], [x1]
    1a48:      	fmov	x8, d22
    1a4c:      	ld1.s	{ v23 }[3], [x12]
    1a50:      	ldr	s22, [x8]
    1a54:      	ld1.s	{ v22 }[1], [x13]
    1a58:      	fmov	x8, d21
    1a5c:      	ld1.s	{ v22 }[2], [x8]
    1a60:      	ld1.s	{ v22 }[3], [x14]
    1a64:      	fmul.4s	v21, v25, v22
    1a68:      	fmul.4s	v22, v26, v23
    1a6c:      	add	x8, x11, x27, lsl #5
    1a70:      	stp	q22, q21, [x8]
    1a74:      	dup.2d	v21, x26
    1a78:      	add.2d	v19, v19, v21
    1a7c:      	add.2d	v18, v18, v21
    1a80:      	add.2d	v20, v20, v21
    1a84:      	add.2d	v17, v17, v21
    1a88:      	fmov	x27, d17
    1a8c:      	cmp	x27, #0x8
    1a90:      	b.lt	0x199c <ltmp0+0x199c>
    1a94:      	ldr	q2, [sp, #0x790]
    1a98:      	fdiv.4s	v2, v2, v7
    1a9c:      	fmul.4s	v2, v6, v2
    1aa0:      	str	s2, [x9, x0]
    1aa4:      	add	x2, x2, #0x1
    1aa8:      	ldr	x8, [sp, #0x2d0]
    1aac:      	cmp	x2, x8
    1ab0:      	adrp	x1, 0x1000 <ltmp0+0x1000>
    1ab4:      	b.ne	0x15ac <ltmp0+0x15ac>
    1ab8:      	ldr	x8, [sp, #0x2a0]
    1abc:      	and	w9, w8, #0x7
    1ac0:      	ldr	w12, [sp, #0x174]
    1ac4:      	ldr	w13, [sp, #0x170]
    1ac8:      	ldr	w14, [sp, #0x16c]
    1acc:      	ldr	x0, [sp, #0x178]
    1ad0:      	cbz	w9, 0xc8 <ltmp0+0xc8>
    1ad4:      	dup.4s	v2, w9
    1ad8:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1adc:      	ldr	q5, [x8]
    1ae0:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1ae4:      	ldr	q6, [x8]
    1ae8:      	cmhi.4s	v10, v2, v6
    1aec:      	cmhi.4s	v2, v2, v5
    1af0:      	uzp1.8h	v6, v2, v10
    1af4:      	umaxv.8h	h5, v6
    1af8:      	fmov	w8, s5
    1afc:      	tbz	w8, #0x0, 0xc8 <ltmp0+0xc8>
    1b00:      	mov	x10, #0x0               ; =0
    1b04:      	ldr	x8, [sp, #0x150]
    1b08:      	ldr	x9, [x8]
    1b0c:      	ldr	x3, [x8, #0x10]
    1b10:      	ldr	x1, [x8, #0x30]
    1b14:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1b18:      	ldr	q5, [x8]
    1b1c:      	str	q6, [sp, #0x90]
    1b20:      	and.16b	v5, v6, v5
    1b24:      	addv.8h	h18, v5
    1b28:      	ubfiz	w8, w0, #2, #27
    1b2c:      	ldr	x11, [sp, #0x2d0]
    1b30:      	orr	w8, w8, w11
    1b34:      	fmov	w11, s18
    1b38:      	and	w11, w11, #0xff
    1b3c:      	str	w11, [sp, #0xe4]
    1b40:      	dup.4s	v5, w8
    1b44:      	and.16b	v16, v2, v5
    1b48:      	and.16b	v7, v10, v5
    1b4c:      	ushll2.2d	v5, v7, #0x0
    1b50:      	ushll2.2d	v6, v16, #0x0
    1b54:      	ushll.2d	v7, v7, #0x0
    1b58:      	ushll.2d	v17, v16, #0x0
    1b5c:      	fmov	x8, d17
    1b60:      	mov	w11, #0x104             ; =260
    1b64:      	umaddl	x11, w8, w11, x9
    1b68:      	add	x14, sp, #0x690
    1b6c:      	b	0x1b90 <ltmp0+0x1b90>
    1b70:      	add	x8, x14, x10
    1b74:      	ldp	q20, q21, [x8]
    1b78:      	bif.16b	v19, v21, v10
    1b7c:      	bif.16b	v16, v20, v2
    1b80:      	stp	q16, q19, [x8]
    1b84:      	add	x10, x10, #0x20
    1b88:      	cmp	x10, #0x100
    1b8c:      	b.eq	0x1c28 <ltmp0+0x1c28>
    1b90:      	fmov	w13, s18
    1b94:      	add	x12, x11, x10
    1b98:      	movi.2d	v16, #0000000000000000
    1b9c:      	movi.2d	v19, #0000000000000000
    1ba0:      	tbnz	w13, #0x0, 0x1bc8 <ltmp0+0x1bc8>
    1ba4:      	and	w13, w13, #0xff
    1ba8:      	tbnz	w13, #0x1, 0x1bd4 <ltmp0+0x1bd4>
    1bac:      	tbnz	w13, #0x2, 0x1be0 <ltmp0+0x1be0>
    1bb0:      	tbnz	w13, #0x3, 0x1bec <ltmp0+0x1bec>
    1bb4:      	tbnz	w13, #0x4, 0x1bf8 <ltmp0+0x1bf8>
    1bb8:      	tbnz	w13, #0x5, 0x1c04 <ltmp0+0x1c04>
    1bbc:      	tbnz	w13, #0x6, 0x1c10 <ltmp0+0x1c10>
    1bc0:      	tbz	w13, #0x7, 0x1b70 <ltmp0+0x1b70>
    1bc4:      	b	0x1c1c <ltmp0+0x1c1c>
    1bc8:      	ldr	s16, [x12]
    1bcc:      	and	w13, w13, #0xff
    1bd0:      	tbz	w13, #0x1, 0x1bac <ltmp0+0x1bac>
    1bd4:      	add	x8, x12, #0x4
    1bd8:      	ld1.s	{ v16 }[1], [x8]
    1bdc:      	tbz	w13, #0x2, 0x1bb0 <ltmp0+0x1bb0>
    1be0:      	add	x8, x12, #0x8
    1be4:      	ld1.s	{ v16 }[2], [x8]
    1be8:      	tbz	w13, #0x3, 0x1bb4 <ltmp0+0x1bb4>
    1bec:      	add	x8, x12, #0xc
    1bf0:      	ld1.s	{ v16 }[3], [x8]
    1bf4:      	tbz	w13, #0x4, 0x1bb8 <ltmp0+0x1bb8>
    1bf8:      	add	x8, x12, #0x10
    1bfc:      	ld1.s	{ v19 }[0], [x8]
    1c00:      	tbz	w13, #0x5, 0x1bbc <ltmp0+0x1bbc>
    1c04:      	add	x8, x12, #0x14
    1c08:      	ld1.s	{ v19 }[1], [x8]
    1c0c:      	tbz	w13, #0x6, 0x1bc0 <ltmp0+0x1bc0>
    1c10:      	add	x8, x12, #0x18
    1c14:      	ld1.s	{ v19 }[2], [x8]
    1c18:      	tbz	w13, #0x7, 0x1b70 <ltmp0+0x1b70>
    1c1c:      	add	x8, x12, #0x1c
    1c20:      	ld1.s	{ v19 }[3], [x8]
    1c24:      	b	0x1b70 <ltmp0+0x1b70>
    1c28:      	xtn.4h	v16, v2
    1c2c:      	uzp1.8b	v20, v16, v0
    1c30:      	sshll.2d	v16, v2, #0x0
    1c34:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1c38:      	ldr	q19, [x8]
    1c3c:      	and.16b	v21, v16, v19
    1c40:      	movi.2d	v22, #0000000000000000
    1c44:      	mov.b	v22[0], v20[0]
    1c48:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1c4c:      	ldr	d19, [x8]
    1c50:      	str	d19, [sp, #0xb8]
    1c54:      	and.8b	v19, v22, v19
    1c58:      	addv.8b	b19, v19
    1c5c:      	fmov	w10, s19
    1c60:      	umaxv.8b	b19, v22
    1c64:      	fmov	w8, s19
    1c68:      	rbit	w11, w10
    1c6c:      	clz	w11, w11
    1c70:      	tst	w8, #0x1
    1c74:      	csel	w13, w11, wzr, ne
    1c78:      	mov	w11, #0x40              ; =64
    1c7c:      	dup.2d	v19, x11
    1c80:      	str	q21, [sp, #0x60]
    1c84:      	orr.16b	v23, v21, v19
    1c88:      	xtn.2s	v17, v17
    1c8c:      	str	q23, [sp, #0xc0]
    1c90:      	movi.2s	v21, #0x41
    1c94:      	umlal.2d	v23, v17, v21
    1c98:      	movi.2d	v21, #0000000000000000
    1c9c:      	mov.b	v21[0], v20[0]
    1ca0:      	ushll.2d	v20, v21, #0x0
    1ca4:      	shl.2d	v20, v20, #0x3f
    1ca8:      	cmlt.2d	v20, v20, #0
    1cac:      	str	q23, [sp, #0x120]
    1cb0:      	and.16b	v20, v20, v23
    1cb4:      	movi.2d	v21, #0000000000000000
    1cb8:      	str	q21, [sp, #0x550]
    1cbc:      	str	q21, [sp, #0x540]
    1cc0:      	str	q21, [sp, #0x530]
    1cc4:      	str	q20, [sp, #0x520]
    1cc8:      	and	x11, x13, #0x7
    1ccc:      	add	x12, sp, #0x520
    1cd0:      	ldr	x11, [x12, x11, lsl #3]
    1cd4:      	sub	x11, x11, x13
    1cd8:      	add	x9, x9, x11, lsl #2
    1cdc:      	movi.2d	v27, #0000000000000000
    1ce0:      	movi.2d	v28, #0000000000000000
    1ce4:      	tbnz	w8, #0x0, 0x2e1c <ltmp0+0x2e1c>
    1ce8:      	tbnz	w10, #0x1, 0x2e24 <ltmp0+0x2e24>
    1cec:      	tbnz	w10, #0x2, 0x2e30 <ltmp0+0x2e30>
    1cf0:      	tbnz	w10, #0x3, 0x2e3c <ltmp0+0x2e3c>
    1cf4:      	tbnz	w10, #0x4, 0x2e48 <ltmp0+0x2e48>
    1cf8:      	tbnz	w10, #0x5, 0x2e54 <ltmp0+0x2e54>
    1cfc:      	tbnz	w10, #0x6, 0x2e60 <ltmp0+0x2e60>
    1d00:      	tbz	w10, #0x7, 0x1d0c <ltmp0+0x1d0c>
    1d04:      	add	x8, x9, #0x1c
    1d08:      	ld1.s	{ v28 }[3], [x8]
    1d0c:      	sshll.2d	v20, v10, #0x0
    1d10:      	sshll2.2d	v30, v2, #0x0
    1d14:      	sshll2.2d	v31, v10, #0x0
    1d18:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1d1c:      	ldr	q21, [x8]
    1d20:      	and.16b	v29, v31, v21
    1d24:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1d28:      	ldr	q21, [x8]
    1d2c:      	and.16b	v26, v30, v21
    1d30:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1d34:      	ldr	q21, [x8]
    1d38:      	and.16b	v25, v20, v21
    1d3c:      	and.16b	v23, v20, v1
    1d40:      	and.16b	v21, v16, v1
    1d44:      	stp	q21, q23, [sp, #0x2c0]
    1d48:      	ldr	q21, [x17]
    1d4c:      	and.16b	v23, v31, v21
    1d50:      	and.16b	v24, v30, v4
    1d54:      	ldr	q21, [x16]
    1d58:      	and.16b	v20, v20, v21
    1d5c:      	and.16b	v21, v16, v3
    1d60:      	stp	q25, q26, [sp, #0x10]
    1d64:      	orr.16b	v25, v25, v19
    1d68:      	orr.16b	v26, v26, v19
    1d6c:      	str	q29, [sp, #0x30]
    1d70:      	orr.16b	v19, v29, v19
    1d74:      	movi.2s	v16, #0x41
    1d78:      	umull.2d	v17, v17, v16
    1d7c:      	str	q17, [sp, #0xd0]
    1d80:      	xtn.2s	v6, v6
    1d84:      	xtn.2s	v7, v7
    1d88:      	xtn.2s	v5, v5
    1d8c:      	str	q19, [sp, #0xa0]
    1d90:      	mov.16b	v17, v19
    1d94:      	umlal.2d	v17, v5, v16
    1d98:      	stp	q26, q25, [sp, #0x70]
    1d9c:      	mov.16b	v5, v26
    1da0:      	umlal.2d	v5, v6, v16
    1da4:      	stp	q5, q17, [sp, #0x100]
    1da8:      	mov.16b	v5, v25
    1dac:      	umlal.2d	v5, v7, v16
    1db0:      	str	q5, [sp, #0xf0]
    1db4:      	str	q21, [sp, #0x4e0]
    1db8:      	str	q24, [sp, #0x4f0]
    1dbc:      	str	q20, [sp, #0x500]
    1dc0:      	str	q23, [sp, #0x510]
    1dc4:      	and	x8, x13, #0x7
    1dc8:      	add	x9, sp, #0x4e0
    1dcc:      	ldr	x8, [x9, x8, lsl #3]
    1dd0:      	orr	x8, x8, #0x100
    1dd4:      	sub	x8, x8, x13, lsl #2
    1dd8:      	tst	w10, #0xff
    1ddc:      	csel	x8, xzr, x8, eq
    1de0:      	str	x8, [sp, #0xe8]
    1de4:      	add	x8, x14, x8
    1de8:      	ldp	q5, q6, [x8]
    1dec:      	zip2.8b	v7, v22, v0
    1df0:      	ushll.4s	v7, v7, #0x0
    1df4:      	shl.4s	v7, v7, #0x1f
    1df8:      	cmlt.4s	v7, v7, #0
    1dfc:      	stp	q28, q27, [sp, #0x40]
    1e00:      	bit.16b	v6, v28, v7
    1e04:      	str	q22, [sp, #0x130]
    1e08:      	zip1.8b	v7, v22, v0
    1e0c:      	ushll.4s	v7, v7, #0x0
    1e10:      	shl.4s	v7, v7, #0x1f
    1e14:      	cmlt.4s	v7, v7, #0
    1e18:      	bit.16b	v5, v27, v7
    1e1c:      	stp	q5, q6, [x8]
    1e20:      	mov	w8, #0x20               ; =32
    1e24:      	dup.2d	v5, x8
    1e28:      	orr.16b	v7, v20, v5
    1e2c:      	orr.16b	v6, v24, v5
    1e30:      	stp	q6, q7, [sp, #0x220]
    1e34:      	orr.16b	v6, v21, v5
    1e38:      	orr.16b	v5, v23, v5
    1e3c:      	stp	q5, q6, [sp, #0x200]
    1e40:      	mov	w8, #0x40               ; =64
    1e44:      	dup.2d	v5, x8
    1e48:      	orr.16b	v7, v20, v5
    1e4c:      	orr.16b	v6, v24, v5
    1e50:      	stp	q6, q7, [sp, #0x1e0]
    1e54:      	orr.16b	v6, v21, v5
    1e58:      	orr.16b	v5, v23, v5
    1e5c:      	stp	q5, q6, [sp, #0x1c0]
    1e60:      	mov	w8, #0x60               ; =96
    1e64:      	dup.2d	v5, x8
    1e68:      	stp	q20, q24, [sp, #0x280]
    1e6c:      	orr.16b	v7, v20, v5
    1e70:      	orr.16b	v6, v24, v5
    1e74:      	stp	q6, q7, [sp, #0x1a0]
    1e78:      	orr.16b	v6, v21, v5
    1e7c:      	str	q23, [sp, #0x2a0]
    1e80:      	orr.16b	v5, v23, v5
    1e84:      	stp	q5, q6, [sp, #0x180]
    1e88:      	ldr	q5, [sp, #0x700]
    1e8c:      	ldr	q6, [sp, #0x6f0]
    1e90:      	fmul.4s	v6, v6, v6
    1e94:      	fmul.4s	v5, v5, v5
    1e98:      	and.16b	v14, v10, v5
    1e9c:      	and.16b	v20, v2, v6
    1ea0:      	ldr	q5, [sp, #0x6d0]
    1ea4:      	fmul.4s	v5, v5, v5
    1ea8:      	ldr	q6, [sp, #0x6e0]
    1eac:      	fmul.4s	v6, v6, v6
    1eb0:      	and.16b	v23, v10, v6
    1eb4:      	and.16b	v15, v2, v5
    1eb8:      	ldr	q5, [sp, #0x6b0]
    1ebc:      	fmul.4s	v5, v5, v5
    1ec0:      	ldr	q6, [sp, #0x6c0]
    1ec4:      	fmul.4s	v6, v6, v6
    1ec8:      	and.16b	v11, v10, v6
    1ecc:      	and.16b	v13, v2, v5
    1ed0:      	str	q21, [sp, #0x270]
    1ed4:      	fmov	x8, d21
    1ed8:      	add	x8, x14, x8
    1edc:      	ldp	q5, q6, [x8]
    1ee0:      	fmul.4s	v5, v5, v5
    1ee4:      	fmul.4s	v6, v6, v6
    1ee8:      	and.16b	v21, v10, v6
    1eec:      	and.16b	v12, v2, v5
    1ef0:      	sshll.2d	v5, v10, #0x0
    1ef4:      	dup.2d	v6, x15
    1ef8:      	and.16b	v5, v5, v6
    1efc:      	sshll.2d	v7, v2, #0x0
    1f00:      	and.16b	v19, v7, v6
    1f04:      	and.16b	v16, v31, v6
    1f08:      	and.16b	v17, v30, v6
    1f0c:      	stp	q31, q30, [sp, #0x240]
    1f10:      	and.16b	v6, v31, v1
    1f14:      	str	q6, [sp, #0x2b0]
    1f18:      	and.16b	v31, v30, v1
    1f1c:      	b	0x1fc0 <ltmp0+0x1fc0>
    1f20:      	fmul.4s	v6, v9, v9
    1f24:      	fmul.4s	v7, v8, v8
    1f28:      	fadd.4s	v22, v12, v7
    1f2c:      	fadd.4s	v26, v21, v6
    1f30:      	fmul.4s	v6, v28, v28
    1f34:      	fmul.4s	v7, v27, v27
    1f38:      	fadd.4s	v7, v13, v7
    1f3c:      	fadd.4s	v6, v11, v6
    1f40:      	fmul.4s	v24, v24, v24
    1f44:      	fmul.4s	v27, v29, v29
    1f48:      	fadd.4s	v27, v15, v27
    1f4c:      	fadd.4s	v24, v23, v24
    1f50:      	sshll.2d	v28, v2, #0x0
    1f54:      	sshll.2d	v29, v10, #0x0
    1f58:      	fmul.4s	v25, v25, v25
    1f5c:      	fmul.4s	v30, v30, v30
    1f60:      	fadd.4s	v30, v14, v30
    1f64:      	fadd.4s	v25, v20, v25
    1f68:      	dup.2d	v8, x15
    1f6c:      	ldr	q9, [sp, #0x240]
    1f70:      	and.16b	v9, v9, v8
    1f74:      	add.2d	v16, v16, v9
    1f78:      	ldr	q9, [sp, #0x250]
    1f7c:      	and.16b	v9, v9, v8
    1f80:      	add.2d	v17, v17, v9
    1f84:      	and.16b	v29, v29, v8
    1f88:      	add.2d	v5, v5, v29
    1f8c:      	and.16b	v28, v28, v8
    1f90:      	add.2d	v19, v19, v28
    1f94:      	bit.16b	v21, v26, v10
    1f98:      	bit.16b	v12, v22, v2
    1f9c:      	bit.16b	v11, v6, v10
    1fa0:      	bit.16b	v13, v7, v2
    1fa4:      	bit.16b	v23, v24, v10
    1fa8:      	bit.16b	v15, v27, v2
    1fac:      	bit.16b	v20, v25, v2
    1fb0:      	bit.16b	v14, v30, v10
    1fb4:      	fmov	x8, d19
    1fb8:      	cmp	x8, #0x8
    1fbc:      	b.ge	0x23c8 <ltmp0+0x23c8>
    1fc0:      	fmov	w9, s18
    1fc4:      	shl.2d	v22, v19, #0x5
    1fc8:      	ldr	q6, [sp, #0x270]
    1fcc:      	orr.16b	v6, v22, v6
    1fd0:      	ldr	q7, [sp, #0x2c0]
    1fd4:      	add.2d	v6, v7, v6
    1fd8:      	movi.2d	v8, #0000000000000000
    1fdc:      	movi.2d	v9, #0000000000000000
    1fe0:      	tbnz	w9, #0x0, 0x2198 <ltmp0+0x2198>
    1fe4:      	and	w9, w9, #0xff
    1fe8:      	tbnz	w9, #0x1, 0x21a8 <ltmp0+0x21a8>
    1fec:      	shl.2d	v6, v17, #0x5
    1ff0:      	ldr	q7, [sp, #0x290]
    1ff4:      	orr.16b	v7, v6, v7
    1ff8:      	add.2d	v7, v31, v7
    1ffc:      	tbnz	w9, #0x2, 0x21c4 <ltmp0+0x21c4>
    2000:      	tbnz	w9, #0x3, 0x21d0 <ltmp0+0x21d0>
    2004:      	shl.2d	v7, v5, #0x5
    2008:      	ldr	q24, [sp, #0x280]
    200c:      	orr.16b	v24, v7, v24
    2010:      	ldr	q25, [sp, #0x2d0]
    2014:      	add.2d	v24, v25, v24
    2018:      	tbnz	w9, #0x4, 0x21f0 <ltmp0+0x21f0>
    201c:      	tbnz	w9, #0x5, 0x21fc <ltmp0+0x21fc>
    2020:      	shl.2d	v26, v16, #0x5
    2024:      	ldp	q24, q25, [sp, #0x2a0]
    2028:      	orr.16b	v24, v26, v24
    202c:      	add.2d	v24, v25, v24
    2030:      	tbnz	w9, #0x6, 0x2218 <ltmp0+0x2218>
    2034:      	tbz	w9, #0x7, 0x2040 <ltmp0+0x2040>
    2038:      	mov.d	x8, v24[1]
    203c:      	ld1.s	{ v9 }[3], [x8]
    2040:      	fmov	w9, s18
    2044:      	ldr	q24, [sp, #0x210]
    2048:      	add.2d	v24, v24, v22
    204c:      	ldr	q25, [sp, #0x2c0]
    2050:      	add.2d	v24, v25, v24
    2054:      	movi.2d	v27, #0000000000000000
    2058:      	movi.2d	v28, #0000000000000000
    205c:      	tbnz	w9, #0x0, 0x2228 <ltmp0+0x2228>
    2060:      	and	w9, w9, #0xff
    2064:      	tbnz	w9, #0x1, 0x2238 <ltmp0+0x2238>
    2068:      	ldr	q24, [sp, #0x220]
    206c:      	add.2d	v24, v24, v6
    2070:      	add.2d	v24, v31, v24
    2074:      	tbnz	w9, #0x2, 0x2250 <ltmp0+0x2250>
    2078:      	tbnz	w9, #0x3, 0x225c <ltmp0+0x225c>
    207c:      	ldr	q24, [sp, #0x230]
    2080:      	add.2d	v24, v24, v7
    2084:      	ldr	q25, [sp, #0x2d0]
    2088:      	add.2d	v24, v25, v24
    208c:      	tbnz	w9, #0x4, 0x2278 <ltmp0+0x2278>
    2090:      	tbnz	w9, #0x5, 0x2284 <ltmp0+0x2284>
    2094:      	ldr	q24, [sp, #0x200]
    2098:      	add.2d	v24, v24, v26
    209c:      	ldr	q25, [sp, #0x2b0]
    20a0:      	add.2d	v24, v25, v24
    20a4:      	tbnz	w9, #0x6, 0x22a0 <ltmp0+0x22a0>
    20a8:      	tbz	w9, #0x7, 0x20b4 <ltmp0+0x20b4>
    20ac:      	mov.d	x8, v24[1]
    20b0:      	ld1.s	{ v28 }[3], [x8]
    20b4:      	fmov	w9, s18
    20b8:      	ldr	q24, [sp, #0x1d0]
    20bc:      	add.2d	v24, v24, v22
    20c0:      	ldr	q25, [sp, #0x2c0]
    20c4:      	add.2d	v25, v25, v24
    20c8:      	movi.2d	v29, #0000000000000000
    20cc:      	movi.2d	v24, #0000000000000000
    20d0:      	tbnz	w9, #0x0, 0x22b0 <ltmp0+0x22b0>
    20d4:      	and	w9, w9, #0xff
    20d8:      	tbnz	w9, #0x1, 0x22c0 <ltmp0+0x22c0>
    20dc:      	ldr	q25, [sp, #0x1e0]
    20e0:      	add.2d	v25, v25, v6
    20e4:      	add.2d	v25, v31, v25
    20e8:      	tbnz	w9, #0x2, 0x22d8 <ltmp0+0x22d8>
    20ec:      	tbnz	w9, #0x3, 0x22e4 <ltmp0+0x22e4>
    20f0:      	ldr	q25, [sp, #0x1f0]
    20f4:      	add.2d	v25, v25, v7
    20f8:      	ldr	q30, [sp, #0x2d0]
    20fc:      	add.2d	v25, v30, v25
    2100:      	tbnz	w9, #0x4, 0x2300 <ltmp0+0x2300>
    2104:      	tbnz	w9, #0x5, 0x230c <ltmp0+0x230c>
    2108:      	ldr	q25, [sp, #0x1c0]
    210c:      	add.2d	v25, v25, v26
    2110:      	ldr	q30, [sp, #0x2b0]
    2114:      	add.2d	v25, v30, v25
    2118:      	tbnz	w9, #0x6, 0x2328 <ltmp0+0x2328>
    211c:      	tbz	w9, #0x7, 0x2128 <ltmp0+0x2128>
    2120:      	mov.d	x8, v25[1]
    2124:      	ld1.s	{ v24 }[3], [x8]
    2128:      	fmov	w9, s18
    212c:      	ldr	q25, [sp, #0x190]
    2130:      	add.2d	v22, v25, v22
    2134:      	ldr	q25, [sp, #0x2c0]
    2138:      	add.2d	v22, v25, v22
    213c:      	movi.2d	v25, #0000000000000000
    2140:      	movi.2d	v30, #0000000000000000
    2144:      	tbnz	w9, #0x0, 0x2338 <ltmp0+0x2338>
    2148:      	and	w9, w9, #0xff
    214c:      	tbnz	w9, #0x1, 0x2348 <ltmp0+0x2348>
    2150:      	ldr	q22, [sp, #0x1a0]
    2154:      	add.2d	v6, v22, v6
    2158:      	add.2d	v6, v31, v6
    215c:      	tbnz	w9, #0x2, 0x2360 <ltmp0+0x2360>
    2160:      	tbnz	w9, #0x3, 0x236c <ltmp0+0x236c>
    2164:      	ldr	q6, [sp, #0x1b0]
    2168:      	add.2d	v6, v6, v7
    216c:      	ldr	q7, [sp, #0x2d0]
    2170:      	add.2d	v6, v7, v6
    2174:      	tbnz	w9, #0x4, 0x2388 <ltmp0+0x2388>
    2178:      	tbnz	w9, #0x5, 0x2394 <ltmp0+0x2394>
    217c:      	ldr	q6, [sp, #0x180]
    2180:      	add.2d	v6, v6, v26
    2184:      	ldr	q7, [sp, #0x2b0]
    2188:      	add.2d	v6, v7, v6
    218c:      	tbnz	w9, #0x6, 0x23b0 <ltmp0+0x23b0>
    2190:      	tbz	w9, #0x7, 0x1f20 <ltmp0+0x1f20>
    2194:      	b	0x23bc <ltmp0+0x23bc>
    2198:      	fmov	x8, d6
    219c:      	ldr	s8, [x8]
    21a0:      	and	w9, w9, #0xff
    21a4:      	tbz	w9, #0x1, 0x1fec <ltmp0+0x1fec>
    21a8:      	mov.d	x8, v6[1]
    21ac:      	ld1.s	{ v8 }[1], [x8]
    21b0:      	shl.2d	v6, v17, #0x5
    21b4:      	ldr	q7, [sp, #0x290]
    21b8:      	orr.16b	v7, v6, v7
    21bc:      	add.2d	v7, v31, v7
    21c0:      	tbz	w9, #0x2, 0x2000 <ltmp0+0x2000>
    21c4:      	fmov	x8, d7
    21c8:      	ld1.s	{ v8 }[2], [x8]
    21cc:      	tbz	w9, #0x3, 0x2004 <ltmp0+0x2004>
    21d0:      	mov.d	x8, v7[1]
    21d4:      	ld1.s	{ v8 }[3], [x8]
    21d8:      	shl.2d	v7, v5, #0x5
    21dc:      	ldr	q24, [sp, #0x280]
    21e0:      	orr.16b	v24, v7, v24
    21e4:      	ldr	q25, [sp, #0x2d0]
    21e8:      	add.2d	v24, v25, v24
    21ec:      	tbz	w9, #0x4, 0x201c <ltmp0+0x201c>
    21f0:      	fmov	x8, d24
    21f4:      	ld1.s	{ v9 }[0], [x8]
    21f8:      	tbz	w9, #0x5, 0x2020 <ltmp0+0x2020>
    21fc:      	mov.d	x8, v24[1]
    2200:      	ld1.s	{ v9 }[1], [x8]
    2204:      	shl.2d	v26, v16, #0x5
    2208:      	ldp	q24, q25, [sp, #0x2a0]
    220c:      	orr.16b	v24, v26, v24
    2210:      	add.2d	v24, v25, v24
    2214:      	tbz	w9, #0x6, 0x2034 <ltmp0+0x2034>
    2218:      	fmov	x8, d24
    221c:      	ld1.s	{ v9 }[2], [x8]
    2220:      	tbnz	w9, #0x7, 0x2038 <ltmp0+0x2038>
    2224:      	b	0x2040 <ltmp0+0x2040>
    2228:      	fmov	x8, d24
    222c:      	ldr	s27, [x8]
    2230:      	and	w9, w9, #0xff
    2234:      	tbz	w9, #0x1, 0x2068 <ltmp0+0x2068>
    2238:      	mov.d	x8, v24[1]
    223c:      	ld1.s	{ v27 }[1], [x8]
    2240:      	ldr	q24, [sp, #0x220]
    2244:      	add.2d	v24, v24, v6
    2248:      	add.2d	v24, v31, v24
    224c:      	tbz	w9, #0x2, 0x2078 <ltmp0+0x2078>
    2250:      	fmov	x8, d24
    2254:      	ld1.s	{ v27 }[2], [x8]
    2258:      	tbz	w9, #0x3, 0x207c <ltmp0+0x207c>
    225c:      	mov.d	x8, v24[1]
    2260:      	ld1.s	{ v27 }[3], [x8]
    2264:      	ldr	q24, [sp, #0x230]
    2268:      	add.2d	v24, v24, v7
    226c:      	ldr	q25, [sp, #0x2d0]
    2270:      	add.2d	v24, v25, v24
    2274:      	tbz	w9, #0x4, 0x2090 <ltmp0+0x2090>
    2278:      	fmov	x8, d24
    227c:      	ld1.s	{ v28 }[0], [x8]
    2280:      	tbz	w9, #0x5, 0x2094 <ltmp0+0x2094>
    2284:      	mov.d	x8, v24[1]
    2288:      	ld1.s	{ v28 }[1], [x8]
    228c:      	ldr	q24, [sp, #0x200]
    2290:      	add.2d	v24, v24, v26
    2294:      	ldr	q25, [sp, #0x2b0]
    2298:      	add.2d	v24, v25, v24
    229c:      	tbz	w9, #0x6, 0x20a8 <ltmp0+0x20a8>
    22a0:      	fmov	x8, d24
    22a4:      	ld1.s	{ v28 }[2], [x8]
    22a8:      	tbnz	w9, #0x7, 0x20ac <ltmp0+0x20ac>
    22ac:      	b	0x20b4 <ltmp0+0x20b4>
    22b0:      	fmov	x8, d25
    22b4:      	ldr	s29, [x8]
    22b8:      	and	w9, w9, #0xff
    22bc:      	tbz	w9, #0x1, 0x20dc <ltmp0+0x20dc>
    22c0:      	mov.d	x8, v25[1]
    22c4:      	ld1.s	{ v29 }[1], [x8]
    22c8:      	ldr	q25, [sp, #0x1e0]
    22cc:      	add.2d	v25, v25, v6
    22d0:      	add.2d	v25, v31, v25
    22d4:      	tbz	w9, #0x2, 0x20ec <ltmp0+0x20ec>
    22d8:      	fmov	x8, d25
    22dc:      	ld1.s	{ v29 }[2], [x8]
    22e0:      	tbz	w9, #0x3, 0x20f0 <ltmp0+0x20f0>
    22e4:      	mov.d	x8, v25[1]
    22e8:      	ld1.s	{ v29 }[3], [x8]
    22ec:      	ldr	q25, [sp, #0x1f0]
    22f0:      	add.2d	v25, v25, v7
    22f4:      	ldr	q30, [sp, #0x2d0]
    22f8:      	add.2d	v25, v30, v25
    22fc:      	tbz	w9, #0x4, 0x2104 <ltmp0+0x2104>
    2300:      	fmov	x8, d25
    2304:      	ld1.s	{ v24 }[0], [x8]
    2308:      	tbz	w9, #0x5, 0x2108 <ltmp0+0x2108>
    230c:      	mov.d	x8, v25[1]
    2310:      	ld1.s	{ v24 }[1], [x8]
    2314:      	ldr	q25, [sp, #0x1c0]
    2318:      	add.2d	v25, v25, v26
    231c:      	ldr	q30, [sp, #0x2b0]
    2320:      	add.2d	v25, v30, v25
    2324:      	tbz	w9, #0x6, 0x211c <ltmp0+0x211c>
    2328:      	fmov	x8, d25
    232c:      	ld1.s	{ v24 }[2], [x8]
    2330:      	tbnz	w9, #0x7, 0x2120 <ltmp0+0x2120>
    2334:      	b	0x2128 <ltmp0+0x2128>
    2338:      	fmov	x8, d22
    233c:      	ldr	s25, [x8]
    2340:      	and	w9, w9, #0xff
    2344:      	tbz	w9, #0x1, 0x2150 <ltmp0+0x2150>
    2348:      	mov.d	x8, v22[1]
    234c:      	ld1.s	{ v25 }[1], [x8]
    2350:      	ldr	q22, [sp, #0x1a0]
    2354:      	add.2d	v6, v22, v6
    2358:      	add.2d	v6, v31, v6
    235c:      	tbz	w9, #0x2, 0x2160 <ltmp0+0x2160>
    2360:      	fmov	x8, d6
    2364:      	ld1.s	{ v25 }[2], [x8]
    2368:      	tbz	w9, #0x3, 0x2164 <ltmp0+0x2164>
    236c:      	mov.d	x8, v6[1]
    2370:      	ld1.s	{ v25 }[3], [x8]
    2374:      	ldr	q6, [sp, #0x1b0]
    2378:      	add.2d	v6, v6, v7
    237c:      	ldr	q7, [sp, #0x2d0]
    2380:      	add.2d	v6, v7, v6
    2384:      	tbz	w9, #0x4, 0x2178 <ltmp0+0x2178>
    2388:      	fmov	x8, d6
    238c:      	ld1.s	{ v30 }[0], [x8]
    2390:      	tbz	w9, #0x5, 0x217c <ltmp0+0x217c>
    2394:      	mov.d	x8, v6[1]
    2398:      	ld1.s	{ v30 }[1], [x8]
    239c:      	ldr	q6, [sp, #0x180]
    23a0:      	add.2d	v6, v6, v26
    23a4:      	ldr	q7, [sp, #0x2b0]
    23a8:      	add.2d	v6, v7, v6
    23ac:      	tbz	w9, #0x6, 0x2190 <ltmp0+0x2190>
    23b0:      	fmov	x8, d6
    23b4:      	ld1.s	{ v30 }[2], [x8]
    23b8:      	tbz	w9, #0x7, 0x1f20 <ltmp0+0x1f20>
    23bc:      	mov.d	x8, v6[1]
    23c0:      	ld1.s	{ v30 }[3], [x8]
    23c4:      	b	0x1f20 <ltmp0+0x1f20>
    23c8:      	str	x1, [sp, #0x230]
    23cc:      	mov	x9, #0x0                ; =0
    23d0:      	ldp	q6, q5, [sp, #0x240]
    23d4:      	and.16b	v16, v6, v0
    23d8:      	and.16b	v17, v5, v0
    23dc:      	sshll.2d	v5, v10, #0x0
    23e0:      	and.16b	v6, v5, v0
    23e4:      	sshll.2d	v5, v2, #0x0
    23e8:      	and.16b	v7, v5, v0
    23ec:      	dup.2d	v5, x26
    23f0:      	ushll2.2d	v19, v10, #0x0
    23f4:      	and.16b	v8, v19, v5
    23f8:      	ushll2.2d	v19, v2, #0x0
    23fc:      	and.16b	v9, v19, v5
    2400:      	ushll.2d	v19, v10, #0x0
    2404:      	and.16b	v10, v19, v5
    2408:      	ushll.2d	v2, v2, #0x0
    240c:      	and.16b	v2, v2, v5
    2410:      	movi.2d	v5, #0000000000000000
    2414:      	movi.2d	v19, #0000000000000000
    2418:      	movi.2d	v24, #0000000000000000
    241c:      	movi.2d	v27, #0000000000000000
    2420:      	b	0x2440 <ltmp0+0x2440>
    2424:      	add.2d	v19, v19, v9
    2428:      	add.2d	v24, v24, v10
    242c:      	add.2d	v27, v27, v8
    2430:      	add.2d	v5, v5, v2
    2434:      	fmov	x9, d5
    2438:      	cmp	x9, #0x8
    243c:      	b.ge	0x25e8 <ltmp0+0x25e8>
    2440:      	fmov	w10, s18
    2444:      	add	x9, x3, x9, lsl #5
    2448:      	movi.2d	v29, #0000000000000000
    244c:      	movi.2d	v28, #0000000000000000
    2450:      	tbnz	w10, #0x0, 0x24e0 <ltmp0+0x24e0>
    2454:      	and	w10, w10, #0xff
    2458:      	tbnz	w10, #0x1, 0x24ec <ltmp0+0x24ec>
    245c:      	tbnz	w10, #0x2, 0x24f8 <ltmp0+0x24f8>
    2460:      	tbnz	w10, #0x3, 0x2504 <ltmp0+0x2504>
    2464:      	tbnz	w10, #0x4, 0x2510 <ltmp0+0x2510>
    2468:      	tbnz	w10, #0x5, 0x251c <ltmp0+0x251c>
    246c:      	tbnz	w10, #0x6, 0x2528 <ltmp0+0x2528>
    2470:      	tbnz	w10, #0x7, 0x2534 <ltmp0+0x2534>
    2474:      	fmov	w9, s18
    2478:      	shl.2d	v25, v5, #0x5
    247c:      	ldr	q30, [sp, #0x270]
    2480:      	orr.16b	v25, v25, v30
    2484:      	add.2d	v25, v7, v25
    2488:      	tbnz	w9, #0x0, 0x2554 <ltmp0+0x2554>
    248c:      	and	w9, w9, #0xff
    2490:      	tbnz	w9, #0x1, 0x2564 <ltmp0+0x2564>
    2494:      	shl.2d	v25, v19, #0x5
    2498:      	ldr	q30, [sp, #0x290]
    249c:      	orr.16b	v25, v25, v30
    24a0:      	add.2d	v25, v17, v25
    24a4:      	tbnz	w9, #0x2, 0x2580 <ltmp0+0x2580>
    24a8:      	tbnz	w9, #0x3, 0x258c <ltmp0+0x258c>
    24ac:      	shl.2d	v25, v24, #0x5
    24b0:      	ldr	q29, [sp, #0x280]
    24b4:      	orr.16b	v25, v25, v29
    24b8:      	add.2d	v25, v6, v25
    24bc:      	tbnz	w9, #0x4, 0x25a8 <ltmp0+0x25a8>
    24c0:      	tbnz	w9, #0x5, 0x25b4 <ltmp0+0x25b4>
    24c4:      	shl.2d	v25, v27, #0x5
    24c8:      	ldr	q29, [sp, #0x2a0]
    24cc:      	orr.16b	v25, v25, v29
    24d0:      	add.2d	v25, v16, v25
    24d4:      	tbnz	w9, #0x6, 0x25d0 <ltmp0+0x25d0>
    24d8:      	tbz	w9, #0x7, 0x2424 <ltmp0+0x2424>
    24dc:      	b	0x25dc <ltmp0+0x25dc>
    24e0:      	ldr	s29, [x9]
    24e4:      	and	w10, w10, #0xff
    24e8:      	tbz	w10, #0x1, 0x245c <ltmp0+0x245c>
    24ec:      	add	x8, x9, #0x4
    24f0:      	ld1.s	{ v29 }[1], [x8]
    24f4:      	tbz	w10, #0x2, 0x2460 <ltmp0+0x2460>
    24f8:      	add	x8, x9, #0x8
    24fc:      	ld1.s	{ v29 }[2], [x8]
    2500:      	tbz	w10, #0x3, 0x2464 <ltmp0+0x2464>
    2504:      	add	x8, x9, #0xc
    2508:      	ld1.s	{ v29 }[3], [x8]
    250c:      	tbz	w10, #0x4, 0x2468 <ltmp0+0x2468>
    2510:      	add	x8, x9, #0x10
    2514:      	ld1.s	{ v28 }[0], [x8]
    2518:      	tbz	w10, #0x5, 0x246c <ltmp0+0x246c>
    251c:      	add	x8, x9, #0x14
    2520:      	ld1.s	{ v28 }[1], [x8]
    2524:      	tbz	w10, #0x6, 0x2470 <ltmp0+0x2470>
    2528:      	add	x8, x9, #0x18
    252c:      	ld1.s	{ v28 }[2], [x8]
    2530:      	tbz	w10, #0x7, 0x2474 <ltmp0+0x2474>
    2534:      	add	x8, x9, #0x1c
    2538:      	ld1.s	{ v28 }[3], [x8]
    253c:      	fmov	w9, s18
    2540:      	shl.2d	v25, v5, #0x5
    2544:      	ldr	q30, [sp, #0x270]
    2548:      	orr.16b	v25, v25, v30
    254c:      	add.2d	v25, v7, v25
    2550:      	tbz	w9, #0x0, 0x248c <ltmp0+0x248c>
    2554:      	fmov	x8, d25
    2558:      	str	s29, [x8]
    255c:      	and	w9, w9, #0xff
    2560:      	tbz	w9, #0x1, 0x2494 <ltmp0+0x2494>
    2564:      	mov.d	x8, v25[1]
    2568:      	st1.s	{ v29 }[1], [x8]
    256c:      	shl.2d	v25, v19, #0x5
    2570:      	ldr	q30, [sp, #0x290]
    2574:      	orr.16b	v25, v25, v30
    2578:      	add.2d	v25, v17, v25
    257c:      	tbz	w9, #0x2, 0x24a8 <ltmp0+0x24a8>
    2580:      	fmov	x8, d25
    2584:      	st1.s	{ v29 }[2], [x8]
    2588:      	tbz	w9, #0x3, 0x24ac <ltmp0+0x24ac>
    258c:      	mov.d	x8, v25[1]
    2590:      	st1.s	{ v29 }[3], [x8]
    2594:      	shl.2d	v25, v24, #0x5
    2598:      	ldr	q29, [sp, #0x280]
    259c:      	orr.16b	v25, v25, v29
    25a0:      	add.2d	v25, v6, v25
    25a4:      	tbz	w9, #0x4, 0x24c0 <ltmp0+0x24c0>
    25a8:      	fmov	x8, d25
    25ac:      	str	s28, [x8]
    25b0:      	tbz	w9, #0x5, 0x24c4 <ltmp0+0x24c4>
    25b4:      	mov.d	x8, v25[1]
    25b8:      	st1.s	{ v28 }[1], [x8]
    25bc:      	shl.2d	v25, v27, #0x5
    25c0:      	ldr	q29, [sp, #0x2a0]
    25c4:      	orr.16b	v25, v25, v29
    25c8:      	add.2d	v25, v16, v25
    25cc:      	tbz	w9, #0x6, 0x24d8 <ltmp0+0x24d8>
    25d0:      	fmov	x8, d25
    25d4:      	st1.s	{ v28 }[2], [x8]
    25d8:      	tbz	w9, #0x7, 0x2424 <ltmp0+0x2424>
    25dc:      	mov.d	x8, v25[1]
    25e0:      	st1.s	{ v28 }[3], [x8]
    25e4:      	b	0x2424 <ltmp0+0x2424>
    25e8:      	ldr	q5, [sp, #0x90]
    25ec:      	xtn.8b	v5, v5
    25f0:      	ldp	q24, q19, [sp, #0x40]
    25f4:      	fmul.4s	v19, v19, v19
    25f8:      	fmul.4s	v24, v24, v24
    25fc:      	fadd.4s	v21, v24, v21
    2600:      	fadd.4s	v19, v19, v12
    2604:      	ldr	q27, [sp, #0x130]
    2608:      	zip1.8b	v24, v27, v0
    260c:      	ushll.4s	v24, v24, #0x0
    2610:      	shl.4s	v24, v24, #0x1f
    2614:      	cmlt.4s	v24, v24, #0
    2618:      	and.16b	v19, v24, v19
    261c:      	zip2.8b	v24, v27, v0
    2620:      	ushll.4s	v24, v24, #0x0
    2624:      	shl.4s	v24, v24, #0x1f
    2628:      	cmlt.4s	v24, v24, #0
    262c:      	and.16b	v21, v24, v21
    2630:      	zip2.8b	v24, v5, v0
    2634:      	ushll.4s	v24, v24, #0x0
    2638:      	shl.4s	v24, v24, #0x1f
    263c:      	cmlt.4s	v24, v24, #0
    2640:      	movi.2d	v25, #0000000000000000
    2644:      	mov.b	v25[2], v5[1]
    2648:      	mov.b	v25[4], v5[2]
    264c:      	mov.b	v25[6], v5[3]
    2650:      	bit.16b	v21, v26, v24
    2654:      	ushll.4s	v24, v25, #0x0
    2658:      	shl.4s	v24, v24, #0x1f
    265c:      	cmlt.4s	v24, v24, #0
    2660:      	bit.16b	v19, v22, v24
    2664:      	fadd.4s	v19, v13, v19
    2668:      	mov.16b	v13, v27
    266c:      	fadd.4s	v21, v11, v21
    2670:      	fadd.4s	v21, v23, v21
    2674:      	fadd.4s	v19, v15, v19
    2678:      	fadd.4s	v20, v20, v19
    267c:      	fadd.4s	v21, v14, v21
    2680:      	ldr	q19, [sp, #0x60]
    2684:      	ldp	q23, q22, [sp, #0x20]
    2688:      	uzp1.4s	v19, v19, v23
    268c:      	ldr	q23, [sp, #0x10]
    2690:      	uzp1.4s	v22, v23, v22
    2694:      	movi.4s	v24, #0x1
    2698:      	eor.16b	v23, v19, v24
    269c:      	mov.s	w8, v23[1]
    26a0:      	mov.s	w12, v23[2]
    26a4:      	eor.16b	v26, v22, v24
    26a8:      	mov.s	w0, v23[3]
    26ac:      	fmov	w9, s23
    26b0:      	add	x10, sp, #0x328
    26b4:      	bfxil	x10, x9, #0, #3
    26b8:      	str	d5, [sp, #0x328]
    26bc:      	ldrb	w10, [x10]
    26c0:      	and	x11, x9, #0x7
    26c4:      	umov.b	w9, v5[0]
    26c8:      	str	q21, [sp, #0x440]
    26cc:      	str	q20, [sp, #0x430]
    26d0:      	add	x14, sp, #0x430
    26d4:      	ldr	s23, [x14, x11, lsl #2]
    26d8:      	ands	w11, w9, #0x1
    26dc:      	tst	w11, w10
    26e0:      	movi	d12, #0000000000000000
    26e4:      	fcsel	s23, s23, s12, ne
    26e8:      	add	x10, sp, #0x328
    26ec:      	bfxil	x10, x8, #0, #3
    26f0:      	ldrb	w14, [x10]
    26f4:      	and	x8, x8, #0x7
    26f8:      	umov.b	w10, v5[1]
    26fc:      	str	q21, [sp, #0x420]
    2700:      	str	q20, [sp, #0x410]
    2704:      	add	x1, sp, #0x410
    2708:      	ldr	s24, [x1, x8, lsl #2]
    270c:      	ands	w8, w10, #0x1
    2710:      	tst	w8, w14
    2714:      	fcsel	s24, s24, s12, ne
    2718:      	add	x8, sp, #0x328
    271c:      	bfxil	x8, x12, #0, #3
    2720:      	ldrb	w8, [x8]
    2724:      	umov.b	w14, v5[2]
    2728:      	and	x12, x12, #0x7
    272c:      	stp	q20, q21, [sp, #0x3f0]
    2730:      	add	x1, sp, #0x3f0
    2734:      	ldr	s25, [x1, x12, lsl #2]
    2738:      	ands	w12, w14, #0x1
    273c:      	tst	w12, w8
    2740:      	fcsel	s25, s25, s12, ne
    2744:      	add	x8, sp, #0x328
    2748:      	bfxil	x8, x0, #0, #3
    274c:      	ldrb	w8, [x8]
    2750:      	and	x12, x0, #0x7
    2754:      	umov.b	w0, v5[3]
    2758:      	stp	q20, q21, [sp, #0x3d0]
    275c:      	add	x1, sp, #0x3d0
    2760:      	ldr	s27, [x1, x12, lsl #2]
    2764:      	ands	w12, w0, #0x1
    2768:      	tst	w12, w8
    276c:      	mov.s	w8, v26[1]
    2770:      	mov.s	w12, v26[2]
    2774:      	fcsel	s27, s27, s12, ne
    2778:      	mov.s	w1, v26[3]
    277c:      	fmov	w2, s26
    2780:      	and	x27, x2, #0x7
    2784:      	add	x28, sp, #0x328
    2788:      	bfxil	x28, x2, #0, #3
    278c:      	ldrb	w28, [x28]
    2790:      	umov.b	w2, v5[4]
    2794:      	and	w28, w2, w28
    2798:      	str	q21, [sp, #0x4c0]
    279c:      	str	q20, [sp, #0x4b0]
    27a0:      	add	x30, sp, #0x4b0
    27a4:      	ldr	s26, [x30, x27, lsl #2]
    27a8:      	tst	w28, #0x1
    27ac:      	fcsel	s26, s26, s12, ne
    27b0:      	add	x27, sp, #0x328
    27b4:      	bfxil	x27, x8, #0, #3
    27b8:      	ldrb	w28, [x27]
    27bc:      	and	x8, x8, #0x7
    27c0:      	umov.b	w27, v5[5]
    27c4:      	str	q21, [sp, #0x4a0]
    27c8:      	str	q20, [sp, #0x490]
    27cc:      	add	x30, sp, #0x490
    27d0:      	ldr	s28, [x30, x8, lsl #2]
    27d4:      	ands	w8, w27, #0x1
    27d8:      	tst	w8, w28
    27dc:      	fcsel	s28, s28, s12, ne
    27e0:      	add	x8, sp, #0x328
    27e4:      	bfxil	x8, x12, #0, #3
    27e8:      	ldrb	w8, [x8]
    27ec:      	and	x12, x12, #0x7
    27f0:      	umov.b	w30, v5[6]
    27f4:      	str	q21, [sp, #0x480]
    27f8:      	str	q20, [sp, #0x470]
    27fc:      	add	x28, sp, #0x470
    2800:      	ldr	s29, [x28, x12, lsl #2]
    2804:      	ands	w12, w30, #0x1
    2808:      	tst	w12, w8
    280c:      	fcsel	s29, s29, s12, ne
    2810:      	add	x8, sp, #0x328
    2814:      	bfxil	x8, x1, #0, #3
    2818:      	ldrb	w8, [x8]
    281c:      	umov.b	w12, v5[7]
    2820:      	and	x1, x1, #0x7
    2824:      	str	q21, [sp, #0x460]
    2828:      	str	q20, [sp, #0x450]
    282c:      	add	x28, sp, #0x450
    2830:      	ldr	s5, [x28, x1, lsl #2]
    2834:      	ands	w1, w12, #0x1
    2838:      	tst	w1, w8
    283c:      	fcsel	s5, s5, s12, ne
    2840:      	mov.s	v26[1], v28[0]
    2844:      	mov.s	v26[2], v29[0]
    2848:      	mov.s	v26[3], v5[0]
    284c:      	mov.s	v23[1], v24[0]
    2850:      	mov.s	v23[2], v25[0]
    2854:      	mov.s	v23[3], v27[0]
    2858:      	fadd.4s	v5, v20, v23
    285c:      	fadd.4s	v20, v21, v26
    2860:      	movi.4s	v23, #0x2
    2864:      	eor.16b	v21, v22, v23
    2868:      	eor.16b	v19, v19, v23
    286c:      	fmov	w8, s19
    2870:      	add	x1, sp, #0x328
    2874:      	bfxil	x1, x8, #0, #3
    2878:      	ldrb	w1, [x1]
    287c:      	and	x8, x8, #0x7
    2880:      	stp	q5, q20, [sp, #0x3b0]
    2884:      	add	x28, sp, #0x3b0
    2888:      	ldr	s19, [x28, x8, lsl #2]
    288c:      	tst	w11, w1
    2890:      	fcsel	s19, s19, s12, ne
    2894:      	fmov	w8, s21
    2898:      	and	x1, x8, #0x7
    289c:      	add	x28, sp, #0x328
    28a0:      	bfxil	x28, x8, #0, #3
    28a4:      	ldrb	w8, [x28]
    28a8:      	and	w8, w2, w8
    28ac:      	stp	q5, q20, [sp, #0x390]
    28b0:      	add	x28, sp, #0x390
    28b4:      	ldr	s21, [x28, x1, lsl #2]
    28b8:      	tst	w8, #0x1
    28bc:      	fcsel	s21, s21, s12, ne
    28c0:      	fadd.4s	v20, v20, v21
    28c4:      	tst	w11, w2
    28c8:      	fcsel	s20, s20, s12, ne
    28cc:      	ands	w8, w9, #0x1
    28d0:      	fadd.4s	v5, v5, v19
    28d4:      	fadd	s5, s5, s20
    28d8:      	fcsel	s19, s5, s12, ne
    28dc:      	tst	w10, #0x1
    28e0:      	fcsel	s20, s19, s12, ne
    28e4:      	tst	w14, #0x1
    28e8:      	fcsel	s21, s19, s12, ne
    28ec:      	tst	w0, #0x1
    28f0:      	fcsel	s22, s19, s12, ne
    28f4:      	tst	w8, w2
    28f8:      	fcsel	s23, s5, s12, ne
    28fc:      	tst	w27, #0x1
    2900:      	fcsel	s24, s19, s12, ne
    2904:      	tst	w30, #0x1
    2908:      	fcsel	s25, s19, s12, ne
    290c:      	tst	w12, #0x1
    2910:      	shl.8b	v5, v13, #0x7
    2914:      	cmlt.8b	v5, v5, #0
    2918:      	ldr	d26, [sp, #0xb8]
    291c:      	and.8b	v5, v5, v26
    2920:      	addv.8b	b5, v5
    2924:      	fmov	w9, s5
    2928:      	fcsel	s26, s19, s12, ne
    292c:      	mov.s	v19[1], v20[0]
    2930:      	mov.s	v19[2], v21[0]
    2934:      	mov.s	v19[3], v22[0]
    2938:      	mov.s	v23[1], v24[0]
    293c:      	mov.s	v23[2], v25[0]
    2940:      	mov.s	v23[3], v26[0]
    2944:      	ldr	w8, [sp, #0xe4]
    2948:      	rbit	w8, w8
    294c:      	clz	w8, w8
    2950:      	stp	q19, q23, [sp, #0x370]
    2954:      	and	x8, x8, #0x7
    2958:      	add	x10, sp, #0x370
    295c:      	ldr	s19, [x10, x8, lsl #2]
    2960:      	mov	b20, v13[0]
    2964:      	mov.b	v20[4], v13[1]
    2968:      	ushll.2d	v20, v20, #0x0
    296c:      	shl.2d	v20, v20, #0x3f
    2970:      	cmlt.2d	v20, v20, #0
    2974:      	mov	b21, v13[2]
    2978:      	mov.b	v21[4], v13[3]
    297c:      	ldr	q22, [sp, #0xc0]
    2980:      	and.16b	v20, v20, v22
    2984:      	ushll.2d	v21, v21, #0x0
    2988:      	shl.2d	v21, v21, #0x3f
    298c:      	cmlt.2d	v21, v21, #0
    2990:      	ldp	q22, q23, [sp, #0x70]
    2994:      	and.16b	v21, v21, v22
    2998:      	mov	b22, v13[4]
    299c:      	mov.b	v22[4], v13[5]
    29a0:      	ushll.2d	v22, v22, #0x0
    29a4:      	shl.2d	v22, v22, #0x3f
    29a8:      	cmlt.2d	v22, v22, #0
    29ac:      	and.16b	v22, v22, v23
    29b0:      	mov	b23, v13[6]
    29b4:      	mov.b	v23[4], v13[7]
    29b8:      	ushll.2d	v23, v23, #0x0
    29bc:      	shl.2d	v23, v23, #0x3f
    29c0:      	cmlt.2d	v23, v23, #0
    29c4:      	ldr	q24, [sp, #0xa0]
    29c8:      	and.16b	v23, v23, v24
    29cc:      	stp	q22, q23, [sp, #0x350]
    29d0:      	stp	q20, q21, [sp, #0x330]
    29d4:      	and	x8, x13, #0x7
    29d8:      	add	x10, sp, #0x330
    29dc:      	ldr	x8, [x10, x8, lsl #3]
    29e0:      	sub	x8, x8, x13
    29e4:      	add	x10, x3, x8, lsl #2
    29e8:      	movi.2d	v20, #0000000000000000
    29ec:      	movi.2d	v21, #0000000000000000
    29f0:      	tbnz	w9, #0x0, 0x2e70 <ltmp0+0x2e70>
    29f4:      	ldr	w14, [sp, #0x16c]
    29f8:      	ldr	x2, [sp, #0x230]
    29fc:      	ldr	x3, [sp, #0xe8]
    2a00:      	tbnz	w9, #0x1, 0x2e84 <ltmp0+0x2e84>
    2a04:      	add	x12, sp, #0x690
    2a08:      	adrp	x1, 0x2000 <ltmp0+0x2000>
    2a0c:      	ldr	x0, [sp, #0x178]
    2a10:      	tbnz	w9, #0x2, 0x2e9c <ltmp0+0x2e9c>
    2a14:      	tbnz	w9, #0x3, 0x2ea8 <ltmp0+0x2ea8>
    2a18:      	tbnz	w9, #0x4, 0x2eb4 <ltmp0+0x2eb4>
    2a1c:      	tbnz	w9, #0x5, 0x2ec0 <ltmp0+0x2ec0>
    2a20:      	tbnz	w9, #0x6, 0x2ecc <ltmp0+0x2ecc>
    2a24:      	tbz	w9, #0x7, 0x2a30 <ltmp0+0x2a30>
    2a28:      	add	x8, x10, #0x1c
    2a2c:      	ld1.s	{ v21 }[3], [x8]
    2a30:      	mov	x10, #0x0               ; =0
    2a34:      	fadd	s19, s19, s12
    2a38:      	mov	w8, #0x42820000         ; =1115815936
    2a3c:      	fmov	s22, w8
    2a40:      	fdiv	s19, s19, s22
    2a44:      	add	x8, sp, #0x570
    2a48:      	add	x8, x8, x3
    2a4c:      	ldp	q22, q23, [x8]
    2a50:      	zip2.8b	v24, v13, v0
    2a54:      	ushll.4s	v24, v24, #0x0
    2a58:      	shl.4s	v24, v24, #0x1f
    2a5c:      	cmlt.4s	v24, v24, #0
    2a60:      	bif.16b	v21, v23, v24
    2a64:      	zip1.8b	v23, v13, v0
    2a68:      	ushll.4s	v23, v23, #0x0
    2a6c:      	shl.4s	v23, v23, #0x1f
    2a70:      	cmlt.4s	v23, v23, #0
    2a74:      	bif.16b	v20, v22, v23
    2a78:      	stp	q20, q21, [x8]
    2a7c:      	mov	w8, #0xc5ac             ; =50604
    2a80:      	movk	w8, #0x3727, lsl #16
    2a84:      	fmov	s20, w8
    2a88:      	fadd	s19, s19, s20
    2a8c:      	fsqrt	s19, s19
    2a90:      	dup.4s	v19, v19[0]
    2a94:      	ldr	q20, [sp, #0xd0]
    2a98:      	fmov	x8, d20
    2a9c:      	add	x9, x2, x8, lsl #2
    2aa0:      	movi.2d	v20, #0000000000000000
    2aa4:      	movi.2d	v21, #0000000000000000
    2aa8:      	movi.2d	v22, #0000000000000000
    2aac:      	movi.2d	v23, #0000000000000000
    2ab0:      	b	0x2ad0 <ltmp0+0x2ad0>
    2ab4:      	add.2d	v21, v21, v9
    2ab8:      	add.2d	v22, v22, v10
    2abc:      	add.2d	v23, v23, v8
    2ac0:      	add.2d	v20, v20, v2
    2ac4:      	fmov	x10, d20
    2ac8:      	cmp	x10, #0x8
    2acc:      	b.ge	0x2d5c <ltmp0+0x2d5c>
    2ad0:      	fmov	w11, s18
    2ad4:      	shl.2d	v24, v20, #0x5
    2ad8:      	ldr	q25, [sp, #0x270]
    2adc:      	orr.16b	v25, v24, v25
    2ae0:      	ldr	q24, [sp, #0x2c0]
    2ae4:      	add.2d	v27, v24, v25
    2ae8:      	movi.2d	v24, #0000000000000000
    2aec:      	movi.2d	v26, #0000000000000000
    2af0:      	tbnz	w11, #0x0, 0x2bcc <ltmp0+0x2bcc>
    2af4:      	and	w11, w11, #0xff
    2af8:      	tbnz	w11, #0x1, 0x2bdc <ltmp0+0x2bdc>
    2afc:      	shl.2d	v27, v21, #0x5
    2b00:      	ldr	q28, [sp, #0x290]
    2b04:      	orr.16b	v28, v27, v28
    2b08:      	add.2d	v27, v31, v28
    2b0c:      	tbnz	w11, #0x2, 0x2bf8 <ltmp0+0x2bf8>
    2b10:      	tbnz	w11, #0x3, 0x2c04 <ltmp0+0x2c04>
    2b14:      	shl.2d	v27, v22, #0x5
    2b18:      	ldr	q29, [sp, #0x280]
    2b1c:      	orr.16b	v29, v27, v29
    2b20:      	ldr	q27, [sp, #0x2d0]
    2b24:      	add.2d	v27, v27, v29
    2b28:      	tbnz	w11, #0x4, 0x2c24 <ltmp0+0x2c24>
    2b2c:      	tbnz	w11, #0x5, 0x2c30 <ltmp0+0x2c30>
    2b30:      	shl.2d	v27, v23, #0x5
    2b34:      	ldr	q30, [sp, #0x2a0]
    2b38:      	orr.16b	v30, v27, v30
    2b3c:      	ldr	q27, [sp, #0x2b0]
    2b40:      	add.2d	v27, v27, v30
    2b44:      	tbnz	w11, #0x6, 0x2c50 <ltmp0+0x2c50>
    2b48:      	tbnz	w11, #0x7, 0x2c5c <ltmp0+0x2c5c>
    2b4c:      	fmov	w11, s18
    2b50:      	add.2d	v11, v7, v25
    2b54:      	movi.2d	v25, #0000000000000000
    2b58:      	movi.2d	v27, #0000000000000000
    2b5c:      	tbnz	w11, #0x0, 0x2c78 <ltmp0+0x2c78>
    2b60:      	and	w11, w11, #0xff
    2b64:      	tbnz	w11, #0x1, 0x2c88 <ltmp0+0x2c88>
    2b68:      	add.2d	v28, v17, v28
    2b6c:      	tbnz	w11, #0x2, 0x2c98 <ltmp0+0x2c98>
    2b70:      	tbnz	w11, #0x3, 0x2ca4 <ltmp0+0x2ca4>
    2b74:      	add.2d	v28, v6, v29
    2b78:      	tbnz	w11, #0x4, 0x2cb4 <ltmp0+0x2cb4>
    2b7c:      	tbnz	w11, #0x5, 0x2cc0 <ltmp0+0x2cc0>
    2b80:      	add.2d	v28, v16, v30
    2b84:      	tbnz	w11, #0x6, 0x2cd0 <ltmp0+0x2cd0>
    2b88:      	tbnz	w11, #0x7, 0x2cdc <ltmp0+0x2cdc>
    2b8c:      	fdiv.4s	v24, v24, v19
    2b90:      	fmov	w11, s18
    2b94:      	fmul.4s	v24, v24, v25
    2b98:      	add	x10, x9, x10, lsl #5
    2b9c:      	tbnz	w11, #0x0, 0x2cf8 <ltmp0+0x2cf8>
    2ba0:      	and	w11, w11, #0xff
    2ba4:      	tbnz	w11, #0x1, 0x2d04 <ltmp0+0x2d04>
    2ba8:      	tbnz	w11, #0x2, 0x2d10 <ltmp0+0x2d10>
    2bac:      	tbnz	w11, #0x3, 0x2d1c <ltmp0+0x2d1c>
    2bb0:      	fdiv.4s	v24, v26, v19
    2bb4:      	fmul.4s	v24, v24, v27
    2bb8:      	tbnz	w11, #0x4, 0x2d30 <ltmp0+0x2d30>
    2bbc:      	tbnz	w11, #0x5, 0x2d38 <ltmp0+0x2d38>
    2bc0:      	tbnz	w11, #0x6, 0x2d44 <ltmp0+0x2d44>
    2bc4:      	tbz	w11, #0x7, 0x2ab4 <ltmp0+0x2ab4>
    2bc8:      	b	0x2d50 <ltmp0+0x2d50>
    2bcc:      	fmov	x8, d27
    2bd0:      	ldr	s24, [x8]
    2bd4:      	and	w11, w11, #0xff
    2bd8:      	tbz	w11, #0x1, 0x2afc <ltmp0+0x2afc>
    2bdc:      	mov.d	x8, v27[1]
    2be0:      	ld1.s	{ v24 }[1], [x8]
    2be4:      	shl.2d	v27, v21, #0x5
    2be8:      	ldr	q28, [sp, #0x290]
    2bec:      	orr.16b	v28, v27, v28
    2bf0:      	add.2d	v27, v31, v28
    2bf4:      	tbz	w11, #0x2, 0x2b10 <ltmp0+0x2b10>
    2bf8:      	fmov	x8, d27
    2bfc:      	ld1.s	{ v24 }[2], [x8]
    2c00:      	tbz	w11, #0x3, 0x2b14 <ltmp0+0x2b14>
    2c04:      	mov.d	x8, v27[1]
    2c08:      	ld1.s	{ v24 }[3], [x8]
    2c0c:      	shl.2d	v27, v22, #0x5
    2c10:      	ldr	q29, [sp, #0x280]
    2c14:      	orr.16b	v29, v27, v29
    2c18:      	ldr	q27, [sp, #0x2d0]
    2c1c:      	add.2d	v27, v27, v29
    2c20:      	tbz	w11, #0x4, 0x2b2c <ltmp0+0x2b2c>
    2c24:      	fmov	x8, d27
    2c28:      	ld1.s	{ v26 }[0], [x8]
    2c2c:      	tbz	w11, #0x5, 0x2b30 <ltmp0+0x2b30>
    2c30:      	mov.d	x8, v27[1]
    2c34:      	ld1.s	{ v26 }[1], [x8]
    2c38:      	shl.2d	v27, v23, #0x5
    2c3c:      	ldr	q30, [sp, #0x2a0]
    2c40:      	orr.16b	v30, v27, v30
    2c44:      	ldr	q27, [sp, #0x2b0]
    2c48:      	add.2d	v27, v27, v30
    2c4c:      	tbz	w11, #0x6, 0x2b48 <ltmp0+0x2b48>
    2c50:      	fmov	x8, d27
    2c54:      	ld1.s	{ v26 }[2], [x8]
    2c58:      	tbz	w11, #0x7, 0x2b4c <ltmp0+0x2b4c>
    2c5c:      	mov.d	x8, v27[1]
    2c60:      	ld1.s	{ v26 }[3], [x8]
    2c64:      	fmov	w11, s18
    2c68:      	add.2d	v11, v7, v25
    2c6c:      	movi.2d	v25, #0000000000000000
    2c70:      	movi.2d	v27, #0000000000000000
    2c74:      	tbz	w11, #0x0, 0x2b60 <ltmp0+0x2b60>
    2c78:      	fmov	x8, d11
    2c7c:      	ldr	s25, [x8]
    2c80:      	and	w11, w11, #0xff
    2c84:      	tbz	w11, #0x1, 0x2b68 <ltmp0+0x2b68>
    2c88:      	mov.d	x8, v11[1]
    2c8c:      	ld1.s	{ v25 }[1], [x8]
    2c90:      	add.2d	v28, v17, v28
    2c94:      	tbz	w11, #0x2, 0x2b70 <ltmp0+0x2b70>
    2c98:      	fmov	x8, d28
    2c9c:      	ld1.s	{ v25 }[2], [x8]
    2ca0:      	tbz	w11, #0x3, 0x2b74 <ltmp0+0x2b74>
    2ca4:      	mov.d	x8, v28[1]
    2ca8:      	ld1.s	{ v25 }[3], [x8]
    2cac:      	add.2d	v28, v6, v29
    2cb0:      	tbz	w11, #0x4, 0x2b7c <ltmp0+0x2b7c>
    2cb4:      	fmov	x8, d28
    2cb8:      	ld1.s	{ v27 }[0], [x8]
    2cbc:      	tbz	w11, #0x5, 0x2b80 <ltmp0+0x2b80>
    2cc0:      	mov.d	x8, v28[1]
    2cc4:      	ld1.s	{ v27 }[1], [x8]
    2cc8:      	add.2d	v28, v16, v30
    2ccc:      	tbz	w11, #0x6, 0x2b88 <ltmp0+0x2b88>
    2cd0:      	fmov	x8, d28
    2cd4:      	ld1.s	{ v27 }[2], [x8]
    2cd8:      	tbz	w11, #0x7, 0x2b8c <ltmp0+0x2b8c>
    2cdc:      	mov.d	x8, v28[1]
    2ce0:      	ld1.s	{ v27 }[3], [x8]
    2ce4:      	fdiv.4s	v24, v24, v19
    2ce8:      	fmov	w11, s18
    2cec:      	fmul.4s	v24, v24, v25
    2cf0:      	add	x10, x9, x10, lsl #5
    2cf4:      	tbz	w11, #0x0, 0x2ba0 <ltmp0+0x2ba0>
    2cf8:      	str	s24, [x10]
    2cfc:      	and	w11, w11, #0xff
    2d00:      	tbz	w11, #0x1, 0x2ba8 <ltmp0+0x2ba8>
    2d04:      	add	x8, x10, #0x4
    2d08:      	st1.s	{ v24 }[1], [x8]
    2d0c:      	tbz	w11, #0x2, 0x2bac <ltmp0+0x2bac>
    2d10:      	add	x8, x10, #0x8
    2d14:      	st1.s	{ v24 }[2], [x8]
    2d18:      	tbz	w11, #0x3, 0x2bb0 <ltmp0+0x2bb0>
    2d1c:      	add	x8, x10, #0xc
    2d20:      	st1.s	{ v24 }[3], [x8]
    2d24:      	fdiv.4s	v24, v26, v19
    2d28:      	fmul.4s	v24, v24, v27
    2d2c:      	tbz	w11, #0x4, 0x2bbc <ltmp0+0x2bbc>
    2d30:      	str	s24, [x10, #0x10]
    2d34:      	tbz	w11, #0x5, 0x2bc0 <ltmp0+0x2bc0>
    2d38:      	add	x8, x10, #0x14
    2d3c:      	st1.s	{ v24 }[1], [x8]
    2d40:      	tbz	w11, #0x6, 0x2bc4 <ltmp0+0x2bc4>
    2d44:      	add	x8, x10, #0x18
    2d48:      	st1.s	{ v24 }[2], [x8]
    2d4c:      	tbz	w11, #0x7, 0x2ab4 <ltmp0+0x2ab4>
    2d50:      	add	x8, x10, #0x1c
    2d54:      	st1.s	{ v24 }[3], [x8]
    2d58:      	b	0x2ab4 <ltmp0+0x2ab4>
    2d5c:      	add	x8, x12, x3
    2d60:      	ldp	q6, q2, [x8]
    2d64:      	zip1.8b	v7, v13, v0
    2d68:      	ushll.4s	v7, v7, #0x0
    2d6c:      	shl.4s	v7, v7, #0x1f
    2d70:      	cmlt.4s	v7, v7, #0
    2d74:      	and.16b	v6, v7, v6
    2d78:      	fmov	w9, s5
    2d7c:      	fdiv.4s	v6, v6, v19
    2d80:      	add	x8, sp, #0x570
    2d84:      	add	x8, x8, x3
    2d88:      	ldp	q16, q5, [x8]
    2d8c:      	and.16b	v7, v7, v16
    2d90:      	fmul.4s	v6, v6, v7
    2d94:      	ldr	q7, [sp, #0x120]
    2d98:      	str	q7, [sp, #0x2e0]
    2d9c:      	ldr	q7, [sp, #0x100]
    2da0:      	str	q7, [sp, #0x2f0]
    2da4:      	ldr	q7, [sp, #0xf0]
    2da8:      	str	q7, [sp, #0x300]
    2dac:      	ldr	q7, [sp, #0x110]
    2db0:      	str	q7, [sp, #0x310]
    2db4:      	and	x8, x13, #0x7
    2db8:      	add	x10, sp, #0x2e0
    2dbc:      	ldr	x8, [x10, x8, lsl #3]
    2dc0:      	sub	x8, x8, x13
    2dc4:      	add	x10, x2, x8, lsl #2
    2dc8:      	tbnz	w9, #0x0, 0x2edc <ltmp0+0x2edc>
    2dcc:      	ldr	w12, [sp, #0x174]
    2dd0:      	ldr	w13, [sp, #0x170]
    2dd4:      	tbnz	w9, #0x1, 0x2eec <ltmp0+0x2eec>
    2dd8:      	tbnz	w9, #0x2, 0x2ef8 <ltmp0+0x2ef8>
    2ddc:      	tbz	w9, #0x3, 0x2de8 <ltmp0+0x2de8>
    2de0:      	add	x8, x10, #0xc
    2de4:      	st1.s	{ v6 }[3], [x8]
    2de8:      	zip2.8b	v6, v13, v0
    2dec:      	ushll.4s	v6, v6, #0x0
    2df0:      	shl.4s	v6, v6, #0x1f
    2df4:      	cmlt.4s	v6, v6, #0
    2df8:      	and.16b	v2, v6, v2
    2dfc:      	fdiv.4s	v2, v2, v19
    2e00:      	and.16b	v5, v6, v5
    2e04:      	fmul.4s	v2, v2, v5
    2e08:      	tbnz	w9, #0x4, 0x2f08 <ltmp0+0x2f08>
    2e0c:      	tbnz	w9, #0x5, 0x2f10 <ltmp0+0x2f10>
    2e10:      	tbnz	w9, #0x6, 0x2f1c <ltmp0+0x2f1c>
    2e14:      	tbz	w9, #0x7, 0xc8 <ltmp0+0xc8>
    2e18:      	b	0x2f28 <ltmp0+0x2f28>
    2e1c:      	ldr	s27, [x9]
    2e20:      	tbz	w10, #0x1, 0x1cec <ltmp0+0x1cec>
    2e24:      	add	x8, x9, #0x4
    2e28:      	ld1.s	{ v27 }[1], [x8]
    2e2c:      	tbz	w10, #0x2, 0x1cf0 <ltmp0+0x1cf0>
    2e30:      	add	x8, x9, #0x8
    2e34:      	ld1.s	{ v27 }[2], [x8]
    2e38:      	tbz	w10, #0x3, 0x1cf4 <ltmp0+0x1cf4>
    2e3c:      	add	x8, x9, #0xc
    2e40:      	ld1.s	{ v27 }[3], [x8]
    2e44:      	tbz	w10, #0x4, 0x1cf8 <ltmp0+0x1cf8>
    2e48:      	add	x8, x9, #0x10
    2e4c:      	ld1.s	{ v28 }[0], [x8]
    2e50:      	tbz	w10, #0x5, 0x1cfc <ltmp0+0x1cfc>
    2e54:      	add	x8, x9, #0x14
    2e58:      	ld1.s	{ v28 }[1], [x8]
    2e5c:      	tbz	w10, #0x6, 0x1d00 <ltmp0+0x1d00>
    2e60:      	add	x8, x9, #0x18
    2e64:      	ld1.s	{ v28 }[2], [x8]
    2e68:      	tbnz	w10, #0x7, 0x1d04 <ltmp0+0x1d04>
    2e6c:      	b	0x1d0c <ltmp0+0x1d0c>
    2e70:      	ldr	s20, [x10]
    2e74:      	ldr	w14, [sp, #0x16c]
    2e78:      	ldr	x2, [sp, #0x230]
    2e7c:      	ldr	x3, [sp, #0xe8]
    2e80:      	tbz	w9, #0x1, 0x2a04 <ltmp0+0x2a04>
    2e84:      	add	x8, x10, #0x4
    2e88:      	ld1.s	{ v20 }[1], [x8]
    2e8c:      	add	x12, sp, #0x690
    2e90:      	adrp	x1, 0x2000 <ltmp0+0x2000>
    2e94:      	ldr	x0, [sp, #0x178]
    2e98:      	tbz	w9, #0x2, 0x2a14 <ltmp0+0x2a14>
    2e9c:      	add	x8, x10, #0x8
    2ea0:      	ld1.s	{ v20 }[2], [x8]
    2ea4:      	tbz	w9, #0x3, 0x2a18 <ltmp0+0x2a18>
    2ea8:      	add	x8, x10, #0xc
    2eac:      	ld1.s	{ v20 }[3], [x8]
    2eb0:      	tbz	w9, #0x4, 0x2a1c <ltmp0+0x2a1c>
    2eb4:      	add	x8, x10, #0x10
    2eb8:      	ld1.s	{ v21 }[0], [x8]
    2ebc:      	tbz	w9, #0x5, 0x2a20 <ltmp0+0x2a20>
    2ec0:      	add	x8, x10, #0x14
    2ec4:      	ld1.s	{ v21 }[1], [x8]
    2ec8:      	tbz	w9, #0x6, 0x2a24 <ltmp0+0x2a24>
    2ecc:      	add	x8, x10, #0x18
    2ed0:      	ld1.s	{ v21 }[2], [x8]
    2ed4:      	tbnz	w9, #0x7, 0x2a28 <ltmp0+0x2a28>
    2ed8:      	b	0x2a30 <ltmp0+0x2a30>
    2edc:      	str	s6, [x10]
    2ee0:      	ldr	w12, [sp, #0x174]
    2ee4:      	ldr	w13, [sp, #0x170]
    2ee8:      	tbz	w9, #0x1, 0x2dd8 <ltmp0+0x2dd8>
    2eec:      	add	x8, x10, #0x4
    2ef0:      	st1.s	{ v6 }[1], [x8]
    2ef4:      	tbz	w9, #0x2, 0x2ddc <ltmp0+0x2ddc>
    2ef8:      	add	x8, x10, #0x8
    2efc:      	st1.s	{ v6 }[2], [x8]
    2f00:      	tbnz	w9, #0x3, 0x2de0 <ltmp0+0x2de0>
    2f04:      	b	0x2de8 <ltmp0+0x2de8>
    2f08:      	str	s2, [x10, #0x10]
    2f0c:      	tbz	w9, #0x5, 0x2e10 <ltmp0+0x2e10>
    2f10:      	add	x8, x10, #0x14
    2f14:      	st1.s	{ v2 }[1], [x8]
    2f18:      	tbz	w9, #0x6, 0x2e14 <ltmp0+0x2e14>
    2f1c:      	add	x8, x10, #0x18
    2f20:      	st1.s	{ v2 }[2], [x8]
    2f24:      	tbz	w9, #0x7, 0xc8 <ltmp0+0xc8>
    2f28:      	add	x8, x10, #0x1c
    2f2c:      	st1.s	{ v2 }[3], [x8]
    2f30:      	b	0xc8 <ltmp0+0xc8>
    2f34:      	stp	w0, w14, [x2]
    2f38:      	str	w13, [x2, #0x8]
    2f3c:      	mov	w8, #0x18               ; =24
    2f40:      	str	w8, [x2, #0x24]
    2f44:      	add	sp, sp, #0x7b0
    2f48:      	ldp	x29, x30, [sp, #0x90]
    2f4c:      	ldp	x20, x19, [sp, #0x80]
    2f50:      	ldp	x22, x21, [sp, #0x70]
    2f54:      	ldp	x24, x23, [sp, #0x60]
    2f58:      	ldp	x26, x25, [sp, #0x50]
    2f5c:      	ldp	x28, x27, [sp, #0x40]
    2f60:      	ldp	d9, d8, [sp, #0x30]
    2f64:      	ldp	d11, d10, [sp, #0x20]
    2f68:      	ldp	d13, d12, [sp, #0x10]
    2f6c:      	ldp	d15, d14, [sp], #0xa0
    2f70:      	ret

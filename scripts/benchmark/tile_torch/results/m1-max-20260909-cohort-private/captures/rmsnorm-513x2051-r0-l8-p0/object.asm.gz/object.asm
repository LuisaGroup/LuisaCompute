
/tmp/luisa-cohort-private.qfZvpM/capture/rmsnorm-513x2051-r0-l8-p0/object/tile_xir_w8_77317_1788916371990048_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x4, lsl #12   ; =0x4000
      2c:      	sub	sp, sp, #0x590
      30:      	str	x0, [sp, #0x130]
      34:      	str	w3, [sp, #0x148]
      38:      	cbz	w3, 0x30ac <ltmp0+0x30ac>
      3c:      	mov	w14, #0x0               ; =0
      40:      	add	x8, sp, #0x550
      44:      	add	x10, sp, #0x2, lsl #12  ; =0x2000
      48:      	add	x10, x10, #0x570
      4c:      	dup.2d	v0, x8
      50:      	mov	w13, #0x4               ; =4
      54:      	adrp	x15, 0x0 <ltmp0>
      58:      	dup.2d	v1, x10
      5c:      	adrp	x16, 0x0 <ltmp0>
      60:      	adrp	x17, 0x0 <ltmp0>
      64:      	adrp	x1, 0x0 <ltmp0>
      68:      	adrp	x4, 0x0 <ltmp0>
      6c:      	dup.2d	v2, x13
      70:      	str	q2, [sp, #0x120]
      74:      	adrp	x5, 0x0 <ltmp0>
      78:      	adrp	x8, 0x0 <ltmp0>
      7c:      	ldr	q3, [x8]
      80:      	adrp	x6, 0x0 <ltmp0>
      84:      	adrp	x8, 0x0 <ltmp0>
      88:      	ldr	q4, [x8]
      8c:      	adrp	x7, 0x0 <ltmp0>
      90:      	adrp	x19, 0x0 <ltmp0>
      94:      	adrp	x20, 0x0 <ltmp0>
      98:      	adrp	x21, 0x0 <ltmp0>
      9c:      	adrp	x22, 0x0 <ltmp0>
      a0:      	adrp	x23, 0x0 <ltmp0>
      a4:      	mov	w24, #0x1               ; =1
      a8:      	movi	d12, #0000000000000000
      ac:      	ldp	w9, w8, [x2, #0x2c]
      b0:      	str	w9, [sp, #0x144]
      b4:      	str	w8, [sp, #0x140]
      b8:      	ldp	w8, w9, [x2]
      bc:      	ldp	w11, w12, [x2, #0x8]
      c0:      	str	x2, [sp, #0x8]
      c4:      	str	x12, [sp, #0x138]
      c8:      	str	q3, [sp, #0x240]
      cc:      	b	0x110 <ltmp0+0x110>
      d0:      	add	w8, w25, #0x1
      d4:      	ldr	w9, [sp, #0x144]
      d8:      	cmp	w8, w9
      dc:      	cset	w9, eq
      e0:      	csinc	w8, wzr, w25, eq
      e4:      	cinc	w11, w2, eq
      e8:      	ldr	w12, [sp, #0x140]
      ec:      	cmp	w11, w12
      f0:      	cset	w12, eq
      f4:      	ands	w12, w9, w12
      f8:      	csel	w9, wzr, w11, ne
      fc:      	add	w11, w0, w12
     100:      	add	w14, w14, #0x1
     104:      	ldr	w12, [sp, #0x148]
     108:      	cmp	w14, w12
     10c:      	b.eq	0x3098 <ltmp0+0x3098>
     110:      	str	w11, [sp, #0x154]
     114:      	str	w9, [sp, #0x150]
     118:      	mov	x2, x8
     11c:      	ubfiz	x8, x8, #5, #32
     120:      	ldr	x0, [sp, #0x138]
     124:      	cmp	x8, x0
     128:      	csel	x9, x8, xzr, ls
     12c:      	subs	x11, x0, x9
     130:      	cmp	x11, #0x20
     134:      	mov	w12, #0x20              ; =32
     138:      	csel	x11, x11, x12, lo
     13c:      	cmp	x0, x9
     140:      	ccmp	x8, x0, #0x2, hi
     144:      	csel	x9, x11, xzr, ls
     148:      	cmp	x9, #0x20
     14c:      	str	x2, [sp, #0x158]
     150:      	b.lo	0x1624 <ltmp0+0x1624>
     154:      	mov	x8, #0x0                ; =0
     158:      	ldr	x9, [sp, #0x130]
     15c:      	ldr	x11, [x9]
     160:      	ldr	x3, [x9, #0x10]
     164:      	ldr	x9, [x9, #0x30]
     168:      	str	x9, [sp, #0x1e0]
     16c:      	ubfiz	w12, w2, #2, #27
     170:      	mov	w9, #0x200c             ; =8204
     174:      	umull	x0, w12, w9
     178:      	mov	w2, #0x200c             ; =8204
     17c:      	mov	x26, x11
     180:      	str	w12, [sp, #0x1d0]
     184:      	umaddl	x9, w12, w9, x11
     188:      	adrp	x11, 0x0 <ltmp0>
     18c:      	add	x12, x9, x8
     190:      	ldp	q2, q5, [x12]
     194:      	add	x12, x10, x8
     198:      	stp	q2, q5, [x12]
     19c:      	add	x8, x8, #0x20
     1a0:      	cmp	x8, #0x2, lsl #12       ; =0x2000
     1a4:      	b.ne	0x18c <ltmp0+0x18c>
     1a8:      	add	x9, x0, #0x2, lsl #12   ; =0x2000
     1ac:      	add	x8, x26, x9
     1b0:      	add	x12, x8, #0x4
     1b4:      	add	x25, x8, #0x8
     1b8:      	ldr	s2, [x8]
     1bc:      	ld1.s	{ v2 }[1], [x12]
     1c0:      	ld1.s	{ v2 }[2], [x25]
     1c4:      	add	x8, x10, x2
     1c8:      	str	q2, [sp, #0x290]
     1cc:      	ld1.s	{ v2 }[3], [x8]
     1d0:      	str	q2, [sp, #0x4570]
     1d4:      	ldr	q2, [sp, #0x2570]
     1d8:      	ldr	q5, [sp, #0x2580]
     1dc:      	fmul.4s	v5, v5, v5
     1e0:      	fmul.4s	v6, v2, v2
     1e4:      	ldr	q2, [sp, #0x2590]
     1e8:      	ldr	q7, [sp, #0x25a0]
     1ec:      	fmul.4s	v16, v7, v7
     1f0:      	fmul.4s	v7, v2, v2
     1f4:      	ldr	q2, [sp, #0x25b0]
     1f8:      	ldr	q17, [sp, #0x25c0]
     1fc:      	fmul.4s	v17, v17, v17
     200:      	fmul.4s	v18, v2, v2
     204:      	ldr	q2, [sp, #0x25d0]
     208:      	ldr	q19, [sp, #0x25e0]
     20c:      	fmul.4s	v10, v19, v19
     210:      	fmul.4s	v9, v2, v2
     214:      	ldr	q14, [sp, #0x120]
     218:      	mov.16b	v11, v14
     21c:      	mov.16b	v12, v14
     220:      	mov.16b	v13, v14
     224:      	shl.2d	v2, v11, #0x5
     228:      	add.2d	v30, v1, v2
     22c:      	ldr	q2, [sp, #0x240]
     230:      	add.2d	v21, v30, v2
     234:      	mov.d	x8, v21[1]
     238:      	shl.2d	v2, v12, #0x5
     23c:      	add.2d	v19, v1, v2
     240:      	add.2d	v22, v19, v4
     244:      	mov.d	x12, v22[1]
     248:      	ldr	q27, [x11]
     24c:      	shl.2d	v2, v13, #0x5
     250:      	add.2d	v15, v1, v2
     254:      	add.2d	v23, v15, v27
     258:      	mov.d	x25, v23[1]
     25c:      	ldr	q20, [x15]
     260:      	shl.2d	v2, v14, #0x5
     264:      	add.2d	v2, v1, v2
     268:      	add.2d	v24, v2, v20
     26c:      	mov.d	x27, v24[1]
     270:      	fmov	x28, d21
     274:      	ldr	s21, [x28]
     278:      	fmov	x28, d22
     27c:      	fmov	x30, d23
     280:      	ld1.s	{ v21 }[1], [x8]
     284:      	fmov	x8, d24
     288:      	ld1.s	{ v21 }[2], [x28]
     28c:      	ld1.s	{ v21 }[3], [x12]
     290:      	ldr	s22, [x30]
     294:      	ld1.s	{ v22 }[1], [x25]
     298:      	ld1.s	{ v22 }[2], [x8]
     29c:      	ld1.s	{ v22 }[3], [x27]
     2a0:      	fmul.4s	v22, v22, v22
     2a4:      	fmul.4s	v21, v21, v21
     2a8:      	fadd.4s	v6, v6, v21
     2ac:      	fadd.4s	v5, v5, v22
     2b0:      	ldr	q23, [x16]
     2b4:      	ldr	q24, [x17]
     2b8:      	ldr	q28, [x1]
     2bc:      	ldr	q29, [x4]
     2c0:      	add.2d	v21, v2, v29
     2c4:      	add.2d	v22, v15, v28
     2c8:      	add.2d	v25, v19, v24
     2cc:      	add.2d	v26, v30, v23
     2d0:      	mov.d	x8, v26[1]
     2d4:      	fmov	x12, d26
     2d8:      	mov.d	x25, v25[1]
     2dc:      	fmov	x27, d25
     2e0:      	mov.d	x28, v22[1]
     2e4:      	fmov	x30, d22
     2e8:      	mov.d	x2, v21[1]
     2ec:      	ldr	s22, [x12]
     2f0:      	ld1.s	{ v22 }[1], [x8]
     2f4:      	ld1.s	{ v22 }[2], [x27]
     2f8:      	ld1.s	{ v22 }[3], [x25]
     2fc:      	fmov	x8, d21
     300:      	ldr	s21, [x30]
     304:      	ld1.s	{ v21 }[1], [x28]
     308:      	ld1.s	{ v21 }[2], [x8]
     30c:      	ld1.s	{ v21 }[3], [x2]
     310:      	fmul.4s	v21, v21, v21
     314:      	fmul.4s	v22, v22, v22
     318:      	fadd.4s	v7, v7, v22
     31c:      	fadd.4s	v16, v16, v21
     320:      	ldr	q26, [x5]
     324:      	ldr	q25, [x6]
     328:      	ldr	q31, [x7]
     32c:      	ldr	q3, [x19]
     330:      	add.2d	v21, v2, v3
     334:      	add.2d	v22, v30, v26
     338:      	mov.d	x8, v22[1]
     33c:      	fmov	x12, d22
     340:      	add.2d	v22, v19, v25
     344:      	mov.d	x2, v22[1]
     348:      	fmov	x25, d22
     34c:      	add.2d	v22, v15, v31
     350:      	mov.d	x27, v22[1]
     354:      	mov.d	x28, v21[1]
     358:      	fmov	x30, d22
     35c:      	ldr	s22, [x12]
     360:      	ld1.s	{ v22 }[1], [x8]
     364:      	ld1.s	{ v22 }[2], [x25]
     368:      	fmov	x8, d21
     36c:      	ld1.s	{ v22 }[3], [x2]
     370:      	ldr	s21, [x30]
     374:      	ld1.s	{ v21 }[1], [x27]
     378:      	ld1.s	{ v21 }[2], [x8]
     37c:      	ld1.s	{ v21 }[3], [x28]
     380:      	fmul.4s	v21, v21, v21
     384:      	fmul.4s	v22, v22, v22
     388:      	fadd.4s	v18, v18, v22
     38c:      	fadd.4s	v17, v17, v21
     390:      	ldr	q22, [x20]
     394:      	add.2d	v21, v30, v22
     398:      	mov.d	x8, v21[1]
     39c:      	ldr	q30, [x21]
     3a0:      	fmov	x12, d21
     3a4:      	ldr	q8, [x22]
     3a8:      	add.2d	v21, v19, v30
     3ac:      	mov.d	x2, v21[1]
     3b0:      	fmov	x25, d21
     3b4:      	ldr	q19, [x23]
     3b8:      	add.2d	v2, v2, v19
     3bc:      	add.2d	v21, v15, v8
     3c0:      	mov.d	x27, v21[1]
     3c4:      	fmov	x28, d21
     3c8:      	mov.d	x30, v2[1]
     3cc:      	ldr	s21, [x12]
     3d0:      	ld1.s	{ v21 }[1], [x8]
     3d4:      	fmov	x8, d2
     3d8:      	ld1.s	{ v21 }[2], [x25]
     3dc:      	ld1.s	{ v21 }[3], [x2]
     3e0:      	fmul.4s	v2, v21, v21
     3e4:      	fadd.4s	v9, v9, v2
     3e8:      	ldr	s2, [x28]
     3ec:      	ld1.s	{ v2 }[1], [x27]
     3f0:      	ld1.s	{ v2 }[2], [x8]
     3f4:      	ld1.s	{ v2 }[3], [x30]
     3f8:      	fmul.4s	v2, v2, v2
     3fc:      	fadd.4s	v10, v10, v2
     400:      	dup.2d	v2, x13
     404:      	add.2d	v13, v13, v2
     408:      	add.2d	v12, v12, v2
     40c:      	add.2d	v14, v14, v2
     410:      	add.2d	v11, v11, v2
     414:      	fmov	x8, d11
     418:      	cmp	x8, #0x100
     41c:      	b.lt	0x224 <ltmp0+0x224>
     420:      	stp	q22, q3, [sp, #0x220]
     424:      	stp	q31, q25, [sp, #0x250]
     428:      	str	q26, [sp, #0x270]
     42c:      	str	q19, [sp, #0x1f0]
     430:      	stp	q24, q23, [sp, #0x2a0]
     434:      	mov	x8, #0x0                ; =0
     438:      	movi.2d	v2, #0000000000000000
     43c:      	movi.2d	v21, #0000000000000000
     440:      	movi.2d	v22, #0000000000000000
     444:      	movi.2d	v11, #0000000000000000
     448:      	mov.16b	v19, v27
     44c:      	ldr	q3, [sp, #0x240]
     450:      	add	x8, x3, x8, lsl #5
     454:      	ldp	q13, q12, [x8]
     458:      	shl.2d	v14, v2, #0x5
     45c:      	shl.2d	v15, v21, #0x5
     460:      	shl.2d	v23, v22, #0x5
     464:      	shl.2d	v24, v11, #0x5
     468:      	add.2d	v24, v24, v20
     46c:      	add.2d	v24, v0, v24
     470:      	add.2d	v23, v23, v19
     474:      	add.2d	v15, v15, v4
     478:      	add.2d	v14, v14, v3
     47c:      	add.2d	v14, v0, v14
     480:      	mov.d	x8, v14[1]
     484:      	fmov	x12, d14
     488:      	str	s13, [x12]
     48c:      	st1.s	{ v13 }[1], [x8]
     490:      	add.2d	v14, v0, v15
     494:      	mov.d	x8, v14[1]
     498:      	fmov	x12, d14
     49c:      	st1.s	{ v13 }[2], [x12]
     4a0:      	add.2d	v23, v0, v23
     4a4:      	st1.s	{ v13 }[3], [x8]
     4a8:      	mov.d	x8, v23[1]
     4ac:      	fmov	x12, d23
     4b0:      	str	s12, [x12]
     4b4:      	st1.s	{ v12 }[1], [x8]
     4b8:      	mov.d	x8, v24[1]
     4bc:      	fmov	x12, d24
     4c0:      	st1.s	{ v12 }[2], [x12]
     4c4:      	st1.s	{ v12 }[3], [x8]
     4c8:      	dup.2d	v23, x24
     4cc:      	add.2d	v22, v22, v23
     4d0:      	add.2d	v21, v21, v23
     4d4:      	add.2d	v11, v11, v23
     4d8:      	add.2d	v2, v2, v23
     4dc:      	fmov	x8, d2
     4e0:      	cmp	x8, #0x100
     4e4:      	b.lt	0x450 <ltmp0+0x450>
     4e8:      	mov	x8, #0x0                ; =0
     4ec:      	ldr	q2, [sp, #0x290]
     4f0:      	fmul.4s	v2, v2, v2
     4f4:      	fadd.4s	v2, v2, v6
     4f8:      	mov.s	v2[3], v6[3]
     4fc:      	fadd.4s	v5, v16, v5
     500:      	fadd.4s	v2, v7, v2
     504:      	fadd.4s	v2, v18, v2
     508:      	fadd.4s	v5, v17, v5
     50c:      	fadd.4s	v5, v10, v5
     510:      	fadd.4s	v2, v9, v2
     514:      	rev64.4s	v6, v2
     518:      	rev64.4s	v7, v5
     51c:      	fadd.4s	v5, v5, v7
     520:      	fadd.4s	v2, v2, v6
     524:      	dup.4s	v6, v2[2]
     528:      	dup.4s	v7, v5[2]
     52c:      	fadd.4s	v5, v5, v7
     530:      	fadd.4s	v2, v2, v6
     534:      	fadd.4s	v2, v2, v5
     538:      	movi	d5, #0000000000000000
     53c:      	fadd	s2, s2, s5
     540:      	mov	w11, #0x3000            ; =12288
     544:      	movk	w11, #0x4500, lsl #16
     548:      	fmov	s5, w11
     54c:      	fdiv	s5, s2, s5
     550:      	mov	w11, #0x2004            ; =8196
     554:      	add	x12, x3, x11
     558:      	ldr	s2, [x3, #0x2000]
     55c:      	ld1.s	{ v2 }[1], [x12]
     560:      	mov	w11, #0x2008            ; =8200
     564:      	add	x12, x3, x11
     568:      	ld1.s	{ v2 }[2], [x12]
     56c:      	add	x11, sp, #0x550
     570:      	mov	w1, #0x200c             ; =8204
     574:      	add	x12, x11, x1
     578:      	ld1.s	{ v2 }[3], [x12]
     57c:      	add	x27, x3, #0x2, lsl #12  ; =0x2000
     580:      	mov	w11, #0xc5ac            ; =50604
     584:      	movk	w11, #0x3727, lsl #16
     588:      	fmov	s6, w11
     58c:      	fadd	s5, s5, s6
     590:      	fsqrt	s5, s5
     594:      	dup.4s	v6, v5[0]
     598:      	str	q2, [sp, #0x2550]
     59c:      	ldr	x4, [sp, #0x1e0]
     5a0:      	add	x12, x4, x0
     5a4:      	movi.2d	v7, #0000000000000000
     5a8:      	movi.2d	v16, #0000000000000000
     5ac:      	movi.2d	v17, #0000000000000000
     5b0:      	movi.2d	v18, #0000000000000000
     5b4:      	mov	x5, x26
     5b8:      	ldr	w6, [sp, #0x1d0]
     5bc:      	ldr	q27, [sp, #0x270]
     5c0:      	shl.2d	v21, v18, #0x5
     5c4:      	shl.2d	v22, v17, #0x5
     5c8:      	shl.2d	v23, v16, #0x5
     5cc:      	shl.2d	v24, v7, #0x5
     5d0:      	orr.16b	v24, v24, v3
     5d4:      	orr.16b	v23, v23, v4
     5d8:      	orr.16b	v22, v22, v19
     5dc:      	orr.16b	v21, v21, v20
     5e0:      	add.2d	v9, v1, v21
     5e4:      	add.2d	v10, v1, v22
     5e8:      	add.2d	v11, v1, v23
     5ec:      	add.2d	v12, v1, v24
     5f0:      	mov.d	x0, v12[1]
     5f4:      	mov.d	x2, v11[1]
     5f8:      	mov.d	x25, v10[1]
     5fc:      	fmov	x28, d12
     600:      	fmov	x30, d10
     604:      	mov.d	x26, v9[1]
     608:      	fmov	x11, d9
     60c:      	ldr	s9, [x30]
     610:      	ld1.s	{ v9 }[1], [x25]
     614:      	ld1.s	{ v9 }[2], [x11]
     618:      	ld1.s	{ v9 }[3], [x26]
     61c:      	fmov	x11, d11
     620:      	ldr	s10, [x28]
     624:      	ld1.s	{ v10 }[1], [x0]
     628:      	ld1.s	{ v10 }[2], [x11]
     62c:      	ld1.s	{ v10 }[3], [x2]
     630:      	fdiv.4s	v10, v10, v6
     634:      	fdiv.4s	v9, v9, v6
     638:      	add.2d	v21, v0, v21
     63c:      	add.2d	v22, v0, v22
     640:      	add.2d	v23, v0, v23
     644:      	add.2d	v24, v0, v24
     648:      	mov.d	x11, v24[1]
     64c:      	fmov	x0, d24
     650:      	mov.d	x2, v23[1]
     654:      	mov.d	x25, v22[1]
     658:      	mov.d	x26, v21[1]
     65c:      	fmov	x28, d23
     660:      	ldr	s23, [x0]
     664:      	ld1.s	{ v23 }[1], [x11]
     668:      	ld1.s	{ v23 }[2], [x28]
     66c:      	fmov	x11, d22
     670:      	ld1.s	{ v23 }[3], [x2]
     674:      	ldr	s22, [x11]
     678:      	ld1.s	{ v22 }[1], [x25]
     67c:      	fmov	x11, d21
     680:      	ld1.s	{ v22 }[2], [x11]
     684:      	ld1.s	{ v22 }[3], [x26]
     688:      	fmul.4s	v21, v9, v22
     68c:      	fmul.4s	v22, v10, v23
     690:      	add	x8, x12, x8, lsl #5
     694:      	stp	q22, q21, [x8]
     698:      	dup.2d	v21, x24
     69c:      	add.2d	v17, v17, v21
     6a0:      	add.2d	v16, v16, v21
     6a4:      	add.2d	v18, v18, v21
     6a8:      	add.2d	v7, v7, v21
     6ac:      	fmov	x8, d7
     6b0:      	cmp	x8, #0x100
     6b4:      	b.lt	0x5c0 <ltmp0+0x5c0>
     6b8:      	stp	q8, q30, [sp, #0x200]
     6bc:      	stp	q29, q28, [sp, #0x280]
     6c0:      	mov	x12, #0x0               ; =0
     6c4:      	ldr	q6, [sp, #0x4570]
     6c8:      	dup.4s	v5, v5[0]
     6cc:      	fdiv.4s	v5, v6, v5
     6d0:      	fmul.4s	v2, v2, v5
     6d4:      	add	x8, x4, x9
     6d8:      	str	d2, [x8], #0x8
     6dc:      	st1.s	{ v2 }[2], [x8]
     6e0:      	orr	w9, w6, #0x1
     6e4:      	umull	x8, w9, w1
     6e8:      	umaddl	x9, w9, w1, x5
     6ec:      	add	x11, x9, x12
     6f0:      	ldp	q2, q5, [x11]
     6f4:      	add	x11, x10, x12
     6f8:      	stp	q2, q5, [x11]
     6fc:      	add	x12, x12, #0x20
     700:      	cmp	x12, #0x2, lsl #12      ; =0x2000
     704:      	b.ne	0x6ec <ltmp0+0x6ec>
     708:      	add	x9, x8, #0x2, lsl #12   ; =0x2000
     70c:      	add	x11, x5, x9
     710:      	add	x12, x11, #0x4
     714:      	add	x0, x11, #0x8
     718:      	ldr	s2, [x11]
     71c:      	ld1.s	{ v2 }[1], [x12]
     720:      	ld1.s	{ v2 }[2], [x0]
     724:      	add	x11, x10, x1
     728:      	str	q2, [sp, #0x1c0]
     72c:      	ld1.s	{ v2 }[3], [x11]
     730:      	str	q2, [sp, #0x4570]
     734:      	ldr	q2, [sp, #0x2570]
     738:      	ldr	q5, [sp, #0x2580]
     73c:      	fmul.4s	v5, v5, v5
     740:      	fmul.4s	v6, v2, v2
     744:      	ldr	q2, [sp, #0x2590]
     748:      	ldr	q7, [sp, #0x25a0]
     74c:      	fmul.4s	v16, v7, v7
     750:      	fmul.4s	v7, v2, v2
     754:      	ldr	q2, [sp, #0x25b0]
     758:      	ldr	q17, [sp, #0x25c0]
     75c:      	fmul.4s	v17, v17, v17
     760:      	fmul.4s	v18, v2, v2
     764:      	ldr	q2, [sp, #0x25d0]
     768:      	ldr	q21, [sp, #0x25e0]
     76c:      	fmul.4s	v10, v21, v21
     770:      	fmul.4s	v9, v2, v2
     774:      	dup.2d	v11, x13
     778:      	mov.16b	v12, v11
     77c:      	mov.16b	v13, v11
     780:      	mov.16b	v14, v11
     784:      	mov.16b	v30, v27
     788:      	ldr	q8, [sp, #0x250]
     78c:      	ldp	q27, q26, [sp, #0x220]
     790:      	ldp	q29, q28, [sp, #0x200]
     794:      	ldr	q31, [sp, #0x1f0]
     798:      	shl.2d	v2, v11, #0x5
     79c:      	shl.2d	v22, v12, #0x5
     7a0:      	shl.2d	v23, v13, #0x5
     7a4:      	shl.2d	v21, v14, #0x5
     7a8:      	add.2d	v15, v1, v21
     7ac:      	add.2d	v24, v15, v20
     7b0:      	add.2d	v21, v1, v2
     7b4:      	add.2d	v25, v21, v3
     7b8:      	mov.d	x11, v25[1]
     7bc:      	add.2d	v2, v1, v23
     7c0:      	add.2d	v22, v1, v22
     7c4:      	fmov	x12, d25
     7c8:      	add.2d	v23, v22, v4
     7cc:      	mov.d	x0, v23[1]
     7d0:      	fmov	x2, d23
     7d4:      	add.2d	v23, v2, v19
     7d8:      	mov.d	x25, v23[1]
     7dc:      	fmov	x26, d23
     7e0:      	mov.d	x28, v24[1]
     7e4:      	ldr	s23, [x12]
     7e8:      	ld1.s	{ v23 }[1], [x11]
     7ec:      	fmov	x11, d24
     7f0:      	ld1.s	{ v23 }[2], [x2]
     7f4:      	ld1.s	{ v23 }[3], [x0]
     7f8:      	ldr	s24, [x26]
     7fc:      	ld1.s	{ v24 }[1], [x25]
     800:      	ld1.s	{ v24 }[2], [x11]
     804:      	ld1.s	{ v24 }[3], [x28]
     808:      	fmul.4s	v24, v24, v24
     80c:      	fmul.4s	v23, v23, v23
     810:      	fadd.4s	v6, v6, v23
     814:      	fadd.4s	v5, v5, v24
     818:      	ldr	q23, [sp, #0x280]
     81c:      	add.2d	v23, v15, v23
     820:      	ldr	q24, [sp, #0x2b0]
     824:      	add.2d	v24, v21, v24
     828:      	mov.d	x11, v24[1]
     82c:      	fmov	x12, d24
     830:      	ldr	q24, [sp, #0x2a0]
     834:      	add.2d	v24, v22, v24
     838:      	mov.d	x0, v24[1]
     83c:      	fmov	x2, d24
     840:      	ldr	q24, [sp, #0x290]
     844:      	add.2d	v24, v2, v24
     848:      	mov.d	x25, v24[1]
     84c:      	mov.d	x26, v23[1]
     850:      	fmov	x28, d24
     854:      	ldr	s24, [x12]
     858:      	ld1.s	{ v24 }[1], [x11]
     85c:      	ld1.s	{ v24 }[2], [x2]
     860:      	fmov	x11, d23
     864:      	ld1.s	{ v24 }[3], [x0]
     868:      	ldr	s23, [x28]
     86c:      	ld1.s	{ v23 }[1], [x25]
     870:      	ld1.s	{ v23 }[2], [x11]
     874:      	ld1.s	{ v23 }[3], [x26]
     878:      	fmul.4s	v23, v23, v23
     87c:      	fmul.4s	v24, v24, v24
     880:      	fadd.4s	v7, v7, v24
     884:      	fadd.4s	v16, v16, v23
     888:      	add.2d	v23, v15, v26
     88c:      	add.2d	v24, v21, v30
     890:      	mov.d	x11, v24[1]
     894:      	fmov	x12, d24
     898:      	ldr	q24, [sp, #0x260]
     89c:      	add.2d	v24, v22, v24
     8a0:      	mov.d	x0, v24[1]
     8a4:      	fmov	x2, d24
     8a8:      	add.2d	v24, v2, v8
     8ac:      	mov.d	x25, v24[1]
     8b0:      	fmov	x26, d24
     8b4:      	mov.d	x28, v23[1]
     8b8:      	ldr	s24, [x12]
     8bc:      	ld1.s	{ v24 }[1], [x11]
     8c0:      	ld1.s	{ v24 }[2], [x2]
     8c4:      	ld1.s	{ v24 }[3], [x0]
     8c8:      	fmov	x11, d23
     8cc:      	fmul.4s	v23, v24, v24
     8d0:      	fadd.4s	v18, v18, v23
     8d4:      	ldr	s23, [x26]
     8d8:      	ld1.s	{ v23 }[1], [x25]
     8dc:      	ld1.s	{ v23 }[2], [x11]
     8e0:      	ld1.s	{ v23 }[3], [x28]
     8e4:      	fmul.4s	v23, v23, v23
     8e8:      	fadd.4s	v17, v17, v23
     8ec:      	add.2d	v22, v22, v28
     8f0:      	add.2d	v21, v21, v27
     8f4:      	mov.d	x11, v21[1]
     8f8:      	mov.d	x12, v22[1]
     8fc:      	fmov	x0, d21
     900:      	fmov	x2, d22
     904:      	add.2d	v21, v15, v31
     908:      	add.2d	v2, v2, v29
     90c:      	mov.d	x25, v2[1]
     910:      	fmov	x26, d2
     914:      	mov.d	x28, v21[1]
     918:      	ldr	s2, [x0]
     91c:      	ld1.s	{ v2 }[1], [x11]
     920:      	fmov	x11, d21
     924:      	ld1.s	{ v2 }[2], [x2]
     928:      	ld1.s	{ v2 }[3], [x12]
     92c:      	fmul.4s	v2, v2, v2
     930:      	fadd.4s	v9, v9, v2
     934:      	ldr	s2, [x26]
     938:      	ld1.s	{ v2 }[1], [x25]
     93c:      	ld1.s	{ v2 }[2], [x11]
     940:      	ld1.s	{ v2 }[3], [x28]
     944:      	fmul.4s	v2, v2, v2
     948:      	fadd.4s	v10, v10, v2
     94c:      	dup.2d	v2, x13
     950:      	add.2d	v13, v13, v2
     954:      	add.2d	v12, v12, v2
     958:      	add.2d	v14, v14, v2
     95c:      	add.2d	v11, v11, v2
     960:      	fmov	x11, d11
     964:      	cmp	x11, #0x100
     968:      	b.lt	0x798 <ltmp0+0x798>
     96c:      	mov	x12, #0x0               ; =0
     970:      	movi.2d	v2, #0000000000000000
     974:      	movi.2d	v21, #0000000000000000
     978:      	movi.2d	v22, #0000000000000000
     97c:      	movi.2d	v11, #0000000000000000
     980:      	add	x11, x3, x12, lsl #5
     984:      	ldp	q24, q23, [x11]
     988:      	shl.2d	v25, v2, #0x5
     98c:      	shl.2d	v12, v21, #0x5
     990:      	shl.2d	v13, v22, #0x5
     994:      	shl.2d	v14, v11, #0x5
     998:      	add.2d	v14, v14, v20
     99c:      	add.2d	v14, v0, v14
     9a0:      	add.2d	v13, v13, v19
     9a4:      	add.2d	v12, v12, v4
     9a8:      	add.2d	v25, v25, v3
     9ac:      	add.2d	v25, v0, v25
     9b0:      	mov.d	x11, v25[1]
     9b4:      	fmov	x12, d25
     9b8:      	str	s24, [x12]
     9bc:      	st1.s	{ v24 }[1], [x11]
     9c0:      	add.2d	v25, v0, v12
     9c4:      	mov.d	x11, v25[1]
     9c8:      	fmov	x12, d25
     9cc:      	st1.s	{ v24 }[2], [x12]
     9d0:      	add.2d	v25, v0, v13
     9d4:      	st1.s	{ v24 }[3], [x11]
     9d8:      	mov.d	x11, v25[1]
     9dc:      	fmov	x12, d25
     9e0:      	str	s23, [x12]
     9e4:      	st1.s	{ v23 }[1], [x11]
     9e8:      	mov.d	x11, v14[1]
     9ec:      	fmov	x12, d14
     9f0:      	st1.s	{ v23 }[2], [x12]
     9f4:      	st1.s	{ v23 }[3], [x11]
     9f8:      	dup.2d	v23, x24
     9fc:      	add.2d	v22, v22, v23
     a00:      	add.2d	v21, v21, v23
     a04:      	add.2d	v11, v11, v23
     a08:      	add.2d	v2, v2, v23
     a0c:      	fmov	x12, d2
     a10:      	cmp	x12, #0x100
     a14:      	b.lt	0x980 <ltmp0+0x980>
     a18:      	mov	x0, #0x0                ; =0
     a1c:      	ldr	q2, [sp, #0x1c0]
     a20:      	fmul.4s	v2, v2, v2
     a24:      	fadd.4s	v2, v2, v6
     a28:      	mov.s	v2[3], v6[3]
     a2c:      	fadd.4s	v5, v16, v5
     a30:      	fadd.4s	v2, v7, v2
     a34:      	fadd.4s	v2, v18, v2
     a38:      	fadd.4s	v5, v17, v5
     a3c:      	fadd.4s	v5, v10, v5
     a40:      	fadd.4s	v2, v9, v2
     a44:      	rev64.4s	v6, v2
     a48:      	rev64.4s	v7, v5
     a4c:      	fadd.4s	v2, v2, v6
     a50:      	dup.4s	v6, v2[2]
     a54:      	fadd.4s	v5, v5, v7
     a58:      	dup.4s	v7, v5[2]
     a5c:      	fadd.4s	v5, v5, v7
     a60:      	fadd.4s	v2, v2, v6
     a64:      	fadd.4s	v2, v2, v5
     a68:      	movi	d5, #0000000000000000
     a6c:      	fadd	s5, s2, s5
     a70:      	mov	w11, #0x3000            ; =12288
     a74:      	movk	w11, #0x4500, lsl #16
     a78:      	fmov	s6, w11
     a7c:      	add	x11, x27, #0x4
     a80:      	ldr	s2, [x27]
     a84:      	ld1.s	{ v2 }[1], [x11]
     a88:      	add	x11, x27, #0x8
     a8c:      	ld1.s	{ v2 }[2], [x11]
     a90:      	add	x11, sp, #0x550
     a94:      	add	x11, x11, x1
     a98:      	ld1.s	{ v2 }[3], [x11]
     a9c:      	fdiv	s5, s5, s6
     aa0:      	mov	w11, #0xc5ac            ; =50604
     aa4:      	movk	w11, #0x3727, lsl #16
     aa8:      	fmov	s6, w11
     aac:      	fadd	s5, s5, s6
     ab0:      	fsqrt	s5, s5
     ab4:      	dup.4s	v6, v5[0]
     ab8:      	str	q2, [sp, #0x2550]
     abc:      	add	x8, x4, x8
     ac0:      	movi.2d	v7, #0000000000000000
     ac4:      	movi.2d	v16, #0000000000000000
     ac8:      	movi.2d	v17, #0000000000000000
     acc:      	movi.2d	v18, #0000000000000000
     ad0:      	shl.2d	v21, v18, #0x5
     ad4:      	shl.2d	v22, v17, #0x5
     ad8:      	shl.2d	v23, v16, #0x5
     adc:      	shl.2d	v24, v7, #0x5
     ae0:      	orr.16b	v24, v24, v3
     ae4:      	orr.16b	v23, v23, v4
     ae8:      	orr.16b	v22, v22, v19
     aec:      	orr.16b	v21, v21, v20
     af0:      	add.2d	v25, v1, v21
     af4:      	add.2d	v9, v1, v22
     af8:      	add.2d	v10, v1, v23
     afc:      	add.2d	v11, v1, v24
     b00:      	mov.d	x11, v11[1]
     b04:      	mov.d	x12, v10[1]
     b08:      	mov.d	x2, v9[1]
     b0c:      	fmov	x25, d11
     b10:      	fmov	x26, d9
     b14:      	mov.d	x28, v25[1]
     b18:      	fmov	x30, d25
     b1c:      	ldr	s25, [x26]
     b20:      	ld1.s	{ v25 }[1], [x2]
     b24:      	ld1.s	{ v25 }[2], [x30]
     b28:      	ld1.s	{ v25 }[3], [x28]
     b2c:      	fmov	x2, d10
     b30:      	ldr	s9, [x25]
     b34:      	ld1.s	{ v9 }[1], [x11]
     b38:      	ld1.s	{ v9 }[2], [x2]
     b3c:      	ld1.s	{ v9 }[3], [x12]
     b40:      	fdiv.4s	v9, v9, v6
     b44:      	fdiv.4s	v25, v25, v6
     b48:      	add.2d	v21, v0, v21
     b4c:      	add.2d	v22, v0, v22
     b50:      	add.2d	v23, v0, v23
     b54:      	add.2d	v24, v0, v24
     b58:      	mov.d	x11, v24[1]
     b5c:      	fmov	x12, d24
     b60:      	mov.d	x2, v23[1]
     b64:      	mov.d	x25, v22[1]
     b68:      	mov.d	x26, v21[1]
     b6c:      	fmov	x28, d23
     b70:      	ldr	s23, [x12]
     b74:      	ld1.s	{ v23 }[1], [x11]
     b78:      	ld1.s	{ v23 }[2], [x28]
     b7c:      	fmov	x11, d22
     b80:      	ld1.s	{ v23 }[3], [x2]
     b84:      	ldr	s22, [x11]
     b88:      	ld1.s	{ v22 }[1], [x25]
     b8c:      	fmov	x11, d21
     b90:      	ld1.s	{ v22 }[2], [x11]
     b94:      	ld1.s	{ v22 }[3], [x26]
     b98:      	fmul.4s	v21, v25, v22
     b9c:      	fmul.4s	v22, v9, v23
     ba0:      	add	x11, x8, x0, lsl #5
     ba4:      	stp	q22, q21, [x11]
     ba8:      	dup.2d	v21, x24
     bac:      	add.2d	v17, v17, v21
     bb0:      	add.2d	v16, v16, v21
     bb4:      	add.2d	v18, v18, v21
     bb8:      	add.2d	v7, v7, v21
     bbc:      	fmov	x0, d7
     bc0:      	cmp	x0, #0x100
     bc4:      	b.lt	0xad0 <ltmp0+0xad0>
     bc8:      	mov	x12, #0x0               ; =0
     bcc:      	ldr	q6, [sp, #0x4570]
     bd0:      	dup.4s	v5, v5[0]
     bd4:      	fdiv.4s	v5, v6, v5
     bd8:      	fmul.4s	v2, v2, v5
     bdc:      	add	x8, x4, x9
     be0:      	str	d2, [x8], #0x8
     be4:      	st1.s	{ v2 }[2], [x8]
     be8:      	orr	w9, w6, #0x2
     bec:      	umull	x8, w9, w1
     bf0:      	umaddl	x9, w9, w1, x5
     bf4:      	add	x11, x9, x12
     bf8:      	ldp	q2, q5, [x11]
     bfc:      	add	x11, x10, x12
     c00:      	stp	q2, q5, [x11]
     c04:      	add	x12, x12, #0x20
     c08:      	cmp	x12, #0x2, lsl #12      ; =0x2000
     c0c:      	b.ne	0xbf4 <ltmp0+0xbf4>
     c10:      	add	x9, x8, #0x2, lsl #12   ; =0x2000
     c14:      	add	x11, x5, x9
     c18:      	add	x12, x11, #0x4
     c1c:      	add	x0, x11, #0x8
     c20:      	ldr	s2, [x11]
     c24:      	ld1.s	{ v2 }[1], [x12]
     c28:      	ld1.s	{ v2 }[2], [x0]
     c2c:      	add	x11, x10, x1
     c30:      	str	q2, [sp, #0x1c0]
     c34:      	ld1.s	{ v2 }[3], [x11]
     c38:      	str	q2, [sp, #0x4570]
     c3c:      	ldr	q2, [sp, #0x2570]
     c40:      	ldr	q5, [sp, #0x2580]
     c44:      	fmul.4s	v5, v5, v5
     c48:      	fmul.4s	v6, v2, v2
     c4c:      	ldr	q2, [sp, #0x2590]
     c50:      	ldr	q7, [sp, #0x25a0]
     c54:      	fmul.4s	v16, v7, v7
     c58:      	fmul.4s	v7, v2, v2
     c5c:      	ldr	q2, [sp, #0x25b0]
     c60:      	ldr	q17, [sp, #0x25c0]
     c64:      	fmul.4s	v17, v17, v17
     c68:      	fmul.4s	v18, v2, v2
     c6c:      	ldr	q2, [sp, #0x25d0]
     c70:      	ldr	q21, [sp, #0x25e0]
     c74:      	fmul.4s	v10, v21, v21
     c78:      	fmul.4s	v9, v2, v2
     c7c:      	dup.2d	v11, x13
     c80:      	mov.16b	v12, v11
     c84:      	mov.16b	v13, v11
     c88:      	mov.16b	v14, v11
     c8c:      	ldp	q8, q31, [sp, #0x250]
     c90:      	ldp	q27, q26, [sp, #0x220]
     c94:      	ldp	q29, q28, [sp, #0x200]
     c98:      	ldr	q30, [sp, #0x1f0]
     c9c:      	shl.2d	v2, v11, #0x5
     ca0:      	shl.2d	v22, v12, #0x5
     ca4:      	shl.2d	v23, v13, #0x5
     ca8:      	shl.2d	v21, v14, #0x5
     cac:      	add.2d	v15, v1, v21
     cb0:      	add.2d	v24, v15, v20
     cb4:      	add.2d	v21, v1, v2
     cb8:      	add.2d	v25, v21, v3
     cbc:      	mov.d	x11, v25[1]
     cc0:      	add.2d	v2, v1, v23
     cc4:      	add.2d	v22, v1, v22
     cc8:      	fmov	x12, d25
     ccc:      	add.2d	v23, v22, v4
     cd0:      	mov.d	x0, v23[1]
     cd4:      	fmov	x2, d23
     cd8:      	add.2d	v23, v2, v19
     cdc:      	mov.d	x25, v23[1]
     ce0:      	fmov	x26, d23
     ce4:      	mov.d	x28, v24[1]
     ce8:      	ldr	s23, [x12]
     cec:      	ld1.s	{ v23 }[1], [x11]
     cf0:      	fmov	x11, d24
     cf4:      	ld1.s	{ v23 }[2], [x2]
     cf8:      	ld1.s	{ v23 }[3], [x0]
     cfc:      	ldr	s24, [x26]
     d00:      	ld1.s	{ v24 }[1], [x25]
     d04:      	ld1.s	{ v24 }[2], [x11]
     d08:      	ld1.s	{ v24 }[3], [x28]
     d0c:      	fmul.4s	v24, v24, v24
     d10:      	fmul.4s	v23, v23, v23
     d14:      	fadd.4s	v6, v6, v23
     d18:      	fadd.4s	v5, v5, v24
     d1c:      	ldr	q23, [sp, #0x280]
     d20:      	add.2d	v23, v15, v23
     d24:      	ldr	q24, [sp, #0x2b0]
     d28:      	add.2d	v24, v21, v24
     d2c:      	mov.d	x11, v24[1]
     d30:      	fmov	x12, d24
     d34:      	ldr	q24, [sp, #0x2a0]
     d38:      	add.2d	v24, v22, v24
     d3c:      	mov.d	x0, v24[1]
     d40:      	fmov	x2, d24
     d44:      	ldr	q24, [sp, #0x290]
     d48:      	add.2d	v24, v2, v24
     d4c:      	mov.d	x25, v24[1]
     d50:      	mov.d	x26, v23[1]
     d54:      	fmov	x28, d24
     d58:      	ldr	s24, [x12]
     d5c:      	ld1.s	{ v24 }[1], [x11]
     d60:      	ld1.s	{ v24 }[2], [x2]
     d64:      	fmov	x11, d23
     d68:      	ld1.s	{ v24 }[3], [x0]
     d6c:      	ldr	s23, [x28]
     d70:      	ld1.s	{ v23 }[1], [x25]
     d74:      	ld1.s	{ v23 }[2], [x11]
     d78:      	ld1.s	{ v23 }[3], [x26]
     d7c:      	fmul.4s	v23, v23, v23
     d80:      	fmul.4s	v24, v24, v24
     d84:      	fadd.4s	v7, v7, v24
     d88:      	fadd.4s	v16, v16, v23
     d8c:      	add.2d	v23, v15, v26
     d90:      	ldr	q24, [sp, #0x270]
     d94:      	add.2d	v24, v21, v24
     d98:      	mov.d	x11, v24[1]
     d9c:      	fmov	x12, d24
     da0:      	add.2d	v24, v22, v31
     da4:      	mov.d	x0, v24[1]
     da8:      	fmov	x2, d24
     dac:      	add.2d	v24, v2, v8
     db0:      	mov.d	x25, v24[1]
     db4:      	fmov	x26, d24
     db8:      	mov.d	x28, v23[1]
     dbc:      	ldr	s24, [x12]
     dc0:      	ld1.s	{ v24 }[1], [x11]
     dc4:      	ld1.s	{ v24 }[2], [x2]
     dc8:      	ld1.s	{ v24 }[3], [x0]
     dcc:      	fmov	x11, d23
     dd0:      	fmul.4s	v23, v24, v24
     dd4:      	fadd.4s	v18, v18, v23
     dd8:      	ldr	s23, [x26]
     ddc:      	ld1.s	{ v23 }[1], [x25]
     de0:      	ld1.s	{ v23 }[2], [x11]
     de4:      	ld1.s	{ v23 }[3], [x28]
     de8:      	fmul.4s	v23, v23, v23
     dec:      	fadd.4s	v17, v17, v23
     df0:      	add.2d	v22, v22, v28
     df4:      	add.2d	v21, v21, v27
     df8:      	mov.d	x11, v21[1]
     dfc:      	mov.d	x12, v22[1]
     e00:      	fmov	x0, d21
     e04:      	fmov	x2, d22
     e08:      	add.2d	v21, v15, v30
     e0c:      	add.2d	v2, v2, v29
     e10:      	mov.d	x25, v2[1]
     e14:      	fmov	x26, d2
     e18:      	mov.d	x28, v21[1]
     e1c:      	ldr	s2, [x0]
     e20:      	ld1.s	{ v2 }[1], [x11]
     e24:      	fmov	x11, d21
     e28:      	ld1.s	{ v2 }[2], [x2]
     e2c:      	ld1.s	{ v2 }[3], [x12]
     e30:      	fmul.4s	v2, v2, v2
     e34:      	fadd.4s	v9, v9, v2
     e38:      	ldr	s2, [x26]
     e3c:      	ld1.s	{ v2 }[1], [x25]
     e40:      	ld1.s	{ v2 }[2], [x11]
     e44:      	ld1.s	{ v2 }[3], [x28]
     e48:      	fmul.4s	v2, v2, v2
     e4c:      	fadd.4s	v10, v10, v2
     e50:      	dup.2d	v2, x13
     e54:      	add.2d	v13, v13, v2
     e58:      	add.2d	v12, v12, v2
     e5c:      	add.2d	v14, v14, v2
     e60:      	add.2d	v11, v11, v2
     e64:      	fmov	x11, d11
     e68:      	cmp	x11, #0x100
     e6c:      	b.lt	0xc9c <ltmp0+0xc9c>
     e70:      	mov	x12, #0x0               ; =0
     e74:      	movi.2d	v2, #0000000000000000
     e78:      	movi.2d	v21, #0000000000000000
     e7c:      	movi.2d	v22, #0000000000000000
     e80:      	movi.2d	v11, #0000000000000000
     e84:      	add	x11, x3, x12, lsl #5
     e88:      	ldp	q24, q23, [x11]
     e8c:      	shl.2d	v25, v2, #0x5
     e90:      	shl.2d	v12, v21, #0x5
     e94:      	shl.2d	v13, v22, #0x5
     e98:      	shl.2d	v14, v11, #0x5
     e9c:      	add.2d	v14, v14, v20
     ea0:      	add.2d	v14, v0, v14
     ea4:      	add.2d	v13, v13, v19
     ea8:      	add.2d	v12, v12, v4
     eac:      	add.2d	v25, v25, v3
     eb0:      	add.2d	v25, v0, v25
     eb4:      	mov.d	x11, v25[1]
     eb8:      	fmov	x12, d25
     ebc:      	str	s24, [x12]
     ec0:      	st1.s	{ v24 }[1], [x11]
     ec4:      	add.2d	v25, v0, v12
     ec8:      	mov.d	x11, v25[1]
     ecc:      	fmov	x12, d25
     ed0:      	st1.s	{ v24 }[2], [x12]
     ed4:      	add.2d	v25, v0, v13
     ed8:      	st1.s	{ v24 }[3], [x11]
     edc:      	mov.d	x11, v25[1]
     ee0:      	fmov	x12, d25
     ee4:      	str	s23, [x12]
     ee8:      	st1.s	{ v23 }[1], [x11]
     eec:      	mov.d	x11, v14[1]
     ef0:      	fmov	x12, d14
     ef4:      	st1.s	{ v23 }[2], [x12]
     ef8:      	st1.s	{ v23 }[3], [x11]
     efc:      	dup.2d	v23, x24
     f00:      	add.2d	v22, v22, v23
     f04:      	add.2d	v21, v21, v23
     f08:      	add.2d	v11, v11, v23
     f0c:      	add.2d	v2, v2, v23
     f10:      	fmov	x12, d2
     f14:      	cmp	x12, #0x100
     f18:      	b.lt	0xe84 <ltmp0+0xe84>
     f1c:      	mov	x0, #0x0                ; =0
     f20:      	ldr	q2, [sp, #0x1c0]
     f24:      	fmul.4s	v2, v2, v2
     f28:      	fadd.4s	v2, v2, v6
     f2c:      	mov.s	v2[3], v6[3]
     f30:      	fadd.4s	v5, v16, v5
     f34:      	fadd.4s	v2, v7, v2
     f38:      	fadd.4s	v2, v18, v2
     f3c:      	fadd.4s	v5, v17, v5
     f40:      	fadd.4s	v5, v10, v5
     f44:      	fadd.4s	v2, v9, v2
     f48:      	rev64.4s	v6, v2
     f4c:      	rev64.4s	v7, v5
     f50:      	fadd.4s	v2, v2, v6
     f54:      	dup.4s	v6, v2[2]
     f58:      	fadd.4s	v5, v5, v7
     f5c:      	dup.4s	v7, v5[2]
     f60:      	fadd.4s	v5, v5, v7
     f64:      	fadd.4s	v2, v2, v6
     f68:      	fadd.4s	v2, v2, v5
     f6c:      	movi	d5, #0000000000000000
     f70:      	fadd	s5, s2, s5
     f74:      	mov	w11, #0x3000            ; =12288
     f78:      	movk	w11, #0x4500, lsl #16
     f7c:      	fmov	s6, w11
     f80:      	add	x11, x27, #0x4
     f84:      	ldr	s2, [x27]
     f88:      	ld1.s	{ v2 }[1], [x11]
     f8c:      	add	x11, x27, #0x8
     f90:      	ld1.s	{ v2 }[2], [x11]
     f94:      	add	x11, sp, #0x550
     f98:      	add	x11, x11, x1
     f9c:      	ld1.s	{ v2 }[3], [x11]
     fa0:      	fdiv	s5, s5, s6
     fa4:      	mov	w11, #0xc5ac            ; =50604
     fa8:      	movk	w11, #0x3727, lsl #16
     fac:      	fmov	s6, w11
     fb0:      	fadd	s5, s5, s6
     fb4:      	fsqrt	s5, s5
     fb8:      	dup.4s	v6, v5[0]
     fbc:      	str	q2, [sp, #0x2550]
     fc0:      	add	x8, x4, x8
     fc4:      	movi.2d	v7, #0000000000000000
     fc8:      	movi.2d	v16, #0000000000000000
     fcc:      	movi.2d	v17, #0000000000000000
     fd0:      	movi.2d	v18, #0000000000000000
     fd4:      	shl.2d	v21, v18, #0x5
     fd8:      	shl.2d	v22, v17, #0x5
     fdc:      	shl.2d	v23, v16, #0x5
     fe0:      	shl.2d	v24, v7, #0x5
     fe4:      	orr.16b	v24, v24, v3
     fe8:      	orr.16b	v23, v23, v4
     fec:      	orr.16b	v22, v22, v19
     ff0:      	orr.16b	v21, v21, v20
     ff4:      	add.2d	v25, v1, v21
     ff8:      	add.2d	v9, v1, v22
     ffc:      	add.2d	v10, v1, v23
    1000:      	add.2d	v11, v1, v24
    1004:      	mov.d	x11, v11[1]
    1008:      	mov.d	x12, v10[1]
    100c:      	mov.d	x2, v9[1]
    1010:      	fmov	x25, d11
    1014:      	fmov	x26, d9
    1018:      	mov.d	x28, v25[1]
    101c:      	fmov	x30, d25
    1020:      	ldr	s25, [x26]
    1024:      	ld1.s	{ v25 }[1], [x2]
    1028:      	ld1.s	{ v25 }[2], [x30]
    102c:      	ld1.s	{ v25 }[3], [x28]
    1030:      	fmov	x2, d10
    1034:      	ldr	s9, [x25]
    1038:      	ld1.s	{ v9 }[1], [x11]
    103c:      	ld1.s	{ v9 }[2], [x2]
    1040:      	ld1.s	{ v9 }[3], [x12]
    1044:      	fdiv.4s	v9, v9, v6
    1048:      	fdiv.4s	v25, v25, v6
    104c:      	add.2d	v21, v0, v21
    1050:      	add.2d	v22, v0, v22
    1054:      	add.2d	v23, v0, v23
    1058:      	add.2d	v24, v0, v24
    105c:      	mov.d	x11, v24[1]
    1060:      	fmov	x12, d24
    1064:      	mov.d	x2, v23[1]
    1068:      	mov.d	x25, v22[1]
    106c:      	mov.d	x26, v21[1]
    1070:      	fmov	x28, d23
    1074:      	ldr	s23, [x12]
    1078:      	ld1.s	{ v23 }[1], [x11]
    107c:      	ld1.s	{ v23 }[2], [x28]
    1080:      	fmov	x11, d22
    1084:      	ld1.s	{ v23 }[3], [x2]
    1088:      	ldr	s22, [x11]
    108c:      	ld1.s	{ v22 }[1], [x25]
    1090:      	fmov	x11, d21
    1094:      	ld1.s	{ v22 }[2], [x11]
    1098:      	ld1.s	{ v22 }[3], [x26]
    109c:      	fmul.4s	v21, v25, v22
    10a0:      	fmul.4s	v22, v9, v23
    10a4:      	add	x11, x8, x0, lsl #5
    10a8:      	stp	q22, q21, [x11]
    10ac:      	dup.2d	v21, x24
    10b0:      	add.2d	v17, v17, v21
    10b4:      	add.2d	v16, v16, v21
    10b8:      	add.2d	v18, v18, v21
    10bc:      	add.2d	v7, v7, v21
    10c0:      	fmov	x0, d7
    10c4:      	cmp	x0, #0x100
    10c8:      	b.lt	0xfd4 <ltmp0+0xfd4>
    10cc:      	mov	x12, #0x0               ; =0
    10d0:      	ldr	q6, [sp, #0x4570]
    10d4:      	dup.4s	v5, v5[0]
    10d8:      	fdiv.4s	v5, v6, v5
    10dc:      	fmul.4s	v2, v2, v5
    10e0:      	add	x8, x4, x9
    10e4:      	str	d2, [x8], #0x8
    10e8:      	st1.s	{ v2 }[2], [x8]
    10ec:      	orr	w9, w6, #0x3
    10f0:      	umull	x8, w9, w1
    10f4:      	umaddl	x9, w9, w1, x5
    10f8:      	add	x11, x9, x12
    10fc:      	ldp	q2, q5, [x11]
    1100:      	add	x11, x10, x12
    1104:      	stp	q2, q5, [x11]
    1108:      	add	x12, x12, #0x20
    110c:      	cmp	x12, #0x2, lsl #12      ; =0x2000
    1110:      	b.ne	0x10f8 <ltmp0+0x10f8>
    1114:      	add	x9, x8, #0x2, lsl #12   ; =0x2000
    1118:      	add	x11, x5, x9
    111c:      	add	x12, x11, #0x4
    1120:      	add	x0, x11, #0x8
    1124:      	ldr	s2, [x11]
    1128:      	ld1.s	{ v2 }[1], [x12]
    112c:      	ld1.s	{ v2 }[2], [x0]
    1130:      	add	x11, x10, x1
    1134:      	str	q2, [sp, #0x1d0]
    1138:      	ld1.s	{ v2 }[3], [x11]
    113c:      	str	q2, [sp, #0x4570]
    1140:      	ldr	q2, [sp, #0x2570]
    1144:      	ldr	q5, [sp, #0x2580]
    1148:      	fmul.4s	v5, v5, v5
    114c:      	fmul.4s	v6, v2, v2
    1150:      	ldr	q2, [sp, #0x2590]
    1154:      	ldr	q7, [sp, #0x25a0]
    1158:      	fmul.4s	v16, v7, v7
    115c:      	fmul.4s	v7, v2, v2
    1160:      	ldr	q2, [sp, #0x25b0]
    1164:      	ldr	q17, [sp, #0x25c0]
    1168:      	fmul.4s	v17, v17, v17
    116c:      	fmul.4s	v18, v2, v2
    1170:      	ldr	q2, [sp, #0x25d0]
    1174:      	ldr	q21, [sp, #0x25e0]
    1178:      	fmul.4s	v10, v21, v21
    117c:      	fmul.4s	v9, v2, v2
    1180:      	dup.2d	v11, x13
    1184:      	mov.16b	v12, v11
    1188:      	mov.16b	v13, v11
    118c:      	mov.16b	v14, v11
    1190:      	ldp	q8, q31, [sp, #0x250]
    1194:      	ldp	q27, q26, [sp, #0x220]
    1198:      	ldp	q29, q28, [sp, #0x200]
    119c:      	ldr	q30, [sp, #0x1f0]
    11a0:      	shl.2d	v2, v11, #0x5
    11a4:      	shl.2d	v22, v12, #0x5
    11a8:      	shl.2d	v23, v13, #0x5
    11ac:      	shl.2d	v21, v14, #0x5
    11b0:      	add.2d	v15, v1, v21
    11b4:      	add.2d	v24, v15, v20
    11b8:      	add.2d	v21, v1, v2
    11bc:      	add.2d	v25, v21, v3
    11c0:      	mov.d	x11, v25[1]
    11c4:      	add.2d	v2, v1, v23
    11c8:      	add.2d	v22, v1, v22
    11cc:      	fmov	x12, d25
    11d0:      	add.2d	v23, v22, v4
    11d4:      	mov.d	x0, v23[1]
    11d8:      	fmov	x2, d23
    11dc:      	add.2d	v23, v2, v19
    11e0:      	mov.d	x25, v23[1]
    11e4:      	fmov	x26, d23
    11e8:      	mov.d	x28, v24[1]
    11ec:      	ldr	s23, [x12]
    11f0:      	ld1.s	{ v23 }[1], [x11]
    11f4:      	fmov	x11, d24
    11f8:      	ld1.s	{ v23 }[2], [x2]
    11fc:      	ld1.s	{ v23 }[3], [x0]
    1200:      	ldr	s24, [x26]
    1204:      	ld1.s	{ v24 }[1], [x25]
    1208:      	ld1.s	{ v24 }[2], [x11]
    120c:      	ld1.s	{ v24 }[3], [x28]
    1210:      	fmul.4s	v24, v24, v24
    1214:      	fmul.4s	v23, v23, v23
    1218:      	fadd.4s	v6, v6, v23
    121c:      	fadd.4s	v5, v5, v24
    1220:      	ldr	q23, [sp, #0x280]
    1224:      	add.2d	v23, v15, v23
    1228:      	ldr	q24, [sp, #0x2b0]
    122c:      	add.2d	v24, v21, v24
    1230:      	mov.d	x11, v24[1]
    1234:      	fmov	x12, d24
    1238:      	ldr	q24, [sp, #0x2a0]
    123c:      	add.2d	v24, v22, v24
    1240:      	mov.d	x0, v24[1]
    1244:      	fmov	x2, d24
    1248:      	ldr	q24, [sp, #0x290]
    124c:      	add.2d	v24, v2, v24
    1250:      	mov.d	x25, v24[1]
    1254:      	mov.d	x26, v23[1]
    1258:      	fmov	x28, d24
    125c:      	ldr	s24, [x12]
    1260:      	ld1.s	{ v24 }[1], [x11]
    1264:      	ld1.s	{ v24 }[2], [x2]
    1268:      	fmov	x11, d23
    126c:      	ld1.s	{ v24 }[3], [x0]
    1270:      	ldr	s23, [x28]
    1274:      	ld1.s	{ v23 }[1], [x25]
    1278:      	ld1.s	{ v23 }[2], [x11]
    127c:      	ld1.s	{ v23 }[3], [x26]
    1280:      	fmul.4s	v23, v23, v23
    1284:      	fmul.4s	v24, v24, v24
    1288:      	fadd.4s	v7, v7, v24
    128c:      	fadd.4s	v16, v16, v23
    1290:      	add.2d	v23, v15, v26
    1294:      	ldr	q24, [sp, #0x270]
    1298:      	add.2d	v24, v21, v24
    129c:      	mov.d	x11, v24[1]
    12a0:      	fmov	x12, d24
    12a4:      	add.2d	v24, v22, v31
    12a8:      	mov.d	x0, v24[1]
    12ac:      	fmov	x2, d24
    12b0:      	add.2d	v24, v2, v8
    12b4:      	mov.d	x25, v24[1]
    12b8:      	fmov	x26, d24
    12bc:      	mov.d	x28, v23[1]
    12c0:      	ldr	s24, [x12]
    12c4:      	ld1.s	{ v24 }[1], [x11]
    12c8:      	ld1.s	{ v24 }[2], [x2]
    12cc:      	ld1.s	{ v24 }[3], [x0]
    12d0:      	fmov	x11, d23
    12d4:      	fmul.4s	v23, v24, v24
    12d8:      	fadd.4s	v18, v18, v23
    12dc:      	ldr	s23, [x26]
    12e0:      	ld1.s	{ v23 }[1], [x25]
    12e4:      	ld1.s	{ v23 }[2], [x11]
    12e8:      	ld1.s	{ v23 }[3], [x28]
    12ec:      	fmul.4s	v23, v23, v23
    12f0:      	fadd.4s	v17, v17, v23
    12f4:      	add.2d	v22, v22, v28
    12f8:      	add.2d	v21, v21, v27
    12fc:      	mov.d	x11, v21[1]
    1300:      	mov.d	x12, v22[1]
    1304:      	fmov	x0, d21
    1308:      	fmov	x2, d22
    130c:      	add.2d	v21, v15, v30
    1310:      	add.2d	v2, v2, v29
    1314:      	mov.d	x25, v2[1]
    1318:      	fmov	x26, d2
    131c:      	mov.d	x28, v21[1]
    1320:      	ldr	s2, [x0]
    1324:      	ld1.s	{ v2 }[1], [x11]
    1328:      	fmov	x11, d21
    132c:      	ld1.s	{ v2 }[2], [x2]
    1330:      	ld1.s	{ v2 }[3], [x12]
    1334:      	fmul.4s	v2, v2, v2
    1338:      	fadd.4s	v9, v9, v2
    133c:      	ldr	s2, [x26]
    1340:      	ld1.s	{ v2 }[1], [x25]
    1344:      	ld1.s	{ v2 }[2], [x11]
    1348:      	ld1.s	{ v2 }[3], [x28]
    134c:      	fmul.4s	v2, v2, v2
    1350:      	fadd.4s	v10, v10, v2
    1354:      	dup.2d	v2, x13
    1358:      	add.2d	v13, v13, v2
    135c:      	add.2d	v12, v12, v2
    1360:      	add.2d	v14, v14, v2
    1364:      	add.2d	v11, v11, v2
    1368:      	fmov	x11, d11
    136c:      	cmp	x11, #0x100
    1370:      	b.lt	0x11a0 <ltmp0+0x11a0>
    1374:      	mov	x11, #0x0               ; =0
    1378:      	movi.2d	v2, #0000000000000000
    137c:      	movi.2d	v21, #0000000000000000
    1380:      	movi.2d	v22, #0000000000000000
    1384:      	movi.2d	v23, #0000000000000000
    1388:      	add	x11, x3, x11, lsl #5
    138c:      	ldp	q25, q24, [x11]
    1390:      	shl.2d	v26, v2, #0x5
    1394:      	shl.2d	v27, v21, #0x5
    1398:      	shl.2d	v28, v22, #0x5
    139c:      	shl.2d	v29, v23, #0x5
    13a0:      	add.2d	v29, v29, v20
    13a4:      	add.2d	v29, v0, v29
    13a8:      	add.2d	v28, v28, v19
    13ac:      	add.2d	v27, v27, v4
    13b0:      	add.2d	v26, v26, v3
    13b4:      	add.2d	v26, v0, v26
    13b8:      	mov.d	x11, v26[1]
    13bc:      	fmov	x12, d26
    13c0:      	str	s25, [x12]
    13c4:      	st1.s	{ v25 }[1], [x11]
    13c8:      	add.2d	v26, v0, v27
    13cc:      	mov.d	x11, v26[1]
    13d0:      	fmov	x12, d26
    13d4:      	st1.s	{ v25 }[2], [x12]
    13d8:      	add.2d	v26, v0, v28
    13dc:      	st1.s	{ v25 }[3], [x11]
    13e0:      	mov.d	x11, v26[1]
    13e4:      	fmov	x12, d26
    13e8:      	str	s24, [x12]
    13ec:      	st1.s	{ v24 }[1], [x11]
    13f0:      	mov.d	x11, v29[1]
    13f4:      	fmov	x12, d29
    13f8:      	st1.s	{ v24 }[2], [x12]
    13fc:      	st1.s	{ v24 }[3], [x11]
    1400:      	dup.2d	v24, x24
    1404:      	add.2d	v22, v22, v24
    1408:      	add.2d	v21, v21, v24
    140c:      	add.2d	v23, v23, v24
    1410:      	add.2d	v2, v2, v24
    1414:      	fmov	x11, d2
    1418:      	cmp	x11, #0x100
    141c:      	b.lt	0x1388 <ltmp0+0x1388>
    1420:      	mov	x11, #0x0               ; =0
    1424:      	ldr	q2, [sp, #0x1d0]
    1428:      	fmul.4s	v2, v2, v2
    142c:      	fadd.4s	v2, v2, v6
    1430:      	mov.s	v2[3], v6[3]
    1434:      	fadd.4s	v5, v16, v5
    1438:      	fadd.4s	v2, v7, v2
    143c:      	fadd.4s	v2, v18, v2
    1440:      	fadd.4s	v5, v17, v5
    1444:      	fadd.4s	v5, v10, v5
    1448:      	fadd.4s	v2, v9, v2
    144c:      	rev64.4s	v6, v2
    1450:      	rev64.4s	v7, v5
    1454:      	fadd.4s	v2, v2, v6
    1458:      	dup.4s	v6, v2[2]
    145c:      	fadd.4s	v5, v5, v7
    1460:      	dup.4s	v7, v5[2]
    1464:      	fadd.4s	v5, v5, v7
    1468:      	fadd.4s	v2, v2, v6
    146c:      	fadd.4s	v2, v2, v5
    1470:      	movi	d12, #0000000000000000
    1474:      	fadd	s5, s2, s12
    1478:      	mov	w12, #0x3000            ; =12288
    147c:      	movk	w12, #0x4500, lsl #16
    1480:      	fmov	s6, w12
    1484:      	add	x12, x27, #0x4
    1488:      	ldr	s2, [x27]
    148c:      	ld1.s	{ v2 }[1], [x12]
    1490:      	add	x12, x27, #0x8
    1494:      	ld1.s	{ v2 }[2], [x12]
    1498:      	add	x12, sp, #0x550
    149c:      	add	x12, x12, x1
    14a0:      	ld1.s	{ v2 }[3], [x12]
    14a4:      	fdiv	s5, s5, s6
    14a8:      	mov	w12, #0xc5ac            ; =50604
    14ac:      	movk	w12, #0x3727, lsl #16
    14b0:      	fmov	s6, w12
    14b4:      	fadd	s5, s5, s6
    14b8:      	fsqrt	s5, s5
    14bc:      	dup.4s	v6, v5[0]
    14c0:      	str	q2, [sp, #0x2550]
    14c4:      	add	x8, x4, x8
    14c8:      	movi.2d	v7, #0000000000000000
    14cc:      	movi.2d	v16, #0000000000000000
    14d0:      	movi.2d	v17, #0000000000000000
    14d4:      	movi.2d	v18, #0000000000000000
    14d8:      	shl.2d	v21, v18, #0x5
    14dc:      	shl.2d	v22, v17, #0x5
    14e0:      	shl.2d	v23, v16, #0x5
    14e4:      	shl.2d	v24, v7, #0x5
    14e8:      	orr.16b	v24, v24, v3
    14ec:      	orr.16b	v23, v23, v4
    14f0:      	orr.16b	v22, v22, v19
    14f4:      	orr.16b	v21, v21, v20
    14f8:      	add.2d	v25, v1, v21
    14fc:      	add.2d	v26, v1, v22
    1500:      	add.2d	v27, v1, v23
    1504:      	add.2d	v28, v1, v24
    1508:      	mov.d	x12, v28[1]
    150c:      	mov.d	x0, v27[1]
    1510:      	mov.d	x2, v26[1]
    1514:      	fmov	x3, d28
    1518:      	fmov	x25, d26
    151c:      	mov.d	x26, v25[1]
    1520:      	fmov	x27, d25
    1524:      	ldr	s25, [x25]
    1528:      	ld1.s	{ v25 }[1], [x2]
    152c:      	ld1.s	{ v25 }[2], [x27]
    1530:      	ld1.s	{ v25 }[3], [x26]
    1534:      	fmov	x2, d27
    1538:      	ldr	s26, [x3]
    153c:      	ld1.s	{ v26 }[1], [x12]
    1540:      	ld1.s	{ v26 }[2], [x2]
    1544:      	ld1.s	{ v26 }[3], [x0]
    1548:      	fdiv.4s	v26, v26, v6
    154c:      	fdiv.4s	v25, v25, v6
    1550:      	add.2d	v21, v0, v21
    1554:      	add.2d	v22, v0, v22
    1558:      	add.2d	v23, v0, v23
    155c:      	add.2d	v24, v0, v24
    1560:      	mov.d	x12, v24[1]
    1564:      	fmov	x0, d24
    1568:      	mov.d	x2, v23[1]
    156c:      	mov.d	x3, v22[1]
    1570:      	mov.d	x25, v21[1]
    1574:      	fmov	x26, d23
    1578:      	ldr	s23, [x0]
    157c:      	ld1.s	{ v23 }[1], [x12]
    1580:      	ld1.s	{ v23 }[2], [x26]
    1584:      	fmov	x12, d22
    1588:      	ld1.s	{ v23 }[3], [x2]
    158c:      	ldr	s22, [x12]
    1590:      	ld1.s	{ v22 }[1], [x3]
    1594:      	fmov	x12, d21
    1598:      	ld1.s	{ v22 }[2], [x12]
    159c:      	ld1.s	{ v22 }[3], [x25]
    15a0:      	fmul.4s	v21, v25, v22
    15a4:      	fmul.4s	v22, v26, v23
    15a8:      	add	x11, x8, x11, lsl #5
    15ac:      	stp	q22, q21, [x11]
    15b0:      	dup.2d	v21, x24
    15b4:      	add.2d	v17, v17, v21
    15b8:      	add.2d	v16, v16, v21
    15bc:      	add.2d	v18, v18, v21
    15c0:      	add.2d	v7, v7, v21
    15c4:      	fmov	x11, d7
    15c8:      	cmp	x11, #0x100
    15cc:      	b.lt	0x14d8 <ltmp0+0x14d8>
    15d0:      	ldr	q6, [sp, #0x4570]
    15d4:      	dup.4s	v5, v5[0]
    15d8:      	fdiv.4s	v5, v6, v5
    15dc:      	fmul.4s	v2, v2, v5
    15e0:      	add	x8, x4, x9
    15e4:      	str	d2, [x8], #0x8
    15e8:      	st1.s	{ v2 }[2], [x8]
    15ec:      	adrp	x1, 0x1000 <ltmp0+0x1000>
    15f0:      	adrp	x4, 0x1000 <ltmp0+0x1000>
    15f4:      	adrp	x5, 0x1000 <ltmp0+0x1000>
    15f8:      	adrp	x6, 0x1000 <ltmp0+0x1000>
    15fc:      	adrp	x7, 0x1000 <ltmp0+0x1000>
    1600:      	adrp	x19, 0x1000 <ltmp0+0x1000>
    1604:      	adrp	x20, 0x1000 <ltmp0+0x1000>
    1608:      	adrp	x21, 0x1000 <ltmp0+0x1000>
    160c:      	adrp	x22, 0x1000 <ltmp0+0x1000>
    1610:      	adrp	x23, 0x1000 <ltmp0+0x1000>
    1614:      	ldr	w0, [sp, #0x154]
    1618:      	ldr	w2, [sp, #0x150]
    161c:      	ldr	x25, [sp, #0x158]
    1620:      	b	0xd0 <ltmp0+0xd0>
    1624:      	str	w14, [sp, #0x14c]
    1628:      	lsr	x8, x9, #3
    162c:      	str	x8, [sp, #0x2b0]
    1630:      	str	x9, [sp, #0x270]
    1634:      	cmp	x9, #0x8
    1638:      	mov	w14, #0x200c            ; =8204
    163c:      	b.lo	0x1bf8 <ltmp0+0x1bf8>
    1640:      	mov	x3, #0x0                ; =0
    1644:      	ldr	x8, [sp, #0x130]
    1648:      	ldr	x11, [x8]
    164c:      	ldr	x27, [x8, #0x10]
    1650:      	ldr	x15, [x8, #0x30]
    1654:      	add	x25, x27, #0x2, lsl #12 ; =0x2000
    1658:      	ldr	x8, [sp, #0x158]
    165c:      	lsl	w9, w8, #2
    1660:      	str	x9, [sp, #0x290]
    1664:      	and	x8, x8, #0x7ffffff
    1668:      	mov	w9, #0x8030             ; =32816
    166c:      	str	x11, [sp, #0x2a0]
    1670:      	umaddl	x9, w8, w9, x11
    1674:      	str	x15, [sp, #0x280]
    1678:      	mov	x12, #0x0               ; =0
    167c:      	ldr	x8, [sp, #0x290]
    1680:      	add	w8, w3, w8
    1684:      	and	x8, x8, #0x1fffffff
    1688:      	umull	x8, w8, w14
    168c:      	add	x30, x9, x12
    1690:      	ldp	q2, q5, [x30]
    1694:      	add	x30, x10, x12
    1698:      	stp	q2, q5, [x30]
    169c:      	add	x12, x12, #0x20
    16a0:      	cmp	x12, #0x2, lsl #12      ; =0x2000
    16a4:      	b.ne	0x168c <ltmp0+0x168c>
    16a8:      	add	x30, x8, #0x2, lsl #12  ; =0x2000
    16ac:      	ldr	x11, [sp, #0x2a0]
    16b0:      	add	x12, x11, x30
    16b4:      	add	x11, x12, #0x4
    16b8:      	add	x2, x12, #0x8
    16bc:      	ldr	s6, [x12]
    16c0:      	ld1.s	{ v6 }[1], [x11]
    16c4:      	ld1.s	{ v6 }[2], [x2]
    16c8:      	add	x11, x10, x14
    16cc:      	mov.16b	v2, v6
    16d0:      	ld1.s	{ v2 }[3], [x11]
    16d4:      	str	q2, [sp, #0x4570]
    16d8:      	ldr	q2, [sp, #0x2570]
    16dc:      	ldr	q5, [sp, #0x2580]
    16e0:      	fmul.4s	v7, v5, v5
    16e4:      	fmul.4s	v16, v2, v2
    16e8:      	ldr	q2, [sp, #0x2590]
    16ec:      	ldr	q5, [sp, #0x25a0]
    16f0:      	fmul.4s	v18, v5, v5
    16f4:      	fmul.4s	v17, v2, v2
    16f8:      	ldr	q2, [sp, #0x25b0]
    16fc:      	ldr	q5, [sp, #0x25c0]
    1700:      	fmul.4s	v19, v5, v5
    1704:      	fmul.4s	v20, v2, v2
    1708:      	ldr	q2, [sp, #0x25d0]
    170c:      	ldr	q5, [sp, #0x25e0]
    1710:      	fmul.4s	v22, v5, v5
    1714:      	fmul.4s	v21, v2, v2
    1718:      	dup.2d	v23, x13
    171c:      	mov.16b	v24, v23
    1720:      	mov.16b	v25, v23
    1724:      	mov.16b	v26, v23
    1728:      	adrp	x17, 0x1000 <ltmp0+0x1000>
    172c:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    1730:      	adrp	x1, 0x1000 <ltmp0+0x1000>
    1734:      	adrp	x4, 0x1000 <ltmp0+0x1000>
    1738:      	adrp	x5, 0x1000 <ltmp0+0x1000>
    173c:      	adrp	x6, 0x1000 <ltmp0+0x1000>
    1740:      	adrp	x7, 0x1000 <ltmp0+0x1000>
    1744:      	adrp	x19, 0x1000 <ltmp0+0x1000>
    1748:      	adrp	x20, 0x1000 <ltmp0+0x1000>
    174c:      	adrp	x21, 0x1000 <ltmp0+0x1000>
    1750:      	adrp	x22, 0x1000 <ltmp0+0x1000>
    1754:      	adrp	x23, 0x1000 <ltmp0+0x1000>
    1758:      	adrp	x0, 0x1000 <ltmp0+0x1000>
    175c:      	mov	w10, #0x4               ; =4
    1760:      	adrp	x13, 0x1000 <ltmp0+0x1000>
    1764:      	shl.2d	v2, v23, #0x5
    1768:      	add.2d	v27, v1, v2
    176c:      	add.2d	v31, v27, v3
    1770:      	mov.d	x11, v31[1]
    1774:      	shl.2d	v2, v24, #0x5
    1778:      	add.2d	v28, v1, v2
    177c:      	add.2d	v8, v28, v4
    1780:      	mov.d	x12, v8[1]
    1784:      	ldr	q2, [x17]
    1788:      	shl.2d	v5, v25, #0x5
    178c:      	add.2d	v29, v1, v5
    1790:      	add.2d	v9, v29, v2
    1794:      	mov.d	x2, v9[1]
    1798:      	ldr	q5, [x1]
    179c:      	shl.2d	v30, v26, #0x5
    17a0:      	add.2d	v30, v1, v30
    17a4:      	add.2d	v10, v30, v5
    17a8:      	mov.d	x28, v10[1]
    17ac:      	fmov	x26, d31
    17b0:      	ldr	s31, [x26]
    17b4:      	fmov	x26, d8
    17b8:      	fmov	x16, d9
    17bc:      	ld1.s	{ v31 }[1], [x11]
    17c0:      	fmov	x11, d10
    17c4:      	ld1.s	{ v31 }[2], [x26]
    17c8:      	ld1.s	{ v31 }[3], [x12]
    17cc:      	ldr	s8, [x16]
    17d0:      	ld1.s	{ v8 }[1], [x2]
    17d4:      	ld1.s	{ v8 }[2], [x11]
    17d8:      	ld1.s	{ v8 }[3], [x28]
    17dc:      	fmul.4s	v8, v8, v8
    17e0:      	fmul.4s	v31, v31, v31
    17e4:      	fadd.4s	v16, v16, v31
    17e8:      	fadd.4s	v7, v7, v8
    17ec:      	ldr	q31, [x15]
    17f0:      	ldr	q8, [x4]
    17f4:      	ldr	q9, [x5]
    17f8:      	ldr	q10, [x6]
    17fc:      	add.2d	v10, v30, v10
    1800:      	add.2d	v9, v29, v9
    1804:      	add.2d	v8, v28, v8
    1808:      	add.2d	v31, v27, v31
    180c:      	mov.d	x11, v31[1]
    1810:      	fmov	x12, d31
    1814:      	mov.d	x16, v8[1]
    1818:      	fmov	x2, d8
    181c:      	mov.d	x26, v9[1]
    1820:      	fmov	x28, d9
    1824:      	mov.d	x14, v10[1]
    1828:      	ldr	s31, [x12]
    182c:      	ld1.s	{ v31 }[1], [x11]
    1830:      	ld1.s	{ v31 }[2], [x2]
    1834:      	ld1.s	{ v31 }[3], [x16]
    1838:      	fmov	x11, d10
    183c:      	ldr	s8, [x28]
    1840:      	ld1.s	{ v8 }[1], [x26]
    1844:      	ld1.s	{ v8 }[2], [x11]
    1848:      	ld1.s	{ v8 }[3], [x14]
    184c:      	fmul.4s	v8, v8, v8
    1850:      	fmul.4s	v31, v31, v31
    1854:      	fadd.4s	v17, v17, v31
    1858:      	fadd.4s	v18, v18, v8
    185c:      	ldr	q31, [x7]
    1860:      	ldr	q8, [x19]
    1864:      	ldr	q9, [x20]
    1868:      	ldr	q10, [x21]
    186c:      	add.2d	v10, v30, v10
    1870:      	add.2d	v9, v29, v9
    1874:      	add.2d	v8, v28, v8
    1878:      	add.2d	v31, v27, v31
    187c:      	mov.d	x11, v31[1]
    1880:      	mov.d	x12, v8[1]
    1884:      	fmov	x14, d31
    1888:      	fmov	x16, d8
    188c:      	mov.d	x2, v9[1]
    1890:      	mov.d	x26, v10[1]
    1894:      	fmov	x28, d9
    1898:      	ldr	s31, [x14]
    189c:      	ld1.s	{ v31 }[1], [x11]
    18a0:      	ld1.s	{ v31 }[2], [x16]
    18a4:      	fmov	x11, d10
    18a8:      	ld1.s	{ v31 }[3], [x12]
    18ac:      	ldr	s8, [x28]
    18b0:      	ld1.s	{ v8 }[1], [x2]
    18b4:      	ld1.s	{ v8 }[2], [x11]
    18b8:      	ld1.s	{ v8 }[3], [x26]
    18bc:      	fmul.4s	v8, v8, v8
    18c0:      	fmul.4s	v31, v31, v31
    18c4:      	fadd.4s	v20, v20, v31
    18c8:      	fadd.4s	v19, v19, v8
    18cc:      	ldr	q31, [x22]
    18d0:      	ldr	q8, [x23]
    18d4:      	ldr	q9, [x0]
    18d8:      	ldr	q10, [x13]
    18dc:      	add.2d	v30, v30, v10
    18e0:      	add.2d	v29, v29, v9
    18e4:      	add.2d	v28, v28, v8
    18e8:      	add.2d	v27, v27, v31
    18ec:      	mov.d	x11, v27[1]
    18f0:      	fmov	x12, d27
    18f4:      	mov.d	x14, v28[1]
    18f8:      	fmov	x16, d28
    18fc:      	mov.d	x2, v29[1]
    1900:      	fmov	x26, d29
    1904:      	mov.d	x28, v30[1]
    1908:      	ldr	s27, [x12]
    190c:      	ld1.s	{ v27 }[1], [x11]
    1910:      	fmov	x11, d30
    1914:      	ld1.s	{ v27 }[2], [x16]
    1918:      	ld1.s	{ v27 }[3], [x14]
    191c:      	ldr	s28, [x26]
    1920:      	ld1.s	{ v28 }[1], [x2]
    1924:      	ld1.s	{ v28 }[2], [x11]
    1928:      	ld1.s	{ v28 }[3], [x28]
    192c:      	fmul.4s	v28, v28, v28
    1930:      	fmul.4s	v27, v27, v27
    1934:      	fadd.4s	v21, v21, v27
    1938:      	fadd.4s	v22, v22, v28
    193c:      	dup.2d	v27, x10
    1940:      	add.2d	v25, v25, v27
    1944:      	add.2d	v24, v24, v27
    1948:      	add.2d	v26, v26, v27
    194c:      	add.2d	v23, v23, v27
    1950:      	fmov	x11, d23
    1954:      	cmp	x11, #0x100
    1958:      	b.lt	0x1764 <ltmp0+0x1764>
    195c:      	mov	x12, #0x0               ; =0
    1960:      	movi.2d	v23, #0000000000000000
    1964:      	movi.2d	v24, #0000000000000000
    1968:      	movi.2d	v25, #0000000000000000
    196c:      	movi.2d	v26, #0000000000000000
    1970:      	add	x11, x27, x12, lsl #5
    1974:      	ldp	q28, q27, [x11]
    1978:      	shl.2d	v29, v23, #0x5
    197c:      	shl.2d	v30, v24, #0x5
    1980:      	shl.2d	v31, v25, #0x5
    1984:      	shl.2d	v8, v26, #0x5
    1988:      	add.2d	v8, v8, v5
    198c:      	add.2d	v8, v0, v8
    1990:      	add.2d	v31, v31, v2
    1994:      	add.2d	v30, v30, v4
    1998:      	add.2d	v29, v29, v3
    199c:      	add.2d	v29, v0, v29
    19a0:      	mov.d	x11, v29[1]
    19a4:      	fmov	x12, d29
    19a8:      	str	s28, [x12]
    19ac:      	st1.s	{ v28 }[1], [x11]
    19b0:      	add.2d	v29, v0, v30
    19b4:      	mov.d	x11, v29[1]
    19b8:      	fmov	x12, d29
    19bc:      	st1.s	{ v28 }[2], [x12]
    19c0:      	add.2d	v29, v0, v31
    19c4:      	st1.s	{ v28 }[3], [x11]
    19c8:      	mov.d	x11, v29[1]
    19cc:      	fmov	x12, d29
    19d0:      	str	s27, [x12]
    19d4:      	st1.s	{ v27 }[1], [x11]
    19d8:      	mov.d	x11, v8[1]
    19dc:      	fmov	x12, d8
    19e0:      	st1.s	{ v27 }[2], [x12]
    19e4:      	st1.s	{ v27 }[3], [x11]
    19e8:      	dup.2d	v27, x24
    19ec:      	add.2d	v25, v25, v27
    19f0:      	add.2d	v24, v24, v27
    19f4:      	add.2d	v26, v26, v27
    19f8:      	add.2d	v23, v23, v27
    19fc:      	fmov	x12, d23
    1a00:      	cmp	x12, #0x100
    1a04:      	b.lt	0x1970 <ltmp0+0x1970>
    1a08:      	mov	x12, #0x0               ; =0
    1a0c:      	fmul.4s	v6, v6, v6
    1a10:      	fadd.4s	v6, v6, v16
    1a14:      	mov.s	v6[3], v16[3]
    1a18:      	fadd.4s	v7, v18, v7
    1a1c:      	fadd.4s	v6, v17, v6
    1a20:      	fadd.4s	v6, v20, v6
    1a24:      	fadd.4s	v7, v19, v7
    1a28:      	fadd.4s	v7, v22, v7
    1a2c:      	fadd.4s	v6, v21, v6
    1a30:      	rev64.4s	v16, v6
    1a34:      	rev64.4s	v17, v7
    1a38:      	fadd.4s	v6, v6, v16
    1a3c:      	dup.4s	v16, v6[2]
    1a40:      	fadd.4s	v7, v7, v17
    1a44:      	dup.4s	v17, v7[2]
    1a48:      	fadd.4s	v7, v7, v17
    1a4c:      	fadd.4s	v6, v6, v16
    1a50:      	fadd.4s	v6, v6, v7
    1a54:      	fadd	s7, s6, s12
    1a58:      	mov	w10, #0x3000            ; =12288
    1a5c:      	movk	w10, #0x4500, lsl #16
    1a60:      	fmov	s16, w10
    1a64:      	add	x11, x25, #0x4
    1a68:      	ldr	s6, [x25]
    1a6c:      	ld1.s	{ v6 }[1], [x11]
    1a70:      	add	x11, x25, #0x8
    1a74:      	ld1.s	{ v6 }[2], [x11]
    1a78:      	add	x11, sp, #0x550
    1a7c:      	mov	w10, #0x200c            ; =8204
    1a80:      	add	x11, x11, x10
    1a84:      	ld1.s	{ v6 }[3], [x11]
    1a88:      	fdiv	s7, s7, s16
    1a8c:      	mov	w10, #0xc5ac            ; =50604
    1a90:      	movk	w10, #0x3727, lsl #16
    1a94:      	fmov	s16, w10
    1a98:      	fadd	s7, s7, s16
    1a9c:      	fsqrt	s7, s7
    1aa0:      	dup.4s	v16, v7[0]
    1aa4:      	str	q6, [sp, #0x2550]
    1aa8:      	ldr	x15, [sp, #0x280]
    1aac:      	add	x8, x15, x8
    1ab0:      	movi.2d	v17, #0000000000000000
    1ab4:      	movi.2d	v18, #0000000000000000
    1ab8:      	movi.2d	v19, #0000000000000000
    1abc:      	movi.2d	v20, #0000000000000000
    1ac0:      	mov	w13, #0x4               ; =4
    1ac4:      	add	x10, sp, #0x2, lsl #12  ; =0x2000
    1ac8:      	add	x10, x10, #0x570
    1acc:      	shl.2d	v21, v20, #0x5
    1ad0:      	shl.2d	v22, v19, #0x5
    1ad4:      	shl.2d	v23, v18, #0x5
    1ad8:      	shl.2d	v24, v17, #0x5
    1adc:      	orr.16b	v24, v24, v3
    1ae0:      	orr.16b	v23, v23, v4
    1ae4:      	orr.16b	v22, v22, v2
    1ae8:      	orr.16b	v21, v21, v5
    1aec:      	add.2d	v25, v1, v21
    1af0:      	add.2d	v26, v1, v22
    1af4:      	add.2d	v27, v1, v23
    1af8:      	add.2d	v28, v1, v24
    1afc:      	mov.d	x11, v28[1]
    1b00:      	mov.d	x14, v27[1]
    1b04:      	mov.d	x16, v26[1]
    1b08:      	fmov	x2, d28
    1b0c:      	fmov	x26, d26
    1b10:      	mov.d	x28, v25[1]
    1b14:      	fmov	x17, d25
    1b18:      	ldr	s25, [x26]
    1b1c:      	ld1.s	{ v25 }[1], [x16]
    1b20:      	ld1.s	{ v25 }[2], [x17]
    1b24:      	ld1.s	{ v25 }[3], [x28]
    1b28:      	fmov	x16, d27
    1b2c:      	ldr	s26, [x2]
    1b30:      	ld1.s	{ v26 }[1], [x11]
    1b34:      	ld1.s	{ v26 }[2], [x16]
    1b38:      	ld1.s	{ v26 }[3], [x14]
    1b3c:      	fdiv.4s	v26, v26, v16
    1b40:      	fdiv.4s	v25, v25, v16
    1b44:      	add.2d	v21, v0, v21
    1b48:      	add.2d	v22, v0, v22
    1b4c:      	add.2d	v23, v0, v23
    1b50:      	add.2d	v24, v0, v24
    1b54:      	mov.d	x11, v24[1]
    1b58:      	fmov	x14, d24
    1b5c:      	mov.d	x16, v23[1]
    1b60:      	mov.d	x17, v22[1]
    1b64:      	mov.d	x2, v21[1]
    1b68:      	fmov	x26, d23
    1b6c:      	ldr	s23, [x14]
    1b70:      	ld1.s	{ v23 }[1], [x11]
    1b74:      	ld1.s	{ v23 }[2], [x26]
    1b78:      	fmov	x11, d22
    1b7c:      	ld1.s	{ v23 }[3], [x16]
    1b80:      	ldr	s22, [x11]
    1b84:      	ld1.s	{ v22 }[1], [x17]
    1b88:      	fmov	x11, d21
    1b8c:      	ld1.s	{ v22 }[2], [x11]
    1b90:      	ld1.s	{ v22 }[3], [x2]
    1b94:      	fmul.4s	v21, v25, v22
    1b98:      	fmul.4s	v22, v26, v23
    1b9c:      	add	x11, x8, x12, lsl #5
    1ba0:      	stp	q22, q21, [x11]
    1ba4:      	dup.2d	v21, x24
    1ba8:      	add.2d	v19, v19, v21
    1bac:      	add.2d	v18, v18, v21
    1bb0:      	add.2d	v20, v20, v21
    1bb4:      	add.2d	v17, v17, v21
    1bb8:      	fmov	x12, d17
    1bbc:      	cmp	x12, #0x100
    1bc0:      	b.lt	0x1acc <ltmp0+0x1acc>
    1bc4:      	ldr	q2, [sp, #0x4570]
    1bc8:      	dup.4s	v5, v7[0]
    1bcc:      	fdiv.4s	v2, v2, v5
    1bd0:      	fmul.4s	v2, v6, v2
    1bd4:      	add	x8, x15, x30
    1bd8:      	str	d2, [x8], #0x8
    1bdc:      	st1.s	{ v2 }[2], [x8]
    1be0:      	add	x3, x3, #0x1
    1be4:      	mov	w14, #0x200c            ; =8204
    1be8:      	add	x9, x9, x14
    1bec:      	ldr	x8, [sp, #0x2b0]
    1bf0:      	cmp	x3, x8
    1bf4:      	b.ne	0x1678 <ltmp0+0x1678>
    1bf8:      	mov	w3, #0x200c             ; =8204
    1bfc:      	ldr	x8, [sp, #0x270]
    1c00:      	and	w8, w8, #0x7
    1c04:      	ldr	w14, [sp, #0x14c]
    1c08:      	adrp	x16, 0x1000 <ltmp0+0x1000>
    1c0c:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    1c10:      	adrp	x17, 0x1000 <ltmp0+0x1000>
    1c14:      	adrp	x1, 0x1000 <ltmp0+0x1000>
    1c18:      	adrp	x4, 0x1000 <ltmp0+0x1000>
    1c1c:      	adrp	x5, 0x1000 <ltmp0+0x1000>
    1c20:      	adrp	x6, 0x1000 <ltmp0+0x1000>
    1c24:      	adrp	x7, 0x1000 <ltmp0+0x1000>
    1c28:      	adrp	x19, 0x1000 <ltmp0+0x1000>
    1c2c:      	adrp	x20, 0x1000 <ltmp0+0x1000>
    1c30:      	adrp	x21, 0x1000 <ltmp0+0x1000>
    1c34:      	adrp	x22, 0x1000 <ltmp0+0x1000>
    1c38:      	adrp	x23, 0x1000 <ltmp0+0x1000>
    1c3c:      	ldr	w0, [sp, #0x154]
    1c40:      	ldr	w2, [sp, #0x150]
    1c44:      	ldr	x25, [sp, #0x158]
    1c48:      	cbz	w8, 0xd0 <ltmp0+0xd0>
    1c4c:      	dup.4s	v2, w8
    1c50:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1c54:      	ldr	q5, [x8]
    1c58:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1c5c:      	ldr	q6, [x8]
    1c60:      	cmhi.4s	v6, v2, v6
    1c64:      	cmhi.4s	v16, v2, v5
    1c68:      	uzp1.8h	v7, v16, v6
    1c6c:      	umaxv.8h	h2, v7
    1c70:      	fmov	w8, s2
    1c74:      	tbz	w8, #0x0, 0xd0 <ltmp0+0xd0>
    1c78:      	mov	x9, #0x0                ; =0
    1c7c:      	ldr	x12, [sp, #0x130]
    1c80:      	ldr	x8, [x12]
    1c84:      	ldr	x11, [x12, #0x10]
    1c88:      	ldr	x1, [x12, #0x30]
    1c8c:      	adrp	x12, 0x1000 <ltmp0+0x1000>
    1c90:      	ldr	q2, [x12]
    1c94:      	and.16b	v2, v7, v2
    1c98:      	addv.8h	h19, v2
    1c9c:      	ubfiz	w12, w25, #2, #27
    1ca0:      	ldr	x14, [sp, #0x2b0]
    1ca4:      	orr	w12, w12, w14
    1ca8:      	fmov	w14, s19
    1cac:      	and	w4, w14, #0xff
    1cb0:      	dup.4s	v2, w12
    1cb4:      	and.16b	v17, v16, v2
    1cb8:      	and.16b	v5, v6, v2
    1cbc:      	ushll2.2d	v2, v5, #0x0
    1cc0:      	ushll2.2d	v18, v17, #0x0
    1cc4:      	ushll.2d	v5, v5, #0x0
    1cc8:      	ushll.2d	v21, v17, #0x0
    1ccc:      	fmov	x12, d21
    1cd0:      	umaddl	x12, w12, w3, x8
    1cd4:      	b	0x1cf8 <ltmp0+0x1cf8>
    1cd8:      	add	x14, x10, x9
    1cdc:      	ldp	q22, q23, [x14]
    1ce0:      	bif.16b	v20, v23, v6
    1ce4:      	bif.16b	v17, v22, v16
    1ce8:      	stp	q17, q20, [x14]
    1cec:      	add	x9, x9, #0x20
    1cf0:      	cmp	x9, #0x2, lsl #12       ; =0x2000
    1cf4:      	b.eq	0x1d90 <ltmp0+0x1d90>
    1cf8:      	fmov	w2, s19
    1cfc:      	add	x0, x12, x9
    1d00:      	movi.2d	v17, #0000000000000000
    1d04:      	movi.2d	v20, #0000000000000000
    1d08:      	tbnz	w2, #0x0, 0x1d30 <ltmp0+0x1d30>
    1d0c:      	and	w2, w2, #0xff
    1d10:      	tbnz	w2, #0x1, 0x1d3c <ltmp0+0x1d3c>
    1d14:      	tbnz	w2, #0x2, 0x1d48 <ltmp0+0x1d48>
    1d18:      	tbnz	w2, #0x3, 0x1d54 <ltmp0+0x1d54>
    1d1c:      	tbnz	w2, #0x4, 0x1d60 <ltmp0+0x1d60>
    1d20:      	tbnz	w2, #0x5, 0x1d6c <ltmp0+0x1d6c>
    1d24:      	tbnz	w2, #0x6, 0x1d78 <ltmp0+0x1d78>
    1d28:      	tbz	w2, #0x7, 0x1cd8 <ltmp0+0x1cd8>
    1d2c:      	b	0x1d84 <ltmp0+0x1d84>
    1d30:      	ldr	s17, [x0]
    1d34:      	and	w2, w2, #0xff
    1d38:      	tbz	w2, #0x1, 0x1d14 <ltmp0+0x1d14>
    1d3c:      	add	x14, x0, #0x4
    1d40:      	ld1.s	{ v17 }[1], [x14]
    1d44:      	tbz	w2, #0x2, 0x1d18 <ltmp0+0x1d18>
    1d48:      	add	x14, x0, #0x8
    1d4c:      	ld1.s	{ v17 }[2], [x14]
    1d50:      	tbz	w2, #0x3, 0x1d1c <ltmp0+0x1d1c>
    1d54:      	add	x14, x0, #0xc
    1d58:      	ld1.s	{ v17 }[3], [x14]
    1d5c:      	tbz	w2, #0x4, 0x1d20 <ltmp0+0x1d20>
    1d60:      	add	x14, x0, #0x10
    1d64:      	ld1.s	{ v20 }[0], [x14]
    1d68:      	tbz	w2, #0x5, 0x1d24 <ltmp0+0x1d24>
    1d6c:      	add	x14, x0, #0x14
    1d70:      	ld1.s	{ v20 }[1], [x14]
    1d74:      	tbz	w2, #0x6, 0x1d28 <ltmp0+0x1d28>
    1d78:      	add	x14, x0, #0x18
    1d7c:      	ld1.s	{ v20 }[2], [x14]
    1d80:      	tbz	w2, #0x7, 0x1cd8 <ltmp0+0x1cd8>
    1d84:      	add	x14, x0, #0x1c
    1d88:      	ld1.s	{ v20 }[3], [x14]
    1d8c:      	b	0x1cd8 <ltmp0+0x1cd8>
    1d90:      	xtn.8b	v20, v7
    1d94:      	sshll.2d	v7, v16, #0x0
    1d98:      	sshll2.2d	v22, v16, #0x0
    1d9c:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1da0:      	ldr	q17, [x9]
    1da4:      	str	q22, [sp, #0x230]
    1da8:      	and.16b	v23, v22, v17
    1dac:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1db0:      	ldr	q17, [x9]
    1db4:      	and.16b	v22, v7, v17
    1db8:      	movi	d17, #0x00000000ffffff
    1dbc:      	and.8b	v24, v20, v17
    1dc0:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1dc4:      	ldr	d17, [x9]
    1dc8:      	str	q20, [sp, #0x90]
    1dcc:      	and.8b	v17, v20, v17
    1dd0:      	addv.8b	b17, v17
    1dd4:      	fmov	w9, s17
    1dd8:      	umaxv.8b	b17, v24
    1ddc:      	fmov	w12, s17
    1de0:      	rbit	w14, w9
    1de4:      	clz	w14, w14
    1de8:      	tst	w12, #0x1
    1dec:      	mov	w12, #0x800             ; =2048
    1df0:      	dup.2d	v20, x12
    1df4:      	csel	w26, w14, wzr, ne
    1df8:      	stp	q22, q23, [sp, #0x50]
    1dfc:      	orr.16b	v22, v22, v20
    1e00:      	orr.16b	v23, v23, v20
    1e04:      	mov	w12, #0x803             ; =2051
    1e08:      	dup.2s	v17, w12
    1e0c:      	xtn.2s	v21, v21
    1e10:      	xtn.2s	v18, v18
    1e14:      	str	q23, [sp, #0xc0]
    1e18:      	umlal.2d	v23, v18, v17
    1e1c:      	str	q22, [sp, #0xa0]
    1e20:      	umlal.2d	v22, v21, v17
    1e24:      	mov	b18, v24[0]
    1e28:      	mov.b	v18[4], v24[1]
    1e2c:      	ushll.2d	v18, v18, #0x0
    1e30:      	shl.2d	v18, v18, #0x3f
    1e34:      	cmlt.2d	v18, v18, #0
    1e38:      	stp	q22, q23, [sp, #0xf0]
    1e3c:      	and.16b	v18, v18, v22
    1e40:      	mov	b22, v24[2]
    1e44:      	mov.b	v22[4], v24[3]
    1e48:      	ushll.2d	v22, v22, #0x0
    1e4c:      	shl.2d	v22, v22, #0x3f
    1e50:      	cmlt.2d	v22, v22, #0
    1e54:      	and.16b	v22, v22, v23
    1e58:      	movi.2d	v23, #0000000000000000
    1e5c:      	str	q23, [sp, #0x530]
    1e60:      	str	q23, [sp, #0x520]
    1e64:      	str	q22, [sp, #0x510]
    1e68:      	str	q18, [sp, #0x500]
    1e6c:      	and	x12, x26, #0x7
    1e70:      	add	x14, sp, #0x500
    1e74:      	ldr	x12, [x14, x12, lsl #3]
    1e78:      	sub	x12, x12, x26
    1e7c:      	add	x8, x8, x12, lsl #2
    1e80:      	movi.2d	v27, #0000000000000000
    1e84:      	movi.2d	v28, #0000000000000000
    1e88:      	tbnz	w9, #0x0, 0x2f94 <ltmp0+0x2f94>
    1e8c:      	tbnz	w9, #0x1, 0x2f9c <ltmp0+0x2f9c>
    1e90:      	tbnz	w9, #0x2, 0x2fa8 <ltmp0+0x2fa8>
    1e94:      	tbnz	w9, #0x3, 0x2fb4 <ltmp0+0x2fb4>
    1e98:      	tbnz	w9, #0x4, 0x2fc0 <ltmp0+0x2fc0>
    1e9c:      	tbnz	w9, #0x5, 0x2fcc <ltmp0+0x2fcc>
    1ea0:      	tbnz	w9, #0x6, 0x2fd8 <ltmp0+0x2fd8>
    1ea4:      	tbz	w9, #0x7, 0x1eb0 <ltmp0+0x1eb0>
    1ea8:      	add	x8, x8, #0x1c
    1eac:      	ld1.s	{ v28 }[3], [x8]
    1eb0:      	sshll.2d	v18, v6, #0x0
    1eb4:      	sshll2.2d	v8, v6, #0x0
    1eb8:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1ebc:      	ldr	q22, [x8]
    1ec0:      	and.16b	v29, v8, v22
    1ec4:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1ec8:      	ldr	q22, [x8]
    1ecc:      	and.16b	v30, v18, v22
    1ed0:      	and.16b	v23, v18, v1
    1ed4:      	and.16b	v22, v7, v1
    1ed8:      	stp	q22, q23, [sp, #0x2a0]
    1edc:      	ldr	q22, [x15]
    1ee0:      	and.16b	v23, v8, v22
    1ee4:      	ldr	q31, [sp, #0x230]
    1ee8:      	and.16b	v25, v31, v4
    1eec:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1ef0:      	ldr	q22, [x8]
    1ef4:      	and.16b	v18, v18, v22
    1ef8:      	and.16b	v26, v7, v3
    1efc:      	stp	q30, q29, [sp, #0x10]
    1f00:      	orr.16b	v22, v30, v20
    1f04:      	orr.16b	v20, v29, v20
    1f08:      	umull.2d	v7, v21, v17
    1f0c:      	str	q7, [sp, #0xb0]
    1f10:      	xtn.2s	v5, v5
    1f14:      	xtn.2s	v2, v2
    1f18:      	stp	q22, q20, [sp, #0x70]
    1f1c:      	mov.16b	v7, v20
    1f20:      	umlal.2d	v7, v2, v17
    1f24:      	mov.16b	v2, v22
    1f28:      	umlal.2d	v2, v5, v17
    1f2c:      	stp	q2, q7, [sp, #0xd0]
    1f30:      	str	q26, [sp, #0x4c0]
    1f34:      	str	q25, [sp, #0x4d0]
    1f38:      	str	q18, [sp, #0x4e0]
    1f3c:      	str	q23, [sp, #0x4f0]
    1f40:      	and	x8, x26, #0x7
    1f44:      	add	x12, sp, #0x4c0
    1f48:      	ldr	x8, [x12, x8, lsl #3]
    1f4c:      	orr	x8, x8, #0x2000
    1f50:      	sub	x8, x8, x26, lsl #2
    1f54:      	tst	w9, #0xff
    1f58:      	csel	x3, xzr, x8, eq
    1f5c:      	add	x8, x10, x3
    1f60:      	ldp	q2, q5, [x8]
    1f64:      	zip2.8b	v7, v24, v0
    1f68:      	ushll.4s	v7, v7, #0x0
    1f6c:      	shl.4s	v7, v7, #0x1f
    1f70:      	cmlt.4s	v7, v7, #0
    1f74:      	stp	q28, q27, [sp, #0x30]
    1f78:      	bit.16b	v5, v28, v7
    1f7c:      	str	q24, [sp, #0x110]
    1f80:      	zip1.8b	v7, v24, v0
    1f84:      	ushll.4s	v7, v7, #0x0
    1f88:      	shl.4s	v7, v7, #0x1f
    1f8c:      	cmlt.4s	v7, v7, #0
    1f90:      	bit.16b	v2, v27, v7
    1f94:      	stp	q2, q5, [x8]
    1f98:      	mov	w8, #0x20               ; =32
    1f9c:      	dup.2d	v2, x8
    1fa0:      	orr.16b	v7, v18, v2
    1fa4:      	orr.16b	v5, v25, v2
    1fa8:      	stp	q5, q7, [sp, #0x200]
    1fac:      	orr.16b	v5, v26, v2
    1fb0:      	orr.16b	v2, v23, v2
    1fb4:      	stp	q2, q5, [sp, #0x1e0]
    1fb8:      	mov	w8, #0x40               ; =64
    1fbc:      	dup.2d	v2, x8
    1fc0:      	orr.16b	v7, v18, v2
    1fc4:      	orr.16b	v5, v25, v2
    1fc8:      	stp	q5, q7, [sp, #0x1c0]
    1fcc:      	orr.16b	v5, v26, v2
    1fd0:      	orr.16b	v2, v23, v2
    1fd4:      	stp	q2, q5, [sp, #0x1a0]
    1fd8:      	mov	w8, #0x60               ; =96
    1fdc:      	dup.2d	v2, x8
    1fe0:      	stp	q18, q25, [sp, #0x260]
    1fe4:      	orr.16b	v7, v18, v2
    1fe8:      	orr.16b	v5, v25, v2
    1fec:      	stp	q5, q7, [sp, #0x180]
    1ff0:      	orr.16b	v5, v26, v2
    1ff4:      	str	q23, [sp, #0x280]
    1ff8:      	orr.16b	v2, v23, v2
    1ffc:      	stp	q2, q5, [sp, #0x160]
    2000:      	ldr	q2, [sp, #0x25e0]
    2004:      	ldr	q5, [sp, #0x25d0]
    2008:      	fmul.4s	v5, v5, v5
    200c:      	fmul.4s	v2, v2, v2
    2010:      	and.16b	v21, v6, v2
    2014:      	and.16b	v22, v16, v5
    2018:      	ldr	q2, [sp, #0x25c0]
    201c:      	ldr	q5, [sp, #0x25b0]
    2020:      	fmul.4s	v5, v5, v5
    2024:      	fmul.4s	v2, v2, v2
    2028:      	and.16b	v7, v6, v2
    202c:      	and.16b	v15, v16, v5
    2030:      	ldr	q2, [sp, #0x25a0]
    2034:      	ldr	q5, [sp, #0x2590]
    2038:      	fmul.4s	v5, v5, v5
    203c:      	fmul.4s	v2, v2, v2
    2040:      	and.16b	v13, v6, v2
    2044:      	and.16b	v14, v16, v5
    2048:      	str	q26, [sp, #0x250]
    204c:      	fmov	x8, d26
    2050:      	add	x8, x10, x8
    2054:      	ldp	q2, q5, [x8]
    2058:      	fmul.4s	v2, v2, v2
    205c:      	fmul.4s	v5, v5, v5
    2060:      	and.16b	v24, v6, v5
    2064:      	and.16b	v23, v16, v2
    2068:      	sshll.2d	v2, v6, #0x0
    206c:      	dup.2d	v17, x13
    2070:      	and.16b	v5, v2, v17
    2074:      	sshll.2d	v2, v16, #0x0
    2078:      	and.16b	v12, v2, v17
    207c:      	and.16b	v20, v8, v17
    2080:      	and.16b	v2, v31, v17
    2084:      	str	q8, [sp, #0x220]
    2088:      	and.16b	v17, v8, v1
    208c:      	str	q17, [sp, #0x290]
    2090:      	and.16b	v8, v31, v1
    2094:      	b	0x2138 <ltmp0+0x2138>
    2098:      	fmul.4s	v17, v9, v9
    209c:      	fmul.4s	v18, v18, v18
    20a0:      	fadd.4s	v27, v23, v18
    20a4:      	fadd.4s	v30, v24, v17
    20a8:      	fmul.4s	v17, v29, v29
    20ac:      	fmul.4s	v18, v28, v28
    20b0:      	fadd.4s	v18, v14, v18
    20b4:      	fadd.4s	v17, v13, v17
    20b8:      	fmul.4s	v26, v26, v26
    20bc:      	fmul.4s	v25, v25, v25
    20c0:      	fadd.4s	v25, v15, v25
    20c4:      	fadd.4s	v26, v7, v26
    20c8:      	sshll.2d	v28, v16, #0x0
    20cc:      	sshll.2d	v29, v6, #0x0
    20d0:      	fmul.4s	v9, v10, v10
    20d4:      	fmul.4s	v31, v31, v31
    20d8:      	fadd.4s	v31, v21, v31
    20dc:      	fadd.4s	v9, v22, v9
    20e0:      	dup.2d	v10, x13
    20e4:      	ldr	q11, [sp, #0x220]
    20e8:      	and.16b	v11, v11, v10
    20ec:      	add.2d	v20, v20, v11
    20f0:      	ldr	q11, [sp, #0x230]
    20f4:      	and.16b	v11, v11, v10
    20f8:      	add.2d	v2, v2, v11
    20fc:      	and.16b	v29, v29, v10
    2100:      	add.2d	v5, v5, v29
    2104:      	and.16b	v28, v28, v10
    2108:      	add.2d	v12, v12, v28
    210c:      	bit.16b	v24, v30, v6
    2110:      	bit.16b	v23, v27, v16
    2114:      	bit.16b	v13, v17, v6
    2118:      	bit.16b	v14, v18, v16
    211c:      	bit.16b	v7, v26, v6
    2120:      	bit.16b	v15, v25, v16
    2124:      	bit.16b	v22, v9, v16
    2128:      	bit.16b	v21, v31, v6
    212c:      	fmov	x8, d12
    2130:      	cmp	x8, #0x100
    2134:      	b.ge	0x2540 <ltmp0+0x2540>
    2138:      	fmov	w8, s19
    213c:      	shl.2d	v10, v12, #0x5
    2140:      	ldr	q17, [sp, #0x250]
    2144:      	orr.16b	v17, v10, v17
    2148:      	ldr	q18, [sp, #0x2a0]
    214c:      	add.2d	v17, v18, v17
    2150:      	movi.2d	v18, #0000000000000000
    2154:      	movi.2d	v9, #0000000000000000
    2158:      	tbnz	w8, #0x0, 0x2310 <ltmp0+0x2310>
    215c:      	and	w8, w8, #0xff
    2160:      	tbnz	w8, #0x1, 0x2320 <ltmp0+0x2320>
    2164:      	shl.2d	v11, v2, #0x5
    2168:      	ldr	q17, [sp, #0x270]
    216c:      	orr.16b	v17, v11, v17
    2170:      	add.2d	v17, v8, v17
    2174:      	tbnz	w8, #0x2, 0x233c <ltmp0+0x233c>
    2178:      	tbnz	w8, #0x3, 0x2348 <ltmp0+0x2348>
    217c:      	shl.2d	v17, v5, #0x5
    2180:      	ldr	q25, [sp, #0x260]
    2184:      	orr.16b	v25, v17, v25
    2188:      	ldr	q26, [sp, #0x2b0]
    218c:      	add.2d	v25, v26, v25
    2190:      	tbnz	w8, #0x4, 0x2368 <ltmp0+0x2368>
    2194:      	tbnz	w8, #0x5, 0x2374 <ltmp0+0x2374>
    2198:      	shl.2d	v27, v20, #0x5
    219c:      	ldp	q25, q26, [sp, #0x280]
    21a0:      	orr.16b	v25, v27, v25
    21a4:      	add.2d	v25, v26, v25
    21a8:      	tbnz	w8, #0x6, 0x2390 <ltmp0+0x2390>
    21ac:      	tbz	w8, #0x7, 0x21b8 <ltmp0+0x21b8>
    21b0:      	mov.d	x8, v25[1]
    21b4:      	ld1.s	{ v9 }[3], [x8]
    21b8:      	fmov	w8, s19
    21bc:      	ldr	q25, [sp, #0x1f0]
    21c0:      	add.2d	v25, v25, v10
    21c4:      	ldr	q26, [sp, #0x2a0]
    21c8:      	add.2d	v25, v26, v25
    21cc:      	movi.2d	v28, #0000000000000000
    21d0:      	movi.2d	v29, #0000000000000000
    21d4:      	tbnz	w8, #0x0, 0x23a0 <ltmp0+0x23a0>
    21d8:      	and	w8, w8, #0xff
    21dc:      	tbnz	w8, #0x1, 0x23b0 <ltmp0+0x23b0>
    21e0:      	ldr	q25, [sp, #0x200]
    21e4:      	add.2d	v25, v25, v11
    21e8:      	add.2d	v25, v8, v25
    21ec:      	tbnz	w8, #0x2, 0x23c8 <ltmp0+0x23c8>
    21f0:      	tbnz	w8, #0x3, 0x23d4 <ltmp0+0x23d4>
    21f4:      	ldr	q25, [sp, #0x210]
    21f8:      	add.2d	v25, v25, v17
    21fc:      	ldr	q26, [sp, #0x2b0]
    2200:      	add.2d	v25, v26, v25
    2204:      	tbnz	w8, #0x4, 0x23f0 <ltmp0+0x23f0>
    2208:      	tbnz	w8, #0x5, 0x23fc <ltmp0+0x23fc>
    220c:      	ldr	q25, [sp, #0x1e0]
    2210:      	add.2d	v25, v25, v27
    2214:      	ldr	q26, [sp, #0x290]
    2218:      	add.2d	v25, v26, v25
    221c:      	tbnz	w8, #0x6, 0x2418 <ltmp0+0x2418>
    2220:      	tbz	w8, #0x7, 0x222c <ltmp0+0x222c>
    2224:      	mov.d	x8, v25[1]
    2228:      	ld1.s	{ v29 }[3], [x8]
    222c:      	fmov	w8, s19
    2230:      	ldr	q25, [sp, #0x1b0]
    2234:      	add.2d	v25, v25, v10
    2238:      	ldr	q26, [sp, #0x2a0]
    223c:      	add.2d	v30, v26, v25
    2240:      	movi.2d	v25, #0000000000000000
    2244:      	movi.2d	v26, #0000000000000000
    2248:      	tbnz	w8, #0x0, 0x2428 <ltmp0+0x2428>
    224c:      	and	w8, w8, #0xff
    2250:      	tbnz	w8, #0x1, 0x2438 <ltmp0+0x2438>
    2254:      	ldr	q30, [sp, #0x1c0]
    2258:      	add.2d	v30, v30, v11
    225c:      	add.2d	v30, v8, v30
    2260:      	tbnz	w8, #0x2, 0x2450 <ltmp0+0x2450>
    2264:      	tbnz	w8, #0x3, 0x245c <ltmp0+0x245c>
    2268:      	ldr	q30, [sp, #0x1d0]
    226c:      	add.2d	v30, v30, v17
    2270:      	ldr	q31, [sp, #0x2b0]
    2274:      	add.2d	v30, v31, v30
    2278:      	tbnz	w8, #0x4, 0x2478 <ltmp0+0x2478>
    227c:      	tbnz	w8, #0x5, 0x2484 <ltmp0+0x2484>
    2280:      	ldr	q30, [sp, #0x1a0]
    2284:      	add.2d	v30, v30, v27
    2288:      	ldr	q31, [sp, #0x290]
    228c:      	add.2d	v30, v31, v30
    2290:      	tbnz	w8, #0x6, 0x24a0 <ltmp0+0x24a0>
    2294:      	tbz	w8, #0x7, 0x22a0 <ltmp0+0x22a0>
    2298:      	mov.d	x8, v30[1]
    229c:      	ld1.s	{ v26 }[3], [x8]
    22a0:      	fmov	w8, s19
    22a4:      	ldr	q30, [sp, #0x170]
    22a8:      	add.2d	v30, v30, v10
    22ac:      	ldr	q31, [sp, #0x2a0]
    22b0:      	add.2d	v30, v31, v30
    22b4:      	movi.2d	v10, #0000000000000000
    22b8:      	movi.2d	v31, #0000000000000000
    22bc:      	tbnz	w8, #0x0, 0x24b0 <ltmp0+0x24b0>
    22c0:      	and	w8, w8, #0xff
    22c4:      	tbnz	w8, #0x1, 0x24c0 <ltmp0+0x24c0>
    22c8:      	ldr	q30, [sp, #0x180]
    22cc:      	add.2d	v30, v30, v11
    22d0:      	add.2d	v30, v8, v30
    22d4:      	tbnz	w8, #0x2, 0x24d8 <ltmp0+0x24d8>
    22d8:      	tbnz	w8, #0x3, 0x24e4 <ltmp0+0x24e4>
    22dc:      	ldr	q30, [sp, #0x190]
    22e0:      	add.2d	v17, v30, v17
    22e4:      	ldr	q30, [sp, #0x2b0]
    22e8:      	add.2d	v17, v30, v17
    22ec:      	tbnz	w8, #0x4, 0x2500 <ltmp0+0x2500>
    22f0:      	tbnz	w8, #0x5, 0x250c <ltmp0+0x250c>
    22f4:      	ldr	q17, [sp, #0x160]
    22f8:      	add.2d	v17, v17, v27
    22fc:      	ldr	q27, [sp, #0x290]
    2300:      	add.2d	v17, v27, v17
    2304:      	tbnz	w8, #0x6, 0x2528 <ltmp0+0x2528>
    2308:      	tbz	w8, #0x7, 0x2098 <ltmp0+0x2098>
    230c:      	b	0x2534 <ltmp0+0x2534>
    2310:      	fmov	x9, d17
    2314:      	ldr	s18, [x9]
    2318:      	and	w8, w8, #0xff
    231c:      	tbz	w8, #0x1, 0x2164 <ltmp0+0x2164>
    2320:      	mov.d	x9, v17[1]
    2324:      	ld1.s	{ v18 }[1], [x9]
    2328:      	shl.2d	v11, v2, #0x5
    232c:      	ldr	q17, [sp, #0x270]
    2330:      	orr.16b	v17, v11, v17
    2334:      	add.2d	v17, v8, v17
    2338:      	tbz	w8, #0x2, 0x2178 <ltmp0+0x2178>
    233c:      	fmov	x9, d17
    2340:      	ld1.s	{ v18 }[2], [x9]
    2344:      	tbz	w8, #0x3, 0x217c <ltmp0+0x217c>
    2348:      	mov.d	x9, v17[1]
    234c:      	ld1.s	{ v18 }[3], [x9]
    2350:      	shl.2d	v17, v5, #0x5
    2354:      	ldr	q25, [sp, #0x260]
    2358:      	orr.16b	v25, v17, v25
    235c:      	ldr	q26, [sp, #0x2b0]
    2360:      	add.2d	v25, v26, v25
    2364:      	tbz	w8, #0x4, 0x2194 <ltmp0+0x2194>
    2368:      	fmov	x9, d25
    236c:      	ld1.s	{ v9 }[0], [x9]
    2370:      	tbz	w8, #0x5, 0x2198 <ltmp0+0x2198>
    2374:      	mov.d	x9, v25[1]
    2378:      	ld1.s	{ v9 }[1], [x9]
    237c:      	shl.2d	v27, v20, #0x5
    2380:      	ldp	q25, q26, [sp, #0x280]
    2384:      	orr.16b	v25, v27, v25
    2388:      	add.2d	v25, v26, v25
    238c:      	tbz	w8, #0x6, 0x21ac <ltmp0+0x21ac>
    2390:      	fmov	x9, d25
    2394:      	ld1.s	{ v9 }[2], [x9]
    2398:      	tbnz	w8, #0x7, 0x21b0 <ltmp0+0x21b0>
    239c:      	b	0x21b8 <ltmp0+0x21b8>
    23a0:      	fmov	x9, d25
    23a4:      	ldr	s28, [x9]
    23a8:      	and	w8, w8, #0xff
    23ac:      	tbz	w8, #0x1, 0x21e0 <ltmp0+0x21e0>
    23b0:      	mov.d	x9, v25[1]
    23b4:      	ld1.s	{ v28 }[1], [x9]
    23b8:      	ldr	q25, [sp, #0x200]
    23bc:      	add.2d	v25, v25, v11
    23c0:      	add.2d	v25, v8, v25
    23c4:      	tbz	w8, #0x2, 0x21f0 <ltmp0+0x21f0>
    23c8:      	fmov	x9, d25
    23cc:      	ld1.s	{ v28 }[2], [x9]
    23d0:      	tbz	w8, #0x3, 0x21f4 <ltmp0+0x21f4>
    23d4:      	mov.d	x9, v25[1]
    23d8:      	ld1.s	{ v28 }[3], [x9]
    23dc:      	ldr	q25, [sp, #0x210]
    23e0:      	add.2d	v25, v25, v17
    23e4:      	ldr	q26, [sp, #0x2b0]
    23e8:      	add.2d	v25, v26, v25
    23ec:      	tbz	w8, #0x4, 0x2208 <ltmp0+0x2208>
    23f0:      	fmov	x9, d25
    23f4:      	ld1.s	{ v29 }[0], [x9]
    23f8:      	tbz	w8, #0x5, 0x220c <ltmp0+0x220c>
    23fc:      	mov.d	x9, v25[1]
    2400:      	ld1.s	{ v29 }[1], [x9]
    2404:      	ldr	q25, [sp, #0x1e0]
    2408:      	add.2d	v25, v25, v27
    240c:      	ldr	q26, [sp, #0x290]
    2410:      	add.2d	v25, v26, v25
    2414:      	tbz	w8, #0x6, 0x2220 <ltmp0+0x2220>
    2418:      	fmov	x9, d25
    241c:      	ld1.s	{ v29 }[2], [x9]
    2420:      	tbnz	w8, #0x7, 0x2224 <ltmp0+0x2224>
    2424:      	b	0x222c <ltmp0+0x222c>
    2428:      	fmov	x9, d30
    242c:      	ldr	s25, [x9]
    2430:      	and	w8, w8, #0xff
    2434:      	tbz	w8, #0x1, 0x2254 <ltmp0+0x2254>
    2438:      	mov.d	x9, v30[1]
    243c:      	ld1.s	{ v25 }[1], [x9]
    2440:      	ldr	q30, [sp, #0x1c0]
    2444:      	add.2d	v30, v30, v11
    2448:      	add.2d	v30, v8, v30
    244c:      	tbz	w8, #0x2, 0x2264 <ltmp0+0x2264>
    2450:      	fmov	x9, d30
    2454:      	ld1.s	{ v25 }[2], [x9]
    2458:      	tbz	w8, #0x3, 0x2268 <ltmp0+0x2268>
    245c:      	mov.d	x9, v30[1]
    2460:      	ld1.s	{ v25 }[3], [x9]
    2464:      	ldr	q30, [sp, #0x1d0]
    2468:      	add.2d	v30, v30, v17
    246c:      	ldr	q31, [sp, #0x2b0]
    2470:      	add.2d	v30, v31, v30
    2474:      	tbz	w8, #0x4, 0x227c <ltmp0+0x227c>
    2478:      	fmov	x9, d30
    247c:      	ld1.s	{ v26 }[0], [x9]
    2480:      	tbz	w8, #0x5, 0x2280 <ltmp0+0x2280>
    2484:      	mov.d	x9, v30[1]
    2488:      	ld1.s	{ v26 }[1], [x9]
    248c:      	ldr	q30, [sp, #0x1a0]
    2490:      	add.2d	v30, v30, v27
    2494:      	ldr	q31, [sp, #0x290]
    2498:      	add.2d	v30, v31, v30
    249c:      	tbz	w8, #0x6, 0x2294 <ltmp0+0x2294>
    24a0:      	fmov	x9, d30
    24a4:      	ld1.s	{ v26 }[2], [x9]
    24a8:      	tbnz	w8, #0x7, 0x2298 <ltmp0+0x2298>
    24ac:      	b	0x22a0 <ltmp0+0x22a0>
    24b0:      	fmov	x9, d30
    24b4:      	ldr	s10, [x9]
    24b8:      	and	w8, w8, #0xff
    24bc:      	tbz	w8, #0x1, 0x22c8 <ltmp0+0x22c8>
    24c0:      	mov.d	x9, v30[1]
    24c4:      	ld1.s	{ v10 }[1], [x9]
    24c8:      	ldr	q30, [sp, #0x180]
    24cc:      	add.2d	v30, v30, v11
    24d0:      	add.2d	v30, v8, v30
    24d4:      	tbz	w8, #0x2, 0x22d8 <ltmp0+0x22d8>
    24d8:      	fmov	x9, d30
    24dc:      	ld1.s	{ v10 }[2], [x9]
    24e0:      	tbz	w8, #0x3, 0x22dc <ltmp0+0x22dc>
    24e4:      	mov.d	x9, v30[1]
    24e8:      	ld1.s	{ v10 }[3], [x9]
    24ec:      	ldr	q30, [sp, #0x190]
    24f0:      	add.2d	v17, v30, v17
    24f4:      	ldr	q30, [sp, #0x2b0]
    24f8:      	add.2d	v17, v30, v17
    24fc:      	tbz	w8, #0x4, 0x22f0 <ltmp0+0x22f0>
    2500:      	fmov	x9, d17
    2504:      	ld1.s	{ v31 }[0], [x9]
    2508:      	tbz	w8, #0x5, 0x22f4 <ltmp0+0x22f4>
    250c:      	mov.d	x9, v17[1]
    2510:      	ld1.s	{ v31 }[1], [x9]
    2514:      	ldr	q17, [sp, #0x160]
    2518:      	add.2d	v17, v17, v27
    251c:      	ldr	q27, [sp, #0x290]
    2520:      	add.2d	v17, v27, v17
    2524:      	tbz	w8, #0x6, 0x2308 <ltmp0+0x2308>
    2528:      	fmov	x9, d17
    252c:      	ld1.s	{ v31 }[2], [x9]
    2530:      	tbz	w8, #0x7, 0x2098 <ltmp0+0x2098>
    2534:      	mov.d	x8, v17[1]
    2538:      	ld1.s	{ v31 }[3], [x8]
    253c:      	b	0x2098 <ltmp0+0x2098>
    2540:      	mov	x8, #0x0                ; =0
    2544:      	ldp	q5, q2, [sp, #0x220]
    2548:      	and.16b	v17, v5, v0
    254c:      	and.16b	v18, v2, v0
    2550:      	sshll.2d	v2, v6, #0x0
    2554:      	and.16b	v10, v2, v0
    2558:      	sshll.2d	v2, v16, #0x0
    255c:      	and.16b	v9, v2, v0
    2560:      	dup.2d	v5, x24
    2564:      	ushll2.2d	v2, v6, #0x0
    2568:      	and.16b	v11, v2, v5
    256c:      	ushll2.2d	v2, v16, #0x0
    2570:      	and.16b	v2, v2, v5
    2574:      	ushll.2d	v6, v6, #0x0
    2578:      	and.16b	v6, v6, v5
    257c:      	ushll.2d	v16, v16, #0x0
    2580:      	and.16b	v16, v16, v5
    2584:      	movi.2d	v5, #0000000000000000
    2588:      	movi.2d	v20, #0000000000000000
    258c:      	movi.2d	v25, #0000000000000000
    2590:      	movi.2d	v26, #0000000000000000
    2594:      	b	0x25b4 <ltmp0+0x25b4>
    2598:      	add.2d	v20, v20, v2
    259c:      	add.2d	v25, v25, v6
    25a0:      	add.2d	v26, v26, v11
    25a4:      	add.2d	v5, v5, v16
    25a8:      	fmov	x8, d5
    25ac:      	cmp	x8, #0x100
    25b0:      	b.ge	0x275c <ltmp0+0x275c>
    25b4:      	fmov	w9, s19
    25b8:      	add	x8, x11, x8, lsl #5
    25bc:      	movi.2d	v29, #0000000000000000
    25c0:      	movi.2d	v28, #0000000000000000
    25c4:      	tbnz	w9, #0x0, 0x2654 <ltmp0+0x2654>
    25c8:      	and	w9, w9, #0xff
    25cc:      	tbnz	w9, #0x1, 0x2660 <ltmp0+0x2660>
    25d0:      	tbnz	w9, #0x2, 0x266c <ltmp0+0x266c>
    25d4:      	tbnz	w9, #0x3, 0x2678 <ltmp0+0x2678>
    25d8:      	tbnz	w9, #0x4, 0x2684 <ltmp0+0x2684>
    25dc:      	tbnz	w9, #0x5, 0x2690 <ltmp0+0x2690>
    25e0:      	tbnz	w9, #0x6, 0x269c <ltmp0+0x269c>
    25e4:      	tbnz	w9, #0x7, 0x26a8 <ltmp0+0x26a8>
    25e8:      	fmov	w8, s19
    25ec:      	shl.2d	v31, v5, #0x5
    25f0:      	ldr	q12, [sp, #0x250]
    25f4:      	orr.16b	v31, v31, v12
    25f8:      	add.2d	v31, v9, v31
    25fc:      	tbnz	w8, #0x0, 0x26c8 <ltmp0+0x26c8>
    2600:      	and	w8, w8, #0xff
    2604:      	tbnz	w8, #0x1, 0x26d8 <ltmp0+0x26d8>
    2608:      	shl.2d	v31, v20, #0x5
    260c:      	ldr	q12, [sp, #0x270]
    2610:      	orr.16b	v31, v31, v12
    2614:      	add.2d	v31, v18, v31
    2618:      	tbnz	w8, #0x2, 0x26f4 <ltmp0+0x26f4>
    261c:      	tbnz	w8, #0x3, 0x2700 <ltmp0+0x2700>
    2620:      	shl.2d	v29, v25, #0x5
    2624:      	ldr	q31, [sp, #0x260]
    2628:      	orr.16b	v29, v29, v31
    262c:      	add.2d	v29, v10, v29
    2630:      	tbnz	w8, #0x4, 0x271c <ltmp0+0x271c>
    2634:      	tbnz	w8, #0x5, 0x2728 <ltmp0+0x2728>
    2638:      	shl.2d	v29, v26, #0x5
    263c:      	ldr	q31, [sp, #0x280]
    2640:      	orr.16b	v29, v29, v31
    2644:      	add.2d	v29, v17, v29
    2648:      	tbnz	w8, #0x6, 0x2744 <ltmp0+0x2744>
    264c:      	tbz	w8, #0x7, 0x2598 <ltmp0+0x2598>
    2650:      	b	0x2750 <ltmp0+0x2750>
    2654:      	ldr	s29, [x8]
    2658:      	and	w9, w9, #0xff
    265c:      	tbz	w9, #0x1, 0x25d0 <ltmp0+0x25d0>
    2660:      	add	x12, x8, #0x4
    2664:      	ld1.s	{ v29 }[1], [x12]
    2668:      	tbz	w9, #0x2, 0x25d4 <ltmp0+0x25d4>
    266c:      	add	x12, x8, #0x8
    2670:      	ld1.s	{ v29 }[2], [x12]
    2674:      	tbz	w9, #0x3, 0x25d8 <ltmp0+0x25d8>
    2678:      	add	x12, x8, #0xc
    267c:      	ld1.s	{ v29 }[3], [x12]
    2680:      	tbz	w9, #0x4, 0x25dc <ltmp0+0x25dc>
    2684:      	add	x12, x8, #0x10
    2688:      	ld1.s	{ v28 }[0], [x12]
    268c:      	tbz	w9, #0x5, 0x25e0 <ltmp0+0x25e0>
    2690:      	add	x12, x8, #0x14
    2694:      	ld1.s	{ v28 }[1], [x12]
    2698:      	tbz	w9, #0x6, 0x25e4 <ltmp0+0x25e4>
    269c:      	add	x12, x8, #0x18
    26a0:      	ld1.s	{ v28 }[2], [x12]
    26a4:      	tbz	w9, #0x7, 0x25e8 <ltmp0+0x25e8>
    26a8:      	add	x8, x8, #0x1c
    26ac:      	ld1.s	{ v28 }[3], [x8]
    26b0:      	fmov	w8, s19
    26b4:      	shl.2d	v31, v5, #0x5
    26b8:      	ldr	q12, [sp, #0x250]
    26bc:      	orr.16b	v31, v31, v12
    26c0:      	add.2d	v31, v9, v31
    26c4:      	tbz	w8, #0x0, 0x2600 <ltmp0+0x2600>
    26c8:      	fmov	x9, d31
    26cc:      	str	s29, [x9]
    26d0:      	and	w8, w8, #0xff
    26d4:      	tbz	w8, #0x1, 0x2608 <ltmp0+0x2608>
    26d8:      	mov.d	x9, v31[1]
    26dc:      	st1.s	{ v29 }[1], [x9]
    26e0:      	shl.2d	v31, v20, #0x5
    26e4:      	ldr	q12, [sp, #0x270]
    26e8:      	orr.16b	v31, v31, v12
    26ec:      	add.2d	v31, v18, v31
    26f0:      	tbz	w8, #0x2, 0x261c <ltmp0+0x261c>
    26f4:      	fmov	x9, d31
    26f8:      	st1.s	{ v29 }[2], [x9]
    26fc:      	tbz	w8, #0x3, 0x2620 <ltmp0+0x2620>
    2700:      	mov.d	x9, v31[1]
    2704:      	st1.s	{ v29 }[3], [x9]
    2708:      	shl.2d	v29, v25, #0x5
    270c:      	ldr	q31, [sp, #0x260]
    2710:      	orr.16b	v29, v29, v31
    2714:      	add.2d	v29, v10, v29
    2718:      	tbz	w8, #0x4, 0x2634 <ltmp0+0x2634>
    271c:      	fmov	x9, d29
    2720:      	str	s28, [x9]
    2724:      	tbz	w8, #0x5, 0x2638 <ltmp0+0x2638>
    2728:      	mov.d	x9, v29[1]
    272c:      	st1.s	{ v28 }[1], [x9]
    2730:      	shl.2d	v29, v26, #0x5
    2734:      	ldr	q31, [sp, #0x280]
    2738:      	orr.16b	v29, v29, v31
    273c:      	add.2d	v29, v17, v29
    2740:      	tbz	w8, #0x6, 0x264c <ltmp0+0x264c>
    2744:      	fmov	x9, d29
    2748:      	st1.s	{ v28 }[2], [x9]
    274c:      	tbz	w8, #0x7, 0x2598 <ltmp0+0x2598>
    2750:      	mov.d	x8, v29[1]
    2754:      	st1.s	{ v28 }[3], [x8]
    2758:      	b	0x2598 <ltmp0+0x2598>
    275c:      	movi	d5, #0xffffffffff000000
    2760:      	ldr	q29, [sp, #0x90]
    2764:      	and.8b	v5, v29, v5
    2768:      	ldp	q25, q20, [sp, #0x30]
    276c:      	fmul.4s	v20, v20, v20
    2770:      	fmul.4s	v25, v25, v25
    2774:      	fadd.4s	v24, v25, v24
    2778:      	fadd.4s	v20, v20, v23
    277c:      	ldr	q25, [sp, #0x110]
    2780:      	zip1.8b	v23, v25, v0
    2784:      	ushll.4s	v23, v23, #0x0
    2788:      	shl.4s	v23, v23, #0x1f
    278c:      	cmlt.4s	v23, v23, #0
    2790:      	and.16b	v20, v23, v20
    2794:      	zip2.8b	v23, v25, v0
    2798:      	ushll.4s	v23, v23, #0x0
    279c:      	shl.4s	v23, v23, #0x1f
    27a0:      	cmlt.4s	v23, v23, #0
    27a4:      	and.16b	v23, v23, v24
    27a8:      	zip2.8b	v24, v5, v0
    27ac:      	ushll.4s	v24, v24, #0x0
    27b0:      	shl.4s	v24, v24, #0x1f
    27b4:      	cmlt.4s	v24, v24, #0
    27b8:      	bit.16b	v23, v30, v24
    27bc:      	zip1.8b	v5, v5, v0
    27c0:      	ushll.4s	v5, v5, #0x0
    27c4:      	shl.4s	v5, v5, #0x1f
    27c8:      	cmlt.4s	v5, v5, #0
    27cc:      	bsl.16b	v5, v27, v20
    27d0:      	fadd.4s	v5, v14, v5
    27d4:      	fadd.4s	v20, v13, v23
    27d8:      	mov.16b	v13, v25
    27dc:      	fadd.4s	v20, v7, v20
    27e0:      	fadd.4s	v5, v15, v5
    27e4:      	fadd.4s	v7, v22, v5
    27e8:      	fadd.4s	v20, v21, v20
    27ec:      	ldp	q21, q5, [sp, #0x50]
    27f0:      	uzp1.4s	v5, v21, v5
    27f4:      	ldp	q22, q21, [sp, #0x10]
    27f8:      	uzp1.4s	v21, v22, v21
    27fc:      	movi.4s	v23, #0x1
    2800:      	eor.16b	v22, v5, v23
    2804:      	mov.s	w9, v22[1]
    2808:      	mov.s	w12, v22[2]
    280c:      	eor.16b	v25, v21, v23
    2810:      	mov.s	w14, v22[3]
    2814:      	fmov	w8, s22
    2818:      	add	x16, sp, #0x308
    281c:      	bfxil	x16, x8, #0, #3
    2820:      	str	d29, [sp, #0x308]
    2824:      	ldrb	w16, [x16]
    2828:      	and	x17, x8, #0x7
    282c:      	umov.b	w8, v29[0]
    2830:      	str	q20, [sp, #0x420]
    2834:      	str	q7, [sp, #0x410]
    2838:      	add	x15, sp, #0x410
    283c:      	ldr	s22, [x15, x17, lsl #2]
    2840:      	ands	w0, w8, #0x1
    2844:      	tst	w0, w16
    2848:      	movi	d12, #0000000000000000
    284c:      	fcsel	s22, s22, s12, ne
    2850:      	add	x16, sp, #0x308
    2854:      	bfxil	x16, x9, #0, #3
    2858:      	ldrb	w16, [x16]
    285c:      	and	x17, x9, #0x7
    2860:      	umov.b	w9, v29[1]
    2864:      	stp	q7, q20, [sp, #0x3f0]
    2868:      	add	x15, sp, #0x3f0
    286c:      	ldr	s23, [x15, x17, lsl #2]
    2870:      	ands	w17, w9, #0x1
    2874:      	tst	w17, w16
    2878:      	fcsel	s23, s23, s12, ne
    287c:      	add	x16, sp, #0x308
    2880:      	bfxil	x16, x12, #0, #3
    2884:      	ldrb	w16, [x16]
    2888:      	umov.b	w2, v29[2]
    288c:      	and	x12, x12, #0x7
    2890:      	stp	q7, q20, [sp, #0x3d0]
    2894:      	add	x15, sp, #0x3d0
    2898:      	ldr	s24, [x15, x12, lsl #2]
    289c:      	ands	w12, w2, #0x1
    28a0:      	tst	w12, w16
    28a4:      	fcsel	s24, s24, s12, ne
    28a8:      	add	x12, sp, #0x308
    28ac:      	bfxil	x12, x14, #0, #3
    28b0:      	ldrb	w12, [x12]
    28b4:      	and	x14, x14, #0x7
    28b8:      	umov.b	w25, v29[3]
    28bc:      	stp	q7, q20, [sp, #0x3b0]
    28c0:      	add	x15, sp, #0x3b0
    28c4:      	ldr	s26, [x15, x14, lsl #2]
    28c8:      	ands	w14, w25, #0x1
    28cc:      	tst	w14, w12
    28d0:      	mov.s	w14, v25[1]
    28d4:      	mov.s	w16, v25[2]
    28d8:      	fcsel	s26, s26, s12, ne
    28dc:      	mov.s	w17, v25[3]
    28e0:      	fmov	w12, s25
    28e4:      	and	x27, x12, #0x7
    28e8:      	add	x28, sp, #0x308
    28ec:      	bfxil	x28, x12, #0, #3
    28f0:      	ldrb	w28, [x28]
    28f4:      	umov.b	w12, v29[4]
    28f8:      	and	w28, w12, w28
    28fc:      	str	q20, [sp, #0x4a0]
    2900:      	str	q7, [sp, #0x490]
    2904:      	add	x15, sp, #0x490
    2908:      	ldr	s25, [x15, x27, lsl #2]
    290c:      	tst	w28, #0x1
    2910:      	fcsel	s25, s25, s12, ne
    2914:      	add	x27, sp, #0x308
    2918:      	bfxil	x27, x14, #0, #3
    291c:      	ldrb	w28, [x27]
    2920:      	and	x14, x14, #0x7
    2924:      	umov.b	w27, v29[5]
    2928:      	str	q20, [sp, #0x480]
    292c:      	str	q7, [sp, #0x470]
    2930:      	add	x15, sp, #0x470
    2934:      	ldr	s27, [x15, x14, lsl #2]
    2938:      	ands	w14, w27, #0x1
    293c:      	tst	w14, w28
    2940:      	fcsel	s27, s27, s12, ne
    2944:      	add	x14, sp, #0x308
    2948:      	bfxil	x14, x16, #0, #3
    294c:      	ldrb	w14, [x14]
    2950:      	and	x16, x16, #0x7
    2954:      	umov.b	w28, v29[6]
    2958:      	str	q20, [sp, #0x460]
    295c:      	str	q7, [sp, #0x450]
    2960:      	add	x15, sp, #0x450
    2964:      	ldr	s28, [x15, x16, lsl #2]
    2968:      	ands	w16, w28, #0x1
    296c:      	tst	w16, w14
    2970:      	fcsel	s28, s28, s12, ne
    2974:      	add	x14, sp, #0x308
    2978:      	bfxil	x14, x17, #0, #3
    297c:      	ldrb	w14, [x14]
    2980:      	umov.b	w30, v29[7]
    2984:      	and	x16, x17, #0x7
    2988:      	str	q20, [sp, #0x440]
    298c:      	str	q7, [sp, #0x430]
    2990:      	add	x15, sp, #0x430
    2994:      	ldr	s29, [x15, x16, lsl #2]
    2998:      	ands	w16, w30, #0x1
    299c:      	tst	w16, w14
    29a0:      	fcsel	s29, s29, s12, ne
    29a4:      	mov.s	v25[1], v27[0]
    29a8:      	mov.s	v25[2], v28[0]
    29ac:      	mov.s	v25[3], v29[0]
    29b0:      	mov.s	v22[1], v23[0]
    29b4:      	mov.s	v22[2], v24[0]
    29b8:      	mov.s	v22[3], v26[0]
    29bc:      	fadd.4s	v7, v7, v22
    29c0:      	fadd.4s	v20, v20, v25
    29c4:      	movi.4s	v22, #0x2
    29c8:      	eor.16b	v21, v21, v22
    29cc:      	eor.16b	v5, v5, v22
    29d0:      	fmov	w14, s5
    29d4:      	add	x16, sp, #0x308
    29d8:      	bfxil	x16, x14, #0, #3
    29dc:      	ldrb	w16, [x16]
    29e0:      	and	x14, x14, #0x7
    29e4:      	stp	q7, q20, [sp, #0x390]
    29e8:      	add	x15, sp, #0x390
    29ec:      	ldr	s5, [x15, x14, lsl #2]
    29f0:      	tst	w0, w16
    29f4:      	fcsel	s5, s5, s12, ne
    29f8:      	fmov	w14, s21
    29fc:      	and	x16, x14, #0x7
    2a00:      	add	x17, sp, #0x308
    2a04:      	bfxil	x17, x14, #0, #3
    2a08:      	ldrb	w14, [x17]
    2a0c:      	and	w14, w12, w14
    2a10:      	stp	q7, q20, [sp, #0x370]
    2a14:      	add	x15, sp, #0x370
    2a18:      	ldr	s21, [x15, x16, lsl #2]
    2a1c:      	tst	w14, #0x1
    2a20:      	fcsel	s21, s21, s12, ne
    2a24:      	fadd.4s	v20, v20, v21
    2a28:      	tst	w0, w12
    2a2c:      	fcsel	s20, s20, s12, ne
    2a30:      	ands	w8, w8, #0x1
    2a34:      	fadd.4s	v5, v7, v5
    2a38:      	fadd	s5, s5, s20
    2a3c:      	fcsel	s7, s5, s12, ne
    2a40:      	tst	w9, #0x1
    2a44:      	fcsel	s20, s7, s12, ne
    2a48:      	tst	w2, #0x1
    2a4c:      	fcsel	s21, s7, s12, ne
    2a50:      	tst	w25, #0x1
    2a54:      	fcsel	s22, s7, s12, ne
    2a58:      	tst	w8, w12
    2a5c:      	fcsel	s23, s5, s12, ne
    2a60:      	tst	w27, #0x1
    2a64:      	fcsel	s24, s7, s12, ne
    2a68:      	tst	w28, #0x1
    2a6c:      	fcsel	s25, s7, s12, ne
    2a70:      	tst	w30, #0x1
    2a74:      	adrp	x8, 0x2000 <ltmp0+0x2000>
    2a78:      	ldr	d5, [x8]
    2a7c:      	shl.8b	v26, v13, #0x7
    2a80:      	cmlt.8b	v26, v26, #0
    2a84:      	and.8b	v5, v26, v5
    2a88:      	addv.8b	b5, v5
    2a8c:      	fmov	w8, s5
    2a90:      	fcsel	s26, s7, s12, ne
    2a94:      	mov.s	v7[1], v20[0]
    2a98:      	mov.s	v7[2], v21[0]
    2a9c:      	mov.s	v7[3], v22[0]
    2aa0:      	mov.s	v23[1], v24[0]
    2aa4:      	mov.s	v23[2], v25[0]
    2aa8:      	mov.s	v23[3], v26[0]
    2aac:      	rbit	w9, w4
    2ab0:      	clz	w9, w9
    2ab4:      	stp	q7, q23, [sp, #0x350]
    2ab8:      	and	x9, x9, #0x7
    2abc:      	add	x12, sp, #0x350
    2ac0:      	ldr	s7, [x12, x9, lsl #2]
    2ac4:      	mov	b20, v13[0]
    2ac8:      	mov.b	v20[4], v13[1]
    2acc:      	ushll.2d	v20, v20, #0x0
    2ad0:      	shl.2d	v20, v20, #0x3f
    2ad4:      	cmlt.2d	v20, v20, #0
    2ad8:      	mov	b21, v13[2]
    2adc:      	mov.b	v21[4], v13[3]
    2ae0:      	ldr	q22, [sp, #0xa0]
    2ae4:      	and.16b	v20, v20, v22
    2ae8:      	ushll.2d	v21, v21, #0x0
    2aec:      	shl.2d	v21, v21, #0x3f
    2af0:      	cmlt.2d	v21, v21, #0
    2af4:      	ldr	q22, [sp, #0xc0]
    2af8:      	and.16b	v21, v21, v22
    2afc:      	mov	b22, v13[4]
    2b00:      	mov.b	v22[4], v13[5]
    2b04:      	ushll.2d	v22, v22, #0x0
    2b08:      	shl.2d	v22, v22, #0x3f
    2b0c:      	cmlt.2d	v22, v22, #0
    2b10:      	ldp	q23, q24, [sp, #0x70]
    2b14:      	and.16b	v22, v22, v23
    2b18:      	mov	b23, v13[6]
    2b1c:      	mov.b	v23[4], v13[7]
    2b20:      	ushll.2d	v23, v23, #0x0
    2b24:      	shl.2d	v23, v23, #0x3f
    2b28:      	cmlt.2d	v23, v23, #0
    2b2c:      	and.16b	v23, v23, v24
    2b30:      	stp	q22, q23, [sp, #0x330]
    2b34:      	stp	q20, q21, [sp, #0x310]
    2b38:      	and	x9, x26, #0x7
    2b3c:      	add	x12, sp, #0x310
    2b40:      	ldr	x9, [x12, x9, lsl #3]
    2b44:      	sub	x9, x9, x26
    2b48:      	add	x9, x11, x9, lsl #2
    2b4c:      	movi.2d	v20, #0000000000000000
    2b50:      	movi.2d	v21, #0000000000000000
    2b54:      	tbnz	w8, #0x0, 0x2fe8 <ltmp0+0x2fe8>
    2b58:      	ldr	w14, [sp, #0x14c]
    2b5c:      	tbnz	w8, #0x1, 0x2ff4 <ltmp0+0x2ff4>
    2b60:      	adrp	x16, 0x2000 <ltmp0+0x2000>
    2b64:      	adrp	x15, 0x2000 <ltmp0+0x2000>
    2b68:      	adrp	x17, 0x2000 <ltmp0+0x2000>
    2b6c:      	ldr	x25, [sp, #0x158]
    2b70:      	tbnz	w8, #0x2, 0x3010 <ltmp0+0x3010>
    2b74:      	tbnz	w8, #0x3, 0x301c <ltmp0+0x301c>
    2b78:      	tbnz	w8, #0x4, 0x3028 <ltmp0+0x3028>
    2b7c:      	tbnz	w8, #0x5, 0x3034 <ltmp0+0x3034>
    2b80:      	tbnz	w8, #0x6, 0x3040 <ltmp0+0x3040>
    2b84:      	tbz	w8, #0x7, 0x2b90 <ltmp0+0x2b90>
    2b88:      	add	x8, x9, #0x1c
    2b8c:      	ld1.s	{ v21 }[3], [x8]
    2b90:      	mov	x9, #0x0                ; =0
    2b94:      	fadd	s7, s7, s12
    2b98:      	mov	w8, #0x3000             ; =12288
    2b9c:      	movk	w8, #0x4500, lsl #16
    2ba0:      	fmov	s22, w8
    2ba4:      	fdiv	s7, s7, s22
    2ba8:      	add	x8, sp, #0x550
    2bac:      	add	x8, x8, x3
    2bb0:      	ldp	q22, q23, [x8]
    2bb4:      	zip2.8b	v24, v13, v0
    2bb8:      	ushll.4s	v24, v24, #0x0
    2bbc:      	shl.4s	v24, v24, #0x1f
    2bc0:      	cmlt.4s	v24, v24, #0
    2bc4:      	bif.16b	v21, v23, v24
    2bc8:      	zip1.8b	v23, v13, v0
    2bcc:      	ushll.4s	v23, v23, #0x0
    2bd0:      	shl.4s	v23, v23, #0x1f
    2bd4:      	cmlt.4s	v23, v23, #0
    2bd8:      	bif.16b	v20, v22, v23
    2bdc:      	stp	q20, q21, [x8]
    2be0:      	mov	w8, #0xc5ac             ; =50604
    2be4:      	movk	w8, #0x3727, lsl #16
    2be8:      	fmov	s20, w8
    2bec:      	fadd	s7, s7, s20
    2bf0:      	fsqrt	s7, s7
    2bf4:      	dup.4s	v7, v7[0]
    2bf8:      	ldr	q20, [sp, #0xb0]
    2bfc:      	fmov	x8, d20
    2c00:      	add	x8, x1, x8, lsl #2
    2c04:      	movi.2d	v20, #0000000000000000
    2c08:      	movi.2d	v21, #0000000000000000
    2c0c:      	movi.2d	v22, #0000000000000000
    2c10:      	movi.2d	v23, #0000000000000000
    2c14:      	b	0x2c34 <ltmp0+0x2c34>
    2c18:      	add.2d	v21, v21, v2
    2c1c:      	add.2d	v22, v22, v6
    2c20:      	add.2d	v23, v23, v11
    2c24:      	add.2d	v20, v20, v16
    2c28:      	fmov	x9, d20
    2c2c:      	cmp	x9, #0x100
    2c30:      	b.ge	0x2eb8 <ltmp0+0x2eb8>
    2c34:      	fmov	w11, s19
    2c38:      	shl.2d	v24, v20, #0x5
    2c3c:      	ldr	q25, [sp, #0x250]
    2c40:      	orr.16b	v26, v24, v25
    2c44:      	ldr	q24, [sp, #0x2a0]
    2c48:      	add.2d	v27, v24, v26
    2c4c:      	movi.2d	v25, #0000000000000000
    2c50:      	movi.2d	v24, #0000000000000000
    2c54:      	tbnz	w11, #0x0, 0x2d2c <ltmp0+0x2d2c>
    2c58:      	and	w11, w11, #0xff
    2c5c:      	tbnz	w11, #0x1, 0x2d3c <ltmp0+0x2d3c>
    2c60:      	shl.2d	v27, v21, #0x5
    2c64:      	ldr	q28, [sp, #0x270]
    2c68:      	orr.16b	v27, v27, v28
    2c6c:      	add.2d	v28, v8, v27
    2c70:      	tbnz	w11, #0x2, 0x2d58 <ltmp0+0x2d58>
    2c74:      	tbnz	w11, #0x3, 0x2d64 <ltmp0+0x2d64>
    2c78:      	shl.2d	v28, v22, #0x5
    2c7c:      	ldr	q29, [sp, #0x260]
    2c80:      	orr.16b	v28, v28, v29
    2c84:      	ldr	q29, [sp, #0x2b0]
    2c88:      	add.2d	v29, v29, v28
    2c8c:      	tbnz	w11, #0x4, 0x2d84 <ltmp0+0x2d84>
    2c90:      	tbnz	w11, #0x5, 0x2d90 <ltmp0+0x2d90>
    2c94:      	shl.2d	v29, v23, #0x5
    2c98:      	ldp	q31, q30, [sp, #0x280]
    2c9c:      	orr.16b	v29, v29, v31
    2ca0:      	add.2d	v30, v30, v29
    2ca4:      	tbnz	w11, #0x6, 0x2dac <ltmp0+0x2dac>
    2ca8:      	tbnz	w11, #0x7, 0x2db8 <ltmp0+0x2db8>
    2cac:      	fmov	w11, s19
    2cb0:      	add.2d	v31, v9, v26
    2cb4:      	movi.2d	v30, #0000000000000000
    2cb8:      	movi.2d	v26, #0000000000000000
    2cbc:      	tbnz	w11, #0x0, 0x2dd4 <ltmp0+0x2dd4>
    2cc0:      	and	w11, w11, #0xff
    2cc4:      	tbnz	w11, #0x1, 0x2de4 <ltmp0+0x2de4>
    2cc8:      	add.2d	v27, v18, v27
    2ccc:      	tbnz	w11, #0x2, 0x2df4 <ltmp0+0x2df4>
    2cd0:      	tbnz	w11, #0x3, 0x2e00 <ltmp0+0x2e00>
    2cd4:      	add.2d	v27, v10, v28
    2cd8:      	tbnz	w11, #0x4, 0x2e10 <ltmp0+0x2e10>
    2cdc:      	tbnz	w11, #0x5, 0x2e1c <ltmp0+0x2e1c>
    2ce0:      	add.2d	v27, v17, v29
    2ce4:      	tbnz	w11, #0x6, 0x2e2c <ltmp0+0x2e2c>
    2ce8:      	tbnz	w11, #0x7, 0x2e38 <ltmp0+0x2e38>
    2cec:      	fdiv.4s	v25, v25, v7
    2cf0:      	fmov	w11, s19
    2cf4:      	fmul.4s	v25, v25, v30
    2cf8:      	add	x9, x8, x9, lsl #5
    2cfc:      	tbnz	w11, #0x0, 0x2e54 <ltmp0+0x2e54>
    2d00:      	and	w11, w11, #0xff
    2d04:      	tbnz	w11, #0x1, 0x2e60 <ltmp0+0x2e60>
    2d08:      	tbnz	w11, #0x2, 0x2e6c <ltmp0+0x2e6c>
    2d0c:      	tbnz	w11, #0x3, 0x2e78 <ltmp0+0x2e78>
    2d10:      	fdiv.4s	v24, v24, v7
    2d14:      	fmul.4s	v24, v24, v26
    2d18:      	tbnz	w11, #0x4, 0x2e8c <ltmp0+0x2e8c>
    2d1c:      	tbnz	w11, #0x5, 0x2e94 <ltmp0+0x2e94>
    2d20:      	tbnz	w11, #0x6, 0x2ea0 <ltmp0+0x2ea0>
    2d24:      	tbz	w11, #0x7, 0x2c18 <ltmp0+0x2c18>
    2d28:      	b	0x2eac <ltmp0+0x2eac>
    2d2c:      	fmov	x12, d27
    2d30:      	ldr	s25, [x12]
    2d34:      	and	w11, w11, #0xff
    2d38:      	tbz	w11, #0x1, 0x2c60 <ltmp0+0x2c60>
    2d3c:      	mov.d	x12, v27[1]
    2d40:      	ld1.s	{ v25 }[1], [x12]
    2d44:      	shl.2d	v27, v21, #0x5
    2d48:      	ldr	q28, [sp, #0x270]
    2d4c:      	orr.16b	v27, v27, v28
    2d50:      	add.2d	v28, v8, v27
    2d54:      	tbz	w11, #0x2, 0x2c74 <ltmp0+0x2c74>
    2d58:      	fmov	x12, d28
    2d5c:      	ld1.s	{ v25 }[2], [x12]
    2d60:      	tbz	w11, #0x3, 0x2c78 <ltmp0+0x2c78>
    2d64:      	mov.d	x12, v28[1]
    2d68:      	ld1.s	{ v25 }[3], [x12]
    2d6c:      	shl.2d	v28, v22, #0x5
    2d70:      	ldr	q29, [sp, #0x260]
    2d74:      	orr.16b	v28, v28, v29
    2d78:      	ldr	q29, [sp, #0x2b0]
    2d7c:      	add.2d	v29, v29, v28
    2d80:      	tbz	w11, #0x4, 0x2c90 <ltmp0+0x2c90>
    2d84:      	fmov	x12, d29
    2d88:      	ld1.s	{ v24 }[0], [x12]
    2d8c:      	tbz	w11, #0x5, 0x2c94 <ltmp0+0x2c94>
    2d90:      	mov.d	x12, v29[1]
    2d94:      	ld1.s	{ v24 }[1], [x12]
    2d98:      	shl.2d	v29, v23, #0x5
    2d9c:      	ldp	q31, q30, [sp, #0x280]
    2da0:      	orr.16b	v29, v29, v31
    2da4:      	add.2d	v30, v30, v29
    2da8:      	tbz	w11, #0x6, 0x2ca8 <ltmp0+0x2ca8>
    2dac:      	fmov	x12, d30
    2db0:      	ld1.s	{ v24 }[2], [x12]
    2db4:      	tbz	w11, #0x7, 0x2cac <ltmp0+0x2cac>
    2db8:      	mov.d	x11, v30[1]
    2dbc:      	ld1.s	{ v24 }[3], [x11]
    2dc0:      	fmov	w11, s19
    2dc4:      	add.2d	v31, v9, v26
    2dc8:      	movi.2d	v30, #0000000000000000
    2dcc:      	movi.2d	v26, #0000000000000000
    2dd0:      	tbz	w11, #0x0, 0x2cc0 <ltmp0+0x2cc0>
    2dd4:      	fmov	x12, d31
    2dd8:      	ldr	s30, [x12]
    2ddc:      	and	w11, w11, #0xff
    2de0:      	tbz	w11, #0x1, 0x2cc8 <ltmp0+0x2cc8>
    2de4:      	mov.d	x12, v31[1]
    2de8:      	ld1.s	{ v30 }[1], [x12]
    2dec:      	add.2d	v27, v18, v27
    2df0:      	tbz	w11, #0x2, 0x2cd0 <ltmp0+0x2cd0>
    2df4:      	fmov	x12, d27
    2df8:      	ld1.s	{ v30 }[2], [x12]
    2dfc:      	tbz	w11, #0x3, 0x2cd4 <ltmp0+0x2cd4>
    2e00:      	mov.d	x12, v27[1]
    2e04:      	ld1.s	{ v30 }[3], [x12]
    2e08:      	add.2d	v27, v10, v28
    2e0c:      	tbz	w11, #0x4, 0x2cdc <ltmp0+0x2cdc>
    2e10:      	fmov	x12, d27
    2e14:      	ld1.s	{ v26 }[0], [x12]
    2e18:      	tbz	w11, #0x5, 0x2ce0 <ltmp0+0x2ce0>
    2e1c:      	mov.d	x12, v27[1]
    2e20:      	ld1.s	{ v26 }[1], [x12]
    2e24:      	add.2d	v27, v17, v29
    2e28:      	tbz	w11, #0x6, 0x2ce8 <ltmp0+0x2ce8>
    2e2c:      	fmov	x12, d27
    2e30:      	ld1.s	{ v26 }[2], [x12]
    2e34:      	tbz	w11, #0x7, 0x2cec <ltmp0+0x2cec>
    2e38:      	mov.d	x11, v27[1]
    2e3c:      	ld1.s	{ v26 }[3], [x11]
    2e40:      	fdiv.4s	v25, v25, v7
    2e44:      	fmov	w11, s19
    2e48:      	fmul.4s	v25, v25, v30
    2e4c:      	add	x9, x8, x9, lsl #5
    2e50:      	tbz	w11, #0x0, 0x2d00 <ltmp0+0x2d00>
    2e54:      	str	s25, [x9]
    2e58:      	and	w11, w11, #0xff
    2e5c:      	tbz	w11, #0x1, 0x2d08 <ltmp0+0x2d08>
    2e60:      	add	x12, x9, #0x4
    2e64:      	st1.s	{ v25 }[1], [x12]
    2e68:      	tbz	w11, #0x2, 0x2d0c <ltmp0+0x2d0c>
    2e6c:      	add	x12, x9, #0x8
    2e70:      	st1.s	{ v25 }[2], [x12]
    2e74:      	tbz	w11, #0x3, 0x2d10 <ltmp0+0x2d10>
    2e78:      	add	x12, x9, #0xc
    2e7c:      	st1.s	{ v25 }[3], [x12]
    2e80:      	fdiv.4s	v24, v24, v7
    2e84:      	fmul.4s	v24, v24, v26
    2e88:      	tbz	w11, #0x4, 0x2d1c <ltmp0+0x2d1c>
    2e8c:      	str	s24, [x9, #0x10]
    2e90:      	tbz	w11, #0x5, 0x2d20 <ltmp0+0x2d20>
    2e94:      	add	x12, x9, #0x14
    2e98:      	st1.s	{ v24 }[1], [x12]
    2e9c:      	tbz	w11, #0x6, 0x2d24 <ltmp0+0x2d24>
    2ea0:      	add	x12, x9, #0x18
    2ea4:      	st1.s	{ v24 }[2], [x12]
    2ea8:      	tbz	w11, #0x7, 0x2c18 <ltmp0+0x2c18>
    2eac:      	add	x9, x9, #0x1c
    2eb0:      	st1.s	{ v24 }[3], [x9]
    2eb4:      	b	0x2c18 <ltmp0+0x2c18>
    2eb8:      	add	x8, x10, x3
    2ebc:      	ldp	q6, q2, [x8]
    2ec0:      	zip1.8b	v16, v13, v0
    2ec4:      	ushll.4s	v16, v16, #0x0
    2ec8:      	shl.4s	v16, v16, #0x1f
    2ecc:      	cmlt.4s	v16, v16, #0
    2ed0:      	and.16b	v6, v16, v6
    2ed4:      	fmov	w8, s5
    2ed8:      	fdiv.4s	v6, v6, v7
    2edc:      	add	x9, sp, #0x550
    2ee0:      	add	x9, x9, x3
    2ee4:      	ldp	q17, q5, [x9]
    2ee8:      	and.16b	v16, v16, v17
    2eec:      	fmul.4s	v6, v6, v16
    2ef0:      	ldp	q17, q16, [sp, #0xf0]
    2ef4:      	stp	q17, q16, [sp, #0x2c0]
    2ef8:      	ldp	q17, q16, [sp, #0xd0]
    2efc:      	stp	q17, q16, [sp, #0x2e0]
    2f00:      	and	x9, x26, #0x7
    2f04:      	add	x11, sp, #0x2c0
    2f08:      	ldr	x9, [x11, x9, lsl #3]
    2f0c:      	sub	x9, x9, x26
    2f10:      	add	x9, x1, x9, lsl #2
    2f14:      	tbz	w8, #0x0, 0x2f1c <ltmp0+0x2f1c>
    2f18:      	str	s6, [x9]
    2f1c:      	adrp	x1, 0x2000 <ltmp0+0x2000>
    2f20:      	adrp	x4, 0x2000 <ltmp0+0x2000>
    2f24:      	adrp	x5, 0x2000 <ltmp0+0x2000>
    2f28:      	adrp	x6, 0x2000 <ltmp0+0x2000>
    2f2c:      	adrp	x7, 0x2000 <ltmp0+0x2000>
    2f30:      	adrp	x19, 0x2000 <ltmp0+0x2000>
    2f34:      	adrp	x20, 0x2000 <ltmp0+0x2000>
    2f38:      	adrp	x21, 0x2000 <ltmp0+0x2000>
    2f3c:      	adrp	x22, 0x2000 <ltmp0+0x2000>
    2f40:      	adrp	x23, 0x2000 <ltmp0+0x2000>
    2f44:      	ldr	w0, [sp, #0x154]
    2f48:      	ldr	w2, [sp, #0x150]
    2f4c:      	tbnz	w8, #0x1, 0x3050 <ltmp0+0x3050>
    2f50:      	tbnz	w8, #0x2, 0x305c <ltmp0+0x305c>
    2f54:      	tbz	w8, #0x3, 0x2f60 <ltmp0+0x2f60>
    2f58:      	add	x11, x9, #0xc
    2f5c:      	st1.s	{ v6 }[3], [x11]
    2f60:      	zip2.8b	v6, v13, v0
    2f64:      	ushll.4s	v6, v6, #0x0
    2f68:      	shl.4s	v6, v6, #0x1f
    2f6c:      	cmlt.4s	v6, v6, #0
    2f70:      	and.16b	v2, v6, v2
    2f74:      	fdiv.4s	v2, v2, v7
    2f78:      	and.16b	v5, v6, v5
    2f7c:      	fmul.4s	v2, v2, v5
    2f80:      	tbnz	w8, #0x4, 0x306c <ltmp0+0x306c>
    2f84:      	tbnz	w8, #0x5, 0x3074 <ltmp0+0x3074>
    2f88:      	tbnz	w8, #0x6, 0x3080 <ltmp0+0x3080>
    2f8c:      	tbz	w8, #0x7, 0xd0 <ltmp0+0xd0>
    2f90:      	b	0x308c <ltmp0+0x308c>
    2f94:      	ldr	s27, [x8]
    2f98:      	tbz	w9, #0x1, 0x1e90 <ltmp0+0x1e90>
    2f9c:      	add	x12, x8, #0x4
    2fa0:      	ld1.s	{ v27 }[1], [x12]
    2fa4:      	tbz	w9, #0x2, 0x1e94 <ltmp0+0x1e94>
    2fa8:      	add	x12, x8, #0x8
    2fac:      	ld1.s	{ v27 }[2], [x12]
    2fb0:      	tbz	w9, #0x3, 0x1e98 <ltmp0+0x1e98>
    2fb4:      	add	x12, x8, #0xc
    2fb8:      	ld1.s	{ v27 }[3], [x12]
    2fbc:      	tbz	w9, #0x4, 0x1e9c <ltmp0+0x1e9c>
    2fc0:      	add	x12, x8, #0x10
    2fc4:      	ld1.s	{ v28 }[0], [x12]
    2fc8:      	tbz	w9, #0x5, 0x1ea0 <ltmp0+0x1ea0>
    2fcc:      	add	x12, x8, #0x14
    2fd0:      	ld1.s	{ v28 }[1], [x12]
    2fd4:      	tbz	w9, #0x6, 0x1ea4 <ltmp0+0x1ea4>
    2fd8:      	add	x12, x8, #0x18
    2fdc:      	ld1.s	{ v28 }[2], [x12]
    2fe0:      	tbnz	w9, #0x7, 0x1ea8 <ltmp0+0x1ea8>
    2fe4:      	b	0x1eb0 <ltmp0+0x1eb0>
    2fe8:      	ldr	s20, [x9]
    2fec:      	ldr	w14, [sp, #0x14c]
    2ff0:      	tbz	w8, #0x1, 0x2b60 <ltmp0+0x2b60>
    2ff4:      	add	x11, x9, #0x4
    2ff8:      	ld1.s	{ v20 }[1], [x11]
    2ffc:      	adrp	x16, 0x2000 <ltmp0+0x2000>
    3000:      	adrp	x15, 0x3000 <ltmp0+0x3000>
    3004:      	adrp	x17, 0x3000 <ltmp0+0x3000>
    3008:      	ldr	x25, [sp, #0x158]
    300c:      	tbz	w8, #0x2, 0x2b74 <ltmp0+0x2b74>
    3010:      	add	x11, x9, #0x8
    3014:      	ld1.s	{ v20 }[2], [x11]
    3018:      	tbz	w8, #0x3, 0x2b78 <ltmp0+0x2b78>
    301c:      	add	x11, x9, #0xc
    3020:      	ld1.s	{ v20 }[3], [x11]
    3024:      	tbz	w8, #0x4, 0x2b7c <ltmp0+0x2b7c>
    3028:      	add	x11, x9, #0x10
    302c:      	ld1.s	{ v21 }[0], [x11]
    3030:      	tbz	w8, #0x5, 0x2b80 <ltmp0+0x2b80>
    3034:      	add	x11, x9, #0x14
    3038:      	ld1.s	{ v21 }[1], [x11]
    303c:      	tbz	w8, #0x6, 0x2b84 <ltmp0+0x2b84>
    3040:      	add	x11, x9, #0x18
    3044:      	ld1.s	{ v21 }[2], [x11]
    3048:      	tbnz	w8, #0x7, 0x2b88 <ltmp0+0x2b88>
    304c:      	b	0x2b90 <ltmp0+0x2b90>
    3050:      	add	x11, x9, #0x4
    3054:      	st1.s	{ v6 }[1], [x11]
    3058:      	tbz	w8, #0x2, 0x2f54 <ltmp0+0x2f54>
    305c:      	add	x11, x9, #0x8
    3060:      	st1.s	{ v6 }[2], [x11]
    3064:      	tbnz	w8, #0x3, 0x2f58 <ltmp0+0x2f58>
    3068:      	b	0x2f60 <ltmp0+0x2f60>
    306c:      	str	s2, [x9, #0x10]
    3070:      	tbz	w8, #0x5, 0x2f88 <ltmp0+0x2f88>
    3074:      	add	x11, x9, #0x14
    3078:      	st1.s	{ v2 }[1], [x11]
    307c:      	tbz	w8, #0x6, 0x2f8c <ltmp0+0x2f8c>
    3080:      	add	x11, x9, #0x18
    3084:      	st1.s	{ v2 }[2], [x11]
    3088:      	tbz	w8, #0x7, 0xd0 <ltmp0+0xd0>
    308c:      	add	x8, x9, #0x1c
    3090:      	st1.s	{ v2 }[3], [x8]
    3094:      	b	0xd0 <ltmp0+0xd0>
    3098:      	ldr	x9, [sp, #0x8]
    309c:      	stp	w25, w2, [x9]
    30a0:      	str	w0, [x9, #0x8]
    30a4:      	mov	w8, #0x18               ; =24
    30a8:      	str	w8, [x9, #0x24]
    30ac:      	add	sp, sp, #0x4, lsl #12   ; =0x4000
    30b0:      	add	sp, sp, #0x590
    30b4:      	ldp	x29, x30, [sp, #0x90]
    30b8:      	ldp	x20, x19, [sp, #0x80]
    30bc:      	ldp	x22, x21, [sp, #0x70]
    30c0:      	ldp	x24, x23, [sp, #0x60]
    30c4:      	ldp	x26, x25, [sp, #0x50]
    30c8:      	ldp	x28, x27, [sp, #0x40]
    30cc:      	ldp	d9, d8, [sp, #0x30]
    30d0:      	ldp	d11, d10, [sp, #0x20]
    30d4:      	ldp	d13, d12, [sp, #0x10]
    30d8:      	ldp	d15, d14, [sp], #0xa0
    30dc:      	ret


/tmp/luisa-cohort-private.qfZvpM/capture/rmsnorm-1024x4097-r0-l8-p0/object/tile_xir_w8_77311_1788916369156878_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      2c:      	sub	sp, sp, #0x5c0
      30:      	str	x0, [sp, #0x150]
      34:      	str	w3, [sp, #0x168]
      38:      	cbz	w3, 0x2f94 <ltmp0+0x2f94>
      3c:      	mov	w15, #0x0               ; =0
      40:      	add	x8, sp, #0x580
      44:      	add	x14, sp, #0x4, lsl #12  ; =0x4000
      48:      	add	x14, x14, #0x5a0
      4c:      	dup.2d	v0, x8
      50:      	mov	w27, #0x4               ; =4
      54:      	dup.2d	v1, x14
      58:      	adrp	x16, 0x0 <ltmp0>
      5c:      	adrp	x1, 0x0 <ltmp0>
      60:      	adrp	x17, 0x0 <ltmp0>
      64:      	adrp	x4, 0x0 <ltmp0>
      68:      	dup.2d	v2, x27
      6c:      	str	q2, [sp, #0x140]
      70:      	adrp	x5, 0x0 <ltmp0>
      74:      	adrp	x6, 0x0 <ltmp0>
      78:      	adrp	x7, 0x0 <ltmp0>
      7c:      	adrp	x19, 0x0 <ltmp0>
      80:      	adrp	x20, 0x0 <ltmp0>
      84:      	ldp	w9, w8, [x2, #0x2c]
      88:      	str	w9, [sp, #0x164]
      8c:      	str	w8, [sp, #0x160]
      90:      	adrp	x22, 0x0 <ltmp0>
      94:      	adrp	x8, 0x0 <ltmp0>
      98:      	ldr	q3, [x8]
      9c:      	adrp	x23, 0x0 <ltmp0>
      a0:      	adrp	x24, 0x0 <ltmp0>
      a4:      	adrp	x25, 0x0 <ltmp0>
      a8:      	adrp	x26, 0x0 <ltmp0>
      ac:      	adrp	x10, 0x0 <ltmp0>
      b0:      	mov	w28, #0x1               ; =1
      b4:      	movi	d11, #0000000000000000
      b8:      	ldp	w8, w9, [x2]
      bc:      	ldp	w11, w12, [x2, #0x8]
      c0:      	str	x2, [sp, #0x8]
      c4:      	str	x12, [sp, #0x158]
      c8:      	str	q3, [sp, #0x280]
      cc:      	b	0x110 <ltmp0+0x110>
      d0:      	add	w8, w2, #0x1
      d4:      	ldr	w9, [sp, #0x164]
      d8:      	cmp	w8, w9
      dc:      	cset	w9, eq
      e0:      	csinc	w8, wzr, w2, eq
      e4:      	cinc	w11, w0, eq
      e8:      	ldr	w12, [sp, #0x160]
      ec:      	cmp	w11, w12
      f0:      	cset	w12, eq
      f4:      	ands	w12, w9, w12
      f8:      	csel	w9, wzr, w11, ne
      fc:      	add	w11, w13, w12
     100:      	add	w15, w15, #0x1
     104:      	ldr	w12, [sp, #0x168]
     108:      	cmp	w15, w12
     10c:      	b.eq	0x2f80 <ltmp0+0x2f80>
     110:      	mov	x0, x11
     114:      	str	w9, [sp, #0x16c]
     118:      	mov	x3, x8
     11c:      	ubfiz	x8, x8, #5, #32
     120:      	ldr	x13, [sp, #0x158]
     124:      	cmp	x8, x13
     128:      	csel	x9, x8, xzr, ls
     12c:      	subs	x11, x13, x9
     130:      	cmp	x11, #0x20
     134:      	mov	w12, #0x20              ; =32
     138:      	csel	x11, x11, x12, lo
     13c:      	cmp	x13, x9
     140:      	ccmp	x8, x13, #0x2, hi
     144:      	csel	x9, x11, xzr, ls
     148:      	cmp	x9, #0x20
     14c:      	str	w15, [sp, #0x174]
     150:      	str	w0, [sp, #0x170]
     154:      	str	x3, [sp, #0x178]
     158:      	b.lo	0x1528 <ltmp0+0x1528>
     15c:      	mov	x8, #0x0                ; =0
     160:      	ldr	x9, [sp, #0x150]
     164:      	ldr	x11, [x9]
     168:      	ldr	x2, [x9, #0x10]
     16c:      	ldr	x9, [x9, #0x30]
     170:      	str	x9, [sp, #0x210]
     174:      	ubfiz	w13, w3, #2, #27
     178:      	mov	w9, #0x4004             ; =16388
     17c:      	umull	x12, w13, w9
     180:      	mov	x15, x11
     184:      	str	w13, [sp, #0x200]
     188:      	umaddl	x9, w13, w9, x11
     18c:      	add	x13, x9, x8
     190:      	ldp	q2, q4, [x13]
     194:      	add	x13, x14, x8
     198:      	stp	q2, q4, [x13]
     19c:      	add	x8, x8, #0x20
     1a0:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     1a4:      	b.ne	0x18c <ltmp0+0x18c>
     1a8:      	add	x9, x12, #0x4, lsl #12  ; =0x4000
     1ac:      	ldr	s2, [x15, x9]
     1b0:      	str	q2, [sp, #0x2c0]
     1b4:      	str	s2, [x14, x8]
     1b8:      	ldr	q2, [sp, #0x45a0]
     1bc:      	ldr	q4, [sp, #0x45b0]
     1c0:      	fmul.4s	v5, v4, v4
     1c4:      	fmul.4s	v4, v2, v2
     1c8:      	ldr	q2, [sp, #0x45c0]
     1cc:      	ldr	q6, [sp, #0x45d0]
     1d0:      	fmul.4s	v7, v6, v6
     1d4:      	fmul.4s	v6, v2, v2
     1d8:      	ldr	q2, [sp, #0x45e0]
     1dc:      	ldr	q16, [sp, #0x45f0]
     1e0:      	fmul.4s	v31, v16, v16
     1e4:      	fmul.4s	v8, v2, v2
     1e8:      	ldr	q2, [sp, #0x4600]
     1ec:      	ldr	q16, [sp, #0x4610]
     1f0:      	fmul.4s	v10, v16, v16
     1f4:      	fmul.4s	v9, v2, v2
     1f8:      	ldr	q14, [sp, #0x140]
     1fc:      	mov.16b	v11, v14
     200:      	mov.16b	v12, v14
     204:      	mov.16b	v13, v14
     208:      	shl.2d	v2, v11, #0x5
     20c:      	add.2d	v28, v1, v2
     210:      	ldr	q2, [sp, #0x280]
     214:      	add.2d	v19, v28, v2
     218:      	mov.d	x8, v19[1]
     21c:      	ldr	q25, [x16]
     220:      	shl.2d	v2, v12, #0x5
     224:      	add.2d	v16, v1, v2
     228:      	add.2d	v20, v16, v25
     22c:      	mov.d	x13, v20[1]
     230:      	ldr	q17, [x1]
     234:      	shl.2d	v2, v13, #0x5
     238:      	add.2d	v15, v1, v2
     23c:      	add.2d	v21, v15, v17
     240:      	mov.d	x0, v21[1]
     244:      	ldr	q18, [x17]
     248:      	shl.2d	v2, v14, #0x5
     24c:      	add.2d	v2, v1, v2
     250:      	add.2d	v22, v2, v18
     254:      	mov.d	x21, v22[1]
     258:      	fmov	x30, d19
     25c:      	ldr	s19, [x30]
     260:      	fmov	x30, d20
     264:      	fmov	x11, d21
     268:      	ld1.s	{ v19 }[1], [x8]
     26c:      	fmov	x8, d22
     270:      	ld1.s	{ v19 }[2], [x30]
     274:      	ld1.s	{ v19 }[3], [x13]
     278:      	ldr	s20, [x11]
     27c:      	ld1.s	{ v20 }[1], [x0]
     280:      	ld1.s	{ v20 }[2], [x8]
     284:      	ld1.s	{ v20 }[3], [x21]
     288:      	fmul.4s	v20, v20, v20
     28c:      	fmul.4s	v19, v19, v19
     290:      	fadd.4s	v4, v4, v19
     294:      	fadd.4s	v5, v5, v20
     298:      	ldr	q21, [x4]
     29c:      	ldr	q22, [x5]
     2a0:      	ldr	q26, [x6]
     2a4:      	ldr	q27, [x7]
     2a8:      	add.2d	v19, v2, v27
     2ac:      	add.2d	v20, v15, v26
     2b0:      	add.2d	v23, v16, v22
     2b4:      	add.2d	v24, v28, v21
     2b8:      	mov.d	x8, v24[1]
     2bc:      	fmov	x11, d24
     2c0:      	mov.d	x13, v23[1]
     2c4:      	fmov	x0, d23
     2c8:      	mov.d	x21, v20[1]
     2cc:      	fmov	x30, d20
     2d0:      	mov.d	x3, v19[1]
     2d4:      	ldr	s20, [x11]
     2d8:      	ld1.s	{ v20 }[1], [x8]
     2dc:      	ld1.s	{ v20 }[2], [x0]
     2e0:      	ld1.s	{ v20 }[3], [x13]
     2e4:      	fmov	x8, d19
     2e8:      	ldr	s19, [x30]
     2ec:      	ld1.s	{ v19 }[1], [x21]
     2f0:      	ld1.s	{ v19 }[2], [x8]
     2f4:      	ld1.s	{ v19 }[3], [x3]
     2f8:      	fmul.4s	v19, v19, v19
     2fc:      	fmul.4s	v20, v20, v20
     300:      	fadd.4s	v6, v6, v20
     304:      	fadd.4s	v7, v7, v19
     308:      	ldr	q24, [x19]
     30c:      	ldr	q23, [x20]
     310:      	ldr	q29, [x22]
     314:      	ldr	q3, [x23]
     318:      	add.2d	v19, v2, v3
     31c:      	add.2d	v20, v28, v24
     320:      	mov.d	x8, v20[1]
     324:      	fmov	x11, d20
     328:      	add.2d	v20, v16, v23
     32c:      	mov.d	x13, v20[1]
     330:      	fmov	x0, d20
     334:      	add.2d	v20, v15, v29
     338:      	mov.d	x3, v20[1]
     33c:      	mov.d	x21, v19[1]
     340:      	fmov	x30, d20
     344:      	ldr	s20, [x11]
     348:      	ld1.s	{ v20 }[1], [x8]
     34c:      	ld1.s	{ v20 }[2], [x0]
     350:      	fmov	x8, d19
     354:      	ld1.s	{ v20 }[3], [x13]
     358:      	ldr	s19, [x30]
     35c:      	ld1.s	{ v19 }[1], [x3]
     360:      	ld1.s	{ v19 }[2], [x8]
     364:      	ld1.s	{ v19 }[3], [x21]
     368:      	fmul.4s	v19, v19, v19
     36c:      	fmul.4s	v20, v20, v20
     370:      	fadd.4s	v8, v8, v20
     374:      	fadd.4s	v31, v31, v19
     378:      	ldr	q20, [x24]
     37c:      	add.2d	v19, v28, v20
     380:      	mov.d	x8, v19[1]
     384:      	ldr	q28, [x25]
     388:      	fmov	x11, d19
     38c:      	ldr	q30, [x26]
     390:      	add.2d	v19, v16, v28
     394:      	mov.d	x13, v19[1]
     398:      	fmov	x0, d19
     39c:      	ldr	q16, [x10]
     3a0:      	add.2d	v2, v2, v16
     3a4:      	add.2d	v19, v15, v30
     3a8:      	mov.d	x3, v19[1]
     3ac:      	fmov	x21, d19
     3b0:      	mov.d	x30, v2[1]
     3b4:      	ldr	s19, [x11]
     3b8:      	ld1.s	{ v19 }[1], [x8]
     3bc:      	fmov	x8, d2
     3c0:      	ld1.s	{ v19 }[2], [x0]
     3c4:      	ld1.s	{ v19 }[3], [x13]
     3c8:      	fmul.4s	v2, v19, v19
     3cc:      	fadd.4s	v9, v9, v2
     3d0:      	ldr	s2, [x21]
     3d4:      	ld1.s	{ v2 }[1], [x3]
     3d8:      	ld1.s	{ v2 }[2], [x8]
     3dc:      	ld1.s	{ v2 }[3], [x30]
     3e0:      	fmul.4s	v2, v2, v2
     3e4:      	fadd.4s	v10, v10, v2
     3e8:      	dup.2d	v2, x27
     3ec:      	add.2d	v13, v13, v2
     3f0:      	add.2d	v12, v12, v2
     3f4:      	add.2d	v14, v14, v2
     3f8:      	add.2d	v11, v11, v2
     3fc:      	fmov	x8, d11
     400:      	cmp	x8, #0x200
     404:      	b.lt	0x208 <ltmp0+0x208>
     408:      	stp	q3, q29, [sp, #0x260]
     40c:      	stp	q23, q24, [sp, #0x290]
     410:      	str	q16, [sp, #0x220]
     414:      	str	q20, [sp, #0x250]
     418:      	stp	q22, q21, [sp, #0x2d0]
     41c:      	mov	x8, #0x0                ; =0
     420:      	movi.2d	v2, #0000000000000000
     424:      	movi.2d	v19, #0000000000000000
     428:      	movi.2d	v20, #0000000000000000
     42c:      	movi.2d	v11, #0000000000000000
     430:      	mov.16b	v16, v25
     434:      	ldr	q3, [sp, #0x280]
     438:      	add	x8, x2, x8, lsl #5
     43c:      	ldp	q13, q12, [x8]
     440:      	shl.2d	v14, v2, #0x5
     444:      	shl.2d	v15, v19, #0x5
     448:      	shl.2d	v21, v20, #0x5
     44c:      	shl.2d	v22, v11, #0x5
     450:      	add.2d	v22, v22, v18
     454:      	add.2d	v22, v0, v22
     458:      	add.2d	v21, v21, v17
     45c:      	add.2d	v15, v15, v16
     460:      	add.2d	v14, v14, v3
     464:      	add.2d	v14, v0, v14
     468:      	mov.d	x8, v14[1]
     46c:      	fmov	x11, d14
     470:      	str	s13, [x11]
     474:      	st1.s	{ v13 }[1], [x8]
     478:      	add.2d	v14, v0, v15
     47c:      	mov.d	x8, v14[1]
     480:      	fmov	x11, d14
     484:      	st1.s	{ v13 }[2], [x11]
     488:      	add.2d	v21, v0, v21
     48c:      	st1.s	{ v13 }[3], [x8]
     490:      	mov.d	x8, v21[1]
     494:      	fmov	x11, d21
     498:      	str	s12, [x11]
     49c:      	st1.s	{ v12 }[1], [x8]
     4a0:      	mov.d	x8, v22[1]
     4a4:      	fmov	x11, d22
     4a8:      	st1.s	{ v12 }[2], [x11]
     4ac:      	st1.s	{ v12 }[3], [x8]
     4b0:      	dup.2d	v21, x28
     4b4:      	add.2d	v20, v20, v21
     4b8:      	add.2d	v19, v19, v21
     4bc:      	add.2d	v11, v11, v21
     4c0:      	add.2d	v2, v2, v21
     4c4:      	fmov	x8, d2
     4c8:      	cmp	x8, #0x200
     4cc:      	b.lt	0x438 <ltmp0+0x438>
     4d0:      	mov	x8, #0x0                ; =0
     4d4:      	ldr	q2, [sp, #0x2c0]
     4d8:      	fmul.4s	v2, v2, v2
     4dc:      	fadd.4s	v2, v2, v4
     4e0:      	mov.s	v4[0], v2[0]
     4e4:      	fadd.4s	v2, v7, v5
     4e8:      	fadd.4s	v4, v6, v4
     4ec:      	fadd.4s	v4, v8, v4
     4f0:      	fadd.4s	v2, v31, v2
     4f4:      	fadd.4s	v2, v10, v2
     4f8:      	fadd.4s	v4, v9, v4
     4fc:      	rev64.4s	v5, v4
     500:      	rev64.4s	v6, v2
     504:      	fadd.4s	v4, v4, v5
     508:      	dup.4s	v5, v4[2]
     50c:      	fadd.4s	v2, v2, v6
     510:      	dup.4s	v6, v2[2]
     514:      	fadd.4s	v2, v2, v6
     518:      	fadd.4s	v4, v4, v5
     51c:      	fadd.4s	v2, v4, v2
     520:      	movi	d4, #0000000000000000
     524:      	fadd	s4, s2, s4
     528:      	mov	w11, #0x800             ; =2048
     52c:      	movk	w11, #0x4580, lsl #16
     530:      	fmov	s5, w11
     534:      	add	x5, x2, #0x4, lsl #12   ; =0x4000
     538:      	ldr	q2, [sp, #0x4580]
     53c:      	ld1.s	{ v2 }[0], [x5]
     540:      	fdiv	s4, s4, s5
     544:      	mov	w11, #0xc5ac            ; =50604
     548:      	movk	w11, #0x3727, lsl #16
     54c:      	fmov	s5, w11
     550:      	fadd	s4, s4, s5
     554:      	fsqrt	s4, s4
     558:      	dup.4s	v5, v4[0]
     55c:      	str	q2, [sp, #0x4580]
     560:      	ldr	x17, [sp, #0x210]
     564:      	add	x12, x17, x12
     568:      	movi.2d	v6, #0000000000000000
     56c:      	movi.2d	v7, #0000000000000000
     570:      	movi.2d	v19, #0000000000000000
     574:      	movi.2d	v20, #0000000000000000
     578:      	mov	x1, x15
     57c:      	ldr	w4, [sp, #0x200]
     580:      	ldr	q25, [sp, #0x2a0]
     584:      	shl.2d	v21, v20, #0x5
     588:      	shl.2d	v22, v19, #0x5
     58c:      	shl.2d	v31, v7, #0x5
     590:      	shl.2d	v8, v6, #0x5
     594:      	orr.16b	v8, v8, v3
     598:      	orr.16b	v31, v31, v16
     59c:      	orr.16b	v22, v22, v17
     5a0:      	orr.16b	v21, v21, v18
     5a4:      	add.2d	v9, v1, v21
     5a8:      	add.2d	v10, v1, v22
     5ac:      	add.2d	v11, v1, v31
     5b0:      	add.2d	v12, v1, v8
     5b4:      	mov.d	x11, v12[1]
     5b8:      	mov.d	x13, v11[1]
     5bc:      	mov.d	x3, v10[1]
     5c0:      	fmov	x21, d12
     5c4:      	fmov	x30, d10
     5c8:      	mov.d	x0, v9[1]
     5cc:      	fmov	x20, d9
     5d0:      	ldr	s9, [x30]
     5d4:      	ld1.s	{ v9 }[1], [x3]
     5d8:      	ld1.s	{ v9 }[2], [x20]
     5dc:      	ld1.s	{ v9 }[3], [x0]
     5e0:      	fmov	x0, d11
     5e4:      	ldr	s10, [x21]
     5e8:      	ld1.s	{ v10 }[1], [x11]
     5ec:      	ld1.s	{ v10 }[2], [x0]
     5f0:      	ld1.s	{ v10 }[3], [x13]
     5f4:      	fdiv.4s	v10, v10, v5
     5f8:      	fdiv.4s	v9, v9, v5
     5fc:      	add.2d	v21, v0, v21
     600:      	add.2d	v22, v0, v22
     604:      	add.2d	v31, v0, v31
     608:      	add.2d	v8, v0, v8
     60c:      	mov.d	x11, v8[1]
     610:      	fmov	x13, d8
     614:      	mov.d	x0, v31[1]
     618:      	mov.d	x3, v22[1]
     61c:      	mov.d	x20, v21[1]
     620:      	fmov	x21, d31
     624:      	ldr	s31, [x13]
     628:      	ld1.s	{ v31 }[1], [x11]
     62c:      	ld1.s	{ v31 }[2], [x21]
     630:      	fmov	x11, d22
     634:      	ld1.s	{ v31 }[3], [x0]
     638:      	ldr	s22, [x11]
     63c:      	ld1.s	{ v22 }[1], [x3]
     640:      	fmov	x11, d21
     644:      	ld1.s	{ v22 }[2], [x11]
     648:      	ld1.s	{ v22 }[3], [x20]
     64c:      	fmul.4s	v21, v9, v22
     650:      	fmul.4s	v22, v10, v31
     654:      	add	x8, x12, x8, lsl #5
     658:      	stp	q22, q21, [x8]
     65c:      	dup.2d	v21, x28
     660:      	add.2d	v19, v19, v21
     664:      	add.2d	v7, v7, v21
     668:      	add.2d	v20, v20, v21
     66c:      	add.2d	v6, v6, v21
     670:      	fmov	x8, d6
     674:      	cmp	x8, #0x200
     678:      	b.lt	0x584 <ltmp0+0x584>
     67c:      	stp	q30, q28, [sp, #0x230]
     680:      	stp	q27, q26, [sp, #0x2b0]
     684:      	mov	x12, #0x0               ; =0
     688:      	ldr	q5, [sp, #0x85a0]
     68c:      	fdiv.4s	v4, v5, v4
     690:      	fmul.4s	v2, v2, v4
     694:      	str	s2, [x17, x9]
     698:      	orr	w9, w4, #0x1
     69c:      	mov	w11, #0x4004            ; =16388
     6a0:      	umull	x8, w9, w11
     6a4:      	umaddl	x9, w9, w11, x1
     6a8:      	ldr	w15, [sp, #0x174]
     6ac:      	add	x11, x9, x12
     6b0:      	ldp	q2, q4, [x11]
     6b4:      	add	x11, x14, x12
     6b8:      	stp	q2, q4, [x11]
     6bc:      	add	x12, x12, #0x20
     6c0:      	cmp	x12, #0x4, lsl #12      ; =0x4000
     6c4:      	b.ne	0x6ac <ltmp0+0x6ac>
     6c8:      	add	x9, x8, #0x4, lsl #12   ; =0x4000
     6cc:      	ldr	s2, [x1, x9]
     6d0:      	mov	w11, #0x4000            ; =16384
     6d4:      	str	q2, [sp, #0x1f0]
     6d8:      	str	s2, [x14, x11]
     6dc:      	ldr	q2, [sp, #0x45a0]
     6e0:      	ldr	q4, [sp, #0x45b0]
     6e4:      	fmul.4s	v5, v4, v4
     6e8:      	fmul.4s	v4, v2, v2
     6ec:      	ldr	q2, [sp, #0x45c0]
     6f0:      	ldr	q6, [sp, #0x45d0]
     6f4:      	fmul.4s	v7, v6, v6
     6f8:      	fmul.4s	v6, v2, v2
     6fc:      	ldr	q2, [sp, #0x45e0]
     700:      	ldr	q19, [sp, #0x45f0]
     704:      	fmul.4s	v31, v19, v19
     708:      	fmul.4s	v8, v2, v2
     70c:      	ldr	q2, [sp, #0x4600]
     710:      	ldr	q19, [sp, #0x4610]
     714:      	fmul.4s	v10, v19, v19
     718:      	fmul.4s	v9, v2, v2
     71c:      	dup.2d	v11, x27
     720:      	mov.16b	v12, v11
     724:      	mov.16b	v13, v11
     728:      	mov.16b	v14, v11
     72c:      	mov.16b	v28, v25
     730:      	ldp	q24, q30, [sp, #0x260]
     734:      	ldp	q26, q25, [sp, #0x240]
     738:      	ldp	q29, q27, [sp, #0x220]
     73c:      	shl.2d	v2, v11, #0x5
     740:      	shl.2d	v20, v12, #0x5
     744:      	shl.2d	v21, v13, #0x5
     748:      	shl.2d	v19, v14, #0x5
     74c:      	add.2d	v15, v1, v19
     750:      	add.2d	v22, v15, v18
     754:      	add.2d	v19, v1, v2
     758:      	add.2d	v23, v19, v3
     75c:      	mov.d	x11, v23[1]
     760:      	add.2d	v2, v1, v21
     764:      	add.2d	v20, v1, v20
     768:      	fmov	x12, d23
     76c:      	add.2d	v21, v20, v16
     770:      	mov.d	x13, v21[1]
     774:      	fmov	x0, d21
     778:      	add.2d	v21, v2, v17
     77c:      	mov.d	x3, v21[1]
     780:      	fmov	x20, d21
     784:      	mov.d	x21, v22[1]
     788:      	ldr	s21, [x12]
     78c:      	ld1.s	{ v21 }[1], [x11]
     790:      	fmov	x11, d22
     794:      	ld1.s	{ v21 }[2], [x0]
     798:      	ld1.s	{ v21 }[3], [x13]
     79c:      	ldr	s22, [x20]
     7a0:      	ld1.s	{ v22 }[1], [x3]
     7a4:      	ld1.s	{ v22 }[2], [x11]
     7a8:      	ld1.s	{ v22 }[3], [x21]
     7ac:      	fmul.4s	v22, v22, v22
     7b0:      	fmul.4s	v21, v21, v21
     7b4:      	fadd.4s	v4, v4, v21
     7b8:      	fadd.4s	v5, v5, v22
     7bc:      	ldr	q21, [sp, #0x2b0]
     7c0:      	add.2d	v21, v15, v21
     7c4:      	ldr	q22, [sp, #0x2e0]
     7c8:      	add.2d	v22, v19, v22
     7cc:      	mov.d	x11, v22[1]
     7d0:      	fmov	x12, d22
     7d4:      	ldr	q22, [sp, #0x2d0]
     7d8:      	add.2d	v22, v20, v22
     7dc:      	mov.d	x13, v22[1]
     7e0:      	fmov	x0, d22
     7e4:      	ldr	q22, [sp, #0x2c0]
     7e8:      	add.2d	v22, v2, v22
     7ec:      	mov.d	x3, v22[1]
     7f0:      	mov.d	x20, v21[1]
     7f4:      	fmov	x21, d22
     7f8:      	ldr	s22, [x12]
     7fc:      	ld1.s	{ v22 }[1], [x11]
     800:      	ld1.s	{ v22 }[2], [x0]
     804:      	fmov	x11, d21
     808:      	ld1.s	{ v22 }[3], [x13]
     80c:      	ldr	s21, [x21]
     810:      	ld1.s	{ v21 }[1], [x3]
     814:      	ld1.s	{ v21 }[2], [x11]
     818:      	ld1.s	{ v21 }[3], [x20]
     81c:      	fmul.4s	v21, v21, v21
     820:      	fmul.4s	v22, v22, v22
     824:      	fadd.4s	v6, v6, v22
     828:      	fadd.4s	v7, v7, v21
     82c:      	add.2d	v21, v15, v24
     830:      	add.2d	v22, v19, v28
     834:      	mov.d	x11, v22[1]
     838:      	fmov	x12, d22
     83c:      	ldr	q22, [sp, #0x290]
     840:      	add.2d	v22, v20, v22
     844:      	mov.d	x13, v22[1]
     848:      	fmov	x0, d22
     84c:      	add.2d	v22, v2, v30
     850:      	mov.d	x3, v22[1]
     854:      	fmov	x20, d22
     858:      	mov.d	x21, v21[1]
     85c:      	ldr	s22, [x12]
     860:      	ld1.s	{ v22 }[1], [x11]
     864:      	ld1.s	{ v22 }[2], [x0]
     868:      	ld1.s	{ v22 }[3], [x13]
     86c:      	fmov	x11, d21
     870:      	fmul.4s	v21, v22, v22
     874:      	fadd.4s	v8, v8, v21
     878:      	ldr	s21, [x20]
     87c:      	ld1.s	{ v21 }[1], [x3]
     880:      	ld1.s	{ v21 }[2], [x11]
     884:      	ld1.s	{ v21 }[3], [x21]
     888:      	fmul.4s	v21, v21, v21
     88c:      	fadd.4s	v31, v31, v21
     890:      	add.2d	v20, v20, v26
     894:      	add.2d	v19, v19, v25
     898:      	mov.d	x11, v19[1]
     89c:      	mov.d	x12, v20[1]
     8a0:      	fmov	x13, d19
     8a4:      	fmov	x0, d20
     8a8:      	add.2d	v19, v15, v29
     8ac:      	add.2d	v2, v2, v27
     8b0:      	mov.d	x3, v2[1]
     8b4:      	fmov	x20, d2
     8b8:      	mov.d	x21, v19[1]
     8bc:      	ldr	s2, [x13]
     8c0:      	ld1.s	{ v2 }[1], [x11]
     8c4:      	fmov	x11, d19
     8c8:      	ld1.s	{ v2 }[2], [x0]
     8cc:      	ld1.s	{ v2 }[3], [x12]
     8d0:      	fmul.4s	v2, v2, v2
     8d4:      	fadd.4s	v9, v9, v2
     8d8:      	ldr	s2, [x20]
     8dc:      	ld1.s	{ v2 }[1], [x3]
     8e0:      	ld1.s	{ v2 }[2], [x11]
     8e4:      	ld1.s	{ v2 }[3], [x21]
     8e8:      	fmul.4s	v2, v2, v2
     8ec:      	fadd.4s	v10, v10, v2
     8f0:      	dup.2d	v2, x27
     8f4:      	add.2d	v13, v13, v2
     8f8:      	add.2d	v12, v12, v2
     8fc:      	add.2d	v14, v14, v2
     900:      	add.2d	v11, v11, v2
     904:      	fmov	x11, d11
     908:      	cmp	x11, #0x200
     90c:      	b.lt	0x73c <ltmp0+0x73c>
     910:      	mov	x12, #0x0               ; =0
     914:      	movi.2d	v2, #0000000000000000
     918:      	movi.2d	v19, #0000000000000000
     91c:      	movi.2d	v20, #0000000000000000
     920:      	movi.2d	v11, #0000000000000000
     924:      	add	x11, x2, x12, lsl #5
     928:      	ldp	q22, q21, [x11]
     92c:      	shl.2d	v23, v2, #0x5
     930:      	shl.2d	v12, v19, #0x5
     934:      	shl.2d	v13, v20, #0x5
     938:      	shl.2d	v14, v11, #0x5
     93c:      	add.2d	v14, v14, v18
     940:      	add.2d	v14, v0, v14
     944:      	add.2d	v13, v13, v17
     948:      	add.2d	v12, v12, v16
     94c:      	add.2d	v23, v23, v3
     950:      	add.2d	v23, v0, v23
     954:      	mov.d	x11, v23[1]
     958:      	fmov	x12, d23
     95c:      	str	s22, [x12]
     960:      	st1.s	{ v22 }[1], [x11]
     964:      	add.2d	v23, v0, v12
     968:      	mov.d	x11, v23[1]
     96c:      	fmov	x12, d23
     970:      	st1.s	{ v22 }[2], [x12]
     974:      	add.2d	v23, v0, v13
     978:      	st1.s	{ v22 }[3], [x11]
     97c:      	mov.d	x11, v23[1]
     980:      	fmov	x12, d23
     984:      	str	s21, [x12]
     988:      	st1.s	{ v21 }[1], [x11]
     98c:      	mov.d	x11, v14[1]
     990:      	fmov	x12, d14
     994:      	st1.s	{ v21 }[2], [x12]
     998:      	st1.s	{ v21 }[3], [x11]
     99c:      	dup.2d	v21, x28
     9a0:      	add.2d	v20, v20, v21
     9a4:      	add.2d	v19, v19, v21
     9a8:      	add.2d	v11, v11, v21
     9ac:      	add.2d	v2, v2, v21
     9b0:      	fmov	x12, d2
     9b4:      	cmp	x12, #0x200
     9b8:      	b.lt	0x924 <ltmp0+0x924>
     9bc:      	mov	x12, #0x0               ; =0
     9c0:      	ldr	q2, [sp, #0x1f0]
     9c4:      	fmul.4s	v2, v2, v2
     9c8:      	fadd.4s	v2, v2, v4
     9cc:      	mov.s	v4[0], v2[0]
     9d0:      	fadd.4s	v2, v7, v5
     9d4:      	fadd.4s	v4, v6, v4
     9d8:      	fadd.4s	v4, v8, v4
     9dc:      	fadd.4s	v2, v31, v2
     9e0:      	fadd.4s	v2, v10, v2
     9e4:      	fadd.4s	v4, v9, v4
     9e8:      	rev64.4s	v5, v4
     9ec:      	rev64.4s	v6, v2
     9f0:      	fadd.4s	v2, v2, v6
     9f4:      	fadd.4s	v4, v4, v5
     9f8:      	dup.4s	v5, v4[2]
     9fc:      	dup.4s	v6, v2[2]
     a00:      	fadd.4s	v2, v2, v6
     a04:      	fadd.4s	v4, v4, v5
     a08:      	fadd.4s	v2, v4, v2
     a0c:      	movi	d4, #0000000000000000
     a10:      	fadd	s4, s2, s4
     a14:      	mov	w11, #0x800             ; =2048
     a18:      	movk	w11, #0x4580, lsl #16
     a1c:      	fmov	s5, w11
     a20:      	ldr	q2, [sp, #0x4580]
     a24:      	ld1.s	{ v2 }[0], [x5]
     a28:      	fdiv	s4, s4, s5
     a2c:      	mov	w11, #0xc5ac            ; =50604
     a30:      	movk	w11, #0x3727, lsl #16
     a34:      	fmov	s5, w11
     a38:      	fadd	s4, s4, s5
     a3c:      	fsqrt	s4, s4
     a40:      	dup.4s	v5, v4[0]
     a44:      	str	q2, [sp, #0x4580]
     a48:      	add	x8, x17, x8
     a4c:      	movi.2d	v6, #0000000000000000
     a50:      	movi.2d	v7, #0000000000000000
     a54:      	movi.2d	v19, #0000000000000000
     a58:      	movi.2d	v20, #0000000000000000
     a5c:      	shl.2d	v21, v20, #0x5
     a60:      	shl.2d	v22, v19, #0x5
     a64:      	shl.2d	v23, v7, #0x5
     a68:      	shl.2d	v31, v6, #0x5
     a6c:      	orr.16b	v31, v31, v3
     a70:      	orr.16b	v23, v23, v16
     a74:      	orr.16b	v22, v22, v17
     a78:      	orr.16b	v21, v21, v18
     a7c:      	add.2d	v8, v1, v21
     a80:      	add.2d	v9, v1, v22
     a84:      	add.2d	v10, v1, v23
     a88:      	add.2d	v11, v1, v31
     a8c:      	mov.d	x11, v11[1]
     a90:      	mov.d	x13, v10[1]
     a94:      	mov.d	x0, v9[1]
     a98:      	fmov	x3, d11
     a9c:      	fmov	x20, d9
     aa0:      	mov.d	x21, v8[1]
     aa4:      	fmov	x30, d8
     aa8:      	ldr	s8, [x20]
     aac:      	ld1.s	{ v8 }[1], [x0]
     ab0:      	ld1.s	{ v8 }[2], [x30]
     ab4:      	ld1.s	{ v8 }[3], [x21]
     ab8:      	fmov	x0, d10
     abc:      	ldr	s9, [x3]
     ac0:      	ld1.s	{ v9 }[1], [x11]
     ac4:      	ld1.s	{ v9 }[2], [x0]
     ac8:      	ld1.s	{ v9 }[3], [x13]
     acc:      	fdiv.4s	v9, v9, v5
     ad0:      	fdiv.4s	v8, v8, v5
     ad4:      	add.2d	v21, v0, v21
     ad8:      	add.2d	v22, v0, v22
     adc:      	add.2d	v23, v0, v23
     ae0:      	add.2d	v31, v0, v31
     ae4:      	mov.d	x11, v31[1]
     ae8:      	fmov	x13, d31
     aec:      	mov.d	x0, v23[1]
     af0:      	mov.d	x3, v22[1]
     af4:      	mov.d	x20, v21[1]
     af8:      	fmov	x21, d23
     afc:      	ldr	s23, [x13]
     b00:      	ld1.s	{ v23 }[1], [x11]
     b04:      	ld1.s	{ v23 }[2], [x21]
     b08:      	fmov	x11, d22
     b0c:      	ld1.s	{ v23 }[3], [x0]
     b10:      	ldr	s22, [x11]
     b14:      	ld1.s	{ v22 }[1], [x3]
     b18:      	fmov	x11, d21
     b1c:      	ld1.s	{ v22 }[2], [x11]
     b20:      	ld1.s	{ v22 }[3], [x20]
     b24:      	fmul.4s	v21, v8, v22
     b28:      	fmul.4s	v22, v9, v23
     b2c:      	add	x11, x8, x12, lsl #5
     b30:      	stp	q22, q21, [x11]
     b34:      	dup.2d	v21, x28
     b38:      	add.2d	v19, v19, v21
     b3c:      	add.2d	v7, v7, v21
     b40:      	add.2d	v20, v20, v21
     b44:      	add.2d	v6, v6, v21
     b48:      	fmov	x12, d6
     b4c:      	cmp	x12, #0x200
     b50:      	b.lt	0xa5c <ltmp0+0xa5c>
     b54:      	mov	x12, #0x0               ; =0
     b58:      	ldr	q5, [sp, #0x85a0]
     b5c:      	fdiv.4s	v4, v5, v4
     b60:      	fmul.4s	v2, v2, v4
     b64:      	str	s2, [x17, x9]
     b68:      	orr	w9, w4, #0x2
     b6c:      	mov	w11, #0x4004            ; =16388
     b70:      	umull	x8, w9, w11
     b74:      	umaddl	x9, w9, w11, x1
     b78:      	add	x11, x9, x12
     b7c:      	ldp	q2, q4, [x11]
     b80:      	add	x11, x14, x12
     b84:      	stp	q2, q4, [x11]
     b88:      	add	x12, x12, #0x20
     b8c:      	cmp	x12, #0x4, lsl #12      ; =0x4000
     b90:      	b.ne	0xb78 <ltmp0+0xb78>
     b94:      	add	x9, x8, #0x4, lsl #12   ; =0x4000
     b98:      	ldr	s2, [x1, x9]
     b9c:      	mov	w11, #0x4000            ; =16384
     ba0:      	str	q2, [sp, #0x1f0]
     ba4:      	str	s2, [x14, x11]
     ba8:      	ldr	q2, [sp, #0x45a0]
     bac:      	ldr	q4, [sp, #0x45b0]
     bb0:      	fmul.4s	v5, v4, v4
     bb4:      	fmul.4s	v4, v2, v2
     bb8:      	ldr	q2, [sp, #0x45c0]
     bbc:      	ldr	q6, [sp, #0x45d0]
     bc0:      	fmul.4s	v7, v6, v6
     bc4:      	fmul.4s	v6, v2, v2
     bc8:      	ldr	q2, [sp, #0x45e0]
     bcc:      	ldr	q19, [sp, #0x45f0]
     bd0:      	fmul.4s	v31, v19, v19
     bd4:      	fmul.4s	v8, v2, v2
     bd8:      	ldr	q2, [sp, #0x4600]
     bdc:      	ldr	q19, [sp, #0x4610]
     be0:      	fmul.4s	v10, v19, v19
     be4:      	fmul.4s	v9, v2, v2
     be8:      	dup.2d	v11, x27
     bec:      	mov.16b	v12, v11
     bf0:      	mov.16b	v13, v11
     bf4:      	mov.16b	v14, v11
     bf8:      	ldr	q29, [sp, #0x290]
     bfc:      	ldp	q24, q30, [sp, #0x260]
     c00:      	ldp	q26, q25, [sp, #0x240]
     c04:      	ldp	q28, q27, [sp, #0x220]
     c08:      	shl.2d	v2, v11, #0x5
     c0c:      	shl.2d	v20, v12, #0x5
     c10:      	shl.2d	v21, v13, #0x5
     c14:      	shl.2d	v19, v14, #0x5
     c18:      	add.2d	v15, v1, v19
     c1c:      	add.2d	v22, v15, v18
     c20:      	add.2d	v19, v1, v2
     c24:      	add.2d	v23, v19, v3
     c28:      	mov.d	x11, v23[1]
     c2c:      	add.2d	v2, v1, v21
     c30:      	add.2d	v20, v1, v20
     c34:      	fmov	x12, d23
     c38:      	add.2d	v21, v20, v16
     c3c:      	mov.d	x13, v21[1]
     c40:      	fmov	x0, d21
     c44:      	add.2d	v21, v2, v17
     c48:      	mov.d	x3, v21[1]
     c4c:      	fmov	x20, d21
     c50:      	mov.d	x21, v22[1]
     c54:      	ldr	s21, [x12]
     c58:      	ld1.s	{ v21 }[1], [x11]
     c5c:      	fmov	x11, d22
     c60:      	ld1.s	{ v21 }[2], [x0]
     c64:      	ld1.s	{ v21 }[3], [x13]
     c68:      	ldr	s22, [x20]
     c6c:      	ld1.s	{ v22 }[1], [x3]
     c70:      	ld1.s	{ v22 }[2], [x11]
     c74:      	ld1.s	{ v22 }[3], [x21]
     c78:      	fmul.4s	v22, v22, v22
     c7c:      	fmul.4s	v21, v21, v21
     c80:      	fadd.4s	v4, v4, v21
     c84:      	fadd.4s	v5, v5, v22
     c88:      	ldr	q21, [sp, #0x2b0]
     c8c:      	add.2d	v21, v15, v21
     c90:      	ldr	q22, [sp, #0x2e0]
     c94:      	add.2d	v22, v19, v22
     c98:      	mov.d	x11, v22[1]
     c9c:      	fmov	x12, d22
     ca0:      	ldr	q22, [sp, #0x2d0]
     ca4:      	add.2d	v22, v20, v22
     ca8:      	mov.d	x13, v22[1]
     cac:      	fmov	x0, d22
     cb0:      	ldr	q22, [sp, #0x2c0]
     cb4:      	add.2d	v22, v2, v22
     cb8:      	mov.d	x3, v22[1]
     cbc:      	mov.d	x20, v21[1]
     cc0:      	fmov	x21, d22
     cc4:      	ldr	s22, [x12]
     cc8:      	ld1.s	{ v22 }[1], [x11]
     ccc:      	ld1.s	{ v22 }[2], [x0]
     cd0:      	fmov	x11, d21
     cd4:      	ld1.s	{ v22 }[3], [x13]
     cd8:      	ldr	s21, [x21]
     cdc:      	ld1.s	{ v21 }[1], [x3]
     ce0:      	ld1.s	{ v21 }[2], [x11]
     ce4:      	ld1.s	{ v21 }[3], [x20]
     ce8:      	fmul.4s	v21, v21, v21
     cec:      	fmul.4s	v22, v22, v22
     cf0:      	fadd.4s	v6, v6, v22
     cf4:      	fadd.4s	v7, v7, v21
     cf8:      	add.2d	v21, v15, v24
     cfc:      	ldr	q22, [sp, #0x2a0]
     d00:      	add.2d	v22, v19, v22
     d04:      	mov.d	x11, v22[1]
     d08:      	fmov	x12, d22
     d0c:      	add.2d	v22, v20, v29
     d10:      	mov.d	x13, v22[1]
     d14:      	fmov	x0, d22
     d18:      	add.2d	v22, v2, v30
     d1c:      	mov.d	x3, v22[1]
     d20:      	fmov	x20, d22
     d24:      	mov.d	x21, v21[1]
     d28:      	ldr	s22, [x12]
     d2c:      	ld1.s	{ v22 }[1], [x11]
     d30:      	ld1.s	{ v22 }[2], [x0]
     d34:      	ld1.s	{ v22 }[3], [x13]
     d38:      	fmov	x11, d21
     d3c:      	fmul.4s	v21, v22, v22
     d40:      	fadd.4s	v8, v8, v21
     d44:      	ldr	s21, [x20]
     d48:      	ld1.s	{ v21 }[1], [x3]
     d4c:      	ld1.s	{ v21 }[2], [x11]
     d50:      	ld1.s	{ v21 }[3], [x21]
     d54:      	fmul.4s	v21, v21, v21
     d58:      	fadd.4s	v31, v31, v21
     d5c:      	add.2d	v20, v20, v26
     d60:      	add.2d	v19, v19, v25
     d64:      	mov.d	x11, v19[1]
     d68:      	mov.d	x12, v20[1]
     d6c:      	fmov	x13, d19
     d70:      	fmov	x0, d20
     d74:      	add.2d	v19, v15, v28
     d78:      	add.2d	v2, v2, v27
     d7c:      	mov.d	x3, v2[1]
     d80:      	fmov	x20, d2
     d84:      	mov.d	x21, v19[1]
     d88:      	ldr	s2, [x13]
     d8c:      	ld1.s	{ v2 }[1], [x11]
     d90:      	fmov	x11, d19
     d94:      	ld1.s	{ v2 }[2], [x0]
     d98:      	ld1.s	{ v2 }[3], [x12]
     d9c:      	fmul.4s	v2, v2, v2
     da0:      	fadd.4s	v9, v9, v2
     da4:      	ldr	s2, [x20]
     da8:      	ld1.s	{ v2 }[1], [x3]
     dac:      	ld1.s	{ v2 }[2], [x11]
     db0:      	ld1.s	{ v2 }[3], [x21]
     db4:      	fmul.4s	v2, v2, v2
     db8:      	fadd.4s	v10, v10, v2
     dbc:      	dup.2d	v2, x27
     dc0:      	add.2d	v13, v13, v2
     dc4:      	add.2d	v12, v12, v2
     dc8:      	add.2d	v14, v14, v2
     dcc:      	add.2d	v11, v11, v2
     dd0:      	fmov	x11, d11
     dd4:      	cmp	x11, #0x200
     dd8:      	b.lt	0xc08 <ltmp0+0xc08>
     ddc:      	mov	x12, #0x0               ; =0
     de0:      	movi.2d	v2, #0000000000000000
     de4:      	movi.2d	v19, #0000000000000000
     de8:      	movi.2d	v20, #0000000000000000
     dec:      	movi.2d	v11, #0000000000000000
     df0:      	add	x11, x2, x12, lsl #5
     df4:      	ldp	q22, q21, [x11]
     df8:      	shl.2d	v23, v2, #0x5
     dfc:      	shl.2d	v12, v19, #0x5
     e00:      	shl.2d	v13, v20, #0x5
     e04:      	shl.2d	v14, v11, #0x5
     e08:      	add.2d	v14, v14, v18
     e0c:      	add.2d	v14, v0, v14
     e10:      	add.2d	v13, v13, v17
     e14:      	add.2d	v12, v12, v16
     e18:      	add.2d	v23, v23, v3
     e1c:      	add.2d	v23, v0, v23
     e20:      	mov.d	x11, v23[1]
     e24:      	fmov	x12, d23
     e28:      	str	s22, [x12]
     e2c:      	st1.s	{ v22 }[1], [x11]
     e30:      	add.2d	v23, v0, v12
     e34:      	mov.d	x11, v23[1]
     e38:      	fmov	x12, d23
     e3c:      	st1.s	{ v22 }[2], [x12]
     e40:      	add.2d	v23, v0, v13
     e44:      	st1.s	{ v22 }[3], [x11]
     e48:      	mov.d	x11, v23[1]
     e4c:      	fmov	x12, d23
     e50:      	str	s21, [x12]
     e54:      	st1.s	{ v21 }[1], [x11]
     e58:      	mov.d	x11, v14[1]
     e5c:      	fmov	x12, d14
     e60:      	st1.s	{ v21 }[2], [x12]
     e64:      	st1.s	{ v21 }[3], [x11]
     e68:      	dup.2d	v21, x28
     e6c:      	add.2d	v20, v20, v21
     e70:      	add.2d	v19, v19, v21
     e74:      	add.2d	v11, v11, v21
     e78:      	add.2d	v2, v2, v21
     e7c:      	fmov	x12, d2
     e80:      	cmp	x12, #0x200
     e84:      	b.lt	0xdf0 <ltmp0+0xdf0>
     e88:      	mov	x12, #0x0               ; =0
     e8c:      	ldr	q2, [sp, #0x1f0]
     e90:      	fmul.4s	v2, v2, v2
     e94:      	fadd.4s	v2, v2, v4
     e98:      	mov.s	v4[0], v2[0]
     e9c:      	fadd.4s	v2, v7, v5
     ea0:      	fadd.4s	v4, v6, v4
     ea4:      	fadd.4s	v4, v8, v4
     ea8:      	fadd.4s	v2, v31, v2
     eac:      	fadd.4s	v2, v10, v2
     eb0:      	fadd.4s	v4, v9, v4
     eb4:      	rev64.4s	v5, v4
     eb8:      	rev64.4s	v6, v2
     ebc:      	fadd.4s	v2, v2, v6
     ec0:      	fadd.4s	v4, v4, v5
     ec4:      	dup.4s	v5, v4[2]
     ec8:      	dup.4s	v6, v2[2]
     ecc:      	fadd.4s	v2, v2, v6
     ed0:      	fadd.4s	v4, v4, v5
     ed4:      	fadd.4s	v2, v4, v2
     ed8:      	movi	d4, #0000000000000000
     edc:      	fadd	s4, s2, s4
     ee0:      	mov	w11, #0x800             ; =2048
     ee4:      	movk	w11, #0x4580, lsl #16
     ee8:      	fmov	s5, w11
     eec:      	ldr	q2, [sp, #0x4580]
     ef0:      	ld1.s	{ v2 }[0], [x5]
     ef4:      	fdiv	s4, s4, s5
     ef8:      	mov	w11, #0xc5ac            ; =50604
     efc:      	movk	w11, #0x3727, lsl #16
     f00:      	fmov	s5, w11
     f04:      	fadd	s4, s4, s5
     f08:      	fsqrt	s4, s4
     f0c:      	dup.4s	v5, v4[0]
     f10:      	str	q2, [sp, #0x4580]
     f14:      	add	x8, x17, x8
     f18:      	movi.2d	v6, #0000000000000000
     f1c:      	movi.2d	v7, #0000000000000000
     f20:      	movi.2d	v19, #0000000000000000
     f24:      	movi.2d	v20, #0000000000000000
     f28:      	shl.2d	v21, v20, #0x5
     f2c:      	shl.2d	v22, v19, #0x5
     f30:      	shl.2d	v23, v7, #0x5
     f34:      	shl.2d	v31, v6, #0x5
     f38:      	orr.16b	v31, v31, v3
     f3c:      	orr.16b	v23, v23, v16
     f40:      	orr.16b	v22, v22, v17
     f44:      	orr.16b	v21, v21, v18
     f48:      	add.2d	v8, v1, v21
     f4c:      	add.2d	v9, v1, v22
     f50:      	add.2d	v10, v1, v23
     f54:      	add.2d	v11, v1, v31
     f58:      	mov.d	x11, v11[1]
     f5c:      	mov.d	x13, v10[1]
     f60:      	mov.d	x0, v9[1]
     f64:      	fmov	x3, d11
     f68:      	fmov	x20, d9
     f6c:      	mov.d	x21, v8[1]
     f70:      	fmov	x30, d8
     f74:      	ldr	s8, [x20]
     f78:      	ld1.s	{ v8 }[1], [x0]
     f7c:      	ld1.s	{ v8 }[2], [x30]
     f80:      	ld1.s	{ v8 }[3], [x21]
     f84:      	fmov	x0, d10
     f88:      	ldr	s9, [x3]
     f8c:      	ld1.s	{ v9 }[1], [x11]
     f90:      	ld1.s	{ v9 }[2], [x0]
     f94:      	ld1.s	{ v9 }[3], [x13]
     f98:      	fdiv.4s	v9, v9, v5
     f9c:      	fdiv.4s	v8, v8, v5
     fa0:      	add.2d	v21, v0, v21
     fa4:      	add.2d	v22, v0, v22
     fa8:      	add.2d	v23, v0, v23
     fac:      	add.2d	v31, v0, v31
     fb0:      	mov.d	x11, v31[1]
     fb4:      	fmov	x13, d31
     fb8:      	mov.d	x0, v23[1]
     fbc:      	mov.d	x3, v22[1]
     fc0:      	mov.d	x20, v21[1]
     fc4:      	fmov	x21, d23
     fc8:      	ldr	s23, [x13]
     fcc:      	ld1.s	{ v23 }[1], [x11]
     fd0:      	ld1.s	{ v23 }[2], [x21]
     fd4:      	fmov	x11, d22
     fd8:      	ld1.s	{ v23 }[3], [x0]
     fdc:      	ldr	s22, [x11]
     fe0:      	ld1.s	{ v22 }[1], [x3]
     fe4:      	fmov	x11, d21
     fe8:      	ld1.s	{ v22 }[2], [x11]
     fec:      	ld1.s	{ v22 }[3], [x20]
     ff0:      	fmul.4s	v21, v8, v22
     ff4:      	fmul.4s	v22, v9, v23
     ff8:      	add	x11, x8, x12, lsl #5
     ffc:      	stp	q22, q21, [x11]
    1000:      	dup.2d	v21, x28
    1004:      	add.2d	v19, v19, v21
    1008:      	add.2d	v7, v7, v21
    100c:      	add.2d	v20, v20, v21
    1010:      	add.2d	v6, v6, v21
    1014:      	fmov	x12, d6
    1018:      	cmp	x12, #0x200
    101c:      	b.lt	0xf28 <ltmp0+0xf28>
    1020:      	mov	x8, #0x0                ; =0
    1024:      	ldr	q5, [sp, #0x85a0]
    1028:      	fdiv.4s	v4, v5, v4
    102c:      	fmul.4s	v2, v2, v4
    1030:      	str	s2, [x17, x9]
    1034:      	orr	w9, w4, #0x3
    1038:      	mov	w12, #0x4004            ; =16388
    103c:      	umull	x11, w9, w12
    1040:      	umaddl	x9, w9, w12, x1
    1044:      	add	x12, x9, x8
    1048:      	ldp	q2, q4, [x12]
    104c:      	add	x12, x14, x8
    1050:      	stp	q2, q4, [x12]
    1054:      	add	x8, x8, #0x20
    1058:      	cmp	x8, #0x4, lsl #12       ; =0x4000
    105c:      	b.ne	0x1044 <ltmp0+0x1044>
    1060:      	add	x9, x11, #0x4, lsl #12  ; =0x4000
    1064:      	ldr	s2, [x1, x9]
    1068:      	str	q2, [sp, #0x200]
    106c:      	str	s2, [x14, x8]
    1070:      	ldr	q2, [sp, #0x45a0]
    1074:      	ldr	q4, [sp, #0x45b0]
    1078:      	fmul.4s	v4, v4, v4
    107c:      	fmul.4s	v2, v2, v2
    1080:      	ldr	q5, [sp, #0x45c0]
    1084:      	ldr	q6, [sp, #0x45d0]
    1088:      	fmul.4s	v6, v6, v6
    108c:      	fmul.4s	v5, v5, v5
    1090:      	ldr	q19, [sp, #0x45e0]
    1094:      	ldr	q7, [sp, #0x45f0]
    1098:      	fmul.4s	v7, v7, v7
    109c:      	fmul.4s	v31, v19, v19
    10a0:      	ldr	q19, [sp, #0x4600]
    10a4:      	ldr	q20, [sp, #0x4610]
    10a8:      	fmul.4s	v9, v20, v20
    10ac:      	fmul.4s	v8, v19, v19
    10b0:      	dup.2d	v11, x27
    10b4:      	mov.16b	v12, v11
    10b8:      	mov.16b	v13, v11
    10bc:      	mov.16b	v14, v11
    10c0:      	ldr	q29, [sp, #0x290]
    10c4:      	ldp	q24, q30, [sp, #0x260]
    10c8:      	ldp	q26, q25, [sp, #0x240]
    10cc:      	ldp	q28, q27, [sp, #0x220]
    10d0:      	shl.2d	v19, v11, #0x5
    10d4:      	shl.2d	v20, v12, #0x5
    10d8:      	shl.2d	v21, v13, #0x5
    10dc:      	shl.2d	v22, v14, #0x5
    10e0:      	add.2d	v15, v1, v22
    10e4:      	add.2d	v22, v15, v18
    10e8:      	add.2d	v19, v1, v19
    10ec:      	add.2d	v23, v19, v3
    10f0:      	mov.d	x8, v23[1]
    10f4:      	add.2d	v10, v1, v21
    10f8:      	add.2d	v20, v1, v20
    10fc:      	fmov	x12, d23
    1100:      	add.2d	v21, v20, v16
    1104:      	mov.d	x13, v21[1]
    1108:      	fmov	x0, d21
    110c:      	add.2d	v21, v10, v17
    1110:      	mov.d	x3, v21[1]
    1114:      	fmov	x20, d21
    1118:      	mov.d	x21, v22[1]
    111c:      	ldr	s21, [x12]
    1120:      	ld1.s	{ v21 }[1], [x8]
    1124:      	fmov	x8, d22
    1128:      	ld1.s	{ v21 }[2], [x0]
    112c:      	ld1.s	{ v21 }[3], [x13]
    1130:      	ldr	s22, [x20]
    1134:      	ld1.s	{ v22 }[1], [x3]
    1138:      	ld1.s	{ v22 }[2], [x8]
    113c:      	ld1.s	{ v22 }[3], [x21]
    1140:      	fmul.4s	v22, v22, v22
    1144:      	fmul.4s	v21, v21, v21
    1148:      	fadd.4s	v2, v2, v21
    114c:      	fadd.4s	v4, v4, v22
    1150:      	ldr	q21, [sp, #0x2b0]
    1154:      	add.2d	v21, v15, v21
    1158:      	ldr	q22, [sp, #0x2e0]
    115c:      	add.2d	v22, v19, v22
    1160:      	mov.d	x8, v22[1]
    1164:      	fmov	x12, d22
    1168:      	ldr	q22, [sp, #0x2d0]
    116c:      	add.2d	v22, v20, v22
    1170:      	mov.d	x13, v22[1]
    1174:      	fmov	x0, d22
    1178:      	ldr	q22, [sp, #0x2c0]
    117c:      	add.2d	v22, v10, v22
    1180:      	mov.d	x3, v22[1]
    1184:      	mov.d	x20, v21[1]
    1188:      	fmov	x21, d22
    118c:      	ldr	s22, [x12]
    1190:      	ld1.s	{ v22 }[1], [x8]
    1194:      	ld1.s	{ v22 }[2], [x0]
    1198:      	fmov	x8, d21
    119c:      	ld1.s	{ v22 }[3], [x13]
    11a0:      	ldr	s21, [x21]
    11a4:      	ld1.s	{ v21 }[1], [x3]
    11a8:      	ld1.s	{ v21 }[2], [x8]
    11ac:      	ld1.s	{ v21 }[3], [x20]
    11b0:      	fmul.4s	v21, v21, v21
    11b4:      	fmul.4s	v22, v22, v22
    11b8:      	fadd.4s	v5, v5, v22
    11bc:      	fadd.4s	v6, v6, v21
    11c0:      	add.2d	v21, v15, v24
    11c4:      	ldr	q22, [sp, #0x2a0]
    11c8:      	add.2d	v22, v19, v22
    11cc:      	mov.d	x8, v22[1]
    11d0:      	fmov	x12, d22
    11d4:      	add.2d	v22, v20, v29
    11d8:      	mov.d	x13, v22[1]
    11dc:      	fmov	x0, d22
    11e0:      	add.2d	v22, v10, v30
    11e4:      	mov.d	x3, v22[1]
    11e8:      	fmov	x20, d22
    11ec:      	mov.d	x21, v21[1]
    11f0:      	ldr	s22, [x12]
    11f4:      	ld1.s	{ v22 }[1], [x8]
    11f8:      	ld1.s	{ v22 }[2], [x0]
    11fc:      	ld1.s	{ v22 }[3], [x13]
    1200:      	fmov	x8, d21
    1204:      	fmul.4s	v21, v22, v22
    1208:      	fadd.4s	v31, v31, v21
    120c:      	ldr	s21, [x20]
    1210:      	ld1.s	{ v21 }[1], [x3]
    1214:      	ld1.s	{ v21 }[2], [x8]
    1218:      	ld1.s	{ v21 }[3], [x21]
    121c:      	fmul.4s	v21, v21, v21
    1220:      	fadd.4s	v7, v7, v21
    1224:      	add.2d	v20, v20, v26
    1228:      	add.2d	v19, v19, v25
    122c:      	mov.d	x8, v19[1]
    1230:      	mov.d	x12, v20[1]
    1234:      	fmov	x13, d19
    1238:      	fmov	x0, d20
    123c:      	add.2d	v19, v15, v28
    1240:      	add.2d	v20, v10, v27
    1244:      	mov.d	x3, v20[1]
    1248:      	fmov	x20, d20
    124c:      	mov.d	x21, v19[1]
    1250:      	ldr	s20, [x13]
    1254:      	ld1.s	{ v20 }[1], [x8]
    1258:      	fmov	x8, d19
    125c:      	ld1.s	{ v20 }[2], [x0]
    1260:      	ld1.s	{ v20 }[3], [x12]
    1264:      	fmul.4s	v19, v20, v20
    1268:      	fadd.4s	v8, v8, v19
    126c:      	ldr	s19, [x20]
    1270:      	ld1.s	{ v19 }[1], [x3]
    1274:      	ld1.s	{ v19 }[2], [x8]
    1278:      	ld1.s	{ v19 }[3], [x21]
    127c:      	fmul.4s	v19, v19, v19
    1280:      	fadd.4s	v9, v9, v19
    1284:      	dup.2d	v19, x27
    1288:      	add.2d	v13, v13, v19
    128c:      	add.2d	v12, v12, v19
    1290:      	add.2d	v14, v14, v19
    1294:      	add.2d	v11, v11, v19
    1298:      	fmov	x8, d11
    129c:      	cmp	x8, #0x200
    12a0:      	b.lt	0x10d0 <ltmp0+0x10d0>
    12a4:      	mov	x8, #0x0                ; =0
    12a8:      	movi.2d	v19, #0000000000000000
    12ac:      	movi.2d	v20, #0000000000000000
    12b0:      	movi.2d	v21, #0000000000000000
    12b4:      	movi.2d	v22, #0000000000000000
    12b8:      	add	x8, x2, x8, lsl #5
    12bc:      	ldp	q24, q23, [x8]
    12c0:      	shl.2d	v25, v19, #0x5
    12c4:      	shl.2d	v26, v20, #0x5
    12c8:      	shl.2d	v27, v21, #0x5
    12cc:      	shl.2d	v28, v22, #0x5
    12d0:      	add.2d	v28, v28, v18
    12d4:      	add.2d	v28, v0, v28
    12d8:      	add.2d	v27, v27, v17
    12dc:      	add.2d	v26, v26, v16
    12e0:      	add.2d	v25, v25, v3
    12e4:      	add.2d	v25, v0, v25
    12e8:      	mov.d	x8, v25[1]
    12ec:      	fmov	x12, d25
    12f0:      	str	s24, [x12]
    12f4:      	st1.s	{ v24 }[1], [x8]
    12f8:      	add.2d	v25, v0, v26
    12fc:      	mov.d	x8, v25[1]
    1300:      	fmov	x12, d25
    1304:      	st1.s	{ v24 }[2], [x12]
    1308:      	add.2d	v25, v0, v27
    130c:      	st1.s	{ v24 }[3], [x8]
    1310:      	mov.d	x8, v25[1]
    1314:      	fmov	x12, d25
    1318:      	str	s23, [x12]
    131c:      	st1.s	{ v23 }[1], [x8]
    1320:      	mov.d	x8, v28[1]
    1324:      	fmov	x12, d28
    1328:      	st1.s	{ v23 }[2], [x12]
    132c:      	st1.s	{ v23 }[3], [x8]
    1330:      	dup.2d	v23, x28
    1334:      	add.2d	v21, v21, v23
    1338:      	add.2d	v20, v20, v23
    133c:      	add.2d	v22, v22, v23
    1340:      	add.2d	v19, v19, v23
    1344:      	fmov	x8, d19
    1348:      	cmp	x8, #0x200
    134c:      	b.lt	0x12b8 <ltmp0+0x12b8>
    1350:      	mov	x8, #0x0                ; =0
    1354:      	ldr	q19, [sp, #0x200]
    1358:      	fmul.4s	v19, v19, v19
    135c:      	fadd.4s	v19, v19, v2
    1360:      	mov.s	v2[0], v19[0]
    1364:      	ldr	q19, [sp, #0x4580]
    1368:      	ld1.s	{ v19 }[0], [x5]
    136c:      	fadd.4s	v4, v6, v4
    1370:      	fadd.4s	v2, v5, v2
    1374:      	fadd.4s	v2, v31, v2
    1378:      	fadd.4s	v4, v7, v4
    137c:      	fadd.4s	v4, v9, v4
    1380:      	fadd.4s	v2, v8, v2
    1384:      	rev64.4s	v5, v2
    1388:      	rev64.4s	v6, v4
    138c:      	fadd.4s	v4, v4, v6
    1390:      	fadd.4s	v2, v2, v5
    1394:      	dup.4s	v5, v2[2]
    1398:      	dup.4s	v6, v4[2]
    139c:      	fadd.4s	v4, v4, v6
    13a0:      	fadd.4s	v2, v2, v5
    13a4:      	fadd.4s	v2, v2, v4
    13a8:      	movi	d11, #0000000000000000
    13ac:      	fadd	s2, s2, s11
    13b0:      	mov	w12, #0x800             ; =2048
    13b4:      	movk	w12, #0x4580, lsl #16
    13b8:      	fmov	s4, w12
    13bc:      	fdiv	s2, s2, s4
    13c0:      	mov	w12, #0xc5ac            ; =50604
    13c4:      	movk	w12, #0x3727, lsl #16
    13c8:      	fmov	s4, w12
    13cc:      	fadd	s2, s2, s4
    13d0:      	fsqrt	s2, s2
    13d4:      	dup.4s	v4, v2[0]
    13d8:      	str	q19, [sp, #0x4580]
    13dc:      	add	x11, x17, x11
    13e0:      	movi.2d	v5, #0000000000000000
    13e4:      	movi.2d	v6, #0000000000000000
    13e8:      	movi.2d	v7, #0000000000000000
    13ec:      	movi.2d	v20, #0000000000000000
    13f0:      	shl.2d	v21, v20, #0x5
    13f4:      	shl.2d	v22, v7, #0x5
    13f8:      	shl.2d	v23, v6, #0x5
    13fc:      	shl.2d	v24, v5, #0x5
    1400:      	orr.16b	v24, v24, v3
    1404:      	orr.16b	v23, v23, v16
    1408:      	orr.16b	v22, v22, v17
    140c:      	orr.16b	v21, v21, v18
    1410:      	add.2d	v25, v1, v21
    1414:      	add.2d	v26, v1, v22
    1418:      	add.2d	v27, v1, v23
    141c:      	add.2d	v28, v1, v24
    1420:      	mov.d	x12, v28[1]
    1424:      	mov.d	x13, v27[1]
    1428:      	mov.d	x0, v26[1]
    142c:      	fmov	x2, d28
    1430:      	fmov	x3, d26
    1434:      	mov.d	x20, v25[1]
    1438:      	fmov	x21, d25
    143c:      	ldr	s25, [x3]
    1440:      	ld1.s	{ v25 }[1], [x0]
    1444:      	ld1.s	{ v25 }[2], [x21]
    1448:      	ld1.s	{ v25 }[3], [x20]
    144c:      	fmov	x0, d27
    1450:      	ldr	s26, [x2]
    1454:      	ld1.s	{ v26 }[1], [x12]
    1458:      	ld1.s	{ v26 }[2], [x0]
    145c:      	ld1.s	{ v26 }[3], [x13]
    1460:      	fdiv.4s	v26, v26, v4
    1464:      	fdiv.4s	v25, v25, v4
    1468:      	add.2d	v21, v0, v21
    146c:      	add.2d	v22, v0, v22
    1470:      	add.2d	v23, v0, v23
    1474:      	add.2d	v24, v0, v24
    1478:      	mov.d	x12, v24[1]
    147c:      	fmov	x13, d24
    1480:      	mov.d	x0, v23[1]
    1484:      	mov.d	x2, v22[1]
    1488:      	mov.d	x3, v21[1]
    148c:      	fmov	x20, d23
    1490:      	ldr	s23, [x13]
    1494:      	ld1.s	{ v23 }[1], [x12]
    1498:      	ld1.s	{ v23 }[2], [x20]
    149c:      	fmov	x12, d22
    14a0:      	ld1.s	{ v23 }[3], [x0]
    14a4:      	ldr	s22, [x12]
    14a8:      	ld1.s	{ v22 }[1], [x2]
    14ac:      	fmov	x12, d21
    14b0:      	ld1.s	{ v22 }[2], [x12]
    14b4:      	ld1.s	{ v22 }[3], [x3]
    14b8:      	fmul.4s	v21, v25, v22
    14bc:      	fmul.4s	v22, v26, v23
    14c0:      	add	x8, x11, x8, lsl #5
    14c4:      	stp	q22, q21, [x8]
    14c8:      	dup.2d	v21, x28
    14cc:      	add.2d	v7, v7, v21
    14d0:      	add.2d	v6, v6, v21
    14d4:      	add.2d	v20, v20, v21
    14d8:      	add.2d	v5, v5, v21
    14dc:      	fmov	x8, d5
    14e0:      	cmp	x8, #0x200
    14e4:      	b.lt	0x13f0 <ltmp0+0x13f0>
    14e8:      	ldr	q4, [sp, #0x85a0]
    14ec:      	fdiv.4s	v2, v4, v2
    14f0:      	fmul.4s	v2, v19, v2
    14f4:      	str	s2, [x17, x9]
    14f8:      	adrp	x1, 0x1000 <ltmp0+0x1000>
    14fc:      	adrp	x4, 0x1000 <ltmp0+0x1000>
    1500:      	adrp	x17, 0x1000 <ltmp0+0x1000>
    1504:      	adrp	x5, 0x1000 <ltmp0+0x1000>
    1508:      	adrp	x6, 0x1000 <ltmp0+0x1000>
    150c:      	adrp	x7, 0x1000 <ltmp0+0x1000>
    1510:      	adrp	x19, 0x1000 <ltmp0+0x1000>
    1514:      	adrp	x20, 0x1000 <ltmp0+0x1000>
    1518:      	ldr	w13, [sp, #0x170]
    151c:      	ldr	w0, [sp, #0x16c]
    1520:      	ldr	x2, [sp, #0x178]
    1524:      	b	0xd0 <ltmp0+0xd0>
    1528:      	lsr	x8, x9, #3
    152c:      	str	x8, [sp, #0x2d0]
    1530:      	str	x9, [sp, #0x270]
    1534:      	cmp	x9, #0x8
    1538:      	b.lo	0x1adc <ltmp0+0x1adc>
    153c:      	mov	x2, #0x0                ; =0
    1540:      	ldr	x8, [sp, #0x150]
    1544:      	ldr	x10, [x8]
    1548:      	ldr	x20, [x8, #0x10]
    154c:      	ldr	x12, [x8, #0x30]
    1550:      	add	x8, x20, #0x4, lsl #12  ; =0x4000
    1554:      	str	x8, [sp, #0x2b0]
    1558:      	ldr	x8, [sp, #0x178]
    155c:      	lsl	w9, w8, #2
    1560:      	str	x9, [sp, #0x2a0]
    1564:      	and	x8, x8, #0x7ffffff
    1568:      	mov	w9, #0x10               ; =16
    156c:      	movk	w9, #0x1, lsl #16
    1570:      	str	x10, [sp, #0x2c0]
    1574:      	umaddl	x21, w8, w9, x10
    1578:      	str	x12, [sp, #0x290]
    157c:      	mov	x25, x22
    1580:      	mov	x12, #0x0               ; =0
    1584:      	ldr	x8, [sp, #0x2a0]
    1588:      	add	w8, w2, w8
    158c:      	and	x8, x8, #0x1fffffff
    1590:      	add	x8, x8, x8, lsl #12
    1594:      	lsl	x8, x8, #2
    1598:      	add	x0, x21, x12
    159c:      	ldp	q2, q4, [x0]
    15a0:      	add	x0, x14, x12
    15a4:      	stp	q2, q4, [x0]
    15a8:      	add	x12, x12, #0x20
    15ac:      	cmp	x12, #0x4, lsl #12      ; =0x4000
    15b0:      	b.ne	0x1598 <ltmp0+0x1598>
    15b4:      	add	x10, x8, #0x4, lsl #12  ; =0x4000
    15b8:      	ldr	x9, [sp, #0x2c0]
    15bc:      	str	x10, [sp, #0x2e0]
    15c0:      	ldr	s6, [x9, x10]
    15c4:      	mov	w9, #0x4000             ; =16384
    15c8:      	str	s6, [x14, x9]
    15cc:      	ldr	q2, [sp, #0x45a0]
    15d0:      	ldr	q4, [sp, #0x45b0]
    15d4:      	fmul.4s	v16, v4, v4
    15d8:      	fmul.4s	v7, v2, v2
    15dc:      	ldr	q2, [sp, #0x45c0]
    15e0:      	ldr	q4, [sp, #0x45d0]
    15e4:      	fmul.4s	v18, v4, v4
    15e8:      	fmul.4s	v17, v2, v2
    15ec:      	ldr	q2, [sp, #0x45e0]
    15f0:      	ldr	q4, [sp, #0x45f0]
    15f4:      	fmul.4s	v19, v4, v4
    15f8:      	fmul.4s	v20, v2, v2
    15fc:      	ldr	q2, [sp, #0x4600]
    1600:      	ldr	q4, [sp, #0x4610]
    1604:      	fmul.4s	v22, v4, v4
    1608:      	fmul.4s	v21, v2, v2
    160c:      	dup.2d	v23, x27
    1610:      	mov.16b	v24, v23
    1614:      	mov.16b	v25, v23
    1618:      	mov.16b	v26, v23
    161c:      	adrp	x4, 0x1000 <ltmp0+0x1000>
    1620:      	adrp	x17, 0x1000 <ltmp0+0x1000>
    1624:      	adrp	x5, 0x1000 <ltmp0+0x1000>
    1628:      	adrp	x6, 0x1000 <ltmp0+0x1000>
    162c:      	adrp	x7, 0x1000 <ltmp0+0x1000>
    1630:      	adrp	x19, 0x1000 <ltmp0+0x1000>
    1634:      	adrp	x22, 0x1000 <ltmp0+0x1000>
    1638:      	adrp	x23, 0x1000 <ltmp0+0x1000>
    163c:      	mov	x24, x25
    1640:      	adrp	x26, 0x1000 <ltmp0+0x1000>
    1644:      	mov	w12, #0x4               ; =4
    1648:      	adrp	x27, 0x1000 <ltmp0+0x1000>
    164c:      	adrp	x13, 0x1000 <ltmp0+0x1000>
    1650:      	adrp	x14, 0x1000 <ltmp0+0x1000>
    1654:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1658:      	shl.2d	v2, v23, #0x5
    165c:      	add.2d	v27, v1, v2
    1660:      	add.2d	v31, v27, v3
    1664:      	mov.d	x0, v31[1]
    1668:      	ldr	q2, [x16]
    166c:      	shl.2d	v4, v24, #0x5
    1670:      	add.2d	v28, v1, v4
    1674:      	add.2d	v8, v28, v2
    1678:      	mov.d	x11, v8[1]
    167c:      	ldr	q4, [x4]
    1680:      	shl.2d	v5, v25, #0x5
    1684:      	add.2d	v29, v1, v5
    1688:      	add.2d	v9, v29, v4
    168c:      	mov.d	x30, v9[1]
    1690:      	ldr	q5, [x5]
    1694:      	shl.2d	v30, v26, #0x5
    1698:      	add.2d	v30, v1, v30
    169c:      	add.2d	v10, v30, v5
    16a0:      	mov.d	x9, v10[1]
    16a4:      	fmov	x3, d31
    16a8:      	ldr	s31, [x3]
    16ac:      	fmov	x3, d8
    16b0:      	fmov	x1, d9
    16b4:      	ld1.s	{ v31 }[1], [x0]
    16b8:      	fmov	x0, d10
    16bc:      	ld1.s	{ v31 }[2], [x3]
    16c0:      	ld1.s	{ v31 }[3], [x11]
    16c4:      	ldr	s8, [x1]
    16c8:      	ld1.s	{ v8 }[1], [x30]
    16cc:      	ld1.s	{ v8 }[2], [x0]
    16d0:      	ld1.s	{ v8 }[3], [x9]
    16d4:      	fmul.4s	v8, v8, v8
    16d8:      	fmul.4s	v31, v31, v31
    16dc:      	fadd.4s	v7, v7, v31
    16e0:      	fadd.4s	v16, v16, v8
    16e4:      	ldr	q31, [x17]
    16e8:      	ldr	q8, [x6]
    16ec:      	ldr	q9, [x7]
    16f0:      	ldr	q10, [x19]
    16f4:      	add.2d	v10, v30, v10
    16f8:      	add.2d	v9, v29, v9
    16fc:      	add.2d	v8, v28, v8
    1700:      	add.2d	v31, v27, v31
    1704:      	mov.d	x9, v31[1]
    1708:      	fmov	x11, d31
    170c:      	mov.d	x0, v8[1]
    1710:      	fmov	x1, d8
    1714:      	mov.d	x3, v9[1]
    1718:      	fmov	x30, d9
    171c:      	mov.d	x15, v10[1]
    1720:      	ldr	s31, [x11]
    1724:      	ld1.s	{ v31 }[1], [x9]
    1728:      	ld1.s	{ v31 }[2], [x1]
    172c:      	ld1.s	{ v31 }[3], [x0]
    1730:      	fmov	x9, d10
    1734:      	ldr	s8, [x30]
    1738:      	ld1.s	{ v8 }[1], [x3]
    173c:      	ld1.s	{ v8 }[2], [x9]
    1740:      	ld1.s	{ v8 }[3], [x15]
    1744:      	fmul.4s	v8, v8, v8
    1748:      	fmul.4s	v31, v31, v31
    174c:      	fadd.4s	v17, v17, v31
    1750:      	fadd.4s	v18, v18, v8
    1754:      	ldr	q31, [x22]
    1758:      	ldr	q8, [x23]
    175c:      	ldr	q9, [x24]
    1760:      	ldr	q10, [x26]
    1764:      	add.2d	v10, v30, v10
    1768:      	add.2d	v9, v29, v9
    176c:      	add.2d	v8, v28, v8
    1770:      	add.2d	v31, v27, v31
    1774:      	mov.d	x9, v31[1]
    1778:      	mov.d	x11, v8[1]
    177c:      	fmov	x15, d31
    1780:      	fmov	x0, d8
    1784:      	mov.d	x1, v9[1]
    1788:      	mov.d	x3, v10[1]
    178c:      	fmov	x30, d9
    1790:      	ldr	s31, [x15]
    1794:      	ld1.s	{ v31 }[1], [x9]
    1798:      	ld1.s	{ v31 }[2], [x0]
    179c:      	fmov	x9, d10
    17a0:      	ld1.s	{ v31 }[3], [x11]
    17a4:      	ldr	s8, [x30]
    17a8:      	ld1.s	{ v8 }[1], [x1]
    17ac:      	ld1.s	{ v8 }[2], [x9]
    17b0:      	ld1.s	{ v8 }[3], [x3]
    17b4:      	fmul.4s	v8, v8, v8
    17b8:      	fmul.4s	v31, v31, v31
    17bc:      	fadd.4s	v20, v20, v31
    17c0:      	fadd.4s	v19, v19, v8
    17c4:      	ldr	q31, [x27]
    17c8:      	ldr	q8, [x13]
    17cc:      	ldr	q9, [x14]
    17d0:      	ldr	q10, [x10]
    17d4:      	add.2d	v30, v30, v10
    17d8:      	add.2d	v29, v29, v9
    17dc:      	add.2d	v28, v28, v8
    17e0:      	add.2d	v27, v27, v31
    17e4:      	mov.d	x9, v27[1]
    17e8:      	fmov	x11, d27
    17ec:      	mov.d	x15, v28[1]
    17f0:      	fmov	x0, d28
    17f4:      	mov.d	x1, v29[1]
    17f8:      	fmov	x3, d29
    17fc:      	mov.d	x30, v30[1]
    1800:      	ldr	s27, [x11]
    1804:      	ld1.s	{ v27 }[1], [x9]
    1808:      	fmov	x9, d30
    180c:      	ld1.s	{ v27 }[2], [x0]
    1810:      	ld1.s	{ v27 }[3], [x15]
    1814:      	ldr	s28, [x3]
    1818:      	ld1.s	{ v28 }[1], [x1]
    181c:      	ld1.s	{ v28 }[2], [x9]
    1820:      	ld1.s	{ v28 }[3], [x30]
    1824:      	fmul.4s	v28, v28, v28
    1828:      	fmul.4s	v27, v27, v27
    182c:      	fadd.4s	v21, v21, v27
    1830:      	fadd.4s	v22, v22, v28
    1834:      	dup.2d	v27, x12
    1838:      	add.2d	v25, v25, v27
    183c:      	add.2d	v24, v24, v27
    1840:      	add.2d	v26, v26, v27
    1844:      	add.2d	v23, v23, v27
    1848:      	fmov	x9, d23
    184c:      	cmp	x9, #0x200
    1850:      	b.lt	0x1658 <ltmp0+0x1658>
    1854:      	mov	x0, #0x0                ; =0
    1858:      	movi.2d	v23, #0000000000000000
    185c:      	movi.2d	v24, #0000000000000000
    1860:      	movi.2d	v25, #0000000000000000
    1864:      	movi.2d	v26, #0000000000000000
    1868:      	add	x9, x20, x0, lsl #5
    186c:      	ldp	q28, q27, [x9]
    1870:      	shl.2d	v29, v23, #0x5
    1874:      	shl.2d	v30, v24, #0x5
    1878:      	shl.2d	v31, v25, #0x5
    187c:      	shl.2d	v8, v26, #0x5
    1880:      	add.2d	v8, v8, v5
    1884:      	add.2d	v8, v0, v8
    1888:      	add.2d	v31, v31, v4
    188c:      	add.2d	v30, v30, v2
    1890:      	add.2d	v29, v29, v3
    1894:      	add.2d	v29, v0, v29
    1898:      	mov.d	x9, v29[1]
    189c:      	fmov	x11, d29
    18a0:      	str	s28, [x11]
    18a4:      	st1.s	{ v28 }[1], [x9]
    18a8:      	add.2d	v29, v0, v30
    18ac:      	mov.d	x9, v29[1]
    18b0:      	fmov	x11, d29
    18b4:      	st1.s	{ v28 }[2], [x11]
    18b8:      	add.2d	v29, v0, v31
    18bc:      	st1.s	{ v28 }[3], [x9]
    18c0:      	mov.d	x9, v29[1]
    18c4:      	fmov	x11, d29
    18c8:      	str	s27, [x11]
    18cc:      	st1.s	{ v27 }[1], [x9]
    18d0:      	mov.d	x9, v8[1]
    18d4:      	fmov	x11, d8
    18d8:      	st1.s	{ v27 }[2], [x11]
    18dc:      	st1.s	{ v27 }[3], [x9]
    18e0:      	dup.2d	v27, x28
    18e4:      	add.2d	v25, v25, v27
    18e8:      	add.2d	v24, v24, v27
    18ec:      	add.2d	v26, v26, v27
    18f0:      	add.2d	v23, v23, v27
    18f4:      	fmov	x0, d23
    18f8:      	cmp	x0, #0x200
    18fc:      	b.lt	0x1868 <ltmp0+0x1868>
    1900:      	mov	x0, #0x0                ; =0
    1904:      	fmul.4s	v6, v6, v6
    1908:      	fadd.4s	v6, v6, v7
    190c:      	mov.s	v7[0], v6[0]
    1910:      	fadd.4s	v6, v18, v16
    1914:      	fadd.4s	v7, v17, v7
    1918:      	fadd.4s	v7, v20, v7
    191c:      	fadd.4s	v6, v19, v6
    1920:      	fadd.4s	v6, v22, v6
    1924:      	fadd.4s	v7, v21, v7
    1928:      	rev64.4s	v16, v7
    192c:      	rev64.4s	v17, v6
    1930:      	fadd.4s	v6, v6, v17
    1934:      	fadd.4s	v7, v7, v16
    1938:      	dup.4s	v16, v7[2]
    193c:      	dup.4s	v17, v6[2]
    1940:      	fadd.4s	v6, v6, v17
    1944:      	fadd.4s	v7, v7, v16
    1948:      	fadd.4s	v6, v7, v6
    194c:      	fadd	s7, s6, s11
    1950:      	mov	w9, #0x800              ; =2048
    1954:      	movk	w9, #0x4580, lsl #16
    1958:      	fmov	s16, w9
    195c:      	ldr	q6, [sp, #0x4580]
    1960:      	ldr	x9, [sp, #0x2b0]
    1964:      	ld1.s	{ v6 }[0], [x9]
    1968:      	fdiv	s7, s7, s16
    196c:      	mov	w9, #0xc5ac             ; =50604
    1970:      	movk	w9, #0x3727, lsl #16
    1974:      	fmov	s16, w9
    1978:      	fadd	s7, s7, s16
    197c:      	fsqrt	s7, s7
    1980:      	dup.4s	v16, v7[0]
    1984:      	str	q6, [sp, #0x4580]
    1988:      	ldr	x12, [sp, #0x290]
    198c:      	add	x8, x12, x8
    1990:      	movi.2d	v17, #0000000000000000
    1994:      	movi.2d	v18, #0000000000000000
    1998:      	movi.2d	v19, #0000000000000000
    199c:      	movi.2d	v20, #0000000000000000
    19a0:      	mov	x22, x25
    19a4:      	adrp	x26, 0x1000 <ltmp0+0x1000>
    19a8:      	add	x14, sp, #0x4, lsl #12  ; =0x4000
    19ac:      	add	x14, x14, #0x5a0
    19b0:      	mov	w27, #0x4               ; =4
    19b4:      	shl.2d	v21, v20, #0x5
    19b8:      	shl.2d	v22, v19, #0x5
    19bc:      	shl.2d	v23, v18, #0x5
    19c0:      	shl.2d	v24, v17, #0x5
    19c4:      	orr.16b	v24, v24, v3
    19c8:      	orr.16b	v23, v23, v2
    19cc:      	orr.16b	v22, v22, v4
    19d0:      	orr.16b	v21, v21, v5
    19d4:      	add.2d	v25, v1, v21
    19d8:      	add.2d	v26, v1, v22
    19dc:      	add.2d	v27, v1, v23
    19e0:      	add.2d	v28, v1, v24
    19e4:      	mov.d	x9, v28[1]
    19e8:      	mov.d	x11, v27[1]
    19ec:      	mov.d	x15, v26[1]
    19f0:      	fmov	x1, d28
    19f4:      	fmov	x3, d26
    19f8:      	mov.d	x30, v25[1]
    19fc:      	fmov	x16, d25
    1a00:      	ldr	s25, [x3]
    1a04:      	ld1.s	{ v25 }[1], [x15]
    1a08:      	ld1.s	{ v25 }[2], [x16]
    1a0c:      	ld1.s	{ v25 }[3], [x30]
    1a10:      	fmov	x15, d27
    1a14:      	ldr	s26, [x1]
    1a18:      	ld1.s	{ v26 }[1], [x9]
    1a1c:      	ld1.s	{ v26 }[2], [x15]
    1a20:      	ld1.s	{ v26 }[3], [x11]
    1a24:      	fdiv.4s	v26, v26, v16
    1a28:      	fdiv.4s	v25, v25, v16
    1a2c:      	add.2d	v21, v0, v21
    1a30:      	add.2d	v22, v0, v22
    1a34:      	add.2d	v23, v0, v23
    1a38:      	add.2d	v24, v0, v24
    1a3c:      	mov.d	x9, v24[1]
    1a40:      	fmov	x11, d24
    1a44:      	mov.d	x15, v23[1]
    1a48:      	mov.d	x16, v22[1]
    1a4c:      	mov.d	x1, v21[1]
    1a50:      	fmov	x3, d23
    1a54:      	ldr	s23, [x11]
    1a58:      	ld1.s	{ v23 }[1], [x9]
    1a5c:      	ld1.s	{ v23 }[2], [x3]
    1a60:      	fmov	x9, d22
    1a64:      	ld1.s	{ v23 }[3], [x15]
    1a68:      	ldr	s22, [x9]
    1a6c:      	ld1.s	{ v22 }[1], [x16]
    1a70:      	fmov	x9, d21
    1a74:      	ld1.s	{ v22 }[2], [x9]
    1a78:      	ld1.s	{ v22 }[3], [x1]
    1a7c:      	fmul.4s	v21, v25, v22
    1a80:      	fmul.4s	v22, v26, v23
    1a84:      	add	x9, x8, x0, lsl #5
    1a88:      	stp	q22, q21, [x9]
    1a8c:      	dup.2d	v21, x28
    1a90:      	add.2d	v19, v19, v21
    1a94:      	add.2d	v18, v18, v21
    1a98:      	add.2d	v20, v20, v21
    1a9c:      	add.2d	v17, v17, v21
    1aa0:      	fmov	x0, d17
    1aa4:      	cmp	x0, #0x200
    1aa8:      	b.lt	0x19b4 <ltmp0+0x19b4>
    1aac:      	ldr	q2, [sp, #0x85a0]
    1ab0:      	fdiv.4s	v2, v2, v7
    1ab4:      	fmul.4s	v2, v6, v2
    1ab8:      	ldr	x8, [sp, #0x2e0]
    1abc:      	str	s2, [x12, x8]
    1ac0:      	add	x2, x2, #0x1
    1ac4:      	mov	w8, #0x4004             ; =16388
    1ac8:      	add	x21, x21, x8
    1acc:      	ldr	x8, [sp, #0x2d0]
    1ad0:      	cmp	x2, x8
    1ad4:      	adrp	x16, 0x1000 <ltmp0+0x1000>
    1ad8:      	b.ne	0x157c <ltmp0+0x157c>
    1adc:      	ldr	x8, [sp, #0x270]
    1ae0:      	and	w8, w8, #0x7
    1ae4:      	ldr	w15, [sp, #0x174]
    1ae8:      	adrp	x1, 0x1000 <ltmp0+0x1000>
    1aec:      	adrp	x4, 0x1000 <ltmp0+0x1000>
    1af0:      	adrp	x17, 0x1000 <ltmp0+0x1000>
    1af4:      	adrp	x5, 0x1000 <ltmp0+0x1000>
    1af8:      	adrp	x6, 0x1000 <ltmp0+0x1000>
    1afc:      	adrp	x7, 0x1000 <ltmp0+0x1000>
    1b00:      	adrp	x19, 0x1000 <ltmp0+0x1000>
    1b04:      	adrp	x20, 0x1000 <ltmp0+0x1000>
    1b08:      	adrp	x23, 0x1000 <ltmp0+0x1000>
    1b0c:      	adrp	x24, 0x1000 <ltmp0+0x1000>
    1b10:      	adrp	x25, 0x1000 <ltmp0+0x1000>
    1b14:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1b18:      	ldr	w13, [sp, #0x170]
    1b1c:      	ldr	w0, [sp, #0x16c]
    1b20:      	ldr	x2, [sp, #0x178]
    1b24:      	cbz	w8, 0xd0 <ltmp0+0xd0>
    1b28:      	dup.4s	v2, w8
    1b2c:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1b30:      	ldr	q4, [x8]
    1b34:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1b38:      	ldr	q5, [x8]
    1b3c:      	cmhi.4s	v8, v2, v5
    1b40:      	cmhi.4s	v31, v2, v4
    1b44:      	uzp1.8h	v4, v31, v8
    1b48:      	umaxv.8h	h2, v4
    1b4c:      	fmov	w8, s2
    1b50:      	tbz	w8, #0x0, 0xd0 <ltmp0+0xd0>
    1b54:      	mov	x9, #0x0                ; =0
    1b58:      	ldr	x11, [sp, #0x150]
    1b5c:      	ldr	x8, [x11]
    1b60:      	ldr	x20, [x11, #0x10]
    1b64:      	ldr	x11, [x11, #0x30]
    1b68:      	str	x11, [sp, #0x138]
    1b6c:      	adrp	x11, 0x1000 <ltmp0+0x1000>
    1b70:      	ldr	q2, [x11]
    1b74:      	str	q4, [sp, #0x90]
    1b78:      	and.16b	v2, v4, v2
    1b7c:      	addv.8h	h16, v2
    1b80:      	ubfiz	w11, w2, #2, #27
    1b84:      	ldr	x12, [sp, #0x2d0]
    1b88:      	orr	w11, w11, w12
    1b8c:      	fmov	w12, s16
    1b90:      	and	w5, w12, #0xff
    1b94:      	dup.4s	v2, w11
    1b98:      	and.16b	v6, v31, v2
    1b9c:      	and.16b	v5, v8, v2
    1ba0:      	ushll2.2d	v2, v5, #0x0
    1ba4:      	ushll2.2d	v4, v6, #0x0
    1ba8:      	ushll.2d	v5, v5, #0x0
    1bac:      	ushll.2d	v7, v6, #0x0
    1bb0:      	fmov	x11, d7
    1bb4:      	mov	w12, #0x4004            ; =16388
    1bb8:      	umaddl	x11, w11, w12, x8
    1bbc:      	b	0x1be0 <ltmp0+0x1be0>
    1bc0:      	add	x12, x14, x9
    1bc4:      	ldp	q18, q19, [x12]
    1bc8:      	bif.16b	v17, v19, v8
    1bcc:      	bif.16b	v6, v18, v31
    1bd0:      	stp	q6, q17, [x12]
    1bd4:      	add	x9, x9, #0x20
    1bd8:      	cmp	x9, #0x4, lsl #12       ; =0x4000
    1bdc:      	b.eq	0x1c78 <ltmp0+0x1c78>
    1be0:      	fmov	w13, s16
    1be4:      	add	x12, x11, x9
    1be8:      	movi.2d	v6, #0000000000000000
    1bec:      	movi.2d	v17, #0000000000000000
    1bf0:      	tbnz	w13, #0x0, 0x1c18 <ltmp0+0x1c18>
    1bf4:      	and	w13, w13, #0xff
    1bf8:      	tbnz	w13, #0x1, 0x1c24 <ltmp0+0x1c24>
    1bfc:      	tbnz	w13, #0x2, 0x1c30 <ltmp0+0x1c30>
    1c00:      	tbnz	w13, #0x3, 0x1c3c <ltmp0+0x1c3c>
    1c04:      	tbnz	w13, #0x4, 0x1c48 <ltmp0+0x1c48>
    1c08:      	tbnz	w13, #0x5, 0x1c54 <ltmp0+0x1c54>
    1c0c:      	tbnz	w13, #0x6, 0x1c60 <ltmp0+0x1c60>
    1c10:      	tbz	w13, #0x7, 0x1bc0 <ltmp0+0x1bc0>
    1c14:      	b	0x1c6c <ltmp0+0x1c6c>
    1c18:      	ldr	s6, [x12]
    1c1c:      	and	w13, w13, #0xff
    1c20:      	tbz	w13, #0x1, 0x1bfc <ltmp0+0x1bfc>
    1c24:      	add	x15, x12, #0x4
    1c28:      	ld1.s	{ v6 }[1], [x15]
    1c2c:      	tbz	w13, #0x2, 0x1c00 <ltmp0+0x1c00>
    1c30:      	add	x15, x12, #0x8
    1c34:      	ld1.s	{ v6 }[2], [x15]
    1c38:      	tbz	w13, #0x3, 0x1c04 <ltmp0+0x1c04>
    1c3c:      	add	x15, x12, #0xc
    1c40:      	ld1.s	{ v6 }[3], [x15]
    1c44:      	tbz	w13, #0x4, 0x1c08 <ltmp0+0x1c08>
    1c48:      	add	x15, x12, #0x10
    1c4c:      	ld1.s	{ v17 }[0], [x15]
    1c50:      	tbz	w13, #0x5, 0x1c0c <ltmp0+0x1c0c>
    1c54:      	add	x15, x12, #0x14
    1c58:      	ld1.s	{ v17 }[1], [x15]
    1c5c:      	tbz	w13, #0x6, 0x1c10 <ltmp0+0x1c10>
    1c60:      	add	x15, x12, #0x18
    1c64:      	ld1.s	{ v17 }[2], [x15]
    1c68:      	tbz	w13, #0x7, 0x1bc0 <ltmp0+0x1bc0>
    1c6c:      	add	x12, x12, #0x1c
    1c70:      	ld1.s	{ v17 }[3], [x12]
    1c74:      	b	0x1bc0 <ltmp0+0x1bc0>
    1c78:      	xtn.4h	v6, v31
    1c7c:      	uzp1.8b	v19, v6, v0
    1c80:      	sshll.2d	v6, v31, #0x0
    1c84:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1c88:      	ldr	q17, [x9]
    1c8c:      	and.16b	v20, v6, v17
    1c90:      	movi.2d	v21, #0000000000000000
    1c94:      	mov.b	v21[0], v19[0]
    1c98:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1c9c:      	ldr	d17, [x9]
    1ca0:      	str	d17, [sp, #0xb8]
    1ca4:      	and.8b	v17, v21, v17
    1ca8:      	addv.8b	b17, v17
    1cac:      	fmov	w9, s17
    1cb0:      	umaxv.8b	b17, v21
    1cb4:      	fmov	w11, s17
    1cb8:      	rbit	w12, w9
    1cbc:      	clz	w12, w12
    1cc0:      	tst	w11, #0x1
    1cc4:      	csel	w4, w12, wzr, ne
    1cc8:      	mov	w12, #0x1000            ; =4096
    1ccc:      	dup.2d	v18, x12
    1cd0:      	str	q20, [sp, #0x60]
    1cd4:      	orr.16b	v22, v20, v18
    1cd8:      	mov	w12, #0x1001            ; =4097
    1cdc:      	dup.2s	v17, w12
    1ce0:      	xtn.2s	v7, v7
    1ce4:      	str	q22, [sp, #0xc0]
    1ce8:      	umlal.2d	v22, v7, v17
    1cec:      	movi.2d	v20, #0000000000000000
    1cf0:      	mov.b	v20[0], v19[0]
    1cf4:      	ushll.2d	v19, v20, #0x0
    1cf8:      	shl.2d	v19, v19, #0x3f
    1cfc:      	cmlt.2d	v19, v19, #0
    1d00:      	str	q22, [sp, #0x110]
    1d04:      	and.16b	v19, v19, v22
    1d08:      	movi.2d	v20, #0000000000000000
    1d0c:      	str	q20, [sp, #0x560]
    1d10:      	str	q20, [sp, #0x550]
    1d14:      	str	q20, [sp, #0x540]
    1d18:      	str	q19, [sp, #0x530]
    1d1c:      	and	x12, x4, #0x7
    1d20:      	add	x13, sp, #0x530
    1d24:      	ldr	x12, [x13, x12, lsl #3]
    1d28:      	sub	x12, x12, x4
    1d2c:      	add	x8, x8, x12, lsl #2
    1d30:      	movi.2d	v26, #0000000000000000
    1d34:      	movi.2d	v27, #0000000000000000
    1d38:      	tbnz	w11, #0x0, 0x2e7c <ltmp0+0x2e7c>
    1d3c:      	tbnz	w9, #0x1, 0x2e84 <ltmp0+0x2e84>
    1d40:      	tbnz	w9, #0x2, 0x2e90 <ltmp0+0x2e90>
    1d44:      	tbnz	w9, #0x3, 0x2e9c <ltmp0+0x2e9c>
    1d48:      	tbnz	w9, #0x4, 0x2ea8 <ltmp0+0x2ea8>
    1d4c:      	tbnz	w9, #0x5, 0x2eb4 <ltmp0+0x2eb4>
    1d50:      	tbnz	w9, #0x6, 0x2ec0 <ltmp0+0x2ec0>
    1d54:      	tbz	w9, #0x7, 0x1d60 <ltmp0+0x1d60>
    1d58:      	add	x8, x8, #0x1c
    1d5c:      	ld1.s	{ v27 }[3], [x8]
    1d60:      	sshll.2d	v19, v8, #0x0
    1d64:      	sshll2.2d	v14, v31, #0x0
    1d68:      	sshll2.2d	v15, v8, #0x0
    1d6c:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1d70:      	ldr	q20, [x8]
    1d74:      	and.16b	v29, v15, v20
    1d78:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1d7c:      	ldr	q20, [x8]
    1d80:      	and.16b	v25, v14, v20
    1d84:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1d88:      	ldr	q20, [x8]
    1d8c:      	and.16b	v30, v19, v20
    1d90:      	and.16b	v20, v19, v1
    1d94:      	str	q20, [sp, #0x290]
    1d98:      	and.16b	v28, v6, v1
    1d9c:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1da0:      	ldr	q20, [x8]
    1da4:      	and.16b	v22, v15, v20
    1da8:      	ldr	q20, [x16]
    1dac:      	and.16b	v23, v14, v20
    1db0:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1db4:      	ldr	q20, [x8]
    1db8:      	and.16b	v19, v19, v20
    1dbc:      	and.16b	v24, v6, v3
    1dc0:      	stp	q30, q25, [sp, #0x10]
    1dc4:      	orr.16b	v20, v30, v18
    1dc8:      	orr.16b	v25, v25, v18
    1dcc:      	str	q29, [sp, #0x30]
    1dd0:      	orr.16b	v18, v29, v18
    1dd4:      	umull.2d	v6, v7, v17
    1dd8:      	str	q6, [sp, #0xd0]
    1ddc:      	xtn.2s	v4, v4
    1de0:      	xtn.2s	v5, v5
    1de4:      	xtn.2s	v2, v2
    1de8:      	str	q18, [sp, #0xa0]
    1dec:      	mov.16b	v6, v18
    1df0:      	umlal.2d	v6, v2, v17
    1df4:      	stp	q25, q20, [sp, #0x70]
    1df8:      	mov.16b	v2, v25
    1dfc:      	umlal.2d	v2, v4, v17
    1e00:      	stp	q2, q6, [sp, #0xf0]
    1e04:      	mov.16b	v2, v20
    1e08:      	umlal.2d	v2, v5, v17
    1e0c:      	str	q2, [sp, #0xe0]
    1e10:      	str	q24, [sp, #0x4f0]
    1e14:      	str	q23, [sp, #0x500]
    1e18:      	str	q19, [sp, #0x510]
    1e1c:      	str	q22, [sp, #0x520]
    1e20:      	and	x8, x4, #0x7
    1e24:      	add	x11, sp, #0x4f0
    1e28:      	ldr	x8, [x11, x8, lsl #3]
    1e2c:      	orr	x8, x8, #0x4000
    1e30:      	sub	x8, x8, x4, lsl #2
    1e34:      	tst	w9, #0xff
    1e38:      	csel	x3, xzr, x8, eq
    1e3c:      	add	x8, x14, x3
    1e40:      	ldp	q2, q4, [x8]
    1e44:      	zip2.8b	v5, v21, v0
    1e48:      	ushll.4s	v5, v5, #0x0
    1e4c:      	shl.4s	v5, v5, #0x1f
    1e50:      	cmlt.4s	v5, v5, #0
    1e54:      	stp	q27, q26, [sp, #0x40]
    1e58:      	bit.16b	v4, v27, v5
    1e5c:      	str	q21, [sp, #0x120]
    1e60:      	zip1.8b	v5, v21, v0
    1e64:      	ushll.4s	v5, v5, #0x0
    1e68:      	shl.4s	v5, v5, #0x1f
    1e6c:      	cmlt.4s	v5, v5, #0
    1e70:      	bit.16b	v2, v26, v5
    1e74:      	stp	q2, q4, [x8]
    1e78:      	mov	w8, #0x20               ; =32
    1e7c:      	dup.2d	v2, x8
    1e80:      	orr.16b	v5, v19, v2
    1e84:      	orr.16b	v4, v23, v2
    1e88:      	stp	q4, q5, [sp, #0x220]
    1e8c:      	orr.16b	v4, v24, v2
    1e90:      	orr.16b	v2, v22, v2
    1e94:      	stp	q2, q4, [sp, #0x200]
    1e98:      	mov	w8, #0x40               ; =64
    1e9c:      	dup.2d	v2, x8
    1ea0:      	orr.16b	v5, v19, v2
    1ea4:      	orr.16b	v4, v23, v2
    1ea8:      	stp	q4, q5, [sp, #0x1e0]
    1eac:      	orr.16b	v4, v24, v2
    1eb0:      	orr.16b	v2, v22, v2
    1eb4:      	stp	q2, q4, [sp, #0x1c0]
    1eb8:      	mov	w8, #0x60               ; =96
    1ebc:      	dup.2d	v2, x8
    1ec0:      	stp	q19, q23, [sp, #0x2b0]
    1ec4:      	orr.16b	v5, v19, v2
    1ec8:      	orr.16b	v4, v23, v2
    1ecc:      	stp	q4, q5, [sp, #0x1a0]
    1ed0:      	orr.16b	v4, v24, v2
    1ed4:      	str	q22, [sp, #0x2d0]
    1ed8:      	orr.16b	v2, v22, v2
    1edc:      	stp	q2, q4, [sp, #0x180]
    1ee0:      	ldr	q2, [sp, #0x4610]
    1ee4:      	ldr	q4, [sp, #0x4600]
    1ee8:      	fmul.4s	v4, v4, v4
    1eec:      	fmul.4s	v2, v2, v2
    1ef0:      	and.16b	v11, v8, v2
    1ef4:      	and.16b	v12, v31, v4
    1ef8:      	ldr	q2, [sp, #0x45e0]
    1efc:      	fmul.4s	v2, v2, v2
    1f00:      	ldr	q4, [sp, #0x45f0]
    1f04:      	fmul.4s	v4, v4, v4
    1f08:      	and.16b	v13, v8, v4
    1f0c:      	and.16b	v18, v31, v2
    1f10:      	ldr	q2, [sp, #0x45c0]
    1f14:      	fmul.4s	v2, v2, v2
    1f18:      	ldr	q4, [sp, #0x45d0]
    1f1c:      	fmul.4s	v4, v4, v4
    1f20:      	and.16b	v20, v8, v4
    1f24:      	and.16b	v22, v31, v2
    1f28:      	str	q24, [sp, #0x2a0]
    1f2c:      	fmov	x8, d24
    1f30:      	add	x8, x14, x8
    1f34:      	ldp	q2, q4, [x8]
    1f38:      	fmul.4s	v2, v2, v2
    1f3c:      	fmul.4s	v4, v4, v4
    1f40:      	and.16b	v10, v8, v4
    1f44:      	and.16b	v9, v31, v2
    1f48:      	sshll.2d	v2, v8, #0x0
    1f4c:      	dup.2d	v5, x27
    1f50:      	and.16b	v2, v2, v5
    1f54:      	sshll.2d	v4, v31, #0x0
    1f58:      	and.16b	v19, v4, v5
    1f5c:      	and.16b	v4, v15, v5
    1f60:      	and.16b	v17, v14, v5
    1f64:      	stp	q15, q14, [sp, #0x250]
    1f68:      	and.16b	v5, v15, v1
    1f6c:      	str	q5, [sp, #0x2e0]
    1f70:      	and.16b	v29, v14, v1
    1f74:      	str	q29, [sp, #0x240]
    1f78:      	str	q28, [sp, #0x270]
    1f7c:      	b	0x2024 <ltmp0+0x2024>
    1f80:      	fmul.4s	v5, v30, v30
    1f84:      	fmul.4s	v6, v7, v7
    1f88:      	fadd.4s	v26, v9, v6
    1f8c:      	fadd.4s	v27, v10, v5
    1f90:      	fmul.4s	v5, v25, v25
    1f94:      	fmul.4s	v6, v24, v24
    1f98:      	fadd.4s	v6, v22, v6
    1f9c:      	fadd.4s	v5, v20, v5
    1fa0:      	fmul.4s	v7, v23, v23
    1fa4:      	fmul.4s	v21, v21, v21
    1fa8:      	fadd.4s	v21, v18, v21
    1fac:      	fadd.4s	v7, v13, v7
    1fb0:      	sshll.2d	v23, v31, #0x0
    1fb4:      	sshll.2d	v24, v8, #0x0
    1fb8:      	fmul.4s	v25, v14, v14
    1fbc:      	fmul.4s	v28, v28, v28
    1fc0:      	fadd.4s	v28, v11, v28
    1fc4:      	fadd.4s	v25, v12, v25
    1fc8:      	dup.2d	v30, x27
    1fcc:      	ldr	q14, [sp, #0x250]
    1fd0:      	and.16b	v14, v14, v30
    1fd4:      	add.2d	v4, v4, v14
    1fd8:      	ldr	q14, [sp, #0x260]
    1fdc:      	and.16b	v14, v14, v30
    1fe0:      	add.2d	v17, v17, v14
    1fe4:      	and.16b	v24, v24, v30
    1fe8:      	add.2d	v2, v2, v24
    1fec:      	and.16b	v23, v23, v30
    1ff0:      	add.2d	v19, v19, v23
    1ff4:      	bit.16b	v10, v27, v8
    1ff8:      	bit.16b	v9, v26, v31
    1ffc:      	bit.16b	v20, v5, v8
    2000:      	bit.16b	v22, v6, v31
    2004:      	bit.16b	v13, v7, v8
    2008:      	bit.16b	v18, v21, v31
    200c:      	bit.16b	v12, v25, v31
    2010:      	bit.16b	v11, v28, v8
    2014:      	fmov	x8, d19
    2018:      	cmp	x8, #0x200
    201c:      	ldr	q28, [sp, #0x270]
    2020:      	b.ge	0x240c <ltmp0+0x240c>
    2024:      	fmov	w8, s16
    2028:      	shl.2d	v14, v19, #0x5
    202c:      	ldr	q5, [sp, #0x2a0]
    2030:      	orr.16b	v5, v14, v5
    2034:      	add.2d	v5, v28, v5
    2038:      	movi.2d	v7, #0000000000000000
    203c:      	movi.2d	v30, #0000000000000000
    2040:      	tbnz	w8, #0x0, 0x21e4 <ltmp0+0x21e4>
    2044:      	and	w8, w8, #0xff
    2048:      	tbnz	w8, #0x1, 0x21f4 <ltmp0+0x21f4>
    204c:      	shl.2d	v15, v17, #0x5
    2050:      	ldr	q5, [sp, #0x2c0]
    2054:      	orr.16b	v5, v15, v5
    2058:      	add.2d	v5, v29, v5
    205c:      	ldr	q27, [sp, #0x290]
    2060:      	tbnz	w8, #0x2, 0x2214 <ltmp0+0x2214>
    2064:      	tbnz	w8, #0x3, 0x2220 <ltmp0+0x2220>
    2068:      	shl.2d	v5, v2, #0x5
    206c:      	ldr	q6, [sp, #0x2b0]
    2070:      	orr.16b	v6, v5, v6
    2074:      	add.2d	v6, v27, v6
    2078:      	tbnz	w8, #0x4, 0x223c <ltmp0+0x223c>
    207c:      	tbnz	w8, #0x5, 0x2248 <ltmp0+0x2248>
    2080:      	shl.2d	v6, v4, #0x5
    2084:      	ldp	q21, q23, [sp, #0x2d0]
    2088:      	orr.16b	v21, v6, v21
    208c:      	add.2d	v21, v23, v21
    2090:      	tbnz	w8, #0x6, 0x2264 <ltmp0+0x2264>
    2094:      	tbz	w8, #0x7, 0x20a0 <ltmp0+0x20a0>
    2098:      	mov.d	x8, v21[1]
    209c:      	ld1.s	{ v30 }[3], [x8]
    20a0:      	fmov	w8, s16
    20a4:      	ldr	q21, [sp, #0x210]
    20a8:      	add.2d	v21, v21, v14
    20ac:      	add.2d	v21, v28, v21
    20b0:      	movi.2d	v24, #0000000000000000
    20b4:      	movi.2d	v25, #0000000000000000
    20b8:      	tbnz	w8, #0x0, 0x2274 <ltmp0+0x2274>
    20bc:      	and	w8, w8, #0xff
    20c0:      	tbnz	w8, #0x1, 0x2284 <ltmp0+0x2284>
    20c4:      	ldr	q21, [sp, #0x220]
    20c8:      	add.2d	v21, v21, v15
    20cc:      	add.2d	v21, v29, v21
    20d0:      	tbnz	w8, #0x2, 0x229c <ltmp0+0x229c>
    20d4:      	tbnz	w8, #0x3, 0x22a8 <ltmp0+0x22a8>
    20d8:      	ldr	q21, [sp, #0x230]
    20dc:      	add.2d	v21, v21, v5
    20e0:      	add.2d	v21, v27, v21
    20e4:      	tbnz	w8, #0x4, 0x22c0 <ltmp0+0x22c0>
    20e8:      	tbnz	w8, #0x5, 0x22cc <ltmp0+0x22cc>
    20ec:      	ldr	q21, [sp, #0x200]
    20f0:      	add.2d	v21, v21, v6
    20f4:      	ldr	q23, [sp, #0x2e0]
    20f8:      	add.2d	v21, v23, v21
    20fc:      	tbnz	w8, #0x6, 0x22e8 <ltmp0+0x22e8>
    2100:      	tbz	w8, #0x7, 0x210c <ltmp0+0x210c>
    2104:      	mov.d	x8, v21[1]
    2108:      	ld1.s	{ v25 }[3], [x8]
    210c:      	fmov	w8, s16
    2110:      	ldr	q21, [sp, #0x1d0]
    2114:      	add.2d	v21, v21, v14
    2118:      	add.2d	v26, v28, v21
    211c:      	movi.2d	v21, #0000000000000000
    2120:      	movi.2d	v23, #0000000000000000
    2124:      	tbnz	w8, #0x0, 0x22f8 <ltmp0+0x22f8>
    2128:      	and	w8, w8, #0xff
    212c:      	tbnz	w8, #0x1, 0x2308 <ltmp0+0x2308>
    2130:      	ldr	q26, [sp, #0x1e0]
    2134:      	add.2d	v26, v26, v15
    2138:      	add.2d	v26, v29, v26
    213c:      	tbnz	w8, #0x2, 0x2320 <ltmp0+0x2320>
    2140:      	tbnz	w8, #0x3, 0x232c <ltmp0+0x232c>
    2144:      	ldr	q26, [sp, #0x1f0]
    2148:      	add.2d	v26, v26, v5
    214c:      	add.2d	v26, v27, v26
    2150:      	tbnz	w8, #0x4, 0x2344 <ltmp0+0x2344>
    2154:      	tbnz	w8, #0x5, 0x2350 <ltmp0+0x2350>
    2158:      	ldr	q26, [sp, #0x1c0]
    215c:      	add.2d	v26, v26, v6
    2160:      	ldr	q29, [sp, #0x2e0]
    2164:      	add.2d	v26, v29, v26
    2168:      	tbnz	w8, #0x6, 0x236c <ltmp0+0x236c>
    216c:      	ldr	q29, [sp, #0x240]
    2170:      	tbz	w8, #0x7, 0x217c <ltmp0+0x217c>
    2174:      	mov.d	x8, v26[1]
    2178:      	ld1.s	{ v23 }[3], [x8]
    217c:      	fmov	w8, s16
    2180:      	ldr	q26, [sp, #0x190]
    2184:      	add.2d	v26, v26, v14
    2188:      	add.2d	v26, v28, v26
    218c:      	movi.2d	v14, #0000000000000000
    2190:      	movi.2d	v28, #0000000000000000
    2194:      	tbnz	w8, #0x0, 0x2380 <ltmp0+0x2380>
    2198:      	and	w8, w8, #0xff
    219c:      	tbnz	w8, #0x1, 0x2390 <ltmp0+0x2390>
    21a0:      	ldr	q26, [sp, #0x1a0]
    21a4:      	add.2d	v26, v26, v15
    21a8:      	add.2d	v26, v29, v26
    21ac:      	tbnz	w8, #0x2, 0x23a8 <ltmp0+0x23a8>
    21b0:      	tbnz	w8, #0x3, 0x23b4 <ltmp0+0x23b4>
    21b4:      	ldr	q26, [sp, #0x1b0]
    21b8:      	add.2d	v5, v26, v5
    21bc:      	add.2d	v5, v27, v5
    21c0:      	tbnz	w8, #0x4, 0x23cc <ltmp0+0x23cc>
    21c4:      	tbnz	w8, #0x5, 0x23d8 <ltmp0+0x23d8>
    21c8:      	ldr	q5, [sp, #0x180]
    21cc:      	add.2d	v5, v5, v6
    21d0:      	ldr	q6, [sp, #0x2e0]
    21d4:      	add.2d	v5, v6, v5
    21d8:      	tbnz	w8, #0x6, 0x23f4 <ltmp0+0x23f4>
    21dc:      	tbz	w8, #0x7, 0x1f80 <ltmp0+0x1f80>
    21e0:      	b	0x2400 <ltmp0+0x2400>
    21e4:      	fmov	x9, d5
    21e8:      	ldr	s7, [x9]
    21ec:      	and	w8, w8, #0xff
    21f0:      	tbz	w8, #0x1, 0x204c <ltmp0+0x204c>
    21f4:      	mov.d	x9, v5[1]
    21f8:      	ld1.s	{ v7 }[1], [x9]
    21fc:      	shl.2d	v15, v17, #0x5
    2200:      	ldr	q5, [sp, #0x2c0]
    2204:      	orr.16b	v5, v15, v5
    2208:      	add.2d	v5, v29, v5
    220c:      	ldr	q27, [sp, #0x290]
    2210:      	tbz	w8, #0x2, 0x2064 <ltmp0+0x2064>
    2214:      	fmov	x9, d5
    2218:      	ld1.s	{ v7 }[2], [x9]
    221c:      	tbz	w8, #0x3, 0x2068 <ltmp0+0x2068>
    2220:      	mov.d	x9, v5[1]
    2224:      	ld1.s	{ v7 }[3], [x9]
    2228:      	shl.2d	v5, v2, #0x5
    222c:      	ldr	q6, [sp, #0x2b0]
    2230:      	orr.16b	v6, v5, v6
    2234:      	add.2d	v6, v27, v6
    2238:      	tbz	w8, #0x4, 0x207c <ltmp0+0x207c>
    223c:      	fmov	x9, d6
    2240:      	ld1.s	{ v30 }[0], [x9]
    2244:      	tbz	w8, #0x5, 0x2080 <ltmp0+0x2080>
    2248:      	mov.d	x9, v6[1]
    224c:      	ld1.s	{ v30 }[1], [x9]
    2250:      	shl.2d	v6, v4, #0x5
    2254:      	ldp	q21, q23, [sp, #0x2d0]
    2258:      	orr.16b	v21, v6, v21
    225c:      	add.2d	v21, v23, v21
    2260:      	tbz	w8, #0x6, 0x2094 <ltmp0+0x2094>
    2264:      	fmov	x9, d21
    2268:      	ld1.s	{ v30 }[2], [x9]
    226c:      	tbnz	w8, #0x7, 0x2098 <ltmp0+0x2098>
    2270:      	b	0x20a0 <ltmp0+0x20a0>
    2274:      	fmov	x9, d21
    2278:      	ldr	s24, [x9]
    227c:      	and	w8, w8, #0xff
    2280:      	tbz	w8, #0x1, 0x20c4 <ltmp0+0x20c4>
    2284:      	mov.d	x9, v21[1]
    2288:      	ld1.s	{ v24 }[1], [x9]
    228c:      	ldr	q21, [sp, #0x220]
    2290:      	add.2d	v21, v21, v15
    2294:      	add.2d	v21, v29, v21
    2298:      	tbz	w8, #0x2, 0x20d4 <ltmp0+0x20d4>
    229c:      	fmov	x9, d21
    22a0:      	ld1.s	{ v24 }[2], [x9]
    22a4:      	tbz	w8, #0x3, 0x20d8 <ltmp0+0x20d8>
    22a8:      	mov.d	x9, v21[1]
    22ac:      	ld1.s	{ v24 }[3], [x9]
    22b0:      	ldr	q21, [sp, #0x230]
    22b4:      	add.2d	v21, v21, v5
    22b8:      	add.2d	v21, v27, v21
    22bc:      	tbz	w8, #0x4, 0x20e8 <ltmp0+0x20e8>
    22c0:      	fmov	x9, d21
    22c4:      	ld1.s	{ v25 }[0], [x9]
    22c8:      	tbz	w8, #0x5, 0x20ec <ltmp0+0x20ec>
    22cc:      	mov.d	x9, v21[1]
    22d0:      	ld1.s	{ v25 }[1], [x9]
    22d4:      	ldr	q21, [sp, #0x200]
    22d8:      	add.2d	v21, v21, v6
    22dc:      	ldr	q23, [sp, #0x2e0]
    22e0:      	add.2d	v21, v23, v21
    22e4:      	tbz	w8, #0x6, 0x2100 <ltmp0+0x2100>
    22e8:      	fmov	x9, d21
    22ec:      	ld1.s	{ v25 }[2], [x9]
    22f0:      	tbnz	w8, #0x7, 0x2104 <ltmp0+0x2104>
    22f4:      	b	0x210c <ltmp0+0x210c>
    22f8:      	fmov	x9, d26
    22fc:      	ldr	s21, [x9]
    2300:      	and	w8, w8, #0xff
    2304:      	tbz	w8, #0x1, 0x2130 <ltmp0+0x2130>
    2308:      	mov.d	x9, v26[1]
    230c:      	ld1.s	{ v21 }[1], [x9]
    2310:      	ldr	q26, [sp, #0x1e0]
    2314:      	add.2d	v26, v26, v15
    2318:      	add.2d	v26, v29, v26
    231c:      	tbz	w8, #0x2, 0x2140 <ltmp0+0x2140>
    2320:      	fmov	x9, d26
    2324:      	ld1.s	{ v21 }[2], [x9]
    2328:      	tbz	w8, #0x3, 0x2144 <ltmp0+0x2144>
    232c:      	mov.d	x9, v26[1]
    2330:      	ld1.s	{ v21 }[3], [x9]
    2334:      	ldr	q26, [sp, #0x1f0]
    2338:      	add.2d	v26, v26, v5
    233c:      	add.2d	v26, v27, v26
    2340:      	tbz	w8, #0x4, 0x2154 <ltmp0+0x2154>
    2344:      	fmov	x9, d26
    2348:      	ld1.s	{ v23 }[0], [x9]
    234c:      	tbz	w8, #0x5, 0x2158 <ltmp0+0x2158>
    2350:      	mov.d	x9, v26[1]
    2354:      	ld1.s	{ v23 }[1], [x9]
    2358:      	ldr	q26, [sp, #0x1c0]
    235c:      	add.2d	v26, v26, v6
    2360:      	ldr	q29, [sp, #0x2e0]
    2364:      	add.2d	v26, v29, v26
    2368:      	tbz	w8, #0x6, 0x216c <ltmp0+0x216c>
    236c:      	fmov	x9, d26
    2370:      	ld1.s	{ v23 }[2], [x9]
    2374:      	ldr	q29, [sp, #0x240]
    2378:      	tbnz	w8, #0x7, 0x2174 <ltmp0+0x2174>
    237c:      	b	0x217c <ltmp0+0x217c>
    2380:      	fmov	x9, d26
    2384:      	ldr	s14, [x9]
    2388:      	and	w8, w8, #0xff
    238c:      	tbz	w8, #0x1, 0x21a0 <ltmp0+0x21a0>
    2390:      	mov.d	x9, v26[1]
    2394:      	ld1.s	{ v14 }[1], [x9]
    2398:      	ldr	q26, [sp, #0x1a0]
    239c:      	add.2d	v26, v26, v15
    23a0:      	add.2d	v26, v29, v26
    23a4:      	tbz	w8, #0x2, 0x21b0 <ltmp0+0x21b0>
    23a8:      	fmov	x9, d26
    23ac:      	ld1.s	{ v14 }[2], [x9]
    23b0:      	tbz	w8, #0x3, 0x21b4 <ltmp0+0x21b4>
    23b4:      	mov.d	x9, v26[1]
    23b8:      	ld1.s	{ v14 }[3], [x9]
    23bc:      	ldr	q26, [sp, #0x1b0]
    23c0:      	add.2d	v5, v26, v5
    23c4:      	add.2d	v5, v27, v5
    23c8:      	tbz	w8, #0x4, 0x21c4 <ltmp0+0x21c4>
    23cc:      	fmov	x9, d5
    23d0:      	ld1.s	{ v28 }[0], [x9]
    23d4:      	tbz	w8, #0x5, 0x21c8 <ltmp0+0x21c8>
    23d8:      	mov.d	x9, v5[1]
    23dc:      	ld1.s	{ v28 }[1], [x9]
    23e0:      	ldr	q5, [sp, #0x180]
    23e4:      	add.2d	v5, v5, v6
    23e8:      	ldr	q6, [sp, #0x2e0]
    23ec:      	add.2d	v5, v6, v5
    23f0:      	tbz	w8, #0x6, 0x21dc <ltmp0+0x21dc>
    23f4:      	fmov	x9, d5
    23f8:      	ld1.s	{ v28 }[2], [x9]
    23fc:      	tbz	w8, #0x7, 0x1f80 <ltmp0+0x1f80>
    2400:      	mov.d	x8, v5[1]
    2404:      	ld1.s	{ v28 }[3], [x8]
    2408:      	b	0x1f80 <ltmp0+0x1f80>
    240c:      	mov	x8, #0x0                ; =0
    2410:      	ldp	q4, q2, [sp, #0x250]
    2414:      	and.16b	v14, v4, v0
    2418:      	and.16b	v15, v2, v0
    241c:      	sshll.2d	v2, v8, #0x0
    2420:      	and.16b	v6, v2, v0
    2424:      	sshll.2d	v2, v31, #0x0
    2428:      	and.16b	v7, v2, v0
    242c:      	dup.2d	v2, x28
    2430:      	ushll2.2d	v4, v8, #0x0
    2434:      	and.16b	v5, v4, v2
    2438:      	ushll2.2d	v4, v31, #0x0
    243c:      	and.16b	v30, v4, v2
    2440:      	ushll.2d	v4, v8, #0x0
    2444:      	and.16b	v8, v4, v2
    2448:      	ushll.2d	v4, v31, #0x0
    244c:      	and.16b	v31, v4, v2
    2450:      	movi.2d	v2, #0000000000000000
    2454:      	movi.2d	v4, #0000000000000000
    2458:      	movi.2d	v17, #0000000000000000
    245c:      	movi.2d	v19, #0000000000000000
    2460:      	b	0x2480 <ltmp0+0x2480>
    2464:      	add.2d	v4, v4, v30
    2468:      	add.2d	v17, v17, v8
    246c:      	add.2d	v19, v19, v5
    2470:      	add.2d	v2, v2, v31
    2474:      	fmov	x8, d2
    2478:      	cmp	x8, #0x200
    247c:      	b.ge	0x2628 <ltmp0+0x2628>
    2480:      	fmov	w9, s16
    2484:      	add	x8, x20, x8, lsl #5
    2488:      	movi.2d	v23, #0000000000000000
    248c:      	movi.2d	v21, #0000000000000000
    2490:      	tbnz	w9, #0x0, 0x2520 <ltmp0+0x2520>
    2494:      	and	w9, w9, #0xff
    2498:      	tbnz	w9, #0x1, 0x252c <ltmp0+0x252c>
    249c:      	tbnz	w9, #0x2, 0x2538 <ltmp0+0x2538>
    24a0:      	tbnz	w9, #0x3, 0x2544 <ltmp0+0x2544>
    24a4:      	tbnz	w9, #0x4, 0x2550 <ltmp0+0x2550>
    24a8:      	tbnz	w9, #0x5, 0x255c <ltmp0+0x255c>
    24ac:      	tbnz	w9, #0x6, 0x2568 <ltmp0+0x2568>
    24b0:      	tbnz	w9, #0x7, 0x2574 <ltmp0+0x2574>
    24b4:      	fmov	w8, s16
    24b8:      	shl.2d	v24, v2, #0x5
    24bc:      	ldr	q25, [sp, #0x2a0]
    24c0:      	orr.16b	v24, v24, v25
    24c4:      	add.2d	v24, v7, v24
    24c8:      	tbnz	w8, #0x0, 0x2594 <ltmp0+0x2594>
    24cc:      	and	w8, w8, #0xff
    24d0:      	tbnz	w8, #0x1, 0x25a4 <ltmp0+0x25a4>
    24d4:      	shl.2d	v24, v4, #0x5
    24d8:      	ldr	q25, [sp, #0x2c0]
    24dc:      	orr.16b	v24, v24, v25
    24e0:      	add.2d	v24, v15, v24
    24e4:      	tbnz	w8, #0x2, 0x25c0 <ltmp0+0x25c0>
    24e8:      	tbnz	w8, #0x3, 0x25cc <ltmp0+0x25cc>
    24ec:      	shl.2d	v23, v17, #0x5
    24f0:      	ldr	q24, [sp, #0x2b0]
    24f4:      	orr.16b	v23, v23, v24
    24f8:      	add.2d	v23, v6, v23
    24fc:      	tbnz	w8, #0x4, 0x25e8 <ltmp0+0x25e8>
    2500:      	tbnz	w8, #0x5, 0x25f4 <ltmp0+0x25f4>
    2504:      	shl.2d	v23, v19, #0x5
    2508:      	ldr	q24, [sp, #0x2d0]
    250c:      	orr.16b	v23, v23, v24
    2510:      	add.2d	v23, v14, v23
    2514:      	tbnz	w8, #0x6, 0x2610 <ltmp0+0x2610>
    2518:      	tbz	w8, #0x7, 0x2464 <ltmp0+0x2464>
    251c:      	b	0x261c <ltmp0+0x261c>
    2520:      	ldr	s23, [x8]
    2524:      	and	w9, w9, #0xff
    2528:      	tbz	w9, #0x1, 0x249c <ltmp0+0x249c>
    252c:      	add	x11, x8, #0x4
    2530:      	ld1.s	{ v23 }[1], [x11]
    2534:      	tbz	w9, #0x2, 0x24a0 <ltmp0+0x24a0>
    2538:      	add	x11, x8, #0x8
    253c:      	ld1.s	{ v23 }[2], [x11]
    2540:      	tbz	w9, #0x3, 0x24a4 <ltmp0+0x24a4>
    2544:      	add	x11, x8, #0xc
    2548:      	ld1.s	{ v23 }[3], [x11]
    254c:      	tbz	w9, #0x4, 0x24a8 <ltmp0+0x24a8>
    2550:      	add	x11, x8, #0x10
    2554:      	ld1.s	{ v21 }[0], [x11]
    2558:      	tbz	w9, #0x5, 0x24ac <ltmp0+0x24ac>
    255c:      	add	x11, x8, #0x14
    2560:      	ld1.s	{ v21 }[1], [x11]
    2564:      	tbz	w9, #0x6, 0x24b0 <ltmp0+0x24b0>
    2568:      	add	x11, x8, #0x18
    256c:      	ld1.s	{ v21 }[2], [x11]
    2570:      	tbz	w9, #0x7, 0x24b4 <ltmp0+0x24b4>
    2574:      	add	x8, x8, #0x1c
    2578:      	ld1.s	{ v21 }[3], [x8]
    257c:      	fmov	w8, s16
    2580:      	shl.2d	v24, v2, #0x5
    2584:      	ldr	q25, [sp, #0x2a0]
    2588:      	orr.16b	v24, v24, v25
    258c:      	add.2d	v24, v7, v24
    2590:      	tbz	w8, #0x0, 0x24cc <ltmp0+0x24cc>
    2594:      	fmov	x9, d24
    2598:      	str	s23, [x9]
    259c:      	and	w8, w8, #0xff
    25a0:      	tbz	w8, #0x1, 0x24d4 <ltmp0+0x24d4>
    25a4:      	mov.d	x9, v24[1]
    25a8:      	st1.s	{ v23 }[1], [x9]
    25ac:      	shl.2d	v24, v4, #0x5
    25b0:      	ldr	q25, [sp, #0x2c0]
    25b4:      	orr.16b	v24, v24, v25
    25b8:      	add.2d	v24, v15, v24
    25bc:      	tbz	w8, #0x2, 0x24e8 <ltmp0+0x24e8>
    25c0:      	fmov	x9, d24
    25c4:      	st1.s	{ v23 }[2], [x9]
    25c8:      	tbz	w8, #0x3, 0x24ec <ltmp0+0x24ec>
    25cc:      	mov.d	x9, v24[1]
    25d0:      	st1.s	{ v23 }[3], [x9]
    25d4:      	shl.2d	v23, v17, #0x5
    25d8:      	ldr	q24, [sp, #0x2b0]
    25dc:      	orr.16b	v23, v23, v24
    25e0:      	add.2d	v23, v6, v23
    25e4:      	tbz	w8, #0x4, 0x2500 <ltmp0+0x2500>
    25e8:      	fmov	x9, d23
    25ec:      	str	s21, [x9]
    25f0:      	tbz	w8, #0x5, 0x2504 <ltmp0+0x2504>
    25f4:      	mov.d	x9, v23[1]
    25f8:      	st1.s	{ v21 }[1], [x9]
    25fc:      	shl.2d	v23, v19, #0x5
    2600:      	ldr	q24, [sp, #0x2d0]
    2604:      	orr.16b	v23, v23, v24
    2608:      	add.2d	v23, v14, v23
    260c:      	tbz	w8, #0x6, 0x2518 <ltmp0+0x2518>
    2610:      	fmov	x9, d23
    2614:      	st1.s	{ v21 }[2], [x9]
    2618:      	tbz	w8, #0x7, 0x2464 <ltmp0+0x2464>
    261c:      	mov.d	x8, v23[1]
    2620:      	st1.s	{ v21 }[3], [x8]
    2624:      	b	0x2464 <ltmp0+0x2464>
    2628:      	ldr	q2, [sp, #0x90]
    262c:      	xtn.8b	v2, v2
    2630:      	ldp	q17, q4, [sp, #0x40]
    2634:      	fmul.4s	v4, v4, v4
    2638:      	fmul.4s	v17, v17, v17
    263c:      	fadd.4s	v17, v17, v10
    2640:      	fadd.4s	v4, v4, v9
    2644:      	ldr	q9, [sp, #0x120]
    2648:      	zip1.8b	v19, v9, v0
    264c:      	ushll.4s	v19, v19, #0x0
    2650:      	shl.4s	v19, v19, #0x1f
    2654:      	cmlt.4s	v19, v19, #0
    2658:      	and.16b	v4, v19, v4
    265c:      	zip2.8b	v19, v9, v0
    2660:      	ushll.4s	v19, v19, #0x0
    2664:      	shl.4s	v19, v19, #0x1f
    2668:      	cmlt.4s	v19, v19, #0
    266c:      	and.16b	v17, v19, v17
    2670:      	zip2.8b	v19, v2, v0
    2674:      	ushll.4s	v19, v19, #0x0
    2678:      	shl.4s	v19, v19, #0x1f
    267c:      	cmlt.4s	v19, v19, #0
    2680:      	movi.2d	v21, #0000000000000000
    2684:      	mov.b	v21[2], v2[1]
    2688:      	mov.b	v21[4], v2[2]
    268c:      	mov.b	v21[6], v2[3]
    2690:      	bit.16b	v17, v27, v19
    2694:      	ushll.4s	v19, v21, #0x0
    2698:      	shl.4s	v19, v19, #0x1f
    269c:      	cmlt.4s	v19, v19, #0
    26a0:      	bit.16b	v4, v26, v19
    26a4:      	fadd.4s	v4, v22, v4
    26a8:      	fadd.4s	v17, v20, v17
    26ac:      	fadd.4s	v19, v13, v17
    26b0:      	fadd.4s	v4, v18, v4
    26b4:      	fadd.4s	v17, v12, v4
    26b8:      	fadd.4s	v18, v11, v19
    26bc:      	ldr	q4, [sp, #0x60]
    26c0:      	ldp	q20, q19, [sp, #0x20]
    26c4:      	uzp1.4s	v4, v4, v20
    26c8:      	ldr	q20, [sp, #0x10]
    26cc:      	uzp1.4s	v19, v20, v19
    26d0:      	movi.4s	v21, #0x1
    26d4:      	eor.16b	v20, v4, v21
    26d8:      	mov.s	w9, v20[1]
    26dc:      	mov.s	w13, v20[2]
    26e0:      	eor.16b	v23, v19, v21
    26e4:      	mov.s	w15, v20[3]
    26e8:      	fmov	w8, s20
    26ec:      	add	x11, sp, #0x338
    26f0:      	bfxil	x11, x8, #0, #3
    26f4:      	str	d2, [sp, #0x338]
    26f8:      	ldrb	w12, [x11]
    26fc:      	and	x11, x8, #0x7
    2700:      	umov.b	w8, v2[0]
    2704:      	str	q18, [sp, #0x450]
    2708:      	str	q17, [sp, #0x440]
    270c:      	add	x16, sp, #0x440
    2710:      	ldr	s20, [x16, x11, lsl #2]
    2714:      	ands	w11, w8, #0x1
    2718:      	tst	w11, w12
    271c:      	movi	d11, #0000000000000000
    2720:      	fcsel	s20, s20, s11, ne
    2724:      	add	x12, sp, #0x338
    2728:      	bfxil	x12, x9, #0, #3
    272c:      	ldrb	w12, [x12]
    2730:      	and	x16, x9, #0x7
    2734:      	umov.b	w9, v2[1]
    2738:      	str	q18, [sp, #0x430]
    273c:      	str	q17, [sp, #0x420]
    2740:      	add	x17, sp, #0x420
    2744:      	ldr	s21, [x17, x16, lsl #2]
    2748:      	ands	w16, w9, #0x1
    274c:      	tst	w16, w12
    2750:      	fcsel	s21, s21, s11, ne
    2754:      	add	x12, sp, #0x338
    2758:      	bfxil	x12, x13, #0, #3
    275c:      	ldrb	w16, [x12]
    2760:      	umov.b	w12, v2[2]
    2764:      	and	x13, x13, #0x7
    2768:      	str	q18, [sp, #0x410]
    276c:      	str	q17, [sp, #0x400]
    2770:      	add	x17, sp, #0x400
    2774:      	ldr	s22, [x17, x13, lsl #2]
    2778:      	ands	w13, w12, #0x1
    277c:      	tst	w13, w16
    2780:      	fcsel	s22, s22, s11, ne
    2784:      	add	x13, sp, #0x338
    2788:      	bfxil	x13, x15, #0, #3
    278c:      	ldrb	w16, [x13]
    2790:      	and	x15, x15, #0x7
    2794:      	umov.b	w13, v2[3]
    2798:      	stp	q17, q18, [sp, #0x3e0]
    279c:      	add	x17, sp, #0x3e0
    27a0:      	ldr	s24, [x17, x15, lsl #2]
    27a4:      	ands	w15, w13, #0x1
    27a8:      	tst	w15, w16
    27ac:      	mov.s	w15, v23[1]
    27b0:      	mov.s	w16, v23[2]
    27b4:      	fcsel	s24, s24, s11, ne
    27b8:      	mov.s	w1, v23[3]
    27bc:      	fmov	w0, s23
    27c0:      	and	x2, x0, #0x7
    27c4:      	add	x21, sp, #0x338
    27c8:      	bfxil	x21, x0, #0, #3
    27cc:      	ldrb	w21, [x21]
    27d0:      	umov.b	w0, v2[4]
    27d4:      	and	w21, w0, w21
    27d8:      	str	q18, [sp, #0x4d0]
    27dc:      	str	q17, [sp, #0x4c0]
    27e0:      	add	x17, sp, #0x4c0
    27e4:      	ldr	s23, [x17, x2, lsl #2]
    27e8:      	tst	w21, #0x1
    27ec:      	fcsel	s23, s23, s11, ne
    27f0:      	add	x2, sp, #0x338
    27f4:      	bfxil	x2, x15, #0, #3
    27f8:      	ldrb	w2, [x2]
    27fc:      	and	x15, x15, #0x7
    2800:      	umov.b	w21, v2[5]
    2804:      	str	q18, [sp, #0x4b0]
    2808:      	str	q17, [sp, #0x4a0]
    280c:      	add	x17, sp, #0x4a0
    2810:      	ldr	s25, [x17, x15, lsl #2]
    2814:      	ands	w15, w21, #0x1
    2818:      	tst	w15, w2
    281c:      	fcsel	s25, s25, s11, ne
    2820:      	add	x15, sp, #0x338
    2824:      	bfxil	x15, x16, #0, #3
    2828:      	ldrb	w15, [x15]
    282c:      	and	x16, x16, #0x7
    2830:      	umov.b	w30, v2[6]
    2834:      	str	q18, [sp, #0x490]
    2838:      	str	q17, [sp, #0x480]
    283c:      	add	x17, sp, #0x480
    2840:      	ldr	s26, [x17, x16, lsl #2]
    2844:      	ands	w16, w30, #0x1
    2848:      	tst	w16, w15
    284c:      	fcsel	s26, s26, s11, ne
    2850:      	add	x15, sp, #0x338
    2854:      	bfxil	x15, x1, #0, #3
    2858:      	ldrb	w15, [x15]
    285c:      	umov.b	w2, v2[7]
    2860:      	and	x16, x1, #0x7
    2864:      	str	q18, [sp, #0x470]
    2868:      	str	q17, [sp, #0x460]
    286c:      	add	x17, sp, #0x460
    2870:      	ldr	s2, [x17, x16, lsl #2]
    2874:      	ands	w16, w2, #0x1
    2878:      	tst	w16, w15
    287c:      	fcsel	s2, s2, s11, ne
    2880:      	mov.s	v23[1], v25[0]
    2884:      	mov.s	v23[2], v26[0]
    2888:      	mov.s	v23[3], v2[0]
    288c:      	mov.s	v20[1], v21[0]
    2890:      	mov.s	v20[2], v22[0]
    2894:      	mov.s	v20[3], v24[0]
    2898:      	fadd.4s	v2, v17, v20
    289c:      	fadd.4s	v17, v18, v23
    28a0:      	movi.4s	v20, #0x2
    28a4:      	eor.16b	v18, v19, v20
    28a8:      	eor.16b	v4, v4, v20
    28ac:      	fmov	w15, s4
    28b0:      	add	x16, sp, #0x338
    28b4:      	bfxil	x16, x15, #0, #3
    28b8:      	ldrb	w16, [x16]
    28bc:      	and	x15, x15, #0x7
    28c0:      	stp	q2, q17, [sp, #0x3c0]
    28c4:      	add	x17, sp, #0x3c0
    28c8:      	ldr	s4, [x17, x15, lsl #2]
    28cc:      	tst	w11, w16
    28d0:      	fcsel	s4, s4, s11, ne
    28d4:      	fmov	w15, s18
    28d8:      	and	x16, x15, #0x7
    28dc:      	add	x1, sp, #0x338
    28e0:      	bfxil	x1, x15, #0, #3
    28e4:      	ldrb	w15, [x1]
    28e8:      	and	w15, w0, w15
    28ec:      	stp	q2, q17, [sp, #0x3a0]
    28f0:      	add	x17, sp, #0x3a0
    28f4:      	ldr	s18, [x17, x16, lsl #2]
    28f8:      	tst	w15, #0x1
    28fc:      	fcsel	s18, s18, s11, ne
    2900:      	fadd.4s	v17, v17, v18
    2904:      	tst	w11, w0
    2908:      	fcsel	s17, s17, s11, ne
    290c:      	ands	w8, w8, #0x1
    2910:      	fadd.4s	v2, v2, v4
    2914:      	fadd	s2, s2, s17
    2918:      	fcsel	s4, s2, s11, ne
    291c:      	tst	w9, #0x1
    2920:      	fcsel	s17, s4, s11, ne
    2924:      	tst	w12, #0x1
    2928:      	fcsel	s18, s4, s11, ne
    292c:      	tst	w13, #0x1
    2930:      	fcsel	s19, s4, s11, ne
    2934:      	tst	w8, w0
    2938:      	fcsel	s20, s2, s11, ne
    293c:      	tst	w21, #0x1
    2940:      	fcsel	s21, s4, s11, ne
    2944:      	tst	w30, #0x1
    2948:      	fcsel	s22, s4, s11, ne
    294c:      	tst	w2, #0x1
    2950:      	shl.8b	v2, v9, #0x7
    2954:      	cmlt.8b	v2, v2, #0
    2958:      	ldr	d23, [sp, #0xb8]
    295c:      	and.8b	v2, v2, v23
    2960:      	addv.8b	b2, v2
    2964:      	fmov	w8, s2
    2968:      	fcsel	s23, s4, s11, ne
    296c:      	mov.s	v4[1], v17[0]
    2970:      	mov.s	v4[2], v18[0]
    2974:      	mov.s	v4[3], v19[0]
    2978:      	mov.s	v20[1], v21[0]
    297c:      	mov.s	v20[2], v22[0]
    2980:      	mov.s	v20[3], v23[0]
    2984:      	rbit	w9, w5
    2988:      	clz	w9, w9
    298c:      	stp	q4, q20, [sp, #0x380]
    2990:      	and	x9, x9, #0x7
    2994:      	add	x11, sp, #0x380
    2998:      	ldr	s4, [x11, x9, lsl #2]
    299c:      	mov	b17, v9[0]
    29a0:      	mov.b	v17[4], v9[1]
    29a4:      	ushll.2d	v17, v17, #0x0
    29a8:      	shl.2d	v17, v17, #0x3f
    29ac:      	cmlt.2d	v17, v17, #0
    29b0:      	mov	b18, v9[2]
    29b4:      	mov.b	v18[4], v9[3]
    29b8:      	ldr	q19, [sp, #0xc0]
    29bc:      	and.16b	v17, v17, v19
    29c0:      	ushll.2d	v18, v18, #0x0
    29c4:      	shl.2d	v18, v18, #0x3f
    29c8:      	cmlt.2d	v18, v18, #0
    29cc:      	ldp	q19, q20, [sp, #0x70]
    29d0:      	and.16b	v18, v18, v19
    29d4:      	mov	b19, v9[4]
    29d8:      	mov.b	v19[4], v9[5]
    29dc:      	ushll.2d	v19, v19, #0x0
    29e0:      	shl.2d	v19, v19, #0x3f
    29e4:      	cmlt.2d	v19, v19, #0
    29e8:      	and.16b	v19, v19, v20
    29ec:      	mov	b20, v9[6]
    29f0:      	mov.b	v20[4], v9[7]
    29f4:      	ushll.2d	v20, v20, #0x0
    29f8:      	shl.2d	v20, v20, #0x3f
    29fc:      	cmlt.2d	v20, v20, #0
    2a00:      	ldr	q21, [sp, #0xa0]
    2a04:      	and.16b	v20, v20, v21
    2a08:      	stp	q19, q20, [sp, #0x360]
    2a0c:      	stp	q17, q18, [sp, #0x340]
    2a10:      	and	x9, x4, #0x7
    2a14:      	add	x11, sp, #0x340
    2a18:      	ldr	x9, [x11, x9, lsl #3]
    2a1c:      	mov	x30, x4
    2a20:      	sub	x9, x9, x4
    2a24:      	add	x9, x20, x9, lsl #2
    2a28:      	movi.2d	v17, #0000000000000000
    2a2c:      	movi.2d	v18, #0000000000000000
    2a30:      	tbz	w8, #0x0, 0x2a38 <ltmp0+0x2a38>
    2a34:      	ldr	s17, [x9]
    2a38:      	adrp	x1, 0x2000 <ltmp0+0x2000>
    2a3c:      	adrp	x4, 0x2000 <ltmp0+0x2000>
    2a40:      	adrp	x17, 0x2000 <ltmp0+0x2000>
    2a44:      	adrp	x5, 0x2000 <ltmp0+0x2000>
    2a48:      	adrp	x6, 0x2000 <ltmp0+0x2000>
    2a4c:      	adrp	x7, 0x2000 <ltmp0+0x2000>
    2a50:      	adrp	x19, 0x2000 <ltmp0+0x2000>
    2a54:      	adrp	x20, 0x2000 <ltmp0+0x2000>
    2a58:      	ldr	x2, [sp, #0x138]
    2a5c:      	ldr	q26, [sp, #0x290]
    2a60:      	tbnz	w8, #0x1, 0x2ed0 <ltmp0+0x2ed0>
    2a64:      	ldr	w15, [sp, #0x174]
    2a68:      	adrp	x16, 0x2000 <ltmp0+0x2000>
    2a6c:      	ldr	w13, [sp, #0x170]
    2a70:      	ldr	w0, [sp, #0x16c]
    2a74:      	tbnz	w8, #0x2, 0x2eec <ltmp0+0x2eec>
    2a78:      	tbnz	w8, #0x3, 0x2ef8 <ltmp0+0x2ef8>
    2a7c:      	tbnz	w8, #0x4, 0x2f04 <ltmp0+0x2f04>
    2a80:      	tbnz	w8, #0x5, 0x2f10 <ltmp0+0x2f10>
    2a84:      	tbnz	w8, #0x6, 0x2f1c <ltmp0+0x2f1c>
    2a88:      	tbz	w8, #0x7, 0x2a94 <ltmp0+0x2a94>
    2a8c:      	add	x8, x9, #0x1c
    2a90:      	ld1.s	{ v18 }[3], [x8]
    2a94:      	mov	x9, #0x0                ; =0
    2a98:      	fadd	s4, s4, s11
    2a9c:      	mov	w8, #0x800              ; =2048
    2aa0:      	movk	w8, #0x4580, lsl #16
    2aa4:      	fmov	s19, w8
    2aa8:      	fdiv	s4, s4, s19
    2aac:      	add	x8, sp, #0x580
    2ab0:      	add	x8, x8, x3
    2ab4:      	ldp	q19, q20, [x8]
    2ab8:      	zip2.8b	v21, v9, v0
    2abc:      	ushll.4s	v21, v21, #0x0
    2ac0:      	shl.4s	v21, v21, #0x1f
    2ac4:      	cmlt.4s	v21, v21, #0
    2ac8:      	bif.16b	v18, v20, v21
    2acc:      	zip1.8b	v20, v9, v0
    2ad0:      	ushll.4s	v20, v20, #0x0
    2ad4:      	shl.4s	v20, v20, #0x1f
    2ad8:      	cmlt.4s	v20, v20, #0
    2adc:      	bif.16b	v17, v19, v20
    2ae0:      	stp	q17, q18, [x8]
    2ae4:      	mov	w8, #0xc5ac             ; =50604
    2ae8:      	movk	w8, #0x3727, lsl #16
    2aec:      	fmov	s17, w8
    2af0:      	fadd	s4, s4, s17
    2af4:      	fsqrt	s4, s4
    2af8:      	dup.4s	v4, v4[0]
    2afc:      	ldr	q17, [sp, #0xd0]
    2b00:      	fmov	x8, d17
    2b04:      	add	x8, x2, x8, lsl #2
    2b08:      	movi.2d	v17, #0000000000000000
    2b0c:      	movi.2d	v18, #0000000000000000
    2b10:      	movi.2d	v19, #0000000000000000
    2b14:      	movi.2d	v20, #0000000000000000
    2b18:      	b	0x2b38 <ltmp0+0x2b38>
    2b1c:      	add.2d	v18, v18, v30
    2b20:      	add.2d	v19, v19, v8
    2b24:      	add.2d	v20, v20, v5
    2b28:      	add.2d	v17, v17, v31
    2b2c:      	fmov	x9, d17
    2b30:      	cmp	x9, #0x200
    2b34:      	b.ge	0x2dc0 <ltmp0+0x2dc0>
    2b38:      	fmov	w11, s16
    2b3c:      	shl.2d	v21, v17, #0x5
    2b40:      	ldr	q22, [sp, #0x2a0]
    2b44:      	orr.16b	v23, v21, v22
    2b48:      	add.2d	v24, v28, v23
    2b4c:      	movi.2d	v21, #0000000000000000
    2b50:      	movi.2d	v22, #0000000000000000
    2b54:      	tbnz	w11, #0x0, 0x2c30 <ltmp0+0x2c30>
    2b58:      	and	w11, w11, #0xff
    2b5c:      	tbnz	w11, #0x1, 0x2c40 <ltmp0+0x2c40>
    2b60:      	shl.2d	v24, v18, #0x5
    2b64:      	ldr	q25, [sp, #0x2c0]
    2b68:      	orr.16b	v24, v24, v25
    2b6c:      	add.2d	v25, v29, v24
    2b70:      	tbnz	w11, #0x2, 0x2c5c <ltmp0+0x2c5c>
    2b74:      	tbnz	w11, #0x3, 0x2c68 <ltmp0+0x2c68>
    2b78:      	shl.2d	v25, v19, #0x5
    2b7c:      	ldr	q27, [sp, #0x2b0]
    2b80:      	orr.16b	v25, v25, v27
    2b84:      	add.2d	v26, v26, v25
    2b88:      	tbnz	w11, #0x4, 0x2c84 <ltmp0+0x2c84>
    2b8c:      	tbnz	w11, #0x5, 0x2c90 <ltmp0+0x2c90>
    2b90:      	shl.2d	v26, v20, #0x5
    2b94:      	ldp	q28, q27, [sp, #0x2d0]
    2b98:      	orr.16b	v26, v26, v28
    2b9c:      	add.2d	v27, v27, v26
    2ba0:      	tbnz	w11, #0x6, 0x2cac <ltmp0+0x2cac>
    2ba4:      	tbnz	w11, #0x7, 0x2cb8 <ltmp0+0x2cb8>
    2ba8:      	fmov	w11, s16
    2bac:      	add.2d	v28, v7, v23
    2bb0:      	movi.2d	v27, #0000000000000000
    2bb4:      	movi.2d	v23, #0000000000000000
    2bb8:      	tbnz	w11, #0x0, 0x2cd4 <ltmp0+0x2cd4>
    2bbc:      	and	w11, w11, #0xff
    2bc0:      	tbnz	w11, #0x1, 0x2ce4 <ltmp0+0x2ce4>
    2bc4:      	ldr	q28, [sp, #0x270]
    2bc8:      	add.2d	v24, v15, v24
    2bcc:      	tbnz	w11, #0x2, 0x2cf8 <ltmp0+0x2cf8>
    2bd0:      	tbnz	w11, #0x3, 0x2d04 <ltmp0+0x2d04>
    2bd4:      	add.2d	v24, v6, v25
    2bd8:      	tbnz	w11, #0x4, 0x2d14 <ltmp0+0x2d14>
    2bdc:      	tbnz	w11, #0x5, 0x2d20 <ltmp0+0x2d20>
    2be0:      	add.2d	v24, v14, v26
    2be4:      	tbnz	w11, #0x6, 0x2d30 <ltmp0+0x2d30>
    2be8:      	tbnz	w11, #0x7, 0x2d3c <ltmp0+0x2d3c>
    2bec:      	fdiv.4s	v21, v21, v4
    2bf0:      	fmov	w11, s16
    2bf4:      	fmul.4s	v21, v21, v27
    2bf8:      	add	x9, x8, x9, lsl #5
    2bfc:      	tbnz	w11, #0x0, 0x2d58 <ltmp0+0x2d58>
    2c00:      	and	w11, w11, #0xff
    2c04:      	ldr	q26, [sp, #0x290]
    2c08:      	tbnz	w11, #0x1, 0x2d68 <ltmp0+0x2d68>
    2c0c:      	tbnz	w11, #0x2, 0x2d74 <ltmp0+0x2d74>
    2c10:      	tbnz	w11, #0x3, 0x2d80 <ltmp0+0x2d80>
    2c14:      	fdiv.4s	v21, v22, v4
    2c18:      	fmul.4s	v21, v21, v23
    2c1c:      	tbnz	w11, #0x4, 0x2d94 <ltmp0+0x2d94>
    2c20:      	tbnz	w11, #0x5, 0x2d9c <ltmp0+0x2d9c>
    2c24:      	tbnz	w11, #0x6, 0x2da8 <ltmp0+0x2da8>
    2c28:      	tbz	w11, #0x7, 0x2b1c <ltmp0+0x2b1c>
    2c2c:      	b	0x2db4 <ltmp0+0x2db4>
    2c30:      	fmov	x12, d24
    2c34:      	ldr	s21, [x12]
    2c38:      	and	w11, w11, #0xff
    2c3c:      	tbz	w11, #0x1, 0x2b60 <ltmp0+0x2b60>
    2c40:      	mov.d	x12, v24[1]
    2c44:      	ld1.s	{ v21 }[1], [x12]
    2c48:      	shl.2d	v24, v18, #0x5
    2c4c:      	ldr	q25, [sp, #0x2c0]
    2c50:      	orr.16b	v24, v24, v25
    2c54:      	add.2d	v25, v29, v24
    2c58:      	tbz	w11, #0x2, 0x2b74 <ltmp0+0x2b74>
    2c5c:      	fmov	x12, d25
    2c60:      	ld1.s	{ v21 }[2], [x12]
    2c64:      	tbz	w11, #0x3, 0x2b78 <ltmp0+0x2b78>
    2c68:      	mov.d	x12, v25[1]
    2c6c:      	ld1.s	{ v21 }[3], [x12]
    2c70:      	shl.2d	v25, v19, #0x5
    2c74:      	ldr	q27, [sp, #0x2b0]
    2c78:      	orr.16b	v25, v25, v27
    2c7c:      	add.2d	v26, v26, v25
    2c80:      	tbz	w11, #0x4, 0x2b8c <ltmp0+0x2b8c>
    2c84:      	fmov	x12, d26
    2c88:      	ld1.s	{ v22 }[0], [x12]
    2c8c:      	tbz	w11, #0x5, 0x2b90 <ltmp0+0x2b90>
    2c90:      	mov.d	x12, v26[1]
    2c94:      	ld1.s	{ v22 }[1], [x12]
    2c98:      	shl.2d	v26, v20, #0x5
    2c9c:      	ldp	q28, q27, [sp, #0x2d0]
    2ca0:      	orr.16b	v26, v26, v28
    2ca4:      	add.2d	v27, v27, v26
    2ca8:      	tbz	w11, #0x6, 0x2ba4 <ltmp0+0x2ba4>
    2cac:      	fmov	x12, d27
    2cb0:      	ld1.s	{ v22 }[2], [x12]
    2cb4:      	tbz	w11, #0x7, 0x2ba8 <ltmp0+0x2ba8>
    2cb8:      	mov.d	x11, v27[1]
    2cbc:      	ld1.s	{ v22 }[3], [x11]
    2cc0:      	fmov	w11, s16
    2cc4:      	add.2d	v28, v7, v23
    2cc8:      	movi.2d	v27, #0000000000000000
    2ccc:      	movi.2d	v23, #0000000000000000
    2cd0:      	tbz	w11, #0x0, 0x2bbc <ltmp0+0x2bbc>
    2cd4:      	fmov	x12, d28
    2cd8:      	ldr	s27, [x12]
    2cdc:      	and	w11, w11, #0xff
    2ce0:      	tbz	w11, #0x1, 0x2bc4 <ltmp0+0x2bc4>
    2ce4:      	mov.d	x12, v28[1]
    2ce8:      	ld1.s	{ v27 }[1], [x12]
    2cec:      	ldr	q28, [sp, #0x270]
    2cf0:      	add.2d	v24, v15, v24
    2cf4:      	tbz	w11, #0x2, 0x2bd0 <ltmp0+0x2bd0>
    2cf8:      	fmov	x12, d24
    2cfc:      	ld1.s	{ v27 }[2], [x12]
    2d00:      	tbz	w11, #0x3, 0x2bd4 <ltmp0+0x2bd4>
    2d04:      	mov.d	x12, v24[1]
    2d08:      	ld1.s	{ v27 }[3], [x12]
    2d0c:      	add.2d	v24, v6, v25
    2d10:      	tbz	w11, #0x4, 0x2bdc <ltmp0+0x2bdc>
    2d14:      	fmov	x12, d24
    2d18:      	ld1.s	{ v23 }[0], [x12]
    2d1c:      	tbz	w11, #0x5, 0x2be0 <ltmp0+0x2be0>
    2d20:      	mov.d	x12, v24[1]
    2d24:      	ld1.s	{ v23 }[1], [x12]
    2d28:      	add.2d	v24, v14, v26
    2d2c:      	tbz	w11, #0x6, 0x2be8 <ltmp0+0x2be8>
    2d30:      	fmov	x12, d24
    2d34:      	ld1.s	{ v23 }[2], [x12]
    2d38:      	tbz	w11, #0x7, 0x2bec <ltmp0+0x2bec>
    2d3c:      	mov.d	x11, v24[1]
    2d40:      	ld1.s	{ v23 }[3], [x11]
    2d44:      	fdiv.4s	v21, v21, v4
    2d48:      	fmov	w11, s16
    2d4c:      	fmul.4s	v21, v21, v27
    2d50:      	add	x9, x8, x9, lsl #5
    2d54:      	tbz	w11, #0x0, 0x2c00 <ltmp0+0x2c00>
    2d58:      	str	s21, [x9]
    2d5c:      	and	w11, w11, #0xff
    2d60:      	ldr	q26, [sp, #0x290]
    2d64:      	tbz	w11, #0x1, 0x2c0c <ltmp0+0x2c0c>
    2d68:      	add	x12, x9, #0x4
    2d6c:      	st1.s	{ v21 }[1], [x12]
    2d70:      	tbz	w11, #0x2, 0x2c10 <ltmp0+0x2c10>
    2d74:      	add	x12, x9, #0x8
    2d78:      	st1.s	{ v21 }[2], [x12]
    2d7c:      	tbz	w11, #0x3, 0x2c14 <ltmp0+0x2c14>
    2d80:      	add	x12, x9, #0xc
    2d84:      	st1.s	{ v21 }[3], [x12]
    2d88:      	fdiv.4s	v21, v22, v4
    2d8c:      	fmul.4s	v21, v21, v23
    2d90:      	tbz	w11, #0x4, 0x2c20 <ltmp0+0x2c20>
    2d94:      	str	s21, [x9, #0x10]
    2d98:      	tbz	w11, #0x5, 0x2c24 <ltmp0+0x2c24>
    2d9c:      	add	x12, x9, #0x14
    2da0:      	st1.s	{ v21 }[1], [x12]
    2da4:      	tbz	w11, #0x6, 0x2c28 <ltmp0+0x2c28>
    2da8:      	add	x12, x9, #0x18
    2dac:      	st1.s	{ v21 }[2], [x12]
    2db0:      	tbz	w11, #0x7, 0x2b1c <ltmp0+0x2b1c>
    2db4:      	add	x9, x9, #0x1c
    2db8:      	st1.s	{ v21 }[3], [x9]
    2dbc:      	b	0x2b1c <ltmp0+0x2b1c>
    2dc0:      	add	x8, x14, x3
    2dc4:      	ldp	q6, q5, [x8]
    2dc8:      	zip1.8b	v7, v9, v0
    2dcc:      	ushll.4s	v7, v7, #0x0
    2dd0:      	shl.4s	v7, v7, #0x1f
    2dd4:      	cmlt.4s	v7, v7, #0
    2dd8:      	and.16b	v6, v7, v6
    2ddc:      	fmov	w8, s2
    2de0:      	fdiv.4s	v6, v6, v4
    2de4:      	add	x9, sp, #0x580
    2de8:      	add	x9, x9, x3
    2dec:      	ldp	q16, q2, [x9]
    2df0:      	and.16b	v7, v7, v16
    2df4:      	fmul.4s	v6, v6, v7
    2df8:      	ldr	q7, [sp, #0x110]
    2dfc:      	str	q7, [sp, #0x2f0]
    2e00:      	ldr	q7, [sp, #0xf0]
    2e04:      	str	q7, [sp, #0x300]
    2e08:      	ldr	q7, [sp, #0xe0]
    2e0c:      	str	q7, [sp, #0x310]
    2e10:      	ldr	q7, [sp, #0x100]
    2e14:      	str	q7, [sp, #0x320]
    2e18:      	and	x9, x30, #0x7
    2e1c:      	add	x11, sp, #0x2f0
    2e20:      	ldr	x9, [x11, x9, lsl #3]
    2e24:      	sub	x9, x9, x30
    2e28:      	add	x9, x2, x9, lsl #2
    2e2c:      	tbnz	w8, #0x0, 0x2f2c <ltmp0+0x2f2c>
    2e30:      	ldr	x2, [sp, #0x178]
    2e34:      	tbnz	w8, #0x1, 0x2f38 <ltmp0+0x2f38>
    2e38:      	tbnz	w8, #0x2, 0x2f44 <ltmp0+0x2f44>
    2e3c:      	tbz	w8, #0x3, 0x2e48 <ltmp0+0x2e48>
    2e40:      	add	x11, x9, #0xc
    2e44:      	st1.s	{ v6 }[3], [x11]
    2e48:      	zip2.8b	v6, v9, v0
    2e4c:      	ushll.4s	v6, v6, #0x0
    2e50:      	shl.4s	v6, v6, #0x1f
    2e54:      	cmlt.4s	v6, v6, #0
    2e58:      	and.16b	v5, v6, v5
    2e5c:      	fdiv.4s	v4, v5, v4
    2e60:      	and.16b	v2, v6, v2
    2e64:      	fmul.4s	v2, v4, v2
    2e68:      	tbnz	w8, #0x4, 0x2f54 <ltmp0+0x2f54>
    2e6c:      	tbnz	w8, #0x5, 0x2f5c <ltmp0+0x2f5c>
    2e70:      	tbnz	w8, #0x6, 0x2f68 <ltmp0+0x2f68>
    2e74:      	tbz	w8, #0x7, 0xd0 <ltmp0+0xd0>
    2e78:      	b	0x2f74 <ltmp0+0x2f74>
    2e7c:      	ldr	s26, [x8]
    2e80:      	tbz	w9, #0x1, 0x1d40 <ltmp0+0x1d40>
    2e84:      	add	x11, x8, #0x4
    2e88:      	ld1.s	{ v26 }[1], [x11]
    2e8c:      	tbz	w9, #0x2, 0x1d44 <ltmp0+0x1d44>
    2e90:      	add	x11, x8, #0x8
    2e94:      	ld1.s	{ v26 }[2], [x11]
    2e98:      	tbz	w9, #0x3, 0x1d48 <ltmp0+0x1d48>
    2e9c:      	add	x11, x8, #0xc
    2ea0:      	ld1.s	{ v26 }[3], [x11]
    2ea4:      	tbz	w9, #0x4, 0x1d4c <ltmp0+0x1d4c>
    2ea8:      	add	x11, x8, #0x10
    2eac:      	ld1.s	{ v27 }[0], [x11]
    2eb0:      	tbz	w9, #0x5, 0x1d50 <ltmp0+0x1d50>
    2eb4:      	add	x11, x8, #0x14
    2eb8:      	ld1.s	{ v27 }[1], [x11]
    2ebc:      	tbz	w9, #0x6, 0x1d54 <ltmp0+0x1d54>
    2ec0:      	add	x11, x8, #0x18
    2ec4:      	ld1.s	{ v27 }[2], [x11]
    2ec8:      	tbnz	w9, #0x7, 0x1d58 <ltmp0+0x1d58>
    2ecc:      	b	0x1d60 <ltmp0+0x1d60>
    2ed0:      	add	x11, x9, #0x4
    2ed4:      	ld1.s	{ v17 }[1], [x11]
    2ed8:      	ldr	w15, [sp, #0x174]
    2edc:      	adrp	x16, 0x2000 <ltmp0+0x2000>
    2ee0:      	ldr	w13, [sp, #0x170]
    2ee4:      	ldr	w0, [sp, #0x16c]
    2ee8:      	tbz	w8, #0x2, 0x2a78 <ltmp0+0x2a78>
    2eec:      	add	x11, x9, #0x8
    2ef0:      	ld1.s	{ v17 }[2], [x11]
    2ef4:      	tbz	w8, #0x3, 0x2a7c <ltmp0+0x2a7c>
    2ef8:      	add	x11, x9, #0xc
    2efc:      	ld1.s	{ v17 }[3], [x11]
    2f00:      	tbz	w8, #0x4, 0x2a80 <ltmp0+0x2a80>
    2f04:      	add	x11, x9, #0x10
    2f08:      	ld1.s	{ v18 }[0], [x11]
    2f0c:      	tbz	w8, #0x5, 0x2a84 <ltmp0+0x2a84>
    2f10:      	add	x11, x9, #0x14
    2f14:      	ld1.s	{ v18 }[1], [x11]
    2f18:      	tbz	w8, #0x6, 0x2a88 <ltmp0+0x2a88>
    2f1c:      	add	x11, x9, #0x18
    2f20:      	ld1.s	{ v18 }[2], [x11]
    2f24:      	tbnz	w8, #0x7, 0x2a8c <ltmp0+0x2a8c>
    2f28:      	b	0x2a94 <ltmp0+0x2a94>
    2f2c:      	str	s6, [x9]
    2f30:      	ldr	x2, [sp, #0x178]
    2f34:      	tbz	w8, #0x1, 0x2e38 <ltmp0+0x2e38>
    2f38:      	add	x11, x9, #0x4
    2f3c:      	st1.s	{ v6 }[1], [x11]
    2f40:      	tbz	w8, #0x2, 0x2e3c <ltmp0+0x2e3c>
    2f44:      	add	x11, x9, #0x8
    2f48:      	st1.s	{ v6 }[2], [x11]
    2f4c:      	tbnz	w8, #0x3, 0x2e40 <ltmp0+0x2e40>
    2f50:      	b	0x2e48 <ltmp0+0x2e48>
    2f54:      	str	s2, [x9, #0x10]
    2f58:      	tbz	w8, #0x5, 0x2e70 <ltmp0+0x2e70>
    2f5c:      	add	x11, x9, #0x14
    2f60:      	st1.s	{ v2 }[1], [x11]
    2f64:      	tbz	w8, #0x6, 0x2e74 <ltmp0+0x2e74>
    2f68:      	add	x11, x9, #0x18
    2f6c:      	st1.s	{ v2 }[2], [x11]
    2f70:      	tbz	w8, #0x7, 0xd0 <ltmp0+0xd0>
    2f74:      	add	x8, x9, #0x1c
    2f78:      	st1.s	{ v2 }[3], [x8]
    2f7c:      	b	0xd0 <ltmp0+0xd0>
    2f80:      	ldr	x9, [sp, #0x8]
    2f84:      	stp	w2, w0, [x9]
    2f88:      	str	w13, [x9, #0x8]
    2f8c:      	mov	w8, #0x18               ; =24
    2f90:      	str	w8, [x9, #0x24]
    2f94:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    2f98:      	add	sp, sp, #0x5c0
    2f9c:      	ldp	x29, x30, [sp, #0x90]
    2fa0:      	ldp	x20, x19, [sp, #0x80]
    2fa4:      	ldp	x22, x21, [sp, #0x70]
    2fa8:      	ldp	x24, x23, [sp, #0x60]
    2fac:      	ldp	x26, x25, [sp, #0x50]
    2fb0:      	ldp	x28, x27, [sp, #0x40]
    2fb4:      	ldp	d9, d8, [sp, #0x30]
    2fb8:      	ldp	d11, d10, [sp, #0x20]
    2fbc:      	ldp	d13, d12, [sp, #0x10]
    2fc0:      	ldp	d15, d14, [sp], #0xa0
    2fc4:      	ret

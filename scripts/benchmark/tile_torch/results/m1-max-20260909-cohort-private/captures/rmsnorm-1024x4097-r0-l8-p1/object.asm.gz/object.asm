
/tmp/luisa-cohort-private.qfZvpM/capture/rmsnorm-1024x4097-r0-l8-p1/object/tile_xir_w8_77312_1788916369792215_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x8, lsl #12   ; =0x8000
      2c:      	sub	sp, sp, #0x420
      30:      	str	x0, [sp, #0x68]
      34:      	cbz	w3, 0x1728 <ltmp0+0x1728>
      38:      	mov	w25, #0x0               ; =0
      3c:      	add	x26, sp, #0x4, lsl #12  ; =0x4000
      40:      	add	x26, x26, #0x400
      44:      	ldp	w9, w8, [x2, #0x2c]
      48:      	stp	w8, w9, [sp, #0x90]
      4c:      	add	x19, sp, #0x3e0
      50:      	ldp	w8, w9, [x2]
      54:      	ldp	w10, w11, [x2, #0x8]
      58:      	str	x2, [sp, #0x8]
      5c:      	str	x11, [sp, #0x88]
      60:      	movi	d8, #0000000000000000
      64:      	str	w3, [sp, #0x98]
      68:      	b	0xac <ltmp0+0xac>
      6c:      	ldr	w25, [sp, #0x9c]
      70:      	add	w8, w7, #0x1
      74:      	ldp	w11, w9, [sp, #0x90]
      78:      	cmp	w8, w9
      7c:      	cset	w9, eq
      80:      	csinc	w8, wzr, w7, eq
      84:      	ldp	w13, w12, [sp, #0xa0]
      88:      	cinc	w10, w13, eq
      8c:      	cmp	w10, w11
      90:      	cset	w11, eq
      94:      	ands	w11, w9, w11
      98:      	csel	w9, wzr, w10, ne
      9c:      	add	w10, w12, w11
      a0:      	add	w25, w25, #0x1
      a4:      	cmp	w25, w3
      a8:      	b.eq	0x1714 <ltmp0+0x1714>
      ac:      	stp	w9, w10, [sp, #0xa0]
      b0:      	mov	x13, x8
      b4:      	ubfiz	x8, x8, #5, #32
      b8:      	ldr	x12, [sp, #0x88]
      bc:      	cmp	x8, x12
      c0:      	csel	x9, x8, xzr, ls
      c4:      	subs	x10, x12, x9
      c8:      	cmp	x10, #0x20
      cc:      	mov	w11, #0x20              ; =32
      d0:      	csel	x10, x10, x11, lo
      d4:      	cmp	x12, x9
      d8:      	ccmp	x8, x12, #0x2, hi
      dc:      	csel	x9, x10, xzr, ls
      e0:      	cmp	x9, #0x20
      e4:      	str	x13, [sp, #0xa8]
      e8:      	b.lo	0x850 <ltmp0+0x850>
      ec:      	ldr	x8, [sp, #0x68]
      f0:      	ldr	x28, [x8]
      f4:      	ldr	x22, [x8, #0x10]
      f8:      	ldr	x20, [x8, #0x30]
      fc:      	ubfiz	w27, w13, #2, #27
     100:      	mov	w8, #0x4004             ; =16388
     104:      	umull	x23, w27, w8
     108:      	umaddl	x1, w27, w8, x28
     10c:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     110:      	add	x0, x0, #0x400
     114:      	mov	w2, #0x4000             ; =16384
     118:      	bl	0x118 <ltmp0+0x118>
     11c:      	mov	x8, #0x0                ; =0
     120:      	add	x21, x23, #0x4, lsl #12 ; =0x4000
     124:      	ldr	s0, [x28, x21]
     128:      	str	q0, [sp, #0x140]
     12c:      	str	q0, [sp, #0x8400]
     130:      	ldr	q0, [sp, #0x4400]
     134:      	ldr	q1, [sp, #0x4410]
     138:      	fmul.4s	v3, v1, v1
     13c:      	fmul.4s	v2, v0, v0
     140:      	ldr	q0, [sp, #0x4420]
     144:      	ldr	q1, [sp, #0x4430]
     148:      	fmul.4s	v5, v1, v1
     14c:      	fmul.4s	v4, v0, v0
     150:      	ldr	q0, [sp, #0x4440]
     154:      	ldr	q1, [sp, #0x4450]
     158:      	fmul.4s	v6, v1, v1
     15c:      	fmul.4s	v7, v0, v0
     160:      	ldr	q0, [sp, #0x4460]
     164:      	ldr	q1, [sp, #0x4470]
     168:      	fmul.4s	v17, v1, v1
     16c:      	fmul.4s	v16, v0, v0
     170:      	add	x9, x26, x8, lsl #5
     174:      	ldp	q1, q0, [x9, #0x80]
     178:      	fmul.4s	v1, v1, v1
     17c:      	fmul.4s	v0, v0, v0
     180:      	fadd.4s	v3, v3, v0
     184:      	fadd.4s	v2, v2, v1
     188:      	ldp	q1, q0, [x9, #0xa0]
     18c:      	fmul.4s	v1, v1, v1
     190:      	fmul.4s	v0, v0, v0
     194:      	fadd.4s	v5, v5, v0
     198:      	fadd.4s	v4, v4, v1
     19c:      	ldp	q1, q0, [x9, #0xc0]
     1a0:      	fmul.4s	v1, v1, v1
     1a4:      	fmul.4s	v0, v0, v0
     1a8:      	fadd.4s	v6, v6, v0
     1ac:      	fadd.4s	v7, v7, v1
     1b0:      	ldp	q1, q0, [x9, #0xe0]
     1b4:      	fmul.4s	v1, v1, v1
     1b8:      	fmul.4s	v0, v0, v0
     1bc:      	fadd.4s	v17, v17, v0
     1c0:      	fadd.4s	v16, v16, v1
     1c4:      	add	x8, x8, #0x4
     1c8:      	cmp	x8, #0x1fc
     1cc:      	b.lo	0x170 <ltmp0+0x170>
     1d0:      	add	x0, sp, #0x3e0
     1d4:      	mov	x1, x22
     1d8:      	mov	w2, #0x4000             ; =16384
     1dc:      	stp	q2, q5, [sp, #0xc0]
     1e0:      	stp	q3, q7, [sp, #0xe0]
     1e4:      	stp	q4, q17, [sp, #0x100]
     1e8:      	stp	q6, q16, [sp, #0x120]
     1ec:      	bl	0x1ec <ltmp0+0x1ec>
     1f0:      	mov	x8, #0x0                ; =0
     1f4:      	ldr	q7, [sp, #0x140]
     1f8:      	fmul.4s	v0, v7, v7
     1fc:      	ldp	q1, q2, [sp, #0xc0]
     200:      	fadd.4s	v0, v0, v1
     204:      	mov.s	v1[0], v0[0]
     208:      	ldr	q0, [sp, #0xe0]
     20c:      	fadd.4s	v0, v2, v0
     210:      	ldp	q2, q3, [sp, #0xf0]
     214:      	fadd.4s	v1, v3, v1
     218:      	fadd.4s	v1, v2, v1
     21c:      	ldp	q2, q3, [sp, #0x110]
     220:      	fadd.4s	v0, v3, v0
     224:      	fadd.4s	v0, v2, v0
     228:      	ldr	q2, [sp, #0x130]
     22c:      	fadd.4s	v1, v2, v1
     230:      	rev64.4s	v2, v1
     234:      	rev64.4s	v3, v0
     238:      	fadd.4s	v1, v1, v2
     23c:      	dup.4s	v2, v1[2]
     240:      	fadd.4s	v0, v0, v3
     244:      	dup.4s	v3, v0[2]
     248:      	fadd.4s	v0, v0, v3
     24c:      	fadd.4s	v1, v1, v2
     250:      	fadd.4s	v0, v1, v0
     254:      	fadd	s0, s0, s8
     258:      	mov	w9, #0x800              ; =2048
     25c:      	movk	w9, #0x4580, lsl #16
     260:      	fmov	s1, w9
     264:      	fdiv	s1, s0, s1
     268:      	add	x24, x22, #0x4, lsl #12 ; =0x4000
     26c:      	ldr	s0, [x24]
     270:      	str	q0, [sp, #0x43e0]
     274:      	mov	w9, #0xc5ac             ; =50604
     278:      	movk	w9, #0x3727, lsl #16
     27c:      	fmov	s2, w9
     280:      	fadd	s1, s1, s2
     284:      	fsqrt	s1, s1
     288:      	dup.4s	v2, v1[0]
     28c:      	add	x9, x20, x23
     290:      	add	x10, x26, x8
     294:      	ldp	q3, q4, [x10]
     298:      	fdiv.4s	v4, v4, v2
     29c:      	fdiv.4s	v3, v3, v2
     2a0:      	add	x10, x19, x8
     2a4:      	ldp	q6, q5, [x10]
     2a8:      	fmul.4s	v3, v3, v6
     2ac:      	fmul.4s	v4, v4, v5
     2b0:      	add	x10, x9, x8
     2b4:      	stp	q3, q4, [x10]
     2b8:      	add	x8, x8, #0x20
     2bc:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     2c0:      	b.ne	0x290 <ltmp0+0x290>
     2c4:      	fdiv.4s	v1, v7, v1
     2c8:      	fmul.4s	v0, v1, v0
     2cc:      	str	s0, [x20, x21]
     2d0:      	orr	w8, w27, #0x1
     2d4:      	mov	w9, #0x4004             ; =16388
     2d8:      	umull	x23, w8, w9
     2dc:      	umaddl	x1, w8, w9, x28
     2e0:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     2e4:      	add	x0, x0, #0x400
     2e8:      	mov	w2, #0x4000             ; =16384
     2ec:      	bl	0x2ec <ltmp0+0x2ec>
     2f0:      	mov	x8, #0x0                ; =0
     2f4:      	add	x21, x23, #0x4, lsl #12 ; =0x4000
     2f8:      	ldr	s0, [x28, x21]
     2fc:      	str	q0, [sp, #0x140]
     300:      	str	q0, [sp, #0x8400]
     304:      	ldr	q0, [sp, #0x4400]
     308:      	ldr	q1, [sp, #0x4410]
     30c:      	fmul.4s	v3, v1, v1
     310:      	fmul.4s	v2, v0, v0
     314:      	ldr	q0, [sp, #0x4420]
     318:      	ldr	q1, [sp, #0x4430]
     31c:      	fmul.4s	v5, v1, v1
     320:      	fmul.4s	v4, v0, v0
     324:      	ldr	q0, [sp, #0x4440]
     328:      	ldr	q1, [sp, #0x4450]
     32c:      	fmul.4s	v6, v1, v1
     330:      	fmul.4s	v7, v0, v0
     334:      	ldr	q0, [sp, #0x4460]
     338:      	ldr	q1, [sp, #0x4470]
     33c:      	fmul.4s	v17, v1, v1
     340:      	fmul.4s	v16, v0, v0
     344:      	add	x9, x26, x8, lsl #5
     348:      	ldp	q1, q0, [x9, #0x80]
     34c:      	fmul.4s	v1, v1, v1
     350:      	fmul.4s	v0, v0, v0
     354:      	fadd.4s	v3, v3, v0
     358:      	fadd.4s	v2, v2, v1
     35c:      	ldp	q1, q0, [x9, #0xa0]
     360:      	fmul.4s	v1, v1, v1
     364:      	fmul.4s	v0, v0, v0
     368:      	fadd.4s	v5, v5, v0
     36c:      	fadd.4s	v4, v4, v1
     370:      	ldp	q1, q0, [x9, #0xc0]
     374:      	fmul.4s	v1, v1, v1
     378:      	fmul.4s	v0, v0, v0
     37c:      	fadd.4s	v6, v6, v0
     380:      	fadd.4s	v7, v7, v1
     384:      	ldp	q1, q0, [x9, #0xe0]
     388:      	fmul.4s	v1, v1, v1
     38c:      	fmul.4s	v0, v0, v0
     390:      	fadd.4s	v17, v17, v0
     394:      	fadd.4s	v16, v16, v1
     398:      	add	x8, x8, #0x4
     39c:      	cmp	x8, #0x1fc
     3a0:      	b.lo	0x344 <ltmp0+0x344>
     3a4:      	add	x0, sp, #0x3e0
     3a8:      	mov	x1, x22
     3ac:      	mov	w2, #0x4000             ; =16384
     3b0:      	stp	q2, q5, [sp, #0xc0]
     3b4:      	stp	q3, q7, [sp, #0xe0]
     3b8:      	stp	q4, q17, [sp, #0x100]
     3bc:      	stp	q6, q16, [sp, #0x120]
     3c0:      	bl	0x3c0 <ltmp0+0x3c0>
     3c4:      	mov	x8, #0x0                ; =0
     3c8:      	ldr	q7, [sp, #0x140]
     3cc:      	fmul.4s	v0, v7, v7
     3d0:      	ldp	q1, q2, [sp, #0xc0]
     3d4:      	fadd.4s	v0, v0, v1
     3d8:      	mov.s	v1[0], v0[0]
     3dc:      	ldr	q0, [sp, #0xe0]
     3e0:      	fadd.4s	v0, v2, v0
     3e4:      	ldp	q2, q3, [sp, #0xf0]
     3e8:      	fadd.4s	v1, v3, v1
     3ec:      	fadd.4s	v1, v2, v1
     3f0:      	ldp	q2, q3, [sp, #0x110]
     3f4:      	fadd.4s	v0, v3, v0
     3f8:      	fadd.4s	v0, v2, v0
     3fc:      	ldr	q2, [sp, #0x130]
     400:      	fadd.4s	v1, v2, v1
     404:      	rev64.4s	v2, v1
     408:      	rev64.4s	v3, v0
     40c:      	fadd.4s	v0, v0, v3
     410:      	fadd.4s	v1, v1, v2
     414:      	dup.4s	v2, v1[2]
     418:      	dup.4s	v3, v0[2]
     41c:      	fadd.4s	v0, v0, v3
     420:      	fadd.4s	v1, v1, v2
     424:      	fadd.4s	v0, v1, v0
     428:      	fadd	s0, s0, s8
     42c:      	mov	w9, #0x800              ; =2048
     430:      	movk	w9, #0x4580, lsl #16
     434:      	fmov	s1, w9
     438:      	fdiv	s1, s0, s1
     43c:      	ldr	s0, [x24]
     440:      	str	q0, [sp, #0x43e0]
     444:      	mov	w9, #0xc5ac             ; =50604
     448:      	movk	w9, #0x3727, lsl #16
     44c:      	fmov	s2, w9
     450:      	fadd	s1, s1, s2
     454:      	fsqrt	s1, s1
     458:      	dup.4s	v2, v1[0]
     45c:      	add	x9, x20, x23
     460:      	add	x10, x26, x8
     464:      	ldp	q3, q4, [x10]
     468:      	fdiv.4s	v4, v4, v2
     46c:      	fdiv.4s	v3, v3, v2
     470:      	add	x10, x19, x8
     474:      	ldp	q6, q5, [x10]
     478:      	fmul.4s	v3, v3, v6
     47c:      	fmul.4s	v4, v4, v5
     480:      	add	x10, x9, x8
     484:      	stp	q3, q4, [x10]
     488:      	add	x8, x8, #0x20
     48c:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     490:      	b.ne	0x460 <ltmp0+0x460>
     494:      	fdiv.4s	v1, v7, v1
     498:      	fmul.4s	v0, v1, v0
     49c:      	str	s0, [x20, x21]
     4a0:      	orr	w8, w27, #0x2
     4a4:      	mov	w9, #0x4004             ; =16388
     4a8:      	umull	x23, w8, w9
     4ac:      	umaddl	x1, w8, w9, x28
     4b0:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     4b4:      	add	x0, x0, #0x400
     4b8:      	mov	w2, #0x4000             ; =16384
     4bc:      	bl	0x4bc <ltmp0+0x4bc>
     4c0:      	mov	x8, #0x0                ; =0
     4c4:      	add	x21, x23, #0x4, lsl #12 ; =0x4000
     4c8:      	ldr	s0, [x28, x21]
     4cc:      	str	q0, [sp, #0x140]
     4d0:      	str	q0, [sp, #0x8400]
     4d4:      	ldr	q0, [sp, #0x4400]
     4d8:      	ldr	q1, [sp, #0x4410]
     4dc:      	fmul.4s	v3, v1, v1
     4e0:      	fmul.4s	v2, v0, v0
     4e4:      	ldr	q0, [sp, #0x4420]
     4e8:      	ldr	q1, [sp, #0x4430]
     4ec:      	fmul.4s	v5, v1, v1
     4f0:      	fmul.4s	v4, v0, v0
     4f4:      	ldr	q0, [sp, #0x4440]
     4f8:      	ldr	q1, [sp, #0x4450]
     4fc:      	fmul.4s	v6, v1, v1
     500:      	fmul.4s	v7, v0, v0
     504:      	ldr	q0, [sp, #0x4460]
     508:      	ldr	q1, [sp, #0x4470]
     50c:      	fmul.4s	v17, v1, v1
     510:      	fmul.4s	v16, v0, v0
     514:      	add	x9, x26, x8, lsl #5
     518:      	ldp	q1, q0, [x9, #0x80]
     51c:      	fmul.4s	v1, v1, v1
     520:      	fmul.4s	v0, v0, v0
     524:      	fadd.4s	v3, v3, v0
     528:      	fadd.4s	v2, v2, v1
     52c:      	ldp	q1, q0, [x9, #0xa0]
     530:      	fmul.4s	v1, v1, v1
     534:      	fmul.4s	v0, v0, v0
     538:      	fadd.4s	v5, v5, v0
     53c:      	fadd.4s	v4, v4, v1
     540:      	ldp	q1, q0, [x9, #0xc0]
     544:      	fmul.4s	v1, v1, v1
     548:      	fmul.4s	v0, v0, v0
     54c:      	fadd.4s	v6, v6, v0
     550:      	fadd.4s	v7, v7, v1
     554:      	ldp	q1, q0, [x9, #0xe0]
     558:      	fmul.4s	v1, v1, v1
     55c:      	fmul.4s	v0, v0, v0
     560:      	fadd.4s	v17, v17, v0
     564:      	fadd.4s	v16, v16, v1
     568:      	add	x8, x8, #0x4
     56c:      	cmp	x8, #0x1fc
     570:      	b.lo	0x514 <ltmp0+0x514>
     574:      	add	x0, sp, #0x3e0
     578:      	mov	x1, x22
     57c:      	mov	w2, #0x4000             ; =16384
     580:      	stp	q2, q5, [sp, #0xc0]
     584:      	stp	q3, q7, [sp, #0xe0]
     588:      	stp	q4, q17, [sp, #0x100]
     58c:      	stp	q6, q16, [sp, #0x120]
     590:      	bl	0x590 <ltmp0+0x590>
     594:      	mov	x8, #0x0                ; =0
     598:      	ldr	q7, [sp, #0x140]
     59c:      	fmul.4s	v0, v7, v7
     5a0:      	ldp	q1, q2, [sp, #0xc0]
     5a4:      	fadd.4s	v0, v0, v1
     5a8:      	mov.s	v1[0], v0[0]
     5ac:      	ldr	q0, [sp, #0xe0]
     5b0:      	fadd.4s	v0, v2, v0
     5b4:      	ldp	q2, q3, [sp, #0xf0]
     5b8:      	fadd.4s	v1, v3, v1
     5bc:      	fadd.4s	v1, v2, v1
     5c0:      	ldp	q2, q3, [sp, #0x110]
     5c4:      	fadd.4s	v0, v3, v0
     5c8:      	fadd.4s	v0, v2, v0
     5cc:      	ldr	q2, [sp, #0x130]
     5d0:      	fadd.4s	v1, v2, v1
     5d4:      	rev64.4s	v2, v1
     5d8:      	rev64.4s	v3, v0
     5dc:      	fadd.4s	v0, v0, v3
     5e0:      	fadd.4s	v1, v1, v2
     5e4:      	dup.4s	v2, v1[2]
     5e8:      	dup.4s	v3, v0[2]
     5ec:      	fadd.4s	v0, v0, v3
     5f0:      	fadd.4s	v1, v1, v2
     5f4:      	fadd.4s	v0, v1, v0
     5f8:      	fadd	s0, s0, s8
     5fc:      	mov	w9, #0x800              ; =2048
     600:      	movk	w9, #0x4580, lsl #16
     604:      	fmov	s1, w9
     608:      	fdiv	s1, s0, s1
     60c:      	ldr	s0, [x24]
     610:      	str	q0, [sp, #0x43e0]
     614:      	mov	w9, #0xc5ac             ; =50604
     618:      	movk	w9, #0x3727, lsl #16
     61c:      	fmov	s2, w9
     620:      	fadd	s1, s1, s2
     624:      	fsqrt	s1, s1
     628:      	dup.4s	v2, v1[0]
     62c:      	add	x9, x20, x23
     630:      	add	x10, x26, x8
     634:      	ldp	q3, q4, [x10]
     638:      	fdiv.4s	v4, v4, v2
     63c:      	fdiv.4s	v3, v3, v2
     640:      	add	x10, x19, x8
     644:      	ldp	q6, q5, [x10]
     648:      	fmul.4s	v3, v3, v6
     64c:      	fmul.4s	v4, v4, v5
     650:      	add	x10, x9, x8
     654:      	stp	q3, q4, [x10]
     658:      	add	x8, x8, #0x20
     65c:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     660:      	b.ne	0x630 <ltmp0+0x630>
     664:      	fdiv.4s	v1, v7, v1
     668:      	fmul.4s	v0, v1, v0
     66c:      	str	s0, [x20, x21]
     670:      	orr	w8, w27, #0x3
     674:      	mov	w9, #0x4004             ; =16388
     678:      	umull	x23, w8, w9
     67c:      	umaddl	x1, w8, w9, x28
     680:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     684:      	add	x0, x0, #0x400
     688:      	mov	w2, #0x4000             ; =16384
     68c:      	bl	0x68c <ltmp0+0x68c>
     690:      	mov	x8, #0x0                ; =0
     694:      	add	x21, x23, #0x4, lsl #12 ; =0x4000
     698:      	ldr	s0, [x28, x21]
     69c:      	str	q0, [sp, #0x140]
     6a0:      	str	q0, [sp, #0x8400]
     6a4:      	ldr	q0, [sp, #0x4400]
     6a8:      	ldr	q1, [sp, #0x4410]
     6ac:      	fmul.4s	v3, v1, v1
     6b0:      	fmul.4s	v2, v0, v0
     6b4:      	ldr	q0, [sp, #0x4420]
     6b8:      	ldr	q1, [sp, #0x4430]
     6bc:      	fmul.4s	v5, v1, v1
     6c0:      	fmul.4s	v4, v0, v0
     6c4:      	ldr	q0, [sp, #0x4440]
     6c8:      	ldr	q1, [sp, #0x4450]
     6cc:      	fmul.4s	v6, v1, v1
     6d0:      	fmul.4s	v7, v0, v0
     6d4:      	ldr	q0, [sp, #0x4460]
     6d8:      	ldr	q1, [sp, #0x4470]
     6dc:      	fmul.4s	v17, v1, v1
     6e0:      	fmul.4s	v16, v0, v0
     6e4:      	add	x9, x26, x8, lsl #5
     6e8:      	ldp	q1, q0, [x9, #0x80]
     6ec:      	fmul.4s	v1, v1, v1
     6f0:      	fmul.4s	v0, v0, v0
     6f4:      	fadd.4s	v3, v3, v0
     6f8:      	fadd.4s	v2, v2, v1
     6fc:      	ldp	q1, q0, [x9, #0xa0]
     700:      	fmul.4s	v1, v1, v1
     704:      	fmul.4s	v0, v0, v0
     708:      	fadd.4s	v5, v5, v0
     70c:      	fadd.4s	v4, v4, v1
     710:      	ldp	q1, q0, [x9, #0xc0]
     714:      	fmul.4s	v1, v1, v1
     718:      	fmul.4s	v0, v0, v0
     71c:      	fadd.4s	v6, v6, v0
     720:      	fadd.4s	v7, v7, v1
     724:      	ldp	q1, q0, [x9, #0xe0]
     728:      	fmul.4s	v1, v1, v1
     72c:      	fmul.4s	v0, v0, v0
     730:      	fadd.4s	v17, v17, v0
     734:      	fadd.4s	v16, v16, v1
     738:      	add	x8, x8, #0x4
     73c:      	cmp	x8, #0x1fc
     740:      	b.lo	0x6e4 <ltmp0+0x6e4>
     744:      	add	x0, sp, #0x3e0
     748:      	mov	x1, x22
     74c:      	mov	w2, #0x4000             ; =16384
     750:      	stp	q2, q5, [sp, #0xc0]
     754:      	stp	q3, q7, [sp, #0xe0]
     758:      	stp	q4, q17, [sp, #0x100]
     75c:      	stp	q6, q16, [sp, #0x120]
     760:      	bl	0x760 <ltmp0+0x760>
     764:      	mov	x8, #0x0                ; =0
     768:      	ldr	q7, [sp, #0x140]
     76c:      	fmul.4s	v0, v7, v7
     770:      	ldp	q1, q3, [sp, #0xc0]
     774:      	fadd.4s	v0, v0, v1
     778:      	mov.s	v1[0], v0[0]
     77c:      	mov.16b	v2, v1
     780:      	ldr	s0, [x24]
     784:      	ldr	q1, [sp, #0xe0]
     788:      	fadd.4s	v1, v3, v1
     78c:      	ldp	q3, q4, [sp, #0xf0]
     790:      	fadd.4s	v2, v4, v2
     794:      	fadd.4s	v2, v3, v2
     798:      	ldp	q3, q4, [sp, #0x110]
     79c:      	fadd.4s	v1, v4, v1
     7a0:      	fadd.4s	v1, v3, v1
     7a4:      	ldr	q3, [sp, #0x130]
     7a8:      	fadd.4s	v2, v3, v2
     7ac:      	rev64.4s	v3, v2
     7b0:      	rev64.4s	v4, v1
     7b4:      	fadd.4s	v1, v1, v4
     7b8:      	fadd.4s	v2, v2, v3
     7bc:      	dup.4s	v3, v2[2]
     7c0:      	dup.4s	v4, v1[2]
     7c4:      	fadd.4s	v1, v1, v4
     7c8:      	fadd.4s	v2, v2, v3
     7cc:      	fadd.4s	v1, v2, v1
     7d0:      	fadd	s1, s1, s8
     7d4:      	mov	w9, #0x800              ; =2048
     7d8:      	movk	w9, #0x4580, lsl #16
     7dc:      	fmov	s2, w9
     7e0:      	fdiv	s1, s1, s2
     7e4:      	str	q0, [sp, #0x43e0]
     7e8:      	mov	w9, #0xc5ac             ; =50604
     7ec:      	movk	w9, #0x3727, lsl #16
     7f0:      	fmov	s2, w9
     7f4:      	fadd	s1, s1, s2
     7f8:      	fsqrt	s1, s1
     7fc:      	dup.4s	v2, v1[0]
     800:      	add	x9, x20, x23
     804:      	add	x10, x26, x8
     808:      	ldp	q3, q4, [x10]
     80c:      	fdiv.4s	v4, v4, v2
     810:      	fdiv.4s	v3, v3, v2
     814:      	add	x10, x19, x8
     818:      	ldp	q6, q5, [x10]
     81c:      	fmul.4s	v3, v3, v6
     820:      	fmul.4s	v4, v4, v5
     824:      	add	x10, x9, x8
     828:      	stp	q3, q4, [x10]
     82c:      	add	x8, x8, #0x20
     830:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     834:      	b.ne	0x804 <ltmp0+0x804>
     838:      	fdiv.4s	v1, v7, v1
     83c:      	fmul.4s	v0, v1, v0
     840:      	str	s0, [x20, x21]
     844:      	ldr	x7, [sp, #0xa8]
     848:      	ldr	w3, [sp, #0x98]
     84c:      	b	0x70 <ltmp0+0x70>
     850:      	str	w25, [sp, #0x9c]
     854:      	lsr	x8, x9, #3
     858:      	str	x8, [sp, #0xb0]
     85c:      	str	x9, [sp, #0x70]
     860:      	cmp	x9, #0x8
     864:      	b.lo	0xa80 <ltmp0+0xa80>
     868:      	mov	x27, #0x0               ; =0
     86c:      	ldr	x8, [sp, #0x68]
     870:      	ldr	x28, [x8]
     874:      	ldr	x22, [x8, #0x10]
     878:      	ldr	x21, [x8, #0x30]
     87c:      	add	x25, x22, #0x4, lsl #12 ; =0x4000
     880:      	ldr	x8, [sp, #0xa8]
     884:      	lsl	w23, w8, #2
     888:      	and	x8, x8, #0x7ffffff
     88c:      	mov	w9, #0x10               ; =16
     890:      	movk	w9, #0x1, lsl #16
     894:      	umaddl	x24, w8, w9, x21
     898:      	add	w8, w27, w23
     89c:      	and	x8, x8, #0x1fffffff
     8a0:      	add	x8, x8, x8, lsl #12
     8a4:      	lsl	x20, x8, #2
     8a8:      	add	x0, sp, #0x4, lsl #12   ; =0x4000
     8ac:      	add	x0, x0, #0x400
     8b0:      	add	x1, x28, x20
     8b4:      	mov	w2, #0x4000             ; =16384
     8b8:      	bl	0x8b8 <ltmp0+0x8b8>
     8bc:      	mov	x8, #0x0                ; =0
     8c0:      	add	x20, x20, #0x4, lsl #12 ; =0x4000
     8c4:      	ldr	s0, [x28, x20]
     8c8:      	str	q0, [sp, #0x140]
     8cc:      	str	q0, [sp, #0x8400]
     8d0:      	ldr	q0, [sp, #0x4400]
     8d4:      	ldr	q1, [sp, #0x4410]
     8d8:      	fmul.4s	v3, v1, v1
     8dc:      	fmul.4s	v2, v0, v0
     8e0:      	ldr	q0, [sp, #0x4420]
     8e4:      	ldr	q1, [sp, #0x4430]
     8e8:      	fmul.4s	v5, v1, v1
     8ec:      	fmul.4s	v4, v0, v0
     8f0:      	ldr	q0, [sp, #0x4440]
     8f4:      	ldr	q1, [sp, #0x4450]
     8f8:      	fmul.4s	v6, v1, v1
     8fc:      	fmul.4s	v7, v0, v0
     900:      	ldr	q0, [sp, #0x4460]
     904:      	ldr	q1, [sp, #0x4470]
     908:      	fmul.4s	v17, v1, v1
     90c:      	fmul.4s	v16, v0, v0
     910:      	add	x9, x26, x8, lsl #5
     914:      	ldp	q1, q0, [x9, #0x80]
     918:      	fmul.4s	v1, v1, v1
     91c:      	fmul.4s	v0, v0, v0
     920:      	fadd.4s	v3, v3, v0
     924:      	fadd.4s	v2, v2, v1
     928:      	ldp	q1, q0, [x9, #0xa0]
     92c:      	fmul.4s	v1, v1, v1
     930:      	fmul.4s	v0, v0, v0
     934:      	fadd.4s	v5, v5, v0
     938:      	fadd.4s	v4, v4, v1
     93c:      	ldp	q1, q0, [x9, #0xc0]
     940:      	fmul.4s	v1, v1, v1
     944:      	fmul.4s	v0, v0, v0
     948:      	fadd.4s	v6, v6, v0
     94c:      	fadd.4s	v7, v7, v1
     950:      	ldp	q1, q0, [x9, #0xe0]
     954:      	fmul.4s	v1, v1, v1
     958:      	fmul.4s	v0, v0, v0
     95c:      	fadd.4s	v17, v17, v0
     960:      	fadd.4s	v16, v16, v1
     964:      	add	x8, x8, #0x4
     968:      	cmp	x8, #0x1fc
     96c:      	b.lo	0x910 <ltmp0+0x910>
     970:      	add	x0, sp, #0x3e0
     974:      	mov	x1, x22
     978:      	mov	w2, #0x4000             ; =16384
     97c:      	stp	q2, q5, [sp, #0xc0]
     980:      	stp	q3, q7, [sp, #0xe0]
     984:      	stp	q4, q17, [sp, #0x100]
     988:      	stp	q6, q16, [sp, #0x120]
     98c:      	bl	0x98c <ltmp0+0x98c>
     990:      	mov	x8, #0x0                ; =0
     994:      	ldr	q7, [sp, #0x140]
     998:      	fmul.4s	v0, v7, v7
     99c:      	ldp	q1, q2, [sp, #0xc0]
     9a0:      	fadd.4s	v0, v0, v1
     9a4:      	mov.s	v1[0], v0[0]
     9a8:      	ldr	q0, [sp, #0xe0]
     9ac:      	fadd.4s	v0, v2, v0
     9b0:      	ldp	q2, q3, [sp, #0xf0]
     9b4:      	fadd.4s	v1, v3, v1
     9b8:      	fadd.4s	v1, v2, v1
     9bc:      	ldp	q2, q3, [sp, #0x110]
     9c0:      	fadd.4s	v0, v3, v0
     9c4:      	fadd.4s	v0, v2, v0
     9c8:      	ldr	q2, [sp, #0x130]
     9cc:      	fadd.4s	v1, v2, v1
     9d0:      	rev64.4s	v2, v1
     9d4:      	rev64.4s	v3, v0
     9d8:      	fadd.4s	v0, v0, v3
     9dc:      	fadd.4s	v1, v1, v2
     9e0:      	dup.4s	v2, v1[2]
     9e4:      	dup.4s	v3, v0[2]
     9e8:      	fadd.4s	v0, v0, v3
     9ec:      	fadd.4s	v1, v1, v2
     9f0:      	fadd.4s	v0, v1, v0
     9f4:      	fadd	s0, s0, s8
     9f8:      	mov	w9, #0x800              ; =2048
     9fc:      	movk	w9, #0x4580, lsl #16
     a00:      	fmov	s1, w9
     a04:      	fdiv	s1, s0, s1
     a08:      	ldr	s0, [x25]
     a0c:      	str	q0, [sp, #0x43e0]
     a10:      	mov	w9, #0xc5ac             ; =50604
     a14:      	movk	w9, #0x3727, lsl #16
     a18:      	fmov	s2, w9
     a1c:      	fadd	s1, s1, s2
     a20:      	fsqrt	s1, s1
     a24:      	dup.4s	v2, v1[0]
     a28:      	add	x9, x26, x8
     a2c:      	ldp	q3, q4, [x9]
     a30:      	fdiv.4s	v4, v4, v2
     a34:      	fdiv.4s	v3, v3, v2
     a38:      	add	x9, x19, x8
     a3c:      	ldp	q6, q5, [x9]
     a40:      	fmul.4s	v3, v3, v6
     a44:      	fmul.4s	v4, v4, v5
     a48:      	add	x9, x24, x8
     a4c:      	stp	q3, q4, [x9]
     a50:      	add	x8, x8, #0x20
     a54:      	cmp	x8, #0x4, lsl #12       ; =0x4000
     a58:      	b.ne	0xa28 <ltmp0+0xa28>
     a5c:      	fdiv.4s	v1, v7, v1
     a60:      	fmul.4s	v0, v1, v0
     a64:      	str	s0, [x21, x20]
     a68:      	add	x27, x27, #0x1
     a6c:      	mov	w8, #0x4004             ; =16388
     a70:      	add	x24, x24, x8
     a74:      	ldr	x8, [sp, #0xb0]
     a78:      	cmp	x27, x8
     a7c:      	b.ne	0x898 <ltmp0+0x898>
     a80:      	ldr	x8, [sp, #0x70]
     a84:      	and	w8, w8, #0x7
     a88:      	ldp	w3, w25, [sp, #0x98]
     a8c:      	ldr	x7, [sp, #0xa8]
     a90:      	cbz	w8, 0x70 <ltmp0+0x70>
     a94:      	dup.4s	v1, w8
     a98:      	adrp	x8, 0x0 <ltmp0>
     a9c:      	ldr	q2, [x8]
     aa0:      	adrp	x8, 0x0 <ltmp0>
     aa4:      	ldr	q0, [x8]
     aa8:      	cmhi.4s	v0, v1, v0
     aac:      	cmhi.4s	v1, v1, v2
     ab0:      	uzp1.8h	v3, v1, v0
     ab4:      	umaxv.8h	h2, v3
     ab8:      	fmov	w8, s2
     abc:      	mov	w17, #0x4               ; =4
     ac0:      	tbz	w8, #0x0, 0x6c <ltmp0+0x6c>
     ac4:      	mov	x9, #0x0                ; =0
     ac8:      	ldr	x8, [sp, #0x68]
     acc:      	ldr	x12, [x8]
     ad0:      	ldr	x10, [x8, #0x10]
     ad4:      	ldr	x8, [x8, #0x30]
     ad8:      	adrp	x11, 0x0 <ltmp0>
     adc:      	ldr	q2, [x11]
     ae0:      	str	q3, [sp, #0x70]
     ae4:      	and.16b	v2, v3, v2
     ae8:      	addv.8h	h2, v2
     aec:      	ubfiz	w11, w7, #2, #27
     af0:      	ldr	x13, [sp, #0xb0]
     af4:      	orr	w13, w11, w13
     af8:      	fmov	w11, s2
     afc:      	and	w11, w11, #0xff
     b00:      	dup.4s	v3, w13
     b04:      	and.16b	v4, v1, v3
     b08:      	and.16b	v3, v0, v3
     b0c:      	ushll2.2d	v7, v3, #0x0
     b10:      	ushll2.2d	v16, v4, #0x0
     b14:      	ushll.2d	v17, v3, #0x0
     b18:      	ushll.2d	v3, v4, #0x0
     b1c:      	fmov	x13, d3
     b20:      	mov	w14, #0x4004            ; =16388
     b24:      	umaddl	x13, w13, w14, x12
     b28:      	b	0xb4c <ltmp0+0xb4c>
     b2c:      	add	x14, x26, x9
     b30:      	ldp	q6, q18, [x14]
     b34:      	bif.16b	v5, v18, v0
     b38:      	bif.16b	v4, v6, v1
     b3c:      	stp	q4, q5, [x14]
     b40:      	add	x9, x9, #0x20
     b44:      	cmp	x9, #0x4, lsl #12       ; =0x4000
     b48:      	b.eq	0xbe4 <ltmp0+0xbe4>
     b4c:      	fmov	w15, s2
     b50:      	add	x14, x13, x9
     b54:      	movi.2d	v4, #0000000000000000
     b58:      	movi.2d	v5, #0000000000000000
     b5c:      	tbnz	w15, #0x0, 0xb84 <ltmp0+0xb84>
     b60:      	and	w15, w15, #0xff
     b64:      	tbnz	w15, #0x1, 0xb90 <ltmp0+0xb90>
     b68:      	tbnz	w15, #0x2, 0xb9c <ltmp0+0xb9c>
     b6c:      	tbnz	w15, #0x3, 0xba8 <ltmp0+0xba8>
     b70:      	tbnz	w15, #0x4, 0xbb4 <ltmp0+0xbb4>
     b74:      	tbnz	w15, #0x5, 0xbc0 <ltmp0+0xbc0>
     b78:      	tbnz	w15, #0x6, 0xbcc <ltmp0+0xbcc>
     b7c:      	tbz	w15, #0x7, 0xb2c <ltmp0+0xb2c>
     b80:      	b	0xbd8 <ltmp0+0xbd8>
     b84:      	ldr	s4, [x14]
     b88:      	and	w15, w15, #0xff
     b8c:      	tbz	w15, #0x1, 0xb68 <ltmp0+0xb68>
     b90:      	add	x16, x14, #0x4
     b94:      	ld1.s	{ v4 }[1], [x16]
     b98:      	tbz	w15, #0x2, 0xb6c <ltmp0+0xb6c>
     b9c:      	add	x16, x14, #0x8
     ba0:      	ld1.s	{ v4 }[2], [x16]
     ba4:      	tbz	w15, #0x3, 0xb70 <ltmp0+0xb70>
     ba8:      	add	x16, x14, #0xc
     bac:      	ld1.s	{ v4 }[3], [x16]
     bb0:      	tbz	w15, #0x4, 0xb74 <ltmp0+0xb74>
     bb4:      	add	x16, x14, #0x10
     bb8:      	ld1.s	{ v5 }[0], [x16]
     bbc:      	tbz	w15, #0x5, 0xb78 <ltmp0+0xb78>
     bc0:      	add	x16, x14, #0x14
     bc4:      	ld1.s	{ v5 }[1], [x16]
     bc8:      	tbz	w15, #0x6, 0xb7c <ltmp0+0xb7c>
     bcc:      	add	x16, x14, #0x18
     bd0:      	ld1.s	{ v5 }[2], [x16]
     bd4:      	tbz	w15, #0x7, 0xb2c <ltmp0+0xb2c>
     bd8:      	add	x14, x14, #0x1c
     bdc:      	ld1.s	{ v5 }[3], [x14]
     be0:      	b	0xb2c <ltmp0+0xb2c>
     be4:      	xtn.4h	v4, v1
     be8:      	uzp1.8b	v4, v4, v0
     bec:      	sshll.2d	v18, v1, #0x0
     bf0:      	adrp	x9, 0x0 <ltmp0>
     bf4:      	ldr	q5, [x9]
     bf8:      	and.16b	v19, v18, v5
     bfc:      	movi.2d	v6, #0000000000000000
     c00:      	mov.b	v6[0], v4[0]
     c04:      	adrp	x9, 0x0 <ltmp0>
     c08:      	ldr	d5, [x9]
     c0c:      	str	d5, [sp, #0xd0]
     c10:      	and.8b	v5, v6, v5
     c14:      	addv.8b	b5, v5
     c18:      	fmov	w13, s5
     c1c:      	umaxv.8b	b5, v6
     c20:      	fmov	w14, s5
     c24:      	rbit	w9, w13
     c28:      	clz	w9, w9
     c2c:      	tst	w14, #0x1
     c30:      	csel	w9, w9, wzr, ne
     c34:      	mov	w15, #0x1000            ; =4096
     c38:      	dup.2d	v20, x15
     c3c:      	str	q19, [sp, #0x40]
     c40:      	orr.16b	v5, v19, v20
     c44:      	mov	w15, #0x1001            ; =4097
     c48:      	dup.2s	v19, w15
     c4c:      	xtn.2s	v23, v3
     c50:      	str	q5, [sp, #0xe0]
     c54:      	umlal.2d	v5, v23, v19
     c58:      	movi.2d	v3, #0000000000000000
     c5c:      	mov.b	v3[0], v4[0]
     c60:      	ushll.2d	v3, v3, #0x0
     c64:      	shl.2d	v3, v3, #0x3f
     c68:      	cmlt.2d	v3, v3, #0
     c6c:      	str	q5, [sp, #0x140]
     c70:      	and.16b	v3, v3, v5
     c74:      	movi.2d	v4, #0000000000000000
     c78:      	stp	q4, q4, [sp, #0x3b0]
     c7c:      	stp	q3, q4, [sp, #0x390]
     c80:      	and	x15, x9, #0x7
     c84:      	add	x16, sp, #0x390
     c88:      	ldr	x15, [x16, x15, lsl #3]
     c8c:      	sub	x15, x15, x9
     c90:      	add	x12, x12, x15, lsl #2
     c94:      	movi.2d	v5, #0000000000000000
     c98:      	movi.2d	v3, #0000000000000000
     c9c:      	tbnz	w14, #0x0, 0x160c <ltmp0+0x160c>
     ca0:      	tbnz	w13, #0x1, 0x1614 <ltmp0+0x1614>
     ca4:      	tbnz	w13, #0x2, 0x1620 <ltmp0+0x1620>
     ca8:      	tbnz	w13, #0x3, 0x162c <ltmp0+0x162c>
     cac:      	tbnz	w13, #0x4, 0x1638 <ltmp0+0x1638>
     cb0:      	tbnz	w13, #0x5, 0x1644 <ltmp0+0x1644>
     cb4:      	tbnz	w13, #0x6, 0x1650 <ltmp0+0x1650>
     cb8:      	tbz	w13, #0x7, 0xcc4 <ltmp0+0xcc4>
     cbc:      	add	x12, x12, #0x1c
     cc0:      	ld1.s	{ v3 }[3], [x12]
     cc4:      	sshll.2d	v4, v0, #0x0
     cc8:      	sshll2.2d	v21, v1, #0x0
     ccc:      	sshll2.2d	v22, v0, #0x0
     cd0:      	adrp	x12, 0x0 <ltmp0>
     cd4:      	ldr	q24, [x12]
     cd8:      	and.16b	v29, v22, v24
     cdc:      	adrp	x12, 0x0 <ltmp0>
     ce0:      	ldr	q24, [x12]
     ce4:      	and.16b	v28, v21, v24
     ce8:      	adrp	x12, 0x0 <ltmp0>
     cec:      	ldr	q24, [x12]
     cf0:      	and.16b	v26, v4, v24
     cf4:      	adrp	x12, 0x0 <ltmp0>
     cf8:      	ldr	q24, [x12]
     cfc:      	and.16b	v24, v22, v24
     d00:      	adrp	x12, 0x0 <ltmp0>
     d04:      	ldr	q25, [x12]
     d08:      	and.16b	v25, v21, v25
     d0c:      	adrp	x12, 0x0 <ltmp0>
     d10:      	ldr	q27, [x12]
     d14:      	and.16b	v27, v4, v27
     d18:      	adrp	x12, 0x0 <ltmp0>
     d1c:      	ldr	q4, [x12]
     d20:      	and.16b	v4, v18, v4
     d24:      	stp	q26, q28, [sp, #0x10]
     d28:      	orr.16b	v26, v26, v20
     d2c:      	orr.16b	v28, v28, v20
     d30:      	str	q29, [sp, #0x30]
     d34:      	orr.16b	v20, v29, v20
     d38:      	umull.2d	v29, v23, v19
     d3c:      	xtn.2s	v16, v16
     d40:      	xtn.2s	v17, v17
     d44:      	xtn.2s	v7, v7
     d48:      	stp	q26, q20, [sp, #0xb0]
     d4c:      	mov.16b	v18, v20
     d50:      	umlal.2d	v18, v7, v19
     d54:      	str	q28, [sp, #0x50]
     d58:      	mov.16b	v7, v28
     d5c:      	umlal.2d	v7, v16, v19
     d60:      	stp	q7, q18, [sp, #0x110]
     d64:      	mov.16b	v7, v26
     d68:      	umlal.2d	v7, v17, v19
     d6c:      	stp	q29, q7, [sp, #0xf0]
     d70:      	sshll.2d	v7, v1, #0x0
     d74:      	sshll.2d	v18, v0, #0x0
     d78:      	stp	q4, q25, [sp, #0x350]
     d7c:      	stp	q27, q24, [sp, #0x370]
     d80:      	and	x12, x9, #0x7
     d84:      	add	x14, sp, #0x350
     d88:      	ldr	x12, [x14, x12, lsl #3]
     d8c:      	orr	x12, x12, #0x4000
     d90:      	sub	x12, x12, x9, lsl #2
     d94:      	tst	w13, #0xff
     d98:      	csel	x12, xzr, x12, eq
     d9c:      	add	x13, x26, x12
     da0:      	ldp	q16, q17, [x13]
     da4:      	zip2.8b	v19, v6, v0
     da8:      	ushll.4s	v19, v19, #0x0
     dac:      	shl.4s	v19, v19, #0x1f
     db0:      	cmlt.4s	v19, v19, #0
     db4:      	str	q3, [sp, #0x130]
     db8:      	bit.16b	v17, v3, v19
     dbc:      	zip1.8b	v19, v6, v0
     dc0:      	ushll.4s	v19, v19, #0x0
     dc4:      	shl.4s	v19, v19, #0x1f
     dc8:      	cmlt.4s	v19, v19, #0
     dcc:      	mov.16b	v3, v5
     dd0:      	bit.16b	v16, v5, v19
     dd4:      	stp	q16, q17, [x13]
     dd8:      	dup.2d	v19, x17
     ddc:      	and.16b	v16, v22, v19
     de0:      	and.16b	v17, v21, v19
     de4:      	and.16b	v23, v18, v19
     de8:      	and.16b	v24, v7, v19
     dec:      	fmov	x13, d24
     df0:      	ldr	q7, [sp, #0x4470]
     df4:      	ldr	q18, [sp, #0x4460]
     df8:      	fmul.4s	v18, v18, v18
     dfc:      	fmul.4s	v7, v7, v7
     e00:      	and.16b	v10, v0, v7
     e04:      	and.16b	v11, v1, v18
     e08:      	ldr	q7, [sp, #0x4450]
     e0c:      	ldr	q18, [sp, #0x4440]
     e10:      	fmul.4s	v18, v18, v18
     e14:      	fmul.4s	v7, v7, v7
     e18:      	and.16b	v13, v0, v7
     e1c:      	and.16b	v12, v1, v18
     e20:      	ldr	q7, [sp, #0x4430]
     e24:      	ldr	q18, [sp, #0x4420]
     e28:      	fmul.4s	v18, v18, v18
     e2c:      	fmul.4s	v7, v7, v7
     e30:      	and.16b	v14, v0, v7
     e34:      	and.16b	v15, v1, v18
     e38:      	fmov	x14, d4
     e3c:      	add	x14, x26, x14
     e40:      	ldp	q7, q4, [x14]
     e44:      	fmul.4s	v7, v7, v7
     e48:      	fmul.4s	v4, v4, v4
     e4c:      	and.16b	v19, v0, v4
     e50:      	and.16b	v18, v1, v7
     e54:      	sshll.2d	v4, v1, #0x0
     e58:      	sshll.2d	v25, v0, #0x0
     e5c:      	add	x13, x26, x13, lsl #5
     e60:      	ldp	q20, q7, [x13]
     e64:      	and.16b	v20, v1, v20
     e68:      	and.16b	v7, v0, v7
     e6c:      	fmul.4s	v7, v7, v7
     e70:      	fmul.4s	v20, v20, v20
     e74:      	fadd.4s	v20, v18, v20
     e78:      	fadd.4s	v7, v19, v7
     e7c:      	ldp	q28, q27, [x13, #0x20]
     e80:      	and.16b	v28, v1, v28
     e84:      	and.16b	v27, v0, v27
     e88:      	fmul.4s	v27, v27, v27
     e8c:      	fmul.4s	v28, v28, v28
     e90:      	fadd.4s	v28, v15, v28
     e94:      	fadd.4s	v27, v14, v27
     e98:      	ldp	q5, q29, [x13, #0x40]
     e9c:      	and.16b	v5, v1, v5
     ea0:      	and.16b	v29, v0, v29
     ea4:      	fmul.4s	v29, v29, v29
     ea8:      	fmul.4s	v5, v5, v5
     eac:      	fadd.4s	v5, v12, v5
     eb0:      	fadd.4s	v29, v13, v29
     eb4:      	ldp	q31, q30, [x13, #0x60]
     eb8:      	and.16b	v31, v1, v31
     ebc:      	and.16b	v30, v0, v30
     ec0:      	fmul.4s	v30, v30, v30
     ec4:      	fmul.4s	v31, v31, v31
     ec8:      	fadd.4s	v31, v11, v31
     ecc:      	fadd.4s	v30, v10, v30
     ed0:      	dup.2d	v9, x17
     ed4:      	and.16b	v26, v22, v9
     ed8:      	add.2d	v16, v16, v26
     edc:      	and.16b	v26, v21, v9
     ee0:      	add.2d	v17, v17, v26
     ee4:      	and.16b	v25, v25, v9
     ee8:      	add.2d	v23, v23, v25
     eec:      	and.16b	v4, v4, v9
     ef0:      	add.2d	v24, v24, v4
     ef4:      	bit.16b	v19, v7, v0
     ef8:      	bit.16b	v18, v20, v1
     efc:      	bit.16b	v14, v27, v0
     f00:      	bit.16b	v15, v28, v1
     f04:      	bit.16b	v13, v29, v0
     f08:      	bit.16b	v12, v5, v1
     f0c:      	bit.16b	v10, v30, v0
     f10:      	bit.16b	v11, v31, v1
     f14:      	fmov	x13, d24
     f18:      	cmp	x13, #0x200
     f1c:      	b.lt	0xe54 <ltmp0+0xe54>
     f20:      	mov	x13, #0x0               ; =0
     f24:      	mov	w14, #0x1               ; =1
     f28:      	dup.2d	v4, x14
     f2c:      	ushll2.2d	v5, v0, #0x0
     f30:      	and.16b	v21, v5, v4
     f34:      	ushll2.2d	v5, v1, #0x0
     f38:      	and.16b	v22, v5, v4
     f3c:      	ushll.2d	v5, v0, #0x0
     f40:      	and.16b	v23, v5, v4
     f44:      	ushll.2d	v5, v1, #0x0
     f48:      	and.16b	v24, v5, v4
     f4c:      	movi.2d	v16, #0000000000000000
     f50:      	movi.2d	v17, #0000000000000000
     f54:      	movi.2d	v25, #0000000000000000
     f58:      	movi.2d	v27, #0000000000000000
     f5c:      	mov.16b	v29, v3
     f60:      	ldr	q3, [sp, #0x130]
     f64:      	b	0xf98 <ltmp0+0xf98>
     f68:      	add	x13, x19, x13
     f6c:      	ldp	q5, q26, [x13]
     f70:      	bif.16b	v4, v26, v0
     f74:      	bit.16b	v5, v28, v1
     f78:      	stp	q5, q4, [x13]
     f7c:      	add.2d	v17, v17, v22
     f80:      	add.2d	v25, v25, v23
     f84:      	add.2d	v27, v27, v21
     f88:      	add.2d	v16, v16, v24
     f8c:      	fmov	x13, d16
     f90:      	cmp	x13, #0x200
     f94:      	b.ge	0x1034 <ltmp0+0x1034>
     f98:      	fmov	w15, s2
     f9c:      	lsl	x13, x13, #5
     fa0:      	add	x14, x10, x13
     fa4:      	movi.2d	v28, #0000000000000000
     fa8:      	movi.2d	v4, #0000000000000000
     fac:      	tbnz	w15, #0x0, 0xfd4 <ltmp0+0xfd4>
     fb0:      	and	w15, w15, #0xff
     fb4:      	tbnz	w15, #0x1, 0xfe0 <ltmp0+0xfe0>
     fb8:      	tbnz	w15, #0x2, 0xfec <ltmp0+0xfec>
     fbc:      	tbnz	w15, #0x3, 0xff8 <ltmp0+0xff8>
     fc0:      	tbnz	w15, #0x4, 0x1004 <ltmp0+0x1004>
     fc4:      	tbnz	w15, #0x5, 0x1010 <ltmp0+0x1010>
     fc8:      	tbnz	w15, #0x6, 0x101c <ltmp0+0x101c>
     fcc:      	tbz	w15, #0x7, 0xf68 <ltmp0+0xf68>
     fd0:      	b	0x1028 <ltmp0+0x1028>
     fd4:      	ldr	s28, [x14]
     fd8:      	and	w15, w15, #0xff
     fdc:      	tbz	w15, #0x1, 0xfb8 <ltmp0+0xfb8>
     fe0:      	add	x16, x14, #0x4
     fe4:      	ld1.s	{ v28 }[1], [x16]
     fe8:      	tbz	w15, #0x2, 0xfbc <ltmp0+0xfbc>
     fec:      	add	x16, x14, #0x8
     ff0:      	ld1.s	{ v28 }[2], [x16]
     ff4:      	tbz	w15, #0x3, 0xfc0 <ltmp0+0xfc0>
     ff8:      	add	x16, x14, #0xc
     ffc:      	ld1.s	{ v28 }[3], [x16]
    1000:      	tbz	w15, #0x4, 0xfc4 <ltmp0+0xfc4>
    1004:      	add	x16, x14, #0x10
    1008:      	ld1.s	{ v4 }[0], [x16]
    100c:      	tbz	w15, #0x5, 0xfc8 <ltmp0+0xfc8>
    1010:      	add	x16, x14, #0x14
    1014:      	ld1.s	{ v4 }[1], [x16]
    1018:      	tbz	w15, #0x6, 0xfcc <ltmp0+0xfcc>
    101c:      	add	x16, x14, #0x18
    1020:      	ld1.s	{ v4 }[2], [x16]
    1024:      	tbz	w15, #0x7, 0xf68 <ltmp0+0xf68>
    1028:      	add	x14, x14, #0x1c
    102c:      	ld1.s	{ v4 }[3], [x14]
    1030:      	b	0xf68 <ltmp0+0xf68>
    1034:      	ldr	q4, [sp, #0x70]
    1038:      	xtn.8b	v26, v4
    103c:      	fmul.4s	v4, v29, v29
    1040:      	fmul.4s	v5, v3, v3
    1044:      	fadd.4s	v5, v5, v19
    1048:      	fadd.4s	v4, v4, v18
    104c:      	zip1.8b	v16, v6, v0
    1050:      	ushll.4s	v16, v16, #0x0
    1054:      	shl.4s	v16, v16, #0x1f
    1058:      	cmlt.4s	v16, v16, #0
    105c:      	and.16b	v4, v16, v4
    1060:      	zip2.8b	v16, v6, v0
    1064:      	ushll.4s	v16, v16, #0x0
    1068:      	shl.4s	v16, v16, #0x1f
    106c:      	cmlt.4s	v16, v16, #0
    1070:      	and.16b	v5, v16, v5
    1074:      	zip2.8b	v16, v26, v0
    1078:      	ushll.4s	v16, v16, #0x0
    107c:      	shl.4s	v16, v16, #0x1f
    1080:      	cmlt.4s	v16, v16, #0
    1084:      	movi.2d	v17, #0000000000000000
    1088:      	mov.b	v17[2], v26[1]
    108c:      	mov.b	v17[4], v26[2]
    1090:      	mov.b	v17[6], v26[3]
    1094:      	bit.16b	v5, v7, v16
    1098:      	ushll.4s	v7, v17, #0x0
    109c:      	shl.4s	v7, v7, #0x1f
    10a0:      	cmlt.4s	v7, v7, #0
    10a4:      	bit.16b	v4, v20, v7
    10a8:      	fadd.4s	v4, v15, v4
    10ac:      	fadd.4s	v5, v14, v5
    10b0:      	fadd.4s	v5, v13, v5
    10b4:      	fadd.4s	v4, v12, v4
    10b8:      	fadd.4s	v18, v11, v4
    10bc:      	fadd.4s	v19, v10, v5
    10c0:      	ldr	q4, [sp, #0x40]
    10c4:      	ldr	q5, [sp, #0x20]
    10c8:      	uzp1.4s	v7, v4, v5
    10cc:      	ldr	q4, [sp, #0x30]
    10d0:      	ldr	q5, [sp, #0x10]
    10d4:      	uzp1.4s	v20, v5, v4
    10d8:      	movi.4s	v5, #0x1
    10dc:      	eor.16b	v4, v7, v5
    10e0:      	mov.s	w14, v4[1]
    10e4:      	mov.s	w17, v4[2]
    10e8:      	eor.16b	v25, v20, v5
    10ec:      	mov.s	w0, v4[3]
    10f0:      	fmov	w13, s4
    10f4:      	add	x15, sp, #0x198
    10f8:      	bfxil	x15, x13, #0, #3
    10fc:      	str	d26, [sp, #0x198]
    1100:      	ldrb	w16, [x15]
    1104:      	and	x15, x13, #0x7
    1108:      	umov.b	w13, v26[0]
    110c:      	stp	q18, q19, [sp, #0x2a0]
    1110:      	add	x1, sp, #0x2a0
    1114:      	ldr	s4, [x1, x15, lsl #2]
    1118:      	ands	w15, w13, #0x1
    111c:      	tst	w15, w16
    1120:      	fcsel	s16, s4, s8, ne
    1124:      	add	x16, sp, #0x198
    1128:      	bfxil	x16, x14, #0, #3
    112c:      	ldrb	w16, [x16]
    1130:      	and	x1, x14, #0x7
    1134:      	umov.b	w14, v26[1]
    1138:      	stp	q18, q19, [sp, #0x280]
    113c:      	add	x2, sp, #0x280
    1140:      	ldr	s4, [x2, x1, lsl #2]
    1144:      	ands	w1, w14, #0x1
    1148:      	tst	w1, w16
    114c:      	fcsel	s17, s4, s8, ne
    1150:      	add	x16, sp, #0x198
    1154:      	bfxil	x16, x17, #0, #3
    1158:      	ldrb	w1, [x16]
    115c:      	umov.b	w16, v26[2]
    1160:      	and	x17, x17, #0x7
    1164:      	stp	q18, q19, [sp, #0x260]
    1168:      	add	x2, sp, #0x260
    116c:      	ldr	s4, [x2, x17, lsl #2]
    1170:      	ands	w17, w16, #0x1
    1174:      	tst	w17, w1
    1178:      	fcsel	s4, s4, s8, ne
    117c:      	add	x17, sp, #0x198
    1180:      	bfxil	x17, x0, #0, #3
    1184:      	ldrb	w1, [x17]
    1188:      	and	x0, x0, #0x7
    118c:      	umov.b	w17, v26[3]
    1190:      	stp	q18, q19, [sp, #0x240]
    1194:      	add	x2, sp, #0x240
    1198:      	ldr	s5, [x2, x0, lsl #2]
    119c:      	ands	w0, w17, #0x1
    11a0:      	tst	w0, w1
    11a4:      	mov.s	w1, v25[1]
    11a8:      	mov.s	w2, v25[2]
    11ac:      	fcsel	s27, s5, s8, ne
    11b0:      	mov.s	w4, v25[3]
    11b4:      	fmov	w0, s25
    11b8:      	and	x20, x0, #0x7
    11bc:      	add	x5, sp, #0x198
    11c0:      	bfxil	x5, x0, #0, #3
    11c4:      	ldrb	w5, [x5]
    11c8:      	umov.b	w0, v26[4]
    11cc:      	and	w5, w0, w5
    11d0:      	stp	q18, q19, [sp, #0x320]
    11d4:      	add	x6, sp, #0x320
    11d8:      	ldr	s5, [x6, x20, lsl #2]
    11dc:      	tst	w5, #0x1
    11e0:      	fcsel	s5, s5, s8, ne
    11e4:      	add	x5, sp, #0x198
    11e8:      	bfxil	x5, x1, #0, #3
    11ec:      	ldrb	w20, [x5]
    11f0:      	and	x5, x1, #0x7
    11f4:      	umov.b	w1, v26[5]
    11f8:      	stp	q18, q19, [sp, #0x300]
    11fc:      	add	x6, sp, #0x300
    1200:      	ldr	s25, [x6, x5, lsl #2]
    1204:      	ands	w5, w1, #0x1
    1208:      	tst	w5, w20
    120c:      	fcsel	s25, s25, s8, ne
    1210:      	add	x5, sp, #0x198
    1214:      	bfxil	x5, x2, #0, #3
    1218:      	ldrb	w20, [x5]
    121c:      	and	x5, x2, #0x7
    1220:      	umov.b	w2, v26[6]
    1224:      	stp	q18, q19, [sp, #0x2e0]
    1228:      	add	x6, sp, #0x2e0
    122c:      	ldr	s28, [x6, x5, lsl #2]
    1230:      	ands	w5, w2, #0x1
    1234:      	tst	w5, w20
    1238:      	fcsel	s28, s28, s8, ne
    123c:      	add	x5, sp, #0x198
    1240:      	bfxil	x5, x4, #0, #3
    1244:      	ldrb	w5, [x5]
    1248:      	umov.b	w20, v26[7]
    124c:      	and	x4, x4, #0x7
    1250:      	stp	q18, q19, [sp, #0x2c0]
    1254:      	add	x6, sp, #0x2c0
    1258:      	ldr	s26, [x6, x4, lsl #2]
    125c:      	ands	w4, w20, #0x1
    1260:      	tst	w4, w5
    1264:      	fcsel	s26, s26, s8, ne
    1268:      	mov.s	v5[1], v25[0]
    126c:      	mov.s	v5[2], v28[0]
    1270:      	mov.s	v5[3], v26[0]
    1274:      	mov.s	v16[1], v17[0]
    1278:      	mov.s	v16[2], v4[0]
    127c:      	mov.s	v16[3], v27[0]
    1280:      	fadd.4s	v4, v18, v16
    1284:      	fadd.4s	v5, v19, v5
    1288:      	movi.4s	v17, #0x2
    128c:      	eor.16b	v16, v20, v17
    1290:      	eor.16b	v7, v7, v17
    1294:      	fmov	w4, s7
    1298:      	add	x5, sp, #0x198
    129c:      	bfxil	x5, x4, #0, #3
    12a0:      	ldrb	w5, [x5]
    12a4:      	and	x4, x4, #0x7
    12a8:      	stp	q4, q5, [sp, #0x220]
    12ac:      	add	x6, sp, #0x220
    12b0:      	ldr	s7, [x6, x4, lsl #2]
    12b4:      	tst	w15, w5
    12b8:      	fcsel	s7, s7, s8, ne
    12bc:      	fmov	w4, s16
    12c0:      	and	x5, x4, #0x7
    12c4:      	add	x6, sp, #0x198
    12c8:      	bfxil	x6, x4, #0, #3
    12cc:      	ldrb	w4, [x6]
    12d0:      	and	w4, w0, w4
    12d4:      	stp	q4, q5, [sp, #0x200]
    12d8:      	add	x6, sp, #0x200
    12dc:      	ldr	s16, [x6, x5, lsl #2]
    12e0:      	tst	w4, #0x1
    12e4:      	fcsel	s16, s16, s8, ne
    12e8:      	fadd.4s	v5, v5, v16
    12ec:      	tst	w15, w0
    12f0:      	fcsel	s5, s5, s8, ne
    12f4:      	ands	w13, w13, #0x1
    12f8:      	fadd.4s	v4, v4, v7
    12fc:      	fadd	s4, s4, s5
    1300:      	fcsel	s5, s4, s8, ne
    1304:      	tst	w14, #0x1
    1308:      	fcsel	s7, s5, s8, ne
    130c:      	tst	w16, #0x1
    1310:      	fcsel	s16, s5, s8, ne
    1314:      	tst	w17, #0x1
    1318:      	fcsel	s17, s5, s8, ne
    131c:      	tst	w13, w0
    1320:      	fcsel	s4, s4, s8, ne
    1324:      	tst	w1, #0x1
    1328:      	fcsel	s18, s5, s8, ne
    132c:      	tst	w2, #0x1
    1330:      	fcsel	s19, s5, s8, ne
    1334:      	tst	w20, #0x1
    1338:      	shl.8b	v20, v6, #0x7
    133c:      	cmlt.8b	v20, v20, #0
    1340:      	ldr	d25, [sp, #0xd0]
    1344:      	and.8b	v20, v20, v25
    1348:      	addv.8b	b20, v20
    134c:      	fmov	w13, s20
    1350:      	fcsel	s25, s5, s8, ne
    1354:      	mov.s	v5[1], v7[0]
    1358:      	mov.s	v5[2], v16[0]
    135c:      	mov.s	v5[3], v17[0]
    1360:      	mov.s	v4[1], v18[0]
    1364:      	mov.s	v4[2], v19[0]
    1368:      	mov.s	v4[3], v25[0]
    136c:      	rbit	w11, w11
    1370:      	clz	w11, w11
    1374:      	stp	q5, q4, [sp, #0x1e0]
    1378:      	and	x11, x11, #0x7
    137c:      	add	x14, sp, #0x1e0
    1380:      	ldr	s19, [x14, x11, lsl #2]
    1384:      	mov	b4, v6[0]
    1388:      	mov.b	v4[4], v6[1]
    138c:      	ushll.2d	v4, v4, #0x0
    1390:      	shl.2d	v4, v4, #0x3f
    1394:      	cmlt.2d	v4, v4, #0
    1398:      	mov	b5, v6[2]
    139c:      	mov.b	v5[4], v6[3]
    13a0:      	ldr	q7, [sp, #0xe0]
    13a4:      	and.16b	v4, v4, v7
    13a8:      	ushll.2d	v5, v5, #0x0
    13ac:      	shl.2d	v5, v5, #0x3f
    13b0:      	cmlt.2d	v5, v5, #0
    13b4:      	ldr	q7, [sp, #0x50]
    13b8:      	and.16b	v5, v5, v7
    13bc:      	mov	b7, v6[4]
    13c0:      	mov.b	v7[4], v6[5]
    13c4:      	ushll.2d	v7, v7, #0x0
    13c8:      	shl.2d	v7, v7, #0x3f
    13cc:      	cmlt.2d	v7, v7, #0
    13d0:      	ldp	q16, q17, [sp, #0xb0]
    13d4:      	and.16b	v7, v7, v16
    13d8:      	mov	b16, v6[6]
    13dc:      	mov.b	v16[4], v6[7]
    13e0:      	ushll.2d	v16, v16, #0x0
    13e4:      	shl.2d	v16, v16, #0x3f
    13e8:      	cmlt.2d	v16, v16, #0
    13ec:      	and.16b	v16, v16, v17
    13f0:      	stp	q7, q16, [sp, #0x1c0]
    13f4:      	stp	q4, q5, [sp, #0x1a0]
    13f8:      	and	x11, x9, #0x7
    13fc:      	add	x14, sp, #0x1a0
    1400:      	ldr	x11, [x14, x11, lsl #3]
    1404:      	sub	x11, x11, x9
    1408:      	add	x10, x10, x11, lsl #2
    140c:      	movi.2d	v7, #0000000000000000
    1410:      	movi.2d	v18, #0000000000000000
    1414:      	tbnz	w13, #0x0, 0x1660 <ltmp0+0x1660>
    1418:      	tbnz	w13, #0x1, 0x1668 <ltmp0+0x1668>
    141c:      	tbnz	w13, #0x2, 0x1674 <ltmp0+0x1674>
    1420:      	tbnz	w13, #0x3, 0x1680 <ltmp0+0x1680>
    1424:      	tbnz	w13, #0x4, 0x168c <ltmp0+0x168c>
    1428:      	tbnz	w13, #0x5, 0x1698 <ltmp0+0x1698>
    142c:      	tbnz	w13, #0x6, 0x16a4 <ltmp0+0x16a4>
    1430:      	tbz	w13, #0x7, 0x143c <ltmp0+0x143c>
    1434:      	add	x10, x10, #0x1c
    1438:      	ld1.s	{ v18 }[3], [x10]
    143c:      	mov	x11, #0x0               ; =0
    1440:      	fadd	s4, s19, s8
    1444:      	mov	w10, #0x800             ; =2048
    1448:      	movk	w10, #0x4580, lsl #16
    144c:      	fmov	s5, w10
    1450:      	fdiv	s4, s4, s5
    1454:      	add	x10, x19, x12
    1458:      	ldp	q5, q16, [x10]
    145c:      	zip2.8b	v17, v6, v0
    1460:      	ushll.4s	v17, v17, #0x0
    1464:      	shl.4s	v17, v17, #0x1f
    1468:      	cmlt.4s	v17, v17, #0
    146c:      	bit.16b	v16, v18, v17
    1470:      	zip1.8b	v6, v6, v0
    1474:      	ushll.4s	v6, v6, #0x0
    1478:      	shl.4s	v6, v6, #0x1f
    147c:      	cmlt.4s	v6, v6, #0
    1480:      	bit.16b	v5, v7, v6
    1484:      	stp	q5, q16, [x10]
    1488:      	mov	w10, #0xc5ac            ; =50604
    148c:      	movk	w10, #0x3727, lsl #16
    1490:      	fmov	s5, w10
    1494:      	fadd	s4, s4, s5
    1498:      	fsqrt	s4, s4
    149c:      	dup.4s	v6, v4[0]
    14a0:      	ldr	q4, [sp, #0xf0]
    14a4:      	fmov	x10, d4
    14a8:      	add	x10, x8, x10, lsl #2
    14ac:      	movi.2d	v4, #0000000000000000
    14b0:      	movi.2d	v16, #0000000000000000
    14b4:      	movi.2d	v17, #0000000000000000
    14b8:      	movi.2d	v19, #0000000000000000
    14bc:      	b	0x14dc <ltmp0+0x14dc>
    14c0:      	add.2d	v16, v16, v22
    14c4:      	add.2d	v17, v17, v23
    14c8:      	add.2d	v19, v19, v21
    14cc:      	add.2d	v4, v4, v24
    14d0:      	fmov	x11, d4
    14d4:      	cmp	x11, #0x200
    14d8:      	b.ge	0x15ac <ltmp0+0x15ac>
    14dc:      	fmov	w12, s2
    14e0:      	lsl	x11, x11, #5
    14e4:      	add	x13, x26, x11
    14e8:      	ldp	q5, q25, [x13]
    14ec:      	and.16b	v5, v1, v5
    14f0:      	fdiv.4s	v5, v5, v6
    14f4:      	add	x13, x19, x11
    14f8:      	ldp	q27, q26, [x13]
    14fc:      	and.16b	v27, v1, v27
    1500:      	fmul.4s	v27, v5, v27
    1504:      	add	x11, x10, x11
    1508:      	tbnz	w12, #0x0, 0x1540 <ltmp0+0x1540>
    150c:      	and	w12, w12, #0xff
    1510:      	tbnz	w12, #0x1, 0x154c <ltmp0+0x154c>
    1514:      	tbnz	w12, #0x2, 0x1558 <ltmp0+0x1558>
    1518:      	tbnz	w12, #0x3, 0x1564 <ltmp0+0x1564>
    151c:      	and.16b	v5, v0, v25
    1520:      	fdiv.4s	v5, v5, v6
    1524:      	and.16b	v25, v0, v26
    1528:      	fmul.4s	v25, v5, v25
    152c:      	tbnz	w12, #0x4, 0x1580 <ltmp0+0x1580>
    1530:      	tbnz	w12, #0x5, 0x1588 <ltmp0+0x1588>
    1534:      	tbnz	w12, #0x6, 0x1594 <ltmp0+0x1594>
    1538:      	tbz	w12, #0x7, 0x14c0 <ltmp0+0x14c0>
    153c:      	b	0x15a0 <ltmp0+0x15a0>
    1540:      	str	s27, [x11]
    1544:      	and	w12, w12, #0xff
    1548:      	tbz	w12, #0x1, 0x1514 <ltmp0+0x1514>
    154c:      	add	x13, x11, #0x4
    1550:      	st1.s	{ v27 }[1], [x13]
    1554:      	tbz	w12, #0x2, 0x1518 <ltmp0+0x1518>
    1558:      	add	x13, x11, #0x8
    155c:      	st1.s	{ v27 }[2], [x13]
    1560:      	tbz	w12, #0x3, 0x151c <ltmp0+0x151c>
    1564:      	add	x13, x11, #0xc
    1568:      	st1.s	{ v27 }[3], [x13]
    156c:      	and.16b	v5, v0, v25
    1570:      	fdiv.4s	v5, v5, v6
    1574:      	and.16b	v25, v0, v26
    1578:      	fmul.4s	v25, v5, v25
    157c:      	tbz	w12, #0x4, 0x1530 <ltmp0+0x1530>
    1580:      	str	s25, [x11, #0x10]
    1584:      	tbz	w12, #0x5, 0x1534 <ltmp0+0x1534>
    1588:      	add	x13, x11, #0x14
    158c:      	st1.s	{ v25 }[1], [x13]
    1590:      	tbz	w12, #0x6, 0x1538 <ltmp0+0x1538>
    1594:      	add	x13, x11, #0x18
    1598:      	st1.s	{ v25 }[2], [x13]
    159c:      	tbz	w12, #0x7, 0x14c0 <ltmp0+0x14c0>
    15a0:      	add	x11, x11, #0x1c
    15a4:      	st1.s	{ v25 }[3], [x11]
    15a8:      	b	0x14c0 <ltmp0+0x14c0>
    15ac:      	fdiv.4s	v0, v29, v6
    15b0:      	fmul.4s	v0, v0, v7
    15b4:      	ldr	q2, [sp, #0x140]
    15b8:      	ldp	q5, q4, [sp, #0x100]
    15bc:      	stp	q2, q4, [sp, #0x150]
    15c0:      	ldr	q1, [sp, #0x120]
    15c4:      	stp	q5, q1, [sp, #0x170]
    15c8:      	and	x10, x9, #0x7
    15cc:      	add	x11, sp, #0x150
    15d0:      	ldr	x10, [x11, x10, lsl #3]
    15d4:      	sub	x9, x10, x9
    15d8:      	add	x8, x8, x9, lsl #2
    15dc:      	fmov	w9, s20
    15e0:      	tbnz	w9, #0x0, 0x16b4 <ltmp0+0x16b4>
    15e4:      	tbnz	w9, #0x1, 0x16bc <ltmp0+0x16bc>
    15e8:      	tbnz	w9, #0x2, 0x16c8 <ltmp0+0x16c8>
    15ec:      	tbnz	w9, #0x3, 0x16d4 <ltmp0+0x16d4>
    15f0:      	fdiv.4s	v0, v3, v6
    15f4:      	fmul.4s	v0, v0, v18
    15f8:      	tbnz	w9, #0x4, 0x16e8 <ltmp0+0x16e8>
    15fc:      	tbnz	w9, #0x5, 0x16f0 <ltmp0+0x16f0>
    1600:      	tbnz	w9, #0x6, 0x16fc <ltmp0+0x16fc>
    1604:      	tbz	w9, #0x7, 0x6c <ltmp0+0x6c>
    1608:      	b	0x1708 <ltmp0+0x1708>
    160c:      	ldr	s5, [x12]
    1610:      	tbz	w13, #0x1, 0xca4 <ltmp0+0xca4>
    1614:      	add	x14, x12, #0x4
    1618:      	ld1.s	{ v5 }[1], [x14]
    161c:      	tbz	w13, #0x2, 0xca8 <ltmp0+0xca8>
    1620:      	add	x14, x12, #0x8
    1624:      	ld1.s	{ v5 }[2], [x14]
    1628:      	tbz	w13, #0x3, 0xcac <ltmp0+0xcac>
    162c:      	add	x14, x12, #0xc
    1630:      	ld1.s	{ v5 }[3], [x14]
    1634:      	tbz	w13, #0x4, 0xcb0 <ltmp0+0xcb0>
    1638:      	add	x14, x12, #0x10
    163c:      	ld1.s	{ v3 }[0], [x14]
    1640:      	tbz	w13, #0x5, 0xcb4 <ltmp0+0xcb4>
    1644:      	add	x14, x12, #0x14
    1648:      	ld1.s	{ v3 }[1], [x14]
    164c:      	tbz	w13, #0x6, 0xcb8 <ltmp0+0xcb8>
    1650:      	add	x14, x12, #0x18
    1654:      	ld1.s	{ v3 }[2], [x14]
    1658:      	tbnz	w13, #0x7, 0xcbc <ltmp0+0xcbc>
    165c:      	b	0xcc4 <ltmp0+0xcc4>
    1660:      	ldr	s7, [x10]
    1664:      	tbz	w13, #0x1, 0x141c <ltmp0+0x141c>
    1668:      	add	x11, x10, #0x4
    166c:      	ld1.s	{ v7 }[1], [x11]
    1670:      	tbz	w13, #0x2, 0x1420 <ltmp0+0x1420>
    1674:      	add	x11, x10, #0x8
    1678:      	ld1.s	{ v7 }[2], [x11]
    167c:      	tbz	w13, #0x3, 0x1424 <ltmp0+0x1424>
    1680:      	add	x11, x10, #0xc
    1684:      	ld1.s	{ v7 }[3], [x11]
    1688:      	tbz	w13, #0x4, 0x1428 <ltmp0+0x1428>
    168c:      	add	x11, x10, #0x10
    1690:      	ld1.s	{ v18 }[0], [x11]
    1694:      	tbz	w13, #0x5, 0x142c <ltmp0+0x142c>
    1698:      	add	x11, x10, #0x14
    169c:      	ld1.s	{ v18 }[1], [x11]
    16a0:      	tbz	w13, #0x6, 0x1430 <ltmp0+0x1430>
    16a4:      	add	x11, x10, #0x18
    16a8:      	ld1.s	{ v18 }[2], [x11]
    16ac:      	tbnz	w13, #0x7, 0x1434 <ltmp0+0x1434>
    16b0:      	b	0x143c <ltmp0+0x143c>
    16b4:      	str	s0, [x8]
    16b8:      	tbz	w9, #0x1, 0x15e8 <ltmp0+0x15e8>
    16bc:      	add	x10, x8, #0x4
    16c0:      	st1.s	{ v0 }[1], [x10]
    16c4:      	tbz	w9, #0x2, 0x15ec <ltmp0+0x15ec>
    16c8:      	add	x10, x8, #0x8
    16cc:      	st1.s	{ v0 }[2], [x10]
    16d0:      	tbz	w9, #0x3, 0x15f0 <ltmp0+0x15f0>
    16d4:      	add	x10, x8, #0xc
    16d8:      	st1.s	{ v0 }[3], [x10]
    16dc:      	fdiv.4s	v0, v3, v6
    16e0:      	fmul.4s	v0, v0, v18
    16e4:      	tbz	w9, #0x4, 0x15fc <ltmp0+0x15fc>
    16e8:      	str	s0, [x8, #0x10]
    16ec:      	tbz	w9, #0x5, 0x1600 <ltmp0+0x1600>
    16f0:      	add	x10, x8, #0x14
    16f4:      	st1.s	{ v0 }[1], [x10]
    16f8:      	tbz	w9, #0x6, 0x1604 <ltmp0+0x1604>
    16fc:      	add	x10, x8, #0x18
    1700:      	st1.s	{ v0 }[2], [x10]
    1704:      	tbz	w9, #0x7, 0x6c <ltmp0+0x6c>
    1708:      	add	x8, x8, #0x1c
    170c:      	st1.s	{ v0 }[3], [x8]
    1710:      	b	0x6c <ltmp0+0x6c>
    1714:      	ldr	x9, [sp, #0x8]
    1718:      	stp	w7, w13, [x9]
    171c:      	str	w12, [x9, #0x8]
    1720:      	mov	w8, #0x18               ; =24
    1724:      	str	w8, [x9, #0x24]
    1728:      	add	sp, sp, #0x8, lsl #12   ; =0x8000
    172c:      	add	sp, sp, #0x420
    1730:      	ldp	x29, x30, [sp, #0x90]
    1734:      	ldp	x20, x19, [sp, #0x80]
    1738:      	ldp	x22, x21, [sp, #0x70]
    173c:      	ldp	x24, x23, [sp, #0x60]
    1740:      	ldp	x26, x25, [sp, #0x50]
    1744:      	ldp	x28, x27, [sp, #0x40]
    1748:      	ldp	d9, d8, [sp, #0x30]
    174c:      	ldp	d11, d10, [sp, #0x20]
    1750:      	ldp	d13, d12, [sp, #0x10]
    1754:      	ldp	d15, d14, [sp], #0xa0
    1758:      	ret

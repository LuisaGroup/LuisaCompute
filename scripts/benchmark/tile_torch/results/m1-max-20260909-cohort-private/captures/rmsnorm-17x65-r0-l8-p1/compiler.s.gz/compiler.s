	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_8:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_9:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_10:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB0_115
; %bb.1:                                ; %block.batch.loop.preheader
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1536
	mov	w8, #0                          ; =0x0
	mov	w26, #32                        ; =0x20
	mov	w10, #260                       ; =0x104
	mov	w11, #1115815936                ; =0x42820000
	ldp	w27, w28, [x2, #44]
	mov	w14, #50604                     ; =0xc5ac
	movk	w14, #14119, lsl #16
	ldp	w9, w17, [x2]
	add	x4, sp, #1248
	ldp	w1, w7, [x2, #8]
	str	x2, [sp, #16]                   ; 8-byte Folded Spill
	movi	d15, #0000000000000000
	mov	w30, #4                         ; =0x4
	add	x15, sp, #960
	str	w3, [sp, #28]                   ; 4-byte Folded Spill
	b	LBB0_4
LBB0_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	x21, [x0]
	ldr	x20, [x0, #16]
	ldr	x19, [x0, #48]
	ubfiz	w23, w6, #2, #27
	umull	x9, w23, w10
	umaddl	x17, w23, w10, x21
	ldp	q28, q26, [x17]
	ldp	q25, q24, [x17, #32]
	ldp	q23, q22, [x17, #64]
	ldp	q20, q21, [x17, #96]
	ldp	q19, q18, [x17, #128]
	ldp	q16, q17, [x17, #160]
	ldp	q7, q27, [x17, #192]
	ldp	q30, q29, [x17, #224]
	add	x22, x9, #256
	ldr	s31, [x21, x22]
	ldp	q9, q8, [x20]
	ldp	q0, q1, [x20, #32]
	stp	q0, q1, [sp, #208]              ; 32-byte Folded Spill
	ldp	q0, q1, [x20, #64]
	stp	q0, q1, [sp, #240]              ; 32-byte Folded Spill
	fmul.4s	v5, v28, v28
	fmul.4s	v6, v26, v26
	fmul.4s	v10, v24, v24
	fmul.4s	v11, v25, v25
	fmul.4s	v12, v23, v23
	fmul.4s	v13, v22, v22
	fmul.4s	v14, v21, v21
	fmul.4s	v15, v20, v20
	fmul.4s	v0, v30, v30
	fadd.4s	v0, v15, v0
	fmul.4s	v15, v29, v29
	fadd.4s	v14, v14, v15
	fmul.4s	v15, v27, v27
	fadd.4s	v13, v13, v15
	fmul.4s	v15, v7, v7
	fadd.4s	v12, v12, v15
	fmul.4s	v15, v16, v16
	fadd.4s	v11, v11, v15
	fmul.4s	v15, v17, v17
	fadd.4s	v10, v10, v15
	fmul.4s	v15, v19, v19
	fadd.4s	v5, v5, v15
	fmul.4s	v15, v31, v31
	fadd.4s	v15, v5, v15
	mov.s	v5[0], v15[0]
	fmul.4s	v15, v18, v18
	fadd.4s	v6, v6, v15
	fadd.4s	v6, v10, v6
	ldp	q15, q10, [x20, #96]
	fadd.4s	v5, v11, v5
	fadd.4s	v5, v12, v5
	fadd.4s	v6, v13, v6
	fadd.4s	v6, v14, v6
	fadd.4s	v0, v0, v5
	rev64.4s	v5, v0
	rev64.4s	v11, v6
	fadd.4s	v6, v6, v11
	fadd.4s	v0, v0, v5
	dup.4s	v5, v0[2]
	dup.4s	v11, v6[2]
	ldp	q13, q12, [x20, #128]
	fadd.4s	v6, v6, v11
	fadd.4s	v0, v0, v5
	fadd.4s	v0, v0, v6
	movi	d1, #0000000000000000
	fadd	s0, s0, s1
	fmov	s1, w11
	str	s1, [sp, #296]                  ; 4-byte Folded Spill
	fdiv	s0, s0, s1
	fmov	s1, w14
	str	s1, [sp, #272]                  ; 4-byte Folded Spill
	fadd	s0, s0, s1
	fsqrt	s0, s0
	dup.4s	v11, v0[0]
	fdiv.4s	v28, v28, v11
	fmul.4s	v28, v9, v28
	ldp	q14, q9, [x20, #160]
	umaddl	x9, w23, w10, x19
	fdiv.4s	v26, v26, v11
	fmul.4s	v26, v8, v26
	ldp	q1, q8, [x20, #192]
	ldp	q2, q3, [x20, #224]
	ldr	s4, [x20, #256]
	stp	q28, q26, [x9]
	fdiv.4s	v25, v25, v11
	ldp	q6, q5, [sp, #208]              ; 32-byte Folded Reload
	fmul.4s	v25, v6, v25
	fdiv.4s	v24, v24, v11
	fmul.4s	v24, v5, v24
	stp	q25, q24, [x9, #32]
	fdiv.4s	v22, v22, v11
	fdiv.4s	v23, v23, v11
	ldp	q6, q5, [sp, #240]              ; 32-byte Folded Reload
	fmul.4s	v23, v6, v23
	fmul.4s	v22, v5, v22
	stp	q23, q22, [x9, #64]
	fdiv.4s	v21, v21, v11
	fdiv.4s	v20, v20, v11
	fmul.4s	v20, v15, v20
	fmul.4s	v21, v10, v21
	stp	q20, q21, [x9, #96]
	fdiv.4s	v18, v18, v11
	fdiv.4s	v19, v19, v11
	fmul.4s	v19, v13, v19
	fmul.4s	v18, v12, v18
	stp	q19, q18, [x9, #128]
	fdiv.4s	v17, v17, v11
	fdiv.4s	v16, v16, v11
	fmul.4s	v16, v14, v16
	fmul.4s	v17, v9, v17
	stp	q16, q17, [x9, #160]
	fdiv.4s	v16, v27, v11
	fdiv.4s	v7, v7, v11
	fmul.4s	v1, v1, v7
	fmul.4s	v7, v8, v16
	stp	q1, q7, [x9, #192]
	fdiv.4s	v1, v29, v11
	fdiv.4s	v7, v30, v11
	fmul.4s	v2, v2, v7
	fmul.4s	v1, v3, v1
	stp	q2, q1, [x9, #224]
	fdiv.4s	v0, v31, v0
	fmul.4s	v0, v4, v0
	str	s0, [x19, x22]
	mov	w23, #1                         ; =0x1
	bfi	w23, w6, #2, #27
	umull	x9, w23, w10
	umaddl	x17, w23, w10, x21
	ldp	q27, q26, [x17]
	ldp	q25, q24, [x17, #32]
	ldp	q23, q22, [x17, #64]
	ldp	q20, q21, [x17, #96]
	ldp	q19, q18, [x17, #128]
	ldp	q16, q17, [x17, #160]
	ldp	q7, q5, [x17, #192]
	ldp	q2, q6, [x17, #224]
	add	x22, x9, #256
	ldr	s1, [x21, x22]
	ldp	q31, q30, [x20]
	ldp	q0, q3, [x20, #32]
	stp	q3, q2, [sp, #240]              ; 32-byte Folded Spill
	stp	q0, q1, [sp, #208]              ; 32-byte Folded Spill
	fmul.4s	v0, v27, v27
	fmul.4s	v8, v26, v26
	fmul.4s	v9, v24, v24
	fmul.4s	v10, v25, v25
	fmul.4s	v11, v23, v23
	fmul.4s	v12, v22, v22
	fmul.4s	v13, v21, v21
	fmul.4s	v14, v20, v20
	fmul.4s	v15, v2, v2
	fadd.4s	v14, v14, v15
	fmul.4s	v15, v6, v6
	fadd.4s	v13, v13, v15
	fmul.4s	v15, v5, v5
	fadd.4s	v12, v12, v15
	fmul.4s	v15, v7, v7
	fadd.4s	v11, v11, v15
	fmul.4s	v15, v16, v16
	fadd.4s	v10, v10, v15
	fmul.4s	v15, v17, v17
	fadd.4s	v9, v9, v15
	fmul.4s	v15, v19, v19
	fadd.4s	v0, v0, v15
	fmul.4s	v15, v1, v1
	fadd.4s	v15, v0, v15
	mov.s	v0[0], v15[0]
	fmul.4s	v15, v18, v18
	fadd.4s	v8, v8, v15
	fadd.4s	v8, v9, v8
	ldp	q15, q9, [x20, #64]
	fadd.4s	v0, v10, v0
	fadd.4s	v0, v11, v0
	ldp	q11, q10, [x20, #96]
	fadd.4s	v8, v12, v8
	fadd.4s	v8, v13, v8
	fadd.4s	v0, v14, v0
	rev64.4s	v12, v0
	rev64.4s	v13, v8
	fadd.4s	v8, v8, v13
	fadd.4s	v0, v0, v12
	dup.4s	v12, v8[2]
	ldp	q14, q13, [x20, #128]
	fadd.4s	v8, v8, v12
	dup.4s	v12, v0[2]
	fadd.4s	v0, v0, v12
	fadd.4s	v0, v0, v8
	movi	d1, #0000000000000000
	fadd	s0, s0, s1
	ldr	s28, [sp, #296]                 ; 4-byte Folded Reload
	fdiv	s0, s0, s28
	ldr	s29, [sp, #272]                 ; 4-byte Folded Reload
	fadd	s0, s0, s29
	fsqrt	s0, s0
	dup.4s	v8, v0[0]
	fdiv.4s	v27, v27, v8
	fmul.4s	v27, v31, v27
	ldp	q12, q31, [x20, #160]
	umaddl	x9, w23, w10, x19
	fdiv.4s	v26, v26, v8
	fmul.4s	v26, v30, v26
	ldp	q1, q30, [x20, #192]
	ldp	q2, q3, [x20, #224]
	ldr	s4, [x20, #256]
	stp	q27, q26, [x9]
	fdiv.4s	v25, v25, v8
	ldr	q26, [sp, #208]                 ; 16-byte Folded Reload
	fmul.4s	v25, v26, v25
	fdiv.4s	v24, v24, v8
	ldr	q26, [sp, #240]                 ; 16-byte Folded Reload
	fmul.4s	v24, v26, v24
	stp	q25, q24, [x9, #32]
	fdiv.4s	v22, v22, v8
	fdiv.4s	v23, v23, v8
	fmul.4s	v23, v15, v23
	fmul.4s	v22, v9, v22
	stp	q23, q22, [x9, #64]
	fdiv.4s	v21, v21, v8
	fdiv.4s	v20, v20, v8
	fmul.4s	v20, v11, v20
	fmul.4s	v21, v10, v21
	stp	q20, q21, [x9, #96]
	fdiv.4s	v18, v18, v8
	fdiv.4s	v19, v19, v8
	fmul.4s	v19, v14, v19
	fmul.4s	v18, v13, v18
	stp	q19, q18, [x9, #128]
	fdiv.4s	v17, v17, v8
	fdiv.4s	v16, v16, v8
	fmul.4s	v16, v12, v16
	fmul.4s	v17, v31, v17
	stp	q16, q17, [x9, #160]
	fdiv.4s	v5, v5, v8
	fdiv.4s	v7, v7, v8
	fmul.4s	v1, v1, v7
	fmul.4s	v5, v30, v5
	stp	q1, q5, [x9, #192]
	fdiv.4s	v1, v6, v8
	ldr	q5, [sp, #256]                  ; 16-byte Folded Reload
	fdiv.4s	v5, v5, v8
	fmul.4s	v2, v2, v5
	fmul.4s	v1, v3, v1
	stp	q2, q1, [x9, #224]
	ldr	q1, [sp, #224]                  ; 16-byte Folded Reload
	fdiv.4s	v0, v1, v0
	fmul.4s	v0, v4, v0
	str	s0, [x19, x22]
	mov	w23, #2                         ; =0x2
	bfi	w23, w6, #2, #27
	umull	x9, w23, w10
	umaddl	x17, w23, w10, x21
	ldp	q27, q26, [x17]
	ldp	q25, q24, [x17, #32]
	ldp	q23, q22, [x17, #64]
	ldp	q20, q21, [x17, #96]
	ldp	q19, q18, [x17, #128]
	ldp	q16, q17, [x17, #160]
	ldp	q7, q4, [x17, #192]
	ldp	q2, q3, [x17, #224]
	add	x22, x9, #256
	ldr	s1, [x21, x22]
	ldp	q31, q30, [x20]
	ldp	q0, q5, [x20, #32]
	stp	q5, q2, [sp, #240]              ; 32-byte Folded Spill
	stp	q0, q1, [sp, #208]              ; 32-byte Folded Spill
	fmul.4s	v0, v27, v27
	fmul.4s	v5, v26, v26
	fmul.4s	v6, v24, v24
	fmul.4s	v8, v25, v25
	fmul.4s	v9, v23, v23
	fmul.4s	v10, v22, v22
	fmul.4s	v11, v21, v21
	fmul.4s	v12, v20, v20
	fmul.4s	v13, v2, v2
	fadd.4s	v12, v12, v13
	fmul.4s	v13, v3, v3
	fadd.4s	v11, v11, v13
	fmul.4s	v13, v4, v4
	fadd.4s	v10, v10, v13
	fmul.4s	v13, v7, v7
	fadd.4s	v9, v9, v13
	fmul.4s	v13, v16, v16
	fadd.4s	v8, v8, v13
	fmul.4s	v13, v17, v17
	fadd.4s	v6, v6, v13
	fmul.4s	v13, v19, v19
	fadd.4s	v0, v0, v13
	fmul.4s	v13, v1, v1
	fadd.4s	v13, v0, v13
	mov.s	v0[0], v13[0]
	fmul.4s	v13, v18, v18
	fadd.4s	v5, v5, v13
	fadd.4s	v5, v6, v5
	ldp	q13, q6, [x20, #64]
	fadd.4s	v0, v8, v0
	fadd.4s	v0, v9, v0
	ldp	q9, q8, [x20, #96]
	fadd.4s	v5, v10, v5
	fadd.4s	v5, v11, v5
	fadd.4s	v0, v12, v0
	rev64.4s	v10, v0
	rev64.4s	v11, v5
	fadd.4s	v5, v5, v11
	fadd.4s	v0, v0, v10
	dup.4s	v10, v5[2]
	ldp	q12, q11, [x20, #128]
	fadd.4s	v5, v5, v10
	dup.4s	v10, v0[2]
	fadd.4s	v0, v0, v10
	fadd.4s	v0, v0, v5
	movi	d1, #0000000000000000
	fadd	s0, s0, s1
	fdiv	s0, s0, s28
	fadd	s0, s0, s29
	fsqrt	s0, s0
	dup.4s	v5, v0[0]
	fdiv.4s	v27, v27, v5
	fmul.4s	v27, v31, v27
	ldp	q10, q31, [x20, #160]
	umaddl	x9, w23, w10, x19
	fdiv.4s	v26, v26, v5
	fmul.4s	v26, v30, v26
	ldp	q14, q30, [x20, #192]
	ldp	q1, q15, [x20, #224]
	ldr	s2, [x20, #256]
	stp	q27, q26, [x9]
	fdiv.4s	v25, v25, v5
	ldr	q26, [sp, #208]                 ; 16-byte Folded Reload
	fmul.4s	v25, v26, v25
	fdiv.4s	v24, v24, v5
	ldr	q26, [sp, #240]                 ; 16-byte Folded Reload
	fmul.4s	v24, v26, v24
	stp	q25, q24, [x9, #32]
	fdiv.4s	v22, v22, v5
	fdiv.4s	v23, v23, v5
	fmul.4s	v23, v13, v23
	fmul.4s	v6, v6, v22
	stp	q23, q6, [x9, #64]
	fdiv.4s	v6, v21, v5
	fdiv.4s	v20, v20, v5
	fmul.4s	v20, v9, v20
	fmul.4s	v6, v8, v6
	stp	q20, q6, [x9, #96]
	fdiv.4s	v6, v18, v5
	fdiv.4s	v18, v19, v5
	fmul.4s	v18, v12, v18
	fmul.4s	v6, v11, v6
	stp	q18, q6, [x9, #128]
	fdiv.4s	v6, v17, v5
	fdiv.4s	v16, v16, v5
	fmul.4s	v16, v10, v16
	fmul.4s	v6, v31, v6
	stp	q16, q6, [x9, #160]
	fdiv.4s	v4, v4, v5
	fdiv.4s	v6, v7, v5
	fmul.4s	v6, v14, v6
	fmul.4s	v4, v30, v4
	stp	q6, q4, [x9, #192]
	fdiv.4s	v3, v3, v5
	ldr	q4, [sp, #256]                  ; 16-byte Folded Reload
	fdiv.4s	v4, v4, v5
	fmul.4s	v1, v1, v4
	fmul.4s	v3, v15, v3
	movi	d15, #0000000000000000
	stp	q1, q3, [x9, #224]
	ldr	q1, [sp, #224]                  ; 16-byte Folded Reload
	fdiv.4s	v0, v1, v0
	fmul.4s	v0, v2, v0
	str	s0, [x19, x22]
	mov	w23, #3                         ; =0x3
	bfi	w23, w6, #2, #27
	umull	x9, w23, w10
	umaddl	x17, w23, w10, x21
	ldp	q27, q26, [x17]
	ldp	q24, q25, [x17, #32]
	ldp	q23, q22, [x17, #64]
	ldp	q21, q20, [x17, #96]
	ldp	q19, q18, [x17, #128]
	ldp	q17, q16, [x17, #160]
	ldp	q7, q4, [x17, #192]
	ldp	q2, q3, [x17, #224]
	add	x22, x9, #256
	ldr	s1, [x21, x22]
	ldp	q29, q28, [x20]
	fmul.4s	v0, v27, v27
	fmul.4s	v5, v26, v26
	fmul.4s	v6, v25, v25
	fmul.4s	v30, v24, v24
	fmul.4s	v31, v23, v23
	fmul.4s	v8, v22, v22
	fmul.4s	v9, v20, v20
	fmul.4s	v10, v21, v21
	fmul.4s	v11, v3, v3
	fmul.4s	v12, v2, v2
	fadd.4s	v10, v10, v12
	fadd.4s	v9, v9, v11
	fmul.4s	v11, v7, v7
	fmul.4s	v12, v4, v4
	fadd.4s	v8, v8, v12
	fadd.4s	v31, v31, v11
	fmul.4s	v11, v16, v16
	fmul.4s	v12, v17, v17
	fadd.4s	v30, v30, v12
	fadd.4s	v6, v6, v11
	fmul.4s	v11, v19, v19
	fmul.4s	v12, v18, v18
	fadd.4s	v5, v5, v12
	fadd.4s	v0, v0, v11
	fmul.4s	v11, v1, v1
	fadd.4s	v11, v0, v11
	mov.s	v0[0], v11[0]
	ldp	q12, q11, [x20, #32]
	fadd.4s	v5, v6, v5
	fadd.4s	v0, v30, v0
	ldp	q13, q30, [x20, #64]
	fadd.4s	v0, v31, v0
	fadd.4s	v5, v8, v5
	fadd.4s	v5, v9, v5
	fadd.4s	v0, v10, v0
	rev64.4s	v6, v0
	rev64.4s	v31, v5
	fadd.4s	v5, v5, v31
	fadd.4s	v0, v0, v6
	dup.4s	v6, v0[2]
	dup.4s	v31, v5[2]
	ldp	q9, q8, [x20, #96]
	fadd.4s	v5, v5, v31
	fadd.4s	v0, v0, v6
	ldp	q10, q31, [x20, #128]
	fadd.4s	v0, v0, v5
	fadd	s0, s0, s15
	ldr	s5, [sp, #296]                  ; 4-byte Folded Reload
	fdiv	s0, s0, s5
	ldr	s5, [sp, #272]                  ; 4-byte Folded Reload
	fadd	s0, s0, s5
	fsqrt	s5, s0
	dup.4s	v6, v5[0]
	ldp	q14, q0, [x20, #160]
	fdiv.4s	v26, v26, v6
	fdiv.4s	v27, v27, v6
	fmul.4s	v27, v29, v27
	fmul.4s	v26, v28, v26
	ldp	q29, q28, [x20, #192]
	fdiv.4s	v25, v25, v6
	fdiv.4s	v24, v24, v6
	fmul.4s	v24, v12, v24
	fmul.4s	v25, v11, v25
	ldp	q12, q11, [x20, #224]
	fdiv.4s	v23, v23, v6
	fmul.4s	v23, v13, v23
	ldr	s13, [x20, #256]
	umaddl	x9, w23, w10, x19
	stp	q27, q26, [x9]
	fdiv.4s	v22, v22, v6
	fmul.4s	v22, v30, v22
	fdiv.4s	v21, v21, v6
	fmul.4s	v21, v9, v21
	stp	q24, q25, [x9, #32]
	fdiv.4s	v20, v20, v6
	fmul.4s	v20, v8, v20
	stp	q23, q22, [x9, #64]
	fdiv.4s	v19, v19, v6
	fmul.4s	v19, v10, v19
	stp	q21, q20, [x9, #96]
	fdiv.4s	v18, v18, v6
	fmul.4s	v18, v31, v18
	stp	q19, q18, [x9, #128]
	fdiv.4s	v17, v17, v6
	fmul.4s	v17, v14, v17
	fdiv.4s	v16, v16, v6
	fmul.4s	v0, v0, v16
	stp	q17, q0, [x9, #160]
	fdiv.4s	v0, v7, v6
	fmul.4s	v0, v29, v0
	fdiv.4s	v4, v4, v6
	fmul.4s	v4, v28, v4
	stp	q0, q4, [x9, #192]
	fdiv.4s	v0, v3, v6
	fdiv.4s	v2, v2, v6
	fmul.4s	v2, v12, v2
	fmul.4s	v0, v11, v0
	stp	q2, q0, [x9, #224]
	fdiv.4s	v0, v1, v5
	fmul.4s	v0, v13, v0
	str	s0, [x19, x22]
LBB0_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	w9, w6, #1
	cmp	w9, w27
	cset	w12, eq
	csinc	w9, wzr, w6, eq
	cinc	w13, w5, eq
	cmp	w13, w28
	cset	w17, eq
	ands	w12, w12, w17
	csel	w17, wzr, w13, ne
	add	w1, w16, w12
	add	w8, w8, #1
	cmp	w8, w3
	b.eq	LBB0_114
LBB0_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_7 Depth 2
                                        ;     Child Loop BB0_12 Depth 2
                                        ;     Child Loop BB0_38 Depth 2
                                        ;     Child Loop BB0_41 Depth 2
                                        ;     Child Loop BB0_68 Depth 2
	mov	x16, x1
	mov	x5, x17
	mov	x6, x9
	ubfiz	x9, x9, #5, #32
	cmp	x9, x7
	csel	x17, x9, xzr, ls
	subs	x1, x7, x17
	cmp	x1, #32
	csel	x1, x1, x26, lo
	cmp	x7, x17
	ccmp	x9, x7, #2, hi
	csel	x19, x1, xzr, ls
	cmp	x19, #32
	b.hs	LBB0_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	lsr	x25, x19, #3
	cmp	x19, #8
	b.lo	LBB0_8
; %bb.6:                                ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	x9, [x0]
	ldr	x21, [x0, #16]
	ldr	x17, [x0, #48]
	add	x22, x21, #256
	and	x1, x6, #0x7ffffff
	add	x1, x1, x1, lsl #6
	lsl	x1, x1, #4
	add	x9, x9, x1
	add	x23, x9, #128
	add	x9, x17, x1
	add	x24, x9, #128
	mov	x20, x25
LBB0_7:                                 ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q25, q24, [x23, #-128]
	ldp	q23, q22, [x23, #-96]
	ldp	q21, q20, [x23, #-64]
	ldp	q19, q18, [x23, #-32]
	ldp	q17, q16, [x23]
	ldp	q7, q6, [x23, #32]
	ldp	q5, q4, [x23, #64]
	ldp	q2, q3, [x23, #96]
	ldr	s1, [x23, #128]
	ldp	q29, q28, [x21]
	ldp	q27, q26, [x21, #32]
	fmul.4s	v0, v25, v25
	fmul.4s	v30, v24, v24
	fmul.4s	v31, v22, v22
	fmul.4s	v8, v23, v23
	fmul.4s	v9, v21, v21
	fmul.4s	v10, v20, v20
	fmul.4s	v11, v18, v18
	fmul.4s	v12, v19, v19
	fmul.4s	v13, v2, v2
	fadd.4s	v12, v12, v13
	fmul.4s	v13, v5, v5
	fmul.4s	v14, v4, v4
	fadd.4s	v10, v10, v14
	fadd.4s	v9, v9, v13
	fmul.4s	v13, v6, v6
	fmul.4s	v14, v7, v7
	fadd.4s	v8, v8, v14
	fadd.4s	v31, v31, v13
	fmul.4s	v13, v17, v17
	fmul.4s	v14, v16, v16
	fadd.4s	v30, v30, v14
	fadd.4s	v0, v0, v13
	fmul.4s	v13, v1, v1
	fmul.4s	v14, v3, v3
	fadd.4s	v13, v0, v13
	mov.s	v0[0], v13[0]
	fadd.4s	v30, v31, v30
	fadd.4s	v0, v8, v0
	fadd.4s	v31, v11, v14
	fadd.4s	v0, v9, v0
	fadd.4s	v30, v10, v30
	fadd.4s	v30, v31, v30
	fadd.4s	v0, v12, v0
	ldp	q9, q8, [x21, #64]
	rev64.4s	v31, v0
	rev64.4s	v10, v30
	fadd.4s	v30, v30, v10
	fadd.4s	v0, v0, v31
	dup.4s	v31, v0[2]
	dup.4s	v10, v30[2]
	fadd.4s	v30, v30, v10
	fadd.4s	v0, v0, v31
	ldp	q11, q10, [x21, #96]
	fadd.4s	v0, v0, v30
	fadd	s0, s0, s15
	fmov	s30, w11
	fdiv	s0, s0, s30
	ldp	q13, q12, [x21, #128]
	fmov	s30, w14
	fadd	s0, s0, s30
	fsqrt	s30, s0
	dup.4s	v31, v30[0]
	ldp	q14, q0, [x21, #160]
	fdiv.4s	v25, v25, v31
	fmul.4s	v25, v29, v25
	fdiv.4s	v24, v24, v31
	fmul.4s	v24, v28, v24
	ldp	q28, q29, [x21, #192]
	fdiv.4s	v23, v23, v31
	fmul.4s	v23, v27, v23
	fdiv.4s	v22, v22, v31
	fmul.4s	v22, v26, v22
	ldp	q26, q27, [x21, #224]
	fdiv.4s	v21, v21, v31
	fmul.4s	v21, v9, v21
	ldr	s9, [x22]
	stp	q25, q24, [x24, #-128]
	fdiv.4s	v20, v20, v31
	fmul.4s	v20, v8, v20
	fdiv.4s	v19, v19, v31
	fmul.4s	v19, v11, v19
	stp	q23, q22, [x24, #-96]
	fdiv.4s	v18, v18, v31
	fmul.4s	v18, v10, v18
	fdiv.4s	v17, v17, v31
	fmul.4s	v17, v13, v17
	stp	q21, q20, [x24, #-64]
	stp	q19, q18, [x24, #-32]
	fdiv.4s	v16, v16, v31
	fmul.4s	v16, v12, v16
	stp	q17, q16, [x24]
	fdiv.4s	v7, v7, v31
	fmul.4s	v7, v14, v7
	fdiv.4s	v6, v6, v31
	fmul.4s	v0, v0, v6
	stp	q7, q0, [x24, #32]
	fdiv.4s	v0, v5, v31
	fmul.4s	v0, v28, v0
	fdiv.4s	v4, v4, v31
	fmul.4s	v4, v29, v4
	stp	q0, q4, [x24, #64]
	fdiv.4s	v0, v3, v31
	fdiv.4s	v2, v2, v31
	fmul.4s	v2, v26, v2
	fmul.4s	v0, v27, v0
	stp	q2, q0, [x24, #96]
	fdiv.4s	v0, v1, v30
	fmul.4s	v0, v9, v0
	str	s0, [x24, #128]
	add	x23, x23, #260
	add	x24, x24, #260
	subs	x20, x20, #1
	b.ne	LBB0_7
LBB0_8:                                 ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w9, w19, #0x7
	cbz	w9, LBB0_3
; %bb.9:                                ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	dup.4s	v0, w9
Lloh0:
	adrp	x9, lCPI0_1@PAGE
Lloh1:
	ldr	q1, [x9, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x9, lCPI0_2@PAGE
Lloh3:
	ldr	q2, [x9, lCPI0_2@PAGEOFF]
	cmhi.4s	v5, v0, v2
	cmhi.4s	v6, v0, v1
	uzp1.8h	v31, v6, v5
	umaxv.8h	h0, v31
	fmov	w9, s0
	tbz	w9, #0, LBB0_3
; %bb.10:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x20, #0                         ; =0x0
	ldr	x23, [x0]
	ldr	x21, [x0, #16]
	ldr	x13, [x0, #48]
Lloh4:
	adrp	x9, lCPI0_0@PAGE
Lloh5:
	ldr	q0, [x9, lCPI0_0@PAGEOFF]
	and.16b	v0, v31, v0
	addv.8h	h7, v0
	ubfiz	w9, w6, #2, #27
	orr	w9, w9, w25
	fmov	w17, s7
	and	w12, w17, #0xff
	str	w12, [sp, #240]                 ; 4-byte Folded Spill
	dup.4s	v0, w9
	and.16b	v1, v6, v0
	and.16b	v0, v5, v0
	ushll2.2d	v20, v0, #0
	ushll2.2d	v21, v1, #0
	ushll.2d	v22, v0, #0
	ushll.2d	v2, v1, #0
	fmov	x9, d2
	umaddl	x24, w9, w10, x23
	b	LBB0_12
LBB0_11:                                ; %else74
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x9, x4, x20
	ldp	q0, q4, [x9]
	bif.16b	v3, v4, v5
	bit.16b	v0, v1, v6
	stp	q0, q3, [x9]
	add	x20, x20, #32
	cmp	x20, #256
	b.eq	LBB0_28
LBB0_12:                                ; %direct.true.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s7
	add	x25, x24, x20
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w9, #0, LBB0_20
; %bb.13:                               ; %else
                                        ;   in Loop: Header=BB0_12 Depth=2
	and	w17, w9, #0xff
	tbnz	w17, #1, LBB0_21
LBB0_14:                                ; %else56
                                        ;   in Loop: Header=BB0_12 Depth=2
	tbnz	w17, #2, LBB0_22
LBB0_15:                                ; %else59
                                        ;   in Loop: Header=BB0_12 Depth=2
	tbnz	w17, #3, LBB0_23
LBB0_16:                                ; %else62
                                        ;   in Loop: Header=BB0_12 Depth=2
	tbnz	w17, #4, LBB0_24
LBB0_17:                                ; %else65
                                        ;   in Loop: Header=BB0_12 Depth=2
	tbnz	w17, #5, LBB0_25
LBB0_18:                                ; %else68
                                        ;   in Loop: Header=BB0_12 Depth=2
	tbnz	w17, #6, LBB0_26
LBB0_19:                                ; %else71
                                        ;   in Loop: Header=BB0_12 Depth=2
	tbz	w17, #7, LBB0_11
	b	LBB0_27
LBB0_20:                                ; %cond.load
                                        ;   in Loop: Header=BB0_12 Depth=2
	ldr	s1, [x25]
	and	w17, w9, #0xff
	tbz	w17, #1, LBB0_14
LBB0_21:                                ; %cond.load55
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x9, x25, #4
	ld1.s	{ v1 }[1], [x9]
	tbz	w17, #2, LBB0_15
LBB0_22:                                ; %cond.load58
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x9, x25, #8
	ld1.s	{ v1 }[2], [x9]
	tbz	w17, #3, LBB0_16
LBB0_23:                                ; %cond.load61
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x9, x25, #12
	ld1.s	{ v1 }[3], [x9]
	tbz	w17, #4, LBB0_17
LBB0_24:                                ; %cond.load64
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x9, x25, #16
	ld1.s	{ v3 }[0], [x9]
	tbz	w17, #5, LBB0_18
LBB0_25:                                ; %cond.load67
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x9, x25, #20
	ld1.s	{ v3 }[1], [x9]
	tbz	w17, #6, LBB0_19
LBB0_26:                                ; %cond.load70
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x9, x25, #24
	ld1.s	{ v3 }[2], [x9]
	tbz	w17, #7, LBB0_11
LBB0_27:                                ; %cond.load73
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x9, x25, #28
	ld1.s	{ v3 }[3], [x9]
	b	LBB0_11
LBB0_28:                                ; %direct.true57.preheader.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	xtn.4h	v0, v6
	uzp1.8b	v0, v0, v0
	sshll.2d	v1, v6, #0
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q3, [x9, lCPI0_6@PAGEOFF]
	and.16b	v4, v1, v3
	movi.2d	v19, #0000000000000000
	mov.b	v19[0], v0[0]
Lloh8:
	adrp	x9, lCPI0_11@PAGE
Lloh9:
	ldr	d3, [x9, lCPI0_11@PAGEOFF]
	str	d3, [sp, #152]                  ; 8-byte Folded Spill
	and.8b	v3, v19, v3
	addv.8b	b3, v3
	fmov	w24, s3
	umaxv.8b	b3, v19
	fmov	w9, s3
	rbit	w17, w24
	clz	w17, w17
	tst	w9, #0x1
	csel	w20, w17, wzr, ne
	mov	w12, #64                        ; =0x40
	dup.2d	v3, x12
	str	q4, [sp, #80]                   ; 16-byte Folded Spill
	orr.16b	v16, v4, v3
	xtn.2s	v2, v2
	str	q16, [sp, #160]                 ; 16-byte Folded Spill
	movi.2s	v4, #65
	umlal.2d	v16, v2, v4
	movi.2d	v4, #0000000000000000
	mov.b	v4[0], v0[0]
	ushll.2d	v0, v4, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	str	q16, [sp, #272]                 ; 16-byte Folded Spill
	and.16b	v0, v0, v16
	movi.2d	v4, #0000000000000000
	stp	q4, q4, [sp, #912]
	stp	q0, q4, [sp, #880]
	and	x17, x20, #0x7
	add	x12, sp, #880
	ldr	x17, [x12, x17, lsl #3]
	sub	x17, x17, x20
	add	x23, x23, x17, lsl #2
	movi.2d	v24, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w9, #0, LBB0_92
; %bb.29:                               ; %else78
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w24, #1, LBB0_93
LBB0_30:                                ; %else81
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w24, #2, LBB0_94
LBB0_31:                                ; %else84
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w24, #3, LBB0_95
LBB0_32:                                ; %else87
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w24, #4, LBB0_96
LBB0_33:                                ; %else90
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w24, #5, LBB0_97
LBB0_34:                                ; %else93
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w24, #6, LBB0_98
LBB0_35:                                ; %else96
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w24, #7, LBB0_37
LBB0_36:                                ; %cond.load98
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x23, #28
	ld1.s	{ v16 }[3], [x9]
LBB0_37:                                ; %else99
                                        ;   in Loop: Header=BB0_4 Depth=1
	sshll.2d	v0, v5, #0
	sshll2.2d	v26, v6, #0
	sshll2.2d	v27, v5, #0
Lloh10:
	adrp	x9, lCPI0_3@PAGE
Lloh11:
	ldr	q4, [x9, lCPI0_3@PAGEOFF]
	and.16b	v18, v27, v4
Lloh12:
	adrp	x9, lCPI0_4@PAGE
Lloh13:
	ldr	q4, [x9, lCPI0_4@PAGEOFF]
	and.16b	v25, v26, v4
Lloh14:
	adrp	x9, lCPI0_5@PAGE
Lloh15:
	ldr	q4, [x9, lCPI0_5@PAGEOFF]
	and.16b	v28, v0, v4
Lloh16:
	adrp	x9, lCPI0_7@PAGE
Lloh17:
	ldr	q4, [x9, lCPI0_7@PAGEOFF]
	and.16b	v4, v27, v4
Lloh18:
	adrp	x9, lCPI0_8@PAGE
Lloh19:
	ldr	q17, [x9, lCPI0_8@PAGEOFF]
	and.16b	v23, v26, v17
Lloh20:
	adrp	x9, lCPI0_9@PAGE
Lloh21:
	ldr	q17, [x9, lCPI0_9@PAGEOFF]
	and.16b	v0, v0, v17
Lloh22:
	adrp	x9, lCPI0_10@PAGE
Lloh23:
	ldr	q17, [x9, lCPI0_10@PAGEOFF]
	and.16b	v17, v1, v17
	stp	q28, q25, [sp, #32]             ; 32-byte Folded Spill
	orr.16b	v28, v28, v3
	orr.16b	v29, v25, v3
	str	q18, [sp, #64]                  ; 16-byte Folded Spill
	orr.16b	v25, v18, v3
	movi.2s	v18, #65
	umull.2d	v1, v2, v18
	str	q1, [sp, #176]                  ; 16-byte Folded Spill
	xtn.2s	v1, v21
	xtn.2s	v2, v22
	xtn.2s	v3, v20
	stp	q28, q25, [sp, #112]            ; 32-byte Folded Spill
	mov.16b	v20, v25
	umlal.2d	v20, v3, v18
	str	q29, [sp, #96]                  ; 16-byte Folded Spill
	mov.16b	v3, v29
	umlal.2d	v3, v1, v18
	stp	q3, q20, [sp, #208]             ; 32-byte Folded Spill
	mov.16b	v1, v28
	umlal.2d	v1, v2, v18
	str	q1, [sp, #192]                  ; 16-byte Folded Spill
	sshll.2d	v1, v6, #0
	sshll.2d	v2, v5, #0
	stp	q17, q23, [sp, #816]
	stp	q0, q4, [sp, #848]
	and	x9, x20, #0x7
	add	x12, sp, #816
	ldr	x9, [x12, x9, lsl #3]
	orr	x9, x9, #0x100
	sub	x9, x9, x20, lsl #2
	tst	w24, #0xff
	csel	x3, xzr, x9, eq
	add	x9, x4, x3
	ldp	q0, q3, [x9]
	zip2.8b	v4, v19, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bit.16b	v3, v16, v4
	zip1.8b	v4, v19, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	str	q24, [sp, #256]                 ; 16-byte Folded Spill
	bit.16b	v0, v24, v4
	stp	q0, q3, [x9]
	dup.2d	v0, x30
	and.16b	v21, v27, v0
	and.16b	v22, v26, v0
	and.16b	v28, v2, v0
	and.16b	v29, v1, v0
	fmov	x9, d29
	ldr	q0, [sp, #1360]
	ldr	q1, [sp, #1344]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	and.16b	v14, v5, v0
	and.16b	v15, v6, v1
	ldr	q0, [sp, #1328]
	ldr	q1, [sp, #1312]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	and.16b	v4, v5, v0
	and.16b	v3, v6, v1
	ldr	q0, [sp, #1296]
	ldr	q1, [sp, #1280]
	fmul.4s	v2, v1, v1
	fmul.4s	v0, v0, v0
	and.16b	v1, v5, v0
	and.16b	v2, v6, v2
	fmov	x17, d17
	add	x17, x4, x17
	ldp	q17, q0, [x17]
	fmul.4s	v17, v17, v17
	fmul.4s	v0, v0, v0
	and.16b	v24, v5, v0
	and.16b	v23, v6, v17
LBB0_38:                                ; %direct.true57.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v6, #0
	sshll.2d	v17, v5, #0
	add	x9, x4, x9, lsl #5
	ldp	q25, q20, [x9]
	and.16b	v25, v6, v25
	and.16b	v20, v5, v20
	fmul.4s	v20, v20, v20
	fmul.4s	v25, v25, v25
	fadd.4s	v25, v23, v25
	fadd.4s	v20, v24, v20
	ldp	q8, q30, [x9, #32]
	and.16b	v8, v6, v8
	and.16b	v30, v5, v30
	fmul.4s	v30, v30, v30
	fmul.4s	v8, v8, v8
	fadd.4s	v8, v2, v8
	fadd.4s	v30, v1, v30
	ldp	q10, q9, [x9, #64]
	and.16b	v10, v6, v10
	and.16b	v9, v5, v9
	fmul.4s	v9, v9, v9
	fmul.4s	v10, v10, v10
	fadd.4s	v10, v3, v10
	fadd.4s	v9, v4, v9
	ldp	q11, q18, [x9, #96]
	and.16b	v11, v6, v11
	and.16b	v18, v5, v18
	fmul.4s	v18, v18, v18
	fmul.4s	v11, v11, v11
	fadd.4s	v11, v15, v11
	fadd.4s	v18, v14, v18
	dup.2d	v12, x30
	and.16b	v13, v27, v12
	add.2d	v21, v21, v13
	and.16b	v13, v26, v12
	add.2d	v22, v22, v13
	and.16b	v17, v17, v12
	add.2d	v28, v28, v17
	and.16b	v0, v0, v12
	add.2d	v29, v29, v0
	bit.16b	v24, v20, v5
	bit.16b	v23, v25, v6
	bit.16b	v1, v30, v5
	bit.16b	v2, v8, v6
	bit.16b	v4, v9, v5
	bit.16b	v3, v10, v6
	bit.16b	v14, v18, v5
	bit.16b	v15, v11, v6
	fmov	x9, d29
	cmp	x9, #8
	b.lt	LBB0_38
; %bb.39:                               ; %direct.false58.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	x13, [sp, #296]                 ; 8-byte Folded Spill
	mov	x9, #0                          ; =0x0
	mov	w12, #1                         ; =0x1
	dup.2d	v0, x12
	ushll2.2d	v17, v5, #0
	and.16b	v26, v17, v0
	ushll2.2d	v17, v6, #0
	and.16b	v27, v17, v0
	ushll.2d	v17, v5, #0
	and.16b	v28, v17, v0
	ushll.2d	v17, v6, #0
	and.16b	v29, v17, v0
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v8, #0000000000000000
	b	LBB0_41
LBB0_40:                                ; %else124
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x9, x15, x24
	ldp	q0, q18, [x9]
	bif.16b	v17, v18, v5
	bit.16b	v0, v9, v6
	stp	q0, q17, [x9]
	add.2d	v22, v22, v27
	add.2d	v30, v30, v28
	add.2d	v8, v8, v26
	add.2d	v21, v21, v29
	fmov	x9, d21
	cmp	x9, #8
	b.ge	LBB0_57
LBB0_41:                                ; %direct.true93.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w17, s7
	lsl	x24, x9, #5
	add	x25, x21, x24
	movi.2d	v9, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w17, #0, LBB0_49
; %bb.42:                               ; %else103
                                        ;   in Loop: Header=BB0_41 Depth=2
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB0_50
LBB0_43:                                ; %else106
                                        ;   in Loop: Header=BB0_41 Depth=2
	tbnz	w17, #2, LBB0_51
LBB0_44:                                ; %else109
                                        ;   in Loop: Header=BB0_41 Depth=2
	tbnz	w17, #3, LBB0_52
LBB0_45:                                ; %else112
                                        ;   in Loop: Header=BB0_41 Depth=2
	tbnz	w17, #4, LBB0_53
LBB0_46:                                ; %else115
                                        ;   in Loop: Header=BB0_41 Depth=2
	tbnz	w17, #5, LBB0_54
LBB0_47:                                ; %else118
                                        ;   in Loop: Header=BB0_41 Depth=2
	tbnz	w17, #6, LBB0_55
LBB0_48:                                ; %else121
                                        ;   in Loop: Header=BB0_41 Depth=2
	tbz	w17, #7, LBB0_40
	b	LBB0_56
LBB0_49:                                ; %cond.load102
                                        ;   in Loop: Header=BB0_41 Depth=2
	ldr	s9, [x25]
	and	w17, w17, #0xff
	tbz	w17, #1, LBB0_43
LBB0_50:                                ; %cond.load105
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x9, x25, #4
	ld1.s	{ v9 }[1], [x9]
	tbz	w17, #2, LBB0_44
LBB0_51:                                ; %cond.load108
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x9, x25, #8
	ld1.s	{ v9 }[2], [x9]
	tbz	w17, #3, LBB0_45
LBB0_52:                                ; %cond.load111
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x9, x25, #12
	ld1.s	{ v9 }[3], [x9]
	tbz	w17, #4, LBB0_46
LBB0_53:                                ; %cond.load114
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x9, x25, #16
	ld1.s	{ v17 }[0], [x9]
	tbz	w17, #5, LBB0_47
LBB0_54:                                ; %cond.load117
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x9, x25, #20
	ld1.s	{ v17 }[1], [x9]
	tbz	w17, #6, LBB0_48
LBB0_55:                                ; %cond.load120
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x9, x25, #24
	ld1.s	{ v17 }[2], [x9]
	tbz	w17, #7, LBB0_40
LBB0_56:                                ; %cond.load123
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x9, x25, #28
	ld1.s	{ v17 }[3], [x9]
	b	LBB0_40
LBB0_57:                                ; %direct.false94.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x23, x28
	mov	x19, x27
	xtn.8b	v31, v31
	ldr	q30, [sp, #256]                 ; 16-byte Folded Reload
	fmul.4s	v0, v30, v30
	fmul.4s	v17, v16, v16
	fadd.4s	v17, v17, v24
	fadd.4s	v0, v0, v23
	zip1.8b	v18, v19, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	and.16b	v0, v18, v0
	zip2.8b	v18, v19, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	and.16b	v17, v18, v17
	zip2.8b	v18, v31, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	movi.2d	v21, #0000000000000000
	mov.b	v21[2], v31[1]
	mov.b	v21[4], v31[2]
	mov.b	v21[6], v31[3]
	bit.16b	v17, v20, v18
	ushll.4s	v18, v21, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	bit.16b	v0, v25, v18
	fadd.4s	v0, v2, v0
	fadd.4s	v1, v1, v17
	fadd.4s	v1, v4, v1
	fadd.4s	v0, v3, v0
	fadd.4s	v2, v15, v0
	fadd.4s	v3, v14, v1
	ldp	q0, q4, [sp, #64]               ; 32-byte Folded Reload
	ldr	q1, [sp, #48]                   ; 16-byte Folded Reload
	uzp1.4s	v1, v4, v1
	ldr	q4, [sp, #32]                   ; 16-byte Folded Reload
	uzp1.4s	v4, v4, v0
	movi.4s	v17, #1
	eor.16b	v0, v1, v17
	mov.s	w9, v0[1]
	mov.s	w17, v0[2]
	eor.16b	v22, v4, v17
	mov.s	w1, v0[3]
	fmov	w2, s0
	add	x24, sp, #376
	bfxil	x24, x2, #0, #3
	str	d31, [sp, #376]
	ldrb	w25, [x24]
	and	x2, x2, #0x7
	umov.b	w24, v31[0]
	stp	q2, q3, [sp, #640]
	add	x12, sp, #640
	ldr	s0, [x12, x2, lsl #2]
	ands	w26, w24, #0x1
	tst	w26, w25
	movi	d15, #0000000000000000
	fcsel	s20, s0, s15, ne
	add	x2, sp, #376
	bfxil	x2, x9, #0, #3
	ldrb	w2, [x2]
	and	x9, x9, #0x7
	umov.b	w25, v31[1]
	stp	q2, q3, [sp, #608]
	add	x12, sp, #608
	ldr	s0, [x12, x9, lsl #2]
	ands	w9, w25, #0x1
	tst	w9, w2
	fcsel	s21, s0, s15, ne
	add	x9, sp, #376
	bfxil	x9, x17, #0, #3
	ldrb	w9, [x9]
	umov.b	w27, v31[2]
	and	x17, x17, #0x7
	stp	q2, q3, [sp, #576]
	add	x12, sp, #576
	ldr	s0, [x12, x17, lsl #2]
	ands	w17, w27, #0x1
	tst	w17, w9
	fcsel	s17, s0, s15, ne
	add	x9, sp, #376
	bfxil	x9, x1, #0, #3
	ldrb	w9, [x9]
	and	x17, x1, #0x7
	umov.b	w28, v31[3]
	stp	q2, q3, [sp, #544]
	add	x12, sp, #544
	ldr	s0, [x12, x17, lsl #2]
	ands	w17, w28, #0x1
	tst	w17, w9
	mov.s	w9, v22[1]
	mov.s	w2, v22[2]
	fcsel	s23, s0, s15, ne
	mov.s	w22, v22[3]
	fmov	w17, s22
	and	x1, x17, #0x7
	add	x12, sp, #376
	bfxil	x12, x17, #0, #3
	ldrb	w12, [x12]
	umov.b	w17, v31[4]
	and	w12, w17, w12
	stp	q2, q3, [sp, #768]
	add	x13, sp, #768
	ldr	s0, [x13, x1, lsl #2]
	tst	w12, #0x1
	fcsel	s0, s0, s15, ne
	add	x12, sp, #376
	bfxil	x12, x9, #0, #3
	ldrb	w12, [x12]
	and	x9, x9, #0x7
	umov.b	w1, v31[5]
	stp	q2, q3, [sp, #736]
	add	x13, sp, #736
	ldr	s18, [x13, x9, lsl #2]
	ands	w9, w1, #0x1
	tst	w9, w12
	fcsel	s18, s18, s15, ne
	add	x9, sp, #376
	bfxil	x9, x2, #0, #3
	ldrb	w12, [x9]
	and	x2, x2, #0x7
	umov.b	w9, v31[6]
	stp	q2, q3, [sp, #704]
	add	x13, sp, #704
	ldr	s22, [x13, x2, lsl #2]
	ands	w2, w9, #0x1
	tst	w2, w12
	fcsel	s22, s22, s15, ne
	add	x12, sp, #376
	bfxil	x12, x22, #0, #3
	ldrb	w12, [x12]
	umov.b	w2, v31[7]
	and	x22, x22, #0x7
	stp	q2, q3, [sp, #672]
	add	x13, sp, #672
	ldr	s24, [x13, x22, lsl #2]
	ands	w22, w2, #0x1
	tst	w22, w12
	fcsel	s24, s24, s15, ne
	mov.s	v0[1], v18[0]
	mov.s	v0[2], v22[0]
	mov.s	v0[3], v24[0]
	mov.s	v20[1], v21[0]
	mov.s	v20[2], v17[0]
	mov.s	v20[3], v23[0]
	fadd.4s	v2, v2, v20
	fadd.4s	v0, v3, v0
	movi.4s	v17, #2
	eor.16b	v3, v4, v17
	eor.16b	v1, v1, v17
	fmov	w12, s1
	add	x22, sp, #376
	bfxil	x22, x12, #0, #3
	ldrb	w22, [x22]
	and	x12, x12, #0x7
	stp	q2, q0, [sp, #512]
	add	x13, sp, #512
	ldr	s1, [x13, x12, lsl #2]
	tst	w26, w22
	fcsel	s1, s1, s15, ne
	fmov	w12, s3
	and	x22, x12, #0x7
	add	x13, sp, #376
	bfxil	x13, x12, #0, #3
	ldrb	w12, [x13]
	and	w12, w17, w12
	stp	q2, q0, [sp, #480]
	add	x13, sp, #480
	ldr	s3, [x13, x22, lsl #2]
	tst	w12, #0x1
	fcsel	s3, s3, s15, ne
	fadd.4s	v0, v0, v3
	tst	w26, w17
	fcsel	s0, s0, s15, ne
	ands	w12, w24, #0x1
	fadd.4s	v1, v2, v1
	fadd	s0, s1, s0
	fcsel	s1, s0, s15, ne
	tst	w25, #0x1
	fcsel	s2, s1, s15, ne
	tst	w27, #0x1
	fcsel	s3, s1, s15, ne
	tst	w28, #0x1
	fcsel	s4, s1, s15, ne
	tst	w12, w17
	fcsel	s0, s0, s15, ne
	tst	w1, #0x1
	fcsel	s17, s1, s15, ne
	tst	w9, #0x1
	fcsel	s18, s1, s15, ne
	tst	w2, #0x1
	shl.8b	v20, v19, #7
	cmlt.8b	v20, v20, #0
	ldr	d21, [sp, #152]                 ; 8-byte Folded Reload
	and.8b	v20, v20, v21
	addv.8b	b25, v20
	fmov	w24, s25
	fcsel	s20, s1, s15, ne
	mov.s	v1[1], v2[0]
	mov.s	v1[2], v3[0]
	mov.s	v1[3], v4[0]
	mov.s	v0[1], v17[0]
	mov.s	v0[2], v18[0]
	mov.s	v0[3], v20[0]
	ldr	w9, [sp, #240]                  ; 4-byte Folded Reload
	rbit	w9, w9
	clz	w9, w9
	stp	q1, q0, [sp, #448]
	and	x9, x9, #0x7
	add	x12, sp, #448
	ldr	s3, [x12, x9, lsl #2]
	mov	b0, v19[0]
	mov.b	v0[4], v19[1]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	mov	b1, v19[2]
	mov.b	v1[4], v19[3]
	ldr	q2, [sp, #160]                  ; 16-byte Folded Reload
	and.16b	v0, v0, v2
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	ldp	q2, q4, [sp, #96]               ; 32-byte Folded Reload
	and.16b	v1, v1, v2
	mov	b2, v19[4]
	mov.b	v2[4], v19[5]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	and.16b	v2, v2, v4
	mov	b4, v19[6]
	mov.b	v4[4], v19[7]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldr	q17, [sp, #128]                 ; 16-byte Folded Reload
	and.16b	v4, v4, v17
	stp	q2, q4, [sp, #416]
	stp	q0, q1, [sp, #384]
	and	x9, x20, #0x7
	add	x12, sp, #384
	ldr	x9, [x12, x9, lsl #3]
	sub	x9, x9, x20
	add	x21, x21, x9, lsl #2
	movi.2d	v2, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbnz	w24, #0, LBB0_99
; %bb.58:                               ; %else128
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	x13, [sp, #296]                 ; 8-byte Folded Reload
	tbnz	w24, #1, LBB0_100
LBB0_59:                                ; %else131
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	w26, #32                        ; =0x20
	mov	x27, x19
	mov	x28, x23
	tbnz	w24, #2, LBB0_101
LBB0_60:                                ; %else134
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w24, #3, LBB0_102
LBB0_61:                                ; %else137
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w24, #4, LBB0_103
LBB0_62:                                ; %else140
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w24, #5, LBB0_104
LBB0_63:                                ; %else143
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w24, #6, LBB0_105
LBB0_64:                                ; %else146
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w24, #7, LBB0_66
LBB0_65:                                ; %cond.load148
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x21, #28
	ld1.s	{ v1 }[3], [x9]
LBB0_66:                                ; %else149
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x9, #0                          ; =0x0
	fadd	s0, s3, s15
	fmov	s3, w11
	fdiv	s0, s0, s3
	add	x12, x15, x3
	ldp	q3, q4, [x12]
	zip2.8b	v17, v19, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bit.16b	v4, v1, v17
	zip1.8b	v17, v19, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bit.16b	v3, v2, v17
	stp	q3, q4, [x12]
	fmov	s3, w14
	fadd	s0, s0, s3
	fsqrt	s0, s0
	dup.4s	v3, v0[0]
	ldr	q0, [sp, #176]                  ; 16-byte Folded Reload
	fmov	x12, d0
	add	x17, x13, x12, lsl #2
	movi.2d	v4, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	ldr	w3, [sp, #28]                   ; 4-byte Folded Reload
	b	LBB0_68
LBB0_67:                                ; %else166
                                        ;   in Loop: Header=BB0_68 Depth=2
	add.2d	v17, v17, v27
	add.2d	v19, v19, v28
	add.2d	v20, v20, v26
	add.2d	v4, v4, v29
	fmov	x9, d4
	cmp	x9, #8
	b.ge	LBB0_84
LBB0_68:                                ; %direct.true119.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w1, s7
	lsl	x9, x9, #5
	add	x12, x4, x9
	ldp	q0, q21, [x12]
	and.16b	v0, v6, v0
	fdiv.4s	v0, v0, v3
	add	x12, x15, x9
	ldp	q18, q22, [x12]
	and.16b	v18, v6, v18
	fmul.4s	v23, v0, v18
	add	x9, x17, x9
	tbnz	w1, #0, LBB0_76
; %bb.69:                               ; %else152
                                        ;   in Loop: Header=BB0_68 Depth=2
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB0_77
LBB0_70:                                ; %else154
                                        ;   in Loop: Header=BB0_68 Depth=2
	tbnz	w1, #2, LBB0_78
LBB0_71:                                ; %else156
                                        ;   in Loop: Header=BB0_68 Depth=2
	tbnz	w1, #3, LBB0_79
LBB0_72:                                ; %else158
                                        ;   in Loop: Header=BB0_68 Depth=2
	and.16b	v0, v5, v21
	fdiv.4s	v0, v0, v3
	and.16b	v18, v5, v22
	fmul.4s	v21, v0, v18
	tbnz	w1, #4, LBB0_80
LBB0_73:                                ; %else160
                                        ;   in Loop: Header=BB0_68 Depth=2
	tbnz	w1, #5, LBB0_81
LBB0_74:                                ; %else162
                                        ;   in Loop: Header=BB0_68 Depth=2
	tbnz	w1, #6, LBB0_82
LBB0_75:                                ; %else164
                                        ;   in Loop: Header=BB0_68 Depth=2
	tbz	w1, #7, LBB0_67
	b	LBB0_83
LBB0_76:                                ; %cond.store
                                        ;   in Loop: Header=BB0_68 Depth=2
	str	s23, [x9]
	and	w1, w1, #0xff
	tbz	w1, #1, LBB0_70
LBB0_77:                                ; %cond.store153
                                        ;   in Loop: Header=BB0_68 Depth=2
	add	x12, x9, #4
	st1.s	{ v23 }[1], [x12]
	tbz	w1, #2, LBB0_71
LBB0_78:                                ; %cond.store155
                                        ;   in Loop: Header=BB0_68 Depth=2
	add	x12, x9, #8
	st1.s	{ v23 }[2], [x12]
	tbz	w1, #3, LBB0_72
LBB0_79:                                ; %cond.store157
                                        ;   in Loop: Header=BB0_68 Depth=2
	add	x12, x9, #12
	st1.s	{ v23 }[3], [x12]
	and.16b	v0, v5, v21
	fdiv.4s	v0, v0, v3
	and.16b	v18, v5, v22
	fmul.4s	v21, v0, v18
	tbz	w1, #4, LBB0_73
LBB0_80:                                ; %cond.store159
                                        ;   in Loop: Header=BB0_68 Depth=2
	str	s21, [x9, #16]
	tbz	w1, #5, LBB0_74
LBB0_81:                                ; %cond.store161
                                        ;   in Loop: Header=BB0_68 Depth=2
	add	x12, x9, #20
	st1.s	{ v21 }[1], [x12]
	tbz	w1, #6, LBB0_75
LBB0_82:                                ; %cond.store163
                                        ;   in Loop: Header=BB0_68 Depth=2
	add	x12, x9, #24
	st1.s	{ v21 }[2], [x12]
	tbz	w1, #7, LBB0_67
LBB0_83:                                ; %cond.store165
                                        ;   in Loop: Header=BB0_68 Depth=2
	add	x9, x9, #28
	st1.s	{ v21 }[3], [x9]
	b	LBB0_67
LBB0_84:                                ; %direct.false120.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	fdiv.4s	v0, v30, v3
	fmul.4s	v2, v0, v2
	ldr	q4, [sp, #272]                  ; 16-byte Folded Reload
	ldp	q6, q5, [sp, #192]              ; 32-byte Folded Reload
	stp	q4, q5, [sp, #304]
	ldr	q0, [sp, #224]                  ; 16-byte Folded Reload
	stp	q6, q0, [sp, #336]
	and	x9, x20, #0x7
	add	x12, sp, #304
	ldr	x9, [x12, x9, lsl #3]
	sub	x9, x9, x20
	add	x9, x13, x9, lsl #2
	fmov	w17, s25
	tbnz	w17, #0, LBB0_106
; %bb.85:                               ; %else169
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w17, #1, LBB0_107
LBB0_86:                                ; %else171
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w17, #2, LBB0_108
LBB0_87:                                ; %else173
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w17, #3, LBB0_109
LBB0_88:                                ; %else175
                                        ;   in Loop: Header=BB0_4 Depth=1
	fdiv.4s	v0, v16, v3
	fmul.4s	v1, v0, v1
	tbnz	w17, #4, LBB0_110
LBB0_89:                                ; %else177
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w17, #5, LBB0_111
LBB0_90:                                ; %else179
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w17, #6, LBB0_112
LBB0_91:                                ; %else181
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w17, #7, LBB0_3
	b	LBB0_113
LBB0_92:                                ; %cond.load77
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	s24, [x23]
	tbz	w24, #1, LBB0_30
LBB0_93:                                ; %cond.load80
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x23, #4
	ld1.s	{ v24 }[1], [x9]
	tbz	w24, #2, LBB0_31
LBB0_94:                                ; %cond.load83
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x23, #8
	ld1.s	{ v24 }[2], [x9]
	tbz	w24, #3, LBB0_32
LBB0_95:                                ; %cond.load86
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x23, #12
	ld1.s	{ v24 }[3], [x9]
	tbz	w24, #4, LBB0_33
LBB0_96:                                ; %cond.load89
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x23, #16
	ld1.s	{ v16 }[0], [x9]
	tbz	w24, #5, LBB0_34
LBB0_97:                                ; %cond.load92
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x23, #20
	ld1.s	{ v16 }[1], [x9]
	tbz	w24, #6, LBB0_35
LBB0_98:                                ; %cond.load95
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x23, #24
	ld1.s	{ v16 }[2], [x9]
	tbnz	w24, #7, LBB0_36
	b	LBB0_37
LBB0_99:                                ; %cond.load127
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	s2, [x21]
	ldr	x13, [sp, #296]                 ; 8-byte Folded Reload
	tbz	w24, #1, LBB0_59
LBB0_100:                               ; %cond.load130
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x21, #4
	ld1.s	{ v2 }[1], [x9]
	mov	w26, #32                        ; =0x20
	mov	x27, x19
	mov	x28, x23
	tbz	w24, #2, LBB0_60
LBB0_101:                               ; %cond.load133
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x21, #8
	ld1.s	{ v2 }[2], [x9]
	tbz	w24, #3, LBB0_61
LBB0_102:                               ; %cond.load136
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x21, #12
	ld1.s	{ v2 }[3], [x9]
	tbz	w24, #4, LBB0_62
LBB0_103:                               ; %cond.load139
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x21, #16
	ld1.s	{ v1 }[0], [x9]
	tbz	w24, #5, LBB0_63
LBB0_104:                               ; %cond.load142
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x21, #20
	ld1.s	{ v1 }[1], [x9]
	tbz	w24, #6, LBB0_64
LBB0_105:                               ; %cond.load145
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x21, #24
	ld1.s	{ v1 }[2], [x9]
	tbnz	w24, #7, LBB0_65
	b	LBB0_66
LBB0_106:                               ; %cond.store168
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s2, [x9]
	tbz	w17, #1, LBB0_86
LBB0_107:                               ; %cond.store170
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x12, x9, #4
	st1.s	{ v2 }[1], [x12]
	tbz	w17, #2, LBB0_87
LBB0_108:                               ; %cond.store172
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x12, x9, #8
	st1.s	{ v2 }[2], [x12]
	tbz	w17, #3, LBB0_88
LBB0_109:                               ; %cond.store174
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x12, x9, #12
	st1.s	{ v2 }[3], [x12]
	fdiv.4s	v0, v16, v3
	fmul.4s	v1, v0, v1
	tbz	w17, #4, LBB0_89
LBB0_110:                               ; %cond.store176
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s1, [x9, #16]
	tbz	w17, #5, LBB0_90
LBB0_111:                               ; %cond.store178
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x12, x9, #20
	st1.s	{ v1 }[1], [x12]
	tbz	w17, #6, LBB0_91
LBB0_112:                               ; %cond.store180
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x12, x9, #24
	st1.s	{ v1 }[2], [x12]
	tbz	w17, #7, LBB0_3
LBB0_113:                               ; %cond.store182
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v1 }[3], [x9]
	b	LBB0_3
LBB0_114:                               ; %block.batch.exit.loopexit
	ldr	x9, [sp, #16]                   ; 8-byte Folded Reload
	stp	w6, w5, [x9]
	str	w16, [x9, #8]
	mov	w8, #24                         ; =0x18
	str	w8, [x9, #36]
	add	sp, sp, #1536
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_115:                               ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
                                        ; -- End function
.subsections_via_symbols

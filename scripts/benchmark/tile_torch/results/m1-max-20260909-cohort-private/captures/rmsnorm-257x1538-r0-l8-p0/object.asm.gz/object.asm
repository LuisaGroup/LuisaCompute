
/tmp/luisa-cohort-private.qfZvpM/capture/rmsnorm-257x1538-r0-l8-p0/object/tile_xir_w8_77308_1788916368193564_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x3, lsl #12   ; =0x3000
      2c:      	sub	sp, sp, #0x5a0
      30:      	str	x0, [sp, #0x140]
      34:      	str	w3, [sp, #0x158]
      38:      	cbz	w3, 0x3018 <ltmp0+0x3018>
      3c:      	mov	w15, #0x0               ; =0
      40:      	add	x8, sp, #0x560
      44:      	add	x23, sp, #0x1, lsl #12  ; =0x1000
      48:      	add	x23, x23, #0xd80
      4c:      	dup.2d	v0, x8
      50:      	mov	w17, #0x1808            ; =6152
      54:      	mov	w14, #0x4               ; =4
      58:      	adrp	x1, 0x0 <ltmp0>
      5c:      	dup.2d	v1, x23
      60:      	adrp	x16, 0x0 <ltmp0>
      64:      	adrp	x4, 0x0 <ltmp0>
      68:      	adrp	x5, 0x0 <ltmp0>
      6c:      	dup.2d	v2, x14
      70:      	str	q2, [sp, #0x130]
      74:      	adrp	x6, 0x0 <ltmp0>
      78:      	adrp	x8, 0x0 <ltmp0>
      7c:      	ldr	q3, [x8]
      80:      	adrp	x7, 0x0 <ltmp0>
      84:      	adrp	x8, 0x0 <ltmp0>
      88:      	ldr	q4, [x8]
      8c:      	adrp	x19, 0x0 <ltmp0>
      90:      	adrp	x20, 0x0 <ltmp0>
      94:      	adrp	x21, 0x0 <ltmp0>
      98:      	adrp	x22, 0x0 <ltmp0>
      9c:      	adrp	x10, 0x0 <ltmp0>
      a0:      	adrp	x24, 0x0 <ltmp0>
      a4:      	mov	w25, #0x1               ; =1
      a8:      	movi	d12, #0000000000000000
      ac:      	ldp	w9, w8, [x2, #0x2c]
      b0:      	str	w9, [sp, #0x154]
      b4:      	str	w8, [sp, #0x150]
      b8:      	ldp	w8, w9, [x2]
      bc:      	ldp	w11, w12, [x2, #0x8]
      c0:      	str	x2, [sp, #0x8]
      c4:      	str	x12, [sp, #0x148]
      c8:      	str	q3, [sp, #0x250]
      cc:      	b	0x110 <ltmp0+0x110>
      d0:      	add	w8, w26, #0x1
      d4:      	ldr	w9, [sp, #0x154]
      d8:      	cmp	w8, w9
      dc:      	cset	w9, eq
      e0:      	csinc	w8, wzr, w26, eq
      e4:      	cinc	w11, w2, eq
      e8:      	ldr	w12, [sp, #0x150]
      ec:      	cmp	w11, w12
      f0:      	cset	w12, eq
      f4:      	ands	w12, w9, w12
      f8:      	csel	w9, wzr, w11, ne
      fc:      	add	w11, w0, w12
     100:      	add	w15, w15, #0x1
     104:      	ldr	w12, [sp, #0x158]
     108:      	cmp	w15, w12
     10c:      	b.eq	0x3004 <ltmp0+0x3004>
     110:      	mov	x0, x11
     114:      	mov	x2, x9
     118:      	mov	x26, x8
     11c:      	ubfiz	x8, x8, #5, #32
     120:      	ldr	x13, [sp, #0x148]
     124:      	cmp	x8, x13
     128:      	csel	x9, x8, xzr, ls
     12c:      	subs	x11, x13, x9
     130:      	cmp	x11, #0x20
     134:      	mov	w12, #0x20              ; =32
     138:      	csel	x11, x11, x12, lo
     13c:      	cmp	x13, x9
     140:      	ccmp	x8, x13, #0x2, hi
     144:      	csel	x9, x11, xzr, ls
     148:      	cmp	x9, #0x20
     14c:      	str	w0, [sp, #0x164]
     150:      	str	w2, [sp, #0x160]
     154:      	str	x26, [sp, #0x168]
     158:      	b.lo	0x15cc <ltmp0+0x15cc>
     15c:      	mov	x12, #0x0               ; =0
     160:      	ldr	x8, [sp, #0x140]
     164:      	ldr	x11, [x8]
     168:      	ldr	x3, [x8, #0x10]
     16c:      	ldr	x8, [x8, #0x30]
     170:      	str	x8, [sp, #0x260]
     174:      	ubfiz	w9, w26, #2, #27
     178:      	umull	x8, w9, w17
     17c:      	str	w9, [sp, #0x1d0]
     180:      	umaddl	x13, w9, w17, x11
     184:      	lsl	x0, x12, #5
     188:      	add	x26, x13, x0
     18c:      	ldp	q2, q5, [x26]
     190:      	add	x0, x23, x0
     194:      	stp	q2, q5, [x0]
     198:      	add	x12, x12, #0x1
     19c:      	cmp	x12, #0xc0
     1a0:      	b.ne	0x184 <ltmp0+0x184>
     1a4:      	mov	w9, #0x1800             ; =6144
     1a8:      	add	x13, x8, x9
     1ac:      	str	x11, [sp, #0x1e0]
     1b0:      	add	x12, x11, x13
     1b4:      	add	x0, x12, #0x4
     1b8:      	ldr	s5, [x12]
     1bc:      	ld1.s	{ v5 }[1], [x0]
     1c0:      	ldr	q2, [sp, #0x3580]
     1c4:      	str	q5, [sp, #0x2a0]
     1c8:      	mov.d	v5[1], v2[1]
     1cc:      	str	q5, [sp, #0x3580]
     1d0:      	ldr	q2, [sp, #0x1d80]
     1d4:      	ldr	q5, [sp, #0x1d90]
     1d8:      	fmul.4s	v5, v5, v5
     1dc:      	fmul.4s	v6, v2, v2
     1e0:      	ldr	q2, [sp, #0x1da0]
     1e4:      	ldr	q7, [sp, #0x1db0]
     1e8:      	fmul.4s	v16, v7, v7
     1ec:      	fmul.4s	v7, v2, v2
     1f0:      	ldr	q2, [sp, #0x1dc0]
     1f4:      	ldr	q17, [sp, #0x1dd0]
     1f8:      	fmul.4s	v17, v17, v17
     1fc:      	fmul.4s	v18, v2, v2
     200:      	ldr	q2, [sp, #0x1de0]
     204:      	ldr	q19, [sp, #0x1df0]
     208:      	fmul.4s	v10, v19, v19
     20c:      	fmul.4s	v9, v2, v2
     210:      	ldr	q14, [sp, #0x130]
     214:      	mov.16b	v11, v14
     218:      	mov.16b	v12, v14
     21c:      	mov.16b	v13, v14
     220:      	adrp	x9, 0x0 <ltmp0>
     224:      	adrp	x11, 0x0 <ltmp0>
     228:      	shl.2d	v2, v11, #0x5
     22c:      	add.2d	v30, v1, v2
     230:      	ldr	q2, [sp, #0x250]
     234:      	add.2d	v21, v30, v2
     238:      	mov.d	x12, v21[1]
     23c:      	shl.2d	v2, v12, #0x5
     240:      	add.2d	v19, v1, v2
     244:      	add.2d	v22, v19, v4
     248:      	mov.d	x0, v22[1]
     24c:      	ldr	q27, [x1]
     250:      	shl.2d	v2, v13, #0x5
     254:      	add.2d	v15, v1, v2
     258:      	add.2d	v23, v15, v27
     25c:      	mov.d	x26, v23[1]
     260:      	ldr	q20, [x16]
     264:      	shl.2d	v2, v14, #0x5
     268:      	add.2d	v2, v1, v2
     26c:      	add.2d	v24, v2, v20
     270:      	mov.d	x27, v24[1]
     274:      	fmov	x28, d21
     278:      	ldr	s21, [x28]
     27c:      	fmov	x28, d22
     280:      	fmov	x30, d23
     284:      	ld1.s	{ v21 }[1], [x12]
     288:      	fmov	x12, d24
     28c:      	ld1.s	{ v21 }[2], [x28]
     290:      	ld1.s	{ v21 }[3], [x0]
     294:      	ldr	s22, [x30]
     298:      	ld1.s	{ v22 }[1], [x26]
     29c:      	ld1.s	{ v22 }[2], [x12]
     2a0:      	ld1.s	{ v22 }[3], [x27]
     2a4:      	fmul.4s	v22, v22, v22
     2a8:      	fmul.4s	v21, v21, v21
     2ac:      	fadd.4s	v6, v6, v21
     2b0:      	fadd.4s	v5, v5, v22
     2b4:      	ldr	q23, [x9]
     2b8:      	ldr	q24, [x4]
     2bc:      	ldr	q28, [x5]
     2c0:      	ldr	q29, [x6]
     2c4:      	add.2d	v21, v2, v29
     2c8:      	add.2d	v22, v15, v28
     2cc:      	add.2d	v25, v19, v24
     2d0:      	add.2d	v26, v30, v23
     2d4:      	mov.d	x12, v26[1]
     2d8:      	fmov	x0, d26
     2dc:      	mov.d	x26, v25[1]
     2e0:      	fmov	x27, d25
     2e4:      	mov.d	x28, v22[1]
     2e8:      	fmov	x30, d22
     2ec:      	mov.d	x2, v21[1]
     2f0:      	ldr	s22, [x0]
     2f4:      	ld1.s	{ v22 }[1], [x12]
     2f8:      	ld1.s	{ v22 }[2], [x27]
     2fc:      	ld1.s	{ v22 }[3], [x26]
     300:      	fmov	x12, d21
     304:      	ldr	s21, [x30]
     308:      	ld1.s	{ v21 }[1], [x28]
     30c:      	ld1.s	{ v21 }[2], [x12]
     310:      	ld1.s	{ v21 }[3], [x2]
     314:      	fmul.4s	v21, v21, v21
     318:      	fmul.4s	v22, v22, v22
     31c:      	fadd.4s	v7, v7, v22
     320:      	fadd.4s	v16, v16, v21
     324:      	ldr	q26, [x7]
     328:      	ldr	q25, [x19]
     32c:      	ldr	q31, [x20]
     330:      	ldr	q3, [x21]
     334:      	add.2d	v21, v2, v3
     338:      	add.2d	v22, v30, v26
     33c:      	mov.d	x12, v22[1]
     340:      	fmov	x0, d22
     344:      	add.2d	v22, v19, v25
     348:      	mov.d	x2, v22[1]
     34c:      	fmov	x26, d22
     350:      	add.2d	v22, v15, v31
     354:      	mov.d	x27, v22[1]
     358:      	mov.d	x28, v21[1]
     35c:      	fmov	x30, d22
     360:      	ldr	s22, [x0]
     364:      	ld1.s	{ v22 }[1], [x12]
     368:      	ld1.s	{ v22 }[2], [x26]
     36c:      	fmov	x12, d21
     370:      	ld1.s	{ v22 }[3], [x2]
     374:      	ldr	s21, [x30]
     378:      	ld1.s	{ v21 }[1], [x27]
     37c:      	ld1.s	{ v21 }[2], [x12]
     380:      	ld1.s	{ v21 }[3], [x28]
     384:      	fmul.4s	v21, v21, v21
     388:      	fmul.4s	v22, v22, v22
     38c:      	fadd.4s	v18, v18, v22
     390:      	fadd.4s	v17, v17, v21
     394:      	ldr	q22, [x22]
     398:      	add.2d	v21, v30, v22
     39c:      	mov.d	x12, v21[1]
     3a0:      	ldr	q30, [x10]
     3a4:      	fmov	x0, d21
     3a8:      	ldr	q8, [x24]
     3ac:      	add.2d	v21, v19, v30
     3b0:      	mov.d	x2, v21[1]
     3b4:      	fmov	x26, d21
     3b8:      	ldr	q19, [x11]
     3bc:      	add.2d	v2, v2, v19
     3c0:      	add.2d	v21, v15, v8
     3c4:      	mov.d	x27, v21[1]
     3c8:      	fmov	x28, d21
     3cc:      	mov.d	x30, v2[1]
     3d0:      	ldr	s21, [x0]
     3d4:      	ld1.s	{ v21 }[1], [x12]
     3d8:      	fmov	x12, d2
     3dc:      	ld1.s	{ v21 }[2], [x26]
     3e0:      	ld1.s	{ v21 }[3], [x2]
     3e4:      	fmul.4s	v2, v21, v21
     3e8:      	fadd.4s	v9, v9, v2
     3ec:      	ldr	s2, [x28]
     3f0:      	ld1.s	{ v2 }[1], [x27]
     3f4:      	ld1.s	{ v2 }[2], [x12]
     3f8:      	ld1.s	{ v2 }[3], [x30]
     3fc:      	fmul.4s	v2, v2, v2
     400:      	fadd.4s	v10, v10, v2
     404:      	dup.2d	v2, x14
     408:      	add.2d	v13, v13, v2
     40c:      	add.2d	v12, v12, v2
     410:      	add.2d	v14, v14, v2
     414:      	add.2d	v11, v11, v2
     418:      	fmov	x12, d11
     41c:      	cmp	x12, #0xc0
     420:      	b.lt	0x228 <ltmp0+0x228>
     424:      	stp	q3, q31, [sp, #0x230]
     428:      	stp	q25, q26, [sp, #0x270]
     42c:      	str	q19, [sp, #0x1f0]
     430:      	str	q22, [sp, #0x220]
     434:      	stp	q24, q23, [sp, #0x2b0]
     438:      	mov	x12, #0x0               ; =0
     43c:      	movi.2d	v2, #0000000000000000
     440:      	movi.2d	v21, #0000000000000000
     444:      	movi.2d	v22, #0000000000000000
     448:      	movi.2d	v11, #0000000000000000
     44c:      	mov.16b	v19, v27
     450:      	ldr	q3, [sp, #0x250]
     454:      	add	x12, x3, x12, lsl #5
     458:      	ldp	q13, q12, [x12]
     45c:      	shl.2d	v14, v2, #0x5
     460:      	shl.2d	v15, v21, #0x5
     464:      	shl.2d	v23, v22, #0x5
     468:      	shl.2d	v24, v11, #0x5
     46c:      	add.2d	v24, v24, v20
     470:      	add.2d	v24, v0, v24
     474:      	add.2d	v23, v23, v19
     478:      	add.2d	v15, v15, v4
     47c:      	add.2d	v14, v14, v3
     480:      	add.2d	v14, v0, v14
     484:      	mov.d	x12, v14[1]
     488:      	fmov	x0, d14
     48c:      	str	s13, [x0]
     490:      	st1.s	{ v13 }[1], [x12]
     494:      	add.2d	v14, v0, v15
     498:      	mov.d	x12, v14[1]
     49c:      	fmov	x0, d14
     4a0:      	st1.s	{ v13 }[2], [x0]
     4a4:      	add.2d	v23, v0, v23
     4a8:      	st1.s	{ v13 }[3], [x12]
     4ac:      	mov.d	x12, v23[1]
     4b0:      	fmov	x0, d23
     4b4:      	str	s12, [x0]
     4b8:      	st1.s	{ v12 }[1], [x12]
     4bc:      	mov.d	x12, v24[1]
     4c0:      	fmov	x0, d24
     4c4:      	st1.s	{ v12 }[2], [x0]
     4c8:      	st1.s	{ v12 }[3], [x12]
     4cc:      	dup.2d	v23, x25
     4d0:      	add.2d	v22, v22, v23
     4d4:      	add.2d	v21, v21, v23
     4d8:      	add.2d	v11, v11, v23
     4dc:      	add.2d	v2, v2, v23
     4e0:      	fmov	x12, d2
     4e4:      	cmp	x12, #0xc0
     4e8:      	b.lt	0x454 <ltmp0+0x454>
     4ec:      	mov	x12, #0x0               ; =0
     4f0:      	ldr	q2, [sp, #0x2a0]
     4f4:      	fmul.4s	v2, v2, v2
     4f8:      	fadd.4s	v2, v2, v6
     4fc:      	mov.d	v2[1], v6[1]
     500:      	fadd.4s	v5, v16, v5
     504:      	fadd.4s	v2, v7, v2
     508:      	fadd.4s	v2, v18, v2
     50c:      	fadd.4s	v5, v17, v5
     510:      	fadd.4s	v5, v10, v5
     514:      	fadd.4s	v2, v9, v2
     518:      	rev64.4s	v6, v2
     51c:      	rev64.4s	v7, v5
     520:      	fadd.4s	v5, v5, v7
     524:      	fadd.4s	v2, v2, v6
     528:      	dup.4s	v6, v2[2]
     52c:      	dup.4s	v7, v5[2]
     530:      	fadd.4s	v5, v5, v7
     534:      	fadd.4s	v2, v2, v6
     538:      	fadd.4s	v2, v2, v5
     53c:      	movi	d5, #0000000000000000
     540:      	fadd	s2, s2, s5
     544:      	mov	w9, #0x4000             ; =16384
     548:      	movk	w9, #0x44c0, lsl #16
     54c:      	fmov	s5, w9
     550:      	fdiv	s5, s2, s5
     554:      	mov	w9, #0x1804             ; =6148
     558:      	add	x0, x3, x9
     55c:      	ldr	s2, [x3, #0x1800]
     560:      	ld1.s	{ v2 }[1], [x0]
     564:      	ldr	q6, [sp, #0x1d60]
     568:      	mov.d	v2[1], v6[1]
     56c:      	mov	w9, #0x1800             ; =6144
     570:      	add	x9, x3, x9
     574:      	str	x9, [sp, #0x1c0]
     578:      	mov	w9, #0xc5ac             ; =50604
     57c:      	movk	w9, #0x3727, lsl #16
     580:      	fmov	s6, w9
     584:      	fadd	s5, s5, s6
     588:      	fsqrt	s5, s5
     58c:      	dup.4s	v6, v5[0]
     590:      	str	q2, [sp, #0x1d60]
     594:      	ldr	x11, [sp, #0x260]
     598:      	add	x8, x11, x8
     59c:      	movi.2d	v7, #0000000000000000
     5a0:      	movi.2d	v16, #0000000000000000
     5a4:      	movi.2d	v17, #0000000000000000
     5a8:      	movi.2d	v18, #0000000000000000
     5ac:      	ldr	q27, [sp, #0x280]
     5b0:      	shl.2d	v21, v18, #0x5
     5b4:      	shl.2d	v22, v17, #0x5
     5b8:      	shl.2d	v23, v16, #0x5
     5bc:      	shl.2d	v24, v7, #0x5
     5c0:      	orr.16b	v24, v24, v3
     5c4:      	orr.16b	v23, v23, v4
     5c8:      	orr.16b	v22, v22, v19
     5cc:      	orr.16b	v21, v21, v20
     5d0:      	add.2d	v9, v1, v21
     5d4:      	add.2d	v10, v1, v22
     5d8:      	add.2d	v11, v1, v23
     5dc:      	add.2d	v12, v1, v24
     5e0:      	mov.d	x0, v12[1]
     5e4:      	mov.d	x2, v11[1]
     5e8:      	mov.d	x26, v10[1]
     5ec:      	fmov	x28, d12
     5f0:      	fmov	x30, d10
     5f4:      	mov.d	x9, v9[1]
     5f8:      	fmov	x27, d9
     5fc:      	ldr	s9, [x30]
     600:      	ld1.s	{ v9 }[1], [x26]
     604:      	ld1.s	{ v9 }[2], [x27]
     608:      	ld1.s	{ v9 }[3], [x9]
     60c:      	fmov	x9, d11
     610:      	ldr	s10, [x28]
     614:      	ld1.s	{ v10 }[1], [x0]
     618:      	ld1.s	{ v10 }[2], [x9]
     61c:      	ld1.s	{ v10 }[3], [x2]
     620:      	fdiv.4s	v10, v10, v6
     624:      	fdiv.4s	v9, v9, v6
     628:      	add.2d	v21, v0, v21
     62c:      	add.2d	v22, v0, v22
     630:      	add.2d	v23, v0, v23
     634:      	add.2d	v24, v0, v24
     638:      	mov.d	x9, v24[1]
     63c:      	fmov	x0, d24
     640:      	mov.d	x2, v23[1]
     644:      	mov.d	x26, v22[1]
     648:      	mov.d	x27, v21[1]
     64c:      	fmov	x28, d23
     650:      	ldr	s23, [x0]
     654:      	ld1.s	{ v23 }[1], [x9]
     658:      	ld1.s	{ v23 }[2], [x28]
     65c:      	fmov	x9, d22
     660:      	ld1.s	{ v23 }[3], [x2]
     664:      	ldr	s22, [x9]
     668:      	ld1.s	{ v22 }[1], [x26]
     66c:      	fmov	x9, d21
     670:      	ld1.s	{ v22 }[2], [x9]
     674:      	ld1.s	{ v22 }[3], [x27]
     678:      	fmul.4s	v21, v9, v22
     67c:      	fmul.4s	v22, v10, v23
     680:      	add	x9, x8, x12, lsl #5
     684:      	stp	q22, q21, [x9]
     688:      	dup.2d	v21, x25
     68c:      	add.2d	v17, v17, v21
     690:      	add.2d	v16, v16, v21
     694:      	add.2d	v18, v18, v21
     698:      	add.2d	v7, v7, v21
     69c:      	fmov	x12, d7
     6a0:      	cmp	x12, #0xc0
     6a4:      	b.lt	0x5b0 <ltmp0+0x5b0>
     6a8:      	stp	q8, q30, [sp, #0x200]
     6ac:      	stp	q29, q28, [sp, #0x290]
     6b0:      	mov	x12, #0x0               ; =0
     6b4:      	dup.2s	v5, v5[0]
     6b8:      	ldr	d6, [sp, #0x3580]
     6bc:      	fdiv.2s	v5, v6, v5
     6c0:      	fmul.2s	v2, v2, v5
     6c4:      	str	d2, [x11, x13]
     6c8:      	ldr	w8, [sp, #0x1d0]
     6cc:      	orr	w9, w8, #0x1
     6d0:      	umull	x8, w9, w17
     6d4:      	ldr	x2, [sp, #0x1e0]
     6d8:      	umaddl	x13, w9, w17, x2
     6dc:      	lsl	x9, x12, #5
     6e0:      	add	x0, x13, x9
     6e4:      	ldp	q2, q5, [x0]
     6e8:      	add	x9, x23, x9
     6ec:      	stp	q2, q5, [x9]
     6f0:      	add	x12, x12, #0x1
     6f4:      	cmp	x12, #0xc0
     6f8:      	b.ne	0x6dc <ltmp0+0x6dc>
     6fc:      	mov	w9, #0x1800             ; =6144
     700:      	add	x13, x8, x9
     704:      	add	x9, x2, x13
     708:      	add	x12, x9, #0x4
     70c:      	ldr	s5, [x9]
     710:      	ld1.s	{ v5 }[1], [x12]
     714:      	ldr	q2, [sp, #0x3580]
     718:      	str	q5, [sp, #0x1b0]
     71c:      	mov.d	v5[1], v2[1]
     720:      	str	q5, [sp, #0x3580]
     724:      	ldr	q5, [sp, #0x1d80]
     728:      	ldr	q2, [sp, #0x1d90]
     72c:      	fmul.4s	v2, v2, v2
     730:      	fmul.4s	v10, v5, v5
     734:      	ldr	q5, [sp, #0x1da0]
     738:      	ldr	q6, [sp, #0x1db0]
     73c:      	fmul.4s	v6, v6, v6
     740:      	fmul.4s	v5, v5, v5
     744:      	ldr	q16, [sp, #0x1dc0]
     748:      	ldr	q7, [sp, #0x1dd0]
     74c:      	fmul.4s	v7, v7, v7
     750:      	fmul.4s	v16, v16, v16
     754:      	ldr	q17, [sp, #0x1de0]
     758:      	ldr	q18, [sp, #0x1df0]
     75c:      	fmul.4s	v18, v18, v18
     760:      	fmul.4s	v17, v17, v17
     764:      	dup.2d	v11, x14
     768:      	mov.16b	v12, v11
     76c:      	mov.16b	v13, v11
     770:      	mov.16b	v14, v11
     774:      	mov.16b	v30, v27
     778:      	ldp	q26, q8, [sp, #0x230]
     77c:      	ldp	q28, q27, [sp, #0x210]
     780:      	ldp	q31, q29, [sp, #0x1f0]
     784:      	shl.2d	v21, v11, #0x5
     788:      	shl.2d	v22, v12, #0x5
     78c:      	shl.2d	v23, v13, #0x5
     790:      	shl.2d	v24, v14, #0x5
     794:      	add.2d	v15, v1, v24
     798:      	add.2d	v24, v15, v20
     79c:      	add.2d	v21, v1, v21
     7a0:      	add.2d	v25, v21, v3
     7a4:      	mov.d	x9, v25[1]
     7a8:      	add.2d	v9, v1, v23
     7ac:      	add.2d	v22, v1, v22
     7b0:      	fmov	x12, d25
     7b4:      	add.2d	v23, v22, v4
     7b8:      	mov.d	x0, v23[1]
     7bc:      	fmov	x2, d23
     7c0:      	add.2d	v23, v9, v19
     7c4:      	mov.d	x26, v23[1]
     7c8:      	fmov	x27, d23
     7cc:      	mov.d	x28, v24[1]
     7d0:      	ldr	s23, [x12]
     7d4:      	ld1.s	{ v23 }[1], [x9]
     7d8:      	fmov	x9, d24
     7dc:      	ld1.s	{ v23 }[2], [x2]
     7e0:      	ld1.s	{ v23 }[3], [x0]
     7e4:      	ldr	s24, [x27]
     7e8:      	ld1.s	{ v24 }[1], [x26]
     7ec:      	ld1.s	{ v24 }[2], [x9]
     7f0:      	ld1.s	{ v24 }[3], [x28]
     7f4:      	fmul.4s	v24, v24, v24
     7f8:      	fmul.4s	v23, v23, v23
     7fc:      	fadd.4s	v10, v10, v23
     800:      	fadd.4s	v2, v2, v24
     804:      	ldr	q23, [sp, #0x290]
     808:      	add.2d	v23, v15, v23
     80c:      	ldr	q24, [sp, #0x2c0]
     810:      	add.2d	v24, v21, v24
     814:      	mov.d	x9, v24[1]
     818:      	fmov	x12, d24
     81c:      	ldr	q24, [sp, #0x2b0]
     820:      	add.2d	v24, v22, v24
     824:      	mov.d	x0, v24[1]
     828:      	fmov	x2, d24
     82c:      	ldr	q24, [sp, #0x2a0]
     830:      	add.2d	v24, v9, v24
     834:      	mov.d	x26, v24[1]
     838:      	mov.d	x27, v23[1]
     83c:      	fmov	x28, d24
     840:      	ldr	s24, [x12]
     844:      	ld1.s	{ v24 }[1], [x9]
     848:      	ld1.s	{ v24 }[2], [x2]
     84c:      	fmov	x9, d23
     850:      	ld1.s	{ v24 }[3], [x0]
     854:      	ldr	s23, [x28]
     858:      	ld1.s	{ v23 }[1], [x26]
     85c:      	ld1.s	{ v23 }[2], [x9]
     860:      	ld1.s	{ v23 }[3], [x27]
     864:      	fmul.4s	v23, v23, v23
     868:      	fmul.4s	v24, v24, v24
     86c:      	fadd.4s	v5, v5, v24
     870:      	fadd.4s	v6, v6, v23
     874:      	add.2d	v23, v15, v26
     878:      	add.2d	v24, v21, v30
     87c:      	mov.d	x9, v24[1]
     880:      	fmov	x12, d24
     884:      	ldr	q24, [sp, #0x270]
     888:      	add.2d	v24, v22, v24
     88c:      	mov.d	x0, v24[1]
     890:      	fmov	x2, d24
     894:      	add.2d	v24, v9, v8
     898:      	mov.d	x26, v24[1]
     89c:      	fmov	x27, d24
     8a0:      	mov.d	x28, v23[1]
     8a4:      	ldr	s24, [x12]
     8a8:      	ld1.s	{ v24 }[1], [x9]
     8ac:      	ld1.s	{ v24 }[2], [x2]
     8b0:      	ld1.s	{ v24 }[3], [x0]
     8b4:      	fmov	x9, d23
     8b8:      	fmul.4s	v23, v24, v24
     8bc:      	fadd.4s	v16, v16, v23
     8c0:      	ldr	s23, [x27]
     8c4:      	ld1.s	{ v23 }[1], [x26]
     8c8:      	ld1.s	{ v23 }[2], [x9]
     8cc:      	ld1.s	{ v23 }[3], [x28]
     8d0:      	fmul.4s	v23, v23, v23
     8d4:      	fadd.4s	v7, v7, v23
     8d8:      	add.2d	v22, v22, v28
     8dc:      	add.2d	v21, v21, v27
     8e0:      	mov.d	x9, v21[1]
     8e4:      	mov.d	x12, v22[1]
     8e8:      	fmov	x0, d21
     8ec:      	fmov	x2, d22
     8f0:      	add.2d	v21, v15, v31
     8f4:      	add.2d	v22, v9, v29
     8f8:      	mov.d	x26, v22[1]
     8fc:      	fmov	x27, d22
     900:      	mov.d	x28, v21[1]
     904:      	ldr	s22, [x0]
     908:      	ld1.s	{ v22 }[1], [x9]
     90c:      	fmov	x9, d21
     910:      	ld1.s	{ v22 }[2], [x2]
     914:      	ld1.s	{ v22 }[3], [x12]
     918:      	fmul.4s	v21, v22, v22
     91c:      	fadd.4s	v17, v17, v21
     920:      	ldr	s21, [x27]
     924:      	ld1.s	{ v21 }[1], [x26]
     928:      	ld1.s	{ v21 }[2], [x9]
     92c:      	ld1.s	{ v21 }[3], [x28]
     930:      	fmul.4s	v21, v21, v21
     934:      	fadd.4s	v18, v18, v21
     938:      	dup.2d	v21, x14
     93c:      	add.2d	v13, v13, v21
     940:      	add.2d	v12, v12, v21
     944:      	add.2d	v14, v14, v21
     948:      	add.2d	v11, v11, v21
     94c:      	fmov	x9, d11
     950:      	cmp	x9, #0xc0
     954:      	b.lt	0x784 <ltmp0+0x784>
     958:      	mov	x12, #0x0               ; =0
     95c:      	movi.2d	v21, #0000000000000000
     960:      	movi.2d	v22, #0000000000000000
     964:      	movi.2d	v9, #0000000000000000
     968:      	movi.2d	v11, #0000000000000000
     96c:      	add	x9, x3, x12, lsl #5
     970:      	ldp	q24, q23, [x9]
     974:      	shl.2d	v25, v21, #0x5
     978:      	shl.2d	v12, v22, #0x5
     97c:      	shl.2d	v13, v9, #0x5
     980:      	shl.2d	v14, v11, #0x5
     984:      	add.2d	v14, v14, v20
     988:      	add.2d	v14, v0, v14
     98c:      	add.2d	v13, v13, v19
     990:      	add.2d	v12, v12, v4
     994:      	add.2d	v25, v25, v3
     998:      	add.2d	v25, v0, v25
     99c:      	mov.d	x9, v25[1]
     9a0:      	fmov	x12, d25
     9a4:      	str	s24, [x12]
     9a8:      	st1.s	{ v24 }[1], [x9]
     9ac:      	add.2d	v25, v0, v12
     9b0:      	mov.d	x9, v25[1]
     9b4:      	fmov	x12, d25
     9b8:      	st1.s	{ v24 }[2], [x12]
     9bc:      	add.2d	v25, v0, v13
     9c0:      	st1.s	{ v24 }[3], [x9]
     9c4:      	mov.d	x9, v25[1]
     9c8:      	fmov	x12, d25
     9cc:      	str	s23, [x12]
     9d0:      	st1.s	{ v23 }[1], [x9]
     9d4:      	mov.d	x9, v14[1]
     9d8:      	fmov	x12, d14
     9dc:      	st1.s	{ v23 }[2], [x12]
     9e0:      	st1.s	{ v23 }[3], [x9]
     9e4:      	dup.2d	v23, x25
     9e8:      	add.2d	v9, v9, v23
     9ec:      	add.2d	v22, v22, v23
     9f0:      	add.2d	v11, v11, v23
     9f4:      	add.2d	v21, v21, v23
     9f8:      	fmov	x12, d21
     9fc:      	cmp	x12, #0xc0
     a00:      	b.lt	0x96c <ltmp0+0x96c>
     a04:      	mov	x0, #0x0                ; =0
     a08:      	ldr	q21, [sp, #0x1b0]
     a0c:      	fmul.4s	v21, v21, v21
     a10:      	fadd.4s	v21, v21, v10
     a14:      	mov.d	v21[1], v10[1]
     a18:      	ldr	x12, [sp, #0x1c0]
     a1c:      	add	x9, x12, #0x4
     a20:      	ldr	s9, [x12]
     a24:      	ld1.s	{ v9 }[1], [x9]
     a28:      	fadd.4s	v2, v6, v2
     a2c:      	fadd.4s	v5, v5, v21
     a30:      	fadd.4s	v5, v16, v5
     a34:      	fadd.4s	v2, v7, v2
     a38:      	fadd.4s	v2, v18, v2
     a3c:      	fadd.4s	v5, v17, v5
     a40:      	rev64.4s	v6, v5
     a44:      	rev64.4s	v7, v2
     a48:      	fadd.4s	v2, v2, v7
     a4c:      	fadd.4s	v5, v5, v6
     a50:      	dup.4s	v6, v5[2]
     a54:      	dup.4s	v7, v2[2]
     a58:      	fadd.4s	v2, v2, v7
     a5c:      	fadd.4s	v5, v5, v6
     a60:      	fadd.4s	v2, v5, v2
     a64:      	movi	d5, #0000000000000000
     a68:      	fadd	s2, s2, s5
     a6c:      	mov	w9, #0x4000             ; =16384
     a70:      	movk	w9, #0x44c0, lsl #16
     a74:      	fmov	s5, w9
     a78:      	ldr	q6, [sp, #0x1d60]
     a7c:      	mov.d	v9[1], v6[1]
     a80:      	fdiv	s2, s2, s5
     a84:      	mov	w9, #0xc5ac             ; =50604
     a88:      	movk	w9, #0x3727, lsl #16
     a8c:      	fmov	s5, w9
     a90:      	fadd	s2, s2, s5
     a94:      	fsqrt	s2, s2
     a98:      	dup.4s	v5, v2[0]
     a9c:      	str	q9, [sp, #0x1d60]
     aa0:      	add	x8, x11, x8
     aa4:      	movi.2d	v6, #0000000000000000
     aa8:      	movi.2d	v7, #0000000000000000
     aac:      	movi.2d	v16, #0000000000000000
     ab0:      	movi.2d	v17, #0000000000000000
     ab4:      	shl.2d	v18, v17, #0x5
     ab8:      	shl.2d	v21, v16, #0x5
     abc:      	shl.2d	v22, v7, #0x5
     ac0:      	shl.2d	v23, v6, #0x5
     ac4:      	orr.16b	v23, v23, v3
     ac8:      	orr.16b	v22, v22, v4
     acc:      	orr.16b	v21, v21, v19
     ad0:      	orr.16b	v18, v18, v20
     ad4:      	add.2d	v24, v1, v18
     ad8:      	add.2d	v25, v1, v21
     adc:      	add.2d	v10, v1, v22
     ae0:      	add.2d	v11, v1, v23
     ae4:      	mov.d	x9, v11[1]
     ae8:      	mov.d	x12, v10[1]
     aec:      	mov.d	x2, v25[1]
     af0:      	fmov	x26, d11
     af4:      	fmov	x27, d25
     af8:      	mov.d	x28, v24[1]
     afc:      	fmov	x30, d24
     b00:      	ldr	s24, [x27]
     b04:      	ld1.s	{ v24 }[1], [x2]
     b08:      	ld1.s	{ v24 }[2], [x30]
     b0c:      	ld1.s	{ v24 }[3], [x28]
     b10:      	fmov	x2, d10
     b14:      	ldr	s25, [x26]
     b18:      	ld1.s	{ v25 }[1], [x9]
     b1c:      	ld1.s	{ v25 }[2], [x2]
     b20:      	ld1.s	{ v25 }[3], [x12]
     b24:      	fdiv.4s	v25, v25, v5
     b28:      	fdiv.4s	v24, v24, v5
     b2c:      	add.2d	v18, v0, v18
     b30:      	add.2d	v21, v0, v21
     b34:      	add.2d	v22, v0, v22
     b38:      	add.2d	v23, v0, v23
     b3c:      	mov.d	x9, v23[1]
     b40:      	fmov	x12, d23
     b44:      	mov.d	x2, v22[1]
     b48:      	mov.d	x26, v21[1]
     b4c:      	mov.d	x27, v18[1]
     b50:      	fmov	x28, d22
     b54:      	ldr	s22, [x12]
     b58:      	ld1.s	{ v22 }[1], [x9]
     b5c:      	ld1.s	{ v22 }[2], [x28]
     b60:      	fmov	x9, d21
     b64:      	ld1.s	{ v22 }[3], [x2]
     b68:      	ldr	s21, [x9]
     b6c:      	ld1.s	{ v21 }[1], [x26]
     b70:      	fmov	x9, d18
     b74:      	ld1.s	{ v21 }[2], [x9]
     b78:      	ld1.s	{ v21 }[3], [x27]
     b7c:      	fmul.4s	v18, v24, v21
     b80:      	fmul.4s	v21, v25, v22
     b84:      	add	x9, x8, x0, lsl #5
     b88:      	stp	q21, q18, [x9]
     b8c:      	dup.2d	v18, x25
     b90:      	add.2d	v16, v16, v18
     b94:      	add.2d	v7, v7, v18
     b98:      	add.2d	v17, v17, v18
     b9c:      	add.2d	v6, v6, v18
     ba0:      	fmov	x0, d6
     ba4:      	cmp	x0, #0xc0
     ba8:      	b.lt	0xab4 <ltmp0+0xab4>
     bac:      	mov	x12, #0x0               ; =0
     bb0:      	dup.2s	v2, v2[0]
     bb4:      	ldr	d5, [sp, #0x3580]
     bb8:      	fdiv.2s	v2, v5, v2
     bbc:      	fmul.2s	v2, v9, v2
     bc0:      	str	d2, [x11, x13]
     bc4:      	ldr	w8, [sp, #0x1d0]
     bc8:      	orr	w9, w8, #0x2
     bcc:      	umull	x8, w9, w17
     bd0:      	ldr	x2, [sp, #0x1e0]
     bd4:      	umaddl	x13, w9, w17, x2
     bd8:      	lsl	x9, x12, #5
     bdc:      	add	x0, x13, x9
     be0:      	ldp	q2, q5, [x0]
     be4:      	add	x9, x23, x9
     be8:      	stp	q2, q5, [x9]
     bec:      	add	x12, x12, #0x1
     bf0:      	cmp	x12, #0xc0
     bf4:      	b.ne	0xbd8 <ltmp0+0xbd8>
     bf8:      	mov	w9, #0x1800             ; =6144
     bfc:      	add	x13, x8, x9
     c00:      	add	x9, x2, x13
     c04:      	add	x12, x9, #0x4
     c08:      	ldr	s5, [x9]
     c0c:      	ld1.s	{ v5 }[1], [x12]
     c10:      	ldr	q2, [sp, #0x3580]
     c14:      	str	q5, [sp, #0x1b0]
     c18:      	mov.d	v5[1], v2[1]
     c1c:      	str	q5, [sp, #0x3580]
     c20:      	ldr	q5, [sp, #0x1d80]
     c24:      	ldr	q2, [sp, #0x1d90]
     c28:      	fmul.4s	v2, v2, v2
     c2c:      	fmul.4s	v10, v5, v5
     c30:      	ldr	q5, [sp, #0x1da0]
     c34:      	ldr	q6, [sp, #0x1db0]
     c38:      	fmul.4s	v6, v6, v6
     c3c:      	fmul.4s	v5, v5, v5
     c40:      	ldr	q16, [sp, #0x1dc0]
     c44:      	ldr	q7, [sp, #0x1dd0]
     c48:      	fmul.4s	v7, v7, v7
     c4c:      	fmul.4s	v16, v16, v16
     c50:      	ldr	q17, [sp, #0x1de0]
     c54:      	ldr	q18, [sp, #0x1df0]
     c58:      	fmul.4s	v18, v18, v18
     c5c:      	fmul.4s	v17, v17, v17
     c60:      	dup.2d	v11, x14
     c64:      	mov.16b	v12, v11
     c68:      	mov.16b	v13, v11
     c6c:      	mov.16b	v14, v11
     c70:      	ldr	q31, [sp, #0x270]
     c74:      	ldp	q26, q8, [sp, #0x230]
     c78:      	ldp	q28, q27, [sp, #0x210]
     c7c:      	ldp	q30, q29, [sp, #0x1f0]
     c80:      	shl.2d	v21, v11, #0x5
     c84:      	shl.2d	v22, v12, #0x5
     c88:      	shl.2d	v23, v13, #0x5
     c8c:      	shl.2d	v24, v14, #0x5
     c90:      	add.2d	v15, v1, v24
     c94:      	add.2d	v24, v15, v20
     c98:      	add.2d	v21, v1, v21
     c9c:      	add.2d	v25, v21, v3
     ca0:      	mov.d	x9, v25[1]
     ca4:      	add.2d	v9, v1, v23
     ca8:      	add.2d	v22, v1, v22
     cac:      	fmov	x12, d25
     cb0:      	add.2d	v23, v22, v4
     cb4:      	mov.d	x0, v23[1]
     cb8:      	fmov	x2, d23
     cbc:      	add.2d	v23, v9, v19
     cc0:      	mov.d	x26, v23[1]
     cc4:      	fmov	x27, d23
     cc8:      	mov.d	x28, v24[1]
     ccc:      	ldr	s23, [x12]
     cd0:      	ld1.s	{ v23 }[1], [x9]
     cd4:      	fmov	x9, d24
     cd8:      	ld1.s	{ v23 }[2], [x2]
     cdc:      	ld1.s	{ v23 }[3], [x0]
     ce0:      	ldr	s24, [x27]
     ce4:      	ld1.s	{ v24 }[1], [x26]
     ce8:      	ld1.s	{ v24 }[2], [x9]
     cec:      	ld1.s	{ v24 }[3], [x28]
     cf0:      	fmul.4s	v24, v24, v24
     cf4:      	fmul.4s	v23, v23, v23
     cf8:      	fadd.4s	v10, v10, v23
     cfc:      	fadd.4s	v2, v2, v24
     d00:      	ldr	q23, [sp, #0x290]
     d04:      	add.2d	v23, v15, v23
     d08:      	ldr	q24, [sp, #0x2c0]
     d0c:      	add.2d	v24, v21, v24
     d10:      	mov.d	x9, v24[1]
     d14:      	fmov	x12, d24
     d18:      	ldr	q24, [sp, #0x2b0]
     d1c:      	add.2d	v24, v22, v24
     d20:      	mov.d	x0, v24[1]
     d24:      	fmov	x2, d24
     d28:      	ldr	q24, [sp, #0x2a0]
     d2c:      	add.2d	v24, v9, v24
     d30:      	mov.d	x26, v24[1]
     d34:      	mov.d	x27, v23[1]
     d38:      	fmov	x28, d24
     d3c:      	ldr	s24, [x12]
     d40:      	ld1.s	{ v24 }[1], [x9]
     d44:      	ld1.s	{ v24 }[2], [x2]
     d48:      	fmov	x9, d23
     d4c:      	ld1.s	{ v24 }[3], [x0]
     d50:      	ldr	s23, [x28]
     d54:      	ld1.s	{ v23 }[1], [x26]
     d58:      	ld1.s	{ v23 }[2], [x9]
     d5c:      	ld1.s	{ v23 }[3], [x27]
     d60:      	fmul.4s	v23, v23, v23
     d64:      	fmul.4s	v24, v24, v24
     d68:      	fadd.4s	v5, v5, v24
     d6c:      	fadd.4s	v6, v6, v23
     d70:      	add.2d	v23, v15, v26
     d74:      	ldr	q24, [sp, #0x280]
     d78:      	add.2d	v24, v21, v24
     d7c:      	mov.d	x9, v24[1]
     d80:      	fmov	x12, d24
     d84:      	add.2d	v24, v22, v31
     d88:      	mov.d	x0, v24[1]
     d8c:      	fmov	x2, d24
     d90:      	add.2d	v24, v9, v8
     d94:      	mov.d	x26, v24[1]
     d98:      	fmov	x27, d24
     d9c:      	mov.d	x28, v23[1]
     da0:      	ldr	s24, [x12]
     da4:      	ld1.s	{ v24 }[1], [x9]
     da8:      	ld1.s	{ v24 }[2], [x2]
     dac:      	ld1.s	{ v24 }[3], [x0]
     db0:      	fmov	x9, d23
     db4:      	fmul.4s	v23, v24, v24
     db8:      	fadd.4s	v16, v16, v23
     dbc:      	ldr	s23, [x27]
     dc0:      	ld1.s	{ v23 }[1], [x26]
     dc4:      	ld1.s	{ v23 }[2], [x9]
     dc8:      	ld1.s	{ v23 }[3], [x28]
     dcc:      	fmul.4s	v23, v23, v23
     dd0:      	fadd.4s	v7, v7, v23
     dd4:      	add.2d	v22, v22, v28
     dd8:      	add.2d	v21, v21, v27
     ddc:      	mov.d	x9, v21[1]
     de0:      	mov.d	x12, v22[1]
     de4:      	fmov	x0, d21
     de8:      	fmov	x2, d22
     dec:      	add.2d	v21, v15, v30
     df0:      	add.2d	v22, v9, v29
     df4:      	mov.d	x26, v22[1]
     df8:      	fmov	x27, d22
     dfc:      	mov.d	x28, v21[1]
     e00:      	ldr	s22, [x0]
     e04:      	ld1.s	{ v22 }[1], [x9]
     e08:      	fmov	x9, d21
     e0c:      	ld1.s	{ v22 }[2], [x2]
     e10:      	ld1.s	{ v22 }[3], [x12]
     e14:      	fmul.4s	v21, v22, v22
     e18:      	fadd.4s	v17, v17, v21
     e1c:      	ldr	s21, [x27]
     e20:      	ld1.s	{ v21 }[1], [x26]
     e24:      	ld1.s	{ v21 }[2], [x9]
     e28:      	ld1.s	{ v21 }[3], [x28]
     e2c:      	fmul.4s	v21, v21, v21
     e30:      	fadd.4s	v18, v18, v21
     e34:      	dup.2d	v21, x14
     e38:      	add.2d	v13, v13, v21
     e3c:      	add.2d	v12, v12, v21
     e40:      	add.2d	v14, v14, v21
     e44:      	add.2d	v11, v11, v21
     e48:      	fmov	x9, d11
     e4c:      	cmp	x9, #0xc0
     e50:      	b.lt	0xc80 <ltmp0+0xc80>
     e54:      	mov	x12, #0x0               ; =0
     e58:      	movi.2d	v21, #0000000000000000
     e5c:      	movi.2d	v22, #0000000000000000
     e60:      	movi.2d	v9, #0000000000000000
     e64:      	movi.2d	v11, #0000000000000000
     e68:      	add	x9, x3, x12, lsl #5
     e6c:      	ldp	q24, q23, [x9]
     e70:      	shl.2d	v25, v21, #0x5
     e74:      	shl.2d	v12, v22, #0x5
     e78:      	shl.2d	v13, v9, #0x5
     e7c:      	shl.2d	v14, v11, #0x5
     e80:      	add.2d	v14, v14, v20
     e84:      	add.2d	v14, v0, v14
     e88:      	add.2d	v13, v13, v19
     e8c:      	add.2d	v12, v12, v4
     e90:      	add.2d	v25, v25, v3
     e94:      	add.2d	v25, v0, v25
     e98:      	mov.d	x9, v25[1]
     e9c:      	fmov	x12, d25
     ea0:      	str	s24, [x12]
     ea4:      	st1.s	{ v24 }[1], [x9]
     ea8:      	add.2d	v25, v0, v12
     eac:      	mov.d	x9, v25[1]
     eb0:      	fmov	x12, d25
     eb4:      	st1.s	{ v24 }[2], [x12]
     eb8:      	add.2d	v25, v0, v13
     ebc:      	st1.s	{ v24 }[3], [x9]
     ec0:      	mov.d	x9, v25[1]
     ec4:      	fmov	x12, d25
     ec8:      	str	s23, [x12]
     ecc:      	st1.s	{ v23 }[1], [x9]
     ed0:      	mov.d	x9, v14[1]
     ed4:      	fmov	x12, d14
     ed8:      	st1.s	{ v23 }[2], [x12]
     edc:      	st1.s	{ v23 }[3], [x9]
     ee0:      	dup.2d	v23, x25
     ee4:      	add.2d	v9, v9, v23
     ee8:      	add.2d	v22, v22, v23
     eec:      	add.2d	v11, v11, v23
     ef0:      	add.2d	v21, v21, v23
     ef4:      	fmov	x12, d21
     ef8:      	cmp	x12, #0xc0
     efc:      	b.lt	0xe68 <ltmp0+0xe68>
     f00:      	mov	x0, #0x0                ; =0
     f04:      	ldr	q21, [sp, #0x1b0]
     f08:      	fmul.4s	v21, v21, v21
     f0c:      	fadd.4s	v21, v21, v10
     f10:      	mov.d	v21[1], v10[1]
     f14:      	ldr	x12, [sp, #0x1c0]
     f18:      	add	x9, x12, #0x4
     f1c:      	ldr	s9, [x12]
     f20:      	ld1.s	{ v9 }[1], [x9]
     f24:      	fadd.4s	v2, v6, v2
     f28:      	fadd.4s	v5, v5, v21
     f2c:      	fadd.4s	v5, v16, v5
     f30:      	fadd.4s	v2, v7, v2
     f34:      	fadd.4s	v2, v18, v2
     f38:      	fadd.4s	v5, v17, v5
     f3c:      	rev64.4s	v6, v5
     f40:      	rev64.4s	v7, v2
     f44:      	fadd.4s	v2, v2, v7
     f48:      	fadd.4s	v5, v5, v6
     f4c:      	dup.4s	v6, v5[2]
     f50:      	dup.4s	v7, v2[2]
     f54:      	fadd.4s	v2, v2, v7
     f58:      	fadd.4s	v5, v5, v6
     f5c:      	fadd.4s	v2, v5, v2
     f60:      	movi	d5, #0000000000000000
     f64:      	fadd	s2, s2, s5
     f68:      	mov	w9, #0x4000             ; =16384
     f6c:      	movk	w9, #0x44c0, lsl #16
     f70:      	fmov	s5, w9
     f74:      	ldr	q6, [sp, #0x1d60]
     f78:      	mov.d	v9[1], v6[1]
     f7c:      	fdiv	s2, s2, s5
     f80:      	mov	w9, #0xc5ac             ; =50604
     f84:      	movk	w9, #0x3727, lsl #16
     f88:      	fmov	s5, w9
     f8c:      	fadd	s2, s2, s5
     f90:      	fsqrt	s2, s2
     f94:      	dup.4s	v5, v2[0]
     f98:      	str	q9, [sp, #0x1d60]
     f9c:      	add	x8, x11, x8
     fa0:      	movi.2d	v6, #0000000000000000
     fa4:      	movi.2d	v7, #0000000000000000
     fa8:      	movi.2d	v16, #0000000000000000
     fac:      	movi.2d	v17, #0000000000000000
     fb0:      	shl.2d	v18, v17, #0x5
     fb4:      	shl.2d	v21, v16, #0x5
     fb8:      	shl.2d	v22, v7, #0x5
     fbc:      	shl.2d	v23, v6, #0x5
     fc0:      	orr.16b	v23, v23, v3
     fc4:      	orr.16b	v22, v22, v4
     fc8:      	orr.16b	v21, v21, v19
     fcc:      	orr.16b	v18, v18, v20
     fd0:      	add.2d	v24, v1, v18
     fd4:      	add.2d	v25, v1, v21
     fd8:      	add.2d	v10, v1, v22
     fdc:      	add.2d	v11, v1, v23
     fe0:      	mov.d	x9, v11[1]
     fe4:      	mov.d	x12, v10[1]
     fe8:      	mov.d	x2, v25[1]
     fec:      	fmov	x26, d11
     ff0:      	fmov	x27, d25
     ff4:      	mov.d	x28, v24[1]
     ff8:      	fmov	x30, d24
     ffc:      	ldr	s24, [x27]
    1000:      	ld1.s	{ v24 }[1], [x2]
    1004:      	ld1.s	{ v24 }[2], [x30]
    1008:      	ld1.s	{ v24 }[3], [x28]
    100c:      	fmov	x2, d10
    1010:      	ldr	s25, [x26]
    1014:      	ld1.s	{ v25 }[1], [x9]
    1018:      	ld1.s	{ v25 }[2], [x2]
    101c:      	ld1.s	{ v25 }[3], [x12]
    1020:      	fdiv.4s	v25, v25, v5
    1024:      	fdiv.4s	v24, v24, v5
    1028:      	add.2d	v18, v0, v18
    102c:      	add.2d	v21, v0, v21
    1030:      	add.2d	v22, v0, v22
    1034:      	add.2d	v23, v0, v23
    1038:      	mov.d	x9, v23[1]
    103c:      	fmov	x12, d23
    1040:      	mov.d	x2, v22[1]
    1044:      	mov.d	x26, v21[1]
    1048:      	mov.d	x27, v18[1]
    104c:      	fmov	x28, d22
    1050:      	ldr	s22, [x12]
    1054:      	ld1.s	{ v22 }[1], [x9]
    1058:      	ld1.s	{ v22 }[2], [x28]
    105c:      	fmov	x9, d21
    1060:      	ld1.s	{ v22 }[3], [x2]
    1064:      	ldr	s21, [x9]
    1068:      	ld1.s	{ v21 }[1], [x26]
    106c:      	fmov	x9, d18
    1070:      	ld1.s	{ v21 }[2], [x9]
    1074:      	ld1.s	{ v21 }[3], [x27]
    1078:      	fmul.4s	v18, v24, v21
    107c:      	fmul.4s	v21, v25, v22
    1080:      	add	x9, x8, x0, lsl #5
    1084:      	stp	q21, q18, [x9]
    1088:      	dup.2d	v18, x25
    108c:      	add.2d	v16, v16, v18
    1090:      	add.2d	v7, v7, v18
    1094:      	add.2d	v17, v17, v18
    1098:      	add.2d	v6, v6, v18
    109c:      	fmov	x0, d6
    10a0:      	cmp	x0, #0xc0
    10a4:      	b.lt	0xfb0 <ltmp0+0xfb0>
    10a8:      	mov	x12, #0x0               ; =0
    10ac:      	dup.2s	v2, v2[0]
    10b0:      	ldr	d5, [sp, #0x3580]
    10b4:      	fdiv.2s	v2, v5, v2
    10b8:      	fmul.2s	v2, v9, v2
    10bc:      	str	d2, [x11, x13]
    10c0:      	ldr	w8, [sp, #0x1d0]
    10c4:      	orr	w9, w8, #0x3
    10c8:      	umull	x8, w9, w17
    10cc:      	ldr	x11, [sp, #0x1e0]
    10d0:      	umaddl	x13, w9, w17, x11
    10d4:      	lsl	x9, x12, #5
    10d8:      	add	x0, x13, x9
    10dc:      	ldp	q2, q5, [x0]
    10e0:      	add	x9, x23, x9
    10e4:      	stp	q2, q5, [x9]
    10e8:      	add	x12, x12, #0x1
    10ec:      	cmp	x12, #0xc0
    10f0:      	b.ne	0x10d4 <ltmp0+0x10d4>
    10f4:      	mov	w9, #0x1800             ; =6144
    10f8:      	add	x13, x8, x9
    10fc:      	add	x9, x11, x13
    1100:      	add	x11, x9, #0x4
    1104:      	ldr	s5, [x9]
    1108:      	ld1.s	{ v5 }[1], [x11]
    110c:      	ldr	q2, [sp, #0x3580]
    1110:      	str	q5, [sp, #0x1e0]
    1114:      	mov.d	v5[1], v2[1]
    1118:      	str	q5, [sp, #0x3580]
    111c:      	ldr	q2, [sp, #0x1d80]
    1120:      	ldr	q5, [sp, #0x1d90]
    1124:      	fmul.4s	v5, v5, v5
    1128:      	fmul.4s	v6, v2, v2
    112c:      	ldr	q2, [sp, #0x1da0]
    1130:      	ldr	q7, [sp, #0x1db0]
    1134:      	fmul.4s	v16, v7, v7
    1138:      	fmul.4s	v7, v2, v2
    113c:      	ldr	q2, [sp, #0x1dc0]
    1140:      	ldr	q17, [sp, #0x1dd0]
    1144:      	fmul.4s	v17, v17, v17
    1148:      	fmul.4s	v18, v2, v2
    114c:      	ldr	q2, [sp, #0x1de0]
    1150:      	ldr	q21, [sp, #0x1df0]
    1154:      	fmul.4s	v10, v21, v21
    1158:      	fmul.4s	v9, v2, v2
    115c:      	dup.2d	v11, x14
    1160:      	mov.16b	v12, v11
    1164:      	mov.16b	v13, v11
    1168:      	mov.16b	v14, v11
    116c:      	ldr	q31, [sp, #0x270]
    1170:      	ldp	q26, q8, [sp, #0x230]
    1174:      	ldp	q28, q27, [sp, #0x210]
    1178:      	ldp	q30, q29, [sp, #0x1f0]
    117c:      	shl.2d	v2, v11, #0x5
    1180:      	shl.2d	v22, v12, #0x5
    1184:      	shl.2d	v23, v13, #0x5
    1188:      	shl.2d	v21, v14, #0x5
    118c:      	add.2d	v15, v1, v21
    1190:      	add.2d	v24, v15, v20
    1194:      	add.2d	v21, v1, v2
    1198:      	add.2d	v25, v21, v3
    119c:      	mov.d	x9, v25[1]
    11a0:      	add.2d	v2, v1, v23
    11a4:      	add.2d	v22, v1, v22
    11a8:      	fmov	x11, d25
    11ac:      	add.2d	v23, v22, v4
    11b0:      	mov.d	x12, v23[1]
    11b4:      	fmov	x0, d23
    11b8:      	add.2d	v23, v2, v19
    11bc:      	mov.d	x2, v23[1]
    11c0:      	fmov	x26, d23
    11c4:      	mov.d	x27, v24[1]
    11c8:      	ldr	s23, [x11]
    11cc:      	ld1.s	{ v23 }[1], [x9]
    11d0:      	fmov	x9, d24
    11d4:      	ld1.s	{ v23 }[2], [x0]
    11d8:      	ld1.s	{ v23 }[3], [x12]
    11dc:      	ldr	s24, [x26]
    11e0:      	ld1.s	{ v24 }[1], [x2]
    11e4:      	ld1.s	{ v24 }[2], [x9]
    11e8:      	ld1.s	{ v24 }[3], [x27]
    11ec:      	fmul.4s	v24, v24, v24
    11f0:      	fmul.4s	v23, v23, v23
    11f4:      	fadd.4s	v6, v6, v23
    11f8:      	fadd.4s	v5, v5, v24
    11fc:      	ldr	q23, [sp, #0x290]
    1200:      	add.2d	v23, v15, v23
    1204:      	ldr	q24, [sp, #0x2c0]
    1208:      	add.2d	v24, v21, v24
    120c:      	mov.d	x9, v24[1]
    1210:      	fmov	x11, d24
    1214:      	ldr	q24, [sp, #0x2b0]
    1218:      	add.2d	v24, v22, v24
    121c:      	mov.d	x12, v24[1]
    1220:      	fmov	x0, d24
    1224:      	ldr	q24, [sp, #0x2a0]
    1228:      	add.2d	v24, v2, v24
    122c:      	mov.d	x2, v24[1]
    1230:      	mov.d	x26, v23[1]
    1234:      	fmov	x27, d24
    1238:      	ldr	s24, [x11]
    123c:      	ld1.s	{ v24 }[1], [x9]
    1240:      	ld1.s	{ v24 }[2], [x0]
    1244:      	fmov	x9, d23
    1248:      	ld1.s	{ v24 }[3], [x12]
    124c:      	ldr	s23, [x27]
    1250:      	ld1.s	{ v23 }[1], [x2]
    1254:      	ld1.s	{ v23 }[2], [x9]
    1258:      	ld1.s	{ v23 }[3], [x26]
    125c:      	fmul.4s	v23, v23, v23
    1260:      	fmul.4s	v24, v24, v24
    1264:      	fadd.4s	v7, v7, v24
    1268:      	fadd.4s	v16, v16, v23
    126c:      	add.2d	v23, v15, v26
    1270:      	ldr	q24, [sp, #0x280]
    1274:      	add.2d	v24, v21, v24
    1278:      	mov.d	x9, v24[1]
    127c:      	fmov	x11, d24
    1280:      	add.2d	v24, v22, v31
    1284:      	mov.d	x12, v24[1]
    1288:      	fmov	x0, d24
    128c:      	add.2d	v24, v2, v8
    1290:      	mov.d	x2, v24[1]
    1294:      	fmov	x26, d24
    1298:      	mov.d	x27, v23[1]
    129c:      	ldr	s24, [x11]
    12a0:      	ld1.s	{ v24 }[1], [x9]
    12a4:      	ld1.s	{ v24 }[2], [x0]
    12a8:      	ld1.s	{ v24 }[3], [x12]
    12ac:      	fmov	x9, d23
    12b0:      	fmul.4s	v23, v24, v24
    12b4:      	fadd.4s	v18, v18, v23
    12b8:      	ldr	s23, [x26]
    12bc:      	ld1.s	{ v23 }[1], [x2]
    12c0:      	ld1.s	{ v23 }[2], [x9]
    12c4:      	ld1.s	{ v23 }[3], [x27]
    12c8:      	fmul.4s	v23, v23, v23
    12cc:      	fadd.4s	v17, v17, v23
    12d0:      	add.2d	v22, v22, v28
    12d4:      	add.2d	v21, v21, v27
    12d8:      	mov.d	x9, v21[1]
    12dc:      	mov.d	x11, v22[1]
    12e0:      	fmov	x12, d21
    12e4:      	fmov	x0, d22
    12e8:      	add.2d	v21, v15, v30
    12ec:      	add.2d	v2, v2, v29
    12f0:      	mov.d	x2, v2[1]
    12f4:      	fmov	x26, d2
    12f8:      	mov.d	x27, v21[1]
    12fc:      	ldr	s2, [x12]
    1300:      	ld1.s	{ v2 }[1], [x9]
    1304:      	fmov	x9, d21
    1308:      	ld1.s	{ v2 }[2], [x0]
    130c:      	ld1.s	{ v2 }[3], [x11]
    1310:      	fmul.4s	v2, v2, v2
    1314:      	fadd.4s	v9, v9, v2
    1318:      	ldr	s2, [x26]
    131c:      	ld1.s	{ v2 }[1], [x2]
    1320:      	ld1.s	{ v2 }[2], [x9]
    1324:      	ld1.s	{ v2 }[3], [x27]
    1328:      	fmul.4s	v2, v2, v2
    132c:      	fadd.4s	v10, v10, v2
    1330:      	dup.2d	v2, x14
    1334:      	add.2d	v13, v13, v2
    1338:      	add.2d	v12, v12, v2
    133c:      	add.2d	v14, v14, v2
    1340:      	add.2d	v11, v11, v2
    1344:      	fmov	x9, d11
    1348:      	cmp	x9, #0xc0
    134c:      	b.lt	0x117c <ltmp0+0x117c>
    1350:      	mov	x11, #0x0               ; =0
    1354:      	movi.2d	v2, #0000000000000000
    1358:      	movi.2d	v21, #0000000000000000
    135c:      	movi.2d	v22, #0000000000000000
    1360:      	movi.2d	v23, #0000000000000000
    1364:      	add	x9, x3, x11, lsl #5
    1368:      	ldp	q25, q24, [x9]
    136c:      	shl.2d	v26, v2, #0x5
    1370:      	shl.2d	v27, v21, #0x5
    1374:      	shl.2d	v28, v22, #0x5
    1378:      	shl.2d	v29, v23, #0x5
    137c:      	add.2d	v29, v29, v20
    1380:      	add.2d	v29, v0, v29
    1384:      	add.2d	v28, v28, v19
    1388:      	add.2d	v27, v27, v4
    138c:      	add.2d	v26, v26, v3
    1390:      	add.2d	v26, v0, v26
    1394:      	mov.d	x9, v26[1]
    1398:      	fmov	x11, d26
    139c:      	str	s25, [x11]
    13a0:      	st1.s	{ v25 }[1], [x9]
    13a4:      	add.2d	v26, v0, v27
    13a8:      	mov.d	x9, v26[1]
    13ac:      	fmov	x11, d26
    13b0:      	st1.s	{ v25 }[2], [x11]
    13b4:      	add.2d	v26, v0, v28
    13b8:      	st1.s	{ v25 }[3], [x9]
    13bc:      	mov.d	x9, v26[1]
    13c0:      	fmov	x11, d26
    13c4:      	str	s24, [x11]
    13c8:      	st1.s	{ v24 }[1], [x9]
    13cc:      	mov.d	x9, v29[1]
    13d0:      	fmov	x11, d29
    13d4:      	st1.s	{ v24 }[2], [x11]
    13d8:      	st1.s	{ v24 }[3], [x9]
    13dc:      	dup.2d	v24, x25
    13e0:      	add.2d	v22, v22, v24
    13e4:      	add.2d	v21, v21, v24
    13e8:      	add.2d	v23, v23, v24
    13ec:      	add.2d	v2, v2, v24
    13f0:      	fmov	x11, d2
    13f4:      	cmp	x11, #0xc0
    13f8:      	b.lt	0x1364 <ltmp0+0x1364>
    13fc:      	mov	x11, #0x0               ; =0
    1400:      	ldr	q2, [sp, #0x1e0]
    1404:      	fmul.4s	v2, v2, v2
    1408:      	fadd.4s	v2, v2, v6
    140c:      	mov.d	v2[1], v6[1]
    1410:      	fadd.4s	v5, v16, v5
    1414:      	fadd.4s	v2, v7, v2
    1418:      	fadd.4s	v2, v18, v2
    141c:      	fadd.4s	v5, v17, v5
    1420:      	fadd.4s	v5, v10, v5
    1424:      	fadd.4s	v2, v9, v2
    1428:      	rev64.4s	v6, v2
    142c:      	rev64.4s	v7, v5
    1430:      	fadd.4s	v5, v5, v7
    1434:      	fadd.4s	v2, v2, v6
    1438:      	dup.4s	v6, v2[2]
    143c:      	dup.4s	v7, v5[2]
    1440:      	fadd.4s	v5, v5, v7
    1444:      	fadd.4s	v2, v2, v6
    1448:      	fadd.4s	v2, v2, v5
    144c:      	movi	d12, #0000000000000000
    1450:      	fadd	s5, s2, s12
    1454:      	mov	w9, #0x4000             ; =16384
    1458:      	movk	w9, #0x44c0, lsl #16
    145c:      	fmov	s6, w9
    1460:      	ldr	x9, [sp, #0x1c0]
    1464:      	ldr	s2, [x9], #0x4
    1468:      	ld1.s	{ v2 }[1], [x9]
    146c:      	ldr	q7, [sp, #0x1d60]
    1470:      	mov.d	v2[1], v7[1]
    1474:      	fdiv	s5, s5, s6
    1478:      	mov	w9, #0xc5ac             ; =50604
    147c:      	movk	w9, #0x3727, lsl #16
    1480:      	fmov	s6, w9
    1484:      	fadd	s5, s5, s6
    1488:      	fsqrt	s5, s5
    148c:      	dup.4s	v6, v5[0]
    1490:      	str	q2, [sp, #0x1d60]
    1494:      	ldr	x9, [sp, #0x260]
    1498:      	add	x8, x9, x8
    149c:      	movi.2d	v7, #0000000000000000
    14a0:      	movi.2d	v16, #0000000000000000
    14a4:      	movi.2d	v17, #0000000000000000
    14a8:      	movi.2d	v18, #0000000000000000
    14ac:      	shl.2d	v21, v18, #0x5
    14b0:      	shl.2d	v22, v17, #0x5
    14b4:      	shl.2d	v23, v16, #0x5
    14b8:      	shl.2d	v24, v7, #0x5
    14bc:      	orr.16b	v24, v24, v3
    14c0:      	orr.16b	v23, v23, v4
    14c4:      	orr.16b	v22, v22, v19
    14c8:      	orr.16b	v21, v21, v20
    14cc:      	add.2d	v25, v1, v21
    14d0:      	add.2d	v26, v1, v22
    14d4:      	add.2d	v27, v1, v23
    14d8:      	add.2d	v28, v1, v24
    14dc:      	mov.d	x9, v28[1]
    14e0:      	mov.d	x12, v27[1]
    14e4:      	mov.d	x0, v26[1]
    14e8:      	fmov	x2, d28
    14ec:      	fmov	x3, d26
    14f0:      	mov.d	x26, v25[1]
    14f4:      	fmov	x27, d25
    14f8:      	ldr	s25, [x3]
    14fc:      	ld1.s	{ v25 }[1], [x0]
    1500:      	ld1.s	{ v25 }[2], [x27]
    1504:      	ld1.s	{ v25 }[3], [x26]
    1508:      	fmov	x0, d27
    150c:      	ldr	s26, [x2]
    1510:      	ld1.s	{ v26 }[1], [x9]
    1514:      	ld1.s	{ v26 }[2], [x0]
    1518:      	ld1.s	{ v26 }[3], [x12]
    151c:      	fdiv.4s	v26, v26, v6
    1520:      	fdiv.4s	v25, v25, v6
    1524:      	add.2d	v21, v0, v21
    1528:      	add.2d	v22, v0, v22
    152c:      	add.2d	v23, v0, v23
    1530:      	add.2d	v24, v0, v24
    1534:      	mov.d	x9, v24[1]
    1538:      	fmov	x12, d24
    153c:      	mov.d	x0, v23[1]
    1540:      	mov.d	x2, v22[1]
    1544:      	mov.d	x3, v21[1]
    1548:      	fmov	x26, d23
    154c:      	ldr	s23, [x12]
    1550:      	ld1.s	{ v23 }[1], [x9]
    1554:      	ld1.s	{ v23 }[2], [x26]
    1558:      	fmov	x9, d22
    155c:      	ld1.s	{ v23 }[3], [x0]
    1560:      	ldr	s22, [x9]
    1564:      	ld1.s	{ v22 }[1], [x2]
    1568:      	fmov	x9, d21
    156c:      	ld1.s	{ v22 }[2], [x9]
    1570:      	ld1.s	{ v22 }[3], [x3]
    1574:      	fmul.4s	v21, v25, v22
    1578:      	fmul.4s	v22, v26, v23
    157c:      	add	x9, x8, x11, lsl #5
    1580:      	stp	q22, q21, [x9]
    1584:      	dup.2d	v21, x25
    1588:      	add.2d	v17, v17, v21
    158c:      	add.2d	v16, v16, v21
    1590:      	add.2d	v18, v18, v21
    1594:      	add.2d	v7, v7, v21
    1598:      	fmov	x11, d7
    159c:      	cmp	x11, #0xc0
    15a0:      	b.lt	0x14ac <ltmp0+0x14ac>
    15a4:      	dup.2s	v5, v5[0]
    15a8:      	ldr	d6, [sp, #0x3580]
    15ac:      	fdiv.2s	v5, v6, v5
    15b0:      	fmul.2s	v2, v2, v5
    15b4:      	ldr	x8, [sp, #0x260]
    15b8:      	str	d2, [x8, x13]
    15bc:      	ldr	w0, [sp, #0x164]
    15c0:      	ldr	w2, [sp, #0x160]
    15c4:      	ldr	x26, [sp, #0x168]
    15c8:      	b	0xd0 <ltmp0+0xd0>
    15cc:      	str	w15, [sp, #0x15c]
    15d0:      	lsr	x8, x9, #3
    15d4:      	str	x8, [sp, #0x2b0]
    15d8:      	str	x9, [sp, #0x260]
    15dc:      	cmp	x9, #0x8
    15e0:      	b.lo	0x1bb4 <ltmp0+0x1bb4>
    15e4:      	mov	x2, #0x0                ; =0
    15e8:      	ldr	x8, [sp, #0x140]
    15ec:      	ldr	x10, [x8]
    15f0:      	ldr	x27, [x8, #0x10]
    15f4:      	ldr	x13, [x8, #0x30]
    15f8:      	mov	w8, #0x1800             ; =6144
    15fc:      	add	x8, x27, x8
    1600:      	str	x8, [sp, #0x280]
    1604:      	ldr	x8, [sp, #0x168]
    1608:      	lsl	w9, w8, #2
    160c:      	str	x9, [sp, #0x270]
    1610:      	and	x8, x8, #0x7ffffff
    1614:      	mov	w9, #0x6020             ; =24608
    1618:      	str	x10, [sp, #0x2a0]
    161c:      	umaddl	x30, w8, w9, x10
    1620:      	str	x13, [sp, #0x290]
    1624:      	mov	x20, x6
    1628:      	mov	x5, x4
    162c:      	mov	x12, #0x0               ; =0
    1630:      	ldr	x8, [sp, #0x270]
    1634:      	add	w8, w2, w8
    1638:      	and	x8, x8, #0x1fffffff
    163c:      	umull	x8, w8, w17
    1640:      	lsl	x13, x12, #5
    1644:      	add	x11, x30, x13
    1648:      	ldp	q2, q5, [x11]
    164c:      	add	x11, x23, x13
    1650:      	stp	q2, q5, [x11]
    1654:      	add	x12, x12, #0x1
    1658:      	cmp	x12, #0xc0
    165c:      	b.ne	0x1640 <ltmp0+0x1640>
    1660:      	mov	w9, #0x1800             ; =6144
    1664:      	add	x10, x8, x9
    1668:      	ldr	x9, [sp, #0x2a0]
    166c:      	str	x10, [sp, #0x2c0]
    1670:      	add	x11, x9, x10
    1674:      	add	x12, x11, #0x4
    1678:      	ldr	s21, [x11]
    167c:      	ld1.s	{ v21 }[1], [x12]
    1680:      	ldr	q2, [sp, #0x3580]
    1684:      	mov.16b	v5, v21
    1688:      	mov.d	v5[1], v2[1]
    168c:      	str	q5, [sp, #0x3580]
    1690:      	ldr	q2, [sp, #0x1d80]
    1694:      	ldr	q5, [sp, #0x1d90]
    1698:      	fmul.4s	v6, v5, v5
    169c:      	fmul.4s	v22, v2, v2
    16a0:      	ldr	q2, [sp, #0x1da0]
    16a4:      	ldr	q5, [sp, #0x1db0]
    16a8:      	fmul.4s	v16, v5, v5
    16ac:      	fmul.4s	v7, v2, v2
    16b0:      	ldr	q2, [sp, #0x1dc0]
    16b4:      	ldr	q5, [sp, #0x1dd0]
    16b8:      	fmul.4s	v17, v5, v5
    16bc:      	fmul.4s	v18, v2, v2
    16c0:      	ldr	q2, [sp, #0x1de0]
    16c4:      	ldr	q5, [sp, #0x1df0]
    16c8:      	fmul.4s	v20, v5, v5
    16cc:      	fmul.4s	v19, v2, v2
    16d0:      	dup.2d	v23, x14
    16d4:      	mov.16b	v24, v23
    16d8:      	mov.16b	v25, v23
    16dc:      	mov.16b	v26, v23
    16e0:      	adrp	x4, 0x1000 <ltmp0+0x1000>
    16e4:      	mov	x16, x5
    16e8:      	adrp	x6, 0x1000 <ltmp0+0x1000>
    16ec:      	adrp	x7, 0x1000 <ltmp0+0x1000>
    16f0:      	mov	x19, x20
    16f4:      	adrp	x21, 0x1000 <ltmp0+0x1000>
    16f8:      	adrp	x22, 0x1000 <ltmp0+0x1000>
    16fc:      	adrp	x23, 0x1000 <ltmp0+0x1000>
    1700:      	adrp	x24, 0x1000 <ltmp0+0x1000>
    1704:      	adrp	x26, 0x1000 <ltmp0+0x1000>
    1708:      	mov	w13, #0x4               ; =4
    170c:      	adrp	x14, 0x1000 <ltmp0+0x1000>
    1710:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1714:      	adrp	x0, 0x1000 <ltmp0+0x1000>
    1718:      	shl.2d	v2, v23, #0x5
    171c:      	add.2d	v27, v1, v2
    1720:      	add.2d	v31, v27, v3
    1724:      	mov.d	x11, v31[1]
    1728:      	shl.2d	v2, v24, #0x5
    172c:      	add.2d	v28, v1, v2
    1730:      	add.2d	v8, v28, v4
    1734:      	mov.d	x12, v8[1]
    1738:      	ldr	q2, [x1]
    173c:      	shl.2d	v5, v25, #0x5
    1740:      	add.2d	v29, v1, v5
    1744:      	add.2d	v9, v29, v2
    1748:      	mov.d	x9, v9[1]
    174c:      	ldr	q5, [x6]
    1750:      	shl.2d	v30, v26, #0x5
    1754:      	add.2d	v30, v1, v30
    1758:      	add.2d	v10, v30, v5
    175c:      	mov.d	x28, v10[1]
    1760:      	fmov	x3, d31
    1764:      	ldr	s31, [x3]
    1768:      	fmov	x3, d8
    176c:      	fmov	x17, d9
    1770:      	ld1.s	{ v31 }[1], [x11]
    1774:      	fmov	x11, d10
    1778:      	ld1.s	{ v31 }[2], [x3]
    177c:      	ld1.s	{ v31 }[3], [x12]
    1780:      	ldr	s8, [x17]
    1784:      	ld1.s	{ v8 }[1], [x9]
    1788:      	ld1.s	{ v8 }[2], [x11]
    178c:      	ld1.s	{ v8 }[3], [x28]
    1790:      	fmul.4s	v8, v8, v8
    1794:      	fmul.4s	v31, v31, v31
    1798:      	fadd.4s	v22, v22, v31
    179c:      	fadd.4s	v6, v6, v8
    17a0:      	ldr	q31, [x4]
    17a4:      	ldr	q8, [x16]
    17a8:      	ldr	q9, [x7]
    17ac:      	ldr	q10, [x19]
    17b0:      	add.2d	v10, v30, v10
    17b4:      	add.2d	v9, v29, v9
    17b8:      	add.2d	v8, v28, v8
    17bc:      	add.2d	v31, v27, v31
    17c0:      	mov.d	x9, v31[1]
    17c4:      	fmov	x11, d31
    17c8:      	mov.d	x12, v8[1]
    17cc:      	fmov	x17, d8
    17d0:      	mov.d	x3, v9[1]
    17d4:      	fmov	x28, d9
    17d8:      	mov.d	x15, v10[1]
    17dc:      	ldr	s31, [x11]
    17e0:      	ld1.s	{ v31 }[1], [x9]
    17e4:      	ld1.s	{ v31 }[2], [x17]
    17e8:      	ld1.s	{ v31 }[3], [x12]
    17ec:      	fmov	x9, d10
    17f0:      	ldr	s8, [x28]
    17f4:      	ld1.s	{ v8 }[1], [x3]
    17f8:      	ld1.s	{ v8 }[2], [x9]
    17fc:      	ld1.s	{ v8 }[3], [x15]
    1800:      	fmul.4s	v8, v8, v8
    1804:      	fmul.4s	v31, v31, v31
    1808:      	fadd.4s	v7, v7, v31
    180c:      	fadd.4s	v16, v16, v8
    1810:      	ldr	q31, [x21]
    1814:      	ldr	q8, [x22]
    1818:      	ldr	q9, [x23]
    181c:      	ldr	q10, [x24]
    1820:      	add.2d	v10, v30, v10
    1824:      	add.2d	v9, v29, v9
    1828:      	add.2d	v8, v28, v8
    182c:      	add.2d	v31, v27, v31
    1830:      	mov.d	x9, v31[1]
    1834:      	mov.d	x11, v8[1]
    1838:      	fmov	x12, d31
    183c:      	fmov	x15, d8
    1840:      	mov.d	x17, v9[1]
    1844:      	mov.d	x3, v10[1]
    1848:      	fmov	x28, d9
    184c:      	ldr	s31, [x12]
    1850:      	ld1.s	{ v31 }[1], [x9]
    1854:      	ld1.s	{ v31 }[2], [x15]
    1858:      	fmov	x9, d10
    185c:      	ld1.s	{ v31 }[3], [x11]
    1860:      	ldr	s8, [x28]
    1864:      	ld1.s	{ v8 }[1], [x17]
    1868:      	ld1.s	{ v8 }[2], [x9]
    186c:      	ld1.s	{ v8 }[3], [x3]
    1870:      	fmul.4s	v8, v8, v8
    1874:      	fmul.4s	v31, v31, v31
    1878:      	fadd.4s	v18, v18, v31
    187c:      	fadd.4s	v17, v17, v8
    1880:      	ldr	q31, [x26]
    1884:      	ldr	q8, [x14]
    1888:      	ldr	q9, [x10]
    188c:      	ldr	q10, [x0]
    1890:      	add.2d	v30, v30, v10
    1894:      	add.2d	v29, v29, v9
    1898:      	add.2d	v28, v28, v8
    189c:      	add.2d	v27, v27, v31
    18a0:      	mov.d	x9, v27[1]
    18a4:      	fmov	x11, d27
    18a8:      	mov.d	x12, v28[1]
    18ac:      	fmov	x15, d28
    18b0:      	mov.d	x17, v29[1]
    18b4:      	fmov	x3, d29
    18b8:      	mov.d	x28, v30[1]
    18bc:      	ldr	s27, [x11]
    18c0:      	ld1.s	{ v27 }[1], [x9]
    18c4:      	fmov	x9, d30
    18c8:      	ld1.s	{ v27 }[2], [x15]
    18cc:      	ld1.s	{ v27 }[3], [x12]
    18d0:      	ldr	s28, [x3]
    18d4:      	ld1.s	{ v28 }[1], [x17]
    18d8:      	ld1.s	{ v28 }[2], [x9]
    18dc:      	ld1.s	{ v28 }[3], [x28]
    18e0:      	fmul.4s	v28, v28, v28
    18e4:      	fmul.4s	v27, v27, v27
    18e8:      	fadd.4s	v19, v19, v27
    18ec:      	fadd.4s	v20, v20, v28
    18f0:      	dup.2d	v27, x13
    18f4:      	add.2d	v25, v25, v27
    18f8:      	add.2d	v24, v24, v27
    18fc:      	add.2d	v26, v26, v27
    1900:      	add.2d	v23, v23, v27
    1904:      	fmov	x9, d23
    1908:      	cmp	x9, #0xc0
    190c:      	b.lt	0x1718 <ltmp0+0x1718>
    1910:      	mov	x12, #0x0               ; =0
    1914:      	movi.2d	v23, #0000000000000000
    1918:      	movi.2d	v24, #0000000000000000
    191c:      	movi.2d	v25, #0000000000000000
    1920:      	movi.2d	v26, #0000000000000000
    1924:      	add	x9, x27, x12, lsl #5
    1928:      	ldp	q28, q27, [x9]
    192c:      	shl.2d	v29, v23, #0x5
    1930:      	shl.2d	v30, v24, #0x5
    1934:      	shl.2d	v31, v25, #0x5
    1938:      	shl.2d	v8, v26, #0x5
    193c:      	add.2d	v8, v8, v5
    1940:      	add.2d	v8, v0, v8
    1944:      	add.2d	v31, v31, v2
    1948:      	add.2d	v30, v30, v4
    194c:      	add.2d	v29, v29, v3
    1950:      	add.2d	v29, v0, v29
    1954:      	mov.d	x9, v29[1]
    1958:      	fmov	x11, d29
    195c:      	str	s28, [x11]
    1960:      	st1.s	{ v28 }[1], [x9]
    1964:      	add.2d	v29, v0, v30
    1968:      	mov.d	x9, v29[1]
    196c:      	fmov	x11, d29
    1970:      	st1.s	{ v28 }[2], [x11]
    1974:      	add.2d	v29, v0, v31
    1978:      	st1.s	{ v28 }[3], [x9]
    197c:      	mov.d	x9, v29[1]
    1980:      	fmov	x11, d29
    1984:      	str	s27, [x11]
    1988:      	st1.s	{ v27 }[1], [x9]
    198c:      	mov.d	x9, v8[1]
    1990:      	fmov	x11, d8
    1994:      	st1.s	{ v27 }[2], [x11]
    1998:      	st1.s	{ v27 }[3], [x9]
    199c:      	dup.2d	v27, x25
    19a0:      	add.2d	v25, v25, v27
    19a4:      	add.2d	v24, v24, v27
    19a8:      	add.2d	v26, v26, v27
    19ac:      	add.2d	v23, v23, v27
    19b0:      	fmov	x12, d23
    19b4:      	cmp	x12, #0xc0
    19b8:      	b.lt	0x1924 <ltmp0+0x1924>
    19bc:      	mov	x12, #0x0               ; =0
    19c0:      	fmul.4s	v21, v21, v21
    19c4:      	fadd.4s	v23, v21, v22
    19c8:      	mov.d	v23[1], v22[1]
    19cc:      	ldr	x10, [sp, #0x280]
    19d0:      	add	x9, x10, #0x4
    19d4:      	ldr	s21, [x10]
    19d8:      	ld1.s	{ v21 }[1], [x9]
    19dc:      	fadd.4s	v6, v16, v6
    19e0:      	fadd.4s	v7, v7, v23
    19e4:      	fadd.4s	v7, v18, v7
    19e8:      	fadd.4s	v6, v17, v6
    19ec:      	fadd.4s	v6, v20, v6
    19f0:      	fadd.4s	v7, v19, v7
    19f4:      	rev64.4s	v16, v7
    19f8:      	rev64.4s	v17, v6
    19fc:      	fadd.4s	v6, v6, v17
    1a00:      	fadd.4s	v7, v7, v16
    1a04:      	dup.4s	v16, v7[2]
    1a08:      	dup.4s	v17, v6[2]
    1a0c:      	fadd.4s	v6, v6, v17
    1a10:      	fadd.4s	v7, v7, v16
    1a14:      	fadd.4s	v6, v7, v6
    1a18:      	fadd	s6, s6, s12
    1a1c:      	mov	w9, #0x4000             ; =16384
    1a20:      	movk	w9, #0x44c0, lsl #16
    1a24:      	fmov	s7, w9
    1a28:      	ldr	q16, [sp, #0x1d60]
    1a2c:      	mov.d	v21[1], v16[1]
    1a30:      	fdiv	s6, s6, s7
    1a34:      	mov	w9, #0xc5ac             ; =50604
    1a38:      	movk	w9, #0x3727, lsl #16
    1a3c:      	fmov	s7, w9
    1a40:      	fadd	s6, s6, s7
    1a44:      	fsqrt	s6, s6
    1a48:      	dup.4s	v7, v6[0]
    1a4c:      	str	q21, [sp, #0x1d60]
    1a50:      	ldr	x13, [sp, #0x290]
    1a54:      	add	x8, x13, x8
    1a58:      	movi.2d	v16, #0000000000000000
    1a5c:      	movi.2d	v17, #0000000000000000
    1a60:      	movi.2d	v18, #0000000000000000
    1a64:      	movi.2d	v19, #0000000000000000
    1a68:      	mov	x4, x5
    1a6c:      	mov	x6, x20
    1a70:      	adrp	x21, 0x1000 <ltmp0+0x1000>
    1a74:      	adrp	x22, 0x1000 <ltmp0+0x1000>
    1a78:      	add	x23, sp, #0x1, lsl #12  ; =0x1000
    1a7c:      	add	x23, x23, #0xd80
    1a80:      	mov	w14, #0x4               ; =4
    1a84:      	adrp	x24, 0x1000 <ltmp0+0x1000>
    1a88:      	shl.2d	v20, v19, #0x5
    1a8c:      	shl.2d	v22, v18, #0x5
    1a90:      	shl.2d	v23, v17, #0x5
    1a94:      	shl.2d	v24, v16, #0x5
    1a98:      	orr.16b	v24, v24, v3
    1a9c:      	orr.16b	v23, v23, v4
    1aa0:      	orr.16b	v22, v22, v2
    1aa4:      	orr.16b	v20, v20, v5
    1aa8:      	add.2d	v25, v1, v20
    1aac:      	add.2d	v26, v1, v22
    1ab0:      	add.2d	v27, v1, v23
    1ab4:      	add.2d	v28, v1, v24
    1ab8:      	mov.d	x9, v28[1]
    1abc:      	mov.d	x11, v27[1]
    1ac0:      	mov.d	x15, v26[1]
    1ac4:      	fmov	x17, d28
    1ac8:      	fmov	x3, d26
    1acc:      	mov.d	x28, v25[1]
    1ad0:      	fmov	x1, d25
    1ad4:      	ldr	s25, [x3]
    1ad8:      	ld1.s	{ v25 }[1], [x15]
    1adc:      	ld1.s	{ v25 }[2], [x1]
    1ae0:      	ld1.s	{ v25 }[3], [x28]
    1ae4:      	fmov	x15, d27
    1ae8:      	ldr	s26, [x17]
    1aec:      	ld1.s	{ v26 }[1], [x9]
    1af0:      	ld1.s	{ v26 }[2], [x15]
    1af4:      	ld1.s	{ v26 }[3], [x11]
    1af8:      	fdiv.4s	v26, v26, v7
    1afc:      	fdiv.4s	v25, v25, v7
    1b00:      	add.2d	v20, v0, v20
    1b04:      	add.2d	v22, v0, v22
    1b08:      	add.2d	v23, v0, v23
    1b0c:      	add.2d	v24, v0, v24
    1b10:      	mov.d	x9, v24[1]
    1b14:      	fmov	x11, d24
    1b18:      	mov.d	x15, v23[1]
    1b1c:      	mov.d	x17, v22[1]
    1b20:      	mov.d	x1, v20[1]
    1b24:      	fmov	x3, d23
    1b28:      	ldr	s23, [x11]
    1b2c:      	ld1.s	{ v23 }[1], [x9]
    1b30:      	ld1.s	{ v23 }[2], [x3]
    1b34:      	fmov	x9, d22
    1b38:      	ld1.s	{ v23 }[3], [x15]
    1b3c:      	ldr	s22, [x9]
    1b40:      	ld1.s	{ v22 }[1], [x17]
    1b44:      	fmov	x9, d20
    1b48:      	ld1.s	{ v22 }[2], [x9]
    1b4c:      	ld1.s	{ v22 }[3], [x1]
    1b50:      	fmul.4s	v20, v25, v22
    1b54:      	fmul.4s	v22, v26, v23
    1b58:      	add	x9, x8, x12, lsl #5
    1b5c:      	stp	q22, q20, [x9]
    1b60:      	dup.2d	v20, x25
    1b64:      	add.2d	v18, v18, v20
    1b68:      	add.2d	v17, v17, v20
    1b6c:      	add.2d	v19, v19, v20
    1b70:      	add.2d	v16, v16, v20
    1b74:      	fmov	x12, d16
    1b78:      	cmp	x12, #0xc0
    1b7c:      	b.lt	0x1a88 <ltmp0+0x1a88>
    1b80:      	dup.2s	v2, v6[0]
    1b84:      	ldr	d5, [sp, #0x3580]
    1b88:      	fdiv.2s	v2, v5, v2
    1b8c:      	fmul.2s	v2, v21, v2
    1b90:      	ldr	x8, [sp, #0x2c0]
    1b94:      	str	d2, [x13, x8]
    1b98:      	add	x2, x2, #0x1
    1b9c:      	mov	w17, #0x1808            ; =6152
    1ba0:      	add	x30, x30, x17
    1ba4:      	ldr	x8, [sp, #0x2b0]
    1ba8:      	cmp	x2, x8
    1bac:      	adrp	x1, 0x1000 <ltmp0+0x1000>
    1bb0:      	b.ne	0x1624 <ltmp0+0x1624>
    1bb4:      	ldr	x8, [sp, #0x260]
    1bb8:      	and	w8, w8, #0x7
    1bbc:      	ldr	w15, [sp, #0x15c]
    1bc0:      	adrp	x16, 0x1000 <ltmp0+0x1000>
    1bc4:      	adrp	x5, 0x1000 <ltmp0+0x1000>
    1bc8:      	adrp	x7, 0x1000 <ltmp0+0x1000>
    1bcc:      	adrp	x19, 0x1000 <ltmp0+0x1000>
    1bd0:      	adrp	x20, 0x1000 <ltmp0+0x1000>
    1bd4:      	adrp	x10, 0x1000 <ltmp0+0x1000>
    1bd8:      	ldr	w0, [sp, #0x164]
    1bdc:      	ldr	w2, [sp, #0x160]
    1be0:      	ldr	x26, [sp, #0x168]
    1be4:      	cbz	w8, 0xd0 <ltmp0+0xd0>
    1be8:      	dup.4s	v2, w8
    1bec:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1bf0:      	ldr	q5, [x8]
    1bf4:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1bf8:      	ldr	q6, [x8]
    1bfc:      	cmhi.4s	v9, v2, v6
    1c00:      	cmhi.4s	v18, v2, v5
    1c04:      	uzp1.8h	v7, v18, v9
    1c08:      	umaxv.8h	h2, v7
    1c0c:      	fmov	w8, s2
    1c10:      	tbz	w8, #0x0, 0xd0 <ltmp0+0xd0>
    1c14:      	mov	x13, #0x0               ; =0
    1c18:      	ldr	x9, [sp, #0x140]
    1c1c:      	ldr	x8, [x9]
    1c20:      	ldr	x11, [x9, #0x10]
    1c24:      	ldr	x2, [x9, #0x30]
    1c28:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1c2c:      	ldr	q2, [x9]
    1c30:      	and.16b	v2, v7, v2
    1c34:      	addv.8h	h19, v2
    1c38:      	ubfiz	w9, w26, #2, #27
    1c3c:      	ldr	x12, [sp, #0x2b0]
    1c40:      	orr	w9, w9, w12
    1c44:      	fmov	w12, s19
    1c48:      	and	w12, w12, #0xff
    1c4c:      	str	w12, [sp, #0xdc]
    1c50:      	dup.4s	v2, w9
    1c54:      	and.16b	v16, v18, v2
    1c58:      	and.16b	v6, v9, v2
    1c5c:      	ushll2.2d	v2, v6, #0x0
    1c60:      	ushll2.2d	v5, v16, #0x0
    1c64:      	ushll.2d	v6, v6, #0x0
    1c68:      	ushll.2d	v17, v16, #0x0
    1c6c:      	fmov	x9, d17
    1c70:      	umaddl	x9, w9, w17, x8
    1c74:      	b	0x1c98 <ltmp0+0x1c98>
    1c78:      	add	x12, x23, x13, lsl #5
    1c7c:      	ldp	q21, q22, [x12]
    1c80:      	bif.16b	v20, v22, v9
    1c84:      	bif.16b	v16, v21, v18
    1c88:      	stp	q16, q20, [x12]
    1c8c:      	add	x13, x13, #0x1
    1c90:      	cmp	x13, #0xc0
    1c94:      	b.eq	0x1d30 <ltmp0+0x1d30>
    1c98:      	fmov	w0, s19
    1c9c:      	add	x12, x9, x13, lsl #5
    1ca0:      	movi.2d	v16, #0000000000000000
    1ca4:      	movi.2d	v20, #0000000000000000
    1ca8:      	tbnz	w0, #0x0, 0x1cd0 <ltmp0+0x1cd0>
    1cac:      	and	w0, w0, #0xff
    1cb0:      	tbnz	w0, #0x1, 0x1cdc <ltmp0+0x1cdc>
    1cb4:      	tbnz	w0, #0x2, 0x1ce8 <ltmp0+0x1ce8>
    1cb8:      	tbnz	w0, #0x3, 0x1cf4 <ltmp0+0x1cf4>
    1cbc:      	tbnz	w0, #0x4, 0x1d00 <ltmp0+0x1d00>
    1cc0:      	tbnz	w0, #0x5, 0x1d0c <ltmp0+0x1d0c>
    1cc4:      	tbnz	w0, #0x6, 0x1d18 <ltmp0+0x1d18>
    1cc8:      	tbz	w0, #0x7, 0x1c78 <ltmp0+0x1c78>
    1ccc:      	b	0x1d24 <ltmp0+0x1d24>
    1cd0:      	ldr	s16, [x12]
    1cd4:      	and	w0, w0, #0xff
    1cd8:      	tbz	w0, #0x1, 0x1cb4 <ltmp0+0x1cb4>
    1cdc:      	add	x15, x12, #0x4
    1ce0:      	ld1.s	{ v16 }[1], [x15]
    1ce4:      	tbz	w0, #0x2, 0x1cb8 <ltmp0+0x1cb8>
    1ce8:      	add	x15, x12, #0x8
    1cec:      	ld1.s	{ v16 }[2], [x15]
    1cf0:      	tbz	w0, #0x3, 0x1cbc <ltmp0+0x1cbc>
    1cf4:      	add	x15, x12, #0xc
    1cf8:      	ld1.s	{ v16 }[3], [x15]
    1cfc:      	tbz	w0, #0x4, 0x1cc0 <ltmp0+0x1cc0>
    1d00:      	add	x15, x12, #0x10
    1d04:      	ld1.s	{ v20 }[0], [x15]
    1d08:      	tbz	w0, #0x5, 0x1cc4 <ltmp0+0x1cc4>
    1d0c:      	add	x15, x12, #0x14
    1d10:      	ld1.s	{ v20 }[1], [x15]
    1d14:      	tbz	w0, #0x6, 0x1cc8 <ltmp0+0x1cc8>
    1d18:      	add	x15, x12, #0x18
    1d1c:      	ld1.s	{ v20 }[2], [x15]
    1d20:      	tbz	w0, #0x7, 0x1c78 <ltmp0+0x1c78>
    1d24:      	add	x12, x12, #0x1c
    1d28:      	ld1.s	{ v20 }[3], [x12]
    1d2c:      	b	0x1c78 <ltmp0+0x1c78>
    1d30:      	xtn.8b	v20, v7
    1d34:      	sshll.2d	v7, v18, #0x0
    1d38:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1d3c:      	ldr	q16, [x9]
    1d40:      	and.16b	v21, v7, v16
    1d44:      	movi	d16, #0x0000000000ffff
    1d48:      	and.8b	v23, v20, v16
    1d4c:      	adrp	x9, 0x1000 <ltmp0+0x1000>
    1d50:      	ldr	d16, [x9]
    1d54:      	str	q20, [sp, #0xa0]
    1d58:      	and.8b	v16, v20, v16
    1d5c:      	addv.8b	b16, v16
    1d60:      	fmov	w13, s16
    1d64:      	umaxv.8b	b16, v23
    1d68:      	fmov	w9, s16
    1d6c:      	rbit	w12, w13
    1d70:      	clz	w12, w12
    1d74:      	tst	w9, #0x1
    1d78:      	csel	w3, w12, wzr, ne
    1d7c:      	mov	w12, #0x600             ; =1536
    1d80:      	dup.2d	v20, x12
    1d84:      	str	q21, [sp, #0x60]
    1d88:      	orr.16b	v22, v21, v20
    1d8c:      	mov	w12, #0x602             ; =1538
    1d90:      	dup.2s	v16, w12
    1d94:      	xtn.2s	v17, v17
    1d98:      	str	q22, [sp, #0xb0]
    1d9c:      	umlal.2d	v22, v17, v16
    1da0:      	mov	b21, v23[0]
    1da4:      	mov.b	v21[4], v23[1]
    1da8:      	ushll.2d	v21, v21, #0x0
    1dac:      	shl.2d	v21, v21, #0x3f
    1db0:      	cmlt.2d	v21, v21, #0
    1db4:      	str	q22, [sp, #0x110]
    1db8:      	and.16b	v21, v21, v22
    1dbc:      	movi.2d	v22, #0000000000000000
    1dc0:      	str	q22, [sp, #0x540]
    1dc4:      	str	q22, [sp, #0x530]
    1dc8:      	str	q22, [sp, #0x520]
    1dcc:      	str	q21, [sp, #0x510]
    1dd0:      	and	x12, x3, #0x7
    1dd4:      	add	x15, sp, #0x510
    1dd8:      	ldr	x12, [x15, x12, lsl #3]
    1ddc:      	sub	x12, x12, x3
    1de0:      	add	x8, x8, x12, lsl #2
    1de4:      	movi.2d	v28, #0000000000000000
    1de8:      	movi.2d	v29, #0000000000000000
    1dec:      	tbnz	w13, #0x0, 0x2f20 <ltmp0+0x2f20>
    1df0:      	tbnz	w13, #0x1, 0x2f28 <ltmp0+0x2f28>
    1df4:      	tbnz	w13, #0x2, 0x2f34 <ltmp0+0x2f34>
    1df8:      	tbnz	w13, #0x3, 0x2f40 <ltmp0+0x2f40>
    1dfc:      	tbnz	w13, #0x4, 0x2f4c <ltmp0+0x2f4c>
    1e00:      	tbnz	w13, #0x5, 0x2f58 <ltmp0+0x2f58>
    1e04:      	tbnz	w13, #0x6, 0x2f64 <ltmp0+0x2f64>
    1e08:      	tbz	w13, #0x7, 0x1e14 <ltmp0+0x1e14>
    1e0c:      	add	x8, x8, #0x1c
    1e10:      	ld1.s	{ v29 }[3], [x8]
    1e14:      	sshll.2d	v21, v9, #0x0
    1e18:      	sshll2.2d	v31, v18, #0x0
    1e1c:      	sshll2.2d	v8, v9, #0x0
    1e20:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1e24:      	ldr	q22, [x8]
    1e28:      	and.16b	v30, v8, v22
    1e2c:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1e30:      	ldr	q22, [x8]
    1e34:      	and.16b	v27, v31, v22
    1e38:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1e3c:      	ldr	q22, [x8]
    1e40:      	and.16b	v26, v21, v22
    1e44:      	and.16b	v24, v21, v1
    1e48:      	and.16b	v22, v7, v1
    1e4c:      	stp	q22, q24, [sp, #0x2b0]
    1e50:      	ldr	q22, [x16]
    1e54:      	and.16b	v24, v8, v22
    1e58:      	and.16b	v25, v31, v4
    1e5c:      	ldr	q22, [x1]
    1e60:      	and.16b	v21, v21, v22
    1e64:      	and.16b	v22, v7, v3
    1e68:      	stp	q26, q27, [sp, #0x10]
    1e6c:      	orr.16b	v26, v26, v20
    1e70:      	orr.16b	v27, v27, v20
    1e74:      	str	q30, [sp, #0x30]
    1e78:      	orr.16b	v20, v30, v20
    1e7c:      	umull.2d	v7, v17, v16
    1e80:      	str	q7, [sp, #0xc0]
    1e84:      	xtn.2s	v5, v5
    1e88:      	xtn.2s	v6, v6
    1e8c:      	xtn.2s	v2, v2
    1e90:      	stp	q26, q20, [sp, #0x80]
    1e94:      	mov.16b	v7, v20
    1e98:      	umlal.2d	v7, v2, v16
    1e9c:      	str	q27, [sp, #0x70]
    1ea0:      	mov.16b	v2, v27
    1ea4:      	umlal.2d	v2, v5, v16
    1ea8:      	stp	q2, q7, [sp, #0xf0]
    1eac:      	mov.16b	v2, v26
    1eb0:      	umlal.2d	v2, v6, v16
    1eb4:      	str	q2, [sp, #0xe0]
    1eb8:      	str	q22, [sp, #0x4d0]
    1ebc:      	str	q25, [sp, #0x4e0]
    1ec0:      	str	q21, [sp, #0x4f0]
    1ec4:      	str	q24, [sp, #0x500]
    1ec8:      	and	x8, x3, #0x7
    1ecc:      	add	x12, sp, #0x4d0
    1ed0:      	ldr	x8, [x12, x8, lsl #3]
    1ed4:      	orr	x8, x8, #0x1800
    1ed8:      	sub	x8, x8, x3, lsl #2
    1edc:      	tst	w13, #0xff
    1ee0:      	csel	x15, xzr, x8, eq
    1ee4:      	add	x8, x23, x15
    1ee8:      	ldp	q2, q5, [x8]
    1eec:      	zip2.8b	v6, v23, v0
    1ef0:      	ushll.4s	v6, v6, #0x0
    1ef4:      	shl.4s	v6, v6, #0x1f
    1ef8:      	cmlt.4s	v6, v6, #0
    1efc:      	stp	q29, q28, [sp, #0x40]
    1f00:      	bit.16b	v5, v29, v6
    1f04:      	str	q23, [sp, #0x120]
    1f08:      	zip1.8b	v6, v23, v0
    1f0c:      	ushll.4s	v6, v6, #0x0
    1f10:      	shl.4s	v6, v6, #0x1f
    1f14:      	cmlt.4s	v6, v6, #0
    1f18:      	bit.16b	v2, v28, v6
    1f1c:      	stp	q2, q5, [x8]
    1f20:      	mov	w8, #0x20               ; =32
    1f24:      	dup.2d	v2, x8
    1f28:      	orr.16b	v6, v21, v2
    1f2c:      	orr.16b	v5, v25, v2
    1f30:      	stp	q5, q6, [sp, #0x210]
    1f34:      	orr.16b	v5, v22, v2
    1f38:      	orr.16b	v2, v24, v2
    1f3c:      	stp	q2, q5, [sp, #0x1f0]
    1f40:      	mov	w8, #0x40               ; =64
    1f44:      	dup.2d	v2, x8
    1f48:      	orr.16b	v6, v21, v2
    1f4c:      	orr.16b	v5, v25, v2
    1f50:      	stp	q5, q6, [sp, #0x1d0]
    1f54:      	orr.16b	v5, v22, v2
    1f58:      	orr.16b	v2, v24, v2
    1f5c:      	stp	q2, q5, [sp, #0x1b0]
    1f60:      	mov	w8, #0x60               ; =96
    1f64:      	dup.2d	v2, x8
    1f68:      	stp	q21, q25, [sp, #0x270]
    1f6c:      	orr.16b	v6, v21, v2
    1f70:      	orr.16b	v5, v25, v2
    1f74:      	stp	q5, q6, [sp, #0x190]
    1f78:      	orr.16b	v5, v22, v2
    1f7c:      	str	q24, [sp, #0x290]
    1f80:      	orr.16b	v2, v24, v2
    1f84:      	stp	q2, q5, [sp, #0x170]
    1f88:      	ldr	q2, [sp, #0x1df0]
    1f8c:      	ldr	q5, [sp, #0x1de0]
    1f90:      	fmul.4s	v5, v5, v5
    1f94:      	fmul.4s	v2, v2, v2
    1f98:      	and.16b	v14, v9, v2
    1f9c:      	and.16b	v21, v18, v5
    1fa0:      	ldr	q2, [sp, #0x1dc0]
    1fa4:      	fmul.4s	v2, v2, v2
    1fa8:      	ldr	q5, [sp, #0x1dd0]
    1fac:      	fmul.4s	v5, v5, v5
    1fb0:      	and.16b	v24, v9, v5
    1fb4:      	and.16b	v15, v18, v2
    1fb8:      	ldr	q2, [sp, #0x1da0]
    1fbc:      	fmul.4s	v2, v2, v2
    1fc0:      	ldr	q5, [sp, #0x1db0]
    1fc4:      	fmul.4s	v5, v5, v5
    1fc8:      	and.16b	v12, v9, v5
    1fcc:      	and.16b	v13, v18, v2
    1fd0:      	str	q22, [sp, #0x260]
    1fd4:      	fmov	x8, d22
    1fd8:      	add	x8, x23, x8
    1fdc:      	ldp	q2, q5, [x8]
    1fe0:      	fmul.4s	v2, v2, v2
    1fe4:      	fmul.4s	v5, v5, v5
    1fe8:      	and.16b	v23, v9, v5
    1fec:      	and.16b	v2, v18, v2
    1ff0:      	sshll.2d	v5, v9, #0x0
    1ff4:      	dup.2d	v6, x14
    1ff8:      	and.16b	v11, v5, v6
    1ffc:      	sshll.2d	v5, v18, #0x0
    2000:      	and.16b	v20, v5, v6
    2004:      	and.16b	v16, v8, v6
    2008:      	and.16b	v17, v31, v6
    200c:      	stp	q8, q31, [sp, #0x230]
    2010:      	and.16b	v5, v8, v1
    2014:      	str	q5, [sp, #0x2a0]
    2018:      	and.16b	v8, v31, v1
    201c:      	b	0x20c0 <ltmp0+0x20c0>
    2020:      	fmul.4s	v6, v10, v10
    2024:      	fmul.4s	v5, v22, v22
    2028:      	fadd.4s	v5, v2, v5
    202c:      	fadd.4s	v27, v23, v6
    2030:      	fmul.4s	v6, v29, v29
    2034:      	fmul.4s	v7, v28, v28
    2038:      	fadd.4s	v7, v13, v7
    203c:      	fadd.4s	v6, v12, v6
    2040:      	fmul.4s	v22, v25, v25
    2044:      	fmul.4s	v25, v30, v30
    2048:      	fadd.4s	v25, v15, v25
    204c:      	fadd.4s	v22, v24, v22
    2050:      	sshll.2d	v28, v18, #0x0
    2054:      	sshll.2d	v29, v9, #0x0
    2058:      	fmul.4s	v26, v26, v26
    205c:      	fmul.4s	v30, v31, v31
    2060:      	fadd.4s	v30, v14, v30
    2064:      	fadd.4s	v26, v21, v26
    2068:      	dup.2d	v31, x14
    206c:      	ldr	q10, [sp, #0x230]
    2070:      	and.16b	v10, v10, v31
    2074:      	add.2d	v16, v16, v10
    2078:      	ldr	q10, [sp, #0x240]
    207c:      	and.16b	v10, v10, v31
    2080:      	add.2d	v17, v17, v10
    2084:      	and.16b	v29, v29, v31
    2088:      	add.2d	v11, v11, v29
    208c:      	and.16b	v28, v28, v31
    2090:      	add.2d	v20, v20, v28
    2094:      	bit.16b	v23, v27, v9
    2098:      	bit.16b	v2, v5, v18
    209c:      	bit.16b	v12, v6, v9
    20a0:      	bit.16b	v13, v7, v18
    20a4:      	bit.16b	v24, v22, v9
    20a8:      	bit.16b	v15, v25, v18
    20ac:      	bit.16b	v21, v26, v18
    20b0:      	bit.16b	v14, v30, v9
    20b4:      	fmov	x8, d20
    20b8:      	cmp	x8, #0xc0
    20bc:      	b.ge	0x24c8 <ltmp0+0x24c8>
    20c0:      	fmov	w8, s19
    20c4:      	shl.2d	v5, v20, #0x5
    20c8:      	ldr	q6, [sp, #0x260]
    20cc:      	orr.16b	v6, v5, v6
    20d0:      	ldr	q7, [sp, #0x2b0]
    20d4:      	add.2d	v6, v7, v6
    20d8:      	movi.2d	v22, #0000000000000000
    20dc:      	movi.2d	v10, #0000000000000000
    20e0:      	tbnz	w8, #0x0, 0x2298 <ltmp0+0x2298>
    20e4:      	and	w8, w8, #0xff
    20e8:      	tbnz	w8, #0x1, 0x22a8 <ltmp0+0x22a8>
    20ec:      	shl.2d	v6, v17, #0x5
    20f0:      	ldr	q7, [sp, #0x280]
    20f4:      	orr.16b	v7, v6, v7
    20f8:      	add.2d	v7, v8, v7
    20fc:      	tbnz	w8, #0x2, 0x22c4 <ltmp0+0x22c4>
    2100:      	tbnz	w8, #0x3, 0x22d0 <ltmp0+0x22d0>
    2104:      	shl.2d	v7, v11, #0x5
    2108:      	ldr	q25, [sp, #0x270]
    210c:      	orr.16b	v25, v7, v25
    2110:      	ldr	q26, [sp, #0x2c0]
    2114:      	add.2d	v25, v26, v25
    2118:      	tbnz	w8, #0x4, 0x22f0 <ltmp0+0x22f0>
    211c:      	tbnz	w8, #0x5, 0x22fc <ltmp0+0x22fc>
    2120:      	shl.2d	v27, v16, #0x5
    2124:      	ldp	q25, q26, [sp, #0x290]
    2128:      	orr.16b	v25, v27, v25
    212c:      	add.2d	v25, v26, v25
    2130:      	tbnz	w8, #0x6, 0x2318 <ltmp0+0x2318>
    2134:      	tbz	w8, #0x7, 0x2140 <ltmp0+0x2140>
    2138:      	mov.d	x8, v25[1]
    213c:      	ld1.s	{ v10 }[3], [x8]
    2140:      	fmov	w8, s19
    2144:      	ldr	q25, [sp, #0x200]
    2148:      	add.2d	v25, v25, v5
    214c:      	ldr	q26, [sp, #0x2b0]
    2150:      	add.2d	v25, v26, v25
    2154:      	movi.2d	v28, #0000000000000000
    2158:      	movi.2d	v29, #0000000000000000
    215c:      	tbnz	w8, #0x0, 0x2328 <ltmp0+0x2328>
    2160:      	and	w8, w8, #0xff
    2164:      	tbnz	w8, #0x1, 0x2338 <ltmp0+0x2338>
    2168:      	ldr	q25, [sp, #0x210]
    216c:      	add.2d	v25, v25, v6
    2170:      	add.2d	v25, v8, v25
    2174:      	tbnz	w8, #0x2, 0x2350 <ltmp0+0x2350>
    2178:      	tbnz	w8, #0x3, 0x235c <ltmp0+0x235c>
    217c:      	ldr	q25, [sp, #0x220]
    2180:      	add.2d	v25, v25, v7
    2184:      	ldr	q26, [sp, #0x2c0]
    2188:      	add.2d	v25, v26, v25
    218c:      	tbnz	w8, #0x4, 0x2378 <ltmp0+0x2378>
    2190:      	tbnz	w8, #0x5, 0x2384 <ltmp0+0x2384>
    2194:      	ldr	q25, [sp, #0x1f0]
    2198:      	add.2d	v25, v25, v27
    219c:      	ldr	q26, [sp, #0x2a0]
    21a0:      	add.2d	v25, v26, v25
    21a4:      	tbnz	w8, #0x6, 0x23a0 <ltmp0+0x23a0>
    21a8:      	tbz	w8, #0x7, 0x21b4 <ltmp0+0x21b4>
    21ac:      	mov.d	x8, v25[1]
    21b0:      	ld1.s	{ v29 }[3], [x8]
    21b4:      	fmov	w8, s19
    21b8:      	ldr	q25, [sp, #0x1c0]
    21bc:      	add.2d	v25, v25, v5
    21c0:      	ldr	q26, [sp, #0x2b0]
    21c4:      	add.2d	v26, v26, v25
    21c8:      	movi.2d	v30, #0000000000000000
    21cc:      	movi.2d	v25, #0000000000000000
    21d0:      	tbnz	w8, #0x0, 0x23b0 <ltmp0+0x23b0>
    21d4:      	and	w8, w8, #0xff
    21d8:      	tbnz	w8, #0x1, 0x23c0 <ltmp0+0x23c0>
    21dc:      	ldr	q26, [sp, #0x1d0]
    21e0:      	add.2d	v26, v26, v6
    21e4:      	add.2d	v26, v8, v26
    21e8:      	tbnz	w8, #0x2, 0x23d8 <ltmp0+0x23d8>
    21ec:      	tbnz	w8, #0x3, 0x23e4 <ltmp0+0x23e4>
    21f0:      	ldr	q26, [sp, #0x1e0]
    21f4:      	add.2d	v26, v26, v7
    21f8:      	ldr	q31, [sp, #0x2c0]
    21fc:      	add.2d	v26, v31, v26
    2200:      	tbnz	w8, #0x4, 0x2400 <ltmp0+0x2400>
    2204:      	tbnz	w8, #0x5, 0x240c <ltmp0+0x240c>
    2208:      	ldr	q26, [sp, #0x1b0]
    220c:      	add.2d	v26, v26, v27
    2210:      	ldr	q31, [sp, #0x2a0]
    2214:      	add.2d	v26, v31, v26
    2218:      	tbnz	w8, #0x6, 0x2428 <ltmp0+0x2428>
    221c:      	tbz	w8, #0x7, 0x2228 <ltmp0+0x2228>
    2220:      	mov.d	x8, v26[1]
    2224:      	ld1.s	{ v25 }[3], [x8]
    2228:      	fmov	w8, s19
    222c:      	ldr	q26, [sp, #0x180]
    2230:      	add.2d	v5, v26, v5
    2234:      	ldr	q26, [sp, #0x2b0]
    2238:      	add.2d	v5, v26, v5
    223c:      	movi.2d	v26, #0000000000000000
    2240:      	movi.2d	v31, #0000000000000000
    2244:      	tbnz	w8, #0x0, 0x2438 <ltmp0+0x2438>
    2248:      	and	w8, w8, #0xff
    224c:      	tbnz	w8, #0x1, 0x2448 <ltmp0+0x2448>
    2250:      	ldr	q5, [sp, #0x190]
    2254:      	add.2d	v5, v5, v6
    2258:      	add.2d	v5, v8, v5
    225c:      	tbnz	w8, #0x2, 0x2460 <ltmp0+0x2460>
    2260:      	tbnz	w8, #0x3, 0x246c <ltmp0+0x246c>
    2264:      	ldr	q5, [sp, #0x1a0]
    2268:      	add.2d	v5, v5, v7
    226c:      	ldr	q6, [sp, #0x2c0]
    2270:      	add.2d	v5, v6, v5
    2274:      	tbnz	w8, #0x4, 0x2488 <ltmp0+0x2488>
    2278:      	tbnz	w8, #0x5, 0x2494 <ltmp0+0x2494>
    227c:      	ldr	q5, [sp, #0x170]
    2280:      	add.2d	v5, v5, v27
    2284:      	ldr	q6, [sp, #0x2a0]
    2288:      	add.2d	v5, v6, v5
    228c:      	tbnz	w8, #0x6, 0x24b0 <ltmp0+0x24b0>
    2290:      	tbz	w8, #0x7, 0x2020 <ltmp0+0x2020>
    2294:      	b	0x24bc <ltmp0+0x24bc>
    2298:      	fmov	x12, d6
    229c:      	ldr	s22, [x12]
    22a0:      	and	w8, w8, #0xff
    22a4:      	tbz	w8, #0x1, 0x20ec <ltmp0+0x20ec>
    22a8:      	mov.d	x12, v6[1]
    22ac:      	ld1.s	{ v22 }[1], [x12]
    22b0:      	shl.2d	v6, v17, #0x5
    22b4:      	ldr	q7, [sp, #0x280]
    22b8:      	orr.16b	v7, v6, v7
    22bc:      	add.2d	v7, v8, v7
    22c0:      	tbz	w8, #0x2, 0x2100 <ltmp0+0x2100>
    22c4:      	fmov	x12, d7
    22c8:      	ld1.s	{ v22 }[2], [x12]
    22cc:      	tbz	w8, #0x3, 0x2104 <ltmp0+0x2104>
    22d0:      	mov.d	x12, v7[1]
    22d4:      	ld1.s	{ v22 }[3], [x12]
    22d8:      	shl.2d	v7, v11, #0x5
    22dc:      	ldr	q25, [sp, #0x270]
    22e0:      	orr.16b	v25, v7, v25
    22e4:      	ldr	q26, [sp, #0x2c0]
    22e8:      	add.2d	v25, v26, v25
    22ec:      	tbz	w8, #0x4, 0x211c <ltmp0+0x211c>
    22f0:      	fmov	x12, d25
    22f4:      	ld1.s	{ v10 }[0], [x12]
    22f8:      	tbz	w8, #0x5, 0x2120 <ltmp0+0x2120>
    22fc:      	mov.d	x12, v25[1]
    2300:      	ld1.s	{ v10 }[1], [x12]
    2304:      	shl.2d	v27, v16, #0x5
    2308:      	ldp	q25, q26, [sp, #0x290]
    230c:      	orr.16b	v25, v27, v25
    2310:      	add.2d	v25, v26, v25
    2314:      	tbz	w8, #0x6, 0x2134 <ltmp0+0x2134>
    2318:      	fmov	x12, d25
    231c:      	ld1.s	{ v10 }[2], [x12]
    2320:      	tbnz	w8, #0x7, 0x2138 <ltmp0+0x2138>
    2324:      	b	0x2140 <ltmp0+0x2140>
    2328:      	fmov	x12, d25
    232c:      	ldr	s28, [x12]
    2330:      	and	w8, w8, #0xff
    2334:      	tbz	w8, #0x1, 0x2168 <ltmp0+0x2168>
    2338:      	mov.d	x12, v25[1]
    233c:      	ld1.s	{ v28 }[1], [x12]
    2340:      	ldr	q25, [sp, #0x210]
    2344:      	add.2d	v25, v25, v6
    2348:      	add.2d	v25, v8, v25
    234c:      	tbz	w8, #0x2, 0x2178 <ltmp0+0x2178>
    2350:      	fmov	x12, d25
    2354:      	ld1.s	{ v28 }[2], [x12]
    2358:      	tbz	w8, #0x3, 0x217c <ltmp0+0x217c>
    235c:      	mov.d	x12, v25[1]
    2360:      	ld1.s	{ v28 }[3], [x12]
    2364:      	ldr	q25, [sp, #0x220]
    2368:      	add.2d	v25, v25, v7
    236c:      	ldr	q26, [sp, #0x2c0]
    2370:      	add.2d	v25, v26, v25
    2374:      	tbz	w8, #0x4, 0x2190 <ltmp0+0x2190>
    2378:      	fmov	x12, d25
    237c:      	ld1.s	{ v29 }[0], [x12]
    2380:      	tbz	w8, #0x5, 0x2194 <ltmp0+0x2194>
    2384:      	mov.d	x12, v25[1]
    2388:      	ld1.s	{ v29 }[1], [x12]
    238c:      	ldr	q25, [sp, #0x1f0]
    2390:      	add.2d	v25, v25, v27
    2394:      	ldr	q26, [sp, #0x2a0]
    2398:      	add.2d	v25, v26, v25
    239c:      	tbz	w8, #0x6, 0x21a8 <ltmp0+0x21a8>
    23a0:      	fmov	x12, d25
    23a4:      	ld1.s	{ v29 }[2], [x12]
    23a8:      	tbnz	w8, #0x7, 0x21ac <ltmp0+0x21ac>
    23ac:      	b	0x21b4 <ltmp0+0x21b4>
    23b0:      	fmov	x12, d26
    23b4:      	ldr	s30, [x12]
    23b8:      	and	w8, w8, #0xff
    23bc:      	tbz	w8, #0x1, 0x21dc <ltmp0+0x21dc>
    23c0:      	mov.d	x12, v26[1]
    23c4:      	ld1.s	{ v30 }[1], [x12]
    23c8:      	ldr	q26, [sp, #0x1d0]
    23cc:      	add.2d	v26, v26, v6
    23d0:      	add.2d	v26, v8, v26
    23d4:      	tbz	w8, #0x2, 0x21ec <ltmp0+0x21ec>
    23d8:      	fmov	x12, d26
    23dc:      	ld1.s	{ v30 }[2], [x12]
    23e0:      	tbz	w8, #0x3, 0x21f0 <ltmp0+0x21f0>
    23e4:      	mov.d	x12, v26[1]
    23e8:      	ld1.s	{ v30 }[3], [x12]
    23ec:      	ldr	q26, [sp, #0x1e0]
    23f0:      	add.2d	v26, v26, v7
    23f4:      	ldr	q31, [sp, #0x2c0]
    23f8:      	add.2d	v26, v31, v26
    23fc:      	tbz	w8, #0x4, 0x2204 <ltmp0+0x2204>
    2400:      	fmov	x12, d26
    2404:      	ld1.s	{ v25 }[0], [x12]
    2408:      	tbz	w8, #0x5, 0x2208 <ltmp0+0x2208>
    240c:      	mov.d	x12, v26[1]
    2410:      	ld1.s	{ v25 }[1], [x12]
    2414:      	ldr	q26, [sp, #0x1b0]
    2418:      	add.2d	v26, v26, v27
    241c:      	ldr	q31, [sp, #0x2a0]
    2420:      	add.2d	v26, v31, v26
    2424:      	tbz	w8, #0x6, 0x221c <ltmp0+0x221c>
    2428:      	fmov	x12, d26
    242c:      	ld1.s	{ v25 }[2], [x12]
    2430:      	tbnz	w8, #0x7, 0x2220 <ltmp0+0x2220>
    2434:      	b	0x2228 <ltmp0+0x2228>
    2438:      	fmov	x12, d5
    243c:      	ldr	s26, [x12]
    2440:      	and	w8, w8, #0xff
    2444:      	tbz	w8, #0x1, 0x2250 <ltmp0+0x2250>
    2448:      	mov.d	x12, v5[1]
    244c:      	ld1.s	{ v26 }[1], [x12]
    2450:      	ldr	q5, [sp, #0x190]
    2454:      	add.2d	v5, v5, v6
    2458:      	add.2d	v5, v8, v5
    245c:      	tbz	w8, #0x2, 0x2260 <ltmp0+0x2260>
    2460:      	fmov	x12, d5
    2464:      	ld1.s	{ v26 }[2], [x12]
    2468:      	tbz	w8, #0x3, 0x2264 <ltmp0+0x2264>
    246c:      	mov.d	x12, v5[1]
    2470:      	ld1.s	{ v26 }[3], [x12]
    2474:      	ldr	q5, [sp, #0x1a0]
    2478:      	add.2d	v5, v5, v7
    247c:      	ldr	q6, [sp, #0x2c0]
    2480:      	add.2d	v5, v6, v5
    2484:      	tbz	w8, #0x4, 0x2278 <ltmp0+0x2278>
    2488:      	fmov	x12, d5
    248c:      	ld1.s	{ v31 }[0], [x12]
    2490:      	tbz	w8, #0x5, 0x227c <ltmp0+0x227c>
    2494:      	mov.d	x12, v5[1]
    2498:      	ld1.s	{ v31 }[1], [x12]
    249c:      	ldr	q5, [sp, #0x170]
    24a0:      	add.2d	v5, v5, v27
    24a4:      	ldr	q6, [sp, #0x2a0]
    24a8:      	add.2d	v5, v6, v5
    24ac:      	tbz	w8, #0x6, 0x2290 <ltmp0+0x2290>
    24b0:      	fmov	x12, d5
    24b4:      	ld1.s	{ v31 }[2], [x12]
    24b8:      	tbz	w8, #0x7, 0x2020 <ltmp0+0x2020>
    24bc:      	mov.d	x8, v5[1]
    24c0:      	ld1.s	{ v31 }[3], [x8]
    24c4:      	b	0x2020 <ltmp0+0x2020>
    24c8:      	str	x2, [sp, #0x220]
    24cc:      	mov	x8, #0x0                ; =0
    24d0:      	ldr	q6, [sp, #0x230]
    24d4:      	and.16b	v7, v6, v0
    24d8:      	ldr	q6, [sp, #0x240]
    24dc:      	and.16b	v16, v6, v0
    24e0:      	sshll.2d	v6, v9, #0x0
    24e4:      	and.16b	v17, v6, v0
    24e8:      	sshll.2d	v6, v18, #0x0
    24ec:      	and.16b	v6, v6, v0
    24f0:      	dup.2d	v20, x25
    24f4:      	ushll2.2d	v22, v9, #0x0
    24f8:      	and.16b	v10, v22, v20
    24fc:      	ushll2.2d	v22, v18, #0x0
    2500:      	and.16b	v22, v22, v20
    2504:      	ushll.2d	v25, v9, #0x0
    2508:      	and.16b	v9, v25, v20
    250c:      	ushll.2d	v18, v18, #0x0
    2510:      	and.16b	v18, v18, v20
    2514:      	movi.2d	v20, #0000000000000000
    2518:      	movi.2d	v25, #0000000000000000
    251c:      	movi.2d	v28, #0000000000000000
    2520:      	movi.2d	v29, #0000000000000000
    2524:      	b	0x2544 <ltmp0+0x2544>
    2528:      	add.2d	v25, v25, v22
    252c:      	add.2d	v28, v28, v9
    2530:      	add.2d	v29, v29, v10
    2534:      	add.2d	v20, v20, v18
    2538:      	fmov	x8, d20
    253c:      	cmp	x8, #0xc0
    2540:      	b.ge	0x26ec <ltmp0+0x26ec>
    2544:      	fmov	w12, s19
    2548:      	add	x8, x11, x8, lsl #5
    254c:      	movi.2d	v11, #0000000000000000
    2550:      	movi.2d	v30, #0000000000000000
    2554:      	tbnz	w12, #0x0, 0x25e4 <ltmp0+0x25e4>
    2558:      	and	w12, w12, #0xff
    255c:      	tbnz	w12, #0x1, 0x25f0 <ltmp0+0x25f0>
    2560:      	tbnz	w12, #0x2, 0x25fc <ltmp0+0x25fc>
    2564:      	tbnz	w12, #0x3, 0x2608 <ltmp0+0x2608>
    2568:      	tbnz	w12, #0x4, 0x2614 <ltmp0+0x2614>
    256c:      	tbnz	w12, #0x5, 0x2620 <ltmp0+0x2620>
    2570:      	tbnz	w12, #0x6, 0x262c <ltmp0+0x262c>
    2574:      	tbnz	w12, #0x7, 0x2638 <ltmp0+0x2638>
    2578:      	fmov	w8, s19
    257c:      	shl.2d	v26, v20, #0x5
    2580:      	ldr	q31, [sp, #0x260]
    2584:      	orr.16b	v26, v26, v31
    2588:      	add.2d	v26, v6, v26
    258c:      	tbnz	w8, #0x0, 0x2658 <ltmp0+0x2658>
    2590:      	and	w8, w8, #0xff
    2594:      	tbnz	w8, #0x1, 0x2668 <ltmp0+0x2668>
    2598:      	shl.2d	v26, v25, #0x5
    259c:      	ldr	q31, [sp, #0x280]
    25a0:      	orr.16b	v26, v26, v31
    25a4:      	add.2d	v26, v16, v26
    25a8:      	tbnz	w8, #0x2, 0x2684 <ltmp0+0x2684>
    25ac:      	tbnz	w8, #0x3, 0x2690 <ltmp0+0x2690>
    25b0:      	shl.2d	v26, v28, #0x5
    25b4:      	ldr	q31, [sp, #0x270]
    25b8:      	orr.16b	v26, v26, v31
    25bc:      	add.2d	v26, v17, v26
    25c0:      	tbnz	w8, #0x4, 0x26ac <ltmp0+0x26ac>
    25c4:      	tbnz	w8, #0x5, 0x26b8 <ltmp0+0x26b8>
    25c8:      	shl.2d	v26, v29, #0x5
    25cc:      	ldr	q31, [sp, #0x290]
    25d0:      	orr.16b	v26, v26, v31
    25d4:      	add.2d	v26, v7, v26
    25d8:      	tbnz	w8, #0x6, 0x26d4 <ltmp0+0x26d4>
    25dc:      	tbz	w8, #0x7, 0x2528 <ltmp0+0x2528>
    25e0:      	b	0x26e0 <ltmp0+0x26e0>
    25e4:      	ldr	s11, [x8]
    25e8:      	and	w12, w12, #0xff
    25ec:      	tbz	w12, #0x1, 0x2560 <ltmp0+0x2560>
    25f0:      	add	x13, x8, #0x4
    25f4:      	ld1.s	{ v11 }[1], [x13]
    25f8:      	tbz	w12, #0x2, 0x2564 <ltmp0+0x2564>
    25fc:      	add	x13, x8, #0x8
    2600:      	ld1.s	{ v11 }[2], [x13]
    2604:      	tbz	w12, #0x3, 0x2568 <ltmp0+0x2568>
    2608:      	add	x13, x8, #0xc
    260c:      	ld1.s	{ v11 }[3], [x13]
    2610:      	tbz	w12, #0x4, 0x256c <ltmp0+0x256c>
    2614:      	add	x13, x8, #0x10
    2618:      	ld1.s	{ v30 }[0], [x13]
    261c:      	tbz	w12, #0x5, 0x2570 <ltmp0+0x2570>
    2620:      	add	x13, x8, #0x14
    2624:      	ld1.s	{ v30 }[1], [x13]
    2628:      	tbz	w12, #0x6, 0x2574 <ltmp0+0x2574>
    262c:      	add	x13, x8, #0x18
    2630:      	ld1.s	{ v30 }[2], [x13]
    2634:      	tbz	w12, #0x7, 0x2578 <ltmp0+0x2578>
    2638:      	add	x8, x8, #0x1c
    263c:      	ld1.s	{ v30 }[3], [x8]
    2640:      	fmov	w8, s19
    2644:      	shl.2d	v26, v20, #0x5
    2648:      	ldr	q31, [sp, #0x260]
    264c:      	orr.16b	v26, v26, v31
    2650:      	add.2d	v26, v6, v26
    2654:      	tbz	w8, #0x0, 0x2590 <ltmp0+0x2590>
    2658:      	fmov	x12, d26
    265c:      	str	s11, [x12]
    2660:      	and	w8, w8, #0xff
    2664:      	tbz	w8, #0x1, 0x2598 <ltmp0+0x2598>
    2668:      	mov.d	x12, v26[1]
    266c:      	st1.s	{ v11 }[1], [x12]
    2670:      	shl.2d	v26, v25, #0x5
    2674:      	ldr	q31, [sp, #0x280]
    2678:      	orr.16b	v26, v26, v31
    267c:      	add.2d	v26, v16, v26
    2680:      	tbz	w8, #0x2, 0x25ac <ltmp0+0x25ac>
    2684:      	fmov	x12, d26
    2688:      	st1.s	{ v11 }[2], [x12]
    268c:      	tbz	w8, #0x3, 0x25b0 <ltmp0+0x25b0>
    2690:      	mov.d	x12, v26[1]
    2694:      	st1.s	{ v11 }[3], [x12]
    2698:      	shl.2d	v26, v28, #0x5
    269c:      	ldr	q31, [sp, #0x270]
    26a0:      	orr.16b	v26, v26, v31
    26a4:      	add.2d	v26, v17, v26
    26a8:      	tbz	w8, #0x4, 0x25c4 <ltmp0+0x25c4>
    26ac:      	fmov	x12, d26
    26b0:      	str	s30, [x12]
    26b4:      	tbz	w8, #0x5, 0x25c8 <ltmp0+0x25c8>
    26b8:      	mov.d	x12, v26[1]
    26bc:      	st1.s	{ v30 }[1], [x12]
    26c0:      	shl.2d	v26, v29, #0x5
    26c4:      	ldr	q31, [sp, #0x290]
    26c8:      	orr.16b	v26, v26, v31
    26cc:      	add.2d	v26, v7, v26
    26d0:      	tbz	w8, #0x6, 0x25dc <ltmp0+0x25dc>
    26d4:      	fmov	x12, d26
    26d8:      	st1.s	{ v30 }[2], [x12]
    26dc:      	tbz	w8, #0x7, 0x2528 <ltmp0+0x2528>
    26e0:      	mov.d	x8, v26[1]
    26e4:      	st1.s	{ v30 }[3], [x8]
    26e8:      	b	0x2528 <ltmp0+0x2528>
    26ec:      	mov	x9, x15
    26f0:      	movi	d20, #0xffffffffffff0000
    26f4:      	ldr	q30, [sp, #0xa0]
    26f8:      	and.8b	v20, v30, v20
    26fc:      	ldp	q26, q25, [sp, #0x40]
    2700:      	fmul.4s	v25, v25, v25
    2704:      	fmul.4s	v26, v26, v26
    2708:      	fadd.4s	v23, v26, v23
    270c:      	fadd.4s	v2, v25, v2
    2710:      	ldr	q26, [sp, #0x120]
    2714:      	zip1.8b	v25, v26, v0
    2718:      	ushll.4s	v25, v25, #0x0
    271c:      	shl.4s	v25, v25, #0x1f
    2720:      	cmlt.4s	v25, v25, #0
    2724:      	and.16b	v2, v25, v2
    2728:      	zip2.8b	v25, v26, v0
    272c:      	ushll.4s	v25, v25, #0x0
    2730:      	shl.4s	v25, v25, #0x1f
    2734:      	cmlt.4s	v25, v25, #0
    2738:      	and.16b	v23, v25, v23
    273c:      	zip2.8b	v25, v20, v0
    2740:      	ushll.4s	v25, v25, #0x0
    2744:      	shl.4s	v25, v25, #0x1f
    2748:      	cmlt.4s	v25, v25, #0
    274c:      	bit.16b	v23, v27, v25
    2750:      	zip1.8b	v20, v20, v0
    2754:      	ushll.4s	v20, v20, #0x0
    2758:      	shl.4s	v20, v20, #0x1f
    275c:      	cmlt.4s	v20, v20, #0
    2760:      	bit.16b	v2, v5, v20
    2764:      	fadd.4s	v2, v13, v2
    2768:      	mov.16b	v13, v26
    276c:      	fadd.4s	v5, v12, v23
    2770:      	fadd.4s	v20, v24, v5
    2774:      	fadd.4s	v2, v15, v2
    2778:      	fadd.4s	v5, v21, v2
    277c:      	fadd.4s	v20, v14, v20
    2780:      	ldr	q2, [sp, #0x60]
    2784:      	ldp	q23, q21, [sp, #0x20]
    2788:      	uzp1.4s	v2, v2, v23
    278c:      	ldr	q23, [sp, #0x10]
    2790:      	uzp1.4s	v21, v23, v21
    2794:      	movi.4s	v24, #0x1
    2798:      	eor.16b	v23, v2, v24
    279c:      	mov.s	w12, v23[1]
    27a0:      	mov.s	w15, v23[2]
    27a4:      	eor.16b	v26, v21, v24
    27a8:      	mov.s	w17, v23[3]
    27ac:      	fmov	w8, s23
    27b0:      	add	x13, sp, #0x318
    27b4:      	bfxil	x13, x8, #0, #3
    27b8:      	str	d30, [sp, #0x318]
    27bc:      	ldrb	w13, [x13]
    27c0:      	and	x0, x8, #0x7
    27c4:      	umov.b	w8, v30[0]
    27c8:      	str	q20, [sp, #0x430]
    27cc:      	str	q5, [sp, #0x420]
    27d0:      	add	x1, sp, #0x420
    27d4:      	ldr	s23, [x1, x0, lsl #2]
    27d8:      	ands	w0, w8, #0x1
    27dc:      	tst	w0, w13
    27e0:      	movi	d12, #0000000000000000
    27e4:      	fcsel	s23, s23, s12, ne
    27e8:      	add	x13, sp, #0x318
    27ec:      	bfxil	x13, x12, #0, #3
    27f0:      	ldrb	w1, [x13]
    27f4:      	and	x12, x12, #0x7
    27f8:      	umov.b	w13, v30[1]
    27fc:      	str	q20, [sp, #0x410]
    2800:      	str	q5, [sp, #0x400]
    2804:      	add	x2, sp, #0x400
    2808:      	ldr	s24, [x2, x12, lsl #2]
    280c:      	ands	w12, w13, #0x1
    2810:      	tst	w12, w1
    2814:      	fcsel	s24, s24, s12, ne
    2818:      	add	x12, sp, #0x318
    281c:      	bfxil	x12, x15, #0, #3
    2820:      	ldrb	w12, [x12]
    2824:      	umov.b	w2, v30[2]
    2828:      	and	x15, x15, #0x7
    282c:      	stp	q5, q20, [sp, #0x3e0]
    2830:      	add	x1, sp, #0x3e0
    2834:      	ldr	s25, [x1, x15, lsl #2]
    2838:      	ands	w15, w2, #0x1
    283c:      	tst	w15, w12
    2840:      	fcsel	s25, s25, s12, ne
    2844:      	add	x12, sp, #0x318
    2848:      	bfxil	x12, x17, #0, #3
    284c:      	ldrb	w15, [x12]
    2850:      	and	x17, x17, #0x7
    2854:      	umov.b	w12, v30[3]
    2858:      	stp	q5, q20, [sp, #0x3c0]
    285c:      	add	x1, sp, #0x3c0
    2860:      	ldr	s27, [x1, x17, lsl #2]
    2864:      	ands	w17, w12, #0x1
    2868:      	tst	w17, w15
    286c:      	mov.s	w15, v26[1]
    2870:      	mov.s	w17, v26[2]
    2874:      	fcsel	s27, s27, s12, ne
    2878:      	mov.s	w1, v26[3]
    287c:      	fmov	w26, s26
    2880:      	and	x27, x26, #0x7
    2884:      	add	x28, sp, #0x318
    2888:      	bfxil	x28, x26, #0, #3
    288c:      	ldrb	w28, [x28]
    2890:      	umov.b	w26, v30[4]
    2894:      	and	w28, w26, w28
    2898:      	str	q20, [sp, #0x4b0]
    289c:      	str	q5, [sp, #0x4a0]
    28a0:      	add	x30, sp, #0x4a0
    28a4:      	ldr	s26, [x30, x27, lsl #2]
    28a8:      	tst	w28, #0x1
    28ac:      	fcsel	s26, s26, s12, ne
    28b0:      	add	x27, sp, #0x318
    28b4:      	bfxil	x27, x15, #0, #3
    28b8:      	ldrb	w28, [x27]
    28bc:      	and	x15, x15, #0x7
    28c0:      	umov.b	w27, v30[5]
    28c4:      	str	q20, [sp, #0x490]
    28c8:      	str	q5, [sp, #0x480]
    28cc:      	add	x30, sp, #0x480
    28d0:      	ldr	s28, [x30, x15, lsl #2]
    28d4:      	ands	w15, w27, #0x1
    28d8:      	tst	w15, w28
    28dc:      	fcsel	s28, s28, s12, ne
    28e0:      	add	x15, sp, #0x318
    28e4:      	bfxil	x15, x17, #0, #3
    28e8:      	ldrb	w15, [x15]
    28ec:      	and	x17, x17, #0x7
    28f0:      	umov.b	w28, v30[6]
    28f4:      	str	q20, [sp, #0x470]
    28f8:      	str	q5, [sp, #0x460]
    28fc:      	add	x30, sp, #0x460
    2900:      	ldr	s29, [x30, x17, lsl #2]
    2904:      	ands	w17, w28, #0x1
    2908:      	tst	w17, w15
    290c:      	fcsel	s29, s29, s12, ne
    2910:      	add	x15, sp, #0x318
    2914:      	bfxil	x15, x1, #0, #3
    2918:      	ldrb	w15, [x15]
    291c:      	umov.b	w30, v30[7]
    2920:      	and	x17, x1, #0x7
    2924:      	str	q20, [sp, #0x450]
    2928:      	str	q5, [sp, #0x440]
    292c:      	add	x1, sp, #0x440
    2930:      	ldr	s30, [x1, x17, lsl #2]
    2934:      	ands	w17, w30, #0x1
    2938:      	tst	w17, w15
    293c:      	fcsel	s30, s30, s12, ne
    2940:      	mov.s	v26[1], v28[0]
    2944:      	mov.s	v26[2], v29[0]
    2948:      	mov.s	v26[3], v30[0]
    294c:      	mov.s	v23[1], v24[0]
    2950:      	mov.s	v23[2], v25[0]
    2954:      	mov.s	v23[3], v27[0]
    2958:      	fadd.4s	v5, v5, v23
    295c:      	fadd.4s	v20, v20, v26
    2960:      	movi.4s	v23, #0x2
    2964:      	eor.16b	v21, v21, v23
    2968:      	eor.16b	v2, v2, v23
    296c:      	fmov	w15, s2
    2970:      	add	x17, sp, #0x318
    2974:      	bfxil	x17, x15, #0, #3
    2978:      	ldrb	w17, [x17]
    297c:      	and	x15, x15, #0x7
    2980:      	stp	q5, q20, [sp, #0x3a0]
    2984:      	add	x1, sp, #0x3a0
    2988:      	ldr	s2, [x1, x15, lsl #2]
    298c:      	tst	w0, w17
    2990:      	fcsel	s2, s2, s12, ne
    2994:      	fmov	w15, s21
    2998:      	and	x17, x15, #0x7
    299c:      	add	x1, sp, #0x318
    29a0:      	bfxil	x1, x15, #0, #3
    29a4:      	ldrb	w15, [x1]
    29a8:      	and	w15, w26, w15
    29ac:      	stp	q5, q20, [sp, #0x380]
    29b0:      	add	x1, sp, #0x380
    29b4:      	ldr	s21, [x1, x17, lsl #2]
    29b8:      	tst	w15, #0x1
    29bc:      	fcsel	s21, s21, s12, ne
    29c0:      	fadd.4s	v20, v20, v21
    29c4:      	tst	w0, w26
    29c8:      	fcsel	s20, s20, s12, ne
    29cc:      	ands	w8, w8, #0x1
    29d0:      	fadd.4s	v2, v5, v2
    29d4:      	fadd	s2, s2, s20
    29d8:      	fcsel	s5, s2, s12, ne
    29dc:      	tst	w13, #0x1
    29e0:      	fcsel	s20, s5, s12, ne
    29e4:      	tst	w2, #0x1
    29e8:      	fcsel	s21, s5, s12, ne
    29ec:      	tst	w12, #0x1
    29f0:      	fcsel	s23, s5, s12, ne
    29f4:      	tst	w8, w26
    29f8:      	fcsel	s24, s2, s12, ne
    29fc:      	tst	w27, #0x1
    2a00:      	fcsel	s25, s5, s12, ne
    2a04:      	tst	w28, #0x1
    2a08:      	fcsel	s26, s5, s12, ne
    2a0c:      	tst	w30, #0x1
    2a10:      	adrp	x8, 0x2000 <ltmp0+0x2000>
    2a14:      	ldr	d2, [x8]
    2a18:      	shl.8b	v27, v13, #0x7
    2a1c:      	cmlt.8b	v27, v27, #0
    2a20:      	and.8b	v2, v27, v2
    2a24:      	addv.8b	b2, v2
    2a28:      	fmov	w8, s2
    2a2c:      	fcsel	s27, s5, s12, ne
    2a30:      	mov.s	v5[1], v20[0]
    2a34:      	mov.s	v5[2], v21[0]
    2a38:      	mov.s	v5[3], v23[0]
    2a3c:      	mov.s	v24[1], v25[0]
    2a40:      	mov.s	v24[2], v26[0]
    2a44:      	mov.s	v24[3], v27[0]
    2a48:      	ldr	w12, [sp, #0xdc]
    2a4c:      	rbit	w12, w12
    2a50:      	clz	w12, w12
    2a54:      	stp	q5, q24, [sp, #0x360]
    2a58:      	and	x12, x12, #0x7
    2a5c:      	add	x13, sp, #0x360
    2a60:      	ldr	s5, [x13, x12, lsl #2]
    2a64:      	mov	b20, v13[0]
    2a68:      	mov.b	v20[4], v13[1]
    2a6c:      	ushll.2d	v20, v20, #0x0
    2a70:      	shl.2d	v20, v20, #0x3f
    2a74:      	cmlt.2d	v20, v20, #0
    2a78:      	mov	b21, v13[2]
    2a7c:      	mov.b	v21[4], v13[3]
    2a80:      	ldr	q23, [sp, #0xb0]
    2a84:      	and.16b	v20, v20, v23
    2a88:      	ushll.2d	v21, v21, #0x0
    2a8c:      	shl.2d	v21, v21, #0x3f
    2a90:      	cmlt.2d	v21, v21, #0
    2a94:      	ldp	q23, q24, [sp, #0x70]
    2a98:      	and.16b	v21, v21, v23
    2a9c:      	mov	b23, v13[4]
    2aa0:      	mov.b	v23[4], v13[5]
    2aa4:      	ushll.2d	v23, v23, #0x0
    2aa8:      	shl.2d	v23, v23, #0x3f
    2aac:      	cmlt.2d	v23, v23, #0
    2ab0:      	and.16b	v23, v23, v24
    2ab4:      	mov	b24, v13[6]
    2ab8:      	mov.b	v24[4], v13[7]
    2abc:      	ushll.2d	v24, v24, #0x0
    2ac0:      	shl.2d	v24, v24, #0x3f
    2ac4:      	cmlt.2d	v24, v24, #0
    2ac8:      	ldr	q25, [sp, #0x90]
    2acc:      	and.16b	v24, v24, v25
    2ad0:      	stp	q23, q24, [sp, #0x340]
    2ad4:      	stp	q20, q21, [sp, #0x320]
    2ad8:      	mov	x28, x3
    2adc:      	and	x12, x3, #0x7
    2ae0:      	add	x13, sp, #0x320
    2ae4:      	ldr	x12, [x13, x12, lsl #3]
    2ae8:      	sub	x12, x12, x3
    2aec:      	add	x11, x11, x12, lsl #2
    2af0:      	movi.2d	v20, #0000000000000000
    2af4:      	movi.2d	v21, #0000000000000000
    2af8:      	tbz	w8, #0x0, 0x2b00 <ltmp0+0x2b00>
    2afc:      	ldr	s20, [x11]
    2b00:      	ldr	x3, [sp, #0x220]
    2b04:      	tbz	w8, #0x1, 0x2b10 <ltmp0+0x2b10>
    2b08:      	add	x12, x11, #0x4
    2b0c:      	ld1.s	{ v20 }[1], [x12]
    2b10:      	ldr	w15, [sp, #0x15c]
    2b14:      	mov	w17, #0x1808            ; =6152
    2b18:      	adrp	x1, 0x2000 <ltmp0+0x2000>
    2b1c:      	ldr	w0, [sp, #0x164]
    2b20:      	ldr	w2, [sp, #0x160]
    2b24:      	ldr	x26, [sp, #0x168]
    2b28:      	tbnz	w8, #0x2, 0x2f74 <ltmp0+0x2f74>
    2b2c:      	tbnz	w8, #0x3, 0x2f80 <ltmp0+0x2f80>
    2b30:      	tbnz	w8, #0x4, 0x2f8c <ltmp0+0x2f8c>
    2b34:      	tbnz	w8, #0x5, 0x2f98 <ltmp0+0x2f98>
    2b38:      	tbnz	w8, #0x6, 0x2fa4 <ltmp0+0x2fa4>
    2b3c:      	tbz	w8, #0x7, 0x2b48 <ltmp0+0x2b48>
    2b40:      	add	x8, x11, #0x1c
    2b44:      	ld1.s	{ v21 }[3], [x8]
    2b48:      	mov	x11, #0x0               ; =0
    2b4c:      	fadd	s5, s5, s12
    2b50:      	mov	w8, #0x4000             ; =16384
    2b54:      	movk	w8, #0x44c0, lsl #16
    2b58:      	fmov	s23, w8
    2b5c:      	fdiv	s5, s5, s23
    2b60:      	add	x8, sp, #0x560
    2b64:      	add	x8, x8, x9
    2b68:      	ldp	q23, q24, [x8]
    2b6c:      	zip2.8b	v25, v13, v0
    2b70:      	ushll.4s	v25, v25, #0x0
    2b74:      	shl.4s	v25, v25, #0x1f
    2b78:      	cmlt.4s	v25, v25, #0
    2b7c:      	bif.16b	v21, v24, v25
    2b80:      	zip1.8b	v24, v13, v0
    2b84:      	ushll.4s	v24, v24, #0x0
    2b88:      	shl.4s	v24, v24, #0x1f
    2b8c:      	cmlt.4s	v24, v24, #0
    2b90:      	bif.16b	v20, v23, v24
    2b94:      	stp	q20, q21, [x8]
    2b98:      	mov	w8, #0xc5ac             ; =50604
    2b9c:      	movk	w8, #0x3727, lsl #16
    2ba0:      	fmov	s20, w8
    2ba4:      	fadd	s5, s5, s20
    2ba8:      	fsqrt	s5, s5
    2bac:      	dup.4s	v5, v5[0]
    2bb0:      	ldr	q20, [sp, #0xc0]
    2bb4:      	fmov	x8, d20
    2bb8:      	add	x8, x3, x8, lsl #2
    2bbc:      	movi.2d	v20, #0000000000000000
    2bc0:      	movi.2d	v21, #0000000000000000
    2bc4:      	movi.2d	v23, #0000000000000000
    2bc8:      	movi.2d	v24, #0000000000000000
    2bcc:      	b	0x2bec <ltmp0+0x2bec>
    2bd0:      	add.2d	v21, v21, v22
    2bd4:      	add.2d	v23, v23, v9
    2bd8:      	add.2d	v24, v24, v10
    2bdc:      	add.2d	v20, v20, v18
    2be0:      	fmov	x11, d20
    2be4:      	cmp	x11, #0xc0
    2be8:      	b.ge	0x2e78 <ltmp0+0x2e78>
    2bec:      	fmov	w12, s19
    2bf0:      	shl.2d	v25, v20, #0x5
    2bf4:      	ldr	q26, [sp, #0x260]
    2bf8:      	orr.16b	v26, v25, v26
    2bfc:      	ldr	q25, [sp, #0x2b0]
    2c00:      	add.2d	v28, v25, v26
    2c04:      	movi.2d	v25, #0000000000000000
    2c08:      	movi.2d	v27, #0000000000000000
    2c0c:      	tbnz	w12, #0x0, 0x2ce8 <ltmp0+0x2ce8>
    2c10:      	and	w12, w12, #0xff
    2c14:      	tbnz	w12, #0x1, 0x2cf8 <ltmp0+0x2cf8>
    2c18:      	shl.2d	v28, v21, #0x5
    2c1c:      	ldr	q29, [sp, #0x280]
    2c20:      	orr.16b	v29, v28, v29
    2c24:      	add.2d	v28, v8, v29
    2c28:      	tbnz	w12, #0x2, 0x2d14 <ltmp0+0x2d14>
    2c2c:      	tbnz	w12, #0x3, 0x2d20 <ltmp0+0x2d20>
    2c30:      	shl.2d	v28, v23, #0x5
    2c34:      	ldr	q30, [sp, #0x270]
    2c38:      	orr.16b	v30, v28, v30
    2c3c:      	ldr	q28, [sp, #0x2c0]
    2c40:      	add.2d	v28, v28, v30
    2c44:      	tbnz	w12, #0x4, 0x2d40 <ltmp0+0x2d40>
    2c48:      	tbnz	w12, #0x5, 0x2d4c <ltmp0+0x2d4c>
    2c4c:      	shl.2d	v28, v24, #0x5
    2c50:      	ldr	q31, [sp, #0x290]
    2c54:      	orr.16b	v31, v28, v31
    2c58:      	ldr	q28, [sp, #0x2a0]
    2c5c:      	add.2d	v28, v28, v31
    2c60:      	tbnz	w12, #0x6, 0x2d6c <ltmp0+0x2d6c>
    2c64:      	tbnz	w12, #0x7, 0x2d78 <ltmp0+0x2d78>
    2c68:      	fmov	w12, s19
    2c6c:      	add.2d	v11, v6, v26
    2c70:      	movi.2d	v26, #0000000000000000
    2c74:      	movi.2d	v28, #0000000000000000
    2c78:      	tbnz	w12, #0x0, 0x2d94 <ltmp0+0x2d94>
    2c7c:      	and	w12, w12, #0xff
    2c80:      	tbnz	w12, #0x1, 0x2da4 <ltmp0+0x2da4>
    2c84:      	add.2d	v29, v16, v29
    2c88:      	tbnz	w12, #0x2, 0x2db4 <ltmp0+0x2db4>
    2c8c:      	tbnz	w12, #0x3, 0x2dc0 <ltmp0+0x2dc0>
    2c90:      	add.2d	v29, v17, v30
    2c94:      	tbnz	w12, #0x4, 0x2dd0 <ltmp0+0x2dd0>
    2c98:      	tbnz	w12, #0x5, 0x2ddc <ltmp0+0x2ddc>
    2c9c:      	add.2d	v29, v7, v31
    2ca0:      	tbnz	w12, #0x6, 0x2dec <ltmp0+0x2dec>
    2ca4:      	tbnz	w12, #0x7, 0x2df8 <ltmp0+0x2df8>
    2ca8:      	fdiv.4s	v25, v25, v5
    2cac:      	fmov	w12, s19
    2cb0:      	fmul.4s	v25, v25, v26
    2cb4:      	add	x11, x8, x11, lsl #5
    2cb8:      	tbnz	w12, #0x0, 0x2e14 <ltmp0+0x2e14>
    2cbc:      	and	w12, w12, #0xff
    2cc0:      	tbnz	w12, #0x1, 0x2e20 <ltmp0+0x2e20>
    2cc4:      	tbnz	w12, #0x2, 0x2e2c <ltmp0+0x2e2c>
    2cc8:      	tbnz	w12, #0x3, 0x2e38 <ltmp0+0x2e38>
    2ccc:      	fdiv.4s	v25, v27, v5
    2cd0:      	fmul.4s	v25, v25, v28
    2cd4:      	tbnz	w12, #0x4, 0x2e4c <ltmp0+0x2e4c>
    2cd8:      	tbnz	w12, #0x5, 0x2e54 <ltmp0+0x2e54>
    2cdc:      	tbnz	w12, #0x6, 0x2e60 <ltmp0+0x2e60>
    2ce0:      	tbz	w12, #0x7, 0x2bd0 <ltmp0+0x2bd0>
    2ce4:      	b	0x2e6c <ltmp0+0x2e6c>
    2ce8:      	fmov	x13, d28
    2cec:      	ldr	s25, [x13]
    2cf0:      	and	w12, w12, #0xff
    2cf4:      	tbz	w12, #0x1, 0x2c18 <ltmp0+0x2c18>
    2cf8:      	mov.d	x13, v28[1]
    2cfc:      	ld1.s	{ v25 }[1], [x13]
    2d00:      	shl.2d	v28, v21, #0x5
    2d04:      	ldr	q29, [sp, #0x280]
    2d08:      	orr.16b	v29, v28, v29
    2d0c:      	add.2d	v28, v8, v29
    2d10:      	tbz	w12, #0x2, 0x2c2c <ltmp0+0x2c2c>
    2d14:      	fmov	x13, d28
    2d18:      	ld1.s	{ v25 }[2], [x13]
    2d1c:      	tbz	w12, #0x3, 0x2c30 <ltmp0+0x2c30>
    2d20:      	mov.d	x13, v28[1]
    2d24:      	ld1.s	{ v25 }[3], [x13]
    2d28:      	shl.2d	v28, v23, #0x5
    2d2c:      	ldr	q30, [sp, #0x270]
    2d30:      	orr.16b	v30, v28, v30
    2d34:      	ldr	q28, [sp, #0x2c0]
    2d38:      	add.2d	v28, v28, v30
    2d3c:      	tbz	w12, #0x4, 0x2c48 <ltmp0+0x2c48>
    2d40:      	fmov	x13, d28
    2d44:      	ld1.s	{ v27 }[0], [x13]
    2d48:      	tbz	w12, #0x5, 0x2c4c <ltmp0+0x2c4c>
    2d4c:      	mov.d	x13, v28[1]
    2d50:      	ld1.s	{ v27 }[1], [x13]
    2d54:      	shl.2d	v28, v24, #0x5
    2d58:      	ldr	q31, [sp, #0x290]
    2d5c:      	orr.16b	v31, v28, v31
    2d60:      	ldr	q28, [sp, #0x2a0]
    2d64:      	add.2d	v28, v28, v31
    2d68:      	tbz	w12, #0x6, 0x2c64 <ltmp0+0x2c64>
    2d6c:      	fmov	x13, d28
    2d70:      	ld1.s	{ v27 }[2], [x13]
    2d74:      	tbz	w12, #0x7, 0x2c68 <ltmp0+0x2c68>
    2d78:      	mov.d	x12, v28[1]
    2d7c:      	ld1.s	{ v27 }[3], [x12]
    2d80:      	fmov	w12, s19
    2d84:      	add.2d	v11, v6, v26
    2d88:      	movi.2d	v26, #0000000000000000
    2d8c:      	movi.2d	v28, #0000000000000000
    2d90:      	tbz	w12, #0x0, 0x2c7c <ltmp0+0x2c7c>
    2d94:      	fmov	x13, d11
    2d98:      	ldr	s26, [x13]
    2d9c:      	and	w12, w12, #0xff
    2da0:      	tbz	w12, #0x1, 0x2c84 <ltmp0+0x2c84>
    2da4:      	mov.d	x13, v11[1]
    2da8:      	ld1.s	{ v26 }[1], [x13]
    2dac:      	add.2d	v29, v16, v29
    2db0:      	tbz	w12, #0x2, 0x2c8c <ltmp0+0x2c8c>
    2db4:      	fmov	x13, d29
    2db8:      	ld1.s	{ v26 }[2], [x13]
    2dbc:      	tbz	w12, #0x3, 0x2c90 <ltmp0+0x2c90>
    2dc0:      	mov.d	x13, v29[1]
    2dc4:      	ld1.s	{ v26 }[3], [x13]
    2dc8:      	add.2d	v29, v17, v30
    2dcc:      	tbz	w12, #0x4, 0x2c98 <ltmp0+0x2c98>
    2dd0:      	fmov	x13, d29
    2dd4:      	ld1.s	{ v28 }[0], [x13]
    2dd8:      	tbz	w12, #0x5, 0x2c9c <ltmp0+0x2c9c>
    2ddc:      	mov.d	x13, v29[1]
    2de0:      	ld1.s	{ v28 }[1], [x13]
    2de4:      	add.2d	v29, v7, v31
    2de8:      	tbz	w12, #0x6, 0x2ca4 <ltmp0+0x2ca4>
    2dec:      	fmov	x13, d29
    2df0:      	ld1.s	{ v28 }[2], [x13]
    2df4:      	tbz	w12, #0x7, 0x2ca8 <ltmp0+0x2ca8>
    2df8:      	mov.d	x12, v29[1]
    2dfc:      	ld1.s	{ v28 }[3], [x12]
    2e00:      	fdiv.4s	v25, v25, v5
    2e04:      	fmov	w12, s19
    2e08:      	fmul.4s	v25, v25, v26
    2e0c:      	add	x11, x8, x11, lsl #5
    2e10:      	tbz	w12, #0x0, 0x2cbc <ltmp0+0x2cbc>
    2e14:      	str	s25, [x11]
    2e18:      	and	w12, w12, #0xff
    2e1c:      	tbz	w12, #0x1, 0x2cc4 <ltmp0+0x2cc4>
    2e20:      	add	x13, x11, #0x4
    2e24:      	st1.s	{ v25 }[1], [x13]
    2e28:      	tbz	w12, #0x2, 0x2cc8 <ltmp0+0x2cc8>
    2e2c:      	add	x13, x11, #0x8
    2e30:      	st1.s	{ v25 }[2], [x13]
    2e34:      	tbz	w12, #0x3, 0x2ccc <ltmp0+0x2ccc>
    2e38:      	add	x13, x11, #0xc
    2e3c:      	st1.s	{ v25 }[3], [x13]
    2e40:      	fdiv.4s	v25, v27, v5
    2e44:      	fmul.4s	v25, v25, v28
    2e48:      	tbz	w12, #0x4, 0x2cd8 <ltmp0+0x2cd8>
    2e4c:      	str	s25, [x11, #0x10]
    2e50:      	tbz	w12, #0x5, 0x2cdc <ltmp0+0x2cdc>
    2e54:      	add	x13, x11, #0x14
    2e58:      	st1.s	{ v25 }[1], [x13]
    2e5c:      	tbz	w12, #0x6, 0x2ce0 <ltmp0+0x2ce0>
    2e60:      	add	x13, x11, #0x18
    2e64:      	st1.s	{ v25 }[2], [x13]
    2e68:      	tbz	w12, #0x7, 0x2bd0 <ltmp0+0x2bd0>
    2e6c:      	add	x11, x11, #0x1c
    2e70:      	st1.s	{ v25 }[3], [x11]
    2e74:      	b	0x2bd0 <ltmp0+0x2bd0>
    2e78:      	add	x8, x23, x9
    2e7c:      	ldp	q7, q6, [x8]
    2e80:      	zip1.8b	v16, v13, v0
    2e84:      	ushll.4s	v16, v16, #0x0
    2e88:      	shl.4s	v16, v16, #0x1f
    2e8c:      	cmlt.4s	v16, v16, #0
    2e90:      	and.16b	v7, v16, v7
    2e94:      	fmov	w8, s2
    2e98:      	fdiv.4s	v7, v7, v5
    2e9c:      	add	x11, sp, #0x560
    2ea0:      	add	x11, x11, x9
    2ea4:      	ldp	q17, q2, [x11]
    2ea8:      	and.16b	v16, v16, v17
    2eac:      	fmul.4s	v7, v7, v16
    2eb0:      	ldp	q16, q17, [sp, #0x100]
    2eb4:      	ldp	q19, q18, [sp, #0xe0]
    2eb8:      	stp	q17, q18, [sp, #0x2d0]
    2ebc:      	stp	q19, q16, [sp, #0x2f0]
    2ec0:      	and	x11, x28, #0x7
    2ec4:      	add	x12, sp, #0x2d0
    2ec8:      	ldr	x11, [x12, x11, lsl #3]
    2ecc:      	sub	x9, x11, x28
    2ed0:      	add	x9, x3, x9, lsl #2
    2ed4:      	tbnz	w8, #0x0, 0x2fb4 <ltmp0+0x2fb4>
    2ed8:      	tbnz	w8, #0x1, 0x2fbc <ltmp0+0x2fbc>
    2edc:      	tbnz	w8, #0x2, 0x2fc8 <ltmp0+0x2fc8>
    2ee0:      	tbz	w8, #0x3, 0x2eec <ltmp0+0x2eec>
    2ee4:      	add	x11, x9, #0xc
    2ee8:      	st1.s	{ v7 }[3], [x11]
    2eec:      	zip2.8b	v7, v13, v0
    2ef0:      	ushll.4s	v7, v7, #0x0
    2ef4:      	shl.4s	v7, v7, #0x1f
    2ef8:      	cmlt.4s	v7, v7, #0
    2efc:      	and.16b	v6, v7, v6
    2f00:      	fdiv.4s	v5, v6, v5
    2f04:      	and.16b	v2, v7, v2
    2f08:      	fmul.4s	v2, v5, v2
    2f0c:      	tbnz	w8, #0x4, 0x2fd8 <ltmp0+0x2fd8>
    2f10:      	tbnz	w8, #0x5, 0x2fe0 <ltmp0+0x2fe0>
    2f14:      	tbnz	w8, #0x6, 0x2fec <ltmp0+0x2fec>
    2f18:      	tbz	w8, #0x7, 0xd0 <ltmp0+0xd0>
    2f1c:      	b	0x2ff8 <ltmp0+0x2ff8>
    2f20:      	ldr	s28, [x8]
    2f24:      	tbz	w13, #0x1, 0x1df4 <ltmp0+0x1df4>
    2f28:      	add	x12, x8, #0x4
    2f2c:      	ld1.s	{ v28 }[1], [x12]
    2f30:      	tbz	w13, #0x2, 0x1df8 <ltmp0+0x1df8>
    2f34:      	add	x12, x8, #0x8
    2f38:      	ld1.s	{ v28 }[2], [x12]
    2f3c:      	tbz	w13, #0x3, 0x1dfc <ltmp0+0x1dfc>
    2f40:      	add	x12, x8, #0xc
    2f44:      	ld1.s	{ v28 }[3], [x12]
    2f48:      	tbz	w13, #0x4, 0x1e00 <ltmp0+0x1e00>
    2f4c:      	add	x12, x8, #0x10
    2f50:      	ld1.s	{ v29 }[0], [x12]
    2f54:      	tbz	w13, #0x5, 0x1e04 <ltmp0+0x1e04>
    2f58:      	add	x12, x8, #0x14
    2f5c:      	ld1.s	{ v29 }[1], [x12]
    2f60:      	tbz	w13, #0x6, 0x1e08 <ltmp0+0x1e08>
    2f64:      	add	x12, x8, #0x18
    2f68:      	ld1.s	{ v29 }[2], [x12]
    2f6c:      	tbnz	w13, #0x7, 0x1e0c <ltmp0+0x1e0c>
    2f70:      	b	0x1e14 <ltmp0+0x1e14>
    2f74:      	add	x12, x11, #0x8
    2f78:      	ld1.s	{ v20 }[2], [x12]
    2f7c:      	tbz	w8, #0x3, 0x2b30 <ltmp0+0x2b30>
    2f80:      	add	x12, x11, #0xc
    2f84:      	ld1.s	{ v20 }[3], [x12]
    2f88:      	tbz	w8, #0x4, 0x2b34 <ltmp0+0x2b34>
    2f8c:      	add	x12, x11, #0x10
    2f90:      	ld1.s	{ v21 }[0], [x12]
    2f94:      	tbz	w8, #0x5, 0x2b38 <ltmp0+0x2b38>
    2f98:      	add	x12, x11, #0x14
    2f9c:      	ld1.s	{ v21 }[1], [x12]
    2fa0:      	tbz	w8, #0x6, 0x2b3c <ltmp0+0x2b3c>
    2fa4:      	add	x12, x11, #0x18
    2fa8:      	ld1.s	{ v21 }[2], [x12]
    2fac:      	tbnz	w8, #0x7, 0x2b40 <ltmp0+0x2b40>
    2fb0:      	b	0x2b48 <ltmp0+0x2b48>
    2fb4:      	str	s7, [x9]
    2fb8:      	tbz	w8, #0x1, 0x2edc <ltmp0+0x2edc>
    2fbc:      	add	x11, x9, #0x4
    2fc0:      	st1.s	{ v7 }[1], [x11]
    2fc4:      	tbz	w8, #0x2, 0x2ee0 <ltmp0+0x2ee0>
    2fc8:      	add	x11, x9, #0x8
    2fcc:      	st1.s	{ v7 }[2], [x11]
    2fd0:      	tbnz	w8, #0x3, 0x2ee4 <ltmp0+0x2ee4>
    2fd4:      	b	0x2eec <ltmp0+0x2eec>
    2fd8:      	str	s2, [x9, #0x10]
    2fdc:      	tbz	w8, #0x5, 0x2f14 <ltmp0+0x2f14>
    2fe0:      	add	x11, x9, #0x14
    2fe4:      	st1.s	{ v2 }[1], [x11]
    2fe8:      	tbz	w8, #0x6, 0x2f18 <ltmp0+0x2f18>
    2fec:      	add	x11, x9, #0x18
    2ff0:      	st1.s	{ v2 }[2], [x11]
    2ff4:      	tbz	w8, #0x7, 0xd0 <ltmp0+0xd0>
    2ff8:      	add	x8, x9, #0x1c
    2ffc:      	st1.s	{ v2 }[3], [x8]
    3000:      	b	0xd0 <ltmp0+0xd0>
    3004:      	ldr	x9, [sp, #0x8]
    3008:      	stp	w26, w2, [x9]
    300c:      	str	w0, [x9, #0x8]
    3010:      	mov	w8, #0x18               ; =24
    3014:      	str	w8, [x9, #0x24]
    3018:      	add	sp, sp, #0x3, lsl #12   ; =0x3000
    301c:      	add	sp, sp, #0x5a0
    3020:      	ldp	x29, x30, [sp, #0x90]
    3024:      	ldp	x20, x19, [sp, #0x80]
    3028:      	ldp	x22, x21, [sp, #0x70]
    302c:      	ldp	x24, x23, [sp, #0x60]
    3030:      	ldp	x26, x25, [sp, #0x50]
    3034:      	ldp	x28, x27, [sp, #0x40]
    3038:      	ldp	d9, d8, [sp, #0x30]
    303c:      	ldp	d11, d10, [sp, #0x20]
    3040:      	ldp	d13, d12, [sp, #0x10]
    3044:      	ldp	d15, d14, [sp], #0xa0
    3048:      	ret

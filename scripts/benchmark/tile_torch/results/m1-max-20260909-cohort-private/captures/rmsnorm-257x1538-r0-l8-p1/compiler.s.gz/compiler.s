	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_8:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_9:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_10:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
lCPI0_12:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #1040
	str	x0, [sp, #72]                   ; 8-byte Folded Spill
	cbz	w3, LBB0_136
; %bb.1:                                ; %block.batch.loop.preheader
	mov	w25, #0                         ; =0x0
	ldp	w9, w8, [x2, #44]
	stp	w8, w9, [sp, #108]              ; 8-byte Folded Spill
	add	x19, sp, #1, lsl #12            ; =4096
	add	x19, x19, #3056
	add	x24, sp, #976
	ldp	w8, w9, [x2]
	ldp	w10, w11, [x2, #8]
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	str	x11, [sp, #96]                  ; 8-byte Folded Spill
	movi	d8, #0000000000000000
	str	w3, [sp, #116]                  ; 4-byte Folded Spill
	b	LBB0_4
LBB0_2:                                 ; %llm_rows.exit.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	w25, [sp, #140]                 ; 4-byte Folded Reload
LBB0_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	w8, w7, #1
	ldp	w11, w9, [sp, #108]             ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w9, eq
	csinc	w8, wzr, w7, eq
	ldp	w13, w12, [sp, #120]            ; 8-byte Folded Reload
	cinc	w10, w13, eq
	cmp	w10, w11
	cset	w11, eq
	ands	w11, w9, w11
	csel	w9, wzr, w10, ne
	add	w10, w12, w11
	add	w25, w25, #1
	cmp	w25, w3
	b.eq	LBB0_135
LBB0_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_24 Depth 2
                                        ;       Child Loop BB0_25 Depth 3
                                        ;       Child Loop BB0_27 Depth 3
                                        ;     Child Loop BB0_33 Depth 2
                                        ;     Child Loop BB0_59 Depth 2
                                        ;     Child Loop BB0_62 Depth 2
                                        ;     Child Loop BB0_89 Depth 2
                                        ;     Child Loop BB0_6 Depth 2
                                        ;     Child Loop BB0_8 Depth 2
                                        ;     Child Loop BB0_10 Depth 2
                                        ;     Child Loop BB0_12 Depth 2
                                        ;     Child Loop BB0_14 Depth 2
                                        ;     Child Loop BB0_16 Depth 2
                                        ;     Child Loop BB0_18 Depth 2
                                        ;     Child Loop BB0_20 Depth 2
	str	w10, [sp, #124]                 ; 4-byte Folded Spill
	mov	x13, x9
	mov	x14, x8
	ubfiz	x8, x8, #5, #32
	ldr	x12, [sp, #96]                  ; 8-byte Folded Reload
	cmp	x8, x12
	csel	x9, x8, xzr, ls
	subs	x10, x12, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x12, x9
	ccmp	x8, x12, #2, hi
	csel	x9, x10, xzr, ls
	cmp	x9, #32
	str	w25, [sp, #140]                 ; 4-byte Folded Spill
	str	w13, [sp, #120]                 ; 4-byte Folded Spill
	str	x14, [sp, #128]                 ; 8-byte Folded Spill
	b.lo	LBB0_22
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x27, [x8]
	ldr	x22, [x8, #16]
	ldr	x28, [x8, #48]
	ubfiz	w20, w14, #2, #27
	mov	w21, #6152                      ; =0x1808
	umull	x23, w20, w21
	umaddl	x1, w20, w21, x27
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #3056
	mov	w2, #6144                       ; =0x1800
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	mov	w9, #6144                       ; =0x1800
	umaddl	x21, w20, w21, x9
	add	x9, x27, x21
	ldr	s0, [x9], #4
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp, #304]                  ; 16-byte Folded Spill
	str	q0, [sp, #13296]
	ldr	q0, [sp, #7152]
	ldr	q1, [sp, #7168]
	fmul.4s	v2, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #7184]
	ldr	q1, [sp, #7200]
	fmul.4s	v5, v1, v1
	fmul.4s	v4, v0, v0
	ldr	q0, [sp, #7216]
	ldr	q1, [sp, #7232]
	fmul.4s	v6, v1, v1
	fmul.4s	v7, v0, v0
	ldr	q0, [sp, #7248]
	ldr	q1, [sp, #7264]
	fmul.4s	v17, v1, v1
	fmul.4s	v16, v0, v0
LBB0_6:                                 ; %direct.true57.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x9, x19, x8, lsl #5
	ldp	q1, q0, [x9, #128]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x9, #160]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v5, v5, v0
	fadd.4s	v4, v4, v1
	ldp	q1, q0, [x9, #192]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v6, v6, v0
	fadd.4s	v7, v7, v1
	ldp	q1, q0, [x9, #224]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v17, v17, v0
	fadd.4s	v16, v16, v1
	add	x8, x8, #4
	cmp	x8, #188
	b.lo	LBB0_6
; %bb.7:                                ; %direct.false58.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x0, sp, #976
	mov	x1, x22
	mov	w2, #6144                       ; =0x1800
	stp	q5, q2, [sp, #192]              ; 32-byte Folded Spill
	str	q3, [sp, #176]                  ; 16-byte Folded Spill
	stp	q7, q4, [sp, #224]              ; 32-byte Folded Spill
	stp	q6, q16, [sp, #272]             ; 32-byte Folded Spill
	str	q17, [sp, #256]                 ; 16-byte Folded Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	q7, [sp, #304]                  ; 16-byte Folded Reload
	fmul.4s	v0, v7, v7
	ldp	q1, q2, [sp, #176]              ; 32-byte Folded Reload
	fadd.4s	v0, v0, v1
	mov.d	v0[1], v1[1]
	ldr	q1, [sp, #208]                  ; 16-byte Folded Reload
	fadd.4s	v1, v2, v1
	ldp	q2, q3, [sp, #224]              ; 32-byte Folded Reload
	fadd.4s	v0, v3, v0
	fadd.4s	v0, v2, v0
	ldp	q2, q3, [sp, #256]              ; 32-byte Folded Reload
	fadd.4s	v1, v3, v1
	fadd.4s	v1, v2, v1
	ldr	q2, [sp, #288]                  ; 16-byte Folded Reload
	fadd.4s	v0, v2, v0
	rev64.4s	v2, v0
	rev64.4s	v3, v1
	fadd.4s	v1, v1, v3
	fadd.4s	v0, v0, v2
	dup.4s	v2, v0[2]
	dup.4s	v3, v1[2]
	fadd.4s	v1, v1, v3
	fadd.4s	v0, v0, v2
	fadd.4s	v0, v0, v1
	fadd	s0, s0, s8
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s1, w9
	fdiv	s1, s0, s1
	mov	w9, #6148                       ; =0x1804
	add	x9, x22, x9
	ldr	s0, [x22, #6144]
	ld1.s	{ v0 }[1], [x9]
	mov	w9, #6144                       ; =0x1800
	add	x25, x22, x9
	str	q0, [sp, #7120]
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s2, w9
	fadd	s1, s1, s2
	fsqrt	s1, s1
	dup.4s	v2, v1[0]
	add	x9, x28, x23
LBB0_8:                                 ; %direct.true119.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x8, #5
	add	x11, x19, x10
	ldp	q3, q4, [x11]
	fdiv.4s	v4, v4, v2
	fdiv.4s	v3, v3, v2
	add	x11, x24, x10
	ldp	q6, q5, [x11]
	fmul.4s	v3, v3, v6
	fmul.4s	v4, v4, v5
	add	x10, x9, x10
	stp	q3, q4, [x10]
	add	x8, x8, #1
	cmp	x8, #192
	b.ne	LBB0_8
; %bb.9:                                ; %llm_rows.full_packet.exit.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	dup.2s	v1, v1[0]
	fdiv.2s	v1, v7, v1
	fmul.2s	v0, v1, v0
	str	d0, [x28, x21]
	orr	w21, w20, #0x1
	mov	w26, #6152                      ; =0x1808
	umull	x23, w21, w26
	umaddl	x1, w21, w26, x27
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #3056
	mov	w2, #6144                       ; =0x1800
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	mov	w9, #6144                       ; =0x1800
	umaddl	x21, w21, w26, x9
	add	x9, x27, x21
	ldr	s0, [x9], #4
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp, #304]                  ; 16-byte Folded Spill
	str	q0, [sp, #13296]
	ldr	q0, [sp, #7152]
	ldr	q1, [sp, #7168]
	fmul.4s	v2, v1, v1
	fmul.4s	v17, v0, v0
	ldr	q0, [sp, #7184]
	ldr	q1, [sp, #7200]
	fmul.4s	v4, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #7216]
	ldr	q1, [sp, #7232]
	fmul.4s	v5, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [sp, #7248]
	ldr	q1, [sp, #7264]
	fmul.4s	v16, v1, v1
	fmul.4s	v7, v0, v0
LBB0_10:                                ; %direct.true57.i18.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x9, x19, x8, lsl #5
	ldp	q1, q0, [x9, #128]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v17, v17, v1
	ldp	q1, q0, [x9, #160]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x9, #192]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v5, v5, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x9, #224]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v7, v7, v1
	add	x8, x8, #4
	cmp	x8, #188
	b.lo	LBB0_10
; %bb.11:                               ; %direct.false58.i31.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x0, sp, #976
	mov	x1, x22
	mov	w2, #6144                       ; =0x1800
	stp	q4, q2, [sp, #192]              ; 32-byte Folded Spill
	stp	q6, q3, [sp, #224]              ; 32-byte Folded Spill
	stp	q5, q7, [sp, #272]              ; 32-byte Folded Spill
	str	q16, [sp, #256]                 ; 16-byte Folded Spill
	str	q17, [sp, #176]                 ; 16-byte Folded Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	q7, [sp, #304]                  ; 16-byte Folded Reload
	fmul.4s	v0, v7, v7
	ldp	q2, q3, [sp, #176]              ; 32-byte Folded Reload
	fadd.4s	v1, v0, v2
	mov.d	v1[1], v2[1]
	mov	w9, #6148                       ; =0x1804
	add	x9, x22, x9
	ldr	s0, [x25]
	ld1.s	{ v0 }[1], [x9]
	ldr	q2, [sp, #208]                  ; 16-byte Folded Reload
	fadd.4s	v2, v3, v2
	ldp	q3, q4, [sp, #224]              ; 32-byte Folded Reload
	fadd.4s	v1, v4, v1
	fadd.4s	v1, v3, v1
	ldp	q3, q4, [sp, #256]              ; 32-byte Folded Reload
	fadd.4s	v2, v4, v2
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #288]                  ; 16-byte Folded Reload
	fadd.4s	v1, v3, v1
	rev64.4s	v3, v1
	rev64.4s	v4, v2
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	dup.4s	v3, v1[2]
	dup.4s	v4, v2[2]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	fadd.4s	v1, v1, v2
	fadd	s1, s1, s8
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s2, w9
	fdiv	s1, s1, s2
	str	q0, [sp, #7120]
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s2, w9
	fadd	s1, s1, s2
	fsqrt	s1, s1
	dup.4s	v2, v1[0]
	add	x9, x28, x23
LBB0_12:                                ; %direct.true119.i38.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x8, #5
	add	x11, x19, x10
	ldp	q3, q4, [x11]
	fdiv.4s	v4, v4, v2
	fdiv.4s	v3, v3, v2
	add	x11, x24, x10
	ldp	q6, q5, [x11]
	fmul.4s	v3, v3, v6
	fmul.4s	v4, v4, v5
	add	x10, x9, x10
	stp	q3, q4, [x10]
	add	x8, x8, #1
	cmp	x8, #192
	b.ne	LBB0_12
; %bb.13:                               ; %llm_rows.full_packet.exit47.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	dup.2s	v1, v1[0]
	fdiv.2s	v1, v7, v1
	fmul.2s	v0, v1, v0
	str	d0, [x28, x21]
	orr	w21, w20, #0x2
	mov	w26, #6152                      ; =0x1808
	umull	x23, w21, w26
	umaddl	x1, w21, w26, x27
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #3056
	mov	w2, #6144                       ; =0x1800
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	mov	w9, #6144                       ; =0x1800
	umaddl	x21, w21, w26, x9
	add	x9, x27, x21
	ldr	s0, [x9], #4
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp, #304]                  ; 16-byte Folded Spill
	str	q0, [sp, #13296]
	ldr	q0, [sp, #7152]
	ldr	q1, [sp, #7168]
	fmul.4s	v2, v1, v1
	fmul.4s	v17, v0, v0
	ldr	q0, [sp, #7184]
	ldr	q1, [sp, #7200]
	fmul.4s	v4, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #7216]
	ldr	q1, [sp, #7232]
	fmul.4s	v5, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [sp, #7248]
	ldr	q1, [sp, #7264]
	fmul.4s	v16, v1, v1
	fmul.4s	v7, v0, v0
LBB0_14:                                ; %direct.true57.i63.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x9, x19, x8, lsl #5
	ldp	q1, q0, [x9, #128]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v17, v17, v1
	ldp	q1, q0, [x9, #160]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x9, #192]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v5, v5, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x9, #224]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v7, v7, v1
	add	x8, x8, #4
	cmp	x8, #188
	b.lo	LBB0_14
; %bb.15:                               ; %direct.false58.i76.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x0, sp, #976
	mov	x1, x22
	mov	w2, #6144                       ; =0x1800
	stp	q4, q2, [sp, #192]              ; 32-byte Folded Spill
	stp	q6, q3, [sp, #224]              ; 32-byte Folded Spill
	stp	q5, q7, [sp, #272]              ; 32-byte Folded Spill
	str	q16, [sp, #256]                 ; 16-byte Folded Spill
	str	q17, [sp, #176]                 ; 16-byte Folded Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	q7, [sp, #304]                  ; 16-byte Folded Reload
	fmul.4s	v0, v7, v7
	ldp	q2, q3, [sp, #176]              ; 32-byte Folded Reload
	fadd.4s	v1, v0, v2
	mov.d	v1[1], v2[1]
	mov	w9, #6148                       ; =0x1804
	add	x9, x22, x9
	ldr	s0, [x25]
	ld1.s	{ v0 }[1], [x9]
	ldr	q2, [sp, #208]                  ; 16-byte Folded Reload
	fadd.4s	v2, v3, v2
	ldp	q3, q4, [sp, #224]              ; 32-byte Folded Reload
	fadd.4s	v1, v4, v1
	fadd.4s	v1, v3, v1
	ldp	q3, q4, [sp, #256]              ; 32-byte Folded Reload
	fadd.4s	v2, v4, v2
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #288]                  ; 16-byte Folded Reload
	fadd.4s	v1, v3, v1
	rev64.4s	v3, v1
	rev64.4s	v4, v2
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	dup.4s	v3, v1[2]
	dup.4s	v4, v2[2]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	fadd.4s	v1, v1, v2
	fadd	s1, s1, s8
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s2, w9
	fdiv	s1, s1, s2
	str	q0, [sp, #7120]
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s2, w9
	fadd	s1, s1, s2
	fsqrt	s1, s1
	dup.4s	v2, v1[0]
	add	x9, x28, x23
LBB0_16:                                ; %direct.true119.i83.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x8, #5
	add	x11, x19, x10
	ldp	q3, q4, [x11]
	fdiv.4s	v4, v4, v2
	fdiv.4s	v3, v3, v2
	add	x11, x24, x10
	ldp	q6, q5, [x11]
	fmul.4s	v3, v3, v6
	fmul.4s	v4, v4, v5
	add	x10, x9, x10
	stp	q3, q4, [x10]
	add	x8, x8, #1
	cmp	x8, #192
	b.ne	LBB0_16
; %bb.17:                               ; %llm_rows.full_packet.exit92.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	dup.2s	v1, v1[0]
	fdiv.2s	v1, v7, v1
	fmul.2s	v0, v1, v0
	str	d0, [x28, x21]
	orr	w20, w20, #0x3
	mov	w23, #6152                      ; =0x1808
	umull	x21, w20, w23
	umaddl	x1, w20, w23, x27
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #3056
	mov	w2, #6144                       ; =0x1800
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	mov	w9, #6144                       ; =0x1800
	umaddl	x20, w20, w23, x9
	add	x9, x27, x20
	ldr	s0, [x9], #4
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp, #304]                  ; 16-byte Folded Spill
	str	q0, [sp, #13296]
	ldr	q0, [sp, #7152]
	ldr	q1, [sp, #7168]
	fmul.4s	v2, v1, v1
	fmul.4s	v17, v0, v0
	ldr	q0, [sp, #7184]
	ldr	q1, [sp, #7200]
	fmul.4s	v4, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #7216]
	ldr	q1, [sp, #7232]
	fmul.4s	v5, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [sp, #7248]
	ldr	q1, [sp, #7264]
	fmul.4s	v16, v1, v1
	fmul.4s	v7, v0, v0
LBB0_18:                                ; %direct.true57.i108.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x9, x19, x8, lsl #5
	ldp	q1, q0, [x9, #128]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v17, v17, v1
	ldp	q1, q0, [x9, #160]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x9, #192]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v5, v5, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x9, #224]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v7, v7, v1
	add	x8, x8, #4
	cmp	x8, #188
	b.lo	LBB0_18
; %bb.19:                               ; %direct.false58.i121.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x0, sp, #976
	mov	x1, x22
	mov	w2, #6144                       ; =0x1800
	stp	q4, q2, [sp, #192]              ; 32-byte Folded Spill
	stp	q6, q3, [sp, #224]              ; 32-byte Folded Spill
	stp	q5, q7, [sp, #272]              ; 32-byte Folded Spill
	str	q16, [sp, #256]                 ; 16-byte Folded Spill
	str	q17, [sp, #176]                 ; 16-byte Folded Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	q7, [sp, #304]                  ; 16-byte Folded Reload
	fmul.4s	v0, v7, v7
	ldp	q2, q3, [sp, #176]              ; 32-byte Folded Reload
	fadd.4s	v1, v0, v2
	mov.d	v1[1], v2[1]
	ldr	s0, [x25]
	ldr	q2, [sp, #208]                  ; 16-byte Folded Reload
	fadd.4s	v2, v3, v2
	ldp	q3, q4, [sp, #224]              ; 32-byte Folded Reload
	fadd.4s	v1, v4, v1
	fadd.4s	v1, v3, v1
	ldp	q3, q4, [sp, #256]              ; 32-byte Folded Reload
	fadd.4s	v2, v4, v2
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #288]                  ; 16-byte Folded Reload
	fadd.4s	v1, v3, v1
	rev64.4s	v3, v1
	rev64.4s	v4, v2
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	dup.4s	v3, v1[2]
	dup.4s	v4, v2[2]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	fadd.4s	v1, v1, v2
	fadd	s1, s1, s8
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s2, w9
	fdiv	s1, s1, s2
	mov	w9, #6148                       ; =0x1804
	add	x9, x22, x9
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp, #7120]
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s2, w9
	fadd	s1, s1, s2
	fsqrt	s1, s1
	dup.4s	v2, v1[0]
	add	x9, x28, x21
LBB0_20:                                ; %direct.true119.i128.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x8, #5
	add	x11, x19, x10
	ldp	q3, q4, [x11]
	fdiv.4s	v4, v4, v2
	fdiv.4s	v3, v3, v2
	add	x11, x24, x10
	ldp	q6, q5, [x11]
	fmul.4s	v3, v3, v6
	fmul.4s	v4, v4, v5
	add	x10, x9, x10
	stp	q3, q4, [x10]
	add	x8, x8, #1
	cmp	x8, #192
	b.ne	LBB0_20
; %bb.21:                               ; %llm_rows.full_packet.exit137.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	dup.2s	v1, v1[0]
	fdiv.2s	v1, v7, v1
	fmul.2s	v0, v1, v0
	str	d0, [x28, x20]
	ldr	w25, [sp, #140]                 ; 4-byte Folded Reload
	ldr	x7, [sp, #128]                  ; 8-byte Folded Reload
	ldr	w3, [sp, #116]                  ; 4-byte Folded Reload
	b	LBB0_3
LBB0_22:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	lsr	x8, x9, #3
	str	x8, [sp, #160]                  ; 8-byte Folded Spill
	str	x9, [sp, #80]                   ; 8-byte Folded Spill
	cmp	x9, #8
	mov	w9, #6152                       ; =0x1808
	b.lo	LBB0_29
; %bb.23:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x27, #0                         ; =0x0
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x28, [x8]
	ldr	x22, [x8, #16]
	ldr	x21, [x8, #48]
	mov	w8, #6144                       ; =0x1800
	add	x8, x22, x8
	str	x8, [sp, #144]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #128]                  ; 8-byte Folded Reload
	lsl	w25, w8, #2
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	and	x8, x8, #0x7ffffff
	mov	w10, #24608                     ; =0x6020
	umaddl	x26, w8, w10, x21
LBB0_24:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_25 Depth 3
                                        ;       Child Loop BB0_27 Depth 3
	add	w8, w27, w25
	and	x20, x8, #0x1fffffff
	umaddl	x1, w20, w9, x28
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #3056
	mov	w2, #6144                       ; =0x1800
	mov	w23, #6152                      ; =0x1808
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	mov	w9, #6144                       ; =0x1800
	umaddl	x20, w20, w23, x9
	add	x9, x28, x20
	ldr	s0, [x9], #4
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp, #304]                  ; 16-byte Folded Spill
	str	q0, [sp, #13296]
	ldr	q0, [sp, #7152]
	ldr	q1, [sp, #7168]
	fmul.4s	v2, v1, v1
	fmul.4s	v17, v0, v0
	ldr	q0, [sp, #7184]
	ldr	q1, [sp, #7200]
	fmul.4s	v4, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #7216]
	ldr	q1, [sp, #7232]
	fmul.4s	v5, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [sp, #7248]
	ldr	q1, [sp, #7264]
	fmul.4s	v16, v1, v1
	fmul.4s	v7, v0, v0
LBB0_25:                                ; %direct.true57.i153.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ;     Parent Loop BB0_24 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x19, x8, lsl #5
	ldp	q1, q0, [x9, #128]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v17, v17, v1
	ldp	q1, q0, [x9, #160]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x9, #192]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v5, v5, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x9, #224]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v7, v7, v1
	add	x8, x8, #4
	cmp	x8, #188
	b.lo	LBB0_25
; %bb.26:                               ; %direct.false58.i166.i
                                        ;   in Loop: Header=BB0_24 Depth=2
	add	x0, sp, #976
	mov	x1, x22
	mov	w2, #6144                       ; =0x1800
	stp	q4, q2, [sp, #192]              ; 32-byte Folded Spill
	stp	q6, q3, [sp, #224]              ; 32-byte Folded Spill
	stp	q5, q7, [sp, #272]              ; 32-byte Folded Spill
	str	q16, [sp, #256]                 ; 16-byte Folded Spill
	str	q17, [sp, #176]                 ; 16-byte Folded Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	q7, [sp, #304]                  ; 16-byte Folded Reload
	fmul.4s	v0, v7, v7
	ldp	q2, q3, [sp, #176]              ; 32-byte Folded Reload
	fadd.4s	v1, v0, v2
	mov.d	v1[1], v2[1]
	mov	w9, #6148                       ; =0x1804
	add	x9, x22, x9
	ldr	x10, [sp, #144]                 ; 8-byte Folded Reload
	ldr	s0, [x10]
	ld1.s	{ v0 }[1], [x9]
	ldr	q2, [sp, #208]                  ; 16-byte Folded Reload
	fadd.4s	v2, v3, v2
	ldp	q3, q4, [sp, #224]              ; 32-byte Folded Reload
	fadd.4s	v1, v4, v1
	fadd.4s	v1, v3, v1
	ldp	q3, q4, [sp, #256]              ; 32-byte Folded Reload
	fadd.4s	v2, v4, v2
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #288]                  ; 16-byte Folded Reload
	fadd.4s	v1, v3, v1
	rev64.4s	v3, v1
	rev64.4s	v4, v2
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	dup.4s	v3, v1[2]
	dup.4s	v4, v2[2]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	fadd.4s	v1, v1, v2
	fadd	s1, s1, s8
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s2, w9
	fdiv	s1, s1, s2
	str	q0, [sp, #7120]
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s2, w9
	fadd	s1, s1, s2
	fsqrt	s1, s1
	dup.4s	v2, v1[0]
LBB0_27:                                ; %direct.true119.i173.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ;     Parent Loop BB0_24 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x9, x8, #5
	add	x10, x19, x9
	ldp	q3, q4, [x10]
	fdiv.4s	v4, v4, v2
	fdiv.4s	v3, v3, v2
	add	x10, x24, x9
	ldp	q6, q5, [x10]
	fmul.4s	v3, v3, v6
	fmul.4s	v4, v4, v5
	add	x9, x26, x9
	stp	q3, q4, [x9]
	add	x8, x8, #1
	cmp	x8, #192
	b.ne	LBB0_27
; %bb.28:                               ; %llm_rows.full_packet.exit182.i
                                        ;   in Loop: Header=BB0_24 Depth=2
	dup.2s	v1, v1[0]
	fdiv.2s	v1, v7, v1
	fmul.2s	v0, v1, v0
	str	d0, [x21, x20]
	add	x27, x27, #1
	mov	w9, #6152                       ; =0x1808
	add	x26, x26, x9
	ldr	x8, [sp, #160]                  ; 8-byte Folded Reload
	cmp	x27, x8
	b.ne	LBB0_24
LBB0_29:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	w14, #6152                      ; =0x1808
	ldr	x8, [sp, #80]                   ; 8-byte Folded Reload
	and	w8, w8, #0x7
	ldr	w3, [sp, #116]                  ; 4-byte Folded Reload
	ldr	w25, [sp, #140]                 ; 4-byte Folded Reload
	ldr	x7, [sp, #128]                  ; 8-byte Folded Reload
	cbz	w8, LBB0_3
; %bb.30:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	dup.4s	v1, w8
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q0, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v3, v1, v0
	umaxv.8h	h2, v3
	fmov	w8, s2
	mov	w17, #4                         ; =0x4
	tbz	w8, #0, LBB0_2
; %bb.31:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x8, [sp, #72]                   ; 8-byte Folded Reload
	ldr	x12, [x8]
	ldr	x10, [x8, #16]
	ldr	x8, [x8, #48]
Lloh4:
	adrp	x11, lCPI0_0@PAGE
Lloh5:
	ldr	q2, [x11, lCPI0_0@PAGEOFF]
	and.16b	v2, v3, v2
	addv.8h	h2, v2
	ubfiz	w11, w7, #2, #27
	ldr	x13, [sp, #160]                 ; 8-byte Folded Reload
	orr	w13, w11, w13
	fmov	w11, s2
	and	w11, w11, #0xff
	dup.4s	v4, w13
	and.16b	v5, v1, v4
	and.16b	v4, v0, v4
	ushll2.2d	v7, v4, #0
	ushll2.2d	v16, v5, #0
	ushll.2d	v17, v4, #0
	ushll.2d	v4, v5, #0
	fmov	x13, d4
	umaddl	x13, w13, w14, x12
	b	LBB0_33
LBB0_32:                                ; %else234
                                        ;   in Loop: Header=BB0_33 Depth=2
	add	x14, x19, x9, lsl #5
	ldp	q18, q19, [x14]
	bif.16b	v6, v19, v0
	bif.16b	v5, v18, v1
	stp	q5, q6, [x14]
	add	x9, x9, #1
	cmp	x9, #192
	b.eq	LBB0_49
LBB0_33:                                ; %direct.true.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w15, s2
	add	x14, x13, x9, lsl #5
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w15, #0, LBB0_41
; %bb.34:                               ; %else
                                        ;   in Loop: Header=BB0_33 Depth=2
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_42
LBB0_35:                                ; %else216
                                        ;   in Loop: Header=BB0_33 Depth=2
	tbnz	w15, #2, LBB0_43
LBB0_36:                                ; %else219
                                        ;   in Loop: Header=BB0_33 Depth=2
	tbnz	w15, #3, LBB0_44
LBB0_37:                                ; %else222
                                        ;   in Loop: Header=BB0_33 Depth=2
	tbnz	w15, #4, LBB0_45
LBB0_38:                                ; %else225
                                        ;   in Loop: Header=BB0_33 Depth=2
	tbnz	w15, #5, LBB0_46
LBB0_39:                                ; %else228
                                        ;   in Loop: Header=BB0_33 Depth=2
	tbnz	w15, #6, LBB0_47
LBB0_40:                                ; %else231
                                        ;   in Loop: Header=BB0_33 Depth=2
	tbz	w15, #7, LBB0_32
	b	LBB0_48
LBB0_41:                                ; %cond.load
                                        ;   in Loop: Header=BB0_33 Depth=2
	ldr	s5, [x14]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_35
LBB0_42:                                ; %cond.load215
                                        ;   in Loop: Header=BB0_33 Depth=2
	add	x16, x14, #4
	ld1.s	{ v5 }[1], [x16]
	tbz	w15, #2, LBB0_36
LBB0_43:                                ; %cond.load218
                                        ;   in Loop: Header=BB0_33 Depth=2
	add	x16, x14, #8
	ld1.s	{ v5 }[2], [x16]
	tbz	w15, #3, LBB0_37
LBB0_44:                                ; %cond.load221
                                        ;   in Loop: Header=BB0_33 Depth=2
	add	x16, x14, #12
	ld1.s	{ v5 }[3], [x16]
	tbz	w15, #4, LBB0_38
LBB0_45:                                ; %cond.load224
                                        ;   in Loop: Header=BB0_33 Depth=2
	add	x16, x14, #16
	ld1.s	{ v6 }[0], [x16]
	tbz	w15, #5, LBB0_39
LBB0_46:                                ; %cond.load227
                                        ;   in Loop: Header=BB0_33 Depth=2
	add	x16, x14, #20
	ld1.s	{ v6 }[1], [x16]
	tbz	w15, #6, LBB0_40
LBB0_47:                                ; %cond.load230
                                        ;   in Loop: Header=BB0_33 Depth=2
	add	x16, x14, #24
	ld1.s	{ v6 }[2], [x16]
	tbz	w15, #7, LBB0_32
LBB0_48:                                ; %cond.load233
                                        ;   in Loop: Header=BB0_33 Depth=2
	add	x14, x14, #28
	ld1.s	{ v6 }[3], [x14]
	b	LBB0_32
LBB0_49:                                ; %direct.true57.preheader.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	xtn.8b	v24, v3
	sshll.2d	v18, v1, #0
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q3, [x9, lCPI0_6@PAGEOFF]
	and.16b	v5, v18, v3
	movi	d3, #0x0000000000ffff
	and.8b	v6, v24, v3
Lloh8:
	adrp	x9, lCPI0_11@PAGE
Lloh9:
	ldr	d3, [x9, lCPI0_11@PAGEOFF]
	and.8b	v3, v24, v3
	addv.8b	b3, v3
	fmov	w13, s3
	umaxv.8b	b3, v6
	fmov	w9, s3
	rbit	w14, w13
	clz	w14, w14
	tst	w9, #0x1
	csel	w9, w14, wzr, ne
	mov	w14, #1536                      ; =0x600
	dup.2d	v22, x14
	str	q5, [sp, #80]                   ; 16-byte Folded Spill
	orr.16b	v3, v5, v22
	mov	w14, #1538                      ; =0x602
	dup.2s	v19, w14
	xtn.2s	v23, v4
	str	q3, [sp, #192]                  ; 16-byte Folded Spill
	mov.16b	v4, v3
	umlal.2d	v4, v23, v19
	mov	b3, v6[0]
	mov.b	v3[4], v6[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	str	q4, [sp, #288]                  ; 16-byte Folded Spill
	and.16b	v3, v3, v4
	movi.2d	v4, #0000000000000000
	stp	q4, q4, [sp, #928]
	stp	q3, q4, [sp, #896]
	and	x14, x9, #0x7
	add	x15, sp, #896
	ldr	x14, [x15, x14, lsl #3]
	sub	x14, x14, x9
	add	x12, x12, x14, lsl #2
	movi.2d	v5, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w13, #0, LBB0_113
; %bb.50:                               ; %else238
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w13, #1, LBB0_114
LBB0_51:                                ; %else241
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w13, #2, LBB0_115
LBB0_52:                                ; %else244
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w13, #3, LBB0_116
LBB0_53:                                ; %else247
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w13, #4, LBB0_117
LBB0_54:                                ; %else250
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w13, #5, LBB0_118
LBB0_55:                                ; %else253
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w13, #6, LBB0_119
LBB0_56:                                ; %else256
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #7, LBB0_58
LBB0_57:                                ; %cond.load258
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x12, x12, #28
	ld1.s	{ v3 }[3], [x12]
LBB0_58:                                ; %else259
                                        ;   in Loop: Header=BB0_4 Depth=1
	sshll.2d	v4, v0, #0
	sshll2.2d	v20, v1, #0
	sshll2.2d	v21, v0, #0
Lloh10:
	adrp	x12, lCPI0_3@PAGE
Lloh11:
	ldr	q25, [x12, lCPI0_3@PAGEOFF]
	and.16b	v30, v21, v25
Lloh12:
	adrp	x12, lCPI0_4@PAGE
Lloh13:
	ldr	q25, [x12, lCPI0_4@PAGEOFF]
	and.16b	v29, v20, v25
Lloh14:
	adrp	x12, lCPI0_5@PAGE
Lloh15:
	ldr	q25, [x12, lCPI0_5@PAGEOFF]
	and.16b	v28, v4, v25
Lloh16:
	adrp	x12, lCPI0_7@PAGE
Lloh17:
	ldr	q25, [x12, lCPI0_7@PAGEOFF]
	and.16b	v25, v21, v25
Lloh18:
	adrp	x12, lCPI0_8@PAGE
Lloh19:
	ldr	q26, [x12, lCPI0_8@PAGEOFF]
	and.16b	v26, v20, v26
Lloh20:
	adrp	x12, lCPI0_9@PAGE
Lloh21:
	ldr	q27, [x12, lCPI0_9@PAGEOFF]
	and.16b	v27, v4, v27
Lloh22:
	adrp	x12, lCPI0_10@PAGE
Lloh23:
	ldr	q4, [x12, lCPI0_10@PAGEOFF]
	and.16b	v4, v18, v4
	stp	q28, q29, [sp, #16]             ; 32-byte Folded Spill
	orr.16b	v28, v28, v22
	orr.16b	v29, v29, v22
	str	q30, [sp, #48]                  ; 16-byte Folded Spill
	orr.16b	v22, v30, v22
	umull.2d	v30, v23, v19
	xtn.2s	v16, v16
	xtn.2s	v17, v17
	xtn.2s	v7, v7
	stp	q28, q22, [sp, #160]            ; 32-byte Folded Spill
	mov.16b	v18, v22
	umlal.2d	v18, v7, v19
	str	q29, [sp, #144]                 ; 16-byte Folded Spill
	mov.16b	v7, v29
	umlal.2d	v7, v16, v19
	stp	q7, q18, [sp, #240]             ; 32-byte Folded Spill
	mov.16b	v7, v28
	umlal.2d	v7, v17, v19
	stp	q30, q7, [sp, #208]             ; 32-byte Folded Spill
	sshll.2d	v7, v1, #0
	sshll.2d	v18, v0, #0
	stp	q4, q26, [sp, #832]
	stp	q27, q25, [sp, #864]
	and	x12, x9, #0x7
	add	x14, sp, #832
	ldr	x12, [x14, x12, lsl #3]
	orr	x12, x12, #0x1800
	sub	x12, x12, x9, lsl #2
	tst	w13, #0xff
	csel	x12, xzr, x12, eq
	add	x13, x19, x12
	ldp	q16, q17, [x13]
	zip2.8b	v19, v6, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	str	q3, [sp, #304]                  ; 16-byte Folded Spill
	bit.16b	v17, v3, v19
	zip1.8b	v19, v6, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	str	q5, [sp, #272]                  ; 16-byte Folded Spill
	bit.16b	v16, v5, v19
	stp	q16, q17, [x13]
	dup.2d	v19, x17
	and.16b	v16, v21, v19
	and.16b	v17, v20, v19
	and.16b	v22, v18, v19
	and.16b	v23, v7, v19
	fmov	x13, d23
	ldr	q7, [sp, #7264]
	ldr	q18, [sp, #7248]
	fmul.4s	v18, v18, v18
	fmul.4s	v7, v7, v7
	and.16b	v11, v0, v7
	and.16b	v12, v1, v18
	ldr	q7, [sp, #7232]
	ldr	q18, [sp, #7216]
	fmul.4s	v18, v18, v18
	fmul.4s	v7, v7, v7
	and.16b	v14, v0, v7
	and.16b	v13, v1, v18
	ldr	q7, [sp, #7200]
	ldr	q18, [sp, #7184]
	fmul.4s	v18, v18, v18
	fmul.4s	v7, v7, v7
	and.16b	v15, v0, v7
	and.16b	v9, v1, v18
	fmov	x14, d4
	add	x14, x19, x14
	ldp	q7, q4, [x14]
	fmul.4s	v7, v7, v7
	fmul.4s	v4, v4, v4
	and.16b	v18, v0, v4
	and.16b	v10, v1, v7
LBB0_59:                                ; %direct.true57.i198.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v4, v1, #0
	sshll.2d	v25, v0, #0
	add	x13, x19, x13, lsl #5
	ldp	q19, q7, [x13]
	and.16b	v19, v1, v19
	and.16b	v7, v0, v7
	fmul.4s	v7, v7, v7
	fmul.4s	v19, v19, v19
	fadd.4s	v19, v10, v19
	fadd.4s	v7, v18, v7
	ldp	q27, q26, [x13, #32]
	and.16b	v27, v1, v27
	and.16b	v26, v0, v26
	fmul.4s	v26, v26, v26
	fmul.4s	v27, v27, v27
	fadd.4s	v27, v9, v27
	fadd.4s	v26, v15, v26
	ldp	q5, q28, [x13, #64]
	and.16b	v5, v1, v5
	and.16b	v28, v0, v28
	fmul.4s	v28, v28, v28
	fmul.4s	v5, v5, v5
	fadd.4s	v5, v13, v5
	fadd.4s	v28, v14, v28
	ldp	q30, q29, [x13, #96]
	and.16b	v30, v1, v30
	and.16b	v29, v0, v29
	fmul.4s	v29, v29, v29
	fmul.4s	v30, v30, v30
	fadd.4s	v30, v12, v30
	fadd.4s	v29, v11, v29
	dup.2d	v31, x17
	and.16b	v3, v21, v31
	add.2d	v16, v16, v3
	and.16b	v3, v20, v31
	add.2d	v17, v17, v3
	and.16b	v3, v25, v31
	add.2d	v22, v22, v3
	and.16b	v3, v4, v31
	add.2d	v23, v23, v3
	bit.16b	v18, v7, v0
	bit.16b	v10, v19, v1
	bit.16b	v15, v26, v0
	bit.16b	v9, v27, v1
	bit.16b	v14, v28, v0
	bit.16b	v13, v5, v1
	bit.16b	v11, v29, v0
	bit.16b	v12, v30, v1
	fmov	x13, d23
	cmp	x13, #192
	b.lt	LBB0_59
; %bb.60:                               ; %direct.false58.i207.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x13, #0                         ; =0x0
	mov	w14, #1                         ; =0x1
	dup.2d	v3, x14
	ushll2.2d	v4, v0, #0
	and.16b	v20, v4, v3
	ushll2.2d	v4, v1, #0
	and.16b	v21, v4, v3
	ushll.2d	v4, v0, #0
	and.16b	v22, v4, v3
	ushll.2d	v4, v1, #0
	and.16b	v23, v4, v3
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	ldr	q29, [sp, #304]                 ; 16-byte Folded Reload
	ldr	q30, [sp, #272]                 ; 16-byte Folded Reload
	b	LBB0_62
LBB0_61:                                ; %else284
                                        ;   in Loop: Header=BB0_62 Depth=2
	add	x13, x24, x13
	ldp	q3, q5, [x13]
	bif.16b	v4, v5, v0
	bit.16b	v3, v27, v1
	stp	q3, q4, [x13]
	add.2d	v17, v17, v21
	add.2d	v25, v25, v22
	add.2d	v26, v26, v20
	add.2d	v16, v16, v23
	fmov	x13, d16
	cmp	x13, #192
	b.ge	LBB0_78
LBB0_62:                                ; %direct.true93.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w15, s2
	lsl	x13, x13, #5
	add	x14, x10, x13
	movi.2d	v27, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w15, #0, LBB0_70
; %bb.63:                               ; %else263
                                        ;   in Loop: Header=BB0_62 Depth=2
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_71
LBB0_64:                                ; %else266
                                        ;   in Loop: Header=BB0_62 Depth=2
	tbnz	w15, #2, LBB0_72
LBB0_65:                                ; %else269
                                        ;   in Loop: Header=BB0_62 Depth=2
	tbnz	w15, #3, LBB0_73
LBB0_66:                                ; %else272
                                        ;   in Loop: Header=BB0_62 Depth=2
	tbnz	w15, #4, LBB0_74
LBB0_67:                                ; %else275
                                        ;   in Loop: Header=BB0_62 Depth=2
	tbnz	w15, #5, LBB0_75
LBB0_68:                                ; %else278
                                        ;   in Loop: Header=BB0_62 Depth=2
	tbnz	w15, #6, LBB0_76
LBB0_69:                                ; %else281
                                        ;   in Loop: Header=BB0_62 Depth=2
	tbz	w15, #7, LBB0_61
	b	LBB0_77
LBB0_70:                                ; %cond.load262
                                        ;   in Loop: Header=BB0_62 Depth=2
	ldr	s27, [x14]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_64
LBB0_71:                                ; %cond.load265
                                        ;   in Loop: Header=BB0_62 Depth=2
	add	x16, x14, #4
	ld1.s	{ v27 }[1], [x16]
	tbz	w15, #2, LBB0_65
LBB0_72:                                ; %cond.load268
                                        ;   in Loop: Header=BB0_62 Depth=2
	add	x16, x14, #8
	ld1.s	{ v27 }[2], [x16]
	tbz	w15, #3, LBB0_66
LBB0_73:                                ; %cond.load271
                                        ;   in Loop: Header=BB0_62 Depth=2
	add	x16, x14, #12
	ld1.s	{ v27 }[3], [x16]
	tbz	w15, #4, LBB0_67
LBB0_74:                                ; %cond.load274
                                        ;   in Loop: Header=BB0_62 Depth=2
	add	x16, x14, #16
	ld1.s	{ v4 }[0], [x16]
	tbz	w15, #5, LBB0_68
LBB0_75:                                ; %cond.load277
                                        ;   in Loop: Header=BB0_62 Depth=2
	add	x16, x14, #20
	ld1.s	{ v4 }[1], [x16]
	tbz	w15, #6, LBB0_69
LBB0_76:                                ; %cond.load280
                                        ;   in Loop: Header=BB0_62 Depth=2
	add	x16, x14, #24
	ld1.s	{ v4 }[2], [x16]
	tbz	w15, #7, LBB0_61
LBB0_77:                                ; %cond.load283
                                        ;   in Loop: Header=BB0_62 Depth=2
	add	x14, x14, #28
	ld1.s	{ v4 }[3], [x14]
	b	LBB0_61
LBB0_78:                                ; %direct.false94.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	movi	d3, #0xffffffffffff0000
	and.8b	v3, v24, v3
	fmul.4s	v4, v30, v30
	fmul.4s	v5, v29, v29
	fadd.4s	v5, v5, v18
	fadd.4s	v4, v4, v10
	zip1.8b	v16, v6, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	and.16b	v4, v16, v4
	zip2.8b	v16, v6, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	and.16b	v5, v16, v5
	zip2.8b	v16, v3, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	bit.16b	v5, v7, v16
	zip1.8b	v3, v3, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bsl.16b	v3, v19, v4
	fadd.4s	v3, v9, v3
	fadd.4s	v4, v15, v5
	fadd.4s	v4, v14, v4
	fadd.4s	v3, v13, v3
	fadd.4s	v18, v12, v3
	fadd.4s	v19, v11, v4
	ldr	q3, [sp, #80]                   ; 16-byte Folded Reload
	ldp	q4, q5, [sp, #16]               ; 32-byte Folded Reload
	uzp1.4s	v7, v3, v5
	ldr	q3, [sp, #48]                   ; 16-byte Folded Reload
	uzp1.4s	v28, v4, v3
	movi.4s	v4, #1
	eor.16b	v3, v7, v4
	mov.s	w14, v3[1]
	mov.s	w17, v3[2]
	eor.16b	v25, v28, v4
	mov.s	w0, v3[3]
	fmov	w13, s3
	add	x15, sp, #392
	bfxil	x15, x13, #0, #3
	str	d24, [sp, #392]
	ldrb	w16, [x15]
	and	x15, x13, #0x7
	umov.b	w13, v24[0]
	stp	q18, q19, [sp, #656]
	add	x1, sp, #656
	ldr	s3, [x1, x15, lsl #2]
	ands	w15, w13, #0x1
	tst	w15, w16
	fcsel	s16, s3, s8, ne
	add	x16, sp, #392
	bfxil	x16, x14, #0, #3
	ldrb	w16, [x16]
	and	x1, x14, #0x7
	umov.b	w14, v24[1]
	stp	q18, q19, [sp, #624]
	add	x2, sp, #624
	ldr	s3, [x2, x1, lsl #2]
	ands	w1, w14, #0x1
	tst	w1, w16
	fcsel	s17, s3, s8, ne
	add	x16, sp, #392
	bfxil	x16, x17, #0, #3
	ldrb	w1, [x16]
	umov.b	w16, v24[2]
	and	x17, x17, #0x7
	stp	q18, q19, [sp, #592]
	add	x2, sp, #592
	ldr	s3, [x2, x17, lsl #2]
	ands	w17, w16, #0x1
	tst	w17, w1
	fcsel	s4, s3, s8, ne
	add	x17, sp, #392
	bfxil	x17, x0, #0, #3
	ldrb	w1, [x17]
	and	x0, x0, #0x7
	umov.b	w17, v24[3]
	stp	q18, q19, [sp, #560]
	add	x2, sp, #560
	ldr	s3, [x2, x0, lsl #2]
	ands	w0, w17, #0x1
	tst	w0, w1
	mov.s	w1, v25[1]
	mov.s	w2, v25[2]
	fcsel	s26, s3, s8, ne
	mov.s	w4, v25[3]
	fmov	w0, s25
	and	x20, x0, #0x7
	add	x5, sp, #392
	bfxil	x5, x0, #0, #3
	ldrb	w5, [x5]
	umov.b	w0, v24[4]
	and	w5, w0, w5
	stp	q18, q19, [sp, #784]
	add	x6, sp, #784
	ldr	s3, [x6, x20, lsl #2]
	tst	w5, #0x1
	fcsel	s3, s3, s8, ne
	add	x5, sp, #392
	bfxil	x5, x1, #0, #3
	ldrb	w20, [x5]
	and	x5, x1, #0x7
	umov.b	w1, v24[5]
	stp	q18, q19, [sp, #752]
	add	x6, sp, #752
	ldr	s5, [x6, x5, lsl #2]
	ands	w5, w1, #0x1
	tst	w5, w20
	fcsel	s5, s5, s8, ne
	add	x5, sp, #392
	bfxil	x5, x2, #0, #3
	ldrb	w20, [x5]
	and	x5, x2, #0x7
	umov.b	w2, v24[6]
	stp	q18, q19, [sp, #720]
	add	x6, sp, #720
	ldr	s25, [x6, x5, lsl #2]
	ands	w5, w2, #0x1
	tst	w5, w20
	fcsel	s25, s25, s8, ne
	add	x5, sp, #392
	bfxil	x5, x4, #0, #3
	ldrb	w5, [x5]
	umov.b	w20, v24[7]
	and	x4, x4, #0x7
	stp	q18, q19, [sp, #688]
	add	x6, sp, #688
	ldr	s24, [x6, x4, lsl #2]
	ands	w4, w20, #0x1
	tst	w4, w5
	fcsel	s24, s24, s8, ne
	mov.s	v3[1], v5[0]
	mov.s	v3[2], v25[0]
	mov.s	v3[3], v24[0]
	mov.s	v16[1], v17[0]
	mov.s	v16[2], v4[0]
	mov.s	v16[3], v26[0]
	fadd.4s	v4, v18, v16
	fadd.4s	v3, v19, v3
	movi.4s	v16, #2
	eor.16b	v5, v28, v16
	eor.16b	v7, v7, v16
	fmov	w4, s7
	add	x5, sp, #392
	bfxil	x5, x4, #0, #3
	ldrb	w5, [x5]
	and	x4, x4, #0x7
	stp	q4, q3, [sp, #528]
	add	x6, sp, #528
	ldr	s7, [x6, x4, lsl #2]
	tst	w15, w5
	fcsel	s7, s7, s8, ne
	fmov	w4, s5
	and	x5, x4, #0x7
	add	x6, sp, #392
	bfxil	x6, x4, #0, #3
	ldrb	w4, [x6]
	and	w4, w0, w4
	stp	q4, q3, [sp, #496]
	add	x6, sp, #496
	ldr	s5, [x6, x5, lsl #2]
	tst	w4, #0x1
	fcsel	s5, s5, s8, ne
	fadd.4s	v3, v3, v5
	tst	w15, w0
	fcsel	s3, s3, s8, ne
	ands	w13, w13, #0x1
	fadd.4s	v4, v4, v7
	fadd	s3, s4, s3
	fcsel	s4, s3, s8, ne
	tst	w14, #0x1
	fcsel	s5, s4, s8, ne
	tst	w16, #0x1
	fcsel	s7, s4, s8, ne
	tst	w17, #0x1
	fcsel	s16, s4, s8, ne
	tst	w13, w0
	fcsel	s3, s3, s8, ne
	tst	w1, #0x1
	fcsel	s17, s4, s8, ne
	tst	w2, #0x1
	fcsel	s18, s4, s8, ne
	tst	w20, #0x1
Lloh24:
	adrp	x13, lCPI0_12@PAGE
Lloh25:
	ldr	d19, [x13, lCPI0_12@PAGEOFF]
	shl.8b	v24, v6, #7
	cmlt.8b	v24, v24, #0
	and.8b	v19, v24, v19
	addv.8b	b24, v19
	fmov	w13, s24
	fcsel	s19, s4, s8, ne
	mov.s	v4[1], v5[0]
	mov.s	v4[2], v7[0]
	mov.s	v4[3], v16[0]
	mov.s	v3[1], v17[0]
	mov.s	v3[2], v18[0]
	mov.s	v3[3], v19[0]
	rbit	w11, w11
	clz	w11, w11
	stp	q4, q3, [sp, #464]
	and	x11, x11, #0x7
	add	x14, sp, #464
	ldr	s19, [x14, x11, lsl #2]
	mov	b3, v6[0]
	mov.b	v3[4], v6[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	mov	b4, v6[2]
	mov.b	v4[4], v6[3]
	ldp	q16, q5, [sp, #176]             ; 32-byte Folded Reload
	and.16b	v3, v3, v5
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldp	q5, q7, [sp, #144]              ; 32-byte Folded Reload
	and.16b	v4, v4, v5
	mov	b5, v6[4]
	mov.b	v5[4], v6[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	and.16b	v5, v5, v7
	mov	b7, v6[6]
	mov.b	v7[4], v6[7]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v16
	stp	q5, q7, [sp, #432]
	stp	q3, q4, [sp, #400]
	and	x11, x9, #0x7
	add	x14, sp, #400
	ldr	x11, [x14, x11, lsl #3]
	sub	x11, x11, x9
	add	x10, x10, x11, lsl #2
	movi.2d	v7, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w13, #0, LBB0_120
; %bb.79:                               ; %else288
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w13, #1, LBB0_121
LBB0_80:                                ; %else291
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w13, #2, LBB0_122
LBB0_81:                                ; %else294
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w13, #3, LBB0_123
LBB0_82:                                ; %else297
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w13, #4, LBB0_124
LBB0_83:                                ; %else300
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w13, #5, LBB0_125
LBB0_84:                                ; %else303
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w13, #6, LBB0_126
LBB0_85:                                ; %else306
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w13, #7, LBB0_87
LBB0_86:                                ; %cond.load308
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x10, x10, #28
	ld1.s	{ v18 }[3], [x10]
LBB0_87:                                ; %else309
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x11, #0                         ; =0x0
	fadd	s3, s19, s8
	mov	w10, #16384                     ; =0x4000
	movk	w10, #17600, lsl #16
	fmov	s4, w10
	fdiv	s3, s3, s4
	add	x10, x24, x12
	ldp	q4, q5, [x10]
	zip2.8b	v16, v6, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	bit.16b	v5, v18, v16
	zip1.8b	v6, v6, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bit.16b	v4, v7, v6
	stp	q4, q5, [x10]
	mov	w10, #50604                     ; =0xc5ac
	movk	w10, #14119, lsl #16
	fmov	s4, w10
	fadd	s3, s3, s4
	fsqrt	s3, s3
	dup.4s	v6, v3[0]
	ldr	q3, [sp, #208]                  ; 16-byte Folded Reload
	fmov	x10, d3
	add	x10, x8, x10, lsl #2
	movi.2d	v4, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v19, #0000000000000000
	b	LBB0_89
LBB0_88:                                ; %else326
                                        ;   in Loop: Header=BB0_89 Depth=2
	add.2d	v16, v16, v21
	add.2d	v17, v17, v22
	add.2d	v19, v19, v20
	add.2d	v4, v4, v23
	fmov	x11, d4
	cmp	x11, #192
	b.ge	LBB0_105
LBB0_89:                                ; %direct.true119.i213.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w12, s2
	lsl	x11, x11, #5
	add	x13, x19, x11
	ldp	q3, q25, [x13]
	and.16b	v3, v1, v3
	fdiv.4s	v3, v3, v6
	add	x13, x24, x11
	ldp	q5, q26, [x13]
	and.16b	v5, v1, v5
	fmul.4s	v27, v3, v5
	add	x11, x10, x11
	tbnz	w12, #0, LBB0_97
; %bb.90:                               ; %else312
                                        ;   in Loop: Header=BB0_89 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_98
LBB0_91:                                ; %else314
                                        ;   in Loop: Header=BB0_89 Depth=2
	tbnz	w12, #2, LBB0_99
LBB0_92:                                ; %else316
                                        ;   in Loop: Header=BB0_89 Depth=2
	tbnz	w12, #3, LBB0_100
LBB0_93:                                ; %else318
                                        ;   in Loop: Header=BB0_89 Depth=2
	and.16b	v3, v0, v25
	fdiv.4s	v3, v3, v6
	and.16b	v5, v0, v26
	fmul.4s	v25, v3, v5
	tbnz	w12, #4, LBB0_101
LBB0_94:                                ; %else320
                                        ;   in Loop: Header=BB0_89 Depth=2
	tbnz	w12, #5, LBB0_102
LBB0_95:                                ; %else322
                                        ;   in Loop: Header=BB0_89 Depth=2
	tbnz	w12, #6, LBB0_103
LBB0_96:                                ; %else324
                                        ;   in Loop: Header=BB0_89 Depth=2
	tbz	w12, #7, LBB0_88
	b	LBB0_104
LBB0_97:                                ; %cond.store
                                        ;   in Loop: Header=BB0_89 Depth=2
	str	s27, [x11]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_91
LBB0_98:                                ; %cond.store313
                                        ;   in Loop: Header=BB0_89 Depth=2
	add	x13, x11, #4
	st1.s	{ v27 }[1], [x13]
	tbz	w12, #2, LBB0_92
LBB0_99:                                ; %cond.store315
                                        ;   in Loop: Header=BB0_89 Depth=2
	add	x13, x11, #8
	st1.s	{ v27 }[2], [x13]
	tbz	w12, #3, LBB0_93
LBB0_100:                               ; %cond.store317
                                        ;   in Loop: Header=BB0_89 Depth=2
	add	x13, x11, #12
	st1.s	{ v27 }[3], [x13]
	and.16b	v3, v0, v25
	fdiv.4s	v3, v3, v6
	and.16b	v5, v0, v26
	fmul.4s	v25, v3, v5
	tbz	w12, #4, LBB0_94
LBB0_101:                               ; %cond.store319
                                        ;   in Loop: Header=BB0_89 Depth=2
	str	s25, [x11, #16]
	tbz	w12, #5, LBB0_95
LBB0_102:                               ; %cond.store321
                                        ;   in Loop: Header=BB0_89 Depth=2
	add	x13, x11, #20
	st1.s	{ v25 }[1], [x13]
	tbz	w12, #6, LBB0_96
LBB0_103:                               ; %cond.store323
                                        ;   in Loop: Header=BB0_89 Depth=2
	add	x13, x11, #24
	st1.s	{ v25 }[2], [x13]
	tbz	w12, #7, LBB0_88
LBB0_104:                               ; %cond.store325
                                        ;   in Loop: Header=BB0_89 Depth=2
	add	x11, x11, #28
	st1.s	{ v25 }[3], [x11]
	b	LBB0_88
LBB0_105:                               ; %direct.false120.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	fdiv.4s	v0, v30, v6
	fmul.4s	v0, v0, v7
	ldr	q2, [sp, #288]                  ; 16-byte Folded Reload
	ldp	q4, q3, [sp, #224]              ; 32-byte Folded Reload
	stp	q2, q3, [sp, #320]
	ldr	q1, [sp, #256]                  ; 16-byte Folded Reload
	stp	q4, q1, [sp, #352]
	and	x10, x9, #0x7
	add	x11, sp, #320
	ldr	x10, [x11, x10, lsl #3]
	sub	x9, x10, x9
	add	x8, x8, x9, lsl #2
	fmov	w9, s24
	tbnz	w9, #0, LBB0_127
; %bb.106:                              ; %else329
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #1, LBB0_128
LBB0_107:                               ; %else331
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #2, LBB0_129
LBB0_108:                               ; %else333
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #3, LBB0_130
LBB0_109:                               ; %else335
                                        ;   in Loop: Header=BB0_4 Depth=1
	fdiv.4s	v0, v29, v6
	fmul.4s	v0, v0, v18
	tbnz	w9, #4, LBB0_131
LBB0_110:                               ; %else337
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #5, LBB0_132
LBB0_111:                               ; %else339
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #6, LBB0_133
LBB0_112:                               ; %else341
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w9, #7, LBB0_2
	b	LBB0_134
LBB0_113:                               ; %cond.load237
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	s5, [x12]
	tbz	w13, #1, LBB0_51
LBB0_114:                               ; %cond.load240
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x14, x12, #4
	ld1.s	{ v5 }[1], [x14]
	tbz	w13, #2, LBB0_52
LBB0_115:                               ; %cond.load243
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x14, x12, #8
	ld1.s	{ v5 }[2], [x14]
	tbz	w13, #3, LBB0_53
LBB0_116:                               ; %cond.load246
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x14, x12, #12
	ld1.s	{ v5 }[3], [x14]
	tbz	w13, #4, LBB0_54
LBB0_117:                               ; %cond.load249
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x14, x12, #16
	ld1.s	{ v3 }[0], [x14]
	tbz	w13, #5, LBB0_55
LBB0_118:                               ; %cond.load252
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x14, x12, #20
	ld1.s	{ v3 }[1], [x14]
	tbz	w13, #6, LBB0_56
LBB0_119:                               ; %cond.load255
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x14, x12, #24
	ld1.s	{ v3 }[2], [x14]
	tbnz	w13, #7, LBB0_57
	b	LBB0_58
LBB0_120:                               ; %cond.load287
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	s7, [x10]
	tbz	w13, #1, LBB0_80
LBB0_121:                               ; %cond.load290
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #4
	ld1.s	{ v7 }[1], [x11]
	tbz	w13, #2, LBB0_81
LBB0_122:                               ; %cond.load293
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #8
	ld1.s	{ v7 }[2], [x11]
	tbz	w13, #3, LBB0_82
LBB0_123:                               ; %cond.load296
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #12
	ld1.s	{ v7 }[3], [x11]
	tbz	w13, #4, LBB0_83
LBB0_124:                               ; %cond.load299
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #16
	ld1.s	{ v18 }[0], [x11]
	tbz	w13, #5, LBB0_84
LBB0_125:                               ; %cond.load302
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #20
	ld1.s	{ v18 }[1], [x11]
	tbz	w13, #6, LBB0_85
LBB0_126:                               ; %cond.load305
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #24
	ld1.s	{ v18 }[2], [x11]
	tbnz	w13, #7, LBB0_86
	b	LBB0_87
LBB0_127:                               ; %cond.store328
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s0, [x8]
	tbz	w9, #1, LBB0_107
LBB0_128:                               ; %cond.store330
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x10, x8, #4
	st1.s	{ v0 }[1], [x10]
	tbz	w9, #2, LBB0_108
LBB0_129:                               ; %cond.store332
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x10, x8, #8
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #3, LBB0_109
LBB0_130:                               ; %cond.store334
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x10, x8, #12
	st1.s	{ v0 }[3], [x10]
	fdiv.4s	v0, v29, v6
	fmul.4s	v0, v0, v18
	tbz	w9, #4, LBB0_110
LBB0_131:                               ; %cond.store336
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s0, [x8, #16]
	tbz	w9, #5, LBB0_111
LBB0_132:                               ; %cond.store338
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x10, x8, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w9, #6, LBB0_112
LBB0_133:                               ; %cond.store340
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x10, x8, #24
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_2
LBB0_134:                               ; %cond.store342
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
	b	LBB0_2
LBB0_135:                               ; %block.batch.exit.loopexit
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	stp	w7, w13, [x9]
	str	w12, [x9, #8]
	mov	w8, #24                         ; =0x18
	str	w8, [x9, #36]
LBB0_136:                               ; %block.batch.exit
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #1040
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh24, Lloh25
                                        ; -- End function
.subsections_via_symbols

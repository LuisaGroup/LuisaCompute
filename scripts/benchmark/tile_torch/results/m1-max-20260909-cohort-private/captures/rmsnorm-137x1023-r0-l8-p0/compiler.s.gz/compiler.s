	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_1:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_2:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_4:
	.quad	32                              ; 0x20
	.quad	36                              ; 0x24
lCPI0_5:
	.quad	40                              ; 0x28
	.quad	44                              ; 0x2c
lCPI0_6:
	.quad	48                              ; 0x30
	.quad	52                              ; 0x34
lCPI0_7:
	.quad	56                              ; 0x38
	.quad	60                              ; 0x3c
lCPI0_8:
	.quad	64                              ; 0x40
	.quad	68                              ; 0x44
lCPI0_9:
	.quad	72                              ; 0x48
	.quad	76                              ; 0x4c
lCPI0_10:
	.quad	80                              ; 0x50
	.quad	84                              ; 0x54
lCPI0_11:
	.quad	88                              ; 0x58
	.quad	92                              ; 0x5c
lCPI0_12:
	.quad	96                              ; 0x60
	.quad	100                             ; 0x64
lCPI0_13:
	.quad	104                             ; 0x68
	.quad	108                             ; 0x6c
lCPI0_14:
	.quad	112                             ; 0x70
	.quad	116                             ; 0x74
lCPI0_15:
	.quad	120                             ; 0x78
	.quad	124                             ; 0x7c
lCPI0_16:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_17:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_18:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_19:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_20:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_21:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_22:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_23:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #1376
	str	x0, [sp, #336]                  ; 8-byte Folded Spill
	str	w3, [sp, #360]                  ; 4-byte Folded Spill
	cbz	w3, LBB0_267
; %bb.1:                                ; %block.batch.loop.preheader
	mov	w16, #0                         ; =0x0
	add	x8, sp, #1376
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1376
	ldp	w11, w9, [x2, #44]
	str	w11, [sp, #356]                 ; 4-byte Folded Spill
	str	w9, [sp, #352]                  ; 4-byte Folded Spill
	mov	w17, #4092                      ; =0xffc
	mov	w15, #4                         ; =0x4
	adrp	x5, lCPI0_1@PAGE
	dup.2d	v0, x8
	adrp	x1, lCPI0_3@PAGE
	adrp	x6, lCPI0_5@PAGE
	adrp	x7, lCPI0_6@PAGE
	dup.2d	v1, x10
	adrp	x19, lCPI0_7@PAGE
	adrp	x4, lCPI0_8@PAGE
	adrp	x20, lCPI0_9@PAGE
	adrp	x21, lCPI0_10@PAGE
	dup.2d	v2, x15
	str	q2, [sp, #304]                  ; 16-byte Folded Spill
	adrp	x22, lCPI0_11@PAGE
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_0@PAGEOFF]
	adrp	x23, lCPI0_12@PAGE
	adrp	x24, lCPI0_13@PAGE
	adrp	x25, lCPI0_14@PAGE
	adrp	x26, lCPI0_15@PAGE
	mov	w27, #1                         ; =0x1
	ldp	w8, w9, [x2]
	ldp	w11, w12, [x2, #8]
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	str	x12, [sp, #344]                 ; 8-byte Folded Spill
	str	q3, [sp, #608]                  ; 16-byte Folded Spill
	b	LBB0_3
LBB0_2:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	w8, w0, #1
	ldr	w9, [sp, #356]                  ; 4-byte Folded Reload
	cmp	w8, w9
	cset	w9, eq
	csinc	w8, wzr, w0, eq
	cinc	w11, w14, eq
	ldr	w12, [sp, #352]                 ; 4-byte Folded Reload
	cmp	w11, w12
	cset	w12, eq
	ands	w12, w9, w12
	csel	w9, wzr, w11, ne
	add	w11, w13, w12
	add	w16, w16, #1
	ldr	w12, [sp, #360]                 ; 4-byte Folded Reload
	cmp	w16, w12
	b.eq	LBB0_266
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_39 Depth 2
                                        ;       Child Loop BB0_40 Depth 3
                                        ;       Child Loop BB0_42 Depth 3
                                        ;       Child Loop BB0_44 Depth 3
                                        ;       Child Loop BB0_46 Depth 3
                                        ;     Child Loop BB0_52 Depth 2
                                        ;     Child Loop BB0_79 Depth 2
                                        ;     Child Loop BB0_145 Depth 2
                                        ;     Child Loop BB0_190 Depth 2
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_7 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_11 Depth 2
                                        ;     Child Loop BB0_13 Depth 2
                                        ;     Child Loop BB0_15 Depth 2
                                        ;     Child Loop BB0_17 Depth 2
                                        ;     Child Loop BB0_19 Depth 2
                                        ;     Child Loop BB0_21 Depth 2
                                        ;     Child Loop BB0_23 Depth 2
                                        ;     Child Loop BB0_25 Depth 2
                                        ;     Child Loop BB0_27 Depth 2
                                        ;     Child Loop BB0_29 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_33 Depth 2
                                        ;     Child Loop BB0_35 Depth 2
	str	w11, [sp, #372]                 ; 4-byte Folded Spill
	mov	x14, x9
	mov	x0, x8
	ubfiz	x8, x8, #5, #32
	ldr	x13, [sp, #344]                 ; 8-byte Folded Reload
	cmp	x8, x13
	csel	x9, x8, xzr, ls
	subs	x11, x13, x9
	cmp	x11, #32
	mov	w12, #32                        ; =0x20
	csel	x11, x11, x12, lo
	cmp	x13, x9
	ccmp	x8, x13, #2, hi
	csel	x9, x11, xzr, ls
	cmp	x9, #32
	str	w14, [sp, #368]                 ; 4-byte Folded Spill
	str	x0, [sp, #376]                  ; 8-byte Folded Spill
	b.lo	LBB0_37
; %bb.4:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #336]                  ; 8-byte Folded Reload
	ldr	x11, [x9]
	ldr	x3, [x9, #16]
	ldr	x9, [x9, #48]
	str	x9, [sp, #592]                  ; 8-byte Folded Spill
	ubfiz	w9, w0, #2, #27
	umull	x13, w9, w17
	str	w9, [sp, #464]                  ; 4-byte Folded Spill
	umaddl	x9, w9, w17, x11
LBB0_5:                                 ; %direct.true.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x9, x8
	ldp	q2, q4, [x14]
	add	x14, x10, x8
	stp	q2, q4, [x14]
	add	x8, x8, #32
	cmp	x8, #4064
	b.ne	LBB0_5
; %bb.6:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x13, #4064
	str	x11, [sp, #480]                 ; 8-byte Folded Spill
	mov	x17, x8
	add	x8, x11, x8
	add	x14, x8, #4
	add	x0, x8, #8
	add	x28, x8, #12
	add	x30, x8, #20
	add	x11, x8, #24
	ldr	s2, [x8]
	ld1.s	{ v2 }[1], [x14]
	ld1.s	{ v2 }[2], [x0]
	ld1.s	{ v2 }[3], [x28]
	ldr	s4, [x8, #16]
	ld1.s	{ v4 }[1], [x30]
	ld1.s	{ v4 }[2], [x11]
	add	x8, x10, #4092
	ld1.s	{ v4 }[3], [x8]
	str	q2, [sp, #672]                  ; 16-byte Folded Spill
	str	q2, [sp, #9536]
	str	q4, [sp, #528]                  ; 16-byte Folded Spill
	str	q4, [sp, #9552]
	ldr	q2, [sp, #5472]
	ldr	q4, [sp, #5488]
	fmul.4s	v10, v4, v4
	fmul.4s	v9, v2, v2
	ldr	q2, [sp, #5504]
	ldr	q4, [sp, #5520]
	fmul.4s	v8, v4, v4
	fmul.4s	v31, v2, v2
	ldr	q2, [sp, #5536]
	ldr	q4, [sp, #5552]
	fmul.4s	v7, v4, v4
	fmul.4s	v11, v2, v2
	ldr	q2, [sp, #5568]
	ldr	q4, [sp, #5584]
	fmul.4s	v5, v4, v4
	fmul.4s	v6, v2, v2
	ldr	q15, [sp, #304]                 ; 16-byte Folded Reload
	mov.16b	v12, v15
	mov.16b	v13, v15
	mov.16b	v14, v15
	adrp	x9, lCPI0_2@PAGE
	adrp	x12, lCPI0_4@PAGE
LBB0_7:                                 ; %direct.true59.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v2, v12, #5
	add.2d	v28, v1, v2
	ldr	q2, [sp, #608]                  ; 16-byte Folded Reload
	add.2d	v19, v28, v2
	mov.d	x8, v19[1]
	ldr	q25, [x5, lCPI0_1@PAGEOFF]
	shl.2d	v2, v13, #5
	add.2d	v30, v1, v2
	add.2d	v20, v30, v25
	mov.d	x11, v20[1]
	ldr	q17, [x9, lCPI0_2@PAGEOFF]
	shl.2d	v2, v14, #5
	add.2d	v2, v1, v2
	add.2d	v21, v2, v17
	mov.d	x14, v21[1]
	ldr	q18, [x1, lCPI0_3@PAGEOFF]
	shl.2d	v4, v15, #5
	add.2d	v4, v1, v4
	add.2d	v22, v4, v18
	mov.d	x0, v22[1]
	fmov	x28, d19
	ldr	s19, [x28]
	fmov	x28, d20
	fmov	x30, d21
	ld1.s	{ v19 }[1], [x8]
	fmov	x8, d22
	ld1.s	{ v19 }[2], [x28]
	ld1.s	{ v19 }[3], [x11]
	ldr	s20, [x30]
	ld1.s	{ v20 }[1], [x14]
	ld1.s	{ v20 }[2], [x8]
	ld1.s	{ v20 }[3], [x0]
	fmul.4s	v20, v20, v20
	fmul.4s	v19, v19, v19
	fadd.4s	v9, v9, v19
	fadd.4s	v10, v10, v20
	ldr	q21, [x12, lCPI0_4@PAGEOFF]
	ldr	q22, [x6, lCPI0_5@PAGEOFF]
	ldr	q26, [x7, lCPI0_6@PAGEOFF]
	ldr	q27, [x19, lCPI0_7@PAGEOFF]
	add.2d	v19, v4, v27
	add.2d	v20, v2, v26
	add.2d	v23, v30, v22
	add.2d	v24, v28, v21
	mov.d	x8, v24[1]
	fmov	x11, d24
	mov.d	x14, v23[1]
	fmov	x0, d23
	mov.d	x28, v20[1]
	fmov	x30, d20
	mov.d	x2, v19[1]
	ldr	s20, [x11]
	ld1.s	{ v20 }[1], [x8]
	ld1.s	{ v20 }[2], [x0]
	ld1.s	{ v20 }[3], [x14]
	fmov	x8, d19
	ldr	s19, [x30]
	ld1.s	{ v19 }[1], [x28]
	ld1.s	{ v19 }[2], [x8]
	ld1.s	{ v19 }[3], [x2]
	fmul.4s	v19, v19, v19
	fmul.4s	v20, v20, v20
	fadd.4s	v31, v31, v20
	fadd.4s	v8, v8, v19
	ldr	q24, [x4, lCPI0_8@PAGEOFF]
	ldr	q23, [x20, lCPI0_9@PAGEOFF]
	ldr	q29, [x21, lCPI0_10@PAGEOFF]
	ldr	q3, [x22, lCPI0_11@PAGEOFF]
	add.2d	v19, v4, v3
	add.2d	v20, v28, v24
	mov.d	x8, v20[1]
	fmov	x11, d20
	add.2d	v20, v30, v23
	mov.d	x14, v20[1]
	fmov	x0, d20
	add.2d	v20, v2, v29
	mov.d	x2, v20[1]
	mov.d	x28, v19[1]
	fmov	x30, d20
	ldr	s20, [x11]
	ld1.s	{ v20 }[1], [x8]
	ld1.s	{ v20 }[2], [x0]
	fmov	x8, d19
	ld1.s	{ v20 }[3], [x14]
	ldr	s19, [x30]
	ld1.s	{ v19 }[1], [x2]
	ld1.s	{ v19 }[2], [x8]
	ld1.s	{ v19 }[3], [x28]
	fmul.4s	v19, v19, v19
	fmul.4s	v20, v20, v20
	fadd.4s	v11, v11, v20
	fadd.4s	v7, v7, v19
	ldr	q20, [x23, lCPI0_12@PAGEOFF]
	add.2d	v19, v28, v20
	mov.d	x8, v19[1]
	ldr	q28, [x24, lCPI0_13@PAGEOFF]
	fmov	x11, d19
	ldr	q16, [x25, lCPI0_14@PAGEOFF]
	add.2d	v19, v30, v28
	mov.d	x14, v19[1]
	fmov	x0, d19
	mov.16b	v19, v16
	ldr	q16, [x26, lCPI0_15@PAGEOFF]
	add.2d	v4, v4, v16
	add.2d	v2, v2, v19
	mov.d	x2, v2[1]
	fmov	x28, d2
	mov.d	x30, v4[1]
	ldr	s2, [x11]
	ld1.s	{ v2 }[1], [x8]
	fmov	x8, d4
	ld1.s	{ v2 }[2], [x0]
	ld1.s	{ v2 }[3], [x14]
	fmul.4s	v2, v2, v2
	fadd.4s	v6, v6, v2
	ldr	s2, [x28]
	ld1.s	{ v2 }[1], [x2]
	ld1.s	{ v2 }[2], [x8]
	ld1.s	{ v2 }[3], [x30]
	fmul.4s	v2, v2, v2
	fadd.4s	v5, v5, v2
	dup.2d	v2, x15
	add.2d	v14, v14, v2
	add.2d	v13, v13, v2
	add.2d	v15, v15, v2
	add.2d	v12, v12, v2
	fmov	x8, d12
	cmp	x8, #124
	b.lt	LBB0_7
; %bb.8:                                ; %direct.false60.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	stp	q3, q29, [sp, #560]             ; 32-byte Folded Spill
	stp	q23, q24, [sp, #624]            ; 32-byte Folded Spill
	str	q27, [sp, #656]                 ; 16-byte Folded Spill
	mov.16b	v30, v26
	stp	q16, q19, [sp, #496]            ; 32-byte Folded Spill
	str	q20, [sp, #544]                 ; 16-byte Folded Spill
	stp	q22, q21, [sp, #688]            ; 32-byte Folded Spill
	mov	x8, #0                          ; =0x0
	ldr	q24, [sp, #9456]
	ldr	q27, [sp, #9440]
	ldr	q23, [sp, #9488]
	ldr	q26, [sp, #9472]
	movi.2d	v13, #0000000000000000
	movi.2d	v15, #0000000000000000
	ldr	q29, [sp, #9520]
	movi.2d	v2, #0000000000000000
	movi.2d	v4, #0000000000000000
	ldr	q3, [sp, #9504]
	str	q3, [sp, #448]                  ; 16-byte Folded Spill
	mov.16b	v16, v25
	ldr	q3, [sp, #608]                  ; 16-byte Folded Reload
LBB0_9:                                 ; %direct.true97.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, x3, x8, lsl #5
	ldp	q20, q19, [x8]
	shl.2d	v12, v13, #5
	shl.2d	v14, v15, #5
	shl.2d	v21, v2, #5
	shl.2d	v22, v4, #5
	add.2d	v22, v22, v18
	add.2d	v22, v0, v22
	add.2d	v21, v21, v17
	add.2d	v14, v14, v16
	add.2d	v12, v12, v3
	add.2d	v12, v0, v12
	mov.d	x8, v12[1]
	fmov	x11, d12
	str	s20, [x11]
	st1.s	{ v20 }[1], [x8]
	add.2d	v12, v0, v14
	mov.d	x8, v12[1]
	fmov	x11, d12
	st1.s	{ v20 }[2], [x11]
	add.2d	v21, v0, v21
	st1.s	{ v20 }[3], [x8]
	mov.d	x8, v21[1]
	fmov	x11, d21
	str	s19, [x11]
	st1.s	{ v19 }[1], [x8]
	mov.d	x8, v22[1]
	fmov	x11, d22
	st1.s	{ v19 }[2], [x11]
	st1.s	{ v19 }[3], [x8]
	dup.2d	v19, x27
	add.2d	v2, v2, v19
	add.2d	v15, v15, v19
	add.2d	v4, v4, v19
	add.2d	v13, v13, v19
	fmov	x8, d13
	cmp	x8, #127
	b.lt	LBB0_9
; %bb.10:                               ; %direct.false98.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	fmul.4s	v2, v27, v27
	fmul.4s	v4, v24, v24
	fadd.4s	v4, v10, v4
	fadd.4s	v2, v9, v2
	fmul.4s	v19, v26, v26
	fmul.4s	v20, v23, v23
	fadd.4s	v20, v8, v20
	fadd.4s	v19, v31, v19
	fmul.4s	v21, v29, v29
	ldr	q22, [sp, #448]                 ; 16-byte Folded Reload
	fmul.4s	v22, v22, v22
	fadd.4s	v22, v11, v22
	fadd.4s	v7, v7, v21
	ldr	q21, [sp, #528]                 ; 16-byte Folded Reload
	fmul.4s	v21, v21, v21
	ldr	q23, [sp, #672]                 ; 16-byte Folded Reload
	fmul.4s	v31, v23, v23
	fadd.4s	v21, v21, v4
	mov.s	v21[3], v4[3]
	fadd.4s	v2, v31, v2
	fadd.4s	v2, v19, v2
	fadd.4s	v4, v20, v21
	fadd.4s	v4, v7, v4
	fadd.4s	v2, v22, v2
	fadd.4s	v2, v6, v2
	fadd.4s	v4, v5, v4
	rev64.4s	v5, v4
	rev64.4s	v6, v2
	fadd.4s	v4, v4, v5
	dup.4s	v5, v4[2]
	fadd.4s	v2, v2, v6
	dup.4s	v6, v2[2]
	fadd.4s	v2, v2, v6
	fadd.4s	v4, v4, v5
	fadd.4s	v2, v2, v4
	movi	d4, #0000000000000000
	fadd	s2, s2, s4
	mov	w9, #49152                      ; =0xc000
	movk	w9, #17535, lsl #16
	fmov	s4, w9
	fdiv	s5, s2, s4
	add	x14, x3, #4064
	add	x11, x3, #4068
	add	x0, x3, #4072
	add	x2, x3, #4076
	ldr	s2, [x3, #4064]
	ld1.s	{ v2 }[1], [x11]
	ld1.s	{ v2 }[2], [x0]
	add	x11, x3, #4084
	ld1.s	{ v2 }[3], [x2]
	ldr	s4, [x3, #4080]
	ld1.s	{ v4 }[1], [x11]
	add	x11, x3, #4088
	ld1.s	{ v4 }[2], [x11]
	add	x9, sp, #1376
	add	x11, x9, #4092
	ld1.s	{ v4 }[3], [x11]
	str	q2, [sp, #5440]
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s6, w9
	fadd	s5, s5, s6
	fsqrt	s5, s5
	dup.4s	v6, v5[0]
	str	q4, [sp, #5456]
	ldr	x9, [sp, #592]                  ; 8-byte Folded Reload
	add	x13, x9, x13
	movi.2d	v7, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v31, #0000000000000000
	ldr	q25, [sp, #640]                 ; 16-byte Folded Reload
LBB0_11:                                ; %direct.true121.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v21, v31, #5
	shl.2d	v22, v20, #5
	shl.2d	v8, v19, #5
	shl.2d	v9, v7, #5
	orr.16b	v9, v9, v3
	orr.16b	v8, v8, v16
	orr.16b	v22, v22, v17
	orr.16b	v21, v21, v18
	add.2d	v10, v1, v21
	add.2d	v11, v1, v22
	add.2d	v12, v1, v8
	add.2d	v13, v1, v9
	mov.d	x11, v13[1]
	mov.d	x0, v12[1]
	mov.d	x2, v11[1]
	fmov	x28, d13
	fmov	x30, d11
	mov.d	x12, v10[1]
	fmov	x9, d10
	ldr	s10, [x30]
	ld1.s	{ v10 }[1], [x2]
	ld1.s	{ v10 }[2], [x9]
	ld1.s	{ v10 }[3], [x12]
	fmov	x9, d12
	ldr	s11, [x28]
	ld1.s	{ v11 }[1], [x11]
	ld1.s	{ v11 }[2], [x9]
	ld1.s	{ v11 }[3], [x0]
	fdiv.4s	v11, v11, v6
	fdiv.4s	v10, v10, v6
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v8, v0, v8
	add.2d	v9, v0, v9
	mov.d	x9, v9[1]
	fmov	x11, d9
	mov.d	x12, v8[1]
	mov.d	x0, v22[1]
	mov.d	x2, v21[1]
	fmov	x28, d8
	ldr	s8, [x11]
	ld1.s	{ v8 }[1], [x9]
	ld1.s	{ v8 }[2], [x28]
	fmov	x9, d22
	ld1.s	{ v8 }[3], [x12]
	ldr	s22, [x9]
	ld1.s	{ v22 }[1], [x0]
	fmov	x9, d21
	ld1.s	{ v22 }[2], [x9]
	ld1.s	{ v22 }[3], [x2]
	fmul.4s	v21, v10, v22
	fmul.4s	v22, v11, v8
	add	x8, x13, x8, lsl #5
	stp	q22, q21, [x8]
	dup.2d	v21, x27
	add.2d	v20, v20, v21
	add.2d	v19, v19, v21
	add.2d	v31, v31, v21
	add.2d	v7, v7, v21
	fmov	x8, d7
	cmp	x8, #127
	b.lt	LBB0_11
; %bb.12:                               ; %llm_rows.full_packet.exit.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q28, [sp, #528]                 ; 16-byte Folded Spill
	str	q30, [sp, #672]                 ; 16-byte Folded Spill
	mov	x13, #0                         ; =0x0
	ldr	q6, [sp, #9552]
	ldr	q7, [sp, #9536]
	dup.4s	v5, v5[0]
	fdiv.4s	v7, v7, v5
	fdiv.4s	v5, v6, v5
	fmul.4s	v4, v4, v5
	fmul.4s	v2, v2, v7
	ldr	x8, [sp, #592]                  ; 8-byte Folded Reload
	add	x8, x8, x17
	str	q2, [x8]
	str	d4, [x8, #16]
	add	x8, x8, #24
	st1.s	{ v4 }[2], [x8]
	ldr	w8, [sp, #464]                  ; 4-byte Folded Reload
	orr	w9, w8, #0x1
	mov	w17, #4092                      ; =0xffc
	umull	x8, w9, w17
	ldr	x12, [sp, #480]                 ; 8-byte Folded Reload
	umaddl	x9, w9, w17, x12
LBB0_13:                                ; %direct.true.i8.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x9, x13
	ldp	q2, q4, [x11]
	add	x11, x10, x13
	stp	q2, q4, [x11]
	add	x13, x13, #32
	cmp	x13, #4064
	b.ne	LBB0_13
; %bb.14:                               ; %direct.false.i14.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x8, #4064
	str	x9, [sp, #448]                  ; 8-byte Folded Spill
	add	x11, x12, x9
	add	x12, x11, #4
	add	x13, x11, #8
	add	x0, x11, #12
	ldr	s2, [x11]
	ld1.s	{ v2 }[1], [x12]
	ld1.s	{ v2 }[2], [x13]
	add	x12, x11, #20
	ld1.s	{ v2 }[3], [x0]
	ldr	s4, [x11, #16]
	ld1.s	{ v4 }[1], [x12]
	add	x11, x11, #24
	ld1.s	{ v4 }[2], [x11]
	add	x11, x10, #4092
	ld1.s	{ v4 }[3], [x11]
	stp	q4, q2, [sp, #416]              ; 32-byte Folded Spill
	str	q2, [sp, #9536]
	str	q4, [sp, #9552]
	ldr	q2, [sp, #5472]
	ldr	q4, [sp, #5488]
	fmul.4s	v10, v4, v4
	fmul.4s	v9, v2, v2
	ldr	q2, [sp, #5504]
	ldr	q4, [sp, #5520]
	fmul.4s	v8, v4, v4
	fmul.4s	v31, v2, v2
	ldr	q2, [sp, #5536]
	ldr	q4, [sp, #5552]
	fmul.4s	v7, v4, v4
	fmul.4s	v11, v2, v2
	ldr	q2, [sp, #5568]
	ldr	q4, [sp, #5584]
	fmul.4s	v5, v4, v4
	fmul.4s	v6, v2, v2
	dup.2d	v12, x15
	mov.16b	v13, v12
	mov.16b	v14, v12
	mov.16b	v15, v12
	mov.16b	v28, v25
	ldp	q24, q30, [sp, #560]            ; 32-byte Folded Reload
	ldp	q26, q25, [sp, #528]            ; 32-byte Folded Reload
	ldp	q29, q27, [sp, #496]            ; 32-byte Folded Reload
LBB0_15:                                ; %direct.true59.i26.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v4, v12, #5
	shl.2d	v20, v13, #5
	shl.2d	v21, v14, #5
	shl.2d	v2, v15, #5
	add.2d	v2, v1, v2
	add.2d	v22, v2, v18
	add.2d	v19, v1, v4
	add.2d	v23, v19, v3
	mov.d	x11, v23[1]
	add.2d	v4, v1, v21
	add.2d	v20, v1, v20
	fmov	x12, d23
	add.2d	v21, v20, v16
	mov.d	x13, v21[1]
	fmov	x0, d21
	add.2d	v21, v4, v17
	mov.d	x2, v21[1]
	fmov	x28, d21
	mov.d	x30, v22[1]
	ldr	s21, [x12]
	ld1.s	{ v21 }[1], [x11]
	fmov	x11, d22
	ld1.s	{ v21 }[2], [x0]
	ld1.s	{ v21 }[3], [x13]
	ldr	s22, [x28]
	ld1.s	{ v22 }[1], [x2]
	ld1.s	{ v22 }[2], [x11]
	ld1.s	{ v22 }[3], [x30]
	fmul.4s	v22, v22, v22
	fmul.4s	v21, v21, v21
	fadd.4s	v9, v9, v21
	fadd.4s	v10, v10, v22
	ldr	q21, [sp, #656]                 ; 16-byte Folded Reload
	add.2d	v21, v2, v21
	ldr	q22, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v22, v19, v22
	mov.d	x11, v22[1]
	fmov	x12, d22
	ldr	q22, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v22, v20, v22
	mov.d	x13, v22[1]
	fmov	x0, d22
	ldr	q22, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v22, v4, v22
	mov.d	x2, v22[1]
	mov.d	x28, v21[1]
	fmov	x30, d22
	ldr	s22, [x12]
	ld1.s	{ v22 }[1], [x11]
	ld1.s	{ v22 }[2], [x0]
	fmov	x11, d21
	ld1.s	{ v22 }[3], [x13]
	ldr	s21, [x30]
	ld1.s	{ v21 }[1], [x2]
	ld1.s	{ v21 }[2], [x11]
	ld1.s	{ v21 }[3], [x28]
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	fadd.4s	v31, v31, v22
	fadd.4s	v8, v8, v21
	add.2d	v21, v2, v24
	add.2d	v22, v19, v28
	mov.d	x11, v22[1]
	fmov	x12, d22
	ldr	q22, [sp, #624]                 ; 16-byte Folded Reload
	add.2d	v22, v20, v22
	mov.d	x13, v22[1]
	fmov	x0, d22
	add.2d	v22, v4, v30
	mov.d	x2, v22[1]
	fmov	x28, d22
	mov.d	x30, v21[1]
	ldr	s22, [x12]
	ld1.s	{ v22 }[1], [x11]
	ld1.s	{ v22 }[2], [x0]
	ld1.s	{ v22 }[3], [x13]
	fmov	x11, d21
	fmul.4s	v21, v22, v22
	fadd.4s	v11, v11, v21
	ldr	s21, [x28]
	ld1.s	{ v21 }[1], [x2]
	ld1.s	{ v21 }[2], [x11]
	ld1.s	{ v21 }[3], [x30]
	fmul.4s	v21, v21, v21
	fadd.4s	v7, v7, v21
	add.2d	v20, v20, v26
	add.2d	v19, v19, v25
	mov.d	x11, v19[1]
	mov.d	x12, v20[1]
	fmov	x13, d19
	fmov	x0, d20
	add.2d	v2, v2, v29
	add.2d	v4, v4, v27
	mov.d	x2, v4[1]
	fmov	x28, d4
	mov.d	x30, v2[1]
	ldr	s4, [x13]
	ld1.s	{ v4 }[1], [x11]
	fmov	x11, d2
	ld1.s	{ v4 }[2], [x0]
	ld1.s	{ v4 }[3], [x12]
	fmul.4s	v2, v4, v4
	fadd.4s	v6, v6, v2
	ldr	s2, [x28]
	ld1.s	{ v2 }[1], [x2]
	ld1.s	{ v2 }[2], [x11]
	ld1.s	{ v2 }[3], [x30]
	fmul.4s	v2, v2, v2
	fadd.4s	v5, v5, v2
	dup.2d	v2, x15
	add.2d	v14, v14, v2
	add.2d	v13, v13, v2
	add.2d	v15, v15, v2
	add.2d	v12, v12, v2
	fmov	x11, d12
	cmp	x11, #124
	b.lt	LBB0_15
; %bb.16:                               ; %direct.false60.i32.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x13, #0                         ; =0x0
	ldr	q25, [sp, #9456]
	ldr	q27, [sp, #9440]
	ldr	q24, [sp, #9488]
	ldr	q26, [sp, #9472]
	movi.2d	v13, #0000000000000000
	movi.2d	v15, #0000000000000000
	ldr	q28, [sp, #9520]
	movi.2d	v2, #0000000000000000
	movi.2d	v4, #0000000000000000
	ldr	q14, [sp, #9504]
LBB0_17:                                ; %direct.true97.i39.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x3, x13, lsl #5
	ldp	q22, q21, [x11]
	shl.2d	v23, v13, #5
	shl.2d	v19, v15, #5
	shl.2d	v20, v2, #5
	shl.2d	v12, v4, #5
	add.2d	v12, v12, v18
	add.2d	v12, v0, v12
	add.2d	v20, v20, v17
	add.2d	v19, v19, v16
	add.2d	v23, v23, v3
	add.2d	v23, v0, v23
	mov.d	x11, v23[1]
	fmov	x12, d23
	str	s22, [x12]
	st1.s	{ v22 }[1], [x11]
	add.2d	v19, v0, v19
	mov.d	x11, v19[1]
	fmov	x12, d19
	st1.s	{ v22 }[2], [x12]
	add.2d	v19, v0, v20
	st1.s	{ v22 }[3], [x11]
	mov.d	x11, v19[1]
	fmov	x12, d19
	str	s21, [x12]
	st1.s	{ v21 }[1], [x11]
	mov.d	x11, v12[1]
	fmov	x12, d12
	st1.s	{ v21 }[2], [x12]
	st1.s	{ v21 }[3], [x11]
	dup.2d	v19, x27
	add.2d	v2, v2, v19
	add.2d	v15, v15, v19
	add.2d	v4, v4, v19
	add.2d	v13, v13, v19
	fmov	x13, d13
	cmp	x13, #127
	b.lt	LBB0_17
; %bb.18:                               ; %direct.false98.i43.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x13, #0                         ; =0x0
	fmul.4s	v2, v27, v27
	fmul.4s	v4, v25, v25
	fadd.4s	v4, v10, v4
	fadd.4s	v2, v9, v2
	fmul.4s	v19, v26, v26
	fmul.4s	v20, v24, v24
	fadd.4s	v20, v8, v20
	fadd.4s	v19, v31, v19
	fmul.4s	v21, v28, v28
	fmul.4s	v22, v14, v14
	fadd.4s	v22, v11, v22
	fadd.4s	v7, v7, v21
	ldp	q21, q23, [sp, #416]            ; 32-byte Folded Reload
	fmul.4s	v21, v21, v21
	fmul.4s	v23, v23, v23
	fadd.4s	v2, v23, v2
	fadd.4s	v21, v21, v4
	mov.s	v21[3], v4[3]
	fadd.4s	v2, v19, v2
	fadd.4s	v4, v20, v21
	fadd.4s	v4, v7, v4
	fadd.4s	v2, v22, v2
	fadd.4s	v2, v6, v2
	fadd.4s	v4, v5, v4
	rev64.4s	v5, v4
	rev64.4s	v6, v2
	fadd.4s	v2, v2, v6
	fadd.4s	v4, v4, v5
	dup.4s	v5, v4[2]
	dup.4s	v6, v2[2]
	fadd.4s	v2, v2, v6
	fadd.4s	v4, v4, v5
	fadd.4s	v2, v2, v4
	movi	d4, #0000000000000000
	fadd	s2, s2, s4
	mov	w9, #49152                      ; =0xc000
	movk	w9, #17535, lsl #16
	fmov	s4, w9
	fdiv	s5, s2, s4
	add	x11, x14, #4
	add	x12, x14, #8
	add	x0, x14, #12
	ldr	s2, [x14]
	ld1.s	{ v2 }[1], [x11]
	ld1.s	{ v2 }[2], [x12]
	add	x11, x14, #20
	ld1.s	{ v2 }[3], [x0]
	ldr	s4, [x14, #16]
	ld1.s	{ v4 }[1], [x11]
	add	x11, x14, #24
	ld1.s	{ v4 }[2], [x11]
	add	x9, sp, #1376
	add	x11, x9, #4092
	ld1.s	{ v4 }[3], [x11]
	str	q2, [sp, #5440]
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s6, w9
	fadd	s5, s5, s6
	fsqrt	s5, s5
	dup.4s	v6, v5[0]
	str	q4, [sp, #5456]
	ldr	x9, [sp, #592]                  ; 8-byte Folded Reload
	add	x8, x9, x8
	movi.2d	v7, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v31, #0000000000000000
LBB0_19:                                ; %direct.true121.i51.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v21, v31, #5
	shl.2d	v22, v20, #5
	shl.2d	v23, v19, #5
	shl.2d	v8, v7, #5
	orr.16b	v8, v8, v3
	orr.16b	v23, v23, v16
	orr.16b	v22, v22, v17
	orr.16b	v21, v21, v18
	add.2d	v9, v1, v21
	add.2d	v10, v1, v22
	add.2d	v11, v1, v23
	add.2d	v12, v1, v8
	mov.d	x11, v12[1]
	mov.d	x12, v11[1]
	mov.d	x0, v10[1]
	fmov	x2, d12
	fmov	x28, d10
	mov.d	x30, v9[1]
	fmov	x9, d9
	ldr	s9, [x28]
	ld1.s	{ v9 }[1], [x0]
	ld1.s	{ v9 }[2], [x9]
	ld1.s	{ v9 }[3], [x30]
	fmov	x9, d11
	ldr	s10, [x2]
	ld1.s	{ v10 }[1], [x11]
	ld1.s	{ v10 }[2], [x9]
	ld1.s	{ v10 }[3], [x12]
	fdiv.4s	v10, v10, v6
	fdiv.4s	v9, v9, v6
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v8, v0, v8
	mov.d	x9, v8[1]
	fmov	x11, d8
	mov.d	x12, v23[1]
	mov.d	x0, v22[1]
	mov.d	x2, v21[1]
	fmov	x28, d23
	ldr	s23, [x11]
	ld1.s	{ v23 }[1], [x9]
	ld1.s	{ v23 }[2], [x28]
	fmov	x9, d22
	ld1.s	{ v23 }[3], [x12]
	ldr	s22, [x9]
	ld1.s	{ v22 }[1], [x0]
	fmov	x9, d21
	ld1.s	{ v22 }[2], [x9]
	ld1.s	{ v22 }[3], [x2]
	fmul.4s	v21, v9, v22
	fmul.4s	v22, v10, v23
	add	x9, x8, x13, lsl #5
	stp	q22, q21, [x9]
	dup.2d	v21, x27
	add.2d	v20, v20, v21
	add.2d	v19, v19, v21
	add.2d	v31, v31, v21
	add.2d	v7, v7, v21
	fmov	x13, d7
	cmp	x13, #127
	b.lt	LBB0_19
; %bb.20:                               ; %llm_rows.full_packet.exit57.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x13, #0                         ; =0x0
	ldr	q6, [sp, #9552]
	ldr	q7, [sp, #9536]
	dup.4s	v5, v5[0]
	fdiv.4s	v7, v7, v5
	fdiv.4s	v5, v6, v5
	fmul.4s	v4, v4, v5
	fmul.4s	v2, v2, v7
	ldr	x8, [sp, #592]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #448]                  ; 8-byte Folded Reload
	add	x8, x8, x9
	str	q2, [x8]
	str	d4, [x8, #16]
	add	x8, x8, #24
	st1.s	{ v4 }[2], [x8]
	ldr	w8, [sp, #464]                  ; 4-byte Folded Reload
	orr	w9, w8, #0x2
	umull	x8, w9, w17
	ldr	x12, [sp, #480]                 ; 8-byte Folded Reload
	umaddl	x9, w9, w17, x12
LBB0_21:                                ; %direct.true.i63.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x9, x13
	ldp	q2, q4, [x11]
	add	x11, x10, x13
	stp	q2, q4, [x11]
	add	x13, x13, #32
	cmp	x13, #4064
	b.ne	LBB0_21
; %bb.22:                               ; %direct.false.i69.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x8, #4064
	str	x9, [sp, #448]                  ; 8-byte Folded Spill
	add	x11, x12, x9
	add	x12, x11, #4
	add	x13, x11, #8
	add	x0, x11, #12
	ldr	s2, [x11]
	ld1.s	{ v2 }[1], [x12]
	ld1.s	{ v2 }[2], [x13]
	add	x12, x11, #20
	ld1.s	{ v2 }[3], [x0]
	ldr	s4, [x11, #16]
	ld1.s	{ v4 }[1], [x12]
	add	x11, x11, #24
	ld1.s	{ v4 }[2], [x11]
	add	x11, x10, #4092
	ld1.s	{ v4 }[3], [x11]
	stp	q4, q2, [sp, #416]              ; 32-byte Folded Spill
	str	q2, [sp, #9536]
	str	q4, [sp, #9552]
	ldr	q2, [sp, #5472]
	ldr	q4, [sp, #5488]
	fmul.4s	v10, v4, v4
	fmul.4s	v9, v2, v2
	ldr	q2, [sp, #5504]
	ldr	q4, [sp, #5520]
	fmul.4s	v8, v4, v4
	fmul.4s	v31, v2, v2
	ldr	q2, [sp, #5536]
	ldr	q4, [sp, #5552]
	fmul.4s	v7, v4, v4
	fmul.4s	v11, v2, v2
	ldr	q2, [sp, #5568]
	ldr	q4, [sp, #5584]
	fmul.4s	v5, v4, v4
	fmul.4s	v6, v2, v2
	dup.2d	v12, x15
	mov.16b	v13, v12
	mov.16b	v14, v12
	mov.16b	v15, v12
	ldr	q29, [sp, #624]                 ; 16-byte Folded Reload
	ldp	q24, q30, [sp, #560]            ; 32-byte Folded Reload
	ldp	q26, q25, [sp, #528]            ; 32-byte Folded Reload
	ldp	q28, q27, [sp, #496]            ; 32-byte Folded Reload
LBB0_23:                                ; %direct.true59.i81.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v4, v12, #5
	shl.2d	v20, v13, #5
	shl.2d	v21, v14, #5
	shl.2d	v2, v15, #5
	add.2d	v2, v1, v2
	add.2d	v22, v2, v18
	add.2d	v19, v1, v4
	add.2d	v23, v19, v3
	mov.d	x11, v23[1]
	add.2d	v4, v1, v21
	add.2d	v20, v1, v20
	fmov	x12, d23
	add.2d	v21, v20, v16
	mov.d	x13, v21[1]
	fmov	x0, d21
	add.2d	v21, v4, v17
	mov.d	x2, v21[1]
	fmov	x28, d21
	mov.d	x30, v22[1]
	ldr	s21, [x12]
	ld1.s	{ v21 }[1], [x11]
	fmov	x11, d22
	ld1.s	{ v21 }[2], [x0]
	ld1.s	{ v21 }[3], [x13]
	ldr	s22, [x28]
	ld1.s	{ v22 }[1], [x2]
	ld1.s	{ v22 }[2], [x11]
	ld1.s	{ v22 }[3], [x30]
	fmul.4s	v22, v22, v22
	fmul.4s	v21, v21, v21
	fadd.4s	v9, v9, v21
	fadd.4s	v10, v10, v22
	ldr	q21, [sp, #656]                 ; 16-byte Folded Reload
	add.2d	v21, v2, v21
	ldr	q22, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v22, v19, v22
	mov.d	x11, v22[1]
	fmov	x12, d22
	ldr	q22, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v22, v20, v22
	mov.d	x13, v22[1]
	fmov	x0, d22
	ldr	q22, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v22, v4, v22
	mov.d	x2, v22[1]
	mov.d	x28, v21[1]
	fmov	x30, d22
	ldr	s22, [x12]
	ld1.s	{ v22 }[1], [x11]
	ld1.s	{ v22 }[2], [x0]
	fmov	x11, d21
	ld1.s	{ v22 }[3], [x13]
	ldr	s21, [x30]
	ld1.s	{ v21 }[1], [x2]
	ld1.s	{ v21 }[2], [x11]
	ld1.s	{ v21 }[3], [x28]
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	fadd.4s	v31, v31, v22
	fadd.4s	v8, v8, v21
	add.2d	v21, v2, v24
	ldr	q22, [sp, #640]                 ; 16-byte Folded Reload
	add.2d	v22, v19, v22
	mov.d	x11, v22[1]
	fmov	x12, d22
	add.2d	v22, v20, v29
	mov.d	x13, v22[1]
	fmov	x0, d22
	add.2d	v22, v4, v30
	mov.d	x2, v22[1]
	fmov	x28, d22
	mov.d	x30, v21[1]
	ldr	s22, [x12]
	ld1.s	{ v22 }[1], [x11]
	ld1.s	{ v22 }[2], [x0]
	ld1.s	{ v22 }[3], [x13]
	fmov	x11, d21
	fmul.4s	v21, v22, v22
	fadd.4s	v11, v11, v21
	ldr	s21, [x28]
	ld1.s	{ v21 }[1], [x2]
	ld1.s	{ v21 }[2], [x11]
	ld1.s	{ v21 }[3], [x30]
	fmul.4s	v21, v21, v21
	fadd.4s	v7, v7, v21
	add.2d	v20, v20, v26
	add.2d	v19, v19, v25
	mov.d	x11, v19[1]
	mov.d	x12, v20[1]
	fmov	x13, d19
	fmov	x0, d20
	add.2d	v2, v2, v28
	add.2d	v4, v4, v27
	mov.d	x2, v4[1]
	fmov	x28, d4
	mov.d	x30, v2[1]
	ldr	s4, [x13]
	ld1.s	{ v4 }[1], [x11]
	fmov	x11, d2
	ld1.s	{ v4 }[2], [x0]
	ld1.s	{ v4 }[3], [x12]
	fmul.4s	v2, v4, v4
	fadd.4s	v6, v6, v2
	ldr	s2, [x28]
	ld1.s	{ v2 }[1], [x2]
	ld1.s	{ v2 }[2], [x11]
	ld1.s	{ v2 }[3], [x30]
	fmul.4s	v2, v2, v2
	fadd.4s	v5, v5, v2
	dup.2d	v2, x15
	add.2d	v14, v14, v2
	add.2d	v13, v13, v2
	add.2d	v15, v15, v2
	add.2d	v12, v12, v2
	fmov	x11, d12
	cmp	x11, #124
	b.lt	LBB0_23
; %bb.24:                               ; %direct.false60.i87.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x13, #0                         ; =0x0
	ldr	q25, [sp, #9456]
	ldr	q27, [sp, #9440]
	ldr	q24, [sp, #9488]
	ldr	q26, [sp, #9472]
	movi.2d	v13, #0000000000000000
	movi.2d	v15, #0000000000000000
	ldr	q28, [sp, #9520]
	movi.2d	v2, #0000000000000000
	movi.2d	v4, #0000000000000000
	ldr	q14, [sp, #9504]
LBB0_25:                                ; %direct.true97.i94.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x3, x13, lsl #5
	ldp	q22, q21, [x11]
	shl.2d	v23, v13, #5
	shl.2d	v19, v15, #5
	shl.2d	v20, v2, #5
	shl.2d	v12, v4, #5
	add.2d	v12, v12, v18
	add.2d	v12, v0, v12
	add.2d	v20, v20, v17
	add.2d	v19, v19, v16
	add.2d	v23, v23, v3
	add.2d	v23, v0, v23
	mov.d	x11, v23[1]
	fmov	x12, d23
	str	s22, [x12]
	st1.s	{ v22 }[1], [x11]
	add.2d	v19, v0, v19
	mov.d	x11, v19[1]
	fmov	x12, d19
	st1.s	{ v22 }[2], [x12]
	add.2d	v19, v0, v20
	st1.s	{ v22 }[3], [x11]
	mov.d	x11, v19[1]
	fmov	x12, d19
	str	s21, [x12]
	st1.s	{ v21 }[1], [x11]
	mov.d	x11, v12[1]
	fmov	x12, d12
	st1.s	{ v21 }[2], [x12]
	st1.s	{ v21 }[3], [x11]
	dup.2d	v19, x27
	add.2d	v2, v2, v19
	add.2d	v15, v15, v19
	add.2d	v4, v4, v19
	add.2d	v13, v13, v19
	fmov	x13, d13
	cmp	x13, #127
	b.lt	LBB0_25
; %bb.26:                               ; %direct.false98.i98.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x13, #0                         ; =0x0
	fmul.4s	v2, v27, v27
	fmul.4s	v4, v25, v25
	fadd.4s	v4, v10, v4
	fadd.4s	v2, v9, v2
	fmul.4s	v19, v26, v26
	fmul.4s	v20, v24, v24
	fadd.4s	v20, v8, v20
	fadd.4s	v19, v31, v19
	fmul.4s	v21, v28, v28
	fmul.4s	v22, v14, v14
	fadd.4s	v22, v11, v22
	fadd.4s	v7, v7, v21
	ldp	q21, q23, [sp, #416]            ; 32-byte Folded Reload
	fmul.4s	v21, v21, v21
	fmul.4s	v23, v23, v23
	fadd.4s	v2, v23, v2
	fadd.4s	v21, v21, v4
	mov.s	v21[3], v4[3]
	fadd.4s	v2, v19, v2
	fadd.4s	v4, v20, v21
	fadd.4s	v4, v7, v4
	fadd.4s	v2, v22, v2
	fadd.4s	v2, v6, v2
	fadd.4s	v4, v5, v4
	rev64.4s	v5, v4
	rev64.4s	v6, v2
	fadd.4s	v2, v2, v6
	fadd.4s	v4, v4, v5
	dup.4s	v5, v4[2]
	dup.4s	v6, v2[2]
	fadd.4s	v2, v2, v6
	fadd.4s	v4, v4, v5
	fadd.4s	v2, v2, v4
	movi	d4, #0000000000000000
	fadd	s2, s2, s4
	mov	w9, #49152                      ; =0xc000
	movk	w9, #17535, lsl #16
	fmov	s4, w9
	fdiv	s5, s2, s4
	add	x11, x14, #4
	add	x12, x14, #8
	add	x0, x14, #12
	ldr	s2, [x14]
	ld1.s	{ v2 }[1], [x11]
	ld1.s	{ v2 }[2], [x12]
	add	x11, x14, #20
	ld1.s	{ v2 }[3], [x0]
	ldr	s4, [x14, #16]
	ld1.s	{ v4 }[1], [x11]
	add	x11, x14, #24
	ld1.s	{ v4 }[2], [x11]
	add	x9, sp, #1376
	add	x11, x9, #4092
	ld1.s	{ v4 }[3], [x11]
	str	q2, [sp, #5440]
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s6, w9
	fadd	s5, s5, s6
	fsqrt	s5, s5
	dup.4s	v6, v5[0]
	str	q4, [sp, #5456]
	ldr	x9, [sp, #592]                  ; 8-byte Folded Reload
	add	x8, x9, x8
	movi.2d	v7, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v31, #0000000000000000
LBB0_27:                                ; %direct.true121.i106.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v21, v31, #5
	shl.2d	v22, v20, #5
	shl.2d	v23, v19, #5
	shl.2d	v8, v7, #5
	orr.16b	v8, v8, v3
	orr.16b	v23, v23, v16
	orr.16b	v22, v22, v17
	orr.16b	v21, v21, v18
	add.2d	v9, v1, v21
	add.2d	v10, v1, v22
	add.2d	v11, v1, v23
	add.2d	v12, v1, v8
	mov.d	x11, v12[1]
	mov.d	x12, v11[1]
	mov.d	x0, v10[1]
	fmov	x2, d12
	fmov	x28, d10
	mov.d	x30, v9[1]
	fmov	x9, d9
	ldr	s9, [x28]
	ld1.s	{ v9 }[1], [x0]
	ld1.s	{ v9 }[2], [x9]
	ld1.s	{ v9 }[3], [x30]
	fmov	x9, d11
	ldr	s10, [x2]
	ld1.s	{ v10 }[1], [x11]
	ld1.s	{ v10 }[2], [x9]
	ld1.s	{ v10 }[3], [x12]
	fdiv.4s	v10, v10, v6
	fdiv.4s	v9, v9, v6
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v8, v0, v8
	mov.d	x9, v8[1]
	fmov	x11, d8
	mov.d	x12, v23[1]
	mov.d	x0, v22[1]
	mov.d	x2, v21[1]
	fmov	x28, d23
	ldr	s23, [x11]
	ld1.s	{ v23 }[1], [x9]
	ld1.s	{ v23 }[2], [x28]
	fmov	x9, d22
	ld1.s	{ v23 }[3], [x12]
	ldr	s22, [x9]
	ld1.s	{ v22 }[1], [x0]
	fmov	x9, d21
	ld1.s	{ v22 }[2], [x9]
	ld1.s	{ v22 }[3], [x2]
	fmul.4s	v21, v9, v22
	fmul.4s	v22, v10, v23
	add	x9, x8, x13, lsl #5
	stp	q22, q21, [x9]
	dup.2d	v21, x27
	add.2d	v20, v20, v21
	add.2d	v19, v19, v21
	add.2d	v31, v31, v21
	add.2d	v7, v7, v21
	fmov	x13, d7
	cmp	x13, #127
	b.lt	LBB0_27
; %bb.28:                               ; %llm_rows.full_packet.exit112.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x13, #0                         ; =0x0
	ldr	q6, [sp, #9552]
	ldr	q7, [sp, #9536]
	dup.4s	v5, v5[0]
	fdiv.4s	v7, v7, v5
	fdiv.4s	v5, v6, v5
	fmul.4s	v4, v4, v5
	fmul.4s	v2, v2, v7
	ldr	x8, [sp, #592]                  ; 8-byte Folded Reload
	ldr	x9, [sp, #448]                  ; 8-byte Folded Reload
	add	x8, x8, x9
	str	q2, [x8]
	str	d4, [x8, #16]
	add	x8, x8, #24
	st1.s	{ v4 }[2], [x8]
	ldr	w8, [sp, #464]                  ; 4-byte Folded Reload
	orr	w9, w8, #0x3
	umull	x8, w9, w17
	ldr	x12, [sp, #480]                 ; 8-byte Folded Reload
	umaddl	x9, w9, w17, x12
LBB0_29:                                ; %direct.true.i118.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x9, x13
	ldp	q2, q4, [x11]
	add	x11, x10, x13
	stp	q2, q4, [x11]
	add	x13, x13, #32
	cmp	x13, #4064
	b.ne	LBB0_29
; %bb.30:                               ; %direct.false.i124.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x8, #4064
	add	x11, x12, x9
	add	x12, x11, #4
	add	x13, x11, #8
	add	x0, x11, #12
	ldr	s2, [x11]
	ld1.s	{ v2 }[1], [x12]
	ld1.s	{ v2 }[2], [x13]
	add	x12, x11, #20
	ld1.s	{ v2 }[3], [x0]
	ldr	s4, [x11, #16]
	ld1.s	{ v4 }[1], [x12]
	add	x11, x11, #24
	ld1.s	{ v4 }[2], [x11]
	add	x11, x10, #4092
	ld1.s	{ v4 }[3], [x11]
	stp	q4, q2, [sp, #464]              ; 32-byte Folded Spill
	str	q2, [sp, #9536]
	str	q4, [sp, #9552]
	ldr	q2, [sp, #5472]
	ldr	q4, [sp, #5488]
	fmul.4s	v10, v4, v4
	fmul.4s	v9, v2, v2
	ldr	q2, [sp, #5504]
	ldr	q4, [sp, #5520]
	fmul.4s	v8, v4, v4
	fmul.4s	v31, v2, v2
	ldr	q2, [sp, #5536]
	ldr	q4, [sp, #5552]
	fmul.4s	v7, v4, v4
	fmul.4s	v11, v2, v2
	ldr	q2, [sp, #5568]
	ldr	q4, [sp, #5584]
	fmul.4s	v5, v4, v4
	fmul.4s	v6, v2, v2
	dup.2d	v12, x15
	mov.16b	v13, v12
	mov.16b	v14, v12
	mov.16b	v15, v12
	ldr	q29, [sp, #624]                 ; 16-byte Folded Reload
	ldp	q24, q30, [sp, #560]            ; 32-byte Folded Reload
	ldp	q26, q25, [sp, #528]            ; 32-byte Folded Reload
	ldp	q28, q27, [sp, #496]            ; 32-byte Folded Reload
LBB0_31:                                ; %direct.true59.i136.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v4, v12, #5
	shl.2d	v20, v13, #5
	shl.2d	v21, v14, #5
	shl.2d	v2, v15, #5
	add.2d	v2, v1, v2
	add.2d	v22, v2, v18
	add.2d	v19, v1, v4
	add.2d	v23, v19, v3
	mov.d	x11, v23[1]
	add.2d	v4, v1, v21
	add.2d	v20, v1, v20
	fmov	x12, d23
	add.2d	v21, v20, v16
	mov.d	x13, v21[1]
	fmov	x0, d21
	add.2d	v21, v4, v17
	mov.d	x2, v21[1]
	fmov	x28, d21
	mov.d	x30, v22[1]
	ldr	s21, [x12]
	ld1.s	{ v21 }[1], [x11]
	fmov	x11, d22
	ld1.s	{ v21 }[2], [x0]
	ld1.s	{ v21 }[3], [x13]
	ldr	s22, [x28]
	ld1.s	{ v22 }[1], [x2]
	ld1.s	{ v22 }[2], [x11]
	ld1.s	{ v22 }[3], [x30]
	fmul.4s	v22, v22, v22
	fmul.4s	v21, v21, v21
	fadd.4s	v9, v9, v21
	fadd.4s	v10, v10, v22
	ldr	q21, [sp, #656]                 ; 16-byte Folded Reload
	add.2d	v21, v2, v21
	ldr	q22, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v22, v19, v22
	mov.d	x11, v22[1]
	fmov	x12, d22
	ldr	q22, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v22, v20, v22
	mov.d	x13, v22[1]
	fmov	x0, d22
	ldr	q22, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v22, v4, v22
	mov.d	x2, v22[1]
	mov.d	x28, v21[1]
	fmov	x30, d22
	ldr	s22, [x12]
	ld1.s	{ v22 }[1], [x11]
	ld1.s	{ v22 }[2], [x0]
	fmov	x11, d21
	ld1.s	{ v22 }[3], [x13]
	ldr	s21, [x30]
	ld1.s	{ v21 }[1], [x2]
	ld1.s	{ v21 }[2], [x11]
	ld1.s	{ v21 }[3], [x28]
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	fadd.4s	v31, v31, v22
	fadd.4s	v8, v8, v21
	add.2d	v21, v2, v24
	ldr	q22, [sp, #640]                 ; 16-byte Folded Reload
	add.2d	v22, v19, v22
	mov.d	x11, v22[1]
	fmov	x12, d22
	add.2d	v22, v20, v29
	mov.d	x13, v22[1]
	fmov	x0, d22
	add.2d	v22, v4, v30
	mov.d	x2, v22[1]
	fmov	x28, d22
	mov.d	x30, v21[1]
	ldr	s22, [x12]
	ld1.s	{ v22 }[1], [x11]
	ld1.s	{ v22 }[2], [x0]
	ld1.s	{ v22 }[3], [x13]
	fmov	x11, d21
	fmul.4s	v21, v22, v22
	fadd.4s	v11, v11, v21
	ldr	s21, [x28]
	ld1.s	{ v21 }[1], [x2]
	ld1.s	{ v21 }[2], [x11]
	ld1.s	{ v21 }[3], [x30]
	fmul.4s	v21, v21, v21
	fadd.4s	v7, v7, v21
	add.2d	v20, v20, v26
	add.2d	v19, v19, v25
	mov.d	x11, v19[1]
	mov.d	x12, v20[1]
	fmov	x13, d19
	fmov	x0, d20
	add.2d	v2, v2, v28
	add.2d	v4, v4, v27
	mov.d	x2, v4[1]
	fmov	x28, d4
	mov.d	x30, v2[1]
	ldr	s4, [x13]
	ld1.s	{ v4 }[1], [x11]
	fmov	x11, d2
	ld1.s	{ v4 }[2], [x0]
	ld1.s	{ v4 }[3], [x12]
	fmul.4s	v2, v4, v4
	fadd.4s	v6, v6, v2
	ldr	s2, [x28]
	ld1.s	{ v2 }[1], [x2]
	ld1.s	{ v2 }[2], [x11]
	ld1.s	{ v2 }[3], [x30]
	fmul.4s	v2, v2, v2
	fadd.4s	v5, v5, v2
	dup.2d	v2, x15
	add.2d	v14, v14, v2
	add.2d	v13, v13, v2
	add.2d	v15, v15, v2
	add.2d	v12, v12, v2
	fmov	x11, d12
	cmp	x11, #124
	b.lt	LBB0_31
; %bb.32:                               ; %direct.false60.i142.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	ldr	q4, [sp, #9456]
	ldr	q20, [sp, #9440]
	ldr	q2, [sp, #9488]
	ldr	q19, [sp, #9472]
	movi.2d	v22, #0000000000000000
	movi.2d	v24, #0000000000000000
	ldr	q21, [sp, #9520]
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	ldr	q23, [sp, #9504]
LBB0_33:                                ; %direct.true97.i149.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x3, x11, lsl #5
	ldp	q28, q27, [x11]
	shl.2d	v29, v22, #5
	shl.2d	v30, v24, #5
	shl.2d	v12, v25, #5
	shl.2d	v13, v26, #5
	add.2d	v13, v13, v18
	add.2d	v13, v0, v13
	add.2d	v12, v12, v17
	add.2d	v30, v30, v16
	add.2d	v29, v29, v3
	add.2d	v29, v0, v29
	mov.d	x11, v29[1]
	fmov	x12, d29
	str	s28, [x12]
	st1.s	{ v28 }[1], [x11]
	add.2d	v29, v0, v30
	mov.d	x11, v29[1]
	fmov	x12, d29
	st1.s	{ v28 }[2], [x12]
	add.2d	v29, v0, v12
	st1.s	{ v28 }[3], [x11]
	mov.d	x11, v29[1]
	fmov	x12, d29
	str	s27, [x12]
	st1.s	{ v27 }[1], [x11]
	mov.d	x11, v13[1]
	fmov	x12, d13
	st1.s	{ v27 }[2], [x12]
	st1.s	{ v27 }[3], [x11]
	dup.2d	v27, x27
	add.2d	v25, v25, v27
	add.2d	v24, v24, v27
	add.2d	v26, v26, v27
	add.2d	v22, v22, v27
	fmov	x11, d22
	cmp	x11, #127
	b.lt	LBB0_33
; %bb.34:                               ; %direct.false98.i153.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	fmul.4s	v20, v20, v20
	fmul.4s	v4, v4, v4
	fadd.4s	v4, v10, v4
	fadd.4s	v20, v9, v20
	fmul.4s	v19, v19, v19
	fmul.4s	v2, v2, v2
	fadd.4s	v2, v8, v2
	fadd.4s	v19, v31, v19
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v23, v23
	fadd.4s	v22, v11, v22
	fadd.4s	v7, v7, v21
	ldp	q21, q23, [sp, #464]            ; 32-byte Folded Reload
	fmul.4s	v21, v21, v21
	fmul.4s	v23, v23, v23
	fadd.4s	v20, v23, v20
	fadd.4s	v21, v21, v4
	mov.s	v21[3], v4[3]
	fadd.4s	v4, v19, v20
	fadd.4s	v2, v2, v21
	fadd.4s	v2, v7, v2
	fadd.4s	v4, v22, v4
	fadd.4s	v4, v6, v4
	fadd.4s	v2, v5, v2
	rev64.4s	v5, v2
	rev64.4s	v6, v4
	fadd.4s	v4, v4, v6
	fadd.4s	v2, v2, v5
	dup.4s	v5, v2[2]
	dup.4s	v6, v4[2]
	fadd.4s	v4, v4, v6
	fadd.4s	v2, v2, v5
	fadd.4s	v2, v4, v2
	movi	d4, #0000000000000000
	fadd	s2, s2, s4
	mov	w12, #49152                     ; =0xc000
	movk	w12, #17535, lsl #16
	fmov	s4, w12
	fdiv	s5, s2, s4
	add	x12, x14, #4
	add	x13, x14, #8
	add	x0, x14, #12
	ldr	s2, [x14]
	ld1.s	{ v2 }[1], [x12]
	ld1.s	{ v2 }[2], [x13]
	add	x12, x14, #20
	ld1.s	{ v2 }[3], [x0]
	ldr	s4, [x14, #16]
	ld1.s	{ v4 }[1], [x12]
	add	x12, x14, #24
	ld1.s	{ v4 }[2], [x12]
	add	x12, sp, #1376
	add	x12, x12, #4092
	ld1.s	{ v4 }[3], [x12]
	str	q2, [sp, #5440]
	mov	w12, #50604                     ; =0xc5ac
	movk	w12, #14119, lsl #16
	fmov	s6, w12
	fadd	s5, s5, s6
	fsqrt	s5, s5
	dup.4s	v6, v5[0]
	str	q4, [sp, #5456]
	ldr	x12, [sp, #592]                 ; 8-byte Folded Reload
	add	x8, x12, x8
	movi.2d	v7, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
LBB0_35:                                ; %direct.true121.i161.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v22, v21, #5
	shl.2d	v23, v20, #5
	shl.2d	v24, v19, #5
	shl.2d	v25, v7, #5
	orr.16b	v25, v25, v3
	orr.16b	v24, v24, v16
	orr.16b	v23, v23, v17
	orr.16b	v22, v22, v18
	add.2d	v26, v1, v22
	add.2d	v27, v1, v23
	add.2d	v28, v1, v24
	add.2d	v29, v1, v25
	mov.d	x12, v29[1]
	mov.d	x13, v28[1]
	mov.d	x14, v27[1]
	fmov	x0, d29
	fmov	x2, d27
	mov.d	x3, v26[1]
	fmov	x28, d26
	ldr	s26, [x2]
	ld1.s	{ v26 }[1], [x14]
	ld1.s	{ v26 }[2], [x28]
	ld1.s	{ v26 }[3], [x3]
	fmov	x14, d28
	ldr	s27, [x0]
	ld1.s	{ v27 }[1], [x12]
	ld1.s	{ v27 }[2], [x14]
	ld1.s	{ v27 }[3], [x13]
	fdiv.4s	v27, v27, v6
	fdiv.4s	v26, v26, v6
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v24, v0, v24
	add.2d	v25, v0, v25
	mov.d	x12, v25[1]
	fmov	x13, d25
	mov.d	x14, v24[1]
	mov.d	x0, v23[1]
	mov.d	x2, v22[1]
	fmov	x3, d24
	ldr	s24, [x13]
	ld1.s	{ v24 }[1], [x12]
	ld1.s	{ v24 }[2], [x3]
	fmov	x12, d23
	ld1.s	{ v24 }[3], [x14]
	ldr	s23, [x12]
	ld1.s	{ v23 }[1], [x0]
	fmov	x12, d22
	ld1.s	{ v23 }[2], [x12]
	ld1.s	{ v23 }[3], [x2]
	fmul.4s	v22, v26, v23
	fmul.4s	v23, v27, v24
	add	x11, x8, x11, lsl #5
	stp	q23, q22, [x11]
	dup.2d	v22, x27
	add.2d	v20, v20, v22
	add.2d	v19, v19, v22
	add.2d	v21, v21, v22
	add.2d	v7, v7, v22
	fmov	x11, d7
	cmp	x11, #127
	b.lt	LBB0_35
; %bb.36:                               ; %llm_rows.full_packet.exit167.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q6, [sp, #9552]
	ldr	q7, [sp, #9536]
	dup.4s	v5, v5[0]
	fdiv.4s	v7, v7, v5
	fdiv.4s	v5, v6, v5
	fmul.4s	v4, v4, v5
	fmul.4s	v2, v2, v7
	ldr	x8, [sp, #592]                  ; 8-byte Folded Reload
	add	x8, x8, x9
	str	q2, [x8]
	str	d4, [x8, #16]
	add	x8, x8, #24
	st1.s	{ v4 }[2], [x8]
	ldr	w13, [sp, #372]                 ; 4-byte Folded Reload
	ldr	w14, [sp, #368]                 ; 4-byte Folded Reload
	ldr	x0, [sp, #376]                  ; 8-byte Folded Reload
	b	LBB0_2
LBB0_37:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	w16, [sp, #364]                 ; 4-byte Folded Spill
	lsr	x8, x9, #3
	str	x8, [sp, #688]                  ; 8-byte Folded Spill
	str	x9, [sp, #624]                  ; 8-byte Folded Spill
	cmp	x9, #8
	b.lo	LBB0_48
; %bb.38:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x14, #0                         ; =0x0
	ldr	x8, [sp, #336]                  ; 8-byte Folded Reload
	ldr	x11, [x8]
	ldr	x3, [x8, #16]
	ldr	x13, [x8, #48]
	add	x28, x3, #4064
	ldr	x8, [sp, #376]                  ; 8-byte Folded Reload
	lsl	w9, w8, #2
	str	x9, [sp, #640]                  ; 8-byte Folded Spill
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	and	x8, x8, #0x7ffffff
	mov	w9, #16368                      ; =0x3ff0
	str	x11, [sp, #672]                 ; 8-byte Folded Spill
	umaddl	x9, w8, w9, x11
	str	x13, [sp, #656]                 ; 8-byte Folded Spill
LBB0_39:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_40 Depth 3
                                        ;       Child Loop BB0_42 Depth 3
                                        ;       Child Loop BB0_44 Depth 3
                                        ;       Child Loop BB0_46 Depth 3
	mov	x12, #0                         ; =0x0
	ldr	x8, [sp, #640]                  ; 8-byte Folded Reload
	add	w8, w14, w8
	and	x8, x8, #0x1fffffff
	lsl	x13, x8, #12
	sub	x8, x13, x8, lsl #2
LBB0_40:                                ; %direct.true.i173.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x13, x9, x12
	ldp	q2, q4, [x13]
	add	x13, x10, x12
	stp	q2, q4, [x13]
	add	x12, x12, #32
	cmp	x12, #4064
	b.ne	LBB0_40
; %bb.41:                               ; %direct.false.i179.i
                                        ;   in Loop: Header=BB0_39 Depth=2
	add	x12, x8, #4064
	ldr	x11, [sp, #672]                 ; 8-byte Folded Reload
	str	x12, [sp, #704]                 ; 8-byte Folded Spill
	add	x12, x11, x12
	add	x11, x12, #4
	add	x30, x12, #8
	add	x2, x12, #12
	ldr	s6, [x12]
	ld1.s	{ v6 }[1], [x11]
	ld1.s	{ v6 }[2], [x30]
	add	x11, x12, #20
	ld1.s	{ v6 }[3], [x2]
	ldr	s7, [x12, #16]
	ld1.s	{ v7 }[1], [x11]
	add	x11, x12, #24
	ld1.s	{ v7 }[2], [x11]
	add	x11, x10, #4092
	ld1.s	{ v7 }[3], [x11]
	str	q6, [sp, #9536]
	str	q7, [sp, #9552]
	ldr	q2, [sp, #5472]
	ldr	q4, [sp, #5488]
	fmul.4s	v22, v4, v4
	fmul.4s	v21, v2, v2
	ldr	q2, [sp, #5504]
	ldr	q4, [sp, #5520]
	fmul.4s	v20, v4, v4
	fmul.4s	v19, v2, v2
	ldr	q2, [sp, #5536]
	ldr	q4, [sp, #5552]
	fmul.4s	v18, v4, v4
	fmul.4s	v23, v2, v2
	ldr	q2, [sp, #5568]
	ldr	q4, [sp, #5584]
	fmul.4s	v16, v4, v4
	fmul.4s	v17, v2, v2
	dup.2d	v24, x15
	mov.16b	v25, v24
	mov.16b	v26, v24
	mov.16b	v27, v24
	adrp	x6, lCPI0_2@PAGE
	adrp	x1, lCPI0_4@PAGE
	adrp	x7, lCPI0_3@PAGE
	adrp	x20, lCPI0_5@PAGE
	adrp	x21, lCPI0_6@PAGE
	adrp	x22, lCPI0_7@PAGE
	adrp	x23, lCPI0_8@PAGE
	adrp	x24, lCPI0_9@PAGE
	adrp	x26, lCPI0_10@PAGE
	adrp	x0, lCPI0_11@PAGE
	mov	w10, #4                         ; =0x4
	adrp	x15, lCPI0_12@PAGE
	adrp	x13, lCPI0_13@PAGE
	adrp	x25, lCPI0_14@PAGE
	adrp	x19, lCPI0_15@PAGE
LBB0_42:                                ; %direct.true59.i191.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.2d	v2, v24, #5
	add.2d	v28, v1, v2
	add.2d	v8, v28, v3
	mov.d	x11, v8[1]
	ldr	q2, [x5, lCPI0_1@PAGEOFF]
	shl.2d	v4, v25, #5
	add.2d	v29, v1, v4
	add.2d	v9, v29, v2
	mov.d	x12, v9[1]
	ldr	q4, [x6, lCPI0_2@PAGEOFF]
	shl.2d	v5, v26, #5
	add.2d	v30, v1, v5
	add.2d	v10, v30, v4
	mov.d	x2, v10[1]
	ldr	q5, [x7, lCPI0_3@PAGEOFF]
	shl.2d	v31, v27, #5
	add.2d	v31, v1, v31
	add.2d	v11, v31, v5
	mov.d	x30, v11[1]
	fmov	x16, d8
	ldr	s8, [x16]
	fmov	x16, d9
	fmov	x4, d10
	ld1.s	{ v8 }[1], [x11]
	fmov	x11, d11
	ld1.s	{ v8 }[2], [x16]
	ld1.s	{ v8 }[3], [x12]
	ldr	s9, [x4]
	ld1.s	{ v9 }[1], [x2]
	ld1.s	{ v9 }[2], [x11]
	ld1.s	{ v9 }[3], [x30]
	fmul.4s	v9, v9, v9
	fmul.4s	v8, v8, v8
	fadd.4s	v21, v21, v8
	fadd.4s	v22, v22, v9
	ldr	q8, [x1, lCPI0_4@PAGEOFF]
	ldr	q9, [x20, lCPI0_5@PAGEOFF]
	ldr	q10, [x21, lCPI0_6@PAGEOFF]
	ldr	q11, [x22, lCPI0_7@PAGEOFF]
	add.2d	v11, v31, v11
	add.2d	v10, v30, v10
	add.2d	v9, v29, v9
	add.2d	v8, v28, v8
	mov.d	x11, v8[1]
	fmov	x12, d8
	mov.d	x16, v9[1]
	fmov	x2, d9
	mov.d	x4, v10[1]
	fmov	x30, d10
	mov.d	x17, v11[1]
	ldr	s8, [x12]
	ld1.s	{ v8 }[1], [x11]
	ld1.s	{ v8 }[2], [x2]
	ld1.s	{ v8 }[3], [x16]
	fmov	x11, d11
	ldr	s9, [x30]
	ld1.s	{ v9 }[1], [x4]
	ld1.s	{ v9 }[2], [x11]
	ld1.s	{ v9 }[3], [x17]
	fmul.4s	v9, v9, v9
	fmul.4s	v8, v8, v8
	fadd.4s	v19, v19, v8
	fadd.4s	v20, v20, v9
	ldr	q8, [x23, lCPI0_8@PAGEOFF]
	ldr	q9, [x24, lCPI0_9@PAGEOFF]
	ldr	q10, [x26, lCPI0_10@PAGEOFF]
	ldr	q11, [x0, lCPI0_11@PAGEOFF]
	add.2d	v11, v31, v11
	add.2d	v10, v30, v10
	add.2d	v9, v29, v9
	add.2d	v8, v28, v8
	mov.d	x11, v8[1]
	mov.d	x12, v9[1]
	fmov	x16, d8
	fmov	x17, d9
	mov.d	x2, v10[1]
	mov.d	x4, v11[1]
	fmov	x30, d10
	ldr	s8, [x16]
	ld1.s	{ v8 }[1], [x11]
	ld1.s	{ v8 }[2], [x17]
	fmov	x11, d11
	ld1.s	{ v8 }[3], [x12]
	ldr	s9, [x30]
	ld1.s	{ v9 }[1], [x2]
	ld1.s	{ v9 }[2], [x11]
	ld1.s	{ v9 }[3], [x4]
	fmul.4s	v9, v9, v9
	fmul.4s	v8, v8, v8
	fadd.4s	v23, v23, v8
	fadd.4s	v18, v18, v9
	ldr	q8, [x15, lCPI0_12@PAGEOFF]
	ldr	q9, [x13, lCPI0_13@PAGEOFF]
	ldr	q10, [x25, lCPI0_14@PAGEOFF]
	ldr	q11, [x19, lCPI0_15@PAGEOFF]
	add.2d	v31, v31, v11
	add.2d	v30, v30, v10
	add.2d	v29, v29, v9
	add.2d	v28, v28, v8
	mov.d	x11, v28[1]
	fmov	x12, d28
	mov.d	x16, v29[1]
	fmov	x17, d29
	mov.d	x2, v30[1]
	fmov	x4, d30
	mov.d	x30, v31[1]
	ldr	s28, [x12]
	ld1.s	{ v28 }[1], [x11]
	fmov	x11, d31
	ld1.s	{ v28 }[2], [x17]
	ld1.s	{ v28 }[3], [x16]
	ldr	s29, [x4]
	ld1.s	{ v29 }[1], [x2]
	ld1.s	{ v29 }[2], [x11]
	ld1.s	{ v29 }[3], [x30]
	fmul.4s	v29, v29, v29
	fmul.4s	v28, v28, v28
	fadd.4s	v17, v17, v28
	fadd.4s	v16, v16, v29
	dup.2d	v28, x10
	add.2d	v26, v26, v28
	add.2d	v25, v25, v28
	add.2d	v27, v27, v28
	add.2d	v24, v24, v28
	fmov	x11, d24
	cmp	x11, #124
	b.lt	LBB0_42
; %bb.43:                               ; %direct.false60.i197.i
                                        ;   in Loop: Header=BB0_39 Depth=2
	mov	x12, #0                         ; =0x0
	ldr	q25, [sp, #9456]
	ldr	q27, [sp, #9440]
	ldr	q24, [sp, #9488]
	ldr	q26, [sp, #9472]
	movi.2d	v29, #0000000000000000
	movi.2d	v31, #0000000000000000
	ldr	q28, [sp, #9520]
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	ldr	q30, [sp, #9504]
LBB0_44:                                ; %direct.true97.i204.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x11, x3, x12, lsl #5
	ldp	q11, q10, [x11]
	shl.2d	v12, v29, #5
	shl.2d	v13, v31, #5
	shl.2d	v14, v8, #5
	shl.2d	v15, v9, #5
	add.2d	v15, v15, v5
	add.2d	v15, v0, v15
	add.2d	v14, v14, v4
	add.2d	v13, v13, v2
	add.2d	v12, v12, v3
	add.2d	v12, v0, v12
	mov.d	x11, v12[1]
	fmov	x12, d12
	str	s11, [x12]
	st1.s	{ v11 }[1], [x11]
	add.2d	v12, v0, v13
	mov.d	x11, v12[1]
	fmov	x12, d12
	st1.s	{ v11 }[2], [x12]
	add.2d	v12, v0, v14
	st1.s	{ v11 }[3], [x11]
	mov.d	x11, v12[1]
	fmov	x12, d12
	str	s10, [x12]
	st1.s	{ v10 }[1], [x11]
	mov.d	x11, v15[1]
	fmov	x12, d15
	st1.s	{ v10 }[2], [x12]
	st1.s	{ v10 }[3], [x11]
	dup.2d	v10, x27
	add.2d	v8, v8, v10
	add.2d	v31, v31, v10
	add.2d	v9, v9, v10
	add.2d	v29, v29, v10
	fmov	x12, d29
	cmp	x12, #127
	b.lt	LBB0_44
; %bb.45:                               ; %direct.false98.i208.i
                                        ;   in Loop: Header=BB0_39 Depth=2
	mov	x12, #0                         ; =0x0
	fmul.4s	v27, v27, v27
	fmul.4s	v25, v25, v25
	fadd.4s	v22, v22, v25
	fadd.4s	v21, v21, v27
	fmul.4s	v25, v26, v26
	fmul.4s	v24, v24, v24
	fadd.4s	v20, v20, v24
	fadd.4s	v19, v19, v25
	fmul.4s	v24, v28, v28
	fmul.4s	v25, v30, v30
	fadd.4s	v23, v23, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v7, v7, v7
	fmul.4s	v6, v6, v6
	fadd.4s	v6, v6, v21
	fadd.4s	v7, v7, v22
	mov.s	v7[3], v22[3]
	fadd.4s	v6, v19, v6
	fadd.4s	v7, v20, v7
	fadd.4s	v7, v18, v7
	fadd.4s	v6, v23, v6
	fadd.4s	v6, v17, v6
	fadd.4s	v7, v16, v7
	rev64.4s	v16, v7
	rev64.4s	v17, v6
	fadd.4s	v6, v6, v17
	fadd.4s	v7, v7, v16
	dup.4s	v16, v7[2]
	dup.4s	v17, v6[2]
	fadd.4s	v6, v6, v17
	fadd.4s	v7, v7, v16
	fadd.4s	v6, v6, v7
	movi	d7, #0000000000000000
	fadd	s6, s6, s7
	mov	w10, #49152                     ; =0xc000
	movk	w10, #17535, lsl #16
	fmov	s7, w10
	fdiv	s16, s6, s7
	add	x11, x28, #4
	add	x16, x28, #8
	add	x17, x28, #12
	ldr	s6, [x28]
	ld1.s	{ v6 }[1], [x11]
	ld1.s	{ v6 }[2], [x16]
	add	x11, x28, #20
	ld1.s	{ v6 }[3], [x17]
	ldr	s7, [x28, #16]
	ld1.s	{ v7 }[1], [x11]
	add	x11, x28, #24
	ld1.s	{ v7 }[2], [x11]
	add	x11, sp, #1376
	add	x11, x11, #4092
	ld1.s	{ v7 }[3], [x11]
	str	q6, [sp, #5440]
	mov	w10, #50604                     ; =0xc5ac
	movk	w10, #14119, lsl #16
	fmov	s17, w10
	fadd	s16, s16, s17
	fsqrt	s16, s16
	dup.4s	v17, v16[0]
	str	q7, [sp, #5456]
	ldr	x13, [sp, #656]                 ; 8-byte Folded Reload
	add	x8, x13, x8
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	adrp	x1, lCPI0_3@PAGE
	adrp	x20, lCPI0_9@PAGE
	mov	w15, #4                         ; =0x4
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #1376
	adrp	x26, lCPI0_15@PAGE
LBB0_46:                                ; %direct.true121.i216.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.2d	v22, v21, #5
	shl.2d	v23, v20, #5
	shl.2d	v24, v19, #5
	shl.2d	v25, v18, #5
	orr.16b	v25, v25, v3
	orr.16b	v24, v24, v2
	orr.16b	v23, v23, v4
	orr.16b	v22, v22, v5
	add.2d	v26, v1, v22
	add.2d	v27, v1, v23
	add.2d	v28, v1, v24
	add.2d	v29, v1, v25
	mov.d	x11, v29[1]
	mov.d	x16, v28[1]
	mov.d	x17, v27[1]
	fmov	x2, d29
	fmov	x4, d27
	mov.d	x30, v26[1]
	fmov	x5, d26
	ldr	s26, [x4]
	ld1.s	{ v26 }[1], [x17]
	ld1.s	{ v26 }[2], [x5]
	ld1.s	{ v26 }[3], [x30]
	fmov	x17, d28
	ldr	s27, [x2]
	ld1.s	{ v27 }[1], [x11]
	ld1.s	{ v27 }[2], [x17]
	ld1.s	{ v27 }[3], [x16]
	fdiv.4s	v27, v27, v17
	fdiv.4s	v26, v26, v17
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v24, v0, v24
	add.2d	v25, v0, v25
	mov.d	x11, v25[1]
	fmov	x16, d25
	mov.d	x17, v24[1]
	mov.d	x2, v23[1]
	mov.d	x4, v22[1]
	fmov	x5, d24
	ldr	s24, [x16]
	ld1.s	{ v24 }[1], [x11]
	ld1.s	{ v24 }[2], [x5]
	fmov	x11, d23
	ld1.s	{ v24 }[3], [x17]
	ldr	s23, [x11]
	ld1.s	{ v23 }[1], [x2]
	fmov	x11, d22
	ld1.s	{ v23 }[2], [x11]
	ld1.s	{ v23 }[3], [x4]
	fmul.4s	v22, v26, v23
	fmul.4s	v23, v27, v24
	add	x11, x8, x12, lsl #5
	stp	q23, q22, [x11]
	dup.2d	v22, x27
	add.2d	v20, v20, v22
	add.2d	v19, v19, v22
	add.2d	v21, v21, v22
	add.2d	v18, v18, v22
	fmov	x12, d18
	cmp	x12, #127
	b.lt	LBB0_46
; %bb.47:                               ; %llm_rows.full_packet.exit222.i
                                        ;   in Loop: Header=BB0_39 Depth=2
	ldr	q2, [sp, #9552]
	ldr	q4, [sp, #9536]
	dup.4s	v5, v16[0]
	fdiv.4s	v4, v4, v5
	fdiv.4s	v2, v2, v5
	fmul.4s	v2, v7, v2
	fmul.4s	v4, v6, v4
	ldr	x8, [sp, #704]                  ; 8-byte Folded Reload
	add	x8, x13, x8
	str	q4, [x8]
	str	d2, [x8, #16]
	add	x8, x8, #24
	st1.s	{ v2 }[2], [x8]
	add	x14, x14, #1
	add	x9, x9, #4092
	ldr	x8, [sp, #688]                  ; 8-byte Folded Reload
	cmp	x14, x8
	adrp	x5, lCPI0_1@PAGE
	b.ne	LBB0_39
LBB0_48:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #624]                  ; 8-byte Folded Reload
	and	w8, w8, #0x7
	ldr	w16, [sp, #364]                 ; 4-byte Folded Reload
	mov	w17, #4092                      ; =0xffc
	adrp	x6, lCPI0_5@PAGE
	adrp	x7, lCPI0_6@PAGE
	adrp	x19, lCPI0_7@PAGE
	adrp	x4, lCPI0_8@PAGE
	adrp	x21, lCPI0_10@PAGE
	adrp	x22, lCPI0_11@PAGE
	adrp	x23, lCPI0_12@PAGE
	adrp	x24, lCPI0_13@PAGE
	adrp	x25, lCPI0_14@PAGE
	ldr	w13, [sp, #372]                 ; 4-byte Folded Reload
	ldr	w14, [sp, #368]                 ; 4-byte Folded Reload
	ldr	x0, [sp, #376]                  ; 8-byte Folded Reload
	cbz	w8, LBB0_2
; %bb.49:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v2, w8
Lloh2:
	adrp	x8, lCPI0_17@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_17@PAGEOFF]
Lloh4:
	adrp	x8, lCPI0_18@PAGE
Lloh5:
	ldr	q5, [x8, lCPI0_18@PAGEOFF]
	cmhi.4s	v13, v2, v5
	cmhi.4s	v14, v2, v4
	uzp1.8h	v2, v14, v13
	umaxv.8h	h4, v2
	fmov	w8, s4
	tbz	w8, #0, LBB0_2
; %bb.50:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x11, [sp, #336]                 ; 8-byte Folded Reload
	ldr	x8, [x11]
	ldr	x12, [x11, #16]
	ldr	x16, [x11, #48]
Lloh6:
	adrp	x11, lCPI0_16@PAGE
Lloh7:
	ldr	q4, [x11, lCPI0_16@PAGEOFF]
	and.16b	v4, v2, v4
	addv.8h	h16, v4
	ubfiz	w11, w0, #2, #27
	ldr	x13, [sp, #688]                 ; 8-byte Folded Reload
	orr	w11, w11, w13
	fmov	w13, s16
	and	w13, w13, #0xff
	str	w13, [sp, #236]                 ; 4-byte Folded Spill
	dup.4s	v4, w11
	and.16b	v6, v14, v4
	and.16b	v4, v13, v4
	ushll2.2d	v5, v4, #0
	ushll2.2d	v7, v6, #0
	ushll.2d	v17, v4, #0
	ushll.2d	v6, v6, #0
	fmov	x11, d6
	umaddl	x13, w11, w17, x8
	b	LBB0_52
LBB0_51:                                ; %else953
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x11, x10, x9
	ldp	q19, q20, [x11]
	bif.16b	v18, v20, v13
	bif.16b	v4, v19, v14
	stp	q4, q18, [x11]
	add	x9, x9, #32
	cmp	x9, #4064
	b.eq	LBB0_68
LBB0_52:                                ; %direct.true.i227.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w11, s16
	add	x14, x13, x9
	movi.2d	v4, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w11, #0, LBB0_60
; %bb.53:                               ; %else
                                        ;   in Loop: Header=BB0_52 Depth=2
	and	w0, w11, #0xff
	tbnz	w0, #1, LBB0_61
LBB0_54:                                ; %else935
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w0, #2, LBB0_62
LBB0_55:                                ; %else938
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w0, #3, LBB0_63
LBB0_56:                                ; %else941
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w0, #4, LBB0_64
LBB0_57:                                ; %else944
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w0, #5, LBB0_65
LBB0_58:                                ; %else947
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w0, #6, LBB0_66
LBB0_59:                                ; %else950
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbz	w0, #7, LBB0_51
	b	LBB0_67
LBB0_60:                                ; %cond.load
                                        ;   in Loop: Header=BB0_52 Depth=2
	ldr	s4, [x14]
	and	w0, w11, #0xff
	tbz	w0, #1, LBB0_54
LBB0_61:                                ; %cond.load934
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x11, x14, #4
	ld1.s	{ v4 }[1], [x11]
	tbz	w0, #2, LBB0_55
LBB0_62:                                ; %cond.load937
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x11, x14, #8
	ld1.s	{ v4 }[2], [x11]
	tbz	w0, #3, LBB0_56
LBB0_63:                                ; %cond.load940
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x11, x14, #12
	ld1.s	{ v4 }[3], [x11]
	tbz	w0, #4, LBB0_57
LBB0_64:                                ; %cond.load943
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x11, x14, #16
	ld1.s	{ v18 }[0], [x11]
	tbz	w0, #5, LBB0_58
LBB0_65:                                ; %cond.load946
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x11, x14, #20
	ld1.s	{ v18 }[1], [x11]
	tbz	w0, #6, LBB0_59
LBB0_66:                                ; %cond.load949
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x11, x14, #24
	ld1.s	{ v18 }[2], [x11]
	tbz	w0, #7, LBB0_51
LBB0_67:                                ; %cond.load952
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x11, x14, #28
	ld1.s	{ v18 }[3], [x11]
	b	LBB0_51
LBB0_68:                                ; %direct.true59.preheader.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	xtn.8b	v23, v2
	sshll.2d	v2, v14, #0
	sshll2.2d	v19, v14, #0
	sshll.2d	v4, v13, #0
	sshll2.2d	v20, v13, #0
Lloh8:
	adrp	x9, lCPI0_19@PAGE
Lloh9:
	ldr	q18, [x9, lCPI0_19@PAGEOFF]
	str	q20, [sp, #576]                 ; 16-byte Folded Spill
	and.16b	v20, v20, v18
Lloh10:
	adrp	x9, lCPI0_20@PAGE
Lloh11:
	ldr	q18, [x9, lCPI0_20@PAGEOFF]
	and.16b	v21, v4, v18
Lloh12:
	adrp	x9, lCPI0_21@PAGE
Lloh13:
	ldr	q18, [x9, lCPI0_21@PAGEOFF]
	str	q19, [sp, #592]                 ; 16-byte Folded Spill
	and.16b	v24, v19, v18
Lloh14:
	adrp	x9, lCPI0_22@PAGE
Lloh15:
	ldr	q18, [x9, lCPI0_22@PAGEOFF]
	and.16b	v22, v2, v18
	mov.16b	v19, v23
	mov.b	v19[7], wzr
Lloh16:
	adrp	x9, lCPI0_23@PAGE
Lloh17:
	ldr	d18, [x9, lCPI0_23@PAGEOFF]
	str	d18, [sp, #136]                 ; 8-byte Folded Spill
	and.8b	v18, v19, v18
	addv.8b	b18, v18
	fmov	w9, s18
	str	q19, [sp, #320]                 ; 16-byte Folded Spill
	umaxv.8b	b18, v19
	fmov	w11, s18
	rbit	w13, w9
	clz	w13, w13
	tst	w11, #0x1
	csel	w14, w13, wzr, ne
	mov	w11, #1016                      ; =0x3f8
	dup.2d	v18, x11
	stp	q22, q24, [sp, #48]             ; 32-byte Folded Spill
	orr.16b	v22, v22, v18
	orr.16b	v19, v24, v18
	stp	q21, q20, [sp, #80]             ; 32-byte Folded Spill
	orr.16b	v21, v21, v18
	orr.16b	v20, v20, v18
	xtn.2s	v6, v6
	xtn.2s	v7, v7
	xtn.2s	v17, v17
	xtn.2s	v5, v5
	stp	q21, q20, [sp, #192]            ; 32-byte Folded Spill
	movi.2s	v18, #3, msl #8
	umlal.2d	v20, v5, v18
	umlal.2d	v21, v17, v18
	stp	q22, q19, [sp, #160]            ; 32-byte Folded Spill
	mov.16b	v17, v19
	umlal.2d	v17, v7, v18
	movi.2s	v19, #3, msl #8
	umlal.2d	v22, v6, v18
	mov	b5, v23[0]
	mov.b	v5[4], v23[1]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	mov	b7, v23[2]
	mov.b	v7[4], v23[3]
	stp	q22, q17, [sp, #240]            ; 32-byte Folded Spill
	and.16b	v5, v5, v22
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v17
	mov	b17, v23[4]
	mov.b	v17[4], v23[5]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	stp	q21, q20, [sp, #272]            ; 32-byte Folded Spill
	and.16b	v17, v17, v21
	movi.2d	v18, #0000000000000000
	str	q23, [sp, #112]                 ; 16-byte Folded Spill
	mov.b	v18[0], v23[6]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	and.16b	v18, v18, v20
	str	q18, [sp, #1344]
	str	q17, [sp, #1328]
	str	q7, [sp, #1312]
	str	q5, [sp, #1296]
	and	x11, x14, #0x7
	add	x13, sp, #1296
	ldr	x11, [x13, x11, lsl #3]
	sub	x11, x11, x14
	add	x8, x8, x11, lsl #2
	movi.2d	v23, #0000000000000000
	movi.2d	v25, #0000000000000000
	tbnz	w9, #0, LBB0_247
; %bb.69:                               ; %else957
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #1, LBB0_248
LBB0_70:                                ; %else960
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #2, LBB0_249
LBB0_71:                                ; %else963
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #3, LBB0_250
LBB0_72:                                ; %else966
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #4, LBB0_251
LBB0_73:                                ; %else969
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #5, LBB0_252
LBB0_74:                                ; %else972
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #6, LBB0_253
LBB0_75:                                ; %else975
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w9, #7, LBB0_77
LBB0_76:                                ; %cond.load977
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x8, #28
	ld1.s	{ v25 }[3], [x8]
LBB0_77:                                ; %else978
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q27, q26, [sp, #576]            ; 32-byte Folded Reload
	and.16b	v7, v27, v1
	and.16b	v5, v4, v1
	stp	q5, q7, [sp, #688]              ; 32-byte Folded Spill
	and.16b	v24, v2, v1
	ldr	q5, [x1, lCPI0_3@PAGEOFF]
	and.16b	v18, v27, v5
	ldr	q5, [x5, lCPI0_1@PAGEOFF]
	and.16b	v20, v26, v5
Lloh18:
	adrp	x8, lCPI0_2@PAGE
Lloh19:
	ldr	q5, [x8, lCPI0_2@PAGEOFF]
	and.16b	v21, v4, v5
	and.16b	v22, v2, v3
	umull.2d	v2, v6, v19
	str	q2, [sp, #144]                  ; 16-byte Folded Spill
	sshll.2d	v4, v14, #0
	sshll.2d	v6, v13, #0
	str	q22, [sp, #1232]
	str	q20, [sp, #1248]
	str	q21, [sp, #1264]
	str	q18, [sp, #1280]
	and	x8, x14, #0x7
	add	x11, sp, #1232
	ldr	x8, [x11, x8, lsl #3]
	orr	x8, x8, #0xfe0
	sub	x8, x8, x14, lsl #2
	tst	w9, #0xff
	csel	x3, xzr, x8, eq
	add	x8, x10, x3
	ldp	q2, q5, [x8]
	ldr	q17, [sp, #320]                 ; 16-byte Folded Reload
	zip2.8b	v7, v17, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	stp	q25, q23, [sp, #16]             ; 32-byte Folded Spill
	bit.16b	v5, v25, v7
	zip1.8b	v7, v17, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bit.16b	v2, v23, v7
	stp	q2, q5, [x8]
	mov	w8, #32                         ; =0x20
	dup.2d	v2, x8
	orr.16b	v7, v21, v2
	orr.16b	v5, v20, v2
	stp	q5, q7, [sp, #544]              ; 32-byte Folded Spill
	orr.16b	v5, v22, v2
	orr.16b	v2, v18, v2
	stp	q2, q5, [sp, #512]              ; 32-byte Folded Spill
	mov	w8, #64                         ; =0x40
	dup.2d	v2, x8
	orr.16b	v7, v21, v2
	orr.16b	v5, v20, v2
	stp	q5, q7, [sp, #480]              ; 32-byte Folded Spill
	orr.16b	v5, v22, v2
	orr.16b	v2, v18, v2
	stp	q2, q5, [sp, #448]              ; 32-byte Folded Spill
	mov	w8, #96                         ; =0x60
	dup.2d	v2, x8
	stp	q21, q20, [sp, #640]            ; 32-byte Folded Spill
	orr.16b	v7, v21, v2
	orr.16b	v5, v20, v2
	stp	q5, q7, [sp, #416]              ; 32-byte Folded Spill
	orr.16b	v5, v22, v2
	str	q18, [sp, #672]                 ; 16-byte Folded Spill
	orr.16b	v2, v18, v2
	stp	q2, q5, [sp, #384]              ; 32-byte Folded Spill
	ldr	q2, [sp, #5584]
	ldr	q5, [sp, #5568]
	fmul.4s	v5, v5, v5
	fmul.4s	v2, v2, v2
	and.16b	v18, v13, v2
	and.16b	v5, v14, v5
	ldr	q2, [sp, #5552]
	ldr	q7, [sp, #5536]
	fmul.4s	v7, v7, v7
	fmul.4s	v2, v2, v2
	and.16b	v2, v13, v2
	and.16b	v30, v14, v7
	ldr	q7, [sp, #5520]
	ldr	q17, [sp, #5504]
	fmul.4s	v17, v17, v17
	fmul.4s	v7, v7, v7
	and.16b	v31, v13, v7
	and.16b	v8, v14, v17
	str	q22, [sp, #624]                 ; 16-byte Folded Spill
	fmov	x8, d22
	add	x8, x10, x8
	ldp	q17, q7, [x8]
	fmul.4s	v17, v17, v17
	fmul.4s	v7, v7, v7
	and.16b	v19, v13, v7
	dup.2d	v7, x15
	and.16b	v20, v14, v17
	and.16b	v9, v27, v7
	and.16b	v10, v6, v7
	and.16b	v11, v4, v7
	and.16b	v15, v26, v7
	and.16b	v29, v26, v1
	b	LBB0_79
LBB0_78:                                ; %else1174
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmul.4s	v4, v6, v6
	fmul.4s	v6, v21, v21
	fadd.4s	v21, v20, v6
	fadd.4s	v12, v19, v4
	fmul.4s	v4, v26, v26
	fmul.4s	v6, v25, v25
	fadd.4s	v7, v8, v6
	fadd.4s	v17, v31, v4
	fmul.4s	v6, v28, v28
	fmul.4s	v4, v27, v27
	fadd.4s	v4, v30, v4
	fadd.4s	v6, v2, v6
	sshll.2d	v25, v14, #0
	sshll.2d	v26, v13, #0
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	fadd.4s	v23, v18, v23
	fadd.4s	v22, v5, v22
	dup.2d	v27, x15
	ldr	q28, [sp, #576]                 ; 16-byte Folded Reload
	and.16b	v28, v28, v27
	add.2d	v9, v9, v28
	ldr	q28, [sp, #592]                 ; 16-byte Folded Reload
	and.16b	v28, v28, v27
	add.2d	v15, v15, v28
	and.16b	v26, v26, v27
	add.2d	v10, v10, v26
	and.16b	v25, v25, v27
	add.2d	v11, v11, v25
	bit.16b	v19, v12, v13
	bit.16b	v20, v21, v14
	bit.16b	v31, v17, v13
	bit.16b	v8, v7, v14
	bit.16b	v2, v6, v13
	bit.16b	v30, v4, v14
	bit.16b	v5, v22, v14
	bit.16b	v18, v23, v13
	fmov	x8, d11
	cmp	x8, #124
	b.ge	LBB0_143
LBB0_79:                                ; %direct.true59.i242.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w8, s16
	shl.2d	v4, v11, #5
	ldr	q6, [sp, #624]                  ; 16-byte Folded Reload
	orr.16b	v6, v4, v6
	add.2d	v7, v24, v6
	movi.2d	v21, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w8, #0, LBB0_114
; %bb.80:                               ; %else985
                                        ;   in Loop: Header=BB0_79 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_115
LBB0_81:                                ; %else991
                                        ;   in Loop: Header=BB0_79 Depth=2
	shl.2d	v7, v15, #5
	ldr	q17, [sp, #656]                 ; 16-byte Folded Reload
	orr.16b	v17, v7, v17
	add.2d	v17, v29, v17
	tbnz	w8, #2, LBB0_116
LBB0_82:                                ; %else997
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #3, LBB0_117
LBB0_83:                                ; %else1003
                                        ;   in Loop: Header=BB0_79 Depth=2
	shl.2d	v17, v10, #5
	ldr	q22, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v22, v17, v22
	ldr	q23, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v22, v23, v22
	tbnz	w8, #4, LBB0_118
LBB0_84:                                ; %else1009
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #5, LBB0_119
LBB0_85:                                ; %else1015
                                        ;   in Loop: Header=BB0_79 Depth=2
	shl.2d	v12, v9, #5
	ldr	q22, [sp, #672]                 ; 16-byte Folded Reload
	orr.16b	v22, v12, v22
	ldr	q23, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v22, v23, v22
	tbnz	w8, #6, LBB0_120
LBB0_86:                                ; %else1021
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbz	w8, #7, LBB0_88
LBB0_87:                                ; %cond.load1023
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x8, v22[1]
	ld1.s	{ v6 }[3], [x8]
LBB0_88:                                ; %else1027
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	w8, s16
	ldr	q22, [sp, #528]                 ; 16-byte Folded Reload
	add.2d	v22, v22, v4
	add.2d	v22, v24, v22
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbnz	w8, #0, LBB0_121
; %bb.89:                               ; %else1034
                                        ;   in Loop: Header=BB0_79 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_122
LBB0_90:                                ; %else1040
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q22, [sp, #544]                 ; 16-byte Folded Reload
	add.2d	v22, v22, v7
	add.2d	v22, v29, v22
	tbnz	w8, #2, LBB0_123
LBB0_91:                                ; %else1046
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #3, LBB0_124
LBB0_92:                                ; %else1052
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q22, [sp, #560]                 ; 16-byte Folded Reload
	add.2d	v22, v22, v17
	ldr	q23, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v22, v23, v22
	tbnz	w8, #4, LBB0_125
LBB0_93:                                ; %else1058
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #5, LBB0_126
LBB0_94:                                ; %else1064
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q22, [sp, #512]                 ; 16-byte Folded Reload
	add.2d	v22, v22, v12
	ldr	q23, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v22, v23, v22
	tbnz	w8, #6, LBB0_127
LBB0_95:                                ; %else1070
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbz	w8, #7, LBB0_97
LBB0_96:                                ; %cond.load1072
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x8, v22[1]
	ld1.s	{ v26 }[3], [x8]
LBB0_97:                                ; %else1076
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	w8, s16
	ldr	q22, [sp, #464]                 ; 16-byte Folded Reload
	add.2d	v22, v22, v4
	add.2d	v22, v24, v22
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbnz	w8, #0, LBB0_128
; %bb.98:                               ; %else1083
                                        ;   in Loop: Header=BB0_79 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_129
LBB0_99:                                ; %else1089
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q22, [sp, #480]                 ; 16-byte Folded Reload
	add.2d	v22, v22, v7
	add.2d	v22, v29, v22
	tbnz	w8, #2, LBB0_130
LBB0_100:                               ; %else1095
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #3, LBB0_131
LBB0_101:                               ; %else1101
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q22, [sp, #496]                 ; 16-byte Folded Reload
	add.2d	v22, v22, v17
	ldr	q23, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v22, v23, v22
	tbnz	w8, #4, LBB0_132
LBB0_102:                               ; %else1107
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #5, LBB0_133
LBB0_103:                               ; %else1113
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q22, [sp, #448]                 ; 16-byte Folded Reload
	add.2d	v22, v22, v12
	ldr	q23, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v22, v23, v22
	tbnz	w8, #6, LBB0_134
LBB0_104:                               ; %else1119
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbz	w8, #7, LBB0_106
LBB0_105:                               ; %cond.load1121
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x8, v22[1]
	ld1.s	{ v28 }[3], [x8]
LBB0_106:                               ; %else1125
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	w8, s16
	ldr	q22, [sp, #400]                 ; 16-byte Folded Reload
	add.2d	v4, v22, v4
	add.2d	v4, v24, v4
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w8, #0, LBB0_135
; %bb.107:                              ; %else1132
                                        ;   in Loop: Header=BB0_79 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_136
LBB0_108:                               ; %else1138
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q4, [sp, #416]                  ; 16-byte Folded Reload
	add.2d	v4, v4, v7
	add.2d	v4, v29, v4
	tbnz	w8, #2, LBB0_137
LBB0_109:                               ; %else1144
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #3, LBB0_138
LBB0_110:                               ; %else1150
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q4, [sp, #432]                  ; 16-byte Folded Reload
	add.2d	v4, v4, v17
	ldr	q7, [sp, #688]                  ; 16-byte Folded Reload
	add.2d	v4, v7, v4
	tbnz	w8, #4, LBB0_139
LBB0_111:                               ; %else1156
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #5, LBB0_140
LBB0_112:                               ; %else1162
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q4, [sp, #384]                  ; 16-byte Folded Reload
	add.2d	v4, v4, v12
	ldr	q7, [sp, #704]                  ; 16-byte Folded Reload
	add.2d	v4, v7, v4
	tbnz	w8, #6, LBB0_141
LBB0_113:                               ; %else1168
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbz	w8, #7, LBB0_78
	b	LBB0_142
LBB0_114:                               ; %cond.load981
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d7
	ldr	s21, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_81
LBB0_115:                               ; %cond.load987
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v7[1]
	ld1.s	{ v21 }[1], [x9]
	shl.2d	v7, v15, #5
	ldr	q17, [sp, #656]                 ; 16-byte Folded Reload
	orr.16b	v17, v7, v17
	add.2d	v17, v29, v17
	tbz	w8, #2, LBB0_82
LBB0_116:                               ; %cond.load993
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d17
	ld1.s	{ v21 }[2], [x9]
	tbz	w8, #3, LBB0_83
LBB0_117:                               ; %cond.load999
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v17[1]
	ld1.s	{ v21 }[3], [x9]
	shl.2d	v17, v10, #5
	ldr	q22, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v22, v17, v22
	ldr	q23, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v22, v23, v22
	tbz	w8, #4, LBB0_84
LBB0_118:                               ; %cond.load1005
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d22
	ld1.s	{ v6 }[0], [x9]
	tbz	w8, #5, LBB0_85
LBB0_119:                               ; %cond.load1011
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v22[1]
	ld1.s	{ v6 }[1], [x9]
	shl.2d	v12, v9, #5
	ldr	q22, [sp, #672]                 ; 16-byte Folded Reload
	orr.16b	v22, v12, v22
	ldr	q23, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v22, v23, v22
	tbz	w8, #6, LBB0_86
LBB0_120:                               ; %cond.load1017
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d22
	ld1.s	{ v6 }[2], [x9]
	tbnz	w8, #7, LBB0_87
	b	LBB0_88
LBB0_121:                               ; %cond.load1030
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d22
	ldr	s25, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_90
LBB0_122:                               ; %cond.load1036
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v22[1]
	ld1.s	{ v25 }[1], [x9]
	ldr	q22, [sp, #544]                 ; 16-byte Folded Reload
	add.2d	v22, v22, v7
	add.2d	v22, v29, v22
	tbz	w8, #2, LBB0_91
LBB0_123:                               ; %cond.load1042
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d22
	ld1.s	{ v25 }[2], [x9]
	tbz	w8, #3, LBB0_92
LBB0_124:                               ; %cond.load1048
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v22[1]
	ld1.s	{ v25 }[3], [x9]
	ldr	q22, [sp, #560]                 ; 16-byte Folded Reload
	add.2d	v22, v22, v17
	ldr	q23, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v22, v23, v22
	tbz	w8, #4, LBB0_93
LBB0_125:                               ; %cond.load1054
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d22
	ld1.s	{ v26 }[0], [x9]
	tbz	w8, #5, LBB0_94
LBB0_126:                               ; %cond.load1060
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v22[1]
	ld1.s	{ v26 }[1], [x9]
	ldr	q22, [sp, #512]                 ; 16-byte Folded Reload
	add.2d	v22, v22, v12
	ldr	q23, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v22, v23, v22
	tbz	w8, #6, LBB0_95
LBB0_127:                               ; %cond.load1066
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d22
	ld1.s	{ v26 }[2], [x9]
	tbnz	w8, #7, LBB0_96
	b	LBB0_97
LBB0_128:                               ; %cond.load1079
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d22
	ldr	s27, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_99
LBB0_129:                               ; %cond.load1085
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v22[1]
	ld1.s	{ v27 }[1], [x9]
	ldr	q22, [sp, #480]                 ; 16-byte Folded Reload
	add.2d	v22, v22, v7
	add.2d	v22, v29, v22
	tbz	w8, #2, LBB0_100
LBB0_130:                               ; %cond.load1091
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d22
	ld1.s	{ v27 }[2], [x9]
	tbz	w8, #3, LBB0_101
LBB0_131:                               ; %cond.load1097
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v22[1]
	ld1.s	{ v27 }[3], [x9]
	ldr	q22, [sp, #496]                 ; 16-byte Folded Reload
	add.2d	v22, v22, v17
	ldr	q23, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v22, v23, v22
	tbz	w8, #4, LBB0_102
LBB0_132:                               ; %cond.load1103
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d22
	ld1.s	{ v28 }[0], [x9]
	tbz	w8, #5, LBB0_103
LBB0_133:                               ; %cond.load1109
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v22[1]
	ld1.s	{ v28 }[1], [x9]
	ldr	q22, [sp, #448]                 ; 16-byte Folded Reload
	add.2d	v22, v22, v12
	ldr	q23, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v22, v23, v22
	tbz	w8, #6, LBB0_104
LBB0_134:                               ; %cond.load1115
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d22
	ld1.s	{ v28 }[2], [x9]
	tbnz	w8, #7, LBB0_105
	b	LBB0_106
LBB0_135:                               ; %cond.load1128
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d4
	ldr	s22, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_108
LBB0_136:                               ; %cond.load1134
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v22 }[1], [x9]
	ldr	q4, [sp, #416]                  ; 16-byte Folded Reload
	add.2d	v4, v4, v7
	add.2d	v4, v29, v4
	tbz	w8, #2, LBB0_109
LBB0_137:                               ; %cond.load1140
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d4
	ld1.s	{ v22 }[2], [x9]
	tbz	w8, #3, LBB0_110
LBB0_138:                               ; %cond.load1146
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v22 }[3], [x9]
	ldr	q4, [sp, #432]                  ; 16-byte Folded Reload
	add.2d	v4, v4, v17
	ldr	q7, [sp, #688]                  ; 16-byte Folded Reload
	add.2d	v4, v7, v4
	tbz	w8, #4, LBB0_111
LBB0_139:                               ; %cond.load1152
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d4
	ld1.s	{ v23 }[0], [x9]
	tbz	w8, #5, LBB0_112
LBB0_140:                               ; %cond.load1158
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v23 }[1], [x9]
	ldr	q4, [sp, #384]                  ; 16-byte Folded Reload
	add.2d	v4, v4, v12
	ldr	q7, [sp, #704]                  ; 16-byte Folded Reload
	add.2d	v4, v7, v4
	tbz	w8, #6, LBB0_113
LBB0_141:                               ; %cond.load1164
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d4
	ld1.s	{ v23 }[2], [x9]
	tbz	w8, #7, LBB0_78
LBB0_142:                               ; %cond.load1170
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x8, v4[1]
	ld1.s	{ v23 }[3], [x8]
	b	LBB0_78
LBB0_143:                               ; %direct.false60.i243.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	x14, [sp, #544]                 ; 8-byte Folded Spill
	str	x16, [sp, #560]                 ; 8-byte Folded Spill
	mov	x8, #0                          ; =0x0
	ldr	q2, [sp, #9456]
	str	q2, [sp, #512]                  ; 16-byte Folded Spill
	ldr	q2, [sp, #9440]
	str	q2, [sp, #496]                  ; 16-byte Folded Spill
	ldr	q2, [sp, #9488]
	str	q2, [sp, #528]                  ; 16-byte Folded Spill
	ldr	q2, [sp, #576]                  ; 16-byte Folded Reload
	and.16b	v10, v2, v0
	ldr	q2, [sp, #592]                  ; 16-byte Folded Reload
	and.16b	v2, v2, v0
	sshll.2d	v21, v13, #0
	and.16b	v30, v21, v0
	sshll.2d	v21, v14, #0
	and.16b	v31, v21, v0
	dup.2d	v21, x27
	ldr	q22, [sp, #9472]
	str	q22, [sp, #480]                 ; 16-byte Folded Spill
	ldr	q23, [sp, #9520]
	ldr	q22, [sp, #9504]
	stp	q22, q23, [sp, #576]            ; 32-byte Folded Spill
	ushll2.2d	v22, v13, #0
	and.16b	v8, v22, v21
	ushll2.2d	v22, v14, #0
	and.16b	v9, v22, v21
	ushll.2d	v22, v13, #0
	and.16b	v11, v22, v21
	ushll.2d	v22, v14, #0
	and.16b	v15, v22, v21
	movi.2d	v21, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	b	LBB0_145
LBB0_144:                               ; %else1232
                                        ;   in Loop: Header=BB0_145 Depth=2
	add.2d	v25, v25, v9
	add.2d	v26, v26, v11
	add.2d	v27, v27, v8
	add.2d	v21, v21, v15
	fmov	x8, d21
	cmp	x8, #127
	b.ge	LBB0_177
LBB0_145:                               ; %direct.true97.i250.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s16
	add	x8, x12, x8, lsl #5
	movi.2d	v12, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbnz	w9, #0, LBB0_161
; %bb.146:                              ; %else1178
                                        ;   in Loop: Header=BB0_145 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_162
LBB0_147:                               ; %else1181
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w9, #2, LBB0_163
LBB0_148:                               ; %else1184
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w9, #3, LBB0_164
LBB0_149:                               ; %else1187
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w9, #4, LBB0_165
LBB0_150:                               ; %else1190
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w9, #5, LBB0_166
LBB0_151:                               ; %else1193
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w9, #6, LBB0_167
LBB0_152:                               ; %else1196
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w9, #7, LBB0_168
LBB0_153:                               ; %else1199
                                        ;   in Loop: Header=BB0_145 Depth=2
	fmov	w8, s16
	shl.2d	v22, v21, #5
	ldr	q23, [sp, #624]                 ; 16-byte Folded Reload
	orr.16b	v22, v22, v23
	add.2d	v22, v31, v22
	tbnz	w8, #0, LBB0_169
LBB0_154:                               ; %else1204
                                        ;   in Loop: Header=BB0_145 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_170
LBB0_155:                               ; %else1208
                                        ;   in Loop: Header=BB0_145 Depth=2
	shl.2d	v22, v25, #5
	ldr	q23, [sp, #656]                 ; 16-byte Folded Reload
	orr.16b	v22, v22, v23
	add.2d	v22, v2, v22
	tbnz	w8, #2, LBB0_171
LBB0_156:                               ; %else1212
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w8, #3, LBB0_172
LBB0_157:                               ; %else1216
                                        ;   in Loop: Header=BB0_145 Depth=2
	shl.2d	v22, v26, #5
	ldr	q23, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v22, v22, v23
	add.2d	v22, v30, v22
	tbnz	w8, #4, LBB0_173
LBB0_158:                               ; %else1220
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w8, #5, LBB0_174
LBB0_159:                               ; %else1224
                                        ;   in Loop: Header=BB0_145 Depth=2
	shl.2d	v22, v27, #5
	ldr	q23, [sp, #672]                 ; 16-byte Folded Reload
	orr.16b	v22, v22, v23
	add.2d	v22, v10, v22
	tbnz	w8, #6, LBB0_175
LBB0_160:                               ; %else1228
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbz	w8, #7, LBB0_144
	b	LBB0_176
LBB0_161:                               ; %cond.load1177
                                        ;   in Loop: Header=BB0_145 Depth=2
	ldr	s12, [x8]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_147
LBB0_162:                               ; %cond.load1180
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x11, x8, #4
	ld1.s	{ v12 }[1], [x11]
	tbz	w9, #2, LBB0_148
LBB0_163:                               ; %cond.load1183
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x11, x8, #8
	ld1.s	{ v12 }[2], [x11]
	tbz	w9, #3, LBB0_149
LBB0_164:                               ; %cond.load1186
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x11, x8, #12
	ld1.s	{ v12 }[3], [x11]
	tbz	w9, #4, LBB0_150
LBB0_165:                               ; %cond.load1189
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x11, x8, #16
	ld1.s	{ v28 }[0], [x11]
	tbz	w9, #5, LBB0_151
LBB0_166:                               ; %cond.load1192
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x11, x8, #20
	ld1.s	{ v28 }[1], [x11]
	tbz	w9, #6, LBB0_152
LBB0_167:                               ; %cond.load1195
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x11, x8, #24
	ld1.s	{ v28 }[2], [x11]
	tbz	w9, #7, LBB0_153
LBB0_168:                               ; %cond.load1198
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x8, x8, #28
	ld1.s	{ v28 }[3], [x8]
	fmov	w8, s16
	shl.2d	v22, v21, #5
	ldr	q23, [sp, #624]                 ; 16-byte Folded Reload
	orr.16b	v22, v22, v23
	add.2d	v22, v31, v22
	tbz	w8, #0, LBB0_154
LBB0_169:                               ; %cond.store
                                        ;   in Loop: Header=BB0_145 Depth=2
	fmov	x9, d22
	str	s12, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_155
LBB0_170:                               ; %cond.store1205
                                        ;   in Loop: Header=BB0_145 Depth=2
	mov.d	x9, v22[1]
	st1.s	{ v12 }[1], [x9]
	shl.2d	v22, v25, #5
	ldr	q23, [sp, #656]                 ; 16-byte Folded Reload
	orr.16b	v22, v22, v23
	add.2d	v22, v2, v22
	tbz	w8, #2, LBB0_156
LBB0_171:                               ; %cond.store1209
                                        ;   in Loop: Header=BB0_145 Depth=2
	fmov	x9, d22
	st1.s	{ v12 }[2], [x9]
	tbz	w8, #3, LBB0_157
LBB0_172:                               ; %cond.store1213
                                        ;   in Loop: Header=BB0_145 Depth=2
	mov.d	x9, v22[1]
	st1.s	{ v12 }[3], [x9]
	shl.2d	v22, v26, #5
	ldr	q23, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v22, v22, v23
	add.2d	v22, v30, v22
	tbz	w8, #4, LBB0_158
LBB0_173:                               ; %cond.store1217
                                        ;   in Loop: Header=BB0_145 Depth=2
	fmov	x9, d22
	str	s28, [x9]
	tbz	w8, #5, LBB0_159
LBB0_174:                               ; %cond.store1221
                                        ;   in Loop: Header=BB0_145 Depth=2
	mov.d	x9, v22[1]
	st1.s	{ v28 }[1], [x9]
	shl.2d	v22, v27, #5
	ldr	q23, [sp, #672]                 ; 16-byte Folded Reload
	orr.16b	v22, v22, v23
	add.2d	v22, v10, v22
	tbz	w8, #6, LBB0_160
LBB0_175:                               ; %cond.store1225
                                        ;   in Loop: Header=BB0_145 Depth=2
	fmov	x9, d22
	st1.s	{ v28 }[2], [x9]
	tbz	w8, #7, LBB0_144
LBB0_176:                               ; %cond.store1229
                                        ;   in Loop: Header=BB0_145 Depth=2
	mov.d	x8, v22[1]
	st1.s	{ v28 }[3], [x8]
	b	LBB0_144
LBB0_177:                               ; %direct.false98.i252.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q21, q22, [sp, #496]            ; 32-byte Folded Reload
	and.16b	v21, v14, v21
	and.16b	v22, v13, v22
	fmul.4s	v22, v22, v22
	fmul.4s	v21, v21, v21
	fadd.4s	v20, v20, v21
	fadd.4s	v19, v19, v22
	ldr	q21, [sp, #528]                 ; 16-byte Folded Reload
	and.16b	v21, v13, v21
	ldr	q22, [sp, #480]                 ; 16-byte Folded Reload
	and.16b	v22, v14, v22
	fmul.4s	v22, v22, v22
	fmul.4s	v21, v21, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v22
	and.16b	v7, v14, v7
	and.16b	v17, v13, v17
	ldp	q21, q22, [sp, #576]            ; 32-byte Folded Reload
	and.16b	v21, v14, v21
	and.16b	v22, v13, v22
	fmul.4s	v22, v22, v22
	fmul.4s	v21, v21, v21
	fadd.4s	v4, v4, v21
	fadd.4s	v6, v6, v22
	and.16b	v6, v13, v6
	and.16b	v4, v14, v4
	ldp	q22, q21, [sp, #16]             ; 32-byte Folded Reload
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	fadd.4s	v22, v22, v19
	fadd.4s	v20, v21, v20
	ldr	q28, [sp, #320]                 ; 16-byte Folded Reload
	zip1.8b	v21, v28, v0
	ushll.4s	v21, v21, #0
	shl.4s	v21, v21, #31
	cmlt.4s	v21, v21, #0
	and.16b	v20, v21, v20
	zip2.8b	v21, v28, v0
	ushll.4s	v21, v21, #0
	shl.4s	v21, v21, #31
	cmlt.4s	v21, v21, #0
	movi.2d	v23, #0000000000000000
	ldr	q25, [sp, #112]                 ; 16-byte Folded Reload
	mov.b	v23[6], v25[7]
	and.16b	v21, v21, v22
	ushll.4s	v22, v23, #0
	shl.4s	v22, v22, #31
	cmlt.4s	v22, v22, #0
	bif.16b	v19, v21, v22
	fadd.4s	v17, v17, v19
	fadd.4s	v7, v7, v20
	fadd.4s	v7, v4, v7
	fadd.4s	v4, v6, v17
	fadd.4s	v4, v18, v4
	fadd.4s	v6, v5, v7
	ldp	q7, q5, [sp, #48]               ; 32-byte Folded Reload
	uzp1.4s	v5, v7, v5
	ldp	q17, q7, [sp, #80]              ; 32-byte Folded Reload
	uzp1.4s	v7, v17, v7
	movi.4s	v18, #1
	eor.16b	v17, v5, v18
	mov.s	w9, v17[1]
	mov.s	w11, v17[2]
	eor.16b	v20, v7, v18
	mov.s	w16, v17[3]
	fmov	w8, s17
	add	x13, sp, #792
	bfxil	x13, x8, #0, #3
	str	d25, [sp, #792]
	ldrb	w14, [x13]
	and	x13, x8, #0x7
	umov.b	w8, v25[0]
	str	q6, [sp, #1056]
	str	q4, [sp, #1072]
	add	x17, sp, #1056
	ldr	s17, [x17, x13, lsl #2]
	ands	w13, w8, #0x1
	tst	w13, w14
	movi	d26, #0000000000000000
	fcsel	s17, s17, s26, ne
	add	x14, sp, #792
	bfxil	x14, x9, #0, #3
	ldrb	w14, [x14]
	and	x17, x9, #0x7
	umov.b	w9, v25[1]
	str	q6, [sp, #1024]
	str	q4, [sp, #1040]
	add	x0, sp, #1024
	ldr	s18, [x0, x17, lsl #2]
	ands	w17, w9, #0x1
	tst	w17, w14
	fcsel	s18, s18, s26, ne
	add	x14, sp, #792
	bfxil	x14, x11, #0, #3
	ldrb	w17, [x14]
	umov.b	w14, v25[2]
	and	x11, x11, #0x7
	stp	q6, q4, [sp, #992]
	add	x0, sp, #992
	ldr	s19, [x0, x11, lsl #2]
	ands	w11, w14, #0x1
	tst	w11, w17
	fcsel	s19, s19, s26, ne
	add	x11, sp, #792
	bfxil	x11, x16, #0, #3
	ldrb	w11, [x11]
	and	x16, x16, #0x7
	umov.b	w0, v25[3]
	stp	q6, q4, [sp, #960]
	add	x17, sp, #960
	ldr	s21, [x17, x16, lsl #2]
	ands	w16, w0, #0x1
	tst	w16, w11
	mov.s	w11, v20[1]
	mov.s	w16, v20[2]
	fcsel	s21, s21, s26, ne
	mov.s	w17, v20[3]
	fmov	w2, s20
	and	x4, x2, #0x7
	add	x5, sp, #792
	bfxil	x5, x2, #0, #3
	ldrb	w2, [x5]
	umov.b	w28, v25[4]
	and	w2, w28, w2
	str	q6, [sp, #1184]
	str	q4, [sp, #1200]
	add	x5, sp, #1184
	ldr	s20, [x5, x4, lsl #2]
	tst	w2, #0x1
	fcsel	s20, s20, s26, ne
	add	x2, sp, #792
	bfxil	x2, x11, #0, #3
	ldrb	w2, [x2]
	and	x11, x11, #0x7
	umov.b	w30, v25[5]
	str	q6, [sp, #1152]
	str	q4, [sp, #1168]
	add	x4, sp, #1152
	ldr	s22, [x4, x11, lsl #2]
	ands	w11, w30, #0x1
	tst	w11, w2
	fcsel	s22, s22, s26, ne
	add	x11, sp, #792
	bfxil	x11, x16, #0, #3
	ldrb	w2, [x11]
	and	x16, x16, #0x7
	umov.b	w11, v25[6]
	str	q6, [sp, #1120]
	str	q4, [sp, #1136]
	add	x4, sp, #1120
	ldr	s23, [x4, x16, lsl #2]
	ands	w16, w11, #0x1
	tst	w16, w2
	fcsel	s23, s23, s26, ne
	add	x16, sp, #792
	bfxil	x16, x17, #0, #3
	ldrb	w16, [x16]
	umov.b	w2, v25[7]
	and	x17, x17, #0x7
	str	q6, [sp, #1088]
	str	q4, [sp, #1104]
	add	x4, sp, #1088
	ldr	s25, [x4, x17, lsl #2]
	ands	w17, w2, #0x1
	tst	w17, w16
	fcsel	s25, s25, s26, ne
	mov.s	v20[1], v22[0]
	mov.s	v20[2], v23[0]
	mov.s	v20[3], v25[0]
	mov.s	v17[1], v18[0]
	mov.s	v17[2], v19[0]
	mov.s	v17[3], v21[0]
	fadd.4s	v6, v6, v17
	fadd.4s	v4, v4, v20
	movi.4s	v17, #2
	eor.16b	v7, v7, v17
	eor.16b	v5, v5, v17
	fmov	w16, s5
	add	x17, sp, #792
	bfxil	x17, x16, #0, #3
	ldrb	w17, [x17]
	and	x16, x16, #0x7
	stp	q6, q4, [sp, #928]
	add	x4, sp, #928
	ldr	s5, [x4, x16, lsl #2]
	tst	w13, w17
	fcsel	s5, s5, s26, ne
	fmov	w16, s7
	and	x17, x16, #0x7
	add	x4, sp, #792
	bfxil	x4, x16, #0, #3
	ldrb	w16, [x4]
	and	w16, w28, w16
	stp	q6, q4, [sp, #896]
	add	x4, sp, #896
	ldr	s7, [x4, x17, lsl #2]
	tst	w16, #0x1
	fcsel	s7, s7, s26, ne
	fadd.4s	v4, v4, v7
	tst	w13, w28
	fcsel	s4, s4, s26, ne
	ands	w8, w8, #0x1
	fadd.4s	v5, v6, v5
	fadd	s4, s5, s4
	fcsel	s5, s4, s26, ne
	tst	w9, #0x1
	fcsel	s6, s5, s26, ne
	tst	w14, #0x1
	fcsel	s7, s5, s26, ne
	tst	w0, #0x1
	fcsel	s17, s5, s26, ne
	tst	w8, w28
	fcsel	s18, s4, s26, ne
	tst	w30, #0x1
	fcsel	s19, s5, s26, ne
	tst	w11, #0x1
	fcsel	s20, s5, s26, ne
	tst	w2, #0x1
	shl.8b	v4, v28, #7
	cmlt.8b	v4, v4, #0
	ldr	d21, [sp, #136]                 ; 8-byte Folded Reload
	and.8b	v4, v4, v21
	addv.8b	b4, v4
	fmov	w8, s4
	fcsel	s21, s5, s26, ne
	mov.s	v5[1], v6[0]
	mov.s	v5[2], v7[0]
	mov.s	v5[3], v17[0]
	mov.s	v18[1], v19[0]
	mov.s	v18[2], v20[0]
	mov.s	v18[3], v21[0]
	ldr	w9, [sp, #236]                  ; 4-byte Folded Reload
	rbit	w9, w9
	clz	w9, w9
	stp	q5, q18, [sp, #864]
	and	x9, x9, #0x7
	add	x11, sp, #864
	ldr	s5, [x11, x9, lsl #2]
	mov	b6, v28[0]
	mov.b	v6[4], v28[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	mov	b7, v28[2]
	mov.b	v7[4], v28[3]
	ldp	q18, q17, [sp, #160]            ; 32-byte Folded Reload
	and.16b	v6, v6, v18
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v17
	mov	b17, v28[4]
	mov.b	v17[4], v28[5]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	ldp	q18, q19, [sp, #192]            ; 32-byte Folded Reload
	and.16b	v17, v17, v18
	mov	b18, v28[6]
	mov.b	v18[4], v28[7]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	and.16b	v18, v18, v19
	stp	q17, q18, [sp, #832]
	stp	q6, q7, [sp, #800]
	ldr	x30, [sp, #544]                 ; 8-byte Folded Reload
	and	x9, x30, #0x7
	add	x11, sp, #800
	ldr	x9, [x11, x9, lsl #3]
	sub	x9, x9, x30
	add	x9, x12, x9, lsl #2
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbz	w8, #0, LBB0_179
; %bb.178:                              ; %cond.load1234
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	s6, [x9]
LBB0_179:                               ; %else1235
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	w13, [sp, #372]                 ; 4-byte Folded Reload
	ldr	x2, [sp, #560]                  ; 8-byte Folded Reload
	tbz	w8, #1, LBB0_181
; %bb.180:                              ; %cond.load1237
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #4
	ld1.s	{ v6 }[1], [x11]
LBB0_181:                               ; %else1238
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	w16, [sp, #364]                 ; 4-byte Folded Reload
	mov	w17, #4092                      ; =0xffc
	adrp	x5, lCPI0_1@PAGE
	adrp	x4, lCPI0_8@PAGE
	ldr	w14, [sp, #368]                 ; 4-byte Folded Reload
	ldr	x0, [sp, #376]                  ; 8-byte Folded Reload
	tbnz	w8, #2, LBB0_254
; %bb.182:                              ; %else1241
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #3, LBB0_255
LBB0_183:                               ; %else1244
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #4, LBB0_256
LBB0_184:                               ; %else1247
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #5, LBB0_257
LBB0_185:                               ; %else1250
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #6, LBB0_258
LBB0_186:                               ; %else1253
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w8, #7, LBB0_188
LBB0_187:                               ; %cond.load1255
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x9, #28
	ld1.s	{ v7 }[3], [x8]
LBB0_188:                               ; %else1256
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	movi	d17, #0000000000000000
	fadd	s5, s5, s17
	mov	w8, #49152                      ; =0xc000
	movk	w8, #17535, lsl #16
	fmov	s17, w8
	fdiv	s5, s5, s17
	add	x8, sp, #1376
	add	x8, x8, x3
	ldp	q17, q18, [x8]
	zip2.8b	v19, v28, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	bif.16b	v7, v18, v19
	zip1.8b	v18, v28, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	bif.16b	v6, v17, v18
	stp	q6, q7, [x8]
	mov	w8, #50604                      ; =0xc5ac
	movk	w8, #14119, lsl #16
	fmov	s6, w8
	fadd	s5, s5, s6
	fsqrt	s5, s5
	dup.4s	v5, v5[0]
	ldr	q6, [sp, #144]                  ; 16-byte Folded Reload
	fmov	x8, d6
	add	x8, x2, x8, lsl #2
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	b	LBB0_190
LBB0_189:                               ; %else1372
                                        ;   in Loop: Header=BB0_190 Depth=2
	add.2d	v7, v7, v9
	add.2d	v17, v17, v11
	add.2d	v18, v18, v8
	add.2d	v6, v6, v15
	fmov	x9, d6
	cmp	x9, #127
	b.ge	LBB0_238
LBB0_190:                               ; %direct.true121.i259.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w11, s16
	shl.2d	v19, v6, #5
	ldr	q20, [sp, #624]                 ; 16-byte Folded Reload
	orr.16b	v21, v19, v20
	add.2d	v22, v24, v21
	movi.2d	v20, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbnz	w11, #0, LBB0_214
; %bb.191:                              ; %else1263
                                        ;   in Loop: Header=BB0_190 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_215
LBB0_192:                               ; %else1269
                                        ;   in Loop: Header=BB0_190 Depth=2
	shl.2d	v22, v7, #5
	ldr	q23, [sp, #656]                 ; 16-byte Folded Reload
	orr.16b	v22, v22, v23
	add.2d	v23, v29, v22
	tbnz	w11, #2, LBB0_216
LBB0_193:                               ; %else1275
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w11, #3, LBB0_217
LBB0_194:                               ; %else1281
                                        ;   in Loop: Header=BB0_190 Depth=2
	shl.2d	v23, v17, #5
	ldr	q25, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v23, v23, v25
	ldr	q25, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v23
	tbnz	w11, #4, LBB0_218
LBB0_195:                               ; %else1287
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w11, #5, LBB0_219
LBB0_196:                               ; %else1293
                                        ;   in Loop: Header=BB0_190 Depth=2
	shl.2d	v25, v18, #5
	ldr	q26, [sp, #672]                 ; 16-byte Folded Reload
	orr.16b	v25, v25, v26
	ldr	q26, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v25
	tbnz	w11, #6, LBB0_220
LBB0_197:                               ; %else1299
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w11, #7, LBB0_221
LBB0_198:                               ; %else1305
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	w11, s16
	add.2d	v27, v31, v21
	movi.2d	v26, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w11, #0, LBB0_222
LBB0_199:                               ; %else1312
                                        ;   in Loop: Header=BB0_190 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_223
LBB0_200:                               ; %else1318
                                        ;   in Loop: Header=BB0_190 Depth=2
	add.2d	v22, v2, v22
	tbnz	w11, #2, LBB0_224
LBB0_201:                               ; %else1324
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w11, #3, LBB0_225
LBB0_202:                               ; %else1330
                                        ;   in Loop: Header=BB0_190 Depth=2
	add.2d	v22, v30, v23
	tbnz	w11, #4, LBB0_226
LBB0_203:                               ; %else1336
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w11, #5, LBB0_227
LBB0_204:                               ; %else1342
                                        ;   in Loop: Header=BB0_190 Depth=2
	add.2d	v22, v10, v25
	tbnz	w11, #6, LBB0_228
LBB0_205:                               ; %else1348
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w11, #7, LBB0_229
LBB0_206:                               ; %else1354
                                        ;   in Loop: Header=BB0_190 Depth=2
	fdiv.4s	v20, v20, v5
	fmov	w11, s16
	fmul.4s	v20, v20, v26
	add	x9, x8, x9, lsl #5
	tbnz	w11, #0, LBB0_230
LBB0_207:                               ; %else1358
                                        ;   in Loop: Header=BB0_190 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_231
LBB0_208:                               ; %else1360
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w11, #2, LBB0_232
LBB0_209:                               ; %else1362
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w11, #3, LBB0_233
LBB0_210:                               ; %else1364
                                        ;   in Loop: Header=BB0_190 Depth=2
	fdiv.4s	v19, v19, v5
	fmul.4s	v19, v19, v21
	tbnz	w11, #4, LBB0_234
LBB0_211:                               ; %else1366
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w11, #5, LBB0_235
LBB0_212:                               ; %else1368
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbnz	w11, #6, LBB0_236
LBB0_213:                               ; %else1370
                                        ;   in Loop: Header=BB0_190 Depth=2
	tbz	w11, #7, LBB0_189
	b	LBB0_237
LBB0_214:                               ; %cond.load1259
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x12, d22
	ldr	s20, [x12]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_192
LBB0_215:                               ; %cond.load1265
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x12, v22[1]
	ld1.s	{ v20 }[1], [x12]
	shl.2d	v22, v7, #5
	ldr	q23, [sp, #656]                 ; 16-byte Folded Reload
	orr.16b	v22, v22, v23
	add.2d	v23, v29, v22
	tbz	w11, #2, LBB0_193
LBB0_216:                               ; %cond.load1271
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x12, d23
	ld1.s	{ v20 }[2], [x12]
	tbz	w11, #3, LBB0_194
LBB0_217:                               ; %cond.load1277
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x12, v23[1]
	ld1.s	{ v20 }[3], [x12]
	shl.2d	v23, v17, #5
	ldr	q25, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v23, v23, v25
	ldr	q25, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v23
	tbz	w11, #4, LBB0_195
LBB0_218:                               ; %cond.load1283
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x12, d25
	ld1.s	{ v19 }[0], [x12]
	tbz	w11, #5, LBB0_196
LBB0_219:                               ; %cond.load1289
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x12, v25[1]
	ld1.s	{ v19 }[1], [x12]
	shl.2d	v25, v18, #5
	ldr	q26, [sp, #672]                 ; 16-byte Folded Reload
	orr.16b	v25, v25, v26
	ldr	q26, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v25
	tbz	w11, #6, LBB0_197
LBB0_220:                               ; %cond.load1295
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x12, d26
	ld1.s	{ v19 }[2], [x12]
	tbz	w11, #7, LBB0_198
LBB0_221:                               ; %cond.load1301
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x11, v26[1]
	ld1.s	{ v19 }[3], [x11]
	fmov	w11, s16
	add.2d	v27, v31, v21
	movi.2d	v26, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbz	w11, #0, LBB0_199
LBB0_222:                               ; %cond.load1308
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x12, d27
	ldr	s26, [x12]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_200
LBB0_223:                               ; %cond.load1314
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x12, v27[1]
	ld1.s	{ v26 }[1], [x12]
	add.2d	v22, v2, v22
	tbz	w11, #2, LBB0_201
LBB0_224:                               ; %cond.load1320
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x12, d22
	ld1.s	{ v26 }[2], [x12]
	tbz	w11, #3, LBB0_202
LBB0_225:                               ; %cond.load1326
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x12, v22[1]
	ld1.s	{ v26 }[3], [x12]
	add.2d	v22, v30, v23
	tbz	w11, #4, LBB0_203
LBB0_226:                               ; %cond.load1332
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x12, d22
	ld1.s	{ v21 }[0], [x12]
	tbz	w11, #5, LBB0_204
LBB0_227:                               ; %cond.load1338
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x12, v22[1]
	ld1.s	{ v21 }[1], [x12]
	add.2d	v22, v10, v25
	tbz	w11, #6, LBB0_205
LBB0_228:                               ; %cond.load1344
                                        ;   in Loop: Header=BB0_190 Depth=2
	fmov	x12, d22
	ld1.s	{ v21 }[2], [x12]
	tbz	w11, #7, LBB0_206
LBB0_229:                               ; %cond.load1350
                                        ;   in Loop: Header=BB0_190 Depth=2
	mov.d	x11, v22[1]
	ld1.s	{ v21 }[3], [x11]
	fdiv.4s	v20, v20, v5
	fmov	w11, s16
	fmul.4s	v20, v20, v26
	add	x9, x8, x9, lsl #5
	tbz	w11, #0, LBB0_207
LBB0_230:                               ; %cond.store1357
                                        ;   in Loop: Header=BB0_190 Depth=2
	str	s20, [x9]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_208
LBB0_231:                               ; %cond.store1359
                                        ;   in Loop: Header=BB0_190 Depth=2
	add	x12, x9, #4
	st1.s	{ v20 }[1], [x12]
	tbz	w11, #2, LBB0_209
LBB0_232:                               ; %cond.store1361
                                        ;   in Loop: Header=BB0_190 Depth=2
	add	x12, x9, #8
	st1.s	{ v20 }[2], [x12]
	tbz	w11, #3, LBB0_210
LBB0_233:                               ; %cond.store1363
                                        ;   in Loop: Header=BB0_190 Depth=2
	add	x12, x9, #12
	st1.s	{ v20 }[3], [x12]
	fdiv.4s	v19, v19, v5
	fmul.4s	v19, v19, v21
	tbz	w11, #4, LBB0_211
LBB0_234:                               ; %cond.store1365
                                        ;   in Loop: Header=BB0_190 Depth=2
	str	s19, [x9, #16]
	tbz	w11, #5, LBB0_212
LBB0_235:                               ; %cond.store1367
                                        ;   in Loop: Header=BB0_190 Depth=2
	add	x12, x9, #20
	st1.s	{ v19 }[1], [x12]
	tbz	w11, #6, LBB0_213
LBB0_236:                               ; %cond.store1369
                                        ;   in Loop: Header=BB0_190 Depth=2
	add	x12, x9, #24
	st1.s	{ v19 }[2], [x12]
	tbz	w11, #7, LBB0_189
LBB0_237:                               ; %cond.store1371
                                        ;   in Loop: Header=BB0_190 Depth=2
	add	x9, x9, #28
	st1.s	{ v19 }[3], [x9]
	b	LBB0_189
LBB0_238:                               ; %direct.false122.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x10, x3
	ldp	q6, q2, [x8]
	zip1.8b	v7, v28, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v6, v7, v6
	fmov	w8, s4
	fdiv.4s	v6, v6, v5
	add	x9, sp, #1376
	add	x9, x9, x3
	ldp	q16, q4, [x9]
	and.16b	v7, v7, v16
	fmul.4s	v6, v6, v7
	ldr	q7, [sp, #240]                  ; 16-byte Folded Reload
	str	q7, [sp, #720]
	ldr	q7, [sp, #256]                  ; 16-byte Folded Reload
	str	q7, [sp, #736]
	ldr	q7, [sp, #272]                  ; 16-byte Folded Reload
	str	q7, [sp, #752]
	ldr	q7, [sp, #288]                  ; 16-byte Folded Reload
	str	q7, [sp, #768]
	and	x9, x30, #0x7
	add	x11, sp, #720
	ldr	x9, [x11, x9, lsl #3]
	sub	x9, x9, x30
	add	x9, x2, x9, lsl #2
	tbnz	w8, #0, LBB0_259
; %bb.239:                              ; %else1375
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #1, LBB0_260
LBB0_240:                               ; %else1377
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #2, LBB0_261
LBB0_241:                               ; %else1379
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w8, #3, LBB0_243
LBB0_242:                               ; %cond.store1380
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #12
	st1.s	{ v6 }[3], [x11]
LBB0_243:                               ; %else1381
                                        ;   in Loop: Header=BB0_3 Depth=1
	zip2.8b	v6, v28, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v2, v6, v2
	fdiv.4s	v2, v2, v5
	and.16b	v4, v6, v4
	fmul.4s	v2, v2, v4
	tbnz	w8, #4, LBB0_262
; %bb.244:                              ; %else1383
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #5, LBB0_263
LBB0_245:                               ; %else1385
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #6, LBB0_264
LBB0_246:                               ; %else1387
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w8, #7, LBB0_2
	b	LBB0_265
LBB0_247:                               ; %cond.load956
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	s23, [x8]
	tbz	w9, #1, LBB0_70
LBB0_248:                               ; %cond.load959
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x8, #4
	ld1.s	{ v23 }[1], [x11]
	tbz	w9, #2, LBB0_71
LBB0_249:                               ; %cond.load962
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x8, #8
	ld1.s	{ v23 }[2], [x11]
	tbz	w9, #3, LBB0_72
LBB0_250:                               ; %cond.load965
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x8, #12
	ld1.s	{ v23 }[3], [x11]
	tbz	w9, #4, LBB0_73
LBB0_251:                               ; %cond.load968
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x8, #16
	ld1.s	{ v25 }[0], [x11]
	tbz	w9, #5, LBB0_74
LBB0_252:                               ; %cond.load971
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x8, #20
	ld1.s	{ v25 }[1], [x11]
	tbz	w9, #6, LBB0_75
LBB0_253:                               ; %cond.load974
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x8, #24
	ld1.s	{ v25 }[2], [x11]
	tbnz	w9, #7, LBB0_76
	b	LBB0_77
LBB0_254:                               ; %cond.load1240
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #8
	ld1.s	{ v6 }[2], [x11]
	tbz	w8, #3, LBB0_183
LBB0_255:                               ; %cond.load1243
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #12
	ld1.s	{ v6 }[3], [x11]
	tbz	w8, #4, LBB0_184
LBB0_256:                               ; %cond.load1246
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #16
	ld1.s	{ v7 }[0], [x11]
	tbz	w8, #5, LBB0_185
LBB0_257:                               ; %cond.load1249
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #20
	ld1.s	{ v7 }[1], [x11]
	tbz	w8, #6, LBB0_186
LBB0_258:                               ; %cond.load1252
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #24
	ld1.s	{ v7 }[2], [x11]
	tbnz	w8, #7, LBB0_187
	b	LBB0_188
LBB0_259:                               ; %cond.store1374
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s6, [x9]
	tbz	w8, #1, LBB0_240
LBB0_260:                               ; %cond.store1376
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #4
	st1.s	{ v6 }[1], [x11]
	tbz	w8, #2, LBB0_241
LBB0_261:                               ; %cond.store1378
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #8
	st1.s	{ v6 }[2], [x11]
	tbnz	w8, #3, LBB0_242
	b	LBB0_243
LBB0_262:                               ; %cond.store1382
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s2, [x9, #16]
	tbz	w8, #5, LBB0_245
LBB0_263:                               ; %cond.store1384
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #20
	st1.s	{ v2 }[1], [x11]
	tbz	w8, #6, LBB0_246
LBB0_264:                               ; %cond.store1386
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #24
	st1.s	{ v2 }[2], [x11]
	tbz	w8, #7, LBB0_2
LBB0_265:                               ; %cond.store1388
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x9, #28
	st1.s	{ v2 }[3], [x8]
	b	LBB0_2
LBB0_266:                               ; %block.batch.exit.loopexit
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	stp	w0, w14, [x9]
	str	w13, [x9, #8]
	mov	w8, #24                         ; =0x18
	str	w8, [x9, #36]
LBB0_267:                               ; %block.batch.exit
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #1376
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh18, Lloh19
                                        ; -- End function
.subsections_via_symbols


/tmp/luisa-cohort-private.qfZvpM/capture/rmsnorm-137x1023-r0-l8-p0/object/tile_xir_w8_77315_1788916371104791_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x2, lsl #12   ; =0x2000
      2c:      	sub	sp, sp, #0x560
      30:      	str	x0, [sp, #0x150]
      34:      	str	w3, [sp, #0x168]
      38:      	cbz	w3, 0x3494 <ltmp0+0x3494>
      3c:      	mov	w16, #0x0               ; =0
      40:      	add	x8, sp, #0x560
      44:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
      48:      	add	x10, x10, #0x560
      4c:      	ldp	w11, w9, [x2, #0x2c]
      50:      	str	w11, [sp, #0x164]
      54:      	str	w9, [sp, #0x160]
      58:      	mov	w17, #0xffc             ; =4092
      5c:      	mov	w15, #0x4               ; =4
      60:      	adrp	x5, 0x0 <ltmp0>
      64:      	dup.2d	v0, x8
      68:      	adrp	x1, 0x0 <ltmp0>
      6c:      	adrp	x6, 0x0 <ltmp0>
      70:      	adrp	x7, 0x0 <ltmp0>
      74:      	dup.2d	v1, x10
      78:      	adrp	x19, 0x0 <ltmp0>
      7c:      	adrp	x4, 0x0 <ltmp0>
      80:      	adrp	x20, 0x0 <ltmp0>
      84:      	adrp	x21, 0x0 <ltmp0>
      88:      	dup.2d	v2, x15
      8c:      	str	q2, [sp, #0x130]
      90:      	adrp	x22, 0x0 <ltmp0>
      94:      	adrp	x8, 0x0 <ltmp0>
      98:      	ldr	q3, [x8]
      9c:      	adrp	x23, 0x0 <ltmp0>
      a0:      	adrp	x24, 0x0 <ltmp0>
      a4:      	adrp	x25, 0x0 <ltmp0>
      a8:      	adrp	x26, 0x0 <ltmp0>
      ac:      	mov	w27, #0x1               ; =1
      b0:      	ldp	w8, w9, [x2]
      b4:      	ldp	w11, w12, [x2, #0x8]
      b8:      	str	x2, [sp, #0x8]
      bc:      	str	x12, [sp, #0x158]
      c0:      	str	q3, [sp, #0x260]
      c4:      	b	0x108 <ltmp0+0x108>
      c8:      	add	w8, w0, #0x1
      cc:      	ldr	w9, [sp, #0x164]
      d0:      	cmp	w8, w9
      d4:      	cset	w9, eq
      d8:      	csinc	w8, wzr, w0, eq
      dc:      	cinc	w11, w14, eq
      e0:      	ldr	w12, [sp, #0x160]
      e4:      	cmp	w11, w12
      e8:      	cset	w12, eq
      ec:      	ands	w12, w9, w12
      f0:      	csel	w9, wzr, w11, ne
      f4:      	add	w11, w13, w12
      f8:      	add	w16, w16, #0x1
      fc:      	ldr	w12, [sp, #0x168]
     100:      	cmp	w16, w12
     104:      	b.eq	0x3480 <ltmp0+0x3480>
     108:      	str	w11, [sp, #0x174]
     10c:      	mov	x14, x9
     110:      	mov	x0, x8
     114:      	ubfiz	x8, x8, #5, #32
     118:      	ldr	x13, [sp, #0x158]
     11c:      	cmp	x8, x13
     120:      	csel	x9, x8, xzr, ls
     124:      	subs	x11, x13, x9
     128:      	cmp	x11, #0x20
     12c:      	mov	w12, #0x20              ; =32
     130:      	csel	x11, x11, x12, lo
     134:      	cmp	x13, x9
     138:      	ccmp	x8, x13, #0x2, hi
     13c:      	csel	x9, x11, xzr, ls
     140:      	cmp	x9, #0x20
     144:      	str	w14, [sp, #0x170]
     148:      	str	x0, [sp, #0x178]
     14c:      	b.lo	0x18d8 <ltmp0+0x18d8>
     150:      	mov	x8, #0x0                ; =0
     154:      	ldr	x9, [sp, #0x150]
     158:      	ldr	x11, [x9]
     15c:      	ldr	x3, [x9, #0x10]
     160:      	ldr	x9, [x9, #0x30]
     164:      	str	x9, [sp, #0x250]
     168:      	ubfiz	w9, w0, #2, #27
     16c:      	umull	x13, w9, w17
     170:      	str	w9, [sp, #0x1d0]
     174:      	umaddl	x9, w9, w17, x11
     178:      	add	x14, x9, x8
     17c:      	ldp	q2, q4, [x14]
     180:      	add	x14, x10, x8
     184:      	stp	q2, q4, [x14]
     188:      	add	x8, x8, #0x20
     18c:      	cmp	x8, #0xfe0
     190:      	b.ne	0x178 <ltmp0+0x178>
     194:      	add	x8, x13, #0xfe0
     198:      	str	x11, [sp, #0x1e0]
     19c:      	mov	x17, x8
     1a0:      	add	x8, x11, x8
     1a4:      	add	x14, x8, #0x4
     1a8:      	add	x0, x8, #0x8
     1ac:      	add	x28, x8, #0xc
     1b0:      	add	x30, x8, #0x14
     1b4:      	add	x11, x8, #0x18
     1b8:      	ldr	s2, [x8]
     1bc:      	ld1.s	{ v2 }[1], [x14]
     1c0:      	ld1.s	{ v2 }[2], [x0]
     1c4:      	ld1.s	{ v2 }[3], [x28]
     1c8:      	ldr	s4, [x8, #0x10]
     1cc:      	ld1.s	{ v4 }[1], [x30]
     1d0:      	ld1.s	{ v4 }[2], [x11]
     1d4:      	add	x8, x10, #0xffc
     1d8:      	ld1.s	{ v4 }[3], [x8]
     1dc:      	str	q2, [sp, #0x2a0]
     1e0:      	str	q2, [sp, #0x2540]
     1e4:      	str	q4, [sp, #0x210]
     1e8:      	str	q4, [sp, #0x2550]
     1ec:      	ldr	q2, [sp, #0x1560]
     1f0:      	ldr	q4, [sp, #0x1570]
     1f4:      	fmul.4s	v10, v4, v4
     1f8:      	fmul.4s	v9, v2, v2
     1fc:      	ldr	q2, [sp, #0x1580]
     200:      	ldr	q4, [sp, #0x1590]
     204:      	fmul.4s	v8, v4, v4
     208:      	fmul.4s	v31, v2, v2
     20c:      	ldr	q2, [sp, #0x15a0]
     210:      	ldr	q4, [sp, #0x15b0]
     214:      	fmul.4s	v7, v4, v4
     218:      	fmul.4s	v11, v2, v2
     21c:      	ldr	q2, [sp, #0x15c0]
     220:      	ldr	q4, [sp, #0x15d0]
     224:      	fmul.4s	v5, v4, v4
     228:      	fmul.4s	v6, v2, v2
     22c:      	ldr	q15, [sp, #0x130]
     230:      	mov.16b	v12, v15
     234:      	mov.16b	v13, v15
     238:      	mov.16b	v14, v15
     23c:      	adrp	x9, 0x0 <ltmp0>
     240:      	adrp	x12, 0x0 <ltmp0>
     244:      	shl.2d	v2, v12, #0x5
     248:      	add.2d	v28, v1, v2
     24c:      	ldr	q2, [sp, #0x260]
     250:      	add.2d	v19, v28, v2
     254:      	mov.d	x8, v19[1]
     258:      	ldr	q25, [x5]
     25c:      	shl.2d	v2, v13, #0x5
     260:      	add.2d	v30, v1, v2
     264:      	add.2d	v20, v30, v25
     268:      	mov.d	x11, v20[1]
     26c:      	ldr	q17, [x9]
     270:      	shl.2d	v2, v14, #0x5
     274:      	add.2d	v2, v1, v2
     278:      	add.2d	v21, v2, v17
     27c:      	mov.d	x14, v21[1]
     280:      	ldr	q18, [x1]
     284:      	shl.2d	v4, v15, #0x5
     288:      	add.2d	v4, v1, v4
     28c:      	add.2d	v22, v4, v18
     290:      	mov.d	x0, v22[1]
     294:      	fmov	x28, d19
     298:      	ldr	s19, [x28]
     29c:      	fmov	x28, d20
     2a0:      	fmov	x30, d21
     2a4:      	ld1.s	{ v19 }[1], [x8]
     2a8:      	fmov	x8, d22
     2ac:      	ld1.s	{ v19 }[2], [x28]
     2b0:      	ld1.s	{ v19 }[3], [x11]
     2b4:      	ldr	s20, [x30]
     2b8:      	ld1.s	{ v20 }[1], [x14]
     2bc:      	ld1.s	{ v20 }[2], [x8]
     2c0:      	ld1.s	{ v20 }[3], [x0]
     2c4:      	fmul.4s	v20, v20, v20
     2c8:      	fmul.4s	v19, v19, v19
     2cc:      	fadd.4s	v9, v9, v19
     2d0:      	fadd.4s	v10, v10, v20
     2d4:      	ldr	q21, [x12]
     2d8:      	ldr	q22, [x6]
     2dc:      	ldr	q26, [x7]
     2e0:      	ldr	q27, [x19]
     2e4:      	add.2d	v19, v4, v27
     2e8:      	add.2d	v20, v2, v26
     2ec:      	add.2d	v23, v30, v22
     2f0:      	add.2d	v24, v28, v21
     2f4:      	mov.d	x8, v24[1]
     2f8:      	fmov	x11, d24
     2fc:      	mov.d	x14, v23[1]
     300:      	fmov	x0, d23
     304:      	mov.d	x28, v20[1]
     308:      	fmov	x30, d20
     30c:      	mov.d	x2, v19[1]
     310:      	ldr	s20, [x11]
     314:      	ld1.s	{ v20 }[1], [x8]
     318:      	ld1.s	{ v20 }[2], [x0]
     31c:      	ld1.s	{ v20 }[3], [x14]
     320:      	fmov	x8, d19
     324:      	ldr	s19, [x30]
     328:      	ld1.s	{ v19 }[1], [x28]
     32c:      	ld1.s	{ v19 }[2], [x8]
     330:      	ld1.s	{ v19 }[3], [x2]
     334:      	fmul.4s	v19, v19, v19
     338:      	fmul.4s	v20, v20, v20
     33c:      	fadd.4s	v31, v31, v20
     340:      	fadd.4s	v8, v8, v19
     344:      	ldr	q24, [x4]
     348:      	ldr	q23, [x20]
     34c:      	ldr	q29, [x21]
     350:      	ldr	q3, [x22]
     354:      	add.2d	v19, v4, v3
     358:      	add.2d	v20, v28, v24
     35c:      	mov.d	x8, v20[1]
     360:      	fmov	x11, d20
     364:      	add.2d	v20, v30, v23
     368:      	mov.d	x14, v20[1]
     36c:      	fmov	x0, d20
     370:      	add.2d	v20, v2, v29
     374:      	mov.d	x2, v20[1]
     378:      	mov.d	x28, v19[1]
     37c:      	fmov	x30, d20
     380:      	ldr	s20, [x11]
     384:      	ld1.s	{ v20 }[1], [x8]
     388:      	ld1.s	{ v20 }[2], [x0]
     38c:      	fmov	x8, d19
     390:      	ld1.s	{ v20 }[3], [x14]
     394:      	ldr	s19, [x30]
     398:      	ld1.s	{ v19 }[1], [x2]
     39c:      	ld1.s	{ v19 }[2], [x8]
     3a0:      	ld1.s	{ v19 }[3], [x28]
     3a4:      	fmul.4s	v19, v19, v19
     3a8:      	fmul.4s	v20, v20, v20
     3ac:      	fadd.4s	v11, v11, v20
     3b0:      	fadd.4s	v7, v7, v19
     3b4:      	ldr	q20, [x23]
     3b8:      	add.2d	v19, v28, v20
     3bc:      	mov.d	x8, v19[1]
     3c0:      	ldr	q28, [x24]
     3c4:      	fmov	x11, d19
     3c8:      	ldr	q16, [x25]
     3cc:      	add.2d	v19, v30, v28
     3d0:      	mov.d	x14, v19[1]
     3d4:      	fmov	x0, d19
     3d8:      	mov.16b	v19, v16
     3dc:      	ldr	q16, [x26]
     3e0:      	add.2d	v4, v4, v16
     3e4:      	add.2d	v2, v2, v19
     3e8:      	mov.d	x2, v2[1]
     3ec:      	fmov	x28, d2
     3f0:      	mov.d	x30, v4[1]
     3f4:      	ldr	s2, [x11]
     3f8:      	ld1.s	{ v2 }[1], [x8]
     3fc:      	fmov	x8, d4
     400:      	ld1.s	{ v2 }[2], [x0]
     404:      	ld1.s	{ v2 }[3], [x14]
     408:      	fmul.4s	v2, v2, v2
     40c:      	fadd.4s	v6, v6, v2
     410:      	ldr	s2, [x28]
     414:      	ld1.s	{ v2 }[1], [x2]
     418:      	ld1.s	{ v2 }[2], [x8]
     41c:      	ld1.s	{ v2 }[3], [x30]
     420:      	fmul.4s	v2, v2, v2
     424:      	fadd.4s	v5, v5, v2
     428:      	dup.2d	v2, x15
     42c:      	add.2d	v14, v14, v2
     430:      	add.2d	v13, v13, v2
     434:      	add.2d	v15, v15, v2
     438:      	add.2d	v12, v12, v2
     43c:      	fmov	x8, d12
     440:      	cmp	x8, #0x7c
     444:      	b.lt	0x244 <ltmp0+0x244>
     448:      	stp	q3, q29, [sp, #0x230]
     44c:      	stp	q23, q24, [sp, #0x270]
     450:      	str	q27, [sp, #0x290]
     454:      	mov.16b	v30, v26
     458:      	stp	q16, q19, [sp, #0x1f0]
     45c:      	str	q20, [sp, #0x220]
     460:      	stp	q22, q21, [sp, #0x2b0]
     464:      	mov	x8, #0x0                ; =0
     468:      	ldr	q24, [sp, #0x24f0]
     46c:      	ldr	q27, [sp, #0x24e0]
     470:      	ldr	q23, [sp, #0x2510]
     474:      	ldr	q26, [sp, #0x2500]
     478:      	movi.2d	v13, #0000000000000000
     47c:      	movi.2d	v15, #0000000000000000
     480:      	ldr	q29, [sp, #0x2530]
     484:      	movi.2d	v2, #0000000000000000
     488:      	movi.2d	v4, #0000000000000000
     48c:      	ldr	q3, [sp, #0x2520]
     490:      	str	q3, [sp, #0x1c0]
     494:      	mov.16b	v16, v25
     498:      	ldr	q3, [sp, #0x260]
     49c:      	add	x8, x3, x8, lsl #5
     4a0:      	ldp	q20, q19, [x8]
     4a4:      	shl.2d	v12, v13, #0x5
     4a8:      	shl.2d	v14, v15, #0x5
     4ac:      	shl.2d	v21, v2, #0x5
     4b0:      	shl.2d	v22, v4, #0x5
     4b4:      	add.2d	v22, v22, v18
     4b8:      	add.2d	v22, v0, v22
     4bc:      	add.2d	v21, v21, v17
     4c0:      	add.2d	v14, v14, v16
     4c4:      	add.2d	v12, v12, v3
     4c8:      	add.2d	v12, v0, v12
     4cc:      	mov.d	x8, v12[1]
     4d0:      	fmov	x11, d12
     4d4:      	str	s20, [x11]
     4d8:      	st1.s	{ v20 }[1], [x8]
     4dc:      	add.2d	v12, v0, v14
     4e0:      	mov.d	x8, v12[1]
     4e4:      	fmov	x11, d12
     4e8:      	st1.s	{ v20 }[2], [x11]
     4ec:      	add.2d	v21, v0, v21
     4f0:      	st1.s	{ v20 }[3], [x8]
     4f4:      	mov.d	x8, v21[1]
     4f8:      	fmov	x11, d21
     4fc:      	str	s19, [x11]
     500:      	st1.s	{ v19 }[1], [x8]
     504:      	mov.d	x8, v22[1]
     508:      	fmov	x11, d22
     50c:      	st1.s	{ v19 }[2], [x11]
     510:      	st1.s	{ v19 }[3], [x8]
     514:      	dup.2d	v19, x27
     518:      	add.2d	v2, v2, v19
     51c:      	add.2d	v15, v15, v19
     520:      	add.2d	v4, v4, v19
     524:      	add.2d	v13, v13, v19
     528:      	fmov	x8, d13
     52c:      	cmp	x8, #0x7f
     530:      	b.lt	0x49c <ltmp0+0x49c>
     534:      	mov	x8, #0x0                ; =0
     538:      	fmul.4s	v2, v27, v27
     53c:      	fmul.4s	v4, v24, v24
     540:      	fadd.4s	v4, v10, v4
     544:      	fadd.4s	v2, v9, v2
     548:      	fmul.4s	v19, v26, v26
     54c:      	fmul.4s	v20, v23, v23
     550:      	fadd.4s	v20, v8, v20
     554:      	fadd.4s	v19, v31, v19
     558:      	fmul.4s	v21, v29, v29
     55c:      	ldr	q22, [sp, #0x1c0]
     560:      	fmul.4s	v22, v22, v22
     564:      	fadd.4s	v22, v11, v22
     568:      	fadd.4s	v7, v7, v21
     56c:      	ldr	q21, [sp, #0x210]
     570:      	fmul.4s	v21, v21, v21
     574:      	ldr	q23, [sp, #0x2a0]
     578:      	fmul.4s	v31, v23, v23
     57c:      	fadd.4s	v21, v21, v4
     580:      	mov.s	v21[3], v4[3]
     584:      	fadd.4s	v2, v31, v2
     588:      	fadd.4s	v2, v19, v2
     58c:      	fadd.4s	v4, v20, v21
     590:      	fadd.4s	v4, v7, v4
     594:      	fadd.4s	v2, v22, v2
     598:      	fadd.4s	v2, v6, v2
     59c:      	fadd.4s	v4, v5, v4
     5a0:      	rev64.4s	v5, v4
     5a4:      	rev64.4s	v6, v2
     5a8:      	fadd.4s	v4, v4, v5
     5ac:      	dup.4s	v5, v4[2]
     5b0:      	fadd.4s	v2, v2, v6
     5b4:      	dup.4s	v6, v2[2]
     5b8:      	fadd.4s	v2, v2, v6
     5bc:      	fadd.4s	v4, v4, v5
     5c0:      	fadd.4s	v2, v2, v4
     5c4:      	movi	d4, #0000000000000000
     5c8:      	fadd	s2, s2, s4
     5cc:      	mov	w9, #0xc000             ; =49152
     5d0:      	movk	w9, #0x447f, lsl #16
     5d4:      	fmov	s4, w9
     5d8:      	fdiv	s5, s2, s4
     5dc:      	add	x14, x3, #0xfe0
     5e0:      	add	x11, x3, #0xfe4
     5e4:      	add	x0, x3, #0xfe8
     5e8:      	add	x2, x3, #0xfec
     5ec:      	ldr	s2, [x3, #0xfe0]
     5f0:      	ld1.s	{ v2 }[1], [x11]
     5f4:      	ld1.s	{ v2 }[2], [x0]
     5f8:      	add	x11, x3, #0xff4
     5fc:      	ld1.s	{ v2 }[3], [x2]
     600:      	ldr	s4, [x3, #0xff0]
     604:      	ld1.s	{ v4 }[1], [x11]
     608:      	add	x11, x3, #0xff8
     60c:      	ld1.s	{ v4 }[2], [x11]
     610:      	add	x9, sp, #0x560
     614:      	add	x11, x9, #0xffc
     618:      	ld1.s	{ v4 }[3], [x11]
     61c:      	str	q2, [sp, #0x1540]
     620:      	mov	w9, #0xc5ac             ; =50604
     624:      	movk	w9, #0x3727, lsl #16
     628:      	fmov	s6, w9
     62c:      	fadd	s5, s5, s6
     630:      	fsqrt	s5, s5
     634:      	dup.4s	v6, v5[0]
     638:      	str	q4, [sp, #0x1550]
     63c:      	ldr	x9, [sp, #0x250]
     640:      	add	x13, x9, x13
     644:      	movi.2d	v7, #0000000000000000
     648:      	movi.2d	v19, #0000000000000000
     64c:      	movi.2d	v20, #0000000000000000
     650:      	movi.2d	v31, #0000000000000000
     654:      	ldr	q25, [sp, #0x280]
     658:      	shl.2d	v21, v31, #0x5
     65c:      	shl.2d	v22, v20, #0x5
     660:      	shl.2d	v8, v19, #0x5
     664:      	shl.2d	v9, v7, #0x5
     668:      	orr.16b	v9, v9, v3
     66c:      	orr.16b	v8, v8, v16
     670:      	orr.16b	v22, v22, v17
     674:      	orr.16b	v21, v21, v18
     678:      	add.2d	v10, v1, v21
     67c:      	add.2d	v11, v1, v22
     680:      	add.2d	v12, v1, v8
     684:      	add.2d	v13, v1, v9
     688:      	mov.d	x11, v13[1]
     68c:      	mov.d	x0, v12[1]
     690:      	mov.d	x2, v11[1]
     694:      	fmov	x28, d13
     698:      	fmov	x30, d11
     69c:      	mov.d	x12, v10[1]
     6a0:      	fmov	x9, d10
     6a4:      	ldr	s10, [x30]
     6a8:      	ld1.s	{ v10 }[1], [x2]
     6ac:      	ld1.s	{ v10 }[2], [x9]
     6b0:      	ld1.s	{ v10 }[3], [x12]
     6b4:      	fmov	x9, d12
     6b8:      	ldr	s11, [x28]
     6bc:      	ld1.s	{ v11 }[1], [x11]
     6c0:      	ld1.s	{ v11 }[2], [x9]
     6c4:      	ld1.s	{ v11 }[3], [x0]
     6c8:      	fdiv.4s	v11, v11, v6
     6cc:      	fdiv.4s	v10, v10, v6
     6d0:      	add.2d	v21, v0, v21
     6d4:      	add.2d	v22, v0, v22
     6d8:      	add.2d	v8, v0, v8
     6dc:      	add.2d	v9, v0, v9
     6e0:      	mov.d	x9, v9[1]
     6e4:      	fmov	x11, d9
     6e8:      	mov.d	x12, v8[1]
     6ec:      	mov.d	x0, v22[1]
     6f0:      	mov.d	x2, v21[1]
     6f4:      	fmov	x28, d8
     6f8:      	ldr	s8, [x11]
     6fc:      	ld1.s	{ v8 }[1], [x9]
     700:      	ld1.s	{ v8 }[2], [x28]
     704:      	fmov	x9, d22
     708:      	ld1.s	{ v8 }[3], [x12]
     70c:      	ldr	s22, [x9]
     710:      	ld1.s	{ v22 }[1], [x0]
     714:      	fmov	x9, d21
     718:      	ld1.s	{ v22 }[2], [x9]
     71c:      	ld1.s	{ v22 }[3], [x2]
     720:      	fmul.4s	v21, v10, v22
     724:      	fmul.4s	v22, v11, v8
     728:      	add	x8, x13, x8, lsl #5
     72c:      	stp	q22, q21, [x8]
     730:      	dup.2d	v21, x27
     734:      	add.2d	v20, v20, v21
     738:      	add.2d	v19, v19, v21
     73c:      	add.2d	v31, v31, v21
     740:      	add.2d	v7, v7, v21
     744:      	fmov	x8, d7
     748:      	cmp	x8, #0x7f
     74c:      	b.lt	0x658 <ltmp0+0x658>
     750:      	str	q28, [sp, #0x210]
     754:      	str	q30, [sp, #0x2a0]
     758:      	mov	x13, #0x0               ; =0
     75c:      	ldr	q6, [sp, #0x2550]
     760:      	ldr	q7, [sp, #0x2540]
     764:      	dup.4s	v5, v5[0]
     768:      	fdiv.4s	v7, v7, v5
     76c:      	fdiv.4s	v5, v6, v5
     770:      	fmul.4s	v4, v4, v5
     774:      	fmul.4s	v2, v2, v7
     778:      	ldr	x8, [sp, #0x250]
     77c:      	add	x8, x8, x17
     780:      	str	q2, [x8]
     784:      	str	d4, [x8, #0x10]
     788:      	add	x8, x8, #0x18
     78c:      	st1.s	{ v4 }[2], [x8]
     790:      	ldr	w8, [sp, #0x1d0]
     794:      	orr	w9, w8, #0x1
     798:      	mov	w17, #0xffc             ; =4092
     79c:      	umull	x8, w9, w17
     7a0:      	ldr	x12, [sp, #0x1e0]
     7a4:      	umaddl	x9, w9, w17, x12
     7a8:      	add	x11, x9, x13
     7ac:      	ldp	q2, q4, [x11]
     7b0:      	add	x11, x10, x13
     7b4:      	stp	q2, q4, [x11]
     7b8:      	add	x13, x13, #0x20
     7bc:      	cmp	x13, #0xfe0
     7c0:      	b.ne	0x7a8 <ltmp0+0x7a8>
     7c4:      	add	x9, x8, #0xfe0
     7c8:      	str	x9, [sp, #0x1c0]
     7cc:      	add	x11, x12, x9
     7d0:      	add	x12, x11, #0x4
     7d4:      	add	x13, x11, #0x8
     7d8:      	add	x0, x11, #0xc
     7dc:      	ldr	s2, [x11]
     7e0:      	ld1.s	{ v2 }[1], [x12]
     7e4:      	ld1.s	{ v2 }[2], [x13]
     7e8:      	add	x12, x11, #0x14
     7ec:      	ld1.s	{ v2 }[3], [x0]
     7f0:      	ldr	s4, [x11, #0x10]
     7f4:      	ld1.s	{ v4 }[1], [x12]
     7f8:      	add	x11, x11, #0x18
     7fc:      	ld1.s	{ v4 }[2], [x11]
     800:      	add	x11, x10, #0xffc
     804:      	ld1.s	{ v4 }[3], [x11]
     808:      	stp	q4, q2, [sp, #0x1a0]
     80c:      	str	q2, [sp, #0x2540]
     810:      	str	q4, [sp, #0x2550]
     814:      	ldr	q2, [sp, #0x1560]
     818:      	ldr	q4, [sp, #0x1570]
     81c:      	fmul.4s	v10, v4, v4
     820:      	fmul.4s	v9, v2, v2
     824:      	ldr	q2, [sp, #0x1580]
     828:      	ldr	q4, [sp, #0x1590]
     82c:      	fmul.4s	v8, v4, v4
     830:      	fmul.4s	v31, v2, v2
     834:      	ldr	q2, [sp, #0x15a0]
     838:      	ldr	q4, [sp, #0x15b0]
     83c:      	fmul.4s	v7, v4, v4
     840:      	fmul.4s	v11, v2, v2
     844:      	ldr	q2, [sp, #0x15c0]
     848:      	ldr	q4, [sp, #0x15d0]
     84c:      	fmul.4s	v5, v4, v4
     850:      	fmul.4s	v6, v2, v2
     854:      	dup.2d	v12, x15
     858:      	mov.16b	v13, v12
     85c:      	mov.16b	v14, v12
     860:      	mov.16b	v15, v12
     864:      	mov.16b	v28, v25
     868:      	ldp	q24, q30, [sp, #0x230]
     86c:      	ldp	q26, q25, [sp, #0x210]
     870:      	ldp	q29, q27, [sp, #0x1f0]
     874:      	shl.2d	v4, v12, #0x5
     878:      	shl.2d	v20, v13, #0x5
     87c:      	shl.2d	v21, v14, #0x5
     880:      	shl.2d	v2, v15, #0x5
     884:      	add.2d	v2, v1, v2
     888:      	add.2d	v22, v2, v18
     88c:      	add.2d	v19, v1, v4
     890:      	add.2d	v23, v19, v3
     894:      	mov.d	x11, v23[1]
     898:      	add.2d	v4, v1, v21
     89c:      	add.2d	v20, v1, v20
     8a0:      	fmov	x12, d23
     8a4:      	add.2d	v21, v20, v16
     8a8:      	mov.d	x13, v21[1]
     8ac:      	fmov	x0, d21
     8b0:      	add.2d	v21, v4, v17
     8b4:      	mov.d	x2, v21[1]
     8b8:      	fmov	x28, d21
     8bc:      	mov.d	x30, v22[1]
     8c0:      	ldr	s21, [x12]
     8c4:      	ld1.s	{ v21 }[1], [x11]
     8c8:      	fmov	x11, d22
     8cc:      	ld1.s	{ v21 }[2], [x0]
     8d0:      	ld1.s	{ v21 }[3], [x13]
     8d4:      	ldr	s22, [x28]
     8d8:      	ld1.s	{ v22 }[1], [x2]
     8dc:      	ld1.s	{ v22 }[2], [x11]
     8e0:      	ld1.s	{ v22 }[3], [x30]
     8e4:      	fmul.4s	v22, v22, v22
     8e8:      	fmul.4s	v21, v21, v21
     8ec:      	fadd.4s	v9, v9, v21
     8f0:      	fadd.4s	v10, v10, v22
     8f4:      	ldr	q21, [sp, #0x290]
     8f8:      	add.2d	v21, v2, v21
     8fc:      	ldr	q22, [sp, #0x2c0]
     900:      	add.2d	v22, v19, v22
     904:      	mov.d	x11, v22[1]
     908:      	fmov	x12, d22
     90c:      	ldr	q22, [sp, #0x2b0]
     910:      	add.2d	v22, v20, v22
     914:      	mov.d	x13, v22[1]
     918:      	fmov	x0, d22
     91c:      	ldr	q22, [sp, #0x2a0]
     920:      	add.2d	v22, v4, v22
     924:      	mov.d	x2, v22[1]
     928:      	mov.d	x28, v21[1]
     92c:      	fmov	x30, d22
     930:      	ldr	s22, [x12]
     934:      	ld1.s	{ v22 }[1], [x11]
     938:      	ld1.s	{ v22 }[2], [x0]
     93c:      	fmov	x11, d21
     940:      	ld1.s	{ v22 }[3], [x13]
     944:      	ldr	s21, [x30]
     948:      	ld1.s	{ v21 }[1], [x2]
     94c:      	ld1.s	{ v21 }[2], [x11]
     950:      	ld1.s	{ v21 }[3], [x28]
     954:      	fmul.4s	v21, v21, v21
     958:      	fmul.4s	v22, v22, v22
     95c:      	fadd.4s	v31, v31, v22
     960:      	fadd.4s	v8, v8, v21
     964:      	add.2d	v21, v2, v24
     968:      	add.2d	v22, v19, v28
     96c:      	mov.d	x11, v22[1]
     970:      	fmov	x12, d22
     974:      	ldr	q22, [sp, #0x270]
     978:      	add.2d	v22, v20, v22
     97c:      	mov.d	x13, v22[1]
     980:      	fmov	x0, d22
     984:      	add.2d	v22, v4, v30
     988:      	mov.d	x2, v22[1]
     98c:      	fmov	x28, d22
     990:      	mov.d	x30, v21[1]
     994:      	ldr	s22, [x12]
     998:      	ld1.s	{ v22 }[1], [x11]
     99c:      	ld1.s	{ v22 }[2], [x0]
     9a0:      	ld1.s	{ v22 }[3], [x13]
     9a4:      	fmov	x11, d21
     9a8:      	fmul.4s	v21, v22, v22
     9ac:      	fadd.4s	v11, v11, v21
     9b0:      	ldr	s21, [x28]
     9b4:      	ld1.s	{ v21 }[1], [x2]
     9b8:      	ld1.s	{ v21 }[2], [x11]
     9bc:      	ld1.s	{ v21 }[3], [x30]
     9c0:      	fmul.4s	v21, v21, v21
     9c4:      	fadd.4s	v7, v7, v21
     9c8:      	add.2d	v20, v20, v26
     9cc:      	add.2d	v19, v19, v25
     9d0:      	mov.d	x11, v19[1]
     9d4:      	mov.d	x12, v20[1]
     9d8:      	fmov	x13, d19
     9dc:      	fmov	x0, d20
     9e0:      	add.2d	v2, v2, v29
     9e4:      	add.2d	v4, v4, v27
     9e8:      	mov.d	x2, v4[1]
     9ec:      	fmov	x28, d4
     9f0:      	mov.d	x30, v2[1]
     9f4:      	ldr	s4, [x13]
     9f8:      	ld1.s	{ v4 }[1], [x11]
     9fc:      	fmov	x11, d2
     a00:      	ld1.s	{ v4 }[2], [x0]
     a04:      	ld1.s	{ v4 }[3], [x12]
     a08:      	fmul.4s	v2, v4, v4
     a0c:      	fadd.4s	v6, v6, v2
     a10:      	ldr	s2, [x28]
     a14:      	ld1.s	{ v2 }[1], [x2]
     a18:      	ld1.s	{ v2 }[2], [x11]
     a1c:      	ld1.s	{ v2 }[3], [x30]
     a20:      	fmul.4s	v2, v2, v2
     a24:      	fadd.4s	v5, v5, v2
     a28:      	dup.2d	v2, x15
     a2c:      	add.2d	v14, v14, v2
     a30:      	add.2d	v13, v13, v2
     a34:      	add.2d	v15, v15, v2
     a38:      	add.2d	v12, v12, v2
     a3c:      	fmov	x11, d12
     a40:      	cmp	x11, #0x7c
     a44:      	b.lt	0x874 <ltmp0+0x874>
     a48:      	mov	x13, #0x0               ; =0
     a4c:      	ldr	q25, [sp, #0x24f0]
     a50:      	ldr	q27, [sp, #0x24e0]
     a54:      	ldr	q24, [sp, #0x2510]
     a58:      	ldr	q26, [sp, #0x2500]
     a5c:      	movi.2d	v13, #0000000000000000
     a60:      	movi.2d	v15, #0000000000000000
     a64:      	ldr	q28, [sp, #0x2530]
     a68:      	movi.2d	v2, #0000000000000000
     a6c:      	movi.2d	v4, #0000000000000000
     a70:      	ldr	q14, [sp, #0x2520]
     a74:      	add	x11, x3, x13, lsl #5
     a78:      	ldp	q22, q21, [x11]
     a7c:      	shl.2d	v23, v13, #0x5
     a80:      	shl.2d	v19, v15, #0x5
     a84:      	shl.2d	v20, v2, #0x5
     a88:      	shl.2d	v12, v4, #0x5
     a8c:      	add.2d	v12, v12, v18
     a90:      	add.2d	v12, v0, v12
     a94:      	add.2d	v20, v20, v17
     a98:      	add.2d	v19, v19, v16
     a9c:      	add.2d	v23, v23, v3
     aa0:      	add.2d	v23, v0, v23
     aa4:      	mov.d	x11, v23[1]
     aa8:      	fmov	x12, d23
     aac:      	str	s22, [x12]
     ab0:      	st1.s	{ v22 }[1], [x11]
     ab4:      	add.2d	v19, v0, v19
     ab8:      	mov.d	x11, v19[1]
     abc:      	fmov	x12, d19
     ac0:      	st1.s	{ v22 }[2], [x12]
     ac4:      	add.2d	v19, v0, v20
     ac8:      	st1.s	{ v22 }[3], [x11]
     acc:      	mov.d	x11, v19[1]
     ad0:      	fmov	x12, d19
     ad4:      	str	s21, [x12]
     ad8:      	st1.s	{ v21 }[1], [x11]
     adc:      	mov.d	x11, v12[1]
     ae0:      	fmov	x12, d12
     ae4:      	st1.s	{ v21 }[2], [x12]
     ae8:      	st1.s	{ v21 }[3], [x11]
     aec:      	dup.2d	v19, x27
     af0:      	add.2d	v2, v2, v19
     af4:      	add.2d	v15, v15, v19
     af8:      	add.2d	v4, v4, v19
     afc:      	add.2d	v13, v13, v19
     b00:      	fmov	x13, d13
     b04:      	cmp	x13, #0x7f
     b08:      	b.lt	0xa74 <ltmp0+0xa74>
     b0c:      	mov	x13, #0x0               ; =0
     b10:      	fmul.4s	v2, v27, v27
     b14:      	fmul.4s	v4, v25, v25
     b18:      	fadd.4s	v4, v10, v4
     b1c:      	fadd.4s	v2, v9, v2
     b20:      	fmul.4s	v19, v26, v26
     b24:      	fmul.4s	v20, v24, v24
     b28:      	fadd.4s	v20, v8, v20
     b2c:      	fadd.4s	v19, v31, v19
     b30:      	fmul.4s	v21, v28, v28
     b34:      	fmul.4s	v22, v14, v14
     b38:      	fadd.4s	v22, v11, v22
     b3c:      	fadd.4s	v7, v7, v21
     b40:      	ldp	q21, q23, [sp, #0x1a0]
     b44:      	fmul.4s	v21, v21, v21
     b48:      	fmul.4s	v23, v23, v23
     b4c:      	fadd.4s	v2, v23, v2
     b50:      	fadd.4s	v21, v21, v4
     b54:      	mov.s	v21[3], v4[3]
     b58:      	fadd.4s	v2, v19, v2
     b5c:      	fadd.4s	v4, v20, v21
     b60:      	fadd.4s	v4, v7, v4
     b64:      	fadd.4s	v2, v22, v2
     b68:      	fadd.4s	v2, v6, v2
     b6c:      	fadd.4s	v4, v5, v4
     b70:      	rev64.4s	v5, v4
     b74:      	rev64.4s	v6, v2
     b78:      	fadd.4s	v2, v2, v6
     b7c:      	fadd.4s	v4, v4, v5
     b80:      	dup.4s	v5, v4[2]
     b84:      	dup.4s	v6, v2[2]
     b88:      	fadd.4s	v2, v2, v6
     b8c:      	fadd.4s	v4, v4, v5
     b90:      	fadd.4s	v2, v2, v4
     b94:      	movi	d4, #0000000000000000
     b98:      	fadd	s2, s2, s4
     b9c:      	mov	w9, #0xc000             ; =49152
     ba0:      	movk	w9, #0x447f, lsl #16
     ba4:      	fmov	s4, w9
     ba8:      	fdiv	s5, s2, s4
     bac:      	add	x11, x14, #0x4
     bb0:      	add	x12, x14, #0x8
     bb4:      	add	x0, x14, #0xc
     bb8:      	ldr	s2, [x14]
     bbc:      	ld1.s	{ v2 }[1], [x11]
     bc0:      	ld1.s	{ v2 }[2], [x12]
     bc4:      	add	x11, x14, #0x14
     bc8:      	ld1.s	{ v2 }[3], [x0]
     bcc:      	ldr	s4, [x14, #0x10]
     bd0:      	ld1.s	{ v4 }[1], [x11]
     bd4:      	add	x11, x14, #0x18
     bd8:      	ld1.s	{ v4 }[2], [x11]
     bdc:      	add	x9, sp, #0x560
     be0:      	add	x11, x9, #0xffc
     be4:      	ld1.s	{ v4 }[3], [x11]
     be8:      	str	q2, [sp, #0x1540]
     bec:      	mov	w9, #0xc5ac             ; =50604
     bf0:      	movk	w9, #0x3727, lsl #16
     bf4:      	fmov	s6, w9
     bf8:      	fadd	s5, s5, s6
     bfc:      	fsqrt	s5, s5
     c00:      	dup.4s	v6, v5[0]
     c04:      	str	q4, [sp, #0x1550]
     c08:      	ldr	x9, [sp, #0x250]
     c0c:      	add	x8, x9, x8
     c10:      	movi.2d	v7, #0000000000000000
     c14:      	movi.2d	v19, #0000000000000000
     c18:      	movi.2d	v20, #0000000000000000
     c1c:      	movi.2d	v31, #0000000000000000
     c20:      	shl.2d	v21, v31, #0x5
     c24:      	shl.2d	v22, v20, #0x5
     c28:      	shl.2d	v23, v19, #0x5
     c2c:      	shl.2d	v8, v7, #0x5
     c30:      	orr.16b	v8, v8, v3
     c34:      	orr.16b	v23, v23, v16
     c38:      	orr.16b	v22, v22, v17
     c3c:      	orr.16b	v21, v21, v18
     c40:      	add.2d	v9, v1, v21
     c44:      	add.2d	v10, v1, v22
     c48:      	add.2d	v11, v1, v23
     c4c:      	add.2d	v12, v1, v8
     c50:      	mov.d	x11, v12[1]
     c54:      	mov.d	x12, v11[1]
     c58:      	mov.d	x0, v10[1]
     c5c:      	fmov	x2, d12
     c60:      	fmov	x28, d10
     c64:      	mov.d	x30, v9[1]
     c68:      	fmov	x9, d9
     c6c:      	ldr	s9, [x28]
     c70:      	ld1.s	{ v9 }[1], [x0]
     c74:      	ld1.s	{ v9 }[2], [x9]
     c78:      	ld1.s	{ v9 }[3], [x30]
     c7c:      	fmov	x9, d11
     c80:      	ldr	s10, [x2]
     c84:      	ld1.s	{ v10 }[1], [x11]
     c88:      	ld1.s	{ v10 }[2], [x9]
     c8c:      	ld1.s	{ v10 }[3], [x12]
     c90:      	fdiv.4s	v10, v10, v6
     c94:      	fdiv.4s	v9, v9, v6
     c98:      	add.2d	v21, v0, v21
     c9c:      	add.2d	v22, v0, v22
     ca0:      	add.2d	v23, v0, v23
     ca4:      	add.2d	v8, v0, v8
     ca8:      	mov.d	x9, v8[1]
     cac:      	fmov	x11, d8
     cb0:      	mov.d	x12, v23[1]
     cb4:      	mov.d	x0, v22[1]
     cb8:      	mov.d	x2, v21[1]
     cbc:      	fmov	x28, d23
     cc0:      	ldr	s23, [x11]
     cc4:      	ld1.s	{ v23 }[1], [x9]
     cc8:      	ld1.s	{ v23 }[2], [x28]
     ccc:      	fmov	x9, d22
     cd0:      	ld1.s	{ v23 }[3], [x12]
     cd4:      	ldr	s22, [x9]
     cd8:      	ld1.s	{ v22 }[1], [x0]
     cdc:      	fmov	x9, d21
     ce0:      	ld1.s	{ v22 }[2], [x9]
     ce4:      	ld1.s	{ v22 }[3], [x2]
     ce8:      	fmul.4s	v21, v9, v22
     cec:      	fmul.4s	v22, v10, v23
     cf0:      	add	x9, x8, x13, lsl #5
     cf4:      	stp	q22, q21, [x9]
     cf8:      	dup.2d	v21, x27
     cfc:      	add.2d	v20, v20, v21
     d00:      	add.2d	v19, v19, v21
     d04:      	add.2d	v31, v31, v21
     d08:      	add.2d	v7, v7, v21
     d0c:      	fmov	x13, d7
     d10:      	cmp	x13, #0x7f
     d14:      	b.lt	0xc20 <ltmp0+0xc20>
     d18:      	mov	x13, #0x0               ; =0
     d1c:      	ldr	q6, [sp, #0x2550]
     d20:      	ldr	q7, [sp, #0x2540]
     d24:      	dup.4s	v5, v5[0]
     d28:      	fdiv.4s	v7, v7, v5
     d2c:      	fdiv.4s	v5, v6, v5
     d30:      	fmul.4s	v4, v4, v5
     d34:      	fmul.4s	v2, v2, v7
     d38:      	ldr	x8, [sp, #0x250]
     d3c:      	ldr	x9, [sp, #0x1c0]
     d40:      	add	x8, x8, x9
     d44:      	str	q2, [x8]
     d48:      	str	d4, [x8, #0x10]
     d4c:      	add	x8, x8, #0x18
     d50:      	st1.s	{ v4 }[2], [x8]
     d54:      	ldr	w8, [sp, #0x1d0]
     d58:      	orr	w9, w8, #0x2
     d5c:      	umull	x8, w9, w17
     d60:      	ldr	x12, [sp, #0x1e0]
     d64:      	umaddl	x9, w9, w17, x12
     d68:      	add	x11, x9, x13
     d6c:      	ldp	q2, q4, [x11]
     d70:      	add	x11, x10, x13
     d74:      	stp	q2, q4, [x11]
     d78:      	add	x13, x13, #0x20
     d7c:      	cmp	x13, #0xfe0
     d80:      	b.ne	0xd68 <ltmp0+0xd68>
     d84:      	add	x9, x8, #0xfe0
     d88:      	str	x9, [sp, #0x1c0]
     d8c:      	add	x11, x12, x9
     d90:      	add	x12, x11, #0x4
     d94:      	add	x13, x11, #0x8
     d98:      	add	x0, x11, #0xc
     d9c:      	ldr	s2, [x11]
     da0:      	ld1.s	{ v2 }[1], [x12]
     da4:      	ld1.s	{ v2 }[2], [x13]
     da8:      	add	x12, x11, #0x14
     dac:      	ld1.s	{ v2 }[3], [x0]
     db0:      	ldr	s4, [x11, #0x10]
     db4:      	ld1.s	{ v4 }[1], [x12]
     db8:      	add	x11, x11, #0x18
     dbc:      	ld1.s	{ v4 }[2], [x11]
     dc0:      	add	x11, x10, #0xffc
     dc4:      	ld1.s	{ v4 }[3], [x11]
     dc8:      	stp	q4, q2, [sp, #0x1a0]
     dcc:      	str	q2, [sp, #0x2540]
     dd0:      	str	q4, [sp, #0x2550]
     dd4:      	ldr	q2, [sp, #0x1560]
     dd8:      	ldr	q4, [sp, #0x1570]
     ddc:      	fmul.4s	v10, v4, v4
     de0:      	fmul.4s	v9, v2, v2
     de4:      	ldr	q2, [sp, #0x1580]
     de8:      	ldr	q4, [sp, #0x1590]
     dec:      	fmul.4s	v8, v4, v4
     df0:      	fmul.4s	v31, v2, v2
     df4:      	ldr	q2, [sp, #0x15a0]
     df8:      	ldr	q4, [sp, #0x15b0]
     dfc:      	fmul.4s	v7, v4, v4
     e00:      	fmul.4s	v11, v2, v2
     e04:      	ldr	q2, [sp, #0x15c0]
     e08:      	ldr	q4, [sp, #0x15d0]
     e0c:      	fmul.4s	v5, v4, v4
     e10:      	fmul.4s	v6, v2, v2
     e14:      	dup.2d	v12, x15
     e18:      	mov.16b	v13, v12
     e1c:      	mov.16b	v14, v12
     e20:      	mov.16b	v15, v12
     e24:      	ldr	q29, [sp, #0x270]
     e28:      	ldp	q24, q30, [sp, #0x230]
     e2c:      	ldp	q26, q25, [sp, #0x210]
     e30:      	ldp	q28, q27, [sp, #0x1f0]
     e34:      	shl.2d	v4, v12, #0x5
     e38:      	shl.2d	v20, v13, #0x5
     e3c:      	shl.2d	v21, v14, #0x5
     e40:      	shl.2d	v2, v15, #0x5
     e44:      	add.2d	v2, v1, v2
     e48:      	add.2d	v22, v2, v18
     e4c:      	add.2d	v19, v1, v4
     e50:      	add.2d	v23, v19, v3
     e54:      	mov.d	x11, v23[1]
     e58:      	add.2d	v4, v1, v21
     e5c:      	add.2d	v20, v1, v20
     e60:      	fmov	x12, d23
     e64:      	add.2d	v21, v20, v16
     e68:      	mov.d	x13, v21[1]
     e6c:      	fmov	x0, d21
     e70:      	add.2d	v21, v4, v17
     e74:      	mov.d	x2, v21[1]
     e78:      	fmov	x28, d21
     e7c:      	mov.d	x30, v22[1]
     e80:      	ldr	s21, [x12]
     e84:      	ld1.s	{ v21 }[1], [x11]
     e88:      	fmov	x11, d22
     e8c:      	ld1.s	{ v21 }[2], [x0]
     e90:      	ld1.s	{ v21 }[3], [x13]
     e94:      	ldr	s22, [x28]
     e98:      	ld1.s	{ v22 }[1], [x2]
     e9c:      	ld1.s	{ v22 }[2], [x11]
     ea0:      	ld1.s	{ v22 }[3], [x30]
     ea4:      	fmul.4s	v22, v22, v22
     ea8:      	fmul.4s	v21, v21, v21
     eac:      	fadd.4s	v9, v9, v21
     eb0:      	fadd.4s	v10, v10, v22
     eb4:      	ldr	q21, [sp, #0x290]
     eb8:      	add.2d	v21, v2, v21
     ebc:      	ldr	q22, [sp, #0x2c0]
     ec0:      	add.2d	v22, v19, v22
     ec4:      	mov.d	x11, v22[1]
     ec8:      	fmov	x12, d22
     ecc:      	ldr	q22, [sp, #0x2b0]
     ed0:      	add.2d	v22, v20, v22
     ed4:      	mov.d	x13, v22[1]
     ed8:      	fmov	x0, d22
     edc:      	ldr	q22, [sp, #0x2a0]
     ee0:      	add.2d	v22, v4, v22
     ee4:      	mov.d	x2, v22[1]
     ee8:      	mov.d	x28, v21[1]
     eec:      	fmov	x30, d22
     ef0:      	ldr	s22, [x12]
     ef4:      	ld1.s	{ v22 }[1], [x11]
     ef8:      	ld1.s	{ v22 }[2], [x0]
     efc:      	fmov	x11, d21
     f00:      	ld1.s	{ v22 }[3], [x13]
     f04:      	ldr	s21, [x30]
     f08:      	ld1.s	{ v21 }[1], [x2]
     f0c:      	ld1.s	{ v21 }[2], [x11]
     f10:      	ld1.s	{ v21 }[3], [x28]
     f14:      	fmul.4s	v21, v21, v21
     f18:      	fmul.4s	v22, v22, v22
     f1c:      	fadd.4s	v31, v31, v22
     f20:      	fadd.4s	v8, v8, v21
     f24:      	add.2d	v21, v2, v24
     f28:      	ldr	q22, [sp, #0x280]
     f2c:      	add.2d	v22, v19, v22
     f30:      	mov.d	x11, v22[1]
     f34:      	fmov	x12, d22
     f38:      	add.2d	v22, v20, v29
     f3c:      	mov.d	x13, v22[1]
     f40:      	fmov	x0, d22
     f44:      	add.2d	v22, v4, v30
     f48:      	mov.d	x2, v22[1]
     f4c:      	fmov	x28, d22
     f50:      	mov.d	x30, v21[1]
     f54:      	ldr	s22, [x12]
     f58:      	ld1.s	{ v22 }[1], [x11]
     f5c:      	ld1.s	{ v22 }[2], [x0]
     f60:      	ld1.s	{ v22 }[3], [x13]
     f64:      	fmov	x11, d21
     f68:      	fmul.4s	v21, v22, v22
     f6c:      	fadd.4s	v11, v11, v21
     f70:      	ldr	s21, [x28]
     f74:      	ld1.s	{ v21 }[1], [x2]
     f78:      	ld1.s	{ v21 }[2], [x11]
     f7c:      	ld1.s	{ v21 }[3], [x30]
     f80:      	fmul.4s	v21, v21, v21
     f84:      	fadd.4s	v7, v7, v21
     f88:      	add.2d	v20, v20, v26
     f8c:      	add.2d	v19, v19, v25
     f90:      	mov.d	x11, v19[1]
     f94:      	mov.d	x12, v20[1]
     f98:      	fmov	x13, d19
     f9c:      	fmov	x0, d20
     fa0:      	add.2d	v2, v2, v28
     fa4:      	add.2d	v4, v4, v27
     fa8:      	mov.d	x2, v4[1]
     fac:      	fmov	x28, d4
     fb0:      	mov.d	x30, v2[1]
     fb4:      	ldr	s4, [x13]
     fb8:      	ld1.s	{ v4 }[1], [x11]
     fbc:      	fmov	x11, d2
     fc0:      	ld1.s	{ v4 }[2], [x0]
     fc4:      	ld1.s	{ v4 }[3], [x12]
     fc8:      	fmul.4s	v2, v4, v4
     fcc:      	fadd.4s	v6, v6, v2
     fd0:      	ldr	s2, [x28]
     fd4:      	ld1.s	{ v2 }[1], [x2]
     fd8:      	ld1.s	{ v2 }[2], [x11]
     fdc:      	ld1.s	{ v2 }[3], [x30]
     fe0:      	fmul.4s	v2, v2, v2
     fe4:      	fadd.4s	v5, v5, v2
     fe8:      	dup.2d	v2, x15
     fec:      	add.2d	v14, v14, v2
     ff0:      	add.2d	v13, v13, v2
     ff4:      	add.2d	v15, v15, v2
     ff8:      	add.2d	v12, v12, v2
     ffc:      	fmov	x11, d12
    1000:      	cmp	x11, #0x7c
    1004:      	b.lt	0xe34 <ltmp0+0xe34>
    1008:      	mov	x13, #0x0               ; =0
    100c:      	ldr	q25, [sp, #0x24f0]
    1010:      	ldr	q27, [sp, #0x24e0]
    1014:      	ldr	q24, [sp, #0x2510]
    1018:      	ldr	q26, [sp, #0x2500]
    101c:      	movi.2d	v13, #0000000000000000
    1020:      	movi.2d	v15, #0000000000000000
    1024:      	ldr	q28, [sp, #0x2530]
    1028:      	movi.2d	v2, #0000000000000000
    102c:      	movi.2d	v4, #0000000000000000
    1030:      	ldr	q14, [sp, #0x2520]
    1034:      	add	x11, x3, x13, lsl #5
    1038:      	ldp	q22, q21, [x11]
    103c:      	shl.2d	v23, v13, #0x5
    1040:      	shl.2d	v19, v15, #0x5
    1044:      	shl.2d	v20, v2, #0x5
    1048:      	shl.2d	v12, v4, #0x5
    104c:      	add.2d	v12, v12, v18
    1050:      	add.2d	v12, v0, v12
    1054:      	add.2d	v20, v20, v17
    1058:      	add.2d	v19, v19, v16
    105c:      	add.2d	v23, v23, v3
    1060:      	add.2d	v23, v0, v23
    1064:      	mov.d	x11, v23[1]
    1068:      	fmov	x12, d23
    106c:      	str	s22, [x12]
    1070:      	st1.s	{ v22 }[1], [x11]
    1074:      	add.2d	v19, v0, v19
    1078:      	mov.d	x11, v19[1]
    107c:      	fmov	x12, d19
    1080:      	st1.s	{ v22 }[2], [x12]
    1084:      	add.2d	v19, v0, v20
    1088:      	st1.s	{ v22 }[3], [x11]
    108c:      	mov.d	x11, v19[1]
    1090:      	fmov	x12, d19
    1094:      	str	s21, [x12]
    1098:      	st1.s	{ v21 }[1], [x11]
    109c:      	mov.d	x11, v12[1]
    10a0:      	fmov	x12, d12
    10a4:      	st1.s	{ v21 }[2], [x12]
    10a8:      	st1.s	{ v21 }[3], [x11]
    10ac:      	dup.2d	v19, x27
    10b0:      	add.2d	v2, v2, v19
    10b4:      	add.2d	v15, v15, v19
    10b8:      	add.2d	v4, v4, v19
    10bc:      	add.2d	v13, v13, v19
    10c0:      	fmov	x13, d13
    10c4:      	cmp	x13, #0x7f
    10c8:      	b.lt	0x1034 <ltmp0+0x1034>
    10cc:      	mov	x13, #0x0               ; =0
    10d0:      	fmul.4s	v2, v27, v27
    10d4:      	fmul.4s	v4, v25, v25
    10d8:      	fadd.4s	v4, v10, v4
    10dc:      	fadd.4s	v2, v9, v2
    10e0:      	fmul.4s	v19, v26, v26
    10e4:      	fmul.4s	v20, v24, v24
    10e8:      	fadd.4s	v20, v8, v20
    10ec:      	fadd.4s	v19, v31, v19
    10f0:      	fmul.4s	v21, v28, v28
    10f4:      	fmul.4s	v22, v14, v14
    10f8:      	fadd.4s	v22, v11, v22
    10fc:      	fadd.4s	v7, v7, v21
    1100:      	ldp	q21, q23, [sp, #0x1a0]
    1104:      	fmul.4s	v21, v21, v21
    1108:      	fmul.4s	v23, v23, v23
    110c:      	fadd.4s	v2, v23, v2
    1110:      	fadd.4s	v21, v21, v4
    1114:      	mov.s	v21[3], v4[3]
    1118:      	fadd.4s	v2, v19, v2
    111c:      	fadd.4s	v4, v20, v21
    1120:      	fadd.4s	v4, v7, v4
    1124:      	fadd.4s	v2, v22, v2
    1128:      	fadd.4s	v2, v6, v2
    112c:      	fadd.4s	v4, v5, v4
    1130:      	rev64.4s	v5, v4
    1134:      	rev64.4s	v6, v2
    1138:      	fadd.4s	v2, v2, v6
    113c:      	fadd.4s	v4, v4, v5
    1140:      	dup.4s	v5, v4[2]
    1144:      	dup.4s	v6, v2[2]
    1148:      	fadd.4s	v2, v2, v6
    114c:      	fadd.4s	v4, v4, v5
    1150:      	fadd.4s	v2, v2, v4
    1154:      	movi	d4, #0000000000000000
    1158:      	fadd	s2, s2, s4
    115c:      	mov	w9, #0xc000             ; =49152
    1160:      	movk	w9, #0x447f, lsl #16
    1164:      	fmov	s4, w9
    1168:      	fdiv	s5, s2, s4
    116c:      	add	x11, x14, #0x4
    1170:      	add	x12, x14, #0x8
    1174:      	add	x0, x14, #0xc
    1178:      	ldr	s2, [x14]
    117c:      	ld1.s	{ v2 }[1], [x11]
    1180:      	ld1.s	{ v2 }[2], [x12]
    1184:      	add	x11, x14, #0x14
    1188:      	ld1.s	{ v2 }[3], [x0]
    118c:      	ldr	s4, [x14, #0x10]
    1190:      	ld1.s	{ v4 }[1], [x11]
    1194:      	add	x11, x14, #0x18
    1198:      	ld1.s	{ v4 }[2], [x11]
    119c:      	add	x9, sp, #0x560
    11a0:      	add	x11, x9, #0xffc
    11a4:      	ld1.s	{ v4 }[3], [x11]
    11a8:      	str	q2, [sp, #0x1540]
    11ac:      	mov	w9, #0xc5ac             ; =50604
    11b0:      	movk	w9, #0x3727, lsl #16
    11b4:      	fmov	s6, w9
    11b8:      	fadd	s5, s5, s6
    11bc:      	fsqrt	s5, s5
    11c0:      	dup.4s	v6, v5[0]
    11c4:      	str	q4, [sp, #0x1550]
    11c8:      	ldr	x9, [sp, #0x250]
    11cc:      	add	x8, x9, x8
    11d0:      	movi.2d	v7, #0000000000000000
    11d4:      	movi.2d	v19, #0000000000000000
    11d8:      	movi.2d	v20, #0000000000000000
    11dc:      	movi.2d	v31, #0000000000000000
    11e0:      	shl.2d	v21, v31, #0x5
    11e4:      	shl.2d	v22, v20, #0x5
    11e8:      	shl.2d	v23, v19, #0x5
    11ec:      	shl.2d	v8, v7, #0x5
    11f0:      	orr.16b	v8, v8, v3
    11f4:      	orr.16b	v23, v23, v16
    11f8:      	orr.16b	v22, v22, v17
    11fc:      	orr.16b	v21, v21, v18
    1200:      	add.2d	v9, v1, v21
    1204:      	add.2d	v10, v1, v22
    1208:      	add.2d	v11, v1, v23
    120c:      	add.2d	v12, v1, v8
    1210:      	mov.d	x11, v12[1]
    1214:      	mov.d	x12, v11[1]
    1218:      	mov.d	x0, v10[1]
    121c:      	fmov	x2, d12
    1220:      	fmov	x28, d10
    1224:      	mov.d	x30, v9[1]
    1228:      	fmov	x9, d9
    122c:      	ldr	s9, [x28]
    1230:      	ld1.s	{ v9 }[1], [x0]
    1234:      	ld1.s	{ v9 }[2], [x9]
    1238:      	ld1.s	{ v9 }[3], [x30]
    123c:      	fmov	x9, d11
    1240:      	ldr	s10, [x2]
    1244:      	ld1.s	{ v10 }[1], [x11]
    1248:      	ld1.s	{ v10 }[2], [x9]
    124c:      	ld1.s	{ v10 }[3], [x12]
    1250:      	fdiv.4s	v10, v10, v6
    1254:      	fdiv.4s	v9, v9, v6
    1258:      	add.2d	v21, v0, v21
    125c:      	add.2d	v22, v0, v22
    1260:      	add.2d	v23, v0, v23
    1264:      	add.2d	v8, v0, v8
    1268:      	mov.d	x9, v8[1]
    126c:      	fmov	x11, d8
    1270:      	mov.d	x12, v23[1]
    1274:      	mov.d	x0, v22[1]
    1278:      	mov.d	x2, v21[1]
    127c:      	fmov	x28, d23
    1280:      	ldr	s23, [x11]
    1284:      	ld1.s	{ v23 }[1], [x9]
    1288:      	ld1.s	{ v23 }[2], [x28]
    128c:      	fmov	x9, d22
    1290:      	ld1.s	{ v23 }[3], [x12]
    1294:      	ldr	s22, [x9]
    1298:      	ld1.s	{ v22 }[1], [x0]
    129c:      	fmov	x9, d21
    12a0:      	ld1.s	{ v22 }[2], [x9]
    12a4:      	ld1.s	{ v22 }[3], [x2]
    12a8:      	fmul.4s	v21, v9, v22
    12ac:      	fmul.4s	v22, v10, v23
    12b0:      	add	x9, x8, x13, lsl #5
    12b4:      	stp	q22, q21, [x9]
    12b8:      	dup.2d	v21, x27
    12bc:      	add.2d	v20, v20, v21
    12c0:      	add.2d	v19, v19, v21
    12c4:      	add.2d	v31, v31, v21
    12c8:      	add.2d	v7, v7, v21
    12cc:      	fmov	x13, d7
    12d0:      	cmp	x13, #0x7f
    12d4:      	b.lt	0x11e0 <ltmp0+0x11e0>
    12d8:      	mov	x13, #0x0               ; =0
    12dc:      	ldr	q6, [sp, #0x2550]
    12e0:      	ldr	q7, [sp, #0x2540]
    12e4:      	dup.4s	v5, v5[0]
    12e8:      	fdiv.4s	v7, v7, v5
    12ec:      	fdiv.4s	v5, v6, v5
    12f0:      	fmul.4s	v4, v4, v5
    12f4:      	fmul.4s	v2, v2, v7
    12f8:      	ldr	x8, [sp, #0x250]
    12fc:      	ldr	x9, [sp, #0x1c0]
    1300:      	add	x8, x8, x9
    1304:      	str	q2, [x8]
    1308:      	str	d4, [x8, #0x10]
    130c:      	add	x8, x8, #0x18
    1310:      	st1.s	{ v4 }[2], [x8]
    1314:      	ldr	w8, [sp, #0x1d0]
    1318:      	orr	w9, w8, #0x3
    131c:      	umull	x8, w9, w17
    1320:      	ldr	x12, [sp, #0x1e0]
    1324:      	umaddl	x9, w9, w17, x12
    1328:      	add	x11, x9, x13
    132c:      	ldp	q2, q4, [x11]
    1330:      	add	x11, x10, x13
    1334:      	stp	q2, q4, [x11]
    1338:      	add	x13, x13, #0x20
    133c:      	cmp	x13, #0xfe0
    1340:      	b.ne	0x1328 <ltmp0+0x1328>
    1344:      	add	x9, x8, #0xfe0
    1348:      	add	x11, x12, x9
    134c:      	add	x12, x11, #0x4
    1350:      	add	x13, x11, #0x8
    1354:      	add	x0, x11, #0xc
    1358:      	ldr	s2, [x11]
    135c:      	ld1.s	{ v2 }[1], [x12]
    1360:      	ld1.s	{ v2 }[2], [x13]
    1364:      	add	x12, x11, #0x14
    1368:      	ld1.s	{ v2 }[3], [x0]
    136c:      	ldr	s4, [x11, #0x10]
    1370:      	ld1.s	{ v4 }[1], [x12]
    1374:      	add	x11, x11, #0x18
    1378:      	ld1.s	{ v4 }[2], [x11]
    137c:      	add	x11, x10, #0xffc
    1380:      	ld1.s	{ v4 }[3], [x11]
    1384:      	stp	q4, q2, [sp, #0x1d0]
    1388:      	str	q2, [sp, #0x2540]
    138c:      	str	q4, [sp, #0x2550]
    1390:      	ldr	q2, [sp, #0x1560]
    1394:      	ldr	q4, [sp, #0x1570]
    1398:      	fmul.4s	v10, v4, v4
    139c:      	fmul.4s	v9, v2, v2
    13a0:      	ldr	q2, [sp, #0x1580]
    13a4:      	ldr	q4, [sp, #0x1590]
    13a8:      	fmul.4s	v8, v4, v4
    13ac:      	fmul.4s	v31, v2, v2
    13b0:      	ldr	q2, [sp, #0x15a0]
    13b4:      	ldr	q4, [sp, #0x15b0]
    13b8:      	fmul.4s	v7, v4, v4
    13bc:      	fmul.4s	v11, v2, v2
    13c0:      	ldr	q2, [sp, #0x15c0]
    13c4:      	ldr	q4, [sp, #0x15d0]
    13c8:      	fmul.4s	v5, v4, v4
    13cc:      	fmul.4s	v6, v2, v2
    13d0:      	dup.2d	v12, x15
    13d4:      	mov.16b	v13, v12
    13d8:      	mov.16b	v14, v12
    13dc:      	mov.16b	v15, v12
    13e0:      	ldr	q29, [sp, #0x270]
    13e4:      	ldp	q24, q30, [sp, #0x230]
    13e8:      	ldp	q26, q25, [sp, #0x210]
    13ec:      	ldp	q28, q27, [sp, #0x1f0]
    13f0:      	shl.2d	v4, v12, #0x5
    13f4:      	shl.2d	v20, v13, #0x5
    13f8:      	shl.2d	v21, v14, #0x5
    13fc:      	shl.2d	v2, v15, #0x5
    1400:      	add.2d	v2, v1, v2
    1404:      	add.2d	v22, v2, v18
    1408:      	add.2d	v19, v1, v4
    140c:      	add.2d	v23, v19, v3
    1410:      	mov.d	x11, v23[1]
    1414:      	add.2d	v4, v1, v21
    1418:      	add.2d	v20, v1, v20
    141c:      	fmov	x12, d23
    1420:      	add.2d	v21, v20, v16
    1424:      	mov.d	x13, v21[1]
    1428:      	fmov	x0, d21
    142c:      	add.2d	v21, v4, v17
    1430:      	mov.d	x2, v21[1]
    1434:      	fmov	x28, d21
    1438:      	mov.d	x30, v22[1]
    143c:      	ldr	s21, [x12]
    1440:      	ld1.s	{ v21 }[1], [x11]
    1444:      	fmov	x11, d22
    1448:      	ld1.s	{ v21 }[2], [x0]
    144c:      	ld1.s	{ v21 }[3], [x13]
    1450:      	ldr	s22, [x28]
    1454:      	ld1.s	{ v22 }[1], [x2]
    1458:      	ld1.s	{ v22 }[2], [x11]
    145c:      	ld1.s	{ v22 }[3], [x30]
    1460:      	fmul.4s	v22, v22, v22
    1464:      	fmul.4s	v21, v21, v21
    1468:      	fadd.4s	v9, v9, v21
    146c:      	fadd.4s	v10, v10, v22
    1470:      	ldr	q21, [sp, #0x290]
    1474:      	add.2d	v21, v2, v21
    1478:      	ldr	q22, [sp, #0x2c0]
    147c:      	add.2d	v22, v19, v22
    1480:      	mov.d	x11, v22[1]
    1484:      	fmov	x12, d22
    1488:      	ldr	q22, [sp, #0x2b0]
    148c:      	add.2d	v22, v20, v22
    1490:      	mov.d	x13, v22[1]
    1494:      	fmov	x0, d22
    1498:      	ldr	q22, [sp, #0x2a0]
    149c:      	add.2d	v22, v4, v22
    14a0:      	mov.d	x2, v22[1]
    14a4:      	mov.d	x28, v21[1]
    14a8:      	fmov	x30, d22
    14ac:      	ldr	s22, [x12]
    14b0:      	ld1.s	{ v22 }[1], [x11]
    14b4:      	ld1.s	{ v22 }[2], [x0]
    14b8:      	fmov	x11, d21
    14bc:      	ld1.s	{ v22 }[3], [x13]
    14c0:      	ldr	s21, [x30]
    14c4:      	ld1.s	{ v21 }[1], [x2]
    14c8:      	ld1.s	{ v21 }[2], [x11]
    14cc:      	ld1.s	{ v21 }[3], [x28]
    14d0:      	fmul.4s	v21, v21, v21
    14d4:      	fmul.4s	v22, v22, v22
    14d8:      	fadd.4s	v31, v31, v22
    14dc:      	fadd.4s	v8, v8, v21
    14e0:      	add.2d	v21, v2, v24
    14e4:      	ldr	q22, [sp, #0x280]
    14e8:      	add.2d	v22, v19, v22
    14ec:      	mov.d	x11, v22[1]
    14f0:      	fmov	x12, d22
    14f4:      	add.2d	v22, v20, v29
    14f8:      	mov.d	x13, v22[1]
    14fc:      	fmov	x0, d22
    1500:      	add.2d	v22, v4, v30
    1504:      	mov.d	x2, v22[1]
    1508:      	fmov	x28, d22
    150c:      	mov.d	x30, v21[1]
    1510:      	ldr	s22, [x12]
    1514:      	ld1.s	{ v22 }[1], [x11]
    1518:      	ld1.s	{ v22 }[2], [x0]
    151c:      	ld1.s	{ v22 }[3], [x13]
    1520:      	fmov	x11, d21
    1524:      	fmul.4s	v21, v22, v22
    1528:      	fadd.4s	v11, v11, v21
    152c:      	ldr	s21, [x28]
    1530:      	ld1.s	{ v21 }[1], [x2]
    1534:      	ld1.s	{ v21 }[2], [x11]
    1538:      	ld1.s	{ v21 }[3], [x30]
    153c:      	fmul.4s	v21, v21, v21
    1540:      	fadd.4s	v7, v7, v21
    1544:      	add.2d	v20, v20, v26
    1548:      	add.2d	v19, v19, v25
    154c:      	mov.d	x11, v19[1]
    1550:      	mov.d	x12, v20[1]
    1554:      	fmov	x13, d19
    1558:      	fmov	x0, d20
    155c:      	add.2d	v2, v2, v28
    1560:      	add.2d	v4, v4, v27
    1564:      	mov.d	x2, v4[1]
    1568:      	fmov	x28, d4
    156c:      	mov.d	x30, v2[1]
    1570:      	ldr	s4, [x13]
    1574:      	ld1.s	{ v4 }[1], [x11]
    1578:      	fmov	x11, d2
    157c:      	ld1.s	{ v4 }[2], [x0]
    1580:      	ld1.s	{ v4 }[3], [x12]
    1584:      	fmul.4s	v2, v4, v4
    1588:      	fadd.4s	v6, v6, v2
    158c:      	ldr	s2, [x28]
    1590:      	ld1.s	{ v2 }[1], [x2]
    1594:      	ld1.s	{ v2 }[2], [x11]
    1598:      	ld1.s	{ v2 }[3], [x30]
    159c:      	fmul.4s	v2, v2, v2
    15a0:      	fadd.4s	v5, v5, v2
    15a4:      	dup.2d	v2, x15
    15a8:      	add.2d	v14, v14, v2
    15ac:      	add.2d	v13, v13, v2
    15b0:      	add.2d	v15, v15, v2
    15b4:      	add.2d	v12, v12, v2
    15b8:      	fmov	x11, d12
    15bc:      	cmp	x11, #0x7c
    15c0:      	b.lt	0x13f0 <ltmp0+0x13f0>
    15c4:      	mov	x11, #0x0               ; =0
    15c8:      	ldr	q4, [sp, #0x24f0]
    15cc:      	ldr	q20, [sp, #0x24e0]
    15d0:      	ldr	q2, [sp, #0x2510]
    15d4:      	ldr	q19, [sp, #0x2500]
    15d8:      	movi.2d	v22, #0000000000000000
    15dc:      	movi.2d	v24, #0000000000000000
    15e0:      	ldr	q21, [sp, #0x2530]
    15e4:      	movi.2d	v25, #0000000000000000
    15e8:      	movi.2d	v26, #0000000000000000
    15ec:      	ldr	q23, [sp, #0x2520]
    15f0:      	add	x11, x3, x11, lsl #5
    15f4:      	ldp	q28, q27, [x11]
    15f8:      	shl.2d	v29, v22, #0x5
    15fc:      	shl.2d	v30, v24, #0x5
    1600:      	shl.2d	v12, v25, #0x5
    1604:      	shl.2d	v13, v26, #0x5
    1608:      	add.2d	v13, v13, v18
    160c:      	add.2d	v13, v0, v13
    1610:      	add.2d	v12, v12, v17
    1614:      	add.2d	v30, v30, v16
    1618:      	add.2d	v29, v29, v3
    161c:      	add.2d	v29, v0, v29
    1620:      	mov.d	x11, v29[1]
    1624:      	fmov	x12, d29
    1628:      	str	s28, [x12]
    162c:      	st1.s	{ v28 }[1], [x11]
    1630:      	add.2d	v29, v0, v30
    1634:      	mov.d	x11, v29[1]
    1638:      	fmov	x12, d29
    163c:      	st1.s	{ v28 }[2], [x12]
    1640:      	add.2d	v29, v0, v12
    1644:      	st1.s	{ v28 }[3], [x11]
    1648:      	mov.d	x11, v29[1]
    164c:      	fmov	x12, d29
    1650:      	str	s27, [x12]
    1654:      	st1.s	{ v27 }[1], [x11]
    1658:      	mov.d	x11, v13[1]
    165c:      	fmov	x12, d13
    1660:      	st1.s	{ v27 }[2], [x12]
    1664:      	st1.s	{ v27 }[3], [x11]
    1668:      	dup.2d	v27, x27
    166c:      	add.2d	v25, v25, v27
    1670:      	add.2d	v24, v24, v27
    1674:      	add.2d	v26, v26, v27
    1678:      	add.2d	v22, v22, v27
    167c:      	fmov	x11, d22
    1680:      	cmp	x11, #0x7f
    1684:      	b.lt	0x15f0 <ltmp0+0x15f0>
    1688:      	mov	x11, #0x0               ; =0
    168c:      	fmul.4s	v20, v20, v20
    1690:      	fmul.4s	v4, v4, v4
    1694:      	fadd.4s	v4, v10, v4
    1698:      	fadd.4s	v20, v9, v20
    169c:      	fmul.4s	v19, v19, v19
    16a0:      	fmul.4s	v2, v2, v2
    16a4:      	fadd.4s	v2, v8, v2
    16a8:      	fadd.4s	v19, v31, v19
    16ac:      	fmul.4s	v21, v21, v21
    16b0:      	fmul.4s	v22, v23, v23
    16b4:      	fadd.4s	v22, v11, v22
    16b8:      	fadd.4s	v7, v7, v21
    16bc:      	ldp	q21, q23, [sp, #0x1d0]
    16c0:      	fmul.4s	v21, v21, v21
    16c4:      	fmul.4s	v23, v23, v23
    16c8:      	fadd.4s	v20, v23, v20
    16cc:      	fadd.4s	v21, v21, v4
    16d0:      	mov.s	v21[3], v4[3]
    16d4:      	fadd.4s	v4, v19, v20
    16d8:      	fadd.4s	v2, v2, v21
    16dc:      	fadd.4s	v2, v7, v2
    16e0:      	fadd.4s	v4, v22, v4
    16e4:      	fadd.4s	v4, v6, v4
    16e8:      	fadd.4s	v2, v5, v2
    16ec:      	rev64.4s	v5, v2
    16f0:      	rev64.4s	v6, v4
    16f4:      	fadd.4s	v4, v4, v6
    16f8:      	fadd.4s	v2, v2, v5
    16fc:      	dup.4s	v5, v2[2]
    1700:      	dup.4s	v6, v4[2]
    1704:      	fadd.4s	v4, v4, v6
    1708:      	fadd.4s	v2, v2, v5
    170c:      	fadd.4s	v2, v4, v2
    1710:      	movi	d4, #0000000000000000
    1714:      	fadd	s2, s2, s4
    1718:      	mov	w12, #0xc000            ; =49152
    171c:      	movk	w12, #0x447f, lsl #16
    1720:      	fmov	s4, w12
    1724:      	fdiv	s5, s2, s4
    1728:      	add	x12, x14, #0x4
    172c:      	add	x13, x14, #0x8
    1730:      	add	x0, x14, #0xc
    1734:      	ldr	s2, [x14]
    1738:      	ld1.s	{ v2 }[1], [x12]
    173c:      	ld1.s	{ v2 }[2], [x13]
    1740:      	add	x12, x14, #0x14
    1744:      	ld1.s	{ v2 }[3], [x0]
    1748:      	ldr	s4, [x14, #0x10]
    174c:      	ld1.s	{ v4 }[1], [x12]
    1750:      	add	x12, x14, #0x18
    1754:      	ld1.s	{ v4 }[2], [x12]
    1758:      	add	x12, sp, #0x560
    175c:      	add	x12, x12, #0xffc
    1760:      	ld1.s	{ v4 }[3], [x12]
    1764:      	str	q2, [sp, #0x1540]
    1768:      	mov	w12, #0xc5ac            ; =50604
    176c:      	movk	w12, #0x3727, lsl #16
    1770:      	fmov	s6, w12
    1774:      	fadd	s5, s5, s6
    1778:      	fsqrt	s5, s5
    177c:      	dup.4s	v6, v5[0]
    1780:      	str	q4, [sp, #0x1550]
    1784:      	ldr	x12, [sp, #0x250]
    1788:      	add	x8, x12, x8
    178c:      	movi.2d	v7, #0000000000000000
    1790:      	movi.2d	v19, #0000000000000000
    1794:      	movi.2d	v20, #0000000000000000
    1798:      	movi.2d	v21, #0000000000000000
    179c:      	shl.2d	v22, v21, #0x5
    17a0:      	shl.2d	v23, v20, #0x5
    17a4:      	shl.2d	v24, v19, #0x5
    17a8:      	shl.2d	v25, v7, #0x5
    17ac:      	orr.16b	v25, v25, v3
    17b0:      	orr.16b	v24, v24, v16
    17b4:      	orr.16b	v23, v23, v17
    17b8:      	orr.16b	v22, v22, v18
    17bc:      	add.2d	v26, v1, v22
    17c0:      	add.2d	v27, v1, v23
    17c4:      	add.2d	v28, v1, v24
    17c8:      	add.2d	v29, v1, v25
    17cc:      	mov.d	x12, v29[1]
    17d0:      	mov.d	x13, v28[1]
    17d4:      	mov.d	x14, v27[1]
    17d8:      	fmov	x0, d29
    17dc:      	fmov	x2, d27
    17e0:      	mov.d	x3, v26[1]
    17e4:      	fmov	x28, d26
    17e8:      	ldr	s26, [x2]
    17ec:      	ld1.s	{ v26 }[1], [x14]
    17f0:      	ld1.s	{ v26 }[2], [x28]
    17f4:      	ld1.s	{ v26 }[3], [x3]
    17f8:      	fmov	x14, d28
    17fc:      	ldr	s27, [x0]
    1800:      	ld1.s	{ v27 }[1], [x12]
    1804:      	ld1.s	{ v27 }[2], [x14]
    1808:      	ld1.s	{ v27 }[3], [x13]
    180c:      	fdiv.4s	v27, v27, v6
    1810:      	fdiv.4s	v26, v26, v6
    1814:      	add.2d	v22, v0, v22
    1818:      	add.2d	v23, v0, v23
    181c:      	add.2d	v24, v0, v24
    1820:      	add.2d	v25, v0, v25
    1824:      	mov.d	x12, v25[1]
    1828:      	fmov	x13, d25
    182c:      	mov.d	x14, v24[1]
    1830:      	mov.d	x0, v23[1]
    1834:      	mov.d	x2, v22[1]
    1838:      	fmov	x3, d24
    183c:      	ldr	s24, [x13]
    1840:      	ld1.s	{ v24 }[1], [x12]
    1844:      	ld1.s	{ v24 }[2], [x3]
    1848:      	fmov	x12, d23
    184c:      	ld1.s	{ v24 }[3], [x14]
    1850:      	ldr	s23, [x12]
    1854:      	ld1.s	{ v23 }[1], [x0]
    1858:      	fmov	x12, d22
    185c:      	ld1.s	{ v23 }[2], [x12]
    1860:      	ld1.s	{ v23 }[3], [x2]
    1864:      	fmul.4s	v22, v26, v23
    1868:      	fmul.4s	v23, v27, v24
    186c:      	add	x11, x8, x11, lsl #5
    1870:      	stp	q23, q22, [x11]
    1874:      	dup.2d	v22, x27
    1878:      	add.2d	v20, v20, v22
    187c:      	add.2d	v19, v19, v22
    1880:      	add.2d	v21, v21, v22
    1884:      	add.2d	v7, v7, v22
    1888:      	fmov	x11, d7
    188c:      	cmp	x11, #0x7f
    1890:      	b.lt	0x179c <ltmp0+0x179c>
    1894:      	ldr	q6, [sp, #0x2550]
    1898:      	ldr	q7, [sp, #0x2540]
    189c:      	dup.4s	v5, v5[0]
    18a0:      	fdiv.4s	v7, v7, v5
    18a4:      	fdiv.4s	v5, v6, v5
    18a8:      	fmul.4s	v4, v4, v5
    18ac:      	fmul.4s	v2, v2, v7
    18b0:      	ldr	x8, [sp, #0x250]
    18b4:      	add	x8, x8, x9
    18b8:      	str	q2, [x8]
    18bc:      	str	d4, [x8, #0x10]
    18c0:      	add	x8, x8, #0x18
    18c4:      	st1.s	{ v4 }[2], [x8]
    18c8:      	ldr	w13, [sp, #0x174]
    18cc:      	ldr	w14, [sp, #0x170]
    18d0:      	ldr	x0, [sp, #0x178]
    18d4:      	b	0xc8 <ltmp0+0xc8>
    18d8:      	str	w16, [sp, #0x16c]
    18dc:      	lsr	x8, x9, #3
    18e0:      	str	x8, [sp, #0x2b0]
    18e4:      	str	x9, [sp, #0x270]
    18e8:      	cmp	x9, #0x8
    18ec:      	b.lo	0x1f64 <ltmp0+0x1f64>
    18f0:      	mov	x14, #0x0               ; =0
    18f4:      	ldr	x8, [sp, #0x150]
    18f8:      	ldr	x11, [x8]
    18fc:      	ldr	x3, [x8, #0x10]
    1900:      	ldr	x13, [x8, #0x30]
    1904:      	add	x28, x3, #0xfe0
    1908:      	ldr	x8, [sp, #0x178]
    190c:      	lsl	w9, w8, #2
    1910:      	str	x9, [sp, #0x280]
    1914:      	and	x8, x8, #0x7ffffff
    1918:      	mov	w9, #0x3ff0             ; =16368
    191c:      	str	x11, [sp, #0x2a0]
    1920:      	umaddl	x9, w8, w9, x11
    1924:      	str	x13, [sp, #0x290]
    1928:      	mov	x12, #0x0               ; =0
    192c:      	ldr	x8, [sp, #0x280]
    1930:      	add	w8, w14, w8
    1934:      	and	x8, x8, #0x1fffffff
    1938:      	lsl	x13, x8, #12
    193c:      	sub	x8, x13, x8, lsl #2
    1940:      	add	x13, x9, x12
    1944:      	ldp	q2, q4, [x13]
    1948:      	add	x13, x10, x12
    194c:      	stp	q2, q4, [x13]
    1950:      	add	x12, x12, #0x20
    1954:      	cmp	x12, #0xfe0
    1958:      	b.ne	0x1940 <ltmp0+0x1940>
    195c:      	add	x12, x8, #0xfe0
    1960:      	ldr	x11, [sp, #0x2a0]
    1964:      	str	x12, [sp, #0x2c0]
    1968:      	add	x12, x11, x12
    196c:      	add	x11, x12, #0x4
    1970:      	add	x30, x12, #0x8
    1974:      	add	x2, x12, #0xc
    1978:      	ldr	s6, [x12]
    197c:      	ld1.s	{ v6 }[1], [x11]
    1980:      	ld1.s	{ v6 }[2], [x30]
    1984:      	add	x11, x12, #0x14
    1988:      	ld1.s	{ v6 }[3], [x2]
    198c:      	ldr	s7, [x12, #0x10]
    1990:      	ld1.s	{ v7 }[1], [x11]
    1994:      	add	x11, x12, #0x18
    1998:      	ld1.s	{ v7 }[2], [x11]
    199c:      	add	x11, x10, #0xffc
    19a0:      	ld1.s	{ v7 }[3], [x11]
    19a4:      	str	q6, [sp, #0x2540]
    19a8:      	str	q7, [sp, #0x2550]
    19ac:      	ldr	q2, [sp, #0x1560]
    19b0:      	ldr	q4, [sp, #0x1570]
    19b4:      	fmul.4s	v22, v4, v4
    19b8:      	fmul.4s	v21, v2, v2
    19bc:      	ldr	q2, [sp, #0x1580]
    19c0:      	ldr	q4, [sp, #0x1590]
    19c4:      	fmul.4s	v20, v4, v4
    19c8:      	fmul.4s	v19, v2, v2
    19cc:      	ldr	q2, [sp, #0x15a0]
    19d0:      	ldr	q4, [sp, #0x15b0]
    19d4:      	fmul.4s	v18, v4, v4
    19d8:      	fmul.4s	v23, v2, v2
    19dc:      	ldr	q2, [sp, #0x15c0]
    19e0:      	ldr	q4, [sp, #0x15d0]
    19e4:      	fmul.4s	v16, v4, v4
    19e8:      	fmul.4s	v17, v2, v2
    19ec:      	dup.2d	v24, x15
    19f0:      	mov.16b	v25, v24
    19f4:      	mov.16b	v26, v24
    19f8:      	mov.16b	v27, v24
    19fc:      	adrp	x6, 0x1000 <ltmp0+0x1000>
    1a00:      	adrp	x1, 0x1000 <ltmp0+0x1000>
    1a04:      	adrp	x7, 0x1000 <ltmp0+0x1000>
    1a08:      	adrp	x20, 0x1000 <ltmp0+0x1000>
    1a0c:      	adrp	x21, 0x1000 <ltmp0+0x1000>
    1a10:      	adrp	x22, 0x1000 <ltmp0+0x1000>
    1a14:      	adrp	x23, 0x1000 <ltmp0+0x1000>
    1a18:      	adrp	x24, 0x1000 <ltmp0+0x1000>
    1a1c:      	adrp	x26, 0x1000 <ltmp0+0x1000>
    1a20:      	adrp	x0, 0x1000 <ltmp0+0x1000>
    1a24:      	mov	w10, #0x4               ; =4
    1a28:      	adrp	x15, 0x1000 <ltmp0+0x1000>
    1a2c:      	adrp	x13, 0x1000 <ltmp0+0x1000>
    1a30:      	adrp	x25, 0x1000 <ltmp0+0x1000>
    1a34:      	adrp	x19, 0x1000 <ltmp0+0x1000>
    1a38:      	shl.2d	v2, v24, #0x5
    1a3c:      	add.2d	v28, v1, v2
    1a40:      	add.2d	v8, v28, v3
    1a44:      	mov.d	x11, v8[1]
    1a48:      	ldr	q2, [x5]
    1a4c:      	shl.2d	v4, v25, #0x5
    1a50:      	add.2d	v29, v1, v4
    1a54:      	add.2d	v9, v29, v2
    1a58:      	mov.d	x12, v9[1]
    1a5c:      	ldr	q4, [x6]
    1a60:      	shl.2d	v5, v26, #0x5
    1a64:      	add.2d	v30, v1, v5
    1a68:      	add.2d	v10, v30, v4
    1a6c:      	mov.d	x2, v10[1]
    1a70:      	ldr	q5, [x7]
    1a74:      	shl.2d	v31, v27, #0x5
    1a78:      	add.2d	v31, v1, v31
    1a7c:      	add.2d	v11, v31, v5
    1a80:      	mov.d	x30, v11[1]
    1a84:      	fmov	x16, d8
    1a88:      	ldr	s8, [x16]
    1a8c:      	fmov	x16, d9
    1a90:      	fmov	x4, d10
    1a94:      	ld1.s	{ v8 }[1], [x11]
    1a98:      	fmov	x11, d11
    1a9c:      	ld1.s	{ v8 }[2], [x16]
    1aa0:      	ld1.s	{ v8 }[3], [x12]
    1aa4:      	ldr	s9, [x4]
    1aa8:      	ld1.s	{ v9 }[1], [x2]
    1aac:      	ld1.s	{ v9 }[2], [x11]
    1ab0:      	ld1.s	{ v9 }[3], [x30]
    1ab4:      	fmul.4s	v9, v9, v9
    1ab8:      	fmul.4s	v8, v8, v8
    1abc:      	fadd.4s	v21, v21, v8
    1ac0:      	fadd.4s	v22, v22, v9
    1ac4:      	ldr	q8, [x1]
    1ac8:      	ldr	q9, [x20]
    1acc:      	ldr	q10, [x21]
    1ad0:      	ldr	q11, [x22]
    1ad4:      	add.2d	v11, v31, v11
    1ad8:      	add.2d	v10, v30, v10
    1adc:      	add.2d	v9, v29, v9
    1ae0:      	add.2d	v8, v28, v8
    1ae4:      	mov.d	x11, v8[1]
    1ae8:      	fmov	x12, d8
    1aec:      	mov.d	x16, v9[1]
    1af0:      	fmov	x2, d9
    1af4:      	mov.d	x4, v10[1]
    1af8:      	fmov	x30, d10
    1afc:      	mov.d	x17, v11[1]
    1b00:      	ldr	s8, [x12]
    1b04:      	ld1.s	{ v8 }[1], [x11]
    1b08:      	ld1.s	{ v8 }[2], [x2]
    1b0c:      	ld1.s	{ v8 }[3], [x16]
    1b10:      	fmov	x11, d11
    1b14:      	ldr	s9, [x30]
    1b18:      	ld1.s	{ v9 }[1], [x4]
    1b1c:      	ld1.s	{ v9 }[2], [x11]
    1b20:      	ld1.s	{ v9 }[3], [x17]
    1b24:      	fmul.4s	v9, v9, v9
    1b28:      	fmul.4s	v8, v8, v8
    1b2c:      	fadd.4s	v19, v19, v8
    1b30:      	fadd.4s	v20, v20, v9
    1b34:      	ldr	q8, [x23]
    1b38:      	ldr	q9, [x24]
    1b3c:      	ldr	q10, [x26]
    1b40:      	ldr	q11, [x0]
    1b44:      	add.2d	v11, v31, v11
    1b48:      	add.2d	v10, v30, v10
    1b4c:      	add.2d	v9, v29, v9
    1b50:      	add.2d	v8, v28, v8
    1b54:      	mov.d	x11, v8[1]
    1b58:      	mov.d	x12, v9[1]
    1b5c:      	fmov	x16, d8
    1b60:      	fmov	x17, d9
    1b64:      	mov.d	x2, v10[1]
    1b68:      	mov.d	x4, v11[1]
    1b6c:      	fmov	x30, d10
    1b70:      	ldr	s8, [x16]
    1b74:      	ld1.s	{ v8 }[1], [x11]
    1b78:      	ld1.s	{ v8 }[2], [x17]
    1b7c:      	fmov	x11, d11
    1b80:      	ld1.s	{ v8 }[3], [x12]
    1b84:      	ldr	s9, [x30]
    1b88:      	ld1.s	{ v9 }[1], [x2]
    1b8c:      	ld1.s	{ v9 }[2], [x11]
    1b90:      	ld1.s	{ v9 }[3], [x4]
    1b94:      	fmul.4s	v9, v9, v9
    1b98:      	fmul.4s	v8, v8, v8
    1b9c:      	fadd.4s	v23, v23, v8
    1ba0:      	fadd.4s	v18, v18, v9
    1ba4:      	ldr	q8, [x15]
    1ba8:      	ldr	q9, [x13]
    1bac:      	ldr	q10, [x25]
    1bb0:      	ldr	q11, [x19]
    1bb4:      	add.2d	v31, v31, v11
    1bb8:      	add.2d	v30, v30, v10
    1bbc:      	add.2d	v29, v29, v9
    1bc0:      	add.2d	v28, v28, v8
    1bc4:      	mov.d	x11, v28[1]
    1bc8:      	fmov	x12, d28
    1bcc:      	mov.d	x16, v29[1]
    1bd0:      	fmov	x17, d29
    1bd4:      	mov.d	x2, v30[1]
    1bd8:      	fmov	x4, d30
    1bdc:      	mov.d	x30, v31[1]
    1be0:      	ldr	s28, [x12]
    1be4:      	ld1.s	{ v28 }[1], [x11]
    1be8:      	fmov	x11, d31
    1bec:      	ld1.s	{ v28 }[2], [x17]
    1bf0:      	ld1.s	{ v28 }[3], [x16]
    1bf4:      	ldr	s29, [x4]
    1bf8:      	ld1.s	{ v29 }[1], [x2]
    1bfc:      	ld1.s	{ v29 }[2], [x11]
    1c00:      	ld1.s	{ v29 }[3], [x30]
    1c04:      	fmul.4s	v29, v29, v29
    1c08:      	fmul.4s	v28, v28, v28
    1c0c:      	fadd.4s	v17, v17, v28
    1c10:      	fadd.4s	v16, v16, v29
    1c14:      	dup.2d	v28, x10
    1c18:      	add.2d	v26, v26, v28
    1c1c:      	add.2d	v25, v25, v28
    1c20:      	add.2d	v27, v27, v28
    1c24:      	add.2d	v24, v24, v28
    1c28:      	fmov	x11, d24
    1c2c:      	cmp	x11, #0x7c
    1c30:      	b.lt	0x1a38 <ltmp0+0x1a38>
    1c34:      	mov	x12, #0x0               ; =0
    1c38:      	ldr	q25, [sp, #0x24f0]
    1c3c:      	ldr	q27, [sp, #0x24e0]
    1c40:      	ldr	q24, [sp, #0x2510]
    1c44:      	ldr	q26, [sp, #0x2500]
    1c48:      	movi.2d	v29, #0000000000000000
    1c4c:      	movi.2d	v31, #0000000000000000
    1c50:      	ldr	q28, [sp, #0x2530]
    1c54:      	movi.2d	v8, #0000000000000000
    1c58:      	movi.2d	v9, #0000000000000000
    1c5c:      	ldr	q30, [sp, #0x2520]
    1c60:      	add	x11, x3, x12, lsl #5
    1c64:      	ldp	q11, q10, [x11]
    1c68:      	shl.2d	v12, v29, #0x5
    1c6c:      	shl.2d	v13, v31, #0x5
    1c70:      	shl.2d	v14, v8, #0x5
    1c74:      	shl.2d	v15, v9, #0x5
    1c78:      	add.2d	v15, v15, v5
    1c7c:      	add.2d	v15, v0, v15
    1c80:      	add.2d	v14, v14, v4
    1c84:      	add.2d	v13, v13, v2
    1c88:      	add.2d	v12, v12, v3
    1c8c:      	add.2d	v12, v0, v12
    1c90:      	mov.d	x11, v12[1]
    1c94:      	fmov	x12, d12
    1c98:      	str	s11, [x12]
    1c9c:      	st1.s	{ v11 }[1], [x11]
    1ca0:      	add.2d	v12, v0, v13
    1ca4:      	mov.d	x11, v12[1]
    1ca8:      	fmov	x12, d12
    1cac:      	st1.s	{ v11 }[2], [x12]
    1cb0:      	add.2d	v12, v0, v14
    1cb4:      	st1.s	{ v11 }[3], [x11]
    1cb8:      	mov.d	x11, v12[1]
    1cbc:      	fmov	x12, d12
    1cc0:      	str	s10, [x12]
    1cc4:      	st1.s	{ v10 }[1], [x11]
    1cc8:      	mov.d	x11, v15[1]
    1ccc:      	fmov	x12, d15
    1cd0:      	st1.s	{ v10 }[2], [x12]
    1cd4:      	st1.s	{ v10 }[3], [x11]
    1cd8:      	dup.2d	v10, x27
    1cdc:      	add.2d	v8, v8, v10
    1ce0:      	add.2d	v31, v31, v10
    1ce4:      	add.2d	v9, v9, v10
    1ce8:      	add.2d	v29, v29, v10
    1cec:      	fmov	x12, d29
    1cf0:      	cmp	x12, #0x7f
    1cf4:      	b.lt	0x1c60 <ltmp0+0x1c60>
    1cf8:      	mov	x12, #0x0               ; =0
    1cfc:      	fmul.4s	v27, v27, v27
    1d00:      	fmul.4s	v25, v25, v25
    1d04:      	fadd.4s	v22, v22, v25
    1d08:      	fadd.4s	v21, v21, v27
    1d0c:      	fmul.4s	v25, v26, v26
    1d10:      	fmul.4s	v24, v24, v24
    1d14:      	fadd.4s	v20, v20, v24
    1d18:      	fadd.4s	v19, v19, v25
    1d1c:      	fmul.4s	v24, v28, v28
    1d20:      	fmul.4s	v25, v30, v30
    1d24:      	fadd.4s	v23, v23, v25
    1d28:      	fadd.4s	v18, v18, v24
    1d2c:      	fmul.4s	v7, v7, v7
    1d30:      	fmul.4s	v6, v6, v6
    1d34:      	fadd.4s	v6, v6, v21
    1d38:      	fadd.4s	v7, v7, v22
    1d3c:      	mov.s	v7[3], v22[3]
    1d40:      	fadd.4s	v6, v19, v6
    1d44:      	fadd.4s	v7, v20, v7
    1d48:      	fadd.4s	v7, v18, v7
    1d4c:      	fadd.4s	v6, v23, v6
    1d50:      	fadd.4s	v6, v17, v6
    1d54:      	fadd.4s	v7, v16, v7
    1d58:      	rev64.4s	v16, v7
    1d5c:      	rev64.4s	v17, v6
    1d60:      	fadd.4s	v6, v6, v17
    1d64:      	fadd.4s	v7, v7, v16
    1d68:      	dup.4s	v16, v7[2]
    1d6c:      	dup.4s	v17, v6[2]
    1d70:      	fadd.4s	v6, v6, v17
    1d74:      	fadd.4s	v7, v7, v16
    1d78:      	fadd.4s	v6, v6, v7
    1d7c:      	movi	d7, #0000000000000000
    1d80:      	fadd	s6, s6, s7
    1d84:      	mov	w10, #0xc000            ; =49152
    1d88:      	movk	w10, #0x447f, lsl #16
    1d8c:      	fmov	s7, w10
    1d90:      	fdiv	s16, s6, s7
    1d94:      	add	x11, x28, #0x4
    1d98:      	add	x16, x28, #0x8
    1d9c:      	add	x17, x28, #0xc
    1da0:      	ldr	s6, [x28]
    1da4:      	ld1.s	{ v6 }[1], [x11]
    1da8:      	ld1.s	{ v6 }[2], [x16]
    1dac:      	add	x11, x28, #0x14
    1db0:      	ld1.s	{ v6 }[3], [x17]
    1db4:      	ldr	s7, [x28, #0x10]
    1db8:      	ld1.s	{ v7 }[1], [x11]
    1dbc:      	add	x11, x28, #0x18
    1dc0:      	ld1.s	{ v7 }[2], [x11]
    1dc4:      	add	x11, sp, #0x560
    1dc8:      	add	x11, x11, #0xffc
    1dcc:      	ld1.s	{ v7 }[3], [x11]
    1dd0:      	str	q6, [sp, #0x1540]
    1dd4:      	mov	w10, #0xc5ac            ; =50604
    1dd8:      	movk	w10, #0x3727, lsl #16
    1ddc:      	fmov	s17, w10
    1de0:      	fadd	s16, s16, s17
    1de4:      	fsqrt	s16, s16
    1de8:      	dup.4s	v17, v16[0]
    1dec:      	str	q7, [sp, #0x1550]
    1df0:      	ldr	x13, [sp, #0x290]
    1df4:      	add	x8, x13, x8
    1df8:      	movi.2d	v18, #0000000000000000
    1dfc:      	movi.2d	v19, #0000000000000000
    1e00:      	movi.2d	v20, #0000000000000000
    1e04:      	movi.2d	v21, #0000000000000000
    1e08:      	adrp	x1, 0x1000 <ltmp0+0x1000>
    1e0c:      	adrp	x20, 0x1000 <ltmp0+0x1000>
    1e10:      	mov	w15, #0x4               ; =4
    1e14:      	add	x10, sp, #0x1, lsl #12  ; =0x1000
    1e18:      	add	x10, x10, #0x560
    1e1c:      	adrp	x26, 0x1000 <ltmp0+0x1000>
    1e20:      	shl.2d	v22, v21, #0x5
    1e24:      	shl.2d	v23, v20, #0x5
    1e28:      	shl.2d	v24, v19, #0x5
    1e2c:      	shl.2d	v25, v18, #0x5
    1e30:      	orr.16b	v25, v25, v3
    1e34:      	orr.16b	v24, v24, v2
    1e38:      	orr.16b	v23, v23, v4
    1e3c:      	orr.16b	v22, v22, v5
    1e40:      	add.2d	v26, v1, v22
    1e44:      	add.2d	v27, v1, v23
    1e48:      	add.2d	v28, v1, v24
    1e4c:      	add.2d	v29, v1, v25
    1e50:      	mov.d	x11, v29[1]
    1e54:      	mov.d	x16, v28[1]
    1e58:      	mov.d	x17, v27[1]
    1e5c:      	fmov	x2, d29
    1e60:      	fmov	x4, d27
    1e64:      	mov.d	x30, v26[1]
    1e68:      	fmov	x5, d26
    1e6c:      	ldr	s26, [x4]
    1e70:      	ld1.s	{ v26 }[1], [x17]
    1e74:      	ld1.s	{ v26 }[2], [x5]
    1e78:      	ld1.s	{ v26 }[3], [x30]
    1e7c:      	fmov	x17, d28
    1e80:      	ldr	s27, [x2]
    1e84:      	ld1.s	{ v27 }[1], [x11]
    1e88:      	ld1.s	{ v27 }[2], [x17]
    1e8c:      	ld1.s	{ v27 }[3], [x16]
    1e90:      	fdiv.4s	v27, v27, v17
    1e94:      	fdiv.4s	v26, v26, v17
    1e98:      	add.2d	v22, v0, v22
    1e9c:      	add.2d	v23, v0, v23
    1ea0:      	add.2d	v24, v0, v24
    1ea4:      	add.2d	v25, v0, v25
    1ea8:      	mov.d	x11, v25[1]
    1eac:      	fmov	x16, d25
    1eb0:      	mov.d	x17, v24[1]
    1eb4:      	mov.d	x2, v23[1]
    1eb8:      	mov.d	x4, v22[1]
    1ebc:      	fmov	x5, d24
    1ec0:      	ldr	s24, [x16]
    1ec4:      	ld1.s	{ v24 }[1], [x11]
    1ec8:      	ld1.s	{ v24 }[2], [x5]
    1ecc:      	fmov	x11, d23
    1ed0:      	ld1.s	{ v24 }[3], [x17]
    1ed4:      	ldr	s23, [x11]
    1ed8:      	ld1.s	{ v23 }[1], [x2]
    1edc:      	fmov	x11, d22
    1ee0:      	ld1.s	{ v23 }[2], [x11]
    1ee4:      	ld1.s	{ v23 }[3], [x4]
    1ee8:      	fmul.4s	v22, v26, v23
    1eec:      	fmul.4s	v23, v27, v24
    1ef0:      	add	x11, x8, x12, lsl #5
    1ef4:      	stp	q23, q22, [x11]
    1ef8:      	dup.2d	v22, x27
    1efc:      	add.2d	v20, v20, v22
    1f00:      	add.2d	v19, v19, v22
    1f04:      	add.2d	v21, v21, v22
    1f08:      	add.2d	v18, v18, v22
    1f0c:      	fmov	x12, d18
    1f10:      	cmp	x12, #0x7f
    1f14:      	b.lt	0x1e20 <ltmp0+0x1e20>
    1f18:      	ldr	q2, [sp, #0x2550]
    1f1c:      	ldr	q4, [sp, #0x2540]
    1f20:      	dup.4s	v5, v16[0]
    1f24:      	fdiv.4s	v4, v4, v5
    1f28:      	fdiv.4s	v2, v2, v5
    1f2c:      	fmul.4s	v2, v7, v2
    1f30:      	fmul.4s	v4, v6, v4
    1f34:      	ldr	x8, [sp, #0x2c0]
    1f38:      	add	x8, x13, x8
    1f3c:      	str	q4, [x8]
    1f40:      	str	d2, [x8, #0x10]
    1f44:      	add	x8, x8, #0x18
    1f48:      	st1.s	{ v2 }[2], [x8]
    1f4c:      	add	x14, x14, #0x1
    1f50:      	add	x9, x9, #0xffc
    1f54:      	ldr	x8, [sp, #0x2b0]
    1f58:      	cmp	x14, x8
    1f5c:      	adrp	x5, 0x1000 <ltmp0+0x1000>
    1f60:      	b.ne	0x1928 <ltmp0+0x1928>
    1f64:      	ldr	x8, [sp, #0x270]
    1f68:      	and	w8, w8, #0x7
    1f6c:      	ldr	w16, [sp, #0x16c]
    1f70:      	mov	w17, #0xffc             ; =4092
    1f74:      	adrp	x6, 0x1000 <ltmp0+0x1000>
    1f78:      	adrp	x7, 0x1000 <ltmp0+0x1000>
    1f7c:      	adrp	x19, 0x1000 <ltmp0+0x1000>
    1f80:      	adrp	x4, 0x1000 <ltmp0+0x1000>
    1f84:      	adrp	x21, 0x1000 <ltmp0+0x1000>
    1f88:      	adrp	x22, 0x1000 <ltmp0+0x1000>
    1f8c:      	adrp	x23, 0x1000 <ltmp0+0x1000>
    1f90:      	adrp	x24, 0x1000 <ltmp0+0x1000>
    1f94:      	adrp	x25, 0x1000 <ltmp0+0x1000>
    1f98:      	ldr	w13, [sp, #0x174]
    1f9c:      	ldr	w14, [sp, #0x170]
    1fa0:      	ldr	x0, [sp, #0x178]
    1fa4:      	cbz	w8, 0xc8 <ltmp0+0xc8>
    1fa8:      	dup.4s	v2, w8
    1fac:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1fb0:      	ldr	q4, [x8]
    1fb4:      	adrp	x8, 0x1000 <ltmp0+0x1000>
    1fb8:      	ldr	q5, [x8]
    1fbc:      	cmhi.4s	v13, v2, v5
    1fc0:      	cmhi.4s	v14, v2, v4
    1fc4:      	uzp1.8h	v2, v14, v13
    1fc8:      	umaxv.8h	h4, v2
    1fcc:      	fmov	w8, s4
    1fd0:      	tbz	w8, #0x0, 0xc8 <ltmp0+0xc8>
    1fd4:      	mov	x9, #0x0                ; =0
    1fd8:      	ldr	x11, [sp, #0x150]
    1fdc:      	ldr	x8, [x11]
    1fe0:      	ldr	x12, [x11, #0x10]
    1fe4:      	ldr	x16, [x11, #0x30]
    1fe8:      	adrp	x11, 0x1000 <ltmp0+0x1000>
    1fec:      	ldr	q4, [x11]
    1ff0:      	and.16b	v4, v2, v4
    1ff4:      	addv.8h	h16, v4
    1ff8:      	ubfiz	w11, w0, #2, #27
    1ffc:      	ldr	x13, [sp, #0x2b0]
    2000:      	orr	w11, w11, w13
    2004:      	fmov	w13, s16
    2008:      	and	w13, w13, #0xff
    200c:      	str	w13, [sp, #0xec]
    2010:      	dup.4s	v4, w11
    2014:      	and.16b	v6, v14, v4
    2018:      	and.16b	v4, v13, v4
    201c:      	ushll2.2d	v5, v4, #0x0
    2020:      	ushll2.2d	v7, v6, #0x0
    2024:      	ushll.2d	v17, v4, #0x0
    2028:      	ushll.2d	v6, v6, #0x0
    202c:      	fmov	x11, d6
    2030:      	umaddl	x13, w11, w17, x8
    2034:      	b	0x2058 <ltmp0+0x2058>
    2038:      	add	x11, x10, x9
    203c:      	ldp	q19, q20, [x11]
    2040:      	bif.16b	v18, v20, v13
    2044:      	bif.16b	v4, v19, v14
    2048:      	stp	q4, q18, [x11]
    204c:      	add	x9, x9, #0x20
    2050:      	cmp	x9, #0xfe0
    2054:      	b.eq	0x20f0 <ltmp0+0x20f0>
    2058:      	fmov	w11, s16
    205c:      	add	x14, x13, x9
    2060:      	movi.2d	v4, #0000000000000000
    2064:      	movi.2d	v18, #0000000000000000
    2068:      	tbnz	w11, #0x0, 0x2090 <ltmp0+0x2090>
    206c:      	and	w0, w11, #0xff
    2070:      	tbnz	w0, #0x1, 0x209c <ltmp0+0x209c>
    2074:      	tbnz	w0, #0x2, 0x20a8 <ltmp0+0x20a8>
    2078:      	tbnz	w0, #0x3, 0x20b4 <ltmp0+0x20b4>
    207c:      	tbnz	w0, #0x4, 0x20c0 <ltmp0+0x20c0>
    2080:      	tbnz	w0, #0x5, 0x20cc <ltmp0+0x20cc>
    2084:      	tbnz	w0, #0x6, 0x20d8 <ltmp0+0x20d8>
    2088:      	tbz	w0, #0x7, 0x2038 <ltmp0+0x2038>
    208c:      	b	0x20e4 <ltmp0+0x20e4>
    2090:      	ldr	s4, [x14]
    2094:      	and	w0, w11, #0xff
    2098:      	tbz	w0, #0x1, 0x2074 <ltmp0+0x2074>
    209c:      	add	x11, x14, #0x4
    20a0:      	ld1.s	{ v4 }[1], [x11]
    20a4:      	tbz	w0, #0x2, 0x2078 <ltmp0+0x2078>
    20a8:      	add	x11, x14, #0x8
    20ac:      	ld1.s	{ v4 }[2], [x11]
    20b0:      	tbz	w0, #0x3, 0x207c <ltmp0+0x207c>
    20b4:      	add	x11, x14, #0xc
    20b8:      	ld1.s	{ v4 }[3], [x11]
    20bc:      	tbz	w0, #0x4, 0x2080 <ltmp0+0x2080>
    20c0:      	add	x11, x14, #0x10
    20c4:      	ld1.s	{ v18 }[0], [x11]
    20c8:      	tbz	w0, #0x5, 0x2084 <ltmp0+0x2084>
    20cc:      	add	x11, x14, #0x14
    20d0:      	ld1.s	{ v18 }[1], [x11]
    20d4:      	tbz	w0, #0x6, 0x2088 <ltmp0+0x2088>
    20d8:      	add	x11, x14, #0x18
    20dc:      	ld1.s	{ v18 }[2], [x11]
    20e0:      	tbz	w0, #0x7, 0x2038 <ltmp0+0x2038>
    20e4:      	add	x11, x14, #0x1c
    20e8:      	ld1.s	{ v18 }[3], [x11]
    20ec:      	b	0x2038 <ltmp0+0x2038>
    20f0:      	xtn.8b	v23, v2
    20f4:      	sshll.2d	v2, v14, #0x0
    20f8:      	sshll2.2d	v19, v14, #0x0
    20fc:      	sshll.2d	v4, v13, #0x0
    2100:      	sshll2.2d	v20, v13, #0x0
    2104:      	adrp	x9, 0x2000 <ltmp0+0x2000>
    2108:      	ldr	q18, [x9]
    210c:      	str	q20, [sp, #0x240]
    2110:      	and.16b	v20, v20, v18
    2114:      	adrp	x9, 0x2000 <ltmp0+0x2000>
    2118:      	ldr	q18, [x9]
    211c:      	and.16b	v21, v4, v18
    2120:      	adrp	x9, 0x2000 <ltmp0+0x2000>
    2124:      	ldr	q18, [x9]
    2128:      	str	q19, [sp, #0x250]
    212c:      	and.16b	v24, v19, v18
    2130:      	adrp	x9, 0x2000 <ltmp0+0x2000>
    2134:      	ldr	q18, [x9]
    2138:      	and.16b	v22, v2, v18
    213c:      	mov.16b	v19, v23
    2140:      	mov.b	v19[7], wzr
    2144:      	adrp	x9, 0x2000 <ltmp0+0x2000>
    2148:      	ldr	d18, [x9]
    214c:      	str	d18, [sp, #0x88]
    2150:      	and.8b	v18, v19, v18
    2154:      	addv.8b	b18, v18
    2158:      	fmov	w9, s18
    215c:      	str	q19, [sp, #0x140]
    2160:      	umaxv.8b	b18, v19
    2164:      	fmov	w11, s18
    2168:      	rbit	w13, w9
    216c:      	clz	w13, w13
    2170:      	tst	w11, #0x1
    2174:      	csel	w14, w13, wzr, ne
    2178:      	mov	w11, #0x3f8             ; =1016
    217c:      	dup.2d	v18, x11
    2180:      	stp	q22, q24, [sp, #0x30]
    2184:      	orr.16b	v22, v22, v18
    2188:      	orr.16b	v19, v24, v18
    218c:      	stp	q21, q20, [sp, #0x50]
    2190:      	orr.16b	v21, v21, v18
    2194:      	orr.16b	v20, v20, v18
    2198:      	xtn.2s	v6, v6
    219c:      	xtn.2s	v7, v7
    21a0:      	xtn.2s	v17, v17
    21a4:      	xtn.2s	v5, v5
    21a8:      	stp	q21, q20, [sp, #0xc0]
    21ac:      	movi.2s	v18, #0x3, msl #8
    21b0:      	umlal.2d	v20, v5, v18
    21b4:      	umlal.2d	v21, v17, v18
    21b8:      	stp	q22, q19, [sp, #0xa0]
    21bc:      	mov.16b	v17, v19
    21c0:      	umlal.2d	v17, v7, v18
    21c4:      	movi.2s	v19, #0x3, msl #8
    21c8:      	umlal.2d	v22, v6, v18
    21cc:      	mov	b5, v23[0]
    21d0:      	mov.b	v5[4], v23[1]
    21d4:      	ushll.2d	v5, v5, #0x0
    21d8:      	shl.2d	v5, v5, #0x3f
    21dc:      	cmlt.2d	v5, v5, #0
    21e0:      	mov	b7, v23[2]
    21e4:      	mov.b	v7[4], v23[3]
    21e8:      	stp	q22, q17, [sp, #0xf0]
    21ec:      	and.16b	v5, v5, v22
    21f0:      	ushll.2d	v7, v7, #0x0
    21f4:      	shl.2d	v7, v7, #0x3f
    21f8:      	cmlt.2d	v7, v7, #0
    21fc:      	and.16b	v7, v7, v17
    2200:      	mov	b17, v23[4]
    2204:      	mov.b	v17[4], v23[5]
    2208:      	ushll.2d	v17, v17, #0x0
    220c:      	shl.2d	v17, v17, #0x3f
    2210:      	cmlt.2d	v17, v17, #0
    2214:      	stp	q21, q20, [sp, #0x110]
    2218:      	and.16b	v17, v17, v21
    221c:      	movi.2d	v18, #0000000000000000
    2220:      	str	q23, [sp, #0x70]
    2224:      	mov.b	v18[0], v23[6]
    2228:      	ushll.2d	v18, v18, #0x0
    222c:      	shl.2d	v18, v18, #0x3f
    2230:      	cmlt.2d	v18, v18, #0
    2234:      	and.16b	v18, v18, v20
    2238:      	str	q18, [sp, #0x540]
    223c:      	str	q17, [sp, #0x530]
    2240:      	str	q7, [sp, #0x520]
    2244:      	str	q5, [sp, #0x510]
    2248:      	and	x11, x14, #0x7
    224c:      	add	x13, sp, #0x510
    2250:      	ldr	x11, [x13, x11, lsl #3]
    2254:      	sub	x11, x11, x14
    2258:      	add	x8, x8, x11, lsl #2
    225c:      	movi.2d	v23, #0000000000000000
    2260:      	movi.2d	v25, #0000000000000000
    2264:      	tbnz	w9, #0x0, 0x339c <ltmp0+0x339c>
    2268:      	tbnz	w9, #0x1, 0x33a4 <ltmp0+0x33a4>
    226c:      	tbnz	w9, #0x2, 0x33b0 <ltmp0+0x33b0>
    2270:      	tbnz	w9, #0x3, 0x33bc <ltmp0+0x33bc>
    2274:      	tbnz	w9, #0x4, 0x33c8 <ltmp0+0x33c8>
    2278:      	tbnz	w9, #0x5, 0x33d4 <ltmp0+0x33d4>
    227c:      	tbnz	w9, #0x6, 0x33e0 <ltmp0+0x33e0>
    2280:      	tbz	w9, #0x7, 0x228c <ltmp0+0x228c>
    2284:      	add	x8, x8, #0x1c
    2288:      	ld1.s	{ v25 }[3], [x8]
    228c:      	ldp	q27, q26, [sp, #0x240]
    2290:      	and.16b	v7, v27, v1
    2294:      	and.16b	v5, v4, v1
    2298:      	stp	q5, q7, [sp, #0x2b0]
    229c:      	and.16b	v24, v2, v1
    22a0:      	ldr	q5, [x1]
    22a4:      	and.16b	v18, v27, v5
    22a8:      	ldr	q5, [x5]
    22ac:      	and.16b	v20, v26, v5
    22b0:      	adrp	x8, 0x2000 <ltmp0+0x2000>
    22b4:      	ldr	q5, [x8]
    22b8:      	and.16b	v21, v4, v5
    22bc:      	and.16b	v22, v2, v3
    22c0:      	umull.2d	v2, v6, v19
    22c4:      	str	q2, [sp, #0x90]
    22c8:      	sshll.2d	v4, v14, #0x0
    22cc:      	sshll.2d	v6, v13, #0x0
    22d0:      	str	q22, [sp, #0x4d0]
    22d4:      	str	q20, [sp, #0x4e0]
    22d8:      	str	q21, [sp, #0x4f0]
    22dc:      	str	q18, [sp, #0x500]
    22e0:      	and	x8, x14, #0x7
    22e4:      	add	x11, sp, #0x4d0
    22e8:      	ldr	x8, [x11, x8, lsl #3]
    22ec:      	orr	x8, x8, #0xfe0
    22f0:      	sub	x8, x8, x14, lsl #2
    22f4:      	tst	w9, #0xff
    22f8:      	csel	x3, xzr, x8, eq
    22fc:      	add	x8, x10, x3
    2300:      	ldp	q2, q5, [x8]
    2304:      	ldr	q17, [sp, #0x140]
    2308:      	zip2.8b	v7, v17, v0
    230c:      	ushll.4s	v7, v7, #0x0
    2310:      	shl.4s	v7, v7, #0x1f
    2314:      	cmlt.4s	v7, v7, #0
    2318:      	stp	q25, q23, [sp, #0x10]
    231c:      	bit.16b	v5, v25, v7
    2320:      	zip1.8b	v7, v17, v0
    2324:      	ushll.4s	v7, v7, #0x0
    2328:      	shl.4s	v7, v7, #0x1f
    232c:      	cmlt.4s	v7, v7, #0
    2330:      	bit.16b	v2, v23, v7
    2334:      	stp	q2, q5, [x8]
    2338:      	mov	w8, #0x20               ; =32
    233c:      	dup.2d	v2, x8
    2340:      	orr.16b	v7, v21, v2
    2344:      	orr.16b	v5, v20, v2
    2348:      	stp	q5, q7, [sp, #0x220]
    234c:      	orr.16b	v5, v22, v2
    2350:      	orr.16b	v2, v18, v2
    2354:      	stp	q2, q5, [sp, #0x200]
    2358:      	mov	w8, #0x40               ; =64
    235c:      	dup.2d	v2, x8
    2360:      	orr.16b	v7, v21, v2
    2364:      	orr.16b	v5, v20, v2
    2368:      	stp	q5, q7, [sp, #0x1e0]
    236c:      	orr.16b	v5, v22, v2
    2370:      	orr.16b	v2, v18, v2
    2374:      	stp	q2, q5, [sp, #0x1c0]
    2378:      	mov	w8, #0x60               ; =96
    237c:      	dup.2d	v2, x8
    2380:      	stp	q21, q20, [sp, #0x280]
    2384:      	orr.16b	v7, v21, v2
    2388:      	orr.16b	v5, v20, v2
    238c:      	stp	q5, q7, [sp, #0x1a0]
    2390:      	orr.16b	v5, v22, v2
    2394:      	str	q18, [sp, #0x2a0]
    2398:      	orr.16b	v2, v18, v2
    239c:      	stp	q2, q5, [sp, #0x180]
    23a0:      	ldr	q2, [sp, #0x15d0]
    23a4:      	ldr	q5, [sp, #0x15c0]
    23a8:      	fmul.4s	v5, v5, v5
    23ac:      	fmul.4s	v2, v2, v2
    23b0:      	and.16b	v18, v13, v2
    23b4:      	and.16b	v5, v14, v5
    23b8:      	ldr	q2, [sp, #0x15b0]
    23bc:      	ldr	q7, [sp, #0x15a0]
    23c0:      	fmul.4s	v7, v7, v7
    23c4:      	fmul.4s	v2, v2, v2
    23c8:      	and.16b	v2, v13, v2
    23cc:      	and.16b	v30, v14, v7
    23d0:      	ldr	q7, [sp, #0x1590]
    23d4:      	ldr	q17, [sp, #0x1580]
    23d8:      	fmul.4s	v17, v17, v17
    23dc:      	fmul.4s	v7, v7, v7
    23e0:      	and.16b	v31, v13, v7
    23e4:      	and.16b	v8, v14, v17
    23e8:      	str	q22, [sp, #0x270]
    23ec:      	fmov	x8, d22
    23f0:      	add	x8, x10, x8
    23f4:      	ldp	q17, q7, [x8]
    23f8:      	fmul.4s	v17, v17, v17
    23fc:      	fmul.4s	v7, v7, v7
    2400:      	and.16b	v19, v13, v7
    2404:      	dup.2d	v7, x15
    2408:      	and.16b	v20, v14, v17
    240c:      	and.16b	v9, v27, v7
    2410:      	and.16b	v10, v6, v7
    2414:      	and.16b	v11, v4, v7
    2418:      	and.16b	v15, v26, v7
    241c:      	and.16b	v29, v26, v1
    2420:      	b	0x24c4 <ltmp0+0x24c4>
    2424:      	fmul.4s	v4, v6, v6
    2428:      	fmul.4s	v6, v21, v21
    242c:      	fadd.4s	v21, v20, v6
    2430:      	fadd.4s	v12, v19, v4
    2434:      	fmul.4s	v4, v26, v26
    2438:      	fmul.4s	v6, v25, v25
    243c:      	fadd.4s	v7, v8, v6
    2440:      	fadd.4s	v17, v31, v4
    2444:      	fmul.4s	v6, v28, v28
    2448:      	fmul.4s	v4, v27, v27
    244c:      	fadd.4s	v4, v30, v4
    2450:      	fadd.4s	v6, v2, v6
    2454:      	sshll.2d	v25, v14, #0x0
    2458:      	sshll.2d	v26, v13, #0x0
    245c:      	fmul.4s	v22, v22, v22
    2460:      	fmul.4s	v23, v23, v23
    2464:      	fadd.4s	v23, v18, v23
    2468:      	fadd.4s	v22, v5, v22
    246c:      	dup.2d	v27, x15
    2470:      	ldr	q28, [sp, #0x240]
    2474:      	and.16b	v28, v28, v27
    2478:      	add.2d	v9, v9, v28
    247c:      	ldr	q28, [sp, #0x250]
    2480:      	and.16b	v28, v28, v27
    2484:      	add.2d	v15, v15, v28
    2488:      	and.16b	v26, v26, v27
    248c:      	add.2d	v10, v10, v26
    2490:      	and.16b	v25, v25, v27
    2494:      	add.2d	v11, v11, v25
    2498:      	bit.16b	v19, v12, v13
    249c:      	bit.16b	v20, v21, v14
    24a0:      	bit.16b	v31, v17, v13
    24a4:      	bit.16b	v8, v7, v14
    24a8:      	bit.16b	v2, v6, v13
    24ac:      	bit.16b	v30, v4, v14
    24b0:      	bit.16b	v5, v22, v14
    24b4:      	bit.16b	v18, v23, v13
    24b8:      	fmov	x8, d11
    24bc:      	cmp	x8, #0x7c
    24c0:      	b.ge	0x28c4 <ltmp0+0x28c4>
    24c4:      	fmov	w8, s16
    24c8:      	shl.2d	v4, v11, #0x5
    24cc:      	ldr	q6, [sp, #0x270]
    24d0:      	orr.16b	v6, v4, v6
    24d4:      	add.2d	v7, v24, v6
    24d8:      	movi.2d	v21, #0000000000000000
    24dc:      	movi.2d	v6, #0000000000000000
    24e0:      	tbnz	w8, #0x0, 0x2690 <ltmp0+0x2690>
    24e4:      	and	w8, w8, #0xff
    24e8:      	tbnz	w8, #0x1, 0x26a0 <ltmp0+0x26a0>
    24ec:      	shl.2d	v7, v15, #0x5
    24f0:      	ldr	q17, [sp, #0x290]
    24f4:      	orr.16b	v17, v7, v17
    24f8:      	add.2d	v17, v29, v17
    24fc:      	tbnz	w8, #0x2, 0x26bc <ltmp0+0x26bc>
    2500:      	tbnz	w8, #0x3, 0x26c8 <ltmp0+0x26c8>
    2504:      	shl.2d	v17, v10, #0x5
    2508:      	ldr	q22, [sp, #0x280]
    250c:      	orr.16b	v22, v17, v22
    2510:      	ldr	q23, [sp, #0x2b0]
    2514:      	add.2d	v22, v23, v22
    2518:      	tbnz	w8, #0x4, 0x26e8 <ltmp0+0x26e8>
    251c:      	tbnz	w8, #0x5, 0x26f4 <ltmp0+0x26f4>
    2520:      	shl.2d	v12, v9, #0x5
    2524:      	ldr	q22, [sp, #0x2a0]
    2528:      	orr.16b	v22, v12, v22
    252c:      	ldr	q23, [sp, #0x2c0]
    2530:      	add.2d	v22, v23, v22
    2534:      	tbnz	w8, #0x6, 0x2714 <ltmp0+0x2714>
    2538:      	tbz	w8, #0x7, 0x2544 <ltmp0+0x2544>
    253c:      	mov.d	x8, v22[1]
    2540:      	ld1.s	{ v6 }[3], [x8]
    2544:      	fmov	w8, s16
    2548:      	ldr	q22, [sp, #0x210]
    254c:      	add.2d	v22, v22, v4
    2550:      	add.2d	v22, v24, v22
    2554:      	movi.2d	v25, #0000000000000000
    2558:      	movi.2d	v26, #0000000000000000
    255c:      	tbnz	w8, #0x0, 0x2724 <ltmp0+0x2724>
    2560:      	and	w8, w8, #0xff
    2564:      	tbnz	w8, #0x1, 0x2734 <ltmp0+0x2734>
    2568:      	ldr	q22, [sp, #0x220]
    256c:      	add.2d	v22, v22, v7
    2570:      	add.2d	v22, v29, v22
    2574:      	tbnz	w8, #0x2, 0x274c <ltmp0+0x274c>
    2578:      	tbnz	w8, #0x3, 0x2758 <ltmp0+0x2758>
    257c:      	ldr	q22, [sp, #0x230]
    2580:      	add.2d	v22, v22, v17
    2584:      	ldr	q23, [sp, #0x2b0]
    2588:      	add.2d	v22, v23, v22
    258c:      	tbnz	w8, #0x4, 0x2774 <ltmp0+0x2774>
    2590:      	tbnz	w8, #0x5, 0x2780 <ltmp0+0x2780>
    2594:      	ldr	q22, [sp, #0x200]
    2598:      	add.2d	v22, v22, v12
    259c:      	ldr	q23, [sp, #0x2c0]
    25a0:      	add.2d	v22, v23, v22
    25a4:      	tbnz	w8, #0x6, 0x279c <ltmp0+0x279c>
    25a8:      	tbz	w8, #0x7, 0x25b4 <ltmp0+0x25b4>
    25ac:      	mov.d	x8, v22[1]
    25b0:      	ld1.s	{ v26 }[3], [x8]
    25b4:      	fmov	w8, s16
    25b8:      	ldr	q22, [sp, #0x1d0]
    25bc:      	add.2d	v22, v22, v4
    25c0:      	add.2d	v22, v24, v22
    25c4:      	movi.2d	v27, #0000000000000000
    25c8:      	movi.2d	v28, #0000000000000000
    25cc:      	tbnz	w8, #0x0, 0x27ac <ltmp0+0x27ac>
    25d0:      	and	w8, w8, #0xff
    25d4:      	tbnz	w8, #0x1, 0x27bc <ltmp0+0x27bc>
    25d8:      	ldr	q22, [sp, #0x1e0]
    25dc:      	add.2d	v22, v22, v7
    25e0:      	add.2d	v22, v29, v22
    25e4:      	tbnz	w8, #0x2, 0x27d4 <ltmp0+0x27d4>
    25e8:      	tbnz	w8, #0x3, 0x27e0 <ltmp0+0x27e0>
    25ec:      	ldr	q22, [sp, #0x1f0]
    25f0:      	add.2d	v22, v22, v17
    25f4:      	ldr	q23, [sp, #0x2b0]
    25f8:      	add.2d	v22, v23, v22
    25fc:      	tbnz	w8, #0x4, 0x27fc <ltmp0+0x27fc>
    2600:      	tbnz	w8, #0x5, 0x2808 <ltmp0+0x2808>
    2604:      	ldr	q22, [sp, #0x1c0]
    2608:      	add.2d	v22, v22, v12
    260c:      	ldr	q23, [sp, #0x2c0]
    2610:      	add.2d	v22, v23, v22
    2614:      	tbnz	w8, #0x6, 0x2824 <ltmp0+0x2824>
    2618:      	tbz	w8, #0x7, 0x2624 <ltmp0+0x2624>
    261c:      	mov.d	x8, v22[1]
    2620:      	ld1.s	{ v28 }[3], [x8]
    2624:      	fmov	w8, s16
    2628:      	ldr	q22, [sp, #0x190]
    262c:      	add.2d	v4, v22, v4
    2630:      	add.2d	v4, v24, v4
    2634:      	movi.2d	v22, #0000000000000000
    2638:      	movi.2d	v23, #0000000000000000
    263c:      	tbnz	w8, #0x0, 0x2834 <ltmp0+0x2834>
    2640:      	and	w8, w8, #0xff
    2644:      	tbnz	w8, #0x1, 0x2844 <ltmp0+0x2844>
    2648:      	ldr	q4, [sp, #0x1a0]
    264c:      	add.2d	v4, v4, v7
    2650:      	add.2d	v4, v29, v4
    2654:      	tbnz	w8, #0x2, 0x285c <ltmp0+0x285c>
    2658:      	tbnz	w8, #0x3, 0x2868 <ltmp0+0x2868>
    265c:      	ldr	q4, [sp, #0x1b0]
    2660:      	add.2d	v4, v4, v17
    2664:      	ldr	q7, [sp, #0x2b0]
    2668:      	add.2d	v4, v7, v4
    266c:      	tbnz	w8, #0x4, 0x2884 <ltmp0+0x2884>
    2670:      	tbnz	w8, #0x5, 0x2890 <ltmp0+0x2890>
    2674:      	ldr	q4, [sp, #0x180]
    2678:      	add.2d	v4, v4, v12
    267c:      	ldr	q7, [sp, #0x2c0]
    2680:      	add.2d	v4, v7, v4
    2684:      	tbnz	w8, #0x6, 0x28ac <ltmp0+0x28ac>
    2688:      	tbz	w8, #0x7, 0x2424 <ltmp0+0x2424>
    268c:      	b	0x28b8 <ltmp0+0x28b8>
    2690:      	fmov	x9, d7
    2694:      	ldr	s21, [x9]
    2698:      	and	w8, w8, #0xff
    269c:      	tbz	w8, #0x1, 0x24ec <ltmp0+0x24ec>
    26a0:      	mov.d	x9, v7[1]
    26a4:      	ld1.s	{ v21 }[1], [x9]
    26a8:      	shl.2d	v7, v15, #0x5
    26ac:      	ldr	q17, [sp, #0x290]
    26b0:      	orr.16b	v17, v7, v17
    26b4:      	add.2d	v17, v29, v17
    26b8:      	tbz	w8, #0x2, 0x2500 <ltmp0+0x2500>
    26bc:      	fmov	x9, d17
    26c0:      	ld1.s	{ v21 }[2], [x9]
    26c4:      	tbz	w8, #0x3, 0x2504 <ltmp0+0x2504>
    26c8:      	mov.d	x9, v17[1]
    26cc:      	ld1.s	{ v21 }[3], [x9]
    26d0:      	shl.2d	v17, v10, #0x5
    26d4:      	ldr	q22, [sp, #0x280]
    26d8:      	orr.16b	v22, v17, v22
    26dc:      	ldr	q23, [sp, #0x2b0]
    26e0:      	add.2d	v22, v23, v22
    26e4:      	tbz	w8, #0x4, 0x251c <ltmp0+0x251c>
    26e8:      	fmov	x9, d22
    26ec:      	ld1.s	{ v6 }[0], [x9]
    26f0:      	tbz	w8, #0x5, 0x2520 <ltmp0+0x2520>
    26f4:      	mov.d	x9, v22[1]
    26f8:      	ld1.s	{ v6 }[1], [x9]
    26fc:      	shl.2d	v12, v9, #0x5
    2700:      	ldr	q22, [sp, #0x2a0]
    2704:      	orr.16b	v22, v12, v22
    2708:      	ldr	q23, [sp, #0x2c0]
    270c:      	add.2d	v22, v23, v22
    2710:      	tbz	w8, #0x6, 0x2538 <ltmp0+0x2538>
    2714:      	fmov	x9, d22
    2718:      	ld1.s	{ v6 }[2], [x9]
    271c:      	tbnz	w8, #0x7, 0x253c <ltmp0+0x253c>
    2720:      	b	0x2544 <ltmp0+0x2544>
    2724:      	fmov	x9, d22
    2728:      	ldr	s25, [x9]
    272c:      	and	w8, w8, #0xff
    2730:      	tbz	w8, #0x1, 0x2568 <ltmp0+0x2568>
    2734:      	mov.d	x9, v22[1]
    2738:      	ld1.s	{ v25 }[1], [x9]
    273c:      	ldr	q22, [sp, #0x220]
    2740:      	add.2d	v22, v22, v7
    2744:      	add.2d	v22, v29, v22
    2748:      	tbz	w8, #0x2, 0x2578 <ltmp0+0x2578>
    274c:      	fmov	x9, d22
    2750:      	ld1.s	{ v25 }[2], [x9]
    2754:      	tbz	w8, #0x3, 0x257c <ltmp0+0x257c>
    2758:      	mov.d	x9, v22[1]
    275c:      	ld1.s	{ v25 }[3], [x9]
    2760:      	ldr	q22, [sp, #0x230]
    2764:      	add.2d	v22, v22, v17
    2768:      	ldr	q23, [sp, #0x2b0]
    276c:      	add.2d	v22, v23, v22
    2770:      	tbz	w8, #0x4, 0x2590 <ltmp0+0x2590>
    2774:      	fmov	x9, d22
    2778:      	ld1.s	{ v26 }[0], [x9]
    277c:      	tbz	w8, #0x5, 0x2594 <ltmp0+0x2594>
    2780:      	mov.d	x9, v22[1]
    2784:      	ld1.s	{ v26 }[1], [x9]
    2788:      	ldr	q22, [sp, #0x200]
    278c:      	add.2d	v22, v22, v12
    2790:      	ldr	q23, [sp, #0x2c0]
    2794:      	add.2d	v22, v23, v22
    2798:      	tbz	w8, #0x6, 0x25a8 <ltmp0+0x25a8>
    279c:      	fmov	x9, d22
    27a0:      	ld1.s	{ v26 }[2], [x9]
    27a4:      	tbnz	w8, #0x7, 0x25ac <ltmp0+0x25ac>
    27a8:      	b	0x25b4 <ltmp0+0x25b4>
    27ac:      	fmov	x9, d22
    27b0:      	ldr	s27, [x9]
    27b4:      	and	w8, w8, #0xff
    27b8:      	tbz	w8, #0x1, 0x25d8 <ltmp0+0x25d8>
    27bc:      	mov.d	x9, v22[1]
    27c0:      	ld1.s	{ v27 }[1], [x9]
    27c4:      	ldr	q22, [sp, #0x1e0]
    27c8:      	add.2d	v22, v22, v7
    27cc:      	add.2d	v22, v29, v22
    27d0:      	tbz	w8, #0x2, 0x25e8 <ltmp0+0x25e8>
    27d4:      	fmov	x9, d22
    27d8:      	ld1.s	{ v27 }[2], [x9]
    27dc:      	tbz	w8, #0x3, 0x25ec <ltmp0+0x25ec>
    27e0:      	mov.d	x9, v22[1]
    27e4:      	ld1.s	{ v27 }[3], [x9]
    27e8:      	ldr	q22, [sp, #0x1f0]
    27ec:      	add.2d	v22, v22, v17
    27f0:      	ldr	q23, [sp, #0x2b0]
    27f4:      	add.2d	v22, v23, v22
    27f8:      	tbz	w8, #0x4, 0x2600 <ltmp0+0x2600>
    27fc:      	fmov	x9, d22
    2800:      	ld1.s	{ v28 }[0], [x9]
    2804:      	tbz	w8, #0x5, 0x2604 <ltmp0+0x2604>
    2808:      	mov.d	x9, v22[1]
    280c:      	ld1.s	{ v28 }[1], [x9]
    2810:      	ldr	q22, [sp, #0x1c0]
    2814:      	add.2d	v22, v22, v12
    2818:      	ldr	q23, [sp, #0x2c0]
    281c:      	add.2d	v22, v23, v22
    2820:      	tbz	w8, #0x6, 0x2618 <ltmp0+0x2618>
    2824:      	fmov	x9, d22
    2828:      	ld1.s	{ v28 }[2], [x9]
    282c:      	tbnz	w8, #0x7, 0x261c <ltmp0+0x261c>
    2830:      	b	0x2624 <ltmp0+0x2624>
    2834:      	fmov	x9, d4
    2838:      	ldr	s22, [x9]
    283c:      	and	w8, w8, #0xff
    2840:      	tbz	w8, #0x1, 0x2648 <ltmp0+0x2648>
    2844:      	mov.d	x9, v4[1]
    2848:      	ld1.s	{ v22 }[1], [x9]
    284c:      	ldr	q4, [sp, #0x1a0]
    2850:      	add.2d	v4, v4, v7
    2854:      	add.2d	v4, v29, v4
    2858:      	tbz	w8, #0x2, 0x2658 <ltmp0+0x2658>
    285c:      	fmov	x9, d4
    2860:      	ld1.s	{ v22 }[2], [x9]
    2864:      	tbz	w8, #0x3, 0x265c <ltmp0+0x265c>
    2868:      	mov.d	x9, v4[1]
    286c:      	ld1.s	{ v22 }[3], [x9]
    2870:      	ldr	q4, [sp, #0x1b0]
    2874:      	add.2d	v4, v4, v17
    2878:      	ldr	q7, [sp, #0x2b0]
    287c:      	add.2d	v4, v7, v4
    2880:      	tbz	w8, #0x4, 0x2670 <ltmp0+0x2670>
    2884:      	fmov	x9, d4
    2888:      	ld1.s	{ v23 }[0], [x9]
    288c:      	tbz	w8, #0x5, 0x2674 <ltmp0+0x2674>
    2890:      	mov.d	x9, v4[1]
    2894:      	ld1.s	{ v23 }[1], [x9]
    2898:      	ldr	q4, [sp, #0x180]
    289c:      	add.2d	v4, v4, v12
    28a0:      	ldr	q7, [sp, #0x2c0]
    28a4:      	add.2d	v4, v7, v4
    28a8:      	tbz	w8, #0x6, 0x2688 <ltmp0+0x2688>
    28ac:      	fmov	x9, d4
    28b0:      	ld1.s	{ v23 }[2], [x9]
    28b4:      	tbz	w8, #0x7, 0x2424 <ltmp0+0x2424>
    28b8:      	mov.d	x8, v4[1]
    28bc:      	ld1.s	{ v23 }[3], [x8]
    28c0:      	b	0x2424 <ltmp0+0x2424>
    28c4:      	str	x14, [sp, #0x220]
    28c8:      	str	x16, [sp, #0x230]
    28cc:      	mov	x8, #0x0                ; =0
    28d0:      	ldr	q2, [sp, #0x24f0]
    28d4:      	str	q2, [sp, #0x200]
    28d8:      	ldr	q2, [sp, #0x24e0]
    28dc:      	str	q2, [sp, #0x1f0]
    28e0:      	ldr	q2, [sp, #0x2510]
    28e4:      	str	q2, [sp, #0x210]
    28e8:      	ldr	q2, [sp, #0x240]
    28ec:      	and.16b	v10, v2, v0
    28f0:      	ldr	q2, [sp, #0x250]
    28f4:      	and.16b	v2, v2, v0
    28f8:      	sshll.2d	v21, v13, #0x0
    28fc:      	and.16b	v30, v21, v0
    2900:      	sshll.2d	v21, v14, #0x0
    2904:      	and.16b	v31, v21, v0
    2908:      	dup.2d	v21, x27
    290c:      	ldr	q22, [sp, #0x2500]
    2910:      	str	q22, [sp, #0x1e0]
    2914:      	ldr	q23, [sp, #0x2530]
    2918:      	ldr	q22, [sp, #0x2520]
    291c:      	stp	q22, q23, [sp, #0x240]
    2920:      	ushll2.2d	v22, v13, #0x0
    2924:      	and.16b	v8, v22, v21
    2928:      	ushll2.2d	v22, v14, #0x0
    292c:      	and.16b	v9, v22, v21
    2930:      	ushll.2d	v22, v13, #0x0
    2934:      	and.16b	v11, v22, v21
    2938:      	ushll.2d	v22, v14, #0x0
    293c:      	and.16b	v15, v22, v21
    2940:      	movi.2d	v21, #0000000000000000
    2944:      	movi.2d	v25, #0000000000000000
    2948:      	movi.2d	v26, #0000000000000000
    294c:      	movi.2d	v27, #0000000000000000
    2950:      	b	0x2970 <ltmp0+0x2970>
    2954:      	add.2d	v25, v25, v9
    2958:      	add.2d	v26, v26, v11
    295c:      	add.2d	v27, v27, v8
    2960:      	add.2d	v21, v21, v15
    2964:      	fmov	x8, d21
    2968:      	cmp	x8, #0x7f
    296c:      	b.ge	0x2b18 <ltmp0+0x2b18>
    2970:      	fmov	w9, s16
    2974:      	add	x8, x12, x8, lsl #5
    2978:      	movi.2d	v12, #0000000000000000
    297c:      	movi.2d	v28, #0000000000000000
    2980:      	tbnz	w9, #0x0, 0x2a10 <ltmp0+0x2a10>
    2984:      	and	w9, w9, #0xff
    2988:      	tbnz	w9, #0x1, 0x2a1c <ltmp0+0x2a1c>
    298c:      	tbnz	w9, #0x2, 0x2a28 <ltmp0+0x2a28>
    2990:      	tbnz	w9, #0x3, 0x2a34 <ltmp0+0x2a34>
    2994:      	tbnz	w9, #0x4, 0x2a40 <ltmp0+0x2a40>
    2998:      	tbnz	w9, #0x5, 0x2a4c <ltmp0+0x2a4c>
    299c:      	tbnz	w9, #0x6, 0x2a58 <ltmp0+0x2a58>
    29a0:      	tbnz	w9, #0x7, 0x2a64 <ltmp0+0x2a64>
    29a4:      	fmov	w8, s16
    29a8:      	shl.2d	v22, v21, #0x5
    29ac:      	ldr	q23, [sp, #0x270]
    29b0:      	orr.16b	v22, v22, v23
    29b4:      	add.2d	v22, v31, v22
    29b8:      	tbnz	w8, #0x0, 0x2a84 <ltmp0+0x2a84>
    29bc:      	and	w8, w8, #0xff
    29c0:      	tbnz	w8, #0x1, 0x2a94 <ltmp0+0x2a94>
    29c4:      	shl.2d	v22, v25, #0x5
    29c8:      	ldr	q23, [sp, #0x290]
    29cc:      	orr.16b	v22, v22, v23
    29d0:      	add.2d	v22, v2, v22
    29d4:      	tbnz	w8, #0x2, 0x2ab0 <ltmp0+0x2ab0>
    29d8:      	tbnz	w8, #0x3, 0x2abc <ltmp0+0x2abc>
    29dc:      	shl.2d	v22, v26, #0x5
    29e0:      	ldr	q23, [sp, #0x280]
    29e4:      	orr.16b	v22, v22, v23
    29e8:      	add.2d	v22, v30, v22
    29ec:      	tbnz	w8, #0x4, 0x2ad8 <ltmp0+0x2ad8>
    29f0:      	tbnz	w8, #0x5, 0x2ae4 <ltmp0+0x2ae4>
    29f4:      	shl.2d	v22, v27, #0x5
    29f8:      	ldr	q23, [sp, #0x2a0]
    29fc:      	orr.16b	v22, v22, v23
    2a00:      	add.2d	v22, v10, v22
    2a04:      	tbnz	w8, #0x6, 0x2b00 <ltmp0+0x2b00>
    2a08:      	tbz	w8, #0x7, 0x2954 <ltmp0+0x2954>
    2a0c:      	b	0x2b0c <ltmp0+0x2b0c>
    2a10:      	ldr	s12, [x8]
    2a14:      	and	w9, w9, #0xff
    2a18:      	tbz	w9, #0x1, 0x298c <ltmp0+0x298c>
    2a1c:      	add	x11, x8, #0x4
    2a20:      	ld1.s	{ v12 }[1], [x11]
    2a24:      	tbz	w9, #0x2, 0x2990 <ltmp0+0x2990>
    2a28:      	add	x11, x8, #0x8
    2a2c:      	ld1.s	{ v12 }[2], [x11]
    2a30:      	tbz	w9, #0x3, 0x2994 <ltmp0+0x2994>
    2a34:      	add	x11, x8, #0xc
    2a38:      	ld1.s	{ v12 }[3], [x11]
    2a3c:      	tbz	w9, #0x4, 0x2998 <ltmp0+0x2998>
    2a40:      	add	x11, x8, #0x10
    2a44:      	ld1.s	{ v28 }[0], [x11]
    2a48:      	tbz	w9, #0x5, 0x299c <ltmp0+0x299c>
    2a4c:      	add	x11, x8, #0x14
    2a50:      	ld1.s	{ v28 }[1], [x11]
    2a54:      	tbz	w9, #0x6, 0x29a0 <ltmp0+0x29a0>
    2a58:      	add	x11, x8, #0x18
    2a5c:      	ld1.s	{ v28 }[2], [x11]
    2a60:      	tbz	w9, #0x7, 0x29a4 <ltmp0+0x29a4>
    2a64:      	add	x8, x8, #0x1c
    2a68:      	ld1.s	{ v28 }[3], [x8]
    2a6c:      	fmov	w8, s16
    2a70:      	shl.2d	v22, v21, #0x5
    2a74:      	ldr	q23, [sp, #0x270]
    2a78:      	orr.16b	v22, v22, v23
    2a7c:      	add.2d	v22, v31, v22
    2a80:      	tbz	w8, #0x0, 0x29bc <ltmp0+0x29bc>
    2a84:      	fmov	x9, d22
    2a88:      	str	s12, [x9]
    2a8c:      	and	w8, w8, #0xff
    2a90:      	tbz	w8, #0x1, 0x29c4 <ltmp0+0x29c4>
    2a94:      	mov.d	x9, v22[1]
    2a98:      	st1.s	{ v12 }[1], [x9]
    2a9c:      	shl.2d	v22, v25, #0x5
    2aa0:      	ldr	q23, [sp, #0x290]
    2aa4:      	orr.16b	v22, v22, v23
    2aa8:      	add.2d	v22, v2, v22
    2aac:      	tbz	w8, #0x2, 0x29d8 <ltmp0+0x29d8>
    2ab0:      	fmov	x9, d22
    2ab4:      	st1.s	{ v12 }[2], [x9]
    2ab8:      	tbz	w8, #0x3, 0x29dc <ltmp0+0x29dc>
    2abc:      	mov.d	x9, v22[1]
    2ac0:      	st1.s	{ v12 }[3], [x9]
    2ac4:      	shl.2d	v22, v26, #0x5
    2ac8:      	ldr	q23, [sp, #0x280]
    2acc:      	orr.16b	v22, v22, v23
    2ad0:      	add.2d	v22, v30, v22
    2ad4:      	tbz	w8, #0x4, 0x29f0 <ltmp0+0x29f0>
    2ad8:      	fmov	x9, d22
    2adc:      	str	s28, [x9]
    2ae0:      	tbz	w8, #0x5, 0x29f4 <ltmp0+0x29f4>
    2ae4:      	mov.d	x9, v22[1]
    2ae8:      	st1.s	{ v28 }[1], [x9]
    2aec:      	shl.2d	v22, v27, #0x5
    2af0:      	ldr	q23, [sp, #0x2a0]
    2af4:      	orr.16b	v22, v22, v23
    2af8:      	add.2d	v22, v10, v22
    2afc:      	tbz	w8, #0x6, 0x2a08 <ltmp0+0x2a08>
    2b00:      	fmov	x9, d22
    2b04:      	st1.s	{ v28 }[2], [x9]
    2b08:      	tbz	w8, #0x7, 0x2954 <ltmp0+0x2954>
    2b0c:      	mov.d	x8, v22[1]
    2b10:      	st1.s	{ v28 }[3], [x8]
    2b14:      	b	0x2954 <ltmp0+0x2954>
    2b18:      	ldp	q21, q22, [sp, #0x1f0]
    2b1c:      	and.16b	v21, v14, v21
    2b20:      	and.16b	v22, v13, v22
    2b24:      	fmul.4s	v22, v22, v22
    2b28:      	fmul.4s	v21, v21, v21
    2b2c:      	fadd.4s	v20, v20, v21
    2b30:      	fadd.4s	v19, v19, v22
    2b34:      	ldr	q21, [sp, #0x210]
    2b38:      	and.16b	v21, v13, v21
    2b3c:      	ldr	q22, [sp, #0x1e0]
    2b40:      	and.16b	v22, v14, v22
    2b44:      	fmul.4s	v22, v22, v22
    2b48:      	fmul.4s	v21, v21, v21
    2b4c:      	fadd.4s	v17, v17, v21
    2b50:      	fadd.4s	v7, v7, v22
    2b54:      	and.16b	v7, v14, v7
    2b58:      	and.16b	v17, v13, v17
    2b5c:      	ldp	q21, q22, [sp, #0x240]
    2b60:      	and.16b	v21, v14, v21
    2b64:      	and.16b	v22, v13, v22
    2b68:      	fmul.4s	v22, v22, v22
    2b6c:      	fmul.4s	v21, v21, v21
    2b70:      	fadd.4s	v4, v4, v21
    2b74:      	fadd.4s	v6, v6, v22
    2b78:      	and.16b	v6, v13, v6
    2b7c:      	and.16b	v4, v14, v4
    2b80:      	ldp	q22, q21, [sp, #0x10]
    2b84:      	fmul.4s	v21, v21, v21
    2b88:      	fmul.4s	v22, v22, v22
    2b8c:      	fadd.4s	v22, v22, v19
    2b90:      	fadd.4s	v20, v21, v20
    2b94:      	ldr	q28, [sp, #0x140]
    2b98:      	zip1.8b	v21, v28, v0
    2b9c:      	ushll.4s	v21, v21, #0x0
    2ba0:      	shl.4s	v21, v21, #0x1f
    2ba4:      	cmlt.4s	v21, v21, #0
    2ba8:      	and.16b	v20, v21, v20
    2bac:      	zip2.8b	v21, v28, v0
    2bb0:      	ushll.4s	v21, v21, #0x0
    2bb4:      	shl.4s	v21, v21, #0x1f
    2bb8:      	cmlt.4s	v21, v21, #0
    2bbc:      	movi.2d	v23, #0000000000000000
    2bc0:      	ldr	q25, [sp, #0x70]
    2bc4:      	mov.b	v23[6], v25[7]
    2bc8:      	and.16b	v21, v21, v22
    2bcc:      	ushll.4s	v22, v23, #0x0
    2bd0:      	shl.4s	v22, v22, #0x1f
    2bd4:      	cmlt.4s	v22, v22, #0
    2bd8:      	bif.16b	v19, v21, v22
    2bdc:      	fadd.4s	v17, v17, v19
    2be0:      	fadd.4s	v7, v7, v20
    2be4:      	fadd.4s	v7, v4, v7
    2be8:      	fadd.4s	v4, v6, v17
    2bec:      	fadd.4s	v4, v18, v4
    2bf0:      	fadd.4s	v6, v5, v7
    2bf4:      	ldp	q7, q5, [sp, #0x30]
    2bf8:      	uzp1.4s	v5, v7, v5
    2bfc:      	ldp	q17, q7, [sp, #0x50]
    2c00:      	uzp1.4s	v7, v17, v7
    2c04:      	movi.4s	v18, #0x1
    2c08:      	eor.16b	v17, v5, v18
    2c0c:      	mov.s	w9, v17[1]
    2c10:      	mov.s	w11, v17[2]
    2c14:      	eor.16b	v20, v7, v18
    2c18:      	mov.s	w16, v17[3]
    2c1c:      	fmov	w8, s17
    2c20:      	add	x13, sp, #0x318
    2c24:      	bfxil	x13, x8, #0, #3
    2c28:      	str	d25, [sp, #0x318]
    2c2c:      	ldrb	w14, [x13]
    2c30:      	and	x13, x8, #0x7
    2c34:      	umov.b	w8, v25[0]
    2c38:      	str	q6, [sp, #0x420]
    2c3c:      	str	q4, [sp, #0x430]
    2c40:      	add	x17, sp, #0x420
    2c44:      	ldr	s17, [x17, x13, lsl #2]
    2c48:      	ands	w13, w8, #0x1
    2c4c:      	tst	w13, w14
    2c50:      	movi	d26, #0000000000000000
    2c54:      	fcsel	s17, s17, s26, ne
    2c58:      	add	x14, sp, #0x318
    2c5c:      	bfxil	x14, x9, #0, #3
    2c60:      	ldrb	w14, [x14]
    2c64:      	and	x17, x9, #0x7
    2c68:      	umov.b	w9, v25[1]
    2c6c:      	str	q6, [sp, #0x400]
    2c70:      	str	q4, [sp, #0x410]
    2c74:      	add	x0, sp, #0x400
    2c78:      	ldr	s18, [x0, x17, lsl #2]
    2c7c:      	ands	w17, w9, #0x1
    2c80:      	tst	w17, w14
    2c84:      	fcsel	s18, s18, s26, ne
    2c88:      	add	x14, sp, #0x318
    2c8c:      	bfxil	x14, x11, #0, #3
    2c90:      	ldrb	w17, [x14]
    2c94:      	umov.b	w14, v25[2]
    2c98:      	and	x11, x11, #0x7
    2c9c:      	stp	q6, q4, [sp, #0x3e0]
    2ca0:      	add	x0, sp, #0x3e0
    2ca4:      	ldr	s19, [x0, x11, lsl #2]
    2ca8:      	ands	w11, w14, #0x1
    2cac:      	tst	w11, w17
    2cb0:      	fcsel	s19, s19, s26, ne
    2cb4:      	add	x11, sp, #0x318
    2cb8:      	bfxil	x11, x16, #0, #3
    2cbc:      	ldrb	w11, [x11]
    2cc0:      	and	x16, x16, #0x7
    2cc4:      	umov.b	w0, v25[3]
    2cc8:      	stp	q6, q4, [sp, #0x3c0]
    2ccc:      	add	x17, sp, #0x3c0
    2cd0:      	ldr	s21, [x17, x16, lsl #2]
    2cd4:      	ands	w16, w0, #0x1
    2cd8:      	tst	w16, w11
    2cdc:      	mov.s	w11, v20[1]
    2ce0:      	mov.s	w16, v20[2]
    2ce4:      	fcsel	s21, s21, s26, ne
    2ce8:      	mov.s	w17, v20[3]
    2cec:      	fmov	w2, s20
    2cf0:      	and	x4, x2, #0x7
    2cf4:      	add	x5, sp, #0x318
    2cf8:      	bfxil	x5, x2, #0, #3
    2cfc:      	ldrb	w2, [x5]
    2d00:      	umov.b	w28, v25[4]
    2d04:      	and	w2, w28, w2
    2d08:      	str	q6, [sp, #0x4a0]
    2d0c:      	str	q4, [sp, #0x4b0]
    2d10:      	add	x5, sp, #0x4a0
    2d14:      	ldr	s20, [x5, x4, lsl #2]
    2d18:      	tst	w2, #0x1
    2d1c:      	fcsel	s20, s20, s26, ne
    2d20:      	add	x2, sp, #0x318
    2d24:      	bfxil	x2, x11, #0, #3
    2d28:      	ldrb	w2, [x2]
    2d2c:      	and	x11, x11, #0x7
    2d30:      	umov.b	w30, v25[5]
    2d34:      	str	q6, [sp, #0x480]
    2d38:      	str	q4, [sp, #0x490]
    2d3c:      	add	x4, sp, #0x480
    2d40:      	ldr	s22, [x4, x11, lsl #2]
    2d44:      	ands	w11, w30, #0x1
    2d48:      	tst	w11, w2
    2d4c:      	fcsel	s22, s22, s26, ne
    2d50:      	add	x11, sp, #0x318
    2d54:      	bfxil	x11, x16, #0, #3
    2d58:      	ldrb	w2, [x11]
    2d5c:      	and	x16, x16, #0x7
    2d60:      	umov.b	w11, v25[6]
    2d64:      	str	q6, [sp, #0x460]
    2d68:      	str	q4, [sp, #0x470]
    2d6c:      	add	x4, sp, #0x460
    2d70:      	ldr	s23, [x4, x16, lsl #2]
    2d74:      	ands	w16, w11, #0x1
    2d78:      	tst	w16, w2
    2d7c:      	fcsel	s23, s23, s26, ne
    2d80:      	add	x16, sp, #0x318
    2d84:      	bfxil	x16, x17, #0, #3
    2d88:      	ldrb	w16, [x16]
    2d8c:      	umov.b	w2, v25[7]
    2d90:      	and	x17, x17, #0x7
    2d94:      	str	q6, [sp, #0x440]
    2d98:      	str	q4, [sp, #0x450]
    2d9c:      	add	x4, sp, #0x440
    2da0:      	ldr	s25, [x4, x17, lsl #2]
    2da4:      	ands	w17, w2, #0x1
    2da8:      	tst	w17, w16
    2dac:      	fcsel	s25, s25, s26, ne
    2db0:      	mov.s	v20[1], v22[0]
    2db4:      	mov.s	v20[2], v23[0]
    2db8:      	mov.s	v20[3], v25[0]
    2dbc:      	mov.s	v17[1], v18[0]
    2dc0:      	mov.s	v17[2], v19[0]
    2dc4:      	mov.s	v17[3], v21[0]
    2dc8:      	fadd.4s	v6, v6, v17
    2dcc:      	fadd.4s	v4, v4, v20
    2dd0:      	movi.4s	v17, #0x2
    2dd4:      	eor.16b	v7, v7, v17
    2dd8:      	eor.16b	v5, v5, v17
    2ddc:      	fmov	w16, s5
    2de0:      	add	x17, sp, #0x318
    2de4:      	bfxil	x17, x16, #0, #3
    2de8:      	ldrb	w17, [x17]
    2dec:      	and	x16, x16, #0x7
    2df0:      	stp	q6, q4, [sp, #0x3a0]
    2df4:      	add	x4, sp, #0x3a0
    2df8:      	ldr	s5, [x4, x16, lsl #2]
    2dfc:      	tst	w13, w17
    2e00:      	fcsel	s5, s5, s26, ne
    2e04:      	fmov	w16, s7
    2e08:      	and	x17, x16, #0x7
    2e0c:      	add	x4, sp, #0x318
    2e10:      	bfxil	x4, x16, #0, #3
    2e14:      	ldrb	w16, [x4]
    2e18:      	and	w16, w28, w16
    2e1c:      	stp	q6, q4, [sp, #0x380]
    2e20:      	add	x4, sp, #0x380
    2e24:      	ldr	s7, [x4, x17, lsl #2]
    2e28:      	tst	w16, #0x1
    2e2c:      	fcsel	s7, s7, s26, ne
    2e30:      	fadd.4s	v4, v4, v7
    2e34:      	tst	w13, w28
    2e38:      	fcsel	s4, s4, s26, ne
    2e3c:      	ands	w8, w8, #0x1
    2e40:      	fadd.4s	v5, v6, v5
    2e44:      	fadd	s4, s5, s4
    2e48:      	fcsel	s5, s4, s26, ne
    2e4c:      	tst	w9, #0x1
    2e50:      	fcsel	s6, s5, s26, ne
    2e54:      	tst	w14, #0x1
    2e58:      	fcsel	s7, s5, s26, ne
    2e5c:      	tst	w0, #0x1
    2e60:      	fcsel	s17, s5, s26, ne
    2e64:      	tst	w8, w28
    2e68:      	fcsel	s18, s4, s26, ne
    2e6c:      	tst	w30, #0x1
    2e70:      	fcsel	s19, s5, s26, ne
    2e74:      	tst	w11, #0x1
    2e78:      	fcsel	s20, s5, s26, ne
    2e7c:      	tst	w2, #0x1
    2e80:      	shl.8b	v4, v28, #0x7
    2e84:      	cmlt.8b	v4, v4, #0
    2e88:      	ldr	d21, [sp, #0x88]
    2e8c:      	and.8b	v4, v4, v21
    2e90:      	addv.8b	b4, v4
    2e94:      	fmov	w8, s4
    2e98:      	fcsel	s21, s5, s26, ne
    2e9c:      	mov.s	v5[1], v6[0]
    2ea0:      	mov.s	v5[2], v7[0]
    2ea4:      	mov.s	v5[3], v17[0]
    2ea8:      	mov.s	v18[1], v19[0]
    2eac:      	mov.s	v18[2], v20[0]
    2eb0:      	mov.s	v18[3], v21[0]
    2eb4:      	ldr	w9, [sp, #0xec]
    2eb8:      	rbit	w9, w9
    2ebc:      	clz	w9, w9
    2ec0:      	stp	q5, q18, [sp, #0x360]
    2ec4:      	and	x9, x9, #0x7
    2ec8:      	add	x11, sp, #0x360
    2ecc:      	ldr	s5, [x11, x9, lsl #2]
    2ed0:      	mov	b6, v28[0]
    2ed4:      	mov.b	v6[4], v28[1]
    2ed8:      	ushll.2d	v6, v6, #0x0
    2edc:      	shl.2d	v6, v6, #0x3f
    2ee0:      	cmlt.2d	v6, v6, #0
    2ee4:      	mov	b7, v28[2]
    2ee8:      	mov.b	v7[4], v28[3]
    2eec:      	ldp	q18, q17, [sp, #0xa0]
    2ef0:      	and.16b	v6, v6, v18
    2ef4:      	ushll.2d	v7, v7, #0x0
    2ef8:      	shl.2d	v7, v7, #0x3f
    2efc:      	cmlt.2d	v7, v7, #0
    2f00:      	and.16b	v7, v7, v17
    2f04:      	mov	b17, v28[4]
    2f08:      	mov.b	v17[4], v28[5]
    2f0c:      	ushll.2d	v17, v17, #0x0
    2f10:      	shl.2d	v17, v17, #0x3f
    2f14:      	cmlt.2d	v17, v17, #0
    2f18:      	ldp	q18, q19, [sp, #0xc0]
    2f1c:      	and.16b	v17, v17, v18
    2f20:      	mov	b18, v28[6]
    2f24:      	mov.b	v18[4], v28[7]
    2f28:      	ushll.2d	v18, v18, #0x0
    2f2c:      	shl.2d	v18, v18, #0x3f
    2f30:      	cmlt.2d	v18, v18, #0
    2f34:      	and.16b	v18, v18, v19
    2f38:      	stp	q17, q18, [sp, #0x340]
    2f3c:      	stp	q6, q7, [sp, #0x320]
    2f40:      	ldr	x30, [sp, #0x220]
    2f44:      	and	x9, x30, #0x7
    2f48:      	add	x11, sp, #0x320
    2f4c:      	ldr	x9, [x11, x9, lsl #3]
    2f50:      	sub	x9, x9, x30
    2f54:      	add	x9, x12, x9, lsl #2
    2f58:      	movi.2d	v6, #0000000000000000
    2f5c:      	movi.2d	v7, #0000000000000000
    2f60:      	tbz	w8, #0x0, 0x2f68 <ltmp0+0x2f68>
    2f64:      	ldr	s6, [x9]
    2f68:      	ldr	w13, [sp, #0x174]
    2f6c:      	ldr	x2, [sp, #0x230]
    2f70:      	tbz	w8, #0x1, 0x2f7c <ltmp0+0x2f7c>
    2f74:      	add	x11, x9, #0x4
    2f78:      	ld1.s	{ v6 }[1], [x11]
    2f7c:      	ldr	w16, [sp, #0x16c]
    2f80:      	mov	w17, #0xffc             ; =4092
    2f84:      	adrp	x5, 0x2000 <ltmp0+0x2000>
    2f88:      	adrp	x4, 0x2000 <ltmp0+0x2000>
    2f8c:      	ldr	w14, [sp, #0x170]
    2f90:      	ldr	x0, [sp, #0x178]
    2f94:      	tbnz	w8, #0x2, 0x33f0 <ltmp0+0x33f0>
    2f98:      	tbnz	w8, #0x3, 0x33fc <ltmp0+0x33fc>
    2f9c:      	tbnz	w8, #0x4, 0x3408 <ltmp0+0x3408>
    2fa0:      	tbnz	w8, #0x5, 0x3414 <ltmp0+0x3414>
    2fa4:      	tbnz	w8, #0x6, 0x3420 <ltmp0+0x3420>
    2fa8:      	tbz	w8, #0x7, 0x2fb4 <ltmp0+0x2fb4>
    2fac:      	add	x8, x9, #0x1c
    2fb0:      	ld1.s	{ v7 }[3], [x8]
    2fb4:      	mov	x9, #0x0                ; =0
    2fb8:      	movi	d17, #0000000000000000
    2fbc:      	fadd	s5, s5, s17
    2fc0:      	mov	w8, #0xc000             ; =49152
    2fc4:      	movk	w8, #0x447f, lsl #16
    2fc8:      	fmov	s17, w8
    2fcc:      	fdiv	s5, s5, s17
    2fd0:      	add	x8, sp, #0x560
    2fd4:      	add	x8, x8, x3
    2fd8:      	ldp	q17, q18, [x8]
    2fdc:      	zip2.8b	v19, v28, v0
    2fe0:      	ushll.4s	v19, v19, #0x0
    2fe4:      	shl.4s	v19, v19, #0x1f
    2fe8:      	cmlt.4s	v19, v19, #0
    2fec:      	bif.16b	v7, v18, v19
    2ff0:      	zip1.8b	v18, v28, v0
    2ff4:      	ushll.4s	v18, v18, #0x0
    2ff8:      	shl.4s	v18, v18, #0x1f
    2ffc:      	cmlt.4s	v18, v18, #0
    3000:      	bif.16b	v6, v17, v18
    3004:      	stp	q6, q7, [x8]
    3008:      	mov	w8, #0xc5ac             ; =50604
    300c:      	movk	w8, #0x3727, lsl #16
    3010:      	fmov	s6, w8
    3014:      	fadd	s5, s5, s6
    3018:      	fsqrt	s5, s5
    301c:      	dup.4s	v5, v5[0]
    3020:      	ldr	q6, [sp, #0x90]
    3024:      	fmov	x8, d6
    3028:      	add	x8, x2, x8, lsl #2
    302c:      	movi.2d	v6, #0000000000000000
    3030:      	movi.2d	v7, #0000000000000000
    3034:      	movi.2d	v17, #0000000000000000
    3038:      	movi.2d	v18, #0000000000000000
    303c:      	b	0x305c <ltmp0+0x305c>
    3040:      	add.2d	v7, v7, v9
    3044:      	add.2d	v17, v17, v11
    3048:      	add.2d	v18, v18, v8
    304c:      	add.2d	v6, v6, v15
    3050:      	fmov	x9, d6
    3054:      	cmp	x9, #0x7f
    3058:      	b.ge	0x32e4 <ltmp0+0x32e4>
    305c:      	fmov	w11, s16
    3060:      	shl.2d	v19, v6, #0x5
    3064:      	ldr	q20, [sp, #0x270]
    3068:      	orr.16b	v21, v19, v20
    306c:      	add.2d	v22, v24, v21
    3070:      	movi.2d	v20, #0000000000000000
    3074:      	movi.2d	v19, #0000000000000000
    3078:      	tbnz	w11, #0x0, 0x3154 <ltmp0+0x3154>
    307c:      	and	w11, w11, #0xff
    3080:      	tbnz	w11, #0x1, 0x3164 <ltmp0+0x3164>
    3084:      	shl.2d	v22, v7, #0x5
    3088:      	ldr	q23, [sp, #0x290]
    308c:      	orr.16b	v22, v22, v23
    3090:      	add.2d	v23, v29, v22
    3094:      	tbnz	w11, #0x2, 0x3180 <ltmp0+0x3180>
    3098:      	tbnz	w11, #0x3, 0x318c <ltmp0+0x318c>
    309c:      	shl.2d	v23, v17, #0x5
    30a0:      	ldr	q25, [sp, #0x280]
    30a4:      	orr.16b	v23, v23, v25
    30a8:      	ldr	q25, [sp, #0x2b0]
    30ac:      	add.2d	v25, v25, v23
    30b0:      	tbnz	w11, #0x4, 0x31ac <ltmp0+0x31ac>
    30b4:      	tbnz	w11, #0x5, 0x31b8 <ltmp0+0x31b8>
    30b8:      	shl.2d	v25, v18, #0x5
    30bc:      	ldr	q26, [sp, #0x2a0]
    30c0:      	orr.16b	v25, v25, v26
    30c4:      	ldr	q26, [sp, #0x2c0]
    30c8:      	add.2d	v26, v26, v25
    30cc:      	tbnz	w11, #0x6, 0x31d8 <ltmp0+0x31d8>
    30d0:      	tbnz	w11, #0x7, 0x31e4 <ltmp0+0x31e4>
    30d4:      	fmov	w11, s16
    30d8:      	add.2d	v27, v31, v21
    30dc:      	movi.2d	v26, #0000000000000000
    30e0:      	movi.2d	v21, #0000000000000000
    30e4:      	tbnz	w11, #0x0, 0x3200 <ltmp0+0x3200>
    30e8:      	and	w11, w11, #0xff
    30ec:      	tbnz	w11, #0x1, 0x3210 <ltmp0+0x3210>
    30f0:      	add.2d	v22, v2, v22
    30f4:      	tbnz	w11, #0x2, 0x3220 <ltmp0+0x3220>
    30f8:      	tbnz	w11, #0x3, 0x322c <ltmp0+0x322c>
    30fc:      	add.2d	v22, v30, v23
    3100:      	tbnz	w11, #0x4, 0x323c <ltmp0+0x323c>
    3104:      	tbnz	w11, #0x5, 0x3248 <ltmp0+0x3248>
    3108:      	add.2d	v22, v10, v25
    310c:      	tbnz	w11, #0x6, 0x3258 <ltmp0+0x3258>
    3110:      	tbnz	w11, #0x7, 0x3264 <ltmp0+0x3264>
    3114:      	fdiv.4s	v20, v20, v5
    3118:      	fmov	w11, s16
    311c:      	fmul.4s	v20, v20, v26
    3120:      	add	x9, x8, x9, lsl #5
    3124:      	tbnz	w11, #0x0, 0x3280 <ltmp0+0x3280>
    3128:      	and	w11, w11, #0xff
    312c:      	tbnz	w11, #0x1, 0x328c <ltmp0+0x328c>
    3130:      	tbnz	w11, #0x2, 0x3298 <ltmp0+0x3298>
    3134:      	tbnz	w11, #0x3, 0x32a4 <ltmp0+0x32a4>
    3138:      	fdiv.4s	v19, v19, v5
    313c:      	fmul.4s	v19, v19, v21
    3140:      	tbnz	w11, #0x4, 0x32b8 <ltmp0+0x32b8>
    3144:      	tbnz	w11, #0x5, 0x32c0 <ltmp0+0x32c0>
    3148:      	tbnz	w11, #0x6, 0x32cc <ltmp0+0x32cc>
    314c:      	tbz	w11, #0x7, 0x3040 <ltmp0+0x3040>
    3150:      	b	0x32d8 <ltmp0+0x32d8>
    3154:      	fmov	x12, d22
    3158:      	ldr	s20, [x12]
    315c:      	and	w11, w11, #0xff
    3160:      	tbz	w11, #0x1, 0x3084 <ltmp0+0x3084>
    3164:      	mov.d	x12, v22[1]
    3168:      	ld1.s	{ v20 }[1], [x12]
    316c:      	shl.2d	v22, v7, #0x5
    3170:      	ldr	q23, [sp, #0x290]
    3174:      	orr.16b	v22, v22, v23
    3178:      	add.2d	v23, v29, v22
    317c:      	tbz	w11, #0x2, 0x3098 <ltmp0+0x3098>
    3180:      	fmov	x12, d23
    3184:      	ld1.s	{ v20 }[2], [x12]
    3188:      	tbz	w11, #0x3, 0x309c <ltmp0+0x309c>
    318c:      	mov.d	x12, v23[1]
    3190:      	ld1.s	{ v20 }[3], [x12]
    3194:      	shl.2d	v23, v17, #0x5
    3198:      	ldr	q25, [sp, #0x280]
    319c:      	orr.16b	v23, v23, v25
    31a0:      	ldr	q25, [sp, #0x2b0]
    31a4:      	add.2d	v25, v25, v23
    31a8:      	tbz	w11, #0x4, 0x30b4 <ltmp0+0x30b4>
    31ac:      	fmov	x12, d25
    31b0:      	ld1.s	{ v19 }[0], [x12]
    31b4:      	tbz	w11, #0x5, 0x30b8 <ltmp0+0x30b8>
    31b8:      	mov.d	x12, v25[1]
    31bc:      	ld1.s	{ v19 }[1], [x12]
    31c0:      	shl.2d	v25, v18, #0x5
    31c4:      	ldr	q26, [sp, #0x2a0]
    31c8:      	orr.16b	v25, v25, v26
    31cc:      	ldr	q26, [sp, #0x2c0]
    31d0:      	add.2d	v26, v26, v25
    31d4:      	tbz	w11, #0x6, 0x30d0 <ltmp0+0x30d0>
    31d8:      	fmov	x12, d26
    31dc:      	ld1.s	{ v19 }[2], [x12]
    31e0:      	tbz	w11, #0x7, 0x30d4 <ltmp0+0x30d4>
    31e4:      	mov.d	x11, v26[1]
    31e8:      	ld1.s	{ v19 }[3], [x11]
    31ec:      	fmov	w11, s16
    31f0:      	add.2d	v27, v31, v21
    31f4:      	movi.2d	v26, #0000000000000000
    31f8:      	movi.2d	v21, #0000000000000000
    31fc:      	tbz	w11, #0x0, 0x30e8 <ltmp0+0x30e8>
    3200:      	fmov	x12, d27
    3204:      	ldr	s26, [x12]
    3208:      	and	w11, w11, #0xff
    320c:      	tbz	w11, #0x1, 0x30f0 <ltmp0+0x30f0>
    3210:      	mov.d	x12, v27[1]
    3214:      	ld1.s	{ v26 }[1], [x12]
    3218:      	add.2d	v22, v2, v22
    321c:      	tbz	w11, #0x2, 0x30f8 <ltmp0+0x30f8>
    3220:      	fmov	x12, d22
    3224:      	ld1.s	{ v26 }[2], [x12]
    3228:      	tbz	w11, #0x3, 0x30fc <ltmp0+0x30fc>
    322c:      	mov.d	x12, v22[1]
    3230:      	ld1.s	{ v26 }[3], [x12]
    3234:      	add.2d	v22, v30, v23
    3238:      	tbz	w11, #0x4, 0x3104 <ltmp0+0x3104>
    323c:      	fmov	x12, d22
    3240:      	ld1.s	{ v21 }[0], [x12]
    3244:      	tbz	w11, #0x5, 0x3108 <ltmp0+0x3108>
    3248:      	mov.d	x12, v22[1]
    324c:      	ld1.s	{ v21 }[1], [x12]
    3250:      	add.2d	v22, v10, v25
    3254:      	tbz	w11, #0x6, 0x3110 <ltmp0+0x3110>
    3258:      	fmov	x12, d22
    325c:      	ld1.s	{ v21 }[2], [x12]
    3260:      	tbz	w11, #0x7, 0x3114 <ltmp0+0x3114>
    3264:      	mov.d	x11, v22[1]
    3268:      	ld1.s	{ v21 }[3], [x11]
    326c:      	fdiv.4s	v20, v20, v5
    3270:      	fmov	w11, s16
    3274:      	fmul.4s	v20, v20, v26
    3278:      	add	x9, x8, x9, lsl #5
    327c:      	tbz	w11, #0x0, 0x3128 <ltmp0+0x3128>
    3280:      	str	s20, [x9]
    3284:      	and	w11, w11, #0xff
    3288:      	tbz	w11, #0x1, 0x3130 <ltmp0+0x3130>
    328c:      	add	x12, x9, #0x4
    3290:      	st1.s	{ v20 }[1], [x12]
    3294:      	tbz	w11, #0x2, 0x3134 <ltmp0+0x3134>
    3298:      	add	x12, x9, #0x8
    329c:      	st1.s	{ v20 }[2], [x12]
    32a0:      	tbz	w11, #0x3, 0x3138 <ltmp0+0x3138>
    32a4:      	add	x12, x9, #0xc
    32a8:      	st1.s	{ v20 }[3], [x12]
    32ac:      	fdiv.4s	v19, v19, v5
    32b0:      	fmul.4s	v19, v19, v21
    32b4:      	tbz	w11, #0x4, 0x3144 <ltmp0+0x3144>
    32b8:      	str	s19, [x9, #0x10]
    32bc:      	tbz	w11, #0x5, 0x3148 <ltmp0+0x3148>
    32c0:      	add	x12, x9, #0x14
    32c4:      	st1.s	{ v19 }[1], [x12]
    32c8:      	tbz	w11, #0x6, 0x314c <ltmp0+0x314c>
    32cc:      	add	x12, x9, #0x18
    32d0:      	st1.s	{ v19 }[2], [x12]
    32d4:      	tbz	w11, #0x7, 0x3040 <ltmp0+0x3040>
    32d8:      	add	x9, x9, #0x1c
    32dc:      	st1.s	{ v19 }[3], [x9]
    32e0:      	b	0x3040 <ltmp0+0x3040>
    32e4:      	add	x8, x10, x3
    32e8:      	ldp	q6, q2, [x8]
    32ec:      	zip1.8b	v7, v28, v0
    32f0:      	ushll.4s	v7, v7, #0x0
    32f4:      	shl.4s	v7, v7, #0x1f
    32f8:      	cmlt.4s	v7, v7, #0
    32fc:      	and.16b	v6, v7, v6
    3300:      	fmov	w8, s4
    3304:      	fdiv.4s	v6, v6, v5
    3308:      	add	x9, sp, #0x560
    330c:      	add	x9, x9, x3
    3310:      	ldp	q16, q4, [x9]
    3314:      	and.16b	v7, v7, v16
    3318:      	fmul.4s	v6, v6, v7
    331c:      	ldr	q7, [sp, #0xf0]
    3320:      	str	q7, [sp, #0x2d0]
    3324:      	ldr	q7, [sp, #0x100]
    3328:      	str	q7, [sp, #0x2e0]
    332c:      	ldr	q7, [sp, #0x110]
    3330:      	str	q7, [sp, #0x2f0]
    3334:      	ldr	q7, [sp, #0x120]
    3338:      	str	q7, [sp, #0x300]
    333c:      	and	x9, x30, #0x7
    3340:      	add	x11, sp, #0x2d0
    3344:      	ldr	x9, [x11, x9, lsl #3]
    3348:      	sub	x9, x9, x30
    334c:      	add	x9, x2, x9, lsl #2
    3350:      	tbnz	w8, #0x0, 0x3430 <ltmp0+0x3430>
    3354:      	tbnz	w8, #0x1, 0x3438 <ltmp0+0x3438>
    3358:      	tbnz	w8, #0x2, 0x3444 <ltmp0+0x3444>
    335c:      	tbz	w8, #0x3, 0x3368 <ltmp0+0x3368>
    3360:      	add	x11, x9, #0xc
    3364:      	st1.s	{ v6 }[3], [x11]
    3368:      	zip2.8b	v6, v28, v0
    336c:      	ushll.4s	v6, v6, #0x0
    3370:      	shl.4s	v6, v6, #0x1f
    3374:      	cmlt.4s	v6, v6, #0
    3378:      	and.16b	v2, v6, v2
    337c:      	fdiv.4s	v2, v2, v5
    3380:      	and.16b	v4, v6, v4
    3384:      	fmul.4s	v2, v2, v4
    3388:      	tbnz	w8, #0x4, 0x3454 <ltmp0+0x3454>
    338c:      	tbnz	w8, #0x5, 0x345c <ltmp0+0x345c>
    3390:      	tbnz	w8, #0x6, 0x3468 <ltmp0+0x3468>
    3394:      	tbz	w8, #0x7, 0xc8 <ltmp0+0xc8>
    3398:      	b	0x3474 <ltmp0+0x3474>
    339c:      	ldr	s23, [x8]
    33a0:      	tbz	w9, #0x1, 0x226c <ltmp0+0x226c>
    33a4:      	add	x11, x8, #0x4
    33a8:      	ld1.s	{ v23 }[1], [x11]
    33ac:      	tbz	w9, #0x2, 0x2270 <ltmp0+0x2270>
    33b0:      	add	x11, x8, #0x8
    33b4:      	ld1.s	{ v23 }[2], [x11]
    33b8:      	tbz	w9, #0x3, 0x2274 <ltmp0+0x2274>
    33bc:      	add	x11, x8, #0xc
    33c0:      	ld1.s	{ v23 }[3], [x11]
    33c4:      	tbz	w9, #0x4, 0x2278 <ltmp0+0x2278>
    33c8:      	add	x11, x8, #0x10
    33cc:      	ld1.s	{ v25 }[0], [x11]
    33d0:      	tbz	w9, #0x5, 0x227c <ltmp0+0x227c>
    33d4:      	add	x11, x8, #0x14
    33d8:      	ld1.s	{ v25 }[1], [x11]
    33dc:      	tbz	w9, #0x6, 0x2280 <ltmp0+0x2280>
    33e0:      	add	x11, x8, #0x18
    33e4:      	ld1.s	{ v25 }[2], [x11]
    33e8:      	tbnz	w9, #0x7, 0x2284 <ltmp0+0x2284>
    33ec:      	b	0x228c <ltmp0+0x228c>
    33f0:      	add	x11, x9, #0x8
    33f4:      	ld1.s	{ v6 }[2], [x11]
    33f8:      	tbz	w8, #0x3, 0x2f9c <ltmp0+0x2f9c>
    33fc:      	add	x11, x9, #0xc
    3400:      	ld1.s	{ v6 }[3], [x11]
    3404:      	tbz	w8, #0x4, 0x2fa0 <ltmp0+0x2fa0>
    3408:      	add	x11, x9, #0x10
    340c:      	ld1.s	{ v7 }[0], [x11]
    3410:      	tbz	w8, #0x5, 0x2fa4 <ltmp0+0x2fa4>
    3414:      	add	x11, x9, #0x14
    3418:      	ld1.s	{ v7 }[1], [x11]
    341c:      	tbz	w8, #0x6, 0x2fa8 <ltmp0+0x2fa8>
    3420:      	add	x11, x9, #0x18
    3424:      	ld1.s	{ v7 }[2], [x11]
    3428:      	tbnz	w8, #0x7, 0x2fac <ltmp0+0x2fac>
    342c:      	b	0x2fb4 <ltmp0+0x2fb4>
    3430:      	str	s6, [x9]
    3434:      	tbz	w8, #0x1, 0x3358 <ltmp0+0x3358>
    3438:      	add	x11, x9, #0x4
    343c:      	st1.s	{ v6 }[1], [x11]
    3440:      	tbz	w8, #0x2, 0x335c <ltmp0+0x335c>
    3444:      	add	x11, x9, #0x8
    3448:      	st1.s	{ v6 }[2], [x11]
    344c:      	tbnz	w8, #0x3, 0x3360 <ltmp0+0x3360>
    3450:      	b	0x3368 <ltmp0+0x3368>
    3454:      	str	s2, [x9, #0x10]
    3458:      	tbz	w8, #0x5, 0x3390 <ltmp0+0x3390>
    345c:      	add	x11, x9, #0x14
    3460:      	st1.s	{ v2 }[1], [x11]
    3464:      	tbz	w8, #0x6, 0x3394 <ltmp0+0x3394>
    3468:      	add	x11, x9, #0x18
    346c:      	st1.s	{ v2 }[2], [x11]
    3470:      	tbz	w8, #0x7, 0xc8 <ltmp0+0xc8>
    3474:      	add	x8, x9, #0x1c
    3478:      	st1.s	{ v2 }[3], [x8]
    347c:      	b	0xc8 <ltmp0+0xc8>
    3480:      	ldr	x9, [sp, #0x8]
    3484:      	stp	w0, w14, [x9]
    3488:      	str	w13, [x9, #0x8]
    348c:      	mov	w8, #0x18               ; =24
    3490:      	str	w8, [x9, #0x24]
    3494:      	add	sp, sp, #0x2, lsl #12   ; =0x2000
    3498:      	add	sp, sp, #0x560
    349c:      	ldp	x29, x30, [sp, #0x90]
    34a0:      	ldp	x20, x19, [sp, #0x80]
    34a4:      	ldp	x22, x21, [sp, #0x70]
    34a8:      	ldp	x24, x23, [sp, #0x60]
    34ac:      	ldp	x26, x25, [sp, #0x50]
    34b0:      	ldp	x28, x27, [sp, #0x40]
    34b4:      	ldp	d9, d8, [sp, #0x30]
    34b8:      	ldp	d11, d10, [sp, #0x20]
    34bc:      	ldp	d13, d12, [sp, #0x10]
    34c0:      	ldp	d15, d14, [sp], #0xa0
    34c4:      	ret

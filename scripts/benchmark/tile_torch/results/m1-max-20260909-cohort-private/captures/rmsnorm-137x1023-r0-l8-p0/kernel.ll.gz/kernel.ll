; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [4096 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [4096 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill5, align 1
  %.spill6 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill6, align 4
  %.spill7 = alloca i64, align 8
  store i64 0, ptr %.spill7, align 4
  %.slot8 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot8, align 64
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.spill13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill13, align 32
  %.spill14 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill14, align 32
  %.slot15 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot15, align 32
  %.spill16 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill16, align 4
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot18, align 64
  %.spill19 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill19, align 4
  %.slot20 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot20, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat22, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat24, %41
  %44 = mul i32 %32, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat26, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert27 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat28, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert29 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat30 = shufflevector <8 x i32> %.splatinsert29, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat30
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 127
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state31 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state31, 8
  %.splatinsert32 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat33 = shufflevector <8 x i64> %.splatinsert32, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat33, %.spill.load
  %.spill.load34 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load34, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 1023)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state35 = load i64, ptr %.slot, align 4
  %.splatinsert36 = insertelement <8 x i64> poison, i64 %.state35, i64 0
  %.splat37 = shufflevector <8 x i64> %.splatinsert36, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat37, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state38 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state38, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load39 = load <8 x i64>, ptr %.spill, align 64
  %102 = icmp slt <8 x i64> %.spill.load39, splat (i64 7)
  %103 = load <8 x i1>, ptr %.spill5, align 1
  %104 = select <8 x i1> %51, <8 x i1> %102, <8 x i1> %103
  store <8 x i1> %104, ptr %.spill5, align 1
  %105 = and <8 x i1> %51, %102
  %106 = xor <8 x i1> %102, splat (i1 true)
  %107 = and <8 x i1> %51, %106
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %109 = bitcast <8 x i1> %105 to i8
  %110 = call i8 @llvm.cttz.i8(i8 %109, i1 false)
  %111 = zext i8 %110 to i32
  %112 = select i1 %108, i32 %111, i32 0
  %.spill.load40 = load <8 x i64>, ptr %.spill, align 64
  %113 = add <8 x i64> splat (i64 1016), %.spill.load40
  %.spill.load41 = load <8 x i64>, ptr %.spill4, align 64
  %114 = add <8 x i64> %.spill.load41, zeroinitializer
  %115 = add <8 x i64> zeroinitializer, %114
  %116 = add <8 x i64> zeroinitializer, %113
  %117 = mul <8 x i64> %115, splat (i64 1023)
  %118 = add <8 x i64> %117, %116
  %119 = extractvalue { ptr, i64 } %9, 0
  %120 = select <8 x i1> %105, <8 x i64> %118, <8 x i64> zeroinitializer
  %121 = extractelement <8 x i64> %120, i32 %112
  %122 = zext i32 %112 to i64
  %123 = sub i64 %121, %122
  %124 = mul i64 %123, 4
  %buffer.contiguous.address42 = getelementptr i8, ptr %119, i64 %124
  %buffer.contiguous.load43 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address42, i32 1, <8 x i1> %105, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load44 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 1
  %127 = add <8 x i64> %126, splat (i64 4064)
  %128 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %125, 0
  %129 = insertvalue { <8 x ptr>, <8 x i64> } %128, <8 x i64> %127, 1
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %129, 1
  %132 = extractelement <8 x ptr> %130, i32 0
  %133 = extractelement <8 x i64> %131, i32 %112
  %134 = zext i32 %112 to i64
  %135 = mul i64 %134, 4
  %136 = sub i64 %133, %135
  %137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %138 = select i1 %137, i64 %136, i64 0
  %private.contiguous.address45 = getelementptr i8, ptr %132, i64 %138
  %private.contiguous.preserve46 = load <8 x float>, ptr %private.contiguous.address45, align 4
  %139 = select <8 x i1> %105, <8 x float> %buffer.contiguous.load43, <8 x float> %private.contiguous.preserve46
  store <8 x float> %139, ptr %private.contiguous.address45, align 4
  %140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %107)
  %141 = bitcast <8 x i1> %107 to i8
  %142 = call i8 @llvm.cttz.i8(i8 %141, i1 false)
  %143 = zext i8 %142 to i32
  %144 = select i1 %140, i32 %143, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  store float 0.000000e+00, ptr %.spill6, align 4
  store i64 0, ptr %.spill7, align 4
  %tile_snapshot.spill.load47 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 0
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 1
  %147 = add <8 x i64> %146, zeroinitializer
  %148 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %145, 0
  %149 = insertvalue { <8 x ptr>, <8 x i64> } %148, <8 x i64> %147, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %149, 1
  %152 = extractelement <8 x ptr> %150, i32 0
  %153 = extractelement <8 x i64> %151, i32 0
  %154 = sub i64 %153, 0
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %156 = select i1 %155, i64 %154, i64 0
  %private.contiguous.address48 = getelementptr i8, ptr %152, i64 %156
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address48, align 4
  %157 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %158 = fmul <8 x float> %157, %157
  %tile_snapshot.spill.load49 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load49, 0
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load49, 1
  %161 = add <8 x i64> %160, splat (i64 32)
  %162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %159, 0
  %163 = insertvalue { <8 x ptr>, <8 x i64> } %162, <8 x i64> %161, 1
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %163, 1
  %166 = extractelement <8 x ptr> %164, i32 0
  %167 = extractelement <8 x i64> %165, i32 0
  %168 = sub i64 %167, 0
  %169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %170 = select i1 %169, i64 %168, i64 0
  %private.contiguous.address50 = getelementptr i8, ptr %166, i64 %170
  %private.contiguous.load51 = load <8 x float>, ptr %private.contiguous.address50, align 4
  %171 = select <8 x i1> %51, <8 x float> %private.contiguous.load51, <8 x float> zeroinitializer
  %172 = fmul <8 x float> %171, %171
  %tile_snapshot.spill.load52 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 0
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 1
  %175 = add <8 x i64> %174, splat (i64 64)
  %176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %173, 0
  %177 = insertvalue { <8 x ptr>, <8 x i64> } %176, <8 x i64> %175, 1
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %177, 1
  %180 = extractelement <8 x ptr> %178, i32 0
  %181 = extractelement <8 x i64> %179, i32 0
  %182 = sub i64 %181, 0
  %183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %184 = select i1 %183, i64 %182, i64 0
  %private.contiguous.address53 = getelementptr i8, ptr %180, i64 %184
  %private.contiguous.load54 = load <8 x float>, ptr %private.contiguous.address53, align 4
  %185 = select <8 x i1> %51, <8 x float> %private.contiguous.load54, <8 x float> zeroinitializer
  %186 = fmul <8 x float> %185, %185
  %tile_snapshot.spill.load55 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load55, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load55, 1
  %189 = add <8 x i64> %188, splat (i64 96)
  %190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %187, 0
  %191 = insertvalue { <8 x ptr>, <8 x i64> } %190, <8 x i64> %189, 1
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %191, 1
  %194 = extractelement <8 x ptr> %192, i32 0
  %195 = extractelement <8 x i64> %193, i32 0
  %196 = sub i64 %195, 0
  %197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %198 = select i1 %197, i64 %196, i64 0
  %private.contiguous.address56 = getelementptr i8, ptr %194, i64 %198
  %private.contiguous.load57 = load <8 x float>, ptr %private.contiguous.address56, align 4
  %199 = select <8 x i1> %51, <8 x float> %private.contiguous.load57, <8 x float> zeroinitializer
  %200 = fmul <8 x float> %199, %199
  %201 = load <8 x i64>, ptr %.slot8, align 64
  %202 = select <8 x i1> %51, <8 x i64> splat (i64 4), <8 x i64> %201
  store <8 x i64> %202, ptr %.slot8, align 64
  %203 = load <8 x float>, ptr %.slot9, align 32
  %204 = select <8 x i1> %51, <8 x float> %158, <8 x float> %203
  store <8 x float> %204, ptr %.slot9, align 32
  %205 = load <8 x float>, ptr %.slot10, align 32
  %206 = select <8 x i1> %51, <8 x float> %172, <8 x float> %205
  store <8 x float> %206, ptr %.slot10, align 32
  %207 = load <8 x float>, ptr %.slot11, align 32
  %208 = select <8 x i1> %51, <8 x float> %186, <8 x float> %207
  store <8 x float> %208, ptr %.slot11, align 32
  %209 = load <8 x float>, ptr %.slot12, align 32
  %210 = select <8 x i1> %51, <8 x float> %200, <8 x float> %209
  store <8 x float> %210, ptr %.slot12, align 32
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state58 = load <8 x i64>, ptr %.slot8, align 64
  %211 = icmp slt <8 x i64> %.state58, splat (i64 124)
  %212 = extractelement <8 x i1> %211, i32 0
  br i1 %212, label %direct.true59, label %direct.false60

direct.schedule.7:                                ; preds = %direct.true59
  %.state61 = load <8 x i64>, ptr %.slot8, align 64
  %213 = add <8 x i64> %.state61, zeroinitializer
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %216 = mul <8 x i64> %213, splat (i64 32)
  %217 = add <8 x i64> %215, %216
  %218 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %214, 0
  %219 = insertvalue { <8 x ptr>, <8 x i64> } %218, <8 x i64> %217, 1
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %219, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %219, 1
  %222 = getelementptr i8, <8 x ptr> %220, <8 x i64> %221
  %223 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %222, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %224 = fmul <8 x float> %223, %223
  %.state63 = load <8 x float>, ptr %.slot9, align 32
  %225 = fadd <8 x float> %.state63, %224
  %.state64 = load <8 x i64>, ptr %.slot8, align 64
  %226 = add <8 x i64> %.state64, splat (i64 1)
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %229 = mul <8 x i64> %226, splat (i64 32)
  %230 = add <8 x i64> %228, %229
  %231 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %227, 0
  %232 = insertvalue { <8 x ptr>, <8 x i64> } %231, <8 x i64> %230, 1
  %233 = extractvalue { <8 x ptr>, <8 x i64> } %232, 0
  %234 = extractvalue { <8 x ptr>, <8 x i64> } %232, 1
  %235 = getelementptr i8, <8 x ptr> %233, <8 x i64> %234
  %236 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %235, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %237 = fmul <8 x float> %236, %236
  %.state66 = load <8 x float>, ptr %.slot10, align 32
  %238 = fadd <8 x float> %.state66, %237
  %.state67 = load <8 x i64>, ptr %.slot8, align 64
  %239 = add <8 x i64> %.state67, splat (i64 2)
  %tile_snapshot.spill.load68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 1
  %242 = mul <8 x i64> %239, splat (i64 32)
  %243 = add <8 x i64> %241, %242
  %244 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %240, 0
  %245 = insertvalue { <8 x ptr>, <8 x i64> } %244, <8 x i64> %243, 1
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %245, 0
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %245, 1
  %248 = getelementptr i8, <8 x ptr> %246, <8 x i64> %247
  %249 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %248, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %250 = fmul <8 x float> %249, %249
  %.state69 = load <8 x float>, ptr %.slot11, align 32
  %251 = fadd <8 x float> %.state69, %250
  %.state70 = load <8 x i64>, ptr %.slot8, align 64
  %252 = add <8 x i64> %.state70, splat (i64 3)
  %tile_snapshot.spill.load71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 1
  %255 = mul <8 x i64> %252, splat (i64 32)
  %256 = add <8 x i64> %254, %255
  %257 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %253, 0
  %258 = insertvalue { <8 x ptr>, <8 x i64> } %257, <8 x i64> %256, 1
  %259 = extractvalue { <8 x ptr>, <8 x i64> } %258, 0
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %258, 1
  %261 = getelementptr i8, <8 x ptr> %259, <8 x i64> %260
  %262 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %261, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %263 = fmul <8 x float> %262, %262
  %.state72 = load <8 x float>, ptr %.slot12, align 32
  %264 = fadd <8 x float> %.state72, %263
  %.state73 = load <8 x i64>, ptr %.slot8, align 64
  %265 = add <8 x i64> %.state73, splat (i64 4)
  %266 = load <8 x i64>, ptr %.slot8, align 64
  %267 = select <8 x i1> %51, <8 x i64> %265, <8 x i64> %266
  store <8 x i64> %267, ptr %.slot8, align 64
  %268 = load <8 x float>, ptr %.slot9, align 32
  %269 = select <8 x i1> %51, <8 x float> %225, <8 x float> %268
  store <8 x float> %269, ptr %.slot9, align 32
  %270 = load <8 x float>, ptr %.slot10, align 32
  %271 = select <8 x i1> %51, <8 x float> %238, <8 x float> %270
  store <8 x float> %271, ptr %.slot10, align 32
  %272 = load <8 x float>, ptr %.slot11, align 32
  %273 = select <8 x i1> %51, <8 x float> %251, <8 x float> %272
  store <8 x float> %273, ptr %.slot11, align 32
  %274 = load <8 x float>, ptr %.slot12, align 32
  %275 = select <8 x i1> %51, <8 x float> %264, <8 x float> %274
  store <8 x float> %275, ptr %.slot12, align 32
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false60
  %tile_snapshot.spill.load74 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 0
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 1
  %278 = add <8 x i64> %277, splat (i64 3968)
  %279 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %276, 0
  %280 = insertvalue { <8 x ptr>, <8 x i64> } %279, <8 x i64> %278, 1
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %280, 1
  %283 = extractelement <8 x ptr> %281, i32 0
  %284 = extractelement <8 x i64> %282, i32 0
  %285 = sub i64 %284, 0
  %286 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %287 = select i1 %286, i64 %285, i64 0
  %private.contiguous.address75 = getelementptr i8, ptr %283, i64 %287
  %private.contiguous.load76 = load <8 x float>, ptr %private.contiguous.address75, align 4
  %288 = select <8 x i1> %51, <8 x float> %private.contiguous.load76, <8 x float> zeroinitializer
  %289 = fmul <8 x float> %288, %288
  %.state77 = load <8 x float>, ptr %.slot9, align 32
  %290 = fadd <8 x float> %.state77, %289
  %tile_snapshot.spill.load78 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 0
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 1
  %293 = add <8 x i64> %292, splat (i64 4000)
  %294 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %291, 0
  %295 = insertvalue { <8 x ptr>, <8 x i64> } %294, <8 x i64> %293, 1
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %295, 1
  %298 = extractelement <8 x ptr> %296, i32 0
  %299 = extractelement <8 x i64> %297, i32 0
  %300 = sub i64 %299, 0
  %301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %302 = select i1 %301, i64 %300, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %298, i64 %302
  %private.contiguous.load80 = load <8 x float>, ptr %private.contiguous.address79, align 4
  %303 = select <8 x i1> %51, <8 x float> %private.contiguous.load80, <8 x float> zeroinitializer
  %304 = fmul <8 x float> %303, %303
  %.state81 = load <8 x float>, ptr %.slot10, align 32
  %305 = fadd <8 x float> %.state81, %304
  %306 = load <8 x float>, ptr %.spill13, align 32
  %307 = select <8 x i1> %51, <8 x float> %305, <8 x float> %306
  store <8 x float> %307, ptr %.spill13, align 32
  %tile_snapshot.spill.load82 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 1
  %310 = add <8 x i64> %309, splat (i64 4032)
  %311 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %308, 0
  %312 = insertvalue { <8 x ptr>, <8 x i64> } %311, <8 x i64> %310, 1
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %312, 1
  %315 = extractelement <8 x ptr> %313, i32 0
  %316 = extractelement <8 x i64> %314, i32 0
  %317 = sub i64 %316, 0
  %318 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %319 = select i1 %318, i64 %317, i64 0
  %private.contiguous.address83 = getelementptr i8, ptr %315, i64 %319
  %private.contiguous.load84 = load <8 x float>, ptr %private.contiguous.address83, align 4
  %320 = select <8 x i1> %51, <8 x float> %private.contiguous.load84, <8 x float> zeroinitializer
  %321 = fmul <8 x float> %320, %320
  %.state85 = load <8 x float>, ptr %.slot11, align 32
  %322 = fadd <8 x float> %.state85, %321
  %323 = load <8 x float>, ptr %.spill14, align 32
  %324 = select <8 x i1> %51, <8 x float> %322, <8 x float> %323
  store <8 x float> %324, ptr %.spill14, align 32
  %.spill.load86 = load <8 x i1>, ptr %.spill5, align 1
  %325 = and <8 x i1> %51, %.spill.load86
  %326 = xor <8 x i1> %.spill.load86, splat (i1 true)
  %327 = and <8 x i1> %51, %326
  %328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %325)
  %329 = bitcast <8 x i1> %325 to i8
  %330 = call i8 @llvm.cttz.i8(i8 %329, i1 false)
  %331 = zext i8 %330 to i32
  %332 = select i1 %328, i32 %331, i32 0
  %tile_snapshot.spill.load87 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 0
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 1
  %335 = add <8 x i64> %334, splat (i64 4064)
  %336 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %333, 0
  %337 = insertvalue { <8 x ptr>, <8 x i64> } %336, <8 x i64> %335, 1
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %337, 1
  %340 = extractelement <8 x ptr> %338, i32 0
  %341 = extractelement <8 x i64> %339, i32 %332
  %342 = zext i32 %332 to i64
  %343 = mul i64 %342, 4
  %344 = sub i64 %341, %343
  %345 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %325)
  %346 = select i1 %345, i64 %344, i64 0
  %private.contiguous.address88 = getelementptr i8, ptr %340, i64 %346
  %private.contiguous.load89 = load <8 x float>, ptr %private.contiguous.address88, align 4
  %347 = select <8 x i1> %325, <8 x float> %private.contiguous.load89, <8 x float> zeroinitializer
  %348 = fmul <8 x float> %347, %347
  %349 = fadd <8 x float> %290, %348
  %350 = load <8 x float>, ptr %.slot15, align 32
  %351 = select <8 x i1> %325, <8 x float> %349, <8 x float> %350
  store <8 x float> %351, ptr %.slot15, align 32
  %352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %327)
  %353 = bitcast <8 x i1> %327 to i8
  %354 = call i8 @llvm.cttz.i8(i8 %353, i1 false)
  %355 = zext i8 %354 to i32
  %356 = select i1 %352, i32 %355, i32 0
  %357 = load <8 x float>, ptr %.slot15, align 32
  %358 = select <8 x i1> %327, <8 x float> %290, <8 x float> %357
  store <8 x float> %358, ptr %.slot15, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %.state90 = load <8 x float>, ptr %.slot15, align 32
  %.spill.load91 = load <8 x float>, ptr %.spill13, align 32
  %359 = fadd <8 x float> %.state90, %.spill.load91
  %.spill.load92 = load <8 x float>, ptr %.spill14, align 32
  %360 = fadd <8 x float> %359, %.spill.load92
  %.state93 = load <8 x float>, ptr %.slot12, align 32
  %361 = fadd <8 x float> %360, %.state93
  %.spill.load94 = load <8 x i64>, ptr %.spill, align 64
  %362 = trunc <8 x i64> %.spill.load94 to <8 x i32>
  %363 = xor <8 x i32> %362, splat (i32 1)
  %364 = extractelement <8 x i32> %363, i64 0
  %365 = icmp ult i32 %364, 8
  %366 = select i1 %365, i32 %364, i32 0
  %367 = extractelement <8 x i1> %51, i32 %366
  %368 = extractelement <8 x i1> %51, i64 0
  %369 = and i1 %365, %367
  %370 = and i1 %368, %369
  %371 = extractelement <8 x float> %361, i32 %366
  %372 = select i1 %370, float %371, float 0.000000e+00
  %373 = insertelement <8 x float> poison, float %372, i64 0
  %374 = xor i1 %370, true
  %375 = and i1 %368, %374
  %376 = insertelement <8 x i1> poison, i1 %375, i64 0
  %377 = extractelement <8 x i32> %363, i64 1
  %378 = icmp ult i32 %377, 8
  %379 = select i1 %378, i32 %377, i32 0
  %380 = extractelement <8 x i1> %51, i32 %379
  %381 = extractelement <8 x i1> %51, i64 1
  %382 = and i1 %378, %380
  %383 = and i1 %381, %382
  %384 = extractelement <8 x float> %361, i32 %379
  %385 = select i1 %383, float %384, float 0.000000e+00
  %386 = insertelement <8 x float> %373, float %385, i64 1
  %387 = xor i1 %383, true
  %388 = and i1 %381, %387
  %389 = insertelement <8 x i1> %376, i1 %388, i64 1
  %390 = extractelement <8 x i32> %363, i64 2
  %391 = icmp ult i32 %390, 8
  %392 = select i1 %391, i32 %390, i32 0
  %393 = extractelement <8 x i1> %51, i32 %392
  %394 = extractelement <8 x i1> %51, i64 2
  %395 = and i1 %391, %393
  %396 = and i1 %394, %395
  %397 = extractelement <8 x float> %361, i32 %392
  %398 = select i1 %396, float %397, float 0.000000e+00
  %399 = insertelement <8 x float> %386, float %398, i64 2
  %400 = xor i1 %396, true
  %401 = and i1 %394, %400
  %402 = insertelement <8 x i1> %389, i1 %401, i64 2
  %403 = extractelement <8 x i32> %363, i64 3
  %404 = icmp ult i32 %403, 8
  %405 = select i1 %404, i32 %403, i32 0
  %406 = extractelement <8 x i1> %51, i32 %405
  %407 = extractelement <8 x i1> %51, i64 3
  %408 = and i1 %404, %406
  %409 = and i1 %407, %408
  %410 = extractelement <8 x float> %361, i32 %405
  %411 = select i1 %409, float %410, float 0.000000e+00
  %412 = insertelement <8 x float> %399, float %411, i64 3
  %413 = xor i1 %409, true
  %414 = and i1 %407, %413
  %415 = insertelement <8 x i1> %402, i1 %414, i64 3
  %416 = extractelement <8 x i32> %363, i64 4
  %417 = icmp ult i32 %416, 8
  %418 = select i1 %417, i32 %416, i32 0
  %419 = extractelement <8 x i1> %51, i32 %418
  %420 = extractelement <8 x i1> %51, i64 4
  %421 = and i1 %417, %419
  %422 = and i1 %420, %421
  %423 = extractelement <8 x float> %361, i32 %418
  %424 = select i1 %422, float %423, float 0.000000e+00
  %425 = insertelement <8 x float> %412, float %424, i64 4
  %426 = xor i1 %422, true
  %427 = and i1 %420, %426
  %428 = insertelement <8 x i1> %415, i1 %427, i64 4
  %429 = extractelement <8 x i32> %363, i64 5
  %430 = icmp ult i32 %429, 8
  %431 = select i1 %430, i32 %429, i32 0
  %432 = extractelement <8 x i1> %51, i32 %431
  %433 = extractelement <8 x i1> %51, i64 5
  %434 = and i1 %430, %432
  %435 = and i1 %433, %434
  %436 = extractelement <8 x float> %361, i32 %431
  %437 = select i1 %435, float %436, float 0.000000e+00
  %438 = insertelement <8 x float> %425, float %437, i64 5
  %439 = xor i1 %435, true
  %440 = and i1 %433, %439
  %441 = insertelement <8 x i1> %428, i1 %440, i64 5
  %442 = extractelement <8 x i32> %363, i64 6
  %443 = icmp ult i32 %442, 8
  %444 = select i1 %443, i32 %442, i32 0
  %445 = extractelement <8 x i1> %51, i32 %444
  %446 = extractelement <8 x i1> %51, i64 6
  %447 = and i1 %443, %445
  %448 = and i1 %446, %447
  %449 = extractelement <8 x float> %361, i32 %444
  %450 = select i1 %448, float %449, float 0.000000e+00
  %451 = insertelement <8 x float> %438, float %450, i64 6
  %452 = xor i1 %448, true
  %453 = and i1 %446, %452
  %454 = insertelement <8 x i1> %441, i1 %453, i64 6
  %455 = extractelement <8 x i32> %363, i64 7
  %456 = icmp ult i32 %455, 8
  %457 = select i1 %456, i32 %455, i32 0
  %458 = extractelement <8 x i1> %51, i32 %457
  %459 = extractelement <8 x i1> %51, i64 7
  %460 = and i1 %456, %458
  %461 = and i1 %459, %460
  %462 = extractelement <8 x float> %361, i32 %457
  %463 = select i1 %461, float %462, float 0.000000e+00
  %464 = insertelement <8 x float> %451, float %463, i64 7
  %465 = xor i1 %461, true
  %466 = and i1 %459, %465
  %467 = insertelement <8 x i1> %454, i1 %466, i64 7
  %468 = fadd <8 x float> %361, %464
  %469 = xor <8 x i32> %362, splat (i32 2)
  %470 = extractelement <8 x i32> %469, i64 0
  %471 = icmp ult i32 %470, 8
  %472 = select i1 %471, i32 %470, i32 0
  %473 = extractelement <8 x i1> %51, i32 %472
  %474 = extractelement <8 x i1> %51, i64 0
  %475 = and i1 %471, %473
  %476 = and i1 %474, %475
  %477 = extractelement <8 x float> %468, i32 %472
  %478 = select i1 %476, float %477, float 0.000000e+00
  %479 = insertelement <8 x float> poison, float %478, i64 0
  %480 = xor i1 %476, true
  %481 = and i1 %474, %480
  %482 = insertelement <8 x i1> poison, i1 %481, i64 0
  %483 = extractelement <8 x i32> %469, i64 1
  %484 = icmp ult i32 %483, 8
  %485 = select i1 %484, i32 %483, i32 0
  %486 = extractelement <8 x i1> %51, i32 %485
  %487 = extractelement <8 x i1> %51, i64 1
  %488 = and i1 %484, %486
  %489 = and i1 %487, %488
  %490 = extractelement <8 x float> %468, i32 %485
  %491 = select i1 %489, float %490, float 0.000000e+00
  %492 = insertelement <8 x float> %479, float %491, i64 1
  %493 = xor i1 %489, true
  %494 = and i1 %487, %493
  %495 = insertelement <8 x i1> %482, i1 %494, i64 1
  %496 = extractelement <8 x i32> %469, i64 2
  %497 = icmp ult i32 %496, 8
  %498 = select i1 %497, i32 %496, i32 0
  %499 = extractelement <8 x i1> %51, i32 %498
  %500 = extractelement <8 x i1> %51, i64 2
  %501 = and i1 %497, %499
  %502 = and i1 %500, %501
  %503 = extractelement <8 x float> %468, i32 %498
  %504 = select i1 %502, float %503, float 0.000000e+00
  %505 = insertelement <8 x float> %492, float %504, i64 2
  %506 = xor i1 %502, true
  %507 = and i1 %500, %506
  %508 = insertelement <8 x i1> %495, i1 %507, i64 2
  %509 = extractelement <8 x i32> %469, i64 3
  %510 = icmp ult i32 %509, 8
  %511 = select i1 %510, i32 %509, i32 0
  %512 = extractelement <8 x i1> %51, i32 %511
  %513 = extractelement <8 x i1> %51, i64 3
  %514 = and i1 %510, %512
  %515 = and i1 %513, %514
  %516 = extractelement <8 x float> %468, i32 %511
  %517 = select i1 %515, float %516, float 0.000000e+00
  %518 = insertelement <8 x float> %505, float %517, i64 3
  %519 = xor i1 %515, true
  %520 = and i1 %513, %519
  %521 = insertelement <8 x i1> %508, i1 %520, i64 3
  %522 = extractelement <8 x i32> %469, i64 4
  %523 = icmp ult i32 %522, 8
  %524 = select i1 %523, i32 %522, i32 0
  %525 = extractelement <8 x i1> %51, i32 %524
  %526 = extractelement <8 x i1> %51, i64 4
  %527 = and i1 %523, %525
  %528 = and i1 %526, %527
  %529 = extractelement <8 x float> %468, i32 %524
  %530 = select i1 %528, float %529, float 0.000000e+00
  %531 = insertelement <8 x float> %518, float %530, i64 4
  %532 = xor i1 %528, true
  %533 = and i1 %526, %532
  %534 = insertelement <8 x i1> %521, i1 %533, i64 4
  %535 = extractelement <8 x i32> %469, i64 5
  %536 = icmp ult i32 %535, 8
  %537 = select i1 %536, i32 %535, i32 0
  %538 = extractelement <8 x i1> %51, i32 %537
  %539 = extractelement <8 x i1> %51, i64 5
  %540 = and i1 %536, %538
  %541 = and i1 %539, %540
  %542 = extractelement <8 x float> %468, i32 %537
  %543 = select i1 %541, float %542, float 0.000000e+00
  %544 = insertelement <8 x float> %531, float %543, i64 5
  %545 = xor i1 %541, true
  %546 = and i1 %539, %545
  %547 = insertelement <8 x i1> %534, i1 %546, i64 5
  %548 = extractelement <8 x i32> %469, i64 6
  %549 = icmp ult i32 %548, 8
  %550 = select i1 %549, i32 %548, i32 0
  %551 = extractelement <8 x i1> %51, i32 %550
  %552 = extractelement <8 x i1> %51, i64 6
  %553 = and i1 %549, %551
  %554 = and i1 %552, %553
  %555 = extractelement <8 x float> %468, i32 %550
  %556 = select i1 %554, float %555, float 0.000000e+00
  %557 = insertelement <8 x float> %544, float %556, i64 6
  %558 = xor i1 %554, true
  %559 = and i1 %552, %558
  %560 = insertelement <8 x i1> %547, i1 %559, i64 6
  %561 = extractelement <8 x i32> %469, i64 7
  %562 = icmp ult i32 %561, 8
  %563 = select i1 %562, i32 %561, i32 0
  %564 = extractelement <8 x i1> %51, i32 %563
  %565 = extractelement <8 x i1> %51, i64 7
  %566 = and i1 %562, %564
  %567 = and i1 %565, %566
  %568 = extractelement <8 x float> %468, i32 %563
  %569 = select i1 %567, float %568, float 0.000000e+00
  %570 = insertelement <8 x float> %557, float %569, i64 7
  %571 = xor i1 %567, true
  %572 = and i1 %565, %571
  %573 = insertelement <8 x i1> %560, i1 %572, i64 7
  %574 = fadd <8 x float> %468, %570
  %575 = xor <8 x i32> %362, splat (i32 4)
  %576 = extractelement <8 x i32> %575, i64 0
  %577 = icmp ult i32 %576, 8
  %578 = select i1 %577, i32 %576, i32 0
  %579 = extractelement <8 x i1> %51, i32 %578
  %580 = extractelement <8 x i1> %51, i64 0
  %581 = and i1 %577, %579
  %582 = and i1 %580, %581
  %583 = extractelement <8 x float> %574, i32 %578
  %584 = select i1 %582, float %583, float 0.000000e+00
  %585 = insertelement <8 x float> poison, float %584, i64 0
  %586 = xor i1 %582, true
  %587 = and i1 %580, %586
  %588 = insertelement <8 x i1> poison, i1 %587, i64 0
  %589 = extractelement <8 x i32> %575, i64 1
  %590 = icmp ult i32 %589, 8
  %591 = select i1 %590, i32 %589, i32 0
  %592 = extractelement <8 x i1> %51, i32 %591
  %593 = extractelement <8 x i1> %51, i64 1
  %594 = and i1 %590, %592
  %595 = and i1 %593, %594
  %596 = extractelement <8 x float> %574, i32 %591
  %597 = select i1 %595, float %596, float 0.000000e+00
  %598 = insertelement <8 x float> %585, float %597, i64 1
  %599 = xor i1 %595, true
  %600 = and i1 %593, %599
  %601 = insertelement <8 x i1> %588, i1 %600, i64 1
  %602 = extractelement <8 x i32> %575, i64 2
  %603 = icmp ult i32 %602, 8
  %604 = select i1 %603, i32 %602, i32 0
  %605 = extractelement <8 x i1> %51, i32 %604
  %606 = extractelement <8 x i1> %51, i64 2
  %607 = and i1 %603, %605
  %608 = and i1 %606, %607
  %609 = extractelement <8 x float> %574, i32 %604
  %610 = select i1 %608, float %609, float 0.000000e+00
  %611 = insertelement <8 x float> %598, float %610, i64 2
  %612 = xor i1 %608, true
  %613 = and i1 %606, %612
  %614 = insertelement <8 x i1> %601, i1 %613, i64 2
  %615 = extractelement <8 x i32> %575, i64 3
  %616 = icmp ult i32 %615, 8
  %617 = select i1 %616, i32 %615, i32 0
  %618 = extractelement <8 x i1> %51, i32 %617
  %619 = extractelement <8 x i1> %51, i64 3
  %620 = and i1 %616, %618
  %621 = and i1 %619, %620
  %622 = extractelement <8 x float> %574, i32 %617
  %623 = select i1 %621, float %622, float 0.000000e+00
  %624 = insertelement <8 x float> %611, float %623, i64 3
  %625 = xor i1 %621, true
  %626 = and i1 %619, %625
  %627 = insertelement <8 x i1> %614, i1 %626, i64 3
  %628 = extractelement <8 x i32> %575, i64 4
  %629 = icmp ult i32 %628, 8
  %630 = select i1 %629, i32 %628, i32 0
  %631 = extractelement <8 x i1> %51, i32 %630
  %632 = extractelement <8 x i1> %51, i64 4
  %633 = and i1 %629, %631
  %634 = and i1 %632, %633
  %635 = extractelement <8 x float> %574, i32 %630
  %636 = select i1 %634, float %635, float 0.000000e+00
  %637 = insertelement <8 x float> %624, float %636, i64 4
  %638 = xor i1 %634, true
  %639 = and i1 %632, %638
  %640 = insertelement <8 x i1> %627, i1 %639, i64 4
  %641 = extractelement <8 x i32> %575, i64 5
  %642 = icmp ult i32 %641, 8
  %643 = select i1 %642, i32 %641, i32 0
  %644 = extractelement <8 x i1> %51, i32 %643
  %645 = extractelement <8 x i1> %51, i64 5
  %646 = and i1 %642, %644
  %647 = and i1 %645, %646
  %648 = extractelement <8 x float> %574, i32 %643
  %649 = select i1 %647, float %648, float 0.000000e+00
  %650 = insertelement <8 x float> %637, float %649, i64 5
  %651 = xor i1 %647, true
  %652 = and i1 %645, %651
  %653 = insertelement <8 x i1> %640, i1 %652, i64 5
  %654 = extractelement <8 x i32> %575, i64 6
  %655 = icmp ult i32 %654, 8
  %656 = select i1 %655, i32 %654, i32 0
  %657 = extractelement <8 x i1> %51, i32 %656
  %658 = extractelement <8 x i1> %51, i64 6
  %659 = and i1 %655, %657
  %660 = and i1 %658, %659
  %661 = extractelement <8 x float> %574, i32 %656
  %662 = select i1 %660, float %661, float 0.000000e+00
  %663 = insertelement <8 x float> %650, float %662, i64 6
  %664 = xor i1 %660, true
  %665 = and i1 %658, %664
  %666 = insertelement <8 x i1> %653, i1 %665, i64 6
  %667 = extractelement <8 x i32> %575, i64 7
  %668 = icmp ult i32 %667, 8
  %669 = select i1 %668, i32 %667, i32 0
  %670 = extractelement <8 x i1> %51, i32 %669
  %671 = extractelement <8 x i1> %51, i64 7
  %672 = and i1 %668, %670
  %673 = and i1 %671, %672
  %674 = extractelement <8 x float> %574, i32 %669
  %675 = select i1 %673, float %674, float 0.000000e+00
  %676 = insertelement <8 x float> %663, float %675, i64 7
  %677 = xor i1 %673, true
  %678 = and i1 %671, %677
  %679 = insertelement <8 x i1> %666, i1 %678, i64 7
  %680 = fadd <8 x float> %574, %676
  %681 = extractelement <8 x i1> %51, i32 0
  %682 = extractelement <8 x i1> %51, i64 0
  %683 = and i1 true, %681
  %684 = and i1 %682, %683
  %685 = extractelement <8 x float> %680, i32 0
  %686 = select i1 %684, float %685, float 0.000000e+00
  %687 = insertelement <8 x float> poison, float %686, i64 0
  %688 = xor i1 %684, true
  %689 = and i1 %682, %688
  %690 = insertelement <8 x i1> poison, i1 %689, i64 0
  %691 = extractelement <8 x i1> %51, i32 0
  %692 = extractelement <8 x i1> %51, i64 1
  %693 = and i1 true, %691
  %694 = and i1 %692, %693
  %695 = extractelement <8 x float> %680, i32 0
  %696 = select i1 %694, float %695, float 0.000000e+00
  %697 = insertelement <8 x float> %687, float %696, i64 1
  %698 = xor i1 %694, true
  %699 = and i1 %692, %698
  %700 = insertelement <8 x i1> %690, i1 %699, i64 1
  %701 = extractelement <8 x i1> %51, i32 0
  %702 = extractelement <8 x i1> %51, i64 2
  %703 = and i1 true, %701
  %704 = and i1 %702, %703
  %705 = extractelement <8 x float> %680, i32 0
  %706 = select i1 %704, float %705, float 0.000000e+00
  %707 = insertelement <8 x float> %697, float %706, i64 2
  %708 = xor i1 %704, true
  %709 = and i1 %702, %708
  %710 = insertelement <8 x i1> %700, i1 %709, i64 2
  %711 = extractelement <8 x i1> %51, i32 0
  %712 = extractelement <8 x i1> %51, i64 3
  %713 = and i1 true, %711
  %714 = and i1 %712, %713
  %715 = extractelement <8 x float> %680, i32 0
  %716 = select i1 %714, float %715, float 0.000000e+00
  %717 = insertelement <8 x float> %707, float %716, i64 3
  %718 = xor i1 %714, true
  %719 = and i1 %712, %718
  %720 = insertelement <8 x i1> %710, i1 %719, i64 3
  %721 = extractelement <8 x i1> %51, i32 0
  %722 = extractelement <8 x i1> %51, i64 4
  %723 = and i1 true, %721
  %724 = and i1 %722, %723
  %725 = extractelement <8 x float> %680, i32 0
  %726 = select i1 %724, float %725, float 0.000000e+00
  %727 = insertelement <8 x float> %717, float %726, i64 4
  %728 = xor i1 %724, true
  %729 = and i1 %722, %728
  %730 = insertelement <8 x i1> %720, i1 %729, i64 4
  %731 = extractelement <8 x i1> %51, i32 0
  %732 = extractelement <8 x i1> %51, i64 5
  %733 = and i1 true, %731
  %734 = and i1 %732, %733
  %735 = extractelement <8 x float> %680, i32 0
  %736 = select i1 %734, float %735, float 0.000000e+00
  %737 = insertelement <8 x float> %727, float %736, i64 5
  %738 = xor i1 %734, true
  %739 = and i1 %732, %738
  %740 = insertelement <8 x i1> %730, i1 %739, i64 5
  %741 = extractelement <8 x i1> %51, i32 0
  %742 = extractelement <8 x i1> %51, i64 6
  %743 = and i1 true, %741
  %744 = and i1 %742, %743
  %745 = extractelement <8 x float> %680, i32 0
  %746 = select i1 %744, float %745, float 0.000000e+00
  %747 = insertelement <8 x float> %737, float %746, i64 6
  %748 = xor i1 %744, true
  %749 = and i1 %742, %748
  %750 = insertelement <8 x i1> %740, i1 %749, i64 6
  %751 = extractelement <8 x i1> %51, i32 0
  %752 = extractelement <8 x i1> %51, i64 7
  %753 = and i1 true, %751
  %754 = and i1 %752, %753
  %755 = extractelement <8 x float> %680, i32 0
  %756 = select i1 %754, float %755, float 0.000000e+00
  %757 = insertelement <8 x float> %747, float %756, i64 7
  %758 = xor i1 %754, true
  %759 = and i1 %752, %758
  %760 = insertelement <8 x i1> %750, i1 %759, i64 7
  %761 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %762 = bitcast <8 x i1> %51 to i8
  %763 = call i8 @llvm.cttz.i8(i8 %762, i1 false)
  %764 = zext i8 %763 to i32
  %765 = select i1 %761, i32 %764, i32 0
  %766 = extractelement <8 x float> %757, i32 %765
  %.spill.load95 = load float, ptr %.spill6, align 4
  %767 = fadd float %.spill.load95, %766
  %768 = fdiv float %767, 1.023000e+03
  store float %768, ptr %.spill16, align 4
  %769 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %770 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %771 = extractvalue { <8 x ptr>, <8 x i64> } %769, 0
  %772 = select <8 x i1> %51, <8 x ptr> %770, <8 x ptr> %771
  %773 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %774 = extractvalue { <8 x ptr>, <8 x i64> } %769, 1
  %775 = select <8 x i1> %51, <8 x i64> %773, <8 x i64> %774
  %776 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %772, 0
  %777 = insertvalue { <8 x ptr>, <8 x i64> } %776, <8 x i64> %775, 1
  store { <8 x ptr>, <8 x i64> } %777, ptr %tile_snapshot.spill17, align 64
  %778 = load <8 x i64>, ptr %.slot18, align 64
  %779 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %778
  store <8 x i64> %779, ptr %.slot18, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state96 = load <8 x i64>, ptr %.slot18, align 64
  %780 = icmp slt <8 x i64> %.state96, splat (i64 127)
  %781 = extractelement <8 x i1> %780, i32 0
  br i1 %781, label %direct.true97, label %direct.false98

direct.schedule.12:                               ; preds = %direct.true97
  %.state99 = load <8 x i64>, ptr %.slot18, align 64
  %782 = mul <8 x i64> %.state99, splat (i64 8)
  %.spill.load100 = load <8 x i64>, ptr %.spill, align 64
  %783 = add <8 x i64> %782, %.spill.load100
  %.spill.load101 = load i64, ptr %.spill7, align 4
  %784 = add i64 %.spill.load101, 0
  %785 = add <8 x i64> zeroinitializer, %783
  %786 = mul i64 %784, 1023
  %.splatinsert102 = insertelement <8 x i64> poison, i64 %786, i64 0
  %.splat103 = shufflevector <8 x i64> %.splatinsert102, <8 x i64> poison, <8 x i32> zeroinitializer
  %787 = add <8 x i64> %.splat103, %785
  %788 = extractvalue { ptr, i64 } %15, 0
  %789 = extractelement <8 x i64> %787, i32 0
  %790 = sub i64 %789, 0
  %791 = mul i64 %790, 4
  %buffer.contiguous.address104 = getelementptr i8, ptr %788, i64 %791
  %buffer.contiguous.load105 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address104, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load106 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %792 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 0
  %793 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 1
  %.state107 = load <8 x i64>, ptr %.slot18, align 64
  %794 = mul <8 x i64> %.state107, splat (i64 32)
  %795 = add <8 x i64> %793, %794
  %796 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %792, 0
  %797 = insertvalue { <8 x ptr>, <8 x i64> } %796, <8 x i64> %795, 1
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %797, 0
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %797, 1
  %800 = getelementptr i8, <8 x ptr> %798, <8 x i64> %799
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %buffer.contiguous.load105, <8 x ptr> %800, i32 1, <8 x i1> %51)
  %.state108 = load <8 x i64>, ptr %.slot18, align 64
  %801 = add <8 x i64> %.state108, splat (i64 1)
  %802 = load <8 x i64>, ptr %.slot18, align 64
  %803 = select <8 x i1> %51, <8 x i64> %801, <8 x i64> %802
  store <8 x i64> %803, ptr %.slot18, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false98
  %.spill.load109 = load <8 x i1>, ptr %.spill5, align 1
  %804 = and <8 x i1> %51, %.spill.load109
  %805 = xor <8 x i1> %.spill.load109, splat (i1 true)
  %806 = and <8 x i1> %51, %805
  %807 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %804)
  %808 = bitcast <8 x i1> %804 to i8
  %809 = call i8 @llvm.cttz.i8(i8 %808, i1 false)
  %810 = zext i8 %809 to i32
  %811 = select i1 %807, i32 %810, i32 0
  %.spill.load110 = load <8 x i64>, ptr %.spill, align 64
  %812 = add <8 x i64> splat (i64 1016), %.spill.load110
  %.spill.load111 = load i64, ptr %.spill7, align 4
  %813 = add i64 %.spill.load111, 0
  %814 = add <8 x i64> zeroinitializer, %812
  %815 = mul i64 %813, 1023
  %.splatinsert112 = insertelement <8 x i64> poison, i64 %815, i64 0
  %.splat113 = shufflevector <8 x i64> %.splatinsert112, <8 x i64> poison, <8 x i32> zeroinitializer
  %816 = add <8 x i64> %.splat113, %814
  %817 = extractvalue { ptr, i64 } %15, 0
  %818 = select <8 x i1> %804, <8 x i64> %816, <8 x i64> zeroinitializer
  %819 = extractelement <8 x i64> %818, i32 %811
  %820 = zext i32 %811 to i64
  %821 = sub i64 %819, %820
  %822 = mul i64 %821, 4
  %buffer.contiguous.address114 = getelementptr i8, ptr %817, i64 %822
  %buffer.contiguous.load115 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address114, i32 1, <8 x i1> %804, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load116 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %823 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 0
  %824 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 1
  %825 = add <8 x i64> %824, splat (i64 4064)
  %826 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %823, 0
  %827 = insertvalue { <8 x ptr>, <8 x i64> } %826, <8 x i64> %825, 1
  %828 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %829 = extractvalue { <8 x ptr>, <8 x i64> } %827, 1
  %830 = extractelement <8 x ptr> %828, i32 0
  %831 = extractelement <8 x i64> %829, i32 %811
  %832 = zext i32 %811 to i64
  %833 = mul i64 %832, 4
  %834 = sub i64 %831, %833
  %835 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %804)
  %836 = select i1 %835, i64 %834, i64 0
  %private.contiguous.address117 = getelementptr i8, ptr %830, i64 %836
  %private.contiguous.preserve118 = load <8 x float>, ptr %private.contiguous.address117, align 4
  %837 = select <8 x i1> %804, <8 x float> %buffer.contiguous.load115, <8 x float> %private.contiguous.preserve118
  store <8 x float> %837, ptr %private.contiguous.address117, align 4
  %838 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %806)
  %839 = bitcast <8 x i1> %806 to i8
  %840 = call i8 @llvm.cttz.i8(i8 %839, i1 false)
  %841 = zext i8 %840 to i32
  %842 = select i1 %838, i32 %841, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  %.spill.load119 = load float, ptr %.spill16, align 4
  %843 = fadd float %.spill.load119, 0x3EE4F8B580000000
  %844 = call float @llvm.sqrt.f32(float %843)
  store float %844, ptr %.spill19, align 4
  %845 = load <8 x i64>, ptr %.slot20, align 64
  %846 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %845
  store <8 x i64> %846, ptr %.slot20, align 64
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state120 = load <8 x i64>, ptr %.slot20, align 64
  %847 = icmp slt <8 x i64> %.state120, splat (i64 127)
  %848 = extractelement <8 x i1> %847, i32 0
  br i1 %848, label %direct.true121, label %direct.false122

direct.schedule.17:                               ; preds = %direct.true121
  %.state123 = load <8 x i64>, ptr %.slot20, align 64
  %849 = mul <8 x i64> %.state123, splat (i64 8)
  %.spill.load124 = load <8 x i64>, ptr %.spill, align 64
  %850 = add <8 x i64> %849, %.spill.load124
  %.spill.load125 = load <8 x i64>, ptr %.spill4, align 64
  %851 = add <8 x i64> %.spill.load125, zeroinitializer
  %852 = add <8 x i64> zeroinitializer, %851
  %853 = add <8 x i64> zeroinitializer, %850
  %854 = mul <8 x i64> %852, splat (i64 1023)
  %855 = add <8 x i64> %854, %853
  %tile_snapshot.spill.load126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %856 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 0
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 1
  %.state127 = load <8 x i64>, ptr %.slot20, align 64
  %858 = mul <8 x i64> %.state127, splat (i64 32)
  %859 = add <8 x i64> %857, %858
  %860 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %856, 0
  %861 = insertvalue { <8 x ptr>, <8 x i64> } %860, <8 x i64> %859, 1
  %862 = extractvalue { <8 x ptr>, <8 x i64> } %861, 0
  %863 = extractvalue { <8 x ptr>, <8 x i64> } %861, 1
  %864 = getelementptr i8, <8 x ptr> %862, <8 x i64> %863
  %865 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %864, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %.spill.load128 = load float, ptr %.spill19, align 4
  %.splatinsert129 = insertelement <8 x float> poison, float %.spill.load128, i64 0
  %.splat130 = shufflevector <8 x float> %.splatinsert129, <8 x float> poison, <8 x i32> zeroinitializer
  %866 = fdiv <8 x float> %865, %.splat130
  %tile_snapshot.spill.load131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %867 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 0
  %868 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 1
  %.state132 = load <8 x i64>, ptr %.slot20, align 64
  %869 = mul <8 x i64> %.state132, splat (i64 32)
  %870 = add <8 x i64> %868, %869
  %871 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %867, 0
  %872 = insertvalue { <8 x ptr>, <8 x i64> } %871, <8 x i64> %870, 1
  %873 = extractvalue { <8 x ptr>, <8 x i64> } %872, 0
  %874 = extractvalue { <8 x ptr>, <8 x i64> } %872, 1
  %875 = getelementptr i8, <8 x ptr> %873, <8 x i64> %874
  %876 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %875, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %877 = fmul <8 x float> %866, %876
  %878 = extractvalue { ptr, i64 } %27, 0
  %879 = extractelement <8 x i64> %855, i32 0
  %880 = sub i64 %879, 0
  %881 = mul i64 %880, 4
  %buffer.contiguous.address133 = getelementptr i8, ptr %878, i64 %881
  call void @llvm.masked.store.v8f32.p0(<8 x float> %877, ptr %buffer.contiguous.address133, i32 1, <8 x i1> %51)
  %.state134 = load <8 x i64>, ptr %.slot20, align 64
  %882 = add <8 x i64> %.state134, splat (i64 1)
  %883 = load <8 x i64>, ptr %.slot20, align 64
  %884 = select <8 x i1> %51, <8 x i64> %882, <8 x i64> %883
  store <8 x i64> %884, ptr %.slot20, align 64
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false122
  %.spill.load135 = load <8 x i1>, ptr %.spill5, align 1
  %885 = and <8 x i1> %51, %.spill.load135
  %886 = xor <8 x i1> %.spill.load135, splat (i1 true)
  %887 = and <8 x i1> %51, %886
  %888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %885)
  %889 = bitcast <8 x i1> %885 to i8
  %890 = call i8 @llvm.cttz.i8(i8 %889, i1 false)
  %891 = zext i8 %890 to i32
  %892 = select i1 %888, i32 %891, i32 0
  %.spill.load136 = load <8 x i64>, ptr %.spill, align 64
  %893 = add <8 x i64> splat (i64 1016), %.spill.load136
  %.spill.load137 = load <8 x i64>, ptr %.spill4, align 64
  %894 = add <8 x i64> %.spill.load137, zeroinitializer
  %895 = add <8 x i64> zeroinitializer, %894
  %896 = add <8 x i64> zeroinitializer, %893
  %897 = mul <8 x i64> %895, splat (i64 1023)
  %898 = add <8 x i64> %897, %896
  %tile_snapshot.spill.load138 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %899 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 0
  %900 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 1
  %901 = add <8 x i64> %900, splat (i64 4064)
  %902 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %899, 0
  %903 = insertvalue { <8 x ptr>, <8 x i64> } %902, <8 x i64> %901, 1
  %904 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %905 = extractvalue { <8 x ptr>, <8 x i64> } %903, 1
  %906 = extractelement <8 x ptr> %904, i32 0
  %907 = extractelement <8 x i64> %905, i32 %892
  %908 = zext i32 %892 to i64
  %909 = mul i64 %908, 4
  %910 = sub i64 %907, %909
  %911 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %885)
  %912 = select i1 %911, i64 %910, i64 0
  %private.contiguous.address139 = getelementptr i8, ptr %906, i64 %912
  %private.contiguous.load140 = load <8 x float>, ptr %private.contiguous.address139, align 4
  %913 = select <8 x i1> %885, <8 x float> %private.contiguous.load140, <8 x float> zeroinitializer
  %.spill.load141 = load float, ptr %.spill19, align 4
  %.splatinsert142 = insertelement <8 x float> poison, float %.spill.load141, i64 0
  %.splat143 = shufflevector <8 x float> %.splatinsert142, <8 x float> poison, <8 x i32> zeroinitializer
  %914 = fdiv <8 x float> %913, %.splat143
  %tile_snapshot.spill.load144 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %915 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 0
  %916 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 1
  %917 = add <8 x i64> %916, splat (i64 4064)
  %918 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %915, 0
  %919 = insertvalue { <8 x ptr>, <8 x i64> } %918, <8 x i64> %917, 1
  %920 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %921 = extractvalue { <8 x ptr>, <8 x i64> } %919, 1
  %922 = extractelement <8 x ptr> %920, i32 0
  %923 = extractelement <8 x i64> %921, i32 %892
  %924 = zext i32 %892 to i64
  %925 = mul i64 %924, 4
  %926 = sub i64 %923, %925
  %927 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %885)
  %928 = select i1 %927, i64 %926, i64 0
  %private.contiguous.address145 = getelementptr i8, ptr %922, i64 %928
  %private.contiguous.load146 = load <8 x float>, ptr %private.contiguous.address145, align 4
  %929 = select <8 x i1> %885, <8 x float> %private.contiguous.load146, <8 x float> zeroinitializer
  %930 = fmul <8 x float> %914, %929
  %931 = extractvalue { ptr, i64 } %27, 0
  %932 = extractelement <8 x i64> %898, i32 %892
  %933 = zext i32 %892 to i64
  %934 = sub i64 %932, %933
  %935 = mul i64 %934, 4
  %buffer.contiguous.address147 = getelementptr i8, ptr %931, i64 %935
  call void @llvm.masked.store.v8f32.p0(<8 x float> %930, ptr %buffer.contiguous.address147, i32 1, <8 x i1> %885)
  %936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %887)
  %937 = bitcast <8 x i1> %887 to i8
  %938 = call i8 @llvm.cttz.i8(i8 %937, i1 false)
  %939 = zext i8 %938 to i32
  %940 = select i1 %936, i32 %939, i32 0
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true59:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false60:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true97:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false98:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true121:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false122:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #4

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [4096 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [4096 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill5, align 1
  %.spill6 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill6, align 4
  %.spill7 = alloca i64, align 8
  store i64 0, ptr %.spill7, align 4
  %.slot8 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot8, align 64
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.spill13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill13, align 32
  %.spill14 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill14, align 32
  %.slot15 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot15, align 32
  %.spill16 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill16, align 4
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot18, align 64
  %.spill19 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill19, align 4
  %.slot20 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot20, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat22, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat24, %41
  %44 = mul i32 %32, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat26, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert27 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat28, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert29 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat30 = shufflevector <8 x i32> %.splatinsert29, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat30
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 127
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state31 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state31, 8
  %.splatinsert32 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat33 = shufflevector <8 x i64> %.splatinsert32, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat33, %.spill.load
  %.spill.load34 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load34, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 1023)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state35 = load i64, ptr %.slot, align 4
  %.splatinsert36 = insertelement <8 x i64> poison, i64 %.state35, i64 0
  %.splat37 = shufflevector <8 x i64> %.splatinsert36, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat37, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state38 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state38, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load39 = load <8 x i64>, ptr %.spill, align 64
  %102 = icmp slt <8 x i64> %.spill.load39, splat (i64 7)
  %103 = load <8 x i1>, ptr %.spill5, align 1
  %104 = select <8 x i1> %51, <8 x i1> %102, <8 x i1> %103
  store <8 x i1> %104, ptr %.spill5, align 1
  %105 = and <8 x i1> %51, %102
  %106 = xor <8 x i1> %102, splat (i1 true)
  %107 = and <8 x i1> %51, %106
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %109 = bitcast <8 x i1> %105 to i8
  %110 = call i8 @llvm.cttz.i8(i8 %109, i1 false)
  %111 = zext i8 %110 to i32
  %112 = select i1 %108, i32 %111, i32 0
  %.spill.load40 = load <8 x i64>, ptr %.spill, align 64
  %113 = add <8 x i64> splat (i64 1016), %.spill.load40
  %.spill.load41 = load <8 x i64>, ptr %.spill4, align 64
  %114 = add <8 x i64> %.spill.load41, zeroinitializer
  %115 = add <8 x i64> zeroinitializer, %114
  %116 = add <8 x i64> zeroinitializer, %113
  %117 = mul <8 x i64> %115, splat (i64 1023)
  %118 = add <8 x i64> %117, %116
  %119 = extractvalue { ptr, i64 } %9, 0
  %120 = select <8 x i1> %105, <8 x i64> %118, <8 x i64> zeroinitializer
  %121 = extractelement <8 x i64> %120, i32 %112
  %122 = zext i32 %112 to i64
  %123 = sub i64 %121, %122
  %124 = mul i64 %123, 4
  %buffer.contiguous.address42 = getelementptr i8, ptr %119, i64 %124
  %buffer.contiguous.load43 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address42, i32 1, <8 x i1> %105, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load44 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 1
  %127 = add <8 x i64> %126, splat (i64 4064)
  %128 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %125, 0
  %129 = insertvalue { <8 x ptr>, <8 x i64> } %128, <8 x i64> %127, 1
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %129, 1
  %132 = extractelement <8 x ptr> %130, i32 0
  %133 = extractelement <8 x i64> %131, i32 %112
  %134 = zext i32 %112 to i64
  %135 = mul i64 %134, 4
  %136 = sub i64 %133, %135
  %137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %138 = select i1 %137, i64 %136, i64 0
  %private.contiguous.address45 = getelementptr i8, ptr %132, i64 %138
  %private.contiguous.preserve46 = load <8 x float>, ptr %private.contiguous.address45, align 4
  %139 = select <8 x i1> %105, <8 x float> %buffer.contiguous.load43, <8 x float> %private.contiguous.preserve46
  store <8 x float> %139, ptr %private.contiguous.address45, align 4
  %140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %107)
  %141 = bitcast <8 x i1> %107 to i8
  %142 = call i8 @llvm.cttz.i8(i8 %141, i1 false)
  %143 = zext i8 %142 to i32
  %144 = select i1 %140, i32 %143, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  store float 0.000000e+00, ptr %.spill6, align 4
  store i64 0, ptr %.spill7, align 4
  %tile_snapshot.spill.load47 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 0
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 1
  %147 = add <8 x i64> %146, zeroinitializer
  %148 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %145, 0
  %149 = insertvalue { <8 x ptr>, <8 x i64> } %148, <8 x i64> %147, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %149, 1
  %152 = extractelement <8 x ptr> %150, i32 0
  %153 = extractelement <8 x i64> %151, i32 0
  %154 = sub i64 %153, 0
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %156 = select i1 %155, i64 %154, i64 0
  %private.contiguous.address48 = getelementptr i8, ptr %152, i64 %156
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address48, align 4
  %157 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %158 = fmul <8 x float> %157, %157
  %tile_snapshot.spill.load49 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load49, 0
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load49, 1
  %161 = add <8 x i64> %160, splat (i64 32)
  %162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %159, 0
  %163 = insertvalue { <8 x ptr>, <8 x i64> } %162, <8 x i64> %161, 1
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %163, 1
  %166 = extractelement <8 x ptr> %164, i32 0
  %167 = extractelement <8 x i64> %165, i32 0
  %168 = sub i64 %167, 0
  %169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %170 = select i1 %169, i64 %168, i64 0
  %private.contiguous.address50 = getelementptr i8, ptr %166, i64 %170
  %private.contiguous.load51 = load <8 x float>, ptr %private.contiguous.address50, align 4
  %171 = select <8 x i1> %51, <8 x float> %private.contiguous.load51, <8 x float> zeroinitializer
  %172 = fmul <8 x float> %171, %171
  %tile_snapshot.spill.load52 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 0
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 1
  %175 = add <8 x i64> %174, splat (i64 64)
  %176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %173, 0
  %177 = insertvalue { <8 x ptr>, <8 x i64> } %176, <8 x i64> %175, 1
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %177, 1
  %180 = extractelement <8 x ptr> %178, i32 0
  %181 = extractelement <8 x i64> %179, i32 0
  %182 = sub i64 %181, 0
  %183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %184 = select i1 %183, i64 %182, i64 0
  %private.contiguous.address53 = getelementptr i8, ptr %180, i64 %184
  %private.contiguous.load54 = load <8 x float>, ptr %private.contiguous.address53, align 4
  %185 = select <8 x i1> %51, <8 x float> %private.contiguous.load54, <8 x float> zeroinitializer
  %186 = fmul <8 x float> %185, %185
  %tile_snapshot.spill.load55 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load55, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load55, 1
  %189 = add <8 x i64> %188, splat (i64 96)
  %190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %187, 0
  %191 = insertvalue { <8 x ptr>, <8 x i64> } %190, <8 x i64> %189, 1
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %191, 1
  %194 = extractelement <8 x ptr> %192, i32 0
  %195 = extractelement <8 x i64> %193, i32 0
  %196 = sub i64 %195, 0
  %197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %198 = select i1 %197, i64 %196, i64 0
  %private.contiguous.address56 = getelementptr i8, ptr %194, i64 %198
  %private.contiguous.load57 = load <8 x float>, ptr %private.contiguous.address56, align 4
  %199 = select <8 x i1> %51, <8 x float> %private.contiguous.load57, <8 x float> zeroinitializer
  %200 = fmul <8 x float> %199, %199
  %201 = load <8 x i64>, ptr %.slot8, align 64
  %202 = select <8 x i1> %51, <8 x i64> splat (i64 4), <8 x i64> %201
  store <8 x i64> %202, ptr %.slot8, align 64
  %203 = load <8 x float>, ptr %.slot9, align 32
  %204 = select <8 x i1> %51, <8 x float> %158, <8 x float> %203
  store <8 x float> %204, ptr %.slot9, align 32
  %205 = load <8 x float>, ptr %.slot10, align 32
  %206 = select <8 x i1> %51, <8 x float> %172, <8 x float> %205
  store <8 x float> %206, ptr %.slot10, align 32
  %207 = load <8 x float>, ptr %.slot11, align 32
  %208 = select <8 x i1> %51, <8 x float> %186, <8 x float> %207
  store <8 x float> %208, ptr %.slot11, align 32
  %209 = load <8 x float>, ptr %.slot12, align 32
  %210 = select <8 x i1> %51, <8 x float> %200, <8 x float> %209
  store <8 x float> %210, ptr %.slot12, align 32
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state58 = load <8 x i64>, ptr %.slot8, align 64
  %211 = icmp slt <8 x i64> %.state58, splat (i64 124)
  %212 = extractelement <8 x i1> %211, i32 0
  br i1 %212, label %direct.true59, label %direct.false60

direct.schedule.7:                                ; preds = %direct.true59
  %.state61 = load <8 x i64>, ptr %.slot8, align 64
  %213 = add <8 x i64> %.state61, zeroinitializer
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %216 = mul <8 x i64> %213, splat (i64 32)
  %217 = add <8 x i64> %215, %216
  %218 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %214, 0
  %219 = insertvalue { <8 x ptr>, <8 x i64> } %218, <8 x i64> %217, 1
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %219, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %219, 1
  %222 = getelementptr i8, <8 x ptr> %220, <8 x i64> %221
  %223 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %222, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %224 = fmul <8 x float> %223, %223
  %.state63 = load <8 x float>, ptr %.slot9, align 32
  %225 = fadd <8 x float> %.state63, %224
  %.state64 = load <8 x i64>, ptr %.slot8, align 64
  %226 = add <8 x i64> %.state64, splat (i64 1)
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %229 = mul <8 x i64> %226, splat (i64 32)
  %230 = add <8 x i64> %228, %229
  %231 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %227, 0
  %232 = insertvalue { <8 x ptr>, <8 x i64> } %231, <8 x i64> %230, 1
  %233 = extractvalue { <8 x ptr>, <8 x i64> } %232, 0
  %234 = extractvalue { <8 x ptr>, <8 x i64> } %232, 1
  %235 = getelementptr i8, <8 x ptr> %233, <8 x i64> %234
  %236 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %235, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %237 = fmul <8 x float> %236, %236
  %.state66 = load <8 x float>, ptr %.slot10, align 32
  %238 = fadd <8 x float> %.state66, %237
  %.state67 = load <8 x i64>, ptr %.slot8, align 64
  %239 = add <8 x i64> %.state67, splat (i64 2)
  %tile_snapshot.spill.load68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 1
  %242 = mul <8 x i64> %239, splat (i64 32)
  %243 = add <8 x i64> %241, %242
  %244 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %240, 0
  %245 = insertvalue { <8 x ptr>, <8 x i64> } %244, <8 x i64> %243, 1
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %245, 0
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %245, 1
  %248 = getelementptr i8, <8 x ptr> %246, <8 x i64> %247
  %249 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %248, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %250 = fmul <8 x float> %249, %249
  %.state69 = load <8 x float>, ptr %.slot11, align 32
  %251 = fadd <8 x float> %.state69, %250
  %.state70 = load <8 x i64>, ptr %.slot8, align 64
  %252 = add <8 x i64> %.state70, splat (i64 3)
  %tile_snapshot.spill.load71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 1
  %255 = mul <8 x i64> %252, splat (i64 32)
  %256 = add <8 x i64> %254, %255
  %257 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %253, 0
  %258 = insertvalue { <8 x ptr>, <8 x i64> } %257, <8 x i64> %256, 1
  %259 = extractvalue { <8 x ptr>, <8 x i64> } %258, 0
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %258, 1
  %261 = getelementptr i8, <8 x ptr> %259, <8 x i64> %260
  %262 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %261, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %263 = fmul <8 x float> %262, %262
  %.state72 = load <8 x float>, ptr %.slot12, align 32
  %264 = fadd <8 x float> %.state72, %263
  %.state73 = load <8 x i64>, ptr %.slot8, align 64
  %265 = add <8 x i64> %.state73, splat (i64 4)
  %266 = load <8 x i64>, ptr %.slot8, align 64
  %267 = select <8 x i1> %51, <8 x i64> %265, <8 x i64> %266
  store <8 x i64> %267, ptr %.slot8, align 64
  %268 = load <8 x float>, ptr %.slot9, align 32
  %269 = select <8 x i1> %51, <8 x float> %225, <8 x float> %268
  store <8 x float> %269, ptr %.slot9, align 32
  %270 = load <8 x float>, ptr %.slot10, align 32
  %271 = select <8 x i1> %51, <8 x float> %238, <8 x float> %270
  store <8 x float> %271, ptr %.slot10, align 32
  %272 = load <8 x float>, ptr %.slot11, align 32
  %273 = select <8 x i1> %51, <8 x float> %251, <8 x float> %272
  store <8 x float> %273, ptr %.slot11, align 32
  %274 = load <8 x float>, ptr %.slot12, align 32
  %275 = select <8 x i1> %51, <8 x float> %264, <8 x float> %274
  store <8 x float> %275, ptr %.slot12, align 32
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false60
  %tile_snapshot.spill.load74 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 0
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 1
  %278 = add <8 x i64> %277, splat (i64 3968)
  %279 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %276, 0
  %280 = insertvalue { <8 x ptr>, <8 x i64> } %279, <8 x i64> %278, 1
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %280, 1
  %283 = extractelement <8 x ptr> %281, i32 0
  %284 = extractelement <8 x i64> %282, i32 0
  %285 = sub i64 %284, 0
  %286 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %287 = select i1 %286, i64 %285, i64 0
  %private.contiguous.address75 = getelementptr i8, ptr %283, i64 %287
  %private.contiguous.load76 = load <8 x float>, ptr %private.contiguous.address75, align 4
  %288 = select <8 x i1> %51, <8 x float> %private.contiguous.load76, <8 x float> zeroinitializer
  %289 = fmul <8 x float> %288, %288
  %.state77 = load <8 x float>, ptr %.slot9, align 32
  %290 = fadd <8 x float> %.state77, %289
  %tile_snapshot.spill.load78 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 0
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 1
  %293 = add <8 x i64> %292, splat (i64 4000)
  %294 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %291, 0
  %295 = insertvalue { <8 x ptr>, <8 x i64> } %294, <8 x i64> %293, 1
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %295, 1
  %298 = extractelement <8 x ptr> %296, i32 0
  %299 = extractelement <8 x i64> %297, i32 0
  %300 = sub i64 %299, 0
  %301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %302 = select i1 %301, i64 %300, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %298, i64 %302
  %private.contiguous.load80 = load <8 x float>, ptr %private.contiguous.address79, align 4
  %303 = select <8 x i1> %51, <8 x float> %private.contiguous.load80, <8 x float> zeroinitializer
  %304 = fmul <8 x float> %303, %303
  %.state81 = load <8 x float>, ptr %.slot10, align 32
  %305 = fadd <8 x float> %.state81, %304
  %306 = load <8 x float>, ptr %.spill13, align 32
  %307 = select <8 x i1> %51, <8 x float> %305, <8 x float> %306
  store <8 x float> %307, ptr %.spill13, align 32
  %tile_snapshot.spill.load82 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load82, 1
  %310 = add <8 x i64> %309, splat (i64 4032)
  %311 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %308, 0
  %312 = insertvalue { <8 x ptr>, <8 x i64> } %311, <8 x i64> %310, 1
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %312, 1
  %315 = extractelement <8 x ptr> %313, i32 0
  %316 = extractelement <8 x i64> %314, i32 0
  %317 = sub i64 %316, 0
  %318 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %319 = select i1 %318, i64 %317, i64 0
  %private.contiguous.address83 = getelementptr i8, ptr %315, i64 %319
  %private.contiguous.load84 = load <8 x float>, ptr %private.contiguous.address83, align 4
  %320 = select <8 x i1> %51, <8 x float> %private.contiguous.load84, <8 x float> zeroinitializer
  %321 = fmul <8 x float> %320, %320
  %.state85 = load <8 x float>, ptr %.slot11, align 32
  %322 = fadd <8 x float> %.state85, %321
  %323 = load <8 x float>, ptr %.spill14, align 32
  %324 = select <8 x i1> %51, <8 x float> %322, <8 x float> %323
  store <8 x float> %324, ptr %.spill14, align 32
  %.spill.load86 = load <8 x i1>, ptr %.spill5, align 1
  %325 = and <8 x i1> %51, %.spill.load86
  %326 = xor <8 x i1> %.spill.load86, splat (i1 true)
  %327 = and <8 x i1> %51, %326
  %328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %325)
  %329 = bitcast <8 x i1> %325 to i8
  %330 = call i8 @llvm.cttz.i8(i8 %329, i1 false)
  %331 = zext i8 %330 to i32
  %332 = select i1 %328, i32 %331, i32 0
  %tile_snapshot.spill.load87 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 0
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load87, 1
  %335 = add <8 x i64> %334, splat (i64 4064)
  %336 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %333, 0
  %337 = insertvalue { <8 x ptr>, <8 x i64> } %336, <8 x i64> %335, 1
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %337, 1
  %340 = extractelement <8 x ptr> %338, i32 0
  %341 = extractelement <8 x i64> %339, i32 %332
  %342 = zext i32 %332 to i64
  %343 = mul i64 %342, 4
  %344 = sub i64 %341, %343
  %345 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %325)
  %346 = select i1 %345, i64 %344, i64 0
  %private.contiguous.address88 = getelementptr i8, ptr %340, i64 %346
  %private.contiguous.load89 = load <8 x float>, ptr %private.contiguous.address88, align 4
  %347 = select <8 x i1> %325, <8 x float> %private.contiguous.load89, <8 x float> zeroinitializer
  %348 = fmul <8 x float> %347, %347
  %349 = fadd <8 x float> %290, %348
  %350 = load <8 x float>, ptr %.slot15, align 32
  %351 = select <8 x i1> %325, <8 x float> %349, <8 x float> %350
  store <8 x float> %351, ptr %.slot15, align 32
  %352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %327)
  %353 = bitcast <8 x i1> %327 to i8
  %354 = call i8 @llvm.cttz.i8(i8 %353, i1 false)
  %355 = zext i8 %354 to i32
  %356 = select i1 %352, i32 %355, i32 0
  %357 = load <8 x float>, ptr %.slot15, align 32
  %358 = select <8 x i1> %327, <8 x float> %290, <8 x float> %357
  store <8 x float> %358, ptr %.slot15, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %.state90 = load <8 x float>, ptr %.slot15, align 32
  %.spill.load91 = load <8 x float>, ptr %.spill13, align 32
  %359 = fadd <8 x float> %.state90, %.spill.load91
  %.spill.load92 = load <8 x float>, ptr %.spill14, align 32
  %360 = fadd <8 x float> %359, %.spill.load92
  %.state93 = load <8 x float>, ptr %.slot12, align 32
  %361 = fadd <8 x float> %360, %.state93
  %.spill.load94 = load <8 x i64>, ptr %.spill, align 64
  %362 = trunc <8 x i64> %.spill.load94 to <8 x i32>
  %363 = xor <8 x i32> %362, splat (i32 1)
  %364 = extractelement <8 x i32> %363, i64 0
  %365 = icmp ult i32 %364, 8
  %366 = select i1 %365, i32 %364, i32 0
  %367 = extractelement <8 x i1> %51, i32 %366
  %368 = extractelement <8 x i1> %51, i64 0
  %369 = and i1 %365, %367
  %370 = and i1 %368, %369
  %371 = extractelement <8 x float> %361, i32 %366
  %372 = select i1 %370, float %371, float 0.000000e+00
  %373 = insertelement <8 x float> poison, float %372, i64 0
  %374 = xor i1 %370, true
  %375 = and i1 %368, %374
  %376 = insertelement <8 x i1> poison, i1 %375, i64 0
  %377 = extractelement <8 x i32> %363, i64 1
  %378 = icmp ult i32 %377, 8
  %379 = select i1 %378, i32 %377, i32 0
  %380 = extractelement <8 x i1> %51, i32 %379
  %381 = extractelement <8 x i1> %51, i64 1
  %382 = and i1 %378, %380
  %383 = and i1 %381, %382
  %384 = extractelement <8 x float> %361, i32 %379
  %385 = select i1 %383, float %384, float 0.000000e+00
  %386 = insertelement <8 x float> %373, float %385, i64 1
  %387 = xor i1 %383, true
  %388 = and i1 %381, %387
  %389 = insertelement <8 x i1> %376, i1 %388, i64 1
  %390 = extractelement <8 x i32> %363, i64 2
  %391 = icmp ult i32 %390, 8
  %392 = select i1 %391, i32 %390, i32 0
  %393 = extractelement <8 x i1> %51, i32 %392
  %394 = extractelement <8 x i1> %51, i64 2
  %395 = and i1 %391, %393
  %396 = and i1 %394, %395
  %397 = extractelement <8 x float> %361, i32 %392
  %398 = select i1 %396, float %397, float 0.000000e+00
  %399 = insertelement <8 x float> %386, float %398, i64 2
  %400 = xor i1 %396, true
  %401 = and i1 %394, %400
  %402 = insertelement <8 x i1> %389, i1 %401, i64 2
  %403 = extractelement <8 x i32> %363, i64 3
  %404 = icmp ult i32 %403, 8
  %405 = select i1 %404, i32 %403, i32 0
  %406 = extractelement <8 x i1> %51, i32 %405
  %407 = extractelement <8 x i1> %51, i64 3
  %408 = and i1 %404, %406
  %409 = and i1 %407, %408
  %410 = extractelement <8 x float> %361, i32 %405
  %411 = select i1 %409, float %410, float 0.000000e+00
  %412 = insertelement <8 x float> %399, float %411, i64 3
  %413 = xor i1 %409, true
  %414 = and i1 %407, %413
  %415 = insertelement <8 x i1> %402, i1 %414, i64 3
  %416 = extractelement <8 x i32> %363, i64 4
  %417 = icmp ult i32 %416, 8
  %418 = select i1 %417, i32 %416, i32 0
  %419 = extractelement <8 x i1> %51, i32 %418
  %420 = extractelement <8 x i1> %51, i64 4
  %421 = and i1 %417, %419
  %422 = and i1 %420, %421
  %423 = extractelement <8 x float> %361, i32 %418
  %424 = select i1 %422, float %423, float 0.000000e+00
  %425 = insertelement <8 x float> %412, float %424, i64 4
  %426 = xor i1 %422, true
  %427 = and i1 %420, %426
  %428 = insertelement <8 x i1> %415, i1 %427, i64 4
  %429 = extractelement <8 x i32> %363, i64 5
  %430 = icmp ult i32 %429, 8
  %431 = select i1 %430, i32 %429, i32 0
  %432 = extractelement <8 x i1> %51, i32 %431
  %433 = extractelement <8 x i1> %51, i64 5
  %434 = and i1 %430, %432
  %435 = and i1 %433, %434
  %436 = extractelement <8 x float> %361, i32 %431
  %437 = select i1 %435, float %436, float 0.000000e+00
  %438 = insertelement <8 x float> %425, float %437, i64 5
  %439 = xor i1 %435, true
  %440 = and i1 %433, %439
  %441 = insertelement <8 x i1> %428, i1 %440, i64 5
  %442 = extractelement <8 x i32> %363, i64 6
  %443 = icmp ult i32 %442, 8
  %444 = select i1 %443, i32 %442, i32 0
  %445 = extractelement <8 x i1> %51, i32 %444
  %446 = extractelement <8 x i1> %51, i64 6
  %447 = and i1 %443, %445
  %448 = and i1 %446, %447
  %449 = extractelement <8 x float> %361, i32 %444
  %450 = select i1 %448, float %449, float 0.000000e+00
  %451 = insertelement <8 x float> %438, float %450, i64 6
  %452 = xor i1 %448, true
  %453 = and i1 %446, %452
  %454 = insertelement <8 x i1> %441, i1 %453, i64 6
  %455 = extractelement <8 x i32> %363, i64 7
  %456 = icmp ult i32 %455, 8
  %457 = select i1 %456, i32 %455, i32 0
  %458 = extractelement <8 x i1> %51, i32 %457
  %459 = extractelement <8 x i1> %51, i64 7
  %460 = and i1 %456, %458
  %461 = and i1 %459, %460
  %462 = extractelement <8 x float> %361, i32 %457
  %463 = select i1 %461, float %462, float 0.000000e+00
  %464 = insertelement <8 x float> %451, float %463, i64 7
  %465 = xor i1 %461, true
  %466 = and i1 %459, %465
  %467 = insertelement <8 x i1> %454, i1 %466, i64 7
  %468 = fadd <8 x float> %361, %464
  %469 = xor <8 x i32> %362, splat (i32 2)
  %470 = extractelement <8 x i32> %469, i64 0
  %471 = icmp ult i32 %470, 8
  %472 = select i1 %471, i32 %470, i32 0
  %473 = extractelement <8 x i1> %51, i32 %472
  %474 = extractelement <8 x i1> %51, i64 0
  %475 = and i1 %471, %473
  %476 = and i1 %474, %475
  %477 = extractelement <8 x float> %468, i32 %472
  %478 = select i1 %476, float %477, float 0.000000e+00
  %479 = insertelement <8 x float> poison, float %478, i64 0
  %480 = xor i1 %476, true
  %481 = and i1 %474, %480
  %482 = insertelement <8 x i1> poison, i1 %481, i64 0
  %483 = extractelement <8 x i32> %469, i64 1
  %484 = icmp ult i32 %483, 8
  %485 = select i1 %484, i32 %483, i32 0
  %486 = extractelement <8 x i1> %51, i32 %485
  %487 = extractelement <8 x i1> %51, i64 1
  %488 = and i1 %484, %486
  %489 = and i1 %487, %488
  %490 = extractelement <8 x float> %468, i32 %485
  %491 = select i1 %489, float %490, float 0.000000e+00
  %492 = insertelement <8 x float> %479, float %491, i64 1
  %493 = xor i1 %489, true
  %494 = and i1 %487, %493
  %495 = insertelement <8 x i1> %482, i1 %494, i64 1
  %496 = extractelement <8 x i32> %469, i64 2
  %497 = icmp ult i32 %496, 8
  %498 = select i1 %497, i32 %496, i32 0
  %499 = extractelement <8 x i1> %51, i32 %498
  %500 = extractelement <8 x i1> %51, i64 2
  %501 = and i1 %497, %499
  %502 = and i1 %500, %501
  %503 = extractelement <8 x float> %468, i32 %498
  %504 = select i1 %502, float %503, float 0.000000e+00
  %505 = insertelement <8 x float> %492, float %504, i64 2
  %506 = xor i1 %502, true
  %507 = and i1 %500, %506
  %508 = insertelement <8 x i1> %495, i1 %507, i64 2
  %509 = extractelement <8 x i32> %469, i64 3
  %510 = icmp ult i32 %509, 8
  %511 = select i1 %510, i32 %509, i32 0
  %512 = extractelement <8 x i1> %51, i32 %511
  %513 = extractelement <8 x i1> %51, i64 3
  %514 = and i1 %510, %512
  %515 = and i1 %513, %514
  %516 = extractelement <8 x float> %468, i32 %511
  %517 = select i1 %515, float %516, float 0.000000e+00
  %518 = insertelement <8 x float> %505, float %517, i64 3
  %519 = xor i1 %515, true
  %520 = and i1 %513, %519
  %521 = insertelement <8 x i1> %508, i1 %520, i64 3
  %522 = extractelement <8 x i32> %469, i64 4
  %523 = icmp ult i32 %522, 8
  %524 = select i1 %523, i32 %522, i32 0
  %525 = extractelement <8 x i1> %51, i32 %524
  %526 = extractelement <8 x i1> %51, i64 4
  %527 = and i1 %523, %525
  %528 = and i1 %526, %527
  %529 = extractelement <8 x float> %468, i32 %524
  %530 = select i1 %528, float %529, float 0.000000e+00
  %531 = insertelement <8 x float> %518, float %530, i64 4
  %532 = xor i1 %528, true
  %533 = and i1 %526, %532
  %534 = insertelement <8 x i1> %521, i1 %533, i64 4
  %535 = extractelement <8 x i32> %469, i64 5
  %536 = icmp ult i32 %535, 8
  %537 = select i1 %536, i32 %535, i32 0
  %538 = extractelement <8 x i1> %51, i32 %537
  %539 = extractelement <8 x i1> %51, i64 5
  %540 = and i1 %536, %538
  %541 = and i1 %539, %540
  %542 = extractelement <8 x float> %468, i32 %537
  %543 = select i1 %541, float %542, float 0.000000e+00
  %544 = insertelement <8 x float> %531, float %543, i64 5
  %545 = xor i1 %541, true
  %546 = and i1 %539, %545
  %547 = insertelement <8 x i1> %534, i1 %546, i64 5
  %548 = extractelement <8 x i32> %469, i64 6
  %549 = icmp ult i32 %548, 8
  %550 = select i1 %549, i32 %548, i32 0
  %551 = extractelement <8 x i1> %51, i32 %550
  %552 = extractelement <8 x i1> %51, i64 6
  %553 = and i1 %549, %551
  %554 = and i1 %552, %553
  %555 = extractelement <8 x float> %468, i32 %550
  %556 = select i1 %554, float %555, float 0.000000e+00
  %557 = insertelement <8 x float> %544, float %556, i64 6
  %558 = xor i1 %554, true
  %559 = and i1 %552, %558
  %560 = insertelement <8 x i1> %547, i1 %559, i64 6
  %561 = extractelement <8 x i32> %469, i64 7
  %562 = icmp ult i32 %561, 8
  %563 = select i1 %562, i32 %561, i32 0
  %564 = extractelement <8 x i1> %51, i32 %563
  %565 = extractelement <8 x i1> %51, i64 7
  %566 = and i1 %562, %564
  %567 = and i1 %565, %566
  %568 = extractelement <8 x float> %468, i32 %563
  %569 = select i1 %567, float %568, float 0.000000e+00
  %570 = insertelement <8 x float> %557, float %569, i64 7
  %571 = xor i1 %567, true
  %572 = and i1 %565, %571
  %573 = insertelement <8 x i1> %560, i1 %572, i64 7
  %574 = fadd <8 x float> %468, %570
  %575 = xor <8 x i32> %362, splat (i32 4)
  %576 = extractelement <8 x i32> %575, i64 0
  %577 = icmp ult i32 %576, 8
  %578 = select i1 %577, i32 %576, i32 0
  %579 = extractelement <8 x i1> %51, i32 %578
  %580 = extractelement <8 x i1> %51, i64 0
  %581 = and i1 %577, %579
  %582 = and i1 %580, %581
  %583 = extractelement <8 x float> %574, i32 %578
  %584 = select i1 %582, float %583, float 0.000000e+00
  %585 = insertelement <8 x float> poison, float %584, i64 0
  %586 = xor i1 %582, true
  %587 = and i1 %580, %586
  %588 = insertelement <8 x i1> poison, i1 %587, i64 0
  %589 = extractelement <8 x i32> %575, i64 1
  %590 = icmp ult i32 %589, 8
  %591 = select i1 %590, i32 %589, i32 0
  %592 = extractelement <8 x i1> %51, i32 %591
  %593 = extractelement <8 x i1> %51, i64 1
  %594 = and i1 %590, %592
  %595 = and i1 %593, %594
  %596 = extractelement <8 x float> %574, i32 %591
  %597 = select i1 %595, float %596, float 0.000000e+00
  %598 = insertelement <8 x float> %585, float %597, i64 1
  %599 = xor i1 %595, true
  %600 = and i1 %593, %599
  %601 = insertelement <8 x i1> %588, i1 %600, i64 1
  %602 = extractelement <8 x i32> %575, i64 2
  %603 = icmp ult i32 %602, 8
  %604 = select i1 %603, i32 %602, i32 0
  %605 = extractelement <8 x i1> %51, i32 %604
  %606 = extractelement <8 x i1> %51, i64 2
  %607 = and i1 %603, %605
  %608 = and i1 %606, %607
  %609 = extractelement <8 x float> %574, i32 %604
  %610 = select i1 %608, float %609, float 0.000000e+00
  %611 = insertelement <8 x float> %598, float %610, i64 2
  %612 = xor i1 %608, true
  %613 = and i1 %606, %612
  %614 = insertelement <8 x i1> %601, i1 %613, i64 2
  %615 = extractelement <8 x i32> %575, i64 3
  %616 = icmp ult i32 %615, 8
  %617 = select i1 %616, i32 %615, i32 0
  %618 = extractelement <8 x i1> %51, i32 %617
  %619 = extractelement <8 x i1> %51, i64 3
  %620 = and i1 %616, %618
  %621 = and i1 %619, %620
  %622 = extractelement <8 x float> %574, i32 %617
  %623 = select i1 %621, float %622, float 0.000000e+00
  %624 = insertelement <8 x float> %611, float %623, i64 3
  %625 = xor i1 %621, true
  %626 = and i1 %619, %625
  %627 = insertelement <8 x i1> %614, i1 %626, i64 3
  %628 = extractelement <8 x i32> %575, i64 4
  %629 = icmp ult i32 %628, 8
  %630 = select i1 %629, i32 %628, i32 0
  %631 = extractelement <8 x i1> %51, i32 %630
  %632 = extractelement <8 x i1> %51, i64 4
  %633 = and i1 %629, %631
  %634 = and i1 %632, %633
  %635 = extractelement <8 x float> %574, i32 %630
  %636 = select i1 %634, float %635, float 0.000000e+00
  %637 = insertelement <8 x float> %624, float %636, i64 4
  %638 = xor i1 %634, true
  %639 = and i1 %632, %638
  %640 = insertelement <8 x i1> %627, i1 %639, i64 4
  %641 = extractelement <8 x i32> %575, i64 5
  %642 = icmp ult i32 %641, 8
  %643 = select i1 %642, i32 %641, i32 0
  %644 = extractelement <8 x i1> %51, i32 %643
  %645 = extractelement <8 x i1> %51, i64 5
  %646 = and i1 %642, %644
  %647 = and i1 %645, %646
  %648 = extractelement <8 x float> %574, i32 %643
  %649 = select i1 %647, float %648, float 0.000000e+00
  %650 = insertelement <8 x float> %637, float %649, i64 5
  %651 = xor i1 %647, true
  %652 = and i1 %645, %651
  %653 = insertelement <8 x i1> %640, i1 %652, i64 5
  %654 = extractelement <8 x i32> %575, i64 6
  %655 = icmp ult i32 %654, 8
  %656 = select i1 %655, i32 %654, i32 0
  %657 = extractelement <8 x i1> %51, i32 %656
  %658 = extractelement <8 x i1> %51, i64 6
  %659 = and i1 %655, %657
  %660 = and i1 %658, %659
  %661 = extractelement <8 x float> %574, i32 %656
  %662 = select i1 %660, float %661, float 0.000000e+00
  %663 = insertelement <8 x float> %650, float %662, i64 6
  %664 = xor i1 %660, true
  %665 = and i1 %658, %664
  %666 = insertelement <8 x i1> %653, i1 %665, i64 6
  %667 = extractelement <8 x i32> %575, i64 7
  %668 = icmp ult i32 %667, 8
  %669 = select i1 %668, i32 %667, i32 0
  %670 = extractelement <8 x i1> %51, i32 %669
  %671 = extractelement <8 x i1> %51, i64 7
  %672 = and i1 %668, %670
  %673 = and i1 %671, %672
  %674 = extractelement <8 x float> %574, i32 %669
  %675 = select i1 %673, float %674, float 0.000000e+00
  %676 = insertelement <8 x float> %663, float %675, i64 7
  %677 = xor i1 %673, true
  %678 = and i1 %671, %677
  %679 = insertelement <8 x i1> %666, i1 %678, i64 7
  %680 = fadd <8 x float> %574, %676
  %681 = extractelement <8 x i1> %51, i32 0
  %682 = extractelement <8 x i1> %51, i64 0
  %683 = and i1 true, %681
  %684 = and i1 %682, %683
  %685 = extractelement <8 x float> %680, i32 0
  %686 = select i1 %684, float %685, float 0.000000e+00
  %687 = insertelement <8 x float> poison, float %686, i64 0
  %688 = xor i1 %684, true
  %689 = and i1 %682, %688
  %690 = insertelement <8 x i1> poison, i1 %689, i64 0
  %691 = extractelement <8 x i1> %51, i32 0
  %692 = extractelement <8 x i1> %51, i64 1
  %693 = and i1 true, %691
  %694 = and i1 %692, %693
  %695 = extractelement <8 x float> %680, i32 0
  %696 = select i1 %694, float %695, float 0.000000e+00
  %697 = insertelement <8 x float> %687, float %696, i64 1
  %698 = xor i1 %694, true
  %699 = and i1 %692, %698
  %700 = insertelement <8 x i1> %690, i1 %699, i64 1
  %701 = extractelement <8 x i1> %51, i32 0
  %702 = extractelement <8 x i1> %51, i64 2
  %703 = and i1 true, %701
  %704 = and i1 %702, %703
  %705 = extractelement <8 x float> %680, i32 0
  %706 = select i1 %704, float %705, float 0.000000e+00
  %707 = insertelement <8 x float> %697, float %706, i64 2
  %708 = xor i1 %704, true
  %709 = and i1 %702, %708
  %710 = insertelement <8 x i1> %700, i1 %709, i64 2
  %711 = extractelement <8 x i1> %51, i32 0
  %712 = extractelement <8 x i1> %51, i64 3
  %713 = and i1 true, %711
  %714 = and i1 %712, %713
  %715 = extractelement <8 x float> %680, i32 0
  %716 = select i1 %714, float %715, float 0.000000e+00
  %717 = insertelement <8 x float> %707, float %716, i64 3
  %718 = xor i1 %714, true
  %719 = and i1 %712, %718
  %720 = insertelement <8 x i1> %710, i1 %719, i64 3
  %721 = extractelement <8 x i1> %51, i32 0
  %722 = extractelement <8 x i1> %51, i64 4
  %723 = and i1 true, %721
  %724 = and i1 %722, %723
  %725 = extractelement <8 x float> %680, i32 0
  %726 = select i1 %724, float %725, float 0.000000e+00
  %727 = insertelement <8 x float> %717, float %726, i64 4
  %728 = xor i1 %724, true
  %729 = and i1 %722, %728
  %730 = insertelement <8 x i1> %720, i1 %729, i64 4
  %731 = extractelement <8 x i1> %51, i32 0
  %732 = extractelement <8 x i1> %51, i64 5
  %733 = and i1 true, %731
  %734 = and i1 %732, %733
  %735 = extractelement <8 x float> %680, i32 0
  %736 = select i1 %734, float %735, float 0.000000e+00
  %737 = insertelement <8 x float> %727, float %736, i64 5
  %738 = xor i1 %734, true
  %739 = and i1 %732, %738
  %740 = insertelement <8 x i1> %730, i1 %739, i64 5
  %741 = extractelement <8 x i1> %51, i32 0
  %742 = extractelement <8 x i1> %51, i64 6
  %743 = and i1 true, %741
  %744 = and i1 %742, %743
  %745 = extractelement <8 x float> %680, i32 0
  %746 = select i1 %744, float %745, float 0.000000e+00
  %747 = insertelement <8 x float> %737, float %746, i64 6
  %748 = xor i1 %744, true
  %749 = and i1 %742, %748
  %750 = insertelement <8 x i1> %740, i1 %749, i64 6
  %751 = extractelement <8 x i1> %51, i32 0
  %752 = extractelement <8 x i1> %51, i64 7
  %753 = and i1 true, %751
  %754 = and i1 %752, %753
  %755 = extractelement <8 x float> %680, i32 0
  %756 = select i1 %754, float %755, float 0.000000e+00
  %757 = insertelement <8 x float> %747, float %756, i64 7
  %758 = xor i1 %754, true
  %759 = and i1 %752, %758
  %760 = insertelement <8 x i1> %750, i1 %759, i64 7
  %761 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %762 = bitcast <8 x i1> %51 to i8
  %763 = call i8 @llvm.cttz.i8(i8 %762, i1 false)
  %764 = zext i8 %763 to i32
  %765 = select i1 %761, i32 %764, i32 0
  %766 = extractelement <8 x float> %757, i32 %765
  %.spill.load95 = load float, ptr %.spill6, align 4
  %767 = fadd float %.spill.load95, %766
  %768 = fdiv float %767, 1.023000e+03
  store float %768, ptr %.spill16, align 4
  %769 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %770 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %771 = extractvalue { <8 x ptr>, <8 x i64> } %769, 0
  %772 = select <8 x i1> %51, <8 x ptr> %770, <8 x ptr> %771
  %773 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %774 = extractvalue { <8 x ptr>, <8 x i64> } %769, 1
  %775 = select <8 x i1> %51, <8 x i64> %773, <8 x i64> %774
  %776 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %772, 0
  %777 = insertvalue { <8 x ptr>, <8 x i64> } %776, <8 x i64> %775, 1
  store { <8 x ptr>, <8 x i64> } %777, ptr %tile_snapshot.spill17, align 64
  %778 = load <8 x i64>, ptr %.slot18, align 64
  %779 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %778
  store <8 x i64> %779, ptr %.slot18, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state96 = load <8 x i64>, ptr %.slot18, align 64
  %780 = icmp slt <8 x i64> %.state96, splat (i64 127)
  %781 = extractelement <8 x i1> %780, i32 0
  br i1 %781, label %direct.true97, label %direct.false98

direct.schedule.12:                               ; preds = %direct.true97
  %.state99 = load <8 x i64>, ptr %.slot18, align 64
  %782 = mul <8 x i64> %.state99, splat (i64 8)
  %.spill.load100 = load <8 x i64>, ptr %.spill, align 64
  %783 = add <8 x i64> %782, %.spill.load100
  %.spill.load101 = load i64, ptr %.spill7, align 4
  %784 = add i64 %.spill.load101, 0
  %785 = add <8 x i64> zeroinitializer, %783
  %786 = mul i64 %784, 1023
  %.splatinsert102 = insertelement <8 x i64> poison, i64 %786, i64 0
  %.splat103 = shufflevector <8 x i64> %.splatinsert102, <8 x i64> poison, <8 x i32> zeroinitializer
  %787 = add <8 x i64> %.splat103, %785
  %788 = extractvalue { ptr, i64 } %15, 0
  %789 = extractelement <8 x i64> %787, i32 0
  %790 = sub i64 %789, 0
  %791 = mul i64 %790, 4
  %buffer.contiguous.address104 = getelementptr i8, ptr %788, i64 %791
  %buffer.contiguous.load105 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address104, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load106 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %792 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 0
  %793 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 1
  %.state107 = load <8 x i64>, ptr %.slot18, align 64
  %794 = mul <8 x i64> %.state107, splat (i64 32)
  %795 = add <8 x i64> %793, %794
  %796 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %792, 0
  %797 = insertvalue { <8 x ptr>, <8 x i64> } %796, <8 x i64> %795, 1
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %797, 0
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %797, 1
  %800 = getelementptr i8, <8 x ptr> %798, <8 x i64> %799
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %buffer.contiguous.load105, <8 x ptr> %800, i32 1, <8 x i1> %51)
  %.state108 = load <8 x i64>, ptr %.slot18, align 64
  %801 = add <8 x i64> %.state108, splat (i64 1)
  %802 = load <8 x i64>, ptr %.slot18, align 64
  %803 = select <8 x i1> %51, <8 x i64> %801, <8 x i64> %802
  store <8 x i64> %803, ptr %.slot18, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false98
  %.spill.load109 = load <8 x i1>, ptr %.spill5, align 1
  %804 = and <8 x i1> %51, %.spill.load109
  %805 = xor <8 x i1> %.spill.load109, splat (i1 true)
  %806 = and <8 x i1> %51, %805
  %807 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %804)
  %808 = bitcast <8 x i1> %804 to i8
  %809 = call i8 @llvm.cttz.i8(i8 %808, i1 false)
  %810 = zext i8 %809 to i32
  %811 = select i1 %807, i32 %810, i32 0
  %.spill.load110 = load <8 x i64>, ptr %.spill, align 64
  %812 = add <8 x i64> splat (i64 1016), %.spill.load110
  %.spill.load111 = load i64, ptr %.spill7, align 4
  %813 = add i64 %.spill.load111, 0
  %814 = add <8 x i64> zeroinitializer, %812
  %815 = mul i64 %813, 1023
  %.splatinsert112 = insertelement <8 x i64> poison, i64 %815, i64 0
  %.splat113 = shufflevector <8 x i64> %.splatinsert112, <8 x i64> poison, <8 x i32> zeroinitializer
  %816 = add <8 x i64> %.splat113, %814
  %817 = extractvalue { ptr, i64 } %15, 0
  %818 = select <8 x i1> %804, <8 x i64> %816, <8 x i64> zeroinitializer
  %819 = extractelement <8 x i64> %818, i32 %811
  %820 = zext i32 %811 to i64
  %821 = sub i64 %819, %820
  %822 = mul i64 %821, 4
  %buffer.contiguous.address114 = getelementptr i8, ptr %817, i64 %822
  %buffer.contiguous.load115 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address114, i32 1, <8 x i1> %804, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load116 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %823 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 0
  %824 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load116, 1
  %825 = add <8 x i64> %824, splat (i64 4064)
  %826 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %823, 0
  %827 = insertvalue { <8 x ptr>, <8 x i64> } %826, <8 x i64> %825, 1
  %828 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %829 = extractvalue { <8 x ptr>, <8 x i64> } %827, 1
  %830 = extractelement <8 x ptr> %828, i32 0
  %831 = extractelement <8 x i64> %829, i32 %811
  %832 = zext i32 %811 to i64
  %833 = mul i64 %832, 4
  %834 = sub i64 %831, %833
  %835 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %804)
  %836 = select i1 %835, i64 %834, i64 0
  %private.contiguous.address117 = getelementptr i8, ptr %830, i64 %836
  %private.contiguous.preserve118 = load <8 x float>, ptr %private.contiguous.address117, align 4
  %837 = select <8 x i1> %804, <8 x float> %buffer.contiguous.load115, <8 x float> %private.contiguous.preserve118
  store <8 x float> %837, ptr %private.contiguous.address117, align 4
  %838 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %806)
  %839 = bitcast <8 x i1> %806 to i8
  %840 = call i8 @llvm.cttz.i8(i8 %839, i1 false)
  %841 = zext i8 %840 to i32
  %842 = select i1 %838, i32 %841, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  %.spill.load119 = load float, ptr %.spill16, align 4
  %843 = fadd float %.spill.load119, 0x3EE4F8B580000000
  %844 = call float @llvm.sqrt.f32(float %843)
  store float %844, ptr %.spill19, align 4
  %845 = load <8 x i64>, ptr %.slot20, align 64
  %846 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %845
  store <8 x i64> %846, ptr %.slot20, align 64
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state120 = load <8 x i64>, ptr %.slot20, align 64
  %847 = icmp slt <8 x i64> %.state120, splat (i64 127)
  %848 = extractelement <8 x i1> %847, i32 0
  br i1 %848, label %direct.true121, label %direct.false122

direct.schedule.17:                               ; preds = %direct.true121
  %.state123 = load <8 x i64>, ptr %.slot20, align 64
  %849 = mul <8 x i64> %.state123, splat (i64 8)
  %.spill.load124 = load <8 x i64>, ptr %.spill, align 64
  %850 = add <8 x i64> %849, %.spill.load124
  %.spill.load125 = load <8 x i64>, ptr %.spill4, align 64
  %851 = add <8 x i64> %.spill.load125, zeroinitializer
  %852 = add <8 x i64> zeroinitializer, %851
  %853 = add <8 x i64> zeroinitializer, %850
  %854 = mul <8 x i64> %852, splat (i64 1023)
  %855 = add <8 x i64> %854, %853
  %tile_snapshot.spill.load126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %856 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 0
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 1
  %.state127 = load <8 x i64>, ptr %.slot20, align 64
  %858 = mul <8 x i64> %.state127, splat (i64 32)
  %859 = add <8 x i64> %857, %858
  %860 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %856, 0
  %861 = insertvalue { <8 x ptr>, <8 x i64> } %860, <8 x i64> %859, 1
  %862 = extractvalue { <8 x ptr>, <8 x i64> } %861, 0
  %863 = extractvalue { <8 x ptr>, <8 x i64> } %861, 1
  %864 = getelementptr i8, <8 x ptr> %862, <8 x i64> %863
  %865 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %864, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %.spill.load128 = load float, ptr %.spill19, align 4
  %.splatinsert129 = insertelement <8 x float> poison, float %.spill.load128, i64 0
  %.splat130 = shufflevector <8 x float> %.splatinsert129, <8 x float> poison, <8 x i32> zeroinitializer
  %866 = fdiv <8 x float> %865, %.splat130
  %tile_snapshot.spill.load131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %867 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 0
  %868 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 1
  %.state132 = load <8 x i64>, ptr %.slot20, align 64
  %869 = mul <8 x i64> %.state132, splat (i64 32)
  %870 = add <8 x i64> %868, %869
  %871 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %867, 0
  %872 = insertvalue { <8 x ptr>, <8 x i64> } %871, <8 x i64> %870, 1
  %873 = extractvalue { <8 x ptr>, <8 x i64> } %872, 0
  %874 = extractvalue { <8 x ptr>, <8 x i64> } %872, 1
  %875 = getelementptr i8, <8 x ptr> %873, <8 x i64> %874
  %876 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %875, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %877 = fmul <8 x float> %866, %876
  %878 = extractvalue { ptr, i64 } %27, 0
  %879 = extractelement <8 x i64> %855, i32 0
  %880 = sub i64 %879, 0
  %881 = mul i64 %880, 4
  %buffer.contiguous.address133 = getelementptr i8, ptr %878, i64 %881
  call void @llvm.masked.store.v8f32.p0(<8 x float> %877, ptr %buffer.contiguous.address133, i32 1, <8 x i1> %51)
  %.state134 = load <8 x i64>, ptr %.slot20, align 64
  %882 = add <8 x i64> %.state134, splat (i64 1)
  %883 = load <8 x i64>, ptr %.slot20, align 64
  %884 = select <8 x i1> %51, <8 x i64> %882, <8 x i64> %883
  store <8 x i64> %884, ptr %.slot20, align 64
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false122
  %.spill.load135 = load <8 x i1>, ptr %.spill5, align 1
  %885 = and <8 x i1> %51, %.spill.load135
  %886 = xor <8 x i1> %.spill.load135, splat (i1 true)
  %887 = and <8 x i1> %51, %886
  %888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %885)
  %889 = bitcast <8 x i1> %885 to i8
  %890 = call i8 @llvm.cttz.i8(i8 %889, i1 false)
  %891 = zext i8 %890 to i32
  %892 = select i1 %888, i32 %891, i32 0
  %.spill.load136 = load <8 x i64>, ptr %.spill, align 64
  %893 = add <8 x i64> splat (i64 1016), %.spill.load136
  %.spill.load137 = load <8 x i64>, ptr %.spill4, align 64
  %894 = add <8 x i64> %.spill.load137, zeroinitializer
  %895 = add <8 x i64> zeroinitializer, %894
  %896 = add <8 x i64> zeroinitializer, %893
  %897 = mul <8 x i64> %895, splat (i64 1023)
  %898 = add <8 x i64> %897, %896
  %tile_snapshot.spill.load138 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %899 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 0
  %900 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 1
  %901 = add <8 x i64> %900, splat (i64 4064)
  %902 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %899, 0
  %903 = insertvalue { <8 x ptr>, <8 x i64> } %902, <8 x i64> %901, 1
  %904 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %905 = extractvalue { <8 x ptr>, <8 x i64> } %903, 1
  %906 = extractelement <8 x ptr> %904, i32 0
  %907 = extractelement <8 x i64> %905, i32 %892
  %908 = zext i32 %892 to i64
  %909 = mul i64 %908, 4
  %910 = sub i64 %907, %909
  %911 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %885)
  %912 = select i1 %911, i64 %910, i64 0
  %private.contiguous.address139 = getelementptr i8, ptr %906, i64 %912
  %private.contiguous.load140 = load <8 x float>, ptr %private.contiguous.address139, align 4
  %913 = select <8 x i1> %885, <8 x float> %private.contiguous.load140, <8 x float> zeroinitializer
  %.spill.load141 = load float, ptr %.spill19, align 4
  %.splatinsert142 = insertelement <8 x float> poison, float %.spill.load141, i64 0
  %.splat143 = shufflevector <8 x float> %.splatinsert142, <8 x float> poison, <8 x i32> zeroinitializer
  %914 = fdiv <8 x float> %913, %.splat143
  %tile_snapshot.spill.load144 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %915 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 0
  %916 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 1
  %917 = add <8 x i64> %916, splat (i64 4064)
  %918 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %915, 0
  %919 = insertvalue { <8 x ptr>, <8 x i64> } %918, <8 x i64> %917, 1
  %920 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %921 = extractvalue { <8 x ptr>, <8 x i64> } %919, 1
  %922 = extractelement <8 x ptr> %920, i32 0
  %923 = extractelement <8 x i64> %921, i32 %892
  %924 = zext i32 %892 to i64
  %925 = mul i64 %924, 4
  %926 = sub i64 %923, %925
  %927 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %885)
  %928 = select i1 %927, i64 %926, i64 0
  %private.contiguous.address145 = getelementptr i8, ptr %922, i64 %928
  %private.contiguous.load146 = load <8 x float>, ptr %private.contiguous.address145, align 4
  %929 = select <8 x i1> %885, <8 x float> %private.contiguous.load146, <8 x float> zeroinitializer
  %930 = fmul <8 x float> %914, %929
  %931 = extractvalue { ptr, i64 } %27, 0
  %932 = extractelement <8 x i64> %898, i32 %892
  %933 = zext i32 %892 to i64
  %934 = sub i64 %932, %933
  %935 = mul i64 %934, 4
  %buffer.contiguous.address147 = getelementptr i8, ptr %931, i64 %935
  call void @llvm.masked.store.v8f32.p0(<8 x float> %930, ptr %buffer.contiguous.address147, i32 1, <8 x i1> %885)
  %936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %887)
  %937 = bitcast <8 x i1> %887 to i8
  %938 = call i8 @llvm.cttz.i8(i8 %937, i1 false)
  %939 = zext i8 %938 to i32
  %940 = select i1 %936, i32 %939, i32 0
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true59:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false60:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true97:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false98:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true121:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false122:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

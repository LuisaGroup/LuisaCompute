
/private/tmp/luisa-cohort-private.qfZvpM/native-137x1023/inductor/ww/cww7i7a62on5i5qtfpckgm3u4fmzzr7wb3p7mccahphwz5zzt5tb.main.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0xc0
     6b4:      	stp	d11, d10, [sp, #0x40]
     6b8:      	stp	d9, d8, [sp, #0x50]
     6bc:      	stp	x28, x27, [sp, #0x60]
     6c0:      	stp	x26, x25, [sp, #0x70]
     6c4:      	stp	x24, x23, [sp, #0x80]
     6c8:      	stp	x22, x21, [sp, #0x90]
     6cc:      	stp	x20, x19, [sp, #0xa0]
     6d0:      	stp	x29, x30, [sp, #0xb0]
     6d4:      	add	x29, sp, #0xb0
     6d8:      	mov	x19, #0x0               ; =0
     6dc:      	str	wzr, [sp, #0x20]
     6e0:      	adrp	x20, 0x4000 <dyld_stub_binder+0x4000>
     6e4:      	ldr	x20, [x20, #0x98]
     6e8:      	add	x8, sp, #0x20
     6ec:      	str	x8, [x20]
     6f0:      	mov	w8, #0xc000             ; =49152
     6f4:      	movk	w8, #0x447f, lsl #16
     6f8:      	fmov	s8, w8
     6fc:      	mov	w8, #0xc5ac             ; =50604
     700:      	movk	w8, #0x3727, lsl #16
     704:      	fmov	s9, w8
     708:      	adrp	x21, 0x4000 <dyld_stub_binder+0x4000>
     70c:      	ldr	x21, [x21, #0x80]
     710:      	movi.2d	v10, #0000000000000000
     714:      	fmov	s11, #1.00000000
     718:      	ldr	q0, [x21]
     71c:      	mov	x9, #-0x4               ; =-4
     720:      	mov	x8, x0
     724:      	movi.2d	v1, #0000000000000000
     728:      	ldr	q2, [x8], #0x10
     72c:      	fmul.4s	v2, v2, v2
     730:      	fadd.4s	v1, v1, v2
     734:      	add	x9, x9, #0x4
     738:      	cmp	x9, #0x3f8
     73c:      	b.lo	0x728 <_kernel+0x78>
     740:      	mov	x22, #0x0               ; =0
     744:      	ldr	d2, [x8], #0x8
     748:      	movi.2d	v3, #0000000000000000
     74c:      	mov.s	v3[0], v2[0]
     750:      	mov.s	v3[1], v2[1]
     754:      	ld1.s	{ v3 }[2], [x8]
     758:      	fmul.4s	v2, v3, v3
     75c:      	fadd.4s	v2, v1, v2
     760:      	bsl.16b	v0, v2, v1
     764:      	dup.2d	v1, v0[1]
     768:      	fadd.4s	v0, v1, v0
     76c:      	faddp.2s	s0, v0
     770:      	fadd	s0, s0, s10
     774:      	str	s0, [x2, x19, lsl #2]
     778:      	mov	x23, #-0x4              ; =-4
     77c:      	ldr	q2, [x0, x22]
     780:      	ldr	s0, [x2, x19, lsl #2]
     784:      	ldr	q3, [x1, x22]
     788:      	fdiv	s0, s0, s8
     78c:      	fadd	s1, s0, s9
     790:      	fsqrt	s0, s1
     794:      	fcmp	s0, s0
     798:      	b.vs	0x7c0 <_kernel+0x110>
     79c:      	fdiv	s0, s11, s0
     7a0:      	fmul.4s	v0, v2, v0[0]
     7a4:      	fmul.4s	v0, v3, v0
     7a8:      	str	q0, [x3, x22]
     7ac:      	add	x23, x23, #0x4
     7b0:      	add	x22, x22, #0x10
     7b4:      	cmp	x23, #0x3f8
     7b8:      	b.lo	0x77c <_kernel+0xcc>
     7bc:      	b	0x7f4 <_kernel+0x144>
     7c0:      	mov.16b	v0, v1
     7c4:      	mov	x24, x3
     7c8:      	mov	x26, x2
     7cc:      	mov	x25, x1
     7d0:      	mov	x27, x0
     7d4:      	stp	q3, q2, [sp]
     7d8:      	bl	0x1838 <dyld_stub_binder+0x1838>
     7dc:      	ldp	q3, q2, [sp]
     7e0:      	mov	x0, x27
     7e4:      	mov	x1, x25
     7e8:      	mov	x2, x26
     7ec:      	mov	x3, x24
     7f0:      	b	0x79c <_kernel+0xec>
     7f4:      	add	x8, x0, x22
     7f8:      	add	x9, x8, #0x8
     7fc:      	ldr	d2, [x8]
     800:      	ld1.s	{ v2 }[2], [x9]
     804:      	ldr	s0, [x2, x19, lsl #2]
     808:      	add	x8, x1, x22
     80c:      	add	x9, x8, #0x8
     810:      	ldr	d3, [x8]
     814:      	ld1.s	{ v3 }[2], [x9]
     818:      	fdiv	s0, s0, s8
     81c:      	fadd	s1, s0, s9
     820:      	fsqrt	s0, s1
     824:      	fcmp	s0, s0
     828:      	b.vs	0x860 <_kernel+0x1b0>
     82c:      	fdiv	s0, s11, s0
     830:      	add	x8, x3, x22
     834:      	fmul.4s	v0, v2, v0[0]
     838:      	fmul.4s	v0, v3, v0
     83c:      	add	x9, x8, #0x8
     840:      	st1.s	{ v0 }[2], [x9]
     844:      	str	d0, [x8]
     848:      	add	x19, x19, #0x1
     84c:      	add	x0, x0, #0xffc
     850:      	add	x3, x3, #0xffc
     854:      	cmp	x19, #0x89
     858:      	b.ne	0x718 <_kernel+0x68>
     85c:      	b	0x894 <_kernel+0x1e4>
     860:      	mov.16b	v0, v1
     864:      	mov	x23, x3
     868:      	mov	x25, x2
     86c:      	mov	x24, x1
     870:      	mov	x26, x0
     874:      	stp	q3, q2, [sp]
     878:      	bl	0x1838 <dyld_stub_binder+0x1838>
     87c:      	ldp	q3, q2, [sp]
     880:      	mov	x0, x26
     884:      	mov	x1, x24
     888:      	mov	x2, x25
     88c:      	mov	x3, x23
     890:      	b	0x82c <_kernel+0x17c>
     894:      	str	xzr, [x20]
     898:      	add	x8, sp, #0x20
     89c:      	ldapr	w8, [x8]
     8a0:      	cbnz	w8, 0x8cc <_kernel+0x21c>
     8a4:      	ldp	x29, x30, [sp, #0xb0]
     8a8:      	ldp	x20, x19, [sp, #0xa0]
     8ac:      	ldp	x22, x21, [sp, #0x90]
     8b0:      	ldp	x24, x23, [sp, #0x80]
     8b4:      	ldp	x26, x25, [sp, #0x70]
     8b8:      	ldp	x28, x27, [sp, #0x60]
     8bc:      	ldp	d9, d8, [sp, #0x50]
     8c0:      	ldp	d11, d10, [sp, #0x40]
     8c4:      	add	sp, sp, #0xc0
     8c8:      	ret
     8cc:      	mov	w0, #0x10               ; =16
     8d0:      	bl	0x17cc <dyld_stub_binder+0x17cc>
     8d4:      	mov	x19, x0
     8d8:      	mov	w8, #0x33d              ; =829
     8dc:      	str	w8, [sp, #0x24]
     8e0:      	adrp	x0, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xd4>
     8e4:      	add	x0, x0, #0xb08
     8e8:      	adrp	x1, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xd4>
     8ec:      	add	x1, x1, #0xb94
     8f0:      	adrp	x3, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xd4>
     8f4:      	add	x3, x3, #0xbbf
     8f8:      	adrp	x4, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xd4>
     8fc:      	add	x4, x4, #0xc3d
     900:      	adrp	x2, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xd4>
     904:      	add	x2, x2, #0xbbc
     908:      	add	x8, sp, #0x28
     90c:      	add	x5, sp, #0x24
     910:      	adrp	x7, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xd4>
     914:      	add	x7, x7, #0xc3f
     918:      	mov	x6, x2
     91c:      	bl	0x990 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     920:      	mov	w21, #0x1               ; =1
     924:      	add	x1, sp, #0x28
     928:      	mov	x0, x19
     92c:      	bl	0x1718 <dyld_stub_binder+0x1718>
     930:      	mov	w21, #0x0               ; =0
     934:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     938:      	ldr	x1, [x1, #0x18]
     93c:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     940:      	ldr	x2, [x2, #0x8]
     944:      	mov	x0, x19
     948:      	bl	0x17fc <dyld_stub_binder+0x17fc>
     94c:      	brk	#0x1
     950:      	mov	x20, x0
     954:      	ldrsb	w8, [sp, #0x3f]
     958:      	tbz	w8, #0x1f, 0x974 <_kernel+0x2c4>
     95c:      	ldr	x0, [sp, #0x28]
     960:      	ldr	x8, [sp, #0x38]
     964:      	and	x1, x8, #0x7fffffffffffffff
     968:      	bl	0x17b4 <dyld_stub_binder+0x17b4>
     96c:      	tbnz	w21, #0x0, 0x980 <_kernel+0x2d0>
     970:      	b	0x988 <_kernel+0x2d8>
     974:      	cbnz	w21, 0x980 <_kernel+0x2d0>
     978:      	b	0x988 <_kernel+0x2d8>
     97c:      	mov	x20, x0
     980:      	mov	x0, x19
     984:      	bl	0x17f0 <dyld_stub_binder+0x17f0>
     988:      	mov	x0, x20
     98c:      	bl	0x16dc <dyld_stub_binder+0x16dc>


/private/tmp/luisa-cohort-private.qfZvpM/native-513x2051/inductor/hy/chysqzitk2exfjphkdoo2u2o2fmkl54kqhnr37rxh4kyhkngqeby.main.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0xc0
     6b4:      	stp	d11, d10, [sp, #0x40]
     6b8:      	stp	d9, d8, [sp, #0x50]
     6bc:      	stp	x28, x27, [sp, #0x60]
     6c0:      	stp	x26, x25, [sp, #0x70]
     6c4:      	stp	x24, x23, [sp, #0x80]
     6c8:      	stp	x22, x21, [sp, #0x90]
     6cc:      	stp	x20, x19, [sp, #0xa0]
     6d0:      	stp	x29, x30, [sp, #0xb0]
     6d4:      	add	x29, sp, #0xb0
     6d8:      	mov	x19, #0x0               ; =0
     6dc:      	adrp	x20, 0x4000 <dyld_stub_binder+0x4000>
     6e0:      	ldr	x20, [x20, #0x98]
     6e4:      	str	wzr, [sp, #0x20]
     6e8:      	add	x8, sp, #0x20
     6ec:      	str	x8, [x20]
     6f0:      	adrp	x21, 0x4000 <dyld_stub_binder+0x4000>
     6f4:      	ldr	x21, [x21, #0x80]
     6f8:      	movi.2d	v8, #0000000000000000
     6fc:      	mov	w8, #0x3000             ; =12288
     700:      	movk	w8, #0x4500, lsl #16
     704:      	fmov	s9, w8
     708:      	mov	w8, #0xc5ac             ; =50604
     70c:      	movk	w8, #0x3727, lsl #16
     710:      	fmov	s10, w8
     714:      	fmov	s11, #1.00000000
     718:      	mov	w22, #0x200c            ; =8204
     71c:      	ldr	q0, [x21]
     720:      	mov	x9, #-0x4               ; =-4
     724:      	mov	x8, x0
     728:      	movi.2d	v1, #0000000000000000
     72c:      	ldr	q2, [x8], #0x10
     730:      	fmul.4s	v2, v2, v2
     734:      	fadd.4s	v1, v1, v2
     738:      	add	x9, x9, #0x4
     73c:      	cmp	x9, #0x7fc
     740:      	b.lo	0x72c <_kernel+0x7c>
     744:      	mov	x23, #0x0               ; =0
     748:      	ldr	d2, [x8], #0x8
     74c:      	movi.2d	v3, #0000000000000000
     750:      	mov.s	v3[0], v2[0]
     754:      	mov.s	v3[1], v2[1]
     758:      	ld1.s	{ v3 }[2], [x8]
     75c:      	fmul.4s	v2, v3, v3
     760:      	fadd.4s	v2, v1, v2
     764:      	bsl.16b	v0, v2, v1
     768:      	dup.2d	v1, v0[1]
     76c:      	fadd.4s	v0, v1, v0
     770:      	faddp.2s	s0, v0
     774:      	fadd	s0, s0, s8
     778:      	str	s0, [x2, x19, lsl #2]
     77c:      	mov	x24, #-0x4              ; =-4
     780:      	ldr	q2, [x0, x23]
     784:      	ldr	s0, [x2, x19, lsl #2]
     788:      	ldr	q3, [x1, x23]
     78c:      	fdiv	s0, s0, s9
     790:      	fadd	s1, s0, s10
     794:      	fsqrt	s0, s1
     798:      	fcmp	s0, s0
     79c:      	b.vs	0x7c4 <_kernel+0x114>
     7a0:      	fdiv	s0, s11, s0
     7a4:      	fmul.4s	v0, v2, v0[0]
     7a8:      	fmul.4s	v0, v3, v0
     7ac:      	str	q0, [x3, x23]
     7b0:      	add	x24, x24, #0x4
     7b4:      	add	x23, x23, #0x10
     7b8:      	cmp	x24, #0x7fc
     7bc:      	b.lo	0x780 <_kernel+0xd0>
     7c0:      	b	0x7f8 <_kernel+0x148>
     7c4:      	mov.16b	v0, v1
     7c8:      	mov	x25, x3
     7cc:      	mov	x27, x2
     7d0:      	mov	x26, x1
     7d4:      	mov	x28, x0
     7d8:      	stp	q3, q2, [sp]
     7dc:      	bl	0x183c <dyld_stub_binder+0x183c>
     7e0:      	ldp	q3, q2, [sp]
     7e4:      	mov	x0, x28
     7e8:      	mov	x1, x26
     7ec:      	mov	x2, x27
     7f0:      	mov	x3, x25
     7f4:      	b	0x7a0 <_kernel+0xf0>
     7f8:      	add	x8, x0, x23
     7fc:      	add	x9, x8, #0x8
     800:      	ldr	d2, [x8]
     804:      	ld1.s	{ v2 }[2], [x9]
     808:      	ldr	s0, [x2, x19, lsl #2]
     80c:      	add	x8, x1, x23
     810:      	add	x9, x8, #0x8
     814:      	ldr	d3, [x8]
     818:      	ld1.s	{ v3 }[2], [x9]
     81c:      	fdiv	s0, s0, s9
     820:      	fadd	s1, s0, s10
     824:      	fsqrt	s0, s1
     828:      	fcmp	s0, s0
     82c:      	b.vs	0x864 <_kernel+0x1b4>
     830:      	fdiv	s0, s11, s0
     834:      	add	x8, x3, x23
     838:      	fmul.4s	v0, v2, v0[0]
     83c:      	fmul.4s	v0, v3, v0
     840:      	add	x9, x8, #0x8
     844:      	st1.s	{ v0 }[2], [x9]
     848:      	str	d0, [x8]
     84c:      	add	x19, x19, #0x1
     850:      	add	x0, x0, x22
     854:      	add	x3, x3, x22
     858:      	cmp	x19, #0x201
     85c:      	b.ne	0x71c <_kernel+0x6c>
     860:      	b	0x898 <_kernel+0x1e8>
     864:      	mov.16b	v0, v1
     868:      	mov	x24, x3
     86c:      	mov	x26, x2
     870:      	mov	x25, x1
     874:      	mov	x27, x0
     878:      	stp	q3, q2, [sp]
     87c:      	bl	0x183c <dyld_stub_binder+0x183c>
     880:      	ldp	q3, q2, [sp]
     884:      	mov	x0, x27
     888:      	mov	x1, x25
     88c:      	mov	x2, x26
     890:      	mov	x3, x24
     894:      	b	0x830 <_kernel+0x180>
     898:      	str	xzr, [x20]
     89c:      	add	x8, sp, #0x20
     8a0:      	ldapr	w8, [x8]
     8a4:      	cbnz	w8, 0x8d0 <_kernel+0x220>
     8a8:      	ldp	x29, x30, [sp, #0xb0]
     8ac:      	ldp	x20, x19, [sp, #0xa0]
     8b0:      	ldp	x22, x21, [sp, #0x90]
     8b4:      	ldp	x24, x23, [sp, #0x80]
     8b8:      	ldp	x26, x25, [sp, #0x70]
     8bc:      	ldp	x28, x27, [sp, #0x60]
     8c0:      	ldp	d9, d8, [sp, #0x50]
     8c4:      	ldp	d11, d10, [sp, #0x40]
     8c8:      	add	sp, sp, #0xc0
     8cc:      	ret
     8d0:      	mov	w0, #0x10               ; =16
     8d4:      	bl	0x17d0 <dyld_stub_binder+0x17d0>
     8d8:      	mov	x19, x0
     8dc:      	mov	w8, #0x33d              ; =829
     8e0:      	str	w8, [sp, #0x24]
     8e4:      	adrp	x0, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xd0>
     8e8:      	add	x0, x0, #0xb0c
     8ec:      	adrp	x1, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xd0>
     8f0:      	add	x1, x1, #0xb98
     8f4:      	adrp	x3, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xd0>
     8f8:      	add	x3, x3, #0xbc3
     8fc:      	adrp	x4, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xd0>
     900:      	add	x4, x4, #0xc41
     904:      	adrp	x2, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xd0>
     908:      	add	x2, x2, #0xbc0
     90c:      	add	x8, sp, #0x28
     910:      	add	x5, sp, #0x24
     914:      	adrp	x7, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xd0>
     918:      	add	x7, x7, #0xc43
     91c:      	mov	x6, x2
     920:      	bl	0x994 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     924:      	mov	w21, #0x1               ; =1
     928:      	add	x1, sp, #0x28
     92c:      	mov	x0, x19
     930:      	bl	0x171c <dyld_stub_binder+0x171c>
     934:      	mov	w21, #0x0               ; =0
     938:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     93c:      	ldr	x1, [x1, #0x18]
     940:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     944:      	ldr	x2, [x2, #0x8]
     948:      	mov	x0, x19
     94c:      	bl	0x1800 <dyld_stub_binder+0x1800>
     950:      	brk	#0x1
     954:      	mov	x20, x0
     958:      	ldrsb	w8, [sp, #0x3f]
     95c:      	tbz	w8, #0x1f, 0x978 <_kernel+0x2c8>
     960:      	ldr	x0, [sp, #0x28]
     964:      	ldr	x8, [sp, #0x38]
     968:      	and	x1, x8, #0x7fffffffffffffff
     96c:      	bl	0x17b8 <dyld_stub_binder+0x17b8>
     970:      	tbnz	w21, #0x0, 0x984 <_kernel+0x2d4>
     974:      	b	0x98c <_kernel+0x2dc>
     978:      	cbnz	w21, 0x984 <_kernel+0x2d4>
     97c:      	b	0x98c <_kernel+0x2dc>
     980:      	mov	x20, x0
     984:      	mov	x0, x19
     988:      	bl	0x17f4 <dyld_stub_binder+0x17f4>
     98c:      	mov	x0, x20
     990:      	bl	0x16e0 <dyld_stub_binder+0x16e0>

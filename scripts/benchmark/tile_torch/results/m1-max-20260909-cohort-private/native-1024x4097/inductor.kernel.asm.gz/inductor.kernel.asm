
/private/tmp/luisa-cohort-private.qfZvpM/native-1024x4097/inductor/oh/cohwsiyfpihsxsbv2loxydaneo5uxr7xwcaamt7m37roarpeg355.main.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0xf0
     6b4:      	stp	d11, d10, [sp, #0x70]
     6b8:      	stp	d9, d8, [sp, #0x80]
     6bc:      	stp	x28, x27, [sp, #0x90]
     6c0:      	stp	x26, x25, [sp, #0xa0]
     6c4:      	stp	x24, x23, [sp, #0xb0]
     6c8:      	stp	x22, x21, [sp, #0xc0]
     6cc:      	stp	x20, x19, [sp, #0xd0]
     6d0:      	stp	x29, x30, [sp, #0xe0]
     6d4:      	add	x29, sp, #0xe0
     6d8:      	mov	x19, x3
     6dc:      	mov	x20, x2
     6e0:      	mov	x21, x1
     6e4:      	mov	x24, x0
     6e8:      	mov	x23, #0x0               ; =0
     6ec:      	str	wzr, [sp, #0x68]
     6f0:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     6f4:      	ldr	x9, [x9, #0x98]
     6f8:      	add	x8, sp, #0x68
     6fc:      	str	x8, [x9]
     700:      	mov	w27, #0x4004            ; =16388
     704:      	mov	w8, #0x800              ; =2048
     708:      	movk	w8, #0x4580, lsl #16
     70c:      	fmov	s8, w8
     710:      	mov	w8, #0xc5ac             ; =50604
     714:      	movk	w8, #0x3727, lsl #16
     718:      	fmov	s9, w8
     71c:      	fmov	s10, #1.00000000
     720:      	str	x3, [sp, #0x28]
     724:      	mov	x22, x0
     728:      	b	0x778 <_kernel+0xc8>
     72c:      	ldr	s2, [x24, x25, lsl #2]
     730:      	ldr	s0, [x20, x23, lsl #2]
     734:      	add	x8, x21, #0x4, lsl #12  ; =0x4000
     738:      	ldr	s3, [x8]
     73c:      	fdiv	s0, s0, s8
     740:      	fadd	s1, s0, s9
     744:      	fsqrt	s0, s1
     748:      	fcmp	s0, s0
     74c:      	b.vs	0x9e4 <_kernel+0x334>
     750:      	fdiv	s0, s10, s0
     754:      	fmul	s0, s2, s0
     758:      	fmul	s0, s3, s0
     75c:      	ldr	x8, [sp, #0x28]
     760:      	str	s0, [x8, x25, lsl #2]
     764:      	add	x23, x23, #0x1
     768:      	add	x22, x22, x27
     76c:      	add	x19, x19, x27
     770:      	cmp	x23, #0x400
     774:      	b.eq	0xa00 <_kernel+0x350>
     778:      	movi.2d	v0, #0000000000000000
     77c:      	stp	q0, q0, [sp, #0x40]
     780:      	str	q0, [sp, #0x30]
     784:      	mov	w8, #0x1                ; =1
     788:      	str	x8, [sp, #0x48]
     78c:      	str	wzr, [sp, #0x6c]
     790:      	add	x0, sp, #0x30
     794:      	add	x2, sp, #0x6c
     798:      	mov	w1, #0x1                ; =1
     79c:      	bl	0xb30 <__ZNSt3__16vectorIfNS_9allocatorIfEEE6assignEmRKf>
     7a0:      	madd	x8, x23, x27, x24
     7a4:      	add	x8, x8, #0x4, lsl #12   ; =0x4000
     7a8:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     7ac:      	ldr	x9, [x9, #0x80]
     7b0:      	ldr	q1, [x9]
     7b4:      	movi.2d	v0, #0000000000000000
     7b8:      	mov	x9, #-0x4               ; =-4
     7bc:      	mov	x10, x22
     7c0:      	cmp	x9, #0xffc
     7c4:      	b.eq	0x9ac <_kernel+0x2fc>
     7c8:      	ldr	q2, [x10], #0x10
     7cc:      	fmul.4s	v2, v2, v2
     7d0:      	fadd.4s	v0, v0, v2
     7d4:      	add	x9, x9, #0x4
     7d8:      	cmp	x9, #0xffd
     7dc:      	b.lo	0x7c0 <_kernel+0x110>
     7e0:      	ldr	x8, [sp, #0x30]
     7e4:      	ldr	x9, [sp, #0x48]
     7e8:      	ldr	s1, [x8]
     7ec:      	cmp	x9, #0x2
     7f0:      	b.lo	0x910 <_kernel+0x260>
     7f4:      	cmp	x9, #0x5
     7f8:      	b.hs	0x804 <_kernel+0x154>
     7fc:      	mov	w12, #0x1               ; =1
     800:      	b	0x8f8 <_kernel+0x248>
     804:      	sub	x10, x9, #0x1
     808:      	cmp	x9, #0x11
     80c:      	b.hs	0x818 <_kernel+0x168>
     810:      	mov	x11, #0x0               ; =0
     814:      	b	0x8b4 <_kernel+0x204>
     818:      	and	x12, x10, #0xc
     81c:      	and	x11, x10, #0xfffffffffffffff0
     820:      	add	x13, x8, #0x24
     824:      	and	x14, x10, #0xfffffffffffffff0
     828:      	ldp	q2, q3, [x13, #-0x20]
     82c:      	mov	s4, v2[3]
     830:      	mov	s5, v2[2]
     834:      	mov	s6, v2[1]
     838:      	mov	s7, v3[3]
     83c:      	mov	s16, v3[2]
     840:      	mov	s17, v3[1]
     844:      	ldp	q18, q19, [x13], #0x40
     848:      	mov	s20, v18[3]
     84c:      	mov	s21, v18[2]
     850:      	mov	s22, v18[1]
     854:      	mov	s23, v19[3]
     858:      	mov	s24, v19[2]
     85c:      	mov	s25, v19[1]
     860:      	fadd	s1, s1, s2
     864:      	fadd	s1, s1, s6
     868:      	fadd	s1, s1, s5
     86c:      	fadd	s1, s1, s4
     870:      	fadd	s1, s1, s3
     874:      	fadd	s1, s1, s17
     878:      	fadd	s1, s1, s16
     87c:      	fadd	s1, s1, s7
     880:      	fadd	s1, s1, s18
     884:      	fadd	s1, s1, s22
     888:      	fadd	s1, s1, s21
     88c:      	fadd	s1, s1, s20
     890:      	fadd	s1, s1, s19
     894:      	fadd	s1, s1, s25
     898:      	fadd	s1, s1, s24
     89c:      	fadd	s1, s1, s23
     8a0:      	subs	x14, x14, #0x10
     8a4:      	b.ne	0x828 <_kernel+0x178>
     8a8:      	cmp	x10, x11
     8ac:      	b.eq	0x910 <_kernel+0x260>
     8b0:      	cbz	x12, 0x9dc <_kernel+0x32c>
     8b4:      	and	x13, x10, #0xfffffffffffffffc
     8b8:      	orr	x12, x13, #0x1
     8bc:      	add	x14, x8, x11, lsl #2
     8c0:      	add	x14, x14, #0x4
     8c4:      	sub	x11, x11, x13
     8c8:      	ldr	q2, [x14], #0x10
     8cc:      	mov	s3, v2[3]
     8d0:      	mov	s4, v2[2]
     8d4:      	mov	s5, v2[1]
     8d8:      	fadd	s1, s1, s2
     8dc:      	fadd	s1, s1, s5
     8e0:      	fadd	s1, s1, s4
     8e4:      	fadd	s1, s1, s3
     8e8:      	adds	x11, x11, #0x4
     8ec:      	b.ne	0x8c8 <_kernel+0x218>
     8f0:      	cmp	x10, x13
     8f4:      	b.eq	0x910 <_kernel+0x260>
     8f8:      	sub	x9, x9, x12
     8fc:      	add	x8, x8, x12, lsl #2
     900:      	ldr	s2, [x8], #0x4
     904:      	fadd	s1, s1, s2
     908:      	subs	x9, x9, #0x1
     90c:      	b.ne	0x900 <_kernel+0x250>
     910:      	dup.2d	v2, v0[1]
     914:      	fadd.4s	v0, v0, v2
     918:      	faddp.2s	s0, v0
     91c:      	fadd	s0, s1, s0
     920:      	str	s0, [x20, x23, lsl #2]
     924:      	ldr	x0, [sp, #0x30]
     928:      	cbz	x0, 0x93c <_kernel+0x28c>
     92c:      	str	x0, [sp, #0x38]
     930:      	ldr	x8, [sp, #0x40]
     934:      	sub	x1, x8, x0
     938:      	bl	0x1c24 <dyld_stub_binder+0x1c24>
     93c:      	mov	x26, #0x0               ; =0
     940:      	add	x8, x23, x23, lsl #12
     944:      	add	x25, x8, #0x1, lsl #12  ; =0x1000
     948:      	mov	x28, #-0x4              ; =-4
     94c:      	cmp	x28, #0xffc
     950:      	b.eq	0x72c <_kernel+0x7c>
     954:      	ldr	q2, [x22, x26]
     958:      	ldr	s0, [x20, x23, lsl #2]
     95c:      	ldr	q3, [x21, x26]
     960:      	fdiv	s0, s0, s8
     964:      	fadd	s1, s0, s9
     968:      	fsqrt	s0, s1
     96c:      	fcmp	s0, s0
     970:      	b.vs	0x998 <_kernel+0x2e8>
     974:      	fdiv	s0, s10, s0
     978:      	fmul.4s	v0, v2, v0[0]
     97c:      	fmul.4s	v0, v3, v0
     980:      	str	q0, [x19, x26]
     984:      	add	x26, x26, #0x10
     988:      	add	x28, x28, #0x4
     98c:      	cmp	x28, #0xffd
     990:      	b.lo	0x94c <_kernel+0x29c>
     994:      	b	0x764 <_kernel+0xb4>
     998:      	mov.16b	v0, v1
     99c:      	stp	q3, q2, [sp]
     9a0:      	bl	0x1ca8 <dyld_stub_binder+0x1ca8>
     9a4:      	ldp	q3, q2, [sp]
     9a8:      	b	0x974 <_kernel+0x2c4>
     9ac:      	ldr	s2, [x8]
     9b0:      	fmul	s2, s2, s2
     9b4:      	movi.2d	v3, #0000000000000000
     9b8:      	mov.s	v3[0], v2[0]
     9bc:      	and.16b	v1, v1, v3
     9c0:      	fadd.4s	v0, v0, v1
     9c4:      	ldr	x8, [sp, #0x30]
     9c8:      	ldr	x9, [sp, #0x48]
     9cc:      	ldr	s1, [x8]
     9d0:      	cmp	x9, #0x2
     9d4:      	b.hs	0x7f4 <_kernel+0x144>
     9d8:      	b	0x910 <_kernel+0x260>
     9dc:      	orr	x12, x11, #0x1
     9e0:      	b	0x8f8 <_kernel+0x248>
     9e4:      	mov.16b	v0, v1
     9e8:      	str	s2, [sp, #0x10]
     9ec:      	str	s3, [sp]
     9f0:      	bl	0x1ca8 <dyld_stub_binder+0x1ca8>
     9f4:      	ldr	s3, [sp]
     9f8:      	ldr	s2, [sp, #0x10]
     9fc:      	b	0x750 <_kernel+0xa0>
     a00:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     a04:      	ldr	x8, [x8, #0x98]
     a08:      	str	xzr, [x8]
     a0c:      	add	x8, sp, #0x68
     a10:      	ldapr	w8, [x8]
     a14:      	cbnz	w8, 0xa40 <_kernel+0x390>
     a18:      	ldp	x29, x30, [sp, #0xe0]
     a1c:      	ldp	x20, x19, [sp, #0xd0]
     a20:      	ldp	x22, x21, [sp, #0xc0]
     a24:      	ldp	x24, x23, [sp, #0xb0]
     a28:      	ldp	x26, x25, [sp, #0xa0]
     a2c:      	ldp	x28, x27, [sp, #0x90]
     a30:      	ldp	d9, d8, [sp, #0x80]
     a34:      	ldp	d11, d10, [sp, #0x70]
     a38:      	add	sp, sp, #0xf0
     a3c:      	ret
     a40:      	mov	w0, #0x10               ; =16
     a44:      	bl	0x1c3c <dyld_stub_binder+0x1c3c>
     a48:      	mov	x19, x0
     a4c:      	mov	w8, #0x33d              ; =829
     a50:      	str	w8, [sp, #0x6c]
     a54:      	adrp	x0, 0x1000 <__ZN3c106detail12_str_wrapperIJPKcS3_S3_S3_RKiS3_S3_EE4callERKS3_S8_S8_S8_S5_S8_S8_+0x134>
     a58:      	add	x0, x0, #0xf87
     a5c:      	adrp	x1, 0x2000 <dyld_stub_binder+0x2000>
     a60:      	add	x1, x1, #0x13
     a64:      	adrp	x3, 0x2000 <dyld_stub_binder+0x2000>
     a68:      	add	x3, x3, #0x3e
     a6c:      	adrp	x4, 0x2000 <dyld_stub_binder+0x2000>
     a70:      	add	x4, x4, #0xbc
     a74:      	adrp	x2, 0x2000 <dyld_stub_binder+0x2000>
     a78:      	add	x2, x2, #0x3b
     a7c:      	add	x8, sp, #0x30
     a80:      	add	x5, sp, #0x6c
     a84:      	adrp	x7, 0x2000 <dyld_stub_binder+0x2000>
     a88:      	add	x7, x7, #0xbe
     a8c:      	mov	x6, x2
     a90:      	bl	0xe84 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     a94:      	mov	w21, #0x1               ; =1
     a98:      	add	x1, sp, #0x30
     a9c:      	mov	x0, x19
     aa0:      	bl	0x1b88 <dyld_stub_binder+0x1b88>
     aa4:      	mov	w21, #0x0               ; =0
     aa8:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     aac:      	ldr	x1, [x1, #0x18]
     ab0:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     ab4:      	ldr	x2, [x2, #0x8]
     ab8:      	mov	x0, x19
     abc:      	bl	0x1c6c <dyld_stub_binder+0x1c6c>
     ac0:      	brk	#0x1
     ac4:      	mov	x20, x0
     ac8:      	ldrsb	w8, [sp, #0x47]
     acc:      	tbz	w8, #0x1f, 0xae8 <_kernel+0x438>
     ad0:      	ldr	x0, [sp, #0x30]
     ad4:      	ldr	x8, [sp, #0x40]
     ad8:      	and	x1, x8, #0x7fffffffffffffff
     adc:      	bl	0x1c24 <dyld_stub_binder+0x1c24>
     ae0:      	tbnz	w21, #0x0, 0xaf4 <_kernel+0x444>
     ae4:      	b	0xb10 <_kernel+0x460>
     ae8:      	cbnz	w21, 0xaf4 <_kernel+0x444>
     aec:      	b	0xb10 <_kernel+0x460>
     af0:      	mov	x20, x0
     af4:      	mov	x0, x19
     af8:      	bl	0x1c60 <dyld_stub_binder+0x1c60>
     afc:      	mov	x0, x20
     b00:      	bl	0x1b4c <dyld_stub_binder+0x1b4c>
     b04:      	mov	x20, x0
     b08:      	ldr	x0, [sp, #0x30]
     b0c:      	cbnz	x0, 0xb18 <_kernel+0x468>
     b10:      	mov	x0, x20
     b14:      	bl	0x1b4c <dyld_stub_binder+0x1b4c>
     b18:      	str	x0, [sp, #0x38]
     b1c:      	ldr	x8, [sp, #0x40]
     b20:      	sub	x1, x8, x0
     b24:      	bl	0x1c24 <dyld_stub_binder+0x1c24>
     b28:      	mov	x0, x20
     b2c:      	bl	0x1b4c <dyld_stub_binder+0x1b4c>

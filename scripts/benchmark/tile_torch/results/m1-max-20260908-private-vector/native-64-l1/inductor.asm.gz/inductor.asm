
/private/tmp/luisa-xir-contiguous.plPTgi/native-64-l1/inductor/k4/ck4nfag4k45q2yoscptekuktu2yh27whx467wsxbf23ntdpvi64m.main.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006a8 <_kernel>:
     6a8:      	sub	sp, sp, #0xb0
     6ac:      	stp	d11, d10, [sp, #0x40]
     6b0:      	stp	d9, d8, [sp, #0x50]
     6b4:      	stp	x26, x25, [sp, #0x60]
     6b8:      	stp	x24, x23, [sp, #0x70]
     6bc:      	stp	x22, x21, [sp, #0x80]
     6c0:      	stp	x20, x19, [sp, #0x90]
     6c4:      	stp	x29, x30, [sp, #0xa0]
     6c8:      	add	x29, sp, #0xa0
     6cc:      	mov	x19, #0x0               ; =0
     6d0:      	str	wzr, [sp, #0x20]
     6d4:      	adrp	x20, 0x4000 <dyld_stub_binder+0x4000>
     6d8:      	ldr	x20, [x20, #0x90]
     6dc:      	add	x8, sp, #0x20
     6e0:      	str	x8, [x20]
     6e4:      	mov	w8, #0x3b800000         ; =998244352
     6e8:      	fmov	s8, w8
     6ec:      	mov	w8, #0xc5ac             ; =50604
     6f0:      	movk	w8, #0x3727, lsl #16
     6f4:      	fmov	s9, w8
     6f8:      	fmov	s10, #1.00000000
     6fc:      	b	0x714 <_kernel+0x6c>
     700:      	add	x19, x19, #0x1
     704:      	add	x0, x0, #0x400
     708:      	add	x3, x3, #0x400
     70c:      	cmp	x19, #0x40
     710:      	b.eq	0x7c8 <_kernel+0x120>
     714:      	movi.2d	v0, #0000000000000000
     718:      	mov	x8, #-0x4               ; =-4
     71c:      	mov	x9, x0
     720:      	ldr	q1, [x9], #0x10
     724:      	fmul.4s	v1, v1, v1
     728:      	fadd.4s	v0, v0, v1
     72c:      	add	x8, x8, #0x4
     730:      	cmp	x8, #0xfc
     734:      	b.lo	0x720 <_kernel+0x78>
     738:      	mov	x21, #0x0               ; =0
     73c:      	dup.2d	v1, v0[1]
     740:      	fadd.4s	v0, v0, v1
     744:      	faddp.2s	s0, v0
     748:      	str	s0, [x2, x19, lsl #2]
     74c:      	mov	x22, #-0x4              ; =-4
     750:      	ldr	q2, [x0, x21]
     754:      	ldr	s0, [x2, x19, lsl #2]
     758:      	ldr	q3, [x1, x21]
     75c:      	fmul	s0, s0, s8
     760:      	fadd	s1, s0, s9
     764:      	fsqrt	s0, s1
     768:      	fcmp	s0, s0
     76c:      	b.vs	0x794 <_kernel+0xec>
     770:      	fdiv	s0, s10, s0
     774:      	fmul.4s	v0, v2, v0[0]
     778:      	fmul.4s	v0, v3, v0
     77c:      	str	q0, [x3, x21]
     780:      	add	x22, x22, #0x4
     784:      	add	x21, x21, #0x10
     788:      	cmp	x22, #0xfc
     78c:      	b.lo	0x750 <_kernel+0xa8>
     790:      	b	0x700 <_kernel+0x58>
     794:      	mov.16b	v0, v1
     798:      	mov	x23, x3
     79c:      	mov	x25, x2
     7a0:      	mov	x24, x1
     7a4:      	mov	x26, x0
     7a8:      	stp	q3, q2, [sp]
     7ac:      	bl	0x1768 <dyld_stub_binder+0x1768>
     7b0:      	ldp	q3, q2, [sp]
     7b4:      	mov	x0, x26
     7b8:      	mov	x1, x24
     7bc:      	mov	x2, x25
     7c0:      	mov	x3, x23
     7c4:      	b	0x770 <_kernel+0xc8>
     7c8:      	str	xzr, [x20]
     7cc:      	add	x8, sp, #0x20
     7d0:      	ldapr	w8, [x8]
     7d4:      	cbnz	w8, 0x7fc <_kernel+0x154>
     7d8:      	ldp	x29, x30, [sp, #0xa0]
     7dc:      	ldp	x20, x19, [sp, #0x90]
     7e0:      	ldp	x22, x21, [sp, #0x80]
     7e4:      	ldp	x24, x23, [sp, #0x70]
     7e8:      	ldp	x26, x25, [sp, #0x60]
     7ec:      	ldp	d9, d8, [sp, #0x50]
     7f0:      	ldp	d11, d10, [sp, #0x40]
     7f4:      	add	sp, sp, #0xb0
     7f8:      	ret
     7fc:      	mov	w0, #0x10               ; =16
     800:      	bl	0x16fc <dyld_stub_binder+0x16fc>
     804:      	mov	x19, x0
     808:      	mov	w8, #0x33d              ; =829
     80c:      	str	w8, [sp, #0x24]
     810:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     814:      	add	x0, x0, #0xa38
     818:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     81c:      	add	x1, x1, #0xac4
     820:      	adrp	x3, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     824:      	add	x3, x3, #0xaef
     828:      	adrp	x4, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     82c:      	add	x4, x4, #0xb6d
     830:      	adrp	x2, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     834:      	add	x2, x2, #0xaec
     838:      	add	x8, sp, #0x28
     83c:      	add	x5, sp, #0x24
     840:      	adrp	x7, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     844:      	add	x7, x7, #0xb6f
     848:      	mov	x6, x2
     84c:      	bl	0x8c0 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     850:      	mov	w21, #0x1               ; =1
     854:      	add	x1, sp, #0x28
     858:      	mov	x0, x19
     85c:      	bl	0x1648 <dyld_stub_binder+0x1648>
     860:      	mov	w21, #0x0               ; =0
     864:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     868:      	ldr	x1, [x1, #0x18]
     86c:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     870:      	ldr	x2, [x2, #0x8]
     874:      	mov	x0, x19
     878:      	bl	0x172c <dyld_stub_binder+0x172c>
     87c:      	brk	#0x1
     880:      	mov	x20, x0
     884:      	ldrsb	w8, [sp, #0x3f]
     888:      	tbz	w8, #0x1f, 0x8a4 <_kernel+0x1fc>
     88c:      	ldr	x0, [sp, #0x28]
     890:      	ldr	x8, [sp, #0x38]
     894:      	and	x1, x8, #0x7fffffffffffffff
     898:      	bl	0x16e4 <dyld_stub_binder+0x16e4>
     89c:      	tbnz	w21, #0x0, 0x8b0 <_kernel+0x208>
     8a0:      	b	0x8b8 <_kernel+0x210>
     8a4:      	cbnz	w21, 0x8b0 <_kernel+0x208>
     8a8:      	b	0x8b8 <_kernel+0x210>
     8ac:      	mov	x20, x0
     8b0:      	mov	x0, x19
     8b4:      	bl	0x1720 <dyld_stub_binder+0x1720>
     8b8:      	mov	x0, x20
     8bc:      	bl	0x160c <dyld_stub_binder+0x160c>

00000000000008c0 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>:
     8c0:      	sub	sp, sp, #0x40
     8c4:      	stp	x29, x30, [sp, #0x30]
     8c8:      	add	x29, sp, #0x30
     8cc:      	mov	x9, x5
     8d0:      	stp	x2, x1, [x29, #-0x10]
     8d4:      	stp	x4, x3, [sp, #0x10]
     8d8:      	stp	x7, x6, [sp]
     8dc:      	sub	x0, x29, #0x8
     8e0:      	sub	x1, x29, #0x10
     8e4:      	add	x2, sp, #0x18
     8e8:      	add	x3, sp, #0x10
     8ec:      	add	x5, sp, #0x8
     8f0:      	mov	x6, sp
     8f4:      	mov	x4, x9
     8f8:      	bl	0x908 <__ZN3c106detail12_str_wrapperIJPKcS3_S3_S3_RKiS3_S3_EE4callERKS3_S8_S8_S8_S5_S8_S8_>
     8fc:      	ldp	x29, x30, [sp, #0x30]
     900:      	add	sp, sp, #0x40
     904:      	ret

0000000000000908 <__ZN3c106detail12_str_wrapperIJPKcS3_S3_S3_RKiS3_S3_EE4callERKS3_S8_S8_S8_S5_S8_S8_>:
     908:      	sub	sp, sp, #0x170
     90c:      	stp	x28, x27, [sp, #0x110]
     910:      	stp	x26, x25, [sp, #0x120]
     914:      	stp	x24, x23, [sp, #0x130]
     918:      	stp	x22, x21, [sp, #0x140]
     91c:      	stp	x20, x19, [sp, #0x150]
     920:      	stp	x29, x30, [sp, #0x160]
     924:      	add	x29, sp, #0x160
     928:      	mov	x20, x6
     92c:      	mov	x21, x5
     930:      	mov	x22, x4
     934:      	mov	x23, x3
     938:      	mov	x24, x2
     93c:      	mov	x25, x1
     940:      	mov	x26, x0
     944:      	mov	x19, x8
     948:      	add	x0, sp, #0x8
     94c:      	bl	0xabc <__ZNSt3__119basic_ostringstreamIcNS_11char_traitsIcEENS_9allocatorIcEEEC1B9nqe220108Ev>
     950:      	ldr	x26, [x26]
     954:      	mov	x0, x26
     958:      	bl	0x1774 <dyld_stub_binder+0x1774>
     95c:      	mov	x2, x0
     960:      	add	x0, sp, #0x8
     964:      	mov	x1, x26
     968:      	bl	0xe5c <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m>
     96c:      	ldr	x25, [x25]
     970:      	mov	x0, x25
     974:      	bl	0x1774 <dyld_stub_binder+0x1774>
     978:      	mov	x2, x0
     97c:      	add	x0, sp, #0x8
     980:      	mov	x1, x25
     984:      	bl	0xe5c <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m>
     988:      	ldr	x24, [x24]
     98c:      	mov	x0, x24
     990:      	bl	0x1774 <dyld_stub_binder+0x1774>
     994:      	mov	x2, x0
     998:      	add	x0, sp, #0x8
     99c:      	mov	x1, x24
     9a0:      	bl	0xe5c <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m>
     9a4:      	ldr	x23, [x23]
     9a8:      	mov	x0, x23
     9ac:      	bl	0x1774 <dyld_stub_binder+0x1774>
     9b0:      	mov	x2, x0
     9b4:      	add	x0, sp, #0x8
     9b8:      	mov	x1, x23
     9bc:      	bl	0xe5c <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m>
     9c0:      	ldr	w1, [x22]
     9c4:      	add	x0, sp, #0x8
     9c8:      	bl	0x1684 <dyld_stub_binder+0x1684>
     9cc:      	ldr	x21, [x21]
     9d0:      	mov	x0, x21
     9d4:      	bl	0x1774 <dyld_stub_binder+0x1774>
     9d8:      	mov	x2, x0
     9dc:      	add	x0, sp, #0x8
     9e0:      	mov	x1, x21
     9e4:      	bl	0xe5c <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m>
     9e8:      	ldr	x20, [x20]
     9ec:      	mov	x0, x20
     9f0:      	bl	0x1774 <dyld_stub_binder+0x1774>
     9f4:      	mov	x2, x0
     9f8:      	add	x21, sp, #0x8
     9fc:      	add	x0, sp, #0x8
     a00:      	mov	x1, x20
     a04:      	bl	0xe5c <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m>
     a08:      	add	x0, x21, #0x8
     a0c:      	mov	x8, x19
     a10:      	bl	0x1180 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev>
     a14:      	adrp	x19, 0x4000 <dyld_stub_binder+0x4000>
     a18:      	ldr	x19, [x19, #0x28]
     a1c:      	ldr	x8, [x19]
     a20:      	str	x8, [sp, #0x8]
     a24:      	ldr	x9, [x19, #0x18]
     a28:      	ldur	x8, [x8, #-0x18]
     a2c:      	add	x20, sp, #0x8
     a30:      	str	x9, [x20, x8]
     a34:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     a38:      	ldr	x8, [x8, #0x38]
     a3c:      	add	x8, x8, #0x10
     a40:      	str	x8, [sp, #0x10]
     a44:      	ldrsb	w8, [sp, #0x67]
     a48:      	tbz	w8, #0x1f, 0xa5c <__ZN3c106detail12_str_wrapperIJPKcS3_S3_S3_RKiS3_S3_EE4callERKS3_S8_S8_S8_S5_S8_S8_+0x154>
     a4c:      	ldr	x0, [sp, #0x50]
     a50:      	ldr	x8, [sp, #0x60]
     a54:      	and	x1, x8, #0x7fffffffffffffff
     a58:      	bl	0x16e4 <dyld_stub_binder+0x16e4>
     a5c:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     a60:      	ldr	x8, [x8, #0x30]
     a64:      	add	x8, x8, #0x10
     a68:      	str	x8, [sp, #0x10]
     a6c:      	add	x0, x20, #0x10
     a70:      	bl	0x169c <dyld_stub_binder+0x169c>
     a74:      	add	x0, sp, #0x8
     a78:      	add	x1, x19, #0x8
     a7c:      	bl	0x1678 <dyld_stub_binder+0x1678>
     a80:      	add	x0, x20, #0x70
     a84:      	bl	0x16cc <dyld_stub_binder+0x16cc>
     a88:      	ldp	x29, x30, [sp, #0x160]
     a8c:      	ldp	x20, x19, [sp, #0x150]
     a90:      	ldp	x22, x21, [sp, #0x140]
     a94:      	ldp	x24, x23, [sp, #0x130]
     a98:      	ldp	x26, x25, [sp, #0x120]
     a9c:      	ldp	x28, x27, [sp, #0x110]
     aa0:      	add	sp, sp, #0x170
     aa4:      	ret
     aa8:      	mov	x19, x0
     aac:      	add	x0, sp, #0x8
     ab0:      	bl	0xbf4 <__ZNSt3__119basic_ostringstreamIcNS_11char_traitsIcEENS_9allocatorIcEEED1Ev>
     ab4:      	mov	x0, x19
     ab8:      	bl	0x160c <dyld_stub_binder+0x160c>

0000000000000abc <__ZNSt3__119basic_ostringstreamIcNS_11char_traitsIcEENS_9allocatorIcEEEC1B9nqe220108Ev>:
     abc:      	stp	x24, x23, [sp, #-0x40]!
     ac0:      	stp	x22, x21, [sp, #0x10]
     ac4:      	stp	x20, x19, [sp, #0x20]
     ac8:      	stp	x29, x30, [sp, #0x30]
     acc:      	add	x29, sp, #0x30
     ad0:      	mov	x20, x0
     ad4:      	adrp	x24, 0x4000 <dyld_stub_binder+0x4000>
     ad8:      	ldr	x24, [x24, #0x40]
     adc:      	add	x23, x24, #0x40
     ae0:      	mov	x19, x0
     ae4:      	str	x23, [x19, #0x70]!
     ae8:      	str	xzr, [x0, #0xa0]
     aec:      	adrp	x22, 0x4000 <dyld_stub_binder+0x4000>
     af0:      	ldr	x22, [x22, #0x28]
     af4:      	ldp	x8, x9, [x22, #0x8]
     af8:      	str	x8, [x0]
     afc:      	ldur	x8, [x8, #-0x18]
     b00:      	str	x9, [x0, x8]
     b04:      	ldr	x8, [x0]
     b08:      	ldur	x8, [x8, #-0x18]
     b0c:      	add	x21, x0, x8
     b10:      	add	x1, x0, #0x8
     b14:      	mov	x0, x21
     b18:      	bl	0x16b4 <dyld_stub_binder+0x16b4>
     b1c:      	str	xzr, [x21, #0x88]
     b20:      	mov	w8, #-0x1               ; =-1
     b24:      	str	w8, [x21, #0x90]
     b28:      	add	x8, x24, #0x18
     b2c:      	str	x23, [x20, #0x70]
     b30:      	adrp	x23, 0x4000 <dyld_stub_binder+0x4000>
     b34:      	ldr	x23, [x23, #0x30]
     b38:      	add	x9, x23, #0x10
     b3c:      	stp	x8, x9, [x20]
     b40:      	add	x0, x20, #0x10
     b44:      	bl	0x1690 <dyld_stub_binder+0x1690>
     b48:      	movi.2d	v0, #0000000000000000
     b4c:      	stur	q0, [x20, #0x38]
     b50:      	stur	q0, [x20, #0x28]
     b54:      	stur	q0, [x20, #0x18]
     b58:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     b5c:      	ldr	x8, [x8, #0x38]
     b60:      	add	x8, x8, #0x10
     b64:      	str	x8, [x20, #0x8]
     b68:      	stur	q0, [x20, #0x48]
     b6c:      	stur	q0, [x20, #0x58]
     b70:      	mov	w8, #0x10               ; =16
     b74:      	str	w8, [x20, #0x68]
     b78:      	add	x0, x20, #0x8
     b7c:      	bl	0xc84 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev>
     b80:      	mov	x0, x20
     b84:      	ldp	x29, x30, [sp, #0x30]
     b88:      	ldp	x20, x19, [sp, #0x20]
     b8c:      	ldp	x22, x21, [sp, #0x10]
     b90:      	ldp	x24, x23, [sp], #0x40
     b94:      	ret
     b98:      	mov	x21, x0
     b9c:      	ldrsb	w8, [x20, #0x5f]
     ba0:      	tbz	w8, #0x1f, 0xbb4 <__ZNSt3__119basic_ostringstreamIcNS_11char_traitsIcEENS_9allocatorIcEEEC1B9nqe220108Ev+0xf8>
     ba4:      	ldr	x0, [x20, #0x48]
     ba8:      	ldr	x8, [x20, #0x58]
     bac:      	and	x1, x8, #0x7fffffffffffffff
     bb0:      	bl	0x16e4 <dyld_stub_binder+0x16e4>
     bb4:      	add	x8, x23, #0x10
     bb8:      	str	x8, [x20, #0x8]
     bbc:      	add	x0, x20, #0x10
     bc0:      	bl	0x169c <dyld_stub_binder+0x169c>
     bc4:      	add	x1, x22, #0x8
     bc8:      	mov	x0, x20
     bcc:      	bl	0x1678 <dyld_stub_binder+0x1678>
     bd0:      	mov	x0, x19
     bd4:      	bl	0x16cc <dyld_stub_binder+0x16cc>
     bd8:      	mov	x0, x21
     bdc:      	bl	0x160c <dyld_stub_binder+0x160c>
     be0:      	mov	x21, x0
     be4:      	mov	x0, x19
     be8:      	bl	0x16cc <dyld_stub_binder+0x16cc>
     bec:      	mov	x0, x21
     bf0:      	bl	0x160c <dyld_stub_binder+0x160c>

0000000000000bf4 <__ZNSt3__119basic_ostringstreamIcNS_11char_traitsIcEENS_9allocatorIcEEED1Ev>:
     bf4:      	stp	x20, x19, [sp, #-0x20]!
     bf8:      	stp	x29, x30, [sp, #0x10]
     bfc:      	add	x29, sp, #0x10
     c00:      	mov	x19, x0
     c04:      	adrp	x20, 0x4000 <dyld_stub_binder+0x4000>
     c08:      	ldr	x20, [x20, #0x28]
     c0c:      	ldr	x8, [x20]
     c10:      	str	x8, [x0]
     c14:      	ldr	x9, [x20, #0x18]
     c18:      	ldur	x8, [x8, #-0x18]
     c1c:      	str	x9, [x0, x8]
     c20:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     c24:      	ldr	x8, [x8, #0x38]
     c28:      	add	x8, x8, #0x10
     c2c:      	str	x8, [x0, #0x8]
     c30:      	ldrsb	w8, [x0, #0x5f]
     c34:      	tbz	w8, #0x1f, 0xc48 <__ZNSt3__119basic_ostringstreamIcNS_11char_traitsIcEENS_9allocatorIcEEED1Ev+0x54>
     c38:      	ldr	x0, [x19, #0x48]
     c3c:      	ldr	x8, [x19, #0x58]
     c40:      	and	x1, x8, #0x7fffffffffffffff
     c44:      	bl	0x16e4 <dyld_stub_binder+0x16e4>
     c48:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     c4c:      	ldr	x8, [x8, #0x30]
     c50:      	add	x8, x8, #0x10
     c54:      	str	x8, [x19, #0x8]
     c58:      	add	x0, x19, #0x10
     c5c:      	bl	0x169c <dyld_stub_binder+0x169c>
     c60:      	add	x1, x20, #0x8
     c64:      	mov	x0, x19
     c68:      	bl	0x1678 <dyld_stub_binder+0x1678>
     c6c:      	add	x0, x19, #0x70
     c70:      	bl	0x16cc <dyld_stub_binder+0x16cc>
     c74:      	mov	x0, x19
     c78:      	ldp	x29, x30, [sp, #0x10]
     c7c:      	ldp	x20, x19, [sp], #0x20
     c80:      	ret

0000000000000c84 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev>:
     c84:      	stp	x22, x21, [sp, #-0x30]!
     c88:      	stp	x20, x19, [sp, #0x10]
     c8c:      	stp	x29, x30, [sp, #0x20]
     c90:      	add	x29, sp, #0x20
     c94:      	mov	x8, x0
     c98:      	ldr	x9, [x8, #0x40]!
     c9c:      	str	xzr, [x8, #0x18]
     ca0:      	ldrb	w11, [x8, #0x17]
     ca4:      	sxtb	w10, w11
     ca8:      	cmp	w10, #0x0
     cac:      	csel	x19, x9, x8, mi
     cb0:      	ldr	x12, [x8, #0x8]
     cb4:      	and	x11, x11, #0xff
     cb8:      	csel	x20, x12, x11, mi
     cbc:      	ldr	w11, [x8, #0x20]
     cc0:      	tbz	w11, #0x3, 0xcd4 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x50>
     cc4:      	add	x12, x19, x20
     cc8:      	str	x12, [x0, #0x58]
     ccc:      	stp	x19, x19, [x0, #0x10]
     cd0:      	str	x12, [x0, #0x20]
     cd4:      	tbz	w11, #0x4, 0xdb4 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x130>
     cd8:      	add	x11, x19, x20
     cdc:      	str	x11, [x0, #0x58]
     ce0:      	ldr	x11, [x0, #0x50]
     ce4:      	and	x11, x11, #0x7fffffffffffffff
     ce8:      	sub	x12, x11, #0x1
     cec:      	cmp	w10, #0x0
     cf0:      	mov	w11, #0x16              ; =22
     cf4:      	csel	x11, x12, x11, mi
     cf8:      	subs	x1, x11, x20
     cfc:      	b.ls	0xd18 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x94>
     d00:      	mov	x21, x0
     d04:      	mov	x0, x8
     d08:      	mov	w2, #0x0                ; =0
     d0c:      	bl	0x1654 <dyld_stub_binder+0x1654>
     d10:      	mov	x0, x21
     d14:      	b	0xd34 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0xb0>
     d18:      	tbnz	w10, #0x1f, 0xd28 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0xa4>
     d1c:      	mov	w9, #0x16               ; =22
     d20:      	strb	w9, [x0, #0x57]
     d24:      	b	0xd30 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0xac>
     d28:      	str	x12, [x0, #0x48]
     d2c:      	mov	x8, x9
     d30:      	strb	wzr, [x8, x11]
     d34:      	ldrb	w8, [x0, #0x57]
     d38:      	ldr	x9, [x0, #0x48]
     d3c:      	tst	w8, #0x80
     d40:      	csel	x8, x9, x8, ne
     d44:      	add	x8, x19, x8
     d48:      	stp	x19, x19, [x0, #0x28]
     d4c:      	str	x8, [x0, #0x38]
     d50:      	ldrb	w8, [x0, #0x60]
     d54:      	tst	w8, #0x3
     d58:      	b.eq	0xdb4 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x130>
     d5c:      	lsr	x8, x20, #31
     d60:      	cbz	x8, 0xda8 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x124>
     d64:      	mov	x8, #-0x80000000        ; =-2147483648
     d68:      	add	x8, x20, x8
     d6c:      	mov	x9, #0x5                ; =5
     d70:      	movk	x9, #0x2, lsl #32
     d74:      	umulh	x9, x8, x9
     d78:      	sub	x8, x8, x9
     d7c:      	add	x8, x9, x8, lsr #1
     d80:      	lsr	x8, x8, #30
     d84:      	lsl	x9, x8, #31
     d88:      	mov	w10, #0x7fffffff        ; =2147483647
     d8c:      	sub	x8, x9, x8
     d90:      	sub	x9, x20, x8
     d94:      	add	x10, x19, x10
     d98:      	add	x19, x10, x8
     d9c:      	mov	x8, #-0x7fffffff        ; =-2147483647
     da0:      	add	x20, x9, x8
     da4:      	str	x19, [x0, #0x30]
     da8:      	cbz	x20, 0xdb4 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x130>
     dac:      	add	x8, x19, x20
     db0:      	str	x8, [x0, #0x30]
     db4:      	ldp	x29, x30, [sp, #0x20]
     db8:      	ldp	x20, x19, [sp, #0x10]
     dbc:      	ldp	x22, x21, [sp], #0x30
     dc0:      	ret

0000000000000dc4 <___clang_call_terminate>:
     dc4:      	stp	x29, x30, [sp, #-0x10]!
     dc8:      	mov	x29, sp
     dcc:      	bl	0x1708 <dyld_stub_binder+0x1708>
     dd0:      	bl	0x16d8 <dyld_stub_binder+0x16d8>

0000000000000dd4 <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE20__throw_length_errorB9nqe220108Ev>:
     dd4:      	stp	x29, x30, [sp, #-0x10]!
     dd8:      	mov	x29, sp
     ddc:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     de0:      	add	x0, x0, #0xb81
     de4:      	bl	0xde8 <__ZNSt3__120__throw_length_errorB9nqe220108EPKc>

0000000000000de8 <__ZNSt3__120__throw_length_errorB9nqe220108EPKc>:
     de8:      	stp	x20, x19, [sp, #-0x20]!
     dec:      	stp	x29, x30, [sp, #0x10]
     df0:      	add	x29, sp, #0x10
     df4:      	mov	x20, x0
     df8:      	mov	w0, #0x10               ; =16
     dfc:      	bl	0x16fc <dyld_stub_binder+0x16fc>
     e00:      	mov	x19, x0
     e04:      	mov	x1, x20
     e08:      	bl	0xe38 <__ZNSt12length_errorC1B9nqe220108EPKc>
     e0c:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     e10:      	ldr	x1, [x1, #0x78]
     e14:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     e18:      	ldr	x2, [x2]
     e1c:      	mov	x0, x19
     e20:      	bl	0x172c <dyld_stub_binder+0x172c>
     e24:      	mov	x20, x0
     e28:      	mov	x0, x19
     e2c:      	bl	0x1720 <dyld_stub_binder+0x1720>
     e30:      	mov	x0, x20
     e34:      	bl	0x160c <dyld_stub_binder+0x160c>

0000000000000e38 <__ZNSt12length_errorC1B9nqe220108EPKc>:
     e38:      	stp	x29, x30, [sp, #-0x10]!
     e3c:      	mov	x29, sp
     e40:      	bl	0x1630 <dyld_stub_binder+0x1630>
     e44:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     e48:      	ldr	x8, [x8, #0x48]
     e4c:      	add	x8, x8, #0x10
     e50:      	str	x8, [x0]
     e54:      	ldp	x29, x30, [sp], #0x10
     e58:      	ret

0000000000000e5c <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m>:
     e5c:      	sub	sp, sp, #0x70
     e60:      	stp	x26, x25, [sp, #0x20]
     e64:      	stp	x24, x23, [sp, #0x30]
     e68:      	stp	x22, x21, [sp, #0x40]
     e6c:      	stp	x20, x19, [sp, #0x50]
     e70:      	stp	x29, x30, [sp, #0x60]
     e74:      	add	x29, sp, #0x60
     e78:      	mov	x21, x2
     e7c:      	mov	x20, x1
     e80:      	mov	x19, x0
     e84:      	add	x0, sp, #0x8
     e88:      	mov	x1, x19
     e8c:      	bl	0x1660 <dyld_stub_binder+0x1660>
     e90:      	ldrb	w8, [sp, #0x8]
     e94:      	cmp	w8, #0x1
     e98:      	b.ne	0xf44 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xe8>
     e9c:      	ldr	x8, [x19]
     ea0:      	ldur	x8, [x8, #-0x18]
     ea4:      	add	x4, x19, x8
     ea8:      	ldr	x22, [x4, #0x28]
     eac:      	ldr	w24, [x4, #0x8]
     eb0:      	ldr	w23, [x4, #0x90]
     eb4:      	cmn	w23, #0x1
     eb8:      	b.ne	0xf00 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xa4>
     ebc:      	add	x8, sp, #0x18
     ec0:      	mov	x25, x4
     ec4:      	mov	x0, x4
     ec8:      	bl	0x1624 <dyld_stub_binder+0x1624>
     ecc:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     ed0:      	ldr	x1, [x1, #0x10]
     ed4:      	add	x0, sp, #0x18
     ed8:      	bl	0x1618 <dyld_stub_binder+0x1618>
     edc:      	ldr	x8, [x0]
     ee0:      	ldr	x8, [x8, #0x38]
     ee4:      	mov	w1, #0x20               ; =32
     ee8:      	blr	x8
     eec:      	mov	x23, x0
     ef0:      	add	x0, sp, #0x18
     ef4:      	bl	0x169c <dyld_stub_binder+0x169c>
     ef8:      	mov	x4, x25
     efc:      	str	w23, [x25, #0x90]
     f00:      	mov	w8, #0xb0               ; =176
     f04:      	and	w8, w24, w8
     f08:      	add	x3, x20, x21
     f0c:      	cmp	w8, #0x20
     f10:      	csel	x2, x3, x20, eq
     f14:      	sxtb	w5, w23
     f18:      	mov	x0, x22
     f1c:      	mov	x1, x20
     f20:      	bl	0xfc8 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_>
     f24:      	cbnz	x0, 0xf44 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xe8>
     f28:      	ldr	x8, [x19]
     f2c:      	ldur	x8, [x8, #-0x18]
     f30:      	add	x0, x19, x8
     f34:      	ldr	w8, [x0, #0x20]
     f38:      	mov	w9, #0x5                ; =5
     f3c:      	orr	w1, w8, w9
     f40:      	bl	0x16c0 <dyld_stub_binder+0x16c0>
     f44:      	add	x0, sp, #0x8
     f48:      	bl	0x166c <dyld_stub_binder+0x166c>
     f4c:      	mov	x0, x19
     f50:      	ldp	x29, x30, [sp, #0x60]
     f54:      	ldp	x20, x19, [sp, #0x50]
     f58:      	ldp	x22, x21, [sp, #0x40]
     f5c:      	ldp	x24, x23, [sp, #0x30]
     f60:      	ldp	x26, x25, [sp, #0x20]
     f64:      	add	sp, sp, #0x70
     f68:      	ret
     f6c:      	b	0xf80 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x124>
     f70:      	mov	x20, x0
     f74:      	add	x0, sp, #0x18
     f78:      	bl	0x169c <dyld_stub_binder+0x169c>
     f7c:      	b	0xf84 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x128>
     f80:      	mov	x20, x0
     f84:      	add	x0, sp, #0x8
     f88:      	bl	0x166c <dyld_stub_binder+0x166c>
     f8c:      	b	0xf94 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x138>
     f90:      	mov	x20, x0
     f94:      	mov	x0, x20
     f98:      	bl	0x1708 <dyld_stub_binder+0x1708>
     f9c:      	ldr	x8, [x19]
     fa0:      	ldur	x8, [x8, #-0x18]
     fa4:      	add	x0, x19, x8
     fa8:      	bl	0x16a8 <dyld_stub_binder+0x16a8>
     fac:      	bl	0x1714 <dyld_stub_binder+0x1714>
     fb0:      	b	0xf4c <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xf0>
     fb4:      	mov	x19, x0
     fb8:      	bl	0x1714 <dyld_stub_binder+0x1714>
     fbc:      	mov	x0, x19
     fc0:      	bl	0x160c <dyld_stub_binder+0x160c>
     fc4:      	bl	0xdc4 <___clang_call_terminate>

0000000000000fc8 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_>:
     fc8:      	sub	sp, sp, #0x70
     fcc:      	stp	x26, x25, [sp, #0x20]
     fd0:      	stp	x24, x23, [sp, #0x30]
     fd4:      	stp	x22, x21, [sp, #0x40]
     fd8:      	stp	x20, x19, [sp, #0x50]
     fdc:      	stp	x29, x30, [sp, #0x60]
     fe0:      	add	x29, sp, #0x60
     fe4:      	mov	x19, x0
     fe8:      	cbz	x0, 0x1138 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x170>
     fec:      	mov	x24, x5
     ff0:      	mov	x20, x4
     ff4:      	mov	x22, x3
     ff8:      	mov	x21, x2
     ffc:      	mov	x23, x1
    1000:      	ldr	x25, [x4, #0x18]
    1004:      	sub	x26, x2, x1
    1008:      	cmp	x26, #0x1
    100c:      	b.lt	0x1030 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x68>
    1010:      	ldr	x8, [x19]
    1014:      	ldr	x8, [x8, #0x60]
    1018:      	sub	x2, x21, x23
    101c:      	mov	x0, x19
    1020:      	mov	x1, x23
    1024:      	blr	x8
    1028:      	cmp	x0, x26
    102c:      	b.ne	0x1134 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x16c>
    1030:      	sub	x8, x22, x23
    1034:      	cmp	x25, x8
    1038:      	b.le	0x1100 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x138>
    103c:      	mov	x9, #-0x9               ; =-9
    1040:      	movk	x9, #0x7fff, lsl #48
    1044:      	sub	x23, x25, x8
    1048:      	cmp	x23, x9
    104c:      	b.hs	0x1158 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x190>
    1050:      	cmp	x23, #0x17
    1054:      	b.hs	0x1064 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x9c>
    1058:      	strb	w23, [sp, #0x1f]
    105c:      	add	x25, sp, #0x8
    1060:      	b	0x1090 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xc8>
    1064:      	and	x8, x23, #0x7ffffffffffffff8
    1068:      	add	x8, x8, #0x8
    106c:      	mov	w9, #0x19               ; =25
    1070:      	cmp	x8, #0x18
    1074:      	csel	x26, x9, x8, eq
    1078:      	mov	x0, x26
    107c:      	bl	0x16f0 <dyld_stub_binder+0x16f0>
    1080:      	mov	x25, x0
    1084:      	orr	x8, x26, #0x8000000000000000
    1088:      	stp	x0, x23, [sp, #0x8]
    108c:      	str	x8, [sp, #0x18]
    1090:      	mov	x0, x25
    1094:      	mov	x1, x24
    1098:      	mov	x2, x23
    109c:      	bl	0x175c <dyld_stub_binder+0x175c>
    10a0:      	strb	wzr, [x25, x23]
    10a4:      	ldrsb	w8, [sp, #0x1f]
    10a8:      	ldr	x9, [sp, #0x8]
    10ac:      	cmp	w8, #0x0
    10b0:      	add	x8, sp, #0x8
    10b4:      	csel	x1, x9, x8, mi
    10b8:      	ldr	x8, [x19]
    10bc:      	ldr	x8, [x8, #0x60]
    10c0:      	mov	x0, x19
    10c4:      	mov	x2, x23
    10c8:      	blr	x8
    10cc:      	ldrsb	w8, [sp, #0x1f]
    10d0:      	tbnz	w8, #0x1f, 0x10e0 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x118>
    10d4:      	cmp	x0, x23
    10d8:      	b.ne	0x1134 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x16c>
    10dc:      	b	0x1100 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x138>
    10e0:      	ldr	x8, [sp, #0x8]
    10e4:      	ldr	x9, [sp, #0x18]
    10e8:      	and	x1, x9, #0x7fffffffffffffff
    10ec:      	mov	x24, x0
    10f0:      	mov	x0, x8
    10f4:      	bl	0x16e4 <dyld_stub_binder+0x16e4>
    10f8:      	cmp	x24, x23
    10fc:      	b.ne	0x1134 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x16c>
    1100:      	sub	x22, x22, x21
    1104:      	cmp	x22, #0x1
    1108:      	b.lt	0x112c <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x164>
    110c:      	ldr	x8, [x19]
    1110:      	ldr	x8, [x8, #0x60]
    1114:      	mov	x0, x19
    1118:      	mov	x1, x21
    111c:      	mov	x2, x22
    1120:      	blr	x8
    1124:      	cmp	x0, x22
    1128:      	b.ne	0x1134 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x16c>
    112c:      	str	xzr, [x20, #0x18]
    1130:      	b	0x1138 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x170>
    1134:      	mov	x19, #0x0               ; =0
    1138:      	mov	x0, x19
    113c:      	ldp	x29, x30, [sp, #0x60]
    1140:      	ldp	x20, x19, [sp, #0x50]
    1144:      	ldp	x22, x21, [sp, #0x40]
    1148:      	ldp	x24, x23, [sp, #0x30]
    114c:      	ldp	x26, x25, [sp, #0x20]
    1150:      	add	sp, sp, #0x70
    1154:      	ret
    1158:      	bl	0xdd4 <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE20__throw_length_errorB9nqe220108Ev>
    115c:      	mov	x19, x0
    1160:      	ldrsb	w8, [sp, #0x1f]
    1164:      	tbz	w8, #0x1f, 0x1178 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x1b0>
    1168:      	ldr	x0, [sp, #0x8]
    116c:      	ldr	x8, [sp, #0x18]
    1170:      	and	x1, x8, #0x7fffffffffffffff
    1174:      	bl	0x16e4 <dyld_stub_binder+0x16e4>
    1178:      	mov	x0, x19
    117c:      	bl	0x160c <dyld_stub_binder+0x160c>

0000000000001180 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev>:
    1180:      	stp	x22, x21, [sp, #-0x30]!
    1184:      	stp	x20, x19, [sp, #0x10]
    1188:      	stp	x29, x30, [sp, #0x20]
    118c:      	add	x29, sp, #0x20
    1190:      	mov	x20, x0
    1194:      	mov	x19, x8
    1198:      	ldr	w8, [x0, #0x60]
    119c:      	tbnz	w8, #0x4, 0x11ac <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x2c>
    11a0:      	tbnz	w8, #0x3, 0x11f0 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x70>
    11a4:      	mov	x8, #0x0                ; =0
    11a8:      	b	0x1204 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x84>
    11ac:      	ldr	x8, [x20, #0x58]
    11b0:      	ldr	x9, [x20, #0x30]
    11b4:      	cmp	x8, x9
    11b8:      	b.hs	0x11c4 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x44>
    11bc:      	str	x9, [x20, #0x58]
    11c0:      	mov	x8, x9
    11c4:      	add	x9, x20, #0x28
    11c8:      	ldr	x9, [x9]
    11cc:      	subs	x8, x8, x9
    11d0:      	b.eq	0x1204 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x84>
    11d4:      	mov	x10, x20
    11d8:      	ldr	x11, [x10, #0x40]!
    11dc:      	ldrsb	w12, [x10, #0x17]
    11e0:      	cmp	w12, #0x0
    11e4:      	csel	x10, x11, x10, mi
    11e8:      	sub	x21, x9, x10
    11ec:      	b	0x1208 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x88>
    11f0:      	add	x9, x20, #0x10
    11f4:      	ldr	x8, [x20, #0x20]
    11f8:      	ldr	x9, [x9]
    11fc:      	subs	x8, x8, x9
    1200:      	b.ne	0x11d4 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x54>
    1204:      	mov	x21, #0x0               ; =0
    1208:      	ldr	x9, [x20, #0x50]
    120c:      	str	x9, [x19, #0x10]
    1210:      	ldr	q0, [x20, #0x40]
    1214:      	str	q0, [x19]
    1218:      	stp	xzr, xzr, [x20, #0x48]
    121c:      	str	xzr, [x20, #0x40]
    1220:      	lsr	x10, x9, #56
    1224:      	sxtb	w9, w10
    1228:      	ldr	x11, [x19, #0x8]
    122c:      	cmp	w9, #0x0
    1230:      	csel	x10, x11, x10, mi
    1234:      	add	x8, x21, x8
    1238:      	subs	x1, x8, x10
    123c:      	b.ls	0x1268 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0xe8>
    1240:      	mov	x0, x19
    1244:      	mov	w2, #0x0                ; =0
    1248:      	bl	0x1654 <dyld_stub_binder+0x1654>
    124c:      	cmn	x21, #0x1
    1250:      	b.eq	0x1280 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x100>
    1254:      	mov	x0, x19
    1258:      	mov	x1, #0x0                ; =0
    125c:      	mov	x2, x21
    1260:      	bl	0x12f4 <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE26__erase_external_with_moveEmm>
    1264:      	b	0x12b8 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x138>
    1268:      	tbnz	w9, #0x1f, 0x1294 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x114>
    126c:      	and	w9, w8, #0x7f
    1270:      	strb	w9, [x19, #0x17]
    1274:      	strb	wzr, [x19, x8]
    1278:      	cmn	x21, #0x1
    127c:      	b.ne	0x1254 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0xd4>
    1280:      	ldrsb	w8, [x19, #0x17]
    1284:      	tbnz	w8, #0x1f, 0x12ac <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x12c>
    1288:      	strb	wzr, [x19, #0x17]
    128c:      	strb	wzr, [x19]
    1290:      	b	0x12b8 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x138>
    1294:      	ldr	x9, [x19]
    1298:      	str	x8, [x19, #0x8]
    129c:      	strb	wzr, [x9, x8]
    12a0:      	cmn	x21, #0x1
    12a4:      	b.ne	0x1254 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0xd4>
    12a8:      	b	0x1280 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x100>
    12ac:      	ldr	x8, [x19]
    12b0:      	str	xzr, [x19, #0x8]
    12b4:      	strb	wzr, [x8]
    12b8:      	mov	x0, x20
    12bc:      	bl	0xc84 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev>
    12c0:      	ldp	x29, x30, [sp, #0x20]
    12c4:      	ldp	x20, x19, [sp, #0x10]
    12c8:      	ldp	x22, x21, [sp], #0x30
    12cc:      	ret
    12d0:      	mov	x20, x0
    12d4:      	ldrsb	w8, [x19, #0x17]
    12d8:      	tbz	w8, #0x1f, 0x12ec <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x16c>
    12dc:      	ldr	x0, [x19]
    12e0:      	ldr	x8, [x19, #0x10]
    12e4:      	and	x1, x8, #0x7fffffffffffffff
    12e8:      	bl	0x16e4 <dyld_stub_binder+0x16e4>
    12ec:      	mov	x0, x20
    12f0:      	bl	0x160c <dyld_stub_binder+0x160c>

00000000000012f4 <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE26__erase_external_with_moveEmm>:
    12f4:      	cbz	x2, 0x1378 <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE26__erase_external_with_moveEmm+0x84>
    12f8:      	stp	x22, x21, [sp, #-0x30]!
    12fc:      	stp	x20, x19, [sp, #0x10]
    1300:      	stp	x29, x30, [sp, #0x20]
    1304:      	add	x29, sp, #0x20
    1308:      	ldrb	w9, [x0, #0x17]
    130c:      	sxtb	w8, w9
    1310:      	cmp	w8, #0x0
    1314:      	ldp	x11, x10, [x0]
    1318:      	csel	x20, x10, x9, mi
    131c:      	csel	x19, x11, x0, mi
    1320:      	sub	x9, x20, x1
    1324:      	cmp	x9, x2
    1328:      	csel	x21, x9, x2, lo
    132c:      	b.ls	0x1350 <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE26__erase_external_with_moveEmm+0x5c>
    1330:      	sub	x2, x9, x21
    1334:      	add	x8, x19, x1
    1338:      	add	x1, x8, x21
    133c:      	mov	x22, x0
    1340:      	mov	x0, x8
    1344:      	bl	0x1750 <dyld_stub_binder+0x1750>
    1348:      	mov	x0, x22
    134c:      	ldrb	w8, [x22, #0x17]
    1350:      	sub	x9, x20, x21
    1354:      	tbnz	w8, #0x7, 0x1364 <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE26__erase_external_with_moveEmm+0x70>
    1358:      	and	w8, w9, #0x7f
    135c:      	strb	w8, [x0, #0x17]
    1360:      	b	0x1368 <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE26__erase_external_with_moveEmm+0x74>
    1364:      	str	x9, [x0, #0x8]
    1368:      	strb	wzr, [x19, x9]
    136c:      	ldp	x29, x30, [sp, #0x20]
    1370:      	ldp	x20, x19, [sp, #0x10]
    1374:      	ldp	x22, x21, [sp], #0x30
    1378:      	ret

000000000000137c <_PyInit_kernel>:
    137c:      	sub	sp, sp, #0x30
    1380:      	stp	x20, x19, [sp, #0x10]
    1384:      	stp	x29, x30, [sp, #0x20]
    1388:      	add	x29, sp, #0x20
    138c:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
    1390:      	add	x0, x0, #0xb8e
    1394:      	bl	0x1744 <dyld_stub_binder+0x1744>
    1398:      	cbz	x0, 0x13f8 <_PyInit_kernel+0x7c>
    139c:      	mov	x19, x0
    13a0:      	str	xzr, [sp, #0x8]
    13a4:      	bl	0x1738 <dyld_stub_binder+0x1738>
    13a8:      	str	wzr, [x0]
    13ac:      	add	x1, sp, #0x8
    13b0:      	mov	x0, x19
    13b4:      	mov	w2, #0xa                ; =10
    13b8:      	bl	0x1780 <dyld_stub_binder+0x1780>
    13bc:      	mov	x20, x0
    13c0:      	bl	0x1738 <dyld_stub_binder+0x1738>
    13c4:      	ldr	w8, [x0]
    13c8:      	cbz	w8, 0x1424 <_PyInit_kernel+0xa8>
    13cc:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
    13d0:      	ldr	x8, [x8, #0x60]
    13d4:      	ldr	x0, [x8]
    13d8:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
    13dc:      	add	x1, x1, #0xbea
    13e0:      	bl	0x15f4 <dyld_stub_binder+0x15f4>
    13e4:      	mov	x0, #0x0                ; =0
    13e8:      	ldp	x29, x30, [sp, #0x20]
    13ec:      	ldp	x20, x19, [sp, #0x10]
    13f0:      	add	sp, sp, #0x30
    13f4:      	ret
    13f8:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
    13fc:      	ldr	x8, [x8, #0x60]
    1400:      	ldr	x0, [x8]
    1404:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
    1408:      	add	x1, x1, #0xbb6
    140c:      	bl	0x15f4 <dyld_stub_binder+0x15f4>
    1410:      	mov	x0, #0x0                ; =0
    1414:      	ldp	x29, x30, [sp, #0x20]
    1418:      	ldp	x20, x19, [sp, #0x10]
    141c:      	add	sp, sp, #0x30
    1420:      	ret
    1424:      	ldr	x8, [sp, #0x8]
    1428:      	cmp	x8, x19
    142c:      	b.eq	0x13cc <_PyInit_kernel+0x50>
    1430:      	cbz	x20, 0x13cc <_PyInit_kernel+0x50>
    1434:      	adrp	x8, 0x8000 <dyld_stub_binder+0x8000>
    1438:      	str	x20, [x8, #0x1b8]
    143c:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
    1440:      	add	x0, x0, #0x108
    1444:      	mov	w1, #0x3f5              ; =1013
    1448:      	bl	0x1600 <dyld_stub_binder+0x1600>
    144c:      	ldp	x29, x30, [sp, #0x20]
    1450:      	ldp	x20, x19, [sp, #0x10]
    1454:      	add	sp, sp, #0x30
    1458:      	ret

000000000000145c <__ZL9kernel_pyP7_objectS0_>:
    145c:      	stp	x24, x23, [sp, #-0x40]!
    1460:      	stp	x22, x21, [sp, #0x10]
    1464:      	stp	x20, x19, [sp, #0x20]
    1468:      	stp	x29, x30, [sp, #0x30]
    146c:      	add	x29, sp, #0x30
    1470:      	ldr	x8, [x1, #0x8]
    1474:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
    1478:      	ldr	x9, [x9, #0x68]
    147c:      	cmp	x8, x9
    1480:      	b.ne	0x1504 <__ZL9kernel_pyP7_objectS0_+0xa8>
    1484:      	mov	x19, x1
    1488:      	ldr	x8, [x1, #0x10]
    148c:      	cmp	x8, #0x4
    1490:      	b.ne	0x1520 <__ZL9kernel_pyP7_objectS0_+0xc4>
    1494:      	adrp	x23, 0x8000 <dyld_stub_binder+0x8000>
    1498:      	ldr	x8, [x23, #0x1b8]
    149c:      	ldr	x0, [x19, #0x18]
    14a0:      	blr	x8
    14a4:      	mov	x20, x0
    14a8:      	ldr	x8, [x23, #0x1b8]
    14ac:      	ldr	x0, [x19, #0x20]
    14b0:      	blr	x8
    14b4:      	mov	x21, x0
    14b8:      	ldr	x8, [x23, #0x1b8]
    14bc:      	ldr	x0, [x19, #0x28]
    14c0:      	blr	x8
    14c4:      	mov	x22, x0
    14c8:      	ldr	x8, [x23, #0x1b8]
    14cc:      	ldr	x0, [x19, #0x30]
    14d0:      	blr	x8
    14d4:      	mov	x3, x0
    14d8:      	mov	x0, x20
    14dc:      	mov	x1, x21
    14e0:      	mov	x2, x22
    14e4:      	bl	0x6a8 <_kernel>
    14e8:      	adrp	x0, 0x4000 <dyld_stub_binder+0x4000>
    14ec:      	ldr	x0, [x0, #0x70]
    14f0:      	ldp	x29, x30, [sp, #0x30]
    14f4:      	ldp	x20, x19, [sp, #0x20]
    14f8:      	ldp	x22, x21, [sp, #0x10]
    14fc:      	ldp	x24, x23, [sp], #0x40
    1500:      	ret
    1504:      	mov	w0, #0x10               ; =16
    1508:      	bl	0x16fc <dyld_stub_binder+0x16fc>
    150c:      	mov	x19, x0
    1510:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
    1514:      	add	x1, x1, #0xc2a
    1518:      	bl	0x163c <dyld_stub_binder+0x163c>
    151c:      	b	0x1538 <__ZL9kernel_pyP7_objectS0_+0xdc>
    1520:      	mov	w0, #0x10               ; =16
    1524:      	bl	0x16fc <dyld_stub_binder+0x16fc>
    1528:      	mov	x19, x0
    152c:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
    1530:      	add	x1, x1, #0xc3e
    1534:      	bl	0x163c <dyld_stub_binder+0x163c>
    1538:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
    153c:      	ldr	x1, [x1, #0x18]
    1540:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
    1544:      	ldr	x2, [x2, #0x8]
    1548:      	mov	x0, x19
    154c:      	bl	0x172c <dyld_stub_binder+0x172c>
    1550:      	brk	#0x1
    1554:      	b	0x1558 <__ZL9kernel_pyP7_objectS0_+0xfc>
    1558:      	mov	x20, x1
    155c:      	mov	x21, x0
    1560:      	mov	x0, x19
    1564:      	bl	0x1720 <dyld_stub_binder+0x1720>
    1568:      	mov	x0, x21
    156c:      	b	0x1574 <__ZL9kernel_pyP7_objectS0_+0x118>
    1570:      	mov	x20, x1
    1574:      	bl	0x1708 <dyld_stub_binder+0x1708>
    1578:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
    157c:      	ldr	x8, [x8, #0x60]
    1580:      	ldr	x19, [x8]
    1584:      	cmp	w20, #0x2
    1588:      	b.ne	0x15a8 <__ZL9kernel_pyP7_objectS0_+0x14c>
    158c:      	ldr	x8, [x0]
    1590:      	ldr	x8, [x8, #0x10]
    1594:      	blr	x8
    1598:      	mov	x1, x0
    159c:      	mov	x0, x19
    15a0:      	bl	0x15f4 <dyld_stub_binder+0x15f4>
    15a4:      	b	0x15b8 <__ZL9kernel_pyP7_objectS0_+0x15c>
    15a8:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
    15ac:      	add	x1, x1, #0xc4e
    15b0:      	mov	x0, x19
    15b4:      	bl	0x15f4 <dyld_stub_binder+0x15f4>
    15b8:      	bl	0x1714 <dyld_stub_binder+0x1714>
    15bc:      	mov	x0, #0x0                ; =0
    15c0:      	ldp	x29, x30, [sp, #0x30]
    15c4:      	ldp	x20, x19, [sp, #0x20]
    15c8:      	ldp	x22, x21, [sp, #0x10]
    15cc:      	ldp	x24, x23, [sp], #0x40
    15d0:      	ret
    15d4:      	mov	x19, x0
    15d8:      	bl	0x1714 <dyld_stub_binder+0x1714>
    15dc:      	b	0x15e8 <__ZL9kernel_pyP7_objectS0_+0x18c>
    15e0:      	mov	x19, x0
    15e4:      	bl	0x1714 <dyld_stub_binder+0x1714>
    15e8:      	mov	x0, x19
    15ec:      	bl	0x160c <dyld_stub_binder+0x160c>
    15f0:      	bl	0xdc4 <___clang_call_terminate>

Disassembly of section __TEXT,__stubs:

00000000000015f4 <__stubs>:
    15f4:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    15f8:      	ldr	x16, [x16]
    15fc:      	br	x16
    1600:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1604:      	ldr	x16, [x16, #0x8]
    1608:      	br	x16
    160c:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1610:      	ldr	x16, [x16, #0x10]
    1614:      	br	x16
    1618:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    161c:      	ldr	x16, [x16, #0x18]
    1620:      	br	x16
    1624:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1628:      	ldr	x16, [x16, #0x20]
    162c:      	br	x16
    1630:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1634:      	ldr	x16, [x16, #0x28]
    1638:      	br	x16
    163c:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1640:      	ldr	x16, [x16, #0x30]
    1644:      	br	x16
    1648:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    164c:      	ldr	x16, [x16, #0x38]
    1650:      	br	x16
    1654:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1658:      	ldr	x16, [x16, #0x40]
    165c:      	br	x16
    1660:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1664:      	ldr	x16, [x16, #0x48]
    1668:      	br	x16
    166c:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1670:      	ldr	x16, [x16, #0x50]
    1674:      	br	x16
    1678:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    167c:      	ldr	x16, [x16, #0x58]
    1680:      	br	x16
    1684:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1688:      	ldr	x16, [x16, #0x60]
    168c:      	br	x16
    1690:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1694:      	ldr	x16, [x16, #0x68]
    1698:      	br	x16
    169c:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    16a0:      	ldr	x16, [x16, #0x70]
    16a4:      	br	x16
    16a8:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    16ac:      	ldr	x16, [x16, #0x78]
    16b0:      	br	x16
    16b4:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    16b8:      	ldr	x16, [x16, #0x80]
    16bc:      	br	x16
    16c0:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    16c4:      	ldr	x16, [x16, #0x88]
    16c8:      	br	x16
    16cc:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    16d0:      	ldr	x16, [x16, #0x90]
    16d4:      	br	x16
    16d8:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    16dc:      	ldr	x16, [x16, #0x98]
    16e0:      	br	x16
    16e4:      	adrp	x16, 0x4000 <dyld_stub_binder+0x4000>
    16e8:      	ldr	x16, [x16, #0x80]
    16ec:      	br	x16
    16f0:      	adrp	x16, 0x4000 <dyld_stub_binder+0x4000>
    16f4:      	ldr	x16, [x16, #0x88]
    16f8:      	br	x16
    16fc:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1700:      	ldr	x16, [x16, #0xa0]
    1704:      	br	x16
    1708:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    170c:      	ldr	x16, [x16, #0xa8]
    1710:      	br	x16
    1714:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1718:      	ldr	x16, [x16, #0xb0]
    171c:      	br	x16
    1720:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1724:      	ldr	x16, [x16, #0xb8]
    1728:      	br	x16
    172c:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1730:      	ldr	x16, [x16, #0xc0]
    1734:      	br	x16
    1738:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    173c:      	ldr	x16, [x16, #0xc8]
    1740:      	br	x16
    1744:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1748:      	ldr	x16, [x16, #0xd0]
    174c:      	br	x16
    1750:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1754:      	ldr	x16, [x16, #0xd8]
    1758:      	br	x16
    175c:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1760:      	ldr	x16, [x16, #0xe0]
    1764:      	br	x16
    1768:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    176c:      	ldr	x16, [x16, #0xe8]
    1770:      	br	x16
    1774:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1778:      	ldr	x16, [x16, #0xf0]
    177c:      	br	x16
    1780:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1784:      	ldr	x16, [x16, #0xf8]
    1788:      	br	x16

Disassembly of section __TEXT,__stub_helper:

000000000000178c <__stub_helper>:
    178c:      	adrp	x17, 0x8000 <dyld_stub_binder+0x8000>
    1790:      	add	x17, x17, #0x1b0
    1794:      	stp	x16, x17, [sp, #-0x10]!
    1798:      	adrp	x16, 0x4000 <dyld_stub_binder+0x4000>
    179c:      	ldr	x16, [x16, #0x58]
    17a0:      	br	x16
    17a4:      	ldr	w16, 0x17ac <__stub_helper+0x20>
    17a8:      	b	0x178c <__stub_helper>
    17ac:      	udf	#0x0
    17b0:      	ldr	w16, 0x17b8 <__stub_helper+0x2c>
    17b4:      	b	0x178c <__stub_helper>
    17b8:      	udf	#0x17
    17bc:      	ldr	w16, 0x17c4 <__stub_helper+0x38>
    17c0:      	b	0x178c <__stub_helper>
    17c4:      	udf	#0x2f
    17c8:      	ldr	w16, 0x17d0 <__stub_helper+0x44>
    17cc:      	b	0x178c <__stub_helper>
    17d0:      	udf	#0x45
    17d4:      	ldr	w16, 0x17dc <__stub_helper+0x50>
    17d8:      	b	0x178c <__stub_helper>
    17dc:      	udf	#0x72
    17e0:      	ldr	w16, 0x17e8 <__stub_helper+0x5c>
    17e4:      	b	0x178c <__stub_helper>
    17e8:      	udf	#0x96
    17ec:      	ldr	w16, 0x17f4 <__stub_helper+0x68>
    17f0:      	b	0x178c <__stub_helper>
    17f4:      	udf	#0xb6
    17f8:      	ldr	w16, 0x1800 <__stub_helper+0x74>
    17fc:      	b	0x178c <__stub_helper>
    1800:      	udf	#0xd8
    1804:      	ldr	w16, 0x180c <__stub_helper+0x80>
    1808:      	b	0x178c <__stub_helper>
    180c:      	udf	#0x139
    1810:      	ldr	w16, 0x1818 <__stub_helper+0x8c>
    1814:      	b	0x178c <__stub_helper>
    1818:      	udf	#0x18a
    181c:      	ldr	w16, 0x1824 <__stub_helper+0x98>
    1820:      	b	0x178c <__stub_helper>
    1824:      	udf	#0x1cf
    1828:      	ldr	w16, 0x1830 <__stub_helper+0xa4>
    182c:      	b	0x178c <__stub_helper>
    1830:      	udf	#0x211
    1834:      	ldr	w16, 0x183c <__stub_helper+0xb0>
    1838:      	b	0x178c <__stub_helper>
    183c:      	udf	#0x24c
    1840:      	ldr	w16, 0x1848 <__stub_helper+0xbc>
    1844:      	b	0x178c <__stub_helper>
    1848:      	udf	#0x287
    184c:      	ldr	w16, 0x1854 <__stub_helper+0xc8>
    1850:      	b	0x178c <__stub_helper>
    1854:      	udf	#0x2a3
    1858:      	ldr	w16, 0x1860 <__stub_helper+0xd4>
    185c:      	b	0x178c <__stub_helper>
    1860:      	udf	#0x2bf
    1864:      	ldr	w16, 0x186c <__stub_helper+0xe0>
    1868:      	b	0x178c <__stub_helper>
    186c:      	udf	#0x2fe
    1870:      	ldr	w16, 0x1878 <__stub_helper+0xec>
    1874:      	b	0x178c <__stub_helper>
    1878:      	udf	#0x321
    187c:      	ldr	w16, 0x1884 <__stub_helper+0xf8>
    1880:      	b	0x178c <__stub_helper>
    1884:      	udf	#0x344
    1888:      	ldr	w16, 0x1890 <__stub_helper+0x104>
    188c:      	b	0x178c <__stub_helper>
    1890:      	udf	#0x37b
    1894:      	ldr	w16, 0x189c <__stub_helper+0x110>
    1898:      	b	0x178c <__stub_helper>
    189c:      	udf	#0x393
    18a0:      	ldr	w16, 0x18a8 <__stub_helper+0x11c>
    18a4:      	b	0x178c <__stub_helper>
    18a8:      	udf	#0x3b4
    18ac:      	ldr	w16, 0x18b4 <__stub_helper+0x128>
    18b0:      	b	0x178c <__stub_helper>
    18b4:      	udf	#0x3ce
    18b8:      	ldr	w16, 0x18c0 <__stub_helper+0x134>
    18bc:      	b	0x178c <__stub_helper>
    18c0:      	udf	#0x3e6
    18c4:      	ldr	w16, 0x18cc <__stub_helper+0x140>
    18c8:      	b	0x178c <__stub_helper>
    18cc:      	udf	#0x403
    18d0:      	ldr	w16, 0x18d8 <__stub_helper+0x14c>
    18d4:      	b	0x178c <__stub_helper>
    18d8:      	udf	#0x417
    18dc:      	ldr	w16, 0x18e4 <__stub_helper+0x158>
    18e0:      	b	0x178c <__stub_helper>
    18e4:      	udf	#0x427
    18e8:      	ldr	w16, 0x18f0 <__stub_helper+0x164>
    18ec:      	b	0x178c <__stub_helper>
    18f0:      	udf	#0x436
    18f4:      	ldr	w16, 0x18fc <__stub_helper+0x170>
    18f8:      	b	0x178c <__stub_helper>
    18fc:      	udf	#0x446
    1900:      	ldr	w16, 0x1908 <__stub_helper+0x17c>
    1904:      	b	0x178c <__stub_helper>
    1908:      	udf	#0x455
    190c:      	ldr	w16, 0x1914 <__stub_helper+0x188>
    1910:      	b	0x178c <__stub_helper>
    1914:      	udf	#0x463
    1918:      	ldr	w16, 0x1920 <__stub_helper+0x194>
    191c:      	b	0x178c <__stub_helper>
    1920:      	udf	#0x472

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [8192 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [8192 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill4 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill4, align 4
  %.spill5 = alloca i64, align 8
  store i64 0, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.spill7 = alloca i64, align 8
  store i64 0, ptr %.spill7, align 4
  %.slot8 = alloca i64, align 8
  store i64 0, ptr %.slot8, align 4
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.spill13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill13, align 32
  %tile_snapshot.spill14 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill14, align 64
  %.slot15 = alloca i64, align 8
  store i64 0, ptr %.slot15, align 4
  %.spill16 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill16, align 32
  %.slot17 = alloca i64, align 8
  store i64 0, ptr %.slot17, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert18 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat19 = shufflevector <8 x i32> %.splatinsert18, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat19, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 64
  %.splatinsert20 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat21, %41
  %44 = mul i32 %32, 1
  %.splatinsert22 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat23 = shufflevector <8 x i32> %.splatinsert22, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat23, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert24 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat25 = shufflevector <8 x i32> %.splatinsert24, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat25, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert26 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat27 = shufflevector <8 x i32> %.splatinsert26, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat27
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = zext <8 x i32> %53 to <8 x i64>
  %55 = select <8 x i1> %51, <8 x i64> %54, <8 x i64> zeroinitializer
  %56 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %57 = sdiv <8 x i64> %55, %56
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %51, <8 x i64> %57, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %61 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %62 = extractvalue { <8 x ptr>, <8 x i64> } %60, 0
  %63 = select <8 x i1> %51, <8 x ptr> %61, <8 x ptr> %62
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %65 = extractvalue { <8 x ptr>, <8 x i64> } %60, 1
  %66 = select <8 x i1> %51, <8 x i64> %64, <8 x i64> %65
  %67 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %63, 0
  %68 = insertvalue { <8 x ptr>, <8 x i64> } %67, <8 x i64> %66, 1
  store { <8 x ptr>, <8 x i64> } %68, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %69 = icmp slt i64 %.state, 256
  br i1 %69, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %70 = add <8 x i64> %.spill.load, zeroinitializer
  %71 = add <8 x i64> zeroinitializer, %70
  %.state28 = load i64, ptr %.slot, align 4
  %72 = add i64 0, %.state28
  %73 = mul <8 x i64> %71, splat (i64 256)
  %.splatinsert29 = insertelement <8 x i64> poison, i64 %72, i64 0
  %.splat30 = shufflevector <8 x i64> %.splatinsert29, <8 x i64> poison, <8 x i32> zeroinitializer
  %74 = add <8 x i64> %73, %.splat30
  %75 = extractvalue { ptr, i64 } %9, 0
  %76 = mul <8 x i64> %74, splat (i64 4)
  %77 = getelementptr i8, ptr %75, <8 x i64> %76
  %78 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %77, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %79 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %80 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state31 = load i64, ptr %.slot, align 4
  %.splatinsert32 = insertelement <8 x i64> poison, i64 %.state31, i64 0
  %.splat33 = shufflevector <8 x i64> %.splatinsert32, <8 x i64> poison, <8 x i32> zeroinitializer
  %81 = mul <8 x i64> %.splat33, splat (i64 32)
  %82 = add <8 x i64> %80, %81
  %83 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %79, 0
  %84 = insertvalue { <8 x ptr>, <8 x i64> } %83, <8 x i64> %82, 1
  %85 = extractvalue { <8 x ptr>, <8 x i64> } %84, 0
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %84, 1
  %87 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %88 = bitcast <8 x i1> %51 to i8
  %89 = call i8 @llvm.cttz.i8(i8 %88, i1 false)
  %90 = zext i8 %89 to i32
  %91 = select i1 %87, i32 %90, i32 0
  %92 = select <8 x i1> %51, <8 x ptr> %85, <8 x ptr> zeroinitializer
  %93 = select <8 x i1> %51, <8 x i64> %86, <8 x i64> zeroinitializer
  %94 = extractelement <8 x ptr> %92, i32 %91
  %95 = extractelement <8 x i64> %93, i32 %91
  %96 = zext i32 %91 to i64
  %97 = mul i64 %96, 4
  %98 = sub i64 %95, %97
  %private.contiguous.address = getelementptr i8, ptr %94, i64 %98
  call void @llvm.masked.store.v8f32.p0(<8 x float> %78, ptr %private.contiguous.address, i32 4, <8 x i1> %51)
  %.state34 = load i64, ptr %.slot, align 4
  %99 = add i64 %.state34, 1
  store i64 %99, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill4, align 4
  store i64 0, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  store i64 0, ptr %.spill7, align 4
  %tile_snapshot.spill.load35 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %100 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 0
  %101 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 1
  %102 = add <8 x i64> %101, zeroinitializer
  %103 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %100, 0
  %104 = insertvalue { <8 x ptr>, <8 x i64> } %103, <8 x i64> %102, 1
  %105 = extractvalue { <8 x ptr>, <8 x i64> } %104, 0
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %104, 1
  %107 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %108 = bitcast <8 x i1> %51 to i8
  %109 = call i8 @llvm.cttz.i8(i8 %108, i1 false)
  %110 = zext i8 %109 to i32
  %111 = select i1 %107, i32 %110, i32 0
  %112 = select <8 x i1> %51, <8 x ptr> %105, <8 x ptr> zeroinitializer
  %113 = select <8 x i1> %51, <8 x i64> %106, <8 x i64> zeroinitializer
  %114 = extractelement <8 x ptr> %112, i32 %111
  %115 = extractelement <8 x i64> %113, i32 %111
  %116 = zext i32 %111 to i64
  %117 = mul i64 %116, 4
  %118 = sub i64 %115, %117
  %private.contiguous.address36 = getelementptr i8, ptr %114, i64 %118
  %private.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address36, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %119 = fmul <8 x float> %private.contiguous.load, %private.contiguous.load
  %tile_snapshot.spill.load37 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 0
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 1
  %122 = add <8 x i64> %121, splat (i64 32)
  %123 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %120, 0
  %124 = insertvalue { <8 x ptr>, <8 x i64> } %123, <8 x i64> %122, 1
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %128 = bitcast <8 x i1> %51 to i8
  %129 = call i8 @llvm.cttz.i8(i8 %128, i1 false)
  %130 = zext i8 %129 to i32
  %131 = select i1 %127, i32 %130, i32 0
  %132 = select <8 x i1> %51, <8 x ptr> %125, <8 x ptr> zeroinitializer
  %133 = select <8 x i1> %51, <8 x i64> %126, <8 x i64> zeroinitializer
  %134 = extractelement <8 x ptr> %132, i32 %131
  %135 = extractelement <8 x i64> %133, i32 %131
  %136 = zext i32 %131 to i64
  %137 = mul i64 %136, 4
  %138 = sub i64 %135, %137
  %private.contiguous.address38 = getelementptr i8, ptr %134, i64 %138
  %private.contiguous.load39 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address38, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %139 = fmul <8 x float> %private.contiguous.load39, %private.contiguous.load39
  %tile_snapshot.spill.load40 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %140 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load40, 0
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load40, 1
  %142 = add <8 x i64> %141, splat (i64 64)
  %143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %140, 0
  %144 = insertvalue { <8 x ptr>, <8 x i64> } %143, <8 x i64> %142, 1
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %144, 0
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %144, 1
  %147 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %148 = bitcast <8 x i1> %51 to i8
  %149 = call i8 @llvm.cttz.i8(i8 %148, i1 false)
  %150 = zext i8 %149 to i32
  %151 = select i1 %147, i32 %150, i32 0
  %152 = select <8 x i1> %51, <8 x ptr> %145, <8 x ptr> zeroinitializer
  %153 = select <8 x i1> %51, <8 x i64> %146, <8 x i64> zeroinitializer
  %154 = extractelement <8 x ptr> %152, i32 %151
  %155 = extractelement <8 x i64> %153, i32 %151
  %156 = zext i32 %151 to i64
  %157 = mul i64 %156, 4
  %158 = sub i64 %155, %157
  %private.contiguous.address41 = getelementptr i8, ptr %154, i64 %158
  %private.contiguous.load42 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address41, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %159 = fmul <8 x float> %private.contiguous.load42, %private.contiguous.load42
  %tile_snapshot.spill.load43 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 0
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 1
  %162 = add <8 x i64> %161, splat (i64 96)
  %163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %160, 0
  %164 = insertvalue { <8 x ptr>, <8 x i64> } %163, <8 x i64> %162, 1
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %164, 0
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %164, 1
  %167 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %168 = bitcast <8 x i1> %51 to i8
  %169 = call i8 @llvm.cttz.i8(i8 %168, i1 false)
  %170 = zext i8 %169 to i32
  %171 = select i1 %167, i32 %170, i32 0
  %172 = select <8 x i1> %51, <8 x ptr> %165, <8 x ptr> zeroinitializer
  %173 = select <8 x i1> %51, <8 x i64> %166, <8 x i64> zeroinitializer
  %174 = extractelement <8 x ptr> %172, i32 %171
  %175 = extractelement <8 x i64> %173, i32 %171
  %176 = zext i32 %171 to i64
  %177 = mul i64 %176, 4
  %178 = sub i64 %175, %177
  %private.contiguous.address44 = getelementptr i8, ptr %174, i64 %178
  %private.contiguous.load45 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address44, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %179 = fmul <8 x float> %private.contiguous.load45, %private.contiguous.load45
  store i64 4, ptr %.slot8, align 4
  %180 = load <8 x float>, ptr %.slot9, align 32
  %181 = select <8 x i1> %51, <8 x float> %119, <8 x float> %180
  store <8 x float> %181, ptr %.slot9, align 32
  %182 = load <8 x float>, ptr %.slot10, align 32
  %183 = select <8 x i1> %51, <8 x float> %139, <8 x float> %182
  store <8 x float> %183, ptr %.slot10, align 32
  %184 = load <8 x float>, ptr %.slot11, align 32
  %185 = select <8 x i1> %51, <8 x float> %159, <8 x float> %184
  store <8 x float> %185, ptr %.slot11, align 32
  %186 = load <8 x float>, ptr %.slot12, align 32
  %187 = select <8 x i1> %51, <8 x float> %179, <8 x float> %186
  store <8 x float> %187, ptr %.slot12, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state46 = load i64, ptr %.slot8, align 4
  %188 = icmp slt i64 %.state46, 256
  br i1 %188, label %direct.true47, label %direct.false48

direct.schedule.5:                                ; preds = %direct.true47
  %.state49 = load i64, ptr %.slot8, align 4
  %189 = add i64 %.state49, 0
  %190 = sdiv i64 %189, 1
  %.spill.load50 = load i64, ptr %.spill6, align 4
  %191 = add i64 %.spill.load50, %190
  %.spill.load51 = load i64, ptr %.spill7, align 4
  %192 = add i64 %.spill.load51, %191
  %tile_snapshot.spill.load52 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 0
  %194 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 1
  %.splatinsert53 = insertelement <8 x i64> poison, i64 %192, i64 0
  %.splat54 = shufflevector <8 x i64> %.splatinsert53, <8 x i64> poison, <8 x i32> zeroinitializer
  %195 = mul <8 x i64> %.splat54, splat (i64 32)
  %196 = add <8 x i64> %194, %195
  %197 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %193, 0
  %198 = insertvalue { <8 x ptr>, <8 x i64> } %197, <8 x i64> %196, 1
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %198, 0
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %198, 1
  %201 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %202 = bitcast <8 x i1> %51 to i8
  %203 = call i8 @llvm.cttz.i8(i8 %202, i1 false)
  %204 = zext i8 %203 to i32
  %205 = select i1 %201, i32 %204, i32 0
  %206 = select <8 x i1> %51, <8 x ptr> %199, <8 x ptr> zeroinitializer
  %207 = select <8 x i1> %51, <8 x i64> %200, <8 x i64> zeroinitializer
  %208 = extractelement <8 x ptr> %206, i32 %205
  %209 = extractelement <8 x i64> %207, i32 %205
  %210 = zext i32 %205 to i64
  %211 = mul i64 %210, 4
  %212 = sub i64 %209, %211
  %private.contiguous.address55 = getelementptr i8, ptr %208, i64 %212
  %private.contiguous.load56 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address55, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %213 = fmul <8 x float> %private.contiguous.load56, %private.contiguous.load56
  %.state57 = load <8 x float>, ptr %.slot9, align 32
  %214 = fadd <8 x float> %.state57, %213
  %.state58 = load i64, ptr %.slot8, align 4
  %215 = add i64 %.state58, 1
  %216 = sdiv i64 %215, 1
  %.spill.load59 = load i64, ptr %.spill6, align 4
  %217 = add i64 %.spill.load59, %216
  %.spill.load60 = load i64, ptr %.spill7, align 4
  %218 = add i64 %.spill.load60, %217
  %tile_snapshot.spill.load61 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 0
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 1
  %.splatinsert62 = insertelement <8 x i64> poison, i64 %218, i64 0
  %.splat63 = shufflevector <8 x i64> %.splatinsert62, <8 x i64> poison, <8 x i32> zeroinitializer
  %221 = mul <8 x i64> %.splat63, splat (i64 32)
  %222 = add <8 x i64> %220, %221
  %223 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %219, 0
  %224 = insertvalue { <8 x ptr>, <8 x i64> } %223, <8 x i64> %222, 1
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %224, 0
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %224, 1
  %227 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %228 = bitcast <8 x i1> %51 to i8
  %229 = call i8 @llvm.cttz.i8(i8 %228, i1 false)
  %230 = zext i8 %229 to i32
  %231 = select i1 %227, i32 %230, i32 0
  %232 = select <8 x i1> %51, <8 x ptr> %225, <8 x ptr> zeroinitializer
  %233 = select <8 x i1> %51, <8 x i64> %226, <8 x i64> zeroinitializer
  %234 = extractelement <8 x ptr> %232, i32 %231
  %235 = extractelement <8 x i64> %233, i32 %231
  %236 = zext i32 %231 to i64
  %237 = mul i64 %236, 4
  %238 = sub i64 %235, %237
  %private.contiguous.address64 = getelementptr i8, ptr %234, i64 %238
  %private.contiguous.load65 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address64, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %239 = fmul <8 x float> %private.contiguous.load65, %private.contiguous.load65
  %.state66 = load <8 x float>, ptr %.slot10, align 32
  %240 = fadd <8 x float> %.state66, %239
  %.state67 = load i64, ptr %.slot8, align 4
  %241 = add i64 %.state67, 2
  %242 = sdiv i64 %241, 1
  %.spill.load68 = load i64, ptr %.spill6, align 4
  %243 = add i64 %.spill.load68, %242
  %.spill.load69 = load i64, ptr %.spill7, align 4
  %244 = add i64 %.spill.load69, %243
  %tile_snapshot.spill.load70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %245 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 0
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 1
  %.splatinsert71 = insertelement <8 x i64> poison, i64 %244, i64 0
  %.splat72 = shufflevector <8 x i64> %.splatinsert71, <8 x i64> poison, <8 x i32> zeroinitializer
  %247 = mul <8 x i64> %.splat72, splat (i64 32)
  %248 = add <8 x i64> %246, %247
  %249 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %245, 0
  %250 = insertvalue { <8 x ptr>, <8 x i64> } %249, <8 x i64> %248, 1
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %250, 0
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %250, 1
  %253 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %254 = bitcast <8 x i1> %51 to i8
  %255 = call i8 @llvm.cttz.i8(i8 %254, i1 false)
  %256 = zext i8 %255 to i32
  %257 = select i1 %253, i32 %256, i32 0
  %258 = select <8 x i1> %51, <8 x ptr> %251, <8 x ptr> zeroinitializer
  %259 = select <8 x i1> %51, <8 x i64> %252, <8 x i64> zeroinitializer
  %260 = extractelement <8 x ptr> %258, i32 %257
  %261 = extractelement <8 x i64> %259, i32 %257
  %262 = zext i32 %257 to i64
  %263 = mul i64 %262, 4
  %264 = sub i64 %261, %263
  %private.contiguous.address73 = getelementptr i8, ptr %260, i64 %264
  %private.contiguous.load74 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address73, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %265 = fmul <8 x float> %private.contiguous.load74, %private.contiguous.load74
  %.state75 = load <8 x float>, ptr %.slot11, align 32
  %266 = fadd <8 x float> %.state75, %265
  %.state76 = load i64, ptr %.slot8, align 4
  %267 = add i64 %.state76, 3
  %268 = sdiv i64 %267, 1
  %.spill.load77 = load i64, ptr %.spill6, align 4
  %269 = add i64 %.spill.load77, %268
  %.spill.load78 = load i64, ptr %.spill7, align 4
  %270 = add i64 %.spill.load78, %269
  %tile_snapshot.spill.load79 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load79, 0
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load79, 1
  %.splatinsert80 = insertelement <8 x i64> poison, i64 %270, i64 0
  %.splat81 = shufflevector <8 x i64> %.splatinsert80, <8 x i64> poison, <8 x i32> zeroinitializer
  %273 = mul <8 x i64> %.splat81, splat (i64 32)
  %274 = add <8 x i64> %272, %273
  %275 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %271, 0
  %276 = insertvalue { <8 x ptr>, <8 x i64> } %275, <8 x i64> %274, 1
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %276, 0
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %276, 1
  %279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %280 = bitcast <8 x i1> %51 to i8
  %281 = call i8 @llvm.cttz.i8(i8 %280, i1 false)
  %282 = zext i8 %281 to i32
  %283 = select i1 %279, i32 %282, i32 0
  %284 = select <8 x i1> %51, <8 x ptr> %277, <8 x ptr> zeroinitializer
  %285 = select <8 x i1> %51, <8 x i64> %278, <8 x i64> zeroinitializer
  %286 = extractelement <8 x ptr> %284, i32 %283
  %287 = extractelement <8 x i64> %285, i32 %283
  %288 = zext i32 %283 to i64
  %289 = mul i64 %288, 4
  %290 = sub i64 %287, %289
  %private.contiguous.address82 = getelementptr i8, ptr %286, i64 %290
  %private.contiguous.load83 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address82, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %291 = fmul <8 x float> %private.contiguous.load83, %private.contiguous.load83
  %.state84 = load <8 x float>, ptr %.slot12, align 32
  %292 = fadd <8 x float> %.state84, %291
  %.state85 = load i64, ptr %.slot8, align 4
  %293 = add i64 %.state85, 4
  store i64 %293, ptr %.slot8, align 4
  %294 = load <8 x float>, ptr %.slot9, align 32
  %295 = select <8 x i1> %51, <8 x float> %214, <8 x float> %294
  store <8 x float> %295, ptr %.slot9, align 32
  %296 = load <8 x float>, ptr %.slot10, align 32
  %297 = select <8 x i1> %51, <8 x float> %240, <8 x float> %296
  store <8 x float> %297, ptr %.slot10, align 32
  %298 = load <8 x float>, ptr %.slot11, align 32
  %299 = select <8 x i1> %51, <8 x float> %266, <8 x float> %298
  store <8 x float> %299, ptr %.slot11, align 32
  %300 = load <8 x float>, ptr %.slot12, align 32
  %301 = select <8 x i1> %51, <8 x float> %292, <8 x float> %300
  store <8 x float> %301, ptr %.slot12, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false48
  %.spill.load86 = load float, ptr %.spill4, align 4
  %.splatinsert87 = insertelement <8 x float> poison, float %.spill.load86, i64 0
  %.splat88 = shufflevector <8 x float> %.splatinsert87, <8 x float> poison, <8 x i32> zeroinitializer
  %.state89 = load <8 x float>, ptr %.slot9, align 32
  %302 = fadd <8 x float> %.splat88, %.state89
  %.state90 = load <8 x float>, ptr %.slot10, align 32
  %303 = fadd <8 x float> %302, %.state90
  %.state91 = load <8 x float>, ptr %.slot11, align 32
  %304 = fadd <8 x float> %303, %.state91
  %.state92 = load <8 x float>, ptr %.slot12, align 32
  %305 = fadd <8 x float> %304, %.state92
  %306 = fdiv <8 x float> %305, splat (float 2.560000e+02)
  %307 = load <8 x float>, ptr %.spill13, align 32
  %308 = select <8 x i1> %51, <8 x float> %306, <8 x float> %307
  store <8 x float> %308, ptr %.spill13, align 32
  %309 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 0
  %312 = select <8 x i1> %51, <8 x ptr> %310, <8 x ptr> %311
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %315 = select <8 x i1> %51, <8 x i64> %313, <8 x i64> %314
  %316 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %312, 0
  %317 = insertvalue { <8 x ptr>, <8 x i64> } %316, <8 x i64> %315, 1
  store { <8 x ptr>, <8 x i64> } %317, ptr %tile_snapshot.spill14, align 64
  store i64 0, ptr %.slot15, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state93 = load i64, ptr %.slot15, align 4
  %318 = icmp slt i64 %.state93, 256
  br i1 %318, label %direct.true94, label %direct.false95

direct.schedule.8:                                ; preds = %direct.true94
  %.spill.load96 = load i64, ptr %.spill5, align 4
  %319 = add i64 %.spill.load96, 0
  %.state97 = load i64, ptr %.slot15, align 4
  %320 = add i64 0, %.state97
  %321 = mul i64 %319, 256
  %322 = add i64 %321, %320
  %323 = extractvalue { ptr, i64 } %15, 0
  %324 = mul i64 %322, 4
  %325 = getelementptr i8, ptr %323, i64 %324
  %326 = load float, ptr %325, align 4
  %.splatinsert98 = insertelement <8 x float> poison, float %326, i64 0
  %.splat99 = shufflevector <8 x float> %.splatinsert98, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load100 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 0
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 1
  %.state101 = load i64, ptr %.slot15, align 4
  %.splatinsert102 = insertelement <8 x i64> poison, i64 %.state101, i64 0
  %.splat103 = shufflevector <8 x i64> %.splatinsert102, <8 x i64> poison, <8 x i32> zeroinitializer
  %329 = mul <8 x i64> %.splat103, splat (i64 32)
  %330 = add <8 x i64> %328, %329
  %331 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %327, 0
  %332 = insertvalue { <8 x ptr>, <8 x i64> } %331, <8 x i64> %330, 1
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %332, 0
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %332, 1
  %335 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %336 = bitcast <8 x i1> %51 to i8
  %337 = call i8 @llvm.cttz.i8(i8 %336, i1 false)
  %338 = zext i8 %337 to i32
  %339 = select i1 %335, i32 %338, i32 0
  %340 = select <8 x i1> %51, <8 x ptr> %333, <8 x ptr> zeroinitializer
  %341 = select <8 x i1> %51, <8 x i64> %334, <8 x i64> zeroinitializer
  %342 = extractelement <8 x ptr> %340, i32 %339
  %343 = extractelement <8 x i64> %341, i32 %339
  %344 = zext i32 %339 to i64
  %345 = mul i64 %344, 4
  %346 = sub i64 %343, %345
  %private.contiguous.address104 = getelementptr i8, ptr %342, i64 %346
  call void @llvm.masked.store.v8f32.p0(<8 x float> %.splat99, ptr %private.contiguous.address104, i32 4, <8 x i1> %51)
  %.state105 = load i64, ptr %.slot15, align 4
  %347 = add i64 %.state105, 1
  store i64 %347, ptr %.slot15, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false95
  %.spill.load106 = load <8 x float>, ptr %.spill13, align 32
  %348 = fadd <8 x float> %.spill.load106, splat (float 0x3EE4F8B580000000)
  %349 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %348)
  %350 = load <8 x float>, ptr %.spill16, align 32
  %351 = select <8 x i1> %51, <8 x float> %349, <8 x float> %350
  store <8 x float> %351, ptr %.spill16, align 32
  store i64 0, ptr %.slot17, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state107 = load i64, ptr %.slot17, align 4
  %352 = icmp slt i64 %.state107, 256
  br i1 %352, label %direct.true108, label %direct.false109

direct.schedule.11:                               ; preds = %direct.true108
  %.spill.load110 = load <8 x i64>, ptr %.spill, align 64
  %353 = add <8 x i64> %.spill.load110, zeroinitializer
  %354 = add <8 x i64> zeroinitializer, %353
  %.state111 = load i64, ptr %.slot17, align 4
  %355 = add i64 0, %.state111
  %356 = mul <8 x i64> %354, splat (i64 256)
  %.splatinsert112 = insertelement <8 x i64> poison, i64 %355, i64 0
  %.splat113 = shufflevector <8 x i64> %.splatinsert112, <8 x i64> poison, <8 x i32> zeroinitializer
  %357 = add <8 x i64> %356, %.splat113
  %.spill.load114 = load i64, ptr %.spill7, align 4
  %.state115 = load i64, ptr %.slot17, align 4
  %358 = add i64 %.spill.load114, %.state115
  %.spill.load116 = load i64, ptr %.spill7, align 4
  %359 = add i64 %.spill.load116, %358
  %tile_snapshot.spill.load117 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %360 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 0
  %361 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 1
  %.splatinsert118 = insertelement <8 x i64> poison, i64 %359, i64 0
  %.splat119 = shufflevector <8 x i64> %.splatinsert118, <8 x i64> poison, <8 x i32> zeroinitializer
  %362 = mul <8 x i64> %.splat119, splat (i64 32)
  %363 = add <8 x i64> %361, %362
  %364 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %360, 0
  %365 = insertvalue { <8 x ptr>, <8 x i64> } %364, <8 x i64> %363, 1
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %365, 0
  %367 = extractvalue { <8 x ptr>, <8 x i64> } %365, 1
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %369 = bitcast <8 x i1> %51 to i8
  %370 = call i8 @llvm.cttz.i8(i8 %369, i1 false)
  %371 = zext i8 %370 to i32
  %372 = select i1 %368, i32 %371, i32 0
  %373 = select <8 x i1> %51, <8 x ptr> %366, <8 x ptr> zeroinitializer
  %374 = select <8 x i1> %51, <8 x i64> %367, <8 x i64> zeroinitializer
  %375 = extractelement <8 x ptr> %373, i32 %372
  %376 = extractelement <8 x i64> %374, i32 %372
  %377 = zext i32 %372 to i64
  %378 = mul i64 %377, 4
  %379 = sub i64 %376, %378
  %private.contiguous.address120 = getelementptr i8, ptr %375, i64 %379
  %private.contiguous.load121 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address120, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %.spill.load122 = load <8 x float>, ptr %.spill16, align 32
  %380 = fdiv <8 x float> %private.contiguous.load121, %.spill.load122
  %tile_snapshot.spill.load123 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 0
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 1
  %.splatinsert124 = insertelement <8 x i64> poison, i64 %358, i64 0
  %.splat125 = shufflevector <8 x i64> %.splatinsert124, <8 x i64> poison, <8 x i32> zeroinitializer
  %383 = mul <8 x i64> %.splat125, splat (i64 32)
  %384 = add <8 x i64> %382, %383
  %385 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %381, 0
  %386 = insertvalue { <8 x ptr>, <8 x i64> } %385, <8 x i64> %384, 1
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %386, 0
  %388 = extractvalue { <8 x ptr>, <8 x i64> } %386, 1
  %389 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %390 = bitcast <8 x i1> %51 to i8
  %391 = call i8 @llvm.cttz.i8(i8 %390, i1 false)
  %392 = zext i8 %391 to i32
  %393 = select i1 %389, i32 %392, i32 0
  %394 = select <8 x i1> %51, <8 x ptr> %387, <8 x ptr> zeroinitializer
  %395 = select <8 x i1> %51, <8 x i64> %388, <8 x i64> zeroinitializer
  %396 = extractelement <8 x ptr> %394, i32 %393
  %397 = extractelement <8 x i64> %395, i32 %393
  %398 = zext i32 %393 to i64
  %399 = mul i64 %398, 4
  %400 = sub i64 %397, %399
  %private.contiguous.address126 = getelementptr i8, ptr %396, i64 %400
  %private.contiguous.load127 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address126, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %401 = fmul <8 x float> %380, %private.contiguous.load127
  %402 = extractvalue { ptr, i64 } %27, 0
  %403 = mul <8 x i64> %357, splat (i64 4)
  %404 = getelementptr i8, ptr %402, <8 x i64> %403
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %401, <8 x ptr> %404, i32 1, <8 x i1> %51)
  %.state128 = load i64, ptr %.slot17, align 4
  %405 = add i64 %.state128, 1
  store i64 %405, ptr %.slot17, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false109
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true47:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false48:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true94:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false95:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true108:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false109:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.sqrt.v8f32(<8 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #4

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 64
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 64
  %3 = sub i64 64, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 8
  %8 = icmp uge i64 %packet.range.remaining, 64
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index3 = add i32 %base.thread.index, 32
  store i32 %packet.thread.index3, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index4 = add i32 %base.thread.index, 40
  store i32 %packet.thread.index4, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index5 = add i32 %base.thread.index, 48
  store i32 %packet.thread.index5, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index6 = add i32 %base.thread.index, 56
  store i32 %packet.thread.index6, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(write) }

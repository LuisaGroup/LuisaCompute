; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [8192 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [8192 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill4 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill4, align 4
  %.spill5 = alloca i64, align 8
  store i64 0, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.spill7 = alloca i64, align 8
  store i64 0, ptr %.spill7, align 4
  %.slot8 = alloca i64, align 8
  store i64 0, ptr %.slot8, align 4
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.spill13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill13, align 32
  %tile_snapshot.spill14 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill14, align 64
  %.slot15 = alloca i64, align 8
  store i64 0, ptr %.slot15, align 4
  %.spill16 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill16, align 32
  %.slot17 = alloca i64, align 8
  store i64 0, ptr %.slot17, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert18 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat19 = shufflevector <8 x i32> %.splatinsert18, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat19, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 64
  %.splatinsert20 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat21, %41
  %44 = mul i32 %32, 1
  %.splatinsert22 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat23 = shufflevector <8 x i32> %.splatinsert22, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat23, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert24 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat25 = shufflevector <8 x i32> %.splatinsert24, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat25, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert26 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat27 = shufflevector <8 x i32> %.splatinsert26, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat27
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = zext <8 x i32> %53 to <8 x i64>
  %55 = select <8 x i1> %51, <8 x i64> %54, <8 x i64> zeroinitializer
  %56 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %57 = sdiv <8 x i64> %55, %56
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %51, <8 x i64> %57, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %61 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %62 = extractvalue { <8 x ptr>, <8 x i64> } %60, 0
  %63 = select <8 x i1> %51, <8 x ptr> %61, <8 x ptr> %62
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %65 = extractvalue { <8 x ptr>, <8 x i64> } %60, 1
  %66 = select <8 x i1> %51, <8 x i64> %64, <8 x i64> %65
  %67 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %63, 0
  %68 = insertvalue { <8 x ptr>, <8 x i64> } %67, <8 x i64> %66, 1
  store { <8 x ptr>, <8 x i64> } %68, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %69 = icmp slt i64 %.state, 256
  br i1 %69, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %70 = add <8 x i64> %.spill.load, zeroinitializer
  %71 = add <8 x i64> zeroinitializer, %70
  %.state28 = load i64, ptr %.slot, align 4
  %72 = add i64 0, %.state28
  %73 = mul <8 x i64> %71, splat (i64 256)
  %.splatinsert29 = insertelement <8 x i64> poison, i64 %72, i64 0
  %.splat30 = shufflevector <8 x i64> %.splatinsert29, <8 x i64> poison, <8 x i32> zeroinitializer
  %74 = add <8 x i64> %73, %.splat30
  %75 = extractvalue { ptr, i64 } %9, 0
  %76 = mul <8 x i64> %74, splat (i64 4)
  %77 = getelementptr i8, ptr %75, <8 x i64> %76
  %78 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %77, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %79 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %80 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state31 = load i64, ptr %.slot, align 4
  %.splatinsert32 = insertelement <8 x i64> poison, i64 %.state31, i64 0
  %.splat33 = shufflevector <8 x i64> %.splatinsert32, <8 x i64> poison, <8 x i32> zeroinitializer
  %81 = mul <8 x i64> %.splat33, splat (i64 32)
  %82 = add <8 x i64> %80, %81
  %83 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %79, 0
  %84 = insertvalue { <8 x ptr>, <8 x i64> } %83, <8 x i64> %82, 1
  %85 = extractvalue { <8 x ptr>, <8 x i64> } %84, 0
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %84, 1
  %87 = getelementptr i8, <8 x ptr> %85, <8 x i64> %86
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %78, <8 x ptr> %87, i32 1, <8 x i1> %51)
  %.state34 = load i64, ptr %.slot, align 4
  %88 = add i64 %.state34, 1
  store i64 %88, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill4, align 4
  store i64 0, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  store i64 0, ptr %.spill7, align 4
  %tile_snapshot.spill.load35 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 0
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 1
  %91 = add <8 x i64> %90, zeroinitializer
  %92 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %89, 0
  %93 = insertvalue { <8 x ptr>, <8 x i64> } %92, <8 x i64> %91, 1
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %93, 0
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %93, 1
  %96 = getelementptr i8, <8 x ptr> %94, <8 x i64> %95
  %97 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %96, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %98 = fmul <8 x float> %97, %97
  %tile_snapshot.spill.load36 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 0
  %100 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 1
  %101 = add <8 x i64> %100, splat (i64 32)
  %102 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %99, 0
  %103 = insertvalue { <8 x ptr>, <8 x i64> } %102, <8 x i64> %101, 1
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %103, 0
  %105 = extractvalue { <8 x ptr>, <8 x i64> } %103, 1
  %106 = getelementptr i8, <8 x ptr> %104, <8 x i64> %105
  %107 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %106, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %108 = fmul <8 x float> %107, %107
  %tile_snapshot.spill.load37 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 0
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 1
  %111 = add <8 x i64> %110, splat (i64 64)
  %112 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %109, 0
  %113 = insertvalue { <8 x ptr>, <8 x i64> } %112, <8 x i64> %111, 1
  %114 = extractvalue { <8 x ptr>, <8 x i64> } %113, 0
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %113, 1
  %116 = getelementptr i8, <8 x ptr> %114, <8 x i64> %115
  %117 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %116, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %118 = fmul <8 x float> %117, %117
  %tile_snapshot.spill.load38 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %119 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load38, 0
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load38, 1
  %121 = add <8 x i64> %120, splat (i64 96)
  %122 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %119, 0
  %123 = insertvalue { <8 x ptr>, <8 x i64> } %122, <8 x i64> %121, 1
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %123, 0
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %123, 1
  %126 = getelementptr i8, <8 x ptr> %124, <8 x i64> %125
  %127 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %126, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %128 = fmul <8 x float> %127, %127
  store i64 4, ptr %.slot8, align 4
  %129 = load <8 x float>, ptr %.slot9, align 32
  %130 = select <8 x i1> %51, <8 x float> %98, <8 x float> %129
  store <8 x float> %130, ptr %.slot9, align 32
  %131 = load <8 x float>, ptr %.slot10, align 32
  %132 = select <8 x i1> %51, <8 x float> %108, <8 x float> %131
  store <8 x float> %132, ptr %.slot10, align 32
  %133 = load <8 x float>, ptr %.slot11, align 32
  %134 = select <8 x i1> %51, <8 x float> %118, <8 x float> %133
  store <8 x float> %134, ptr %.slot11, align 32
  %135 = load <8 x float>, ptr %.slot12, align 32
  %136 = select <8 x i1> %51, <8 x float> %128, <8 x float> %135
  store <8 x float> %136, ptr %.slot12, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state39 = load i64, ptr %.slot8, align 4
  %137 = icmp slt i64 %.state39, 256
  br i1 %137, label %direct.true40, label %direct.false41

direct.schedule.5:                                ; preds = %direct.true40
  %.state42 = load i64, ptr %.slot8, align 4
  %138 = add i64 %.state42, 0
  %139 = sdiv i64 %138, 1
  %.spill.load43 = load i64, ptr %.spill6, align 4
  %140 = add i64 %.spill.load43, %139
  %.spill.load44 = load i64, ptr %.spill7, align 4
  %141 = add i64 %.spill.load44, %140
  %tile_snapshot.spill.load45 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load45, 0
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load45, 1
  %.splatinsert46 = insertelement <8 x i64> poison, i64 %141, i64 0
  %.splat47 = shufflevector <8 x i64> %.splatinsert46, <8 x i64> poison, <8 x i32> zeroinitializer
  %144 = mul <8 x i64> %.splat47, splat (i64 32)
  %145 = add <8 x i64> %143, %144
  %146 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %142, 0
  %147 = insertvalue { <8 x ptr>, <8 x i64> } %146, <8 x i64> %145, 1
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %147, 0
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %147, 1
  %150 = getelementptr i8, <8 x ptr> %148, <8 x i64> %149
  %151 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %150, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %152 = fmul <8 x float> %151, %151
  %.state48 = load <8 x float>, ptr %.slot9, align 32
  %153 = fadd <8 x float> %.state48, %152
  %.state49 = load i64, ptr %.slot8, align 4
  %154 = add i64 %.state49, 1
  %155 = sdiv i64 %154, 1
  %.spill.load50 = load i64, ptr %.spill6, align 4
  %156 = add i64 %.spill.load50, %155
  %.spill.load51 = load i64, ptr %.spill7, align 4
  %157 = add i64 %.spill.load51, %156
  %tile_snapshot.spill.load52 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 0
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 1
  %.splatinsert53 = insertelement <8 x i64> poison, i64 %157, i64 0
  %.splat54 = shufflevector <8 x i64> %.splatinsert53, <8 x i64> poison, <8 x i32> zeroinitializer
  %160 = mul <8 x i64> %.splat54, splat (i64 32)
  %161 = add <8 x i64> %159, %160
  %162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %158, 0
  %163 = insertvalue { <8 x ptr>, <8 x i64> } %162, <8 x i64> %161, 1
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %163, 0
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %163, 1
  %166 = getelementptr i8, <8 x ptr> %164, <8 x i64> %165
  %167 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %166, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %168 = fmul <8 x float> %167, %167
  %.state55 = load <8 x float>, ptr %.slot10, align 32
  %169 = fadd <8 x float> %.state55, %168
  %.state56 = load i64, ptr %.slot8, align 4
  %170 = add i64 %.state56, 2
  %171 = sdiv i64 %170, 1
  %.spill.load57 = load i64, ptr %.spill6, align 4
  %172 = add i64 %.spill.load57, %171
  %.spill.load58 = load i64, ptr %.spill7, align 4
  %173 = add i64 %.spill.load58, %172
  %tile_snapshot.spill.load59 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 0
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 1
  %.splatinsert60 = insertelement <8 x i64> poison, i64 %173, i64 0
  %.splat61 = shufflevector <8 x i64> %.splatinsert60, <8 x i64> poison, <8 x i32> zeroinitializer
  %176 = mul <8 x i64> %.splat61, splat (i64 32)
  %177 = add <8 x i64> %175, %176
  %178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %174, 0
  %179 = insertvalue { <8 x ptr>, <8 x i64> } %178, <8 x i64> %177, 1
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %179, 0
  %181 = extractvalue { <8 x ptr>, <8 x i64> } %179, 1
  %182 = getelementptr i8, <8 x ptr> %180, <8 x i64> %181
  %183 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %182, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %184 = fmul <8 x float> %183, %183
  %.state62 = load <8 x float>, ptr %.slot11, align 32
  %185 = fadd <8 x float> %.state62, %184
  %.state63 = load i64, ptr %.slot8, align 4
  %186 = add i64 %.state63, 3
  %187 = sdiv i64 %186, 1
  %.spill.load64 = load i64, ptr %.spill6, align 4
  %188 = add i64 %.spill.load64, %187
  %.spill.load65 = load i64, ptr %.spill7, align 4
  %189 = add i64 %.spill.load65, %188
  %tile_snapshot.spill.load66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load66, 0
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load66, 1
  %.splatinsert67 = insertelement <8 x i64> poison, i64 %189, i64 0
  %.splat68 = shufflevector <8 x i64> %.splatinsert67, <8 x i64> poison, <8 x i32> zeroinitializer
  %192 = mul <8 x i64> %.splat68, splat (i64 32)
  %193 = add <8 x i64> %191, %192
  %194 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %190, 0
  %195 = insertvalue { <8 x ptr>, <8 x i64> } %194, <8 x i64> %193, 1
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %195, 0
  %197 = extractvalue { <8 x ptr>, <8 x i64> } %195, 1
  %198 = getelementptr i8, <8 x ptr> %196, <8 x i64> %197
  %199 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %198, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %200 = fmul <8 x float> %199, %199
  %.state69 = load <8 x float>, ptr %.slot12, align 32
  %201 = fadd <8 x float> %.state69, %200
  %.state70 = load i64, ptr %.slot8, align 4
  %202 = add i64 %.state70, 4
  store i64 %202, ptr %.slot8, align 4
  %203 = load <8 x float>, ptr %.slot9, align 32
  %204 = select <8 x i1> %51, <8 x float> %153, <8 x float> %203
  store <8 x float> %204, ptr %.slot9, align 32
  %205 = load <8 x float>, ptr %.slot10, align 32
  %206 = select <8 x i1> %51, <8 x float> %169, <8 x float> %205
  store <8 x float> %206, ptr %.slot10, align 32
  %207 = load <8 x float>, ptr %.slot11, align 32
  %208 = select <8 x i1> %51, <8 x float> %185, <8 x float> %207
  store <8 x float> %208, ptr %.slot11, align 32
  %209 = load <8 x float>, ptr %.slot12, align 32
  %210 = select <8 x i1> %51, <8 x float> %201, <8 x float> %209
  store <8 x float> %210, ptr %.slot12, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false41
  %.spill.load71 = load float, ptr %.spill4, align 4
  %.splatinsert72 = insertelement <8 x float> poison, float %.spill.load71, i64 0
  %.splat73 = shufflevector <8 x float> %.splatinsert72, <8 x float> poison, <8 x i32> zeroinitializer
  %.state74 = load <8 x float>, ptr %.slot9, align 32
  %211 = fadd <8 x float> %.splat73, %.state74
  %.state75 = load <8 x float>, ptr %.slot10, align 32
  %212 = fadd <8 x float> %211, %.state75
  %.state76 = load <8 x float>, ptr %.slot11, align 32
  %213 = fadd <8 x float> %212, %.state76
  %.state77 = load <8 x float>, ptr %.slot12, align 32
  %214 = fadd <8 x float> %213, %.state77
  %215 = fdiv <8 x float> %214, splat (float 2.560000e+02)
  %216 = load <8 x float>, ptr %.spill13, align 32
  %217 = select <8 x i1> %51, <8 x float> %215, <8 x float> %216
  store <8 x float> %217, ptr %.spill13, align 32
  %218 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %218, 0
  %221 = select <8 x i1> %51, <8 x ptr> %219, <8 x ptr> %220
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %218, 1
  %224 = select <8 x i1> %51, <8 x i64> %222, <8 x i64> %223
  %225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %221, 0
  %226 = insertvalue { <8 x ptr>, <8 x i64> } %225, <8 x i64> %224, 1
  store { <8 x ptr>, <8 x i64> } %226, ptr %tile_snapshot.spill14, align 64
  store i64 0, ptr %.slot15, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state78 = load i64, ptr %.slot15, align 4
  %227 = icmp slt i64 %.state78, 256
  br i1 %227, label %direct.true79, label %direct.false80

direct.schedule.8:                                ; preds = %direct.true79
  %.spill.load81 = load i64, ptr %.spill5, align 4
  %228 = add i64 %.spill.load81, 0
  %.state82 = load i64, ptr %.slot15, align 4
  %229 = add i64 0, %.state82
  %230 = mul i64 %228, 256
  %231 = add i64 %230, %229
  %232 = extractvalue { ptr, i64 } %15, 0
  %233 = mul i64 %231, 4
  %234 = getelementptr i8, ptr %232, i64 %233
  %235 = load float, ptr %234, align 4
  %.splatinsert83 = insertelement <8 x float> poison, float %235, i64 0
  %.splat84 = shufflevector <8 x float> %.splatinsert83, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 0
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 1
  %.state86 = load i64, ptr %.slot15, align 4
  %.splatinsert87 = insertelement <8 x i64> poison, i64 %.state86, i64 0
  %.splat88 = shufflevector <8 x i64> %.splatinsert87, <8 x i64> poison, <8 x i32> zeroinitializer
  %238 = mul <8 x i64> %.splat88, splat (i64 32)
  %239 = add <8 x i64> %237, %238
  %240 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %236, 0
  %241 = insertvalue { <8 x ptr>, <8 x i64> } %240, <8 x i64> %239, 1
  %242 = extractvalue { <8 x ptr>, <8 x i64> } %241, 0
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %241, 1
  %244 = getelementptr i8, <8 x ptr> %242, <8 x i64> %243
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.splat84, <8 x ptr> %244, i32 1, <8 x i1> %51)
  %.state89 = load i64, ptr %.slot15, align 4
  %245 = add i64 %.state89, 1
  store i64 %245, ptr %.slot15, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false80
  %.spill.load90 = load <8 x float>, ptr %.spill13, align 32
  %246 = fadd <8 x float> %.spill.load90, splat (float 0x3EE4F8B580000000)
  %247 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %246)
  %248 = load <8 x float>, ptr %.spill16, align 32
  %249 = select <8 x i1> %51, <8 x float> %247, <8 x float> %248
  store <8 x float> %249, ptr %.spill16, align 32
  store i64 0, ptr %.slot17, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state91 = load i64, ptr %.slot17, align 4
  %250 = icmp slt i64 %.state91, 256
  br i1 %250, label %direct.true92, label %direct.false93

direct.schedule.11:                               ; preds = %direct.true92
  %.spill.load94 = load <8 x i64>, ptr %.spill, align 64
  %251 = add <8 x i64> %.spill.load94, zeroinitializer
  %252 = add <8 x i64> zeroinitializer, %251
  %.state95 = load i64, ptr %.slot17, align 4
  %253 = add i64 0, %.state95
  %254 = mul <8 x i64> %252, splat (i64 256)
  %.splatinsert96 = insertelement <8 x i64> poison, i64 %253, i64 0
  %.splat97 = shufflevector <8 x i64> %.splatinsert96, <8 x i64> poison, <8 x i32> zeroinitializer
  %255 = add <8 x i64> %254, %.splat97
  %.spill.load98 = load i64, ptr %.spill7, align 4
  %.state99 = load i64, ptr %.slot17, align 4
  %256 = add i64 %.spill.load98, %.state99
  %.spill.load100 = load i64, ptr %.spill7, align 4
  %257 = add i64 %.spill.load100, %256
  %tile_snapshot.spill.load101 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 0
  %259 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 1
  %.splatinsert102 = insertelement <8 x i64> poison, i64 %257, i64 0
  %.splat103 = shufflevector <8 x i64> %.splatinsert102, <8 x i64> poison, <8 x i32> zeroinitializer
  %260 = mul <8 x i64> %.splat103, splat (i64 32)
  %261 = add <8 x i64> %259, %260
  %262 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %258, 0
  %263 = insertvalue { <8 x ptr>, <8 x i64> } %262, <8 x i64> %261, 1
  %264 = extractvalue { <8 x ptr>, <8 x i64> } %263, 0
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %263, 1
  %266 = getelementptr i8, <8 x ptr> %264, <8 x i64> %265
  %267 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %266, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %.spill.load104 = load <8 x float>, ptr %.spill16, align 32
  %268 = fdiv <8 x float> %267, %.spill.load104
  %tile_snapshot.spill.load105 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load105, 0
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load105, 1
  %.splatinsert106 = insertelement <8 x i64> poison, i64 %256, i64 0
  %.splat107 = shufflevector <8 x i64> %.splatinsert106, <8 x i64> poison, <8 x i32> zeroinitializer
  %271 = mul <8 x i64> %.splat107, splat (i64 32)
  %272 = add <8 x i64> %270, %271
  %273 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %269, 0
  %274 = insertvalue { <8 x ptr>, <8 x i64> } %273, <8 x i64> %272, 1
  %275 = extractvalue { <8 x ptr>, <8 x i64> } %274, 0
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %274, 1
  %277 = getelementptr i8, <8 x ptr> %275, <8 x i64> %276
  %278 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %277, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %279 = fmul <8 x float> %268, %278
  %280 = extractvalue { ptr, i64 } %27, 0
  %281 = mul <8 x i64> %255, splat (i64 4)
  %282 = getelementptr i8, ptr %280, <8 x i64> %281
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %279, <8 x ptr> %282, i32 1, <8 x i1> %51)
  %.state108 = load i64, ptr %.slot17, align 4
  %283 = add i64 %.state108, 1
  store i64 %283, ptr %.slot17, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false93
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true40:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false41:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true79:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false80:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true92:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false93:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.sqrt.v8f32(<8 x float>) #0

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 64
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 64
  %3 = sub i64 64, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 8
  %8 = icmp uge i64 %packet.range.remaining, 64
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index3 = add i32 %base.thread.index, 32
  store i32 %packet.thread.index3, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index4 = add i32 %base.thread.index, 40
  store i32 %packet.thread.index4, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index5 = add i32 %base.thread.index, 48
  store i32 %packet.thread.index5, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index6 = add i32 %base.thread.index, 56
  store i32 %packet.thread.index6, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }

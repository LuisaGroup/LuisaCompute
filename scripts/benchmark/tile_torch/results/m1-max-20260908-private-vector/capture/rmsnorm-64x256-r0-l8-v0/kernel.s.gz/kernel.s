	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_4:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_5:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #2480
	dup.4s	v0, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q1, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q2, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v19, v0, v2
	cmhi.4s	v20, v0, v1
	uzp1.8h	v21, v20, v19
	umaxv.8h	h0, v21
	fmov	w8, s0
	tbz	w8, #0, LBB0_222
; %bb.1:                                ; %direct.activate
	stp	q2, q1, [sp, #16]               ; 32-byte Folded Spill
	mov	x13, #0                         ; =0x0
	add	x11, sp, #192
	add	x8, sp, #432
	dup.2d	v22, x8
	ldr	x12, [x0, #16]
	ldr	x8, [x0, #48]
Lloh4:
	adrp	x9, lCPI0_0@PAGE
Lloh5:
	ldr	q0, [x9, lCPI0_0@PAGEOFF]
	and.16b	v0, v21, v0
	addv.8h	h0, v0
	fmov	w9, s0
	and	w9, w9, #0xff
	sshll.2d	v16, v20, #0
	sshll.2d	v7, v19, #0
	sshll2.2d	v18, v20, #0
	sshll2.2d	v24, v19, #0
	ldr	x14, [x0]
	add	x10, sp, #1456
	dup.2d	v4, x10
	ldr	w10, [x1]
	ldr	w15, [x1, #36]
	add	w10, w15, w10, lsl #9
	lsr	w10, w10, #3
	fmov	s1, w10
	and.16b	v17, v20, v1
	and.16b	v1, v24, v4
	and.16b	v2, v18, v4
	and.16b	v3, v7, v4
	and.16b	v4, v16, v4
Lloh6:
	adrp	x10, lCPI0_3@PAGE
Lloh7:
	ldr	q5, [x10, lCPI0_3@PAGEOFF]
	and.16b	v5, v24, v5
Lloh8:
	adrp	x10, lCPI0_4@PAGE
Lloh9:
	ldr	q6, [x10, lCPI0_4@PAGEOFF]
	str	q18, [sp]                       ; 16-byte Folded Spill
	and.16b	v6, v18, v6
Lloh10:
	adrp	x10, lCPI0_5@PAGE
Lloh11:
	ldr	q18, [x10, lCPI0_5@PAGEOFF]
	and.16b	v7, v7, v18
Lloh12:
	adrp	x10, lCPI0_6@PAGE
Lloh13:
	ldr	q18, [x10, lCPI0_6@PAGEOFF]
	and.16b	v16, v16, v18
	fmov	w10, s17
	ubfiz	x10, x10, #10, #32
	add	x14, x14, x10
	fmov	w15, s0
	b	LBB0_3
LBB0_2:                                 ; %else56
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x13, #32
	cmp	x13, #1024
	b.eq	LBB0_35
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x14, x13
	movi.2d	v26, #0000000000000000
	movi.2d	v25, #0000000000000000
	tbnz	w15, #0, LBB0_19
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w17, w15, #0xff
	tbnz	w17, #1, LBB0_20
LBB0_5:                                 ; %else21
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #2, LBB0_21
LBB0_6:                                 ; %else24
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #3, LBB0_22
LBB0_7:                                 ; %else27
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #4, LBB0_23
LBB0_8:                                 ; %else30
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #5, LBB0_24
LBB0_9:                                 ; %else33
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #6, LBB0_25
LBB0_10:                                ; %else36
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #7, LBB0_26
LBB0_11:                                ; %else39
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	w16, s0
	dup.2d	v17, x13
	orr.16b	v18, v17, v16
	add.2d	v18, v4, v18
	tbnz	w16, #0, LBB0_27
LBB0_12:                                ; %else42
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_28
LBB0_13:                                ; %else44
                                        ;   in Loop: Header=BB0_3 Depth=1
	orr.16b	v18, v17, v6
	add.2d	v18, v2, v18
	tbnz	w16, #2, LBB0_29
LBB0_14:                                ; %else46
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #3, LBB0_30
LBB0_15:                                ; %else48
                                        ;   in Loop: Header=BB0_3 Depth=1
	orr.16b	v18, v17, v7
	add.2d	v18, v3, v18
	tbnz	w16, #4, LBB0_31
LBB0_16:                                ; %else50
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #5, LBB0_32
LBB0_17:                                ; %else52
                                        ;   in Loop: Header=BB0_3 Depth=1
	orr.16b	v17, v17, v5
	add.2d	v17, v1, v17
	tbnz	w16, #6, LBB0_33
LBB0_18:                                ; %else54
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w16, #7, LBB0_2
	b	LBB0_34
LBB0_19:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	s26, [x16]
	and	w17, w15, #0xff
	tbz	w17, #1, LBB0_5
LBB0_20:                                ; %cond.load20
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x16, #4
	ld1.s	{ v26 }[1], [x0]
	tbz	w17, #2, LBB0_6
LBB0_21:                                ; %cond.load23
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x16, #8
	ld1.s	{ v26 }[2], [x0]
	tbz	w17, #3, LBB0_7
LBB0_22:                                ; %cond.load26
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x16, #12
	ld1.s	{ v26 }[3], [x0]
	tbz	w17, #4, LBB0_8
LBB0_23:                                ; %cond.load29
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x16, #16
	ld1.s	{ v25 }[0], [x0]
	tbz	w17, #5, LBB0_9
LBB0_24:                                ; %cond.load32
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x16, #20
	ld1.s	{ v25 }[1], [x0]
	tbz	w17, #6, LBB0_10
LBB0_25:                                ; %cond.load35
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x16, #24
	ld1.s	{ v25 }[2], [x0]
	tbz	w17, #7, LBB0_11
LBB0_26:                                ; %cond.load38
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x16, #28
	ld1.s	{ v25 }[3], [x16]
	fmov	w16, s0
	dup.2d	v17, x13
	orr.16b	v18, v17, v16
	add.2d	v18, v4, v18
	tbz	w16, #0, LBB0_12
LBB0_27:                                ; %cond.store
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x17, d18
	str	s26, [x17]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_13
LBB0_28:                                ; %cond.store43
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x17, v18[1]
	st1.s	{ v26 }[1], [x17]
	orr.16b	v18, v17, v6
	add.2d	v18, v2, v18
	tbz	w16, #2, LBB0_14
LBB0_29:                                ; %cond.store45
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x17, d18
	st1.s	{ v26 }[2], [x17]
	tbz	w16, #3, LBB0_15
LBB0_30:                                ; %cond.store47
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x17, v18[1]
	st1.s	{ v26 }[3], [x17]
	orr.16b	v18, v17, v7
	add.2d	v18, v3, v18
	tbz	w16, #4, LBB0_16
LBB0_31:                                ; %cond.store49
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x17, d18
	str	s25, [x17]
	tbz	w16, #5, LBB0_17
LBB0_32:                                ; %cond.store51
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x17, v18[1]
	st1.s	{ v25 }[1], [x17]
	orr.16b	v17, v17, v5
	add.2d	v17, v1, v17
	tbz	w16, #6, LBB0_18
LBB0_33:                                ; %cond.store53
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x17, d17
	st1.s	{ v25 }[2], [x17]
	tbz	w16, #7, LBB0_2
LBB0_34:                                ; %cond.store55
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x16, v17[1]
	st1.s	{ v25 }[3], [x16]
	b	LBB0_2
LBB0_35:                                ; %direct.false
	fmov	w14, s0
	and	w13, w14, #0xff
	add.2d	v27, v4, v16
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbnz	w14, #0, LBB0_223
; %bb.36:                               ; %else60
	tbnz	w13, #1, LBB0_224
LBB0_37:                                ; %else64
	add.2d	v28, v2, v6
	tbnz	w13, #2, LBB0_225
LBB0_38:                                ; %else68
	tbnz	w13, #3, LBB0_226
LBB0_39:                                ; %else72
	add.2d	v29, v3, v7
	tbnz	w13, #4, LBB0_227
LBB0_40:                                ; %else76
	tbnz	w13, #5, LBB0_228
LBB0_41:                                ; %else80
	add.2d	v30, v1, v5
	tbnz	w13, #6, LBB0_229
LBB0_42:                                ; %else84
	tbz	w13, #7, LBB0_44
LBB0_43:                                ; %cond.load86
	mov.d	x13, v30[1]
	ld1.s	{ v26 }[3], [x13]
LBB0_44:                                ; %else88
	fmov	w14, s0
	and	w13, w14, #0xff
	mov	w15, #32                        ; =0x20
	dup.2d	v17, x15
	add.2d	v18, v27, v17
	movi.2d	v31, #0000000000000000
	movi.2d	v8, #0000000000000000
	tbnz	w14, #0, LBB0_230
; %bb.45:                               ; %else95
	tbnz	w13, #1, LBB0_231
LBB0_46:                                ; %else101
	add.2d	v18, v28, v17
	tbnz	w13, #2, LBB0_232
LBB0_47:                                ; %else107
	tbnz	w13, #3, LBB0_233
LBB0_48:                                ; %else113
	add.2d	v18, v29, v17
	tbnz	w13, #4, LBB0_234
LBB0_49:                                ; %else119
	tbnz	w13, #5, LBB0_235
LBB0_50:                                ; %else125
	add.2d	v17, v30, v17
	tbnz	w13, #6, LBB0_236
LBB0_51:                                ; %else131
	tbz	w13, #7, LBB0_53
LBB0_52:                                ; %cond.load133
	mov.d	x13, v17[1]
	ld1.s	{ v8 }[3], [x13]
LBB0_53:                                ; %else137
	fmov	w14, s0
	and	w13, w14, #0xff
	mov	w15, #64                        ; =0x40
	dup.2d	v17, x15
	add.2d	v18, v27, v17
	movi.2d	v9, #0000000000000000
	movi.2d	v10, #0000000000000000
	tbnz	w14, #0, LBB0_237
; %bb.54:                               ; %else144
	tbnz	w13, #1, LBB0_238
LBB0_55:                                ; %else150
	add.2d	v18, v28, v17
	tbnz	w13, #2, LBB0_239
LBB0_56:                                ; %else156
	tbnz	w13, #3, LBB0_240
LBB0_57:                                ; %else162
	add.2d	v18, v29, v17
	tbnz	w13, #4, LBB0_241
LBB0_58:                                ; %else168
	tbnz	w13, #5, LBB0_242
LBB0_59:                                ; %else174
	add.2d	v17, v30, v17
	tbnz	w13, #6, LBB0_243
LBB0_60:                                ; %else180
	tbz	w13, #7, LBB0_62
LBB0_61:                                ; %cond.load182
	mov.d	x13, v17[1]
	ld1.s	{ v10 }[3], [x13]
LBB0_62:                                ; %else186
	fmov	w14, s0
	and	w13, w14, #0xff
	mov	w15, #96                        ; =0x60
	dup.2d	v18, x15
	add.2d	v23, v27, v18
	movi.2d	v17, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w14, #0, LBB0_244
; %bb.63:                               ; %else193
	tbnz	w13, #1, LBB0_245
LBB0_64:                                ; %else199
	add.2d	v23, v28, v18
	tbnz	w13, #2, LBB0_246
LBB0_65:                                ; %else205
	tbnz	w13, #3, LBB0_247
LBB0_66:                                ; %else211
	add.2d	v23, v29, v18
	tbnz	w13, #4, LBB0_248
LBB0_67:                                ; %else217
	tbnz	w13, #5, LBB0_249
LBB0_68:                                ; %else223
	add.2d	v29, v30, v18
	tbz	w13, #6, LBB0_70
LBB0_69:                                ; %cond.load225
	fmov	x14, d29
	ld1.s	{ v27 }[2], [x14]
LBB0_70:                                ; %else229
	fmul.4s	v18, v25, v25
	fmul.4s	v25, v26, v26
	fmul.4s	v28, v31, v31
	fmul.4s	v30, v8, v8
	fmul.4s	v31, v9, v9
	fmul.4s	v8, v10, v10
	tbz	w13, #7, LBB0_72
; %bb.71:                               ; %cond.load231
	mov.d	x13, v29[1]
	ld1.s	{ v27 }[3], [x13]
LBB0_72:                                ; %else235
	mov	x13, #0                         ; =0x0
	fmul.4s	v17, v17, v17
	fmul.4s	v23, v27, v27
	and.16b	v26, v19, v25
	and.16b	v25, v20, v18
	and.16b	v30, v19, v30
	and.16b	v29, v20, v28
	and.16b	v27, v19, v8
	and.16b	v31, v20, v31
	and.16b	v28, v19, v23
	mov	w14, #224                       ; =0xe0
	fmov	w15, s0
	and.16b	v8, v20, v17
	b	LBB0_74
LBB0_73:                                ; %else431
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmul.4s	v18, v10, v10
	fmul.4s	v23, v9, v9
	fadd.4s	v23, v25, v23
	fadd.4s	v18, v26, v18
	fmul.4s	v9, v12, v12
	fmul.4s	v10, v11, v11
	fadd.4s	v10, v29, v10
	fadd.4s	v9, v30, v9
	fmul.4s	v11, v14, v14
	fmul.4s	v12, v13, v13
	fadd.4s	v12, v31, v12
	fadd.4s	v11, v27, v11
	fmul.4s	v13, v15, v15
	fmul.4s	v17, v17, v17
	fadd.4s	v17, v28, v17
	fadd.4s	v13, v8, v13
	bit.16b	v26, v18, v19
	bit.16b	v25, v23, v20
	bit.16b	v30, v9, v19
	bit.16b	v29, v10, v20
	bit.16b	v27, v11, v19
	bit.16b	v31, v12, v20
	add	x14, x14, #128
	bit.16b	v8, v13, v20
	add	x13, x13, #4
	bit.16b	v28, v17, v19
	cmp	x13, #28
	b.hs	LBB0_138
LBB0_74:                                ; %direct.true40
                                        ; =>This Inner Loop Header: Depth=1
	sub	x16, x14, #96
	dup.2d	v17, x16
	orr.16b	v18, v17, v16
	add.2d	v18, v4, v18
	movi.2d	v9, #0000000000000000
	movi.2d	v10, #0000000000000000
	tbnz	w15, #0, LBB0_109
; %bb.75:                               ; %else242
                                        ;   in Loop: Header=BB0_74 Depth=1
	and	w16, w15, #0xff
	tbnz	w16, #1, LBB0_110
LBB0_76:                                ; %else248
                                        ;   in Loop: Header=BB0_74 Depth=1
	orr.16b	v18, v17, v6
	add.2d	v18, v2, v18
	tbnz	w16, #2, LBB0_111
LBB0_77:                                ; %else254
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w16, #3, LBB0_112
LBB0_78:                                ; %else260
                                        ;   in Loop: Header=BB0_74 Depth=1
	orr.16b	v18, v17, v7
	add.2d	v18, v3, v18
	tbnz	w16, #4, LBB0_113
LBB0_79:                                ; %else266
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w16, #5, LBB0_114
LBB0_80:                                ; %else272
                                        ;   in Loop: Header=BB0_74 Depth=1
	orr.16b	v17, v17, v5
	add.2d	v17, v1, v17
	tbnz	w16, #6, LBB0_115
LBB0_81:                                ; %else278
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbz	w16, #7, LBB0_83
LBB0_82:                                ; %cond.load280
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x16, v17[1]
	ld1.s	{ v10 }[3], [x16]
LBB0_83:                                ; %else284
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	w16, s0
	sub	x17, x14, #64
	dup.2d	v17, x17
	orr.16b	v18, v17, v16
	add.2d	v18, v4, v18
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	tbnz	w16, #0, LBB0_116
; %bb.84:                               ; %else291
                                        ;   in Loop: Header=BB0_74 Depth=1
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_117
LBB0_85:                                ; %else297
                                        ;   in Loop: Header=BB0_74 Depth=1
	orr.16b	v18, v17, v6
	add.2d	v18, v2, v18
	tbnz	w16, #2, LBB0_118
LBB0_86:                                ; %else303
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w16, #3, LBB0_119
LBB0_87:                                ; %else309
                                        ;   in Loop: Header=BB0_74 Depth=1
	orr.16b	v18, v17, v7
	add.2d	v18, v3, v18
	tbnz	w16, #4, LBB0_120
LBB0_88:                                ; %else315
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w16, #5, LBB0_121
LBB0_89:                                ; %else321
                                        ;   in Loop: Header=BB0_74 Depth=1
	orr.16b	v17, v17, v5
	add.2d	v17, v1, v17
	tbnz	w16, #6, LBB0_122
LBB0_90:                                ; %else327
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbz	w16, #7, LBB0_92
LBB0_91:                                ; %cond.load329
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x16, v17[1]
	ld1.s	{ v12 }[3], [x16]
LBB0_92:                                ; %else333
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	w16, s0
	sub	x17, x14, #32
	dup.2d	v17, x17
	orr.16b	v18, v17, v16
	add.2d	v18, v4, v18
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	tbnz	w16, #0, LBB0_123
; %bb.93:                               ; %else340
                                        ;   in Loop: Header=BB0_74 Depth=1
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_124
LBB0_94:                                ; %else346
                                        ;   in Loop: Header=BB0_74 Depth=1
	orr.16b	v18, v17, v6
	add.2d	v18, v2, v18
	tbnz	w16, #2, LBB0_125
LBB0_95:                                ; %else352
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w16, #3, LBB0_126
LBB0_96:                                ; %else358
                                        ;   in Loop: Header=BB0_74 Depth=1
	orr.16b	v18, v17, v7
	add.2d	v18, v3, v18
	tbnz	w16, #4, LBB0_127
LBB0_97:                                ; %else364
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w16, #5, LBB0_128
LBB0_98:                                ; %else370
                                        ;   in Loop: Header=BB0_74 Depth=1
	orr.16b	v17, v17, v5
	add.2d	v17, v1, v17
	tbnz	w16, #6, LBB0_129
LBB0_99:                                ; %else376
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbz	w16, #7, LBB0_101
LBB0_100:                               ; %cond.load378
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x16, v17[1]
	ld1.s	{ v14 }[3], [x16]
LBB0_101:                               ; %else382
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	w16, s0
	dup.2d	v18, x14
	orr.16b	v17, v18, v16
	add.2d	v23, v4, v17
	movi.2d	v15, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w16, #0, LBB0_130
; %bb.102:                              ; %else389
                                        ;   in Loop: Header=BB0_74 Depth=1
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_131
LBB0_103:                               ; %else395
                                        ;   in Loop: Header=BB0_74 Depth=1
	orr.16b	v23, v18, v6
	add.2d	v23, v2, v23
	tbnz	w16, #2, LBB0_132
LBB0_104:                               ; %else401
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w16, #3, LBB0_133
LBB0_105:                               ; %else407
                                        ;   in Loop: Header=BB0_74 Depth=1
	orr.16b	v23, v18, v7
	add.2d	v23, v3, v23
	tbnz	w16, #4, LBB0_134
LBB0_106:                               ; %else413
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w16, #5, LBB0_135
LBB0_107:                               ; %else419
                                        ;   in Loop: Header=BB0_74 Depth=1
	orr.16b	v18, v18, v5
	add.2d	v18, v1, v18
	tbnz	w16, #6, LBB0_136
LBB0_108:                               ; %else425
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbz	w16, #7, LBB0_73
	b	LBB0_137
LBB0_109:                               ; %cond.load238
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x16, d18
	ldr	s9, [x16]
	and	w16, w15, #0xff
	tbz	w16, #1, LBB0_76
LBB0_110:                               ; %cond.load244
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x17, v18[1]
	ld1.s	{ v9 }[1], [x17]
	orr.16b	v18, v17, v6
	add.2d	v18, v2, v18
	tbz	w16, #2, LBB0_77
LBB0_111:                               ; %cond.load250
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x17, d18
	ld1.s	{ v9 }[2], [x17]
	tbz	w16, #3, LBB0_78
LBB0_112:                               ; %cond.load256
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x17, v18[1]
	ld1.s	{ v9 }[3], [x17]
	orr.16b	v18, v17, v7
	add.2d	v18, v3, v18
	tbz	w16, #4, LBB0_79
LBB0_113:                               ; %cond.load262
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x17, d18
	ld1.s	{ v10 }[0], [x17]
	tbz	w16, #5, LBB0_80
LBB0_114:                               ; %cond.load268
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x17, v18[1]
	ld1.s	{ v10 }[1], [x17]
	orr.16b	v17, v17, v5
	add.2d	v17, v1, v17
	tbz	w16, #6, LBB0_81
LBB0_115:                               ; %cond.load274
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x17, d17
	ld1.s	{ v10 }[2], [x17]
	tbnz	w16, #7, LBB0_82
	b	LBB0_83
LBB0_116:                               ; %cond.load287
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x17, d18
	ldr	s11, [x17]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_85
LBB0_117:                               ; %cond.load293
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x17, v18[1]
	ld1.s	{ v11 }[1], [x17]
	orr.16b	v18, v17, v6
	add.2d	v18, v2, v18
	tbz	w16, #2, LBB0_86
LBB0_118:                               ; %cond.load299
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x17, d18
	ld1.s	{ v11 }[2], [x17]
	tbz	w16, #3, LBB0_87
LBB0_119:                               ; %cond.load305
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x17, v18[1]
	ld1.s	{ v11 }[3], [x17]
	orr.16b	v18, v17, v7
	add.2d	v18, v3, v18
	tbz	w16, #4, LBB0_88
LBB0_120:                               ; %cond.load311
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x17, d18
	ld1.s	{ v12 }[0], [x17]
	tbz	w16, #5, LBB0_89
LBB0_121:                               ; %cond.load317
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x17, v18[1]
	ld1.s	{ v12 }[1], [x17]
	orr.16b	v17, v17, v5
	add.2d	v17, v1, v17
	tbz	w16, #6, LBB0_90
LBB0_122:                               ; %cond.load323
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x17, d17
	ld1.s	{ v12 }[2], [x17]
	tbnz	w16, #7, LBB0_91
	b	LBB0_92
LBB0_123:                               ; %cond.load336
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x17, d18
	ldr	s13, [x17]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_94
LBB0_124:                               ; %cond.load342
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x17, v18[1]
	ld1.s	{ v13 }[1], [x17]
	orr.16b	v18, v17, v6
	add.2d	v18, v2, v18
	tbz	w16, #2, LBB0_95
LBB0_125:                               ; %cond.load348
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x17, d18
	ld1.s	{ v13 }[2], [x17]
	tbz	w16, #3, LBB0_96
LBB0_126:                               ; %cond.load354
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x17, v18[1]
	ld1.s	{ v13 }[3], [x17]
	orr.16b	v18, v17, v7
	add.2d	v18, v3, v18
	tbz	w16, #4, LBB0_97
LBB0_127:                               ; %cond.load360
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x17, d18
	ld1.s	{ v14 }[0], [x17]
	tbz	w16, #5, LBB0_98
LBB0_128:                               ; %cond.load366
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x17, v18[1]
	ld1.s	{ v14 }[1], [x17]
	orr.16b	v17, v17, v5
	add.2d	v17, v1, v17
	tbz	w16, #6, LBB0_99
LBB0_129:                               ; %cond.load372
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x17, d17
	ld1.s	{ v14 }[2], [x17]
	tbnz	w16, #7, LBB0_100
	b	LBB0_101
LBB0_130:                               ; %cond.load385
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x17, d23
	ldr	s15, [x17]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_103
LBB0_131:                               ; %cond.load391
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x17, v23[1]
	ld1.s	{ v15 }[1], [x17]
	orr.16b	v23, v18, v6
	add.2d	v23, v2, v23
	tbz	w16, #2, LBB0_104
LBB0_132:                               ; %cond.load397
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x17, d23
	ld1.s	{ v15 }[2], [x17]
	tbz	w16, #3, LBB0_105
LBB0_133:                               ; %cond.load403
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x17, v23[1]
	ld1.s	{ v15 }[3], [x17]
	orr.16b	v23, v18, v7
	add.2d	v23, v3, v23
	tbz	w16, #4, LBB0_106
LBB0_134:                               ; %cond.load409
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x17, d23
	ld1.s	{ v17 }[0], [x17]
	tbz	w16, #5, LBB0_107
LBB0_135:                               ; %cond.load415
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x17, v23[1]
	ld1.s	{ v17 }[1], [x17]
	orr.16b	v18, v18, v5
	add.2d	v18, v1, v18
	tbz	w16, #6, LBB0_108
LBB0_136:                               ; %cond.load421
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	x17, d18
	ld1.s	{ v17 }[2], [x17]
	tbz	w16, #7, LBB0_73
LBB0_137:                               ; %cond.load427
                                        ;   in Loop: Header=BB0_74 Depth=1
	mov.d	x16, v18[1]
	ld1.s	{ v17 }[3], [x16]
	b	LBB0_73
LBB0_138:                               ; %direct.false41
	mov	x13, #0                         ; =0x0
	sshll.2d	v17, v20, #0
	sshll.2d	v18, v19, #0
	and.16b	v24, v24, v22
	ldr	q23, [sp]                       ; 16-byte Folded Reload
	and.16b	v23, v23, v22
	and.16b	v9, v18, v22
	and.16b	v22, v17, v22
	b	LBB0_140
LBB0_139:                               ; %else490
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x13, x13, #32
	cmp	x13, #1024
	b.eq	LBB0_172
LBB0_140:                               ; %direct.true70
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w15, s0
	add	x14, x12, x13
	movi.2d	v11, #0000000000000000
	movi.2d	v10, #0000000000000000
	tbnz	w15, #0, LBB0_156
; %bb.141:                              ; %else435
                                        ;   in Loop: Header=BB0_140 Depth=1
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_157
LBB0_142:                               ; %else438
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w15, #2, LBB0_158
LBB0_143:                               ; %else441
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w15, #3, LBB0_159
LBB0_144:                               ; %else444
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w15, #4, LBB0_160
LBB0_145:                               ; %else447
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w15, #5, LBB0_161
LBB0_146:                               ; %else450
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w15, #6, LBB0_162
LBB0_147:                               ; %else453
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w15, #7, LBB0_163
LBB0_148:                               ; %else456
                                        ;   in Loop: Header=BB0_140 Depth=1
	fmov	w14, s0
	dup.2d	v17, x13
	orr.16b	v18, v17, v16
	add.2d	v18, v22, v18
	tbnz	w14, #0, LBB0_164
LBB0_149:                               ; %else462
                                        ;   in Loop: Header=BB0_140 Depth=1
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_165
LBB0_150:                               ; %else466
                                        ;   in Loop: Header=BB0_140 Depth=1
	orr.16b	v18, v17, v6
	add.2d	v18, v23, v18
	tbnz	w14, #2, LBB0_166
LBB0_151:                               ; %else470
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w14, #3, LBB0_167
LBB0_152:                               ; %else474
                                        ;   in Loop: Header=BB0_140 Depth=1
	orr.16b	v18, v17, v7
	add.2d	v18, v9, v18
	tbnz	w14, #4, LBB0_168
LBB0_153:                               ; %else478
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w14, #5, LBB0_169
LBB0_154:                               ; %else482
                                        ;   in Loop: Header=BB0_140 Depth=1
	orr.16b	v17, v17, v5
	add.2d	v17, v24, v17
	tbnz	w14, #6, LBB0_170
LBB0_155:                               ; %else486
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbz	w14, #7, LBB0_139
	b	LBB0_171
LBB0_156:                               ; %cond.load434
                                        ;   in Loop: Header=BB0_140 Depth=1
	ldr	s11, [x14]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_142
LBB0_157:                               ; %cond.load437
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x16, x14, #4
	ld1.s	{ v11 }[1], [x16]
	tbz	w15, #2, LBB0_143
LBB0_158:                               ; %cond.load440
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x16, x14, #8
	ld1.s	{ v11 }[2], [x16]
	tbz	w15, #3, LBB0_144
LBB0_159:                               ; %cond.load443
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x16, x14, #12
	ld1.s	{ v11 }[3], [x16]
	tbz	w15, #4, LBB0_145
LBB0_160:                               ; %cond.load446
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x16, x14, #16
	ld1.s	{ v10 }[0], [x16]
	tbz	w15, #5, LBB0_146
LBB0_161:                               ; %cond.load449
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x16, x14, #20
	ld1.s	{ v10 }[1], [x16]
	tbz	w15, #6, LBB0_147
LBB0_162:                               ; %cond.load452
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x16, x14, #24
	ld1.s	{ v10 }[2], [x16]
	tbz	w15, #7, LBB0_148
LBB0_163:                               ; %cond.load455
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x14, x14, #28
	ld1.s	{ v10 }[3], [x14]
	fmov	w14, s0
	dup.2d	v17, x13
	orr.16b	v18, v17, v16
	add.2d	v18, v22, v18
	tbz	w14, #0, LBB0_149
LBB0_164:                               ; %cond.store459
                                        ;   in Loop: Header=BB0_140 Depth=1
	fmov	x15, d18
	str	s11, [x15]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_150
LBB0_165:                               ; %cond.store463
                                        ;   in Loop: Header=BB0_140 Depth=1
	mov.d	x15, v18[1]
	st1.s	{ v11 }[1], [x15]
	orr.16b	v18, v17, v6
	add.2d	v18, v23, v18
	tbz	w14, #2, LBB0_151
LBB0_166:                               ; %cond.store467
                                        ;   in Loop: Header=BB0_140 Depth=1
	fmov	x15, d18
	st1.s	{ v11 }[2], [x15]
	tbz	w14, #3, LBB0_152
LBB0_167:                               ; %cond.store471
                                        ;   in Loop: Header=BB0_140 Depth=1
	mov.d	x15, v18[1]
	st1.s	{ v11 }[3], [x15]
	orr.16b	v18, v17, v7
	add.2d	v18, v9, v18
	tbz	w14, #4, LBB0_153
LBB0_168:                               ; %cond.store475
                                        ;   in Loop: Header=BB0_140 Depth=1
	fmov	x15, d18
	str	s10, [x15]
	tbz	w14, #5, LBB0_154
LBB0_169:                               ; %cond.store479
                                        ;   in Loop: Header=BB0_140 Depth=1
	mov.d	x15, v18[1]
	st1.s	{ v10 }[1], [x15]
	orr.16b	v17, v17, v5
	add.2d	v17, v24, v17
	tbz	w14, #6, LBB0_155
LBB0_170:                               ; %cond.store483
                                        ;   in Loop: Header=BB0_140 Depth=1
	fmov	x15, d17
	st1.s	{ v10 }[2], [x15]
	tbz	w14, #7, LBB0_139
LBB0_171:                               ; %cond.store487
                                        ;   in Loop: Header=BB0_140 Depth=1
	mov.d	x14, v17[1]
	st1.s	{ v10 }[3], [x14]
	b	LBB0_139
LBB0_172:                               ; %direct.false71
	mov	x12, #0                         ; =0x0
	xtn.8b	v10, v21
	fadd.4s	v17, v26, v30
	fadd.4s	v18, v25, v29
	fadd.4s	v18, v18, v31
	fadd.4s	v17, v17, v27
	fadd.4s	v21, v17, v28
	fadd.4s	v25, v18, v8
	ldp	q18, q17, [sp, #16]             ; 32-byte Folded Reload
	and.16b	v17, v20, v17
	and.16b	v18, v19, v18
	movi.4s	v19, #1
	eor.16b	v20, v18, v19
	eor.16b	v28, v17, v19
	umov.b	w14, v10[0]
	str	q25, [x11, #192]
	ldr	s19, [x11, #196]
	umov.b	w13, v10[1]
	ands	w15, w14, #0x1
	tst	w15, w13
	movi	d17, #0000000000000000
	fcsel	s19, s19, s17, ne
	mov.s	w16, v28[1]
	add	x17, sp, #56
	add	x0, sp, #56
	bfxil	x0, x16, #0, #3
	str	d10, [sp, #56]
	ldrb	w0, [x0]
	add	x1, sp, #352
	orr	x16, x1, x16, lsl #2
	stp	q25, q21, [x11, #160]
	ldr	s26, [x16]
	ands	w16, w13, #0x1
	tst	w16, w0
	fcsel	s26, s26, s17, ne
	mov.s	w16, v28[2]
	add	x0, sp, #56
	bfxil	x0, x16, #0, #3
	ldrb	w0, [x0]
	add	x1, sp, #320
	orr	x1, x1, x16, lsl #2
	umov.b	w16, v10[2]
	stp	q25, q21, [x11, #128]
	ldr	s27, [x1]
	ands	w1, w16, #0x1
	tst	w1, w0
	fcsel	s27, s27, s17, ne
	mov.s	w1, v28[3]
	add	x0, sp, #56
	bfxil	x0, x1, #0, #3
	ldrb	w2, [x0]
	add	x3, sp, #288
	umov.b	w0, v10[3]
	orr	x1, x3, x1, lsl #2
	stp	q25, q21, [x11, #96]
	ldr	s28, [x1]
	ands	w1, w0, #0x1
	tst	w1, w2
	fcsel	s28, s28, s17, ne
	fmov	w2, s20
	add	x3, sp, #56
	bfxil	x3, x2, #0, #3
	umov.b	w1, v10[4]
	ldrb	w3, [x3]
	stp	q25, q21, [x11, #64]
	add	x4, sp, #256
	ldr	s29, [x4, w2, uxtw #2]
	and	w2, w1, w3
	tst	w2, #0x1
	fcsel	s29, s29, s17, ne
	mov.s	w3, v20[1]
	add	x2, sp, #56
	bfxil	x2, x3, #0, #3
	ldrb	w4, [x2]
	umov.b	w2, v10[5]
	stp	q25, q21, [x11, #32]
	add	x5, sp, #224
	ldr	s30, [x5, w3, uxtw #2]
	ands	w3, w2, #0x1
	tst	w3, w4
	fcsel	s30, s30, s17, ne
	mov.s	w4, v20[2]
	add	x5, sp, #56
	bfxil	x5, x4, #0, #3
	umov.b	w3, v10[6]
	ldrb	w5, [x5]
	stp	q25, q21, [x11]
	add	x11, sp, #192
	ldr	s31, [x11, w4, uxtw #2]
	ands	w11, w3, #0x1
	tst	w11, w5
	mov.s	w11, v20[3]
	add	x4, sp, #56
	bfxil	x4, x11, #0, #3
	ldrb	w4, [x4]
	stp	q25, q21, [sp, #160]
	add	x5, sp, #160
	ldr	s20, [x5, w11, uxtw #2]
	fcsel	s31, s31, s17, ne
	umov.b	w11, v10[7]
	ands	w5, w11, #0x1
	tst	w5, w4
	fcsel	s20, s20, s17, ne
	mov.s	v19[1], v26[0]
	mov.s	v19[2], v27[0]
	mov.s	v19[3], v28[0]
	mov.s	v29[1], v30[0]
	mov.s	v29[2], v31[0]
	mov.s	v29[3], v20[0]
	fadd.4s	v20, v21, v29
	fadd.4s	v19, v25, v19
	movi.4s	v21, #2
	eor.16b	v18, v18, v21
	str	q19, [sp, #128]
	ldr	s21, [sp, #136]
	tst	w15, w16
	fcsel	s21, s21, s17, ne
	fmov	w4, s18
	bfxil	x17, x4, #0, #3
	ldrb	w17, [x17]
	and	w17, w1, w17
	stp	q19, q20, [sp, #96]
	add	x5, sp, #96
	ldr	s18, [x5, w4, uxtw #2]
	tst	w17, #0x1
	fcsel	s18, s18, s17, ne
	fadd.4s	v18, v20, v18
	tst	w15, w1
	fcsel	s18, s18, s17, ne
	ands	w14, w14, #0x1
	fadd.4s	v19, v19, v21
	fadd	s18, s19, s18
	fcsel	s19, s18, s17, ne
	tst	w13, #0x1
	fcsel	s20, s19, s17, ne
	tst	w16, #0x1
	fcsel	s21, s19, s17, ne
	tst	w0, #0x1
	fcsel	s25, s19, s17, ne
	tst	w14, w1
	fcsel	s18, s18, s17, ne
	tst	w2, #0x1
	fcsel	s26, s19, s17, ne
	tst	w3, #0x1
	fcsel	s27, s19, s17, ne
	tst	w11, #0x1
	fcsel	s28, s19, s17, ne
	mov.s	v19[1], v20[0]
	mov.s	v19[2], v21[0]
	mov.s	v19[3], v25[0]
	mov.s	v18[1], v26[0]
	mov.s	v18[2], v27[0]
	mov.s	v18[3], v28[0]
	rbit	w9, w9
	clz	w9, w9
	stp	q19, q18, [sp, #64]
	and	x9, x9, #0x7
	add	x11, sp, #64
	ldr	s18, [x11, x9, lsl #2]
	fadd	s17, s18, s17
	mov	w9, #998244352                  ; =0x3b800000
	fmov	s18, w9
	fmul	s17, s17, s18
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s18, w9
	fadd	s17, s17, s18
	fsqrt	s17, s17
	dup.4s	v17, v17[0]
	add	x8, x8, x10
	fmov	w9, s0
	b	LBB0_174
LBB0_173:                               ; %else605
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x12, x12, #32
	cmp	x12, #1024
	b.eq	LBB0_222
LBB0_174:                               ; %direct.true88
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v26, x12
	orr.16b	v20, v26, v16
	add.2d	v21, v4, v20
	movi.2d	v19, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w9, #0, LBB0_198
; %bb.175:                              ; %else496
                                        ;   in Loop: Header=BB0_174 Depth=1
	and	w10, w9, #0xff
	tbnz	w10, #1, LBB0_199
LBB0_176:                               ; %else502
                                        ;   in Loop: Header=BB0_174 Depth=1
	orr.16b	v21, v26, v6
	add.2d	v25, v2, v21
	tbnz	w10, #2, LBB0_200
LBB0_177:                               ; %else508
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w10, #3, LBB0_201
LBB0_178:                               ; %else514
                                        ;   in Loop: Header=BB0_174 Depth=1
	orr.16b	v25, v26, v7
	add.2d	v27, v3, v25
	tbnz	w10, #4, LBB0_202
LBB0_179:                               ; %else520
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w10, #5, LBB0_203
LBB0_180:                               ; %else526
                                        ;   in Loop: Header=BB0_174 Depth=1
	orr.16b	v26, v26, v5
	add.2d	v27, v1, v26
	tbnz	w10, #6, LBB0_204
LBB0_181:                               ; %else532
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w10, #7, LBB0_205
LBB0_182:                               ; %else538
                                        ;   in Loop: Header=BB0_174 Depth=1
	fmov	w10, s0
	add.2d	v28, v22, v20
	movi.2d	v27, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbnz	w10, #0, LBB0_206
LBB0_183:                               ; %else545
                                        ;   in Loop: Header=BB0_174 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_207
LBB0_184:                               ; %else551
                                        ;   in Loop: Header=BB0_174 Depth=1
	add.2d	v21, v23, v21
	tbnz	w10, #2, LBB0_208
LBB0_185:                               ; %else557
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w10, #3, LBB0_209
LBB0_186:                               ; %else563
                                        ;   in Loop: Header=BB0_174 Depth=1
	add.2d	v21, v9, v25
	tbnz	w10, #4, LBB0_210
LBB0_187:                               ; %else569
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w10, #5, LBB0_211
LBB0_188:                               ; %else575
                                        ;   in Loop: Header=BB0_174 Depth=1
	add.2d	v21, v24, v26
	tbnz	w10, #6, LBB0_212
LBB0_189:                               ; %else581
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w10, #7, LBB0_213
LBB0_190:                               ; %else587
                                        ;   in Loop: Header=BB0_174 Depth=1
	fdiv.4s	v19, v19, v17
	fmov	w11, s0
	fmul.4s	v19, v19, v27
	add	x10, x8, x12
	tbnz	w11, #0, LBB0_214
LBB0_191:                               ; %else591
                                        ;   in Loop: Header=BB0_174 Depth=1
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_215
LBB0_192:                               ; %else593
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w11, #2, LBB0_216
LBB0_193:                               ; %else595
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w11, #3, LBB0_217
LBB0_194:                               ; %else597
                                        ;   in Loop: Header=BB0_174 Depth=1
	fdiv.4s	v18, v18, v17
	fmul.4s	v18, v18, v20
	tbnz	w11, #4, LBB0_218
LBB0_195:                               ; %else599
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w11, #5, LBB0_219
LBB0_196:                               ; %else601
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w11, #6, LBB0_220
LBB0_197:                               ; %else603
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbz	w11, #7, LBB0_173
	b	LBB0_221
LBB0_198:                               ; %cond.load492
                                        ;   in Loop: Header=BB0_174 Depth=1
	fmov	x10, d21
	ldr	s19, [x10]
	and	w10, w9, #0xff
	tbz	w10, #1, LBB0_176
LBB0_199:                               ; %cond.load498
                                        ;   in Loop: Header=BB0_174 Depth=1
	mov.d	x11, v21[1]
	ld1.s	{ v19 }[1], [x11]
	orr.16b	v21, v26, v6
	add.2d	v25, v2, v21
	tbz	w10, #2, LBB0_177
LBB0_200:                               ; %cond.load504
                                        ;   in Loop: Header=BB0_174 Depth=1
	fmov	x11, d25
	ld1.s	{ v19 }[2], [x11]
	tbz	w10, #3, LBB0_178
LBB0_201:                               ; %cond.load510
                                        ;   in Loop: Header=BB0_174 Depth=1
	mov.d	x11, v25[1]
	ld1.s	{ v19 }[3], [x11]
	orr.16b	v25, v26, v7
	add.2d	v27, v3, v25
	tbz	w10, #4, LBB0_179
LBB0_202:                               ; %cond.load516
                                        ;   in Loop: Header=BB0_174 Depth=1
	fmov	x11, d27
	ld1.s	{ v18 }[0], [x11]
	tbz	w10, #5, LBB0_180
LBB0_203:                               ; %cond.load522
                                        ;   in Loop: Header=BB0_174 Depth=1
	mov.d	x11, v27[1]
	ld1.s	{ v18 }[1], [x11]
	orr.16b	v26, v26, v5
	add.2d	v27, v1, v26
	tbz	w10, #6, LBB0_181
LBB0_204:                               ; %cond.load528
                                        ;   in Loop: Header=BB0_174 Depth=1
	fmov	x11, d27
	ld1.s	{ v18 }[2], [x11]
	tbz	w10, #7, LBB0_182
LBB0_205:                               ; %cond.load534
                                        ;   in Loop: Header=BB0_174 Depth=1
	mov.d	x10, v27[1]
	ld1.s	{ v18 }[3], [x10]
	fmov	w10, s0
	add.2d	v28, v22, v20
	movi.2d	v27, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbz	w10, #0, LBB0_183
LBB0_206:                               ; %cond.load541
                                        ;   in Loop: Header=BB0_174 Depth=1
	fmov	x11, d28
	ldr	s27, [x11]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_184
LBB0_207:                               ; %cond.load547
                                        ;   in Loop: Header=BB0_174 Depth=1
	mov.d	x11, v28[1]
	ld1.s	{ v27 }[1], [x11]
	add.2d	v21, v23, v21
	tbz	w10, #2, LBB0_185
LBB0_208:                               ; %cond.load553
                                        ;   in Loop: Header=BB0_174 Depth=1
	fmov	x11, d21
	ld1.s	{ v27 }[2], [x11]
	tbz	w10, #3, LBB0_186
LBB0_209:                               ; %cond.load559
                                        ;   in Loop: Header=BB0_174 Depth=1
	mov.d	x11, v21[1]
	ld1.s	{ v27 }[3], [x11]
	add.2d	v21, v9, v25
	tbz	w10, #4, LBB0_187
LBB0_210:                               ; %cond.load565
                                        ;   in Loop: Header=BB0_174 Depth=1
	fmov	x11, d21
	ld1.s	{ v20 }[0], [x11]
	tbz	w10, #5, LBB0_188
LBB0_211:                               ; %cond.load571
                                        ;   in Loop: Header=BB0_174 Depth=1
	mov.d	x11, v21[1]
	ld1.s	{ v20 }[1], [x11]
	add.2d	v21, v24, v26
	tbz	w10, #6, LBB0_189
LBB0_212:                               ; %cond.load577
                                        ;   in Loop: Header=BB0_174 Depth=1
	fmov	x11, d21
	ld1.s	{ v20 }[2], [x11]
	tbz	w10, #7, LBB0_190
LBB0_213:                               ; %cond.load583
                                        ;   in Loop: Header=BB0_174 Depth=1
	mov.d	x10, v21[1]
	ld1.s	{ v20 }[3], [x10]
	fdiv.4s	v19, v19, v17
	fmov	w11, s0
	fmul.4s	v19, v19, v27
	add	x10, x8, x12
	tbz	w11, #0, LBB0_191
LBB0_214:                               ; %cond.store590
                                        ;   in Loop: Header=BB0_174 Depth=1
	str	s19, [x10]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_192
LBB0_215:                               ; %cond.store592
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x13, x10, #4
	st1.s	{ v19 }[1], [x13]
	tbz	w11, #2, LBB0_193
LBB0_216:                               ; %cond.store594
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x13, x10, #8
	st1.s	{ v19 }[2], [x13]
	tbz	w11, #3, LBB0_194
LBB0_217:                               ; %cond.store596
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x13, x10, #12
	st1.s	{ v19 }[3], [x13]
	fdiv.4s	v18, v18, v17
	fmul.4s	v18, v18, v20
	tbz	w11, #4, LBB0_195
LBB0_218:                               ; %cond.store598
                                        ;   in Loop: Header=BB0_174 Depth=1
	str	s18, [x10, #16]
	tbz	w11, #5, LBB0_196
LBB0_219:                               ; %cond.store600
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x13, x10, #20
	st1.s	{ v18 }[1], [x13]
	tbz	w11, #6, LBB0_197
LBB0_220:                               ; %cond.store602
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x13, x10, #24
	st1.s	{ v18 }[2], [x13]
	tbz	w11, #7, LBB0_173
LBB0_221:                               ; %cond.store604
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x10, x10, #28
	st1.s	{ v18 }[3], [x10]
	b	LBB0_173
LBB0_222:                               ; %common.ret
	add	sp, sp, #2480
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
	ret
LBB0_223:                               ; %cond.load58
	fmov	x14, d27
	ldr	s25, [x14]
	tbz	w13, #1, LBB0_37
LBB0_224:                               ; %cond.load62
	mov.d	x14, v27[1]
	ld1.s	{ v25 }[1], [x14]
	add.2d	v28, v2, v6
	tbz	w13, #2, LBB0_38
LBB0_225:                               ; %cond.load66
	fmov	x14, d28
	ld1.s	{ v25 }[2], [x14]
	tbz	w13, #3, LBB0_39
LBB0_226:                               ; %cond.load70
	mov.d	x14, v28[1]
	ld1.s	{ v25 }[3], [x14]
	add.2d	v29, v3, v7
	tbz	w13, #4, LBB0_40
LBB0_227:                               ; %cond.load74
	fmov	x14, d29
	ld1.s	{ v26 }[0], [x14]
	tbz	w13, #5, LBB0_41
LBB0_228:                               ; %cond.load78
	mov.d	x14, v29[1]
	ld1.s	{ v26 }[1], [x14]
	add.2d	v30, v1, v5
	tbz	w13, #6, LBB0_42
LBB0_229:                               ; %cond.load82
	fmov	x14, d30
	ld1.s	{ v26 }[2], [x14]
	tbnz	w13, #7, LBB0_43
	b	LBB0_44
LBB0_230:                               ; %cond.load91
	fmov	x14, d18
	ldr	s31, [x14]
	tbz	w13, #1, LBB0_46
LBB0_231:                               ; %cond.load97
	mov.d	x14, v18[1]
	ld1.s	{ v31 }[1], [x14]
	add.2d	v18, v28, v17
	tbz	w13, #2, LBB0_47
LBB0_232:                               ; %cond.load103
	fmov	x14, d18
	ld1.s	{ v31 }[2], [x14]
	tbz	w13, #3, LBB0_48
LBB0_233:                               ; %cond.load109
	mov.d	x14, v18[1]
	ld1.s	{ v31 }[3], [x14]
	add.2d	v18, v29, v17
	tbz	w13, #4, LBB0_49
LBB0_234:                               ; %cond.load115
	fmov	x14, d18
	ld1.s	{ v8 }[0], [x14]
	tbz	w13, #5, LBB0_50
LBB0_235:                               ; %cond.load121
	mov.d	x14, v18[1]
	ld1.s	{ v8 }[1], [x14]
	add.2d	v17, v30, v17
	tbz	w13, #6, LBB0_51
LBB0_236:                               ; %cond.load127
	fmov	x14, d17
	ld1.s	{ v8 }[2], [x14]
	tbnz	w13, #7, LBB0_52
	b	LBB0_53
LBB0_237:                               ; %cond.load140
	fmov	x14, d18
	ldr	s9, [x14]
	tbz	w13, #1, LBB0_55
LBB0_238:                               ; %cond.load146
	mov.d	x14, v18[1]
	ld1.s	{ v9 }[1], [x14]
	add.2d	v18, v28, v17
	tbz	w13, #2, LBB0_56
LBB0_239:                               ; %cond.load152
	fmov	x14, d18
	ld1.s	{ v9 }[2], [x14]
	tbz	w13, #3, LBB0_57
LBB0_240:                               ; %cond.load158
	mov.d	x14, v18[1]
	ld1.s	{ v9 }[3], [x14]
	add.2d	v18, v29, v17
	tbz	w13, #4, LBB0_58
LBB0_241:                               ; %cond.load164
	fmov	x14, d18
	ld1.s	{ v10 }[0], [x14]
	tbz	w13, #5, LBB0_59
LBB0_242:                               ; %cond.load170
	mov.d	x14, v18[1]
	ld1.s	{ v10 }[1], [x14]
	add.2d	v17, v30, v17
	tbz	w13, #6, LBB0_60
LBB0_243:                               ; %cond.load176
	fmov	x14, d17
	ld1.s	{ v10 }[2], [x14]
	tbnz	w13, #7, LBB0_61
	b	LBB0_62
LBB0_244:                               ; %cond.load189
	fmov	x14, d23
	ldr	s17, [x14]
	tbz	w13, #1, LBB0_64
LBB0_245:                               ; %cond.load195
	mov.d	x14, v23[1]
	ld1.s	{ v17 }[1], [x14]
	add.2d	v23, v28, v18
	tbz	w13, #2, LBB0_65
LBB0_246:                               ; %cond.load201
	fmov	x14, d23
	ld1.s	{ v17 }[2], [x14]
	tbz	w13, #3, LBB0_66
LBB0_247:                               ; %cond.load207
	mov.d	x14, v23[1]
	ld1.s	{ v17 }[3], [x14]
	add.2d	v23, v29, v18
	tbz	w13, #4, LBB0_67
LBB0_248:                               ; %cond.load213
	fmov	x14, d23
	ld1.s	{ v27 }[0], [x14]
	tbz	w13, #5, LBB0_68
LBB0_249:                               ; %cond.load219
	mov.d	x14, v23[1]
	ld1.s	{ v27 }[1], [x14]
	add.2d	v29, v30, v18
	tbnz	w13, #6, LBB0_69
	b	LBB0_70
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_13
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	mov	w22, #0                         ; =0x0
	ldp	w24, w8, [x2, #44]
	stp	w3, w8, [sp, #8]                ; 8-byte Folded Spill
	ldp	w25, w26, [x2]
	ldp	w28, w27, [x2, #8]
	str	w24, [sp, #4]                   ; 4-byte Folded Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #504                        ; =0x1f8
	str	w8, [x20, #36]
	ldp	w24, w19, [sp, #4]              ; 8-byte Folded Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w24
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w26, eq
	ldr	w10, [sp, #12]                  ; 4-byte Folded Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w26, wzr, w9, ne
	add	w28, w28, w8
	add	w22, w22, #1
	cmp	w22, w19
	b.eq	LBB1_12
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_9 Depth 2
                                        ;     Child Loop BB1_6 Depth 2
	ubfiz	x8, x25, #9, #32
	cmp	x8, x27
	csel	x9, x8, xzr, ls
	subs	x10, x27, x9
	cmp	x10, #512
	mov	w11, #512                       ; =0x200
	csel	x10, x10, x11, lo
	cmp	x27, x9
	stp	w25, w26, [x20]
	str	w28, [x20, #8]
	ccmp	x8, x27, #2, hi
	csel	x23, x10, xzr, ls
	cmp	x23, #512
	b.lo	LBB1_7
; %bb.5:                                ; %packet.batch.full.loop.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w23, #0                         ; =0x0
LBB1_6:                                 ; %packet.batch.full.loop.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	w23, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w23, w23, #8
	cmp	w23, #512
	b.ne	LBB1_6
	b	LBB1_3
LBB1_7:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x8, x23, #3
	lsl	w24, w8, #3
	cmp	x23, #8
	b.lo	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w19, #0                         ; =0x0
LBB1_9:                                 ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	w19, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w19, w19, #8
	cmp	w24, w19
	b.ne	LBB1_9
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w23, #0x7
	cbz	w2, LBB1_2
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w24, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
	b	LBB1_2
LBB1_12:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_13:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

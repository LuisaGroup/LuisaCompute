	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_4:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_6:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_7:
	.quad	32                              ; 0x20
	.quad	36                              ; 0x24
lCPI0_8:
	.quad	48                              ; 0x30
	.quad	52                              ; 0x34
lCPI0_9:
	.quad	40                              ; 0x28
	.quad	44                              ; 0x2c
lCPI0_10:
	.quad	56                              ; 0x38
	.quad	60                              ; 0x3c
lCPI0_11:
	.quad	64                              ; 0x40
	.quad	68                              ; 0x44
lCPI0_12:
	.quad	80                              ; 0x50
	.quad	84                              ; 0x54
lCPI0_13:
	.quad	72                              ; 0x48
	.quad	76                              ; 0x4c
lCPI0_14:
	.quad	88                              ; 0x58
	.quad	92                              ; 0x5c
lCPI0_15:
	.quad	96                              ; 0x60
	.quad	100                             ; 0x64
lCPI0_16:
	.quad	112                             ; 0x70
	.quad	116                             ; 0x74
lCPI0_17:
	.quad	104                             ; 0x68
	.quad	108                             ; 0x6c
lCPI0_18:
	.quad	120                             ; 0x78
	.quad	124                             ; 0x7c
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-96]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #1104
	dup.4s	v0, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v20, v0, v4
	cmhi.4s	v19, v0, v3
	uzp1.8h	v0, v19, v20
	umaxv.8h	h1, v0
	fmov	w8, s1
	tbz	w8, #0, LBB0_206
; %bb.1:                                ; %direct.activate
	mov	x14, #0                         ; =0x0
	add	x11, sp, #160
	ldr	x9, [x1, #136]
	add	x8, x9, #32, lsl #12            ; =131072
	dup.2d	v1, x8
	str	q1, [sp]                        ; 16-byte Folded Spill
	ldr	x16, [x0]
	ldr	x12, [x0, #16]
	ldr	x8, [x0, #48]
Lloh4:
	adrp	x10, lCPI0_0@PAGE
Lloh5:
	ldr	q1, [x10, lCPI0_0@PAGEOFF]
	and.16b	v0, v0, v1
	addv.8h	h0, v0
	fmov	w10, s0
	and	w10, w10, #0xff
	sshll2.2d	v1, v20, #0
	sshll2.2d	v2, v19, #0
	sshll.2d	v7, v20, #0
	sshll.2d	v16, v19, #0
	ldr	w13, [x1]
	ldr	w15, [x1, #36]
	add	w13, w15, w13, lsl #10
	dup.4s	v5, w13
	add.4s	v3, v5, v3
	add.4s	v4, v5, v4
	dup.2d	v17, x9
	and.16b	v5, v20, v4
	and.16b	v6, v19, v3
	ushll2.2d	v3, v5, #14
	ushll2.2d	v4, v6, #14
	ushll.2d	v5, v5, #14
	ushll.2d	v6, v6, #14
	rbit	w9, w10
	clz	w13, w9
	and.16b	v16, v16, v17
	and.16b	v7, v7, v17
	and.16b	v18, v2, v17
	and.16b	v17, v1, v17
	stp	q7, q17, [x11, #896]
	stp	q16, q18, [x11, #864]
	and	x9, x13, #0x7
	add	x10, sp, #1024
	ldr	x9, [x10, x9, lsl #3]
	lsl	w10, w13, #2
	fmov	w15, s0
	dup.2d	v7, x16
	add.2d	v22, v7, v5
	add.2d	v23, v7, v4
	add.2d	v24, v7, v6
	add.2d	v25, v7, v3
Lloh6:
	adrp	x16, lCPI0_3@PAGE
Lloh7:
	ldr	q7, [x16, lCPI0_3@PAGEOFF]
Lloh8:
	adrp	x16, lCPI0_4@PAGE
Lloh9:
	ldr	q16, [x16, lCPI0_4@PAGEOFF]
Lloh10:
	adrp	x16, lCPI0_5@PAGE
Lloh11:
	ldr	q17, [x16, lCPI0_5@PAGEOFF]
Lloh12:
	adrp	x16, lCPI0_6@PAGE
Lloh13:
	ldr	q18, [x16, lCPI0_6@PAGEOFF]
	and	x16, x13, #0x7
	add	x17, sp, #944
	b	LBB0_3
LBB0_2:                                 ; %else51
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x14, x14, #1
	cmp	x14, #1, lsl #12                ; =4096
	b.eq	LBB0_35
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v28, x14
	shl.2d	v29, v28, #2
	add.2d	v30, v24, v29
	movi.2d	v27, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbnz	w15, #0, LBB0_20
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w0, w15, #0xff
	tbnz	w0, #1, LBB0_21
LBB0_5:                                 ; %else16
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v30, v23, v29
	tbnz	w0, #2, LBB0_22
LBB0_6:                                 ; %else19
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #3, LBB0_23
LBB0_7:                                 ; %else22
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v30, v22, v29
	tbnz	w0, #4, LBB0_24
LBB0_8:                                 ; %else25
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #5, LBB0_25
LBB0_9:                                 ; %else28
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v29, v25, v29
	tbnz	w0, #6, LBB0_26
LBB0_10:                                ; %else31
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w0, #7, LBB0_12
LBB0_11:                                ; %cond.load33
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x0, v29[1]
	ld1.s	{ v26 }[3], [x0]
LBB0_12:                                ; %else34
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	w1, s0
	sshll.2d	v29, v20, #0
	sshll.2d	v30, v19, #0
	shl.2d	v28, v28, #5
	orr.16b	v31, v28, v7
	orr.16b	v8, v28, v16
	orr.16b	v9, v28, v17
	orr.16b	v28, v28, v18
	and.16b	v28, v1, v28
	and.16b	v30, v30, v9
	and.16b	v29, v29, v8
	and.16b	v31, v2, v31
	stp	q30, q31, [x11, #784]
	stp	q29, q28, [x11, #816]
	ldr	x0, [x17, x16, lsl #3]
	sub	x0, x0, x10
	add	x0, x9, x0
	tbnz	w1, #0, LBB0_27
; %bb.13:                               ; %else37
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB0_28
LBB0_14:                                ; %else39
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w1, #2, LBB0_29
LBB0_15:                                ; %else41
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w1, #3, LBB0_30
LBB0_16:                                ; %else43
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w1, #4, LBB0_31
LBB0_17:                                ; %else45
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w1, #5, LBB0_32
LBB0_18:                                ; %else47
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w1, #6, LBB0_33
LBB0_19:                                ; %else49
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w1, #7, LBB0_2
	b	LBB0_34
LBB0_20:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x0, d30
	ldr	s27, [x0]
	and	w0, w15, #0xff
	tbz	w0, #1, LBB0_5
LBB0_21:                                ; %cond.load15
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x1, v30[1]
	ld1.s	{ v27 }[1], [x1]
	add.2d	v30, v23, v29
	tbz	w0, #2, LBB0_6
LBB0_22:                                ; %cond.load18
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x1, d30
	ld1.s	{ v27 }[2], [x1]
	tbz	w0, #3, LBB0_7
LBB0_23:                                ; %cond.load21
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x1, v30[1]
	ld1.s	{ v27 }[3], [x1]
	add.2d	v30, v22, v29
	tbz	w0, #4, LBB0_8
LBB0_24:                                ; %cond.load24
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x1, d30
	ld1.s	{ v26 }[0], [x1]
	tbz	w0, #5, LBB0_9
LBB0_25:                                ; %cond.load27
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x1, v30[1]
	ld1.s	{ v26 }[1], [x1]
	add.2d	v29, v25, v29
	tbz	w0, #6, LBB0_10
LBB0_26:                                ; %cond.load30
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x1, d29
	ld1.s	{ v26 }[2], [x1]
	tbnz	w0, #7, LBB0_11
	b	LBB0_12
LBB0_27:                                ; %cond.store
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s27, [x0]
	and	w1, w1, #0xff
	tbz	w1, #1, LBB0_14
LBB0_28:                                ; %cond.store38
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x0, #4
	st1.s	{ v27 }[1], [x2]
	tbz	w1, #2, LBB0_15
LBB0_29:                                ; %cond.store40
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x0, #8
	st1.s	{ v27 }[2], [x2]
	tbz	w1, #3, LBB0_16
LBB0_30:                                ; %cond.store42
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x0, #12
	st1.s	{ v27 }[3], [x2]
	tbz	w1, #4, LBB0_17
LBB0_31:                                ; %cond.store44
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s26, [x0, #16]
	tbz	w1, #5, LBB0_18
LBB0_32:                                ; %cond.store46
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x0, #20
	st1.s	{ v26 }[1], [x2]
	tbz	w1, #6, LBB0_19
LBB0_33:                                ; %cond.store48
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x0, #24
	st1.s	{ v26 }[2], [x2]
	tbz	w1, #7, LBB0_2
LBB0_34:                                ; %cond.store50
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x0, #28
	st1.s	{ v26 }[3], [x0]
	b	LBB0_2
LBB0_35:                                ; %direct.false
	fmov	w16, s0
	and	w14, w16, #0xff
	sshll.2d	v22, v20, #0
	sshll.2d	v23, v19, #0
	and.16b	v23, v23, v17
	and.16b	v22, v22, v16
	and.16b	v24, v2, v7
	and.16b	v25, v1, v18
	stp	q22, q25, [x11, #736]
	stp	q23, q24, [x11, #704]
	and	x15, x13, #0x7
	add	x17, sp, #864
	ldr	x15, [x17, x15, lsl #3]
	sub	x15, x15, x10
	add	x15, x9, x15
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w16, #0, LBB0_207
; %bb.36:                               ; %else54
	tbnz	w14, #1, LBB0_208
LBB0_37:                                ; %else57
	tbnz	w14, #2, LBB0_209
LBB0_38:                                ; %else60
	tbnz	w14, #3, LBB0_210
LBB0_39:                                ; %else63
	tbnz	w14, #4, LBB0_211
LBB0_40:                                ; %else66
	tbnz	w14, #5, LBB0_212
LBB0_41:                                ; %else69
	tbnz	w14, #6, LBB0_213
LBB0_42:                                ; %else72
	tbz	w14, #7, LBB0_44
LBB0_43:                                ; %cond.load74
	add	x14, x15, #28
	ld1.s	{ v23 }[3], [x14]
LBB0_44:                                ; %else75
	fmov	w16, s0
	and	w14, w16, #0xff
	sshll.2d	v24, v20, #0
	sshll.2d	v25, v19, #0
Lloh14:
	adrp	x15, lCPI0_7@PAGE
Lloh15:
	ldr	q26, [x15, lCPI0_7@PAGEOFF]
	and.16b	v25, v25, v26
Lloh16:
	adrp	x15, lCPI0_8@PAGE
Lloh17:
	ldr	q26, [x15, lCPI0_8@PAGEOFF]
	and.16b	v24, v24, v26
Lloh18:
	adrp	x15, lCPI0_9@PAGE
Lloh19:
	ldr	q26, [x15, lCPI0_9@PAGEOFF]
	and.16b	v26, v2, v26
Lloh20:
	adrp	x15, lCPI0_10@PAGE
Lloh21:
	ldr	q27, [x15, lCPI0_10@PAGEOFF]
	and.16b	v27, v1, v27
	stp	q24, q27, [x11, #656]
	stp	q25, q26, [x11, #624]
	and	x15, x13, #0x7
	add	x17, sp, #784
	ldr	x15, [x17, x15, lsl #3]
	sub	x15, x15, x10
	add	x15, x9, x15
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	tbnz	w16, #0, LBB0_214
; %bb.45:                               ; %else79
	tbnz	w14, #1, LBB0_215
LBB0_46:                                ; %else82
	tbnz	w14, #2, LBB0_216
LBB0_47:                                ; %else85
	tbnz	w14, #3, LBB0_217
LBB0_48:                                ; %else88
	tbnz	w14, #4, LBB0_218
LBB0_49:                                ; %else91
	tbnz	w14, #5, LBB0_219
LBB0_50:                                ; %else94
	tbnz	w14, #6, LBB0_220
LBB0_51:                                ; %else97
	tbz	w14, #7, LBB0_53
LBB0_52:                                ; %cond.load99
	add	x14, x15, #28
	ld1.s	{ v25 }[3], [x14]
LBB0_53:                                ; %else100
	fmov	w16, s0
	and	w14, w16, #0xff
	sshll.2d	v26, v20, #0
	sshll.2d	v27, v19, #0
Lloh22:
	adrp	x15, lCPI0_11@PAGE
Lloh23:
	ldr	q28, [x15, lCPI0_11@PAGEOFF]
	and.16b	v27, v27, v28
Lloh24:
	adrp	x15, lCPI0_12@PAGE
Lloh25:
	ldr	q28, [x15, lCPI0_12@PAGEOFF]
	and.16b	v26, v26, v28
Lloh26:
	adrp	x15, lCPI0_13@PAGE
Lloh27:
	ldr	q28, [x15, lCPI0_13@PAGEOFF]
	and.16b	v28, v2, v28
Lloh28:
	adrp	x15, lCPI0_14@PAGE
Lloh29:
	ldr	q29, [x15, lCPI0_14@PAGEOFF]
	and.16b	v29, v1, v29
	stp	q26, q29, [x11, #576]
	stp	q27, q28, [x11, #544]
	and	x15, x13, #0x7
	add	x17, sp, #704
	ldr	x15, [x17, x15, lsl #3]
	sub	x15, x15, x10
	add	x15, x9, x15
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w16, #0, LBB0_221
; %bb.54:                               ; %else104
	tbnz	w14, #1, LBB0_222
LBB0_55:                                ; %else107
	tbnz	w14, #2, LBB0_223
LBB0_56:                                ; %else110
	tbnz	w14, #3, LBB0_224
LBB0_57:                                ; %else113
	tbnz	w14, #4, LBB0_225
LBB0_58:                                ; %else116
	tbnz	w14, #5, LBB0_226
LBB0_59:                                ; %else119
	tbnz	w14, #6, LBB0_227
LBB0_60:                                ; %else122
	tbz	w14, #7, LBB0_62
LBB0_61:                                ; %cond.load124
	add	x14, x15, #28
	ld1.s	{ v27 }[3], [x14]
LBB0_62:                                ; %else125
	fmov	w16, s0
	and	w14, w16, #0xff
	sshll.2d	v28, v20, #0
	sshll.2d	v29, v19, #0
Lloh30:
	adrp	x15, lCPI0_15@PAGE
Lloh31:
	ldr	q30, [x15, lCPI0_15@PAGEOFF]
	and.16b	v29, v29, v30
Lloh32:
	adrp	x15, lCPI0_16@PAGE
Lloh33:
	ldr	q30, [x15, lCPI0_16@PAGEOFF]
	and.16b	v28, v28, v30
Lloh34:
	adrp	x15, lCPI0_17@PAGE
Lloh35:
	ldr	q30, [x15, lCPI0_17@PAGEOFF]
	and.16b	v30, v2, v30
Lloh36:
	adrp	x15, lCPI0_18@PAGE
Lloh37:
	ldr	q31, [x15, lCPI0_18@PAGEOFF]
	and.16b	v31, v1, v31
	stp	q28, q31, [x11, #496]
	stp	q29, q30, [x11, #464]
	and	x15, x13, #0x7
	add	x17, sp, #624
	ldr	x15, [x17, x15, lsl #3]
	sub	x15, x15, x10
	add	x15, x9, x15
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w16, #0, LBB0_228
; %bb.63:                               ; %else129
	tbnz	w14, #1, LBB0_229
LBB0_64:                                ; %else132
	tbnz	w14, #2, LBB0_230
LBB0_65:                                ; %else135
	tbnz	w14, #3, LBB0_231
LBB0_66:                                ; %else138
	tbnz	w14, #4, LBB0_232
LBB0_67:                                ; %else141
	tbnz	w14, #5, LBB0_233
LBB0_68:                                ; %else144
	tbz	w14, #6, LBB0_70
LBB0_69:                                ; %cond.load146
	add	x16, x15, #24
	ld1.s	{ v29 }[2], [x16]
LBB0_70:                                ; %else147
	stp	q5, q4, [sp, #16]               ; 32-byte Folded Spill
	str	q3, [sp, #48]                   ; 16-byte Folded Spill
	fmul.4s	v30, v22, v22
	fmul.4s	v22, v23, v23
	fmul.4s	v31, v24, v24
	fmul.4s	v23, v25, v25
	fmul.4s	v26, v26, v26
	fmul.4s	v27, v27, v27
	tbz	w14, #7, LBB0_72
; %bb.71:                               ; %cond.load149
	add	x14, x15, #28
	ld1.s	{ v29 }[3], [x14]
LBB0_72:                                ; %else150
	mov	x14, #0                         ; =0x0
	fmul.4s	v8, v28, v28
	fmul.4s	v29, v29, v29
	and.16b	v22, v20, v22
	and.16b	v24, v19, v30
	and.16b	v23, v20, v23
	and.16b	v25, v19, v31
	mov	w15, #224                       ; =0xe0
	fmov	w16, s0
	and.16b	v28, v20, v27
	and.16b	v27, v19, v26
	and.16b	v26, v20, v29
	and	x17, x13, #0x7
	add	x0, sp, #544
	and	x1, x13, #0x7
	add	x2, sp, #464
	and	x3, x13, #0x7
	and.16b	v29, v19, v8
	add	x4, sp, #384
	sshll.2d	v30, v20, #0
	and	x5, x13, #0x7
	add	x6, sp, #304
	sshll.2d	v31, v19, #0
	b	LBB0_74
LBB0_73:                                ; %else250
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmul.4s	v3, v9, v9
	fmul.4s	v4, v8, v8
	fadd.4s	v4, v24, v4
	fadd.4s	v3, v22, v3
	fmul.4s	v5, v11, v11
	fmul.4s	v21, v10, v10
	fadd.4s	v21, v25, v21
	fadd.4s	v5, v23, v5
	fmul.4s	v8, v13, v13
	fmul.4s	v9, v12, v12
	fadd.4s	v9, v27, v9
	fadd.4s	v8, v28, v8
	fmul.4s	v10, v14, v14
	fmul.4s	v11, v15, v15
	fadd.4s	v11, v26, v11
	fadd.4s	v10, v29, v10
	bit.16b	v22, v3, v20
	bit.16b	v24, v4, v19
	bit.16b	v23, v5, v20
	bit.16b	v25, v21, v19
	bit.16b	v28, v8, v20
	bit.16b	v27, v9, v19
	add	x15, x15, #128
	bit.16b	v29, v10, v19
	add	x14, x14, #4
	bit.16b	v26, v11, v20
	cmp	x14, #4092
	b.hs	LBB0_138
LBB0_74:                                ; %direct.true48
                                        ; =>This Inner Loop Header: Depth=1
	sub	x7, x15, #96
	dup.2d	v8, x7
	orr.16b	v9, v8, v18
	orr.16b	v10, v8, v7
	orr.16b	v11, v8, v16
	orr.16b	v8, v8, v17
	and.16b	v8, v31, v8
	and.16b	v11, v30, v11
	and.16b	v10, v2, v10
	and.16b	v9, v1, v9
	stp	q11, q9, [x11, #416]
	stp	q8, q10, [x11, #384]
	ldr	x7, [x0, x17, lsl #3]
	sub	x7, x7, x10
	add	x7, x9, x7
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w16, #0, LBB0_109
; %bb.75:                               ; %else154
                                        ;   in Loop: Header=BB0_74 Depth=1
	and	w19, w16, #0xff
	tbnz	w19, #1, LBB0_110
LBB0_76:                                ; %else157
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #2, LBB0_111
LBB0_77:                                ; %else160
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #3, LBB0_112
LBB0_78:                                ; %else163
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #4, LBB0_113
LBB0_79:                                ; %else166
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #5, LBB0_114
LBB0_80:                                ; %else169
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #6, LBB0_115
LBB0_81:                                ; %else172
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbz	w19, #7, LBB0_83
LBB0_82:                                ; %cond.load174
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x7, x7, #28
	ld1.s	{ v9 }[3], [x7]
LBB0_83:                                ; %else175
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	w19, s0
	sshll.2d	v10, v20, #0
	sshll.2d	v11, v19, #0
	sub	x7, x15, #64
	dup.2d	v12, x7
	orr.16b	v13, v12, v18
	orr.16b	v14, v12, v7
	orr.16b	v15, v12, v16
	orr.16b	v12, v12, v17
	and.16b	v11, v11, v12
	and.16b	v10, v10, v15
	and.16b	v12, v2, v14
	and.16b	v13, v1, v13
	stp	q10, q13, [x11, #336]
	stp	q11, q12, [x11, #304]
	ldr	x7, [x2, x1, lsl #3]
	sub	x7, x7, x10
	add	x7, x9, x7
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	tbnz	w19, #0, LBB0_116
; %bb.84:                               ; %else179
                                        ;   in Loop: Header=BB0_74 Depth=1
	and	w19, w19, #0xff
	tbnz	w19, #1, LBB0_117
LBB0_85:                                ; %else182
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #2, LBB0_118
LBB0_86:                                ; %else185
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #3, LBB0_119
LBB0_87:                                ; %else188
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #4, LBB0_120
LBB0_88:                                ; %else191
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #5, LBB0_121
LBB0_89:                                ; %else194
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #6, LBB0_122
LBB0_90:                                ; %else197
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbz	w19, #7, LBB0_92
LBB0_91:                                ; %cond.load199
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x7, x7, #28
	ld1.s	{ v11 }[3], [x7]
LBB0_92:                                ; %else200
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	w19, s0
	sshll.2d	v12, v20, #0
	sshll.2d	v13, v19, #0
	sub	x7, x15, #32
	dup.2d	v14, x7
	orr.16b	v15, v14, v18
	orr.16b	v21, v14, v7
	orr.16b	v3, v14, v16
	orr.16b	v14, v14, v17
	and.16b	v13, v13, v14
	and.16b	v3, v12, v3
	and.16b	v21, v2, v21
	and.16b	v12, v1, v15
	stp	q3, q12, [x11, #256]
	stp	q13, q21, [x11, #224]
	ldr	x7, [x4, x3, lsl #3]
	sub	x7, x7, x10
	add	x7, x9, x7
	movi.2d	v12, #0000000000000000
	movi.2d	v13, #0000000000000000
	tbnz	w19, #0, LBB0_123
; %bb.93:                               ; %else204
                                        ;   in Loop: Header=BB0_74 Depth=1
	and	w19, w19, #0xff
	tbnz	w19, #1, LBB0_124
LBB0_94:                                ; %else207
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #2, LBB0_125
LBB0_95:                                ; %else210
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #3, LBB0_126
LBB0_96:                                ; %else213
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #4, LBB0_127
LBB0_97:                                ; %else216
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #5, LBB0_128
LBB0_98:                                ; %else219
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #6, LBB0_129
LBB0_99:                                ; %else222
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbz	w19, #7, LBB0_101
LBB0_100:                               ; %cond.load224
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x7, x7, #28
	ld1.s	{ v13 }[3], [x7]
LBB0_101:                               ; %else225
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	w19, s0
	sshll.2d	v3, v20, #0
	sshll.2d	v21, v19, #0
	dup.2d	v14, x15
	orr.16b	v15, v14, v18
	orr.16b	v4, v14, v7
	orr.16b	v5, v14, v16
	orr.16b	v14, v14, v17
	and.16b	v21, v21, v14
	and.16b	v3, v3, v5
	and.16b	v4, v2, v4
	and.16b	v5, v1, v15
	stp	q3, q5, [x11, #176]
	stp	q21, q4, [x11, #144]
	ldr	x7, [x6, x5, lsl #3]
	sub	x7, x7, x10
	add	x7, x9, x7
	movi.2d	v14, #0000000000000000
	movi.2d	v15, #0000000000000000
	tbnz	w19, #0, LBB0_130
; %bb.102:                              ; %else229
                                        ;   in Loop: Header=BB0_74 Depth=1
	and	w19, w19, #0xff
	tbnz	w19, #1, LBB0_131
LBB0_103:                               ; %else232
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #2, LBB0_132
LBB0_104:                               ; %else235
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #3, LBB0_133
LBB0_105:                               ; %else238
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #4, LBB0_134
LBB0_106:                               ; %else241
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #5, LBB0_135
LBB0_107:                               ; %else244
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w19, #6, LBB0_136
LBB0_108:                               ; %else247
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbz	w19, #7, LBB0_73
	b	LBB0_137
LBB0_109:                               ; %cond.load153
                                        ;   in Loop: Header=BB0_74 Depth=1
	ldr	s8, [x7]
	and	w19, w16, #0xff
	tbz	w19, #1, LBB0_76
LBB0_110:                               ; %cond.load156
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #4
	ld1.s	{ v8 }[1], [x20]
	tbz	w19, #2, LBB0_77
LBB0_111:                               ; %cond.load159
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #8
	ld1.s	{ v8 }[2], [x20]
	tbz	w19, #3, LBB0_78
LBB0_112:                               ; %cond.load162
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #12
	ld1.s	{ v8 }[3], [x20]
	tbz	w19, #4, LBB0_79
LBB0_113:                               ; %cond.load165
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #16
	ld1.s	{ v9 }[0], [x20]
	tbz	w19, #5, LBB0_80
LBB0_114:                               ; %cond.load168
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #20
	ld1.s	{ v9 }[1], [x20]
	tbz	w19, #6, LBB0_81
LBB0_115:                               ; %cond.load171
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #24
	ld1.s	{ v9 }[2], [x20]
	tbnz	w19, #7, LBB0_82
	b	LBB0_83
LBB0_116:                               ; %cond.load178
                                        ;   in Loop: Header=BB0_74 Depth=1
	ldr	s10, [x7]
	and	w19, w19, #0xff
	tbz	w19, #1, LBB0_85
LBB0_117:                               ; %cond.load181
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #4
	ld1.s	{ v10 }[1], [x20]
	tbz	w19, #2, LBB0_86
LBB0_118:                               ; %cond.load184
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #8
	ld1.s	{ v10 }[2], [x20]
	tbz	w19, #3, LBB0_87
LBB0_119:                               ; %cond.load187
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #12
	ld1.s	{ v10 }[3], [x20]
	tbz	w19, #4, LBB0_88
LBB0_120:                               ; %cond.load190
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #16
	ld1.s	{ v11 }[0], [x20]
	tbz	w19, #5, LBB0_89
LBB0_121:                               ; %cond.load193
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #20
	ld1.s	{ v11 }[1], [x20]
	tbz	w19, #6, LBB0_90
LBB0_122:                               ; %cond.load196
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #24
	ld1.s	{ v11 }[2], [x20]
	tbnz	w19, #7, LBB0_91
	b	LBB0_92
LBB0_123:                               ; %cond.load203
                                        ;   in Loop: Header=BB0_74 Depth=1
	ldr	s12, [x7]
	and	w19, w19, #0xff
	tbz	w19, #1, LBB0_94
LBB0_124:                               ; %cond.load206
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #4
	ld1.s	{ v12 }[1], [x20]
	tbz	w19, #2, LBB0_95
LBB0_125:                               ; %cond.load209
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #8
	ld1.s	{ v12 }[2], [x20]
	tbz	w19, #3, LBB0_96
LBB0_126:                               ; %cond.load212
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #12
	ld1.s	{ v12 }[3], [x20]
	tbz	w19, #4, LBB0_97
LBB0_127:                               ; %cond.load215
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #16
	ld1.s	{ v13 }[0], [x20]
	tbz	w19, #5, LBB0_98
LBB0_128:                               ; %cond.load218
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #20
	ld1.s	{ v13 }[1], [x20]
	tbz	w19, #6, LBB0_99
LBB0_129:                               ; %cond.load221
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #24
	ld1.s	{ v13 }[2], [x20]
	tbnz	w19, #7, LBB0_100
	b	LBB0_101
LBB0_130:                               ; %cond.load228
                                        ;   in Loop: Header=BB0_74 Depth=1
	ldr	s14, [x7]
	and	w19, w19, #0xff
	tbz	w19, #1, LBB0_103
LBB0_131:                               ; %cond.load231
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #4
	ld1.s	{ v14 }[1], [x20]
	tbz	w19, #2, LBB0_104
LBB0_132:                               ; %cond.load234
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #8
	ld1.s	{ v14 }[2], [x20]
	tbz	w19, #3, LBB0_105
LBB0_133:                               ; %cond.load237
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #12
	ld1.s	{ v14 }[3], [x20]
	tbz	w19, #4, LBB0_106
LBB0_134:                               ; %cond.load240
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #16
	ld1.s	{ v15 }[0], [x20]
	tbz	w19, #5, LBB0_107
LBB0_135:                               ; %cond.load243
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #20
	ld1.s	{ v15 }[1], [x20]
	tbz	w19, #6, LBB0_108
LBB0_136:                               ; %cond.load246
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x20, x7, #24
	ld1.s	{ v15 }[2], [x20]
	tbz	w19, #7, LBB0_73
LBB0_137:                               ; %cond.load249
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x7, x7, #28
	ld1.s	{ v15 }[3], [x7]
	b	LBB0_73
LBB0_138:                               ; %direct.false49
	mov	x15, #0                         ; =0x0
	sshll.2d	v30, v20, #0
	sshll.2d	v31, v19, #0
	ldr	q21, [sp]                       ; 16-byte Folded Reload
	and.16b	v3, v31, v21
	and.16b	v4, v30, v21
	and.16b	v5, v2, v21
	and.16b	v21, v1, v21
	stp	q4, q21, [x11, #112]
	stp	q3, q5, [x11, #80]
	and	x14, x13, #0x7
	add	x16, sp, #240
	ldr	x14, [x16, x14, lsl #3]
	fmov	w16, s0
	and	x17, x13, #0x7
	add	x0, sp, #160
	ldp	q10, q9, [sp, #32]              ; 32-byte Folded Reload
	ldr	q11, [sp, #16]                  ; 16-byte Folded Reload
	b	LBB0_140
LBB0_139:                               ; %else268
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x15, x15, #32
	add	x12, x12, #4
	cmp	x15, #32, lsl #12               ; =131072
	b.eq	LBB0_156
LBB0_140:                               ; %direct.true95
                                        ; =>This Inner Loop Header: Depth=1
	ld1r.4s	{ v21 }, [x12]
	dup.2d	v3, x15
	orr.16b	v4, v3, v18
	orr.16b	v5, v3, v7
	orr.16b	v8, v3, v16
	orr.16b	v3, v3, v17
	and.16b	v3, v31, v3
	and.16b	v8, v30, v8
	and.16b	v5, v2, v5
	and.16b	v4, v1, v4
	str	q4, [x11, #48]
	stp	q5, q8, [sp, #176]
	str	q3, [sp, #160]
	ldr	x1, [x0, x17, lsl #3]
	sub	x1, x1, x10
	add	x1, x14, x1
	tbnz	w16, #0, LBB0_148
; %bb.141:                              ; %else254
                                        ;   in Loop: Header=BB0_140 Depth=1
	and	w2, w16, #0xff
	tbnz	w2, #1, LBB0_149
LBB0_142:                               ; %else256
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w2, #2, LBB0_150
LBB0_143:                               ; %else258
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w2, #3, LBB0_151
LBB0_144:                               ; %else260
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w2, #4, LBB0_152
LBB0_145:                               ; %else262
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w2, #5, LBB0_153
LBB0_146:                               ; %else264
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w2, #6, LBB0_154
LBB0_147:                               ; %else266
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbz	w2, #7, LBB0_139
	b	LBB0_155
LBB0_148:                               ; %cond.store253
                                        ;   in Loop: Header=BB0_140 Depth=1
	str	s21, [x1]
	and	w2, w16, #0xff
	tbz	w2, #1, LBB0_142
LBB0_149:                               ; %cond.store255
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x3, x1, #4
	st1.s	{ v21 }[1], [x3]
	tbz	w2, #2, LBB0_143
LBB0_150:                               ; %cond.store257
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x3, x1, #8
	st1.s	{ v21 }[2], [x3]
	tbz	w2, #3, LBB0_144
LBB0_151:                               ; %cond.store259
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x3, x1, #12
	st1.s	{ v21 }[3], [x3]
	tbz	w2, #4, LBB0_145
LBB0_152:                               ; %cond.store261
                                        ;   in Loop: Header=BB0_140 Depth=1
	str	s21, [x1, #16]
	tbz	w2, #5, LBB0_146
LBB0_153:                               ; %cond.store263
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x3, x1, #20
	st1.s	{ v21 }[1], [x3]
	tbz	w2, #6, LBB0_147
LBB0_154:                               ; %cond.store265
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x3, x1, #24
	st1.s	{ v21 }[2], [x3]
	tbz	w2, #7, LBB0_139
LBB0_155:                               ; %cond.store267
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x1, x1, #28
	st1.s	{ v21 }[3], [x1]
	b	LBB0_139
LBB0_156:                               ; %direct.false96
	mov	x11, #0                         ; =0x0
	fadd.4s	v3, v24, v25
	fadd.4s	v4, v22, v23
	fadd.4s	v4, v4, v28
	fadd.4s	v3, v3, v27
	fadd.4s	v3, v3, v29
	fadd.4s	v4, v4, v26
	mov	w12, #964689920                 ; =0x39800000
	dup.4s	v5, w12
	fmul.4s	v4, v4, v5
	mov	w12, #50604                     ; =0xc5ac
	movk	w12, #14119, lsl #16
	dup.4s	v21, w12
	fmul.4s	v3, v3, v5
	fadd.4s	v3, v3, v21
	fadd.4s	v4, v4, v21
	fsqrt.4s	v4, v4
	fsqrt.4s	v3, v3
	and.16b	v21, v19, v3
	and.16b	v22, v20, v4
	fmov	w12, s0
	sshll.2d	v20, v20, #0
	sshll.2d	v19, v19, #0
	and	x13, x13, #0x7
	add	x15, sp, #80
	b	LBB0_158
LBB0_157:                               ; %else343
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x11, x11, #1
	cmp	x11, #1, lsl #12                ; =4096
	b.eq	LBB0_206
LBB0_158:                               ; %direct.true109
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v24, x11
	shl.2d	v3, v24, #5
	orr.16b	v4, v3, v18
	orr.16b	v5, v3, v7
	orr.16b	v23, v3, v16
	orr.16b	v3, v3, v17
	and.16b	v3, v19, v3
	and.16b	v23, v20, v23
	and.16b	v5, v2, v5
	and.16b	v4, v1, v4
	stp	q23, q4, [sp, #112]
	stp	q3, q5, [sp, #80]
	ldr	x16, [x15, x13, lsl #3]
	sub	x16, x16, x10
	add	x17, x9, x16
	movi.2d	v25, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w12, #0, LBB0_183
; %bb.159:                              ; %else271
                                        ;   in Loop: Header=BB0_158 Depth=1
	and	w0, w12, #0xff
	tbnz	w0, #1, LBB0_184
LBB0_160:                               ; %else274
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w0, #2, LBB0_185
LBB0_161:                               ; %else277
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w0, #3, LBB0_186
LBB0_162:                               ; %else280
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w0, #4, LBB0_187
LBB0_163:                               ; %else283
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w0, #5, LBB0_188
LBB0_164:                               ; %else286
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w0, #6, LBB0_189
LBB0_165:                               ; %else289
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w0, #7, LBB0_190
LBB0_166:                               ; %else292
                                        ;   in Loop: Header=BB0_158 Depth=1
	fmov	w17, s0
	add	x16, x14, x16
	movi.2d	v27, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbnz	w17, #0, LBB0_191
LBB0_167:                               ; %else296
                                        ;   in Loop: Header=BB0_158 Depth=1
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB0_192
LBB0_168:                               ; %else299
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w17, #2, LBB0_193
LBB0_169:                               ; %else302
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w17, #3, LBB0_194
LBB0_170:                               ; %else305
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w17, #4, LBB0_195
LBB0_171:                               ; %else308
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w17, #5, LBB0_196
LBB0_172:                               ; %else311
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w17, #6, LBB0_197
LBB0_173:                               ; %else314
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbz	w17, #7, LBB0_175
LBB0_174:                               ; %cond.load316
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x16, x16, #28
	ld1.s	{ v26 }[3], [x16]
LBB0_175:                               ; %else317
                                        ;   in Loop: Header=BB0_158 Depth=1
	fdiv.4s	v3, v25, v21
	fmov	w16, s0
	fmul.4s	v27, v3, v27
	shl.2d	v24, v24, #2
	dup.2d	v25, x8
	add.2d	v3, v25, v6
	add.2d	v28, v3, v24
	tbnz	w16, #0, LBB0_198
; %bb.176:                              ; %else322
                                        ;   in Loop: Header=BB0_158 Depth=1
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_199
LBB0_177:                               ; %else325
                                        ;   in Loop: Header=BB0_158 Depth=1
	add.2d	v3, v25, v10
	add.2d	v28, v3, v24
	tbnz	w16, #2, LBB0_200
LBB0_178:                               ; %else328
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w16, #3, LBB0_201
LBB0_179:                               ; %else331
                                        ;   in Loop: Header=BB0_158 Depth=1
	fdiv.4s	v3, v23, v22
	fmul.4s	v23, v3, v26
	add.2d	v3, v25, v11
	add.2d	v26, v3, v24
	tbnz	w16, #4, LBB0_202
LBB0_180:                               ; %else334
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbnz	w16, #5, LBB0_203
LBB0_181:                               ; %else337
                                        ;   in Loop: Header=BB0_158 Depth=1
	add.2d	v3, v25, v9
	add.2d	v24, v3, v24
	tbnz	w16, #6, LBB0_204
LBB0_182:                               ; %else340
                                        ;   in Loop: Header=BB0_158 Depth=1
	tbz	w16, #7, LBB0_157
	b	LBB0_205
LBB0_183:                               ; %cond.load270
                                        ;   in Loop: Header=BB0_158 Depth=1
	ldr	s25, [x17]
	and	w0, w12, #0xff
	tbz	w0, #1, LBB0_160
LBB0_184:                               ; %cond.load273
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x1, x17, #4
	ld1.s	{ v25 }[1], [x1]
	tbz	w0, #2, LBB0_161
LBB0_185:                               ; %cond.load276
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x1, x17, #8
	ld1.s	{ v25 }[2], [x1]
	tbz	w0, #3, LBB0_162
LBB0_186:                               ; %cond.load279
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x1, x17, #12
	ld1.s	{ v25 }[3], [x1]
	tbz	w0, #4, LBB0_163
LBB0_187:                               ; %cond.load282
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x1, x17, #16
	ld1.s	{ v23 }[0], [x1]
	tbz	w0, #5, LBB0_164
LBB0_188:                               ; %cond.load285
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x1, x17, #20
	ld1.s	{ v23 }[1], [x1]
	tbz	w0, #6, LBB0_165
LBB0_189:                               ; %cond.load288
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x1, x17, #24
	ld1.s	{ v23 }[2], [x1]
	tbz	w0, #7, LBB0_166
LBB0_190:                               ; %cond.load291
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x17, x17, #28
	ld1.s	{ v23 }[3], [x17]
	fmov	w17, s0
	add	x16, x14, x16
	movi.2d	v27, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbz	w17, #0, LBB0_167
LBB0_191:                               ; %cond.load295
                                        ;   in Loop: Header=BB0_158 Depth=1
	ldr	s27, [x16]
	and	w17, w17, #0xff
	tbz	w17, #1, LBB0_168
LBB0_192:                               ; %cond.load298
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x0, x16, #4
	ld1.s	{ v27 }[1], [x0]
	tbz	w17, #2, LBB0_169
LBB0_193:                               ; %cond.load301
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x0, x16, #8
	ld1.s	{ v27 }[2], [x0]
	tbz	w17, #3, LBB0_170
LBB0_194:                               ; %cond.load304
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x0, x16, #12
	ld1.s	{ v27 }[3], [x0]
	tbz	w17, #4, LBB0_171
LBB0_195:                               ; %cond.load307
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x0, x16, #16
	ld1.s	{ v26 }[0], [x0]
	tbz	w17, #5, LBB0_172
LBB0_196:                               ; %cond.load310
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x0, x16, #20
	ld1.s	{ v26 }[1], [x0]
	tbz	w17, #6, LBB0_173
LBB0_197:                               ; %cond.load313
                                        ;   in Loop: Header=BB0_158 Depth=1
	add	x0, x16, #24
	ld1.s	{ v26 }[2], [x0]
	tbnz	w17, #7, LBB0_174
	b	LBB0_175
LBB0_198:                               ; %cond.store320
                                        ;   in Loop: Header=BB0_158 Depth=1
	fmov	x17, d28
	str	s27, [x17]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_177
LBB0_199:                               ; %cond.store323
                                        ;   in Loop: Header=BB0_158 Depth=1
	mov.d	x17, v28[1]
	st1.s	{ v27 }[1], [x17]
	add.2d	v3, v25, v10
	add.2d	v28, v3, v24
	tbz	w16, #2, LBB0_178
LBB0_200:                               ; %cond.store326
                                        ;   in Loop: Header=BB0_158 Depth=1
	fmov	x17, d28
	st1.s	{ v27 }[2], [x17]
	tbz	w16, #3, LBB0_179
LBB0_201:                               ; %cond.store329
                                        ;   in Loop: Header=BB0_158 Depth=1
	mov.d	x17, v28[1]
	st1.s	{ v27 }[3], [x17]
	fdiv.4s	v3, v23, v22
	fmul.4s	v23, v3, v26
	add.2d	v3, v25, v11
	add.2d	v26, v3, v24
	tbz	w16, #4, LBB0_180
LBB0_202:                               ; %cond.store332
                                        ;   in Loop: Header=BB0_158 Depth=1
	fmov	x17, d26
	str	s23, [x17]
	tbz	w16, #5, LBB0_181
LBB0_203:                               ; %cond.store335
                                        ;   in Loop: Header=BB0_158 Depth=1
	mov.d	x17, v26[1]
	st1.s	{ v23 }[1], [x17]
	add.2d	v3, v25, v9
	add.2d	v24, v3, v24
	tbz	w16, #6, LBB0_182
LBB0_204:                               ; %cond.store338
                                        ;   in Loop: Header=BB0_158 Depth=1
	fmov	x17, d24
	st1.s	{ v23 }[2], [x17]
	tbz	w16, #7, LBB0_157
LBB0_205:                               ; %cond.store341
                                        ;   in Loop: Header=BB0_158 Depth=1
	mov.d	x16, v24[1]
	st1.s	{ v23 }[3], [x16]
	b	LBB0_157
LBB0_206:                               ; %common.ret
	add	sp, sp, #1104
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #96             ; 16-byte Folded Reload
	ret
LBB0_207:                               ; %cond.load53
	ldr	s22, [x15]
	tbz	w14, #1, LBB0_37
LBB0_208:                               ; %cond.load56
	add	x16, x15, #4
	ld1.s	{ v22 }[1], [x16]
	tbz	w14, #2, LBB0_38
LBB0_209:                               ; %cond.load59
	add	x16, x15, #8
	ld1.s	{ v22 }[2], [x16]
	tbz	w14, #3, LBB0_39
LBB0_210:                               ; %cond.load62
	add	x16, x15, #12
	ld1.s	{ v22 }[3], [x16]
	tbz	w14, #4, LBB0_40
LBB0_211:                               ; %cond.load65
	add	x16, x15, #16
	ld1.s	{ v23 }[0], [x16]
	tbz	w14, #5, LBB0_41
LBB0_212:                               ; %cond.load68
	add	x16, x15, #20
	ld1.s	{ v23 }[1], [x16]
	tbz	w14, #6, LBB0_42
LBB0_213:                               ; %cond.load71
	add	x16, x15, #24
	ld1.s	{ v23 }[2], [x16]
	tbnz	w14, #7, LBB0_43
	b	LBB0_44
LBB0_214:                               ; %cond.load78
	ldr	s24, [x15]
	tbz	w14, #1, LBB0_46
LBB0_215:                               ; %cond.load81
	add	x16, x15, #4
	ld1.s	{ v24 }[1], [x16]
	tbz	w14, #2, LBB0_47
LBB0_216:                               ; %cond.load84
	add	x16, x15, #8
	ld1.s	{ v24 }[2], [x16]
	tbz	w14, #3, LBB0_48
LBB0_217:                               ; %cond.load87
	add	x16, x15, #12
	ld1.s	{ v24 }[3], [x16]
	tbz	w14, #4, LBB0_49
LBB0_218:                               ; %cond.load90
	add	x16, x15, #16
	ld1.s	{ v25 }[0], [x16]
	tbz	w14, #5, LBB0_50
LBB0_219:                               ; %cond.load93
	add	x16, x15, #20
	ld1.s	{ v25 }[1], [x16]
	tbz	w14, #6, LBB0_51
LBB0_220:                               ; %cond.load96
	add	x16, x15, #24
	ld1.s	{ v25 }[2], [x16]
	tbnz	w14, #7, LBB0_52
	b	LBB0_53
LBB0_221:                               ; %cond.load103
	ldr	s26, [x15]
	tbz	w14, #1, LBB0_55
LBB0_222:                               ; %cond.load106
	add	x16, x15, #4
	ld1.s	{ v26 }[1], [x16]
	tbz	w14, #2, LBB0_56
LBB0_223:                               ; %cond.load109
	add	x16, x15, #8
	ld1.s	{ v26 }[2], [x16]
	tbz	w14, #3, LBB0_57
LBB0_224:                               ; %cond.load112
	add	x16, x15, #12
	ld1.s	{ v26 }[3], [x16]
	tbz	w14, #4, LBB0_58
LBB0_225:                               ; %cond.load115
	add	x16, x15, #16
	ld1.s	{ v27 }[0], [x16]
	tbz	w14, #5, LBB0_59
LBB0_226:                               ; %cond.load118
	add	x16, x15, #20
	ld1.s	{ v27 }[1], [x16]
	tbz	w14, #6, LBB0_60
LBB0_227:                               ; %cond.load121
	add	x16, x15, #24
	ld1.s	{ v27 }[2], [x16]
	tbnz	w14, #7, LBB0_61
	b	LBB0_62
LBB0_228:                               ; %cond.load128
	ldr	s28, [x15]
	tbz	w14, #1, LBB0_64
LBB0_229:                               ; %cond.load131
	add	x16, x15, #4
	ld1.s	{ v28 }[1], [x16]
	tbz	w14, #2, LBB0_65
LBB0_230:                               ; %cond.load134
	add	x16, x15, #8
	ld1.s	{ v28 }[2], [x16]
	tbz	w14, #3, LBB0_66
LBB0_231:                               ; %cond.load137
	add	x16, x15, #12
	ld1.s	{ v28 }[3], [x16]
	tbz	w14, #4, LBB0_67
LBB0_232:                               ; %cond.load140
	add	x16, x15, #16
	ld1.s	{ v29 }[0], [x16]
	tbz	w14, #5, LBB0_68
LBB0_233:                               ; %cond.load143
	add	x16, x15, #20
	ld1.s	{ v29 }[1], [x16]
	tbnz	w14, #6, LBB0_69
	b	LBB0_70
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_13
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	mov	w22, #0                         ; =0x0
	ldp	w24, w8, [x2, #44]
	stp	w3, w8, [sp, #8]                ; 8-byte Folded Spill
	ldp	w25, w26, [x2]
	ldp	w28, w27, [x2, #8]
	str	w24, [sp, #4]                   ; 4-byte Folded Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #1016                       ; =0x3f8
	str	w8, [x20, #36]
	ldp	w24, w19, [sp, #4]              ; 8-byte Folded Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w24
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w26, eq
	ldr	w10, [sp, #12]                  ; 4-byte Folded Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w26, wzr, w9, ne
	add	w28, w28, w8
	add	w22, w22, #1
	cmp	w22, w19
	b.eq	LBB1_12
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_9 Depth 2
                                        ;     Child Loop BB1_6 Depth 2
	ubfiz	x8, x25, #10, #32
	cmp	x8, x27
	csel	x9, x8, xzr, ls
	subs	x10, x27, x9
	cmp	x10, #1024
	mov	w11, #1024                      ; =0x400
	csel	x10, x10, x11, lo
	cmp	x27, x9
	stp	w25, w26, [x20]
	str	w28, [x20, #8]
	ccmp	x8, x27, #2, hi
	csel	x23, x10, xzr, ls
	cmp	x23, #1024
	b.lo	LBB1_7
; %bb.5:                                ; %packet.batch.full.loop.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w23, #0                         ; =0x0
LBB1_6:                                 ; %packet.batch.full.loop.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	w23, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w23, w23, #8
	cmp	w23, #1024
	b.ne	LBB1_6
	b	LBB1_3
LBB1_7:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x8, x23, #3
	lsl	w24, w8, #3
	cmp	x23, #8
	b.lo	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w19, #0                         ; =0x0
LBB1_9:                                 ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	w19, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w19, w19, #8
	cmp	w24, w19
	b.ne	LBB1_9
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w23, #0x7
	cbz	w2, LBB1_2
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w24, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
	b	LBB1_2
LBB1_12:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_13:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

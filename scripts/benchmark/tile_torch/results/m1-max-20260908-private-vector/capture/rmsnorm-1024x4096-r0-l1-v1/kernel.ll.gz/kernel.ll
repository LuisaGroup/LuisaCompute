; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 131072
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.spill7 = alloca i64, align 8
  store i64 0, ptr %.spill7, align 4
  %.spill8 = alloca i64, align 8
  store i64 0, ptr %.spill8, align 4
  %.slot9 = alloca i64, align 8
  store i64 0, ptr %.slot9, align 4
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.slot13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot13, align 32
  %.spill14 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill14, align 32
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %.spill17 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill17, align 32
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %6 = getelementptr i8, ptr %argument_buffer, i64 0
  %7 = load ptr, ptr %6, align 16
  %8 = getelementptr i8, ptr %6, i64 8
  %9 = load i64, ptr %8, align 8
  %10 = insertvalue { ptr, i64 } poison, ptr %7, 0
  %11 = insertvalue { ptr, i64 } %10, i64 %9, 1
  %12 = getelementptr i8, ptr %argument_buffer, i64 16
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 32
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 48
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = load i32, ptr %launch_config, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 12
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 4
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 16
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 8
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 20
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 36
  %42 = load i32, ptr %41, align 4
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat20, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %44 = mul i32 %30, 1024
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat22, %43
  %46 = mul i32 %34, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat24, zeroinitializer
  %48 = mul i32 %38, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat26, zeroinitializer
  %50 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %45, 0
  %51 = insertvalue [3 x <8 x i32>] %50, <8 x i32> %47, 1
  %52 = insertvalue [3 x <8 x i32>] %51, <8 x i32> %49, 2
  %.splatinsert27 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat28
  %54 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  br i1 %54, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %55 = extractvalue [3 x <8 x i32>] %52, 0
  %56 = zext <8 x i32> %55 to <8 x i64>
  %57 = select <8 x i1> %53, <8 x i64> %56, <8 x i64> zeroinitializer
  %58 = select <8 x i1> %53, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %59 = sdiv <8 x i64> %57, %58
  %60 = load <8 x i64>, ptr %.spill, align 64
  %61 = select <8 x i1> %53, <8 x i64> %59, <8 x i64> %60
  store <8 x i64> %61, ptr %.spill, align 64
  %62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %63 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %62, 0
  %65 = select <8 x i1> %53, <8 x ptr> %63, <8 x ptr> %64
  %66 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %62, 1
  %68 = select <8 x i1> %53, <8 x i64> %66, <8 x i64> %67
  %69 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %65, 0
  %70 = insertvalue { <8 x ptr>, <8 x i64> } %69, <8 x i64> %68, 1
  store { <8 x ptr>, <8 x i64> } %70, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %71 = icmp slt i64 %.state, 4096
  br i1 %71, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %72 = add <8 x i64> %.spill.load, zeroinitializer
  %73 = add <8 x i64> zeroinitializer, %72
  %.state29 = load i64, ptr %.slot, align 4
  %74 = add i64 0, %.state29
  %75 = mul <8 x i64> %73, splat (i64 4096)
  %.splatinsert30 = insertelement <8 x i64> poison, i64 %74, i64 0
  %.splat31 = shufflevector <8 x i64> %.splatinsert30, <8 x i64> poison, <8 x i32> zeroinitializer
  %76 = add <8 x i64> %75, %.splat31
  %77 = extractvalue { ptr, i64 } %11, 0
  %78 = mul <8 x i64> %76, splat (i64 4)
  %79 = getelementptr i8, ptr %77, <8 x i64> %78
  %80 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %79, i32 1, <8 x i1> %53, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %81 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %82 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state32 = load i64, ptr %.slot, align 4
  %.splatinsert33 = insertelement <8 x i64> poison, i64 %.state32, i64 0
  %.splat34 = shufflevector <8 x i64> %.splatinsert33, <8 x i64> poison, <8 x i32> zeroinitializer
  %83 = mul <8 x i64> %.splat34, splat (i64 32)
  %84 = add <8 x i64> %82, %83
  %85 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %81, 0
  %86 = insertvalue { <8 x ptr>, <8 x i64> } %85, <8 x i64> %84, 1
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %86, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %86, 1
  %89 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %90 = bitcast <8 x i1> %53 to i8
  %91 = call i8 @llvm.cttz.i8(i8 %90, i1 false)
  %92 = zext i8 %91 to i32
  %93 = select i1 %89, i32 %92, i32 0
  %94 = select <8 x i1> %53, <8 x ptr> %87, <8 x ptr> zeroinitializer
  %95 = select <8 x i1> %53, <8 x i64> %88, <8 x i64> zeroinitializer
  %96 = extractelement <8 x ptr> %94, i32 %93
  %97 = extractelement <8 x i64> %95, i32 %93
  %98 = zext i32 %93 to i64
  %99 = mul i64 %98, 4
  %100 = sub i64 %97, %99
  %private.contiguous.address = getelementptr i8, ptr %96, i64 %100
  call void @llvm.masked.store.v8f32.p0(<8 x float> %80, ptr %private.contiguous.address, i32 4, <8 x i1> %53)
  %.state35 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state35, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  store i64 0, ptr %.spill7, align 4
  store i64 0, ptr %.spill8, align 4
  %tile_snapshot.spill.load36 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 0
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 1
  %104 = add <8 x i64> %103, zeroinitializer
  %105 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %102, 0
  %106 = insertvalue { <8 x ptr>, <8 x i64> } %105, <8 x i64> %104, 1
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %106, 0
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %106, 1
  %109 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %110 = bitcast <8 x i1> %53 to i8
  %111 = call i8 @llvm.cttz.i8(i8 %110, i1 false)
  %112 = zext i8 %111 to i32
  %113 = select i1 %109, i32 %112, i32 0
  %114 = select <8 x i1> %53, <8 x ptr> %107, <8 x ptr> zeroinitializer
  %115 = select <8 x i1> %53, <8 x i64> %108, <8 x i64> zeroinitializer
  %116 = extractelement <8 x ptr> %114, i32 %113
  %117 = extractelement <8 x i64> %115, i32 %113
  %118 = zext i32 %113 to i64
  %119 = mul i64 %118, 4
  %120 = sub i64 %117, %119
  %private.contiguous.address37 = getelementptr i8, ptr %116, i64 %120
  %private.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address37, i32 4, <8 x i1> %53, <8 x float> zeroinitializer)
  %121 = fmul <8 x float> %private.contiguous.load, %private.contiguous.load
  %tile_snapshot.spill.load38 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load38, 0
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load38, 1
  %124 = add <8 x i64> %123, splat (i64 32)
  %125 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %122, 0
  %126 = insertvalue { <8 x ptr>, <8 x i64> } %125, <8 x i64> %124, 1
  %127 = extractvalue { <8 x ptr>, <8 x i64> } %126, 0
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %126, 1
  %129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %130 = bitcast <8 x i1> %53 to i8
  %131 = call i8 @llvm.cttz.i8(i8 %130, i1 false)
  %132 = zext i8 %131 to i32
  %133 = select i1 %129, i32 %132, i32 0
  %134 = select <8 x i1> %53, <8 x ptr> %127, <8 x ptr> zeroinitializer
  %135 = select <8 x i1> %53, <8 x i64> %128, <8 x i64> zeroinitializer
  %136 = extractelement <8 x ptr> %134, i32 %133
  %137 = extractelement <8 x i64> %135, i32 %133
  %138 = zext i32 %133 to i64
  %139 = mul i64 %138, 4
  %140 = sub i64 %137, %139
  %private.contiguous.address39 = getelementptr i8, ptr %136, i64 %140
  %private.contiguous.load40 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address39, i32 4, <8 x i1> %53, <8 x float> zeroinitializer)
  %141 = fmul <8 x float> %private.contiguous.load40, %private.contiguous.load40
  %tile_snapshot.spill.load41 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load41, 0
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load41, 1
  %144 = add <8 x i64> %143, splat (i64 64)
  %145 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %142, 0
  %146 = insertvalue { <8 x ptr>, <8 x i64> } %145, <8 x i64> %144, 1
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %146, 0
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %146, 1
  %149 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %150 = bitcast <8 x i1> %53 to i8
  %151 = call i8 @llvm.cttz.i8(i8 %150, i1 false)
  %152 = zext i8 %151 to i32
  %153 = select i1 %149, i32 %152, i32 0
  %154 = select <8 x i1> %53, <8 x ptr> %147, <8 x ptr> zeroinitializer
  %155 = select <8 x i1> %53, <8 x i64> %148, <8 x i64> zeroinitializer
  %156 = extractelement <8 x ptr> %154, i32 %153
  %157 = extractelement <8 x i64> %155, i32 %153
  %158 = zext i32 %153 to i64
  %159 = mul i64 %158, 4
  %160 = sub i64 %157, %159
  %private.contiguous.address42 = getelementptr i8, ptr %156, i64 %160
  %private.contiguous.load43 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address42, i32 4, <8 x i1> %53, <8 x float> zeroinitializer)
  %161 = fmul <8 x float> %private.contiguous.load43, %private.contiguous.load43
  %tile_snapshot.spill.load44 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 0
  %163 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 1
  %164 = add <8 x i64> %163, splat (i64 96)
  %165 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %162, 0
  %166 = insertvalue { <8 x ptr>, <8 x i64> } %165, <8 x i64> %164, 1
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %166, 0
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %166, 1
  %169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %170 = bitcast <8 x i1> %53 to i8
  %171 = call i8 @llvm.cttz.i8(i8 %170, i1 false)
  %172 = zext i8 %171 to i32
  %173 = select i1 %169, i32 %172, i32 0
  %174 = select <8 x i1> %53, <8 x ptr> %167, <8 x ptr> zeroinitializer
  %175 = select <8 x i1> %53, <8 x i64> %168, <8 x i64> zeroinitializer
  %176 = extractelement <8 x ptr> %174, i32 %173
  %177 = extractelement <8 x i64> %175, i32 %173
  %178 = zext i32 %173 to i64
  %179 = mul i64 %178, 4
  %180 = sub i64 %177, %179
  %private.contiguous.address45 = getelementptr i8, ptr %176, i64 %180
  %private.contiguous.load46 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address45, i32 4, <8 x i1> %53, <8 x float> zeroinitializer)
  %181 = fmul <8 x float> %private.contiguous.load46, %private.contiguous.load46
  store i64 4, ptr %.slot9, align 4
  %182 = load <8 x float>, ptr %.slot10, align 32
  %183 = select <8 x i1> %53, <8 x float> %121, <8 x float> %182
  store <8 x float> %183, ptr %.slot10, align 32
  %184 = load <8 x float>, ptr %.slot11, align 32
  %185 = select <8 x i1> %53, <8 x float> %141, <8 x float> %184
  store <8 x float> %185, ptr %.slot11, align 32
  %186 = load <8 x float>, ptr %.slot12, align 32
  %187 = select <8 x i1> %53, <8 x float> %161, <8 x float> %186
  store <8 x float> %187, ptr %.slot12, align 32
  %188 = load <8 x float>, ptr %.slot13, align 32
  %189 = select <8 x i1> %53, <8 x float> %181, <8 x float> %188
  store <8 x float> %189, ptr %.slot13, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state47 = load i64, ptr %.slot9, align 4
  %190 = icmp slt i64 %.state47, 4096
  br i1 %190, label %direct.true48, label %direct.false49

direct.schedule.5:                                ; preds = %direct.true48
  %.state50 = load i64, ptr %.slot9, align 4
  %191 = add i64 %.state50, 0
  %192 = sdiv i64 %191, 1
  %.spill.load51 = load i64, ptr %.spill7, align 4
  %193 = add i64 %.spill.load51, %192
  %.spill.load52 = load i64, ptr %.spill8, align 4
  %194 = add i64 %.spill.load52, %193
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %194, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %197 = mul <8 x i64> %.splat55, splat (i64 32)
  %198 = add <8 x i64> %196, %197
  %199 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %195, 0
  %200 = insertvalue { <8 x ptr>, <8 x i64> } %199, <8 x i64> %198, 1
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %200, 0
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %200, 1
  %203 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %204 = bitcast <8 x i1> %53 to i8
  %205 = call i8 @llvm.cttz.i8(i8 %204, i1 false)
  %206 = zext i8 %205 to i32
  %207 = select i1 %203, i32 %206, i32 0
  %208 = select <8 x i1> %53, <8 x ptr> %201, <8 x ptr> zeroinitializer
  %209 = select <8 x i1> %53, <8 x i64> %202, <8 x i64> zeroinitializer
  %210 = extractelement <8 x ptr> %208, i32 %207
  %211 = extractelement <8 x i64> %209, i32 %207
  %212 = zext i32 %207 to i64
  %213 = mul i64 %212, 4
  %214 = sub i64 %211, %213
  %private.contiguous.address56 = getelementptr i8, ptr %210, i64 %214
  %private.contiguous.load57 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address56, i32 4, <8 x i1> %53, <8 x float> zeroinitializer)
  %215 = fmul <8 x float> %private.contiguous.load57, %private.contiguous.load57
  %.state58 = load <8 x float>, ptr %.slot10, align 32
  %216 = fadd <8 x float> %.state58, %215
  %.state59 = load i64, ptr %.slot9, align 4
  %217 = add i64 %.state59, 1
  %218 = sdiv i64 %217, 1
  %.spill.load60 = load i64, ptr %.spill7, align 4
  %219 = add i64 %.spill.load60, %218
  %.spill.load61 = load i64, ptr %.spill8, align 4
  %220 = add i64 %.spill.load61, %219
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %.splatinsert63 = insertelement <8 x i64> poison, i64 %220, i64 0
  %.splat64 = shufflevector <8 x i64> %.splatinsert63, <8 x i64> poison, <8 x i32> zeroinitializer
  %223 = mul <8 x i64> %.splat64, splat (i64 32)
  %224 = add <8 x i64> %222, %223
  %225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %221, 0
  %226 = insertvalue { <8 x ptr>, <8 x i64> } %225, <8 x i64> %224, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %226, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %226, 1
  %229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %230 = bitcast <8 x i1> %53 to i8
  %231 = call i8 @llvm.cttz.i8(i8 %230, i1 false)
  %232 = zext i8 %231 to i32
  %233 = select i1 %229, i32 %232, i32 0
  %234 = select <8 x i1> %53, <8 x ptr> %227, <8 x ptr> zeroinitializer
  %235 = select <8 x i1> %53, <8 x i64> %228, <8 x i64> zeroinitializer
  %236 = extractelement <8 x ptr> %234, i32 %233
  %237 = extractelement <8 x i64> %235, i32 %233
  %238 = zext i32 %233 to i64
  %239 = mul i64 %238, 4
  %240 = sub i64 %237, %239
  %private.contiguous.address65 = getelementptr i8, ptr %236, i64 %240
  %private.contiguous.load66 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address65, i32 4, <8 x i1> %53, <8 x float> zeroinitializer)
  %241 = fmul <8 x float> %private.contiguous.load66, %private.contiguous.load66
  %.state67 = load <8 x float>, ptr %.slot11, align 32
  %242 = fadd <8 x float> %.state67, %241
  %.state68 = load i64, ptr %.slot9, align 4
  %243 = add i64 %.state68, 2
  %244 = sdiv i64 %243, 1
  %.spill.load69 = load i64, ptr %.spill7, align 4
  %245 = add i64 %.spill.load69, %244
  %.spill.load70 = load i64, ptr %.spill8, align 4
  %246 = add i64 %.spill.load70, %245
  %tile_snapshot.spill.load71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 0
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 1
  %.splatinsert72 = insertelement <8 x i64> poison, i64 %246, i64 0
  %.splat73 = shufflevector <8 x i64> %.splatinsert72, <8 x i64> poison, <8 x i32> zeroinitializer
  %249 = mul <8 x i64> %.splat73, splat (i64 32)
  %250 = add <8 x i64> %248, %249
  %251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %247, 0
  %252 = insertvalue { <8 x ptr>, <8 x i64> } %251, <8 x i64> %250, 1
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %252, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %252, 1
  %255 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %256 = bitcast <8 x i1> %53 to i8
  %257 = call i8 @llvm.cttz.i8(i8 %256, i1 false)
  %258 = zext i8 %257 to i32
  %259 = select i1 %255, i32 %258, i32 0
  %260 = select <8 x i1> %53, <8 x ptr> %253, <8 x ptr> zeroinitializer
  %261 = select <8 x i1> %53, <8 x i64> %254, <8 x i64> zeroinitializer
  %262 = extractelement <8 x ptr> %260, i32 %259
  %263 = extractelement <8 x i64> %261, i32 %259
  %264 = zext i32 %259 to i64
  %265 = mul i64 %264, 4
  %266 = sub i64 %263, %265
  %private.contiguous.address74 = getelementptr i8, ptr %262, i64 %266
  %private.contiguous.load75 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address74, i32 4, <8 x i1> %53, <8 x float> zeroinitializer)
  %267 = fmul <8 x float> %private.contiguous.load75, %private.contiguous.load75
  %.state76 = load <8 x float>, ptr %.slot12, align 32
  %268 = fadd <8 x float> %.state76, %267
  %.state77 = load i64, ptr %.slot9, align 4
  %269 = add i64 %.state77, 3
  %270 = sdiv i64 %269, 1
  %.spill.load78 = load i64, ptr %.spill7, align 4
  %271 = add i64 %.spill.load78, %270
  %.spill.load79 = load i64, ptr %.spill8, align 4
  %272 = add i64 %.spill.load79, %271
  %tile_snapshot.spill.load80 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 1
  %.splatinsert81 = insertelement <8 x i64> poison, i64 %272, i64 0
  %.splat82 = shufflevector <8 x i64> %.splatinsert81, <8 x i64> poison, <8 x i32> zeroinitializer
  %275 = mul <8 x i64> %.splat82, splat (i64 32)
  %276 = add <8 x i64> %274, %275
  %277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %273, 0
  %278 = insertvalue { <8 x ptr>, <8 x i64> } %277, <8 x i64> %276, 1
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %278, 0
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %278, 1
  %281 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %282 = bitcast <8 x i1> %53 to i8
  %283 = call i8 @llvm.cttz.i8(i8 %282, i1 false)
  %284 = zext i8 %283 to i32
  %285 = select i1 %281, i32 %284, i32 0
  %286 = select <8 x i1> %53, <8 x ptr> %279, <8 x ptr> zeroinitializer
  %287 = select <8 x i1> %53, <8 x i64> %280, <8 x i64> zeroinitializer
  %288 = extractelement <8 x ptr> %286, i32 %285
  %289 = extractelement <8 x i64> %287, i32 %285
  %290 = zext i32 %285 to i64
  %291 = mul i64 %290, 4
  %292 = sub i64 %289, %291
  %private.contiguous.address83 = getelementptr i8, ptr %288, i64 %292
  %private.contiguous.load84 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address83, i32 4, <8 x i1> %53, <8 x float> zeroinitializer)
  %293 = fmul <8 x float> %private.contiguous.load84, %private.contiguous.load84
  %.state85 = load <8 x float>, ptr %.slot13, align 32
  %294 = fadd <8 x float> %.state85, %293
  %.state86 = load i64, ptr %.slot9, align 4
  %295 = add i64 %.state86, 4
  store i64 %295, ptr %.slot9, align 4
  %296 = load <8 x float>, ptr %.slot10, align 32
  %297 = select <8 x i1> %53, <8 x float> %216, <8 x float> %296
  store <8 x float> %297, ptr %.slot10, align 32
  %298 = load <8 x float>, ptr %.slot11, align 32
  %299 = select <8 x i1> %53, <8 x float> %242, <8 x float> %298
  store <8 x float> %299, ptr %.slot11, align 32
  %300 = load <8 x float>, ptr %.slot12, align 32
  %301 = select <8 x i1> %53, <8 x float> %268, <8 x float> %300
  store <8 x float> %301, ptr %.slot12, align 32
  %302 = load <8 x float>, ptr %.slot13, align 32
  %303 = select <8 x i1> %53, <8 x float> %294, <8 x float> %302
  store <8 x float> %303, ptr %.slot13, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false49
  %.spill.load87 = load float, ptr %.spill5, align 4
  %.splatinsert88 = insertelement <8 x float> poison, float %.spill.load87, i64 0
  %.splat89 = shufflevector <8 x float> %.splatinsert88, <8 x float> poison, <8 x i32> zeroinitializer
  %.state90 = load <8 x float>, ptr %.slot10, align 32
  %304 = fadd <8 x float> %.splat89, %.state90
  %.state91 = load <8 x float>, ptr %.slot11, align 32
  %305 = fadd <8 x float> %304, %.state91
  %.state92 = load <8 x float>, ptr %.slot12, align 32
  %306 = fadd <8 x float> %305, %.state92
  %.state93 = load <8 x float>, ptr %.slot13, align 32
  %307 = fadd <8 x float> %306, %.state93
  %308 = fdiv <8 x float> %307, splat (float 4.096000e+03)
  %309 = load <8 x float>, ptr %.spill14, align 32
  %310 = select <8 x i1> %53, <8 x float> %308, <8 x float> %309
  store <8 x float> %310, ptr %.spill14, align 32
  %311 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %312 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %311, 0
  %314 = select <8 x i1> %53, <8 x ptr> %312, <8 x ptr> %313
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %316 = extractvalue { <8 x ptr>, <8 x i64> } %311, 1
  %317 = select <8 x i1> %53, <8 x i64> %315, <8 x i64> %316
  %318 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %314, 0
  %319 = insertvalue { <8 x ptr>, <8 x i64> } %318, <8 x i64> %317, 1
  store { <8 x ptr>, <8 x i64> } %319, ptr %tile_snapshot.spill15, align 64
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state94 = load i64, ptr %.slot16, align 4
  %320 = icmp slt i64 %.state94, 4096
  br i1 %320, label %direct.true95, label %direct.false96

direct.schedule.8:                                ; preds = %direct.true95
  %.spill.load97 = load i64, ptr %.spill6, align 4
  %321 = add i64 %.spill.load97, 0
  %.state98 = load i64, ptr %.slot16, align 4
  %322 = add i64 0, %.state98
  %323 = mul i64 %321, 4096
  %324 = add i64 %323, %322
  %325 = extractvalue { ptr, i64 } %17, 0
  %326 = mul i64 %324, 4
  %327 = getelementptr i8, ptr %325, i64 %326
  %328 = load float, ptr %327, align 4
  %.splatinsert99 = insertelement <8 x float> poison, float %328, i64 0
  %.splat100 = shufflevector <8 x float> %.splatinsert99, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load101 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 1
  %.state102 = load i64, ptr %.slot16, align 4
  %.splatinsert103 = insertelement <8 x i64> poison, i64 %.state102, i64 0
  %.splat104 = shufflevector <8 x i64> %.splatinsert103, <8 x i64> poison, <8 x i32> zeroinitializer
  %331 = mul <8 x i64> %.splat104, splat (i64 32)
  %332 = add <8 x i64> %330, %331
  %333 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %329, 0
  %334 = insertvalue { <8 x ptr>, <8 x i64> } %333, <8 x i64> %332, 1
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %334, 0
  %336 = extractvalue { <8 x ptr>, <8 x i64> } %334, 1
  %337 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %338 = bitcast <8 x i1> %53 to i8
  %339 = call i8 @llvm.cttz.i8(i8 %338, i1 false)
  %340 = zext i8 %339 to i32
  %341 = select i1 %337, i32 %340, i32 0
  %342 = select <8 x i1> %53, <8 x ptr> %335, <8 x ptr> zeroinitializer
  %343 = select <8 x i1> %53, <8 x i64> %336, <8 x i64> zeroinitializer
  %344 = extractelement <8 x ptr> %342, i32 %341
  %345 = extractelement <8 x i64> %343, i32 %341
  %346 = zext i32 %341 to i64
  %347 = mul i64 %346, 4
  %348 = sub i64 %345, %347
  %private.contiguous.address105 = getelementptr i8, ptr %344, i64 %348
  call void @llvm.masked.store.v8f32.p0(<8 x float> %.splat100, ptr %private.contiguous.address105, i32 4, <8 x i1> %53)
  %.state106 = load i64, ptr %.slot16, align 4
  %349 = add i64 %.state106, 1
  store i64 %349, ptr %.slot16, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false96
  %.spill.load107 = load <8 x float>, ptr %.spill14, align 32
  %350 = fadd <8 x float> %.spill.load107, splat (float 0x3EE4F8B580000000)
  %351 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %350)
  %352 = load <8 x float>, ptr %.spill17, align 32
  %353 = select <8 x i1> %53, <8 x float> %351, <8 x float> %352
  store <8 x float> %353, ptr %.spill17, align 32
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state108 = load i64, ptr %.slot18, align 4
  %354 = icmp slt i64 %.state108, 4096
  br i1 %354, label %direct.true109, label %direct.false110

direct.schedule.11:                               ; preds = %direct.true109
  %.spill.load111 = load <8 x i64>, ptr %.spill, align 64
  %355 = add <8 x i64> %.spill.load111, zeroinitializer
  %356 = add <8 x i64> zeroinitializer, %355
  %.state112 = load i64, ptr %.slot18, align 4
  %357 = add i64 0, %.state112
  %358 = mul <8 x i64> %356, splat (i64 4096)
  %.splatinsert113 = insertelement <8 x i64> poison, i64 %357, i64 0
  %.splat114 = shufflevector <8 x i64> %.splatinsert113, <8 x i64> poison, <8 x i32> zeroinitializer
  %359 = add <8 x i64> %358, %.splat114
  %.spill.load115 = load i64, ptr %.spill8, align 4
  %.state116 = load i64, ptr %.slot18, align 4
  %360 = add i64 %.spill.load115, %.state116
  %.spill.load117 = load i64, ptr %.spill8, align 4
  %361 = add i64 %.spill.load117, %360
  %tile_snapshot.spill.load118 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %362 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 0
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 1
  %.splatinsert119 = insertelement <8 x i64> poison, i64 %361, i64 0
  %.splat120 = shufflevector <8 x i64> %.splatinsert119, <8 x i64> poison, <8 x i32> zeroinitializer
  %364 = mul <8 x i64> %.splat120, splat (i64 32)
  %365 = add <8 x i64> %363, %364
  %366 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %362, 0
  %367 = insertvalue { <8 x ptr>, <8 x i64> } %366, <8 x i64> %365, 1
  %368 = extractvalue { <8 x ptr>, <8 x i64> } %367, 0
  %369 = extractvalue { <8 x ptr>, <8 x i64> } %367, 1
  %370 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %371 = bitcast <8 x i1> %53 to i8
  %372 = call i8 @llvm.cttz.i8(i8 %371, i1 false)
  %373 = zext i8 %372 to i32
  %374 = select i1 %370, i32 %373, i32 0
  %375 = select <8 x i1> %53, <8 x ptr> %368, <8 x ptr> zeroinitializer
  %376 = select <8 x i1> %53, <8 x i64> %369, <8 x i64> zeroinitializer
  %377 = extractelement <8 x ptr> %375, i32 %374
  %378 = extractelement <8 x i64> %376, i32 %374
  %379 = zext i32 %374 to i64
  %380 = mul i64 %379, 4
  %381 = sub i64 %378, %380
  %private.contiguous.address121 = getelementptr i8, ptr %377, i64 %381
  %private.contiguous.load122 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address121, i32 4, <8 x i1> %53, <8 x float> zeroinitializer)
  %.spill.load123 = load <8 x float>, ptr %.spill17, align 32
  %382 = fdiv <8 x float> %private.contiguous.load122, %.spill.load123
  %tile_snapshot.spill.load124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %383 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 0
  %384 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 1
  %.splatinsert125 = insertelement <8 x i64> poison, i64 %360, i64 0
  %.splat126 = shufflevector <8 x i64> %.splatinsert125, <8 x i64> poison, <8 x i32> zeroinitializer
  %385 = mul <8 x i64> %.splat126, splat (i64 32)
  %386 = add <8 x i64> %384, %385
  %387 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %383, 0
  %388 = insertvalue { <8 x ptr>, <8 x i64> } %387, <8 x i64> %386, 1
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %388, 0
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %388, 1
  %391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %53)
  %392 = bitcast <8 x i1> %53 to i8
  %393 = call i8 @llvm.cttz.i8(i8 %392, i1 false)
  %394 = zext i8 %393 to i32
  %395 = select i1 %391, i32 %394, i32 0
  %396 = select <8 x i1> %53, <8 x ptr> %389, <8 x ptr> zeroinitializer
  %397 = select <8 x i1> %53, <8 x i64> %390, <8 x i64> zeroinitializer
  %398 = extractelement <8 x ptr> %396, i32 %395
  %399 = extractelement <8 x i64> %397, i32 %395
  %400 = zext i32 %395 to i64
  %401 = mul i64 %400, 4
  %402 = sub i64 %399, %401
  %private.contiguous.address127 = getelementptr i8, ptr %398, i64 %402
  %private.contiguous.load128 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address127, i32 4, <8 x i1> %53, <8 x float> zeroinitializer)
  %403 = fmul <8 x float> %382, %private.contiguous.load128
  %404 = extractvalue { ptr, i64 } %29, 0
  %405 = mul <8 x i64> %359, splat (i64 4)
  %406 = getelementptr i8, ptr %404, <8 x i64> %405
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %403, <8 x ptr> %406, i32 1, <8 x i1> %53)
  %.state129 = load i64, ptr %.slot18, align 4
  %407 = add i64 %.state129, 1
  store i64 %407, ptr %.slot18, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false110
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true48:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false49:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true95:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false96:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true109:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false110:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.sqrt.v8f32(<8 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #4

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 1024
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 1024
  %3 = sub i64 1024, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 128
  %8 = icmp uge i64 %packet.range.remaining, 1024
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  br label %packet.batch.full.loop

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full.loop
  ret void

packet.batch.full.loop:                           ; preds = %packet.batch.full.loop, %packet.batch.full
  %packet.index = phi i32 [ 0, %packet.batch.full ], [ %packet.index.next, %packet.batch.full.loop ]
  %packet.thread.offset = mul i32 %packet.index, 8
  %packet.thread.index = add i32 %base.thread.index, %packet.thread.offset
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.index.next = add i32 %packet.index, 1
  %packet.batch.has.more = icmp ult i32 %packet.index.next, %packet_count
  br i1 %packet.batch.has.more, label %packet.batch.full.loop, label %packet.batch.exit

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 128)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(write) }

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_4:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_5:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_7:
	.quad	32                              ; 0x20
	.quad	36                              ; 0x24
lCPI0_8:
	.quad	48                              ; 0x30
	.quad	52                              ; 0x34
lCPI0_9:
	.quad	40                              ; 0x28
	.quad	44                              ; 0x2c
lCPI0_10:
	.quad	56                              ; 0x38
	.quad	60                              ; 0x3c
lCPI0_11:
	.quad	64                              ; 0x40
	.quad	68                              ; 0x44
lCPI0_12:
	.quad	80                              ; 0x50
	.quad	84                              ; 0x54
lCPI0_13:
	.quad	72                              ; 0x48
	.quad	76                              ; 0x4c
lCPI0_14:
	.quad	88                              ; 0x58
	.quad	92                              ; 0x5c
lCPI0_15:
	.quad	96                              ; 0x60
	.quad	100                             ; 0x64
lCPI0_16:
	.quad	112                             ; 0x70
	.quad	116                             ; 0x74
lCPI0_17:
	.quad	104                             ; 0x68
	.quad	108                             ; 0x6c
lCPI0_18:
	.quad	120                             ; 0x78
	.quad	124                             ; 0x7c
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-96]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #1440
	dup.4s	v0, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q1, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q2, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v16, v0, v2
	cmhi.4s	v7, v0, v1
	uzp1.8h	v3, v7, v16
	umaxv.8h	h0, v3
	fmov	w8, s0
	tbz	w8, #0, LBB0_222
; %bb.1:                                ; %direct.activate
	stp	q2, q1, [sp, #16]               ; 32-byte Folded Spill
	mov	x15, #0                         ; =0x0
	add	x13, sp, #176
	add	x8, sp, #1440
	dup.2d	v20, x8
	ldr	x14, [x0, #16]
	ldr	x10, [x0, #48]
Lloh4:
	adrp	x8, lCPI0_0@PAGE
Lloh5:
	ldr	q0, [x8, lCPI0_0@PAGEOFF]
	str	q3, [sp]                        ; 16-byte Folded Spill
	and.16b	v0, v3, v0
	addv.8h	h0, v0
	fmov	w8, s0
	and	w8, w8, #0xff
	sshll2.2d	v1, v16, #0
	sshll2.2d	v2, v7, #0
	sshll.2d	v3, v16, #0
	sshll.2d	v4, v7, #0
	ldr	x9, [x0]
	ldr	w11, [x1]
	ldr	w12, [x1, #36]
	add	w11, w12, w11, lsl #10
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1440
	dup.2d	v5, x12
	lsr	w11, w11, #3
	fmov	s6, w11
	and.16b	v6, v7, v6
	fmov	w11, s6
	ubfiz	x12, x11, #14, #32
	add	x16, x9, x12
	rbit	w8, w8
	clz	w11, w8
	and.16b	v4, v4, v5
	and.16b	v3, v3, v5
	and.16b	v6, v2, v5
	and.16b	v5, v1, v5
	str	q5, [x13, #1232]
	str	q6, [x13, #1200]
	str	q3, [x13, #1216]
	str	q4, [x13, #1184]
	and	x8, x11, #0x7
	add	x9, sp, #1360
	ldr	x8, [x9, x8, lsl #3]
	lsl	w9, w11, #2
	fmov	w17, s0
Lloh6:
	adrp	x0, lCPI0_3@PAGE
Lloh7:
	ldr	q3, [x0, lCPI0_3@PAGEOFF]
Lloh8:
	adrp	x0, lCPI0_4@PAGE
Lloh9:
	ldr	q4, [x0, lCPI0_4@PAGEOFF]
Lloh10:
	adrp	x0, lCPI0_5@PAGE
Lloh11:
	ldr	q5, [x0, lCPI0_5@PAGEOFF]
Lloh12:
	adrp	x0, lCPI0_6@PAGE
Lloh13:
	ldr	q6, [x0, lCPI0_6@PAGEOFF]
	and	x0, x11, #0x7
	add	x1, sp, #1280
	b	LBB0_3
LBB0_2:                                 ; %else56
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x15, x15, #32
	cmp	x15, #4, lsl #12                ; =16384
	b.eq	LBB0_35
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x2, x16, x15
	movi.2d	v22, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w17, #0, LBB0_20
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w3, w17, #0xff
	tbnz	w3, #1, LBB0_21
LBB0_5:                                 ; %else21
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w3, #2, LBB0_22
LBB0_6:                                 ; %else24
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w3, #3, LBB0_23
LBB0_7:                                 ; %else27
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w3, #4, LBB0_24
LBB0_8:                                 ; %else30
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w3, #5, LBB0_25
LBB0_9:                                 ; %else33
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w3, #6, LBB0_26
LBB0_10:                                ; %else36
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w3, #7, LBB0_12
LBB0_11:                                ; %cond.load38
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x2, #28
	ld1.s	{ v21 }[3], [x2]
LBB0_12:                                ; %else39
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	w3, s0
	sshll.2d	v23, v16, #0
	sshll.2d	v24, v7, #0
	dup.2d	v25, x15
	orr.16b	v26, v25, v3
	orr.16b	v27, v25, v4
	orr.16b	v28, v25, v5
	orr.16b	v25, v25, v6
	and.16b	v24, v24, v25
	and.16b	v23, v23, v28
	and.16b	v25, v2, v27
	and.16b	v26, v1, v26
	str	q26, [x13, #1152]
	str	q25, [x13, #1120]
	str	q23, [x13, #1136]
	str	q24, [x13, #1104]
	ldr	x2, [x1, x0, lsl #3]
	sub	x2, x2, x9
	add	x2, x8, x2
	tbnz	w3, #0, LBB0_27
; %bb.13:                               ; %else42
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w3, w3, #0xff
	tbnz	w3, #1, LBB0_28
LBB0_14:                                ; %else44
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w3, #2, LBB0_29
LBB0_15:                                ; %else46
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w3, #3, LBB0_30
LBB0_16:                                ; %else48
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w3, #4, LBB0_31
LBB0_17:                                ; %else50
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w3, #5, LBB0_32
LBB0_18:                                ; %else52
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w3, #6, LBB0_33
LBB0_19:                                ; %else54
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w3, #7, LBB0_2
	b	LBB0_34
LBB0_20:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	s22, [x2]
	and	w3, w17, #0xff
	tbz	w3, #1, LBB0_5
LBB0_21:                                ; %cond.load20
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x4, x2, #4
	ld1.s	{ v22 }[1], [x4]
	tbz	w3, #2, LBB0_6
LBB0_22:                                ; %cond.load23
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x4, x2, #8
	ld1.s	{ v22 }[2], [x4]
	tbz	w3, #3, LBB0_7
LBB0_23:                                ; %cond.load26
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x4, x2, #12
	ld1.s	{ v22 }[3], [x4]
	tbz	w3, #4, LBB0_8
LBB0_24:                                ; %cond.load29
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x4, x2, #16
	ld1.s	{ v21 }[0], [x4]
	tbz	w3, #5, LBB0_9
LBB0_25:                                ; %cond.load32
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x4, x2, #20
	ld1.s	{ v21 }[1], [x4]
	tbz	w3, #6, LBB0_10
LBB0_26:                                ; %cond.load35
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x4, x2, #24
	ld1.s	{ v21 }[2], [x4]
	tbnz	w3, #7, LBB0_11
	b	LBB0_12
LBB0_27:                                ; %cond.store
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s22, [x2]
	and	w3, w3, #0xff
	tbz	w3, #1, LBB0_14
LBB0_28:                                ; %cond.store43
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x4, x2, #4
	st1.s	{ v22 }[1], [x4]
	tbz	w3, #2, LBB0_15
LBB0_29:                                ; %cond.store45
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x4, x2, #8
	st1.s	{ v22 }[2], [x4]
	tbz	w3, #3, LBB0_16
LBB0_30:                                ; %cond.store47
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x4, x2, #12
	st1.s	{ v22 }[3], [x4]
	tbz	w3, #4, LBB0_17
LBB0_31:                                ; %cond.store49
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s21, [x2, #16]
	tbz	w3, #5, LBB0_18
LBB0_32:                                ; %cond.store51
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x4, x2, #20
	st1.s	{ v21 }[1], [x4]
	tbz	w3, #6, LBB0_19
LBB0_33:                                ; %cond.store53
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x4, x2, #24
	st1.s	{ v21 }[2], [x4]
	tbz	w3, #7, LBB0_2
LBB0_34:                                ; %cond.store55
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x2, #28
	st1.s	{ v21 }[3], [x2]
	b	LBB0_2
LBB0_35:                                ; %direct.false
	fmov	w17, s0
	and	w15, w17, #0xff
	sshll.2d	v21, v16, #0
	sshll.2d	v22, v7, #0
	and.16b	v22, v22, v6
	and.16b	v21, v21, v5
	and.16b	v23, v2, v4
	and.16b	v24, v1, v3
	str	q24, [x13, #1072]
	str	q23, [x13, #1040]
	str	q21, [x13, #1056]
	str	q22, [x13, #1024]
	and	x16, x11, #0x7
	add	x0, sp, #1200
	ldr	x16, [x0, x16, lsl #3]
	sub	x16, x16, x9
	add	x16, x8, x16
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	tbnz	w17, #0, LBB0_223
; %bb.36:                               ; %else59
	tbnz	w15, #1, LBB0_224
LBB0_37:                                ; %else62
	tbnz	w15, #2, LBB0_225
LBB0_38:                                ; %else65
	tbnz	w15, #3, LBB0_226
LBB0_39:                                ; %else68
	tbnz	w15, #4, LBB0_227
LBB0_40:                                ; %else71
	tbnz	w15, #5, LBB0_228
LBB0_41:                                ; %else74
	tbnz	w15, #6, LBB0_229
LBB0_42:                                ; %else77
	tbz	w15, #7, LBB0_44
LBB0_43:                                ; %cond.load79
	add	x15, x16, #28
	ld1.s	{ v22 }[3], [x15]
LBB0_44:                                ; %else80
	fmov	w17, s0
	and	w15, w17, #0xff
	sshll.2d	v23, v16, #0
	sshll.2d	v24, v7, #0
Lloh14:
	adrp	x16, lCPI0_7@PAGE
Lloh15:
	ldr	q25, [x16, lCPI0_7@PAGEOFF]
	and.16b	v24, v24, v25
Lloh16:
	adrp	x16, lCPI0_8@PAGE
Lloh17:
	ldr	q25, [x16, lCPI0_8@PAGEOFF]
	and.16b	v23, v23, v25
Lloh18:
	adrp	x16, lCPI0_9@PAGE
Lloh19:
	ldr	q25, [x16, lCPI0_9@PAGEOFF]
	and.16b	v25, v2, v25
Lloh20:
	adrp	x16, lCPI0_10@PAGE
Lloh21:
	ldr	q26, [x16, lCPI0_10@PAGEOFF]
	and.16b	v26, v1, v26
	stp	q23, q26, [x13, #976]
	stp	q24, q25, [x13, #944]
	and	x16, x11, #0x7
	add	x0, sp, #1120
	ldr	x16, [x0, x16, lsl #3]
	sub	x16, x16, x9
	add	x16, x8, x16
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbnz	w17, #0, LBB0_230
; %bb.45:                               ; %else84
	tbnz	w15, #1, LBB0_231
LBB0_46:                                ; %else87
	tbnz	w15, #2, LBB0_232
LBB0_47:                                ; %else90
	tbnz	w15, #3, LBB0_233
LBB0_48:                                ; %else93
	tbnz	w15, #4, LBB0_234
LBB0_49:                                ; %else96
	tbnz	w15, #5, LBB0_235
LBB0_50:                                ; %else99
	tbnz	w15, #6, LBB0_236
LBB0_51:                                ; %else102
	tbz	w15, #7, LBB0_53
LBB0_52:                                ; %cond.load104
	add	x15, x16, #28
	ld1.s	{ v24 }[3], [x15]
LBB0_53:                                ; %else105
	fmov	w17, s0
	and	w15, w17, #0xff
	sshll.2d	v25, v16, #0
	sshll.2d	v26, v7, #0
Lloh22:
	adrp	x16, lCPI0_11@PAGE
Lloh23:
	ldr	q27, [x16, lCPI0_11@PAGEOFF]
	and.16b	v26, v26, v27
Lloh24:
	adrp	x16, lCPI0_12@PAGE
Lloh25:
	ldr	q27, [x16, lCPI0_12@PAGEOFF]
	and.16b	v25, v25, v27
Lloh26:
	adrp	x16, lCPI0_13@PAGE
Lloh27:
	ldr	q27, [x16, lCPI0_13@PAGEOFF]
	and.16b	v27, v2, v27
Lloh28:
	adrp	x16, lCPI0_14@PAGE
Lloh29:
	ldr	q28, [x16, lCPI0_14@PAGEOFF]
	and.16b	v28, v1, v28
	stp	q25, q28, [x13, #896]
	stp	q26, q27, [x13, #864]
	and	x16, x11, #0x7
	add	x0, sp, #1040
	ldr	x16, [x0, x16, lsl #3]
	sub	x16, x16, x9
	add	x16, x8, x16
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbnz	w17, #0, LBB0_237
; %bb.54:                               ; %else109
	tbnz	w15, #1, LBB0_238
LBB0_55:                                ; %else112
	tbnz	w15, #2, LBB0_239
LBB0_56:                                ; %else115
	tbnz	w15, #3, LBB0_240
LBB0_57:                                ; %else118
	tbnz	w15, #4, LBB0_241
LBB0_58:                                ; %else121
	tbnz	w15, #5, LBB0_242
LBB0_59:                                ; %else124
	tbnz	w15, #6, LBB0_243
LBB0_60:                                ; %else127
	tbz	w15, #7, LBB0_62
LBB0_61:                                ; %cond.load129
	add	x15, x16, #28
	ld1.s	{ v26 }[3], [x15]
LBB0_62:                                ; %else130
	fmov	w17, s0
	and	w15, w17, #0xff
	sshll.2d	v27, v16, #0
	sshll.2d	v28, v7, #0
Lloh30:
	adrp	x16, lCPI0_15@PAGE
Lloh31:
	ldr	q29, [x16, lCPI0_15@PAGEOFF]
	and.16b	v28, v28, v29
Lloh32:
	adrp	x16, lCPI0_16@PAGE
Lloh33:
	ldr	q29, [x16, lCPI0_16@PAGEOFF]
	and.16b	v27, v27, v29
Lloh34:
	adrp	x16, lCPI0_17@PAGE
Lloh35:
	ldr	q29, [x16, lCPI0_17@PAGEOFF]
	and.16b	v29, v2, v29
Lloh36:
	adrp	x16, lCPI0_18@PAGE
Lloh37:
	ldr	q30, [x16, lCPI0_18@PAGEOFF]
	and.16b	v30, v1, v30
	stp	q27, q30, [x13, #816]
	stp	q28, q29, [x13, #784]
	and	x16, x11, #0x7
	add	x0, sp, #960
	ldr	x16, [x0, x16, lsl #3]
	sub	x16, x16, x9
	add	x16, x8, x16
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbnz	w17, #0, LBB0_244
; %bb.63:                               ; %else134
	tbnz	w15, #1, LBB0_245
LBB0_64:                                ; %else137
	tbnz	w15, #2, LBB0_246
LBB0_65:                                ; %else140
	tbnz	w15, #3, LBB0_247
LBB0_66:                                ; %else143
	tbnz	w15, #4, LBB0_248
LBB0_67:                                ; %else146
	tbnz	w15, #5, LBB0_249
LBB0_68:                                ; %else149
	tbz	w15, #6, LBB0_70
LBB0_69:                                ; %cond.load151
	add	x17, x16, #24
	ld1.s	{ v28 }[2], [x17]
LBB0_70:                                ; %else152
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	fmul.4s	v24, v24, v24
	fmul.4s	v29, v25, v25
	fmul.4s	v25, v26, v26
	tbz	w15, #7, LBB0_72
; %bb.71:                               ; %cond.load154
	add	x15, x16, #28
	ld1.s	{ v28 }[3], [x15]
LBB0_72:                                ; %else155
	mov	x15, #0                         ; =0x0
	fmul.4s	v30, v27, v27
	fmul.4s	v26, v28, v28
	and.16b	v22, v16, v22
	and.16b	v21, v7, v21
	and.16b	v24, v16, v24
	and.16b	v23, v7, v23
	mov	w16, #224                       ; =0xe0
	fmov	w17, s0
	and.16b	v25, v16, v25
	and.16b	v27, v7, v29
	and.16b	v26, v16, v26
	and	x0, x11, #0x7
	add	x1, sp, #880
	and	x2, x11, #0x7
	add	x3, sp, #800
	and	x4, x11, #0x7
	and.16b	v28, v7, v30
	add	x5, sp, #720
	sshll.2d	v29, v16, #0
	and	x6, x11, #0x7
	add	x7, sp, #640
	sshll.2d	v30, v7, #0
	b	LBB0_74
LBB0_73:                                ; %else255
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmul.4s	v17, v8, v8
	fmul.4s	v18, v31, v31
	fadd.4s	v18, v21, v18
	fadd.4s	v17, v22, v17
	fmul.4s	v19, v10, v10
	fmul.4s	v31, v9, v9
	fadd.4s	v31, v23, v31
	fadd.4s	v19, v24, v19
	fmul.4s	v8, v12, v12
	fmul.4s	v9, v11, v11
	fadd.4s	v9, v27, v9
	fadd.4s	v8, v25, v8
	fmul.4s	v10, v13, v13
	fmul.4s	v11, v14, v14
	fadd.4s	v11, v26, v11
	fadd.4s	v10, v28, v10
	bit.16b	v22, v17, v16
	bit.16b	v21, v18, v7
	bit.16b	v24, v19, v16
	bit.16b	v23, v31, v7
	bit.16b	v25, v8, v16
	bit.16b	v27, v9, v7
	add	x16, x16, #128
	bit.16b	v28, v10, v7
	add	x15, x15, #4
	bit.16b	v26, v11, v16
	cmp	x15, #508
	b.hs	LBB0_138
LBB0_74:                                ; %direct.true47
                                        ; =>This Inner Loop Header: Depth=1
	sub	x19, x16, #96
	dup.2d	v31, x19
	orr.16b	v8, v31, v3
	orr.16b	v9, v31, v4
	orr.16b	v10, v31, v5
	orr.16b	v31, v31, v6
	and.16b	v31, v30, v31
	and.16b	v10, v29, v10
	and.16b	v9, v2, v9
	and.16b	v8, v1, v8
	stp	q10, q8, [x13, #736]
	stp	q31, q9, [x13, #704]
	ldr	x19, [x1, x0, lsl #3]
	sub	x19, x19, x9
	add	x19, x8, x19
	movi.2d	v31, #0000000000000000
	movi.2d	v8, #0000000000000000
	tbnz	w17, #0, LBB0_109
; %bb.75:                               ; %else159
                                        ;   in Loop: Header=BB0_74 Depth=1
	and	w20, w17, #0xff
	tbnz	w20, #1, LBB0_110
LBB0_76:                                ; %else162
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #2, LBB0_111
LBB0_77:                                ; %else165
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #3, LBB0_112
LBB0_78:                                ; %else168
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #4, LBB0_113
LBB0_79:                                ; %else171
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #5, LBB0_114
LBB0_80:                                ; %else174
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #6, LBB0_115
LBB0_81:                                ; %else177
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbz	w20, #7, LBB0_83
LBB0_82:                                ; %cond.load179
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x19, x19, #28
	ld1.s	{ v8 }[3], [x19]
LBB0_83:                                ; %else180
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	w20, s0
	sshll.2d	v9, v16, #0
	sshll.2d	v10, v7, #0
	sub	x19, x16, #64
	dup.2d	v11, x19
	orr.16b	v12, v11, v3
	orr.16b	v13, v11, v4
	orr.16b	v14, v11, v5
	orr.16b	v11, v11, v6
	and.16b	v10, v10, v11
	and.16b	v9, v9, v14
	and.16b	v11, v2, v13
	and.16b	v12, v1, v12
	stp	q9, q12, [x13, #656]
	stp	q10, q11, [x13, #624]
	ldr	x19, [x3, x2, lsl #3]
	sub	x19, x19, x9
	add	x19, x8, x19
	movi.2d	v9, #0000000000000000
	movi.2d	v10, #0000000000000000
	tbnz	w20, #0, LBB0_116
; %bb.84:                               ; %else184
                                        ;   in Loop: Header=BB0_74 Depth=1
	and	w20, w20, #0xff
	tbnz	w20, #1, LBB0_117
LBB0_85:                                ; %else187
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #2, LBB0_118
LBB0_86:                                ; %else190
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #3, LBB0_119
LBB0_87:                                ; %else193
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #4, LBB0_120
LBB0_88:                                ; %else196
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #5, LBB0_121
LBB0_89:                                ; %else199
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #6, LBB0_122
LBB0_90:                                ; %else202
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbz	w20, #7, LBB0_92
LBB0_91:                                ; %cond.load204
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x19, x19, #28
	ld1.s	{ v10 }[3], [x19]
LBB0_92:                                ; %else205
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	w20, s0
	sshll.2d	v11, v16, #0
	sshll.2d	v12, v7, #0
	sub	x19, x16, #32
	dup.2d	v13, x19
	orr.16b	v14, v13, v3
	orr.16b	v15, v13, v4
	orr.16b	v17, v13, v5
	orr.16b	v13, v13, v6
	and.16b	v12, v12, v13
	and.16b	v17, v11, v17
	and.16b	v11, v2, v15
	and.16b	v13, v1, v14
	stp	q17, q13, [x13, #576]
	stp	q12, q11, [x13, #544]
	ldr	x19, [x5, x4, lsl #3]
	sub	x19, x19, x9
	add	x19, x8, x19
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	tbnz	w20, #0, LBB0_123
; %bb.93:                               ; %else209
                                        ;   in Loop: Header=BB0_74 Depth=1
	and	w20, w20, #0xff
	tbnz	w20, #1, LBB0_124
LBB0_94:                                ; %else212
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #2, LBB0_125
LBB0_95:                                ; %else215
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #3, LBB0_126
LBB0_96:                                ; %else218
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #4, LBB0_127
LBB0_97:                                ; %else221
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #5, LBB0_128
LBB0_98:                                ; %else224
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #6, LBB0_129
LBB0_99:                                ; %else227
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbz	w20, #7, LBB0_101
LBB0_100:                               ; %cond.load229
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x19, x19, #28
	ld1.s	{ v12 }[3], [x19]
LBB0_101:                               ; %else230
                                        ;   in Loop: Header=BB0_74 Depth=1
	fmov	w20, s0
	sshll.2d	v17, v16, #0
	sshll.2d	v13, v7, #0
	dup.2d	v14, x16
	orr.16b	v15, v14, v3
	orr.16b	v18, v14, v4
	orr.16b	v19, v14, v5
	orr.16b	v14, v14, v6
	and.16b	v13, v13, v14
	and.16b	v17, v17, v19
	and.16b	v18, v2, v18
	and.16b	v19, v1, v15
	stp	q17, q19, [x13, #496]
	stp	q13, q18, [x13, #464]
	ldr	x19, [x7, x6, lsl #3]
	sub	x19, x19, x9
	add	x19, x8, x19
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	tbnz	w20, #0, LBB0_130
; %bb.102:                              ; %else234
                                        ;   in Loop: Header=BB0_74 Depth=1
	and	w20, w20, #0xff
	tbnz	w20, #1, LBB0_131
LBB0_103:                               ; %else237
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #2, LBB0_132
LBB0_104:                               ; %else240
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #3, LBB0_133
LBB0_105:                               ; %else243
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #4, LBB0_134
LBB0_106:                               ; %else246
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #5, LBB0_135
LBB0_107:                               ; %else249
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbnz	w20, #6, LBB0_136
LBB0_108:                               ; %else252
                                        ;   in Loop: Header=BB0_74 Depth=1
	tbz	w20, #7, LBB0_73
	b	LBB0_137
LBB0_109:                               ; %cond.load158
                                        ;   in Loop: Header=BB0_74 Depth=1
	ldr	s31, [x19]
	and	w20, w17, #0xff
	tbz	w20, #1, LBB0_76
LBB0_110:                               ; %cond.load161
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #4
	ld1.s	{ v31 }[1], [x21]
	tbz	w20, #2, LBB0_77
LBB0_111:                               ; %cond.load164
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #8
	ld1.s	{ v31 }[2], [x21]
	tbz	w20, #3, LBB0_78
LBB0_112:                               ; %cond.load167
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #12
	ld1.s	{ v31 }[3], [x21]
	tbz	w20, #4, LBB0_79
LBB0_113:                               ; %cond.load170
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #16
	ld1.s	{ v8 }[0], [x21]
	tbz	w20, #5, LBB0_80
LBB0_114:                               ; %cond.load173
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #20
	ld1.s	{ v8 }[1], [x21]
	tbz	w20, #6, LBB0_81
LBB0_115:                               ; %cond.load176
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #24
	ld1.s	{ v8 }[2], [x21]
	tbnz	w20, #7, LBB0_82
	b	LBB0_83
LBB0_116:                               ; %cond.load183
                                        ;   in Loop: Header=BB0_74 Depth=1
	ldr	s9, [x19]
	and	w20, w20, #0xff
	tbz	w20, #1, LBB0_85
LBB0_117:                               ; %cond.load186
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #4
	ld1.s	{ v9 }[1], [x21]
	tbz	w20, #2, LBB0_86
LBB0_118:                               ; %cond.load189
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #8
	ld1.s	{ v9 }[2], [x21]
	tbz	w20, #3, LBB0_87
LBB0_119:                               ; %cond.load192
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #12
	ld1.s	{ v9 }[3], [x21]
	tbz	w20, #4, LBB0_88
LBB0_120:                               ; %cond.load195
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #16
	ld1.s	{ v10 }[0], [x21]
	tbz	w20, #5, LBB0_89
LBB0_121:                               ; %cond.load198
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #20
	ld1.s	{ v10 }[1], [x21]
	tbz	w20, #6, LBB0_90
LBB0_122:                               ; %cond.load201
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #24
	ld1.s	{ v10 }[2], [x21]
	tbnz	w20, #7, LBB0_91
	b	LBB0_92
LBB0_123:                               ; %cond.load208
                                        ;   in Loop: Header=BB0_74 Depth=1
	ldr	s11, [x19]
	and	w20, w20, #0xff
	tbz	w20, #1, LBB0_94
LBB0_124:                               ; %cond.load211
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #4
	ld1.s	{ v11 }[1], [x21]
	tbz	w20, #2, LBB0_95
LBB0_125:                               ; %cond.load214
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #8
	ld1.s	{ v11 }[2], [x21]
	tbz	w20, #3, LBB0_96
LBB0_126:                               ; %cond.load217
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #12
	ld1.s	{ v11 }[3], [x21]
	tbz	w20, #4, LBB0_97
LBB0_127:                               ; %cond.load220
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #16
	ld1.s	{ v12 }[0], [x21]
	tbz	w20, #5, LBB0_98
LBB0_128:                               ; %cond.load223
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #20
	ld1.s	{ v12 }[1], [x21]
	tbz	w20, #6, LBB0_99
LBB0_129:                               ; %cond.load226
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #24
	ld1.s	{ v12 }[2], [x21]
	tbnz	w20, #7, LBB0_100
	b	LBB0_101
LBB0_130:                               ; %cond.load233
                                        ;   in Loop: Header=BB0_74 Depth=1
	ldr	s13, [x19]
	and	w20, w20, #0xff
	tbz	w20, #1, LBB0_103
LBB0_131:                               ; %cond.load236
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #4
	ld1.s	{ v13 }[1], [x21]
	tbz	w20, #2, LBB0_104
LBB0_132:                               ; %cond.load239
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #8
	ld1.s	{ v13 }[2], [x21]
	tbz	w20, #3, LBB0_105
LBB0_133:                               ; %cond.load242
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #12
	ld1.s	{ v13 }[3], [x21]
	tbz	w20, #4, LBB0_106
LBB0_134:                               ; %cond.load245
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #16
	ld1.s	{ v14 }[0], [x21]
	tbz	w20, #5, LBB0_107
LBB0_135:                               ; %cond.load248
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #20
	ld1.s	{ v14 }[1], [x21]
	tbz	w20, #6, LBB0_108
LBB0_136:                               ; %cond.load251
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x21, x19, #24
	ld1.s	{ v14 }[2], [x21]
	tbz	w20, #7, LBB0_73
LBB0_137:                               ; %cond.load254
                                        ;   in Loop: Header=BB0_74 Depth=1
	add	x19, x19, #28
	ld1.s	{ v14 }[3], [x19]
	b	LBB0_73
LBB0_138:                               ; %direct.false48
	mov	x16, #0                         ; =0x0
	sshll.2d	v17, v16, #0
	sshll.2d	v18, v7, #0
	and.16b	v18, v18, v20
	and.16b	v17, v17, v20
	and.16b	v19, v2, v20
	and.16b	v20, v1, v20
	stp	q17, q20, [x13, #432]
	stp	q18, q19, [x13, #400]
	and	x15, x11, #0x7
	add	x17, sp, #576
	ldr	x15, [x17, x15, lsl #3]
	fmov	w17, s0
	and	x0, x11, #0x7
	add	x1, sp, #496
	b	LBB0_140
LBB0_139:                               ; %else298
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x16, x16, #32
	cmp	x16, #4, lsl #12                ; =16384
	b.eq	LBB0_172
LBB0_140:                               ; %direct.true85
                                        ; =>This Inner Loop Header: Depth=1
	add	x2, x14, x16
	movi.2d	v29, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbnz	w17, #0, LBB0_157
; %bb.141:                              ; %else259
                                        ;   in Loop: Header=BB0_140 Depth=1
	and	w3, w17, #0xff
	tbnz	w3, #1, LBB0_158
LBB0_142:                               ; %else262
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w3, #2, LBB0_159
LBB0_143:                               ; %else265
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w3, #3, LBB0_160
LBB0_144:                               ; %else268
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w3, #4, LBB0_161
LBB0_145:                               ; %else271
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w3, #5, LBB0_162
LBB0_146:                               ; %else274
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w3, #6, LBB0_163
LBB0_147:                               ; %else277
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbz	w3, #7, LBB0_149
LBB0_148:                               ; %cond.load279
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x2, x2, #28
	ld1.s	{ v20 }[3], [x2]
LBB0_149:                               ; %else280
                                        ;   in Loop: Header=BB0_140 Depth=1
	fmov	w3, s0
	sshll.2d	v17, v16, #0
	sshll.2d	v18, v7, #0
	dup.2d	v19, x16
	orr.16b	v30, v19, v3
	orr.16b	v31, v19, v4
	orr.16b	v8, v19, v5
	orr.16b	v19, v19, v6
	and.16b	v18, v18, v19
	and.16b	v17, v17, v8
	and.16b	v19, v2, v31
	and.16b	v30, v1, v30
	stp	q17, q30, [x13, #352]
	stp	q18, q19, [x13, #320]
	ldr	x2, [x1, x0, lsl #3]
	sub	x2, x2, x9
	add	x2, x15, x2
	tbnz	w3, #0, LBB0_164
; %bb.150:                              ; %else284
                                        ;   in Loop: Header=BB0_140 Depth=1
	and	w3, w3, #0xff
	tbnz	w3, #1, LBB0_165
LBB0_151:                               ; %else286
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w3, #2, LBB0_166
LBB0_152:                               ; %else288
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w3, #3, LBB0_167
LBB0_153:                               ; %else290
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w3, #4, LBB0_168
LBB0_154:                               ; %else292
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w3, #5, LBB0_169
LBB0_155:                               ; %else294
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w3, #6, LBB0_170
LBB0_156:                               ; %else296
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbz	w3, #7, LBB0_139
	b	LBB0_171
LBB0_157:                               ; %cond.load258
                                        ;   in Loop: Header=BB0_140 Depth=1
	ldr	s29, [x2]
	and	w3, w17, #0xff
	tbz	w3, #1, LBB0_142
LBB0_158:                               ; %cond.load261
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x4, x2, #4
	ld1.s	{ v29 }[1], [x4]
	tbz	w3, #2, LBB0_143
LBB0_159:                               ; %cond.load264
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x4, x2, #8
	ld1.s	{ v29 }[2], [x4]
	tbz	w3, #3, LBB0_144
LBB0_160:                               ; %cond.load267
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x4, x2, #12
	ld1.s	{ v29 }[3], [x4]
	tbz	w3, #4, LBB0_145
LBB0_161:                               ; %cond.load270
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x4, x2, #16
	ld1.s	{ v20 }[0], [x4]
	tbz	w3, #5, LBB0_146
LBB0_162:                               ; %cond.load273
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x4, x2, #20
	ld1.s	{ v20 }[1], [x4]
	tbz	w3, #6, LBB0_147
LBB0_163:                               ; %cond.load276
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x4, x2, #24
	ld1.s	{ v20 }[2], [x4]
	tbnz	w3, #7, LBB0_148
	b	LBB0_149
LBB0_164:                               ; %cond.store283
                                        ;   in Loop: Header=BB0_140 Depth=1
	str	s29, [x2]
	and	w3, w3, #0xff
	tbz	w3, #1, LBB0_151
LBB0_165:                               ; %cond.store285
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x4, x2, #4
	st1.s	{ v29 }[1], [x4]
	tbz	w3, #2, LBB0_152
LBB0_166:                               ; %cond.store287
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x4, x2, #8
	st1.s	{ v29 }[2], [x4]
	tbz	w3, #3, LBB0_153
LBB0_167:                               ; %cond.store289
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x4, x2, #12
	st1.s	{ v29 }[3], [x4]
	tbz	w3, #4, LBB0_154
LBB0_168:                               ; %cond.store291
                                        ;   in Loop: Header=BB0_140 Depth=1
	str	s20, [x2, #16]
	tbz	w3, #5, LBB0_155
LBB0_169:                               ; %cond.store293
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x4, x2, #20
	st1.s	{ v20 }[1], [x4]
	tbz	w3, #6, LBB0_156
LBB0_170:                               ; %cond.store295
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x4, x2, #24
	st1.s	{ v20 }[2], [x4]
	tbz	w3, #7, LBB0_139
LBB0_171:                               ; %cond.store297
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x2, x2, #28
	st1.s	{ v20 }[3], [x2]
	b	LBB0_139
LBB0_172:                               ; %direct.false86
	mov	x14, #0                         ; =0x0
	ldr	q17, [sp]                       ; 16-byte Folded Reload
	xtn.8b	v29, v17
	fadd.4s	v17, v22, v24
	fadd.4s	v18, v21, v23
	fadd.4s	v18, v18, v27
	fadd.4s	v17, v17, v25
	fadd.4s	v19, v17, v26
	fadd.4s	v20, v18, v28
	ldp	q18, q17, [sp, #16]             ; 32-byte Folded Reload
	and.16b	v17, v7, v17
	and.16b	v18, v16, v18
	movi.4s	v21, #1
	eor.16b	v22, v18, v21
	eor.16b	v25, v17, v21
	umov.b	w17, v29[0]
	str	q20, [x13, #288]
	ldr	s21, [x13, #292]
	umov.b	w16, v29[1]
	ands	w0, w17, #0x1
	tst	w0, w16
	movi	d17, #0000000000000000
	fcsel	s21, s21, s17, ne
	mov.s	w1, v25[1]
	add	x2, sp, #136
	add	x3, sp, #136
	bfxil	x3, x1, #0, #3
	str	d29, [sp, #136]
	ldrb	w3, [x3]
	add	x4, sp, #432
	orr	x1, x4, x1, lsl #2
	stp	q20, q19, [x13, #256]
	ldr	s23, [x1]
	ands	w1, w16, #0x1
	tst	w1, w3
	mov.s	w1, v25[2]
	fcsel	s23, s23, s17, ne
	add	x3, sp, #136
	bfxil	x3, x1, #0, #3
	ldrb	w3, [x3]
	add	x4, sp, #400
	orr	x4, x4, x1, lsl #2
	umov.b	w1, v29[2]
	stp	q20, q19, [x13, #224]
	ldr	s24, [x4]
	ands	w4, w1, #0x1
	tst	w4, w3
	fcsel	s24, s24, s17, ne
	mov.s	w3, v25[3]
	add	x4, sp, #136
	bfxil	x4, x3, #0, #3
	ldrb	w4, [x4]
	add	x5, sp, #368
	orr	x5, x5, x3, lsl #2
	umov.b	w3, v29[3]
	stp	q20, q19, [x13, #192]
	ldr	s25, [x5]
	ands	w5, w3, #0x1
	tst	w5, w4
	fcsel	s25, s25, s17, ne
	fmov	w5, s22
	add	x4, sp, #136
	bfxil	x4, x5, #0, #3
	ldrb	w6, [x4]
	umov.b	w4, v29[4]
	and	w6, w4, w6
	stp	q20, q19, [x13, #160]
	add	x7, sp, #336
	ldr	s26, [x7, w5, uxtw #2]
	tst	w6, #0x1
	mov.s	w6, v22[1]
	add	x7, sp, #136
	bfxil	x7, x6, #0, #3
	umov.b	w5, v29[5]
	ldrb	w7, [x7]
	stp	q20, q19, [x13, #128]
	add	x19, sp, #304
	ldr	s27, [x19, w6, uxtw #2]
	fcsel	s26, s26, s17, ne
	ands	w6, w5, #0x1
	tst	w6, w7
	fcsel	s27, s27, s17, ne
	mov.s	w7, v22[2]
	add	x6, sp, #136
	bfxil	x6, x7, #0, #3
	ldrb	w19, [x6]
	umov.b	w6, v29[6]
	stp	q20, q19, [x13, #96]
	add	x20, sp, #272
	ldr	s28, [x20, w7, uxtw #2]
	ands	w7, w6, #0x1
	tst	w7, w19
	mov.s	w7, v22[3]
	add	x19, sp, #136
	bfxil	x19, x7, #0, #3
	ldrb	w19, [x19]
	stp	q20, q19, [x13, #64]
	add	x20, sp, #240
	ldr	s22, [x20, w7, uxtw #2]
	umov.b	w7, v29[7]
	fcsel	s28, s28, s17, ne
	ands	w20, w7, #0x1
	tst	w20, w19
	fcsel	s22, s22, s17, ne
	mov.s	v21[1], v23[0]
	mov.s	v21[2], v24[0]
	mov.s	v21[3], v25[0]
	mov.s	v26[1], v27[0]
	mov.s	v26[2], v28[0]
	mov.s	v26[3], v22[0]
	fadd.4s	v19, v19, v26
	fadd.4s	v20, v20, v21
	movi.4s	v21, #2
	eor.16b	v18, v18, v21
	str	q20, [x13, #32]
	ldr	s21, [x13, #40]
	tst	w0, w1
	fcsel	s21, s21, s17, ne
	fmov	w19, s18
	bfxil	x2, x19, #0, #3
	ldrb	w2, [x2]
	and	w2, w4, w2
	str	q20, [sp, #176]
	str	q19, [x13, #16]
	add	x13, sp, #176
	ldr	s18, [x13, w19, uxtw #2]
	tst	w2, #0x1
	fcsel	s18, s18, s17, ne
	fadd.4s	v18, v19, v18
	tst	w0, w4
	fcsel	s18, s18, s17, ne
	ands	w13, w17, #0x1
	fadd.4s	v19, v20, v21
	fadd	s18, s19, s18
	fcsel	s19, s18, s17, ne
	tst	w16, #0x1
	fcsel	s20, s19, s17, ne
	tst	w1, #0x1
	fcsel	s21, s19, s17, ne
	tst	w3, #0x1
	fcsel	s22, s19, s17, ne
	tst	w13, w4
	fcsel	s18, s18, s17, ne
	tst	w5, #0x1
	fcsel	s23, s19, s17, ne
	tst	w6, #0x1
	fcsel	s24, s19, s17, ne
	tst	w7, #0x1
	fcsel	s25, s19, s17, ne
	mov.s	v19[1], v20[0]
	mov.s	v19[2], v21[0]
	mov.s	v19[3], v22[0]
	mov.s	v18[1], v23[0]
	mov.s	v18[2], v24[0]
	mov.s	v18[3], v25[0]
	stp	q19, q18, [sp, #144]
	and	x13, x11, #0x7
	add	x16, sp, #144
	ldr	s18, [x16, x13, lsl #2]
	fadd	s17, s18, s17
	mov	w13, #964689920                 ; =0x39800000
	fmov	s18, w13
	fmul	s17, s17, s18
	mov	w13, #50604                     ; =0xc5ac
	movk	w13, #14119, lsl #16
	fmov	s18, w13
	fadd	s17, s17, s18
	fsqrt	s17, s17
	dup.4s	v17, v17[0]
	add	x10, x10, x12
	fmov	w12, s0
	sshll.2d	v16, v16, #0
	sshll.2d	v7, v7, #0
	and	x11, x11, #0x7
	add	x13, sp, #64
	b	LBB0_174
LBB0_173:                               ; %else365
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x14, x14, #32
	cmp	x14, #4, lsl #12                ; =16384
	b.eq	LBB0_222
LBB0_174:                               ; %direct.true104
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v18, x14
	orr.16b	v19, v18, v3
	orr.16b	v20, v18, v4
	orr.16b	v21, v18, v5
	orr.16b	v18, v18, v6
	and.16b	v18, v7, v18
	and.16b	v21, v16, v21
	and.16b	v20, v2, v20
	and.16b	v19, v1, v19
	stp	q21, q19, [sp, #96]
	stp	q18, q20, [sp, #64]
	ldr	x16, [x13, x11, lsl #3]
	sub	x16, x16, x9
	add	x17, x8, x16
	movi.2d	v19, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbnz	w12, #0, LBB0_198
; %bb.175:                              ; %else301
                                        ;   in Loop: Header=BB0_174 Depth=1
	and	w0, w12, #0xff
	tbnz	w0, #1, LBB0_199
LBB0_176:                               ; %else304
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w0, #2, LBB0_200
LBB0_177:                               ; %else307
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w0, #3, LBB0_201
LBB0_178:                               ; %else310
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w0, #4, LBB0_202
LBB0_179:                               ; %else313
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w0, #5, LBB0_203
LBB0_180:                               ; %else316
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w0, #6, LBB0_204
LBB0_181:                               ; %else319
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w0, #7, LBB0_205
LBB0_182:                               ; %else322
                                        ;   in Loop: Header=BB0_174 Depth=1
	fmov	w17, s0
	add	x16, x15, x16
	movi.2d	v21, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbnz	w17, #0, LBB0_206
LBB0_183:                               ; %else326
                                        ;   in Loop: Header=BB0_174 Depth=1
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB0_207
LBB0_184:                               ; %else329
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w17, #2, LBB0_208
LBB0_185:                               ; %else332
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w17, #3, LBB0_209
LBB0_186:                               ; %else335
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w17, #4, LBB0_210
LBB0_187:                               ; %else338
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w17, #5, LBB0_211
LBB0_188:                               ; %else341
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w17, #6, LBB0_212
LBB0_189:                               ; %else344
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w17, #7, LBB0_213
LBB0_190:                               ; %else347
                                        ;   in Loop: Header=BB0_174 Depth=1
	fdiv.4s	v19, v19, v17
	fmov	w17, s0
	fmul.4s	v19, v19, v21
	add	x16, x10, x14
	tbnz	w17, #0, LBB0_214
LBB0_191:                               ; %else351
                                        ;   in Loop: Header=BB0_174 Depth=1
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB0_215
LBB0_192:                               ; %else353
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w17, #2, LBB0_216
LBB0_193:                               ; %else355
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w17, #3, LBB0_217
LBB0_194:                               ; %else357
                                        ;   in Loop: Header=BB0_174 Depth=1
	fdiv.4s	v18, v18, v17
	fmul.4s	v18, v18, v20
	tbnz	w17, #4, LBB0_218
LBB0_195:                               ; %else359
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w17, #5, LBB0_219
LBB0_196:                               ; %else361
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbnz	w17, #6, LBB0_220
LBB0_197:                               ; %else363
                                        ;   in Loop: Header=BB0_174 Depth=1
	tbz	w17, #7, LBB0_173
	b	LBB0_221
LBB0_198:                               ; %cond.load300
                                        ;   in Loop: Header=BB0_174 Depth=1
	ldr	s19, [x17]
	and	w0, w12, #0xff
	tbz	w0, #1, LBB0_176
LBB0_199:                               ; %cond.load303
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x1, x17, #4
	ld1.s	{ v19 }[1], [x1]
	tbz	w0, #2, LBB0_177
LBB0_200:                               ; %cond.load306
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x1, x17, #8
	ld1.s	{ v19 }[2], [x1]
	tbz	w0, #3, LBB0_178
LBB0_201:                               ; %cond.load309
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x1, x17, #12
	ld1.s	{ v19 }[3], [x1]
	tbz	w0, #4, LBB0_179
LBB0_202:                               ; %cond.load312
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x1, x17, #16
	ld1.s	{ v18 }[0], [x1]
	tbz	w0, #5, LBB0_180
LBB0_203:                               ; %cond.load315
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x1, x17, #20
	ld1.s	{ v18 }[1], [x1]
	tbz	w0, #6, LBB0_181
LBB0_204:                               ; %cond.load318
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x1, x17, #24
	ld1.s	{ v18 }[2], [x1]
	tbz	w0, #7, LBB0_182
LBB0_205:                               ; %cond.load321
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x17, x17, #28
	ld1.s	{ v18 }[3], [x17]
	fmov	w17, s0
	add	x16, x15, x16
	movi.2d	v21, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbz	w17, #0, LBB0_183
LBB0_206:                               ; %cond.load325
                                        ;   in Loop: Header=BB0_174 Depth=1
	ldr	s21, [x16]
	and	w17, w17, #0xff
	tbz	w17, #1, LBB0_184
LBB0_207:                               ; %cond.load328
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x0, x16, #4
	ld1.s	{ v21 }[1], [x0]
	tbz	w17, #2, LBB0_185
LBB0_208:                               ; %cond.load331
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x0, x16, #8
	ld1.s	{ v21 }[2], [x0]
	tbz	w17, #3, LBB0_186
LBB0_209:                               ; %cond.load334
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x0, x16, #12
	ld1.s	{ v21 }[3], [x0]
	tbz	w17, #4, LBB0_187
LBB0_210:                               ; %cond.load337
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x0, x16, #16
	ld1.s	{ v20 }[0], [x0]
	tbz	w17, #5, LBB0_188
LBB0_211:                               ; %cond.load340
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x0, x16, #20
	ld1.s	{ v20 }[1], [x0]
	tbz	w17, #6, LBB0_189
LBB0_212:                               ; %cond.load343
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x0, x16, #24
	ld1.s	{ v20 }[2], [x0]
	tbz	w17, #7, LBB0_190
LBB0_213:                               ; %cond.load346
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x16, x16, #28
	ld1.s	{ v20 }[3], [x16]
	fdiv.4s	v19, v19, v17
	fmov	w17, s0
	fmul.4s	v19, v19, v21
	add	x16, x10, x14
	tbz	w17, #0, LBB0_191
LBB0_214:                               ; %cond.store350
                                        ;   in Loop: Header=BB0_174 Depth=1
	str	s19, [x16]
	and	w17, w17, #0xff
	tbz	w17, #1, LBB0_192
LBB0_215:                               ; %cond.store352
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x0, x16, #4
	st1.s	{ v19 }[1], [x0]
	tbz	w17, #2, LBB0_193
LBB0_216:                               ; %cond.store354
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x0, x16, #8
	st1.s	{ v19 }[2], [x0]
	tbz	w17, #3, LBB0_194
LBB0_217:                               ; %cond.store356
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x0, x16, #12
	st1.s	{ v19 }[3], [x0]
	fdiv.4s	v18, v18, v17
	fmul.4s	v18, v18, v20
	tbz	w17, #4, LBB0_195
LBB0_218:                               ; %cond.store358
                                        ;   in Loop: Header=BB0_174 Depth=1
	str	s18, [x16, #16]
	tbz	w17, #5, LBB0_196
LBB0_219:                               ; %cond.store360
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x0, x16, #20
	st1.s	{ v18 }[1], [x0]
	tbz	w17, #6, LBB0_197
LBB0_220:                               ; %cond.store362
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x0, x16, #24
	st1.s	{ v18 }[2], [x0]
	tbz	w17, #7, LBB0_173
LBB0_221:                               ; %cond.store364
                                        ;   in Loop: Header=BB0_174 Depth=1
	add	x16, x16, #28
	st1.s	{ v18 }[3], [x16]
	b	LBB0_173
LBB0_222:                               ; %common.ret
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #1440
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #96             ; 16-byte Folded Reload
	ret
LBB0_223:                               ; %cond.load58
	ldr	s21, [x16]
	tbz	w15, #1, LBB0_37
LBB0_224:                               ; %cond.load61
	add	x17, x16, #4
	ld1.s	{ v21 }[1], [x17]
	tbz	w15, #2, LBB0_38
LBB0_225:                               ; %cond.load64
	add	x17, x16, #8
	ld1.s	{ v21 }[2], [x17]
	tbz	w15, #3, LBB0_39
LBB0_226:                               ; %cond.load67
	add	x17, x16, #12
	ld1.s	{ v21 }[3], [x17]
	tbz	w15, #4, LBB0_40
LBB0_227:                               ; %cond.load70
	add	x17, x16, #16
	ld1.s	{ v22 }[0], [x17]
	tbz	w15, #5, LBB0_41
LBB0_228:                               ; %cond.load73
	add	x17, x16, #20
	ld1.s	{ v22 }[1], [x17]
	tbz	w15, #6, LBB0_42
LBB0_229:                               ; %cond.load76
	add	x17, x16, #24
	ld1.s	{ v22 }[2], [x17]
	tbnz	w15, #7, LBB0_43
	b	LBB0_44
LBB0_230:                               ; %cond.load83
	ldr	s23, [x16]
	tbz	w15, #1, LBB0_46
LBB0_231:                               ; %cond.load86
	add	x17, x16, #4
	ld1.s	{ v23 }[1], [x17]
	tbz	w15, #2, LBB0_47
LBB0_232:                               ; %cond.load89
	add	x17, x16, #8
	ld1.s	{ v23 }[2], [x17]
	tbz	w15, #3, LBB0_48
LBB0_233:                               ; %cond.load92
	add	x17, x16, #12
	ld1.s	{ v23 }[3], [x17]
	tbz	w15, #4, LBB0_49
LBB0_234:                               ; %cond.load95
	add	x17, x16, #16
	ld1.s	{ v24 }[0], [x17]
	tbz	w15, #5, LBB0_50
LBB0_235:                               ; %cond.load98
	add	x17, x16, #20
	ld1.s	{ v24 }[1], [x17]
	tbz	w15, #6, LBB0_51
LBB0_236:                               ; %cond.load101
	add	x17, x16, #24
	ld1.s	{ v24 }[2], [x17]
	tbnz	w15, #7, LBB0_52
	b	LBB0_53
LBB0_237:                               ; %cond.load108
	ldr	s25, [x16]
	tbz	w15, #1, LBB0_55
LBB0_238:                               ; %cond.load111
	add	x17, x16, #4
	ld1.s	{ v25 }[1], [x17]
	tbz	w15, #2, LBB0_56
LBB0_239:                               ; %cond.load114
	add	x17, x16, #8
	ld1.s	{ v25 }[2], [x17]
	tbz	w15, #3, LBB0_57
LBB0_240:                               ; %cond.load117
	add	x17, x16, #12
	ld1.s	{ v25 }[3], [x17]
	tbz	w15, #4, LBB0_58
LBB0_241:                               ; %cond.load120
	add	x17, x16, #16
	ld1.s	{ v26 }[0], [x17]
	tbz	w15, #5, LBB0_59
LBB0_242:                               ; %cond.load123
	add	x17, x16, #20
	ld1.s	{ v26 }[1], [x17]
	tbz	w15, #6, LBB0_60
LBB0_243:                               ; %cond.load126
	add	x17, x16, #24
	ld1.s	{ v26 }[2], [x17]
	tbnz	w15, #7, LBB0_61
	b	LBB0_62
LBB0_244:                               ; %cond.load133
	ldr	s27, [x16]
	tbz	w15, #1, LBB0_64
LBB0_245:                               ; %cond.load136
	add	x17, x16, #4
	ld1.s	{ v27 }[1], [x17]
	tbz	w15, #2, LBB0_65
LBB0_246:                               ; %cond.load139
	add	x17, x16, #8
	ld1.s	{ v27 }[2], [x17]
	tbz	w15, #3, LBB0_66
LBB0_247:                               ; %cond.load142
	add	x17, x16, #12
	ld1.s	{ v27 }[3], [x17]
	tbz	w15, #4, LBB0_67
LBB0_248:                               ; %cond.load145
	add	x17, x16, #16
	ld1.s	{ v28 }[0], [x17]
	tbz	w15, #5, LBB0_68
LBB0_249:                               ; %cond.load148
	add	x17, x16, #20
	ld1.s	{ v28 }[1], [x17]
	tbnz	w15, #6, LBB0_69
	b	LBB0_70
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_13
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	mov	w22, #0                         ; =0x0
	ldp	w24, w8, [x2, #44]
	stp	w3, w8, [sp, #8]                ; 8-byte Folded Spill
	ldp	w25, w26, [x2]
	ldp	w28, w27, [x2, #8]
	str	w24, [sp, #4]                   ; 4-byte Folded Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #1016                       ; =0x3f8
	str	w8, [x20, #36]
	ldp	w24, w19, [sp, #4]              ; 8-byte Folded Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w24
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w26, eq
	ldr	w10, [sp, #12]                  ; 4-byte Folded Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w26, wzr, w9, ne
	add	w28, w28, w8
	add	w22, w22, #1
	cmp	w22, w19
	b.eq	LBB1_12
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_9 Depth 2
                                        ;     Child Loop BB1_6 Depth 2
	ubfiz	x8, x25, #10, #32
	cmp	x8, x27
	csel	x9, x8, xzr, ls
	subs	x10, x27, x9
	cmp	x10, #1024
	mov	w11, #1024                      ; =0x400
	csel	x10, x10, x11, lo
	cmp	x27, x9
	stp	w25, w26, [x20]
	str	w28, [x20, #8]
	ccmp	x8, x27, #2, hi
	csel	x23, x10, xzr, ls
	cmp	x23, #1024
	b.lo	LBB1_7
; %bb.5:                                ; %packet.batch.full.loop.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w23, #0                         ; =0x0
LBB1_6:                                 ; %packet.batch.full.loop.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	w23, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w23, w23, #8
	cmp	w23, #1024
	b.ne	LBB1_6
	b	LBB1_3
LBB1_7:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x8, x23, #3
	lsl	w24, w8, #3
	cmp	x23, #8
	b.lo	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w19, #0                         ; =0x0
LBB1_9:                                 ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	w19, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w19, w19, #8
	cmp	w24, w19
	b.ne	LBB1_9
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w23, #0x7
	cbz	w2, LBB1_2
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w24, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
	b	LBB1_2
LBB1_12:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_13:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [16384 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [16384 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.slot7 = alloca i64, align 8
  store i64 0, ptr %.slot7, align 4
  %.slot8 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot8, align 32
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.spill12 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill12, align 4
  %tile_snapshot.spill13 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill13, align 64
  %.slot14 = alloca i64, align 8
  store i64 0, ptr %.slot14, align 4
  %.spill15 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill15, align 4
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat18, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 1024
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat20, %41
  %44 = mul i32 %32, 1
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat22, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat24, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat26
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 512
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state27 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state27, 8
  %.splatinsert28 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat29 = shufflevector <8 x i64> %.splatinsert28, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat29, %.spill.load
  %.spill.load30 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load30, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 4096)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state31 = load i64, ptr %.slot, align 4
  %.splatinsert32 = insertelement <8 x i64> poison, i64 %.state31, i64 0
  %.splat33 = shufflevector <8 x i64> %.splatinsert32, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat33, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %92, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %96 = bitcast <8 x i1> %51 to i8
  %97 = call i8 @llvm.cttz.i8(i8 %96, i1 false)
  %98 = zext i8 %97 to i32
  %99 = select i1 %95, i32 %98, i32 0
  %100 = select <8 x i1> %51, <8 x ptr> %93, <8 x ptr> zeroinitializer
  %101 = select <8 x i1> %51, <8 x i64> %94, <8 x i64> zeroinitializer
  %102 = extractelement <8 x ptr> %100, i32 %99
  %103 = extractelement <8 x i64> %101, i32 %99
  %104 = zext i32 %99 to i64
  %105 = mul i64 %104, 4
  %106 = sub i64 %103, %105
  %private.contiguous.address = getelementptr i8, ptr %102, i64 %106
  call void @llvm.masked.store.v8f32.p0(<8 x float> %buffer.contiguous.load, ptr %private.contiguous.address, i32 4, <8 x i1> %51)
  %.state34 = load i64, ptr %.slot, align 4
  %107 = add i64 %.state34, 1
  store i64 %107, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  %tile_snapshot.spill.load35 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 0
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 1
  %110 = add <8 x i64> %109, zeroinitializer
  %111 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %108, 0
  %112 = insertvalue { <8 x ptr>, <8 x i64> } %111, <8 x i64> %110, 1
  %113 = extractvalue { <8 x ptr>, <8 x i64> } %112, 0
  %114 = extractvalue { <8 x ptr>, <8 x i64> } %112, 1
  %115 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %116 = bitcast <8 x i1> %51 to i8
  %117 = call i8 @llvm.cttz.i8(i8 %116, i1 false)
  %118 = zext i8 %117 to i32
  %119 = select i1 %115, i32 %118, i32 0
  %120 = select <8 x i1> %51, <8 x ptr> %113, <8 x ptr> zeroinitializer
  %121 = select <8 x i1> %51, <8 x i64> %114, <8 x i64> zeroinitializer
  %122 = extractelement <8 x ptr> %120, i32 %119
  %123 = extractelement <8 x i64> %121, i32 %119
  %124 = zext i32 %119 to i64
  %125 = mul i64 %124, 4
  %126 = sub i64 %123, %125
  %private.contiguous.address36 = getelementptr i8, ptr %122, i64 %126
  %private.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address36, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %127 = fmul <8 x float> %private.contiguous.load, %private.contiguous.load
  %tile_snapshot.spill.load37 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 0
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 1
  %130 = add <8 x i64> %129, splat (i64 32)
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %128, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %132, 0
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %132, 1
  %135 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %136 = bitcast <8 x i1> %51 to i8
  %137 = call i8 @llvm.cttz.i8(i8 %136, i1 false)
  %138 = zext i8 %137 to i32
  %139 = select i1 %135, i32 %138, i32 0
  %140 = select <8 x i1> %51, <8 x ptr> %133, <8 x ptr> zeroinitializer
  %141 = select <8 x i1> %51, <8 x i64> %134, <8 x i64> zeroinitializer
  %142 = extractelement <8 x ptr> %140, i32 %139
  %143 = extractelement <8 x i64> %141, i32 %139
  %144 = zext i32 %139 to i64
  %145 = mul i64 %144, 4
  %146 = sub i64 %143, %145
  %private.contiguous.address38 = getelementptr i8, ptr %142, i64 %146
  %private.contiguous.load39 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address38, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %147 = fmul <8 x float> %private.contiguous.load39, %private.contiguous.load39
  %tile_snapshot.spill.load40 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load40, 0
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load40, 1
  %150 = add <8 x i64> %149, splat (i64 64)
  %151 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %148, 0
  %152 = insertvalue { <8 x ptr>, <8 x i64> } %151, <8 x i64> %150, 1
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %152, 0
  %154 = extractvalue { <8 x ptr>, <8 x i64> } %152, 1
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %156 = bitcast <8 x i1> %51 to i8
  %157 = call i8 @llvm.cttz.i8(i8 %156, i1 false)
  %158 = zext i8 %157 to i32
  %159 = select i1 %155, i32 %158, i32 0
  %160 = select <8 x i1> %51, <8 x ptr> %153, <8 x ptr> zeroinitializer
  %161 = select <8 x i1> %51, <8 x i64> %154, <8 x i64> zeroinitializer
  %162 = extractelement <8 x ptr> %160, i32 %159
  %163 = extractelement <8 x i64> %161, i32 %159
  %164 = zext i32 %159 to i64
  %165 = mul i64 %164, 4
  %166 = sub i64 %163, %165
  %private.contiguous.address41 = getelementptr i8, ptr %162, i64 %166
  %private.contiguous.load42 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address41, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %167 = fmul <8 x float> %private.contiguous.load42, %private.contiguous.load42
  %tile_snapshot.spill.load43 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 0
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 1
  %170 = add <8 x i64> %169, splat (i64 96)
  %171 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %172 = insertvalue { <8 x ptr>, <8 x i64> } %171, <8 x i64> %170, 1
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %172, 0
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %172, 1
  %175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %176 = bitcast <8 x i1> %51 to i8
  %177 = call i8 @llvm.cttz.i8(i8 %176, i1 false)
  %178 = zext i8 %177 to i32
  %179 = select i1 %175, i32 %178, i32 0
  %180 = select <8 x i1> %51, <8 x ptr> %173, <8 x ptr> zeroinitializer
  %181 = select <8 x i1> %51, <8 x i64> %174, <8 x i64> zeroinitializer
  %182 = extractelement <8 x ptr> %180, i32 %179
  %183 = extractelement <8 x i64> %181, i32 %179
  %184 = zext i32 %179 to i64
  %185 = mul i64 %184, 4
  %186 = sub i64 %183, %185
  %private.contiguous.address44 = getelementptr i8, ptr %182, i64 %186
  %private.contiguous.load45 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address44, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %187 = fmul <8 x float> %private.contiguous.load45, %private.contiguous.load45
  store i64 4, ptr %.slot7, align 4
  %188 = load <8 x float>, ptr %.slot8, align 32
  %189 = select <8 x i1> %51, <8 x float> %127, <8 x float> %188
  store <8 x float> %189, ptr %.slot8, align 32
  %190 = load <8 x float>, ptr %.slot9, align 32
  %191 = select <8 x i1> %51, <8 x float> %147, <8 x float> %190
  store <8 x float> %191, ptr %.slot9, align 32
  %192 = load <8 x float>, ptr %.slot10, align 32
  %193 = select <8 x i1> %51, <8 x float> %167, <8 x float> %192
  store <8 x float> %193, ptr %.slot10, align 32
  %194 = load <8 x float>, ptr %.slot11, align 32
  %195 = select <8 x i1> %51, <8 x float> %187, <8 x float> %194
  store <8 x float> %195, ptr %.slot11, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state46 = load i64, ptr %.slot7, align 4
  %196 = icmp slt i64 %.state46, 512
  br i1 %196, label %direct.true47, label %direct.false48

direct.schedule.5:                                ; preds = %direct.true47
  %.state49 = load i64, ptr %.slot7, align 4
  %197 = add i64 %.state49, 0
  %tile_snapshot.spill.load50 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load50, 0
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load50, 1
  %.splatinsert51 = insertelement <8 x i64> poison, i64 %197, i64 0
  %.splat52 = shufflevector <8 x i64> %.splatinsert51, <8 x i64> poison, <8 x i32> zeroinitializer
  %200 = mul <8 x i64> %.splat52, splat (i64 32)
  %201 = add <8 x i64> %199, %200
  %202 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %198, 0
  %203 = insertvalue { <8 x ptr>, <8 x i64> } %202, <8 x i64> %201, 1
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %203, 0
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %203, 1
  %206 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %207 = bitcast <8 x i1> %51 to i8
  %208 = call i8 @llvm.cttz.i8(i8 %207, i1 false)
  %209 = zext i8 %208 to i32
  %210 = select i1 %206, i32 %209, i32 0
  %211 = select <8 x i1> %51, <8 x ptr> %204, <8 x ptr> zeroinitializer
  %212 = select <8 x i1> %51, <8 x i64> %205, <8 x i64> zeroinitializer
  %213 = extractelement <8 x ptr> %211, i32 %210
  %214 = extractelement <8 x i64> %212, i32 %210
  %215 = zext i32 %210 to i64
  %216 = mul i64 %215, 4
  %217 = sub i64 %214, %216
  %private.contiguous.address53 = getelementptr i8, ptr %213, i64 %217
  %private.contiguous.load54 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address53, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %218 = fmul <8 x float> %private.contiguous.load54, %private.contiguous.load54
  %.state55 = load <8 x float>, ptr %.slot8, align 32
  %219 = fadd <8 x float> %.state55, %218
  %.state56 = load i64, ptr %.slot7, align 4
  %220 = add i64 %.state56, 1
  %tile_snapshot.spill.load57 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 0
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load57, 1
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %220, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %223 = mul <8 x i64> %.splat59, splat (i64 32)
  %224 = add <8 x i64> %222, %223
  %225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %221, 0
  %226 = insertvalue { <8 x ptr>, <8 x i64> } %225, <8 x i64> %224, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %226, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %226, 1
  %229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %230 = bitcast <8 x i1> %51 to i8
  %231 = call i8 @llvm.cttz.i8(i8 %230, i1 false)
  %232 = zext i8 %231 to i32
  %233 = select i1 %229, i32 %232, i32 0
  %234 = select <8 x i1> %51, <8 x ptr> %227, <8 x ptr> zeroinitializer
  %235 = select <8 x i1> %51, <8 x i64> %228, <8 x i64> zeroinitializer
  %236 = extractelement <8 x ptr> %234, i32 %233
  %237 = extractelement <8 x i64> %235, i32 %233
  %238 = zext i32 %233 to i64
  %239 = mul i64 %238, 4
  %240 = sub i64 %237, %239
  %private.contiguous.address60 = getelementptr i8, ptr %236, i64 %240
  %private.contiguous.load61 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address60, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %241 = fmul <8 x float> %private.contiguous.load61, %private.contiguous.load61
  %.state62 = load <8 x float>, ptr %.slot9, align 32
  %242 = fadd <8 x float> %.state62, %241
  %.state63 = load i64, ptr %.slot7, align 4
  %243 = add i64 %.state63, 2
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %245 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %.splatinsert65 = insertelement <8 x i64> poison, i64 %243, i64 0
  %.splat66 = shufflevector <8 x i64> %.splatinsert65, <8 x i64> poison, <8 x i32> zeroinitializer
  %246 = mul <8 x i64> %.splat66, splat (i64 32)
  %247 = add <8 x i64> %245, %246
  %248 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %244, 0
  %249 = insertvalue { <8 x ptr>, <8 x i64> } %248, <8 x i64> %247, 1
  %250 = extractvalue { <8 x ptr>, <8 x i64> } %249, 0
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %249, 1
  %252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %253 = bitcast <8 x i1> %51 to i8
  %254 = call i8 @llvm.cttz.i8(i8 %253, i1 false)
  %255 = zext i8 %254 to i32
  %256 = select i1 %252, i32 %255, i32 0
  %257 = select <8 x i1> %51, <8 x ptr> %250, <8 x ptr> zeroinitializer
  %258 = select <8 x i1> %51, <8 x i64> %251, <8 x i64> zeroinitializer
  %259 = extractelement <8 x ptr> %257, i32 %256
  %260 = extractelement <8 x i64> %258, i32 %256
  %261 = zext i32 %256 to i64
  %262 = mul i64 %261, 4
  %263 = sub i64 %260, %262
  %private.contiguous.address67 = getelementptr i8, ptr %259, i64 %263
  %private.contiguous.load68 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address67, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %264 = fmul <8 x float> %private.contiguous.load68, %private.contiguous.load68
  %.state69 = load <8 x float>, ptr %.slot10, align 32
  %265 = fadd <8 x float> %.state69, %264
  %.state70 = load i64, ptr %.slot7, align 4
  %266 = add i64 %.state70, 3
  %tile_snapshot.spill.load71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load71, 1
  %.splatinsert72 = insertelement <8 x i64> poison, i64 %266, i64 0
  %.splat73 = shufflevector <8 x i64> %.splatinsert72, <8 x i64> poison, <8 x i32> zeroinitializer
  %269 = mul <8 x i64> %.splat73, splat (i64 32)
  %270 = add <8 x i64> %268, %269
  %271 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %267, 0
  %272 = insertvalue { <8 x ptr>, <8 x i64> } %271, <8 x i64> %270, 1
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %272, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %272, 1
  %275 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %276 = bitcast <8 x i1> %51 to i8
  %277 = call i8 @llvm.cttz.i8(i8 %276, i1 false)
  %278 = zext i8 %277 to i32
  %279 = select i1 %275, i32 %278, i32 0
  %280 = select <8 x i1> %51, <8 x ptr> %273, <8 x ptr> zeroinitializer
  %281 = select <8 x i1> %51, <8 x i64> %274, <8 x i64> zeroinitializer
  %282 = extractelement <8 x ptr> %280, i32 %279
  %283 = extractelement <8 x i64> %281, i32 %279
  %284 = zext i32 %279 to i64
  %285 = mul i64 %284, 4
  %286 = sub i64 %283, %285
  %private.contiguous.address74 = getelementptr i8, ptr %282, i64 %286
  %private.contiguous.load75 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address74, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %287 = fmul <8 x float> %private.contiguous.load75, %private.contiguous.load75
  %.state76 = load <8 x float>, ptr %.slot11, align 32
  %288 = fadd <8 x float> %.state76, %287
  %.state77 = load i64, ptr %.slot7, align 4
  %289 = add i64 %.state77, 4
  store i64 %289, ptr %.slot7, align 4
  %290 = load <8 x float>, ptr %.slot8, align 32
  %291 = select <8 x i1> %51, <8 x float> %219, <8 x float> %290
  store <8 x float> %291, ptr %.slot8, align 32
  %292 = load <8 x float>, ptr %.slot9, align 32
  %293 = select <8 x i1> %51, <8 x float> %242, <8 x float> %292
  store <8 x float> %293, ptr %.slot9, align 32
  %294 = load <8 x float>, ptr %.slot10, align 32
  %295 = select <8 x i1> %51, <8 x float> %265, <8 x float> %294
  store <8 x float> %295, ptr %.slot10, align 32
  %296 = load <8 x float>, ptr %.slot11, align 32
  %297 = select <8 x i1> %51, <8 x float> %288, <8 x float> %296
  store <8 x float> %297, ptr %.slot11, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false48
  %.state78 = load <8 x float>, ptr %.slot8, align 32
  %.state79 = load <8 x float>, ptr %.slot9, align 32
  %298 = fadd <8 x float> %.state78, %.state79
  %.state80 = load <8 x float>, ptr %.slot10, align 32
  %299 = fadd <8 x float> %298, %.state80
  %.state81 = load <8 x float>, ptr %.slot11, align 32
  %300 = fadd <8 x float> %299, %.state81
  %.spill.load82 = load <8 x i64>, ptr %.spill, align 64
  %301 = trunc <8 x i64> %.spill.load82 to <8 x i32>
  %302 = xor <8 x i32> %301, splat (i32 1)
  %303 = extractelement <8 x i32> %302, i64 0
  %304 = icmp ult i32 %303, 8
  %305 = select i1 %304, i32 %303, i32 0
  %306 = extractelement <8 x i1> %51, i32 %305
  %307 = extractelement <8 x i1> %51, i64 0
  %308 = and i1 %304, %306
  %309 = and i1 %307, %308
  %310 = extractelement <8 x float> %300, i32 %305
  %311 = select i1 %309, float %310, float 0.000000e+00
  %312 = insertelement <8 x float> poison, float %311, i64 0
  %313 = xor i1 %309, true
  %314 = and i1 %307, %313
  %315 = insertelement <8 x i1> poison, i1 %314, i64 0
  %316 = extractelement <8 x i32> %302, i64 1
  %317 = icmp ult i32 %316, 8
  %318 = select i1 %317, i32 %316, i32 0
  %319 = extractelement <8 x i1> %51, i32 %318
  %320 = extractelement <8 x i1> %51, i64 1
  %321 = and i1 %317, %319
  %322 = and i1 %320, %321
  %323 = extractelement <8 x float> %300, i32 %318
  %324 = select i1 %322, float %323, float 0.000000e+00
  %325 = insertelement <8 x float> %312, float %324, i64 1
  %326 = xor i1 %322, true
  %327 = and i1 %320, %326
  %328 = insertelement <8 x i1> %315, i1 %327, i64 1
  %329 = extractelement <8 x i32> %302, i64 2
  %330 = icmp ult i32 %329, 8
  %331 = select i1 %330, i32 %329, i32 0
  %332 = extractelement <8 x i1> %51, i32 %331
  %333 = extractelement <8 x i1> %51, i64 2
  %334 = and i1 %330, %332
  %335 = and i1 %333, %334
  %336 = extractelement <8 x float> %300, i32 %331
  %337 = select i1 %335, float %336, float 0.000000e+00
  %338 = insertelement <8 x float> %325, float %337, i64 2
  %339 = xor i1 %335, true
  %340 = and i1 %333, %339
  %341 = insertelement <8 x i1> %328, i1 %340, i64 2
  %342 = extractelement <8 x i32> %302, i64 3
  %343 = icmp ult i32 %342, 8
  %344 = select i1 %343, i32 %342, i32 0
  %345 = extractelement <8 x i1> %51, i32 %344
  %346 = extractelement <8 x i1> %51, i64 3
  %347 = and i1 %343, %345
  %348 = and i1 %346, %347
  %349 = extractelement <8 x float> %300, i32 %344
  %350 = select i1 %348, float %349, float 0.000000e+00
  %351 = insertelement <8 x float> %338, float %350, i64 3
  %352 = xor i1 %348, true
  %353 = and i1 %346, %352
  %354 = insertelement <8 x i1> %341, i1 %353, i64 3
  %355 = extractelement <8 x i32> %302, i64 4
  %356 = icmp ult i32 %355, 8
  %357 = select i1 %356, i32 %355, i32 0
  %358 = extractelement <8 x i1> %51, i32 %357
  %359 = extractelement <8 x i1> %51, i64 4
  %360 = and i1 %356, %358
  %361 = and i1 %359, %360
  %362 = extractelement <8 x float> %300, i32 %357
  %363 = select i1 %361, float %362, float 0.000000e+00
  %364 = insertelement <8 x float> %351, float %363, i64 4
  %365 = xor i1 %361, true
  %366 = and i1 %359, %365
  %367 = insertelement <8 x i1> %354, i1 %366, i64 4
  %368 = extractelement <8 x i32> %302, i64 5
  %369 = icmp ult i32 %368, 8
  %370 = select i1 %369, i32 %368, i32 0
  %371 = extractelement <8 x i1> %51, i32 %370
  %372 = extractelement <8 x i1> %51, i64 5
  %373 = and i1 %369, %371
  %374 = and i1 %372, %373
  %375 = extractelement <8 x float> %300, i32 %370
  %376 = select i1 %374, float %375, float 0.000000e+00
  %377 = insertelement <8 x float> %364, float %376, i64 5
  %378 = xor i1 %374, true
  %379 = and i1 %372, %378
  %380 = insertelement <8 x i1> %367, i1 %379, i64 5
  %381 = extractelement <8 x i32> %302, i64 6
  %382 = icmp ult i32 %381, 8
  %383 = select i1 %382, i32 %381, i32 0
  %384 = extractelement <8 x i1> %51, i32 %383
  %385 = extractelement <8 x i1> %51, i64 6
  %386 = and i1 %382, %384
  %387 = and i1 %385, %386
  %388 = extractelement <8 x float> %300, i32 %383
  %389 = select i1 %387, float %388, float 0.000000e+00
  %390 = insertelement <8 x float> %377, float %389, i64 6
  %391 = xor i1 %387, true
  %392 = and i1 %385, %391
  %393 = insertelement <8 x i1> %380, i1 %392, i64 6
  %394 = extractelement <8 x i32> %302, i64 7
  %395 = icmp ult i32 %394, 8
  %396 = select i1 %395, i32 %394, i32 0
  %397 = extractelement <8 x i1> %51, i32 %396
  %398 = extractelement <8 x i1> %51, i64 7
  %399 = and i1 %395, %397
  %400 = and i1 %398, %399
  %401 = extractelement <8 x float> %300, i32 %396
  %402 = select i1 %400, float %401, float 0.000000e+00
  %403 = insertelement <8 x float> %390, float %402, i64 7
  %404 = xor i1 %400, true
  %405 = and i1 %398, %404
  %406 = insertelement <8 x i1> %393, i1 %405, i64 7
  %407 = fadd <8 x float> %300, %403
  %408 = xor <8 x i32> %301, splat (i32 2)
  %409 = extractelement <8 x i32> %408, i64 0
  %410 = icmp ult i32 %409, 8
  %411 = select i1 %410, i32 %409, i32 0
  %412 = extractelement <8 x i1> %51, i32 %411
  %413 = extractelement <8 x i1> %51, i64 0
  %414 = and i1 %410, %412
  %415 = and i1 %413, %414
  %416 = extractelement <8 x float> %407, i32 %411
  %417 = select i1 %415, float %416, float 0.000000e+00
  %418 = insertelement <8 x float> poison, float %417, i64 0
  %419 = xor i1 %415, true
  %420 = and i1 %413, %419
  %421 = insertelement <8 x i1> poison, i1 %420, i64 0
  %422 = extractelement <8 x i32> %408, i64 1
  %423 = icmp ult i32 %422, 8
  %424 = select i1 %423, i32 %422, i32 0
  %425 = extractelement <8 x i1> %51, i32 %424
  %426 = extractelement <8 x i1> %51, i64 1
  %427 = and i1 %423, %425
  %428 = and i1 %426, %427
  %429 = extractelement <8 x float> %407, i32 %424
  %430 = select i1 %428, float %429, float 0.000000e+00
  %431 = insertelement <8 x float> %418, float %430, i64 1
  %432 = xor i1 %428, true
  %433 = and i1 %426, %432
  %434 = insertelement <8 x i1> %421, i1 %433, i64 1
  %435 = extractelement <8 x i32> %408, i64 2
  %436 = icmp ult i32 %435, 8
  %437 = select i1 %436, i32 %435, i32 0
  %438 = extractelement <8 x i1> %51, i32 %437
  %439 = extractelement <8 x i1> %51, i64 2
  %440 = and i1 %436, %438
  %441 = and i1 %439, %440
  %442 = extractelement <8 x float> %407, i32 %437
  %443 = select i1 %441, float %442, float 0.000000e+00
  %444 = insertelement <8 x float> %431, float %443, i64 2
  %445 = xor i1 %441, true
  %446 = and i1 %439, %445
  %447 = insertelement <8 x i1> %434, i1 %446, i64 2
  %448 = extractelement <8 x i32> %408, i64 3
  %449 = icmp ult i32 %448, 8
  %450 = select i1 %449, i32 %448, i32 0
  %451 = extractelement <8 x i1> %51, i32 %450
  %452 = extractelement <8 x i1> %51, i64 3
  %453 = and i1 %449, %451
  %454 = and i1 %452, %453
  %455 = extractelement <8 x float> %407, i32 %450
  %456 = select i1 %454, float %455, float 0.000000e+00
  %457 = insertelement <8 x float> %444, float %456, i64 3
  %458 = xor i1 %454, true
  %459 = and i1 %452, %458
  %460 = insertelement <8 x i1> %447, i1 %459, i64 3
  %461 = extractelement <8 x i32> %408, i64 4
  %462 = icmp ult i32 %461, 8
  %463 = select i1 %462, i32 %461, i32 0
  %464 = extractelement <8 x i1> %51, i32 %463
  %465 = extractelement <8 x i1> %51, i64 4
  %466 = and i1 %462, %464
  %467 = and i1 %465, %466
  %468 = extractelement <8 x float> %407, i32 %463
  %469 = select i1 %467, float %468, float 0.000000e+00
  %470 = insertelement <8 x float> %457, float %469, i64 4
  %471 = xor i1 %467, true
  %472 = and i1 %465, %471
  %473 = insertelement <8 x i1> %460, i1 %472, i64 4
  %474 = extractelement <8 x i32> %408, i64 5
  %475 = icmp ult i32 %474, 8
  %476 = select i1 %475, i32 %474, i32 0
  %477 = extractelement <8 x i1> %51, i32 %476
  %478 = extractelement <8 x i1> %51, i64 5
  %479 = and i1 %475, %477
  %480 = and i1 %478, %479
  %481 = extractelement <8 x float> %407, i32 %476
  %482 = select i1 %480, float %481, float 0.000000e+00
  %483 = insertelement <8 x float> %470, float %482, i64 5
  %484 = xor i1 %480, true
  %485 = and i1 %478, %484
  %486 = insertelement <8 x i1> %473, i1 %485, i64 5
  %487 = extractelement <8 x i32> %408, i64 6
  %488 = icmp ult i32 %487, 8
  %489 = select i1 %488, i32 %487, i32 0
  %490 = extractelement <8 x i1> %51, i32 %489
  %491 = extractelement <8 x i1> %51, i64 6
  %492 = and i1 %488, %490
  %493 = and i1 %491, %492
  %494 = extractelement <8 x float> %407, i32 %489
  %495 = select i1 %493, float %494, float 0.000000e+00
  %496 = insertelement <8 x float> %483, float %495, i64 6
  %497 = xor i1 %493, true
  %498 = and i1 %491, %497
  %499 = insertelement <8 x i1> %486, i1 %498, i64 6
  %500 = extractelement <8 x i32> %408, i64 7
  %501 = icmp ult i32 %500, 8
  %502 = select i1 %501, i32 %500, i32 0
  %503 = extractelement <8 x i1> %51, i32 %502
  %504 = extractelement <8 x i1> %51, i64 7
  %505 = and i1 %501, %503
  %506 = and i1 %504, %505
  %507 = extractelement <8 x float> %407, i32 %502
  %508 = select i1 %506, float %507, float 0.000000e+00
  %509 = insertelement <8 x float> %496, float %508, i64 7
  %510 = xor i1 %506, true
  %511 = and i1 %504, %510
  %512 = insertelement <8 x i1> %499, i1 %511, i64 7
  %513 = fadd <8 x float> %407, %509
  %514 = xor <8 x i32> %301, splat (i32 4)
  %515 = extractelement <8 x i32> %514, i64 0
  %516 = icmp ult i32 %515, 8
  %517 = select i1 %516, i32 %515, i32 0
  %518 = extractelement <8 x i1> %51, i32 %517
  %519 = extractelement <8 x i1> %51, i64 0
  %520 = and i1 %516, %518
  %521 = and i1 %519, %520
  %522 = extractelement <8 x float> %513, i32 %517
  %523 = select i1 %521, float %522, float 0.000000e+00
  %524 = insertelement <8 x float> poison, float %523, i64 0
  %525 = xor i1 %521, true
  %526 = and i1 %519, %525
  %527 = insertelement <8 x i1> poison, i1 %526, i64 0
  %528 = extractelement <8 x i32> %514, i64 1
  %529 = icmp ult i32 %528, 8
  %530 = select i1 %529, i32 %528, i32 0
  %531 = extractelement <8 x i1> %51, i32 %530
  %532 = extractelement <8 x i1> %51, i64 1
  %533 = and i1 %529, %531
  %534 = and i1 %532, %533
  %535 = extractelement <8 x float> %513, i32 %530
  %536 = select i1 %534, float %535, float 0.000000e+00
  %537 = insertelement <8 x float> %524, float %536, i64 1
  %538 = xor i1 %534, true
  %539 = and i1 %532, %538
  %540 = insertelement <8 x i1> %527, i1 %539, i64 1
  %541 = extractelement <8 x i32> %514, i64 2
  %542 = icmp ult i32 %541, 8
  %543 = select i1 %542, i32 %541, i32 0
  %544 = extractelement <8 x i1> %51, i32 %543
  %545 = extractelement <8 x i1> %51, i64 2
  %546 = and i1 %542, %544
  %547 = and i1 %545, %546
  %548 = extractelement <8 x float> %513, i32 %543
  %549 = select i1 %547, float %548, float 0.000000e+00
  %550 = insertelement <8 x float> %537, float %549, i64 2
  %551 = xor i1 %547, true
  %552 = and i1 %545, %551
  %553 = insertelement <8 x i1> %540, i1 %552, i64 2
  %554 = extractelement <8 x i32> %514, i64 3
  %555 = icmp ult i32 %554, 8
  %556 = select i1 %555, i32 %554, i32 0
  %557 = extractelement <8 x i1> %51, i32 %556
  %558 = extractelement <8 x i1> %51, i64 3
  %559 = and i1 %555, %557
  %560 = and i1 %558, %559
  %561 = extractelement <8 x float> %513, i32 %556
  %562 = select i1 %560, float %561, float 0.000000e+00
  %563 = insertelement <8 x float> %550, float %562, i64 3
  %564 = xor i1 %560, true
  %565 = and i1 %558, %564
  %566 = insertelement <8 x i1> %553, i1 %565, i64 3
  %567 = extractelement <8 x i32> %514, i64 4
  %568 = icmp ult i32 %567, 8
  %569 = select i1 %568, i32 %567, i32 0
  %570 = extractelement <8 x i1> %51, i32 %569
  %571 = extractelement <8 x i1> %51, i64 4
  %572 = and i1 %568, %570
  %573 = and i1 %571, %572
  %574 = extractelement <8 x float> %513, i32 %569
  %575 = select i1 %573, float %574, float 0.000000e+00
  %576 = insertelement <8 x float> %563, float %575, i64 4
  %577 = xor i1 %573, true
  %578 = and i1 %571, %577
  %579 = insertelement <8 x i1> %566, i1 %578, i64 4
  %580 = extractelement <8 x i32> %514, i64 5
  %581 = icmp ult i32 %580, 8
  %582 = select i1 %581, i32 %580, i32 0
  %583 = extractelement <8 x i1> %51, i32 %582
  %584 = extractelement <8 x i1> %51, i64 5
  %585 = and i1 %581, %583
  %586 = and i1 %584, %585
  %587 = extractelement <8 x float> %513, i32 %582
  %588 = select i1 %586, float %587, float 0.000000e+00
  %589 = insertelement <8 x float> %576, float %588, i64 5
  %590 = xor i1 %586, true
  %591 = and i1 %584, %590
  %592 = insertelement <8 x i1> %579, i1 %591, i64 5
  %593 = extractelement <8 x i32> %514, i64 6
  %594 = icmp ult i32 %593, 8
  %595 = select i1 %594, i32 %593, i32 0
  %596 = extractelement <8 x i1> %51, i32 %595
  %597 = extractelement <8 x i1> %51, i64 6
  %598 = and i1 %594, %596
  %599 = and i1 %597, %598
  %600 = extractelement <8 x float> %513, i32 %595
  %601 = select i1 %599, float %600, float 0.000000e+00
  %602 = insertelement <8 x float> %589, float %601, i64 6
  %603 = xor i1 %599, true
  %604 = and i1 %597, %603
  %605 = insertelement <8 x i1> %592, i1 %604, i64 6
  %606 = extractelement <8 x i32> %514, i64 7
  %607 = icmp ult i32 %606, 8
  %608 = select i1 %607, i32 %606, i32 0
  %609 = extractelement <8 x i1> %51, i32 %608
  %610 = extractelement <8 x i1> %51, i64 7
  %611 = and i1 %607, %609
  %612 = and i1 %610, %611
  %613 = extractelement <8 x float> %513, i32 %608
  %614 = select i1 %612, float %613, float 0.000000e+00
  %615 = insertelement <8 x float> %602, float %614, i64 7
  %616 = xor i1 %612, true
  %617 = and i1 %610, %616
  %618 = insertelement <8 x i1> %605, i1 %617, i64 7
  %619 = fadd <8 x float> %513, %615
  %620 = extractelement <8 x i1> %51, i32 0
  %621 = extractelement <8 x i1> %51, i64 0
  %622 = and i1 true, %620
  %623 = and i1 %621, %622
  %624 = extractelement <8 x float> %619, i32 0
  %625 = select i1 %623, float %624, float 0.000000e+00
  %626 = insertelement <8 x float> poison, float %625, i64 0
  %627 = xor i1 %623, true
  %628 = and i1 %621, %627
  %629 = insertelement <8 x i1> poison, i1 %628, i64 0
  %630 = extractelement <8 x i1> %51, i32 0
  %631 = extractelement <8 x i1> %51, i64 1
  %632 = and i1 true, %630
  %633 = and i1 %631, %632
  %634 = extractelement <8 x float> %619, i32 0
  %635 = select i1 %633, float %634, float 0.000000e+00
  %636 = insertelement <8 x float> %626, float %635, i64 1
  %637 = xor i1 %633, true
  %638 = and i1 %631, %637
  %639 = insertelement <8 x i1> %629, i1 %638, i64 1
  %640 = extractelement <8 x i1> %51, i32 0
  %641 = extractelement <8 x i1> %51, i64 2
  %642 = and i1 true, %640
  %643 = and i1 %641, %642
  %644 = extractelement <8 x float> %619, i32 0
  %645 = select i1 %643, float %644, float 0.000000e+00
  %646 = insertelement <8 x float> %636, float %645, i64 2
  %647 = xor i1 %643, true
  %648 = and i1 %641, %647
  %649 = insertelement <8 x i1> %639, i1 %648, i64 2
  %650 = extractelement <8 x i1> %51, i32 0
  %651 = extractelement <8 x i1> %51, i64 3
  %652 = and i1 true, %650
  %653 = and i1 %651, %652
  %654 = extractelement <8 x float> %619, i32 0
  %655 = select i1 %653, float %654, float 0.000000e+00
  %656 = insertelement <8 x float> %646, float %655, i64 3
  %657 = xor i1 %653, true
  %658 = and i1 %651, %657
  %659 = insertelement <8 x i1> %649, i1 %658, i64 3
  %660 = extractelement <8 x i1> %51, i32 0
  %661 = extractelement <8 x i1> %51, i64 4
  %662 = and i1 true, %660
  %663 = and i1 %661, %662
  %664 = extractelement <8 x float> %619, i32 0
  %665 = select i1 %663, float %664, float 0.000000e+00
  %666 = insertelement <8 x float> %656, float %665, i64 4
  %667 = xor i1 %663, true
  %668 = and i1 %661, %667
  %669 = insertelement <8 x i1> %659, i1 %668, i64 4
  %670 = extractelement <8 x i1> %51, i32 0
  %671 = extractelement <8 x i1> %51, i64 5
  %672 = and i1 true, %670
  %673 = and i1 %671, %672
  %674 = extractelement <8 x float> %619, i32 0
  %675 = select i1 %673, float %674, float 0.000000e+00
  %676 = insertelement <8 x float> %666, float %675, i64 5
  %677 = xor i1 %673, true
  %678 = and i1 %671, %677
  %679 = insertelement <8 x i1> %669, i1 %678, i64 5
  %680 = extractelement <8 x i1> %51, i32 0
  %681 = extractelement <8 x i1> %51, i64 6
  %682 = and i1 true, %680
  %683 = and i1 %681, %682
  %684 = extractelement <8 x float> %619, i32 0
  %685 = select i1 %683, float %684, float 0.000000e+00
  %686 = insertelement <8 x float> %676, float %685, i64 6
  %687 = xor i1 %683, true
  %688 = and i1 %681, %687
  %689 = insertelement <8 x i1> %679, i1 %688, i64 6
  %690 = extractelement <8 x i1> %51, i32 0
  %691 = extractelement <8 x i1> %51, i64 7
  %692 = and i1 true, %690
  %693 = and i1 %691, %692
  %694 = extractelement <8 x float> %619, i32 0
  %695 = select i1 %693, float %694, float 0.000000e+00
  %696 = insertelement <8 x float> %686, float %695, i64 7
  %697 = xor i1 %693, true
  %698 = and i1 %691, %697
  %699 = insertelement <8 x i1> %689, i1 %698, i64 7
  %700 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %701 = bitcast <8 x i1> %51 to i8
  %702 = call i8 @llvm.cttz.i8(i8 %701, i1 false)
  %703 = zext i8 %702 to i32
  %704 = select i1 %700, i32 %703, i32 0
  %705 = extractelement <8 x float> %696, i32 %704
  %.spill.load83 = load float, ptr %.spill5, align 4
  %706 = fadd float %.spill.load83, %705
  %707 = fdiv float %706, 4.096000e+03
  store float %707, ptr %.spill12, align 4
  %708 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %709 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %710 = extractvalue { <8 x ptr>, <8 x i64> } %708, 0
  %711 = select <8 x i1> %51, <8 x ptr> %709, <8 x ptr> %710
  %712 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %713 = extractvalue { <8 x ptr>, <8 x i64> } %708, 1
  %714 = select <8 x i1> %51, <8 x i64> %712, <8 x i64> %713
  %715 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %711, 0
  %716 = insertvalue { <8 x ptr>, <8 x i64> } %715, <8 x i64> %714, 1
  store { <8 x ptr>, <8 x i64> } %716, ptr %tile_snapshot.spill13, align 64
  store i64 0, ptr %.slot14, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state84 = load i64, ptr %.slot14, align 4
  %717 = icmp slt i64 %.state84, 512
  br i1 %717, label %direct.true85, label %direct.false86

direct.schedule.8:                                ; preds = %direct.true85
  %.state87 = load i64, ptr %.slot14, align 4
  %718 = mul i64 %.state87, 8
  %.splatinsert88 = insertelement <8 x i64> poison, i64 %718, i64 0
  %.splat89 = shufflevector <8 x i64> %.splatinsert88, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load90 = load <8 x i64>, ptr %.spill, align 64
  %719 = add <8 x i64> %.splat89, %.spill.load90
  %.spill.load91 = load i64, ptr %.spill6, align 4
  %720 = add i64 %.spill.load91, 0
  %721 = add <8 x i64> zeroinitializer, %719
  %722 = mul i64 %720, 4096
  %.splatinsert92 = insertelement <8 x i64> poison, i64 %722, i64 0
  %.splat93 = shufflevector <8 x i64> %.splatinsert92, <8 x i64> poison, <8 x i32> zeroinitializer
  %723 = add <8 x i64> %.splat93, %721
  %724 = extractvalue { ptr, i64 } %15, 0
  %725 = extractelement <8 x i64> %723, i32 0
  %726 = sub i64 %725, 0
  %727 = mul i64 %726, 4
  %buffer.contiguous.address94 = getelementptr i8, ptr %724, i64 %727
  %buffer.contiguous.load95 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address94, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 0
  %729 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 1
  %.state97 = load i64, ptr %.slot14, align 4
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %.state97, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %730 = mul <8 x i64> %.splat99, splat (i64 32)
  %731 = add <8 x i64> %729, %730
  %732 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %728, 0
  %733 = insertvalue { <8 x ptr>, <8 x i64> } %732, <8 x i64> %731, 1
  %734 = extractvalue { <8 x ptr>, <8 x i64> } %733, 0
  %735 = extractvalue { <8 x ptr>, <8 x i64> } %733, 1
  %736 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %737 = bitcast <8 x i1> %51 to i8
  %738 = call i8 @llvm.cttz.i8(i8 %737, i1 false)
  %739 = zext i8 %738 to i32
  %740 = select i1 %736, i32 %739, i32 0
  %741 = select <8 x i1> %51, <8 x ptr> %734, <8 x ptr> zeroinitializer
  %742 = select <8 x i1> %51, <8 x i64> %735, <8 x i64> zeroinitializer
  %743 = extractelement <8 x ptr> %741, i32 %740
  %744 = extractelement <8 x i64> %742, i32 %740
  %745 = zext i32 %740 to i64
  %746 = mul i64 %745, 4
  %747 = sub i64 %744, %746
  %private.contiguous.address100 = getelementptr i8, ptr %743, i64 %747
  call void @llvm.masked.store.v8f32.p0(<8 x float> %buffer.contiguous.load95, ptr %private.contiguous.address100, i32 4, <8 x i1> %51)
  %.state101 = load i64, ptr %.slot14, align 4
  %748 = add i64 %.state101, 1
  store i64 %748, ptr %.slot14, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false86
  %.spill.load102 = load float, ptr %.spill12, align 4
  %749 = fadd float %.spill.load102, 0x3EE4F8B580000000
  %750 = call float @llvm.sqrt.f32(float %749)
  store float %750, ptr %.spill15, align 4
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state103 = load i64, ptr %.slot16, align 4
  %751 = icmp slt i64 %.state103, 512
  br i1 %751, label %direct.true104, label %direct.false105

direct.schedule.11:                               ; preds = %direct.true104
  %.state106 = load i64, ptr %.slot16, align 4
  %752 = mul i64 %.state106, 8
  %.splatinsert107 = insertelement <8 x i64> poison, i64 %752, i64 0
  %.splat108 = shufflevector <8 x i64> %.splatinsert107, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load109 = load <8 x i64>, ptr %.spill, align 64
  %753 = add <8 x i64> %.splat108, %.spill.load109
  %.spill.load110 = load <8 x i64>, ptr %.spill4, align 64
  %754 = add <8 x i64> %.spill.load110, zeroinitializer
  %755 = add <8 x i64> zeroinitializer, %754
  %756 = add <8 x i64> zeroinitializer, %753
  %757 = mul <8 x i64> %755, splat (i64 4096)
  %758 = add <8 x i64> %757, %756
  %tile_snapshot.spill.load111 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 0
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 1
  %.state112 = load i64, ptr %.slot16, align 4
  %.splatinsert113 = insertelement <8 x i64> poison, i64 %.state112, i64 0
  %.splat114 = shufflevector <8 x i64> %.splatinsert113, <8 x i64> poison, <8 x i32> zeroinitializer
  %761 = mul <8 x i64> %.splat114, splat (i64 32)
  %762 = add <8 x i64> %760, %761
  %763 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %759, 0
  %764 = insertvalue { <8 x ptr>, <8 x i64> } %763, <8 x i64> %762, 1
  %765 = extractvalue { <8 x ptr>, <8 x i64> } %764, 0
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %764, 1
  %767 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %768 = bitcast <8 x i1> %51 to i8
  %769 = call i8 @llvm.cttz.i8(i8 %768, i1 false)
  %770 = zext i8 %769 to i32
  %771 = select i1 %767, i32 %770, i32 0
  %772 = select <8 x i1> %51, <8 x ptr> %765, <8 x ptr> zeroinitializer
  %773 = select <8 x i1> %51, <8 x i64> %766, <8 x i64> zeroinitializer
  %774 = extractelement <8 x ptr> %772, i32 %771
  %775 = extractelement <8 x i64> %773, i32 %771
  %776 = zext i32 %771 to i64
  %777 = mul i64 %776, 4
  %778 = sub i64 %775, %777
  %private.contiguous.address115 = getelementptr i8, ptr %774, i64 %778
  %private.contiguous.load116 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address115, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %.spill.load117 = load float, ptr %.spill15, align 4
  %.splatinsert118 = insertelement <8 x float> poison, float %.spill.load117, i64 0
  %.splat119 = shufflevector <8 x float> %.splatinsert118, <8 x float> poison, <8 x i32> zeroinitializer
  %779 = fdiv <8 x float> %private.contiguous.load116, %.splat119
  %tile_snapshot.spill.load120 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %780 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 0
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 1
  %.state121 = load i64, ptr %.slot16, align 4
  %.splatinsert122 = insertelement <8 x i64> poison, i64 %.state121, i64 0
  %.splat123 = shufflevector <8 x i64> %.splatinsert122, <8 x i64> poison, <8 x i32> zeroinitializer
  %782 = mul <8 x i64> %.splat123, splat (i64 32)
  %783 = add <8 x i64> %781, %782
  %784 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %780, 0
  %785 = insertvalue { <8 x ptr>, <8 x i64> } %784, <8 x i64> %783, 1
  %786 = extractvalue { <8 x ptr>, <8 x i64> } %785, 0
  %787 = extractvalue { <8 x ptr>, <8 x i64> } %785, 1
  %788 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %789 = bitcast <8 x i1> %51 to i8
  %790 = call i8 @llvm.cttz.i8(i8 %789, i1 false)
  %791 = zext i8 %790 to i32
  %792 = select i1 %788, i32 %791, i32 0
  %793 = select <8 x i1> %51, <8 x ptr> %786, <8 x ptr> zeroinitializer
  %794 = select <8 x i1> %51, <8 x i64> %787, <8 x i64> zeroinitializer
  %795 = extractelement <8 x ptr> %793, i32 %792
  %796 = extractelement <8 x i64> %794, i32 %792
  %797 = zext i32 %792 to i64
  %798 = mul i64 %797, 4
  %799 = sub i64 %796, %798
  %private.contiguous.address124 = getelementptr i8, ptr %795, i64 %799
  %private.contiguous.load125 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %private.contiguous.address124, i32 4, <8 x i1> %51, <8 x float> zeroinitializer)
  %800 = fmul <8 x float> %779, %private.contiguous.load125
  %801 = extractvalue { ptr, i64 } %27, 0
  %802 = extractelement <8 x i64> %758, i32 0
  %803 = sub i64 %802, 0
  %804 = mul i64 %803, 4
  %buffer.contiguous.address126 = getelementptr i8, ptr %801, i64 %804
  call void @llvm.masked.store.v8f32.p0(<8 x float> %800, ptr %buffer.contiguous.address126, i32 1, <8 x i1> %51)
  %.state127 = load i64, ptr %.slot16, align 4
  %805 = add i64 %.state127, 1
  store i64 %805, ptr %.slot16, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false105
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true47:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false48:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true85:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false86:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true104:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false105:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #0

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 1024
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 1024
  %3 = sub i64 1024, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 128
  %8 = icmp uge i64 %packet.range.remaining, 1024
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  br label %packet.batch.full.loop

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full.loop
  ret void

packet.batch.full.loop:                           ; preds = %packet.batch.full.loop, %packet.batch.full
  %packet.index = phi i32 [ 0, %packet.batch.full ], [ %packet.index.next, %packet.batch.full.loop ]
  %packet.thread.offset = mul i32 %packet.index, 8
  %packet.thread.index = add i32 %base.thread.index, %packet.thread.offset
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.index.next = add i32 %packet.index, 1
  %packet.batch.has.more = icmp ult i32 %packet.index.next, %packet_count
  br i1 %packet.batch.has.more, label %packet.batch.full.loop, label %packet.batch.exit

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 128)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

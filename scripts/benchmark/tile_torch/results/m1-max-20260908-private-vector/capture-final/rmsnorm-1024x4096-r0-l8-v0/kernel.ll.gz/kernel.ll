; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [16384 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [16384 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.slot7 = alloca i64, align 8
  store i64 0, ptr %.slot7, align 4
  %.slot8 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot8, align 32
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.spill12 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill12, align 4
  %tile_snapshot.spill13 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill13, align 64
  %.slot14 = alloca i64, align 8
  store i64 0, ptr %.slot14, align 4
  %.spill15 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill15, align 4
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat18, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 1024
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat20, %41
  %44 = mul i32 %32, 1
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat22, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat24, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat26
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 512
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state27 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state27, 8
  %.splatinsert28 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat29 = shufflevector <8 x i64> %.splatinsert28, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat29, %.spill.load
  %.spill.load30 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load30, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 4096)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state31 = load i64, ptr %.slot, align 4
  %.splatinsert32 = insertelement <8 x i64> poison, i64 %.state31, i64 0
  %.splat33 = shufflevector <8 x i64> %.splatinsert32, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat33, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %92, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = getelementptr i8, <8 x ptr> %93, <8 x i64> %94
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %buffer.contiguous.load, <8 x ptr> %95, i32 1, <8 x i1> %51)
  %.state34 = load i64, ptr %.slot, align 4
  %96 = add i64 %.state34, 1
  store i64 %96, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store float 0.000000e+00, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  %tile_snapshot.spill.load35 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 0
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load35, 1
  %99 = add <8 x i64> %98, zeroinitializer
  %100 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %97, 0
  %101 = insertvalue { <8 x ptr>, <8 x i64> } %100, <8 x i64> %99, 1
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %101, 0
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %101, 1
  %104 = getelementptr i8, <8 x ptr> %102, <8 x i64> %103
  %105 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %104, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %106 = fmul <8 x float> %105, %105
  %tile_snapshot.spill.load36 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 0
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 1
  %109 = add <8 x i64> %108, splat (i64 32)
  %110 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %107, 0
  %111 = insertvalue { <8 x ptr>, <8 x i64> } %110, <8 x i64> %109, 1
  %112 = extractvalue { <8 x ptr>, <8 x i64> } %111, 0
  %113 = extractvalue { <8 x ptr>, <8 x i64> } %111, 1
  %114 = getelementptr i8, <8 x ptr> %112, <8 x i64> %113
  %115 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %114, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %116 = fmul <8 x float> %115, %115
  %tile_snapshot.spill.load37 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 0
  %118 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load37, 1
  %119 = add <8 x i64> %118, splat (i64 64)
  %120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %117, 0
  %121 = insertvalue { <8 x ptr>, <8 x i64> } %120, <8 x i64> %119, 1
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %121, 0
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %121, 1
  %124 = getelementptr i8, <8 x ptr> %122, <8 x i64> %123
  %125 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %124, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %126 = fmul <8 x float> %125, %125
  %tile_snapshot.spill.load38 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %127 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load38, 0
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load38, 1
  %129 = add <8 x i64> %128, splat (i64 96)
  %130 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %131 = insertvalue { <8 x ptr>, <8 x i64> } %130, <8 x i64> %129, 1
  %132 = extractvalue { <8 x ptr>, <8 x i64> } %131, 0
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %131, 1
  %134 = getelementptr i8, <8 x ptr> %132, <8 x i64> %133
  %135 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %134, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %136 = fmul <8 x float> %135, %135
  store i64 4, ptr %.slot7, align 4
  %137 = load <8 x float>, ptr %.slot8, align 32
  %138 = select <8 x i1> %51, <8 x float> %106, <8 x float> %137
  store <8 x float> %138, ptr %.slot8, align 32
  %139 = load <8 x float>, ptr %.slot9, align 32
  %140 = select <8 x i1> %51, <8 x float> %116, <8 x float> %139
  store <8 x float> %140, ptr %.slot9, align 32
  %141 = load <8 x float>, ptr %.slot10, align 32
  %142 = select <8 x i1> %51, <8 x float> %126, <8 x float> %141
  store <8 x float> %142, ptr %.slot10, align 32
  %143 = load <8 x float>, ptr %.slot11, align 32
  %144 = select <8 x i1> %51, <8 x float> %136, <8 x float> %143
  store <8 x float> %144, ptr %.slot11, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state39 = load i64, ptr %.slot7, align 4
  %145 = icmp slt i64 %.state39, 512
  br i1 %145, label %direct.true40, label %direct.false41

direct.schedule.5:                                ; preds = %direct.true40
  %.state42 = load i64, ptr %.slot7, align 4
  %146 = add i64 %.state42, 0
  %tile_snapshot.spill.load43 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 0
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 1
  %.splatinsert44 = insertelement <8 x i64> poison, i64 %146, i64 0
  %.splat45 = shufflevector <8 x i64> %.splatinsert44, <8 x i64> poison, <8 x i32> zeroinitializer
  %149 = mul <8 x i64> %.splat45, splat (i64 32)
  %150 = add <8 x i64> %148, %149
  %151 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %147, 0
  %152 = insertvalue { <8 x ptr>, <8 x i64> } %151, <8 x i64> %150, 1
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %152, 0
  %154 = extractvalue { <8 x ptr>, <8 x i64> } %152, 1
  %155 = getelementptr i8, <8 x ptr> %153, <8 x i64> %154
  %156 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %155, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %157 = fmul <8 x float> %156, %156
  %.state46 = load <8 x float>, ptr %.slot8, align 32
  %158 = fadd <8 x float> %.state46, %157
  %.state47 = load i64, ptr %.slot7, align 4
  %159 = add i64 %.state47, 1
  %tile_snapshot.spill.load48 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load48, 0
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load48, 1
  %.splatinsert49 = insertelement <8 x i64> poison, i64 %159, i64 0
  %.splat50 = shufflevector <8 x i64> %.splatinsert49, <8 x i64> poison, <8 x i32> zeroinitializer
  %162 = mul <8 x i64> %.splat50, splat (i64 32)
  %163 = add <8 x i64> %161, %162
  %164 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %160, 0
  %165 = insertvalue { <8 x ptr>, <8 x i64> } %164, <8 x i64> %163, 1
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %168 = getelementptr i8, <8 x ptr> %166, <8 x i64> %167
  %169 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %168, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %170 = fmul <8 x float> %169, %169
  %.state51 = load <8 x float>, ptr %.slot9, align 32
  %171 = fadd <8 x float> %.state51, %170
  %.state52 = load i64, ptr %.slot7, align 4
  %172 = add i64 %.state52, 2
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %172, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %175 = mul <8 x i64> %.splat55, splat (i64 32)
  %176 = add <8 x i64> %174, %175
  %177 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %173, 0
  %178 = insertvalue { <8 x ptr>, <8 x i64> } %177, <8 x i64> %176, 1
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %178, 0
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %178, 1
  %181 = getelementptr i8, <8 x ptr> %179, <8 x i64> %180
  %182 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %181, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %183 = fmul <8 x float> %182, %182
  %.state56 = load <8 x float>, ptr %.slot10, align 32
  %184 = fadd <8 x float> %.state56, %183
  %.state57 = load i64, ptr %.slot7, align 4
  %185 = add i64 %.state57, 3
  %tile_snapshot.spill.load58 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load58, 0
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load58, 1
  %.splatinsert59 = insertelement <8 x i64> poison, i64 %185, i64 0
  %.splat60 = shufflevector <8 x i64> %.splatinsert59, <8 x i64> poison, <8 x i32> zeroinitializer
  %188 = mul <8 x i64> %.splat60, splat (i64 32)
  %189 = add <8 x i64> %187, %188
  %190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %186, 0
  %191 = insertvalue { <8 x ptr>, <8 x i64> } %190, <8 x i64> %189, 1
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %191, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %191, 1
  %194 = getelementptr i8, <8 x ptr> %192, <8 x i64> %193
  %195 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %194, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %196 = fmul <8 x float> %195, %195
  %.state61 = load <8 x float>, ptr %.slot11, align 32
  %197 = fadd <8 x float> %.state61, %196
  %.state62 = load i64, ptr %.slot7, align 4
  %198 = add i64 %.state62, 4
  store i64 %198, ptr %.slot7, align 4
  %199 = load <8 x float>, ptr %.slot8, align 32
  %200 = select <8 x i1> %51, <8 x float> %158, <8 x float> %199
  store <8 x float> %200, ptr %.slot8, align 32
  %201 = load <8 x float>, ptr %.slot9, align 32
  %202 = select <8 x i1> %51, <8 x float> %171, <8 x float> %201
  store <8 x float> %202, ptr %.slot9, align 32
  %203 = load <8 x float>, ptr %.slot10, align 32
  %204 = select <8 x i1> %51, <8 x float> %184, <8 x float> %203
  store <8 x float> %204, ptr %.slot10, align 32
  %205 = load <8 x float>, ptr %.slot11, align 32
  %206 = select <8 x i1> %51, <8 x float> %197, <8 x float> %205
  store <8 x float> %206, ptr %.slot11, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false41
  %.state63 = load <8 x float>, ptr %.slot8, align 32
  %.state64 = load <8 x float>, ptr %.slot9, align 32
  %207 = fadd <8 x float> %.state63, %.state64
  %.state65 = load <8 x float>, ptr %.slot10, align 32
  %208 = fadd <8 x float> %207, %.state65
  %.state66 = load <8 x float>, ptr %.slot11, align 32
  %209 = fadd <8 x float> %208, %.state66
  %.spill.load67 = load <8 x i64>, ptr %.spill, align 64
  %210 = trunc <8 x i64> %.spill.load67 to <8 x i32>
  %211 = xor <8 x i32> %210, splat (i32 1)
  %212 = extractelement <8 x i32> %211, i64 0
  %213 = icmp ult i32 %212, 8
  %214 = select i1 %213, i32 %212, i32 0
  %215 = extractelement <8 x i1> %51, i32 %214
  %216 = extractelement <8 x i1> %51, i64 0
  %217 = and i1 %213, %215
  %218 = and i1 %216, %217
  %219 = extractelement <8 x float> %209, i32 %214
  %220 = select i1 %218, float %219, float 0.000000e+00
  %221 = insertelement <8 x float> poison, float %220, i64 0
  %222 = xor i1 %218, true
  %223 = and i1 %216, %222
  %224 = insertelement <8 x i1> poison, i1 %223, i64 0
  %225 = extractelement <8 x i32> %211, i64 1
  %226 = icmp ult i32 %225, 8
  %227 = select i1 %226, i32 %225, i32 0
  %228 = extractelement <8 x i1> %51, i32 %227
  %229 = extractelement <8 x i1> %51, i64 1
  %230 = and i1 %226, %228
  %231 = and i1 %229, %230
  %232 = extractelement <8 x float> %209, i32 %227
  %233 = select i1 %231, float %232, float 0.000000e+00
  %234 = insertelement <8 x float> %221, float %233, i64 1
  %235 = xor i1 %231, true
  %236 = and i1 %229, %235
  %237 = insertelement <8 x i1> %224, i1 %236, i64 1
  %238 = extractelement <8 x i32> %211, i64 2
  %239 = icmp ult i32 %238, 8
  %240 = select i1 %239, i32 %238, i32 0
  %241 = extractelement <8 x i1> %51, i32 %240
  %242 = extractelement <8 x i1> %51, i64 2
  %243 = and i1 %239, %241
  %244 = and i1 %242, %243
  %245 = extractelement <8 x float> %209, i32 %240
  %246 = select i1 %244, float %245, float 0.000000e+00
  %247 = insertelement <8 x float> %234, float %246, i64 2
  %248 = xor i1 %244, true
  %249 = and i1 %242, %248
  %250 = insertelement <8 x i1> %237, i1 %249, i64 2
  %251 = extractelement <8 x i32> %211, i64 3
  %252 = icmp ult i32 %251, 8
  %253 = select i1 %252, i32 %251, i32 0
  %254 = extractelement <8 x i1> %51, i32 %253
  %255 = extractelement <8 x i1> %51, i64 3
  %256 = and i1 %252, %254
  %257 = and i1 %255, %256
  %258 = extractelement <8 x float> %209, i32 %253
  %259 = select i1 %257, float %258, float 0.000000e+00
  %260 = insertelement <8 x float> %247, float %259, i64 3
  %261 = xor i1 %257, true
  %262 = and i1 %255, %261
  %263 = insertelement <8 x i1> %250, i1 %262, i64 3
  %264 = extractelement <8 x i32> %211, i64 4
  %265 = icmp ult i32 %264, 8
  %266 = select i1 %265, i32 %264, i32 0
  %267 = extractelement <8 x i1> %51, i32 %266
  %268 = extractelement <8 x i1> %51, i64 4
  %269 = and i1 %265, %267
  %270 = and i1 %268, %269
  %271 = extractelement <8 x float> %209, i32 %266
  %272 = select i1 %270, float %271, float 0.000000e+00
  %273 = insertelement <8 x float> %260, float %272, i64 4
  %274 = xor i1 %270, true
  %275 = and i1 %268, %274
  %276 = insertelement <8 x i1> %263, i1 %275, i64 4
  %277 = extractelement <8 x i32> %211, i64 5
  %278 = icmp ult i32 %277, 8
  %279 = select i1 %278, i32 %277, i32 0
  %280 = extractelement <8 x i1> %51, i32 %279
  %281 = extractelement <8 x i1> %51, i64 5
  %282 = and i1 %278, %280
  %283 = and i1 %281, %282
  %284 = extractelement <8 x float> %209, i32 %279
  %285 = select i1 %283, float %284, float 0.000000e+00
  %286 = insertelement <8 x float> %273, float %285, i64 5
  %287 = xor i1 %283, true
  %288 = and i1 %281, %287
  %289 = insertelement <8 x i1> %276, i1 %288, i64 5
  %290 = extractelement <8 x i32> %211, i64 6
  %291 = icmp ult i32 %290, 8
  %292 = select i1 %291, i32 %290, i32 0
  %293 = extractelement <8 x i1> %51, i32 %292
  %294 = extractelement <8 x i1> %51, i64 6
  %295 = and i1 %291, %293
  %296 = and i1 %294, %295
  %297 = extractelement <8 x float> %209, i32 %292
  %298 = select i1 %296, float %297, float 0.000000e+00
  %299 = insertelement <8 x float> %286, float %298, i64 6
  %300 = xor i1 %296, true
  %301 = and i1 %294, %300
  %302 = insertelement <8 x i1> %289, i1 %301, i64 6
  %303 = extractelement <8 x i32> %211, i64 7
  %304 = icmp ult i32 %303, 8
  %305 = select i1 %304, i32 %303, i32 0
  %306 = extractelement <8 x i1> %51, i32 %305
  %307 = extractelement <8 x i1> %51, i64 7
  %308 = and i1 %304, %306
  %309 = and i1 %307, %308
  %310 = extractelement <8 x float> %209, i32 %305
  %311 = select i1 %309, float %310, float 0.000000e+00
  %312 = insertelement <8 x float> %299, float %311, i64 7
  %313 = xor i1 %309, true
  %314 = and i1 %307, %313
  %315 = insertelement <8 x i1> %302, i1 %314, i64 7
  %316 = fadd <8 x float> %209, %312
  %317 = xor <8 x i32> %210, splat (i32 2)
  %318 = extractelement <8 x i32> %317, i64 0
  %319 = icmp ult i32 %318, 8
  %320 = select i1 %319, i32 %318, i32 0
  %321 = extractelement <8 x i1> %51, i32 %320
  %322 = extractelement <8 x i1> %51, i64 0
  %323 = and i1 %319, %321
  %324 = and i1 %322, %323
  %325 = extractelement <8 x float> %316, i32 %320
  %326 = select i1 %324, float %325, float 0.000000e+00
  %327 = insertelement <8 x float> poison, float %326, i64 0
  %328 = xor i1 %324, true
  %329 = and i1 %322, %328
  %330 = insertelement <8 x i1> poison, i1 %329, i64 0
  %331 = extractelement <8 x i32> %317, i64 1
  %332 = icmp ult i32 %331, 8
  %333 = select i1 %332, i32 %331, i32 0
  %334 = extractelement <8 x i1> %51, i32 %333
  %335 = extractelement <8 x i1> %51, i64 1
  %336 = and i1 %332, %334
  %337 = and i1 %335, %336
  %338 = extractelement <8 x float> %316, i32 %333
  %339 = select i1 %337, float %338, float 0.000000e+00
  %340 = insertelement <8 x float> %327, float %339, i64 1
  %341 = xor i1 %337, true
  %342 = and i1 %335, %341
  %343 = insertelement <8 x i1> %330, i1 %342, i64 1
  %344 = extractelement <8 x i32> %317, i64 2
  %345 = icmp ult i32 %344, 8
  %346 = select i1 %345, i32 %344, i32 0
  %347 = extractelement <8 x i1> %51, i32 %346
  %348 = extractelement <8 x i1> %51, i64 2
  %349 = and i1 %345, %347
  %350 = and i1 %348, %349
  %351 = extractelement <8 x float> %316, i32 %346
  %352 = select i1 %350, float %351, float 0.000000e+00
  %353 = insertelement <8 x float> %340, float %352, i64 2
  %354 = xor i1 %350, true
  %355 = and i1 %348, %354
  %356 = insertelement <8 x i1> %343, i1 %355, i64 2
  %357 = extractelement <8 x i32> %317, i64 3
  %358 = icmp ult i32 %357, 8
  %359 = select i1 %358, i32 %357, i32 0
  %360 = extractelement <8 x i1> %51, i32 %359
  %361 = extractelement <8 x i1> %51, i64 3
  %362 = and i1 %358, %360
  %363 = and i1 %361, %362
  %364 = extractelement <8 x float> %316, i32 %359
  %365 = select i1 %363, float %364, float 0.000000e+00
  %366 = insertelement <8 x float> %353, float %365, i64 3
  %367 = xor i1 %363, true
  %368 = and i1 %361, %367
  %369 = insertelement <8 x i1> %356, i1 %368, i64 3
  %370 = extractelement <8 x i32> %317, i64 4
  %371 = icmp ult i32 %370, 8
  %372 = select i1 %371, i32 %370, i32 0
  %373 = extractelement <8 x i1> %51, i32 %372
  %374 = extractelement <8 x i1> %51, i64 4
  %375 = and i1 %371, %373
  %376 = and i1 %374, %375
  %377 = extractelement <8 x float> %316, i32 %372
  %378 = select i1 %376, float %377, float 0.000000e+00
  %379 = insertelement <8 x float> %366, float %378, i64 4
  %380 = xor i1 %376, true
  %381 = and i1 %374, %380
  %382 = insertelement <8 x i1> %369, i1 %381, i64 4
  %383 = extractelement <8 x i32> %317, i64 5
  %384 = icmp ult i32 %383, 8
  %385 = select i1 %384, i32 %383, i32 0
  %386 = extractelement <8 x i1> %51, i32 %385
  %387 = extractelement <8 x i1> %51, i64 5
  %388 = and i1 %384, %386
  %389 = and i1 %387, %388
  %390 = extractelement <8 x float> %316, i32 %385
  %391 = select i1 %389, float %390, float 0.000000e+00
  %392 = insertelement <8 x float> %379, float %391, i64 5
  %393 = xor i1 %389, true
  %394 = and i1 %387, %393
  %395 = insertelement <8 x i1> %382, i1 %394, i64 5
  %396 = extractelement <8 x i32> %317, i64 6
  %397 = icmp ult i32 %396, 8
  %398 = select i1 %397, i32 %396, i32 0
  %399 = extractelement <8 x i1> %51, i32 %398
  %400 = extractelement <8 x i1> %51, i64 6
  %401 = and i1 %397, %399
  %402 = and i1 %400, %401
  %403 = extractelement <8 x float> %316, i32 %398
  %404 = select i1 %402, float %403, float 0.000000e+00
  %405 = insertelement <8 x float> %392, float %404, i64 6
  %406 = xor i1 %402, true
  %407 = and i1 %400, %406
  %408 = insertelement <8 x i1> %395, i1 %407, i64 6
  %409 = extractelement <8 x i32> %317, i64 7
  %410 = icmp ult i32 %409, 8
  %411 = select i1 %410, i32 %409, i32 0
  %412 = extractelement <8 x i1> %51, i32 %411
  %413 = extractelement <8 x i1> %51, i64 7
  %414 = and i1 %410, %412
  %415 = and i1 %413, %414
  %416 = extractelement <8 x float> %316, i32 %411
  %417 = select i1 %415, float %416, float 0.000000e+00
  %418 = insertelement <8 x float> %405, float %417, i64 7
  %419 = xor i1 %415, true
  %420 = and i1 %413, %419
  %421 = insertelement <8 x i1> %408, i1 %420, i64 7
  %422 = fadd <8 x float> %316, %418
  %423 = xor <8 x i32> %210, splat (i32 4)
  %424 = extractelement <8 x i32> %423, i64 0
  %425 = icmp ult i32 %424, 8
  %426 = select i1 %425, i32 %424, i32 0
  %427 = extractelement <8 x i1> %51, i32 %426
  %428 = extractelement <8 x i1> %51, i64 0
  %429 = and i1 %425, %427
  %430 = and i1 %428, %429
  %431 = extractelement <8 x float> %422, i32 %426
  %432 = select i1 %430, float %431, float 0.000000e+00
  %433 = insertelement <8 x float> poison, float %432, i64 0
  %434 = xor i1 %430, true
  %435 = and i1 %428, %434
  %436 = insertelement <8 x i1> poison, i1 %435, i64 0
  %437 = extractelement <8 x i32> %423, i64 1
  %438 = icmp ult i32 %437, 8
  %439 = select i1 %438, i32 %437, i32 0
  %440 = extractelement <8 x i1> %51, i32 %439
  %441 = extractelement <8 x i1> %51, i64 1
  %442 = and i1 %438, %440
  %443 = and i1 %441, %442
  %444 = extractelement <8 x float> %422, i32 %439
  %445 = select i1 %443, float %444, float 0.000000e+00
  %446 = insertelement <8 x float> %433, float %445, i64 1
  %447 = xor i1 %443, true
  %448 = and i1 %441, %447
  %449 = insertelement <8 x i1> %436, i1 %448, i64 1
  %450 = extractelement <8 x i32> %423, i64 2
  %451 = icmp ult i32 %450, 8
  %452 = select i1 %451, i32 %450, i32 0
  %453 = extractelement <8 x i1> %51, i32 %452
  %454 = extractelement <8 x i1> %51, i64 2
  %455 = and i1 %451, %453
  %456 = and i1 %454, %455
  %457 = extractelement <8 x float> %422, i32 %452
  %458 = select i1 %456, float %457, float 0.000000e+00
  %459 = insertelement <8 x float> %446, float %458, i64 2
  %460 = xor i1 %456, true
  %461 = and i1 %454, %460
  %462 = insertelement <8 x i1> %449, i1 %461, i64 2
  %463 = extractelement <8 x i32> %423, i64 3
  %464 = icmp ult i32 %463, 8
  %465 = select i1 %464, i32 %463, i32 0
  %466 = extractelement <8 x i1> %51, i32 %465
  %467 = extractelement <8 x i1> %51, i64 3
  %468 = and i1 %464, %466
  %469 = and i1 %467, %468
  %470 = extractelement <8 x float> %422, i32 %465
  %471 = select i1 %469, float %470, float 0.000000e+00
  %472 = insertelement <8 x float> %459, float %471, i64 3
  %473 = xor i1 %469, true
  %474 = and i1 %467, %473
  %475 = insertelement <8 x i1> %462, i1 %474, i64 3
  %476 = extractelement <8 x i32> %423, i64 4
  %477 = icmp ult i32 %476, 8
  %478 = select i1 %477, i32 %476, i32 0
  %479 = extractelement <8 x i1> %51, i32 %478
  %480 = extractelement <8 x i1> %51, i64 4
  %481 = and i1 %477, %479
  %482 = and i1 %480, %481
  %483 = extractelement <8 x float> %422, i32 %478
  %484 = select i1 %482, float %483, float 0.000000e+00
  %485 = insertelement <8 x float> %472, float %484, i64 4
  %486 = xor i1 %482, true
  %487 = and i1 %480, %486
  %488 = insertelement <8 x i1> %475, i1 %487, i64 4
  %489 = extractelement <8 x i32> %423, i64 5
  %490 = icmp ult i32 %489, 8
  %491 = select i1 %490, i32 %489, i32 0
  %492 = extractelement <8 x i1> %51, i32 %491
  %493 = extractelement <8 x i1> %51, i64 5
  %494 = and i1 %490, %492
  %495 = and i1 %493, %494
  %496 = extractelement <8 x float> %422, i32 %491
  %497 = select i1 %495, float %496, float 0.000000e+00
  %498 = insertelement <8 x float> %485, float %497, i64 5
  %499 = xor i1 %495, true
  %500 = and i1 %493, %499
  %501 = insertelement <8 x i1> %488, i1 %500, i64 5
  %502 = extractelement <8 x i32> %423, i64 6
  %503 = icmp ult i32 %502, 8
  %504 = select i1 %503, i32 %502, i32 0
  %505 = extractelement <8 x i1> %51, i32 %504
  %506 = extractelement <8 x i1> %51, i64 6
  %507 = and i1 %503, %505
  %508 = and i1 %506, %507
  %509 = extractelement <8 x float> %422, i32 %504
  %510 = select i1 %508, float %509, float 0.000000e+00
  %511 = insertelement <8 x float> %498, float %510, i64 6
  %512 = xor i1 %508, true
  %513 = and i1 %506, %512
  %514 = insertelement <8 x i1> %501, i1 %513, i64 6
  %515 = extractelement <8 x i32> %423, i64 7
  %516 = icmp ult i32 %515, 8
  %517 = select i1 %516, i32 %515, i32 0
  %518 = extractelement <8 x i1> %51, i32 %517
  %519 = extractelement <8 x i1> %51, i64 7
  %520 = and i1 %516, %518
  %521 = and i1 %519, %520
  %522 = extractelement <8 x float> %422, i32 %517
  %523 = select i1 %521, float %522, float 0.000000e+00
  %524 = insertelement <8 x float> %511, float %523, i64 7
  %525 = xor i1 %521, true
  %526 = and i1 %519, %525
  %527 = insertelement <8 x i1> %514, i1 %526, i64 7
  %528 = fadd <8 x float> %422, %524
  %529 = extractelement <8 x i1> %51, i32 0
  %530 = extractelement <8 x i1> %51, i64 0
  %531 = and i1 true, %529
  %532 = and i1 %530, %531
  %533 = extractelement <8 x float> %528, i32 0
  %534 = select i1 %532, float %533, float 0.000000e+00
  %535 = insertelement <8 x float> poison, float %534, i64 0
  %536 = xor i1 %532, true
  %537 = and i1 %530, %536
  %538 = insertelement <8 x i1> poison, i1 %537, i64 0
  %539 = extractelement <8 x i1> %51, i32 0
  %540 = extractelement <8 x i1> %51, i64 1
  %541 = and i1 true, %539
  %542 = and i1 %540, %541
  %543 = extractelement <8 x float> %528, i32 0
  %544 = select i1 %542, float %543, float 0.000000e+00
  %545 = insertelement <8 x float> %535, float %544, i64 1
  %546 = xor i1 %542, true
  %547 = and i1 %540, %546
  %548 = insertelement <8 x i1> %538, i1 %547, i64 1
  %549 = extractelement <8 x i1> %51, i32 0
  %550 = extractelement <8 x i1> %51, i64 2
  %551 = and i1 true, %549
  %552 = and i1 %550, %551
  %553 = extractelement <8 x float> %528, i32 0
  %554 = select i1 %552, float %553, float 0.000000e+00
  %555 = insertelement <8 x float> %545, float %554, i64 2
  %556 = xor i1 %552, true
  %557 = and i1 %550, %556
  %558 = insertelement <8 x i1> %548, i1 %557, i64 2
  %559 = extractelement <8 x i1> %51, i32 0
  %560 = extractelement <8 x i1> %51, i64 3
  %561 = and i1 true, %559
  %562 = and i1 %560, %561
  %563 = extractelement <8 x float> %528, i32 0
  %564 = select i1 %562, float %563, float 0.000000e+00
  %565 = insertelement <8 x float> %555, float %564, i64 3
  %566 = xor i1 %562, true
  %567 = and i1 %560, %566
  %568 = insertelement <8 x i1> %558, i1 %567, i64 3
  %569 = extractelement <8 x i1> %51, i32 0
  %570 = extractelement <8 x i1> %51, i64 4
  %571 = and i1 true, %569
  %572 = and i1 %570, %571
  %573 = extractelement <8 x float> %528, i32 0
  %574 = select i1 %572, float %573, float 0.000000e+00
  %575 = insertelement <8 x float> %565, float %574, i64 4
  %576 = xor i1 %572, true
  %577 = and i1 %570, %576
  %578 = insertelement <8 x i1> %568, i1 %577, i64 4
  %579 = extractelement <8 x i1> %51, i32 0
  %580 = extractelement <8 x i1> %51, i64 5
  %581 = and i1 true, %579
  %582 = and i1 %580, %581
  %583 = extractelement <8 x float> %528, i32 0
  %584 = select i1 %582, float %583, float 0.000000e+00
  %585 = insertelement <8 x float> %575, float %584, i64 5
  %586 = xor i1 %582, true
  %587 = and i1 %580, %586
  %588 = insertelement <8 x i1> %578, i1 %587, i64 5
  %589 = extractelement <8 x i1> %51, i32 0
  %590 = extractelement <8 x i1> %51, i64 6
  %591 = and i1 true, %589
  %592 = and i1 %590, %591
  %593 = extractelement <8 x float> %528, i32 0
  %594 = select i1 %592, float %593, float 0.000000e+00
  %595 = insertelement <8 x float> %585, float %594, i64 6
  %596 = xor i1 %592, true
  %597 = and i1 %590, %596
  %598 = insertelement <8 x i1> %588, i1 %597, i64 6
  %599 = extractelement <8 x i1> %51, i32 0
  %600 = extractelement <8 x i1> %51, i64 7
  %601 = and i1 true, %599
  %602 = and i1 %600, %601
  %603 = extractelement <8 x float> %528, i32 0
  %604 = select i1 %602, float %603, float 0.000000e+00
  %605 = insertelement <8 x float> %595, float %604, i64 7
  %606 = xor i1 %602, true
  %607 = and i1 %600, %606
  %608 = insertelement <8 x i1> %598, i1 %607, i64 7
  %609 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %610 = bitcast <8 x i1> %51 to i8
  %611 = call i8 @llvm.cttz.i8(i8 %610, i1 false)
  %612 = zext i8 %611 to i32
  %613 = select i1 %609, i32 %612, i32 0
  %614 = extractelement <8 x float> %605, i32 %613
  %.spill.load68 = load float, ptr %.spill5, align 4
  %615 = fadd float %.spill.load68, %614
  %616 = fdiv float %615, 4.096000e+03
  store float %616, ptr %.spill12, align 4
  %617 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %618 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %619 = extractvalue { <8 x ptr>, <8 x i64> } %617, 0
  %620 = select <8 x i1> %51, <8 x ptr> %618, <8 x ptr> %619
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %617, 1
  %623 = select <8 x i1> %51, <8 x i64> %621, <8 x i64> %622
  %624 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %620, 0
  %625 = insertvalue { <8 x ptr>, <8 x i64> } %624, <8 x i64> %623, 1
  store { <8 x ptr>, <8 x i64> } %625, ptr %tile_snapshot.spill13, align 64
  store i64 0, ptr %.slot14, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state69 = load i64, ptr %.slot14, align 4
  %626 = icmp slt i64 %.state69, 512
  br i1 %626, label %direct.true70, label %direct.false71

direct.schedule.8:                                ; preds = %direct.true70
  %.state72 = load i64, ptr %.slot14, align 4
  %627 = mul i64 %.state72, 8
  %.splatinsert73 = insertelement <8 x i64> poison, i64 %627, i64 0
  %.splat74 = shufflevector <8 x i64> %.splatinsert73, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load75 = load <8 x i64>, ptr %.spill, align 64
  %628 = add <8 x i64> %.splat74, %.spill.load75
  %.spill.load76 = load i64, ptr %.spill6, align 4
  %629 = add i64 %.spill.load76, 0
  %630 = add <8 x i64> zeroinitializer, %628
  %631 = mul i64 %629, 4096
  %.splatinsert77 = insertelement <8 x i64> poison, i64 %631, i64 0
  %.splat78 = shufflevector <8 x i64> %.splatinsert77, <8 x i64> poison, <8 x i32> zeroinitializer
  %632 = add <8 x i64> %.splat78, %630
  %633 = extractvalue { ptr, i64 } %15, 0
  %634 = extractelement <8 x i64> %632, i32 0
  %635 = sub i64 %634, 0
  %636 = mul i64 %635, 4
  %buffer.contiguous.address79 = getelementptr i8, ptr %633, i64 %636
  %buffer.contiguous.load80 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address79, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load81 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 0
  %638 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 1
  %.state82 = load i64, ptr %.slot14, align 4
  %.splatinsert83 = insertelement <8 x i64> poison, i64 %.state82, i64 0
  %.splat84 = shufflevector <8 x i64> %.splatinsert83, <8 x i64> poison, <8 x i32> zeroinitializer
  %639 = mul <8 x i64> %.splat84, splat (i64 32)
  %640 = add <8 x i64> %638, %639
  %641 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %637, 0
  %642 = insertvalue { <8 x ptr>, <8 x i64> } %641, <8 x i64> %640, 1
  %643 = extractvalue { <8 x ptr>, <8 x i64> } %642, 0
  %644 = extractvalue { <8 x ptr>, <8 x i64> } %642, 1
  %645 = getelementptr i8, <8 x ptr> %643, <8 x i64> %644
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %buffer.contiguous.load80, <8 x ptr> %645, i32 1, <8 x i1> %51)
  %.state85 = load i64, ptr %.slot14, align 4
  %646 = add i64 %.state85, 1
  store i64 %646, ptr %.slot14, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false71
  %.spill.load86 = load float, ptr %.spill12, align 4
  %647 = fadd float %.spill.load86, 0x3EE4F8B580000000
  %648 = call float @llvm.sqrt.f32(float %647)
  store float %648, ptr %.spill15, align 4
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state87 = load i64, ptr %.slot16, align 4
  %649 = icmp slt i64 %.state87, 512
  br i1 %649, label %direct.true88, label %direct.false89

direct.schedule.11:                               ; preds = %direct.true88
  %.state90 = load i64, ptr %.slot16, align 4
  %650 = mul i64 %.state90, 8
  %.splatinsert91 = insertelement <8 x i64> poison, i64 %650, i64 0
  %.splat92 = shufflevector <8 x i64> %.splatinsert91, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load93 = load <8 x i64>, ptr %.spill, align 64
  %651 = add <8 x i64> %.splat92, %.spill.load93
  %.spill.load94 = load <8 x i64>, ptr %.spill4, align 64
  %652 = add <8 x i64> %.spill.load94, zeroinitializer
  %653 = add <8 x i64> zeroinitializer, %652
  %654 = add <8 x i64> zeroinitializer, %651
  %655 = mul <8 x i64> %653, splat (i64 4096)
  %656 = add <8 x i64> %655, %654
  %tile_snapshot.spill.load95 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %657 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 0
  %658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 1
  %.state96 = load i64, ptr %.slot16, align 4
  %.splatinsert97 = insertelement <8 x i64> poison, i64 %.state96, i64 0
  %.splat98 = shufflevector <8 x i64> %.splatinsert97, <8 x i64> poison, <8 x i32> zeroinitializer
  %659 = mul <8 x i64> %.splat98, splat (i64 32)
  %660 = add <8 x i64> %658, %659
  %661 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %657, 0
  %662 = insertvalue { <8 x ptr>, <8 x i64> } %661, <8 x i64> %660, 1
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %662, 0
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %662, 1
  %665 = getelementptr i8, <8 x ptr> %663, <8 x i64> %664
  %666 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %665, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %.spill.load99 = load float, ptr %.spill15, align 4
  %.splatinsert100 = insertelement <8 x float> poison, float %.spill.load99, i64 0
  %.splat101 = shufflevector <8 x float> %.splatinsert100, <8 x float> poison, <8 x i32> zeroinitializer
  %667 = fdiv <8 x float> %666, %.splat101
  %tile_snapshot.spill.load102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 0
  %669 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 1
  %.state103 = load i64, ptr %.slot16, align 4
  %.splatinsert104 = insertelement <8 x i64> poison, i64 %.state103, i64 0
  %.splat105 = shufflevector <8 x i64> %.splatinsert104, <8 x i64> poison, <8 x i32> zeroinitializer
  %670 = mul <8 x i64> %.splat105, splat (i64 32)
  %671 = add <8 x i64> %669, %670
  %672 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %668, 0
  %673 = insertvalue { <8 x ptr>, <8 x i64> } %672, <8 x i64> %671, 1
  %674 = extractvalue { <8 x ptr>, <8 x i64> } %673, 0
  %675 = extractvalue { <8 x ptr>, <8 x i64> } %673, 1
  %676 = getelementptr i8, <8 x ptr> %674, <8 x i64> %675
  %677 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %676, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %678 = fmul <8 x float> %667, %677
  %679 = extractvalue { ptr, i64 } %27, 0
  %680 = extractelement <8 x i64> %656, i32 0
  %681 = sub i64 %680, 0
  %682 = mul i64 %681, 4
  %buffer.contiguous.address106 = getelementptr i8, ptr %679, i64 %682
  call void @llvm.masked.store.v8f32.p0(<8 x float> %678, ptr %buffer.contiguous.address106, i32 1, <8 x i1> %51)
  %.state107 = load i64, ptr %.slot16, align 4
  %683 = add i64 %.state107, 1
  store i64 %683, ptr %.slot16, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false89
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true40:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false41:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true70:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false71:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true88:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false89:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #4

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 1024
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 1024
  %3 = sub i64 1024, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 128
  %8 = icmp uge i64 %packet.range.remaining, 1024
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  br label %packet.batch.full.loop

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full.loop
  ret void

packet.batch.full.loop:                           ; preds = %packet.batch.full.loop, %packet.batch.full
  %packet.index = phi i32 [ 0, %packet.batch.full ], [ %packet.index.next, %packet.batch.full.loop ]
  %packet.thread.offset = mul i32 %packet.index, 8
  %packet.thread.index = add i32 %base.thread.index, %packet.thread.offset
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.index.next = add i32 %packet.index, 1
  %packet.batch.has.more = icmp ult i32 %packet.index.next, %packet_count
  br i1 %packet.batch.has.more, label %packet.batch.full.loop, label %packet.batch.exit

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 128)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB0_122
; %bb.1:                                ; %block.batch.loop.preheader
	stp	d11, d10, [sp, #-128]!          ; 16-byte Folded Spill
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	sub	sp, sp, #4, lsl #12             ; =16384
	sub	sp, sp, #32
	mov	w8, #0                          ; =0x0
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #32
	ldp	w10, w11, [x2, #44]
	ldp	w19, w20, [x2]
	add	x12, x9, #224
	str	x12, [sp, #16]                  ; 8-byte Folded Spill
Lloh0:
	adrp	x14, lCPI0_0@PAGE
Lloh1:
	ldr	q0, [x14, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x14, lCPI0_1@PAGE
Lloh3:
	ldr	q1, [x14, lCPI0_1@PAGEOFF]
	add	x14, sp, #32
	mov	w16, #50604                     ; =0xc5ac
	movk	w16, #14119, lsl #16
	adrp	x1, lCPI0_2@PAGE
	ldp	w21, w4, [x2, #8]
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	b	LBB0_3
LBB0_2:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	w12, w7, #1
	cmp	w12, w10
	cset	w12, eq
	csinc	w19, wzr, w7, eq
	cinc	w13, w6, eq
	cmp	w13, w11
	cset	w15, eq
	ands	w12, w12, w15
	csel	w20, wzr, w13, ne
	add	w21, w5, w12
	add	w8, w8, #1
	cmp	w8, w3
	b.eq	LBB0_121
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_70 Depth 2
                                        ;       Child Loop BB0_71 Depth 3
                                        ;       Child Loop BB0_73 Depth 3
                                        ;       Child Loop BB0_75 Depth 3
                                        ;       Child Loop BB0_77 Depth 3
                                        ;     Child Loop BB0_83 Depth 2
                                        ;     Child Loop BB0_100 Depth 2
                                        ;     Child Loop BB0_102 Depth 2
                                        ;     Child Loop BB0_105 Depth 2
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_7 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_11 Depth 2
                                        ;     Child Loop BB0_13 Depth 2
                                        ;     Child Loop BB0_15 Depth 2
                                        ;     Child Loop BB0_17 Depth 2
                                        ;     Child Loop BB0_19 Depth 2
                                        ;     Child Loop BB0_21 Depth 2
                                        ;     Child Loop BB0_23 Depth 2
                                        ;     Child Loop BB0_25 Depth 2
                                        ;     Child Loop BB0_27 Depth 2
                                        ;     Child Loop BB0_29 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_33 Depth 2
                                        ;     Child Loop BB0_35 Depth 2
                                        ;     Child Loop BB0_37 Depth 2
                                        ;     Child Loop BB0_39 Depth 2
                                        ;     Child Loop BB0_41 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
                                        ;     Child Loop BB0_45 Depth 2
                                        ;     Child Loop BB0_47 Depth 2
                                        ;     Child Loop BB0_49 Depth 2
                                        ;     Child Loop BB0_51 Depth 2
                                        ;     Child Loop BB0_53 Depth 2
                                        ;     Child Loop BB0_55 Depth 2
                                        ;     Child Loop BB0_57 Depth 2
                                        ;     Child Loop BB0_59 Depth 2
                                        ;     Child Loop BB0_61 Depth 2
                                        ;     Child Loop BB0_63 Depth 2
                                        ;     Child Loop BB0_65 Depth 2
                                        ;     Child Loop BB0_67 Depth 2
	mov	x5, x21
	mov	x6, x20
	mov	x7, x19
	ubfiz	x19, x19, #6, #32
	cmp	x19, x4
	csel	x20, x19, xzr, ls
	subs	x21, x4, x20
	cmp	x21, #64
	mov	w12, #64                        ; =0x40
	csel	x21, x21, x12, lo
	cmp	x4, x20
	ccmp	x19, x4, #2, hi
	csel	x19, x21, xzr, ls
	mov	w12, #998244352                 ; =0x3b800000
	dup.4s	v3, w12
	dup.4s	v2, w16
	cmp	x19, #64
	b.lo	LBB0_68
; %bb.4:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x22, #0                         ; =0x0
	ldr	x24, [x0]
	ldr	x19, [x0, #16]
	ldr	x21, [x0, #48]
	lsl	w20, w7, #6
	dup.4s	v4, w20
	orr.16b	v5, v4, v0
	orr.16b	v4, v4, v1
	ushll2.2d	v6, v5, #10
	ushll2.2d	v7, v4, #10
	ushll.2d	v16, v5, #10
	ushll.2d	v17, v4, #10
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #32
	dup.2d	v4, x24
LBB0_5:                                 ; %direct.true.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v5, x22
	add.2d	v18, v5, v17
	add.2d	v19, v5, v7
	add.2d	v20, v5, v16
	add.2d	v5, v5, v6
	add.2d	v5, v4, v5
	add.2d	v20, v4, v20
	add.2d	v19, v4, v19
	add.2d	v18, v4, v18
	mov.d	x24, v18[1]
	fmov	x25, d18
	mov.d	x26, v19[1]
	fmov	x27, d19
	mov.d	x28, v20[1]
	fmov	x30, d20
	mov.d	x12, v5[1]
	ldr	s18, [x30]
	ld1.s	{ v18 }[1], [x28]
	fmov	x28, d5
	ld1.s	{ v18 }[2], [x28]
	ld1.s	{ v18 }[3], [x12]
	ldr	s5, [x25]
	ld1.s	{ v5 }[1], [x24]
	ld1.s	{ v5 }[2], [x27]
	ld1.s	{ v5 }[3], [x26]
	stp	q5, q18, [x23], #32
	add	x22, x22, #4
	cmp	x22, #1024
	b.ne	LBB0_5
; %bb.6:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x22, #0                         ; =0x0
	ldp	q5, q18, [x9]
	fmul.4s	v18, v18, v18
	fmul.4s	v5, v5, v5
	ldp	q19, q20, [x9, #32]
	fmul.4s	v20, v20, v20
	fmul.4s	v19, v19, v19
	ldp	q22, q21, [x9, #64]
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	ldp	q23, q24, [x9, #96]
	fmul.4s	v24, v24, v24
	fmul.4s	v23, v23, v23
LBB0_7:                                 ; %direct.true47.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x22, lsl #5
	ldp	q26, q25, [x12, #128]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v18, v18, v25
	fadd.4s	v5, v5, v26
	ldp	q26, q25, [x12, #160]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v20, v20, v25
	fadd.4s	v19, v19, v26
	ldp	q26, q25, [x12, #192]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v21, v21, v25
	fadd.4s	v22, v22, v26
	ldp	q26, q25, [x12, #224]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v24, v24, v25
	fadd.4s	v23, v23, v26
	add	x22, x22, #4
	cmp	x22, #252
	b.lo	LBB0_7
; %bb.8:                                ; %direct.true94.i.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x22, #0                         ; =0x0
LBB0_9:                                 ; %direct.true94.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x19, x22, lsl #2
	ld1r.4s	{ v25 }, [x12]
	add	x12, x14, x22, lsl #5
	stp	q25, q25, [x12]
	add	x22, x22, #1
	cmp	x22, #256
	b.ne	LBB0_9
; %bb.10:                               ; %direct.false95.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x22, #0                         ; =0x0
	mov	x23, #0                         ; =0x0
	fadd.4s	v18, v18, v20
	fadd.4s	v5, v5, v19
	fadd.4s	v5, v5, v22
	fadd.4s	v18, v18, v21
	fadd.4s	v18, v18, v24
	fadd.4s	v5, v5, v23
	fmul.4s	v5, v5, v3
	fmul.4s	v18, v18, v3
	fadd.4s	v19, v18, v2
	fadd.4s	v5, v5, v2
	fsqrt.4s	v18, v5
	fsqrt.4s	v19, v19
LBB0_11:                                ; %direct.true109.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x23
	ldp	q20, q5, [x12]
	fdiv.4s	v20, v20, v18
	fdiv.4s	v5, v5, v19
	add	x12, x14, x23
	ldp	q21, q22, [x12]
	fmul.4s	v22, v5, v22
	fmul.4s	v20, v20, v21
	dup.2d	v5, x22
	add.2d	v21, v5, v17
	add.2d	v23, v5, v7
	add.2d	v24, v5, v16
	add.2d	v25, v5, v6
	dup.2d	v5, x21
	add.2d	v23, v5, v23
	add.2d	v21, v5, v21
	mov.d	x12, v21[1]
	fmov	x24, d21
	str	s20, [x24]
	st1.s	{ v20 }[1], [x12]
	mov.d	x12, v23[1]
	add.2d	v21, v5, v24
	fmov	x24, d23
	st1.s	{ v20 }[2], [x24]
	st1.s	{ v20 }[3], [x12]
	mov.d	x12, v21[1]
	fmov	x24, d21
	str	s22, [x24]
	st1.s	{ v22 }[1], [x12]
	add.2d	v20, v5, v25
	mov.d	x12, v20[1]
	fmov	x24, d20
	st1.s	{ v22 }[2], [x24]
	st1.s	{ v22 }[3], [x12]
	add	x23, x23, #32
	add	x22, x22, #4
	cmp	x23, #2, lsl #12                ; =8192
	b.ne	LBB0_11
; %bb.12:                               ; %llm_rows.exit.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	orr	w12, w20, #0x8
	dup.4s	v6, w12
	orr.16b	v16, v6, v0
	orr.16b	v17, v6, v1
	ushll2.2d	v6, v16, #10
	ushll2.2d	v7, v17, #10
	ushll.2d	v16, v16, #10
	ushll.2d	v17, v17, #10
	add	x22, sp, #2, lsl #12            ; =8192
	add	x22, x22, #32
LBB0_13:                                ; %direct.true.i6.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v18, x21
	add.2d	v19, v18, v17
	add.2d	v20, v18, v7
	add.2d	v21, v18, v16
	add.2d	v18, v18, v6
	add.2d	v18, v4, v18
	add.2d	v21, v4, v21
	add.2d	v20, v4, v20
	add.2d	v19, v4, v19
	mov.d	x12, v19[1]
	fmov	x23, d19
	mov.d	x24, v20[1]
	fmov	x25, d20
	mov.d	x26, v21[1]
	fmov	x27, d21
	mov.d	x28, v18[1]
	ldr	s19, [x27]
	ld1.s	{ v19 }[1], [x26]
	fmov	x26, d18
	ld1.s	{ v19 }[2], [x26]
	ld1.s	{ v19 }[3], [x28]
	ldr	s18, [x23]
	ld1.s	{ v18 }[1], [x12]
	ld1.s	{ v18 }[2], [x25]
	ld1.s	{ v18 }[3], [x24]
	stp	q18, q19, [x22], #32
	add	x21, x21, #4
	cmp	x21, #1024
	b.ne	LBB0_13
; %bb.14:                               ; %direct.false.i12.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	ldp	q18, q19, [x9]
	fmul.4s	v19, v19, v19
	fmul.4s	v18, v18, v18
	ldp	q20, q21, [x9, #32]
	fmul.4s	v21, v21, v21
	fmul.4s	v20, v20, v20
	ldp	q23, q22, [x9, #64]
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	ldp	q24, q25, [x9, #96]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
LBB0_15:                                ; %direct.true47.i20.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x21, lsl #5
	ldp	q27, q26, [x12, #128]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v19, v19, v26
	fadd.4s	v18, v18, v27
	ldp	q27, q26, [x12, #160]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v21, v21, v26
	fadd.4s	v20, v20, v27
	ldp	q27, q26, [x12, #192]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v23, v23, v27
	ldp	q27, q26, [x12, #224]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v25, v25, v26
	fadd.4s	v24, v24, v27
	add	x21, x21, #4
	cmp	x21, #252
	b.lo	LBB0_15
; %bb.16:                               ; %direct.true94.i35.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
LBB0_17:                                ; %direct.true94.i35.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x19, x21, lsl #2
	ld1r.4s	{ v26 }, [x12]
	add	x12, x14, x21, lsl #5
	stp	q26, q26, [x12]
	add	x21, x21, #1
	cmp	x21, #256
	b.ne	LBB0_17
; %bb.18:                               ; %direct.false95.i42.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	fadd.4s	v18, v18, v23
	fadd.4s	v19, v19, v22
	fadd.4s	v19, v19, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v18, v3
	fmul.4s	v19, v19, v3
	fadd.4s	v19, v19, v2
	fadd.4s	v18, v18, v2
	fsqrt.4s	v18, v18
	fsqrt.4s	v19, v19
LBB0_19:                                ; %direct.true109.i43.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x22
	ldp	q21, q20, [x12]
	fdiv.4s	v21, v21, v18
	fdiv.4s	v20, v20, v19
	add	x12, x14, x22
	ldp	q22, q23, [x12]
	fmul.4s	v20, v20, v23
	fmul.4s	v21, v21, v22
	dup.2d	v22, x21
	add.2d	v23, v22, v17
	add.2d	v24, v22, v7
	add.2d	v25, v22, v16
	add.2d	v22, v22, v6
	add.2d	v24, v5, v24
	add.2d	v23, v5, v23
	mov.d	x12, v23[1]
	fmov	x23, d23
	str	s21, [x23]
	st1.s	{ v21 }[1], [x12]
	mov.d	x12, v24[1]
	add.2d	v23, v5, v25
	fmov	x23, d24
	st1.s	{ v21 }[2], [x23]
	st1.s	{ v21 }[3], [x12]
	mov.d	x12, v23[1]
	fmov	x23, d23
	str	s20, [x23]
	st1.s	{ v20 }[1], [x12]
	add.2d	v21, v5, v22
	mov.d	x12, v21[1]
	fmov	x23, d21
	st1.s	{ v20 }[2], [x23]
	st1.s	{ v20 }[3], [x12]
	add	x22, x22, #32
	add	x21, x21, #4
	cmp	x22, #2, lsl #12                ; =8192
	b.ne	LBB0_19
; %bb.20:                               ; %llm_rows.exit51.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	orr	w12, w20, #0x10
	dup.4s	v6, w12
	orr.16b	v16, v6, v0
	orr.16b	v17, v6, v1
	ushll2.2d	v6, v16, #10
	ushll2.2d	v7, v17, #10
	ushll.2d	v16, v16, #10
	ushll.2d	v17, v17, #10
	add	x22, sp, #2, lsl #12            ; =8192
	add	x22, x22, #32
LBB0_21:                                ; %direct.true.i55.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v18, x21
	add.2d	v19, v18, v17
	add.2d	v20, v18, v7
	add.2d	v21, v18, v16
	add.2d	v18, v18, v6
	add.2d	v18, v4, v18
	add.2d	v21, v4, v21
	add.2d	v20, v4, v20
	add.2d	v19, v4, v19
	mov.d	x12, v19[1]
	fmov	x23, d19
	mov.d	x24, v20[1]
	fmov	x25, d20
	mov.d	x26, v21[1]
	fmov	x27, d21
	mov.d	x28, v18[1]
	ldr	s19, [x27]
	ld1.s	{ v19 }[1], [x26]
	fmov	x26, d18
	ld1.s	{ v19 }[2], [x26]
	ld1.s	{ v19 }[3], [x28]
	ldr	s18, [x23]
	ld1.s	{ v18 }[1], [x12]
	ld1.s	{ v18 }[2], [x25]
	ld1.s	{ v18 }[3], [x24]
	stp	q18, q19, [x22], #32
	add	x21, x21, #4
	cmp	x21, #1024
	b.ne	LBB0_21
; %bb.22:                               ; %direct.false.i61.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	ldp	q18, q19, [x9]
	fmul.4s	v19, v19, v19
	fmul.4s	v18, v18, v18
	ldp	q20, q21, [x9, #32]
	fmul.4s	v21, v21, v21
	fmul.4s	v20, v20, v20
	ldp	q23, q22, [x9, #64]
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	ldp	q24, q25, [x9, #96]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
LBB0_23:                                ; %direct.true47.i69.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x21, lsl #5
	ldp	q27, q26, [x12, #128]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v19, v19, v26
	fadd.4s	v18, v18, v27
	ldp	q27, q26, [x12, #160]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v21, v21, v26
	fadd.4s	v20, v20, v27
	ldp	q27, q26, [x12, #192]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v23, v23, v27
	ldp	q27, q26, [x12, #224]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v25, v25, v26
	fadd.4s	v24, v24, v27
	add	x21, x21, #4
	cmp	x21, #252
	b.lo	LBB0_23
; %bb.24:                               ; %direct.true94.i84.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
LBB0_25:                                ; %direct.true94.i84.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x19, x21, lsl #2
	ld1r.4s	{ v26 }, [x12]
	add	x12, x14, x21, lsl #5
	stp	q26, q26, [x12]
	add	x21, x21, #1
	cmp	x21, #256
	b.ne	LBB0_25
; %bb.26:                               ; %direct.false95.i91.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	fadd.4s	v18, v18, v23
	fadd.4s	v19, v19, v22
	fadd.4s	v19, v19, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v18, v3
	fmul.4s	v19, v19, v3
	fadd.4s	v19, v19, v2
	fadd.4s	v18, v18, v2
	fsqrt.4s	v18, v18
	fsqrt.4s	v19, v19
LBB0_27:                                ; %direct.true109.i92.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x22
	ldp	q21, q20, [x12]
	fdiv.4s	v21, v21, v18
	fdiv.4s	v20, v20, v19
	add	x12, x14, x22
	ldp	q22, q23, [x12]
	fmul.4s	v20, v20, v23
	fmul.4s	v21, v21, v22
	dup.2d	v22, x21
	add.2d	v23, v22, v17
	add.2d	v24, v22, v7
	add.2d	v25, v22, v16
	add.2d	v22, v22, v6
	add.2d	v24, v5, v24
	add.2d	v23, v5, v23
	mov.d	x12, v23[1]
	fmov	x23, d23
	str	s21, [x23]
	st1.s	{ v21 }[1], [x12]
	mov.d	x12, v24[1]
	add.2d	v23, v5, v25
	fmov	x23, d24
	st1.s	{ v21 }[2], [x23]
	st1.s	{ v21 }[3], [x12]
	mov.d	x12, v23[1]
	fmov	x23, d23
	str	s20, [x23]
	st1.s	{ v20 }[1], [x12]
	add.2d	v21, v5, v22
	mov.d	x12, v21[1]
	fmov	x23, d21
	st1.s	{ v20 }[2], [x23]
	st1.s	{ v20 }[3], [x12]
	add	x22, x22, #32
	add	x21, x21, #4
	cmp	x22, #2, lsl #12                ; =8192
	b.ne	LBB0_27
; %bb.28:                               ; %llm_rows.exit100.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	orr	w12, w20, #0x18
	dup.4s	v6, w12
	orr.16b	v16, v6, v0
	orr.16b	v17, v6, v1
	ushll2.2d	v6, v16, #10
	ushll2.2d	v7, v17, #10
	ushll.2d	v16, v16, #10
	ushll.2d	v17, v17, #10
	add	x22, sp, #2, lsl #12            ; =8192
	add	x22, x22, #32
LBB0_29:                                ; %direct.true.i104.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v18, x21
	add.2d	v19, v18, v17
	add.2d	v20, v18, v7
	add.2d	v21, v18, v16
	add.2d	v18, v18, v6
	add.2d	v18, v4, v18
	add.2d	v21, v4, v21
	add.2d	v20, v4, v20
	add.2d	v19, v4, v19
	mov.d	x12, v19[1]
	fmov	x23, d19
	mov.d	x24, v20[1]
	fmov	x25, d20
	mov.d	x26, v21[1]
	fmov	x27, d21
	mov.d	x28, v18[1]
	ldr	s19, [x27]
	ld1.s	{ v19 }[1], [x26]
	fmov	x26, d18
	ld1.s	{ v19 }[2], [x26]
	ld1.s	{ v19 }[3], [x28]
	ldr	s18, [x23]
	ld1.s	{ v18 }[1], [x12]
	ld1.s	{ v18 }[2], [x25]
	ld1.s	{ v18 }[3], [x24]
	stp	q18, q19, [x22], #32
	add	x21, x21, #4
	cmp	x21, #1024
	b.ne	LBB0_29
; %bb.30:                               ; %direct.false.i110.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	ldp	q18, q19, [x9]
	fmul.4s	v19, v19, v19
	fmul.4s	v18, v18, v18
	ldp	q20, q21, [x9, #32]
	fmul.4s	v21, v21, v21
	fmul.4s	v20, v20, v20
	ldp	q23, q22, [x9, #64]
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	ldp	q24, q25, [x9, #96]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
LBB0_31:                                ; %direct.true47.i118.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x21, lsl #5
	ldp	q27, q26, [x12, #128]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v19, v19, v26
	fadd.4s	v18, v18, v27
	ldp	q27, q26, [x12, #160]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v21, v21, v26
	fadd.4s	v20, v20, v27
	ldp	q27, q26, [x12, #192]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v23, v23, v27
	ldp	q27, q26, [x12, #224]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v25, v25, v26
	fadd.4s	v24, v24, v27
	add	x21, x21, #4
	cmp	x21, #252
	b.lo	LBB0_31
; %bb.32:                               ; %direct.true94.i133.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
LBB0_33:                                ; %direct.true94.i133.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x19, x21, lsl #2
	ld1r.4s	{ v26 }, [x12]
	add	x12, x14, x21, lsl #5
	stp	q26, q26, [x12]
	add	x21, x21, #1
	cmp	x21, #256
	b.ne	LBB0_33
; %bb.34:                               ; %direct.false95.i140.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	fadd.4s	v18, v18, v23
	fadd.4s	v19, v19, v22
	fadd.4s	v19, v19, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v18, v3
	fmul.4s	v19, v19, v3
	fadd.4s	v19, v19, v2
	fadd.4s	v18, v18, v2
	fsqrt.4s	v18, v18
	fsqrt.4s	v19, v19
LBB0_35:                                ; %direct.true109.i141.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x22
	ldp	q21, q20, [x12]
	fdiv.4s	v21, v21, v18
	fdiv.4s	v20, v20, v19
	add	x12, x14, x22
	ldp	q22, q23, [x12]
	fmul.4s	v20, v20, v23
	fmul.4s	v21, v21, v22
	dup.2d	v22, x21
	add.2d	v23, v22, v17
	add.2d	v24, v22, v7
	add.2d	v25, v22, v16
	add.2d	v22, v22, v6
	add.2d	v24, v5, v24
	add.2d	v23, v5, v23
	mov.d	x12, v23[1]
	fmov	x23, d23
	str	s21, [x23]
	st1.s	{ v21 }[1], [x12]
	mov.d	x12, v24[1]
	add.2d	v23, v5, v25
	fmov	x23, d24
	st1.s	{ v21 }[2], [x23]
	st1.s	{ v21 }[3], [x12]
	mov.d	x12, v23[1]
	fmov	x23, d23
	str	s20, [x23]
	st1.s	{ v20 }[1], [x12]
	add.2d	v21, v5, v22
	mov.d	x12, v21[1]
	fmov	x23, d21
	st1.s	{ v20 }[2], [x23]
	st1.s	{ v20 }[3], [x12]
	add	x22, x22, #32
	add	x21, x21, #4
	cmp	x22, #2, lsl #12                ; =8192
	b.ne	LBB0_35
; %bb.36:                               ; %llm_rows.exit149.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	orr	w12, w20, #0x20
	dup.4s	v6, w12
	orr.16b	v16, v6, v0
	orr.16b	v17, v6, v1
	ushll2.2d	v6, v16, #10
	ushll2.2d	v7, v17, #10
	ushll.2d	v16, v16, #10
	ushll.2d	v17, v17, #10
	add	x22, sp, #2, lsl #12            ; =8192
	add	x22, x22, #32
LBB0_37:                                ; %direct.true.i153.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v18, x21
	add.2d	v19, v18, v17
	add.2d	v20, v18, v7
	add.2d	v21, v18, v16
	add.2d	v18, v18, v6
	add.2d	v18, v4, v18
	add.2d	v21, v4, v21
	add.2d	v20, v4, v20
	add.2d	v19, v4, v19
	mov.d	x12, v19[1]
	fmov	x23, d19
	mov.d	x24, v20[1]
	fmov	x25, d20
	mov.d	x26, v21[1]
	fmov	x27, d21
	mov.d	x28, v18[1]
	ldr	s19, [x27]
	ld1.s	{ v19 }[1], [x26]
	fmov	x26, d18
	ld1.s	{ v19 }[2], [x26]
	ld1.s	{ v19 }[3], [x28]
	ldr	s18, [x23]
	ld1.s	{ v18 }[1], [x12]
	ld1.s	{ v18 }[2], [x25]
	ld1.s	{ v18 }[3], [x24]
	stp	q18, q19, [x22], #32
	add	x21, x21, #4
	cmp	x21, #1024
	b.ne	LBB0_37
; %bb.38:                               ; %direct.false.i159.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	ldp	q18, q19, [x9]
	fmul.4s	v19, v19, v19
	fmul.4s	v18, v18, v18
	ldp	q20, q21, [x9, #32]
	fmul.4s	v21, v21, v21
	fmul.4s	v20, v20, v20
	ldp	q23, q22, [x9, #64]
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	ldp	q24, q25, [x9, #96]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
LBB0_39:                                ; %direct.true47.i167.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x21, lsl #5
	ldp	q27, q26, [x12, #128]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v19, v19, v26
	fadd.4s	v18, v18, v27
	ldp	q27, q26, [x12, #160]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v21, v21, v26
	fadd.4s	v20, v20, v27
	ldp	q27, q26, [x12, #192]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v23, v23, v27
	ldp	q27, q26, [x12, #224]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v25, v25, v26
	fadd.4s	v24, v24, v27
	add	x21, x21, #4
	cmp	x21, #252
	b.lo	LBB0_39
; %bb.40:                               ; %direct.true94.i182.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
LBB0_41:                                ; %direct.true94.i182.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x19, x21, lsl #2
	ld1r.4s	{ v26 }, [x12]
	add	x12, x14, x21, lsl #5
	stp	q26, q26, [x12]
	add	x21, x21, #1
	cmp	x21, #256
	b.ne	LBB0_41
; %bb.42:                               ; %direct.false95.i189.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	fadd.4s	v18, v18, v23
	fadd.4s	v19, v19, v22
	fadd.4s	v19, v19, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v18, v3
	fmul.4s	v19, v19, v3
	fadd.4s	v19, v19, v2
	fadd.4s	v18, v18, v2
	fsqrt.4s	v18, v18
	fsqrt.4s	v19, v19
LBB0_43:                                ; %direct.true109.i190.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x22
	ldp	q21, q20, [x12]
	fdiv.4s	v21, v21, v18
	fdiv.4s	v20, v20, v19
	add	x12, x14, x22
	ldp	q22, q23, [x12]
	fmul.4s	v20, v20, v23
	fmul.4s	v21, v21, v22
	dup.2d	v22, x21
	add.2d	v23, v22, v17
	add.2d	v24, v22, v7
	add.2d	v25, v22, v16
	add.2d	v22, v22, v6
	add.2d	v24, v5, v24
	add.2d	v23, v5, v23
	mov.d	x12, v23[1]
	fmov	x23, d23
	str	s21, [x23]
	st1.s	{ v21 }[1], [x12]
	mov.d	x12, v24[1]
	add.2d	v23, v5, v25
	fmov	x23, d24
	st1.s	{ v21 }[2], [x23]
	st1.s	{ v21 }[3], [x12]
	mov.d	x12, v23[1]
	fmov	x23, d23
	str	s20, [x23]
	st1.s	{ v20 }[1], [x12]
	add.2d	v21, v5, v22
	mov.d	x12, v21[1]
	fmov	x23, d21
	st1.s	{ v20 }[2], [x23]
	st1.s	{ v20 }[3], [x12]
	add	x22, x22, #32
	add	x21, x21, #4
	cmp	x22, #2, lsl #12                ; =8192
	b.ne	LBB0_43
; %bb.44:                               ; %llm_rows.exit198.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	mov	w12, #40                        ; =0x28
	orr	w12, w20, w12
	dup.4s	v6, w12
	orr.16b	v16, v6, v0
	orr.16b	v17, v6, v1
	ushll2.2d	v6, v16, #10
	ushll2.2d	v7, v17, #10
	ushll.2d	v16, v16, #10
	ushll.2d	v17, v17, #10
	add	x22, sp, #2, lsl #12            ; =8192
	add	x22, x22, #32
LBB0_45:                                ; %direct.true.i202.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v18, x21
	add.2d	v19, v18, v17
	add.2d	v20, v18, v7
	add.2d	v21, v18, v16
	add.2d	v18, v18, v6
	add.2d	v18, v4, v18
	add.2d	v21, v4, v21
	add.2d	v20, v4, v20
	add.2d	v19, v4, v19
	mov.d	x12, v19[1]
	fmov	x23, d19
	mov.d	x24, v20[1]
	fmov	x25, d20
	mov.d	x26, v21[1]
	fmov	x27, d21
	mov.d	x28, v18[1]
	ldr	s19, [x27]
	ld1.s	{ v19 }[1], [x26]
	fmov	x26, d18
	ld1.s	{ v19 }[2], [x26]
	ld1.s	{ v19 }[3], [x28]
	ldr	s18, [x23]
	ld1.s	{ v18 }[1], [x12]
	ld1.s	{ v18 }[2], [x25]
	ld1.s	{ v18 }[3], [x24]
	stp	q18, q19, [x22], #32
	add	x21, x21, #4
	cmp	x21, #1024
	b.ne	LBB0_45
; %bb.46:                               ; %direct.false.i208.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	ldp	q18, q19, [x9]
	fmul.4s	v19, v19, v19
	fmul.4s	v18, v18, v18
	ldp	q20, q21, [x9, #32]
	fmul.4s	v21, v21, v21
	fmul.4s	v20, v20, v20
	ldp	q23, q22, [x9, #64]
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	ldp	q24, q25, [x9, #96]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
LBB0_47:                                ; %direct.true47.i216.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x21, lsl #5
	ldp	q27, q26, [x12, #128]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v19, v19, v26
	fadd.4s	v18, v18, v27
	ldp	q27, q26, [x12, #160]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v21, v21, v26
	fadd.4s	v20, v20, v27
	ldp	q27, q26, [x12, #192]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v23, v23, v27
	ldp	q27, q26, [x12, #224]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v25, v25, v26
	fadd.4s	v24, v24, v27
	add	x21, x21, #4
	cmp	x21, #252
	b.lo	LBB0_47
; %bb.48:                               ; %direct.true94.i231.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
LBB0_49:                                ; %direct.true94.i231.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x19, x21, lsl #2
	ld1r.4s	{ v26 }, [x12]
	add	x12, x14, x21, lsl #5
	stp	q26, q26, [x12]
	add	x21, x21, #1
	cmp	x21, #256
	b.ne	LBB0_49
; %bb.50:                               ; %direct.false95.i238.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	fadd.4s	v18, v18, v23
	fadd.4s	v19, v19, v22
	fadd.4s	v19, v19, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v18, v3
	fmul.4s	v19, v19, v3
	fadd.4s	v19, v19, v2
	fadd.4s	v18, v18, v2
	fsqrt.4s	v18, v18
	fsqrt.4s	v19, v19
LBB0_51:                                ; %direct.true109.i239.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x22
	ldp	q21, q20, [x12]
	fdiv.4s	v21, v21, v18
	fdiv.4s	v20, v20, v19
	add	x12, x14, x22
	ldp	q22, q23, [x12]
	fmul.4s	v20, v20, v23
	fmul.4s	v21, v21, v22
	dup.2d	v22, x21
	add.2d	v23, v22, v17
	add.2d	v24, v22, v7
	add.2d	v25, v22, v16
	add.2d	v22, v22, v6
	add.2d	v24, v5, v24
	add.2d	v23, v5, v23
	mov.d	x12, v23[1]
	fmov	x23, d23
	str	s21, [x23]
	st1.s	{ v21 }[1], [x12]
	mov.d	x12, v24[1]
	add.2d	v23, v5, v25
	fmov	x23, d24
	st1.s	{ v21 }[2], [x23]
	st1.s	{ v21 }[3], [x12]
	mov.d	x12, v23[1]
	fmov	x23, d23
	str	s20, [x23]
	st1.s	{ v20 }[1], [x12]
	add.2d	v21, v5, v22
	mov.d	x12, v21[1]
	fmov	x23, d21
	st1.s	{ v20 }[2], [x23]
	st1.s	{ v20 }[3], [x12]
	add	x22, x22, #32
	add	x21, x21, #4
	cmp	x22, #2, lsl #12                ; =8192
	b.ne	LBB0_51
; %bb.52:                               ; %llm_rows.exit247.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	orr	w12, w20, #0x30
	dup.4s	v6, w12
	orr.16b	v16, v6, v0
	orr.16b	v17, v6, v1
	ushll2.2d	v6, v16, #10
	ushll2.2d	v7, v17, #10
	ushll.2d	v16, v16, #10
	ushll.2d	v17, v17, #10
	add	x22, sp, #2, lsl #12            ; =8192
	add	x22, x22, #32
LBB0_53:                                ; %direct.true.i251.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v18, x21
	add.2d	v19, v18, v17
	add.2d	v20, v18, v7
	add.2d	v21, v18, v16
	add.2d	v18, v18, v6
	add.2d	v18, v4, v18
	add.2d	v21, v4, v21
	add.2d	v20, v4, v20
	add.2d	v19, v4, v19
	mov.d	x12, v19[1]
	fmov	x23, d19
	mov.d	x24, v20[1]
	fmov	x25, d20
	mov.d	x26, v21[1]
	fmov	x27, d21
	mov.d	x28, v18[1]
	ldr	s19, [x27]
	ld1.s	{ v19 }[1], [x26]
	fmov	x26, d18
	ld1.s	{ v19 }[2], [x26]
	ld1.s	{ v19 }[3], [x28]
	ldr	s18, [x23]
	ld1.s	{ v18 }[1], [x12]
	ld1.s	{ v18 }[2], [x25]
	ld1.s	{ v18 }[3], [x24]
	stp	q18, q19, [x22], #32
	add	x21, x21, #4
	cmp	x21, #1024
	b.ne	LBB0_53
; %bb.54:                               ; %direct.false.i257.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	ldp	q18, q19, [x9]
	fmul.4s	v19, v19, v19
	fmul.4s	v18, v18, v18
	ldp	q20, q21, [x9, #32]
	fmul.4s	v21, v21, v21
	fmul.4s	v20, v20, v20
	ldp	q23, q22, [x9, #64]
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	ldp	q24, q25, [x9, #96]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
LBB0_55:                                ; %direct.true47.i265.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x21, lsl #5
	ldp	q27, q26, [x12, #128]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v19, v19, v26
	fadd.4s	v18, v18, v27
	ldp	q27, q26, [x12, #160]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v21, v21, v26
	fadd.4s	v20, v20, v27
	ldp	q27, q26, [x12, #192]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v23, v23, v27
	ldp	q27, q26, [x12, #224]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v25, v25, v26
	fadd.4s	v24, v24, v27
	add	x21, x21, #4
	cmp	x21, #252
	b.lo	LBB0_55
; %bb.56:                               ; %direct.true94.i280.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
LBB0_57:                                ; %direct.true94.i280.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x19, x21, lsl #2
	ld1r.4s	{ v26 }, [x12]
	add	x12, x14, x21, lsl #5
	stp	q26, q26, [x12]
	add	x21, x21, #1
	cmp	x21, #256
	b.ne	LBB0_57
; %bb.58:                               ; %direct.false95.i287.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	mov	x22, #0                         ; =0x0
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	fadd.4s	v18, v18, v23
	fadd.4s	v19, v19, v22
	fadd.4s	v19, v19, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v18, v3
	fmul.4s	v19, v19, v3
	fadd.4s	v19, v19, v2
	fadd.4s	v18, v18, v2
	fsqrt.4s	v18, v18
	fsqrt.4s	v19, v19
LBB0_59:                                ; %direct.true109.i288.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x22
	ldp	q21, q20, [x12]
	fdiv.4s	v21, v21, v18
	fdiv.4s	v20, v20, v19
	add	x12, x14, x22
	ldp	q22, q23, [x12]
	fmul.4s	v20, v20, v23
	fmul.4s	v21, v21, v22
	dup.2d	v22, x21
	add.2d	v23, v22, v17
	add.2d	v24, v22, v7
	add.2d	v25, v22, v16
	add.2d	v22, v22, v6
	add.2d	v24, v5, v24
	add.2d	v23, v5, v23
	mov.d	x12, v23[1]
	fmov	x23, d23
	str	s21, [x23]
	st1.s	{ v21 }[1], [x12]
	mov.d	x12, v24[1]
	add.2d	v23, v5, v25
	fmov	x23, d24
	st1.s	{ v21 }[2], [x23]
	st1.s	{ v21 }[3], [x12]
	mov.d	x12, v23[1]
	fmov	x23, d23
	str	s20, [x23]
	st1.s	{ v20 }[1], [x12]
	add.2d	v21, v5, v22
	mov.d	x12, v21[1]
	fmov	x23, d21
	st1.s	{ v20 }[2], [x23]
	st1.s	{ v20 }[3], [x12]
	add	x22, x22, #32
	add	x21, x21, #4
	cmp	x22, #2, lsl #12                ; =8192
	b.ne	LBB0_59
; %bb.60:                               ; %llm_rows.exit296.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
	orr	w12, w20, #0x38
	dup.4s	v6, w12
	orr.16b	v16, v6, v0
	orr.16b	v17, v6, v1
	ushll2.2d	v6, v16, #10
	ushll2.2d	v7, v17, #10
	ushll.2d	v16, v16, #10
	ushll.2d	v17, v17, #10
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #32
LBB0_61:                                ; %direct.true.i300.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v18, x21
	add.2d	v19, v18, v17
	add.2d	v20, v18, v7
	add.2d	v21, v18, v16
	add.2d	v18, v18, v6
	add.2d	v18, v4, v18
	add.2d	v21, v4, v21
	add.2d	v20, v4, v20
	add.2d	v19, v4, v19
	mov.d	x12, v19[1]
	fmov	x22, d19
	mov.d	x23, v20[1]
	fmov	x24, d20
	mov.d	x25, v21[1]
	fmov	x26, d21
	mov.d	x27, v18[1]
	ldr	s19, [x26]
	ld1.s	{ v19 }[1], [x25]
	fmov	x25, d18
	ld1.s	{ v19 }[2], [x25]
	ld1.s	{ v19 }[3], [x27]
	ldr	s18, [x22]
	ld1.s	{ v18 }[1], [x12]
	ld1.s	{ v18 }[2], [x24]
	ld1.s	{ v18 }[3], [x23]
	stp	q18, q19, [x20], #32
	add	x21, x21, #4
	cmp	x21, #1024
	b.ne	LBB0_61
; %bb.62:                               ; %direct.false.i306.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x20, #0                         ; =0x0
	ldp	q4, q18, [x9]
	fmul.4s	v18, v18, v18
	fmul.4s	v4, v4, v4
	ldp	q19, q20, [x9, #32]
	fmul.4s	v20, v20, v20
	fmul.4s	v19, v19, v19
	ldp	q22, q21, [x9, #64]
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	ldp	q23, q24, [x9, #96]
	fmul.4s	v24, v24, v24
	fmul.4s	v23, v23, v23
LBB0_63:                                ; %direct.true47.i314.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x20, lsl #5
	ldp	q26, q25, [x12, #128]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v18, v18, v25
	fadd.4s	v4, v4, v26
	ldp	q26, q25, [x12, #160]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v20, v20, v25
	fadd.4s	v19, v19, v26
	ldp	q26, q25, [x12, #192]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v21, v21, v25
	fadd.4s	v22, v22, v26
	ldp	q26, q25, [x12, #224]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v24, v24, v25
	fadd.4s	v23, v23, v26
	add	x20, x20, #4
	cmp	x20, #252
	b.lo	LBB0_63
; %bb.64:                               ; %direct.true94.i329.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x20, #0                         ; =0x0
LBB0_65:                                ; %direct.true94.i329.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x19, x20, lsl #2
	ld1r.4s	{ v25 }, [x12]
	add	x12, x14, x20, lsl #5
	stp	q25, q25, [x12]
	add	x20, x20, #1
	cmp	x20, #256
	b.ne	LBB0_65
; %bb.66:                               ; %direct.false95.i336.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x19, #0                         ; =0x0
	mov	x20, #0                         ; =0x0
	fadd.4s	v18, v18, v20
	fadd.4s	v4, v4, v19
	fadd.4s	v4, v4, v22
	fadd.4s	v18, v18, v21
	fadd.4s	v18, v18, v24
	fadd.4s	v4, v4, v23
	fmul.4s	v4, v4, v3
	fmul.4s	v3, v18, v3
	fadd.4s	v3, v3, v2
	fadd.4s	v2, v4, v2
	fsqrt.4s	v2, v2
	fsqrt.4s	v3, v3
LBB0_67:                                ; %direct.true109.i337.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x20
	ldp	q18, q4, [x12]
	fdiv.4s	v18, v18, v2
	fdiv.4s	v4, v4, v3
	add	x12, x14, x20
	ldp	q19, q20, [x12]
	fmul.4s	v4, v4, v20
	fmul.4s	v18, v18, v19
	dup.2d	v19, x19
	add.2d	v20, v19, v17
	add.2d	v21, v19, v7
	add.2d	v22, v19, v16
	add.2d	v19, v19, v6
	add.2d	v21, v5, v21
	add.2d	v20, v5, v20
	mov.d	x12, v20[1]
	fmov	x21, d20
	str	s18, [x21]
	st1.s	{ v18 }[1], [x12]
	mov.d	x12, v21[1]
	add.2d	v20, v5, v22
	fmov	x21, d21
	st1.s	{ v18 }[2], [x21]
	st1.s	{ v18 }[3], [x12]
	mov.d	x12, v20[1]
	fmov	x21, d20
	str	s4, [x21]
	st1.s	{ v4 }[1], [x12]
	add.2d	v18, v5, v19
	mov.d	x12, v18[1]
	fmov	x21, d18
	st1.s	{ v4 }[2], [x21]
	st1.s	{ v4 }[3], [x12]
	add	x20, x20, #32
	add	x19, x19, #4
	cmp	x20, #2, lsl #12                ; =8192
	b.ne	LBB0_67
	b	LBB0_2
LBB0_68:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	lsr	x21, x19, #3
	cmp	x19, #8
	b.lo	LBB0_79
; %bb.69:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w20, #0                         ; =0x0
	ldr	x22, [x0]
	ldr	x23, [x0, #16]
	lsl	w24, w7, #6
	ldr	x25, [x0, #48]
LBB0_70:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_71 Depth 3
                                        ;       Child Loop BB0_73 Depth 3
                                        ;       Child Loop BB0_75 Depth 3
                                        ;       Child Loop BB0_77 Depth 3
	mov	x26, #0                         ; =0x0
	add	w12, w24, w20, lsl #3
	dup.4s	v4, w12
	orr.16b	v6, v4, v0
	orr.16b	v7, v4, v1
	ushll2.2d	v4, v6, #10
	ushll2.2d	v5, v7, #10
	ushll.2d	v6, v6, #10
	ushll.2d	v7, v7, #10
	add	x27, sp, #2, lsl #12            ; =8192
	add	x27, x27, #32
LBB0_71:                                ; %direct.true.i349.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_70 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	dup.2d	v16, x26
	add.2d	v17, v16, v7
	add.2d	v18, v16, v5
	add.2d	v19, v16, v6
	add.2d	v16, v16, v4
	dup.2d	v20, x22
	add.2d	v16, v20, v16
	add.2d	v19, v20, v19
	add.2d	v18, v20, v18
	add.2d	v17, v20, v17
	mov.d	x12, v17[1]
	fmov	x28, d17
	mov.d	x30, v18[1]
	fmov	x17, d18
	mov.d	x13, v19[1]
	fmov	x2, d19
	mov.d	x15, v16[1]
	ldr	s17, [x2]
	ld1.s	{ v17 }[1], [x13]
	fmov	x13, d16
	ld1.s	{ v17 }[2], [x13]
	ld1.s	{ v17 }[3], [x15]
	ldr	s16, [x28]
	ld1.s	{ v16 }[1], [x12]
	ld1.s	{ v16 }[2], [x17]
	ld1.s	{ v16 }[3], [x30]
	stp	q16, q17, [x27], #32
	add	x26, x26, #4
	cmp	x26, #1024
	b.ne	LBB0_71
; %bb.72:                               ; %direct.false.i355.i
                                        ;   in Loop: Header=BB0_70 Depth=2
	mov	x26, #0                         ; =0x0
	ldp	q16, q17, [x9]
	fmul.4s	v17, v17, v17
	fmul.4s	v16, v16, v16
	ldp	q18, q19, [x9, #32]
	fmul.4s	v19, v19, v19
	fmul.4s	v18, v18, v18
	ldp	q21, q20, [x9, #64]
	fmul.4s	v20, v20, v20
	fmul.4s	v21, v21, v21
	ldp	q22, q23, [x9, #96]
	fmul.4s	v23, v23, v23
	fmul.4s	v22, v22, v22
LBB0_73:                                ; %direct.true47.i363.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_70 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x12, x9, x26, lsl #5
	ldp	q25, q24, [x12, #128]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v17, v17, v24
	fadd.4s	v16, v16, v25
	ldp	q25, q24, [x12, #160]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v19, v19, v24
	fadd.4s	v18, v18, v25
	ldp	q25, q24, [x12, #192]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v20, v20, v24
	fadd.4s	v21, v21, v25
	ldp	q25, q24, [x12, #224]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v23, v23, v24
	fadd.4s	v22, v22, v25
	add	x26, x26, #4
	cmp	x26, #252
	b.lo	LBB0_73
; %bb.74:                               ; %direct.true94.i378.i.preheader
                                        ;   in Loop: Header=BB0_70 Depth=2
	mov	x26, #0                         ; =0x0
LBB0_75:                                ; %direct.true94.i378.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_70 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x12, x23, x26, lsl #2
	ld1r.4s	{ v24 }, [x12]
	add	x12, x14, x26, lsl #5
	stp	q24, q24, [x12]
	add	x26, x26, #1
	cmp	x26, #256
	b.ne	LBB0_75
; %bb.76:                               ; %direct.false95.i385.i
                                        ;   in Loop: Header=BB0_70 Depth=2
	mov	x26, #0                         ; =0x0
	mov	x27, #0                         ; =0x0
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	fadd.4s	v16, v16, v21
	fadd.4s	v17, v17, v20
	fadd.4s	v17, v17, v23
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v16, v3
	fmul.4s	v17, v17, v3
	fadd.4s	v17, v17, v2
	fadd.4s	v16, v16, v2
	fsqrt.4s	v16, v16
	fsqrt.4s	v17, v17
LBB0_77:                                ; %direct.true109.i386.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_70 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x12, x9, x27
	ldp	q19, q18, [x12]
	fdiv.4s	v19, v19, v16
	fdiv.4s	v18, v18, v17
	add	x12, x14, x27
	ldp	q20, q21, [x12]
	fmul.4s	v18, v18, v21
	fmul.4s	v19, v19, v20
	dup.2d	v20, x26
	add.2d	v21, v20, v7
	add.2d	v22, v20, v5
	add.2d	v23, v20, v6
	add.2d	v20, v20, v4
	dup.2d	v24, x25
	add.2d	v22, v24, v22
	add.2d	v21, v24, v21
	mov.d	x12, v21[1]
	fmov	x13, d21
	str	s19, [x13]
	st1.s	{ v19 }[1], [x12]
	mov.d	x12, v22[1]
	add.2d	v21, v24, v23
	fmov	x13, d22
	st1.s	{ v19 }[2], [x13]
	st1.s	{ v19 }[3], [x12]
	mov.d	x12, v21[1]
	fmov	x13, d21
	str	s18, [x13]
	st1.s	{ v18 }[1], [x12]
	add.2d	v19, v24, v20
	mov.d	x12, v19[1]
	fmov	x13, d19
	st1.s	{ v18 }[2], [x13]
	st1.s	{ v18 }[3], [x12]
	add	x27, x27, #32
	add	x26, x26, #4
	cmp	x27, #2, lsl #12                ; =8192
	b.ne	LBB0_77
; %bb.78:                               ; %llm_rows.exit394.i
                                        ;   in Loop: Header=BB0_70 Depth=2
	add	w20, w20, #1
	cmp	w20, w21
	b.ne	LBB0_70
LBB0_79:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w19, w19, #0x7
	cbz	w19, LBB0_2
; %bb.80:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v5, w19
	cmhi.4s	v4, v5, v0
	cmhi.4s	v5, v5, v1
	uzp1.8h	v19, v5, v4
	umaxv.8h	h6, v19
	fmov	w12, s6
	tbz	w12, #0, LBB0_2
; %bb.81:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x22, #0                         ; =0x0
	ldr	x23, [x0]
	ldr	x20, [x0, #16]
	ldr	x19, [x0, #48]
	lsl	w12, w21, #3
	orr	w12, w12, w7, lsl #6
	dup.4s	v6, w12
	orr.16b	v7, v6, v1
	orr.16b	v6, v6, v0
	and.16b	v16, v4, v6
	and.16b	v17, v5, v7
	ushll2.2d	v6, v16, #10
	ushll2.2d	v7, v17, #10
	ushll.2d	v16, v16, #10
	ushll.2d	v17, v17, #10
	add	x21, sp, #2, lsl #12            ; =8192
	add	x21, x21, #32
	b	LBB0_83
LBB0_82:                                ; %else819
                                        ;   in Loop: Header=BB0_83 Depth=2
	ldp	q22, q23, [x21]
	bif.16b	v21, v23, v4
	bif.16b	v20, v22, v5
	stp	q20, q21, [x21], #32
	add	x22, x22, #4
	cmp	x22, #1024
	b.eq	LBB0_99
LBB0_83:                                ; %direct.true.i398.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q18, [x1, lCPI0_2@PAGEOFF]
	and.16b	v18, v19, v18
	addv.8h	h18, v18
	fmov	w24, s18
	dup.2d	v22, x22
	add.2d	v20, v22, v17
	dup.2d	v23, x23
	add.2d	v24, v23, v20
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w24, #0, LBB0_91
; %bb.84:                               ; %else
                                        ;   in Loop: Header=BB0_83 Depth=2
	and	w24, w24, #0xff
	tbnz	w24, #1, LBB0_92
LBB0_85:                                ; %else783
                                        ;   in Loop: Header=BB0_83 Depth=2
	add.2d	v24, v22, v7
	add.2d	v24, v23, v24
	tbnz	w24, #2, LBB0_93
LBB0_86:                                ; %else789
                                        ;   in Loop: Header=BB0_83 Depth=2
	tbnz	w24, #3, LBB0_94
LBB0_87:                                ; %else795
                                        ;   in Loop: Header=BB0_83 Depth=2
	add.2d	v24, v22, v16
	add.2d	v24, v23, v24
	tbnz	w24, #4, LBB0_95
LBB0_88:                                ; %else801
                                        ;   in Loop: Header=BB0_83 Depth=2
	tbnz	w24, #5, LBB0_96
LBB0_89:                                ; %else807
                                        ;   in Loop: Header=BB0_83 Depth=2
	add.2d	v22, v22, v6
	add.2d	v22, v23, v22
	tbnz	w24, #6, LBB0_97
LBB0_90:                                ; %else813
                                        ;   in Loop: Header=BB0_83 Depth=2
	tbz	w24, #7, LBB0_82
	b	LBB0_98
LBB0_91:                                ; %cond.load
                                        ;   in Loop: Header=BB0_83 Depth=2
	fmov	x12, d24
	ldr	s20, [x12]
	and	w24, w24, #0xff
	tbz	w24, #1, LBB0_85
LBB0_92:                                ; %cond.load779
                                        ;   in Loop: Header=BB0_83 Depth=2
	mov.d	x12, v24[1]
	ld1.s	{ v20 }[1], [x12]
	add.2d	v24, v22, v7
	add.2d	v24, v23, v24
	tbz	w24, #2, LBB0_86
LBB0_93:                                ; %cond.load785
                                        ;   in Loop: Header=BB0_83 Depth=2
	fmov	x12, d24
	ld1.s	{ v20 }[2], [x12]
	tbz	w24, #3, LBB0_87
LBB0_94:                                ; %cond.load791
                                        ;   in Loop: Header=BB0_83 Depth=2
	mov.d	x12, v24[1]
	ld1.s	{ v20 }[3], [x12]
	add.2d	v24, v22, v16
	add.2d	v24, v23, v24
	tbz	w24, #4, LBB0_88
LBB0_95:                                ; %cond.load797
                                        ;   in Loop: Header=BB0_83 Depth=2
	fmov	x12, d24
	ld1.s	{ v21 }[0], [x12]
	tbz	w24, #5, LBB0_89
LBB0_96:                                ; %cond.load803
                                        ;   in Loop: Header=BB0_83 Depth=2
	mov.d	x12, v24[1]
	ld1.s	{ v21 }[1], [x12]
	add.2d	v22, v22, v6
	add.2d	v22, v23, v22
	tbz	w24, #6, LBB0_90
LBB0_97:                                ; %cond.load809
                                        ;   in Loop: Header=BB0_83 Depth=2
	fmov	x12, d22
	ld1.s	{ v21 }[2], [x12]
	tbz	w24, #7, LBB0_82
LBB0_98:                                ; %cond.load815
                                        ;   in Loop: Header=BB0_83 Depth=2
	mov.d	x12, v22[1]
	ld1.s	{ v21 }[3], [x12]
	b	LBB0_82
LBB0_99:                                ; %direct.false.i404.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q20, q19, [x9]
	fmul.4s	v20, v20, v20
	fmul.4s	v19, v19, v19
	ldp	q22, q21, [x9, #32]
	fmul.4s	v23, v22, v22
	fmul.4s	v21, v21, v21
	ldp	q24, q22, [x9, #64]
	fmul.4s	v25, v24, v24
	fmul.4s	v24, v22, v22
	ldp	q26, q22, [x9, #96]
	fmul.4s	v27, v26, v26
	fmul.4s	v28, v22, v22
	and.16b	v19, v4, v19
	and.16b	v22, v5, v20
	and.16b	v21, v4, v21
	and.16b	v26, v5, v23
	and.16b	v24, v4, v24
	and.16b	v23, v5, v25
	and.16b	v20, v4, v28
	and.16b	v25, v5, v27
	ldr	x21, [sp, #16]                  ; 8-byte Folded Reload
	mov	w22, #4                         ; =0x4
LBB0_100:                               ; %direct.true47.i412.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q28, q27, [x21, #-96]
	and.16b	v28, v5, v28
	and.16b	v27, v4, v27
	fmul.4s	v27, v27, v27
	fmul.4s	v28, v28, v28
	fadd.4s	v28, v22, v28
	fadd.4s	v27, v19, v27
	ldp	q30, q29, [x21, #-64]
	and.16b	v30, v5, v30
	and.16b	v29, v4, v29
	fmul.4s	v29, v29, v29
	fmul.4s	v30, v30, v30
	fadd.4s	v30, v26, v30
	fadd.4s	v29, v21, v29
	ldp	q8, q31, [x21, #-32]
	and.16b	v8, v5, v8
	and.16b	v31, v4, v31
	fmul.4s	v31, v31, v31
	fmul.4s	v8, v8, v8
	fadd.4s	v8, v23, v8
	fadd.4s	v31, v24, v31
	ldp	q10, q9, [x21], #128
	and.16b	v10, v5, v10
	and.16b	v9, v4, v9
	fmul.4s	v9, v9, v9
	fmul.4s	v10, v10, v10
	fadd.4s	v10, v25, v10
	fadd.4s	v9, v20, v9
	bit.16b	v19, v27, v4
	bit.16b	v22, v28, v5
	bit.16b	v21, v29, v4
	bit.16b	v26, v30, v5
	bit.16b	v24, v31, v4
	bit.16b	v23, v8, v5
	bit.16b	v20, v9, v4
	bit.16b	v25, v10, v5
	cmp	x22, #252
	add	x22, x22, #4
	b.lo	LBB0_100
; %bb.101:                              ; %direct.true94.i427.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x21, #0                         ; =0x0
LBB0_102:                               ; %direct.true94.i427.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x20, x21, lsl #2
	ld1r.4s	{ v27 }, [x12]
	add	x12, x14, x21, lsl #5
	ldp	q28, q29, [x12]
	bit.16b	v29, v27, v4
	bif.16b	v27, v28, v5
	stp	q27, q29, [x12]
	add	x21, x21, #1
	cmp	x21, #256
	b.ne	LBB0_102
; %bb.103:                              ; %direct.false95.i434.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x20, #0                         ; =0x0
	fadd.4s	v22, v22, v26
	fadd.4s	v19, v19, v21
	fadd.4s	v19, v19, v24
	fadd.4s	v21, v22, v23
	fadd.4s	v21, v21, v25
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v19, v3
	fmul.4s	v3, v21, v3
	fadd.4s	v3, v3, v2
	fadd.4s	v2, v19, v2
	fsqrt.4s	v19, v2
	fsqrt.4s	v2, v3
	and.16b	v2, v5, v2
	and.16b	v3, v4, v19
	add	x21, sp, #32
	add	x22, sp, #2, lsl #12            ; =8192
	add	x22, x22, #32
	b	LBB0_105
LBB0_104:                               ; %else852
                                        ;   in Loop: Header=BB0_105 Depth=2
	add	x20, x20, #4
	add	x21, x21, #32
	add	x22, x22, #32
	cmp	x20, #1024
	b.eq	LBB0_2
LBB0_105:                               ; %direct.true109.i435.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w23, s18
	ldp	q19, q21, [x22]
	and.16b	v19, v5, v19
	fdiv.4s	v19, v19, v2
	ldp	q20, q22, [x21]
	and.16b	v20, v5, v20
	fmul.4s	v23, v19, v20
	dup.2d	v19, x20
	add.2d	v24, v19, v17
	dup.2d	v20, x19
	add.2d	v24, v20, v24
	tbnz	w23, #0, LBB0_114
; %bb.106:                              ; %else824
                                        ;   in Loop: Header=BB0_105 Depth=2
	and	w23, w23, #0xff
	tbnz	w23, #1, LBB0_115
LBB0_107:                               ; %else828
                                        ;   in Loop: Header=BB0_105 Depth=2
	add.2d	v24, v19, v7
	add.2d	v24, v20, v24
	tbnz	w23, #2, LBB0_116
LBB0_108:                               ; %else832
                                        ;   in Loop: Header=BB0_105 Depth=2
	tbz	w23, #3, LBB0_110
LBB0_109:                               ; %cond.store833
                                        ;   in Loop: Header=BB0_105 Depth=2
	mov.d	x12, v24[1]
	st1.s	{ v23 }[3], [x12]
LBB0_110:                               ; %else836
                                        ;   in Loop: Header=BB0_105 Depth=2
	and.16b	v21, v4, v21
	fdiv.4s	v21, v21, v3
	and.16b	v22, v4, v22
	fmul.4s	v21, v21, v22
	add.2d	v22, v19, v16
	add.2d	v22, v20, v22
	tbnz	w23, #4, LBB0_117
; %bb.111:                              ; %else840
                                        ;   in Loop: Header=BB0_105 Depth=2
	tbnz	w23, #5, LBB0_118
LBB0_112:                               ; %else844
                                        ;   in Loop: Header=BB0_105 Depth=2
	add.2d	v19, v19, v6
	add.2d	v19, v20, v19
	tbnz	w23, #6, LBB0_119
LBB0_113:                               ; %else848
                                        ;   in Loop: Header=BB0_105 Depth=2
	tbz	w23, #7, LBB0_104
	b	LBB0_120
LBB0_114:                               ; %cond.store
                                        ;   in Loop: Header=BB0_105 Depth=2
	fmov	x12, d24
	str	s23, [x12]
	and	w23, w23, #0xff
	tbz	w23, #1, LBB0_107
LBB0_115:                               ; %cond.store825
                                        ;   in Loop: Header=BB0_105 Depth=2
	mov.d	x12, v24[1]
	st1.s	{ v23 }[1], [x12]
	add.2d	v24, v19, v7
	add.2d	v24, v20, v24
	tbz	w23, #2, LBB0_108
LBB0_116:                               ; %cond.store829
                                        ;   in Loop: Header=BB0_105 Depth=2
	fmov	x12, d24
	st1.s	{ v23 }[2], [x12]
	tbnz	w23, #3, LBB0_109
	b	LBB0_110
LBB0_117:                               ; %cond.store837
                                        ;   in Loop: Header=BB0_105 Depth=2
	fmov	x12, d22
	str	s21, [x12]
	tbz	w23, #5, LBB0_112
LBB0_118:                               ; %cond.store841
                                        ;   in Loop: Header=BB0_105 Depth=2
	mov.d	x12, v22[1]
	st1.s	{ v21 }[1], [x12]
	add.2d	v19, v19, v6
	add.2d	v19, v20, v19
	tbz	w23, #6, LBB0_113
LBB0_119:                               ; %cond.store845
                                        ;   in Loop: Header=BB0_105 Depth=2
	fmov	x12, d19
	st1.s	{ v21 }[2], [x12]
	tbz	w23, #7, LBB0_104
LBB0_120:                               ; %cond.store849
                                        ;   in Loop: Header=BB0_105 Depth=2
	mov.d	x12, v19[1]
	st1.s	{ v21 }[3], [x12]
	b	LBB0_104
LBB0_121:                               ; %block.batch.exit.loopexit
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	stp	w7, w6, [x9]
	str	w5, [x9, #8]
	mov	w8, #56                         ; =0x38
	str	w8, [x9, #36]
	add	sp, sp, #4, lsl #12             ; =16384
	add	sp, sp, #32
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp], #128            ; 16-byte Folded Reload
LBB0_122:                               ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
.subsections_via_symbols

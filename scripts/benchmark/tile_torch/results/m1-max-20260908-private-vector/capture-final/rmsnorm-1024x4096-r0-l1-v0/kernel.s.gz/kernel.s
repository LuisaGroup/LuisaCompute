	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_1:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_2:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_3:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_4:
	.quad	56                              ; 0x38
	.quad	60                              ; 0x3c
lCPI0_5:
	.quad	48                              ; 0x30
	.quad	52                              ; 0x34
lCPI0_6:
	.quad	40                              ; 0x28
	.quad	44                              ; 0x2c
lCPI0_7:
	.quad	32                              ; 0x20
	.quad	36                              ; 0x24
lCPI0_8:
	.quad	88                              ; 0x58
	.quad	92                              ; 0x5c
lCPI0_9:
	.quad	80                              ; 0x50
	.quad	84                              ; 0x54
lCPI0_10:
	.quad	72                              ; 0x48
	.quad	76                              ; 0x4c
lCPI0_11:
	.quad	64                              ; 0x40
	.quad	68                              ; 0x44
lCPI0_12:
	.quad	120                             ; 0x78
	.quad	124                             ; 0x7c
lCPI0_13:
	.quad	112                             ; 0x70
	.quad	116                             ; 0x74
lCPI0_14:
	.quad	104                             ; 0x68
	.quad	108                             ; 0x6c
lCPI0_15:
	.quad	96                              ; 0x60
	.quad	100                             ; 0x64
lCPI0_16:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_17:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_18:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #496
	str	x0, [sp, #216]                  ; 8-byte Folded Spill
	str	w3, [sp, #236]                  ; 4-byte Folded Spill
	cbz	w3, LBB0_260
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x1, x2
	mov	w8, #0                          ; =0x0
	ldp	w0, w9, [x2, #44]
	str	w9, [sp, #232]                  ; 4-byte Folded Spill
	ldp	w9, w10, [x2]
Lloh0:
	adrp	x11, lCPI0_0@PAGE
Lloh1:
	ldr	q0, [x11, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x11, lCPI0_1@PAGE
Lloh3:
	ldr	q1, [x11, lCPI0_1@PAGEOFF]
Lloh4:
	adrp	x11, lCPI0_2@PAGE
Lloh5:
	ldr	q2, [x11, lCPI0_2@PAGEOFF]
Lloh6:
	adrp	x11, lCPI0_3@PAGE
Lloh7:
	ldr	q3, [x11, lCPI0_3@PAGEOFF]
Lloh8:
	adrp	x11, lCPI0_4@PAGE
Lloh9:
	ldr	q4, [x11, lCPI0_4@PAGEOFF]
	str	q4, [sp, #192]                  ; 16-byte Folded Spill
Lloh10:
	adrp	x11, lCPI0_5@PAGE
Lloh11:
	ldr	q4, [x11, lCPI0_5@PAGEOFF]
	str	q4, [sp, #176]                  ; 16-byte Folded Spill
Lloh12:
	adrp	x11, lCPI0_6@PAGE
Lloh13:
	ldr	q4, [x11, lCPI0_6@PAGEOFF]
	str	q4, [sp, #160]                  ; 16-byte Folded Spill
Lloh14:
	adrp	x11, lCPI0_7@PAGE
Lloh15:
	ldr	q4, [x11, lCPI0_7@PAGEOFF]
	str	q4, [sp, #144]                  ; 16-byte Folded Spill
Lloh16:
	adrp	x11, lCPI0_8@PAGE
Lloh17:
	ldr	q4, [x11, lCPI0_8@PAGEOFF]
	str	q4, [sp, #128]                  ; 16-byte Folded Spill
Lloh18:
	adrp	x11, lCPI0_9@PAGE
Lloh19:
	ldr	q4, [x11, lCPI0_9@PAGEOFF]
	str	q4, [sp, #112]                  ; 16-byte Folded Spill
Lloh20:
	adrp	x11, lCPI0_10@PAGE
Lloh21:
	ldr	q4, [x11, lCPI0_10@PAGEOFF]
	str	q4, [sp, #96]                   ; 16-byte Folded Spill
Lloh22:
	adrp	x11, lCPI0_11@PAGE
Lloh23:
	ldr	q4, [x11, lCPI0_11@PAGEOFF]
	str	q4, [sp, #80]                   ; 16-byte Folded Spill
Lloh24:
	adrp	x11, lCPI0_12@PAGE
Lloh25:
	ldr	q4, [x11, lCPI0_12@PAGEOFF]
	str	q4, [sp, #64]                   ; 16-byte Folded Spill
Lloh26:
	adrp	x11, lCPI0_13@PAGE
Lloh27:
	ldr	q4, [x11, lCPI0_13@PAGEOFF]
	str	q4, [sp, #48]                   ; 16-byte Folded Spill
Lloh28:
	adrp	x11, lCPI0_14@PAGE
Lloh29:
	ldr	q4, [x11, lCPI0_14@PAGEOFF]
	str	q4, [sp, #32]                   ; 16-byte Folded Spill
Lloh30:
	adrp	x11, lCPI0_15@PAGE
Lloh31:
	ldr	q4, [x11, lCPI0_15@PAGEOFF]
	str	q4, [sp, #16]                   ; 16-byte Folded Spill
Lloh32:
	adrp	x11, lCPI0_16@PAGE
Lloh33:
	ldr	q4, [x11, lCPI0_16@PAGEOFF]
	str	q4, [sp, #432]                  ; 16-byte Folded Spill
Lloh34:
	adrp	x11, lCPI0_17@PAGE
Lloh35:
	ldr	q4, [x11, lCPI0_17@PAGEOFF]
	str	q4, [sp, #416]                  ; 16-byte Folded Spill
	ldp	w11, w12, [x2, #8]
	str	x12, [sp, #224]                 ; 8-byte Folded Spill
	str	x2, [sp, #208]                  ; 8-byte Folded Spill
	str	w0, [sp, #12]                   ; 4-byte Folded Spill
	b	LBB0_3
LBB0_2:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x15, [sp, #248]                 ; 8-byte Folded Reload
	add	w9, w15, #1
	cmp	w9, w0
	cset	w10, eq
	csinc	w9, wzr, w15, eq
	ldp	w14, w13, [sp, #240]            ; 8-byte Folded Reload
	cinc	w11, w14, eq
	ldr	w12, [sp, #232]                 ; 4-byte Folded Reload
	cmp	w11, w12
	cset	w12, eq
	ands	w12, w10, w12
	csel	w10, wzr, w11, ne
	add	w11, w13, w12
	add	w8, w8, #1
	ldr	w12, [sp, #236]                 ; 4-byte Folded Reload
	cmp	w8, w12
	b.eq	LBB0_259
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_16 Depth 2
                                        ;       Child Loop BB0_17 Depth 3
                                        ;       Child Loop BB0_19 Depth 3
                                        ;       Child Loop BB0_21 Depth 3
                                        ;       Child Loop BB0_23 Depth 3
                                        ;     Child Loop BB0_29 Depth 2
                                        ;     Child Loop BB0_99 Depth 2
                                        ;     Child Loop BB0_165 Depth 2
                                        ;     Child Loop BB0_183 Depth 2
                                        ;     Child Loop BB0_5 Depth 2
                                        ;       Child Loop BB0_6 Depth 3
                                        ;       Child Loop BB0_8 Depth 3
                                        ;       Child Loop BB0_10 Depth 3
                                        ;       Child Loop BB0_12 Depth 3
	mov	x14, x11
	mov	x15, x10
	mov	x16, x9
	ubfiz	x9, x9, #10, #32
	ldr	x13, [sp, #224]                 ; 8-byte Folded Reload
	cmp	x9, x13
	csel	x10, x9, xzr, ls
	subs	x11, x13, x10
	cmp	x11, #1024
	mov	w12, #1024                      ; =0x400
	csel	x11, x11, x12, lo
	cmp	x13, x10
	ccmp	x9, x13, #2, hi
	csel	x19, x11, xzr, ls
	mov	w9, #964689920                  ; =0x39800000
	dup.4s	v5, w9
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	dup.4s	v4, w9
	stp	q5, q4, [sp, #448]              ; 32-byte Folded Spill
	cmp	x19, #1024
	stp	w15, w14, [sp, #240]            ; 8-byte Folded Spill
	str	x16, [sp, #248]                 ; 8-byte Folded Spill
	b.lo	LBB0_14
; %bb.4:                                ; %packet.batch.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w7, #0                          ; =0x0
	ldr	x9, [x1, #136]
	add	x19, x9, #32, lsl #12           ; =131072
	ldr	x11, [sp, #216]                 ; 8-byte Folded Reload
	ldr	x10, [x11]
	ldr	x20, [x11, #16]
	ldr	x21, [x11, #48]
	lsl	w22, w16, #10
	dup.2d	v4, x9
	add.2d	v5, v4, v0
	str	q5, [sp, #400]                  ; 16-byte Folded Spill
	add.2d	v6, v4, v1
	add.2d	v5, v4, v2
	str	q5, [sp, #368]                  ; 16-byte Folded Spill
	add.2d	v7, v4, v3
	ldr	q5, [sp, #192]                  ; 16-byte Folded Reload
	add.2d	v17, v4, v5
	ldr	q5, [sp, #176]                  ; 16-byte Folded Reload
	add.2d	v16, v4, v5
	ldr	q5, [sp, #160]                  ; 16-byte Folded Reload
	add.2d	v19, v4, v5
	ldr	q5, [sp, #144]                  ; 16-byte Folded Reload
	add.2d	v18, v4, v5
	ldr	q5, [sp, #128]                  ; 16-byte Folded Reload
	add.2d	v21, v4, v5
	ldr	q5, [sp, #112]                  ; 16-byte Folded Reload
	add.2d	v20, v4, v5
	ldr	q5, [sp, #96]                   ; 16-byte Folded Reload
	add.2d	v23, v4, v5
	ldr	q5, [sp, #80]                   ; 16-byte Folded Reload
	add.2d	v22, v4, v5
	ldr	q5, [sp, #64]                   ; 16-byte Folded Reload
	add.2d	v29, v4, v5
	ldr	q5, [sp, #48]                   ; 16-byte Folded Reload
	add.2d	v24, v4, v5
	ldr	q5, [sp, #32]                   ; 16-byte Folded Reload
	add.2d	v31, v4, v5
	ldr	q5, [sp, #16]                   ; 16-byte Folded Reload
	add.2d	v5, v4, v5
	stp	q16, q7, [sp, #336]             ; 32-byte Folded Spill
	fmov	x23, d7
	str	q6, [sp, #384]                  ; 16-byte Folded Spill
	fmov	x24, d6
	stp	q20, q18, [sp, #304]            ; 32-byte Folded Spill
	fmov	x25, d18
	fmov	x26, d16
	dup.2d	v9, x10
	stp	q24, q22, [sp, #272]            ; 32-byte Folded Spill
	fmov	x15, d22
	fmov	x16, d20
	str	q5, [sp, #256]                  ; 16-byte Folded Spill
	fmov	x11, d5
	fmov	x17, d24
LBB0_5:                                 ; %packet.batch.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_6 Depth 3
                                        ;       Child Loop BB0_8 Depth 3
                                        ;       Child Loop BB0_10 Depth 3
                                        ;       Child Loop BB0_12 Depth 3
	mov	x9, #0                          ; =0x0
	add	w10, w22, w7, lsl #3
	dup.4s	v6, w10
	ldp	q5, q7, [sp, #416]              ; 32-byte Folded Reload
	orr.16b	v16, v6, v7
	orr.16b	v6, v6, v5
	ushll2.2d	v10, v16, #14
	ushll2.2d	v11, v6, #14
	ushll.2d	v12, v16, #14
	ushll.2d	v13, v6, #14
	add.2d	v6, v9, v10
	add.2d	v16, v9, v12
	add.2d	v18, v9, v11
	add.2d	v20, v9, v13
LBB0_6:                                 ; %direct.true.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_5 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	dup.2d	v22, x9
	shl.2d	v24, v22, #2
	add.2d	v25, v6, v24
	add.2d	v26, v16, v24
	add.2d	v27, v18, v24
	add.2d	v24, v20, v24
	mov.d	x10, v24[1]
	fmov	x12, d24
	ldr	s24, [x12]
	mov.d	x12, v27[1]
	ldr	s28, [x10]
	fmov	x10, d27
	ldr	s27, [x10]
	ldr	s14, [x12]
	mov.d	x10, v26[1]
	fmov	x12, d26
	ldr	s26, [x12]
	ldr	s15, [x10]
	mov.d	x10, v25[1]
	fmov	x12, d25
	ldr	s25, [x12]
	ldr	s30, [x10]
	shl.2d	v22, v22, #5
	add.2d	v22, v4, v22
	add.2d	v8, v22, v0
	add.2d	v5, v22, v1
	add.2d	v7, v22, v2
	add.2d	v22, v22, v3
	mov.d	x10, v22[1]
	fmov	x12, d22
	str	s24, [x12]
	str	s28, [x10]
	mov.d	x10, v7[1]
	fmov	x12, d7
	str	s27, [x12]
	str	s14, [x10]
	mov.d	x10, v5[1]
	fmov	x12, d5
	str	s26, [x12]
	mov.d	x12, v8[1]
	str	s15, [x10]
	fmov	x10, d8
	str	s25, [x10]
	str	s30, [x12]
	add	x9, x9, #1
	cmp	x9, #1, lsl #12                 ; =4096
	b.ne	LBB0_6
; %bb.7:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB0_5 Depth=2
	mov	x27, #0                         ; =0x0
	ldp	q5, q6, [sp, #352]              ; 32-byte Folded Reload
	mov.d	x9, v5[1]
	mov.d	x10, v6[1]
	ldp	q7, q5, [sp, #384]              ; 32-byte Folded Reload
	mov.d	x12, v7[1]
	fmov	x13, d5
	mov.d	x2, v5[1]
	ldr	s5, [x24]
	ld1.s	{ v5 }[1], [x12]
	ld1.s	{ v5 }[2], [x13]
	ld1.s	{ v5 }[3], [x2]
	fmov	x12, d6
	ldr	s6, [x23]
	ld1.s	{ v6 }[1], [x9]
	ld1.s	{ v6 }[2], [x12]
	ld1.s	{ v6 }[3], [x10]
	fmul.4s	v14, v6, v6
	ldp	q7, q6, [sp, #320]              ; 32-byte Folded Reload
	mov.d	x9, v7[1]
	mov.d	x10, v19[1]
	mov.d	x12, v6[1]
	mov.d	x13, v17[1]
	fmov	x2, d17
	ldr	s6, [x26]
	ld1.s	{ v6 }[1], [x12]
	ld1.s	{ v6 }[2], [x2]
	fmul.4s	v15, v5, v5
	ld1.s	{ v6 }[3], [x13]
	ldr	s5, [x25]
	ld1.s	{ v5 }[1], [x9]
	fmov	x9, d19
	ld1.s	{ v5 }[2], [x9]
	ld1.s	{ v5 }[3], [x10]
	fmul.4s	v24, v5, v5
	ldp	q7, q5, [sp, #288]              ; 32-byte Folded Reload
	mov.d	x9, v7[1]
	mov.d	x10, v23[1]
	mov.d	x12, v5[1]
	fmov	x13, d23
	mov.d	x2, v21[1]
	ldr	s5, [x16]
	ld1.s	{ v5 }[1], [x12]
	fmov	x12, d21
	ld1.s	{ v5 }[2], [x12]
	ld1.s	{ v5 }[3], [x2]
	ldr	s7, [x15]
	ld1.s	{ v7 }[1], [x9]
	ld1.s	{ v7 }[2], [x13]
	ld1.s	{ v7 }[3], [x10]
	fmul.4s	v27, v6, v6
	fmul.4s	v25, v7, v7
	fmul.4s	v26, v5, v5
	ldr	q5, [sp, #256]                  ; 16-byte Folded Reload
	mov.d	x9, v5[1]
	fmov	x10, d31
	mov.d	x12, v31[1]
	ldr	q5, [sp, #272]                  ; 16-byte Folded Reload
	mov.d	x13, v5[1]
	mov.d	x2, v29[1]
	ldr	s5, [x17]
	ld1.s	{ v5 }[1], [x13]
	ldr	s6, [x11]
	ld1.s	{ v6 }[1], [x9]
	fmov	x9, d29
	ld1.s	{ v6 }[2], [x10]
	ld1.s	{ v6 }[3], [x12]
	fmul.4s	v6, v6, v6
	ld1.s	{ v5 }[2], [x9]
	ld1.s	{ v5 }[3], [x2]
	fmul.4s	v16, v5, v5
	mov	w12, #224                       ; =0xe0
LBB0_8:                                 ; %direct.true41.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_5 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sub	x9, x12, #96
	dup.2d	v5, x9
	add.2d	v5, v4, v5
	add.2d	v7, v5, v0
	add.2d	v18, v5, v1
	add.2d	v20, v5, v2
	add.2d	v5, v5, v3
	mov.d	x2, v5[1]
	fmov	x13, d5
	mov.d	x9, v20[1]
	fmov	x3, d20
	mov.d	x5, v18[1]
	fmov	x28, d18
	mov.d	x10, v7[1]
	fmov	x4, d7
	sub	x30, x12, #64
	ldr	s18, [x28]
	dup.2d	v5, x30
	add.2d	v5, v4, v5
	add.2d	v7, v5, v0
	add.2d	v22, v5, v1
	ldr	s20, [x13]
	add.2d	v28, v5, v2
	add.2d	v5, v5, v3
	mov.d	x28, v5[1]
	ld1.s	{ v18 }[1], [x5]
	mov.d	x13, v28[1]
	mov.d	x5, v22[1]
	ld1.s	{ v20 }[1], [x2]
	fmov	x30, d5
	fmov	x2, d22
	ldr	s22, [x2]
	fmov	x14, d28
	ld1.s	{ v22 }[1], [x5]
	mov.d	x2, v7[1]
	ldr	s28, [x30]
	sub	x5, x12, #32
	ld1.s	{ v28 }[1], [x28]
	dup.2d	v5, x5
	fmov	x5, d7
	add.2d	v5, v4, v5
	ld1.s	{ v18 }[2], [x4]
	add.2d	v7, v5, v0
	add.2d	v30, v5, v1
	add.2d	v8, v5, v2
	add.2d	v5, v5, v3
	ld1.s	{ v20 }[2], [x3]
	mov.d	x3, v5[1]
	mov.d	x4, v30[1]
	ld1.s	{ v22 }[2], [x5]
	fmov	x5, d30
	ldr	s30, [x5]
	mov.d	x5, v7[1]
	ld1.s	{ v28 }[2], [x14]
	fmov	x14, d5
	ld1.s	{ v30 }[1], [x4]
	fmov	x4, d7
	ld1.s	{ v30 }[2], [x4]
	mov.d	x4, v8[1]
	ldr	s5, [x14]
	fmov	x14, d8
	ld1.s	{ v18 }[3], [x10]
	ld1.s	{ v5 }[1], [x3]
	dup.2d	v7, x12
	ld1.s	{ v20 }[3], [x9]
	add.2d	v7, v4, v7
	add.2d	v8, v7, v3
	mov.d	x9, v8[1]
	ld1.s	{ v22 }[3], [x2]
	fmov	x10, d8
	add.2d	v8, v7, v2
	mov.d	x2, v8[1]
	ld1.s	{ v28 }[3], [x13]
	fmov	x13, d8
	add.2d	v8, v7, v1
	mov.d	x3, v8[1]
	ld1.s	{ v30 }[3], [x5]
	fmov	x5, d8
	fmul.4s	v20, v20, v20
	fmul.4s	v18, v18, v18
	ld1.s	{ v5 }[2], [x14]
	fadd.4s	v15, v15, v18
	ld1.s	{ v5 }[3], [x4]
	add.2d	v7, v7, v0
	mov.d	x14, v7[1]
	fadd.4s	v14, v14, v20
	fmov	x4, d7
	fmul.4s	v7, v28, v28
	fmul.4s	v18, v22, v22
	fmul.4s	v5, v5, v5
	fmul.4s	v20, v30, v30
	fadd.4s	v27, v27, v18
	ldr	s18, [x5]
	ld1.s	{ v18 }[1], [x3]
	ld1.s	{ v18 }[2], [x4]
	fadd.4s	v24, v24, v7
	ld1.s	{ v18 }[3], [x14]
	ldr	s7, [x10]
	ld1.s	{ v7 }[1], [x9]
	fadd.4s	v26, v26, v20
	ld1.s	{ v7 }[2], [x13]
	ld1.s	{ v7 }[3], [x2]
	fmul.4s	v7, v7, v7
	fadd.4s	v25, v25, v5
	fmul.4s	v5, v18, v18
	fadd.4s	v16, v16, v5
	fadd.4s	v6, v6, v7
	add	x27, x27, #4
	add	x12, x12, #128
	cmp	x27, #4092
	b.lo	LBB0_8
; %bb.9:                                ; %direct.true80.i.i.preheader
                                        ;   in Loop: Header=BB0_5 Depth=2
	mov	x9, #0                          ; =0x0
	mov	x10, x20
LBB0_10:                                ; %direct.true80.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_5 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	s5, [x10], #4
	dup.2d	v7, x9
	dup.2d	v18, x19
	add.2d	v7, v18, v7
	add.2d	v20, v7, v0
	add.2d	v22, v7, v1
	add.2d	v28, v7, v2
	add.2d	v7, v7, v3
	mov.d	x12, v7[1]
	fmov	x13, d7
	str	s5, [x13]
	str	s5, [x12]
	mov.d	x12, v28[1]
	fmov	x13, d28
	str	s5, [x13]
	str	s5, [x12]
	mov.d	x12, v22[1]
	fmov	x13, d22
	str	s5, [x13]
	mov.d	x13, v20[1]
	str	s5, [x12]
	fmov	x12, d20
	str	s5, [x12]
	str	s5, [x13]
	add	x9, x9, #32
	cmp	x9, #32, lsl #12                ; =131072
	b.ne	LBB0_10
; %bb.11:                               ; %direct.false81.i.i
                                        ;   in Loop: Header=BB0_5 Depth=2
	mov	x12, #0                         ; =0x0
	fadd.4s	v5, v15, v27
	fadd.4s	v7, v14, v24
	fadd.4s	v7, v7, v25
	fadd.4s	v5, v5, v26
	fadd.4s	v5, v5, v16
	fadd.4s	v6, v7, v6
	ldr	q7, [sp, #448]                  ; 16-byte Folded Reload
	fmul.4s	v6, v6, v7
	fmul.4s	v5, v5, v7
	ldr	q7, [sp, #464]                  ; 16-byte Folded Reload
	fadd.4s	v5, v5, v7
	fadd.4s	v6, v6, v7
	fsqrt.4s	v6, v6
	fsqrt.4s	v16, v5
LBB0_12:                                ; %direct.true93.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_5 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	dup.2d	v20, x12
	shl.2d	v5, v20, #5
	orr.16b	v7, v5, v3
	orr.16b	v22, v5, v2
	orr.16b	v24, v5, v1
	orr.16b	v5, v5, v0
	add.2d	v25, v4, v5
	add.2d	v26, v4, v24
	add.2d	v27, v4, v22
	add.2d	v28, v4, v7
	mov.d	x9, v28[1]
	fmov	x10, d28
	mov.d	x13, v27[1]
	fmov	x14, d27
	mov.d	x2, v26[1]
	fmov	x3, d26
	mov.d	x4, v25[1]
	fmov	x5, d25
	ldr	s25, [x3]
	ld1.s	{ v25 }[1], [x2]
	ldr	s26, [x10]
	add.2d	v5, v18, v5
	add.2d	v24, v18, v24
	add.2d	v22, v18, v22
	ld1.s	{ v26 }[1], [x9]
	add.2d	v7, v18, v7
	mov.d	x9, v7[1]
	fmov	x10, d7
	ld1.s	{ v25 }[2], [x5]
	mov.d	x2, v22[1]
	mov.d	x3, v24[1]
	ld1.s	{ v26 }[2], [x14]
	fmov	x14, d22
	mov.d	x5, v5[1]
	ldr	s7, [x10]
	ld1.s	{ v25 }[3], [x4]
	ld1.s	{ v7 }[1], [x9]
	ld1.s	{ v7 }[2], [x14]
	ld1.s	{ v26 }[3], [x13]
	fmov	x9, d24
	ldr	s22, [x9]
	ld1.s	{ v22 }[1], [x3]
	ld1.s	{ v7 }[3], [x2]
	fmov	x9, d5
	ld1.s	{ v22 }[2], [x9]
	ld1.s	{ v22 }[3], [x5]
	fdiv.4s	v5, v26, v6
	fdiv.4s	v24, v25, v16
	shl.2d	v20, v20, #2
	dup.2d	v25, x21
	add.2d	v26, v25, v10
	fmul.4s	v22, v24, v22
	add.2d	v24, v26, v20
	add.2d	v26, v25, v12
	add.2d	v27, v25, v11
	add.2d	v25, v25, v13
	add.2d	v25, v25, v20
	fmul.4s	v5, v5, v7
	mov.d	x9, v25[1]
	fmov	x10, d25
	str	s5, [x10]
	st1.s	{ v5 }[1], [x9]
	add.2d	v7, v27, v20
	mov.d	x9, v7[1]
	fmov	x10, d7
	st1.s	{ v5 }[2], [x10]
	add.2d	v7, v26, v20
	mov.d	x10, v7[1]
	fmov	x13, d7
	st1.s	{ v5 }[3], [x9]
	str	s22, [x13]
	mov.d	x9, v24[1]
	fmov	x13, d24
	st1.s	{ v22 }[1], [x10]
	st1.s	{ v22 }[2], [x13]
	st1.s	{ v22 }[3], [x9]
	add	x12, x12, #1
	cmp	x12, #1, lsl #12                ; =4096
	b.ne	LBB0_12
; %bb.13:                               ; %llm_rows.exit.i
                                        ;   in Loop: Header=BB0_5 Depth=2
	add	w7, w7, #1
	cmp	w7, #128
	b.ne	LBB0_5
	b	LBB0_2
LBB0_14:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	lsr	x7, x19, #3
	cmp	x19, #8
	b.lo	LBB0_25
; %bb.15:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w20, #0                         ; =0x0
	ldr	x9, [sp, #208]                  ; 8-byte Folded Reload
	ldr	x9, [x9, #136]
	dup.2d	v4, x9
	add.2d	v5, v4, v0
	str	q5, [sp, #400]                  ; 16-byte Folded Spill
	add	x21, x9, #32, lsl #12           ; =131072
	add.2d	v6, v4, v1
	add.2d	v7, v4, v2
	add.2d	v16, v4, v3
	ldr	x9, [sp, #216]                  ; 8-byte Folded Reload
	ldr	x22, [x9]
	ldr	x23, [x9, #16]
	ldr	x24, [x9, #48]
	ldr	q5, [sp, #192]                  ; 16-byte Folded Reload
	add.2d	v17, v4, v5
	ldr	q5, [sp, #176]                  ; 16-byte Folded Reload
	add.2d	v18, v4, v5
	ldr	q5, [sp, #160]                  ; 16-byte Folded Reload
	add.2d	v19, v4, v5
	ldr	x9, [sp, #248]                  ; 8-byte Folded Reload
	lsl	w25, w9, #10
	ldr	q5, [sp, #144]                  ; 16-byte Folded Reload
	add.2d	v20, v4, v5
	ldr	q5, [sp, #128]                  ; 16-byte Folded Reload
	add.2d	v21, v4, v5
	ldr	q5, [sp, #112]                  ; 16-byte Folded Reload
	add.2d	v22, v4, v5
	ldr	q5, [sp, #96]                   ; 16-byte Folded Reload
	add.2d	v23, v4, v5
	ldr	q5, [sp, #80]                   ; 16-byte Folded Reload
	add.2d	v24, v4, v5
	ldr	q5, [sp, #64]                   ; 16-byte Folded Reload
	add.2d	v29, v4, v5
	ldr	q5, [sp, #48]                   ; 16-byte Folded Reload
	add.2d	v25, v4, v5
	ldr	q5, [sp, #32]                   ; 16-byte Folded Reload
	add.2d	v31, v4, v5
	stp	q16, q6, [sp, #368]             ; 32-byte Folded Spill
	fmov	x26, d16
	fmov	x27, d6
	stp	q20, q18, [sp, #336]            ; 32-byte Folded Spill
	fmov	x28, d20
	fmov	x30, d18
	ldr	q5, [sp, #16]                   ; 16-byte Folded Reload
	add.2d	v5, v4, v5
	stp	q24, q22, [sp, #304]            ; 32-byte Folded Spill
	fmov	x15, d24
	fmov	x16, d22
	stp	q5, q25, [sp, #272]             ; 32-byte Folded Spill
	fmov	x17, d5
	fmov	x11, d25
LBB0_16:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_17 Depth 3
                                        ;       Child Loop BB0_19 Depth 3
                                        ;       Child Loop BB0_21 Depth 3
                                        ;       Child Loop BB0_23 Depth 3
	mov	x9, #0                          ; =0x0
	add	w10, w25, w20, lsl #3
	dup.4s	v6, w10
	ldr	q5, [sp, #432]                  ; 16-byte Folded Reload
	orr.16b	v16, v6, v5
	ldr	q5, [sp, #416]                  ; 16-byte Folded Reload
	orr.16b	v6, v6, v5
	ushll2.2d	v9, v16, #14
	ushll2.2d	v10, v6, #14
	ushll.2d	v11, v16, #14
	ushll.2d	v12, v6, #14
LBB0_17:                                ; %direct.true.i10.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_16 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	dup.2d	v6, x9
	shl.2d	v16, v6, #2
	dup.2d	v18, x22
	add.2d	v20, v18, v9
	add.2d	v20, v20, v16
	add.2d	v22, v18, v11
	add.2d	v22, v22, v16
	add.2d	v24, v18, v10
	add.2d	v24, v24, v16
	add.2d	v18, v18, v12
	add.2d	v16, v18, v16
	mov.d	x10, v16[1]
	fmov	x12, d16
	ldr	s16, [x12]
	mov.d	x12, v24[1]
	ldr	s18, [x10]
	fmov	x10, d24
	ldr	s24, [x10]
	ldr	s25, [x12]
	mov.d	x10, v22[1]
	fmov	x12, d22
	ldr	s22, [x12]
	ldr	s26, [x10]
	mov.d	x10, v20[1]
	fmov	x12, d20
	ldr	s20, [x12]
	ldr	s27, [x10]
	shl.2d	v6, v6, #5
	add.2d	v6, v4, v6
	add.2d	v13, v6, v0
	add.2d	v14, v6, v1
	add.2d	v15, v6, v2
	add.2d	v6, v6, v3
	mov.d	x10, v6[1]
	fmov	x12, d6
	str	s16, [x12]
	str	s18, [x10]
	mov.d	x10, v15[1]
	fmov	x12, d15
	str	s24, [x12]
	str	s25, [x10]
	mov.d	x10, v14[1]
	fmov	x12, d14
	str	s22, [x12]
	mov.d	x12, v13[1]
	str	s26, [x10]
	fmov	x10, d13
	str	s20, [x10]
	str	s27, [x12]
	add	x9, x9, #1
	cmp	x9, #1, lsl #12                 ; =4096
	b.ne	LBB0_17
; %bb.18:                               ; %direct.false.i15.i
                                        ;   in Loop: Header=BB0_16 Depth=2
	mov	x12, #0                         ; =0x0
	ldp	q6, q5, [sp, #368]              ; 32-byte Folded Reload
	mov.d	x9, v6[1]
	mov.d	x10, v7[1]
	mov.d	x13, v5[1]
	ldr	q5, [sp, #400]                  ; 16-byte Folded Reload
	fmov	x14, d5
	mov.d	x2, v5[1]
	ldr	s6, [x27]
	ld1.s	{ v6 }[1], [x13]
	ld1.s	{ v6 }[2], [x14]
	ld1.s	{ v6 }[3], [x2]
	fmov	x13, d7
	ldr	s16, [x26]
	ld1.s	{ v16 }[1], [x9]
	ld1.s	{ v16 }[2], [x13]
	ld1.s	{ v16 }[3], [x10]
	fmul.4s	v13, v16, v16
	ldr	q5, [sp, #336]                  ; 16-byte Folded Reload
	mov.d	x9, v5[1]
	mov.d	x10, v19[1]
	ldr	q5, [sp, #352]                  ; 16-byte Folded Reload
	mov.d	x13, v5[1]
	mov.d	x14, v17[1]
	fmov	x2, d17
	ldr	s16, [x30]
	ld1.s	{ v16 }[1], [x13]
	ld1.s	{ v16 }[2], [x2]
	fmul.4s	v14, v6, v6
	ld1.s	{ v16 }[3], [x14]
	ldr	s6, [x28]
	ld1.s	{ v6 }[1], [x9]
	fmov	x9, d19
	ld1.s	{ v6 }[2], [x9]
	ld1.s	{ v6 }[3], [x10]
	fmul.4s	v24, v6, v6
	ldr	q5, [sp, #304]                  ; 16-byte Folded Reload
	mov.d	x9, v5[1]
	mov.d	x10, v23[1]
	ldr	q5, [sp, #320]                  ; 16-byte Folded Reload
	mov.d	x13, v5[1]
	fmov	x14, d23
	mov.d	x2, v21[1]
	ldr	s6, [x16]
	ld1.s	{ v6 }[1], [x13]
	fmov	x13, d21
	ld1.s	{ v6 }[2], [x13]
	ld1.s	{ v6 }[3], [x2]
	ldr	s18, [x15]
	ld1.s	{ v18 }[1], [x9]
	ld1.s	{ v18 }[2], [x14]
	ld1.s	{ v18 }[3], [x10]
	fmul.4s	v27, v16, v16
	fmul.4s	v25, v18, v18
	fmul.4s	v26, v6, v6
	ldr	q5, [sp, #272]                  ; 16-byte Folded Reload
	mov.d	x9, v5[1]
	fmov	x10, d31
	mov.d	x13, v31[1]
	ldr	q5, [sp, #288]                  ; 16-byte Folded Reload
	mov.d	x14, v5[1]
	mov.d	x2, v29[1]
	ldr	s6, [x11]
	ld1.s	{ v6 }[1], [x14]
	ldr	s16, [x17]
	ld1.s	{ v16 }[1], [x9]
	fmov	x9, d29
	ld1.s	{ v16 }[2], [x10]
	ld1.s	{ v16 }[3], [x13]
	fmul.4s	v15, v16, v16
	ld1.s	{ v6 }[2], [x9]
	ld1.s	{ v6 }[3], [x2]
	fmul.4s	v6, v6, v6
	mov	w13, #224                       ; =0xe0
LBB0_19:                                ; %direct.true41.i16.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_16 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sub	x9, x13, #96
	dup.2d	v16, x9
	add.2d	v16, v4, v16
	add.2d	v18, v16, v0
	add.2d	v20, v16, v1
	add.2d	v22, v16, v2
	add.2d	v16, v16, v3
	mov.d	x14, v16[1]
	fmov	x2, d16
	mov.d	x9, v22[1]
	fmov	x3, d22
	mov.d	x4, v20[1]
	fmov	x0, d20
	mov.d	x10, v18[1]
	fmov	x5, d18
	sub	x1, x13, #64
	ldr	s16, [x0]
	dup.2d	v18, x1
	add.2d	v20, v4, v18
	add.2d	v28, v20, v0
	add.2d	v22, v20, v1
	ldr	s18, [x2]
	add.2d	v30, v20, v2
	add.2d	v20, v20, v3
	mov.d	x0, v20[1]
	ld1.s	{ v16 }[1], [x4]
	mov.d	x4, v30[1]
	mov.d	x1, v22[1]
	ld1.s	{ v18 }[1], [x14]
	fmov	x14, d20
	fmov	x2, d22
	ldr	s20, [x2]
	fmov	x6, d30
	ld1.s	{ v20 }[1], [x1]
	mov.d	x2, v28[1]
	ldr	s22, [x14]
	sub	x14, x13, #32
	ld1.s	{ v22 }[1], [x0]
	dup.2d	v30, x14
	fmov	x14, d28
	add.2d	v28, v4, v30
	ld1.s	{ v16 }[2], [x5]
	add.2d	v30, v28, v0
	add.2d	v8, v28, v1
	add.2d	v5, v28, v2
	add.2d	v28, v28, v3
	ld1.s	{ v18 }[2], [x3]
	mov.d	x0, v28[1]
	mov.d	x1, v8[1]
	ld1.s	{ v20 }[2], [x14]
	fmov	x14, d8
	ldr	s8, [x14]
	mov.d	x14, v30[1]
	ld1.s	{ v22 }[2], [x6]
	fmov	x3, d28
	ld1.s	{ v8 }[1], [x1]
	fmov	x1, d30
	ld1.s	{ v8 }[2], [x1]
	mov.d	x1, v5[1]
	ldr	s28, [x3]
	fmov	x3, d5
	ld1.s	{ v16 }[3], [x10]
	ld1.s	{ v28 }[1], [x0]
	dup.2d	v5, x13
	ld1.s	{ v18 }[3], [x9]
	add.2d	v5, v4, v5
	add.2d	v30, v5, v3
	mov.d	x9, v30[1]
	ld1.s	{ v20 }[3], [x2]
	fmov	x10, d30
	add.2d	v30, v5, v2
	mov.d	x0, v30[1]
	ld1.s	{ v22 }[3], [x4]
	fmov	x2, d30
	add.2d	v30, v5, v1
	mov.d	x4, v30[1]
	ld1.s	{ v8 }[3], [x14]
	fmov	x14, d30
	fmul.4s	v18, v18, v18
	fmul.4s	v16, v16, v16
	ld1.s	{ v28 }[2], [x3]
	fadd.4s	v14, v14, v16
	ld1.s	{ v28 }[3], [x1]
	add.2d	v5, v5, v0
	mov.d	x1, v5[1]
	fadd.4s	v13, v13, v18
	fmov	x3, d5
	fmul.4s	v5, v22, v22
	fmul.4s	v16, v20, v20
	fmul.4s	v18, v28, v28
	fmul.4s	v20, v8, v8
	fadd.4s	v27, v27, v16
	ldr	s16, [x14]
	ld1.s	{ v16 }[1], [x4]
	ld1.s	{ v16 }[2], [x3]
	fadd.4s	v24, v24, v5
	ld1.s	{ v16 }[3], [x1]
	ldr	s5, [x10]
	ld1.s	{ v5 }[1], [x9]
	fadd.4s	v26, v26, v20
	ld1.s	{ v5 }[2], [x2]
	ld1.s	{ v5 }[3], [x0]
	fmul.4s	v5, v5, v5
	fadd.4s	v25, v25, v18
	fmul.4s	v16, v16, v16
	fadd.4s	v6, v6, v16
	fadd.4s	v15, v15, v5
	add	x12, x12, #4
	add	x13, x13, #128
	cmp	x12, #4092
	b.lo	LBB0_19
; %bb.20:                               ; %direct.true80.i27.i.preheader
                                        ;   in Loop: Header=BB0_16 Depth=2
	mov	x9, #0                          ; =0x0
	mov	x10, x23
LBB0_21:                                ; %direct.true80.i27.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_16 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	s5, [x10], #4
	dup.2d	v18, x9
	dup.2d	v16, x21
	add.2d	v18, v16, v18
	add.2d	v20, v18, v0
	add.2d	v22, v18, v1
	add.2d	v28, v18, v2
	add.2d	v18, v18, v3
	mov.d	x12, v18[1]
	fmov	x13, d18
	str	s5, [x13]
	str	s5, [x12]
	mov.d	x12, v28[1]
	fmov	x13, d28
	str	s5, [x13]
	str	s5, [x12]
	mov.d	x12, v22[1]
	fmov	x13, d22
	str	s5, [x13]
	mov.d	x13, v20[1]
	str	s5, [x12]
	fmov	x12, d20
	str	s5, [x12]
	str	s5, [x13]
	add	x9, x9, #32
	cmp	x9, #32, lsl #12                ; =131072
	b.ne	LBB0_21
; %bb.22:                               ; %direct.false81.i33.i
                                        ;   in Loop: Header=BB0_16 Depth=2
	mov	x12, #0                         ; =0x0
	fadd.4s	v5, v14, v27
	fadd.4s	v18, v13, v24
	fadd.4s	v18, v18, v25
	fadd.4s	v5, v5, v26
	fadd.4s	v5, v5, v6
	fadd.4s	v6, v18, v15
	ldp	q20, q18, [sp, #448]            ; 32-byte Folded Reload
	fmul.4s	v6, v6, v20
	fmul.4s	v5, v5, v20
	fadd.4s	v5, v5, v18
	fadd.4s	v6, v6, v18
	fsqrt.4s	v6, v6
	fsqrt.4s	v24, v5
LBB0_23:                                ; %direct.true93.i34.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_16 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	dup.2d	v18, x12
	shl.2d	v5, v18, #5
	orr.16b	v20, v5, v3
	orr.16b	v22, v5, v2
	orr.16b	v25, v5, v1
	orr.16b	v5, v5, v0
	add.2d	v26, v4, v5
	add.2d	v27, v4, v25
	add.2d	v28, v4, v22
	add.2d	v30, v4, v20
	mov.d	x9, v30[1]
	fmov	x10, d30
	mov.d	x13, v28[1]
	fmov	x14, d28
	mov.d	x0, v27[1]
	fmov	x1, d27
	mov.d	x2, v26[1]
	fmov	x3, d26
	ldr	s26, [x1]
	ld1.s	{ v26 }[1], [x0]
	ldr	s27, [x10]
	add.2d	v5, v16, v5
	add.2d	v25, v16, v25
	add.2d	v22, v16, v22
	ld1.s	{ v27 }[1], [x9]
	add.2d	v20, v16, v20
	mov.d	x9, v20[1]
	fmov	x10, d20
	ld1.s	{ v26 }[2], [x3]
	mov.d	x0, v22[1]
	mov.d	x1, v25[1]
	ld1.s	{ v27 }[2], [x14]
	fmov	x14, d22
	mov.d	x3, v5[1]
	ldr	s20, [x10]
	ld1.s	{ v26 }[3], [x2]
	ld1.s	{ v20 }[1], [x9]
	ld1.s	{ v20 }[2], [x14]
	ld1.s	{ v27 }[3], [x13]
	fmov	x9, d25
	ldr	s22, [x9]
	ld1.s	{ v22 }[1], [x1]
	ld1.s	{ v20 }[3], [x0]
	fmov	x9, d5
	ld1.s	{ v22 }[2], [x9]
	ld1.s	{ v22 }[3], [x3]
	fdiv.4s	v5, v27, v6
	fdiv.4s	v25, v26, v24
	shl.2d	v18, v18, #2
	dup.2d	v26, x24
	add.2d	v27, v26, v9
	fmul.4s	v22, v25, v22
	add.2d	v25, v27, v18
	add.2d	v27, v26, v11
	add.2d	v28, v26, v10
	add.2d	v26, v26, v12
	add.2d	v26, v26, v18
	fmul.4s	v5, v5, v20
	mov.d	x9, v26[1]
	fmov	x10, d26
	str	s5, [x10]
	st1.s	{ v5 }[1], [x9]
	add.2d	v20, v28, v18
	mov.d	x9, v20[1]
	fmov	x10, d20
	st1.s	{ v5 }[2], [x10]
	add.2d	v18, v27, v18
	mov.d	x10, v18[1]
	fmov	x13, d18
	st1.s	{ v5 }[3], [x9]
	str	s22, [x13]
	mov.d	x9, v25[1]
	fmov	x13, d25
	st1.s	{ v22 }[1], [x10]
	st1.s	{ v22 }[2], [x13]
	st1.s	{ v22 }[3], [x9]
	add	x12, x12, #1
	cmp	x12, #1, lsl #12                ; =4096
	b.ne	LBB0_23
; %bb.24:                               ; %llm_rows.exit39.i
                                        ;   in Loop: Header=BB0_16 Depth=2
	add	w20, w20, #1
	cmp	w20, w7
	b.ne	LBB0_16
LBB0_25:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w9, w19, #0x7
	ldr	x1, [sp, #208]                  ; 8-byte Folded Reload
	ldr	w0, [sp, #12]                   ; 4-byte Folded Reload
	cbz	w9, LBB0_2
; %bb.26:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v4, w9
	ldp	q5, q6, [sp, #416]              ; 32-byte Folded Reload
	cmhi.4s	v13, v4, v6
	cmhi.4s	v6, v4, v5
	uzp1.8h	v7, v6, v13
	umaxv.8h	h4, v7
	fmov	w9, s4
	tbz	w9, #0, LBB0_2
; %bb.27:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	ldr	x9, [x1, #136]
	add	x10, x9, #32, lsl #12           ; =131072
	dup.2d	v4, x10
	str	q4, [sp, #320]                  ; 16-byte Folded Spill
	sshll.2d	v4, v6, #0
	sshll.2d	v5, v13, #0
	sshll2.2d	v20, v6, #0
	sshll2.2d	v21, v13, #0
	lsl	w10, w7, #3
	ldr	x12, [sp, #248]                 ; 8-byte Folded Reload
	orr	w10, w10, w12, lsl #10
	dup.4s	v16, w10
	ldp	q17, q19, [sp, #416]            ; 32-byte Folded Reload
	orr.16b	v17, v16, v17
	dup.2d	v18, x9
	orr.16b	v16, v16, v19
	ldr	x9, [sp, #216]                  ; 8-byte Folded Reload
	ldr	x12, [x9]
	and.16b	v16, v13, v16
	ldr	x19, [x9, #16]
	and.16b	v17, v6, v17
	ldr	x7, [x9, #48]
	and.16b	v28, v21, v18
	and.16b	v29, v20, v18
	and.16b	v30, v5, v18
	and.16b	v31, v4, v18
	stp	q21, q20, [sp, #288]            ; 32-byte Folded Spill
	and.16b	v8, v21, v0
	and.16b	v9, v20, v2
	and.16b	v10, v5, v1
	and.16b	v11, v4, v3
	ushll2.2d	v25, v16, #14
	ushll2.2d	v12, v17, #14
	ushll.2d	v5, v16, #14
	ushll.2d	v4, v17, #14
	stp	q4, q5, [sp, #384]              ; 32-byte Folded Spill
	adrp	x13, lCPI0_18@PAGE
	b	LBB0_29
LBB0_28:                                ; %else762
                                        ;   in Loop: Header=BB0_29 Depth=2
	add	x11, x11, #1
	cmp	x11, #1, lsl #12                ; =4096
	b.eq	LBB0_61
LBB0_29:                                ; %direct.true.i47.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x13, lCPI0_18@PAGEOFF]
	and.16b	v4, v7, v4
	addv.8h	h4, v4
	fmov	w9, s4
	dup.2d	v18, x11
	shl.2d	v19, v18, #2
	dup.2d	v20, x12
	ldr	q5, [sp, #384]                  ; 16-byte Folded Reload
	add.2d	v5, v20, v5
	add.2d	v21, v5, v19
	movi.2d	v17, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w9, #0, LBB0_45
; %bb.30:                               ; %else
                                        ;   in Loop: Header=BB0_29 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_46
LBB0_31:                                ; %else693
                                        ;   in Loop: Header=BB0_29 Depth=2
	add.2d	v5, v20, v12
	add.2d	v5, v5, v19
	tbnz	w9, #2, LBB0_47
LBB0_32:                                ; %else699
                                        ;   in Loop: Header=BB0_29 Depth=2
	tbnz	w9, #3, LBB0_48
LBB0_33:                                ; %else705
                                        ;   in Loop: Header=BB0_29 Depth=2
	ldr	q5, [sp, #400]                  ; 16-byte Folded Reload
	add.2d	v5, v20, v5
	add.2d	v5, v5, v19
	tbnz	w9, #4, LBB0_49
LBB0_34:                                ; %else711
                                        ;   in Loop: Header=BB0_29 Depth=2
	tbnz	w9, #5, LBB0_50
LBB0_35:                                ; %else717
                                        ;   in Loop: Header=BB0_29 Depth=2
	add.2d	v5, v20, v25
	add.2d	v5, v5, v19
	tbnz	w9, #6, LBB0_51
LBB0_36:                                ; %else723
                                        ;   in Loop: Header=BB0_29 Depth=2
	tbnz	w9, #7, LBB0_52
LBB0_37:                                ; %else729
                                        ;   in Loop: Header=BB0_29 Depth=2
	fmov	w9, s4
	shl.2d	v18, v18, #5
	orr.16b	v5, v18, v11
	add.2d	v5, v31, v5
	tbnz	w9, #0, LBB0_53
LBB0_38:                                ; %else734
                                        ;   in Loop: Header=BB0_29 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_54
LBB0_39:                                ; %else738
                                        ;   in Loop: Header=BB0_29 Depth=2
	orr.16b	v5, v18, v9
	add.2d	v5, v29, v5
	tbnz	w9, #2, LBB0_55
LBB0_40:                                ; %else742
                                        ;   in Loop: Header=BB0_29 Depth=2
	tbnz	w9, #3, LBB0_56
LBB0_41:                                ; %else746
                                        ;   in Loop: Header=BB0_29 Depth=2
	orr.16b	v5, v18, v10
	add.2d	v5, v30, v5
	tbnz	w9, #4, LBB0_57
LBB0_42:                                ; %else750
                                        ;   in Loop: Header=BB0_29 Depth=2
	tbnz	w9, #5, LBB0_58
LBB0_43:                                ; %else754
                                        ;   in Loop: Header=BB0_29 Depth=2
	orr.16b	v5, v18, v8
	add.2d	v5, v28, v5
	tbnz	w9, #6, LBB0_59
LBB0_44:                                ; %else758
                                        ;   in Loop: Header=BB0_29 Depth=2
	tbz	w9, #7, LBB0_28
	b	LBB0_60
LBB0_45:                                ; %cond.load
                                        ;   in Loop: Header=BB0_29 Depth=2
	fmov	x10, d21
	ldr	s17, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_31
LBB0_46:                                ; %cond.load689
                                        ;   in Loop: Header=BB0_29 Depth=2
	mov.d	x10, v21[1]
	ld1.s	{ v17 }[1], [x10]
	add.2d	v5, v20, v12
	add.2d	v5, v5, v19
	tbz	w9, #2, LBB0_32
LBB0_47:                                ; %cond.load695
                                        ;   in Loop: Header=BB0_29 Depth=2
	fmov	x10, d5
	ld1.s	{ v17 }[2], [x10]
	tbz	w9, #3, LBB0_33
LBB0_48:                                ; %cond.load701
                                        ;   in Loop: Header=BB0_29 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v17 }[3], [x10]
	ldr	q5, [sp, #400]                  ; 16-byte Folded Reload
	add.2d	v5, v20, v5
	add.2d	v5, v5, v19
	tbz	w9, #4, LBB0_34
LBB0_49:                                ; %cond.load707
                                        ;   in Loop: Header=BB0_29 Depth=2
	fmov	x10, d5
	ld1.s	{ v16 }[0], [x10]
	tbz	w9, #5, LBB0_35
LBB0_50:                                ; %cond.load713
                                        ;   in Loop: Header=BB0_29 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v16 }[1], [x10]
	add.2d	v5, v20, v25
	add.2d	v5, v5, v19
	tbz	w9, #6, LBB0_36
LBB0_51:                                ; %cond.load719
                                        ;   in Loop: Header=BB0_29 Depth=2
	fmov	x10, d5
	ld1.s	{ v16 }[2], [x10]
	tbz	w9, #7, LBB0_37
LBB0_52:                                ; %cond.load725
                                        ;   in Loop: Header=BB0_29 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v16 }[3], [x9]
	fmov	w9, s4
	shl.2d	v18, v18, #5
	orr.16b	v5, v18, v11
	add.2d	v5, v31, v5
	tbz	w9, #0, LBB0_38
LBB0_53:                                ; %cond.store
                                        ;   in Loop: Header=BB0_29 Depth=2
	fmov	x10, d5
	str	s17, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_39
LBB0_54:                                ; %cond.store735
                                        ;   in Loop: Header=BB0_29 Depth=2
	mov.d	x10, v5[1]
	st1.s	{ v17 }[1], [x10]
	orr.16b	v5, v18, v9
	add.2d	v5, v29, v5
	tbz	w9, #2, LBB0_40
LBB0_55:                                ; %cond.store739
                                        ;   in Loop: Header=BB0_29 Depth=2
	fmov	x10, d5
	st1.s	{ v17 }[2], [x10]
	tbz	w9, #3, LBB0_41
LBB0_56:                                ; %cond.store743
                                        ;   in Loop: Header=BB0_29 Depth=2
	mov.d	x10, v5[1]
	st1.s	{ v17 }[3], [x10]
	orr.16b	v5, v18, v10
	add.2d	v5, v30, v5
	tbz	w9, #4, LBB0_42
LBB0_57:                                ; %cond.store747
                                        ;   in Loop: Header=BB0_29 Depth=2
	fmov	x10, d5
	str	s16, [x10]
	tbz	w9, #5, LBB0_43
LBB0_58:                                ; %cond.store751
                                        ;   in Loop: Header=BB0_29 Depth=2
	mov.d	x10, v5[1]
	st1.s	{ v16 }[1], [x10]
	orr.16b	v5, v18, v8
	add.2d	v5, v28, v5
	tbz	w9, #6, LBB0_44
LBB0_59:                                ; %cond.store755
                                        ;   in Loop: Header=BB0_29 Depth=2
	fmov	x10, d5
	st1.s	{ v16 }[2], [x10]
	tbz	w9, #7, LBB0_28
LBB0_60:                                ; %cond.store759
                                        ;   in Loop: Header=BB0_29 Depth=2
	mov.d	x9, v5[1]
	st1.s	{ v16 }[3], [x9]
	b	LBB0_28
LBB0_61:                                ; %direct.false.i52.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	w9, s4
	add.2d	v17, v31, v11
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w9, #0, LBB0_231
; %bb.62:                               ; %else768
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_232
LBB0_63:                                ; %else774
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v18, v29, v9
	tbnz	w9, #2, LBB0_233
LBB0_64:                                ; %else780
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #3, LBB0_234
LBB0_65:                                ; %else786
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v19, v30, v10
	tbnz	w9, #4, LBB0_235
LBB0_66:                                ; %else792
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #5, LBB0_236
LBB0_67:                                ; %else798
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v20, v28, v8
	tbnz	w9, #6, LBB0_237
LBB0_68:                                ; %else804
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w9, #7, LBB0_70
LBB0_69:                                ; %cond.load806
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x9, v20[1]
	ld1.s	{ v16 }[3], [x9]
LBB0_70:                                ; %else810
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	w9, s4
	mov	w10, #32                        ; =0x20
	dup.2d	v23, x10
	add.2d	v24, v17, v23
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	tbnz	w9, #0, LBB0_238
; %bb.71:                               ; %else817
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_239
LBB0_72:                                ; %else823
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v5, v18, v23
	tbnz	w9, #2, LBB0_240
LBB0_73:                                ; %else829
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #3, LBB0_241
LBB0_74:                                ; %else835
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v5, v19, v23
	tbnz	w9, #4, LBB0_242
LBB0_75:                                ; %else841
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #5, LBB0_243
LBB0_76:                                ; %else847
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v5, v20, v23
	tbnz	w9, #6, LBB0_244
LBB0_77:                                ; %else853
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q25, [sp, #336]                 ; 16-byte Folded Spill
	tbz	w9, #7, LBB0_79
LBB0_78:                                ; %cond.load855
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x9, v5[1]
	ld1.s	{ v22 }[3], [x9]
LBB0_79:                                ; %else859
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	w9, s4
	mov	w10, #64                        ; =0x40
	dup.2d	v25, x10
	add.2d	v26, v17, v25
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbnz	w9, #0, LBB0_245
; %bb.80:                               ; %else866
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_246
LBB0_81:                                ; %else872
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v5, v18, v25
	tbnz	w9, #2, LBB0_247
LBB0_82:                                ; %else878
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #3, LBB0_248
LBB0_83:                                ; %else884
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v5, v19, v25
	tbnz	w9, #4, LBB0_249
LBB0_84:                                ; %else890
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #5, LBB0_250
LBB0_85:                                ; %else896
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v5, v20, v25
	tbnz	w9, #6, LBB0_251
LBB0_86:                                ; %else902
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w9, #7, LBB0_88
LBB0_87:                                ; %cond.load904
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x9, v5[1]
	ld1.s	{ v24 }[3], [x9]
LBB0_88:                                ; %else908
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	w9, s4
	mov	w10, #96                        ; =0x60
	dup.2d	v26, x10
	add.2d	v27, v17, v26
	movi.2d	v17, #0000000000000000
	movi.2d	v25, #0000000000000000
	tbnz	w9, #0, LBB0_252
; %bb.89:                               ; %else915
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_253
LBB0_90:                                ; %else921
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v5, v18, v26
	tbnz	w9, #2, LBB0_254
LBB0_91:                                ; %else927
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #3, LBB0_255
LBB0_92:                                ; %else933
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v5, v19, v26
	tbnz	w9, #4, LBB0_256
LBB0_93:                                ; %else939
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #5, LBB0_257
LBB0_94:                                ; %else945
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v5, v20, v26
	tbnz	w9, #6, LBB0_258
LBB0_95:                                ; %else951
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w9, #7, LBB0_97
LBB0_96:                                ; %cond.load953
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x9, v5[1]
	ld1.s	{ v25 }[3], [x9]
LBB0_97:                                ; %else957
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	fmul.4s	v5, v7, v7
	fmul.4s	v7, v16, v16
	fmul.4s	v16, v21, v21
	fmul.4s	v19, v22, v22
	fmul.4s	v22, v23, v23
	fmul.4s	v23, v24, v24
	fmul.4s	v17, v17, v17
	fmul.4s	v24, v25, v25
	and.16b	v18, v13, v7
	and.16b	v21, v6, v5
	and.16b	v20, v13, v19
	and.16b	v16, v6, v16
	and.16b	v23, v13, v23
	and.16b	v22, v6, v22
	and.16b	v19, v13, v24
	mov	w15, #224                       ; =0xe0
	and.16b	v17, v6, v17
	stp	q12, q13, [sp, #352]            ; 32-byte Folded Spill
	b	LBB0_99
LBB0_98:                                ; %else1153
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmul.4s	v5, v12, v12
	fmul.4s	v7, v7, v7
	fadd.4s	v7, v21, v7
	fadd.4s	v5, v18, v5
	fmul.4s	v12, v14, v14
	fmul.4s	v13, v13, v13
	fadd.4s	v13, v16, v13
	fadd.4s	v12, v20, v12
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v24, v22, v24
	fadd.4s	v25, v23, v25
	fmul.4s	v26, v26, v26
	fmul.4s	v27, v27, v27
	fadd.4s	v27, v19, v27
	fadd.4s	v26, v17, v26
	ldr	q14, [sp, #368]                 ; 16-byte Folded Reload
	bit.16b	v18, v5, v14
	bit.16b	v21, v7, v6
	bit.16b	v20, v12, v14
	bit.16b	v16, v13, v6
	bit.16b	v23, v25, v14
	bit.16b	v22, v24, v6
	add	x11, x11, #4
	bit.16b	v17, v26, v6
	add	x15, x15, #128
	bit.16b	v19, v27, v14
	cmp	x11, #4092
	b.hs	LBB0_163
LBB0_99:                                ; %direct.true41.i53.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s4
	sub	x10, x15, #96
	dup.2d	v24, x10
	orr.16b	v5, v24, v11
	add.2d	v25, v31, v5
	movi.2d	v7, #0000000000000000
	movi.2d	v12, #0000000000000000
	tbnz	w9, #0, LBB0_134
; %bb.100:                              ; %else964
                                        ;   in Loop: Header=BB0_99 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_135
LBB0_101:                               ; %else970
                                        ;   in Loop: Header=BB0_99 Depth=2
	orr.16b	v5, v24, v9
	add.2d	v5, v29, v5
	tbnz	w9, #2, LBB0_136
LBB0_102:                               ; %else976
                                        ;   in Loop: Header=BB0_99 Depth=2
	tbnz	w9, #3, LBB0_137
LBB0_103:                               ; %else982
                                        ;   in Loop: Header=BB0_99 Depth=2
	orr.16b	v5, v24, v10
	add.2d	v5, v30, v5
	tbnz	w9, #4, LBB0_138
LBB0_104:                               ; %else988
                                        ;   in Loop: Header=BB0_99 Depth=2
	tbnz	w9, #5, LBB0_139
LBB0_105:                               ; %else994
                                        ;   in Loop: Header=BB0_99 Depth=2
	orr.16b	v5, v24, v8
	add.2d	v5, v28, v5
	tbnz	w9, #6, LBB0_140
LBB0_106:                               ; %else1000
                                        ;   in Loop: Header=BB0_99 Depth=2
	tbz	w9, #7, LBB0_108
LBB0_107:                               ; %cond.load1002
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v12 }[3], [x9]
LBB0_108:                               ; %else1006
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	w9, s4
	sub	x10, x15, #64
	dup.2d	v24, x10
	orr.16b	v5, v24, v11
	add.2d	v25, v31, v5
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	tbnz	w9, #0, LBB0_141
; %bb.109:                              ; %else1013
                                        ;   in Loop: Header=BB0_99 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_142
LBB0_110:                               ; %else1019
                                        ;   in Loop: Header=BB0_99 Depth=2
	orr.16b	v5, v24, v9
	add.2d	v5, v29, v5
	tbnz	w9, #2, LBB0_143
LBB0_111:                               ; %else1025
                                        ;   in Loop: Header=BB0_99 Depth=2
	tbnz	w9, #3, LBB0_144
LBB0_112:                               ; %else1031
                                        ;   in Loop: Header=BB0_99 Depth=2
	orr.16b	v5, v24, v10
	add.2d	v5, v30, v5
	tbnz	w9, #4, LBB0_145
LBB0_113:                               ; %else1037
                                        ;   in Loop: Header=BB0_99 Depth=2
	tbnz	w9, #5, LBB0_146
LBB0_114:                               ; %else1043
                                        ;   in Loop: Header=BB0_99 Depth=2
	orr.16b	v5, v24, v8
	add.2d	v5, v28, v5
	tbnz	w9, #6, LBB0_147
LBB0_115:                               ; %else1049
                                        ;   in Loop: Header=BB0_99 Depth=2
	tbz	w9, #7, LBB0_117
LBB0_116:                               ; %cond.load1051
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v14 }[3], [x9]
LBB0_117:                               ; %else1055
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	w9, s4
	sub	x10, x15, #32
	dup.2d	v26, x10
	orr.16b	v5, v26, v11
	add.2d	v27, v31, v5
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	tbnz	w9, #0, LBB0_148
; %bb.118:                              ; %else1062
                                        ;   in Loop: Header=BB0_99 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_149
LBB0_119:                               ; %else1068
                                        ;   in Loop: Header=BB0_99 Depth=2
	orr.16b	v5, v26, v9
	add.2d	v5, v29, v5
	tbnz	w9, #2, LBB0_150
LBB0_120:                               ; %else1074
                                        ;   in Loop: Header=BB0_99 Depth=2
	tbnz	w9, #3, LBB0_151
LBB0_121:                               ; %else1080
                                        ;   in Loop: Header=BB0_99 Depth=2
	orr.16b	v5, v26, v10
	add.2d	v5, v30, v5
	tbnz	w9, #4, LBB0_152
LBB0_122:                               ; %else1086
                                        ;   in Loop: Header=BB0_99 Depth=2
	tbnz	w9, #5, LBB0_153
LBB0_123:                               ; %else1092
                                        ;   in Loop: Header=BB0_99 Depth=2
	orr.16b	v5, v26, v8
	add.2d	v5, v28, v5
	tbnz	w9, #6, LBB0_154
LBB0_124:                               ; %else1098
                                        ;   in Loop: Header=BB0_99 Depth=2
	tbz	w9, #7, LBB0_126
LBB0_125:                               ; %cond.load1100
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v25 }[3], [x9]
LBB0_126:                               ; %else1104
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	w9, s4
	dup.2d	v15, x15
	orr.16b	v5, v15, v11
	add.2d	v5, v31, v5
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w9, #0, LBB0_155
; %bb.127:                              ; %else1111
                                        ;   in Loop: Header=BB0_99 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_156
LBB0_128:                               ; %else1117
                                        ;   in Loop: Header=BB0_99 Depth=2
	orr.16b	v5, v15, v9
	add.2d	v5, v29, v5
	tbnz	w9, #2, LBB0_157
LBB0_129:                               ; %else1123
                                        ;   in Loop: Header=BB0_99 Depth=2
	tbnz	w9, #3, LBB0_158
LBB0_130:                               ; %else1129
                                        ;   in Loop: Header=BB0_99 Depth=2
	orr.16b	v5, v15, v10
	add.2d	v5, v30, v5
	tbnz	w9, #4, LBB0_159
LBB0_131:                               ; %else1135
                                        ;   in Loop: Header=BB0_99 Depth=2
	tbnz	w9, #5, LBB0_160
LBB0_132:                               ; %else1141
                                        ;   in Loop: Header=BB0_99 Depth=2
	orr.16b	v5, v15, v8
	add.2d	v5, v28, v5
	tbnz	w9, #6, LBB0_161
LBB0_133:                               ; %else1147
                                        ;   in Loop: Header=BB0_99 Depth=2
	ldr	q15, [sp, #352]                 ; 16-byte Folded Reload
	tbz	w9, #7, LBB0_98
	b	LBB0_162
LBB0_134:                               ; %cond.load960
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d25
	ldr	s7, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_101
LBB0_135:                               ; %cond.load966
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x10, v25[1]
	ld1.s	{ v7 }[1], [x10]
	orr.16b	v5, v24, v9
	add.2d	v5, v29, v5
	tbz	w9, #2, LBB0_102
LBB0_136:                               ; %cond.load972
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d5
	ld1.s	{ v7 }[2], [x10]
	tbz	w9, #3, LBB0_103
LBB0_137:                               ; %cond.load978
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v7 }[3], [x10]
	orr.16b	v5, v24, v10
	add.2d	v5, v30, v5
	tbz	w9, #4, LBB0_104
LBB0_138:                               ; %cond.load984
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d5
	ld1.s	{ v12 }[0], [x10]
	tbz	w9, #5, LBB0_105
LBB0_139:                               ; %cond.load990
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v12 }[1], [x10]
	orr.16b	v5, v24, v8
	add.2d	v5, v28, v5
	tbz	w9, #6, LBB0_106
LBB0_140:                               ; %cond.load996
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d5
	ld1.s	{ v12 }[2], [x10]
	tbnz	w9, #7, LBB0_107
	b	LBB0_108
LBB0_141:                               ; %cond.load1009
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d25
	ldr	s13, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_110
LBB0_142:                               ; %cond.load1015
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x10, v25[1]
	ld1.s	{ v13 }[1], [x10]
	orr.16b	v5, v24, v9
	add.2d	v5, v29, v5
	tbz	w9, #2, LBB0_111
LBB0_143:                               ; %cond.load1021
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d5
	ld1.s	{ v13 }[2], [x10]
	tbz	w9, #3, LBB0_112
LBB0_144:                               ; %cond.load1027
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v13 }[3], [x10]
	orr.16b	v5, v24, v10
	add.2d	v5, v30, v5
	tbz	w9, #4, LBB0_113
LBB0_145:                               ; %cond.load1033
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d5
	ld1.s	{ v14 }[0], [x10]
	tbz	w9, #5, LBB0_114
LBB0_146:                               ; %cond.load1039
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v14 }[1], [x10]
	orr.16b	v5, v24, v8
	add.2d	v5, v28, v5
	tbz	w9, #6, LBB0_115
LBB0_147:                               ; %cond.load1045
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d5
	ld1.s	{ v14 }[2], [x10]
	tbnz	w9, #7, LBB0_116
	b	LBB0_117
LBB0_148:                               ; %cond.load1058
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d27
	ldr	s24, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_119
LBB0_149:                               ; %cond.load1064
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x10, v27[1]
	ld1.s	{ v24 }[1], [x10]
	orr.16b	v5, v26, v9
	add.2d	v5, v29, v5
	tbz	w9, #2, LBB0_120
LBB0_150:                               ; %cond.load1070
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d5
	ld1.s	{ v24 }[2], [x10]
	tbz	w9, #3, LBB0_121
LBB0_151:                               ; %cond.load1076
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v24 }[3], [x10]
	orr.16b	v5, v26, v10
	add.2d	v5, v30, v5
	tbz	w9, #4, LBB0_122
LBB0_152:                               ; %cond.load1082
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d5
	ld1.s	{ v25 }[0], [x10]
	tbz	w9, #5, LBB0_123
LBB0_153:                               ; %cond.load1088
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v25 }[1], [x10]
	orr.16b	v5, v26, v8
	add.2d	v5, v28, v5
	tbz	w9, #6, LBB0_124
LBB0_154:                               ; %cond.load1094
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d5
	ld1.s	{ v25 }[2], [x10]
	tbnz	w9, #7, LBB0_125
	b	LBB0_126
LBB0_155:                               ; %cond.load1107
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d5
	ldr	s26, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_128
LBB0_156:                               ; %cond.load1113
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v26 }[1], [x10]
	orr.16b	v5, v15, v9
	add.2d	v5, v29, v5
	tbz	w9, #2, LBB0_129
LBB0_157:                               ; %cond.load1119
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d5
	ld1.s	{ v26 }[2], [x10]
	tbz	w9, #3, LBB0_130
LBB0_158:                               ; %cond.load1125
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v26 }[3], [x10]
	orr.16b	v5, v15, v10
	add.2d	v5, v30, v5
	tbz	w9, #4, LBB0_131
LBB0_159:                               ; %cond.load1131
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d5
	ld1.s	{ v27 }[0], [x10]
	tbz	w9, #5, LBB0_132
LBB0_160:                               ; %cond.load1137
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v27 }[1], [x10]
	orr.16b	v5, v15, v8
	add.2d	v5, v28, v5
	tbz	w9, #6, LBB0_133
LBB0_161:                               ; %cond.load1143
                                        ;   in Loop: Header=BB0_99 Depth=2
	fmov	x10, d5
	ld1.s	{ v27 }[2], [x10]
	ldr	q15, [sp, #352]                 ; 16-byte Folded Reload
	tbz	w9, #7, LBB0_98
LBB0_162:                               ; %cond.load1149
                                        ;   in Loop: Header=BB0_99 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v27 }[3], [x9]
	b	LBB0_98
LBB0_163:                               ; %direct.false42.i63.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	sshll.2d	v5, v6, #0
	sshll.2d	v24, v14, #0
	ldp	q26, q25, [sp, #304]            ; 32-byte Folded Reload
	ldr	q7, [sp, #288]                  ; 16-byte Folded Reload
	and.16b	v7, v7, v25
	and.16b	v12, v26, v25
	and.16b	v13, v24, v25
	and.16b	v14, v5, v25
	b	LBB0_165
LBB0_164:                               ; %else1187
                                        ;   in Loop: Header=BB0_165 Depth=2
	add	x9, x9, #32
	add	x19, x19, #4
	cmp	x9, #32, lsl #12                ; =131072
	b.eq	LBB0_181
LBB0_165:                               ; %direct.true80.i64.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w10, s4
	ld1r.4s	{ v24 }, [x19]
	dup.2d	v25, x9
	orr.16b	v5, v25, v11
	add.2d	v5, v14, v5
	tbnz	w10, #0, LBB0_173
; %bb.166:                              ; %else1159
                                        ;   in Loop: Header=BB0_165 Depth=2
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_174
LBB0_167:                               ; %else1163
                                        ;   in Loop: Header=BB0_165 Depth=2
	orr.16b	v5, v25, v9
	add.2d	v5, v12, v5
	tbnz	w10, #2, LBB0_175
LBB0_168:                               ; %else1167
                                        ;   in Loop: Header=BB0_165 Depth=2
	tbnz	w10, #3, LBB0_176
LBB0_169:                               ; %else1171
                                        ;   in Loop: Header=BB0_165 Depth=2
	orr.16b	v5, v25, v10
	add.2d	v5, v13, v5
	tbnz	w10, #4, LBB0_177
LBB0_170:                               ; %else1175
                                        ;   in Loop: Header=BB0_165 Depth=2
	tbnz	w10, #5, LBB0_178
LBB0_171:                               ; %else1179
                                        ;   in Loop: Header=BB0_165 Depth=2
	orr.16b	v5, v25, v8
	add.2d	v5, v7, v5
	tbnz	w10, #6, LBB0_179
LBB0_172:                               ; %else1183
                                        ;   in Loop: Header=BB0_165 Depth=2
	tbz	w10, #7, LBB0_164
	b	LBB0_180
LBB0_173:                               ; %cond.store1156
                                        ;   in Loop: Header=BB0_165 Depth=2
	fmov	x11, d5
	str	s24, [x11]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_167
LBB0_174:                               ; %cond.store1160
                                        ;   in Loop: Header=BB0_165 Depth=2
	mov.d	x11, v5[1]
	st1.s	{ v24 }[1], [x11]
	orr.16b	v5, v25, v9
	add.2d	v5, v12, v5
	tbz	w10, #2, LBB0_168
LBB0_175:                               ; %cond.store1164
                                        ;   in Loop: Header=BB0_165 Depth=2
	fmov	x11, d5
	st1.s	{ v24 }[2], [x11]
	tbz	w10, #3, LBB0_169
LBB0_176:                               ; %cond.store1168
                                        ;   in Loop: Header=BB0_165 Depth=2
	mov.d	x11, v5[1]
	st1.s	{ v24 }[3], [x11]
	orr.16b	v5, v25, v10
	add.2d	v5, v13, v5
	tbz	w10, #4, LBB0_170
LBB0_177:                               ; %cond.store1172
                                        ;   in Loop: Header=BB0_165 Depth=2
	fmov	x11, d5
	str	s24, [x11]
	tbz	w10, #5, LBB0_171
LBB0_178:                               ; %cond.store1176
                                        ;   in Loop: Header=BB0_165 Depth=2
	mov.d	x11, v5[1]
	st1.s	{ v24 }[1], [x11]
	orr.16b	v5, v25, v8
	add.2d	v5, v7, v5
	tbz	w10, #6, LBB0_172
LBB0_179:                               ; %cond.store1180
                                        ;   in Loop: Header=BB0_165 Depth=2
	fmov	x11, d5
	st1.s	{ v24 }[2], [x11]
	tbz	w10, #7, LBB0_164
LBB0_180:                               ; %cond.store1184
                                        ;   in Loop: Header=BB0_165 Depth=2
	mov.d	x10, v5[1]
	st1.s	{ v24 }[3], [x10]
	b	LBB0_164
LBB0_181:                               ; %direct.false81.i70.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	fadd.4s	v5, v21, v16
	fadd.4s	v16, v18, v20
	fadd.4s	v16, v16, v23
	fadd.4s	v5, v5, v22
	fadd.4s	v5, v5, v17
	fadd.4s	v16, v16, v19
	ldp	q18, q17, [sp, #448]            ; 32-byte Folded Reload
	fmul.4s	v16, v16, v18
	fmul.4s	v5, v5, v18
	fadd.4s	v5, v5, v17
	fadd.4s	v16, v16, v17
	fsqrt.4s	v16, v16
	fsqrt.4s	v5, v5
	and.16b	v6, v6, v5
	ldr	q5, [sp, #368]                  ; 16-byte Folded Reload
	and.16b	v5, v5, v16
	ldr	q25, [sp, #336]                 ; 16-byte Folded Reload
	b	LBB0_183
LBB0_182:                               ; %else1318
                                        ;   in Loop: Header=BB0_183 Depth=2
	add	x11, x11, #1
	cmp	x11, #1, lsl #12                ; =4096
	b.eq	LBB0_2
LBB0_183:                               ; %direct.true93.i71.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v17, x11
	fmov	w9, s4
	shl.2d	v22, v17, #5
	orr.16b	v19, v22, v11
	add.2d	v20, v31, v19
	movi.2d	v18, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w9, #0, LBB0_208
; %bb.184:                              ; %else1193
                                        ;   in Loop: Header=BB0_183 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_209
LBB0_185:                               ; %else1199
                                        ;   in Loop: Header=BB0_183 Depth=2
	orr.16b	v20, v22, v9
	add.2d	v21, v29, v20
	tbnz	w9, #2, LBB0_210
LBB0_186:                               ; %else1205
                                        ;   in Loop: Header=BB0_183 Depth=2
	tbnz	w9, #3, LBB0_211
LBB0_187:                               ; %else1211
                                        ;   in Loop: Header=BB0_183 Depth=2
	orr.16b	v21, v22, v10
	add.2d	v23, v30, v21
	tbnz	w9, #4, LBB0_212
LBB0_188:                               ; %else1217
                                        ;   in Loop: Header=BB0_183 Depth=2
	tbnz	w9, #5, LBB0_213
LBB0_189:                               ; %else1223
                                        ;   in Loop: Header=BB0_183 Depth=2
	orr.16b	v22, v22, v8
	add.2d	v23, v28, v22
	tbnz	w9, #6, LBB0_214
LBB0_190:                               ; %else1229
                                        ;   in Loop: Header=BB0_183 Depth=2
	tbnz	w9, #7, LBB0_215
LBB0_191:                               ; %else1235
                                        ;   in Loop: Header=BB0_183 Depth=2
	fmov	w9, s4
	add.2d	v24, v14, v19
	movi.2d	v23, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbnz	w9, #0, LBB0_216
LBB0_192:                               ; %else1242
                                        ;   in Loop: Header=BB0_183 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_217
LBB0_193:                               ; %else1248
                                        ;   in Loop: Header=BB0_183 Depth=2
	add.2d	v20, v12, v20
	tbnz	w9, #2, LBB0_218
LBB0_194:                               ; %else1254
                                        ;   in Loop: Header=BB0_183 Depth=2
	tbnz	w9, #3, LBB0_219
LBB0_195:                               ; %else1260
                                        ;   in Loop: Header=BB0_183 Depth=2
	add.2d	v20, v13, v21
	tbnz	w9, #4, LBB0_220
LBB0_196:                               ; %else1266
                                        ;   in Loop: Header=BB0_183 Depth=2
	tbnz	w9, #5, LBB0_221
LBB0_197:                               ; %else1272
                                        ;   in Loop: Header=BB0_183 Depth=2
	add.2d	v20, v7, v22
	tbnz	w9, #6, LBB0_222
LBB0_198:                               ; %else1278
                                        ;   in Loop: Header=BB0_183 Depth=2
	tbz	w9, #7, LBB0_200
LBB0_199:                               ; %cond.load1280
                                        ;   in Loop: Header=BB0_183 Depth=2
	mov.d	x9, v20[1]
	ld1.s	{ v19 }[3], [x9]
LBB0_200:                               ; %else1284
                                        ;   in Loop: Header=BB0_183 Depth=2
	fdiv.4s	v18, v18, v6
	fmov	w9, s4
	fmul.4s	v20, v18, v23
	shl.2d	v17, v17, #2
	dup.2d	v18, x7
	ldr	q21, [sp, #384]                 ; 16-byte Folded Reload
	add.2d	v21, v18, v21
	add.2d	v21, v21, v17
	tbnz	w9, #0, LBB0_223
; %bb.201:                              ; %else1290
                                        ;   in Loop: Header=BB0_183 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_224
LBB0_202:                               ; %else1294
                                        ;   in Loop: Header=BB0_183 Depth=2
	add.2d	v21, v18, v15
	add.2d	v21, v21, v17
	tbnz	w9, #2, LBB0_225
LBB0_203:                               ; %else1298
                                        ;   in Loop: Header=BB0_183 Depth=2
	tbnz	w9, #3, LBB0_226
LBB0_204:                               ; %else1302
                                        ;   in Loop: Header=BB0_183 Depth=2
	fdiv.4s	v16, v16, v5
	fmul.4s	v16, v16, v19
	ldr	q19, [sp, #400]                 ; 16-byte Folded Reload
	add.2d	v19, v18, v19
	add.2d	v19, v19, v17
	tbnz	w9, #4, LBB0_227
LBB0_205:                               ; %else1306
                                        ;   in Loop: Header=BB0_183 Depth=2
	tbnz	w9, #5, LBB0_228
LBB0_206:                               ; %else1310
                                        ;   in Loop: Header=BB0_183 Depth=2
	add.2d	v18, v18, v25
	add.2d	v17, v18, v17
	tbnz	w9, #6, LBB0_229
LBB0_207:                               ; %else1314
                                        ;   in Loop: Header=BB0_183 Depth=2
	tbz	w9, #7, LBB0_182
	b	LBB0_230
LBB0_208:                               ; %cond.load1189
                                        ;   in Loop: Header=BB0_183 Depth=2
	fmov	x10, d20
	ldr	s18, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_185
LBB0_209:                               ; %cond.load1195
                                        ;   in Loop: Header=BB0_183 Depth=2
	mov.d	x10, v20[1]
	ld1.s	{ v18 }[1], [x10]
	orr.16b	v20, v22, v9
	add.2d	v21, v29, v20
	tbz	w9, #2, LBB0_186
LBB0_210:                               ; %cond.load1201
                                        ;   in Loop: Header=BB0_183 Depth=2
	fmov	x10, d21
	ld1.s	{ v18 }[2], [x10]
	tbz	w9, #3, LBB0_187
LBB0_211:                               ; %cond.load1207
                                        ;   in Loop: Header=BB0_183 Depth=2
	mov.d	x10, v21[1]
	ld1.s	{ v18 }[3], [x10]
	orr.16b	v21, v22, v10
	add.2d	v23, v30, v21
	tbz	w9, #4, LBB0_188
LBB0_212:                               ; %cond.load1213
                                        ;   in Loop: Header=BB0_183 Depth=2
	fmov	x10, d23
	ld1.s	{ v16 }[0], [x10]
	tbz	w9, #5, LBB0_189
LBB0_213:                               ; %cond.load1219
                                        ;   in Loop: Header=BB0_183 Depth=2
	mov.d	x10, v23[1]
	ld1.s	{ v16 }[1], [x10]
	orr.16b	v22, v22, v8
	add.2d	v23, v28, v22
	tbz	w9, #6, LBB0_190
LBB0_214:                               ; %cond.load1225
                                        ;   in Loop: Header=BB0_183 Depth=2
	fmov	x10, d23
	ld1.s	{ v16 }[2], [x10]
	tbz	w9, #7, LBB0_191
LBB0_215:                               ; %cond.load1231
                                        ;   in Loop: Header=BB0_183 Depth=2
	mov.d	x9, v23[1]
	ld1.s	{ v16 }[3], [x9]
	fmov	w9, s4
	add.2d	v24, v14, v19
	movi.2d	v23, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w9, #0, LBB0_192
LBB0_216:                               ; %cond.load1238
                                        ;   in Loop: Header=BB0_183 Depth=2
	fmov	x10, d24
	ldr	s23, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_193
LBB0_217:                               ; %cond.load1244
                                        ;   in Loop: Header=BB0_183 Depth=2
	mov.d	x10, v24[1]
	ld1.s	{ v23 }[1], [x10]
	add.2d	v20, v12, v20
	tbz	w9, #2, LBB0_194
LBB0_218:                               ; %cond.load1250
                                        ;   in Loop: Header=BB0_183 Depth=2
	fmov	x10, d20
	ld1.s	{ v23 }[2], [x10]
	tbz	w9, #3, LBB0_195
LBB0_219:                               ; %cond.load1256
                                        ;   in Loop: Header=BB0_183 Depth=2
	mov.d	x10, v20[1]
	ld1.s	{ v23 }[3], [x10]
	add.2d	v20, v13, v21
	tbz	w9, #4, LBB0_196
LBB0_220:                               ; %cond.load1262
                                        ;   in Loop: Header=BB0_183 Depth=2
	fmov	x10, d20
	ld1.s	{ v19 }[0], [x10]
	tbz	w9, #5, LBB0_197
LBB0_221:                               ; %cond.load1268
                                        ;   in Loop: Header=BB0_183 Depth=2
	mov.d	x10, v20[1]
	ld1.s	{ v19 }[1], [x10]
	add.2d	v20, v7, v22
	tbz	w9, #6, LBB0_198
LBB0_222:                               ; %cond.load1274
                                        ;   in Loop: Header=BB0_183 Depth=2
	fmov	x10, d20
	ld1.s	{ v19 }[2], [x10]
	tbnz	w9, #7, LBB0_199
	b	LBB0_200
LBB0_223:                               ; %cond.store1287
                                        ;   in Loop: Header=BB0_183 Depth=2
	fmov	x10, d21
	str	s20, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_202
LBB0_224:                               ; %cond.store1291
                                        ;   in Loop: Header=BB0_183 Depth=2
	mov.d	x10, v21[1]
	st1.s	{ v20 }[1], [x10]
	add.2d	v21, v18, v15
	add.2d	v21, v21, v17
	tbz	w9, #2, LBB0_203
LBB0_225:                               ; %cond.store1295
                                        ;   in Loop: Header=BB0_183 Depth=2
	fmov	x10, d21
	st1.s	{ v20 }[2], [x10]
	tbz	w9, #3, LBB0_204
LBB0_226:                               ; %cond.store1299
                                        ;   in Loop: Header=BB0_183 Depth=2
	mov.d	x10, v21[1]
	st1.s	{ v20 }[3], [x10]
	fdiv.4s	v16, v16, v5
	fmul.4s	v16, v16, v19
	ldr	q19, [sp, #400]                 ; 16-byte Folded Reload
	add.2d	v19, v18, v19
	add.2d	v19, v19, v17
	tbz	w9, #4, LBB0_205
LBB0_227:                               ; %cond.store1303
                                        ;   in Loop: Header=BB0_183 Depth=2
	fmov	x10, d19
	str	s16, [x10]
	tbz	w9, #5, LBB0_206
LBB0_228:                               ; %cond.store1307
                                        ;   in Loop: Header=BB0_183 Depth=2
	mov.d	x10, v19[1]
	st1.s	{ v16 }[1], [x10]
	add.2d	v18, v18, v25
	add.2d	v17, v18, v17
	tbz	w9, #6, LBB0_207
LBB0_229:                               ; %cond.store1311
                                        ;   in Loop: Header=BB0_183 Depth=2
	fmov	x10, d17
	st1.s	{ v16 }[2], [x10]
	tbz	w9, #7, LBB0_182
LBB0_230:                               ; %cond.store1315
                                        ;   in Loop: Header=BB0_183 Depth=2
	mov.d	x9, v17[1]
	st1.s	{ v16 }[3], [x9]
	b	LBB0_182
LBB0_231:                               ; %cond.load764
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d17
	ldr	s7, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_63
LBB0_232:                               ; %cond.load770
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x10, v17[1]
	ld1.s	{ v7 }[1], [x10]
	add.2d	v18, v29, v9
	tbz	w9, #2, LBB0_64
LBB0_233:                               ; %cond.load776
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d18
	ld1.s	{ v7 }[2], [x10]
	tbz	w9, #3, LBB0_65
LBB0_234:                               ; %cond.load782
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x10, v18[1]
	ld1.s	{ v7 }[3], [x10]
	add.2d	v19, v30, v10
	tbz	w9, #4, LBB0_66
LBB0_235:                               ; %cond.load788
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d19
	ld1.s	{ v16 }[0], [x10]
	tbz	w9, #5, LBB0_67
LBB0_236:                               ; %cond.load794
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x10, v19[1]
	ld1.s	{ v16 }[1], [x10]
	add.2d	v20, v28, v8
	tbz	w9, #6, LBB0_68
LBB0_237:                               ; %cond.load800
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d20
	ld1.s	{ v16 }[2], [x10]
	tbnz	w9, #7, LBB0_69
	b	LBB0_70
LBB0_238:                               ; %cond.load813
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d24
	ldr	s21, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_72
LBB0_239:                               ; %cond.load819
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x10, v24[1]
	ld1.s	{ v21 }[1], [x10]
	add.2d	v5, v18, v23
	tbz	w9, #2, LBB0_73
LBB0_240:                               ; %cond.load825
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d5
	ld1.s	{ v21 }[2], [x10]
	tbz	w9, #3, LBB0_74
LBB0_241:                               ; %cond.load831
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x10, v5[1]
	ld1.s	{ v21 }[3], [x10]
	add.2d	v5, v19, v23
	tbz	w9, #4, LBB0_75
LBB0_242:                               ; %cond.load837
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d5
	ld1.s	{ v22 }[0], [x10]
	tbz	w9, #5, LBB0_76
LBB0_243:                               ; %cond.load843
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x10, v5[1]
	ld1.s	{ v22 }[1], [x10]
	add.2d	v5, v20, v23
	tbz	w9, #6, LBB0_77
LBB0_244:                               ; %cond.load849
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d5
	ld1.s	{ v22 }[2], [x10]
	str	q25, [sp, #336]                 ; 16-byte Folded Spill
	tbnz	w9, #7, LBB0_78
	b	LBB0_79
LBB0_245:                               ; %cond.load862
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d26
	ldr	s23, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_81
LBB0_246:                               ; %cond.load868
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x10, v26[1]
	ld1.s	{ v23 }[1], [x10]
	add.2d	v5, v18, v25
	tbz	w9, #2, LBB0_82
LBB0_247:                               ; %cond.load874
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d5
	ld1.s	{ v23 }[2], [x10]
	tbz	w9, #3, LBB0_83
LBB0_248:                               ; %cond.load880
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x10, v5[1]
	ld1.s	{ v23 }[3], [x10]
	add.2d	v5, v19, v25
	tbz	w9, #4, LBB0_84
LBB0_249:                               ; %cond.load886
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d5
	ld1.s	{ v24 }[0], [x10]
	tbz	w9, #5, LBB0_85
LBB0_250:                               ; %cond.load892
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x10, v5[1]
	ld1.s	{ v24 }[1], [x10]
	add.2d	v5, v20, v25
	tbz	w9, #6, LBB0_86
LBB0_251:                               ; %cond.load898
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d5
	ld1.s	{ v24 }[2], [x10]
	tbnz	w9, #7, LBB0_87
	b	LBB0_88
LBB0_252:                               ; %cond.load911
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d27
	ldr	s17, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_90
LBB0_253:                               ; %cond.load917
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x10, v27[1]
	ld1.s	{ v17 }[1], [x10]
	add.2d	v5, v18, v26
	tbz	w9, #2, LBB0_91
LBB0_254:                               ; %cond.load923
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d5
	ld1.s	{ v17 }[2], [x10]
	tbz	w9, #3, LBB0_92
LBB0_255:                               ; %cond.load929
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x10, v5[1]
	ld1.s	{ v17 }[3], [x10]
	add.2d	v5, v19, v26
	tbz	w9, #4, LBB0_93
LBB0_256:                               ; %cond.load935
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d5
	ld1.s	{ v25 }[0], [x10]
	tbz	w9, #5, LBB0_94
LBB0_257:                               ; %cond.load941
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x10, v5[1]
	ld1.s	{ v25 }[1], [x10]
	add.2d	v5, v20, v26
	tbz	w9, #6, LBB0_95
LBB0_258:                               ; %cond.load947
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x10, d5
	ld1.s	{ v25 }[2], [x10]
	tbnz	w9, #7, LBB0_96
	b	LBB0_97
LBB0_259:                               ; %block.batch.exit.loopexit
	stp	w15, w14, [x1]
	str	w13, [x1, #8]
	mov	w8, #1016                       ; =0x3f8
	str	w8, [x1, #36]
LBB0_260:                               ; %block.batch.exit
	add	sp, sp, #496
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
.subsections_via_symbols

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [576 x i8], align 8
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local4 = alloca [72 x i8], align 1
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 9, i64 18, i64 27, i64 36, i64 45, i64 54, i64 63>, 1
  %tile_snapshot.local7 = alloca [288 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local10 = alloca [288 x i8], align 4
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %8 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %9 = insertvalue { <8 x ptr>, <8 x i64> } %8, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill13 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill13, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill14 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill14, align 1
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot16, align 64
  %.spill17 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill17, align 64
  %tile_snapshot.spill18 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill18, align 64
  %.slot19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot19, align 64
  %.spill20 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill20, align 4
  %tile_snapshot.spill21 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill21, align 64
  %.slot22 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot22, align 64
  %.spill23 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill23, align 4
  %.slot24 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot24, align 64
  %.slot25 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot25, align 32
  %.slot26 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot26, align 32
  %.slot27 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot27, align 32
  %.slot28 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot28, align 32
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.spill30 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill30, align 32
  %.spill31 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill31, align 32
  %.spill32 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill32, align 32
  %.spill33 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill33, align 4
  %.spill34 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill34, align 4
  %tile_snapshot.spill35 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill35, align 64
  %.slot36 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot36, align 64
  %.slot37 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot37, align 64
  %.slot38 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot38, align 32
  %.slot39 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot39, align 32
  %.slot40 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot40, align 32
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.spill43 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill43, align 4
  %.slot44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot44, align 64
  %10 = getelementptr i8, ptr %argument_buffer, i64 0
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 16
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 32
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = getelementptr i8, ptr %argument_buffer, i64 48
  %29 = load ptr, ptr %28, align 16
  %30 = getelementptr i8, ptr %28, i64 8
  %31 = load i64, ptr %30, align 8
  %32 = insertvalue { ptr, i64 } poison, ptr %29, 0
  %33 = insertvalue { ptr, i64 } %32, i64 %31, 1
  %34 = load i32, ptr %launch_config, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 12
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 4
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 16
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 8
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 20
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 36
  %46 = load i32, ptr %45, align 4
  %.splatinsert45 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat46 = shufflevector <8 x i32> %.splatinsert45, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat46, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %48 = mul i32 %34, 32
  %.splatinsert47 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat48 = shufflevector <8 x i32> %.splatinsert47, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat48, %47
  %50 = mul i32 %38, 1
  %.splatinsert49 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat50 = shufflevector <8 x i32> %.splatinsert49, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat50, zeroinitializer
  %52 = mul i32 %42, 1
  %.splatinsert51 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat52 = shufflevector <8 x i32> %.splatinsert51, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat52, zeroinitializer
  %54 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %49, 0
  %55 = insertvalue [3 x <8 x i32>] %54, <8 x i32> %51, 1
  %56 = insertvalue [3 x <8 x i32>] %55, <8 x i32> %53, 2
  %.splatinsert53 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat54 = shufflevector <8 x i32> %.splatinsert53, <8 x i32> poison, <8 x i32> zeroinitializer
  %57 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat54
  %58 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  br i1 %58, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %59 = extractvalue [3 x <8 x i32>] %56, 0
  %60 = load <8 x i64>, ptr %.spill, align 64
  %61 = select <8 x i1> %57, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %60
  store <8 x i64> %61, ptr %.spill, align 64
  %62 = sub <8 x i32> %59, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %63 = select <8 x i1> %57, <8 x i32> %62, <8 x i32> zeroinitializer
  %64 = select <8 x i1> %57, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %65 = lshr <8 x i32> %63, %64
  %66 = zext <8 x i32> %65 to <8 x i64>
  %67 = select <8 x i1> %57, <8 x i64> %66, <8 x i64> zeroinitializer
  %68 = select <8 x i1> %57, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %69 = sdiv <8 x i64> %67, %68
  %70 = load <8 x i64>, ptr %.spill13, align 64
  %71 = select <8 x i1> %57, <8 x i64> %69, <8 x i64> %70
  store <8 x i64> %71, ptr %.spill13, align 64
  %72 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %74 = extractvalue { <8 x ptr>, <8 x i64> } %72, 0
  %75 = select <8 x i1> %57, <8 x ptr> %73, <8 x ptr> %74
  %76 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %77 = extractvalue { <8 x ptr>, <8 x i64> } %72, 1
  %78 = select <8 x i1> %57, <8 x i64> %76, <8 x i64> %77
  %79 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %75, 0
  %80 = insertvalue { <8 x ptr>, <8 x i64> } %79, <8 x i64> %78, 1
  store { <8 x ptr>, <8 x i64> } %80, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %81 = icmp slt i64 %.state, 8
  br i1 %81, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state55 = load i64, ptr %.slot, align 4
  %82 = mul i64 %.state55, 8
  %.splatinsert56 = insertelement <8 x i64> poison, i64 %82, i64 0
  %.splat57 = shufflevector <8 x i64> %.splatinsert56, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %83 = add <8 x i64> %.splat57, %.spill.load
  %.spill.load58 = load <8 x i64>, ptr %.spill13, align 64
  %84 = add <8 x i64> %.spill.load58, zeroinitializer
  %85 = add <8 x i64> zeroinitializer, %84
  %86 = add <8 x i64> zeroinitializer, %83
  %87 = mul <8 x i64> %85, splat (i64 65)
  %88 = add <8 x i64> %87, %86
  %89 = extractvalue { ptr, i64 } %15, 0
  %90 = extractelement <8 x i64> %88, i32 0
  %91 = sub i64 %90, 0
  %92 = mul i64 %91, 4
  %buffer.contiguous.address = getelementptr i8, ptr %89, i64 %92
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %57, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state59 = load i64, ptr %.slot, align 4
  %.splatinsert60 = insertelement <8 x i64> poison, i64 %.state59, i64 0
  %.splat61 = shufflevector <8 x i64> %.splatinsert60, <8 x i64> poison, <8 x i32> zeroinitializer
  %95 = mul <8 x i64> %.splat61, splat (i64 32)
  %96 = add <8 x i64> %94, %95
  %97 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %93, 0
  %98 = insertvalue { <8 x ptr>, <8 x i64> } %97, <8 x i64> %96, 1
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %100 = extractvalue { <8 x ptr>, <8 x i64> } %98, 1
  %101 = extractelement <8 x ptr> %99, i32 0
  %102 = extractelement <8 x i64> %100, i32 0
  %103 = sub i64 %102, 0
  %104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %105 = select i1 %104, i64 %103, i64 0
  %private.contiguous.address = getelementptr i8, ptr %101, i64 %105
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %106 = select <8 x i1> %57, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %106, ptr %private.contiguous.address, align 4
  %.state62 = load i64, ptr %.slot, align 4
  %107 = add i64 %.state62, 1
  store i64 %107, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load63 = load <8 x i64>, ptr %.spill, align 64
  %108 = icmp slt <8 x i64> %.spill.load63, splat (i64 1)
  %109 = load <8 x i1>, ptr %.spill14, align 1
  %110 = select <8 x i1> %57, <8 x i1> %108, <8 x i1> %109
  store <8 x i1> %110, ptr %.spill14, align 1
  %111 = and <8 x i1> %57, %108
  %112 = xor <8 x i1> %108, splat (i1 true)
  %113 = and <8 x i1> %57, %112
  %114 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  %115 = bitcast <8 x i1> %111 to i8
  %116 = call i8 @llvm.cttz.i8(i8 %115, i1 false)
  %117 = zext i8 %116 to i32
  %118 = select i1 %114, i32 %117, i32 0
  %.spill.load64 = load <8 x i64>, ptr %.spill, align 64
  %119 = add <8 x i64> splat (i64 64), %.spill.load64
  %.spill.load65 = load <8 x i64>, ptr %.spill13, align 64
  %120 = add <8 x i64> %.spill.load65, zeroinitializer
  %121 = add <8 x i64> zeroinitializer, %120
  %122 = add <8 x i64> zeroinitializer, %119
  %123 = mul <8 x i64> %121, splat (i64 65)
  %124 = add <8 x i64> %123, %122
  %125 = extractvalue { ptr, i64 } %15, 0
  %126 = select <8 x i1> %111, <8 x i64> %124, <8 x i64> zeroinitializer
  %127 = extractelement <8 x i64> %126, i32 %118
  %128 = zext i32 %118 to i64
  %129 = sub i64 %127, %128
  %130 = mul i64 %129, 4
  %buffer.contiguous.address66 = getelementptr i8, ptr %125, i64 %130
  %buffer.contiguous.load67 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address66, i32 1, <8 x i1> %111, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 0
  %132 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 1
  %133 = add <8 x i64> %132, splat (i64 256)
  %134 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %131, 0
  %135 = insertvalue { <8 x ptr>, <8 x i64> } %134, <8 x i64> %133, 1
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %135, 1
  %138 = extractelement <8 x ptr> %136, i32 0
  %139 = extractelement <8 x i64> %137, i32 %118
  %140 = zext i32 %118 to i64
  %141 = mul i64 %140, 4
  %142 = sub i64 %139, %141
  %143 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  %144 = select i1 %143, i64 %142, i64 0
  %private.contiguous.address69 = getelementptr i8, ptr %138, i64 %144
  %private.contiguous.preserve70 = load <8 x float>, ptr %private.contiguous.address69, align 4
  %145 = select <8 x i1> %111, <8 x float> %buffer.contiguous.load67, <8 x float> %private.contiguous.preserve70
  store <8 x float> %145, ptr %private.contiguous.address69, align 4
  %146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %113)
  %147 = bitcast <8 x i1> %113 to i8
  %148 = call i8 @llvm.cttz.i8(i8 %147, i1 false)
  %149 = zext i8 %148 to i32
  %150 = select i1 %146, i32 %149, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  %151 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %151, 0
  %154 = select <8 x i1> %57, <8 x ptr> %152, <8 x ptr> %153
  %155 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %151, 1
  %157 = select <8 x i1> %57, <8 x i64> %155, <8 x i64> %156
  %158 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %154, 0
  %159 = insertvalue { <8 x ptr>, <8 x i64> } %158, <8 x i64> %157, 1
  store { <8 x ptr>, <8 x i64> } %159, ptr %tile_snapshot.spill15, align 64
  %160 = load <8 x i64>, ptr %.slot16, align 64
  %161 = select <8 x i1> %57, <8 x i64> zeroinitializer, <8 x i64> %160
  store <8 x i64> %161, ptr %.slot16, align 64
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state71 = load <8 x i64>, ptr %.slot16, align 64
  %162 = icmp slt <8 x i64> %.state71, splat (i64 8)
  %163 = extractelement <8 x i1> %162, i32 0
  br i1 %163, label %direct.true72, label %direct.false73

direct.schedule.7:                                ; preds = %direct.true72
  %.state74 = load <8 x i64>, ptr %.slot16, align 64
  %164 = mul <8 x i64> %.state74, splat (i64 8)
  %.spill.load75 = load <8 x i64>, ptr %.spill, align 64
  %165 = add <8 x i64> %164, %.spill.load75
  %tile_snapshot.spill.load76 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 1
  %.state77 = load <8 x i64>, ptr %.slot16, align 64
  %168 = mul <8 x i64> %.state77, splat (i64 64)
  %169 = add <8 x i64> %167, %168
  %170 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %166, 0
  %171 = insertvalue { <8 x ptr>, <8 x i64> } %170, <8 x i64> %169, 1
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %174 = extractelement <8 x ptr> %172, i32 0
  %175 = extractelement <8 x i64> %173, i32 0
  %176 = sub i64 %175, 0
  %177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %178 = select i1 %177, i64 %176, i64 0
  %private.contiguous.address78 = getelementptr i8, ptr %174, i64 %178
  %private.contiguous.preserve79 = load <8 x i64>, ptr %private.contiguous.address78, align 8
  %179 = select <8 x i1> %57, <8 x i64> %165, <8 x i64> %private.contiguous.preserve79
  store <8 x i64> %179, ptr %private.contiguous.address78, align 8
  %.state80 = load <8 x i64>, ptr %.slot16, align 64
  %180 = add <8 x i64> %.state80, splat (i64 1)
  %181 = load <8 x i64>, ptr %.slot16, align 64
  %182 = select <8 x i1> %57, <8 x i64> %180, <8 x i64> %181
  store <8 x i64> %182, ptr %.slot16, align 64
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false73
  %.spill.load81 = load <8 x i1>, ptr %.spill14, align 1
  %183 = and <8 x i1> %57, %.spill.load81
  %184 = xor <8 x i1> %.spill.load81, splat (i1 true)
  %185 = and <8 x i1> %57, %184
  %186 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %183)
  %187 = bitcast <8 x i1> %183 to i8
  %188 = call i8 @llvm.cttz.i8(i8 %187, i1 false)
  %189 = zext i8 %188 to i32
  %190 = select i1 %186, i32 %189, i32 0
  %.spill.load82 = load <8 x i64>, ptr %.spill, align 64
  %191 = add <8 x i64> splat (i64 64), %.spill.load82
  %tile_snapshot.spill.load83 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 1
  %194 = add <8 x i64> %193, splat (i64 512)
  %195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %192, 0
  %196 = insertvalue { <8 x ptr>, <8 x i64> } %195, <8 x i64> %194, 1
  %197 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %196, 1
  %199 = extractelement <8 x ptr> %197, i32 0
  %200 = extractelement <8 x i64> %198, i32 %190
  %201 = zext i32 %190 to i64
  %202 = mul i64 %201, 8
  %203 = sub i64 %200, %202
  %204 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %183)
  %205 = select i1 %204, i64 %203, i64 0
  %private.contiguous.address84 = getelementptr i8, ptr %199, i64 %205
  %private.contiguous.preserve85 = load <8 x i64>, ptr %private.contiguous.address84, align 8
  %206 = select <8 x i1> %183, <8 x i64> %191, <8 x i64> %private.contiguous.preserve85
  store <8 x i64> %206, ptr %private.contiguous.address84, align 8
  %207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %185)
  %208 = bitcast <8 x i1> %185 to i8
  %209 = call i8 @llvm.cttz.i8(i8 %208, i1 false)
  %210 = zext i8 %209 to i32
  %211 = select i1 %207, i32 %210, i32 0
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %.spill.load86 = load <8 x i64>, ptr %.spill13, align 64
  %212 = select <8 x i1> %57, <8 x i64> %.spill.load86, <8 x i64> zeroinitializer
  %213 = select <8 x i1> %57, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %214 = srem <8 x i64> %212, %213
  %215 = load <8 x i64>, ptr %.spill17, align 64
  %216 = select <8 x i1> %57, <8 x i64> %214, <8 x i64> %215
  store <8 x i64> %216, ptr %.spill17, align 64
  %217 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %217, 0
  %220 = select <8 x i1> %57, <8 x ptr> %218, <8 x ptr> %219
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %217, 1
  %223 = select <8 x i1> %57, <8 x i64> %221, <8 x i64> %222
  %224 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %220, 0
  %225 = insertvalue { <8 x ptr>, <8 x i64> } %224, <8 x i64> %223, 1
  store { <8 x ptr>, <8 x i64> } %225, ptr %tile_snapshot.spill18, align 64
  %226 = load <8 x i64>, ptr %.slot19, align 64
  %227 = select <8 x i1> %57, <8 x i64> zeroinitializer, <8 x i64> %226
  store <8 x i64> %227, ptr %.slot19, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state87 = load <8 x i64>, ptr %.slot19, align 64
  %228 = icmp slt <8 x i64> %.state87, splat (i64 8)
  %229 = extractelement <8 x i1> %228, i32 0
  br i1 %229, label %direct.true88, label %direct.false89

direct.schedule.12:                               ; preds = %direct.true88
  %tile_snapshot.spill.load90 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load90, 0
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load90, 1
  %.state91 = load <8 x i64>, ptr %.slot19, align 64
  %232 = mul <8 x i64> %.state91, splat (i64 64)
  %233 = add <8 x i64> %231, %232
  %234 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %230, 0
  %235 = insertvalue { <8 x ptr>, <8 x i64> } %234, <8 x i64> %233, 1
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %235, 1
  %238 = extractelement <8 x ptr> %236, i32 0
  %239 = extractelement <8 x i64> %237, i32 0
  %240 = sub i64 %239, 0
  %241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %242 = select i1 %241, i64 %240, i64 0
  %private.contiguous.address92 = getelementptr i8, ptr %238, i64 %242
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address92, align 8
  %243 = select <8 x i1> %57, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load93 = load <8 x i64>, ptr %.spill17, align 64
  %244 = icmp sle <8 x i64> %243, %.spill.load93
  %tile_snapshot.spill.load94 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %245 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 0
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 1
  %.state95 = load <8 x i64>, ptr %.slot19, align 64
  %247 = add <8 x i64> %246, %.state95
  %248 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %245, 0
  %249 = insertvalue { <8 x ptr>, <8 x i64> } %248, <8 x i64> %247, 1
  %250 = extractvalue { <8 x ptr>, <8 x i64> } %249, 0
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %249, 1
  %252 = getelementptr i8, <8 x ptr> %250, <8 x i64> %251
  %253 = zext <8 x i1> %244 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %253, <8 x ptr> %252, i32 1, <8 x i1> %57)
  %.state96 = load <8 x i64>, ptr %.slot19, align 64
  %254 = add <8 x i64> %.state96, splat (i64 1)
  %255 = load <8 x i64>, ptr %.slot19, align 64
  %256 = select <8 x i1> %57, <8 x i64> %254, <8 x i64> %255
  store <8 x i64> %256, ptr %.slot19, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false89
  %.spill.load97 = load <8 x i1>, ptr %.spill14, align 1
  %257 = and <8 x i1> %57, %.spill.load97
  %258 = xor <8 x i1> %.spill.load97, splat (i1 true)
  %259 = and <8 x i1> %57, %258
  %260 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %257)
  %261 = bitcast <8 x i1> %257 to i8
  %262 = call i8 @llvm.cttz.i8(i8 %261, i1 false)
  %263 = zext i8 %262 to i32
  %264 = select i1 %260, i32 %263, i32 0
  %tile_snapshot.spill.load98 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 0
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 1
  %267 = add <8 x i64> %266, splat (i64 512)
  %268 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %265, 0
  %269 = insertvalue { <8 x ptr>, <8 x i64> } %268, <8 x i64> %267, 1
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %269, 1
  %272 = extractelement <8 x ptr> %270, i32 0
  %273 = extractelement <8 x i64> %271, i32 %264
  %274 = zext i32 %264 to i64
  %275 = mul i64 %274, 8
  %276 = sub i64 %273, %275
  %277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %257)
  %278 = select i1 %277, i64 %276, i64 0
  %private.contiguous.address99 = getelementptr i8, ptr %272, i64 %278
  %private.contiguous.load100 = load <8 x i64>, ptr %private.contiguous.address99, align 8
  %279 = select <8 x i1> %257, <8 x i64> %private.contiguous.load100, <8 x i64> zeroinitializer
  %.spill.load101 = load <8 x i64>, ptr %.spill17, align 64
  %280 = icmp sle <8 x i64> %279, %.spill.load101
  %tile_snapshot.spill.load102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 0
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 1
  %283 = add <8 x i64> %282, splat (i64 8)
  %284 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %281, 0
  %285 = insertvalue { <8 x ptr>, <8 x i64> } %284, <8 x i64> %283, 1
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %285, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %285, 1
  %288 = getelementptr i8, <8 x ptr> %286, <8 x i64> %287
  %289 = zext <8 x i1> %280 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %289, <8 x ptr> %288, i32 1, <8 x i1> %257)
  %290 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %259)
  %291 = bitcast <8 x i1> %259 to i8
  %292 = call i8 @llvm.cttz.i8(i8 %291, i1 false)
  %293 = zext i8 %292 to i32
  %294 = select i1 %290, i32 %293, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  store float 0xC6293E5940000000, ptr %.spill20, align 4
  %295 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %295, 0
  %298 = select <8 x i1> %57, <8 x ptr> %296, <8 x ptr> %297
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %295, 1
  %301 = select <8 x i1> %57, <8 x i64> %299, <8 x i64> %300
  %302 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %298, 0
  %303 = insertvalue { <8 x ptr>, <8 x i64> } %302, <8 x i64> %301, 1
  store { <8 x ptr>, <8 x i64> } %303, ptr %tile_snapshot.spill21, align 64
  %304 = load <8 x i64>, ptr %.slot22, align 64
  %305 = select <8 x i1> %57, <8 x i64> zeroinitializer, <8 x i64> %304
  store <8 x i64> %305, ptr %.slot22, align 64
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state103 = load <8 x i64>, ptr %.slot22, align 64
  %306 = icmp slt <8 x i64> %.state103, splat (i64 8)
  %307 = extractelement <8 x i1> %306, i32 0
  br i1 %307, label %direct.true104, label %direct.false105

direct.schedule.17:                               ; preds = %direct.true104
  %tile_snapshot.spill.load106 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 1
  %.state107 = load <8 x i64>, ptr %.slot22, align 64
  %310 = add <8 x i64> %309, %.state107
  %311 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %308, 0
  %312 = insertvalue { <8 x ptr>, <8 x i64> } %311, <8 x i64> %310, 1
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %312, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %312, 1
  %315 = getelementptr i8, <8 x ptr> %313, <8 x i64> %314
  %316 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %315, i32 1, <8 x i1> %57, <8 x i8> zeroinitializer)
  %317 = icmp ne <8 x i8> %316, zeroinitializer
  %tile_snapshot.spill.load108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 0
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 1
  %.state109 = load <8 x i64>, ptr %.slot22, align 64
  %320 = mul <8 x i64> %.state109, splat (i64 32)
  %321 = add <8 x i64> %319, %320
  %322 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %318, 0
  %323 = insertvalue { <8 x ptr>, <8 x i64> } %322, <8 x i64> %321, 1
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %323, 1
  %326 = extractelement <8 x ptr> %324, i32 0
  %327 = extractelement <8 x i64> %325, i32 0
  %328 = sub i64 %327, 0
  %329 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %330 = select i1 %329, i64 %328, i64 0
  %private.contiguous.address110 = getelementptr i8, ptr %326, i64 %330
  %private.contiguous.load111 = load <8 x float>, ptr %private.contiguous.address110, align 4
  %331 = select <8 x i1> %57, <8 x float> %private.contiguous.load111, <8 x float> zeroinitializer
  %.spill.load112 = load float, ptr %.spill20, align 4
  %.splatinsert113 = insertelement <8 x float> poison, float %.spill.load112, i64 0
  %.splat114 = shufflevector <8 x float> %.splatinsert113, <8 x float> poison, <8 x i32> zeroinitializer
  %332 = select <8 x i1> %317, <8 x float> %331, <8 x float> %.splat114
  %tile_snapshot.spill.load115 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 0
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 1
  %.state116 = load <8 x i64>, ptr %.slot22, align 64
  %335 = mul <8 x i64> %.state116, splat (i64 32)
  %336 = add <8 x i64> %334, %335
  %337 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %333, 0
  %338 = insertvalue { <8 x ptr>, <8 x i64> } %337, <8 x i64> %336, 1
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %338, 1
  %341 = extractelement <8 x ptr> %339, i32 0
  %342 = extractelement <8 x i64> %340, i32 0
  %343 = sub i64 %342, 0
  %344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %345 = select i1 %344, i64 %343, i64 0
  %private.contiguous.address117 = getelementptr i8, ptr %341, i64 %345
  %private.contiguous.preserve118 = load <8 x float>, ptr %private.contiguous.address117, align 4
  %346 = select <8 x i1> %57, <8 x float> %332, <8 x float> %private.contiguous.preserve118
  store <8 x float> %346, ptr %private.contiguous.address117, align 4
  %.state119 = load <8 x i64>, ptr %.slot22, align 64
  %347 = add <8 x i64> %.state119, splat (i64 1)
  %348 = load <8 x i64>, ptr %.slot22, align 64
  %349 = select <8 x i1> %57, <8 x i64> %347, <8 x i64> %348
  store <8 x i64> %349, ptr %.slot22, align 64
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false105
  %.spill.load120 = load <8 x i1>, ptr %.spill14, align 1
  %350 = and <8 x i1> %57, %.spill.load120
  %351 = xor <8 x i1> %.spill.load120, splat (i1 true)
  %352 = and <8 x i1> %57, %351
  %353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %350)
  %354 = bitcast <8 x i1> %350 to i8
  %355 = call i8 @llvm.cttz.i8(i8 %354, i1 false)
  %356 = zext i8 %355 to i32
  %357 = select i1 %353, i32 %356, i32 0
  %tile_snapshot.spill.load121 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 0
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 1
  %360 = add <8 x i64> %359, splat (i64 8)
  %361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %358, 0
  %362 = insertvalue { <8 x ptr>, <8 x i64> } %361, <8 x i64> %360, 1
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %362, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %362, 1
  %365 = getelementptr i8, <8 x ptr> %363, <8 x i64> %364
  %366 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %365, i32 1, <8 x i1> %350, <8 x i8> zeroinitializer)
  %367 = icmp ne <8 x i8> %366, zeroinitializer
  %tile_snapshot.spill.load122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %368 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 0
  %369 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 1
  %370 = add <8 x i64> %369, splat (i64 256)
  %371 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %368, 0
  %372 = insertvalue { <8 x ptr>, <8 x i64> } %371, <8 x i64> %370, 1
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %372, 1
  %375 = extractelement <8 x ptr> %373, i32 0
  %376 = extractelement <8 x i64> %374, i32 %357
  %377 = zext i32 %357 to i64
  %378 = mul i64 %377, 4
  %379 = sub i64 %376, %378
  %380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %350)
  %381 = select i1 %380, i64 %379, i64 0
  %private.contiguous.address123 = getelementptr i8, ptr %375, i64 %381
  %private.contiguous.load124 = load <8 x float>, ptr %private.contiguous.address123, align 4
  %382 = select <8 x i1> %350, <8 x float> %private.contiguous.load124, <8 x float> zeroinitializer
  %.spill.load125 = load float, ptr %.spill20, align 4
  %.splatinsert126 = insertelement <8 x float> poison, float %.spill.load125, i64 0
  %.splat127 = shufflevector <8 x float> %.splatinsert126, <8 x float> poison, <8 x i32> zeroinitializer
  %383 = select <8 x i1> %367, <8 x float> %382, <8 x float> %.splat127
  %tile_snapshot.spill.load128 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %384 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load128, 0
  %385 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load128, 1
  %386 = add <8 x i64> %385, splat (i64 256)
  %387 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %384, 0
  %388 = insertvalue { <8 x ptr>, <8 x i64> } %387, <8 x i64> %386, 1
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %388, 1
  %391 = extractelement <8 x ptr> %389, i32 0
  %392 = extractelement <8 x i64> %390, i32 %357
  %393 = zext i32 %357 to i64
  %394 = mul i64 %393, 4
  %395 = sub i64 %392, %394
  %396 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %350)
  %397 = select i1 %396, i64 %395, i64 0
  %private.contiguous.address129 = getelementptr i8, ptr %391, i64 %397
  %private.contiguous.preserve130 = load <8 x float>, ptr %private.contiguous.address129, align 4
  %398 = select <8 x i1> %350, <8 x float> %383, <8 x float> %private.contiguous.preserve130
  store <8 x float> %398, ptr %private.contiguous.address129, align 4
  %399 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %352)
  %400 = bitcast <8 x i1> %352 to i8
  %401 = call i8 @llvm.cttz.i8(i8 %400, i1 false)
  %402 = zext i8 %401 to i32
  %403 = select i1 %399, i32 %402, i32 0
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  store float 0xFFF0000000000000, ptr %.spill23, align 4
  %tile_snapshot.spill.load131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 0
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 1
  %406 = add <8 x i64> %405, zeroinitializer
  %407 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %404, 0
  %408 = insertvalue { <8 x ptr>, <8 x i64> } %407, <8 x i64> %406, 1
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %408, 1
  %411 = extractelement <8 x ptr> %409, i32 0
  %412 = extractelement <8 x i64> %410, i32 0
  %413 = sub i64 %412, 0
  %414 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %415 = select i1 %414, i64 %413, i64 0
  %private.contiguous.address132 = getelementptr i8, ptr %411, i64 %415
  %private.contiguous.load133 = load <8 x float>, ptr %private.contiguous.address132, align 4
  %416 = select <8 x i1> %57, <8 x float> %private.contiguous.load133, <8 x float> zeroinitializer
  %tile_snapshot.spill.load134 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %417 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load134, 0
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load134, 1
  %419 = add <8 x i64> %418, splat (i64 32)
  %420 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %417, 0
  %421 = insertvalue { <8 x ptr>, <8 x i64> } %420, <8 x i64> %419, 1
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %421, 1
  %424 = extractelement <8 x ptr> %422, i32 0
  %425 = extractelement <8 x i64> %423, i32 0
  %426 = sub i64 %425, 0
  %427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %428 = select i1 %427, i64 %426, i64 0
  %private.contiguous.address135 = getelementptr i8, ptr %424, i64 %428
  %private.contiguous.load136 = load <8 x float>, ptr %private.contiguous.address135, align 4
  %429 = select <8 x i1> %57, <8 x float> %private.contiguous.load136, <8 x float> zeroinitializer
  %tile_snapshot.spill.load137 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %430 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load137, 0
  %431 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load137, 1
  %432 = add <8 x i64> %431, splat (i64 64)
  %433 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %430, 0
  %434 = insertvalue { <8 x ptr>, <8 x i64> } %433, <8 x i64> %432, 1
  %435 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %436 = extractvalue { <8 x ptr>, <8 x i64> } %434, 1
  %437 = extractelement <8 x ptr> %435, i32 0
  %438 = extractelement <8 x i64> %436, i32 0
  %439 = sub i64 %438, 0
  %440 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %441 = select i1 %440, i64 %439, i64 0
  %private.contiguous.address138 = getelementptr i8, ptr %437, i64 %441
  %private.contiguous.load139 = load <8 x float>, ptr %private.contiguous.address138, align 4
  %442 = select <8 x i1> %57, <8 x float> %private.contiguous.load139, <8 x float> zeroinitializer
  %tile_snapshot.spill.load140 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %443 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load140, 0
  %444 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load140, 1
  %445 = add <8 x i64> %444, splat (i64 96)
  %446 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %443, 0
  %447 = insertvalue { <8 x ptr>, <8 x i64> } %446, <8 x i64> %445, 1
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %449 = extractvalue { <8 x ptr>, <8 x i64> } %447, 1
  %450 = extractelement <8 x ptr> %448, i32 0
  %451 = extractelement <8 x i64> %449, i32 0
  %452 = sub i64 %451, 0
  %453 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %454 = select i1 %453, i64 %452, i64 0
  %private.contiguous.address141 = getelementptr i8, ptr %450, i64 %454
  %private.contiguous.load142 = load <8 x float>, ptr %private.contiguous.address141, align 4
  %455 = select <8 x i1> %57, <8 x float> %private.contiguous.load142, <8 x float> zeroinitializer
  %456 = load <8 x i64>, ptr %.slot24, align 64
  %457 = select <8 x i1> %57, <8 x i64> splat (i64 4), <8 x i64> %456
  store <8 x i64> %457, ptr %.slot24, align 64
  %458 = load <8 x float>, ptr %.slot25, align 32
  %459 = select <8 x i1> %57, <8 x float> %416, <8 x float> %458
  store <8 x float> %459, ptr %.slot25, align 32
  %460 = load <8 x float>, ptr %.slot26, align 32
  %461 = select <8 x i1> %57, <8 x float> %429, <8 x float> %460
  store <8 x float> %461, ptr %.slot26, align 32
  %462 = load <8 x float>, ptr %.slot27, align 32
  %463 = select <8 x i1> %57, <8 x float> %442, <8 x float> %462
  store <8 x float> %463, ptr %.slot27, align 32
  %464 = load <8 x float>, ptr %.slot28, align 32
  %465 = select <8 x i1> %57, <8 x float> %455, <8 x float> %464
  store <8 x float> %465, ptr %.slot28, align 32
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.22, %direct.schedule.20
  %.state143 = load <8 x i64>, ptr %.slot24, align 64
  %466 = icmp slt <8 x i64> %.state143, splat (i64 8)
  %467 = extractelement <8 x i1> %466, i32 0
  br i1 %467, label %direct.true144, label %direct.false145

direct.schedule.22:                               ; preds = %direct.true144
  %.state146 = load <8 x i64>, ptr %.slot24, align 64
  %468 = add <8 x i64> %.state146, zeroinitializer
  %tile_snapshot.spill.load147 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %469 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %470 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %471 = mul <8 x i64> %468, splat (i64 32)
  %472 = add <8 x i64> %470, %471
  %473 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %469, 0
  %474 = insertvalue { <8 x ptr>, <8 x i64> } %473, <8 x i64> %472, 1
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %476 = extractvalue { <8 x ptr>, <8 x i64> } %474, 1
  %477 = extractelement <8 x ptr> %475, i32 0
  %478 = extractelement <8 x i64> %476, i32 0
  %479 = sub i64 %478, 0
  %480 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %481 = select i1 %480, i64 %479, i64 0
  %private.contiguous.address148 = getelementptr i8, ptr %477, i64 %481
  %private.contiguous.load149 = load <8 x float>, ptr %private.contiguous.address148, align 4
  %482 = select <8 x i1> %57, <8 x float> %private.contiguous.load149, <8 x float> zeroinitializer
  %.state150 = load <8 x float>, ptr %.slot25, align 32
  %483 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state150, <8 x float> %482)
  %.state151 = load <8 x i64>, ptr %.slot24, align 64
  %484 = add <8 x i64> %.state151, splat (i64 1)
  %tile_snapshot.spill.load152 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load152, 0
  %486 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load152, 1
  %487 = mul <8 x i64> %484, splat (i64 32)
  %488 = add <8 x i64> %486, %487
  %489 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %485, 0
  %490 = insertvalue { <8 x ptr>, <8 x i64> } %489, <8 x i64> %488, 1
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %492 = extractvalue { <8 x ptr>, <8 x i64> } %490, 1
  %493 = extractelement <8 x ptr> %491, i32 0
  %494 = extractelement <8 x i64> %492, i32 0
  %495 = sub i64 %494, 0
  %496 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %497 = select i1 %496, i64 %495, i64 0
  %private.contiguous.address153 = getelementptr i8, ptr %493, i64 %497
  %private.contiguous.load154 = load <8 x float>, ptr %private.contiguous.address153, align 4
  %498 = select <8 x i1> %57, <8 x float> %private.contiguous.load154, <8 x float> zeroinitializer
  %.state155 = load <8 x float>, ptr %.slot26, align 32
  %499 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state155, <8 x float> %498)
  %.state156 = load <8 x i64>, ptr %.slot24, align 64
  %500 = add <8 x i64> %.state156, splat (i64 2)
  %tile_snapshot.spill.load157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 0
  %502 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 1
  %503 = mul <8 x i64> %500, splat (i64 32)
  %504 = add <8 x i64> %502, %503
  %505 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %501, 0
  %506 = insertvalue { <8 x ptr>, <8 x i64> } %505, <8 x i64> %504, 1
  %507 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %508 = extractvalue { <8 x ptr>, <8 x i64> } %506, 1
  %509 = extractelement <8 x ptr> %507, i32 0
  %510 = extractelement <8 x i64> %508, i32 0
  %511 = sub i64 %510, 0
  %512 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %513 = select i1 %512, i64 %511, i64 0
  %private.contiguous.address158 = getelementptr i8, ptr %509, i64 %513
  %private.contiguous.load159 = load <8 x float>, ptr %private.contiguous.address158, align 4
  %514 = select <8 x i1> %57, <8 x float> %private.contiguous.load159, <8 x float> zeroinitializer
  %.state160 = load <8 x float>, ptr %.slot27, align 32
  %515 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state160, <8 x float> %514)
  %.state161 = load <8 x i64>, ptr %.slot24, align 64
  %516 = add <8 x i64> %.state161, splat (i64 3)
  %tile_snapshot.spill.load162 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 0
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 1
  %519 = mul <8 x i64> %516, splat (i64 32)
  %520 = add <8 x i64> %518, %519
  %521 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %517, 0
  %522 = insertvalue { <8 x ptr>, <8 x i64> } %521, <8 x i64> %520, 1
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %524 = extractvalue { <8 x ptr>, <8 x i64> } %522, 1
  %525 = extractelement <8 x ptr> %523, i32 0
  %526 = extractelement <8 x i64> %524, i32 0
  %527 = sub i64 %526, 0
  %528 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %529 = select i1 %528, i64 %527, i64 0
  %private.contiguous.address163 = getelementptr i8, ptr %525, i64 %529
  %private.contiguous.load164 = load <8 x float>, ptr %private.contiguous.address163, align 4
  %530 = select <8 x i1> %57, <8 x float> %private.contiguous.load164, <8 x float> zeroinitializer
  %.state165 = load <8 x float>, ptr %.slot28, align 32
  %531 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state165, <8 x float> %530)
  %.state166 = load <8 x i64>, ptr %.slot24, align 64
  %532 = add <8 x i64> %.state166, splat (i64 4)
  %533 = load <8 x i64>, ptr %.slot24, align 64
  %534 = select <8 x i1> %57, <8 x i64> %532, <8 x i64> %533
  store <8 x i64> %534, ptr %.slot24, align 64
  %535 = load <8 x float>, ptr %.slot25, align 32
  %536 = select <8 x i1> %57, <8 x float> %483, <8 x float> %535
  store <8 x float> %536, ptr %.slot25, align 32
  %537 = load <8 x float>, ptr %.slot26, align 32
  %538 = select <8 x i1> %57, <8 x float> %499, <8 x float> %537
  store <8 x float> %538, ptr %.slot26, align 32
  %539 = load <8 x float>, ptr %.slot27, align 32
  %540 = select <8 x i1> %57, <8 x float> %515, <8 x float> %539
  store <8 x float> %540, ptr %.slot27, align 32
  %541 = load <8 x float>, ptr %.slot28, align 32
  %542 = select <8 x i1> %57, <8 x float> %531, <8 x float> %541
  store <8 x float> %542, ptr %.slot28, align 32
  br label %direct.schedule.21

direct.schedule.23:                               ; preds = %direct.false145
  %.spill.load167 = load <8 x i1>, ptr %.spill14, align 1
  %543 = and <8 x i1> %57, %.spill.load167
  %544 = xor <8 x i1> %.spill.load167, splat (i1 true)
  %545 = and <8 x i1> %57, %544
  %546 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %543)
  %547 = bitcast <8 x i1> %543 to i8
  %548 = call i8 @llvm.cttz.i8(i8 %547, i1 false)
  %549 = zext i8 %548 to i32
  %550 = select i1 %546, i32 %549, i32 0
  %tile_snapshot.spill.load168 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %551 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load168, 0
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load168, 1
  %553 = add <8 x i64> %552, splat (i64 256)
  %554 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %551, 0
  %555 = insertvalue { <8 x ptr>, <8 x i64> } %554, <8 x i64> %553, 1
  %556 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %557 = extractvalue { <8 x ptr>, <8 x i64> } %555, 1
  %558 = extractelement <8 x ptr> %556, i32 0
  %559 = extractelement <8 x i64> %557, i32 %550
  %560 = zext i32 %550 to i64
  %561 = mul i64 %560, 4
  %562 = sub i64 %559, %561
  %563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %543)
  %564 = select i1 %563, i64 %562, i64 0
  %private.contiguous.address169 = getelementptr i8, ptr %558, i64 %564
  %private.contiguous.load170 = load <8 x float>, ptr %private.contiguous.address169, align 4
  %565 = select <8 x i1> %543, <8 x float> %private.contiguous.load170, <8 x float> zeroinitializer
  %.state171 = load <8 x float>, ptr %.slot25, align 32
  %566 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state171, <8 x float> %565)
  %567 = load <8 x float>, ptr %.slot29, align 32
  %568 = select <8 x i1> %543, <8 x float> %566, <8 x float> %567
  store <8 x float> %568, ptr %.slot29, align 32
  %569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %545)
  %570 = bitcast <8 x i1> %545 to i8
  %571 = call i8 @llvm.cttz.i8(i8 %570, i1 false)
  %572 = zext i8 %571 to i32
  %573 = select i1 %569, i32 %572, i32 0
  %.state172 = load <8 x float>, ptr %.slot25, align 32
  %574 = load <8 x float>, ptr %.slot29, align 32
  %575 = select <8 x i1> %545, <8 x float> %.state172, <8 x float> %574
  store <8 x float> %575, ptr %.slot29, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.23
  %.state173 = load <8 x float>, ptr %.slot29, align 32
  %.state174 = load <8 x float>, ptr %.slot26, align 32
  %576 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state173, <8 x float> %.state174)
  %.state175 = load <8 x float>, ptr %.slot27, align 32
  %577 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %576, <8 x float> %.state175)
  %.state176 = load <8 x float>, ptr %.slot28, align 32
  %578 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %577, <8 x float> %.state176)
  %.spill.load177 = load <8 x i64>, ptr %.spill, align 64
  %579 = trunc <8 x i64> %.spill.load177 to <8 x i32>
  %580 = xor <8 x i32> %579, splat (i32 1)
  %581 = load <8 x i32>, ptr %.spill30, align 32
  %582 = select <8 x i1> %57, <8 x i32> %580, <8 x i32> %581
  store <8 x i32> %582, ptr %.spill30, align 32
  %583 = extractelement <8 x i32> %580, i64 0
  %584 = icmp ult i32 %583, 8
  %585 = select i1 %584, i32 %583, i32 0
  %586 = extractelement <8 x i1> %57, i32 %585
  %587 = extractelement <8 x i1> %57, i64 0
  %588 = and i1 %584, %586
  %589 = and i1 %587, %588
  %590 = extractelement <8 x float> %578, i32 %585
  %591 = select i1 %589, float %590, float 0.000000e+00
  %592 = insertelement <8 x float> poison, float %591, i64 0
  %593 = xor i1 %589, true
  %594 = and i1 %587, %593
  %595 = insertelement <8 x i1> poison, i1 %594, i64 0
  %596 = extractelement <8 x i32> %580, i64 1
  %597 = icmp ult i32 %596, 8
  %598 = select i1 %597, i32 %596, i32 0
  %599 = extractelement <8 x i1> %57, i32 %598
  %600 = extractelement <8 x i1> %57, i64 1
  %601 = and i1 %597, %599
  %602 = and i1 %600, %601
  %603 = extractelement <8 x float> %578, i32 %598
  %604 = select i1 %602, float %603, float 0.000000e+00
  %605 = insertelement <8 x float> %592, float %604, i64 1
  %606 = xor i1 %602, true
  %607 = and i1 %600, %606
  %608 = insertelement <8 x i1> %595, i1 %607, i64 1
  %609 = extractelement <8 x i32> %580, i64 2
  %610 = icmp ult i32 %609, 8
  %611 = select i1 %610, i32 %609, i32 0
  %612 = extractelement <8 x i1> %57, i32 %611
  %613 = extractelement <8 x i1> %57, i64 2
  %614 = and i1 %610, %612
  %615 = and i1 %613, %614
  %616 = extractelement <8 x float> %578, i32 %611
  %617 = select i1 %615, float %616, float 0.000000e+00
  %618 = insertelement <8 x float> %605, float %617, i64 2
  %619 = xor i1 %615, true
  %620 = and i1 %613, %619
  %621 = insertelement <8 x i1> %608, i1 %620, i64 2
  %622 = extractelement <8 x i32> %580, i64 3
  %623 = icmp ult i32 %622, 8
  %624 = select i1 %623, i32 %622, i32 0
  %625 = extractelement <8 x i1> %57, i32 %624
  %626 = extractelement <8 x i1> %57, i64 3
  %627 = and i1 %623, %625
  %628 = and i1 %626, %627
  %629 = extractelement <8 x float> %578, i32 %624
  %630 = select i1 %628, float %629, float 0.000000e+00
  %631 = insertelement <8 x float> %618, float %630, i64 3
  %632 = xor i1 %628, true
  %633 = and i1 %626, %632
  %634 = insertelement <8 x i1> %621, i1 %633, i64 3
  %635 = extractelement <8 x i32> %580, i64 4
  %636 = icmp ult i32 %635, 8
  %637 = select i1 %636, i32 %635, i32 0
  %638 = extractelement <8 x i1> %57, i32 %637
  %639 = extractelement <8 x i1> %57, i64 4
  %640 = and i1 %636, %638
  %641 = and i1 %639, %640
  %642 = extractelement <8 x float> %578, i32 %637
  %643 = select i1 %641, float %642, float 0.000000e+00
  %644 = insertelement <8 x float> %631, float %643, i64 4
  %645 = xor i1 %641, true
  %646 = and i1 %639, %645
  %647 = insertelement <8 x i1> %634, i1 %646, i64 4
  %648 = extractelement <8 x i32> %580, i64 5
  %649 = icmp ult i32 %648, 8
  %650 = select i1 %649, i32 %648, i32 0
  %651 = extractelement <8 x i1> %57, i32 %650
  %652 = extractelement <8 x i1> %57, i64 5
  %653 = and i1 %649, %651
  %654 = and i1 %652, %653
  %655 = extractelement <8 x float> %578, i32 %650
  %656 = select i1 %654, float %655, float 0.000000e+00
  %657 = insertelement <8 x float> %644, float %656, i64 5
  %658 = xor i1 %654, true
  %659 = and i1 %652, %658
  %660 = insertelement <8 x i1> %647, i1 %659, i64 5
  %661 = extractelement <8 x i32> %580, i64 6
  %662 = icmp ult i32 %661, 8
  %663 = select i1 %662, i32 %661, i32 0
  %664 = extractelement <8 x i1> %57, i32 %663
  %665 = extractelement <8 x i1> %57, i64 6
  %666 = and i1 %662, %664
  %667 = and i1 %665, %666
  %668 = extractelement <8 x float> %578, i32 %663
  %669 = select i1 %667, float %668, float 0.000000e+00
  %670 = insertelement <8 x float> %657, float %669, i64 6
  %671 = xor i1 %667, true
  %672 = and i1 %665, %671
  %673 = insertelement <8 x i1> %660, i1 %672, i64 6
  %674 = extractelement <8 x i32> %580, i64 7
  %675 = icmp ult i32 %674, 8
  %676 = select i1 %675, i32 %674, i32 0
  %677 = extractelement <8 x i1> %57, i32 %676
  %678 = extractelement <8 x i1> %57, i64 7
  %679 = and i1 %675, %677
  %680 = and i1 %678, %679
  %681 = extractelement <8 x float> %578, i32 %676
  %682 = select i1 %680, float %681, float 0.000000e+00
  %683 = insertelement <8 x float> %670, float %682, i64 7
  %684 = xor i1 %680, true
  %685 = and i1 %678, %684
  %686 = insertelement <8 x i1> %673, i1 %685, i64 7
  %687 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %578, <8 x float> %683)
  %688 = xor <8 x i32> %579, splat (i32 2)
  %689 = load <8 x i32>, ptr %.spill31, align 32
  %690 = select <8 x i1> %57, <8 x i32> %688, <8 x i32> %689
  store <8 x i32> %690, ptr %.spill31, align 32
  %691 = extractelement <8 x i32> %688, i64 0
  %692 = icmp ult i32 %691, 8
  %693 = select i1 %692, i32 %691, i32 0
  %694 = extractelement <8 x i1> %57, i32 %693
  %695 = extractelement <8 x i1> %57, i64 0
  %696 = and i1 %692, %694
  %697 = and i1 %695, %696
  %698 = extractelement <8 x float> %687, i32 %693
  %699 = select i1 %697, float %698, float 0.000000e+00
  %700 = insertelement <8 x float> poison, float %699, i64 0
  %701 = xor i1 %697, true
  %702 = and i1 %695, %701
  %703 = insertelement <8 x i1> poison, i1 %702, i64 0
  %704 = extractelement <8 x i32> %688, i64 1
  %705 = icmp ult i32 %704, 8
  %706 = select i1 %705, i32 %704, i32 0
  %707 = extractelement <8 x i1> %57, i32 %706
  %708 = extractelement <8 x i1> %57, i64 1
  %709 = and i1 %705, %707
  %710 = and i1 %708, %709
  %711 = extractelement <8 x float> %687, i32 %706
  %712 = select i1 %710, float %711, float 0.000000e+00
  %713 = insertelement <8 x float> %700, float %712, i64 1
  %714 = xor i1 %710, true
  %715 = and i1 %708, %714
  %716 = insertelement <8 x i1> %703, i1 %715, i64 1
  %717 = extractelement <8 x i32> %688, i64 2
  %718 = icmp ult i32 %717, 8
  %719 = select i1 %718, i32 %717, i32 0
  %720 = extractelement <8 x i1> %57, i32 %719
  %721 = extractelement <8 x i1> %57, i64 2
  %722 = and i1 %718, %720
  %723 = and i1 %721, %722
  %724 = extractelement <8 x float> %687, i32 %719
  %725 = select i1 %723, float %724, float 0.000000e+00
  %726 = insertelement <8 x float> %713, float %725, i64 2
  %727 = xor i1 %723, true
  %728 = and i1 %721, %727
  %729 = insertelement <8 x i1> %716, i1 %728, i64 2
  %730 = extractelement <8 x i32> %688, i64 3
  %731 = icmp ult i32 %730, 8
  %732 = select i1 %731, i32 %730, i32 0
  %733 = extractelement <8 x i1> %57, i32 %732
  %734 = extractelement <8 x i1> %57, i64 3
  %735 = and i1 %731, %733
  %736 = and i1 %734, %735
  %737 = extractelement <8 x float> %687, i32 %732
  %738 = select i1 %736, float %737, float 0.000000e+00
  %739 = insertelement <8 x float> %726, float %738, i64 3
  %740 = xor i1 %736, true
  %741 = and i1 %734, %740
  %742 = insertelement <8 x i1> %729, i1 %741, i64 3
  %743 = extractelement <8 x i32> %688, i64 4
  %744 = icmp ult i32 %743, 8
  %745 = select i1 %744, i32 %743, i32 0
  %746 = extractelement <8 x i1> %57, i32 %745
  %747 = extractelement <8 x i1> %57, i64 4
  %748 = and i1 %744, %746
  %749 = and i1 %747, %748
  %750 = extractelement <8 x float> %687, i32 %745
  %751 = select i1 %749, float %750, float 0.000000e+00
  %752 = insertelement <8 x float> %739, float %751, i64 4
  %753 = xor i1 %749, true
  %754 = and i1 %747, %753
  %755 = insertelement <8 x i1> %742, i1 %754, i64 4
  %756 = extractelement <8 x i32> %688, i64 5
  %757 = icmp ult i32 %756, 8
  %758 = select i1 %757, i32 %756, i32 0
  %759 = extractelement <8 x i1> %57, i32 %758
  %760 = extractelement <8 x i1> %57, i64 5
  %761 = and i1 %757, %759
  %762 = and i1 %760, %761
  %763 = extractelement <8 x float> %687, i32 %758
  %764 = select i1 %762, float %763, float 0.000000e+00
  %765 = insertelement <8 x float> %752, float %764, i64 5
  %766 = xor i1 %762, true
  %767 = and i1 %760, %766
  %768 = insertelement <8 x i1> %755, i1 %767, i64 5
  %769 = extractelement <8 x i32> %688, i64 6
  %770 = icmp ult i32 %769, 8
  %771 = select i1 %770, i32 %769, i32 0
  %772 = extractelement <8 x i1> %57, i32 %771
  %773 = extractelement <8 x i1> %57, i64 6
  %774 = and i1 %770, %772
  %775 = and i1 %773, %774
  %776 = extractelement <8 x float> %687, i32 %771
  %777 = select i1 %775, float %776, float 0.000000e+00
  %778 = insertelement <8 x float> %765, float %777, i64 6
  %779 = xor i1 %775, true
  %780 = and i1 %773, %779
  %781 = insertelement <8 x i1> %768, i1 %780, i64 6
  %782 = extractelement <8 x i32> %688, i64 7
  %783 = icmp ult i32 %782, 8
  %784 = select i1 %783, i32 %782, i32 0
  %785 = extractelement <8 x i1> %57, i32 %784
  %786 = extractelement <8 x i1> %57, i64 7
  %787 = and i1 %783, %785
  %788 = and i1 %786, %787
  %789 = extractelement <8 x float> %687, i32 %784
  %790 = select i1 %788, float %789, float 0.000000e+00
  %791 = insertelement <8 x float> %778, float %790, i64 7
  %792 = xor i1 %788, true
  %793 = and i1 %786, %792
  %794 = insertelement <8 x i1> %781, i1 %793, i64 7
  %795 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %687, <8 x float> %791)
  %796 = xor <8 x i32> %579, splat (i32 4)
  %797 = load <8 x i32>, ptr %.spill32, align 32
  %798 = select <8 x i1> %57, <8 x i32> %796, <8 x i32> %797
  store <8 x i32> %798, ptr %.spill32, align 32
  %799 = extractelement <8 x i32> %796, i64 0
  %800 = icmp ult i32 %799, 8
  %801 = select i1 %800, i32 %799, i32 0
  %802 = extractelement <8 x i1> %57, i32 %801
  %803 = extractelement <8 x i1> %57, i64 0
  %804 = and i1 %800, %802
  %805 = and i1 %803, %804
  %806 = extractelement <8 x float> %795, i32 %801
  %807 = select i1 %805, float %806, float 0.000000e+00
  %808 = insertelement <8 x float> poison, float %807, i64 0
  %809 = xor i1 %805, true
  %810 = and i1 %803, %809
  %811 = insertelement <8 x i1> poison, i1 %810, i64 0
  %812 = extractelement <8 x i32> %796, i64 1
  %813 = icmp ult i32 %812, 8
  %814 = select i1 %813, i32 %812, i32 0
  %815 = extractelement <8 x i1> %57, i32 %814
  %816 = extractelement <8 x i1> %57, i64 1
  %817 = and i1 %813, %815
  %818 = and i1 %816, %817
  %819 = extractelement <8 x float> %795, i32 %814
  %820 = select i1 %818, float %819, float 0.000000e+00
  %821 = insertelement <8 x float> %808, float %820, i64 1
  %822 = xor i1 %818, true
  %823 = and i1 %816, %822
  %824 = insertelement <8 x i1> %811, i1 %823, i64 1
  %825 = extractelement <8 x i32> %796, i64 2
  %826 = icmp ult i32 %825, 8
  %827 = select i1 %826, i32 %825, i32 0
  %828 = extractelement <8 x i1> %57, i32 %827
  %829 = extractelement <8 x i1> %57, i64 2
  %830 = and i1 %826, %828
  %831 = and i1 %829, %830
  %832 = extractelement <8 x float> %795, i32 %827
  %833 = select i1 %831, float %832, float 0.000000e+00
  %834 = insertelement <8 x float> %821, float %833, i64 2
  %835 = xor i1 %831, true
  %836 = and i1 %829, %835
  %837 = insertelement <8 x i1> %824, i1 %836, i64 2
  %838 = extractelement <8 x i32> %796, i64 3
  %839 = icmp ult i32 %838, 8
  %840 = select i1 %839, i32 %838, i32 0
  %841 = extractelement <8 x i1> %57, i32 %840
  %842 = extractelement <8 x i1> %57, i64 3
  %843 = and i1 %839, %841
  %844 = and i1 %842, %843
  %845 = extractelement <8 x float> %795, i32 %840
  %846 = select i1 %844, float %845, float 0.000000e+00
  %847 = insertelement <8 x float> %834, float %846, i64 3
  %848 = xor i1 %844, true
  %849 = and i1 %842, %848
  %850 = insertelement <8 x i1> %837, i1 %849, i64 3
  %851 = extractelement <8 x i32> %796, i64 4
  %852 = icmp ult i32 %851, 8
  %853 = select i1 %852, i32 %851, i32 0
  %854 = extractelement <8 x i1> %57, i32 %853
  %855 = extractelement <8 x i1> %57, i64 4
  %856 = and i1 %852, %854
  %857 = and i1 %855, %856
  %858 = extractelement <8 x float> %795, i32 %853
  %859 = select i1 %857, float %858, float 0.000000e+00
  %860 = insertelement <8 x float> %847, float %859, i64 4
  %861 = xor i1 %857, true
  %862 = and i1 %855, %861
  %863 = insertelement <8 x i1> %850, i1 %862, i64 4
  %864 = extractelement <8 x i32> %796, i64 5
  %865 = icmp ult i32 %864, 8
  %866 = select i1 %865, i32 %864, i32 0
  %867 = extractelement <8 x i1> %57, i32 %866
  %868 = extractelement <8 x i1> %57, i64 5
  %869 = and i1 %865, %867
  %870 = and i1 %868, %869
  %871 = extractelement <8 x float> %795, i32 %866
  %872 = select i1 %870, float %871, float 0.000000e+00
  %873 = insertelement <8 x float> %860, float %872, i64 5
  %874 = xor i1 %870, true
  %875 = and i1 %868, %874
  %876 = insertelement <8 x i1> %863, i1 %875, i64 5
  %877 = extractelement <8 x i32> %796, i64 6
  %878 = icmp ult i32 %877, 8
  %879 = select i1 %878, i32 %877, i32 0
  %880 = extractelement <8 x i1> %57, i32 %879
  %881 = extractelement <8 x i1> %57, i64 6
  %882 = and i1 %878, %880
  %883 = and i1 %881, %882
  %884 = extractelement <8 x float> %795, i32 %879
  %885 = select i1 %883, float %884, float 0.000000e+00
  %886 = insertelement <8 x float> %873, float %885, i64 6
  %887 = xor i1 %883, true
  %888 = and i1 %881, %887
  %889 = insertelement <8 x i1> %876, i1 %888, i64 6
  %890 = extractelement <8 x i32> %796, i64 7
  %891 = icmp ult i32 %890, 8
  %892 = select i1 %891, i32 %890, i32 0
  %893 = extractelement <8 x i1> %57, i32 %892
  %894 = extractelement <8 x i1> %57, i64 7
  %895 = and i1 %891, %893
  %896 = and i1 %894, %895
  %897 = extractelement <8 x float> %795, i32 %892
  %898 = select i1 %896, float %897, float 0.000000e+00
  %899 = insertelement <8 x float> %886, float %898, i64 7
  %900 = xor i1 %896, true
  %901 = and i1 %894, %900
  %902 = insertelement <8 x i1> %889, i1 %901, i64 7
  %903 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %795, <8 x float> %899)
  %904 = extractelement <8 x i1> %57, i32 0
  %905 = extractelement <8 x i1> %57, i64 0
  %906 = and i1 true, %904
  %907 = and i1 %905, %906
  %908 = extractelement <8 x float> %903, i32 0
  %909 = select i1 %907, float %908, float 0.000000e+00
  %910 = insertelement <8 x float> poison, float %909, i64 0
  %911 = xor i1 %907, true
  %912 = and i1 %905, %911
  %913 = insertelement <8 x i1> poison, i1 %912, i64 0
  %914 = extractelement <8 x i1> %57, i32 0
  %915 = extractelement <8 x i1> %57, i64 1
  %916 = and i1 true, %914
  %917 = and i1 %915, %916
  %918 = extractelement <8 x float> %903, i32 0
  %919 = select i1 %917, float %918, float 0.000000e+00
  %920 = insertelement <8 x float> %910, float %919, i64 1
  %921 = xor i1 %917, true
  %922 = and i1 %915, %921
  %923 = insertelement <8 x i1> %913, i1 %922, i64 1
  %924 = extractelement <8 x i1> %57, i32 0
  %925 = extractelement <8 x i1> %57, i64 2
  %926 = and i1 true, %924
  %927 = and i1 %925, %926
  %928 = extractelement <8 x float> %903, i32 0
  %929 = select i1 %927, float %928, float 0.000000e+00
  %930 = insertelement <8 x float> %920, float %929, i64 2
  %931 = xor i1 %927, true
  %932 = and i1 %925, %931
  %933 = insertelement <8 x i1> %923, i1 %932, i64 2
  %934 = extractelement <8 x i1> %57, i32 0
  %935 = extractelement <8 x i1> %57, i64 3
  %936 = and i1 true, %934
  %937 = and i1 %935, %936
  %938 = extractelement <8 x float> %903, i32 0
  %939 = select i1 %937, float %938, float 0.000000e+00
  %940 = insertelement <8 x float> %930, float %939, i64 3
  %941 = xor i1 %937, true
  %942 = and i1 %935, %941
  %943 = insertelement <8 x i1> %933, i1 %942, i64 3
  %944 = extractelement <8 x i1> %57, i32 0
  %945 = extractelement <8 x i1> %57, i64 4
  %946 = and i1 true, %944
  %947 = and i1 %945, %946
  %948 = extractelement <8 x float> %903, i32 0
  %949 = select i1 %947, float %948, float 0.000000e+00
  %950 = insertelement <8 x float> %940, float %949, i64 4
  %951 = xor i1 %947, true
  %952 = and i1 %945, %951
  %953 = insertelement <8 x i1> %943, i1 %952, i64 4
  %954 = extractelement <8 x i1> %57, i32 0
  %955 = extractelement <8 x i1> %57, i64 5
  %956 = and i1 true, %954
  %957 = and i1 %955, %956
  %958 = extractelement <8 x float> %903, i32 0
  %959 = select i1 %957, float %958, float 0.000000e+00
  %960 = insertelement <8 x float> %950, float %959, i64 5
  %961 = xor i1 %957, true
  %962 = and i1 %955, %961
  %963 = insertelement <8 x i1> %953, i1 %962, i64 5
  %964 = extractelement <8 x i1> %57, i32 0
  %965 = extractelement <8 x i1> %57, i64 6
  %966 = and i1 true, %964
  %967 = and i1 %965, %966
  %968 = extractelement <8 x float> %903, i32 0
  %969 = select i1 %967, float %968, float 0.000000e+00
  %970 = insertelement <8 x float> %960, float %969, i64 6
  %971 = xor i1 %967, true
  %972 = and i1 %965, %971
  %973 = insertelement <8 x i1> %963, i1 %972, i64 6
  %974 = extractelement <8 x i1> %57, i32 0
  %975 = extractelement <8 x i1> %57, i64 7
  %976 = and i1 true, %974
  %977 = and i1 %975, %976
  %978 = extractelement <8 x float> %903, i32 0
  %979 = select i1 %977, float %978, float 0.000000e+00
  %980 = insertelement <8 x float> %970, float %979, i64 7
  %981 = xor i1 %977, true
  %982 = and i1 %975, %981
  %983 = insertelement <8 x i1> %973, i1 %982, i64 7
  %984 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %985 = bitcast <8 x i1> %57 to i8
  %986 = call i8 @llvm.cttz.i8(i8 %985, i1 false)
  %987 = zext i8 %986 to i32
  %988 = select i1 %984, i32 %987, i32 0
  %989 = extractelement <8 x float> %980, i32 %988
  %.spill.load178 = load float, ptr %.spill23, align 4
  %990 = call float @llvm.maxnum.f32(float %.spill.load178, float %989)
  store float %990, ptr %.spill33, align 4
  store float 0.000000e+00, ptr %.spill34, align 4
  %991 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %992 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %993 = extractvalue { <8 x ptr>, <8 x i64> } %991, 0
  %994 = select <8 x i1> %57, <8 x ptr> %992, <8 x ptr> %993
  %995 = extractvalue { <8 x ptr>, <8 x i64> } %9, 1
  %996 = extractvalue { <8 x ptr>, <8 x i64> } %991, 1
  %997 = select <8 x i1> %57, <8 x i64> %995, <8 x i64> %996
  %998 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %994, 0
  %999 = insertvalue { <8 x ptr>, <8 x i64> } %998, <8 x i64> %997, 1
  store { <8 x ptr>, <8 x i64> } %999, ptr %tile_snapshot.spill35, align 64
  %1000 = load <8 x i64>, ptr %.slot36, align 64
  %1001 = select <8 x i1> %57, <8 x i64> zeroinitializer, <8 x i64> %1000
  store <8 x i64> %1001, ptr %.slot36, align 64
  br label %direct.schedule.26

direct.schedule.26:                               ; preds = %direct.schedule.27, %direct.schedule.25
  %.state179 = load <8 x i64>, ptr %.slot36, align 64
  %1002 = icmp slt <8 x i64> %.state179, splat (i64 8)
  %1003 = extractelement <8 x i1> %1002, i32 0
  br i1 %1003, label %direct.true180, label %direct.false181

direct.schedule.27:                               ; preds = %direct.true180
  %tile_snapshot.spill.load182 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %1004 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 0
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 1
  %.state183 = load <8 x i64>, ptr %.slot36, align 64
  %1006 = add <8 x i64> %1005, %.state183
  %1007 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1004, 0
  %1008 = insertvalue { <8 x ptr>, <8 x i64> } %1007, <8 x i64> %1006, 1
  %1009 = extractvalue { <8 x ptr>, <8 x i64> } %1008, 0
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %1008, 1
  %1011 = getelementptr i8, <8 x ptr> %1009, <8 x i64> %1010
  %1012 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %1011, i32 1, <8 x i1> %57, <8 x i8> zeroinitializer)
  %1013 = icmp ne <8 x i8> %1012, zeroinitializer
  %tile_snapshot.spill.load184 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %1014 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 0
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 1
  %.state185 = load <8 x i64>, ptr %.slot36, align 64
  %1016 = mul <8 x i64> %.state185, splat (i64 32)
  %1017 = add <8 x i64> %1015, %1016
  %1018 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1014, 0
  %1019 = insertvalue { <8 x ptr>, <8 x i64> } %1018, <8 x i64> %1017, 1
  %1020 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1021 = extractvalue { <8 x ptr>, <8 x i64> } %1019, 1
  %1022 = extractelement <8 x ptr> %1020, i32 0
  %1023 = extractelement <8 x i64> %1021, i32 0
  %1024 = sub i64 %1023, 0
  %1025 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1026 = select i1 %1025, i64 %1024, i64 0
  %private.contiguous.address186 = getelementptr i8, ptr %1022, i64 %1026
  %private.contiguous.load187 = load <8 x float>, ptr %private.contiguous.address186, align 4
  %1027 = select <8 x i1> %57, <8 x float> %private.contiguous.load187, <8 x float> zeroinitializer
  %.spill.load188 = load float, ptr %.spill33, align 4
  %.splatinsert189 = insertelement <8 x float> poison, float %.spill.load188, i64 0
  %.splat190 = shufflevector <8 x float> %.splatinsert189, <8 x float> poison, <8 x i32> zeroinitializer
  %1028 = fsub <8 x float> %1027, %.splat190
  %1029 = select <8 x i1> %57, <8 x float> %1028, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1029)
  %.spill.load191 = load float, ptr %.spill34, align 4
  %.splatinsert192 = insertelement <8 x float> poison, float %.spill.load191, i64 0
  %.splat193 = shufflevector <8 x float> %.splatinsert192, <8 x float> poison, <8 x i32> zeroinitializer
  %1030 = select <8 x i1> %1013, <8 x float> %native.exp, <8 x float> %.splat193
  %tile_snapshot.spill.load194 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1031 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load194, 0
  %1032 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load194, 1
  %.state195 = load <8 x i64>, ptr %.slot36, align 64
  %1033 = mul <8 x i64> %.state195, splat (i64 32)
  %1034 = add <8 x i64> %1032, %1033
  %1035 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1031, 0
  %1036 = insertvalue { <8 x ptr>, <8 x i64> } %1035, <8 x i64> %1034, 1
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1038 = extractvalue { <8 x ptr>, <8 x i64> } %1036, 1
  %1039 = extractelement <8 x ptr> %1037, i32 0
  %1040 = extractelement <8 x i64> %1038, i32 0
  %1041 = sub i64 %1040, 0
  %1042 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1043 = select i1 %1042, i64 %1041, i64 0
  %private.contiguous.address196 = getelementptr i8, ptr %1039, i64 %1043
  %private.contiguous.preserve197 = load <8 x float>, ptr %private.contiguous.address196, align 4
  %1044 = select <8 x i1> %57, <8 x float> %1030, <8 x float> %private.contiguous.preserve197
  store <8 x float> %1044, ptr %private.contiguous.address196, align 4
  %.state198 = load <8 x i64>, ptr %.slot36, align 64
  %1045 = add <8 x i64> %.state198, splat (i64 1)
  %1046 = load <8 x i64>, ptr %.slot36, align 64
  %1047 = select <8 x i1> %57, <8 x i64> %1045, <8 x i64> %1046
  store <8 x i64> %1047, ptr %.slot36, align 64
  br label %direct.schedule.26

direct.schedule.28:                               ; preds = %direct.false181
  %.spill.load199 = load <8 x i1>, ptr %.spill14, align 1
  %1048 = and <8 x i1> %57, %.spill.load199
  %1049 = xor <8 x i1> %.spill.load199, splat (i1 true)
  %1050 = and <8 x i1> %57, %1049
  %1051 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1048)
  %1052 = bitcast <8 x i1> %1048 to i8
  %1053 = call i8 @llvm.cttz.i8(i8 %1052, i1 false)
  %1054 = zext i8 %1053 to i32
  %1055 = select i1 %1051, i32 %1054, i32 0
  %tile_snapshot.spill.load200 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %1056 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load200, 0
  %1057 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load200, 1
  %1058 = add <8 x i64> %1057, splat (i64 8)
  %1059 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1056, 0
  %1060 = insertvalue { <8 x ptr>, <8 x i64> } %1059, <8 x i64> %1058, 1
  %1061 = extractvalue { <8 x ptr>, <8 x i64> } %1060, 0
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %1060, 1
  %1063 = getelementptr i8, <8 x ptr> %1061, <8 x i64> %1062
  %1064 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %1063, i32 1, <8 x i1> %1048, <8 x i8> zeroinitializer)
  %1065 = icmp ne <8 x i8> %1064, zeroinitializer
  %tile_snapshot.spill.load201 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %1066 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 0
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 1
  %1068 = add <8 x i64> %1067, splat (i64 256)
  %1069 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1066, 0
  %1070 = insertvalue { <8 x ptr>, <8 x i64> } %1069, <8 x i64> %1068, 1
  %1071 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1072 = extractvalue { <8 x ptr>, <8 x i64> } %1070, 1
  %1073 = extractelement <8 x ptr> %1071, i32 0
  %1074 = extractelement <8 x i64> %1072, i32 %1055
  %1075 = zext i32 %1055 to i64
  %1076 = mul i64 %1075, 4
  %1077 = sub i64 %1074, %1076
  %1078 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1048)
  %1079 = select i1 %1078, i64 %1077, i64 0
  %private.contiguous.address202 = getelementptr i8, ptr %1073, i64 %1079
  %private.contiguous.load203 = load <8 x float>, ptr %private.contiguous.address202, align 4
  %1080 = select <8 x i1> %1048, <8 x float> %private.contiguous.load203, <8 x float> zeroinitializer
  %.spill.load204 = load float, ptr %.spill33, align 4
  %.splatinsert205 = insertelement <8 x float> poison, float %.spill.load204, i64 0
  %.splat206 = shufflevector <8 x float> %.splatinsert205, <8 x float> poison, <8 x i32> zeroinitializer
  %1081 = fsub <8 x float> %1080, %.splat206
  %1082 = select <8 x i1> %1048, <8 x float> %1081, <8 x float> zeroinitializer
  %native.exp207 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1082)
  %.spill.load208 = load float, ptr %.spill34, align 4
  %.splatinsert209 = insertelement <8 x float> poison, float %.spill.load208, i64 0
  %.splat210 = shufflevector <8 x float> %.splatinsert209, <8 x float> poison, <8 x i32> zeroinitializer
  %1083 = select <8 x i1> %1065, <8 x float> %native.exp207, <8 x float> %.splat210
  %tile_snapshot.spill.load211 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1084 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 0
  %1085 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 1
  %1086 = add <8 x i64> %1085, splat (i64 256)
  %1087 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1084, 0
  %1088 = insertvalue { <8 x ptr>, <8 x i64> } %1087, <8 x i64> %1086, 1
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1090 = extractvalue { <8 x ptr>, <8 x i64> } %1088, 1
  %1091 = extractelement <8 x ptr> %1089, i32 0
  %1092 = extractelement <8 x i64> %1090, i32 %1055
  %1093 = zext i32 %1055 to i64
  %1094 = mul i64 %1093, 4
  %1095 = sub i64 %1092, %1094
  %1096 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1048)
  %1097 = select i1 %1096, i64 %1095, i64 0
  %private.contiguous.address212 = getelementptr i8, ptr %1091, i64 %1097
  %private.contiguous.preserve213 = load <8 x float>, ptr %private.contiguous.address212, align 4
  %1098 = select <8 x i1> %1048, <8 x float> %1083, <8 x float> %private.contiguous.preserve213
  store <8 x float> %1098, ptr %private.contiguous.address212, align 4
  %1099 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1050)
  %1100 = bitcast <8 x i1> %1050 to i8
  %1101 = call i8 @llvm.cttz.i8(i8 %1100, i1 false)
  %1102 = zext i8 %1101 to i32
  %1103 = select i1 %1099, i32 %1102, i32 0
  br label %direct.schedule.30

direct.schedule.30:                               ; preds = %direct.schedule.28
  %tile_snapshot.spill.load214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1104 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 0
  %1105 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 1
  %1106 = add <8 x i64> %1105, zeroinitializer
  %1107 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1104, 0
  %1108 = insertvalue { <8 x ptr>, <8 x i64> } %1107, <8 x i64> %1106, 1
  %1109 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1110 = extractvalue { <8 x ptr>, <8 x i64> } %1108, 1
  %1111 = extractelement <8 x ptr> %1109, i32 0
  %1112 = extractelement <8 x i64> %1110, i32 0
  %1113 = sub i64 %1112, 0
  %1114 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1115 = select i1 %1114, i64 %1113, i64 0
  %private.contiguous.address215 = getelementptr i8, ptr %1111, i64 %1115
  %private.contiguous.load216 = load <8 x float>, ptr %private.contiguous.address215, align 4
  %1116 = select <8 x i1> %57, <8 x float> %private.contiguous.load216, <8 x float> zeroinitializer
  %tile_snapshot.spill.load217 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1117 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load217, 0
  %1118 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load217, 1
  %1119 = add <8 x i64> %1118, splat (i64 32)
  %1120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1117, 0
  %1121 = insertvalue { <8 x ptr>, <8 x i64> } %1120, <8 x i64> %1119, 1
  %1122 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1123 = extractvalue { <8 x ptr>, <8 x i64> } %1121, 1
  %1124 = extractelement <8 x ptr> %1122, i32 0
  %1125 = extractelement <8 x i64> %1123, i32 0
  %1126 = sub i64 %1125, 0
  %1127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1128 = select i1 %1127, i64 %1126, i64 0
  %private.contiguous.address218 = getelementptr i8, ptr %1124, i64 %1128
  %private.contiguous.load219 = load <8 x float>, ptr %private.contiguous.address218, align 4
  %1129 = select <8 x i1> %57, <8 x float> %private.contiguous.load219, <8 x float> zeroinitializer
  %tile_snapshot.spill.load220 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1130 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load220, 0
  %1131 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load220, 1
  %1132 = add <8 x i64> %1131, splat (i64 64)
  %1133 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1130, 0
  %1134 = insertvalue { <8 x ptr>, <8 x i64> } %1133, <8 x i64> %1132, 1
  %1135 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1136 = extractvalue { <8 x ptr>, <8 x i64> } %1134, 1
  %1137 = extractelement <8 x ptr> %1135, i32 0
  %1138 = extractelement <8 x i64> %1136, i32 0
  %1139 = sub i64 %1138, 0
  %1140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1141 = select i1 %1140, i64 %1139, i64 0
  %private.contiguous.address221 = getelementptr i8, ptr %1137, i64 %1141
  %private.contiguous.load222 = load <8 x float>, ptr %private.contiguous.address221, align 4
  %1142 = select <8 x i1> %57, <8 x float> %private.contiguous.load222, <8 x float> zeroinitializer
  %tile_snapshot.spill.load223 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1143 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load223, 0
  %1144 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load223, 1
  %1145 = add <8 x i64> %1144, splat (i64 96)
  %1146 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1143, 0
  %1147 = insertvalue { <8 x ptr>, <8 x i64> } %1146, <8 x i64> %1145, 1
  %1148 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1149 = extractvalue { <8 x ptr>, <8 x i64> } %1147, 1
  %1150 = extractelement <8 x ptr> %1148, i32 0
  %1151 = extractelement <8 x i64> %1149, i32 0
  %1152 = sub i64 %1151, 0
  %1153 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1154 = select i1 %1153, i64 %1152, i64 0
  %private.contiguous.address224 = getelementptr i8, ptr %1150, i64 %1154
  %private.contiguous.load225 = load <8 x float>, ptr %private.contiguous.address224, align 4
  %1155 = select <8 x i1> %57, <8 x float> %private.contiguous.load225, <8 x float> zeroinitializer
  %1156 = load <8 x i64>, ptr %.slot37, align 64
  %1157 = select <8 x i1> %57, <8 x i64> splat (i64 4), <8 x i64> %1156
  store <8 x i64> %1157, ptr %.slot37, align 64
  %1158 = load <8 x float>, ptr %.slot38, align 32
  %1159 = select <8 x i1> %57, <8 x float> %1116, <8 x float> %1158
  store <8 x float> %1159, ptr %.slot38, align 32
  %1160 = load <8 x float>, ptr %.slot39, align 32
  %1161 = select <8 x i1> %57, <8 x float> %1129, <8 x float> %1160
  store <8 x float> %1161, ptr %.slot39, align 32
  %1162 = load <8 x float>, ptr %.slot40, align 32
  %1163 = select <8 x i1> %57, <8 x float> %1142, <8 x float> %1162
  store <8 x float> %1163, ptr %.slot40, align 32
  %1164 = load <8 x float>, ptr %.slot41, align 32
  %1165 = select <8 x i1> %57, <8 x float> %1155, <8 x float> %1164
  store <8 x float> %1165, ptr %.slot41, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state226 = load <8 x i64>, ptr %.slot37, align 64
  %1166 = icmp slt <8 x i64> %.state226, splat (i64 8)
  %1167 = extractelement <8 x i1> %1166, i32 0
  br i1 %1167, label %direct.true227, label %direct.false228

direct.schedule.32:                               ; preds = %direct.true227
  %.state229 = load <8 x i64>, ptr %.slot37, align 64
  %1168 = add <8 x i64> %.state229, zeroinitializer
  %tile_snapshot.spill.load230 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load230, 0
  %1170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load230, 1
  %1171 = mul <8 x i64> %1168, splat (i64 32)
  %1172 = add <8 x i64> %1170, %1171
  %1173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1169, 0
  %1174 = insertvalue { <8 x ptr>, <8 x i64> } %1173, <8 x i64> %1172, 1
  %1175 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1176 = extractvalue { <8 x ptr>, <8 x i64> } %1174, 1
  %1177 = extractelement <8 x ptr> %1175, i32 0
  %1178 = extractelement <8 x i64> %1176, i32 0
  %1179 = sub i64 %1178, 0
  %1180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1181 = select i1 %1180, i64 %1179, i64 0
  %private.contiguous.address231 = getelementptr i8, ptr %1177, i64 %1181
  %private.contiguous.load232 = load <8 x float>, ptr %private.contiguous.address231, align 4
  %1182 = select <8 x i1> %57, <8 x float> %private.contiguous.load232, <8 x float> zeroinitializer
  %.state233 = load <8 x float>, ptr %.slot38, align 32
  %1183 = fadd <8 x float> %.state233, %1182
  %.state234 = load <8 x i64>, ptr %.slot37, align 64
  %1184 = add <8 x i64> %.state234, splat (i64 1)
  %tile_snapshot.spill.load235 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load235, 0
  %1186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load235, 1
  %1187 = mul <8 x i64> %1184, splat (i64 32)
  %1188 = add <8 x i64> %1186, %1187
  %1189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1185, 0
  %1190 = insertvalue { <8 x ptr>, <8 x i64> } %1189, <8 x i64> %1188, 1
  %1191 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %1190, 1
  %1193 = extractelement <8 x ptr> %1191, i32 0
  %1194 = extractelement <8 x i64> %1192, i32 0
  %1195 = sub i64 %1194, 0
  %1196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1197 = select i1 %1196, i64 %1195, i64 0
  %private.contiguous.address236 = getelementptr i8, ptr %1193, i64 %1197
  %private.contiguous.load237 = load <8 x float>, ptr %private.contiguous.address236, align 4
  %1198 = select <8 x i1> %57, <8 x float> %private.contiguous.load237, <8 x float> zeroinitializer
  %.state238 = load <8 x float>, ptr %.slot39, align 32
  %1199 = fadd <8 x float> %.state238, %1198
  %.state239 = load <8 x i64>, ptr %.slot37, align 64
  %1200 = add <8 x i64> %.state239, splat (i64 2)
  %tile_snapshot.spill.load240 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1201 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load240, 0
  %1202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load240, 1
  %1203 = mul <8 x i64> %1200, splat (i64 32)
  %1204 = add <8 x i64> %1202, %1203
  %1205 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1201, 0
  %1206 = insertvalue { <8 x ptr>, <8 x i64> } %1205, <8 x i64> %1204, 1
  %1207 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1208 = extractvalue { <8 x ptr>, <8 x i64> } %1206, 1
  %1209 = extractelement <8 x ptr> %1207, i32 0
  %1210 = extractelement <8 x i64> %1208, i32 0
  %1211 = sub i64 %1210, 0
  %1212 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1213 = select i1 %1212, i64 %1211, i64 0
  %private.contiguous.address241 = getelementptr i8, ptr %1209, i64 %1213
  %private.contiguous.load242 = load <8 x float>, ptr %private.contiguous.address241, align 4
  %1214 = select <8 x i1> %57, <8 x float> %private.contiguous.load242, <8 x float> zeroinitializer
  %.state243 = load <8 x float>, ptr %.slot40, align 32
  %1215 = fadd <8 x float> %.state243, %1214
  %.state244 = load <8 x i64>, ptr %.slot37, align 64
  %1216 = add <8 x i64> %.state244, splat (i64 3)
  %tile_snapshot.spill.load245 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1217 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load245, 0
  %1218 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load245, 1
  %1219 = mul <8 x i64> %1216, splat (i64 32)
  %1220 = add <8 x i64> %1218, %1219
  %1221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1217, 0
  %1222 = insertvalue { <8 x ptr>, <8 x i64> } %1221, <8 x i64> %1220, 1
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1224 = extractvalue { <8 x ptr>, <8 x i64> } %1222, 1
  %1225 = extractelement <8 x ptr> %1223, i32 0
  %1226 = extractelement <8 x i64> %1224, i32 0
  %1227 = sub i64 %1226, 0
  %1228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1229 = select i1 %1228, i64 %1227, i64 0
  %private.contiguous.address246 = getelementptr i8, ptr %1225, i64 %1229
  %private.contiguous.load247 = load <8 x float>, ptr %private.contiguous.address246, align 4
  %1230 = select <8 x i1> %57, <8 x float> %private.contiguous.load247, <8 x float> zeroinitializer
  %.state248 = load <8 x float>, ptr %.slot41, align 32
  %1231 = fadd <8 x float> %.state248, %1230
  %.state249 = load <8 x i64>, ptr %.slot37, align 64
  %1232 = add <8 x i64> %.state249, splat (i64 4)
  %1233 = load <8 x i64>, ptr %.slot37, align 64
  %1234 = select <8 x i1> %57, <8 x i64> %1232, <8 x i64> %1233
  store <8 x i64> %1234, ptr %.slot37, align 64
  %1235 = load <8 x float>, ptr %.slot38, align 32
  %1236 = select <8 x i1> %57, <8 x float> %1183, <8 x float> %1235
  store <8 x float> %1236, ptr %.slot38, align 32
  %1237 = load <8 x float>, ptr %.slot39, align 32
  %1238 = select <8 x i1> %57, <8 x float> %1199, <8 x float> %1237
  store <8 x float> %1238, ptr %.slot39, align 32
  %1239 = load <8 x float>, ptr %.slot40, align 32
  %1240 = select <8 x i1> %57, <8 x float> %1215, <8 x float> %1239
  store <8 x float> %1240, ptr %.slot40, align 32
  %1241 = load <8 x float>, ptr %.slot41, align 32
  %1242 = select <8 x i1> %57, <8 x float> %1231, <8 x float> %1241
  store <8 x float> %1242, ptr %.slot41, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false228
  %.spill.load250 = load <8 x i1>, ptr %.spill14, align 1
  %1243 = and <8 x i1> %57, %.spill.load250
  %1244 = xor <8 x i1> %.spill.load250, splat (i1 true)
  %1245 = and <8 x i1> %57, %1244
  %1246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1243)
  %1247 = bitcast <8 x i1> %1243 to i8
  %1248 = call i8 @llvm.cttz.i8(i8 %1247, i1 false)
  %1249 = zext i8 %1248 to i32
  %1250 = select i1 %1246, i32 %1249, i32 0
  %tile_snapshot.spill.load251 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 0
  %1252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 1
  %1253 = add <8 x i64> %1252, splat (i64 256)
  %1254 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1251, 0
  %1255 = insertvalue { <8 x ptr>, <8 x i64> } %1254, <8 x i64> %1253, 1
  %1256 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1257 = extractvalue { <8 x ptr>, <8 x i64> } %1255, 1
  %1258 = extractelement <8 x ptr> %1256, i32 0
  %1259 = extractelement <8 x i64> %1257, i32 %1250
  %1260 = zext i32 %1250 to i64
  %1261 = mul i64 %1260, 4
  %1262 = sub i64 %1259, %1261
  %1263 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1243)
  %1264 = select i1 %1263, i64 %1262, i64 0
  %private.contiguous.address252 = getelementptr i8, ptr %1258, i64 %1264
  %private.contiguous.load253 = load <8 x float>, ptr %private.contiguous.address252, align 4
  %1265 = select <8 x i1> %1243, <8 x float> %private.contiguous.load253, <8 x float> zeroinitializer
  %.state254 = load <8 x float>, ptr %.slot38, align 32
  %1266 = fadd <8 x float> %.state254, %1265
  %1267 = load <8 x float>, ptr %.slot42, align 32
  %1268 = select <8 x i1> %1243, <8 x float> %1266, <8 x float> %1267
  store <8 x float> %1268, ptr %.slot42, align 32
  %1269 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1245)
  %1270 = bitcast <8 x i1> %1245 to i8
  %1271 = call i8 @llvm.cttz.i8(i8 %1270, i1 false)
  %1272 = zext i8 %1271 to i32
  %1273 = select i1 %1269, i32 %1272, i32 0
  %.state255 = load <8 x float>, ptr %.slot38, align 32
  %1274 = load <8 x float>, ptr %.slot42, align 32
  %1275 = select <8 x i1> %1245, <8 x float> %.state255, <8 x float> %1274
  store <8 x float> %1275, ptr %.slot42, align 32
  br label %direct.schedule.35

direct.schedule.35:                               ; preds = %direct.schedule.33
  %.state256 = load <8 x float>, ptr %.slot42, align 32
  %.state257 = load <8 x float>, ptr %.slot39, align 32
  %1276 = fadd <8 x float> %.state256, %.state257
  %.state258 = load <8 x float>, ptr %.slot40, align 32
  %1277 = fadd <8 x float> %1276, %.state258
  %.state259 = load <8 x float>, ptr %.slot41, align 32
  %1278 = fadd <8 x float> %1277, %.state259
  %.spill.load260 = load <8 x i32>, ptr %.spill30, align 32
  %1279 = extractelement <8 x i32> %.spill.load260, i64 0
  %1280 = icmp ult i32 %1279, 8
  %1281 = select i1 %1280, i32 %1279, i32 0
  %1282 = extractelement <8 x i1> %57, i32 %1281
  %1283 = extractelement <8 x i1> %57, i64 0
  %1284 = and i1 %1280, %1282
  %1285 = and i1 %1283, %1284
  %1286 = extractelement <8 x float> %1278, i32 %1281
  %1287 = select i1 %1285, float %1286, float 0.000000e+00
  %1288 = insertelement <8 x float> poison, float %1287, i64 0
  %1289 = xor i1 %1285, true
  %1290 = and i1 %1283, %1289
  %1291 = insertelement <8 x i1> poison, i1 %1290, i64 0
  %1292 = extractelement <8 x i32> %.spill.load260, i64 1
  %1293 = icmp ult i32 %1292, 8
  %1294 = select i1 %1293, i32 %1292, i32 0
  %1295 = extractelement <8 x i1> %57, i32 %1294
  %1296 = extractelement <8 x i1> %57, i64 1
  %1297 = and i1 %1293, %1295
  %1298 = and i1 %1296, %1297
  %1299 = extractelement <8 x float> %1278, i32 %1294
  %1300 = select i1 %1298, float %1299, float 0.000000e+00
  %1301 = insertelement <8 x float> %1288, float %1300, i64 1
  %1302 = xor i1 %1298, true
  %1303 = and i1 %1296, %1302
  %1304 = insertelement <8 x i1> %1291, i1 %1303, i64 1
  %1305 = extractelement <8 x i32> %.spill.load260, i64 2
  %1306 = icmp ult i32 %1305, 8
  %1307 = select i1 %1306, i32 %1305, i32 0
  %1308 = extractelement <8 x i1> %57, i32 %1307
  %1309 = extractelement <8 x i1> %57, i64 2
  %1310 = and i1 %1306, %1308
  %1311 = and i1 %1309, %1310
  %1312 = extractelement <8 x float> %1278, i32 %1307
  %1313 = select i1 %1311, float %1312, float 0.000000e+00
  %1314 = insertelement <8 x float> %1301, float %1313, i64 2
  %1315 = xor i1 %1311, true
  %1316 = and i1 %1309, %1315
  %1317 = insertelement <8 x i1> %1304, i1 %1316, i64 2
  %1318 = extractelement <8 x i32> %.spill.load260, i64 3
  %1319 = icmp ult i32 %1318, 8
  %1320 = select i1 %1319, i32 %1318, i32 0
  %1321 = extractelement <8 x i1> %57, i32 %1320
  %1322 = extractelement <8 x i1> %57, i64 3
  %1323 = and i1 %1319, %1321
  %1324 = and i1 %1322, %1323
  %1325 = extractelement <8 x float> %1278, i32 %1320
  %1326 = select i1 %1324, float %1325, float 0.000000e+00
  %1327 = insertelement <8 x float> %1314, float %1326, i64 3
  %1328 = xor i1 %1324, true
  %1329 = and i1 %1322, %1328
  %1330 = insertelement <8 x i1> %1317, i1 %1329, i64 3
  %1331 = extractelement <8 x i32> %.spill.load260, i64 4
  %1332 = icmp ult i32 %1331, 8
  %1333 = select i1 %1332, i32 %1331, i32 0
  %1334 = extractelement <8 x i1> %57, i32 %1333
  %1335 = extractelement <8 x i1> %57, i64 4
  %1336 = and i1 %1332, %1334
  %1337 = and i1 %1335, %1336
  %1338 = extractelement <8 x float> %1278, i32 %1333
  %1339 = select i1 %1337, float %1338, float 0.000000e+00
  %1340 = insertelement <8 x float> %1327, float %1339, i64 4
  %1341 = xor i1 %1337, true
  %1342 = and i1 %1335, %1341
  %1343 = insertelement <8 x i1> %1330, i1 %1342, i64 4
  %1344 = extractelement <8 x i32> %.spill.load260, i64 5
  %1345 = icmp ult i32 %1344, 8
  %1346 = select i1 %1345, i32 %1344, i32 0
  %1347 = extractelement <8 x i1> %57, i32 %1346
  %1348 = extractelement <8 x i1> %57, i64 5
  %1349 = and i1 %1345, %1347
  %1350 = and i1 %1348, %1349
  %1351 = extractelement <8 x float> %1278, i32 %1346
  %1352 = select i1 %1350, float %1351, float 0.000000e+00
  %1353 = insertelement <8 x float> %1340, float %1352, i64 5
  %1354 = xor i1 %1350, true
  %1355 = and i1 %1348, %1354
  %1356 = insertelement <8 x i1> %1343, i1 %1355, i64 5
  %1357 = extractelement <8 x i32> %.spill.load260, i64 6
  %1358 = icmp ult i32 %1357, 8
  %1359 = select i1 %1358, i32 %1357, i32 0
  %1360 = extractelement <8 x i1> %57, i32 %1359
  %1361 = extractelement <8 x i1> %57, i64 6
  %1362 = and i1 %1358, %1360
  %1363 = and i1 %1361, %1362
  %1364 = extractelement <8 x float> %1278, i32 %1359
  %1365 = select i1 %1363, float %1364, float 0.000000e+00
  %1366 = insertelement <8 x float> %1353, float %1365, i64 6
  %1367 = xor i1 %1363, true
  %1368 = and i1 %1361, %1367
  %1369 = insertelement <8 x i1> %1356, i1 %1368, i64 6
  %1370 = extractelement <8 x i32> %.spill.load260, i64 7
  %1371 = icmp ult i32 %1370, 8
  %1372 = select i1 %1371, i32 %1370, i32 0
  %1373 = extractelement <8 x i1> %57, i32 %1372
  %1374 = extractelement <8 x i1> %57, i64 7
  %1375 = and i1 %1371, %1373
  %1376 = and i1 %1374, %1375
  %1377 = extractelement <8 x float> %1278, i32 %1372
  %1378 = select i1 %1376, float %1377, float 0.000000e+00
  %1379 = insertelement <8 x float> %1366, float %1378, i64 7
  %1380 = xor i1 %1376, true
  %1381 = and i1 %1374, %1380
  %1382 = insertelement <8 x i1> %1369, i1 %1381, i64 7
  %1383 = fadd <8 x float> %1278, %1379
  %.spill.load261 = load <8 x i32>, ptr %.spill31, align 32
  %1384 = extractelement <8 x i32> %.spill.load261, i64 0
  %1385 = icmp ult i32 %1384, 8
  %1386 = select i1 %1385, i32 %1384, i32 0
  %1387 = extractelement <8 x i1> %57, i32 %1386
  %1388 = extractelement <8 x i1> %57, i64 0
  %1389 = and i1 %1385, %1387
  %1390 = and i1 %1388, %1389
  %1391 = extractelement <8 x float> %1383, i32 %1386
  %1392 = select i1 %1390, float %1391, float 0.000000e+00
  %1393 = insertelement <8 x float> poison, float %1392, i64 0
  %1394 = xor i1 %1390, true
  %1395 = and i1 %1388, %1394
  %1396 = insertelement <8 x i1> poison, i1 %1395, i64 0
  %1397 = extractelement <8 x i32> %.spill.load261, i64 1
  %1398 = icmp ult i32 %1397, 8
  %1399 = select i1 %1398, i32 %1397, i32 0
  %1400 = extractelement <8 x i1> %57, i32 %1399
  %1401 = extractelement <8 x i1> %57, i64 1
  %1402 = and i1 %1398, %1400
  %1403 = and i1 %1401, %1402
  %1404 = extractelement <8 x float> %1383, i32 %1399
  %1405 = select i1 %1403, float %1404, float 0.000000e+00
  %1406 = insertelement <8 x float> %1393, float %1405, i64 1
  %1407 = xor i1 %1403, true
  %1408 = and i1 %1401, %1407
  %1409 = insertelement <8 x i1> %1396, i1 %1408, i64 1
  %1410 = extractelement <8 x i32> %.spill.load261, i64 2
  %1411 = icmp ult i32 %1410, 8
  %1412 = select i1 %1411, i32 %1410, i32 0
  %1413 = extractelement <8 x i1> %57, i32 %1412
  %1414 = extractelement <8 x i1> %57, i64 2
  %1415 = and i1 %1411, %1413
  %1416 = and i1 %1414, %1415
  %1417 = extractelement <8 x float> %1383, i32 %1412
  %1418 = select i1 %1416, float %1417, float 0.000000e+00
  %1419 = insertelement <8 x float> %1406, float %1418, i64 2
  %1420 = xor i1 %1416, true
  %1421 = and i1 %1414, %1420
  %1422 = insertelement <8 x i1> %1409, i1 %1421, i64 2
  %1423 = extractelement <8 x i32> %.spill.load261, i64 3
  %1424 = icmp ult i32 %1423, 8
  %1425 = select i1 %1424, i32 %1423, i32 0
  %1426 = extractelement <8 x i1> %57, i32 %1425
  %1427 = extractelement <8 x i1> %57, i64 3
  %1428 = and i1 %1424, %1426
  %1429 = and i1 %1427, %1428
  %1430 = extractelement <8 x float> %1383, i32 %1425
  %1431 = select i1 %1429, float %1430, float 0.000000e+00
  %1432 = insertelement <8 x float> %1419, float %1431, i64 3
  %1433 = xor i1 %1429, true
  %1434 = and i1 %1427, %1433
  %1435 = insertelement <8 x i1> %1422, i1 %1434, i64 3
  %1436 = extractelement <8 x i32> %.spill.load261, i64 4
  %1437 = icmp ult i32 %1436, 8
  %1438 = select i1 %1437, i32 %1436, i32 0
  %1439 = extractelement <8 x i1> %57, i32 %1438
  %1440 = extractelement <8 x i1> %57, i64 4
  %1441 = and i1 %1437, %1439
  %1442 = and i1 %1440, %1441
  %1443 = extractelement <8 x float> %1383, i32 %1438
  %1444 = select i1 %1442, float %1443, float 0.000000e+00
  %1445 = insertelement <8 x float> %1432, float %1444, i64 4
  %1446 = xor i1 %1442, true
  %1447 = and i1 %1440, %1446
  %1448 = insertelement <8 x i1> %1435, i1 %1447, i64 4
  %1449 = extractelement <8 x i32> %.spill.load261, i64 5
  %1450 = icmp ult i32 %1449, 8
  %1451 = select i1 %1450, i32 %1449, i32 0
  %1452 = extractelement <8 x i1> %57, i32 %1451
  %1453 = extractelement <8 x i1> %57, i64 5
  %1454 = and i1 %1450, %1452
  %1455 = and i1 %1453, %1454
  %1456 = extractelement <8 x float> %1383, i32 %1451
  %1457 = select i1 %1455, float %1456, float 0.000000e+00
  %1458 = insertelement <8 x float> %1445, float %1457, i64 5
  %1459 = xor i1 %1455, true
  %1460 = and i1 %1453, %1459
  %1461 = insertelement <8 x i1> %1448, i1 %1460, i64 5
  %1462 = extractelement <8 x i32> %.spill.load261, i64 6
  %1463 = icmp ult i32 %1462, 8
  %1464 = select i1 %1463, i32 %1462, i32 0
  %1465 = extractelement <8 x i1> %57, i32 %1464
  %1466 = extractelement <8 x i1> %57, i64 6
  %1467 = and i1 %1463, %1465
  %1468 = and i1 %1466, %1467
  %1469 = extractelement <8 x float> %1383, i32 %1464
  %1470 = select i1 %1468, float %1469, float 0.000000e+00
  %1471 = insertelement <8 x float> %1458, float %1470, i64 6
  %1472 = xor i1 %1468, true
  %1473 = and i1 %1466, %1472
  %1474 = insertelement <8 x i1> %1461, i1 %1473, i64 6
  %1475 = extractelement <8 x i32> %.spill.load261, i64 7
  %1476 = icmp ult i32 %1475, 8
  %1477 = select i1 %1476, i32 %1475, i32 0
  %1478 = extractelement <8 x i1> %57, i32 %1477
  %1479 = extractelement <8 x i1> %57, i64 7
  %1480 = and i1 %1476, %1478
  %1481 = and i1 %1479, %1480
  %1482 = extractelement <8 x float> %1383, i32 %1477
  %1483 = select i1 %1481, float %1482, float 0.000000e+00
  %1484 = insertelement <8 x float> %1471, float %1483, i64 7
  %1485 = xor i1 %1481, true
  %1486 = and i1 %1479, %1485
  %1487 = insertelement <8 x i1> %1474, i1 %1486, i64 7
  %1488 = fadd <8 x float> %1383, %1484
  %.spill.load262 = load <8 x i32>, ptr %.spill32, align 32
  %1489 = extractelement <8 x i32> %.spill.load262, i64 0
  %1490 = icmp ult i32 %1489, 8
  %1491 = select i1 %1490, i32 %1489, i32 0
  %1492 = extractelement <8 x i1> %57, i32 %1491
  %1493 = extractelement <8 x i1> %57, i64 0
  %1494 = and i1 %1490, %1492
  %1495 = and i1 %1493, %1494
  %1496 = extractelement <8 x float> %1488, i32 %1491
  %1497 = select i1 %1495, float %1496, float 0.000000e+00
  %1498 = insertelement <8 x float> poison, float %1497, i64 0
  %1499 = xor i1 %1495, true
  %1500 = and i1 %1493, %1499
  %1501 = insertelement <8 x i1> poison, i1 %1500, i64 0
  %1502 = extractelement <8 x i32> %.spill.load262, i64 1
  %1503 = icmp ult i32 %1502, 8
  %1504 = select i1 %1503, i32 %1502, i32 0
  %1505 = extractelement <8 x i1> %57, i32 %1504
  %1506 = extractelement <8 x i1> %57, i64 1
  %1507 = and i1 %1503, %1505
  %1508 = and i1 %1506, %1507
  %1509 = extractelement <8 x float> %1488, i32 %1504
  %1510 = select i1 %1508, float %1509, float 0.000000e+00
  %1511 = insertelement <8 x float> %1498, float %1510, i64 1
  %1512 = xor i1 %1508, true
  %1513 = and i1 %1506, %1512
  %1514 = insertelement <8 x i1> %1501, i1 %1513, i64 1
  %1515 = extractelement <8 x i32> %.spill.load262, i64 2
  %1516 = icmp ult i32 %1515, 8
  %1517 = select i1 %1516, i32 %1515, i32 0
  %1518 = extractelement <8 x i1> %57, i32 %1517
  %1519 = extractelement <8 x i1> %57, i64 2
  %1520 = and i1 %1516, %1518
  %1521 = and i1 %1519, %1520
  %1522 = extractelement <8 x float> %1488, i32 %1517
  %1523 = select i1 %1521, float %1522, float 0.000000e+00
  %1524 = insertelement <8 x float> %1511, float %1523, i64 2
  %1525 = xor i1 %1521, true
  %1526 = and i1 %1519, %1525
  %1527 = insertelement <8 x i1> %1514, i1 %1526, i64 2
  %1528 = extractelement <8 x i32> %.spill.load262, i64 3
  %1529 = icmp ult i32 %1528, 8
  %1530 = select i1 %1529, i32 %1528, i32 0
  %1531 = extractelement <8 x i1> %57, i32 %1530
  %1532 = extractelement <8 x i1> %57, i64 3
  %1533 = and i1 %1529, %1531
  %1534 = and i1 %1532, %1533
  %1535 = extractelement <8 x float> %1488, i32 %1530
  %1536 = select i1 %1534, float %1535, float 0.000000e+00
  %1537 = insertelement <8 x float> %1524, float %1536, i64 3
  %1538 = xor i1 %1534, true
  %1539 = and i1 %1532, %1538
  %1540 = insertelement <8 x i1> %1527, i1 %1539, i64 3
  %1541 = extractelement <8 x i32> %.spill.load262, i64 4
  %1542 = icmp ult i32 %1541, 8
  %1543 = select i1 %1542, i32 %1541, i32 0
  %1544 = extractelement <8 x i1> %57, i32 %1543
  %1545 = extractelement <8 x i1> %57, i64 4
  %1546 = and i1 %1542, %1544
  %1547 = and i1 %1545, %1546
  %1548 = extractelement <8 x float> %1488, i32 %1543
  %1549 = select i1 %1547, float %1548, float 0.000000e+00
  %1550 = insertelement <8 x float> %1537, float %1549, i64 4
  %1551 = xor i1 %1547, true
  %1552 = and i1 %1545, %1551
  %1553 = insertelement <8 x i1> %1540, i1 %1552, i64 4
  %1554 = extractelement <8 x i32> %.spill.load262, i64 5
  %1555 = icmp ult i32 %1554, 8
  %1556 = select i1 %1555, i32 %1554, i32 0
  %1557 = extractelement <8 x i1> %57, i32 %1556
  %1558 = extractelement <8 x i1> %57, i64 5
  %1559 = and i1 %1555, %1557
  %1560 = and i1 %1558, %1559
  %1561 = extractelement <8 x float> %1488, i32 %1556
  %1562 = select i1 %1560, float %1561, float 0.000000e+00
  %1563 = insertelement <8 x float> %1550, float %1562, i64 5
  %1564 = xor i1 %1560, true
  %1565 = and i1 %1558, %1564
  %1566 = insertelement <8 x i1> %1553, i1 %1565, i64 5
  %1567 = extractelement <8 x i32> %.spill.load262, i64 6
  %1568 = icmp ult i32 %1567, 8
  %1569 = select i1 %1568, i32 %1567, i32 0
  %1570 = extractelement <8 x i1> %57, i32 %1569
  %1571 = extractelement <8 x i1> %57, i64 6
  %1572 = and i1 %1568, %1570
  %1573 = and i1 %1571, %1572
  %1574 = extractelement <8 x float> %1488, i32 %1569
  %1575 = select i1 %1573, float %1574, float 0.000000e+00
  %1576 = insertelement <8 x float> %1563, float %1575, i64 6
  %1577 = xor i1 %1573, true
  %1578 = and i1 %1571, %1577
  %1579 = insertelement <8 x i1> %1566, i1 %1578, i64 6
  %1580 = extractelement <8 x i32> %.spill.load262, i64 7
  %1581 = icmp ult i32 %1580, 8
  %1582 = select i1 %1581, i32 %1580, i32 0
  %1583 = extractelement <8 x i1> %57, i32 %1582
  %1584 = extractelement <8 x i1> %57, i64 7
  %1585 = and i1 %1581, %1583
  %1586 = and i1 %1584, %1585
  %1587 = extractelement <8 x float> %1488, i32 %1582
  %1588 = select i1 %1586, float %1587, float 0.000000e+00
  %1589 = insertelement <8 x float> %1576, float %1588, i64 7
  %1590 = xor i1 %1586, true
  %1591 = and i1 %1584, %1590
  %1592 = insertelement <8 x i1> %1579, i1 %1591, i64 7
  %1593 = fadd <8 x float> %1488, %1589
  %1594 = extractelement <8 x i1> %57, i32 0
  %1595 = extractelement <8 x i1> %57, i64 0
  %1596 = and i1 true, %1594
  %1597 = and i1 %1595, %1596
  %1598 = extractelement <8 x float> %1593, i32 0
  %1599 = select i1 %1597, float %1598, float 0.000000e+00
  %1600 = insertelement <8 x float> poison, float %1599, i64 0
  %1601 = xor i1 %1597, true
  %1602 = and i1 %1595, %1601
  %1603 = insertelement <8 x i1> poison, i1 %1602, i64 0
  %1604 = extractelement <8 x i1> %57, i32 0
  %1605 = extractelement <8 x i1> %57, i64 1
  %1606 = and i1 true, %1604
  %1607 = and i1 %1605, %1606
  %1608 = extractelement <8 x float> %1593, i32 0
  %1609 = select i1 %1607, float %1608, float 0.000000e+00
  %1610 = insertelement <8 x float> %1600, float %1609, i64 1
  %1611 = xor i1 %1607, true
  %1612 = and i1 %1605, %1611
  %1613 = insertelement <8 x i1> %1603, i1 %1612, i64 1
  %1614 = extractelement <8 x i1> %57, i32 0
  %1615 = extractelement <8 x i1> %57, i64 2
  %1616 = and i1 true, %1614
  %1617 = and i1 %1615, %1616
  %1618 = extractelement <8 x float> %1593, i32 0
  %1619 = select i1 %1617, float %1618, float 0.000000e+00
  %1620 = insertelement <8 x float> %1610, float %1619, i64 2
  %1621 = xor i1 %1617, true
  %1622 = and i1 %1615, %1621
  %1623 = insertelement <8 x i1> %1613, i1 %1622, i64 2
  %1624 = extractelement <8 x i1> %57, i32 0
  %1625 = extractelement <8 x i1> %57, i64 3
  %1626 = and i1 true, %1624
  %1627 = and i1 %1625, %1626
  %1628 = extractelement <8 x float> %1593, i32 0
  %1629 = select i1 %1627, float %1628, float 0.000000e+00
  %1630 = insertelement <8 x float> %1620, float %1629, i64 3
  %1631 = xor i1 %1627, true
  %1632 = and i1 %1625, %1631
  %1633 = insertelement <8 x i1> %1623, i1 %1632, i64 3
  %1634 = extractelement <8 x i1> %57, i32 0
  %1635 = extractelement <8 x i1> %57, i64 4
  %1636 = and i1 true, %1634
  %1637 = and i1 %1635, %1636
  %1638 = extractelement <8 x float> %1593, i32 0
  %1639 = select i1 %1637, float %1638, float 0.000000e+00
  %1640 = insertelement <8 x float> %1630, float %1639, i64 4
  %1641 = xor i1 %1637, true
  %1642 = and i1 %1635, %1641
  %1643 = insertelement <8 x i1> %1633, i1 %1642, i64 4
  %1644 = extractelement <8 x i1> %57, i32 0
  %1645 = extractelement <8 x i1> %57, i64 5
  %1646 = and i1 true, %1644
  %1647 = and i1 %1645, %1646
  %1648 = extractelement <8 x float> %1593, i32 0
  %1649 = select i1 %1647, float %1648, float 0.000000e+00
  %1650 = insertelement <8 x float> %1640, float %1649, i64 5
  %1651 = xor i1 %1647, true
  %1652 = and i1 %1645, %1651
  %1653 = insertelement <8 x i1> %1643, i1 %1652, i64 5
  %1654 = extractelement <8 x i1> %57, i32 0
  %1655 = extractelement <8 x i1> %57, i64 6
  %1656 = and i1 true, %1654
  %1657 = and i1 %1655, %1656
  %1658 = extractelement <8 x float> %1593, i32 0
  %1659 = select i1 %1657, float %1658, float 0.000000e+00
  %1660 = insertelement <8 x float> %1650, float %1659, i64 6
  %1661 = xor i1 %1657, true
  %1662 = and i1 %1655, %1661
  %1663 = insertelement <8 x i1> %1653, i1 %1662, i64 6
  %1664 = extractelement <8 x i1> %57, i32 0
  %1665 = extractelement <8 x i1> %57, i64 7
  %1666 = and i1 true, %1664
  %1667 = and i1 %1665, %1666
  %1668 = extractelement <8 x float> %1593, i32 0
  %1669 = select i1 %1667, float %1668, float 0.000000e+00
  %1670 = insertelement <8 x float> %1660, float %1669, i64 7
  %1671 = xor i1 %1667, true
  %1672 = and i1 %1665, %1671
  %1673 = insertelement <8 x i1> %1663, i1 %1672, i64 7
  %1674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1675 = bitcast <8 x i1> %57 to i8
  %1676 = call i8 @llvm.cttz.i8(i8 %1675, i1 false)
  %1677 = zext i8 %1676 to i32
  %1678 = select i1 %1674, i32 %1677, i32 0
  %1679 = extractelement <8 x float> %1670, i32 %1678
  %.spill.load263 = load float, ptr %.spill34, align 4
  %1680 = fadd float %.spill.load263, %1679
  store float %1680, ptr %.spill43, align 4
  br label %direct.schedule.36

direct.schedule.36:                               ; preds = %direct.schedule.35
  %1681 = load <8 x i64>, ptr %.slot44, align 64
  %1682 = select <8 x i1> %57, <8 x i64> zeroinitializer, <8 x i64> %1681
  store <8 x i64> %1682, ptr %.slot44, align 64
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state264 = load <8 x i64>, ptr %.slot44, align 64
  %1683 = icmp slt <8 x i64> %.state264, splat (i64 8)
  %1684 = extractelement <8 x i1> %1683, i32 0
  br i1 %1684, label %direct.true265, label %direct.false266

direct.schedule.38:                               ; preds = %direct.true265
  %.state267 = load <8 x i64>, ptr %.slot44, align 64
  %1685 = mul <8 x i64> %.state267, splat (i64 8)
  %.spill.load268 = load <8 x i64>, ptr %.spill, align 64
  %1686 = add <8 x i64> %1685, %.spill.load268
  %tile_snapshot.spill.load269 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load269, 0
  %1688 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load269, 1
  %.state270 = load <8 x i64>, ptr %.slot44, align 64
  %1689 = mul <8 x i64> %.state270, splat (i64 32)
  %1690 = add <8 x i64> %1688, %1689
  %1691 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1687, 0
  %1692 = insertvalue { <8 x ptr>, <8 x i64> } %1691, <8 x i64> %1690, 1
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1694 = extractvalue { <8 x ptr>, <8 x i64> } %1692, 1
  %1695 = extractelement <8 x ptr> %1693, i32 0
  %1696 = extractelement <8 x i64> %1694, i32 0
  %1697 = sub i64 %1696, 0
  %1698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1699 = select i1 %1698, i64 %1697, i64 0
  %private.contiguous.address271 = getelementptr i8, ptr %1695, i64 %1699
  %private.contiguous.load272 = load <8 x float>, ptr %private.contiguous.address271, align 4
  %1700 = select <8 x i1> %57, <8 x float> %private.contiguous.load272, <8 x float> zeroinitializer
  %.spill.load273 = load float, ptr %.spill43, align 4
  %.splatinsert274 = insertelement <8 x float> poison, float %.spill.load273, i64 0
  %.splat275 = shufflevector <8 x float> %.splatinsert274, <8 x float> poison, <8 x i32> zeroinitializer
  %1701 = fdiv <8 x float> %1700, %.splat275
  %.spill.load276 = load <8 x i64>, ptr %.spill13, align 64
  %1702 = add <8 x i64> %.spill.load276, zeroinitializer
  %1703 = add <8 x i64> zeroinitializer, %1702
  %1704 = add <8 x i64> zeroinitializer, %1686
  %1705 = mul <8 x i64> %1703, splat (i64 65)
  %1706 = add <8 x i64> %1705, %1704
  %1707 = extractvalue { ptr, i64 } %33, 0
  %1708 = extractelement <8 x i64> %1706, i32 0
  %1709 = sub i64 %1708, 0
  %1710 = mul i64 %1709, 4
  %buffer.contiguous.address277 = getelementptr i8, ptr %1707, i64 %1710
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1701, ptr %buffer.contiguous.address277, i32 1, <8 x i1> %57)
  %.state278 = load <8 x i64>, ptr %.slot44, align 64
  %1711 = add <8 x i64> %.state278, splat (i64 1)
  %1712 = load <8 x i64>, ptr %.slot44, align 64
  %1713 = select <8 x i1> %57, <8 x i64> %1711, <8 x i64> %1712
  store <8 x i64> %1713, ptr %.slot44, align 64
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false266
  %.spill.load279 = load <8 x i1>, ptr %.spill14, align 1
  %1714 = and <8 x i1> %57, %.spill.load279
  %1715 = xor <8 x i1> %.spill.load279, splat (i1 true)
  %1716 = and <8 x i1> %57, %1715
  %1717 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1714)
  %1718 = bitcast <8 x i1> %1714 to i8
  %1719 = call i8 @llvm.cttz.i8(i8 %1718, i1 false)
  %1720 = zext i8 %1719 to i32
  %1721 = select i1 %1717, i32 %1720, i32 0
  %.spill.load280 = load <8 x i64>, ptr %.spill, align 64
  %1722 = add <8 x i64> splat (i64 64), %.spill.load280
  %tile_snapshot.spill.load281 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1723 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %1724 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %1725 = add <8 x i64> %1724, splat (i64 256)
  %1726 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1723, 0
  %1727 = insertvalue { <8 x ptr>, <8 x i64> } %1726, <8 x i64> %1725, 1
  %1728 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1729 = extractvalue { <8 x ptr>, <8 x i64> } %1727, 1
  %1730 = extractelement <8 x ptr> %1728, i32 0
  %1731 = extractelement <8 x i64> %1729, i32 %1721
  %1732 = zext i32 %1721 to i64
  %1733 = mul i64 %1732, 4
  %1734 = sub i64 %1731, %1733
  %1735 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1714)
  %1736 = select i1 %1735, i64 %1734, i64 0
  %private.contiguous.address282 = getelementptr i8, ptr %1730, i64 %1736
  %private.contiguous.load283 = load <8 x float>, ptr %private.contiguous.address282, align 4
  %1737 = select <8 x i1> %1714, <8 x float> %private.contiguous.load283, <8 x float> zeroinitializer
  %.spill.load284 = load float, ptr %.spill43, align 4
  %.splatinsert285 = insertelement <8 x float> poison, float %.spill.load284, i64 0
  %.splat286 = shufflevector <8 x float> %.splatinsert285, <8 x float> poison, <8 x i32> zeroinitializer
  %1738 = fdiv <8 x float> %1737, %.splat286
  %.spill.load287 = load <8 x i64>, ptr %.spill13, align 64
  %1739 = add <8 x i64> %.spill.load287, zeroinitializer
  %1740 = add <8 x i64> zeroinitializer, %1739
  %1741 = add <8 x i64> zeroinitializer, %1722
  %1742 = mul <8 x i64> %1740, splat (i64 65)
  %1743 = add <8 x i64> %1742, %1741
  %1744 = extractvalue { ptr, i64 } %33, 0
  %1745 = extractelement <8 x i64> %1743, i32 %1721
  %1746 = zext i32 %1721 to i64
  %1747 = sub i64 %1745, %1746
  %1748 = mul i64 %1747, 4
  %buffer.contiguous.address288 = getelementptr i8, ptr %1744, i64 %1748
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1738, ptr %buffer.contiguous.address288, i32 1, <8 x i1> %1714)
  %1749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1716)
  %1750 = bitcast <8 x i1> %1716 to i8
  %1751 = call i8 @llvm.cttz.i8(i8 %1750, i1 false)
  %1752 = zext i8 %1751 to i32
  %1753 = select i1 %1749, i32 %1752, i32 0
  br label %direct.schedule.41

direct.schedule.41:                               ; preds = %direct.schedule.39
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true72:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false73:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true88:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false89:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true104:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false105:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true144:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false145:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.23

direct.true180:                                   ; preds = %direct.schedule.26
  br label %direct.schedule.27

direct.false181:                                  ; preds = %direct.schedule.26
  br label %direct.schedule.28

direct.true227:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false228:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true265:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false266:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, i32 immarg, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x i8>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maxnum.f32(float, float) #0

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #4 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #5

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [576 x i8], align 8
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local4 = alloca [72 x i8], align 1
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 9, i64 18, i64 27, i64 36, i64 45, i64 54, i64 63>, 1
  %tile_snapshot.local7 = alloca [288 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local10 = alloca [288 x i8], align 4
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %8 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %9 = insertvalue { <8 x ptr>, <8 x i64> } %8, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill13 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill13, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill14 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill14, align 1
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot16, align 64
  %.spill17 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill17, align 64
  %tile_snapshot.spill18 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill18, align 64
  %.slot19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot19, align 64
  %.spill20 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill20, align 4
  %tile_snapshot.spill21 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill21, align 64
  %.slot22 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot22, align 64
  %.spill23 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill23, align 4
  %.slot24 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot24, align 64
  %.slot25 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot25, align 32
  %.slot26 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot26, align 32
  %.slot27 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot27, align 32
  %.slot28 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot28, align 32
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.spill30 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill30, align 32
  %.spill31 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill31, align 32
  %.spill32 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill32, align 32
  %.spill33 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill33, align 4
  %.spill34 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill34, align 4
  %tile_snapshot.spill35 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill35, align 64
  %.slot36 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot36, align 64
  %.slot37 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot37, align 64
  %.slot38 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot38, align 32
  %.slot39 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot39, align 32
  %.slot40 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot40, align 32
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.spill43 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill43, align 4
  %.slot44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot44, align 64
  %10 = getelementptr i8, ptr %argument_buffer, i64 0
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 16
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 32
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = getelementptr i8, ptr %argument_buffer, i64 48
  %29 = load ptr, ptr %28, align 16
  %30 = getelementptr i8, ptr %28, i64 8
  %31 = load i64, ptr %30, align 8
  %32 = insertvalue { ptr, i64 } poison, ptr %29, 0
  %33 = insertvalue { ptr, i64 } %32, i64 %31, 1
  %34 = load i32, ptr %launch_config, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 12
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 4
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 16
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 8
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 20
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 36
  %46 = load i32, ptr %45, align 4
  %.splatinsert45 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat46 = shufflevector <8 x i32> %.splatinsert45, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat46, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %48 = mul i32 %34, 32
  %.splatinsert47 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat48 = shufflevector <8 x i32> %.splatinsert47, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat48, %47
  %50 = mul i32 %38, 1
  %.splatinsert49 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat50 = shufflevector <8 x i32> %.splatinsert49, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat50, zeroinitializer
  %52 = mul i32 %42, 1
  %.splatinsert51 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat52 = shufflevector <8 x i32> %.splatinsert51, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat52, zeroinitializer
  %54 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %49, 0
  %55 = insertvalue [3 x <8 x i32>] %54, <8 x i32> %51, 1
  %56 = insertvalue [3 x <8 x i32>] %55, <8 x i32> %53, 2
  %.splatinsert53 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat54 = shufflevector <8 x i32> %.splatinsert53, <8 x i32> poison, <8 x i32> zeroinitializer
  %57 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat54
  %58 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  br i1 %58, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %59 = extractvalue [3 x <8 x i32>] %56, 0
  %60 = load <8 x i64>, ptr %.spill, align 64
  %61 = select <8 x i1> %57, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %60
  store <8 x i64> %61, ptr %.spill, align 64
  %62 = sub <8 x i32> %59, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %63 = select <8 x i1> %57, <8 x i32> %62, <8 x i32> zeroinitializer
  %64 = select <8 x i1> %57, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %65 = lshr <8 x i32> %63, %64
  %66 = zext <8 x i32> %65 to <8 x i64>
  %67 = select <8 x i1> %57, <8 x i64> %66, <8 x i64> zeroinitializer
  %68 = select <8 x i1> %57, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %69 = sdiv <8 x i64> %67, %68
  %70 = load <8 x i64>, ptr %.spill13, align 64
  %71 = select <8 x i1> %57, <8 x i64> %69, <8 x i64> %70
  store <8 x i64> %71, ptr %.spill13, align 64
  %72 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %74 = extractvalue { <8 x ptr>, <8 x i64> } %72, 0
  %75 = select <8 x i1> %57, <8 x ptr> %73, <8 x ptr> %74
  %76 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %77 = extractvalue { <8 x ptr>, <8 x i64> } %72, 1
  %78 = select <8 x i1> %57, <8 x i64> %76, <8 x i64> %77
  %79 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %75, 0
  %80 = insertvalue { <8 x ptr>, <8 x i64> } %79, <8 x i64> %78, 1
  store { <8 x ptr>, <8 x i64> } %80, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %81 = icmp slt i64 %.state, 8
  br i1 %81, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state55 = load i64, ptr %.slot, align 4
  %82 = mul i64 %.state55, 8
  %.splatinsert56 = insertelement <8 x i64> poison, i64 %82, i64 0
  %.splat57 = shufflevector <8 x i64> %.splatinsert56, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %83 = add <8 x i64> %.splat57, %.spill.load
  %.spill.load58 = load <8 x i64>, ptr %.spill13, align 64
  %84 = add <8 x i64> %.spill.load58, zeroinitializer
  %85 = add <8 x i64> zeroinitializer, %84
  %86 = add <8 x i64> zeroinitializer, %83
  %87 = mul <8 x i64> %85, splat (i64 65)
  %88 = add <8 x i64> %87, %86
  %89 = extractvalue { ptr, i64 } %15, 0
  %90 = extractelement <8 x i64> %88, i32 0
  %91 = sub i64 %90, 0
  %92 = mul i64 %91, 4
  %buffer.contiguous.address = getelementptr i8, ptr %89, i64 %92
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %57, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state59 = load i64, ptr %.slot, align 4
  %.splatinsert60 = insertelement <8 x i64> poison, i64 %.state59, i64 0
  %.splat61 = shufflevector <8 x i64> %.splatinsert60, <8 x i64> poison, <8 x i32> zeroinitializer
  %95 = mul <8 x i64> %.splat61, splat (i64 32)
  %96 = add <8 x i64> %94, %95
  %97 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %93, 0
  %98 = insertvalue { <8 x ptr>, <8 x i64> } %97, <8 x i64> %96, 1
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %100 = extractvalue { <8 x ptr>, <8 x i64> } %98, 1
  %101 = extractelement <8 x ptr> %99, i32 0
  %102 = extractelement <8 x i64> %100, i32 0
  %103 = sub i64 %102, 0
  %104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %105 = select i1 %104, i64 %103, i64 0
  %private.contiguous.address = getelementptr i8, ptr %101, i64 %105
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %106 = select <8 x i1> %57, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %106, ptr %private.contiguous.address, align 4
  %.state62 = load i64, ptr %.slot, align 4
  %107 = add i64 %.state62, 1
  store i64 %107, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load63 = load <8 x i64>, ptr %.spill, align 64
  %108 = icmp slt <8 x i64> %.spill.load63, splat (i64 1)
  %109 = load <8 x i1>, ptr %.spill14, align 1
  %110 = select <8 x i1> %57, <8 x i1> %108, <8 x i1> %109
  store <8 x i1> %110, ptr %.spill14, align 1
  %111 = and <8 x i1> %57, %108
  %112 = xor <8 x i1> %108, splat (i1 true)
  %113 = and <8 x i1> %57, %112
  %114 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  %115 = bitcast <8 x i1> %111 to i8
  %116 = call i8 @llvm.cttz.i8(i8 %115, i1 false)
  %117 = zext i8 %116 to i32
  %118 = select i1 %114, i32 %117, i32 0
  %.spill.load64 = load <8 x i64>, ptr %.spill, align 64
  %119 = add <8 x i64> splat (i64 64), %.spill.load64
  %.spill.load65 = load <8 x i64>, ptr %.spill13, align 64
  %120 = add <8 x i64> %.spill.load65, zeroinitializer
  %121 = add <8 x i64> zeroinitializer, %120
  %122 = add <8 x i64> zeroinitializer, %119
  %123 = mul <8 x i64> %121, splat (i64 65)
  %124 = add <8 x i64> %123, %122
  %125 = extractvalue { ptr, i64 } %15, 0
  %126 = select <8 x i1> %111, <8 x i64> %124, <8 x i64> zeroinitializer
  %127 = extractelement <8 x i64> %126, i32 %118
  %128 = zext i32 %118 to i64
  %129 = sub i64 %127, %128
  %130 = mul i64 %129, 4
  %buffer.contiguous.address66 = getelementptr i8, ptr %125, i64 %130
  %buffer.contiguous.load67 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address66, i32 1, <8 x i1> %111, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 0
  %132 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 1
  %133 = add <8 x i64> %132, splat (i64 256)
  %134 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %131, 0
  %135 = insertvalue { <8 x ptr>, <8 x i64> } %134, <8 x i64> %133, 1
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %135, 1
  %138 = extractelement <8 x ptr> %136, i32 0
  %139 = extractelement <8 x i64> %137, i32 %118
  %140 = zext i32 %118 to i64
  %141 = mul i64 %140, 4
  %142 = sub i64 %139, %141
  %143 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  %144 = select i1 %143, i64 %142, i64 0
  %private.contiguous.address69 = getelementptr i8, ptr %138, i64 %144
  %private.contiguous.preserve70 = load <8 x float>, ptr %private.contiguous.address69, align 4
  %145 = select <8 x i1> %111, <8 x float> %buffer.contiguous.load67, <8 x float> %private.contiguous.preserve70
  store <8 x float> %145, ptr %private.contiguous.address69, align 4
  %146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %113)
  %147 = bitcast <8 x i1> %113 to i8
  %148 = call i8 @llvm.cttz.i8(i8 %147, i1 false)
  %149 = zext i8 %148 to i32
  %150 = select i1 %146, i32 %149, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  %151 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %151, 0
  %154 = select <8 x i1> %57, <8 x ptr> %152, <8 x ptr> %153
  %155 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %151, 1
  %157 = select <8 x i1> %57, <8 x i64> %155, <8 x i64> %156
  %158 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %154, 0
  %159 = insertvalue { <8 x ptr>, <8 x i64> } %158, <8 x i64> %157, 1
  store { <8 x ptr>, <8 x i64> } %159, ptr %tile_snapshot.spill15, align 64
  %160 = load <8 x i64>, ptr %.slot16, align 64
  %161 = select <8 x i1> %57, <8 x i64> zeroinitializer, <8 x i64> %160
  store <8 x i64> %161, ptr %.slot16, align 64
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state71 = load <8 x i64>, ptr %.slot16, align 64
  %162 = icmp slt <8 x i64> %.state71, splat (i64 8)
  %163 = extractelement <8 x i1> %162, i32 0
  br i1 %163, label %direct.true72, label %direct.false73

direct.schedule.7:                                ; preds = %direct.true72
  %.state74 = load <8 x i64>, ptr %.slot16, align 64
  %164 = mul <8 x i64> %.state74, splat (i64 8)
  %.spill.load75 = load <8 x i64>, ptr %.spill, align 64
  %165 = add <8 x i64> %164, %.spill.load75
  %tile_snapshot.spill.load76 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 1
  %.state77 = load <8 x i64>, ptr %.slot16, align 64
  %168 = mul <8 x i64> %.state77, splat (i64 64)
  %169 = add <8 x i64> %167, %168
  %170 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %166, 0
  %171 = insertvalue { <8 x ptr>, <8 x i64> } %170, <8 x i64> %169, 1
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %174 = extractelement <8 x ptr> %172, i32 0
  %175 = extractelement <8 x i64> %173, i32 0
  %176 = sub i64 %175, 0
  %177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %178 = select i1 %177, i64 %176, i64 0
  %private.contiguous.address78 = getelementptr i8, ptr %174, i64 %178
  %private.contiguous.preserve79 = load <8 x i64>, ptr %private.contiguous.address78, align 8
  %179 = select <8 x i1> %57, <8 x i64> %165, <8 x i64> %private.contiguous.preserve79
  store <8 x i64> %179, ptr %private.contiguous.address78, align 8
  %.state80 = load <8 x i64>, ptr %.slot16, align 64
  %180 = add <8 x i64> %.state80, splat (i64 1)
  %181 = load <8 x i64>, ptr %.slot16, align 64
  %182 = select <8 x i1> %57, <8 x i64> %180, <8 x i64> %181
  store <8 x i64> %182, ptr %.slot16, align 64
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false73
  %.spill.load81 = load <8 x i1>, ptr %.spill14, align 1
  %183 = and <8 x i1> %57, %.spill.load81
  %184 = xor <8 x i1> %.spill.load81, splat (i1 true)
  %185 = and <8 x i1> %57, %184
  %186 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %183)
  %187 = bitcast <8 x i1> %183 to i8
  %188 = call i8 @llvm.cttz.i8(i8 %187, i1 false)
  %189 = zext i8 %188 to i32
  %190 = select i1 %186, i32 %189, i32 0
  %.spill.load82 = load <8 x i64>, ptr %.spill, align 64
  %191 = add <8 x i64> splat (i64 64), %.spill.load82
  %tile_snapshot.spill.load83 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 1
  %194 = add <8 x i64> %193, splat (i64 512)
  %195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %192, 0
  %196 = insertvalue { <8 x ptr>, <8 x i64> } %195, <8 x i64> %194, 1
  %197 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %196, 1
  %199 = extractelement <8 x ptr> %197, i32 0
  %200 = extractelement <8 x i64> %198, i32 %190
  %201 = zext i32 %190 to i64
  %202 = mul i64 %201, 8
  %203 = sub i64 %200, %202
  %204 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %183)
  %205 = select i1 %204, i64 %203, i64 0
  %private.contiguous.address84 = getelementptr i8, ptr %199, i64 %205
  %private.contiguous.preserve85 = load <8 x i64>, ptr %private.contiguous.address84, align 8
  %206 = select <8 x i1> %183, <8 x i64> %191, <8 x i64> %private.contiguous.preserve85
  store <8 x i64> %206, ptr %private.contiguous.address84, align 8
  %207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %185)
  %208 = bitcast <8 x i1> %185 to i8
  %209 = call i8 @llvm.cttz.i8(i8 %208, i1 false)
  %210 = zext i8 %209 to i32
  %211 = select i1 %207, i32 %210, i32 0
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %.spill.load86 = load <8 x i64>, ptr %.spill13, align 64
  %212 = select <8 x i1> %57, <8 x i64> %.spill.load86, <8 x i64> zeroinitializer
  %213 = select <8 x i1> %57, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %214 = srem <8 x i64> %212, %213
  %215 = load <8 x i64>, ptr %.spill17, align 64
  %216 = select <8 x i1> %57, <8 x i64> %214, <8 x i64> %215
  store <8 x i64> %216, ptr %.spill17, align 64
  %217 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %217, 0
  %220 = select <8 x i1> %57, <8 x ptr> %218, <8 x ptr> %219
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %217, 1
  %223 = select <8 x i1> %57, <8 x i64> %221, <8 x i64> %222
  %224 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %220, 0
  %225 = insertvalue { <8 x ptr>, <8 x i64> } %224, <8 x i64> %223, 1
  store { <8 x ptr>, <8 x i64> } %225, ptr %tile_snapshot.spill18, align 64
  %226 = load <8 x i64>, ptr %.slot19, align 64
  %227 = select <8 x i1> %57, <8 x i64> zeroinitializer, <8 x i64> %226
  store <8 x i64> %227, ptr %.slot19, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state87 = load <8 x i64>, ptr %.slot19, align 64
  %228 = icmp slt <8 x i64> %.state87, splat (i64 8)
  %229 = extractelement <8 x i1> %228, i32 0
  br i1 %229, label %direct.true88, label %direct.false89

direct.schedule.12:                               ; preds = %direct.true88
  %tile_snapshot.spill.load90 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load90, 0
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load90, 1
  %.state91 = load <8 x i64>, ptr %.slot19, align 64
  %232 = mul <8 x i64> %.state91, splat (i64 64)
  %233 = add <8 x i64> %231, %232
  %234 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %230, 0
  %235 = insertvalue { <8 x ptr>, <8 x i64> } %234, <8 x i64> %233, 1
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %235, 1
  %238 = extractelement <8 x ptr> %236, i32 0
  %239 = extractelement <8 x i64> %237, i32 0
  %240 = sub i64 %239, 0
  %241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %242 = select i1 %241, i64 %240, i64 0
  %private.contiguous.address92 = getelementptr i8, ptr %238, i64 %242
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address92, align 8
  %243 = select <8 x i1> %57, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load93 = load <8 x i64>, ptr %.spill17, align 64
  %244 = icmp sle <8 x i64> %243, %.spill.load93
  %tile_snapshot.spill.load94 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %245 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 0
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 1
  %.state95 = load <8 x i64>, ptr %.slot19, align 64
  %247 = add <8 x i64> %246, %.state95
  %248 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %245, 0
  %249 = insertvalue { <8 x ptr>, <8 x i64> } %248, <8 x i64> %247, 1
  %250 = extractvalue { <8 x ptr>, <8 x i64> } %249, 0
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %249, 1
  %252 = getelementptr i8, <8 x ptr> %250, <8 x i64> %251
  %253 = zext <8 x i1> %244 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %253, <8 x ptr> %252, i32 1, <8 x i1> %57)
  %.state96 = load <8 x i64>, ptr %.slot19, align 64
  %254 = add <8 x i64> %.state96, splat (i64 1)
  %255 = load <8 x i64>, ptr %.slot19, align 64
  %256 = select <8 x i1> %57, <8 x i64> %254, <8 x i64> %255
  store <8 x i64> %256, ptr %.slot19, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false89
  %.spill.load97 = load <8 x i1>, ptr %.spill14, align 1
  %257 = and <8 x i1> %57, %.spill.load97
  %258 = xor <8 x i1> %.spill.load97, splat (i1 true)
  %259 = and <8 x i1> %57, %258
  %260 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %257)
  %261 = bitcast <8 x i1> %257 to i8
  %262 = call i8 @llvm.cttz.i8(i8 %261, i1 false)
  %263 = zext i8 %262 to i32
  %264 = select i1 %260, i32 %263, i32 0
  %tile_snapshot.spill.load98 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 0
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 1
  %267 = add <8 x i64> %266, splat (i64 512)
  %268 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %265, 0
  %269 = insertvalue { <8 x ptr>, <8 x i64> } %268, <8 x i64> %267, 1
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %269, 1
  %272 = extractelement <8 x ptr> %270, i32 0
  %273 = extractelement <8 x i64> %271, i32 %264
  %274 = zext i32 %264 to i64
  %275 = mul i64 %274, 8
  %276 = sub i64 %273, %275
  %277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %257)
  %278 = select i1 %277, i64 %276, i64 0
  %private.contiguous.address99 = getelementptr i8, ptr %272, i64 %278
  %private.contiguous.load100 = load <8 x i64>, ptr %private.contiguous.address99, align 8
  %279 = select <8 x i1> %257, <8 x i64> %private.contiguous.load100, <8 x i64> zeroinitializer
  %.spill.load101 = load <8 x i64>, ptr %.spill17, align 64
  %280 = icmp sle <8 x i64> %279, %.spill.load101
  %tile_snapshot.spill.load102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 0
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load102, 1
  %283 = add <8 x i64> %282, splat (i64 8)
  %284 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %281, 0
  %285 = insertvalue { <8 x ptr>, <8 x i64> } %284, <8 x i64> %283, 1
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %285, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %285, 1
  %288 = getelementptr i8, <8 x ptr> %286, <8 x i64> %287
  %289 = zext <8 x i1> %280 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %289, <8 x ptr> %288, i32 1, <8 x i1> %257)
  %290 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %259)
  %291 = bitcast <8 x i1> %259 to i8
  %292 = call i8 @llvm.cttz.i8(i8 %291, i1 false)
  %293 = zext i8 %292 to i32
  %294 = select i1 %290, i32 %293, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  store float 0xC6293E5940000000, ptr %.spill20, align 4
  %295 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %295, 0
  %298 = select <8 x i1> %57, <8 x ptr> %296, <8 x ptr> %297
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %295, 1
  %301 = select <8 x i1> %57, <8 x i64> %299, <8 x i64> %300
  %302 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %298, 0
  %303 = insertvalue { <8 x ptr>, <8 x i64> } %302, <8 x i64> %301, 1
  store { <8 x ptr>, <8 x i64> } %303, ptr %tile_snapshot.spill21, align 64
  %304 = load <8 x i64>, ptr %.slot22, align 64
  %305 = select <8 x i1> %57, <8 x i64> zeroinitializer, <8 x i64> %304
  store <8 x i64> %305, ptr %.slot22, align 64
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state103 = load <8 x i64>, ptr %.slot22, align 64
  %306 = icmp slt <8 x i64> %.state103, splat (i64 8)
  %307 = extractelement <8 x i1> %306, i32 0
  br i1 %307, label %direct.true104, label %direct.false105

direct.schedule.17:                               ; preds = %direct.true104
  %tile_snapshot.spill.load106 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 1
  %.state107 = load <8 x i64>, ptr %.slot22, align 64
  %310 = add <8 x i64> %309, %.state107
  %311 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %308, 0
  %312 = insertvalue { <8 x ptr>, <8 x i64> } %311, <8 x i64> %310, 1
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %312, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %312, 1
  %315 = getelementptr i8, <8 x ptr> %313, <8 x i64> %314
  %316 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %315, i32 1, <8 x i1> %57, <8 x i8> zeroinitializer)
  %317 = icmp ne <8 x i8> %316, zeroinitializer
  %tile_snapshot.spill.load108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 0
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 1
  %.state109 = load <8 x i64>, ptr %.slot22, align 64
  %320 = mul <8 x i64> %.state109, splat (i64 32)
  %321 = add <8 x i64> %319, %320
  %322 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %318, 0
  %323 = insertvalue { <8 x ptr>, <8 x i64> } %322, <8 x i64> %321, 1
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %323, 1
  %326 = extractelement <8 x ptr> %324, i32 0
  %327 = extractelement <8 x i64> %325, i32 0
  %328 = sub i64 %327, 0
  %329 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %330 = select i1 %329, i64 %328, i64 0
  %private.contiguous.address110 = getelementptr i8, ptr %326, i64 %330
  %private.contiguous.load111 = load <8 x float>, ptr %private.contiguous.address110, align 4
  %331 = select <8 x i1> %57, <8 x float> %private.contiguous.load111, <8 x float> zeroinitializer
  %.spill.load112 = load float, ptr %.spill20, align 4
  %.splatinsert113 = insertelement <8 x float> poison, float %.spill.load112, i64 0
  %.splat114 = shufflevector <8 x float> %.splatinsert113, <8 x float> poison, <8 x i32> zeroinitializer
  %332 = select <8 x i1> %317, <8 x float> %331, <8 x float> %.splat114
  %tile_snapshot.spill.load115 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 0
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 1
  %.state116 = load <8 x i64>, ptr %.slot22, align 64
  %335 = mul <8 x i64> %.state116, splat (i64 32)
  %336 = add <8 x i64> %334, %335
  %337 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %333, 0
  %338 = insertvalue { <8 x ptr>, <8 x i64> } %337, <8 x i64> %336, 1
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %338, 1
  %341 = extractelement <8 x ptr> %339, i32 0
  %342 = extractelement <8 x i64> %340, i32 0
  %343 = sub i64 %342, 0
  %344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %345 = select i1 %344, i64 %343, i64 0
  %private.contiguous.address117 = getelementptr i8, ptr %341, i64 %345
  %private.contiguous.preserve118 = load <8 x float>, ptr %private.contiguous.address117, align 4
  %346 = select <8 x i1> %57, <8 x float> %332, <8 x float> %private.contiguous.preserve118
  store <8 x float> %346, ptr %private.contiguous.address117, align 4
  %.state119 = load <8 x i64>, ptr %.slot22, align 64
  %347 = add <8 x i64> %.state119, splat (i64 1)
  %348 = load <8 x i64>, ptr %.slot22, align 64
  %349 = select <8 x i1> %57, <8 x i64> %347, <8 x i64> %348
  store <8 x i64> %349, ptr %.slot22, align 64
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false105
  %.spill.load120 = load <8 x i1>, ptr %.spill14, align 1
  %350 = and <8 x i1> %57, %.spill.load120
  %351 = xor <8 x i1> %.spill.load120, splat (i1 true)
  %352 = and <8 x i1> %57, %351
  %353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %350)
  %354 = bitcast <8 x i1> %350 to i8
  %355 = call i8 @llvm.cttz.i8(i8 %354, i1 false)
  %356 = zext i8 %355 to i32
  %357 = select i1 %353, i32 %356, i32 0
  %tile_snapshot.spill.load121 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 0
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 1
  %360 = add <8 x i64> %359, splat (i64 8)
  %361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %358, 0
  %362 = insertvalue { <8 x ptr>, <8 x i64> } %361, <8 x i64> %360, 1
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %362, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %362, 1
  %365 = getelementptr i8, <8 x ptr> %363, <8 x i64> %364
  %366 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %365, i32 1, <8 x i1> %350, <8 x i8> zeroinitializer)
  %367 = icmp ne <8 x i8> %366, zeroinitializer
  %tile_snapshot.spill.load122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %368 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 0
  %369 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 1
  %370 = add <8 x i64> %369, splat (i64 256)
  %371 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %368, 0
  %372 = insertvalue { <8 x ptr>, <8 x i64> } %371, <8 x i64> %370, 1
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %372, 1
  %375 = extractelement <8 x ptr> %373, i32 0
  %376 = extractelement <8 x i64> %374, i32 %357
  %377 = zext i32 %357 to i64
  %378 = mul i64 %377, 4
  %379 = sub i64 %376, %378
  %380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %350)
  %381 = select i1 %380, i64 %379, i64 0
  %private.contiguous.address123 = getelementptr i8, ptr %375, i64 %381
  %private.contiguous.load124 = load <8 x float>, ptr %private.contiguous.address123, align 4
  %382 = select <8 x i1> %350, <8 x float> %private.contiguous.load124, <8 x float> zeroinitializer
  %.spill.load125 = load float, ptr %.spill20, align 4
  %.splatinsert126 = insertelement <8 x float> poison, float %.spill.load125, i64 0
  %.splat127 = shufflevector <8 x float> %.splatinsert126, <8 x float> poison, <8 x i32> zeroinitializer
  %383 = select <8 x i1> %367, <8 x float> %382, <8 x float> %.splat127
  %tile_snapshot.spill.load128 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %384 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load128, 0
  %385 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load128, 1
  %386 = add <8 x i64> %385, splat (i64 256)
  %387 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %384, 0
  %388 = insertvalue { <8 x ptr>, <8 x i64> } %387, <8 x i64> %386, 1
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %388, 1
  %391 = extractelement <8 x ptr> %389, i32 0
  %392 = extractelement <8 x i64> %390, i32 %357
  %393 = zext i32 %357 to i64
  %394 = mul i64 %393, 4
  %395 = sub i64 %392, %394
  %396 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %350)
  %397 = select i1 %396, i64 %395, i64 0
  %private.contiguous.address129 = getelementptr i8, ptr %391, i64 %397
  %private.contiguous.preserve130 = load <8 x float>, ptr %private.contiguous.address129, align 4
  %398 = select <8 x i1> %350, <8 x float> %383, <8 x float> %private.contiguous.preserve130
  store <8 x float> %398, ptr %private.contiguous.address129, align 4
  %399 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %352)
  %400 = bitcast <8 x i1> %352 to i8
  %401 = call i8 @llvm.cttz.i8(i8 %400, i1 false)
  %402 = zext i8 %401 to i32
  %403 = select i1 %399, i32 %402, i32 0
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  store float 0xFFF0000000000000, ptr %.spill23, align 4
  %tile_snapshot.spill.load131 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 0
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load131, 1
  %406 = add <8 x i64> %405, zeroinitializer
  %407 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %404, 0
  %408 = insertvalue { <8 x ptr>, <8 x i64> } %407, <8 x i64> %406, 1
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %408, 1
  %411 = extractelement <8 x ptr> %409, i32 0
  %412 = extractelement <8 x i64> %410, i32 0
  %413 = sub i64 %412, 0
  %414 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %415 = select i1 %414, i64 %413, i64 0
  %private.contiguous.address132 = getelementptr i8, ptr %411, i64 %415
  %private.contiguous.load133 = load <8 x float>, ptr %private.contiguous.address132, align 4
  %416 = select <8 x i1> %57, <8 x float> %private.contiguous.load133, <8 x float> zeroinitializer
  %tile_snapshot.spill.load134 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %417 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load134, 0
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load134, 1
  %419 = add <8 x i64> %418, splat (i64 32)
  %420 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %417, 0
  %421 = insertvalue { <8 x ptr>, <8 x i64> } %420, <8 x i64> %419, 1
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %421, 1
  %424 = extractelement <8 x ptr> %422, i32 0
  %425 = extractelement <8 x i64> %423, i32 0
  %426 = sub i64 %425, 0
  %427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %428 = select i1 %427, i64 %426, i64 0
  %private.contiguous.address135 = getelementptr i8, ptr %424, i64 %428
  %private.contiguous.load136 = load <8 x float>, ptr %private.contiguous.address135, align 4
  %429 = select <8 x i1> %57, <8 x float> %private.contiguous.load136, <8 x float> zeroinitializer
  %tile_snapshot.spill.load137 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %430 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load137, 0
  %431 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load137, 1
  %432 = add <8 x i64> %431, splat (i64 64)
  %433 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %430, 0
  %434 = insertvalue { <8 x ptr>, <8 x i64> } %433, <8 x i64> %432, 1
  %435 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %436 = extractvalue { <8 x ptr>, <8 x i64> } %434, 1
  %437 = extractelement <8 x ptr> %435, i32 0
  %438 = extractelement <8 x i64> %436, i32 0
  %439 = sub i64 %438, 0
  %440 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %441 = select i1 %440, i64 %439, i64 0
  %private.contiguous.address138 = getelementptr i8, ptr %437, i64 %441
  %private.contiguous.load139 = load <8 x float>, ptr %private.contiguous.address138, align 4
  %442 = select <8 x i1> %57, <8 x float> %private.contiguous.load139, <8 x float> zeroinitializer
  %tile_snapshot.spill.load140 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %443 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load140, 0
  %444 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load140, 1
  %445 = add <8 x i64> %444, splat (i64 96)
  %446 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %443, 0
  %447 = insertvalue { <8 x ptr>, <8 x i64> } %446, <8 x i64> %445, 1
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %449 = extractvalue { <8 x ptr>, <8 x i64> } %447, 1
  %450 = extractelement <8 x ptr> %448, i32 0
  %451 = extractelement <8 x i64> %449, i32 0
  %452 = sub i64 %451, 0
  %453 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %454 = select i1 %453, i64 %452, i64 0
  %private.contiguous.address141 = getelementptr i8, ptr %450, i64 %454
  %private.contiguous.load142 = load <8 x float>, ptr %private.contiguous.address141, align 4
  %455 = select <8 x i1> %57, <8 x float> %private.contiguous.load142, <8 x float> zeroinitializer
  %456 = load <8 x i64>, ptr %.slot24, align 64
  %457 = select <8 x i1> %57, <8 x i64> splat (i64 4), <8 x i64> %456
  store <8 x i64> %457, ptr %.slot24, align 64
  %458 = load <8 x float>, ptr %.slot25, align 32
  %459 = select <8 x i1> %57, <8 x float> %416, <8 x float> %458
  store <8 x float> %459, ptr %.slot25, align 32
  %460 = load <8 x float>, ptr %.slot26, align 32
  %461 = select <8 x i1> %57, <8 x float> %429, <8 x float> %460
  store <8 x float> %461, ptr %.slot26, align 32
  %462 = load <8 x float>, ptr %.slot27, align 32
  %463 = select <8 x i1> %57, <8 x float> %442, <8 x float> %462
  store <8 x float> %463, ptr %.slot27, align 32
  %464 = load <8 x float>, ptr %.slot28, align 32
  %465 = select <8 x i1> %57, <8 x float> %455, <8 x float> %464
  store <8 x float> %465, ptr %.slot28, align 32
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.22, %direct.schedule.20
  %.state143 = load <8 x i64>, ptr %.slot24, align 64
  %466 = icmp slt <8 x i64> %.state143, splat (i64 8)
  %467 = extractelement <8 x i1> %466, i32 0
  br i1 %467, label %direct.true144, label %direct.false145

direct.schedule.22:                               ; preds = %direct.true144
  %.state146 = load <8 x i64>, ptr %.slot24, align 64
  %468 = add <8 x i64> %.state146, zeroinitializer
  %tile_snapshot.spill.load147 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %469 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %470 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %471 = mul <8 x i64> %468, splat (i64 32)
  %472 = add <8 x i64> %470, %471
  %473 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %469, 0
  %474 = insertvalue { <8 x ptr>, <8 x i64> } %473, <8 x i64> %472, 1
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %476 = extractvalue { <8 x ptr>, <8 x i64> } %474, 1
  %477 = extractelement <8 x ptr> %475, i32 0
  %478 = extractelement <8 x i64> %476, i32 0
  %479 = sub i64 %478, 0
  %480 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %481 = select i1 %480, i64 %479, i64 0
  %private.contiguous.address148 = getelementptr i8, ptr %477, i64 %481
  %private.contiguous.load149 = load <8 x float>, ptr %private.contiguous.address148, align 4
  %482 = select <8 x i1> %57, <8 x float> %private.contiguous.load149, <8 x float> zeroinitializer
  %.state150 = load <8 x float>, ptr %.slot25, align 32
  %483 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state150, <8 x float> %482)
  %.state151 = load <8 x i64>, ptr %.slot24, align 64
  %484 = add <8 x i64> %.state151, splat (i64 1)
  %tile_snapshot.spill.load152 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load152, 0
  %486 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load152, 1
  %487 = mul <8 x i64> %484, splat (i64 32)
  %488 = add <8 x i64> %486, %487
  %489 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %485, 0
  %490 = insertvalue { <8 x ptr>, <8 x i64> } %489, <8 x i64> %488, 1
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %492 = extractvalue { <8 x ptr>, <8 x i64> } %490, 1
  %493 = extractelement <8 x ptr> %491, i32 0
  %494 = extractelement <8 x i64> %492, i32 0
  %495 = sub i64 %494, 0
  %496 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %497 = select i1 %496, i64 %495, i64 0
  %private.contiguous.address153 = getelementptr i8, ptr %493, i64 %497
  %private.contiguous.load154 = load <8 x float>, ptr %private.contiguous.address153, align 4
  %498 = select <8 x i1> %57, <8 x float> %private.contiguous.load154, <8 x float> zeroinitializer
  %.state155 = load <8 x float>, ptr %.slot26, align 32
  %499 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state155, <8 x float> %498)
  %.state156 = load <8 x i64>, ptr %.slot24, align 64
  %500 = add <8 x i64> %.state156, splat (i64 2)
  %tile_snapshot.spill.load157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 0
  %502 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 1
  %503 = mul <8 x i64> %500, splat (i64 32)
  %504 = add <8 x i64> %502, %503
  %505 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %501, 0
  %506 = insertvalue { <8 x ptr>, <8 x i64> } %505, <8 x i64> %504, 1
  %507 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %508 = extractvalue { <8 x ptr>, <8 x i64> } %506, 1
  %509 = extractelement <8 x ptr> %507, i32 0
  %510 = extractelement <8 x i64> %508, i32 0
  %511 = sub i64 %510, 0
  %512 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %513 = select i1 %512, i64 %511, i64 0
  %private.contiguous.address158 = getelementptr i8, ptr %509, i64 %513
  %private.contiguous.load159 = load <8 x float>, ptr %private.contiguous.address158, align 4
  %514 = select <8 x i1> %57, <8 x float> %private.contiguous.load159, <8 x float> zeroinitializer
  %.state160 = load <8 x float>, ptr %.slot27, align 32
  %515 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state160, <8 x float> %514)
  %.state161 = load <8 x i64>, ptr %.slot24, align 64
  %516 = add <8 x i64> %.state161, splat (i64 3)
  %tile_snapshot.spill.load162 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 0
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 1
  %519 = mul <8 x i64> %516, splat (i64 32)
  %520 = add <8 x i64> %518, %519
  %521 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %517, 0
  %522 = insertvalue { <8 x ptr>, <8 x i64> } %521, <8 x i64> %520, 1
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %524 = extractvalue { <8 x ptr>, <8 x i64> } %522, 1
  %525 = extractelement <8 x ptr> %523, i32 0
  %526 = extractelement <8 x i64> %524, i32 0
  %527 = sub i64 %526, 0
  %528 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %529 = select i1 %528, i64 %527, i64 0
  %private.contiguous.address163 = getelementptr i8, ptr %525, i64 %529
  %private.contiguous.load164 = load <8 x float>, ptr %private.contiguous.address163, align 4
  %530 = select <8 x i1> %57, <8 x float> %private.contiguous.load164, <8 x float> zeroinitializer
  %.state165 = load <8 x float>, ptr %.slot28, align 32
  %531 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state165, <8 x float> %530)
  %.state166 = load <8 x i64>, ptr %.slot24, align 64
  %532 = add <8 x i64> %.state166, splat (i64 4)
  %533 = load <8 x i64>, ptr %.slot24, align 64
  %534 = select <8 x i1> %57, <8 x i64> %532, <8 x i64> %533
  store <8 x i64> %534, ptr %.slot24, align 64
  %535 = load <8 x float>, ptr %.slot25, align 32
  %536 = select <8 x i1> %57, <8 x float> %483, <8 x float> %535
  store <8 x float> %536, ptr %.slot25, align 32
  %537 = load <8 x float>, ptr %.slot26, align 32
  %538 = select <8 x i1> %57, <8 x float> %499, <8 x float> %537
  store <8 x float> %538, ptr %.slot26, align 32
  %539 = load <8 x float>, ptr %.slot27, align 32
  %540 = select <8 x i1> %57, <8 x float> %515, <8 x float> %539
  store <8 x float> %540, ptr %.slot27, align 32
  %541 = load <8 x float>, ptr %.slot28, align 32
  %542 = select <8 x i1> %57, <8 x float> %531, <8 x float> %541
  store <8 x float> %542, ptr %.slot28, align 32
  br label %direct.schedule.21

direct.schedule.23:                               ; preds = %direct.false145
  %.spill.load167 = load <8 x i1>, ptr %.spill14, align 1
  %543 = and <8 x i1> %57, %.spill.load167
  %544 = xor <8 x i1> %.spill.load167, splat (i1 true)
  %545 = and <8 x i1> %57, %544
  %546 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %543)
  %547 = bitcast <8 x i1> %543 to i8
  %548 = call i8 @llvm.cttz.i8(i8 %547, i1 false)
  %549 = zext i8 %548 to i32
  %550 = select i1 %546, i32 %549, i32 0
  %tile_snapshot.spill.load168 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %551 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load168, 0
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load168, 1
  %553 = add <8 x i64> %552, splat (i64 256)
  %554 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %551, 0
  %555 = insertvalue { <8 x ptr>, <8 x i64> } %554, <8 x i64> %553, 1
  %556 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %557 = extractvalue { <8 x ptr>, <8 x i64> } %555, 1
  %558 = extractelement <8 x ptr> %556, i32 0
  %559 = extractelement <8 x i64> %557, i32 %550
  %560 = zext i32 %550 to i64
  %561 = mul i64 %560, 4
  %562 = sub i64 %559, %561
  %563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %543)
  %564 = select i1 %563, i64 %562, i64 0
  %private.contiguous.address169 = getelementptr i8, ptr %558, i64 %564
  %private.contiguous.load170 = load <8 x float>, ptr %private.contiguous.address169, align 4
  %565 = select <8 x i1> %543, <8 x float> %private.contiguous.load170, <8 x float> zeroinitializer
  %.state171 = load <8 x float>, ptr %.slot25, align 32
  %566 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state171, <8 x float> %565)
  %567 = load <8 x float>, ptr %.slot29, align 32
  %568 = select <8 x i1> %543, <8 x float> %566, <8 x float> %567
  store <8 x float> %568, ptr %.slot29, align 32
  %569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %545)
  %570 = bitcast <8 x i1> %545 to i8
  %571 = call i8 @llvm.cttz.i8(i8 %570, i1 false)
  %572 = zext i8 %571 to i32
  %573 = select i1 %569, i32 %572, i32 0
  %.state172 = load <8 x float>, ptr %.slot25, align 32
  %574 = load <8 x float>, ptr %.slot29, align 32
  %575 = select <8 x i1> %545, <8 x float> %.state172, <8 x float> %574
  store <8 x float> %575, ptr %.slot29, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.23
  %.state173 = load <8 x float>, ptr %.slot29, align 32
  %.state174 = load <8 x float>, ptr %.slot26, align 32
  %576 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state173, <8 x float> %.state174)
  %.state175 = load <8 x float>, ptr %.slot27, align 32
  %577 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %576, <8 x float> %.state175)
  %.state176 = load <8 x float>, ptr %.slot28, align 32
  %578 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %577, <8 x float> %.state176)
  %.spill.load177 = load <8 x i64>, ptr %.spill, align 64
  %579 = trunc <8 x i64> %.spill.load177 to <8 x i32>
  %580 = xor <8 x i32> %579, splat (i32 1)
  %581 = load <8 x i32>, ptr %.spill30, align 32
  %582 = select <8 x i1> %57, <8 x i32> %580, <8 x i32> %581
  store <8 x i32> %582, ptr %.spill30, align 32
  %583 = extractelement <8 x i32> %580, i64 0
  %584 = icmp ult i32 %583, 8
  %585 = select i1 %584, i32 %583, i32 0
  %586 = extractelement <8 x i1> %57, i32 %585
  %587 = extractelement <8 x i1> %57, i64 0
  %588 = and i1 %584, %586
  %589 = and i1 %587, %588
  %590 = extractelement <8 x float> %578, i32 %585
  %591 = select i1 %589, float %590, float 0.000000e+00
  %592 = insertelement <8 x float> poison, float %591, i64 0
  %593 = xor i1 %589, true
  %594 = and i1 %587, %593
  %595 = insertelement <8 x i1> poison, i1 %594, i64 0
  %596 = extractelement <8 x i32> %580, i64 1
  %597 = icmp ult i32 %596, 8
  %598 = select i1 %597, i32 %596, i32 0
  %599 = extractelement <8 x i1> %57, i32 %598
  %600 = extractelement <8 x i1> %57, i64 1
  %601 = and i1 %597, %599
  %602 = and i1 %600, %601
  %603 = extractelement <8 x float> %578, i32 %598
  %604 = select i1 %602, float %603, float 0.000000e+00
  %605 = insertelement <8 x float> %592, float %604, i64 1
  %606 = xor i1 %602, true
  %607 = and i1 %600, %606
  %608 = insertelement <8 x i1> %595, i1 %607, i64 1
  %609 = extractelement <8 x i32> %580, i64 2
  %610 = icmp ult i32 %609, 8
  %611 = select i1 %610, i32 %609, i32 0
  %612 = extractelement <8 x i1> %57, i32 %611
  %613 = extractelement <8 x i1> %57, i64 2
  %614 = and i1 %610, %612
  %615 = and i1 %613, %614
  %616 = extractelement <8 x float> %578, i32 %611
  %617 = select i1 %615, float %616, float 0.000000e+00
  %618 = insertelement <8 x float> %605, float %617, i64 2
  %619 = xor i1 %615, true
  %620 = and i1 %613, %619
  %621 = insertelement <8 x i1> %608, i1 %620, i64 2
  %622 = extractelement <8 x i32> %580, i64 3
  %623 = icmp ult i32 %622, 8
  %624 = select i1 %623, i32 %622, i32 0
  %625 = extractelement <8 x i1> %57, i32 %624
  %626 = extractelement <8 x i1> %57, i64 3
  %627 = and i1 %623, %625
  %628 = and i1 %626, %627
  %629 = extractelement <8 x float> %578, i32 %624
  %630 = select i1 %628, float %629, float 0.000000e+00
  %631 = insertelement <8 x float> %618, float %630, i64 3
  %632 = xor i1 %628, true
  %633 = and i1 %626, %632
  %634 = insertelement <8 x i1> %621, i1 %633, i64 3
  %635 = extractelement <8 x i32> %580, i64 4
  %636 = icmp ult i32 %635, 8
  %637 = select i1 %636, i32 %635, i32 0
  %638 = extractelement <8 x i1> %57, i32 %637
  %639 = extractelement <8 x i1> %57, i64 4
  %640 = and i1 %636, %638
  %641 = and i1 %639, %640
  %642 = extractelement <8 x float> %578, i32 %637
  %643 = select i1 %641, float %642, float 0.000000e+00
  %644 = insertelement <8 x float> %631, float %643, i64 4
  %645 = xor i1 %641, true
  %646 = and i1 %639, %645
  %647 = insertelement <8 x i1> %634, i1 %646, i64 4
  %648 = extractelement <8 x i32> %580, i64 5
  %649 = icmp ult i32 %648, 8
  %650 = select i1 %649, i32 %648, i32 0
  %651 = extractelement <8 x i1> %57, i32 %650
  %652 = extractelement <8 x i1> %57, i64 5
  %653 = and i1 %649, %651
  %654 = and i1 %652, %653
  %655 = extractelement <8 x float> %578, i32 %650
  %656 = select i1 %654, float %655, float 0.000000e+00
  %657 = insertelement <8 x float> %644, float %656, i64 5
  %658 = xor i1 %654, true
  %659 = and i1 %652, %658
  %660 = insertelement <8 x i1> %647, i1 %659, i64 5
  %661 = extractelement <8 x i32> %580, i64 6
  %662 = icmp ult i32 %661, 8
  %663 = select i1 %662, i32 %661, i32 0
  %664 = extractelement <8 x i1> %57, i32 %663
  %665 = extractelement <8 x i1> %57, i64 6
  %666 = and i1 %662, %664
  %667 = and i1 %665, %666
  %668 = extractelement <8 x float> %578, i32 %663
  %669 = select i1 %667, float %668, float 0.000000e+00
  %670 = insertelement <8 x float> %657, float %669, i64 6
  %671 = xor i1 %667, true
  %672 = and i1 %665, %671
  %673 = insertelement <8 x i1> %660, i1 %672, i64 6
  %674 = extractelement <8 x i32> %580, i64 7
  %675 = icmp ult i32 %674, 8
  %676 = select i1 %675, i32 %674, i32 0
  %677 = extractelement <8 x i1> %57, i32 %676
  %678 = extractelement <8 x i1> %57, i64 7
  %679 = and i1 %675, %677
  %680 = and i1 %678, %679
  %681 = extractelement <8 x float> %578, i32 %676
  %682 = select i1 %680, float %681, float 0.000000e+00
  %683 = insertelement <8 x float> %670, float %682, i64 7
  %684 = xor i1 %680, true
  %685 = and i1 %678, %684
  %686 = insertelement <8 x i1> %673, i1 %685, i64 7
  %687 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %578, <8 x float> %683)
  %688 = xor <8 x i32> %579, splat (i32 2)
  %689 = load <8 x i32>, ptr %.spill31, align 32
  %690 = select <8 x i1> %57, <8 x i32> %688, <8 x i32> %689
  store <8 x i32> %690, ptr %.spill31, align 32
  %691 = extractelement <8 x i32> %688, i64 0
  %692 = icmp ult i32 %691, 8
  %693 = select i1 %692, i32 %691, i32 0
  %694 = extractelement <8 x i1> %57, i32 %693
  %695 = extractelement <8 x i1> %57, i64 0
  %696 = and i1 %692, %694
  %697 = and i1 %695, %696
  %698 = extractelement <8 x float> %687, i32 %693
  %699 = select i1 %697, float %698, float 0.000000e+00
  %700 = insertelement <8 x float> poison, float %699, i64 0
  %701 = xor i1 %697, true
  %702 = and i1 %695, %701
  %703 = insertelement <8 x i1> poison, i1 %702, i64 0
  %704 = extractelement <8 x i32> %688, i64 1
  %705 = icmp ult i32 %704, 8
  %706 = select i1 %705, i32 %704, i32 0
  %707 = extractelement <8 x i1> %57, i32 %706
  %708 = extractelement <8 x i1> %57, i64 1
  %709 = and i1 %705, %707
  %710 = and i1 %708, %709
  %711 = extractelement <8 x float> %687, i32 %706
  %712 = select i1 %710, float %711, float 0.000000e+00
  %713 = insertelement <8 x float> %700, float %712, i64 1
  %714 = xor i1 %710, true
  %715 = and i1 %708, %714
  %716 = insertelement <8 x i1> %703, i1 %715, i64 1
  %717 = extractelement <8 x i32> %688, i64 2
  %718 = icmp ult i32 %717, 8
  %719 = select i1 %718, i32 %717, i32 0
  %720 = extractelement <8 x i1> %57, i32 %719
  %721 = extractelement <8 x i1> %57, i64 2
  %722 = and i1 %718, %720
  %723 = and i1 %721, %722
  %724 = extractelement <8 x float> %687, i32 %719
  %725 = select i1 %723, float %724, float 0.000000e+00
  %726 = insertelement <8 x float> %713, float %725, i64 2
  %727 = xor i1 %723, true
  %728 = and i1 %721, %727
  %729 = insertelement <8 x i1> %716, i1 %728, i64 2
  %730 = extractelement <8 x i32> %688, i64 3
  %731 = icmp ult i32 %730, 8
  %732 = select i1 %731, i32 %730, i32 0
  %733 = extractelement <8 x i1> %57, i32 %732
  %734 = extractelement <8 x i1> %57, i64 3
  %735 = and i1 %731, %733
  %736 = and i1 %734, %735
  %737 = extractelement <8 x float> %687, i32 %732
  %738 = select i1 %736, float %737, float 0.000000e+00
  %739 = insertelement <8 x float> %726, float %738, i64 3
  %740 = xor i1 %736, true
  %741 = and i1 %734, %740
  %742 = insertelement <8 x i1> %729, i1 %741, i64 3
  %743 = extractelement <8 x i32> %688, i64 4
  %744 = icmp ult i32 %743, 8
  %745 = select i1 %744, i32 %743, i32 0
  %746 = extractelement <8 x i1> %57, i32 %745
  %747 = extractelement <8 x i1> %57, i64 4
  %748 = and i1 %744, %746
  %749 = and i1 %747, %748
  %750 = extractelement <8 x float> %687, i32 %745
  %751 = select i1 %749, float %750, float 0.000000e+00
  %752 = insertelement <8 x float> %739, float %751, i64 4
  %753 = xor i1 %749, true
  %754 = and i1 %747, %753
  %755 = insertelement <8 x i1> %742, i1 %754, i64 4
  %756 = extractelement <8 x i32> %688, i64 5
  %757 = icmp ult i32 %756, 8
  %758 = select i1 %757, i32 %756, i32 0
  %759 = extractelement <8 x i1> %57, i32 %758
  %760 = extractelement <8 x i1> %57, i64 5
  %761 = and i1 %757, %759
  %762 = and i1 %760, %761
  %763 = extractelement <8 x float> %687, i32 %758
  %764 = select i1 %762, float %763, float 0.000000e+00
  %765 = insertelement <8 x float> %752, float %764, i64 5
  %766 = xor i1 %762, true
  %767 = and i1 %760, %766
  %768 = insertelement <8 x i1> %755, i1 %767, i64 5
  %769 = extractelement <8 x i32> %688, i64 6
  %770 = icmp ult i32 %769, 8
  %771 = select i1 %770, i32 %769, i32 0
  %772 = extractelement <8 x i1> %57, i32 %771
  %773 = extractelement <8 x i1> %57, i64 6
  %774 = and i1 %770, %772
  %775 = and i1 %773, %774
  %776 = extractelement <8 x float> %687, i32 %771
  %777 = select i1 %775, float %776, float 0.000000e+00
  %778 = insertelement <8 x float> %765, float %777, i64 6
  %779 = xor i1 %775, true
  %780 = and i1 %773, %779
  %781 = insertelement <8 x i1> %768, i1 %780, i64 6
  %782 = extractelement <8 x i32> %688, i64 7
  %783 = icmp ult i32 %782, 8
  %784 = select i1 %783, i32 %782, i32 0
  %785 = extractelement <8 x i1> %57, i32 %784
  %786 = extractelement <8 x i1> %57, i64 7
  %787 = and i1 %783, %785
  %788 = and i1 %786, %787
  %789 = extractelement <8 x float> %687, i32 %784
  %790 = select i1 %788, float %789, float 0.000000e+00
  %791 = insertelement <8 x float> %778, float %790, i64 7
  %792 = xor i1 %788, true
  %793 = and i1 %786, %792
  %794 = insertelement <8 x i1> %781, i1 %793, i64 7
  %795 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %687, <8 x float> %791)
  %796 = xor <8 x i32> %579, splat (i32 4)
  %797 = load <8 x i32>, ptr %.spill32, align 32
  %798 = select <8 x i1> %57, <8 x i32> %796, <8 x i32> %797
  store <8 x i32> %798, ptr %.spill32, align 32
  %799 = extractelement <8 x i32> %796, i64 0
  %800 = icmp ult i32 %799, 8
  %801 = select i1 %800, i32 %799, i32 0
  %802 = extractelement <8 x i1> %57, i32 %801
  %803 = extractelement <8 x i1> %57, i64 0
  %804 = and i1 %800, %802
  %805 = and i1 %803, %804
  %806 = extractelement <8 x float> %795, i32 %801
  %807 = select i1 %805, float %806, float 0.000000e+00
  %808 = insertelement <8 x float> poison, float %807, i64 0
  %809 = xor i1 %805, true
  %810 = and i1 %803, %809
  %811 = insertelement <8 x i1> poison, i1 %810, i64 0
  %812 = extractelement <8 x i32> %796, i64 1
  %813 = icmp ult i32 %812, 8
  %814 = select i1 %813, i32 %812, i32 0
  %815 = extractelement <8 x i1> %57, i32 %814
  %816 = extractelement <8 x i1> %57, i64 1
  %817 = and i1 %813, %815
  %818 = and i1 %816, %817
  %819 = extractelement <8 x float> %795, i32 %814
  %820 = select i1 %818, float %819, float 0.000000e+00
  %821 = insertelement <8 x float> %808, float %820, i64 1
  %822 = xor i1 %818, true
  %823 = and i1 %816, %822
  %824 = insertelement <8 x i1> %811, i1 %823, i64 1
  %825 = extractelement <8 x i32> %796, i64 2
  %826 = icmp ult i32 %825, 8
  %827 = select i1 %826, i32 %825, i32 0
  %828 = extractelement <8 x i1> %57, i32 %827
  %829 = extractelement <8 x i1> %57, i64 2
  %830 = and i1 %826, %828
  %831 = and i1 %829, %830
  %832 = extractelement <8 x float> %795, i32 %827
  %833 = select i1 %831, float %832, float 0.000000e+00
  %834 = insertelement <8 x float> %821, float %833, i64 2
  %835 = xor i1 %831, true
  %836 = and i1 %829, %835
  %837 = insertelement <8 x i1> %824, i1 %836, i64 2
  %838 = extractelement <8 x i32> %796, i64 3
  %839 = icmp ult i32 %838, 8
  %840 = select i1 %839, i32 %838, i32 0
  %841 = extractelement <8 x i1> %57, i32 %840
  %842 = extractelement <8 x i1> %57, i64 3
  %843 = and i1 %839, %841
  %844 = and i1 %842, %843
  %845 = extractelement <8 x float> %795, i32 %840
  %846 = select i1 %844, float %845, float 0.000000e+00
  %847 = insertelement <8 x float> %834, float %846, i64 3
  %848 = xor i1 %844, true
  %849 = and i1 %842, %848
  %850 = insertelement <8 x i1> %837, i1 %849, i64 3
  %851 = extractelement <8 x i32> %796, i64 4
  %852 = icmp ult i32 %851, 8
  %853 = select i1 %852, i32 %851, i32 0
  %854 = extractelement <8 x i1> %57, i32 %853
  %855 = extractelement <8 x i1> %57, i64 4
  %856 = and i1 %852, %854
  %857 = and i1 %855, %856
  %858 = extractelement <8 x float> %795, i32 %853
  %859 = select i1 %857, float %858, float 0.000000e+00
  %860 = insertelement <8 x float> %847, float %859, i64 4
  %861 = xor i1 %857, true
  %862 = and i1 %855, %861
  %863 = insertelement <8 x i1> %850, i1 %862, i64 4
  %864 = extractelement <8 x i32> %796, i64 5
  %865 = icmp ult i32 %864, 8
  %866 = select i1 %865, i32 %864, i32 0
  %867 = extractelement <8 x i1> %57, i32 %866
  %868 = extractelement <8 x i1> %57, i64 5
  %869 = and i1 %865, %867
  %870 = and i1 %868, %869
  %871 = extractelement <8 x float> %795, i32 %866
  %872 = select i1 %870, float %871, float 0.000000e+00
  %873 = insertelement <8 x float> %860, float %872, i64 5
  %874 = xor i1 %870, true
  %875 = and i1 %868, %874
  %876 = insertelement <8 x i1> %863, i1 %875, i64 5
  %877 = extractelement <8 x i32> %796, i64 6
  %878 = icmp ult i32 %877, 8
  %879 = select i1 %878, i32 %877, i32 0
  %880 = extractelement <8 x i1> %57, i32 %879
  %881 = extractelement <8 x i1> %57, i64 6
  %882 = and i1 %878, %880
  %883 = and i1 %881, %882
  %884 = extractelement <8 x float> %795, i32 %879
  %885 = select i1 %883, float %884, float 0.000000e+00
  %886 = insertelement <8 x float> %873, float %885, i64 6
  %887 = xor i1 %883, true
  %888 = and i1 %881, %887
  %889 = insertelement <8 x i1> %876, i1 %888, i64 6
  %890 = extractelement <8 x i32> %796, i64 7
  %891 = icmp ult i32 %890, 8
  %892 = select i1 %891, i32 %890, i32 0
  %893 = extractelement <8 x i1> %57, i32 %892
  %894 = extractelement <8 x i1> %57, i64 7
  %895 = and i1 %891, %893
  %896 = and i1 %894, %895
  %897 = extractelement <8 x float> %795, i32 %892
  %898 = select i1 %896, float %897, float 0.000000e+00
  %899 = insertelement <8 x float> %886, float %898, i64 7
  %900 = xor i1 %896, true
  %901 = and i1 %894, %900
  %902 = insertelement <8 x i1> %889, i1 %901, i64 7
  %903 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %795, <8 x float> %899)
  %904 = extractelement <8 x i1> %57, i32 0
  %905 = extractelement <8 x i1> %57, i64 0
  %906 = and i1 true, %904
  %907 = and i1 %905, %906
  %908 = extractelement <8 x float> %903, i32 0
  %909 = select i1 %907, float %908, float 0.000000e+00
  %910 = insertelement <8 x float> poison, float %909, i64 0
  %911 = xor i1 %907, true
  %912 = and i1 %905, %911
  %913 = insertelement <8 x i1> poison, i1 %912, i64 0
  %914 = extractelement <8 x i1> %57, i32 0
  %915 = extractelement <8 x i1> %57, i64 1
  %916 = and i1 true, %914
  %917 = and i1 %915, %916
  %918 = extractelement <8 x float> %903, i32 0
  %919 = select i1 %917, float %918, float 0.000000e+00
  %920 = insertelement <8 x float> %910, float %919, i64 1
  %921 = xor i1 %917, true
  %922 = and i1 %915, %921
  %923 = insertelement <8 x i1> %913, i1 %922, i64 1
  %924 = extractelement <8 x i1> %57, i32 0
  %925 = extractelement <8 x i1> %57, i64 2
  %926 = and i1 true, %924
  %927 = and i1 %925, %926
  %928 = extractelement <8 x float> %903, i32 0
  %929 = select i1 %927, float %928, float 0.000000e+00
  %930 = insertelement <8 x float> %920, float %929, i64 2
  %931 = xor i1 %927, true
  %932 = and i1 %925, %931
  %933 = insertelement <8 x i1> %923, i1 %932, i64 2
  %934 = extractelement <8 x i1> %57, i32 0
  %935 = extractelement <8 x i1> %57, i64 3
  %936 = and i1 true, %934
  %937 = and i1 %935, %936
  %938 = extractelement <8 x float> %903, i32 0
  %939 = select i1 %937, float %938, float 0.000000e+00
  %940 = insertelement <8 x float> %930, float %939, i64 3
  %941 = xor i1 %937, true
  %942 = and i1 %935, %941
  %943 = insertelement <8 x i1> %933, i1 %942, i64 3
  %944 = extractelement <8 x i1> %57, i32 0
  %945 = extractelement <8 x i1> %57, i64 4
  %946 = and i1 true, %944
  %947 = and i1 %945, %946
  %948 = extractelement <8 x float> %903, i32 0
  %949 = select i1 %947, float %948, float 0.000000e+00
  %950 = insertelement <8 x float> %940, float %949, i64 4
  %951 = xor i1 %947, true
  %952 = and i1 %945, %951
  %953 = insertelement <8 x i1> %943, i1 %952, i64 4
  %954 = extractelement <8 x i1> %57, i32 0
  %955 = extractelement <8 x i1> %57, i64 5
  %956 = and i1 true, %954
  %957 = and i1 %955, %956
  %958 = extractelement <8 x float> %903, i32 0
  %959 = select i1 %957, float %958, float 0.000000e+00
  %960 = insertelement <8 x float> %950, float %959, i64 5
  %961 = xor i1 %957, true
  %962 = and i1 %955, %961
  %963 = insertelement <8 x i1> %953, i1 %962, i64 5
  %964 = extractelement <8 x i1> %57, i32 0
  %965 = extractelement <8 x i1> %57, i64 6
  %966 = and i1 true, %964
  %967 = and i1 %965, %966
  %968 = extractelement <8 x float> %903, i32 0
  %969 = select i1 %967, float %968, float 0.000000e+00
  %970 = insertelement <8 x float> %960, float %969, i64 6
  %971 = xor i1 %967, true
  %972 = and i1 %965, %971
  %973 = insertelement <8 x i1> %963, i1 %972, i64 6
  %974 = extractelement <8 x i1> %57, i32 0
  %975 = extractelement <8 x i1> %57, i64 7
  %976 = and i1 true, %974
  %977 = and i1 %975, %976
  %978 = extractelement <8 x float> %903, i32 0
  %979 = select i1 %977, float %978, float 0.000000e+00
  %980 = insertelement <8 x float> %970, float %979, i64 7
  %981 = xor i1 %977, true
  %982 = and i1 %975, %981
  %983 = insertelement <8 x i1> %973, i1 %982, i64 7
  %984 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %985 = bitcast <8 x i1> %57 to i8
  %986 = call i8 @llvm.cttz.i8(i8 %985, i1 false)
  %987 = zext i8 %986 to i32
  %988 = select i1 %984, i32 %987, i32 0
  %989 = extractelement <8 x float> %980, i32 %988
  %.spill.load178 = load float, ptr %.spill23, align 4
  %990 = call float @llvm.maxnum.f32(float %.spill.load178, float %989)
  store float %990, ptr %.spill33, align 4
  store float 0.000000e+00, ptr %.spill34, align 4
  %991 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %992 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %993 = extractvalue { <8 x ptr>, <8 x i64> } %991, 0
  %994 = select <8 x i1> %57, <8 x ptr> %992, <8 x ptr> %993
  %995 = extractvalue { <8 x ptr>, <8 x i64> } %9, 1
  %996 = extractvalue { <8 x ptr>, <8 x i64> } %991, 1
  %997 = select <8 x i1> %57, <8 x i64> %995, <8 x i64> %996
  %998 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %994, 0
  %999 = insertvalue { <8 x ptr>, <8 x i64> } %998, <8 x i64> %997, 1
  store { <8 x ptr>, <8 x i64> } %999, ptr %tile_snapshot.spill35, align 64
  %1000 = load <8 x i64>, ptr %.slot36, align 64
  %1001 = select <8 x i1> %57, <8 x i64> zeroinitializer, <8 x i64> %1000
  store <8 x i64> %1001, ptr %.slot36, align 64
  br label %direct.schedule.26

direct.schedule.26:                               ; preds = %direct.schedule.27, %direct.schedule.25
  %.state179 = load <8 x i64>, ptr %.slot36, align 64
  %1002 = icmp slt <8 x i64> %.state179, splat (i64 8)
  %1003 = extractelement <8 x i1> %1002, i32 0
  br i1 %1003, label %direct.true180, label %direct.false181

direct.schedule.27:                               ; preds = %direct.true180
  %tile_snapshot.spill.load182 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %1004 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 0
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 1
  %.state183 = load <8 x i64>, ptr %.slot36, align 64
  %1006 = add <8 x i64> %1005, %.state183
  %1007 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1004, 0
  %1008 = insertvalue { <8 x ptr>, <8 x i64> } %1007, <8 x i64> %1006, 1
  %1009 = extractvalue { <8 x ptr>, <8 x i64> } %1008, 0
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %1008, 1
  %1011 = getelementptr i8, <8 x ptr> %1009, <8 x i64> %1010
  %1012 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %1011, i32 1, <8 x i1> %57, <8 x i8> zeroinitializer)
  %1013 = icmp ne <8 x i8> %1012, zeroinitializer
  %tile_snapshot.spill.load184 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %1014 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 0
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 1
  %.state185 = load <8 x i64>, ptr %.slot36, align 64
  %1016 = mul <8 x i64> %.state185, splat (i64 32)
  %1017 = add <8 x i64> %1015, %1016
  %1018 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1014, 0
  %1019 = insertvalue { <8 x ptr>, <8 x i64> } %1018, <8 x i64> %1017, 1
  %1020 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1021 = extractvalue { <8 x ptr>, <8 x i64> } %1019, 1
  %1022 = extractelement <8 x ptr> %1020, i32 0
  %1023 = extractelement <8 x i64> %1021, i32 0
  %1024 = sub i64 %1023, 0
  %1025 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1026 = select i1 %1025, i64 %1024, i64 0
  %private.contiguous.address186 = getelementptr i8, ptr %1022, i64 %1026
  %private.contiguous.load187 = load <8 x float>, ptr %private.contiguous.address186, align 4
  %1027 = select <8 x i1> %57, <8 x float> %private.contiguous.load187, <8 x float> zeroinitializer
  %.spill.load188 = load float, ptr %.spill33, align 4
  %.splatinsert189 = insertelement <8 x float> poison, float %.spill.load188, i64 0
  %.splat190 = shufflevector <8 x float> %.splatinsert189, <8 x float> poison, <8 x i32> zeroinitializer
  %1028 = fsub <8 x float> %1027, %.splat190
  %1029 = select <8 x i1> %57, <8 x float> %1028, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1029)
  %.spill.load191 = load float, ptr %.spill34, align 4
  %.splatinsert192 = insertelement <8 x float> poison, float %.spill.load191, i64 0
  %.splat193 = shufflevector <8 x float> %.splatinsert192, <8 x float> poison, <8 x i32> zeroinitializer
  %1030 = select <8 x i1> %1013, <8 x float> %native.exp, <8 x float> %.splat193
  %tile_snapshot.spill.load194 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1031 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load194, 0
  %1032 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load194, 1
  %.state195 = load <8 x i64>, ptr %.slot36, align 64
  %1033 = mul <8 x i64> %.state195, splat (i64 32)
  %1034 = add <8 x i64> %1032, %1033
  %1035 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1031, 0
  %1036 = insertvalue { <8 x ptr>, <8 x i64> } %1035, <8 x i64> %1034, 1
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1038 = extractvalue { <8 x ptr>, <8 x i64> } %1036, 1
  %1039 = extractelement <8 x ptr> %1037, i32 0
  %1040 = extractelement <8 x i64> %1038, i32 0
  %1041 = sub i64 %1040, 0
  %1042 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1043 = select i1 %1042, i64 %1041, i64 0
  %private.contiguous.address196 = getelementptr i8, ptr %1039, i64 %1043
  %private.contiguous.preserve197 = load <8 x float>, ptr %private.contiguous.address196, align 4
  %1044 = select <8 x i1> %57, <8 x float> %1030, <8 x float> %private.contiguous.preserve197
  store <8 x float> %1044, ptr %private.contiguous.address196, align 4
  %.state198 = load <8 x i64>, ptr %.slot36, align 64
  %1045 = add <8 x i64> %.state198, splat (i64 1)
  %1046 = load <8 x i64>, ptr %.slot36, align 64
  %1047 = select <8 x i1> %57, <8 x i64> %1045, <8 x i64> %1046
  store <8 x i64> %1047, ptr %.slot36, align 64
  br label %direct.schedule.26

direct.schedule.28:                               ; preds = %direct.false181
  %.spill.load199 = load <8 x i1>, ptr %.spill14, align 1
  %1048 = and <8 x i1> %57, %.spill.load199
  %1049 = xor <8 x i1> %.spill.load199, splat (i1 true)
  %1050 = and <8 x i1> %57, %1049
  %1051 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1048)
  %1052 = bitcast <8 x i1> %1048 to i8
  %1053 = call i8 @llvm.cttz.i8(i8 %1052, i1 false)
  %1054 = zext i8 %1053 to i32
  %1055 = select i1 %1051, i32 %1054, i32 0
  %tile_snapshot.spill.load200 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %1056 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load200, 0
  %1057 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load200, 1
  %1058 = add <8 x i64> %1057, splat (i64 8)
  %1059 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1056, 0
  %1060 = insertvalue { <8 x ptr>, <8 x i64> } %1059, <8 x i64> %1058, 1
  %1061 = extractvalue { <8 x ptr>, <8 x i64> } %1060, 0
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %1060, 1
  %1063 = getelementptr i8, <8 x ptr> %1061, <8 x i64> %1062
  %1064 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> %1063, i32 1, <8 x i1> %1048, <8 x i8> zeroinitializer)
  %1065 = icmp ne <8 x i8> %1064, zeroinitializer
  %tile_snapshot.spill.load201 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill21, align 64
  %1066 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 0
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 1
  %1068 = add <8 x i64> %1067, splat (i64 256)
  %1069 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1066, 0
  %1070 = insertvalue { <8 x ptr>, <8 x i64> } %1069, <8 x i64> %1068, 1
  %1071 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1072 = extractvalue { <8 x ptr>, <8 x i64> } %1070, 1
  %1073 = extractelement <8 x ptr> %1071, i32 0
  %1074 = extractelement <8 x i64> %1072, i32 %1055
  %1075 = zext i32 %1055 to i64
  %1076 = mul i64 %1075, 4
  %1077 = sub i64 %1074, %1076
  %1078 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1048)
  %1079 = select i1 %1078, i64 %1077, i64 0
  %private.contiguous.address202 = getelementptr i8, ptr %1073, i64 %1079
  %private.contiguous.load203 = load <8 x float>, ptr %private.contiguous.address202, align 4
  %1080 = select <8 x i1> %1048, <8 x float> %private.contiguous.load203, <8 x float> zeroinitializer
  %.spill.load204 = load float, ptr %.spill33, align 4
  %.splatinsert205 = insertelement <8 x float> poison, float %.spill.load204, i64 0
  %.splat206 = shufflevector <8 x float> %.splatinsert205, <8 x float> poison, <8 x i32> zeroinitializer
  %1081 = fsub <8 x float> %1080, %.splat206
  %1082 = select <8 x i1> %1048, <8 x float> %1081, <8 x float> zeroinitializer
  %native.exp207 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1082)
  %.spill.load208 = load float, ptr %.spill34, align 4
  %.splatinsert209 = insertelement <8 x float> poison, float %.spill.load208, i64 0
  %.splat210 = shufflevector <8 x float> %.splatinsert209, <8 x float> poison, <8 x i32> zeroinitializer
  %1083 = select <8 x i1> %1065, <8 x float> %native.exp207, <8 x float> %.splat210
  %tile_snapshot.spill.load211 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1084 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 0
  %1085 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 1
  %1086 = add <8 x i64> %1085, splat (i64 256)
  %1087 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1084, 0
  %1088 = insertvalue { <8 x ptr>, <8 x i64> } %1087, <8 x i64> %1086, 1
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1090 = extractvalue { <8 x ptr>, <8 x i64> } %1088, 1
  %1091 = extractelement <8 x ptr> %1089, i32 0
  %1092 = extractelement <8 x i64> %1090, i32 %1055
  %1093 = zext i32 %1055 to i64
  %1094 = mul i64 %1093, 4
  %1095 = sub i64 %1092, %1094
  %1096 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1048)
  %1097 = select i1 %1096, i64 %1095, i64 0
  %private.contiguous.address212 = getelementptr i8, ptr %1091, i64 %1097
  %private.contiguous.preserve213 = load <8 x float>, ptr %private.contiguous.address212, align 4
  %1098 = select <8 x i1> %1048, <8 x float> %1083, <8 x float> %private.contiguous.preserve213
  store <8 x float> %1098, ptr %private.contiguous.address212, align 4
  %1099 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1050)
  %1100 = bitcast <8 x i1> %1050 to i8
  %1101 = call i8 @llvm.cttz.i8(i8 %1100, i1 false)
  %1102 = zext i8 %1101 to i32
  %1103 = select i1 %1099, i32 %1102, i32 0
  br label %direct.schedule.30

direct.schedule.30:                               ; preds = %direct.schedule.28
  %tile_snapshot.spill.load214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1104 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 0
  %1105 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 1
  %1106 = add <8 x i64> %1105, zeroinitializer
  %1107 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1104, 0
  %1108 = insertvalue { <8 x ptr>, <8 x i64> } %1107, <8 x i64> %1106, 1
  %1109 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1110 = extractvalue { <8 x ptr>, <8 x i64> } %1108, 1
  %1111 = extractelement <8 x ptr> %1109, i32 0
  %1112 = extractelement <8 x i64> %1110, i32 0
  %1113 = sub i64 %1112, 0
  %1114 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1115 = select i1 %1114, i64 %1113, i64 0
  %private.contiguous.address215 = getelementptr i8, ptr %1111, i64 %1115
  %private.contiguous.load216 = load <8 x float>, ptr %private.contiguous.address215, align 4
  %1116 = select <8 x i1> %57, <8 x float> %private.contiguous.load216, <8 x float> zeroinitializer
  %tile_snapshot.spill.load217 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1117 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load217, 0
  %1118 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load217, 1
  %1119 = add <8 x i64> %1118, splat (i64 32)
  %1120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1117, 0
  %1121 = insertvalue { <8 x ptr>, <8 x i64> } %1120, <8 x i64> %1119, 1
  %1122 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1123 = extractvalue { <8 x ptr>, <8 x i64> } %1121, 1
  %1124 = extractelement <8 x ptr> %1122, i32 0
  %1125 = extractelement <8 x i64> %1123, i32 0
  %1126 = sub i64 %1125, 0
  %1127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1128 = select i1 %1127, i64 %1126, i64 0
  %private.contiguous.address218 = getelementptr i8, ptr %1124, i64 %1128
  %private.contiguous.load219 = load <8 x float>, ptr %private.contiguous.address218, align 4
  %1129 = select <8 x i1> %57, <8 x float> %private.contiguous.load219, <8 x float> zeroinitializer
  %tile_snapshot.spill.load220 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1130 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load220, 0
  %1131 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load220, 1
  %1132 = add <8 x i64> %1131, splat (i64 64)
  %1133 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1130, 0
  %1134 = insertvalue { <8 x ptr>, <8 x i64> } %1133, <8 x i64> %1132, 1
  %1135 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1136 = extractvalue { <8 x ptr>, <8 x i64> } %1134, 1
  %1137 = extractelement <8 x ptr> %1135, i32 0
  %1138 = extractelement <8 x i64> %1136, i32 0
  %1139 = sub i64 %1138, 0
  %1140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1141 = select i1 %1140, i64 %1139, i64 0
  %private.contiguous.address221 = getelementptr i8, ptr %1137, i64 %1141
  %private.contiguous.load222 = load <8 x float>, ptr %private.contiguous.address221, align 4
  %1142 = select <8 x i1> %57, <8 x float> %private.contiguous.load222, <8 x float> zeroinitializer
  %tile_snapshot.spill.load223 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1143 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load223, 0
  %1144 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load223, 1
  %1145 = add <8 x i64> %1144, splat (i64 96)
  %1146 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1143, 0
  %1147 = insertvalue { <8 x ptr>, <8 x i64> } %1146, <8 x i64> %1145, 1
  %1148 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1149 = extractvalue { <8 x ptr>, <8 x i64> } %1147, 1
  %1150 = extractelement <8 x ptr> %1148, i32 0
  %1151 = extractelement <8 x i64> %1149, i32 0
  %1152 = sub i64 %1151, 0
  %1153 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1154 = select i1 %1153, i64 %1152, i64 0
  %private.contiguous.address224 = getelementptr i8, ptr %1150, i64 %1154
  %private.contiguous.load225 = load <8 x float>, ptr %private.contiguous.address224, align 4
  %1155 = select <8 x i1> %57, <8 x float> %private.contiguous.load225, <8 x float> zeroinitializer
  %1156 = load <8 x i64>, ptr %.slot37, align 64
  %1157 = select <8 x i1> %57, <8 x i64> splat (i64 4), <8 x i64> %1156
  store <8 x i64> %1157, ptr %.slot37, align 64
  %1158 = load <8 x float>, ptr %.slot38, align 32
  %1159 = select <8 x i1> %57, <8 x float> %1116, <8 x float> %1158
  store <8 x float> %1159, ptr %.slot38, align 32
  %1160 = load <8 x float>, ptr %.slot39, align 32
  %1161 = select <8 x i1> %57, <8 x float> %1129, <8 x float> %1160
  store <8 x float> %1161, ptr %.slot39, align 32
  %1162 = load <8 x float>, ptr %.slot40, align 32
  %1163 = select <8 x i1> %57, <8 x float> %1142, <8 x float> %1162
  store <8 x float> %1163, ptr %.slot40, align 32
  %1164 = load <8 x float>, ptr %.slot41, align 32
  %1165 = select <8 x i1> %57, <8 x float> %1155, <8 x float> %1164
  store <8 x float> %1165, ptr %.slot41, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state226 = load <8 x i64>, ptr %.slot37, align 64
  %1166 = icmp slt <8 x i64> %.state226, splat (i64 8)
  %1167 = extractelement <8 x i1> %1166, i32 0
  br i1 %1167, label %direct.true227, label %direct.false228

direct.schedule.32:                               ; preds = %direct.true227
  %.state229 = load <8 x i64>, ptr %.slot37, align 64
  %1168 = add <8 x i64> %.state229, zeroinitializer
  %tile_snapshot.spill.load230 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load230, 0
  %1170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load230, 1
  %1171 = mul <8 x i64> %1168, splat (i64 32)
  %1172 = add <8 x i64> %1170, %1171
  %1173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1169, 0
  %1174 = insertvalue { <8 x ptr>, <8 x i64> } %1173, <8 x i64> %1172, 1
  %1175 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1176 = extractvalue { <8 x ptr>, <8 x i64> } %1174, 1
  %1177 = extractelement <8 x ptr> %1175, i32 0
  %1178 = extractelement <8 x i64> %1176, i32 0
  %1179 = sub i64 %1178, 0
  %1180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1181 = select i1 %1180, i64 %1179, i64 0
  %private.contiguous.address231 = getelementptr i8, ptr %1177, i64 %1181
  %private.contiguous.load232 = load <8 x float>, ptr %private.contiguous.address231, align 4
  %1182 = select <8 x i1> %57, <8 x float> %private.contiguous.load232, <8 x float> zeroinitializer
  %.state233 = load <8 x float>, ptr %.slot38, align 32
  %1183 = fadd <8 x float> %.state233, %1182
  %.state234 = load <8 x i64>, ptr %.slot37, align 64
  %1184 = add <8 x i64> %.state234, splat (i64 1)
  %tile_snapshot.spill.load235 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load235, 0
  %1186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load235, 1
  %1187 = mul <8 x i64> %1184, splat (i64 32)
  %1188 = add <8 x i64> %1186, %1187
  %1189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1185, 0
  %1190 = insertvalue { <8 x ptr>, <8 x i64> } %1189, <8 x i64> %1188, 1
  %1191 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %1190, 1
  %1193 = extractelement <8 x ptr> %1191, i32 0
  %1194 = extractelement <8 x i64> %1192, i32 0
  %1195 = sub i64 %1194, 0
  %1196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1197 = select i1 %1196, i64 %1195, i64 0
  %private.contiguous.address236 = getelementptr i8, ptr %1193, i64 %1197
  %private.contiguous.load237 = load <8 x float>, ptr %private.contiguous.address236, align 4
  %1198 = select <8 x i1> %57, <8 x float> %private.contiguous.load237, <8 x float> zeroinitializer
  %.state238 = load <8 x float>, ptr %.slot39, align 32
  %1199 = fadd <8 x float> %.state238, %1198
  %.state239 = load <8 x i64>, ptr %.slot37, align 64
  %1200 = add <8 x i64> %.state239, splat (i64 2)
  %tile_snapshot.spill.load240 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1201 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load240, 0
  %1202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load240, 1
  %1203 = mul <8 x i64> %1200, splat (i64 32)
  %1204 = add <8 x i64> %1202, %1203
  %1205 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1201, 0
  %1206 = insertvalue { <8 x ptr>, <8 x i64> } %1205, <8 x i64> %1204, 1
  %1207 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1208 = extractvalue { <8 x ptr>, <8 x i64> } %1206, 1
  %1209 = extractelement <8 x ptr> %1207, i32 0
  %1210 = extractelement <8 x i64> %1208, i32 0
  %1211 = sub i64 %1210, 0
  %1212 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1213 = select i1 %1212, i64 %1211, i64 0
  %private.contiguous.address241 = getelementptr i8, ptr %1209, i64 %1213
  %private.contiguous.load242 = load <8 x float>, ptr %private.contiguous.address241, align 4
  %1214 = select <8 x i1> %57, <8 x float> %private.contiguous.load242, <8 x float> zeroinitializer
  %.state243 = load <8 x float>, ptr %.slot40, align 32
  %1215 = fadd <8 x float> %.state243, %1214
  %.state244 = load <8 x i64>, ptr %.slot37, align 64
  %1216 = add <8 x i64> %.state244, splat (i64 3)
  %tile_snapshot.spill.load245 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1217 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load245, 0
  %1218 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load245, 1
  %1219 = mul <8 x i64> %1216, splat (i64 32)
  %1220 = add <8 x i64> %1218, %1219
  %1221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1217, 0
  %1222 = insertvalue { <8 x ptr>, <8 x i64> } %1221, <8 x i64> %1220, 1
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1224 = extractvalue { <8 x ptr>, <8 x i64> } %1222, 1
  %1225 = extractelement <8 x ptr> %1223, i32 0
  %1226 = extractelement <8 x i64> %1224, i32 0
  %1227 = sub i64 %1226, 0
  %1228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1229 = select i1 %1228, i64 %1227, i64 0
  %private.contiguous.address246 = getelementptr i8, ptr %1225, i64 %1229
  %private.contiguous.load247 = load <8 x float>, ptr %private.contiguous.address246, align 4
  %1230 = select <8 x i1> %57, <8 x float> %private.contiguous.load247, <8 x float> zeroinitializer
  %.state248 = load <8 x float>, ptr %.slot41, align 32
  %1231 = fadd <8 x float> %.state248, %1230
  %.state249 = load <8 x i64>, ptr %.slot37, align 64
  %1232 = add <8 x i64> %.state249, splat (i64 4)
  %1233 = load <8 x i64>, ptr %.slot37, align 64
  %1234 = select <8 x i1> %57, <8 x i64> %1232, <8 x i64> %1233
  store <8 x i64> %1234, ptr %.slot37, align 64
  %1235 = load <8 x float>, ptr %.slot38, align 32
  %1236 = select <8 x i1> %57, <8 x float> %1183, <8 x float> %1235
  store <8 x float> %1236, ptr %.slot38, align 32
  %1237 = load <8 x float>, ptr %.slot39, align 32
  %1238 = select <8 x i1> %57, <8 x float> %1199, <8 x float> %1237
  store <8 x float> %1238, ptr %.slot39, align 32
  %1239 = load <8 x float>, ptr %.slot40, align 32
  %1240 = select <8 x i1> %57, <8 x float> %1215, <8 x float> %1239
  store <8 x float> %1240, ptr %.slot40, align 32
  %1241 = load <8 x float>, ptr %.slot41, align 32
  %1242 = select <8 x i1> %57, <8 x float> %1231, <8 x float> %1241
  store <8 x float> %1242, ptr %.slot41, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false228
  %.spill.load250 = load <8 x i1>, ptr %.spill14, align 1
  %1243 = and <8 x i1> %57, %.spill.load250
  %1244 = xor <8 x i1> %.spill.load250, splat (i1 true)
  %1245 = and <8 x i1> %57, %1244
  %1246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1243)
  %1247 = bitcast <8 x i1> %1243 to i8
  %1248 = call i8 @llvm.cttz.i8(i8 %1247, i1 false)
  %1249 = zext i8 %1248 to i32
  %1250 = select i1 %1246, i32 %1249, i32 0
  %tile_snapshot.spill.load251 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 0
  %1252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 1
  %1253 = add <8 x i64> %1252, splat (i64 256)
  %1254 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1251, 0
  %1255 = insertvalue { <8 x ptr>, <8 x i64> } %1254, <8 x i64> %1253, 1
  %1256 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1257 = extractvalue { <8 x ptr>, <8 x i64> } %1255, 1
  %1258 = extractelement <8 x ptr> %1256, i32 0
  %1259 = extractelement <8 x i64> %1257, i32 %1250
  %1260 = zext i32 %1250 to i64
  %1261 = mul i64 %1260, 4
  %1262 = sub i64 %1259, %1261
  %1263 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1243)
  %1264 = select i1 %1263, i64 %1262, i64 0
  %private.contiguous.address252 = getelementptr i8, ptr %1258, i64 %1264
  %private.contiguous.load253 = load <8 x float>, ptr %private.contiguous.address252, align 4
  %1265 = select <8 x i1> %1243, <8 x float> %private.contiguous.load253, <8 x float> zeroinitializer
  %.state254 = load <8 x float>, ptr %.slot38, align 32
  %1266 = fadd <8 x float> %.state254, %1265
  %1267 = load <8 x float>, ptr %.slot42, align 32
  %1268 = select <8 x i1> %1243, <8 x float> %1266, <8 x float> %1267
  store <8 x float> %1268, ptr %.slot42, align 32
  %1269 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1245)
  %1270 = bitcast <8 x i1> %1245 to i8
  %1271 = call i8 @llvm.cttz.i8(i8 %1270, i1 false)
  %1272 = zext i8 %1271 to i32
  %1273 = select i1 %1269, i32 %1272, i32 0
  %.state255 = load <8 x float>, ptr %.slot38, align 32
  %1274 = load <8 x float>, ptr %.slot42, align 32
  %1275 = select <8 x i1> %1245, <8 x float> %.state255, <8 x float> %1274
  store <8 x float> %1275, ptr %.slot42, align 32
  br label %direct.schedule.35

direct.schedule.35:                               ; preds = %direct.schedule.33
  %.state256 = load <8 x float>, ptr %.slot42, align 32
  %.state257 = load <8 x float>, ptr %.slot39, align 32
  %1276 = fadd <8 x float> %.state256, %.state257
  %.state258 = load <8 x float>, ptr %.slot40, align 32
  %1277 = fadd <8 x float> %1276, %.state258
  %.state259 = load <8 x float>, ptr %.slot41, align 32
  %1278 = fadd <8 x float> %1277, %.state259
  %.spill.load260 = load <8 x i32>, ptr %.spill30, align 32
  %1279 = extractelement <8 x i32> %.spill.load260, i64 0
  %1280 = icmp ult i32 %1279, 8
  %1281 = select i1 %1280, i32 %1279, i32 0
  %1282 = extractelement <8 x i1> %57, i32 %1281
  %1283 = extractelement <8 x i1> %57, i64 0
  %1284 = and i1 %1280, %1282
  %1285 = and i1 %1283, %1284
  %1286 = extractelement <8 x float> %1278, i32 %1281
  %1287 = select i1 %1285, float %1286, float 0.000000e+00
  %1288 = insertelement <8 x float> poison, float %1287, i64 0
  %1289 = xor i1 %1285, true
  %1290 = and i1 %1283, %1289
  %1291 = insertelement <8 x i1> poison, i1 %1290, i64 0
  %1292 = extractelement <8 x i32> %.spill.load260, i64 1
  %1293 = icmp ult i32 %1292, 8
  %1294 = select i1 %1293, i32 %1292, i32 0
  %1295 = extractelement <8 x i1> %57, i32 %1294
  %1296 = extractelement <8 x i1> %57, i64 1
  %1297 = and i1 %1293, %1295
  %1298 = and i1 %1296, %1297
  %1299 = extractelement <8 x float> %1278, i32 %1294
  %1300 = select i1 %1298, float %1299, float 0.000000e+00
  %1301 = insertelement <8 x float> %1288, float %1300, i64 1
  %1302 = xor i1 %1298, true
  %1303 = and i1 %1296, %1302
  %1304 = insertelement <8 x i1> %1291, i1 %1303, i64 1
  %1305 = extractelement <8 x i32> %.spill.load260, i64 2
  %1306 = icmp ult i32 %1305, 8
  %1307 = select i1 %1306, i32 %1305, i32 0
  %1308 = extractelement <8 x i1> %57, i32 %1307
  %1309 = extractelement <8 x i1> %57, i64 2
  %1310 = and i1 %1306, %1308
  %1311 = and i1 %1309, %1310
  %1312 = extractelement <8 x float> %1278, i32 %1307
  %1313 = select i1 %1311, float %1312, float 0.000000e+00
  %1314 = insertelement <8 x float> %1301, float %1313, i64 2
  %1315 = xor i1 %1311, true
  %1316 = and i1 %1309, %1315
  %1317 = insertelement <8 x i1> %1304, i1 %1316, i64 2
  %1318 = extractelement <8 x i32> %.spill.load260, i64 3
  %1319 = icmp ult i32 %1318, 8
  %1320 = select i1 %1319, i32 %1318, i32 0
  %1321 = extractelement <8 x i1> %57, i32 %1320
  %1322 = extractelement <8 x i1> %57, i64 3
  %1323 = and i1 %1319, %1321
  %1324 = and i1 %1322, %1323
  %1325 = extractelement <8 x float> %1278, i32 %1320
  %1326 = select i1 %1324, float %1325, float 0.000000e+00
  %1327 = insertelement <8 x float> %1314, float %1326, i64 3
  %1328 = xor i1 %1324, true
  %1329 = and i1 %1322, %1328
  %1330 = insertelement <8 x i1> %1317, i1 %1329, i64 3
  %1331 = extractelement <8 x i32> %.spill.load260, i64 4
  %1332 = icmp ult i32 %1331, 8
  %1333 = select i1 %1332, i32 %1331, i32 0
  %1334 = extractelement <8 x i1> %57, i32 %1333
  %1335 = extractelement <8 x i1> %57, i64 4
  %1336 = and i1 %1332, %1334
  %1337 = and i1 %1335, %1336
  %1338 = extractelement <8 x float> %1278, i32 %1333
  %1339 = select i1 %1337, float %1338, float 0.000000e+00
  %1340 = insertelement <8 x float> %1327, float %1339, i64 4
  %1341 = xor i1 %1337, true
  %1342 = and i1 %1335, %1341
  %1343 = insertelement <8 x i1> %1330, i1 %1342, i64 4
  %1344 = extractelement <8 x i32> %.spill.load260, i64 5
  %1345 = icmp ult i32 %1344, 8
  %1346 = select i1 %1345, i32 %1344, i32 0
  %1347 = extractelement <8 x i1> %57, i32 %1346
  %1348 = extractelement <8 x i1> %57, i64 5
  %1349 = and i1 %1345, %1347
  %1350 = and i1 %1348, %1349
  %1351 = extractelement <8 x float> %1278, i32 %1346
  %1352 = select i1 %1350, float %1351, float 0.000000e+00
  %1353 = insertelement <8 x float> %1340, float %1352, i64 5
  %1354 = xor i1 %1350, true
  %1355 = and i1 %1348, %1354
  %1356 = insertelement <8 x i1> %1343, i1 %1355, i64 5
  %1357 = extractelement <8 x i32> %.spill.load260, i64 6
  %1358 = icmp ult i32 %1357, 8
  %1359 = select i1 %1358, i32 %1357, i32 0
  %1360 = extractelement <8 x i1> %57, i32 %1359
  %1361 = extractelement <8 x i1> %57, i64 6
  %1362 = and i1 %1358, %1360
  %1363 = and i1 %1361, %1362
  %1364 = extractelement <8 x float> %1278, i32 %1359
  %1365 = select i1 %1363, float %1364, float 0.000000e+00
  %1366 = insertelement <8 x float> %1353, float %1365, i64 6
  %1367 = xor i1 %1363, true
  %1368 = and i1 %1361, %1367
  %1369 = insertelement <8 x i1> %1356, i1 %1368, i64 6
  %1370 = extractelement <8 x i32> %.spill.load260, i64 7
  %1371 = icmp ult i32 %1370, 8
  %1372 = select i1 %1371, i32 %1370, i32 0
  %1373 = extractelement <8 x i1> %57, i32 %1372
  %1374 = extractelement <8 x i1> %57, i64 7
  %1375 = and i1 %1371, %1373
  %1376 = and i1 %1374, %1375
  %1377 = extractelement <8 x float> %1278, i32 %1372
  %1378 = select i1 %1376, float %1377, float 0.000000e+00
  %1379 = insertelement <8 x float> %1366, float %1378, i64 7
  %1380 = xor i1 %1376, true
  %1381 = and i1 %1374, %1380
  %1382 = insertelement <8 x i1> %1369, i1 %1381, i64 7
  %1383 = fadd <8 x float> %1278, %1379
  %.spill.load261 = load <8 x i32>, ptr %.spill31, align 32
  %1384 = extractelement <8 x i32> %.spill.load261, i64 0
  %1385 = icmp ult i32 %1384, 8
  %1386 = select i1 %1385, i32 %1384, i32 0
  %1387 = extractelement <8 x i1> %57, i32 %1386
  %1388 = extractelement <8 x i1> %57, i64 0
  %1389 = and i1 %1385, %1387
  %1390 = and i1 %1388, %1389
  %1391 = extractelement <8 x float> %1383, i32 %1386
  %1392 = select i1 %1390, float %1391, float 0.000000e+00
  %1393 = insertelement <8 x float> poison, float %1392, i64 0
  %1394 = xor i1 %1390, true
  %1395 = and i1 %1388, %1394
  %1396 = insertelement <8 x i1> poison, i1 %1395, i64 0
  %1397 = extractelement <8 x i32> %.spill.load261, i64 1
  %1398 = icmp ult i32 %1397, 8
  %1399 = select i1 %1398, i32 %1397, i32 0
  %1400 = extractelement <8 x i1> %57, i32 %1399
  %1401 = extractelement <8 x i1> %57, i64 1
  %1402 = and i1 %1398, %1400
  %1403 = and i1 %1401, %1402
  %1404 = extractelement <8 x float> %1383, i32 %1399
  %1405 = select i1 %1403, float %1404, float 0.000000e+00
  %1406 = insertelement <8 x float> %1393, float %1405, i64 1
  %1407 = xor i1 %1403, true
  %1408 = and i1 %1401, %1407
  %1409 = insertelement <8 x i1> %1396, i1 %1408, i64 1
  %1410 = extractelement <8 x i32> %.spill.load261, i64 2
  %1411 = icmp ult i32 %1410, 8
  %1412 = select i1 %1411, i32 %1410, i32 0
  %1413 = extractelement <8 x i1> %57, i32 %1412
  %1414 = extractelement <8 x i1> %57, i64 2
  %1415 = and i1 %1411, %1413
  %1416 = and i1 %1414, %1415
  %1417 = extractelement <8 x float> %1383, i32 %1412
  %1418 = select i1 %1416, float %1417, float 0.000000e+00
  %1419 = insertelement <8 x float> %1406, float %1418, i64 2
  %1420 = xor i1 %1416, true
  %1421 = and i1 %1414, %1420
  %1422 = insertelement <8 x i1> %1409, i1 %1421, i64 2
  %1423 = extractelement <8 x i32> %.spill.load261, i64 3
  %1424 = icmp ult i32 %1423, 8
  %1425 = select i1 %1424, i32 %1423, i32 0
  %1426 = extractelement <8 x i1> %57, i32 %1425
  %1427 = extractelement <8 x i1> %57, i64 3
  %1428 = and i1 %1424, %1426
  %1429 = and i1 %1427, %1428
  %1430 = extractelement <8 x float> %1383, i32 %1425
  %1431 = select i1 %1429, float %1430, float 0.000000e+00
  %1432 = insertelement <8 x float> %1419, float %1431, i64 3
  %1433 = xor i1 %1429, true
  %1434 = and i1 %1427, %1433
  %1435 = insertelement <8 x i1> %1422, i1 %1434, i64 3
  %1436 = extractelement <8 x i32> %.spill.load261, i64 4
  %1437 = icmp ult i32 %1436, 8
  %1438 = select i1 %1437, i32 %1436, i32 0
  %1439 = extractelement <8 x i1> %57, i32 %1438
  %1440 = extractelement <8 x i1> %57, i64 4
  %1441 = and i1 %1437, %1439
  %1442 = and i1 %1440, %1441
  %1443 = extractelement <8 x float> %1383, i32 %1438
  %1444 = select i1 %1442, float %1443, float 0.000000e+00
  %1445 = insertelement <8 x float> %1432, float %1444, i64 4
  %1446 = xor i1 %1442, true
  %1447 = and i1 %1440, %1446
  %1448 = insertelement <8 x i1> %1435, i1 %1447, i64 4
  %1449 = extractelement <8 x i32> %.spill.load261, i64 5
  %1450 = icmp ult i32 %1449, 8
  %1451 = select i1 %1450, i32 %1449, i32 0
  %1452 = extractelement <8 x i1> %57, i32 %1451
  %1453 = extractelement <8 x i1> %57, i64 5
  %1454 = and i1 %1450, %1452
  %1455 = and i1 %1453, %1454
  %1456 = extractelement <8 x float> %1383, i32 %1451
  %1457 = select i1 %1455, float %1456, float 0.000000e+00
  %1458 = insertelement <8 x float> %1445, float %1457, i64 5
  %1459 = xor i1 %1455, true
  %1460 = and i1 %1453, %1459
  %1461 = insertelement <8 x i1> %1448, i1 %1460, i64 5
  %1462 = extractelement <8 x i32> %.spill.load261, i64 6
  %1463 = icmp ult i32 %1462, 8
  %1464 = select i1 %1463, i32 %1462, i32 0
  %1465 = extractelement <8 x i1> %57, i32 %1464
  %1466 = extractelement <8 x i1> %57, i64 6
  %1467 = and i1 %1463, %1465
  %1468 = and i1 %1466, %1467
  %1469 = extractelement <8 x float> %1383, i32 %1464
  %1470 = select i1 %1468, float %1469, float 0.000000e+00
  %1471 = insertelement <8 x float> %1458, float %1470, i64 6
  %1472 = xor i1 %1468, true
  %1473 = and i1 %1466, %1472
  %1474 = insertelement <8 x i1> %1461, i1 %1473, i64 6
  %1475 = extractelement <8 x i32> %.spill.load261, i64 7
  %1476 = icmp ult i32 %1475, 8
  %1477 = select i1 %1476, i32 %1475, i32 0
  %1478 = extractelement <8 x i1> %57, i32 %1477
  %1479 = extractelement <8 x i1> %57, i64 7
  %1480 = and i1 %1476, %1478
  %1481 = and i1 %1479, %1480
  %1482 = extractelement <8 x float> %1383, i32 %1477
  %1483 = select i1 %1481, float %1482, float 0.000000e+00
  %1484 = insertelement <8 x float> %1471, float %1483, i64 7
  %1485 = xor i1 %1481, true
  %1486 = and i1 %1479, %1485
  %1487 = insertelement <8 x i1> %1474, i1 %1486, i64 7
  %1488 = fadd <8 x float> %1383, %1484
  %.spill.load262 = load <8 x i32>, ptr %.spill32, align 32
  %1489 = extractelement <8 x i32> %.spill.load262, i64 0
  %1490 = icmp ult i32 %1489, 8
  %1491 = select i1 %1490, i32 %1489, i32 0
  %1492 = extractelement <8 x i1> %57, i32 %1491
  %1493 = extractelement <8 x i1> %57, i64 0
  %1494 = and i1 %1490, %1492
  %1495 = and i1 %1493, %1494
  %1496 = extractelement <8 x float> %1488, i32 %1491
  %1497 = select i1 %1495, float %1496, float 0.000000e+00
  %1498 = insertelement <8 x float> poison, float %1497, i64 0
  %1499 = xor i1 %1495, true
  %1500 = and i1 %1493, %1499
  %1501 = insertelement <8 x i1> poison, i1 %1500, i64 0
  %1502 = extractelement <8 x i32> %.spill.load262, i64 1
  %1503 = icmp ult i32 %1502, 8
  %1504 = select i1 %1503, i32 %1502, i32 0
  %1505 = extractelement <8 x i1> %57, i32 %1504
  %1506 = extractelement <8 x i1> %57, i64 1
  %1507 = and i1 %1503, %1505
  %1508 = and i1 %1506, %1507
  %1509 = extractelement <8 x float> %1488, i32 %1504
  %1510 = select i1 %1508, float %1509, float 0.000000e+00
  %1511 = insertelement <8 x float> %1498, float %1510, i64 1
  %1512 = xor i1 %1508, true
  %1513 = and i1 %1506, %1512
  %1514 = insertelement <8 x i1> %1501, i1 %1513, i64 1
  %1515 = extractelement <8 x i32> %.spill.load262, i64 2
  %1516 = icmp ult i32 %1515, 8
  %1517 = select i1 %1516, i32 %1515, i32 0
  %1518 = extractelement <8 x i1> %57, i32 %1517
  %1519 = extractelement <8 x i1> %57, i64 2
  %1520 = and i1 %1516, %1518
  %1521 = and i1 %1519, %1520
  %1522 = extractelement <8 x float> %1488, i32 %1517
  %1523 = select i1 %1521, float %1522, float 0.000000e+00
  %1524 = insertelement <8 x float> %1511, float %1523, i64 2
  %1525 = xor i1 %1521, true
  %1526 = and i1 %1519, %1525
  %1527 = insertelement <8 x i1> %1514, i1 %1526, i64 2
  %1528 = extractelement <8 x i32> %.spill.load262, i64 3
  %1529 = icmp ult i32 %1528, 8
  %1530 = select i1 %1529, i32 %1528, i32 0
  %1531 = extractelement <8 x i1> %57, i32 %1530
  %1532 = extractelement <8 x i1> %57, i64 3
  %1533 = and i1 %1529, %1531
  %1534 = and i1 %1532, %1533
  %1535 = extractelement <8 x float> %1488, i32 %1530
  %1536 = select i1 %1534, float %1535, float 0.000000e+00
  %1537 = insertelement <8 x float> %1524, float %1536, i64 3
  %1538 = xor i1 %1534, true
  %1539 = and i1 %1532, %1538
  %1540 = insertelement <8 x i1> %1527, i1 %1539, i64 3
  %1541 = extractelement <8 x i32> %.spill.load262, i64 4
  %1542 = icmp ult i32 %1541, 8
  %1543 = select i1 %1542, i32 %1541, i32 0
  %1544 = extractelement <8 x i1> %57, i32 %1543
  %1545 = extractelement <8 x i1> %57, i64 4
  %1546 = and i1 %1542, %1544
  %1547 = and i1 %1545, %1546
  %1548 = extractelement <8 x float> %1488, i32 %1543
  %1549 = select i1 %1547, float %1548, float 0.000000e+00
  %1550 = insertelement <8 x float> %1537, float %1549, i64 4
  %1551 = xor i1 %1547, true
  %1552 = and i1 %1545, %1551
  %1553 = insertelement <8 x i1> %1540, i1 %1552, i64 4
  %1554 = extractelement <8 x i32> %.spill.load262, i64 5
  %1555 = icmp ult i32 %1554, 8
  %1556 = select i1 %1555, i32 %1554, i32 0
  %1557 = extractelement <8 x i1> %57, i32 %1556
  %1558 = extractelement <8 x i1> %57, i64 5
  %1559 = and i1 %1555, %1557
  %1560 = and i1 %1558, %1559
  %1561 = extractelement <8 x float> %1488, i32 %1556
  %1562 = select i1 %1560, float %1561, float 0.000000e+00
  %1563 = insertelement <8 x float> %1550, float %1562, i64 5
  %1564 = xor i1 %1560, true
  %1565 = and i1 %1558, %1564
  %1566 = insertelement <8 x i1> %1553, i1 %1565, i64 5
  %1567 = extractelement <8 x i32> %.spill.load262, i64 6
  %1568 = icmp ult i32 %1567, 8
  %1569 = select i1 %1568, i32 %1567, i32 0
  %1570 = extractelement <8 x i1> %57, i32 %1569
  %1571 = extractelement <8 x i1> %57, i64 6
  %1572 = and i1 %1568, %1570
  %1573 = and i1 %1571, %1572
  %1574 = extractelement <8 x float> %1488, i32 %1569
  %1575 = select i1 %1573, float %1574, float 0.000000e+00
  %1576 = insertelement <8 x float> %1563, float %1575, i64 6
  %1577 = xor i1 %1573, true
  %1578 = and i1 %1571, %1577
  %1579 = insertelement <8 x i1> %1566, i1 %1578, i64 6
  %1580 = extractelement <8 x i32> %.spill.load262, i64 7
  %1581 = icmp ult i32 %1580, 8
  %1582 = select i1 %1581, i32 %1580, i32 0
  %1583 = extractelement <8 x i1> %57, i32 %1582
  %1584 = extractelement <8 x i1> %57, i64 7
  %1585 = and i1 %1581, %1583
  %1586 = and i1 %1584, %1585
  %1587 = extractelement <8 x float> %1488, i32 %1582
  %1588 = select i1 %1586, float %1587, float 0.000000e+00
  %1589 = insertelement <8 x float> %1576, float %1588, i64 7
  %1590 = xor i1 %1586, true
  %1591 = and i1 %1584, %1590
  %1592 = insertelement <8 x i1> %1579, i1 %1591, i64 7
  %1593 = fadd <8 x float> %1488, %1589
  %1594 = extractelement <8 x i1> %57, i32 0
  %1595 = extractelement <8 x i1> %57, i64 0
  %1596 = and i1 true, %1594
  %1597 = and i1 %1595, %1596
  %1598 = extractelement <8 x float> %1593, i32 0
  %1599 = select i1 %1597, float %1598, float 0.000000e+00
  %1600 = insertelement <8 x float> poison, float %1599, i64 0
  %1601 = xor i1 %1597, true
  %1602 = and i1 %1595, %1601
  %1603 = insertelement <8 x i1> poison, i1 %1602, i64 0
  %1604 = extractelement <8 x i1> %57, i32 0
  %1605 = extractelement <8 x i1> %57, i64 1
  %1606 = and i1 true, %1604
  %1607 = and i1 %1605, %1606
  %1608 = extractelement <8 x float> %1593, i32 0
  %1609 = select i1 %1607, float %1608, float 0.000000e+00
  %1610 = insertelement <8 x float> %1600, float %1609, i64 1
  %1611 = xor i1 %1607, true
  %1612 = and i1 %1605, %1611
  %1613 = insertelement <8 x i1> %1603, i1 %1612, i64 1
  %1614 = extractelement <8 x i1> %57, i32 0
  %1615 = extractelement <8 x i1> %57, i64 2
  %1616 = and i1 true, %1614
  %1617 = and i1 %1615, %1616
  %1618 = extractelement <8 x float> %1593, i32 0
  %1619 = select i1 %1617, float %1618, float 0.000000e+00
  %1620 = insertelement <8 x float> %1610, float %1619, i64 2
  %1621 = xor i1 %1617, true
  %1622 = and i1 %1615, %1621
  %1623 = insertelement <8 x i1> %1613, i1 %1622, i64 2
  %1624 = extractelement <8 x i1> %57, i32 0
  %1625 = extractelement <8 x i1> %57, i64 3
  %1626 = and i1 true, %1624
  %1627 = and i1 %1625, %1626
  %1628 = extractelement <8 x float> %1593, i32 0
  %1629 = select i1 %1627, float %1628, float 0.000000e+00
  %1630 = insertelement <8 x float> %1620, float %1629, i64 3
  %1631 = xor i1 %1627, true
  %1632 = and i1 %1625, %1631
  %1633 = insertelement <8 x i1> %1623, i1 %1632, i64 3
  %1634 = extractelement <8 x i1> %57, i32 0
  %1635 = extractelement <8 x i1> %57, i64 4
  %1636 = and i1 true, %1634
  %1637 = and i1 %1635, %1636
  %1638 = extractelement <8 x float> %1593, i32 0
  %1639 = select i1 %1637, float %1638, float 0.000000e+00
  %1640 = insertelement <8 x float> %1630, float %1639, i64 4
  %1641 = xor i1 %1637, true
  %1642 = and i1 %1635, %1641
  %1643 = insertelement <8 x i1> %1633, i1 %1642, i64 4
  %1644 = extractelement <8 x i1> %57, i32 0
  %1645 = extractelement <8 x i1> %57, i64 5
  %1646 = and i1 true, %1644
  %1647 = and i1 %1645, %1646
  %1648 = extractelement <8 x float> %1593, i32 0
  %1649 = select i1 %1647, float %1648, float 0.000000e+00
  %1650 = insertelement <8 x float> %1640, float %1649, i64 5
  %1651 = xor i1 %1647, true
  %1652 = and i1 %1645, %1651
  %1653 = insertelement <8 x i1> %1643, i1 %1652, i64 5
  %1654 = extractelement <8 x i1> %57, i32 0
  %1655 = extractelement <8 x i1> %57, i64 6
  %1656 = and i1 true, %1654
  %1657 = and i1 %1655, %1656
  %1658 = extractelement <8 x float> %1593, i32 0
  %1659 = select i1 %1657, float %1658, float 0.000000e+00
  %1660 = insertelement <8 x float> %1650, float %1659, i64 6
  %1661 = xor i1 %1657, true
  %1662 = and i1 %1655, %1661
  %1663 = insertelement <8 x i1> %1653, i1 %1662, i64 6
  %1664 = extractelement <8 x i1> %57, i32 0
  %1665 = extractelement <8 x i1> %57, i64 7
  %1666 = and i1 true, %1664
  %1667 = and i1 %1665, %1666
  %1668 = extractelement <8 x float> %1593, i32 0
  %1669 = select i1 %1667, float %1668, float 0.000000e+00
  %1670 = insertelement <8 x float> %1660, float %1669, i64 7
  %1671 = xor i1 %1667, true
  %1672 = and i1 %1665, %1671
  %1673 = insertelement <8 x i1> %1663, i1 %1672, i64 7
  %1674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1675 = bitcast <8 x i1> %57 to i8
  %1676 = call i8 @llvm.cttz.i8(i8 %1675, i1 false)
  %1677 = zext i8 %1676 to i32
  %1678 = select i1 %1674, i32 %1677, i32 0
  %1679 = extractelement <8 x float> %1670, i32 %1678
  %.spill.load263 = load float, ptr %.spill34, align 4
  %1680 = fadd float %.spill.load263, %1679
  store float %1680, ptr %.spill43, align 4
  br label %direct.schedule.36

direct.schedule.36:                               ; preds = %direct.schedule.35
  %1681 = load <8 x i64>, ptr %.slot44, align 64
  %1682 = select <8 x i1> %57, <8 x i64> zeroinitializer, <8 x i64> %1681
  store <8 x i64> %1682, ptr %.slot44, align 64
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state264 = load <8 x i64>, ptr %.slot44, align 64
  %1683 = icmp slt <8 x i64> %.state264, splat (i64 8)
  %1684 = extractelement <8 x i1> %1683, i32 0
  br i1 %1684, label %direct.true265, label %direct.false266

direct.schedule.38:                               ; preds = %direct.true265
  %.state267 = load <8 x i64>, ptr %.slot44, align 64
  %1685 = mul <8 x i64> %.state267, splat (i64 8)
  %.spill.load268 = load <8 x i64>, ptr %.spill, align 64
  %1686 = add <8 x i64> %1685, %.spill.load268
  %tile_snapshot.spill.load269 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load269, 0
  %1688 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load269, 1
  %.state270 = load <8 x i64>, ptr %.slot44, align 64
  %1689 = mul <8 x i64> %.state270, splat (i64 32)
  %1690 = add <8 x i64> %1688, %1689
  %1691 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1687, 0
  %1692 = insertvalue { <8 x ptr>, <8 x i64> } %1691, <8 x i64> %1690, 1
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1694 = extractvalue { <8 x ptr>, <8 x i64> } %1692, 1
  %1695 = extractelement <8 x ptr> %1693, i32 0
  %1696 = extractelement <8 x i64> %1694, i32 0
  %1697 = sub i64 %1696, 0
  %1698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1699 = select i1 %1698, i64 %1697, i64 0
  %private.contiguous.address271 = getelementptr i8, ptr %1695, i64 %1699
  %private.contiguous.load272 = load <8 x float>, ptr %private.contiguous.address271, align 4
  %1700 = select <8 x i1> %57, <8 x float> %private.contiguous.load272, <8 x float> zeroinitializer
  %.spill.load273 = load float, ptr %.spill43, align 4
  %.splatinsert274 = insertelement <8 x float> poison, float %.spill.load273, i64 0
  %.splat275 = shufflevector <8 x float> %.splatinsert274, <8 x float> poison, <8 x i32> zeroinitializer
  %1701 = fdiv <8 x float> %1700, %.splat275
  %.spill.load276 = load <8 x i64>, ptr %.spill13, align 64
  %1702 = add <8 x i64> %.spill.load276, zeroinitializer
  %1703 = add <8 x i64> zeroinitializer, %1702
  %1704 = add <8 x i64> zeroinitializer, %1686
  %1705 = mul <8 x i64> %1703, splat (i64 65)
  %1706 = add <8 x i64> %1705, %1704
  %1707 = extractvalue { ptr, i64 } %33, 0
  %1708 = extractelement <8 x i64> %1706, i32 0
  %1709 = sub i64 %1708, 0
  %1710 = mul i64 %1709, 4
  %buffer.contiguous.address277 = getelementptr i8, ptr %1707, i64 %1710
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1701, ptr %buffer.contiguous.address277, i32 1, <8 x i1> %57)
  %.state278 = load <8 x i64>, ptr %.slot44, align 64
  %1711 = add <8 x i64> %.state278, splat (i64 1)
  %1712 = load <8 x i64>, ptr %.slot44, align 64
  %1713 = select <8 x i1> %57, <8 x i64> %1711, <8 x i64> %1712
  store <8 x i64> %1713, ptr %.slot44, align 64
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false266
  %.spill.load279 = load <8 x i1>, ptr %.spill14, align 1
  %1714 = and <8 x i1> %57, %.spill.load279
  %1715 = xor <8 x i1> %.spill.load279, splat (i1 true)
  %1716 = and <8 x i1> %57, %1715
  %1717 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1714)
  %1718 = bitcast <8 x i1> %1714 to i8
  %1719 = call i8 @llvm.cttz.i8(i8 %1718, i1 false)
  %1720 = zext i8 %1719 to i32
  %1721 = select i1 %1717, i32 %1720, i32 0
  %.spill.load280 = load <8 x i64>, ptr %.spill, align 64
  %1722 = add <8 x i64> splat (i64 64), %.spill.load280
  %tile_snapshot.spill.load281 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1723 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %1724 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %1725 = add <8 x i64> %1724, splat (i64 256)
  %1726 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1723, 0
  %1727 = insertvalue { <8 x ptr>, <8 x i64> } %1726, <8 x i64> %1725, 1
  %1728 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1729 = extractvalue { <8 x ptr>, <8 x i64> } %1727, 1
  %1730 = extractelement <8 x ptr> %1728, i32 0
  %1731 = extractelement <8 x i64> %1729, i32 %1721
  %1732 = zext i32 %1721 to i64
  %1733 = mul i64 %1732, 4
  %1734 = sub i64 %1731, %1733
  %1735 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1714)
  %1736 = select i1 %1735, i64 %1734, i64 0
  %private.contiguous.address282 = getelementptr i8, ptr %1730, i64 %1736
  %private.contiguous.load283 = load <8 x float>, ptr %private.contiguous.address282, align 4
  %1737 = select <8 x i1> %1714, <8 x float> %private.contiguous.load283, <8 x float> zeroinitializer
  %.spill.load284 = load float, ptr %.spill43, align 4
  %.splatinsert285 = insertelement <8 x float> poison, float %.spill.load284, i64 0
  %.splat286 = shufflevector <8 x float> %.splatinsert285, <8 x float> poison, <8 x i32> zeroinitializer
  %1738 = fdiv <8 x float> %1737, %.splat286
  %.spill.load287 = load <8 x i64>, ptr %.spill13, align 64
  %1739 = add <8 x i64> %.spill.load287, zeroinitializer
  %1740 = add <8 x i64> zeroinitializer, %1739
  %1741 = add <8 x i64> zeroinitializer, %1722
  %1742 = mul <8 x i64> %1740, splat (i64 65)
  %1743 = add <8 x i64> %1742, %1741
  %1744 = extractvalue { ptr, i64 } %33, 0
  %1745 = extractelement <8 x i64> %1743, i32 %1721
  %1746 = zext i32 %1721 to i64
  %1747 = sub i64 %1745, %1746
  %1748 = mul i64 %1747, 4
  %buffer.contiguous.address288 = getelementptr i8, ptr %1744, i64 %1748
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1738, ptr %buffer.contiguous.address288, i32 1, <8 x i1> %1714)
  %1749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1716)
  %1750 = bitcast <8 x i1> %1716 to i8
  %1751 = call i8 @llvm.cttz.i8(i8 %1750, i1 false)
  %1752 = zext i8 %1751 to i32
  %1753 = select i1 %1749, i32 %1752, i32 0
  br label %direct.schedule.41

direct.schedule.41:                               ; preds = %direct.schedule.39
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true72:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false73:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true88:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false89:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true104:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false105:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true144:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false145:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.23

direct.true180:                                   ; preds = %direct.schedule.26
  br label %direct.schedule.27

direct.false181:                                  ; preds = %direct.schedule.26
  br label %direct.schedule.28

direct.true227:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false228:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true265:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false266:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #4 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

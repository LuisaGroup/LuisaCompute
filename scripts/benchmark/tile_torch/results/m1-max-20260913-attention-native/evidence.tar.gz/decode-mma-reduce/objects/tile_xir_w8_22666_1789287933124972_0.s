	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_4:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_5:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	dup.4s	v2, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v2, v4
	cmhi.4s	v1, v2, v3
	uzp1.8h	v17, v1, v0
	umaxv.8h	h5, v17
	fmov	w8, s5
	tbz	w8, #0, LBB0_122
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2240
	mov	x9, #0                          ; =0x0
	ldr	x10, [x1, #136]
	add	x8, x10, #2560
	mov	w11, #5632                      ; =0x1600
	add	x11, x10, x11
	mov	w12, #8704                      ; =0x2200
	add	x12, x10, x12
	mov	w13, #49664                     ; =0xc200
	add	x13, x10, x13
	add	x14, x10, #24, lsl #12          ; =98304
	add	x14, x14, #512
	add	x15, x10, #24, lsl #12          ; =98304
	add	x15, x15, #1536
	ldr	x2, [x0]
	ldr	x16, [x0, #16]
	ldr	w17, [x1]
	ldr	w1, [x1, #36]
	add	w1, w1, w17, lsl #5
	ldr	x17, [x0, #32]
	ldr	x0, [x0, #48]
	str	x0, [sp, #80]                   ; 8-byte Spill
	dup.4s	v5, w1
	add.4s	v6, v5, v4
	add.4s	v5, v5, v3
	and.16b	v16, v1, v5
	and.16b	v7, v0, v6
	ushll2.2d	v22, v7, #0
	ushll2.2d	v23, v16, #0
	ushll.2d	v24, v7, #0
	ushll.2d	v25, v16, #0
	movi.4s	v6, #80
	umull2.2d	v5, v7, v6
	umull2.2d	v6, v16, v6
	movi.2s	v18, #80
	umull.2d	v7, v7, v18
	umull.2d	v16, v16, v18
Lloh4:
	adrp	x0, lCPI0_2@PAGE
Lloh5:
	ldr	q18, [x0, lCPI0_2@PAGEOFF]
	and.16b	v17, v17, v18
	addv.8h	h17, v17
	str	q17, [sp, #1936]                ; 16-byte Spill
	fmov	w0, s17
	dup.2d	v17, x2
	b	LBB0_3
LBB0_2:                                 ; %else192
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x10, x9, lsl #5
	ldp	q20, q21, [x1]
	bif.16b	v19, v21, v0
	bif.16b	v18, v20, v1
	stp	q18, q19, [x1]
	add	x9, x9, #1
	cmp	x9, #80
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v20, x9
	add.2d	v18, v20, v16
	shl.2d	v18, v18, #2
	add.2d	v21, v17, v18
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w0, #0, LBB0_11
; %bb.4:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x1, d21
	ldr	s18, [x1]
	and	w1, w0, #0xff
	tbnz	w1, #1, LBB0_12
LBB0_5:                                 ; %else174
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v21, v20, v6
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbz	w1, #2, LBB0_13
LBB0_6:                                 ; %cond.load176
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x2, d21
	ld1.s	{ v18 }[2], [x2]
	tbnz	w1, #3, LBB0_14
LBB0_7:                                 ; %else180
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v21, v20, v7
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbz	w1, #4, LBB0_15
LBB0_8:                                 ; %cond.load182
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x2, d21
	ld1.s	{ v19 }[0], [x2]
	tbnz	w1, #5, LBB0_16
LBB0_9:                                 ; %else186
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v20, v20, v5
	shl.2d	v20, v20, #2
	add.2d	v20, v17, v20
	tbz	w1, #6, LBB0_17
LBB0_10:                                ; %cond.load188
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x2, d20
	ld1.s	{ v19 }[2], [x2]
	tbz	w1, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w1, w0, #0xff
	tbz	w1, #1, LBB0_5
LBB0_12:                                ; %cond.load173
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x2, v21[1]
	ld1.s	{ v18 }[1], [x2]
	add.2d	v21, v20, v6
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbnz	w1, #2, LBB0_6
LBB0_13:                                ; %else177
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w1, #3, LBB0_7
LBB0_14:                                ; %cond.load179
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x2, v21[1]
	ld1.s	{ v18 }[3], [x2]
	add.2d	v21, v20, v7
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbnz	w1, #4, LBB0_8
LBB0_15:                                ; %else183
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w1, #5, LBB0_9
LBB0_16:                                ; %cond.load185
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x2, v21[1]
	ld1.s	{ v19 }[1], [x2]
	add.2d	v20, v20, v5
	shl.2d	v20, v20, #2
	add.2d	v20, v17, v20
	tbnz	w1, #6, LBB0_10
LBB0_17:                                ; %else189
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w1, #7, LBB0_2
LBB0_18:                                ; %cond.load191
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x1, v20[1]
	ld1.s	{ v19 }[3], [x1]
	b	LBB0_2
LBB0_19:                                ; %direct.true152.preheader
	mov	x9, #0                          ; =0x0
	cmhs.4s	v4, v4, v2
	cmhs.4s	v5, v3, v2
LBB0_20:                                ; %direct.true152
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, x8, x9
	ldp	q2, q3, [x0]
	and.16b	v3, v4, v3
	and.16b	v2, v5, v2
	stp	q2, q3, [x0]
	add	x9, x9, #32
	cmp	x9, #3072
	b.ne	LBB0_20
; %bb.21:                               ; %direct.false153
	str	q5, [sp, #1840]                 ; 16-byte Spill
	str	q4, [sp, #1888]                 ; 16-byte Spill
	mov	x0, #0                          ; =0x0
	sshll.2d	v2, v1, #0
	sshll.2d	v3, v0, #0
	sshll2.2d	v16, v1, #0
	sshll2.2d	v17, v0, #0
	stp	q25, q24, [sp, #16]             ; 32-byte Folded Spill
	ushr.2d	v4, v25, #2
	stp	q23, q22, [sp, #48]             ; 32-byte Folded Spill
	ushr.2d	v5, v23, #2
	ushr.2d	v6, v24, #2
	ushr.2d	v7, v22, #2
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q18, [x9, lCPI0_6@PAGEOFF]
	str	q18, [sp, #1216]                ; 16-byte Spill
	and.16b	v31, v2, v18
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v18, w9
	and.16b	v19, v0, v18
	str	q19, [sp, #1712]                ; 16-byte Spill
	mov.d	x9, v7[1]
	mov	w1, #2053                       ; =0x805
	mul	x9, x9, x1
	fmov	x2, d7
	mul	x2, x2, x1
	fmov	d7, x2
	mov.d	v7[1], x9
	mov.d	x9, v6[1]
	mul	x9, x9, x1
	fmov	x2, d6
	mul	x2, x2, x1
	fmov	d6, x2
	mov.d	v6[1], x9
	mov.d	x9, v5[1]
	mul	x9, x9, x1
	fmov	x2, d5
	mul	x2, x2, x1
	fmov	d5, x2
	mov.d	v5[1], x9
	mov.d	x9, v4[1]
	mul	x9, x9, x1
	fmov	x2, d4
	mul	x1, x2, x1
	fmov	d4, x1
	mov.d	v4[1], x9
	str	q18, [sp, #288]                 ; 16-byte Spill
	and.16b	v18, v1, v18
	str	q18, [sp, #1696]                ; 16-byte Spill
	and.16b	v2, v2, v4
	str	q2, [sp, #2128]                 ; 16-byte Spill
	str	q16, [sp, #1232]                ; 16-byte Spill
	and.16b	v2, v16, v5
	str	q2, [sp, #2112]                 ; 16-byte Spill
	and.16b	v2, v3, v6
	str	q2, [sp, #2096]                 ; 16-byte Spill
	str	q17, [sp, #2144]                ; 16-byte Spill
	and.16b	v2, v17, v7
	str	q2, [sp, #2080]                 ; 16-byte Spill
Lloh8:
	adrp	x9, lCPI0_3@PAGE
Lloh9:
	ldr	q2, [x9, lCPI0_3@PAGEOFF]
	str	q2, [sp, #1184]                 ; 16-byte Spill
Lloh10:
	adrp	x9, lCPI0_4@PAGE
Lloh11:
	ldr	q2, [x9, lCPI0_4@PAGEOFF]
	str	q2, [sp, #1168]                 ; 16-byte Spill
Lloh12:
	adrp	x9, lCPI0_5@PAGE
Lloh13:
	ldr	q2, [x9, lCPI0_5@PAGEOFF]
	str	q2, [sp, #1152]                 ; 16-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #512
	str	x9, [sp, #280]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #544
	str	x9, [sp, #272]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #576
	str	x9, [sp, #264]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #608
	str	x9, [sp, #256]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #640
	str	x9, [sp, #248]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #672
	str	x9, [sp, #240]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #704
	str	x9, [sp, #232]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #736
	str	x9, [sp, #224]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #768
	str	x9, [sp, #216]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #800
	str	x9, [sp, #208]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #832
	str	x9, [sp, #200]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	mvni.4s	v2, #63, msl #16
	fneg.4s	v2, v2
	str	q2, [sp, #1920]                 ; 16-byte Spill
	add	x9, x9, #864
	str	x9, [sp, #192]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #896
	str	x9, [sp, #184]                  ; 8-byte Spill
	movi.2d	v14, #0000000000000000
	movi.2d	v15, #0000000000000000
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #1136]                 ; 16-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #928
	str	x9, [sp, #176]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	movi.2d	v9, #0000000000000000
	movi.2d	v3, #0000000000000000
	str	q2, [sp, #1120]                 ; 16-byte Spill
	add	x9, x9, #960
	str	x9, [sp, #168]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #992
	str	x9, [sp, #160]                  ; 8-byte Spill
	str	q2, [sp, #1104]                 ; 16-byte Spill
	str	q2, [sp, #1088]                 ; 16-byte Spill
	str	q2, [sp, #1072]                 ; 16-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1056
	str	x9, [sp, #152]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1088
	str	x9, [sp, #144]                  ; 8-byte Spill
	str	q2, [sp, #1056]                 ; 16-byte Spill
	str	q2, [sp, #1040]                 ; 16-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1120
	str	x9, [sp, #136]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1152
	str	x9, [sp, #128]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1184
	str	x9, [sp, #120]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1216
	str	x9, [sp, #112]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1248
	str	x9, [sp, #104]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1280
	str	x9, [sp, #96]                   ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1312
	str	x9, [sp, #88]                   ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x7, x9, #1344
	add	x9, x10, #24, lsl #12           ; =98304
	add	x19, x9, #1376
	add	x9, x10, #24, lsl #12           ; =98304
	add	x20, x9, #1408
	add	x9, x10, #24, lsl #12           ; =98304
	add	x21, x9, #1440
	add	x9, x10, #24, lsl #12           ; =98304
	add	x22, x9, #1472
	add	x9, x10, #24, lsl #12           ; =98304
	add	x23, x9, #1504
	mov	w9, #33792                      ; =0x8400
	movk	w9, #1, lsl #16
	add	x24, x10, x9
	mov	w25, #52429                     ; =0xcccd
	mov	w26, #80                        ; =0x50
	mov	w27, #43691                     ; =0xaaab
	mov	w28, #96                        ; =0x60
	mov	x30, #-6148914691236517206      ; =0xaaaaaaaaaaaaaaaa
	movk	x30, #43691
	mov	w9, #3072                       ; =0xc00
	str	q2, [sp, #1024]                 ; 16-byte Spill
	str	q2, [sp, #1648]                 ; 16-byte Spill
	str	q2, [sp, #1632]                 ; 16-byte Spill
	str	q2, [sp, #1616]                 ; 16-byte Spill
	str	q2, [sp, #1600]                 ; 16-byte Spill
	movi.2d	v11, #0000000000000000
	str	q2, [sp, #1584]                 ; 16-byte Spill
	movi.2d	v28, #0000000000000000
	str	q2, [sp, #1568]                 ; 16-byte Spill
	movi.2d	v8, #0000000000000000
	str	q2, [sp, #1552]                 ; 16-byte Spill
	movi.2d	v13, #0000000000000000
	str	q2, [sp, #1536]                 ; 16-byte Spill
	movi.2d	v7, #0000000000000000
	str	q2, [sp, #1520]                 ; 16-byte Spill
	movi.2d	v16, #0000000000000000
	str	q2, [sp, #1504]                 ; 16-byte Spill
	movi.2d	v12, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v22, #0000000000000000
	str	q2, [sp, #2064]                 ; 16-byte Spill
	str	q2, [sp, #2048]                 ; 16-byte Spill
	str	q2, [sp, #2032]                 ; 16-byte Spill
	str	q2, [sp, #2016]                 ; 16-byte Spill
	str	q2, [sp, #2208]                 ; 16-byte Spill
	str	q2, [sp, #2192]                 ; 16-byte Spill
	str	q2, [sp, #2000]                 ; 16-byte Spill
	str	q2, [sp, #1984]                 ; 16-byte Spill
	str	q2, [sp, #1968]                 ; 16-byte Spill
	str	q2, [sp, #1952]                 ; 16-byte Spill
	str	q2, [sp, #2176]                 ; 16-byte Spill
	str	q2, [sp, #2160]                 ; 16-byte Spill
	stp	q2, q2, [sp, #992]              ; 32-byte Folded Spill
	stp	q2, q2, [sp, #960]              ; 32-byte Folded Spill
	movi.2d	v10, #0000000000000000
	movi.2d	v30, #0000000000000000
	str	q31, [sp, #1200]                ; 16-byte Spill
LBB0_22:                                ; %direct.true162
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_24 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
                                        ;     Child Loop BB0_61 Depth 2
                                        ;     Child Loop BB0_63 Depth 2
                                        ;     Child Loop BB0_65 Depth 2
                                        ;     Child Loop BB0_67 Depth 2
                                        ;     Child Loop BB0_69 Depth 2
                                        ;     Child Loop BB0_71 Depth 2
                                        ;     Child Loop BB0_73 Depth 2
                                        ;     Child Loop BB0_75 Depth 2
                                        ;     Child Loop BB0_77 Depth 2
                                        ;     Child Loop BB0_79 Depth 2
                                        ;     Child Loop BB0_81 Depth 2
                                        ;     Child Loop BB0_83 Depth 2
                                        ;     Child Loop BB0_85 Depth 2
                                        ;     Child Loop BB0_87 Depth 2
                                        ;     Child Loop BB0_89 Depth 2
                                        ;     Child Loop BB0_91 Depth 2
                                        ;     Child Loop BB0_93 Depth 2
                                        ;     Child Loop BB0_95 Depth 2
                                        ;       Child Loop BB0_96 Depth 3
                                        ;     Child Loop BB0_99 Depth 2
                                        ;     Child Loop BB0_101 Depth 2
	str	q24, [sp, #1872]                ; 16-byte Spill
	stp	q30, q10, [sp, #912]            ; 32-byte Folded Spill
	str	q3, [sp, #1680]                 ; 16-byte Spill
	str	q9, [sp, #944]                  ; 16-byte Spill
	mov	x2, #0                          ; =0x0
	lsl	x1, x0, #4
	ldr	q3, [sp, #1232]                 ; 16-byte Reload
	b	LBB0_24
LBB0_23:                                ; %direct.schedule.12
                                        ;   in Loop: Header=BB0_24 Depth=2
	str	q10, [sp, #1952]                ; 16-byte Spill
	str	q21, [sp, #1968]                ; 16-byte Spill
	ldr	q2, [sp, #1984]                 ; 16-byte Reload
	bit.16b	v2, v30, v0
	str	q2, [sp, #1984]                 ; 16-byte Spill
	ldr	q2, [sp, #2000]                 ; 16-byte Reload
	bit.16b	v2, v23, v1
	str	q2, [sp, #2000]                 ; 16-byte Spill
	add	x3, x12, x2, lsl #5
	ldp	q31, q9, [x3]
	bif.16b	v30, v9, v0
	bif.16b	v23, v31, v1
	stp	q23, q30, [x3]
	add	x2, x2, #1
	cmp	x2, #1280
	b.eq	LBB0_41
LBB0_24:                                ; %direct.true166
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w3, w2, #0xffff
	mul	w3, w3, w25
	lsr	w4, w3, #22
	add	x3, x1, x4
	dup.2d	v2, x3
	ldr	q21, [sp, #2112]                ; 16-byte Reload
	add.2d	v21, v2, v21
	ldr	q23, [sp, #2096]                ; 16-byte Reload
	add.2d	v23, v2, v23
	ldr	q30, [sp, #2080]                ; 16-byte Reload
	add.2d	v30, v2, v30
	mov.d	x5, v30[1]
	fmov	x6, d30
	add	x6, x6, x6, lsl #2
	lsl	x6, x6, #4
	fmov	d30, x6
	add	x5, x5, x5, lsl #2
	lsl	x5, x5, #4
	mov.d	v30[1], x5
	mov.d	x5, v23[1]
	fmov	x6, d23
	add	x6, x6, x6, lsl #2
	lsl	x6, x6, #4
	fmov	d23, x6
	add	x5, x5, x5, lsl #2
	lsl	x5, x5, #4
	mov.d	v23[1], x5
	mov.d	x5, v21[1]
	ldr	q31, [sp, #2128]                ; 16-byte Reload
	add.2d	v2, v2, v31
	fmov	x6, d21
	add	x6, x6, x6, lsl #2
	lsl	x6, x6, #4
	fmov	d21, x6
	add	x5, x5, x5, lsl #2
	lsl	x5, x5, #4
	mov.d	v21[1], x5
	mov.d	x5, v2[1]
	fmov	x6, d2
	add	x6, x6, x6, lsl #2
	lsl	x6, x6, #4
	fmov	d2, x6
	sshll.2d	v31, v1, #0
	msub	w4, w4, w26, w2
	and	x4, x4, #0xffff
	add	x5, x5, x5, lsl #2
	lsl	x5, x5, #4
	mov.d	v2[1], x5
	dup.2d	v9, x4
	sshll.2d	v10, v0, #0
	add.2d	v2, v2, v9
	add.2d	v21, v21, v9
	add.2d	v23, v23, v9
	add.2d	v30, v30, v9
	ldr	q9, [sp, #2144]                 ; 16-byte Reload
	ldr	q24, [sp, #2160]                ; 16-byte Reload
	bit.16b	v24, v30, v9
	str	q24, [sp, #2160]                ; 16-byte Spill
	ldr	q30, [sp, #2176]                ; 16-byte Reload
	bit.16b	v30, v23, v10
	str	q30, [sp, #2176]                ; 16-byte Spill
	ldr	q10, [sp, #1952]                ; 16-byte Reload
	bit.16b	v10, v21, v3
	ldr	q21, [sp, #1968]                ; 16-byte Reload
	bit.16b	v21, v2, v31
	movi.2d	v23, #0000000000000000
	movi.2d	v30, #0000000000000000
	cmp	x3, #2052
	b.hi	LBB0_23
; %bb.25:                               ; %direct.true179
                                        ;   in Loop: Header=BB0_24 Depth=2
	ldr	q2, [sp, #1936]                 ; 16-byte Reload
	fmov	w3, s2
	shl.2d	v2, v21, #2
	dup.2d	v31, x16
	add.2d	v9, v31, v2
	tbz	w3, #0, LBB0_33
; %bb.26:                               ; %cond.load195
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x4, d9
	ldr	s23, [x4]
	and	w3, w3, #0xff
	tbnz	w3, #1, LBB0_34
LBB0_27:                                ; %else205
                                        ;   in Loop: Header=BB0_24 Depth=2
	shl.2d	v2, v10, #2
	add.2d	v9, v31, v2
	tbz	w3, #2, LBB0_35
LBB0_28:                                ; %cond.load207
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x4, d9
	ld1.s	{ v23 }[2], [x4]
	tbnz	w3, #3, LBB0_36
LBB0_29:                                ; %else217
                                        ;   in Loop: Header=BB0_24 Depth=2
	ldr	q2, [sp, #2176]                 ; 16-byte Reload
	shl.2d	v2, v2, #2
	add.2d	v9, v31, v2
	tbz	w3, #4, LBB0_37
LBB0_30:                                ; %cond.load219
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x4, d9
	ld1.s	{ v30 }[0], [x4]
	tbnz	w3, #5, LBB0_38
LBB0_31:                                ; %else229
                                        ;   in Loop: Header=BB0_24 Depth=2
	ldr	q2, [sp, #2160]                 ; 16-byte Reload
	shl.2d	v2, v2, #2
	add.2d	v31, v31, v2
	tbz	w3, #6, LBB0_39
LBB0_32:                                ; %cond.load231
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x4, d31
	ld1.s	{ v30 }[2], [x4]
	tbz	w3, #7, LBB0_23
	b	LBB0_40
LBB0_33:                                ; %else199
                                        ;   in Loop: Header=BB0_24 Depth=2
	and	w3, w3, #0xff
	tbz	w3, #1, LBB0_27
LBB0_34:                                ; %cond.load201
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x4, v9[1]
	ld1.s	{ v23 }[1], [x4]
	shl.2d	v2, v10, #2
	add.2d	v9, v31, v2
	tbnz	w3, #2, LBB0_28
LBB0_35:                                ; %else211
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w3, #3, LBB0_29
LBB0_36:                                ; %cond.load213
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x4, v9[1]
	ld1.s	{ v23 }[3], [x4]
	ldr	q2, [sp, #2176]                 ; 16-byte Reload
	shl.2d	v2, v2, #2
	add.2d	v9, v31, v2
	tbnz	w3, #4, LBB0_30
LBB0_37:                                ; %else223
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w3, #5, LBB0_31
LBB0_38:                                ; %cond.load225
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x4, v9[1]
	ld1.s	{ v30 }[1], [x4]
	ldr	q2, [sp, #2160]                 ; 16-byte Reload
	shl.2d	v2, v2, #2
	add.2d	v31, v31, v2
	tbnz	w3, #6, LBB0_32
LBB0_39:                                ; %else235
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w3, #7, LBB0_23
LBB0_40:                                ; %cond.load237
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x3, v31[1]
	ld1.s	{ v30 }[3], [x3]
	b	LBB0_23
LBB0_41:                                ; %direct.true191.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q20, [sp, #1904]                ; 16-byte Spill
	mov	x2, #0                          ; =0x0
	b	LBB0_43
LBB0_42:                                ; %direct.schedule.17
                                        ;   in Loop: Header=BB0_43 Depth=2
	str	q10, [sp, #2016]                ; 16-byte Spill
	str	q21, [sp, #2032]                ; 16-byte Spill
	ldr	q2, [sp, #2048]                 ; 16-byte Reload
	bit.16b	v2, v30, v0
	str	q2, [sp, #2048]                 ; 16-byte Spill
	ldr	q2, [sp, #2064]                 ; 16-byte Reload
	bit.16b	v2, v23, v1
	str	q2, [sp, #2064]                 ; 16-byte Spill
	add	x3, x13, x2, lsl #5
	ldp	q31, q9, [x3]
	bif.16b	v30, v9, v0
	bif.16b	v23, v31, v1
	stp	q23, q30, [x3]
	add	x2, x2, #1
	cmp	x2, #1536
	b.eq	LBB0_60
LBB0_43:                                ; %direct.true191
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w3, w2, #0xffff
	mul	w3, w3, w27
	lsr	w4, w3, #22
	add	x3, x1, x4
	dup.2d	v2, x3
	ldr	q21, [sp, #2112]                ; 16-byte Reload
	add.2d	v21, v2, v21
	ldr	q23, [sp, #2096]                ; 16-byte Reload
	add.2d	v23, v2, v23
	ldr	q30, [sp, #2080]                ; 16-byte Reload
	add.2d	v30, v2, v30
	mov.d	x5, v30[1]
	fmov	x6, d30
	add	x6, x6, x6, lsl #1
	lsl	x6, x6, #5
	fmov	d30, x6
	add	x5, x5, x5, lsl #1
	lsl	x5, x5, #5
	mov.d	v30[1], x5
	mov.d	x5, v23[1]
	fmov	x6, d23
	add	x6, x6, x6, lsl #1
	lsl	x6, x6, #5
	fmov	d23, x6
	add	x5, x5, x5, lsl #1
	lsl	x5, x5, #5
	mov.d	v23[1], x5
	mov.d	x5, v21[1]
	ldr	q31, [sp, #2128]                ; 16-byte Reload
	add.2d	v2, v2, v31
	fmov	x6, d21
	add	x6, x6, x6, lsl #1
	lsl	x6, x6, #5
	fmov	d21, x6
	add	x5, x5, x5, lsl #1
	lsl	x5, x5, #5
	mov.d	v21[1], x5
	mov.d	x5, v2[1]
	fmov	x6, d2
	add	x6, x6, x6, lsl #1
	lsl	x6, x6, #5
	fmov	d2, x6
	sshll.2d	v31, v1, #0
	msub	w4, w4, w28, w2
	and	x4, x4, #0xffff
	add	x5, x5, x5, lsl #1
	lsl	x5, x5, #5
	mov.d	v2[1], x5
	dup.2d	v9, x4
	sshll.2d	v10, v0, #0
	add.2d	v2, v2, v9
	add.2d	v21, v21, v9
	add.2d	v23, v23, v9
	add.2d	v30, v30, v9
	ldr	q9, [sp, #2144]                 ; 16-byte Reload
	ldr	q20, [sp, #2192]                ; 16-byte Reload
	bit.16b	v20, v30, v9
	str	q20, [sp, #2192]                ; 16-byte Spill
	ldr	q30, [sp, #2208]                ; 16-byte Reload
	bit.16b	v30, v23, v10
	str	q30, [sp, #2208]                ; 16-byte Spill
	ldr	q10, [sp, #2016]                ; 16-byte Reload
	bit.16b	v10, v21, v3
	ldr	q21, [sp, #2032]                ; 16-byte Reload
	bit.16b	v21, v2, v31
	movi.2d	v23, #0000000000000000
	movi.2d	v30, #0000000000000000
	cmp	x3, #2053
	b.hs	LBB0_42
; %bb.44:                               ; %direct.true204
                                        ;   in Loop: Header=BB0_43 Depth=2
	ldr	q2, [sp, #1936]                 ; 16-byte Reload
	fmov	w3, s2
	shl.2d	v2, v21, #2
	dup.2d	v31, x17
	add.2d	v9, v31, v2
	tbz	w3, #0, LBB0_52
; %bb.45:                               ; %cond.load244
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x4, d9
	ldr	s23, [x4]
	and	w3, w3, #0xff
	tbnz	w3, #1, LBB0_53
LBB0_46:                                ; %else254
                                        ;   in Loop: Header=BB0_43 Depth=2
	shl.2d	v2, v10, #2
	add.2d	v9, v31, v2
	tbz	w3, #2, LBB0_54
LBB0_47:                                ; %cond.load256
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x4, d9
	ld1.s	{ v23 }[2], [x4]
	tbnz	w3, #3, LBB0_55
LBB0_48:                                ; %else266
                                        ;   in Loop: Header=BB0_43 Depth=2
	ldr	q2, [sp, #2208]                 ; 16-byte Reload
	shl.2d	v2, v2, #2
	add.2d	v9, v31, v2
	tbz	w3, #4, LBB0_56
LBB0_49:                                ; %cond.load268
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x4, d9
	ld1.s	{ v30 }[0], [x4]
	tbnz	w3, #5, LBB0_57
LBB0_50:                                ; %else278
                                        ;   in Loop: Header=BB0_43 Depth=2
	ldr	q2, [sp, #2192]                 ; 16-byte Reload
	shl.2d	v2, v2, #2
	add.2d	v31, v31, v2
	tbz	w3, #6, LBB0_58
LBB0_51:                                ; %cond.load280
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x4, d31
	ld1.s	{ v30 }[2], [x4]
	tbz	w3, #7, LBB0_42
	b	LBB0_59
LBB0_52:                                ; %else248
                                        ;   in Loop: Header=BB0_43 Depth=2
	and	w3, w3, #0xff
	tbz	w3, #1, LBB0_46
LBB0_53:                                ; %cond.load250
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x4, v9[1]
	ld1.s	{ v23 }[1], [x4]
	shl.2d	v2, v10, #2
	add.2d	v9, v31, v2
	tbnz	w3, #2, LBB0_47
LBB0_54:                                ; %else260
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w3, #3, LBB0_48
LBB0_55:                                ; %cond.load262
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x4, v9[1]
	ld1.s	{ v23 }[3], [x4]
	ldr	q2, [sp, #2208]                 ; 16-byte Reload
	shl.2d	v2, v2, #2
	add.2d	v9, v31, v2
	tbnz	w3, #4, LBB0_49
LBB0_56:                                ; %else272
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w3, #5, LBB0_50
LBB0_57:                                ; %cond.load274
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x4, v9[1]
	ld1.s	{ v30 }[1], [x4]
	ldr	q2, [sp, #2192]                 ; 16-byte Reload
	shl.2d	v2, v2, #2
	add.2d	v31, v31, v2
	tbnz	w3, #6, LBB0_51
LBB0_58:                                ; %else284
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w3, #7, LBB0_42
LBB0_59:                                ; %cond.load286
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x3, v31[1]
	ld1.s	{ v30 }[3], [x3]
	b	LBB0_42
LBB0_60:                                ; %direct.false192
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x1, #0                          ; =0x0
	sshll.2d	v2, v1, #0
	sshll.2d	v21, v0, #0
	ldr	q23, [sp, #2144]                ; 16-byte Reload
	ldr	q30, [sp, #1184]                ; 16-byte Reload
	ldr	q20, [sp, #960]                 ; 16-byte Reload
	bit.16b	v20, v30, v23
	str	q20, [sp, #960]                 ; 16-byte Spill
	ldr	q23, [sp, #1168]                ; 16-byte Reload
	ldr	q20, [sp, #992]                 ; 16-byte Reload
	bit.16b	v20, v23, v3
	str	q20, [sp, #992]                 ; 16-byte Spill
	ldr	q3, [sp, #1152]                 ; 16-byte Reload
	ldr	q20, [sp, #976]                 ; 16-byte Reload
	bit.16b	v20, v3, v21
	str	q20, [sp, #976]                 ; 16-byte Spill
	ldr	q3, [sp, #1216]                 ; 16-byte Reload
	ldr	q20, [sp, #1008]                ; 16-byte Reload
	bit.16b	v20, v3, v2
	bic.16b	v22, v22, v0
	bic.16b	v6, v6, v1
	ldr	q3, [sp, #1200]                 ; 16-byte Reload
LBB0_61:                                ; %direct.true216
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	d2, x1
	orr.16b	v21, v2, v3
	fmov	x2, d21
	add	x2, x10, x2
	ldp	q21, q23, [x2]
	orr.16b	v2, v2, v20
	fmov	x2, d2
	add	x2, x12, x2
	ldp	q2, q30, [x2]
	fmul.4s	v23, v23, v30
	fmul.4s	v2, v21, v2
	fadd.4s	v2, v6, v2
	fadd.4s	v21, v22, v23
	bit.16b	v22, v21, v0
	bit.16b	v6, v2, v1
	add	x1, x1, #32
	cmp	x1, #2560
	b.ne	LBB0_61
; %bb.62:                               ; %direct.false217
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q20, [sp, #1008]                ; 16-byte Spill
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	and.16b	v5, v2, v5
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	and.16b	v4, v2, v4
	mov	x1, x10
	mov	w2, #80                         ; =0x50
	ldr	q31, [sp, #1648]                ; 16-byte Reload
	ldr	q9, [sp, #1632]                 ; 16-byte Reload
	ldr	q10, [sp, #1616]                ; 16-byte Reload
LBB0_63:                                ; %direct.true231
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q21, [x1]
	ldr	q23, [x1, #11264]
	ldr	q30, [x1, #11280]
	fmul.4s	v21, v21, v30
	fmul.4s	v2, v2, v23
	fadd.4s	v2, v4, v2
	fadd.4s	v21, v5, v21
	bit.16b	v5, v21, v0
	bit.16b	v4, v2, v1
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_63
; %bb.64:                               ; %direct.false232
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	and.16b	v19, v2, v19
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	and.16b	v29, v2, v29
	mov	x1, x10
	mov	w2, #80                         ; =0x50
	ldr	q3, [sp, #1040]                 ; 16-byte Reload
	ldr	q20, [sp, #1904]                ; 16-byte Reload
	ldr	q24, [sp, #1872]                ; 16-byte Reload
LBB0_65:                                ; %direct.true248
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q21, [x1]
	ldr	q23, [x1, #13824]
	ldr	q30, [x1, #13840]
	fmul.4s	v21, v21, v30
	fmul.4s	v2, v2, v23
	fadd.4s	v2, v29, v2
	fadd.4s	v21, v19, v21
	bit.16b	v19, v21, v0
	bit.16b	v29, v2, v1
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_65
; %bb.66:                               ; %direct.false249
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	and.16b	v18, v2, v18
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	and.16b	v17, v2, v17
	mov	x1, x10
	mov	w2, #80                         ; =0x50
LBB0_67:                                ; %direct.true265
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q21, [x1]
	ldr	q23, [x1, #16384]
	ldr	q30, [x1, #16400]
	fmul.4s	v21, v21, v30
	fmul.4s	v2, v2, v23
	fadd.4s	v2, v17, v2
	fadd.4s	v21, v18, v21
	bit.16b	v18, v21, v0
	bit.16b	v17, v2, v1
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_67
; %bb.68:                               ; %direct.false266
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	and.16b	v27, v2, v27
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	and.16b	v26, v2, v26
	mov	x1, x10
	mov	w2, #80                         ; =0x50
LBB0_69:                                ; %direct.true282
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q21, [x1]
	ldr	q23, [x1, #18944]
	ldr	q30, [x1, #18960]
	fmul.4s	v21, v21, v30
	fmul.4s	v2, v2, v23
	fadd.4s	v2, v26, v2
	fadd.4s	v21, v27, v21
	bit.16b	v27, v21, v0
	bit.16b	v26, v2, v1
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_69
; %bb.70:                               ; %direct.false283
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	and.16b	v25, v2, v25
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	and.16b	v24, v2, v24
	mov	x1, x10
	mov	w2, #80                         ; =0x50
LBB0_71:                                ; %direct.true299
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q21, [x1]
	ldr	q23, [x1, #21504]
	ldr	q30, [x1, #21520]
	fmul.4s	v21, v21, v30
	fmul.4s	v2, v2, v23
	fadd.4s	v2, v24, v2
	fadd.4s	v21, v25, v21
	bit.16b	v25, v21, v0
	bit.16b	v24, v2, v1
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_71
; %bb.72:                               ; %direct.false300
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	and.16b	v20, v2, v20
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	and.16b	v12, v2, v12
	mov	x1, x10
	mov	w2, #80                         ; =0x50
LBB0_73:                                ; %direct.true316
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q21, [x1]
	ldr	q23, [x1, #24064]
	ldr	q30, [x1, #24080]
	fmul.4s	v21, v21, v30
	fmul.4s	v2, v2, v23
	fadd.4s	v2, v12, v2
	fadd.4s	v21, v20, v21
	bit.16b	v20, v21, v0
	bit.16b	v12, v2, v1
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_73
; %bb.74:                               ; %direct.false317
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q12, [sp, #880]                 ; 16-byte Spill
	ldr	q12, [sp, #1504]                ; 16-byte Reload
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	and.16b	v12, v2, v12
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	and.16b	v16, v2, v16
	mov	x1, x10
	mov	w2, #80                         ; =0x50
LBB0_75:                                ; %direct.true333
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q21, [x1]
	ldr	q23, [x1, #26624]
	ldr	q30, [x1, #26640]
	fmul.4s	v21, v21, v30
	fmul.4s	v2, v2, v23
	fadd.4s	v2, v16, v2
	fadd.4s	v21, v12, v21
	bit.16b	v12, v21, v0
	bit.16b	v16, v2, v1
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_75
; %bb.76:                               ; %direct.false334
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q12, [sp, #1504]                ; 16-byte Spill
	str	q16, [sp, #1424]                ; 16-byte Spill
	ldr	q16, [sp, #1520]                ; 16-byte Reload
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	and.16b	v16, v2, v16
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	and.16b	v7, v2, v7
	mov	x1, x10
	mov	w2, #80                         ; =0x50
LBB0_77:                                ; %direct.true350
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q21, [x1]
	ldr	q23, [x1, #29184]
	ldr	q30, [x1, #29200]
	fmul.4s	v21, v21, v30
	fmul.4s	v2, v2, v23
	fadd.4s	v2, v7, v2
	fadd.4s	v21, v16, v21
	bit.16b	v16, v21, v0
	bit.16b	v7, v2, v1
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_77
; %bb.78:                               ; %direct.false351
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q16, [sp, #1520]                ; 16-byte Spill
	str	q7, [sp, #896]                  ; 16-byte Spill
	ldr	q7, [sp, #1536]                 ; 16-byte Reload
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	and.16b	v7, v2, v7
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	and.16b	v13, v2, v13
	mov	x1, x10
	mov	w2, #80                         ; =0x50
	ldr	q12, [sp, #880]                 ; 16-byte Reload
LBB0_79:                                ; %direct.true367
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q21, [x1]
	ldr	q23, [x1, #31744]
	ldr	q30, [x1, #31760]
	fmul.4s	v21, v21, v30
	fmul.4s	v2, v2, v23
	fadd.4s	v2, v13, v2
	fadd.4s	v21, v7, v21
	bit.16b	v7, v21, v0
	bit.16b	v13, v2, v1
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_79
; %bb.80:                               ; %direct.false368
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q7, [sp, #1536]                 ; 16-byte Spill
	str	q13, [sp, #1440]                ; 16-byte Spill
	ldr	q13, [sp, #1552]                ; 16-byte Reload
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	and.16b	v13, v2, v13
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	and.16b	v8, v2, v8
	mov	x1, x10
	mov	w2, #80                         ; =0x50
LBB0_81:                                ; %direct.true384
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q21, [x1]
	ldr	q23, [x1, #34304]
	ldr	q30, [x1, #34320]
	fmul.4s	v21, v21, v30
	fmul.4s	v2, v2, v23
	fadd.4s	v2, v8, v2
	fadd.4s	v21, v13, v21
	bit.16b	v13, v21, v0
	bit.16b	v8, v2, v1
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_81
; %bb.82:                               ; %direct.false385
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q13, [sp, #1552]                ; 16-byte Spill
	str	q8, [sp, #1456]                 ; 16-byte Spill
	ldr	q8, [sp, #1568]                 ; 16-byte Reload
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	and.16b	v8, v2, v8
	ldr	q13, [sp, #1840]                ; 16-byte Reload
	and.16b	v28, v13, v28
	mov	x1, x10
	mov	w2, #80                         ; =0x50
	ldr	q7, [sp, #896]                  ; 16-byte Reload
LBB0_83:                                ; %direct.true401
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q21, [x1]
	ldr	q23, [x1, #36864]
	ldr	q30, [x1, #36880]
	fmul.4s	v21, v21, v30
	fmul.4s	v2, v2, v23
	fadd.4s	v2, v28, v2
	fadd.4s	v21, v8, v21
	bit.16b	v8, v21, v0
	bit.16b	v28, v2, v1
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_83
; %bb.84:                               ; %direct.false402
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q8, [sp, #1568]                 ; 16-byte Spill
	str	q28, [sp, #1472]                ; 16-byte Spill
	ldr	q28, [sp, #1584]                ; 16-byte Reload
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	and.16b	v28, v2, v28
	and.16b	v11, v13, v11
	mov	x1, x10
	mov	w2, #80                         ; =0x50
LBB0_85:                                ; %direct.true418
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q21, [x1]
	ldr	q23, [x1, #39424]
	ldr	q30, [x1, #39440]
	fmul.4s	v21, v21, v30
	fmul.4s	v2, v2, v23
	fadd.4s	v2, v11, v2
	fadd.4s	v21, v28, v21
	bit.16b	v28, v21, v0
	bit.16b	v11, v2, v1
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_85
; %bb.86:                               ; %direct.false419
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q28, [sp, #1584]                ; 16-byte Spill
	str	q11, [sp, #1488]                ; 16-byte Spill
	ldr	q11, [sp, #1600]                ; 16-byte Reload
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	and.16b	v11, v2, v11
	and.16b	v10, v13, v10
	mov	x1, x10
	mov	w2, #80                         ; =0x50
LBB0_87:                                ; %direct.true435
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q21, [x1]
	ldr	q23, [x1, #41984]
	ldr	q30, [x1, #42000]
	fmul.4s	v21, v21, v30
	fmul.4s	v2, v2, v23
	fadd.4s	v2, v10, v2
	fadd.4s	v21, v11, v21
	bit.16b	v11, v21, v0
	bit.16b	v10, v2, v1
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_87
; %bb.88:                               ; %direct.false436
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q11, [sp, #1600]                ; 16-byte Spill
	ldr	q11, [sp, #1888]                ; 16-byte Reload
	and.16b	v9, v11, v9
	and.16b	v31, v13, v31
	mov	x1, x10
	mov	w2, #80                         ; =0x50
LBB0_89:                                ; %direct.true452
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q21, [x1]
	ldr	q23, [x1, #44544]
	ldr	q30, [x1, #44560]
	fmul.4s	v21, v21, v30
	fmul.4s	v2, v2, v23
	fadd.4s	v2, v31, v2
	fadd.4s	v21, v9, v21
	bit.16b	v9, v21, v0
	bit.16b	v31, v2, v1
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_89
; %bb.90:                               ; %direct.false453
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q27, [sp, #1248]                ; 16-byte Spill
	str	q10, [sp, #1616]                ; 16-byte Spill
	str	q9, [sp, #1632]                 ; 16-byte Spill
	str	q31, [sp, #1648]                ; 16-byte Spill
	ldr	q28, [sp, #1024]                ; 16-byte Reload
	and.16b	v28, v11, v28
	and.16b	v3, v13, v3
	mov	x1, x10
	mov	w2, #80                         ; =0x50
LBB0_91:                                ; %direct.true469
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q2, q21, [x1]
	ldr	q23, [x1, #47104]
	ldr	q30, [x1, #47120]
	fmul.4s	v21, v21, v30
	fmul.4s	v2, v2, v23
	fadd.4s	v2, v3, v2
	fadd.4s	v21, v28, v21
	bit.16b	v28, v21, v0
	bit.16b	v3, v2, v1
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_91
; %bb.92:                               ; %direct.false470
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x1, #0                          ; =0x0
	mov	w2, #63790                      ; =0xf92e
	movk	w2, #15844, lsl #16
	dup.4s	v23, w2
	cmp	x0, #128
	cset	w2, lo
	dup.4h	v30, w2
	fmul.4s	v27, v6, v23
	fmul.4s	v16, v22, v23
	ldp	x3, x4, [sp, #272]              ; 16-byte Folded Reload
	ldp	q2, q21, [x4]
	fmul.4s	v9, v4, v23
	fmul.4s	v31, v5, v23
	str	q16, [sp, #1904]                ; 16-byte Spill
	bit.16b	v21, v16, v0
	str	q27, [sp, #1872]                ; 16-byte Spill
	bit.16b	v2, v27, v1
	stp	q2, q21, [x4]
	stp	q29, q18, [sp, #336]            ; 32-byte Folded Spill
	fmul.4s	v13, v29, v23
	str	q19, [sp, #304]                 ; 16-byte Spill
	fmul.4s	v16, v19, v23
	str	q17, [sp, #448]                 ; 16-byte Spill
	fmul.4s	v27, v17, v23
	fmul.4s	v11, v18, v23
	ldp	q2, q21, [x3]
	str	q26, [sp, #640]                 ; 16-byte Spill
	fmul.4s	v8, v26, v23
	str	q31, [sp, #1376]                ; 16-byte Spill
	bit.16b	v21, v31, v0
	str	q9, [sp, #1360]                 ; 16-byte Spill
	bit.16b	v2, v9, v1
	stp	q2, q21, [x3]
	ldr	q2, [sp, #1248]                 ; 16-byte Reload
	fmul.4s	v26, v2, v23
	str	q25, [sp, #784]                 ; 16-byte Spill
	fmul.4s	v10, v25, v23
	fmul.4s	v21, v24, v23
	ldp	x3, x5, [sp, #256]              ; 16-byte Folded Reload
	ldp	q31, q9, [x5]
	fmul.4s	v2, v20, v23
	str	q2, [sp, #1856]                 ; 16-byte Spill
	str	q16, [sp, #1344]                ; 16-byte Spill
	bit.16b	v9, v16, v0
	str	q13, [sp, #1328]                ; 16-byte Spill
	bit.16b	v31, v13, v1
	stp	q31, q9, [x5]
	fmul.4s	v31, v12, v23
	ldr	q2, [sp, #1504]                 ; 16-byte Reload
	fmul.4s	v29, v2, v23
	ldr	q2, [sp, #1424]                 ; 16-byte Reload
	fmul.4s	v25, v2, v23
	ldp	q2, q13, [x3]
	ldr	q16, [sp, #1520]                ; 16-byte Reload
	fmul.4s	v19, v16, v23
	str	q11, [sp, #1312]                ; 16-byte Spill
	bit.16b	v13, v11, v0
	str	q27, [sp, #1296]                ; 16-byte Spill
	bit.16b	v2, v27, v1
	stp	q2, q13, [x3]
	fmul.4s	v9, v7, v23
	ldr	q2, [sp, #1440]                 ; 16-byte Reload
	fmul.4s	v18, v2, v23
	ldr	q2, [sp, #1536]                 ; 16-byte Reload
	fmul.4s	v27, v2, v23
	ldp	x3, x6, [sp, #240]              ; 16-byte Folded Reload
	mov.16b	v17, v3
	ldp	q2, q3, [x6]
	ushll.4s	v30, v30, #0
	str	q26, [sp, #1280]                ; 16-byte Spill
	bit.16b	v3, v26, v0
	str	q8, [sp, #1264]                 ; 16-byte Spill
	bit.16b	v2, v8, v1
	stp	q2, q3, [x6]
	shl.4s	v2, v30, #31
	cmlt.4s	v30, v2, #0
	ldr	q8, [sp, #288]                  ; 16-byte Reload
	mov.16b	v16, v30
	bsl.16b	v16, v21, v8
	ldp	q2, q3, [x3]
	mov.16b	v21, v30
	bsl.16b	v21, v10, v8
	stp	q21, q16, [sp, #576]            ; 32-byte Folded Spill
	bit.16b	v3, v21, v0
	bit.16b	v2, v16, v1
	stp	q2, q3, [x3]
	ldr	q2, [sp, #1456]                 ; 16-byte Reload
	fmul.4s	v26, v2, v23
	ldr	q2, [sp, #1552]                 ; 16-byte Reload
	fmul.4s	v2, v2, v23
	str	q2, [sp, #1824]                 ; 16-byte Spill
	mov.16b	v2, v30
	bsl.16b	v2, v31, v8
	ldr	x3, [sp, #232]                  ; 8-byte Reload
	ldp	q21, q31, [x3]
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	bif.16b	v3, v8, v30
	stp	q3, q2, [sp, #512]              ; 32-byte Folded Spill
	bit.16b	v31, v3, v0
	bit.16b	v21, v2, v1
	stp	q21, q31, [x3]
	ldr	q2, [sp, #1472]                 ; 16-byte Reload
	fmul.4s	v21, v2, v23
	ldr	q2, [sp, #1568]                 ; 16-byte Reload
	fmul.4s	v3, v2, v23
	mov.16b	v2, v30
	bsl.16b	v2, v25, v8
	ldr	x3, [sp, #224]                  ; 8-byte Reload
	ldp	q10, q11, [x3]
	mov.16b	v16, v30
	bsl.16b	v16, v29, v8
	stp	q16, q2, [sp, #480]             ; 32-byte Folded Spill
	bit.16b	v11, v16, v0
	bit.16b	v10, v2, v1
	stp	q10, q11, [x3]
	ldr	q2, [sp, #1488]                 ; 16-byte Reload
	fmul.4s	v10, v2, v23
	ldr	q2, [sp, #1584]                 ; 16-byte Reload
	fmul.4s	v11, v2, v23
	mov.16b	v16, v30
	bsl.16b	v16, v9, v8
	ldr	x3, [sp, #216]                  ; 8-byte Reload
	ldp	q9, q2, [x3]
	mov.16b	v25, v30
	bsl.16b	v25, v19, v8
	stp	q25, q16, [sp, #544]            ; 32-byte Folded Spill
	bit.16b	v2, v25, v0
	bit.16b	v9, v16, v1
	stp	q9, q2, [x3]
	ldr	q2, [sp, #1600]                 ; 16-byte Reload
	fmul.4s	v13, v2, v23
	ldr	q2, [sp, #1616]                 ; 16-byte Reload
	fmul.4s	v9, v2, v23
	mov.16b	v16, v30
	bsl.16b	v16, v27, v8
	ldr	x3, [sp, #208]                  ; 8-byte Reload
	mov.16b	v31, v28
	ldp	q28, q2, [x3]
	mov.16b	v25, v30
	bsl.16b	v25, v18, v8
	stp	q25, q16, [sp, #608]            ; 32-byte Folded Spill
	bit.16b	v28, v25, v1
	bit.16b	v2, v16, v0
	stp	q28, q2, [x3]
	ldr	q2, [sp, #1824]                 ; 16-byte Reload
	mov.16b	v16, v30
	bsl.16b	v16, v2, v8
	bif.16b	v26, v8, v30
	mov.16b	v25, v30
	bsl.16b	v25, v3, v8
	ldr	x3, [sp, #200]                  ; 8-byte Reload
	ldp	q3, q2, [x3]
	mov.16b	v28, v30
	bsl.16b	v28, v21, v8
	stp	q26, q16, [sp, #656]            ; 32-byte Folded Spill
	bit.16b	v3, v26, v1
	bit.16b	v2, v16, v0
	stp	q3, q2, [x3]
	mov.16b	v16, v30
	bsl.16b	v16, v11, v8
	mov.16b	v21, v30
	bsl.16b	v21, v10, v8
	ldr	x3, [sp, #192]                  ; 8-byte Reload
	ldp	q3, q2, [x3]
	stp	q28, q25, [sp, #688]            ; 32-byte Folded Spill
	bit.16b	v3, v28, v1
	bit.16b	v2, v25, v0
	stp	q3, q2, [x3]
	ldr	x3, [sp, #184]                  ; 8-byte Reload
	ldp	q3, q2, [x3]
	stp	q21, q16, [sp, #720]            ; 32-byte Folded Spill
	bit.16b	v3, v21, v1
	bit.16b	v2, v16, v0
	stp	q3, q2, [x3]
	ldr	q2, [sp, #1648]                 ; 16-byte Reload
	fmul.4s	v2, v2, v23
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	fmul.4s	v3, v3, v23
	str	q17, [sp, #1040]                ; 16-byte Spill
	fmul.4s	v21, v17, v23
	str	q31, [sp, #1024]                ; 16-byte Spill
	fmul.4s	v23, v31, v23
	mov.16b	v25, v30
	bsl.16b	v25, v9, v8
	mov.16b	v9, v30
	bsl.16b	v9, v13, v8
	mov.16b	v28, v30
	bsl.16b	v28, v3, v8
	mov.16b	v31, v30
	bsl.16b	v31, v2, v8
	mov.16b	v16, v30
	bsl.16b	v16, v23, v8
	bif.16b	v21, v8, v30
	ldr	x3, [sp, #176]                  ; 8-byte Reload
	ldp	q3, q2, [x3]
	stp	q9, q25, [sp, #752]             ; 32-byte Folded Spill
	bit.16b	v2, v9, v0
	bit.16b	v3, v25, v1
	stp	q3, q2, [x3]
	ldr	x3, [sp, #168]                  ; 8-byte Reload
	ldp	q2, q3, [x3]
	stp	q31, q28, [sp, #800]            ; 32-byte Folded Spill
	bit.16b	v2, v31, v1
	bit.16b	v3, v28, v0
	stp	q2, q3, [x3]
	ldr	x3, [sp, #160]                  ; 8-byte Reload
	ldp	q2, q3, [x3]
	stp	q21, q16, [sp, #832]            ; 32-byte Folded Spill
	bit.16b	v2, v21, v1
	bit.16b	v3, v16, v0
	stp	q2, q3, [x3]
	mvni.4s	v2, #127, msl #16
	ldr	q28, [sp, #1056]                ; 16-byte Reload
	bit.16b	v28, v2, v0
	ldr	q21, [sp, #1072]                ; 16-byte Reload
	bit.16b	v21, v2, v1
	dup.8b	v2, w2
	str	d2, [sp, #864]                  ; 8-byte Spill
LBB0_93:                                ; %direct.true583
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x2, x14, x1
	ldp	q2, q3, [x2]
	and.16b	v3, v0, v3
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v21, v2
	fmaxnm.4s	v3, v28, v3
	bit.16b	v28, v3, v0
	bit.16b	v21, v2, v1
	add	x1, x1, #32
	cmp	x1, #512
	b.ne	LBB0_93
; %bb.94:                               ; %direct.false584
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x1, #0                          ; =0x0
	ldr	q2, [sp, #1696]                 ; 16-byte Reload
	str	q21, [sp, #1072]                ; 16-byte Spill
	fmaxnm.4s	v10, v2, v21
	ldr	q2, [sp, #1872]                 ; 16-byte Reload
	fsub.4s	v2, v2, v10
	str	q10, [sp, #1776]                ; 16-byte Spill
	and.16b	v23, v1, v2
	mov	w2, #-1026555904                ; =0xc2d00000
	dup.4s	v8, w2
	mov	w2, #1120403456                 ; =0x42c80000
	dup.4s	v13, w2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v13, v23
	and.16b	v2, v2, v3
	str	q28, [sp, #1056]                ; 16-byte Spill
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	fmaxnm.4s	v19, v3, v28
	ldr	q3, [sp, #1904]                 ; 16-byte Reload
	fsub.4s	v3, v3, v19
	and.16b	v30, v0, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v13, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	mov	w2, #43579                      ; =0xaa3b
	movk	w2, #16312, lsl #16
	dup.4s	v17, w2
	fmul.4s	v21, v3, v17
	movi.4s	v25, #75, lsl #24
	mvni.4s	v31, #128, lsl #24
	mov.16b	v28, v31
	bsl.16b	v28, v25, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v17
	bsl.16b	v31, v25, v28
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v11, v21
	mov	w2, #29184                      ; =0x7200
	movk	w2, #16177, lsl #16
	dup.4s	v16, w2
	str	q16, [sp, #1856]                ; 16-byte Spill
	scvtf.4s	v21, v11
	fmul.4s	v31, v21, v16
	fsub.4s	v3, v3, v31
	fcvtzs.4s	v31, v28
	scvtf.4s	v28, v31
	fmul.4s	v9, v28, v16
	fsub.4s	v2, v2, v9
	mov	w2, #48782                      ; =0xbe8e
	movk	w2, #13759, lsl #16
	dup.4s	v16, w2
	str	q16, [sp, #1904]                ; 16-byte Spill
	fmul.4s	v28, v28, v16
	fsub.4s	v2, v2, v28
	fmul.4s	v21, v21, v16
	fsub.4s	v3, v3, v21
	mov	w2, #11226                      ; =0x2bda
	movk	w2, #14672, lsl #16
	dup.4s	v27, w2
	fmul.4s	v21, v3, v27
	mov	w2, #38601                      ; =0x96c9
	movk	w2, #15030, lsl #16
	dup.4s	v16, w2
	fadd.4s	v21, v21, v16
	str	q16, [sp, #1744]                ; 16-byte Spill
	fmul.4s	v21, v3, v21
	mov	w2, #34982                      ; =0x88a6
	movk	w2, #15368, lsl #16
	dup.4s	v26, w2
	fadd.4s	v21, v21, v26
	fmul.4s	v21, v3, v21
	mov	w2, #43642                      ; =0xaa7a
	movk	w2, #15658, lsl #16
	dup.4s	v29, w2
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v3, v21
	mov	w2, #43691                      ; =0xaaab
	movk	w2, #15914, lsl #16
	dup.4s	v25, w2
	fadd.4s	v21, v21, v25
	fmul.4s	v21, v3, v21
	movi.4s	v28, #63, lsl #24
	fadd.4s	v21, v21, v28
	movi.4s	v18, #63, lsl #24
	fmul.4s	v28, v3, v3
	fmul.4s	v21, v28, v21
	fmul.4s	v28, v2, v27
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v2, v28
	fadd.4s	v28, v28, v26
	fmul.4s	v28, v2, v28
	fadd.4s	v28, v28, v29
	fmul.4s	v28, v2, v28
	fadd.4s	v28, v28, v25
	fmul.4s	v28, v2, v28
	fadd.4s	v28, v28, v18
	fmul.4s	v9, v2, v2
	fmul.4s	v28, v9, v28
	fadd.4s	v2, v2, v28
	fadd.4s	v3, v3, v21
	fmov.4s	v16, #1.00000000
	fadd.4s	v2, v2, v16
	sshr.4s	v21, v31, #1
	shl.4s	v28, v21, #23
	add.4s	v28, v28, v16
	fmul.4s	v2, v2, v28
	fadd.4s	v3, v3, v16
	sshr.4s	v28, v11, #1
	shl.4s	v9, v28, #23
	add.4s	v9, v9, v16
	fmul.4s	v3, v3, v9
	sub.4s	v21, v31, v21
	sub.4s	v28, v11, v28
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v16
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v16
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v13
	mvni.4s	v28, #127, msl #16
	fneg.4s	v18, v28
	str	q18, [sp, #1872]                ; 16-byte Spill
	bit.16b	v3, v18, v21
	fcmgt.4s	v21, v23, v13
	bit.16b	v2, v18, v21
	fcmeq.4s	v21, v23, v23
	ldr	q18, [sp, #1920]                ; 16-byte Reload
	bif.16b	v2, v18, v21
	str	q2, [sp, #1408]                 ; 16-byte Spill
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v18
	str	q2, [sp, #1392]                 ; 16-byte Spill
	ldr	q2, [sp, #1360]                 ; 16-byte Reload
	fsub.4s	v2, v2, v10
	and.16b	v23, v1, v2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v13, v23
	and.16b	v2, v2, v3
	mov.16b	v11, v19
	str	q19, [sp, #1760]                ; 16-byte Spill
	ldr	q3, [sp, #1376]                 ; 16-byte Reload
	fsub.4s	v3, v3, v19
	and.16b	v30, v0, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v13, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	str	q17, [sp, #1824]                ; 16-byte Spill
	fmul.4s	v21, v3, v17
	movi.4s	v18, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	mov.16b	v28, v19
	bsl.16b	v28, v18, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v17
	mov.16b	v31, v19
	bsl.16b	v31, v18, v28
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v31, v21
	scvtf.4s	v21, v31
	ldr	q17, [sp, #1856]                ; 16-byte Reload
	fmul.4s	v9, v21, v17
	fsub.4s	v3, v3, v9
	fcvtzs.4s	v28, v28
	scvtf.4s	v9, v28
	fmul.4s	v10, v9, v17
	fsub.4s	v2, v2, v10
	ldr	q17, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v9, v9, v17
	fsub.4s	v2, v2, v9
	fmul.4s	v21, v21, v17
	fsub.4s	v3, v3, v21
	fmul.4s	v21, v3, v27
	ldr	q18, [sp, #1744]                ; 16-byte Reload
	fadd.4s	v21, v21, v18
	fmul.4s	v21, v3, v21
	str	q26, [sp, #1808]                ; 16-byte Spill
	fadd.4s	v21, v21, v26
	fmul.4s	v21, v3, v21
	mov.16b	v17, v29
	str	q29, [sp, #1792]                ; 16-byte Spill
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v3, v21
	fadd.4s	v21, v21, v25
	fmul.4s	v21, v3, v21
	movi.4s	v29, #63, lsl #24
	fadd.4s	v21, v21, v29
	fmul.4s	v9, v3, v3
	fmul.4s	v21, v9, v21
	fmul.4s	v9, v2, v27
	fadd.4s	v9, v9, v18
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v26
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v17
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v25
	mov.16b	v19, v25
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v29
	fmul.4s	v10, v2, v2
	fmul.4s	v9, v10, v9
	fadd.4s	v2, v2, v9
	fadd.4s	v3, v3, v21
	fadd.4s	v2, v2, v16
	sshr.4s	v21, v28, #1
	shl.4s	v9, v21, #23
	add.4s	v9, v9, v16
	fmul.4s	v2, v2, v9
	fadd.4s	v3, v3, v16
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v16
	fmul.4s	v3, v3, v10
	sub.4s	v21, v28, v21
	sub.4s	v28, v31, v9
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v16
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v16
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v13
	ldr	q17, [sp, #1872]                ; 16-byte Reload
	bit.16b	v3, v17, v21
	fcmgt.4s	v21, v23, v13
	bit.16b	v2, v17, v21
	fcmeq.4s	v21, v23, v23
	ldr	q17, [sp, #1920]                ; 16-byte Reload
	bif.16b	v2, v17, v21
	str	q2, [sp, #1376]                 ; 16-byte Spill
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v17
	str	q2, [sp, #1360]                 ; 16-byte Spill
	ldr	q2, [sp, #1328]                 ; 16-byte Reload
	ldr	q18, [sp, #1776]                ; 16-byte Reload
	fsub.4s	v2, v2, v18
	and.16b	v23, v1, v2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v13, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1344]                 ; 16-byte Reload
	fsub.4s	v3, v3, v11
	and.16b	v30, v0, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v13, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	ldr	q26, [sp, #1824]                ; 16-byte Reload
	fmul.4s	v21, v3, v26
	mvni.4s	v17, #128, lsl #24
	movi.4s	v25, #75, lsl #24
	mov.16b	v28, v17
	bsl.16b	v28, v25, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v26
	mov.16b	v31, v17
	bsl.16b	v31, v25, v28
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v31, v21
	scvtf.4s	v21, v31
	ldr	q17, [sp, #1856]                ; 16-byte Reload
	fmul.4s	v9, v21, v17
	fsub.4s	v3, v3, v9
	fcvtzs.4s	v28, v28
	scvtf.4s	v9, v28
	fmul.4s	v10, v9, v17
	fsub.4s	v2, v2, v10
	ldr	q17, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v9, v9, v17
	fsub.4s	v2, v2, v9
	fmul.4s	v21, v21, v17
	fsub.4s	v3, v3, v21
	mov.16b	v11, v27
	fmul.4s	v21, v3, v27
	ldr	q29, [sp, #1744]                ; 16-byte Reload
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v3, v21
	ldr	q25, [sp, #1808]                ; 16-byte Reload
	fadd.4s	v21, v21, v25
	fmul.4s	v21, v3, v21
	ldr	q17, [sp, #1792]                ; 16-byte Reload
	fadd.4s	v21, v21, v17
	fmul.4s	v21, v3, v21
	fadd.4s	v21, v21, v19
	fmul.4s	v21, v3, v21
	movi.4s	v27, #63, lsl #24
	fadd.4s	v21, v21, v27
	fmul.4s	v9, v3, v3
	fmul.4s	v21, v9, v21
	fmul.4s	v9, v2, v11
	fadd.4s	v9, v9, v29
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v25
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v17
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v19
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v27
	fmul.4s	v10, v2, v2
	fmul.4s	v9, v10, v9
	fadd.4s	v2, v2, v9
	fadd.4s	v3, v3, v21
	fadd.4s	v2, v2, v16
	sshr.4s	v21, v28, #1
	shl.4s	v9, v21, #23
	add.4s	v9, v9, v16
	fmul.4s	v2, v2, v9
	fadd.4s	v3, v3, v16
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v16
	fmul.4s	v3, v3, v10
	sub.4s	v21, v28, v21
	sub.4s	v28, v31, v9
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v16
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v16
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v13
	ldr	q16, [sp, #1872]                ; 16-byte Reload
	bit.16b	v3, v16, v21
	fcmgt.4s	v21, v23, v13
	bit.16b	v2, v16, v21
	fcmeq.4s	v21, v23, v23
	ldr	q16, [sp, #1920]                ; 16-byte Reload
	bif.16b	v2, v16, v21
	str	q2, [sp, #1344]                 ; 16-byte Spill
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v16
	str	q2, [sp, #1328]                 ; 16-byte Spill
	mov.16b	v25, v18
	ldr	q2, [sp, #1296]                 ; 16-byte Reload
	fsub.4s	v2, v2, v18
	and.16b	v23, v1, v2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v13, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1312]                 ; 16-byte Reload
	ldr	q16, [sp, #1760]                ; 16-byte Reload
	fsub.4s	v3, v3, v16
	and.16b	v30, v0, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v13, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	ldr	q17, [sp, #1824]                ; 16-byte Reload
	fmul.4s	v21, v3, v17
	movi.4s	v18, #75, lsl #24
	mvni.4s	v26, #128, lsl #24
	mov.16b	v28, v26
	bsl.16b	v28, v18, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v17
	mov.16b	v31, v26
	bsl.16b	v31, v18, v28
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v31, v21
	scvtf.4s	v21, v31
	ldr	q18, [sp, #1856]                ; 16-byte Reload
	fmul.4s	v9, v21, v18
	fsub.4s	v3, v3, v9
	fcvtzs.4s	v28, v28
	scvtf.4s	v9, v28
	fmul.4s	v10, v9, v18
	fsub.4s	v2, v2, v10
	ldr	q18, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v9, v9, v18
	fsub.4s	v2, v2, v9
	fmul.4s	v21, v21, v18
	fsub.4s	v3, v3, v21
	fmul.4s	v21, v3, v11
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v3, v21
	ldr	q27, [sp, #1808]                ; 16-byte Reload
	fadd.4s	v21, v21, v27
	fmul.4s	v21, v3, v21
	ldr	q26, [sp, #1792]                ; 16-byte Reload
	fadd.4s	v21, v21, v26
	fmul.4s	v21, v3, v21
	mov.16b	v18, v19
	fadd.4s	v21, v21, v19
	fmul.4s	v21, v3, v21
	movi.4s	v10, #63, lsl #24
	fadd.4s	v21, v21, v10
	fmul.4s	v9, v3, v3
	fmul.4s	v21, v9, v21
	fmul.4s	v9, v2, v11
	mov.16b	v19, v11
	fadd.4s	v9, v9, v29
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v27
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v26
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v18
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v10
	fmul.4s	v10, v2, v2
	fmul.4s	v9, v10, v9
	fadd.4s	v2, v2, v9
	fadd.4s	v3, v3, v21
	fmov.4s	v26, #1.00000000
	fadd.4s	v2, v2, v26
	sshr.4s	v21, v28, #1
	shl.4s	v9, v21, #23
	add.4s	v9, v9, v26
	fmul.4s	v2, v2, v9
	fadd.4s	v3, v3, v26
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v26
	fmul.4s	v3, v3, v10
	sub.4s	v21, v28, v21
	sub.4s	v28, v31, v9
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v26
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v26
	fmov.4s	v27, #1.00000000
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v13
	ldr	q26, [sp, #1872]                ; 16-byte Reload
	bit.16b	v3, v26, v21
	fcmgt.4s	v21, v23, v13
	bit.16b	v2, v26, v21
	fcmeq.4s	v21, v23, v23
	ldr	q23, [sp, #1920]                ; 16-byte Reload
	bif.16b	v2, v23, v21
	str	q2, [sp, #1312]                 ; 16-byte Spill
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v23
	str	q2, [sp, #1296]                 ; 16-byte Spill
	ldr	q2, [sp, #1264]                 ; 16-byte Reload
	fsub.4s	v2, v2, v25
	and.16b	v23, v1, v2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v13, v23
	and.16b	v2, v2, v3
	mov.16b	v11, v16
	ldr	q3, [sp, #1280]                 ; 16-byte Reload
	fsub.4s	v3, v3, v16
	and.16b	v30, v0, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v13, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	fmul.4s	v21, v3, v17
	movi.4s	v31, #75, lsl #24
	mvni.4s	v9, #128, lsl #24
	mov.16b	v28, v9
	bsl.16b	v28, v31, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v17
	bif.16b	v31, v28, v9
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v31, v21
	scvtf.4s	v21, v31
	ldr	q16, [sp, #1856]                ; 16-byte Reload
	fmul.4s	v9, v21, v16
	fsub.4s	v3, v3, v9
	fcvtzs.4s	v28, v28
	scvtf.4s	v9, v28
	fmul.4s	v10, v9, v16
	fsub.4s	v2, v2, v10
	ldr	q16, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v9, v9, v16
	fsub.4s	v2, v2, v9
	fmul.4s	v21, v21, v16
	fsub.4s	v3, v3, v21
	fmul.4s	v21, v3, v19
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v3, v21
	ldr	q26, [sp, #1808]                ; 16-byte Reload
	fadd.4s	v21, v21, v26
	fmul.4s	v21, v3, v21
	ldr	q17, [sp, #1792]                ; 16-byte Reload
	fadd.4s	v21, v21, v17
	fmul.4s	v21, v3, v21
	mov.16b	v10, v18
	str	q18, [sp, #1728]                ; 16-byte Spill
	fadd.4s	v21, v21, v18
	fmul.4s	v21, v3, v21
	movi.4s	v16, #63, lsl #24
	fadd.4s	v21, v21, v16
	fmul.4s	v9, v3, v3
	fmul.4s	v21, v9, v21
	fmul.4s	v9, v2, v19
	mov.16b	v18, v19
	fadd.4s	v9, v9, v29
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v26
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v17
	mov.16b	v19, v17
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v10
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v16
	fmul.4s	v10, v2, v2
	fmul.4s	v9, v10, v9
	fadd.4s	v2, v2, v9
	fadd.4s	v3, v3, v21
	fadd.4s	v2, v2, v27
	sshr.4s	v21, v28, #1
	shl.4s	v9, v21, #23
	add.4s	v9, v9, v27
	fmul.4s	v2, v2, v9
	fadd.4s	v3, v3, v27
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v27
	fmul.4s	v3, v3, v10
	sub.4s	v21, v28, v21
	sub.4s	v28, v31, v9
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v27
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v27
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v13
	ldr	q16, [sp, #1872]                ; 16-byte Reload
	bit.16b	v3, v16, v21
	fcmgt.4s	v21, v23, v13
	bit.16b	v2, v16, v21
	fcmeq.4s	v21, v23, v23
	ldr	q16, [sp, #1920]                ; 16-byte Reload
	bif.16b	v2, v16, v21
	str	q2, [sp, #1280]                 ; 16-byte Spill
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v16
	str	q2, [sp, #1264]                 ; 16-byte Spill
	ldr	q2, [sp, #576]                  ; 16-byte Reload
	fsub.4s	v2, v2, v11
	and.16b	v23, v0, v2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v13, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #592]                  ; 16-byte Reload
	fsub.4s	v3, v3, v25
	and.16b	v30, v1, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v13, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	ldr	q26, [sp, #1824]                ; 16-byte Reload
	fmul.4s	v21, v3, v26
	mvni.4s	v16, #128, lsl #24
	movi.4s	v17, #75, lsl #24
	mov.16b	v28, v16
	bsl.16b	v28, v17, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v26
	mov.16b	v31, v16
	bsl.16b	v31, v17, v28
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v31, v21
	scvtf.4s	v21, v31
	ldr	q16, [sp, #1856]                ; 16-byte Reload
	fmul.4s	v9, v21, v16
	fsub.4s	v3, v3, v9
	fcvtzs.4s	v28, v28
	scvtf.4s	v9, v28
	fmul.4s	v10, v9, v16
	fsub.4s	v2, v2, v10
	ldr	q16, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v9, v9, v16
	fsub.4s	v2, v2, v9
	fmul.4s	v21, v21, v16
	fsub.4s	v3, v3, v21
	mov.16b	v26, v18
	fmul.4s	v21, v3, v18
	mov.16b	v10, v29
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v3, v21
	ldr	q18, [sp, #1808]                ; 16-byte Reload
	fadd.4s	v21, v21, v18
	fmul.4s	v21, v3, v21
	fadd.4s	v21, v21, v19
	fmul.4s	v21, v3, v21
	ldr	q17, [sp, #1728]                ; 16-byte Reload
	fadd.4s	v21, v21, v17
	fmul.4s	v21, v3, v21
	movi.4s	v16, #63, lsl #24
	fadd.4s	v21, v21, v16
	fmul.4s	v9, v3, v3
	fmul.4s	v21, v9, v21
	fmul.4s	v9, v2, v26
	mov.16b	v29, v26
	fadd.4s	v9, v9, v10
	mov.16b	v26, v10
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v18
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v19
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v17
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v16
	fmul.4s	v10, v2, v2
	fmul.4s	v9, v10, v9
	fadd.4s	v2, v2, v9
	fadd.4s	v3, v3, v21
	fadd.4s	v2, v2, v27
	sshr.4s	v21, v28, #1
	shl.4s	v9, v21, #23
	add.4s	v9, v9, v27
	fmul.4s	v2, v2, v9
	fadd.4s	v3, v3, v27
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v27
	fmul.4s	v3, v3, v10
	sub.4s	v21, v28, v21
	sub.4s	v28, v31, v9
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v27
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v27
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v13
	ldr	q16, [sp, #1872]                ; 16-byte Reload
	bit.16b	v3, v16, v21
	fcmgt.4s	v21, v23, v13
	bit.16b	v2, v16, v21
	fcmeq.4s	v21, v23, v23
	ldr	q16, [sp, #1920]                ; 16-byte Reload
	bif.16b	v2, v16, v21
	str	q2, [sp, #592]                  ; 16-byte Spill
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v16
	str	q2, [sp, #576]                  ; 16-byte Spill
	ldr	q2, [sp, #512]                  ; 16-byte Reload
	fsub.4s	v2, v2, v11
	and.16b	v23, v0, v2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v13, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #528]                  ; 16-byte Reload
	fsub.4s	v3, v3, v25
	and.16b	v30, v1, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v13, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	ldr	q16, [sp, #1824]                ; 16-byte Reload
	fmul.4s	v21, v3, v16
	movi.4s	v31, #75, lsl #24
	mvni.4s	v9, #128, lsl #24
	mov.16b	v28, v9
	bsl.16b	v28, v31, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v16
	bif.16b	v31, v28, v9
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v31, v21
	scvtf.4s	v21, v31
	ldr	q16, [sp, #1856]                ; 16-byte Reload
	fmul.4s	v9, v21, v16
	fsub.4s	v3, v3, v9
	fcvtzs.4s	v28, v28
	scvtf.4s	v9, v28
	fmul.4s	v10, v9, v16
	fsub.4s	v2, v2, v10
	ldr	q16, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v9, v9, v16
	fsub.4s	v2, v2, v9
	fmul.4s	v21, v21, v16
	fsub.4s	v3, v3, v21
	mov.16b	v16, v29
	fmul.4s	v21, v3, v29
	mov.16b	v10, v26
	fadd.4s	v21, v21, v26
	fmul.4s	v21, v3, v21
	fadd.4s	v21, v21, v18
	fmul.4s	v21, v3, v21
	fadd.4s	v21, v21, v19
	fmul.4s	v21, v3, v21
	fadd.4s	v21, v21, v17
	fmul.4s	v21, v3, v21
	movi.4s	v26, #63, lsl #24
	fadd.4s	v21, v21, v26
	fmul.4s	v9, v3, v3
	fmul.4s	v21, v9, v21
	fmul.4s	v9, v2, v29
	fadd.4s	v9, v9, v10
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v18
	mov.16b	v29, v18
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v19
	mov.16b	v18, v19
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v17
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v26
	fmul.4s	v10, v2, v2
	fmul.4s	v9, v10, v9
	fadd.4s	v2, v2, v9
	fadd.4s	v3, v3, v21
	fadd.4s	v2, v2, v27
	sshr.4s	v21, v28, #1
	shl.4s	v9, v21, #23
	add.4s	v9, v9, v27
	fmul.4s	v2, v2, v9
	fadd.4s	v3, v3, v27
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v27
	fmul.4s	v3, v3, v10
	sub.4s	v21, v28, v21
	sub.4s	v28, v31, v9
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v27
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v27
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v13
	ldr	q19, [sp, #1872]                ; 16-byte Reload
	bit.16b	v3, v19, v21
	fcmgt.4s	v21, v23, v13
	bit.16b	v2, v19, v21
	fcmeq.4s	v21, v23, v23
	ldr	q19, [sp, #1920]                ; 16-byte Reload
	bif.16b	v2, v19, v21
	str	q2, [sp, #528]                  ; 16-byte Spill
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v19
	str	q2, [sp, #512]                  ; 16-byte Spill
	ldr	q2, [sp, #480]                  ; 16-byte Reload
	fsub.4s	v2, v2, v11
	and.16b	v23, v0, v2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v13, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #496]                  ; 16-byte Reload
	fsub.4s	v3, v3, v25
	and.16b	v30, v1, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v13, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	ldr	q26, [sp, #1824]                ; 16-byte Reload
	fmul.4s	v21, v3, v26
	mvni.4s	v19, #128, lsl #24
	movi.4s	v25, #75, lsl #24
	mov.16b	v28, v19
	bsl.16b	v28, v25, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v26
	mov.16b	v31, v19
	bsl.16b	v31, v25, v28
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v31, v21
	scvtf.4s	v21, v31
	ldr	q27, [sp, #1856]                ; 16-byte Reload
	fmul.4s	v9, v21, v27
	fsub.4s	v3, v3, v9
	fcvtzs.4s	v28, v28
	scvtf.4s	v9, v28
	fmul.4s	v10, v9, v27
	fsub.4s	v2, v2, v10
	ldr	q19, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v9, v9, v19
	fsub.4s	v2, v2, v9
	fmul.4s	v21, v21, v19
	fsub.4s	v3, v3, v21
	fmul.4s	v21, v3, v16
	ldr	q19, [sp, #1744]                ; 16-byte Reload
	fadd.4s	v21, v21, v19
	fmul.4s	v21, v3, v21
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v3, v21
	mov.16b	v10, v18
	fadd.4s	v21, v21, v18
	fmul.4s	v21, v3, v21
	mov.16b	v25, v17
	fadd.4s	v21, v21, v17
	fmul.4s	v21, v3, v21
	movi.4s	v17, #63, lsl #24
	fadd.4s	v21, v21, v17
	fmul.4s	v9, v3, v3
	fmul.4s	v21, v9, v21
	fmul.4s	v9, v2, v16
	mov.16b	v18, v16
	fadd.4s	v9, v9, v19
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v29
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v10
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v25
	mov.16b	v29, v25
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v17
	fmul.4s	v10, v2, v2
	fmul.4s	v9, v10, v9
	fadd.4s	v2, v2, v9
	fadd.4s	v3, v3, v21
	fmov.4s	v16, #1.00000000
	fadd.4s	v2, v2, v16
	sshr.4s	v21, v28, #1
	shl.4s	v9, v21, #23
	add.4s	v9, v9, v16
	fmul.4s	v2, v2, v9
	fadd.4s	v3, v3, v16
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v16
	fmul.4s	v3, v3, v10
	sub.4s	v21, v28, v21
	sub.4s	v28, v31, v9
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v16
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v16
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v13
	ldr	q16, [sp, #1872]                ; 16-byte Reload
	bit.16b	v3, v16, v21
	fcmgt.4s	v21, v23, v13
	bit.16b	v2, v16, v21
	fcmeq.4s	v21, v23, v23
	ldr	q16, [sp, #1920]                ; 16-byte Reload
	bif.16b	v2, v16, v21
	str	q2, [sp, #496]                  ; 16-byte Spill
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v16
	str	q2, [sp, #480]                  ; 16-byte Spill
	ldr	q2, [sp, #544]                  ; 16-byte Reload
	ldr	q11, [sp, #1760]                ; 16-byte Reload
	fsub.4s	v2, v2, v11
	and.16b	v23, v0, v2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v13, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #560]                  ; 16-byte Reload
	ldr	q17, [sp, #1776]                ; 16-byte Reload
	fsub.4s	v3, v3, v17
	and.16b	v30, v1, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v13, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	fmul.4s	v21, v3, v26
	movi.4s	v25, #75, lsl #24
	mvni.4s	v31, #128, lsl #24
	mov.16b	v28, v31
	bsl.16b	v28, v25, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v26
	bsl.16b	v31, v25, v28
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v31, v21
	scvtf.4s	v21, v31
	fmul.4s	v9, v21, v27
	fsub.4s	v3, v3, v9
	fcvtzs.4s	v28, v28
	scvtf.4s	v9, v28
	fmul.4s	v10, v9, v27
	fsub.4s	v2, v2, v10
	ldr	q16, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v9, v9, v16
	fsub.4s	v2, v2, v9
	fmul.4s	v21, v21, v16
	fsub.4s	v3, v3, v21
	str	q18, [sp, #1664]                ; 16-byte Spill
	fmul.4s	v21, v3, v18
	fadd.4s	v21, v21, v19
	fmul.4s	v21, v3, v21
	ldr	q27, [sp, #1808]                ; 16-byte Reload
	fadd.4s	v21, v21, v27
	fmul.4s	v21, v3, v21
	ldr	q25, [sp, #1792]                ; 16-byte Reload
	fadd.4s	v21, v21, v25
	fmul.4s	v21, v3, v21
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v3, v21
	movi.4s	v10, #63, lsl #24
	fadd.4s	v21, v21, v10
	fmul.4s	v9, v3, v3
	fmul.4s	v21, v9, v21
	fmul.4s	v9, v2, v18
	fadd.4s	v9, v9, v19
	mov.16b	v16, v19
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v27
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v25
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v29
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v10
	fmul.4s	v10, v2, v2
	fmul.4s	v9, v10, v9
	fadd.4s	v2, v2, v9
	fadd.4s	v3, v3, v21
	fmov.4s	v18, #1.00000000
	fadd.4s	v2, v2, v18
	sshr.4s	v21, v28, #1
	shl.4s	v9, v21, #23
	add.4s	v9, v9, v18
	fmul.4s	v2, v2, v9
	fadd.4s	v3, v3, v18
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v18
	fmul.4s	v3, v3, v10
	sub.4s	v21, v28, v21
	sub.4s	v28, v31, v9
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v18
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v18
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v13
	ldr	q19, [sp, #1872]                ; 16-byte Reload
	bit.16b	v3, v19, v21
	fcmgt.4s	v21, v23, v13
	bit.16b	v2, v19, v21
	fcmeq.4s	v21, v23, v23
	ldr	q19, [sp, #1920]                ; 16-byte Reload
	bif.16b	v2, v19, v21
	str	q2, [sp, #560]                  ; 16-byte Spill
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v19
	str	q2, [sp, #544]                  ; 16-byte Spill
	ldr	q2, [sp, #608]                  ; 16-byte Reload
	fsub.4s	v2, v2, v17
	and.16b	v23, v1, v2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v13, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #624]                  ; 16-byte Reload
	fsub.4s	v3, v3, v11
	mov.16b	v19, v11
	and.16b	v30, v0, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v13, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	fmul.4s	v21, v3, v26
	mvni.4s	v17, #128, lsl #24
	movi.4s	v25, #75, lsl #24
	mov.16b	v28, v17
	bsl.16b	v28, v25, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v26
	mov.16b	v31, v17
	bsl.16b	v31, v25, v28
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v31, v21
	scvtf.4s	v21, v31
	ldr	q17, [sp, #1856]                ; 16-byte Reload
	fmul.4s	v9, v21, v17
	fsub.4s	v3, v3, v9
	fcvtzs.4s	v28, v28
	scvtf.4s	v9, v28
	fmul.4s	v10, v9, v17
	fsub.4s	v2, v2, v10
	ldr	q17, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v9, v9, v17
	fsub.4s	v2, v2, v9
	fmul.4s	v21, v21, v17
	fsub.4s	v3, v3, v21
	ldr	q11, [sp, #1664]                ; 16-byte Reload
	fmul.4s	v21, v3, v11
	mov.16b	v25, v16
	fadd.4s	v21, v21, v16
	fmul.4s	v21, v3, v21
	mov.16b	v10, v27
	fadd.4s	v21, v21, v27
	fmul.4s	v21, v3, v21
	ldr	q27, [sp, #1792]                ; 16-byte Reload
	fadd.4s	v21, v21, v27
	fmul.4s	v21, v3, v21
	mov.16b	v17, v29
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v3, v21
	movi.4s	v16, #63, lsl #24
	fadd.4s	v21, v21, v16
	fmul.4s	v9, v3, v3
	fmul.4s	v21, v9, v21
	fmul.4s	v9, v2, v11
	fadd.4s	v9, v9, v25
	mov.16b	v29, v25
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v10
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v27
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v17
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v16
	fmul.4s	v10, v2, v2
	fmul.4s	v9, v10, v9
	fadd.4s	v2, v2, v9
	fadd.4s	v3, v3, v21
	fadd.4s	v2, v2, v18
	sshr.4s	v21, v28, #1
	shl.4s	v9, v21, #23
	add.4s	v9, v9, v18
	fmul.4s	v2, v2, v9
	fadd.4s	v3, v3, v18
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v18
	fmul.4s	v3, v3, v10
	sub.4s	v21, v28, v21
	sub.4s	v28, v31, v9
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v18
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v18
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v13
	ldr	q16, [sp, #1872]                ; 16-byte Reload
	bit.16b	v3, v16, v21
	fcmgt.4s	v21, v23, v13
	bit.16b	v2, v16, v21
	fcmeq.4s	v21, v23, v23
	ldr	q16, [sp, #1920]                ; 16-byte Reload
	bif.16b	v2, v16, v21
	str	q2, [sp, #624]                  ; 16-byte Spill
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v16
	str	q2, [sp, #608]                  ; 16-byte Spill
	ldr	q2, [sp, #656]                  ; 16-byte Reload
	ldr	q16, [sp, #1776]                ; 16-byte Reload
	fsub.4s	v2, v2, v16
	and.16b	v23, v1, v2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v13, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #672]                  ; 16-byte Reload
	fsub.4s	v3, v3, v19
	mov.16b	v11, v19
	and.16b	v30, v0, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v13, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	fmul.4s	v21, v3, v26
	movi.4s	v31, #75, lsl #24
	mvni.4s	v25, #128, lsl #24
	mov.16b	v28, v25
	bsl.16b	v28, v31, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v26
	bif.16b	v31, v28, v25
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v31, v21
	scvtf.4s	v21, v31
	ldr	q18, [sp, #1856]                ; 16-byte Reload
	fmul.4s	v9, v21, v18
	fsub.4s	v3, v3, v9
	fcvtzs.4s	v28, v28
	scvtf.4s	v9, v28
	fmul.4s	v10, v9, v18
	fsub.4s	v2, v2, v10
	ldr	q18, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v9, v9, v18
	fsub.4s	v2, v2, v9
	fmul.4s	v21, v21, v18
	fsub.4s	v3, v3, v21
	ldr	q10, [sp, #1664]                ; 16-byte Reload
	fmul.4s	v21, v3, v10
	mov.16b	v19, v29
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v3, v21
	ldr	q27, [sp, #1808]                ; 16-byte Reload
	fadd.4s	v21, v21, v27
	fmul.4s	v21, v3, v21
	ldr	q18, [sp, #1792]                ; 16-byte Reload
	fadd.4s	v21, v21, v18
	fmul.4s	v21, v3, v21
	mov.16b	v25, v17
	fadd.4s	v21, v21, v17
	fmul.4s	v21, v3, v21
	movi.4s	v26, #63, lsl #24
	fadd.4s	v21, v21, v26
	fmul.4s	v9, v3, v3
	fmul.4s	v21, v9, v21
	fmul.4s	v9, v2, v10
	mov.16b	v17, v10
	fadd.4s	v9, v9, v29
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v27
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v18
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v25
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v26
	fmul.4s	v10, v2, v2
	fmul.4s	v9, v10, v9
	fadd.4s	v2, v2, v9
	fadd.4s	v3, v3, v21
	fmov.4s	v18, #1.00000000
	fadd.4s	v2, v2, v18
	sshr.4s	v21, v28, #1
	shl.4s	v9, v21, #23
	add.4s	v9, v9, v18
	fmul.4s	v2, v2, v9
	fadd.4s	v3, v3, v18
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v18
	fmul.4s	v3, v3, v10
	sub.4s	v21, v28, v21
	sub.4s	v28, v31, v9
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v18
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v18
	fmov.4s	v29, #1.00000000
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v13
	ldr	q25, [sp, #1872]                ; 16-byte Reload
	bit.16b	v3, v25, v21
	fcmgt.4s	v21, v23, v13
	bit.16b	v2, v25, v21
	fcmeq.4s	v21, v23, v23
	ldr	q18, [sp, #1920]                ; 16-byte Reload
	bif.16b	v2, v18, v21
	str	q2, [sp, #672]                  ; 16-byte Spill
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v18
	str	q2, [sp, #656]                  ; 16-byte Spill
	ldr	q2, [sp, #688]                  ; 16-byte Reload
	fsub.4s	v2, v2, v16
	and.16b	v23, v1, v2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v13, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #704]                  ; 16-byte Reload
	mov.16b	v27, v11
	fsub.4s	v3, v3, v11
	and.16b	v30, v0, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v13, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	ldr	q11, [sp, #1824]                ; 16-byte Reload
	fmul.4s	v21, v3, v11
	mvni.4s	v18, #128, lsl #24
	movi.4s	v26, #75, lsl #24
	mov.16b	v28, v18
	bsl.16b	v28, v26, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v11
	mov.16b	v31, v18
	bsl.16b	v31, v26, v28
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v31, v21
	scvtf.4s	v21, v31
	ldr	q16, [sp, #1856]                ; 16-byte Reload
	fmul.4s	v9, v21, v16
	fsub.4s	v3, v3, v9
	fcvtzs.4s	v28, v28
	scvtf.4s	v9, v28
	fmul.4s	v10, v9, v16
	fsub.4s	v2, v2, v10
	ldr	q16, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v9, v9, v16
	fsub.4s	v2, v2, v9
	fmul.4s	v21, v21, v16
	fsub.4s	v3, v3, v21
	mov.16b	v18, v17
	fmul.4s	v21, v3, v17
	mov.16b	v10, v19
	fadd.4s	v21, v21, v19
	fmul.4s	v21, v3, v21
	ldr	q17, [sp, #1808]                ; 16-byte Reload
	fadd.4s	v21, v21, v17
	fmul.4s	v21, v3, v21
	ldr	q26, [sp, #1792]                ; 16-byte Reload
	fadd.4s	v21, v21, v26
	fmul.4s	v21, v3, v21
	ldr	q19, [sp, #1728]                ; 16-byte Reload
	fadd.4s	v21, v21, v19
	fmul.4s	v21, v3, v21
	movi.4s	v16, #63, lsl #24
	fadd.4s	v21, v21, v16
	fmul.4s	v9, v3, v3
	fmul.4s	v21, v9, v21
	fmul.4s	v9, v2, v18
	fadd.4s	v9, v9, v10
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v17
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v26
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v19
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v16
	fmul.4s	v10, v2, v2
	fmul.4s	v9, v10, v9
	fadd.4s	v2, v2, v9
	fadd.4s	v3, v3, v21
	fadd.4s	v2, v2, v29
	sshr.4s	v21, v28, #1
	shl.4s	v9, v21, #23
	add.4s	v9, v9, v29
	fmul.4s	v2, v2, v9
	fadd.4s	v3, v3, v29
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v29
	fmul.4s	v3, v3, v10
	sub.4s	v21, v28, v21
	sub.4s	v28, v31, v9
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v29
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v29
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v13
	bit.16b	v3, v25, v21
	fcmgt.4s	v21, v23, v13
	bit.16b	v2, v25, v21
	fcmeq.4s	v21, v23, v23
	ldr	q16, [sp, #1920]                ; 16-byte Reload
	bif.16b	v2, v16, v21
	str	q2, [sp, #704]                  ; 16-byte Spill
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v16
	str	q2, [sp, #688]                  ; 16-byte Spill
	ldr	q2, [sp, #720]                  ; 16-byte Reload
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v23, v1, v2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v13, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #736]                  ; 16-byte Reload
	fsub.4s	v3, v3, v27
	and.16b	v30, v0, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v13, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	fmul.4s	v21, v3, v11
	movi.4s	v25, #75, lsl #24
	mvni.4s	v31, #128, lsl #24
	mov.16b	v28, v31
	bsl.16b	v28, v25, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v11
	bsl.16b	v31, v25, v28
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v31, v21
	scvtf.4s	v21, v31
	ldr	q16, [sp, #1856]                ; 16-byte Reload
	fmul.4s	v9, v21, v16
	fsub.4s	v3, v3, v9
	fcvtzs.4s	v28, v28
	scvtf.4s	v9, v28
	fmul.4s	v10, v9, v16
	fsub.4s	v2, v2, v10
	ldr	q16, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v9, v9, v16
	fsub.4s	v2, v2, v9
	fmul.4s	v21, v21, v16
	fsub.4s	v3, v3, v21
	mov.16b	v26, v18
	fmul.4s	v21, v3, v18
	ldr	q27, [sp, #1744]                ; 16-byte Reload
	fadd.4s	v21, v21, v27
	fmul.4s	v21, v3, v21
	ldr	q18, [sp, #1808]                ; 16-byte Reload
	fadd.4s	v21, v21, v18
	fmul.4s	v21, v3, v21
	ldr	q17, [sp, #1792]                ; 16-byte Reload
	fadd.4s	v21, v21, v17
	fmul.4s	v21, v3, v21
	ldr	q11, [sp, #1728]                ; 16-byte Reload
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v3, v21
	movi.4s	v10, #63, lsl #24
	fadd.4s	v21, v21, v10
	fmul.4s	v9, v3, v3
	fmul.4s	v21, v9, v21
	fmul.4s	v9, v2, v26
	fadd.4s	v9, v9, v27
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v18
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v17
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v11
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v10
	fmul.4s	v10, v2, v2
	fmul.4s	v9, v10, v9
	fadd.4s	v2, v2, v9
	fadd.4s	v3, v3, v21
	fadd.4s	v2, v2, v29
	sshr.4s	v21, v28, #1
	shl.4s	v9, v21, #23
	add.4s	v9, v9, v29
	fmul.4s	v2, v2, v9
	fadd.4s	v3, v3, v29
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v29
	fmul.4s	v3, v3, v10
	sub.4s	v21, v28, v21
	sub.4s	v28, v31, v9
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v29
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v29
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v13
	ldr	q19, [sp, #1872]                ; 16-byte Reload
	bit.16b	v3, v19, v21
	fcmgt.4s	v21, v23, v13
	bit.16b	v2, v19, v21
	fcmeq.4s	v21, v23, v23
	ldr	q19, [sp, #1920]                ; 16-byte Reload
	bif.16b	v2, v19, v21
	str	q2, [sp, #736]                  ; 16-byte Spill
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v19
	str	q2, [sp, #720]                  ; 16-byte Spill
	ldr	q2, [sp, #752]                  ; 16-byte Reload
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v23, v0, v2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v13, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #768]                  ; 16-byte Reload
	ldr	q25, [sp, #1776]                ; 16-byte Reload
	fsub.4s	v3, v3, v25
	and.16b	v30, v1, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v13, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	ldr	q31, [sp, #1824]                ; 16-byte Reload
	fmul.4s	v21, v3, v31
	mvni.4s	v19, #128, lsl #24
	movi.4s	v29, #75, lsl #24
	mov.16b	v28, v19
	bsl.16b	v28, v29, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v31
	mov.16b	v31, v19
	bsl.16b	v31, v29, v28
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v31, v21
	scvtf.4s	v21, v31
	ldr	q29, [sp, #1856]                ; 16-byte Reload
	fmul.4s	v9, v21, v29
	fsub.4s	v3, v3, v9
	fcvtzs.4s	v28, v28
	scvtf.4s	v9, v28
	fmul.4s	v10, v9, v29
	fsub.4s	v2, v2, v10
	ldr	q19, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v9, v9, v19
	fsub.4s	v2, v2, v9
	fmul.4s	v21, v21, v19
	fsub.4s	v3, v3, v21
	fmul.4s	v21, v3, v26
	fadd.4s	v21, v21, v27
	fmul.4s	v21, v3, v21
	fadd.4s	v21, v21, v18
	fmul.4s	v21, v3, v21
	fadd.4s	v21, v21, v17
	fmul.4s	v21, v3, v21
	mov.16b	v10, v11
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v3, v21
	movi.4s	v11, #63, lsl #24
	fadd.4s	v21, v21, v11
	fmul.4s	v9, v3, v3
	fmul.4s	v21, v9, v21
	fmul.4s	v9, v2, v26
	fadd.4s	v9, v9, v27
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v18
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v17
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v10
	mov.16b	v19, v10
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v11
	fmul.4s	v10, v2, v2
	fmul.4s	v9, v10, v9
	fadd.4s	v2, v2, v9
	fadd.4s	v3, v3, v21
	fmov.4s	v11, #1.00000000
	fadd.4s	v2, v2, v11
	sshr.4s	v21, v28, #1
	shl.4s	v9, v21, #23
	add.4s	v9, v9, v11
	fmul.4s	v2, v2, v9
	fadd.4s	v3, v3, v11
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v11
	fmul.4s	v3, v3, v10
	sub.4s	v21, v28, v21
	sub.4s	v28, v31, v9
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v11
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v11
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v13
	ldr	q28, [sp, #1872]                ; 16-byte Reload
	bit.16b	v3, v28, v21
	fcmgt.4s	v21, v23, v13
	mov.16b	v16, v13
	bit.16b	v2, v28, v21
	fcmeq.4s	v21, v23, v23
	ldr	q23, [sp, #1920]                ; 16-byte Reload
	bif.16b	v2, v23, v21
	str	q2, [sp, #464]                  ; 16-byte Spill
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v23
	str	q2, [sp, #432]                  ; 16-byte Spill
	ldr	q2, [sp, #800]                  ; 16-byte Reload
	fsub.4s	v2, v2, v25
	and.16b	v23, v1, v2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v13, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #816]                  ; 16-byte Reload
	ldr	q25, [sp, #1760]                ; 16-byte Reload
	fsub.4s	v3, v3, v25
	and.16b	v30, v0, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v13, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	ldr	q9, [sp, #1824]                 ; 16-byte Reload
	fmul.4s	v21, v3, v9
	movi.4s	v31, #75, lsl #24
	mvni.4s	v10, #128, lsl #24
	mov.16b	v28, v10
	bsl.16b	v28, v31, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v9
	bif.16b	v31, v28, v10
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v31, v21
	scvtf.4s	v21, v31
	fmul.4s	v9, v21, v29
	fsub.4s	v3, v3, v9
	fcvtzs.4s	v28, v28
	scvtf.4s	v9, v28
	fmul.4s	v10, v9, v29
	fsub.4s	v2, v2, v10
	ldr	q29, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v9, v9, v29
	fsub.4s	v2, v2, v9
	fmul.4s	v21, v21, v29
	fsub.4s	v3, v3, v21
	mov.16b	v13, v26
	fmul.4s	v21, v3, v26
	fadd.4s	v21, v21, v27
	fmul.4s	v21, v3, v21
	fadd.4s	v21, v21, v18
	fmul.4s	v21, v3, v21
	fadd.4s	v21, v21, v17
	fmul.4s	v21, v3, v21
	fadd.4s	v21, v21, v19
	fmul.4s	v21, v3, v21
	movi.4s	v26, #63, lsl #24
	fadd.4s	v21, v21, v26
	fmul.4s	v9, v3, v3
	fmul.4s	v21, v9, v21
	fmul.4s	v9, v2, v13
	fadd.4s	v9, v9, v27
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v18
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v17
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v19
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v26
	fmul.4s	v10, v2, v2
	fmul.4s	v9, v10, v9
	fadd.4s	v2, v2, v9
	fadd.4s	v3, v3, v21
	fadd.4s	v2, v2, v11
	sshr.4s	v21, v28, #1
	shl.4s	v9, v21, #23
	add.4s	v9, v9, v11
	fmul.4s	v2, v2, v9
	fadd.4s	v3, v3, v11
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v11
	fmul.4s	v3, v3, v10
	sub.4s	v21, v28, v21
	sub.4s	v28, v31, v9
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v11
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v11
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v16
	ldr	q26, [sp, #1872]                ; 16-byte Reload
	bit.16b	v3, v26, v21
	fcmgt.4s	v21, v23, v16
	bit.16b	v2, v26, v21
	fcmeq.4s	v21, v23, v23
	ldr	q18, [sp, #1920]                ; 16-byte Reload
	bif.16b	v2, v18, v21
	str	q2, [sp, #384]                  ; 16-byte Spill
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v18
	str	q2, [sp, #368]                  ; 16-byte Spill
	ldr	q2, [sp, #832]                  ; 16-byte Reload
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v23, v1, v2
	fcmge.4s	v2, v23, v8
	fcmge.4s	v3, v16, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #848]                  ; 16-byte Reload
	fsub.4s	v3, v3, v25
	and.16b	v30, v0, v3
	fcmge.4s	v3, v30, v8
	fcmge.4s	v21, v16, v30
	and.16b	v3, v3, v21
	and.16b	v3, v3, v30
	ldr	q31, [sp, #1824]                ; 16-byte Reload
	fmul.4s	v21, v3, v31
	mvni.4s	v25, #128, lsl #24
	movi.4s	v29, #75, lsl #24
	mov.16b	v28, v25
	bsl.16b	v28, v29, v21
	fadd.4s	v21, v21, v28
	fsub.4s	v21, v21, v28
	and.16b	v2, v2, v23
	fmul.4s	v28, v2, v31
	mov.16b	v31, v25
	bsl.16b	v31, v29, v28
	fadd.4s	v28, v28, v31
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v31, v21
	scvtf.4s	v21, v31
	ldr	q25, [sp, #1856]                ; 16-byte Reload
	fmul.4s	v9, v21, v25
	fsub.4s	v3, v3, v9
	fcvtzs.4s	v28, v28
	scvtf.4s	v9, v28
	fmul.4s	v10, v9, v25
	fsub.4s	v2, v2, v10
	ldr	q25, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v21, v21, v25
	fmul.4s	v9, v9, v25
	fsub.4s	v2, v2, v9
	fsub.4s	v3, v3, v21
	fmul.4s	v21, v3, v13
	mov.16b	v10, v27
	fadd.4s	v21, v21, v27
	fmul.4s	v21, v3, v21
	ldr	q27, [sp, #1808]                ; 16-byte Reload
	fadd.4s	v21, v21, v27
	fmul.4s	v21, v3, v21
	fadd.4s	v21, v21, v17
	fmul.4s	v21, v3, v21
	mov.16b	v25, v19
	fadd.4s	v21, v21, v19
	fmul.4s	v21, v3, v21
	movi.4s	v19, #63, lsl #24
	fadd.4s	v21, v21, v19
	fmul.4s	v9, v3, v3
	fmul.4s	v21, v9, v21
	fmul.4s	v9, v2, v13
	fadd.4s	v9, v9, v10
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v27
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v17
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v25
	fmul.4s	v9, v2, v9
	fadd.4s	v9, v9, v19
	fmul.4s	v10, v2, v2
	fmul.4s	v9, v10, v9
	fadd.4s	v2, v2, v9
	fadd.4s	v3, v3, v21
	fadd.4s	v2, v2, v11
	sshr.4s	v21, v28, #1
	shl.4s	v9, v21, #23
	add.4s	v9, v9, v11
	fmul.4s	v2, v2, v9
	fadd.4s	v3, v3, v11
	sshr.4s	v9, v31, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v11
	fmul.4s	v3, v3, v10
	sub.4s	v21, v28, v21
	sub.4s	v28, v31, v9
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v11
	fmul.4s	v3, v3, v28
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v11
	fmul.4s	v2, v2, v21
	fcmgt.4s	v21, v8, v23
	bic.16b	v2, v2, v21
	stp	q16, q8, [sp, #400]             ; 32-byte Folded Spill
	fcmgt.4s	v21, v8, v30
	bic.16b	v3, v3, v21
	fcmgt.4s	v21, v30, v16
	bit.16b	v3, v26, v21
	fcmgt.4s	v21, v23, v16
	bit.16b	v2, v26, v21
	fcmeq.4s	v21, v23, v23
	mov.16b	v29, v21
	bsl.16b	v29, v2, v18
	fcmeq.4s	v2, v30, v30
	bsl.16b	v2, v3, v18
	str	q2, [sp, #320]                  ; 16-byte Spill
	ldr	d16, [sp, #864]                 ; 8-byte Reload
	zip1.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #576]                  ; 16-byte Reload
	and.16b	v23, v2, v3
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #592]                  ; 16-byte Reload
	and.16b	v25, v2, v3
	zip1.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #512]                  ; 16-byte Reload
	and.16b	v26, v2, v3
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #528]                  ; 16-byte Reload
	and.16b	v27, v2, v3
	zip1.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #480]                  ; 16-byte Reload
	and.16b	v28, v2, v3
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #496]                  ; 16-byte Reload
	and.16b	v30, v2, v3
	zip1.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #544]                  ; 16-byte Reload
	and.16b	v8, v2, v3
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #560]                  ; 16-byte Reload
	and.16b	v9, v2, v3
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #608]                  ; 16-byte Reload
	and.16b	v11, v2, v3
	zip1.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #624]                  ; 16-byte Reload
	and.16b	v13, v2, v3
	mov	w2, #33792                      ; =0x8400
	movk	w2, #1, lsl #16
	add	x2, x10, x2
	ldr	q2, [x2, #16]
	ldr	q3, [sp, #1392]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	ldr	q3, [x2]
	ldr	q21, [sp, #1408]                ; 16-byte Reload
	bit.16b	v3, v21, v1
	stp	q3, q2, [x2]
	ldp	x2, x3, [sp, #144]              ; 16-byte Folded Reload
	ldr	q2, [x3, #16]
	ldr	q3, [sp, #1360]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	ldr	q3, [x3]
	ldr	q21, [sp, #1376]                ; 16-byte Reload
	bit.16b	v3, v21, v1
	stp	q3, q2, [x3]
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #656]                  ; 16-byte Reload
	and.16b	v17, v2, v3
	ldr	q2, [x2, #16]
	ldr	q3, [sp, #1328]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	ldr	q3, [x2]
	ldr	q21, [sp, #1344]                ; 16-byte Reload
	bit.16b	v3, v21, v1
	stp	q3, q2, [x2]
	zip1.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #672]                  ; 16-byte Reload
	and.16b	v31, v2, v3
	ldp	x2, x4, [sp, #128]              ; 16-byte Folded Reload
	ldr	q2, [x4, #16]
	ldr	q3, [sp, #1296]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	ldr	q3, [x4]
	ldr	q21, [sp, #1312]                ; 16-byte Reload
	bit.16b	v3, v21, v1
	stp	q3, q2, [x4]
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #688]                  ; 16-byte Reload
	and.16b	v10, v2, v3
	ldr	q2, [x2, #16]
	ldr	q3, [sp, #1264]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	ldr	q3, [x2]
	ldr	q21, [sp, #1280]                ; 16-byte Reload
	bit.16b	v3, v21, v1
	stp	q3, q2, [x2]
	zip1.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #704]                  ; 16-byte Reload
	and.16b	v21, v2, v3
	ldp	x2, x5, [sp, #112]              ; 16-byte Folded Reload
	ldp	q3, q2, [x5]
	str	q25, [sp, #1856]                ; 16-byte Spill
	bit.16b	v2, v25, v0
	str	q23, [sp, #1904]                ; 16-byte Spill
	bit.16b	v3, v23, v1
	stp	q3, q2, [x5]
	ldp	q3, q2, [x2]
	stp	q27, q26, [sp, #832]            ; 32-byte Folded Spill
	bit.16b	v2, v27, v0
	bit.16b	v3, v26, v1
	stp	q3, q2, [x2]
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #720]                  ; 16-byte Reload
	and.16b	v23, v2, v3
	ldp	x2, x6, [sp, #96]               ; 16-byte Folded Reload
	ldp	q3, q2, [x6]
	stp	q30, q28, [sp, #800]            ; 32-byte Folded Spill
	bit.16b	v2, v30, v0
	bit.16b	v3, v28, v1
	stp	q3, q2, [x6]
	zip1.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #736]                  ; 16-byte Reload
	and.16b	v25, v2, v3
	ldp	q3, q2, [x2]
	stp	q9, q8, [sp, #752]              ; 32-byte Folded Spill
	bit.16b	v2, v9, v0
	bit.16b	v3, v8, v1
	stp	q3, q2, [x2]
	zip1.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #432]                  ; 16-byte Reload
	and.16b	v26, v2, v3
	ldr	x2, [sp, #88]                   ; 8-byte Reload
	ldp	q2, q3, [x2]
	stp	q13, q11, [sp, #720]            ; 32-byte Folded Spill
	bit.16b	v2, v13, v1
	bit.16b	v3, v11, v0
	stp	q2, q3, [x2]
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #464]                  ; 16-byte Reload
	and.16b	v18, v2, v3
	ldp	q2, q3, [x7]
	stp	q31, q17, [sp, #688]            ; 32-byte Folded Spill
	bit.16b	v2, v31, v1
	bit.16b	v3, v17, v0
	stp	q2, q3, [x7]
	ldp	q2, q3, [x19]
	stp	q21, q10, [sp, #656]            ; 32-byte Folded Spill
	bit.16b	v2, v21, v1
	bit.16b	v3, v10, v0
	stp	q2, q3, [x19]
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #368]                  ; 16-byte Reload
	and.16b	v17, v2, v3
	ldp	q2, q3, [x20]
	stp	q25, q23, [sp, #608]            ; 32-byte Folded Spill
	bit.16b	v2, v25, v1
	bit.16b	v3, v23, v0
	stp	q2, q3, [x20]
	zip1.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #384]                  ; 16-byte Reload
	and.16b	v21, v2, v3
	ldp	q3, q2, [x21]
	stp	q18, q26, [sp, #576]            ; 32-byte Folded Spill
	bit.16b	v2, v18, v0
	bit.16b	v3, v26, v1
	stp	q3, q2, [x21]
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #320]                  ; 16-byte Reload
	and.16b	v18, v2, v3
	ldp	q2, q3, [x22]
	stp	q21, q17, [sp, #544]            ; 32-byte Folded Spill
	bit.16b	v2, v21, v1
	bit.16b	v3, v17, v0
	stp	q2, q3, [x22]
	zip1.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v3, v2, v29
	ldr	q2, [x23]
	str	q3, [sp, #528]                  ; 16-byte Spill
	bit.16b	v2, v3, v1
	ldr	q3, [x23, #16]
	str	q18, [sp, #864]                 ; 16-byte Spill
	bit.16b	v3, v18, v0
	stp	q2, q3, [x23]
	mov	x2, x13
	ldr	q9, [sp, #1888]                 ; 16-byte Reload
	ldr	q28, [sp, #1840]                ; 16-byte Reload
	ldr	q25, [sp, #1136]                ; 16-byte Reload
	ldr	q8, [sp, #1456]                 ; 16-byte Reload
	ldr	q13, [sp, #1440]                ; 16-byte Reload
	ldr	q16, [sp, #1424]                ; 16-byte Reload
	ldr	q26, [sp, #640]                 ; 16-byte Reload
	ldr	q27, [sp, #1248]                ; 16-byte Reload
LBB0_95:                                ; %direct.true725
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_96 Depth 3
	mov	x3, #0                          ; =0x0
	umulh	x4, x1, x30
	lsr	x5, x4, #6
	add	x4, x24, x5, lsl #5
	madd	x5, x5, x9, x2
	and.16b	v15, v9, v15
	and.16b	v14, v28, v14
LBB0_96:                                ; %direct.true728
                                        ;   Parent Loop BB0_22 Depth=1
                                        ;     Parent Loop BB0_95 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x6, x4, x3
	ldp	q2, q3, [x6]
	ldp	q21, q23, [x5]
	fmul.4s	v3, v3, v23
	fmul.4s	v2, v2, v21
	fadd.4s	v23, v14, v2
	fadd.4s	v30, v15, v3
	bit.16b	v15, v30, v0
	bit.16b	v14, v23, v1
	add	x3, x3, #32
	add	x5, x5, #3072
	cmp	x3, #512
	b.ne	LBB0_96
; %bb.97:                               ; %direct.false729
                                        ;   in Loop: Header=BB0_95 Depth=2
	add	x3, x15, x1, lsl #5
	ldp	q2, q3, [x3]
	bit.16b	v3, v30, v0
	bit.16b	v2, v23, v1
	stp	q2, q3, [x3]
	add	x1, x1, #1
	add	x2, x2, #32
	cmp	x1, #96
	b.ne	LBB0_95
; %bb.98:                               ; %direct.schedule.79.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x1, #0                          ; =0x0
	ldr	q2, [sp, #1712]                 ; 16-byte Reload
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	fsub.4s	v30, v2, v3
	ldr	q2, [sp, #1696]                 ; 16-byte Reload
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	fsub.4s	v23, v2, v3
	and.16b	v23, v1, v23
	and.16b	v30, v0, v30
	ldp	q17, q28, [sp, #400]            ; 32-byte Folded Reload
	fcmge.4s	v31, v30, v28
	fcmge.4s	v9, v23, v28
	fcmge.4s	v10, v17, v30
	fcmge.4s	v11, v17, v23
	and.16b	v9, v9, v11
	and.16b	v31, v31, v10
	and.16b	v31, v31, v30
	and.16b	v9, v9, v23
	ldr	q2, [sp, #1824]                 ; 16-byte Reload
	fmul.4s	v10, v9, v2
	fmul.4s	v11, v31, v2
	movi.4s	v2, #75, lsl #24
	mvni.4s	v3, #128, lsl #24
	mov.16b	v21, v3
	bsl.16b	v21, v2, v11
	bif.16b	v2, v10, v3
	fadd.4s	v10, v10, v2
	fadd.4s	v11, v11, v21
	fsub.4s	v21, v11, v21
	fsub.4s	v2, v10, v2
	fcvtzs.4s	v18, v2
	fcvtzs.4s	v21, v21
	scvtf.4s	v10, v21
	mov	w2, #29184                      ; =0x7200
	movk	w2, #48945, lsl #16
	dup.4s	v11, w2
	fmul.4s	v2, v10, v11
	fadd.4s	v2, v31, v2
	scvtf.4s	v31, v18
	fmul.4s	v11, v31, v11
	fadd.4s	v9, v9, v11
	mov	w2, #48782                      ; =0xbe8e
	movk	w2, #46527, lsl #16
	dup.4s	v11, w2
	fmul.4s	v10, v10, v11
	fmul.4s	v31, v31, v11
	fadd.4s	v31, v9, v31
	fadd.4s	v2, v2, v10
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	fmul.4s	v9, v2, v3
	fmul.4s	v10, v31, v3
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	fadd.4s	v10, v10, v3
	fadd.4s	v9, v9, v3
	fmul.4s	v9, v2, v9
	fmul.4s	v10, v31, v10
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	fadd.4s	v10, v10, v3
	fadd.4s	v9, v9, v3
	fmul.4s	v9, v2, v9
	fmul.4s	v10, v31, v10
	ldr	q3, [sp, #1792]                 ; 16-byte Reload
	fadd.4s	v10, v10, v3
	fadd.4s	v9, v9, v3
	fmul.4s	v9, v2, v9
	fmul.4s	v10, v31, v10
	ldr	q3, [sp, #1728]                 ; 16-byte Reload
	fadd.4s	v10, v10, v3
	fadd.4s	v9, v9, v3
	fmul.4s	v9, v2, v9
	fmul.4s	v10, v31, v10
	movi.4s	v3, #63, lsl #24
	fadd.4s	v10, v10, v3
	fadd.4s	v9, v9, v3
	fmul.4s	v11, v2, v2
	fmul.4s	v9, v11, v9
	fmul.4s	v11, v31, v31
	fmul.4s	v10, v11, v10
	fadd.4s	v31, v31, v10
	fadd.4s	v2, v2, v9
	fmov.4s	v3, #1.00000000
	fadd.4s	v2, v2, v3
	fadd.4s	v31, v31, v3
	sshr.4s	v9, v21, #1
	sshr.4s	v10, v18, #1
	shl.4s	v11, v10, #23
	add.4s	v11, v11, v3
	fmul.4s	v31, v31, v11
	shl.4s	v11, v9, #23
	add.4s	v11, v11, v3
	fmul.4s	v2, v2, v11
	sub.4s	v10, v18, v10
	sub.4s	v21, v21, v9
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v3
	fmul.4s	v2, v2, v21
	shl.4s	v21, v10, #23
	add.4s	v21, v21, v3
	fmul.4s	v21, v31, v21
	fcmgt.4s	v31, v28, v23
	bic.16b	v21, v21, v31
	fcmgt.4s	v31, v28, v30
	bic.16b	v2, v2, v31
	fcmgt.4s	v31, v30, v17
	ldr	q3, [sp, #1872]                 ; 16-byte Reload
	bit.16b	v2, v3, v31
	fcmgt.4s	v31, v23, v17
	bit.16b	v21, v3, v31
	fcmeq.4s	v23, v23, v23
	ldr	q3, [sp, #1920]                 ; 16-byte Reload
	bsl.16b	v23, v21, v3
	fcmeq.4s	v21, v30, v30
	mov.16b	v30, v21
	bsl.16b	v30, v2, v3
	sshll.2d	v2, v0, #0
	ldr	q3, [sp, #1152]                 ; 16-byte Reload
	ldr	q17, [sp, #1680]                ; 16-byte Reload
	bit.16b	v17, v3, v2
	str	q17, [sp, #1680]                ; 16-byte Spill
	sshll.2d	v2, v1, #0
	ldr	q3, [sp, #1216]                 ; 16-byte Reload
	bit.16b	v25, v3, v2
	ldr	q10, [sp, #1088]                ; 16-byte Reload
	bit.16b	v10, v30, v0
	ldr	q11, [sp, #1104]                ; 16-byte Reload
	bit.16b	v11, v23, v1
	ldr	q2, [sp, #2144]                 ; 16-byte Reload
	ldr	q3, [sp, #1184]                 ; 16-byte Reload
	ldr	q21, [sp, #1120]                ; 16-byte Reload
	bit.16b	v21, v3, v2
	str	q21, [sp, #1120]                ; 16-byte Spill
	ldr	q2, [sp, #1232]                 ; 16-byte Reload
	ldr	q3, [sp, #1168]                 ; 16-byte Reload
	ldr	q9, [sp, #944]                  ; 16-byte Reload
	bit.16b	v9, v3, v2
	ldr	q31, [sp, #1200]                ; 16-byte Reload
LBB0_99:                                ; %direct.true754
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	d2, x1
	orr.16b	v3, v2, v31
	fmov	x2, d3
	add	x3, x8, x2
	ldp	q21, q3, [x3]
	and.16b	v21, v1, v21
	and.16b	v3, v0, v3
	fmul.4s	v3, v10, v3
	fmul.4s	v21, v11, v21
	orr.16b	v2, v2, v25
	fmov	x3, d2
	add	x3, x15, x3
	ldp	q28, q2, [x3]
	fadd.4s	v21, v28, v21
	fadd.4s	v2, v2, v3
	add	x2, x11, x2
	ldp	q3, q28, [x2]
	bif.16b	v2, v28, v0
	bit.16b	v3, v21, v1
	stp	q3, q2, [x2]
	add	x1, x1, #32
	cmp	x1, #3072
	b.ne	LBB0_99
; %bb.100:                              ; %direct.true776.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q25, [sp, #1136]                ; 16-byte Spill
	str	q10, [sp, #1088]                ; 16-byte Spill
	str	q11, [sp, #1104]                ; 16-byte Spill
	mov	x1, x10
	mov	w2, #96                         ; =0x60
	ldr	q25, [sp, #784]                 ; 16-byte Reload
	ldr	q17, [sp, #448]                 ; 16-byte Reload
	ldp	q29, q18, [sp, #336]            ; 32-byte Folded Reload
	ldr	q19, [sp, #304]                 ; 16-byte Reload
LBB0_101:                               ; %direct.true776
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x1, #5632]
	ldr	q3, [x1, #5648]
	ldr	q21, [x1, #2560]
	ldr	q28, [x1, #2576]
	bif.16b	v3, v28, v0
	bif.16b	v2, v21, v1
	str	q2, [x1, #2560]
	str	q3, [x1, #2576]
	add	x1, x1, #32
	subs	x2, x2, #1
	b.ne	LBB0_101
; %bb.102:                              ; %direct.false777
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q2, [sp, #1712]                 ; 16-byte Reload
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #1712]                 ; 16-byte Spill
	ldr	q2, [sp, #1696]                 ; 16-byte Reload
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #1696]                 ; 16-byte Spill
	movi.2d	v3, #0000000000000000
	ldr	q2, [sp, #1408]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q21, [sp, #1376]                ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q21, [sp, #1392]                ; 16-byte Reload
	fadd.4s	v3, v21, v3
	ldr	q21, [sp, #1360]                ; 16-byte Reload
	fadd.4s	v3, v3, v21
	ldr	q21, [sp, #1328]                ; 16-byte Reload
	fadd.4s	v3, v3, v21
	ldr	q21, [sp, #1344]                ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q21, [sp, #1312]                ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q21, [sp, #1296]                ; 16-byte Reload
	fadd.4s	v3, v3, v21
	ldr	q21, [sp, #1264]                ; 16-byte Reload
	fadd.4s	v3, v3, v21
	ldr	q21, [sp, #1280]                ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q21, [sp, #1904]                ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q21, [sp, #1856]                ; 16-byte Reload
	fadd.4s	v3, v3, v21
	ldp	q28, q21, [sp, #832]            ; 32-byte Folded Reload
	fadd.4s	v3, v3, v28
	fadd.4s	v2, v2, v21
	ldp	q21, q28, [sp, #800]            ; 32-byte Folded Reload
	fadd.4s	v2, v2, v28
	fadd.4s	v3, v3, v21
	ldp	q28, q21, [sp, #752]            ; 32-byte Folded Reload
	fadd.4s	v3, v3, v28
	fadd.4s	v2, v2, v21
	ldp	q28, q21, [sp, #720]            ; 32-byte Folded Reload
	fadd.4s	v2, v2, v28
	fadd.4s	v3, v3, v21
	ldp	q21, q28, [sp, #688]            ; 32-byte Folded Reload
	fadd.4s	v3, v3, v28
	fadd.4s	v2, v2, v21
	ldp	q28, q21, [sp, #656]            ; 32-byte Folded Reload
	fadd.4s	v2, v2, v28
	fadd.4s	v3, v3, v21
	ldp	q21, q28, [sp, #608]            ; 32-byte Folded Reload
	fadd.4s	v3, v3, v28
	fadd.4s	v2, v2, v21
	ldp	q21, q28, [sp, #576]            ; 32-byte Folded Reload
	fadd.4s	v2, v2, v28
	fadd.4s	v3, v3, v21
	ldp	q21, q28, [sp, #544]            ; 32-byte Folded Reload
	fadd.4s	v3, v3, v28
	fadd.4s	v2, v2, v21
	ldr	q21, [sp, #528]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q21, [sp, #864]                 ; 16-byte Reload
	fadd.4s	v3, v3, v21
	ldp	q28, q10, [sp, #912]            ; 32-byte Folded Reload
	fmul.4s	v21, v10, v23
	fmul.4s	v23, v28, v30
	fadd.4s	v3, v23, v3
	fadd.4s	v2, v21, v2
	bit.16b	v10, v2, v1
	mov.16b	v30, v0
	bsl.16b	v30, v3, v28
	add	x0, x0, #1
	cmp	x0, #129
	ldr	q11, [sp, #1488]                ; 16-byte Reload
	ldr	q28, [sp, #1472]                ; 16-byte Reload
	ldr	q3, [sp, #1680]                 ; 16-byte Reload
	b.ne	LBB0_22
; %bb.103:                              ; %direct.schedule.86.preheader
	mov	x9, #0                          ; =0x0
	ldp	q2, q4, [sp, #16]               ; 32-byte Folded Reload
	xtn.2s	v2, v2
	movi.2s	v5, #96
	umull.2d	v2, v2, v5
	ldp	q3, q6, [sp, #48]               ; 32-byte Folded Reload
	xtn.2s	v3, v3
	umull.2d	v3, v3, v5
	xtn.2s	v4, v4
	umull.2d	v4, v4, v5
	xtn.2s	v6, v6
	umull.2d	v5, v6, v5
	ldr	x12, [sp, #80]                  ; 8-byte Reload
	b	LBB0_105
LBB0_104:                               ; %else315
                                        ;   in Loop: Header=BB0_105 Depth=1
	add	x9, x9, #1
	cmp	x9, #96
	b.eq	LBB0_121
LBB0_105:                               ; %direct.true795
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q6, [sp, #1936]                 ; 16-byte Reload
	fmov	w10, s6
	dup.2d	v6, x9
	add.2d	v7, v6, v2
	add	x11, x8, x9, lsl #5
	ldp	q17, q16, [x11]
	and.16b	v17, v1, v17
	fdiv.4s	v17, v17, v10
	shl.2d	v18, v7, #2
	dup.2d	v7, x12
	add.2d	v18, v7, v18
	tbz	w10, #0, LBB0_113
; %bb.106:                              ; %cond.store
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x11, d18
	str	s17, [x11]
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_114
LBB0_107:                               ; %else297
                                        ;   in Loop: Header=BB0_105 Depth=1
	add.2d	v18, v6, v3
	shl.2d	v18, v18, #2
	add.2d	v18, v7, v18
	tbz	w10, #2, LBB0_115
LBB0_108:                               ; %cond.store298
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x11, d18
	st1.s	{ v17 }[2], [x11]
	tbnz	w10, #3, LBB0_116
LBB0_109:                               ; %else303
                                        ;   in Loop: Header=BB0_105 Depth=1
	add.2d	v17, v6, v4
	and.16b	v16, v0, v16
	fdiv.4s	v16, v16, v30
	shl.2d	v17, v17, #2
	add.2d	v17, v7, v17
	tbz	w10, #4, LBB0_117
LBB0_110:                               ; %cond.store304
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x11, d17
	str	s16, [x11]
	tbnz	w10, #5, LBB0_118
LBB0_111:                               ; %else309
                                        ;   in Loop: Header=BB0_105 Depth=1
	add.2d	v6, v6, v5
	shl.2d	v6, v6, #2
	add.2d	v6, v7, v6
	tbz	w10, #6, LBB0_119
LBB0_112:                               ; %cond.store310
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x11, d6
	st1.s	{ v16 }[2], [x11]
	tbz	w10, #7, LBB0_104
	b	LBB0_120
LBB0_113:                               ; %else294
                                        ;   in Loop: Header=BB0_105 Depth=1
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_107
LBB0_114:                               ; %cond.store295
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x11, v18[1]
	st1.s	{ v17 }[1], [x11]
	add.2d	v18, v6, v3
	shl.2d	v18, v18, #2
	add.2d	v18, v7, v18
	tbnz	w10, #2, LBB0_108
LBB0_115:                               ; %else300
                                        ;   in Loop: Header=BB0_105 Depth=1
	tbz	w10, #3, LBB0_109
LBB0_116:                               ; %cond.store301
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x11, v18[1]
	st1.s	{ v17 }[3], [x11]
	add.2d	v17, v6, v4
	and.16b	v16, v0, v16
	fdiv.4s	v16, v16, v30
	shl.2d	v17, v17, #2
	add.2d	v17, v7, v17
	tbnz	w10, #4, LBB0_110
LBB0_117:                               ; %else306
                                        ;   in Loop: Header=BB0_105 Depth=1
	tbz	w10, #5, LBB0_111
LBB0_118:                               ; %cond.store307
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x11, v17[1]
	st1.s	{ v16 }[1], [x11]
	add.2d	v6, v6, v5
	shl.2d	v6, v6, #2
	add.2d	v6, v7, v6
	tbnz	w10, #6, LBB0_112
LBB0_119:                               ; %else312
                                        ;   in Loop: Header=BB0_105 Depth=1
	tbz	w10, #7, LBB0_104
LBB0_120:                               ; %cond.store313
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x10, v6[1]
	st1.s	{ v16 }[3], [x10]
	b	LBB0_104
LBB0_121:
	add	sp, sp, #2240
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_122:                               ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

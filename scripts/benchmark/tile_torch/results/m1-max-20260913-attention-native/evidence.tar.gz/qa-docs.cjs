// Generated artifact QA only; not control of the user's browser.
const fs = require('node:fs');
const {pathToFileURL} = require('node:url');
const {chromium} = require('/Users/mike/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async () => {
    const root='/tmp/luisa-attention-native.3DVFyG';
    const browser=await chromium.launch({headless:true, executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
    const receipts=[];
    for (const width of [1280,390]) {
        const page=await browser.newPage({viewport:{width,height:1000}});
        await page.goto(pathToFileURL(root+'/docs-html/source/performance/tile/results.html').href);
        const section=page.locator('#attention-priority-contribution-mapping-with-device-failures-retained');
        await section.evaluate(el=>el.scrollIntoView({block:'start'}));
        const text=await section.innerText();
        if (!text.includes('72 ABBA') || !text.includes('1.252–1.332')) throw new Error('Missing new experiment text');
        const overflow=await page.evaluate(()=>document.documentElement.scrollWidth > innerWidth + 1);
        if (overflow) throw new Error('Page overflow');
        await page.screenshot({path:root+'/attention-'+width+'.png'});
        receipts.push({width,overflow,text_checked:true});
        await page.close();
    }
    await browser.close();
    fs.writeFileSync(root+'/docs-qa.json',JSON.stringify(receipts,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});

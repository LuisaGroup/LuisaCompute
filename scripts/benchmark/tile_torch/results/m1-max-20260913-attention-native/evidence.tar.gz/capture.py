import itertools
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/Users/mike/CLionProjects/luisa')
out = Path(__file__).resolve().parent
binary = Path('/tmp/luisa-next-integration.roZbN8/build/bin/benchmark_tile_xir')
cases = [('prefill', (1,4,2,32,65,32,32), (4,16)),
         ('decode', (1,8,2,1,2053,80,96), (1,16))]
records = []
for name, dims, block in cases:
    for qk, pv in itertools.product(('mma', 'reduce'), repeat=2):
        folder = out / f'{name}-{qk}-{pv}'
        folder.mkdir()
        prefix = folder / 'output.f32'
        env = {k:v for k,v in os.environ.items() if not k.startswith(('LUISA_', 'MTL_'))}
        env.update(LUISA_TILE_BENCH_XIR_BACKEND='simd', LUISA_TILE_BENCH_ATTENTION_QK=qk,
                   LUISA_TILE_BENCH_ATTENTION_PV=pv, LUISA_TILE_BENCH_DUMP_SOURCE=str(prefix)+'.source.txt',
                   LUISA_SIMD_DUMP_ASSEMBLY_DIR=str(folder/'objects'))
        cmd = [str(binary), 'llm', 'attention', ','.join(map(str,dims)), *map(str,block), '3','1','1',str(prefix)]
        record = dict(case=name, dimensions=dims, block=block, qk=qk, pv=pv, command=cmd, environment={k:v for k,v in env.items() if k.startswith('LUISA_')}, status='running')
        records.append(record)
        (out/'captures.json').write_text(json.dumps(records, indent=2)+'\n')
        started = time.monotonic()
        try:
            process = subprocess.run(cmd, env=env, capture_output=True, timeout=60)
            (folder/'stdout.log').write_bytes(process.stdout)
            (folder/'stderr.log').write_bytes(process.stderr)
            record.update(returncode=process.returncode, seconds=time.monotonic()-started)
            process.check_returncode()
            metadata = json.loads(process.stdout)
            if (metadata['attention_qk'], metadata['attention_pv']) != (qk,pv):
                raise ValueError('probe ignored')
            record.update(status='captured', metadata=metadata)
        except subprocess.TimeoutExpired as error:
            (folder/'stdout.log').write_bytes(error.stdout or b'')
            (folder/'stderr.log').write_bytes(error.stderr or b'')
            record.update(status='error', error='capture timeout', seconds=time.monotonic()-started)
        except Exception as error:
            record.update(status='error', error=str(error), seconds=time.monotonic()-started)
        (out/'captures.json').write_text(json.dumps(records, indent=2)+'\n')
        print(name,qk,pv,record['status'],flush=True)
sys.exit(any(r['status'] != 'captured' for r in records))

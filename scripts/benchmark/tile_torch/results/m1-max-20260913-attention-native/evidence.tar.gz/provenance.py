import hashlib
import json
from pathlib import Path
import platform
import subprocess

root=Path('/Users/mike/CLionProjects/luisa')
source=Path('/tmp/luisa-next-integration.roZbN8/source')
build=Path('/tmp/luisa-next-integration.roZbN8/build')
out=root/'scripts/benchmark/tile_torch/results/m1-max-20260913-attention-native'
def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
owned=['src/tests/common/tile_llm_benchmark.h','src/tests/benchmark/benchmark_tile_xir.cpp','src/tests/unit/tile/bridge/test_xir_llm.cpp']
assert all(sha(root/p)==sha(source/p) for p in owned)
assert sha(root/'src/backends/simd/llvm/llvm_schedule_codegen.h')==sha(source/'src/backends/simd/llvm/llvm_schedule_codegen.h')
data=dict(checkpoint='2026-09-13 attention native-entry diagnostic',platform=platform.platform(),
          main_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
          origin_next=subprocess.check_output(['git','rev-parse','origin/next'],cwd=root,text=True).strip(),
          source_state='Isolated export at 32bfbe106 plus the three listed C++ changes; upstream 19 commits and protected TIRx WIP excluded. No production emitter/default-policy changes in this experiment.',
          full_build_log='full-build.log in evidence.tar.gz',source_cpp_sha256={p:sha(source/p) for p in owned},
          build_configuration_sha256=sha(build/'CMakeCache.txt'),
          binary_sha256={p.name:sha(p) for p in [build/'bin/benchmark_tile_xir',*sorted((build/'bin').glob('*.dylib'))] if p.is_file()},
          llvm_tools_sha256={p:sha(Path('/opt/homebrew/opt/llvm/bin')/p) for p in ['clang++','llvm-nm']},
          compiler_version=subprocess.check_output(['/opt/homebrew/opt/llvm/bin/clang++','--version'],text=True),
          acceptance=dict(cpu_numerical=True,simd_native_replay=True,production_optimization=False,
                          fresh_gpu_measurements=False,torch_performance_comparison=False,torch_worker_cpu_protocol_smoke=True),
          exclusions=['No binaries for full Runtime environment closure; actual replay objects/dylibs and ABI helper retained.',
                      'Guard payloads are not retained; helper guards are execution receipts. Complete logical outputs are retained.',
                      'Temporary tensors from the worker protocol smoke are deleted by its driver; performance captures retain all tensors.'])
(out/'provenance.json').write_text(json.dumps(data,indent=2)+'\n')

import json
from pathlib import Path
import subprocess
import sys

root=Path('/Users/mike/CLionProjects/luisa')
out=Path(__file__).resolve().parent
runner=root/'scripts/benchmark/tile_torch/native_tile.py'
for case in json.loads((out/'captures.json').read_text()):
    name='-'.join((case['case'],case['qk'],case['pv']))
    folder=out/name
    prepared=out/('prepared-'+name)
    if prepared.exists():
        continue
    cmd=[sys.executable,str(runner),'prepare','--capture-kind','llm','--llvm','/opt/homebrew/opt/llvm/bin',
         '--prefix',str(folder/'output.f32'),'--log',str(folder/'stdout.log'),'--objects',str(folder/'objects'),
         '--output',str(prepared),'--name',case['qk']+'-'+case['pv']]
    p=subprocess.run(cmd,capture_output=True,timeout=60)
    (out/(name+'-prepare.log')).write_bytes(p.stdout+p.stderr)
    print(name,p.returncode,flush=True)
    p.check_returncode()

import json
import os
from pathlib import Path
import subprocess
import sys
import time

root=Path('/Users/mike/CLionProjects/luisa')
out=Path(__file__).resolve().parent
runner=root/'scripts/benchmark/tile_torch/native_tile.py'
record=dict(started=time.time(), load_before=os.getloadavg(), experiments=[])
for name in ('prefill','decode'):
    for label,baseline,candidate in [('pv-qk-mma','mma-mma','mma-reduce'),('pv-qk-reduce','reduce-mma','reduce-reduce'),('qk-pv-mma','mma-mma','reduce-mma')]:
        directory=out/('replay-'+name+'-'+label)
        cmd=[sys.executable,str(runner),'replay','--prepared',str(out/f'prepared-{name}-{baseline}'/'prepared.json'),
             '--prepared',str(out/f'prepared-{name}-{candidate}'/'prepared.json'), '--output',str(directory),
             '--cycles','3','--samples','7','--warmup-ms','30','--target-ms','15']
        p=subprocess.run(cmd,capture_output=True,timeout=60)
        (out/(directory.name+'.log')).write_bytes(p.stdout+p.stderr)
        record['experiments'].append(dict(name=name,label=label,command=cmd,returncode=p.returncode))
        (out/'replays.json').write_text(json.dumps(record,indent=2)+'\n')
        print(name,label,p.returncode,flush=True)
        p.check_returncode()
record.update(finished=time.time(),load_after=os.getloadavg())
(out/'replays.json').write_text(json.dumps(record,indent=2)+'\n')

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_4:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_5:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	dup.4s	v2, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v2, v4
	cmhi.4s	v1, v2, v3
	uzp1.8h	v17, v1, v0
	umaxv.8h	h5, v17
	fmov	w8, s5
	tbz	w8, #0, LBB0_122
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #64
	mov	x9, #0                          ; =0x0
	ldr	x10, [x1, #136]
	add	x8, x10, #2560
	mov	w11, #5632                      ; =0x1600
	add	x11, x10, x11
	mov	w12, #8704                      ; =0x2200
	add	x12, x10, x12
	mov	w13, #49664                     ; =0xc200
	add	x13, x10, x13
	add	x14, x10, #24, lsl #12          ; =98304
	add	x14, x14, #512
	add	x15, x10, #24, lsl #12          ; =98304
	add	x15, x15, #1536
	ldr	x2, [x0]
	ldr	x16, [x0, #16]
	ldr	w17, [x1]
	ldr	w1, [x1, #36]
	add	w1, w1, w17, lsl #5
	ldr	x17, [x0, #32]
	ldr	x0, [x0, #48]
	str	x0, [sp, #88]                   ; 8-byte Spill
	dup.4s	v5, w1
	add.4s	v6, v5, v4
	add.4s	v5, v5, v3
	and.16b	v16, v1, v5
	and.16b	v7, v0, v6
	ushll2.2d	v23, v7, #0
	ushll2.2d	v24, v16, #0
	ushll.2d	v25, v7, #0
	ushll.2d	v26, v16, #0
	movi.4s	v6, #80
	umull2.2d	v5, v7, v6
	umull2.2d	v6, v16, v6
	movi.2s	v18, #80
	umull.2d	v7, v7, v18
	umull.2d	v16, v16, v18
Lloh4:
	adrp	x0, lCPI0_2@PAGE
Lloh5:
	ldr	q18, [x0, lCPI0_2@PAGEOFF]
	and.16b	v17, v17, v18
	addv.8h	h17, v17
	str	q17, [sp, #3872]                ; 16-byte Spill
	fmov	w0, s17
	dup.2d	v17, x2
	b	LBB0_3
LBB0_2:                                 ; %else496
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x10, x9, lsl #5
	ldp	q20, q21, [x1]
	bif.16b	v19, v21, v0
	bif.16b	v18, v20, v1
	stp	q18, q19, [x1]
	add	x9, x9, #1
	cmp	x9, #80
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v20, x9
	add.2d	v18, v20, v16
	shl.2d	v18, v18, #2
	add.2d	v21, v17, v18
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w0, #0, LBB0_11
; %bb.4:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x1, d21
	ldr	s18, [x1]
	and	w1, w0, #0xff
	tbnz	w1, #1, LBB0_12
LBB0_5:                                 ; %else478
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v21, v20, v6
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbz	w1, #2, LBB0_13
LBB0_6:                                 ; %cond.load480
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x2, d21
	ld1.s	{ v18 }[2], [x2]
	tbnz	w1, #3, LBB0_14
LBB0_7:                                 ; %else484
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v21, v20, v7
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbz	w1, #4, LBB0_15
LBB0_8:                                 ; %cond.load486
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x2, d21
	ld1.s	{ v19 }[0], [x2]
	tbnz	w1, #5, LBB0_16
LBB0_9:                                 ; %else490
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v20, v20, v5
	shl.2d	v20, v20, #2
	add.2d	v20, v17, v20
	tbz	w1, #6, LBB0_17
LBB0_10:                                ; %cond.load492
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x2, d20
	ld1.s	{ v19 }[2], [x2]
	tbz	w1, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w1, w0, #0xff
	tbz	w1, #1, LBB0_5
LBB0_12:                                ; %cond.load477
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x2, v21[1]
	ld1.s	{ v18 }[1], [x2]
	add.2d	v21, v20, v6
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbnz	w1, #2, LBB0_6
LBB0_13:                                ; %else481
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w1, #3, LBB0_7
LBB0_14:                                ; %cond.load483
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x2, v21[1]
	ld1.s	{ v18 }[3], [x2]
	add.2d	v21, v20, v7
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbnz	w1, #4, LBB0_8
LBB0_15:                                ; %else487
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w1, #5, LBB0_9
LBB0_16:                                ; %cond.load489
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x2, v21[1]
	ld1.s	{ v19 }[1], [x2]
	add.2d	v20, v20, v5
	shl.2d	v20, v20, #2
	add.2d	v20, v17, v20
	tbnz	w1, #6, LBB0_10
LBB0_17:                                ; %else493
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w1, #7, LBB0_2
LBB0_18:                                ; %cond.load495
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x1, v20[1]
	ld1.s	{ v19 }[3], [x1]
	b	LBB0_2
LBB0_19:                                ; %direct.true223.preheader
	mov	x9, #0                          ; =0x0
	cmhs.4s	v5, v4, v2
	cmhs.4s	v4, v3, v2
LBB0_20:                                ; %direct.true223
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, x8, x9
	ldp	q2, q3, [x0]
	and.16b	v3, v5, v3
	and.16b	v2, v4, v2
	stp	q2, q3, [x0]
	add	x9, x9, #32
	cmp	x9, #3072
	b.ne	LBB0_20
; %bb.21:                               ; %direct.false224
	stp	q4, q5, [sp, #352]              ; 32-byte Folded Spill
	sshll.2d	v2, v1, #0
	mov	x0, #0                          ; =0x0
	sshll.2d	v3, v0, #0
	sshll2.2d	v20, v1, #0
	sshll2.2d	v18, v0, #0
	stp	q26, q25, [sp, #16]             ; 32-byte Folded Spill
	ushr.2d	v4, v26, #2
	stp	q24, q23, [sp, #48]             ; 32-byte Folded Spill
	ushr.2d	v5, v24, #2
	ushr.2d	v6, v25, #2
	ushr.2d	v7, v23, #2
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q16, [x9, lCPI0_6@PAGEOFF]
	str	q16, [sp, #1728]                ; 16-byte Spill
	and.16b	v21, v2, v16
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v16, w9
	and.16b	v17, v0, v16
	str	q17, [sp, #3712]                ; 16-byte Spill
	mov.d	x9, v7[1]
	mov	w1, #2053                       ; =0x805
	mul	x9, x9, x1
	fmov	x2, d7
	mul	x2, x2, x1
	fmov	d7, x2
	mov.d	v7[1], x9
	mov.d	x9, v6[1]
	mul	x9, x9, x1
	fmov	x2, d6
	mul	x2, x2, x1
	fmov	d6, x2
	mov.d	v6[1], x9
	str	q16, [sp, #320]                 ; 16-byte Spill
	and.16b	v16, v1, v16
	str	q16, [sp, #3696]                ; 16-byte Spill
	mov.d	x9, v5[1]
	mul	x9, x9, x1
	fmov	x2, d5
	mul	x2, x2, x1
	fmov	d5, x2
	mov.d	v5[1], x9
	mov.d	x9, v4[1]
	mul	x9, x9, x1
	fmov	x2, d4
	mul	x1, x2, x1
	fmov	d4, x1
	mov.d	v4[1], x9
	and.16b	v19, v2, v4
	str	q20, [sp, #4096]                ; 16-byte Spill
	and.16b	v2, v20, v5
	str	q2, [sp, #4064]                 ; 16-byte Spill
	and.16b	v2, v3, v6
	str	q2, [sp, #4048]                 ; 16-byte Spill
	str	q18, [sp, #4080]                ; 16-byte Spill
	and.16b	v2, v18, v7
	str	q2, [sp, #4032]                 ; 16-byte Spill
	mvni.4s	v2, #63, msl #16
	fneg.4s	v2, v2
	str	q2, [sp, #1712]                 ; 16-byte Spill
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #1696]                 ; 16-byte Spill
	str	q2, [sp, #1680]                 ; 16-byte Spill
	str	q2, [sp, #1664]                 ; 16-byte Spill
	str	q2, [sp, #1648]                 ; 16-byte Spill
	movi.2d	v16, #0000000000000000
	str	q21, [sp, #336]                 ; 16-byte Spill
	fmov	x9, d21
	str	q2, [sp, #1632]                 ; 16-byte Spill
	str	q2, [sp, #1616]                 ; 16-byte Spill
Lloh8:
	adrp	x1, lCPI0_3@PAGE
Lloh9:
	ldr	q2, [x1, lCPI0_3@PAGEOFF]
	str	q2, [sp, #1600]                 ; 16-byte Spill
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #1584]                 ; 16-byte Spill
	movi.2d	v17, #0000000000000000
Lloh10:
	adrp	x1, lCPI0_4@PAGE
Lloh11:
	ldr	q2, [x1, lCPI0_4@PAGEOFF]
	str	q2, [sp, #1568]                 ; 16-byte Spill
Lloh12:
	adrp	x1, lCPI0_5@PAGE
Lloh13:
	ldr	q2, [x1, lCPI0_5@PAGEOFF]
	str	q2, [sp, #1552]                 ; 16-byte Spill
	add	x9, x10, x9
	str	x9, [sp, #296]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #512
	str	x9, [sp, #288]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #544
	str	x9, [sp, #280]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #576
	str	x9, [sp, #272]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #608
	str	x9, [sp, #264]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #640
	str	x9, [sp, #256]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #672
	str	x9, [sp, #248]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #704
	str	x9, [sp, #240]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #736
	str	x9, [sp, #232]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #768
	str	x9, [sp, #224]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #800
	str	x9, [sp, #216]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #832
	str	x9, [sp, #208]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #864
	str	x9, [sp, #200]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #896
	str	x9, [sp, #192]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #928
	str	x9, [sp, #184]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #960
	str	x9, [sp, #176]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #992
	str	x9, [sp, #168]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1056
	str	x9, [sp, #160]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1088
	str	x9, [sp, #152]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1120
	str	x9, [sp, #144]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1152
	str	x9, [sp, #136]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1184
	str	x9, [sp, #128]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1216
	str	x9, [sp, #120]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1248
	str	x9, [sp, #112]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1280
	str	x9, [sp, #104]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1312
	str	x9, [sp, #96]                   ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x19, x9, #1344
	add	x9, x10, #24, lsl #12           ; =98304
	add	x20, x9, #1376
	add	x9, x10, #24, lsl #12           ; =98304
	add	x21, x9, #1408
	add	x9, x10, #24, lsl #12           ; =98304
	add	x22, x9, #1440
	add	x9, x10, #24, lsl #12           ; =98304
	add	x23, x9, #1472
	add	x9, x10, #24, lsl #12           ; =98304
	add	x24, x9, #1504
	mov	w9, #33792                      ; =0x8400
	movk	w9, #1, lsl #16
	add	x25, x10, x9
	mov	w26, #52429                     ; =0xcccd
	mov	w27, #80                        ; =0x50
	mov	w28, #43691                     ; =0xaaab
	mov	w30, #96                        ; =0x60
	mov	x9, #-6148914691236517206       ; =0xaaaaaaaaaaaaaaaa
	movk	x9, #43691
	mov	w1, #3072                       ; =0xc00
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #1536]                 ; 16-byte Spill
	movi.2d	v7, #0000000000000000
	str	q2, [sp, #1520]                 ; 16-byte Spill
	str	q2, [sp, #1504]                 ; 16-byte Spill
	str	q2, [sp, #3600]                 ; 16-byte Spill
	str	q2, [sp, #3584]                 ; 16-byte Spill
	str	q2, [sp, #1488]                 ; 16-byte Spill
	str	q2, [sp, #1472]                 ; 16-byte Spill
	str	q2, [sp, #3568]                 ; 16-byte Spill
	str	q2, [sp, #3552]                 ; 16-byte Spill
	str	q2, [sp, #3536]                 ; 16-byte Spill
	str	q2, [sp, #3520]                 ; 16-byte Spill
	str	q2, [sp, #3504]                 ; 16-byte Spill
	str	q2, [sp, #3488]                 ; 16-byte Spill
	str	q2, [sp, #3472]                 ; 16-byte Spill
	str	q2, [sp, #3456]                 ; 16-byte Spill
	str	q2, [sp, #1456]                 ; 16-byte Spill
	str	q2, [sp, #1440]                 ; 16-byte Spill
	str	q2, [sp, #3440]                 ; 16-byte Spill
	str	q2, [sp, #3424]                 ; 16-byte Spill
	str	q2, [sp, #3408]                 ; 16-byte Spill
	str	q2, [sp, #3392]                 ; 16-byte Spill
	str	q2, [sp, #3376]                 ; 16-byte Spill
	str	q2, [sp, #3360]                 ; 16-byte Spill
	str	q2, [sp, #1424]                 ; 16-byte Spill
	str	q2, [sp, #3344]                 ; 16-byte Spill
	str	q2, [sp, #1408]                 ; 16-byte Spill
	str	q2, [sp, #1392]                 ; 16-byte Spill
	str	q2, [sp, #3328]                 ; 16-byte Spill
	str	q2, [sp, #3312]                 ; 16-byte Spill
	str	q2, [sp, #3296]                 ; 16-byte Spill
	str	q2, [sp, #3280]                 ; 16-byte Spill
	str	q2, [sp, #3264]                 ; 16-byte Spill
	str	q2, [sp, #3248]                 ; 16-byte Spill
	str	q2, [sp, #3232]                 ; 16-byte Spill
	str	q2, [sp, #3216]                 ; 16-byte Spill
	str	q2, [sp, #1376]                 ; 16-byte Spill
	str	q2, [sp, #1360]                 ; 16-byte Spill
	str	q2, [sp, #3200]                 ; 16-byte Spill
	str	q2, [sp, #3184]                 ; 16-byte Spill
	str	q2, [sp, #3168]                 ; 16-byte Spill
	str	q2, [sp, #3152]                 ; 16-byte Spill
	str	q2, [sp, #3136]                 ; 16-byte Spill
	str	q2, [sp, #3120]                 ; 16-byte Spill
	str	q2, [sp, #1344]                 ; 16-byte Spill
	str	q2, [sp, #3104]                 ; 16-byte Spill
	str	q2, [sp, #1328]                 ; 16-byte Spill
	str	q2, [sp, #1312]                 ; 16-byte Spill
	str	q2, [sp, #3088]                 ; 16-byte Spill
	str	q2, [sp, #3072]                 ; 16-byte Spill
	str	q2, [sp, #3056]                 ; 16-byte Spill
	str	q2, [sp, #3040]                 ; 16-byte Spill
	str	q2, [sp, #3024]                 ; 16-byte Spill
	str	q2, [sp, #3008]                 ; 16-byte Spill
	str	q2, [sp, #1296]                 ; 16-byte Spill
	str	q2, [sp, #2992]                 ; 16-byte Spill
	str	q2, [sp, #1280]                 ; 16-byte Spill
	str	q2, [sp, #1264]                 ; 16-byte Spill
	str	q2, [sp, #2976]                 ; 16-byte Spill
	str	q2, [sp, #2960]                 ; 16-byte Spill
	str	q2, [sp, #2944]                 ; 16-byte Spill
	str	q2, [sp, #2928]                 ; 16-byte Spill
	str	q2, [sp, #2912]                 ; 16-byte Spill
	str	q2, [sp, #2896]                 ; 16-byte Spill
	str	q2, [sp, #2880]                 ; 16-byte Spill
	str	q2, [sp, #1248]                 ; 16-byte Spill
	str	q2, [sp, #1232]                 ; 16-byte Spill
	str	q2, [sp, #1216]                 ; 16-byte Spill
	str	q2, [sp, #2864]                 ; 16-byte Spill
	str	q2, [sp, #2848]                 ; 16-byte Spill
	str	q2, [sp, #2832]                 ; 16-byte Spill
	str	q2, [sp, #2816]                 ; 16-byte Spill
	str	q2, [sp, #2800]                 ; 16-byte Spill
	str	q2, [sp, #2784]                 ; 16-byte Spill
	str	q2, [sp, #2768]                 ; 16-byte Spill
	str	q2, [sp, #1200]                 ; 16-byte Spill
	str	q2, [sp, #1184]                 ; 16-byte Spill
	str	q2, [sp, #1168]                 ; 16-byte Spill
	str	q2, [sp, #2752]                 ; 16-byte Spill
	str	q2, [sp, #2736]                 ; 16-byte Spill
	str	q2, [sp, #2720]                 ; 16-byte Spill
	str	q2, [sp, #2704]                 ; 16-byte Spill
	str	q2, [sp, #2688]                 ; 16-byte Spill
	str	q2, [sp, #2672]                 ; 16-byte Spill
	str	q2, [sp, #2656]                 ; 16-byte Spill
	str	q2, [sp, #2640]                 ; 16-byte Spill
	str	q2, [sp, #1152]                 ; 16-byte Spill
	str	q2, [sp, #1136]                 ; 16-byte Spill
	str	q2, [sp, #2624]                 ; 16-byte Spill
	str	q2, [sp, #2608]                 ; 16-byte Spill
	str	q2, [sp, #2592]                 ; 16-byte Spill
	str	q2, [sp, #2576]                 ; 16-byte Spill
	str	q2, [sp, #2560]                 ; 16-byte Spill
	str	q2, [sp, #2544]                 ; 16-byte Spill
	str	q2, [sp, #2528]                 ; 16-byte Spill
	str	q2, [sp, #2512]                 ; 16-byte Spill
	str	q2, [sp, #1120]                 ; 16-byte Spill
	str	q2, [sp, #1104]                 ; 16-byte Spill
	str	q2, [sp, #2496]                 ; 16-byte Spill
	str	q2, [sp, #2480]                 ; 16-byte Spill
	str	q2, [sp, #2464]                 ; 16-byte Spill
	movi.2d	v30, #0000000000000000
	str	q2, [sp, #2448]                 ; 16-byte Spill
	str	q2, [sp, #2432]                 ; 16-byte Spill
	str	q2, [sp, #2416]                 ; 16-byte Spill
	str	q2, [sp, #2400]                 ; 16-byte Spill
	str	q2, [sp, #1088]                 ; 16-byte Spill
	str	q2, [sp, #1072]                 ; 16-byte Spill
	movi.2d	v18, #0000000000000000
	str	q2, [sp, #2384]                 ; 16-byte Spill
	str	q2, [sp, #2368]                 ; 16-byte Spill
	str	q2, [sp, #2352]                 ; 16-byte Spill
	str	q2, [sp, #2336]                 ; 16-byte Spill
	str	q2, [sp, #2320]                 ; 16-byte Spill
	str	q2, [sp, #2304]                 ; 16-byte Spill
	str	q2, [sp, #2288]                 ; 16-byte Spill
	str	q2, [sp, #1056]                 ; 16-byte Spill
	str	q2, [sp, #1040]                 ; 16-byte Spill
	str	q2, [sp, #2272]                 ; 16-byte Spill
	str	q2, [sp, #2256]                 ; 16-byte Spill
	str	q2, [sp, #2240]                 ; 16-byte Spill
	str	q2, [sp, #2224]                 ; 16-byte Spill
	str	q2, [sp, #2208]                 ; 16-byte Spill
	str	q2, [sp, #2192]                 ; 16-byte Spill
	stp	q2, q2, [sp, #1008]             ; 32-byte Folded Spill
	str	q2, [sp, #2176]                 ; 16-byte Spill
	stp	q2, q2, [sp, #976]              ; 32-byte Folded Spill
	str	q2, [sp, #2160]                 ; 16-byte Spill
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v27, #0000000000000000
	str	q2, [sp, #2144]                 ; 16-byte Spill
	stp	q2, q2, [sp, #944]              ; 32-byte Folded Spill
	str	q2, [sp, #2128]                 ; 16-byte Spill
	str	q2, [sp, #2112]                 ; 16-byte Spill
	movi.2d	v15, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v28, #0000000000000000
	stp	q2, q2, [sp, #912]              ; 32-byte Folded Spill
	str	q2, [sp, #2096]                 ; 16-byte Spill
	movi.2d	v8, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v22, #0000000000000000
	str	q2, [sp, #4016]                 ; 16-byte Spill
	str	q2, [sp, #4000]                 ; 16-byte Spill
	str	q2, [sp, #3984]                 ; 16-byte Spill
	str	q2, [sp, #3968]                 ; 16-byte Spill
	str	q2, [sp, #4128]                 ; 16-byte Spill
	str	q2, [sp, #3952]                 ; 16-byte Spill
	str	q2, [sp, #3936]                 ; 16-byte Spill
	str	q2, [sp, #3920]                 ; 16-byte Spill
	str	q2, [sp, #3904]                 ; 16-byte Spill
	str	q2, [sp, #3888]                 ; 16-byte Spill
	str	q2, [sp, #4112]                 ; 16-byte Spill
	movi.2d	v3, #0000000000000000
	stp	q3, q3, [sp, #880]              ; 32-byte Folded Spill
	str	q3, [sp, #864]                  ; 16-byte Spill
	str	q3, [sp, #1760]                 ; 16-byte Spill
	str	q3, [sp, #1744]                 ; 16-byte Spill
	str	q19, [sp, #304]                 ; 16-byte Spill
LBB0_22:                                ; %direct.true233
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_24 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
                                        ;     Child Loop BB0_61 Depth 2
                                        ;     Child Loop BB0_63 Depth 2
                                        ;     Child Loop BB0_65 Depth 2
                                        ;     Child Loop BB0_67 Depth 2
                                        ;     Child Loop BB0_69 Depth 2
                                        ;     Child Loop BB0_71 Depth 2
                                        ;     Child Loop BB0_73 Depth 2
                                        ;     Child Loop BB0_75 Depth 2
                                        ;     Child Loop BB0_77 Depth 2
                                        ;     Child Loop BB0_79 Depth 2
                                        ;     Child Loop BB0_81 Depth 2
                                        ;     Child Loop BB0_83 Depth 2
                                        ;     Child Loop BB0_85 Depth 2
                                        ;     Child Loop BB0_87 Depth 2
                                        ;     Child Loop BB0_89 Depth 2
                                        ;     Child Loop BB0_91 Depth 2
                                        ;     Child Loop BB0_93 Depth 2
                                        ;     Child Loop BB0_95 Depth 2
                                        ;       Child Loop BB0_96 Depth 3
                                        ;     Child Loop BB0_99 Depth 2
                                        ;     Child Loop BB0_101 Depth 2
	str	q18, [sp, #3728]                ; 16-byte Spill
	str	q17, [sp, #3680]                ; 16-byte Spill
	str	q16, [sp, #848]                 ; 16-byte Spill
	str	q7, [sp, #3616]                 ; 16-byte Spill
	str	q6, [sp, #3632]                 ; 16-byte Spill
	str	q5, [sp, #3648]                 ; 16-byte Spill
	str	q4, [sp, #3664]                 ; 16-byte Spill
	mov	x3, #0                          ; =0x0
	lsl	x2, x0, #4
	b	LBB0_24
LBB0_23:                                ; %direct.schedule.12
                                        ;   in Loop: Header=BB0_24 Depth=2
	str	q17, [sp, #3888]                ; 16-byte Spill
	str	q16, [sp, #3904]                ; 16-byte Spill
	str	q7, [sp, #3920]                 ; 16-byte Spill
	ldr	q5, [sp, #3936]                 ; 16-byte Reload
	bit.16b	v5, v4, v0
	str	q5, [sp, #3936]                 ; 16-byte Spill
	ldr	q5, [sp, #3952]                 ; 16-byte Reload
	bit.16b	v5, v3, v1
	str	q5, [sp, #3952]                 ; 16-byte Spill
	add	x4, x12, x3, lsl #5
	ldp	q5, q6, [x4]
	bif.16b	v4, v6, v0
	bif.16b	v3, v5, v1
	stp	q3, q4, [x4]
	add	x3, x3, #1
	cmp	x3, #1280
	b.eq	LBB0_41
LBB0_24:                                ; %direct.true237
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w4, w3, #0xffff
	mul	w4, w4, w26
	lsr	w5, w4, #22
	add	x4, x2, x5
	dup.2d	v3, x4
	ldr	q4, [sp, #4064]                 ; 16-byte Reload
	add.2d	v4, v3, v4
	ldr	q5, [sp, #4048]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	ldr	q6, [sp, #4032]                 ; 16-byte Reload
	add.2d	v6, v3, v6
	mov.d	x6, v6[1]
	fmov	x7, d6
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	fmov	d6, x7
	add	x6, x6, x6, lsl #2
	lsl	x6, x6, #4
	mov.d	v6[1], x6
	mov.d	x6, v5[1]
	fmov	x7, d5
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	fmov	d5, x7
	add	x6, x6, x6, lsl #2
	lsl	x6, x6, #4
	mov.d	v5[1], x6
	mov.d	x6, v4[1]
	add.2d	v3, v3, v19
	fmov	x7, d4
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	fmov	d4, x7
	add	x6, x6, x6, lsl #2
	lsl	x6, x6, #4
	mov.d	v4[1], x6
	mov.d	x6, v3[1]
	fmov	x7, d3
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	fmov	d3, x7
	sshll.2d	v7, v1, #0
	msub	w5, w5, w27, w3
	and	x5, x5, #0xffff
	add	x6, x6, x6, lsl #2
	lsl	x6, x6, #4
	mov.d	v3[1], x6
	dup.2d	v16, x5
	sshll.2d	v17, v0, #0
	add.2d	v3, v3, v16
	add.2d	v4, v4, v16
	add.2d	v5, v5, v16
	add.2d	v6, v6, v16
	ldr	q16, [sp, #4112]                ; 16-byte Reload
	ldr	q18, [sp, #4080]                ; 16-byte Reload
	bit.16b	v16, v6, v18
	str	q16, [sp, #4112]                ; 16-byte Spill
	ldr	q6, [sp, #3888]                 ; 16-byte Reload
	bsl.16b	v17, v5, v6
	ldr	q16, [sp, #3904]                ; 16-byte Reload
	ldr	q5, [sp, #4096]                 ; 16-byte Reload
	bit.16b	v16, v4, v5
	ldr	q4, [sp, #3920]                 ; 16-byte Reload
	bsl.16b	v7, v3, v4
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	cmp	x4, #2052
	b.hi	LBB0_23
; %bb.25:                               ; %direct.true250
                                        ;   in Loop: Header=BB0_24 Depth=2
	ldr	q3, [sp, #3872]                 ; 16-byte Reload
	fmov	w4, s3
	shl.2d	v3, v7, #2
	dup.2d	v5, x16
	add.2d	v6, v5, v3
	movi.2d	v3, #0000000000000000
	tbz	w4, #0, LBB0_33
; %bb.26:                               ; %cond.load499
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x5, d6
	ldr	s3, [x5]
	and	w4, w4, #0xff
	tbnz	w4, #1, LBB0_34
LBB0_27:                                ; %else509
                                        ;   in Loop: Header=BB0_24 Depth=2
	shl.2d	v6, v16, #2
	add.2d	v6, v5, v6
	tbz	w4, #2, LBB0_35
LBB0_28:                                ; %cond.load511
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x5, d6
	ld1.s	{ v3 }[2], [x5]
	tbnz	w4, #3, LBB0_36
LBB0_29:                                ; %else521
                                        ;   in Loop: Header=BB0_24 Depth=2
	shl.2d	v6, v17, #2
	add.2d	v6, v5, v6
	tbz	w4, #4, LBB0_37
LBB0_30:                                ; %cond.load523
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x5, d6
	ld1.s	{ v4 }[0], [x5]
	tbnz	w4, #5, LBB0_38
LBB0_31:                                ; %else533
                                        ;   in Loop: Header=BB0_24 Depth=2
	ldr	q6, [sp, #4112]                 ; 16-byte Reload
	shl.2d	v6, v6, #2
	add.2d	v5, v5, v6
	tbz	w4, #6, LBB0_39
LBB0_32:                                ; %cond.load535
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x5, d5
	ld1.s	{ v4 }[2], [x5]
	tbz	w4, #7, LBB0_23
	b	LBB0_40
LBB0_33:                                ; %else503
                                        ;   in Loop: Header=BB0_24 Depth=2
	and	w4, w4, #0xff
	tbz	w4, #1, LBB0_27
LBB0_34:                                ; %cond.load505
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x5, v6[1]
	ld1.s	{ v3 }[1], [x5]
	shl.2d	v6, v16, #2
	add.2d	v6, v5, v6
	tbnz	w4, #2, LBB0_28
LBB0_35:                                ; %else515
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w4, #3, LBB0_29
LBB0_36:                                ; %cond.load517
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x5, v6[1]
	ld1.s	{ v3 }[3], [x5]
	shl.2d	v6, v17, #2
	add.2d	v6, v5, v6
	tbnz	w4, #4, LBB0_30
LBB0_37:                                ; %else527
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w4, #5, LBB0_31
LBB0_38:                                ; %cond.load529
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x5, v6[1]
	ld1.s	{ v4 }[1], [x5]
	ldr	q6, [sp, #4112]                 ; 16-byte Reload
	shl.2d	v6, v6, #2
	add.2d	v5, v5, v6
	tbnz	w4, #6, LBB0_32
LBB0_39:                                ; %else539
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w4, #7, LBB0_23
LBB0_40:                                ; %cond.load541
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x4, v5[1]
	ld1.s	{ v4 }[3], [x4]
	b	LBB0_23
LBB0_41:                                ; %direct.true262.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x3, #0                          ; =0x0
	b	LBB0_43
LBB0_42:                                ; %direct.schedule.17
                                        ;   in Loop: Header=BB0_43 Depth=2
	str	q17, [sp, #3968]                ; 16-byte Spill
	str	q16, [sp, #3984]                ; 16-byte Spill
	str	q7, [sp, #4000]                 ; 16-byte Spill
	ldr	q5, [sp, #4016]                 ; 16-byte Reload
	bit.16b	v5, v4, v0
	str	q5, [sp, #4016]                 ; 16-byte Spill
	bit.16b	v22, v3, v1
	add	x4, x13, x3, lsl #5
	ldp	q5, q6, [x4]
	bif.16b	v4, v6, v0
	bif.16b	v3, v5, v1
	stp	q3, q4, [x4]
	add	x3, x3, #1
	cmp	x3, #1536
	b.eq	LBB0_60
LBB0_43:                                ; %direct.true262
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w4, w3, #0xffff
	mul	w4, w4, w28
	lsr	w5, w4, #22
	add	x4, x2, x5
	dup.2d	v3, x4
	ldr	q4, [sp, #4064]                 ; 16-byte Reload
	add.2d	v4, v3, v4
	ldr	q5, [sp, #4048]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	ldr	q6, [sp, #4032]                 ; 16-byte Reload
	add.2d	v6, v3, v6
	mov.d	x6, v6[1]
	fmov	x7, d6
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	fmov	d6, x7
	add	x6, x6, x6, lsl #1
	lsl	x6, x6, #5
	mov.d	v6[1], x6
	mov.d	x6, v5[1]
	fmov	x7, d5
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	fmov	d5, x7
	add	x6, x6, x6, lsl #1
	lsl	x6, x6, #5
	mov.d	v5[1], x6
	mov.d	x6, v4[1]
	add.2d	v3, v3, v19
	fmov	x7, d4
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	fmov	d4, x7
	add	x6, x6, x6, lsl #1
	lsl	x6, x6, #5
	mov.d	v4[1], x6
	mov.d	x6, v3[1]
	fmov	x7, d3
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	fmov	d3, x7
	sshll.2d	v7, v1, #0
	msub	w5, w5, w30, w3
	and	x5, x5, #0xffff
	add	x6, x6, x6, lsl #1
	lsl	x6, x6, #5
	mov.d	v3[1], x6
	dup.2d	v16, x5
	sshll.2d	v17, v0, #0
	add.2d	v3, v3, v16
	add.2d	v4, v4, v16
	add.2d	v5, v5, v16
	add.2d	v6, v6, v16
	ldr	q16, [sp, #4128]                ; 16-byte Reload
	ldr	q18, [sp, #4080]                ; 16-byte Reload
	bit.16b	v16, v6, v18
	str	q16, [sp, #4128]                ; 16-byte Spill
	ldr	q6, [sp, #3968]                 ; 16-byte Reload
	bsl.16b	v17, v5, v6
	ldr	q16, [sp, #3984]                ; 16-byte Reload
	ldr	q5, [sp, #4096]                 ; 16-byte Reload
	bit.16b	v16, v4, v5
	ldr	q4, [sp, #4000]                 ; 16-byte Reload
	bsl.16b	v7, v3, v4
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	cmp	x4, #2053
	b.hs	LBB0_42
; %bb.44:                               ; %direct.true275
                                        ;   in Loop: Header=BB0_43 Depth=2
	ldr	q3, [sp, #3872]                 ; 16-byte Reload
	fmov	w4, s3
	shl.2d	v3, v7, #2
	dup.2d	v5, x17
	add.2d	v6, v5, v3
	movi.2d	v3, #0000000000000000
	tbz	w4, #0, LBB0_52
; %bb.45:                               ; %cond.load548
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x5, d6
	ldr	s3, [x5]
	and	w4, w4, #0xff
	tbnz	w4, #1, LBB0_53
LBB0_46:                                ; %else558
                                        ;   in Loop: Header=BB0_43 Depth=2
	shl.2d	v6, v16, #2
	add.2d	v6, v5, v6
	tbz	w4, #2, LBB0_54
LBB0_47:                                ; %cond.load560
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x5, d6
	ld1.s	{ v3 }[2], [x5]
	tbnz	w4, #3, LBB0_55
LBB0_48:                                ; %else570
                                        ;   in Loop: Header=BB0_43 Depth=2
	shl.2d	v6, v17, #2
	add.2d	v6, v5, v6
	tbz	w4, #4, LBB0_56
LBB0_49:                                ; %cond.load572
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x5, d6
	ld1.s	{ v4 }[0], [x5]
	tbnz	w4, #5, LBB0_57
LBB0_50:                                ; %else582
                                        ;   in Loop: Header=BB0_43 Depth=2
	ldr	q6, [sp, #4128]                 ; 16-byte Reload
	shl.2d	v6, v6, #2
	add.2d	v5, v5, v6
	tbz	w4, #6, LBB0_58
LBB0_51:                                ; %cond.load584
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x5, d5
	ld1.s	{ v4 }[2], [x5]
	tbz	w4, #7, LBB0_42
	b	LBB0_59
LBB0_52:                                ; %else552
                                        ;   in Loop: Header=BB0_43 Depth=2
	and	w4, w4, #0xff
	tbz	w4, #1, LBB0_46
LBB0_53:                                ; %cond.load554
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x5, v6[1]
	ld1.s	{ v3 }[1], [x5]
	shl.2d	v6, v16, #2
	add.2d	v6, v5, v6
	tbnz	w4, #2, LBB0_47
LBB0_54:                                ; %else564
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w4, #3, LBB0_48
LBB0_55:                                ; %cond.load566
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x5, v6[1]
	ld1.s	{ v3 }[3], [x5]
	shl.2d	v6, v17, #2
	add.2d	v6, v5, v6
	tbnz	w4, #4, LBB0_49
LBB0_56:                                ; %else576
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w4, #5, LBB0_50
LBB0_57:                                ; %cond.load578
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x5, v6[1]
	ld1.s	{ v4 }[1], [x5]
	ldr	q6, [sp, #4128]                 ; 16-byte Reload
	shl.2d	v6, v6, #2
	add.2d	v5, v5, v6
	tbnz	w4, #6, LBB0_51
LBB0_58:                                ; %else588
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w4, #7, LBB0_42
LBB0_59:                                ; %cond.load590
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x4, v5[1]
	ld1.s	{ v4 }[3], [x4]
	b	LBB0_42
LBB0_60:                                ; %direct.false263
                                        ;   in Loop: Header=BB0_22 Depth=1
	sshll.2d	v3, v1, #0
	sshll.2d	v4, v0, #0
	ldr	q5, [sp, #1552]                 ; 16-byte Reload
	ldr	q6, [sp, #880]                  ; 16-byte Reload
	bit.16b	v6, v5, v4
	str	q6, [sp, #880]                  ; 16-byte Spill
	ldr	q4, [sp, #1728]                 ; 16-byte Reload
	bif.16b	v4, v2, v3
	stp	q4, q22, [sp, #800]             ; 32-byte Folded Spill
	bic.16b	v2, v2, v3
	ldr	x2, [sp, #296]                  ; 8-byte Reload
	ldp	q5, q4, [x2]
	fmov	x2, d2
	add	x2, x12, x2
	ldp	q3, q2, [x2]
	str	q5, [sp, #3840]                 ; 16-byte Spill
	fmul.4s	v3, v5, v3
	str	q4, [sp, #3856]                 ; 16-byte Spill
	fmul.4s	v2, v4, v2
	ldp	q7, q6, [x10, #32]
	ldr	q4, [x10, #8752]
	ldr	q5, [x10, #8736]
	str	q7, [sp, #3808]                 ; 16-byte Spill
	fmul.4s	v5, v7, v5
	str	q6, [sp, #3824]                 ; 16-byte Spill
	fmul.4s	v4, v6, v4
	mov.16b	v22, v0
	bsl.16b	v22, v2, v29
	ldp	q7, q6, [x10, #64]
	mov.16b	v29, v1
	bsl.16b	v29, v3, v23
	ldr	q2, [x10, #8784]
	bit.16b	v24, v4, v0
	ldr	q3, [x10, #8768]
	str	q7, [sp, #3776]                 ; 16-byte Spill
	fmul.4s	v3, v7, v3
	str	q6, [sp, #3792]                 ; 16-byte Spill
	fmul.4s	v2, v6, v2
	bit.16b	v9, v5, v1
	bit.16b	v31, v2, v0
	ldp	q5, q4, [x10, #96]
	bit.16b	v20, v3, v1
	ldr	q2, [x10, #8816]
	str	q4, [sp, #3760]                 ; 16-byte Spill
	fmul.4s	v2, v4, v2
	mov.16b	v23, v24
	mov.16b	v24, v9
	mov.16b	v9, v31
	mov.16b	v31, v20
	ldr	q20, [sp, #912]                 ; 16-byte Reload
	bit.16b	v20, v2, v0
	ldr	q2, [x10, #8800]
	str	q5, [sp, #3744]                 ; 16-byte Spill
	fmul.4s	v2, v5, v2
	bit.16b	v8, v2, v1
	ldr	q2, [sp, #1600]                 ; 16-byte Reload
	ldr	q3, [sp, #864]                  ; 16-byte Reload
	ldr	q4, [sp, #4080]                 ; 16-byte Reload
	bit.16b	v3, v2, v4
	str	q3, [sp, #864]                  ; 16-byte Spill
	ldr	q2, [sp, #1568]                 ; 16-byte Reload
	ldr	q3, [sp, #896]                  ; 16-byte Reload
	ldr	q4, [sp, #4096]                 ; 16-byte Reload
	bit.16b	v3, v2, v4
	str	q3, [sp, #896]                  ; 16-byte Spill
	mov	x2, x10
	mov	w3, #279                        ; =0x117
LBB0_61:                                ; %direct.true327
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x2, #128]!
	ldr	q3, [x2, #8704]
	ldr	q4, [x2, #8720]
	ldp	q5, q6, [x2, #16]
	fmul.4s	v4, v5, v4
	fmul.4s	v2, v2, v3
	fadd.4s	v2, v29, v2
	fadd.4s	v3, v22, v4
	ldr	q4, [x2, #8736]
	ldr	q5, [x2, #8752]
	ldp	q7, q16, [x2, #48]
	fmul.4s	v5, v7, v5
	fmul.4s	v4, v6, v4
	fadd.4s	v4, v24, v4
	fadd.4s	v5, v23, v5
	ldr	q6, [x2, #8768]
	ldr	q7, [x2, #8784]
	ldp	q17, q18, [x2, #80]
	fmul.4s	v7, v17, v7
	fmul.4s	v6, v16, v6
	fadd.4s	v6, v31, v6
	fadd.4s	v7, v9, v7
	ldr	q16, [x2, #112]
	ldr	q17, [x2, #8800]
	ldr	q19, [x2, #8816]
	fmul.4s	v16, v16, v19
	fmul.4s	v17, v18, v17
	fadd.4s	v17, v8, v17
	fadd.4s	v16, v20, v16
	bit.16b	v22, v3, v0
	bit.16b	v29, v2, v1
	bit.16b	v23, v5, v0
	bit.16b	v24, v4, v1
	bit.16b	v9, v7, v0
	bit.16b	v31, v6, v1
	bit.16b	v20, v16, v0
	bit.16b	v8, v17, v1
	sub	x4, x3, #275
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_61
; %bb.62:                               ; %direct.false328
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q16, [sp, #1808]                ; 16-byte Spill
	str	q17, [sp, #1824]                ; 16-byte Spill
	str	q22, [sp, #1840]                ; 16-byte Spill
	str	q29, [sp, #1856]                ; 16-byte Spill
	str	q23, [sp, #1872]                ; 16-byte Spill
	str	q24, [sp, #1888]                ; 16-byte Spill
	str	q9, [sp, #1904]                 ; 16-byte Spill
	str	q31, [sp, #1920]                ; 16-byte Spill
	str	q20, [sp, #912]                 ; 16-byte Spill
	str	q8, [sp, #832]                  ; 16-byte Spill
	ldr	q2, [x10, #11280]
	ldr	q3, [x10, #11264]
	ldr	q4, [sp, #3840]                 ; 16-byte Reload
	fmul.4s	v3, v4, v3
	ldr	q4, [sp, #3856]                 ; 16-byte Reload
	fmul.4s	v2, v4, v2
	ldr	q4, [x10, #11312]
	ldr	q5, [x10, #11296]
	ldr	q6, [sp, #3808]                 ; 16-byte Reload
	fmul.4s	v5, v6, v5
	ldr	q6, [sp, #3824]                 ; 16-byte Reload
	fmul.4s	v4, v6, v4
	ldr	q6, [x10, #11344]
	ldr	q7, [x10, #11328]
	ldr	q16, [sp, #3776]                ; 16-byte Reload
	fmul.4s	v7, v16, v7
	ldr	q16, [sp, #3792]                ; 16-byte Reload
	fmul.4s	v6, v16, v6
	ldr	q16, [x10, #11376]
	ldr	q17, [x10, #11360]
	ldr	q18, [sp, #3744]                ; 16-byte Reload
	fmul.4s	v17, v18, v17
	ldr	q18, [sp, #3760]                ; 16-byte Reload
	fmul.4s	v16, v18, v16
	bit.16b	v28, v2, v0
	bit.16b	v25, v3, v1
	bit.16b	v10, v4, v0
	bit.16b	v15, v5, v1
	ldr	q22, [sp, #2112]                ; 16-byte Reload
	bit.16b	v22, v6, v0
	ldr	q29, [sp, #2128]                ; 16-byte Reload
	bit.16b	v29, v7, v1
	ldp	q20, q23, [sp, #944]            ; 32-byte Folded Reload
	bit.16b	v20, v16, v0
	bit.16b	v23, v17, v1
	mov	x2, x10
	mov	w3, #359                        ; =0x167
LBB0_63:                                ; %direct.true447
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x2, #128]!
	ldr	q3, [x2, #11264]
	ldr	q4, [x2, #11280]
	ldp	q5, q6, [x2, #16]
	fmul.4s	v4, v5, v4
	fmul.4s	v2, v2, v3
	fadd.4s	v2, v25, v2
	fadd.4s	v3, v28, v4
	ldr	q4, [x2, #11296]
	ldr	q5, [x2, #11312]
	ldp	q7, q16, [x2, #48]
	fmul.4s	v5, v7, v5
	fmul.4s	v4, v6, v4
	fadd.4s	v4, v15, v4
	fadd.4s	v5, v10, v5
	ldr	q6, [x2, #11328]
	ldr	q7, [x2, #11344]
	ldp	q17, q18, [x2, #80]
	fmul.4s	v7, v17, v7
	fmul.4s	v6, v16, v6
	fadd.4s	v6, v29, v6
	fadd.4s	v7, v22, v7
	ldr	q16, [x2, #112]
	ldr	q17, [x2, #11360]
	mov.16b	v8, v28
	mov.16b	v28, v25
	mov.16b	v25, v10
	ldr	q19, [x2, #11376]
	fmul.4s	v16, v16, v19
	mov.16b	v10, v25
	mov.16b	v25, v28
	fmul.4s	v17, v18, v17
	fadd.4s	v17, v23, v17
	fadd.4s	v16, v20, v16
	mov.16b	v28, v0
	bsl.16b	v28, v3, v8
	bit.16b	v25, v2, v1
	bit.16b	v10, v5, v0
	bit.16b	v15, v4, v1
	bit.16b	v22, v7, v0
	bit.16b	v29, v6, v1
	bit.16b	v20, v16, v0
	bit.16b	v23, v17, v1
	sub	x4, x3, #355
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_63
; %bb.64:                               ; %direct.false448
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q22, [sp, #2112]                ; 16-byte Spill
	str	q16, [sp, #1776]                ; 16-byte Spill
	str	q17, [sp, #1792]                ; 16-byte Spill
	str	q25, [sp, #1952]                ; 16-byte Spill
	str	q29, [sp, #2128]                ; 16-byte Spill
	stp	q20, q23, [sp, #944]            ; 32-byte Folded Spill
	ldr	q2, [x10, #13840]
	ldr	q3, [x10, #13824]
	ldr	q4, [sp, #3840]                 ; 16-byte Reload
	fmul.4s	v3, v4, v3
	ldr	q4, [sp, #3856]                 ; 16-byte Reload
	fmul.4s	v2, v4, v2
	ldr	q4, [x10, #13872]
	ldr	q5, [x10, #13856]
	ldr	q6, [sp, #3808]                 ; 16-byte Reload
	fmul.4s	v5, v6, v5
	ldr	q6, [sp, #3824]                 ; 16-byte Reload
	fmul.4s	v4, v6, v4
	ldr	q6, [x10, #13904]
	ldr	q7, [x10, #13888]
	ldr	q16, [sp, #3776]                ; 16-byte Reload
	fmul.4s	v7, v16, v7
	ldr	q16, [sp, #3792]                ; 16-byte Reload
	fmul.4s	v6, v16, v6
	ldr	q16, [x10, #13936]
	ldr	q17, [x10, #13920]
	ldr	q18, [sp, #3744]                ; 16-byte Reload
	fmul.4s	v17, v18, v17
	ldr	q18, [sp, #3760]                ; 16-byte Reload
	fmul.4s	v16, v18, v16
	bit.16b	v27, v2, v0
	bit.16b	v21, v3, v1
	bit.16b	v26, v4, v0
	bit.16b	v14, v5, v1
	bit.16b	v13, v6, v0
	ldr	q20, [sp, #2160]                ; 16-byte Reload
	bit.16b	v20, v7, v1
	ldp	q19, q25, [sp, #992]            ; 32-byte Folded Reload
	bit.16b	v19, v16, v0
	bit.16b	v25, v17, v1
	mov	x2, x10
	mov	w3, #439                        ; =0x1b7
	ldr	q31, [sp, #2448]                ; 16-byte Reload
	ldr	q23, [sp, #1088]                ; 16-byte Reload
	ldr	q24, [sp, #2592]                ; 16-byte Reload
LBB0_65:                                ; %direct.true567
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x2, #128]!
	ldr	q3, [x2, #13824]
	ldr	q4, [x2, #13840]
	ldp	q5, q6, [x2, #16]
	fmul.4s	v4, v5, v4
	fmul.4s	v2, v2, v3
	fadd.4s	v2, v21, v2
	fadd.4s	v3, v27, v4
	ldr	q4, [x2, #13856]
	ldr	q5, [x2, #13872]
	ldp	q7, q16, [x2, #48]
	fmul.4s	v5, v7, v5
	fmul.4s	v4, v6, v4
	fadd.4s	v4, v14, v4
	fadd.4s	v5, v26, v5
	ldr	q6, [x2, #13888]
	ldr	q7, [x2, #13904]
	ldp	q17, q18, [x2, #80]
	fmul.4s	v7, v17, v7
	fmul.4s	v6, v16, v6
	fadd.4s	v6, v20, v6
	fadd.4s	v7, v13, v7
	ldr	q16, [x2, #112]
	ldr	q17, [x2, #13920]
	mov.16b	v22, v27
	mov.16b	v27, v21
	mov.16b	v21, v26
	mov.16b	v26, v14
	mov.16b	v14, v13
	mov.16b	v13, v20
	ldr	q20, [x2, #13936]
	fmul.4s	v16, v16, v20
	mov.16b	v20, v13
	mov.16b	v13, v14
	mov.16b	v14, v26
	mov.16b	v26, v21
	mov.16b	v21, v27
	fmul.4s	v17, v18, v17
	fadd.4s	v17, v25, v17
	fadd.4s	v16, v19, v16
	mov.16b	v27, v0
	bsl.16b	v27, v3, v22
	bit.16b	v21, v2, v1
	bit.16b	v26, v5, v0
	bit.16b	v14, v4, v1
	bit.16b	v13, v7, v0
	bit.16b	v20, v6, v1
	bit.16b	v19, v16, v0
	bit.16b	v25, v17, v1
	sub	x4, x3, #435
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_65
; %bb.66:                               ; %direct.false568
                                        ;   in Loop: Header=BB0_22 Depth=1
	stp	q16, q17, [sp, #768]            ; 32-byte Folded Spill
	str	q27, [sp, #2000]                ; 16-byte Spill
	str	q21, [sp, #2016]                ; 16-byte Spill
	str	q26, [sp, #2032]                ; 16-byte Spill
	str	q14, [sp, #2048]                ; 16-byte Spill
	str	q13, [sp, #2064]                ; 16-byte Spill
	str	q20, [sp, #2160]                ; 16-byte Spill
	stp	q19, q25, [sp, #992]            ; 32-byte Folded Spill
	ldr	q2, [x10, #16400]
	ldr	q3, [x10, #16384]
	ldr	q4, [sp, #3840]                 ; 16-byte Reload
	fmul.4s	v3, v4, v3
	ldr	q4, [sp, #3856]                 ; 16-byte Reload
	fmul.4s	v2, v4, v2
	ldr	q4, [x10, #16432]
	ldr	q5, [x10, #16416]
	ldr	q6, [sp, #3808]                 ; 16-byte Reload
	fmul.4s	v5, v6, v5
	ldr	q6, [sp, #3824]                 ; 16-byte Reload
	fmul.4s	v4, v6, v4
	ldr	q6, [x10, #16464]
	ldr	q7, [x10, #16448]
	ldr	q16, [sp, #3776]                ; 16-byte Reload
	fmul.4s	v7, v16, v7
	ldr	q16, [sp, #3792]                ; 16-byte Reload
	fmul.4s	v6, v16, v6
	ldr	q16, [x10, #16496]
	ldr	q17, [x10, #16480]
	ldr	q18, [sp, #3744]                ; 16-byte Reload
	fmul.4s	v17, v18, v17
	ldr	q18, [sp, #3760]                ; 16-byte Reload
	fmul.4s	v16, v18, v16
	ldr	q22, [sp, #2192]                ; 16-byte Reload
	bit.16b	v22, v2, v0
	ldr	q27, [sp, #2208]                ; 16-byte Reload
	bit.16b	v27, v3, v1
	ldr	q21, [sp, #2224]                ; 16-byte Reload
	bit.16b	v21, v4, v0
	ldr	q26, [sp, #2240]                ; 16-byte Reload
	bit.16b	v26, v5, v1
	ldr	q14, [sp, #2256]                ; 16-byte Reload
	bit.16b	v14, v6, v0
	ldr	q25, [sp, #2272]                ; 16-byte Reload
	bit.16b	v25, v7, v1
	ldr	q13, [sp, #1040]                ; 16-byte Reload
	bit.16b	v13, v16, v0
	ldr	q8, [sp, #1056]                 ; 16-byte Reload
	bit.16b	v8, v17, v1
	mov	x2, x10
	mov	w3, #519                        ; =0x207
	ldr	q19, [sp, #1312]                ; 16-byte Reload
	ldr	q29, [sp, #2832]                ; 16-byte Reload
LBB0_67:                                ; %direct.true687
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x2, #128]!
	ldr	q3, [x2, #16384]
	ldr	q4, [x2, #16400]
	ldp	q5, q6, [x2, #16]
	fmul.4s	v4, v5, v4
	fmul.4s	v2, v2, v3
	fadd.4s	v2, v27, v2
	fadd.4s	v3, v22, v4
	ldr	q4, [x2, #16416]
	ldr	q5, [x2, #16432]
	ldp	q7, q16, [x2, #48]
	fmul.4s	v5, v7, v5
	fmul.4s	v4, v6, v4
	fadd.4s	v4, v26, v4
	fadd.4s	v5, v21, v5
	ldr	q6, [x2, #16448]
	ldr	q7, [x2, #16464]
	ldp	q17, q18, [x2, #80]
	fmul.4s	v7, v17, v7
	fmul.4s	v6, v16, v6
	fadd.4s	v6, v25, v6
	fadd.4s	v7, v14, v7
	ldr	q16, [x2, #112]
	ldr	q17, [x2, #16480]
	ldr	q20, [x2, #16496]
	fmul.4s	v16, v16, v20
	fmul.4s	v17, v18, v17
	fadd.4s	v17, v8, v17
	fadd.4s	v16, v13, v16
	bit.16b	v22, v3, v0
	bit.16b	v27, v2, v1
	bit.16b	v21, v5, v0
	bit.16b	v26, v4, v1
	bit.16b	v14, v7, v0
	bit.16b	v25, v6, v1
	bit.16b	v13, v16, v0
	bit.16b	v8, v17, v1
	sub	x4, x3, #515
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_67
; %bb.68:                               ; %direct.false688
                                        ;   in Loop: Header=BB0_22 Depth=1
	stp	q16, q17, [sp, #736]            ; 32-byte Folded Spill
	str	q22, [sp, #2192]                ; 16-byte Spill
	str	q27, [sp, #2208]                ; 16-byte Spill
	str	q21, [sp, #2224]                ; 16-byte Spill
	str	q26, [sp, #2240]                ; 16-byte Spill
	str	q14, [sp, #2256]                ; 16-byte Spill
	str	q25, [sp, #2272]                ; 16-byte Spill
	str	q13, [sp, #1040]                ; 16-byte Spill
	str	q8, [sp, #1056]                 ; 16-byte Spill
	ldr	q2, [x10, #18960]
	ldr	q3, [x10, #18944]
	ldr	q4, [sp, #3840]                 ; 16-byte Reload
	fmul.4s	v3, v4, v3
	ldr	q4, [sp, #3856]                 ; 16-byte Reload
	fmul.4s	v2, v4, v2
	ldr	q4, [x10, #18992]
	ldr	q5, [x10, #18976]
	ldr	q6, [sp, #3808]                 ; 16-byte Reload
	fmul.4s	v5, v6, v5
	ldr	q6, [sp, #3824]                 ; 16-byte Reload
	fmul.4s	v4, v6, v4
	ldr	q6, [x10, #19024]
	ldr	q7, [x10, #19008]
	ldr	q16, [sp, #3776]                ; 16-byte Reload
	fmul.4s	v7, v16, v7
	ldr	q16, [sp, #3792]                ; 16-byte Reload
	fmul.4s	v6, v16, v6
	ldr	q16, [x10, #19056]
	ldr	q17, [x10, #19040]
	ldr	q18, [sp, #3744]                ; 16-byte Reload
	fmul.4s	v17, v18, v17
	ldr	q18, [sp, #3760]                ; 16-byte Reload
	fmul.4s	v16, v18, v16
	ldr	q25, [sp, #2320]                ; 16-byte Reload
	bit.16b	v25, v2, v0
	ldr	q26, [sp, #2336]                ; 16-byte Reload
	bit.16b	v26, v3, v1
	ldr	q14, [sp, #2352]                ; 16-byte Reload
	bit.16b	v14, v4, v0
	ldr	q13, [sp, #2368]                ; 16-byte Reload
	bit.16b	v13, v5, v1
	ldr	q22, [sp, #2384]                ; 16-byte Reload
	bit.16b	v22, v6, v0
	ldr	q27, [sp, #3728]                ; 16-byte Reload
	bit.16b	v27, v7, v1
	ldr	q21, [sp, #1072]                ; 16-byte Reload
	bit.16b	v21, v16, v0
	bit.16b	v23, v17, v1
	mov	x2, x10
	mov	w3, #599                        ; =0x257
LBB0_69:                                ; %direct.true807
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x2, #128]!
	ldr	q3, [x2, #18944]
	ldr	q4, [x2, #18960]
	ldp	q5, q6, [x2, #16]
	fmul.4s	v4, v5, v4
	fmul.4s	v2, v2, v3
	fadd.4s	v2, v26, v2
	fadd.4s	v3, v25, v4
	ldr	q4, [x2, #18976]
	ldr	q5, [x2, #18992]
	ldp	q7, q16, [x2, #48]
	fmul.4s	v5, v7, v5
	fmul.4s	v4, v6, v4
	fadd.4s	v4, v13, v4
	fadd.4s	v5, v14, v5
	ldr	q6, [x2, #19008]
	ldr	q7, [x2, #19024]
	ldp	q17, q18, [x2, #80]
	fmul.4s	v7, v17, v7
	fmul.4s	v6, v16, v6
	fadd.4s	v6, v27, v6
	fadd.4s	v7, v22, v7
	ldr	q16, [x2, #112]
	ldr	q17, [x2, #19040]
	ldr	q20, [x2, #19056]
	fmul.4s	v16, v16, v20
	fmul.4s	v17, v18, v17
	fadd.4s	v17, v23, v17
	fadd.4s	v16, v21, v16
	bit.16b	v25, v3, v0
	bit.16b	v26, v2, v1
	bit.16b	v14, v5, v0
	bit.16b	v13, v4, v1
	bit.16b	v22, v7, v0
	bit.16b	v27, v6, v1
	bit.16b	v21, v16, v0
	bit.16b	v23, v17, v1
	sub	x4, x3, #595
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_69
; %bb.70:                               ; %direct.false808
                                        ;   in Loop: Header=BB0_22 Depth=1
	stp	q16, q17, [sp, #704]            ; 32-byte Folded Spill
	str	q10, [sp, #1968]                ; 16-byte Spill
	str	q25, [sp, #2320]                ; 16-byte Spill
	str	q26, [sp, #2336]                ; 16-byte Spill
	str	q14, [sp, #2352]                ; 16-byte Spill
	str	q13, [sp, #2368]                ; 16-byte Spill
	str	q22, [sp, #2384]                ; 16-byte Spill
	str	q27, [sp, #3728]                ; 16-byte Spill
	str	q21, [sp, #1072]                ; 16-byte Spill
	str	q23, [sp, #1088]                ; 16-byte Spill
	ldr	q2, [x10, #21520]
	ldr	q3, [x10, #21504]
	ldr	q4, [sp, #3840]                 ; 16-byte Reload
	fmul.4s	v3, v4, v3
	ldr	q4, [sp, #3856]                 ; 16-byte Reload
	fmul.4s	v2, v4, v2
	ldr	q4, [x10, #21552]
	ldr	q5, [x10, #21536]
	ldr	q6, [sp, #3808]                 ; 16-byte Reload
	fmul.4s	v5, v6, v5
	ldr	q6, [sp, #3824]                 ; 16-byte Reload
	fmul.4s	v4, v6, v4
	ldr	q6, [x10, #21584]
	ldr	q7, [x10, #21568]
	ldr	q16, [sp, #3776]                ; 16-byte Reload
	fmul.4s	v7, v16, v7
	ldr	q16, [sp, #3792]                ; 16-byte Reload
	fmul.4s	v6, v16, v6
	ldr	q16, [x10, #21616]
	ldr	q18, [x10, #21600]
	ldr	q17, [sp, #3744]                ; 16-byte Reload
	fmul.4s	v18, v17, v18
	ldr	q17, [sp, #3760]                ; 16-byte Reload
	fmul.4s	v16, v17, v16
	ldr	q13, [sp, #2432]                ; 16-byte Reload
	bit.16b	v13, v2, v0
	bit.16b	v31, v3, v1
	bit.16b	v30, v4, v0
	ldr	q20, [sp, #2464]                ; 16-byte Reload
	bit.16b	v20, v5, v1
	ldr	q27, [sp, #2480]                ; 16-byte Reload
	bit.16b	v27, v6, v0
	ldr	q22, [sp, #2496]                ; 16-byte Reload
	bit.16b	v22, v7, v1
	ldr	q17, [sp, #1104]                ; 16-byte Reload
	bit.16b	v17, v16, v0
	ldr	q23, [sp, #1120]                ; 16-byte Reload
	bit.16b	v23, v18, v1
	mov	x2, x10
	mov	w3, #679                        ; =0x2a7
LBB0_71:                                ; %direct.true927
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x2, #128]!
	ldr	q3, [x2, #21504]
	ldr	q4, [x2, #21520]
	ldp	q5, q6, [x2, #16]
	fmul.4s	v4, v5, v4
	fmul.4s	v2, v2, v3
	fadd.4s	v3, v31, v2
	fadd.4s	v4, v13, v4
	ldr	q2, [x2, #21536]
	ldr	q5, [x2, #21552]
	ldp	q7, q16, [x2, #48]
	fmul.4s	v5, v7, v5
	fmul.4s	v2, v6, v2
	fadd.4s	v6, v20, v2
	fadd.4s	v5, v30, v5
	ldr	q2, [x2, #21568]
	ldr	q7, [x2, #21584]
	mov.16b	v8, v30
	mov.16b	v30, v20
	ldp	q18, q20, [x2, #80]
	fmul.4s	v7, v18, v7
	fmul.4s	v2, v16, v2
	fadd.4s	v16, v22, v2
	fadd.4s	v7, v27, v7
	ldr	q2, [x2, #112]
	ldr	q18, [x2, #21600]
	ldr	q21, [x2, #21616]
	fmul.4s	v2, v2, v21
	fmul.4s	v18, v20, v18
	mov.16b	v20, v30
	fadd.4s	v18, v23, v18
	fadd.4s	v2, v17, v2
	bit.16b	v13, v4, v0
	bit.16b	v31, v3, v1
	mov.16b	v30, v0
	bsl.16b	v30, v5, v8
	bit.16b	v20, v6, v1
	bit.16b	v27, v7, v0
	bit.16b	v22, v16, v1
	bit.16b	v17, v2, v0
	bit.16b	v23, v18, v1
	sub	x4, x3, #675
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_71
; %bb.72:                               ; %direct.false928
                                        ;   in Loop: Header=BB0_22 Depth=1
	stp	q2, q18, [sp, #672]             ; 32-byte Folded Spill
	str	q13, [sp, #2432]                ; 16-byte Spill
	str	q31, [sp, #2448]                ; 16-byte Spill
	str	q28, [sp, #1936]                ; 16-byte Spill
	str	q15, [sp, #1984]                ; 16-byte Spill
	str	q30, [sp, #2080]                ; 16-byte Spill
	str	q20, [sp, #2464]                ; 16-byte Spill
	str	q27, [sp, #2480]                ; 16-byte Spill
	str	q22, [sp, #2496]                ; 16-byte Spill
	str	q17, [sp, #1104]                ; 16-byte Spill
	str	q23, [sp, #1120]                ; 16-byte Spill
	ldr	q3, [x10, #24080]
	ldr	q4, [x10, #24064]
	ldr	q2, [sp, #3840]                 ; 16-byte Reload
	fmul.4s	v4, v2, v4
	ldr	q2, [sp, #3856]                 ; 16-byte Reload
	fmul.4s	v3, v2, v3
	ldr	q5, [x10, #24112]
	ldr	q6, [x10, #24096]
	ldr	q2, [sp, #3808]                 ; 16-byte Reload
	fmul.4s	v6, v2, v6
	ldr	q2, [sp, #3824]                 ; 16-byte Reload
	fmul.4s	v5, v2, v5
	ldr	q7, [x10, #24144]
	ldr	q16, [x10, #24128]
	ldr	q2, [sp, #3776]                 ; 16-byte Reload
	fmul.4s	v16, v2, v16
	ldr	q2, [sp, #3792]                 ; 16-byte Reload
	fmul.4s	v7, v2, v7
	ldr	q18, [x10, #24176]
	ldr	q20, [x10, #24160]
	ldr	q2, [sp, #3744]                 ; 16-byte Reload
	fmul.4s	v20, v2, v20
	ldr	q2, [sp, #3760]                 ; 16-byte Reload
	fmul.4s	v18, v2, v18
	ldr	q30, [sp, #2544]                ; 16-byte Reload
	bit.16b	v30, v3, v0
	ldr	q10, [sp, #2560]                ; 16-byte Reload
	bit.16b	v10, v4, v1
	ldr	q23, [sp, #2576]                ; 16-byte Reload
	bit.16b	v23, v5, v0
	bit.16b	v24, v6, v1
	ldr	q9, [sp, #2608]                 ; 16-byte Reload
	bit.16b	v9, v7, v0
	ldr	q21, [sp, #2624]                ; 16-byte Reload
	bit.16b	v21, v16, v1
	ldr	q2, [sp, #1136]                 ; 16-byte Reload
	bit.16b	v2, v18, v0
	ldr	q28, [sp, #1152]                ; 16-byte Reload
	bit.16b	v28, v20, v1
	mov	x2, x10
	mov	w3, #759                        ; =0x2f7
	ldr	q17, [sp, #1440]                ; 16-byte Reload
	ldr	q14, [sp, #2720]                ; 16-byte Reload
	ldr	q26, [sp, #2704]                ; 16-byte Reload
	ldr	q25, [sp, #1232]                ; 16-byte Reload
LBB0_73:                                ; %direct.true1047
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x2, #128]!
	ldr	q4, [x2, #24064]
	ldr	q5, [x2, #24080]
	ldp	q6, q7, [x2, #16]
	fmul.4s	v5, v6, v5
	fmul.4s	v3, v3, v4
	fadd.4s	v3, v10, v3
	fadd.4s	v4, v30, v5
	ldr	q5, [x2, #24096]
	ldr	q6, [x2, #24112]
	ldp	q16, q18, [x2, #48]
	fmul.4s	v6, v16, v6
	fmul.4s	v5, v7, v5
	fadd.4s	v5, v24, v5
	fadd.4s	v6, v23, v6
	ldr	q7, [x2, #24128]
	ldr	q16, [x2, #24144]
	ldp	q20, q22, [x2, #80]
	fmul.4s	v16, v20, v16
	fmul.4s	v7, v18, v7
	fadd.4s	v7, v21, v7
	fadd.4s	v16, v9, v16
	ldr	q18, [x2, #112]
	ldr	q20, [x2, #24160]
	ldr	q27, [x2, #24176]
	fmul.4s	v18, v18, v27
	fmul.4s	v20, v22, v20
	fadd.4s	v20, v28, v20
	fadd.4s	v18, v2, v18
	bit.16b	v30, v4, v0
	bit.16b	v10, v3, v1
	bit.16b	v23, v6, v0
	bit.16b	v24, v5, v1
	bit.16b	v9, v16, v0
	bit.16b	v21, v7, v1
	bit.16b	v2, v18, v0
	bit.16b	v28, v20, v1
	sub	x4, x3, #755
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_73
; %bb.74:                               ; %direct.false1048
                                        ;   in Loop: Header=BB0_22 Depth=1
	stp	q18, q20, [sp, #640]            ; 32-byte Folded Spill
	str	q30, [sp, #2544]                ; 16-byte Spill
	str	q10, [sp, #2560]                ; 16-byte Spill
	str	q23, [sp, #2576]                ; 16-byte Spill
	str	q24, [sp, #2592]                ; 16-byte Spill
	str	q9, [sp, #2608]                 ; 16-byte Spill
	str	q21, [sp, #2624]                ; 16-byte Spill
	str	q2, [sp, #1136]                 ; 16-byte Spill
	str	q28, [sp, #1152]                ; 16-byte Spill
	ldr	q3, [x10, #26640]
	ldr	q4, [x10, #26624]
	ldr	q2, [sp, #3840]                 ; 16-byte Reload
	fmul.4s	v4, v2, v4
	ldr	q2, [sp, #3856]                 ; 16-byte Reload
	fmul.4s	v3, v2, v3
	ldr	q5, [x10, #26672]
	ldr	q6, [x10, #26656]
	ldr	q2, [sp, #3808]                 ; 16-byte Reload
	fmul.4s	v6, v2, v6
	ldr	q2, [sp, #3824]                 ; 16-byte Reload
	fmul.4s	v5, v2, v5
	ldr	q7, [x10, #26704]
	ldr	q16, [x10, #26688]
	ldr	q2, [sp, #3776]                 ; 16-byte Reload
	fmul.4s	v16, v2, v16
	ldr	q2, [sp, #3792]                 ; 16-byte Reload
	fmul.4s	v7, v2, v7
	ldr	q18, [x10, #26736]
	ldr	q20, [x10, #26720]
	ldr	q2, [sp, #3744]                 ; 16-byte Reload
	fmul.4s	v20, v2, v20
	ldr	q2, [sp, #3760]                 ; 16-byte Reload
	fmul.4s	v18, v2, v18
	ldr	q23, [sp, #2672]                ; 16-byte Reload
	bit.16b	v23, v3, v0
	ldr	q15, [sp, #2688]                ; 16-byte Reload
	bit.16b	v15, v4, v1
	bit.16b	v26, v5, v0
	bit.16b	v14, v6, v1
	ldr	q13, [sp, #2736]                ; 16-byte Reload
	bit.16b	v13, v7, v0
	ldr	q28, [sp, #2752]                ; 16-byte Reload
	bit.16b	v28, v16, v1
	ldr	q9, [sp, #1168]                 ; 16-byte Reload
	bit.16b	v9, v18, v0
	ldr	q24, [sp, #1184]                ; 16-byte Reload
	bit.16b	v24, v20, v1
	mov	x2, x10
	mov	w3, #839                        ; =0x347
	ldr	q21, [sp, #1488]                ; 16-byte Reload
	ldr	q2, [sp, #1456]                 ; 16-byte Reload
	ldr	q8, [sp, #2928]                 ; 16-byte Reload
	ldr	q31, [sp, #2912]                ; 16-byte Reload
LBB0_75:                                ; %direct.true1167
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x2, #128]!
	ldr	q4, [x2, #26624]
	ldr	q5, [x2, #26640]
	ldp	q6, q7, [x2, #16]
	fmul.4s	v5, v6, v5
	fmul.4s	v3, v3, v4
	fadd.4s	v3, v15, v3
	fadd.4s	v5, v23, v5
	ldr	q4, [x2, #26656]
	ldr	q6, [x2, #26672]
	ldp	q16, q18, [x2, #48]
	fmul.4s	v6, v16, v6
	fmul.4s	v4, v7, v4
	fadd.4s	v7, v14, v4
	fadd.4s	v6, v26, v6
	ldr	q4, [x2, #26688]
	ldr	q16, [x2, #26704]
	ldp	q20, q22, [x2, #80]
	fmul.4s	v16, v20, v16
	fmul.4s	v4, v18, v4
	fadd.4s	v18, v28, v4
	fadd.4s	v16, v13, v16
	ldr	q4, [x2, #112]
	ldr	q20, [x2, #26720]
	ldr	q27, [x2, #26736]
	fmul.4s	v4, v4, v27
	fmul.4s	v20, v22, v20
	fadd.4s	v20, v24, v20
	fadd.4s	v4, v9, v4
	bit.16b	v23, v5, v0
	bit.16b	v15, v3, v1
	bit.16b	v26, v6, v0
	bit.16b	v14, v7, v1
	bit.16b	v13, v16, v0
	bit.16b	v28, v18, v1
	bit.16b	v9, v4, v0
	bit.16b	v24, v20, v1
	sub	x4, x3, #835
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_75
; %bb.76:                               ; %direct.false1168
                                        ;   in Loop: Header=BB0_22 Depth=1
	stp	q4, q20, [sp, #608]             ; 32-byte Folded Spill
	str	q23, [sp, #2672]                ; 16-byte Spill
	str	q15, [sp, #2688]                ; 16-byte Spill
	str	q26, [sp, #2704]                ; 16-byte Spill
	str	q14, [sp, #2720]                ; 16-byte Spill
	str	q13, [sp, #2736]                ; 16-byte Spill
	str	q28, [sp, #2752]                ; 16-byte Spill
	str	q9, [sp, #1168]                 ; 16-byte Spill
	str	q24, [sp, #1184]                ; 16-byte Spill
	ldr	q3, [x10, #29200]
	ldr	q5, [x10, #29184]
	ldr	q4, [sp, #3840]                 ; 16-byte Reload
	fmul.4s	v5, v4, v5
	ldr	q4, [sp, #3856]                 ; 16-byte Reload
	fmul.4s	v3, v4, v3
	ldr	q6, [x10, #29232]
	ldr	q7, [x10, #29216]
	ldr	q4, [sp, #3808]                 ; 16-byte Reload
	fmul.4s	v7, v4, v7
	ldr	q4, [sp, #3824]                 ; 16-byte Reload
	fmul.4s	v6, v4, v6
	ldr	q16, [x10, #29264]
	ldr	q18, [x10, #29248]
	ldr	q4, [sp, #3776]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	ldr	q4, [sp, #3792]                 ; 16-byte Reload
	fmul.4s	v16, v4, v16
	ldr	q20, [x10, #29296]
	ldr	q22, [x10, #29280]
	ldr	q4, [sp, #3744]                 ; 16-byte Reload
	fmul.4s	v22, v4, v22
	ldr	q4, [sp, #3760]                 ; 16-byte Reload
	fmul.4s	v20, v4, v20
	ldr	q24, [sp, #2784]                ; 16-byte Reload
	bit.16b	v24, v3, v0
	ldr	q23, [sp, #2800]                ; 16-byte Reload
	bit.16b	v23, v5, v1
	ldr	q26, [sp, #2816]                ; 16-byte Reload
	bit.16b	v26, v6, v0
	bit.16b	v29, v7, v1
	ldr	q14, [sp, #2848]                ; 16-byte Reload
	bit.16b	v14, v16, v0
	ldr	q13, [sp, #2864]                ; 16-byte Reload
	bit.16b	v13, v18, v1
	ldr	q4, [sp, #1216]                 ; 16-byte Reload
	bit.16b	v4, v20, v0
	bit.16b	v25, v22, v1
	mov	x2, x10
	mov	w3, #919                        ; =0x397
	ldr	q30, [sp, #3024]                ; 16-byte Reload
	ldr	q10, [sp, #3056]                ; 16-byte Reload
LBB0_77:                                ; %direct.true1287
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x2, #128]!
	ldr	q5, [x2, #29184]
	ldr	q6, [x2, #29200]
	ldp	q7, q16, [x2, #16]
	fmul.4s	v6, v7, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v3, v23, v3
	fadd.4s	v6, v24, v6
	ldr	q5, [x2, #29216]
	ldr	q7, [x2, #29232]
	ldp	q18, q20, [x2, #48]
	fmul.4s	v7, v18, v7
	fmul.4s	v5, v16, v5
	fadd.4s	v16, v29, v5
	fadd.4s	v7, v26, v7
	ldr	q5, [x2, #29248]
	ldr	q18, [x2, #29264]
	ldp	q22, q27, [x2, #80]
	fmul.4s	v18, v22, v18
	fmul.4s	v5, v20, v5
	fadd.4s	v20, v13, v5
	fadd.4s	v18, v14, v18
	ldr	q5, [x2, #112]
	ldr	q22, [x2, #29280]
	mov.16b	v9, v24
	ldr	q28, [x2, #29296]
	fmul.4s	v28, v5, v28
	fmul.4s	v5, v27, v22
	fadd.4s	v5, v25, v5
	fadd.4s	v22, v4, v28
	mov.16b	v24, v0
	bsl.16b	v24, v6, v9
	bit.16b	v23, v3, v1
	bit.16b	v26, v7, v0
	bit.16b	v29, v16, v1
	bit.16b	v14, v18, v0
	bit.16b	v13, v20, v1
	bit.16b	v4, v22, v0
	bit.16b	v25, v5, v1
	sub	x4, x3, #915
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_77
; %bb.78:                               ; %direct.false1288
                                        ;   in Loop: Header=BB0_22 Depth=1
	stp	q22, q5, [sp, #576]             ; 32-byte Folded Spill
	str	q23, [sp, #2800]                ; 16-byte Spill
	str	q26, [sp, #2816]                ; 16-byte Spill
	str	q29, [sp, #2832]                ; 16-byte Spill
	str	q14, [sp, #2848]                ; 16-byte Spill
	str	q13, [sp, #2864]                ; 16-byte Spill
	str	q4, [sp, #1216]                 ; 16-byte Spill
	str	q25, [sp, #1232]                ; 16-byte Spill
	ldr	q3, [x10, #31760]
	ldr	q6, [x10, #31744]
	ldr	q4, [sp, #3840]                 ; 16-byte Reload
	fmul.4s	v6, v4, v6
	ldr	q4, [sp, #3856]                 ; 16-byte Reload
	fmul.4s	v3, v4, v3
	ldr	q7, [x10, #31792]
	ldr	q16, [x10, #31776]
	ldr	q4, [sp, #3808]                 ; 16-byte Reload
	fmul.4s	v16, v4, v16
	ldr	q4, [sp, #3824]                 ; 16-byte Reload
	fmul.4s	v7, v4, v7
	ldr	q18, [x10, #31824]
	ldr	q20, [x10, #31808]
	ldr	q4, [sp, #3776]                 ; 16-byte Reload
	fmul.4s	v20, v4, v20
	ldr	q4, [sp, #3792]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	ldr	q22, [x10, #31856]
	ldr	q27, [x10, #31840]
	ldr	q4, [sp, #3744]                 ; 16-byte Reload
	fmul.4s	v27, v4, v27
	ldr	q4, [sp, #3760]                 ; 16-byte Reload
	fmul.4s	v22, v4, v22
	ldr	q29, [sp, #2896]                ; 16-byte Reload
	bit.16b	v29, v3, v0
	bit.16b	v31, v6, v1
	bit.16b	v8, v7, v0
	ldr	q26, [sp, #2944]                ; 16-byte Reload
	bit.16b	v26, v16, v1
	ldr	q13, [sp, #2960]                ; 16-byte Reload
	bit.16b	v13, v18, v0
	ldr	q14, [sp, #2976]                ; 16-byte Reload
	bit.16b	v14, v20, v1
	ldr	q5, [sp, #1264]                 ; 16-byte Reload
	bit.16b	v5, v22, v0
	ldr	q9, [sp, #1280]                 ; 16-byte Reload
	bit.16b	v9, v27, v1
	mov	x2, x10
	mov	w3, #999                        ; =0x3e7
	ldr	q4, [sp, #3376]                 ; 16-byte Reload
	ldr	q23, [sp, #3072]                ; 16-byte Reload
LBB0_79:                                ; %direct.true1407
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x2, #128]!
	ldr	q6, [x2, #31744]
	ldr	q7, [x2, #31760]
	ldp	q16, q18, [x2, #16]
	fmul.4s	v7, v16, v7
	fmul.4s	v3, v3, v6
	fadd.4s	v3, v31, v3
	fadd.4s	v6, v29, v7
	ldr	q7, [x2, #31776]
	ldr	q16, [x2, #31792]
	ldp	q20, q22, [x2, #48]
	fmul.4s	v16, v20, v16
	fmul.4s	v7, v18, v7
	fadd.4s	v7, v26, v7
	fadd.4s	v16, v8, v16
	ldr	q18, [x2, #31808]
	ldr	q20, [x2, #31824]
	ldp	q27, q28, [x2, #80]
	fmul.4s	v20, v27, v20
	fmul.4s	v18, v22, v18
	fadd.4s	v22, v14, v18
	fadd.4s	v20, v13, v20
	ldr	q18, [x2, #112]
	ldr	q27, [x2, #31840]
	mov.16b	v25, v13
	ldr	q13, [x2, #31856]
	fmul.4s	v18, v18, v13
	mov.16b	v13, v25
	fmul.4s	v27, v28, v27
	fadd.4s	v25, v9, v27
	fadd.4s	v18, v5, v18
	bit.16b	v29, v6, v0
	bit.16b	v31, v3, v1
	bit.16b	v8, v16, v0
	bit.16b	v26, v7, v1
	bit.16b	v13, v20, v0
	bit.16b	v14, v22, v1
	bit.16b	v5, v18, v0
	bit.16b	v9, v25, v1
	sub	x4, x3, #995
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_79
; %bb.80:                               ; %direct.false1408
                                        ;   in Loop: Header=BB0_22 Depth=1
	stp	q18, q25, [sp, #544]            ; 32-byte Folded Spill
	str	q24, [sp, #2784]                ; 16-byte Spill
	str	q8, [sp, #2928]                 ; 16-byte Spill
	str	q26, [sp, #2944]                ; 16-byte Spill
	str	q13, [sp, #2960]                ; 16-byte Spill
	str	q14, [sp, #2976]                ; 16-byte Spill
	str	q5, [sp, #1264]                 ; 16-byte Spill
	str	q9, [sp, #1280]                 ; 16-byte Spill
	ldr	q3, [x10, #34320]
	ldr	q6, [x10, #34304]
	ldr	q5, [sp, #3840]                 ; 16-byte Reload
	fmul.4s	v6, v5, v6
	ldr	q5, [sp, #3856]                 ; 16-byte Reload
	fmul.4s	v3, v5, v3
	ldr	q7, [x10, #34352]
	ldr	q16, [x10, #34336]
	ldr	q5, [sp, #3808]                 ; 16-byte Reload
	fmul.4s	v16, v5, v16
	ldr	q5, [sp, #3824]                 ; 16-byte Reload
	fmul.4s	v7, v5, v7
	ldr	q20, [x10, #34384]
	ldr	q22, [x10, #34368]
	ldr	q5, [sp, #3776]                 ; 16-byte Reload
	fmul.4s	v22, v5, v22
	ldr	q5, [sp, #3792]                 ; 16-byte Reload
	fmul.4s	v20, v5, v20
	ldr	q28, [x10, #34416]
	ldr	q13, [x10, #34400]
	ldr	q5, [sp, #3744]                 ; 16-byte Reload
	fmul.4s	v13, v5, v13
	ldr	q5, [sp, #3760]                 ; 16-byte Reload
	fmul.4s	v28, v5, v28
	ldr	q25, [sp, #3008]                ; 16-byte Reload
	bit.16b	v25, v3, v0
	bit.16b	v30, v6, v1
	ldr	q26, [sp, #3040]                ; 16-byte Reload
	bit.16b	v26, v7, v0
	bit.16b	v10, v16, v1
	bit.16b	v23, v20, v0
	ldr	q27, [sp, #3088]                ; 16-byte Reload
	bit.16b	v27, v22, v1
	bit.16b	v19, v28, v0
	ldr	q24, [sp, #1328]                ; 16-byte Reload
	bit.16b	v24, v13, v1
	mov	x2, x10
	mov	w3, #1079                       ; =0x437
	ldr	q5, [sp, #3408]                 ; 16-byte Reload
	ldr	q9, [sp, #3136]                 ; 16-byte Reload
LBB0_81:                                ; %direct.true1527
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x2, #128]!
	ldr	q6, [x2, #34304]
	ldr	q7, [x2, #34320]
	ldp	q16, q20, [x2, #16]
	fmul.4s	v7, v16, v7
	fmul.4s	v3, v3, v6
	fadd.4s	v3, v30, v3
	fadd.4s	v6, v25, v7
	ldr	q7, [x2, #34336]
	ldr	q16, [x2, #34352]
	ldp	q22, q28, [x2, #48]
	fmul.4s	v16, v22, v16
	fmul.4s	v7, v20, v7
	fadd.4s	v7, v10, v7
	fadd.4s	v16, v26, v16
	ldr	q20, [x2, #34368]
	ldr	q22, [x2, #34384]
	ldp	q13, q14, [x2, #80]
	fmul.4s	v22, v13, v22
	fmul.4s	v20, v28, v20
	fadd.4s	v20, v27, v20
	fadd.4s	v13, v23, v22
	ldr	q22, [x2, #112]
	ldr	q28, [x2, #34400]
	ldr	q15, [x2, #34416]
	fmul.4s	v15, v22, v15
	fmul.4s	v22, v14, v28
	fadd.4s	v18, v24, v22
	fadd.4s	v22, v19, v15
	bit.16b	v25, v6, v0
	bit.16b	v30, v3, v1
	bit.16b	v26, v16, v0
	bit.16b	v10, v7, v1
	bit.16b	v23, v13, v0
	bit.16b	v27, v20, v1
	bit.16b	v19, v22, v0
	bit.16b	v24, v18, v1
	sub	x4, x3, #1075
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_81
; %bb.82:                               ; %direct.false1528
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q22, [sp, #528]                 ; 16-byte Spill
	str	q29, [sp, #2896]                ; 16-byte Spill
	str	q31, [sp, #2912]                ; 16-byte Spill
	str	q25, [sp, #3008]                ; 16-byte Spill
	str	q30, [sp, #3024]                ; 16-byte Spill
	str	q26, [sp, #3040]                ; 16-byte Spill
	str	q10, [sp, #3056]                ; 16-byte Spill
	str	q23, [sp, #3072]                ; 16-byte Spill
	str	q27, [sp, #3088]                ; 16-byte Spill
	str	q19, [sp, #1312]                ; 16-byte Spill
	str	q24, [sp, #1328]                ; 16-byte Spill
	ldr	q3, [x10, #36880]
	ldr	q6, [x10, #36864]
	ldr	q7, [sp, #3840]                 ; 16-byte Reload
	fmul.4s	v6, v7, v6
	ldr	q7, [sp, #3856]                 ; 16-byte Reload
	fmul.4s	v3, v7, v3
	ldr	q7, [x10, #36912]
	ldr	q16, [x10, #36896]
	ldr	q19, [sp, #3808]                ; 16-byte Reload
	fmul.4s	v16, v19, v16
	ldr	q19, [sp, #3824]                ; 16-byte Reload
	fmul.4s	v7, v19, v7
	ldr	q20, [x10, #36944]
	ldr	q13, [x10, #36928]
	ldr	q19, [sp, #3776]                ; 16-byte Reload
	fmul.4s	v13, v19, v13
	ldr	q19, [sp, #3792]                ; 16-byte Reload
	fmul.4s	v20, v19, v20
	ldr	q14, [x10, #36976]
	ldr	q15, [x10, #36960]
	ldr	q19, [sp, #3744]                ; 16-byte Reload
	fmul.4s	v15, v19, v15
	ldr	q19, [sp, #3760]                ; 16-byte Reload
	fmul.4s	v14, v19, v14
	ldr	q10, [sp, #3120]                ; 16-byte Reload
	bit.16b	v10, v3, v0
	bit.16b	v9, v6, v1
	ldr	q24, [sp, #3152]                ; 16-byte Reload
	bit.16b	v24, v7, v0
	ldr	q26, [sp, #3168]                ; 16-byte Reload
	bit.16b	v26, v16, v1
	ldr	q28, [sp, #3184]                ; 16-byte Reload
	bit.16b	v28, v20, v0
	ldr	q23, [sp, #3200]                ; 16-byte Reload
	bit.16b	v23, v13, v1
	ldr	q22, [sp, #1360]                ; 16-byte Reload
	bit.16b	v22, v14, v0
	ldr	q25, [sp, #1376]                ; 16-byte Reload
	bit.16b	v25, v15, v1
	mov	x2, x10
	mov	w3, #1159                       ; =0x487
	ldr	q27, [sp, #3568]                ; 16-byte Reload
	ldr	q8, [sp, #3280]                 ; 16-byte Reload
	ldr	q31, [sp, #3264]                ; 16-byte Reload
LBB0_83:                                ; %direct.true1647
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x2, #128]!
	ldr	q6, [x2, #36864]
	ldr	q7, [x2, #36880]
	ldp	q16, q20, [x2, #16]
	fmul.4s	v7, v16, v7
	fmul.4s	v3, v3, v6
	fadd.4s	v3, v9, v3
	fadd.4s	v7, v10, v7
	ldr	q6, [x2, #36896]
	ldr	q16, [x2, #36912]
	ldp	q13, q14, [x2, #48]
	fmul.4s	v16, v13, v16
	fmul.4s	v6, v20, v6
	fadd.4s	v20, v26, v6
	fadd.4s	v16, v24, v16
	ldr	q6, [x2, #36928]
	ldr	q13, [x2, #36944]
	ldp	q15, q19, [x2, #80]
	fmul.4s	v13, v15, v13
	fmul.4s	v6, v14, v6
	fadd.4s	v15, v23, v6
	fadd.4s	v13, v28, v13
	ldr	q6, [x2, #112]
	ldr	q14, [x2, #36960]
	ldr	q29, [x2, #36976]
	fmul.4s	v29, v6, v29
	fmul.4s	v6, v19, v14
	fadd.4s	v6, v25, v6
	fadd.4s	v14, v22, v29
	bit.16b	v10, v7, v0
	bit.16b	v9, v3, v1
	bit.16b	v24, v16, v0
	bit.16b	v26, v20, v1
	bit.16b	v28, v13, v0
	bit.16b	v23, v15, v1
	bit.16b	v22, v14, v0
	bit.16b	v25, v6, v1
	sub	x4, x3, #1155
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_83
; %bb.84:                               ; %direct.false1648
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q10, [sp, #3120]                ; 16-byte Spill
	str	q9, [sp, #3136]                 ; 16-byte Spill
	str	q24, [sp, #3152]                ; 16-byte Spill
	str	q26, [sp, #3168]                ; 16-byte Spill
	str	q28, [sp, #3184]                ; 16-byte Spill
	str	q23, [sp, #3200]                ; 16-byte Spill
	str	q22, [sp, #1360]                ; 16-byte Spill
	str	q25, [sp, #1376]                ; 16-byte Spill
	ldr	q3, [x10, #39440]
	ldr	q7, [x10, #39424]
	ldr	q16, [sp, #3840]                ; 16-byte Reload
	fmul.4s	v7, v16, v7
	ldr	q16, [sp, #3856]                ; 16-byte Reload
	fmul.4s	v3, v16, v3
	ldr	q16, [x10, #39472]
	ldr	q19, [x10, #39456]
	ldr	q20, [sp, #3808]                ; 16-byte Reload
	fmul.4s	v19, v20, v19
	ldr	q20, [sp, #3824]                ; 16-byte Reload
	fmul.4s	v16, v20, v16
	ldr	q20, [x10, #39504]
	ldr	q29, [x10, #39488]
	ldr	q22, [sp, #3776]                ; 16-byte Reload
	fmul.4s	v29, v22, v29
	ldr	q22, [sp, #3792]                ; 16-byte Reload
	fmul.4s	v20, v22, v20
	ldr	q13, [x10, #39536]
	ldr	q15, [x10, #39520]
	ldr	q22, [sp, #3744]                ; 16-byte Reload
	fmul.4s	v15, v22, v15
	ldr	q22, [sp, #3760]                ; 16-byte Reload
	fmul.4s	v13, v22, v13
	ldr	q9, [sp, #3248]                 ; 16-byte Reload
	bit.16b	v9, v3, v0
	bit.16b	v31, v7, v1
	bit.16b	v8, v16, v0
	ldr	q25, [sp, #3296]                ; 16-byte Reload
	bit.16b	v25, v19, v1
	ldr	q28, [sp, #3312]                ; 16-byte Reload
	bit.16b	v28, v20, v0
	ldr	q26, [sp, #3328]                ; 16-byte Reload
	bit.16b	v26, v29, v1
	ldr	q24, [sp, #1392]                ; 16-byte Reload
	bit.16b	v24, v13, v0
	ldr	q10, [sp, #1408]                ; 16-byte Reload
	bit.16b	v10, v15, v1
	mov	x2, x10
	mov	w3, #1239                       ; =0x4d7
	ldr	q22, [sp, #1472]                ; 16-byte Reload
LBB0_85:                                ; %direct.true1767
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x2, #128]!
	ldr	q7, [x2, #39424]
	ldr	q16, [x2, #39440]
	ldp	q19, q20, [x2, #16]
	fmul.4s	v16, v19, v16
	fmul.4s	v3, v3, v7
	fadd.4s	v7, v31, v3
	fadd.4s	v16, v9, v16
	ldr	q3, [x2, #39456]
	ldr	q19, [x2, #39472]
	ldp	q29, q13, [x2, #48]
	fmul.4s	v19, v29, v19
	fmul.4s	v3, v20, v3
	fadd.4s	v20, v25, v3
	fadd.4s	v19, v8, v19
	ldr	q3, [x2, #39488]
	ldr	q29, [x2, #39504]
	ldp	q15, q23, [x2, #80]
	fmul.4s	v29, v15, v29
	fmul.4s	v3, v13, v3
	fadd.4s	v15, v26, v3
	fadd.4s	v29, v28, v29
	ldr	q3, [x2, #112]
	ldr	q13, [x2, #39520]
	ldr	q30, [x2, #39536]
	fmul.4s	v3, v3, v30
	fmul.4s	v23, v23, v13
	fadd.4s	v13, v10, v23
	fadd.4s	v3, v24, v3
	bit.16b	v9, v16, v0
	bit.16b	v31, v7, v1
	bit.16b	v8, v19, v0
	bit.16b	v25, v20, v1
	bit.16b	v28, v29, v0
	bit.16b	v26, v15, v1
	bit.16b	v24, v3, v0
	bit.16b	v10, v13, v1
	sub	x4, x3, #1235
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_85
; %bb.86:                               ; %direct.false1768
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q9, [sp, #3248]                 ; 16-byte Spill
	str	q31, [sp, #3264]                ; 16-byte Spill
	str	q8, [sp, #3280]                 ; 16-byte Spill
	str	q25, [sp, #3296]                ; 16-byte Spill
	str	q28, [sp, #3312]                ; 16-byte Spill
	str	q26, [sp, #3328]                ; 16-byte Spill
	str	q24, [sp, #1392]                ; 16-byte Spill
	str	q10, [sp, #1408]                ; 16-byte Spill
	ldr	q7, [x10, #42000]
	ldr	q16, [x10, #41984]
	ldr	q19, [sp, #3840]                ; 16-byte Reload
	fmul.4s	v16, v19, v16
	ldr	q19, [sp, #3856]                ; 16-byte Reload
	fmul.4s	v7, v19, v7
	ldr	q19, [x10, #42032]
	ldr	q20, [x10, #42016]
	ldr	q23, [sp, #3808]                ; 16-byte Reload
	fmul.4s	v20, v23, v20
	ldr	q23, [sp, #3824]                ; 16-byte Reload
	fmul.4s	v19, v23, v19
	ldr	q23, [x10, #42064]
	ldr	q29, [x10, #42048]
	ldr	q24, [sp, #3776]                ; 16-byte Reload
	fmul.4s	v29, v24, v29
	ldr	q24, [sp, #3792]                ; 16-byte Reload
	fmul.4s	v23, v24, v23
	ldr	q30, [x10, #42096]
	ldr	q15, [x10, #42080]
	ldr	q24, [sp, #3744]                ; 16-byte Reload
	fmul.4s	v15, v24, v15
	ldr	q24, [sp, #3760]                ; 16-byte Reload
	fmul.4s	v30, v24, v30
	ldr	q8, [sp, #3360]                 ; 16-byte Reload
	bit.16b	v8, v7, v0
	bit.16b	v4, v16, v1
	ldr	q24, [sp, #3392]                ; 16-byte Reload
	bit.16b	v24, v19, v0
	bit.16b	v5, v20, v1
	ldr	q26, [sp, #3424]                ; 16-byte Reload
	bit.16b	v26, v23, v0
	ldr	q25, [sp, #3440]                ; 16-byte Reload
	bit.16b	v25, v29, v1
	bit.16b	v17, v30, v0
	bit.16b	v2, v15, v1
	mov	x2, x10
	mov	w3, #1319                       ; =0x527
LBB0_87:                                ; %direct.true1887
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q7, [x2, #128]!
	ldr	q16, [x2, #41984]
	ldr	q19, [x2, #42000]
	ldp	q20, q23, [x2, #16]
	fmul.4s	v19, v20, v19
	fmul.4s	v7, v7, v16
	fadd.4s	v16, v4, v7
	fadd.4s	v19, v8, v19
	ldr	q7, [x2, #42016]
	ldr	q20, [x2, #42032]
	ldp	q29, q30, [x2, #48]
	fmul.4s	v20, v29, v20
	fmul.4s	v7, v23, v7
	fadd.4s	v23, v5, v7
	fadd.4s	v29, v24, v20
	ldr	q7, [x2, #42048]
	ldr	q20, [x2, #42064]
	mov.16b	v10, v4
	mov.16b	v4, v24
	ldp	q15, q24, [x2, #80]
	fmul.4s	v20, v15, v20
	fmul.4s	v7, v30, v7
	fadd.4s	v30, v25, v7
	fadd.4s	v15, v26, v20
	ldr	q7, [x2, #112]
	ldr	q20, [x2, #42080]
	mov.16b	v28, v5
	mov.16b	v5, v26
	ldr	q26, [x2, #42096]
	fmul.4s	v26, v7, v26
	fmul.4s	v7, v24, v20
	mov.16b	v24, v4
	fadd.4s	v7, v2, v7
	fadd.4s	v20, v17, v26
	mov.16b	v26, v5
	bit.16b	v8, v19, v0
	mov.16b	v4, v1
	bsl.16b	v4, v16, v10
	bit.16b	v24, v29, v0
	mov.16b	v5, v1
	bsl.16b	v5, v23, v28
	bit.16b	v26, v15, v0
	bit.16b	v25, v30, v1
	bit.16b	v17, v20, v0
	bit.16b	v2, v7, v1
	sub	x4, x3, #1315
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_87
; %bb.88:                               ; %direct.false1888
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q8, [sp, #3360]                 ; 16-byte Spill
	str	q24, [sp, #3392]                ; 16-byte Spill
	str	q5, [sp, #3408]                 ; 16-byte Spill
	str	q26, [sp, #3424]                ; 16-byte Spill
	str	q25, [sp, #3440]                ; 16-byte Spill
	str	q17, [sp, #1440]                ; 16-byte Spill
	str	q2, [sp, #1456]                 ; 16-byte Spill
	ldr	q16, [x10, #44560]
	ldr	q19, [x10, #44544]
	ldr	q2, [sp, #3840]                 ; 16-byte Reload
	fmul.4s	v19, v2, v19
	ldr	q2, [sp, #3856]                 ; 16-byte Reload
	fmul.4s	v16, v2, v16
	ldr	q23, [x10, #44592]
	ldr	q24, [x10, #44576]
	ldr	q2, [sp, #3808]                 ; 16-byte Reload
	fmul.4s	v24, v2, v24
	ldr	q2, [sp, #3824]                 ; 16-byte Reload
	fmul.4s	v23, v2, v23
	ldr	q26, [x10, #44624]
	ldr	q29, [x10, #44608]
	ldr	q2, [sp, #3776]                 ; 16-byte Reload
	fmul.4s	v29, v2, v29
	ldr	q2, [sp, #3792]                 ; 16-byte Reload
	fmul.4s	v26, v2, v26
	ldr	q30, [x10, #44656]
	ldr	q15, [x10, #44640]
	ldr	q2, [sp, #3744]                 ; 16-byte Reload
	fmul.4s	v15, v2, v15
	ldr	q2, [sp, #3760]                 ; 16-byte Reload
	fmul.4s	v30, v2, v30
	ldr	q2, [sp, #3488]                 ; 16-byte Reload
	bit.16b	v2, v16, v0
	ldr	q9, [sp, #3504]                 ; 16-byte Reload
	bit.16b	v9, v19, v1
	ldr	q31, [sp, #3520]                ; 16-byte Reload
	bit.16b	v31, v23, v0
	ldr	q8, [sp, #3536]                 ; 16-byte Reload
	bit.16b	v8, v24, v1
	ldr	q10, [sp, #3552]                ; 16-byte Reload
	bit.16b	v10, v26, v0
	bit.16b	v27, v29, v1
	bit.16b	v22, v30, v0
	bit.16b	v21, v15, v1
	mov	x2, x10
	mov	w3, #1399                       ; =0x577
LBB0_89:                                ; %direct.true2007
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q16, [x2, #128]!
	ldr	q19, [x2, #44544]
	ldr	q23, [x2, #44560]
	ldp	q24, q26, [x2, #16]
	fmul.4s	v23, v24, v23
	fmul.4s	v16, v16, v19
	fadd.4s	v19, v9, v16
	fadd.4s	v23, v2, v23
	ldr	q16, [x2, #44576]
	ldr	q24, [x2, #44592]
	ldp	q29, q30, [x2, #48]
	fmul.4s	v24, v29, v24
	fmul.4s	v16, v26, v16
	fadd.4s	v26, v8, v16
	fadd.4s	v24, v31, v24
	ldr	q16, [x2, #44608]
	ldr	q29, [x2, #44624]
	ldp	q15, q17, [x2, #80]
	fmul.4s	v29, v15, v29
	fmul.4s	v16, v30, v16
	fadd.4s	v30, v27, v16
	fadd.4s	v29, v10, v29
	ldr	q16, [x2, #112]
	ldr	q15, [x2, #44640]
	ldr	q25, [x2, #44656]
	fmul.4s	v25, v16, v25
	fmul.4s	v16, v17, v15
	fadd.4s	v16, v21, v16
	fadd.4s	v15, v22, v25
	bit.16b	v2, v23, v0
	bit.16b	v9, v19, v1
	bit.16b	v31, v24, v0
	bit.16b	v8, v26, v1
	bit.16b	v10, v29, v0
	bit.16b	v27, v30, v1
	bit.16b	v22, v15, v0
	bit.16b	v21, v16, v1
	sub	x4, x3, #1395
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_89
; %bb.90:                               ; %direct.false2008
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q4, [sp, #3376]                 ; 16-byte Spill
	str	q2, [sp, #3488]                 ; 16-byte Spill
	str	q9, [sp, #3504]                 ; 16-byte Spill
	str	q31, [sp, #3520]                ; 16-byte Spill
	str	q8, [sp, #3536]                 ; 16-byte Spill
	str	q10, [sp, #3552]                ; 16-byte Spill
	str	q27, [sp, #3568]                ; 16-byte Spill
	str	q22, [sp, #1472]                ; 16-byte Spill
	str	q21, [sp, #1488]                ; 16-byte Spill
	ldr	q17, [x10, #47120]
	ldr	q19, [x10, #47104]
	ldr	q2, [sp, #3840]                 ; 16-byte Reload
	fmul.4s	v19, v2, v19
	ldr	q2, [sp, #3856]                 ; 16-byte Reload
	fmul.4s	v17, v2, v17
	ldr	q23, [x10, #47152]
	ldr	q24, [x10, #47136]
	ldr	q2, [sp, #3808]                 ; 16-byte Reload
	fmul.4s	v24, v2, v24
	ldr	q2, [sp, #3824]                 ; 16-byte Reload
	fmul.4s	v23, v2, v23
	ldr	q25, [x10, #47184]
	ldr	q26, [x10, #47168]
	ldr	q2, [sp, #3776]                 ; 16-byte Reload
	fmul.4s	v26, v2, v26
	ldr	q2, [sp, #3792]                 ; 16-byte Reload
	fmul.4s	v25, v2, v25
	ldr	q29, [x10, #47216]
	ldr	q30, [x10, #47200]
	ldr	q2, [sp, #3744]                 ; 16-byte Reload
	fmul.4s	v30, v2, v30
	ldr	q2, [sp, #3760]                 ; 16-byte Reload
	fmul.4s	v29, v2, v29
	ldr	q28, [sp, #1504]                ; 16-byte Reload
	bit.16b	v28, v17, v0
	ldr	q5, [sp, #1520]                 ; 16-byte Reload
	bit.16b	v5, v19, v1
	ldr	q9, [sp, #3616]                 ; 16-byte Reload
	bit.16b	v9, v23, v0
	ldr	q27, [sp, #1536]                ; 16-byte Reload
	bit.16b	v27, v24, v1
	ldr	q31, [sp, #3632]                ; 16-byte Reload
	bit.16b	v31, v25, v0
	ldr	q8, [sp, #3648]                 ; 16-byte Reload
	bit.16b	v8, v26, v1
	ldr	q22, [sp, #3664]                ; 16-byte Reload
	bit.16b	v22, v29, v0
	ldr	q10, [sp, #3680]                ; 16-byte Reload
	bit.16b	v10, v30, v1
	mov	x2, x10
	mov	w3, #1479                       ; =0x5c7
LBB0_91:                                ; %direct.true2127
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q17, [x2, #128]!
	ldr	q19, [x2, #47104]
	ldr	q23, [x2, #47120]
	ldp	q24, q25, [x2, #16]
	fmul.4s	v23, v24, v23
	fmul.4s	v17, v17, v19
	fadd.4s	v17, v5, v17
	fadd.4s	v19, v28, v23
	ldr	q23, [x2, #47136]
	ldr	q24, [x2, #47152]
	ldp	q26, q29, [x2, #48]
	fmul.4s	v24, v26, v24
	fmul.4s	v23, v25, v23
	fadd.4s	v23, v27, v23
	fadd.4s	v24, v9, v24
	ldr	q25, [x2, #47168]
	ldr	q26, [x2, #47184]
	ldp	q30, q21, [x2, #80]
	fmul.4s	v26, v30, v26
	fmul.4s	v25, v29, v25
	fadd.4s	v25, v8, v25
	fadd.4s	v26, v31, v26
	ldr	q29, [x2, #112]
	ldr	q30, [x2, #47200]
	ldr	q2, [x2, #47216]
	fmul.4s	v2, v29, v2
	fmul.4s	v21, v21, v30
	fadd.4s	v21, v10, v21
	fadd.4s	v2, v22, v2
	bit.16b	v28, v19, v0
	bit.16b	v5, v17, v1
	bit.16b	v9, v24, v0
	bit.16b	v27, v23, v1
	bit.16b	v31, v26, v0
	bit.16b	v8, v25, v1
	bit.16b	v22, v2, v0
	bit.16b	v10, v21, v1
	sub	x4, x3, #1475
	add	x3, x3, #4
	cmp	x4, #76
	b.lo	LBB0_91
; %bb.92:                               ; %direct.false2128
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x2, #0                          ; =0x0
	movi.2d	v24, #0000000000000000
	ldr	q2, [sp, #1840]                 ; 16-byte Reload
	fadd.4s	v2, v2, v24
	ldr	q4, [sp, #1856]                 ; 16-byte Reload
	fadd.4s	v17, v4, v24
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #1872]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1904]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1920]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #1808]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2096]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #2096]                 ; 16-byte Spill
	ldr	q19, [sp, #928]                 ; 16-byte Reload
	bit.16b	v19, v17, v1
	ldr	q2, [sp, #1936]                 ; 16-byte Reload
	fadd.4s	v2, v2, v24
	ldr	q4, [sp, #1952]                 ; 16-byte Reload
	fadd.4s	v17, v4, v24
	ldr	q4, [sp, #1984]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #1968]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2112]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2128]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #1792]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #1776]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2144]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #2144]                 ; 16-byte Spill
	ldr	q29, [sp, #976]                 ; 16-byte Reload
	bit.16b	v29, v17, v1
	ldr	q2, [sp, #2000]                 ; 16-byte Reload
	fadd.4s	v2, v2, v24
	ldr	q4, [sp, #2016]                 ; 16-byte Reload
	fadd.4s	v17, v4, v24
	ldr	q4, [sp, #2048]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #2032]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2064]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2160]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #784]                  ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #768]                  ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2176]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #2176]                 ; 16-byte Spill
	ldr	q21, [sp, #1024]                ; 16-byte Reload
	bit.16b	v21, v17, v1
	ldr	q2, [sp, #2192]                 ; 16-byte Reload
	fadd.4s	v2, v2, v24
	ldr	q4, [sp, #2208]                 ; 16-byte Reload
	fadd.4s	v17, v4, v24
	ldr	q4, [sp, #2240]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #2224]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2256]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2272]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #752]                  ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #736]                  ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2288]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #2288]                 ; 16-byte Spill
	ldr	q2, [sp, #2304]                 ; 16-byte Reload
	bit.16b	v2, v17, v1
	str	q2, [sp, #2304]                 ; 16-byte Spill
	ldr	q2, [sp, #2320]                 ; 16-byte Reload
	fadd.4s	v2, v2, v24
	ldr	q4, [sp, #2336]                 ; 16-byte Reload
	fadd.4s	v17, v4, v24
	ldr	q4, [sp, #2368]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #2352]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2384]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #3728]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #720]                  ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #704]                  ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2400]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #2400]                 ; 16-byte Spill
	ldr	q2, [sp, #2416]                 ; 16-byte Reload
	bit.16b	v2, v17, v1
	str	q2, [sp, #2416]                 ; 16-byte Spill
	ldr	q2, [sp, #2448]                 ; 16-byte Reload
	fadd.4s	v2, v2, v24
	ldr	q4, [sp, #2432]                 ; 16-byte Reload
	fadd.4s	v17, v4, v24
	ldr	q4, [sp, #2080]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #2464]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2496]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2480]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #672]                  ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #688]                  ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2528]                 ; 16-byte Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #2528]                 ; 16-byte Spill
	ldr	q2, [sp, #2512]                 ; 16-byte Reload
	bit.16b	v2, v17, v0
	str	q2, [sp, #2512]                 ; 16-byte Spill
	ldr	q2, [sp, #2560]                 ; 16-byte Reload
	fadd.4s	v2, v2, v24
	ldr	q4, [sp, #2544]                 ; 16-byte Reload
	fadd.4s	v17, v4, v24
	ldr	q4, [sp, #2576]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #2592]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2624]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2608]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #640]                  ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #656]                  ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2656]                 ; 16-byte Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #2656]                 ; 16-byte Spill
	ldr	q2, [sp, #2640]                 ; 16-byte Reload
	bit.16b	v2, v17, v0
	str	q2, [sp, #2640]                 ; 16-byte Spill
	ldr	q2, [sp, #2688]                 ; 16-byte Reload
	fadd.4s	v2, v2, v24
	ldr	q4, [sp, #2672]                 ; 16-byte Reload
	fadd.4s	v17, v4, v24
	ldr	q4, [sp, #2704]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #2720]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2752]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2736]                 ; 16-byte Reload
	fadd.4s	v17, v17, v4
	ldr	q4, [sp, #608]                  ; 16-byte Reload
	fadd.4s	v4, v17, v4
	ldr	q17, [sp, #624]                 ; 16-byte Reload
	fadd.4s	v2, v2, v17
	ldr	q17, [sp, #2768]                ; 16-byte Reload
	bit.16b	v17, v2, v1
	str	q17, [sp, #2768]                ; 16-byte Spill
	ldr	q23, [sp, #1200]                ; 16-byte Reload
	bit.16b	v23, v4, v0
	ldr	q2, [sp, #2800]                 ; 16-byte Reload
	fadd.4s	v2, v2, v24
	ldr	q4, [sp, #2784]                 ; 16-byte Reload
	fadd.4s	v4, v4, v24
	ldr	q17, [sp, #2816]                ; 16-byte Reload
	fadd.4s	v4, v4, v17
	ldr	q17, [sp, #2832]                ; 16-byte Reload
	fadd.4s	v2, v2, v17
	ldr	q17, [sp, #2864]                ; 16-byte Reload
	fadd.4s	v2, v2, v17
	ldr	q17, [sp, #2848]                ; 16-byte Reload
	fadd.4s	v4, v4, v17
	ldp	q25, q17, [sp, #576]            ; 32-byte Folded Reload
	fadd.4s	v4, v4, v25
	fadd.4s	v2, v2, v17
	ldr	q17, [sp, #2880]                ; 16-byte Reload
	bit.16b	v17, v2, v1
	str	q17, [sp, #2880]                ; 16-byte Spill
	ldr	q25, [sp, #1248]                ; 16-byte Reload
	bit.16b	v25, v4, v0
	ldr	q2, [sp, #2896]                 ; 16-byte Reload
	fadd.4s	v2, v2, v24
	ldr	q4, [sp, #2912]                 ; 16-byte Reload
	fadd.4s	v4, v4, v24
	ldr	q17, [sp, #2944]                ; 16-byte Reload
	fadd.4s	v4, v4, v17
	ldr	q17, [sp, #2928]                ; 16-byte Reload
	fadd.4s	v2, v2, v17
	ldr	q17, [sp, #2960]                ; 16-byte Reload
	fadd.4s	v2, v2, v17
	ldr	q17, [sp, #2976]                ; 16-byte Reload
	fadd.4s	v4, v4, v17
	ldp	q17, q26, [sp, #544]            ; 32-byte Folded Reload
	fadd.4s	v4, v4, v26
	fadd.4s	v2, v2, v17
	ldr	q17, [sp, #2992]                ; 16-byte Reload
	bit.16b	v17, v2, v0
	str	q17, [sp, #2992]                ; 16-byte Spill
	ldr	q30, [sp, #1296]                ; 16-byte Reload
	bit.16b	v30, v4, v1
	ldr	q2, [sp, #3008]                 ; 16-byte Reload
	fadd.4s	v2, v2, v24
	ldr	q4, [sp, #3024]                 ; 16-byte Reload
	fadd.4s	v4, v4, v24
	ldr	q17, [sp, #3056]                ; 16-byte Reload
	fadd.4s	v4, v4, v17
	ldr	q17, [sp, #3040]                ; 16-byte Reload
	fadd.4s	v2, v2, v17
	ldr	q17, [sp, #3072]                ; 16-byte Reload
	fadd.4s	v2, v2, v17
	ldr	q17, [sp, #3088]                ; 16-byte Reload
	fadd.4s	v4, v4, v17
	fadd.4s	v4, v4, v18
	ldr	q17, [sp, #528]                 ; 16-byte Reload
	fadd.4s	v2, v2, v17
	ldr	q17, [sp, #3104]                ; 16-byte Reload
	bit.16b	v17, v2, v0
	str	q17, [sp, #3104]                ; 16-byte Spill
	ldr	q26, [sp, #1344]                ; 16-byte Reload
	bit.16b	v26, v4, v1
	ldr	q2, [sp, #3120]                 ; 16-byte Reload
	fadd.4s	v2, v2, v24
	ldr	q4, [sp, #3136]                 ; 16-byte Reload
	fadd.4s	v4, v4, v24
	ldr	q17, [sp, #3168]                ; 16-byte Reload
	fadd.4s	v4, v4, v17
	ldr	q17, [sp, #3152]                ; 16-byte Reload
	fadd.4s	v2, v2, v17
	ldr	q17, [sp, #3184]                ; 16-byte Reload
	fadd.4s	v2, v2, v17
	ldr	q17, [sp, #3200]                ; 16-byte Reload
	fadd.4s	v4, v4, v17
	fadd.4s	v4, v4, v6
	fadd.4s	v2, v2, v14
	ldr	q6, [sp, #3216]                 ; 16-byte Reload
	bit.16b	v6, v2, v0
	str	q6, [sp, #3216]                 ; 16-byte Spill
	ldr	q2, [sp, #3232]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3232]                 ; 16-byte Spill
	ldr	q2, [sp, #3248]                 ; 16-byte Reload
	fadd.4s	v2, v2, v24
	ldr	q4, [sp, #3264]                 ; 16-byte Reload
	fadd.4s	v4, v4, v24
	ldr	q6, [sp, #3296]                 ; 16-byte Reload
	fadd.4s	v4, v4, v6
	ldr	q6, [sp, #3280]                 ; 16-byte Reload
	fadd.4s	v2, v2, v6
	ldr	q6, [sp, #3312]                 ; 16-byte Reload
	fadd.4s	v2, v2, v6
	ldr	q6, [sp, #3328]                 ; 16-byte Reload
	fadd.4s	v4, v4, v6
	fadd.4s	v4, v4, v13
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3344]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #3344]                 ; 16-byte Spill
	ldr	q13, [sp, #1424]                ; 16-byte Reload
	bit.16b	v13, v4, v1
	ldr	q2, [sp, #3376]                 ; 16-byte Reload
	fadd.4s	v2, v2, v24
	ldr	q3, [sp, #3360]                 ; 16-byte Reload
	fadd.4s	v3, v3, v24
	ldr	q4, [sp, #3392]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #3408]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #3440]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #3424]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v7
	ldr	q4, [sp, #3472]                 ; 16-byte Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #3472]                 ; 16-byte Spill
	ldr	q2, [sp, #3456]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #3456]                 ; 16-byte Spill
	ldr	q2, [sp, #3488]                 ; 16-byte Reload
	fadd.4s	v2, v2, v24
	ldr	q3, [sp, #3504]                 ; 16-byte Reload
	fadd.4s	v3, v3, v24
	ldr	q4, [sp, #3536]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #3520]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #3552]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #3568]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	fadd.4s	v3, v3, v16
	fadd.4s	v2, v2, v15
	ldr	q4, [sp, #3584]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #3584]                 ; 16-byte Spill
	ldr	q2, [sp, #3600]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #3600]                 ; 16-byte Spill
	mov	w3, #63790                      ; =0xf92e
	movk	w3, #15844, lsl #16
	dup.4s	v14, w3
	str	q19, [sp, #928]                 ; 16-byte Spill
	fmul.4s	v7, v19, v14
	cmp	x0, #128
	cset	w3, lo
	ldr	q2, [sp, #2096]                 ; 16-byte Reload
	fmul.4s	v3, v2, v14
	dup.4h	v2, w3
	str	d2, [sp, #3856]                 ; 8-byte Spill
	str	q29, [sp, #976]                 ; 16-byte Spill
	fmul.4s	v19, v29, v14
	ldr	q2, [sp, #2144]                 ; 16-byte Reload
	fmul.4s	v18, v2, v14
	str	q21, [sp, #1024]                ; 16-byte Spill
	fmul.4s	v17, v21, v14
	ldp	x4, x5, [sp, #280]              ; 16-byte Folded Reload
	ldp	q4, q6, [x5]
	ldr	q2, [sp, #2176]                 ; 16-byte Reload
	fmul.4s	v2, v2, v14
	str	q3, [sp, #3824]                 ; 16-byte Spill
	bit.16b	v6, v3, v0
	str	q7, [sp, #3808]                 ; 16-byte Spill
	bit.16b	v4, v7, v1
	stp	q4, q6, [x5]
	ldr	q3, [sp, #2304]                 ; 16-byte Reload
	fmul.4s	v3, v3, v14
	ldr	q4, [sp, #2288]                 ; 16-byte Reload
	fmul.4s	v15, v4, v14
	ldr	q4, [sp, #2416]                 ; 16-byte Reload
	fmul.4s	v16, v4, v14
	ldp	q4, q6, [x4]
	ldr	q7, [sp, #2400]                 ; 16-byte Reload
	fmul.4s	v7, v7, v14
	str	q18, [sp, #3792]                ; 16-byte Spill
	bit.16b	v6, v18, v0
	str	q19, [sp, #3776]                ; 16-byte Spill
	bit.16b	v4, v19, v1
	stp	q4, q6, [x4]
	ldr	q4, [sp, #2512]                 ; 16-byte Reload
	fmul.4s	v4, v4, v14
	ldr	q6, [sp, #2528]                 ; 16-byte Reload
	fmul.4s	v29, v6, v14
	ldr	q6, [sp, #2640]                 ; 16-byte Reload
	fmul.4s	v6, v6, v14
	ldp	x4, x6, [sp, #264]              ; 16-byte Folded Reload
	ldp	q18, q19, [x6]
	ldr	q20, [sp, #2656]                ; 16-byte Reload
	fmul.4s	v21, v20, v14
	str	q2, [sp, #3744]                 ; 16-byte Spill
	bit.16b	v19, v2, v0
	str	q17, [sp, #3760]                ; 16-byte Spill
	bit.16b	v18, v17, v1
	stp	q18, q19, [x6]
	str	q23, [sp, #1200]                ; 16-byte Spill
	fmul.4s	v23, v23, v14
	ldr	q2, [sp, #2768]                 ; 16-byte Reload
	fmul.4s	v19, v2, v14
	str	q25, [sp, #1248]                ; 16-byte Spill
	fmul.4s	v2, v25, v14
	str	q2, [sp, #3680]                 ; 16-byte Spill
	ldp	q18, q25, [x4]
	ldr	q2, [sp, #2880]                 ; 16-byte Reload
	fmul.4s	v20, v2, v14
	str	q15, [sp, #1824]                ; 16-byte Spill
	bit.16b	v25, v15, v0
	str	q3, [sp, #1808]                 ; 16-byte Spill
	bit.16b	v18, v3, v1
	stp	q18, q25, [x4]
	str	q30, [sp, #1296]                ; 16-byte Spill
	fmul.4s	v25, v30, v14
	ldr	q2, [sp, #2992]                 ; 16-byte Reload
	fmul.4s	v30, v2, v14
	str	q26, [sp, #1344]                ; 16-byte Spill
	fmul.4s	v2, v26, v14
	str	q2, [sp, #3840]                 ; 16-byte Spill
	ldp	x4, x7, [sp, #248]              ; 16-byte Folded Reload
	ldp	q18, q15, [x7]
	ldr	d2, [sp, #3856]                 ; 8-byte Reload
	ushll.4s	v2, v2, #0
	str	q7, [sp, #1792]                 ; 16-byte Spill
	bit.16b	v15, v7, v0
	str	q16, [sp, #1776]                ; 16-byte Spill
	bit.16b	v18, v16, v1
	stp	q18, q15, [x7]
	shl.4s	v2, v2, #31
	cmlt.4s	v15, v2, #0
	ldr	q18, [sp, #320]                 ; 16-byte Reload
	mov.16b	v26, v15
	bsl.16b	v26, v29, v18
	ldp	q2, q29, [x4]
	bif.16b	v4, v18, v15
	stp	q4, q26, [sp, #544]             ; 32-byte Folded Spill
	bif.16b	v4, v29, v0
	bit.16b	v2, v26, v1
	stp	q2, q4, [x4]
	ldr	q2, [sp, #3104]                 ; 16-byte Reload
	fmul.4s	v2, v2, v14
	ldr	q3, [sp, #3232]                 ; 16-byte Reload
	fmul.4s	v4, v3, v14
	mov.16b	v26, v15
	bsl.16b	v26, v21, v18
	ldr	x4, [sp, #240]                  ; 8-byte Reload
	ldp	q21, q29, [x4]
	mov.16b	v17, v15
	bsl.16b	v17, v6, v18
	stp	q17, q26, [sp, #480]            ; 32-byte Folded Spill
	bif.16b	v17, v29, v0
	bit.16b	v21, v26, v1
	stp	q21, q17, [x4]
	ldr	q3, [sp, #3216]                 ; 16-byte Reload
	fmul.4s	v21, v3, v14
	str	q13, [sp, #1424]                ; 16-byte Spill
	fmul.4s	v17, v13, v14
	mov.16b	v26, v15
	bsl.16b	v26, v19, v18
	ldr	x4, [sp, #232]                  ; 8-byte Reload
	ldp	q19, q29, [x4]
	bif.16b	v23, v18, v15
	stp	q23, q26, [sp, #448]            ; 32-byte Folded Spill
	bif.16b	v23, v29, v0
	bit.16b	v19, v26, v1
	stp	q19, q23, [x4]
	ldr	q3, [sp, #3344]                 ; 16-byte Reload
	fmul.4s	v19, v3, v14
	ldr	q3, [sp, #3456]                 ; 16-byte Reload
	fmul.4s	v23, v3, v14
	mov.16b	v3, v15
	bsl.16b	v3, v20, v18
	ldr	x4, [sp, #224]                  ; 8-byte Reload
	ldp	q29, q26, [x4]
	ldr	q6, [sp, #3680]                 ; 16-byte Reload
	mov.16b	v7, v15
	bsl.16b	v7, v6, v18
	stp	q7, q3, [sp, #512]              ; 32-byte Folded Spill
	bit.16b	v26, v7, v0
	bit.16b	v29, v3, v1
	stp	q29, q26, [x4]
	ldr	q3, [sp, #3472]                 ; 16-byte Reload
	fmul.4s	v26, v3, v14
	mov.16b	v6, v15
	bsl.16b	v6, v30, v18
	mov.16b	v7, v15
	bsl.16b	v7, v25, v18
	ldr	x4, [sp, #216]                  ; 8-byte Reload
	ldp	q30, q29, [x4]
	mov.16b	v3, v15
	bsl.16b	v3, v2, v18
	stp	q7, q6, [sp, #576]              ; 32-byte Folded Spill
	mov.16b	v2, v1
	bsl.16b	v2, v7, v30
	bit.16b	v29, v6, v0
	stp	q2, q29, [x4]
	ldr	q2, [sp, #3840]                 ; 16-byte Reload
	mov.16b	v7, v15
	bsl.16b	v7, v2, v18
	mov.16b	v16, v15
	bsl.16b	v16, v21, v18
	mov.16b	v20, v15
	bsl.16b	v20, v4, v18
	ldr	x4, [sp, #208]                  ; 8-byte Reload
	ldp	q21, q2, [x4]
	mov.16b	v6, v15
	bsl.16b	v6, v19, v18
	stp	q7, q3, [sp, #608]              ; 32-byte Folded Spill
	mov.16b	v19, v1
	bsl.16b	v19, v7, v21
	bit.16b	v2, v3, v0
	stp	q19, q2, [x4]
	mov.16b	v7, v15
	bsl.16b	v7, v17, v18
	mov.16b	v3, v15
	bsl.16b	v3, v26, v18
	mov.16b	v4, v15
	bsl.16b	v4, v23, v18
	ldr	x4, [sp, #200]                  ; 8-byte Reload
	ldp	q17, q2, [x4]
	stp	q20, q16, [sp, #640]            ; 32-byte Folded Spill
	bit.16b	v17, v20, v1
	bit.16b	v2, v16, v0
	stp	q17, q2, [x4]
	ldr	x4, [sp, #192]                  ; 8-byte Reload
	ldp	q17, q2, [x4]
	str	q7, [sp, #672]                  ; 16-byte Spill
	bit.16b	v17, v7, v1
	stp	q6, q4, [sp, #704]              ; 32-byte Folded Spill
	bit.16b	v2, v6, v0
	stp	q17, q2, [x4]
	ldr	x4, [sp, #184]                  ; 8-byte Reload
	ldp	q2, q17, [x4]
	bit.16b	v17, v4, v0
	str	q3, [sp, #736]                  ; 16-byte Spill
	bit.16b	v2, v3, v1
	stp	q2, q17, [x4]
	ldr	q2, [sp, #3600]                 ; 16-byte Reload
	fmul.4s	v2, v2, v14
	ldr	q3, [sp, #3584]                 ; 16-byte Reload
	fmul.4s	v17, v3, v14
	mov.16b	v3, v15
	bsl.16b	v3, v17, v18
	mov.16b	v4, v15
	bsl.16b	v4, v2, v18
	ldr	x4, [sp, #176]                  ; 8-byte Reload
	ldp	q2, q17, [x4]
	stp	q4, q3, [sp, #752]              ; 32-byte Folded Spill
	bit.16b	v2, v4, v1
	bit.16b	v17, v3, v0
	stp	q2, q17, [x4]
	str	q28, [sp, #1504]                ; 16-byte Spill
	fadd.4s	v2, v28, v24
	str	q9, [sp, #3616]                 ; 16-byte Spill
	fadd.4s	v2, v2, v9
	str	q5, [sp, #1520]                 ; 16-byte Spill
	fadd.4s	v17, v5, v24
	str	q27, [sp, #1536]                ; 16-byte Spill
	fadd.4s	v17, v17, v27
	str	q8, [sp, #3648]                 ; 16-byte Spill
	fadd.4s	v17, v17, v8
	str	q31, [sp, #3632]                ; 16-byte Spill
	fadd.4s	v2, v2, v31
	str	q22, [sp, #3664]                ; 16-byte Spill
	fadd.4s	v2, v2, v22
	str	q10, [sp, #3680]                ; 16-byte Spill
	fadd.4s	v17, v17, v10
	fmul.4s	v17, v17, v14
	fmul.4s	v2, v2, v14
	mov.16b	v3, v15
	bsl.16b	v3, v2, v18
	mov.16b	v4, v15
	bsl.16b	v4, v17, v18
	ldr	x4, [sp, #168]                  ; 8-byte Reload
	ldp	q2, q17, [x4]
	str	q4, [sp, #3840]                 ; 16-byte Spill
	bit.16b	v2, v4, v1
	str	q3, [sp, #784]                  ; 16-byte Spill
	bit.16b	v17, v3, v0
	stp	q2, q17, [x4]
	mvni.4s	v2, #127, msl #16
	ldr	q21, [sp, #1584]                ; 16-byte Reload
	bit.16b	v21, v2, v0
	mvni.4s	v18, #127, msl #16
	ldr	q19, [sp, #1616]                ; 16-byte Reload
	bit.16b	v19, v2, v1
	dup.8b	v2, w3
	str	d2, [sp, #688]                  ; 8-byte Spill
LBB0_93:                                ; %direct.true2291
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x14, x2
	ldp	q2, q17, [x3]
	and.16b	v17, v0, v17
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v19, v2
	fmaxnm.4s	v17, v21, v17
	bit.16b	v21, v17, v0
	bit.16b	v19, v2, v1
	add	x2, x2, #32
	cmp	x2, #512
	b.ne	LBB0_93
; %bb.94:                               ; %direct.false2292
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x2, #0                          ; =0x0
	ldr	q2, [sp, #3696]                 ; 16-byte Reload
	str	q19, [sp, #1616]                ; 16-byte Spill
	fmaxnm.4s	v3, v2, v19
	ldr	q2, [sp, #3808]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v13, v1, v2
	mov	w3, #-1026555904                ; =0xc2d00000
	dup.4s	v31, w3
	mov	w3, #1120403456                 ; =0x42c80000
	dup.4s	v8, w3
	fcmge.4s	v2, v13, v31
	fcmge.4s	v17, v8, v13
	and.16b	v2, v2, v17
	ldr	q17, [sp, #3712]                ; 16-byte Reload
	str	q21, [sp, #1584]                ; 16-byte Spill
	fmaxnm.4s	v24, v17, v21
	ldr	q5, [sp, #3824]                 ; 16-byte Reload
	fsub.4s	v16, v5, v24
	and.16b	v14, v0, v16
	fcmge.4s	v16, v14, v31
	fcmge.4s	v17, v8, v14
	and.16b	v16, v16, v17
	and.16b	v17, v16, v14
	mov	w3, #43579                      ; =0xaa3b
	movk	w3, #16312, lsl #16
	dup.4s	v22, w3
	fmul.4s	v16, v17, v22
	movi.4s	v4, #75, lsl #24
	mvni.4s	v5, #128, lsl #24
	mov.16b	v19, v5
	bsl.16b	v19, v4, v16
	fadd.4s	v16, v16, v19
	fsub.4s	v16, v16, v19
	and.16b	v2, v2, v13
	fmul.4s	v19, v2, v22
	mov.16b	v21, v5
	bsl.16b	v21, v4, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v23, v16
	mov	w3, #29184                      ; =0x7200
	movk	w3, #16177, lsl #16
	dup.4s	v16, w3
	scvtf.4s	v21, v23
	fmul.4s	v26, v21, v16
	fsub.4s	v17, v17, v26
	fcvtzs.4s	v30, v19
	scvtf.4s	v19, v30
	fmul.4s	v26, v19, v16
	fsub.4s	v2, v2, v26
	mov	w3, #48782                      ; =0xbe8e
	movk	w3, #13759, lsl #16
	dup.4s	v27, w3
	fmul.4s	v19, v19, v27
	fsub.4s	v2, v2, v19
	fmul.4s	v19, v21, v27
	fsub.4s	v17, v17, v19
	mov	w3, #11226                      ; =0x2bda
	movk	w3, #14672, lsl #16
	dup.4s	v5, w3
	fmul.4s	v19, v17, v5
	mov	w3, #38601                      ; =0x96c9
	movk	w3, #15030, lsl #16
	dup.4s	v28, w3
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v17, v19
	mov	w3, #34982                      ; =0x88a6
	movk	w3, #15368, lsl #16
	dup.4s	v9, w3
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v17, v19
	mov	w3, #43642                      ; =0xaa7a
	movk	w3, #15658, lsl #16
	dup.4s	v10, w3
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v17, v19
	mov	w3, #43691                      ; =0xaaab
	movk	w3, #15914, lsl #16
	dup.4s	v4, w3
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v17, v19
	movi.4s	v6, #63, lsl #24
	fadd.4s	v19, v19, v6
	fmul.4s	v21, v17, v17
	fmul.4s	v19, v21, v19
	fmul.4s	v21, v2, v5
	fadd.4s	v21, v21, v28
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v9
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v10
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v4
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v6
	fmul.4s	v26, v2, v2
	fmul.4s	v21, v26, v21
	fadd.4s	v2, v2, v21
	fadd.4s	v17, v17, v19
	fmov.4s	v15, #1.00000000
	fadd.4s	v2, v2, v15
	sshr.4s	v19, v30, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v15
	fmul.4s	v2, v2, v21
	fadd.4s	v17, v17, v15
	sshr.4s	v21, v23, #1
	shl.4s	v26, v21, #23
	add.4s	v26, v26, v15
	fmul.4s	v17, v17, v26
	sub.4s	v19, v30, v19
	sub.4s	v21, v23, v21
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v15
	fmul.4s	v17, v17, v21
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v15
	fmul.4s	v2, v2, v19
	fcmgt.4s	v19, v31, v13
	bic.16b	v2, v2, v19
	fcmgt.4s	v19, v31, v14
	bic.16b	v17, v17, v19
	fcmgt.4s	v19, v14, v8
	fneg.4s	v30, v18
	bit.16b	v17, v30, v19
	fcmgt.4s	v19, v13, v8
	bit.16b	v2, v30, v19
	fcmeq.4s	v19, v13, v13
	ldr	q25, [sp, #1712]                ; 16-byte Reload
	bif.16b	v2, v25, v19
	str	q2, [sp, #3824]                 ; 16-byte Spill
	fcmeq.4s	v2, v14, v14
	bsl.16b	v2, v17, v25
	str	q2, [sp, #3808]                 ; 16-byte Spill
	ldr	q2, [sp, #3776]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v20, v1, v2
	fcmge.4s	v2, v20, v31
	fcmge.4s	v17, v8, v20
	and.16b	v2, v2, v17
	ldr	q6, [sp, #3792]                 ; 16-byte Reload
	fsub.4s	v7, v6, v24
	and.16b	v7, v0, v7
	fcmge.4s	v17, v7, v31
	fcmge.4s	v19, v8, v7
	and.16b	v17, v17, v19
	and.16b	v17, v17, v7
	fmul.4s	v19, v17, v22
	mvni.4s	v6, #128, lsl #24
	movi.4s	v18, #75, lsl #24
	mov.16b	v21, v6
	bsl.16b	v21, v18, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	and.16b	v2, v2, v20
	fmul.4s	v21, v2, v22
	mov.16b	v23, v6
	bsl.16b	v23, v18, v21
	fadd.4s	v21, v21, v23
	fsub.4s	v21, v21, v23
	fcvtzs.4s	v23, v19
	scvtf.4s	v19, v23
	fmul.4s	v26, v19, v16
	fsub.4s	v17, v17, v26
	fcvtzs.4s	v21, v21
	scvtf.4s	v26, v21
	fmul.4s	v29, v26, v16
	fsub.4s	v2, v2, v29
	fmul.4s	v26, v26, v27
	fsub.4s	v2, v2, v26
	fmul.4s	v19, v19, v27
	fsub.4s	v17, v17, v19
	mov.16b	v14, v5
	fmul.4s	v19, v17, v5
	mov.16b	v13, v28
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v17, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v17, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v17, v19
	mov.16b	v28, v4
	fadd.4s	v19, v19, v4
	fmul.4s	v19, v17, v19
	movi.4s	v6, #63, lsl #24
	fadd.4s	v19, v19, v6
	fmul.4s	v26, v17, v17
	fmul.4s	v19, v26, v19
	fmul.4s	v26, v2, v5
	fadd.4s	v26, v26, v13
	fmul.4s	v26, v2, v26
	fadd.4s	v26, v26, v9
	fmul.4s	v26, v2, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v26, v2, v26
	fadd.4s	v26, v26, v4
	fmul.4s	v26, v2, v26
	fadd.4s	v26, v26, v6
	fmul.4s	v29, v2, v2
	fmul.4s	v26, v29, v26
	fadd.4s	v2, v2, v26
	fadd.4s	v17, v17, v19
	fadd.4s	v2, v2, v15
	sshr.4s	v19, v21, #1
	shl.4s	v26, v19, #23
	add.4s	v26, v26, v15
	fmul.4s	v2, v2, v26
	fadd.4s	v17, v17, v15
	sshr.4s	v26, v23, #1
	shl.4s	v29, v26, #23
	add.4s	v29, v29, v15
	fmul.4s	v17, v17, v29
	sub.4s	v19, v21, v19
	sub.4s	v21, v23, v26
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v15
	fmul.4s	v17, v17, v21
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v15
	fmul.4s	v2, v2, v19
	fcmgt.4s	v19, v31, v20
	bic.16b	v2, v2, v19
	fcmgt.4s	v19, v31, v7
	bic.16b	v17, v17, v19
	fcmgt.4s	v19, v7, v8
	bit.16b	v17, v30, v19
	fcmgt.4s	v19, v20, v8
	bit.16b	v2, v30, v19
	fcmeq.4s	v19, v20, v20
	bif.16b	v2, v25, v19
	str	q2, [sp, #3792]                 ; 16-byte Spill
	fcmeq.4s	v2, v7, v7
	bsl.16b	v2, v17, v25
	mov.16b	v18, v25
	str	q2, [sp, #3776]                 ; 16-byte Spill
	ldr	q2, [sp, #3760]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	mov.16b	v25, v3
	and.16b	v3, v1, v2
	fcmge.4s	v2, v3, v31
	fcmge.4s	v7, v8, v3
	and.16b	v2, v2, v7
	ldr	q4, [sp, #3744]                 ; 16-byte Reload
	fsub.4s	v7, v4, v24
	and.16b	v7, v0, v7
	fcmge.4s	v17, v7, v31
	fcmge.4s	v19, v8, v7
	and.16b	v17, v17, v19
	and.16b	v17, v17, v7
	mov.16b	v29, v22
	fmul.4s	v19, v17, v22
	movi.4s	v4, #75, lsl #24
	mvni.4s	v5, #128, lsl #24
	mov.16b	v20, v5
	bsl.16b	v20, v4, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	and.16b	v2, v2, v3
	fmul.4s	v20, v2, v22
	mov.16b	v21, v5
	bsl.16b	v21, v4, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v21, v20, v21
	fcvtzs.4s	v20, v19
	scvtf.4s	v19, v20
	fmul.4s	v23, v19, v16
	fsub.4s	v17, v17, v23
	fcvtzs.4s	v21, v21
	scvtf.4s	v23, v21
	fmul.4s	v26, v23, v16
	fsub.4s	v2, v2, v26
	fmul.4s	v23, v23, v27
	fsub.4s	v2, v2, v23
	fmul.4s	v19, v19, v27
	fsub.4s	v17, v17, v19
	fmul.4s	v19, v17, v14
	fadd.4s	v19, v19, v13
	fmul.4s	v19, v17, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v17, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v17, v19
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v17, v19
	fadd.4s	v19, v19, v6
	fmul.4s	v23, v17, v17
	fmul.4s	v19, v23, v19
	fmul.4s	v23, v2, v14
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v9
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v28
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v6
	fmul.4s	v26, v2, v2
	fmul.4s	v23, v26, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v17, v17, v19
	fadd.4s	v2, v2, v15
	sshr.4s	v19, v21, #1
	shl.4s	v23, v19, #23
	add.4s	v23, v23, v15
	fmul.4s	v2, v2, v23
	fadd.4s	v17, v17, v15
	sshr.4s	v23, v20, #1
	shl.4s	v26, v23, #23
	add.4s	v26, v26, v15
	fmul.4s	v17, v17, v26
	sub.4s	v19, v21, v19
	sub.4s	v20, v20, v23
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v15
	fmul.4s	v17, v17, v20
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v15
	fmul.4s	v2, v2, v19
	fcmgt.4s	v19, v31, v3
	bic.16b	v2, v2, v19
	fcmgt.4s	v19, v31, v7
	bic.16b	v17, v17, v19
	fcmgt.4s	v19, v7, v8
	bit.16b	v17, v30, v19
	fcmgt.4s	v19, v3, v8
	bit.16b	v2, v30, v19
	fcmeq.4s	v3, v3, v3
	mov.16b	v26, v18
	bif.16b	v2, v18, v3
	str	q2, [sp, #3760]                 ; 16-byte Spill
	fcmeq.4s	v2, v7, v7
	bsl.16b	v2, v17, v18
	str	q2, [sp, #3744]                 ; 16-byte Spill
	ldr	q2, [sp, #1808]                 ; 16-byte Reload
	fsub.4s	v2, v2, v25
	and.16b	v3, v1, v2
	fcmge.4s	v2, v3, v31
	fcmge.4s	v7, v8, v3
	and.16b	v2, v2, v7
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	fsub.4s	v6, v4, v24
	and.16b	v6, v0, v6
	fcmge.4s	v7, v6, v31
	fcmge.4s	v17, v8, v6
	and.16b	v7, v7, v17
	and.16b	v17, v7, v6
	fmul.4s	v7, v17, v22
	mvni.4s	v4, #128, lsl #24
	movi.4s	v5, #75, lsl #24
	mov.16b	v19, v4
	bsl.16b	v19, v5, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v3
	fmul.4s	v19, v2, v22
	mov.16b	v20, v4
	bsl.16b	v20, v5, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v7, v7
	scvtf.4s	v20, v7
	fmul.4s	v21, v20, v16
	fsub.4s	v17, v17, v21
	fcvtzs.4s	v19, v19
	scvtf.4s	v21, v19
	fmul.4s	v23, v21, v16
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v27
	fsub.4s	v2, v2, v21
	fmul.4s	v20, v20, v27
	fsub.4s	v17, v17, v20
	fmul.4s	v20, v17, v14
	fadd.4s	v20, v20, v13
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v9
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v10
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v17, v20
	movi.4s	v4, #63, lsl #24
	fadd.4s	v20, v20, v4
	fmul.4s	v21, v17, v17
	fmul.4s	v20, v21, v20
	fmul.4s	v21, v2, v14
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v9
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v10
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v28
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v4
	fmul.4s	v23, v2, v2
	fmul.4s	v21, v23, v21
	fadd.4s	v2, v2, v21
	fadd.4s	v17, v17, v20
	fadd.4s	v2, v2, v15
	sshr.4s	v20, v19, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v15
	fmul.4s	v2, v2, v21
	fadd.4s	v17, v17, v15
	sshr.4s	v21, v7, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v15
	fmul.4s	v17, v17, v23
	sub.4s	v19, v19, v20
	sub.4s	v7, v7, v21
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v15
	fmul.4s	v7, v17, v7
	shl.4s	v17, v19, #23
	add.4s	v17, v17, v15
	fmul.4s	v2, v2, v17
	fcmgt.4s	v17, v31, v3
	bic.16b	v2, v2, v17
	fcmgt.4s	v17, v31, v6
	bic.16b	v7, v7, v17
	fcmgt.4s	v17, v6, v8
	bit.16b	v7, v30, v17
	fcmgt.4s	v17, v3, v8
	bit.16b	v2, v30, v17
	fcmeq.4s	v3, v3, v3
	bif.16b	v2, v18, v3
	str	q2, [sp, #1824]                 ; 16-byte Spill
	fcmeq.4s	v2, v6, v6
	bsl.16b	v2, v7, v18
	str	q2, [sp, #1808]                 ; 16-byte Spill
	ldr	q2, [sp, #1776]                 ; 16-byte Reload
	fsub.4s	v2, v2, v25
	and.16b	v3, v1, v2
	fcmge.4s	v2, v3, v31
	fcmge.4s	v6, v8, v3
	and.16b	v2, v2, v6
	ldr	q4, [sp, #1792]                 ; 16-byte Reload
	fsub.4s	v6, v4, v24
	and.16b	v6, v0, v6
	fcmge.4s	v7, v6, v31
	fcmge.4s	v17, v8, v6
	and.16b	v7, v7, v17
	and.16b	v17, v7, v6
	fmul.4s	v7, v17, v22
	movi.4s	v4, #75, lsl #24
	mvni.4s	v5, #128, lsl #24
	mov.16b	v19, v5
	bsl.16b	v19, v4, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v3
	fmul.4s	v19, v2, v22
	mov.16b	v20, v5
	bsl.16b	v20, v4, v19
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v7, v7
	scvtf.4s	v20, v7
	fmul.4s	v21, v20, v16
	fsub.4s	v17, v17, v21
	fcvtzs.4s	v19, v19
	scvtf.4s	v21, v19
	fmul.4s	v22, v21, v16
	fsub.4s	v2, v2, v22
	fmul.4s	v21, v21, v27
	fsub.4s	v2, v2, v21
	fmul.4s	v20, v20, v27
	fsub.4s	v17, v17, v20
	fmul.4s	v20, v17, v14
	fadd.4s	v20, v20, v13
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v9
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v10
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v17, v20
	movi.4s	v4, #63, lsl #24
	fadd.4s	v20, v20, v4
	fmul.4s	v21, v17, v17
	fmul.4s	v20, v21, v20
	fmul.4s	v21, v2, v14
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v9
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v10
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v28
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v4
	movi.4s	v23, #63, lsl #24
	fmul.4s	v22, v2, v2
	fmul.4s	v21, v22, v21
	fadd.4s	v2, v2, v21
	fadd.4s	v17, v17, v20
	fadd.4s	v2, v2, v15
	sshr.4s	v20, v19, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v15
	fmul.4s	v2, v2, v21
	fadd.4s	v17, v17, v15
	sshr.4s	v21, v7, #1
	shl.4s	v22, v21, #23
	add.4s	v22, v22, v15
	fmul.4s	v17, v17, v22
	sub.4s	v19, v19, v20
	sub.4s	v7, v7, v21
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v15
	fmul.4s	v7, v17, v7
	shl.4s	v17, v19, #23
	add.4s	v17, v17, v15
	fmul.4s	v2, v2, v17
	fcmgt.4s	v17, v31, v3
	bic.16b	v2, v2, v17
	fcmgt.4s	v17, v31, v6
	bic.16b	v7, v7, v17
	fcmgt.4s	v17, v6, v8
	bit.16b	v7, v30, v17
	fcmgt.4s	v17, v3, v8
	bit.16b	v2, v30, v17
	fcmeq.4s	v3, v3, v3
	bif.16b	v2, v18, v3
	str	q2, [sp, #1792]                 ; 16-byte Spill
	fcmeq.4s	v2, v6, v6
	bsl.16b	v2, v7, v18
	str	q2, [sp, #1776]                 ; 16-byte Spill
	ldp	q2, q4, [sp, #544]              ; 32-byte Folded Reload
	fsub.4s	v2, v2, v24
	and.16b	v3, v0, v2
	fcmge.4s	v2, v3, v31
	fcmge.4s	v6, v8, v3
	and.16b	v2, v2, v6
	fsub.4s	v6, v4, v25
	and.16b	v6, v1, v6
	fcmge.4s	v7, v6, v31
	fcmge.4s	v17, v8, v6
	and.16b	v7, v7, v17
	and.16b	v17, v7, v6
	fmul.4s	v7, v17, v29
	mvni.4s	v4, #128, lsl #24
	movi.4s	v5, #75, lsl #24
	mov.16b	v18, v4
	bsl.16b	v18, v5, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	and.16b	v2, v2, v3
	fmul.4s	v18, v2, v29
	mov.16b	v19, v4
	bsl.16b	v19, v5, v18
	mvni.4s	v22, #128, lsl #24
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	fcvtzs.4s	v7, v7
	scvtf.4s	v19, v7
	fmul.4s	v20, v19, v16
	fsub.4s	v17, v17, v20
	fcvtzs.4s	v18, v18
	scvtf.4s	v20, v18
	fmul.4s	v21, v20, v16
	fsub.4s	v2, v2, v21
	fmul.4s	v20, v20, v27
	fsub.4s	v2, v2, v20
	fmul.4s	v19, v19, v27
	fsub.4s	v17, v17, v19
	fmul.4s	v19, v17, v14
	fadd.4s	v19, v19, v13
	fmul.4s	v19, v17, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v17, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v17, v19
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v17, v19
	fadd.4s	v19, v19, v23
	fmul.4s	v20, v17, v17
	fmul.4s	v19, v20, v19
	fmul.4s	v20, v2, v14
	fadd.4s	v20, v20, v13
	fmul.4s	v20, v2, v20
	fadd.4s	v20, v20, v9
	fmul.4s	v20, v2, v20
	fadd.4s	v20, v20, v10
	fmul.4s	v20, v2, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v2, v20
	fadd.4s	v20, v20, v23
	fmul.4s	v21, v2, v2
	fmul.4s	v20, v21, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v17, v17, v19
	fadd.4s	v2, v2, v15
	sshr.4s	v19, v18, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v15
	fmul.4s	v2, v2, v20
	fadd.4s	v17, v17, v15
	sshr.4s	v20, v7, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v15
	fmul.4s	v17, v17, v21
	sub.4s	v18, v18, v19
	sub.4s	v7, v7, v20
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v15
	fmul.4s	v7, v17, v7
	shl.4s	v17, v18, #23
	add.4s	v17, v17, v15
	fmul.4s	v2, v2, v17
	fcmgt.4s	v17, v31, v3
	bic.16b	v2, v2, v17
	fcmgt.4s	v17, v31, v6
	bic.16b	v7, v7, v17
	fcmgt.4s	v17, v6, v8
	bit.16b	v7, v30, v17
	fcmgt.4s	v17, v3, v8
	bit.16b	v2, v30, v17
	fcmeq.4s	v3, v3, v3
	bif.16b	v2, v26, v3
	str	q2, [sp, #560]                  ; 16-byte Spill
	fcmeq.4s	v2, v6, v6
	bsl.16b	v2, v7, v26
	str	q2, [sp, #544]                  ; 16-byte Spill
	ldp	q2, q4, [sp, #480]              ; 32-byte Folded Reload
	fsub.4s	v2, v2, v24
	and.16b	v3, v0, v2
	fcmge.4s	v2, v3, v31
	fcmge.4s	v5, v8, v3
	and.16b	v2, v2, v5
	fsub.4s	v4, v4, v25
	and.16b	v4, v1, v4
	fcmge.4s	v5, v4, v31
	fcmge.4s	v6, v8, v4
	and.16b	v5, v5, v6
	and.16b	v6, v5, v4
	fmul.4s	v5, v6, v29
	movi.4s	v17, #75, lsl #24
	mov.16b	v7, v22
	bsl.16b	v7, v17, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	and.16b	v2, v2, v3
	fmul.4s	v7, v2, v29
	bif.16b	v17, v7, v22
	movi.4s	v21, #75, lsl #24
	fadd.4s	v7, v7, v17
	fsub.4s	v7, v7, v17
	fcvtzs.4s	v5, v5
	scvtf.4s	v17, v5
	fmul.4s	v18, v17, v16
	fsub.4s	v6, v6, v18
	fcvtzs.4s	v7, v7
	scvtf.4s	v18, v7
	fmul.4s	v19, v18, v16
	fsub.4s	v2, v2, v19
	fmul.4s	v18, v18, v27
	fsub.4s	v2, v2, v18
	fmul.4s	v17, v17, v27
	fsub.4s	v6, v6, v17
	fmul.4s	v17, v6, v14
	fadd.4s	v17, v17, v13
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v9
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v10
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v28
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v23
	fmul.4s	v18, v6, v6
	fmul.4s	v17, v18, v17
	fmul.4s	v18, v2, v14
	fadd.4s	v18, v18, v13
	fmul.4s	v18, v2, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v2, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v2, v18
	fadd.4s	v18, v18, v28
	fmul.4s	v18, v2, v18
	fadd.4s	v18, v18, v23
	fmul.4s	v19, v2, v2
	fmul.4s	v18, v19, v18
	fadd.4s	v2, v2, v18
	fadd.4s	v6, v6, v17
	fadd.4s	v2, v2, v15
	sshr.4s	v17, v7, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v15
	fmul.4s	v2, v2, v18
	fadd.4s	v6, v6, v15
	sshr.4s	v18, v5, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v15
	fmul.4s	v6, v6, v19
	sub.4s	v7, v7, v17
	sub.4s	v5, v5, v18
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v15
	fmul.4s	v5, v6, v5
	shl.4s	v6, v7, #23
	add.4s	v6, v6, v15
	fmul.4s	v2, v2, v6
	fcmgt.4s	v6, v31, v3
	bic.16b	v2, v2, v6
	fcmgt.4s	v6, v31, v4
	bic.16b	v5, v5, v6
	fcmgt.4s	v6, v4, v8
	bit.16b	v5, v30, v6
	fcmgt.4s	v6, v3, v8
	bit.16b	v2, v30, v6
	fcmeq.4s	v3, v3, v3
	bif.16b	v2, v26, v3
	str	q2, [sp, #496]                  ; 16-byte Spill
	fcmeq.4s	v2, v4, v4
	bsl.16b	v2, v5, v26
	str	q2, [sp, #480]                  ; 16-byte Spill
	ldp	q2, q4, [sp, #448]              ; 32-byte Folded Reload
	fsub.4s	v2, v2, v24
	and.16b	v3, v0, v2
	fcmge.4s	v2, v3, v31
	fcmge.4s	v5, v8, v3
	and.16b	v2, v2, v5
	fsub.4s	v5, v4, v25
	and.16b	v5, v1, v5
	fcmge.4s	v6, v5, v31
	fcmge.4s	v7, v8, v5
	and.16b	v6, v6, v7
	and.16b	v7, v6, v5
	fmul.4s	v6, v7, v29
	mov.16b	v17, v22
	bsl.16b	v17, v21, v6
	fadd.4s	v6, v6, v17
	fsub.4s	v6, v6, v17
	and.16b	v2, v2, v3
	fmul.4s	v17, v2, v29
	mov.16b	v18, v22
	bsl.16b	v18, v21, v17
	fadd.4s	v17, v17, v18
	fsub.4s	v17, v17, v18
	fcvtzs.4s	v6, v6
	scvtf.4s	v18, v6
	fmul.4s	v19, v18, v16
	fsub.4s	v7, v7, v19
	fcvtzs.4s	v17, v17
	scvtf.4s	v19, v17
	fmul.4s	v20, v19, v16
	fsub.4s	v2, v2, v20
	fmul.4s	v19, v19, v27
	fsub.4s	v2, v2, v19
	fmul.4s	v18, v18, v27
	fsub.4s	v7, v7, v18
	fmul.4s	v18, v7, v14
	fadd.4s	v18, v18, v13
	fmul.4s	v18, v7, v18
	fadd.4s	v18, v18, v9
	fmul.4s	v18, v7, v18
	fadd.4s	v18, v18, v10
	fmul.4s	v18, v7, v18
	fadd.4s	v18, v18, v28
	fmul.4s	v18, v7, v18
	fadd.4s	v18, v18, v23
	fmul.4s	v19, v7, v7
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v2, v14
	fadd.4s	v19, v19, v13
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v9
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v10
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v23
	fmul.4s	v20, v2, v2
	fmul.4s	v19, v20, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v7, v7, v18
	fadd.4s	v2, v2, v15
	sshr.4s	v18, v17, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v15
	fmul.4s	v2, v2, v19
	fadd.4s	v7, v7, v15
	sshr.4s	v19, v6, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v15
	fmul.4s	v7, v7, v20
	sub.4s	v17, v17, v18
	sub.4s	v6, v6, v19
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v15
	fmul.4s	v6, v7, v6
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v15
	fmul.4s	v2, v2, v7
	fcmgt.4s	v7, v31, v3
	bic.16b	v2, v2, v7
	fcmgt.4s	v7, v31, v5
	bic.16b	v6, v6, v7
	fcmgt.4s	v7, v5, v8
	bit.16b	v6, v30, v7
	fcmgt.4s	v7, v3, v8
	bit.16b	v2, v30, v7
	fcmeq.4s	v3, v3, v3
	bif.16b	v2, v26, v3
	str	q2, [sp, #464]                  ; 16-byte Spill
	fcmeq.4s	v2, v5, v5
	bsl.16b	v2, v6, v26
	str	q2, [sp, #448]                  ; 16-byte Spill
	ldp	q2, q4, [sp, #512]              ; 32-byte Folded Reload
	fsub.4s	v2, v2, v24
	and.16b	v3, v0, v2
	fcmge.4s	v2, v3, v31
	fcmge.4s	v6, v8, v3
	and.16b	v2, v2, v6
	fsub.4s	v6, v4, v25
	and.16b	v6, v1, v6
	fcmge.4s	v7, v6, v31
	fcmge.4s	v17, v8, v6
	and.16b	v7, v7, v17
	and.16b	v17, v7, v6
	fmul.4s	v7, v17, v29
	mov.16b	v18, v22
	bsl.16b	v18, v21, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	and.16b	v2, v2, v3
	fmul.4s	v18, v2, v29
	mov.16b	v20, v22
	bsl.16b	v20, v21, v18
	fadd.4s	v18, v18, v20
	fsub.4s	v18, v18, v20
	fcvtzs.4s	v7, v7
	scvtf.4s	v20, v7
	fmul.4s	v21, v20, v16
	fsub.4s	v17, v17, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v22, v21, v16
	fsub.4s	v2, v2, v22
	fmul.4s	v21, v21, v27
	fsub.4s	v2, v2, v21
	fmul.4s	v20, v20, v27
	fsub.4s	v17, v17, v20
	fmul.4s	v20, v17, v14
	fadd.4s	v20, v20, v13
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v9
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v10
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v17, v20
	movi.4s	v4, #63, lsl #24
	fadd.4s	v20, v20, v4
	fmul.4s	v21, v17, v17
	fmul.4s	v20, v21, v20
	fmul.4s	v21, v2, v14
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v9
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v10
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v28
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v4
	movi.4s	v19, #63, lsl #24
	fmul.4s	v22, v2, v2
	fmul.4s	v21, v22, v21
	fadd.4s	v2, v2, v21
	fadd.4s	v17, v17, v20
	fadd.4s	v2, v2, v15
	sshr.4s	v20, v18, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v15
	fmul.4s	v2, v2, v21
	fadd.4s	v17, v17, v15
	sshr.4s	v21, v7, #1
	shl.4s	v22, v21, #23
	add.4s	v22, v22, v15
	fmul.4s	v17, v17, v22
	sub.4s	v18, v18, v20
	sub.4s	v7, v7, v21
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v15
	fmul.4s	v7, v17, v7
	shl.4s	v17, v18, #23
	add.4s	v17, v17, v15
	fmul.4s	v2, v2, v17
	fcmgt.4s	v17, v31, v3
	bic.16b	v2, v2, v17
	fcmgt.4s	v17, v31, v6
	bic.16b	v7, v7, v17
	fcmgt.4s	v17, v6, v8
	bit.16b	v7, v30, v17
	fcmgt.4s	v17, v3, v8
	bit.16b	v2, v30, v17
	fcmeq.4s	v3, v3, v3
	bif.16b	v2, v26, v3
	str	q2, [sp, #528]                  ; 16-byte Spill
	fcmeq.4s	v2, v6, v6
	bsl.16b	v2, v7, v26
	str	q2, [sp, #512]                  ; 16-byte Spill
	ldp	q2, q4, [sp, #576]              ; 32-byte Folded Reload
	fsub.4s	v2, v2, v25
	and.16b	v3, v1, v2
	fcmge.4s	v2, v3, v31
	fcmge.4s	v6, v8, v3
	and.16b	v2, v2, v6
	fsub.4s	v6, v4, v24
	and.16b	v6, v0, v6
	fcmge.4s	v7, v6, v31
	fcmge.4s	v17, v8, v6
	and.16b	v7, v7, v17
	and.16b	v7, v7, v6
	fmul.4s	v17, v7, v29
	movi.4s	v4, #75, lsl #24
	mvni.4s	v5, #128, lsl #24
	mov.16b	v18, v5
	bsl.16b	v18, v4, v17
	fadd.4s	v17, v17, v18
	fsub.4s	v17, v17, v18
	and.16b	v18, v2, v3
	fmul.4s	v2, v18, v29
	mov.16b	v20, v5
	bsl.16b	v20, v4, v2
	fadd.4s	v2, v2, v20
	fsub.4s	v20, v2, v20
	fcvtzs.4s	v2, v17
	scvtf.4s	v17, v2
	fmul.4s	v21, v17, v16
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v20, v20
	scvtf.4s	v21, v20
	fmul.4s	v22, v21, v16
	fsub.4s	v18, v18, v22
	fmul.4s	v21, v21, v27
	fsub.4s	v18, v18, v21
	fmul.4s	v17, v17, v27
	fsub.4s	v7, v7, v17
	fmul.4s	v17, v7, v14
	fadd.4s	v17, v17, v13
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v9
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v10
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v28
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v19
	fmul.4s	v21, v7, v7
	fmul.4s	v17, v21, v17
	fmul.4s	v21, v18, v14
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v18, v21
	fadd.4s	v21, v21, v9
	fmul.4s	v21, v18, v21
	fadd.4s	v21, v21, v10
	fmul.4s	v21, v18, v21
	fadd.4s	v21, v21, v28
	fmul.4s	v21, v18, v21
	fadd.4s	v21, v21, v19
	fmul.4s	v22, v18, v18
	fmul.4s	v21, v22, v21
	fadd.4s	v18, v18, v21
	fadd.4s	v7, v7, v17
	fadd.4s	v17, v18, v15
	sshr.4s	v18, v20, #1
	shl.4s	v21, v18, #23
	add.4s	v21, v21, v15
	fmul.4s	v17, v17, v21
	fadd.4s	v7, v7, v15
	sshr.4s	v21, v2, #1
	shl.4s	v22, v21, #23
	add.4s	v22, v22, v15
	fmul.4s	v7, v7, v22
	sub.4s	v18, v20, v18
	sub.4s	v2, v2, v21
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v15
	fmul.4s	v2, v7, v2
	shl.4s	v7, v18, #23
	add.4s	v7, v7, v15
	fmul.4s	v7, v17, v7
	fcmgt.4s	v17, v31, v3
	bic.16b	v7, v7, v17
	fcmgt.4s	v17, v31, v6
	bic.16b	v2, v2, v17
	fcmgt.4s	v17, v6, v8
	bsl.16b	v17, v30, v2
	fcmgt.4s	v2, v3, v8
	bsl.16b	v2, v30, v7
	fcmeq.4s	v3, v3, v3
	bif.16b	v2, v26, v3
	str	q2, [sp, #592]                  ; 16-byte Spill
	fcmeq.4s	v3, v6, v6
	mov.16b	v2, v3
	bsl.16b	v2, v17, v26
	str	q2, [sp, #576]                  ; 16-byte Spill
	ldr	q2, [sp, #608]                  ; 16-byte Reload
	fsub.4s	v3, v2, v25
	and.16b	v3, v1, v3
	fcmge.4s	v6, v3, v31
	fcmge.4s	v7, v8, v3
	and.16b	v7, v6, v7
	ldr	q2, [sp, #624]                  ; 16-byte Reload
	fsub.4s	v6, v2, v24
	mov.16b	v18, v24
	and.16b	v6, v0, v6
	fcmge.4s	v17, v6, v31
	fcmge.4s	v20, v8, v6
	and.16b	v17, v17, v20
	and.16b	v17, v17, v6
	fmul.4s	v20, v17, v29
	mov.16b	v21, v5
	bsl.16b	v21, v4, v20
	fadd.4s	v20, v20, v21
	fsub.4s	v20, v20, v21
	and.16b	v21, v7, v3
	fmul.4s	v7, v21, v29
	mov.16b	v22, v5
	bsl.16b	v22, v4, v7
	fadd.4s	v7, v7, v22
	fsub.4s	v22, v7, v22
	fcvtzs.4s	v7, v20
	scvtf.4s	v20, v7
	fmul.4s	v23, v20, v16
	fsub.4s	v17, v17, v23
	fcvtzs.4s	v22, v22
	scvtf.4s	v23, v22
	fmul.4s	v24, v23, v16
	fsub.4s	v21, v21, v24
	fmul.4s	v23, v23, v27
	fsub.4s	v21, v21, v23
	fmul.4s	v20, v20, v27
	fsub.4s	v17, v17, v20
	fmul.4s	v20, v17, v14
	fadd.4s	v20, v20, v13
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v9
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v10
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v17, v20
	movi.4s	v2, #63, lsl #24
	fadd.4s	v20, v20, v2
	fmul.4s	v23, v17, v17
	fmul.4s	v20, v23, v20
	fmul.4s	v23, v21, v14
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v21, v23
	fadd.4s	v23, v23, v9
	fmul.4s	v23, v21, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v23, v21, v23
	fadd.4s	v23, v23, v28
	fmul.4s	v23, v21, v23
	fadd.4s	v23, v23, v2
	fmul.4s	v24, v21, v21
	fmul.4s	v23, v24, v23
	fadd.4s	v21, v21, v23
	fadd.4s	v17, v17, v20
	fadd.4s	v20, v21, v15
	sshr.4s	v21, v22, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v15
	fmul.4s	v20, v20, v23
	fadd.4s	v17, v17, v15
	sshr.4s	v23, v7, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v15
	fmul.4s	v17, v17, v24
	sub.4s	v21, v22, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v15
	fmul.4s	v7, v17, v7
	shl.4s	v17, v21, #23
	add.4s	v17, v17, v15
	fmul.4s	v17, v20, v17
	fcmgt.4s	v20, v31, v3
	bic.16b	v17, v17, v20
	fcmgt.4s	v20, v31, v6
	bic.16b	v7, v7, v20
	fcmgt.4s	v20, v6, v8
	bit.16b	v7, v30, v20
	fcmgt.4s	v20, v3, v8
	bit.16b	v17, v30, v20
	fcmeq.4s	v3, v3, v3
	mov.16b	v2, v3
	bsl.16b	v2, v17, v26
	str	q2, [sp, #624]                  ; 16-byte Spill
	fcmeq.4s	v3, v6, v6
	mov.16b	v2, v3
	bsl.16b	v2, v7, v26
	str	q2, [sp, #608]                  ; 16-byte Spill
	mov.16b	v17, v26
	ldr	q2, [sp, #640]                  ; 16-byte Reload
	mov.16b	v21, v25
	str	q25, [sp, #3856]                ; 16-byte Spill
	fsub.4s	v3, v2, v25
	and.16b	v3, v1, v3
	fcmge.4s	v6, v3, v31
	fcmge.4s	v7, v8, v3
	and.16b	v7, v6, v7
	ldr	q2, [sp, #656]                  ; 16-byte Reload
	fsub.4s	v6, v2, v18
	and.16b	v6, v0, v6
	fcmge.4s	v20, v6, v31
	fcmge.4s	v22, v8, v6
	and.16b	v20, v20, v22
	and.16b	v20, v20, v6
	fmul.4s	v22, v20, v29
	mov.16b	v23, v5
	bsl.16b	v23, v4, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v23, v7, v3
	fmul.4s	v7, v23, v29
	mov.16b	v24, v5
	bsl.16b	v24, v4, v7
	fadd.4s	v7, v7, v24
	fsub.4s	v24, v7, v24
	fcvtzs.4s	v7, v22
	scvtf.4s	v22, v7
	fmul.4s	v25, v22, v16
	fsub.4s	v20, v20, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v16
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v27
	fsub.4s	v23, v23, v25
	fmul.4s	v22, v22, v27
	mov.16b	v5, v27
	fsub.4s	v20, v20, v22
	fmul.4s	v22, v20, v14
	fadd.4s	v22, v22, v13
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v9
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v10
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v28
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v19
	fmul.4s	v25, v20, v20
	fmul.4s	v22, v25, v22
	fmul.4s	v25, v23, v14
	fadd.4s	v25, v25, v13
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v9
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v10
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v28
	mov.16b	v4, v28
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v19
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v20, v20, v22
	fadd.4s	v22, v23, v15
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v15
	fmul.4s	v22, v22, v25
	fadd.4s	v20, v20, v15
	sshr.4s	v25, v7, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v15
	fmul.4s	v20, v20, v26
	sub.4s	v23, v24, v23
	sub.4s	v7, v7, v25
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v15
	fmul.4s	v7, v20, v7
	shl.4s	v20, v23, #23
	add.4s	v20, v20, v15
	fmul.4s	v20, v22, v20
	fcmgt.4s	v22, v31, v3
	bic.16b	v20, v20, v22
	fcmgt.4s	v22, v31, v6
	bic.16b	v7, v7, v22
	fcmgt.4s	v22, v6, v8
	bit.16b	v7, v30, v22
	fcmgt.4s	v22, v3, v8
	bit.16b	v20, v30, v22
	fcmeq.4s	v3, v3, v3
	mov.16b	v19, v17
	mov.16b	v2, v3
	bsl.16b	v2, v20, v17
	str	q2, [sp, #656]                  ; 16-byte Spill
	fcmeq.4s	v3, v6, v6
	mov.16b	v2, v3
	bsl.16b	v2, v7, v17
	str	q2, [sp, #640]                  ; 16-byte Spill
	ldr	q2, [sp, #672]                  ; 16-byte Reload
	fsub.4s	v3, v2, v21
	and.16b	v3, v1, v3
	fcmge.4s	v7, v3, v31
	fcmge.4s	v20, v8, v3
	and.16b	v20, v7, v20
	ldr	q2, [sp, #704]                  ; 16-byte Reload
	fsub.4s	v7, v2, v18
	mov.16b	v17, v18
	and.16b	v7, v0, v7
	fcmge.4s	v23, v7, v31
	fcmge.4s	v24, v8, v7
	and.16b	v23, v23, v24
	and.16b	v23, v23, v7
	fmul.4s	v24, v23, v29
	movi.4s	v2, #75, lsl #24
	mvni.4s	v6, #128, lsl #24
	mov.16b	v25, v6
	bsl.16b	v25, v2, v24
	fadd.4s	v24, v24, v25
	fsub.4s	v24, v24, v25
	and.16b	v25, v20, v3
	fmul.4s	v20, v25, v29
	mov.16b	v26, v6
	bsl.16b	v26, v2, v20
	fadd.4s	v20, v20, v26
	fsub.4s	v26, v20, v26
	fcvtzs.4s	v20, v24
	scvtf.4s	v24, v20
	fmul.4s	v27, v24, v16
	fsub.4s	v23, v23, v27
	fcvtzs.4s	v26, v26
	scvtf.4s	v27, v26
	fmul.4s	v28, v27, v16
	fsub.4s	v25, v25, v28
	fmul.4s	v27, v27, v5
	fsub.4s	v25, v25, v27
	fmul.4s	v24, v24, v5
	fsub.4s	v23, v23, v24
	fmul.4s	v24, v23, v14
	fadd.4s	v24, v24, v13
	fmul.4s	v24, v23, v24
	fadd.4s	v24, v24, v9
	fmul.4s	v24, v23, v24
	fadd.4s	v24, v24, v10
	fmul.4s	v24, v23, v24
	mov.16b	v6, v4
	fadd.4s	v24, v24, v4
	fmul.4s	v24, v23, v24
	movi.4s	v2, #63, lsl #24
	fadd.4s	v24, v24, v2
	fmul.4s	v27, v23, v23
	fmul.4s	v24, v27, v24
	fmul.4s	v27, v25, v14
	fadd.4s	v27, v27, v13
	fmul.4s	v27, v25, v27
	fadd.4s	v27, v27, v9
	mov.16b	v18, v9
	fmul.4s	v27, v25, v27
	fadd.4s	v27, v27, v10
	fmul.4s	v27, v25, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v25, v27
	fadd.4s	v27, v27, v2
	fmul.4s	v28, v25, v25
	fmul.4s	v27, v28, v27
	fadd.4s	v25, v25, v27
	fadd.4s	v23, v23, v24
	fadd.4s	v24, v25, v15
	sshr.4s	v25, v26, #1
	shl.4s	v27, v25, #23
	add.4s	v27, v27, v15
	fmul.4s	v24, v24, v27
	fadd.4s	v23, v23, v15
	sshr.4s	v27, v20, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v15
	fmul.4s	v23, v23, v28
	sub.4s	v25, v26, v25
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v15
	fmul.4s	v20, v23, v20
	shl.4s	v23, v25, #23
	add.4s	v23, v23, v15
	fmul.4s	v23, v24, v23
	fcmgt.4s	v24, v31, v3
	bic.16b	v23, v23, v24
	fcmgt.4s	v24, v31, v7
	bic.16b	v20, v20, v24
	fcmgt.4s	v24, v7, v8
	bit.16b	v20, v30, v24
	fcmgt.4s	v24, v3, v8
	bit.16b	v23, v30, v24
	mov.16b	v22, v30
	fcmeq.4s	v3, v3, v3
	mov.16b	v2, v3
	bsl.16b	v2, v23, v19
	str	q2, [sp, #432]                  ; 16-byte Spill
	fcmeq.4s	v3, v7, v7
	mov.16b	v2, v3
	bsl.16b	v2, v20, v19
	str	q2, [sp, #416]                  ; 16-byte Spill
	mov.16b	v23, v19
	ldr	q2, [sp, #720]                  ; 16-byte Reload
	mov.16b	v4, v17
	fsub.4s	v3, v2, v17
	and.16b	v3, v0, v3
	fcmge.4s	v7, v3, v31
	fcmge.4s	v20, v8, v3
	and.16b	v20, v7, v20
	ldr	q2, [sp, #736]                  ; 16-byte Reload
	ldr	q24, [sp, #3856]                ; 16-byte Reload
	fsub.4s	v7, v2, v24
	and.16b	v7, v1, v7
	fcmge.4s	v25, v7, v31
	fcmge.4s	v26, v8, v7
	and.16b	v25, v25, v26
	and.16b	v25, v25, v7
	fmul.4s	v26, v25, v29
	mvni.4s	v2, #128, lsl #24
	movi.4s	v17, #75, lsl #24
	mov.16b	v27, v2
	bsl.16b	v27, v17, v26
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	and.16b	v27, v20, v3
	fmul.4s	v20, v27, v29
	mov.16b	v28, v2
	bsl.16b	v28, v17, v20
	fadd.4s	v20, v20, v28
	fsub.4s	v28, v20, v28
	fcvtzs.4s	v20, v26
	scvtf.4s	v26, v20
	fmul.4s	v30, v26, v16
	fsub.4s	v25, v25, v30
	fcvtzs.4s	v28, v28
	scvtf.4s	v30, v28
	fmul.4s	v9, v30, v16
	fsub.4s	v27, v27, v9
	fmul.4s	v30, v30, v5
	fsub.4s	v27, v27, v30
	fmul.4s	v26, v26, v5
	fsub.4s	v25, v25, v26
	fmul.4s	v26, v25, v14
	fadd.4s	v26, v26, v13
	fmul.4s	v26, v25, v26
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v25, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v26, v25, v26
	mov.16b	v19, v6
	fadd.4s	v26, v26, v6
	fmul.4s	v26, v25, v26
	movi.4s	v2, #63, lsl #24
	fadd.4s	v26, v26, v2
	fmul.4s	v30, v25, v25
	fmul.4s	v26, v30, v26
	fmul.4s	v30, v27, v14
	fadd.4s	v30, v30, v13
	mov.16b	v6, v13
	fmul.4s	v30, v27, v30
	fadd.4s	v30, v30, v18
	fmul.4s	v30, v27, v30
	fadd.4s	v30, v30, v10
	mov.16b	v17, v10
	fmul.4s	v30, v27, v30
	fadd.4s	v30, v30, v19
	fmul.4s	v30, v27, v30
	fadd.4s	v30, v30, v2
	fmul.4s	v9, v27, v27
	fmul.4s	v30, v9, v30
	fadd.4s	v27, v27, v30
	fadd.4s	v25, v25, v26
	fadd.4s	v26, v27, v15
	sshr.4s	v27, v28, #1
	shl.4s	v30, v27, #23
	add.4s	v30, v30, v15
	fmul.4s	v26, v26, v30
	fadd.4s	v25, v25, v15
	sshr.4s	v30, v20, #1
	shl.4s	v9, v30, #23
	add.4s	v9, v9, v15
	fmul.4s	v25, v25, v9
	sub.4s	v27, v28, v27
	sub.4s	v20, v20, v30
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v15
	fmul.4s	v20, v25, v20
	shl.4s	v25, v27, #23
	add.4s	v25, v25, v15
	fmul.4s	v25, v26, v25
	fcmgt.4s	v26, v31, v3
	bic.16b	v25, v25, v26
	fcmgt.4s	v26, v31, v7
	bic.16b	v20, v20, v26
	fcmgt.4s	v26, v7, v8
	mov.16b	v30, v22
	bit.16b	v20, v22, v26
	fcmgt.4s	v26, v3, v8
	bit.16b	v25, v22, v26
	fcmeq.4s	v3, v3, v3
	mov.16b	v2, v3
	bsl.16b	v2, v25, v23
	str	q2, [sp, #400]                  ; 16-byte Spill
	fcmeq.4s	v3, v7, v7
	mov.16b	v2, v3
	bsl.16b	v2, v20, v23
	str	q2, [sp, #384]                  ; 16-byte Spill
	ldr	q2, [sp, #752]                  ; 16-byte Reload
	fsub.4s	v3, v2, v24
	mov.16b	v28, v24
	and.16b	v3, v1, v3
	fcmge.4s	v7, v3, v31
	fcmge.4s	v20, v8, v3
	and.16b	v20, v7, v20
	ldr	q2, [sp, #768]                  ; 16-byte Reload
	fsub.4s	v7, v2, v4
	mov.16b	v24, v4
	and.16b	v7, v0, v7
	fcmge.4s	v25, v7, v31
	fcmge.4s	v26, v8, v7
	and.16b	v25, v25, v26
	and.16b	v25, v25, v7
	fmul.4s	v26, v25, v29
	mvni.4s	v2, #128, lsl #24
	movi.4s	v4, #75, lsl #24
	mov.16b	v27, v2
	bsl.16b	v27, v4, v26
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	and.16b	v27, v20, v3
	fmul.4s	v20, v27, v29
	mov.16b	v22, v29
	mov.16b	v9, v2
	bsl.16b	v9, v4, v20
	fadd.4s	v20, v20, v9
	fsub.4s	v9, v20, v9
	fcvtzs.4s	v20, v26
	scvtf.4s	v26, v20
	fmul.4s	v10, v26, v16
	fsub.4s	v25, v25, v10
	fcvtzs.4s	v9, v9
	scvtf.4s	v10, v9
	fmul.4s	v13, v10, v16
	fsub.4s	v27, v27, v13
	fmul.4s	v10, v10, v5
	fsub.4s	v27, v27, v10
	fmul.4s	v26, v26, v5
	fsub.4s	v25, v25, v26
	fmul.4s	v26, v25, v14
	mov.16b	v21, v6
	fadd.4s	v26, v26, v6
	fmul.4s	v26, v25, v26
	mov.16b	v2, v18
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v25, v26
	mov.16b	v4, v17
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v25, v26
	fadd.4s	v26, v26, v19
	fmul.4s	v26, v25, v26
	movi.4s	v18, #63, lsl #24
	fadd.4s	v26, v26, v18
	fmul.4s	v10, v25, v25
	fmul.4s	v26, v10, v26
	fmul.4s	v10, v27, v14
	mov.16b	v17, v14
	fadd.4s	v10, v10, v6
	fmul.4s	v10, v27, v10
	fadd.4s	v10, v10, v2
	fmul.4s	v10, v27, v10
	fadd.4s	v10, v10, v4
	fmul.4s	v10, v27, v10
	fadd.4s	v10, v10, v19
	fmul.4s	v10, v27, v10
	fadd.4s	v10, v10, v18
	movi.4s	v29, #63, lsl #24
	fmul.4s	v13, v27, v27
	fmul.4s	v10, v13, v10
	fadd.4s	v27, v27, v10
	fadd.4s	v25, v25, v26
	fadd.4s	v26, v27, v15
	sshr.4s	v27, v9, #1
	shl.4s	v10, v27, #23
	add.4s	v10, v10, v15
	fmul.4s	v26, v26, v10
	fadd.4s	v25, v25, v15
	sshr.4s	v10, v20, #1
	shl.4s	v13, v10, #23
	add.4s	v13, v13, v15
	fmul.4s	v25, v25, v13
	sub.4s	v27, v9, v27
	sub.4s	v20, v20, v10
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v15
	fmul.4s	v20, v25, v20
	shl.4s	v25, v27, #23
	add.4s	v25, v25, v15
	fmul.4s	v25, v26, v25
	fcmgt.4s	v26, v31, v3
	bic.16b	v25, v25, v26
	fcmgt.4s	v26, v31, v7
	bic.16b	v20, v20, v26
	fcmgt.4s	v26, v7, v8
	bit.16b	v20, v30, v26
	fcmgt.4s	v26, v3, v8
	bit.16b	v25, v30, v26
	fcmeq.4s	v3, v3, v3
	mov.16b	v9, v3
	bsl.16b	v9, v25, v23
	fcmeq.4s	v3, v7, v7
	mov.16b	v10, v3
	bsl.16b	v10, v20, v23
	mov.16b	v6, v23
	ldr	q3, [sp, #3840]                 ; 16-byte Reload
	fsub.4s	v3, v3, v28
	and.16b	v3, v1, v3
	fcmge.4s	v7, v3, v31
	fcmge.4s	v20, v8, v3
	and.16b	v20, v7, v20
	str	q24, [sp, #3840]                ; 16-byte Spill
	ldr	q7, [sp, #784]                  ; 16-byte Reload
	fsub.4s	v7, v7, v24
	and.16b	v7, v0, v7
	fcmge.4s	v25, v7, v31
	fcmge.4s	v26, v8, v7
	and.16b	v25, v25, v26
	and.16b	v25, v25, v7
	mov.16b	v13, v22
	fmul.4s	v26, v25, v22
	movi.4s	v22, #75, lsl #24
	mvni.4s	v23, #128, lsl #24
	mov.16b	v27, v23
	bsl.16b	v27, v22, v26
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	and.16b	v27, v20, v3
	str	q13, [sp, #784]                 ; 16-byte Spill
	fmul.4s	v20, v27, v13
	mov.16b	v13, v23
	bsl.16b	v13, v22, v20
	fadd.4s	v20, v20, v13
	fsub.4s	v13, v20, v13
	fcvtzs.4s	v20, v26
	scvtf.4s	v26, v20
	fmul.4s	v14, v26, v16
	fsub.4s	v25, v25, v14
	fcvtzs.4s	v13, v13
	scvtf.4s	v14, v13
	fmul.4s	v16, v14, v16
	fsub.4s	v16, v27, v16
	fmul.4s	v26, v26, v5
	fmul.4s	v27, v14, v5
	fsub.4s	v16, v16, v27
	fsub.4s	v25, v25, v26
	fmul.4s	v26, v25, v17
	fadd.4s	v26, v26, v21
	fmul.4s	v26, v25, v26
	fadd.4s	v26, v26, v2
	fmul.4s	v26, v25, v26
	fadd.4s	v26, v26, v4
	fmul.4s	v26, v25, v26
	fadd.4s	v26, v26, v19
	fmul.4s	v26, v25, v26
	fadd.4s	v26, v26, v29
	fmul.4s	v27, v25, v25
	fmul.4s	v26, v27, v26
	stp	q21, q17, [sp, #752]            ; 32-byte Folded Spill
	fmul.4s	v27, v16, v17
	fadd.4s	v27, v27, v21
	fmul.4s	v27, v16, v27
	stp	q4, q2, [sp, #720]              ; 32-byte Folded Spill
	fadd.4s	v27, v27, v2
	fmul.4s	v27, v16, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v16, v27
	str	q19, [sp, #704]                 ; 16-byte Spill
	fadd.4s	v27, v27, v19
	fmul.4s	v27, v16, v27
	fadd.4s	v27, v27, v29
	fmul.4s	v14, v16, v16
	fmul.4s	v27, v14, v27
	fadd.4s	v16, v16, v27
	fadd.4s	v25, v25, v26
	fadd.4s	v16, v16, v15
	sshr.4s	v26, v13, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v15
	fmul.4s	v16, v16, v27
	fadd.4s	v25, v25, v15
	sshr.4s	v27, v20, #1
	shl.4s	v14, v27, #23
	add.4s	v14, v14, v15
	fmul.4s	v25, v25, v14
	sub.4s	v26, v13, v26
	sub.4s	v20, v20, v27
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v15
	fmul.4s	v20, v25, v20
	shl.4s	v25, v26, #23
	add.4s	v25, v25, v15
	fmul.4s	v16, v16, v25
	fcmgt.4s	v25, v31, v3
	bic.16b	v16, v16, v25
	mov.16b	v15, v31
	fcmgt.4s	v25, v31, v7
	bic.16b	v20, v20, v25
	fcmgt.4s	v25, v7, v8
	bit.16b	v20, v30, v25
	mov.16b	v26, v8
	fcmgt.4s	v25, v3, v8
	str	q30, [sp, #672]                 ; 16-byte Spill
	bit.16b	v16, v30, v25
	fcmeq.4s	v3, v3, v3
	mov.16b	v13, v3
	bsl.16b	v13, v16, v6
	fcmeq.4s	v3, v7, v7
	mov.16b	v14, v3
	bsl.16b	v14, v20, v6
	ldr	d25, [sp, #688]                 ; 8-byte Reload
	zip1.8b	v3, v25, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldp	q4, q2, [sp, #544]              ; 32-byte Folded Reload
	and.16b	v5, v3, v4
	zip2.8b	v3, v25, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v16, v3, v2
	zip1.8b	v3, v25, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldp	q4, q2, [sp, #480]              ; 32-byte Folded Reload
	and.16b	v19, v3, v4
	zip2.8b	v3, v25, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v20, v3, v2
	zip1.8b	v3, v25, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldp	q4, q2, [sp, #448]              ; 32-byte Folded Reload
	and.16b	v22, v3, v4
	zip2.8b	v3, v25, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v23, v3, v2
	zip1.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldp	q3, q2, [sp, #512]              ; 32-byte Folded Reload
	and.16b	v24, v4, v3
	zip2.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v27, v4, v2
	zip2.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldp	q3, q2, [sp, #576]              ; 32-byte Folded Reload
	and.16b	v18, v4, v3
	zip1.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v2, v4, v2
	mov	w3, #33792                      ; =0x8400
	movk	w3, #1, lsl #16
	add	x3, x10, x3
	ldp	q7, q4, [x3]
	ldr	q3, [sp, #3808]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	ldr	q3, [sp, #3824]                 ; 16-byte Reload
	bit.16b	v7, v3, v1
	stp	q7, q4, [x3]
	ldp	x3, x4, [sp, #152]              ; 16-byte Folded Reload
	ldp	q7, q4, [x4]
	ldr	q3, [sp, #3776]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	ldr	q3, [sp, #3792]                 ; 16-byte Reload
	bit.16b	v7, v3, v1
	stp	q7, q4, [x4]
	zip2.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q3, [sp, #608]                  ; 16-byte Reload
	and.16b	v21, v4, v3
	ldp	q7, q4, [x3]
	ldr	q3, [sp, #3744]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	ldr	q3, [sp, #3760]                 ; 16-byte Reload
	bit.16b	v7, v3, v1
	stp	q7, q4, [x3]
	zip1.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q3, [sp, #624]                  ; 16-byte Reload
	and.16b	v17, v4, v3
	ldp	x3, x5, [sp, #136]              ; 16-byte Folded Reload
	ldp	q7, q4, [x5]
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	ldr	q3, [sp, #1824]                 ; 16-byte Reload
	bit.16b	v7, v3, v1
	stp	q7, q4, [x5]
	zip2.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q3, [sp, #640]                  ; 16-byte Reload
	and.16b	v6, v4, v3
	ldp	q7, q4, [x3]
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	ldr	q3, [sp, #1792]                 ; 16-byte Reload
	bit.16b	v7, v3, v1
	stp	q7, q4, [x3]
	zip1.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q3, [sp, #656]                  ; 16-byte Reload
	and.16b	v7, v4, v3
	ldp	x3, x6, [sp, #120]              ; 16-byte Folded Reload
	ldr	q4, [x6, #16]
	stp	q16, q5, [sp, #640]             ; 32-byte Folded Spill
	bit.16b	v4, v16, v0
	ldr	q16, [x6]
	bit.16b	v16, v5, v1
	stp	q16, q4, [x6]
	ldp	q16, q4, [x3]
	stp	q20, q19, [sp, #608]            ; 32-byte Folded Spill
	bit.16b	v4, v20, v0
	bit.16b	v16, v19, v1
	stp	q16, q4, [x3]
	zip2.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldp	q5, q3, [sp, #416]              ; 32-byte Folded Reload
	and.16b	v20, v4, v5
	ldp	x3, x7, [sp, #104]              ; 16-byte Folded Reload
	ldp	q16, q4, [x7]
	stp	q23, q22, [sp, #576]            ; 32-byte Folded Spill
	bit.16b	v4, v23, v0
	bit.16b	v16, v22, v1
	stp	q16, q4, [x7]
	zip1.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v22, v4, v3
	ldp	q16, q4, [x3]
	bit.16b	v4, v27, v0
	str	q24, [sp, #560]                 ; 16-byte Spill
	bit.16b	v16, v24, v1
	stp	q16, q4, [x3]
	zip1.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldp	q5, q3, [sp, #384]              ; 32-byte Folded Reload
	and.16b	v23, v4, v5
	ldr	x3, [sp, #96]                   ; 8-byte Reload
	ldp	q4, q16, [x3]
	bit.16b	v4, v2, v1
	bit.16b	v16, v18, v0
	stp	q4, q16, [x3]
	zip2.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v24, v4, v3
	ldp	q4, q16, [x19]
	bit.16b	v4, v17, v1
	bit.16b	v16, v21, v0
	stp	q4, q16, [x19]
	ldp	q4, q16, [x20]
	bit.16b	v4, v7, v1
	bit.16b	v16, v6, v0
	stp	q4, q16, [x20]
	zip2.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v28, v4, v10
	ldp	q4, q16, [x21]
	bit.16b	v4, v22, v1
	bit.16b	v16, v20, v0
	stp	q4, q16, [x21]
	zip1.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v29, v4, v9
	ldp	q16, q4, [x22]
	bit.16b	v4, v24, v0
	bit.16b	v16, v23, v1
	stp	q16, q4, [x22]
	zip2.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v30, v4, v14
	ldp	q4, q16, [x23]
	bit.16b	v4, v29, v1
	bit.16b	v16, v28, v0
	stp	q4, q16, [x23]
	zip1.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v31, v4, v13
	ldp	q4, q16, [x24]
	bit.16b	v4, v31, v1
	bit.16b	v16, v30, v0
	stp	q4, q16, [x24]
	mov	x3, x13
	ldp	q13, q10, [sp, #352]            ; 32-byte Folded Reload
	ldr	q5, [sp, #1632]                 ; 16-byte Reload
LBB0_95:                                ; %direct.true2433
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_96 Depth 3
	mov	x4, #0                          ; =0x0
	umulh	x5, x2, x9
	lsr	x6, x5, #6
	add	x5, x25, x6, lsl #5
	madd	x6, x6, x1, x3
	and.16b	v12, v10, v12
	and.16b	v11, v13, v11
LBB0_96:                                ; %direct.true2436
                                        ;   Parent Loop BB0_22 Depth=1
                                        ;     Parent Loop BB0_95 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x7, x5, x4
	ldp	q4, q16, [x7]
	ldp	q25, q8, [x6]
	fmul.4s	v16, v16, v8
	fmul.4s	v4, v4, v25
	fadd.4s	v8, v11, v4
	fadd.4s	v9, v12, v16
	bit.16b	v12, v9, v0
	bit.16b	v11, v8, v1
	add	x4, x4, #32
	add	x6, x6, #3072
	cmp	x4, #512
	b.ne	LBB0_96
; %bb.97:                               ; %direct.false2437
                                        ;   in Loop: Header=BB0_95 Depth=2
	add	x4, x15, x2, lsl #5
	ldp	q4, q16, [x4]
	bit.16b	v16, v9, v0
	bit.16b	v4, v8, v1
	stp	q4, q16, [x4]
	add	x2, x2, #1
	add	x3, x3, #32
	cmp	x2, #96
	b.ne	LBB0_95
; %bb.98:                               ; %direct.schedule.79.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x2, #0                          ; =0x0
	ldr	q4, [sp, #3712]                 ; 16-byte Reload
	ldr	q3, [sp, #3840]                 ; 16-byte Reload
	fsub.4s	v9, v4, v3
	ldr	q4, [sp, #3696]                 ; 16-byte Reload
	ldr	q3, [sp, #3856]                 ; 16-byte Reload
	fsub.4s	v8, v4, v3
	and.16b	v8, v1, v8
	and.16b	v9, v0, v9
	mov.16b	v19, v15
	fcmge.4s	v10, v9, v15
	fcmge.4s	v13, v8, v15
	mov.16b	v3, v26
	fcmge.4s	v14, v26, v9
	fcmge.4s	v15, v26, v8
	and.16b	v13, v13, v15
	and.16b	v10, v10, v14
	and.16b	v10, v10, v9
	and.16b	v13, v13, v8
	ldr	q4, [sp, #784]                  ; 16-byte Reload
	fmul.4s	v14, v13, v4
	fmul.4s	v15, v10, v4
	movi.4s	v4, #75, lsl #24
	mvni.4s	v25, #128, lsl #24
	mov.16b	v16, v25
	bsl.16b	v16, v4, v15
	bsl.16b	v25, v4, v14
	fadd.4s	v14, v14, v25
	fadd.4s	v15, v15, v16
	fsub.4s	v16, v15, v16
	fsub.4s	v25, v14, v25
	fcvtzs.4s	v25, v25
	fcvtzs.4s	v16, v16
	scvtf.4s	v14, v16
	mov	w3, #29184                      ; =0x7200
	movk	w3, #48945, lsl #16
	dup.4s	v15, w3
	fmul.4s	v4, v14, v15
	fadd.4s	v4, v10, v4
	scvtf.4s	v10, v25
	fmul.4s	v15, v10, v15
	fadd.4s	v13, v13, v15
	mov	w3, #48782                      ; =0xbe8e
	movk	w3, #46527, lsl #16
	dup.4s	v15, w3
	fmul.4s	v14, v14, v15
	fmul.4s	v10, v10, v15
	fadd.4s	v10, v13, v10
	fadd.4s	v4, v4, v14
	ldr	q26, [sp, #768]                 ; 16-byte Reload
	fmul.4s	v13, v4, v26
	fmul.4s	v14, v10, v26
	ldr	q26, [sp, #752]                 ; 16-byte Reload
	fadd.4s	v14, v14, v26
	fadd.4s	v13, v13, v26
	fmul.4s	v13, v4, v13
	fmul.4s	v14, v10, v14
	ldr	q26, [sp, #736]                 ; 16-byte Reload
	fadd.4s	v14, v14, v26
	fadd.4s	v13, v13, v26
	fmul.4s	v13, v4, v13
	fmul.4s	v14, v10, v14
	ldr	q26, [sp, #720]                 ; 16-byte Reload
	fadd.4s	v14, v14, v26
	fadd.4s	v13, v13, v26
	fmul.4s	v13, v4, v13
	fmul.4s	v14, v10, v14
	ldr	q26, [sp, #704]                 ; 16-byte Reload
	fadd.4s	v14, v14, v26
	fadd.4s	v13, v13, v26
	fmul.4s	v13, v4, v13
	fmul.4s	v14, v10, v14
	movi.4s	v15, #63, lsl #24
	fadd.4s	v14, v14, v15
	fadd.4s	v13, v13, v15
	fmul.4s	v15, v4, v4
	fmul.4s	v13, v15, v13
	fmul.4s	v15, v10, v10
	fmul.4s	v14, v15, v14
	fadd.4s	v10, v10, v14
	fadd.4s	v4, v4, v13
	fmov.4s	v26, #1.00000000
	fadd.4s	v4, v4, v26
	fadd.4s	v10, v10, v26
	sshr.4s	v13, v16, #1
	sshr.4s	v14, v25, #1
	shl.4s	v15, v14, #23
	add.4s	v15, v15, v26
	fmul.4s	v10, v10, v15
	shl.4s	v15, v13, #23
	add.4s	v15, v15, v26
	fmul.4s	v4, v4, v15
	sub.4s	v25, v25, v14
	sub.4s	v16, v16, v13
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v26
	fmul.4s	v4, v4, v16
	shl.4s	v16, v25, #23
	add.4s	v16, v16, v26
	fmul.4s	v16, v10, v16
	fcmgt.4s	v25, v19, v8
	bic.16b	v16, v16, v25
	fcmgt.4s	v25, v19, v9
	bic.16b	v4, v4, v25
	fcmgt.4s	v25, v9, v3
	ldr	q19, [sp, #672]                 ; 16-byte Reload
	bit.16b	v4, v19, v25
	fcmgt.4s	v25, v8, v3
	bit.16b	v16, v19, v25
	fcmeq.4s	v25, v8, v8
	ldr	q26, [sp, #1712]                ; 16-byte Reload
	mov.16b	v8, v25
	bsl.16b	v8, v16, v26
	fcmeq.4s	v16, v9, v9
	mov.16b	v9, v16
	bsl.16b	v9, v4, v26
	sshll.2d	v4, v0, #0
	ldr	q16, [sp, #1664]                ; 16-byte Reload
	ldr	q3, [sp, #1552]                 ; 16-byte Reload
	bit.16b	v16, v3, v4
	str	q16, [sp, #1664]                ; 16-byte Spill
	sshll.2d	v4, v1, #0
	ldr	q26, [sp, #1696]                ; 16-byte Reload
	ldr	q3, [sp, #1728]                 ; 16-byte Reload
	bit.16b	v26, v3, v4
	mov.16b	v3, v0
	bsl.16b	v3, v9, v5
	ldr	q5, [sp, #848]                  ; 16-byte Reload
	bit.16b	v5, v8, v1
	ldr	q4, [sp, #1648]                 ; 16-byte Reload
	ldr	q16, [sp, #1600]                ; 16-byte Reload
	ldr	q25, [sp, #4080]                ; 16-byte Reload
	bit.16b	v4, v16, v25
	str	q4, [sp, #1648]                 ; 16-byte Spill
	ldr	q4, [sp, #1680]                 ; 16-byte Reload
	ldr	q16, [sp, #1568]                ; 16-byte Reload
	ldr	q25, [sp, #4096]                ; 16-byte Reload
	bit.16b	v4, v16, v25
	str	q4, [sp, #1680]                 ; 16-byte Spill
	ldr	q15, [sp, #336]                 ; 16-byte Reload
LBB0_99:                                ; %direct.true2463
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	d4, x2
	orr.16b	v16, v4, v15
	fmov	x3, d16
	add	x4, x8, x3
	ldp	q25, q16, [x4]
	and.16b	v25, v1, v25
	and.16b	v16, v0, v16
	fmul.4s	v16, v3, v16
	fmul.4s	v25, v5, v25
	orr.16b	v4, v4, v26
	fmov	x4, d4
	add	x4, x15, x4
	ldp	q10, q4, [x4]
	fadd.4s	v25, v10, v25
	fadd.4s	v4, v4, v16
	add	x3, x11, x3
	ldp	q16, q10, [x3]
	bif.16b	v4, v10, v0
	bit.16b	v16, v25, v1
	stp	q16, q4, [x3]
	add	x2, x2, #32
	cmp	x2, #3072
	b.ne	LBB0_99
; %bb.100:                              ; %direct.true2485.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q26, [sp, #1696]                ; 16-byte Spill
	str	q3, [sp, #1632]                 ; 16-byte Spill
	mov.16b	v15, v5
	mov	x2, x10
	mov	w3, #96                         ; =0x60
	ldr	q13, [sp, #2064]                ; 16-byte Reload
	ldr	q14, [sp, #2048]                ; 16-byte Reload
	ldr	q26, [sp, #2032]                ; 16-byte Reload
LBB0_101:                               ; %direct.true2485
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x2, #5632]
	ldr	q16, [x2, #5648]
	ldr	q25, [x2, #2560]
	ldr	q10, [x2, #2576]
	bif.16b	v16, v10, v0
	bif.16b	v4, v25, v1
	str	q4, [x2, #2560]
	str	q16, [x2, #2576]
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_101
; %bb.102:                              ; %direct.false2486
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q4, [sp, #3712]                 ; 16-byte Reload
	ldr	q3, [sp, #3840]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #3712]                 ; 16-byte Spill
	ldr	q4, [sp, #3696]                 ; 16-byte Reload
	ldr	q3, [sp, #3856]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #3696]                 ; 16-byte Spill
	movi.2d	v16, #0000000000000000
	ldr	q3, [sp, #3824]                 ; 16-byte Reload
	fadd.4s	v4, v3, v16
	ldr	q3, [sp, #3792]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #3808]                 ; 16-byte Reload
	fadd.4s	v16, v3, v16
	ldr	q3, [sp, #3776]                 ; 16-byte Reload
	fadd.4s	v16, v16, v3
	ldr	q3, [sp, #3744]                 ; 16-byte Reload
	fadd.4s	v16, v16, v3
	ldr	q3, [sp, #3760]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #1824]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	fadd.4s	v16, v16, v3
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	fadd.4s	v16, v16, v3
	ldr	q3, [sp, #1792]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldp	q3, q5, [sp, #640]              ; 32-byte Folded Reload
	fadd.4s	v4, v4, v5
	fadd.4s	v16, v16, v3
	ldp	q5, q3, [sp, #608]              ; 32-byte Folded Reload
	fadd.4s	v16, v16, v5
	fadd.4s	v4, v4, v3
	ldp	q3, q5, [sp, #576]              ; 32-byte Folded Reload
	fadd.4s	v4, v4, v5
	fadd.4s	v3, v16, v3
	fadd.4s	v3, v3, v27
	ldr	q5, [sp, #560]                  ; 16-byte Reload
	fadd.4s	v4, v4, v5
	fadd.4s	v2, v4, v2
	fadd.4s	v3, v3, v18
	fadd.4s	v3, v3, v21
	fadd.4s	v2, v2, v17
	fadd.4s	v2, v2, v7
	fadd.4s	v3, v3, v6
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v22
	fadd.4s	v2, v2, v23
	fadd.4s	v3, v3, v24
	fadd.4s	v3, v3, v28
	fadd.4s	v2, v2, v29
	fadd.4s	v2, v2, v31
	fadd.4s	v3, v3, v30
	ldr	q7, [sp, #1760]                 ; 16-byte Reload
	fmul.4s	v4, v7, v8
	ldr	q6, [sp, #1744]                 ; 16-byte Reload
	fmul.4s	v5, v6, v9
	fadd.4s	v3, v5, v3
	fadd.4s	v2, v4, v2
	add	x0, x0, #1
	bit.16b	v7, v2, v1
	str	q7, [sp, #1760]                 ; 16-byte Spill
	bit.16b	v6, v3, v0
	str	q6, [sp, #1744]                 ; 16-byte Spill
	ldr	q2, [sp, #800]                  ; 16-byte Reload
	cmp	x0, #129
	ldr	q19, [sp, #304]                 ; 16-byte Reload
	mov.16b	v16, v15
	ldr	q17, [sp, #3680]                ; 16-byte Reload
	ldr	q4, [sp, #3664]                 ; 16-byte Reload
	ldr	q5, [sp, #3648]                 ; 16-byte Reload
	ldr	q6, [sp, #3632]                 ; 16-byte Reload
	ldr	q7, [sp, #3616]                 ; 16-byte Reload
	ldr	q30, [sp, #2080]                ; 16-byte Reload
	ldr	q18, [sp, #3728]                ; 16-byte Reload
	ldr	q21, [sp, #2016]                ; 16-byte Reload
	ldr	q27, [sp, #2000]                ; 16-byte Reload
	ldr	q15, [sp, #1984]                ; 16-byte Reload
	ldr	q10, [sp, #1968]                ; 16-byte Reload
	ldr	q25, [sp, #1952]                ; 16-byte Reload
	ldr	q28, [sp, #1936]                ; 16-byte Reload
	ldp	q22, q8, [sp, #816]             ; 32-byte Folded Reload
	ldr	q20, [sp, #1920]                ; 16-byte Reload
	ldr	q31, [sp, #1904]                ; 16-byte Reload
	ldr	q9, [sp, #1888]                 ; 16-byte Reload
	ldr	q24, [sp, #1872]                ; 16-byte Reload
	ldr	q23, [sp, #1856]                ; 16-byte Reload
	ldr	q29, [sp, #1840]                ; 16-byte Reload
	b.ne	LBB0_22
; %bb.103:                              ; %direct.schedule.86.preheader
	mov	x9, #0                          ; =0x0
	ldp	q2, q4, [sp, #16]               ; 32-byte Folded Reload
	xtn.2s	v2, v2
	movi.2s	v5, #96
	umull.2d	v2, v2, v5
	ldp	q3, q6, [sp, #48]               ; 32-byte Folded Reload
	xtn.2s	v3, v3
	umull.2d	v3, v3, v5
	xtn.2s	v4, v4
	umull.2d	v4, v4, v5
	xtn.2s	v6, v6
	umull.2d	v5, v6, v5
	ldr	x12, [sp, #88]                  ; 8-byte Reload
	ldr	q19, [sp, #1760]                ; 16-byte Reload
	ldr	q20, [sp, #1744]                ; 16-byte Reload
	b	LBB0_105
LBB0_104:                               ; %else619
                                        ;   in Loop: Header=BB0_105 Depth=1
	add	x9, x9, #1
	cmp	x9, #96
	b.eq	LBB0_121
LBB0_105:                               ; %direct.true2504
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q6, [sp, #3872]                 ; 16-byte Reload
	fmov	w10, s6
	dup.2d	v6, x9
	add.2d	v7, v6, v2
	add	x11, x8, x9, lsl #5
	ldp	q17, q16, [x11]
	and.16b	v17, v1, v17
	fdiv.4s	v17, v17, v19
	shl.2d	v18, v7, #2
	dup.2d	v7, x12
	add.2d	v18, v7, v18
	tbz	w10, #0, LBB0_113
; %bb.106:                              ; %cond.store
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x11, d18
	str	s17, [x11]
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_114
LBB0_107:                               ; %else601
                                        ;   in Loop: Header=BB0_105 Depth=1
	add.2d	v18, v6, v3
	shl.2d	v18, v18, #2
	add.2d	v18, v7, v18
	tbz	w10, #2, LBB0_115
LBB0_108:                               ; %cond.store602
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x11, d18
	st1.s	{ v17 }[2], [x11]
	tbnz	w10, #3, LBB0_116
LBB0_109:                               ; %else607
                                        ;   in Loop: Header=BB0_105 Depth=1
	add.2d	v17, v6, v4
	and.16b	v16, v0, v16
	fdiv.4s	v16, v16, v20
	shl.2d	v17, v17, #2
	add.2d	v17, v7, v17
	tbz	w10, #4, LBB0_117
LBB0_110:                               ; %cond.store608
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x11, d17
	str	s16, [x11]
	tbnz	w10, #5, LBB0_118
LBB0_111:                               ; %else613
                                        ;   in Loop: Header=BB0_105 Depth=1
	add.2d	v6, v6, v5
	shl.2d	v6, v6, #2
	add.2d	v6, v7, v6
	tbz	w10, #6, LBB0_119
LBB0_112:                               ; %cond.store614
                                        ;   in Loop: Header=BB0_105 Depth=1
	fmov	x11, d6
	st1.s	{ v16 }[2], [x11]
	tbz	w10, #7, LBB0_104
	b	LBB0_120
LBB0_113:                               ; %else598
                                        ;   in Loop: Header=BB0_105 Depth=1
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_107
LBB0_114:                               ; %cond.store599
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x11, v18[1]
	st1.s	{ v17 }[1], [x11]
	add.2d	v18, v6, v3
	shl.2d	v18, v18, #2
	add.2d	v18, v7, v18
	tbnz	w10, #2, LBB0_108
LBB0_115:                               ; %else604
                                        ;   in Loop: Header=BB0_105 Depth=1
	tbz	w10, #3, LBB0_109
LBB0_116:                               ; %cond.store605
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x11, v18[1]
	st1.s	{ v17 }[3], [x11]
	add.2d	v17, v6, v4
	and.16b	v16, v0, v16
	fdiv.4s	v16, v16, v20
	shl.2d	v17, v17, #2
	add.2d	v17, v7, v17
	tbnz	w10, #4, LBB0_110
LBB0_117:                               ; %else610
                                        ;   in Loop: Header=BB0_105 Depth=1
	tbz	w10, #5, LBB0_111
LBB0_118:                               ; %cond.store611
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x11, v17[1]
	st1.s	{ v16 }[1], [x11]
	add.2d	v6, v6, v5
	shl.2d	v6, v6, #2
	add.2d	v6, v7, v6
	tbnz	w10, #6, LBB0_112
LBB0_119:                               ; %else616
                                        ;   in Loop: Header=BB0_105 Depth=1
	tbz	w10, #7, LBB0_104
LBB0_120:                               ; %cond.store617
                                        ;   in Loop: Header=BB0_105 Depth=1
	mov.d	x10, v6[1]
	st1.s	{ v16 }[3], [x10]
	b	LBB0_104
LBB0_121:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #64
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_122:                               ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

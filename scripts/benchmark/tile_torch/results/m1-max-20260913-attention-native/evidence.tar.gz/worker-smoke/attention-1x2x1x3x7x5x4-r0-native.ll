; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [46 x i32] [i32 2, i32 4, i32 6, i32 8, i32 10, i32 103, i32 14, i32 16, i32 18, i32 20, i32 22, i32 24, i32 26, i32 28, i32 30, i32 32, i32 34, i32 36, i32 38, i32 40, i32 42, i32 44, i32 46, i32 48, i32 51, i32 54, i32 57, i32 60, i32 63, i32 66, i32 69, i32 72, i32 75, i32 78, i32 81, i32 84, i32 87, i32 90, i32 93, i32 96, i32 99, i32 102, i32 105, i32 107, i32 109, i32 111], align 4

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %tile_snapshot.local = alloca [960 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [192 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [192 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [768 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill10 = alloca i64, align 8
  store i64 0, ptr %.spill10, align 4
  %.spill11 = alloca i64, align 8
  store i64 0, ptr %.spill11, align 4
  %.spill12 = alloca i64, align 8
  store volatile i64 0, ptr %.spill12, align 4
  %.spill13 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill13, align 64
  %.spill14 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill14, align 64
  %.spill15 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill15, align 32
  %.spill16 = alloca i64, align 8
  store i64 0, ptr %.spill16, align 4
  %.spill17 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill17, align 32
  %.spill18 = alloca i64, align 8
  store i64 0, ptr %.spill18, align 4
  %.spill19 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill19, align 32
  %.spill20 = alloca i64, align 8
  store i64 0, ptr %.spill20, align 4
  %.spill21 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill21, align 32
  %.spill22 = alloca i64, align 8
  store volatile i64 0, ptr %.spill22, align 4
  %.spill23 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill23, align 32
  %.spill24 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill24, align 64
  %.spill25 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill25, align 64
  %.spill26 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill26, align 1
  %.spill27 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill27, align 64
  %.spill28 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill28, align 64
  %.slot = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot, align 32
  %.spill29 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill29, align 64
  %.slot30 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot30, align 32
  %.spill31 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill31, align 64
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.spill33 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill33, align 64
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.spill35 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill35, align 64
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.slot37 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot37, align 64
  %.slot38 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot38, align 32
  %.slot39 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot39, align 32
  %.slot40 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot40, align 32
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot46, align 32
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.spill50 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill50, align 64
  %.spill51 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill51, align 64
  %.spill52 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill52, align 64
  %.spill53 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill53, align 64
  %.spill54 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill54, align 32
  %.spill55 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill55, align 32
  %.spill56 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill56, align 32
  %.spill57 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill57, align 32
  %.spill58 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill58, align 32
  %.spill59 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill59, align 64
  %.spill60 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill60, align 64
  %.spill61 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill61, align 1
  %.spill62 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill62, align 1
  %.spill63 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill63, align 64
  %.spill64 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill64, align 64
  %.slot65 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot65, align 32
  %.spill66 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill66, align 64
  %.slot67 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot67, align 32
  %.spill68 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill68, align 64
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.spill70 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill70, align 64
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.spill72 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill72, align 64
  %.slot73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot73, align 32
  %.spill74 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill74, align 64
  %.spill75 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill75, align 64
  %.spill76 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill76, align 1
  %.spill77 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill77, align 1
  %.spill78 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill78, align 64
  %.spill79 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill79, align 64
  %.slot80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot80, align 32
  %.spill81 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill81, align 64
  %.slot82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot82, align 32
  %.spill83 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill83, align 64
  %.slot84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot84, align 32
  %.spill85 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill85, align 64
  %.slot86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot86, align 32
  %.spill87 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill87, align 64
  %.slot88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot88, align 32
  %.spill89 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill89, align 32
  %.spill90 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill90, align 32
  %.spill91 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill91, align 32
  %.spill92 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill92, align 32
  %.spill93 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill93, align 64
  %.spill94 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill94, align 64
  %.slot95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot95, align 32
  %.spill96 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill96, align 64
  %.slot97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot97, align 32
  %.spill98 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill98, align 64
  %.slot99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot99, align 32
  %.spill100 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill100, align 64
  %.slot101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot101, align 32
  %.spill102 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill102, align 64
  %.spill103 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill103, align 64
  %.slot104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot104, align 32
  %.spill105 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill105, align 64
  %.slot106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot106, align 32
  %.spill107 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill107, align 64
  %.slot108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot108, align 32
  %.spill109 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill109, align 64
  %.slot110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot110, align 32
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot111 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot111, align 64
  %.slot112 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot112, align 32
  %.slot113 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot113, align 64
  %.slot114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot114, align 32
  %.slot115 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot115, align 64
  %.slot116 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot116, align 32
  %.slot117 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot117, align 64
  %.slot118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot118, align 32
  %.slot119 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot119, align 64
  %.slot120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot120, align 32
  %.slot121 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot121, align 64
  %.slot122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot122, align 32
  %.spill123 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill123, align 1
  %.spill124 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill124, align 1
  %.spill125 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill125, align 1
  %.spill126 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill126, align 1
  %.spill127 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill127, align 1
  %.spill128 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill128, align 1
  %.spill129 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill129, align 32
  %.spill130 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill130, align 32
  %.spill131 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill131, align 32
  %.spill132 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill132, align 32
  %.spill133 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill133, align 32
  %.spill134 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill134, align 32
  %tile_snapshot.spill135 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill135, align 64
  %.slot136 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot136, align 64
  %.slot137 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot137, align 32
  %.slot138 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot138, align 64
  %.slot139 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot139, align 32
  %.spill140 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill140, align 32
  %.spill141 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill141, align 32
  %.spill142 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill142, align 32
  %.spill143 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill143, align 32
  %.spill144 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill144, align 32
  %.spill145 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill145, align 32
  %.spill146 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill146, align 32
  %.spill147 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill147, align 32
  %.spill148 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill148, align 32
  %.spill149 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill149, align 32
  %tile_snapshot.spill150 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill150, align 64
  %.spill151 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill151, align 32
  %.spill152 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill152, align 32
  %.slot153 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot153, align 64
  %.slot154 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot154, align 32
  %.slot155 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot155, align 64
  %.slot156 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot156, align 32
  %.spill157 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill157, align 32
  %.spill158 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill158, align 32
  %.spill159 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill159, align 32
  %.spill160 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill160, align 32
  %.spill161 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill161, align 32
  %.spill162 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill162, align 32
  %.spill163 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill163, align 32
  %.spill164 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill164, align 32
  %.spill165 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill165, align 32
  %.spill166 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill166, align 32
  %tile_snapshot.spill167 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill167, align 64
  %.slot168 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot168, align 64
  %.slot169 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot169, align 32
  %.slot170 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot170, align 64
  %.slot171 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot171, align 32
  %.slot172 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot172, align 64
  %.slot173 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot173, align 32
  %.slot174 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot174, align 64
  %.slot175 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot175, align 32
  %.slot176 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot176, align 64
  %.slot177 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot177, align 32
  %.slot178 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot178, align 64
  %.slot179 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot179, align 32
  %.slot180 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot180, align 64
  %.slot181 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot181, align 32
  %.slot182 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot182, align 64
  %.slot183 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot183, align 32
  %.spill184 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill184, align 32
  %.spill185 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill185, align 32
  %.spill186 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill186, align 32
  %.spill187 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill187, align 32
  %.spill188 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill188, align 64
  %.spill189 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill189, align 64
  %.spill190 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill190, align 64
  %.spill191 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill191, align 64
  %.spill192 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill192, align 64
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert193 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat194 = shufflevector <8 x i32> %.splatinsert193, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat194, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert195 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat196 = shufflevector <8 x i32> %.splatinsert195, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat196, %45
  %48 = mul i32 %36, 1
  %.splatinsert197 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat198 = shufflevector <8 x i32> %.splatinsert197, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat198, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert199 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat200 = shufflevector <8 x i32> %.splatinsert199, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat200, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert201 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat202 = shufflevector <8 x i32> %.splatinsert201, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat202
  store <8 x i1> %55, ptr %live.mask, align 1
  %56 = load i32, ptr %current.token, align 4
  %57 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %58 = load i32, ptr %ready.count, align 4
  %59 = icmp uge i32 %58, 8
  %60 = and i1 %57, %59
  br i1 %60, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %61 = select i1 %57, i32 %58, i32 0
  %62 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %61
  %63 = load <8 x i1>, ptr %62, align 1
  %64 = select i1 %57, <8 x i1> %55, <8 x i1> %63
  store <8 x i1> %64, ptr %62, align 1
  %65 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %61
  %66 = load i32, ptr %65, align 4
  %67 = select i1 %57, i32 0, i32 %66
  store i32 %67, ptr %65, align 4
  %68 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %61
  %69 = load i32, ptr %68, align 4
  %70 = select i1 %57, i32 %56, i32 %69
  store i32 %70, ptr %68, align 4
  %71 = add i32 %58, 1
  %72 = select i1 %57, i32 %71, i32 %58
  store i32 %72, ptr %ready.count, align 4
  %73 = load <8 x i1>, ptr %runnable.mask, align 1
  %74 = or <8 x i1> %73, %55
  store <8 x i1> %74, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit2008, %schedule.110, %varying.coherent.false2004, %varying.coherent.true2003, %convergence.cascade.exit1976, %schedule.108, %varying.coherent.false1972, %varying.coherent.true1971, %convergence.cascade.exit1944, %schedule.106, %varying.coherent.false1940, %varying.coherent.true1939, %convergence.cascade.exit1912, %schedule.104, %varying.coherent.false1908, %varying.coherent.true1907, %convergence.cascade.exit1851, %convergence.target.102.ready, %convergence.cascade.exit1813, %schedule.101, %varying.coherent.false1804, %varying.coherent.true1803, %convergence.target.99.ready, %convergence.cascade.exit1780, %schedule.98, %varying.coherent.false1771, %varying.coherent.true1770, %convergence.target.96.ready, %convergence.cascade.exit1747, %schedule.95, %varying.coherent.false1738, %varying.coherent.true1737, %convergence.target.93.ready, %convergence.cascade.exit1714, %schedule.92, %varying.coherent.false1705, %varying.coherent.true1704, %convergence.target.90.ready, %convergence.cascade.exit1681, %schedule.89, %varying.coherent.false1672, %varying.coherent.true1671, %convergence.target.87.ready, %convergence.cascade.exit1648, %schedule.86, %varying.coherent.false1639, %varying.coherent.true1638, %convergence.target.84.ready, %convergence.cascade.exit1615, %schedule.83, %varying.coherent.false1606, %varying.coherent.true1605, %convergence.target.81.ready, %convergence.cascade.exit1582, %schedule.80, %varying.coherent.false1573, %varying.coherent.true1572, %convergence.target.78.ready, %convergence.cascade.exit1433, %schedule.77, %varying.coherent.false1424, %varying.coherent.true1423, %convergence.target.75.ready, %convergence.cascade.exit1400, %schedule.74, %varying.coherent.false1391, %varying.coherent.true1390, %convergence.target.72.ready, %convergence.cascade.exit1328, %schedule.71, %varying.coherent.false1319, %varying.coherent.true1318, %convergence.target.69.ready, %convergence.cascade.exit1295, %schedule.68, %varying.coherent.false1286, %varying.coherent.true1285, %convergence.target.66.ready, %convergence.cascade.exit1231, %schedule.65, %varying.coherent.false1222, %varying.coherent.true1221, %convergence.target.63.ready, %convergence.cascade.exit1198, %schedule.62, %varying.coherent.false1189, %varying.coherent.true1188, %convergence.target.60.ready, %convergence.cascade.exit1165, %schedule.59, %varying.coherent.false1156, %varying.coherent.true1155, %convergence.target.57.ready, %convergence.cascade.exit1132, %schedule.56, %varying.coherent.false1123, %varying.coherent.true1122, %convergence.target.54.ready, %convergence.cascade.exit1099, %schedule.53, %varying.coherent.false1090, %varying.coherent.true1089, %convergence.target.51.ready, %convergence.cascade.exit1066, %schedule.50, %varying.coherent.false1058, %varying.coherent.true1057, %convergence.target.48.ready, %convergence.cascade.exit916, %schedule.47, %varying.coherent.false913, %varying.coherent.true912, %convergence.cascade.exit885, %schedule.45, %varying.coherent.false882, %varying.coherent.true881, %convergence.cascade.exit854, %schedule.43, %varying.coherent.false851, %varying.coherent.true850, %convergence.cascade.exit823, %schedule.41, %varying.coherent.false820, %varying.coherent.true819, %convergence.cascade.exit792, %schedule.39, %varying.coherent.false789, %varying.coherent.true788, %convergence.cascade.exit761, %schedule.37, %varying.coherent.false758, %varying.coherent.true757, %convergence.cascade.exit730, %schedule.35, %varying.coherent.false727, %varying.coherent.true726, %convergence.cascade.exit699, %schedule.33, %varying.coherent.false696, %varying.coherent.true695, %convergence.cascade.exit655, %schedule.31, %varying.coherent.false652, %varying.coherent.true651, %convergence.cascade.exit624, %schedule.29, %varying.coherent.false621, %varying.coherent.true620, %convergence.cascade.exit593, %schedule.27, %varying.coherent.false590, %varying.coherent.true589, %convergence.cascade.exit562, %schedule.25, %varying.coherent.false559, %varying.coherent.true558, %convergence.cascade.exit531, %schedule.23, %varying.coherent.false528, %varying.coherent.true527, %convergence.cascade.exit500, %schedule.21, %varying.coherent.false497, %varying.coherent.true496, %convergence.cascade.exit469, %schedule.19, %varying.coherent.false466, %varying.coherent.true465, %convergence.cascade.exit438, %schedule.17, %varying.coherent.false435, %varying.coherent.true434, %convergence.cascade.exit407, %schedule.15, %varying.coherent.false404, %varying.coherent.true403, %convergence.cascade.exit376, %schedule.13, %varying.coherent.false373, %varying.coherent.true372, %varying.coherent.false342, %varying.coherent.true341, %convergence.target.10.ready, %convergence.cascade.exit319, %schedule.9, %varying.coherent.false316, %varying.coherent.true315, %convergence.cascade.exit288, %schedule.7, %varying.coherent.false285, %varying.coherent.true284, %convergence.cascade.exit257, %schedule.5, %varying.coherent.false254, %varying.coherent.true253, %convergence.cascade.exit226, %schedule.3, %varying.coherent.false223, %varying.coherent.true222, %convergence.cascade.exit, %schedule.1, %varying.coherent.false, %varying.coherent.true, %ready.overflow.resume
  %75 = load i32, ptr %ready.count, align 4
  %76 = icmp ne i32 %75, 0
  br i1 %76, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %77 = sub i32 %75, 1
  store i32 %77, ptr %ready.count, align 4
  %78 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %77
  %79 = load <8 x i1>, ptr %78, align 1
  store <8 x i1> %79, ptr %current.mask, align 1
  %80 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %77
  %81 = load i32, ptr %80, align 4
  %82 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %77
  %83 = load i32, ptr %82, align 4
  store i32 %83, ptr %current.token, align 4
  %84 = load <8 x i1>, ptr %runnable.mask, align 1
  %85 = xor <8 x i1> %79, splat (i1 true)
  %86 = and <8 x i1> %84, %85
  store <8 x i1> %86, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume2002, %ready.overflow.resume1970, %ready.overflow.resume1938, %ready.overflow.resume1906, %ready.overflow.resume1802, %ready.overflow.resume1769, %ready.overflow.resume1736, %ready.overflow.resume1703, %ready.overflow.resume1670, %ready.overflow.resume1637, %ready.overflow.resume1604, %ready.overflow.resume1571, %ready.overflow.resume1422, %ready.overflow.resume1389, %ready.overflow.resume1317, %ready.overflow.resume1284, %ready.overflow.resume1220, %ready.overflow.resume1187, %ready.overflow.resume1154, %ready.overflow.resume1121, %ready.overflow.resume1088, %ready.overflow.resume1056, %ready.overflow.resume911, %ready.overflow.resume880, %ready.overflow.resume849, %ready.overflow.resume818, %ready.overflow.resume787, %ready.overflow.resume756, %ready.overflow.resume725, %ready.overflow.resume694, %ready.overflow.resume650, %ready.overflow.resume619, %ready.overflow.resume588, %ready.overflow.resume557, %ready.overflow.resume526, %ready.overflow.resume495, %ready.overflow.resume464, %ready.overflow.resume433, %ready.overflow.resume402, %ready.overflow.resume371, %ready.overflow.resume340, %ready.overflow.resume314, %ready.overflow.resume283, %ready.overflow.resume252, %ready.overflow.resume221, %ready.overflow.resume204, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %81, %scheduler.dispatch ], [ 2, %ready.overflow.resume204 ], [ 4, %ready.overflow.resume221 ], [ 6, %ready.overflow.resume252 ], [ 8, %ready.overflow.resume283 ], [ 10, %ready.overflow.resume314 ], [ 103, %ready.overflow.resume340 ], [ 14, %ready.overflow.resume371 ], [ 16, %ready.overflow.resume402 ], [ 18, %ready.overflow.resume433 ], [ 20, %ready.overflow.resume464 ], [ 22, %ready.overflow.resume495 ], [ 24, %ready.overflow.resume526 ], [ 26, %ready.overflow.resume557 ], [ 28, %ready.overflow.resume588 ], [ 30, %ready.overflow.resume619 ], [ 32, %ready.overflow.resume650 ], [ 34, %ready.overflow.resume694 ], [ 36, %ready.overflow.resume725 ], [ 38, %ready.overflow.resume756 ], [ 40, %ready.overflow.resume787 ], [ 42, %ready.overflow.resume818 ], [ 44, %ready.overflow.resume849 ], [ 46, %ready.overflow.resume880 ], [ 48, %ready.overflow.resume911 ], [ 51, %ready.overflow.resume1056 ], [ 54, %ready.overflow.resume1088 ], [ 57, %ready.overflow.resume1121 ], [ 60, %ready.overflow.resume1154 ], [ 63, %ready.overflow.resume1187 ], [ 66, %ready.overflow.resume1220 ], [ 69, %ready.overflow.resume1284 ], [ 72, %ready.overflow.resume1317 ], [ 75, %ready.overflow.resume1389 ], [ 78, %ready.overflow.resume1422 ], [ 81, %ready.overflow.resume1571 ], [ 84, %ready.overflow.resume1604 ], [ 87, %ready.overflow.resume1637 ], [ 90, %ready.overflow.resume1670 ], [ 93, %ready.overflow.resume1703 ], [ 96, %ready.overflow.resume1736 ], [ 99, %ready.overflow.resume1769 ], [ 102, %ready.overflow.resume1802 ], [ 105, %ready.overflow.resume1906 ], [ 107, %ready.overflow.resume1938 ], [ 109, %ready.overflow.resume1970 ], [ 111, %ready.overflow.resume2002 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
    i32 24, label %schedule.24
    i32 25, label %schedule.25
    i32 26, label %schedule.26
    i32 27, label %schedule.27
    i32 28, label %schedule.28
    i32 29, label %schedule.29
    i32 30, label %schedule.30
    i32 31, label %schedule.31
    i32 32, label %schedule.32
    i32 33, label %schedule.33
    i32 34, label %schedule.34
    i32 35, label %schedule.35
    i32 36, label %schedule.36
    i32 37, label %schedule.37
    i32 38, label %schedule.38
    i32 39, label %schedule.39
    i32 40, label %schedule.40
    i32 41, label %schedule.41
    i32 42, label %schedule.42
    i32 43, label %schedule.43
    i32 44, label %schedule.44
    i32 45, label %schedule.45
    i32 46, label %schedule.46
    i32 47, label %schedule.47
    i32 48, label %schedule.48
    i32 49, label %schedule.49
    i32 50, label %schedule.50
    i32 51, label %schedule.51
    i32 52, label %schedule.52
    i32 53, label %schedule.53
    i32 54, label %schedule.54
    i32 55, label %schedule.55
    i32 56, label %schedule.56
    i32 57, label %schedule.57
    i32 58, label %schedule.58
    i32 59, label %schedule.59
    i32 60, label %schedule.60
    i32 61, label %schedule.61
    i32 62, label %schedule.62
    i32 63, label %schedule.63
    i32 64, label %schedule.64
    i32 65, label %schedule.65
    i32 66, label %schedule.66
    i32 67, label %schedule.67
    i32 68, label %schedule.68
    i32 69, label %schedule.69
    i32 70, label %schedule.70
    i32 71, label %schedule.71
    i32 72, label %schedule.72
    i32 73, label %schedule.73
    i32 74, label %schedule.74
    i32 75, label %schedule.75
    i32 76, label %schedule.76
    i32 77, label %schedule.77
    i32 78, label %schedule.78
    i32 79, label %schedule.79
    i32 80, label %schedule.80
    i32 81, label %schedule.81
    i32 82, label %schedule.82
    i32 83, label %schedule.83
    i32 84, label %schedule.84
    i32 85, label %schedule.85
    i32 86, label %schedule.86
    i32 87, label %schedule.87
    i32 88, label %schedule.88
    i32 89, label %schedule.89
    i32 90, label %schedule.90
    i32 91, label %schedule.91
    i32 92, label %schedule.92
    i32 93, label %schedule.93
    i32 94, label %schedule.94
    i32 95, label %schedule.95
    i32 96, label %schedule.96
    i32 97, label %schedule.97
    i32 98, label %schedule.98
    i32 99, label %schedule.99
    i32 100, label %schedule.100
    i32 101, label %schedule.101
    i32 102, label %schedule.102
    i32 103, label %schedule.103
    i32 104, label %schedule.104
    i32 105, label %schedule.105
    i32 106, label %schedule.106
    i32 107, label %schedule.107
    i32 108, label %schedule.108
    i32 109, label %schedule.109
    i32 110, label %schedule.110
    i32 111, label %schedule.111
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %87 = load <8 x i1>, ptr %live.mask, align 1
  %88 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %87)
  br i1 %88, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %89 = load <8 x i1>, ptr %current.mask, align 1
  %90 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %89)
  %91 = bitcast <8 x i1> %89 to i8
  %92 = call i8 @llvm.cttz.i8(i8 %91, i1 false)
  %93 = zext i8 %92 to i32
  %94 = select i1 %90, i32 %93, i32 0
  %95 = extractvalue [3 x <8 x i32>] %54, 0
  %96 = zext <8 x i32> %95 to <8 x i64>
  %97 = select <8 x i1> %89, <8 x i64> %96, <8 x i64> zeroinitializer
  %98 = select <8 x i1> %89, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %99 = sdiv <8 x i64> %97, %98
  %100 = select <8 x i1> %89, <8 x i64> %96, <8 x i64> zeroinitializer
  %101 = select <8 x i1> %89, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %102 = sdiv <8 x i64> %100, %101
  %103 = select <8 x i1> %89, <8 x i64> %102, <8 x i64> zeroinitializer
  %104 = select <8 x i1> %89, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %105 = srem <8 x i64> %103, %104
  %106 = mul <8 x i64> %105, splat (i64 2)
  %107 = select <8 x i1> %89, <8 x i64> %99, <8 x i64> zeroinitializer
  %108 = select <8 x i1> %89, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %109 = sdiv <8 x i64> %107, %108
  %110 = load volatile <8 x i64>, ptr %.spill, align 64
  %111 = select <8 x i1> %89, <8 x i64> %109, <8 x i64> %110
  store volatile <8 x i64> %111, ptr %.spill, align 64
  store i64 0, ptr %.spill10, align 4
  store i64 0, ptr %.spill11, align 4
  store volatile i64 0, ptr %.spill12, align 4
  %112 = add <8 x i64> %99, zeroinitializer
  %113 = add <8 x i64> zeroinitializer, %112
  %114 = add <8 x i64> %106, zeroinitializer
  %115 = load volatile <8 x i64>, ptr %.spill13, align 64
  %116 = select <8 x i1> %89, <8 x i64> %114, <8 x i64> %115
  store volatile <8 x i64> %116, ptr %.spill13, align 64
  %117 = mul <8 x i64> %113, splat (i64 3)
  %118 = add <8 x i64> %117, %114
  %119 = load volatile <8 x i64>, ptr %.spill14, align 64
  %120 = select <8 x i1> %89, <8 x i64> %118, <8 x i64> %119
  store volatile <8 x i64> %120, ptr %.spill14, align 64
  %121 = mul <8 x i64> %118, splat (i64 5)
  %122 = add <8 x i64> %121, zeroinitializer
  %123 = extractvalue { ptr, i64 } %13, 0
  %124 = mul <8 x i64> %122, splat (i64 4)
  %125 = getelementptr i8, ptr %123, <8 x i64> %124
  %126 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %125, <8 x i1> %89, <8 x float> zeroinitializer)
  %127 = load volatile <8 x float>, ptr %.spill15, align 32
  %128 = select <8 x i1> %89, <8 x float> %126, <8 x float> %127
  store volatile <8 x float> %128, ptr %.spill15, align 32
  store i64 1, ptr %.spill16, align 4
  %129 = add <8 x i64> %121, splat (i64 1)
  %130 = extractvalue { ptr, i64 } %13, 0
  %131 = mul <8 x i64> %129, splat (i64 4)
  %132 = getelementptr i8, ptr %130, <8 x i64> %131
  %133 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %132, <8 x i1> %89, <8 x float> zeroinitializer)
  %134 = load volatile <8 x float>, ptr %.spill17, align 32
  %135 = select <8 x i1> %89, <8 x float> %133, <8 x float> %134
  store volatile <8 x float> %135, ptr %.spill17, align 32
  store i64 2, ptr %.spill18, align 4
  %136 = add <8 x i64> %121, splat (i64 2)
  %137 = extractvalue { ptr, i64 } %13, 0
  %138 = mul <8 x i64> %136, splat (i64 4)
  %139 = getelementptr i8, ptr %137, <8 x i64> %138
  %140 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %139, <8 x i1> %89, <8 x float> zeroinitializer)
  %141 = load volatile <8 x float>, ptr %.spill19, align 32
  %142 = select <8 x i1> %89, <8 x float> %140, <8 x float> %141
  store volatile <8 x float> %142, ptr %.spill19, align 32
  store i64 3, ptr %.spill20, align 4
  %143 = add <8 x i64> %121, splat (i64 3)
  %144 = extractvalue { ptr, i64 } %13, 0
  %145 = mul <8 x i64> %143, splat (i64 4)
  %146 = getelementptr i8, ptr %144, <8 x i64> %145
  %147 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %146, <8 x i1> %89, <8 x float> zeroinitializer)
  %148 = load volatile <8 x float>, ptr %.spill21, align 32
  %149 = select <8 x i1> %89, <8 x float> %147, <8 x float> %148
  store volatile <8 x float> %149, ptr %.spill21, align 32
  store volatile i64 4, ptr %.spill22, align 4
  %150 = add <8 x i64> %121, splat (i64 4)
  %151 = extractvalue { ptr, i64 } %13, 0
  %152 = mul <8 x i64> %150, splat (i64 4)
  %153 = getelementptr i8, ptr %151, <8 x i64> %152
  %154 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %153, <8 x i1> %89, <8 x float> zeroinitializer)
  %155 = load volatile <8 x float>, ptr %.spill23, align 32
  %156 = select <8 x i1> %89, <8 x float> %154, <8 x float> %155
  store volatile <8 x float> %156, ptr %.spill23, align 32
  %157 = add <8 x i64> %106, splat (i64 1)
  %158 = load volatile <8 x i64>, ptr %.spill24, align 64
  %159 = select <8 x i1> %89, <8 x i64> %157, <8 x i64> %158
  store volatile <8 x i64> %159, ptr %.spill24, align 64
  %160 = add <8 x i64> %117, %157
  %161 = load volatile <8 x i64>, ptr %.spill25, align 64
  %162 = select <8 x i1> %89, <8 x i64> %160, <8 x i64> %161
  store volatile <8 x i64> %162, ptr %.spill25, align 64
  %163 = icmp sge <8 x i64> %157, zeroinitializer
  %164 = and <8 x i1> splat (i1 true), %163
  %165 = icmp slt <8 x i64> %157, splat (i64 3)
  %166 = and <8 x i1> %164, %165
  %167 = load <8 x i1>, ptr %.spill26, align 1
  %168 = select <8 x i1> %89, <8 x i1> %166, <8 x i1> %167
  store <8 x i1> %168, ptr %.spill26, align 1
  %169 = mul <8 x i64> %160, splat (i64 5)
  %170 = load <8 x i64>, ptr %.spill27, align 64
  %171 = select <8 x i1> %89, <8 x i64> %169, <8 x i64> %170
  store <8 x i64> %171, ptr %.spill27, align 64
  %172 = add <8 x i64> %169, zeroinitializer
  %173 = load volatile <8 x i64>, ptr %.spill28, align 64
  %174 = select <8 x i1> %89, <8 x i64> %172, <8 x i64> %173
  store volatile <8 x i64> %174, ptr %.spill28, align 64
  %175 = and <8 x i1> %89, %166
  %176 = xor <8 x i1> %166, splat (i1 true)
  %177 = and <8 x i1> %89, %176
  %178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %175)
  %179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %177)
  %180 = and i1 %178, %179
  br i1 %180, label %varying.divergent, label %varying.coherent

schedule.1:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %181 = load <8 x i1>, ptr %current.mask, align 1
  %182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %181)
  %183 = bitcast <8 x i1> %181 to i8
  %184 = call i8 @llvm.cttz.i8(i8 %183, i1 false)
  %185 = zext i8 %184 to i32
  %186 = select i1 %182, i32 %185, i32 0
  %.spill.load = load volatile <8 x i64>, ptr %.spill28, align 64
  %187 = extractvalue { ptr, i64 } %13, 0
  %188 = mul <8 x i64> %.spill.load, splat (i64 4)
  %189 = getelementptr i8, ptr %187, <8 x i64> %188
  %190 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %189, <8 x i1> %181, <8 x float> zeroinitializer)
  %191 = load <8 x float>, ptr %.slot, align 32
  %192 = select <8 x i1> %181, <8 x float> %190, <8 x float> %191
  store <8 x float> %192, ptr %.slot, align 32
  store <8 x i1> %181, ptr %current.mask, align 1
  %193 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %181)
  br i1 %193, label %schedule.2, label %scheduler.loop

schedule.2:                                       ; preds = %schedule.1, %varying.coherent.false, %scheduler.dispatch.route
  %194 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.3:                                       ; preds = %varying.coherent.true222, %scheduler.dispatch.route
  %195 = load <8 x i1>, ptr %current.mask, align 1
  %196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %195)
  %197 = bitcast <8 x i1> %195 to i8
  %198 = call i8 @llvm.cttz.i8(i8 %197, i1 false)
  %199 = zext i8 %198 to i32
  %200 = select i1 %196, i32 %199, i32 0
  %.spill.load224 = load volatile <8 x i64>, ptr %.spill29, align 64
  %201 = extractvalue { ptr, i64 } %13, 0
  %202 = mul <8 x i64> %.spill.load224, splat (i64 4)
  %203 = getelementptr i8, ptr %201, <8 x i64> %202
  %204 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %203, <8 x i1> %195, <8 x float> zeroinitializer)
  %205 = load <8 x float>, ptr %.slot30, align 32
  %206 = select <8 x i1> %195, <8 x float> %204, <8 x float> %205
  store <8 x float> %206, ptr %.slot30, align 32
  store <8 x i1> %195, ptr %current.mask, align 1
  %207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %195)
  br i1 %207, label %schedule.4, label %scheduler.loop

schedule.4:                                       ; preds = %schedule.3, %varying.coherent.false223, %scheduler.dispatch.route
  %208 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token227 = load i32, ptr %current.token, align 4
  %convergence.token.present228 = icmp ne i32 %convergence.current.token227, 0
  br i1 %convergence.token.present228, label %convergence.cascade225, label %convergence.cascade.exit226

schedule.5:                                       ; preds = %varying.coherent.true253, %scheduler.dispatch.route
  %209 = load <8 x i1>, ptr %current.mask, align 1
  %210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %209)
  %211 = bitcast <8 x i1> %209 to i8
  %212 = call i8 @llvm.cttz.i8(i8 %211, i1 false)
  %213 = zext i8 %212 to i32
  %214 = select i1 %210, i32 %213, i32 0
  %.spill.load255 = load volatile <8 x i64>, ptr %.spill31, align 64
  %215 = extractvalue { ptr, i64 } %13, 0
  %216 = mul <8 x i64> %.spill.load255, splat (i64 4)
  %217 = getelementptr i8, ptr %215, <8 x i64> %216
  %218 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %217, <8 x i1> %209, <8 x float> zeroinitializer)
  %219 = load <8 x float>, ptr %.slot32, align 32
  %220 = select <8 x i1> %209, <8 x float> %218, <8 x float> %219
  store <8 x float> %220, ptr %.slot32, align 32
  store <8 x i1> %209, ptr %current.mask, align 1
  %221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %209)
  br i1 %221, label %schedule.6, label %scheduler.loop

schedule.6:                                       ; preds = %schedule.5, %varying.coherent.false254, %scheduler.dispatch.route
  %222 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token258 = load i32, ptr %current.token, align 4
  %convergence.token.present259 = icmp ne i32 %convergence.current.token258, 0
  br i1 %convergence.token.present259, label %convergence.cascade256, label %convergence.cascade.exit257

schedule.7:                                       ; preds = %varying.coherent.true284, %scheduler.dispatch.route
  %223 = load <8 x i1>, ptr %current.mask, align 1
  %224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %223)
  %225 = bitcast <8 x i1> %223 to i8
  %226 = call i8 @llvm.cttz.i8(i8 %225, i1 false)
  %227 = zext i8 %226 to i32
  %228 = select i1 %224, i32 %227, i32 0
  %.spill.load286 = load volatile <8 x i64>, ptr %.spill33, align 64
  %229 = extractvalue { ptr, i64 } %13, 0
  %230 = mul <8 x i64> %.spill.load286, splat (i64 4)
  %231 = getelementptr i8, ptr %229, <8 x i64> %230
  %232 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %231, <8 x i1> %223, <8 x float> zeroinitializer)
  %233 = load <8 x float>, ptr %.slot34, align 32
  %234 = select <8 x i1> %223, <8 x float> %232, <8 x float> %233
  store <8 x float> %234, ptr %.slot34, align 32
  store <8 x i1> %223, ptr %current.mask, align 1
  %235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %223)
  br i1 %235, label %schedule.8, label %scheduler.loop

schedule.8:                                       ; preds = %schedule.7, %varying.coherent.false285, %scheduler.dispatch.route
  %236 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token289 = load i32, ptr %current.token, align 4
  %convergence.token.present290 = icmp ne i32 %convergence.current.token289, 0
  br i1 %convergence.token.present290, label %convergence.cascade287, label %convergence.cascade.exit288

schedule.9:                                       ; preds = %varying.coherent.true315, %scheduler.dispatch.route
  %237 = load <8 x i1>, ptr %current.mask, align 1
  %238 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %237)
  %239 = bitcast <8 x i1> %237 to i8
  %240 = call i8 @llvm.cttz.i8(i8 %239, i1 false)
  %241 = zext i8 %240 to i32
  %242 = select i1 %238, i32 %241, i32 0
  %.spill.load317 = load volatile <8 x i64>, ptr %.spill35, align 64
  %243 = extractvalue { ptr, i64 } %13, 0
  %244 = mul <8 x i64> %.spill.load317, splat (i64 4)
  %245 = getelementptr i8, ptr %243, <8 x i64> %244
  %246 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %245, <8 x i1> %237, <8 x float> zeroinitializer)
  %247 = load <8 x float>, ptr %.slot36, align 32
  %248 = select <8 x i1> %237, <8 x float> %246, <8 x float> %247
  store <8 x float> %248, ptr %.slot36, align 32
  store <8 x i1> %237, ptr %current.mask, align 1
  %249 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %237)
  br i1 %249, label %schedule.10, label %scheduler.loop

schedule.10:                                      ; preds = %schedule.9, %varying.coherent.false316, %scheduler.dispatch.route
  %250 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token320 = load i32, ptr %current.token, align 4
  %convergence.token.present321 = icmp ne i32 %convergence.current.token320, 0
  br i1 %convergence.token.present321, label %convergence.cascade318, label %convergence.cascade.exit319

schedule.11:                                      ; preds = %convergence.target.102.ready, %convergence.target.10.ready, %scheduler.dispatch.route
  %251 = load <8 x i1>, ptr %current.mask, align 1
  %252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %251)
  %253 = bitcast <8 x i1> %251 to i8
  %254 = call i8 @llvm.cttz.i8(i8 %253, i1 false)
  %255 = zext i8 %254 to i32
  %256 = select i1 %252, i32 %255, i32 0
  %.state = load <8 x i64>, ptr %.slot37, align 64
  %257 = icmp slt <8 x i64> %.state, splat (i64 3)
  %258 = and <8 x i1> %251, %257
  %259 = xor <8 x i1> %257, splat (i1 true)
  %260 = and <8 x i1> %251, %259
  %261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %258)
  %262 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %260)
  %263 = and i1 %261, %262
  br i1 %263, label %varying.divergent335, label %varying.coherent336

schedule.12:                                      ; preds = %varying.coherent.true341, %scheduler.dispatch.route
  %264 = load <8 x i1>, ptr %current.mask, align 1
  %265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %264)
  %266 = bitcast <8 x i1> %264 to i8
  %267 = call i8 @llvm.cttz.i8(i8 %266, i1 false)
  %268 = zext i8 %267 to i32
  %269 = select i1 %265, i32 %268, i32 0
  %.state343 = load <8 x i64>, ptr %.slot37, align 64
  %270 = select <8 x i1> %264, <8 x i64> %.state343, <8 x i64> zeroinitializer
  %271 = select <8 x i1> %264, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %272 = sdiv <8 x i64> %270, %271
  %273 = mul <8 x i64> %272, splat (i64 3)
  %274 = load volatile <8 x i64>, ptr %.spill50, align 64
  %275 = select <8 x i1> %264, <8 x i64> %273, <8 x i64> %274
  store volatile <8 x i64> %275, ptr %.spill50, align 64
  %.spill.load344 = load volatile <8 x i64>, ptr %.spill, align 64
  %276 = add <8 x i64> %.spill.load344, zeroinitializer
  %.spill.load345 = load volatile i64, ptr %.spill12, align 4
  %277 = mul i64 %.spill.load345, 1
  %.splatinsert346 = insertelement <8 x i64> poison, i64 %277, i64 0
  %.splat347 = shufflevector <8 x i64> %.splatinsert346, <8 x i64> poison, <8 x i32> zeroinitializer
  %278 = add <8 x i64> %.splat347, %276
  %279 = add <8 x i64> %273, zeroinitializer
  %280 = load volatile <8 x i64>, ptr %.spill51, align 64
  %281 = select <8 x i1> %264, <8 x i64> %279, <8 x i64> %280
  store volatile <8 x i64> %281, ptr %.spill51, align 64
  %282 = mul <8 x i64> %278, splat (i64 7)
  %283 = load volatile <8 x i64>, ptr %.spill52, align 64
  %284 = select <8 x i1> %264, <8 x i64> %282, <8 x i64> %283
  store volatile <8 x i64> %284, ptr %.spill52, align 64
  %285 = add <8 x i64> %282, %279
  %286 = load volatile <8 x i64>, ptr %.spill53, align 64
  %287 = select <8 x i1> %264, <8 x i64> %285, <8 x i64> %286
  store volatile <8 x i64> %287, ptr %.spill53, align 64
  %288 = mul <8 x i64> %285, splat (i64 5)
  %.spill.load348 = load i64, ptr %.spill10, align 4
  %.splatinsert349 = insertelement <8 x i64> poison, i64 %.spill.load348, i64 0
  %.splat350 = shufflevector <8 x i64> %.splatinsert349, <8 x i64> poison, <8 x i32> zeroinitializer
  %289 = add <8 x i64> %288, %.splat350
  %290 = extractvalue { ptr, i64 } %19, 0
  %291 = mul <8 x i64> %289, splat (i64 4)
  %292 = getelementptr i8, ptr %290, <8 x i64> %291
  %293 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %292, <8 x i1> %264, <8 x float> zeroinitializer)
  %294 = load volatile <8 x float>, ptr %.spill54, align 32
  %295 = select <8 x i1> %264, <8 x float> %293, <8 x float> %294
  store volatile <8 x float> %295, ptr %.spill54, align 32
  %.spill.load351 = load i64, ptr %.spill16, align 4
  %.splatinsert352 = insertelement <8 x i64> poison, i64 %.spill.load351, i64 0
  %.splat353 = shufflevector <8 x i64> %.splatinsert352, <8 x i64> poison, <8 x i32> zeroinitializer
  %296 = add <8 x i64> %288, %.splat353
  %297 = extractvalue { ptr, i64 } %19, 0
  %298 = mul <8 x i64> %296, splat (i64 4)
  %299 = getelementptr i8, ptr %297, <8 x i64> %298
  %300 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %299, <8 x i1> %264, <8 x float> zeroinitializer)
  %301 = load volatile <8 x float>, ptr %.spill55, align 32
  %302 = select <8 x i1> %264, <8 x float> %300, <8 x float> %301
  store volatile <8 x float> %302, ptr %.spill55, align 32
  %.spill.load354 = load i64, ptr %.spill18, align 4
  %.splatinsert355 = insertelement <8 x i64> poison, i64 %.spill.load354, i64 0
  %.splat356 = shufflevector <8 x i64> %.splatinsert355, <8 x i64> poison, <8 x i32> zeroinitializer
  %303 = add <8 x i64> %288, %.splat356
  %304 = extractvalue { ptr, i64 } %19, 0
  %305 = mul <8 x i64> %303, splat (i64 4)
  %306 = getelementptr i8, ptr %304, <8 x i64> %305
  %307 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %306, <8 x i1> %264, <8 x float> zeroinitializer)
  %308 = load volatile <8 x float>, ptr %.spill56, align 32
  %309 = select <8 x i1> %264, <8 x float> %307, <8 x float> %308
  store volatile <8 x float> %309, ptr %.spill56, align 32
  %.spill.load357 = load i64, ptr %.spill20, align 4
  %.splatinsert358 = insertelement <8 x i64> poison, i64 %.spill.load357, i64 0
  %.splat359 = shufflevector <8 x i64> %.splatinsert358, <8 x i64> poison, <8 x i32> zeroinitializer
  %310 = add <8 x i64> %288, %.splat359
  %311 = extractvalue { ptr, i64 } %19, 0
  %312 = mul <8 x i64> %310, splat (i64 4)
  %313 = getelementptr i8, ptr %311, <8 x i64> %312
  %314 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %313, <8 x i1> %264, <8 x float> zeroinitializer)
  %315 = load volatile <8 x float>, ptr %.spill57, align 32
  %316 = select <8 x i1> %264, <8 x float> %314, <8 x float> %315
  store volatile <8 x float> %316, ptr %.spill57, align 32
  %.spill.load360 = load volatile i64, ptr %.spill22, align 4
  %.splatinsert361 = insertelement <8 x i64> poison, i64 %.spill.load360, i64 0
  %.splat362 = shufflevector <8 x i64> %.splatinsert361, <8 x i64> poison, <8 x i32> zeroinitializer
  %317 = add <8 x i64> %288, %.splat362
  %318 = extractvalue { ptr, i64 } %19, 0
  %319 = mul <8 x i64> %317, splat (i64 4)
  %320 = getelementptr i8, ptr %318, <8 x i64> %319
  %321 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %320, <8 x i1> %264, <8 x float> zeroinitializer)
  %322 = load volatile <8 x float>, ptr %.spill58, align 32
  %323 = select <8 x i1> %264, <8 x float> %321, <8 x float> %322
  store volatile <8 x float> %323, ptr %.spill58, align 32
  %324 = add <8 x i64> %273, splat (i64 1)
  %325 = load volatile <8 x i64>, ptr %.spill59, align 64
  %326 = select <8 x i1> %264, <8 x i64> %324, <8 x i64> %325
  store volatile <8 x i64> %326, ptr %.spill59, align 64
  %327 = add <8 x i64> %282, %324
  %328 = load volatile <8 x i64>, ptr %.spill60, align 64
  %329 = select <8 x i1> %264, <8 x i64> %327, <8 x i64> %328
  store volatile <8 x i64> %329, ptr %.spill60, align 64
  %330 = icmp sge <8 x i64> %324, zeroinitializer
  %331 = and <8 x i1> splat (i1 true), %330
  %332 = icmp slt <8 x i64> %324, splat (i64 7)
  %333 = load volatile <8 x i1>, ptr %.spill61, align 1
  %334 = select <8 x i1> %264, <8 x i1> %332, <8 x i1> %333
  store volatile <8 x i1> %334, ptr %.spill61, align 1
  %335 = and <8 x i1> %331, %332
  %336 = load <8 x i1>, ptr %.spill62, align 1
  %337 = select <8 x i1> %264, <8 x i1> %335, <8 x i1> %336
  store <8 x i1> %337, ptr %.spill62, align 1
  %338 = mul <8 x i64> %327, splat (i64 5)
  %339 = load <8 x i64>, ptr %.spill63, align 64
  %340 = select <8 x i1> %264, <8 x i64> %338, <8 x i64> %339
  store <8 x i64> %340, ptr %.spill63, align 64
  %.spill.load363 = load i64, ptr %.spill10, align 4
  %.splatinsert364 = insertelement <8 x i64> poison, i64 %.spill.load363, i64 0
  %.splat365 = shufflevector <8 x i64> %.splatinsert364, <8 x i64> poison, <8 x i32> zeroinitializer
  %341 = add <8 x i64> %338, %.splat365
  %342 = load volatile <8 x i64>, ptr %.spill64, align 64
  %343 = select <8 x i1> %264, <8 x i64> %341, <8 x i64> %342
  store volatile <8 x i64> %343, ptr %.spill64, align 64
  %344 = and <8 x i1> %264, %335
  %345 = xor <8 x i1> %335, splat (i1 true)
  %346 = and <8 x i1> %264, %345
  %347 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %344)
  %348 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %346)
  %349 = and i1 %347, %348
  br i1 %349, label %varying.divergent366, label %varying.coherent367

schedule.13:                                      ; preds = %varying.coherent.true372, %scheduler.dispatch.route
  %350 = load <8 x i1>, ptr %current.mask, align 1
  %351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %350)
  %352 = bitcast <8 x i1> %350 to i8
  %353 = call i8 @llvm.cttz.i8(i8 %352, i1 false)
  %354 = zext i8 %353 to i32
  %355 = select i1 %351, i32 %354, i32 0
  %.spill.load374 = load volatile <8 x i64>, ptr %.spill64, align 64
  %356 = extractvalue { ptr, i64 } %19, 0
  %357 = mul <8 x i64> %.spill.load374, splat (i64 4)
  %358 = getelementptr i8, ptr %356, <8 x i64> %357
  %359 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %358, <8 x i1> %350, <8 x float> zeroinitializer)
  %360 = load <8 x float>, ptr %.slot65, align 32
  %361 = select <8 x i1> %350, <8 x float> %359, <8 x float> %360
  store <8 x float> %361, ptr %.slot65, align 32
  store <8 x i1> %350, ptr %current.mask, align 1
  %362 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %350)
  br i1 %362, label %schedule.14, label %scheduler.loop

schedule.14:                                      ; preds = %schedule.13, %varying.coherent.false373, %scheduler.dispatch.route
  %363 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token377 = load i32, ptr %current.token, align 4
  %convergence.token.present378 = icmp ne i32 %convergence.current.token377, 0
  br i1 %convergence.token.present378, label %convergence.cascade375, label %convergence.cascade.exit376

schedule.15:                                      ; preds = %varying.coherent.true403, %scheduler.dispatch.route
  %364 = load <8 x i1>, ptr %current.mask, align 1
  %365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %364)
  %366 = bitcast <8 x i1> %364 to i8
  %367 = call i8 @llvm.cttz.i8(i8 %366, i1 false)
  %368 = zext i8 %367 to i32
  %369 = select i1 %365, i32 %368, i32 0
  %.spill.load405 = load volatile <8 x i64>, ptr %.spill66, align 64
  %370 = extractvalue { ptr, i64 } %19, 0
  %371 = mul <8 x i64> %.spill.load405, splat (i64 4)
  %372 = getelementptr i8, ptr %370, <8 x i64> %371
  %373 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %372, <8 x i1> %364, <8 x float> zeroinitializer)
  %374 = load <8 x float>, ptr %.slot67, align 32
  %375 = select <8 x i1> %364, <8 x float> %373, <8 x float> %374
  store <8 x float> %375, ptr %.slot67, align 32
  store <8 x i1> %364, ptr %current.mask, align 1
  %376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %364)
  br i1 %376, label %schedule.16, label %scheduler.loop

schedule.16:                                      ; preds = %schedule.15, %varying.coherent.false404, %scheduler.dispatch.route
  %377 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token408 = load i32, ptr %current.token, align 4
  %convergence.token.present409 = icmp ne i32 %convergence.current.token408, 0
  br i1 %convergence.token.present409, label %convergence.cascade406, label %convergence.cascade.exit407

schedule.17:                                      ; preds = %varying.coherent.true434, %scheduler.dispatch.route
  %378 = load <8 x i1>, ptr %current.mask, align 1
  %379 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %378)
  %380 = bitcast <8 x i1> %378 to i8
  %381 = call i8 @llvm.cttz.i8(i8 %380, i1 false)
  %382 = zext i8 %381 to i32
  %383 = select i1 %379, i32 %382, i32 0
  %.spill.load436 = load volatile <8 x i64>, ptr %.spill68, align 64
  %384 = extractvalue { ptr, i64 } %19, 0
  %385 = mul <8 x i64> %.spill.load436, splat (i64 4)
  %386 = getelementptr i8, ptr %384, <8 x i64> %385
  %387 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %386, <8 x i1> %378, <8 x float> zeroinitializer)
  %388 = load <8 x float>, ptr %.slot69, align 32
  %389 = select <8 x i1> %378, <8 x float> %387, <8 x float> %388
  store <8 x float> %389, ptr %.slot69, align 32
  store <8 x i1> %378, ptr %current.mask, align 1
  %390 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %378)
  br i1 %390, label %schedule.18, label %scheduler.loop

schedule.18:                                      ; preds = %schedule.17, %varying.coherent.false435, %scheduler.dispatch.route
  %391 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token439 = load i32, ptr %current.token, align 4
  %convergence.token.present440 = icmp ne i32 %convergence.current.token439, 0
  br i1 %convergence.token.present440, label %convergence.cascade437, label %convergence.cascade.exit438

schedule.19:                                      ; preds = %varying.coherent.true465, %scheduler.dispatch.route
  %392 = load <8 x i1>, ptr %current.mask, align 1
  %393 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %392)
  %394 = bitcast <8 x i1> %392 to i8
  %395 = call i8 @llvm.cttz.i8(i8 %394, i1 false)
  %396 = zext i8 %395 to i32
  %397 = select i1 %393, i32 %396, i32 0
  %.spill.load467 = load volatile <8 x i64>, ptr %.spill70, align 64
  %398 = extractvalue { ptr, i64 } %19, 0
  %399 = mul <8 x i64> %.spill.load467, splat (i64 4)
  %400 = getelementptr i8, ptr %398, <8 x i64> %399
  %401 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %400, <8 x i1> %392, <8 x float> zeroinitializer)
  %402 = load <8 x float>, ptr %.slot71, align 32
  %403 = select <8 x i1> %392, <8 x float> %401, <8 x float> %402
  store <8 x float> %403, ptr %.slot71, align 32
  store <8 x i1> %392, ptr %current.mask, align 1
  %404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %392)
  br i1 %404, label %schedule.20, label %scheduler.loop

schedule.20:                                      ; preds = %schedule.19, %varying.coherent.false466, %scheduler.dispatch.route
  %405 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token470 = load i32, ptr %current.token, align 4
  %convergence.token.present471 = icmp ne i32 %convergence.current.token470, 0
  br i1 %convergence.token.present471, label %convergence.cascade468, label %convergence.cascade.exit469

schedule.21:                                      ; preds = %varying.coherent.true496, %scheduler.dispatch.route
  %406 = load <8 x i1>, ptr %current.mask, align 1
  %407 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %406)
  %408 = bitcast <8 x i1> %406 to i8
  %409 = call i8 @llvm.cttz.i8(i8 %408, i1 false)
  %410 = zext i8 %409 to i32
  %411 = select i1 %407, i32 %410, i32 0
  %.spill.load498 = load volatile <8 x i64>, ptr %.spill72, align 64
  %412 = extractvalue { ptr, i64 } %19, 0
  %413 = mul <8 x i64> %.spill.load498, splat (i64 4)
  %414 = getelementptr i8, ptr %412, <8 x i64> %413
  %415 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %414, <8 x i1> %406, <8 x float> zeroinitializer)
  %416 = load <8 x float>, ptr %.slot73, align 32
  %417 = select <8 x i1> %406, <8 x float> %415, <8 x float> %416
  store <8 x float> %417, ptr %.slot73, align 32
  store <8 x i1> %406, ptr %current.mask, align 1
  %418 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %406)
  br i1 %418, label %schedule.22, label %scheduler.loop

schedule.22:                                      ; preds = %schedule.21, %varying.coherent.false497, %scheduler.dispatch.route
  %419 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token501 = load i32, ptr %current.token, align 4
  %convergence.token.present502 = icmp ne i32 %convergence.current.token501, 0
  br i1 %convergence.token.present502, label %convergence.cascade499, label %convergence.cascade.exit500

schedule.23:                                      ; preds = %varying.coherent.true527, %scheduler.dispatch.route
  %420 = load <8 x i1>, ptr %current.mask, align 1
  %421 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %420)
  %422 = bitcast <8 x i1> %420 to i8
  %423 = call i8 @llvm.cttz.i8(i8 %422, i1 false)
  %424 = zext i8 %423 to i32
  %425 = select i1 %421, i32 %424, i32 0
  %.spill.load529 = load volatile <8 x i64>, ptr %.spill79, align 64
  %426 = extractvalue { ptr, i64 } %19, 0
  %427 = mul <8 x i64> %.spill.load529, splat (i64 4)
  %428 = getelementptr i8, ptr %426, <8 x i64> %427
  %429 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %428, <8 x i1> %420, <8 x float> zeroinitializer)
  %430 = load <8 x float>, ptr %.slot80, align 32
  %431 = select <8 x i1> %420, <8 x float> %429, <8 x float> %430
  store <8 x float> %431, ptr %.slot80, align 32
  store <8 x i1> %420, ptr %current.mask, align 1
  %432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %420)
  br i1 %432, label %schedule.24, label %scheduler.loop

schedule.24:                                      ; preds = %schedule.23, %varying.coherent.false528, %scheduler.dispatch.route
  %433 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token532 = load i32, ptr %current.token, align 4
  %convergence.token.present533 = icmp ne i32 %convergence.current.token532, 0
  br i1 %convergence.token.present533, label %convergence.cascade530, label %convergence.cascade.exit531

schedule.25:                                      ; preds = %varying.coherent.true558, %scheduler.dispatch.route
  %434 = load <8 x i1>, ptr %current.mask, align 1
  %435 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %434)
  %436 = bitcast <8 x i1> %434 to i8
  %437 = call i8 @llvm.cttz.i8(i8 %436, i1 false)
  %438 = zext i8 %437 to i32
  %439 = select i1 %435, i32 %438, i32 0
  %.spill.load560 = load volatile <8 x i64>, ptr %.spill81, align 64
  %440 = extractvalue { ptr, i64 } %19, 0
  %441 = mul <8 x i64> %.spill.load560, splat (i64 4)
  %442 = getelementptr i8, ptr %440, <8 x i64> %441
  %443 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %442, <8 x i1> %434, <8 x float> zeroinitializer)
  %444 = load <8 x float>, ptr %.slot82, align 32
  %445 = select <8 x i1> %434, <8 x float> %443, <8 x float> %444
  store <8 x float> %445, ptr %.slot82, align 32
  store <8 x i1> %434, ptr %current.mask, align 1
  %446 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %434)
  br i1 %446, label %schedule.26, label %scheduler.loop

schedule.26:                                      ; preds = %schedule.25, %varying.coherent.false559, %scheduler.dispatch.route
  %447 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token563 = load i32, ptr %current.token, align 4
  %convergence.token.present564 = icmp ne i32 %convergence.current.token563, 0
  br i1 %convergence.token.present564, label %convergence.cascade561, label %convergence.cascade.exit562

schedule.27:                                      ; preds = %varying.coherent.true589, %scheduler.dispatch.route
  %448 = load <8 x i1>, ptr %current.mask, align 1
  %449 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %448)
  %450 = bitcast <8 x i1> %448 to i8
  %451 = call i8 @llvm.cttz.i8(i8 %450, i1 false)
  %452 = zext i8 %451 to i32
  %453 = select i1 %449, i32 %452, i32 0
  %.spill.load591 = load volatile <8 x i64>, ptr %.spill83, align 64
  %454 = extractvalue { ptr, i64 } %19, 0
  %455 = mul <8 x i64> %.spill.load591, splat (i64 4)
  %456 = getelementptr i8, ptr %454, <8 x i64> %455
  %457 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %456, <8 x i1> %448, <8 x float> zeroinitializer)
  %458 = load <8 x float>, ptr %.slot84, align 32
  %459 = select <8 x i1> %448, <8 x float> %457, <8 x float> %458
  store <8 x float> %459, ptr %.slot84, align 32
  store <8 x i1> %448, ptr %current.mask, align 1
  %460 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %448)
  br i1 %460, label %schedule.28, label %scheduler.loop

schedule.28:                                      ; preds = %schedule.27, %varying.coherent.false590, %scheduler.dispatch.route
  %461 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token594 = load i32, ptr %current.token, align 4
  %convergence.token.present595 = icmp ne i32 %convergence.current.token594, 0
  br i1 %convergence.token.present595, label %convergence.cascade592, label %convergence.cascade.exit593

schedule.29:                                      ; preds = %varying.coherent.true620, %scheduler.dispatch.route
  %462 = load <8 x i1>, ptr %current.mask, align 1
  %463 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %462)
  %464 = bitcast <8 x i1> %462 to i8
  %465 = call i8 @llvm.cttz.i8(i8 %464, i1 false)
  %466 = zext i8 %465 to i32
  %467 = select i1 %463, i32 %466, i32 0
  %.spill.load622 = load volatile <8 x i64>, ptr %.spill85, align 64
  %468 = extractvalue { ptr, i64 } %19, 0
  %469 = mul <8 x i64> %.spill.load622, splat (i64 4)
  %470 = getelementptr i8, ptr %468, <8 x i64> %469
  %471 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %470, <8 x i1> %462, <8 x float> zeroinitializer)
  %472 = load <8 x float>, ptr %.slot86, align 32
  %473 = select <8 x i1> %462, <8 x float> %471, <8 x float> %472
  store <8 x float> %473, ptr %.slot86, align 32
  store <8 x i1> %462, ptr %current.mask, align 1
  %474 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %462)
  br i1 %474, label %schedule.30, label %scheduler.loop

schedule.30:                                      ; preds = %schedule.29, %varying.coherent.false621, %scheduler.dispatch.route
  %475 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token625 = load i32, ptr %current.token, align 4
  %convergence.token.present626 = icmp ne i32 %convergence.current.token625, 0
  br i1 %convergence.token.present626, label %convergence.cascade623, label %convergence.cascade.exit624

schedule.31:                                      ; preds = %varying.coherent.true651, %scheduler.dispatch.route
  %476 = load <8 x i1>, ptr %current.mask, align 1
  %477 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %476)
  %478 = bitcast <8 x i1> %476 to i8
  %479 = call i8 @llvm.cttz.i8(i8 %478, i1 false)
  %480 = zext i8 %479 to i32
  %481 = select i1 %477, i32 %480, i32 0
  %.spill.load653 = load volatile <8 x i64>, ptr %.spill87, align 64
  %482 = extractvalue { ptr, i64 } %19, 0
  %483 = mul <8 x i64> %.spill.load653, splat (i64 4)
  %484 = getelementptr i8, ptr %482, <8 x i64> %483
  %485 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %484, <8 x i1> %476, <8 x float> zeroinitializer)
  %486 = load <8 x float>, ptr %.slot88, align 32
  %487 = select <8 x i1> %476, <8 x float> %485, <8 x float> %486
  store <8 x float> %487, ptr %.slot88, align 32
  store <8 x i1> %476, ptr %current.mask, align 1
  %488 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %476)
  br i1 %488, label %schedule.32, label %scheduler.loop

schedule.32:                                      ; preds = %schedule.31, %varying.coherent.false652, %scheduler.dispatch.route
  %489 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token656 = load i32, ptr %current.token, align 4
  %convergence.token.present657 = icmp ne i32 %convergence.current.token656, 0
  br i1 %convergence.token.present657, label %convergence.cascade654, label %convergence.cascade.exit655

schedule.33:                                      ; preds = %varying.coherent.true695, %scheduler.dispatch.route
  %490 = load <8 x i1>, ptr %current.mask, align 1
  %491 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %490)
  %492 = bitcast <8 x i1> %490 to i8
  %493 = call i8 @llvm.cttz.i8(i8 %492, i1 false)
  %494 = zext i8 %493 to i32
  %495 = select i1 %491, i32 %494, i32 0
  %.spill.load697 = load volatile <8 x i64>, ptr %.spill94, align 64
  %496 = extractvalue { ptr, i64 } %25, 0
  %497 = mul <8 x i64> %.spill.load697, splat (i64 4)
  %498 = getelementptr i8, ptr %496, <8 x i64> %497
  %499 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %498, <8 x i1> %490, <8 x float> zeroinitializer)
  %500 = load <8 x float>, ptr %.slot95, align 32
  %501 = select <8 x i1> %490, <8 x float> %499, <8 x float> %500
  store <8 x float> %501, ptr %.slot95, align 32
  store <8 x i1> %490, ptr %current.mask, align 1
  %502 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %490)
  br i1 %502, label %schedule.34, label %scheduler.loop

schedule.34:                                      ; preds = %schedule.33, %varying.coherent.false696, %scheduler.dispatch.route
  %503 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token700 = load i32, ptr %current.token, align 4
  %convergence.token.present701 = icmp ne i32 %convergence.current.token700, 0
  br i1 %convergence.token.present701, label %convergence.cascade698, label %convergence.cascade.exit699

schedule.35:                                      ; preds = %varying.coherent.true726, %scheduler.dispatch.route
  %504 = load <8 x i1>, ptr %current.mask, align 1
  %505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %504)
  %506 = bitcast <8 x i1> %504 to i8
  %507 = call i8 @llvm.cttz.i8(i8 %506, i1 false)
  %508 = zext i8 %507 to i32
  %509 = select i1 %505, i32 %508, i32 0
  %.spill.load728 = load volatile <8 x i64>, ptr %.spill96, align 64
  %510 = extractvalue { ptr, i64 } %25, 0
  %511 = mul <8 x i64> %.spill.load728, splat (i64 4)
  %512 = getelementptr i8, ptr %510, <8 x i64> %511
  %513 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %512, <8 x i1> %504, <8 x float> zeroinitializer)
  %514 = load <8 x float>, ptr %.slot97, align 32
  %515 = select <8 x i1> %504, <8 x float> %513, <8 x float> %514
  store <8 x float> %515, ptr %.slot97, align 32
  store <8 x i1> %504, ptr %current.mask, align 1
  %516 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %504)
  br i1 %516, label %schedule.36, label %scheduler.loop

schedule.36:                                      ; preds = %schedule.35, %varying.coherent.false727, %scheduler.dispatch.route
  %517 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token731 = load i32, ptr %current.token, align 4
  %convergence.token.present732 = icmp ne i32 %convergence.current.token731, 0
  br i1 %convergence.token.present732, label %convergence.cascade729, label %convergence.cascade.exit730

schedule.37:                                      ; preds = %varying.coherent.true757, %scheduler.dispatch.route
  %518 = load <8 x i1>, ptr %current.mask, align 1
  %519 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %518)
  %520 = bitcast <8 x i1> %518 to i8
  %521 = call i8 @llvm.cttz.i8(i8 %520, i1 false)
  %522 = zext i8 %521 to i32
  %523 = select i1 %519, i32 %522, i32 0
  %.spill.load759 = load volatile <8 x i64>, ptr %.spill98, align 64
  %524 = extractvalue { ptr, i64 } %25, 0
  %525 = mul <8 x i64> %.spill.load759, splat (i64 4)
  %526 = getelementptr i8, ptr %524, <8 x i64> %525
  %527 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %526, <8 x i1> %518, <8 x float> zeroinitializer)
  %528 = load <8 x float>, ptr %.slot99, align 32
  %529 = select <8 x i1> %518, <8 x float> %527, <8 x float> %528
  store <8 x float> %529, ptr %.slot99, align 32
  store <8 x i1> %518, ptr %current.mask, align 1
  %530 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %518)
  br i1 %530, label %schedule.38, label %scheduler.loop

schedule.38:                                      ; preds = %schedule.37, %varying.coherent.false758, %scheduler.dispatch.route
  %531 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token762 = load i32, ptr %current.token, align 4
  %convergence.token.present763 = icmp ne i32 %convergence.current.token762, 0
  br i1 %convergence.token.present763, label %convergence.cascade760, label %convergence.cascade.exit761

schedule.39:                                      ; preds = %varying.coherent.true788, %scheduler.dispatch.route
  %532 = load <8 x i1>, ptr %current.mask, align 1
  %533 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %532)
  %534 = bitcast <8 x i1> %532 to i8
  %535 = call i8 @llvm.cttz.i8(i8 %534, i1 false)
  %536 = zext i8 %535 to i32
  %537 = select i1 %533, i32 %536, i32 0
  %.spill.load790 = load volatile <8 x i64>, ptr %.spill100, align 64
  %538 = extractvalue { ptr, i64 } %25, 0
  %539 = mul <8 x i64> %.spill.load790, splat (i64 4)
  %540 = getelementptr i8, ptr %538, <8 x i64> %539
  %541 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %540, <8 x i1> %532, <8 x float> zeroinitializer)
  %542 = load <8 x float>, ptr %.slot101, align 32
  %543 = select <8 x i1> %532, <8 x float> %541, <8 x float> %542
  store <8 x float> %543, ptr %.slot101, align 32
  store <8 x i1> %532, ptr %current.mask, align 1
  %544 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %532)
  br i1 %544, label %schedule.40, label %scheduler.loop

schedule.40:                                      ; preds = %schedule.39, %varying.coherent.false789, %scheduler.dispatch.route
  %545 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token793 = load i32, ptr %current.token, align 4
  %convergence.token.present794 = icmp ne i32 %convergence.current.token793, 0
  br i1 %convergence.token.present794, label %convergence.cascade791, label %convergence.cascade.exit792

schedule.41:                                      ; preds = %varying.coherent.true819, %scheduler.dispatch.route
  %546 = load <8 x i1>, ptr %current.mask, align 1
  %547 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %546)
  %548 = bitcast <8 x i1> %546 to i8
  %549 = call i8 @llvm.cttz.i8(i8 %548, i1 false)
  %550 = zext i8 %549 to i32
  %551 = select i1 %547, i32 %550, i32 0
  %.spill.load821 = load volatile <8 x i64>, ptr %.spill103, align 64
  %552 = extractvalue { ptr, i64 } %25, 0
  %553 = mul <8 x i64> %.spill.load821, splat (i64 4)
  %554 = getelementptr i8, ptr %552, <8 x i64> %553
  %555 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %554, <8 x i1> %546, <8 x float> zeroinitializer)
  %556 = load <8 x float>, ptr %.slot104, align 32
  %557 = select <8 x i1> %546, <8 x float> %555, <8 x float> %556
  store <8 x float> %557, ptr %.slot104, align 32
  store <8 x i1> %546, ptr %current.mask, align 1
  %558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %546)
  br i1 %558, label %schedule.42, label %scheduler.loop

schedule.42:                                      ; preds = %schedule.41, %varying.coherent.false820, %scheduler.dispatch.route
  %559 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token824 = load i32, ptr %current.token, align 4
  %convergence.token.present825 = icmp ne i32 %convergence.current.token824, 0
  br i1 %convergence.token.present825, label %convergence.cascade822, label %convergence.cascade.exit823

schedule.43:                                      ; preds = %varying.coherent.true850, %scheduler.dispatch.route
  %560 = load <8 x i1>, ptr %current.mask, align 1
  %561 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %560)
  %562 = bitcast <8 x i1> %560 to i8
  %563 = call i8 @llvm.cttz.i8(i8 %562, i1 false)
  %564 = zext i8 %563 to i32
  %565 = select i1 %561, i32 %564, i32 0
  %.spill.load852 = load volatile <8 x i64>, ptr %.spill105, align 64
  %566 = extractvalue { ptr, i64 } %25, 0
  %567 = mul <8 x i64> %.spill.load852, splat (i64 4)
  %568 = getelementptr i8, ptr %566, <8 x i64> %567
  %569 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %568, <8 x i1> %560, <8 x float> zeroinitializer)
  %570 = load <8 x float>, ptr %.slot106, align 32
  %571 = select <8 x i1> %560, <8 x float> %569, <8 x float> %570
  store <8 x float> %571, ptr %.slot106, align 32
  store <8 x i1> %560, ptr %current.mask, align 1
  %572 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %560)
  br i1 %572, label %schedule.44, label %scheduler.loop

schedule.44:                                      ; preds = %schedule.43, %varying.coherent.false851, %scheduler.dispatch.route
  %573 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token855 = load i32, ptr %current.token, align 4
  %convergence.token.present856 = icmp ne i32 %convergence.current.token855, 0
  br i1 %convergence.token.present856, label %convergence.cascade853, label %convergence.cascade.exit854

schedule.45:                                      ; preds = %varying.coherent.true881, %scheduler.dispatch.route
  %574 = load <8 x i1>, ptr %current.mask, align 1
  %575 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %574)
  %576 = bitcast <8 x i1> %574 to i8
  %577 = call i8 @llvm.cttz.i8(i8 %576, i1 false)
  %578 = zext i8 %577 to i32
  %579 = select i1 %575, i32 %578, i32 0
  %.spill.load883 = load volatile <8 x i64>, ptr %.spill107, align 64
  %580 = extractvalue { ptr, i64 } %25, 0
  %581 = mul <8 x i64> %.spill.load883, splat (i64 4)
  %582 = getelementptr i8, ptr %580, <8 x i64> %581
  %583 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %582, <8 x i1> %574, <8 x float> zeroinitializer)
  %584 = load <8 x float>, ptr %.slot108, align 32
  %585 = select <8 x i1> %574, <8 x float> %583, <8 x float> %584
  store <8 x float> %585, ptr %.slot108, align 32
  store <8 x i1> %574, ptr %current.mask, align 1
  %586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %574)
  br i1 %586, label %schedule.46, label %scheduler.loop

schedule.46:                                      ; preds = %schedule.45, %varying.coherent.false882, %scheduler.dispatch.route
  %587 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token886 = load i32, ptr %current.token, align 4
  %convergence.token.present887 = icmp ne i32 %convergence.current.token886, 0
  br i1 %convergence.token.present887, label %convergence.cascade884, label %convergence.cascade.exit885

schedule.47:                                      ; preds = %varying.coherent.true912, %scheduler.dispatch.route
  %588 = load <8 x i1>, ptr %current.mask, align 1
  %589 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %588)
  %590 = bitcast <8 x i1> %588 to i8
  %591 = call i8 @llvm.cttz.i8(i8 %590, i1 false)
  %592 = zext i8 %591 to i32
  %593 = select i1 %589, i32 %592, i32 0
  %.spill.load914 = load volatile <8 x i64>, ptr %.spill109, align 64
  %594 = extractvalue { ptr, i64 } %25, 0
  %595 = mul <8 x i64> %.spill.load914, splat (i64 4)
  %596 = getelementptr i8, ptr %594, <8 x i64> %595
  %597 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %596, <8 x i1> %588, <8 x float> zeroinitializer)
  %598 = load <8 x float>, ptr %.slot110, align 32
  %599 = select <8 x i1> %588, <8 x float> %597, <8 x float> %598
  store <8 x float> %599, ptr %.slot110, align 32
  store <8 x i1> %588, ptr %current.mask, align 1
  %600 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %588)
  br i1 %600, label %schedule.48, label %scheduler.loop

schedule.48:                                      ; preds = %schedule.47, %varying.coherent.false913, %scheduler.dispatch.route
  %601 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token917 = load i32, ptr %current.token, align 4
  %convergence.token.present918 = icmp ne i32 %convergence.current.token917, 0
  br i1 %convergence.token.present918, label %convergence.cascade915, label %convergence.cascade.exit916

schedule.49:                                      ; preds = %schedule.50, %convergence.target.48.ready, %scheduler.dispatch.route
  %602 = load <8 x i1>, ptr %current.mask, align 1
  %603 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %602)
  %604 = bitcast <8 x i1> %602 to i8
  %605 = call i8 @llvm.cttz.i8(i8 %604, i1 false)
  %606 = zext i8 %605 to i32
  %607 = select i1 %603, i32 %606, i32 0
  %.state1050 = load <8 x i64>, ptr %.slot111, align 64
  %608 = icmp slt <8 x i64> %.state1050, splat (i64 5)
  %609 = and <8 x i1> %602, %608
  %610 = xor <8 x i1> %608, splat (i1 true)
  %611 = and <8 x i1> %602, %610
  %612 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %609)
  %613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %611)
  %614 = and i1 %612, %613
  br i1 %614, label %varying.divergent1051, label %varying.coherent1052

schedule.50:                                      ; preds = %varying.coherent.true1057, %scheduler.dispatch.route
  %615 = load <8 x i1>, ptr %current.mask, align 1
  %616 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %615)
  %617 = bitcast <8 x i1> %615 to i8
  %618 = call i8 @llvm.cttz.i8(i8 %617, i1 false)
  %619 = zext i8 %618 to i32
  %620 = select i1 %616, i32 %619, i32 0
  %.state1059 = load <8 x i64>, ptr %.slot111, align 64
  %621 = select <8 x i1> %615, <8 x i64> %.state1059, <8 x i64> zeroinitializer
  %622 = select <8 x i1> %615, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %623 = sdiv <8 x i64> %621, %622
  %.spill.load1060 = load i64, ptr %.spill11, align 4
  %624 = add i64 %.spill.load1060, 0
  %625 = mul i64 %624, 1
  %626 = add i64 %625, 0
  %627 = mul i64 %626, 2
  %628 = add i64 %627, 0
  %629 = mul i64 %628, 5
  %.splatinsert1061 = insertelement <8 x i64> poison, i64 %629, i64 0
  %.splat1062 = shufflevector <8 x i64> %.splatinsert1061, <8 x i64> poison, <8 x i32> zeroinitializer
  %630 = add <8 x i64> %.splat1062, %623
  %631 = mul <8 x i64> %630, splat (i64 3)
  %632 = add <8 x i64> %631, zeroinitializer
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %633 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %634 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %635 = mul <8 x i64> %632, splat (i64 32)
  %636 = add <8 x i64> %634, %635
  %637 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %633, 0
  %638 = insertvalue { <8 x ptr>, <8 x i64> } %637, <8 x i64> %636, 1
  %639 = extractvalue { <8 x ptr>, <8 x i64> } %638, 0
  %640 = extractvalue { <8 x ptr>, <8 x i64> } %638, 1
  %641 = getelementptr i8, <8 x ptr> %639, <8 x i64> %640
  %642 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %641, <8 x i1> %615, <8 x float> zeroinitializer)
  %.state1063 = load <8 x float>, ptr %.slot112, align 32
  %643 = fadd <8 x float> %.state1063, %642
  %.state1064 = load <8 x i64>, ptr %.slot111, align 64
  %644 = add <8 x i64> %.state1064, splat (i64 1)
  %645 = load <8 x i64>, ptr %.slot111, align 64
  %646 = select <8 x i1> %615, <8 x i64> %644, <8 x i64> %645
  store <8 x i64> %646, ptr %.slot111, align 64
  %647 = load <8 x float>, ptr %.slot112, align 32
  %648 = select <8 x i1> %615, <8 x float> %643, <8 x float> %647
  store <8 x float> %648, ptr %.slot112, align 32
  store <8 x i1> %615, ptr %current.mask, align 1
  %649 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %615)
  br i1 %649, label %schedule.49, label %scheduler.loop

schedule.51:                                      ; preds = %varying.coherent.false1058, %scheduler.dispatch.route
  %650 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1067 = load i32, ptr %current.token, align 4
  %convergence.token.present1068 = icmp ne i32 %convergence.current.token1067, 0
  br i1 %convergence.token.present1068, label %convergence.cascade1065, label %convergence.cascade.exit1066

schedule.52:                                      ; preds = %schedule.53, %convergence.target.51.ready, %scheduler.dispatch.route
  %651 = load <8 x i1>, ptr %current.mask, align 1
  %652 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %651)
  %653 = bitcast <8 x i1> %651 to i8
  %654 = call i8 @llvm.cttz.i8(i8 %653, i1 false)
  %655 = zext i8 %654 to i32
  %656 = select i1 %652, i32 %655, i32 0
  %.state1082 = load <8 x i64>, ptr %.slot113, align 64
  %657 = icmp slt <8 x i64> %.state1082, splat (i64 5)
  %658 = and <8 x i1> %651, %657
  %659 = xor <8 x i1> %657, splat (i1 true)
  %660 = and <8 x i1> %651, %659
  %661 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %658)
  %662 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %660)
  %663 = and i1 %661, %662
  br i1 %663, label %varying.divergent1083, label %varying.coherent1084

schedule.53:                                      ; preds = %varying.coherent.true1089, %scheduler.dispatch.route
  %664 = load <8 x i1>, ptr %current.mask, align 1
  %665 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %664)
  %666 = bitcast <8 x i1> %664 to i8
  %667 = call i8 @llvm.cttz.i8(i8 %666, i1 false)
  %668 = zext i8 %667 to i32
  %669 = select i1 %665, i32 %668, i32 0
  %.state1091 = load <8 x i64>, ptr %.slot113, align 64
  %670 = select <8 x i1> %664, <8 x i64> %.state1091, <8 x i64> zeroinitializer
  %671 = select <8 x i1> %664, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %672 = sdiv <8 x i64> %670, %671
  %.spill.load1092 = load i64, ptr %.spill11, align 4
  %673 = add i64 %.spill.load1092, 0
  %674 = mul i64 %673, 1
  %675 = add i64 %674, 0
  %676 = mul i64 %675, 2
  %677 = add i64 %676, 0
  %678 = mul i64 %677, 5
  %.splatinsert1093 = insertelement <8 x i64> poison, i64 %678, i64 0
  %.splat1094 = shufflevector <8 x i64> %.splatinsert1093, <8 x i64> poison, <8 x i32> zeroinitializer
  %679 = add <8 x i64> %.splat1094, %672
  %680 = mul <8 x i64> %679, splat (i64 3)
  %681 = add <8 x i64> %680, splat (i64 1)
  %tile_snapshot.spill.load1095 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %682 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1095, 0
  %683 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1095, 1
  %684 = mul <8 x i64> %681, splat (i64 32)
  %685 = add <8 x i64> %683, %684
  %686 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %682, 0
  %687 = insertvalue { <8 x ptr>, <8 x i64> } %686, <8 x i64> %685, 1
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %687, 0
  %689 = extractvalue { <8 x ptr>, <8 x i64> } %687, 1
  %690 = getelementptr i8, <8 x ptr> %688, <8 x i64> %689
  %691 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %690, <8 x i1> %664, <8 x float> zeroinitializer)
  %.state1096 = load <8 x float>, ptr %.slot114, align 32
  %692 = fadd <8 x float> %.state1096, %691
  %.state1097 = load <8 x i64>, ptr %.slot113, align 64
  %693 = add <8 x i64> %.state1097, splat (i64 1)
  %694 = load <8 x i64>, ptr %.slot113, align 64
  %695 = select <8 x i1> %664, <8 x i64> %693, <8 x i64> %694
  store <8 x i64> %695, ptr %.slot113, align 64
  %696 = load <8 x float>, ptr %.slot114, align 32
  %697 = select <8 x i1> %664, <8 x float> %692, <8 x float> %696
  store <8 x float> %697, ptr %.slot114, align 32
  store <8 x i1> %664, ptr %current.mask, align 1
  %698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %664)
  br i1 %698, label %schedule.52, label %scheduler.loop

schedule.54:                                      ; preds = %varying.coherent.false1090, %scheduler.dispatch.route
  %699 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1100 = load i32, ptr %current.token, align 4
  %convergence.token.present1101 = icmp ne i32 %convergence.current.token1100, 0
  br i1 %convergence.token.present1101, label %convergence.cascade1098, label %convergence.cascade.exit1099

schedule.55:                                      ; preds = %schedule.56, %convergence.target.54.ready, %scheduler.dispatch.route
  %700 = load <8 x i1>, ptr %current.mask, align 1
  %701 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %700)
  %702 = bitcast <8 x i1> %700 to i8
  %703 = call i8 @llvm.cttz.i8(i8 %702, i1 false)
  %704 = zext i8 %703 to i32
  %705 = select i1 %701, i32 %704, i32 0
  %.state1115 = load <8 x i64>, ptr %.slot115, align 64
  %706 = icmp slt <8 x i64> %.state1115, splat (i64 5)
  %707 = and <8 x i1> %700, %706
  %708 = xor <8 x i1> %706, splat (i1 true)
  %709 = and <8 x i1> %700, %708
  %710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %707)
  %711 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %709)
  %712 = and i1 %710, %711
  br i1 %712, label %varying.divergent1116, label %varying.coherent1117

schedule.56:                                      ; preds = %varying.coherent.true1122, %scheduler.dispatch.route
  %713 = load <8 x i1>, ptr %current.mask, align 1
  %714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %713)
  %715 = bitcast <8 x i1> %713 to i8
  %716 = call i8 @llvm.cttz.i8(i8 %715, i1 false)
  %717 = zext i8 %716 to i32
  %718 = select i1 %714, i32 %717, i32 0
  %.state1124 = load <8 x i64>, ptr %.slot115, align 64
  %719 = select <8 x i1> %713, <8 x i64> %.state1124, <8 x i64> zeroinitializer
  %720 = select <8 x i1> %713, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %721 = sdiv <8 x i64> %719, %720
  %.spill.load1125 = load i64, ptr %.spill11, align 4
  %722 = add i64 %.spill.load1125, 0
  %723 = mul i64 %722, 1
  %724 = add i64 %723, 0
  %725 = mul i64 %724, 2
  %726 = add i64 %725, 0
  %727 = mul i64 %726, 5
  %.splatinsert1126 = insertelement <8 x i64> poison, i64 %727, i64 0
  %.splat1127 = shufflevector <8 x i64> %.splatinsert1126, <8 x i64> poison, <8 x i32> zeroinitializer
  %728 = add <8 x i64> %.splat1127, %721
  %729 = mul <8 x i64> %728, splat (i64 3)
  %730 = add <8 x i64> %729, splat (i64 2)
  %tile_snapshot.spill.load1128 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %731 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1128, 0
  %732 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1128, 1
  %733 = mul <8 x i64> %730, splat (i64 32)
  %734 = add <8 x i64> %732, %733
  %735 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %731, 0
  %736 = insertvalue { <8 x ptr>, <8 x i64> } %735, <8 x i64> %734, 1
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %736, 0
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %736, 1
  %739 = getelementptr i8, <8 x ptr> %737, <8 x i64> %738
  %740 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %739, <8 x i1> %713, <8 x float> zeroinitializer)
  %.state1129 = load <8 x float>, ptr %.slot116, align 32
  %741 = fadd <8 x float> %.state1129, %740
  %.state1130 = load <8 x i64>, ptr %.slot115, align 64
  %742 = add <8 x i64> %.state1130, splat (i64 1)
  %743 = load <8 x i64>, ptr %.slot115, align 64
  %744 = select <8 x i1> %713, <8 x i64> %742, <8 x i64> %743
  store <8 x i64> %744, ptr %.slot115, align 64
  %745 = load <8 x float>, ptr %.slot116, align 32
  %746 = select <8 x i1> %713, <8 x float> %741, <8 x float> %745
  store <8 x float> %746, ptr %.slot116, align 32
  store <8 x i1> %713, ptr %current.mask, align 1
  %747 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %713)
  br i1 %747, label %schedule.55, label %scheduler.loop

schedule.57:                                      ; preds = %varying.coherent.false1123, %scheduler.dispatch.route
  %748 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1133 = load i32, ptr %current.token, align 4
  %convergence.token.present1134 = icmp ne i32 %convergence.current.token1133, 0
  br i1 %convergence.token.present1134, label %convergence.cascade1131, label %convergence.cascade.exit1132

schedule.58:                                      ; preds = %schedule.59, %convergence.target.57.ready, %scheduler.dispatch.route
  %749 = load <8 x i1>, ptr %current.mask, align 1
  %750 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %749)
  %751 = bitcast <8 x i1> %749 to i8
  %752 = call i8 @llvm.cttz.i8(i8 %751, i1 false)
  %753 = zext i8 %752 to i32
  %754 = select i1 %750, i32 %753, i32 0
  %.state1148 = load <8 x i64>, ptr %.slot117, align 64
  %755 = icmp slt <8 x i64> %.state1148, splat (i64 5)
  %756 = and <8 x i1> %749, %755
  %757 = xor <8 x i1> %755, splat (i1 true)
  %758 = and <8 x i1> %749, %757
  %759 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %756)
  %760 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %758)
  %761 = and i1 %759, %760
  br i1 %761, label %varying.divergent1149, label %varying.coherent1150

schedule.59:                                      ; preds = %varying.coherent.true1155, %scheduler.dispatch.route
  %762 = load <8 x i1>, ptr %current.mask, align 1
  %763 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %762)
  %764 = bitcast <8 x i1> %762 to i8
  %765 = call i8 @llvm.cttz.i8(i8 %764, i1 false)
  %766 = zext i8 %765 to i32
  %767 = select i1 %763, i32 %766, i32 0
  %.state1157 = load <8 x i64>, ptr %.slot117, align 64
  %768 = select <8 x i1> %762, <8 x i64> %.state1157, <8 x i64> zeroinitializer
  %769 = select <8 x i1> %762, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %770 = sdiv <8 x i64> %768, %769
  %.spill.load1158 = load i64, ptr %.spill11, align 4
  %771 = add i64 %.spill.load1158, 0
  %772 = mul i64 %771, 1
  %773 = add i64 %772, 0
  %774 = mul i64 %773, 2
  %775 = add i64 %774, 1
  %776 = mul i64 %775, 5
  %.splatinsert1159 = insertelement <8 x i64> poison, i64 %776, i64 0
  %.splat1160 = shufflevector <8 x i64> %.splatinsert1159, <8 x i64> poison, <8 x i32> zeroinitializer
  %777 = add <8 x i64> %.splat1160, %770
  %778 = mul <8 x i64> %777, splat (i64 3)
  %779 = add <8 x i64> %778, zeroinitializer
  %tile_snapshot.spill.load1161 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %780 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1161, 0
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1161, 1
  %782 = mul <8 x i64> %779, splat (i64 32)
  %783 = add <8 x i64> %781, %782
  %784 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %780, 0
  %785 = insertvalue { <8 x ptr>, <8 x i64> } %784, <8 x i64> %783, 1
  %786 = extractvalue { <8 x ptr>, <8 x i64> } %785, 0
  %787 = extractvalue { <8 x ptr>, <8 x i64> } %785, 1
  %788 = getelementptr i8, <8 x ptr> %786, <8 x i64> %787
  %789 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %788, <8 x i1> %762, <8 x float> zeroinitializer)
  %.state1162 = load <8 x float>, ptr %.slot118, align 32
  %790 = fadd <8 x float> %.state1162, %789
  %.state1163 = load <8 x i64>, ptr %.slot117, align 64
  %791 = add <8 x i64> %.state1163, splat (i64 1)
  %792 = load <8 x i64>, ptr %.slot117, align 64
  %793 = select <8 x i1> %762, <8 x i64> %791, <8 x i64> %792
  store <8 x i64> %793, ptr %.slot117, align 64
  %794 = load <8 x float>, ptr %.slot118, align 32
  %795 = select <8 x i1> %762, <8 x float> %790, <8 x float> %794
  store <8 x float> %795, ptr %.slot118, align 32
  store <8 x i1> %762, ptr %current.mask, align 1
  %796 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %762)
  br i1 %796, label %schedule.58, label %scheduler.loop

schedule.60:                                      ; preds = %varying.coherent.false1156, %scheduler.dispatch.route
  %797 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1166 = load i32, ptr %current.token, align 4
  %convergence.token.present1167 = icmp ne i32 %convergence.current.token1166, 0
  br i1 %convergence.token.present1167, label %convergence.cascade1164, label %convergence.cascade.exit1165

schedule.61:                                      ; preds = %schedule.62, %convergence.target.60.ready, %scheduler.dispatch.route
  %798 = load <8 x i1>, ptr %current.mask, align 1
  %799 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %798)
  %800 = bitcast <8 x i1> %798 to i8
  %801 = call i8 @llvm.cttz.i8(i8 %800, i1 false)
  %802 = zext i8 %801 to i32
  %803 = select i1 %799, i32 %802, i32 0
  %.state1181 = load <8 x i64>, ptr %.slot119, align 64
  %804 = icmp slt <8 x i64> %.state1181, splat (i64 5)
  %805 = and <8 x i1> %798, %804
  %806 = xor <8 x i1> %804, splat (i1 true)
  %807 = and <8 x i1> %798, %806
  %808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %805)
  %809 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %807)
  %810 = and i1 %808, %809
  br i1 %810, label %varying.divergent1182, label %varying.coherent1183

schedule.62:                                      ; preds = %varying.coherent.true1188, %scheduler.dispatch.route
  %811 = load <8 x i1>, ptr %current.mask, align 1
  %812 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %811)
  %813 = bitcast <8 x i1> %811 to i8
  %814 = call i8 @llvm.cttz.i8(i8 %813, i1 false)
  %815 = zext i8 %814 to i32
  %816 = select i1 %812, i32 %815, i32 0
  %.state1190 = load <8 x i64>, ptr %.slot119, align 64
  %817 = select <8 x i1> %811, <8 x i64> %.state1190, <8 x i64> zeroinitializer
  %818 = select <8 x i1> %811, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %819 = sdiv <8 x i64> %817, %818
  %.spill.load1191 = load i64, ptr %.spill11, align 4
  %820 = add i64 %.spill.load1191, 0
  %821 = mul i64 %820, 1
  %822 = add i64 %821, 0
  %823 = mul i64 %822, 2
  %824 = add i64 %823, 1
  %825 = mul i64 %824, 5
  %.splatinsert1192 = insertelement <8 x i64> poison, i64 %825, i64 0
  %.splat1193 = shufflevector <8 x i64> %.splatinsert1192, <8 x i64> poison, <8 x i32> zeroinitializer
  %826 = add <8 x i64> %.splat1193, %819
  %827 = mul <8 x i64> %826, splat (i64 3)
  %828 = add <8 x i64> %827, splat (i64 1)
  %tile_snapshot.spill.load1194 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %829 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1194, 0
  %830 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1194, 1
  %831 = mul <8 x i64> %828, splat (i64 32)
  %832 = add <8 x i64> %830, %831
  %833 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %829, 0
  %834 = insertvalue { <8 x ptr>, <8 x i64> } %833, <8 x i64> %832, 1
  %835 = extractvalue { <8 x ptr>, <8 x i64> } %834, 0
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %834, 1
  %837 = getelementptr i8, <8 x ptr> %835, <8 x i64> %836
  %838 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %837, <8 x i1> %811, <8 x float> zeroinitializer)
  %.state1195 = load <8 x float>, ptr %.slot120, align 32
  %839 = fadd <8 x float> %.state1195, %838
  %.state1196 = load <8 x i64>, ptr %.slot119, align 64
  %840 = add <8 x i64> %.state1196, splat (i64 1)
  %841 = load <8 x i64>, ptr %.slot119, align 64
  %842 = select <8 x i1> %811, <8 x i64> %840, <8 x i64> %841
  store <8 x i64> %842, ptr %.slot119, align 64
  %843 = load <8 x float>, ptr %.slot120, align 32
  %844 = select <8 x i1> %811, <8 x float> %839, <8 x float> %843
  store <8 x float> %844, ptr %.slot120, align 32
  store <8 x i1> %811, ptr %current.mask, align 1
  %845 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %811)
  br i1 %845, label %schedule.61, label %scheduler.loop

schedule.63:                                      ; preds = %varying.coherent.false1189, %scheduler.dispatch.route
  %846 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1199 = load i32, ptr %current.token, align 4
  %convergence.token.present1200 = icmp ne i32 %convergence.current.token1199, 0
  br i1 %convergence.token.present1200, label %convergence.cascade1197, label %convergence.cascade.exit1198

schedule.64:                                      ; preds = %schedule.65, %convergence.target.63.ready, %scheduler.dispatch.route
  %847 = load <8 x i1>, ptr %current.mask, align 1
  %848 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %847)
  %849 = bitcast <8 x i1> %847 to i8
  %850 = call i8 @llvm.cttz.i8(i8 %849, i1 false)
  %851 = zext i8 %850 to i32
  %852 = select i1 %848, i32 %851, i32 0
  %.state1214 = load <8 x i64>, ptr %.slot121, align 64
  %853 = icmp slt <8 x i64> %.state1214, splat (i64 5)
  %854 = and <8 x i1> %847, %853
  %855 = xor <8 x i1> %853, splat (i1 true)
  %856 = and <8 x i1> %847, %855
  %857 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %854)
  %858 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %856)
  %859 = and i1 %857, %858
  br i1 %859, label %varying.divergent1215, label %varying.coherent1216

schedule.65:                                      ; preds = %varying.coherent.true1221, %scheduler.dispatch.route
  %860 = load <8 x i1>, ptr %current.mask, align 1
  %861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %860)
  %862 = bitcast <8 x i1> %860 to i8
  %863 = call i8 @llvm.cttz.i8(i8 %862, i1 false)
  %864 = zext i8 %863 to i32
  %865 = select i1 %861, i32 %864, i32 0
  %.state1223 = load <8 x i64>, ptr %.slot121, align 64
  %866 = select <8 x i1> %860, <8 x i64> %.state1223, <8 x i64> zeroinitializer
  %867 = select <8 x i1> %860, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %868 = sdiv <8 x i64> %866, %867
  %.spill.load1224 = load i64, ptr %.spill11, align 4
  %869 = add i64 %.spill.load1224, 0
  %870 = mul i64 %869, 1
  %871 = add i64 %870, 0
  %872 = mul i64 %871, 2
  %873 = add i64 %872, 1
  %874 = mul i64 %873, 5
  %.splatinsert1225 = insertelement <8 x i64> poison, i64 %874, i64 0
  %.splat1226 = shufflevector <8 x i64> %.splatinsert1225, <8 x i64> poison, <8 x i32> zeroinitializer
  %875 = add <8 x i64> %.splat1226, %868
  %876 = mul <8 x i64> %875, splat (i64 3)
  %877 = add <8 x i64> %876, splat (i64 2)
  %tile_snapshot.spill.load1227 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %878 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1227, 0
  %879 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1227, 1
  %880 = mul <8 x i64> %877, splat (i64 32)
  %881 = add <8 x i64> %879, %880
  %882 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %878, 0
  %883 = insertvalue { <8 x ptr>, <8 x i64> } %882, <8 x i64> %881, 1
  %884 = extractvalue { <8 x ptr>, <8 x i64> } %883, 0
  %885 = extractvalue { <8 x ptr>, <8 x i64> } %883, 1
  %886 = getelementptr i8, <8 x ptr> %884, <8 x i64> %885
  %887 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %886, <8 x i1> %860, <8 x float> zeroinitializer)
  %.state1228 = load <8 x float>, ptr %.slot122, align 32
  %888 = fadd <8 x float> %.state1228, %887
  %.state1229 = load <8 x i64>, ptr %.slot121, align 64
  %889 = add <8 x i64> %.state1229, splat (i64 1)
  %890 = load <8 x i64>, ptr %.slot121, align 64
  %891 = select <8 x i1> %860, <8 x i64> %889, <8 x i64> %890
  store <8 x i64> %891, ptr %.slot121, align 64
  %892 = load <8 x float>, ptr %.slot122, align 32
  %893 = select <8 x i1> %860, <8 x float> %888, <8 x float> %892
  store <8 x float> %893, ptr %.slot122, align 32
  store <8 x i1> %860, ptr %current.mask, align 1
  %894 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %860)
  br i1 %894, label %schedule.64, label %scheduler.loop

schedule.66:                                      ; preds = %varying.coherent.false1222, %scheduler.dispatch.route
  %895 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1232 = load i32, ptr %current.token, align 4
  %convergence.token.present1233 = icmp ne i32 %convergence.current.token1232, 0
  br i1 %convergence.token.present1233, label %convergence.cascade1230, label %convergence.cascade.exit1231

schedule.67:                                      ; preds = %schedule.68, %convergence.target.66.ready, %scheduler.dispatch.route
  %896 = load <8 x i1>, ptr %current.mask, align 1
  %897 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %896)
  %898 = bitcast <8 x i1> %896 to i8
  %899 = call i8 @llvm.cttz.i8(i8 %898, i1 false)
  %900 = zext i8 %899 to i32
  %901 = select i1 %897, i32 %900, i32 0
  %.state1278 = load <8 x i64>, ptr %.slot136, align 64
  %902 = icmp slt <8 x i64> %.state1278, splat (i64 3)
  %903 = and <8 x i1> %896, %902
  %904 = xor <8 x i1> %902, splat (i1 true)
  %905 = and <8 x i1> %896, %904
  %906 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %903)
  %907 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %905)
  %908 = and i1 %906, %907
  br i1 %908, label %varying.divergent1279, label %varying.coherent1280

schedule.68:                                      ; preds = %varying.coherent.true1285, %scheduler.dispatch.route
  %909 = load <8 x i1>, ptr %current.mask, align 1
  %910 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %909)
  %911 = bitcast <8 x i1> %909 to i8
  %912 = call i8 @llvm.cttz.i8(i8 %911, i1 false)
  %913 = zext i8 %912 to i32
  %914 = select i1 %910, i32 %913, i32 0
  %.state1287 = load <8 x i64>, ptr %.slot136, align 64
  %915 = select <8 x i1> %909, <8 x i64> %.state1287, <8 x i64> zeroinitializer
  %916 = select <8 x i1> %909, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %917 = sdiv <8 x i64> %915, %916
  %.spill.load1288 = load i64, ptr %.spill11, align 4
  %918 = add i64 %.spill.load1288, 0
  %919 = mul i64 %918, 1
  %920 = add i64 %919, 0
  %921 = mul i64 %920, 2
  %922 = add i64 %921, 0
  %923 = mul i64 %922, 3
  %.splatinsert1289 = insertelement <8 x i64> poison, i64 %923, i64 0
  %.splat1290 = shufflevector <8 x i64> %.splatinsert1289, <8 x i64> poison, <8 x i32> zeroinitializer
  %924 = add <8 x i64> %.splat1290, %917
  %tile_snapshot.spill.load1291 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill135, align 64
  %925 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1291, 0
  %926 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1291, 1
  %927 = mul <8 x i64> %924, splat (i64 32)
  %928 = add <8 x i64> %926, %927
  %929 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %925, 0
  %930 = insertvalue { <8 x ptr>, <8 x i64> } %929, <8 x i64> %928, 1
  %931 = extractvalue { <8 x ptr>, <8 x i64> } %930, 0
  %932 = extractvalue { <8 x ptr>, <8 x i64> } %930, 1
  %933 = getelementptr i8, <8 x ptr> %931, <8 x i64> %932
  %934 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %933, <8 x i1> %909, <8 x float> zeroinitializer)
  %.state1292 = load <8 x float>, ptr %.slot137, align 32
  %935 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1292, <8 x float> %934)
  %.state1293 = load <8 x i64>, ptr %.slot136, align 64
  %936 = add <8 x i64> %.state1293, splat (i64 1)
  %937 = load <8 x i64>, ptr %.slot136, align 64
  %938 = select <8 x i1> %909, <8 x i64> %936, <8 x i64> %937
  store <8 x i64> %938, ptr %.slot136, align 64
  %939 = load <8 x float>, ptr %.slot137, align 32
  %940 = select <8 x i1> %909, <8 x float> %935, <8 x float> %939
  store <8 x float> %940, ptr %.slot137, align 32
  store <8 x i1> %909, ptr %current.mask, align 1
  %941 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %909)
  br i1 %941, label %schedule.67, label %scheduler.loop

schedule.69:                                      ; preds = %varying.coherent.false1286, %scheduler.dispatch.route
  %942 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1296 = load i32, ptr %current.token, align 4
  %convergence.token.present1297 = icmp ne i32 %convergence.current.token1296, 0
  br i1 %convergence.token.present1297, label %convergence.cascade1294, label %convergence.cascade.exit1295

schedule.70:                                      ; preds = %schedule.71, %convergence.target.69.ready, %scheduler.dispatch.route
  %943 = load <8 x i1>, ptr %current.mask, align 1
  %944 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %943)
  %945 = bitcast <8 x i1> %943 to i8
  %946 = call i8 @llvm.cttz.i8(i8 %945, i1 false)
  %947 = zext i8 %946 to i32
  %948 = select i1 %944, i32 %947, i32 0
  %.state1311 = load <8 x i64>, ptr %.slot138, align 64
  %949 = icmp slt <8 x i64> %.state1311, splat (i64 3)
  %950 = and <8 x i1> %943, %949
  %951 = xor <8 x i1> %949, splat (i1 true)
  %952 = and <8 x i1> %943, %951
  %953 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %950)
  %954 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %952)
  %955 = and i1 %953, %954
  br i1 %955, label %varying.divergent1312, label %varying.coherent1313

schedule.71:                                      ; preds = %varying.coherent.true1318, %scheduler.dispatch.route
  %956 = load <8 x i1>, ptr %current.mask, align 1
  %957 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %956)
  %958 = bitcast <8 x i1> %956 to i8
  %959 = call i8 @llvm.cttz.i8(i8 %958, i1 false)
  %960 = zext i8 %959 to i32
  %961 = select i1 %957, i32 %960, i32 0
  %.state1320 = load <8 x i64>, ptr %.slot138, align 64
  %962 = select <8 x i1> %956, <8 x i64> %.state1320, <8 x i64> zeroinitializer
  %963 = select <8 x i1> %956, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %964 = sdiv <8 x i64> %962, %963
  %.spill.load1321 = load i64, ptr %.spill11, align 4
  %965 = add i64 %.spill.load1321, 0
  %966 = mul i64 %965, 1
  %967 = add i64 %966, 0
  %968 = mul i64 %967, 2
  %969 = add i64 %968, 1
  %970 = mul i64 %969, 3
  %.splatinsert1322 = insertelement <8 x i64> poison, i64 %970, i64 0
  %.splat1323 = shufflevector <8 x i64> %.splatinsert1322, <8 x i64> poison, <8 x i32> zeroinitializer
  %971 = add <8 x i64> %.splat1323, %964
  %tile_snapshot.spill.load1324 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill135, align 64
  %972 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1324, 0
  %973 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1324, 1
  %974 = mul <8 x i64> %971, splat (i64 32)
  %975 = add <8 x i64> %973, %974
  %976 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %972, 0
  %977 = insertvalue { <8 x ptr>, <8 x i64> } %976, <8 x i64> %975, 1
  %978 = extractvalue { <8 x ptr>, <8 x i64> } %977, 0
  %979 = extractvalue { <8 x ptr>, <8 x i64> } %977, 1
  %980 = getelementptr i8, <8 x ptr> %978, <8 x i64> %979
  %981 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %980, <8 x i1> %956, <8 x float> zeroinitializer)
  %.state1325 = load <8 x float>, ptr %.slot139, align 32
  %982 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1325, <8 x float> %981)
  %.state1326 = load <8 x i64>, ptr %.slot138, align 64
  %983 = add <8 x i64> %.state1326, splat (i64 1)
  %984 = load <8 x i64>, ptr %.slot138, align 64
  %985 = select <8 x i1> %956, <8 x i64> %983, <8 x i64> %984
  store <8 x i64> %985, ptr %.slot138, align 64
  %986 = load <8 x float>, ptr %.slot139, align 32
  %987 = select <8 x i1> %956, <8 x float> %982, <8 x float> %986
  store <8 x float> %987, ptr %.slot139, align 32
  store <8 x i1> %956, ptr %current.mask, align 1
  %988 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %956)
  br i1 %988, label %schedule.70, label %scheduler.loop

schedule.72:                                      ; preds = %varying.coherent.false1319, %scheduler.dispatch.route
  %989 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1329 = load i32, ptr %current.token, align 4
  %convergence.token.present1330 = icmp ne i32 %convergence.current.token1329, 0
  br i1 %convergence.token.present1330, label %convergence.cascade1327, label %convergence.cascade.exit1328

schedule.73:                                      ; preds = %schedule.74, %convergence.target.72.ready, %scheduler.dispatch.route
  %990 = load <8 x i1>, ptr %current.mask, align 1
  %991 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %990)
  %992 = bitcast <8 x i1> %990 to i8
  %993 = call i8 @llvm.cttz.i8(i8 %992, i1 false)
  %994 = zext i8 %993 to i32
  %995 = select i1 %991, i32 %994, i32 0
  %.state1383 = load <8 x i64>, ptr %.slot153, align 64
  %996 = icmp slt <8 x i64> %.state1383, splat (i64 3)
  %997 = and <8 x i1> %990, %996
  %998 = xor <8 x i1> %996, splat (i1 true)
  %999 = and <8 x i1> %990, %998
  %1000 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %997)
  %1001 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %999)
  %1002 = and i1 %1000, %1001
  br i1 %1002, label %varying.divergent1384, label %varying.coherent1385

schedule.74:                                      ; preds = %varying.coherent.true1390, %scheduler.dispatch.route
  %1003 = load <8 x i1>, ptr %current.mask, align 1
  %1004 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1003)
  %1005 = bitcast <8 x i1> %1003 to i8
  %1006 = call i8 @llvm.cttz.i8(i8 %1005, i1 false)
  %1007 = zext i8 %1006 to i32
  %1008 = select i1 %1004, i32 %1007, i32 0
  %.state1392 = load <8 x i64>, ptr %.slot153, align 64
  %1009 = select <8 x i1> %1003, <8 x i64> %.state1392, <8 x i64> zeroinitializer
  %1010 = select <8 x i1> %1003, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1011 = sdiv <8 x i64> %1009, %1010
  %.spill.load1393 = load i64, ptr %.spill11, align 4
  %1012 = add i64 %.spill.load1393, 0
  %1013 = mul i64 %1012, 1
  %1014 = add i64 %1013, 0
  %1015 = mul i64 %1014, 2
  %1016 = add i64 %1015, 0
  %1017 = mul i64 %1016, 3
  %.splatinsert1394 = insertelement <8 x i64> poison, i64 %1017, i64 0
  %.splat1395 = shufflevector <8 x i64> %.splatinsert1394, <8 x i64> poison, <8 x i32> zeroinitializer
  %1018 = add <8 x i64> %.splat1395, %1011
  %tile_snapshot.spill.load1396 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill150, align 64
  %1019 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1396, 0
  %1020 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1396, 1
  %1021 = mul <8 x i64> %1018, splat (i64 32)
  %1022 = add <8 x i64> %1020, %1021
  %1023 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1019, 0
  %1024 = insertvalue { <8 x ptr>, <8 x i64> } %1023, <8 x i64> %1022, 1
  %1025 = extractvalue { <8 x ptr>, <8 x i64> } %1024, 0
  %1026 = extractvalue { <8 x ptr>, <8 x i64> } %1024, 1
  %1027 = getelementptr i8, <8 x ptr> %1025, <8 x i64> %1026
  %1028 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1027, <8 x i1> %1003, <8 x float> zeroinitializer)
  %.state1397 = load <8 x float>, ptr %.slot154, align 32
  %1029 = fadd <8 x float> %.state1397, %1028
  %.state1398 = load <8 x i64>, ptr %.slot153, align 64
  %1030 = add <8 x i64> %.state1398, splat (i64 1)
  %1031 = load <8 x i64>, ptr %.slot153, align 64
  %1032 = select <8 x i1> %1003, <8 x i64> %1030, <8 x i64> %1031
  store <8 x i64> %1032, ptr %.slot153, align 64
  %1033 = load <8 x float>, ptr %.slot154, align 32
  %1034 = select <8 x i1> %1003, <8 x float> %1029, <8 x float> %1033
  store <8 x float> %1034, ptr %.slot154, align 32
  store <8 x i1> %1003, ptr %current.mask, align 1
  %1035 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1003)
  br i1 %1035, label %schedule.73, label %scheduler.loop

schedule.75:                                      ; preds = %varying.coherent.false1391, %scheduler.dispatch.route
  %1036 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1401 = load i32, ptr %current.token, align 4
  %convergence.token.present1402 = icmp ne i32 %convergence.current.token1401, 0
  br i1 %convergence.token.present1402, label %convergence.cascade1399, label %convergence.cascade.exit1400

schedule.76:                                      ; preds = %schedule.77, %convergence.target.75.ready, %scheduler.dispatch.route
  %1037 = load <8 x i1>, ptr %current.mask, align 1
  %1038 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1037)
  %1039 = bitcast <8 x i1> %1037 to i8
  %1040 = call i8 @llvm.cttz.i8(i8 %1039, i1 false)
  %1041 = zext i8 %1040 to i32
  %1042 = select i1 %1038, i32 %1041, i32 0
  %.state1416 = load <8 x i64>, ptr %.slot155, align 64
  %1043 = icmp slt <8 x i64> %.state1416, splat (i64 3)
  %1044 = and <8 x i1> %1037, %1043
  %1045 = xor <8 x i1> %1043, splat (i1 true)
  %1046 = and <8 x i1> %1037, %1045
  %1047 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1044)
  %1048 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1046)
  %1049 = and i1 %1047, %1048
  br i1 %1049, label %varying.divergent1417, label %varying.coherent1418

schedule.77:                                      ; preds = %varying.coherent.true1423, %scheduler.dispatch.route
  %1050 = load <8 x i1>, ptr %current.mask, align 1
  %1051 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1050)
  %1052 = bitcast <8 x i1> %1050 to i8
  %1053 = call i8 @llvm.cttz.i8(i8 %1052, i1 false)
  %1054 = zext i8 %1053 to i32
  %1055 = select i1 %1051, i32 %1054, i32 0
  %.state1425 = load <8 x i64>, ptr %.slot155, align 64
  %1056 = select <8 x i1> %1050, <8 x i64> %.state1425, <8 x i64> zeroinitializer
  %1057 = select <8 x i1> %1050, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1058 = sdiv <8 x i64> %1056, %1057
  %.spill.load1426 = load i64, ptr %.spill11, align 4
  %1059 = add i64 %.spill.load1426, 0
  %1060 = mul i64 %1059, 1
  %1061 = add i64 %1060, 0
  %1062 = mul i64 %1061, 2
  %1063 = add i64 %1062, 1
  %1064 = mul i64 %1063, 3
  %.splatinsert1427 = insertelement <8 x i64> poison, i64 %1064, i64 0
  %.splat1428 = shufflevector <8 x i64> %.splatinsert1427, <8 x i64> poison, <8 x i32> zeroinitializer
  %1065 = add <8 x i64> %.splat1428, %1058
  %tile_snapshot.spill.load1429 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill150, align 64
  %1066 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1429, 0
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1429, 1
  %1068 = mul <8 x i64> %1065, splat (i64 32)
  %1069 = add <8 x i64> %1067, %1068
  %1070 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1066, 0
  %1071 = insertvalue { <8 x ptr>, <8 x i64> } %1070, <8 x i64> %1069, 1
  %1072 = extractvalue { <8 x ptr>, <8 x i64> } %1071, 0
  %1073 = extractvalue { <8 x ptr>, <8 x i64> } %1071, 1
  %1074 = getelementptr i8, <8 x ptr> %1072, <8 x i64> %1073
  %1075 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1074, <8 x i1> %1050, <8 x float> zeroinitializer)
  %.state1430 = load <8 x float>, ptr %.slot156, align 32
  %1076 = fadd <8 x float> %.state1430, %1075
  %.state1431 = load <8 x i64>, ptr %.slot155, align 64
  %1077 = add <8 x i64> %.state1431, splat (i64 1)
  %1078 = load <8 x i64>, ptr %.slot155, align 64
  %1079 = select <8 x i1> %1050, <8 x i64> %1077, <8 x i64> %1078
  store <8 x i64> %1079, ptr %.slot155, align 64
  %1080 = load <8 x float>, ptr %.slot156, align 32
  %1081 = select <8 x i1> %1050, <8 x float> %1076, <8 x float> %1080
  store <8 x float> %1081, ptr %.slot156, align 32
  store <8 x i1> %1050, ptr %current.mask, align 1
  %1082 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1050)
  br i1 %1082, label %schedule.76, label %scheduler.loop

schedule.78:                                      ; preds = %varying.coherent.false1424, %scheduler.dispatch.route
  %1083 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1434 = load i32, ptr %current.token, align 4
  %convergence.token.present1435 = icmp ne i32 %convergence.current.token1434, 0
  br i1 %convergence.token.present1435, label %convergence.cascade1432, label %convergence.cascade.exit1433

schedule.79:                                      ; preds = %schedule.80, %convergence.target.78.ready, %scheduler.dispatch.route
  %1084 = load <8 x i1>, ptr %current.mask, align 1
  %1085 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1084)
  %1086 = bitcast <8 x i1> %1084 to i8
  %1087 = call i8 @llvm.cttz.i8(i8 %1086, i1 false)
  %1088 = zext i8 %1087 to i32
  %1089 = select i1 %1085, i32 %1088, i32 0
  %.state1565 = load <8 x i64>, ptr %.slot168, align 64
  %1090 = icmp slt <8 x i64> %.state1565, splat (i64 3)
  %1091 = and <8 x i1> %1084, %1090
  %1092 = xor <8 x i1> %1090, splat (i1 true)
  %1093 = and <8 x i1> %1084, %1092
  %1094 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1091)
  %1095 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1093)
  %1096 = and i1 %1094, %1095
  br i1 %1096, label %varying.divergent1566, label %varying.coherent1567

schedule.80:                                      ; preds = %varying.coherent.true1572, %scheduler.dispatch.route
  %1097 = load <8 x i1>, ptr %current.mask, align 1
  %1098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1097)
  %1099 = bitcast <8 x i1> %1097 to i8
  %1100 = call i8 @llvm.cttz.i8(i8 %1099, i1 false)
  %1101 = zext i8 %1100 to i32
  %1102 = select i1 %1098, i32 %1101, i32 0
  %.state1574 = load <8 x i64>, ptr %.slot168, align 64
  %1103 = select <8 x i1> %1097, <8 x i64> %.state1574, <8 x i64> zeroinitializer
  %1104 = select <8 x i1> %1097, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1105 = sdiv <8 x i64> %1103, %1104
  %.spill.load1575 = load i64, ptr %.spill11, align 4
  %1106 = add i64 %.spill.load1575, 0
  %1107 = mul i64 %1106, 1
  %1108 = add i64 %1107, 0
  %1109 = mul i64 %1108, 2
  %1110 = add i64 %1109, 0
  %1111 = mul i64 %1110, 3
  %.splatinsert1576 = insertelement <8 x i64> poison, i64 %1111, i64 0
  %.splat1577 = shufflevector <8 x i64> %.splatinsert1576, <8 x i64> poison, <8 x i32> zeroinitializer
  %1112 = add <8 x i64> %.splat1577, %1105
  %1113 = mul <8 x i64> %1112, splat (i64 4)
  %1114 = add <8 x i64> %1113, zeroinitializer
  %tile_snapshot.spill.load1578 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1578, 0
  %1116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1578, 1
  %1117 = mul <8 x i64> %1114, splat (i64 32)
  %1118 = add <8 x i64> %1116, %1117
  %1119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1115, 0
  %1120 = insertvalue { <8 x ptr>, <8 x i64> } %1119, <8 x i64> %1118, 1
  %1121 = extractvalue { <8 x ptr>, <8 x i64> } %1120, 0
  %1122 = extractvalue { <8 x ptr>, <8 x i64> } %1120, 1
  %1123 = getelementptr i8, <8 x ptr> %1121, <8 x i64> %1122
  %1124 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1123, <8 x i1> %1097, <8 x float> zeroinitializer)
  %.state1579 = load <8 x float>, ptr %.slot169, align 32
  %1125 = fadd <8 x float> %.state1579, %1124
  %.state1580 = load <8 x i64>, ptr %.slot168, align 64
  %1126 = add <8 x i64> %.state1580, splat (i64 1)
  %1127 = load <8 x i64>, ptr %.slot168, align 64
  %1128 = select <8 x i1> %1097, <8 x i64> %1126, <8 x i64> %1127
  store <8 x i64> %1128, ptr %.slot168, align 64
  %1129 = load <8 x float>, ptr %.slot169, align 32
  %1130 = select <8 x i1> %1097, <8 x float> %1125, <8 x float> %1129
  store <8 x float> %1130, ptr %.slot169, align 32
  store <8 x i1> %1097, ptr %current.mask, align 1
  %1131 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1097)
  br i1 %1131, label %schedule.79, label %scheduler.loop

schedule.81:                                      ; preds = %varying.coherent.false1573, %scheduler.dispatch.route
  %1132 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1583 = load i32, ptr %current.token, align 4
  %convergence.token.present1584 = icmp ne i32 %convergence.current.token1583, 0
  br i1 %convergence.token.present1584, label %convergence.cascade1581, label %convergence.cascade.exit1582

schedule.82:                                      ; preds = %schedule.83, %convergence.target.81.ready, %scheduler.dispatch.route
  %1133 = load <8 x i1>, ptr %current.mask, align 1
  %1134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1133)
  %1135 = bitcast <8 x i1> %1133 to i8
  %1136 = call i8 @llvm.cttz.i8(i8 %1135, i1 false)
  %1137 = zext i8 %1136 to i32
  %1138 = select i1 %1134, i32 %1137, i32 0
  %.state1598 = load <8 x i64>, ptr %.slot170, align 64
  %1139 = icmp slt <8 x i64> %.state1598, splat (i64 3)
  %1140 = and <8 x i1> %1133, %1139
  %1141 = xor <8 x i1> %1139, splat (i1 true)
  %1142 = and <8 x i1> %1133, %1141
  %1143 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1140)
  %1144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1142)
  %1145 = and i1 %1143, %1144
  br i1 %1145, label %varying.divergent1599, label %varying.coherent1600

schedule.83:                                      ; preds = %varying.coherent.true1605, %scheduler.dispatch.route
  %1146 = load <8 x i1>, ptr %current.mask, align 1
  %1147 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1146)
  %1148 = bitcast <8 x i1> %1146 to i8
  %1149 = call i8 @llvm.cttz.i8(i8 %1148, i1 false)
  %1150 = zext i8 %1149 to i32
  %1151 = select i1 %1147, i32 %1150, i32 0
  %.state1607 = load <8 x i64>, ptr %.slot170, align 64
  %1152 = select <8 x i1> %1146, <8 x i64> %.state1607, <8 x i64> zeroinitializer
  %1153 = select <8 x i1> %1146, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1154 = sdiv <8 x i64> %1152, %1153
  %.spill.load1608 = load i64, ptr %.spill11, align 4
  %1155 = add i64 %.spill.load1608, 0
  %1156 = mul i64 %1155, 1
  %1157 = add i64 %1156, 0
  %1158 = mul i64 %1157, 2
  %1159 = add i64 %1158, 0
  %1160 = mul i64 %1159, 3
  %.splatinsert1609 = insertelement <8 x i64> poison, i64 %1160, i64 0
  %.splat1610 = shufflevector <8 x i64> %.splatinsert1609, <8 x i64> poison, <8 x i32> zeroinitializer
  %1161 = add <8 x i64> %.splat1610, %1154
  %1162 = mul <8 x i64> %1161, splat (i64 4)
  %1163 = add <8 x i64> %1162, splat (i64 1)
  %tile_snapshot.spill.load1611 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %1164 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1611, 0
  %1165 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1611, 1
  %1166 = mul <8 x i64> %1163, splat (i64 32)
  %1167 = add <8 x i64> %1165, %1166
  %1168 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1164, 0
  %1169 = insertvalue { <8 x ptr>, <8 x i64> } %1168, <8 x i64> %1167, 1
  %1170 = extractvalue { <8 x ptr>, <8 x i64> } %1169, 0
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %1169, 1
  %1172 = getelementptr i8, <8 x ptr> %1170, <8 x i64> %1171
  %1173 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1172, <8 x i1> %1146, <8 x float> zeroinitializer)
  %.state1612 = load <8 x float>, ptr %.slot171, align 32
  %1174 = fadd <8 x float> %.state1612, %1173
  %.state1613 = load <8 x i64>, ptr %.slot170, align 64
  %1175 = add <8 x i64> %.state1613, splat (i64 1)
  %1176 = load <8 x i64>, ptr %.slot170, align 64
  %1177 = select <8 x i1> %1146, <8 x i64> %1175, <8 x i64> %1176
  store <8 x i64> %1177, ptr %.slot170, align 64
  %1178 = load <8 x float>, ptr %.slot171, align 32
  %1179 = select <8 x i1> %1146, <8 x float> %1174, <8 x float> %1178
  store <8 x float> %1179, ptr %.slot171, align 32
  store <8 x i1> %1146, ptr %current.mask, align 1
  %1180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1146)
  br i1 %1180, label %schedule.82, label %scheduler.loop

schedule.84:                                      ; preds = %varying.coherent.false1606, %scheduler.dispatch.route
  %1181 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1616 = load i32, ptr %current.token, align 4
  %convergence.token.present1617 = icmp ne i32 %convergence.current.token1616, 0
  br i1 %convergence.token.present1617, label %convergence.cascade1614, label %convergence.cascade.exit1615

schedule.85:                                      ; preds = %schedule.86, %convergence.target.84.ready, %scheduler.dispatch.route
  %1182 = load <8 x i1>, ptr %current.mask, align 1
  %1183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1182)
  %1184 = bitcast <8 x i1> %1182 to i8
  %1185 = call i8 @llvm.cttz.i8(i8 %1184, i1 false)
  %1186 = zext i8 %1185 to i32
  %1187 = select i1 %1183, i32 %1186, i32 0
  %.state1631 = load <8 x i64>, ptr %.slot172, align 64
  %1188 = icmp slt <8 x i64> %.state1631, splat (i64 3)
  %1189 = and <8 x i1> %1182, %1188
  %1190 = xor <8 x i1> %1188, splat (i1 true)
  %1191 = and <8 x i1> %1182, %1190
  %1192 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1189)
  %1193 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1191)
  %1194 = and i1 %1192, %1193
  br i1 %1194, label %varying.divergent1632, label %varying.coherent1633

schedule.86:                                      ; preds = %varying.coherent.true1638, %scheduler.dispatch.route
  %1195 = load <8 x i1>, ptr %current.mask, align 1
  %1196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1195)
  %1197 = bitcast <8 x i1> %1195 to i8
  %1198 = call i8 @llvm.cttz.i8(i8 %1197, i1 false)
  %1199 = zext i8 %1198 to i32
  %1200 = select i1 %1196, i32 %1199, i32 0
  %.state1640 = load <8 x i64>, ptr %.slot172, align 64
  %1201 = select <8 x i1> %1195, <8 x i64> %.state1640, <8 x i64> zeroinitializer
  %1202 = select <8 x i1> %1195, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1203 = sdiv <8 x i64> %1201, %1202
  %.spill.load1641 = load i64, ptr %.spill11, align 4
  %1204 = add i64 %.spill.load1641, 0
  %1205 = mul i64 %1204, 1
  %1206 = add i64 %1205, 0
  %1207 = mul i64 %1206, 2
  %1208 = add i64 %1207, 0
  %1209 = mul i64 %1208, 3
  %.splatinsert1642 = insertelement <8 x i64> poison, i64 %1209, i64 0
  %.splat1643 = shufflevector <8 x i64> %.splatinsert1642, <8 x i64> poison, <8 x i32> zeroinitializer
  %1210 = add <8 x i64> %.splat1643, %1203
  %1211 = mul <8 x i64> %1210, splat (i64 4)
  %1212 = add <8 x i64> %1211, splat (i64 2)
  %tile_snapshot.spill.load1644 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %1213 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1644, 0
  %1214 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1644, 1
  %1215 = mul <8 x i64> %1212, splat (i64 32)
  %1216 = add <8 x i64> %1214, %1215
  %1217 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1213, 0
  %1218 = insertvalue { <8 x ptr>, <8 x i64> } %1217, <8 x i64> %1216, 1
  %1219 = extractvalue { <8 x ptr>, <8 x i64> } %1218, 0
  %1220 = extractvalue { <8 x ptr>, <8 x i64> } %1218, 1
  %1221 = getelementptr i8, <8 x ptr> %1219, <8 x i64> %1220
  %1222 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1221, <8 x i1> %1195, <8 x float> zeroinitializer)
  %.state1645 = load <8 x float>, ptr %.slot173, align 32
  %1223 = fadd <8 x float> %.state1645, %1222
  %.state1646 = load <8 x i64>, ptr %.slot172, align 64
  %1224 = add <8 x i64> %.state1646, splat (i64 1)
  %1225 = load <8 x i64>, ptr %.slot172, align 64
  %1226 = select <8 x i1> %1195, <8 x i64> %1224, <8 x i64> %1225
  store <8 x i64> %1226, ptr %.slot172, align 64
  %1227 = load <8 x float>, ptr %.slot173, align 32
  %1228 = select <8 x i1> %1195, <8 x float> %1223, <8 x float> %1227
  store <8 x float> %1228, ptr %.slot173, align 32
  store <8 x i1> %1195, ptr %current.mask, align 1
  %1229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1195)
  br i1 %1229, label %schedule.85, label %scheduler.loop

schedule.87:                                      ; preds = %varying.coherent.false1639, %scheduler.dispatch.route
  %1230 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1649 = load i32, ptr %current.token, align 4
  %convergence.token.present1650 = icmp ne i32 %convergence.current.token1649, 0
  br i1 %convergence.token.present1650, label %convergence.cascade1647, label %convergence.cascade.exit1648

schedule.88:                                      ; preds = %schedule.89, %convergence.target.87.ready, %scheduler.dispatch.route
  %1231 = load <8 x i1>, ptr %current.mask, align 1
  %1232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1231)
  %1233 = bitcast <8 x i1> %1231 to i8
  %1234 = call i8 @llvm.cttz.i8(i8 %1233, i1 false)
  %1235 = zext i8 %1234 to i32
  %1236 = select i1 %1232, i32 %1235, i32 0
  %.state1664 = load <8 x i64>, ptr %.slot174, align 64
  %1237 = icmp slt <8 x i64> %.state1664, splat (i64 3)
  %1238 = and <8 x i1> %1231, %1237
  %1239 = xor <8 x i1> %1237, splat (i1 true)
  %1240 = and <8 x i1> %1231, %1239
  %1241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1238)
  %1242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1240)
  %1243 = and i1 %1241, %1242
  br i1 %1243, label %varying.divergent1665, label %varying.coherent1666

schedule.89:                                      ; preds = %varying.coherent.true1671, %scheduler.dispatch.route
  %1244 = load <8 x i1>, ptr %current.mask, align 1
  %1245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1244)
  %1246 = bitcast <8 x i1> %1244 to i8
  %1247 = call i8 @llvm.cttz.i8(i8 %1246, i1 false)
  %1248 = zext i8 %1247 to i32
  %1249 = select i1 %1245, i32 %1248, i32 0
  %.state1673 = load <8 x i64>, ptr %.slot174, align 64
  %1250 = select <8 x i1> %1244, <8 x i64> %.state1673, <8 x i64> zeroinitializer
  %1251 = select <8 x i1> %1244, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1252 = sdiv <8 x i64> %1250, %1251
  %.spill.load1674 = load i64, ptr %.spill11, align 4
  %1253 = add i64 %.spill.load1674, 0
  %1254 = mul i64 %1253, 1
  %1255 = add i64 %1254, 0
  %1256 = mul i64 %1255, 2
  %1257 = add i64 %1256, 0
  %1258 = mul i64 %1257, 3
  %.splatinsert1675 = insertelement <8 x i64> poison, i64 %1258, i64 0
  %.splat1676 = shufflevector <8 x i64> %.splatinsert1675, <8 x i64> poison, <8 x i32> zeroinitializer
  %1259 = add <8 x i64> %.splat1676, %1252
  %1260 = mul <8 x i64> %1259, splat (i64 4)
  %1261 = add <8 x i64> %1260, splat (i64 3)
  %tile_snapshot.spill.load1677 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %1262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1677, 0
  %1263 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1677, 1
  %1264 = mul <8 x i64> %1261, splat (i64 32)
  %1265 = add <8 x i64> %1263, %1264
  %1266 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1262, 0
  %1267 = insertvalue { <8 x ptr>, <8 x i64> } %1266, <8 x i64> %1265, 1
  %1268 = extractvalue { <8 x ptr>, <8 x i64> } %1267, 0
  %1269 = extractvalue { <8 x ptr>, <8 x i64> } %1267, 1
  %1270 = getelementptr i8, <8 x ptr> %1268, <8 x i64> %1269
  %1271 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1270, <8 x i1> %1244, <8 x float> zeroinitializer)
  %.state1678 = load <8 x float>, ptr %.slot175, align 32
  %1272 = fadd <8 x float> %.state1678, %1271
  %.state1679 = load <8 x i64>, ptr %.slot174, align 64
  %1273 = add <8 x i64> %.state1679, splat (i64 1)
  %1274 = load <8 x i64>, ptr %.slot174, align 64
  %1275 = select <8 x i1> %1244, <8 x i64> %1273, <8 x i64> %1274
  store <8 x i64> %1275, ptr %.slot174, align 64
  %1276 = load <8 x float>, ptr %.slot175, align 32
  %1277 = select <8 x i1> %1244, <8 x float> %1272, <8 x float> %1276
  store <8 x float> %1277, ptr %.slot175, align 32
  store <8 x i1> %1244, ptr %current.mask, align 1
  %1278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1244)
  br i1 %1278, label %schedule.88, label %scheduler.loop

schedule.90:                                      ; preds = %varying.coherent.false1672, %scheduler.dispatch.route
  %1279 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1682 = load i32, ptr %current.token, align 4
  %convergence.token.present1683 = icmp ne i32 %convergence.current.token1682, 0
  br i1 %convergence.token.present1683, label %convergence.cascade1680, label %convergence.cascade.exit1681

schedule.91:                                      ; preds = %schedule.92, %convergence.target.90.ready, %scheduler.dispatch.route
  %1280 = load <8 x i1>, ptr %current.mask, align 1
  %1281 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1280)
  %1282 = bitcast <8 x i1> %1280 to i8
  %1283 = call i8 @llvm.cttz.i8(i8 %1282, i1 false)
  %1284 = zext i8 %1283 to i32
  %1285 = select i1 %1281, i32 %1284, i32 0
  %.state1697 = load <8 x i64>, ptr %.slot176, align 64
  %1286 = icmp slt <8 x i64> %.state1697, splat (i64 3)
  %1287 = and <8 x i1> %1280, %1286
  %1288 = xor <8 x i1> %1286, splat (i1 true)
  %1289 = and <8 x i1> %1280, %1288
  %1290 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1287)
  %1291 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1289)
  %1292 = and i1 %1290, %1291
  br i1 %1292, label %varying.divergent1698, label %varying.coherent1699

schedule.92:                                      ; preds = %varying.coherent.true1704, %scheduler.dispatch.route
  %1293 = load <8 x i1>, ptr %current.mask, align 1
  %1294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1293)
  %1295 = bitcast <8 x i1> %1293 to i8
  %1296 = call i8 @llvm.cttz.i8(i8 %1295, i1 false)
  %1297 = zext i8 %1296 to i32
  %1298 = select i1 %1294, i32 %1297, i32 0
  %.state1706 = load <8 x i64>, ptr %.slot176, align 64
  %1299 = select <8 x i1> %1293, <8 x i64> %.state1706, <8 x i64> zeroinitializer
  %1300 = select <8 x i1> %1293, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1301 = sdiv <8 x i64> %1299, %1300
  %.spill.load1707 = load i64, ptr %.spill11, align 4
  %1302 = add i64 %.spill.load1707, 0
  %1303 = mul i64 %1302, 1
  %1304 = add i64 %1303, 0
  %1305 = mul i64 %1304, 2
  %1306 = add i64 %1305, 1
  %1307 = mul i64 %1306, 3
  %.splatinsert1708 = insertelement <8 x i64> poison, i64 %1307, i64 0
  %.splat1709 = shufflevector <8 x i64> %.splatinsert1708, <8 x i64> poison, <8 x i32> zeroinitializer
  %1308 = add <8 x i64> %.splat1709, %1301
  %1309 = mul <8 x i64> %1308, splat (i64 4)
  %1310 = add <8 x i64> %1309, zeroinitializer
  %tile_snapshot.spill.load1710 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %1311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1710, 0
  %1312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1710, 1
  %1313 = mul <8 x i64> %1310, splat (i64 32)
  %1314 = add <8 x i64> %1312, %1313
  %1315 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1311, 0
  %1316 = insertvalue { <8 x ptr>, <8 x i64> } %1315, <8 x i64> %1314, 1
  %1317 = extractvalue { <8 x ptr>, <8 x i64> } %1316, 0
  %1318 = extractvalue { <8 x ptr>, <8 x i64> } %1316, 1
  %1319 = getelementptr i8, <8 x ptr> %1317, <8 x i64> %1318
  %1320 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1319, <8 x i1> %1293, <8 x float> zeroinitializer)
  %.state1711 = load <8 x float>, ptr %.slot177, align 32
  %1321 = fadd <8 x float> %.state1711, %1320
  %.state1712 = load <8 x i64>, ptr %.slot176, align 64
  %1322 = add <8 x i64> %.state1712, splat (i64 1)
  %1323 = load <8 x i64>, ptr %.slot176, align 64
  %1324 = select <8 x i1> %1293, <8 x i64> %1322, <8 x i64> %1323
  store <8 x i64> %1324, ptr %.slot176, align 64
  %1325 = load <8 x float>, ptr %.slot177, align 32
  %1326 = select <8 x i1> %1293, <8 x float> %1321, <8 x float> %1325
  store <8 x float> %1326, ptr %.slot177, align 32
  store <8 x i1> %1293, ptr %current.mask, align 1
  %1327 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1293)
  br i1 %1327, label %schedule.91, label %scheduler.loop

schedule.93:                                      ; preds = %varying.coherent.false1705, %scheduler.dispatch.route
  %1328 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1715 = load i32, ptr %current.token, align 4
  %convergence.token.present1716 = icmp ne i32 %convergence.current.token1715, 0
  br i1 %convergence.token.present1716, label %convergence.cascade1713, label %convergence.cascade.exit1714

schedule.94:                                      ; preds = %schedule.95, %convergence.target.93.ready, %scheduler.dispatch.route
  %1329 = load <8 x i1>, ptr %current.mask, align 1
  %1330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1329)
  %1331 = bitcast <8 x i1> %1329 to i8
  %1332 = call i8 @llvm.cttz.i8(i8 %1331, i1 false)
  %1333 = zext i8 %1332 to i32
  %1334 = select i1 %1330, i32 %1333, i32 0
  %.state1730 = load <8 x i64>, ptr %.slot178, align 64
  %1335 = icmp slt <8 x i64> %.state1730, splat (i64 3)
  %1336 = and <8 x i1> %1329, %1335
  %1337 = xor <8 x i1> %1335, splat (i1 true)
  %1338 = and <8 x i1> %1329, %1337
  %1339 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1336)
  %1340 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1338)
  %1341 = and i1 %1339, %1340
  br i1 %1341, label %varying.divergent1731, label %varying.coherent1732

schedule.95:                                      ; preds = %varying.coherent.true1737, %scheduler.dispatch.route
  %1342 = load <8 x i1>, ptr %current.mask, align 1
  %1343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1342)
  %1344 = bitcast <8 x i1> %1342 to i8
  %1345 = call i8 @llvm.cttz.i8(i8 %1344, i1 false)
  %1346 = zext i8 %1345 to i32
  %1347 = select i1 %1343, i32 %1346, i32 0
  %.state1739 = load <8 x i64>, ptr %.slot178, align 64
  %1348 = select <8 x i1> %1342, <8 x i64> %.state1739, <8 x i64> zeroinitializer
  %1349 = select <8 x i1> %1342, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1350 = sdiv <8 x i64> %1348, %1349
  %.spill.load1740 = load i64, ptr %.spill11, align 4
  %1351 = add i64 %.spill.load1740, 0
  %1352 = mul i64 %1351, 1
  %1353 = add i64 %1352, 0
  %1354 = mul i64 %1353, 2
  %1355 = add i64 %1354, 1
  %1356 = mul i64 %1355, 3
  %.splatinsert1741 = insertelement <8 x i64> poison, i64 %1356, i64 0
  %.splat1742 = shufflevector <8 x i64> %.splatinsert1741, <8 x i64> poison, <8 x i32> zeroinitializer
  %1357 = add <8 x i64> %.splat1742, %1350
  %1358 = mul <8 x i64> %1357, splat (i64 4)
  %1359 = add <8 x i64> %1358, splat (i64 1)
  %tile_snapshot.spill.load1743 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %1360 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1743, 0
  %1361 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1743, 1
  %1362 = mul <8 x i64> %1359, splat (i64 32)
  %1363 = add <8 x i64> %1361, %1362
  %1364 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1360, 0
  %1365 = insertvalue { <8 x ptr>, <8 x i64> } %1364, <8 x i64> %1363, 1
  %1366 = extractvalue { <8 x ptr>, <8 x i64> } %1365, 0
  %1367 = extractvalue { <8 x ptr>, <8 x i64> } %1365, 1
  %1368 = getelementptr i8, <8 x ptr> %1366, <8 x i64> %1367
  %1369 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1368, <8 x i1> %1342, <8 x float> zeroinitializer)
  %.state1744 = load <8 x float>, ptr %.slot179, align 32
  %1370 = fadd <8 x float> %.state1744, %1369
  %.state1745 = load <8 x i64>, ptr %.slot178, align 64
  %1371 = add <8 x i64> %.state1745, splat (i64 1)
  %1372 = load <8 x i64>, ptr %.slot178, align 64
  %1373 = select <8 x i1> %1342, <8 x i64> %1371, <8 x i64> %1372
  store <8 x i64> %1373, ptr %.slot178, align 64
  %1374 = load <8 x float>, ptr %.slot179, align 32
  %1375 = select <8 x i1> %1342, <8 x float> %1370, <8 x float> %1374
  store <8 x float> %1375, ptr %.slot179, align 32
  store <8 x i1> %1342, ptr %current.mask, align 1
  %1376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1342)
  br i1 %1376, label %schedule.94, label %scheduler.loop

schedule.96:                                      ; preds = %varying.coherent.false1738, %scheduler.dispatch.route
  %1377 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1748 = load i32, ptr %current.token, align 4
  %convergence.token.present1749 = icmp ne i32 %convergence.current.token1748, 0
  br i1 %convergence.token.present1749, label %convergence.cascade1746, label %convergence.cascade.exit1747

schedule.97:                                      ; preds = %schedule.98, %convergence.target.96.ready, %scheduler.dispatch.route
  %1378 = load <8 x i1>, ptr %current.mask, align 1
  %1379 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1378)
  %1380 = bitcast <8 x i1> %1378 to i8
  %1381 = call i8 @llvm.cttz.i8(i8 %1380, i1 false)
  %1382 = zext i8 %1381 to i32
  %1383 = select i1 %1379, i32 %1382, i32 0
  %.state1763 = load <8 x i64>, ptr %.slot180, align 64
  %1384 = icmp slt <8 x i64> %.state1763, splat (i64 3)
  %1385 = and <8 x i1> %1378, %1384
  %1386 = xor <8 x i1> %1384, splat (i1 true)
  %1387 = and <8 x i1> %1378, %1386
  %1388 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1385)
  %1389 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1387)
  %1390 = and i1 %1388, %1389
  br i1 %1390, label %varying.divergent1764, label %varying.coherent1765

schedule.98:                                      ; preds = %varying.coherent.true1770, %scheduler.dispatch.route
  %1391 = load <8 x i1>, ptr %current.mask, align 1
  %1392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1391)
  %1393 = bitcast <8 x i1> %1391 to i8
  %1394 = call i8 @llvm.cttz.i8(i8 %1393, i1 false)
  %1395 = zext i8 %1394 to i32
  %1396 = select i1 %1392, i32 %1395, i32 0
  %.state1772 = load <8 x i64>, ptr %.slot180, align 64
  %1397 = select <8 x i1> %1391, <8 x i64> %.state1772, <8 x i64> zeroinitializer
  %1398 = select <8 x i1> %1391, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1399 = sdiv <8 x i64> %1397, %1398
  %.spill.load1773 = load i64, ptr %.spill11, align 4
  %1400 = add i64 %.spill.load1773, 0
  %1401 = mul i64 %1400, 1
  %1402 = add i64 %1401, 0
  %1403 = mul i64 %1402, 2
  %1404 = add i64 %1403, 1
  %1405 = mul i64 %1404, 3
  %.splatinsert1774 = insertelement <8 x i64> poison, i64 %1405, i64 0
  %.splat1775 = shufflevector <8 x i64> %.splatinsert1774, <8 x i64> poison, <8 x i32> zeroinitializer
  %1406 = add <8 x i64> %.splat1775, %1399
  %1407 = mul <8 x i64> %1406, splat (i64 4)
  %1408 = add <8 x i64> %1407, splat (i64 2)
  %tile_snapshot.spill.load1776 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %1409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1776, 0
  %1410 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1776, 1
  %1411 = mul <8 x i64> %1408, splat (i64 32)
  %1412 = add <8 x i64> %1410, %1411
  %1413 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1409, 0
  %1414 = insertvalue { <8 x ptr>, <8 x i64> } %1413, <8 x i64> %1412, 1
  %1415 = extractvalue { <8 x ptr>, <8 x i64> } %1414, 0
  %1416 = extractvalue { <8 x ptr>, <8 x i64> } %1414, 1
  %1417 = getelementptr i8, <8 x ptr> %1415, <8 x i64> %1416
  %1418 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1417, <8 x i1> %1391, <8 x float> zeroinitializer)
  %.state1777 = load <8 x float>, ptr %.slot181, align 32
  %1419 = fadd <8 x float> %.state1777, %1418
  %.state1778 = load <8 x i64>, ptr %.slot180, align 64
  %1420 = add <8 x i64> %.state1778, splat (i64 1)
  %1421 = load <8 x i64>, ptr %.slot180, align 64
  %1422 = select <8 x i1> %1391, <8 x i64> %1420, <8 x i64> %1421
  store <8 x i64> %1422, ptr %.slot180, align 64
  %1423 = load <8 x float>, ptr %.slot181, align 32
  %1424 = select <8 x i1> %1391, <8 x float> %1419, <8 x float> %1423
  store <8 x float> %1424, ptr %.slot181, align 32
  store <8 x i1> %1391, ptr %current.mask, align 1
  %1425 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1391)
  br i1 %1425, label %schedule.97, label %scheduler.loop

schedule.99:                                      ; preds = %varying.coherent.false1771, %scheduler.dispatch.route
  %1426 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1781 = load i32, ptr %current.token, align 4
  %convergence.token.present1782 = icmp ne i32 %convergence.current.token1781, 0
  br i1 %convergence.token.present1782, label %convergence.cascade1779, label %convergence.cascade.exit1780

schedule.100:                                     ; preds = %schedule.101, %convergence.target.99.ready, %scheduler.dispatch.route
  %1427 = load <8 x i1>, ptr %current.mask, align 1
  %1428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1427)
  %1429 = bitcast <8 x i1> %1427 to i8
  %1430 = call i8 @llvm.cttz.i8(i8 %1429, i1 false)
  %1431 = zext i8 %1430 to i32
  %1432 = select i1 %1428, i32 %1431, i32 0
  %.state1796 = load <8 x i64>, ptr %.slot182, align 64
  %1433 = icmp slt <8 x i64> %.state1796, splat (i64 3)
  %1434 = and <8 x i1> %1427, %1433
  %1435 = xor <8 x i1> %1433, splat (i1 true)
  %1436 = and <8 x i1> %1427, %1435
  %1437 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1434)
  %1438 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1436)
  %1439 = and i1 %1437, %1438
  br i1 %1439, label %varying.divergent1797, label %varying.coherent1798

schedule.101:                                     ; preds = %varying.coherent.true1803, %scheduler.dispatch.route
  %1440 = load <8 x i1>, ptr %current.mask, align 1
  %1441 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1440)
  %1442 = bitcast <8 x i1> %1440 to i8
  %1443 = call i8 @llvm.cttz.i8(i8 %1442, i1 false)
  %1444 = zext i8 %1443 to i32
  %1445 = select i1 %1441, i32 %1444, i32 0
  %.state1805 = load <8 x i64>, ptr %.slot182, align 64
  %1446 = select <8 x i1> %1440, <8 x i64> %.state1805, <8 x i64> zeroinitializer
  %1447 = select <8 x i1> %1440, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1448 = sdiv <8 x i64> %1446, %1447
  %.spill.load1806 = load i64, ptr %.spill11, align 4
  %1449 = add i64 %.spill.load1806, 0
  %1450 = mul i64 %1449, 1
  %1451 = add i64 %1450, 0
  %1452 = mul i64 %1451, 2
  %1453 = add i64 %1452, 1
  %1454 = mul i64 %1453, 3
  %.splatinsert1807 = insertelement <8 x i64> poison, i64 %1454, i64 0
  %.splat1808 = shufflevector <8 x i64> %.splatinsert1807, <8 x i64> poison, <8 x i32> zeroinitializer
  %1455 = add <8 x i64> %.splat1808, %1448
  %1456 = mul <8 x i64> %1455, splat (i64 4)
  %1457 = add <8 x i64> %1456, splat (i64 3)
  %tile_snapshot.spill.load1809 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %1458 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1809, 0
  %1459 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1809, 1
  %1460 = mul <8 x i64> %1457, splat (i64 32)
  %1461 = add <8 x i64> %1459, %1460
  %1462 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1458, 0
  %1463 = insertvalue { <8 x ptr>, <8 x i64> } %1462, <8 x i64> %1461, 1
  %1464 = extractvalue { <8 x ptr>, <8 x i64> } %1463, 0
  %1465 = extractvalue { <8 x ptr>, <8 x i64> } %1463, 1
  %1466 = getelementptr i8, <8 x ptr> %1464, <8 x i64> %1465
  %1467 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1466, <8 x i1> %1440, <8 x float> zeroinitializer)
  %.state1810 = load <8 x float>, ptr %.slot183, align 32
  %1468 = fadd <8 x float> %.state1810, %1467
  %.state1811 = load <8 x i64>, ptr %.slot182, align 64
  %1469 = add <8 x i64> %.state1811, splat (i64 1)
  %1470 = load <8 x i64>, ptr %.slot182, align 64
  %1471 = select <8 x i1> %1440, <8 x i64> %1469, <8 x i64> %1470
  store <8 x i64> %1471, ptr %.slot182, align 64
  %1472 = load <8 x float>, ptr %.slot183, align 32
  %1473 = select <8 x i1> %1440, <8 x float> %1468, <8 x float> %1472
  store <8 x float> %1473, ptr %.slot183, align 32
  store <8 x i1> %1440, ptr %current.mask, align 1
  %1474 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1440)
  br i1 %1474, label %schedule.100, label %scheduler.loop

schedule.102:                                     ; preds = %varying.coherent.false1804, %scheduler.dispatch.route
  %1475 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1814 = load i32, ptr %current.token, align 4
  %convergence.token.present1815 = icmp ne i32 %convergence.current.token1814, 0
  br i1 %convergence.token.present1815, label %convergence.cascade1812, label %convergence.cascade.exit1813

schedule.103:                                     ; preds = %varying.coherent.false342, %scheduler.dispatch.route
  %1476 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1852 = load i32, ptr %current.token, align 4
  %convergence.token.present1853 = icmp ne i32 %convergence.current.token1852, 0
  br i1 %convergence.token.present1853, label %convergence.cascade1850, label %convergence.cascade.exit1851

schedule.104:                                     ; preds = %varying.coherent.true1907, %scheduler.dispatch.route
  %1477 = load <8 x i1>, ptr %current.mask, align 1
  %1478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1477)
  %1479 = bitcast <8 x i1> %1477 to i8
  %1480 = call i8 @llvm.cttz.i8(i8 %1479, i1 false)
  %1481 = zext i8 %1480 to i32
  %1482 = select i1 %1478, i32 %1481, i32 0
  %.spill.load1909 = load volatile <8 x i64>, ptr %.spill189, align 64
  %.spill.load1910 = load volatile <8 x float>, ptr %.spill184, align 32
  %1483 = extractvalue { ptr, i64 } %31, 0
  %1484 = mul <8 x i64> %.spill.load1909, splat (i64 4)
  %1485 = getelementptr i8, ptr %1483, <8 x i64> %1484
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load1910, <8 x ptr> align 1 %1485, <8 x i1> %1477)
  store <8 x i1> %1477, ptr %current.mask, align 1
  %1486 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1477)
  br i1 %1486, label %schedule.105, label %scheduler.loop

schedule.105:                                     ; preds = %schedule.104, %varying.coherent.false1908, %scheduler.dispatch.route
  %1487 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1913 = load i32, ptr %current.token, align 4
  %convergence.token.present1914 = icmp ne i32 %convergence.current.token1913, 0
  br i1 %convergence.token.present1914, label %convergence.cascade1911, label %convergence.cascade.exit1912

schedule.106:                                     ; preds = %varying.coherent.true1939, %scheduler.dispatch.route
  %1488 = load <8 x i1>, ptr %current.mask, align 1
  %1489 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1488)
  %1490 = bitcast <8 x i1> %1488 to i8
  %1491 = call i8 @llvm.cttz.i8(i8 %1490, i1 false)
  %1492 = zext i8 %1491 to i32
  %1493 = select i1 %1489, i32 %1492, i32 0
  %.spill.load1941 = load volatile <8 x i64>, ptr %.spill190, align 64
  %.spill.load1942 = load volatile <8 x float>, ptr %.spill185, align 32
  %1494 = extractvalue { ptr, i64 } %31, 0
  %1495 = mul <8 x i64> %.spill.load1941, splat (i64 4)
  %1496 = getelementptr i8, ptr %1494, <8 x i64> %1495
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load1942, <8 x ptr> align 1 %1496, <8 x i1> %1488)
  store <8 x i1> %1488, ptr %current.mask, align 1
  %1497 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1488)
  br i1 %1497, label %schedule.107, label %scheduler.loop

schedule.107:                                     ; preds = %schedule.106, %varying.coherent.false1940, %scheduler.dispatch.route
  %1498 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1945 = load i32, ptr %current.token, align 4
  %convergence.token.present1946 = icmp ne i32 %convergence.current.token1945, 0
  br i1 %convergence.token.present1946, label %convergence.cascade1943, label %convergence.cascade.exit1944

schedule.108:                                     ; preds = %varying.coherent.true1971, %scheduler.dispatch.route
  %1499 = load <8 x i1>, ptr %current.mask, align 1
  %1500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1499)
  %1501 = bitcast <8 x i1> %1499 to i8
  %1502 = call i8 @llvm.cttz.i8(i8 %1501, i1 false)
  %1503 = zext i8 %1502 to i32
  %1504 = select i1 %1500, i32 %1503, i32 0
  %.spill.load1973 = load volatile <8 x i64>, ptr %.spill191, align 64
  %.spill.load1974 = load volatile <8 x float>, ptr %.spill186, align 32
  %1505 = extractvalue { ptr, i64 } %31, 0
  %1506 = mul <8 x i64> %.spill.load1973, splat (i64 4)
  %1507 = getelementptr i8, ptr %1505, <8 x i64> %1506
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load1974, <8 x ptr> align 1 %1507, <8 x i1> %1499)
  store <8 x i1> %1499, ptr %current.mask, align 1
  %1508 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1499)
  br i1 %1508, label %schedule.109, label %scheduler.loop

schedule.109:                                     ; preds = %schedule.108, %varying.coherent.false1972, %scheduler.dispatch.route
  %1509 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1977 = load i32, ptr %current.token, align 4
  %convergence.token.present1978 = icmp ne i32 %convergence.current.token1977, 0
  br i1 %convergence.token.present1978, label %convergence.cascade1975, label %convergence.cascade.exit1976

schedule.110:                                     ; preds = %varying.coherent.true2003, %scheduler.dispatch.route
  %1510 = load <8 x i1>, ptr %current.mask, align 1
  %1511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1510)
  %1512 = bitcast <8 x i1> %1510 to i8
  %1513 = call i8 @llvm.cttz.i8(i8 %1512, i1 false)
  %1514 = zext i8 %1513 to i32
  %1515 = select i1 %1511, i32 %1514, i32 0
  %.spill.load2005 = load volatile <8 x i64>, ptr %.spill192, align 64
  %.spill.load2006 = load volatile <8 x float>, ptr %.spill187, align 32
  %1516 = extractvalue { ptr, i64 } %31, 0
  %1517 = mul <8 x i64> %.spill.load2005, splat (i64 4)
  %1518 = getelementptr i8, ptr %1516, <8 x i64> %1517
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load2006, <8 x ptr> align 1 %1518, <8 x i1> %1510)
  store <8 x i1> %1510, ptr %current.mask, align 1
  %1519 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1510)
  br i1 %1519, label %schedule.111, label %scheduler.loop

schedule.111:                                     ; preds = %schedule.110, %varying.coherent.false2004, %scheduler.dispatch.route
  %1520 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2009 = load i32, ptr %current.token, align 4
  %convergence.token.present2010 = icmp ne i32 %convergence.current.token2009, 0
  br i1 %convergence.token.present2010, label %convergence.cascade2007, label %convergence.cascade.exit2008

varying.divergent:                                ; preds = %schedule.0
  %1521 = load i32, ptr %current.token, align 4
  %1522 = icmp ne i32 %1521, 0
  %1523 = sub i32 %1521, 1
  %1524 = select i1 %1522, i32 %1523, i32 0
  %1525 = load i8, ptr %frame.active, align 1
  %1526 = trunc i32 %1524 to i8
  %1527 = shl i8 1, %1526
  %1528 = and i8 %1525, %1527
  %1529 = icmp ne i8 %1528, 0
  %1530 = load <8 x i32>, ptr %frame.static.id, align 32
  %1531 = extractelement <8 x i32> %1530, i32 %1524
  %1532 = icmp eq i32 %1531, 0
  %1533 = and i1 %1529, %1532
  %1534 = and i1 %1522, %1533
  %1535 = xor i1 %1534, true
  %1536 = and i1 true, %1535
  %1537 = xor i8 %1525, -1
  %1538 = icmp ne i8 %1537, 0
  %1539 = xor i1 %1538, true
  %1540 = and i1 %1536, %1539
  br i1 %1540, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.0
  br i1 %178, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %1541 = call i8 @llvm.cttz.i8(i8 %1537, i1 false)
  %1542 = zext i8 %1541 to i32
  %1543 = select i1 %1538, i32 %1542, i32 0
  %1544 = trunc i32 %1543 to i8
  %1545 = shl i8 1, %1544
  %1546 = or i8 %1525, %1545
  %1547 = select i1 %1536, i8 %1546, i8 %1525
  store i8 %1547, ptr %frame.active, align 1
  %1548 = load <8 x i32>, ptr %frame.static.id, align 32
  %1549 = extractelement <8 x i32> %1548, i32 %1543
  %1550 = select i1 %1536, i32 0, i32 %1549
  %1551 = load <8 x i32>, ptr %frame.static.id, align 32
  %1552 = insertelement <8 x i32> %1551, i32 %1550, i32 %1543
  store <8 x i32> %1552, ptr %frame.static.id, align 32
  %1553 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1554 = extractelement <8 x i32> %1553, i32 %1543
  %1555 = select i1 %1536, i32 %1521, i32 %1554
  %1556 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1557 = insertelement <8 x i32> %1556, i32 %1555, i32 %1543
  store <8 x i32> %1557, ptr %frame.parent.token, align 32
  %1558 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1543
  %1559 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1543
  %1560 = load <8 x i1>, ptr %1558, align 1
  %1561 = load <8 x i1>, ptr %1559, align 1
  %1562 = select i1 %1536, <8 x i1> %89, <8 x i1> %1560
  store <8 x i1> %1562, ptr %1558, align 1
  %1563 = select i1 %1536, <8 x i1> zeroinitializer, <8 x i1> %1561
  store <8 x i1> %1563, ptr %1559, align 1
  %1564 = add i32 %1543, 1
  %1565 = select i1 %1534, i32 %1521, i32 %1564
  %1566 = select i1 true, i32 %1565, i32 %1521
  store i32 %1566, ptr %current.token, align 4
  %1567 = load <8 x float>, ptr %.slot, align 32
  %1568 = select <8 x i1> %177, <8 x float> zeroinitializer, <8 x float> %1567
  store <8 x float> %1568, ptr %.slot, align 32
  %1569 = load i32, ptr %current.token, align 4
  %1570 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %175)
  %1571 = load i32, ptr %ready.count, align 4
  %1572 = icmp uge i32 %1571, 8
  %1573 = and i1 %1570, %1572
  br i1 %1573, label %ready.overflow.trap203, label %ready.overflow.resume204

ready.overflow.trap203:                           ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume204:                         ; preds = %convergence.overflow.resume
  %1574 = select i1 %1570, i32 %1571, i32 0
  %1575 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1574
  %1576 = load <8 x i1>, ptr %1575, align 1
  %1577 = select i1 %1570, <8 x i1> %175, <8 x i1> %1576
  store <8 x i1> %1577, ptr %1575, align 1
  %1578 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1574
  %1579 = load i32, ptr %1578, align 4
  %1580 = select i1 %1570, i32 1, i32 %1579
  store i32 %1580, ptr %1578, align 4
  %1581 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1574
  %1582 = load i32, ptr %1581, align 4
  %1583 = select i1 %1570, i32 %1569, i32 %1582
  store i32 %1583, ptr %1581, align 4
  %1584 = add i32 %1571, 1
  %1585 = select i1 %1570, i32 %1584, i32 %1571
  store i32 %1585, ptr %ready.count, align 4
  %1586 = load <8 x i1>, ptr %runnable.mask, align 1
  %1587 = or <8 x i1> %1586, %175
  store <8 x i1> %1587, ptr %runnable.mask, align 1
  store <8 x i1> %177, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %89, ptr %current.mask, align 1
  %1588 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %89)
  br i1 %1588, label %schedule.1, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  %1589 = load <8 x float>, ptr %.slot, align 32
  %1590 = select <8 x i1> %89, <8 x float> zeroinitializer, <8 x float> %1589
  store <8 x float> %1590, ptr %.slot, align 32
  store <8 x i1> %89, ptr %current.mask, align 1
  %1591 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %89)
  br i1 %1591, label %schedule.2, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.2
  %convergence.cascade.flow = phi <8 x i1> [ %194, %schedule.2 ], [ %1634, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.2 ], [ %1635, %convergence.cascade ]
  %1592 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %1593 = load i32, ptr %current.token, align 4
  %1594 = icmp ne i32 %1593, 0
  %1595 = and i1 %1592, %1594
  %1596 = sub i32 %1593, 1
  %1597 = select i1 %1595, i32 %1596, i32 0
  %1598 = load i8, ptr %frame.active, align 1
  %1599 = trunc i32 %1597 to i8
  %1600 = shl i8 1, %1599
  %1601 = and i8 %1598, %1600
  %1602 = icmp ne i8 %1601, 0
  %1603 = load <8 x i32>, ptr %frame.static.id, align 32
  %1604 = extractelement <8 x i32> %1603, i32 %1597
  %convergence.target.pointer = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %1604
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %1605 = icmp eq i32 %convergence.dynamic.target, 2
  %1606 = and i1 %1602, %1605
  %1607 = and i1 %1595, %1606
  %1608 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1597
  %1609 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1597
  %1610 = load <8 x i1>, ptr %1608, align 1
  %1611 = load <8 x i1>, ptr %1609, align 1
  %1612 = or <8 x i1> %1611, %convergence.cascade.flow
  %1613 = load <8 x i1>, ptr %live.mask, align 1
  %1614 = and <8 x i1> %1610, %1613
  %1615 = icmp eq <8 x i1> %1612, %1614
  %1616 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1615)
  %1617 = and i1 %1607, %1616
  %1618 = select i1 %1617, <8 x i1> zeroinitializer, <8 x i1> %1612
  %1619 = select i1 %1607, <8 x i1> %1618, <8 x i1> %1611
  store <8 x i1> %1619, ptr %1609, align 1
  %1620 = select i1 %1617, <8 x i1> zeroinitializer, <8 x i1> %1610
  store <8 x i1> %1620, ptr %1608, align 1
  %1621 = trunc i32 %1597 to i8
  %1622 = shl i8 1, %1621
  %1623 = xor i8 %1622, -1
  %1624 = and i8 %1598, %1623
  %1625 = select i1 %1617, i8 %1624, i8 %1598
  store i8 %1625, ptr %frame.active, align 1
  %.splatinsert205 = insertelement <8 x i1> poison, i1 %1607, i64 0
  %.splat206 = shufflevector <8 x i1> %.splatinsert205, <8 x i1> poison, <8 x i32> zeroinitializer
  %1626 = and <8 x i1> %convergence.cascade.flow, %.splat206
  %1627 = load <8 x i1>, ptr %runnable.mask, align 1
  %1628 = xor <8 x i1> %1626, splat (i1 true)
  %1629 = and <8 x i1> %1627, %1628
  store <8 x i1> %1629, ptr %runnable.mask, align 1
  %.splatinsert207 = insertelement <8 x i1> poison, i1 %1617, i64 0
  %.splat208 = shufflevector <8 x i1> %.splatinsert207, <8 x i1> poison, <8 x i32> zeroinitializer
  %1630 = select <8 x i1> %.splat208, <8 x i1> %1612, <8 x i1> zeroinitializer
  %1631 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1632 = extractelement <8 x i32> %1631, i32 %1597
  %1633 = select i1 %1617, i32 %1632, i32 %1593
  store i32 %1633, ptr %current.token, align 4
  %.splatinsert209 = insertelement <8 x i1> poison, i1 %1607, i64 0
  %.splat210 = shufflevector <8 x i1> %.splatinsert209, <8 x i1> poison, <8 x i32> zeroinitializer
  %1634 = select <8 x i1> %.splat210, <8 x i1> %1630, <8 x i1> %convergence.cascade.flow
  %1635 = add i32 %convergence.cascade.depth, 1
  %1636 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1634)
  %1637 = icmp ult i32 %1635, 8
  %1638 = and i1 %1636, %1637
  %1639 = and i1 %1607, %1638
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %1640 = and i1 %1639, %convergence.parent.present
  br i1 %1640, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.2
  %convergence.cascade.result = phi <8 x i1> [ %194, %schedule.2 ], [ %1634, %convergence.cascade ]
  %1641 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1641, label %convergence.target.2.ready, label %scheduler.loop

convergence.target.2.ready:                       ; preds = %convergence.cascade.exit
  %1642 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1643 = bitcast <8 x i1> %convergence.cascade.result to i8
  %1644 = call i8 @llvm.cttz.i8(i8 %1643, i1 false)
  %1645 = zext i8 %1644 to i32
  %1646 = select i1 %1642, i32 %1645, i32 0
  %.spill.load211 = load <8 x i64>, ptr %.spill27, align 64
  %.spill.load212 = load i64, ptr %.spill16, align 4
  %.splatinsert213 = insertelement <8 x i64> poison, i64 %.spill.load212, i64 0
  %.splat214 = shufflevector <8 x i64> %.splatinsert213, <8 x i64> poison, <8 x i32> zeroinitializer
  %1647 = add <8 x i64> %.spill.load211, %.splat214
  %1648 = load volatile <8 x i64>, ptr %.spill29, align 64
  %1649 = select <8 x i1> %convergence.cascade.result, <8 x i64> %1647, <8 x i64> %1648
  store volatile <8 x i64> %1649, ptr %.spill29, align 64
  %.spill.load215 = load <8 x i1>, ptr %.spill26, align 1
  %1650 = and <8 x i1> %convergence.cascade.result, %.spill.load215
  %1651 = xor <8 x i1> %.spill.load215, splat (i1 true)
  %1652 = and <8 x i1> %convergence.cascade.result, %1651
  %1653 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1650)
  %1654 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1652)
  %1655 = and i1 %1653, %1654
  br i1 %1655, label %varying.divergent216, label %varying.coherent217

varying.divergent216:                             ; preds = %convergence.target.2.ready
  %1656 = load i32, ptr %current.token, align 4
  %1657 = icmp ne i32 %1656, 0
  %1658 = sub i32 %1656, 1
  %1659 = select i1 %1657, i32 %1658, i32 0
  %1660 = load i8, ptr %frame.active, align 1
  %1661 = trunc i32 %1659 to i8
  %1662 = shl i8 1, %1661
  %1663 = and i8 %1660, %1662
  %1664 = icmp ne i8 %1663, 0
  %1665 = load <8 x i32>, ptr %frame.static.id, align 32
  %1666 = extractelement <8 x i32> %1665, i32 %1659
  %1667 = icmp eq i32 %1666, 1
  %1668 = and i1 %1664, %1667
  %1669 = and i1 %1657, %1668
  %1670 = xor i1 %1669, true
  %1671 = and i1 true, %1670
  %1672 = xor i8 %1660, -1
  %1673 = icmp ne i8 %1672, 0
  %1674 = xor i1 %1673, true
  %1675 = and i1 %1671, %1674
  br i1 %1675, label %convergence.overflow.trap218, label %convergence.overflow.resume219

varying.coherent217:                              ; preds = %convergence.target.2.ready
  br i1 %1653, label %varying.coherent.true222, label %varying.coherent.false223

convergence.overflow.trap218:                     ; preds = %varying.divergent216
  call void @llvm.trap()
  unreachable

convergence.overflow.resume219:                   ; preds = %varying.divergent216
  %1676 = call i8 @llvm.cttz.i8(i8 %1672, i1 false)
  %1677 = zext i8 %1676 to i32
  %1678 = select i1 %1673, i32 %1677, i32 0
  %1679 = trunc i32 %1678 to i8
  %1680 = shl i8 1, %1679
  %1681 = or i8 %1660, %1680
  %1682 = select i1 %1671, i8 %1681, i8 %1660
  store i8 %1682, ptr %frame.active, align 1
  %1683 = load <8 x i32>, ptr %frame.static.id, align 32
  %1684 = extractelement <8 x i32> %1683, i32 %1678
  %1685 = select i1 %1671, i32 1, i32 %1684
  %1686 = load <8 x i32>, ptr %frame.static.id, align 32
  %1687 = insertelement <8 x i32> %1686, i32 %1685, i32 %1678
  store <8 x i32> %1687, ptr %frame.static.id, align 32
  %1688 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1689 = extractelement <8 x i32> %1688, i32 %1678
  %1690 = select i1 %1671, i32 %1656, i32 %1689
  %1691 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1692 = insertelement <8 x i32> %1691, i32 %1690, i32 %1678
  store <8 x i32> %1692, ptr %frame.parent.token, align 32
  %1693 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1678
  %1694 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1678
  %1695 = load <8 x i1>, ptr %1693, align 1
  %1696 = load <8 x i1>, ptr %1694, align 1
  %1697 = select i1 %1671, <8 x i1> %convergence.cascade.result, <8 x i1> %1695
  store <8 x i1> %1697, ptr %1693, align 1
  %1698 = select i1 %1671, <8 x i1> zeroinitializer, <8 x i1> %1696
  store <8 x i1> %1698, ptr %1694, align 1
  %1699 = add i32 %1678, 1
  %1700 = select i1 %1669, i32 %1656, i32 %1699
  %1701 = select i1 true, i32 %1700, i32 %1656
  store i32 %1701, ptr %current.token, align 4
  %1702 = load <8 x float>, ptr %.slot30, align 32
  %1703 = select <8 x i1> %1652, <8 x float> zeroinitializer, <8 x float> %1702
  store <8 x float> %1703, ptr %.slot30, align 32
  %1704 = load i32, ptr %current.token, align 4
  %1705 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1650)
  %1706 = load i32, ptr %ready.count, align 4
  %1707 = icmp uge i32 %1706, 8
  %1708 = and i1 %1705, %1707
  br i1 %1708, label %ready.overflow.trap220, label %ready.overflow.resume221

ready.overflow.trap220:                           ; preds = %convergence.overflow.resume219
  call void @llvm.trap()
  unreachable

ready.overflow.resume221:                         ; preds = %convergence.overflow.resume219
  %1709 = select i1 %1705, i32 %1706, i32 0
  %1710 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1709
  %1711 = load <8 x i1>, ptr %1710, align 1
  %1712 = select i1 %1705, <8 x i1> %1650, <8 x i1> %1711
  store <8 x i1> %1712, ptr %1710, align 1
  %1713 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1709
  %1714 = load i32, ptr %1713, align 4
  %1715 = select i1 %1705, i32 3, i32 %1714
  store i32 %1715, ptr %1713, align 4
  %1716 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1709
  %1717 = load i32, ptr %1716, align 4
  %1718 = select i1 %1705, i32 %1704, i32 %1717
  store i32 %1718, ptr %1716, align 4
  %1719 = add i32 %1706, 1
  %1720 = select i1 %1705, i32 %1719, i32 %1706
  store i32 %1720, ptr %ready.count, align 4
  %1721 = load <8 x i1>, ptr %runnable.mask, align 1
  %1722 = or <8 x i1> %1721, %1650
  store <8 x i1> %1722, ptr %runnable.mask, align 1
  store <8 x i1> %1652, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true222:                         ; preds = %varying.coherent217
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %1723 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1723, label %schedule.3, label %scheduler.loop

varying.coherent.false223:                        ; preds = %varying.coherent217
  %1724 = load <8 x float>, ptr %.slot30, align 32
  %1725 = select <8 x i1> %convergence.cascade.result, <8 x float> zeroinitializer, <8 x float> %1724
  store <8 x float> %1725, ptr %.slot30, align 32
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %1726 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1726, label %schedule.4, label %scheduler.loop

convergence.cascade225:                           ; preds = %convergence.cascade225, %schedule.4
  %convergence.cascade.flow229 = phi <8 x i1> [ %208, %schedule.4 ], [ %1769, %convergence.cascade225 ]
  %convergence.cascade.depth230 = phi i32 [ 0, %schedule.4 ], [ %1770, %convergence.cascade225 ]
  %1727 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow229)
  %1728 = load i32, ptr %current.token, align 4
  %1729 = icmp ne i32 %1728, 0
  %1730 = and i1 %1727, %1729
  %1731 = sub i32 %1728, 1
  %1732 = select i1 %1730, i32 %1731, i32 0
  %1733 = load i8, ptr %frame.active, align 1
  %1734 = trunc i32 %1732 to i8
  %1735 = shl i8 1, %1734
  %1736 = and i8 %1733, %1735
  %1737 = icmp ne i8 %1736, 0
  %1738 = load <8 x i32>, ptr %frame.static.id, align 32
  %1739 = extractelement <8 x i32> %1738, i32 %1732
  %convergence.target.pointer231 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %1739
  %convergence.dynamic.target232 = load i32, ptr %convergence.target.pointer231, align 4
  %1740 = icmp eq i32 %convergence.dynamic.target232, 4
  %1741 = and i1 %1737, %1740
  %1742 = and i1 %1730, %1741
  %1743 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1732
  %1744 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1732
  %1745 = load <8 x i1>, ptr %1743, align 1
  %1746 = load <8 x i1>, ptr %1744, align 1
  %1747 = or <8 x i1> %1746, %convergence.cascade.flow229
  %1748 = load <8 x i1>, ptr %live.mask, align 1
  %1749 = and <8 x i1> %1745, %1748
  %1750 = icmp eq <8 x i1> %1747, %1749
  %1751 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1750)
  %1752 = and i1 %1742, %1751
  %1753 = select i1 %1752, <8 x i1> zeroinitializer, <8 x i1> %1747
  %1754 = select i1 %1742, <8 x i1> %1753, <8 x i1> %1746
  store <8 x i1> %1754, ptr %1744, align 1
  %1755 = select i1 %1752, <8 x i1> zeroinitializer, <8 x i1> %1745
  store <8 x i1> %1755, ptr %1743, align 1
  %1756 = trunc i32 %1732 to i8
  %1757 = shl i8 1, %1756
  %1758 = xor i8 %1757, -1
  %1759 = and i8 %1733, %1758
  %1760 = select i1 %1752, i8 %1759, i8 %1733
  store i8 %1760, ptr %frame.active, align 1
  %.splatinsert233 = insertelement <8 x i1> poison, i1 %1742, i64 0
  %.splat234 = shufflevector <8 x i1> %.splatinsert233, <8 x i1> poison, <8 x i32> zeroinitializer
  %1761 = and <8 x i1> %convergence.cascade.flow229, %.splat234
  %1762 = load <8 x i1>, ptr %runnable.mask, align 1
  %1763 = xor <8 x i1> %1761, splat (i1 true)
  %1764 = and <8 x i1> %1762, %1763
  store <8 x i1> %1764, ptr %runnable.mask, align 1
  %.splatinsert235 = insertelement <8 x i1> poison, i1 %1752, i64 0
  %.splat236 = shufflevector <8 x i1> %.splatinsert235, <8 x i1> poison, <8 x i32> zeroinitializer
  %1765 = select <8 x i1> %.splat236, <8 x i1> %1747, <8 x i1> zeroinitializer
  %1766 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1767 = extractelement <8 x i32> %1766, i32 %1732
  %1768 = select i1 %1752, i32 %1767, i32 %1728
  store i32 %1768, ptr %current.token, align 4
  %.splatinsert237 = insertelement <8 x i1> poison, i1 %1742, i64 0
  %.splat238 = shufflevector <8 x i1> %.splatinsert237, <8 x i1> poison, <8 x i32> zeroinitializer
  %1769 = select <8 x i1> %.splat238, <8 x i1> %1765, <8 x i1> %convergence.cascade.flow229
  %1770 = add i32 %convergence.cascade.depth230, 1
  %1771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1769)
  %1772 = icmp ult i32 %1770, 8
  %1773 = and i1 %1771, %1772
  %1774 = and i1 %1742, %1773
  %convergence.parent.token239 = load i32, ptr %current.token, align 4
  %convergence.parent.present240 = icmp ne i32 %convergence.parent.token239, 0
  %1775 = and i1 %1774, %convergence.parent.present240
  br i1 %1775, label %convergence.cascade225, label %convergence.cascade.exit226

convergence.cascade.exit226:                      ; preds = %convergence.cascade225, %schedule.4
  %convergence.cascade.result241 = phi <8 x i1> [ %208, %schedule.4 ], [ %1769, %convergence.cascade225 ]
  %1776 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result241)
  br i1 %1776, label %convergence.target.4.ready, label %scheduler.loop

convergence.target.4.ready:                       ; preds = %convergence.cascade.exit226
  %1777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result241)
  %1778 = bitcast <8 x i1> %convergence.cascade.result241 to i8
  %1779 = call i8 @llvm.cttz.i8(i8 %1778, i1 false)
  %1780 = zext i8 %1779 to i32
  %1781 = select i1 %1777, i32 %1780, i32 0
  %.spill.load242 = load <8 x i64>, ptr %.spill27, align 64
  %.spill.load243 = load i64, ptr %.spill18, align 4
  %.splatinsert244 = insertelement <8 x i64> poison, i64 %.spill.load243, i64 0
  %.splat245 = shufflevector <8 x i64> %.splatinsert244, <8 x i64> poison, <8 x i32> zeroinitializer
  %1782 = add <8 x i64> %.spill.load242, %.splat245
  %1783 = load volatile <8 x i64>, ptr %.spill31, align 64
  %1784 = select <8 x i1> %convergence.cascade.result241, <8 x i64> %1782, <8 x i64> %1783
  store volatile <8 x i64> %1784, ptr %.spill31, align 64
  %.spill.load246 = load <8 x i1>, ptr %.spill26, align 1
  %1785 = and <8 x i1> %convergence.cascade.result241, %.spill.load246
  %1786 = xor <8 x i1> %.spill.load246, splat (i1 true)
  %1787 = and <8 x i1> %convergence.cascade.result241, %1786
  %1788 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1785)
  %1789 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1787)
  %1790 = and i1 %1788, %1789
  br i1 %1790, label %varying.divergent247, label %varying.coherent248

varying.divergent247:                             ; preds = %convergence.target.4.ready
  %1791 = load i32, ptr %current.token, align 4
  %1792 = icmp ne i32 %1791, 0
  %1793 = sub i32 %1791, 1
  %1794 = select i1 %1792, i32 %1793, i32 0
  %1795 = load i8, ptr %frame.active, align 1
  %1796 = trunc i32 %1794 to i8
  %1797 = shl i8 1, %1796
  %1798 = and i8 %1795, %1797
  %1799 = icmp ne i8 %1798, 0
  %1800 = load <8 x i32>, ptr %frame.static.id, align 32
  %1801 = extractelement <8 x i32> %1800, i32 %1794
  %1802 = icmp eq i32 %1801, 2
  %1803 = and i1 %1799, %1802
  %1804 = and i1 %1792, %1803
  %1805 = xor i1 %1804, true
  %1806 = and i1 true, %1805
  %1807 = xor i8 %1795, -1
  %1808 = icmp ne i8 %1807, 0
  %1809 = xor i1 %1808, true
  %1810 = and i1 %1806, %1809
  br i1 %1810, label %convergence.overflow.trap249, label %convergence.overflow.resume250

varying.coherent248:                              ; preds = %convergence.target.4.ready
  br i1 %1788, label %varying.coherent.true253, label %varying.coherent.false254

convergence.overflow.trap249:                     ; preds = %varying.divergent247
  call void @llvm.trap()
  unreachable

convergence.overflow.resume250:                   ; preds = %varying.divergent247
  %1811 = call i8 @llvm.cttz.i8(i8 %1807, i1 false)
  %1812 = zext i8 %1811 to i32
  %1813 = select i1 %1808, i32 %1812, i32 0
  %1814 = trunc i32 %1813 to i8
  %1815 = shl i8 1, %1814
  %1816 = or i8 %1795, %1815
  %1817 = select i1 %1806, i8 %1816, i8 %1795
  store i8 %1817, ptr %frame.active, align 1
  %1818 = load <8 x i32>, ptr %frame.static.id, align 32
  %1819 = extractelement <8 x i32> %1818, i32 %1813
  %1820 = select i1 %1806, i32 2, i32 %1819
  %1821 = load <8 x i32>, ptr %frame.static.id, align 32
  %1822 = insertelement <8 x i32> %1821, i32 %1820, i32 %1813
  store <8 x i32> %1822, ptr %frame.static.id, align 32
  %1823 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1824 = extractelement <8 x i32> %1823, i32 %1813
  %1825 = select i1 %1806, i32 %1791, i32 %1824
  %1826 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1827 = insertelement <8 x i32> %1826, i32 %1825, i32 %1813
  store <8 x i32> %1827, ptr %frame.parent.token, align 32
  %1828 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1813
  %1829 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1813
  %1830 = load <8 x i1>, ptr %1828, align 1
  %1831 = load <8 x i1>, ptr %1829, align 1
  %1832 = select i1 %1806, <8 x i1> %convergence.cascade.result241, <8 x i1> %1830
  store <8 x i1> %1832, ptr %1828, align 1
  %1833 = select i1 %1806, <8 x i1> zeroinitializer, <8 x i1> %1831
  store <8 x i1> %1833, ptr %1829, align 1
  %1834 = add i32 %1813, 1
  %1835 = select i1 %1804, i32 %1791, i32 %1834
  %1836 = select i1 true, i32 %1835, i32 %1791
  store i32 %1836, ptr %current.token, align 4
  %1837 = load <8 x float>, ptr %.slot32, align 32
  %1838 = select <8 x i1> %1787, <8 x float> zeroinitializer, <8 x float> %1837
  store <8 x float> %1838, ptr %.slot32, align 32
  %1839 = load i32, ptr %current.token, align 4
  %1840 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1785)
  %1841 = load i32, ptr %ready.count, align 4
  %1842 = icmp uge i32 %1841, 8
  %1843 = and i1 %1840, %1842
  br i1 %1843, label %ready.overflow.trap251, label %ready.overflow.resume252

ready.overflow.trap251:                           ; preds = %convergence.overflow.resume250
  call void @llvm.trap()
  unreachable

ready.overflow.resume252:                         ; preds = %convergence.overflow.resume250
  %1844 = select i1 %1840, i32 %1841, i32 0
  %1845 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1844
  %1846 = load <8 x i1>, ptr %1845, align 1
  %1847 = select i1 %1840, <8 x i1> %1785, <8 x i1> %1846
  store <8 x i1> %1847, ptr %1845, align 1
  %1848 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1844
  %1849 = load i32, ptr %1848, align 4
  %1850 = select i1 %1840, i32 5, i32 %1849
  store i32 %1850, ptr %1848, align 4
  %1851 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1844
  %1852 = load i32, ptr %1851, align 4
  %1853 = select i1 %1840, i32 %1839, i32 %1852
  store i32 %1853, ptr %1851, align 4
  %1854 = add i32 %1841, 1
  %1855 = select i1 %1840, i32 %1854, i32 %1841
  store i32 %1855, ptr %ready.count, align 4
  %1856 = load <8 x i1>, ptr %runnable.mask, align 1
  %1857 = or <8 x i1> %1856, %1785
  store <8 x i1> %1857, ptr %runnable.mask, align 1
  store <8 x i1> %1787, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true253:                         ; preds = %varying.coherent248
  store <8 x i1> %convergence.cascade.result241, ptr %current.mask, align 1
  %1858 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result241)
  br i1 %1858, label %schedule.5, label %scheduler.loop

varying.coherent.false254:                        ; preds = %varying.coherent248
  %1859 = load <8 x float>, ptr %.slot32, align 32
  %1860 = select <8 x i1> %convergence.cascade.result241, <8 x float> zeroinitializer, <8 x float> %1859
  store <8 x float> %1860, ptr %.slot32, align 32
  store <8 x i1> %convergence.cascade.result241, ptr %current.mask, align 1
  %1861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result241)
  br i1 %1861, label %schedule.6, label %scheduler.loop

convergence.cascade256:                           ; preds = %convergence.cascade256, %schedule.6
  %convergence.cascade.flow260 = phi <8 x i1> [ %222, %schedule.6 ], [ %1904, %convergence.cascade256 ]
  %convergence.cascade.depth261 = phi i32 [ 0, %schedule.6 ], [ %1905, %convergence.cascade256 ]
  %1862 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow260)
  %1863 = load i32, ptr %current.token, align 4
  %1864 = icmp ne i32 %1863, 0
  %1865 = and i1 %1862, %1864
  %1866 = sub i32 %1863, 1
  %1867 = select i1 %1865, i32 %1866, i32 0
  %1868 = load i8, ptr %frame.active, align 1
  %1869 = trunc i32 %1867 to i8
  %1870 = shl i8 1, %1869
  %1871 = and i8 %1868, %1870
  %1872 = icmp ne i8 %1871, 0
  %1873 = load <8 x i32>, ptr %frame.static.id, align 32
  %1874 = extractelement <8 x i32> %1873, i32 %1867
  %convergence.target.pointer262 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %1874
  %convergence.dynamic.target263 = load i32, ptr %convergence.target.pointer262, align 4
  %1875 = icmp eq i32 %convergence.dynamic.target263, 6
  %1876 = and i1 %1872, %1875
  %1877 = and i1 %1865, %1876
  %1878 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1867
  %1879 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1867
  %1880 = load <8 x i1>, ptr %1878, align 1
  %1881 = load <8 x i1>, ptr %1879, align 1
  %1882 = or <8 x i1> %1881, %convergence.cascade.flow260
  %1883 = load <8 x i1>, ptr %live.mask, align 1
  %1884 = and <8 x i1> %1880, %1883
  %1885 = icmp eq <8 x i1> %1882, %1884
  %1886 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1885)
  %1887 = and i1 %1877, %1886
  %1888 = select i1 %1887, <8 x i1> zeroinitializer, <8 x i1> %1882
  %1889 = select i1 %1877, <8 x i1> %1888, <8 x i1> %1881
  store <8 x i1> %1889, ptr %1879, align 1
  %1890 = select i1 %1887, <8 x i1> zeroinitializer, <8 x i1> %1880
  store <8 x i1> %1890, ptr %1878, align 1
  %1891 = trunc i32 %1867 to i8
  %1892 = shl i8 1, %1891
  %1893 = xor i8 %1892, -1
  %1894 = and i8 %1868, %1893
  %1895 = select i1 %1887, i8 %1894, i8 %1868
  store i8 %1895, ptr %frame.active, align 1
  %.splatinsert264 = insertelement <8 x i1> poison, i1 %1877, i64 0
  %.splat265 = shufflevector <8 x i1> %.splatinsert264, <8 x i1> poison, <8 x i32> zeroinitializer
  %1896 = and <8 x i1> %convergence.cascade.flow260, %.splat265
  %1897 = load <8 x i1>, ptr %runnable.mask, align 1
  %1898 = xor <8 x i1> %1896, splat (i1 true)
  %1899 = and <8 x i1> %1897, %1898
  store <8 x i1> %1899, ptr %runnable.mask, align 1
  %.splatinsert266 = insertelement <8 x i1> poison, i1 %1887, i64 0
  %.splat267 = shufflevector <8 x i1> %.splatinsert266, <8 x i1> poison, <8 x i32> zeroinitializer
  %1900 = select <8 x i1> %.splat267, <8 x i1> %1882, <8 x i1> zeroinitializer
  %1901 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1902 = extractelement <8 x i32> %1901, i32 %1867
  %1903 = select i1 %1887, i32 %1902, i32 %1863
  store i32 %1903, ptr %current.token, align 4
  %.splatinsert268 = insertelement <8 x i1> poison, i1 %1877, i64 0
  %.splat269 = shufflevector <8 x i1> %.splatinsert268, <8 x i1> poison, <8 x i32> zeroinitializer
  %1904 = select <8 x i1> %.splat269, <8 x i1> %1900, <8 x i1> %convergence.cascade.flow260
  %1905 = add i32 %convergence.cascade.depth261, 1
  %1906 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1904)
  %1907 = icmp ult i32 %1905, 8
  %1908 = and i1 %1906, %1907
  %1909 = and i1 %1877, %1908
  %convergence.parent.token270 = load i32, ptr %current.token, align 4
  %convergence.parent.present271 = icmp ne i32 %convergence.parent.token270, 0
  %1910 = and i1 %1909, %convergence.parent.present271
  br i1 %1910, label %convergence.cascade256, label %convergence.cascade.exit257

convergence.cascade.exit257:                      ; preds = %convergence.cascade256, %schedule.6
  %convergence.cascade.result272 = phi <8 x i1> [ %222, %schedule.6 ], [ %1904, %convergence.cascade256 ]
  %1911 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result272)
  br i1 %1911, label %convergence.target.6.ready, label %scheduler.loop

convergence.target.6.ready:                       ; preds = %convergence.cascade.exit257
  %1912 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result272)
  %1913 = bitcast <8 x i1> %convergence.cascade.result272 to i8
  %1914 = call i8 @llvm.cttz.i8(i8 %1913, i1 false)
  %1915 = zext i8 %1914 to i32
  %1916 = select i1 %1912, i32 %1915, i32 0
  %.spill.load273 = load <8 x i64>, ptr %.spill27, align 64
  %.spill.load274 = load i64, ptr %.spill20, align 4
  %.splatinsert275 = insertelement <8 x i64> poison, i64 %.spill.load274, i64 0
  %.splat276 = shufflevector <8 x i64> %.splatinsert275, <8 x i64> poison, <8 x i32> zeroinitializer
  %1917 = add <8 x i64> %.spill.load273, %.splat276
  %1918 = load volatile <8 x i64>, ptr %.spill33, align 64
  %1919 = select <8 x i1> %convergence.cascade.result272, <8 x i64> %1917, <8 x i64> %1918
  store volatile <8 x i64> %1919, ptr %.spill33, align 64
  %.spill.load277 = load <8 x i1>, ptr %.spill26, align 1
  %1920 = and <8 x i1> %convergence.cascade.result272, %.spill.load277
  %1921 = xor <8 x i1> %.spill.load277, splat (i1 true)
  %1922 = and <8 x i1> %convergence.cascade.result272, %1921
  %1923 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1920)
  %1924 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1922)
  %1925 = and i1 %1923, %1924
  br i1 %1925, label %varying.divergent278, label %varying.coherent279

varying.divergent278:                             ; preds = %convergence.target.6.ready
  %1926 = load i32, ptr %current.token, align 4
  %1927 = icmp ne i32 %1926, 0
  %1928 = sub i32 %1926, 1
  %1929 = select i1 %1927, i32 %1928, i32 0
  %1930 = load i8, ptr %frame.active, align 1
  %1931 = trunc i32 %1929 to i8
  %1932 = shl i8 1, %1931
  %1933 = and i8 %1930, %1932
  %1934 = icmp ne i8 %1933, 0
  %1935 = load <8 x i32>, ptr %frame.static.id, align 32
  %1936 = extractelement <8 x i32> %1935, i32 %1929
  %1937 = icmp eq i32 %1936, 3
  %1938 = and i1 %1934, %1937
  %1939 = and i1 %1927, %1938
  %1940 = xor i1 %1939, true
  %1941 = and i1 true, %1940
  %1942 = xor i8 %1930, -1
  %1943 = icmp ne i8 %1942, 0
  %1944 = xor i1 %1943, true
  %1945 = and i1 %1941, %1944
  br i1 %1945, label %convergence.overflow.trap280, label %convergence.overflow.resume281

varying.coherent279:                              ; preds = %convergence.target.6.ready
  br i1 %1923, label %varying.coherent.true284, label %varying.coherent.false285

convergence.overflow.trap280:                     ; preds = %varying.divergent278
  call void @llvm.trap()
  unreachable

convergence.overflow.resume281:                   ; preds = %varying.divergent278
  %1946 = call i8 @llvm.cttz.i8(i8 %1942, i1 false)
  %1947 = zext i8 %1946 to i32
  %1948 = select i1 %1943, i32 %1947, i32 0
  %1949 = trunc i32 %1948 to i8
  %1950 = shl i8 1, %1949
  %1951 = or i8 %1930, %1950
  %1952 = select i1 %1941, i8 %1951, i8 %1930
  store i8 %1952, ptr %frame.active, align 1
  %1953 = load <8 x i32>, ptr %frame.static.id, align 32
  %1954 = extractelement <8 x i32> %1953, i32 %1948
  %1955 = select i1 %1941, i32 3, i32 %1954
  %1956 = load <8 x i32>, ptr %frame.static.id, align 32
  %1957 = insertelement <8 x i32> %1956, i32 %1955, i32 %1948
  store <8 x i32> %1957, ptr %frame.static.id, align 32
  %1958 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1959 = extractelement <8 x i32> %1958, i32 %1948
  %1960 = select i1 %1941, i32 %1926, i32 %1959
  %1961 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1962 = insertelement <8 x i32> %1961, i32 %1960, i32 %1948
  store <8 x i32> %1962, ptr %frame.parent.token, align 32
  %1963 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1948
  %1964 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1948
  %1965 = load <8 x i1>, ptr %1963, align 1
  %1966 = load <8 x i1>, ptr %1964, align 1
  %1967 = select i1 %1941, <8 x i1> %convergence.cascade.result272, <8 x i1> %1965
  store <8 x i1> %1967, ptr %1963, align 1
  %1968 = select i1 %1941, <8 x i1> zeroinitializer, <8 x i1> %1966
  store <8 x i1> %1968, ptr %1964, align 1
  %1969 = add i32 %1948, 1
  %1970 = select i1 %1939, i32 %1926, i32 %1969
  %1971 = select i1 true, i32 %1970, i32 %1926
  store i32 %1971, ptr %current.token, align 4
  %1972 = load <8 x float>, ptr %.slot34, align 32
  %1973 = select <8 x i1> %1922, <8 x float> zeroinitializer, <8 x float> %1972
  store <8 x float> %1973, ptr %.slot34, align 32
  %1974 = load i32, ptr %current.token, align 4
  %1975 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1920)
  %1976 = load i32, ptr %ready.count, align 4
  %1977 = icmp uge i32 %1976, 8
  %1978 = and i1 %1975, %1977
  br i1 %1978, label %ready.overflow.trap282, label %ready.overflow.resume283

ready.overflow.trap282:                           ; preds = %convergence.overflow.resume281
  call void @llvm.trap()
  unreachable

ready.overflow.resume283:                         ; preds = %convergence.overflow.resume281
  %1979 = select i1 %1975, i32 %1976, i32 0
  %1980 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1979
  %1981 = load <8 x i1>, ptr %1980, align 1
  %1982 = select i1 %1975, <8 x i1> %1920, <8 x i1> %1981
  store <8 x i1> %1982, ptr %1980, align 1
  %1983 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1979
  %1984 = load i32, ptr %1983, align 4
  %1985 = select i1 %1975, i32 7, i32 %1984
  store i32 %1985, ptr %1983, align 4
  %1986 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1979
  %1987 = load i32, ptr %1986, align 4
  %1988 = select i1 %1975, i32 %1974, i32 %1987
  store i32 %1988, ptr %1986, align 4
  %1989 = add i32 %1976, 1
  %1990 = select i1 %1975, i32 %1989, i32 %1976
  store i32 %1990, ptr %ready.count, align 4
  %1991 = load <8 x i1>, ptr %runnable.mask, align 1
  %1992 = or <8 x i1> %1991, %1920
  store <8 x i1> %1992, ptr %runnable.mask, align 1
  store <8 x i1> %1922, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true284:                         ; preds = %varying.coherent279
  store <8 x i1> %convergence.cascade.result272, ptr %current.mask, align 1
  %1993 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result272)
  br i1 %1993, label %schedule.7, label %scheduler.loop

varying.coherent.false285:                        ; preds = %varying.coherent279
  %1994 = load <8 x float>, ptr %.slot34, align 32
  %1995 = select <8 x i1> %convergence.cascade.result272, <8 x float> zeroinitializer, <8 x float> %1994
  store <8 x float> %1995, ptr %.slot34, align 32
  store <8 x i1> %convergence.cascade.result272, ptr %current.mask, align 1
  %1996 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result272)
  br i1 %1996, label %schedule.8, label %scheduler.loop

convergence.cascade287:                           ; preds = %convergence.cascade287, %schedule.8
  %convergence.cascade.flow291 = phi <8 x i1> [ %236, %schedule.8 ], [ %2039, %convergence.cascade287 ]
  %convergence.cascade.depth292 = phi i32 [ 0, %schedule.8 ], [ %2040, %convergence.cascade287 ]
  %1997 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow291)
  %1998 = load i32, ptr %current.token, align 4
  %1999 = icmp ne i32 %1998, 0
  %2000 = and i1 %1997, %1999
  %2001 = sub i32 %1998, 1
  %2002 = select i1 %2000, i32 %2001, i32 0
  %2003 = load i8, ptr %frame.active, align 1
  %2004 = trunc i32 %2002 to i8
  %2005 = shl i8 1, %2004
  %2006 = and i8 %2003, %2005
  %2007 = icmp ne i8 %2006, 0
  %2008 = load <8 x i32>, ptr %frame.static.id, align 32
  %2009 = extractelement <8 x i32> %2008, i32 %2002
  %convergence.target.pointer293 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %2009
  %convergence.dynamic.target294 = load i32, ptr %convergence.target.pointer293, align 4
  %2010 = icmp eq i32 %convergence.dynamic.target294, 8
  %2011 = and i1 %2007, %2010
  %2012 = and i1 %2000, %2011
  %2013 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2002
  %2014 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2002
  %2015 = load <8 x i1>, ptr %2013, align 1
  %2016 = load <8 x i1>, ptr %2014, align 1
  %2017 = or <8 x i1> %2016, %convergence.cascade.flow291
  %2018 = load <8 x i1>, ptr %live.mask, align 1
  %2019 = and <8 x i1> %2015, %2018
  %2020 = icmp eq <8 x i1> %2017, %2019
  %2021 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2020)
  %2022 = and i1 %2012, %2021
  %2023 = select i1 %2022, <8 x i1> zeroinitializer, <8 x i1> %2017
  %2024 = select i1 %2012, <8 x i1> %2023, <8 x i1> %2016
  store <8 x i1> %2024, ptr %2014, align 1
  %2025 = select i1 %2022, <8 x i1> zeroinitializer, <8 x i1> %2015
  store <8 x i1> %2025, ptr %2013, align 1
  %2026 = trunc i32 %2002 to i8
  %2027 = shl i8 1, %2026
  %2028 = xor i8 %2027, -1
  %2029 = and i8 %2003, %2028
  %2030 = select i1 %2022, i8 %2029, i8 %2003
  store i8 %2030, ptr %frame.active, align 1
  %.splatinsert295 = insertelement <8 x i1> poison, i1 %2012, i64 0
  %.splat296 = shufflevector <8 x i1> %.splatinsert295, <8 x i1> poison, <8 x i32> zeroinitializer
  %2031 = and <8 x i1> %convergence.cascade.flow291, %.splat296
  %2032 = load <8 x i1>, ptr %runnable.mask, align 1
  %2033 = xor <8 x i1> %2031, splat (i1 true)
  %2034 = and <8 x i1> %2032, %2033
  store <8 x i1> %2034, ptr %runnable.mask, align 1
  %.splatinsert297 = insertelement <8 x i1> poison, i1 %2022, i64 0
  %.splat298 = shufflevector <8 x i1> %.splatinsert297, <8 x i1> poison, <8 x i32> zeroinitializer
  %2035 = select <8 x i1> %.splat298, <8 x i1> %2017, <8 x i1> zeroinitializer
  %2036 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2037 = extractelement <8 x i32> %2036, i32 %2002
  %2038 = select i1 %2022, i32 %2037, i32 %1998
  store i32 %2038, ptr %current.token, align 4
  %.splatinsert299 = insertelement <8 x i1> poison, i1 %2012, i64 0
  %.splat300 = shufflevector <8 x i1> %.splatinsert299, <8 x i1> poison, <8 x i32> zeroinitializer
  %2039 = select <8 x i1> %.splat300, <8 x i1> %2035, <8 x i1> %convergence.cascade.flow291
  %2040 = add i32 %convergence.cascade.depth292, 1
  %2041 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2039)
  %2042 = icmp ult i32 %2040, 8
  %2043 = and i1 %2041, %2042
  %2044 = and i1 %2012, %2043
  %convergence.parent.token301 = load i32, ptr %current.token, align 4
  %convergence.parent.present302 = icmp ne i32 %convergence.parent.token301, 0
  %2045 = and i1 %2044, %convergence.parent.present302
  br i1 %2045, label %convergence.cascade287, label %convergence.cascade.exit288

convergence.cascade.exit288:                      ; preds = %convergence.cascade287, %schedule.8
  %convergence.cascade.result303 = phi <8 x i1> [ %236, %schedule.8 ], [ %2039, %convergence.cascade287 ]
  %2046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result303)
  br i1 %2046, label %convergence.target.8.ready, label %scheduler.loop

convergence.target.8.ready:                       ; preds = %convergence.cascade.exit288
  %2047 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result303)
  %2048 = bitcast <8 x i1> %convergence.cascade.result303 to i8
  %2049 = call i8 @llvm.cttz.i8(i8 %2048, i1 false)
  %2050 = zext i8 %2049 to i32
  %2051 = select i1 %2047, i32 %2050, i32 0
  %.spill.load304 = load <8 x i64>, ptr %.spill27, align 64
  %.spill.load305 = load volatile i64, ptr %.spill22, align 4
  %.splatinsert306 = insertelement <8 x i64> poison, i64 %.spill.load305, i64 0
  %.splat307 = shufflevector <8 x i64> %.splatinsert306, <8 x i64> poison, <8 x i32> zeroinitializer
  %2052 = add <8 x i64> %.spill.load304, %.splat307
  %2053 = load volatile <8 x i64>, ptr %.spill35, align 64
  %2054 = select <8 x i1> %convergence.cascade.result303, <8 x i64> %2052, <8 x i64> %2053
  store volatile <8 x i64> %2054, ptr %.spill35, align 64
  %.spill.load308 = load <8 x i1>, ptr %.spill26, align 1
  %2055 = and <8 x i1> %convergence.cascade.result303, %.spill.load308
  %2056 = xor <8 x i1> %.spill.load308, splat (i1 true)
  %2057 = and <8 x i1> %convergence.cascade.result303, %2056
  %2058 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2055)
  %2059 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2057)
  %2060 = and i1 %2058, %2059
  br i1 %2060, label %varying.divergent309, label %varying.coherent310

varying.divergent309:                             ; preds = %convergence.target.8.ready
  %2061 = load i32, ptr %current.token, align 4
  %2062 = icmp ne i32 %2061, 0
  %2063 = sub i32 %2061, 1
  %2064 = select i1 %2062, i32 %2063, i32 0
  %2065 = load i8, ptr %frame.active, align 1
  %2066 = trunc i32 %2064 to i8
  %2067 = shl i8 1, %2066
  %2068 = and i8 %2065, %2067
  %2069 = icmp ne i8 %2068, 0
  %2070 = load <8 x i32>, ptr %frame.static.id, align 32
  %2071 = extractelement <8 x i32> %2070, i32 %2064
  %2072 = icmp eq i32 %2071, 4
  %2073 = and i1 %2069, %2072
  %2074 = and i1 %2062, %2073
  %2075 = xor i1 %2074, true
  %2076 = and i1 true, %2075
  %2077 = xor i8 %2065, -1
  %2078 = icmp ne i8 %2077, 0
  %2079 = xor i1 %2078, true
  %2080 = and i1 %2076, %2079
  br i1 %2080, label %convergence.overflow.trap311, label %convergence.overflow.resume312

varying.coherent310:                              ; preds = %convergence.target.8.ready
  br i1 %2058, label %varying.coherent.true315, label %varying.coherent.false316

convergence.overflow.trap311:                     ; preds = %varying.divergent309
  call void @llvm.trap()
  unreachable

convergence.overflow.resume312:                   ; preds = %varying.divergent309
  %2081 = call i8 @llvm.cttz.i8(i8 %2077, i1 false)
  %2082 = zext i8 %2081 to i32
  %2083 = select i1 %2078, i32 %2082, i32 0
  %2084 = trunc i32 %2083 to i8
  %2085 = shl i8 1, %2084
  %2086 = or i8 %2065, %2085
  %2087 = select i1 %2076, i8 %2086, i8 %2065
  store i8 %2087, ptr %frame.active, align 1
  %2088 = load <8 x i32>, ptr %frame.static.id, align 32
  %2089 = extractelement <8 x i32> %2088, i32 %2083
  %2090 = select i1 %2076, i32 4, i32 %2089
  %2091 = load <8 x i32>, ptr %frame.static.id, align 32
  %2092 = insertelement <8 x i32> %2091, i32 %2090, i32 %2083
  store <8 x i32> %2092, ptr %frame.static.id, align 32
  %2093 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2094 = extractelement <8 x i32> %2093, i32 %2083
  %2095 = select i1 %2076, i32 %2061, i32 %2094
  %2096 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2097 = insertelement <8 x i32> %2096, i32 %2095, i32 %2083
  store <8 x i32> %2097, ptr %frame.parent.token, align 32
  %2098 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2083
  %2099 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2083
  %2100 = load <8 x i1>, ptr %2098, align 1
  %2101 = load <8 x i1>, ptr %2099, align 1
  %2102 = select i1 %2076, <8 x i1> %convergence.cascade.result303, <8 x i1> %2100
  store <8 x i1> %2102, ptr %2098, align 1
  %2103 = select i1 %2076, <8 x i1> zeroinitializer, <8 x i1> %2101
  store <8 x i1> %2103, ptr %2099, align 1
  %2104 = add i32 %2083, 1
  %2105 = select i1 %2074, i32 %2061, i32 %2104
  %2106 = select i1 true, i32 %2105, i32 %2061
  store i32 %2106, ptr %current.token, align 4
  %2107 = load <8 x float>, ptr %.slot36, align 32
  %2108 = select <8 x i1> %2057, <8 x float> zeroinitializer, <8 x float> %2107
  store <8 x float> %2108, ptr %.slot36, align 32
  %2109 = load i32, ptr %current.token, align 4
  %2110 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2055)
  %2111 = load i32, ptr %ready.count, align 4
  %2112 = icmp uge i32 %2111, 8
  %2113 = and i1 %2110, %2112
  br i1 %2113, label %ready.overflow.trap313, label %ready.overflow.resume314

ready.overflow.trap313:                           ; preds = %convergence.overflow.resume312
  call void @llvm.trap()
  unreachable

ready.overflow.resume314:                         ; preds = %convergence.overflow.resume312
  %2114 = select i1 %2110, i32 %2111, i32 0
  %2115 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2114
  %2116 = load <8 x i1>, ptr %2115, align 1
  %2117 = select i1 %2110, <8 x i1> %2055, <8 x i1> %2116
  store <8 x i1> %2117, ptr %2115, align 1
  %2118 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2114
  %2119 = load i32, ptr %2118, align 4
  %2120 = select i1 %2110, i32 9, i32 %2119
  store i32 %2120, ptr %2118, align 4
  %2121 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2114
  %2122 = load i32, ptr %2121, align 4
  %2123 = select i1 %2110, i32 %2109, i32 %2122
  store i32 %2123, ptr %2121, align 4
  %2124 = add i32 %2111, 1
  %2125 = select i1 %2110, i32 %2124, i32 %2111
  store i32 %2125, ptr %ready.count, align 4
  %2126 = load <8 x i1>, ptr %runnable.mask, align 1
  %2127 = or <8 x i1> %2126, %2055
  store <8 x i1> %2127, ptr %runnable.mask, align 1
  store <8 x i1> %2057, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true315:                         ; preds = %varying.coherent310
  store <8 x i1> %convergence.cascade.result303, ptr %current.mask, align 1
  %2128 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result303)
  br i1 %2128, label %schedule.9, label %scheduler.loop

varying.coherent.false316:                        ; preds = %varying.coherent310
  %2129 = load <8 x float>, ptr %.slot36, align 32
  %2130 = select <8 x i1> %convergence.cascade.result303, <8 x float> zeroinitializer, <8 x float> %2129
  store <8 x float> %2130, ptr %.slot36, align 32
  store <8 x i1> %convergence.cascade.result303, ptr %current.mask, align 1
  %2131 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result303)
  br i1 %2131, label %schedule.10, label %scheduler.loop

convergence.cascade318:                           ; preds = %convergence.cascade318, %schedule.10
  %convergence.cascade.flow322 = phi <8 x i1> [ %250, %schedule.10 ], [ %2174, %convergence.cascade318 ]
  %convergence.cascade.depth323 = phi i32 [ 0, %schedule.10 ], [ %2175, %convergence.cascade318 ]
  %2132 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow322)
  %2133 = load i32, ptr %current.token, align 4
  %2134 = icmp ne i32 %2133, 0
  %2135 = and i1 %2132, %2134
  %2136 = sub i32 %2133, 1
  %2137 = select i1 %2135, i32 %2136, i32 0
  %2138 = load i8, ptr %frame.active, align 1
  %2139 = trunc i32 %2137 to i8
  %2140 = shl i8 1, %2139
  %2141 = and i8 %2138, %2140
  %2142 = icmp ne i8 %2141, 0
  %2143 = load <8 x i32>, ptr %frame.static.id, align 32
  %2144 = extractelement <8 x i32> %2143, i32 %2137
  %convergence.target.pointer324 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %2144
  %convergence.dynamic.target325 = load i32, ptr %convergence.target.pointer324, align 4
  %2145 = icmp eq i32 %convergence.dynamic.target325, 10
  %2146 = and i1 %2142, %2145
  %2147 = and i1 %2135, %2146
  %2148 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2137
  %2149 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2137
  %2150 = load <8 x i1>, ptr %2148, align 1
  %2151 = load <8 x i1>, ptr %2149, align 1
  %2152 = or <8 x i1> %2151, %convergence.cascade.flow322
  %2153 = load <8 x i1>, ptr %live.mask, align 1
  %2154 = and <8 x i1> %2150, %2153
  %2155 = icmp eq <8 x i1> %2152, %2154
  %2156 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2155)
  %2157 = and i1 %2147, %2156
  %2158 = select i1 %2157, <8 x i1> zeroinitializer, <8 x i1> %2152
  %2159 = select i1 %2147, <8 x i1> %2158, <8 x i1> %2151
  store <8 x i1> %2159, ptr %2149, align 1
  %2160 = select i1 %2157, <8 x i1> zeroinitializer, <8 x i1> %2150
  store <8 x i1> %2160, ptr %2148, align 1
  %2161 = trunc i32 %2137 to i8
  %2162 = shl i8 1, %2161
  %2163 = xor i8 %2162, -1
  %2164 = and i8 %2138, %2163
  %2165 = select i1 %2157, i8 %2164, i8 %2138
  store i8 %2165, ptr %frame.active, align 1
  %.splatinsert326 = insertelement <8 x i1> poison, i1 %2147, i64 0
  %.splat327 = shufflevector <8 x i1> %.splatinsert326, <8 x i1> poison, <8 x i32> zeroinitializer
  %2166 = and <8 x i1> %convergence.cascade.flow322, %.splat327
  %2167 = load <8 x i1>, ptr %runnable.mask, align 1
  %2168 = xor <8 x i1> %2166, splat (i1 true)
  %2169 = and <8 x i1> %2167, %2168
  store <8 x i1> %2169, ptr %runnable.mask, align 1
  %.splatinsert328 = insertelement <8 x i1> poison, i1 %2157, i64 0
  %.splat329 = shufflevector <8 x i1> %.splatinsert328, <8 x i1> poison, <8 x i32> zeroinitializer
  %2170 = select <8 x i1> %.splat329, <8 x i1> %2152, <8 x i1> zeroinitializer
  %2171 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2172 = extractelement <8 x i32> %2171, i32 %2137
  %2173 = select i1 %2157, i32 %2172, i32 %2133
  store i32 %2173, ptr %current.token, align 4
  %.splatinsert330 = insertelement <8 x i1> poison, i1 %2147, i64 0
  %.splat331 = shufflevector <8 x i1> %.splatinsert330, <8 x i1> poison, <8 x i32> zeroinitializer
  %2174 = select <8 x i1> %.splat331, <8 x i1> %2170, <8 x i1> %convergence.cascade.flow322
  %2175 = add i32 %convergence.cascade.depth323, 1
  %2176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2174)
  %2177 = icmp ult i32 %2175, 8
  %2178 = and i1 %2176, %2177
  %2179 = and i1 %2147, %2178
  %convergence.parent.token332 = load i32, ptr %current.token, align 4
  %convergence.parent.present333 = icmp ne i32 %convergence.parent.token332, 0
  %2180 = and i1 %2179, %convergence.parent.present333
  br i1 %2180, label %convergence.cascade318, label %convergence.cascade.exit319

convergence.cascade.exit319:                      ; preds = %convergence.cascade318, %schedule.10
  %convergence.cascade.result334 = phi <8 x i1> [ %250, %schedule.10 ], [ %2174, %convergence.cascade318 ]
  %2181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result334)
  br i1 %2181, label %convergence.target.10.ready, label %scheduler.loop

convergence.target.10.ready:                      ; preds = %convergence.cascade.exit319
  %2182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result334)
  %2183 = bitcast <8 x i1> %convergence.cascade.result334 to i8
  %2184 = call i8 @llvm.cttz.i8(i8 %2183, i1 false)
  %2185 = zext i8 %2184 to i32
  %2186 = select i1 %2182, i32 %2185, i32 0
  %2187 = load <8 x i64>, ptr %.slot37, align 64
  %2188 = select <8 x i1> %convergence.cascade.result334, <8 x i64> zeroinitializer, <8 x i64> %2187
  store <8 x i64> %2188, ptr %.slot37, align 64
  %2189 = load <8 x float>, ptr %.slot38, align 32
  %2190 = select <8 x i1> %convergence.cascade.result334, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2189
  store <8 x float> %2190, ptr %.slot38, align 32
  %2191 = load <8 x float>, ptr %.slot39, align 32
  %2192 = select <8 x i1> %convergence.cascade.result334, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2191
  store <8 x float> %2192, ptr %.slot39, align 32
  %2193 = load <8 x float>, ptr %.slot40, align 32
  %2194 = select <8 x i1> %convergence.cascade.result334, <8 x float> zeroinitializer, <8 x float> %2193
  store <8 x float> %2194, ptr %.slot40, align 32
  %2195 = load <8 x float>, ptr %.slot41, align 32
  %2196 = select <8 x i1> %convergence.cascade.result334, <8 x float> zeroinitializer, <8 x float> %2195
  store <8 x float> %2196, ptr %.slot41, align 32
  %2197 = load <8 x float>, ptr %.slot42, align 32
  %2198 = select <8 x i1> %convergence.cascade.result334, <8 x float> zeroinitializer, <8 x float> %2197
  store <8 x float> %2198, ptr %.slot42, align 32
  %2199 = load <8 x float>, ptr %.slot43, align 32
  %2200 = select <8 x i1> %convergence.cascade.result334, <8 x float> zeroinitializer, <8 x float> %2199
  store <8 x float> %2200, ptr %.slot43, align 32
  %2201 = load <8 x float>, ptr %.slot44, align 32
  %2202 = select <8 x i1> %convergence.cascade.result334, <8 x float> zeroinitializer, <8 x float> %2201
  store <8 x float> %2202, ptr %.slot44, align 32
  %2203 = load <8 x float>, ptr %.slot45, align 32
  %2204 = select <8 x i1> %convergence.cascade.result334, <8 x float> zeroinitializer, <8 x float> %2203
  store <8 x float> %2204, ptr %.slot45, align 32
  %2205 = load <8 x float>, ptr %.slot46, align 32
  %2206 = select <8 x i1> %convergence.cascade.result334, <8 x float> zeroinitializer, <8 x float> %2205
  store <8 x float> %2206, ptr %.slot46, align 32
  %2207 = load <8 x float>, ptr %.slot47, align 32
  %2208 = select <8 x i1> %convergence.cascade.result334, <8 x float> zeroinitializer, <8 x float> %2207
  store <8 x float> %2208, ptr %.slot47, align 32
  %2209 = load <8 x float>, ptr %.slot48, align 32
  %2210 = select <8 x i1> %convergence.cascade.result334, <8 x float> zeroinitializer, <8 x float> %2209
  store <8 x float> %2210, ptr %.slot48, align 32
  %2211 = load <8 x float>, ptr %.slot49, align 32
  %2212 = select <8 x i1> %convergence.cascade.result334, <8 x float> zeroinitializer, <8 x float> %2211
  store <8 x float> %2212, ptr %.slot49, align 32
  store <8 x i1> %convergence.cascade.result334, ptr %current.mask, align 1
  %2213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result334)
  br i1 %2213, label %schedule.11, label %scheduler.loop

varying.divergent335:                             ; preds = %schedule.11
  %2214 = load i32, ptr %current.token, align 4
  %2215 = icmp ne i32 %2214, 0
  %2216 = sub i32 %2214, 1
  %2217 = select i1 %2215, i32 %2216, i32 0
  %2218 = load i8, ptr %frame.active, align 1
  %2219 = trunc i32 %2217 to i8
  %2220 = shl i8 1, %2219
  %2221 = and i8 %2218, %2220
  %2222 = icmp ne i8 %2221, 0
  %2223 = load <8 x i32>, ptr %frame.static.id, align 32
  %2224 = extractelement <8 x i32> %2223, i32 %2217
  %2225 = icmp eq i32 %2224, 5
  %2226 = and i1 %2222, %2225
  %2227 = and i1 %2215, %2226
  %2228 = xor i1 %2227, true
  %2229 = and i1 true, %2228
  %2230 = xor i8 %2218, -1
  %2231 = icmp ne i8 %2230, 0
  %2232 = xor i1 %2231, true
  %2233 = and i1 %2229, %2232
  br i1 %2233, label %convergence.overflow.trap337, label %convergence.overflow.resume338

varying.coherent336:                              ; preds = %schedule.11
  br i1 %261, label %varying.coherent.true341, label %varying.coherent.false342

convergence.overflow.trap337:                     ; preds = %varying.divergent335
  call void @llvm.trap()
  unreachable

convergence.overflow.resume338:                   ; preds = %varying.divergent335
  %2234 = call i8 @llvm.cttz.i8(i8 %2230, i1 false)
  %2235 = zext i8 %2234 to i32
  %2236 = select i1 %2231, i32 %2235, i32 0
  %2237 = trunc i32 %2236 to i8
  %2238 = shl i8 1, %2237
  %2239 = or i8 %2218, %2238
  %2240 = select i1 %2229, i8 %2239, i8 %2218
  store i8 %2240, ptr %frame.active, align 1
  %2241 = load <8 x i32>, ptr %frame.static.id, align 32
  %2242 = extractelement <8 x i32> %2241, i32 %2236
  %2243 = select i1 %2229, i32 5, i32 %2242
  %2244 = load <8 x i32>, ptr %frame.static.id, align 32
  %2245 = insertelement <8 x i32> %2244, i32 %2243, i32 %2236
  store <8 x i32> %2245, ptr %frame.static.id, align 32
  %2246 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2247 = extractelement <8 x i32> %2246, i32 %2236
  %2248 = select i1 %2229, i32 %2214, i32 %2247
  %2249 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2250 = insertelement <8 x i32> %2249, i32 %2248, i32 %2236
  store <8 x i32> %2250, ptr %frame.parent.token, align 32
  %2251 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2236
  %2252 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2236
  %2253 = load <8 x i1>, ptr %2251, align 1
  %2254 = load <8 x i1>, ptr %2252, align 1
  %2255 = select i1 %2229, <8 x i1> %251, <8 x i1> %2253
  store <8 x i1> %2255, ptr %2251, align 1
  %2256 = select i1 %2229, <8 x i1> zeroinitializer, <8 x i1> %2254
  store <8 x i1> %2256, ptr %2252, align 1
  %2257 = add i32 %2236, 1
  %2258 = select i1 %2227, i32 %2214, i32 %2257
  %2259 = select i1 true, i32 %2258, i32 %2214
  store i32 %2259, ptr %current.token, align 4
  %2260 = load i32, ptr %current.token, align 4
  %2261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %258)
  %2262 = load i32, ptr %ready.count, align 4
  %2263 = icmp uge i32 %2262, 8
  %2264 = and i1 %2261, %2263
  br i1 %2264, label %ready.overflow.trap339, label %ready.overflow.resume340

ready.overflow.trap339:                           ; preds = %convergence.overflow.resume338
  call void @llvm.trap()
  unreachable

ready.overflow.resume340:                         ; preds = %convergence.overflow.resume338
  %2265 = select i1 %2261, i32 %2262, i32 0
  %2266 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2265
  %2267 = load <8 x i1>, ptr %2266, align 1
  %2268 = select i1 %2261, <8 x i1> %258, <8 x i1> %2267
  store <8 x i1> %2268, ptr %2266, align 1
  %2269 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2265
  %2270 = load i32, ptr %2269, align 4
  %2271 = select i1 %2261, i32 12, i32 %2270
  store i32 %2271, ptr %2269, align 4
  %2272 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2265
  %2273 = load i32, ptr %2272, align 4
  %2274 = select i1 %2261, i32 %2260, i32 %2273
  store i32 %2274, ptr %2272, align 4
  %2275 = add i32 %2262, 1
  %2276 = select i1 %2261, i32 %2275, i32 %2262
  store i32 %2276, ptr %ready.count, align 4
  %2277 = load <8 x i1>, ptr %runnable.mask, align 1
  %2278 = or <8 x i1> %2277, %258
  store <8 x i1> %2278, ptr %runnable.mask, align 1
  store <8 x i1> %260, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true341:                         ; preds = %varying.coherent336
  store <8 x i1> %251, ptr %current.mask, align 1
  %2279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %251)
  br i1 %2279, label %schedule.12, label %scheduler.loop

varying.coherent.false342:                        ; preds = %varying.coherent336
  store <8 x i1> %251, ptr %current.mask, align 1
  %2280 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %251)
  br i1 %2280, label %schedule.103, label %scheduler.loop

varying.divergent366:                             ; preds = %schedule.12
  %2281 = load i32, ptr %current.token, align 4
  %2282 = icmp ne i32 %2281, 0
  %2283 = sub i32 %2281, 1
  %2284 = select i1 %2282, i32 %2283, i32 0
  %2285 = load i8, ptr %frame.active, align 1
  %2286 = trunc i32 %2284 to i8
  %2287 = shl i8 1, %2286
  %2288 = and i8 %2285, %2287
  %2289 = icmp ne i8 %2288, 0
  %2290 = load <8 x i32>, ptr %frame.static.id, align 32
  %2291 = extractelement <8 x i32> %2290, i32 %2284
  %2292 = icmp eq i32 %2291, 6
  %2293 = and i1 %2289, %2292
  %2294 = and i1 %2282, %2293
  %2295 = xor i1 %2294, true
  %2296 = and i1 true, %2295
  %2297 = xor i8 %2285, -1
  %2298 = icmp ne i8 %2297, 0
  %2299 = xor i1 %2298, true
  %2300 = and i1 %2296, %2299
  br i1 %2300, label %convergence.overflow.trap368, label %convergence.overflow.resume369

varying.coherent367:                              ; preds = %schedule.12
  br i1 %347, label %varying.coherent.true372, label %varying.coherent.false373

convergence.overflow.trap368:                     ; preds = %varying.divergent366
  call void @llvm.trap()
  unreachable

convergence.overflow.resume369:                   ; preds = %varying.divergent366
  %2301 = call i8 @llvm.cttz.i8(i8 %2297, i1 false)
  %2302 = zext i8 %2301 to i32
  %2303 = select i1 %2298, i32 %2302, i32 0
  %2304 = trunc i32 %2303 to i8
  %2305 = shl i8 1, %2304
  %2306 = or i8 %2285, %2305
  %2307 = select i1 %2296, i8 %2306, i8 %2285
  store i8 %2307, ptr %frame.active, align 1
  %2308 = load <8 x i32>, ptr %frame.static.id, align 32
  %2309 = extractelement <8 x i32> %2308, i32 %2303
  %2310 = select i1 %2296, i32 6, i32 %2309
  %2311 = load <8 x i32>, ptr %frame.static.id, align 32
  %2312 = insertelement <8 x i32> %2311, i32 %2310, i32 %2303
  store <8 x i32> %2312, ptr %frame.static.id, align 32
  %2313 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2314 = extractelement <8 x i32> %2313, i32 %2303
  %2315 = select i1 %2296, i32 %2281, i32 %2314
  %2316 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2317 = insertelement <8 x i32> %2316, i32 %2315, i32 %2303
  store <8 x i32> %2317, ptr %frame.parent.token, align 32
  %2318 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2303
  %2319 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2303
  %2320 = load <8 x i1>, ptr %2318, align 1
  %2321 = load <8 x i1>, ptr %2319, align 1
  %2322 = select i1 %2296, <8 x i1> %264, <8 x i1> %2320
  store <8 x i1> %2322, ptr %2318, align 1
  %2323 = select i1 %2296, <8 x i1> zeroinitializer, <8 x i1> %2321
  store <8 x i1> %2323, ptr %2319, align 1
  %2324 = add i32 %2303, 1
  %2325 = select i1 %2294, i32 %2281, i32 %2324
  %2326 = select i1 true, i32 %2325, i32 %2281
  store i32 %2326, ptr %current.token, align 4
  %2327 = load <8 x float>, ptr %.slot65, align 32
  %2328 = select <8 x i1> %346, <8 x float> zeroinitializer, <8 x float> %2327
  store <8 x float> %2328, ptr %.slot65, align 32
  %2329 = load i32, ptr %current.token, align 4
  %2330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %344)
  %2331 = load i32, ptr %ready.count, align 4
  %2332 = icmp uge i32 %2331, 8
  %2333 = and i1 %2330, %2332
  br i1 %2333, label %ready.overflow.trap370, label %ready.overflow.resume371

ready.overflow.trap370:                           ; preds = %convergence.overflow.resume369
  call void @llvm.trap()
  unreachable

ready.overflow.resume371:                         ; preds = %convergence.overflow.resume369
  %2334 = select i1 %2330, i32 %2331, i32 0
  %2335 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2334
  %2336 = load <8 x i1>, ptr %2335, align 1
  %2337 = select i1 %2330, <8 x i1> %344, <8 x i1> %2336
  store <8 x i1> %2337, ptr %2335, align 1
  %2338 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2334
  %2339 = load i32, ptr %2338, align 4
  %2340 = select i1 %2330, i32 13, i32 %2339
  store i32 %2340, ptr %2338, align 4
  %2341 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2334
  %2342 = load i32, ptr %2341, align 4
  %2343 = select i1 %2330, i32 %2329, i32 %2342
  store i32 %2343, ptr %2341, align 4
  %2344 = add i32 %2331, 1
  %2345 = select i1 %2330, i32 %2344, i32 %2331
  store i32 %2345, ptr %ready.count, align 4
  %2346 = load <8 x i1>, ptr %runnable.mask, align 1
  %2347 = or <8 x i1> %2346, %344
  store <8 x i1> %2347, ptr %runnable.mask, align 1
  store <8 x i1> %346, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true372:                         ; preds = %varying.coherent367
  store <8 x i1> %264, ptr %current.mask, align 1
  %2348 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %264)
  br i1 %2348, label %schedule.13, label %scheduler.loop

varying.coherent.false373:                        ; preds = %varying.coherent367
  %2349 = load <8 x float>, ptr %.slot65, align 32
  %2350 = select <8 x i1> %264, <8 x float> zeroinitializer, <8 x float> %2349
  store <8 x float> %2350, ptr %.slot65, align 32
  store <8 x i1> %264, ptr %current.mask, align 1
  %2351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %264)
  br i1 %2351, label %schedule.14, label %scheduler.loop

convergence.cascade375:                           ; preds = %convergence.cascade375, %schedule.14
  %convergence.cascade.flow379 = phi <8 x i1> [ %363, %schedule.14 ], [ %2394, %convergence.cascade375 ]
  %convergence.cascade.depth380 = phi i32 [ 0, %schedule.14 ], [ %2395, %convergence.cascade375 ]
  %2352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow379)
  %2353 = load i32, ptr %current.token, align 4
  %2354 = icmp ne i32 %2353, 0
  %2355 = and i1 %2352, %2354
  %2356 = sub i32 %2353, 1
  %2357 = select i1 %2355, i32 %2356, i32 0
  %2358 = load i8, ptr %frame.active, align 1
  %2359 = trunc i32 %2357 to i8
  %2360 = shl i8 1, %2359
  %2361 = and i8 %2358, %2360
  %2362 = icmp ne i8 %2361, 0
  %2363 = load <8 x i32>, ptr %frame.static.id, align 32
  %2364 = extractelement <8 x i32> %2363, i32 %2357
  %convergence.target.pointer381 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %2364
  %convergence.dynamic.target382 = load i32, ptr %convergence.target.pointer381, align 4
  %2365 = icmp eq i32 %convergence.dynamic.target382, 14
  %2366 = and i1 %2362, %2365
  %2367 = and i1 %2355, %2366
  %2368 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2357
  %2369 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2357
  %2370 = load <8 x i1>, ptr %2368, align 1
  %2371 = load <8 x i1>, ptr %2369, align 1
  %2372 = or <8 x i1> %2371, %convergence.cascade.flow379
  %2373 = load <8 x i1>, ptr %live.mask, align 1
  %2374 = and <8 x i1> %2370, %2373
  %2375 = icmp eq <8 x i1> %2372, %2374
  %2376 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2375)
  %2377 = and i1 %2367, %2376
  %2378 = select i1 %2377, <8 x i1> zeroinitializer, <8 x i1> %2372
  %2379 = select i1 %2367, <8 x i1> %2378, <8 x i1> %2371
  store <8 x i1> %2379, ptr %2369, align 1
  %2380 = select i1 %2377, <8 x i1> zeroinitializer, <8 x i1> %2370
  store <8 x i1> %2380, ptr %2368, align 1
  %2381 = trunc i32 %2357 to i8
  %2382 = shl i8 1, %2381
  %2383 = xor i8 %2382, -1
  %2384 = and i8 %2358, %2383
  %2385 = select i1 %2377, i8 %2384, i8 %2358
  store i8 %2385, ptr %frame.active, align 1
  %.splatinsert383 = insertelement <8 x i1> poison, i1 %2367, i64 0
  %.splat384 = shufflevector <8 x i1> %.splatinsert383, <8 x i1> poison, <8 x i32> zeroinitializer
  %2386 = and <8 x i1> %convergence.cascade.flow379, %.splat384
  %2387 = load <8 x i1>, ptr %runnable.mask, align 1
  %2388 = xor <8 x i1> %2386, splat (i1 true)
  %2389 = and <8 x i1> %2387, %2388
  store <8 x i1> %2389, ptr %runnable.mask, align 1
  %.splatinsert385 = insertelement <8 x i1> poison, i1 %2377, i64 0
  %.splat386 = shufflevector <8 x i1> %.splatinsert385, <8 x i1> poison, <8 x i32> zeroinitializer
  %2390 = select <8 x i1> %.splat386, <8 x i1> %2372, <8 x i1> zeroinitializer
  %2391 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2392 = extractelement <8 x i32> %2391, i32 %2357
  %2393 = select i1 %2377, i32 %2392, i32 %2353
  store i32 %2393, ptr %current.token, align 4
  %.splatinsert387 = insertelement <8 x i1> poison, i1 %2367, i64 0
  %.splat388 = shufflevector <8 x i1> %.splatinsert387, <8 x i1> poison, <8 x i32> zeroinitializer
  %2394 = select <8 x i1> %.splat388, <8 x i1> %2390, <8 x i1> %convergence.cascade.flow379
  %2395 = add i32 %convergence.cascade.depth380, 1
  %2396 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2394)
  %2397 = icmp ult i32 %2395, 8
  %2398 = and i1 %2396, %2397
  %2399 = and i1 %2367, %2398
  %convergence.parent.token389 = load i32, ptr %current.token, align 4
  %convergence.parent.present390 = icmp ne i32 %convergence.parent.token389, 0
  %2400 = and i1 %2399, %convergence.parent.present390
  br i1 %2400, label %convergence.cascade375, label %convergence.cascade.exit376

convergence.cascade.exit376:                      ; preds = %convergence.cascade375, %schedule.14
  %convergence.cascade.result391 = phi <8 x i1> [ %363, %schedule.14 ], [ %2394, %convergence.cascade375 ]
  %2401 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result391)
  br i1 %2401, label %convergence.target.14.ready, label %scheduler.loop

convergence.target.14.ready:                      ; preds = %convergence.cascade.exit376
  %2402 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result391)
  %2403 = bitcast <8 x i1> %convergence.cascade.result391 to i8
  %2404 = call i8 @llvm.cttz.i8(i8 %2403, i1 false)
  %2405 = zext i8 %2404 to i32
  %2406 = select i1 %2402, i32 %2405, i32 0
  %.spill.load392 = load <8 x i64>, ptr %.spill63, align 64
  %.spill.load393 = load i64, ptr %.spill16, align 4
  %.splatinsert394 = insertelement <8 x i64> poison, i64 %.spill.load393, i64 0
  %.splat395 = shufflevector <8 x i64> %.splatinsert394, <8 x i64> poison, <8 x i32> zeroinitializer
  %2407 = add <8 x i64> %.spill.load392, %.splat395
  %2408 = load volatile <8 x i64>, ptr %.spill66, align 64
  %2409 = select <8 x i1> %convergence.cascade.result391, <8 x i64> %2407, <8 x i64> %2408
  store volatile <8 x i64> %2409, ptr %.spill66, align 64
  %.spill.load396 = load <8 x i1>, ptr %.spill62, align 1
  %2410 = and <8 x i1> %convergence.cascade.result391, %.spill.load396
  %2411 = xor <8 x i1> %.spill.load396, splat (i1 true)
  %2412 = and <8 x i1> %convergence.cascade.result391, %2411
  %2413 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2410)
  %2414 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2412)
  %2415 = and i1 %2413, %2414
  br i1 %2415, label %varying.divergent397, label %varying.coherent398

varying.divergent397:                             ; preds = %convergence.target.14.ready
  %2416 = load i32, ptr %current.token, align 4
  %2417 = icmp ne i32 %2416, 0
  %2418 = sub i32 %2416, 1
  %2419 = select i1 %2417, i32 %2418, i32 0
  %2420 = load i8, ptr %frame.active, align 1
  %2421 = trunc i32 %2419 to i8
  %2422 = shl i8 1, %2421
  %2423 = and i8 %2420, %2422
  %2424 = icmp ne i8 %2423, 0
  %2425 = load <8 x i32>, ptr %frame.static.id, align 32
  %2426 = extractelement <8 x i32> %2425, i32 %2419
  %2427 = icmp eq i32 %2426, 7
  %2428 = and i1 %2424, %2427
  %2429 = and i1 %2417, %2428
  %2430 = xor i1 %2429, true
  %2431 = and i1 true, %2430
  %2432 = xor i8 %2420, -1
  %2433 = icmp ne i8 %2432, 0
  %2434 = xor i1 %2433, true
  %2435 = and i1 %2431, %2434
  br i1 %2435, label %convergence.overflow.trap399, label %convergence.overflow.resume400

varying.coherent398:                              ; preds = %convergence.target.14.ready
  br i1 %2413, label %varying.coherent.true403, label %varying.coherent.false404

convergence.overflow.trap399:                     ; preds = %varying.divergent397
  call void @llvm.trap()
  unreachable

convergence.overflow.resume400:                   ; preds = %varying.divergent397
  %2436 = call i8 @llvm.cttz.i8(i8 %2432, i1 false)
  %2437 = zext i8 %2436 to i32
  %2438 = select i1 %2433, i32 %2437, i32 0
  %2439 = trunc i32 %2438 to i8
  %2440 = shl i8 1, %2439
  %2441 = or i8 %2420, %2440
  %2442 = select i1 %2431, i8 %2441, i8 %2420
  store i8 %2442, ptr %frame.active, align 1
  %2443 = load <8 x i32>, ptr %frame.static.id, align 32
  %2444 = extractelement <8 x i32> %2443, i32 %2438
  %2445 = select i1 %2431, i32 7, i32 %2444
  %2446 = load <8 x i32>, ptr %frame.static.id, align 32
  %2447 = insertelement <8 x i32> %2446, i32 %2445, i32 %2438
  store <8 x i32> %2447, ptr %frame.static.id, align 32
  %2448 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2449 = extractelement <8 x i32> %2448, i32 %2438
  %2450 = select i1 %2431, i32 %2416, i32 %2449
  %2451 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2452 = insertelement <8 x i32> %2451, i32 %2450, i32 %2438
  store <8 x i32> %2452, ptr %frame.parent.token, align 32
  %2453 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2438
  %2454 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2438
  %2455 = load <8 x i1>, ptr %2453, align 1
  %2456 = load <8 x i1>, ptr %2454, align 1
  %2457 = select i1 %2431, <8 x i1> %convergence.cascade.result391, <8 x i1> %2455
  store <8 x i1> %2457, ptr %2453, align 1
  %2458 = select i1 %2431, <8 x i1> zeroinitializer, <8 x i1> %2456
  store <8 x i1> %2458, ptr %2454, align 1
  %2459 = add i32 %2438, 1
  %2460 = select i1 %2429, i32 %2416, i32 %2459
  %2461 = select i1 true, i32 %2460, i32 %2416
  store i32 %2461, ptr %current.token, align 4
  %2462 = load <8 x float>, ptr %.slot67, align 32
  %2463 = select <8 x i1> %2412, <8 x float> zeroinitializer, <8 x float> %2462
  store <8 x float> %2463, ptr %.slot67, align 32
  %2464 = load i32, ptr %current.token, align 4
  %2465 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2410)
  %2466 = load i32, ptr %ready.count, align 4
  %2467 = icmp uge i32 %2466, 8
  %2468 = and i1 %2465, %2467
  br i1 %2468, label %ready.overflow.trap401, label %ready.overflow.resume402

ready.overflow.trap401:                           ; preds = %convergence.overflow.resume400
  call void @llvm.trap()
  unreachable

ready.overflow.resume402:                         ; preds = %convergence.overflow.resume400
  %2469 = select i1 %2465, i32 %2466, i32 0
  %2470 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2469
  %2471 = load <8 x i1>, ptr %2470, align 1
  %2472 = select i1 %2465, <8 x i1> %2410, <8 x i1> %2471
  store <8 x i1> %2472, ptr %2470, align 1
  %2473 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2469
  %2474 = load i32, ptr %2473, align 4
  %2475 = select i1 %2465, i32 15, i32 %2474
  store i32 %2475, ptr %2473, align 4
  %2476 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2469
  %2477 = load i32, ptr %2476, align 4
  %2478 = select i1 %2465, i32 %2464, i32 %2477
  store i32 %2478, ptr %2476, align 4
  %2479 = add i32 %2466, 1
  %2480 = select i1 %2465, i32 %2479, i32 %2466
  store i32 %2480, ptr %ready.count, align 4
  %2481 = load <8 x i1>, ptr %runnable.mask, align 1
  %2482 = or <8 x i1> %2481, %2410
  store <8 x i1> %2482, ptr %runnable.mask, align 1
  store <8 x i1> %2412, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true403:                         ; preds = %varying.coherent398
  store <8 x i1> %convergence.cascade.result391, ptr %current.mask, align 1
  %2483 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result391)
  br i1 %2483, label %schedule.15, label %scheduler.loop

varying.coherent.false404:                        ; preds = %varying.coherent398
  %2484 = load <8 x float>, ptr %.slot67, align 32
  %2485 = select <8 x i1> %convergence.cascade.result391, <8 x float> zeroinitializer, <8 x float> %2484
  store <8 x float> %2485, ptr %.slot67, align 32
  store <8 x i1> %convergence.cascade.result391, ptr %current.mask, align 1
  %2486 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result391)
  br i1 %2486, label %schedule.16, label %scheduler.loop

convergence.cascade406:                           ; preds = %convergence.cascade406, %schedule.16
  %convergence.cascade.flow410 = phi <8 x i1> [ %377, %schedule.16 ], [ %2529, %convergence.cascade406 ]
  %convergence.cascade.depth411 = phi i32 [ 0, %schedule.16 ], [ %2530, %convergence.cascade406 ]
  %2487 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow410)
  %2488 = load i32, ptr %current.token, align 4
  %2489 = icmp ne i32 %2488, 0
  %2490 = and i1 %2487, %2489
  %2491 = sub i32 %2488, 1
  %2492 = select i1 %2490, i32 %2491, i32 0
  %2493 = load i8, ptr %frame.active, align 1
  %2494 = trunc i32 %2492 to i8
  %2495 = shl i8 1, %2494
  %2496 = and i8 %2493, %2495
  %2497 = icmp ne i8 %2496, 0
  %2498 = load <8 x i32>, ptr %frame.static.id, align 32
  %2499 = extractelement <8 x i32> %2498, i32 %2492
  %convergence.target.pointer412 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %2499
  %convergence.dynamic.target413 = load i32, ptr %convergence.target.pointer412, align 4
  %2500 = icmp eq i32 %convergence.dynamic.target413, 16
  %2501 = and i1 %2497, %2500
  %2502 = and i1 %2490, %2501
  %2503 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2492
  %2504 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2492
  %2505 = load <8 x i1>, ptr %2503, align 1
  %2506 = load <8 x i1>, ptr %2504, align 1
  %2507 = or <8 x i1> %2506, %convergence.cascade.flow410
  %2508 = load <8 x i1>, ptr %live.mask, align 1
  %2509 = and <8 x i1> %2505, %2508
  %2510 = icmp eq <8 x i1> %2507, %2509
  %2511 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2510)
  %2512 = and i1 %2502, %2511
  %2513 = select i1 %2512, <8 x i1> zeroinitializer, <8 x i1> %2507
  %2514 = select i1 %2502, <8 x i1> %2513, <8 x i1> %2506
  store <8 x i1> %2514, ptr %2504, align 1
  %2515 = select i1 %2512, <8 x i1> zeroinitializer, <8 x i1> %2505
  store <8 x i1> %2515, ptr %2503, align 1
  %2516 = trunc i32 %2492 to i8
  %2517 = shl i8 1, %2516
  %2518 = xor i8 %2517, -1
  %2519 = and i8 %2493, %2518
  %2520 = select i1 %2512, i8 %2519, i8 %2493
  store i8 %2520, ptr %frame.active, align 1
  %.splatinsert414 = insertelement <8 x i1> poison, i1 %2502, i64 0
  %.splat415 = shufflevector <8 x i1> %.splatinsert414, <8 x i1> poison, <8 x i32> zeroinitializer
  %2521 = and <8 x i1> %convergence.cascade.flow410, %.splat415
  %2522 = load <8 x i1>, ptr %runnable.mask, align 1
  %2523 = xor <8 x i1> %2521, splat (i1 true)
  %2524 = and <8 x i1> %2522, %2523
  store <8 x i1> %2524, ptr %runnable.mask, align 1
  %.splatinsert416 = insertelement <8 x i1> poison, i1 %2512, i64 0
  %.splat417 = shufflevector <8 x i1> %.splatinsert416, <8 x i1> poison, <8 x i32> zeroinitializer
  %2525 = select <8 x i1> %.splat417, <8 x i1> %2507, <8 x i1> zeroinitializer
  %2526 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2527 = extractelement <8 x i32> %2526, i32 %2492
  %2528 = select i1 %2512, i32 %2527, i32 %2488
  store i32 %2528, ptr %current.token, align 4
  %.splatinsert418 = insertelement <8 x i1> poison, i1 %2502, i64 0
  %.splat419 = shufflevector <8 x i1> %.splatinsert418, <8 x i1> poison, <8 x i32> zeroinitializer
  %2529 = select <8 x i1> %.splat419, <8 x i1> %2525, <8 x i1> %convergence.cascade.flow410
  %2530 = add i32 %convergence.cascade.depth411, 1
  %2531 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2529)
  %2532 = icmp ult i32 %2530, 8
  %2533 = and i1 %2531, %2532
  %2534 = and i1 %2502, %2533
  %convergence.parent.token420 = load i32, ptr %current.token, align 4
  %convergence.parent.present421 = icmp ne i32 %convergence.parent.token420, 0
  %2535 = and i1 %2534, %convergence.parent.present421
  br i1 %2535, label %convergence.cascade406, label %convergence.cascade.exit407

convergence.cascade.exit407:                      ; preds = %convergence.cascade406, %schedule.16
  %convergence.cascade.result422 = phi <8 x i1> [ %377, %schedule.16 ], [ %2529, %convergence.cascade406 ]
  %2536 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result422)
  br i1 %2536, label %convergence.target.16.ready, label %scheduler.loop

convergence.target.16.ready:                      ; preds = %convergence.cascade.exit407
  %2537 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result422)
  %2538 = bitcast <8 x i1> %convergence.cascade.result422 to i8
  %2539 = call i8 @llvm.cttz.i8(i8 %2538, i1 false)
  %2540 = zext i8 %2539 to i32
  %2541 = select i1 %2537, i32 %2540, i32 0
  %.spill.load423 = load <8 x i64>, ptr %.spill63, align 64
  %.spill.load424 = load i64, ptr %.spill18, align 4
  %.splatinsert425 = insertelement <8 x i64> poison, i64 %.spill.load424, i64 0
  %.splat426 = shufflevector <8 x i64> %.splatinsert425, <8 x i64> poison, <8 x i32> zeroinitializer
  %2542 = add <8 x i64> %.spill.load423, %.splat426
  %2543 = load volatile <8 x i64>, ptr %.spill68, align 64
  %2544 = select <8 x i1> %convergence.cascade.result422, <8 x i64> %2542, <8 x i64> %2543
  store volatile <8 x i64> %2544, ptr %.spill68, align 64
  %.spill.load427 = load <8 x i1>, ptr %.spill62, align 1
  %2545 = and <8 x i1> %convergence.cascade.result422, %.spill.load427
  %2546 = xor <8 x i1> %.spill.load427, splat (i1 true)
  %2547 = and <8 x i1> %convergence.cascade.result422, %2546
  %2548 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2545)
  %2549 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2547)
  %2550 = and i1 %2548, %2549
  br i1 %2550, label %varying.divergent428, label %varying.coherent429

varying.divergent428:                             ; preds = %convergence.target.16.ready
  %2551 = load i32, ptr %current.token, align 4
  %2552 = icmp ne i32 %2551, 0
  %2553 = sub i32 %2551, 1
  %2554 = select i1 %2552, i32 %2553, i32 0
  %2555 = load i8, ptr %frame.active, align 1
  %2556 = trunc i32 %2554 to i8
  %2557 = shl i8 1, %2556
  %2558 = and i8 %2555, %2557
  %2559 = icmp ne i8 %2558, 0
  %2560 = load <8 x i32>, ptr %frame.static.id, align 32
  %2561 = extractelement <8 x i32> %2560, i32 %2554
  %2562 = icmp eq i32 %2561, 8
  %2563 = and i1 %2559, %2562
  %2564 = and i1 %2552, %2563
  %2565 = xor i1 %2564, true
  %2566 = and i1 true, %2565
  %2567 = xor i8 %2555, -1
  %2568 = icmp ne i8 %2567, 0
  %2569 = xor i1 %2568, true
  %2570 = and i1 %2566, %2569
  br i1 %2570, label %convergence.overflow.trap430, label %convergence.overflow.resume431

varying.coherent429:                              ; preds = %convergence.target.16.ready
  br i1 %2548, label %varying.coherent.true434, label %varying.coherent.false435

convergence.overflow.trap430:                     ; preds = %varying.divergent428
  call void @llvm.trap()
  unreachable

convergence.overflow.resume431:                   ; preds = %varying.divergent428
  %2571 = call i8 @llvm.cttz.i8(i8 %2567, i1 false)
  %2572 = zext i8 %2571 to i32
  %2573 = select i1 %2568, i32 %2572, i32 0
  %2574 = trunc i32 %2573 to i8
  %2575 = shl i8 1, %2574
  %2576 = or i8 %2555, %2575
  %2577 = select i1 %2566, i8 %2576, i8 %2555
  store i8 %2577, ptr %frame.active, align 1
  %2578 = load <8 x i32>, ptr %frame.static.id, align 32
  %2579 = extractelement <8 x i32> %2578, i32 %2573
  %2580 = select i1 %2566, i32 8, i32 %2579
  %2581 = load <8 x i32>, ptr %frame.static.id, align 32
  %2582 = insertelement <8 x i32> %2581, i32 %2580, i32 %2573
  store <8 x i32> %2582, ptr %frame.static.id, align 32
  %2583 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2584 = extractelement <8 x i32> %2583, i32 %2573
  %2585 = select i1 %2566, i32 %2551, i32 %2584
  %2586 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2587 = insertelement <8 x i32> %2586, i32 %2585, i32 %2573
  store <8 x i32> %2587, ptr %frame.parent.token, align 32
  %2588 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2573
  %2589 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2573
  %2590 = load <8 x i1>, ptr %2588, align 1
  %2591 = load <8 x i1>, ptr %2589, align 1
  %2592 = select i1 %2566, <8 x i1> %convergence.cascade.result422, <8 x i1> %2590
  store <8 x i1> %2592, ptr %2588, align 1
  %2593 = select i1 %2566, <8 x i1> zeroinitializer, <8 x i1> %2591
  store <8 x i1> %2593, ptr %2589, align 1
  %2594 = add i32 %2573, 1
  %2595 = select i1 %2564, i32 %2551, i32 %2594
  %2596 = select i1 true, i32 %2595, i32 %2551
  store i32 %2596, ptr %current.token, align 4
  %2597 = load <8 x float>, ptr %.slot69, align 32
  %2598 = select <8 x i1> %2547, <8 x float> zeroinitializer, <8 x float> %2597
  store <8 x float> %2598, ptr %.slot69, align 32
  %2599 = load i32, ptr %current.token, align 4
  %2600 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2545)
  %2601 = load i32, ptr %ready.count, align 4
  %2602 = icmp uge i32 %2601, 8
  %2603 = and i1 %2600, %2602
  br i1 %2603, label %ready.overflow.trap432, label %ready.overflow.resume433

ready.overflow.trap432:                           ; preds = %convergence.overflow.resume431
  call void @llvm.trap()
  unreachable

ready.overflow.resume433:                         ; preds = %convergence.overflow.resume431
  %2604 = select i1 %2600, i32 %2601, i32 0
  %2605 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2604
  %2606 = load <8 x i1>, ptr %2605, align 1
  %2607 = select i1 %2600, <8 x i1> %2545, <8 x i1> %2606
  store <8 x i1> %2607, ptr %2605, align 1
  %2608 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2604
  %2609 = load i32, ptr %2608, align 4
  %2610 = select i1 %2600, i32 17, i32 %2609
  store i32 %2610, ptr %2608, align 4
  %2611 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2604
  %2612 = load i32, ptr %2611, align 4
  %2613 = select i1 %2600, i32 %2599, i32 %2612
  store i32 %2613, ptr %2611, align 4
  %2614 = add i32 %2601, 1
  %2615 = select i1 %2600, i32 %2614, i32 %2601
  store i32 %2615, ptr %ready.count, align 4
  %2616 = load <8 x i1>, ptr %runnable.mask, align 1
  %2617 = or <8 x i1> %2616, %2545
  store <8 x i1> %2617, ptr %runnable.mask, align 1
  store <8 x i1> %2547, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true434:                         ; preds = %varying.coherent429
  store <8 x i1> %convergence.cascade.result422, ptr %current.mask, align 1
  %2618 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result422)
  br i1 %2618, label %schedule.17, label %scheduler.loop

varying.coherent.false435:                        ; preds = %varying.coherent429
  %2619 = load <8 x float>, ptr %.slot69, align 32
  %2620 = select <8 x i1> %convergence.cascade.result422, <8 x float> zeroinitializer, <8 x float> %2619
  store <8 x float> %2620, ptr %.slot69, align 32
  store <8 x i1> %convergence.cascade.result422, ptr %current.mask, align 1
  %2621 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result422)
  br i1 %2621, label %schedule.18, label %scheduler.loop

convergence.cascade437:                           ; preds = %convergence.cascade437, %schedule.18
  %convergence.cascade.flow441 = phi <8 x i1> [ %391, %schedule.18 ], [ %2664, %convergence.cascade437 ]
  %convergence.cascade.depth442 = phi i32 [ 0, %schedule.18 ], [ %2665, %convergence.cascade437 ]
  %2622 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow441)
  %2623 = load i32, ptr %current.token, align 4
  %2624 = icmp ne i32 %2623, 0
  %2625 = and i1 %2622, %2624
  %2626 = sub i32 %2623, 1
  %2627 = select i1 %2625, i32 %2626, i32 0
  %2628 = load i8, ptr %frame.active, align 1
  %2629 = trunc i32 %2627 to i8
  %2630 = shl i8 1, %2629
  %2631 = and i8 %2628, %2630
  %2632 = icmp ne i8 %2631, 0
  %2633 = load <8 x i32>, ptr %frame.static.id, align 32
  %2634 = extractelement <8 x i32> %2633, i32 %2627
  %convergence.target.pointer443 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %2634
  %convergence.dynamic.target444 = load i32, ptr %convergence.target.pointer443, align 4
  %2635 = icmp eq i32 %convergence.dynamic.target444, 18
  %2636 = and i1 %2632, %2635
  %2637 = and i1 %2625, %2636
  %2638 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2627
  %2639 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2627
  %2640 = load <8 x i1>, ptr %2638, align 1
  %2641 = load <8 x i1>, ptr %2639, align 1
  %2642 = or <8 x i1> %2641, %convergence.cascade.flow441
  %2643 = load <8 x i1>, ptr %live.mask, align 1
  %2644 = and <8 x i1> %2640, %2643
  %2645 = icmp eq <8 x i1> %2642, %2644
  %2646 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2645)
  %2647 = and i1 %2637, %2646
  %2648 = select i1 %2647, <8 x i1> zeroinitializer, <8 x i1> %2642
  %2649 = select i1 %2637, <8 x i1> %2648, <8 x i1> %2641
  store <8 x i1> %2649, ptr %2639, align 1
  %2650 = select i1 %2647, <8 x i1> zeroinitializer, <8 x i1> %2640
  store <8 x i1> %2650, ptr %2638, align 1
  %2651 = trunc i32 %2627 to i8
  %2652 = shl i8 1, %2651
  %2653 = xor i8 %2652, -1
  %2654 = and i8 %2628, %2653
  %2655 = select i1 %2647, i8 %2654, i8 %2628
  store i8 %2655, ptr %frame.active, align 1
  %.splatinsert445 = insertelement <8 x i1> poison, i1 %2637, i64 0
  %.splat446 = shufflevector <8 x i1> %.splatinsert445, <8 x i1> poison, <8 x i32> zeroinitializer
  %2656 = and <8 x i1> %convergence.cascade.flow441, %.splat446
  %2657 = load <8 x i1>, ptr %runnable.mask, align 1
  %2658 = xor <8 x i1> %2656, splat (i1 true)
  %2659 = and <8 x i1> %2657, %2658
  store <8 x i1> %2659, ptr %runnable.mask, align 1
  %.splatinsert447 = insertelement <8 x i1> poison, i1 %2647, i64 0
  %.splat448 = shufflevector <8 x i1> %.splatinsert447, <8 x i1> poison, <8 x i32> zeroinitializer
  %2660 = select <8 x i1> %.splat448, <8 x i1> %2642, <8 x i1> zeroinitializer
  %2661 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2662 = extractelement <8 x i32> %2661, i32 %2627
  %2663 = select i1 %2647, i32 %2662, i32 %2623
  store i32 %2663, ptr %current.token, align 4
  %.splatinsert449 = insertelement <8 x i1> poison, i1 %2637, i64 0
  %.splat450 = shufflevector <8 x i1> %.splatinsert449, <8 x i1> poison, <8 x i32> zeroinitializer
  %2664 = select <8 x i1> %.splat450, <8 x i1> %2660, <8 x i1> %convergence.cascade.flow441
  %2665 = add i32 %convergence.cascade.depth442, 1
  %2666 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2664)
  %2667 = icmp ult i32 %2665, 8
  %2668 = and i1 %2666, %2667
  %2669 = and i1 %2637, %2668
  %convergence.parent.token451 = load i32, ptr %current.token, align 4
  %convergence.parent.present452 = icmp ne i32 %convergence.parent.token451, 0
  %2670 = and i1 %2669, %convergence.parent.present452
  br i1 %2670, label %convergence.cascade437, label %convergence.cascade.exit438

convergence.cascade.exit438:                      ; preds = %convergence.cascade437, %schedule.18
  %convergence.cascade.result453 = phi <8 x i1> [ %391, %schedule.18 ], [ %2664, %convergence.cascade437 ]
  %2671 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result453)
  br i1 %2671, label %convergence.target.18.ready, label %scheduler.loop

convergence.target.18.ready:                      ; preds = %convergence.cascade.exit438
  %2672 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result453)
  %2673 = bitcast <8 x i1> %convergence.cascade.result453 to i8
  %2674 = call i8 @llvm.cttz.i8(i8 %2673, i1 false)
  %2675 = zext i8 %2674 to i32
  %2676 = select i1 %2672, i32 %2675, i32 0
  %.spill.load454 = load <8 x i64>, ptr %.spill63, align 64
  %.spill.load455 = load i64, ptr %.spill20, align 4
  %.splatinsert456 = insertelement <8 x i64> poison, i64 %.spill.load455, i64 0
  %.splat457 = shufflevector <8 x i64> %.splatinsert456, <8 x i64> poison, <8 x i32> zeroinitializer
  %2677 = add <8 x i64> %.spill.load454, %.splat457
  %2678 = load volatile <8 x i64>, ptr %.spill70, align 64
  %2679 = select <8 x i1> %convergence.cascade.result453, <8 x i64> %2677, <8 x i64> %2678
  store volatile <8 x i64> %2679, ptr %.spill70, align 64
  %.spill.load458 = load <8 x i1>, ptr %.spill62, align 1
  %2680 = and <8 x i1> %convergence.cascade.result453, %.spill.load458
  %2681 = xor <8 x i1> %.spill.load458, splat (i1 true)
  %2682 = and <8 x i1> %convergence.cascade.result453, %2681
  %2683 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2680)
  %2684 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2682)
  %2685 = and i1 %2683, %2684
  br i1 %2685, label %varying.divergent459, label %varying.coherent460

varying.divergent459:                             ; preds = %convergence.target.18.ready
  %2686 = load i32, ptr %current.token, align 4
  %2687 = icmp ne i32 %2686, 0
  %2688 = sub i32 %2686, 1
  %2689 = select i1 %2687, i32 %2688, i32 0
  %2690 = load i8, ptr %frame.active, align 1
  %2691 = trunc i32 %2689 to i8
  %2692 = shl i8 1, %2691
  %2693 = and i8 %2690, %2692
  %2694 = icmp ne i8 %2693, 0
  %2695 = load <8 x i32>, ptr %frame.static.id, align 32
  %2696 = extractelement <8 x i32> %2695, i32 %2689
  %2697 = icmp eq i32 %2696, 9
  %2698 = and i1 %2694, %2697
  %2699 = and i1 %2687, %2698
  %2700 = xor i1 %2699, true
  %2701 = and i1 true, %2700
  %2702 = xor i8 %2690, -1
  %2703 = icmp ne i8 %2702, 0
  %2704 = xor i1 %2703, true
  %2705 = and i1 %2701, %2704
  br i1 %2705, label %convergence.overflow.trap461, label %convergence.overflow.resume462

varying.coherent460:                              ; preds = %convergence.target.18.ready
  br i1 %2683, label %varying.coherent.true465, label %varying.coherent.false466

convergence.overflow.trap461:                     ; preds = %varying.divergent459
  call void @llvm.trap()
  unreachable

convergence.overflow.resume462:                   ; preds = %varying.divergent459
  %2706 = call i8 @llvm.cttz.i8(i8 %2702, i1 false)
  %2707 = zext i8 %2706 to i32
  %2708 = select i1 %2703, i32 %2707, i32 0
  %2709 = trunc i32 %2708 to i8
  %2710 = shl i8 1, %2709
  %2711 = or i8 %2690, %2710
  %2712 = select i1 %2701, i8 %2711, i8 %2690
  store i8 %2712, ptr %frame.active, align 1
  %2713 = load <8 x i32>, ptr %frame.static.id, align 32
  %2714 = extractelement <8 x i32> %2713, i32 %2708
  %2715 = select i1 %2701, i32 9, i32 %2714
  %2716 = load <8 x i32>, ptr %frame.static.id, align 32
  %2717 = insertelement <8 x i32> %2716, i32 %2715, i32 %2708
  store <8 x i32> %2717, ptr %frame.static.id, align 32
  %2718 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2719 = extractelement <8 x i32> %2718, i32 %2708
  %2720 = select i1 %2701, i32 %2686, i32 %2719
  %2721 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2722 = insertelement <8 x i32> %2721, i32 %2720, i32 %2708
  store <8 x i32> %2722, ptr %frame.parent.token, align 32
  %2723 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2708
  %2724 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2708
  %2725 = load <8 x i1>, ptr %2723, align 1
  %2726 = load <8 x i1>, ptr %2724, align 1
  %2727 = select i1 %2701, <8 x i1> %convergence.cascade.result453, <8 x i1> %2725
  store <8 x i1> %2727, ptr %2723, align 1
  %2728 = select i1 %2701, <8 x i1> zeroinitializer, <8 x i1> %2726
  store <8 x i1> %2728, ptr %2724, align 1
  %2729 = add i32 %2708, 1
  %2730 = select i1 %2699, i32 %2686, i32 %2729
  %2731 = select i1 true, i32 %2730, i32 %2686
  store i32 %2731, ptr %current.token, align 4
  %2732 = load <8 x float>, ptr %.slot71, align 32
  %2733 = select <8 x i1> %2682, <8 x float> zeroinitializer, <8 x float> %2732
  store <8 x float> %2733, ptr %.slot71, align 32
  %2734 = load i32, ptr %current.token, align 4
  %2735 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2680)
  %2736 = load i32, ptr %ready.count, align 4
  %2737 = icmp uge i32 %2736, 8
  %2738 = and i1 %2735, %2737
  br i1 %2738, label %ready.overflow.trap463, label %ready.overflow.resume464

ready.overflow.trap463:                           ; preds = %convergence.overflow.resume462
  call void @llvm.trap()
  unreachable

ready.overflow.resume464:                         ; preds = %convergence.overflow.resume462
  %2739 = select i1 %2735, i32 %2736, i32 0
  %2740 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2739
  %2741 = load <8 x i1>, ptr %2740, align 1
  %2742 = select i1 %2735, <8 x i1> %2680, <8 x i1> %2741
  store <8 x i1> %2742, ptr %2740, align 1
  %2743 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2739
  %2744 = load i32, ptr %2743, align 4
  %2745 = select i1 %2735, i32 19, i32 %2744
  store i32 %2745, ptr %2743, align 4
  %2746 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2739
  %2747 = load i32, ptr %2746, align 4
  %2748 = select i1 %2735, i32 %2734, i32 %2747
  store i32 %2748, ptr %2746, align 4
  %2749 = add i32 %2736, 1
  %2750 = select i1 %2735, i32 %2749, i32 %2736
  store i32 %2750, ptr %ready.count, align 4
  %2751 = load <8 x i1>, ptr %runnable.mask, align 1
  %2752 = or <8 x i1> %2751, %2680
  store <8 x i1> %2752, ptr %runnable.mask, align 1
  store <8 x i1> %2682, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true465:                         ; preds = %varying.coherent460
  store <8 x i1> %convergence.cascade.result453, ptr %current.mask, align 1
  %2753 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result453)
  br i1 %2753, label %schedule.19, label %scheduler.loop

varying.coherent.false466:                        ; preds = %varying.coherent460
  %2754 = load <8 x float>, ptr %.slot71, align 32
  %2755 = select <8 x i1> %convergence.cascade.result453, <8 x float> zeroinitializer, <8 x float> %2754
  store <8 x float> %2755, ptr %.slot71, align 32
  store <8 x i1> %convergence.cascade.result453, ptr %current.mask, align 1
  %2756 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result453)
  br i1 %2756, label %schedule.20, label %scheduler.loop

convergence.cascade468:                           ; preds = %convergence.cascade468, %schedule.20
  %convergence.cascade.flow472 = phi <8 x i1> [ %405, %schedule.20 ], [ %2799, %convergence.cascade468 ]
  %convergence.cascade.depth473 = phi i32 [ 0, %schedule.20 ], [ %2800, %convergence.cascade468 ]
  %2757 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow472)
  %2758 = load i32, ptr %current.token, align 4
  %2759 = icmp ne i32 %2758, 0
  %2760 = and i1 %2757, %2759
  %2761 = sub i32 %2758, 1
  %2762 = select i1 %2760, i32 %2761, i32 0
  %2763 = load i8, ptr %frame.active, align 1
  %2764 = trunc i32 %2762 to i8
  %2765 = shl i8 1, %2764
  %2766 = and i8 %2763, %2765
  %2767 = icmp ne i8 %2766, 0
  %2768 = load <8 x i32>, ptr %frame.static.id, align 32
  %2769 = extractelement <8 x i32> %2768, i32 %2762
  %convergence.target.pointer474 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %2769
  %convergence.dynamic.target475 = load i32, ptr %convergence.target.pointer474, align 4
  %2770 = icmp eq i32 %convergence.dynamic.target475, 20
  %2771 = and i1 %2767, %2770
  %2772 = and i1 %2760, %2771
  %2773 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2762
  %2774 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2762
  %2775 = load <8 x i1>, ptr %2773, align 1
  %2776 = load <8 x i1>, ptr %2774, align 1
  %2777 = or <8 x i1> %2776, %convergence.cascade.flow472
  %2778 = load <8 x i1>, ptr %live.mask, align 1
  %2779 = and <8 x i1> %2775, %2778
  %2780 = icmp eq <8 x i1> %2777, %2779
  %2781 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2780)
  %2782 = and i1 %2772, %2781
  %2783 = select i1 %2782, <8 x i1> zeroinitializer, <8 x i1> %2777
  %2784 = select i1 %2772, <8 x i1> %2783, <8 x i1> %2776
  store <8 x i1> %2784, ptr %2774, align 1
  %2785 = select i1 %2782, <8 x i1> zeroinitializer, <8 x i1> %2775
  store <8 x i1> %2785, ptr %2773, align 1
  %2786 = trunc i32 %2762 to i8
  %2787 = shl i8 1, %2786
  %2788 = xor i8 %2787, -1
  %2789 = and i8 %2763, %2788
  %2790 = select i1 %2782, i8 %2789, i8 %2763
  store i8 %2790, ptr %frame.active, align 1
  %.splatinsert476 = insertelement <8 x i1> poison, i1 %2772, i64 0
  %.splat477 = shufflevector <8 x i1> %.splatinsert476, <8 x i1> poison, <8 x i32> zeroinitializer
  %2791 = and <8 x i1> %convergence.cascade.flow472, %.splat477
  %2792 = load <8 x i1>, ptr %runnable.mask, align 1
  %2793 = xor <8 x i1> %2791, splat (i1 true)
  %2794 = and <8 x i1> %2792, %2793
  store <8 x i1> %2794, ptr %runnable.mask, align 1
  %.splatinsert478 = insertelement <8 x i1> poison, i1 %2782, i64 0
  %.splat479 = shufflevector <8 x i1> %.splatinsert478, <8 x i1> poison, <8 x i32> zeroinitializer
  %2795 = select <8 x i1> %.splat479, <8 x i1> %2777, <8 x i1> zeroinitializer
  %2796 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2797 = extractelement <8 x i32> %2796, i32 %2762
  %2798 = select i1 %2782, i32 %2797, i32 %2758
  store i32 %2798, ptr %current.token, align 4
  %.splatinsert480 = insertelement <8 x i1> poison, i1 %2772, i64 0
  %.splat481 = shufflevector <8 x i1> %.splatinsert480, <8 x i1> poison, <8 x i32> zeroinitializer
  %2799 = select <8 x i1> %.splat481, <8 x i1> %2795, <8 x i1> %convergence.cascade.flow472
  %2800 = add i32 %convergence.cascade.depth473, 1
  %2801 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2799)
  %2802 = icmp ult i32 %2800, 8
  %2803 = and i1 %2801, %2802
  %2804 = and i1 %2772, %2803
  %convergence.parent.token482 = load i32, ptr %current.token, align 4
  %convergence.parent.present483 = icmp ne i32 %convergence.parent.token482, 0
  %2805 = and i1 %2804, %convergence.parent.present483
  br i1 %2805, label %convergence.cascade468, label %convergence.cascade.exit469

convergence.cascade.exit469:                      ; preds = %convergence.cascade468, %schedule.20
  %convergence.cascade.result484 = phi <8 x i1> [ %405, %schedule.20 ], [ %2799, %convergence.cascade468 ]
  %2806 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result484)
  br i1 %2806, label %convergence.target.20.ready, label %scheduler.loop

convergence.target.20.ready:                      ; preds = %convergence.cascade.exit469
  %2807 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result484)
  %2808 = bitcast <8 x i1> %convergence.cascade.result484 to i8
  %2809 = call i8 @llvm.cttz.i8(i8 %2808, i1 false)
  %2810 = zext i8 %2809 to i32
  %2811 = select i1 %2807, i32 %2810, i32 0
  %.spill.load485 = load <8 x i64>, ptr %.spill63, align 64
  %.spill.load486 = load volatile i64, ptr %.spill22, align 4
  %.splatinsert487 = insertelement <8 x i64> poison, i64 %.spill.load486, i64 0
  %.splat488 = shufflevector <8 x i64> %.splatinsert487, <8 x i64> poison, <8 x i32> zeroinitializer
  %2812 = add <8 x i64> %.spill.load485, %.splat488
  %2813 = load volatile <8 x i64>, ptr %.spill72, align 64
  %2814 = select <8 x i1> %convergence.cascade.result484, <8 x i64> %2812, <8 x i64> %2813
  store volatile <8 x i64> %2814, ptr %.spill72, align 64
  %.spill.load489 = load <8 x i1>, ptr %.spill62, align 1
  %2815 = and <8 x i1> %convergence.cascade.result484, %.spill.load489
  %2816 = xor <8 x i1> %.spill.load489, splat (i1 true)
  %2817 = and <8 x i1> %convergence.cascade.result484, %2816
  %2818 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2815)
  %2819 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2817)
  %2820 = and i1 %2818, %2819
  br i1 %2820, label %varying.divergent490, label %varying.coherent491

varying.divergent490:                             ; preds = %convergence.target.20.ready
  %2821 = load i32, ptr %current.token, align 4
  %2822 = icmp ne i32 %2821, 0
  %2823 = sub i32 %2821, 1
  %2824 = select i1 %2822, i32 %2823, i32 0
  %2825 = load i8, ptr %frame.active, align 1
  %2826 = trunc i32 %2824 to i8
  %2827 = shl i8 1, %2826
  %2828 = and i8 %2825, %2827
  %2829 = icmp ne i8 %2828, 0
  %2830 = load <8 x i32>, ptr %frame.static.id, align 32
  %2831 = extractelement <8 x i32> %2830, i32 %2824
  %2832 = icmp eq i32 %2831, 10
  %2833 = and i1 %2829, %2832
  %2834 = and i1 %2822, %2833
  %2835 = xor i1 %2834, true
  %2836 = and i1 true, %2835
  %2837 = xor i8 %2825, -1
  %2838 = icmp ne i8 %2837, 0
  %2839 = xor i1 %2838, true
  %2840 = and i1 %2836, %2839
  br i1 %2840, label %convergence.overflow.trap492, label %convergence.overflow.resume493

varying.coherent491:                              ; preds = %convergence.target.20.ready
  br i1 %2818, label %varying.coherent.true496, label %varying.coherent.false497

convergence.overflow.trap492:                     ; preds = %varying.divergent490
  call void @llvm.trap()
  unreachable

convergence.overflow.resume493:                   ; preds = %varying.divergent490
  %2841 = call i8 @llvm.cttz.i8(i8 %2837, i1 false)
  %2842 = zext i8 %2841 to i32
  %2843 = select i1 %2838, i32 %2842, i32 0
  %2844 = trunc i32 %2843 to i8
  %2845 = shl i8 1, %2844
  %2846 = or i8 %2825, %2845
  %2847 = select i1 %2836, i8 %2846, i8 %2825
  store i8 %2847, ptr %frame.active, align 1
  %2848 = load <8 x i32>, ptr %frame.static.id, align 32
  %2849 = extractelement <8 x i32> %2848, i32 %2843
  %2850 = select i1 %2836, i32 10, i32 %2849
  %2851 = load <8 x i32>, ptr %frame.static.id, align 32
  %2852 = insertelement <8 x i32> %2851, i32 %2850, i32 %2843
  store <8 x i32> %2852, ptr %frame.static.id, align 32
  %2853 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2854 = extractelement <8 x i32> %2853, i32 %2843
  %2855 = select i1 %2836, i32 %2821, i32 %2854
  %2856 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2857 = insertelement <8 x i32> %2856, i32 %2855, i32 %2843
  store <8 x i32> %2857, ptr %frame.parent.token, align 32
  %2858 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2843
  %2859 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2843
  %2860 = load <8 x i1>, ptr %2858, align 1
  %2861 = load <8 x i1>, ptr %2859, align 1
  %2862 = select i1 %2836, <8 x i1> %convergence.cascade.result484, <8 x i1> %2860
  store <8 x i1> %2862, ptr %2858, align 1
  %2863 = select i1 %2836, <8 x i1> zeroinitializer, <8 x i1> %2861
  store <8 x i1> %2863, ptr %2859, align 1
  %2864 = add i32 %2843, 1
  %2865 = select i1 %2834, i32 %2821, i32 %2864
  %2866 = select i1 true, i32 %2865, i32 %2821
  store i32 %2866, ptr %current.token, align 4
  %2867 = load <8 x float>, ptr %.slot73, align 32
  %2868 = select <8 x i1> %2817, <8 x float> zeroinitializer, <8 x float> %2867
  store <8 x float> %2868, ptr %.slot73, align 32
  %2869 = load i32, ptr %current.token, align 4
  %2870 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2815)
  %2871 = load i32, ptr %ready.count, align 4
  %2872 = icmp uge i32 %2871, 8
  %2873 = and i1 %2870, %2872
  br i1 %2873, label %ready.overflow.trap494, label %ready.overflow.resume495

ready.overflow.trap494:                           ; preds = %convergence.overflow.resume493
  call void @llvm.trap()
  unreachable

ready.overflow.resume495:                         ; preds = %convergence.overflow.resume493
  %2874 = select i1 %2870, i32 %2871, i32 0
  %2875 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2874
  %2876 = load <8 x i1>, ptr %2875, align 1
  %2877 = select i1 %2870, <8 x i1> %2815, <8 x i1> %2876
  store <8 x i1> %2877, ptr %2875, align 1
  %2878 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2874
  %2879 = load i32, ptr %2878, align 4
  %2880 = select i1 %2870, i32 21, i32 %2879
  store i32 %2880, ptr %2878, align 4
  %2881 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2874
  %2882 = load i32, ptr %2881, align 4
  %2883 = select i1 %2870, i32 %2869, i32 %2882
  store i32 %2883, ptr %2881, align 4
  %2884 = add i32 %2871, 1
  %2885 = select i1 %2870, i32 %2884, i32 %2871
  store i32 %2885, ptr %ready.count, align 4
  %2886 = load <8 x i1>, ptr %runnable.mask, align 1
  %2887 = or <8 x i1> %2886, %2815
  store <8 x i1> %2887, ptr %runnable.mask, align 1
  store <8 x i1> %2817, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true496:                         ; preds = %varying.coherent491
  store <8 x i1> %convergence.cascade.result484, ptr %current.mask, align 1
  %2888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result484)
  br i1 %2888, label %schedule.21, label %scheduler.loop

varying.coherent.false497:                        ; preds = %varying.coherent491
  %2889 = load <8 x float>, ptr %.slot73, align 32
  %2890 = select <8 x i1> %convergence.cascade.result484, <8 x float> zeroinitializer, <8 x float> %2889
  store <8 x float> %2890, ptr %.slot73, align 32
  store <8 x i1> %convergence.cascade.result484, ptr %current.mask, align 1
  %2891 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result484)
  br i1 %2891, label %schedule.22, label %scheduler.loop

convergence.cascade499:                           ; preds = %convergence.cascade499, %schedule.22
  %convergence.cascade.flow503 = phi <8 x i1> [ %419, %schedule.22 ], [ %2934, %convergence.cascade499 ]
  %convergence.cascade.depth504 = phi i32 [ 0, %schedule.22 ], [ %2935, %convergence.cascade499 ]
  %2892 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow503)
  %2893 = load i32, ptr %current.token, align 4
  %2894 = icmp ne i32 %2893, 0
  %2895 = and i1 %2892, %2894
  %2896 = sub i32 %2893, 1
  %2897 = select i1 %2895, i32 %2896, i32 0
  %2898 = load i8, ptr %frame.active, align 1
  %2899 = trunc i32 %2897 to i8
  %2900 = shl i8 1, %2899
  %2901 = and i8 %2898, %2900
  %2902 = icmp ne i8 %2901, 0
  %2903 = load <8 x i32>, ptr %frame.static.id, align 32
  %2904 = extractelement <8 x i32> %2903, i32 %2897
  %convergence.target.pointer505 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %2904
  %convergence.dynamic.target506 = load i32, ptr %convergence.target.pointer505, align 4
  %2905 = icmp eq i32 %convergence.dynamic.target506, 22
  %2906 = and i1 %2902, %2905
  %2907 = and i1 %2895, %2906
  %2908 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2897
  %2909 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2897
  %2910 = load <8 x i1>, ptr %2908, align 1
  %2911 = load <8 x i1>, ptr %2909, align 1
  %2912 = or <8 x i1> %2911, %convergence.cascade.flow503
  %2913 = load <8 x i1>, ptr %live.mask, align 1
  %2914 = and <8 x i1> %2910, %2913
  %2915 = icmp eq <8 x i1> %2912, %2914
  %2916 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2915)
  %2917 = and i1 %2907, %2916
  %2918 = select i1 %2917, <8 x i1> zeroinitializer, <8 x i1> %2912
  %2919 = select i1 %2907, <8 x i1> %2918, <8 x i1> %2911
  store <8 x i1> %2919, ptr %2909, align 1
  %2920 = select i1 %2917, <8 x i1> zeroinitializer, <8 x i1> %2910
  store <8 x i1> %2920, ptr %2908, align 1
  %2921 = trunc i32 %2897 to i8
  %2922 = shl i8 1, %2921
  %2923 = xor i8 %2922, -1
  %2924 = and i8 %2898, %2923
  %2925 = select i1 %2917, i8 %2924, i8 %2898
  store i8 %2925, ptr %frame.active, align 1
  %.splatinsert507 = insertelement <8 x i1> poison, i1 %2907, i64 0
  %.splat508 = shufflevector <8 x i1> %.splatinsert507, <8 x i1> poison, <8 x i32> zeroinitializer
  %2926 = and <8 x i1> %convergence.cascade.flow503, %.splat508
  %2927 = load <8 x i1>, ptr %runnable.mask, align 1
  %2928 = xor <8 x i1> %2926, splat (i1 true)
  %2929 = and <8 x i1> %2927, %2928
  store <8 x i1> %2929, ptr %runnable.mask, align 1
  %.splatinsert509 = insertelement <8 x i1> poison, i1 %2917, i64 0
  %.splat510 = shufflevector <8 x i1> %.splatinsert509, <8 x i1> poison, <8 x i32> zeroinitializer
  %2930 = select <8 x i1> %.splat510, <8 x i1> %2912, <8 x i1> zeroinitializer
  %2931 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2932 = extractelement <8 x i32> %2931, i32 %2897
  %2933 = select i1 %2917, i32 %2932, i32 %2893
  store i32 %2933, ptr %current.token, align 4
  %.splatinsert511 = insertelement <8 x i1> poison, i1 %2907, i64 0
  %.splat512 = shufflevector <8 x i1> %.splatinsert511, <8 x i1> poison, <8 x i32> zeroinitializer
  %2934 = select <8 x i1> %.splat512, <8 x i1> %2930, <8 x i1> %convergence.cascade.flow503
  %2935 = add i32 %convergence.cascade.depth504, 1
  %2936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2934)
  %2937 = icmp ult i32 %2935, 8
  %2938 = and i1 %2936, %2937
  %2939 = and i1 %2907, %2938
  %convergence.parent.token513 = load i32, ptr %current.token, align 4
  %convergence.parent.present514 = icmp ne i32 %convergence.parent.token513, 0
  %2940 = and i1 %2939, %convergence.parent.present514
  br i1 %2940, label %convergence.cascade499, label %convergence.cascade.exit500

convergence.cascade.exit500:                      ; preds = %convergence.cascade499, %schedule.22
  %convergence.cascade.result515 = phi <8 x i1> [ %419, %schedule.22 ], [ %2934, %convergence.cascade499 ]
  %2941 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result515)
  br i1 %2941, label %convergence.target.22.ready, label %scheduler.loop

convergence.target.22.ready:                      ; preds = %convergence.cascade.exit500
  %2942 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result515)
  %2943 = bitcast <8 x i1> %convergence.cascade.result515 to i8
  %2944 = call i8 @llvm.cttz.i8(i8 %2943, i1 false)
  %2945 = zext i8 %2944 to i32
  %2946 = select i1 %2942, i32 %2945, i32 0
  %.spill.load516 = load volatile <8 x i64>, ptr %.spill50, align 64
  %2947 = add <8 x i64> %.spill.load516, splat (i64 2)
  %2948 = load volatile <8 x i64>, ptr %.spill74, align 64
  %2949 = select <8 x i1> %convergence.cascade.result515, <8 x i64> %2947, <8 x i64> %2948
  store volatile <8 x i64> %2949, ptr %.spill74, align 64
  %.spill.load517 = load volatile <8 x i64>, ptr %.spill52, align 64
  %2950 = add <8 x i64> %.spill.load517, %2947
  %2951 = load volatile <8 x i64>, ptr %.spill75, align 64
  %2952 = select <8 x i1> %convergence.cascade.result515, <8 x i64> %2950, <8 x i64> %2951
  store volatile <8 x i64> %2952, ptr %.spill75, align 64
  %2953 = icmp sge <8 x i64> %2947, zeroinitializer
  %2954 = and <8 x i1> splat (i1 true), %2953
  %2955 = icmp slt <8 x i64> %2947, splat (i64 7)
  %2956 = load volatile <8 x i1>, ptr %.spill76, align 1
  %2957 = select <8 x i1> %convergence.cascade.result515, <8 x i1> %2955, <8 x i1> %2956
  store volatile <8 x i1> %2957, ptr %.spill76, align 1
  %2958 = and <8 x i1> %2954, %2955
  %2959 = load <8 x i1>, ptr %.spill77, align 1
  %2960 = select <8 x i1> %convergence.cascade.result515, <8 x i1> %2958, <8 x i1> %2959
  store <8 x i1> %2960, ptr %.spill77, align 1
  %2961 = mul <8 x i64> %2950, splat (i64 5)
  %2962 = load <8 x i64>, ptr %.spill78, align 64
  %2963 = select <8 x i1> %convergence.cascade.result515, <8 x i64> %2961, <8 x i64> %2962
  store <8 x i64> %2963, ptr %.spill78, align 64
  %.spill.load518 = load i64, ptr %.spill10, align 4
  %.splatinsert519 = insertelement <8 x i64> poison, i64 %.spill.load518, i64 0
  %.splat520 = shufflevector <8 x i64> %.splatinsert519, <8 x i64> poison, <8 x i32> zeroinitializer
  %2964 = add <8 x i64> %2961, %.splat520
  %2965 = load volatile <8 x i64>, ptr %.spill79, align 64
  %2966 = select <8 x i1> %convergence.cascade.result515, <8 x i64> %2964, <8 x i64> %2965
  store volatile <8 x i64> %2966, ptr %.spill79, align 64
  %2967 = and <8 x i1> %convergence.cascade.result515, %2958
  %2968 = xor <8 x i1> %2958, splat (i1 true)
  %2969 = and <8 x i1> %convergence.cascade.result515, %2968
  %2970 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2967)
  %2971 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2969)
  %2972 = and i1 %2970, %2971
  br i1 %2972, label %varying.divergent521, label %varying.coherent522

varying.divergent521:                             ; preds = %convergence.target.22.ready
  %2973 = load i32, ptr %current.token, align 4
  %2974 = icmp ne i32 %2973, 0
  %2975 = sub i32 %2973, 1
  %2976 = select i1 %2974, i32 %2975, i32 0
  %2977 = load i8, ptr %frame.active, align 1
  %2978 = trunc i32 %2976 to i8
  %2979 = shl i8 1, %2978
  %2980 = and i8 %2977, %2979
  %2981 = icmp ne i8 %2980, 0
  %2982 = load <8 x i32>, ptr %frame.static.id, align 32
  %2983 = extractelement <8 x i32> %2982, i32 %2976
  %2984 = icmp eq i32 %2983, 11
  %2985 = and i1 %2981, %2984
  %2986 = and i1 %2974, %2985
  %2987 = xor i1 %2986, true
  %2988 = and i1 true, %2987
  %2989 = xor i8 %2977, -1
  %2990 = icmp ne i8 %2989, 0
  %2991 = xor i1 %2990, true
  %2992 = and i1 %2988, %2991
  br i1 %2992, label %convergence.overflow.trap523, label %convergence.overflow.resume524

varying.coherent522:                              ; preds = %convergence.target.22.ready
  br i1 %2970, label %varying.coherent.true527, label %varying.coherent.false528

convergence.overflow.trap523:                     ; preds = %varying.divergent521
  call void @llvm.trap()
  unreachable

convergence.overflow.resume524:                   ; preds = %varying.divergent521
  %2993 = call i8 @llvm.cttz.i8(i8 %2989, i1 false)
  %2994 = zext i8 %2993 to i32
  %2995 = select i1 %2990, i32 %2994, i32 0
  %2996 = trunc i32 %2995 to i8
  %2997 = shl i8 1, %2996
  %2998 = or i8 %2977, %2997
  %2999 = select i1 %2988, i8 %2998, i8 %2977
  store i8 %2999, ptr %frame.active, align 1
  %3000 = load <8 x i32>, ptr %frame.static.id, align 32
  %3001 = extractelement <8 x i32> %3000, i32 %2995
  %3002 = select i1 %2988, i32 11, i32 %3001
  %3003 = load <8 x i32>, ptr %frame.static.id, align 32
  %3004 = insertelement <8 x i32> %3003, i32 %3002, i32 %2995
  store <8 x i32> %3004, ptr %frame.static.id, align 32
  %3005 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3006 = extractelement <8 x i32> %3005, i32 %2995
  %3007 = select i1 %2988, i32 %2973, i32 %3006
  %3008 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3009 = insertelement <8 x i32> %3008, i32 %3007, i32 %2995
  store <8 x i32> %3009, ptr %frame.parent.token, align 32
  %3010 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2995
  %3011 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2995
  %3012 = load <8 x i1>, ptr %3010, align 1
  %3013 = load <8 x i1>, ptr %3011, align 1
  %3014 = select i1 %2988, <8 x i1> %convergence.cascade.result515, <8 x i1> %3012
  store <8 x i1> %3014, ptr %3010, align 1
  %3015 = select i1 %2988, <8 x i1> zeroinitializer, <8 x i1> %3013
  store <8 x i1> %3015, ptr %3011, align 1
  %3016 = add i32 %2995, 1
  %3017 = select i1 %2986, i32 %2973, i32 %3016
  %3018 = select i1 true, i32 %3017, i32 %2973
  store i32 %3018, ptr %current.token, align 4
  %3019 = load <8 x float>, ptr %.slot80, align 32
  %3020 = select <8 x i1> %2969, <8 x float> zeroinitializer, <8 x float> %3019
  store <8 x float> %3020, ptr %.slot80, align 32
  %3021 = load i32, ptr %current.token, align 4
  %3022 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2967)
  %3023 = load i32, ptr %ready.count, align 4
  %3024 = icmp uge i32 %3023, 8
  %3025 = and i1 %3022, %3024
  br i1 %3025, label %ready.overflow.trap525, label %ready.overflow.resume526

ready.overflow.trap525:                           ; preds = %convergence.overflow.resume524
  call void @llvm.trap()
  unreachable

ready.overflow.resume526:                         ; preds = %convergence.overflow.resume524
  %3026 = select i1 %3022, i32 %3023, i32 0
  %3027 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3026
  %3028 = load <8 x i1>, ptr %3027, align 1
  %3029 = select i1 %3022, <8 x i1> %2967, <8 x i1> %3028
  store <8 x i1> %3029, ptr %3027, align 1
  %3030 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3026
  %3031 = load i32, ptr %3030, align 4
  %3032 = select i1 %3022, i32 23, i32 %3031
  store i32 %3032, ptr %3030, align 4
  %3033 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3026
  %3034 = load i32, ptr %3033, align 4
  %3035 = select i1 %3022, i32 %3021, i32 %3034
  store i32 %3035, ptr %3033, align 4
  %3036 = add i32 %3023, 1
  %3037 = select i1 %3022, i32 %3036, i32 %3023
  store i32 %3037, ptr %ready.count, align 4
  %3038 = load <8 x i1>, ptr %runnable.mask, align 1
  %3039 = or <8 x i1> %3038, %2967
  store <8 x i1> %3039, ptr %runnable.mask, align 1
  store <8 x i1> %2969, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true527:                         ; preds = %varying.coherent522
  store <8 x i1> %convergence.cascade.result515, ptr %current.mask, align 1
  %3040 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result515)
  br i1 %3040, label %schedule.23, label %scheduler.loop

varying.coherent.false528:                        ; preds = %varying.coherent522
  %3041 = load <8 x float>, ptr %.slot80, align 32
  %3042 = select <8 x i1> %convergence.cascade.result515, <8 x float> zeroinitializer, <8 x float> %3041
  store <8 x float> %3042, ptr %.slot80, align 32
  store <8 x i1> %convergence.cascade.result515, ptr %current.mask, align 1
  %3043 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result515)
  br i1 %3043, label %schedule.24, label %scheduler.loop

convergence.cascade530:                           ; preds = %convergence.cascade530, %schedule.24
  %convergence.cascade.flow534 = phi <8 x i1> [ %433, %schedule.24 ], [ %3086, %convergence.cascade530 ]
  %convergence.cascade.depth535 = phi i32 [ 0, %schedule.24 ], [ %3087, %convergence.cascade530 ]
  %3044 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow534)
  %3045 = load i32, ptr %current.token, align 4
  %3046 = icmp ne i32 %3045, 0
  %3047 = and i1 %3044, %3046
  %3048 = sub i32 %3045, 1
  %3049 = select i1 %3047, i32 %3048, i32 0
  %3050 = load i8, ptr %frame.active, align 1
  %3051 = trunc i32 %3049 to i8
  %3052 = shl i8 1, %3051
  %3053 = and i8 %3050, %3052
  %3054 = icmp ne i8 %3053, 0
  %3055 = load <8 x i32>, ptr %frame.static.id, align 32
  %3056 = extractelement <8 x i32> %3055, i32 %3049
  %convergence.target.pointer536 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %3056
  %convergence.dynamic.target537 = load i32, ptr %convergence.target.pointer536, align 4
  %3057 = icmp eq i32 %convergence.dynamic.target537, 24
  %3058 = and i1 %3054, %3057
  %3059 = and i1 %3047, %3058
  %3060 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3049
  %3061 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3049
  %3062 = load <8 x i1>, ptr %3060, align 1
  %3063 = load <8 x i1>, ptr %3061, align 1
  %3064 = or <8 x i1> %3063, %convergence.cascade.flow534
  %3065 = load <8 x i1>, ptr %live.mask, align 1
  %3066 = and <8 x i1> %3062, %3065
  %3067 = icmp eq <8 x i1> %3064, %3066
  %3068 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3067)
  %3069 = and i1 %3059, %3068
  %3070 = select i1 %3069, <8 x i1> zeroinitializer, <8 x i1> %3064
  %3071 = select i1 %3059, <8 x i1> %3070, <8 x i1> %3063
  store <8 x i1> %3071, ptr %3061, align 1
  %3072 = select i1 %3069, <8 x i1> zeroinitializer, <8 x i1> %3062
  store <8 x i1> %3072, ptr %3060, align 1
  %3073 = trunc i32 %3049 to i8
  %3074 = shl i8 1, %3073
  %3075 = xor i8 %3074, -1
  %3076 = and i8 %3050, %3075
  %3077 = select i1 %3069, i8 %3076, i8 %3050
  store i8 %3077, ptr %frame.active, align 1
  %.splatinsert538 = insertelement <8 x i1> poison, i1 %3059, i64 0
  %.splat539 = shufflevector <8 x i1> %.splatinsert538, <8 x i1> poison, <8 x i32> zeroinitializer
  %3078 = and <8 x i1> %convergence.cascade.flow534, %.splat539
  %3079 = load <8 x i1>, ptr %runnable.mask, align 1
  %3080 = xor <8 x i1> %3078, splat (i1 true)
  %3081 = and <8 x i1> %3079, %3080
  store <8 x i1> %3081, ptr %runnable.mask, align 1
  %.splatinsert540 = insertelement <8 x i1> poison, i1 %3069, i64 0
  %.splat541 = shufflevector <8 x i1> %.splatinsert540, <8 x i1> poison, <8 x i32> zeroinitializer
  %3082 = select <8 x i1> %.splat541, <8 x i1> %3064, <8 x i1> zeroinitializer
  %3083 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3084 = extractelement <8 x i32> %3083, i32 %3049
  %3085 = select i1 %3069, i32 %3084, i32 %3045
  store i32 %3085, ptr %current.token, align 4
  %.splatinsert542 = insertelement <8 x i1> poison, i1 %3059, i64 0
  %.splat543 = shufflevector <8 x i1> %.splatinsert542, <8 x i1> poison, <8 x i32> zeroinitializer
  %3086 = select <8 x i1> %.splat543, <8 x i1> %3082, <8 x i1> %convergence.cascade.flow534
  %3087 = add i32 %convergence.cascade.depth535, 1
  %3088 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3086)
  %3089 = icmp ult i32 %3087, 8
  %3090 = and i1 %3088, %3089
  %3091 = and i1 %3059, %3090
  %convergence.parent.token544 = load i32, ptr %current.token, align 4
  %convergence.parent.present545 = icmp ne i32 %convergence.parent.token544, 0
  %3092 = and i1 %3091, %convergence.parent.present545
  br i1 %3092, label %convergence.cascade530, label %convergence.cascade.exit531

convergence.cascade.exit531:                      ; preds = %convergence.cascade530, %schedule.24
  %convergence.cascade.result546 = phi <8 x i1> [ %433, %schedule.24 ], [ %3086, %convergence.cascade530 ]
  %3093 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result546)
  br i1 %3093, label %convergence.target.24.ready, label %scheduler.loop

convergence.target.24.ready:                      ; preds = %convergence.cascade.exit531
  %3094 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result546)
  %3095 = bitcast <8 x i1> %convergence.cascade.result546 to i8
  %3096 = call i8 @llvm.cttz.i8(i8 %3095, i1 false)
  %3097 = zext i8 %3096 to i32
  %3098 = select i1 %3094, i32 %3097, i32 0
  %.spill.load547 = load <8 x i64>, ptr %.spill78, align 64
  %.spill.load548 = load i64, ptr %.spill16, align 4
  %.splatinsert549 = insertelement <8 x i64> poison, i64 %.spill.load548, i64 0
  %.splat550 = shufflevector <8 x i64> %.splatinsert549, <8 x i64> poison, <8 x i32> zeroinitializer
  %3099 = add <8 x i64> %.spill.load547, %.splat550
  %3100 = load volatile <8 x i64>, ptr %.spill81, align 64
  %3101 = select <8 x i1> %convergence.cascade.result546, <8 x i64> %3099, <8 x i64> %3100
  store volatile <8 x i64> %3101, ptr %.spill81, align 64
  %.spill.load551 = load <8 x i1>, ptr %.spill77, align 1
  %3102 = and <8 x i1> %convergence.cascade.result546, %.spill.load551
  %3103 = xor <8 x i1> %.spill.load551, splat (i1 true)
  %3104 = and <8 x i1> %convergence.cascade.result546, %3103
  %3105 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3102)
  %3106 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3104)
  %3107 = and i1 %3105, %3106
  br i1 %3107, label %varying.divergent552, label %varying.coherent553

varying.divergent552:                             ; preds = %convergence.target.24.ready
  %3108 = load i32, ptr %current.token, align 4
  %3109 = icmp ne i32 %3108, 0
  %3110 = sub i32 %3108, 1
  %3111 = select i1 %3109, i32 %3110, i32 0
  %3112 = load i8, ptr %frame.active, align 1
  %3113 = trunc i32 %3111 to i8
  %3114 = shl i8 1, %3113
  %3115 = and i8 %3112, %3114
  %3116 = icmp ne i8 %3115, 0
  %3117 = load <8 x i32>, ptr %frame.static.id, align 32
  %3118 = extractelement <8 x i32> %3117, i32 %3111
  %3119 = icmp eq i32 %3118, 12
  %3120 = and i1 %3116, %3119
  %3121 = and i1 %3109, %3120
  %3122 = xor i1 %3121, true
  %3123 = and i1 true, %3122
  %3124 = xor i8 %3112, -1
  %3125 = icmp ne i8 %3124, 0
  %3126 = xor i1 %3125, true
  %3127 = and i1 %3123, %3126
  br i1 %3127, label %convergence.overflow.trap554, label %convergence.overflow.resume555

varying.coherent553:                              ; preds = %convergence.target.24.ready
  br i1 %3105, label %varying.coherent.true558, label %varying.coherent.false559

convergence.overflow.trap554:                     ; preds = %varying.divergent552
  call void @llvm.trap()
  unreachable

convergence.overflow.resume555:                   ; preds = %varying.divergent552
  %3128 = call i8 @llvm.cttz.i8(i8 %3124, i1 false)
  %3129 = zext i8 %3128 to i32
  %3130 = select i1 %3125, i32 %3129, i32 0
  %3131 = trunc i32 %3130 to i8
  %3132 = shl i8 1, %3131
  %3133 = or i8 %3112, %3132
  %3134 = select i1 %3123, i8 %3133, i8 %3112
  store i8 %3134, ptr %frame.active, align 1
  %3135 = load <8 x i32>, ptr %frame.static.id, align 32
  %3136 = extractelement <8 x i32> %3135, i32 %3130
  %3137 = select i1 %3123, i32 12, i32 %3136
  %3138 = load <8 x i32>, ptr %frame.static.id, align 32
  %3139 = insertelement <8 x i32> %3138, i32 %3137, i32 %3130
  store <8 x i32> %3139, ptr %frame.static.id, align 32
  %3140 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3141 = extractelement <8 x i32> %3140, i32 %3130
  %3142 = select i1 %3123, i32 %3108, i32 %3141
  %3143 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3144 = insertelement <8 x i32> %3143, i32 %3142, i32 %3130
  store <8 x i32> %3144, ptr %frame.parent.token, align 32
  %3145 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3130
  %3146 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3130
  %3147 = load <8 x i1>, ptr %3145, align 1
  %3148 = load <8 x i1>, ptr %3146, align 1
  %3149 = select i1 %3123, <8 x i1> %convergence.cascade.result546, <8 x i1> %3147
  store <8 x i1> %3149, ptr %3145, align 1
  %3150 = select i1 %3123, <8 x i1> zeroinitializer, <8 x i1> %3148
  store <8 x i1> %3150, ptr %3146, align 1
  %3151 = add i32 %3130, 1
  %3152 = select i1 %3121, i32 %3108, i32 %3151
  %3153 = select i1 true, i32 %3152, i32 %3108
  store i32 %3153, ptr %current.token, align 4
  %3154 = load <8 x float>, ptr %.slot82, align 32
  %3155 = select <8 x i1> %3104, <8 x float> zeroinitializer, <8 x float> %3154
  store <8 x float> %3155, ptr %.slot82, align 32
  %3156 = load i32, ptr %current.token, align 4
  %3157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3102)
  %3158 = load i32, ptr %ready.count, align 4
  %3159 = icmp uge i32 %3158, 8
  %3160 = and i1 %3157, %3159
  br i1 %3160, label %ready.overflow.trap556, label %ready.overflow.resume557

ready.overflow.trap556:                           ; preds = %convergence.overflow.resume555
  call void @llvm.trap()
  unreachable

ready.overflow.resume557:                         ; preds = %convergence.overflow.resume555
  %3161 = select i1 %3157, i32 %3158, i32 0
  %3162 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3161
  %3163 = load <8 x i1>, ptr %3162, align 1
  %3164 = select i1 %3157, <8 x i1> %3102, <8 x i1> %3163
  store <8 x i1> %3164, ptr %3162, align 1
  %3165 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3161
  %3166 = load i32, ptr %3165, align 4
  %3167 = select i1 %3157, i32 25, i32 %3166
  store i32 %3167, ptr %3165, align 4
  %3168 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3161
  %3169 = load i32, ptr %3168, align 4
  %3170 = select i1 %3157, i32 %3156, i32 %3169
  store i32 %3170, ptr %3168, align 4
  %3171 = add i32 %3158, 1
  %3172 = select i1 %3157, i32 %3171, i32 %3158
  store i32 %3172, ptr %ready.count, align 4
  %3173 = load <8 x i1>, ptr %runnable.mask, align 1
  %3174 = or <8 x i1> %3173, %3102
  store <8 x i1> %3174, ptr %runnable.mask, align 1
  store <8 x i1> %3104, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true558:                         ; preds = %varying.coherent553
  store <8 x i1> %convergence.cascade.result546, ptr %current.mask, align 1
  %3175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result546)
  br i1 %3175, label %schedule.25, label %scheduler.loop

varying.coherent.false559:                        ; preds = %varying.coherent553
  %3176 = load <8 x float>, ptr %.slot82, align 32
  %3177 = select <8 x i1> %convergence.cascade.result546, <8 x float> zeroinitializer, <8 x float> %3176
  store <8 x float> %3177, ptr %.slot82, align 32
  store <8 x i1> %convergence.cascade.result546, ptr %current.mask, align 1
  %3178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result546)
  br i1 %3178, label %schedule.26, label %scheduler.loop

convergence.cascade561:                           ; preds = %convergence.cascade561, %schedule.26
  %convergence.cascade.flow565 = phi <8 x i1> [ %447, %schedule.26 ], [ %3221, %convergence.cascade561 ]
  %convergence.cascade.depth566 = phi i32 [ 0, %schedule.26 ], [ %3222, %convergence.cascade561 ]
  %3179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow565)
  %3180 = load i32, ptr %current.token, align 4
  %3181 = icmp ne i32 %3180, 0
  %3182 = and i1 %3179, %3181
  %3183 = sub i32 %3180, 1
  %3184 = select i1 %3182, i32 %3183, i32 0
  %3185 = load i8, ptr %frame.active, align 1
  %3186 = trunc i32 %3184 to i8
  %3187 = shl i8 1, %3186
  %3188 = and i8 %3185, %3187
  %3189 = icmp ne i8 %3188, 0
  %3190 = load <8 x i32>, ptr %frame.static.id, align 32
  %3191 = extractelement <8 x i32> %3190, i32 %3184
  %convergence.target.pointer567 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %3191
  %convergence.dynamic.target568 = load i32, ptr %convergence.target.pointer567, align 4
  %3192 = icmp eq i32 %convergence.dynamic.target568, 26
  %3193 = and i1 %3189, %3192
  %3194 = and i1 %3182, %3193
  %3195 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3184
  %3196 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3184
  %3197 = load <8 x i1>, ptr %3195, align 1
  %3198 = load <8 x i1>, ptr %3196, align 1
  %3199 = or <8 x i1> %3198, %convergence.cascade.flow565
  %3200 = load <8 x i1>, ptr %live.mask, align 1
  %3201 = and <8 x i1> %3197, %3200
  %3202 = icmp eq <8 x i1> %3199, %3201
  %3203 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3202)
  %3204 = and i1 %3194, %3203
  %3205 = select i1 %3204, <8 x i1> zeroinitializer, <8 x i1> %3199
  %3206 = select i1 %3194, <8 x i1> %3205, <8 x i1> %3198
  store <8 x i1> %3206, ptr %3196, align 1
  %3207 = select i1 %3204, <8 x i1> zeroinitializer, <8 x i1> %3197
  store <8 x i1> %3207, ptr %3195, align 1
  %3208 = trunc i32 %3184 to i8
  %3209 = shl i8 1, %3208
  %3210 = xor i8 %3209, -1
  %3211 = and i8 %3185, %3210
  %3212 = select i1 %3204, i8 %3211, i8 %3185
  store i8 %3212, ptr %frame.active, align 1
  %.splatinsert569 = insertelement <8 x i1> poison, i1 %3194, i64 0
  %.splat570 = shufflevector <8 x i1> %.splatinsert569, <8 x i1> poison, <8 x i32> zeroinitializer
  %3213 = and <8 x i1> %convergence.cascade.flow565, %.splat570
  %3214 = load <8 x i1>, ptr %runnable.mask, align 1
  %3215 = xor <8 x i1> %3213, splat (i1 true)
  %3216 = and <8 x i1> %3214, %3215
  store <8 x i1> %3216, ptr %runnable.mask, align 1
  %.splatinsert571 = insertelement <8 x i1> poison, i1 %3204, i64 0
  %.splat572 = shufflevector <8 x i1> %.splatinsert571, <8 x i1> poison, <8 x i32> zeroinitializer
  %3217 = select <8 x i1> %.splat572, <8 x i1> %3199, <8 x i1> zeroinitializer
  %3218 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3219 = extractelement <8 x i32> %3218, i32 %3184
  %3220 = select i1 %3204, i32 %3219, i32 %3180
  store i32 %3220, ptr %current.token, align 4
  %.splatinsert573 = insertelement <8 x i1> poison, i1 %3194, i64 0
  %.splat574 = shufflevector <8 x i1> %.splatinsert573, <8 x i1> poison, <8 x i32> zeroinitializer
  %3221 = select <8 x i1> %.splat574, <8 x i1> %3217, <8 x i1> %convergence.cascade.flow565
  %3222 = add i32 %convergence.cascade.depth566, 1
  %3223 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3221)
  %3224 = icmp ult i32 %3222, 8
  %3225 = and i1 %3223, %3224
  %3226 = and i1 %3194, %3225
  %convergence.parent.token575 = load i32, ptr %current.token, align 4
  %convergence.parent.present576 = icmp ne i32 %convergence.parent.token575, 0
  %3227 = and i1 %3226, %convergence.parent.present576
  br i1 %3227, label %convergence.cascade561, label %convergence.cascade.exit562

convergence.cascade.exit562:                      ; preds = %convergence.cascade561, %schedule.26
  %convergence.cascade.result577 = phi <8 x i1> [ %447, %schedule.26 ], [ %3221, %convergence.cascade561 ]
  %3228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result577)
  br i1 %3228, label %convergence.target.26.ready, label %scheduler.loop

convergence.target.26.ready:                      ; preds = %convergence.cascade.exit562
  %3229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result577)
  %3230 = bitcast <8 x i1> %convergence.cascade.result577 to i8
  %3231 = call i8 @llvm.cttz.i8(i8 %3230, i1 false)
  %3232 = zext i8 %3231 to i32
  %3233 = select i1 %3229, i32 %3232, i32 0
  %.spill.load578 = load <8 x i64>, ptr %.spill78, align 64
  %.spill.load579 = load i64, ptr %.spill18, align 4
  %.splatinsert580 = insertelement <8 x i64> poison, i64 %.spill.load579, i64 0
  %.splat581 = shufflevector <8 x i64> %.splatinsert580, <8 x i64> poison, <8 x i32> zeroinitializer
  %3234 = add <8 x i64> %.spill.load578, %.splat581
  %3235 = load volatile <8 x i64>, ptr %.spill83, align 64
  %3236 = select <8 x i1> %convergence.cascade.result577, <8 x i64> %3234, <8 x i64> %3235
  store volatile <8 x i64> %3236, ptr %.spill83, align 64
  %.spill.load582 = load <8 x i1>, ptr %.spill77, align 1
  %3237 = and <8 x i1> %convergence.cascade.result577, %.spill.load582
  %3238 = xor <8 x i1> %.spill.load582, splat (i1 true)
  %3239 = and <8 x i1> %convergence.cascade.result577, %3238
  %3240 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3237)
  %3241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3239)
  %3242 = and i1 %3240, %3241
  br i1 %3242, label %varying.divergent583, label %varying.coherent584

varying.divergent583:                             ; preds = %convergence.target.26.ready
  %3243 = load i32, ptr %current.token, align 4
  %3244 = icmp ne i32 %3243, 0
  %3245 = sub i32 %3243, 1
  %3246 = select i1 %3244, i32 %3245, i32 0
  %3247 = load i8, ptr %frame.active, align 1
  %3248 = trunc i32 %3246 to i8
  %3249 = shl i8 1, %3248
  %3250 = and i8 %3247, %3249
  %3251 = icmp ne i8 %3250, 0
  %3252 = load <8 x i32>, ptr %frame.static.id, align 32
  %3253 = extractelement <8 x i32> %3252, i32 %3246
  %3254 = icmp eq i32 %3253, 13
  %3255 = and i1 %3251, %3254
  %3256 = and i1 %3244, %3255
  %3257 = xor i1 %3256, true
  %3258 = and i1 true, %3257
  %3259 = xor i8 %3247, -1
  %3260 = icmp ne i8 %3259, 0
  %3261 = xor i1 %3260, true
  %3262 = and i1 %3258, %3261
  br i1 %3262, label %convergence.overflow.trap585, label %convergence.overflow.resume586

varying.coherent584:                              ; preds = %convergence.target.26.ready
  br i1 %3240, label %varying.coherent.true589, label %varying.coherent.false590

convergence.overflow.trap585:                     ; preds = %varying.divergent583
  call void @llvm.trap()
  unreachable

convergence.overflow.resume586:                   ; preds = %varying.divergent583
  %3263 = call i8 @llvm.cttz.i8(i8 %3259, i1 false)
  %3264 = zext i8 %3263 to i32
  %3265 = select i1 %3260, i32 %3264, i32 0
  %3266 = trunc i32 %3265 to i8
  %3267 = shl i8 1, %3266
  %3268 = or i8 %3247, %3267
  %3269 = select i1 %3258, i8 %3268, i8 %3247
  store i8 %3269, ptr %frame.active, align 1
  %3270 = load <8 x i32>, ptr %frame.static.id, align 32
  %3271 = extractelement <8 x i32> %3270, i32 %3265
  %3272 = select i1 %3258, i32 13, i32 %3271
  %3273 = load <8 x i32>, ptr %frame.static.id, align 32
  %3274 = insertelement <8 x i32> %3273, i32 %3272, i32 %3265
  store <8 x i32> %3274, ptr %frame.static.id, align 32
  %3275 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3276 = extractelement <8 x i32> %3275, i32 %3265
  %3277 = select i1 %3258, i32 %3243, i32 %3276
  %3278 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3279 = insertelement <8 x i32> %3278, i32 %3277, i32 %3265
  store <8 x i32> %3279, ptr %frame.parent.token, align 32
  %3280 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3265
  %3281 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3265
  %3282 = load <8 x i1>, ptr %3280, align 1
  %3283 = load <8 x i1>, ptr %3281, align 1
  %3284 = select i1 %3258, <8 x i1> %convergence.cascade.result577, <8 x i1> %3282
  store <8 x i1> %3284, ptr %3280, align 1
  %3285 = select i1 %3258, <8 x i1> zeroinitializer, <8 x i1> %3283
  store <8 x i1> %3285, ptr %3281, align 1
  %3286 = add i32 %3265, 1
  %3287 = select i1 %3256, i32 %3243, i32 %3286
  %3288 = select i1 true, i32 %3287, i32 %3243
  store i32 %3288, ptr %current.token, align 4
  %3289 = load <8 x float>, ptr %.slot84, align 32
  %3290 = select <8 x i1> %3239, <8 x float> zeroinitializer, <8 x float> %3289
  store <8 x float> %3290, ptr %.slot84, align 32
  %3291 = load i32, ptr %current.token, align 4
  %3292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3237)
  %3293 = load i32, ptr %ready.count, align 4
  %3294 = icmp uge i32 %3293, 8
  %3295 = and i1 %3292, %3294
  br i1 %3295, label %ready.overflow.trap587, label %ready.overflow.resume588

ready.overflow.trap587:                           ; preds = %convergence.overflow.resume586
  call void @llvm.trap()
  unreachable

ready.overflow.resume588:                         ; preds = %convergence.overflow.resume586
  %3296 = select i1 %3292, i32 %3293, i32 0
  %3297 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3296
  %3298 = load <8 x i1>, ptr %3297, align 1
  %3299 = select i1 %3292, <8 x i1> %3237, <8 x i1> %3298
  store <8 x i1> %3299, ptr %3297, align 1
  %3300 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3296
  %3301 = load i32, ptr %3300, align 4
  %3302 = select i1 %3292, i32 27, i32 %3301
  store i32 %3302, ptr %3300, align 4
  %3303 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3296
  %3304 = load i32, ptr %3303, align 4
  %3305 = select i1 %3292, i32 %3291, i32 %3304
  store i32 %3305, ptr %3303, align 4
  %3306 = add i32 %3293, 1
  %3307 = select i1 %3292, i32 %3306, i32 %3293
  store i32 %3307, ptr %ready.count, align 4
  %3308 = load <8 x i1>, ptr %runnable.mask, align 1
  %3309 = or <8 x i1> %3308, %3237
  store <8 x i1> %3309, ptr %runnable.mask, align 1
  store <8 x i1> %3239, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true589:                         ; preds = %varying.coherent584
  store <8 x i1> %convergence.cascade.result577, ptr %current.mask, align 1
  %3310 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result577)
  br i1 %3310, label %schedule.27, label %scheduler.loop

varying.coherent.false590:                        ; preds = %varying.coherent584
  %3311 = load <8 x float>, ptr %.slot84, align 32
  %3312 = select <8 x i1> %convergence.cascade.result577, <8 x float> zeroinitializer, <8 x float> %3311
  store <8 x float> %3312, ptr %.slot84, align 32
  store <8 x i1> %convergence.cascade.result577, ptr %current.mask, align 1
  %3313 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result577)
  br i1 %3313, label %schedule.28, label %scheduler.loop

convergence.cascade592:                           ; preds = %convergence.cascade592, %schedule.28
  %convergence.cascade.flow596 = phi <8 x i1> [ %461, %schedule.28 ], [ %3356, %convergence.cascade592 ]
  %convergence.cascade.depth597 = phi i32 [ 0, %schedule.28 ], [ %3357, %convergence.cascade592 ]
  %3314 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow596)
  %3315 = load i32, ptr %current.token, align 4
  %3316 = icmp ne i32 %3315, 0
  %3317 = and i1 %3314, %3316
  %3318 = sub i32 %3315, 1
  %3319 = select i1 %3317, i32 %3318, i32 0
  %3320 = load i8, ptr %frame.active, align 1
  %3321 = trunc i32 %3319 to i8
  %3322 = shl i8 1, %3321
  %3323 = and i8 %3320, %3322
  %3324 = icmp ne i8 %3323, 0
  %3325 = load <8 x i32>, ptr %frame.static.id, align 32
  %3326 = extractelement <8 x i32> %3325, i32 %3319
  %convergence.target.pointer598 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %3326
  %convergence.dynamic.target599 = load i32, ptr %convergence.target.pointer598, align 4
  %3327 = icmp eq i32 %convergence.dynamic.target599, 28
  %3328 = and i1 %3324, %3327
  %3329 = and i1 %3317, %3328
  %3330 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3319
  %3331 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3319
  %3332 = load <8 x i1>, ptr %3330, align 1
  %3333 = load <8 x i1>, ptr %3331, align 1
  %3334 = or <8 x i1> %3333, %convergence.cascade.flow596
  %3335 = load <8 x i1>, ptr %live.mask, align 1
  %3336 = and <8 x i1> %3332, %3335
  %3337 = icmp eq <8 x i1> %3334, %3336
  %3338 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3337)
  %3339 = and i1 %3329, %3338
  %3340 = select i1 %3339, <8 x i1> zeroinitializer, <8 x i1> %3334
  %3341 = select i1 %3329, <8 x i1> %3340, <8 x i1> %3333
  store <8 x i1> %3341, ptr %3331, align 1
  %3342 = select i1 %3339, <8 x i1> zeroinitializer, <8 x i1> %3332
  store <8 x i1> %3342, ptr %3330, align 1
  %3343 = trunc i32 %3319 to i8
  %3344 = shl i8 1, %3343
  %3345 = xor i8 %3344, -1
  %3346 = and i8 %3320, %3345
  %3347 = select i1 %3339, i8 %3346, i8 %3320
  store i8 %3347, ptr %frame.active, align 1
  %.splatinsert600 = insertelement <8 x i1> poison, i1 %3329, i64 0
  %.splat601 = shufflevector <8 x i1> %.splatinsert600, <8 x i1> poison, <8 x i32> zeroinitializer
  %3348 = and <8 x i1> %convergence.cascade.flow596, %.splat601
  %3349 = load <8 x i1>, ptr %runnable.mask, align 1
  %3350 = xor <8 x i1> %3348, splat (i1 true)
  %3351 = and <8 x i1> %3349, %3350
  store <8 x i1> %3351, ptr %runnable.mask, align 1
  %.splatinsert602 = insertelement <8 x i1> poison, i1 %3339, i64 0
  %.splat603 = shufflevector <8 x i1> %.splatinsert602, <8 x i1> poison, <8 x i32> zeroinitializer
  %3352 = select <8 x i1> %.splat603, <8 x i1> %3334, <8 x i1> zeroinitializer
  %3353 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3354 = extractelement <8 x i32> %3353, i32 %3319
  %3355 = select i1 %3339, i32 %3354, i32 %3315
  store i32 %3355, ptr %current.token, align 4
  %.splatinsert604 = insertelement <8 x i1> poison, i1 %3329, i64 0
  %.splat605 = shufflevector <8 x i1> %.splatinsert604, <8 x i1> poison, <8 x i32> zeroinitializer
  %3356 = select <8 x i1> %.splat605, <8 x i1> %3352, <8 x i1> %convergence.cascade.flow596
  %3357 = add i32 %convergence.cascade.depth597, 1
  %3358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3356)
  %3359 = icmp ult i32 %3357, 8
  %3360 = and i1 %3358, %3359
  %3361 = and i1 %3329, %3360
  %convergence.parent.token606 = load i32, ptr %current.token, align 4
  %convergence.parent.present607 = icmp ne i32 %convergence.parent.token606, 0
  %3362 = and i1 %3361, %convergence.parent.present607
  br i1 %3362, label %convergence.cascade592, label %convergence.cascade.exit593

convergence.cascade.exit593:                      ; preds = %convergence.cascade592, %schedule.28
  %convergence.cascade.result608 = phi <8 x i1> [ %461, %schedule.28 ], [ %3356, %convergence.cascade592 ]
  %3363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result608)
  br i1 %3363, label %convergence.target.28.ready, label %scheduler.loop

convergence.target.28.ready:                      ; preds = %convergence.cascade.exit593
  %3364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result608)
  %3365 = bitcast <8 x i1> %convergence.cascade.result608 to i8
  %3366 = call i8 @llvm.cttz.i8(i8 %3365, i1 false)
  %3367 = zext i8 %3366 to i32
  %3368 = select i1 %3364, i32 %3367, i32 0
  %.spill.load609 = load <8 x i64>, ptr %.spill78, align 64
  %.spill.load610 = load i64, ptr %.spill20, align 4
  %.splatinsert611 = insertelement <8 x i64> poison, i64 %.spill.load610, i64 0
  %.splat612 = shufflevector <8 x i64> %.splatinsert611, <8 x i64> poison, <8 x i32> zeroinitializer
  %3369 = add <8 x i64> %.spill.load609, %.splat612
  %3370 = load volatile <8 x i64>, ptr %.spill85, align 64
  %3371 = select <8 x i1> %convergence.cascade.result608, <8 x i64> %3369, <8 x i64> %3370
  store volatile <8 x i64> %3371, ptr %.spill85, align 64
  %.spill.load613 = load <8 x i1>, ptr %.spill77, align 1
  %3372 = and <8 x i1> %convergence.cascade.result608, %.spill.load613
  %3373 = xor <8 x i1> %.spill.load613, splat (i1 true)
  %3374 = and <8 x i1> %convergence.cascade.result608, %3373
  %3375 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3372)
  %3376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3374)
  %3377 = and i1 %3375, %3376
  br i1 %3377, label %varying.divergent614, label %varying.coherent615

varying.divergent614:                             ; preds = %convergence.target.28.ready
  %3378 = load i32, ptr %current.token, align 4
  %3379 = icmp ne i32 %3378, 0
  %3380 = sub i32 %3378, 1
  %3381 = select i1 %3379, i32 %3380, i32 0
  %3382 = load i8, ptr %frame.active, align 1
  %3383 = trunc i32 %3381 to i8
  %3384 = shl i8 1, %3383
  %3385 = and i8 %3382, %3384
  %3386 = icmp ne i8 %3385, 0
  %3387 = load <8 x i32>, ptr %frame.static.id, align 32
  %3388 = extractelement <8 x i32> %3387, i32 %3381
  %3389 = icmp eq i32 %3388, 14
  %3390 = and i1 %3386, %3389
  %3391 = and i1 %3379, %3390
  %3392 = xor i1 %3391, true
  %3393 = and i1 true, %3392
  %3394 = xor i8 %3382, -1
  %3395 = icmp ne i8 %3394, 0
  %3396 = xor i1 %3395, true
  %3397 = and i1 %3393, %3396
  br i1 %3397, label %convergence.overflow.trap616, label %convergence.overflow.resume617

varying.coherent615:                              ; preds = %convergence.target.28.ready
  br i1 %3375, label %varying.coherent.true620, label %varying.coherent.false621

convergence.overflow.trap616:                     ; preds = %varying.divergent614
  call void @llvm.trap()
  unreachable

convergence.overflow.resume617:                   ; preds = %varying.divergent614
  %3398 = call i8 @llvm.cttz.i8(i8 %3394, i1 false)
  %3399 = zext i8 %3398 to i32
  %3400 = select i1 %3395, i32 %3399, i32 0
  %3401 = trunc i32 %3400 to i8
  %3402 = shl i8 1, %3401
  %3403 = or i8 %3382, %3402
  %3404 = select i1 %3393, i8 %3403, i8 %3382
  store i8 %3404, ptr %frame.active, align 1
  %3405 = load <8 x i32>, ptr %frame.static.id, align 32
  %3406 = extractelement <8 x i32> %3405, i32 %3400
  %3407 = select i1 %3393, i32 14, i32 %3406
  %3408 = load <8 x i32>, ptr %frame.static.id, align 32
  %3409 = insertelement <8 x i32> %3408, i32 %3407, i32 %3400
  store <8 x i32> %3409, ptr %frame.static.id, align 32
  %3410 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3411 = extractelement <8 x i32> %3410, i32 %3400
  %3412 = select i1 %3393, i32 %3378, i32 %3411
  %3413 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3414 = insertelement <8 x i32> %3413, i32 %3412, i32 %3400
  store <8 x i32> %3414, ptr %frame.parent.token, align 32
  %3415 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3400
  %3416 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3400
  %3417 = load <8 x i1>, ptr %3415, align 1
  %3418 = load <8 x i1>, ptr %3416, align 1
  %3419 = select i1 %3393, <8 x i1> %convergence.cascade.result608, <8 x i1> %3417
  store <8 x i1> %3419, ptr %3415, align 1
  %3420 = select i1 %3393, <8 x i1> zeroinitializer, <8 x i1> %3418
  store <8 x i1> %3420, ptr %3416, align 1
  %3421 = add i32 %3400, 1
  %3422 = select i1 %3391, i32 %3378, i32 %3421
  %3423 = select i1 true, i32 %3422, i32 %3378
  store i32 %3423, ptr %current.token, align 4
  %3424 = load <8 x float>, ptr %.slot86, align 32
  %3425 = select <8 x i1> %3374, <8 x float> zeroinitializer, <8 x float> %3424
  store <8 x float> %3425, ptr %.slot86, align 32
  %3426 = load i32, ptr %current.token, align 4
  %3427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3372)
  %3428 = load i32, ptr %ready.count, align 4
  %3429 = icmp uge i32 %3428, 8
  %3430 = and i1 %3427, %3429
  br i1 %3430, label %ready.overflow.trap618, label %ready.overflow.resume619

ready.overflow.trap618:                           ; preds = %convergence.overflow.resume617
  call void @llvm.trap()
  unreachable

ready.overflow.resume619:                         ; preds = %convergence.overflow.resume617
  %3431 = select i1 %3427, i32 %3428, i32 0
  %3432 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3431
  %3433 = load <8 x i1>, ptr %3432, align 1
  %3434 = select i1 %3427, <8 x i1> %3372, <8 x i1> %3433
  store <8 x i1> %3434, ptr %3432, align 1
  %3435 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3431
  %3436 = load i32, ptr %3435, align 4
  %3437 = select i1 %3427, i32 29, i32 %3436
  store i32 %3437, ptr %3435, align 4
  %3438 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3431
  %3439 = load i32, ptr %3438, align 4
  %3440 = select i1 %3427, i32 %3426, i32 %3439
  store i32 %3440, ptr %3438, align 4
  %3441 = add i32 %3428, 1
  %3442 = select i1 %3427, i32 %3441, i32 %3428
  store i32 %3442, ptr %ready.count, align 4
  %3443 = load <8 x i1>, ptr %runnable.mask, align 1
  %3444 = or <8 x i1> %3443, %3372
  store <8 x i1> %3444, ptr %runnable.mask, align 1
  store <8 x i1> %3374, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true620:                         ; preds = %varying.coherent615
  store <8 x i1> %convergence.cascade.result608, ptr %current.mask, align 1
  %3445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result608)
  br i1 %3445, label %schedule.29, label %scheduler.loop

varying.coherent.false621:                        ; preds = %varying.coherent615
  %3446 = load <8 x float>, ptr %.slot86, align 32
  %3447 = select <8 x i1> %convergence.cascade.result608, <8 x float> zeroinitializer, <8 x float> %3446
  store <8 x float> %3447, ptr %.slot86, align 32
  store <8 x i1> %convergence.cascade.result608, ptr %current.mask, align 1
  %3448 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result608)
  br i1 %3448, label %schedule.30, label %scheduler.loop

convergence.cascade623:                           ; preds = %convergence.cascade623, %schedule.30
  %convergence.cascade.flow627 = phi <8 x i1> [ %475, %schedule.30 ], [ %3491, %convergence.cascade623 ]
  %convergence.cascade.depth628 = phi i32 [ 0, %schedule.30 ], [ %3492, %convergence.cascade623 ]
  %3449 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow627)
  %3450 = load i32, ptr %current.token, align 4
  %3451 = icmp ne i32 %3450, 0
  %3452 = and i1 %3449, %3451
  %3453 = sub i32 %3450, 1
  %3454 = select i1 %3452, i32 %3453, i32 0
  %3455 = load i8, ptr %frame.active, align 1
  %3456 = trunc i32 %3454 to i8
  %3457 = shl i8 1, %3456
  %3458 = and i8 %3455, %3457
  %3459 = icmp ne i8 %3458, 0
  %3460 = load <8 x i32>, ptr %frame.static.id, align 32
  %3461 = extractelement <8 x i32> %3460, i32 %3454
  %convergence.target.pointer629 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %3461
  %convergence.dynamic.target630 = load i32, ptr %convergence.target.pointer629, align 4
  %3462 = icmp eq i32 %convergence.dynamic.target630, 30
  %3463 = and i1 %3459, %3462
  %3464 = and i1 %3452, %3463
  %3465 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3454
  %3466 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3454
  %3467 = load <8 x i1>, ptr %3465, align 1
  %3468 = load <8 x i1>, ptr %3466, align 1
  %3469 = or <8 x i1> %3468, %convergence.cascade.flow627
  %3470 = load <8 x i1>, ptr %live.mask, align 1
  %3471 = and <8 x i1> %3467, %3470
  %3472 = icmp eq <8 x i1> %3469, %3471
  %3473 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3472)
  %3474 = and i1 %3464, %3473
  %3475 = select i1 %3474, <8 x i1> zeroinitializer, <8 x i1> %3469
  %3476 = select i1 %3464, <8 x i1> %3475, <8 x i1> %3468
  store <8 x i1> %3476, ptr %3466, align 1
  %3477 = select i1 %3474, <8 x i1> zeroinitializer, <8 x i1> %3467
  store <8 x i1> %3477, ptr %3465, align 1
  %3478 = trunc i32 %3454 to i8
  %3479 = shl i8 1, %3478
  %3480 = xor i8 %3479, -1
  %3481 = and i8 %3455, %3480
  %3482 = select i1 %3474, i8 %3481, i8 %3455
  store i8 %3482, ptr %frame.active, align 1
  %.splatinsert631 = insertelement <8 x i1> poison, i1 %3464, i64 0
  %.splat632 = shufflevector <8 x i1> %.splatinsert631, <8 x i1> poison, <8 x i32> zeroinitializer
  %3483 = and <8 x i1> %convergence.cascade.flow627, %.splat632
  %3484 = load <8 x i1>, ptr %runnable.mask, align 1
  %3485 = xor <8 x i1> %3483, splat (i1 true)
  %3486 = and <8 x i1> %3484, %3485
  store <8 x i1> %3486, ptr %runnable.mask, align 1
  %.splatinsert633 = insertelement <8 x i1> poison, i1 %3474, i64 0
  %.splat634 = shufflevector <8 x i1> %.splatinsert633, <8 x i1> poison, <8 x i32> zeroinitializer
  %3487 = select <8 x i1> %.splat634, <8 x i1> %3469, <8 x i1> zeroinitializer
  %3488 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3489 = extractelement <8 x i32> %3488, i32 %3454
  %3490 = select i1 %3474, i32 %3489, i32 %3450
  store i32 %3490, ptr %current.token, align 4
  %.splatinsert635 = insertelement <8 x i1> poison, i1 %3464, i64 0
  %.splat636 = shufflevector <8 x i1> %.splatinsert635, <8 x i1> poison, <8 x i32> zeroinitializer
  %3491 = select <8 x i1> %.splat636, <8 x i1> %3487, <8 x i1> %convergence.cascade.flow627
  %3492 = add i32 %convergence.cascade.depth628, 1
  %3493 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3491)
  %3494 = icmp ult i32 %3492, 8
  %3495 = and i1 %3493, %3494
  %3496 = and i1 %3464, %3495
  %convergence.parent.token637 = load i32, ptr %current.token, align 4
  %convergence.parent.present638 = icmp ne i32 %convergence.parent.token637, 0
  %3497 = and i1 %3496, %convergence.parent.present638
  br i1 %3497, label %convergence.cascade623, label %convergence.cascade.exit624

convergence.cascade.exit624:                      ; preds = %convergence.cascade623, %schedule.30
  %convergence.cascade.result639 = phi <8 x i1> [ %475, %schedule.30 ], [ %3491, %convergence.cascade623 ]
  %3498 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result639)
  br i1 %3498, label %convergence.target.30.ready, label %scheduler.loop

convergence.target.30.ready:                      ; preds = %convergence.cascade.exit624
  %3499 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result639)
  %3500 = bitcast <8 x i1> %convergence.cascade.result639 to i8
  %3501 = call i8 @llvm.cttz.i8(i8 %3500, i1 false)
  %3502 = zext i8 %3501 to i32
  %3503 = select i1 %3499, i32 %3502, i32 0
  %.spill.load640 = load <8 x i64>, ptr %.spill78, align 64
  %.spill.load641 = load volatile i64, ptr %.spill22, align 4
  %.splatinsert642 = insertelement <8 x i64> poison, i64 %.spill.load641, i64 0
  %.splat643 = shufflevector <8 x i64> %.splatinsert642, <8 x i64> poison, <8 x i32> zeroinitializer
  %3504 = add <8 x i64> %.spill.load640, %.splat643
  %3505 = load volatile <8 x i64>, ptr %.spill87, align 64
  %3506 = select <8 x i1> %convergence.cascade.result639, <8 x i64> %3504, <8 x i64> %3505
  store volatile <8 x i64> %3506, ptr %.spill87, align 64
  %.spill.load644 = load <8 x i1>, ptr %.spill77, align 1
  %3507 = and <8 x i1> %convergence.cascade.result639, %.spill.load644
  %3508 = xor <8 x i1> %.spill.load644, splat (i1 true)
  %3509 = and <8 x i1> %convergence.cascade.result639, %3508
  %3510 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3507)
  %3511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3509)
  %3512 = and i1 %3510, %3511
  br i1 %3512, label %varying.divergent645, label %varying.coherent646

varying.divergent645:                             ; preds = %convergence.target.30.ready
  %3513 = load i32, ptr %current.token, align 4
  %3514 = icmp ne i32 %3513, 0
  %3515 = sub i32 %3513, 1
  %3516 = select i1 %3514, i32 %3515, i32 0
  %3517 = load i8, ptr %frame.active, align 1
  %3518 = trunc i32 %3516 to i8
  %3519 = shl i8 1, %3518
  %3520 = and i8 %3517, %3519
  %3521 = icmp ne i8 %3520, 0
  %3522 = load <8 x i32>, ptr %frame.static.id, align 32
  %3523 = extractelement <8 x i32> %3522, i32 %3516
  %3524 = icmp eq i32 %3523, 15
  %3525 = and i1 %3521, %3524
  %3526 = and i1 %3514, %3525
  %3527 = xor i1 %3526, true
  %3528 = and i1 true, %3527
  %3529 = xor i8 %3517, -1
  %3530 = icmp ne i8 %3529, 0
  %3531 = xor i1 %3530, true
  %3532 = and i1 %3528, %3531
  br i1 %3532, label %convergence.overflow.trap647, label %convergence.overflow.resume648

varying.coherent646:                              ; preds = %convergence.target.30.ready
  br i1 %3510, label %varying.coherent.true651, label %varying.coherent.false652

convergence.overflow.trap647:                     ; preds = %varying.divergent645
  call void @llvm.trap()
  unreachable

convergence.overflow.resume648:                   ; preds = %varying.divergent645
  %3533 = call i8 @llvm.cttz.i8(i8 %3529, i1 false)
  %3534 = zext i8 %3533 to i32
  %3535 = select i1 %3530, i32 %3534, i32 0
  %3536 = trunc i32 %3535 to i8
  %3537 = shl i8 1, %3536
  %3538 = or i8 %3517, %3537
  %3539 = select i1 %3528, i8 %3538, i8 %3517
  store i8 %3539, ptr %frame.active, align 1
  %3540 = load <8 x i32>, ptr %frame.static.id, align 32
  %3541 = extractelement <8 x i32> %3540, i32 %3535
  %3542 = select i1 %3528, i32 15, i32 %3541
  %3543 = load <8 x i32>, ptr %frame.static.id, align 32
  %3544 = insertelement <8 x i32> %3543, i32 %3542, i32 %3535
  store <8 x i32> %3544, ptr %frame.static.id, align 32
  %3545 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3546 = extractelement <8 x i32> %3545, i32 %3535
  %3547 = select i1 %3528, i32 %3513, i32 %3546
  %3548 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3549 = insertelement <8 x i32> %3548, i32 %3547, i32 %3535
  store <8 x i32> %3549, ptr %frame.parent.token, align 32
  %3550 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3535
  %3551 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3535
  %3552 = load <8 x i1>, ptr %3550, align 1
  %3553 = load <8 x i1>, ptr %3551, align 1
  %3554 = select i1 %3528, <8 x i1> %convergence.cascade.result639, <8 x i1> %3552
  store <8 x i1> %3554, ptr %3550, align 1
  %3555 = select i1 %3528, <8 x i1> zeroinitializer, <8 x i1> %3553
  store <8 x i1> %3555, ptr %3551, align 1
  %3556 = add i32 %3535, 1
  %3557 = select i1 %3526, i32 %3513, i32 %3556
  %3558 = select i1 true, i32 %3557, i32 %3513
  store i32 %3558, ptr %current.token, align 4
  %3559 = load <8 x float>, ptr %.slot88, align 32
  %3560 = select <8 x i1> %3509, <8 x float> zeroinitializer, <8 x float> %3559
  store <8 x float> %3560, ptr %.slot88, align 32
  %3561 = load i32, ptr %current.token, align 4
  %3562 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3507)
  %3563 = load i32, ptr %ready.count, align 4
  %3564 = icmp uge i32 %3563, 8
  %3565 = and i1 %3562, %3564
  br i1 %3565, label %ready.overflow.trap649, label %ready.overflow.resume650

ready.overflow.trap649:                           ; preds = %convergence.overflow.resume648
  call void @llvm.trap()
  unreachable

ready.overflow.resume650:                         ; preds = %convergence.overflow.resume648
  %3566 = select i1 %3562, i32 %3563, i32 0
  %3567 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3566
  %3568 = load <8 x i1>, ptr %3567, align 1
  %3569 = select i1 %3562, <8 x i1> %3507, <8 x i1> %3568
  store <8 x i1> %3569, ptr %3567, align 1
  %3570 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3566
  %3571 = load i32, ptr %3570, align 4
  %3572 = select i1 %3562, i32 31, i32 %3571
  store i32 %3572, ptr %3570, align 4
  %3573 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3566
  %3574 = load i32, ptr %3573, align 4
  %3575 = select i1 %3562, i32 %3561, i32 %3574
  store i32 %3575, ptr %3573, align 4
  %3576 = add i32 %3563, 1
  %3577 = select i1 %3562, i32 %3576, i32 %3563
  store i32 %3577, ptr %ready.count, align 4
  %3578 = load <8 x i1>, ptr %runnable.mask, align 1
  %3579 = or <8 x i1> %3578, %3507
  store <8 x i1> %3579, ptr %runnable.mask, align 1
  store <8 x i1> %3509, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true651:                         ; preds = %varying.coherent646
  store <8 x i1> %convergence.cascade.result639, ptr %current.mask, align 1
  %3580 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result639)
  br i1 %3580, label %schedule.31, label %scheduler.loop

varying.coherent.false652:                        ; preds = %varying.coherent646
  %3581 = load <8 x float>, ptr %.slot88, align 32
  %3582 = select <8 x i1> %convergence.cascade.result639, <8 x float> zeroinitializer, <8 x float> %3581
  store <8 x float> %3582, ptr %.slot88, align 32
  store <8 x i1> %convergence.cascade.result639, ptr %current.mask, align 1
  %3583 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result639)
  br i1 %3583, label %schedule.32, label %scheduler.loop

convergence.cascade654:                           ; preds = %convergence.cascade654, %schedule.32
  %convergence.cascade.flow658 = phi <8 x i1> [ %489, %schedule.32 ], [ %3626, %convergence.cascade654 ]
  %convergence.cascade.depth659 = phi i32 [ 0, %schedule.32 ], [ %3627, %convergence.cascade654 ]
  %3584 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow658)
  %3585 = load i32, ptr %current.token, align 4
  %3586 = icmp ne i32 %3585, 0
  %3587 = and i1 %3584, %3586
  %3588 = sub i32 %3585, 1
  %3589 = select i1 %3587, i32 %3588, i32 0
  %3590 = load i8, ptr %frame.active, align 1
  %3591 = trunc i32 %3589 to i8
  %3592 = shl i8 1, %3591
  %3593 = and i8 %3590, %3592
  %3594 = icmp ne i8 %3593, 0
  %3595 = load <8 x i32>, ptr %frame.static.id, align 32
  %3596 = extractelement <8 x i32> %3595, i32 %3589
  %convergence.target.pointer660 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %3596
  %convergence.dynamic.target661 = load i32, ptr %convergence.target.pointer660, align 4
  %3597 = icmp eq i32 %convergence.dynamic.target661, 32
  %3598 = and i1 %3594, %3597
  %3599 = and i1 %3587, %3598
  %3600 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3589
  %3601 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3589
  %3602 = load <8 x i1>, ptr %3600, align 1
  %3603 = load <8 x i1>, ptr %3601, align 1
  %3604 = or <8 x i1> %3603, %convergence.cascade.flow658
  %3605 = load <8 x i1>, ptr %live.mask, align 1
  %3606 = and <8 x i1> %3602, %3605
  %3607 = icmp eq <8 x i1> %3604, %3606
  %3608 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3607)
  %3609 = and i1 %3599, %3608
  %3610 = select i1 %3609, <8 x i1> zeroinitializer, <8 x i1> %3604
  %3611 = select i1 %3599, <8 x i1> %3610, <8 x i1> %3603
  store <8 x i1> %3611, ptr %3601, align 1
  %3612 = select i1 %3609, <8 x i1> zeroinitializer, <8 x i1> %3602
  store <8 x i1> %3612, ptr %3600, align 1
  %3613 = trunc i32 %3589 to i8
  %3614 = shl i8 1, %3613
  %3615 = xor i8 %3614, -1
  %3616 = and i8 %3590, %3615
  %3617 = select i1 %3609, i8 %3616, i8 %3590
  store i8 %3617, ptr %frame.active, align 1
  %.splatinsert662 = insertelement <8 x i1> poison, i1 %3599, i64 0
  %.splat663 = shufflevector <8 x i1> %.splatinsert662, <8 x i1> poison, <8 x i32> zeroinitializer
  %3618 = and <8 x i1> %convergence.cascade.flow658, %.splat663
  %3619 = load <8 x i1>, ptr %runnable.mask, align 1
  %3620 = xor <8 x i1> %3618, splat (i1 true)
  %3621 = and <8 x i1> %3619, %3620
  store <8 x i1> %3621, ptr %runnable.mask, align 1
  %.splatinsert664 = insertelement <8 x i1> poison, i1 %3609, i64 0
  %.splat665 = shufflevector <8 x i1> %.splatinsert664, <8 x i1> poison, <8 x i32> zeroinitializer
  %3622 = select <8 x i1> %.splat665, <8 x i1> %3604, <8 x i1> zeroinitializer
  %3623 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3624 = extractelement <8 x i32> %3623, i32 %3589
  %3625 = select i1 %3609, i32 %3624, i32 %3585
  store i32 %3625, ptr %current.token, align 4
  %.splatinsert666 = insertelement <8 x i1> poison, i1 %3599, i64 0
  %.splat667 = shufflevector <8 x i1> %.splatinsert666, <8 x i1> poison, <8 x i32> zeroinitializer
  %3626 = select <8 x i1> %.splat667, <8 x i1> %3622, <8 x i1> %convergence.cascade.flow658
  %3627 = add i32 %convergence.cascade.depth659, 1
  %3628 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3626)
  %3629 = icmp ult i32 %3627, 8
  %3630 = and i1 %3628, %3629
  %3631 = and i1 %3599, %3630
  %convergence.parent.token668 = load i32, ptr %current.token, align 4
  %convergence.parent.present669 = icmp ne i32 %convergence.parent.token668, 0
  %3632 = and i1 %3631, %convergence.parent.present669
  br i1 %3632, label %convergence.cascade654, label %convergence.cascade.exit655

convergence.cascade.exit655:                      ; preds = %convergence.cascade654, %schedule.32
  %convergence.cascade.result670 = phi <8 x i1> [ %489, %schedule.32 ], [ %3626, %convergence.cascade654 ]
  %3633 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result670)
  br i1 %3633, label %convergence.target.32.ready, label %scheduler.loop

convergence.target.32.ready:                      ; preds = %convergence.cascade.exit655
  %3634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result670)
  %3635 = bitcast <8 x i1> %convergence.cascade.result670 to i8
  %3636 = call i8 @llvm.cttz.i8(i8 %3635, i1 false)
  %3637 = zext i8 %3636 to i32
  %3638 = select i1 %3634, i32 %3637, i32 0
  %.spill.load671 = load volatile <8 x i64>, ptr %.spill53, align 64
  %3639 = mul <8 x i64> %.spill.load671, splat (i64 4)
  %.spill.load672 = load i64, ptr %.spill10, align 4
  %.splatinsert673 = insertelement <8 x i64> poison, i64 %.spill.load672, i64 0
  %.splat674 = shufflevector <8 x i64> %.splatinsert673, <8 x i64> poison, <8 x i32> zeroinitializer
  %3640 = add <8 x i64> %3639, %.splat674
  %3641 = extractvalue { ptr, i64 } %25, 0
  %3642 = mul <8 x i64> %3640, splat (i64 4)
  %3643 = getelementptr i8, ptr %3641, <8 x i64> %3642
  %3644 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3643, <8 x i1> %convergence.cascade.result670, <8 x float> zeroinitializer)
  %3645 = load volatile <8 x float>, ptr %.spill89, align 32
  %3646 = select <8 x i1> %convergence.cascade.result670, <8 x float> %3644, <8 x float> %3645
  store volatile <8 x float> %3646, ptr %.spill89, align 32
  %.spill.load675 = load i64, ptr %.spill16, align 4
  %.splatinsert676 = insertelement <8 x i64> poison, i64 %.spill.load675, i64 0
  %.splat677 = shufflevector <8 x i64> %.splatinsert676, <8 x i64> poison, <8 x i32> zeroinitializer
  %3647 = add <8 x i64> %3639, %.splat677
  %3648 = extractvalue { ptr, i64 } %25, 0
  %3649 = mul <8 x i64> %3647, splat (i64 4)
  %3650 = getelementptr i8, ptr %3648, <8 x i64> %3649
  %3651 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3650, <8 x i1> %convergence.cascade.result670, <8 x float> zeroinitializer)
  %3652 = load volatile <8 x float>, ptr %.spill90, align 32
  %3653 = select <8 x i1> %convergence.cascade.result670, <8 x float> %3651, <8 x float> %3652
  store volatile <8 x float> %3653, ptr %.spill90, align 32
  %.spill.load678 = load i64, ptr %.spill18, align 4
  %.splatinsert679 = insertelement <8 x i64> poison, i64 %.spill.load678, i64 0
  %.splat680 = shufflevector <8 x i64> %.splatinsert679, <8 x i64> poison, <8 x i32> zeroinitializer
  %3654 = add <8 x i64> %3639, %.splat680
  %3655 = extractvalue { ptr, i64 } %25, 0
  %3656 = mul <8 x i64> %3654, splat (i64 4)
  %3657 = getelementptr i8, ptr %3655, <8 x i64> %3656
  %3658 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3657, <8 x i1> %convergence.cascade.result670, <8 x float> zeroinitializer)
  %3659 = load volatile <8 x float>, ptr %.spill91, align 32
  %3660 = select <8 x i1> %convergence.cascade.result670, <8 x float> %3658, <8 x float> %3659
  store volatile <8 x float> %3660, ptr %.spill91, align 32
  %.spill.load681 = load i64, ptr %.spill20, align 4
  %.splatinsert682 = insertelement <8 x i64> poison, i64 %.spill.load681, i64 0
  %.splat683 = shufflevector <8 x i64> %.splatinsert682, <8 x i64> poison, <8 x i32> zeroinitializer
  %3661 = add <8 x i64> %3639, %.splat683
  %3662 = extractvalue { ptr, i64 } %25, 0
  %3663 = mul <8 x i64> %3661, splat (i64 4)
  %3664 = getelementptr i8, ptr %3662, <8 x i64> %3663
  %3665 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3664, <8 x i1> %convergence.cascade.result670, <8 x float> zeroinitializer)
  %3666 = load volatile <8 x float>, ptr %.spill92, align 32
  %3667 = select <8 x i1> %convergence.cascade.result670, <8 x float> %3665, <8 x float> %3666
  store volatile <8 x float> %3667, ptr %.spill92, align 32
  %.spill.load684 = load volatile <8 x i64>, ptr %.spill60, align 64
  %3668 = mul <8 x i64> %.spill.load684, splat (i64 4)
  %3669 = load volatile <8 x i64>, ptr %.spill93, align 64
  %3670 = select <8 x i1> %convergence.cascade.result670, <8 x i64> %3668, <8 x i64> %3669
  store volatile <8 x i64> %3670, ptr %.spill93, align 64
  %.spill.load685 = load i64, ptr %.spill10, align 4
  %.splatinsert686 = insertelement <8 x i64> poison, i64 %.spill.load685, i64 0
  %.splat687 = shufflevector <8 x i64> %.splatinsert686, <8 x i64> poison, <8 x i32> zeroinitializer
  %3671 = add <8 x i64> %3668, %.splat687
  %3672 = load volatile <8 x i64>, ptr %.spill94, align 64
  %3673 = select <8 x i1> %convergence.cascade.result670, <8 x i64> %3671, <8 x i64> %3672
  store volatile <8 x i64> %3673, ptr %.spill94, align 64
  %.spill.load688 = load <8 x i1>, ptr %.spill62, align 1
  %3674 = and <8 x i1> %convergence.cascade.result670, %.spill.load688
  %3675 = xor <8 x i1> %.spill.load688, splat (i1 true)
  %3676 = and <8 x i1> %convergence.cascade.result670, %3675
  %3677 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3674)
  %3678 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3676)
  %3679 = and i1 %3677, %3678
  br i1 %3679, label %varying.divergent689, label %varying.coherent690

varying.divergent689:                             ; preds = %convergence.target.32.ready
  %3680 = load i32, ptr %current.token, align 4
  %3681 = icmp ne i32 %3680, 0
  %3682 = sub i32 %3680, 1
  %3683 = select i1 %3681, i32 %3682, i32 0
  %3684 = load i8, ptr %frame.active, align 1
  %3685 = trunc i32 %3683 to i8
  %3686 = shl i8 1, %3685
  %3687 = and i8 %3684, %3686
  %3688 = icmp ne i8 %3687, 0
  %3689 = load <8 x i32>, ptr %frame.static.id, align 32
  %3690 = extractelement <8 x i32> %3689, i32 %3683
  %3691 = icmp eq i32 %3690, 16
  %3692 = and i1 %3688, %3691
  %3693 = and i1 %3681, %3692
  %3694 = xor i1 %3693, true
  %3695 = and i1 true, %3694
  %3696 = xor i8 %3684, -1
  %3697 = icmp ne i8 %3696, 0
  %3698 = xor i1 %3697, true
  %3699 = and i1 %3695, %3698
  br i1 %3699, label %convergence.overflow.trap691, label %convergence.overflow.resume692

varying.coherent690:                              ; preds = %convergence.target.32.ready
  br i1 %3677, label %varying.coherent.true695, label %varying.coherent.false696

convergence.overflow.trap691:                     ; preds = %varying.divergent689
  call void @llvm.trap()
  unreachable

convergence.overflow.resume692:                   ; preds = %varying.divergent689
  %3700 = call i8 @llvm.cttz.i8(i8 %3696, i1 false)
  %3701 = zext i8 %3700 to i32
  %3702 = select i1 %3697, i32 %3701, i32 0
  %3703 = trunc i32 %3702 to i8
  %3704 = shl i8 1, %3703
  %3705 = or i8 %3684, %3704
  %3706 = select i1 %3695, i8 %3705, i8 %3684
  store i8 %3706, ptr %frame.active, align 1
  %3707 = load <8 x i32>, ptr %frame.static.id, align 32
  %3708 = extractelement <8 x i32> %3707, i32 %3702
  %3709 = select i1 %3695, i32 16, i32 %3708
  %3710 = load <8 x i32>, ptr %frame.static.id, align 32
  %3711 = insertelement <8 x i32> %3710, i32 %3709, i32 %3702
  store <8 x i32> %3711, ptr %frame.static.id, align 32
  %3712 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3713 = extractelement <8 x i32> %3712, i32 %3702
  %3714 = select i1 %3695, i32 %3680, i32 %3713
  %3715 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3716 = insertelement <8 x i32> %3715, i32 %3714, i32 %3702
  store <8 x i32> %3716, ptr %frame.parent.token, align 32
  %3717 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3702
  %3718 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3702
  %3719 = load <8 x i1>, ptr %3717, align 1
  %3720 = load <8 x i1>, ptr %3718, align 1
  %3721 = select i1 %3695, <8 x i1> %convergence.cascade.result670, <8 x i1> %3719
  store <8 x i1> %3721, ptr %3717, align 1
  %3722 = select i1 %3695, <8 x i1> zeroinitializer, <8 x i1> %3720
  store <8 x i1> %3722, ptr %3718, align 1
  %3723 = add i32 %3702, 1
  %3724 = select i1 %3693, i32 %3680, i32 %3723
  %3725 = select i1 true, i32 %3724, i32 %3680
  store i32 %3725, ptr %current.token, align 4
  %3726 = load <8 x float>, ptr %.slot95, align 32
  %3727 = select <8 x i1> %3676, <8 x float> zeroinitializer, <8 x float> %3726
  store <8 x float> %3727, ptr %.slot95, align 32
  %3728 = load i32, ptr %current.token, align 4
  %3729 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3674)
  %3730 = load i32, ptr %ready.count, align 4
  %3731 = icmp uge i32 %3730, 8
  %3732 = and i1 %3729, %3731
  br i1 %3732, label %ready.overflow.trap693, label %ready.overflow.resume694

ready.overflow.trap693:                           ; preds = %convergence.overflow.resume692
  call void @llvm.trap()
  unreachable

ready.overflow.resume694:                         ; preds = %convergence.overflow.resume692
  %3733 = select i1 %3729, i32 %3730, i32 0
  %3734 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3733
  %3735 = load <8 x i1>, ptr %3734, align 1
  %3736 = select i1 %3729, <8 x i1> %3674, <8 x i1> %3735
  store <8 x i1> %3736, ptr %3734, align 1
  %3737 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3733
  %3738 = load i32, ptr %3737, align 4
  %3739 = select i1 %3729, i32 33, i32 %3738
  store i32 %3739, ptr %3737, align 4
  %3740 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3733
  %3741 = load i32, ptr %3740, align 4
  %3742 = select i1 %3729, i32 %3728, i32 %3741
  store i32 %3742, ptr %3740, align 4
  %3743 = add i32 %3730, 1
  %3744 = select i1 %3729, i32 %3743, i32 %3730
  store i32 %3744, ptr %ready.count, align 4
  %3745 = load <8 x i1>, ptr %runnable.mask, align 1
  %3746 = or <8 x i1> %3745, %3674
  store <8 x i1> %3746, ptr %runnable.mask, align 1
  store <8 x i1> %3676, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true695:                         ; preds = %varying.coherent690
  store <8 x i1> %convergence.cascade.result670, ptr %current.mask, align 1
  %3747 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result670)
  br i1 %3747, label %schedule.33, label %scheduler.loop

varying.coherent.false696:                        ; preds = %varying.coherent690
  %3748 = load <8 x float>, ptr %.slot95, align 32
  %3749 = select <8 x i1> %convergence.cascade.result670, <8 x float> zeroinitializer, <8 x float> %3748
  store <8 x float> %3749, ptr %.slot95, align 32
  store <8 x i1> %convergence.cascade.result670, ptr %current.mask, align 1
  %3750 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result670)
  br i1 %3750, label %schedule.34, label %scheduler.loop

convergence.cascade698:                           ; preds = %convergence.cascade698, %schedule.34
  %convergence.cascade.flow702 = phi <8 x i1> [ %503, %schedule.34 ], [ %3793, %convergence.cascade698 ]
  %convergence.cascade.depth703 = phi i32 [ 0, %schedule.34 ], [ %3794, %convergence.cascade698 ]
  %3751 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow702)
  %3752 = load i32, ptr %current.token, align 4
  %3753 = icmp ne i32 %3752, 0
  %3754 = and i1 %3751, %3753
  %3755 = sub i32 %3752, 1
  %3756 = select i1 %3754, i32 %3755, i32 0
  %3757 = load i8, ptr %frame.active, align 1
  %3758 = trunc i32 %3756 to i8
  %3759 = shl i8 1, %3758
  %3760 = and i8 %3757, %3759
  %3761 = icmp ne i8 %3760, 0
  %3762 = load <8 x i32>, ptr %frame.static.id, align 32
  %3763 = extractelement <8 x i32> %3762, i32 %3756
  %convergence.target.pointer704 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %3763
  %convergence.dynamic.target705 = load i32, ptr %convergence.target.pointer704, align 4
  %3764 = icmp eq i32 %convergence.dynamic.target705, 34
  %3765 = and i1 %3761, %3764
  %3766 = and i1 %3754, %3765
  %3767 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3756
  %3768 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3756
  %3769 = load <8 x i1>, ptr %3767, align 1
  %3770 = load <8 x i1>, ptr %3768, align 1
  %3771 = or <8 x i1> %3770, %convergence.cascade.flow702
  %3772 = load <8 x i1>, ptr %live.mask, align 1
  %3773 = and <8 x i1> %3769, %3772
  %3774 = icmp eq <8 x i1> %3771, %3773
  %3775 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3774)
  %3776 = and i1 %3766, %3775
  %3777 = select i1 %3776, <8 x i1> zeroinitializer, <8 x i1> %3771
  %3778 = select i1 %3766, <8 x i1> %3777, <8 x i1> %3770
  store <8 x i1> %3778, ptr %3768, align 1
  %3779 = select i1 %3776, <8 x i1> zeroinitializer, <8 x i1> %3769
  store <8 x i1> %3779, ptr %3767, align 1
  %3780 = trunc i32 %3756 to i8
  %3781 = shl i8 1, %3780
  %3782 = xor i8 %3781, -1
  %3783 = and i8 %3757, %3782
  %3784 = select i1 %3776, i8 %3783, i8 %3757
  store i8 %3784, ptr %frame.active, align 1
  %.splatinsert706 = insertelement <8 x i1> poison, i1 %3766, i64 0
  %.splat707 = shufflevector <8 x i1> %.splatinsert706, <8 x i1> poison, <8 x i32> zeroinitializer
  %3785 = and <8 x i1> %convergence.cascade.flow702, %.splat707
  %3786 = load <8 x i1>, ptr %runnable.mask, align 1
  %3787 = xor <8 x i1> %3785, splat (i1 true)
  %3788 = and <8 x i1> %3786, %3787
  store <8 x i1> %3788, ptr %runnable.mask, align 1
  %.splatinsert708 = insertelement <8 x i1> poison, i1 %3776, i64 0
  %.splat709 = shufflevector <8 x i1> %.splatinsert708, <8 x i1> poison, <8 x i32> zeroinitializer
  %3789 = select <8 x i1> %.splat709, <8 x i1> %3771, <8 x i1> zeroinitializer
  %3790 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3791 = extractelement <8 x i32> %3790, i32 %3756
  %3792 = select i1 %3776, i32 %3791, i32 %3752
  store i32 %3792, ptr %current.token, align 4
  %.splatinsert710 = insertelement <8 x i1> poison, i1 %3766, i64 0
  %.splat711 = shufflevector <8 x i1> %.splatinsert710, <8 x i1> poison, <8 x i32> zeroinitializer
  %3793 = select <8 x i1> %.splat711, <8 x i1> %3789, <8 x i1> %convergence.cascade.flow702
  %3794 = add i32 %convergence.cascade.depth703, 1
  %3795 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3793)
  %3796 = icmp ult i32 %3794, 8
  %3797 = and i1 %3795, %3796
  %3798 = and i1 %3766, %3797
  %convergence.parent.token712 = load i32, ptr %current.token, align 4
  %convergence.parent.present713 = icmp ne i32 %convergence.parent.token712, 0
  %3799 = and i1 %3798, %convergence.parent.present713
  br i1 %3799, label %convergence.cascade698, label %convergence.cascade.exit699

convergence.cascade.exit699:                      ; preds = %convergence.cascade698, %schedule.34
  %convergence.cascade.result714 = phi <8 x i1> [ %503, %schedule.34 ], [ %3793, %convergence.cascade698 ]
  %3800 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result714)
  br i1 %3800, label %convergence.target.34.ready, label %scheduler.loop

convergence.target.34.ready:                      ; preds = %convergence.cascade.exit699
  %3801 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result714)
  %3802 = bitcast <8 x i1> %convergence.cascade.result714 to i8
  %3803 = call i8 @llvm.cttz.i8(i8 %3802, i1 false)
  %3804 = zext i8 %3803 to i32
  %3805 = select i1 %3801, i32 %3804, i32 0
  %.spill.load715 = load volatile <8 x i64>, ptr %.spill93, align 64
  %.spill.load716 = load i64, ptr %.spill16, align 4
  %.splatinsert717 = insertelement <8 x i64> poison, i64 %.spill.load716, i64 0
  %.splat718 = shufflevector <8 x i64> %.splatinsert717, <8 x i64> poison, <8 x i32> zeroinitializer
  %3806 = add <8 x i64> %.spill.load715, %.splat718
  %3807 = load volatile <8 x i64>, ptr %.spill96, align 64
  %3808 = select <8 x i1> %convergence.cascade.result714, <8 x i64> %3806, <8 x i64> %3807
  store volatile <8 x i64> %3808, ptr %.spill96, align 64
  %.spill.load719 = load <8 x i1>, ptr %.spill62, align 1
  %3809 = and <8 x i1> %convergence.cascade.result714, %.spill.load719
  %3810 = xor <8 x i1> %.spill.load719, splat (i1 true)
  %3811 = and <8 x i1> %convergence.cascade.result714, %3810
  %3812 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3809)
  %3813 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3811)
  %3814 = and i1 %3812, %3813
  br i1 %3814, label %varying.divergent720, label %varying.coherent721

varying.divergent720:                             ; preds = %convergence.target.34.ready
  %3815 = load i32, ptr %current.token, align 4
  %3816 = icmp ne i32 %3815, 0
  %3817 = sub i32 %3815, 1
  %3818 = select i1 %3816, i32 %3817, i32 0
  %3819 = load i8, ptr %frame.active, align 1
  %3820 = trunc i32 %3818 to i8
  %3821 = shl i8 1, %3820
  %3822 = and i8 %3819, %3821
  %3823 = icmp ne i8 %3822, 0
  %3824 = load <8 x i32>, ptr %frame.static.id, align 32
  %3825 = extractelement <8 x i32> %3824, i32 %3818
  %3826 = icmp eq i32 %3825, 17
  %3827 = and i1 %3823, %3826
  %3828 = and i1 %3816, %3827
  %3829 = xor i1 %3828, true
  %3830 = and i1 true, %3829
  %3831 = xor i8 %3819, -1
  %3832 = icmp ne i8 %3831, 0
  %3833 = xor i1 %3832, true
  %3834 = and i1 %3830, %3833
  br i1 %3834, label %convergence.overflow.trap722, label %convergence.overflow.resume723

varying.coherent721:                              ; preds = %convergence.target.34.ready
  br i1 %3812, label %varying.coherent.true726, label %varying.coherent.false727

convergence.overflow.trap722:                     ; preds = %varying.divergent720
  call void @llvm.trap()
  unreachable

convergence.overflow.resume723:                   ; preds = %varying.divergent720
  %3835 = call i8 @llvm.cttz.i8(i8 %3831, i1 false)
  %3836 = zext i8 %3835 to i32
  %3837 = select i1 %3832, i32 %3836, i32 0
  %3838 = trunc i32 %3837 to i8
  %3839 = shl i8 1, %3838
  %3840 = or i8 %3819, %3839
  %3841 = select i1 %3830, i8 %3840, i8 %3819
  store i8 %3841, ptr %frame.active, align 1
  %3842 = load <8 x i32>, ptr %frame.static.id, align 32
  %3843 = extractelement <8 x i32> %3842, i32 %3837
  %3844 = select i1 %3830, i32 17, i32 %3843
  %3845 = load <8 x i32>, ptr %frame.static.id, align 32
  %3846 = insertelement <8 x i32> %3845, i32 %3844, i32 %3837
  store <8 x i32> %3846, ptr %frame.static.id, align 32
  %3847 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3848 = extractelement <8 x i32> %3847, i32 %3837
  %3849 = select i1 %3830, i32 %3815, i32 %3848
  %3850 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3851 = insertelement <8 x i32> %3850, i32 %3849, i32 %3837
  store <8 x i32> %3851, ptr %frame.parent.token, align 32
  %3852 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3837
  %3853 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3837
  %3854 = load <8 x i1>, ptr %3852, align 1
  %3855 = load <8 x i1>, ptr %3853, align 1
  %3856 = select i1 %3830, <8 x i1> %convergence.cascade.result714, <8 x i1> %3854
  store <8 x i1> %3856, ptr %3852, align 1
  %3857 = select i1 %3830, <8 x i1> zeroinitializer, <8 x i1> %3855
  store <8 x i1> %3857, ptr %3853, align 1
  %3858 = add i32 %3837, 1
  %3859 = select i1 %3828, i32 %3815, i32 %3858
  %3860 = select i1 true, i32 %3859, i32 %3815
  store i32 %3860, ptr %current.token, align 4
  %3861 = load <8 x float>, ptr %.slot97, align 32
  %3862 = select <8 x i1> %3811, <8 x float> zeroinitializer, <8 x float> %3861
  store <8 x float> %3862, ptr %.slot97, align 32
  %3863 = load i32, ptr %current.token, align 4
  %3864 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3809)
  %3865 = load i32, ptr %ready.count, align 4
  %3866 = icmp uge i32 %3865, 8
  %3867 = and i1 %3864, %3866
  br i1 %3867, label %ready.overflow.trap724, label %ready.overflow.resume725

ready.overflow.trap724:                           ; preds = %convergence.overflow.resume723
  call void @llvm.trap()
  unreachable

ready.overflow.resume725:                         ; preds = %convergence.overflow.resume723
  %3868 = select i1 %3864, i32 %3865, i32 0
  %3869 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3868
  %3870 = load <8 x i1>, ptr %3869, align 1
  %3871 = select i1 %3864, <8 x i1> %3809, <8 x i1> %3870
  store <8 x i1> %3871, ptr %3869, align 1
  %3872 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3868
  %3873 = load i32, ptr %3872, align 4
  %3874 = select i1 %3864, i32 35, i32 %3873
  store i32 %3874, ptr %3872, align 4
  %3875 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3868
  %3876 = load i32, ptr %3875, align 4
  %3877 = select i1 %3864, i32 %3863, i32 %3876
  store i32 %3877, ptr %3875, align 4
  %3878 = add i32 %3865, 1
  %3879 = select i1 %3864, i32 %3878, i32 %3865
  store i32 %3879, ptr %ready.count, align 4
  %3880 = load <8 x i1>, ptr %runnable.mask, align 1
  %3881 = or <8 x i1> %3880, %3809
  store <8 x i1> %3881, ptr %runnable.mask, align 1
  store <8 x i1> %3811, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true726:                         ; preds = %varying.coherent721
  store <8 x i1> %convergence.cascade.result714, ptr %current.mask, align 1
  %3882 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result714)
  br i1 %3882, label %schedule.35, label %scheduler.loop

varying.coherent.false727:                        ; preds = %varying.coherent721
  %3883 = load <8 x float>, ptr %.slot97, align 32
  %3884 = select <8 x i1> %convergence.cascade.result714, <8 x float> zeroinitializer, <8 x float> %3883
  store <8 x float> %3884, ptr %.slot97, align 32
  store <8 x i1> %convergence.cascade.result714, ptr %current.mask, align 1
  %3885 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result714)
  br i1 %3885, label %schedule.36, label %scheduler.loop

convergence.cascade729:                           ; preds = %convergence.cascade729, %schedule.36
  %convergence.cascade.flow733 = phi <8 x i1> [ %517, %schedule.36 ], [ %3928, %convergence.cascade729 ]
  %convergence.cascade.depth734 = phi i32 [ 0, %schedule.36 ], [ %3929, %convergence.cascade729 ]
  %3886 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow733)
  %3887 = load i32, ptr %current.token, align 4
  %3888 = icmp ne i32 %3887, 0
  %3889 = and i1 %3886, %3888
  %3890 = sub i32 %3887, 1
  %3891 = select i1 %3889, i32 %3890, i32 0
  %3892 = load i8, ptr %frame.active, align 1
  %3893 = trunc i32 %3891 to i8
  %3894 = shl i8 1, %3893
  %3895 = and i8 %3892, %3894
  %3896 = icmp ne i8 %3895, 0
  %3897 = load <8 x i32>, ptr %frame.static.id, align 32
  %3898 = extractelement <8 x i32> %3897, i32 %3891
  %convergence.target.pointer735 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %3898
  %convergence.dynamic.target736 = load i32, ptr %convergence.target.pointer735, align 4
  %3899 = icmp eq i32 %convergence.dynamic.target736, 36
  %3900 = and i1 %3896, %3899
  %3901 = and i1 %3889, %3900
  %3902 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3891
  %3903 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3891
  %3904 = load <8 x i1>, ptr %3902, align 1
  %3905 = load <8 x i1>, ptr %3903, align 1
  %3906 = or <8 x i1> %3905, %convergence.cascade.flow733
  %3907 = load <8 x i1>, ptr %live.mask, align 1
  %3908 = and <8 x i1> %3904, %3907
  %3909 = icmp eq <8 x i1> %3906, %3908
  %3910 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3909)
  %3911 = and i1 %3901, %3910
  %3912 = select i1 %3911, <8 x i1> zeroinitializer, <8 x i1> %3906
  %3913 = select i1 %3901, <8 x i1> %3912, <8 x i1> %3905
  store <8 x i1> %3913, ptr %3903, align 1
  %3914 = select i1 %3911, <8 x i1> zeroinitializer, <8 x i1> %3904
  store <8 x i1> %3914, ptr %3902, align 1
  %3915 = trunc i32 %3891 to i8
  %3916 = shl i8 1, %3915
  %3917 = xor i8 %3916, -1
  %3918 = and i8 %3892, %3917
  %3919 = select i1 %3911, i8 %3918, i8 %3892
  store i8 %3919, ptr %frame.active, align 1
  %.splatinsert737 = insertelement <8 x i1> poison, i1 %3901, i64 0
  %.splat738 = shufflevector <8 x i1> %.splatinsert737, <8 x i1> poison, <8 x i32> zeroinitializer
  %3920 = and <8 x i1> %convergence.cascade.flow733, %.splat738
  %3921 = load <8 x i1>, ptr %runnable.mask, align 1
  %3922 = xor <8 x i1> %3920, splat (i1 true)
  %3923 = and <8 x i1> %3921, %3922
  store <8 x i1> %3923, ptr %runnable.mask, align 1
  %.splatinsert739 = insertelement <8 x i1> poison, i1 %3911, i64 0
  %.splat740 = shufflevector <8 x i1> %.splatinsert739, <8 x i1> poison, <8 x i32> zeroinitializer
  %3924 = select <8 x i1> %.splat740, <8 x i1> %3906, <8 x i1> zeroinitializer
  %3925 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3926 = extractelement <8 x i32> %3925, i32 %3891
  %3927 = select i1 %3911, i32 %3926, i32 %3887
  store i32 %3927, ptr %current.token, align 4
  %.splatinsert741 = insertelement <8 x i1> poison, i1 %3901, i64 0
  %.splat742 = shufflevector <8 x i1> %.splatinsert741, <8 x i1> poison, <8 x i32> zeroinitializer
  %3928 = select <8 x i1> %.splat742, <8 x i1> %3924, <8 x i1> %convergence.cascade.flow733
  %3929 = add i32 %convergence.cascade.depth734, 1
  %3930 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3928)
  %3931 = icmp ult i32 %3929, 8
  %3932 = and i1 %3930, %3931
  %3933 = and i1 %3901, %3932
  %convergence.parent.token743 = load i32, ptr %current.token, align 4
  %convergence.parent.present744 = icmp ne i32 %convergence.parent.token743, 0
  %3934 = and i1 %3933, %convergence.parent.present744
  br i1 %3934, label %convergence.cascade729, label %convergence.cascade.exit730

convergence.cascade.exit730:                      ; preds = %convergence.cascade729, %schedule.36
  %convergence.cascade.result745 = phi <8 x i1> [ %517, %schedule.36 ], [ %3928, %convergence.cascade729 ]
  %3935 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result745)
  br i1 %3935, label %convergence.target.36.ready, label %scheduler.loop

convergence.target.36.ready:                      ; preds = %convergence.cascade.exit730
  %3936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result745)
  %3937 = bitcast <8 x i1> %convergence.cascade.result745 to i8
  %3938 = call i8 @llvm.cttz.i8(i8 %3937, i1 false)
  %3939 = zext i8 %3938 to i32
  %3940 = select i1 %3936, i32 %3939, i32 0
  %.spill.load746 = load volatile <8 x i64>, ptr %.spill93, align 64
  %.spill.load747 = load i64, ptr %.spill18, align 4
  %.splatinsert748 = insertelement <8 x i64> poison, i64 %.spill.load747, i64 0
  %.splat749 = shufflevector <8 x i64> %.splatinsert748, <8 x i64> poison, <8 x i32> zeroinitializer
  %3941 = add <8 x i64> %.spill.load746, %.splat749
  %3942 = load volatile <8 x i64>, ptr %.spill98, align 64
  %3943 = select <8 x i1> %convergence.cascade.result745, <8 x i64> %3941, <8 x i64> %3942
  store volatile <8 x i64> %3943, ptr %.spill98, align 64
  %.spill.load750 = load <8 x i1>, ptr %.spill62, align 1
  %3944 = and <8 x i1> %convergence.cascade.result745, %.spill.load750
  %3945 = xor <8 x i1> %.spill.load750, splat (i1 true)
  %3946 = and <8 x i1> %convergence.cascade.result745, %3945
  %3947 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3944)
  %3948 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3946)
  %3949 = and i1 %3947, %3948
  br i1 %3949, label %varying.divergent751, label %varying.coherent752

varying.divergent751:                             ; preds = %convergence.target.36.ready
  %3950 = load i32, ptr %current.token, align 4
  %3951 = icmp ne i32 %3950, 0
  %3952 = sub i32 %3950, 1
  %3953 = select i1 %3951, i32 %3952, i32 0
  %3954 = load i8, ptr %frame.active, align 1
  %3955 = trunc i32 %3953 to i8
  %3956 = shl i8 1, %3955
  %3957 = and i8 %3954, %3956
  %3958 = icmp ne i8 %3957, 0
  %3959 = load <8 x i32>, ptr %frame.static.id, align 32
  %3960 = extractelement <8 x i32> %3959, i32 %3953
  %3961 = icmp eq i32 %3960, 18
  %3962 = and i1 %3958, %3961
  %3963 = and i1 %3951, %3962
  %3964 = xor i1 %3963, true
  %3965 = and i1 true, %3964
  %3966 = xor i8 %3954, -1
  %3967 = icmp ne i8 %3966, 0
  %3968 = xor i1 %3967, true
  %3969 = and i1 %3965, %3968
  br i1 %3969, label %convergence.overflow.trap753, label %convergence.overflow.resume754

varying.coherent752:                              ; preds = %convergence.target.36.ready
  br i1 %3947, label %varying.coherent.true757, label %varying.coherent.false758

convergence.overflow.trap753:                     ; preds = %varying.divergent751
  call void @llvm.trap()
  unreachable

convergence.overflow.resume754:                   ; preds = %varying.divergent751
  %3970 = call i8 @llvm.cttz.i8(i8 %3966, i1 false)
  %3971 = zext i8 %3970 to i32
  %3972 = select i1 %3967, i32 %3971, i32 0
  %3973 = trunc i32 %3972 to i8
  %3974 = shl i8 1, %3973
  %3975 = or i8 %3954, %3974
  %3976 = select i1 %3965, i8 %3975, i8 %3954
  store i8 %3976, ptr %frame.active, align 1
  %3977 = load <8 x i32>, ptr %frame.static.id, align 32
  %3978 = extractelement <8 x i32> %3977, i32 %3972
  %3979 = select i1 %3965, i32 18, i32 %3978
  %3980 = load <8 x i32>, ptr %frame.static.id, align 32
  %3981 = insertelement <8 x i32> %3980, i32 %3979, i32 %3972
  store <8 x i32> %3981, ptr %frame.static.id, align 32
  %3982 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3983 = extractelement <8 x i32> %3982, i32 %3972
  %3984 = select i1 %3965, i32 %3950, i32 %3983
  %3985 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3986 = insertelement <8 x i32> %3985, i32 %3984, i32 %3972
  store <8 x i32> %3986, ptr %frame.parent.token, align 32
  %3987 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3972
  %3988 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3972
  %3989 = load <8 x i1>, ptr %3987, align 1
  %3990 = load <8 x i1>, ptr %3988, align 1
  %3991 = select i1 %3965, <8 x i1> %convergence.cascade.result745, <8 x i1> %3989
  store <8 x i1> %3991, ptr %3987, align 1
  %3992 = select i1 %3965, <8 x i1> zeroinitializer, <8 x i1> %3990
  store <8 x i1> %3992, ptr %3988, align 1
  %3993 = add i32 %3972, 1
  %3994 = select i1 %3963, i32 %3950, i32 %3993
  %3995 = select i1 true, i32 %3994, i32 %3950
  store i32 %3995, ptr %current.token, align 4
  %3996 = load <8 x float>, ptr %.slot99, align 32
  %3997 = select <8 x i1> %3946, <8 x float> zeroinitializer, <8 x float> %3996
  store <8 x float> %3997, ptr %.slot99, align 32
  %3998 = load i32, ptr %current.token, align 4
  %3999 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3944)
  %4000 = load i32, ptr %ready.count, align 4
  %4001 = icmp uge i32 %4000, 8
  %4002 = and i1 %3999, %4001
  br i1 %4002, label %ready.overflow.trap755, label %ready.overflow.resume756

ready.overflow.trap755:                           ; preds = %convergence.overflow.resume754
  call void @llvm.trap()
  unreachable

ready.overflow.resume756:                         ; preds = %convergence.overflow.resume754
  %4003 = select i1 %3999, i32 %4000, i32 0
  %4004 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4003
  %4005 = load <8 x i1>, ptr %4004, align 1
  %4006 = select i1 %3999, <8 x i1> %3944, <8 x i1> %4005
  store <8 x i1> %4006, ptr %4004, align 1
  %4007 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4003
  %4008 = load i32, ptr %4007, align 4
  %4009 = select i1 %3999, i32 37, i32 %4008
  store i32 %4009, ptr %4007, align 4
  %4010 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4003
  %4011 = load i32, ptr %4010, align 4
  %4012 = select i1 %3999, i32 %3998, i32 %4011
  store i32 %4012, ptr %4010, align 4
  %4013 = add i32 %4000, 1
  %4014 = select i1 %3999, i32 %4013, i32 %4000
  store i32 %4014, ptr %ready.count, align 4
  %4015 = load <8 x i1>, ptr %runnable.mask, align 1
  %4016 = or <8 x i1> %4015, %3944
  store <8 x i1> %4016, ptr %runnable.mask, align 1
  store <8 x i1> %3946, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true757:                         ; preds = %varying.coherent752
  store <8 x i1> %convergence.cascade.result745, ptr %current.mask, align 1
  %4017 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result745)
  br i1 %4017, label %schedule.37, label %scheduler.loop

varying.coherent.false758:                        ; preds = %varying.coherent752
  %4018 = load <8 x float>, ptr %.slot99, align 32
  %4019 = select <8 x i1> %convergence.cascade.result745, <8 x float> zeroinitializer, <8 x float> %4018
  store <8 x float> %4019, ptr %.slot99, align 32
  store <8 x i1> %convergence.cascade.result745, ptr %current.mask, align 1
  %4020 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result745)
  br i1 %4020, label %schedule.38, label %scheduler.loop

convergence.cascade760:                           ; preds = %convergence.cascade760, %schedule.38
  %convergence.cascade.flow764 = phi <8 x i1> [ %531, %schedule.38 ], [ %4063, %convergence.cascade760 ]
  %convergence.cascade.depth765 = phi i32 [ 0, %schedule.38 ], [ %4064, %convergence.cascade760 ]
  %4021 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow764)
  %4022 = load i32, ptr %current.token, align 4
  %4023 = icmp ne i32 %4022, 0
  %4024 = and i1 %4021, %4023
  %4025 = sub i32 %4022, 1
  %4026 = select i1 %4024, i32 %4025, i32 0
  %4027 = load i8, ptr %frame.active, align 1
  %4028 = trunc i32 %4026 to i8
  %4029 = shl i8 1, %4028
  %4030 = and i8 %4027, %4029
  %4031 = icmp ne i8 %4030, 0
  %4032 = load <8 x i32>, ptr %frame.static.id, align 32
  %4033 = extractelement <8 x i32> %4032, i32 %4026
  %convergence.target.pointer766 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %4033
  %convergence.dynamic.target767 = load i32, ptr %convergence.target.pointer766, align 4
  %4034 = icmp eq i32 %convergence.dynamic.target767, 38
  %4035 = and i1 %4031, %4034
  %4036 = and i1 %4024, %4035
  %4037 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4026
  %4038 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4026
  %4039 = load <8 x i1>, ptr %4037, align 1
  %4040 = load <8 x i1>, ptr %4038, align 1
  %4041 = or <8 x i1> %4040, %convergence.cascade.flow764
  %4042 = load <8 x i1>, ptr %live.mask, align 1
  %4043 = and <8 x i1> %4039, %4042
  %4044 = icmp eq <8 x i1> %4041, %4043
  %4045 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4044)
  %4046 = and i1 %4036, %4045
  %4047 = select i1 %4046, <8 x i1> zeroinitializer, <8 x i1> %4041
  %4048 = select i1 %4036, <8 x i1> %4047, <8 x i1> %4040
  store <8 x i1> %4048, ptr %4038, align 1
  %4049 = select i1 %4046, <8 x i1> zeroinitializer, <8 x i1> %4039
  store <8 x i1> %4049, ptr %4037, align 1
  %4050 = trunc i32 %4026 to i8
  %4051 = shl i8 1, %4050
  %4052 = xor i8 %4051, -1
  %4053 = and i8 %4027, %4052
  %4054 = select i1 %4046, i8 %4053, i8 %4027
  store i8 %4054, ptr %frame.active, align 1
  %.splatinsert768 = insertelement <8 x i1> poison, i1 %4036, i64 0
  %.splat769 = shufflevector <8 x i1> %.splatinsert768, <8 x i1> poison, <8 x i32> zeroinitializer
  %4055 = and <8 x i1> %convergence.cascade.flow764, %.splat769
  %4056 = load <8 x i1>, ptr %runnable.mask, align 1
  %4057 = xor <8 x i1> %4055, splat (i1 true)
  %4058 = and <8 x i1> %4056, %4057
  store <8 x i1> %4058, ptr %runnable.mask, align 1
  %.splatinsert770 = insertelement <8 x i1> poison, i1 %4046, i64 0
  %.splat771 = shufflevector <8 x i1> %.splatinsert770, <8 x i1> poison, <8 x i32> zeroinitializer
  %4059 = select <8 x i1> %.splat771, <8 x i1> %4041, <8 x i1> zeroinitializer
  %4060 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4061 = extractelement <8 x i32> %4060, i32 %4026
  %4062 = select i1 %4046, i32 %4061, i32 %4022
  store i32 %4062, ptr %current.token, align 4
  %.splatinsert772 = insertelement <8 x i1> poison, i1 %4036, i64 0
  %.splat773 = shufflevector <8 x i1> %.splatinsert772, <8 x i1> poison, <8 x i32> zeroinitializer
  %4063 = select <8 x i1> %.splat773, <8 x i1> %4059, <8 x i1> %convergence.cascade.flow764
  %4064 = add i32 %convergence.cascade.depth765, 1
  %4065 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4063)
  %4066 = icmp ult i32 %4064, 8
  %4067 = and i1 %4065, %4066
  %4068 = and i1 %4036, %4067
  %convergence.parent.token774 = load i32, ptr %current.token, align 4
  %convergence.parent.present775 = icmp ne i32 %convergence.parent.token774, 0
  %4069 = and i1 %4068, %convergence.parent.present775
  br i1 %4069, label %convergence.cascade760, label %convergence.cascade.exit761

convergence.cascade.exit761:                      ; preds = %convergence.cascade760, %schedule.38
  %convergence.cascade.result776 = phi <8 x i1> [ %531, %schedule.38 ], [ %4063, %convergence.cascade760 ]
  %4070 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result776)
  br i1 %4070, label %convergence.target.38.ready, label %scheduler.loop

convergence.target.38.ready:                      ; preds = %convergence.cascade.exit761
  %4071 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result776)
  %4072 = bitcast <8 x i1> %convergence.cascade.result776 to i8
  %4073 = call i8 @llvm.cttz.i8(i8 %4072, i1 false)
  %4074 = zext i8 %4073 to i32
  %4075 = select i1 %4071, i32 %4074, i32 0
  %.spill.load777 = load volatile <8 x i64>, ptr %.spill93, align 64
  %.spill.load778 = load i64, ptr %.spill20, align 4
  %.splatinsert779 = insertelement <8 x i64> poison, i64 %.spill.load778, i64 0
  %.splat780 = shufflevector <8 x i64> %.splatinsert779, <8 x i64> poison, <8 x i32> zeroinitializer
  %4076 = add <8 x i64> %.spill.load777, %.splat780
  %4077 = load volatile <8 x i64>, ptr %.spill100, align 64
  %4078 = select <8 x i1> %convergence.cascade.result776, <8 x i64> %4076, <8 x i64> %4077
  store volatile <8 x i64> %4078, ptr %.spill100, align 64
  %.spill.load781 = load <8 x i1>, ptr %.spill62, align 1
  %4079 = and <8 x i1> %convergence.cascade.result776, %.spill.load781
  %4080 = xor <8 x i1> %.spill.load781, splat (i1 true)
  %4081 = and <8 x i1> %convergence.cascade.result776, %4080
  %4082 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4079)
  %4083 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4081)
  %4084 = and i1 %4082, %4083
  br i1 %4084, label %varying.divergent782, label %varying.coherent783

varying.divergent782:                             ; preds = %convergence.target.38.ready
  %4085 = load i32, ptr %current.token, align 4
  %4086 = icmp ne i32 %4085, 0
  %4087 = sub i32 %4085, 1
  %4088 = select i1 %4086, i32 %4087, i32 0
  %4089 = load i8, ptr %frame.active, align 1
  %4090 = trunc i32 %4088 to i8
  %4091 = shl i8 1, %4090
  %4092 = and i8 %4089, %4091
  %4093 = icmp ne i8 %4092, 0
  %4094 = load <8 x i32>, ptr %frame.static.id, align 32
  %4095 = extractelement <8 x i32> %4094, i32 %4088
  %4096 = icmp eq i32 %4095, 19
  %4097 = and i1 %4093, %4096
  %4098 = and i1 %4086, %4097
  %4099 = xor i1 %4098, true
  %4100 = and i1 true, %4099
  %4101 = xor i8 %4089, -1
  %4102 = icmp ne i8 %4101, 0
  %4103 = xor i1 %4102, true
  %4104 = and i1 %4100, %4103
  br i1 %4104, label %convergence.overflow.trap784, label %convergence.overflow.resume785

varying.coherent783:                              ; preds = %convergence.target.38.ready
  br i1 %4082, label %varying.coherent.true788, label %varying.coherent.false789

convergence.overflow.trap784:                     ; preds = %varying.divergent782
  call void @llvm.trap()
  unreachable

convergence.overflow.resume785:                   ; preds = %varying.divergent782
  %4105 = call i8 @llvm.cttz.i8(i8 %4101, i1 false)
  %4106 = zext i8 %4105 to i32
  %4107 = select i1 %4102, i32 %4106, i32 0
  %4108 = trunc i32 %4107 to i8
  %4109 = shl i8 1, %4108
  %4110 = or i8 %4089, %4109
  %4111 = select i1 %4100, i8 %4110, i8 %4089
  store i8 %4111, ptr %frame.active, align 1
  %4112 = load <8 x i32>, ptr %frame.static.id, align 32
  %4113 = extractelement <8 x i32> %4112, i32 %4107
  %4114 = select i1 %4100, i32 19, i32 %4113
  %4115 = load <8 x i32>, ptr %frame.static.id, align 32
  %4116 = insertelement <8 x i32> %4115, i32 %4114, i32 %4107
  store <8 x i32> %4116, ptr %frame.static.id, align 32
  %4117 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4118 = extractelement <8 x i32> %4117, i32 %4107
  %4119 = select i1 %4100, i32 %4085, i32 %4118
  %4120 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4121 = insertelement <8 x i32> %4120, i32 %4119, i32 %4107
  store <8 x i32> %4121, ptr %frame.parent.token, align 32
  %4122 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4107
  %4123 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4107
  %4124 = load <8 x i1>, ptr %4122, align 1
  %4125 = load <8 x i1>, ptr %4123, align 1
  %4126 = select i1 %4100, <8 x i1> %convergence.cascade.result776, <8 x i1> %4124
  store <8 x i1> %4126, ptr %4122, align 1
  %4127 = select i1 %4100, <8 x i1> zeroinitializer, <8 x i1> %4125
  store <8 x i1> %4127, ptr %4123, align 1
  %4128 = add i32 %4107, 1
  %4129 = select i1 %4098, i32 %4085, i32 %4128
  %4130 = select i1 true, i32 %4129, i32 %4085
  store i32 %4130, ptr %current.token, align 4
  %4131 = load <8 x float>, ptr %.slot101, align 32
  %4132 = select <8 x i1> %4081, <8 x float> zeroinitializer, <8 x float> %4131
  store <8 x float> %4132, ptr %.slot101, align 32
  %4133 = load i32, ptr %current.token, align 4
  %4134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4079)
  %4135 = load i32, ptr %ready.count, align 4
  %4136 = icmp uge i32 %4135, 8
  %4137 = and i1 %4134, %4136
  br i1 %4137, label %ready.overflow.trap786, label %ready.overflow.resume787

ready.overflow.trap786:                           ; preds = %convergence.overflow.resume785
  call void @llvm.trap()
  unreachable

ready.overflow.resume787:                         ; preds = %convergence.overflow.resume785
  %4138 = select i1 %4134, i32 %4135, i32 0
  %4139 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4138
  %4140 = load <8 x i1>, ptr %4139, align 1
  %4141 = select i1 %4134, <8 x i1> %4079, <8 x i1> %4140
  store <8 x i1> %4141, ptr %4139, align 1
  %4142 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4138
  %4143 = load i32, ptr %4142, align 4
  %4144 = select i1 %4134, i32 39, i32 %4143
  store i32 %4144, ptr %4142, align 4
  %4145 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4138
  %4146 = load i32, ptr %4145, align 4
  %4147 = select i1 %4134, i32 %4133, i32 %4146
  store i32 %4147, ptr %4145, align 4
  %4148 = add i32 %4135, 1
  %4149 = select i1 %4134, i32 %4148, i32 %4135
  store i32 %4149, ptr %ready.count, align 4
  %4150 = load <8 x i1>, ptr %runnable.mask, align 1
  %4151 = or <8 x i1> %4150, %4079
  store <8 x i1> %4151, ptr %runnable.mask, align 1
  store <8 x i1> %4081, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true788:                         ; preds = %varying.coherent783
  store <8 x i1> %convergence.cascade.result776, ptr %current.mask, align 1
  %4152 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result776)
  br i1 %4152, label %schedule.39, label %scheduler.loop

varying.coherent.false789:                        ; preds = %varying.coherent783
  %4153 = load <8 x float>, ptr %.slot101, align 32
  %4154 = select <8 x i1> %convergence.cascade.result776, <8 x float> zeroinitializer, <8 x float> %4153
  store <8 x float> %4154, ptr %.slot101, align 32
  store <8 x i1> %convergence.cascade.result776, ptr %current.mask, align 1
  %4155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result776)
  br i1 %4155, label %schedule.40, label %scheduler.loop

convergence.cascade791:                           ; preds = %convergence.cascade791, %schedule.40
  %convergence.cascade.flow795 = phi <8 x i1> [ %545, %schedule.40 ], [ %4198, %convergence.cascade791 ]
  %convergence.cascade.depth796 = phi i32 [ 0, %schedule.40 ], [ %4199, %convergence.cascade791 ]
  %4156 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow795)
  %4157 = load i32, ptr %current.token, align 4
  %4158 = icmp ne i32 %4157, 0
  %4159 = and i1 %4156, %4158
  %4160 = sub i32 %4157, 1
  %4161 = select i1 %4159, i32 %4160, i32 0
  %4162 = load i8, ptr %frame.active, align 1
  %4163 = trunc i32 %4161 to i8
  %4164 = shl i8 1, %4163
  %4165 = and i8 %4162, %4164
  %4166 = icmp ne i8 %4165, 0
  %4167 = load <8 x i32>, ptr %frame.static.id, align 32
  %4168 = extractelement <8 x i32> %4167, i32 %4161
  %convergence.target.pointer797 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %4168
  %convergence.dynamic.target798 = load i32, ptr %convergence.target.pointer797, align 4
  %4169 = icmp eq i32 %convergence.dynamic.target798, 40
  %4170 = and i1 %4166, %4169
  %4171 = and i1 %4159, %4170
  %4172 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4161
  %4173 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4161
  %4174 = load <8 x i1>, ptr %4172, align 1
  %4175 = load <8 x i1>, ptr %4173, align 1
  %4176 = or <8 x i1> %4175, %convergence.cascade.flow795
  %4177 = load <8 x i1>, ptr %live.mask, align 1
  %4178 = and <8 x i1> %4174, %4177
  %4179 = icmp eq <8 x i1> %4176, %4178
  %4180 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4179)
  %4181 = and i1 %4171, %4180
  %4182 = select i1 %4181, <8 x i1> zeroinitializer, <8 x i1> %4176
  %4183 = select i1 %4171, <8 x i1> %4182, <8 x i1> %4175
  store <8 x i1> %4183, ptr %4173, align 1
  %4184 = select i1 %4181, <8 x i1> zeroinitializer, <8 x i1> %4174
  store <8 x i1> %4184, ptr %4172, align 1
  %4185 = trunc i32 %4161 to i8
  %4186 = shl i8 1, %4185
  %4187 = xor i8 %4186, -1
  %4188 = and i8 %4162, %4187
  %4189 = select i1 %4181, i8 %4188, i8 %4162
  store i8 %4189, ptr %frame.active, align 1
  %.splatinsert799 = insertelement <8 x i1> poison, i1 %4171, i64 0
  %.splat800 = shufflevector <8 x i1> %.splatinsert799, <8 x i1> poison, <8 x i32> zeroinitializer
  %4190 = and <8 x i1> %convergence.cascade.flow795, %.splat800
  %4191 = load <8 x i1>, ptr %runnable.mask, align 1
  %4192 = xor <8 x i1> %4190, splat (i1 true)
  %4193 = and <8 x i1> %4191, %4192
  store <8 x i1> %4193, ptr %runnable.mask, align 1
  %.splatinsert801 = insertelement <8 x i1> poison, i1 %4181, i64 0
  %.splat802 = shufflevector <8 x i1> %.splatinsert801, <8 x i1> poison, <8 x i32> zeroinitializer
  %4194 = select <8 x i1> %.splat802, <8 x i1> %4176, <8 x i1> zeroinitializer
  %4195 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4196 = extractelement <8 x i32> %4195, i32 %4161
  %4197 = select i1 %4181, i32 %4196, i32 %4157
  store i32 %4197, ptr %current.token, align 4
  %.splatinsert803 = insertelement <8 x i1> poison, i1 %4171, i64 0
  %.splat804 = shufflevector <8 x i1> %.splatinsert803, <8 x i1> poison, <8 x i32> zeroinitializer
  %4198 = select <8 x i1> %.splat804, <8 x i1> %4194, <8 x i1> %convergence.cascade.flow795
  %4199 = add i32 %convergence.cascade.depth796, 1
  %4200 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4198)
  %4201 = icmp ult i32 %4199, 8
  %4202 = and i1 %4200, %4201
  %4203 = and i1 %4171, %4202
  %convergence.parent.token805 = load i32, ptr %current.token, align 4
  %convergence.parent.present806 = icmp ne i32 %convergence.parent.token805, 0
  %4204 = and i1 %4203, %convergence.parent.present806
  br i1 %4204, label %convergence.cascade791, label %convergence.cascade.exit792

convergence.cascade.exit792:                      ; preds = %convergence.cascade791, %schedule.40
  %convergence.cascade.result807 = phi <8 x i1> [ %545, %schedule.40 ], [ %4198, %convergence.cascade791 ]
  %4205 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result807)
  br i1 %4205, label %convergence.target.40.ready, label %scheduler.loop

convergence.target.40.ready:                      ; preds = %convergence.cascade.exit792
  %4206 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result807)
  %4207 = bitcast <8 x i1> %convergence.cascade.result807 to i8
  %4208 = call i8 @llvm.cttz.i8(i8 %4207, i1 false)
  %4209 = zext i8 %4208 to i32
  %4210 = select i1 %4206, i32 %4209, i32 0
  %.spill.load808 = load volatile <8 x i64>, ptr %.spill75, align 64
  %4211 = mul <8 x i64> %.spill.load808, splat (i64 4)
  %4212 = load volatile <8 x i64>, ptr %.spill102, align 64
  %4213 = select <8 x i1> %convergence.cascade.result807, <8 x i64> %4211, <8 x i64> %4212
  store volatile <8 x i64> %4213, ptr %.spill102, align 64
  %.spill.load809 = load i64, ptr %.spill10, align 4
  %.splatinsert810 = insertelement <8 x i64> poison, i64 %.spill.load809, i64 0
  %.splat811 = shufflevector <8 x i64> %.splatinsert810, <8 x i64> poison, <8 x i32> zeroinitializer
  %4214 = add <8 x i64> %4211, %.splat811
  %4215 = load volatile <8 x i64>, ptr %.spill103, align 64
  %4216 = select <8 x i1> %convergence.cascade.result807, <8 x i64> %4214, <8 x i64> %4215
  store volatile <8 x i64> %4216, ptr %.spill103, align 64
  %.spill.load812 = load <8 x i1>, ptr %.spill77, align 1
  %4217 = and <8 x i1> %convergence.cascade.result807, %.spill.load812
  %4218 = xor <8 x i1> %.spill.load812, splat (i1 true)
  %4219 = and <8 x i1> %convergence.cascade.result807, %4218
  %4220 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4217)
  %4221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4219)
  %4222 = and i1 %4220, %4221
  br i1 %4222, label %varying.divergent813, label %varying.coherent814

varying.divergent813:                             ; preds = %convergence.target.40.ready
  %4223 = load i32, ptr %current.token, align 4
  %4224 = icmp ne i32 %4223, 0
  %4225 = sub i32 %4223, 1
  %4226 = select i1 %4224, i32 %4225, i32 0
  %4227 = load i8, ptr %frame.active, align 1
  %4228 = trunc i32 %4226 to i8
  %4229 = shl i8 1, %4228
  %4230 = and i8 %4227, %4229
  %4231 = icmp ne i8 %4230, 0
  %4232 = load <8 x i32>, ptr %frame.static.id, align 32
  %4233 = extractelement <8 x i32> %4232, i32 %4226
  %4234 = icmp eq i32 %4233, 20
  %4235 = and i1 %4231, %4234
  %4236 = and i1 %4224, %4235
  %4237 = xor i1 %4236, true
  %4238 = and i1 true, %4237
  %4239 = xor i8 %4227, -1
  %4240 = icmp ne i8 %4239, 0
  %4241 = xor i1 %4240, true
  %4242 = and i1 %4238, %4241
  br i1 %4242, label %convergence.overflow.trap815, label %convergence.overflow.resume816

varying.coherent814:                              ; preds = %convergence.target.40.ready
  br i1 %4220, label %varying.coherent.true819, label %varying.coherent.false820

convergence.overflow.trap815:                     ; preds = %varying.divergent813
  call void @llvm.trap()
  unreachable

convergence.overflow.resume816:                   ; preds = %varying.divergent813
  %4243 = call i8 @llvm.cttz.i8(i8 %4239, i1 false)
  %4244 = zext i8 %4243 to i32
  %4245 = select i1 %4240, i32 %4244, i32 0
  %4246 = trunc i32 %4245 to i8
  %4247 = shl i8 1, %4246
  %4248 = or i8 %4227, %4247
  %4249 = select i1 %4238, i8 %4248, i8 %4227
  store i8 %4249, ptr %frame.active, align 1
  %4250 = load <8 x i32>, ptr %frame.static.id, align 32
  %4251 = extractelement <8 x i32> %4250, i32 %4245
  %4252 = select i1 %4238, i32 20, i32 %4251
  %4253 = load <8 x i32>, ptr %frame.static.id, align 32
  %4254 = insertelement <8 x i32> %4253, i32 %4252, i32 %4245
  store <8 x i32> %4254, ptr %frame.static.id, align 32
  %4255 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4256 = extractelement <8 x i32> %4255, i32 %4245
  %4257 = select i1 %4238, i32 %4223, i32 %4256
  %4258 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4259 = insertelement <8 x i32> %4258, i32 %4257, i32 %4245
  store <8 x i32> %4259, ptr %frame.parent.token, align 32
  %4260 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4245
  %4261 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4245
  %4262 = load <8 x i1>, ptr %4260, align 1
  %4263 = load <8 x i1>, ptr %4261, align 1
  %4264 = select i1 %4238, <8 x i1> %convergence.cascade.result807, <8 x i1> %4262
  store <8 x i1> %4264, ptr %4260, align 1
  %4265 = select i1 %4238, <8 x i1> zeroinitializer, <8 x i1> %4263
  store <8 x i1> %4265, ptr %4261, align 1
  %4266 = add i32 %4245, 1
  %4267 = select i1 %4236, i32 %4223, i32 %4266
  %4268 = select i1 true, i32 %4267, i32 %4223
  store i32 %4268, ptr %current.token, align 4
  %4269 = load <8 x float>, ptr %.slot104, align 32
  %4270 = select <8 x i1> %4219, <8 x float> zeroinitializer, <8 x float> %4269
  store <8 x float> %4270, ptr %.slot104, align 32
  %4271 = load i32, ptr %current.token, align 4
  %4272 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4217)
  %4273 = load i32, ptr %ready.count, align 4
  %4274 = icmp uge i32 %4273, 8
  %4275 = and i1 %4272, %4274
  br i1 %4275, label %ready.overflow.trap817, label %ready.overflow.resume818

ready.overflow.trap817:                           ; preds = %convergence.overflow.resume816
  call void @llvm.trap()
  unreachable

ready.overflow.resume818:                         ; preds = %convergence.overflow.resume816
  %4276 = select i1 %4272, i32 %4273, i32 0
  %4277 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4276
  %4278 = load <8 x i1>, ptr %4277, align 1
  %4279 = select i1 %4272, <8 x i1> %4217, <8 x i1> %4278
  store <8 x i1> %4279, ptr %4277, align 1
  %4280 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4276
  %4281 = load i32, ptr %4280, align 4
  %4282 = select i1 %4272, i32 41, i32 %4281
  store i32 %4282, ptr %4280, align 4
  %4283 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4276
  %4284 = load i32, ptr %4283, align 4
  %4285 = select i1 %4272, i32 %4271, i32 %4284
  store i32 %4285, ptr %4283, align 4
  %4286 = add i32 %4273, 1
  %4287 = select i1 %4272, i32 %4286, i32 %4273
  store i32 %4287, ptr %ready.count, align 4
  %4288 = load <8 x i1>, ptr %runnable.mask, align 1
  %4289 = or <8 x i1> %4288, %4217
  store <8 x i1> %4289, ptr %runnable.mask, align 1
  store <8 x i1> %4219, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true819:                         ; preds = %varying.coherent814
  store <8 x i1> %convergence.cascade.result807, ptr %current.mask, align 1
  %4290 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result807)
  br i1 %4290, label %schedule.41, label %scheduler.loop

varying.coherent.false820:                        ; preds = %varying.coherent814
  %4291 = load <8 x float>, ptr %.slot104, align 32
  %4292 = select <8 x i1> %convergence.cascade.result807, <8 x float> zeroinitializer, <8 x float> %4291
  store <8 x float> %4292, ptr %.slot104, align 32
  store <8 x i1> %convergence.cascade.result807, ptr %current.mask, align 1
  %4293 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result807)
  br i1 %4293, label %schedule.42, label %scheduler.loop

convergence.cascade822:                           ; preds = %convergence.cascade822, %schedule.42
  %convergence.cascade.flow826 = phi <8 x i1> [ %559, %schedule.42 ], [ %4336, %convergence.cascade822 ]
  %convergence.cascade.depth827 = phi i32 [ 0, %schedule.42 ], [ %4337, %convergence.cascade822 ]
  %4294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow826)
  %4295 = load i32, ptr %current.token, align 4
  %4296 = icmp ne i32 %4295, 0
  %4297 = and i1 %4294, %4296
  %4298 = sub i32 %4295, 1
  %4299 = select i1 %4297, i32 %4298, i32 0
  %4300 = load i8, ptr %frame.active, align 1
  %4301 = trunc i32 %4299 to i8
  %4302 = shl i8 1, %4301
  %4303 = and i8 %4300, %4302
  %4304 = icmp ne i8 %4303, 0
  %4305 = load <8 x i32>, ptr %frame.static.id, align 32
  %4306 = extractelement <8 x i32> %4305, i32 %4299
  %convergence.target.pointer828 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %4306
  %convergence.dynamic.target829 = load i32, ptr %convergence.target.pointer828, align 4
  %4307 = icmp eq i32 %convergence.dynamic.target829, 42
  %4308 = and i1 %4304, %4307
  %4309 = and i1 %4297, %4308
  %4310 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4299
  %4311 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4299
  %4312 = load <8 x i1>, ptr %4310, align 1
  %4313 = load <8 x i1>, ptr %4311, align 1
  %4314 = or <8 x i1> %4313, %convergence.cascade.flow826
  %4315 = load <8 x i1>, ptr %live.mask, align 1
  %4316 = and <8 x i1> %4312, %4315
  %4317 = icmp eq <8 x i1> %4314, %4316
  %4318 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4317)
  %4319 = and i1 %4309, %4318
  %4320 = select i1 %4319, <8 x i1> zeroinitializer, <8 x i1> %4314
  %4321 = select i1 %4309, <8 x i1> %4320, <8 x i1> %4313
  store <8 x i1> %4321, ptr %4311, align 1
  %4322 = select i1 %4319, <8 x i1> zeroinitializer, <8 x i1> %4312
  store <8 x i1> %4322, ptr %4310, align 1
  %4323 = trunc i32 %4299 to i8
  %4324 = shl i8 1, %4323
  %4325 = xor i8 %4324, -1
  %4326 = and i8 %4300, %4325
  %4327 = select i1 %4319, i8 %4326, i8 %4300
  store i8 %4327, ptr %frame.active, align 1
  %.splatinsert830 = insertelement <8 x i1> poison, i1 %4309, i64 0
  %.splat831 = shufflevector <8 x i1> %.splatinsert830, <8 x i1> poison, <8 x i32> zeroinitializer
  %4328 = and <8 x i1> %convergence.cascade.flow826, %.splat831
  %4329 = load <8 x i1>, ptr %runnable.mask, align 1
  %4330 = xor <8 x i1> %4328, splat (i1 true)
  %4331 = and <8 x i1> %4329, %4330
  store <8 x i1> %4331, ptr %runnable.mask, align 1
  %.splatinsert832 = insertelement <8 x i1> poison, i1 %4319, i64 0
  %.splat833 = shufflevector <8 x i1> %.splatinsert832, <8 x i1> poison, <8 x i32> zeroinitializer
  %4332 = select <8 x i1> %.splat833, <8 x i1> %4314, <8 x i1> zeroinitializer
  %4333 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4334 = extractelement <8 x i32> %4333, i32 %4299
  %4335 = select i1 %4319, i32 %4334, i32 %4295
  store i32 %4335, ptr %current.token, align 4
  %.splatinsert834 = insertelement <8 x i1> poison, i1 %4309, i64 0
  %.splat835 = shufflevector <8 x i1> %.splatinsert834, <8 x i1> poison, <8 x i32> zeroinitializer
  %4336 = select <8 x i1> %.splat835, <8 x i1> %4332, <8 x i1> %convergence.cascade.flow826
  %4337 = add i32 %convergence.cascade.depth827, 1
  %4338 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4336)
  %4339 = icmp ult i32 %4337, 8
  %4340 = and i1 %4338, %4339
  %4341 = and i1 %4309, %4340
  %convergence.parent.token836 = load i32, ptr %current.token, align 4
  %convergence.parent.present837 = icmp ne i32 %convergence.parent.token836, 0
  %4342 = and i1 %4341, %convergence.parent.present837
  br i1 %4342, label %convergence.cascade822, label %convergence.cascade.exit823

convergence.cascade.exit823:                      ; preds = %convergence.cascade822, %schedule.42
  %convergence.cascade.result838 = phi <8 x i1> [ %559, %schedule.42 ], [ %4336, %convergence.cascade822 ]
  %4343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result838)
  br i1 %4343, label %convergence.target.42.ready, label %scheduler.loop

convergence.target.42.ready:                      ; preds = %convergence.cascade.exit823
  %4344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result838)
  %4345 = bitcast <8 x i1> %convergence.cascade.result838 to i8
  %4346 = call i8 @llvm.cttz.i8(i8 %4345, i1 false)
  %4347 = zext i8 %4346 to i32
  %4348 = select i1 %4344, i32 %4347, i32 0
  %.spill.load839 = load volatile <8 x i64>, ptr %.spill102, align 64
  %.spill.load840 = load i64, ptr %.spill16, align 4
  %.splatinsert841 = insertelement <8 x i64> poison, i64 %.spill.load840, i64 0
  %.splat842 = shufflevector <8 x i64> %.splatinsert841, <8 x i64> poison, <8 x i32> zeroinitializer
  %4349 = add <8 x i64> %.spill.load839, %.splat842
  %4350 = load volatile <8 x i64>, ptr %.spill105, align 64
  %4351 = select <8 x i1> %convergence.cascade.result838, <8 x i64> %4349, <8 x i64> %4350
  store volatile <8 x i64> %4351, ptr %.spill105, align 64
  %.spill.load843 = load <8 x i1>, ptr %.spill77, align 1
  %4352 = and <8 x i1> %convergence.cascade.result838, %.spill.load843
  %4353 = xor <8 x i1> %.spill.load843, splat (i1 true)
  %4354 = and <8 x i1> %convergence.cascade.result838, %4353
  %4355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4352)
  %4356 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4354)
  %4357 = and i1 %4355, %4356
  br i1 %4357, label %varying.divergent844, label %varying.coherent845

varying.divergent844:                             ; preds = %convergence.target.42.ready
  %4358 = load i32, ptr %current.token, align 4
  %4359 = icmp ne i32 %4358, 0
  %4360 = sub i32 %4358, 1
  %4361 = select i1 %4359, i32 %4360, i32 0
  %4362 = load i8, ptr %frame.active, align 1
  %4363 = trunc i32 %4361 to i8
  %4364 = shl i8 1, %4363
  %4365 = and i8 %4362, %4364
  %4366 = icmp ne i8 %4365, 0
  %4367 = load <8 x i32>, ptr %frame.static.id, align 32
  %4368 = extractelement <8 x i32> %4367, i32 %4361
  %4369 = icmp eq i32 %4368, 21
  %4370 = and i1 %4366, %4369
  %4371 = and i1 %4359, %4370
  %4372 = xor i1 %4371, true
  %4373 = and i1 true, %4372
  %4374 = xor i8 %4362, -1
  %4375 = icmp ne i8 %4374, 0
  %4376 = xor i1 %4375, true
  %4377 = and i1 %4373, %4376
  br i1 %4377, label %convergence.overflow.trap846, label %convergence.overflow.resume847

varying.coherent845:                              ; preds = %convergence.target.42.ready
  br i1 %4355, label %varying.coherent.true850, label %varying.coherent.false851

convergence.overflow.trap846:                     ; preds = %varying.divergent844
  call void @llvm.trap()
  unreachable

convergence.overflow.resume847:                   ; preds = %varying.divergent844
  %4378 = call i8 @llvm.cttz.i8(i8 %4374, i1 false)
  %4379 = zext i8 %4378 to i32
  %4380 = select i1 %4375, i32 %4379, i32 0
  %4381 = trunc i32 %4380 to i8
  %4382 = shl i8 1, %4381
  %4383 = or i8 %4362, %4382
  %4384 = select i1 %4373, i8 %4383, i8 %4362
  store i8 %4384, ptr %frame.active, align 1
  %4385 = load <8 x i32>, ptr %frame.static.id, align 32
  %4386 = extractelement <8 x i32> %4385, i32 %4380
  %4387 = select i1 %4373, i32 21, i32 %4386
  %4388 = load <8 x i32>, ptr %frame.static.id, align 32
  %4389 = insertelement <8 x i32> %4388, i32 %4387, i32 %4380
  store <8 x i32> %4389, ptr %frame.static.id, align 32
  %4390 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4391 = extractelement <8 x i32> %4390, i32 %4380
  %4392 = select i1 %4373, i32 %4358, i32 %4391
  %4393 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4394 = insertelement <8 x i32> %4393, i32 %4392, i32 %4380
  store <8 x i32> %4394, ptr %frame.parent.token, align 32
  %4395 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4380
  %4396 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4380
  %4397 = load <8 x i1>, ptr %4395, align 1
  %4398 = load <8 x i1>, ptr %4396, align 1
  %4399 = select i1 %4373, <8 x i1> %convergence.cascade.result838, <8 x i1> %4397
  store <8 x i1> %4399, ptr %4395, align 1
  %4400 = select i1 %4373, <8 x i1> zeroinitializer, <8 x i1> %4398
  store <8 x i1> %4400, ptr %4396, align 1
  %4401 = add i32 %4380, 1
  %4402 = select i1 %4371, i32 %4358, i32 %4401
  %4403 = select i1 true, i32 %4402, i32 %4358
  store i32 %4403, ptr %current.token, align 4
  %4404 = load <8 x float>, ptr %.slot106, align 32
  %4405 = select <8 x i1> %4354, <8 x float> zeroinitializer, <8 x float> %4404
  store <8 x float> %4405, ptr %.slot106, align 32
  %4406 = load i32, ptr %current.token, align 4
  %4407 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4352)
  %4408 = load i32, ptr %ready.count, align 4
  %4409 = icmp uge i32 %4408, 8
  %4410 = and i1 %4407, %4409
  br i1 %4410, label %ready.overflow.trap848, label %ready.overflow.resume849

ready.overflow.trap848:                           ; preds = %convergence.overflow.resume847
  call void @llvm.trap()
  unreachable

ready.overflow.resume849:                         ; preds = %convergence.overflow.resume847
  %4411 = select i1 %4407, i32 %4408, i32 0
  %4412 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4411
  %4413 = load <8 x i1>, ptr %4412, align 1
  %4414 = select i1 %4407, <8 x i1> %4352, <8 x i1> %4413
  store <8 x i1> %4414, ptr %4412, align 1
  %4415 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4411
  %4416 = load i32, ptr %4415, align 4
  %4417 = select i1 %4407, i32 43, i32 %4416
  store i32 %4417, ptr %4415, align 4
  %4418 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4411
  %4419 = load i32, ptr %4418, align 4
  %4420 = select i1 %4407, i32 %4406, i32 %4419
  store i32 %4420, ptr %4418, align 4
  %4421 = add i32 %4408, 1
  %4422 = select i1 %4407, i32 %4421, i32 %4408
  store i32 %4422, ptr %ready.count, align 4
  %4423 = load <8 x i1>, ptr %runnable.mask, align 1
  %4424 = or <8 x i1> %4423, %4352
  store <8 x i1> %4424, ptr %runnable.mask, align 1
  store <8 x i1> %4354, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true850:                         ; preds = %varying.coherent845
  store <8 x i1> %convergence.cascade.result838, ptr %current.mask, align 1
  %4425 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result838)
  br i1 %4425, label %schedule.43, label %scheduler.loop

varying.coherent.false851:                        ; preds = %varying.coherent845
  %4426 = load <8 x float>, ptr %.slot106, align 32
  %4427 = select <8 x i1> %convergence.cascade.result838, <8 x float> zeroinitializer, <8 x float> %4426
  store <8 x float> %4427, ptr %.slot106, align 32
  store <8 x i1> %convergence.cascade.result838, ptr %current.mask, align 1
  %4428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result838)
  br i1 %4428, label %schedule.44, label %scheduler.loop

convergence.cascade853:                           ; preds = %convergence.cascade853, %schedule.44
  %convergence.cascade.flow857 = phi <8 x i1> [ %573, %schedule.44 ], [ %4471, %convergence.cascade853 ]
  %convergence.cascade.depth858 = phi i32 [ 0, %schedule.44 ], [ %4472, %convergence.cascade853 ]
  %4429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow857)
  %4430 = load i32, ptr %current.token, align 4
  %4431 = icmp ne i32 %4430, 0
  %4432 = and i1 %4429, %4431
  %4433 = sub i32 %4430, 1
  %4434 = select i1 %4432, i32 %4433, i32 0
  %4435 = load i8, ptr %frame.active, align 1
  %4436 = trunc i32 %4434 to i8
  %4437 = shl i8 1, %4436
  %4438 = and i8 %4435, %4437
  %4439 = icmp ne i8 %4438, 0
  %4440 = load <8 x i32>, ptr %frame.static.id, align 32
  %4441 = extractelement <8 x i32> %4440, i32 %4434
  %convergence.target.pointer859 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %4441
  %convergence.dynamic.target860 = load i32, ptr %convergence.target.pointer859, align 4
  %4442 = icmp eq i32 %convergence.dynamic.target860, 44
  %4443 = and i1 %4439, %4442
  %4444 = and i1 %4432, %4443
  %4445 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4434
  %4446 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4434
  %4447 = load <8 x i1>, ptr %4445, align 1
  %4448 = load <8 x i1>, ptr %4446, align 1
  %4449 = or <8 x i1> %4448, %convergence.cascade.flow857
  %4450 = load <8 x i1>, ptr %live.mask, align 1
  %4451 = and <8 x i1> %4447, %4450
  %4452 = icmp eq <8 x i1> %4449, %4451
  %4453 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4452)
  %4454 = and i1 %4444, %4453
  %4455 = select i1 %4454, <8 x i1> zeroinitializer, <8 x i1> %4449
  %4456 = select i1 %4444, <8 x i1> %4455, <8 x i1> %4448
  store <8 x i1> %4456, ptr %4446, align 1
  %4457 = select i1 %4454, <8 x i1> zeroinitializer, <8 x i1> %4447
  store <8 x i1> %4457, ptr %4445, align 1
  %4458 = trunc i32 %4434 to i8
  %4459 = shl i8 1, %4458
  %4460 = xor i8 %4459, -1
  %4461 = and i8 %4435, %4460
  %4462 = select i1 %4454, i8 %4461, i8 %4435
  store i8 %4462, ptr %frame.active, align 1
  %.splatinsert861 = insertelement <8 x i1> poison, i1 %4444, i64 0
  %.splat862 = shufflevector <8 x i1> %.splatinsert861, <8 x i1> poison, <8 x i32> zeroinitializer
  %4463 = and <8 x i1> %convergence.cascade.flow857, %.splat862
  %4464 = load <8 x i1>, ptr %runnable.mask, align 1
  %4465 = xor <8 x i1> %4463, splat (i1 true)
  %4466 = and <8 x i1> %4464, %4465
  store <8 x i1> %4466, ptr %runnable.mask, align 1
  %.splatinsert863 = insertelement <8 x i1> poison, i1 %4454, i64 0
  %.splat864 = shufflevector <8 x i1> %.splatinsert863, <8 x i1> poison, <8 x i32> zeroinitializer
  %4467 = select <8 x i1> %.splat864, <8 x i1> %4449, <8 x i1> zeroinitializer
  %4468 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4469 = extractelement <8 x i32> %4468, i32 %4434
  %4470 = select i1 %4454, i32 %4469, i32 %4430
  store i32 %4470, ptr %current.token, align 4
  %.splatinsert865 = insertelement <8 x i1> poison, i1 %4444, i64 0
  %.splat866 = shufflevector <8 x i1> %.splatinsert865, <8 x i1> poison, <8 x i32> zeroinitializer
  %4471 = select <8 x i1> %.splat866, <8 x i1> %4467, <8 x i1> %convergence.cascade.flow857
  %4472 = add i32 %convergence.cascade.depth858, 1
  %4473 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4471)
  %4474 = icmp ult i32 %4472, 8
  %4475 = and i1 %4473, %4474
  %4476 = and i1 %4444, %4475
  %convergence.parent.token867 = load i32, ptr %current.token, align 4
  %convergence.parent.present868 = icmp ne i32 %convergence.parent.token867, 0
  %4477 = and i1 %4476, %convergence.parent.present868
  br i1 %4477, label %convergence.cascade853, label %convergence.cascade.exit854

convergence.cascade.exit854:                      ; preds = %convergence.cascade853, %schedule.44
  %convergence.cascade.result869 = phi <8 x i1> [ %573, %schedule.44 ], [ %4471, %convergence.cascade853 ]
  %4478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result869)
  br i1 %4478, label %convergence.target.44.ready, label %scheduler.loop

convergence.target.44.ready:                      ; preds = %convergence.cascade.exit854
  %4479 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result869)
  %4480 = bitcast <8 x i1> %convergence.cascade.result869 to i8
  %4481 = call i8 @llvm.cttz.i8(i8 %4480, i1 false)
  %4482 = zext i8 %4481 to i32
  %4483 = select i1 %4479, i32 %4482, i32 0
  %.spill.load870 = load volatile <8 x i64>, ptr %.spill102, align 64
  %.spill.load871 = load i64, ptr %.spill18, align 4
  %.splatinsert872 = insertelement <8 x i64> poison, i64 %.spill.load871, i64 0
  %.splat873 = shufflevector <8 x i64> %.splatinsert872, <8 x i64> poison, <8 x i32> zeroinitializer
  %4484 = add <8 x i64> %.spill.load870, %.splat873
  %4485 = load volatile <8 x i64>, ptr %.spill107, align 64
  %4486 = select <8 x i1> %convergence.cascade.result869, <8 x i64> %4484, <8 x i64> %4485
  store volatile <8 x i64> %4486, ptr %.spill107, align 64
  %.spill.load874 = load <8 x i1>, ptr %.spill77, align 1
  %4487 = and <8 x i1> %convergence.cascade.result869, %.spill.load874
  %4488 = xor <8 x i1> %.spill.load874, splat (i1 true)
  %4489 = and <8 x i1> %convergence.cascade.result869, %4488
  %4490 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4487)
  %4491 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4489)
  %4492 = and i1 %4490, %4491
  br i1 %4492, label %varying.divergent875, label %varying.coherent876

varying.divergent875:                             ; preds = %convergence.target.44.ready
  %4493 = load i32, ptr %current.token, align 4
  %4494 = icmp ne i32 %4493, 0
  %4495 = sub i32 %4493, 1
  %4496 = select i1 %4494, i32 %4495, i32 0
  %4497 = load i8, ptr %frame.active, align 1
  %4498 = trunc i32 %4496 to i8
  %4499 = shl i8 1, %4498
  %4500 = and i8 %4497, %4499
  %4501 = icmp ne i8 %4500, 0
  %4502 = load <8 x i32>, ptr %frame.static.id, align 32
  %4503 = extractelement <8 x i32> %4502, i32 %4496
  %4504 = icmp eq i32 %4503, 22
  %4505 = and i1 %4501, %4504
  %4506 = and i1 %4494, %4505
  %4507 = xor i1 %4506, true
  %4508 = and i1 true, %4507
  %4509 = xor i8 %4497, -1
  %4510 = icmp ne i8 %4509, 0
  %4511 = xor i1 %4510, true
  %4512 = and i1 %4508, %4511
  br i1 %4512, label %convergence.overflow.trap877, label %convergence.overflow.resume878

varying.coherent876:                              ; preds = %convergence.target.44.ready
  br i1 %4490, label %varying.coherent.true881, label %varying.coherent.false882

convergence.overflow.trap877:                     ; preds = %varying.divergent875
  call void @llvm.trap()
  unreachable

convergence.overflow.resume878:                   ; preds = %varying.divergent875
  %4513 = call i8 @llvm.cttz.i8(i8 %4509, i1 false)
  %4514 = zext i8 %4513 to i32
  %4515 = select i1 %4510, i32 %4514, i32 0
  %4516 = trunc i32 %4515 to i8
  %4517 = shl i8 1, %4516
  %4518 = or i8 %4497, %4517
  %4519 = select i1 %4508, i8 %4518, i8 %4497
  store i8 %4519, ptr %frame.active, align 1
  %4520 = load <8 x i32>, ptr %frame.static.id, align 32
  %4521 = extractelement <8 x i32> %4520, i32 %4515
  %4522 = select i1 %4508, i32 22, i32 %4521
  %4523 = load <8 x i32>, ptr %frame.static.id, align 32
  %4524 = insertelement <8 x i32> %4523, i32 %4522, i32 %4515
  store <8 x i32> %4524, ptr %frame.static.id, align 32
  %4525 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4526 = extractelement <8 x i32> %4525, i32 %4515
  %4527 = select i1 %4508, i32 %4493, i32 %4526
  %4528 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4529 = insertelement <8 x i32> %4528, i32 %4527, i32 %4515
  store <8 x i32> %4529, ptr %frame.parent.token, align 32
  %4530 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4515
  %4531 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4515
  %4532 = load <8 x i1>, ptr %4530, align 1
  %4533 = load <8 x i1>, ptr %4531, align 1
  %4534 = select i1 %4508, <8 x i1> %convergence.cascade.result869, <8 x i1> %4532
  store <8 x i1> %4534, ptr %4530, align 1
  %4535 = select i1 %4508, <8 x i1> zeroinitializer, <8 x i1> %4533
  store <8 x i1> %4535, ptr %4531, align 1
  %4536 = add i32 %4515, 1
  %4537 = select i1 %4506, i32 %4493, i32 %4536
  %4538 = select i1 true, i32 %4537, i32 %4493
  store i32 %4538, ptr %current.token, align 4
  %4539 = load <8 x float>, ptr %.slot108, align 32
  %4540 = select <8 x i1> %4489, <8 x float> zeroinitializer, <8 x float> %4539
  store <8 x float> %4540, ptr %.slot108, align 32
  %4541 = load i32, ptr %current.token, align 4
  %4542 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4487)
  %4543 = load i32, ptr %ready.count, align 4
  %4544 = icmp uge i32 %4543, 8
  %4545 = and i1 %4542, %4544
  br i1 %4545, label %ready.overflow.trap879, label %ready.overflow.resume880

ready.overflow.trap879:                           ; preds = %convergence.overflow.resume878
  call void @llvm.trap()
  unreachable

ready.overflow.resume880:                         ; preds = %convergence.overflow.resume878
  %4546 = select i1 %4542, i32 %4543, i32 0
  %4547 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4546
  %4548 = load <8 x i1>, ptr %4547, align 1
  %4549 = select i1 %4542, <8 x i1> %4487, <8 x i1> %4548
  store <8 x i1> %4549, ptr %4547, align 1
  %4550 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4546
  %4551 = load i32, ptr %4550, align 4
  %4552 = select i1 %4542, i32 45, i32 %4551
  store i32 %4552, ptr %4550, align 4
  %4553 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4546
  %4554 = load i32, ptr %4553, align 4
  %4555 = select i1 %4542, i32 %4541, i32 %4554
  store i32 %4555, ptr %4553, align 4
  %4556 = add i32 %4543, 1
  %4557 = select i1 %4542, i32 %4556, i32 %4543
  store i32 %4557, ptr %ready.count, align 4
  %4558 = load <8 x i1>, ptr %runnable.mask, align 1
  %4559 = or <8 x i1> %4558, %4487
  store <8 x i1> %4559, ptr %runnable.mask, align 1
  store <8 x i1> %4489, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true881:                         ; preds = %varying.coherent876
  store <8 x i1> %convergence.cascade.result869, ptr %current.mask, align 1
  %4560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result869)
  br i1 %4560, label %schedule.45, label %scheduler.loop

varying.coherent.false882:                        ; preds = %varying.coherent876
  %4561 = load <8 x float>, ptr %.slot108, align 32
  %4562 = select <8 x i1> %convergence.cascade.result869, <8 x float> zeroinitializer, <8 x float> %4561
  store <8 x float> %4562, ptr %.slot108, align 32
  store <8 x i1> %convergence.cascade.result869, ptr %current.mask, align 1
  %4563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result869)
  br i1 %4563, label %schedule.46, label %scheduler.loop

convergence.cascade884:                           ; preds = %convergence.cascade884, %schedule.46
  %convergence.cascade.flow888 = phi <8 x i1> [ %587, %schedule.46 ], [ %4606, %convergence.cascade884 ]
  %convergence.cascade.depth889 = phi i32 [ 0, %schedule.46 ], [ %4607, %convergence.cascade884 ]
  %4564 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow888)
  %4565 = load i32, ptr %current.token, align 4
  %4566 = icmp ne i32 %4565, 0
  %4567 = and i1 %4564, %4566
  %4568 = sub i32 %4565, 1
  %4569 = select i1 %4567, i32 %4568, i32 0
  %4570 = load i8, ptr %frame.active, align 1
  %4571 = trunc i32 %4569 to i8
  %4572 = shl i8 1, %4571
  %4573 = and i8 %4570, %4572
  %4574 = icmp ne i8 %4573, 0
  %4575 = load <8 x i32>, ptr %frame.static.id, align 32
  %4576 = extractelement <8 x i32> %4575, i32 %4569
  %convergence.target.pointer890 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %4576
  %convergence.dynamic.target891 = load i32, ptr %convergence.target.pointer890, align 4
  %4577 = icmp eq i32 %convergence.dynamic.target891, 46
  %4578 = and i1 %4574, %4577
  %4579 = and i1 %4567, %4578
  %4580 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4569
  %4581 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4569
  %4582 = load <8 x i1>, ptr %4580, align 1
  %4583 = load <8 x i1>, ptr %4581, align 1
  %4584 = or <8 x i1> %4583, %convergence.cascade.flow888
  %4585 = load <8 x i1>, ptr %live.mask, align 1
  %4586 = and <8 x i1> %4582, %4585
  %4587 = icmp eq <8 x i1> %4584, %4586
  %4588 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4587)
  %4589 = and i1 %4579, %4588
  %4590 = select i1 %4589, <8 x i1> zeroinitializer, <8 x i1> %4584
  %4591 = select i1 %4579, <8 x i1> %4590, <8 x i1> %4583
  store <8 x i1> %4591, ptr %4581, align 1
  %4592 = select i1 %4589, <8 x i1> zeroinitializer, <8 x i1> %4582
  store <8 x i1> %4592, ptr %4580, align 1
  %4593 = trunc i32 %4569 to i8
  %4594 = shl i8 1, %4593
  %4595 = xor i8 %4594, -1
  %4596 = and i8 %4570, %4595
  %4597 = select i1 %4589, i8 %4596, i8 %4570
  store i8 %4597, ptr %frame.active, align 1
  %.splatinsert892 = insertelement <8 x i1> poison, i1 %4579, i64 0
  %.splat893 = shufflevector <8 x i1> %.splatinsert892, <8 x i1> poison, <8 x i32> zeroinitializer
  %4598 = and <8 x i1> %convergence.cascade.flow888, %.splat893
  %4599 = load <8 x i1>, ptr %runnable.mask, align 1
  %4600 = xor <8 x i1> %4598, splat (i1 true)
  %4601 = and <8 x i1> %4599, %4600
  store <8 x i1> %4601, ptr %runnable.mask, align 1
  %.splatinsert894 = insertelement <8 x i1> poison, i1 %4589, i64 0
  %.splat895 = shufflevector <8 x i1> %.splatinsert894, <8 x i1> poison, <8 x i32> zeroinitializer
  %4602 = select <8 x i1> %.splat895, <8 x i1> %4584, <8 x i1> zeroinitializer
  %4603 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4604 = extractelement <8 x i32> %4603, i32 %4569
  %4605 = select i1 %4589, i32 %4604, i32 %4565
  store i32 %4605, ptr %current.token, align 4
  %.splatinsert896 = insertelement <8 x i1> poison, i1 %4579, i64 0
  %.splat897 = shufflevector <8 x i1> %.splatinsert896, <8 x i1> poison, <8 x i32> zeroinitializer
  %4606 = select <8 x i1> %.splat897, <8 x i1> %4602, <8 x i1> %convergence.cascade.flow888
  %4607 = add i32 %convergence.cascade.depth889, 1
  %4608 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4606)
  %4609 = icmp ult i32 %4607, 8
  %4610 = and i1 %4608, %4609
  %4611 = and i1 %4579, %4610
  %convergence.parent.token898 = load i32, ptr %current.token, align 4
  %convergence.parent.present899 = icmp ne i32 %convergence.parent.token898, 0
  %4612 = and i1 %4611, %convergence.parent.present899
  br i1 %4612, label %convergence.cascade884, label %convergence.cascade.exit885

convergence.cascade.exit885:                      ; preds = %convergence.cascade884, %schedule.46
  %convergence.cascade.result900 = phi <8 x i1> [ %587, %schedule.46 ], [ %4606, %convergence.cascade884 ]
  %4613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result900)
  br i1 %4613, label %convergence.target.46.ready, label %scheduler.loop

convergence.target.46.ready:                      ; preds = %convergence.cascade.exit885
  %4614 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result900)
  %4615 = bitcast <8 x i1> %convergence.cascade.result900 to i8
  %4616 = call i8 @llvm.cttz.i8(i8 %4615, i1 false)
  %4617 = zext i8 %4616 to i32
  %4618 = select i1 %4614, i32 %4617, i32 0
  %.spill.load901 = load volatile <8 x i64>, ptr %.spill102, align 64
  %.spill.load902 = load i64, ptr %.spill20, align 4
  %.splatinsert903 = insertelement <8 x i64> poison, i64 %.spill.load902, i64 0
  %.splat904 = shufflevector <8 x i64> %.splatinsert903, <8 x i64> poison, <8 x i32> zeroinitializer
  %4619 = add <8 x i64> %.spill.load901, %.splat904
  %4620 = load volatile <8 x i64>, ptr %.spill109, align 64
  %4621 = select <8 x i1> %convergence.cascade.result900, <8 x i64> %4619, <8 x i64> %4620
  store volatile <8 x i64> %4621, ptr %.spill109, align 64
  %.spill.load905 = load <8 x i1>, ptr %.spill77, align 1
  %4622 = and <8 x i1> %convergence.cascade.result900, %.spill.load905
  %4623 = xor <8 x i1> %.spill.load905, splat (i1 true)
  %4624 = and <8 x i1> %convergence.cascade.result900, %4623
  %4625 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4622)
  %4626 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4624)
  %4627 = and i1 %4625, %4626
  br i1 %4627, label %varying.divergent906, label %varying.coherent907

varying.divergent906:                             ; preds = %convergence.target.46.ready
  %4628 = load i32, ptr %current.token, align 4
  %4629 = icmp ne i32 %4628, 0
  %4630 = sub i32 %4628, 1
  %4631 = select i1 %4629, i32 %4630, i32 0
  %4632 = load i8, ptr %frame.active, align 1
  %4633 = trunc i32 %4631 to i8
  %4634 = shl i8 1, %4633
  %4635 = and i8 %4632, %4634
  %4636 = icmp ne i8 %4635, 0
  %4637 = load <8 x i32>, ptr %frame.static.id, align 32
  %4638 = extractelement <8 x i32> %4637, i32 %4631
  %4639 = icmp eq i32 %4638, 23
  %4640 = and i1 %4636, %4639
  %4641 = and i1 %4629, %4640
  %4642 = xor i1 %4641, true
  %4643 = and i1 true, %4642
  %4644 = xor i8 %4632, -1
  %4645 = icmp ne i8 %4644, 0
  %4646 = xor i1 %4645, true
  %4647 = and i1 %4643, %4646
  br i1 %4647, label %convergence.overflow.trap908, label %convergence.overflow.resume909

varying.coherent907:                              ; preds = %convergence.target.46.ready
  br i1 %4625, label %varying.coherent.true912, label %varying.coherent.false913

convergence.overflow.trap908:                     ; preds = %varying.divergent906
  call void @llvm.trap()
  unreachable

convergence.overflow.resume909:                   ; preds = %varying.divergent906
  %4648 = call i8 @llvm.cttz.i8(i8 %4644, i1 false)
  %4649 = zext i8 %4648 to i32
  %4650 = select i1 %4645, i32 %4649, i32 0
  %4651 = trunc i32 %4650 to i8
  %4652 = shl i8 1, %4651
  %4653 = or i8 %4632, %4652
  %4654 = select i1 %4643, i8 %4653, i8 %4632
  store i8 %4654, ptr %frame.active, align 1
  %4655 = load <8 x i32>, ptr %frame.static.id, align 32
  %4656 = extractelement <8 x i32> %4655, i32 %4650
  %4657 = select i1 %4643, i32 23, i32 %4656
  %4658 = load <8 x i32>, ptr %frame.static.id, align 32
  %4659 = insertelement <8 x i32> %4658, i32 %4657, i32 %4650
  store <8 x i32> %4659, ptr %frame.static.id, align 32
  %4660 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4661 = extractelement <8 x i32> %4660, i32 %4650
  %4662 = select i1 %4643, i32 %4628, i32 %4661
  %4663 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4664 = insertelement <8 x i32> %4663, i32 %4662, i32 %4650
  store <8 x i32> %4664, ptr %frame.parent.token, align 32
  %4665 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4650
  %4666 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4650
  %4667 = load <8 x i1>, ptr %4665, align 1
  %4668 = load <8 x i1>, ptr %4666, align 1
  %4669 = select i1 %4643, <8 x i1> %convergence.cascade.result900, <8 x i1> %4667
  store <8 x i1> %4669, ptr %4665, align 1
  %4670 = select i1 %4643, <8 x i1> zeroinitializer, <8 x i1> %4668
  store <8 x i1> %4670, ptr %4666, align 1
  %4671 = add i32 %4650, 1
  %4672 = select i1 %4641, i32 %4628, i32 %4671
  %4673 = select i1 true, i32 %4672, i32 %4628
  store i32 %4673, ptr %current.token, align 4
  %4674 = load <8 x float>, ptr %.slot110, align 32
  %4675 = select <8 x i1> %4624, <8 x float> zeroinitializer, <8 x float> %4674
  store <8 x float> %4675, ptr %.slot110, align 32
  %4676 = load i32, ptr %current.token, align 4
  %4677 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4622)
  %4678 = load i32, ptr %ready.count, align 4
  %4679 = icmp uge i32 %4678, 8
  %4680 = and i1 %4677, %4679
  br i1 %4680, label %ready.overflow.trap910, label %ready.overflow.resume911

ready.overflow.trap910:                           ; preds = %convergence.overflow.resume909
  call void @llvm.trap()
  unreachable

ready.overflow.resume911:                         ; preds = %convergence.overflow.resume909
  %4681 = select i1 %4677, i32 %4678, i32 0
  %4682 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4681
  %4683 = load <8 x i1>, ptr %4682, align 1
  %4684 = select i1 %4677, <8 x i1> %4622, <8 x i1> %4683
  store <8 x i1> %4684, ptr %4682, align 1
  %4685 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4681
  %4686 = load i32, ptr %4685, align 4
  %4687 = select i1 %4677, i32 47, i32 %4686
  store i32 %4687, ptr %4685, align 4
  %4688 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4681
  %4689 = load i32, ptr %4688, align 4
  %4690 = select i1 %4677, i32 %4676, i32 %4689
  store i32 %4690, ptr %4688, align 4
  %4691 = add i32 %4678, 1
  %4692 = select i1 %4677, i32 %4691, i32 %4678
  store i32 %4692, ptr %ready.count, align 4
  %4693 = load <8 x i1>, ptr %runnable.mask, align 1
  %4694 = or <8 x i1> %4693, %4622
  store <8 x i1> %4694, ptr %runnable.mask, align 1
  store <8 x i1> %4624, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true912:                         ; preds = %varying.coherent907
  store <8 x i1> %convergence.cascade.result900, ptr %current.mask, align 1
  %4695 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result900)
  br i1 %4695, label %schedule.47, label %scheduler.loop

varying.coherent.false913:                        ; preds = %varying.coherent907
  %4696 = load <8 x float>, ptr %.slot110, align 32
  %4697 = select <8 x i1> %convergence.cascade.result900, <8 x float> zeroinitializer, <8 x float> %4696
  store <8 x float> %4697, ptr %.slot110, align 32
  store <8 x i1> %convergence.cascade.result900, ptr %current.mask, align 1
  %4698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result900)
  br i1 %4698, label %schedule.48, label %scheduler.loop

convergence.cascade915:                           ; preds = %convergence.cascade915, %schedule.48
  %convergence.cascade.flow919 = phi <8 x i1> [ %601, %schedule.48 ], [ %4741, %convergence.cascade915 ]
  %convergence.cascade.depth920 = phi i32 [ 0, %schedule.48 ], [ %4742, %convergence.cascade915 ]
  %4699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow919)
  %4700 = load i32, ptr %current.token, align 4
  %4701 = icmp ne i32 %4700, 0
  %4702 = and i1 %4699, %4701
  %4703 = sub i32 %4700, 1
  %4704 = select i1 %4702, i32 %4703, i32 0
  %4705 = load i8, ptr %frame.active, align 1
  %4706 = trunc i32 %4704 to i8
  %4707 = shl i8 1, %4706
  %4708 = and i8 %4705, %4707
  %4709 = icmp ne i8 %4708, 0
  %4710 = load <8 x i32>, ptr %frame.static.id, align 32
  %4711 = extractelement <8 x i32> %4710, i32 %4704
  %convergence.target.pointer921 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %4711
  %convergence.dynamic.target922 = load i32, ptr %convergence.target.pointer921, align 4
  %4712 = icmp eq i32 %convergence.dynamic.target922, 48
  %4713 = and i1 %4709, %4712
  %4714 = and i1 %4702, %4713
  %4715 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4704
  %4716 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4704
  %4717 = load <8 x i1>, ptr %4715, align 1
  %4718 = load <8 x i1>, ptr %4716, align 1
  %4719 = or <8 x i1> %4718, %convergence.cascade.flow919
  %4720 = load <8 x i1>, ptr %live.mask, align 1
  %4721 = and <8 x i1> %4717, %4720
  %4722 = icmp eq <8 x i1> %4719, %4721
  %4723 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4722)
  %4724 = and i1 %4714, %4723
  %4725 = select i1 %4724, <8 x i1> zeroinitializer, <8 x i1> %4719
  %4726 = select i1 %4714, <8 x i1> %4725, <8 x i1> %4718
  store <8 x i1> %4726, ptr %4716, align 1
  %4727 = select i1 %4724, <8 x i1> zeroinitializer, <8 x i1> %4717
  store <8 x i1> %4727, ptr %4715, align 1
  %4728 = trunc i32 %4704 to i8
  %4729 = shl i8 1, %4728
  %4730 = xor i8 %4729, -1
  %4731 = and i8 %4705, %4730
  %4732 = select i1 %4724, i8 %4731, i8 %4705
  store i8 %4732, ptr %frame.active, align 1
  %.splatinsert923 = insertelement <8 x i1> poison, i1 %4714, i64 0
  %.splat924 = shufflevector <8 x i1> %.splatinsert923, <8 x i1> poison, <8 x i32> zeroinitializer
  %4733 = and <8 x i1> %convergence.cascade.flow919, %.splat924
  %4734 = load <8 x i1>, ptr %runnable.mask, align 1
  %4735 = xor <8 x i1> %4733, splat (i1 true)
  %4736 = and <8 x i1> %4734, %4735
  store <8 x i1> %4736, ptr %runnable.mask, align 1
  %.splatinsert925 = insertelement <8 x i1> poison, i1 %4724, i64 0
  %.splat926 = shufflevector <8 x i1> %.splatinsert925, <8 x i1> poison, <8 x i32> zeroinitializer
  %4737 = select <8 x i1> %.splat926, <8 x i1> %4719, <8 x i1> zeroinitializer
  %4738 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4739 = extractelement <8 x i32> %4738, i32 %4704
  %4740 = select i1 %4724, i32 %4739, i32 %4700
  store i32 %4740, ptr %current.token, align 4
  %.splatinsert927 = insertelement <8 x i1> poison, i1 %4714, i64 0
  %.splat928 = shufflevector <8 x i1> %.splatinsert927, <8 x i1> poison, <8 x i32> zeroinitializer
  %4741 = select <8 x i1> %.splat928, <8 x i1> %4737, <8 x i1> %convergence.cascade.flow919
  %4742 = add i32 %convergence.cascade.depth920, 1
  %4743 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4741)
  %4744 = icmp ult i32 %4742, 8
  %4745 = and i1 %4743, %4744
  %4746 = and i1 %4714, %4745
  %convergence.parent.token929 = load i32, ptr %current.token, align 4
  %convergence.parent.present930 = icmp ne i32 %convergence.parent.token929, 0
  %4747 = and i1 %4746, %convergence.parent.present930
  br i1 %4747, label %convergence.cascade915, label %convergence.cascade.exit916

convergence.cascade.exit916:                      ; preds = %convergence.cascade915, %schedule.48
  %convergence.cascade.result931 = phi <8 x i1> [ %601, %schedule.48 ], [ %4741, %convergence.cascade915 ]
  %4748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  br i1 %4748, label %convergence.target.48.ready, label %scheduler.loop

convergence.target.48.ready:                      ; preds = %convergence.cascade.exit916
  %4749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %4750 = bitcast <8 x i1> %convergence.cascade.result931 to i8
  %4751 = call i8 @llvm.cttz.i8(i8 %4750, i1 false)
  %4752 = zext i8 %4751 to i32
  %4753 = select i1 %4749, i32 %4752, i32 0
  %.spill.load932 = load volatile <8 x float>, ptr %.spill15, align 32
  %.spill.load933 = load volatile <8 x float>, ptr %.spill54, align 32
  %4754 = fmul <8 x float> %.spill.load932, %.spill.load933
  %.spill.load934 = load volatile <8 x float>, ptr %.spill15, align 32
  %.state935 = load <8 x float>, ptr %.slot65, align 32
  %4755 = fmul <8 x float> %.spill.load934, %.state935
  %.spill.load936 = load volatile <8 x float>, ptr %.spill15, align 32
  %.state937 = load <8 x float>, ptr %.slot80, align 32
  %4756 = fmul <8 x float> %.spill.load936, %.state937
  %.spill.load938 = load volatile <8 x float>, ptr %.spill17, align 32
  %.spill.load939 = load volatile <8 x float>, ptr %.spill55, align 32
  %4757 = fmul <8 x float> %.spill.load938, %.spill.load939
  %.spill.load940 = load volatile <8 x float>, ptr %.spill17, align 32
  %.state941 = load <8 x float>, ptr %.slot67, align 32
  %4758 = fmul <8 x float> %.spill.load940, %.state941
  %.spill.load942 = load volatile <8 x float>, ptr %.spill17, align 32
  %.state943 = load <8 x float>, ptr %.slot82, align 32
  %4759 = fmul <8 x float> %.spill.load942, %.state943
  %.spill.load944 = load volatile <8 x float>, ptr %.spill19, align 32
  %.spill.load945 = load volatile <8 x float>, ptr %.spill56, align 32
  %4760 = fmul <8 x float> %.spill.load944, %.spill.load945
  %.spill.load946 = load volatile <8 x float>, ptr %.spill19, align 32
  %.state947 = load <8 x float>, ptr %.slot69, align 32
  %4761 = fmul <8 x float> %.spill.load946, %.state947
  %.spill.load948 = load volatile <8 x float>, ptr %.spill19, align 32
  %.state949 = load <8 x float>, ptr %.slot84, align 32
  %4762 = fmul <8 x float> %.spill.load948, %.state949
  %.spill.load950 = load volatile <8 x float>, ptr %.spill21, align 32
  %.spill.load951 = load volatile <8 x float>, ptr %.spill57, align 32
  %4763 = fmul <8 x float> %.spill.load950, %.spill.load951
  %.spill.load952 = load volatile <8 x float>, ptr %.spill21, align 32
  %.state953 = load <8 x float>, ptr %.slot71, align 32
  %4764 = fmul <8 x float> %.spill.load952, %.state953
  %.spill.load954 = load volatile <8 x float>, ptr %.spill21, align 32
  %.state955 = load <8 x float>, ptr %.slot86, align 32
  %4765 = fmul <8 x float> %.spill.load954, %.state955
  %.spill.load956 = load volatile <8 x float>, ptr %.spill23, align 32
  %.spill.load957 = load volatile <8 x float>, ptr %.spill58, align 32
  %4766 = fmul <8 x float> %.spill.load956, %.spill.load957
  %.spill.load958 = load volatile <8 x float>, ptr %.spill23, align 32
  %.state959 = load <8 x float>, ptr %.slot73, align 32
  %4767 = fmul <8 x float> %.spill.load958, %.state959
  %.spill.load960 = load volatile <8 x float>, ptr %.spill23, align 32
  %.state961 = load <8 x float>, ptr %.slot88, align 32
  %4768 = fmul <8 x float> %.spill.load960, %.state961
  %.state962 = load <8 x float>, ptr %.slot, align 32
  %.spill.load963 = load volatile <8 x float>, ptr %.spill54, align 32
  %4769 = fmul <8 x float> %.state962, %.spill.load963
  %.state964 = load <8 x float>, ptr %.slot, align 32
  %.state965 = load <8 x float>, ptr %.slot65, align 32
  %4770 = fmul <8 x float> %.state964, %.state965
  %.state966 = load <8 x float>, ptr %.slot, align 32
  %.state967 = load <8 x float>, ptr %.slot80, align 32
  %4771 = fmul <8 x float> %.state966, %.state967
  %.state968 = load <8 x float>, ptr %.slot30, align 32
  %.spill.load969 = load volatile <8 x float>, ptr %.spill55, align 32
  %4772 = fmul <8 x float> %.state968, %.spill.load969
  %.state970 = load <8 x float>, ptr %.slot30, align 32
  %.state971 = load <8 x float>, ptr %.slot67, align 32
  %4773 = fmul <8 x float> %.state970, %.state971
  %.state972 = load <8 x float>, ptr %.slot30, align 32
  %.state973 = load <8 x float>, ptr %.slot82, align 32
  %4774 = fmul <8 x float> %.state972, %.state973
  %.state974 = load <8 x float>, ptr %.slot32, align 32
  %.spill.load975 = load volatile <8 x float>, ptr %.spill56, align 32
  %4775 = fmul <8 x float> %.state974, %.spill.load975
  %.state976 = load <8 x float>, ptr %.slot32, align 32
  %.state977 = load <8 x float>, ptr %.slot69, align 32
  %4776 = fmul <8 x float> %.state976, %.state977
  %.state978 = load <8 x float>, ptr %.slot32, align 32
  %.state979 = load <8 x float>, ptr %.slot84, align 32
  %4777 = fmul <8 x float> %.state978, %.state979
  %.state980 = load <8 x float>, ptr %.slot34, align 32
  %.spill.load981 = load volatile <8 x float>, ptr %.spill57, align 32
  %4778 = fmul <8 x float> %.state980, %.spill.load981
  %.state982 = load <8 x float>, ptr %.slot34, align 32
  %.state983 = load <8 x float>, ptr %.slot71, align 32
  %4779 = fmul <8 x float> %.state982, %.state983
  %.state984 = load <8 x float>, ptr %.slot34, align 32
  %.state985 = load <8 x float>, ptr %.slot86, align 32
  %4780 = fmul <8 x float> %.state984, %.state985
  %.state986 = load <8 x float>, ptr %.slot36, align 32
  %.spill.load987 = load volatile <8 x float>, ptr %.spill58, align 32
  %4781 = fmul <8 x float> %.state986, %.spill.load987
  %.state988 = load <8 x float>, ptr %.slot36, align 32
  %.state989 = load <8 x float>, ptr %.slot73, align 32
  %4782 = fmul <8 x float> %.state988, %.state989
  %.state990 = load <8 x float>, ptr %.slot36, align 32
  %.state991 = load <8 x float>, ptr %.slot88, align 32
  %4783 = fmul <8 x float> %.state990, %.state991
  %4784 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %4785 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4786 = extractvalue { <8 x ptr>, <8 x i64> } %4784, 0
  %4787 = select <8 x i1> %convergence.cascade.result931, <8 x ptr> %4785, <8 x ptr> %4786
  %4788 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %4789 = extractvalue { <8 x ptr>, <8 x i64> } %4784, 1
  %4790 = select <8 x i1> %convergence.cascade.result931, <8 x i64> %4788, <8 x i64> %4789
  %4791 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4787, 0
  %4792 = insertvalue { <8 x ptr>, <8 x i64> } %4791, <8 x i64> %4790, 1
  store { <8 x ptr>, <8 x i64> } %4792, ptr %tile_snapshot.spill, align 64
  %4793 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4794 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %4795 = add <8 x i64> %4794, zeroinitializer
  %4796 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4793, 0
  %4797 = insertvalue { <8 x ptr>, <8 x i64> } %4796, <8 x i64> %4795, 1
  %4798 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4799 = extractvalue { <8 x ptr>, <8 x i64> } %4797, 1
  %4800 = extractelement <8 x ptr> %4798, i32 0
  %4801 = extractelement <8 x i64> %4799, i32 %4753
  %4802 = zext i32 %4753 to i64
  %4803 = mul i64 %4802, 4
  %4804 = sub i64 %4801, %4803
  %4805 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %4806 = select i1 %4805, i64 %4804, i64 0
  %private.contiguous.address = getelementptr i8, ptr %4800, i64 %4806
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %4807 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4754, <8 x float> %private.contiguous.preserve
  store <8 x float> %4807, ptr %private.contiguous.address, align 4
  %4808 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4809 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %4810 = add <8 x i64> %4809, splat (i64 32)
  %4811 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4808, 0
  %4812 = insertvalue { <8 x ptr>, <8 x i64> } %4811, <8 x i64> %4810, 1
  %4813 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4814 = extractvalue { <8 x ptr>, <8 x i64> } %4812, 1
  %4815 = extractelement <8 x ptr> %4813, i32 0
  %4816 = extractelement <8 x i64> %4814, i32 %4753
  %4817 = zext i32 %4753 to i64
  %4818 = mul i64 %4817, 4
  %4819 = sub i64 %4816, %4818
  %4820 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %4821 = select i1 %4820, i64 %4819, i64 0
  %private.contiguous.address992 = getelementptr i8, ptr %4815, i64 %4821
  %private.contiguous.preserve993 = load <8 x float>, ptr %private.contiguous.address992, align 4
  %4822 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4755, <8 x float> %private.contiguous.preserve993
  store <8 x float> %4822, ptr %private.contiguous.address992, align 4
  %4823 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4824 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %4825 = add <8 x i64> %4824, splat (i64 64)
  %4826 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4823, 0
  %4827 = insertvalue { <8 x ptr>, <8 x i64> } %4826, <8 x i64> %4825, 1
  %4828 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4829 = extractvalue { <8 x ptr>, <8 x i64> } %4827, 1
  %4830 = extractelement <8 x ptr> %4828, i32 0
  %4831 = extractelement <8 x i64> %4829, i32 %4753
  %4832 = zext i32 %4753 to i64
  %4833 = mul i64 %4832, 4
  %4834 = sub i64 %4831, %4833
  %4835 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %4836 = select i1 %4835, i64 %4834, i64 0
  %private.contiguous.address994 = getelementptr i8, ptr %4830, i64 %4836
  %private.contiguous.preserve995 = load <8 x float>, ptr %private.contiguous.address994, align 4
  %4837 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4756, <8 x float> %private.contiguous.preserve995
  store <8 x float> %4837, ptr %private.contiguous.address994, align 4
  %4838 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4839 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %4840 = add <8 x i64> %4839, splat (i64 96)
  %4841 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4838, 0
  %4842 = insertvalue { <8 x ptr>, <8 x i64> } %4841, <8 x i64> %4840, 1
  %4843 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4844 = extractvalue { <8 x ptr>, <8 x i64> } %4842, 1
  %4845 = extractelement <8 x ptr> %4843, i32 0
  %4846 = extractelement <8 x i64> %4844, i32 %4753
  %4847 = zext i32 %4753 to i64
  %4848 = mul i64 %4847, 4
  %4849 = sub i64 %4846, %4848
  %4850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %4851 = select i1 %4850, i64 %4849, i64 0
  %private.contiguous.address996 = getelementptr i8, ptr %4845, i64 %4851
  %private.contiguous.preserve997 = load <8 x float>, ptr %private.contiguous.address996, align 4
  %4852 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4757, <8 x float> %private.contiguous.preserve997
  store <8 x float> %4852, ptr %private.contiguous.address996, align 4
  %4853 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4854 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %4855 = add <8 x i64> %4854, splat (i64 128)
  %4856 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4853, 0
  %4857 = insertvalue { <8 x ptr>, <8 x i64> } %4856, <8 x i64> %4855, 1
  %4858 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4859 = extractvalue { <8 x ptr>, <8 x i64> } %4857, 1
  %4860 = extractelement <8 x ptr> %4858, i32 0
  %4861 = extractelement <8 x i64> %4859, i32 %4753
  %4862 = zext i32 %4753 to i64
  %4863 = mul i64 %4862, 4
  %4864 = sub i64 %4861, %4863
  %4865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %4866 = select i1 %4865, i64 %4864, i64 0
  %private.contiguous.address998 = getelementptr i8, ptr %4860, i64 %4866
  %private.contiguous.preserve999 = load <8 x float>, ptr %private.contiguous.address998, align 4
  %4867 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4758, <8 x float> %private.contiguous.preserve999
  store <8 x float> %4867, ptr %private.contiguous.address998, align 4
  %4868 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4869 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %4870 = add <8 x i64> %4869, splat (i64 160)
  %4871 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4868, 0
  %4872 = insertvalue { <8 x ptr>, <8 x i64> } %4871, <8 x i64> %4870, 1
  %4873 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4874 = extractvalue { <8 x ptr>, <8 x i64> } %4872, 1
  %4875 = extractelement <8 x ptr> %4873, i32 0
  %4876 = extractelement <8 x i64> %4874, i32 %4753
  %4877 = zext i32 %4753 to i64
  %4878 = mul i64 %4877, 4
  %4879 = sub i64 %4876, %4878
  %4880 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %4881 = select i1 %4880, i64 %4879, i64 0
  %private.contiguous.address1000 = getelementptr i8, ptr %4875, i64 %4881
  %private.contiguous.preserve1001 = load <8 x float>, ptr %private.contiguous.address1000, align 4
  %4882 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4759, <8 x float> %private.contiguous.preserve1001
  store <8 x float> %4882, ptr %private.contiguous.address1000, align 4
  %4883 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4884 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %4885 = add <8 x i64> %4884, splat (i64 192)
  %4886 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4883, 0
  %4887 = insertvalue { <8 x ptr>, <8 x i64> } %4886, <8 x i64> %4885, 1
  %4888 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4889 = extractvalue { <8 x ptr>, <8 x i64> } %4887, 1
  %4890 = extractelement <8 x ptr> %4888, i32 0
  %4891 = extractelement <8 x i64> %4889, i32 %4753
  %4892 = zext i32 %4753 to i64
  %4893 = mul i64 %4892, 4
  %4894 = sub i64 %4891, %4893
  %4895 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %4896 = select i1 %4895, i64 %4894, i64 0
  %private.contiguous.address1002 = getelementptr i8, ptr %4890, i64 %4896
  %private.contiguous.preserve1003 = load <8 x float>, ptr %private.contiguous.address1002, align 4
  %4897 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4760, <8 x float> %private.contiguous.preserve1003
  store <8 x float> %4897, ptr %private.contiguous.address1002, align 4
  %4898 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4899 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %4900 = add <8 x i64> %4899, splat (i64 224)
  %4901 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4898, 0
  %4902 = insertvalue { <8 x ptr>, <8 x i64> } %4901, <8 x i64> %4900, 1
  %4903 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4904 = extractvalue { <8 x ptr>, <8 x i64> } %4902, 1
  %4905 = extractelement <8 x ptr> %4903, i32 0
  %4906 = extractelement <8 x i64> %4904, i32 %4753
  %4907 = zext i32 %4753 to i64
  %4908 = mul i64 %4907, 4
  %4909 = sub i64 %4906, %4908
  %4910 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %4911 = select i1 %4910, i64 %4909, i64 0
  %private.contiguous.address1004 = getelementptr i8, ptr %4905, i64 %4911
  %private.contiguous.preserve1005 = load <8 x float>, ptr %private.contiguous.address1004, align 4
  %4912 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4761, <8 x float> %private.contiguous.preserve1005
  store <8 x float> %4912, ptr %private.contiguous.address1004, align 4
  %4913 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4914 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %4915 = add <8 x i64> %4914, splat (i64 256)
  %4916 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4913, 0
  %4917 = insertvalue { <8 x ptr>, <8 x i64> } %4916, <8 x i64> %4915, 1
  %4918 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4919 = extractvalue { <8 x ptr>, <8 x i64> } %4917, 1
  %4920 = extractelement <8 x ptr> %4918, i32 0
  %4921 = extractelement <8 x i64> %4919, i32 %4753
  %4922 = zext i32 %4753 to i64
  %4923 = mul i64 %4922, 4
  %4924 = sub i64 %4921, %4923
  %4925 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %4926 = select i1 %4925, i64 %4924, i64 0
  %private.contiguous.address1006 = getelementptr i8, ptr %4920, i64 %4926
  %private.contiguous.preserve1007 = load <8 x float>, ptr %private.contiguous.address1006, align 4
  %4927 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4762, <8 x float> %private.contiguous.preserve1007
  store <8 x float> %4927, ptr %private.contiguous.address1006, align 4
  %4928 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4929 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %4930 = add <8 x i64> %4929, splat (i64 288)
  %4931 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4928, 0
  %4932 = insertvalue { <8 x ptr>, <8 x i64> } %4931, <8 x i64> %4930, 1
  %4933 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4934 = extractvalue { <8 x ptr>, <8 x i64> } %4932, 1
  %4935 = extractelement <8 x ptr> %4933, i32 0
  %4936 = extractelement <8 x i64> %4934, i32 %4753
  %4937 = zext i32 %4753 to i64
  %4938 = mul i64 %4937, 4
  %4939 = sub i64 %4936, %4938
  %4940 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %4941 = select i1 %4940, i64 %4939, i64 0
  %private.contiguous.address1008 = getelementptr i8, ptr %4935, i64 %4941
  %private.contiguous.preserve1009 = load <8 x float>, ptr %private.contiguous.address1008, align 4
  %4942 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4763, <8 x float> %private.contiguous.preserve1009
  store <8 x float> %4942, ptr %private.contiguous.address1008, align 4
  %4943 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4944 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %4945 = add <8 x i64> %4944, splat (i64 320)
  %4946 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4943, 0
  %4947 = insertvalue { <8 x ptr>, <8 x i64> } %4946, <8 x i64> %4945, 1
  %4948 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4949 = extractvalue { <8 x ptr>, <8 x i64> } %4947, 1
  %4950 = extractelement <8 x ptr> %4948, i32 0
  %4951 = extractelement <8 x i64> %4949, i32 %4753
  %4952 = zext i32 %4753 to i64
  %4953 = mul i64 %4952, 4
  %4954 = sub i64 %4951, %4953
  %4955 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %4956 = select i1 %4955, i64 %4954, i64 0
  %private.contiguous.address1010 = getelementptr i8, ptr %4950, i64 %4956
  %private.contiguous.preserve1011 = load <8 x float>, ptr %private.contiguous.address1010, align 4
  %4957 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4764, <8 x float> %private.contiguous.preserve1011
  store <8 x float> %4957, ptr %private.contiguous.address1010, align 4
  %4958 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4959 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %4960 = add <8 x i64> %4959, splat (i64 352)
  %4961 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4958, 0
  %4962 = insertvalue { <8 x ptr>, <8 x i64> } %4961, <8 x i64> %4960, 1
  %4963 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4964 = extractvalue { <8 x ptr>, <8 x i64> } %4962, 1
  %4965 = extractelement <8 x ptr> %4963, i32 0
  %4966 = extractelement <8 x i64> %4964, i32 %4753
  %4967 = zext i32 %4753 to i64
  %4968 = mul i64 %4967, 4
  %4969 = sub i64 %4966, %4968
  %4970 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %4971 = select i1 %4970, i64 %4969, i64 0
  %private.contiguous.address1012 = getelementptr i8, ptr %4965, i64 %4971
  %private.contiguous.preserve1013 = load <8 x float>, ptr %private.contiguous.address1012, align 4
  %4972 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4765, <8 x float> %private.contiguous.preserve1013
  store <8 x float> %4972, ptr %private.contiguous.address1012, align 4
  %4973 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4974 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %4975 = add <8 x i64> %4974, splat (i64 384)
  %4976 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4973, 0
  %4977 = insertvalue { <8 x ptr>, <8 x i64> } %4976, <8 x i64> %4975, 1
  %4978 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4979 = extractvalue { <8 x ptr>, <8 x i64> } %4977, 1
  %4980 = extractelement <8 x ptr> %4978, i32 0
  %4981 = extractelement <8 x i64> %4979, i32 %4753
  %4982 = zext i32 %4753 to i64
  %4983 = mul i64 %4982, 4
  %4984 = sub i64 %4981, %4983
  %4985 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %4986 = select i1 %4985, i64 %4984, i64 0
  %private.contiguous.address1014 = getelementptr i8, ptr %4980, i64 %4986
  %private.contiguous.preserve1015 = load <8 x float>, ptr %private.contiguous.address1014, align 4
  %4987 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4766, <8 x float> %private.contiguous.preserve1015
  store <8 x float> %4987, ptr %private.contiguous.address1014, align 4
  %4988 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4989 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %4990 = add <8 x i64> %4989, splat (i64 416)
  %4991 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4988, 0
  %4992 = insertvalue { <8 x ptr>, <8 x i64> } %4991, <8 x i64> %4990, 1
  %4993 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %4994 = extractvalue { <8 x ptr>, <8 x i64> } %4992, 1
  %4995 = extractelement <8 x ptr> %4993, i32 0
  %4996 = extractelement <8 x i64> %4994, i32 %4753
  %4997 = zext i32 %4753 to i64
  %4998 = mul i64 %4997, 4
  %4999 = sub i64 %4996, %4998
  %5000 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5001 = select i1 %5000, i64 %4999, i64 0
  %private.contiguous.address1016 = getelementptr i8, ptr %4995, i64 %5001
  %private.contiguous.preserve1017 = load <8 x float>, ptr %private.contiguous.address1016, align 4
  %5002 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4767, <8 x float> %private.contiguous.preserve1017
  store <8 x float> %5002, ptr %private.contiguous.address1016, align 4
  %5003 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5004 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5005 = add <8 x i64> %5004, splat (i64 448)
  %5006 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5003, 0
  %5007 = insertvalue { <8 x ptr>, <8 x i64> } %5006, <8 x i64> %5005, 1
  %5008 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5009 = extractvalue { <8 x ptr>, <8 x i64> } %5007, 1
  %5010 = extractelement <8 x ptr> %5008, i32 0
  %5011 = extractelement <8 x i64> %5009, i32 %4753
  %5012 = zext i32 %4753 to i64
  %5013 = mul i64 %5012, 4
  %5014 = sub i64 %5011, %5013
  %5015 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5016 = select i1 %5015, i64 %5014, i64 0
  %private.contiguous.address1018 = getelementptr i8, ptr %5010, i64 %5016
  %private.contiguous.preserve1019 = load <8 x float>, ptr %private.contiguous.address1018, align 4
  %5017 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4768, <8 x float> %private.contiguous.preserve1019
  store <8 x float> %5017, ptr %private.contiguous.address1018, align 4
  %5018 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5019 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5020 = add <8 x i64> %5019, splat (i64 480)
  %5021 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5018, 0
  %5022 = insertvalue { <8 x ptr>, <8 x i64> } %5021, <8 x i64> %5020, 1
  %5023 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5024 = extractvalue { <8 x ptr>, <8 x i64> } %5022, 1
  %5025 = extractelement <8 x ptr> %5023, i32 0
  %5026 = extractelement <8 x i64> %5024, i32 %4753
  %5027 = zext i32 %4753 to i64
  %5028 = mul i64 %5027, 4
  %5029 = sub i64 %5026, %5028
  %5030 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5031 = select i1 %5030, i64 %5029, i64 0
  %private.contiguous.address1020 = getelementptr i8, ptr %5025, i64 %5031
  %private.contiguous.preserve1021 = load <8 x float>, ptr %private.contiguous.address1020, align 4
  %5032 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4769, <8 x float> %private.contiguous.preserve1021
  store <8 x float> %5032, ptr %private.contiguous.address1020, align 4
  %5033 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5034 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5035 = add <8 x i64> %5034, splat (i64 512)
  %5036 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5033, 0
  %5037 = insertvalue { <8 x ptr>, <8 x i64> } %5036, <8 x i64> %5035, 1
  %5038 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5039 = extractvalue { <8 x ptr>, <8 x i64> } %5037, 1
  %5040 = extractelement <8 x ptr> %5038, i32 0
  %5041 = extractelement <8 x i64> %5039, i32 %4753
  %5042 = zext i32 %4753 to i64
  %5043 = mul i64 %5042, 4
  %5044 = sub i64 %5041, %5043
  %5045 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5046 = select i1 %5045, i64 %5044, i64 0
  %private.contiguous.address1022 = getelementptr i8, ptr %5040, i64 %5046
  %private.contiguous.preserve1023 = load <8 x float>, ptr %private.contiguous.address1022, align 4
  %5047 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4770, <8 x float> %private.contiguous.preserve1023
  store <8 x float> %5047, ptr %private.contiguous.address1022, align 4
  %5048 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5049 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5050 = add <8 x i64> %5049, splat (i64 544)
  %5051 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5048, 0
  %5052 = insertvalue { <8 x ptr>, <8 x i64> } %5051, <8 x i64> %5050, 1
  %5053 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5054 = extractvalue { <8 x ptr>, <8 x i64> } %5052, 1
  %5055 = extractelement <8 x ptr> %5053, i32 0
  %5056 = extractelement <8 x i64> %5054, i32 %4753
  %5057 = zext i32 %4753 to i64
  %5058 = mul i64 %5057, 4
  %5059 = sub i64 %5056, %5058
  %5060 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5061 = select i1 %5060, i64 %5059, i64 0
  %private.contiguous.address1024 = getelementptr i8, ptr %5055, i64 %5061
  %private.contiguous.preserve1025 = load <8 x float>, ptr %private.contiguous.address1024, align 4
  %5062 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4771, <8 x float> %private.contiguous.preserve1025
  store <8 x float> %5062, ptr %private.contiguous.address1024, align 4
  %5063 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5064 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5065 = add <8 x i64> %5064, splat (i64 576)
  %5066 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5063, 0
  %5067 = insertvalue { <8 x ptr>, <8 x i64> } %5066, <8 x i64> %5065, 1
  %5068 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5069 = extractvalue { <8 x ptr>, <8 x i64> } %5067, 1
  %5070 = extractelement <8 x ptr> %5068, i32 0
  %5071 = extractelement <8 x i64> %5069, i32 %4753
  %5072 = zext i32 %4753 to i64
  %5073 = mul i64 %5072, 4
  %5074 = sub i64 %5071, %5073
  %5075 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5076 = select i1 %5075, i64 %5074, i64 0
  %private.contiguous.address1026 = getelementptr i8, ptr %5070, i64 %5076
  %private.contiguous.preserve1027 = load <8 x float>, ptr %private.contiguous.address1026, align 4
  %5077 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4772, <8 x float> %private.contiguous.preserve1027
  store <8 x float> %5077, ptr %private.contiguous.address1026, align 4
  %5078 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5079 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5080 = add <8 x i64> %5079, splat (i64 608)
  %5081 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5078, 0
  %5082 = insertvalue { <8 x ptr>, <8 x i64> } %5081, <8 x i64> %5080, 1
  %5083 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5084 = extractvalue { <8 x ptr>, <8 x i64> } %5082, 1
  %5085 = extractelement <8 x ptr> %5083, i32 0
  %5086 = extractelement <8 x i64> %5084, i32 %4753
  %5087 = zext i32 %4753 to i64
  %5088 = mul i64 %5087, 4
  %5089 = sub i64 %5086, %5088
  %5090 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5091 = select i1 %5090, i64 %5089, i64 0
  %private.contiguous.address1028 = getelementptr i8, ptr %5085, i64 %5091
  %private.contiguous.preserve1029 = load <8 x float>, ptr %private.contiguous.address1028, align 4
  %5092 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4773, <8 x float> %private.contiguous.preserve1029
  store <8 x float> %5092, ptr %private.contiguous.address1028, align 4
  %5093 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5094 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5095 = add <8 x i64> %5094, splat (i64 640)
  %5096 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5093, 0
  %5097 = insertvalue { <8 x ptr>, <8 x i64> } %5096, <8 x i64> %5095, 1
  %5098 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5099 = extractvalue { <8 x ptr>, <8 x i64> } %5097, 1
  %5100 = extractelement <8 x ptr> %5098, i32 0
  %5101 = extractelement <8 x i64> %5099, i32 %4753
  %5102 = zext i32 %4753 to i64
  %5103 = mul i64 %5102, 4
  %5104 = sub i64 %5101, %5103
  %5105 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5106 = select i1 %5105, i64 %5104, i64 0
  %private.contiguous.address1030 = getelementptr i8, ptr %5100, i64 %5106
  %private.contiguous.preserve1031 = load <8 x float>, ptr %private.contiguous.address1030, align 4
  %5107 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4774, <8 x float> %private.contiguous.preserve1031
  store <8 x float> %5107, ptr %private.contiguous.address1030, align 4
  %5108 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5109 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5110 = add <8 x i64> %5109, splat (i64 672)
  %5111 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5108, 0
  %5112 = insertvalue { <8 x ptr>, <8 x i64> } %5111, <8 x i64> %5110, 1
  %5113 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5114 = extractvalue { <8 x ptr>, <8 x i64> } %5112, 1
  %5115 = extractelement <8 x ptr> %5113, i32 0
  %5116 = extractelement <8 x i64> %5114, i32 %4753
  %5117 = zext i32 %4753 to i64
  %5118 = mul i64 %5117, 4
  %5119 = sub i64 %5116, %5118
  %5120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5121 = select i1 %5120, i64 %5119, i64 0
  %private.contiguous.address1032 = getelementptr i8, ptr %5115, i64 %5121
  %private.contiguous.preserve1033 = load <8 x float>, ptr %private.contiguous.address1032, align 4
  %5122 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4775, <8 x float> %private.contiguous.preserve1033
  store <8 x float> %5122, ptr %private.contiguous.address1032, align 4
  %5123 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5124 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5125 = add <8 x i64> %5124, splat (i64 704)
  %5126 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5123, 0
  %5127 = insertvalue { <8 x ptr>, <8 x i64> } %5126, <8 x i64> %5125, 1
  %5128 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5129 = extractvalue { <8 x ptr>, <8 x i64> } %5127, 1
  %5130 = extractelement <8 x ptr> %5128, i32 0
  %5131 = extractelement <8 x i64> %5129, i32 %4753
  %5132 = zext i32 %4753 to i64
  %5133 = mul i64 %5132, 4
  %5134 = sub i64 %5131, %5133
  %5135 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5136 = select i1 %5135, i64 %5134, i64 0
  %private.contiguous.address1034 = getelementptr i8, ptr %5130, i64 %5136
  %private.contiguous.preserve1035 = load <8 x float>, ptr %private.contiguous.address1034, align 4
  %5137 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4776, <8 x float> %private.contiguous.preserve1035
  store <8 x float> %5137, ptr %private.contiguous.address1034, align 4
  %5138 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5139 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5140 = add <8 x i64> %5139, splat (i64 736)
  %5141 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5138, 0
  %5142 = insertvalue { <8 x ptr>, <8 x i64> } %5141, <8 x i64> %5140, 1
  %5143 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5144 = extractvalue { <8 x ptr>, <8 x i64> } %5142, 1
  %5145 = extractelement <8 x ptr> %5143, i32 0
  %5146 = extractelement <8 x i64> %5144, i32 %4753
  %5147 = zext i32 %4753 to i64
  %5148 = mul i64 %5147, 4
  %5149 = sub i64 %5146, %5148
  %5150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5151 = select i1 %5150, i64 %5149, i64 0
  %private.contiguous.address1036 = getelementptr i8, ptr %5145, i64 %5151
  %private.contiguous.preserve1037 = load <8 x float>, ptr %private.contiguous.address1036, align 4
  %5152 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4777, <8 x float> %private.contiguous.preserve1037
  store <8 x float> %5152, ptr %private.contiguous.address1036, align 4
  %5153 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5154 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5155 = add <8 x i64> %5154, splat (i64 768)
  %5156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5153, 0
  %5157 = insertvalue { <8 x ptr>, <8 x i64> } %5156, <8 x i64> %5155, 1
  %5158 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5159 = extractvalue { <8 x ptr>, <8 x i64> } %5157, 1
  %5160 = extractelement <8 x ptr> %5158, i32 0
  %5161 = extractelement <8 x i64> %5159, i32 %4753
  %5162 = zext i32 %4753 to i64
  %5163 = mul i64 %5162, 4
  %5164 = sub i64 %5161, %5163
  %5165 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5166 = select i1 %5165, i64 %5164, i64 0
  %private.contiguous.address1038 = getelementptr i8, ptr %5160, i64 %5166
  %private.contiguous.preserve1039 = load <8 x float>, ptr %private.contiguous.address1038, align 4
  %5167 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4778, <8 x float> %private.contiguous.preserve1039
  store <8 x float> %5167, ptr %private.contiguous.address1038, align 4
  %5168 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5169 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5170 = add <8 x i64> %5169, splat (i64 800)
  %5171 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5168, 0
  %5172 = insertvalue { <8 x ptr>, <8 x i64> } %5171, <8 x i64> %5170, 1
  %5173 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5174 = extractvalue { <8 x ptr>, <8 x i64> } %5172, 1
  %5175 = extractelement <8 x ptr> %5173, i32 0
  %5176 = extractelement <8 x i64> %5174, i32 %4753
  %5177 = zext i32 %4753 to i64
  %5178 = mul i64 %5177, 4
  %5179 = sub i64 %5176, %5178
  %5180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5181 = select i1 %5180, i64 %5179, i64 0
  %private.contiguous.address1040 = getelementptr i8, ptr %5175, i64 %5181
  %private.contiguous.preserve1041 = load <8 x float>, ptr %private.contiguous.address1040, align 4
  %5182 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4779, <8 x float> %private.contiguous.preserve1041
  store <8 x float> %5182, ptr %private.contiguous.address1040, align 4
  %5183 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5184 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5185 = add <8 x i64> %5184, splat (i64 832)
  %5186 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5183, 0
  %5187 = insertvalue { <8 x ptr>, <8 x i64> } %5186, <8 x i64> %5185, 1
  %5188 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5189 = extractvalue { <8 x ptr>, <8 x i64> } %5187, 1
  %5190 = extractelement <8 x ptr> %5188, i32 0
  %5191 = extractelement <8 x i64> %5189, i32 %4753
  %5192 = zext i32 %4753 to i64
  %5193 = mul i64 %5192, 4
  %5194 = sub i64 %5191, %5193
  %5195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5196 = select i1 %5195, i64 %5194, i64 0
  %private.contiguous.address1042 = getelementptr i8, ptr %5190, i64 %5196
  %private.contiguous.preserve1043 = load <8 x float>, ptr %private.contiguous.address1042, align 4
  %5197 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4780, <8 x float> %private.contiguous.preserve1043
  store <8 x float> %5197, ptr %private.contiguous.address1042, align 4
  %5198 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5199 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5200 = add <8 x i64> %5199, splat (i64 864)
  %5201 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5198, 0
  %5202 = insertvalue { <8 x ptr>, <8 x i64> } %5201, <8 x i64> %5200, 1
  %5203 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5204 = extractvalue { <8 x ptr>, <8 x i64> } %5202, 1
  %5205 = extractelement <8 x ptr> %5203, i32 0
  %5206 = extractelement <8 x i64> %5204, i32 %4753
  %5207 = zext i32 %4753 to i64
  %5208 = mul i64 %5207, 4
  %5209 = sub i64 %5206, %5208
  %5210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5211 = select i1 %5210, i64 %5209, i64 0
  %private.contiguous.address1044 = getelementptr i8, ptr %5205, i64 %5211
  %private.contiguous.preserve1045 = load <8 x float>, ptr %private.contiguous.address1044, align 4
  %5212 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4781, <8 x float> %private.contiguous.preserve1045
  store <8 x float> %5212, ptr %private.contiguous.address1044, align 4
  %5213 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5214 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5215 = add <8 x i64> %5214, splat (i64 896)
  %5216 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5213, 0
  %5217 = insertvalue { <8 x ptr>, <8 x i64> } %5216, <8 x i64> %5215, 1
  %5218 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5219 = extractvalue { <8 x ptr>, <8 x i64> } %5217, 1
  %5220 = extractelement <8 x ptr> %5218, i32 0
  %5221 = extractelement <8 x i64> %5219, i32 %4753
  %5222 = zext i32 %4753 to i64
  %5223 = mul i64 %5222, 4
  %5224 = sub i64 %5221, %5223
  %5225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5226 = select i1 %5225, i64 %5224, i64 0
  %private.contiguous.address1046 = getelementptr i8, ptr %5220, i64 %5226
  %private.contiguous.preserve1047 = load <8 x float>, ptr %private.contiguous.address1046, align 4
  %5227 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4782, <8 x float> %private.contiguous.preserve1047
  store <8 x float> %5227, ptr %private.contiguous.address1046, align 4
  %5228 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5229 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %5230 = add <8 x i64> %5229, splat (i64 928)
  %5231 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5228, 0
  %5232 = insertvalue { <8 x ptr>, <8 x i64> } %5231, <8 x i64> %5230, 1
  %5233 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %5234 = extractvalue { <8 x ptr>, <8 x i64> } %5232, 1
  %5235 = extractelement <8 x ptr> %5233, i32 0
  %5236 = extractelement <8 x i64> %5234, i32 %4753
  %5237 = zext i32 %4753 to i64
  %5238 = mul i64 %5237, 4
  %5239 = sub i64 %5236, %5238
  %5240 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  %5241 = select i1 %5240, i64 %5239, i64 0
  %private.contiguous.address1048 = getelementptr i8, ptr %5235, i64 %5241
  %private.contiguous.preserve1049 = load <8 x float>, ptr %private.contiguous.address1048, align 4
  %5242 = select <8 x i1> %convergence.cascade.result931, <8 x float> %4783, <8 x float> %private.contiguous.preserve1049
  store <8 x float> %5242, ptr %private.contiguous.address1048, align 4
  %5243 = load <8 x i64>, ptr %.slot111, align 64
  %5244 = select <8 x i1> %convergence.cascade.result931, <8 x i64> zeroinitializer, <8 x i64> %5243
  store <8 x i64> %5244, ptr %.slot111, align 64
  %5245 = load <8 x float>, ptr %.slot112, align 32
  %5246 = select <8 x i1> %convergence.cascade.result931, <8 x float> zeroinitializer, <8 x float> %5245
  store <8 x float> %5246, ptr %.slot112, align 32
  store <8 x i1> %convergence.cascade.result931, ptr %current.mask, align 1
  %5247 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result931)
  br i1 %5247, label %schedule.49, label %scheduler.loop

varying.divergent1051:                            ; preds = %schedule.49
  %5248 = load i32, ptr %current.token, align 4
  %5249 = icmp ne i32 %5248, 0
  %5250 = sub i32 %5248, 1
  %5251 = select i1 %5249, i32 %5250, i32 0
  %5252 = load i8, ptr %frame.active, align 1
  %5253 = trunc i32 %5251 to i8
  %5254 = shl i8 1, %5253
  %5255 = and i8 %5252, %5254
  %5256 = icmp ne i8 %5255, 0
  %5257 = load <8 x i32>, ptr %frame.static.id, align 32
  %5258 = extractelement <8 x i32> %5257, i32 %5251
  %5259 = icmp eq i32 %5258, 24
  %5260 = and i1 %5256, %5259
  %5261 = and i1 %5249, %5260
  %5262 = xor i1 %5261, true
  %5263 = and i1 true, %5262
  %5264 = xor i8 %5252, -1
  %5265 = icmp ne i8 %5264, 0
  %5266 = xor i1 %5265, true
  %5267 = and i1 %5263, %5266
  br i1 %5267, label %convergence.overflow.trap1053, label %convergence.overflow.resume1054

varying.coherent1052:                             ; preds = %schedule.49
  br i1 %612, label %varying.coherent.true1057, label %varying.coherent.false1058

convergence.overflow.trap1053:                    ; preds = %varying.divergent1051
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1054:                  ; preds = %varying.divergent1051
  %5268 = call i8 @llvm.cttz.i8(i8 %5264, i1 false)
  %5269 = zext i8 %5268 to i32
  %5270 = select i1 %5265, i32 %5269, i32 0
  %5271 = trunc i32 %5270 to i8
  %5272 = shl i8 1, %5271
  %5273 = or i8 %5252, %5272
  %5274 = select i1 %5263, i8 %5273, i8 %5252
  store i8 %5274, ptr %frame.active, align 1
  %5275 = load <8 x i32>, ptr %frame.static.id, align 32
  %5276 = extractelement <8 x i32> %5275, i32 %5270
  %5277 = select i1 %5263, i32 24, i32 %5276
  %5278 = load <8 x i32>, ptr %frame.static.id, align 32
  %5279 = insertelement <8 x i32> %5278, i32 %5277, i32 %5270
  store <8 x i32> %5279, ptr %frame.static.id, align 32
  %5280 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5281 = extractelement <8 x i32> %5280, i32 %5270
  %5282 = select i1 %5263, i32 %5248, i32 %5281
  %5283 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5284 = insertelement <8 x i32> %5283, i32 %5282, i32 %5270
  store <8 x i32> %5284, ptr %frame.parent.token, align 32
  %5285 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5270
  %5286 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5270
  %5287 = load <8 x i1>, ptr %5285, align 1
  %5288 = load <8 x i1>, ptr %5286, align 1
  %5289 = select i1 %5263, <8 x i1> %602, <8 x i1> %5287
  store <8 x i1> %5289, ptr %5285, align 1
  %5290 = select i1 %5263, <8 x i1> zeroinitializer, <8 x i1> %5288
  store <8 x i1> %5290, ptr %5286, align 1
  %5291 = add i32 %5270, 1
  %5292 = select i1 %5261, i32 %5248, i32 %5291
  %5293 = select i1 true, i32 %5292, i32 %5248
  store i32 %5293, ptr %current.token, align 4
  %5294 = load i32, ptr %current.token, align 4
  %5295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %609)
  %5296 = load i32, ptr %ready.count, align 4
  %5297 = icmp uge i32 %5296, 8
  %5298 = and i1 %5295, %5297
  br i1 %5298, label %ready.overflow.trap1055, label %ready.overflow.resume1056

ready.overflow.trap1055:                          ; preds = %convergence.overflow.resume1054
  call void @llvm.trap()
  unreachable

ready.overflow.resume1056:                        ; preds = %convergence.overflow.resume1054
  %5299 = select i1 %5295, i32 %5296, i32 0
  %5300 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5299
  %5301 = load <8 x i1>, ptr %5300, align 1
  %5302 = select i1 %5295, <8 x i1> %609, <8 x i1> %5301
  store <8 x i1> %5302, ptr %5300, align 1
  %5303 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5299
  %5304 = load i32, ptr %5303, align 4
  %5305 = select i1 %5295, i32 50, i32 %5304
  store i32 %5305, ptr %5303, align 4
  %5306 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5299
  %5307 = load i32, ptr %5306, align 4
  %5308 = select i1 %5295, i32 %5294, i32 %5307
  store i32 %5308, ptr %5306, align 4
  %5309 = add i32 %5296, 1
  %5310 = select i1 %5295, i32 %5309, i32 %5296
  store i32 %5310, ptr %ready.count, align 4
  %5311 = load <8 x i1>, ptr %runnable.mask, align 1
  %5312 = or <8 x i1> %5311, %609
  store <8 x i1> %5312, ptr %runnable.mask, align 1
  store <8 x i1> %611, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1057:                        ; preds = %varying.coherent1052
  store <8 x i1> %602, ptr %current.mask, align 1
  %5313 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %602)
  br i1 %5313, label %schedule.50, label %scheduler.loop

varying.coherent.false1058:                       ; preds = %varying.coherent1052
  store <8 x i1> %602, ptr %current.mask, align 1
  %5314 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %602)
  br i1 %5314, label %schedule.51, label %scheduler.loop

convergence.cascade1065:                          ; preds = %convergence.cascade1065, %schedule.51
  %convergence.cascade.flow1069 = phi <8 x i1> [ %650, %schedule.51 ], [ %5357, %convergence.cascade1065 ]
  %convergence.cascade.depth1070 = phi i32 [ 0, %schedule.51 ], [ %5358, %convergence.cascade1065 ]
  %5315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1069)
  %5316 = load i32, ptr %current.token, align 4
  %5317 = icmp ne i32 %5316, 0
  %5318 = and i1 %5315, %5317
  %5319 = sub i32 %5316, 1
  %5320 = select i1 %5318, i32 %5319, i32 0
  %5321 = load i8, ptr %frame.active, align 1
  %5322 = trunc i32 %5320 to i8
  %5323 = shl i8 1, %5322
  %5324 = and i8 %5321, %5323
  %5325 = icmp ne i8 %5324, 0
  %5326 = load <8 x i32>, ptr %frame.static.id, align 32
  %5327 = extractelement <8 x i32> %5326, i32 %5320
  %convergence.target.pointer1071 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %5327
  %convergence.dynamic.target1072 = load i32, ptr %convergence.target.pointer1071, align 4
  %5328 = icmp eq i32 %convergence.dynamic.target1072, 51
  %5329 = and i1 %5325, %5328
  %5330 = and i1 %5318, %5329
  %5331 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5320
  %5332 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5320
  %5333 = load <8 x i1>, ptr %5331, align 1
  %5334 = load <8 x i1>, ptr %5332, align 1
  %5335 = or <8 x i1> %5334, %convergence.cascade.flow1069
  %5336 = load <8 x i1>, ptr %live.mask, align 1
  %5337 = and <8 x i1> %5333, %5336
  %5338 = icmp eq <8 x i1> %5335, %5337
  %5339 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5338)
  %5340 = and i1 %5330, %5339
  %5341 = select i1 %5340, <8 x i1> zeroinitializer, <8 x i1> %5335
  %5342 = select i1 %5330, <8 x i1> %5341, <8 x i1> %5334
  store <8 x i1> %5342, ptr %5332, align 1
  %5343 = select i1 %5340, <8 x i1> zeroinitializer, <8 x i1> %5333
  store <8 x i1> %5343, ptr %5331, align 1
  %5344 = trunc i32 %5320 to i8
  %5345 = shl i8 1, %5344
  %5346 = xor i8 %5345, -1
  %5347 = and i8 %5321, %5346
  %5348 = select i1 %5340, i8 %5347, i8 %5321
  store i8 %5348, ptr %frame.active, align 1
  %.splatinsert1073 = insertelement <8 x i1> poison, i1 %5330, i64 0
  %.splat1074 = shufflevector <8 x i1> %.splatinsert1073, <8 x i1> poison, <8 x i32> zeroinitializer
  %5349 = and <8 x i1> %convergence.cascade.flow1069, %.splat1074
  %5350 = load <8 x i1>, ptr %runnable.mask, align 1
  %5351 = xor <8 x i1> %5349, splat (i1 true)
  %5352 = and <8 x i1> %5350, %5351
  store <8 x i1> %5352, ptr %runnable.mask, align 1
  %.splatinsert1075 = insertelement <8 x i1> poison, i1 %5340, i64 0
  %.splat1076 = shufflevector <8 x i1> %.splatinsert1075, <8 x i1> poison, <8 x i32> zeroinitializer
  %5353 = select <8 x i1> %.splat1076, <8 x i1> %5335, <8 x i1> zeroinitializer
  %5354 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5355 = extractelement <8 x i32> %5354, i32 %5320
  %5356 = select i1 %5340, i32 %5355, i32 %5316
  store i32 %5356, ptr %current.token, align 4
  %.splatinsert1077 = insertelement <8 x i1> poison, i1 %5330, i64 0
  %.splat1078 = shufflevector <8 x i1> %.splatinsert1077, <8 x i1> poison, <8 x i32> zeroinitializer
  %5357 = select <8 x i1> %.splat1078, <8 x i1> %5353, <8 x i1> %convergence.cascade.flow1069
  %5358 = add i32 %convergence.cascade.depth1070, 1
  %5359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5357)
  %5360 = icmp ult i32 %5358, 8
  %5361 = and i1 %5359, %5360
  %5362 = and i1 %5330, %5361
  %convergence.parent.token1079 = load i32, ptr %current.token, align 4
  %convergence.parent.present1080 = icmp ne i32 %convergence.parent.token1079, 0
  %5363 = and i1 %5362, %convergence.parent.present1080
  br i1 %5363, label %convergence.cascade1065, label %convergence.cascade.exit1066

convergence.cascade.exit1066:                     ; preds = %convergence.cascade1065, %schedule.51
  %convergence.cascade.result1081 = phi <8 x i1> [ %650, %schedule.51 ], [ %5357, %convergence.cascade1065 ]
  %5364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1081)
  br i1 %5364, label %convergence.target.51.ready, label %scheduler.loop

convergence.target.51.ready:                      ; preds = %convergence.cascade.exit1066
  %5365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1081)
  %5366 = bitcast <8 x i1> %convergence.cascade.result1081 to i8
  %5367 = call i8 @llvm.cttz.i8(i8 %5366, i1 false)
  %5368 = zext i8 %5367 to i32
  %5369 = select i1 %5365, i32 %5368, i32 0
  %5370 = load <8 x i64>, ptr %.slot113, align 64
  %5371 = select <8 x i1> %convergence.cascade.result1081, <8 x i64> zeroinitializer, <8 x i64> %5370
  store <8 x i64> %5371, ptr %.slot113, align 64
  %5372 = load <8 x float>, ptr %.slot114, align 32
  %5373 = select <8 x i1> %convergence.cascade.result1081, <8 x float> zeroinitializer, <8 x float> %5372
  store <8 x float> %5373, ptr %.slot114, align 32
  store <8 x i1> %convergence.cascade.result1081, ptr %current.mask, align 1
  %5374 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1081)
  br i1 %5374, label %schedule.52, label %scheduler.loop

varying.divergent1083:                            ; preds = %schedule.52
  %5375 = load i32, ptr %current.token, align 4
  %5376 = icmp ne i32 %5375, 0
  %5377 = sub i32 %5375, 1
  %5378 = select i1 %5376, i32 %5377, i32 0
  %5379 = load i8, ptr %frame.active, align 1
  %5380 = trunc i32 %5378 to i8
  %5381 = shl i8 1, %5380
  %5382 = and i8 %5379, %5381
  %5383 = icmp ne i8 %5382, 0
  %5384 = load <8 x i32>, ptr %frame.static.id, align 32
  %5385 = extractelement <8 x i32> %5384, i32 %5378
  %5386 = icmp eq i32 %5385, 25
  %5387 = and i1 %5383, %5386
  %5388 = and i1 %5376, %5387
  %5389 = xor i1 %5388, true
  %5390 = and i1 true, %5389
  %5391 = xor i8 %5379, -1
  %5392 = icmp ne i8 %5391, 0
  %5393 = xor i1 %5392, true
  %5394 = and i1 %5390, %5393
  br i1 %5394, label %convergence.overflow.trap1085, label %convergence.overflow.resume1086

varying.coherent1084:                             ; preds = %schedule.52
  br i1 %661, label %varying.coherent.true1089, label %varying.coherent.false1090

convergence.overflow.trap1085:                    ; preds = %varying.divergent1083
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1086:                  ; preds = %varying.divergent1083
  %5395 = call i8 @llvm.cttz.i8(i8 %5391, i1 false)
  %5396 = zext i8 %5395 to i32
  %5397 = select i1 %5392, i32 %5396, i32 0
  %5398 = trunc i32 %5397 to i8
  %5399 = shl i8 1, %5398
  %5400 = or i8 %5379, %5399
  %5401 = select i1 %5390, i8 %5400, i8 %5379
  store i8 %5401, ptr %frame.active, align 1
  %5402 = load <8 x i32>, ptr %frame.static.id, align 32
  %5403 = extractelement <8 x i32> %5402, i32 %5397
  %5404 = select i1 %5390, i32 25, i32 %5403
  %5405 = load <8 x i32>, ptr %frame.static.id, align 32
  %5406 = insertelement <8 x i32> %5405, i32 %5404, i32 %5397
  store <8 x i32> %5406, ptr %frame.static.id, align 32
  %5407 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5408 = extractelement <8 x i32> %5407, i32 %5397
  %5409 = select i1 %5390, i32 %5375, i32 %5408
  %5410 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5411 = insertelement <8 x i32> %5410, i32 %5409, i32 %5397
  store <8 x i32> %5411, ptr %frame.parent.token, align 32
  %5412 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5397
  %5413 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5397
  %5414 = load <8 x i1>, ptr %5412, align 1
  %5415 = load <8 x i1>, ptr %5413, align 1
  %5416 = select i1 %5390, <8 x i1> %651, <8 x i1> %5414
  store <8 x i1> %5416, ptr %5412, align 1
  %5417 = select i1 %5390, <8 x i1> zeroinitializer, <8 x i1> %5415
  store <8 x i1> %5417, ptr %5413, align 1
  %5418 = add i32 %5397, 1
  %5419 = select i1 %5388, i32 %5375, i32 %5418
  %5420 = select i1 true, i32 %5419, i32 %5375
  store i32 %5420, ptr %current.token, align 4
  %5421 = load i32, ptr %current.token, align 4
  %5422 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %658)
  %5423 = load i32, ptr %ready.count, align 4
  %5424 = icmp uge i32 %5423, 8
  %5425 = and i1 %5422, %5424
  br i1 %5425, label %ready.overflow.trap1087, label %ready.overflow.resume1088

ready.overflow.trap1087:                          ; preds = %convergence.overflow.resume1086
  call void @llvm.trap()
  unreachable

ready.overflow.resume1088:                        ; preds = %convergence.overflow.resume1086
  %5426 = select i1 %5422, i32 %5423, i32 0
  %5427 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5426
  %5428 = load <8 x i1>, ptr %5427, align 1
  %5429 = select i1 %5422, <8 x i1> %658, <8 x i1> %5428
  store <8 x i1> %5429, ptr %5427, align 1
  %5430 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5426
  %5431 = load i32, ptr %5430, align 4
  %5432 = select i1 %5422, i32 53, i32 %5431
  store i32 %5432, ptr %5430, align 4
  %5433 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5426
  %5434 = load i32, ptr %5433, align 4
  %5435 = select i1 %5422, i32 %5421, i32 %5434
  store i32 %5435, ptr %5433, align 4
  %5436 = add i32 %5423, 1
  %5437 = select i1 %5422, i32 %5436, i32 %5423
  store i32 %5437, ptr %ready.count, align 4
  %5438 = load <8 x i1>, ptr %runnable.mask, align 1
  %5439 = or <8 x i1> %5438, %658
  store <8 x i1> %5439, ptr %runnable.mask, align 1
  store <8 x i1> %660, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1089:                        ; preds = %varying.coherent1084
  store <8 x i1> %651, ptr %current.mask, align 1
  %5440 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %651)
  br i1 %5440, label %schedule.53, label %scheduler.loop

varying.coherent.false1090:                       ; preds = %varying.coherent1084
  store <8 x i1> %651, ptr %current.mask, align 1
  %5441 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %651)
  br i1 %5441, label %schedule.54, label %scheduler.loop

convergence.cascade1098:                          ; preds = %convergence.cascade1098, %schedule.54
  %convergence.cascade.flow1102 = phi <8 x i1> [ %699, %schedule.54 ], [ %5484, %convergence.cascade1098 ]
  %convergence.cascade.depth1103 = phi i32 [ 0, %schedule.54 ], [ %5485, %convergence.cascade1098 ]
  %5442 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1102)
  %5443 = load i32, ptr %current.token, align 4
  %5444 = icmp ne i32 %5443, 0
  %5445 = and i1 %5442, %5444
  %5446 = sub i32 %5443, 1
  %5447 = select i1 %5445, i32 %5446, i32 0
  %5448 = load i8, ptr %frame.active, align 1
  %5449 = trunc i32 %5447 to i8
  %5450 = shl i8 1, %5449
  %5451 = and i8 %5448, %5450
  %5452 = icmp ne i8 %5451, 0
  %5453 = load <8 x i32>, ptr %frame.static.id, align 32
  %5454 = extractelement <8 x i32> %5453, i32 %5447
  %convergence.target.pointer1104 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %5454
  %convergence.dynamic.target1105 = load i32, ptr %convergence.target.pointer1104, align 4
  %5455 = icmp eq i32 %convergence.dynamic.target1105, 54
  %5456 = and i1 %5452, %5455
  %5457 = and i1 %5445, %5456
  %5458 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5447
  %5459 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5447
  %5460 = load <8 x i1>, ptr %5458, align 1
  %5461 = load <8 x i1>, ptr %5459, align 1
  %5462 = or <8 x i1> %5461, %convergence.cascade.flow1102
  %5463 = load <8 x i1>, ptr %live.mask, align 1
  %5464 = and <8 x i1> %5460, %5463
  %5465 = icmp eq <8 x i1> %5462, %5464
  %5466 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5465)
  %5467 = and i1 %5457, %5466
  %5468 = select i1 %5467, <8 x i1> zeroinitializer, <8 x i1> %5462
  %5469 = select i1 %5457, <8 x i1> %5468, <8 x i1> %5461
  store <8 x i1> %5469, ptr %5459, align 1
  %5470 = select i1 %5467, <8 x i1> zeroinitializer, <8 x i1> %5460
  store <8 x i1> %5470, ptr %5458, align 1
  %5471 = trunc i32 %5447 to i8
  %5472 = shl i8 1, %5471
  %5473 = xor i8 %5472, -1
  %5474 = and i8 %5448, %5473
  %5475 = select i1 %5467, i8 %5474, i8 %5448
  store i8 %5475, ptr %frame.active, align 1
  %.splatinsert1106 = insertelement <8 x i1> poison, i1 %5457, i64 0
  %.splat1107 = shufflevector <8 x i1> %.splatinsert1106, <8 x i1> poison, <8 x i32> zeroinitializer
  %5476 = and <8 x i1> %convergence.cascade.flow1102, %.splat1107
  %5477 = load <8 x i1>, ptr %runnable.mask, align 1
  %5478 = xor <8 x i1> %5476, splat (i1 true)
  %5479 = and <8 x i1> %5477, %5478
  store <8 x i1> %5479, ptr %runnable.mask, align 1
  %.splatinsert1108 = insertelement <8 x i1> poison, i1 %5467, i64 0
  %.splat1109 = shufflevector <8 x i1> %.splatinsert1108, <8 x i1> poison, <8 x i32> zeroinitializer
  %5480 = select <8 x i1> %.splat1109, <8 x i1> %5462, <8 x i1> zeroinitializer
  %5481 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5482 = extractelement <8 x i32> %5481, i32 %5447
  %5483 = select i1 %5467, i32 %5482, i32 %5443
  store i32 %5483, ptr %current.token, align 4
  %.splatinsert1110 = insertelement <8 x i1> poison, i1 %5457, i64 0
  %.splat1111 = shufflevector <8 x i1> %.splatinsert1110, <8 x i1> poison, <8 x i32> zeroinitializer
  %5484 = select <8 x i1> %.splat1111, <8 x i1> %5480, <8 x i1> %convergence.cascade.flow1102
  %5485 = add i32 %convergence.cascade.depth1103, 1
  %5486 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5484)
  %5487 = icmp ult i32 %5485, 8
  %5488 = and i1 %5486, %5487
  %5489 = and i1 %5457, %5488
  %convergence.parent.token1112 = load i32, ptr %current.token, align 4
  %convergence.parent.present1113 = icmp ne i32 %convergence.parent.token1112, 0
  %5490 = and i1 %5489, %convergence.parent.present1113
  br i1 %5490, label %convergence.cascade1098, label %convergence.cascade.exit1099

convergence.cascade.exit1099:                     ; preds = %convergence.cascade1098, %schedule.54
  %convergence.cascade.result1114 = phi <8 x i1> [ %699, %schedule.54 ], [ %5484, %convergence.cascade1098 ]
  %5491 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1114)
  br i1 %5491, label %convergence.target.54.ready, label %scheduler.loop

convergence.target.54.ready:                      ; preds = %convergence.cascade.exit1099
  %5492 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1114)
  %5493 = bitcast <8 x i1> %convergence.cascade.result1114 to i8
  %5494 = call i8 @llvm.cttz.i8(i8 %5493, i1 false)
  %5495 = zext i8 %5494 to i32
  %5496 = select i1 %5492, i32 %5495, i32 0
  %5497 = load <8 x i64>, ptr %.slot115, align 64
  %5498 = select <8 x i1> %convergence.cascade.result1114, <8 x i64> zeroinitializer, <8 x i64> %5497
  store <8 x i64> %5498, ptr %.slot115, align 64
  %5499 = load <8 x float>, ptr %.slot116, align 32
  %5500 = select <8 x i1> %convergence.cascade.result1114, <8 x float> zeroinitializer, <8 x float> %5499
  store <8 x float> %5500, ptr %.slot116, align 32
  store <8 x i1> %convergence.cascade.result1114, ptr %current.mask, align 1
  %5501 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1114)
  br i1 %5501, label %schedule.55, label %scheduler.loop

varying.divergent1116:                            ; preds = %schedule.55
  %5502 = load i32, ptr %current.token, align 4
  %5503 = icmp ne i32 %5502, 0
  %5504 = sub i32 %5502, 1
  %5505 = select i1 %5503, i32 %5504, i32 0
  %5506 = load i8, ptr %frame.active, align 1
  %5507 = trunc i32 %5505 to i8
  %5508 = shl i8 1, %5507
  %5509 = and i8 %5506, %5508
  %5510 = icmp ne i8 %5509, 0
  %5511 = load <8 x i32>, ptr %frame.static.id, align 32
  %5512 = extractelement <8 x i32> %5511, i32 %5505
  %5513 = icmp eq i32 %5512, 26
  %5514 = and i1 %5510, %5513
  %5515 = and i1 %5503, %5514
  %5516 = xor i1 %5515, true
  %5517 = and i1 true, %5516
  %5518 = xor i8 %5506, -1
  %5519 = icmp ne i8 %5518, 0
  %5520 = xor i1 %5519, true
  %5521 = and i1 %5517, %5520
  br i1 %5521, label %convergence.overflow.trap1118, label %convergence.overflow.resume1119

varying.coherent1117:                             ; preds = %schedule.55
  br i1 %710, label %varying.coherent.true1122, label %varying.coherent.false1123

convergence.overflow.trap1118:                    ; preds = %varying.divergent1116
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1119:                  ; preds = %varying.divergent1116
  %5522 = call i8 @llvm.cttz.i8(i8 %5518, i1 false)
  %5523 = zext i8 %5522 to i32
  %5524 = select i1 %5519, i32 %5523, i32 0
  %5525 = trunc i32 %5524 to i8
  %5526 = shl i8 1, %5525
  %5527 = or i8 %5506, %5526
  %5528 = select i1 %5517, i8 %5527, i8 %5506
  store i8 %5528, ptr %frame.active, align 1
  %5529 = load <8 x i32>, ptr %frame.static.id, align 32
  %5530 = extractelement <8 x i32> %5529, i32 %5524
  %5531 = select i1 %5517, i32 26, i32 %5530
  %5532 = load <8 x i32>, ptr %frame.static.id, align 32
  %5533 = insertelement <8 x i32> %5532, i32 %5531, i32 %5524
  store <8 x i32> %5533, ptr %frame.static.id, align 32
  %5534 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5535 = extractelement <8 x i32> %5534, i32 %5524
  %5536 = select i1 %5517, i32 %5502, i32 %5535
  %5537 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5538 = insertelement <8 x i32> %5537, i32 %5536, i32 %5524
  store <8 x i32> %5538, ptr %frame.parent.token, align 32
  %5539 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5524
  %5540 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5524
  %5541 = load <8 x i1>, ptr %5539, align 1
  %5542 = load <8 x i1>, ptr %5540, align 1
  %5543 = select i1 %5517, <8 x i1> %700, <8 x i1> %5541
  store <8 x i1> %5543, ptr %5539, align 1
  %5544 = select i1 %5517, <8 x i1> zeroinitializer, <8 x i1> %5542
  store <8 x i1> %5544, ptr %5540, align 1
  %5545 = add i32 %5524, 1
  %5546 = select i1 %5515, i32 %5502, i32 %5545
  %5547 = select i1 true, i32 %5546, i32 %5502
  store i32 %5547, ptr %current.token, align 4
  %5548 = load i32, ptr %current.token, align 4
  %5549 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %707)
  %5550 = load i32, ptr %ready.count, align 4
  %5551 = icmp uge i32 %5550, 8
  %5552 = and i1 %5549, %5551
  br i1 %5552, label %ready.overflow.trap1120, label %ready.overflow.resume1121

ready.overflow.trap1120:                          ; preds = %convergence.overflow.resume1119
  call void @llvm.trap()
  unreachable

ready.overflow.resume1121:                        ; preds = %convergence.overflow.resume1119
  %5553 = select i1 %5549, i32 %5550, i32 0
  %5554 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5553
  %5555 = load <8 x i1>, ptr %5554, align 1
  %5556 = select i1 %5549, <8 x i1> %707, <8 x i1> %5555
  store <8 x i1> %5556, ptr %5554, align 1
  %5557 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5553
  %5558 = load i32, ptr %5557, align 4
  %5559 = select i1 %5549, i32 56, i32 %5558
  store i32 %5559, ptr %5557, align 4
  %5560 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5553
  %5561 = load i32, ptr %5560, align 4
  %5562 = select i1 %5549, i32 %5548, i32 %5561
  store i32 %5562, ptr %5560, align 4
  %5563 = add i32 %5550, 1
  %5564 = select i1 %5549, i32 %5563, i32 %5550
  store i32 %5564, ptr %ready.count, align 4
  %5565 = load <8 x i1>, ptr %runnable.mask, align 1
  %5566 = or <8 x i1> %5565, %707
  store <8 x i1> %5566, ptr %runnable.mask, align 1
  store <8 x i1> %709, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1122:                        ; preds = %varying.coherent1117
  store <8 x i1> %700, ptr %current.mask, align 1
  %5567 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %700)
  br i1 %5567, label %schedule.56, label %scheduler.loop

varying.coherent.false1123:                       ; preds = %varying.coherent1117
  store <8 x i1> %700, ptr %current.mask, align 1
  %5568 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %700)
  br i1 %5568, label %schedule.57, label %scheduler.loop

convergence.cascade1131:                          ; preds = %convergence.cascade1131, %schedule.57
  %convergence.cascade.flow1135 = phi <8 x i1> [ %748, %schedule.57 ], [ %5611, %convergence.cascade1131 ]
  %convergence.cascade.depth1136 = phi i32 [ 0, %schedule.57 ], [ %5612, %convergence.cascade1131 ]
  %5569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1135)
  %5570 = load i32, ptr %current.token, align 4
  %5571 = icmp ne i32 %5570, 0
  %5572 = and i1 %5569, %5571
  %5573 = sub i32 %5570, 1
  %5574 = select i1 %5572, i32 %5573, i32 0
  %5575 = load i8, ptr %frame.active, align 1
  %5576 = trunc i32 %5574 to i8
  %5577 = shl i8 1, %5576
  %5578 = and i8 %5575, %5577
  %5579 = icmp ne i8 %5578, 0
  %5580 = load <8 x i32>, ptr %frame.static.id, align 32
  %5581 = extractelement <8 x i32> %5580, i32 %5574
  %convergence.target.pointer1137 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %5581
  %convergence.dynamic.target1138 = load i32, ptr %convergence.target.pointer1137, align 4
  %5582 = icmp eq i32 %convergence.dynamic.target1138, 57
  %5583 = and i1 %5579, %5582
  %5584 = and i1 %5572, %5583
  %5585 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5574
  %5586 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5574
  %5587 = load <8 x i1>, ptr %5585, align 1
  %5588 = load <8 x i1>, ptr %5586, align 1
  %5589 = or <8 x i1> %5588, %convergence.cascade.flow1135
  %5590 = load <8 x i1>, ptr %live.mask, align 1
  %5591 = and <8 x i1> %5587, %5590
  %5592 = icmp eq <8 x i1> %5589, %5591
  %5593 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5592)
  %5594 = and i1 %5584, %5593
  %5595 = select i1 %5594, <8 x i1> zeroinitializer, <8 x i1> %5589
  %5596 = select i1 %5584, <8 x i1> %5595, <8 x i1> %5588
  store <8 x i1> %5596, ptr %5586, align 1
  %5597 = select i1 %5594, <8 x i1> zeroinitializer, <8 x i1> %5587
  store <8 x i1> %5597, ptr %5585, align 1
  %5598 = trunc i32 %5574 to i8
  %5599 = shl i8 1, %5598
  %5600 = xor i8 %5599, -1
  %5601 = and i8 %5575, %5600
  %5602 = select i1 %5594, i8 %5601, i8 %5575
  store i8 %5602, ptr %frame.active, align 1
  %.splatinsert1139 = insertelement <8 x i1> poison, i1 %5584, i64 0
  %.splat1140 = shufflevector <8 x i1> %.splatinsert1139, <8 x i1> poison, <8 x i32> zeroinitializer
  %5603 = and <8 x i1> %convergence.cascade.flow1135, %.splat1140
  %5604 = load <8 x i1>, ptr %runnable.mask, align 1
  %5605 = xor <8 x i1> %5603, splat (i1 true)
  %5606 = and <8 x i1> %5604, %5605
  store <8 x i1> %5606, ptr %runnable.mask, align 1
  %.splatinsert1141 = insertelement <8 x i1> poison, i1 %5594, i64 0
  %.splat1142 = shufflevector <8 x i1> %.splatinsert1141, <8 x i1> poison, <8 x i32> zeroinitializer
  %5607 = select <8 x i1> %.splat1142, <8 x i1> %5589, <8 x i1> zeroinitializer
  %5608 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5609 = extractelement <8 x i32> %5608, i32 %5574
  %5610 = select i1 %5594, i32 %5609, i32 %5570
  store i32 %5610, ptr %current.token, align 4
  %.splatinsert1143 = insertelement <8 x i1> poison, i1 %5584, i64 0
  %.splat1144 = shufflevector <8 x i1> %.splatinsert1143, <8 x i1> poison, <8 x i32> zeroinitializer
  %5611 = select <8 x i1> %.splat1144, <8 x i1> %5607, <8 x i1> %convergence.cascade.flow1135
  %5612 = add i32 %convergence.cascade.depth1136, 1
  %5613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5611)
  %5614 = icmp ult i32 %5612, 8
  %5615 = and i1 %5613, %5614
  %5616 = and i1 %5584, %5615
  %convergence.parent.token1145 = load i32, ptr %current.token, align 4
  %convergence.parent.present1146 = icmp ne i32 %convergence.parent.token1145, 0
  %5617 = and i1 %5616, %convergence.parent.present1146
  br i1 %5617, label %convergence.cascade1131, label %convergence.cascade.exit1132

convergence.cascade.exit1132:                     ; preds = %convergence.cascade1131, %schedule.57
  %convergence.cascade.result1147 = phi <8 x i1> [ %748, %schedule.57 ], [ %5611, %convergence.cascade1131 ]
  %5618 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1147)
  br i1 %5618, label %convergence.target.57.ready, label %scheduler.loop

convergence.target.57.ready:                      ; preds = %convergence.cascade.exit1132
  %5619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1147)
  %5620 = bitcast <8 x i1> %convergence.cascade.result1147 to i8
  %5621 = call i8 @llvm.cttz.i8(i8 %5620, i1 false)
  %5622 = zext i8 %5621 to i32
  %5623 = select i1 %5619, i32 %5622, i32 0
  %5624 = load <8 x i64>, ptr %.slot117, align 64
  %5625 = select <8 x i1> %convergence.cascade.result1147, <8 x i64> zeroinitializer, <8 x i64> %5624
  store <8 x i64> %5625, ptr %.slot117, align 64
  %5626 = load <8 x float>, ptr %.slot118, align 32
  %5627 = select <8 x i1> %convergence.cascade.result1147, <8 x float> zeroinitializer, <8 x float> %5626
  store <8 x float> %5627, ptr %.slot118, align 32
  store <8 x i1> %convergence.cascade.result1147, ptr %current.mask, align 1
  %5628 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1147)
  br i1 %5628, label %schedule.58, label %scheduler.loop

varying.divergent1149:                            ; preds = %schedule.58
  %5629 = load i32, ptr %current.token, align 4
  %5630 = icmp ne i32 %5629, 0
  %5631 = sub i32 %5629, 1
  %5632 = select i1 %5630, i32 %5631, i32 0
  %5633 = load i8, ptr %frame.active, align 1
  %5634 = trunc i32 %5632 to i8
  %5635 = shl i8 1, %5634
  %5636 = and i8 %5633, %5635
  %5637 = icmp ne i8 %5636, 0
  %5638 = load <8 x i32>, ptr %frame.static.id, align 32
  %5639 = extractelement <8 x i32> %5638, i32 %5632
  %5640 = icmp eq i32 %5639, 27
  %5641 = and i1 %5637, %5640
  %5642 = and i1 %5630, %5641
  %5643 = xor i1 %5642, true
  %5644 = and i1 true, %5643
  %5645 = xor i8 %5633, -1
  %5646 = icmp ne i8 %5645, 0
  %5647 = xor i1 %5646, true
  %5648 = and i1 %5644, %5647
  br i1 %5648, label %convergence.overflow.trap1151, label %convergence.overflow.resume1152

varying.coherent1150:                             ; preds = %schedule.58
  br i1 %759, label %varying.coherent.true1155, label %varying.coherent.false1156

convergence.overflow.trap1151:                    ; preds = %varying.divergent1149
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1152:                  ; preds = %varying.divergent1149
  %5649 = call i8 @llvm.cttz.i8(i8 %5645, i1 false)
  %5650 = zext i8 %5649 to i32
  %5651 = select i1 %5646, i32 %5650, i32 0
  %5652 = trunc i32 %5651 to i8
  %5653 = shl i8 1, %5652
  %5654 = or i8 %5633, %5653
  %5655 = select i1 %5644, i8 %5654, i8 %5633
  store i8 %5655, ptr %frame.active, align 1
  %5656 = load <8 x i32>, ptr %frame.static.id, align 32
  %5657 = extractelement <8 x i32> %5656, i32 %5651
  %5658 = select i1 %5644, i32 27, i32 %5657
  %5659 = load <8 x i32>, ptr %frame.static.id, align 32
  %5660 = insertelement <8 x i32> %5659, i32 %5658, i32 %5651
  store <8 x i32> %5660, ptr %frame.static.id, align 32
  %5661 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5662 = extractelement <8 x i32> %5661, i32 %5651
  %5663 = select i1 %5644, i32 %5629, i32 %5662
  %5664 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5665 = insertelement <8 x i32> %5664, i32 %5663, i32 %5651
  store <8 x i32> %5665, ptr %frame.parent.token, align 32
  %5666 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5651
  %5667 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5651
  %5668 = load <8 x i1>, ptr %5666, align 1
  %5669 = load <8 x i1>, ptr %5667, align 1
  %5670 = select i1 %5644, <8 x i1> %749, <8 x i1> %5668
  store <8 x i1> %5670, ptr %5666, align 1
  %5671 = select i1 %5644, <8 x i1> zeroinitializer, <8 x i1> %5669
  store <8 x i1> %5671, ptr %5667, align 1
  %5672 = add i32 %5651, 1
  %5673 = select i1 %5642, i32 %5629, i32 %5672
  %5674 = select i1 true, i32 %5673, i32 %5629
  store i32 %5674, ptr %current.token, align 4
  %5675 = load i32, ptr %current.token, align 4
  %5676 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %756)
  %5677 = load i32, ptr %ready.count, align 4
  %5678 = icmp uge i32 %5677, 8
  %5679 = and i1 %5676, %5678
  br i1 %5679, label %ready.overflow.trap1153, label %ready.overflow.resume1154

ready.overflow.trap1153:                          ; preds = %convergence.overflow.resume1152
  call void @llvm.trap()
  unreachable

ready.overflow.resume1154:                        ; preds = %convergence.overflow.resume1152
  %5680 = select i1 %5676, i32 %5677, i32 0
  %5681 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5680
  %5682 = load <8 x i1>, ptr %5681, align 1
  %5683 = select i1 %5676, <8 x i1> %756, <8 x i1> %5682
  store <8 x i1> %5683, ptr %5681, align 1
  %5684 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5680
  %5685 = load i32, ptr %5684, align 4
  %5686 = select i1 %5676, i32 59, i32 %5685
  store i32 %5686, ptr %5684, align 4
  %5687 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5680
  %5688 = load i32, ptr %5687, align 4
  %5689 = select i1 %5676, i32 %5675, i32 %5688
  store i32 %5689, ptr %5687, align 4
  %5690 = add i32 %5677, 1
  %5691 = select i1 %5676, i32 %5690, i32 %5677
  store i32 %5691, ptr %ready.count, align 4
  %5692 = load <8 x i1>, ptr %runnable.mask, align 1
  %5693 = or <8 x i1> %5692, %756
  store <8 x i1> %5693, ptr %runnable.mask, align 1
  store <8 x i1> %758, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1155:                        ; preds = %varying.coherent1150
  store <8 x i1> %749, ptr %current.mask, align 1
  %5694 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %749)
  br i1 %5694, label %schedule.59, label %scheduler.loop

varying.coherent.false1156:                       ; preds = %varying.coherent1150
  store <8 x i1> %749, ptr %current.mask, align 1
  %5695 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %749)
  br i1 %5695, label %schedule.60, label %scheduler.loop

convergence.cascade1164:                          ; preds = %convergence.cascade1164, %schedule.60
  %convergence.cascade.flow1168 = phi <8 x i1> [ %797, %schedule.60 ], [ %5738, %convergence.cascade1164 ]
  %convergence.cascade.depth1169 = phi i32 [ 0, %schedule.60 ], [ %5739, %convergence.cascade1164 ]
  %5696 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1168)
  %5697 = load i32, ptr %current.token, align 4
  %5698 = icmp ne i32 %5697, 0
  %5699 = and i1 %5696, %5698
  %5700 = sub i32 %5697, 1
  %5701 = select i1 %5699, i32 %5700, i32 0
  %5702 = load i8, ptr %frame.active, align 1
  %5703 = trunc i32 %5701 to i8
  %5704 = shl i8 1, %5703
  %5705 = and i8 %5702, %5704
  %5706 = icmp ne i8 %5705, 0
  %5707 = load <8 x i32>, ptr %frame.static.id, align 32
  %5708 = extractelement <8 x i32> %5707, i32 %5701
  %convergence.target.pointer1170 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %5708
  %convergence.dynamic.target1171 = load i32, ptr %convergence.target.pointer1170, align 4
  %5709 = icmp eq i32 %convergence.dynamic.target1171, 60
  %5710 = and i1 %5706, %5709
  %5711 = and i1 %5699, %5710
  %5712 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5701
  %5713 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5701
  %5714 = load <8 x i1>, ptr %5712, align 1
  %5715 = load <8 x i1>, ptr %5713, align 1
  %5716 = or <8 x i1> %5715, %convergence.cascade.flow1168
  %5717 = load <8 x i1>, ptr %live.mask, align 1
  %5718 = and <8 x i1> %5714, %5717
  %5719 = icmp eq <8 x i1> %5716, %5718
  %5720 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5719)
  %5721 = and i1 %5711, %5720
  %5722 = select i1 %5721, <8 x i1> zeroinitializer, <8 x i1> %5716
  %5723 = select i1 %5711, <8 x i1> %5722, <8 x i1> %5715
  store <8 x i1> %5723, ptr %5713, align 1
  %5724 = select i1 %5721, <8 x i1> zeroinitializer, <8 x i1> %5714
  store <8 x i1> %5724, ptr %5712, align 1
  %5725 = trunc i32 %5701 to i8
  %5726 = shl i8 1, %5725
  %5727 = xor i8 %5726, -1
  %5728 = and i8 %5702, %5727
  %5729 = select i1 %5721, i8 %5728, i8 %5702
  store i8 %5729, ptr %frame.active, align 1
  %.splatinsert1172 = insertelement <8 x i1> poison, i1 %5711, i64 0
  %.splat1173 = shufflevector <8 x i1> %.splatinsert1172, <8 x i1> poison, <8 x i32> zeroinitializer
  %5730 = and <8 x i1> %convergence.cascade.flow1168, %.splat1173
  %5731 = load <8 x i1>, ptr %runnable.mask, align 1
  %5732 = xor <8 x i1> %5730, splat (i1 true)
  %5733 = and <8 x i1> %5731, %5732
  store <8 x i1> %5733, ptr %runnable.mask, align 1
  %.splatinsert1174 = insertelement <8 x i1> poison, i1 %5721, i64 0
  %.splat1175 = shufflevector <8 x i1> %.splatinsert1174, <8 x i1> poison, <8 x i32> zeroinitializer
  %5734 = select <8 x i1> %.splat1175, <8 x i1> %5716, <8 x i1> zeroinitializer
  %5735 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5736 = extractelement <8 x i32> %5735, i32 %5701
  %5737 = select i1 %5721, i32 %5736, i32 %5697
  store i32 %5737, ptr %current.token, align 4
  %.splatinsert1176 = insertelement <8 x i1> poison, i1 %5711, i64 0
  %.splat1177 = shufflevector <8 x i1> %.splatinsert1176, <8 x i1> poison, <8 x i32> zeroinitializer
  %5738 = select <8 x i1> %.splat1177, <8 x i1> %5734, <8 x i1> %convergence.cascade.flow1168
  %5739 = add i32 %convergence.cascade.depth1169, 1
  %5740 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5738)
  %5741 = icmp ult i32 %5739, 8
  %5742 = and i1 %5740, %5741
  %5743 = and i1 %5711, %5742
  %convergence.parent.token1178 = load i32, ptr %current.token, align 4
  %convergence.parent.present1179 = icmp ne i32 %convergence.parent.token1178, 0
  %5744 = and i1 %5743, %convergence.parent.present1179
  br i1 %5744, label %convergence.cascade1164, label %convergence.cascade.exit1165

convergence.cascade.exit1165:                     ; preds = %convergence.cascade1164, %schedule.60
  %convergence.cascade.result1180 = phi <8 x i1> [ %797, %schedule.60 ], [ %5738, %convergence.cascade1164 ]
  %5745 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1180)
  br i1 %5745, label %convergence.target.60.ready, label %scheduler.loop

convergence.target.60.ready:                      ; preds = %convergence.cascade.exit1165
  %5746 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1180)
  %5747 = bitcast <8 x i1> %convergence.cascade.result1180 to i8
  %5748 = call i8 @llvm.cttz.i8(i8 %5747, i1 false)
  %5749 = zext i8 %5748 to i32
  %5750 = select i1 %5746, i32 %5749, i32 0
  %5751 = load <8 x i64>, ptr %.slot119, align 64
  %5752 = select <8 x i1> %convergence.cascade.result1180, <8 x i64> zeroinitializer, <8 x i64> %5751
  store <8 x i64> %5752, ptr %.slot119, align 64
  %5753 = load <8 x float>, ptr %.slot120, align 32
  %5754 = select <8 x i1> %convergence.cascade.result1180, <8 x float> zeroinitializer, <8 x float> %5753
  store <8 x float> %5754, ptr %.slot120, align 32
  store <8 x i1> %convergence.cascade.result1180, ptr %current.mask, align 1
  %5755 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1180)
  br i1 %5755, label %schedule.61, label %scheduler.loop

varying.divergent1182:                            ; preds = %schedule.61
  %5756 = load i32, ptr %current.token, align 4
  %5757 = icmp ne i32 %5756, 0
  %5758 = sub i32 %5756, 1
  %5759 = select i1 %5757, i32 %5758, i32 0
  %5760 = load i8, ptr %frame.active, align 1
  %5761 = trunc i32 %5759 to i8
  %5762 = shl i8 1, %5761
  %5763 = and i8 %5760, %5762
  %5764 = icmp ne i8 %5763, 0
  %5765 = load <8 x i32>, ptr %frame.static.id, align 32
  %5766 = extractelement <8 x i32> %5765, i32 %5759
  %5767 = icmp eq i32 %5766, 28
  %5768 = and i1 %5764, %5767
  %5769 = and i1 %5757, %5768
  %5770 = xor i1 %5769, true
  %5771 = and i1 true, %5770
  %5772 = xor i8 %5760, -1
  %5773 = icmp ne i8 %5772, 0
  %5774 = xor i1 %5773, true
  %5775 = and i1 %5771, %5774
  br i1 %5775, label %convergence.overflow.trap1184, label %convergence.overflow.resume1185

varying.coherent1183:                             ; preds = %schedule.61
  br i1 %808, label %varying.coherent.true1188, label %varying.coherent.false1189

convergence.overflow.trap1184:                    ; preds = %varying.divergent1182
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1185:                  ; preds = %varying.divergent1182
  %5776 = call i8 @llvm.cttz.i8(i8 %5772, i1 false)
  %5777 = zext i8 %5776 to i32
  %5778 = select i1 %5773, i32 %5777, i32 0
  %5779 = trunc i32 %5778 to i8
  %5780 = shl i8 1, %5779
  %5781 = or i8 %5760, %5780
  %5782 = select i1 %5771, i8 %5781, i8 %5760
  store i8 %5782, ptr %frame.active, align 1
  %5783 = load <8 x i32>, ptr %frame.static.id, align 32
  %5784 = extractelement <8 x i32> %5783, i32 %5778
  %5785 = select i1 %5771, i32 28, i32 %5784
  %5786 = load <8 x i32>, ptr %frame.static.id, align 32
  %5787 = insertelement <8 x i32> %5786, i32 %5785, i32 %5778
  store <8 x i32> %5787, ptr %frame.static.id, align 32
  %5788 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5789 = extractelement <8 x i32> %5788, i32 %5778
  %5790 = select i1 %5771, i32 %5756, i32 %5789
  %5791 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5792 = insertelement <8 x i32> %5791, i32 %5790, i32 %5778
  store <8 x i32> %5792, ptr %frame.parent.token, align 32
  %5793 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5778
  %5794 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5778
  %5795 = load <8 x i1>, ptr %5793, align 1
  %5796 = load <8 x i1>, ptr %5794, align 1
  %5797 = select i1 %5771, <8 x i1> %798, <8 x i1> %5795
  store <8 x i1> %5797, ptr %5793, align 1
  %5798 = select i1 %5771, <8 x i1> zeroinitializer, <8 x i1> %5796
  store <8 x i1> %5798, ptr %5794, align 1
  %5799 = add i32 %5778, 1
  %5800 = select i1 %5769, i32 %5756, i32 %5799
  %5801 = select i1 true, i32 %5800, i32 %5756
  store i32 %5801, ptr %current.token, align 4
  %5802 = load i32, ptr %current.token, align 4
  %5803 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %805)
  %5804 = load i32, ptr %ready.count, align 4
  %5805 = icmp uge i32 %5804, 8
  %5806 = and i1 %5803, %5805
  br i1 %5806, label %ready.overflow.trap1186, label %ready.overflow.resume1187

ready.overflow.trap1186:                          ; preds = %convergence.overflow.resume1185
  call void @llvm.trap()
  unreachable

ready.overflow.resume1187:                        ; preds = %convergence.overflow.resume1185
  %5807 = select i1 %5803, i32 %5804, i32 0
  %5808 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5807
  %5809 = load <8 x i1>, ptr %5808, align 1
  %5810 = select i1 %5803, <8 x i1> %805, <8 x i1> %5809
  store <8 x i1> %5810, ptr %5808, align 1
  %5811 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5807
  %5812 = load i32, ptr %5811, align 4
  %5813 = select i1 %5803, i32 62, i32 %5812
  store i32 %5813, ptr %5811, align 4
  %5814 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5807
  %5815 = load i32, ptr %5814, align 4
  %5816 = select i1 %5803, i32 %5802, i32 %5815
  store i32 %5816, ptr %5814, align 4
  %5817 = add i32 %5804, 1
  %5818 = select i1 %5803, i32 %5817, i32 %5804
  store i32 %5818, ptr %ready.count, align 4
  %5819 = load <8 x i1>, ptr %runnable.mask, align 1
  %5820 = or <8 x i1> %5819, %805
  store <8 x i1> %5820, ptr %runnable.mask, align 1
  store <8 x i1> %807, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1188:                        ; preds = %varying.coherent1183
  store <8 x i1> %798, ptr %current.mask, align 1
  %5821 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %798)
  br i1 %5821, label %schedule.62, label %scheduler.loop

varying.coherent.false1189:                       ; preds = %varying.coherent1183
  store <8 x i1> %798, ptr %current.mask, align 1
  %5822 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %798)
  br i1 %5822, label %schedule.63, label %scheduler.loop

convergence.cascade1197:                          ; preds = %convergence.cascade1197, %schedule.63
  %convergence.cascade.flow1201 = phi <8 x i1> [ %846, %schedule.63 ], [ %5865, %convergence.cascade1197 ]
  %convergence.cascade.depth1202 = phi i32 [ 0, %schedule.63 ], [ %5866, %convergence.cascade1197 ]
  %5823 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1201)
  %5824 = load i32, ptr %current.token, align 4
  %5825 = icmp ne i32 %5824, 0
  %5826 = and i1 %5823, %5825
  %5827 = sub i32 %5824, 1
  %5828 = select i1 %5826, i32 %5827, i32 0
  %5829 = load i8, ptr %frame.active, align 1
  %5830 = trunc i32 %5828 to i8
  %5831 = shl i8 1, %5830
  %5832 = and i8 %5829, %5831
  %5833 = icmp ne i8 %5832, 0
  %5834 = load <8 x i32>, ptr %frame.static.id, align 32
  %5835 = extractelement <8 x i32> %5834, i32 %5828
  %convergence.target.pointer1203 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %5835
  %convergence.dynamic.target1204 = load i32, ptr %convergence.target.pointer1203, align 4
  %5836 = icmp eq i32 %convergence.dynamic.target1204, 63
  %5837 = and i1 %5833, %5836
  %5838 = and i1 %5826, %5837
  %5839 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5828
  %5840 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5828
  %5841 = load <8 x i1>, ptr %5839, align 1
  %5842 = load <8 x i1>, ptr %5840, align 1
  %5843 = or <8 x i1> %5842, %convergence.cascade.flow1201
  %5844 = load <8 x i1>, ptr %live.mask, align 1
  %5845 = and <8 x i1> %5841, %5844
  %5846 = icmp eq <8 x i1> %5843, %5845
  %5847 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5846)
  %5848 = and i1 %5838, %5847
  %5849 = select i1 %5848, <8 x i1> zeroinitializer, <8 x i1> %5843
  %5850 = select i1 %5838, <8 x i1> %5849, <8 x i1> %5842
  store <8 x i1> %5850, ptr %5840, align 1
  %5851 = select i1 %5848, <8 x i1> zeroinitializer, <8 x i1> %5841
  store <8 x i1> %5851, ptr %5839, align 1
  %5852 = trunc i32 %5828 to i8
  %5853 = shl i8 1, %5852
  %5854 = xor i8 %5853, -1
  %5855 = and i8 %5829, %5854
  %5856 = select i1 %5848, i8 %5855, i8 %5829
  store i8 %5856, ptr %frame.active, align 1
  %.splatinsert1205 = insertelement <8 x i1> poison, i1 %5838, i64 0
  %.splat1206 = shufflevector <8 x i1> %.splatinsert1205, <8 x i1> poison, <8 x i32> zeroinitializer
  %5857 = and <8 x i1> %convergence.cascade.flow1201, %.splat1206
  %5858 = load <8 x i1>, ptr %runnable.mask, align 1
  %5859 = xor <8 x i1> %5857, splat (i1 true)
  %5860 = and <8 x i1> %5858, %5859
  store <8 x i1> %5860, ptr %runnable.mask, align 1
  %.splatinsert1207 = insertelement <8 x i1> poison, i1 %5848, i64 0
  %.splat1208 = shufflevector <8 x i1> %.splatinsert1207, <8 x i1> poison, <8 x i32> zeroinitializer
  %5861 = select <8 x i1> %.splat1208, <8 x i1> %5843, <8 x i1> zeroinitializer
  %5862 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5863 = extractelement <8 x i32> %5862, i32 %5828
  %5864 = select i1 %5848, i32 %5863, i32 %5824
  store i32 %5864, ptr %current.token, align 4
  %.splatinsert1209 = insertelement <8 x i1> poison, i1 %5838, i64 0
  %.splat1210 = shufflevector <8 x i1> %.splatinsert1209, <8 x i1> poison, <8 x i32> zeroinitializer
  %5865 = select <8 x i1> %.splat1210, <8 x i1> %5861, <8 x i1> %convergence.cascade.flow1201
  %5866 = add i32 %convergence.cascade.depth1202, 1
  %5867 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5865)
  %5868 = icmp ult i32 %5866, 8
  %5869 = and i1 %5867, %5868
  %5870 = and i1 %5838, %5869
  %convergence.parent.token1211 = load i32, ptr %current.token, align 4
  %convergence.parent.present1212 = icmp ne i32 %convergence.parent.token1211, 0
  %5871 = and i1 %5870, %convergence.parent.present1212
  br i1 %5871, label %convergence.cascade1197, label %convergence.cascade.exit1198

convergence.cascade.exit1198:                     ; preds = %convergence.cascade1197, %schedule.63
  %convergence.cascade.result1213 = phi <8 x i1> [ %846, %schedule.63 ], [ %5865, %convergence.cascade1197 ]
  %5872 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1213)
  br i1 %5872, label %convergence.target.63.ready, label %scheduler.loop

convergence.target.63.ready:                      ; preds = %convergence.cascade.exit1198
  %5873 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1213)
  %5874 = bitcast <8 x i1> %convergence.cascade.result1213 to i8
  %5875 = call i8 @llvm.cttz.i8(i8 %5874, i1 false)
  %5876 = zext i8 %5875 to i32
  %5877 = select i1 %5873, i32 %5876, i32 0
  %5878 = load <8 x i64>, ptr %.slot121, align 64
  %5879 = select <8 x i1> %convergence.cascade.result1213, <8 x i64> zeroinitializer, <8 x i64> %5878
  store <8 x i64> %5879, ptr %.slot121, align 64
  %5880 = load <8 x float>, ptr %.slot122, align 32
  %5881 = select <8 x i1> %convergence.cascade.result1213, <8 x float> zeroinitializer, <8 x float> %5880
  store <8 x float> %5881, ptr %.slot122, align 32
  store <8 x i1> %convergence.cascade.result1213, ptr %current.mask, align 1
  %5882 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1213)
  br i1 %5882, label %schedule.64, label %scheduler.loop

varying.divergent1215:                            ; preds = %schedule.64
  %5883 = load i32, ptr %current.token, align 4
  %5884 = icmp ne i32 %5883, 0
  %5885 = sub i32 %5883, 1
  %5886 = select i1 %5884, i32 %5885, i32 0
  %5887 = load i8, ptr %frame.active, align 1
  %5888 = trunc i32 %5886 to i8
  %5889 = shl i8 1, %5888
  %5890 = and i8 %5887, %5889
  %5891 = icmp ne i8 %5890, 0
  %5892 = load <8 x i32>, ptr %frame.static.id, align 32
  %5893 = extractelement <8 x i32> %5892, i32 %5886
  %5894 = icmp eq i32 %5893, 29
  %5895 = and i1 %5891, %5894
  %5896 = and i1 %5884, %5895
  %5897 = xor i1 %5896, true
  %5898 = and i1 true, %5897
  %5899 = xor i8 %5887, -1
  %5900 = icmp ne i8 %5899, 0
  %5901 = xor i1 %5900, true
  %5902 = and i1 %5898, %5901
  br i1 %5902, label %convergence.overflow.trap1217, label %convergence.overflow.resume1218

varying.coherent1216:                             ; preds = %schedule.64
  br i1 %857, label %varying.coherent.true1221, label %varying.coherent.false1222

convergence.overflow.trap1217:                    ; preds = %varying.divergent1215
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1218:                  ; preds = %varying.divergent1215
  %5903 = call i8 @llvm.cttz.i8(i8 %5899, i1 false)
  %5904 = zext i8 %5903 to i32
  %5905 = select i1 %5900, i32 %5904, i32 0
  %5906 = trunc i32 %5905 to i8
  %5907 = shl i8 1, %5906
  %5908 = or i8 %5887, %5907
  %5909 = select i1 %5898, i8 %5908, i8 %5887
  store i8 %5909, ptr %frame.active, align 1
  %5910 = load <8 x i32>, ptr %frame.static.id, align 32
  %5911 = extractelement <8 x i32> %5910, i32 %5905
  %5912 = select i1 %5898, i32 29, i32 %5911
  %5913 = load <8 x i32>, ptr %frame.static.id, align 32
  %5914 = insertelement <8 x i32> %5913, i32 %5912, i32 %5905
  store <8 x i32> %5914, ptr %frame.static.id, align 32
  %5915 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5916 = extractelement <8 x i32> %5915, i32 %5905
  %5917 = select i1 %5898, i32 %5883, i32 %5916
  %5918 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5919 = insertelement <8 x i32> %5918, i32 %5917, i32 %5905
  store <8 x i32> %5919, ptr %frame.parent.token, align 32
  %5920 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5905
  %5921 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5905
  %5922 = load <8 x i1>, ptr %5920, align 1
  %5923 = load <8 x i1>, ptr %5921, align 1
  %5924 = select i1 %5898, <8 x i1> %847, <8 x i1> %5922
  store <8 x i1> %5924, ptr %5920, align 1
  %5925 = select i1 %5898, <8 x i1> zeroinitializer, <8 x i1> %5923
  store <8 x i1> %5925, ptr %5921, align 1
  %5926 = add i32 %5905, 1
  %5927 = select i1 %5896, i32 %5883, i32 %5926
  %5928 = select i1 true, i32 %5927, i32 %5883
  store i32 %5928, ptr %current.token, align 4
  %5929 = load i32, ptr %current.token, align 4
  %5930 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %854)
  %5931 = load i32, ptr %ready.count, align 4
  %5932 = icmp uge i32 %5931, 8
  %5933 = and i1 %5930, %5932
  br i1 %5933, label %ready.overflow.trap1219, label %ready.overflow.resume1220

ready.overflow.trap1219:                          ; preds = %convergence.overflow.resume1218
  call void @llvm.trap()
  unreachable

ready.overflow.resume1220:                        ; preds = %convergence.overflow.resume1218
  %5934 = select i1 %5930, i32 %5931, i32 0
  %5935 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5934
  %5936 = load <8 x i1>, ptr %5935, align 1
  %5937 = select i1 %5930, <8 x i1> %854, <8 x i1> %5936
  store <8 x i1> %5937, ptr %5935, align 1
  %5938 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5934
  %5939 = load i32, ptr %5938, align 4
  %5940 = select i1 %5930, i32 65, i32 %5939
  store i32 %5940, ptr %5938, align 4
  %5941 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5934
  %5942 = load i32, ptr %5941, align 4
  %5943 = select i1 %5930, i32 %5929, i32 %5942
  store i32 %5943, ptr %5941, align 4
  %5944 = add i32 %5931, 1
  %5945 = select i1 %5930, i32 %5944, i32 %5931
  store i32 %5945, ptr %ready.count, align 4
  %5946 = load <8 x i1>, ptr %runnable.mask, align 1
  %5947 = or <8 x i1> %5946, %854
  store <8 x i1> %5947, ptr %runnable.mask, align 1
  store <8 x i1> %856, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1221:                        ; preds = %varying.coherent1216
  store <8 x i1> %847, ptr %current.mask, align 1
  %5948 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %847)
  br i1 %5948, label %schedule.65, label %scheduler.loop

varying.coherent.false1222:                       ; preds = %varying.coherent1216
  store <8 x i1> %847, ptr %current.mask, align 1
  %5949 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %847)
  br i1 %5949, label %schedule.66, label %scheduler.loop

convergence.cascade1230:                          ; preds = %convergence.cascade1230, %schedule.66
  %convergence.cascade.flow1234 = phi <8 x i1> [ %895, %schedule.66 ], [ %5992, %convergence.cascade1230 ]
  %convergence.cascade.depth1235 = phi i32 [ 0, %schedule.66 ], [ %5993, %convergence.cascade1230 ]
  %5950 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1234)
  %5951 = load i32, ptr %current.token, align 4
  %5952 = icmp ne i32 %5951, 0
  %5953 = and i1 %5950, %5952
  %5954 = sub i32 %5951, 1
  %5955 = select i1 %5953, i32 %5954, i32 0
  %5956 = load i8, ptr %frame.active, align 1
  %5957 = trunc i32 %5955 to i8
  %5958 = shl i8 1, %5957
  %5959 = and i8 %5956, %5958
  %5960 = icmp ne i8 %5959, 0
  %5961 = load <8 x i32>, ptr %frame.static.id, align 32
  %5962 = extractelement <8 x i32> %5961, i32 %5955
  %convergence.target.pointer1236 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %5962
  %convergence.dynamic.target1237 = load i32, ptr %convergence.target.pointer1236, align 4
  %5963 = icmp eq i32 %convergence.dynamic.target1237, 66
  %5964 = and i1 %5960, %5963
  %5965 = and i1 %5953, %5964
  %5966 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5955
  %5967 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5955
  %5968 = load <8 x i1>, ptr %5966, align 1
  %5969 = load <8 x i1>, ptr %5967, align 1
  %5970 = or <8 x i1> %5969, %convergence.cascade.flow1234
  %5971 = load <8 x i1>, ptr %live.mask, align 1
  %5972 = and <8 x i1> %5968, %5971
  %5973 = icmp eq <8 x i1> %5970, %5972
  %5974 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5973)
  %5975 = and i1 %5965, %5974
  %5976 = select i1 %5975, <8 x i1> zeroinitializer, <8 x i1> %5970
  %5977 = select i1 %5965, <8 x i1> %5976, <8 x i1> %5969
  store <8 x i1> %5977, ptr %5967, align 1
  %5978 = select i1 %5975, <8 x i1> zeroinitializer, <8 x i1> %5968
  store <8 x i1> %5978, ptr %5966, align 1
  %5979 = trunc i32 %5955 to i8
  %5980 = shl i8 1, %5979
  %5981 = xor i8 %5980, -1
  %5982 = and i8 %5956, %5981
  %5983 = select i1 %5975, i8 %5982, i8 %5956
  store i8 %5983, ptr %frame.active, align 1
  %.splatinsert1238 = insertelement <8 x i1> poison, i1 %5965, i64 0
  %.splat1239 = shufflevector <8 x i1> %.splatinsert1238, <8 x i1> poison, <8 x i32> zeroinitializer
  %5984 = and <8 x i1> %convergence.cascade.flow1234, %.splat1239
  %5985 = load <8 x i1>, ptr %runnable.mask, align 1
  %5986 = xor <8 x i1> %5984, splat (i1 true)
  %5987 = and <8 x i1> %5985, %5986
  store <8 x i1> %5987, ptr %runnable.mask, align 1
  %.splatinsert1240 = insertelement <8 x i1> poison, i1 %5975, i64 0
  %.splat1241 = shufflevector <8 x i1> %.splatinsert1240, <8 x i1> poison, <8 x i32> zeroinitializer
  %5988 = select <8 x i1> %.splat1241, <8 x i1> %5970, <8 x i1> zeroinitializer
  %5989 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5990 = extractelement <8 x i32> %5989, i32 %5955
  %5991 = select i1 %5975, i32 %5990, i32 %5951
  store i32 %5991, ptr %current.token, align 4
  %.splatinsert1242 = insertelement <8 x i1> poison, i1 %5965, i64 0
  %.splat1243 = shufflevector <8 x i1> %.splatinsert1242, <8 x i1> poison, <8 x i32> zeroinitializer
  %5992 = select <8 x i1> %.splat1243, <8 x i1> %5988, <8 x i1> %convergence.cascade.flow1234
  %5993 = add i32 %convergence.cascade.depth1235, 1
  %5994 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5992)
  %5995 = icmp ult i32 %5993, 8
  %5996 = and i1 %5994, %5995
  %5997 = and i1 %5965, %5996
  %convergence.parent.token1244 = load i32, ptr %current.token, align 4
  %convergence.parent.present1245 = icmp ne i32 %convergence.parent.token1244, 0
  %5998 = and i1 %5997, %convergence.parent.present1245
  br i1 %5998, label %convergence.cascade1230, label %convergence.cascade.exit1231

convergence.cascade.exit1231:                     ; preds = %convergence.cascade1230, %schedule.66
  %convergence.cascade.result1246 = phi <8 x i1> [ %895, %schedule.66 ], [ %5992, %convergence.cascade1230 ]
  %5999 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1246)
  br i1 %5999, label %convergence.target.66.ready, label %scheduler.loop

convergence.target.66.ready:                      ; preds = %convergence.cascade.exit1231
  %6000 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1246)
  %6001 = bitcast <8 x i1> %convergence.cascade.result1246 to i8
  %6002 = call i8 @llvm.cttz.i8(i8 %6001, i1 false)
  %6003 = zext i8 %6002 to i32
  %6004 = select i1 %6000, i32 %6003, i32 0
  %.state1247 = load <8 x float>, ptr %.slot112, align 32
  %6005 = fmul <8 x float> %.state1247, splat (float 0x3FDC9F25C0000000)
  %.state1248 = load <8 x float>, ptr %.slot114, align 32
  %6006 = fmul <8 x float> %.state1248, splat (float 0x3FDC9F25C0000000)
  %.state1249 = load <8 x float>, ptr %.slot116, align 32
  %6007 = fmul <8 x float> %.state1249, splat (float 0x3FDC9F25C0000000)
  %.state1250 = load <8 x float>, ptr %.slot118, align 32
  %6008 = fmul <8 x float> %.state1250, splat (float 0x3FDC9F25C0000000)
  %.state1251 = load <8 x float>, ptr %.slot120, align 32
  %6009 = fmul <8 x float> %.state1251, splat (float 0x3FDC9F25C0000000)
  %.state1252 = load <8 x float>, ptr %.slot122, align 32
  %6010 = fmul <8 x float> %.state1252, splat (float 0x3FDC9F25C0000000)
  %.spill.load1253 = load volatile <8 x i64>, ptr %.spill51, align 64
  %6011 = icmp slt <8 x i64> %.spill.load1253, splat (i64 7)
  %.spill.load1254 = load volatile <8 x i64>, ptr %.spill13, align 64
  %6012 = add <8 x i64> %.spill.load1254, splat (i64 7)
  %.spill.load1255 = load volatile <8 x i64>, ptr %.spill24, align 64
  %6013 = add <8 x i64> %.spill.load1255, splat (i64 7)
  %6014 = sub <8 x i64> %6012, splat (i64 3)
  %6015 = sub <8 x i64> %6013, splat (i64 3)
  %.spill.load1256 = load volatile <8 x i64>, ptr %.spill51, align 64
  %6016 = icmp sle <8 x i64> %.spill.load1256, %6014
  %.spill.load1257 = load volatile <8 x i64>, ptr %.spill51, align 64
  %6017 = icmp sle <8 x i64> %.spill.load1257, %6015
  %.spill.load1258 = load volatile <8 x i64>, ptr %.spill59, align 64
  %6018 = icmp sle <8 x i64> %.spill.load1258, %6014
  %.spill.load1259 = load volatile <8 x i64>, ptr %.spill59, align 64
  %6019 = icmp sle <8 x i64> %.spill.load1259, %6015
  %.spill.load1260 = load volatile <8 x i64>, ptr %.spill74, align 64
  %6020 = icmp sle <8 x i64> %.spill.load1260, %6014
  %.spill.load1261 = load volatile <8 x i64>, ptr %.spill74, align 64
  %6021 = icmp sle <8 x i64> %.spill.load1261, %6015
  %6022 = and <8 x i1> %6011, %6016
  %6023 = load volatile <8 x i1>, ptr %.spill123, align 1
  %6024 = select <8 x i1> %convergence.cascade.result1246, <8 x i1> %6022, <8 x i1> %6023
  store volatile <8 x i1> %6024, ptr %.spill123, align 1
  %6025 = and <8 x i1> %6011, %6017
  %6026 = load volatile <8 x i1>, ptr %.spill124, align 1
  %6027 = select <8 x i1> %convergence.cascade.result1246, <8 x i1> %6025, <8 x i1> %6026
  store volatile <8 x i1> %6027, ptr %.spill124, align 1
  %.spill.load1262 = load volatile <8 x i1>, ptr %.spill61, align 1
  %6028 = and <8 x i1> %.spill.load1262, %6018
  %6029 = load volatile <8 x i1>, ptr %.spill125, align 1
  %6030 = select <8 x i1> %convergence.cascade.result1246, <8 x i1> %6028, <8 x i1> %6029
  store volatile <8 x i1> %6030, ptr %.spill125, align 1
  %.spill.load1263 = load volatile <8 x i1>, ptr %.spill61, align 1
  %6031 = and <8 x i1> %.spill.load1263, %6019
  %6032 = load volatile <8 x i1>, ptr %.spill126, align 1
  %6033 = select <8 x i1> %convergence.cascade.result1246, <8 x i1> %6031, <8 x i1> %6032
  store volatile <8 x i1> %6033, ptr %.spill126, align 1
  %.spill.load1264 = load volatile <8 x i1>, ptr %.spill76, align 1
  %6034 = and <8 x i1> %.spill.load1264, %6020
  %6035 = load volatile <8 x i1>, ptr %.spill127, align 1
  %6036 = select <8 x i1> %convergence.cascade.result1246, <8 x i1> %6034, <8 x i1> %6035
  store volatile <8 x i1> %6036, ptr %.spill127, align 1
  %.spill.load1265 = load volatile <8 x i1>, ptr %.spill76, align 1
  %6037 = and <8 x i1> %.spill.load1265, %6021
  %6038 = load volatile <8 x i1>, ptr %.spill128, align 1
  %6039 = select <8 x i1> %convergence.cascade.result1246, <8 x i1> %6037, <8 x i1> %6038
  store volatile <8 x i1> %6039, ptr %.spill128, align 1
  %6040 = select <8 x i1> %6022, <8 x float> %6005, <8 x float> splat (float 0xC6293E5940000000)
  %6041 = load volatile <8 x float>, ptr %.spill129, align 32
  %6042 = select <8 x i1> %convergence.cascade.result1246, <8 x float> %6040, <8 x float> %6041
  store volatile <8 x float> %6042, ptr %.spill129, align 32
  %6043 = select <8 x i1> %6028, <8 x float> %6006, <8 x float> splat (float 0xC6293E5940000000)
  %6044 = load volatile <8 x float>, ptr %.spill130, align 32
  %6045 = select <8 x i1> %convergence.cascade.result1246, <8 x float> %6043, <8 x float> %6044
  store volatile <8 x float> %6045, ptr %.spill130, align 32
  %6046 = select <8 x i1> %6034, <8 x float> %6007, <8 x float> splat (float 0xC6293E5940000000)
  %6047 = load volatile <8 x float>, ptr %.spill131, align 32
  %6048 = select <8 x i1> %convergence.cascade.result1246, <8 x float> %6046, <8 x float> %6047
  store volatile <8 x float> %6048, ptr %.spill131, align 32
  %6049 = select <8 x i1> %6025, <8 x float> %6008, <8 x float> splat (float 0xC6293E5940000000)
  %6050 = load volatile <8 x float>, ptr %.spill132, align 32
  %6051 = select <8 x i1> %convergence.cascade.result1246, <8 x float> %6049, <8 x float> %6050
  store volatile <8 x float> %6051, ptr %.spill132, align 32
  %6052 = select <8 x i1> %6031, <8 x float> %6009, <8 x float> splat (float 0xC6293E5940000000)
  %6053 = load volatile <8 x float>, ptr %.spill133, align 32
  %6054 = select <8 x i1> %convergence.cascade.result1246, <8 x float> %6052, <8 x float> %6053
  store volatile <8 x float> %6054, ptr %.spill133, align 32
  %6055 = select <8 x i1> %6037, <8 x float> %6010, <8 x float> splat (float 0xC6293E5940000000)
  %6056 = load volatile <8 x float>, ptr %.spill134, align 32
  %6057 = select <8 x i1> %convergence.cascade.result1246, <8 x float> %6055, <8 x float> %6056
  store volatile <8 x float> %6057, ptr %.spill134, align 32
  %6058 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill135, align 64
  %6059 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %6060 = extractvalue { <8 x ptr>, <8 x i64> } %6058, 0
  %6061 = select <8 x i1> %convergence.cascade.result1246, <8 x ptr> %6059, <8 x ptr> %6060
  %6062 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %6063 = extractvalue { <8 x ptr>, <8 x i64> } %6058, 1
  %6064 = select <8 x i1> %convergence.cascade.result1246, <8 x i64> %6062, <8 x i64> %6063
  %6065 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6061, 0
  %6066 = insertvalue { <8 x ptr>, <8 x i64> } %6065, <8 x i64> %6064, 1
  store volatile { <8 x ptr>, <8 x i64> } %6066, ptr %tile_snapshot.spill135, align 64
  %6067 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %6068 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %6069 = add <8 x i64> %6068, zeroinitializer
  %6070 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6067, 0
  %6071 = insertvalue { <8 x ptr>, <8 x i64> } %6070, <8 x i64> %6069, 1
  %6072 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %6073 = extractvalue { <8 x ptr>, <8 x i64> } %6071, 1
  %6074 = extractelement <8 x ptr> %6072, i32 0
  %6075 = extractelement <8 x i64> %6073, i32 %6004
  %6076 = zext i32 %6004 to i64
  %6077 = mul i64 %6076, 4
  %6078 = sub i64 %6075, %6077
  %6079 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1246)
  %6080 = select i1 %6079, i64 %6078, i64 0
  %private.contiguous.address1266 = getelementptr i8, ptr %6074, i64 %6080
  %private.contiguous.preserve1267 = load <8 x float>, ptr %private.contiguous.address1266, align 4
  %6081 = select <8 x i1> %convergence.cascade.result1246, <8 x float> %6040, <8 x float> %private.contiguous.preserve1267
  store <8 x float> %6081, ptr %private.contiguous.address1266, align 4
  %6082 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %6083 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %6084 = add <8 x i64> %6083, splat (i64 32)
  %6085 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6082, 0
  %6086 = insertvalue { <8 x ptr>, <8 x i64> } %6085, <8 x i64> %6084, 1
  %6087 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %6088 = extractvalue { <8 x ptr>, <8 x i64> } %6086, 1
  %6089 = extractelement <8 x ptr> %6087, i32 0
  %6090 = extractelement <8 x i64> %6088, i32 %6004
  %6091 = zext i32 %6004 to i64
  %6092 = mul i64 %6091, 4
  %6093 = sub i64 %6090, %6092
  %6094 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1246)
  %6095 = select i1 %6094, i64 %6093, i64 0
  %private.contiguous.address1268 = getelementptr i8, ptr %6089, i64 %6095
  %private.contiguous.preserve1269 = load <8 x float>, ptr %private.contiguous.address1268, align 4
  %6096 = select <8 x i1> %convergence.cascade.result1246, <8 x float> %6043, <8 x float> %private.contiguous.preserve1269
  store <8 x float> %6096, ptr %private.contiguous.address1268, align 4
  %6097 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %6098 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %6099 = add <8 x i64> %6098, splat (i64 64)
  %6100 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6097, 0
  %6101 = insertvalue { <8 x ptr>, <8 x i64> } %6100, <8 x i64> %6099, 1
  %6102 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %6103 = extractvalue { <8 x ptr>, <8 x i64> } %6101, 1
  %6104 = extractelement <8 x ptr> %6102, i32 0
  %6105 = extractelement <8 x i64> %6103, i32 %6004
  %6106 = zext i32 %6004 to i64
  %6107 = mul i64 %6106, 4
  %6108 = sub i64 %6105, %6107
  %6109 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1246)
  %6110 = select i1 %6109, i64 %6108, i64 0
  %private.contiguous.address1270 = getelementptr i8, ptr %6104, i64 %6110
  %private.contiguous.preserve1271 = load <8 x float>, ptr %private.contiguous.address1270, align 4
  %6111 = select <8 x i1> %convergence.cascade.result1246, <8 x float> %6046, <8 x float> %private.contiguous.preserve1271
  store <8 x float> %6111, ptr %private.contiguous.address1270, align 4
  %6112 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %6113 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %6114 = add <8 x i64> %6113, splat (i64 96)
  %6115 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6112, 0
  %6116 = insertvalue { <8 x ptr>, <8 x i64> } %6115, <8 x i64> %6114, 1
  %6117 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %6118 = extractvalue { <8 x ptr>, <8 x i64> } %6116, 1
  %6119 = extractelement <8 x ptr> %6117, i32 0
  %6120 = extractelement <8 x i64> %6118, i32 %6004
  %6121 = zext i32 %6004 to i64
  %6122 = mul i64 %6121, 4
  %6123 = sub i64 %6120, %6122
  %6124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1246)
  %6125 = select i1 %6124, i64 %6123, i64 0
  %private.contiguous.address1272 = getelementptr i8, ptr %6119, i64 %6125
  %private.contiguous.preserve1273 = load <8 x float>, ptr %private.contiguous.address1272, align 4
  %6126 = select <8 x i1> %convergence.cascade.result1246, <8 x float> %6049, <8 x float> %private.contiguous.preserve1273
  store <8 x float> %6126, ptr %private.contiguous.address1272, align 4
  %6127 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %6128 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %6129 = add <8 x i64> %6128, splat (i64 128)
  %6130 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6127, 0
  %6131 = insertvalue { <8 x ptr>, <8 x i64> } %6130, <8 x i64> %6129, 1
  %6132 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %6133 = extractvalue { <8 x ptr>, <8 x i64> } %6131, 1
  %6134 = extractelement <8 x ptr> %6132, i32 0
  %6135 = extractelement <8 x i64> %6133, i32 %6004
  %6136 = zext i32 %6004 to i64
  %6137 = mul i64 %6136, 4
  %6138 = sub i64 %6135, %6137
  %6139 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1246)
  %6140 = select i1 %6139, i64 %6138, i64 0
  %private.contiguous.address1274 = getelementptr i8, ptr %6134, i64 %6140
  %private.contiguous.preserve1275 = load <8 x float>, ptr %private.contiguous.address1274, align 4
  %6141 = select <8 x i1> %convergence.cascade.result1246, <8 x float> %6052, <8 x float> %private.contiguous.preserve1275
  store <8 x float> %6141, ptr %private.contiguous.address1274, align 4
  %6142 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %6143 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %6144 = add <8 x i64> %6143, splat (i64 160)
  %6145 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6142, 0
  %6146 = insertvalue { <8 x ptr>, <8 x i64> } %6145, <8 x i64> %6144, 1
  %6147 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %6148 = extractvalue { <8 x ptr>, <8 x i64> } %6146, 1
  %6149 = extractelement <8 x ptr> %6147, i32 0
  %6150 = extractelement <8 x i64> %6148, i32 %6004
  %6151 = zext i32 %6004 to i64
  %6152 = mul i64 %6151, 4
  %6153 = sub i64 %6150, %6152
  %6154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1246)
  %6155 = select i1 %6154, i64 %6153, i64 0
  %private.contiguous.address1276 = getelementptr i8, ptr %6149, i64 %6155
  %private.contiguous.preserve1277 = load <8 x float>, ptr %private.contiguous.address1276, align 4
  %6156 = select <8 x i1> %convergence.cascade.result1246, <8 x float> %6055, <8 x float> %private.contiguous.preserve1277
  store <8 x float> %6156, ptr %private.contiguous.address1276, align 4
  %6157 = load <8 x i64>, ptr %.slot136, align 64
  %6158 = select <8 x i1> %convergence.cascade.result1246, <8 x i64> zeroinitializer, <8 x i64> %6157
  store <8 x i64> %6158, ptr %.slot136, align 64
  %6159 = load <8 x float>, ptr %.slot137, align 32
  %6160 = select <8 x i1> %convergence.cascade.result1246, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %6159
  store <8 x float> %6160, ptr %.slot137, align 32
  store <8 x i1> %convergence.cascade.result1246, ptr %current.mask, align 1
  %6161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1246)
  br i1 %6161, label %schedule.67, label %scheduler.loop

varying.divergent1279:                            ; preds = %schedule.67
  %6162 = load i32, ptr %current.token, align 4
  %6163 = icmp ne i32 %6162, 0
  %6164 = sub i32 %6162, 1
  %6165 = select i1 %6163, i32 %6164, i32 0
  %6166 = load i8, ptr %frame.active, align 1
  %6167 = trunc i32 %6165 to i8
  %6168 = shl i8 1, %6167
  %6169 = and i8 %6166, %6168
  %6170 = icmp ne i8 %6169, 0
  %6171 = load <8 x i32>, ptr %frame.static.id, align 32
  %6172 = extractelement <8 x i32> %6171, i32 %6165
  %6173 = icmp eq i32 %6172, 30
  %6174 = and i1 %6170, %6173
  %6175 = and i1 %6163, %6174
  %6176 = xor i1 %6175, true
  %6177 = and i1 true, %6176
  %6178 = xor i8 %6166, -1
  %6179 = icmp ne i8 %6178, 0
  %6180 = xor i1 %6179, true
  %6181 = and i1 %6177, %6180
  br i1 %6181, label %convergence.overflow.trap1281, label %convergence.overflow.resume1282

varying.coherent1280:                             ; preds = %schedule.67
  br i1 %906, label %varying.coherent.true1285, label %varying.coherent.false1286

convergence.overflow.trap1281:                    ; preds = %varying.divergent1279
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1282:                  ; preds = %varying.divergent1279
  %6182 = call i8 @llvm.cttz.i8(i8 %6178, i1 false)
  %6183 = zext i8 %6182 to i32
  %6184 = select i1 %6179, i32 %6183, i32 0
  %6185 = trunc i32 %6184 to i8
  %6186 = shl i8 1, %6185
  %6187 = or i8 %6166, %6186
  %6188 = select i1 %6177, i8 %6187, i8 %6166
  store i8 %6188, ptr %frame.active, align 1
  %6189 = load <8 x i32>, ptr %frame.static.id, align 32
  %6190 = extractelement <8 x i32> %6189, i32 %6184
  %6191 = select i1 %6177, i32 30, i32 %6190
  %6192 = load <8 x i32>, ptr %frame.static.id, align 32
  %6193 = insertelement <8 x i32> %6192, i32 %6191, i32 %6184
  store <8 x i32> %6193, ptr %frame.static.id, align 32
  %6194 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6195 = extractelement <8 x i32> %6194, i32 %6184
  %6196 = select i1 %6177, i32 %6162, i32 %6195
  %6197 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6198 = insertelement <8 x i32> %6197, i32 %6196, i32 %6184
  store <8 x i32> %6198, ptr %frame.parent.token, align 32
  %6199 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6184
  %6200 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6184
  %6201 = load <8 x i1>, ptr %6199, align 1
  %6202 = load <8 x i1>, ptr %6200, align 1
  %6203 = select i1 %6177, <8 x i1> %896, <8 x i1> %6201
  store <8 x i1> %6203, ptr %6199, align 1
  %6204 = select i1 %6177, <8 x i1> zeroinitializer, <8 x i1> %6202
  store <8 x i1> %6204, ptr %6200, align 1
  %6205 = add i32 %6184, 1
  %6206 = select i1 %6175, i32 %6162, i32 %6205
  %6207 = select i1 true, i32 %6206, i32 %6162
  store i32 %6207, ptr %current.token, align 4
  %6208 = load i32, ptr %current.token, align 4
  %6209 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %903)
  %6210 = load i32, ptr %ready.count, align 4
  %6211 = icmp uge i32 %6210, 8
  %6212 = and i1 %6209, %6211
  br i1 %6212, label %ready.overflow.trap1283, label %ready.overflow.resume1284

ready.overflow.trap1283:                          ; preds = %convergence.overflow.resume1282
  call void @llvm.trap()
  unreachable

ready.overflow.resume1284:                        ; preds = %convergence.overflow.resume1282
  %6213 = select i1 %6209, i32 %6210, i32 0
  %6214 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6213
  %6215 = load <8 x i1>, ptr %6214, align 1
  %6216 = select i1 %6209, <8 x i1> %903, <8 x i1> %6215
  store <8 x i1> %6216, ptr %6214, align 1
  %6217 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6213
  %6218 = load i32, ptr %6217, align 4
  %6219 = select i1 %6209, i32 68, i32 %6218
  store i32 %6219, ptr %6217, align 4
  %6220 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6213
  %6221 = load i32, ptr %6220, align 4
  %6222 = select i1 %6209, i32 %6208, i32 %6221
  store i32 %6222, ptr %6220, align 4
  %6223 = add i32 %6210, 1
  %6224 = select i1 %6209, i32 %6223, i32 %6210
  store i32 %6224, ptr %ready.count, align 4
  %6225 = load <8 x i1>, ptr %runnable.mask, align 1
  %6226 = or <8 x i1> %6225, %903
  store <8 x i1> %6226, ptr %runnable.mask, align 1
  store <8 x i1> %905, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1285:                        ; preds = %varying.coherent1280
  store <8 x i1> %896, ptr %current.mask, align 1
  %6227 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %896)
  br i1 %6227, label %schedule.68, label %scheduler.loop

varying.coherent.false1286:                       ; preds = %varying.coherent1280
  store <8 x i1> %896, ptr %current.mask, align 1
  %6228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %896)
  br i1 %6228, label %schedule.69, label %scheduler.loop

convergence.cascade1294:                          ; preds = %convergence.cascade1294, %schedule.69
  %convergence.cascade.flow1298 = phi <8 x i1> [ %942, %schedule.69 ], [ %6271, %convergence.cascade1294 ]
  %convergence.cascade.depth1299 = phi i32 [ 0, %schedule.69 ], [ %6272, %convergence.cascade1294 ]
  %6229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1298)
  %6230 = load i32, ptr %current.token, align 4
  %6231 = icmp ne i32 %6230, 0
  %6232 = and i1 %6229, %6231
  %6233 = sub i32 %6230, 1
  %6234 = select i1 %6232, i32 %6233, i32 0
  %6235 = load i8, ptr %frame.active, align 1
  %6236 = trunc i32 %6234 to i8
  %6237 = shl i8 1, %6236
  %6238 = and i8 %6235, %6237
  %6239 = icmp ne i8 %6238, 0
  %6240 = load <8 x i32>, ptr %frame.static.id, align 32
  %6241 = extractelement <8 x i32> %6240, i32 %6234
  %convergence.target.pointer1300 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %6241
  %convergence.dynamic.target1301 = load i32, ptr %convergence.target.pointer1300, align 4
  %6242 = icmp eq i32 %convergence.dynamic.target1301, 69
  %6243 = and i1 %6239, %6242
  %6244 = and i1 %6232, %6243
  %6245 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6234
  %6246 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6234
  %6247 = load <8 x i1>, ptr %6245, align 1
  %6248 = load <8 x i1>, ptr %6246, align 1
  %6249 = or <8 x i1> %6248, %convergence.cascade.flow1298
  %6250 = load <8 x i1>, ptr %live.mask, align 1
  %6251 = and <8 x i1> %6247, %6250
  %6252 = icmp eq <8 x i1> %6249, %6251
  %6253 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6252)
  %6254 = and i1 %6244, %6253
  %6255 = select i1 %6254, <8 x i1> zeroinitializer, <8 x i1> %6249
  %6256 = select i1 %6244, <8 x i1> %6255, <8 x i1> %6248
  store <8 x i1> %6256, ptr %6246, align 1
  %6257 = select i1 %6254, <8 x i1> zeroinitializer, <8 x i1> %6247
  store <8 x i1> %6257, ptr %6245, align 1
  %6258 = trunc i32 %6234 to i8
  %6259 = shl i8 1, %6258
  %6260 = xor i8 %6259, -1
  %6261 = and i8 %6235, %6260
  %6262 = select i1 %6254, i8 %6261, i8 %6235
  store i8 %6262, ptr %frame.active, align 1
  %.splatinsert1302 = insertelement <8 x i1> poison, i1 %6244, i64 0
  %.splat1303 = shufflevector <8 x i1> %.splatinsert1302, <8 x i1> poison, <8 x i32> zeroinitializer
  %6263 = and <8 x i1> %convergence.cascade.flow1298, %.splat1303
  %6264 = load <8 x i1>, ptr %runnable.mask, align 1
  %6265 = xor <8 x i1> %6263, splat (i1 true)
  %6266 = and <8 x i1> %6264, %6265
  store <8 x i1> %6266, ptr %runnable.mask, align 1
  %.splatinsert1304 = insertelement <8 x i1> poison, i1 %6254, i64 0
  %.splat1305 = shufflevector <8 x i1> %.splatinsert1304, <8 x i1> poison, <8 x i32> zeroinitializer
  %6267 = select <8 x i1> %.splat1305, <8 x i1> %6249, <8 x i1> zeroinitializer
  %6268 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6269 = extractelement <8 x i32> %6268, i32 %6234
  %6270 = select i1 %6254, i32 %6269, i32 %6230
  store i32 %6270, ptr %current.token, align 4
  %.splatinsert1306 = insertelement <8 x i1> poison, i1 %6244, i64 0
  %.splat1307 = shufflevector <8 x i1> %.splatinsert1306, <8 x i1> poison, <8 x i32> zeroinitializer
  %6271 = select <8 x i1> %.splat1307, <8 x i1> %6267, <8 x i1> %convergence.cascade.flow1298
  %6272 = add i32 %convergence.cascade.depth1299, 1
  %6273 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6271)
  %6274 = icmp ult i32 %6272, 8
  %6275 = and i1 %6273, %6274
  %6276 = and i1 %6244, %6275
  %convergence.parent.token1308 = load i32, ptr %current.token, align 4
  %convergence.parent.present1309 = icmp ne i32 %convergence.parent.token1308, 0
  %6277 = and i1 %6276, %convergence.parent.present1309
  br i1 %6277, label %convergence.cascade1294, label %convergence.cascade.exit1295

convergence.cascade.exit1295:                     ; preds = %convergence.cascade1294, %schedule.69
  %convergence.cascade.result1310 = phi <8 x i1> [ %942, %schedule.69 ], [ %6271, %convergence.cascade1294 ]
  %6278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1310)
  br i1 %6278, label %convergence.target.69.ready, label %scheduler.loop

convergence.target.69.ready:                      ; preds = %convergence.cascade.exit1295
  %6279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1310)
  %6280 = bitcast <8 x i1> %convergence.cascade.result1310 to i8
  %6281 = call i8 @llvm.cttz.i8(i8 %6280, i1 false)
  %6282 = zext i8 %6281 to i32
  %6283 = select i1 %6279, i32 %6282, i32 0
  %6284 = load <8 x i64>, ptr %.slot138, align 64
  %6285 = select <8 x i1> %convergence.cascade.result1310, <8 x i64> zeroinitializer, <8 x i64> %6284
  store <8 x i64> %6285, ptr %.slot138, align 64
  %6286 = load <8 x float>, ptr %.slot139, align 32
  %6287 = select <8 x i1> %convergence.cascade.result1310, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %6286
  store <8 x float> %6287, ptr %.slot139, align 32
  store <8 x i1> %convergence.cascade.result1310, ptr %current.mask, align 1
  %6288 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1310)
  br i1 %6288, label %schedule.70, label %scheduler.loop

varying.divergent1312:                            ; preds = %schedule.70
  %6289 = load i32, ptr %current.token, align 4
  %6290 = icmp ne i32 %6289, 0
  %6291 = sub i32 %6289, 1
  %6292 = select i1 %6290, i32 %6291, i32 0
  %6293 = load i8, ptr %frame.active, align 1
  %6294 = trunc i32 %6292 to i8
  %6295 = shl i8 1, %6294
  %6296 = and i8 %6293, %6295
  %6297 = icmp ne i8 %6296, 0
  %6298 = load <8 x i32>, ptr %frame.static.id, align 32
  %6299 = extractelement <8 x i32> %6298, i32 %6292
  %6300 = icmp eq i32 %6299, 31
  %6301 = and i1 %6297, %6300
  %6302 = and i1 %6290, %6301
  %6303 = xor i1 %6302, true
  %6304 = and i1 true, %6303
  %6305 = xor i8 %6293, -1
  %6306 = icmp ne i8 %6305, 0
  %6307 = xor i1 %6306, true
  %6308 = and i1 %6304, %6307
  br i1 %6308, label %convergence.overflow.trap1314, label %convergence.overflow.resume1315

varying.coherent1313:                             ; preds = %schedule.70
  br i1 %953, label %varying.coherent.true1318, label %varying.coherent.false1319

convergence.overflow.trap1314:                    ; preds = %varying.divergent1312
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1315:                  ; preds = %varying.divergent1312
  %6309 = call i8 @llvm.cttz.i8(i8 %6305, i1 false)
  %6310 = zext i8 %6309 to i32
  %6311 = select i1 %6306, i32 %6310, i32 0
  %6312 = trunc i32 %6311 to i8
  %6313 = shl i8 1, %6312
  %6314 = or i8 %6293, %6313
  %6315 = select i1 %6304, i8 %6314, i8 %6293
  store i8 %6315, ptr %frame.active, align 1
  %6316 = load <8 x i32>, ptr %frame.static.id, align 32
  %6317 = extractelement <8 x i32> %6316, i32 %6311
  %6318 = select i1 %6304, i32 31, i32 %6317
  %6319 = load <8 x i32>, ptr %frame.static.id, align 32
  %6320 = insertelement <8 x i32> %6319, i32 %6318, i32 %6311
  store <8 x i32> %6320, ptr %frame.static.id, align 32
  %6321 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6322 = extractelement <8 x i32> %6321, i32 %6311
  %6323 = select i1 %6304, i32 %6289, i32 %6322
  %6324 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6325 = insertelement <8 x i32> %6324, i32 %6323, i32 %6311
  store <8 x i32> %6325, ptr %frame.parent.token, align 32
  %6326 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6311
  %6327 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6311
  %6328 = load <8 x i1>, ptr %6326, align 1
  %6329 = load <8 x i1>, ptr %6327, align 1
  %6330 = select i1 %6304, <8 x i1> %943, <8 x i1> %6328
  store <8 x i1> %6330, ptr %6326, align 1
  %6331 = select i1 %6304, <8 x i1> zeroinitializer, <8 x i1> %6329
  store <8 x i1> %6331, ptr %6327, align 1
  %6332 = add i32 %6311, 1
  %6333 = select i1 %6302, i32 %6289, i32 %6332
  %6334 = select i1 true, i32 %6333, i32 %6289
  store i32 %6334, ptr %current.token, align 4
  %6335 = load i32, ptr %current.token, align 4
  %6336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %950)
  %6337 = load i32, ptr %ready.count, align 4
  %6338 = icmp uge i32 %6337, 8
  %6339 = and i1 %6336, %6338
  br i1 %6339, label %ready.overflow.trap1316, label %ready.overflow.resume1317

ready.overflow.trap1316:                          ; preds = %convergence.overflow.resume1315
  call void @llvm.trap()
  unreachable

ready.overflow.resume1317:                        ; preds = %convergence.overflow.resume1315
  %6340 = select i1 %6336, i32 %6337, i32 0
  %6341 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6340
  %6342 = load <8 x i1>, ptr %6341, align 1
  %6343 = select i1 %6336, <8 x i1> %950, <8 x i1> %6342
  store <8 x i1> %6343, ptr %6341, align 1
  %6344 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6340
  %6345 = load i32, ptr %6344, align 4
  %6346 = select i1 %6336, i32 71, i32 %6345
  store i32 %6346, ptr %6344, align 4
  %6347 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6340
  %6348 = load i32, ptr %6347, align 4
  %6349 = select i1 %6336, i32 %6335, i32 %6348
  store i32 %6349, ptr %6347, align 4
  %6350 = add i32 %6337, 1
  %6351 = select i1 %6336, i32 %6350, i32 %6337
  store i32 %6351, ptr %ready.count, align 4
  %6352 = load <8 x i1>, ptr %runnable.mask, align 1
  %6353 = or <8 x i1> %6352, %950
  store <8 x i1> %6353, ptr %runnable.mask, align 1
  store <8 x i1> %952, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1318:                        ; preds = %varying.coherent1313
  store <8 x i1> %943, ptr %current.mask, align 1
  %6354 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %943)
  br i1 %6354, label %schedule.71, label %scheduler.loop

varying.coherent.false1319:                       ; preds = %varying.coherent1313
  store <8 x i1> %943, ptr %current.mask, align 1
  %6355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %943)
  br i1 %6355, label %schedule.72, label %scheduler.loop

convergence.cascade1327:                          ; preds = %convergence.cascade1327, %schedule.72
  %convergence.cascade.flow1331 = phi <8 x i1> [ %989, %schedule.72 ], [ %6398, %convergence.cascade1327 ]
  %convergence.cascade.depth1332 = phi i32 [ 0, %schedule.72 ], [ %6399, %convergence.cascade1327 ]
  %6356 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1331)
  %6357 = load i32, ptr %current.token, align 4
  %6358 = icmp ne i32 %6357, 0
  %6359 = and i1 %6356, %6358
  %6360 = sub i32 %6357, 1
  %6361 = select i1 %6359, i32 %6360, i32 0
  %6362 = load i8, ptr %frame.active, align 1
  %6363 = trunc i32 %6361 to i8
  %6364 = shl i8 1, %6363
  %6365 = and i8 %6362, %6364
  %6366 = icmp ne i8 %6365, 0
  %6367 = load <8 x i32>, ptr %frame.static.id, align 32
  %6368 = extractelement <8 x i32> %6367, i32 %6361
  %convergence.target.pointer1333 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %6368
  %convergence.dynamic.target1334 = load i32, ptr %convergence.target.pointer1333, align 4
  %6369 = icmp eq i32 %convergence.dynamic.target1334, 72
  %6370 = and i1 %6366, %6369
  %6371 = and i1 %6359, %6370
  %6372 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6361
  %6373 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6361
  %6374 = load <8 x i1>, ptr %6372, align 1
  %6375 = load <8 x i1>, ptr %6373, align 1
  %6376 = or <8 x i1> %6375, %convergence.cascade.flow1331
  %6377 = load <8 x i1>, ptr %live.mask, align 1
  %6378 = and <8 x i1> %6374, %6377
  %6379 = icmp eq <8 x i1> %6376, %6378
  %6380 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6379)
  %6381 = and i1 %6371, %6380
  %6382 = select i1 %6381, <8 x i1> zeroinitializer, <8 x i1> %6376
  %6383 = select i1 %6371, <8 x i1> %6382, <8 x i1> %6375
  store <8 x i1> %6383, ptr %6373, align 1
  %6384 = select i1 %6381, <8 x i1> zeroinitializer, <8 x i1> %6374
  store <8 x i1> %6384, ptr %6372, align 1
  %6385 = trunc i32 %6361 to i8
  %6386 = shl i8 1, %6385
  %6387 = xor i8 %6386, -1
  %6388 = and i8 %6362, %6387
  %6389 = select i1 %6381, i8 %6388, i8 %6362
  store i8 %6389, ptr %frame.active, align 1
  %.splatinsert1335 = insertelement <8 x i1> poison, i1 %6371, i64 0
  %.splat1336 = shufflevector <8 x i1> %.splatinsert1335, <8 x i1> poison, <8 x i32> zeroinitializer
  %6390 = and <8 x i1> %convergence.cascade.flow1331, %.splat1336
  %6391 = load <8 x i1>, ptr %runnable.mask, align 1
  %6392 = xor <8 x i1> %6390, splat (i1 true)
  %6393 = and <8 x i1> %6391, %6392
  store <8 x i1> %6393, ptr %runnable.mask, align 1
  %.splatinsert1337 = insertelement <8 x i1> poison, i1 %6381, i64 0
  %.splat1338 = shufflevector <8 x i1> %.splatinsert1337, <8 x i1> poison, <8 x i32> zeroinitializer
  %6394 = select <8 x i1> %.splat1338, <8 x i1> %6376, <8 x i1> zeroinitializer
  %6395 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6396 = extractelement <8 x i32> %6395, i32 %6361
  %6397 = select i1 %6381, i32 %6396, i32 %6357
  store i32 %6397, ptr %current.token, align 4
  %.splatinsert1339 = insertelement <8 x i1> poison, i1 %6371, i64 0
  %.splat1340 = shufflevector <8 x i1> %.splatinsert1339, <8 x i1> poison, <8 x i32> zeroinitializer
  %6398 = select <8 x i1> %.splat1340, <8 x i1> %6394, <8 x i1> %convergence.cascade.flow1331
  %6399 = add i32 %convergence.cascade.depth1332, 1
  %6400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6398)
  %6401 = icmp ult i32 %6399, 8
  %6402 = and i1 %6400, %6401
  %6403 = and i1 %6371, %6402
  %convergence.parent.token1341 = load i32, ptr %current.token, align 4
  %convergence.parent.present1342 = icmp ne i32 %convergence.parent.token1341, 0
  %6404 = and i1 %6403, %convergence.parent.present1342
  br i1 %6404, label %convergence.cascade1327, label %convergence.cascade.exit1328

convergence.cascade.exit1328:                     ; preds = %convergence.cascade1327, %schedule.72
  %convergence.cascade.result1343 = phi <8 x i1> [ %989, %schedule.72 ], [ %6398, %convergence.cascade1327 ]
  %6405 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1343)
  br i1 %6405, label %convergence.target.72.ready, label %scheduler.loop

convergence.target.72.ready:                      ; preds = %convergence.cascade.exit1328
  %6406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1343)
  %6407 = bitcast <8 x i1> %convergence.cascade.result1343 to i8
  %6408 = call i8 @llvm.cttz.i8(i8 %6407, i1 false)
  %6409 = zext i8 %6408 to i32
  %6410 = select i1 %6406, i32 %6409, i32 0
  %.state1344 = load <8 x float>, ptr %.slot38, align 32
  %.state1345 = load <8 x float>, ptr %.slot137, align 32
  %6411 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1344, <8 x float> %.state1345)
  %6412 = load volatile <8 x float>, ptr %.spill140, align 32
  %6413 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6411, <8 x float> %6412
  store volatile <8 x float> %6413, ptr %.spill140, align 32
  %.state1346 = load <8 x float>, ptr %.slot39, align 32
  %.state1347 = load <8 x float>, ptr %.slot139, align 32
  %6414 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1346, <8 x float> %.state1347)
  %6415 = load volatile <8 x float>, ptr %.spill141, align 32
  %6416 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6414, <8 x float> %6415
  store volatile <8 x float> %6416, ptr %.spill141, align 32
  %.state1348 = load <8 x float>, ptr %.slot38, align 32
  %6417 = fsub <8 x float> %.state1348, %6411
  %.state1349 = load <8 x float>, ptr %.slot39, align 32
  %6418 = fsub <8 x float> %.state1349, %6414
  %6419 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6417, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %6419)
  %6420 = load <8 x float>, ptr %.spill142, align 32
  %6421 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %native.exp, <8 x float> %6420
  store <8 x float> %6421, ptr %.spill142, align 32
  %6422 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6418, <8 x float> zeroinitializer
  %native.exp1350 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %6422)
  %6423 = load <8 x float>, ptr %.spill143, align 32
  %6424 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %native.exp1350, <8 x float> %6423
  store <8 x float> %6424, ptr %.spill143, align 32
  %.spill.load1351 = load volatile <8 x float>, ptr %.spill129, align 32
  %6425 = fsub <8 x float> %.spill.load1351, %6411
  %.spill.load1352 = load volatile <8 x float>, ptr %.spill130, align 32
  %6426 = fsub <8 x float> %.spill.load1352, %6411
  %.spill.load1353 = load volatile <8 x float>, ptr %.spill131, align 32
  %6427 = fsub <8 x float> %.spill.load1353, %6411
  %.spill.load1354 = load volatile <8 x float>, ptr %.spill132, align 32
  %6428 = fsub <8 x float> %.spill.load1354, %6414
  %.spill.load1355 = load volatile <8 x float>, ptr %.spill133, align 32
  %6429 = fsub <8 x float> %.spill.load1355, %6414
  %.spill.load1356 = load volatile <8 x float>, ptr %.spill134, align 32
  %6430 = fsub <8 x float> %.spill.load1356, %6414
  %6431 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6425, <8 x float> zeroinitializer
  %native.exp1357 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %6431)
  %6432 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6426, <8 x float> zeroinitializer
  %native.exp1358 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %6432)
  %6433 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6427, <8 x float> zeroinitializer
  %native.exp1359 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %6433)
  %6434 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6428, <8 x float> zeroinitializer
  %native.exp1360 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %6434)
  %6435 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6429, <8 x float> zeroinitializer
  %native.exp1361 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %6435)
  %6436 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6430, <8 x float> zeroinitializer
  %native.exp1362 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %6436)
  %.spill.load1363 = load volatile <8 x i1>, ptr %.spill123, align 1
  %6437 = select <8 x i1> %.spill.load1363, <8 x float> %native.exp1357, <8 x float> zeroinitializer
  %6438 = load <8 x float>, ptr %.spill144, align 32
  %6439 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6437, <8 x float> %6438
  store <8 x float> %6439, ptr %.spill144, align 32
  %.spill.load1364 = load volatile <8 x i1>, ptr %.spill125, align 1
  %6440 = select <8 x i1> %.spill.load1364, <8 x float> %native.exp1358, <8 x float> zeroinitializer
  %6441 = load <8 x float>, ptr %.spill145, align 32
  %6442 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6440, <8 x float> %6441
  store <8 x float> %6442, ptr %.spill145, align 32
  %.spill.load1365 = load volatile <8 x i1>, ptr %.spill127, align 1
  %6443 = select <8 x i1> %.spill.load1365, <8 x float> %native.exp1359, <8 x float> zeroinitializer
  %6444 = load <8 x float>, ptr %.spill146, align 32
  %6445 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6443, <8 x float> %6444
  store <8 x float> %6445, ptr %.spill146, align 32
  %.spill.load1366 = load volatile <8 x i1>, ptr %.spill124, align 1
  %6446 = select <8 x i1> %.spill.load1366, <8 x float> %native.exp1360, <8 x float> zeroinitializer
  %6447 = load <8 x float>, ptr %.spill147, align 32
  %6448 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6446, <8 x float> %6447
  store <8 x float> %6448, ptr %.spill147, align 32
  %.spill.load1367 = load volatile <8 x i1>, ptr %.spill126, align 1
  %6449 = select <8 x i1> %.spill.load1367, <8 x float> %native.exp1361, <8 x float> zeroinitializer
  %6450 = load <8 x float>, ptr %.spill148, align 32
  %6451 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6449, <8 x float> %6450
  store <8 x float> %6451, ptr %.spill148, align 32
  %.spill.load1368 = load volatile <8 x i1>, ptr %.spill128, align 1
  %6452 = select <8 x i1> %.spill.load1368, <8 x float> %native.exp1362, <8 x float> zeroinitializer
  %6453 = load <8 x float>, ptr %.spill149, align 32
  %6454 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6452, <8 x float> %6453
  store <8 x float> %6454, ptr %.spill149, align 32
  %6455 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill150, align 64
  %6456 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %6457 = extractvalue { <8 x ptr>, <8 x i64> } %6455, 0
  %6458 = select <8 x i1> %convergence.cascade.result1343, <8 x ptr> %6456, <8 x ptr> %6457
  %6459 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %6460 = extractvalue { <8 x ptr>, <8 x i64> } %6455, 1
  %6461 = select <8 x i1> %convergence.cascade.result1343, <8 x i64> %6459, <8 x i64> %6460
  %6462 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6458, 0
  %6463 = insertvalue { <8 x ptr>, <8 x i64> } %6462, <8 x i64> %6461, 1
  store volatile { <8 x ptr>, <8 x i64> } %6463, ptr %tile_snapshot.spill150, align 64
  %6464 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %6465 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %6466 = add <8 x i64> %6465, zeroinitializer
  %6467 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6464, 0
  %6468 = insertvalue { <8 x ptr>, <8 x i64> } %6467, <8 x i64> %6466, 1
  %6469 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %6470 = extractvalue { <8 x ptr>, <8 x i64> } %6468, 1
  %6471 = extractelement <8 x ptr> %6469, i32 0
  %6472 = extractelement <8 x i64> %6470, i32 %6410
  %6473 = zext i32 %6410 to i64
  %6474 = mul i64 %6473, 4
  %6475 = sub i64 %6472, %6474
  %6476 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1343)
  %6477 = select i1 %6476, i64 %6475, i64 0
  %private.contiguous.address1369 = getelementptr i8, ptr %6471, i64 %6477
  %private.contiguous.preserve1370 = load <8 x float>, ptr %private.contiguous.address1369, align 4
  %6478 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6437, <8 x float> %private.contiguous.preserve1370
  store <8 x float> %6478, ptr %private.contiguous.address1369, align 4
  %6479 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %6480 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %6481 = add <8 x i64> %6480, splat (i64 32)
  %6482 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6479, 0
  %6483 = insertvalue { <8 x ptr>, <8 x i64> } %6482, <8 x i64> %6481, 1
  %6484 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %6485 = extractvalue { <8 x ptr>, <8 x i64> } %6483, 1
  %6486 = extractelement <8 x ptr> %6484, i32 0
  %6487 = extractelement <8 x i64> %6485, i32 %6410
  %6488 = zext i32 %6410 to i64
  %6489 = mul i64 %6488, 4
  %6490 = sub i64 %6487, %6489
  %6491 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1343)
  %6492 = select i1 %6491, i64 %6490, i64 0
  %private.contiguous.address1371 = getelementptr i8, ptr %6486, i64 %6492
  %private.contiguous.preserve1372 = load <8 x float>, ptr %private.contiguous.address1371, align 4
  %6493 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6440, <8 x float> %private.contiguous.preserve1372
  store <8 x float> %6493, ptr %private.contiguous.address1371, align 4
  %6494 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %6495 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %6496 = add <8 x i64> %6495, splat (i64 64)
  %6497 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6494, 0
  %6498 = insertvalue { <8 x ptr>, <8 x i64> } %6497, <8 x i64> %6496, 1
  %6499 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %6500 = extractvalue { <8 x ptr>, <8 x i64> } %6498, 1
  %6501 = extractelement <8 x ptr> %6499, i32 0
  %6502 = extractelement <8 x i64> %6500, i32 %6410
  %6503 = zext i32 %6410 to i64
  %6504 = mul i64 %6503, 4
  %6505 = sub i64 %6502, %6504
  %6506 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1343)
  %6507 = select i1 %6506, i64 %6505, i64 0
  %private.contiguous.address1373 = getelementptr i8, ptr %6501, i64 %6507
  %private.contiguous.preserve1374 = load <8 x float>, ptr %private.contiguous.address1373, align 4
  %6508 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6443, <8 x float> %private.contiguous.preserve1374
  store <8 x float> %6508, ptr %private.contiguous.address1373, align 4
  %6509 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %6510 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %6511 = add <8 x i64> %6510, splat (i64 96)
  %6512 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6509, 0
  %6513 = insertvalue { <8 x ptr>, <8 x i64> } %6512, <8 x i64> %6511, 1
  %6514 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %6515 = extractvalue { <8 x ptr>, <8 x i64> } %6513, 1
  %6516 = extractelement <8 x ptr> %6514, i32 0
  %6517 = extractelement <8 x i64> %6515, i32 %6410
  %6518 = zext i32 %6410 to i64
  %6519 = mul i64 %6518, 4
  %6520 = sub i64 %6517, %6519
  %6521 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1343)
  %6522 = select i1 %6521, i64 %6520, i64 0
  %private.contiguous.address1375 = getelementptr i8, ptr %6516, i64 %6522
  %private.contiguous.preserve1376 = load <8 x float>, ptr %private.contiguous.address1375, align 4
  %6523 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6446, <8 x float> %private.contiguous.preserve1376
  store <8 x float> %6523, ptr %private.contiguous.address1375, align 4
  %6524 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %6525 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %6526 = add <8 x i64> %6525, splat (i64 128)
  %6527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6524, 0
  %6528 = insertvalue { <8 x ptr>, <8 x i64> } %6527, <8 x i64> %6526, 1
  %6529 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %6530 = extractvalue { <8 x ptr>, <8 x i64> } %6528, 1
  %6531 = extractelement <8 x ptr> %6529, i32 0
  %6532 = extractelement <8 x i64> %6530, i32 %6410
  %6533 = zext i32 %6410 to i64
  %6534 = mul i64 %6533, 4
  %6535 = sub i64 %6532, %6534
  %6536 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1343)
  %6537 = select i1 %6536, i64 %6535, i64 0
  %private.contiguous.address1377 = getelementptr i8, ptr %6531, i64 %6537
  %private.contiguous.preserve1378 = load <8 x float>, ptr %private.contiguous.address1377, align 4
  %6538 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6449, <8 x float> %private.contiguous.preserve1378
  store <8 x float> %6538, ptr %private.contiguous.address1377, align 4
  %6539 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %6540 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %6541 = add <8 x i64> %6540, splat (i64 160)
  %6542 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6539, 0
  %6543 = insertvalue { <8 x ptr>, <8 x i64> } %6542, <8 x i64> %6541, 1
  %6544 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %6545 = extractvalue { <8 x ptr>, <8 x i64> } %6543, 1
  %6546 = extractelement <8 x ptr> %6544, i32 0
  %6547 = extractelement <8 x i64> %6545, i32 %6410
  %6548 = zext i32 %6410 to i64
  %6549 = mul i64 %6548, 4
  %6550 = sub i64 %6547, %6549
  %6551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1343)
  %6552 = select i1 %6551, i64 %6550, i64 0
  %private.contiguous.address1379 = getelementptr i8, ptr %6546, i64 %6552
  %private.contiguous.preserve1380 = load <8 x float>, ptr %private.contiguous.address1379, align 4
  %6553 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6452, <8 x float> %private.contiguous.preserve1380
  store <8 x float> %6553, ptr %private.contiguous.address1379, align 4
  %.state1381 = load <8 x float>, ptr %.slot40, align 32
  %6554 = fmul <8 x float> %.state1381, %native.exp
  %6555 = load volatile <8 x float>, ptr %.spill151, align 32
  %6556 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6554, <8 x float> %6555
  store volatile <8 x float> %6556, ptr %.spill151, align 32
  %.state1382 = load <8 x float>, ptr %.slot41, align 32
  %6557 = fmul <8 x float> %.state1382, %native.exp1350
  %6558 = load volatile <8 x float>, ptr %.spill152, align 32
  %6559 = select <8 x i1> %convergence.cascade.result1343, <8 x float> %6557, <8 x float> %6558
  store volatile <8 x float> %6559, ptr %.spill152, align 32
  %6560 = load <8 x i64>, ptr %.slot153, align 64
  %6561 = select <8 x i1> %convergence.cascade.result1343, <8 x i64> zeroinitializer, <8 x i64> %6560
  store <8 x i64> %6561, ptr %.slot153, align 64
  %6562 = load <8 x float>, ptr %.slot154, align 32
  %6563 = select <8 x i1> %convergence.cascade.result1343, <8 x float> zeroinitializer, <8 x float> %6562
  store <8 x float> %6563, ptr %.slot154, align 32
  store <8 x i1> %convergence.cascade.result1343, ptr %current.mask, align 1
  %6564 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1343)
  br i1 %6564, label %schedule.73, label %scheduler.loop

varying.divergent1384:                            ; preds = %schedule.73
  %6565 = load i32, ptr %current.token, align 4
  %6566 = icmp ne i32 %6565, 0
  %6567 = sub i32 %6565, 1
  %6568 = select i1 %6566, i32 %6567, i32 0
  %6569 = load i8, ptr %frame.active, align 1
  %6570 = trunc i32 %6568 to i8
  %6571 = shl i8 1, %6570
  %6572 = and i8 %6569, %6571
  %6573 = icmp ne i8 %6572, 0
  %6574 = load <8 x i32>, ptr %frame.static.id, align 32
  %6575 = extractelement <8 x i32> %6574, i32 %6568
  %6576 = icmp eq i32 %6575, 32
  %6577 = and i1 %6573, %6576
  %6578 = and i1 %6566, %6577
  %6579 = xor i1 %6578, true
  %6580 = and i1 true, %6579
  %6581 = xor i8 %6569, -1
  %6582 = icmp ne i8 %6581, 0
  %6583 = xor i1 %6582, true
  %6584 = and i1 %6580, %6583
  br i1 %6584, label %convergence.overflow.trap1386, label %convergence.overflow.resume1387

varying.coherent1385:                             ; preds = %schedule.73
  br i1 %1000, label %varying.coherent.true1390, label %varying.coherent.false1391

convergence.overflow.trap1386:                    ; preds = %varying.divergent1384
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1387:                  ; preds = %varying.divergent1384
  %6585 = call i8 @llvm.cttz.i8(i8 %6581, i1 false)
  %6586 = zext i8 %6585 to i32
  %6587 = select i1 %6582, i32 %6586, i32 0
  %6588 = trunc i32 %6587 to i8
  %6589 = shl i8 1, %6588
  %6590 = or i8 %6569, %6589
  %6591 = select i1 %6580, i8 %6590, i8 %6569
  store i8 %6591, ptr %frame.active, align 1
  %6592 = load <8 x i32>, ptr %frame.static.id, align 32
  %6593 = extractelement <8 x i32> %6592, i32 %6587
  %6594 = select i1 %6580, i32 32, i32 %6593
  %6595 = load <8 x i32>, ptr %frame.static.id, align 32
  %6596 = insertelement <8 x i32> %6595, i32 %6594, i32 %6587
  store <8 x i32> %6596, ptr %frame.static.id, align 32
  %6597 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6598 = extractelement <8 x i32> %6597, i32 %6587
  %6599 = select i1 %6580, i32 %6565, i32 %6598
  %6600 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6601 = insertelement <8 x i32> %6600, i32 %6599, i32 %6587
  store <8 x i32> %6601, ptr %frame.parent.token, align 32
  %6602 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6587
  %6603 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6587
  %6604 = load <8 x i1>, ptr %6602, align 1
  %6605 = load <8 x i1>, ptr %6603, align 1
  %6606 = select i1 %6580, <8 x i1> %990, <8 x i1> %6604
  store <8 x i1> %6606, ptr %6602, align 1
  %6607 = select i1 %6580, <8 x i1> zeroinitializer, <8 x i1> %6605
  store <8 x i1> %6607, ptr %6603, align 1
  %6608 = add i32 %6587, 1
  %6609 = select i1 %6578, i32 %6565, i32 %6608
  %6610 = select i1 true, i32 %6609, i32 %6565
  store i32 %6610, ptr %current.token, align 4
  %6611 = load i32, ptr %current.token, align 4
  %6612 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %997)
  %6613 = load i32, ptr %ready.count, align 4
  %6614 = icmp uge i32 %6613, 8
  %6615 = and i1 %6612, %6614
  br i1 %6615, label %ready.overflow.trap1388, label %ready.overflow.resume1389

ready.overflow.trap1388:                          ; preds = %convergence.overflow.resume1387
  call void @llvm.trap()
  unreachable

ready.overflow.resume1389:                        ; preds = %convergence.overflow.resume1387
  %6616 = select i1 %6612, i32 %6613, i32 0
  %6617 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6616
  %6618 = load <8 x i1>, ptr %6617, align 1
  %6619 = select i1 %6612, <8 x i1> %997, <8 x i1> %6618
  store <8 x i1> %6619, ptr %6617, align 1
  %6620 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6616
  %6621 = load i32, ptr %6620, align 4
  %6622 = select i1 %6612, i32 74, i32 %6621
  store i32 %6622, ptr %6620, align 4
  %6623 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6616
  %6624 = load i32, ptr %6623, align 4
  %6625 = select i1 %6612, i32 %6611, i32 %6624
  store i32 %6625, ptr %6623, align 4
  %6626 = add i32 %6613, 1
  %6627 = select i1 %6612, i32 %6626, i32 %6613
  store i32 %6627, ptr %ready.count, align 4
  %6628 = load <8 x i1>, ptr %runnable.mask, align 1
  %6629 = or <8 x i1> %6628, %997
  store <8 x i1> %6629, ptr %runnable.mask, align 1
  store <8 x i1> %999, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1390:                        ; preds = %varying.coherent1385
  store <8 x i1> %990, ptr %current.mask, align 1
  %6630 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %990)
  br i1 %6630, label %schedule.74, label %scheduler.loop

varying.coherent.false1391:                       ; preds = %varying.coherent1385
  store <8 x i1> %990, ptr %current.mask, align 1
  %6631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %990)
  br i1 %6631, label %schedule.75, label %scheduler.loop

convergence.cascade1399:                          ; preds = %convergence.cascade1399, %schedule.75
  %convergence.cascade.flow1403 = phi <8 x i1> [ %1036, %schedule.75 ], [ %6674, %convergence.cascade1399 ]
  %convergence.cascade.depth1404 = phi i32 [ 0, %schedule.75 ], [ %6675, %convergence.cascade1399 ]
  %6632 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1403)
  %6633 = load i32, ptr %current.token, align 4
  %6634 = icmp ne i32 %6633, 0
  %6635 = and i1 %6632, %6634
  %6636 = sub i32 %6633, 1
  %6637 = select i1 %6635, i32 %6636, i32 0
  %6638 = load i8, ptr %frame.active, align 1
  %6639 = trunc i32 %6637 to i8
  %6640 = shl i8 1, %6639
  %6641 = and i8 %6638, %6640
  %6642 = icmp ne i8 %6641, 0
  %6643 = load <8 x i32>, ptr %frame.static.id, align 32
  %6644 = extractelement <8 x i32> %6643, i32 %6637
  %convergence.target.pointer1405 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %6644
  %convergence.dynamic.target1406 = load i32, ptr %convergence.target.pointer1405, align 4
  %6645 = icmp eq i32 %convergence.dynamic.target1406, 75
  %6646 = and i1 %6642, %6645
  %6647 = and i1 %6635, %6646
  %6648 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6637
  %6649 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6637
  %6650 = load <8 x i1>, ptr %6648, align 1
  %6651 = load <8 x i1>, ptr %6649, align 1
  %6652 = or <8 x i1> %6651, %convergence.cascade.flow1403
  %6653 = load <8 x i1>, ptr %live.mask, align 1
  %6654 = and <8 x i1> %6650, %6653
  %6655 = icmp eq <8 x i1> %6652, %6654
  %6656 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6655)
  %6657 = and i1 %6647, %6656
  %6658 = select i1 %6657, <8 x i1> zeroinitializer, <8 x i1> %6652
  %6659 = select i1 %6647, <8 x i1> %6658, <8 x i1> %6651
  store <8 x i1> %6659, ptr %6649, align 1
  %6660 = select i1 %6657, <8 x i1> zeroinitializer, <8 x i1> %6650
  store <8 x i1> %6660, ptr %6648, align 1
  %6661 = trunc i32 %6637 to i8
  %6662 = shl i8 1, %6661
  %6663 = xor i8 %6662, -1
  %6664 = and i8 %6638, %6663
  %6665 = select i1 %6657, i8 %6664, i8 %6638
  store i8 %6665, ptr %frame.active, align 1
  %.splatinsert1407 = insertelement <8 x i1> poison, i1 %6647, i64 0
  %.splat1408 = shufflevector <8 x i1> %.splatinsert1407, <8 x i1> poison, <8 x i32> zeroinitializer
  %6666 = and <8 x i1> %convergence.cascade.flow1403, %.splat1408
  %6667 = load <8 x i1>, ptr %runnable.mask, align 1
  %6668 = xor <8 x i1> %6666, splat (i1 true)
  %6669 = and <8 x i1> %6667, %6668
  store <8 x i1> %6669, ptr %runnable.mask, align 1
  %.splatinsert1409 = insertelement <8 x i1> poison, i1 %6657, i64 0
  %.splat1410 = shufflevector <8 x i1> %.splatinsert1409, <8 x i1> poison, <8 x i32> zeroinitializer
  %6670 = select <8 x i1> %.splat1410, <8 x i1> %6652, <8 x i1> zeroinitializer
  %6671 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6672 = extractelement <8 x i32> %6671, i32 %6637
  %6673 = select i1 %6657, i32 %6672, i32 %6633
  store i32 %6673, ptr %current.token, align 4
  %.splatinsert1411 = insertelement <8 x i1> poison, i1 %6647, i64 0
  %.splat1412 = shufflevector <8 x i1> %.splatinsert1411, <8 x i1> poison, <8 x i32> zeroinitializer
  %6674 = select <8 x i1> %.splat1412, <8 x i1> %6670, <8 x i1> %convergence.cascade.flow1403
  %6675 = add i32 %convergence.cascade.depth1404, 1
  %6676 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6674)
  %6677 = icmp ult i32 %6675, 8
  %6678 = and i1 %6676, %6677
  %6679 = and i1 %6647, %6678
  %convergence.parent.token1413 = load i32, ptr %current.token, align 4
  %convergence.parent.present1414 = icmp ne i32 %convergence.parent.token1413, 0
  %6680 = and i1 %6679, %convergence.parent.present1414
  br i1 %6680, label %convergence.cascade1399, label %convergence.cascade.exit1400

convergence.cascade.exit1400:                     ; preds = %convergence.cascade1399, %schedule.75
  %convergence.cascade.result1415 = phi <8 x i1> [ %1036, %schedule.75 ], [ %6674, %convergence.cascade1399 ]
  %6681 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1415)
  br i1 %6681, label %convergence.target.75.ready, label %scheduler.loop

convergence.target.75.ready:                      ; preds = %convergence.cascade.exit1400
  %6682 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1415)
  %6683 = bitcast <8 x i1> %convergence.cascade.result1415 to i8
  %6684 = call i8 @llvm.cttz.i8(i8 %6683, i1 false)
  %6685 = zext i8 %6684 to i32
  %6686 = select i1 %6682, i32 %6685, i32 0
  %6687 = load <8 x i64>, ptr %.slot155, align 64
  %6688 = select <8 x i1> %convergence.cascade.result1415, <8 x i64> zeroinitializer, <8 x i64> %6687
  store <8 x i64> %6688, ptr %.slot155, align 64
  %6689 = load <8 x float>, ptr %.slot156, align 32
  %6690 = select <8 x i1> %convergence.cascade.result1415, <8 x float> zeroinitializer, <8 x float> %6689
  store <8 x float> %6690, ptr %.slot156, align 32
  store <8 x i1> %convergence.cascade.result1415, ptr %current.mask, align 1
  %6691 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1415)
  br i1 %6691, label %schedule.76, label %scheduler.loop

varying.divergent1417:                            ; preds = %schedule.76
  %6692 = load i32, ptr %current.token, align 4
  %6693 = icmp ne i32 %6692, 0
  %6694 = sub i32 %6692, 1
  %6695 = select i1 %6693, i32 %6694, i32 0
  %6696 = load i8, ptr %frame.active, align 1
  %6697 = trunc i32 %6695 to i8
  %6698 = shl i8 1, %6697
  %6699 = and i8 %6696, %6698
  %6700 = icmp ne i8 %6699, 0
  %6701 = load <8 x i32>, ptr %frame.static.id, align 32
  %6702 = extractelement <8 x i32> %6701, i32 %6695
  %6703 = icmp eq i32 %6702, 33
  %6704 = and i1 %6700, %6703
  %6705 = and i1 %6693, %6704
  %6706 = xor i1 %6705, true
  %6707 = and i1 true, %6706
  %6708 = xor i8 %6696, -1
  %6709 = icmp ne i8 %6708, 0
  %6710 = xor i1 %6709, true
  %6711 = and i1 %6707, %6710
  br i1 %6711, label %convergence.overflow.trap1419, label %convergence.overflow.resume1420

varying.coherent1418:                             ; preds = %schedule.76
  br i1 %1047, label %varying.coherent.true1423, label %varying.coherent.false1424

convergence.overflow.trap1419:                    ; preds = %varying.divergent1417
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1420:                  ; preds = %varying.divergent1417
  %6712 = call i8 @llvm.cttz.i8(i8 %6708, i1 false)
  %6713 = zext i8 %6712 to i32
  %6714 = select i1 %6709, i32 %6713, i32 0
  %6715 = trunc i32 %6714 to i8
  %6716 = shl i8 1, %6715
  %6717 = or i8 %6696, %6716
  %6718 = select i1 %6707, i8 %6717, i8 %6696
  store i8 %6718, ptr %frame.active, align 1
  %6719 = load <8 x i32>, ptr %frame.static.id, align 32
  %6720 = extractelement <8 x i32> %6719, i32 %6714
  %6721 = select i1 %6707, i32 33, i32 %6720
  %6722 = load <8 x i32>, ptr %frame.static.id, align 32
  %6723 = insertelement <8 x i32> %6722, i32 %6721, i32 %6714
  store <8 x i32> %6723, ptr %frame.static.id, align 32
  %6724 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6725 = extractelement <8 x i32> %6724, i32 %6714
  %6726 = select i1 %6707, i32 %6692, i32 %6725
  %6727 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6728 = insertelement <8 x i32> %6727, i32 %6726, i32 %6714
  store <8 x i32> %6728, ptr %frame.parent.token, align 32
  %6729 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6714
  %6730 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6714
  %6731 = load <8 x i1>, ptr %6729, align 1
  %6732 = load <8 x i1>, ptr %6730, align 1
  %6733 = select i1 %6707, <8 x i1> %1037, <8 x i1> %6731
  store <8 x i1> %6733, ptr %6729, align 1
  %6734 = select i1 %6707, <8 x i1> zeroinitializer, <8 x i1> %6732
  store <8 x i1> %6734, ptr %6730, align 1
  %6735 = add i32 %6714, 1
  %6736 = select i1 %6705, i32 %6692, i32 %6735
  %6737 = select i1 true, i32 %6736, i32 %6692
  store i32 %6737, ptr %current.token, align 4
  %6738 = load i32, ptr %current.token, align 4
  %6739 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1044)
  %6740 = load i32, ptr %ready.count, align 4
  %6741 = icmp uge i32 %6740, 8
  %6742 = and i1 %6739, %6741
  br i1 %6742, label %ready.overflow.trap1421, label %ready.overflow.resume1422

ready.overflow.trap1421:                          ; preds = %convergence.overflow.resume1420
  call void @llvm.trap()
  unreachable

ready.overflow.resume1422:                        ; preds = %convergence.overflow.resume1420
  %6743 = select i1 %6739, i32 %6740, i32 0
  %6744 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6743
  %6745 = load <8 x i1>, ptr %6744, align 1
  %6746 = select i1 %6739, <8 x i1> %1044, <8 x i1> %6745
  store <8 x i1> %6746, ptr %6744, align 1
  %6747 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6743
  %6748 = load i32, ptr %6747, align 4
  %6749 = select i1 %6739, i32 77, i32 %6748
  store i32 %6749, ptr %6747, align 4
  %6750 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6743
  %6751 = load i32, ptr %6750, align 4
  %6752 = select i1 %6739, i32 %6738, i32 %6751
  store i32 %6752, ptr %6750, align 4
  %6753 = add i32 %6740, 1
  %6754 = select i1 %6739, i32 %6753, i32 %6740
  store i32 %6754, ptr %ready.count, align 4
  %6755 = load <8 x i1>, ptr %runnable.mask, align 1
  %6756 = or <8 x i1> %6755, %1044
  store <8 x i1> %6756, ptr %runnable.mask, align 1
  store <8 x i1> %1046, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1423:                        ; preds = %varying.coherent1418
  store <8 x i1> %1037, ptr %current.mask, align 1
  %6757 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1037)
  br i1 %6757, label %schedule.77, label %scheduler.loop

varying.coherent.false1424:                       ; preds = %varying.coherent1418
  store <8 x i1> %1037, ptr %current.mask, align 1
  %6758 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1037)
  br i1 %6758, label %schedule.78, label %scheduler.loop

convergence.cascade1432:                          ; preds = %convergence.cascade1432, %schedule.78
  %convergence.cascade.flow1436 = phi <8 x i1> [ %1083, %schedule.78 ], [ %6801, %convergence.cascade1432 ]
  %convergence.cascade.depth1437 = phi i32 [ 0, %schedule.78 ], [ %6802, %convergence.cascade1432 ]
  %6759 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1436)
  %6760 = load i32, ptr %current.token, align 4
  %6761 = icmp ne i32 %6760, 0
  %6762 = and i1 %6759, %6761
  %6763 = sub i32 %6760, 1
  %6764 = select i1 %6762, i32 %6763, i32 0
  %6765 = load i8, ptr %frame.active, align 1
  %6766 = trunc i32 %6764 to i8
  %6767 = shl i8 1, %6766
  %6768 = and i8 %6765, %6767
  %6769 = icmp ne i8 %6768, 0
  %6770 = load <8 x i32>, ptr %frame.static.id, align 32
  %6771 = extractelement <8 x i32> %6770, i32 %6764
  %convergence.target.pointer1438 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %6771
  %convergence.dynamic.target1439 = load i32, ptr %convergence.target.pointer1438, align 4
  %6772 = icmp eq i32 %convergence.dynamic.target1439, 78
  %6773 = and i1 %6769, %6772
  %6774 = and i1 %6762, %6773
  %6775 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6764
  %6776 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6764
  %6777 = load <8 x i1>, ptr %6775, align 1
  %6778 = load <8 x i1>, ptr %6776, align 1
  %6779 = or <8 x i1> %6778, %convergence.cascade.flow1436
  %6780 = load <8 x i1>, ptr %live.mask, align 1
  %6781 = and <8 x i1> %6777, %6780
  %6782 = icmp eq <8 x i1> %6779, %6781
  %6783 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6782)
  %6784 = and i1 %6774, %6783
  %6785 = select i1 %6784, <8 x i1> zeroinitializer, <8 x i1> %6779
  %6786 = select i1 %6774, <8 x i1> %6785, <8 x i1> %6778
  store <8 x i1> %6786, ptr %6776, align 1
  %6787 = select i1 %6784, <8 x i1> zeroinitializer, <8 x i1> %6777
  store <8 x i1> %6787, ptr %6775, align 1
  %6788 = trunc i32 %6764 to i8
  %6789 = shl i8 1, %6788
  %6790 = xor i8 %6789, -1
  %6791 = and i8 %6765, %6790
  %6792 = select i1 %6784, i8 %6791, i8 %6765
  store i8 %6792, ptr %frame.active, align 1
  %.splatinsert1440 = insertelement <8 x i1> poison, i1 %6774, i64 0
  %.splat1441 = shufflevector <8 x i1> %.splatinsert1440, <8 x i1> poison, <8 x i32> zeroinitializer
  %6793 = and <8 x i1> %convergence.cascade.flow1436, %.splat1441
  %6794 = load <8 x i1>, ptr %runnable.mask, align 1
  %6795 = xor <8 x i1> %6793, splat (i1 true)
  %6796 = and <8 x i1> %6794, %6795
  store <8 x i1> %6796, ptr %runnable.mask, align 1
  %.splatinsert1442 = insertelement <8 x i1> poison, i1 %6784, i64 0
  %.splat1443 = shufflevector <8 x i1> %.splatinsert1442, <8 x i1> poison, <8 x i32> zeroinitializer
  %6797 = select <8 x i1> %.splat1443, <8 x i1> %6779, <8 x i1> zeroinitializer
  %6798 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6799 = extractelement <8 x i32> %6798, i32 %6764
  %6800 = select i1 %6784, i32 %6799, i32 %6760
  store i32 %6800, ptr %current.token, align 4
  %.splatinsert1444 = insertelement <8 x i1> poison, i1 %6774, i64 0
  %.splat1445 = shufflevector <8 x i1> %.splatinsert1444, <8 x i1> poison, <8 x i32> zeroinitializer
  %6801 = select <8 x i1> %.splat1445, <8 x i1> %6797, <8 x i1> %convergence.cascade.flow1436
  %6802 = add i32 %convergence.cascade.depth1437, 1
  %6803 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6801)
  %6804 = icmp ult i32 %6802, 8
  %6805 = and i1 %6803, %6804
  %6806 = and i1 %6774, %6805
  %convergence.parent.token1446 = load i32, ptr %current.token, align 4
  %convergence.parent.present1447 = icmp ne i32 %convergence.parent.token1446, 0
  %6807 = and i1 %6806, %convergence.parent.present1447
  br i1 %6807, label %convergence.cascade1432, label %convergence.cascade.exit1433

convergence.cascade.exit1433:                     ; preds = %convergence.cascade1432, %schedule.78
  %convergence.cascade.result1448 = phi <8 x i1> [ %1083, %schedule.78 ], [ %6801, %convergence.cascade1432 ]
  %6808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  br i1 %6808, label %convergence.target.78.ready, label %scheduler.loop

convergence.target.78.ready:                      ; preds = %convergence.cascade.exit1433
  %6809 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %6810 = bitcast <8 x i1> %convergence.cascade.result1448 to i8
  %6811 = call i8 @llvm.cttz.i8(i8 %6810, i1 false)
  %6812 = zext i8 %6811 to i32
  %6813 = select i1 %6809, i32 %6812, i32 0
  %.spill.load1449 = load volatile <8 x float>, ptr %.spill151, align 32
  %.state1450 = load <8 x float>, ptr %.slot154, align 32
  %6814 = fadd <8 x float> %.spill.load1449, %.state1450
  %6815 = load volatile <8 x float>, ptr %.spill157, align 32
  %6816 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6814, <8 x float> %6815
  store volatile <8 x float> %6816, ptr %.spill157, align 32
  %.spill.load1451 = load volatile <8 x float>, ptr %.spill152, align 32
  %.state1452 = load <8 x float>, ptr %.slot156, align 32
  %6817 = fadd <8 x float> %.spill.load1451, %.state1452
  %6818 = load volatile <8 x float>, ptr %.spill158, align 32
  %6819 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6817, <8 x float> %6818
  store volatile <8 x float> %6819, ptr %.spill158, align 32
  %.state1453 = load <8 x float>, ptr %.slot42, align 32
  %.spill.load1454 = load <8 x float>, ptr %.spill142, align 32
  %6820 = fmul <8 x float> %.state1453, %.spill.load1454
  %6821 = load volatile <8 x float>, ptr %.spill159, align 32
  %6822 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6820, <8 x float> %6821
  store volatile <8 x float> %6822, ptr %.spill159, align 32
  %.state1455 = load <8 x float>, ptr %.slot43, align 32
  %.spill.load1456 = load <8 x float>, ptr %.spill142, align 32
  %6823 = fmul <8 x float> %.state1455, %.spill.load1456
  %6824 = load volatile <8 x float>, ptr %.spill160, align 32
  %6825 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6823, <8 x float> %6824
  store volatile <8 x float> %6825, ptr %.spill160, align 32
  %.state1457 = load <8 x float>, ptr %.slot44, align 32
  %.spill.load1458 = load <8 x float>, ptr %.spill142, align 32
  %6826 = fmul <8 x float> %.state1457, %.spill.load1458
  %6827 = load volatile <8 x float>, ptr %.spill161, align 32
  %6828 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6826, <8 x float> %6827
  store volatile <8 x float> %6828, ptr %.spill161, align 32
  %.state1459 = load <8 x float>, ptr %.slot45, align 32
  %.spill.load1460 = load <8 x float>, ptr %.spill142, align 32
  %6829 = fmul <8 x float> %.state1459, %.spill.load1460
  %6830 = load volatile <8 x float>, ptr %.spill162, align 32
  %6831 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6829, <8 x float> %6830
  store volatile <8 x float> %6831, ptr %.spill162, align 32
  %.state1461 = load <8 x float>, ptr %.slot46, align 32
  %.spill.load1462 = load <8 x float>, ptr %.spill143, align 32
  %6832 = fmul <8 x float> %.state1461, %.spill.load1462
  %6833 = load volatile <8 x float>, ptr %.spill163, align 32
  %6834 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6832, <8 x float> %6833
  store volatile <8 x float> %6834, ptr %.spill163, align 32
  %.state1463 = load <8 x float>, ptr %.slot47, align 32
  %.spill.load1464 = load <8 x float>, ptr %.spill143, align 32
  %6835 = fmul <8 x float> %.state1463, %.spill.load1464
  %6836 = load volatile <8 x float>, ptr %.spill164, align 32
  %6837 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6835, <8 x float> %6836
  store volatile <8 x float> %6837, ptr %.spill164, align 32
  %.state1465 = load <8 x float>, ptr %.slot48, align 32
  %.spill.load1466 = load <8 x float>, ptr %.spill143, align 32
  %6838 = fmul <8 x float> %.state1465, %.spill.load1466
  %6839 = load volatile <8 x float>, ptr %.spill165, align 32
  %6840 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6838, <8 x float> %6839
  store volatile <8 x float> %6840, ptr %.spill165, align 32
  %.state1467 = load <8 x float>, ptr %.slot49, align 32
  %.spill.load1468 = load <8 x float>, ptr %.spill143, align 32
  %6841 = fmul <8 x float> %.state1467, %.spill.load1468
  %6842 = load volatile <8 x float>, ptr %.spill166, align 32
  %6843 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6841, <8 x float> %6842
  store volatile <8 x float> %6843, ptr %.spill166, align 32
  %.spill.load1469 = load <8 x float>, ptr %.spill144, align 32
  %.spill.load1470 = load volatile <8 x float>, ptr %.spill89, align 32
  %6844 = fmul <8 x float> %.spill.load1469, %.spill.load1470
  %.spill.load1471 = load <8 x float>, ptr %.spill144, align 32
  %.spill.load1472 = load volatile <8 x float>, ptr %.spill90, align 32
  %6845 = fmul <8 x float> %.spill.load1471, %.spill.load1472
  %.spill.load1473 = load <8 x float>, ptr %.spill144, align 32
  %.spill.load1474 = load volatile <8 x float>, ptr %.spill91, align 32
  %6846 = fmul <8 x float> %.spill.load1473, %.spill.load1474
  %.spill.load1475 = load <8 x float>, ptr %.spill144, align 32
  %.spill.load1476 = load volatile <8 x float>, ptr %.spill92, align 32
  %6847 = fmul <8 x float> %.spill.load1475, %.spill.load1476
  %.spill.load1477 = load <8 x float>, ptr %.spill145, align 32
  %.state1478 = load <8 x float>, ptr %.slot95, align 32
  %6848 = fmul <8 x float> %.spill.load1477, %.state1478
  %.spill.load1479 = load <8 x float>, ptr %.spill145, align 32
  %.state1480 = load <8 x float>, ptr %.slot97, align 32
  %6849 = fmul <8 x float> %.spill.load1479, %.state1480
  %.spill.load1481 = load <8 x float>, ptr %.spill145, align 32
  %.state1482 = load <8 x float>, ptr %.slot99, align 32
  %6850 = fmul <8 x float> %.spill.load1481, %.state1482
  %.spill.load1483 = load <8 x float>, ptr %.spill145, align 32
  %.state1484 = load <8 x float>, ptr %.slot101, align 32
  %6851 = fmul <8 x float> %.spill.load1483, %.state1484
  %.spill.load1485 = load <8 x float>, ptr %.spill146, align 32
  %.state1486 = load <8 x float>, ptr %.slot104, align 32
  %6852 = fmul <8 x float> %.spill.load1485, %.state1486
  %.spill.load1487 = load <8 x float>, ptr %.spill146, align 32
  %.state1488 = load <8 x float>, ptr %.slot106, align 32
  %6853 = fmul <8 x float> %.spill.load1487, %.state1488
  %.spill.load1489 = load <8 x float>, ptr %.spill146, align 32
  %.state1490 = load <8 x float>, ptr %.slot108, align 32
  %6854 = fmul <8 x float> %.spill.load1489, %.state1490
  %.spill.load1491 = load <8 x float>, ptr %.spill146, align 32
  %.state1492 = load <8 x float>, ptr %.slot110, align 32
  %6855 = fmul <8 x float> %.spill.load1491, %.state1492
  %.spill.load1493 = load <8 x float>, ptr %.spill147, align 32
  %.spill.load1494 = load volatile <8 x float>, ptr %.spill89, align 32
  %6856 = fmul <8 x float> %.spill.load1493, %.spill.load1494
  %.spill.load1495 = load <8 x float>, ptr %.spill147, align 32
  %.spill.load1496 = load volatile <8 x float>, ptr %.spill90, align 32
  %6857 = fmul <8 x float> %.spill.load1495, %.spill.load1496
  %.spill.load1497 = load <8 x float>, ptr %.spill147, align 32
  %.spill.load1498 = load volatile <8 x float>, ptr %.spill91, align 32
  %6858 = fmul <8 x float> %.spill.load1497, %.spill.load1498
  %.spill.load1499 = load <8 x float>, ptr %.spill147, align 32
  %.spill.load1500 = load volatile <8 x float>, ptr %.spill92, align 32
  %6859 = fmul <8 x float> %.spill.load1499, %.spill.load1500
  %.spill.load1501 = load <8 x float>, ptr %.spill148, align 32
  %.state1502 = load <8 x float>, ptr %.slot95, align 32
  %6860 = fmul <8 x float> %.spill.load1501, %.state1502
  %.spill.load1503 = load <8 x float>, ptr %.spill148, align 32
  %.state1504 = load <8 x float>, ptr %.slot97, align 32
  %6861 = fmul <8 x float> %.spill.load1503, %.state1504
  %.spill.load1505 = load <8 x float>, ptr %.spill148, align 32
  %.state1506 = load <8 x float>, ptr %.slot99, align 32
  %6862 = fmul <8 x float> %.spill.load1505, %.state1506
  %.spill.load1507 = load <8 x float>, ptr %.spill148, align 32
  %.state1508 = load <8 x float>, ptr %.slot101, align 32
  %6863 = fmul <8 x float> %.spill.load1507, %.state1508
  %.spill.load1509 = load <8 x float>, ptr %.spill149, align 32
  %.state1510 = load <8 x float>, ptr %.slot104, align 32
  %6864 = fmul <8 x float> %.spill.load1509, %.state1510
  %.spill.load1511 = load <8 x float>, ptr %.spill149, align 32
  %.state1512 = load <8 x float>, ptr %.slot106, align 32
  %6865 = fmul <8 x float> %.spill.load1511, %.state1512
  %.spill.load1513 = load <8 x float>, ptr %.spill149, align 32
  %.state1514 = load <8 x float>, ptr %.slot108, align 32
  %6866 = fmul <8 x float> %.spill.load1513, %.state1514
  %.spill.load1515 = load <8 x float>, ptr %.spill149, align 32
  %.state1516 = load <8 x float>, ptr %.slot110, align 32
  %6867 = fmul <8 x float> %.spill.load1515, %.state1516
  %6868 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %6869 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6870 = extractvalue { <8 x ptr>, <8 x i64> } %6868, 0
  %6871 = select <8 x i1> %convergence.cascade.result1448, <8 x ptr> %6869, <8 x ptr> %6870
  %6872 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %6873 = extractvalue { <8 x ptr>, <8 x i64> } %6868, 1
  %6874 = select <8 x i1> %convergence.cascade.result1448, <8 x i64> %6872, <8 x i64> %6873
  %6875 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6871, 0
  %6876 = insertvalue { <8 x ptr>, <8 x i64> } %6875, <8 x i64> %6874, 1
  store { <8 x ptr>, <8 x i64> } %6876, ptr %tile_snapshot.spill167, align 64
  %6877 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6878 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %6879 = add <8 x i64> %6878, zeroinitializer
  %6880 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6877, 0
  %6881 = insertvalue { <8 x ptr>, <8 x i64> } %6880, <8 x i64> %6879, 1
  %6882 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6883 = extractvalue { <8 x ptr>, <8 x i64> } %6881, 1
  %6884 = extractelement <8 x ptr> %6882, i32 0
  %6885 = extractelement <8 x i64> %6883, i32 %6813
  %6886 = zext i32 %6813 to i64
  %6887 = mul i64 %6886, 4
  %6888 = sub i64 %6885, %6887
  %6889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %6890 = select i1 %6889, i64 %6888, i64 0
  %private.contiguous.address1517 = getelementptr i8, ptr %6884, i64 %6890
  %private.contiguous.preserve1518 = load <8 x float>, ptr %private.contiguous.address1517, align 4
  %6891 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6844, <8 x float> %private.contiguous.preserve1518
  store <8 x float> %6891, ptr %private.contiguous.address1517, align 4
  %6892 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6893 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %6894 = add <8 x i64> %6893, splat (i64 32)
  %6895 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6892, 0
  %6896 = insertvalue { <8 x ptr>, <8 x i64> } %6895, <8 x i64> %6894, 1
  %6897 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6898 = extractvalue { <8 x ptr>, <8 x i64> } %6896, 1
  %6899 = extractelement <8 x ptr> %6897, i32 0
  %6900 = extractelement <8 x i64> %6898, i32 %6813
  %6901 = zext i32 %6813 to i64
  %6902 = mul i64 %6901, 4
  %6903 = sub i64 %6900, %6902
  %6904 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %6905 = select i1 %6904, i64 %6903, i64 0
  %private.contiguous.address1519 = getelementptr i8, ptr %6899, i64 %6905
  %private.contiguous.preserve1520 = load <8 x float>, ptr %private.contiguous.address1519, align 4
  %6906 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6845, <8 x float> %private.contiguous.preserve1520
  store <8 x float> %6906, ptr %private.contiguous.address1519, align 4
  %6907 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6908 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %6909 = add <8 x i64> %6908, splat (i64 64)
  %6910 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6907, 0
  %6911 = insertvalue { <8 x ptr>, <8 x i64> } %6910, <8 x i64> %6909, 1
  %6912 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6913 = extractvalue { <8 x ptr>, <8 x i64> } %6911, 1
  %6914 = extractelement <8 x ptr> %6912, i32 0
  %6915 = extractelement <8 x i64> %6913, i32 %6813
  %6916 = zext i32 %6813 to i64
  %6917 = mul i64 %6916, 4
  %6918 = sub i64 %6915, %6917
  %6919 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %6920 = select i1 %6919, i64 %6918, i64 0
  %private.contiguous.address1521 = getelementptr i8, ptr %6914, i64 %6920
  %private.contiguous.preserve1522 = load <8 x float>, ptr %private.contiguous.address1521, align 4
  %6921 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6846, <8 x float> %private.contiguous.preserve1522
  store <8 x float> %6921, ptr %private.contiguous.address1521, align 4
  %6922 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6923 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %6924 = add <8 x i64> %6923, splat (i64 96)
  %6925 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6922, 0
  %6926 = insertvalue { <8 x ptr>, <8 x i64> } %6925, <8 x i64> %6924, 1
  %6927 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6928 = extractvalue { <8 x ptr>, <8 x i64> } %6926, 1
  %6929 = extractelement <8 x ptr> %6927, i32 0
  %6930 = extractelement <8 x i64> %6928, i32 %6813
  %6931 = zext i32 %6813 to i64
  %6932 = mul i64 %6931, 4
  %6933 = sub i64 %6930, %6932
  %6934 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %6935 = select i1 %6934, i64 %6933, i64 0
  %private.contiguous.address1523 = getelementptr i8, ptr %6929, i64 %6935
  %private.contiguous.preserve1524 = load <8 x float>, ptr %private.contiguous.address1523, align 4
  %6936 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6847, <8 x float> %private.contiguous.preserve1524
  store <8 x float> %6936, ptr %private.contiguous.address1523, align 4
  %6937 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6938 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %6939 = add <8 x i64> %6938, splat (i64 128)
  %6940 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6937, 0
  %6941 = insertvalue { <8 x ptr>, <8 x i64> } %6940, <8 x i64> %6939, 1
  %6942 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6943 = extractvalue { <8 x ptr>, <8 x i64> } %6941, 1
  %6944 = extractelement <8 x ptr> %6942, i32 0
  %6945 = extractelement <8 x i64> %6943, i32 %6813
  %6946 = zext i32 %6813 to i64
  %6947 = mul i64 %6946, 4
  %6948 = sub i64 %6945, %6947
  %6949 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %6950 = select i1 %6949, i64 %6948, i64 0
  %private.contiguous.address1525 = getelementptr i8, ptr %6944, i64 %6950
  %private.contiguous.preserve1526 = load <8 x float>, ptr %private.contiguous.address1525, align 4
  %6951 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6848, <8 x float> %private.contiguous.preserve1526
  store <8 x float> %6951, ptr %private.contiguous.address1525, align 4
  %6952 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6953 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %6954 = add <8 x i64> %6953, splat (i64 160)
  %6955 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6952, 0
  %6956 = insertvalue { <8 x ptr>, <8 x i64> } %6955, <8 x i64> %6954, 1
  %6957 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6958 = extractvalue { <8 x ptr>, <8 x i64> } %6956, 1
  %6959 = extractelement <8 x ptr> %6957, i32 0
  %6960 = extractelement <8 x i64> %6958, i32 %6813
  %6961 = zext i32 %6813 to i64
  %6962 = mul i64 %6961, 4
  %6963 = sub i64 %6960, %6962
  %6964 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %6965 = select i1 %6964, i64 %6963, i64 0
  %private.contiguous.address1527 = getelementptr i8, ptr %6959, i64 %6965
  %private.contiguous.preserve1528 = load <8 x float>, ptr %private.contiguous.address1527, align 4
  %6966 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6849, <8 x float> %private.contiguous.preserve1528
  store <8 x float> %6966, ptr %private.contiguous.address1527, align 4
  %6967 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6968 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %6969 = add <8 x i64> %6968, splat (i64 192)
  %6970 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6967, 0
  %6971 = insertvalue { <8 x ptr>, <8 x i64> } %6970, <8 x i64> %6969, 1
  %6972 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6973 = extractvalue { <8 x ptr>, <8 x i64> } %6971, 1
  %6974 = extractelement <8 x ptr> %6972, i32 0
  %6975 = extractelement <8 x i64> %6973, i32 %6813
  %6976 = zext i32 %6813 to i64
  %6977 = mul i64 %6976, 4
  %6978 = sub i64 %6975, %6977
  %6979 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %6980 = select i1 %6979, i64 %6978, i64 0
  %private.contiguous.address1529 = getelementptr i8, ptr %6974, i64 %6980
  %private.contiguous.preserve1530 = load <8 x float>, ptr %private.contiguous.address1529, align 4
  %6981 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6850, <8 x float> %private.contiguous.preserve1530
  store <8 x float> %6981, ptr %private.contiguous.address1529, align 4
  %6982 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6983 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %6984 = add <8 x i64> %6983, splat (i64 224)
  %6985 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6982, 0
  %6986 = insertvalue { <8 x ptr>, <8 x i64> } %6985, <8 x i64> %6984, 1
  %6987 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6988 = extractvalue { <8 x ptr>, <8 x i64> } %6986, 1
  %6989 = extractelement <8 x ptr> %6987, i32 0
  %6990 = extractelement <8 x i64> %6988, i32 %6813
  %6991 = zext i32 %6813 to i64
  %6992 = mul i64 %6991, 4
  %6993 = sub i64 %6990, %6992
  %6994 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %6995 = select i1 %6994, i64 %6993, i64 0
  %private.contiguous.address1531 = getelementptr i8, ptr %6989, i64 %6995
  %private.contiguous.preserve1532 = load <8 x float>, ptr %private.contiguous.address1531, align 4
  %6996 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6851, <8 x float> %private.contiguous.preserve1532
  store <8 x float> %6996, ptr %private.contiguous.address1531, align 4
  %6997 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6998 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %6999 = add <8 x i64> %6998, splat (i64 256)
  %7000 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6997, 0
  %7001 = insertvalue { <8 x ptr>, <8 x i64> } %7000, <8 x i64> %6999, 1
  %7002 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7003 = extractvalue { <8 x ptr>, <8 x i64> } %7001, 1
  %7004 = extractelement <8 x ptr> %7002, i32 0
  %7005 = extractelement <8 x i64> %7003, i32 %6813
  %7006 = zext i32 %6813 to i64
  %7007 = mul i64 %7006, 4
  %7008 = sub i64 %7005, %7007
  %7009 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7010 = select i1 %7009, i64 %7008, i64 0
  %private.contiguous.address1533 = getelementptr i8, ptr %7004, i64 %7010
  %private.contiguous.preserve1534 = load <8 x float>, ptr %private.contiguous.address1533, align 4
  %7011 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6852, <8 x float> %private.contiguous.preserve1534
  store <8 x float> %7011, ptr %private.contiguous.address1533, align 4
  %7012 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7013 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %7014 = add <8 x i64> %7013, splat (i64 288)
  %7015 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7012, 0
  %7016 = insertvalue { <8 x ptr>, <8 x i64> } %7015, <8 x i64> %7014, 1
  %7017 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7018 = extractvalue { <8 x ptr>, <8 x i64> } %7016, 1
  %7019 = extractelement <8 x ptr> %7017, i32 0
  %7020 = extractelement <8 x i64> %7018, i32 %6813
  %7021 = zext i32 %6813 to i64
  %7022 = mul i64 %7021, 4
  %7023 = sub i64 %7020, %7022
  %7024 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7025 = select i1 %7024, i64 %7023, i64 0
  %private.contiguous.address1535 = getelementptr i8, ptr %7019, i64 %7025
  %private.contiguous.preserve1536 = load <8 x float>, ptr %private.contiguous.address1535, align 4
  %7026 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6853, <8 x float> %private.contiguous.preserve1536
  store <8 x float> %7026, ptr %private.contiguous.address1535, align 4
  %7027 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7028 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %7029 = add <8 x i64> %7028, splat (i64 320)
  %7030 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7027, 0
  %7031 = insertvalue { <8 x ptr>, <8 x i64> } %7030, <8 x i64> %7029, 1
  %7032 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7033 = extractvalue { <8 x ptr>, <8 x i64> } %7031, 1
  %7034 = extractelement <8 x ptr> %7032, i32 0
  %7035 = extractelement <8 x i64> %7033, i32 %6813
  %7036 = zext i32 %6813 to i64
  %7037 = mul i64 %7036, 4
  %7038 = sub i64 %7035, %7037
  %7039 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7040 = select i1 %7039, i64 %7038, i64 0
  %private.contiguous.address1537 = getelementptr i8, ptr %7034, i64 %7040
  %private.contiguous.preserve1538 = load <8 x float>, ptr %private.contiguous.address1537, align 4
  %7041 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6854, <8 x float> %private.contiguous.preserve1538
  store <8 x float> %7041, ptr %private.contiguous.address1537, align 4
  %7042 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7043 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %7044 = add <8 x i64> %7043, splat (i64 352)
  %7045 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7042, 0
  %7046 = insertvalue { <8 x ptr>, <8 x i64> } %7045, <8 x i64> %7044, 1
  %7047 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7048 = extractvalue { <8 x ptr>, <8 x i64> } %7046, 1
  %7049 = extractelement <8 x ptr> %7047, i32 0
  %7050 = extractelement <8 x i64> %7048, i32 %6813
  %7051 = zext i32 %6813 to i64
  %7052 = mul i64 %7051, 4
  %7053 = sub i64 %7050, %7052
  %7054 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7055 = select i1 %7054, i64 %7053, i64 0
  %private.contiguous.address1539 = getelementptr i8, ptr %7049, i64 %7055
  %private.contiguous.preserve1540 = load <8 x float>, ptr %private.contiguous.address1539, align 4
  %7056 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6855, <8 x float> %private.contiguous.preserve1540
  store <8 x float> %7056, ptr %private.contiguous.address1539, align 4
  %7057 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7058 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %7059 = add <8 x i64> %7058, splat (i64 384)
  %7060 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7057, 0
  %7061 = insertvalue { <8 x ptr>, <8 x i64> } %7060, <8 x i64> %7059, 1
  %7062 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7063 = extractvalue { <8 x ptr>, <8 x i64> } %7061, 1
  %7064 = extractelement <8 x ptr> %7062, i32 0
  %7065 = extractelement <8 x i64> %7063, i32 %6813
  %7066 = zext i32 %6813 to i64
  %7067 = mul i64 %7066, 4
  %7068 = sub i64 %7065, %7067
  %7069 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7070 = select i1 %7069, i64 %7068, i64 0
  %private.contiguous.address1541 = getelementptr i8, ptr %7064, i64 %7070
  %private.contiguous.preserve1542 = load <8 x float>, ptr %private.contiguous.address1541, align 4
  %7071 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6856, <8 x float> %private.contiguous.preserve1542
  store <8 x float> %7071, ptr %private.contiguous.address1541, align 4
  %7072 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7073 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %7074 = add <8 x i64> %7073, splat (i64 416)
  %7075 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7072, 0
  %7076 = insertvalue { <8 x ptr>, <8 x i64> } %7075, <8 x i64> %7074, 1
  %7077 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7078 = extractvalue { <8 x ptr>, <8 x i64> } %7076, 1
  %7079 = extractelement <8 x ptr> %7077, i32 0
  %7080 = extractelement <8 x i64> %7078, i32 %6813
  %7081 = zext i32 %6813 to i64
  %7082 = mul i64 %7081, 4
  %7083 = sub i64 %7080, %7082
  %7084 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7085 = select i1 %7084, i64 %7083, i64 0
  %private.contiguous.address1543 = getelementptr i8, ptr %7079, i64 %7085
  %private.contiguous.preserve1544 = load <8 x float>, ptr %private.contiguous.address1543, align 4
  %7086 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6857, <8 x float> %private.contiguous.preserve1544
  store <8 x float> %7086, ptr %private.contiguous.address1543, align 4
  %7087 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7088 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %7089 = add <8 x i64> %7088, splat (i64 448)
  %7090 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7087, 0
  %7091 = insertvalue { <8 x ptr>, <8 x i64> } %7090, <8 x i64> %7089, 1
  %7092 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7093 = extractvalue { <8 x ptr>, <8 x i64> } %7091, 1
  %7094 = extractelement <8 x ptr> %7092, i32 0
  %7095 = extractelement <8 x i64> %7093, i32 %6813
  %7096 = zext i32 %6813 to i64
  %7097 = mul i64 %7096, 4
  %7098 = sub i64 %7095, %7097
  %7099 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7100 = select i1 %7099, i64 %7098, i64 0
  %private.contiguous.address1545 = getelementptr i8, ptr %7094, i64 %7100
  %private.contiguous.preserve1546 = load <8 x float>, ptr %private.contiguous.address1545, align 4
  %7101 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6858, <8 x float> %private.contiguous.preserve1546
  store <8 x float> %7101, ptr %private.contiguous.address1545, align 4
  %7102 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7103 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %7104 = add <8 x i64> %7103, splat (i64 480)
  %7105 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7102, 0
  %7106 = insertvalue { <8 x ptr>, <8 x i64> } %7105, <8 x i64> %7104, 1
  %7107 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7108 = extractvalue { <8 x ptr>, <8 x i64> } %7106, 1
  %7109 = extractelement <8 x ptr> %7107, i32 0
  %7110 = extractelement <8 x i64> %7108, i32 %6813
  %7111 = zext i32 %6813 to i64
  %7112 = mul i64 %7111, 4
  %7113 = sub i64 %7110, %7112
  %7114 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7115 = select i1 %7114, i64 %7113, i64 0
  %private.contiguous.address1547 = getelementptr i8, ptr %7109, i64 %7115
  %private.contiguous.preserve1548 = load <8 x float>, ptr %private.contiguous.address1547, align 4
  %7116 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6859, <8 x float> %private.contiguous.preserve1548
  store <8 x float> %7116, ptr %private.contiguous.address1547, align 4
  %7117 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7118 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %7119 = add <8 x i64> %7118, splat (i64 512)
  %7120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7117, 0
  %7121 = insertvalue { <8 x ptr>, <8 x i64> } %7120, <8 x i64> %7119, 1
  %7122 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7123 = extractvalue { <8 x ptr>, <8 x i64> } %7121, 1
  %7124 = extractelement <8 x ptr> %7122, i32 0
  %7125 = extractelement <8 x i64> %7123, i32 %6813
  %7126 = zext i32 %6813 to i64
  %7127 = mul i64 %7126, 4
  %7128 = sub i64 %7125, %7127
  %7129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7130 = select i1 %7129, i64 %7128, i64 0
  %private.contiguous.address1549 = getelementptr i8, ptr %7124, i64 %7130
  %private.contiguous.preserve1550 = load <8 x float>, ptr %private.contiguous.address1549, align 4
  %7131 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6860, <8 x float> %private.contiguous.preserve1550
  store <8 x float> %7131, ptr %private.contiguous.address1549, align 4
  %7132 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7133 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %7134 = add <8 x i64> %7133, splat (i64 544)
  %7135 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7132, 0
  %7136 = insertvalue { <8 x ptr>, <8 x i64> } %7135, <8 x i64> %7134, 1
  %7137 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7138 = extractvalue { <8 x ptr>, <8 x i64> } %7136, 1
  %7139 = extractelement <8 x ptr> %7137, i32 0
  %7140 = extractelement <8 x i64> %7138, i32 %6813
  %7141 = zext i32 %6813 to i64
  %7142 = mul i64 %7141, 4
  %7143 = sub i64 %7140, %7142
  %7144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7145 = select i1 %7144, i64 %7143, i64 0
  %private.contiguous.address1551 = getelementptr i8, ptr %7139, i64 %7145
  %private.contiguous.preserve1552 = load <8 x float>, ptr %private.contiguous.address1551, align 4
  %7146 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6861, <8 x float> %private.contiguous.preserve1552
  store <8 x float> %7146, ptr %private.contiguous.address1551, align 4
  %7147 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7148 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %7149 = add <8 x i64> %7148, splat (i64 576)
  %7150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7147, 0
  %7151 = insertvalue { <8 x ptr>, <8 x i64> } %7150, <8 x i64> %7149, 1
  %7152 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7153 = extractvalue { <8 x ptr>, <8 x i64> } %7151, 1
  %7154 = extractelement <8 x ptr> %7152, i32 0
  %7155 = extractelement <8 x i64> %7153, i32 %6813
  %7156 = zext i32 %6813 to i64
  %7157 = mul i64 %7156, 4
  %7158 = sub i64 %7155, %7157
  %7159 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7160 = select i1 %7159, i64 %7158, i64 0
  %private.contiguous.address1553 = getelementptr i8, ptr %7154, i64 %7160
  %private.contiguous.preserve1554 = load <8 x float>, ptr %private.contiguous.address1553, align 4
  %7161 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6862, <8 x float> %private.contiguous.preserve1554
  store <8 x float> %7161, ptr %private.contiguous.address1553, align 4
  %7162 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7163 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %7164 = add <8 x i64> %7163, splat (i64 608)
  %7165 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7162, 0
  %7166 = insertvalue { <8 x ptr>, <8 x i64> } %7165, <8 x i64> %7164, 1
  %7167 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7168 = extractvalue { <8 x ptr>, <8 x i64> } %7166, 1
  %7169 = extractelement <8 x ptr> %7167, i32 0
  %7170 = extractelement <8 x i64> %7168, i32 %6813
  %7171 = zext i32 %6813 to i64
  %7172 = mul i64 %7171, 4
  %7173 = sub i64 %7170, %7172
  %7174 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7175 = select i1 %7174, i64 %7173, i64 0
  %private.contiguous.address1555 = getelementptr i8, ptr %7169, i64 %7175
  %private.contiguous.preserve1556 = load <8 x float>, ptr %private.contiguous.address1555, align 4
  %7176 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6863, <8 x float> %private.contiguous.preserve1556
  store <8 x float> %7176, ptr %private.contiguous.address1555, align 4
  %7177 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7178 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %7179 = add <8 x i64> %7178, splat (i64 640)
  %7180 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7177, 0
  %7181 = insertvalue { <8 x ptr>, <8 x i64> } %7180, <8 x i64> %7179, 1
  %7182 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7183 = extractvalue { <8 x ptr>, <8 x i64> } %7181, 1
  %7184 = extractelement <8 x ptr> %7182, i32 0
  %7185 = extractelement <8 x i64> %7183, i32 %6813
  %7186 = zext i32 %6813 to i64
  %7187 = mul i64 %7186, 4
  %7188 = sub i64 %7185, %7187
  %7189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7190 = select i1 %7189, i64 %7188, i64 0
  %private.contiguous.address1557 = getelementptr i8, ptr %7184, i64 %7190
  %private.contiguous.preserve1558 = load <8 x float>, ptr %private.contiguous.address1557, align 4
  %7191 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6864, <8 x float> %private.contiguous.preserve1558
  store <8 x float> %7191, ptr %private.contiguous.address1557, align 4
  %7192 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7193 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %7194 = add <8 x i64> %7193, splat (i64 672)
  %7195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7192, 0
  %7196 = insertvalue { <8 x ptr>, <8 x i64> } %7195, <8 x i64> %7194, 1
  %7197 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7198 = extractvalue { <8 x ptr>, <8 x i64> } %7196, 1
  %7199 = extractelement <8 x ptr> %7197, i32 0
  %7200 = extractelement <8 x i64> %7198, i32 %6813
  %7201 = zext i32 %6813 to i64
  %7202 = mul i64 %7201, 4
  %7203 = sub i64 %7200, %7202
  %7204 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7205 = select i1 %7204, i64 %7203, i64 0
  %private.contiguous.address1559 = getelementptr i8, ptr %7199, i64 %7205
  %private.contiguous.preserve1560 = load <8 x float>, ptr %private.contiguous.address1559, align 4
  %7206 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6865, <8 x float> %private.contiguous.preserve1560
  store <8 x float> %7206, ptr %private.contiguous.address1559, align 4
  %7207 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7208 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %7209 = add <8 x i64> %7208, splat (i64 704)
  %7210 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7207, 0
  %7211 = insertvalue { <8 x ptr>, <8 x i64> } %7210, <8 x i64> %7209, 1
  %7212 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7213 = extractvalue { <8 x ptr>, <8 x i64> } %7211, 1
  %7214 = extractelement <8 x ptr> %7212, i32 0
  %7215 = extractelement <8 x i64> %7213, i32 %6813
  %7216 = zext i32 %6813 to i64
  %7217 = mul i64 %7216, 4
  %7218 = sub i64 %7215, %7217
  %7219 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7220 = select i1 %7219, i64 %7218, i64 0
  %private.contiguous.address1561 = getelementptr i8, ptr %7214, i64 %7220
  %private.contiguous.preserve1562 = load <8 x float>, ptr %private.contiguous.address1561, align 4
  %7221 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6866, <8 x float> %private.contiguous.preserve1562
  store <8 x float> %7221, ptr %private.contiguous.address1561, align 4
  %7222 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7223 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %7224 = add <8 x i64> %7223, splat (i64 736)
  %7225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7222, 0
  %7226 = insertvalue { <8 x ptr>, <8 x i64> } %7225, <8 x i64> %7224, 1
  %7227 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %7228 = extractvalue { <8 x ptr>, <8 x i64> } %7226, 1
  %7229 = extractelement <8 x ptr> %7227, i32 0
  %7230 = extractelement <8 x i64> %7228, i32 %6813
  %7231 = zext i32 %6813 to i64
  %7232 = mul i64 %7231, 4
  %7233 = sub i64 %7230, %7232
  %7234 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  %7235 = select i1 %7234, i64 %7233, i64 0
  %private.contiguous.address1563 = getelementptr i8, ptr %7229, i64 %7235
  %private.contiguous.preserve1564 = load <8 x float>, ptr %private.contiguous.address1563, align 4
  %7236 = select <8 x i1> %convergence.cascade.result1448, <8 x float> %6867, <8 x float> %private.contiguous.preserve1564
  store <8 x float> %7236, ptr %private.contiguous.address1563, align 4
  %7237 = load <8 x i64>, ptr %.slot168, align 64
  %7238 = select <8 x i1> %convergence.cascade.result1448, <8 x i64> zeroinitializer, <8 x i64> %7237
  store <8 x i64> %7238, ptr %.slot168, align 64
  %7239 = load <8 x float>, ptr %.slot169, align 32
  %7240 = select <8 x i1> %convergence.cascade.result1448, <8 x float> zeroinitializer, <8 x float> %7239
  store <8 x float> %7240, ptr %.slot169, align 32
  store <8 x i1> %convergence.cascade.result1448, ptr %current.mask, align 1
  %7241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1448)
  br i1 %7241, label %schedule.79, label %scheduler.loop

varying.divergent1566:                            ; preds = %schedule.79
  %7242 = load i32, ptr %current.token, align 4
  %7243 = icmp ne i32 %7242, 0
  %7244 = sub i32 %7242, 1
  %7245 = select i1 %7243, i32 %7244, i32 0
  %7246 = load i8, ptr %frame.active, align 1
  %7247 = trunc i32 %7245 to i8
  %7248 = shl i8 1, %7247
  %7249 = and i8 %7246, %7248
  %7250 = icmp ne i8 %7249, 0
  %7251 = load <8 x i32>, ptr %frame.static.id, align 32
  %7252 = extractelement <8 x i32> %7251, i32 %7245
  %7253 = icmp eq i32 %7252, 34
  %7254 = and i1 %7250, %7253
  %7255 = and i1 %7243, %7254
  %7256 = xor i1 %7255, true
  %7257 = and i1 true, %7256
  %7258 = xor i8 %7246, -1
  %7259 = icmp ne i8 %7258, 0
  %7260 = xor i1 %7259, true
  %7261 = and i1 %7257, %7260
  br i1 %7261, label %convergence.overflow.trap1568, label %convergence.overflow.resume1569

varying.coherent1567:                             ; preds = %schedule.79
  br i1 %1094, label %varying.coherent.true1572, label %varying.coherent.false1573

convergence.overflow.trap1568:                    ; preds = %varying.divergent1566
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1569:                  ; preds = %varying.divergent1566
  %7262 = call i8 @llvm.cttz.i8(i8 %7258, i1 false)
  %7263 = zext i8 %7262 to i32
  %7264 = select i1 %7259, i32 %7263, i32 0
  %7265 = trunc i32 %7264 to i8
  %7266 = shl i8 1, %7265
  %7267 = or i8 %7246, %7266
  %7268 = select i1 %7257, i8 %7267, i8 %7246
  store i8 %7268, ptr %frame.active, align 1
  %7269 = load <8 x i32>, ptr %frame.static.id, align 32
  %7270 = extractelement <8 x i32> %7269, i32 %7264
  %7271 = select i1 %7257, i32 34, i32 %7270
  %7272 = load <8 x i32>, ptr %frame.static.id, align 32
  %7273 = insertelement <8 x i32> %7272, i32 %7271, i32 %7264
  store <8 x i32> %7273, ptr %frame.static.id, align 32
  %7274 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7275 = extractelement <8 x i32> %7274, i32 %7264
  %7276 = select i1 %7257, i32 %7242, i32 %7275
  %7277 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7278 = insertelement <8 x i32> %7277, i32 %7276, i32 %7264
  store <8 x i32> %7278, ptr %frame.parent.token, align 32
  %7279 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7264
  %7280 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7264
  %7281 = load <8 x i1>, ptr %7279, align 1
  %7282 = load <8 x i1>, ptr %7280, align 1
  %7283 = select i1 %7257, <8 x i1> %1084, <8 x i1> %7281
  store <8 x i1> %7283, ptr %7279, align 1
  %7284 = select i1 %7257, <8 x i1> zeroinitializer, <8 x i1> %7282
  store <8 x i1> %7284, ptr %7280, align 1
  %7285 = add i32 %7264, 1
  %7286 = select i1 %7255, i32 %7242, i32 %7285
  %7287 = select i1 true, i32 %7286, i32 %7242
  store i32 %7287, ptr %current.token, align 4
  %7288 = load i32, ptr %current.token, align 4
  %7289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1091)
  %7290 = load i32, ptr %ready.count, align 4
  %7291 = icmp uge i32 %7290, 8
  %7292 = and i1 %7289, %7291
  br i1 %7292, label %ready.overflow.trap1570, label %ready.overflow.resume1571

ready.overflow.trap1570:                          ; preds = %convergence.overflow.resume1569
  call void @llvm.trap()
  unreachable

ready.overflow.resume1571:                        ; preds = %convergence.overflow.resume1569
  %7293 = select i1 %7289, i32 %7290, i32 0
  %7294 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7293
  %7295 = load <8 x i1>, ptr %7294, align 1
  %7296 = select i1 %7289, <8 x i1> %1091, <8 x i1> %7295
  store <8 x i1> %7296, ptr %7294, align 1
  %7297 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7293
  %7298 = load i32, ptr %7297, align 4
  %7299 = select i1 %7289, i32 80, i32 %7298
  store i32 %7299, ptr %7297, align 4
  %7300 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7293
  %7301 = load i32, ptr %7300, align 4
  %7302 = select i1 %7289, i32 %7288, i32 %7301
  store i32 %7302, ptr %7300, align 4
  %7303 = add i32 %7290, 1
  %7304 = select i1 %7289, i32 %7303, i32 %7290
  store i32 %7304, ptr %ready.count, align 4
  %7305 = load <8 x i1>, ptr %runnable.mask, align 1
  %7306 = or <8 x i1> %7305, %1091
  store <8 x i1> %7306, ptr %runnable.mask, align 1
  store <8 x i1> %1093, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1572:                        ; preds = %varying.coherent1567
  store <8 x i1> %1084, ptr %current.mask, align 1
  %7307 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1084)
  br i1 %7307, label %schedule.80, label %scheduler.loop

varying.coherent.false1573:                       ; preds = %varying.coherent1567
  store <8 x i1> %1084, ptr %current.mask, align 1
  %7308 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1084)
  br i1 %7308, label %schedule.81, label %scheduler.loop

convergence.cascade1581:                          ; preds = %convergence.cascade1581, %schedule.81
  %convergence.cascade.flow1585 = phi <8 x i1> [ %1132, %schedule.81 ], [ %7351, %convergence.cascade1581 ]
  %convergence.cascade.depth1586 = phi i32 [ 0, %schedule.81 ], [ %7352, %convergence.cascade1581 ]
  %7309 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1585)
  %7310 = load i32, ptr %current.token, align 4
  %7311 = icmp ne i32 %7310, 0
  %7312 = and i1 %7309, %7311
  %7313 = sub i32 %7310, 1
  %7314 = select i1 %7312, i32 %7313, i32 0
  %7315 = load i8, ptr %frame.active, align 1
  %7316 = trunc i32 %7314 to i8
  %7317 = shl i8 1, %7316
  %7318 = and i8 %7315, %7317
  %7319 = icmp ne i8 %7318, 0
  %7320 = load <8 x i32>, ptr %frame.static.id, align 32
  %7321 = extractelement <8 x i32> %7320, i32 %7314
  %convergence.target.pointer1587 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %7321
  %convergence.dynamic.target1588 = load i32, ptr %convergence.target.pointer1587, align 4
  %7322 = icmp eq i32 %convergence.dynamic.target1588, 81
  %7323 = and i1 %7319, %7322
  %7324 = and i1 %7312, %7323
  %7325 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7314
  %7326 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7314
  %7327 = load <8 x i1>, ptr %7325, align 1
  %7328 = load <8 x i1>, ptr %7326, align 1
  %7329 = or <8 x i1> %7328, %convergence.cascade.flow1585
  %7330 = load <8 x i1>, ptr %live.mask, align 1
  %7331 = and <8 x i1> %7327, %7330
  %7332 = icmp eq <8 x i1> %7329, %7331
  %7333 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7332)
  %7334 = and i1 %7324, %7333
  %7335 = select i1 %7334, <8 x i1> zeroinitializer, <8 x i1> %7329
  %7336 = select i1 %7324, <8 x i1> %7335, <8 x i1> %7328
  store <8 x i1> %7336, ptr %7326, align 1
  %7337 = select i1 %7334, <8 x i1> zeroinitializer, <8 x i1> %7327
  store <8 x i1> %7337, ptr %7325, align 1
  %7338 = trunc i32 %7314 to i8
  %7339 = shl i8 1, %7338
  %7340 = xor i8 %7339, -1
  %7341 = and i8 %7315, %7340
  %7342 = select i1 %7334, i8 %7341, i8 %7315
  store i8 %7342, ptr %frame.active, align 1
  %.splatinsert1589 = insertelement <8 x i1> poison, i1 %7324, i64 0
  %.splat1590 = shufflevector <8 x i1> %.splatinsert1589, <8 x i1> poison, <8 x i32> zeroinitializer
  %7343 = and <8 x i1> %convergence.cascade.flow1585, %.splat1590
  %7344 = load <8 x i1>, ptr %runnable.mask, align 1
  %7345 = xor <8 x i1> %7343, splat (i1 true)
  %7346 = and <8 x i1> %7344, %7345
  store <8 x i1> %7346, ptr %runnable.mask, align 1
  %.splatinsert1591 = insertelement <8 x i1> poison, i1 %7334, i64 0
  %.splat1592 = shufflevector <8 x i1> %.splatinsert1591, <8 x i1> poison, <8 x i32> zeroinitializer
  %7347 = select <8 x i1> %.splat1592, <8 x i1> %7329, <8 x i1> zeroinitializer
  %7348 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7349 = extractelement <8 x i32> %7348, i32 %7314
  %7350 = select i1 %7334, i32 %7349, i32 %7310
  store i32 %7350, ptr %current.token, align 4
  %.splatinsert1593 = insertelement <8 x i1> poison, i1 %7324, i64 0
  %.splat1594 = shufflevector <8 x i1> %.splatinsert1593, <8 x i1> poison, <8 x i32> zeroinitializer
  %7351 = select <8 x i1> %.splat1594, <8 x i1> %7347, <8 x i1> %convergence.cascade.flow1585
  %7352 = add i32 %convergence.cascade.depth1586, 1
  %7353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7351)
  %7354 = icmp ult i32 %7352, 8
  %7355 = and i1 %7353, %7354
  %7356 = and i1 %7324, %7355
  %convergence.parent.token1595 = load i32, ptr %current.token, align 4
  %convergence.parent.present1596 = icmp ne i32 %convergence.parent.token1595, 0
  %7357 = and i1 %7356, %convergence.parent.present1596
  br i1 %7357, label %convergence.cascade1581, label %convergence.cascade.exit1582

convergence.cascade.exit1582:                     ; preds = %convergence.cascade1581, %schedule.81
  %convergence.cascade.result1597 = phi <8 x i1> [ %1132, %schedule.81 ], [ %7351, %convergence.cascade1581 ]
  %7358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1597)
  br i1 %7358, label %convergence.target.81.ready, label %scheduler.loop

convergence.target.81.ready:                      ; preds = %convergence.cascade.exit1582
  %7359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1597)
  %7360 = bitcast <8 x i1> %convergence.cascade.result1597 to i8
  %7361 = call i8 @llvm.cttz.i8(i8 %7360, i1 false)
  %7362 = zext i8 %7361 to i32
  %7363 = select i1 %7359, i32 %7362, i32 0
  %7364 = load <8 x i64>, ptr %.slot170, align 64
  %7365 = select <8 x i1> %convergence.cascade.result1597, <8 x i64> zeroinitializer, <8 x i64> %7364
  store <8 x i64> %7365, ptr %.slot170, align 64
  %7366 = load <8 x float>, ptr %.slot171, align 32
  %7367 = select <8 x i1> %convergence.cascade.result1597, <8 x float> zeroinitializer, <8 x float> %7366
  store <8 x float> %7367, ptr %.slot171, align 32
  store <8 x i1> %convergence.cascade.result1597, ptr %current.mask, align 1
  %7368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1597)
  br i1 %7368, label %schedule.82, label %scheduler.loop

varying.divergent1599:                            ; preds = %schedule.82
  %7369 = load i32, ptr %current.token, align 4
  %7370 = icmp ne i32 %7369, 0
  %7371 = sub i32 %7369, 1
  %7372 = select i1 %7370, i32 %7371, i32 0
  %7373 = load i8, ptr %frame.active, align 1
  %7374 = trunc i32 %7372 to i8
  %7375 = shl i8 1, %7374
  %7376 = and i8 %7373, %7375
  %7377 = icmp ne i8 %7376, 0
  %7378 = load <8 x i32>, ptr %frame.static.id, align 32
  %7379 = extractelement <8 x i32> %7378, i32 %7372
  %7380 = icmp eq i32 %7379, 35
  %7381 = and i1 %7377, %7380
  %7382 = and i1 %7370, %7381
  %7383 = xor i1 %7382, true
  %7384 = and i1 true, %7383
  %7385 = xor i8 %7373, -1
  %7386 = icmp ne i8 %7385, 0
  %7387 = xor i1 %7386, true
  %7388 = and i1 %7384, %7387
  br i1 %7388, label %convergence.overflow.trap1601, label %convergence.overflow.resume1602

varying.coherent1600:                             ; preds = %schedule.82
  br i1 %1143, label %varying.coherent.true1605, label %varying.coherent.false1606

convergence.overflow.trap1601:                    ; preds = %varying.divergent1599
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1602:                  ; preds = %varying.divergent1599
  %7389 = call i8 @llvm.cttz.i8(i8 %7385, i1 false)
  %7390 = zext i8 %7389 to i32
  %7391 = select i1 %7386, i32 %7390, i32 0
  %7392 = trunc i32 %7391 to i8
  %7393 = shl i8 1, %7392
  %7394 = or i8 %7373, %7393
  %7395 = select i1 %7384, i8 %7394, i8 %7373
  store i8 %7395, ptr %frame.active, align 1
  %7396 = load <8 x i32>, ptr %frame.static.id, align 32
  %7397 = extractelement <8 x i32> %7396, i32 %7391
  %7398 = select i1 %7384, i32 35, i32 %7397
  %7399 = load <8 x i32>, ptr %frame.static.id, align 32
  %7400 = insertelement <8 x i32> %7399, i32 %7398, i32 %7391
  store <8 x i32> %7400, ptr %frame.static.id, align 32
  %7401 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7402 = extractelement <8 x i32> %7401, i32 %7391
  %7403 = select i1 %7384, i32 %7369, i32 %7402
  %7404 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7405 = insertelement <8 x i32> %7404, i32 %7403, i32 %7391
  store <8 x i32> %7405, ptr %frame.parent.token, align 32
  %7406 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7391
  %7407 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7391
  %7408 = load <8 x i1>, ptr %7406, align 1
  %7409 = load <8 x i1>, ptr %7407, align 1
  %7410 = select i1 %7384, <8 x i1> %1133, <8 x i1> %7408
  store <8 x i1> %7410, ptr %7406, align 1
  %7411 = select i1 %7384, <8 x i1> zeroinitializer, <8 x i1> %7409
  store <8 x i1> %7411, ptr %7407, align 1
  %7412 = add i32 %7391, 1
  %7413 = select i1 %7382, i32 %7369, i32 %7412
  %7414 = select i1 true, i32 %7413, i32 %7369
  store i32 %7414, ptr %current.token, align 4
  %7415 = load i32, ptr %current.token, align 4
  %7416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1140)
  %7417 = load i32, ptr %ready.count, align 4
  %7418 = icmp uge i32 %7417, 8
  %7419 = and i1 %7416, %7418
  br i1 %7419, label %ready.overflow.trap1603, label %ready.overflow.resume1604

ready.overflow.trap1603:                          ; preds = %convergence.overflow.resume1602
  call void @llvm.trap()
  unreachable

ready.overflow.resume1604:                        ; preds = %convergence.overflow.resume1602
  %7420 = select i1 %7416, i32 %7417, i32 0
  %7421 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7420
  %7422 = load <8 x i1>, ptr %7421, align 1
  %7423 = select i1 %7416, <8 x i1> %1140, <8 x i1> %7422
  store <8 x i1> %7423, ptr %7421, align 1
  %7424 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7420
  %7425 = load i32, ptr %7424, align 4
  %7426 = select i1 %7416, i32 83, i32 %7425
  store i32 %7426, ptr %7424, align 4
  %7427 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7420
  %7428 = load i32, ptr %7427, align 4
  %7429 = select i1 %7416, i32 %7415, i32 %7428
  store i32 %7429, ptr %7427, align 4
  %7430 = add i32 %7417, 1
  %7431 = select i1 %7416, i32 %7430, i32 %7417
  store i32 %7431, ptr %ready.count, align 4
  %7432 = load <8 x i1>, ptr %runnable.mask, align 1
  %7433 = or <8 x i1> %7432, %1140
  store <8 x i1> %7433, ptr %runnable.mask, align 1
  store <8 x i1> %1142, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1605:                        ; preds = %varying.coherent1600
  store <8 x i1> %1133, ptr %current.mask, align 1
  %7434 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1133)
  br i1 %7434, label %schedule.83, label %scheduler.loop

varying.coherent.false1606:                       ; preds = %varying.coherent1600
  store <8 x i1> %1133, ptr %current.mask, align 1
  %7435 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1133)
  br i1 %7435, label %schedule.84, label %scheduler.loop

convergence.cascade1614:                          ; preds = %convergence.cascade1614, %schedule.84
  %convergence.cascade.flow1618 = phi <8 x i1> [ %1181, %schedule.84 ], [ %7478, %convergence.cascade1614 ]
  %convergence.cascade.depth1619 = phi i32 [ 0, %schedule.84 ], [ %7479, %convergence.cascade1614 ]
  %7436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1618)
  %7437 = load i32, ptr %current.token, align 4
  %7438 = icmp ne i32 %7437, 0
  %7439 = and i1 %7436, %7438
  %7440 = sub i32 %7437, 1
  %7441 = select i1 %7439, i32 %7440, i32 0
  %7442 = load i8, ptr %frame.active, align 1
  %7443 = trunc i32 %7441 to i8
  %7444 = shl i8 1, %7443
  %7445 = and i8 %7442, %7444
  %7446 = icmp ne i8 %7445, 0
  %7447 = load <8 x i32>, ptr %frame.static.id, align 32
  %7448 = extractelement <8 x i32> %7447, i32 %7441
  %convergence.target.pointer1620 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %7448
  %convergence.dynamic.target1621 = load i32, ptr %convergence.target.pointer1620, align 4
  %7449 = icmp eq i32 %convergence.dynamic.target1621, 84
  %7450 = and i1 %7446, %7449
  %7451 = and i1 %7439, %7450
  %7452 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7441
  %7453 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7441
  %7454 = load <8 x i1>, ptr %7452, align 1
  %7455 = load <8 x i1>, ptr %7453, align 1
  %7456 = or <8 x i1> %7455, %convergence.cascade.flow1618
  %7457 = load <8 x i1>, ptr %live.mask, align 1
  %7458 = and <8 x i1> %7454, %7457
  %7459 = icmp eq <8 x i1> %7456, %7458
  %7460 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7459)
  %7461 = and i1 %7451, %7460
  %7462 = select i1 %7461, <8 x i1> zeroinitializer, <8 x i1> %7456
  %7463 = select i1 %7451, <8 x i1> %7462, <8 x i1> %7455
  store <8 x i1> %7463, ptr %7453, align 1
  %7464 = select i1 %7461, <8 x i1> zeroinitializer, <8 x i1> %7454
  store <8 x i1> %7464, ptr %7452, align 1
  %7465 = trunc i32 %7441 to i8
  %7466 = shl i8 1, %7465
  %7467 = xor i8 %7466, -1
  %7468 = and i8 %7442, %7467
  %7469 = select i1 %7461, i8 %7468, i8 %7442
  store i8 %7469, ptr %frame.active, align 1
  %.splatinsert1622 = insertelement <8 x i1> poison, i1 %7451, i64 0
  %.splat1623 = shufflevector <8 x i1> %.splatinsert1622, <8 x i1> poison, <8 x i32> zeroinitializer
  %7470 = and <8 x i1> %convergence.cascade.flow1618, %.splat1623
  %7471 = load <8 x i1>, ptr %runnable.mask, align 1
  %7472 = xor <8 x i1> %7470, splat (i1 true)
  %7473 = and <8 x i1> %7471, %7472
  store <8 x i1> %7473, ptr %runnable.mask, align 1
  %.splatinsert1624 = insertelement <8 x i1> poison, i1 %7461, i64 0
  %.splat1625 = shufflevector <8 x i1> %.splatinsert1624, <8 x i1> poison, <8 x i32> zeroinitializer
  %7474 = select <8 x i1> %.splat1625, <8 x i1> %7456, <8 x i1> zeroinitializer
  %7475 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7476 = extractelement <8 x i32> %7475, i32 %7441
  %7477 = select i1 %7461, i32 %7476, i32 %7437
  store i32 %7477, ptr %current.token, align 4
  %.splatinsert1626 = insertelement <8 x i1> poison, i1 %7451, i64 0
  %.splat1627 = shufflevector <8 x i1> %.splatinsert1626, <8 x i1> poison, <8 x i32> zeroinitializer
  %7478 = select <8 x i1> %.splat1627, <8 x i1> %7474, <8 x i1> %convergence.cascade.flow1618
  %7479 = add i32 %convergence.cascade.depth1619, 1
  %7480 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7478)
  %7481 = icmp ult i32 %7479, 8
  %7482 = and i1 %7480, %7481
  %7483 = and i1 %7451, %7482
  %convergence.parent.token1628 = load i32, ptr %current.token, align 4
  %convergence.parent.present1629 = icmp ne i32 %convergence.parent.token1628, 0
  %7484 = and i1 %7483, %convergence.parent.present1629
  br i1 %7484, label %convergence.cascade1614, label %convergence.cascade.exit1615

convergence.cascade.exit1615:                     ; preds = %convergence.cascade1614, %schedule.84
  %convergence.cascade.result1630 = phi <8 x i1> [ %1181, %schedule.84 ], [ %7478, %convergence.cascade1614 ]
  %7485 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1630)
  br i1 %7485, label %convergence.target.84.ready, label %scheduler.loop

convergence.target.84.ready:                      ; preds = %convergence.cascade.exit1615
  %7486 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1630)
  %7487 = bitcast <8 x i1> %convergence.cascade.result1630 to i8
  %7488 = call i8 @llvm.cttz.i8(i8 %7487, i1 false)
  %7489 = zext i8 %7488 to i32
  %7490 = select i1 %7486, i32 %7489, i32 0
  %7491 = load <8 x i64>, ptr %.slot172, align 64
  %7492 = select <8 x i1> %convergence.cascade.result1630, <8 x i64> zeroinitializer, <8 x i64> %7491
  store <8 x i64> %7492, ptr %.slot172, align 64
  %7493 = load <8 x float>, ptr %.slot173, align 32
  %7494 = select <8 x i1> %convergence.cascade.result1630, <8 x float> zeroinitializer, <8 x float> %7493
  store <8 x float> %7494, ptr %.slot173, align 32
  store <8 x i1> %convergence.cascade.result1630, ptr %current.mask, align 1
  %7495 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1630)
  br i1 %7495, label %schedule.85, label %scheduler.loop

varying.divergent1632:                            ; preds = %schedule.85
  %7496 = load i32, ptr %current.token, align 4
  %7497 = icmp ne i32 %7496, 0
  %7498 = sub i32 %7496, 1
  %7499 = select i1 %7497, i32 %7498, i32 0
  %7500 = load i8, ptr %frame.active, align 1
  %7501 = trunc i32 %7499 to i8
  %7502 = shl i8 1, %7501
  %7503 = and i8 %7500, %7502
  %7504 = icmp ne i8 %7503, 0
  %7505 = load <8 x i32>, ptr %frame.static.id, align 32
  %7506 = extractelement <8 x i32> %7505, i32 %7499
  %7507 = icmp eq i32 %7506, 36
  %7508 = and i1 %7504, %7507
  %7509 = and i1 %7497, %7508
  %7510 = xor i1 %7509, true
  %7511 = and i1 true, %7510
  %7512 = xor i8 %7500, -1
  %7513 = icmp ne i8 %7512, 0
  %7514 = xor i1 %7513, true
  %7515 = and i1 %7511, %7514
  br i1 %7515, label %convergence.overflow.trap1634, label %convergence.overflow.resume1635

varying.coherent1633:                             ; preds = %schedule.85
  br i1 %1192, label %varying.coherent.true1638, label %varying.coherent.false1639

convergence.overflow.trap1634:                    ; preds = %varying.divergent1632
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1635:                  ; preds = %varying.divergent1632
  %7516 = call i8 @llvm.cttz.i8(i8 %7512, i1 false)
  %7517 = zext i8 %7516 to i32
  %7518 = select i1 %7513, i32 %7517, i32 0
  %7519 = trunc i32 %7518 to i8
  %7520 = shl i8 1, %7519
  %7521 = or i8 %7500, %7520
  %7522 = select i1 %7511, i8 %7521, i8 %7500
  store i8 %7522, ptr %frame.active, align 1
  %7523 = load <8 x i32>, ptr %frame.static.id, align 32
  %7524 = extractelement <8 x i32> %7523, i32 %7518
  %7525 = select i1 %7511, i32 36, i32 %7524
  %7526 = load <8 x i32>, ptr %frame.static.id, align 32
  %7527 = insertelement <8 x i32> %7526, i32 %7525, i32 %7518
  store <8 x i32> %7527, ptr %frame.static.id, align 32
  %7528 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7529 = extractelement <8 x i32> %7528, i32 %7518
  %7530 = select i1 %7511, i32 %7496, i32 %7529
  %7531 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7532 = insertelement <8 x i32> %7531, i32 %7530, i32 %7518
  store <8 x i32> %7532, ptr %frame.parent.token, align 32
  %7533 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7518
  %7534 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7518
  %7535 = load <8 x i1>, ptr %7533, align 1
  %7536 = load <8 x i1>, ptr %7534, align 1
  %7537 = select i1 %7511, <8 x i1> %1182, <8 x i1> %7535
  store <8 x i1> %7537, ptr %7533, align 1
  %7538 = select i1 %7511, <8 x i1> zeroinitializer, <8 x i1> %7536
  store <8 x i1> %7538, ptr %7534, align 1
  %7539 = add i32 %7518, 1
  %7540 = select i1 %7509, i32 %7496, i32 %7539
  %7541 = select i1 true, i32 %7540, i32 %7496
  store i32 %7541, ptr %current.token, align 4
  %7542 = load i32, ptr %current.token, align 4
  %7543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1189)
  %7544 = load i32, ptr %ready.count, align 4
  %7545 = icmp uge i32 %7544, 8
  %7546 = and i1 %7543, %7545
  br i1 %7546, label %ready.overflow.trap1636, label %ready.overflow.resume1637

ready.overflow.trap1636:                          ; preds = %convergence.overflow.resume1635
  call void @llvm.trap()
  unreachable

ready.overflow.resume1637:                        ; preds = %convergence.overflow.resume1635
  %7547 = select i1 %7543, i32 %7544, i32 0
  %7548 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7547
  %7549 = load <8 x i1>, ptr %7548, align 1
  %7550 = select i1 %7543, <8 x i1> %1189, <8 x i1> %7549
  store <8 x i1> %7550, ptr %7548, align 1
  %7551 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7547
  %7552 = load i32, ptr %7551, align 4
  %7553 = select i1 %7543, i32 86, i32 %7552
  store i32 %7553, ptr %7551, align 4
  %7554 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7547
  %7555 = load i32, ptr %7554, align 4
  %7556 = select i1 %7543, i32 %7542, i32 %7555
  store i32 %7556, ptr %7554, align 4
  %7557 = add i32 %7544, 1
  %7558 = select i1 %7543, i32 %7557, i32 %7544
  store i32 %7558, ptr %ready.count, align 4
  %7559 = load <8 x i1>, ptr %runnable.mask, align 1
  %7560 = or <8 x i1> %7559, %1189
  store <8 x i1> %7560, ptr %runnable.mask, align 1
  store <8 x i1> %1191, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1638:                        ; preds = %varying.coherent1633
  store <8 x i1> %1182, ptr %current.mask, align 1
  %7561 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1182)
  br i1 %7561, label %schedule.86, label %scheduler.loop

varying.coherent.false1639:                       ; preds = %varying.coherent1633
  store <8 x i1> %1182, ptr %current.mask, align 1
  %7562 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1182)
  br i1 %7562, label %schedule.87, label %scheduler.loop

convergence.cascade1647:                          ; preds = %convergence.cascade1647, %schedule.87
  %convergence.cascade.flow1651 = phi <8 x i1> [ %1230, %schedule.87 ], [ %7605, %convergence.cascade1647 ]
  %convergence.cascade.depth1652 = phi i32 [ 0, %schedule.87 ], [ %7606, %convergence.cascade1647 ]
  %7563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1651)
  %7564 = load i32, ptr %current.token, align 4
  %7565 = icmp ne i32 %7564, 0
  %7566 = and i1 %7563, %7565
  %7567 = sub i32 %7564, 1
  %7568 = select i1 %7566, i32 %7567, i32 0
  %7569 = load i8, ptr %frame.active, align 1
  %7570 = trunc i32 %7568 to i8
  %7571 = shl i8 1, %7570
  %7572 = and i8 %7569, %7571
  %7573 = icmp ne i8 %7572, 0
  %7574 = load <8 x i32>, ptr %frame.static.id, align 32
  %7575 = extractelement <8 x i32> %7574, i32 %7568
  %convergence.target.pointer1653 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %7575
  %convergence.dynamic.target1654 = load i32, ptr %convergence.target.pointer1653, align 4
  %7576 = icmp eq i32 %convergence.dynamic.target1654, 87
  %7577 = and i1 %7573, %7576
  %7578 = and i1 %7566, %7577
  %7579 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7568
  %7580 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7568
  %7581 = load <8 x i1>, ptr %7579, align 1
  %7582 = load <8 x i1>, ptr %7580, align 1
  %7583 = or <8 x i1> %7582, %convergence.cascade.flow1651
  %7584 = load <8 x i1>, ptr %live.mask, align 1
  %7585 = and <8 x i1> %7581, %7584
  %7586 = icmp eq <8 x i1> %7583, %7585
  %7587 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7586)
  %7588 = and i1 %7578, %7587
  %7589 = select i1 %7588, <8 x i1> zeroinitializer, <8 x i1> %7583
  %7590 = select i1 %7578, <8 x i1> %7589, <8 x i1> %7582
  store <8 x i1> %7590, ptr %7580, align 1
  %7591 = select i1 %7588, <8 x i1> zeroinitializer, <8 x i1> %7581
  store <8 x i1> %7591, ptr %7579, align 1
  %7592 = trunc i32 %7568 to i8
  %7593 = shl i8 1, %7592
  %7594 = xor i8 %7593, -1
  %7595 = and i8 %7569, %7594
  %7596 = select i1 %7588, i8 %7595, i8 %7569
  store i8 %7596, ptr %frame.active, align 1
  %.splatinsert1655 = insertelement <8 x i1> poison, i1 %7578, i64 0
  %.splat1656 = shufflevector <8 x i1> %.splatinsert1655, <8 x i1> poison, <8 x i32> zeroinitializer
  %7597 = and <8 x i1> %convergence.cascade.flow1651, %.splat1656
  %7598 = load <8 x i1>, ptr %runnable.mask, align 1
  %7599 = xor <8 x i1> %7597, splat (i1 true)
  %7600 = and <8 x i1> %7598, %7599
  store <8 x i1> %7600, ptr %runnable.mask, align 1
  %.splatinsert1657 = insertelement <8 x i1> poison, i1 %7588, i64 0
  %.splat1658 = shufflevector <8 x i1> %.splatinsert1657, <8 x i1> poison, <8 x i32> zeroinitializer
  %7601 = select <8 x i1> %.splat1658, <8 x i1> %7583, <8 x i1> zeroinitializer
  %7602 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7603 = extractelement <8 x i32> %7602, i32 %7568
  %7604 = select i1 %7588, i32 %7603, i32 %7564
  store i32 %7604, ptr %current.token, align 4
  %.splatinsert1659 = insertelement <8 x i1> poison, i1 %7578, i64 0
  %.splat1660 = shufflevector <8 x i1> %.splatinsert1659, <8 x i1> poison, <8 x i32> zeroinitializer
  %7605 = select <8 x i1> %.splat1660, <8 x i1> %7601, <8 x i1> %convergence.cascade.flow1651
  %7606 = add i32 %convergence.cascade.depth1652, 1
  %7607 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7605)
  %7608 = icmp ult i32 %7606, 8
  %7609 = and i1 %7607, %7608
  %7610 = and i1 %7578, %7609
  %convergence.parent.token1661 = load i32, ptr %current.token, align 4
  %convergence.parent.present1662 = icmp ne i32 %convergence.parent.token1661, 0
  %7611 = and i1 %7610, %convergence.parent.present1662
  br i1 %7611, label %convergence.cascade1647, label %convergence.cascade.exit1648

convergence.cascade.exit1648:                     ; preds = %convergence.cascade1647, %schedule.87
  %convergence.cascade.result1663 = phi <8 x i1> [ %1230, %schedule.87 ], [ %7605, %convergence.cascade1647 ]
  %7612 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1663)
  br i1 %7612, label %convergence.target.87.ready, label %scheduler.loop

convergence.target.87.ready:                      ; preds = %convergence.cascade.exit1648
  %7613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1663)
  %7614 = bitcast <8 x i1> %convergence.cascade.result1663 to i8
  %7615 = call i8 @llvm.cttz.i8(i8 %7614, i1 false)
  %7616 = zext i8 %7615 to i32
  %7617 = select i1 %7613, i32 %7616, i32 0
  %7618 = load <8 x i64>, ptr %.slot174, align 64
  %7619 = select <8 x i1> %convergence.cascade.result1663, <8 x i64> zeroinitializer, <8 x i64> %7618
  store <8 x i64> %7619, ptr %.slot174, align 64
  %7620 = load <8 x float>, ptr %.slot175, align 32
  %7621 = select <8 x i1> %convergence.cascade.result1663, <8 x float> zeroinitializer, <8 x float> %7620
  store <8 x float> %7621, ptr %.slot175, align 32
  store <8 x i1> %convergence.cascade.result1663, ptr %current.mask, align 1
  %7622 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1663)
  br i1 %7622, label %schedule.88, label %scheduler.loop

varying.divergent1665:                            ; preds = %schedule.88
  %7623 = load i32, ptr %current.token, align 4
  %7624 = icmp ne i32 %7623, 0
  %7625 = sub i32 %7623, 1
  %7626 = select i1 %7624, i32 %7625, i32 0
  %7627 = load i8, ptr %frame.active, align 1
  %7628 = trunc i32 %7626 to i8
  %7629 = shl i8 1, %7628
  %7630 = and i8 %7627, %7629
  %7631 = icmp ne i8 %7630, 0
  %7632 = load <8 x i32>, ptr %frame.static.id, align 32
  %7633 = extractelement <8 x i32> %7632, i32 %7626
  %7634 = icmp eq i32 %7633, 37
  %7635 = and i1 %7631, %7634
  %7636 = and i1 %7624, %7635
  %7637 = xor i1 %7636, true
  %7638 = and i1 true, %7637
  %7639 = xor i8 %7627, -1
  %7640 = icmp ne i8 %7639, 0
  %7641 = xor i1 %7640, true
  %7642 = and i1 %7638, %7641
  br i1 %7642, label %convergence.overflow.trap1667, label %convergence.overflow.resume1668

varying.coherent1666:                             ; preds = %schedule.88
  br i1 %1241, label %varying.coherent.true1671, label %varying.coherent.false1672

convergence.overflow.trap1667:                    ; preds = %varying.divergent1665
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1668:                  ; preds = %varying.divergent1665
  %7643 = call i8 @llvm.cttz.i8(i8 %7639, i1 false)
  %7644 = zext i8 %7643 to i32
  %7645 = select i1 %7640, i32 %7644, i32 0
  %7646 = trunc i32 %7645 to i8
  %7647 = shl i8 1, %7646
  %7648 = or i8 %7627, %7647
  %7649 = select i1 %7638, i8 %7648, i8 %7627
  store i8 %7649, ptr %frame.active, align 1
  %7650 = load <8 x i32>, ptr %frame.static.id, align 32
  %7651 = extractelement <8 x i32> %7650, i32 %7645
  %7652 = select i1 %7638, i32 37, i32 %7651
  %7653 = load <8 x i32>, ptr %frame.static.id, align 32
  %7654 = insertelement <8 x i32> %7653, i32 %7652, i32 %7645
  store <8 x i32> %7654, ptr %frame.static.id, align 32
  %7655 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7656 = extractelement <8 x i32> %7655, i32 %7645
  %7657 = select i1 %7638, i32 %7623, i32 %7656
  %7658 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7659 = insertelement <8 x i32> %7658, i32 %7657, i32 %7645
  store <8 x i32> %7659, ptr %frame.parent.token, align 32
  %7660 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7645
  %7661 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7645
  %7662 = load <8 x i1>, ptr %7660, align 1
  %7663 = load <8 x i1>, ptr %7661, align 1
  %7664 = select i1 %7638, <8 x i1> %1231, <8 x i1> %7662
  store <8 x i1> %7664, ptr %7660, align 1
  %7665 = select i1 %7638, <8 x i1> zeroinitializer, <8 x i1> %7663
  store <8 x i1> %7665, ptr %7661, align 1
  %7666 = add i32 %7645, 1
  %7667 = select i1 %7636, i32 %7623, i32 %7666
  %7668 = select i1 true, i32 %7667, i32 %7623
  store i32 %7668, ptr %current.token, align 4
  %7669 = load i32, ptr %current.token, align 4
  %7670 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1238)
  %7671 = load i32, ptr %ready.count, align 4
  %7672 = icmp uge i32 %7671, 8
  %7673 = and i1 %7670, %7672
  br i1 %7673, label %ready.overflow.trap1669, label %ready.overflow.resume1670

ready.overflow.trap1669:                          ; preds = %convergence.overflow.resume1668
  call void @llvm.trap()
  unreachable

ready.overflow.resume1670:                        ; preds = %convergence.overflow.resume1668
  %7674 = select i1 %7670, i32 %7671, i32 0
  %7675 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7674
  %7676 = load <8 x i1>, ptr %7675, align 1
  %7677 = select i1 %7670, <8 x i1> %1238, <8 x i1> %7676
  store <8 x i1> %7677, ptr %7675, align 1
  %7678 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7674
  %7679 = load i32, ptr %7678, align 4
  %7680 = select i1 %7670, i32 89, i32 %7679
  store i32 %7680, ptr %7678, align 4
  %7681 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7674
  %7682 = load i32, ptr %7681, align 4
  %7683 = select i1 %7670, i32 %7669, i32 %7682
  store i32 %7683, ptr %7681, align 4
  %7684 = add i32 %7671, 1
  %7685 = select i1 %7670, i32 %7684, i32 %7671
  store i32 %7685, ptr %ready.count, align 4
  %7686 = load <8 x i1>, ptr %runnable.mask, align 1
  %7687 = or <8 x i1> %7686, %1238
  store <8 x i1> %7687, ptr %runnable.mask, align 1
  store <8 x i1> %1240, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1671:                        ; preds = %varying.coherent1666
  store <8 x i1> %1231, ptr %current.mask, align 1
  %7688 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1231)
  br i1 %7688, label %schedule.89, label %scheduler.loop

varying.coherent.false1672:                       ; preds = %varying.coherent1666
  store <8 x i1> %1231, ptr %current.mask, align 1
  %7689 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1231)
  br i1 %7689, label %schedule.90, label %scheduler.loop

convergence.cascade1680:                          ; preds = %convergence.cascade1680, %schedule.90
  %convergence.cascade.flow1684 = phi <8 x i1> [ %1279, %schedule.90 ], [ %7732, %convergence.cascade1680 ]
  %convergence.cascade.depth1685 = phi i32 [ 0, %schedule.90 ], [ %7733, %convergence.cascade1680 ]
  %7690 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1684)
  %7691 = load i32, ptr %current.token, align 4
  %7692 = icmp ne i32 %7691, 0
  %7693 = and i1 %7690, %7692
  %7694 = sub i32 %7691, 1
  %7695 = select i1 %7693, i32 %7694, i32 0
  %7696 = load i8, ptr %frame.active, align 1
  %7697 = trunc i32 %7695 to i8
  %7698 = shl i8 1, %7697
  %7699 = and i8 %7696, %7698
  %7700 = icmp ne i8 %7699, 0
  %7701 = load <8 x i32>, ptr %frame.static.id, align 32
  %7702 = extractelement <8 x i32> %7701, i32 %7695
  %convergence.target.pointer1686 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %7702
  %convergence.dynamic.target1687 = load i32, ptr %convergence.target.pointer1686, align 4
  %7703 = icmp eq i32 %convergence.dynamic.target1687, 90
  %7704 = and i1 %7700, %7703
  %7705 = and i1 %7693, %7704
  %7706 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7695
  %7707 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7695
  %7708 = load <8 x i1>, ptr %7706, align 1
  %7709 = load <8 x i1>, ptr %7707, align 1
  %7710 = or <8 x i1> %7709, %convergence.cascade.flow1684
  %7711 = load <8 x i1>, ptr %live.mask, align 1
  %7712 = and <8 x i1> %7708, %7711
  %7713 = icmp eq <8 x i1> %7710, %7712
  %7714 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7713)
  %7715 = and i1 %7705, %7714
  %7716 = select i1 %7715, <8 x i1> zeroinitializer, <8 x i1> %7710
  %7717 = select i1 %7705, <8 x i1> %7716, <8 x i1> %7709
  store <8 x i1> %7717, ptr %7707, align 1
  %7718 = select i1 %7715, <8 x i1> zeroinitializer, <8 x i1> %7708
  store <8 x i1> %7718, ptr %7706, align 1
  %7719 = trunc i32 %7695 to i8
  %7720 = shl i8 1, %7719
  %7721 = xor i8 %7720, -1
  %7722 = and i8 %7696, %7721
  %7723 = select i1 %7715, i8 %7722, i8 %7696
  store i8 %7723, ptr %frame.active, align 1
  %.splatinsert1688 = insertelement <8 x i1> poison, i1 %7705, i64 0
  %.splat1689 = shufflevector <8 x i1> %.splatinsert1688, <8 x i1> poison, <8 x i32> zeroinitializer
  %7724 = and <8 x i1> %convergence.cascade.flow1684, %.splat1689
  %7725 = load <8 x i1>, ptr %runnable.mask, align 1
  %7726 = xor <8 x i1> %7724, splat (i1 true)
  %7727 = and <8 x i1> %7725, %7726
  store <8 x i1> %7727, ptr %runnable.mask, align 1
  %.splatinsert1690 = insertelement <8 x i1> poison, i1 %7715, i64 0
  %.splat1691 = shufflevector <8 x i1> %.splatinsert1690, <8 x i1> poison, <8 x i32> zeroinitializer
  %7728 = select <8 x i1> %.splat1691, <8 x i1> %7710, <8 x i1> zeroinitializer
  %7729 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7730 = extractelement <8 x i32> %7729, i32 %7695
  %7731 = select i1 %7715, i32 %7730, i32 %7691
  store i32 %7731, ptr %current.token, align 4
  %.splatinsert1692 = insertelement <8 x i1> poison, i1 %7705, i64 0
  %.splat1693 = shufflevector <8 x i1> %.splatinsert1692, <8 x i1> poison, <8 x i32> zeroinitializer
  %7732 = select <8 x i1> %.splat1693, <8 x i1> %7728, <8 x i1> %convergence.cascade.flow1684
  %7733 = add i32 %convergence.cascade.depth1685, 1
  %7734 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7732)
  %7735 = icmp ult i32 %7733, 8
  %7736 = and i1 %7734, %7735
  %7737 = and i1 %7705, %7736
  %convergence.parent.token1694 = load i32, ptr %current.token, align 4
  %convergence.parent.present1695 = icmp ne i32 %convergence.parent.token1694, 0
  %7738 = and i1 %7737, %convergence.parent.present1695
  br i1 %7738, label %convergence.cascade1680, label %convergence.cascade.exit1681

convergence.cascade.exit1681:                     ; preds = %convergence.cascade1680, %schedule.90
  %convergence.cascade.result1696 = phi <8 x i1> [ %1279, %schedule.90 ], [ %7732, %convergence.cascade1680 ]
  %7739 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1696)
  br i1 %7739, label %convergence.target.90.ready, label %scheduler.loop

convergence.target.90.ready:                      ; preds = %convergence.cascade.exit1681
  %7740 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1696)
  %7741 = bitcast <8 x i1> %convergence.cascade.result1696 to i8
  %7742 = call i8 @llvm.cttz.i8(i8 %7741, i1 false)
  %7743 = zext i8 %7742 to i32
  %7744 = select i1 %7740, i32 %7743, i32 0
  %7745 = load <8 x i64>, ptr %.slot176, align 64
  %7746 = select <8 x i1> %convergence.cascade.result1696, <8 x i64> zeroinitializer, <8 x i64> %7745
  store <8 x i64> %7746, ptr %.slot176, align 64
  %7747 = load <8 x float>, ptr %.slot177, align 32
  %7748 = select <8 x i1> %convergence.cascade.result1696, <8 x float> zeroinitializer, <8 x float> %7747
  store <8 x float> %7748, ptr %.slot177, align 32
  store <8 x i1> %convergence.cascade.result1696, ptr %current.mask, align 1
  %7749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1696)
  br i1 %7749, label %schedule.91, label %scheduler.loop

varying.divergent1698:                            ; preds = %schedule.91
  %7750 = load i32, ptr %current.token, align 4
  %7751 = icmp ne i32 %7750, 0
  %7752 = sub i32 %7750, 1
  %7753 = select i1 %7751, i32 %7752, i32 0
  %7754 = load i8, ptr %frame.active, align 1
  %7755 = trunc i32 %7753 to i8
  %7756 = shl i8 1, %7755
  %7757 = and i8 %7754, %7756
  %7758 = icmp ne i8 %7757, 0
  %7759 = load <8 x i32>, ptr %frame.static.id, align 32
  %7760 = extractelement <8 x i32> %7759, i32 %7753
  %7761 = icmp eq i32 %7760, 38
  %7762 = and i1 %7758, %7761
  %7763 = and i1 %7751, %7762
  %7764 = xor i1 %7763, true
  %7765 = and i1 true, %7764
  %7766 = xor i8 %7754, -1
  %7767 = icmp ne i8 %7766, 0
  %7768 = xor i1 %7767, true
  %7769 = and i1 %7765, %7768
  br i1 %7769, label %convergence.overflow.trap1700, label %convergence.overflow.resume1701

varying.coherent1699:                             ; preds = %schedule.91
  br i1 %1290, label %varying.coherent.true1704, label %varying.coherent.false1705

convergence.overflow.trap1700:                    ; preds = %varying.divergent1698
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1701:                  ; preds = %varying.divergent1698
  %7770 = call i8 @llvm.cttz.i8(i8 %7766, i1 false)
  %7771 = zext i8 %7770 to i32
  %7772 = select i1 %7767, i32 %7771, i32 0
  %7773 = trunc i32 %7772 to i8
  %7774 = shl i8 1, %7773
  %7775 = or i8 %7754, %7774
  %7776 = select i1 %7765, i8 %7775, i8 %7754
  store i8 %7776, ptr %frame.active, align 1
  %7777 = load <8 x i32>, ptr %frame.static.id, align 32
  %7778 = extractelement <8 x i32> %7777, i32 %7772
  %7779 = select i1 %7765, i32 38, i32 %7778
  %7780 = load <8 x i32>, ptr %frame.static.id, align 32
  %7781 = insertelement <8 x i32> %7780, i32 %7779, i32 %7772
  store <8 x i32> %7781, ptr %frame.static.id, align 32
  %7782 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7783 = extractelement <8 x i32> %7782, i32 %7772
  %7784 = select i1 %7765, i32 %7750, i32 %7783
  %7785 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7786 = insertelement <8 x i32> %7785, i32 %7784, i32 %7772
  store <8 x i32> %7786, ptr %frame.parent.token, align 32
  %7787 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7772
  %7788 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7772
  %7789 = load <8 x i1>, ptr %7787, align 1
  %7790 = load <8 x i1>, ptr %7788, align 1
  %7791 = select i1 %7765, <8 x i1> %1280, <8 x i1> %7789
  store <8 x i1> %7791, ptr %7787, align 1
  %7792 = select i1 %7765, <8 x i1> zeroinitializer, <8 x i1> %7790
  store <8 x i1> %7792, ptr %7788, align 1
  %7793 = add i32 %7772, 1
  %7794 = select i1 %7763, i32 %7750, i32 %7793
  %7795 = select i1 true, i32 %7794, i32 %7750
  store i32 %7795, ptr %current.token, align 4
  %7796 = load i32, ptr %current.token, align 4
  %7797 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1287)
  %7798 = load i32, ptr %ready.count, align 4
  %7799 = icmp uge i32 %7798, 8
  %7800 = and i1 %7797, %7799
  br i1 %7800, label %ready.overflow.trap1702, label %ready.overflow.resume1703

ready.overflow.trap1702:                          ; preds = %convergence.overflow.resume1701
  call void @llvm.trap()
  unreachable

ready.overflow.resume1703:                        ; preds = %convergence.overflow.resume1701
  %7801 = select i1 %7797, i32 %7798, i32 0
  %7802 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7801
  %7803 = load <8 x i1>, ptr %7802, align 1
  %7804 = select i1 %7797, <8 x i1> %1287, <8 x i1> %7803
  store <8 x i1> %7804, ptr %7802, align 1
  %7805 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7801
  %7806 = load i32, ptr %7805, align 4
  %7807 = select i1 %7797, i32 92, i32 %7806
  store i32 %7807, ptr %7805, align 4
  %7808 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7801
  %7809 = load i32, ptr %7808, align 4
  %7810 = select i1 %7797, i32 %7796, i32 %7809
  store i32 %7810, ptr %7808, align 4
  %7811 = add i32 %7798, 1
  %7812 = select i1 %7797, i32 %7811, i32 %7798
  store i32 %7812, ptr %ready.count, align 4
  %7813 = load <8 x i1>, ptr %runnable.mask, align 1
  %7814 = or <8 x i1> %7813, %1287
  store <8 x i1> %7814, ptr %runnable.mask, align 1
  store <8 x i1> %1289, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1704:                        ; preds = %varying.coherent1699
  store <8 x i1> %1280, ptr %current.mask, align 1
  %7815 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1280)
  br i1 %7815, label %schedule.92, label %scheduler.loop

varying.coherent.false1705:                       ; preds = %varying.coherent1699
  store <8 x i1> %1280, ptr %current.mask, align 1
  %7816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1280)
  br i1 %7816, label %schedule.93, label %scheduler.loop

convergence.cascade1713:                          ; preds = %convergence.cascade1713, %schedule.93
  %convergence.cascade.flow1717 = phi <8 x i1> [ %1328, %schedule.93 ], [ %7859, %convergence.cascade1713 ]
  %convergence.cascade.depth1718 = phi i32 [ 0, %schedule.93 ], [ %7860, %convergence.cascade1713 ]
  %7817 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1717)
  %7818 = load i32, ptr %current.token, align 4
  %7819 = icmp ne i32 %7818, 0
  %7820 = and i1 %7817, %7819
  %7821 = sub i32 %7818, 1
  %7822 = select i1 %7820, i32 %7821, i32 0
  %7823 = load i8, ptr %frame.active, align 1
  %7824 = trunc i32 %7822 to i8
  %7825 = shl i8 1, %7824
  %7826 = and i8 %7823, %7825
  %7827 = icmp ne i8 %7826, 0
  %7828 = load <8 x i32>, ptr %frame.static.id, align 32
  %7829 = extractelement <8 x i32> %7828, i32 %7822
  %convergence.target.pointer1719 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %7829
  %convergence.dynamic.target1720 = load i32, ptr %convergence.target.pointer1719, align 4
  %7830 = icmp eq i32 %convergence.dynamic.target1720, 93
  %7831 = and i1 %7827, %7830
  %7832 = and i1 %7820, %7831
  %7833 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7822
  %7834 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7822
  %7835 = load <8 x i1>, ptr %7833, align 1
  %7836 = load <8 x i1>, ptr %7834, align 1
  %7837 = or <8 x i1> %7836, %convergence.cascade.flow1717
  %7838 = load <8 x i1>, ptr %live.mask, align 1
  %7839 = and <8 x i1> %7835, %7838
  %7840 = icmp eq <8 x i1> %7837, %7839
  %7841 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7840)
  %7842 = and i1 %7832, %7841
  %7843 = select i1 %7842, <8 x i1> zeroinitializer, <8 x i1> %7837
  %7844 = select i1 %7832, <8 x i1> %7843, <8 x i1> %7836
  store <8 x i1> %7844, ptr %7834, align 1
  %7845 = select i1 %7842, <8 x i1> zeroinitializer, <8 x i1> %7835
  store <8 x i1> %7845, ptr %7833, align 1
  %7846 = trunc i32 %7822 to i8
  %7847 = shl i8 1, %7846
  %7848 = xor i8 %7847, -1
  %7849 = and i8 %7823, %7848
  %7850 = select i1 %7842, i8 %7849, i8 %7823
  store i8 %7850, ptr %frame.active, align 1
  %.splatinsert1721 = insertelement <8 x i1> poison, i1 %7832, i64 0
  %.splat1722 = shufflevector <8 x i1> %.splatinsert1721, <8 x i1> poison, <8 x i32> zeroinitializer
  %7851 = and <8 x i1> %convergence.cascade.flow1717, %.splat1722
  %7852 = load <8 x i1>, ptr %runnable.mask, align 1
  %7853 = xor <8 x i1> %7851, splat (i1 true)
  %7854 = and <8 x i1> %7852, %7853
  store <8 x i1> %7854, ptr %runnable.mask, align 1
  %.splatinsert1723 = insertelement <8 x i1> poison, i1 %7842, i64 0
  %.splat1724 = shufflevector <8 x i1> %.splatinsert1723, <8 x i1> poison, <8 x i32> zeroinitializer
  %7855 = select <8 x i1> %.splat1724, <8 x i1> %7837, <8 x i1> zeroinitializer
  %7856 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7857 = extractelement <8 x i32> %7856, i32 %7822
  %7858 = select i1 %7842, i32 %7857, i32 %7818
  store i32 %7858, ptr %current.token, align 4
  %.splatinsert1725 = insertelement <8 x i1> poison, i1 %7832, i64 0
  %.splat1726 = shufflevector <8 x i1> %.splatinsert1725, <8 x i1> poison, <8 x i32> zeroinitializer
  %7859 = select <8 x i1> %.splat1726, <8 x i1> %7855, <8 x i1> %convergence.cascade.flow1717
  %7860 = add i32 %convergence.cascade.depth1718, 1
  %7861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7859)
  %7862 = icmp ult i32 %7860, 8
  %7863 = and i1 %7861, %7862
  %7864 = and i1 %7832, %7863
  %convergence.parent.token1727 = load i32, ptr %current.token, align 4
  %convergence.parent.present1728 = icmp ne i32 %convergence.parent.token1727, 0
  %7865 = and i1 %7864, %convergence.parent.present1728
  br i1 %7865, label %convergence.cascade1713, label %convergence.cascade.exit1714

convergence.cascade.exit1714:                     ; preds = %convergence.cascade1713, %schedule.93
  %convergence.cascade.result1729 = phi <8 x i1> [ %1328, %schedule.93 ], [ %7859, %convergence.cascade1713 ]
  %7866 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1729)
  br i1 %7866, label %convergence.target.93.ready, label %scheduler.loop

convergence.target.93.ready:                      ; preds = %convergence.cascade.exit1714
  %7867 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1729)
  %7868 = bitcast <8 x i1> %convergence.cascade.result1729 to i8
  %7869 = call i8 @llvm.cttz.i8(i8 %7868, i1 false)
  %7870 = zext i8 %7869 to i32
  %7871 = select i1 %7867, i32 %7870, i32 0
  %7872 = load <8 x i64>, ptr %.slot178, align 64
  %7873 = select <8 x i1> %convergence.cascade.result1729, <8 x i64> zeroinitializer, <8 x i64> %7872
  store <8 x i64> %7873, ptr %.slot178, align 64
  %7874 = load <8 x float>, ptr %.slot179, align 32
  %7875 = select <8 x i1> %convergence.cascade.result1729, <8 x float> zeroinitializer, <8 x float> %7874
  store <8 x float> %7875, ptr %.slot179, align 32
  store <8 x i1> %convergence.cascade.result1729, ptr %current.mask, align 1
  %7876 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1729)
  br i1 %7876, label %schedule.94, label %scheduler.loop

varying.divergent1731:                            ; preds = %schedule.94
  %7877 = load i32, ptr %current.token, align 4
  %7878 = icmp ne i32 %7877, 0
  %7879 = sub i32 %7877, 1
  %7880 = select i1 %7878, i32 %7879, i32 0
  %7881 = load i8, ptr %frame.active, align 1
  %7882 = trunc i32 %7880 to i8
  %7883 = shl i8 1, %7882
  %7884 = and i8 %7881, %7883
  %7885 = icmp ne i8 %7884, 0
  %7886 = load <8 x i32>, ptr %frame.static.id, align 32
  %7887 = extractelement <8 x i32> %7886, i32 %7880
  %7888 = icmp eq i32 %7887, 39
  %7889 = and i1 %7885, %7888
  %7890 = and i1 %7878, %7889
  %7891 = xor i1 %7890, true
  %7892 = and i1 true, %7891
  %7893 = xor i8 %7881, -1
  %7894 = icmp ne i8 %7893, 0
  %7895 = xor i1 %7894, true
  %7896 = and i1 %7892, %7895
  br i1 %7896, label %convergence.overflow.trap1733, label %convergence.overflow.resume1734

varying.coherent1732:                             ; preds = %schedule.94
  br i1 %1339, label %varying.coherent.true1737, label %varying.coherent.false1738

convergence.overflow.trap1733:                    ; preds = %varying.divergent1731
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1734:                  ; preds = %varying.divergent1731
  %7897 = call i8 @llvm.cttz.i8(i8 %7893, i1 false)
  %7898 = zext i8 %7897 to i32
  %7899 = select i1 %7894, i32 %7898, i32 0
  %7900 = trunc i32 %7899 to i8
  %7901 = shl i8 1, %7900
  %7902 = or i8 %7881, %7901
  %7903 = select i1 %7892, i8 %7902, i8 %7881
  store i8 %7903, ptr %frame.active, align 1
  %7904 = load <8 x i32>, ptr %frame.static.id, align 32
  %7905 = extractelement <8 x i32> %7904, i32 %7899
  %7906 = select i1 %7892, i32 39, i32 %7905
  %7907 = load <8 x i32>, ptr %frame.static.id, align 32
  %7908 = insertelement <8 x i32> %7907, i32 %7906, i32 %7899
  store <8 x i32> %7908, ptr %frame.static.id, align 32
  %7909 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7910 = extractelement <8 x i32> %7909, i32 %7899
  %7911 = select i1 %7892, i32 %7877, i32 %7910
  %7912 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7913 = insertelement <8 x i32> %7912, i32 %7911, i32 %7899
  store <8 x i32> %7913, ptr %frame.parent.token, align 32
  %7914 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7899
  %7915 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7899
  %7916 = load <8 x i1>, ptr %7914, align 1
  %7917 = load <8 x i1>, ptr %7915, align 1
  %7918 = select i1 %7892, <8 x i1> %1329, <8 x i1> %7916
  store <8 x i1> %7918, ptr %7914, align 1
  %7919 = select i1 %7892, <8 x i1> zeroinitializer, <8 x i1> %7917
  store <8 x i1> %7919, ptr %7915, align 1
  %7920 = add i32 %7899, 1
  %7921 = select i1 %7890, i32 %7877, i32 %7920
  %7922 = select i1 true, i32 %7921, i32 %7877
  store i32 %7922, ptr %current.token, align 4
  %7923 = load i32, ptr %current.token, align 4
  %7924 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1336)
  %7925 = load i32, ptr %ready.count, align 4
  %7926 = icmp uge i32 %7925, 8
  %7927 = and i1 %7924, %7926
  br i1 %7927, label %ready.overflow.trap1735, label %ready.overflow.resume1736

ready.overflow.trap1735:                          ; preds = %convergence.overflow.resume1734
  call void @llvm.trap()
  unreachable

ready.overflow.resume1736:                        ; preds = %convergence.overflow.resume1734
  %7928 = select i1 %7924, i32 %7925, i32 0
  %7929 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7928
  %7930 = load <8 x i1>, ptr %7929, align 1
  %7931 = select i1 %7924, <8 x i1> %1336, <8 x i1> %7930
  store <8 x i1> %7931, ptr %7929, align 1
  %7932 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7928
  %7933 = load i32, ptr %7932, align 4
  %7934 = select i1 %7924, i32 95, i32 %7933
  store i32 %7934, ptr %7932, align 4
  %7935 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7928
  %7936 = load i32, ptr %7935, align 4
  %7937 = select i1 %7924, i32 %7923, i32 %7936
  store i32 %7937, ptr %7935, align 4
  %7938 = add i32 %7925, 1
  %7939 = select i1 %7924, i32 %7938, i32 %7925
  store i32 %7939, ptr %ready.count, align 4
  %7940 = load <8 x i1>, ptr %runnable.mask, align 1
  %7941 = or <8 x i1> %7940, %1336
  store <8 x i1> %7941, ptr %runnable.mask, align 1
  store <8 x i1> %1338, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1737:                        ; preds = %varying.coherent1732
  store <8 x i1> %1329, ptr %current.mask, align 1
  %7942 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1329)
  br i1 %7942, label %schedule.95, label %scheduler.loop

varying.coherent.false1738:                       ; preds = %varying.coherent1732
  store <8 x i1> %1329, ptr %current.mask, align 1
  %7943 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1329)
  br i1 %7943, label %schedule.96, label %scheduler.loop

convergence.cascade1746:                          ; preds = %convergence.cascade1746, %schedule.96
  %convergence.cascade.flow1750 = phi <8 x i1> [ %1377, %schedule.96 ], [ %7986, %convergence.cascade1746 ]
  %convergence.cascade.depth1751 = phi i32 [ 0, %schedule.96 ], [ %7987, %convergence.cascade1746 ]
  %7944 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1750)
  %7945 = load i32, ptr %current.token, align 4
  %7946 = icmp ne i32 %7945, 0
  %7947 = and i1 %7944, %7946
  %7948 = sub i32 %7945, 1
  %7949 = select i1 %7947, i32 %7948, i32 0
  %7950 = load i8, ptr %frame.active, align 1
  %7951 = trunc i32 %7949 to i8
  %7952 = shl i8 1, %7951
  %7953 = and i8 %7950, %7952
  %7954 = icmp ne i8 %7953, 0
  %7955 = load <8 x i32>, ptr %frame.static.id, align 32
  %7956 = extractelement <8 x i32> %7955, i32 %7949
  %convergence.target.pointer1752 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %7956
  %convergence.dynamic.target1753 = load i32, ptr %convergence.target.pointer1752, align 4
  %7957 = icmp eq i32 %convergence.dynamic.target1753, 96
  %7958 = and i1 %7954, %7957
  %7959 = and i1 %7947, %7958
  %7960 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7949
  %7961 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7949
  %7962 = load <8 x i1>, ptr %7960, align 1
  %7963 = load <8 x i1>, ptr %7961, align 1
  %7964 = or <8 x i1> %7963, %convergence.cascade.flow1750
  %7965 = load <8 x i1>, ptr %live.mask, align 1
  %7966 = and <8 x i1> %7962, %7965
  %7967 = icmp eq <8 x i1> %7964, %7966
  %7968 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7967)
  %7969 = and i1 %7959, %7968
  %7970 = select i1 %7969, <8 x i1> zeroinitializer, <8 x i1> %7964
  %7971 = select i1 %7959, <8 x i1> %7970, <8 x i1> %7963
  store <8 x i1> %7971, ptr %7961, align 1
  %7972 = select i1 %7969, <8 x i1> zeroinitializer, <8 x i1> %7962
  store <8 x i1> %7972, ptr %7960, align 1
  %7973 = trunc i32 %7949 to i8
  %7974 = shl i8 1, %7973
  %7975 = xor i8 %7974, -1
  %7976 = and i8 %7950, %7975
  %7977 = select i1 %7969, i8 %7976, i8 %7950
  store i8 %7977, ptr %frame.active, align 1
  %.splatinsert1754 = insertelement <8 x i1> poison, i1 %7959, i64 0
  %.splat1755 = shufflevector <8 x i1> %.splatinsert1754, <8 x i1> poison, <8 x i32> zeroinitializer
  %7978 = and <8 x i1> %convergence.cascade.flow1750, %.splat1755
  %7979 = load <8 x i1>, ptr %runnable.mask, align 1
  %7980 = xor <8 x i1> %7978, splat (i1 true)
  %7981 = and <8 x i1> %7979, %7980
  store <8 x i1> %7981, ptr %runnable.mask, align 1
  %.splatinsert1756 = insertelement <8 x i1> poison, i1 %7969, i64 0
  %.splat1757 = shufflevector <8 x i1> %.splatinsert1756, <8 x i1> poison, <8 x i32> zeroinitializer
  %7982 = select <8 x i1> %.splat1757, <8 x i1> %7964, <8 x i1> zeroinitializer
  %7983 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7984 = extractelement <8 x i32> %7983, i32 %7949
  %7985 = select i1 %7969, i32 %7984, i32 %7945
  store i32 %7985, ptr %current.token, align 4
  %.splatinsert1758 = insertelement <8 x i1> poison, i1 %7959, i64 0
  %.splat1759 = shufflevector <8 x i1> %.splatinsert1758, <8 x i1> poison, <8 x i32> zeroinitializer
  %7986 = select <8 x i1> %.splat1759, <8 x i1> %7982, <8 x i1> %convergence.cascade.flow1750
  %7987 = add i32 %convergence.cascade.depth1751, 1
  %7988 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7986)
  %7989 = icmp ult i32 %7987, 8
  %7990 = and i1 %7988, %7989
  %7991 = and i1 %7959, %7990
  %convergence.parent.token1760 = load i32, ptr %current.token, align 4
  %convergence.parent.present1761 = icmp ne i32 %convergence.parent.token1760, 0
  %7992 = and i1 %7991, %convergence.parent.present1761
  br i1 %7992, label %convergence.cascade1746, label %convergence.cascade.exit1747

convergence.cascade.exit1747:                     ; preds = %convergence.cascade1746, %schedule.96
  %convergence.cascade.result1762 = phi <8 x i1> [ %1377, %schedule.96 ], [ %7986, %convergence.cascade1746 ]
  %7993 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1762)
  br i1 %7993, label %convergence.target.96.ready, label %scheduler.loop

convergence.target.96.ready:                      ; preds = %convergence.cascade.exit1747
  %7994 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1762)
  %7995 = bitcast <8 x i1> %convergence.cascade.result1762 to i8
  %7996 = call i8 @llvm.cttz.i8(i8 %7995, i1 false)
  %7997 = zext i8 %7996 to i32
  %7998 = select i1 %7994, i32 %7997, i32 0
  %7999 = load <8 x i64>, ptr %.slot180, align 64
  %8000 = select <8 x i1> %convergence.cascade.result1762, <8 x i64> zeroinitializer, <8 x i64> %7999
  store <8 x i64> %8000, ptr %.slot180, align 64
  %8001 = load <8 x float>, ptr %.slot181, align 32
  %8002 = select <8 x i1> %convergence.cascade.result1762, <8 x float> zeroinitializer, <8 x float> %8001
  store <8 x float> %8002, ptr %.slot181, align 32
  store <8 x i1> %convergence.cascade.result1762, ptr %current.mask, align 1
  %8003 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1762)
  br i1 %8003, label %schedule.97, label %scheduler.loop

varying.divergent1764:                            ; preds = %schedule.97
  %8004 = load i32, ptr %current.token, align 4
  %8005 = icmp ne i32 %8004, 0
  %8006 = sub i32 %8004, 1
  %8007 = select i1 %8005, i32 %8006, i32 0
  %8008 = load i8, ptr %frame.active, align 1
  %8009 = trunc i32 %8007 to i8
  %8010 = shl i8 1, %8009
  %8011 = and i8 %8008, %8010
  %8012 = icmp ne i8 %8011, 0
  %8013 = load <8 x i32>, ptr %frame.static.id, align 32
  %8014 = extractelement <8 x i32> %8013, i32 %8007
  %8015 = icmp eq i32 %8014, 40
  %8016 = and i1 %8012, %8015
  %8017 = and i1 %8005, %8016
  %8018 = xor i1 %8017, true
  %8019 = and i1 true, %8018
  %8020 = xor i8 %8008, -1
  %8021 = icmp ne i8 %8020, 0
  %8022 = xor i1 %8021, true
  %8023 = and i1 %8019, %8022
  br i1 %8023, label %convergence.overflow.trap1766, label %convergence.overflow.resume1767

varying.coherent1765:                             ; preds = %schedule.97
  br i1 %1388, label %varying.coherent.true1770, label %varying.coherent.false1771

convergence.overflow.trap1766:                    ; preds = %varying.divergent1764
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1767:                  ; preds = %varying.divergent1764
  %8024 = call i8 @llvm.cttz.i8(i8 %8020, i1 false)
  %8025 = zext i8 %8024 to i32
  %8026 = select i1 %8021, i32 %8025, i32 0
  %8027 = trunc i32 %8026 to i8
  %8028 = shl i8 1, %8027
  %8029 = or i8 %8008, %8028
  %8030 = select i1 %8019, i8 %8029, i8 %8008
  store i8 %8030, ptr %frame.active, align 1
  %8031 = load <8 x i32>, ptr %frame.static.id, align 32
  %8032 = extractelement <8 x i32> %8031, i32 %8026
  %8033 = select i1 %8019, i32 40, i32 %8032
  %8034 = load <8 x i32>, ptr %frame.static.id, align 32
  %8035 = insertelement <8 x i32> %8034, i32 %8033, i32 %8026
  store <8 x i32> %8035, ptr %frame.static.id, align 32
  %8036 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8037 = extractelement <8 x i32> %8036, i32 %8026
  %8038 = select i1 %8019, i32 %8004, i32 %8037
  %8039 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8040 = insertelement <8 x i32> %8039, i32 %8038, i32 %8026
  store <8 x i32> %8040, ptr %frame.parent.token, align 32
  %8041 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8026
  %8042 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8026
  %8043 = load <8 x i1>, ptr %8041, align 1
  %8044 = load <8 x i1>, ptr %8042, align 1
  %8045 = select i1 %8019, <8 x i1> %1378, <8 x i1> %8043
  store <8 x i1> %8045, ptr %8041, align 1
  %8046 = select i1 %8019, <8 x i1> zeroinitializer, <8 x i1> %8044
  store <8 x i1> %8046, ptr %8042, align 1
  %8047 = add i32 %8026, 1
  %8048 = select i1 %8017, i32 %8004, i32 %8047
  %8049 = select i1 true, i32 %8048, i32 %8004
  store i32 %8049, ptr %current.token, align 4
  %8050 = load i32, ptr %current.token, align 4
  %8051 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1385)
  %8052 = load i32, ptr %ready.count, align 4
  %8053 = icmp uge i32 %8052, 8
  %8054 = and i1 %8051, %8053
  br i1 %8054, label %ready.overflow.trap1768, label %ready.overflow.resume1769

ready.overflow.trap1768:                          ; preds = %convergence.overflow.resume1767
  call void @llvm.trap()
  unreachable

ready.overflow.resume1769:                        ; preds = %convergence.overflow.resume1767
  %8055 = select i1 %8051, i32 %8052, i32 0
  %8056 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8055
  %8057 = load <8 x i1>, ptr %8056, align 1
  %8058 = select i1 %8051, <8 x i1> %1385, <8 x i1> %8057
  store <8 x i1> %8058, ptr %8056, align 1
  %8059 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8055
  %8060 = load i32, ptr %8059, align 4
  %8061 = select i1 %8051, i32 98, i32 %8060
  store i32 %8061, ptr %8059, align 4
  %8062 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8055
  %8063 = load i32, ptr %8062, align 4
  %8064 = select i1 %8051, i32 %8050, i32 %8063
  store i32 %8064, ptr %8062, align 4
  %8065 = add i32 %8052, 1
  %8066 = select i1 %8051, i32 %8065, i32 %8052
  store i32 %8066, ptr %ready.count, align 4
  %8067 = load <8 x i1>, ptr %runnable.mask, align 1
  %8068 = or <8 x i1> %8067, %1385
  store <8 x i1> %8068, ptr %runnable.mask, align 1
  store <8 x i1> %1387, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1770:                        ; preds = %varying.coherent1765
  store <8 x i1> %1378, ptr %current.mask, align 1
  %8069 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1378)
  br i1 %8069, label %schedule.98, label %scheduler.loop

varying.coherent.false1771:                       ; preds = %varying.coherent1765
  store <8 x i1> %1378, ptr %current.mask, align 1
  %8070 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1378)
  br i1 %8070, label %schedule.99, label %scheduler.loop

convergence.cascade1779:                          ; preds = %convergence.cascade1779, %schedule.99
  %convergence.cascade.flow1783 = phi <8 x i1> [ %1426, %schedule.99 ], [ %8113, %convergence.cascade1779 ]
  %convergence.cascade.depth1784 = phi i32 [ 0, %schedule.99 ], [ %8114, %convergence.cascade1779 ]
  %8071 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1783)
  %8072 = load i32, ptr %current.token, align 4
  %8073 = icmp ne i32 %8072, 0
  %8074 = and i1 %8071, %8073
  %8075 = sub i32 %8072, 1
  %8076 = select i1 %8074, i32 %8075, i32 0
  %8077 = load i8, ptr %frame.active, align 1
  %8078 = trunc i32 %8076 to i8
  %8079 = shl i8 1, %8078
  %8080 = and i8 %8077, %8079
  %8081 = icmp ne i8 %8080, 0
  %8082 = load <8 x i32>, ptr %frame.static.id, align 32
  %8083 = extractelement <8 x i32> %8082, i32 %8076
  %convergence.target.pointer1785 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %8083
  %convergence.dynamic.target1786 = load i32, ptr %convergence.target.pointer1785, align 4
  %8084 = icmp eq i32 %convergence.dynamic.target1786, 99
  %8085 = and i1 %8081, %8084
  %8086 = and i1 %8074, %8085
  %8087 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8076
  %8088 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8076
  %8089 = load <8 x i1>, ptr %8087, align 1
  %8090 = load <8 x i1>, ptr %8088, align 1
  %8091 = or <8 x i1> %8090, %convergence.cascade.flow1783
  %8092 = load <8 x i1>, ptr %live.mask, align 1
  %8093 = and <8 x i1> %8089, %8092
  %8094 = icmp eq <8 x i1> %8091, %8093
  %8095 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8094)
  %8096 = and i1 %8086, %8095
  %8097 = select i1 %8096, <8 x i1> zeroinitializer, <8 x i1> %8091
  %8098 = select i1 %8086, <8 x i1> %8097, <8 x i1> %8090
  store <8 x i1> %8098, ptr %8088, align 1
  %8099 = select i1 %8096, <8 x i1> zeroinitializer, <8 x i1> %8089
  store <8 x i1> %8099, ptr %8087, align 1
  %8100 = trunc i32 %8076 to i8
  %8101 = shl i8 1, %8100
  %8102 = xor i8 %8101, -1
  %8103 = and i8 %8077, %8102
  %8104 = select i1 %8096, i8 %8103, i8 %8077
  store i8 %8104, ptr %frame.active, align 1
  %.splatinsert1787 = insertelement <8 x i1> poison, i1 %8086, i64 0
  %.splat1788 = shufflevector <8 x i1> %.splatinsert1787, <8 x i1> poison, <8 x i32> zeroinitializer
  %8105 = and <8 x i1> %convergence.cascade.flow1783, %.splat1788
  %8106 = load <8 x i1>, ptr %runnable.mask, align 1
  %8107 = xor <8 x i1> %8105, splat (i1 true)
  %8108 = and <8 x i1> %8106, %8107
  store <8 x i1> %8108, ptr %runnable.mask, align 1
  %.splatinsert1789 = insertelement <8 x i1> poison, i1 %8096, i64 0
  %.splat1790 = shufflevector <8 x i1> %.splatinsert1789, <8 x i1> poison, <8 x i32> zeroinitializer
  %8109 = select <8 x i1> %.splat1790, <8 x i1> %8091, <8 x i1> zeroinitializer
  %8110 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8111 = extractelement <8 x i32> %8110, i32 %8076
  %8112 = select i1 %8096, i32 %8111, i32 %8072
  store i32 %8112, ptr %current.token, align 4
  %.splatinsert1791 = insertelement <8 x i1> poison, i1 %8086, i64 0
  %.splat1792 = shufflevector <8 x i1> %.splatinsert1791, <8 x i1> poison, <8 x i32> zeroinitializer
  %8113 = select <8 x i1> %.splat1792, <8 x i1> %8109, <8 x i1> %convergence.cascade.flow1783
  %8114 = add i32 %convergence.cascade.depth1784, 1
  %8115 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8113)
  %8116 = icmp ult i32 %8114, 8
  %8117 = and i1 %8115, %8116
  %8118 = and i1 %8086, %8117
  %convergence.parent.token1793 = load i32, ptr %current.token, align 4
  %convergence.parent.present1794 = icmp ne i32 %convergence.parent.token1793, 0
  %8119 = and i1 %8118, %convergence.parent.present1794
  br i1 %8119, label %convergence.cascade1779, label %convergence.cascade.exit1780

convergence.cascade.exit1780:                     ; preds = %convergence.cascade1779, %schedule.99
  %convergence.cascade.result1795 = phi <8 x i1> [ %1426, %schedule.99 ], [ %8113, %convergence.cascade1779 ]
  %8120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1795)
  br i1 %8120, label %convergence.target.99.ready, label %scheduler.loop

convergence.target.99.ready:                      ; preds = %convergence.cascade.exit1780
  %8121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1795)
  %8122 = bitcast <8 x i1> %convergence.cascade.result1795 to i8
  %8123 = call i8 @llvm.cttz.i8(i8 %8122, i1 false)
  %8124 = zext i8 %8123 to i32
  %8125 = select i1 %8121, i32 %8124, i32 0
  %8126 = load <8 x i64>, ptr %.slot182, align 64
  %8127 = select <8 x i1> %convergence.cascade.result1795, <8 x i64> zeroinitializer, <8 x i64> %8126
  store <8 x i64> %8127, ptr %.slot182, align 64
  %8128 = load <8 x float>, ptr %.slot183, align 32
  %8129 = select <8 x i1> %convergence.cascade.result1795, <8 x float> zeroinitializer, <8 x float> %8128
  store <8 x float> %8129, ptr %.slot183, align 32
  store <8 x i1> %convergence.cascade.result1795, ptr %current.mask, align 1
  %8130 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1795)
  br i1 %8130, label %schedule.100, label %scheduler.loop

varying.divergent1797:                            ; preds = %schedule.100
  %8131 = load i32, ptr %current.token, align 4
  %8132 = icmp ne i32 %8131, 0
  %8133 = sub i32 %8131, 1
  %8134 = select i1 %8132, i32 %8133, i32 0
  %8135 = load i8, ptr %frame.active, align 1
  %8136 = trunc i32 %8134 to i8
  %8137 = shl i8 1, %8136
  %8138 = and i8 %8135, %8137
  %8139 = icmp ne i8 %8138, 0
  %8140 = load <8 x i32>, ptr %frame.static.id, align 32
  %8141 = extractelement <8 x i32> %8140, i32 %8134
  %8142 = icmp eq i32 %8141, 41
  %8143 = and i1 %8139, %8142
  %8144 = and i1 %8132, %8143
  %8145 = xor i1 %8144, true
  %8146 = and i1 true, %8145
  %8147 = xor i8 %8135, -1
  %8148 = icmp ne i8 %8147, 0
  %8149 = xor i1 %8148, true
  %8150 = and i1 %8146, %8149
  br i1 %8150, label %convergence.overflow.trap1799, label %convergence.overflow.resume1800

varying.coherent1798:                             ; preds = %schedule.100
  br i1 %1437, label %varying.coherent.true1803, label %varying.coherent.false1804

convergence.overflow.trap1799:                    ; preds = %varying.divergent1797
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1800:                  ; preds = %varying.divergent1797
  %8151 = call i8 @llvm.cttz.i8(i8 %8147, i1 false)
  %8152 = zext i8 %8151 to i32
  %8153 = select i1 %8148, i32 %8152, i32 0
  %8154 = trunc i32 %8153 to i8
  %8155 = shl i8 1, %8154
  %8156 = or i8 %8135, %8155
  %8157 = select i1 %8146, i8 %8156, i8 %8135
  store i8 %8157, ptr %frame.active, align 1
  %8158 = load <8 x i32>, ptr %frame.static.id, align 32
  %8159 = extractelement <8 x i32> %8158, i32 %8153
  %8160 = select i1 %8146, i32 41, i32 %8159
  %8161 = load <8 x i32>, ptr %frame.static.id, align 32
  %8162 = insertelement <8 x i32> %8161, i32 %8160, i32 %8153
  store <8 x i32> %8162, ptr %frame.static.id, align 32
  %8163 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8164 = extractelement <8 x i32> %8163, i32 %8153
  %8165 = select i1 %8146, i32 %8131, i32 %8164
  %8166 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8167 = insertelement <8 x i32> %8166, i32 %8165, i32 %8153
  store <8 x i32> %8167, ptr %frame.parent.token, align 32
  %8168 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8153
  %8169 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8153
  %8170 = load <8 x i1>, ptr %8168, align 1
  %8171 = load <8 x i1>, ptr %8169, align 1
  %8172 = select i1 %8146, <8 x i1> %1427, <8 x i1> %8170
  store <8 x i1> %8172, ptr %8168, align 1
  %8173 = select i1 %8146, <8 x i1> zeroinitializer, <8 x i1> %8171
  store <8 x i1> %8173, ptr %8169, align 1
  %8174 = add i32 %8153, 1
  %8175 = select i1 %8144, i32 %8131, i32 %8174
  %8176 = select i1 true, i32 %8175, i32 %8131
  store i32 %8176, ptr %current.token, align 4
  %8177 = load i32, ptr %current.token, align 4
  %8178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1434)
  %8179 = load i32, ptr %ready.count, align 4
  %8180 = icmp uge i32 %8179, 8
  %8181 = and i1 %8178, %8180
  br i1 %8181, label %ready.overflow.trap1801, label %ready.overflow.resume1802

ready.overflow.trap1801:                          ; preds = %convergence.overflow.resume1800
  call void @llvm.trap()
  unreachable

ready.overflow.resume1802:                        ; preds = %convergence.overflow.resume1800
  %8182 = select i1 %8178, i32 %8179, i32 0
  %8183 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8182
  %8184 = load <8 x i1>, ptr %8183, align 1
  %8185 = select i1 %8178, <8 x i1> %1434, <8 x i1> %8184
  store <8 x i1> %8185, ptr %8183, align 1
  %8186 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8182
  %8187 = load i32, ptr %8186, align 4
  %8188 = select i1 %8178, i32 101, i32 %8187
  store i32 %8188, ptr %8186, align 4
  %8189 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8182
  %8190 = load i32, ptr %8189, align 4
  %8191 = select i1 %8178, i32 %8177, i32 %8190
  store i32 %8191, ptr %8189, align 4
  %8192 = add i32 %8179, 1
  %8193 = select i1 %8178, i32 %8192, i32 %8179
  store i32 %8193, ptr %ready.count, align 4
  %8194 = load <8 x i1>, ptr %runnable.mask, align 1
  %8195 = or <8 x i1> %8194, %1434
  store <8 x i1> %8195, ptr %runnable.mask, align 1
  store <8 x i1> %1436, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1803:                        ; preds = %varying.coherent1798
  store <8 x i1> %1427, ptr %current.mask, align 1
  %8196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1427)
  br i1 %8196, label %schedule.101, label %scheduler.loop

varying.coherent.false1804:                       ; preds = %varying.coherent1798
  store <8 x i1> %1427, ptr %current.mask, align 1
  %8197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1427)
  br i1 %8197, label %schedule.102, label %scheduler.loop

convergence.cascade1812:                          ; preds = %convergence.cascade1812, %schedule.102
  %convergence.cascade.flow1816 = phi <8 x i1> [ %1475, %schedule.102 ], [ %8240, %convergence.cascade1812 ]
  %convergence.cascade.depth1817 = phi i32 [ 0, %schedule.102 ], [ %8241, %convergence.cascade1812 ]
  %8198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1816)
  %8199 = load i32, ptr %current.token, align 4
  %8200 = icmp ne i32 %8199, 0
  %8201 = and i1 %8198, %8200
  %8202 = sub i32 %8199, 1
  %8203 = select i1 %8201, i32 %8202, i32 0
  %8204 = load i8, ptr %frame.active, align 1
  %8205 = trunc i32 %8203 to i8
  %8206 = shl i8 1, %8205
  %8207 = and i8 %8204, %8206
  %8208 = icmp ne i8 %8207, 0
  %8209 = load <8 x i32>, ptr %frame.static.id, align 32
  %8210 = extractelement <8 x i32> %8209, i32 %8203
  %convergence.target.pointer1818 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %8210
  %convergence.dynamic.target1819 = load i32, ptr %convergence.target.pointer1818, align 4
  %8211 = icmp eq i32 %convergence.dynamic.target1819, 102
  %8212 = and i1 %8208, %8211
  %8213 = and i1 %8201, %8212
  %8214 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8203
  %8215 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8203
  %8216 = load <8 x i1>, ptr %8214, align 1
  %8217 = load <8 x i1>, ptr %8215, align 1
  %8218 = or <8 x i1> %8217, %convergence.cascade.flow1816
  %8219 = load <8 x i1>, ptr %live.mask, align 1
  %8220 = and <8 x i1> %8216, %8219
  %8221 = icmp eq <8 x i1> %8218, %8220
  %8222 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8221)
  %8223 = and i1 %8213, %8222
  %8224 = select i1 %8223, <8 x i1> zeroinitializer, <8 x i1> %8218
  %8225 = select i1 %8213, <8 x i1> %8224, <8 x i1> %8217
  store <8 x i1> %8225, ptr %8215, align 1
  %8226 = select i1 %8223, <8 x i1> zeroinitializer, <8 x i1> %8216
  store <8 x i1> %8226, ptr %8214, align 1
  %8227 = trunc i32 %8203 to i8
  %8228 = shl i8 1, %8227
  %8229 = xor i8 %8228, -1
  %8230 = and i8 %8204, %8229
  %8231 = select i1 %8223, i8 %8230, i8 %8204
  store i8 %8231, ptr %frame.active, align 1
  %.splatinsert1820 = insertelement <8 x i1> poison, i1 %8213, i64 0
  %.splat1821 = shufflevector <8 x i1> %.splatinsert1820, <8 x i1> poison, <8 x i32> zeroinitializer
  %8232 = and <8 x i1> %convergence.cascade.flow1816, %.splat1821
  %8233 = load <8 x i1>, ptr %runnable.mask, align 1
  %8234 = xor <8 x i1> %8232, splat (i1 true)
  %8235 = and <8 x i1> %8233, %8234
  store <8 x i1> %8235, ptr %runnable.mask, align 1
  %.splatinsert1822 = insertelement <8 x i1> poison, i1 %8223, i64 0
  %.splat1823 = shufflevector <8 x i1> %.splatinsert1822, <8 x i1> poison, <8 x i32> zeroinitializer
  %8236 = select <8 x i1> %.splat1823, <8 x i1> %8218, <8 x i1> zeroinitializer
  %8237 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8238 = extractelement <8 x i32> %8237, i32 %8203
  %8239 = select i1 %8223, i32 %8238, i32 %8199
  store i32 %8239, ptr %current.token, align 4
  %.splatinsert1824 = insertelement <8 x i1> poison, i1 %8213, i64 0
  %.splat1825 = shufflevector <8 x i1> %.splatinsert1824, <8 x i1> poison, <8 x i32> zeroinitializer
  %8240 = select <8 x i1> %.splat1825, <8 x i1> %8236, <8 x i1> %convergence.cascade.flow1816
  %8241 = add i32 %convergence.cascade.depth1817, 1
  %8242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8240)
  %8243 = icmp ult i32 %8241, 8
  %8244 = and i1 %8242, %8243
  %8245 = and i1 %8213, %8244
  %convergence.parent.token1826 = load i32, ptr %current.token, align 4
  %convergence.parent.present1827 = icmp ne i32 %convergence.parent.token1826, 0
  %8246 = and i1 %8245, %convergence.parent.present1827
  br i1 %8246, label %convergence.cascade1812, label %convergence.cascade.exit1813

convergence.cascade.exit1813:                     ; preds = %convergence.cascade1812, %schedule.102
  %convergence.cascade.result1828 = phi <8 x i1> [ %1475, %schedule.102 ], [ %8240, %convergence.cascade1812 ]
  %8247 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1828)
  br i1 %8247, label %convergence.target.102.ready, label %scheduler.loop

convergence.target.102.ready:                     ; preds = %convergence.cascade.exit1813
  %8248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1828)
  %8249 = bitcast <8 x i1> %convergence.cascade.result1828 to i8
  %8250 = call i8 @llvm.cttz.i8(i8 %8249, i1 false)
  %8251 = zext i8 %8250 to i32
  %8252 = select i1 %8248, i32 %8251, i32 0
  %.spill.load1829 = load volatile <8 x float>, ptr %.spill159, align 32
  %.state1830 = load <8 x float>, ptr %.slot169, align 32
  %8253 = fadd <8 x float> %.spill.load1829, %.state1830
  %.spill.load1831 = load volatile <8 x float>, ptr %.spill160, align 32
  %.state1832 = load <8 x float>, ptr %.slot171, align 32
  %8254 = fadd <8 x float> %.spill.load1831, %.state1832
  %.spill.load1833 = load volatile <8 x float>, ptr %.spill161, align 32
  %.state1834 = load <8 x float>, ptr %.slot173, align 32
  %8255 = fadd <8 x float> %.spill.load1833, %.state1834
  %.spill.load1835 = load volatile <8 x float>, ptr %.spill162, align 32
  %.state1836 = load <8 x float>, ptr %.slot175, align 32
  %8256 = fadd <8 x float> %.spill.load1835, %.state1836
  %.spill.load1837 = load volatile <8 x float>, ptr %.spill163, align 32
  %.state1838 = load <8 x float>, ptr %.slot177, align 32
  %8257 = fadd <8 x float> %.spill.load1837, %.state1838
  %.spill.load1839 = load volatile <8 x float>, ptr %.spill164, align 32
  %.state1840 = load <8 x float>, ptr %.slot179, align 32
  %8258 = fadd <8 x float> %.spill.load1839, %.state1840
  %.spill.load1841 = load volatile <8 x float>, ptr %.spill165, align 32
  %.state1842 = load <8 x float>, ptr %.slot181, align 32
  %8259 = fadd <8 x float> %.spill.load1841, %.state1842
  %.spill.load1843 = load volatile <8 x float>, ptr %.spill166, align 32
  %.state1844 = load <8 x float>, ptr %.slot183, align 32
  %8260 = fadd <8 x float> %.spill.load1843, %.state1844
  %.state1845 = load <8 x i64>, ptr %.slot37, align 64
  %8261 = add <8 x i64> %.state1845, splat (i64 1)
  %.spill.load1846 = load volatile <8 x float>, ptr %.spill140, align 32
  %.spill.load1847 = load volatile <8 x float>, ptr %.spill141, align 32
  %.spill.load1848 = load volatile <8 x float>, ptr %.spill157, align 32
  %.spill.load1849 = load volatile <8 x float>, ptr %.spill158, align 32
  %8262 = load <8 x i64>, ptr %.slot37, align 64
  %8263 = select <8 x i1> %convergence.cascade.result1828, <8 x i64> %8261, <8 x i64> %8262
  store <8 x i64> %8263, ptr %.slot37, align 64
  %8264 = load <8 x float>, ptr %.slot38, align 32
  %8265 = select <8 x i1> %convergence.cascade.result1828, <8 x float> %.spill.load1846, <8 x float> %8264
  store <8 x float> %8265, ptr %.slot38, align 32
  %8266 = load <8 x float>, ptr %.slot39, align 32
  %8267 = select <8 x i1> %convergence.cascade.result1828, <8 x float> %.spill.load1847, <8 x float> %8266
  store <8 x float> %8267, ptr %.slot39, align 32
  %8268 = load <8 x float>, ptr %.slot40, align 32
  %8269 = select <8 x i1> %convergence.cascade.result1828, <8 x float> %.spill.load1848, <8 x float> %8268
  store <8 x float> %8269, ptr %.slot40, align 32
  %8270 = load <8 x float>, ptr %.slot41, align 32
  %8271 = select <8 x i1> %convergence.cascade.result1828, <8 x float> %.spill.load1849, <8 x float> %8270
  store <8 x float> %8271, ptr %.slot41, align 32
  %8272 = load <8 x float>, ptr %.slot42, align 32
  %8273 = select <8 x i1> %convergence.cascade.result1828, <8 x float> %8253, <8 x float> %8272
  store <8 x float> %8273, ptr %.slot42, align 32
  %8274 = load <8 x float>, ptr %.slot43, align 32
  %8275 = select <8 x i1> %convergence.cascade.result1828, <8 x float> %8254, <8 x float> %8274
  store <8 x float> %8275, ptr %.slot43, align 32
  %8276 = load <8 x float>, ptr %.slot44, align 32
  %8277 = select <8 x i1> %convergence.cascade.result1828, <8 x float> %8255, <8 x float> %8276
  store <8 x float> %8277, ptr %.slot44, align 32
  %8278 = load <8 x float>, ptr %.slot45, align 32
  %8279 = select <8 x i1> %convergence.cascade.result1828, <8 x float> %8256, <8 x float> %8278
  store <8 x float> %8279, ptr %.slot45, align 32
  %8280 = load <8 x float>, ptr %.slot46, align 32
  %8281 = select <8 x i1> %convergence.cascade.result1828, <8 x float> %8257, <8 x float> %8280
  store <8 x float> %8281, ptr %.slot46, align 32
  %8282 = load <8 x float>, ptr %.slot47, align 32
  %8283 = select <8 x i1> %convergence.cascade.result1828, <8 x float> %8258, <8 x float> %8282
  store <8 x float> %8283, ptr %.slot47, align 32
  %8284 = load <8 x float>, ptr %.slot48, align 32
  %8285 = select <8 x i1> %convergence.cascade.result1828, <8 x float> %8259, <8 x float> %8284
  store <8 x float> %8285, ptr %.slot48, align 32
  %8286 = load <8 x float>, ptr %.slot49, align 32
  %8287 = select <8 x i1> %convergence.cascade.result1828, <8 x float> %8260, <8 x float> %8286
  store <8 x float> %8287, ptr %.slot49, align 32
  store <8 x i1> %convergence.cascade.result1828, ptr %current.mask, align 1
  %8288 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1828)
  br i1 %8288, label %schedule.11, label %scheduler.loop

convergence.cascade1850:                          ; preds = %convergence.cascade1850, %schedule.103
  %convergence.cascade.flow1854 = phi <8 x i1> [ %1476, %schedule.103 ], [ %8331, %convergence.cascade1850 ]
  %convergence.cascade.depth1855 = phi i32 [ 0, %schedule.103 ], [ %8332, %convergence.cascade1850 ]
  %8289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1854)
  %8290 = load i32, ptr %current.token, align 4
  %8291 = icmp ne i32 %8290, 0
  %8292 = and i1 %8289, %8291
  %8293 = sub i32 %8290, 1
  %8294 = select i1 %8292, i32 %8293, i32 0
  %8295 = load i8, ptr %frame.active, align 1
  %8296 = trunc i32 %8294 to i8
  %8297 = shl i8 1, %8296
  %8298 = and i8 %8295, %8297
  %8299 = icmp ne i8 %8298, 0
  %8300 = load <8 x i32>, ptr %frame.static.id, align 32
  %8301 = extractelement <8 x i32> %8300, i32 %8294
  %convergence.target.pointer1856 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %8301
  %convergence.dynamic.target1857 = load i32, ptr %convergence.target.pointer1856, align 4
  %8302 = icmp eq i32 %convergence.dynamic.target1857, 103
  %8303 = and i1 %8299, %8302
  %8304 = and i1 %8292, %8303
  %8305 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8294
  %8306 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8294
  %8307 = load <8 x i1>, ptr %8305, align 1
  %8308 = load <8 x i1>, ptr %8306, align 1
  %8309 = or <8 x i1> %8308, %convergence.cascade.flow1854
  %8310 = load <8 x i1>, ptr %live.mask, align 1
  %8311 = and <8 x i1> %8307, %8310
  %8312 = icmp eq <8 x i1> %8309, %8311
  %8313 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8312)
  %8314 = and i1 %8304, %8313
  %8315 = select i1 %8314, <8 x i1> zeroinitializer, <8 x i1> %8309
  %8316 = select i1 %8304, <8 x i1> %8315, <8 x i1> %8308
  store <8 x i1> %8316, ptr %8306, align 1
  %8317 = select i1 %8314, <8 x i1> zeroinitializer, <8 x i1> %8307
  store <8 x i1> %8317, ptr %8305, align 1
  %8318 = trunc i32 %8294 to i8
  %8319 = shl i8 1, %8318
  %8320 = xor i8 %8319, -1
  %8321 = and i8 %8295, %8320
  %8322 = select i1 %8314, i8 %8321, i8 %8295
  store i8 %8322, ptr %frame.active, align 1
  %.splatinsert1858 = insertelement <8 x i1> poison, i1 %8304, i64 0
  %.splat1859 = shufflevector <8 x i1> %.splatinsert1858, <8 x i1> poison, <8 x i32> zeroinitializer
  %8323 = and <8 x i1> %convergence.cascade.flow1854, %.splat1859
  %8324 = load <8 x i1>, ptr %runnable.mask, align 1
  %8325 = xor <8 x i1> %8323, splat (i1 true)
  %8326 = and <8 x i1> %8324, %8325
  store <8 x i1> %8326, ptr %runnable.mask, align 1
  %.splatinsert1860 = insertelement <8 x i1> poison, i1 %8314, i64 0
  %.splat1861 = shufflevector <8 x i1> %.splatinsert1860, <8 x i1> poison, <8 x i32> zeroinitializer
  %8327 = select <8 x i1> %.splat1861, <8 x i1> %8309, <8 x i1> zeroinitializer
  %8328 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8329 = extractelement <8 x i32> %8328, i32 %8294
  %8330 = select i1 %8314, i32 %8329, i32 %8290
  store i32 %8330, ptr %current.token, align 4
  %.splatinsert1862 = insertelement <8 x i1> poison, i1 %8304, i64 0
  %.splat1863 = shufflevector <8 x i1> %.splatinsert1862, <8 x i1> poison, <8 x i32> zeroinitializer
  %8331 = select <8 x i1> %.splat1863, <8 x i1> %8327, <8 x i1> %convergence.cascade.flow1854
  %8332 = add i32 %convergence.cascade.depth1855, 1
  %8333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8331)
  %8334 = icmp ult i32 %8332, 8
  %8335 = and i1 %8333, %8334
  %8336 = and i1 %8304, %8335
  %convergence.parent.token1864 = load i32, ptr %current.token, align 4
  %convergence.parent.present1865 = icmp ne i32 %convergence.parent.token1864, 0
  %8337 = and i1 %8336, %convergence.parent.present1865
  br i1 %8337, label %convergence.cascade1850, label %convergence.cascade.exit1851

convergence.cascade.exit1851:                     ; preds = %convergence.cascade1850, %schedule.103
  %convergence.cascade.result1866 = phi <8 x i1> [ %1476, %schedule.103 ], [ %8331, %convergence.cascade1850 ]
  %8338 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1866)
  br i1 %8338, label %convergence.target.103.ready, label %scheduler.loop

convergence.target.103.ready:                     ; preds = %convergence.cascade.exit1851
  %8339 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1866)
  %8340 = bitcast <8 x i1> %convergence.cascade.result1866 to i8
  %8341 = call i8 @llvm.cttz.i8(i8 %8340, i1 false)
  %8342 = zext i8 %8341 to i32
  %8343 = select i1 %8339, i32 %8342, i32 0
  %.state1867 = load <8 x float>, ptr %.slot42, align 32
  %.state1868 = load <8 x float>, ptr %.slot40, align 32
  %8344 = fdiv <8 x float> %.state1867, %.state1868
  %.state1869 = load <8 x float>, ptr %.slot43, align 32
  %.state1870 = load <8 x float>, ptr %.slot40, align 32
  %8345 = fdiv <8 x float> %.state1869, %.state1870
  %.state1871 = load <8 x float>, ptr %.slot44, align 32
  %.state1872 = load <8 x float>, ptr %.slot40, align 32
  %8346 = fdiv <8 x float> %.state1871, %.state1872
  %.state1873 = load <8 x float>, ptr %.slot45, align 32
  %.state1874 = load <8 x float>, ptr %.slot40, align 32
  %8347 = fdiv <8 x float> %.state1873, %.state1874
  %.state1875 = load <8 x float>, ptr %.slot46, align 32
  %.state1876 = load <8 x float>, ptr %.slot41, align 32
  %8348 = fdiv <8 x float> %.state1875, %.state1876
  %8349 = load volatile <8 x float>, ptr %.spill184, align 32
  %8350 = select <8 x i1> %convergence.cascade.result1866, <8 x float> %8348, <8 x float> %8349
  store volatile <8 x float> %8350, ptr %.spill184, align 32
  %.state1877 = load <8 x float>, ptr %.slot47, align 32
  %.state1878 = load <8 x float>, ptr %.slot41, align 32
  %8351 = fdiv <8 x float> %.state1877, %.state1878
  %8352 = load volatile <8 x float>, ptr %.spill185, align 32
  %8353 = select <8 x i1> %convergence.cascade.result1866, <8 x float> %8351, <8 x float> %8352
  store volatile <8 x float> %8353, ptr %.spill185, align 32
  %.state1879 = load <8 x float>, ptr %.slot48, align 32
  %.state1880 = load <8 x float>, ptr %.slot41, align 32
  %8354 = fdiv <8 x float> %.state1879, %.state1880
  %8355 = load volatile <8 x float>, ptr %.spill186, align 32
  %8356 = select <8 x i1> %convergence.cascade.result1866, <8 x float> %8354, <8 x float> %8355
  store volatile <8 x float> %8356, ptr %.spill186, align 32
  %.state1881 = load <8 x float>, ptr %.slot49, align 32
  %.state1882 = load <8 x float>, ptr %.slot41, align 32
  %8357 = fdiv <8 x float> %.state1881, %.state1882
  %8358 = load volatile <8 x float>, ptr %.spill187, align 32
  %8359 = select <8 x i1> %convergence.cascade.result1866, <8 x float> %8357, <8 x float> %8358
  store volatile <8 x float> %8359, ptr %.spill187, align 32
  %.spill.load1883 = load volatile <8 x i64>, ptr %.spill14, align 64
  %8360 = mul <8 x i64> %.spill.load1883, splat (i64 4)
  %.spill.load1884 = load i64, ptr %.spill10, align 4
  %.splatinsert1885 = insertelement <8 x i64> poison, i64 %.spill.load1884, i64 0
  %.splat1886 = shufflevector <8 x i64> %.splatinsert1885, <8 x i64> poison, <8 x i32> zeroinitializer
  %8361 = add <8 x i64> %8360, %.splat1886
  %8362 = extractvalue { ptr, i64 } %31, 0
  %8363 = mul <8 x i64> %8361, splat (i64 4)
  %8364 = getelementptr i8, ptr %8362, <8 x i64> %8363
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %8344, <8 x ptr> align 1 %8364, <8 x i1> %convergence.cascade.result1866)
  %.spill.load1887 = load i64, ptr %.spill16, align 4
  %.splatinsert1888 = insertelement <8 x i64> poison, i64 %.spill.load1887, i64 0
  %.splat1889 = shufflevector <8 x i64> %.splatinsert1888, <8 x i64> poison, <8 x i32> zeroinitializer
  %8365 = add <8 x i64> %8360, %.splat1889
  %8366 = extractvalue { ptr, i64 } %31, 0
  %8367 = mul <8 x i64> %8365, splat (i64 4)
  %8368 = getelementptr i8, ptr %8366, <8 x i64> %8367
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %8345, <8 x ptr> align 1 %8368, <8 x i1> %convergence.cascade.result1866)
  %.spill.load1890 = load i64, ptr %.spill18, align 4
  %.splatinsert1891 = insertelement <8 x i64> poison, i64 %.spill.load1890, i64 0
  %.splat1892 = shufflevector <8 x i64> %.splatinsert1891, <8 x i64> poison, <8 x i32> zeroinitializer
  %8369 = add <8 x i64> %8360, %.splat1892
  %8370 = extractvalue { ptr, i64 } %31, 0
  %8371 = mul <8 x i64> %8369, splat (i64 4)
  %8372 = getelementptr i8, ptr %8370, <8 x i64> %8371
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %8346, <8 x ptr> align 1 %8372, <8 x i1> %convergence.cascade.result1866)
  %.spill.load1893 = load i64, ptr %.spill20, align 4
  %.splatinsert1894 = insertelement <8 x i64> poison, i64 %.spill.load1893, i64 0
  %.splat1895 = shufflevector <8 x i64> %.splatinsert1894, <8 x i64> poison, <8 x i32> zeroinitializer
  %8373 = add <8 x i64> %8360, %.splat1895
  %8374 = extractvalue { ptr, i64 } %31, 0
  %8375 = mul <8 x i64> %8373, splat (i64 4)
  %8376 = getelementptr i8, ptr %8374, <8 x i64> %8375
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %8347, <8 x ptr> align 1 %8376, <8 x i1> %convergence.cascade.result1866)
  %.spill.load1896 = load volatile <8 x i64>, ptr %.spill25, align 64
  %8377 = mul <8 x i64> %.spill.load1896, splat (i64 4)
  %8378 = load volatile <8 x i64>, ptr %.spill188, align 64
  %8379 = select <8 x i1> %convergence.cascade.result1866, <8 x i64> %8377, <8 x i64> %8378
  store volatile <8 x i64> %8379, ptr %.spill188, align 64
  %.spill.load1897 = load i64, ptr %.spill10, align 4
  %.splatinsert1898 = insertelement <8 x i64> poison, i64 %.spill.load1897, i64 0
  %.splat1899 = shufflevector <8 x i64> %.splatinsert1898, <8 x i64> poison, <8 x i32> zeroinitializer
  %8380 = add <8 x i64> %8377, %.splat1899
  %8381 = load volatile <8 x i64>, ptr %.spill189, align 64
  %8382 = select <8 x i1> %convergence.cascade.result1866, <8 x i64> %8380, <8 x i64> %8381
  store volatile <8 x i64> %8382, ptr %.spill189, align 64
  %.spill.load1900 = load <8 x i1>, ptr %.spill26, align 1
  %8383 = and <8 x i1> %convergence.cascade.result1866, %.spill.load1900
  %8384 = xor <8 x i1> %.spill.load1900, splat (i1 true)
  %8385 = and <8 x i1> %convergence.cascade.result1866, %8384
  %8386 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8383)
  %8387 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8385)
  %8388 = and i1 %8386, %8387
  br i1 %8388, label %varying.divergent1901, label %varying.coherent1902

varying.divergent1901:                            ; preds = %convergence.target.103.ready
  %8389 = load i32, ptr %current.token, align 4
  %8390 = icmp ne i32 %8389, 0
  %8391 = sub i32 %8389, 1
  %8392 = select i1 %8390, i32 %8391, i32 0
  %8393 = load i8, ptr %frame.active, align 1
  %8394 = trunc i32 %8392 to i8
  %8395 = shl i8 1, %8394
  %8396 = and i8 %8393, %8395
  %8397 = icmp ne i8 %8396, 0
  %8398 = load <8 x i32>, ptr %frame.static.id, align 32
  %8399 = extractelement <8 x i32> %8398, i32 %8392
  %8400 = icmp eq i32 %8399, 42
  %8401 = and i1 %8397, %8400
  %8402 = and i1 %8390, %8401
  %8403 = xor i1 %8402, true
  %8404 = and i1 true, %8403
  %8405 = xor i8 %8393, -1
  %8406 = icmp ne i8 %8405, 0
  %8407 = xor i1 %8406, true
  %8408 = and i1 %8404, %8407
  br i1 %8408, label %convergence.overflow.trap1903, label %convergence.overflow.resume1904

varying.coherent1902:                             ; preds = %convergence.target.103.ready
  br i1 %8386, label %varying.coherent.true1907, label %varying.coherent.false1908

convergence.overflow.trap1903:                    ; preds = %varying.divergent1901
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1904:                  ; preds = %varying.divergent1901
  %8409 = call i8 @llvm.cttz.i8(i8 %8405, i1 false)
  %8410 = zext i8 %8409 to i32
  %8411 = select i1 %8406, i32 %8410, i32 0
  %8412 = trunc i32 %8411 to i8
  %8413 = shl i8 1, %8412
  %8414 = or i8 %8393, %8413
  %8415 = select i1 %8404, i8 %8414, i8 %8393
  store i8 %8415, ptr %frame.active, align 1
  %8416 = load <8 x i32>, ptr %frame.static.id, align 32
  %8417 = extractelement <8 x i32> %8416, i32 %8411
  %8418 = select i1 %8404, i32 42, i32 %8417
  %8419 = load <8 x i32>, ptr %frame.static.id, align 32
  %8420 = insertelement <8 x i32> %8419, i32 %8418, i32 %8411
  store <8 x i32> %8420, ptr %frame.static.id, align 32
  %8421 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8422 = extractelement <8 x i32> %8421, i32 %8411
  %8423 = select i1 %8404, i32 %8389, i32 %8422
  %8424 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8425 = insertelement <8 x i32> %8424, i32 %8423, i32 %8411
  store <8 x i32> %8425, ptr %frame.parent.token, align 32
  %8426 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8411
  %8427 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8411
  %8428 = load <8 x i1>, ptr %8426, align 1
  %8429 = load <8 x i1>, ptr %8427, align 1
  %8430 = select i1 %8404, <8 x i1> %convergence.cascade.result1866, <8 x i1> %8428
  store <8 x i1> %8430, ptr %8426, align 1
  %8431 = select i1 %8404, <8 x i1> zeroinitializer, <8 x i1> %8429
  store <8 x i1> %8431, ptr %8427, align 1
  %8432 = add i32 %8411, 1
  %8433 = select i1 %8402, i32 %8389, i32 %8432
  %8434 = select i1 true, i32 %8433, i32 %8389
  store i32 %8434, ptr %current.token, align 4
  %8435 = load i32, ptr %current.token, align 4
  %8436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8383)
  %8437 = load i32, ptr %ready.count, align 4
  %8438 = icmp uge i32 %8437, 8
  %8439 = and i1 %8436, %8438
  br i1 %8439, label %ready.overflow.trap1905, label %ready.overflow.resume1906

ready.overflow.trap1905:                          ; preds = %convergence.overflow.resume1904
  call void @llvm.trap()
  unreachable

ready.overflow.resume1906:                        ; preds = %convergence.overflow.resume1904
  %8440 = select i1 %8436, i32 %8437, i32 0
  %8441 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8440
  %8442 = load <8 x i1>, ptr %8441, align 1
  %8443 = select i1 %8436, <8 x i1> %8383, <8 x i1> %8442
  store <8 x i1> %8443, ptr %8441, align 1
  %8444 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8440
  %8445 = load i32, ptr %8444, align 4
  %8446 = select i1 %8436, i32 104, i32 %8445
  store i32 %8446, ptr %8444, align 4
  %8447 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8440
  %8448 = load i32, ptr %8447, align 4
  %8449 = select i1 %8436, i32 %8435, i32 %8448
  store i32 %8449, ptr %8447, align 4
  %8450 = add i32 %8437, 1
  %8451 = select i1 %8436, i32 %8450, i32 %8437
  store i32 %8451, ptr %ready.count, align 4
  %8452 = load <8 x i1>, ptr %runnable.mask, align 1
  %8453 = or <8 x i1> %8452, %8383
  store <8 x i1> %8453, ptr %runnable.mask, align 1
  store <8 x i1> %8385, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1907:                        ; preds = %varying.coherent1902
  store <8 x i1> %convergence.cascade.result1866, ptr %current.mask, align 1
  %8454 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1866)
  br i1 %8454, label %schedule.104, label %scheduler.loop

varying.coherent.false1908:                       ; preds = %varying.coherent1902
  store <8 x i1> %convergence.cascade.result1866, ptr %current.mask, align 1
  %8455 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1866)
  br i1 %8455, label %schedule.105, label %scheduler.loop

convergence.cascade1911:                          ; preds = %convergence.cascade1911, %schedule.105
  %convergence.cascade.flow1915 = phi <8 x i1> [ %1487, %schedule.105 ], [ %8498, %convergence.cascade1911 ]
  %convergence.cascade.depth1916 = phi i32 [ 0, %schedule.105 ], [ %8499, %convergence.cascade1911 ]
  %8456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1915)
  %8457 = load i32, ptr %current.token, align 4
  %8458 = icmp ne i32 %8457, 0
  %8459 = and i1 %8456, %8458
  %8460 = sub i32 %8457, 1
  %8461 = select i1 %8459, i32 %8460, i32 0
  %8462 = load i8, ptr %frame.active, align 1
  %8463 = trunc i32 %8461 to i8
  %8464 = shl i8 1, %8463
  %8465 = and i8 %8462, %8464
  %8466 = icmp ne i8 %8465, 0
  %8467 = load <8 x i32>, ptr %frame.static.id, align 32
  %8468 = extractelement <8 x i32> %8467, i32 %8461
  %convergence.target.pointer1917 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %8468
  %convergence.dynamic.target1918 = load i32, ptr %convergence.target.pointer1917, align 4
  %8469 = icmp eq i32 %convergence.dynamic.target1918, 105
  %8470 = and i1 %8466, %8469
  %8471 = and i1 %8459, %8470
  %8472 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8461
  %8473 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8461
  %8474 = load <8 x i1>, ptr %8472, align 1
  %8475 = load <8 x i1>, ptr %8473, align 1
  %8476 = or <8 x i1> %8475, %convergence.cascade.flow1915
  %8477 = load <8 x i1>, ptr %live.mask, align 1
  %8478 = and <8 x i1> %8474, %8477
  %8479 = icmp eq <8 x i1> %8476, %8478
  %8480 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8479)
  %8481 = and i1 %8471, %8480
  %8482 = select i1 %8481, <8 x i1> zeroinitializer, <8 x i1> %8476
  %8483 = select i1 %8471, <8 x i1> %8482, <8 x i1> %8475
  store <8 x i1> %8483, ptr %8473, align 1
  %8484 = select i1 %8481, <8 x i1> zeroinitializer, <8 x i1> %8474
  store <8 x i1> %8484, ptr %8472, align 1
  %8485 = trunc i32 %8461 to i8
  %8486 = shl i8 1, %8485
  %8487 = xor i8 %8486, -1
  %8488 = and i8 %8462, %8487
  %8489 = select i1 %8481, i8 %8488, i8 %8462
  store i8 %8489, ptr %frame.active, align 1
  %.splatinsert1919 = insertelement <8 x i1> poison, i1 %8471, i64 0
  %.splat1920 = shufflevector <8 x i1> %.splatinsert1919, <8 x i1> poison, <8 x i32> zeroinitializer
  %8490 = and <8 x i1> %convergence.cascade.flow1915, %.splat1920
  %8491 = load <8 x i1>, ptr %runnable.mask, align 1
  %8492 = xor <8 x i1> %8490, splat (i1 true)
  %8493 = and <8 x i1> %8491, %8492
  store <8 x i1> %8493, ptr %runnable.mask, align 1
  %.splatinsert1921 = insertelement <8 x i1> poison, i1 %8481, i64 0
  %.splat1922 = shufflevector <8 x i1> %.splatinsert1921, <8 x i1> poison, <8 x i32> zeroinitializer
  %8494 = select <8 x i1> %.splat1922, <8 x i1> %8476, <8 x i1> zeroinitializer
  %8495 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8496 = extractelement <8 x i32> %8495, i32 %8461
  %8497 = select i1 %8481, i32 %8496, i32 %8457
  store i32 %8497, ptr %current.token, align 4
  %.splatinsert1923 = insertelement <8 x i1> poison, i1 %8471, i64 0
  %.splat1924 = shufflevector <8 x i1> %.splatinsert1923, <8 x i1> poison, <8 x i32> zeroinitializer
  %8498 = select <8 x i1> %.splat1924, <8 x i1> %8494, <8 x i1> %convergence.cascade.flow1915
  %8499 = add i32 %convergence.cascade.depth1916, 1
  %8500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8498)
  %8501 = icmp ult i32 %8499, 8
  %8502 = and i1 %8500, %8501
  %8503 = and i1 %8471, %8502
  %convergence.parent.token1925 = load i32, ptr %current.token, align 4
  %convergence.parent.present1926 = icmp ne i32 %convergence.parent.token1925, 0
  %8504 = and i1 %8503, %convergence.parent.present1926
  br i1 %8504, label %convergence.cascade1911, label %convergence.cascade.exit1912

convergence.cascade.exit1912:                     ; preds = %convergence.cascade1911, %schedule.105
  %convergence.cascade.result1927 = phi <8 x i1> [ %1487, %schedule.105 ], [ %8498, %convergence.cascade1911 ]
  %8505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1927)
  br i1 %8505, label %convergence.target.105.ready, label %scheduler.loop

convergence.target.105.ready:                     ; preds = %convergence.cascade.exit1912
  %8506 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1927)
  %8507 = bitcast <8 x i1> %convergence.cascade.result1927 to i8
  %8508 = call i8 @llvm.cttz.i8(i8 %8507, i1 false)
  %8509 = zext i8 %8508 to i32
  %8510 = select i1 %8506, i32 %8509, i32 0
  %.spill.load1928 = load volatile <8 x i64>, ptr %.spill188, align 64
  %.spill.load1929 = load i64, ptr %.spill16, align 4
  %.splatinsert1930 = insertelement <8 x i64> poison, i64 %.spill.load1929, i64 0
  %.splat1931 = shufflevector <8 x i64> %.splatinsert1930, <8 x i64> poison, <8 x i32> zeroinitializer
  %8511 = add <8 x i64> %.spill.load1928, %.splat1931
  %8512 = load volatile <8 x i64>, ptr %.spill190, align 64
  %8513 = select <8 x i1> %convergence.cascade.result1927, <8 x i64> %8511, <8 x i64> %8512
  store volatile <8 x i64> %8513, ptr %.spill190, align 64
  %.spill.load1932 = load <8 x i1>, ptr %.spill26, align 1
  %8514 = and <8 x i1> %convergence.cascade.result1927, %.spill.load1932
  %8515 = xor <8 x i1> %.spill.load1932, splat (i1 true)
  %8516 = and <8 x i1> %convergence.cascade.result1927, %8515
  %8517 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8514)
  %8518 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8516)
  %8519 = and i1 %8517, %8518
  br i1 %8519, label %varying.divergent1933, label %varying.coherent1934

varying.divergent1933:                            ; preds = %convergence.target.105.ready
  %8520 = load i32, ptr %current.token, align 4
  %8521 = icmp ne i32 %8520, 0
  %8522 = sub i32 %8520, 1
  %8523 = select i1 %8521, i32 %8522, i32 0
  %8524 = load i8, ptr %frame.active, align 1
  %8525 = trunc i32 %8523 to i8
  %8526 = shl i8 1, %8525
  %8527 = and i8 %8524, %8526
  %8528 = icmp ne i8 %8527, 0
  %8529 = load <8 x i32>, ptr %frame.static.id, align 32
  %8530 = extractelement <8 x i32> %8529, i32 %8523
  %8531 = icmp eq i32 %8530, 43
  %8532 = and i1 %8528, %8531
  %8533 = and i1 %8521, %8532
  %8534 = xor i1 %8533, true
  %8535 = and i1 true, %8534
  %8536 = xor i8 %8524, -1
  %8537 = icmp ne i8 %8536, 0
  %8538 = xor i1 %8537, true
  %8539 = and i1 %8535, %8538
  br i1 %8539, label %convergence.overflow.trap1935, label %convergence.overflow.resume1936

varying.coherent1934:                             ; preds = %convergence.target.105.ready
  br i1 %8517, label %varying.coherent.true1939, label %varying.coherent.false1940

convergence.overflow.trap1935:                    ; preds = %varying.divergent1933
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1936:                  ; preds = %varying.divergent1933
  %8540 = call i8 @llvm.cttz.i8(i8 %8536, i1 false)
  %8541 = zext i8 %8540 to i32
  %8542 = select i1 %8537, i32 %8541, i32 0
  %8543 = trunc i32 %8542 to i8
  %8544 = shl i8 1, %8543
  %8545 = or i8 %8524, %8544
  %8546 = select i1 %8535, i8 %8545, i8 %8524
  store i8 %8546, ptr %frame.active, align 1
  %8547 = load <8 x i32>, ptr %frame.static.id, align 32
  %8548 = extractelement <8 x i32> %8547, i32 %8542
  %8549 = select i1 %8535, i32 43, i32 %8548
  %8550 = load <8 x i32>, ptr %frame.static.id, align 32
  %8551 = insertelement <8 x i32> %8550, i32 %8549, i32 %8542
  store <8 x i32> %8551, ptr %frame.static.id, align 32
  %8552 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8553 = extractelement <8 x i32> %8552, i32 %8542
  %8554 = select i1 %8535, i32 %8520, i32 %8553
  %8555 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8556 = insertelement <8 x i32> %8555, i32 %8554, i32 %8542
  store <8 x i32> %8556, ptr %frame.parent.token, align 32
  %8557 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8542
  %8558 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8542
  %8559 = load <8 x i1>, ptr %8557, align 1
  %8560 = load <8 x i1>, ptr %8558, align 1
  %8561 = select i1 %8535, <8 x i1> %convergence.cascade.result1927, <8 x i1> %8559
  store <8 x i1> %8561, ptr %8557, align 1
  %8562 = select i1 %8535, <8 x i1> zeroinitializer, <8 x i1> %8560
  store <8 x i1> %8562, ptr %8558, align 1
  %8563 = add i32 %8542, 1
  %8564 = select i1 %8533, i32 %8520, i32 %8563
  %8565 = select i1 true, i32 %8564, i32 %8520
  store i32 %8565, ptr %current.token, align 4
  %8566 = load i32, ptr %current.token, align 4
  %8567 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8514)
  %8568 = load i32, ptr %ready.count, align 4
  %8569 = icmp uge i32 %8568, 8
  %8570 = and i1 %8567, %8569
  br i1 %8570, label %ready.overflow.trap1937, label %ready.overflow.resume1938

ready.overflow.trap1937:                          ; preds = %convergence.overflow.resume1936
  call void @llvm.trap()
  unreachable

ready.overflow.resume1938:                        ; preds = %convergence.overflow.resume1936
  %8571 = select i1 %8567, i32 %8568, i32 0
  %8572 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8571
  %8573 = load <8 x i1>, ptr %8572, align 1
  %8574 = select i1 %8567, <8 x i1> %8514, <8 x i1> %8573
  store <8 x i1> %8574, ptr %8572, align 1
  %8575 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8571
  %8576 = load i32, ptr %8575, align 4
  %8577 = select i1 %8567, i32 106, i32 %8576
  store i32 %8577, ptr %8575, align 4
  %8578 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8571
  %8579 = load i32, ptr %8578, align 4
  %8580 = select i1 %8567, i32 %8566, i32 %8579
  store i32 %8580, ptr %8578, align 4
  %8581 = add i32 %8568, 1
  %8582 = select i1 %8567, i32 %8581, i32 %8568
  store i32 %8582, ptr %ready.count, align 4
  %8583 = load <8 x i1>, ptr %runnable.mask, align 1
  %8584 = or <8 x i1> %8583, %8514
  store <8 x i1> %8584, ptr %runnable.mask, align 1
  store <8 x i1> %8516, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1939:                        ; preds = %varying.coherent1934
  store <8 x i1> %convergence.cascade.result1927, ptr %current.mask, align 1
  %8585 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1927)
  br i1 %8585, label %schedule.106, label %scheduler.loop

varying.coherent.false1940:                       ; preds = %varying.coherent1934
  store <8 x i1> %convergence.cascade.result1927, ptr %current.mask, align 1
  %8586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1927)
  br i1 %8586, label %schedule.107, label %scheduler.loop

convergence.cascade1943:                          ; preds = %convergence.cascade1943, %schedule.107
  %convergence.cascade.flow1947 = phi <8 x i1> [ %1498, %schedule.107 ], [ %8629, %convergence.cascade1943 ]
  %convergence.cascade.depth1948 = phi i32 [ 0, %schedule.107 ], [ %8630, %convergence.cascade1943 ]
  %8587 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1947)
  %8588 = load i32, ptr %current.token, align 4
  %8589 = icmp ne i32 %8588, 0
  %8590 = and i1 %8587, %8589
  %8591 = sub i32 %8588, 1
  %8592 = select i1 %8590, i32 %8591, i32 0
  %8593 = load i8, ptr %frame.active, align 1
  %8594 = trunc i32 %8592 to i8
  %8595 = shl i8 1, %8594
  %8596 = and i8 %8593, %8595
  %8597 = icmp ne i8 %8596, 0
  %8598 = load <8 x i32>, ptr %frame.static.id, align 32
  %8599 = extractelement <8 x i32> %8598, i32 %8592
  %convergence.target.pointer1949 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %8599
  %convergence.dynamic.target1950 = load i32, ptr %convergence.target.pointer1949, align 4
  %8600 = icmp eq i32 %convergence.dynamic.target1950, 107
  %8601 = and i1 %8597, %8600
  %8602 = and i1 %8590, %8601
  %8603 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8592
  %8604 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8592
  %8605 = load <8 x i1>, ptr %8603, align 1
  %8606 = load <8 x i1>, ptr %8604, align 1
  %8607 = or <8 x i1> %8606, %convergence.cascade.flow1947
  %8608 = load <8 x i1>, ptr %live.mask, align 1
  %8609 = and <8 x i1> %8605, %8608
  %8610 = icmp eq <8 x i1> %8607, %8609
  %8611 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8610)
  %8612 = and i1 %8602, %8611
  %8613 = select i1 %8612, <8 x i1> zeroinitializer, <8 x i1> %8607
  %8614 = select i1 %8602, <8 x i1> %8613, <8 x i1> %8606
  store <8 x i1> %8614, ptr %8604, align 1
  %8615 = select i1 %8612, <8 x i1> zeroinitializer, <8 x i1> %8605
  store <8 x i1> %8615, ptr %8603, align 1
  %8616 = trunc i32 %8592 to i8
  %8617 = shl i8 1, %8616
  %8618 = xor i8 %8617, -1
  %8619 = and i8 %8593, %8618
  %8620 = select i1 %8612, i8 %8619, i8 %8593
  store i8 %8620, ptr %frame.active, align 1
  %.splatinsert1951 = insertelement <8 x i1> poison, i1 %8602, i64 0
  %.splat1952 = shufflevector <8 x i1> %.splatinsert1951, <8 x i1> poison, <8 x i32> zeroinitializer
  %8621 = and <8 x i1> %convergence.cascade.flow1947, %.splat1952
  %8622 = load <8 x i1>, ptr %runnable.mask, align 1
  %8623 = xor <8 x i1> %8621, splat (i1 true)
  %8624 = and <8 x i1> %8622, %8623
  store <8 x i1> %8624, ptr %runnable.mask, align 1
  %.splatinsert1953 = insertelement <8 x i1> poison, i1 %8612, i64 0
  %.splat1954 = shufflevector <8 x i1> %.splatinsert1953, <8 x i1> poison, <8 x i32> zeroinitializer
  %8625 = select <8 x i1> %.splat1954, <8 x i1> %8607, <8 x i1> zeroinitializer
  %8626 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8627 = extractelement <8 x i32> %8626, i32 %8592
  %8628 = select i1 %8612, i32 %8627, i32 %8588
  store i32 %8628, ptr %current.token, align 4
  %.splatinsert1955 = insertelement <8 x i1> poison, i1 %8602, i64 0
  %.splat1956 = shufflevector <8 x i1> %.splatinsert1955, <8 x i1> poison, <8 x i32> zeroinitializer
  %8629 = select <8 x i1> %.splat1956, <8 x i1> %8625, <8 x i1> %convergence.cascade.flow1947
  %8630 = add i32 %convergence.cascade.depth1948, 1
  %8631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8629)
  %8632 = icmp ult i32 %8630, 8
  %8633 = and i1 %8631, %8632
  %8634 = and i1 %8602, %8633
  %convergence.parent.token1957 = load i32, ptr %current.token, align 4
  %convergence.parent.present1958 = icmp ne i32 %convergence.parent.token1957, 0
  %8635 = and i1 %8634, %convergence.parent.present1958
  br i1 %8635, label %convergence.cascade1943, label %convergence.cascade.exit1944

convergence.cascade.exit1944:                     ; preds = %convergence.cascade1943, %schedule.107
  %convergence.cascade.result1959 = phi <8 x i1> [ %1498, %schedule.107 ], [ %8629, %convergence.cascade1943 ]
  %8636 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1959)
  br i1 %8636, label %convergence.target.107.ready, label %scheduler.loop

convergence.target.107.ready:                     ; preds = %convergence.cascade.exit1944
  %8637 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1959)
  %8638 = bitcast <8 x i1> %convergence.cascade.result1959 to i8
  %8639 = call i8 @llvm.cttz.i8(i8 %8638, i1 false)
  %8640 = zext i8 %8639 to i32
  %8641 = select i1 %8637, i32 %8640, i32 0
  %.spill.load1960 = load volatile <8 x i64>, ptr %.spill188, align 64
  %.spill.load1961 = load i64, ptr %.spill18, align 4
  %.splatinsert1962 = insertelement <8 x i64> poison, i64 %.spill.load1961, i64 0
  %.splat1963 = shufflevector <8 x i64> %.splatinsert1962, <8 x i64> poison, <8 x i32> zeroinitializer
  %8642 = add <8 x i64> %.spill.load1960, %.splat1963
  %8643 = load volatile <8 x i64>, ptr %.spill191, align 64
  %8644 = select <8 x i1> %convergence.cascade.result1959, <8 x i64> %8642, <8 x i64> %8643
  store volatile <8 x i64> %8644, ptr %.spill191, align 64
  %.spill.load1964 = load <8 x i1>, ptr %.spill26, align 1
  %8645 = and <8 x i1> %convergence.cascade.result1959, %.spill.load1964
  %8646 = xor <8 x i1> %.spill.load1964, splat (i1 true)
  %8647 = and <8 x i1> %convergence.cascade.result1959, %8646
  %8648 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8645)
  %8649 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8647)
  %8650 = and i1 %8648, %8649
  br i1 %8650, label %varying.divergent1965, label %varying.coherent1966

varying.divergent1965:                            ; preds = %convergence.target.107.ready
  %8651 = load i32, ptr %current.token, align 4
  %8652 = icmp ne i32 %8651, 0
  %8653 = sub i32 %8651, 1
  %8654 = select i1 %8652, i32 %8653, i32 0
  %8655 = load i8, ptr %frame.active, align 1
  %8656 = trunc i32 %8654 to i8
  %8657 = shl i8 1, %8656
  %8658 = and i8 %8655, %8657
  %8659 = icmp ne i8 %8658, 0
  %8660 = load <8 x i32>, ptr %frame.static.id, align 32
  %8661 = extractelement <8 x i32> %8660, i32 %8654
  %8662 = icmp eq i32 %8661, 44
  %8663 = and i1 %8659, %8662
  %8664 = and i1 %8652, %8663
  %8665 = xor i1 %8664, true
  %8666 = and i1 true, %8665
  %8667 = xor i8 %8655, -1
  %8668 = icmp ne i8 %8667, 0
  %8669 = xor i1 %8668, true
  %8670 = and i1 %8666, %8669
  br i1 %8670, label %convergence.overflow.trap1967, label %convergence.overflow.resume1968

varying.coherent1966:                             ; preds = %convergence.target.107.ready
  br i1 %8648, label %varying.coherent.true1971, label %varying.coherent.false1972

convergence.overflow.trap1967:                    ; preds = %varying.divergent1965
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1968:                  ; preds = %varying.divergent1965
  %8671 = call i8 @llvm.cttz.i8(i8 %8667, i1 false)
  %8672 = zext i8 %8671 to i32
  %8673 = select i1 %8668, i32 %8672, i32 0
  %8674 = trunc i32 %8673 to i8
  %8675 = shl i8 1, %8674
  %8676 = or i8 %8655, %8675
  %8677 = select i1 %8666, i8 %8676, i8 %8655
  store i8 %8677, ptr %frame.active, align 1
  %8678 = load <8 x i32>, ptr %frame.static.id, align 32
  %8679 = extractelement <8 x i32> %8678, i32 %8673
  %8680 = select i1 %8666, i32 44, i32 %8679
  %8681 = load <8 x i32>, ptr %frame.static.id, align 32
  %8682 = insertelement <8 x i32> %8681, i32 %8680, i32 %8673
  store <8 x i32> %8682, ptr %frame.static.id, align 32
  %8683 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8684 = extractelement <8 x i32> %8683, i32 %8673
  %8685 = select i1 %8666, i32 %8651, i32 %8684
  %8686 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8687 = insertelement <8 x i32> %8686, i32 %8685, i32 %8673
  store <8 x i32> %8687, ptr %frame.parent.token, align 32
  %8688 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8673
  %8689 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8673
  %8690 = load <8 x i1>, ptr %8688, align 1
  %8691 = load <8 x i1>, ptr %8689, align 1
  %8692 = select i1 %8666, <8 x i1> %convergence.cascade.result1959, <8 x i1> %8690
  store <8 x i1> %8692, ptr %8688, align 1
  %8693 = select i1 %8666, <8 x i1> zeroinitializer, <8 x i1> %8691
  store <8 x i1> %8693, ptr %8689, align 1
  %8694 = add i32 %8673, 1
  %8695 = select i1 %8664, i32 %8651, i32 %8694
  %8696 = select i1 true, i32 %8695, i32 %8651
  store i32 %8696, ptr %current.token, align 4
  %8697 = load i32, ptr %current.token, align 4
  %8698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8645)
  %8699 = load i32, ptr %ready.count, align 4
  %8700 = icmp uge i32 %8699, 8
  %8701 = and i1 %8698, %8700
  br i1 %8701, label %ready.overflow.trap1969, label %ready.overflow.resume1970

ready.overflow.trap1969:                          ; preds = %convergence.overflow.resume1968
  call void @llvm.trap()
  unreachable

ready.overflow.resume1970:                        ; preds = %convergence.overflow.resume1968
  %8702 = select i1 %8698, i32 %8699, i32 0
  %8703 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8702
  %8704 = load <8 x i1>, ptr %8703, align 1
  %8705 = select i1 %8698, <8 x i1> %8645, <8 x i1> %8704
  store <8 x i1> %8705, ptr %8703, align 1
  %8706 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8702
  %8707 = load i32, ptr %8706, align 4
  %8708 = select i1 %8698, i32 108, i32 %8707
  store i32 %8708, ptr %8706, align 4
  %8709 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8702
  %8710 = load i32, ptr %8709, align 4
  %8711 = select i1 %8698, i32 %8697, i32 %8710
  store i32 %8711, ptr %8709, align 4
  %8712 = add i32 %8699, 1
  %8713 = select i1 %8698, i32 %8712, i32 %8699
  store i32 %8713, ptr %ready.count, align 4
  %8714 = load <8 x i1>, ptr %runnable.mask, align 1
  %8715 = or <8 x i1> %8714, %8645
  store <8 x i1> %8715, ptr %runnable.mask, align 1
  store <8 x i1> %8647, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1971:                        ; preds = %varying.coherent1966
  store <8 x i1> %convergence.cascade.result1959, ptr %current.mask, align 1
  %8716 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1959)
  br i1 %8716, label %schedule.108, label %scheduler.loop

varying.coherent.false1972:                       ; preds = %varying.coherent1966
  store <8 x i1> %convergence.cascade.result1959, ptr %current.mask, align 1
  %8717 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1959)
  br i1 %8717, label %schedule.109, label %scheduler.loop

convergence.cascade1975:                          ; preds = %convergence.cascade1975, %schedule.109
  %convergence.cascade.flow1979 = phi <8 x i1> [ %1509, %schedule.109 ], [ %8760, %convergence.cascade1975 ]
  %convergence.cascade.depth1980 = phi i32 [ 0, %schedule.109 ], [ %8761, %convergence.cascade1975 ]
  %8718 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1979)
  %8719 = load i32, ptr %current.token, align 4
  %8720 = icmp ne i32 %8719, 0
  %8721 = and i1 %8718, %8720
  %8722 = sub i32 %8719, 1
  %8723 = select i1 %8721, i32 %8722, i32 0
  %8724 = load i8, ptr %frame.active, align 1
  %8725 = trunc i32 %8723 to i8
  %8726 = shl i8 1, %8725
  %8727 = and i8 %8724, %8726
  %8728 = icmp ne i8 %8727, 0
  %8729 = load <8 x i32>, ptr %frame.static.id, align 32
  %8730 = extractelement <8 x i32> %8729, i32 %8723
  %convergence.target.pointer1981 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %8730
  %convergence.dynamic.target1982 = load i32, ptr %convergence.target.pointer1981, align 4
  %8731 = icmp eq i32 %convergence.dynamic.target1982, 109
  %8732 = and i1 %8728, %8731
  %8733 = and i1 %8721, %8732
  %8734 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8723
  %8735 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8723
  %8736 = load <8 x i1>, ptr %8734, align 1
  %8737 = load <8 x i1>, ptr %8735, align 1
  %8738 = or <8 x i1> %8737, %convergence.cascade.flow1979
  %8739 = load <8 x i1>, ptr %live.mask, align 1
  %8740 = and <8 x i1> %8736, %8739
  %8741 = icmp eq <8 x i1> %8738, %8740
  %8742 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8741)
  %8743 = and i1 %8733, %8742
  %8744 = select i1 %8743, <8 x i1> zeroinitializer, <8 x i1> %8738
  %8745 = select i1 %8733, <8 x i1> %8744, <8 x i1> %8737
  store <8 x i1> %8745, ptr %8735, align 1
  %8746 = select i1 %8743, <8 x i1> zeroinitializer, <8 x i1> %8736
  store <8 x i1> %8746, ptr %8734, align 1
  %8747 = trunc i32 %8723 to i8
  %8748 = shl i8 1, %8747
  %8749 = xor i8 %8748, -1
  %8750 = and i8 %8724, %8749
  %8751 = select i1 %8743, i8 %8750, i8 %8724
  store i8 %8751, ptr %frame.active, align 1
  %.splatinsert1983 = insertelement <8 x i1> poison, i1 %8733, i64 0
  %.splat1984 = shufflevector <8 x i1> %.splatinsert1983, <8 x i1> poison, <8 x i32> zeroinitializer
  %8752 = and <8 x i1> %convergence.cascade.flow1979, %.splat1984
  %8753 = load <8 x i1>, ptr %runnable.mask, align 1
  %8754 = xor <8 x i1> %8752, splat (i1 true)
  %8755 = and <8 x i1> %8753, %8754
  store <8 x i1> %8755, ptr %runnable.mask, align 1
  %.splatinsert1985 = insertelement <8 x i1> poison, i1 %8743, i64 0
  %.splat1986 = shufflevector <8 x i1> %.splatinsert1985, <8 x i1> poison, <8 x i32> zeroinitializer
  %8756 = select <8 x i1> %.splat1986, <8 x i1> %8738, <8 x i1> zeroinitializer
  %8757 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8758 = extractelement <8 x i32> %8757, i32 %8723
  %8759 = select i1 %8743, i32 %8758, i32 %8719
  store i32 %8759, ptr %current.token, align 4
  %.splatinsert1987 = insertelement <8 x i1> poison, i1 %8733, i64 0
  %.splat1988 = shufflevector <8 x i1> %.splatinsert1987, <8 x i1> poison, <8 x i32> zeroinitializer
  %8760 = select <8 x i1> %.splat1988, <8 x i1> %8756, <8 x i1> %convergence.cascade.flow1979
  %8761 = add i32 %convergence.cascade.depth1980, 1
  %8762 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8760)
  %8763 = icmp ult i32 %8761, 8
  %8764 = and i1 %8762, %8763
  %8765 = and i1 %8733, %8764
  %convergence.parent.token1989 = load i32, ptr %current.token, align 4
  %convergence.parent.present1990 = icmp ne i32 %convergence.parent.token1989, 0
  %8766 = and i1 %8765, %convergence.parent.present1990
  br i1 %8766, label %convergence.cascade1975, label %convergence.cascade.exit1976

convergence.cascade.exit1976:                     ; preds = %convergence.cascade1975, %schedule.109
  %convergence.cascade.result1991 = phi <8 x i1> [ %1509, %schedule.109 ], [ %8760, %convergence.cascade1975 ]
  %8767 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1991)
  br i1 %8767, label %convergence.target.109.ready, label %scheduler.loop

convergence.target.109.ready:                     ; preds = %convergence.cascade.exit1976
  %8768 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1991)
  %8769 = bitcast <8 x i1> %convergence.cascade.result1991 to i8
  %8770 = call i8 @llvm.cttz.i8(i8 %8769, i1 false)
  %8771 = zext i8 %8770 to i32
  %8772 = select i1 %8768, i32 %8771, i32 0
  %.spill.load1992 = load volatile <8 x i64>, ptr %.spill188, align 64
  %.spill.load1993 = load i64, ptr %.spill20, align 4
  %.splatinsert1994 = insertelement <8 x i64> poison, i64 %.spill.load1993, i64 0
  %.splat1995 = shufflevector <8 x i64> %.splatinsert1994, <8 x i64> poison, <8 x i32> zeroinitializer
  %8773 = add <8 x i64> %.spill.load1992, %.splat1995
  %8774 = load volatile <8 x i64>, ptr %.spill192, align 64
  %8775 = select <8 x i1> %convergence.cascade.result1991, <8 x i64> %8773, <8 x i64> %8774
  store volatile <8 x i64> %8775, ptr %.spill192, align 64
  %.spill.load1996 = load <8 x i1>, ptr %.spill26, align 1
  %8776 = and <8 x i1> %convergence.cascade.result1991, %.spill.load1996
  %8777 = xor <8 x i1> %.spill.load1996, splat (i1 true)
  %8778 = and <8 x i1> %convergence.cascade.result1991, %8777
  %8779 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8776)
  %8780 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8778)
  %8781 = and i1 %8779, %8780
  br i1 %8781, label %varying.divergent1997, label %varying.coherent1998

varying.divergent1997:                            ; preds = %convergence.target.109.ready
  %8782 = load i32, ptr %current.token, align 4
  %8783 = icmp ne i32 %8782, 0
  %8784 = sub i32 %8782, 1
  %8785 = select i1 %8783, i32 %8784, i32 0
  %8786 = load i8, ptr %frame.active, align 1
  %8787 = trunc i32 %8785 to i8
  %8788 = shl i8 1, %8787
  %8789 = and i8 %8786, %8788
  %8790 = icmp ne i8 %8789, 0
  %8791 = load <8 x i32>, ptr %frame.static.id, align 32
  %8792 = extractelement <8 x i32> %8791, i32 %8785
  %8793 = icmp eq i32 %8792, 45
  %8794 = and i1 %8790, %8793
  %8795 = and i1 %8783, %8794
  %8796 = xor i1 %8795, true
  %8797 = and i1 true, %8796
  %8798 = xor i8 %8786, -1
  %8799 = icmp ne i8 %8798, 0
  %8800 = xor i1 %8799, true
  %8801 = and i1 %8797, %8800
  br i1 %8801, label %convergence.overflow.trap1999, label %convergence.overflow.resume2000

varying.coherent1998:                             ; preds = %convergence.target.109.ready
  br i1 %8779, label %varying.coherent.true2003, label %varying.coherent.false2004

convergence.overflow.trap1999:                    ; preds = %varying.divergent1997
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2000:                  ; preds = %varying.divergent1997
  %8802 = call i8 @llvm.cttz.i8(i8 %8798, i1 false)
  %8803 = zext i8 %8802 to i32
  %8804 = select i1 %8799, i32 %8803, i32 0
  %8805 = trunc i32 %8804 to i8
  %8806 = shl i8 1, %8805
  %8807 = or i8 %8786, %8806
  %8808 = select i1 %8797, i8 %8807, i8 %8786
  store i8 %8808, ptr %frame.active, align 1
  %8809 = load <8 x i32>, ptr %frame.static.id, align 32
  %8810 = extractelement <8 x i32> %8809, i32 %8804
  %8811 = select i1 %8797, i32 45, i32 %8810
  %8812 = load <8 x i32>, ptr %frame.static.id, align 32
  %8813 = insertelement <8 x i32> %8812, i32 %8811, i32 %8804
  store <8 x i32> %8813, ptr %frame.static.id, align 32
  %8814 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8815 = extractelement <8 x i32> %8814, i32 %8804
  %8816 = select i1 %8797, i32 %8782, i32 %8815
  %8817 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8818 = insertelement <8 x i32> %8817, i32 %8816, i32 %8804
  store <8 x i32> %8818, ptr %frame.parent.token, align 32
  %8819 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8804
  %8820 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8804
  %8821 = load <8 x i1>, ptr %8819, align 1
  %8822 = load <8 x i1>, ptr %8820, align 1
  %8823 = select i1 %8797, <8 x i1> %convergence.cascade.result1991, <8 x i1> %8821
  store <8 x i1> %8823, ptr %8819, align 1
  %8824 = select i1 %8797, <8 x i1> zeroinitializer, <8 x i1> %8822
  store <8 x i1> %8824, ptr %8820, align 1
  %8825 = add i32 %8804, 1
  %8826 = select i1 %8795, i32 %8782, i32 %8825
  %8827 = select i1 true, i32 %8826, i32 %8782
  store i32 %8827, ptr %current.token, align 4
  %8828 = load i32, ptr %current.token, align 4
  %8829 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8776)
  %8830 = load i32, ptr %ready.count, align 4
  %8831 = icmp uge i32 %8830, 8
  %8832 = and i1 %8829, %8831
  br i1 %8832, label %ready.overflow.trap2001, label %ready.overflow.resume2002

ready.overflow.trap2001:                          ; preds = %convergence.overflow.resume2000
  call void @llvm.trap()
  unreachable

ready.overflow.resume2002:                        ; preds = %convergence.overflow.resume2000
  %8833 = select i1 %8829, i32 %8830, i32 0
  %8834 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8833
  %8835 = load <8 x i1>, ptr %8834, align 1
  %8836 = select i1 %8829, <8 x i1> %8776, <8 x i1> %8835
  store <8 x i1> %8836, ptr %8834, align 1
  %8837 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8833
  %8838 = load i32, ptr %8837, align 4
  %8839 = select i1 %8829, i32 110, i32 %8838
  store i32 %8839, ptr %8837, align 4
  %8840 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8833
  %8841 = load i32, ptr %8840, align 4
  %8842 = select i1 %8829, i32 %8828, i32 %8841
  store i32 %8842, ptr %8840, align 4
  %8843 = add i32 %8830, 1
  %8844 = select i1 %8829, i32 %8843, i32 %8830
  store i32 %8844, ptr %ready.count, align 4
  %8845 = load <8 x i1>, ptr %runnable.mask, align 1
  %8846 = or <8 x i1> %8845, %8776
  store <8 x i1> %8846, ptr %runnable.mask, align 1
  store <8 x i1> %8778, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2003:                        ; preds = %varying.coherent1998
  store <8 x i1> %convergence.cascade.result1991, ptr %current.mask, align 1
  %8847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1991)
  br i1 %8847, label %schedule.110, label %scheduler.loop

varying.coherent.false2004:                       ; preds = %varying.coherent1998
  store <8 x i1> %convergence.cascade.result1991, ptr %current.mask, align 1
  %8848 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1991)
  br i1 %8848, label %schedule.111, label %scheduler.loop

convergence.cascade2007:                          ; preds = %convergence.cascade2007, %schedule.111
  %convergence.cascade.flow2011 = phi <8 x i1> [ %1520, %schedule.111 ], [ %8891, %convergence.cascade2007 ]
  %convergence.cascade.depth2012 = phi i32 [ 0, %schedule.111 ], [ %8892, %convergence.cascade2007 ]
  %8849 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2011)
  %8850 = load i32, ptr %current.token, align 4
  %8851 = icmp ne i32 %8850, 0
  %8852 = and i1 %8849, %8851
  %8853 = sub i32 %8850, 1
  %8854 = select i1 %8852, i32 %8853, i32 0
  %8855 = load i8, ptr %frame.active, align 1
  %8856 = trunc i32 %8854 to i8
  %8857 = shl i8 1, %8856
  %8858 = and i8 %8855, %8857
  %8859 = icmp ne i8 %8858, 0
  %8860 = load <8 x i32>, ptr %frame.static.id, align 32
  %8861 = extractelement <8 x i32> %8860, i32 %8854
  %convergence.target.pointer2013 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %8861
  %convergence.dynamic.target2014 = load i32, ptr %convergence.target.pointer2013, align 4
  %8862 = icmp eq i32 %convergence.dynamic.target2014, 111
  %8863 = and i1 %8859, %8862
  %8864 = and i1 %8852, %8863
  %8865 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8854
  %8866 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8854
  %8867 = load <8 x i1>, ptr %8865, align 1
  %8868 = load <8 x i1>, ptr %8866, align 1
  %8869 = or <8 x i1> %8868, %convergence.cascade.flow2011
  %8870 = load <8 x i1>, ptr %live.mask, align 1
  %8871 = and <8 x i1> %8867, %8870
  %8872 = icmp eq <8 x i1> %8869, %8871
  %8873 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8872)
  %8874 = and i1 %8864, %8873
  %8875 = select i1 %8874, <8 x i1> zeroinitializer, <8 x i1> %8869
  %8876 = select i1 %8864, <8 x i1> %8875, <8 x i1> %8868
  store <8 x i1> %8876, ptr %8866, align 1
  %8877 = select i1 %8874, <8 x i1> zeroinitializer, <8 x i1> %8867
  store <8 x i1> %8877, ptr %8865, align 1
  %8878 = trunc i32 %8854 to i8
  %8879 = shl i8 1, %8878
  %8880 = xor i8 %8879, -1
  %8881 = and i8 %8855, %8880
  %8882 = select i1 %8874, i8 %8881, i8 %8855
  store i8 %8882, ptr %frame.active, align 1
  %.splatinsert2015 = insertelement <8 x i1> poison, i1 %8864, i64 0
  %.splat2016 = shufflevector <8 x i1> %.splatinsert2015, <8 x i1> poison, <8 x i32> zeroinitializer
  %8883 = and <8 x i1> %convergence.cascade.flow2011, %.splat2016
  %8884 = load <8 x i1>, ptr %runnable.mask, align 1
  %8885 = xor <8 x i1> %8883, splat (i1 true)
  %8886 = and <8 x i1> %8884, %8885
  store <8 x i1> %8886, ptr %runnable.mask, align 1
  %.splatinsert2017 = insertelement <8 x i1> poison, i1 %8874, i64 0
  %.splat2018 = shufflevector <8 x i1> %.splatinsert2017, <8 x i1> poison, <8 x i32> zeroinitializer
  %8887 = select <8 x i1> %.splat2018, <8 x i1> %8869, <8 x i1> zeroinitializer
  %8888 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8889 = extractelement <8 x i32> %8888, i32 %8854
  %8890 = select i1 %8874, i32 %8889, i32 %8850
  store i32 %8890, ptr %current.token, align 4
  %.splatinsert2019 = insertelement <8 x i1> poison, i1 %8864, i64 0
  %.splat2020 = shufflevector <8 x i1> %.splatinsert2019, <8 x i1> poison, <8 x i32> zeroinitializer
  %8891 = select <8 x i1> %.splat2020, <8 x i1> %8887, <8 x i1> %convergence.cascade.flow2011
  %8892 = add i32 %convergence.cascade.depth2012, 1
  %8893 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8891)
  %8894 = icmp ult i32 %8892, 8
  %8895 = and i1 %8893, %8894
  %8896 = and i1 %8864, %8895
  %convergence.parent.token2021 = load i32, ptr %current.token, align 4
  %convergence.parent.present2022 = icmp ne i32 %convergence.parent.token2021, 0
  %8897 = and i1 %8896, %convergence.parent.present2022
  br i1 %8897, label %convergence.cascade2007, label %convergence.cascade.exit2008

convergence.cascade.exit2008:                     ; preds = %convergence.cascade2007, %schedule.111
  %convergence.cascade.result2023 = phi <8 x i1> [ %1520, %schedule.111 ], [ %8891, %convergence.cascade2007 ]
  %8898 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2023)
  br i1 %8898, label %convergence.target.111.ready, label %scheduler.loop

convergence.target.111.ready:                     ; preds = %convergence.cascade.exit2008
  %8899 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2023)
  %8900 = bitcast <8 x i1> %convergence.cascade.result2023 to i8
  %8901 = call i8 @llvm.cttz.i8(i8 %8900, i1 false)
  %8902 = zext i8 %8901 to i32
  %8903 = select i1 %8899, i32 %8902, i32 0
  %8904 = load <8 x i1>, ptr %live.mask, align 1
  %8905 = xor <8 x i1> %convergence.cascade.result2023, splat (i1 true)
  %8906 = and <8 x i1> %8904, %8905
  store <8 x i1> %8906, ptr %live.mask, align 1
  %8907 = load <8 x i1>, ptr %runnable.mask, align 1
  %8908 = xor <8 x i1> %convergence.cascade.result2023, splat (i1 true)
  %8909 = and <8 x i1> %8907, %8908
  store <8 x i1> %8909, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.111.ready
  %8910 = load i8, ptr %frame.active, align 1
  %8911 = and i8 %8910, 1
  %8912 = icmp ne i8 %8911, 0
  %8913 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %8914 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %8915 = load <8 x i1>, ptr %8913, align 1
  %8916 = load <8 x i1>, ptr %8914, align 1
  %8917 = and <8 x i1> %8915, %8906
  %8918 = icmp eq <8 x i1> %8916, %8917
  %8919 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8918)
  %8920 = and i1 %8912, %8919
  %.splatinsert2024 = insertelement <8 x i1> poison, i1 %8920, i64 0
  %.splat2025 = shufflevector <8 x i1> %.splatinsert2024, <8 x i1> poison, <8 x i32> zeroinitializer
  %8921 = select <8 x i1> %.splat2025, <8 x i1> %8916, <8 x i1> zeroinitializer
  %8922 = select i1 %8920, <8 x i1> zeroinitializer, <8 x i1> %8917
  store <8 x i1> %8922, ptr %8913, align 1
  %8923 = select i1 %8920, <8 x i1> zeroinitializer, <8 x i1> %8916
  store <8 x i1> %8923, ptr %8914, align 1
  %8924 = and i8 %8910, -2
  %8925 = select i1 %8920, i8 %8924, i8 %8910
  store i8 %8925, ptr %frame.active, align 1
  %8926 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8927 = extractelement <8 x i32> %8926, i32 0
  %8928 = load <8 x i32>, ptr %frame.static.id, align 32
  %8929 = extractelement <8 x i32> %8928, i32 0
  %convergence.target.pointer2026 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %8929
  %convergence.dynamic.target2027 = load i32, ptr %convergence.target.pointer2026, align 4
  %8930 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8921)
  %8931 = load i32, ptr %ready.count, align 4
  %8932 = icmp uge i32 %8931, 8
  %8933 = and i1 %8930, %8932
  br i1 %8933, label %ready.overflow.trap2028, label %ready.overflow.resume2029

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume2071, %convergence.target.111.ready
  br label %scheduler.loop

ready.overflow.trap2028:                          ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume2029:                        ; preds = %return.frame.cleanup
  %8934 = select i1 %8930, i32 %8931, i32 0
  %8935 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8934
  %8936 = load <8 x i1>, ptr %8935, align 1
  %8937 = select i1 %8930, <8 x i1> %8921, <8 x i1> %8936
  store <8 x i1> %8937, ptr %8935, align 1
  %8938 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8934
  %8939 = load i32, ptr %8938, align 4
  %8940 = select i1 %8930, i32 %convergence.dynamic.target2027, i32 %8939
  store i32 %8940, ptr %8938, align 4
  %8941 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8934
  %8942 = load i32, ptr %8941, align 4
  %8943 = select i1 %8930, i32 %8927, i32 %8942
  store i32 %8943, ptr %8941, align 4
  %8944 = add i32 %8931, 1
  %8945 = select i1 %8930, i32 %8944, i32 %8931
  store i32 %8945, ptr %ready.count, align 4
  %8946 = load <8 x i1>, ptr %runnable.mask, align 1
  %8947 = or <8 x i1> %8946, %8921
  store <8 x i1> %8947, ptr %runnable.mask, align 1
  %8948 = load i8, ptr %frame.active, align 1
  %8949 = and i8 %8948, 2
  %8950 = icmp ne i8 %8949, 0
  %8951 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %8952 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %8953 = load <8 x i1>, ptr %8951, align 1
  %8954 = load <8 x i1>, ptr %8952, align 1
  %8955 = and <8 x i1> %8953, %8906
  %8956 = icmp eq <8 x i1> %8954, %8955
  %8957 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8956)
  %8958 = and i1 %8950, %8957
  %.splatinsert2030 = insertelement <8 x i1> poison, i1 %8958, i64 0
  %.splat2031 = shufflevector <8 x i1> %.splatinsert2030, <8 x i1> poison, <8 x i32> zeroinitializer
  %8959 = select <8 x i1> %.splat2031, <8 x i1> %8954, <8 x i1> zeroinitializer
  %8960 = select i1 %8958, <8 x i1> zeroinitializer, <8 x i1> %8955
  store <8 x i1> %8960, ptr %8951, align 1
  %8961 = select i1 %8958, <8 x i1> zeroinitializer, <8 x i1> %8954
  store <8 x i1> %8961, ptr %8952, align 1
  %8962 = and i8 %8948, -3
  %8963 = select i1 %8958, i8 %8962, i8 %8948
  store i8 %8963, ptr %frame.active, align 1
  %8964 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8965 = extractelement <8 x i32> %8964, i32 1
  %8966 = load <8 x i32>, ptr %frame.static.id, align 32
  %8967 = extractelement <8 x i32> %8966, i32 1
  %convergence.target.pointer2032 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %8967
  %convergence.dynamic.target2033 = load i32, ptr %convergence.target.pointer2032, align 4
  %8968 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8959)
  %8969 = load i32, ptr %ready.count, align 4
  %8970 = icmp uge i32 %8969, 8
  %8971 = and i1 %8968, %8970
  br i1 %8971, label %ready.overflow.trap2034, label %ready.overflow.resume2035

ready.overflow.trap2034:                          ; preds = %ready.overflow.resume2029
  call void @llvm.trap()
  unreachable

ready.overflow.resume2035:                        ; preds = %ready.overflow.resume2029
  %8972 = select i1 %8968, i32 %8969, i32 0
  %8973 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8972
  %8974 = load <8 x i1>, ptr %8973, align 1
  %8975 = select i1 %8968, <8 x i1> %8959, <8 x i1> %8974
  store <8 x i1> %8975, ptr %8973, align 1
  %8976 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8972
  %8977 = load i32, ptr %8976, align 4
  %8978 = select i1 %8968, i32 %convergence.dynamic.target2033, i32 %8977
  store i32 %8978, ptr %8976, align 4
  %8979 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8972
  %8980 = load i32, ptr %8979, align 4
  %8981 = select i1 %8968, i32 %8965, i32 %8980
  store i32 %8981, ptr %8979, align 4
  %8982 = add i32 %8969, 1
  %8983 = select i1 %8968, i32 %8982, i32 %8969
  store i32 %8983, ptr %ready.count, align 4
  %8984 = load <8 x i1>, ptr %runnable.mask, align 1
  %8985 = or <8 x i1> %8984, %8959
  store <8 x i1> %8985, ptr %runnable.mask, align 1
  %8986 = load i8, ptr %frame.active, align 1
  %8987 = and i8 %8986, 4
  %8988 = icmp ne i8 %8987, 0
  %8989 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %8990 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %8991 = load <8 x i1>, ptr %8989, align 1
  %8992 = load <8 x i1>, ptr %8990, align 1
  %8993 = and <8 x i1> %8991, %8906
  %8994 = icmp eq <8 x i1> %8992, %8993
  %8995 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8994)
  %8996 = and i1 %8988, %8995
  %.splatinsert2036 = insertelement <8 x i1> poison, i1 %8996, i64 0
  %.splat2037 = shufflevector <8 x i1> %.splatinsert2036, <8 x i1> poison, <8 x i32> zeroinitializer
  %8997 = select <8 x i1> %.splat2037, <8 x i1> %8992, <8 x i1> zeroinitializer
  %8998 = select i1 %8996, <8 x i1> zeroinitializer, <8 x i1> %8993
  store <8 x i1> %8998, ptr %8989, align 1
  %8999 = select i1 %8996, <8 x i1> zeroinitializer, <8 x i1> %8992
  store <8 x i1> %8999, ptr %8990, align 1
  %9000 = and i8 %8986, -5
  %9001 = select i1 %8996, i8 %9000, i8 %8986
  store i8 %9001, ptr %frame.active, align 1
  %9002 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9003 = extractelement <8 x i32> %9002, i32 2
  %9004 = load <8 x i32>, ptr %frame.static.id, align 32
  %9005 = extractelement <8 x i32> %9004, i32 2
  %convergence.target.pointer2038 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %9005
  %convergence.dynamic.target2039 = load i32, ptr %convergence.target.pointer2038, align 4
  %9006 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8997)
  %9007 = load i32, ptr %ready.count, align 4
  %9008 = icmp uge i32 %9007, 8
  %9009 = and i1 %9006, %9008
  br i1 %9009, label %ready.overflow.trap2040, label %ready.overflow.resume2041

ready.overflow.trap2040:                          ; preds = %ready.overflow.resume2035
  call void @llvm.trap()
  unreachable

ready.overflow.resume2041:                        ; preds = %ready.overflow.resume2035
  %9010 = select i1 %9006, i32 %9007, i32 0
  %9011 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9010
  %9012 = load <8 x i1>, ptr %9011, align 1
  %9013 = select i1 %9006, <8 x i1> %8997, <8 x i1> %9012
  store <8 x i1> %9013, ptr %9011, align 1
  %9014 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9010
  %9015 = load i32, ptr %9014, align 4
  %9016 = select i1 %9006, i32 %convergence.dynamic.target2039, i32 %9015
  store i32 %9016, ptr %9014, align 4
  %9017 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9010
  %9018 = load i32, ptr %9017, align 4
  %9019 = select i1 %9006, i32 %9003, i32 %9018
  store i32 %9019, ptr %9017, align 4
  %9020 = add i32 %9007, 1
  %9021 = select i1 %9006, i32 %9020, i32 %9007
  store i32 %9021, ptr %ready.count, align 4
  %9022 = load <8 x i1>, ptr %runnable.mask, align 1
  %9023 = or <8 x i1> %9022, %8997
  store <8 x i1> %9023, ptr %runnable.mask, align 1
  %9024 = load i8, ptr %frame.active, align 1
  %9025 = and i8 %9024, 8
  %9026 = icmp ne i8 %9025, 0
  %9027 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %9028 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %9029 = load <8 x i1>, ptr %9027, align 1
  %9030 = load <8 x i1>, ptr %9028, align 1
  %9031 = and <8 x i1> %9029, %8906
  %9032 = icmp eq <8 x i1> %9030, %9031
  %9033 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9032)
  %9034 = and i1 %9026, %9033
  %.splatinsert2042 = insertelement <8 x i1> poison, i1 %9034, i64 0
  %.splat2043 = shufflevector <8 x i1> %.splatinsert2042, <8 x i1> poison, <8 x i32> zeroinitializer
  %9035 = select <8 x i1> %.splat2043, <8 x i1> %9030, <8 x i1> zeroinitializer
  %9036 = select i1 %9034, <8 x i1> zeroinitializer, <8 x i1> %9031
  store <8 x i1> %9036, ptr %9027, align 1
  %9037 = select i1 %9034, <8 x i1> zeroinitializer, <8 x i1> %9030
  store <8 x i1> %9037, ptr %9028, align 1
  %9038 = and i8 %9024, -9
  %9039 = select i1 %9034, i8 %9038, i8 %9024
  store i8 %9039, ptr %frame.active, align 1
  %9040 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9041 = extractelement <8 x i32> %9040, i32 3
  %9042 = load <8 x i32>, ptr %frame.static.id, align 32
  %9043 = extractelement <8 x i32> %9042, i32 3
  %convergence.target.pointer2044 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %9043
  %convergence.dynamic.target2045 = load i32, ptr %convergence.target.pointer2044, align 4
  %9044 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9035)
  %9045 = load i32, ptr %ready.count, align 4
  %9046 = icmp uge i32 %9045, 8
  %9047 = and i1 %9044, %9046
  br i1 %9047, label %ready.overflow.trap2046, label %ready.overflow.resume2047

ready.overflow.trap2046:                          ; preds = %ready.overflow.resume2041
  call void @llvm.trap()
  unreachable

ready.overflow.resume2047:                        ; preds = %ready.overflow.resume2041
  %9048 = select i1 %9044, i32 %9045, i32 0
  %9049 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9048
  %9050 = load <8 x i1>, ptr %9049, align 1
  %9051 = select i1 %9044, <8 x i1> %9035, <8 x i1> %9050
  store <8 x i1> %9051, ptr %9049, align 1
  %9052 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9048
  %9053 = load i32, ptr %9052, align 4
  %9054 = select i1 %9044, i32 %convergence.dynamic.target2045, i32 %9053
  store i32 %9054, ptr %9052, align 4
  %9055 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9048
  %9056 = load i32, ptr %9055, align 4
  %9057 = select i1 %9044, i32 %9041, i32 %9056
  store i32 %9057, ptr %9055, align 4
  %9058 = add i32 %9045, 1
  %9059 = select i1 %9044, i32 %9058, i32 %9045
  store i32 %9059, ptr %ready.count, align 4
  %9060 = load <8 x i1>, ptr %runnable.mask, align 1
  %9061 = or <8 x i1> %9060, %9035
  store <8 x i1> %9061, ptr %runnable.mask, align 1
  %9062 = load i8, ptr %frame.active, align 1
  %9063 = and i8 %9062, 16
  %9064 = icmp ne i8 %9063, 0
  %9065 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %9066 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %9067 = load <8 x i1>, ptr %9065, align 1
  %9068 = load <8 x i1>, ptr %9066, align 1
  %9069 = and <8 x i1> %9067, %8906
  %9070 = icmp eq <8 x i1> %9068, %9069
  %9071 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9070)
  %9072 = and i1 %9064, %9071
  %.splatinsert2048 = insertelement <8 x i1> poison, i1 %9072, i64 0
  %.splat2049 = shufflevector <8 x i1> %.splatinsert2048, <8 x i1> poison, <8 x i32> zeroinitializer
  %9073 = select <8 x i1> %.splat2049, <8 x i1> %9068, <8 x i1> zeroinitializer
  %9074 = select i1 %9072, <8 x i1> zeroinitializer, <8 x i1> %9069
  store <8 x i1> %9074, ptr %9065, align 1
  %9075 = select i1 %9072, <8 x i1> zeroinitializer, <8 x i1> %9068
  store <8 x i1> %9075, ptr %9066, align 1
  %9076 = and i8 %9062, -17
  %9077 = select i1 %9072, i8 %9076, i8 %9062
  store i8 %9077, ptr %frame.active, align 1
  %9078 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9079 = extractelement <8 x i32> %9078, i32 4
  %9080 = load <8 x i32>, ptr %frame.static.id, align 32
  %9081 = extractelement <8 x i32> %9080, i32 4
  %convergence.target.pointer2050 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %9081
  %convergence.dynamic.target2051 = load i32, ptr %convergence.target.pointer2050, align 4
  %9082 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9073)
  %9083 = load i32, ptr %ready.count, align 4
  %9084 = icmp uge i32 %9083, 8
  %9085 = and i1 %9082, %9084
  br i1 %9085, label %ready.overflow.trap2052, label %ready.overflow.resume2053

ready.overflow.trap2052:                          ; preds = %ready.overflow.resume2047
  call void @llvm.trap()
  unreachable

ready.overflow.resume2053:                        ; preds = %ready.overflow.resume2047
  %9086 = select i1 %9082, i32 %9083, i32 0
  %9087 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9086
  %9088 = load <8 x i1>, ptr %9087, align 1
  %9089 = select i1 %9082, <8 x i1> %9073, <8 x i1> %9088
  store <8 x i1> %9089, ptr %9087, align 1
  %9090 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9086
  %9091 = load i32, ptr %9090, align 4
  %9092 = select i1 %9082, i32 %convergence.dynamic.target2051, i32 %9091
  store i32 %9092, ptr %9090, align 4
  %9093 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9086
  %9094 = load i32, ptr %9093, align 4
  %9095 = select i1 %9082, i32 %9079, i32 %9094
  store i32 %9095, ptr %9093, align 4
  %9096 = add i32 %9083, 1
  %9097 = select i1 %9082, i32 %9096, i32 %9083
  store i32 %9097, ptr %ready.count, align 4
  %9098 = load <8 x i1>, ptr %runnable.mask, align 1
  %9099 = or <8 x i1> %9098, %9073
  store <8 x i1> %9099, ptr %runnable.mask, align 1
  %9100 = load i8, ptr %frame.active, align 1
  %9101 = and i8 %9100, 32
  %9102 = icmp ne i8 %9101, 0
  %9103 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %9104 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %9105 = load <8 x i1>, ptr %9103, align 1
  %9106 = load <8 x i1>, ptr %9104, align 1
  %9107 = and <8 x i1> %9105, %8906
  %9108 = icmp eq <8 x i1> %9106, %9107
  %9109 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9108)
  %9110 = and i1 %9102, %9109
  %.splatinsert2054 = insertelement <8 x i1> poison, i1 %9110, i64 0
  %.splat2055 = shufflevector <8 x i1> %.splatinsert2054, <8 x i1> poison, <8 x i32> zeroinitializer
  %9111 = select <8 x i1> %.splat2055, <8 x i1> %9106, <8 x i1> zeroinitializer
  %9112 = select i1 %9110, <8 x i1> zeroinitializer, <8 x i1> %9107
  store <8 x i1> %9112, ptr %9103, align 1
  %9113 = select i1 %9110, <8 x i1> zeroinitializer, <8 x i1> %9106
  store <8 x i1> %9113, ptr %9104, align 1
  %9114 = and i8 %9100, -33
  %9115 = select i1 %9110, i8 %9114, i8 %9100
  store i8 %9115, ptr %frame.active, align 1
  %9116 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9117 = extractelement <8 x i32> %9116, i32 5
  %9118 = load <8 x i32>, ptr %frame.static.id, align 32
  %9119 = extractelement <8 x i32> %9118, i32 5
  %convergence.target.pointer2056 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %9119
  %convergence.dynamic.target2057 = load i32, ptr %convergence.target.pointer2056, align 4
  %9120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9111)
  %9121 = load i32, ptr %ready.count, align 4
  %9122 = icmp uge i32 %9121, 8
  %9123 = and i1 %9120, %9122
  br i1 %9123, label %ready.overflow.trap2058, label %ready.overflow.resume2059

ready.overflow.trap2058:                          ; preds = %ready.overflow.resume2053
  call void @llvm.trap()
  unreachable

ready.overflow.resume2059:                        ; preds = %ready.overflow.resume2053
  %9124 = select i1 %9120, i32 %9121, i32 0
  %9125 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9124
  %9126 = load <8 x i1>, ptr %9125, align 1
  %9127 = select i1 %9120, <8 x i1> %9111, <8 x i1> %9126
  store <8 x i1> %9127, ptr %9125, align 1
  %9128 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9124
  %9129 = load i32, ptr %9128, align 4
  %9130 = select i1 %9120, i32 %convergence.dynamic.target2057, i32 %9129
  store i32 %9130, ptr %9128, align 4
  %9131 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9124
  %9132 = load i32, ptr %9131, align 4
  %9133 = select i1 %9120, i32 %9117, i32 %9132
  store i32 %9133, ptr %9131, align 4
  %9134 = add i32 %9121, 1
  %9135 = select i1 %9120, i32 %9134, i32 %9121
  store i32 %9135, ptr %ready.count, align 4
  %9136 = load <8 x i1>, ptr %runnable.mask, align 1
  %9137 = or <8 x i1> %9136, %9111
  store <8 x i1> %9137, ptr %runnable.mask, align 1
  %9138 = load i8, ptr %frame.active, align 1
  %9139 = and i8 %9138, 64
  %9140 = icmp ne i8 %9139, 0
  %9141 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %9142 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %9143 = load <8 x i1>, ptr %9141, align 1
  %9144 = load <8 x i1>, ptr %9142, align 1
  %9145 = and <8 x i1> %9143, %8906
  %9146 = icmp eq <8 x i1> %9144, %9145
  %9147 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9146)
  %9148 = and i1 %9140, %9147
  %.splatinsert2060 = insertelement <8 x i1> poison, i1 %9148, i64 0
  %.splat2061 = shufflevector <8 x i1> %.splatinsert2060, <8 x i1> poison, <8 x i32> zeroinitializer
  %9149 = select <8 x i1> %.splat2061, <8 x i1> %9144, <8 x i1> zeroinitializer
  %9150 = select i1 %9148, <8 x i1> zeroinitializer, <8 x i1> %9145
  store <8 x i1> %9150, ptr %9141, align 1
  %9151 = select i1 %9148, <8 x i1> zeroinitializer, <8 x i1> %9144
  store <8 x i1> %9151, ptr %9142, align 1
  %9152 = and i8 %9138, -65
  %9153 = select i1 %9148, i8 %9152, i8 %9138
  store i8 %9153, ptr %frame.active, align 1
  %9154 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9155 = extractelement <8 x i32> %9154, i32 6
  %9156 = load <8 x i32>, ptr %frame.static.id, align 32
  %9157 = extractelement <8 x i32> %9156, i32 6
  %convergence.target.pointer2062 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %9157
  %convergence.dynamic.target2063 = load i32, ptr %convergence.target.pointer2062, align 4
  %9158 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9149)
  %9159 = load i32, ptr %ready.count, align 4
  %9160 = icmp uge i32 %9159, 8
  %9161 = and i1 %9158, %9160
  br i1 %9161, label %ready.overflow.trap2064, label %ready.overflow.resume2065

ready.overflow.trap2064:                          ; preds = %ready.overflow.resume2059
  call void @llvm.trap()
  unreachable

ready.overflow.resume2065:                        ; preds = %ready.overflow.resume2059
  %9162 = select i1 %9158, i32 %9159, i32 0
  %9163 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9162
  %9164 = load <8 x i1>, ptr %9163, align 1
  %9165 = select i1 %9158, <8 x i1> %9149, <8 x i1> %9164
  store <8 x i1> %9165, ptr %9163, align 1
  %9166 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9162
  %9167 = load i32, ptr %9166, align 4
  %9168 = select i1 %9158, i32 %convergence.dynamic.target2063, i32 %9167
  store i32 %9168, ptr %9166, align 4
  %9169 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9162
  %9170 = load i32, ptr %9169, align 4
  %9171 = select i1 %9158, i32 %9155, i32 %9170
  store i32 %9171, ptr %9169, align 4
  %9172 = add i32 %9159, 1
  %9173 = select i1 %9158, i32 %9172, i32 %9159
  store i32 %9173, ptr %ready.count, align 4
  %9174 = load <8 x i1>, ptr %runnable.mask, align 1
  %9175 = or <8 x i1> %9174, %9149
  store <8 x i1> %9175, ptr %runnable.mask, align 1
  %9176 = load i8, ptr %frame.active, align 1
  %9177 = and i8 %9176, -128
  %9178 = icmp ne i8 %9177, 0
  %9179 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %9180 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %9181 = load <8 x i1>, ptr %9179, align 1
  %9182 = load <8 x i1>, ptr %9180, align 1
  %9183 = and <8 x i1> %9181, %8906
  %9184 = icmp eq <8 x i1> %9182, %9183
  %9185 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9184)
  %9186 = and i1 %9178, %9185
  %.splatinsert2066 = insertelement <8 x i1> poison, i1 %9186, i64 0
  %.splat2067 = shufflevector <8 x i1> %.splatinsert2066, <8 x i1> poison, <8 x i32> zeroinitializer
  %9187 = select <8 x i1> %.splat2067, <8 x i1> %9182, <8 x i1> zeroinitializer
  %9188 = select i1 %9186, <8 x i1> zeroinitializer, <8 x i1> %9183
  store <8 x i1> %9188, ptr %9179, align 1
  %9189 = select i1 %9186, <8 x i1> zeroinitializer, <8 x i1> %9182
  store <8 x i1> %9189, ptr %9180, align 1
  %9190 = and i8 %9176, 127
  %9191 = select i1 %9186, i8 %9190, i8 %9176
  store i8 %9191, ptr %frame.active, align 1
  %9192 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9193 = extractelement <8 x i32> %9192, i32 7
  %9194 = load <8 x i32>, ptr %frame.static.id, align 32
  %9195 = extractelement <8 x i32> %9194, i32 7
  %convergence.target.pointer2068 = getelementptr inbounds [46 x i32], ptr @convergence.targets, i32 0, i32 %9195
  %convergence.dynamic.target2069 = load i32, ptr %convergence.target.pointer2068, align 4
  %9196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9187)
  %9197 = load i32, ptr %ready.count, align 4
  %9198 = icmp uge i32 %9197, 8
  %9199 = and i1 %9196, %9198
  br i1 %9199, label %ready.overflow.trap2070, label %ready.overflow.resume2071

ready.overflow.trap2070:                          ; preds = %ready.overflow.resume2065
  call void @llvm.trap()
  unreachable

ready.overflow.resume2071:                        ; preds = %ready.overflow.resume2065
  %9200 = select i1 %9196, i32 %9197, i32 0
  %9201 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9200
  %9202 = load <8 x i1>, ptr %9201, align 1
  %9203 = select i1 %9196, <8 x i1> %9187, <8 x i1> %9202
  store <8 x i1> %9203, ptr %9201, align 1
  %9204 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9200
  %9205 = load i32, ptr %9204, align 4
  %9206 = select i1 %9196, i32 %convergence.dynamic.target2069, i32 %9205
  store i32 %9206, ptr %9204, align 4
  %9207 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9200
  %9208 = load i32, ptr %9207, align 4
  %9209 = select i1 %9196, i32 %9193, i32 %9208
  store i32 %9209, ptr %9207, align 4
  %9210 = add i32 %9197, 1
  %9211 = select i1 %9196, i32 %9210, i32 %9197
  store i32 %9211, ptr %ready.count, align 4
  %9212 = load <8 x i1>, ptr %runnable.mask, align 1
  %9213 = or <8 x i1> %9212, %9187
  store <8 x i1> %9213, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #3

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #4 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #5

define dso_local void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(write) }

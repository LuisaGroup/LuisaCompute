	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_4:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_5:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	dup.4s	v2, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v2, v4
	cmhi.4s	v1, v2, v3
	uzp1.8h	v17, v1, v0
	umaxv.8h	h5, v17
	fmov	w8, s5
	tbz	w8, #0, LBB0_120
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #1088
	mov	x9, #0                          ; =0x0
	ldr	x10, [x1, #136]
	add	x8, x10, #2560
	mov	w11, #5632                      ; =0x1600
	add	x11, x10, x11
	mov	w12, #8704                      ; =0x2200
	add	x12, x10, x12
	mov	w13, #49664                     ; =0xc200
	add	x13, x10, x13
	add	x14, x10, #24, lsl #12          ; =98304
	add	x14, x14, #512
	add	x15, x10, #24, lsl #12          ; =98304
	add	x15, x15, #1536
	ldr	x2, [x0]
	ldr	x16, [x0, #16]
	ldr	w17, [x1]
	ldr	w1, [x1, #36]
	add	w1, w1, w17, lsl #5
	ldr	x17, [x0, #32]
	ldr	x0, [x0, #48]
	str	x0, [sp, #8]                    ; 8-byte Spill
	dup.4s	v5, w1
	add.4s	v6, v5, v4
	add.4s	v5, v5, v3
	and.16b	v16, v1, v5
	and.16b	v7, v0, v6
	ushll2.2d	v6, v7, #0
	ushll2.2d	v5, v16, #0
	stp	q5, q6, [sp, #48]               ; 32-byte Folded Spill
	ushll.2d	v6, v7, #0
	ushll.2d	v5, v16, #0
	stp	q5, q6, [sp, #16]               ; 32-byte Folded Spill
	movi.4s	v6, #80
	umull2.2d	v5, v7, v6
	umull2.2d	v6, v16, v6
	movi.2s	v18, #80
	umull.2d	v7, v7, v18
	umull.2d	v16, v16, v18
Lloh4:
	adrp	x0, lCPI0_2@PAGE
Lloh5:
	ldr	q18, [x0, lCPI0_2@PAGEOFF]
	and.16b	v17, v17, v18
	addv.8h	h17, v17
	str	q17, [sp, #4736]                ; 16-byte Spill
	fmov	w0, s17
	dup.2d	v17, x2
	b	LBB0_3
LBB0_2:                                 ; %else511
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x10, x9, lsl #5
	ldp	q20, q21, [x1]
	bif.16b	v19, v21, v0
	bif.16b	v18, v20, v1
	stp	q18, q19, [x1]
	add	x9, x9, #1
	cmp	x9, #80
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v20, x9
	add.2d	v18, v20, v16
	shl.2d	v18, v18, #2
	add.2d	v21, v17, v18
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w0, #0, LBB0_11
; %bb.4:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x1, d21
	ldr	s18, [x1]
	and	w1, w0, #0xff
	tbnz	w1, #1, LBB0_12
LBB0_5:                                 ; %else493
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v21, v20, v6
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbz	w1, #2, LBB0_13
LBB0_6:                                 ; %cond.load495
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x2, d21
	ld1.s	{ v18 }[2], [x2]
	tbnz	w1, #3, LBB0_14
LBB0_7:                                 ; %else499
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v21, v20, v7
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbz	w1, #4, LBB0_15
LBB0_8:                                 ; %cond.load501
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x2, d21
	ld1.s	{ v19 }[0], [x2]
	tbnz	w1, #5, LBB0_16
LBB0_9:                                 ; %else505
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v20, v20, v5
	shl.2d	v20, v20, #2
	add.2d	v20, v17, v20
	tbz	w1, #6, LBB0_17
LBB0_10:                                ; %cond.load507
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x2, d20
	ld1.s	{ v19 }[2], [x2]
	tbz	w1, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w1, w0, #0xff
	tbz	w1, #1, LBB0_5
LBB0_12:                                ; %cond.load492
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x2, v21[1]
	ld1.s	{ v18 }[1], [x2]
	add.2d	v21, v20, v6
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbnz	w1, #2, LBB0_6
LBB0_13:                                ; %else496
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w1, #3, LBB0_7
LBB0_14:                                ; %cond.load498
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x2, v21[1]
	ld1.s	{ v18 }[3], [x2]
	add.2d	v21, v20, v7
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbnz	w1, #4, LBB0_8
LBB0_15:                                ; %else502
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w1, #5, LBB0_9
LBB0_16:                                ; %cond.load504
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x2, v21[1]
	ld1.s	{ v19 }[1], [x2]
	add.2d	v20, v20, v5
	shl.2d	v20, v20, #2
	add.2d	v20, v17, v20
	tbnz	w1, #6, LBB0_10
LBB0_17:                                ; %else508
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w1, #7, LBB0_2
LBB0_18:                                ; %cond.load510
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x1, v20[1]
	ld1.s	{ v19 }[3], [x1]
	b	LBB0_2
LBB0_19:                                ; %direct.true237.preheader
	mov	x9, #0                          ; =0x0
	cmhs.4s	v4, v4, v2
	cmhs.4s	v2, v3, v2
LBB0_20:                                ; %direct.true237
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, x8, x9
	ldp	q3, q5, [x0]
	and.16b	v5, v4, v5
	and.16b	v3, v2, v3
	stp	q3, q5, [x0]
	add	x9, x9, #32
	cmp	x9, #3072
	b.ne	LBB0_20
; %bb.21:                               ; %direct.false238
	sshll.2d	v2, v1, #0
	mov	x0, #0                          ; =0x0
	sshll.2d	v3, v0, #0
	sshll2.2d	v18, v1, #0
	sshll2.2d	v19, v0, #0
	ldp	q4, q6, [sp, #16]               ; 32-byte Folded Reload
	ushr.2d	v4, v4, #2
	ldp	q5, q7, [sp, #48]               ; 32-byte Folded Reload
	ushr.2d	v5, v5, #2
	ushr.2d	v6, v6, #2
	ushr.2d	v7, v7, #2
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q16, [x9, lCPI0_6@PAGEOFF]
	str	q16, [sp, #2432]                ; 16-byte Spill
	and.16b	v20, v2, v16
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v16, w9
	mov.d	x9, v7[1]
	and.16b	v17, v0, v16
	str	q17, [sp, #4576]                ; 16-byte Spill
	mov	w1, #2053                       ; =0x805
	mul	x9, x9, x1
	fmov	x2, d7
	mul	x2, x2, x1
	fmov	d7, x2
	mov.d	v7[1], x9
	mov.d	x9, v6[1]
	mul	x9, x9, x1
	fmov	x2, d6
	mul	x2, x2, x1
	fmov	d6, x2
	mov.d	v6[1], x9
	mov.d	x9, v5[1]
	mul	x9, x9, x1
	fmov	x2, d5
	mul	x2, x2, x1
	fmov	d5, x2
	mov.d	v5[1], x9
	str	q16, [sp, #304]                 ; 16-byte Spill
	and.16b	v16, v1, v16
	str	q16, [sp, #4560]                ; 16-byte Spill
	mov.d	x9, v4[1]
	mul	x9, x9, x1
	fmov	x2, d4
	mul	x1, x2, x1
	fmov	d4, x1
	mov.d	v4[1], x9
	and.16b	v2, v2, v4
	str	q2, [sp, #5120]                 ; 16-byte Spill
	and.16b	v2, v18, v5
	str	q2, [sp, #5104]                 ; 16-byte Spill
	and.16b	v2, v3, v6
	str	q2, [sp, #5088]                 ; 16-byte Spill
	and.16b	v2, v19, v7
	str	q2, [sp, #5072]                 ; 16-byte Spill
	mvni.4s	v2, #63, msl #16
	fneg.4s	v2, v2
	str	q2, [sp, #288]                  ; 16-byte Spill
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #2416]                 ; 16-byte Spill
	str	q2, [sp, #2400]                 ; 16-byte Spill
	str	q2, [sp, #2384]                 ; 16-byte Spill
	str	q2, [sp, #2368]                 ; 16-byte Spill
	str	q2, [sp, #2352]                 ; 16-byte Spill
	str	q2, [sp, #2336]                 ; 16-byte Spill
	str	q2, [sp, #2320]                 ; 16-byte Spill
	str	q20, [sp, #4720]                ; 16-byte Spill
	fmov	x9, d20
	movi.2d	v5, #0000000000000000
	mov	w1, #52736                      ; =0xce00
	str	q2, [sp, #2304]                 ; 16-byte Spill
	add	x1, x10, x1
	str	q2, [sp, #2288]                 ; 16-byte Spill
	movi.2d	v7, #0000000000000000
Lloh8:
	adrp	x2, lCPI0_3@PAGE
Lloh9:
	ldr	q2, [x2, lCPI0_3@PAGEOFF]
	str	q2, [sp, #2272]                 ; 16-byte Spill
Lloh10:
	adrp	x2, lCPI0_4@PAGE
Lloh11:
	ldr	q2, [x2, lCPI0_4@PAGEOFF]
	str	q2, [sp, #2256]                 ; 16-byte Spill
Lloh12:
	adrp	x2, lCPI0_5@PAGE
Lloh13:
	ldr	q2, [x2, lCPI0_5@PAGEOFF]
	str	q2, [sp, #2240]                 ; 16-byte Spill
	add	x9, x10, x9
	str	x9, [sp, #280]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #512
	str	x9, [sp, #272]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #544
	str	x9, [sp, #264]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #576
	str	x9, [sp, #256]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #608
	str	x9, [sp, #248]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #640
	str	x9, [sp, #240]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #672
	str	x9, [sp, #232]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #704
	str	x9, [sp, #224]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #736
	str	x9, [sp, #216]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #768
	str	x9, [sp, #208]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #800
	str	x9, [sp, #200]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #832
	str	x9, [sp, #192]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #864
	str	x9, [sp, #184]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #896
	str	x9, [sp, #176]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #928
	str	x9, [sp, #168]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #960
	str	x9, [sp, #160]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #992
	str	x9, [sp, #152]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1024
	str	x9, [sp, #144]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1056
	str	x9, [sp, #136]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1088
	str	x9, [sp, #128]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1120
	str	x9, [sp, #120]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1152
	str	x9, [sp, #112]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1184
	str	x9, [sp, #104]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1216
	str	x9, [sp, #96]                   ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1248
	str	x9, [sp, #88]                   ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x20, x9, #1280
	add	x9, x10, #24, lsl #12           ; =98304
	add	x21, x9, #1312
	add	x9, x10, #24, lsl #12           ; =98304
	add	x22, x9, #1344
	add	x9, x10, #24, lsl #12           ; =98304
	add	x23, x9, #1376
	add	x9, x10, #24, lsl #12           ; =98304
	add	x24, x9, #1408
	add	x9, x10, #24, lsl #12           ; =98304
	add	x25, x9, #1440
	add	x9, x10, #24, lsl #12           ; =98304
	add	x26, x9, #1472
	add	x9, x10, #24, lsl #12           ; =98304
	add	x27, x9, #1504
	mov	w28, #52429                     ; =0xcccd
	mov	w30, #80                        ; =0x50
	mov	w9, #43691                      ; =0xaaab
	mov	w2, #96                         ; =0x60
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #2224]                 ; 16-byte Spill
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	str	q2, [sp, #2208]                 ; 16-byte Spill
	str	q2, [sp, #2192]                 ; 16-byte Spill
	str	q2, [sp, #2176]                 ; 16-byte Spill
	movi.2d	v4, #0000000000000000
	movi.2d	v6, #0000000000000000
	str	q2, [sp, #2160]                 ; 16-byte Spill
	str	q2, [sp, #2144]                 ; 16-byte Spill
	str	q2, [sp, #2128]                 ; 16-byte Spill
	str	q2, [sp, #2112]                 ; 16-byte Spill
	str	q2, [sp, #2096]                 ; 16-byte Spill
	str	q2, [sp, #2080]                 ; 16-byte Spill
	str	q2, [sp, #2064]                 ; 16-byte Spill
	str	q2, [sp, #2048]                 ; 16-byte Spill
	str	q2, [sp, #2032]                 ; 16-byte Spill
	str	q2, [sp, #4912]                 ; 16-byte Spill
	str	q2, [sp, #4896]                 ; 16-byte Spill
	str	q2, [sp, #4880]                 ; 16-byte Spill
	str	q2, [sp, #4864]                 ; 16-byte Spill
	str	q2, [sp, #4848]                 ; 16-byte Spill
	str	q2, [sp, #4832]                 ; 16-byte Spill
	str	q2, [sp, #4816]                 ; 16-byte Spill
	str	q2, [sp, #4800]                 ; 16-byte Spill
	str	q2, [sp, #4784]                 ; 16-byte Spill
	str	q2, [sp, #4768]                 ; 16-byte Spill
	str	q2, [sp, #2016]                 ; 16-byte Spill
	str	q2, [sp, #2000]                 ; 16-byte Spill
	str	q2, [sp, #1984]                 ; 16-byte Spill
	str	q2, [sp, #1968]                 ; 16-byte Spill
	str	q2, [sp, #1952]                 ; 16-byte Spill
	str	q2, [sp, #1936]                 ; 16-byte Spill
	str	q2, [sp, #1920]                 ; 16-byte Spill
	str	q2, [sp, #1904]                 ; 16-byte Spill
	str	q2, [sp, #1888]                 ; 16-byte Spill
	str	q2, [sp, #4496]                 ; 16-byte Spill
	str	q2, [sp, #4480]                 ; 16-byte Spill
	str	q2, [sp, #4464]                 ; 16-byte Spill
	str	q2, [sp, #1872]                 ; 16-byte Spill
	str	q2, [sp, #1856]                 ; 16-byte Spill
	str	q2, [sp, #4448]                 ; 16-byte Spill
	str	q2, [sp, #4432]                 ; 16-byte Spill
	str	q2, [sp, #4416]                 ; 16-byte Spill
	str	q2, [sp, #4400]                 ; 16-byte Spill
	str	q2, [sp, #4384]                 ; 16-byte Spill
	str	q2, [sp, #4368]                 ; 16-byte Spill
	str	q2, [sp, #4352]                 ; 16-byte Spill
	str	q2, [sp, #1840]                 ; 16-byte Spill
	str	q2, [sp, #1824]                 ; 16-byte Spill
	str	q2, [sp, #1808]                 ; 16-byte Spill
	str	q2, [sp, #4336]                 ; 16-byte Spill
	str	q2, [sp, #4320]                 ; 16-byte Spill
	str	q2, [sp, #4304]                 ; 16-byte Spill
	str	q2, [sp, #4288]                 ; 16-byte Spill
	str	q2, [sp, #4272]                 ; 16-byte Spill
	str	q2, [sp, #1792]                 ; 16-byte Spill
	str	q2, [sp, #1776]                 ; 16-byte Spill
	str	q2, [sp, #4256]                 ; 16-byte Spill
	str	q2, [sp, #1760]                 ; 16-byte Spill
	str	q2, [sp, #1744]                 ; 16-byte Spill
	str	q2, [sp, #4240]                 ; 16-byte Spill
	str	q2, [sp, #4224]                 ; 16-byte Spill
	str	q2, [sp, #4208]                 ; 16-byte Spill
	str	q2, [sp, #4192]                 ; 16-byte Spill
	str	q2, [sp, #4176]                 ; 16-byte Spill
	str	q2, [sp, #1728]                 ; 16-byte Spill
	str	q2, [sp, #1712]                 ; 16-byte Spill
	str	q2, [sp, #4160]                 ; 16-byte Spill
	str	q2, [sp, #1696]                 ; 16-byte Spill
	str	q2, [sp, #1680]                 ; 16-byte Spill
	str	q2, [sp, #4144]                 ; 16-byte Spill
	str	q2, [sp, #4128]                 ; 16-byte Spill
	str	q2, [sp, #4112]                 ; 16-byte Spill
	str	q2, [sp, #4096]                 ; 16-byte Spill
	str	q2, [sp, #4080]                 ; 16-byte Spill
	str	q2, [sp, #4064]                 ; 16-byte Spill
	str	q2, [sp, #1664]                 ; 16-byte Spill
	str	q2, [sp, #4048]                 ; 16-byte Spill
	str	q2, [sp, #1648]                 ; 16-byte Spill
	str	q2, [sp, #1632]                 ; 16-byte Spill
	str	q2, [sp, #4032]                 ; 16-byte Spill
	str	q2, [sp, #4016]                 ; 16-byte Spill
	str	q2, [sp, #4000]                 ; 16-byte Spill
	str	q2, [sp, #3984]                 ; 16-byte Spill
	str	q2, [sp, #3968]                 ; 16-byte Spill
	str	q2, [sp, #3952]                 ; 16-byte Spill
	str	q2, [sp, #1616]                 ; 16-byte Spill
	str	q2, [sp, #1600]                 ; 16-byte Spill
	str	q2, [sp, #1584]                 ; 16-byte Spill
	str	q2, [sp, #1568]                 ; 16-byte Spill
	str	q2, [sp, #3936]                 ; 16-byte Spill
	str	q2, [sp, #3920]                 ; 16-byte Spill
	str	q2, [sp, #3904]                 ; 16-byte Spill
	str	q2, [sp, #3888]                 ; 16-byte Spill
	str	q2, [sp, #3872]                 ; 16-byte Spill
	str	q2, [sp, #3856]                 ; 16-byte Spill
	str	q2, [sp, #1552]                 ; 16-byte Spill
	str	q2, [sp, #1536]                 ; 16-byte Spill
	str	q2, [sp, #1520]                 ; 16-byte Spill
	str	q2, [sp, #1504]                 ; 16-byte Spill
	str	q2, [sp, #3840]                 ; 16-byte Spill
	str	q2, [sp, #3824]                 ; 16-byte Spill
	str	q2, [sp, #3808]                 ; 16-byte Spill
	str	q2, [sp, #3792]                 ; 16-byte Spill
	str	q2, [sp, #3776]                 ; 16-byte Spill
	str	q2, [sp, #3760]                 ; 16-byte Spill
	str	q2, [sp, #3744]                 ; 16-byte Spill
	str	q2, [sp, #3728]                 ; 16-byte Spill
	str	q2, [sp, #1488]                 ; 16-byte Spill
	str	q2, [sp, #1472]                 ; 16-byte Spill
	str	q2, [sp, #3712]                 ; 16-byte Spill
	str	q2, [sp, #3696]                 ; 16-byte Spill
	str	q2, [sp, #3680]                 ; 16-byte Spill
	str	q2, [sp, #3664]                 ; 16-byte Spill
	str	q2, [sp, #3648]                 ; 16-byte Spill
	str	q2, [sp, #3632]                 ; 16-byte Spill
	str	q2, [sp, #3616]                 ; 16-byte Spill
	str	q2, [sp, #3600]                 ; 16-byte Spill
	str	q2, [sp, #1456]                 ; 16-byte Spill
	str	q2, [sp, #1440]                 ; 16-byte Spill
	str	q2, [sp, #3584]                 ; 16-byte Spill
	str	q2, [sp, #3568]                 ; 16-byte Spill
	str	q2, [sp, #3552]                 ; 16-byte Spill
	str	q2, [sp, #3536]                 ; 16-byte Spill
	str	q2, [sp, #3520]                 ; 16-byte Spill
	str	q2, [sp, #3504]                 ; 16-byte Spill
	str	q2, [sp, #3488]                 ; 16-byte Spill
	str	q2, [sp, #3472]                 ; 16-byte Spill
	str	q2, [sp, #1424]                 ; 16-byte Spill
	str	q2, [sp, #1408]                 ; 16-byte Spill
	str	q2, [sp, #3456]                 ; 16-byte Spill
	str	q2, [sp, #3440]                 ; 16-byte Spill
	str	q2, [sp, #3424]                 ; 16-byte Spill
	str	q2, [sp, #3408]                 ; 16-byte Spill
	str	q2, [sp, #3392]                 ; 16-byte Spill
	movi.2d	v31, #0000000000000000
	str	q2, [sp, #3376]                 ; 16-byte Spill
	str	q2, [sp, #3360]                 ; 16-byte Spill
	str	q2, [sp, #1392]                 ; 16-byte Spill
	str	q2, [sp, #1376]                 ; 16-byte Spill
	str	q2, [sp, #3344]                 ; 16-byte Spill
	str	q2, [sp, #3328]                 ; 16-byte Spill
	str	q2, [sp, #3312]                 ; 16-byte Spill
	str	q2, [sp, #3296]                 ; 16-byte Spill
	str	q2, [sp, #3280]                 ; 16-byte Spill
	movi.2d	v8, #0000000000000000
	str	q2, [sp, #3264]                 ; 16-byte Spill
	str	q2, [sp, #3248]                 ; 16-byte Spill
	str	q2, [sp, #1360]                 ; 16-byte Spill
	str	q2, [sp, #1344]                 ; 16-byte Spill
	str	q2, [sp, #3232]                 ; 16-byte Spill
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v21, #0000000000000000
	str	q2, [sp, #3216]                 ; 16-byte Spill
	str	q2, [sp, #3200]                 ; 16-byte Spill
	str	q2, [sp, #3184]                 ; 16-byte Spill
	str	q2, [sp, #1328]                 ; 16-byte Spill
	str	q2, [sp, #1312]                 ; 16-byte Spill
	str	q2, [sp, #3168]                 ; 16-byte Spill
	movi.2d	v22, #0000000000000000
	str	q2, [sp, #3152]                 ; 16-byte Spill
	movi.2d	v12, #0000000000000000
	str	q2, [sp, #3136]                 ; 16-byte Spill
	str	q2, [sp, #3120]                 ; 16-byte Spill
	str	q2, [sp, #3104]                 ; 16-byte Spill
	str	q2, [sp, #3088]                 ; 16-byte Spill
	str	q2, [sp, #1296]                 ; 16-byte Spill
	str	q2, [sp, #1280]                 ; 16-byte Spill
	str	q2, [sp, #3072]                 ; 16-byte Spill
	movi.2d	v15, #0000000000000000
	str	q2, [sp, #3056]                 ; 16-byte Spill
	movi.2d	v23, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v14, #0000000000000000
	str	q2, [sp, #1264]                 ; 16-byte Spill
	str	q2, [sp, #3040]                 ; 16-byte Spill
	movi.2d	v24, #0000000000000000
	str	q2, [sp, #1248]                 ; 16-byte Spill
	movi.2d	v20, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	str	q2, [sp, #5056]                 ; 16-byte Spill
	str	q2, [sp, #5040]                 ; 16-byte Spill
	str	q2, [sp, #5024]                 ; 16-byte Spill
	str	q2, [sp, #5008]                 ; 16-byte Spill
	str	q2, [sp, #5152]                 ; 16-byte Spill
	str	q2, [sp, #4752]                 ; 16-byte Spill
	str	q2, [sp, #1232]                 ; 16-byte Spill
	str	q2, [sp, #1216]                 ; 16-byte Spill
	str	q2, [sp, #1200]                 ; 16-byte Spill
	str	q2, [sp, #4992]                 ; 16-byte Spill
	str	q2, [sp, #4976]                 ; 16-byte Spill
	str	q2, [sp, #4960]                 ; 16-byte Spill
	str	q2, [sp, #4944]                 ; 16-byte Spill
	str	q2, [sp, #4928]                 ; 16-byte Spill
	str	q2, [sp, #5136]                 ; 16-byte Spill
	movi.2d	v3, #0000000000000000
	str	q3, [sp, #1184]                 ; 16-byte Spill
	str	q3, [sp, #1168]                 ; 16-byte Spill
	str	q3, [sp, #1152]                 ; 16-byte Spill
	str	q3, [sp, #2496]                 ; 16-byte Spill
	str	q3, [sp, #2480]                 ; 16-byte Spill
	str	q18, [sp, #2464]                ; 16-byte Spill
	str	q19, [sp, #2448]                ; 16-byte Spill
LBB0_22:                                ; %direct.true247
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_24 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
                                        ;     Child Loop BB0_61 Depth 2
                                        ;     Child Loop BB0_63 Depth 2
                                        ;     Child Loop BB0_65 Depth 2
                                        ;     Child Loop BB0_67 Depth 2
                                        ;     Child Loop BB0_69 Depth 2
                                        ;     Child Loop BB0_71 Depth 2
                                        ;     Child Loop BB0_73 Depth 2
                                        ;     Child Loop BB0_75 Depth 2
                                        ;     Child Loop BB0_77 Depth 2
                                        ;     Child Loop BB0_79 Depth 2
                                        ;     Child Loop BB0_81 Depth 2
                                        ;     Child Loop BB0_83 Depth 2
                                        ;     Child Loop BB0_85 Depth 2
                                        ;     Child Loop BB0_87 Depth 2
                                        ;     Child Loop BB0_89 Depth 2
                                        ;     Child Loop BB0_91 Depth 2
                                        ;     Child Loop BB0_93 Depth 2
                                        ;     Child Loop BB0_95 Depth 2
                                        ;     Child Loop BB0_97 Depth 2
                                        ;     Child Loop BB0_99 Depth 2
	str	q6, [sp, #4512]                 ; 16-byte Spill
	str	q5, [sp, #4544]                 ; 16-byte Spill
	str	q4, [sp, #4528]                 ; 16-byte Spill
	str	q17, [sp, #1104]                ; 16-byte Spill
	str	q16, [sp, #1120]                ; 16-byte Spill
	str	q7, [sp, #1136]                 ; 16-byte Spill
	mov	x4, #0                          ; =0x0
	lsl	x3, x0, #4
	b	LBB0_24
LBB0_23:                                ; %direct.schedule.12
                                        ;   in Loop: Header=BB0_24 Depth=2
	str	q17, [sp, #4928]                ; 16-byte Spill
	str	q16, [sp, #4944]                ; 16-byte Spill
	str	q7, [sp, #4960]                 ; 16-byte Spill
	ldr	q5, [sp, #4976]                 ; 16-byte Reload
	bit.16b	v5, v4, v0
	str	q5, [sp, #4976]                 ; 16-byte Spill
	ldr	q5, [sp, #4992]                 ; 16-byte Reload
	bit.16b	v5, v3, v1
	str	q5, [sp, #4992]                 ; 16-byte Spill
	add	x5, x12, x4, lsl #5
	ldp	q5, q6, [x5]
	bif.16b	v4, v6, v0
	bif.16b	v3, v5, v1
	stp	q3, q4, [x5]
	add	x4, x4, #1
	cmp	x4, #1280
	b.eq	LBB0_41
LBB0_24:                                ; %direct.true251
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w5, w4, #0xffff
	mul	w5, w5, w28
	lsr	w6, w5, #22
	add	x5, x3, x6
	dup.2d	v3, x5
	ldr	q4, [sp, #5104]                 ; 16-byte Reload
	add.2d	v4, v3, v4
	ldr	q5, [sp, #5088]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	ldr	q6, [sp, #5072]                 ; 16-byte Reload
	add.2d	v6, v3, v6
	mov.d	x7, v6[1]
	fmov	x19, d6
	add	x19, x19, x19, lsl #2
	lsl	x19, x19, #4
	fmov	d6, x19
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	mov.d	v6[1], x7
	mov.d	x7, v5[1]
	fmov	x19, d5
	add	x19, x19, x19, lsl #2
	lsl	x19, x19, #4
	fmov	d5, x19
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	mov.d	v5[1], x7
	mov.d	x7, v4[1]
	ldr	q7, [sp, #5120]                 ; 16-byte Reload
	add.2d	v3, v3, v7
	fmov	x19, d4
	add	x19, x19, x19, lsl #2
	lsl	x19, x19, #4
	fmov	d4, x19
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	mov.d	v4[1], x7
	mov.d	x7, v3[1]
	fmov	x19, d3
	add	x19, x19, x19, lsl #2
	lsl	x19, x19, #4
	fmov	d3, x19
	sshll.2d	v7, v1, #0
	msub	w6, w6, w30, w4
	and	x6, x6, #0xffff
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	mov.d	v3[1], x7
	dup.2d	v16, x6
	sshll.2d	v17, v0, #0
	add.2d	v3, v3, v16
	add.2d	v4, v4, v16
	add.2d	v5, v5, v16
	add.2d	v6, v6, v16
	ldr	q16, [sp, #5136]                ; 16-byte Reload
	bit.16b	v16, v6, v19
	str	q16, [sp, #5136]                ; 16-byte Spill
	ldr	q6, [sp, #4928]                 ; 16-byte Reload
	bsl.16b	v17, v5, v6
	ldr	q16, [sp, #4944]                ; 16-byte Reload
	bit.16b	v16, v4, v18
	ldr	q4, [sp, #4960]                 ; 16-byte Reload
	bsl.16b	v7, v3, v4
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	cmp	x5, #2052
	b.hi	LBB0_23
; %bb.25:                               ; %direct.true264
                                        ;   in Loop: Header=BB0_24 Depth=2
	ldr	q3, [sp, #4736]                 ; 16-byte Reload
	fmov	w5, s3
	shl.2d	v3, v7, #2
	dup.2d	v5, x16
	add.2d	v6, v5, v3
	movi.2d	v3, #0000000000000000
	tbz	w5, #0, LBB0_33
; %bb.26:                               ; %cond.load514
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x6, d6
	ldr	s3, [x6]
	and	w5, w5, #0xff
	tbnz	w5, #1, LBB0_34
LBB0_27:                                ; %else524
                                        ;   in Loop: Header=BB0_24 Depth=2
	shl.2d	v6, v16, #2
	add.2d	v6, v5, v6
	tbz	w5, #2, LBB0_35
LBB0_28:                                ; %cond.load526
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x6, d6
	ld1.s	{ v3 }[2], [x6]
	tbnz	w5, #3, LBB0_36
LBB0_29:                                ; %else536
                                        ;   in Loop: Header=BB0_24 Depth=2
	shl.2d	v6, v17, #2
	add.2d	v6, v5, v6
	tbz	w5, #4, LBB0_37
LBB0_30:                                ; %cond.load538
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x6, d6
	ld1.s	{ v4 }[0], [x6]
	tbnz	w5, #5, LBB0_38
LBB0_31:                                ; %else548
                                        ;   in Loop: Header=BB0_24 Depth=2
	ldr	q6, [sp, #5136]                 ; 16-byte Reload
	shl.2d	v6, v6, #2
	add.2d	v5, v5, v6
	tbz	w5, #6, LBB0_39
LBB0_32:                                ; %cond.load550
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x6, d5
	ld1.s	{ v4 }[2], [x6]
	tbz	w5, #7, LBB0_23
	b	LBB0_40
LBB0_33:                                ; %else518
                                        ;   in Loop: Header=BB0_24 Depth=2
	and	w5, w5, #0xff
	tbz	w5, #1, LBB0_27
LBB0_34:                                ; %cond.load520
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v3 }[1], [x6]
	shl.2d	v6, v16, #2
	add.2d	v6, v5, v6
	tbnz	w5, #2, LBB0_28
LBB0_35:                                ; %else530
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w5, #3, LBB0_29
LBB0_36:                                ; %cond.load532
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v3 }[3], [x6]
	shl.2d	v6, v17, #2
	add.2d	v6, v5, v6
	tbnz	w5, #4, LBB0_30
LBB0_37:                                ; %else542
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w5, #5, LBB0_31
LBB0_38:                                ; %cond.load544
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v4 }[1], [x6]
	ldr	q6, [sp, #5136]                 ; 16-byte Reload
	shl.2d	v6, v6, #2
	add.2d	v5, v5, v6
	tbnz	w5, #6, LBB0_32
LBB0_39:                                ; %else554
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w5, #7, LBB0_23
LBB0_40:                                ; %cond.load556
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x5, v5[1]
	ld1.s	{ v4 }[3], [x5]
	b	LBB0_23
LBB0_41:                                ; %direct.true276.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x4, #0                          ; =0x0
	b	LBB0_43
LBB0_42:                                ; %direct.schedule.17
                                        ;   in Loop: Header=BB0_43 Depth=2
	str	q17, [sp, #5008]                ; 16-byte Spill
	str	q16, [sp, #5024]                ; 16-byte Spill
	str	q7, [sp, #5040]                 ; 16-byte Spill
	ldr	q5, [sp, #5056]                 ; 16-byte Reload
	bit.16b	v5, v4, v0
	str	q5, [sp, #5056]                 ; 16-byte Spill
	bit.16b	v29, v3, v1
	add	x5, x13, x4, lsl #5
	ldp	q5, q6, [x5]
	bif.16b	v4, v6, v0
	bif.16b	v3, v5, v1
	stp	q3, q4, [x5]
	add	x4, x4, #1
	cmp	x4, #1536
	b.eq	LBB0_60
LBB0_43:                                ; %direct.true276
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w5, w4, #0xffff
	mul	w5, w5, w9
	lsr	w6, w5, #22
	add	x5, x3, x6
	dup.2d	v3, x5
	ldr	q4, [sp, #5104]                 ; 16-byte Reload
	add.2d	v4, v3, v4
	ldr	q5, [sp, #5088]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	ldr	q6, [sp, #5072]                 ; 16-byte Reload
	add.2d	v6, v3, v6
	mov.d	x7, v6[1]
	fmov	x19, d6
	add	x19, x19, x19, lsl #1
	lsl	x19, x19, #5
	fmov	d6, x19
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	mov.d	v6[1], x7
	mov.d	x7, v5[1]
	fmov	x19, d5
	add	x19, x19, x19, lsl #1
	lsl	x19, x19, #5
	fmov	d5, x19
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	mov.d	v5[1], x7
	mov.d	x7, v4[1]
	ldr	q7, [sp, #5120]                 ; 16-byte Reload
	add.2d	v3, v3, v7
	fmov	x19, d4
	add	x19, x19, x19, lsl #1
	lsl	x19, x19, #5
	fmov	d4, x19
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	mov.d	v4[1], x7
	mov.d	x7, v3[1]
	fmov	x19, d3
	add	x19, x19, x19, lsl #1
	lsl	x19, x19, #5
	fmov	d3, x19
	sshll.2d	v7, v1, #0
	msub	w6, w6, w2, w4
	and	x6, x6, #0xffff
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	mov.d	v3[1], x7
	dup.2d	v16, x6
	sshll.2d	v17, v0, #0
	add.2d	v3, v3, v16
	add.2d	v4, v4, v16
	add.2d	v5, v5, v16
	add.2d	v6, v6, v16
	ldr	q16, [sp, #5152]                ; 16-byte Reload
	bit.16b	v16, v6, v19
	str	q16, [sp, #5152]                ; 16-byte Spill
	ldr	q6, [sp, #5008]                 ; 16-byte Reload
	bsl.16b	v17, v5, v6
	ldr	q16, [sp, #5024]                ; 16-byte Reload
	bit.16b	v16, v4, v18
	ldr	q4, [sp, #5040]                 ; 16-byte Reload
	bsl.16b	v7, v3, v4
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	cmp	x5, #2053
	b.hs	LBB0_42
; %bb.44:                               ; %direct.true289
                                        ;   in Loop: Header=BB0_43 Depth=2
	ldr	q3, [sp, #4736]                 ; 16-byte Reload
	fmov	w5, s3
	shl.2d	v3, v7, #2
	dup.2d	v5, x17
	add.2d	v6, v5, v3
	movi.2d	v3, #0000000000000000
	tbz	w5, #0, LBB0_52
; %bb.45:                               ; %cond.load563
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x6, d6
	ldr	s3, [x6]
	and	w5, w5, #0xff
	tbnz	w5, #1, LBB0_53
LBB0_46:                                ; %else573
                                        ;   in Loop: Header=BB0_43 Depth=2
	shl.2d	v6, v16, #2
	add.2d	v6, v5, v6
	tbz	w5, #2, LBB0_54
LBB0_47:                                ; %cond.load575
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x6, d6
	ld1.s	{ v3 }[2], [x6]
	tbnz	w5, #3, LBB0_55
LBB0_48:                                ; %else585
                                        ;   in Loop: Header=BB0_43 Depth=2
	shl.2d	v6, v17, #2
	add.2d	v6, v5, v6
	tbz	w5, #4, LBB0_56
LBB0_49:                                ; %cond.load587
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x6, d6
	ld1.s	{ v4 }[0], [x6]
	tbnz	w5, #5, LBB0_57
LBB0_50:                                ; %else597
                                        ;   in Loop: Header=BB0_43 Depth=2
	ldr	q6, [sp, #5152]                 ; 16-byte Reload
	shl.2d	v6, v6, #2
	add.2d	v5, v5, v6
	tbz	w5, #6, LBB0_58
LBB0_51:                                ; %cond.load599
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x6, d5
	ld1.s	{ v4 }[2], [x6]
	tbz	w5, #7, LBB0_42
	b	LBB0_59
LBB0_52:                                ; %else567
                                        ;   in Loop: Header=BB0_43 Depth=2
	and	w5, w5, #0xff
	tbz	w5, #1, LBB0_46
LBB0_53:                                ; %cond.load569
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v3 }[1], [x6]
	shl.2d	v6, v16, #2
	add.2d	v6, v5, v6
	tbnz	w5, #2, LBB0_47
LBB0_54:                                ; %else579
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w5, #3, LBB0_48
LBB0_55:                                ; %cond.load581
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v3 }[3], [x6]
	shl.2d	v6, v17, #2
	add.2d	v6, v5, v6
	tbnz	w5, #4, LBB0_49
LBB0_56:                                ; %else591
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w5, #5, LBB0_50
LBB0_57:                                ; %cond.load593
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x6, v6[1]
	ld1.s	{ v4 }[1], [x6]
	ldr	q6, [sp, #5152]                 ; 16-byte Reload
	shl.2d	v6, v6, #2
	add.2d	v5, v5, v6
	tbnz	w5, #6, LBB0_51
LBB0_58:                                ; %else603
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w5, #7, LBB0_42
LBB0_59:                                ; %cond.load605
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x5, v5[1]
	ld1.s	{ v4 }[3], [x5]
	b	LBB0_42
LBB0_60:                                ; %direct.false277
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q29, [sp, #1072]                ; 16-byte Spill
	sshll.2d	v3, v1, #0
	sshll.2d	v4, v0, #0
	ldr	q5, [sp, #2240]                 ; 16-byte Reload
	ldr	q6, [sp, #1168]                 ; 16-byte Reload
	bit.16b	v6, v5, v4
	str	q6, [sp, #1168]                 ; 16-byte Spill
	ldr	q4, [sp, #2432]                 ; 16-byte Reload
	bif.16b	v4, v2, v3
	str	q4, [sp, #1056]                 ; 16-byte Spill
	bic.16b	v2, v2, v3
	ldr	x3, [sp, #280]                  ; 8-byte Reload
	ldp	q5, q4, [x3]
	fmov	x3, d2
	add	x3, x12, x3
	ldp	q3, q2, [x3]
	str	q5, [sp, #4688]                 ; 16-byte Spill
	fmul.4s	v3, v5, v3
	str	q4, [sp, #4704]                 ; 16-byte Spill
	fmul.4s	v2, v4, v2
	ldp	q7, q6, [x10, #32]
	ldr	q4, [x10, #8752]
	ldr	q5, [x10, #8736]
	str	q7, [sp, #4656]                 ; 16-byte Spill
	fmul.4s	v5, v7, v5
	str	q6, [sp, #4672]                 ; 16-byte Spill
	fmul.4s	v4, v6, v4
	mov.16b	v29, v0
	bsl.16b	v29, v2, v28
	ldp	q7, q6, [x10, #64]
	mov.16b	v28, v1
	bsl.16b	v28, v3, v11
	ldr	q2, [x10, #8784]
	bit.16b	v13, v4, v0
	ldr	q3, [x10, #8768]
	str	q7, [sp, #4624]                 ; 16-byte Spill
	fmul.4s	v3, v7, v3
	str	q6, [sp, #4640]                 ; 16-byte Spill
	fmul.4s	v2, v6, v2
	bit.16b	v30, v5, v1
	bit.16b	v9, v2, v0
	ldp	q5, q4, [x10, #96]
	bit.16b	v20, v3, v1
	ldr	q2, [x10, #8816]
	str	q4, [sp, #4608]                 ; 16-byte Spill
	fmul.4s	v2, v4, v2
	mov.16b	v11, v13
	mov.16b	v13, v30
	mov.16b	v30, v9
	mov.16b	v9, v20
	ldr	q20, [sp, #1248]                ; 16-byte Reload
	bit.16b	v20, v2, v0
	ldr	q2, [x10, #8800]
	str	q5, [sp, #4592]                 ; 16-byte Spill
	fmul.4s	v2, v5, v2
	bit.16b	v24, v2, v1
	ldr	q2, [sp, #2272]                 ; 16-byte Reload
	ldr	q3, [sp, #1152]                 ; 16-byte Reload
	bit.16b	v3, v2, v19
	str	q3, [sp, #1152]                 ; 16-byte Spill
	ldr	q2, [sp, #2256]                 ; 16-byte Reload
	ldr	q3, [sp, #1184]                 ; 16-byte Reload
	bit.16b	v3, v2, v18
	str	q3, [sp, #1184]                 ; 16-byte Spill
	mov	x3, x10
	mov	w4, #279                        ; =0x117
LBB0_61:                                ; %direct.true341
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x3, #128]!
	ldr	q3, [x3, #8704]
	ldr	q4, [x3, #8720]
	ldp	q5, q6, [x3, #16]
	fmul.4s	v4, v5, v4
	fmul.4s	v2, v2, v3
	fadd.4s	v2, v28, v2
	fadd.4s	v3, v29, v4
	ldr	q4, [x3, #8736]
	ldr	q5, [x3, #8752]
	ldp	q7, q16, [x3, #48]
	fmul.4s	v5, v7, v5
	fmul.4s	v4, v6, v4
	fadd.4s	v4, v13, v4
	fadd.4s	v5, v11, v5
	ldr	q6, [x3, #8768]
	ldr	q7, [x3, #8784]
	ldp	q17, q18, [x3, #80]
	fmul.4s	v7, v17, v7
	fmul.4s	v6, v16, v6
	fadd.4s	v6, v9, v6
	fadd.4s	v7, v30, v7
	ldr	q16, [x3, #112]
	ldr	q17, [x3, #8800]
	ldr	q19, [x3, #8816]
	fmul.4s	v16, v16, v19
	fmul.4s	v17, v18, v17
	fadd.4s	v17, v24, v17
	fadd.4s	v16, v20, v16
	bit.16b	v29, v3, v0
	bit.16b	v28, v2, v1
	bit.16b	v11, v5, v0
	bit.16b	v13, v4, v1
	bit.16b	v30, v7, v0
	bit.16b	v9, v6, v1
	bit.16b	v20, v16, v0
	bit.16b	v24, v17, v1
	sub	x5, x4, #275
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_61
; %bb.62:                               ; %direct.false342
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q16, [sp, #2720]                ; 16-byte Spill
	str	q17, [sp, #2736]                ; 16-byte Spill
	str	q29, [sp, #2752]                ; 16-byte Spill
	str	q28, [sp, #2768]                ; 16-byte Spill
	str	q11, [sp, #2784]                ; 16-byte Spill
	str	q13, [sp, #2800]                ; 16-byte Spill
	str	q30, [sp, #2816]                ; 16-byte Spill
	str	q9, [sp, #2832]                 ; 16-byte Spill
	str	q20, [sp, #1248]                ; 16-byte Spill
	str	q24, [sp, #1088]                ; 16-byte Spill
	ldr	q2, [x10, #11280]
	ldr	q3, [x10, #11264]
	ldr	q4, [sp, #4688]                 ; 16-byte Reload
	fmul.4s	v3, v4, v3
	ldr	q4, [sp, #4704]                 ; 16-byte Reload
	fmul.4s	v2, v4, v2
	ldr	q4, [x10, #11312]
	ldr	q5, [x10, #11296]
	ldr	q6, [sp, #4656]                 ; 16-byte Reload
	fmul.4s	v5, v6, v5
	ldr	q6, [sp, #4672]                 ; 16-byte Reload
	fmul.4s	v4, v6, v4
	ldr	q6, [x10, #11344]
	ldr	q7, [x10, #11328]
	ldr	q16, [sp, #4624]                ; 16-byte Reload
	fmul.4s	v7, v16, v7
	ldr	q16, [sp, #4640]                ; 16-byte Reload
	fmul.4s	v6, v16, v6
	ldr	q16, [x10, #11376]
	ldr	q17, [x10, #11360]
	ldr	q18, [sp, #4592]                ; 16-byte Reload
	fmul.4s	v17, v18, v17
	ldr	q18, [sp, #4608]                ; 16-byte Reload
	fmul.4s	v16, v18, v16
	bit.16b	v14, v2, v0
	bit.16b	v27, v3, v1
	bit.16b	v23, v4, v0
	ldr	q28, [sp, #3056]                ; 16-byte Reload
	bit.16b	v28, v5, v1
	bit.16b	v15, v6, v0
	ldr	q19, [sp, #3072]                ; 16-byte Reload
	bit.16b	v19, v7, v1
	ldr	q20, [sp, #1280]                ; 16-byte Reload
	bit.16b	v20, v16, v0
	ldr	q29, [sp, #1296]                ; 16-byte Reload
	bit.16b	v29, v17, v1
	mov	x3, x10
	mov	w4, #359                        ; =0x167
LBB0_63:                                ; %direct.true461
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x3, #128]!
	ldr	q3, [x3, #11264]
	ldr	q4, [x3, #11280]
	ldp	q5, q6, [x3, #16]
	fmul.4s	v4, v5, v4
	fmul.4s	v2, v2, v3
	fadd.4s	v2, v27, v2
	fadd.4s	v3, v14, v4
	ldr	q4, [x3, #11296]
	ldr	q5, [x3, #11312]
	ldp	q7, q16, [x3, #48]
	fmul.4s	v5, v7, v5
	fmul.4s	v4, v6, v4
	fadd.4s	v6, v28, v4
	fadd.4s	v5, v23, v5
	ldr	q4, [x3, #11328]
	ldr	q7, [x3, #11344]
	ldp	q17, q18, [x3, #80]
	fmul.4s	v7, v17, v7
	fmul.4s	v4, v16, v4
	fadd.4s	v16, v19, v4
	fadd.4s	v7, v15, v7
	ldr	q4, [x3, #112]
	ldr	q17, [x3, #11360]
	mov.16b	v24, v14
	mov.16b	v14, v27
	mov.16b	v11, v15
	mov.16b	v15, v19
	ldr	q19, [x3, #11376]
	fmul.4s	v19, v4, v19
	fmul.4s	v4, v18, v17
	fadd.4s	v4, v29, v4
	fadd.4s	v17, v20, v19
	mov.16b	v19, v15
	mov.16b	v27, v14
	mov.16b	v14, v0
	bsl.16b	v14, v3, v24
	bit.16b	v27, v2, v1
	bit.16b	v23, v5, v0
	bit.16b	v28, v6, v1
	mov.16b	v15, v0
	bsl.16b	v15, v7, v11
	bit.16b	v19, v16, v1
	bit.16b	v20, v17, v0
	bit.16b	v29, v4, v1
	sub	x5, x4, #355
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_63
; %bb.64:                               ; %direct.false462
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q17, [sp, #2688]                ; 16-byte Spill
	str	q4, [sp, #2704]                 ; 16-byte Spill
	str	q27, [sp, #2864]                ; 16-byte Spill
	str	q23, [sp, #2880]                ; 16-byte Spill
	str	q15, [sp, #2896]                ; 16-byte Spill
	str	q19, [sp, #3072]                ; 16-byte Spill
	str	q20, [sp, #1280]                ; 16-byte Spill
	str	q29, [sp, #1296]                ; 16-byte Spill
	ldr	q2, [x10, #13840]
	ldr	q3, [x10, #13824]
	ldr	q4, [sp, #4688]                 ; 16-byte Reload
	fmul.4s	v3, v4, v3
	ldr	q4, [sp, #4704]                 ; 16-byte Reload
	fmul.4s	v2, v4, v2
	ldr	q5, [x10, #13872]
	ldr	q6, [x10, #13856]
	ldr	q4, [sp, #4656]                 ; 16-byte Reload
	fmul.4s	v6, v4, v6
	ldr	q4, [sp, #4672]                 ; 16-byte Reload
	fmul.4s	v5, v4, v5
	ldr	q7, [x10, #13904]
	ldr	q16, [x10, #13888]
	ldr	q4, [sp, #4624]                 ; 16-byte Reload
	fmul.4s	v16, v4, v16
	ldr	q4, [sp, #4640]                 ; 16-byte Reload
	fmul.4s	v7, v4, v7
	ldr	q17, [x10, #13936]
	ldr	q18, [x10, #13920]
	ldr	q4, [sp, #4592]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	ldr	q4, [sp, #4608]                 ; 16-byte Reload
	fmul.4s	v17, v4, v17
	ldr	q15, [sp, #3120]                ; 16-byte Reload
	bit.16b	v15, v2, v0
	ldr	q13, [sp, #3136]                ; 16-byte Reload
	bit.16b	v13, v3, v1
	bit.16b	v12, v5, v0
	ldr	q23, [sp, #3152]                ; 16-byte Reload
	bit.16b	v23, v6, v1
	bit.16b	v22, v7, v0
	ldr	q20, [sp, #3168]                ; 16-byte Reload
	bit.16b	v20, v16, v1
	ldr	q4, [sp, #1312]                 ; 16-byte Reload
	bit.16b	v4, v17, v0
	ldr	q9, [sp, #1328]                 ; 16-byte Reload
	bit.16b	v9, v18, v1
	mov	x3, x10
	mov	w4, #439                        ; =0x1b7
	ldr	q30, [sp, #3408]                ; 16-byte Reload
	ldr	q29, [sp, #3296]                ; 16-byte Reload
LBB0_65:                                ; %direct.true581
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x3, #128]!
	ldr	q3, [x3, #13824]
	ldr	q5, [x3, #13840]
	ldp	q6, q7, [x3, #16]
	fmul.4s	v5, v6, v5
	fmul.4s	v2, v2, v3
	fadd.4s	v2, v13, v2
	fadd.4s	v3, v15, v5
	ldr	q5, [x3, #13856]
	ldr	q6, [x3, #13872]
	ldp	q16, q17, [x3, #48]
	fmul.4s	v6, v16, v6
	fmul.4s	v5, v7, v5
	fadd.4s	v5, v23, v5
	fadd.4s	v6, v12, v6
	ldr	q7, [x3, #13888]
	ldr	q16, [x3, #13904]
	ldp	q18, q19, [x3, #80]
	fmul.4s	v16, v18, v16
	fmul.4s	v7, v17, v7
	fadd.4s	v7, v20, v7
	fadd.4s	v16, v22, v16
	ldr	q17, [x3, #112]
	ldr	q18, [x3, #13920]
	mov.16b	v24, v12
	mov.16b	v27, v22
	mov.16b	v22, v20
	ldr	q20, [x3, #13936]
	fmul.4s	v17, v17, v20
	mov.16b	v20, v22
	fmul.4s	v18, v19, v18
	fadd.4s	v18, v9, v18
	fadd.4s	v17, v4, v17
	bit.16b	v15, v3, v0
	bit.16b	v13, v2, v1
	mov.16b	v12, v0
	bsl.16b	v12, v6, v24
	bit.16b	v23, v5, v1
	mov.16b	v22, v0
	bsl.16b	v22, v16, v27
	bit.16b	v20, v7, v1
	bit.16b	v4, v17, v0
	bit.16b	v9, v18, v1
	sub	x5, x4, #435
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_65
; %bb.66:                               ; %direct.false582
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q17, [sp, #2656]                ; 16-byte Spill
	str	q18, [sp, #2672]                ; 16-byte Spill
	str	q28, [sp, #3056]                ; 16-byte Spill
	str	q15, [sp, #3120]                ; 16-byte Spill
	str	q23, [sp, #3152]                ; 16-byte Spill
	str	q12, [sp, #2912]                ; 16-byte Spill
	str	q22, [sp, #2928]                ; 16-byte Spill
	str	q20, [sp, #3168]                ; 16-byte Spill
	str	q4, [sp, #1312]                 ; 16-byte Spill
	str	q9, [sp, #1328]                 ; 16-byte Spill
	ldr	q2, [x10, #16400]
	ldr	q3, [x10, #16384]
	ldr	q4, [sp, #4688]                 ; 16-byte Reload
	fmul.4s	v3, v4, v3
	ldr	q4, [sp, #4704]                 ; 16-byte Reload
	fmul.4s	v2, v4, v2
	ldr	q5, [x10, #16432]
	ldr	q6, [x10, #16416]
	ldr	q4, [sp, #4656]                 ; 16-byte Reload
	fmul.4s	v6, v4, v6
	ldr	q4, [sp, #4672]                 ; 16-byte Reload
	fmul.4s	v5, v4, v5
	ldr	q7, [x10, #16464]
	ldr	q16, [x10, #16448]
	ldr	q4, [sp, #4624]                 ; 16-byte Reload
	fmul.4s	v16, v4, v16
	ldr	q4, [sp, #4640]                 ; 16-byte Reload
	fmul.4s	v7, v4, v7
	ldr	q17, [x10, #16496]
	ldr	q18, [x10, #16480]
	ldr	q4, [sp, #4592]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	ldr	q4, [sp, #4608]                 ; 16-byte Reload
	fmul.4s	v17, v4, v17
	ldr	q12, [sp, #3216]                ; 16-byte Reload
	bit.16b	v12, v2, v0
	bit.16b	v21, v3, v1
	bit.16b	v10, v5, v0
	bit.16b	v26, v6, v1
	bit.16b	v25, v7, v0
	ldr	q20, [sp, #3232]                ; 16-byte Reload
	bit.16b	v20, v16, v1
	ldr	q22, [sp, #1344]                ; 16-byte Reload
	bit.16b	v22, v17, v0
	ldr	q4, [sp, #1360]                 ; 16-byte Reload
	bit.16b	v4, v18, v1
	mov	x3, x10
	mov	w4, #519                        ; =0x207
	ldr	q11, [sp, #3648]                ; 16-byte Reload
LBB0_67:                                ; %direct.true701
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x3, #128]!
	ldr	q3, [x3, #16384]
	ldr	q5, [x3, #16400]
	ldp	q6, q7, [x3, #16]
	fmul.4s	v5, v6, v5
	fmul.4s	v2, v2, v3
	fadd.4s	v2, v21, v2
	fadd.4s	v3, v12, v5
	ldr	q5, [x3, #16416]
	ldr	q6, [x3, #16432]
	ldp	q16, q17, [x3, #48]
	fmul.4s	v6, v16, v6
	fmul.4s	v5, v7, v5
	fadd.4s	v5, v26, v5
	fadd.4s	v6, v10, v6
	ldr	q7, [x3, #16448]
	ldr	q16, [x3, #16464]
	ldp	q18, q19, [x3, #80]
	fmul.4s	v16, v18, v16
	fmul.4s	v7, v17, v7
	fadd.4s	v7, v20, v7
	fadd.4s	v17, v25, v16
	ldr	q16, [x3, #112]
	ldr	q18, [x3, #16480]
	mov.16b	v23, v21
	mov.16b	v21, v10
	mov.16b	v10, v26
	mov.16b	v26, v25
	mov.16b	v25, v20
	ldr	q20, [x3, #16496]
	fmul.4s	v16, v16, v20
	mov.16b	v20, v25
	mov.16b	v25, v26
	mov.16b	v26, v10
	mov.16b	v10, v21
	fmul.4s	v18, v19, v18
	fadd.4s	v18, v4, v18
	fadd.4s	v16, v22, v16
	bit.16b	v12, v3, v0
	mov.16b	v21, v1
	bsl.16b	v21, v2, v23
	bit.16b	v10, v6, v0
	bit.16b	v26, v5, v1
	bit.16b	v25, v17, v0
	bit.16b	v20, v7, v1
	bit.16b	v22, v16, v0
	bit.16b	v4, v18, v1
	sub	x5, x4, #515
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_67
; %bb.68:                               ; %direct.false702
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q16, [sp, #2624]                ; 16-byte Spill
	str	q18, [sp, #2640]                ; 16-byte Spill
	str	q12, [sp, #3216]                ; 16-byte Spill
	str	q21, [sp, #2944]                ; 16-byte Spill
	str	q26, [sp, #2976]                ; 16-byte Spill
	str	q25, [sp, #2992]                ; 16-byte Spill
	str	q20, [sp, #3232]                ; 16-byte Spill
	str	q22, [sp, #1344]                ; 16-byte Spill
	str	q4, [sp, #1360]                 ; 16-byte Spill
	ldr	q2, [x10, #18960]
	ldr	q3, [x10, #18944]
	ldr	q4, [sp, #4688]                 ; 16-byte Reload
	fmul.4s	v3, v4, v3
	ldr	q4, [sp, #4704]                 ; 16-byte Reload
	fmul.4s	v2, v4, v2
	ldr	q5, [x10, #18992]
	ldr	q6, [x10, #18976]
	ldr	q4, [sp, #4656]                 ; 16-byte Reload
	fmul.4s	v6, v4, v6
	ldr	q4, [sp, #4672]                 ; 16-byte Reload
	fmul.4s	v5, v4, v5
	ldr	q7, [x10, #19024]
	ldr	q17, [x10, #19008]
	ldr	q4, [sp, #4624]                 ; 16-byte Reload
	fmul.4s	v17, v4, v17
	ldr	q4, [sp, #4640]                 ; 16-byte Reload
	fmul.4s	v7, v4, v7
	ldr	q18, [x10, #19056]
	ldr	q19, [x10, #19040]
	ldr	q4, [sp, #4592]                 ; 16-byte Reload
	fmul.4s	v19, v4, v19
	ldr	q4, [sp, #4608]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	bit.16b	v8, v2, v0
	ldr	q28, [sp, #3280]                ; 16-byte Reload
	bit.16b	v28, v3, v1
	bit.16b	v29, v5, v0
	ldr	q20, [sp, #3312]                ; 16-byte Reload
	bit.16b	v20, v6, v1
	ldr	q26, [sp, #3328]                ; 16-byte Reload
	bit.16b	v26, v7, v0
	ldr	q25, [sp, #3344]                ; 16-byte Reload
	bit.16b	v25, v17, v1
	ldr	q16, [sp, #1376]                ; 16-byte Reload
	bit.16b	v16, v18, v0
	ldr	q23, [sp, #1392]                ; 16-byte Reload
	bit.16b	v23, v19, v1
	mov	x3, x10
	mov	w4, #599                        ; =0x257
	ldr	q27, [sp, #4096]                ; 16-byte Reload
	ldr	q24, [sp, #1584]                ; 16-byte Reload
	ldr	q4, [sp, #1488]                 ; 16-byte Reload
	ldr	q15, [sp, #3664]                ; 16-byte Reload
LBB0_69:                                ; %direct.true821
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x3, #128]!
	ldr	q3, [x3, #18944]
	ldr	q5, [x3, #18960]
	ldp	q6, q7, [x3, #16]
	fmul.4s	v5, v6, v5
	fmul.4s	v2, v2, v3
	fadd.4s	v3, v28, v2
	fadd.4s	v5, v8, v5
	ldr	q2, [x3, #18976]
	ldr	q6, [x3, #18992]
	ldp	q17, q18, [x3, #48]
	fmul.4s	v6, v17, v6
	fmul.4s	v2, v7, v2
	fadd.4s	v7, v20, v2
	fadd.4s	v6, v29, v6
	ldr	q2, [x3, #19008]
	ldr	q17, [x3, #19024]
	mov.16b	v21, v8
	mov.16b	v8, v28
	mov.16b	v28, v20
	ldp	q19, q20, [x3, #80]
	fmul.4s	v17, v19, v17
	fmul.4s	v2, v18, v2
	fadd.4s	v18, v25, v2
	fadd.4s	v17, v26, v17
	ldr	q2, [x3, #112]
	ldr	q19, [x3, #19040]
	ldr	q22, [x3, #19056]
	fmul.4s	v22, v2, v22
	fmul.4s	v2, v20, v19
	mov.16b	v20, v28
	mov.16b	v28, v8
	fadd.4s	v2, v23, v2
	fadd.4s	v19, v16, v22
	mov.16b	v8, v0
	bsl.16b	v8, v5, v21
	bit.16b	v28, v3, v1
	bit.16b	v29, v6, v0
	bit.16b	v20, v7, v1
	bit.16b	v26, v17, v0
	bit.16b	v25, v18, v1
	bit.16b	v16, v19, v0
	bit.16b	v23, v2, v1
	sub	x5, x4, #595
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_69
; %bb.70:                               ; %direct.false822
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q19, [sp, #2592]                ; 16-byte Spill
	str	q2, [sp, #2608]                 ; 16-byte Spill
	str	q14, [sp, #2848]                ; 16-byte Spill
	str	q8, [sp, #3008]                 ; 16-byte Spill
	str	q28, [sp, #3280]                ; 16-byte Spill
	str	q29, [sp, #3296]                ; 16-byte Spill
	str	q20, [sp, #3312]                ; 16-byte Spill
	str	q26, [sp, #3328]                ; 16-byte Spill
	str	q25, [sp, #3344]                ; 16-byte Spill
	str	q16, [sp, #1376]                ; 16-byte Spill
	str	q23, [sp, #1392]                ; 16-byte Spill
	ldr	q3, [x10, #21520]
	ldr	q5, [x10, #21504]
	ldr	q2, [sp, #4688]                 ; 16-byte Reload
	fmul.4s	v5, v2, v5
	ldr	q2, [sp, #4704]                 ; 16-byte Reload
	fmul.4s	v3, v2, v3
	ldr	q6, [x10, #21552]
	ldr	q7, [x10, #21536]
	ldr	q2, [sp, #4656]                 ; 16-byte Reload
	fmul.4s	v7, v2, v7
	ldr	q2, [sp, #4672]                 ; 16-byte Reload
	fmul.4s	v6, v2, v6
	ldr	q17, [x10, #21584]
	ldr	q18, [x10, #21568]
	ldr	q2, [sp, #4624]                 ; 16-byte Reload
	fmul.4s	v18, v2, v18
	ldr	q2, [sp, #4640]                 ; 16-byte Reload
	fmul.4s	v17, v2, v17
	ldr	q19, [x10, #21616]
	ldr	q20, [x10, #21600]
	ldr	q2, [sp, #4592]                 ; 16-byte Reload
	fmul.4s	v20, v2, v20
	ldr	q2, [sp, #4608]                 ; 16-byte Reload
	fmul.4s	v19, v2, v19
	bit.16b	v31, v3, v0
	ldr	q26, [sp, #3392]                ; 16-byte Reload
	bit.16b	v26, v5, v1
	bit.16b	v30, v6, v0
	ldr	q9, [sp, #3424]                 ; 16-byte Reload
	bit.16b	v9, v7, v1
	ldr	q29, [sp, #3440]                ; 16-byte Reload
	bit.16b	v29, v17, v0
	ldr	q28, [sp, #3456]                ; 16-byte Reload
	bit.16b	v28, v18, v1
	ldr	q2, [sp, #1408]                 ; 16-byte Reload
	bit.16b	v2, v19, v0
	ldr	q8, [sp, #1424]                 ; 16-byte Reload
	bit.16b	v8, v20, v1
	mov	x3, x10
	mov	w4, #679                        ; =0x2a7
	ldr	q16, [sp, #4400]                ; 16-byte Reload
	ldr	q25, [sp, #4016]                ; 16-byte Reload
	ldr	q23, [sp, #3888]                ; 16-byte Reload
	ldr	q12, [sp, #3872]                ; 16-byte Reload
LBB0_71:                                ; %direct.true941
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x3, #128]!
	ldr	q5, [x3, #21504]
	ldr	q6, [x3, #21520]
	ldp	q7, q17, [x3, #16]
	fmul.4s	v6, v7, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v3, v26, v3
	fadd.4s	v5, v31, v6
	ldr	q6, [x3, #21536]
	ldr	q7, [x3, #21552]
	ldp	q18, q19, [x3, #48]
	fmul.4s	v7, v18, v7
	fmul.4s	v6, v17, v6
	fadd.4s	v6, v9, v6
	fadd.4s	v7, v30, v7
	ldr	q17, [x3, #21568]
	ldr	q18, [x3, #21584]
	ldp	q20, q22, [x3, #80]
	mov.16b	v21, v31
	mov.16b	v31, v26
	fmul.4s	v18, v20, v18
	fmul.4s	v17, v19, v17
	fadd.4s	v19, v28, v17
	fadd.4s	v18, v29, v18
	ldr	q17, [x3, #112]
	ldr	q20, [x3, #21600]
	ldr	q26, [x3, #21616]
	fmul.4s	v17, v17, v26
	fmul.4s	v20, v22, v20
	mov.16b	v26, v31
	fadd.4s	v20, v8, v20
	fadd.4s	v17, v2, v17
	mov.16b	v31, v0
	bsl.16b	v31, v5, v21
	bit.16b	v26, v3, v1
	bit.16b	v30, v7, v0
	bit.16b	v9, v6, v1
	bit.16b	v29, v18, v0
	bit.16b	v28, v19, v1
	bit.16b	v2, v17, v0
	bit.16b	v8, v20, v1
	sub	x5, x4, #675
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_71
; %bb.72:                               ; %direct.false942
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q17, [sp, #2560]                ; 16-byte Spill
	str	q20, [sp, #2576]                ; 16-byte Spill
	str	q13, [sp, #3136]                ; 16-byte Spill
	str	q10, [sp, #2960]                ; 16-byte Spill
	str	q31, [sp, #3024]                ; 16-byte Spill
	str	q26, [sp, #3392]                ; 16-byte Spill
	str	q30, [sp, #3408]                ; 16-byte Spill
	str	q9, [sp, #3424]                 ; 16-byte Spill
	str	q29, [sp, #3440]                ; 16-byte Spill
	str	q28, [sp, #3456]                ; 16-byte Spill
	str	q2, [sp, #1408]                 ; 16-byte Spill
	str	q8, [sp, #1424]                 ; 16-byte Spill
	ldr	q3, [x10, #24080]
	ldr	q5, [x10, #24064]
	ldr	q2, [sp, #4688]                 ; 16-byte Reload
	fmul.4s	v5, v2, v5
	ldr	q2, [sp, #4704]                 ; 16-byte Reload
	fmul.4s	v3, v2, v3
	ldr	q6, [x10, #24112]
	ldr	q7, [x10, #24096]
	ldr	q2, [sp, #4656]                 ; 16-byte Reload
	fmul.4s	v7, v2, v7
	ldr	q2, [sp, #4672]                 ; 16-byte Reload
	fmul.4s	v6, v2, v6
	ldr	q18, [x10, #24144]
	ldr	q19, [x10, #24128]
	ldr	q2, [sp, #4624]                 ; 16-byte Reload
	fmul.4s	v19, v2, v19
	ldr	q2, [sp, #4640]                 ; 16-byte Reload
	fmul.4s	v18, v2, v18
	ldr	q22, [x10, #24176]
	ldr	q26, [x10, #24160]
	ldr	q2, [sp, #4592]                 ; 16-byte Reload
	fmul.4s	v26, v2, v26
	ldr	q2, [sp, #4608]                 ; 16-byte Reload
	fmul.4s	v22, v2, v22
	ldr	q8, [sp, #3504]                 ; 16-byte Reload
	bit.16b	v8, v3, v0
	ldr	q14, [sp, #3520]                ; 16-byte Reload
	bit.16b	v14, v5, v1
	ldr	q9, [sp, #3536]                 ; 16-byte Reload
	bit.16b	v9, v6, v0
	ldr	q31, [sp, #3552]                ; 16-byte Reload
	bit.16b	v31, v7, v1
	ldr	q30, [sp, #3568]                ; 16-byte Reload
	bit.16b	v30, v18, v0
	ldr	q20, [sp, #3584]                ; 16-byte Reload
	bit.16b	v20, v19, v1
	ldr	q17, [sp, #1440]                ; 16-byte Reload
	bit.16b	v17, v22, v0
	ldr	q21, [sp, #1456]                ; 16-byte Reload
	bit.16b	v21, v26, v1
	mov	x3, x10
	mov	w4, #759                        ; =0x2f7
	ldr	q2, [sp, #4416]                 ; 16-byte Reload
LBB0_73:                                ; %direct.true1061
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x3, #128]!
	ldr	q5, [x3, #24064]
	ldr	q6, [x3, #24080]
	ldp	q7, q18, [x3, #16]
	fmul.4s	v6, v7, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v3, v14, v3
	fadd.4s	v5, v8, v6
	ldr	q6, [x3, #24096]
	ldr	q7, [x3, #24112]
	ldp	q19, q22, [x3, #48]
	fmul.4s	v7, v19, v7
	fmul.4s	v6, v18, v6
	fadd.4s	v6, v31, v6
	fadd.4s	v7, v9, v7
	ldr	q18, [x3, #24128]
	ldr	q19, [x3, #24144]
	ldp	q26, q28, [x3, #80]
	fmul.4s	v19, v26, v19
	fmul.4s	v18, v22, v18
	fadd.4s	v18, v20, v18
	fadd.4s	v19, v30, v19
	ldr	q22, [x3, #112]
	ldr	q26, [x3, #24160]
	ldr	q29, [x3, #24176]
	fmul.4s	v29, v22, v29
	fmul.4s	v22, v28, v26
	fadd.4s	v22, v21, v22
	fadd.4s	v26, v17, v29
	bit.16b	v8, v5, v0
	bit.16b	v14, v3, v1
	bit.16b	v9, v7, v0
	bit.16b	v31, v6, v1
	bit.16b	v30, v19, v0
	bit.16b	v20, v18, v1
	bit.16b	v17, v26, v0
	bit.16b	v21, v22, v1
	sub	x5, x4, #755
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_73
; %bb.74:                               ; %direct.false1062
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q26, [sp, #2528]                ; 16-byte Spill
	str	q22, [sp, #2544]                ; 16-byte Spill
	str	q8, [sp, #3504]                 ; 16-byte Spill
	str	q14, [sp, #3520]                ; 16-byte Spill
	str	q9, [sp, #3536]                 ; 16-byte Spill
	str	q31, [sp, #3552]                ; 16-byte Spill
	str	q30, [sp, #3568]                ; 16-byte Spill
	str	q20, [sp, #3584]                ; 16-byte Spill
	str	q17, [sp, #1440]                ; 16-byte Spill
	str	q21, [sp, #1456]                ; 16-byte Spill
	ldr	q3, [x10, #26640]
	ldr	q5, [x10, #26624]
	ldr	q6, [sp, #4688]                 ; 16-byte Reload
	fmul.4s	v5, v6, v5
	ldr	q6, [sp, #4704]                 ; 16-byte Reload
	fmul.4s	v3, v6, v3
	ldr	q6, [x10, #26672]
	ldr	q7, [x10, #26656]
	ldr	q17, [sp, #4656]                ; 16-byte Reload
	fmul.4s	v7, v17, v7
	ldr	q17, [sp, #4672]                ; 16-byte Reload
	fmul.4s	v6, v17, v6
	ldr	q18, [x10, #26704]
	ldr	q19, [x10, #26688]
	ldr	q17, [sp, #4624]                ; 16-byte Reload
	fmul.4s	v19, v17, v19
	ldr	q17, [sp, #4640]                ; 16-byte Reload
	fmul.4s	v18, v17, v18
	ldr	q26, [x10, #26736]
	ldr	q28, [x10, #26720]
	ldr	q17, [sp, #4592]                ; 16-byte Reload
	fmul.4s	v28, v17, v28
	ldr	q17, [sp, #4608]                ; 16-byte Reload
	fmul.4s	v26, v17, v26
	ldr	q10, [sp, #3632]                ; 16-byte Reload
	bit.16b	v10, v3, v0
	bit.16b	v11, v5, v1
	bit.16b	v15, v6, v0
	ldr	q13, [sp, #3680]                ; 16-byte Reload
	bit.16b	v13, v7, v1
	ldr	q8, [sp, #3696]                 ; 16-byte Reload
	bit.16b	v8, v18, v0
	ldr	q29, [sp, #3712]                ; 16-byte Reload
	bit.16b	v29, v19, v1
	ldr	q22, [sp, #1472]                ; 16-byte Reload
	bit.16b	v22, v26, v0
	bit.16b	v4, v28, v1
	mov	x3, x10
	mov	w4, #839                        ; =0x347
	ldr	q17, [sp, #4384]                ; 16-byte Reload
	ldr	q20, [sp, #4368]                ; 16-byte Reload
	ldr	q9, [sp, #4000]                 ; 16-byte Reload
LBB0_75:                                ; %direct.true1181
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x3, #128]!
	ldr	q5, [x3, #26624]
	ldr	q6, [x3, #26640]
	ldp	q7, q18, [x3, #16]
	fmul.4s	v6, v7, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v3, v11, v3
	fadd.4s	v5, v10, v6
	ldr	q6, [x3, #26656]
	ldr	q7, [x3, #26672]
	ldp	q19, q26, [x3, #48]
	fmul.4s	v7, v19, v7
	fmul.4s	v6, v18, v6
	fadd.4s	v18, v13, v6
	fadd.4s	v7, v15, v7
	ldr	q6, [x3, #26688]
	ldr	q19, [x3, #26704]
	ldp	q28, q30, [x3, #80]
	fmul.4s	v19, v28, v19
	fmul.4s	v6, v26, v6
	fadd.4s	v26, v29, v6
	fadd.4s	v19, v8, v19
	ldr	q6, [x3, #112]
	ldr	q28, [x3, #26720]
	ldr	q31, [x3, #26736]
	fmul.4s	v31, v6, v31
	fmul.4s	v6, v30, v28
	fadd.4s	v6, v4, v6
	fadd.4s	v21, v22, v31
	bit.16b	v10, v5, v0
	bit.16b	v11, v3, v1
	bit.16b	v15, v7, v0
	bit.16b	v13, v18, v1
	bit.16b	v8, v19, v0
	bit.16b	v29, v26, v1
	bit.16b	v22, v21, v0
	bit.16b	v4, v6, v1
	sub	x5, x4, #835
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_75
; %bb.76:                               ; %direct.false1182
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q21, [sp, #1040]                ; 16-byte Spill
	str	q6, [sp, #2512]                 ; 16-byte Spill
	str	q10, [sp, #3632]                ; 16-byte Spill
	str	q11, [sp, #3648]                ; 16-byte Spill
	str	q15, [sp, #3664]                ; 16-byte Spill
	str	q13, [sp, #3680]                ; 16-byte Spill
	str	q8, [sp, #3696]                 ; 16-byte Spill
	str	q29, [sp, #3712]                ; 16-byte Spill
	str	q22, [sp, #1472]                ; 16-byte Spill
	str	q4, [sp, #1488]                 ; 16-byte Spill
	ldr	q3, [x10, #29200]
	ldr	q5, [x10, #29184]
	ldr	q4, [sp, #4688]                 ; 16-byte Reload
	fmul.4s	v5, v4, v5
	ldr	q4, [sp, #4704]                 ; 16-byte Reload
	fmul.4s	v3, v4, v3
	ldr	q7, [x10, #29232]
	ldr	q18, [x10, #29216]
	ldr	q4, [sp, #4656]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	ldr	q4, [sp, #4672]                 ; 16-byte Reload
	fmul.4s	v7, v4, v7
	ldr	q19, [x10, #29264]
	ldr	q26, [x10, #29248]
	ldr	q4, [sp, #4624]                 ; 16-byte Reload
	fmul.4s	v26, v4, v26
	ldr	q4, [sp, #4640]                 ; 16-byte Reload
	fmul.4s	v19, v4, v19
	ldr	q28, [x10, #29296]
	ldr	q30, [x10, #29280]
	ldr	q4, [sp, #4592]                 ; 16-byte Reload
	fmul.4s	v30, v4, v30
	ldr	q4, [sp, #4608]                 ; 16-byte Reload
	fmul.4s	v28, v4, v28
	ldr	q21, [sp, #3760]                ; 16-byte Reload
	bit.16b	v21, v3, v0
	ldr	q11, [sp, #3776]                ; 16-byte Reload
	bit.16b	v11, v5, v1
	ldr	q15, [sp, #3792]                ; 16-byte Reload
	bit.16b	v15, v7, v0
	ldr	q14, [sp, #3808]                ; 16-byte Reload
	bit.16b	v14, v18, v1
	ldr	q13, [sp, #3824]                ; 16-byte Reload
	bit.16b	v13, v19, v0
	ldr	q10, [sp, #3840]                ; 16-byte Reload
	bit.16b	v10, v26, v1
	ldr	q6, [sp, #1504]                 ; 16-byte Reload
	bit.16b	v6, v28, v0
	ldr	q7, [sp, #1520]                 ; 16-byte Reload
	bit.16b	v7, v30, v1
	mov	x3, x10
	mov	w4, #919                        ; =0x397
	ldr	q22, [sp, #1824]                ; 16-byte Reload
	ldr	q29, [sp, #1792]                ; 16-byte Reload
LBB0_77:                                ; %direct.true1301
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x3, #128]!
	ldr	q5, [x3, #29184]
	mov.16b	v4, v7
	ldr	q7, [x3, #29200]
	ldp	q18, q19, [x3, #16]
	fmul.4s	v7, v18, v7
	fmul.4s	v3, v3, v5
	fadd.4s	v3, v11, v3
	fadd.4s	v5, v21, v7
	ldr	q7, [x3, #29216]
	ldr	q18, [x3, #29232]
	ldp	q26, q28, [x3, #48]
	fmul.4s	v18, v26, v18
	fmul.4s	v7, v19, v7
	fadd.4s	v26, v14, v7
	fadd.4s	v18, v15, v18
	ldr	q7, [x3, #29248]
	ldr	q19, [x3, #29264]
	ldp	q30, q31, [x3, #80]
	fmul.4s	v19, v30, v19
	fmul.4s	v7, v28, v7
	fadd.4s	v28, v10, v7
	fadd.4s	v30, v13, v19
	ldr	q7, [x3, #112]
	ldr	q19, [x3, #29280]
	ldr	q8, [x3, #29296]
	fmul.4s	v8, v7, v8
	fmul.4s	v7, v31, v19
	fadd.4s	v19, v4, v7
	mov.16b	v7, v4
	fadd.4s	v4, v6, v8
	bit.16b	v21, v5, v0
	bit.16b	v11, v3, v1
	bit.16b	v15, v18, v0
	bit.16b	v14, v26, v1
	bit.16b	v13, v30, v0
	bit.16b	v10, v28, v1
	bit.16b	v6, v4, v0
	bit.16b	v7, v19, v1
	sub	x5, x4, #915
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_77
; %bb.78:                               ; %direct.false1302
                                        ;   in Loop: Header=BB0_22 Depth=1
	stp	q4, q19, [sp, #1008]            ; 32-byte Folded Spill
	str	q21, [sp, #3760]                ; 16-byte Spill
	str	q11, [sp, #3776]                ; 16-byte Spill
	str	q15, [sp, #3792]                ; 16-byte Spill
	str	q14, [sp, #3808]                ; 16-byte Spill
	str	q13, [sp, #3824]                ; 16-byte Spill
	str	q10, [sp, #3840]                ; 16-byte Spill
	str	q6, [sp, #1504]                 ; 16-byte Spill
	str	q7, [sp, #1520]                 ; 16-byte Spill
	ldr	q3, [x10, #31760]
	ldr	q5, [x10, #31744]
	ldr	q4, [sp, #4688]                 ; 16-byte Reload
	fmul.4s	v5, v4, v5
	ldr	q4, [sp, #4704]                 ; 16-byte Reload
	fmul.4s	v3, v4, v3
	ldr	q18, [x10, #31792]
	ldr	q26, [x10, #31776]
	ldr	q4, [sp, #4656]                 ; 16-byte Reload
	fmul.4s	v26, v4, v26
	ldr	q4, [sp, #4672]                 ; 16-byte Reload
	fmul.4s	v18, v4, v18
	ldr	q28, [x10, #31824]
	ldr	q30, [x10, #31808]
	ldr	q4, [sp, #4624]                 ; 16-byte Reload
	fmul.4s	v30, v4, v30
	ldr	q4, [sp, #4640]                 ; 16-byte Reload
	fmul.4s	v28, v4, v28
	ldr	q31, [x10, #31856]
	ldr	q8, [x10, #31840]
	ldr	q4, [sp, #4592]                 ; 16-byte Reload
	fmul.4s	v8, v4, v8
	ldr	q4, [sp, #4608]                 ; 16-byte Reload
	fmul.4s	v31, v4, v31
	ldr	q11, [sp, #3856]                ; 16-byte Reload
	bit.16b	v11, v3, v0
	bit.16b	v12, v5, v1
	bit.16b	v23, v18, v0
	ldr	q21, [sp, #3904]                ; 16-byte Reload
	bit.16b	v21, v26, v1
	ldr	q15, [sp, #3920]                ; 16-byte Reload
	bit.16b	v15, v28, v0
	ldr	q19, [sp, #3936]                ; 16-byte Reload
	bit.16b	v19, v30, v1
	ldr	q7, [sp, #1568]                 ; 16-byte Reload
	bit.16b	v7, v31, v0
	bit.16b	v24, v8, v1
	mov	x3, x10
	mov	w4, #999                        ; =0x3e7
	ldr	q14, [sp, #4448]                ; 16-byte Reload
	ldr	q6, [sp, #4288]                 ; 16-byte Reload
LBB0_79:                                ; %direct.true1421
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x3, #128]!
	ldr	q5, [x3, #31744]
	ldr	q18, [x3, #31760]
	ldp	q26, q28, [x3, #16]
	fmul.4s	v18, v26, v18
	fmul.4s	v3, v3, v5
	fadd.4s	v5, v12, v3
	fadd.4s	v18, v11, v18
	ldr	q3, [x3, #31776]
	ldr	q26, [x3, #31792]
	ldp	q30, q31, [x3, #48]
	fmul.4s	v26, v30, v26
	fmul.4s	v3, v28, v3
	fadd.4s	v28, v21, v3
	fadd.4s	v26, v23, v26
	ldr	q3, [x3, #31808]
	ldr	q30, [x3, #31824]
	ldp	q8, q10, [x3, #80]
	fmul.4s	v30, v8, v30
	fmul.4s	v3, v31, v3
	fadd.4s	v31, v19, v3
	fadd.4s	v30, v15, v30
	ldr	q3, [x3, #112]
	ldr	q8, [x3, #31840]
	ldr	q13, [x3, #31856]
	fmul.4s	v13, v3, v13
	fmul.4s	v3, v10, v8
	fadd.4s	v3, v24, v3
	fadd.4s	v4, v7, v13
	bit.16b	v11, v18, v0
	bit.16b	v12, v5, v1
	bit.16b	v23, v26, v0
	bit.16b	v21, v28, v1
	bit.16b	v15, v30, v0
	bit.16b	v19, v31, v1
	bit.16b	v7, v4, v0
	bit.16b	v24, v3, v1
	sub	x5, x4, #995
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_79
; %bb.80:                               ; %direct.false1422
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q3, [sp, #992]                  ; 16-byte Spill
	str	q11, [sp, #3856]                ; 16-byte Spill
	str	q12, [sp, #3872]                ; 16-byte Spill
	str	q23, [sp, #3888]                ; 16-byte Spill
	str	q21, [sp, #3904]                ; 16-byte Spill
	str	q15, [sp, #3920]                ; 16-byte Spill
	str	q19, [sp, #3936]                ; 16-byte Spill
	str	q7, [sp, #1568]                 ; 16-byte Spill
	str	q24, [sp, #1584]                ; 16-byte Spill
	ldr	q5, [x10, #34320]
	ldr	q18, [x10, #34304]
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	fmul.4s	v18, v3, v18
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	fmul.4s	v5, v3, v5
	ldr	q26, [x10, #34352]
	ldr	q28, [x10, #34336]
	ldr	q3, [sp, #4656]                 ; 16-byte Reload
	fmul.4s	v28, v3, v28
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	fmul.4s	v26, v3, v26
	ldr	q30, [x10, #34384]
	ldr	q31, [x10, #34368]
	ldr	q3, [sp, #4624]                 ; 16-byte Reload
	fmul.4s	v31, v3, v31
	ldr	q3, [sp, #4640]                 ; 16-byte Reload
	fmul.4s	v30, v3, v30
	ldr	q8, [x10, #34416]
	ldr	q10, [x10, #34400]
	ldr	q3, [sp, #4592]                 ; 16-byte Reload
	fmul.4s	v10, v3, v10
	ldr	q3, [sp, #4608]                 ; 16-byte Reload
	fmul.4s	v8, v3, v8
	ldr	q12, [sp, #3952]                ; 16-byte Reload
	bit.16b	v12, v5, v0
	ldr	q11, [sp, #3968]                ; 16-byte Reload
	bit.16b	v11, v18, v1
	ldr	q13, [sp, #3984]                ; 16-byte Reload
	bit.16b	v13, v26, v0
	bit.16b	v9, v28, v1
	bit.16b	v25, v30, v0
	ldr	q23, [sp, #4032]                ; 16-byte Reload
	bit.16b	v23, v31, v1
	ldr	q21, [sp, #1632]                ; 16-byte Reload
	bit.16b	v21, v8, v0
	ldr	q3, [sp, #1648]                 ; 16-byte Reload
	bit.16b	v3, v10, v1
	mov	x3, x10
	mov	w4, #1079                       ; =0x437
	ldr	q7, [sp, #4496]                 ; 16-byte Reload
	ldr	q19, [sp, #1872]                ; 16-byte Reload
LBB0_81:                                ; %direct.true1541
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q5, [x3, #128]!
	ldr	q18, [x3, #34304]
	ldr	q26, [x3, #34320]
	ldp	q28, q30, [x3, #16]
	fmul.4s	v26, v28, v26
	fmul.4s	v5, v5, v18
	fadd.4s	v5, v11, v5
	fadd.4s	v28, v12, v26
	ldr	q18, [x3, #34336]
	ldr	q26, [x3, #34352]
	ldp	q31, q8, [x3, #48]
	fmul.4s	v26, v31, v26
	fmul.4s	v18, v30, v18
	fadd.4s	v30, v9, v18
	fadd.4s	v31, v13, v26
	ldr	q18, [x3, #34368]
	ldr	q26, [x3, #34384]
	mov.16b	v24, v13
	ldp	q10, q13, [x3, #80]
	fmul.4s	v26, v10, v26
	fmul.4s	v18, v8, v18
	fadd.4s	v8, v23, v18
	fadd.4s	v10, v25, v26
	ldr	q18, [x3, #112]
	ldr	q26, [x3, #34400]
	ldr	q15, [x3, #34416]
	fmul.4s	v15, v18, v15
	fmul.4s	v18, v13, v26
	mov.16b	v13, v24
	fadd.4s	v18, v3, v18
	fadd.4s	v24, v21, v15
	bit.16b	v12, v28, v0
	bit.16b	v11, v5, v1
	bit.16b	v13, v31, v0
	bit.16b	v9, v30, v1
	bit.16b	v25, v10, v0
	bit.16b	v23, v8, v1
	bit.16b	v21, v24, v0
	bit.16b	v3, v18, v1
	sub	x5, x4, #1075
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_81
; %bb.82:                               ; %direct.false1542
                                        ;   in Loop: Header=BB0_22 Depth=1
	stp	q24, q18, [sp, #944]            ; 32-byte Folded Spill
	str	q4, [sp, #976]                  ; 16-byte Spill
	str	q12, [sp, #3952]                ; 16-byte Spill
	str	q11, [sp, #3968]                ; 16-byte Spill
	str	q13, [sp, #3984]                ; 16-byte Spill
	str	q9, [sp, #4000]                 ; 16-byte Spill
	str	q25, [sp, #4016]                ; 16-byte Spill
	str	q23, [sp, #4032]                ; 16-byte Spill
	str	q21, [sp, #1632]                ; 16-byte Spill
	str	q3, [sp, #1648]                 ; 16-byte Spill
	ldr	q5, [x10, #36880]
	ldr	q28, [x10, #36864]
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	fmul.4s	v28, v3, v28
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	fmul.4s	v5, v3, v5
	ldr	q30, [x10, #36912]
	ldr	q31, [x10, #36896]
	ldr	q3, [sp, #4656]                 ; 16-byte Reload
	fmul.4s	v31, v3, v31
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	fmul.4s	v30, v3, v30
	ldr	q8, [x10, #36944]
	ldr	q10, [x10, #36928]
	ldr	q3, [sp, #4624]                 ; 16-byte Reload
	fmul.4s	v10, v3, v10
	ldr	q3, [sp, #4640]                 ; 16-byte Reload
	fmul.4s	v8, v3, v8
	ldr	q13, [x10, #36976]
	ldr	q15, [x10, #36960]
	ldr	q3, [sp, #4592]                 ; 16-byte Reload
	fmul.4s	v15, v3, v15
	ldr	q3, [sp, #4608]                 ; 16-byte Reload
	fmul.4s	v13, v3, v13
	ldr	q9, [sp, #4064]                 ; 16-byte Reload
	bit.16b	v9, v5, v0
	ldr	q25, [sp, #4080]                ; 16-byte Reload
	bit.16b	v25, v28, v1
	bit.16b	v27, v30, v0
	ldr	q12, [sp, #4112]                ; 16-byte Reload
	bit.16b	v12, v31, v1
	ldr	q11, [sp, #4128]                ; 16-byte Reload
	bit.16b	v11, v8, v0
	ldr	q26, [sp, #4144]                ; 16-byte Reload
	bit.16b	v26, v10, v1
	ldr	q24, [sp, #1680]                ; 16-byte Reload
	bit.16b	v24, v13, v0
	ldr	q18, [sp, #1696]                ; 16-byte Reload
	bit.16b	v18, v15, v1
	mov	x3, x10
	mov	w4, #1159                       ; =0x487
	ldr	q3, [sp, #4272]                 ; 16-byte Reload
LBB0_83:                                ; %direct.true1661
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q5, [x3, #128]!
	ldr	q28, [x3, #36864]
	ldr	q30, [x3, #36880]
	ldp	q31, q8, [x3, #16]
	fmul.4s	v30, v31, v30
	fmul.4s	v5, v5, v28
	fadd.4s	v31, v25, v5
	fadd.4s	v30, v9, v30
	ldr	q5, [x3, #36896]
	ldr	q28, [x3, #36912]
	ldp	q10, q13, [x3, #48]
	fmul.4s	v28, v10, v28
	fmul.4s	v5, v8, v5
	fadd.4s	v8, v12, v5
	fadd.4s	v10, v27, v28
	ldr	q5, [x3, #36928]
	ldr	q28, [x3, #36944]
	ldp	q15, q21, [x3, #80]
	fmul.4s	v28, v15, v28
	fmul.4s	v5, v13, v5
	fadd.4s	v13, v26, v5
	fadd.4s	v15, v11, v28
	ldr	q5, [x3, #112]
	ldr	q28, [x3, #36960]
	ldr	q23, [x3, #36976]
	fmul.4s	v5, v5, v23
	fmul.4s	v21, v21, v28
	fadd.4s	v4, v18, v21
	fadd.4s	v5, v24, v5
	bit.16b	v9, v30, v0
	bit.16b	v25, v31, v1
	bit.16b	v27, v10, v0
	bit.16b	v12, v8, v1
	bit.16b	v11, v15, v0
	bit.16b	v26, v13, v1
	bit.16b	v24, v5, v0
	bit.16b	v18, v4, v1
	sub	x5, x4, #1155
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_83
; %bb.84:                               ; %direct.false1662
                                        ;   in Loop: Header=BB0_22 Depth=1
	stp	q5, q4, [sp, #912]              ; 32-byte Folded Spill
	str	q9, [sp, #4064]                 ; 16-byte Spill
	str	q25, [sp, #4080]                ; 16-byte Spill
	str	q27, [sp, #4096]                ; 16-byte Spill
	str	q12, [sp, #4112]                ; 16-byte Spill
	str	q11, [sp, #4128]                ; 16-byte Spill
	str	q26, [sp, #4144]                ; 16-byte Spill
	str	q24, [sp, #1680]                ; 16-byte Spill
	str	q18, [sp, #1696]                ; 16-byte Spill
	ldr	q21, [x10, #39440]
	ldr	q23, [x10, #39424]
	ldr	q4, [sp, #4688]                 ; 16-byte Reload
	fmul.4s	v23, v4, v23
	ldr	q4, [sp, #4704]                 ; 16-byte Reload
	fmul.4s	v21, v4, v21
	ldr	q30, [x10, #39472]
	ldr	q31, [x10, #39456]
	ldr	q4, [sp, #4656]                 ; 16-byte Reload
	fmul.4s	v31, v4, v31
	ldr	q4, [sp, #4672]                 ; 16-byte Reload
	fmul.4s	v30, v4, v30
	ldr	q8, [x10, #39504]
	ldr	q10, [x10, #39488]
	ldr	q4, [sp, #4624]                 ; 16-byte Reload
	fmul.4s	v10, v4, v10
	ldr	q4, [sp, #4640]                 ; 16-byte Reload
	fmul.4s	v8, v4, v8
	ldr	q13, [x10, #39536]
	ldr	q15, [x10, #39520]
	ldr	q4, [sp, #4592]                 ; 16-byte Reload
	fmul.4s	v15, v4, v15
	ldr	q4, [sp, #4608]                 ; 16-byte Reload
	fmul.4s	v13, v4, v13
	ldr	q5, [sp, #1728]                 ; 16-byte Reload
	bit.16b	v5, v21, v0
	ldr	q4, [sp, #4176]                 ; 16-byte Reload
	bit.16b	v4, v23, v1
	ldr	q11, [sp, #4192]                ; 16-byte Reload
	bit.16b	v11, v30, v0
	ldr	q26, [sp, #4208]                ; 16-byte Reload
	bit.16b	v26, v31, v1
	ldr	q27, [sp, #4224]                ; 16-byte Reload
	bit.16b	v27, v8, v0
	ldr	q12, [sp, #4240]                ; 16-byte Reload
	bit.16b	v12, v10, v1
	ldr	q25, [sp, #1744]                ; 16-byte Reload
	bit.16b	v25, v13, v0
	ldr	q18, [sp, #1760]                ; 16-byte Reload
	bit.16b	v18, v15, v1
	mov	x3, x10
	mov	w4, #1239                       ; =0x4d7
LBB0_85:                                ; %direct.true1781
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q21, [x3, #128]!
	ldr	q23, [x3, #39424]
	ldr	q30, [x3, #39440]
	ldp	q31, q8, [x3, #16]
	fmul.4s	v30, v31, v30
	fmul.4s	v21, v21, v23
	fadd.4s	v21, v4, v21
	fadd.4s	v23, v5, v30
	ldr	q30, [x3, #39456]
	ldr	q31, [x3, #39472]
	ldp	q10, q13, [x3, #48]
	fmul.4s	v31, v10, v31
	fmul.4s	v30, v8, v30
	fadd.4s	v8, v26, v30
	fadd.4s	v31, v11, v31
	ldr	q30, [x3, #39488]
	ldr	q10, [x3, #39504]
	mov.16b	v28, v5
	mov.16b	v5, v4
	ldp	q15, q4, [x3, #80]
	fmul.4s	v10, v15, v10
	fmul.4s	v30, v13, v30
	fadd.4s	v13, v12, v30
	fadd.4s	v15, v27, v10
	ldr	q30, [x3, #112]
	ldr	q10, [x3, #39520]
	ldr	q24, [x3, #39536]
	fmul.4s	v24, v30, v24
	fmul.4s	v4, v4, v10
	fadd.4s	v30, v18, v4
	mov.16b	v4, v5
	fadd.4s	v10, v25, v24
	mov.16b	v5, v0
	bsl.16b	v5, v23, v28
	bit.16b	v4, v21, v1
	bit.16b	v11, v31, v0
	bit.16b	v26, v8, v1
	bit.16b	v27, v15, v0
	bit.16b	v12, v13, v1
	bit.16b	v25, v10, v0
	bit.16b	v18, v30, v1
	sub	x5, x4, #1235
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_85
; %bb.86:                               ; %direct.false1782
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q4, [sp, #4176]                 ; 16-byte Spill
	str	q11, [sp, #4192]                ; 16-byte Spill
	str	q26, [sp, #4208]                ; 16-byte Spill
	str	q27, [sp, #4224]                ; 16-byte Spill
	str	q12, [sp, #4240]                ; 16-byte Spill
	str	q25, [sp, #1744]                ; 16-byte Spill
	str	q18, [sp, #1760]                ; 16-byte Spill
	ldr	q4, [x10, #42000]
	ldr	q21, [x10, #41984]
	ldr	q18, [sp, #4688]                ; 16-byte Reload
	fmul.4s	v21, v18, v21
	ldr	q18, [sp, #4704]                ; 16-byte Reload
	fmul.4s	v4, v18, v4
	ldr	q23, [x10, #42032]
	ldr	q24, [x10, #42016]
	ldr	q18, [sp, #4656]                ; 16-byte Reload
	fmul.4s	v24, v18, v24
	ldr	q18, [sp, #4672]                ; 16-byte Reload
	fmul.4s	v23, v18, v23
	ldr	q31, [x10, #42064]
	ldr	q8, [x10, #42048]
	ldr	q18, [sp, #4624]                ; 16-byte Reload
	fmul.4s	v8, v18, v8
	ldr	q18, [sp, #4640]                ; 16-byte Reload
	fmul.4s	v31, v18, v31
	ldr	q13, [x10, #42096]
	ldr	q15, [x10, #42080]
	ldr	q18, [sp, #4592]                ; 16-byte Reload
	fmul.4s	v15, v18, v15
	ldr	q18, [sp, #4608]                ; 16-byte Reload
	fmul.4s	v13, v18, v13
	bit.16b	v29, v4, v0
	bit.16b	v3, v21, v1
	bit.16b	v6, v23, v0
	ldr	q26, [sp, #4304]                ; 16-byte Reload
	bit.16b	v26, v24, v1
	ldr	q11, [sp, #4320]                ; 16-byte Reload
	bit.16b	v11, v31, v0
	ldr	q28, [sp, #4336]                ; 16-byte Reload
	bit.16b	v28, v8, v1
	ldr	q27, [sp, #1808]                ; 16-byte Reload
	bit.16b	v27, v13, v0
	bit.16b	v22, v15, v1
	mov	x3, x10
	mov	w4, #1319                       ; =0x527
LBB0_87:                                ; %direct.true1901
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x3, #128]!
	ldr	q21, [x3, #41984]
	ldr	q23, [x3, #42000]
	ldp	q24, q31, [x3, #16]
	fmul.4s	v23, v24, v23
	fmul.4s	v4, v4, v21
	fadd.4s	v4, v3, v4
	fadd.4s	v21, v29, v23
	ldr	q23, [x3, #42016]
	ldr	q24, [x3, #42032]
	ldp	q8, q13, [x3, #48]
	fmul.4s	v24, v8, v24
	fmul.4s	v23, v31, v23
	fadd.4s	v23, v26, v23
	fadd.4s	v24, v6, v24
	ldr	q31, [x3, #42048]
	ldr	q8, [x3, #42064]
	ldp	q15, q25, [x3, #80]
	fmul.4s	v8, v15, v8
	fmul.4s	v31, v13, v31
	fadd.4s	v31, v28, v31
	fadd.4s	v13, v11, v8
	ldr	q8, [x3, #112]
	ldr	q15, [x3, #42080]
	mov.16b	v18, v29
	mov.16b	v29, v3
	ldr	q12, [x3, #42096]
	fmul.4s	v8, v8, v12
	mov.16b	v3, v29
	fmul.4s	v25, v25, v15
	fadd.4s	v15, v22, v25
	fadd.4s	v8, v27, v8
	mov.16b	v29, v0
	bsl.16b	v29, v21, v18
	bit.16b	v3, v4, v1
	bit.16b	v6, v24, v0
	bit.16b	v26, v23, v1
	bit.16b	v11, v13, v0
	bit.16b	v28, v31, v1
	bit.16b	v27, v8, v0
	bit.16b	v22, v15, v1
	sub	x5, x4, #1315
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_87
; %bb.88:                               ; %direct.false1902
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q6, [sp, #4288]                 ; 16-byte Spill
	str	q26, [sp, #4304]                ; 16-byte Spill
	str	q11, [sp, #4320]                ; 16-byte Spill
	str	q28, [sp, #4336]                ; 16-byte Spill
	str	q27, [sp, #1808]                ; 16-byte Spill
	str	q22, [sp, #1824]                ; 16-byte Spill
	ldr	q4, [x10, #44560]
	ldr	q21, [x10, #44544]
	ldr	q6, [sp, #4688]                 ; 16-byte Reload
	fmul.4s	v21, v6, v21
	ldr	q6, [sp, #4704]                 ; 16-byte Reload
	fmul.4s	v4, v6, v4
	ldr	q23, [x10, #44592]
	ldr	q24, [x10, #44576]
	ldr	q6, [sp, #4656]                 ; 16-byte Reload
	fmul.4s	v24, v6, v24
	ldr	q6, [sp, #4672]                 ; 16-byte Reload
	fmul.4s	v23, v6, v23
	ldr	q25, [x10, #44624]
	ldr	q31, [x10, #44608]
	ldr	q6, [sp, #4624]                 ; 16-byte Reload
	fmul.4s	v31, v6, v31
	ldr	q6, [sp, #4640]                 ; 16-byte Reload
	fmul.4s	v25, v6, v25
	ldr	q12, [x10, #44656]
	ldr	q13, [x10, #44640]
	ldr	q6, [sp, #4592]                 ; 16-byte Reload
	fmul.4s	v13, v6, v13
	ldr	q6, [sp, #4608]                 ; 16-byte Reload
	fmul.4s	v12, v6, v12
	bit.16b	v20, v4, v0
	bit.16b	v17, v21, v1
	bit.16b	v16, v23, v0
	bit.16b	v2, v24, v1
	ldr	q27, [sp, #4432]                ; 16-byte Reload
	bit.16b	v27, v25, v0
	bit.16b	v14, v31, v1
	ldr	q11, [sp, #1856]                ; 16-byte Reload
	bit.16b	v11, v12, v0
	bit.16b	v19, v13, v1
	mov	x3, x10
	mov	w4, #1399                       ; =0x577
	ldr	q28, [sp, #4144]                ; 16-byte Reload
	ldr	q26, [sp, #3792]                ; 16-byte Reload
LBB0_89:                                ; %direct.true2021
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x3, #128]!
	ldr	q21, [x3, #44544]
	ldr	q23, [x3, #44560]
	ldp	q24, q25, [x3, #16]
	fmul.4s	v23, v24, v23
	fmul.4s	v4, v4, v21
	fadd.4s	v4, v17, v4
	fadd.4s	v21, v20, v23
	ldr	q23, [x3, #44576]
	ldr	q24, [x3, #44592]
	ldp	q31, q12, [x3, #48]
	fmul.4s	v24, v31, v24
	fmul.4s	v23, v25, v23
	fadd.4s	v23, v2, v23
	fadd.4s	v24, v16, v24
	ldr	q25, [x3, #44608]
	ldr	q31, [x3, #44624]
	mov.16b	v22, v20
	mov.16b	v20, v17
	mov.16b	v17, v16
	ldp	q13, q16, [x3, #80]
	fmul.4s	v31, v13, v31
	fmul.4s	v25, v12, v25
	fadd.4s	v25, v14, v25
	fadd.4s	v12, v27, v31
	ldr	q31, [x3, #112]
	ldr	q13, [x3, #44640]
	mov.16b	v9, v2
	mov.16b	v2, v27
	ldr	q27, [x3, #44656]
	fmul.4s	v27, v31, v27
	fmul.4s	v16, v16, v13
	fadd.4s	v13, v19, v16
	mov.16b	v16, v17
	mov.16b	v17, v20
	fadd.4s	v31, v11, v27
	mov.16b	v27, v2
	mov.16b	v20, v0
	bsl.16b	v20, v21, v22
	bit.16b	v17, v4, v1
	bit.16b	v16, v24, v0
	mov.16b	v2, v1
	bsl.16b	v2, v23, v9
	bit.16b	v27, v12, v0
	bit.16b	v14, v25, v1
	bit.16b	v11, v31, v0
	bit.16b	v19, v13, v1
	sub	x5, x4, #1395
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_89
; %bb.90:                               ; %direct.false2022
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q3, [sp, #4272]                 ; 16-byte Spill
	str	q20, [sp, #4368]                ; 16-byte Spill
	str	q17, [sp, #4384]                ; 16-byte Spill
	str	q16, [sp, #4400]                ; 16-byte Spill
	str	q2, [sp, #4416]                 ; 16-byte Spill
	str	q27, [sp, #4432]                ; 16-byte Spill
	str	q14, [sp, #4448]                ; 16-byte Spill
	str	q11, [sp, #1856]                ; 16-byte Spill
	str	q19, [sp, #1872]                ; 16-byte Spill
	ldr	q4, [x10, #47120]
	ldr	q16, [x10, #47104]
	ldr	q2, [sp, #4688]                 ; 16-byte Reload
	fmul.4s	v16, v2, v16
	ldr	q2, [sp, #4704]                 ; 16-byte Reload
	fmul.4s	v4, v2, v4
	ldr	q21, [x10, #47152]
	ldr	q23, [x10, #47136]
	ldr	q2, [sp, #4656]                 ; 16-byte Reload
	fmul.4s	v23, v2, v23
	ldr	q2, [sp, #4672]                 ; 16-byte Reload
	fmul.4s	v21, v2, v21
	ldr	q24, [x10, #47184]
	ldr	q25, [x10, #47168]
	ldr	q2, [sp, #4624]                 ; 16-byte Reload
	fmul.4s	v25, v2, v25
	ldr	q2, [sp, #4640]                 ; 16-byte Reload
	fmul.4s	v24, v2, v24
	ldr	q27, [x10, #47216]
	ldr	q12, [x10, #47200]
	ldr	q2, [sp, #4592]                 ; 16-byte Reload
	fmul.4s	v12, v2, v12
	ldr	q2, [sp, #4608]                 ; 16-byte Reload
	fmul.4s	v27, v2, v27
	bit.16b	v7, v4, v0
	ldr	q11, [sp, #1888]                ; 16-byte Reload
	bit.16b	v11, v16, v1
	ldr	q9, [sp, #1904]                 ; 16-byte Reload
	bit.16b	v9, v21, v0
	ldr	q6, [sp, #1920]                 ; 16-byte Reload
	bit.16b	v6, v23, v1
	ldr	q22, [sp, #1936]                ; 16-byte Reload
	bit.16b	v22, v24, v0
	ldr	q17, [sp, #1952]                ; 16-byte Reload
	bit.16b	v17, v25, v1
	ldr	q20, [sp, #1968]                ; 16-byte Reload
	bit.16b	v20, v27, v0
	ldr	q14, [sp, #1984]                ; 16-byte Reload
	bit.16b	v14, v12, v1
	mov	x3, x10
	mov	w4, #1479                       ; =0x5c7
	ldr	q18, [sp, #4224]                ; 16-byte Reload
LBB0_91:                                ; %direct.true2141
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x3, #128]!
	ldr	q16, [x3, #47104]
	ldr	q21, [x3, #47120]
	ldp	q23, q24, [x3, #16]
	fmul.4s	v21, v23, v21
	fmul.4s	v4, v4, v16
	fadd.4s	v4, v11, v4
	fadd.4s	v16, v7, v21
	ldr	q21, [x3, #47136]
	ldr	q23, [x3, #47152]
	ldp	q25, q27, [x3, #48]
	fmul.4s	v23, v25, v23
	fmul.4s	v21, v24, v21
	fadd.4s	v21, v6, v21
	fadd.4s	v23, v9, v23
	ldr	q24, [x3, #47168]
	ldr	q25, [x3, #47184]
	ldp	q12, q2, [x3, #80]
	fmul.4s	v25, v12, v25
	fmul.4s	v24, v27, v24
	fadd.4s	v24, v17, v24
	fadd.4s	v25, v22, v25
	ldr	q27, [x3, #112]
	ldr	q12, [x3, #47200]
	mov.16b	v19, v7
	mov.16b	v7, v11
	ldr	q11, [x3, #47216]
	fmul.4s	v27, v27, v11
	mov.16b	v11, v7
	fmul.4s	v2, v2, v12
	fadd.4s	v2, v14, v2
	fadd.4s	v27, v20, v27
	mov.16b	v7, v0
	bsl.16b	v7, v16, v19
	bit.16b	v11, v4, v1
	bit.16b	v9, v23, v0
	bit.16b	v6, v21, v1
	bit.16b	v22, v25, v0
	bit.16b	v17, v24, v1
	bit.16b	v20, v27, v0
	bit.16b	v14, v2, v1
	sub	x5, x4, #1475
	add	x4, x4, #4
	cmp	x5, #76
	b.lo	LBB0_91
; %bb.92:                               ; %direct.false2142
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x3, #0                          ; =0x0
	movi.2d	v21, #0000000000000000
	ldr	q2, [sp, #2752]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q3, [sp, #2768]                 ; 16-byte Reload
	fadd.4s	v4, v3, v21
	ldr	q3, [sp, #2800]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2784]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #2832]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2736]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2720]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3040]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #3040]                 ; 16-byte Spill
	ldr	q16, [sp, #1264]                ; 16-byte Reload
	bit.16b	v16, v4, v1
	ldr	q2, [sp, #2848]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q3, [sp, #2864]                 ; 16-byte Reload
	fadd.4s	v4, v3, v21
	ldr	q3, [sp, #3056]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2880]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3072]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2704]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2688]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3088]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #3088]                 ; 16-byte Spill
	ldr	q2, [sp, #3104]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3104]                 ; 16-byte Spill
	ldr	q2, [sp, #3120]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q3, [sp, #3136]                 ; 16-byte Reload
	fadd.4s	v4, v3, v21
	ldr	q3, [sp, #3152]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3168]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2672]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2656]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3184]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #3184]                 ; 16-byte Spill
	ldr	q2, [sp, #3200]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3200]                 ; 16-byte Spill
	ldr	q2, [sp, #3216]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q3, [sp, #2944]                 ; 16-byte Reload
	fadd.4s	v4, v3, v21
	ldr	q3, [sp, #2976]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2960]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #2992]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3232]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2640]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2624]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3248]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #3248]                 ; 16-byte Spill
	ldr	q2, [sp, #3264]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3264]                 ; 16-byte Spill
	ldr	q2, [sp, #3008]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q3, [sp, #3280]                 ; 16-byte Reload
	fadd.4s	v4, v3, v21
	ldr	q3, [sp, #3312]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #3296]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3328]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3344]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2608]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2592]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3360]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #3360]                 ; 16-byte Spill
	ldr	q2, [sp, #3376]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #3376]                 ; 16-byte Spill
	ldr	q2, [sp, #3392]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q3, [sp, #3024]                 ; 16-byte Reload
	fadd.4s	v4, v3, v21
	ldr	q3, [sp, #3408]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #3424]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3456]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3440]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2560]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2576]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3488]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #3488]                 ; 16-byte Spill
	ldr	q2, [sp, #3472]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #3472]                 ; 16-byte Spill
	ldr	q2, [sp, #3520]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q3, [sp, #3504]                 ; 16-byte Reload
	fadd.4s	v4, v3, v21
	ldr	q3, [sp, #3536]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #3552]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3584]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3568]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2528]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2544]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3616]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #3616]                 ; 16-byte Spill
	ldr	q2, [sp, #3600]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #3600]                 ; 16-byte Spill
	ldr	q2, [sp, #3648]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q3, [sp, #3632]                 ; 16-byte Reload
	fadd.4s	v4, v3, v21
	ldr	q3, [sp, #3664]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #3680]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3712]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3696]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #1040]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #2512]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3744]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #3744]                 ; 16-byte Spill
	ldr	q2, [sp, #3728]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #3728]                 ; 16-byte Spill
	ldr	q2, [sp, #3776]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q3, [sp, #3760]                 ; 16-byte Reload
	fadd.4s	v4, v3, v21
	fadd.4s	v4, v4, v26
	ldr	q3, [sp, #3808]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3840]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3824]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #1008]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #1024]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q27, [sp, #1552]                ; 16-byte Reload
	bit.16b	v27, v2, v1
	ldr	q19, [sp, #1536]                ; 16-byte Reload
	bit.16b	v19, v4, v0
	ldr	q2, [sp, #3856]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q3, [sp, #3872]                 ; 16-byte Reload
	fadd.4s	v4, v3, v21
	ldr	q3, [sp, #3904]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #3888]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3920]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #3936]                 ; 16-byte Reload
	fadd.4s	v4, v4, v3
	ldr	q3, [sp, #992]                  ; 16-byte Reload
	fadd.4s	v3, v4, v3
	ldr	q4, [sp, #976]                  ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q26, [sp, #1600]                ; 16-byte Reload
	bit.16b	v26, v2, v0
	ldr	q25, [sp, #1616]                ; 16-byte Reload
	bit.16b	v25, v3, v1
	ldr	q2, [sp, #3952]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q3, [sp, #3968]                 ; 16-byte Reload
	fadd.4s	v3, v3, v21
	ldr	q4, [sp, #4000]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #3984]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4016]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4032]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #960]                  ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #944]                  ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4048]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #4048]                 ; 16-byte Spill
	ldr	q12, [sp, #1664]                ; 16-byte Reload
	bit.16b	v12, v3, v1
	ldr	q2, [sp, #4064]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q3, [sp, #4080]                 ; 16-byte Reload
	fadd.4s	v3, v3, v21
	ldr	q4, [sp, #4112]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4096]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4128]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	fadd.4s	v3, v3, v28
	ldr	q4, [sp, #928]                  ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #912]                  ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4160]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #4160]                 ; 16-byte Spill
	ldr	q24, [sp, #1712]                ; 16-byte Reload
	bit.16b	v24, v3, v1
	str	q5, [sp, #1728]                 ; 16-byte Spill
	fadd.4s	v2, v5, v21
	ldr	q3, [sp, #4176]                 ; 16-byte Reload
	fadd.4s	v3, v3, v21
	ldr	q4, [sp, #4208]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4192]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	fadd.4s	v2, v2, v18
	ldr	q4, [sp, #4240]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	fadd.4s	v3, v3, v30
	fadd.4s	v2, v2, v10
	ldr	q4, [sp, #4256]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #4256]                 ; 16-byte Spill
	ldr	q23, [sp, #1776]                ; 16-byte Reload
	bit.16b	v23, v3, v1
	ldr	q2, [sp, #4272]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	str	q29, [sp, #1792]                ; 16-byte Spill
	fadd.4s	v3, v29, v21
	ldr	q4, [sp, #4288]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4304]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4336]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4320]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	fadd.4s	v3, v3, v8
	fadd.4s	v2, v2, v15
	ldr	q4, [sp, #4352]                 ; 16-byte Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #4352]                 ; 16-byte Spill
	ldr	q18, [sp, #1840]                ; 16-byte Reload
	bit.16b	v18, v3, v0
	ldr	q2, [sp, #4368]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	ldr	q3, [sp, #4384]                 ; 16-byte Reload
	fadd.4s	v3, v3, v21
	ldr	q4, [sp, #4416]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #4400]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4432]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #4448]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	fadd.4s	v3, v3, v13
	fadd.4s	v2, v2, v31
	ldr	q4, [sp, #4464]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #4464]                 ; 16-byte Spill
	ldr	q2, [sp, #4480]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #4480]                 ; 16-byte Spill
	mov	w4, #63790                      ; =0xf92e
	movk	w4, #15844, lsl #16
	dup.4s	v28, w4
	str	q16, [sp, #1264]                ; 16-byte Spill
	fmul.4s	v29, v16, v28
	cmp	x0, #128
	cset	w4, lo
	ldr	q2, [sp, #3040]                 ; 16-byte Reload
	fmul.4s	v2, v2, v28
	dup.4h	v3, w4
	str	d3, [sp, #4672]                 ; 8-byte Spill
	ldr	q3, [sp, #3104]                 ; 16-byte Reload
	fmul.4s	v16, v3, v28
	ldr	q3, [sp, #3088]                 ; 16-byte Reload
	fmul.4s	v5, v3, v28
	ldr	q3, [sp, #3200]                 ; 16-byte Reload
	fmul.4s	v30, v3, v28
	ldp	x5, x6, [sp, #264]              ; 16-byte Folded Reload
	ldp	q3, q4, [x6]
	ldr	q31, [sp, #3184]                ; 16-byte Reload
	fmul.4s	v31, v31, v28
	str	q2, [sp, #4704]                 ; 16-byte Spill
	bit.16b	v4, v2, v0
	str	q29, [sp, #4688]                ; 16-byte Spill
	bit.16b	v3, v29, v1
	stp	q3, q4, [x6]
	ldr	q2, [sp, #3264]                 ; 16-byte Reload
	fmul.4s	v2, v2, v28
	ldr	q3, [sp, #3248]                 ; 16-byte Reload
	fmul.4s	v10, v3, v28
	ldr	q3, [sp, #3376]                 ; 16-byte Reload
	fmul.4s	v13, v3, v28
	ldp	q3, q4, [x5]
	ldr	q29, [sp, #3360]                ; 16-byte Reload
	fmul.4s	v29, v29, v28
	str	q5, [sp, #4624]                 ; 16-byte Spill
	bit.16b	v4, v5, v0
	str	q16, [sp, #4608]                ; 16-byte Spill
	bit.16b	v3, v16, v1
	stp	q3, q4, [x5]
	ldr	q3, [sp, #3472]                 ; 16-byte Reload
	fmul.4s	v4, v3, v28
	ldr	q3, [sp, #3488]                 ; 16-byte Reload
	fmul.4s	v3, v3, v28
	ldr	q5, [sp, #3600]                 ; 16-byte Reload
	fmul.4s	v15, v5, v28
	ldp	x5, x7, [sp, #248]              ; 16-byte Folded Reload
	str	q7, [sp, #4496]                 ; 16-byte Spill
	ldp	q7, q16, [x7]
	ldr	q5, [sp, #3616]                 ; 16-byte Reload
	fmul.4s	v5, v5, v28
	str	q31, [sp, #2688]                ; 16-byte Spill
	bit.16b	v16, v31, v0
	str	q30, [sp, #2704]                ; 16-byte Spill
	bit.16b	v7, v30, v1
	stp	q7, q16, [x7]
	ldr	q7, [sp, #3728]                 ; 16-byte Reload
	fmul.4s	v16, v7, v28
	ldr	q7, [sp, #3744]                 ; 16-byte Reload
	fmul.4s	v30, v7, v28
	str	q19, [sp, #1536]                ; 16-byte Spill
	fmul.4s	v31, v19, v28
	ldp	q7, q19, [x5]
	str	q27, [sp, #1552]                ; 16-byte Spill
	fmul.4s	v8, v27, v28
	str	q10, [sp, #2592]                ; 16-byte Spill
	bit.16b	v19, v10, v0
	str	q2, [sp, #2576]                 ; 16-byte Spill
	bit.16b	v7, v2, v1
	stp	q7, q19, [x5]
	str	q25, [sp, #1616]                ; 16-byte Spill
	fmul.4s	v25, v25, v28
	str	q26, [sp, #1600]                ; 16-byte Spill
	fmul.4s	v10, v26, v28
	mov.16b	v27, v11
	str	q12, [sp, #1664]                ; 16-byte Spill
	fmul.4s	v11, v12, v28
	ldr	x5, [sp, #240]                  ; 8-byte Reload
	ldp	q7, q19, [x5]
	ldr	d2, [sp, #4672]                 ; 8-byte Reload
	ushll.4s	v2, v2, #0
	stp	q13, q29, [sp, #992]            ; 32-byte Folded Spill
	bit.16b	v19, v29, v0
	bit.16b	v7, v13, v1
	stp	q7, q19, [x5]
	shl.4s	v2, v2, #31
	cmlt.4s	v29, v2, #0
	ldr	q19, [sp, #304]                 ; 16-byte Reload
	mov.16b	v26, v29
	bsl.16b	v26, v3, v19
	ldr	x5, [sp, #232]                  ; 8-byte Reload
	ldp	q2, q7, [x5]
	mov.16b	v3, v29
	bsl.16b	v3, v4, v19
	mov.16b	v4, v0
	bsl.16b	v4, v3, v7
	str	q26, [sp, #928]                 ; 16-byte Spill
	bit.16b	v2, v26, v1
	stp	q2, q4, [x5]
	ldr	q2, [sp, #4048]                 ; 16-byte Reload
	fmul.4s	v12, v2, v28
	str	q24, [sp, #1712]                ; 16-byte Spill
	fmul.4s	v13, v24, v28
	bif.16b	v5, v19, v29
	ldr	x5, [sp, #224]                  ; 8-byte Reload
	ldp	q2, q4, [x5]
	mov.16b	v7, v29
	bsl.16b	v7, v15, v19
	stp	q7, q5, [sp, #816]              ; 32-byte Folded Spill
	bit.16b	v4, v7, v0
	bit.16b	v2, v5, v1
	stp	q2, q4, [x5]
	ldr	q2, [sp, #4160]                 ; 16-byte Reload
	fmul.4s	v5, v2, v28
	str	q23, [sp, #1776]                ; 16-byte Spill
	fmul.4s	v15, v23, v28
	mov.16b	v7, v29
	bsl.16b	v7, v30, v19
	ldr	x5, [sp, #216]                  ; 8-byte Reload
	ldp	q2, q4, [x5]
	bif.16b	v16, v19, v29
	stp	q16, q7, [sp, #720]             ; 32-byte Folded Spill
	bit.16b	v4, v16, v0
	bit.16b	v2, v7, v1
	stp	q2, q4, [x5]
	ldr	q2, [sp, #4256]                 ; 16-byte Reload
	fmul.4s	v30, v2, v28
	str	q18, [sp, #1840]                ; 16-byte Spill
	fmul.4s	v2, v18, v28
	mov.16b	v7, v29
	bsl.16b	v7, v8, v19
	ldr	x5, [sp, #208]                  ; 8-byte Reload
	ldp	q8, q4, [x5]
	mov.16b	v16, v29
	bsl.16b	v16, v31, v19
	stp	q16, q7, [sp, #624]             ; 32-byte Folded Spill
	bit.16b	v4, v16, v0
	bit.16b	v8, v7, v1
	stp	q8, q4, [x5]
	ldr	q4, [sp, #4352]                 ; 16-byte Reload
	fmul.4s	v4, v4, v28
	mov.16b	v7, v29
	bsl.16b	v7, v10, v19
	mov.16b	v23, v29
	bsl.16b	v23, v25, v19
	ldr	x5, [sp, #200]                  ; 8-byte Reload
	ldp	q18, q8, [x5]
	mov.16b	v16, v29
	bsl.16b	v16, v12, v19
	stp	q23, q7, [sp, #656]             ; 32-byte Folded Spill
	bit.16b	v18, v23, v1
	bit.16b	v8, v7, v0
	stp	q18, q8, [x5]
	mov.16b	v25, v29
	bsl.16b	v25, v11, v19
	mov.16b	v7, v29
	bsl.16b	v7, v5, v19
	mov.16b	v24, v29
	bsl.16b	v24, v13, v19
	ldr	x5, [sp, #192]                  ; 8-byte Reload
	ldp	q18, q8, [x5]
	mov.16b	v23, v29
	bsl.16b	v23, v30, v19
	stp	q25, q16, [sp, #752]            ; 32-byte Folded Spill
	mov.16b	v30, v1
	bsl.16b	v30, v25, v18
	bit.16b	v8, v16, v0
	stp	q30, q8, [x5]
	mov.16b	v18, v29
	bsl.16b	v18, v15, v19
	mov.16b	v5, v29
	bsl.16b	v5, v4, v19
	mov.16b	v16, v29
	bsl.16b	v16, v2, v19
	ldr	x5, [sp, #184]                  ; 8-byte Reload
	ldp	q4, q2, [x5]
	stp	q24, q7, [sp, #848]             ; 32-byte Folded Spill
	bit.16b	v4, v24, v1
	bit.16b	v2, v7, v0
	stp	q4, q2, [x5]
	ldr	x5, [sp, #176]                  ; 8-byte Reload
	ldp	q4, q2, [x5]
	str	q18, [sp, #944]                 ; 16-byte Spill
	bit.16b	v4, v18, v1
	str	q23, [sp, #1040]                ; 16-byte Spill
	bit.16b	v2, v23, v0
	stp	q4, q2, [x5]
	ldr	x5, [sp, #168]                  ; 8-byte Reload
	ldp	q2, q4, [x5]
	str	q16, [sp, #2512]                ; 16-byte Spill
	bit.16b	v4, v16, v0
	str	q5, [sp, #2528]                 ; 16-byte Spill
	bit.16b	v2, v5, v1
	stp	q2, q4, [x5]
	ldr	q2, [sp, #4480]                 ; 16-byte Reload
	fmul.4s	v2, v2, v28
	ldr	q4, [sp, #4464]                 ; 16-byte Reload
	fmul.4s	v4, v4, v28
	mov.16b	v5, v29
	bsl.16b	v5, v4, v19
	mov.16b	v4, v29
	bsl.16b	v4, v2, v19
	ldr	x5, [sp, #160]                  ; 8-byte Reload
	ldr	q2, [x5]
	str	q4, [sp, #2608]                 ; 16-byte Spill
	bit.16b	v2, v4, v1
	ldr	q4, [x5, #16]
	str	q5, [sp, #2624]                 ; 16-byte Spill
	bit.16b	v4, v5, v0
	stp	q2, q4, [x5]
	ldr	q2, [sp, #4496]                 ; 16-byte Reload
	fadd.4s	v2, v2, v21
	str	q9, [sp, #1904]                 ; 16-byte Spill
	fadd.4s	v2, v2, v9
	str	q27, [sp, #1888]                ; 16-byte Spill
	fadd.4s	v4, v27, v21
	str	q6, [sp, #1920]                 ; 16-byte Spill
	fadd.4s	v4, v4, v6
	str	q17, [sp, #1952]                ; 16-byte Spill
	fadd.4s	v4, v4, v17
	str	q22, [sp, #1936]                ; 16-byte Spill
	fadd.4s	v2, v2, v22
	str	q20, [sp, #1968]                ; 16-byte Spill
	fadd.4s	v2, v2, v20
	str	q14, [sp, #1984]                ; 16-byte Spill
	fadd.4s	v4, v4, v14
	fmul.4s	v4, v4, v28
	fmul.4s	v2, v2, v28
	mov.16b	v5, v29
	bsl.16b	v5, v2, v19
	bif.16b	v4, v19, v29
	ldr	x5, [sp, #152]                  ; 8-byte Reload
	ldr	q2, [x5]
	str	q4, [sp, #2640]                 ; 16-byte Spill
	bit.16b	v2, v4, v1
	ldr	q4, [x5, #16]
	str	q5, [sp, #2720]                 ; 16-byte Spill
	bit.16b	v4, v5, v0
	stp	q2, q4, [x5]
	mvni.4s	v2, #127, msl #16
	ldr	q8, [sp, #2000]                 ; 16-byte Reload
	bit.16b	v8, v2, v0
	mvni.4s	v19, #127, msl #16
	ldr	q30, [sp, #2016]                ; 16-byte Reload
	bit.16b	v30, v2, v1
	dup.8b	v2, w4
	str	d2, [sp, #1024]                 ; 8-byte Spill
LBB0_93:                                ; %direct.true2305
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x4, x14, x3
	ldp	q2, q4, [x4]
	and.16b	v4, v0, v4
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v30, v2
	fmaxnm.4s	v4, v8, v4
	bit.16b	v8, v4, v0
	bit.16b	v30, v2, v1
	add	x3, x3, #32
	cmp	x3, #512
	b.ne	LBB0_93
; %bb.94:                               ; %direct.false2306
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x3, #0                          ; =0x0
	ldr	q4, [sp, #2448]                 ; 16-byte Reload
	ldr	q28, [sp, #2272]                ; 16-byte Reload
	ldr	q2, [sp, #1200]                 ; 16-byte Reload
	bit.16b	v2, v28, v4
	str	q2, [sp, #1200]                 ; 16-byte Spill
	ldr	q2, [sp, #2464]                 ; 16-byte Reload
	ldr	q29, [sp, #2256]                ; 16-byte Reload
	ldr	q5, [sp, #1232]                 ; 16-byte Reload
	bit.16b	v5, v29, v2
	str	q5, [sp, #1232]                 ; 16-byte Spill
	ldr	q21, [sp, #2368]                ; 16-byte Reload
	bit.16b	v21, v28, v4
	str	q21, [sp, #2368]                ; 16-byte Spill
	ldr	q4, [sp, #2400]                 ; 16-byte Reload
	bit.16b	v4, v29, v2
	str	q4, [sp, #2400]                 ; 16-byte Spill
	str	q30, [sp, #2016]                ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	fmaxnm.4s	v21, v2, v30
	ldr	q2, [sp, #4688]                 ; 16-byte Reload
	fsub.4s	v2, v2, v21
	and.16b	v5, v1, v2
	mov	w4, #-1026555904                ; =0xc2d00000
	dup.4s	v9, w4
	mov	w4, #1120403456                 ; =0x42c80000
	dup.4s	v10, w4
	fcmge.4s	v2, v5, v9
	fcmge.4s	v4, v10, v5
	and.16b	v2, v2, v4
	str	q8, [sp, #2000]                 ; 16-byte Spill
	ldr	q4, [sp, #4576]                 ; 16-byte Reload
	fmaxnm.4s	v16, v4, v8
	ldr	q4, [sp, #4704]                 ; 16-byte Reload
	fsub.4s	v4, v4, v16
	and.16b	v6, v0, v4
	fcmge.4s	v4, v6, v9
	fcmge.4s	v26, v10, v6
	and.16b	v4, v4, v26
	and.16b	v4, v4, v6
	mov	w4, #43579                      ; =0xaa3b
	movk	w4, #16312, lsl #16
	dup.4s	v17, w4
	fmul.4s	v26, v4, v17
	movi.4s	v18, #75, lsl #24
	mvni.4s	v20, #128, lsl #24
	mov.16b	v27, v20
	bsl.16b	v27, v18, v26
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	and.16b	v2, v2, v5
	fmul.4s	v27, v2, v17
	mov.16b	v28, v20
	bsl.16b	v28, v18, v27
	fadd.4s	v27, v27, v28
	fsub.4s	v27, v27, v28
	fcvtzs.4s	v26, v26
	mov	w4, #29184                      ; =0x7200
	movk	w4, #16177, lsl #16
	dup.4s	v18, w4
	scvtf.4s	v28, v26
	fmul.4s	v29, v28, v18
	fsub.4s	v4, v4, v29
	fcvtzs.4s	v27, v27
	scvtf.4s	v29, v27
	fmul.4s	v30, v29, v18
	fsub.4s	v2, v2, v30
	mov	w4, #48782                      ; =0xbe8e
	movk	w4, #13759, lsl #16
	dup.4s	v13, w4
	fmul.4s	v29, v29, v13
	fsub.4s	v2, v2, v29
	fmul.4s	v28, v28, v13
	fsub.4s	v4, v4, v28
	mov	w4, #11226                      ; =0x2bda
	movk	w4, #14672, lsl #16
	dup.4s	v12, w4
	fmul.4s	v28, v4, v12
	mov	w4, #38601                      ; =0x96c9
	movk	w4, #15030, lsl #16
	dup.4s	v15, w4
	fadd.4s	v28, v28, v15
	fmul.4s	v28, v4, v28
	mov	w4, #34982                      ; =0x88a6
	movk	w4, #15368, lsl #16
	dup.4s	v14, w4
	fadd.4s	v28, v28, v14
	fmul.4s	v28, v4, v28
	mov	w4, #43642                      ; =0xaa7a
	movk	w4, #15658, lsl #16
	dup.4s	v7, w4
	fadd.4s	v28, v28, v7
	fmul.4s	v28, v4, v28
	mov	w4, #43691                      ; =0xaaab
	movk	w4, #15914, lsl #16
	dup.4s	v22, w4
	fadd.4s	v28, v28, v22
	fmul.4s	v28, v4, v28
	movi.4s	v20, #63, lsl #24
	fadd.4s	v28, v28, v20
	movi.4s	v31, #63, lsl #24
	fmul.4s	v29, v4, v4
	fmul.4s	v28, v29, v28
	fmul.4s	v29, v2, v12
	fadd.4s	v29, v29, v15
	fmul.4s	v29, v2, v29
	fadd.4s	v29, v29, v14
	fmul.4s	v29, v2, v29
	fadd.4s	v29, v29, v7
	fmul.4s	v29, v2, v29
	fadd.4s	v29, v29, v22
	fmul.4s	v29, v2, v29
	fadd.4s	v29, v29, v31
	fmul.4s	v30, v2, v2
	fmul.4s	v29, v30, v29
	fadd.4s	v2, v2, v29
	fadd.4s	v4, v4, v28
	fmov.4s	v8, #1.00000000
	fadd.4s	v2, v2, v8
	sshr.4s	v28, v27, #1
	shl.4s	v29, v28, #23
	add.4s	v29, v29, v8
	fmul.4s	v2, v2, v29
	fadd.4s	v4, v4, v8
	sshr.4s	v29, v26, #1
	shl.4s	v30, v29, #23
	add.4s	v30, v30, v8
	fmul.4s	v4, v4, v30
	sub.4s	v27, v27, v28
	sub.4s	v26, v26, v29
	shl.4s	v26, v26, #23
	add.4s	v26, v26, v8
	fmul.4s	v4, v4, v26
	shl.4s	v26, v27, #23
	add.4s	v26, v26, v8
	fmul.4s	v2, v2, v26
	str	q5, [sp, #4640]                 ; 16-byte Spill
	fcmgt.4s	v26, v9, v5
	bic.16b	v2, v2, v26
	str	q6, [sp, #4704]                 ; 16-byte Spill
	fcmgt.4s	v26, v9, v6
	bic.16b	v4, v4, v26
	fcmgt.4s	v26, v6, v10
	fneg.4s	v11, v19
	bit.16b	v4, v11, v26
	str	q4, [sp, #4688]                 ; 16-byte Spill
	fcmgt.4s	v4, v5, v10
	bit.16b	v2, v11, v4
	str	q2, [sp, #4672]                 ; 16-byte Spill
	ldr	q2, [sp, #4608]                 ; 16-byte Reload
	fsub.4s	v2, v2, v21
	and.16b	v19, v1, v2
	fcmge.4s	v2, v19, v9
	fcmge.4s	v4, v10, v19
	and.16b	v2, v2, v4
	ldr	q4, [sp, #4624]                 ; 16-byte Reload
	fsub.4s	v4, v4, v16
	and.16b	v20, v0, v4
	fcmge.4s	v4, v20, v9
	fcmge.4s	v24, v10, v20
	and.16b	v4, v4, v24
	and.16b	v4, v4, v20
	fmul.4s	v24, v4, v17
	mvni.4s	v5, #128, lsl #24
	movi.4s	v6, #75, lsl #24
	mov.16b	v25, v5
	bsl.16b	v25, v6, v24
	fadd.4s	v24, v24, v25
	fsub.4s	v24, v24, v25
	and.16b	v2, v2, v19
	fmul.4s	v25, v2, v17
	mov.16b	v26, v5
	bsl.16b	v26, v6, v25
	fadd.4s	v25, v25, v26
	fsub.4s	v25, v25, v26
	fcvtzs.4s	v24, v24
	scvtf.4s	v26, v24
	fmul.4s	v27, v26, v18
	fsub.4s	v4, v4, v27
	fcvtzs.4s	v25, v25
	scvtf.4s	v27, v25
	fmul.4s	v28, v27, v18
	fsub.4s	v2, v2, v28
	fmul.4s	v27, v27, v13
	fsub.4s	v2, v2, v27
	fmul.4s	v26, v26, v13
	fsub.4s	v4, v4, v26
	fmul.4s	v26, v4, v12
	fadd.4s	v26, v26, v15
	fmul.4s	v26, v4, v26
	fadd.4s	v26, v26, v14
	fmul.4s	v26, v4, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v4, v26
	mov.16b	v30, v22
	fadd.4s	v26, v26, v22
	fmul.4s	v26, v4, v26
	fadd.4s	v26, v26, v31
	fmul.4s	v27, v4, v4
	fmul.4s	v26, v27, v26
	fmul.4s	v27, v2, v12
	fadd.4s	v27, v27, v15
	fmul.4s	v27, v2, v27
	fadd.4s	v27, v27, v14
	fmul.4s	v27, v2, v27
	fadd.4s	v27, v27, v7
	fmul.4s	v27, v2, v27
	fadd.4s	v27, v27, v22
	fmul.4s	v27, v2, v27
	fadd.4s	v27, v27, v31
	fmul.4s	v28, v2, v2
	fmul.4s	v27, v28, v27
	fadd.4s	v2, v2, v27
	fadd.4s	v4, v4, v26
	fadd.4s	v2, v2, v8
	sshr.4s	v26, v25, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v8
	fmul.4s	v2, v2, v27
	fadd.4s	v4, v4, v8
	sshr.4s	v27, v24, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v8
	fmul.4s	v4, v4, v28
	sub.4s	v25, v25, v26
	sub.4s	v24, v24, v27
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v8
	fmul.4s	v4, v4, v24
	shl.4s	v24, v25, #23
	add.4s	v24, v24, v8
	fmul.4s	v2, v2, v24
	str	q19, [sp, #2736]                ; 16-byte Spill
	fcmgt.4s	v24, v9, v19
	bic.16b	v2, v2, v24
	str	q20, [sp, #4592]                ; 16-byte Spill
	fcmgt.4s	v24, v9, v20
	bic.16b	v4, v4, v24
	fcmgt.4s	v24, v20, v10
	bit.16b	v4, v11, v24
	str	q4, [sp, #4608]                 ; 16-byte Spill
	fcmgt.4s	v4, v19, v10
	bit.16b	v2, v11, v4
	str	q2, [sp, #4624]                 ; 16-byte Spill
	ldr	q2, [sp, #2704]                 ; 16-byte Reload
	fsub.4s	v2, v2, v21
	and.16b	v5, v1, v2
	fcmge.4s	v2, v5, v9
	fcmge.4s	v4, v10, v5
	and.16b	v2, v2, v4
	ldr	q4, [sp, #2688]                 ; 16-byte Reload
	fsub.4s	v4, v4, v16
	and.16b	v6, v0, v4
	fcmge.4s	v4, v6, v9
	fcmge.4s	v22, v10, v6
	and.16b	v4, v4, v22
	and.16b	v4, v4, v6
	mov.16b	v20, v17
	fmul.4s	v22, v4, v17
	movi.4s	v17, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	mov.16b	v23, v19
	bsl.16b	v23, v17, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	and.16b	v2, v2, v5
	fmul.4s	v23, v2, v20
	mov.16b	v28, v20
	mov.16b	v24, v19
	bsl.16b	v24, v17, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	fcvtzs.4s	v22, v22
	scvtf.4s	v24, v22
	fmul.4s	v25, v24, v18
	fsub.4s	v4, v4, v25
	fcvtzs.4s	v23, v23
	scvtf.4s	v25, v23
	fmul.4s	v26, v25, v18
	fsub.4s	v2, v2, v26
	fmul.4s	v25, v25, v13
	fsub.4s	v2, v2, v25
	fmul.4s	v24, v24, v13
	fsub.4s	v4, v4, v24
	fmul.4s	v24, v4, v12
	fadd.4s	v24, v24, v15
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v14
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v7
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v30
	fmul.4s	v24, v4, v24
	fadd.4s	v24, v24, v31
	fmul.4s	v25, v4, v4
	fmul.4s	v24, v25, v24
	fmul.4s	v25, v2, v12
	fadd.4s	v25, v25, v15
	fmul.4s	v25, v2, v25
	fadd.4s	v25, v25, v14
	fmul.4s	v25, v2, v25
	fadd.4s	v25, v25, v7
	mov.16b	v29, v7
	fmul.4s	v25, v2, v25
	fadd.4s	v25, v25, v30
	fmul.4s	v25, v2, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v2, v2
	fmul.4s	v25, v26, v25
	fadd.4s	v2, v2, v25
	fadd.4s	v4, v4, v24
	fadd.4s	v2, v2, v8
	sshr.4s	v24, v23, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v8
	fmul.4s	v2, v2, v25
	fadd.4s	v4, v4, v8
	sshr.4s	v25, v22, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v8
	fmul.4s	v4, v4, v26
	sub.4s	v23, v23, v24
	sub.4s	v22, v22, v25
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v8
	fmul.4s	v4, v4, v22
	shl.4s	v22, v23, #23
	add.4s	v22, v22, v8
	fmul.4s	v2, v2, v22
	str	q5, [sp, #2656]                 ; 16-byte Spill
	fcmgt.4s	v22, v9, v5
	bic.16b	v2, v2, v22
	str	q6, [sp, #2688]                 ; 16-byte Spill
	fcmgt.4s	v22, v9, v6
	bic.16b	v4, v4, v22
	fcmgt.4s	v22, v6, v10
	bit.16b	v4, v11, v22
	str	q4, [sp, #2704]                 ; 16-byte Spill
	fcmgt.4s	v4, v5, v10
	bit.16b	v2, v11, v4
	str	q2, [sp, #2672]                 ; 16-byte Spill
	ldr	q2, [sp, #2576]                 ; 16-byte Reload
	fsub.4s	v2, v2, v21
	mov.16b	v27, v21
	and.16b	v6, v1, v2
	fcmge.4s	v2, v6, v9
	fcmge.4s	v4, v10, v6
	and.16b	v2, v2, v4
	ldr	q4, [sp, #2592]                 ; 16-byte Reload
	fsub.4s	v4, v4, v16
	and.16b	v17, v0, v4
	fcmge.4s	v4, v17, v9
	fcmge.4s	v5, v10, v17
	and.16b	v4, v4, v5
	and.16b	v4, v4, v17
	fmul.4s	v5, v4, v20
	mvni.4s	v7, #128, lsl #24
	movi.4s	v19, #75, lsl #24
	mov.16b	v21, v7
	bsl.16b	v21, v19, v5
	fadd.4s	v5, v5, v21
	fsub.4s	v5, v5, v21
	and.16b	v2, v2, v6
	fmul.4s	v21, v2, v20
	mov.16b	v22, v7
	bsl.16b	v22, v19, v21
	fadd.4s	v21, v21, v22
	fsub.4s	v21, v21, v22
	fcvtzs.4s	v5, v5
	scvtf.4s	v22, v5
	mov.16b	v25, v18
	fmul.4s	v23, v22, v18
	fsub.4s	v4, v4, v23
	fcvtzs.4s	v21, v21
	scvtf.4s	v23, v21
	fmul.4s	v24, v23, v18
	fsub.4s	v2, v2, v24
	fmul.4s	v23, v23, v13
	fsub.4s	v2, v2, v23
	fmul.4s	v22, v22, v13
	fsub.4s	v4, v4, v22
	fmul.4s	v22, v4, v12
	fadd.4s	v22, v22, v15
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v14
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v29
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v30
	fmul.4s	v22, v4, v22
	fadd.4s	v22, v22, v31
	fmul.4s	v23, v4, v4
	fmul.4s	v22, v23, v22
	fmul.4s	v23, v2, v12
	fadd.4s	v23, v23, v15
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v29
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v30
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v24, v2, v2
	fmul.4s	v23, v24, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v4, v4, v22
	fadd.4s	v2, v2, v8
	sshr.4s	v22, v21, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v4, v4, v8
	sshr.4s	v23, v5, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v8
	fmul.4s	v4, v4, v24
	sub.4s	v21, v21, v22
	sub.4s	v5, v5, v23
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v8
	fmul.4s	v4, v4, v5
	shl.4s	v5, v21, #23
	add.4s	v5, v5, v8
	fmul.4s	v2, v2, v5
	str	q6, [sp, #2544]                 ; 16-byte Spill
	fcmgt.4s	v5, v9, v6
	bic.16b	v2, v2, v5
	str	q17, [sp, #2576]                ; 16-byte Spill
	fcmgt.4s	v5, v9, v17
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v17, v10
	bit.16b	v4, v11, v5
	str	q4, [sp, #2592]                 ; 16-byte Spill
	fcmgt.4s	v4, v6, v10
	bit.16b	v2, v11, v4
	str	q2, [sp, #2560]                 ; 16-byte Spill
	ldr	q2, [sp, #992]                  ; 16-byte Reload
	fsub.4s	v2, v2, v27
	and.16b	v6, v1, v2
	fcmge.4s	v2, v6, v9
	fcmge.4s	v4, v10, v6
	and.16b	v2, v2, v4
	ldr	q4, [sp, #1008]                 ; 16-byte Reload
	fsub.4s	v4, v4, v16
	and.16b	v17, v0, v4
	fcmge.4s	v4, v17, v9
	fcmge.4s	v5, v10, v17
	and.16b	v4, v4, v5
	and.16b	v4, v4, v17
	fmul.4s	v5, v4, v20
	movi.4s	v7, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	mov.16b	v18, v19
	bsl.16b	v18, v7, v5
	fadd.4s	v5, v5, v18
	fsub.4s	v5, v5, v18
	and.16b	v2, v2, v6
	fmul.4s	v18, v2, v20
	mov.16b	v20, v19
	bsl.16b	v20, v7, v18
	movi.4s	v23, #75, lsl #24
	fadd.4s	v18, v18, v20
	fsub.4s	v18, v18, v20
	fcvtzs.4s	v5, v5
	scvtf.4s	v20, v5
	fmul.4s	v21, v20, v25
	fsub.4s	v4, v4, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v22, v21, v25
	fsub.4s	v2, v2, v22
	fmul.4s	v21, v21, v13
	fsub.4s	v2, v2, v21
	fmul.4s	v20, v20, v13
	fsub.4s	v4, v4, v20
	fmul.4s	v20, v4, v12
	fadd.4s	v20, v20, v15
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v14
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v29
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v30
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v21, v4, v4
	fmul.4s	v20, v21, v20
	fmul.4s	v21, v2, v12
	fadd.4s	v21, v21, v15
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v22, v2, v2
	fmul.4s	v21, v22, v21
	fadd.4s	v2, v2, v21
	fadd.4s	v4, v4, v20
	fadd.4s	v2, v2, v8
	sshr.4s	v20, v18, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v8
	fmul.4s	v2, v2, v21
	fadd.4s	v4, v4, v8
	sshr.4s	v21, v5, #1
	shl.4s	v22, v21, #23
	add.4s	v22, v22, v8
	fmul.4s	v4, v4, v22
	sub.4s	v18, v18, v20
	sub.4s	v5, v5, v21
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v8
	fmul.4s	v4, v4, v5
	shl.4s	v5, v18, #23
	add.4s	v5, v5, v8
	fmul.4s	v2, v2, v5
	fcmgt.4s	v5, v9, v6
	bic.16b	v2, v2, v5
	fcmgt.4s	v5, v9, v17
	bic.16b	v4, v4, v5
	fcmgt.4s	v5, v17, v10
	bit.16b	v4, v11, v5
	stp	q17, q4, [sp, #992]             ; 32-byte Folded Spill
	fcmgt.4s	v4, v6, v10
	bit.16b	v2, v11, v4
	stp	q6, q2, [sp, #960]              ; 32-byte Folded Spill
	fsub.4s	v2, v3, v16
	mov.16b	v22, v16
	and.16b	v6, v0, v2
	fcmge.4s	v2, v6, v9
	fcmge.4s	v4, v10, v6
	and.16b	v2, v2, v4
	ldr	q3, [sp, #928]                  ; 16-byte Reload
	fsub.4s	v3, v3, v27
	and.16b	v16, v1, v3
	fcmge.4s	v3, v16, v9
	fcmge.4s	v4, v10, v16
	and.16b	v3, v3, v4
	and.16b	v4, v3, v16
	fmul.4s	v3, v4, v28
	mvni.4s	v7, #128, lsl #24
	mov.16b	v5, v7
	bsl.16b	v5, v23, v3
	fadd.4s	v3, v3, v5
	fsub.4s	v3, v3, v5
	and.16b	v2, v2, v6
	fmul.4s	v5, v2, v28
	mov.16b	v18, v7
	bsl.16b	v18, v23, v5
	mvni.4s	v21, #128, lsl #24
	fadd.4s	v5, v5, v18
	fsub.4s	v5, v5, v18
	fcvtzs.4s	v3, v3
	scvtf.4s	v18, v3
	fmul.4s	v19, v18, v25
	fsub.4s	v4, v4, v19
	fcvtzs.4s	v5, v5
	scvtf.4s	v19, v5
	fmul.4s	v20, v19, v25
	fsub.4s	v2, v2, v20
	fmul.4s	v19, v19, v13
	fsub.4s	v2, v2, v19
	fmul.4s	v18, v18, v13
	fsub.4s	v4, v4, v18
	fmul.4s	v18, v4, v12
	fadd.4s	v18, v18, v15
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v14
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v29
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v30
	fmul.4s	v18, v4, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v19, v4, v4
	fmul.4s	v18, v19, v18
	fmul.4s	v19, v2, v12
	fadd.4s	v19, v19, v15
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v14
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v29
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v30
	fmul.4s	v19, v2, v19
	fadd.4s	v19, v19, v31
	fmul.4s	v20, v2, v2
	fmul.4s	v19, v20, v19
	fadd.4s	v2, v2, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v2, v2, v8
	sshr.4s	v18, v5, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v8
	fmul.4s	v2, v2, v19
	fadd.4s	v4, v4, v8
	sshr.4s	v19, v3, #1
	shl.4s	v20, v19, #23
	add.4s	v20, v20, v8
	fmul.4s	v4, v4, v20
	sub.4s	v5, v5, v18
	sub.4s	v3, v3, v19
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v5, #23
	add.4s	v4, v4, v8
	fmul.4s	v2, v2, v4
	fcmgt.4s	v4, v9, v6
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v9, v16
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v16, v10
	bit.16b	v3, v11, v4
	stp	q16, q3, [sp, #912]             ; 32-byte Folded Spill
	fcmgt.4s	v3, v6, v10
	bit.16b	v2, v11, v3
	stp	q6, q2, [sp, #880]              ; 32-byte Folded Spill
	ldr	q2, [sp, #816]                  ; 16-byte Reload
	fsub.4s	v2, v2, v22
	and.16b	v6, v0, v2
	fcmge.4s	v2, v6, v9
	fcmge.4s	v3, v10, v6
	and.16b	v2, v2, v3
	ldr	q3, [sp, #832]                  ; 16-byte Reload
	fsub.4s	v3, v3, v27
	and.16b	v16, v1, v3
	fcmge.4s	v3, v16, v9
	fcmge.4s	v4, v10, v16
	and.16b	v3, v3, v4
	and.16b	v4, v3, v16
	fmul.4s	v3, v4, v28
	mov.16b	v5, v21
	bsl.16b	v5, v23, v3
	fadd.4s	v3, v3, v5
	fsub.4s	v3, v3, v5
	and.16b	v2, v2, v6
	fmul.4s	v5, v2, v28
	mov.16b	v7, v21
	bsl.16b	v7, v23, v5
	fadd.4s	v5, v5, v7
	fsub.4s	v5, v5, v7
	fcvtzs.4s	v3, v3
	scvtf.4s	v7, v3
	fmul.4s	v17, v7, v25
	fsub.4s	v4, v4, v17
	fcvtzs.4s	v5, v5
	scvtf.4s	v17, v5
	fmul.4s	v18, v17, v25
	fsub.4s	v2, v2, v18
	fmul.4s	v17, v17, v13
	fsub.4s	v2, v2, v17
	fmul.4s	v7, v7, v13
	fsub.4s	v4, v4, v7
	fmul.4s	v7, v4, v12
	fadd.4s	v7, v7, v15
	fmul.4s	v7, v4, v7
	fadd.4s	v7, v7, v14
	fmul.4s	v7, v4, v7
	fadd.4s	v7, v7, v29
	fmul.4s	v7, v4, v7
	fadd.4s	v7, v7, v30
	fmul.4s	v7, v4, v7
	fadd.4s	v7, v7, v31
	fmul.4s	v17, v4, v4
	fmul.4s	v7, v17, v7
	fmul.4s	v17, v2, v12
	fadd.4s	v17, v17, v15
	fmul.4s	v17, v2, v17
	fadd.4s	v17, v17, v14
	fmul.4s	v17, v2, v17
	fadd.4s	v17, v17, v29
	fmul.4s	v17, v2, v17
	fadd.4s	v17, v17, v30
	fmul.4s	v17, v2, v17
	fadd.4s	v17, v17, v31
	fmul.4s	v18, v2, v2
	fmul.4s	v17, v18, v17
	fadd.4s	v2, v2, v17
	fadd.4s	v4, v4, v7
	fadd.4s	v2, v2, v8
	sshr.4s	v7, v5, #1
	shl.4s	v17, v7, #23
	add.4s	v17, v17, v8
	fmul.4s	v2, v2, v17
	fadd.4s	v4, v4, v8
	sshr.4s	v17, v3, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v8
	fmul.4s	v4, v4, v18
	sub.4s	v5, v5, v7
	sub.4s	v3, v3, v17
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v5, #23
	add.4s	v4, v4, v8
	fmul.4s	v2, v2, v4
	fcmgt.4s	v4, v9, v6
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v9, v16
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v16, v10
	bit.16b	v3, v11, v4
	stp	q16, q3, [sp, #816]             ; 32-byte Folded Spill
	fcmgt.4s	v3, v6, v10
	bit.16b	v2, v11, v3
	stp	q6, q2, [sp, #784]              ; 32-byte Folded Spill
	ldr	q2, [sp, #720]                  ; 16-byte Reload
	fsub.4s	v2, v2, v22
	and.16b	v17, v0, v2
	fcmge.4s	v2, v17, v9
	fcmge.4s	v3, v10, v17
	and.16b	v2, v2, v3
	ldr	q3, [sp, #736]                  ; 16-byte Reload
	fsub.4s	v3, v3, v27
	and.16b	v18, v1, v3
	fcmge.4s	v3, v18, v9
	fcmge.4s	v4, v10, v18
	and.16b	v3, v3, v4
	and.16b	v4, v3, v18
	fmul.4s	v3, v4, v28
	mov.16b	v5, v21
	bsl.16b	v5, v23, v3
	fadd.4s	v3, v3, v5
	fsub.4s	v3, v3, v5
	and.16b	v2, v2, v17
	fmul.4s	v5, v2, v28
	mov.16b	v6, v21
	bsl.16b	v6, v23, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	fcvtzs.4s	v3, v3
	scvtf.4s	v6, v3
	fmul.4s	v7, v6, v25
	fsub.4s	v4, v4, v7
	fcvtzs.4s	v5, v5
	scvtf.4s	v7, v5
	fmul.4s	v16, v7, v25
	fsub.4s	v2, v2, v16
	fmul.4s	v7, v7, v13
	fsub.4s	v2, v2, v7
	fmul.4s	v6, v6, v13
	fsub.4s	v4, v4, v6
	fmul.4s	v6, v4, v12
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v14
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v29
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v30
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v31
	fmul.4s	v7, v4, v4
	fmul.4s	v6, v7, v6
	fmul.4s	v7, v2, v12
	fadd.4s	v7, v7, v15
	fmul.4s	v7, v2, v7
	fadd.4s	v7, v7, v14
	fmul.4s	v7, v2, v7
	fadd.4s	v7, v7, v29
	fmul.4s	v7, v2, v7
	fadd.4s	v7, v7, v30
	fmul.4s	v7, v2, v7
	fadd.4s	v7, v7, v31
	fmul.4s	v16, v2, v2
	fmul.4s	v7, v16, v7
	fadd.4s	v2, v2, v7
	fadd.4s	v4, v4, v6
	fadd.4s	v2, v2, v8
	sshr.4s	v6, v5, #1
	shl.4s	v7, v6, #23
	add.4s	v7, v7, v8
	fmul.4s	v2, v2, v7
	fadd.4s	v4, v4, v8
	sshr.4s	v7, v3, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v8
	fmul.4s	v4, v4, v16
	sub.4s	v5, v5, v6
	sub.4s	v3, v3, v7
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v5, #23
	add.4s	v4, v4, v8
	fmul.4s	v2, v2, v4
	fcmgt.4s	v4, v9, v17
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v9, v18
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v18, v10
	bit.16b	v3, v11, v4
	stp	q18, q3, [sp, #720]             ; 32-byte Folded Spill
	fcmgt.4s	v3, v17, v10
	bit.16b	v2, v11, v3
	stp	q17, q2, [sp, #688]             ; 32-byte Folded Spill
	ldr	q2, [sp, #624]                  ; 16-byte Reload
	fsub.4s	v2, v2, v22
	and.16b	v17, v0, v2
	fcmge.4s	v2, v17, v9
	fcmge.4s	v3, v10, v17
	and.16b	v2, v2, v3
	ldr	q3, [sp, #640]                  ; 16-byte Reload
	fsub.4s	v3, v3, v27
	and.16b	v18, v1, v3
	fcmge.4s	v3, v18, v9
	fcmge.4s	v4, v10, v18
	and.16b	v3, v3, v4
	and.16b	v3, v3, v18
	fmul.4s	v4, v3, v28
	mov.16b	v5, v21
	bsl.16b	v5, v23, v4
	fadd.4s	v4, v4, v5
	fsub.4s	v4, v4, v5
	and.16b	v5, v2, v17
	fmul.4s	v2, v5, v28
	mov.16b	v6, v21
	bsl.16b	v6, v23, v2
	fadd.4s	v2, v2, v6
	fsub.4s	v6, v2, v6
	fcvtzs.4s	v2, v4
	scvtf.4s	v4, v2
	fmul.4s	v7, v4, v25
	fsub.4s	v3, v3, v7
	fcvtzs.4s	v6, v6
	scvtf.4s	v7, v6
	fmul.4s	v16, v7, v25
	fsub.4s	v5, v5, v16
	fmul.4s	v7, v7, v13
	fsub.4s	v5, v5, v7
	fmul.4s	v4, v4, v13
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v3, v12
	fadd.4s	v4, v4, v15
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v14
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v29
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v30
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v31
	fmul.4s	v7, v3, v3
	fmul.4s	v4, v7, v4
	fmul.4s	v7, v5, v12
	fadd.4s	v7, v7, v15
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v14
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v29
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v30
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v31
	fmul.4s	v16, v5, v5
	fmul.4s	v7, v16, v7
	fadd.4s	v5, v5, v7
	fadd.4s	v3, v3, v4
	fadd.4s	v4, v5, v8
	sshr.4s	v5, v6, #1
	shl.4s	v7, v5, #23
	add.4s	v7, v7, v8
	fmul.4s	v4, v4, v7
	fadd.4s	v3, v3, v8
	sshr.4s	v7, v2, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v8
	fmul.4s	v3, v3, v16
	sub.4s	v5, v6, v5
	sub.4s	v2, v2, v7
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v8
	fmul.4s	v2, v3, v2
	shl.4s	v3, v5, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	fcmgt.4s	v4, v9, v17
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v9, v18
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v18, v10
	bit.16b	v2, v11, v4
	stp	q18, q2, [sp, #624]             ; 32-byte Folded Spill
	fcmgt.4s	v2, v17, v10
	bsl.16b	v2, v11, v3
	stp	q17, q2, [sp, #592]             ; 32-byte Folded Spill
	ldr	q2, [sp, #656]                  ; 16-byte Reload
	fsub.4s	v2, v2, v27
	and.16b	v17, v1, v2
	fcmge.4s	v2, v17, v9
	fcmge.4s	v3, v10, v17
	and.16b	v2, v2, v3
	ldr	q3, [sp, #672]                  ; 16-byte Reload
	fsub.4s	v3, v3, v22
	and.16b	v18, v0, v3
	fcmge.4s	v3, v18, v9
	fcmge.4s	v4, v10, v18
	and.16b	v3, v3, v4
	and.16b	v3, v3, v18
	fmul.4s	v4, v3, v28
	mov.16b	v5, v21
	bsl.16b	v5, v23, v4
	fadd.4s	v4, v4, v5
	fsub.4s	v4, v4, v5
	and.16b	v5, v2, v17
	fmul.4s	v2, v5, v28
	mov.16b	v6, v21
	bsl.16b	v6, v23, v2
	fadd.4s	v2, v2, v6
	fsub.4s	v6, v2, v6
	fcvtzs.4s	v2, v4
	scvtf.4s	v4, v2
	fmul.4s	v7, v4, v25
	fsub.4s	v3, v3, v7
	fcvtzs.4s	v6, v6
	scvtf.4s	v7, v6
	fmul.4s	v16, v7, v25
	fsub.4s	v5, v5, v16
	fmul.4s	v7, v7, v13
	fsub.4s	v5, v5, v7
	fmul.4s	v4, v4, v13
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v3, v12
	fadd.4s	v4, v4, v15
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v14
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v29
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v30
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v31
	fmul.4s	v7, v3, v3
	fmul.4s	v4, v7, v4
	fmul.4s	v7, v5, v12
	fadd.4s	v7, v7, v15
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v14
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v29
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v30
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v31
	fmul.4s	v16, v5, v5
	fmul.4s	v7, v16, v7
	fadd.4s	v5, v5, v7
	fadd.4s	v3, v3, v4
	fadd.4s	v4, v5, v8
	sshr.4s	v5, v6, #1
	shl.4s	v7, v5, #23
	add.4s	v7, v7, v8
	fmul.4s	v4, v4, v7
	fadd.4s	v3, v3, v8
	sshr.4s	v7, v2, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v8
	fmul.4s	v3, v3, v16
	sub.4s	v5, v6, v5
	sub.4s	v2, v2, v7
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v8
	fmul.4s	v2, v3, v2
	shl.4s	v3, v5, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	fcmgt.4s	v4, v9, v17
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v9, v18
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v18, v10
	bit.16b	v2, v11, v4
	stp	q18, q2, [sp, #656]             ; 32-byte Folded Spill
	fcmgt.4s	v2, v17, v10
	bsl.16b	v2, v11, v3
	stp	q17, q2, [sp, #560]             ; 32-byte Folded Spill
	ldr	q2, [sp, #752]                  ; 16-byte Reload
	fsub.4s	v2, v2, v27
	and.16b	v17, v1, v2
	fcmge.4s	v2, v17, v9
	fcmge.4s	v3, v10, v17
	and.16b	v2, v2, v3
	ldr	q3, [sp, #768]                  ; 16-byte Reload
	fsub.4s	v3, v3, v22
	and.16b	v18, v0, v3
	fcmge.4s	v3, v18, v9
	fcmge.4s	v4, v10, v18
	and.16b	v3, v3, v4
	and.16b	v3, v3, v18
	fmul.4s	v4, v3, v28
	mov.16b	v5, v21
	bsl.16b	v5, v23, v4
	fadd.4s	v4, v4, v5
	fsub.4s	v4, v4, v5
	and.16b	v5, v2, v17
	fmul.4s	v2, v5, v28
	mov.16b	v6, v21
	bsl.16b	v6, v23, v2
	fadd.4s	v2, v2, v6
	fsub.4s	v6, v2, v6
	fcvtzs.4s	v2, v4
	scvtf.4s	v4, v2
	fmul.4s	v7, v4, v25
	fsub.4s	v3, v3, v7
	fcvtzs.4s	v6, v6
	scvtf.4s	v7, v6
	fmul.4s	v16, v7, v25
	fsub.4s	v5, v5, v16
	fmul.4s	v7, v7, v13
	fsub.4s	v5, v5, v7
	fmul.4s	v4, v4, v13
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v3, v12
	fadd.4s	v4, v4, v15
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v14
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v29
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v30
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v31
	fmul.4s	v7, v3, v3
	fmul.4s	v4, v7, v4
	fmul.4s	v7, v5, v12
	fadd.4s	v7, v7, v15
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v14
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v29
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v30
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v31
	fmul.4s	v16, v5, v5
	fmul.4s	v7, v16, v7
	fadd.4s	v5, v5, v7
	fadd.4s	v3, v3, v4
	fadd.4s	v4, v5, v8
	sshr.4s	v5, v6, #1
	shl.4s	v7, v5, #23
	add.4s	v7, v7, v8
	fmul.4s	v4, v4, v7
	fadd.4s	v3, v3, v8
	sshr.4s	v7, v2, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v8
	fmul.4s	v3, v3, v16
	sub.4s	v5, v6, v5
	sub.4s	v2, v2, v7
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v8
	fmul.4s	v2, v3, v2
	shl.4s	v3, v5, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	fcmgt.4s	v4, v9, v17
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v9, v18
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v18, v10
	bit.16b	v2, v11, v4
	stp	q18, q2, [sp, #752]             ; 32-byte Folded Spill
	fcmgt.4s	v2, v17, v10
	bsl.16b	v2, v11, v3
	stp	q17, q2, [sp, #528]             ; 32-byte Folded Spill
	ldr	q2, [sp, #848]                  ; 16-byte Reload
	fsub.4s	v2, v2, v27
	and.16b	v7, v1, v2
	fcmge.4s	v2, v7, v9
	fcmge.4s	v3, v10, v7
	and.16b	v2, v2, v3
	ldr	q3, [sp, #864]                  ; 16-byte Reload
	fsub.4s	v3, v3, v22
	and.16b	v16, v0, v3
	fcmge.4s	v3, v16, v9
	fcmge.4s	v4, v10, v16
	and.16b	v3, v3, v4
	and.16b	v3, v3, v16
	fmul.4s	v4, v3, v28
	mov.16b	v5, v21
	bsl.16b	v5, v23, v4
	fadd.4s	v4, v4, v5
	fsub.4s	v4, v4, v5
	and.16b	v5, v2, v7
	fmul.4s	v2, v5, v28
	mov.16b	v6, v21
	bsl.16b	v6, v23, v2
	fadd.4s	v2, v2, v6
	fsub.4s	v6, v2, v6
	fcvtzs.4s	v2, v4
	scvtf.4s	v4, v2
	fmul.4s	v18, v4, v25
	fsub.4s	v3, v3, v18
	fcvtzs.4s	v6, v6
	scvtf.4s	v18, v6
	fmul.4s	v19, v18, v25
	fsub.4s	v5, v5, v19
	fmul.4s	v18, v18, v13
	fsub.4s	v5, v5, v18
	fmul.4s	v4, v4, v13
	fsub.4s	v3, v3, v4
	fmul.4s	v4, v3, v12
	fadd.4s	v4, v4, v15
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v14
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v29
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v30
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v4, v31
	fmul.4s	v18, v3, v3
	fmul.4s	v4, v18, v4
	fmul.4s	v18, v5, v12
	fadd.4s	v18, v18, v15
	fmul.4s	v18, v5, v18
	fadd.4s	v18, v18, v14
	fmul.4s	v18, v5, v18
	fadd.4s	v18, v18, v29
	fmul.4s	v18, v5, v18
	fadd.4s	v18, v18, v30
	fmul.4s	v18, v5, v18
	fadd.4s	v18, v18, v31
	fmul.4s	v19, v5, v5
	fmul.4s	v18, v19, v18
	fadd.4s	v5, v5, v18
	fadd.4s	v3, v3, v4
	fadd.4s	v4, v5, v8
	sshr.4s	v5, v6, #1
	shl.4s	v18, v5, #23
	add.4s	v18, v18, v8
	fmul.4s	v4, v4, v18
	fadd.4s	v3, v3, v8
	sshr.4s	v18, v2, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v8
	fmul.4s	v3, v3, v19
	sub.4s	v5, v6, v5
	sub.4s	v2, v2, v18
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v8
	fmul.4s	v2, v3, v2
	shl.4s	v3, v5, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	fcmgt.4s	v4, v9, v7
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v9, v16
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v16, v10
	bit.16b	v2, v11, v4
	stp	q16, q2, [sp, #848]             ; 32-byte Folded Spill
	fcmgt.4s	v2, v7, v10
	bsl.16b	v2, v11, v3
	stp	q7, q2, [sp, #496]              ; 32-byte Folded Spill
	ldr	q2, [sp, #944]                  ; 16-byte Reload
	fsub.4s	v2, v2, v27
	and.16b	v4, v1, v2
	fcmge.4s	v2, v4, v9
	fcmge.4s	v3, v10, v4
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1040]                 ; 16-byte Reload
	fsub.4s	v3, v3, v22
	and.16b	v6, v0, v3
	fcmge.4s	v3, v6, v9
	fcmge.4s	v5, v10, v6
	and.16b	v3, v3, v5
	and.16b	v3, v3, v6
	fmul.4s	v5, v3, v28
	mov.16b	v18, v21
	bsl.16b	v18, v23, v5
	fadd.4s	v5, v5, v18
	fsub.4s	v5, v5, v18
	and.16b	v18, v2, v4
	fmul.4s	v2, v18, v28
	mov.16b	v19, v21
	bsl.16b	v19, v23, v2
	fadd.4s	v2, v2, v19
	fsub.4s	v19, v2, v19
	fcvtzs.4s	v2, v5
	scvtf.4s	v5, v2
	fmul.4s	v24, v5, v25
	fsub.4s	v3, v3, v24
	fcvtzs.4s	v19, v19
	scvtf.4s	v24, v19
	fmul.4s	v26, v24, v25
	fsub.4s	v18, v18, v26
	fmul.4s	v24, v24, v13
	fsub.4s	v18, v18, v24
	fmul.4s	v5, v5, v13
	fsub.4s	v3, v3, v5
	fmul.4s	v5, v3, v12
	fadd.4s	v5, v5, v15
	fmul.4s	v5, v3, v5
	fadd.4s	v5, v5, v14
	fmul.4s	v5, v3, v5
	fadd.4s	v5, v5, v29
	fmul.4s	v5, v3, v5
	fadd.4s	v5, v5, v30
	fmul.4s	v5, v3, v5
	fadd.4s	v5, v5, v31
	fmul.4s	v24, v3, v3
	fmul.4s	v5, v24, v5
	fmul.4s	v24, v18, v12
	fadd.4s	v24, v24, v15
	fmul.4s	v24, v18, v24
	fadd.4s	v24, v24, v14
	fmul.4s	v24, v18, v24
	fadd.4s	v24, v24, v29
	fmul.4s	v24, v18, v24
	fadd.4s	v24, v24, v30
	fmul.4s	v24, v18, v24
	fadd.4s	v24, v24, v31
	fmul.4s	v26, v18, v18
	fmul.4s	v24, v26, v24
	fadd.4s	v18, v18, v24
	fadd.4s	v3, v3, v5
	fadd.4s	v5, v18, v8
	sshr.4s	v18, v19, #1
	shl.4s	v24, v18, #23
	add.4s	v24, v24, v8
	fmul.4s	v5, v5, v24
	fadd.4s	v3, v3, v8
	sshr.4s	v24, v2, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v8
	fmul.4s	v3, v3, v26
	sub.4s	v18, v19, v18
	sub.4s	v2, v2, v24
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v8
	fmul.4s	v2, v3, v2
	shl.4s	v3, v18, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v5, v3
	fcmgt.4s	v5, v9, v4
	bic.16b	v3, v3, v5
	str	q6, [sp, #480]                  ; 16-byte Spill
	fcmgt.4s	v5, v9, v6
	bic.16b	v2, v2, v5
	fcmgt.4s	v5, v6, v10
	bit.16b	v2, v11, v5
	str	q2, [sp, #944]                  ; 16-byte Spill
	fcmgt.4s	v2, v4, v10
	bsl.16b	v2, v11, v3
	stp	q4, q2, [sp, #448]              ; 32-byte Folded Spill
	ldr	q2, [sp, #2512]                 ; 16-byte Reload
	fsub.4s	v2, v2, v22
	and.16b	v20, v0, v2
	fcmge.4s	v2, v20, v9
	fcmge.4s	v5, v10, v20
	and.16b	v5, v2, v5
	mov.16b	v31, v27
	ldr	q2, [sp, #2528]                 ; 16-byte Reload
	fsub.4s	v2, v2, v27
	and.16b	v16, v1, v2
	fcmge.4s	v18, v16, v9
	fcmge.4s	v19, v10, v16
	and.16b	v18, v18, v19
	and.16b	v18, v18, v16
	fmul.4s	v19, v18, v28
	mov.16b	v24, v21
	bsl.16b	v24, v23, v19
	fadd.4s	v19, v19, v24
	fsub.4s	v19, v19, v24
	and.16b	v24, v5, v20
	fmul.4s	v5, v24, v28
	mov.16b	v17, v28
	mov.16b	v26, v21
	bsl.16b	v26, v23, v5
	fadd.4s	v5, v5, v26
	fsub.4s	v26, v5, v26
	fcvtzs.4s	v5, v19
	scvtf.4s	v19, v5
	fmul.4s	v27, v19, v25
	fsub.4s	v18, v18, v27
	fcvtzs.4s	v26, v26
	scvtf.4s	v27, v26
	fmul.4s	v28, v27, v25
	fsub.4s	v24, v24, v28
	fmul.4s	v27, v27, v13
	fsub.4s	v24, v24, v27
	fmul.4s	v19, v19, v13
	fsub.4s	v18, v18, v19
	fmul.4s	v19, v18, v12
	fadd.4s	v19, v19, v15
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v14
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v29
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v19, v30
	fmul.4s	v19, v18, v19
	movi.4s	v2, #63, lsl #24
	fadd.4s	v19, v19, v2
	fmul.4s	v27, v18, v18
	fmul.4s	v19, v27, v19
	fmul.4s	v27, v24, v12
	mov.16b	v4, v12
	fadd.4s	v27, v27, v15
	mov.16b	v12, v15
	fmul.4s	v27, v24, v27
	fadd.4s	v27, v27, v14
	mov.16b	v6, v14
	fmul.4s	v27, v24, v27
	fadd.4s	v27, v27, v29
	mov.16b	v15, v29
	fmul.4s	v27, v24, v27
	fadd.4s	v27, v27, v30
	mov.16b	v14, v30
	fmul.4s	v27, v24, v27
	fadd.4s	v27, v27, v2
	movi.4s	v3, #63, lsl #24
	fmul.4s	v28, v24, v24
	fmul.4s	v27, v28, v27
	fadd.4s	v24, v24, v27
	fadd.4s	v18, v18, v19
	fadd.4s	v19, v24, v8
	sshr.4s	v24, v26, #1
	shl.4s	v27, v24, #23
	add.4s	v27, v27, v8
	fmul.4s	v19, v19, v27
	fadd.4s	v18, v18, v8
	sshr.4s	v27, v5, #1
	shl.4s	v28, v27, #23
	add.4s	v28, v28, v8
	fmul.4s	v18, v18, v28
	sub.4s	v24, v26, v24
	sub.4s	v5, v5, v27
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v8
	fmul.4s	v5, v18, v5
	shl.4s	v18, v24, #23
	add.4s	v18, v18, v8
	fmul.4s	v18, v19, v18
	str	q20, [sp, #432]                 ; 16-byte Spill
	fcmgt.4s	v19, v9, v20
	bic.16b	v18, v18, v19
	fcmgt.4s	v19, v9, v16
	bic.16b	v5, v5, v19
	fcmgt.4s	v19, v16, v10
	mov.16b	v2, v19
	bsl.16b	v2, v11, v5
	str	q2, [sp, #2528]                 ; 16-byte Spill
	fcmgt.4s	v5, v20, v10
	mov.16b	v2, v5
	bsl.16b	v2, v11, v18
	str	q2, [sp, #2512]                 ; 16-byte Spill
	ldr	q2, [sp, #2608]                 ; 16-byte Reload
	fsub.4s	v5, v2, v31
	str	q31, [sp, #4656]                ; 16-byte Spill
	and.16b	v7, v1, v5
	fcmge.4s	v18, v7, v9
	fcmge.4s	v19, v10, v7
	and.16b	v18, v18, v19
	ldr	q2, [sp, #2624]                 ; 16-byte Reload
	fsub.4s	v19, v2, v22
	and.16b	v2, v0, v19
	fcmge.4s	v19, v2, v9
	fcmge.4s	v26, v10, v2
	and.16b	v19, v19, v26
	and.16b	v19, v19, v2
	fmul.4s	v26, v19, v17
	mov.16b	v27, v21
	bsl.16b	v27, v23, v26
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	and.16b	v27, v18, v7
	fmul.4s	v18, v27, v17
	mov.16b	v20, v17
	mov.16b	v28, v21
	bsl.16b	v28, v23, v18
	fadd.4s	v18, v18, v28
	fsub.4s	v28, v18, v28
	fcvtzs.4s	v18, v26
	scvtf.4s	v26, v18
	fmul.4s	v29, v26, v25
	fsub.4s	v19, v19, v29
	fcvtzs.4s	v28, v28
	scvtf.4s	v29, v28
	fmul.4s	v30, v29, v25
	fsub.4s	v27, v27, v30
	fmul.4s	v29, v29, v13
	fsub.4s	v27, v27, v29
	fmul.4s	v26, v26, v13
	fsub.4s	v19, v19, v26
	mov.16b	v24, v4
	fmul.4s	v26, v19, v4
	fadd.4s	v26, v26, v12
	fmul.4s	v26, v19, v26
	mov.16b	v4, v6
	fadd.4s	v26, v26, v6
	fmul.4s	v26, v19, v26
	fadd.4s	v26, v26, v15
	fmul.4s	v26, v19, v26
	mov.16b	v6, v14
	fadd.4s	v26, v26, v14
	fmul.4s	v26, v19, v26
	fadd.4s	v26, v26, v3
	fmul.4s	v29, v19, v19
	fmul.4s	v26, v29, v26
	fmul.4s	v29, v27, v24
	fadd.4s	v29, v29, v12
	mov.16b	v17, v12
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v4
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v15
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v14
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v3
	fmul.4s	v30, v27, v27
	fmul.4s	v29, v30, v29
	fadd.4s	v27, v27, v29
	fadd.4s	v19, v19, v26
	fadd.4s	v26, v27, v8
	sshr.4s	v27, v28, #1
	shl.4s	v29, v27, #23
	add.4s	v29, v29, v8
	fmul.4s	v26, v26, v29
	fadd.4s	v19, v19, v8
	sshr.4s	v29, v18, #1
	shl.4s	v30, v29, #23
	add.4s	v30, v30, v8
	fmul.4s	v19, v19, v30
	sub.4s	v27, v28, v27
	sub.4s	v18, v18, v29
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v8
	fmul.4s	v18, v19, v18
	shl.4s	v19, v27, #23
	add.4s	v19, v19, v8
	fmul.4s	v19, v26, v19
	fcmgt.4s	v26, v9, v7
	bic.16b	v19, v19, v26
	str	q2, [sp, #2608]                 ; 16-byte Spill
	fcmgt.4s	v26, v9, v2
	bic.16b	v18, v18, v26
	fcmgt.4s	v26, v2, v10
	mov.16b	v2, v26
	bsl.16b	v2, v11, v18
	str	q2, [sp, #2624]                 ; 16-byte Spill
	fcmgt.4s	v18, v7, v10
	mov.16b	v2, v18
	bsl.16b	v2, v11, v19
	stp	q7, q2, [sp, #400]              ; 32-byte Folded Spill
	ldr	q2, [sp, #2640]                 ; 16-byte Reload
	fsub.4s	v18, v2, v31
	and.16b	v21, v1, v18
	fcmge.4s	v18, v21, v9
	fcmge.4s	v19, v10, v21
	and.16b	v18, v18, v19
	ldr	q2, [sp, #2720]                 ; 16-byte Reload
	fsub.4s	v19, v2, v22
	and.16b	v30, v0, v19
	fcmge.4s	v19, v30, v9
	fcmge.4s	v26, v10, v30
	and.16b	v19, v19, v26
	and.16b	v19, v19, v30
	mov.16b	v23, v20
	fmul.4s	v26, v19, v20
	movi.4s	v2, #75, lsl #24
	mvni.4s	v3, #128, lsl #24
	mov.16b	v27, v3
	bsl.16b	v27, v2, v26
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	and.16b	v27, v18, v21
	fmul.4s	v18, v27, v20
	mov.16b	v28, v3
	bsl.16b	v28, v2, v18
	fadd.4s	v18, v18, v28
	fsub.4s	v28, v18, v28
	fcvtzs.4s	v18, v26
	scvtf.4s	v26, v18
	fmul.4s	v29, v26, v25
	fsub.4s	v19, v19, v29
	fcvtzs.4s	v28, v28
	scvtf.4s	v29, v28
	fmul.4s	v31, v29, v25
	fsub.4s	v27, v27, v31
	mov.16b	v20, v13
	fmul.4s	v29, v29, v13
	fsub.4s	v27, v27, v29
	fmul.4s	v26, v26, v13
	fsub.4s	v19, v19, v26
	mov.16b	v12, v24
	fmul.4s	v26, v19, v24
	mov.16b	v24, v17
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v19, v26
	fadd.4s	v26, v26, v4
	fmul.4s	v26, v19, v26
	str	q15, [sp, #352]                 ; 16-byte Spill
	fadd.4s	v26, v26, v15
	fmul.4s	v26, v19, v26
	fadd.4s	v26, v26, v14
	fmul.4s	v26, v19, v26
	movi.4s	v2, #63, lsl #24
	fadd.4s	v26, v26, v2
	fmul.4s	v29, v19, v19
	fmul.4s	v26, v29, v26
	fmul.4s	v29, v27, v12
	fadd.4s	v29, v29, v17
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v4
	mov.16b	v14, v4
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v15
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v6
	mov.16b	v17, v6
	fmul.4s	v29, v27, v29
	fadd.4s	v29, v29, v2
	movi.4s	v6, #63, lsl #24
	fmul.4s	v31, v27, v27
	fmul.4s	v29, v31, v29
	fadd.4s	v27, v27, v29
	fadd.4s	v19, v19, v26
	fadd.4s	v26, v27, v8
	sshr.4s	v27, v28, #1
	shl.4s	v29, v27, #23
	add.4s	v29, v29, v8
	fmul.4s	v26, v26, v29
	fadd.4s	v19, v19, v8
	sshr.4s	v29, v18, #1
	shl.4s	v31, v29, #23
	add.4s	v31, v31, v8
	fmul.4s	v19, v19, v31
	sub.4s	v27, v28, v27
	sub.4s	v18, v18, v29
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v8
	fmul.4s	v18, v19, v18
	shl.4s	v19, v27, #23
	add.4s	v19, v19, v8
	fmul.4s	v19, v26, v19
	fcmgt.4s	v26, v9, v21
	bic.16b	v19, v19, v26
	str	q30, [sp, #320]                 ; 16-byte Spill
	fcmgt.4s	v26, v9, v30
	bic.16b	v18, v18, v26
	fcmgt.4s	v26, v30, v10
	mov.16b	v2, v26
	bsl.16b	v2, v11, v18
	str	q2, [sp, #2640]                 ; 16-byte Spill
	fcmgt.4s	v18, v21, v10
	mov.16b	v2, v10
	mov.16b	v4, v18
	bsl.16b	v4, v11, v19
	stp	q21, q4, [sp, #368]             ; 32-byte Folded Spill
	mov.16b	v10, v11
	str	q22, [sp, #1040]                ; 16-byte Spill
	ldr	q5, [sp, #4576]                 ; 16-byte Reload
	fsub.4s	v18, v5, v22
	and.16b	v15, v0, v18
	fcmge.4s	v18, v15, v9
	fcmge.4s	v19, v2, v15
	and.16b	v18, v18, v19
	ldr	q4, [sp, #4560]                 ; 16-byte Reload
	ldr	q5, [sp, #4656]                 ; 16-byte Reload
	fsub.4s	v19, v4, v5
	and.16b	v11, v1, v19
	fcmge.4s	v19, v11, v9
	fcmge.4s	v26, v2, v11
	and.16b	v19, v19, v26
	and.16b	v19, v19, v11
	fmul.4s	v26, v19, v23
	mvni.4s	v4, #128, lsl #24
	movi.4s	v5, #75, lsl #24
	mov.16b	v27, v4
	bsl.16b	v27, v5, v26
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	and.16b	v18, v18, v15
	fmul.4s	v27, v18, v23
	mov.16b	v28, v4
	bsl.16b	v28, v5, v27
	fadd.4s	v27, v27, v28
	fsub.4s	v27, v27, v28
	fcvtzs.4s	v26, v26
	scvtf.4s	v28, v26
	fmul.4s	v31, v28, v25
	fsub.4s	v19, v19, v31
	fcvtzs.4s	v27, v27
	scvtf.4s	v31, v27
	fmul.4s	v13, v31, v25
	fsub.4s	v18, v18, v13
	fmul.4s	v28, v28, v20
	fmul.4s	v31, v31, v20
	fsub.4s	v18, v18, v31
	fsub.4s	v19, v19, v28
	fmul.4s	v28, v19, v12
	fmul.4s	v31, v18, v12
	fadd.4s	v31, v31, v24
	fadd.4s	v28, v28, v24
	fmul.4s	v28, v19, v28
	fmul.4s	v31, v18, v31
	fadd.4s	v31, v31, v14
	fadd.4s	v28, v28, v14
	fmul.4s	v28, v19, v28
	fmul.4s	v31, v18, v31
	ldr	q4, [sp, #352]                  ; 16-byte Reload
	fadd.4s	v31, v31, v4
	fadd.4s	v28, v28, v4
	fmul.4s	v28, v19, v28
	fmul.4s	v31, v18, v31
	fadd.4s	v31, v31, v17
	fadd.4s	v28, v28, v17
	fmul.4s	v28, v19, v28
	fadd.4s	v28, v28, v6
	fmul.4s	v13, v19, v19
	fmul.4s	v28, v13, v28
	fmul.4s	v31, v18, v31
	fadd.4s	v31, v31, v6
	fmul.4s	v13, v18, v18
	fmul.4s	v31, v13, v31
	fadd.4s	v18, v18, v31
	fadd.4s	v19, v19, v28
	fadd.4s	v18, v18, v8
	sshr.4s	v28, v27, #1
	shl.4s	v31, v28, #23
	add.4s	v31, v31, v8
	fmul.4s	v18, v18, v31
	fadd.4s	v19, v19, v8
	sshr.4s	v31, v26, #1
	shl.4s	v13, v31, #23
	add.4s	v13, v13, v8
	fmul.4s	v19, v19, v13
	sub.4s	v27, v27, v28
	sub.4s	v26, v26, v31
	shl.4s	v26, v26, #23
	add.4s	v26, v26, v8
	fmul.4s	v19, v19, v26
	shl.4s	v26, v27, #23
	add.4s	v26, v26, v8
	fmul.4s	v18, v18, v26
	fcmgt.4s	v26, v9, v15
	bic.16b	v18, v18, v26
	fcmgt.4s	v26, v9, v11
	bic.16b	v19, v19, v26
	fcmgt.4s	v26, v11, v2
	mov.16b	v3, v26
	bsl.16b	v3, v10, v19
	fcmgt.4s	v19, v15, v2
	mov.16b	v2, v19
	bsl.16b	v2, v10, v18
	stp	q2, q3, [sp, #336]              ; 32-byte Folded Spill
	ldr	q2, [sp, #4640]                 ; 16-byte Reload
	fcmeq.4s	v18, v2, v2
	ldr	q3, [sp, #288]                  ; 16-byte Reload
	ldr	q2, [sp, #4672]                 ; 16-byte Reload
	mov.16b	v10, v18
	bsl.16b	v10, v2, v3
	str	q10, [sp, #4640]                ; 16-byte Spill
	ldr	q2, [sp, #4704]                 ; 16-byte Reload
	fcmeq.4s	v18, v2, v2
	ldr	q2, [sp, #4688]                 ; 16-byte Reload
	bif.16b	v2, v3, v18
	str	q2, [sp, #4704]                 ; 16-byte Spill
	ldr	q2, [sp, #2736]                 ; 16-byte Reload
	fcmeq.4s	v18, v2, v2
	ldr	q2, [sp, #4624]                 ; 16-byte Reload
	bif.16b	v2, v3, v18
	str	q2, [sp, #4624]                 ; 16-byte Spill
	ldr	q2, [sp, #4592]                 ; 16-byte Reload
	fcmeq.4s	v18, v2, v2
	ldr	q2, [sp, #4608]                 ; 16-byte Reload
	bif.16b	v2, v3, v18
	str	q2, [sp, #4688]                 ; 16-byte Spill
	ldr	q2, [sp, #2656]                 ; 16-byte Reload
	fcmeq.4s	v18, v2, v2
	ldr	q2, [sp, #2672]                 ; 16-byte Reload
	bif.16b	v2, v3, v18
	str	q2, [sp, #4608]                 ; 16-byte Spill
	ldr	q2, [sp, #2688]                 ; 16-byte Reload
	fcmeq.4s	v18, v2, v2
	ldr	q2, [sp, #2704]                 ; 16-byte Reload
	bif.16b	v2, v3, v18
	str	q2, [sp, #4672]                 ; 16-byte Spill
	ldr	q2, [sp, #2544]                 ; 16-byte Reload
	fcmeq.4s	v18, v2, v2
	ldr	q2, [sp, #2560]                 ; 16-byte Reload
	bif.16b	v2, v3, v18
	str	q2, [sp, #4592]                 ; 16-byte Spill
	ldr	q2, [sp, #2576]                 ; 16-byte Reload
	fcmeq.4s	v18, v2, v2
	ldr	q2, [sp, #2592]                 ; 16-byte Reload
	bif.16b	v2, v3, v18
	str	q2, [sp, #2736]                 ; 16-byte Spill
	ldp	q4, q2, [sp, #960]              ; 32-byte Folded Reload
	fcmeq.4s	v18, v4, v4
	bif.16b	v2, v3, v18
	str	q2, [sp, #2720]                 ; 16-byte Spill
	ldp	q5, q2, [sp, #992]              ; 32-byte Folded Reload
	fcmeq.4s	v18, v5, v5
	bif.16b	v2, v3, v18
	str	q2, [sp, #2704]                 ; 16-byte Spill
	ldp	q6, q2, [sp, #880]              ; 32-byte Folded Reload
	fcmeq.4s	v18, v6, v6
	mov.16b	v17, v18
	bsl.16b	v17, v2, v3
	ldr	q2, [sp, #912]                  ; 16-byte Reload
	fcmeq.4s	v18, v2, v2
	ldr	q2, [sp, #928]                  ; 16-byte Reload
	bif.16b	v2, v3, v18
	ldr	q4, [sp, #784]                  ; 16-byte Reload
	fcmeq.4s	v18, v4, v4
	ldr	q4, [sp, #800]                  ; 16-byte Reload
	mov.16b	v5, v18
	bsl.16b	v5, v4, v3
	ldr	q4, [sp, #816]                  ; 16-byte Reload
	fcmeq.4s	v18, v4, v4
	ldr	q4, [sp, #832]                  ; 16-byte Reload
	mov.16b	v13, v18
	bsl.16b	v13, v4, v3
	ldr	q4, [sp, #688]                  ; 16-byte Reload
	fcmeq.4s	v18, v4, v4
	ldr	q4, [sp, #704]                  ; 16-byte Reload
	mov.16b	v6, v18
	bsl.16b	v6, v4, v3
	ldr	q4, [sp, #720]                  ; 16-byte Reload
	fcmeq.4s	v18, v4, v4
	ldr	q4, [sp, #736]                  ; 16-byte Reload
	bif.16b	v4, v3, v18
	ldr	q7, [sp, #592]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #608]                  ; 16-byte Reload
	mov.16b	v20, v18
	bsl.16b	v20, v7, v3
	ldr	q7, [sp, #624]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #640]                  ; 16-byte Reload
	mov.16b	v19, v18
	bsl.16b	v19, v7, v3
	ldr	q7, [sp, #560]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #576]                  ; 16-byte Reload
	mov.16b	v24, v18
	bsl.16b	v24, v7, v3
	ldr	q7, [sp, #656]                  ; 16-byte Reload
	fcmeq.4s	v18, v7, v7
	ldr	q7, [sp, #672]                  ; 16-byte Reload
	bsl.16b	v18, v7, v3
	ldr	q7, [sp, #528]                  ; 16-byte Reload
	fcmeq.4s	v21, v7, v7
	ldr	q7, [sp, #544]                  ; 16-byte Reload
	mov.16b	v29, v21
	bsl.16b	v29, v7, v3
	ldr	q7, [sp, #752]                  ; 16-byte Reload
	fcmeq.4s	v25, v7, v7
	ldr	q7, [sp, #768]                  ; 16-byte Reload
	bsl.16b	v25, v7, v3
	ldr	q7, [sp, #496]                  ; 16-byte Reload
	fcmeq.4s	v26, v7, v7
	ldr	q7, [sp, #512]                  ; 16-byte Reload
	mov.16b	v31, v26
	bsl.16b	v31, v7, v3
	ldr	q7, [sp, #848]                  ; 16-byte Reload
	fcmeq.4s	v22, v7, v7
	ldr	q7, [sp, #864]                  ; 16-byte Reload
	mov.16b	v26, v22
	bsl.16b	v26, v7, v3
	ldr	q7, [sp, #448]                  ; 16-byte Reload
	fcmeq.4s	v23, v7, v7
	ldr	q7, [sp, #464]                  ; 16-byte Reload
	mov.16b	v12, v23
	bsl.16b	v12, v7, v3
	ldr	q7, [sp, #480]                  ; 16-byte Reload
	fcmeq.4s	v27, v7, v7
	ldr	q7, [sp, #944]                  ; 16-byte Reload
	mov.16b	v9, v27
	bsl.16b	v9, v7, v3
	ldr	q7, [sp, #432]                  ; 16-byte Reload
	fcmeq.4s	v28, v7, v7
	ldr	q7, [sp, #2512]                 ; 16-byte Reload
	mov.16b	v14, v28
	bsl.16b	v14, v7, v3
	fcmeq.4s	v16, v16, v16
	ldr	q7, [sp, #2528]                 ; 16-byte Reload
	mov.16b	v28, v16
	bsl.16b	v28, v7, v3
	ldp	q7, q16, [sp, #400]             ; 32-byte Folded Reload
	fcmeq.4s	v7, v7, v7
	bsl.16b	v7, v16, v3
	str	q7, [sp, #976]                  ; 16-byte Spill
	ldr	q7, [sp, #2608]                 ; 16-byte Reload
	fcmeq.4s	v7, v7, v7
	ldr	q16, [sp, #2624]                ; 16-byte Reload
	bsl.16b	v7, v16, v3
	str	q7, [sp, #2512]                 ; 16-byte Spill
	ldp	q7, q16, [sp, #368]             ; 32-byte Folded Reload
	fcmeq.4s	v7, v7, v7
	bsl.16b	v7, v16, v3
	str	q7, [sp, #1008]                 ; 16-byte Spill
	ldr	q7, [sp, #320]                  ; 16-byte Reload
	fcmeq.4s	v7, v7, v7
	ldr	q16, [sp, #2640]                ; 16-byte Reload
	bsl.16b	v7, v16, v3
	str	q7, [sp, #992]                  ; 16-byte Spill
	ldr	d16, [sp, #1024]                ; 8-byte Reload
	zip1.8b	v7, v16, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v2, v7, v2
	str	q2, [sp, #2688]                 ; 16-byte Spill
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v27, v2, v17
	str	q27, [sp, #2672]                ; 16-byte Spill
	zip1.8b	v7, v16, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v2, v7, v13
	str	q2, [sp, #2656]                 ; 16-byte Spill
	zip2.8b	v7, v16, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v30, v7, v5
	zip1.8b	v7, v16, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v2, v7, v4
	str	q2, [sp, #2640]                 ; 16-byte Spill
	zip2.8b	v7, v16, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v22, v7, v6
	str	q22, [sp, #2624]                ; 16-byte Spill
	zip1.8b	v6, v16, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v23, v6, v19
	str	q23, [sp, #2608]                ; 16-byte Spill
	zip2.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v8, v5, v20
	zip2.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v2, v5, v18
	str	q2, [sp, #2592]                 ; 16-byte Spill
	zip1.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v19, v5, v24
	zip2.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v7, v5, v25
	str	q7, [sp, #2576]                 ; 16-byte Spill
	zip1.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v21, v5, v29
	zip2.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v2, v5, v26
	str	q2, [sp, #2560]                 ; 16-byte Spill
	zip1.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v17, v5, v31
	zip2.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v4, v5, v9
	str	q4, [sp, #2544]                 ; 16-byte Spill
	zip1.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v13, v5, v12
	zip1.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v2, v5, v28
	str	q2, [sp, #2528]                 ; 16-byte Spill
	zip2.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v9, v5, v14
	ldp	x4, x5, [sp, #136]              ; 16-byte Folded Reload
	ldr	q5, [x5, #16]
	ldr	q6, [sp, #4704]                 ; 16-byte Reload
	bit.16b	v5, v6, v0
	ldr	q6, [x5]
	bit.16b	v6, v10, v1
	stp	q6, q5, [x5]
	zip2.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #2512]                 ; 16-byte Reload
	and.16b	v28, v5, v6
	str	q28, [sp, #2512]                ; 16-byte Spill
	ldr	q5, [x4, #16]
	ldr	q6, [sp, #4688]                 ; 16-byte Reload
	bit.16b	v5, v6, v0
	ldr	q6, [x4]
	ldr	q12, [sp, #4624]                ; 16-byte Reload
	bit.16b	v6, v12, v1
	stp	q6, q5, [x4]
	zip1.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #976]                  ; 16-byte Reload
	and.16b	v26, v5, v6
	ldp	x4, x6, [sp, #120]              ; 16-byte Folded Reload
	ldr	q5, [x6, #16]
	ldr	q6, [sp, #4672]                 ; 16-byte Reload
	bit.16b	v5, v6, v0
	ldr	q6, [x6]
	ldr	q29, [sp, #4608]                ; 16-byte Reload
	bit.16b	v6, v29, v1
	stp	q6, q5, [x6]
	zip2.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #992]                  ; 16-byte Reload
	and.16b	v31, v5, v6
	ldp	q6, q5, [x4]
	ldr	q24, [sp, #2736]                ; 16-byte Reload
	bit.16b	v5, v24, v0
	ldr	q14, [sp, #4592]                ; 16-byte Reload
	bit.16b	v6, v14, v1
	stp	q6, q5, [x4]
	zip1.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #1008]                 ; 16-byte Reload
	and.16b	v25, v5, v6
	ldp	x4, x7, [sp, #104]              ; 16-byte Folded Reload
	ldp	q6, q5, [x7]
	ldr	q18, [sp, #2704]                ; 16-byte Reload
	bit.16b	v5, v18, v0
	ldr	q16, [sp, #2720]                ; 16-byte Reload
	bit.16b	v6, v16, v1
	stp	q6, q5, [x7]
	ldp	q6, q5, [x4]
	bit.16b	v5, v27, v0
	ldr	q27, [sp, #2688]                ; 16-byte Reload
	bit.16b	v6, v27, v1
	stp	q6, q5, [x4]
	ldr	x4, [sp, #96]                   ; 8-byte Reload
	ldp	q6, q5, [x4]
	bit.16b	v5, v30, v0
	ldr	q10, [sp, #2656]                ; 16-byte Reload
	bit.16b	v6, v10, v1
	stp	q6, q5, [x4]
	ldr	x4, [sp, #88]                   ; 8-byte Reload
	ldp	q6, q5, [x4]
	bit.16b	v5, v22, v0
	ldr	q20, [sp, #2640]                ; 16-byte Reload
	bit.16b	v6, v20, v1
	stp	q6, q5, [x4]
	ldp	q6, q5, [x20]
	bit.16b	v5, v8, v0
	bit.16b	v6, v23, v1
	stp	q6, q5, [x20]
	ldp	q5, q6, [x21]
	bit.16b	v5, v19, v1
	mov.16b	v22, v19
	ldr	q19, [sp, #2592]                ; 16-byte Reload
	bit.16b	v6, v19, v0
	stp	q5, q6, [x21]
	ldp	q5, q6, [x22]
	bit.16b	v5, v21, v1
	bit.16b	v6, v7, v0
	stp	q5, q6, [x22]
	ldp	q5, q6, [x23]
	bit.16b	v5, v17, v1
	ldr	q7, [sp, #2560]                 ; 16-byte Reload
	bit.16b	v6, v7, v0
	stp	q5, q6, [x23]
	ldp	q5, q6, [x24]
	bit.16b	v5, v13, v1
	bit.16b	v6, v4, v0
	stp	q5, q6, [x24]
	ldp	q6, q5, [x25]
	bit.16b	v5, v9, v0
	bit.16b	v6, v2, v1
	stp	q6, q5, [x25]
	ldp	q5, q6, [x26]
	bit.16b	v5, v26, v1
	bit.16b	v6, v28, v0
	stp	q5, q6, [x26]
	ldp	q5, q6, [x27]
	bit.16b	v5, v25, v1
	bit.16b	v6, v31, v0
	stp	q5, q6, [x27]
	fcmeq.4s	v5, v15, v15
	ldp	q6, q2, [sp, #336]              ; 32-byte Folded Reload
	mov.16b	v4, v5
	bsl.16b	v4, v6, v3
	fcmeq.4s	v5, v11, v11
	mov.16b	v6, v5
	bsl.16b	v6, v2, v3
	sshll.2d	v5, v0, #0
	ldr	q2, [sp, #2240]                 ; 16-byte Reload
	ldr	q3, [sp, #1216]                 ; 16-byte Reload
	bit.16b	v3, v2, v5
	str	q3, [sp, #1216]                 ; 16-byte Spill
	ldr	q3, [sp, #2384]                 ; 16-byte Reload
	bit.16b	v3, v2, v5
	str	q3, [sp, #2384]                 ; 16-byte Spill
	sshll.2d	v5, v1, #0
	ldr	q2, [sp, #2432]                 ; 16-byte Reload
	ldr	q3, [sp, #4752]                 ; 16-byte Reload
	bit.16b	v3, v2, v5
	str	q3, [sp, #4752]                 ; 16-byte Spill
	ldr	q3, [sp, #2416]                 ; 16-byte Reload
	bit.16b	v3, v2, v5
	stp	q6, q4, [sp, #912]              ; 32-byte Folded Spill
	ldr	q2, [sp, #4784]                 ; 16-byte Reload
	bit.16b	v2, v6, v1
	str	q2, [sp, #4784]                 ; 16-byte Spill
	ldr	q2, [sp, #4768]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #4768]                 ; 16-byte Spill
	ldr	q4, [sp, #4816]                 ; 16-byte Reload
	ldr	q2, [sp, #4640]                 ; 16-byte Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #4816]                 ; 16-byte Spill
	ldr	q4, [sp, #4800]                 ; 16-byte Reload
	ldr	q2, [sp, #4704]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #4800]                 ; 16-byte Spill
	ldr	q4, [sp, #4848]                 ; 16-byte Reload
	bit.16b	v4, v12, v1
	str	q4, [sp, #4848]                 ; 16-byte Spill
	ldr	q4, [sp, #4832]                 ; 16-byte Reload
	ldr	q2, [sp, #4688]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #4832]                 ; 16-byte Spill
	ldr	q4, [sp, #4880]                 ; 16-byte Reload
	bit.16b	v4, v29, v1
	str	q4, [sp, #4880]                 ; 16-byte Spill
	ldr	q4, [sp, #4864]                 ; 16-byte Reload
	ldr	q2, [sp, #4672]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #4864]                 ; 16-byte Spill
	ldr	q4, [sp, #4912]                 ; 16-byte Reload
	bit.16b	v4, v14, v1
	str	q4, [sp, #4912]                 ; 16-byte Spill
	ldr	q4, [sp, #4896]                 ; 16-byte Reload
	bit.16b	v4, v24, v0
	str	q4, [sp, #4896]                 ; 16-byte Spill
	ldr	q14, [sp, #2048]                ; 16-byte Reload
	bit.16b	v14, v16, v1
	ldr	q29, [sp, #2032]                ; 16-byte Reload
	bit.16b	v29, v18, v0
	ldr	q11, [sp, #2080]                ; 16-byte Reload
	bit.16b	v11, v27, v1
	ldr	q12, [sp, #2064]                ; 16-byte Reload
	ldr	q2, [sp, #2672]                 ; 16-byte Reload
	bit.16b	v12, v2, v0
	ldr	q23, [sp, #2112]                ; 16-byte Reload
	bit.16b	v23, v10, v1
	ldr	q28, [sp, #2096]                ; 16-byte Reload
	stp	q8, q30, [sp, #1008]            ; 32-byte Folded Spill
	bit.16b	v28, v30, v0
	ldr	q30, [sp, #2144]                ; 16-byte Reload
	bit.16b	v30, v20, v1
	ldr	q10, [sp, #2128]                ; 16-byte Reload
	ldr	q2, [sp, #2624]                 ; 16-byte Reload
	bit.16b	v10, v2, v0
	ldr	q15, [sp, #4512]                ; 16-byte Reload
	ldr	q2, [sp, #2608]                 ; 16-byte Reload
	bit.16b	v15, v2, v1
	ldr	q24, [sp, #2160]                ; 16-byte Reload
	bit.16b	v24, v8, v0
	ldr	q8, [sp, #2176]                 ; 16-byte Reload
	stp	q21, q22, [sp, #976]            ; 32-byte Folded Spill
	bit.16b	v8, v22, v1
	ldr	q22, [sp, #4528]                ; 16-byte Reload
	bit.16b	v22, v19, v0
	ldr	q20, [sp, #2208]                ; 16-byte Reload
	bit.16b	v20, v21, v1
	ldr	q21, [sp, #2192]                ; 16-byte Reload
	ldr	q2, [sp, #2576]                 ; 16-byte Reload
	bit.16b	v21, v2, v0
	ldr	q18, [sp, #1120]                ; 16-byte Reload
	str	q17, [sp, #960]                 ; 16-byte Spill
	bit.16b	v18, v17, v1
	ldr	q19, [sp, #1104]                ; 16-byte Reload
	bit.16b	v19, v7, v0
	ldr	q16, [sp, #1136]                ; 16-byte Reload
	str	q13, [sp, #1120]                ; 16-byte Spill
	bit.16b	v16, v13, v1
	ldr	q17, [sp, #2224]                ; 16-byte Reload
	ldr	q2, [sp, #2544]                 ; 16-byte Reload
	bit.16b	v17, v2, v0
	ldr	q13, [sp, #2304]                ; 16-byte Reload
	ldr	q2, [sp, #2528]                 ; 16-byte Reload
	bit.16b	v13, v2, v1
	ldr	q7, [sp, #2288]                 ; 16-byte Reload
	str	q9, [sp, #1136]                 ; 16-byte Spill
	bit.16b	v7, v9, v0
	ldr	q27, [sp, #2320]                ; 16-byte Reload
	str	q26, [sp, #1104]                ; 16-byte Spill
	bit.16b	v27, v26, v1
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q4, [sp, #2512]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	ldr	q9, [sp, #2352]                 ; 16-byte Reload
	str	q25, [sp, #944]                 ; 16-byte Spill
	bit.16b	v9, v25, v1
	ldr	q26, [sp, #2336]                ; 16-byte Reload
	str	q31, [sp, #2320]                ; 16-byte Spill
	bit.16b	v26, v31, v0
LBB0_95:                                ; %direct.true2447
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	d31, x3
	ldr	q4, [sp, #4720]                 ; 16-byte Reload
	orr.16b	v5, v31, v4
	fmov	x4, d5
	add	x4, x8, x4
	ldp	q6, q5, [x4]
	and.16b	v6, v1, v6
	ldr	q25, [sp, #4752]                ; 16-byte Reload
	orr.16b	v25, v31, v25
	mov.16b	v4, v9
	ldr	q9, [sp, #4784]                 ; 16-byte Reload
	fmul.4s	v6, v9, v6
	fmov	x4, d25
	add	x4, x13, x4
	ldr	q25, [x4]
	and.16b	v25, v1, v25
	ldr	q9, [sp, #4816]                 ; 16-byte Reload
	fmul.4s	v25, v9, v25
	fadd.4s	v6, v6, v25
	ldr	q25, [x4, #16]
	and.16b	v5, v0, v5
	ldr	q9, [sp, #4768]                 ; 16-byte Reload
	fmul.4s	v5, v9, v5
	and.16b	v25, v0, v25
	ldr	q9, [sp, #4800]                 ; 16-byte Reload
	fmul.4s	v25, v9, v25
	fadd.4s	v5, v5, v25
	add	x4, x1, x3
	ldr	q25, [x4, #16]
	and.16b	v25, v0, v25
	ldr	q9, [sp, #4832]                 ; 16-byte Reload
	fmul.4s	v25, v9, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x4]
	and.16b	v25, v1, v25
	ldr	q9, [sp, #4848]                 ; 16-byte Reload
	fmul.4s	v25, v9, v25
	mov.16b	v9, v4
	fadd.4s	v6, v6, v25
	ldr	q25, [x4, #3072]
	and.16b	v25, v1, v25
	ldr	q4, [sp, #4880]                 ; 16-byte Reload
	fmul.4s	v25, v4, v25
	fadd.4s	v6, v6, v25
	ldr	q25, [x4, #3088]
	and.16b	v25, v0, v25
	ldr	q4, [sp, #4864]                 ; 16-byte Reload
	fmul.4s	v25, v4, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x4, #6160]
	and.16b	v25, v0, v25
	ldr	q4, [sp, #4896]                 ; 16-byte Reload
	fmul.4s	v25, v4, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x4, #6144]
	and.16b	v25, v1, v25
	ldr	q4, [sp, #4912]                 ; 16-byte Reload
	fmul.4s	v25, v4, v25
	fadd.4s	v6, v6, v25
	ldr	q25, [x4, #9216]
	and.16b	v25, v1, v25
	fmul.4s	v25, v14, v25
	fadd.4s	v6, v6, v25
	ldr	q25, [x4, #9232]
	and.16b	v25, v0, v25
	fmul.4s	v25, v29, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x4, #12304]
	and.16b	v25, v0, v25
	fmul.4s	v25, v12, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x4, #12288]
	and.16b	v25, v1, v25
	fmul.4s	v25, v11, v25
	fadd.4s	v6, v6, v25
	ldr	q25, [x4, #15360]
	and.16b	v25, v1, v25
	fmul.4s	v25, v23, v25
	fadd.4s	v6, v6, v25
	ldr	q25, [x4, #15376]
	and.16b	v25, v0, v25
	fmul.4s	v25, v28, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x4, #18448]
	and.16b	v25, v0, v25
	fmul.4s	v25, v10, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x4, #18432]
	and.16b	v25, v1, v25
	fmul.4s	v25, v30, v25
	fadd.4s	v6, v6, v25
	ldr	q25, [x4, #21504]
	and.16b	v25, v1, v25
	fmul.4s	v25, v15, v25
	fadd.4s	v6, v6, v25
	ldr	q25, [x4, #21520]
	and.16b	v25, v0, v25
	fmul.4s	v25, v24, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x4, #24592]
	and.16b	v25, v0, v25
	fmul.4s	v25, v22, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x4, #24576]
	and.16b	v25, v1, v25
	fmul.4s	v25, v8, v25
	fadd.4s	v6, v6, v25
	ldr	q25, [x4, #27648]
	and.16b	v25, v1, v25
	fmul.4s	v25, v20, v25
	fadd.4s	v6, v6, v25
	ldr	q25, [x4, #27664]
	and.16b	v25, v0, v25
	fmul.4s	v25, v21, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x4, #30736]
	and.16b	v25, v0, v25
	fmul.4s	v25, v19, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x4, #30720]
	and.16b	v25, v1, v25
	fmul.4s	v25, v18, v25
	fadd.4s	v6, v6, v25
	ldr	q25, [x4, #33792]
	and.16b	v25, v1, v25
	fmul.4s	v25, v16, v25
	fadd.4s	v6, v6, v25
	ldr	q25, [x4, #33808]
	and.16b	v25, v0, v25
	fmul.4s	v25, v17, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x4, #36880]
	and.16b	v25, v0, v25
	fmul.4s	v25, v7, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x4, #36864]
	and.16b	v25, v1, v25
	fmul.4s	v25, v13, v25
	fadd.4s	v6, v6, v25
	ldr	q25, [x4, #39936]
	and.16b	v25, v1, v25
	fmul.4s	v25, v27, v25
	fadd.4s	v6, v6, v25
	ldr	q25, [x4, #39952]
	and.16b	v25, v0, v25
	fmul.4s	v25, v2, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x4, #43024]
	and.16b	v25, v0, v25
	fmul.4s	v25, v26, v25
	fadd.4s	v5, v5, v25
	ldr	q25, [x4, #43008]
	and.16b	v25, v1, v25
	fmul.4s	v25, v9, v25
	fadd.4s	v6, v6, v25
	orr.16b	v25, v31, v3
	fmov	x4, d25
	add	x4, x15, x4
	ldp	q4, q25, [x4]
	bif.16b	v6, v4, v1
	bif.16b	v5, v25, v0
	stp	q6, q5, [x4]
	add	x3, x3, #32
	cmp	x3, #3072
	b.ne	LBB0_95
; %bb.96:                               ; %direct.true2575.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q29, [sp, #2032]                ; 16-byte Spill
	str	q14, [sp, #2048]                ; 16-byte Spill
	str	q12, [sp, #2064]                ; 16-byte Spill
	str	q11, [sp, #2080]                ; 16-byte Spill
	str	q28, [sp, #2096]                ; 16-byte Spill
	str	q23, [sp, #2112]                ; 16-byte Spill
	str	q30, [sp, #2144]                ; 16-byte Spill
	str	q15, [sp, #4512]                ; 16-byte Spill
	str	q22, [sp, #4528]                ; 16-byte Spill
	str	q8, [sp, #2176]                 ; 16-byte Spill
	str	q21, [sp, #2192]                ; 16-byte Spill
	str	q20, [sp, #2208]                ; 16-byte Spill
	str	q17, [sp, #2224]                ; 16-byte Spill
	str	q7, [sp, #2288]                 ; 16-byte Spill
	str	q13, [sp, #2304]                ; 16-byte Spill
	str	q2, [sp, #4544]                 ; 16-byte Spill
	mov.16b	v31, v26
	mov	x3, #0                          ; =0x0
	ldr	q2, [sp, #4720]                 ; 16-byte Reload
LBB0_97:                                ; %direct.true2575
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	d5, x3
	orr.16b	v6, v5, v3
	fmov	x4, d6
	add	x4, x15, x4
	ldp	q6, q25, [x4]
	orr.16b	v5, v5, v2
	fmov	x4, d5
	add	x4, x11, x4
	ldp	q5, q26, [x4]
	bif.16b	v25, v26, v0
	bit.16b	v5, v6, v1
	stp	q5, q25, [x4]
	add	x3, x3, #32
	cmp	x3, #3072
	b.ne	LBB0_97
; %bb.98:                               ; %direct.true2591.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q9, [sp, #2352]                 ; 16-byte Spill
	str	q3, [sp, #2416]                 ; 16-byte Spill
	mov	x3, x10
	mov	w4, #96                         ; =0x60
	mov.16b	v7, v16
	mov.16b	v16, v18
	mov.16b	v17, v19
	str	q24, [sp, #2160]                ; 16-byte Spill
	str	q10, [sp, #2128]                ; 16-byte Spill
	ldr	q18, [sp, #2480]                ; 16-byte Reload
	ldr	q8, [sp, #3008]                 ; 16-byte Reload
	ldr	q21, [sp, #2944]                ; 16-byte Reload
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	ldr	q12, [sp, #2912]                ; 16-byte Reload
	ldr	q15, [sp, #2896]                ; 16-byte Reload
	ldr	q23, [sp, #2880]                ; 16-byte Reload
	ldr	q14, [sp, #2848]                ; 16-byte Reload
	ldr	q20, [sp, #2832]                ; 16-byte Reload
	ldr	q9, [sp, #2816]                 ; 16-byte Reload
	ldr	q30, [sp, #2800]                ; 16-byte Reload
	ldr	q13, [sp, #2784]                ; 16-byte Reload
	ldr	q11, [sp, #2768]                ; 16-byte Reload
	ldr	q28, [sp, #2752]                ; 16-byte Reload
	ldr	q29, [sp, #1072]                ; 16-byte Reload
LBB0_99:                                ; %direct.true2591
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q5, [x3, #5632]
	ldr	q6, [x3, #5648]
	ldr	q25, [x3, #2560]
	ldr	q26, [x3, #2576]
	bif.16b	v6, v26, v0
	bif.16b	v5, v25, v1
	str	q5, [x3, #2560]
	str	q6, [x3, #2576]
	add	x3, x3, #32
	subs	x4, x4, #1
	b.ne	LBB0_99
; %bb.100:                              ; %direct.false2592
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q5, [sp, #4576]                 ; 16-byte Reload
	ldr	q2, [sp, #1040]                 ; 16-byte Reload
	bit.16b	v5, v2, v0
	str	q5, [sp, #4576]                 ; 16-byte Spill
	ldr	q5, [sp, #4560]                 ; 16-byte Reload
	ldr	q2, [sp, #4656]                 ; 16-byte Reload
	bit.16b	v5, v2, v1
	str	q5, [sp, #4560]                 ; 16-byte Spill
	movi.2d	v6, #0000000000000000
	ldr	q2, [sp, #4640]                 ; 16-byte Reload
	fadd.4s	v5, v2, v6
	ldr	q2, [sp, #4624]                 ; 16-byte Reload
	fadd.4s	v5, v5, v2
	ldr	q2, [sp, #4704]                 ; 16-byte Reload
	fadd.4s	v6, v2, v6
	ldr	q2, [sp, #4688]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4672]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #4608]                 ; 16-byte Reload
	fadd.4s	v5, v5, v2
	ldr	q2, [sp, #4592]                 ; 16-byte Reload
	fadd.4s	v5, v5, v2
	ldr	q2, [sp, #2736]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #2704]                 ; 16-byte Reload
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #2720]                 ; 16-byte Reload
	fadd.4s	v5, v5, v2
	ldr	q2, [sp, #2688]                 ; 16-byte Reload
	fadd.4s	v5, v5, v2
	ldr	q2, [sp, #2672]                 ; 16-byte Reload
	fadd.4s	v2, v6, v2
	ldr	q3, [sp, #1024]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #2656]                 ; 16-byte Reload
	fadd.4s	v4, v5, v3
	ldr	q3, [sp, #2640]                 ; 16-byte Reload
	fadd.4s	v3, v4, v3
	ldr	q4, [sp, #2624]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1008]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2608]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #992]                  ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #2592]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2576]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldp	q4, q5, [sp, #960]              ; 32-byte Folded Reload
	fadd.4s	v3, v3, v5
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #2560]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2544]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1120]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #2528]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1136]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2512]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1104]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldp	q5, q4, [sp, #928]              ; 32-byte Folded Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #2320]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q6, [sp, #2496]                 ; 16-byte Reload
	ldr	q4, [sp, #912]                  ; 16-byte Reload
	fmul.4s	v4, v6, v4
	fmul.4s	v5, v18, v5
	fadd.4s	v2, v5, v2
	fadd.4s	v3, v4, v3
	add	x0, x0, #1
	bit.16b	v6, v3, v1
	str	q6, [sp, #2496]                 ; 16-byte Spill
	bit.16b	v18, v2, v0
	str	q18, [sp, #2480]                ; 16-byte Spill
	ldr	q2, [sp, #1056]                 ; 16-byte Reload
	cmp	x0, #129
	ldr	q18, [sp, #2464]                ; 16-byte Reload
	ldr	q19, [sp, #2448]                ; 16-byte Reload
	str	q31, [sp, #2336]                ; 16-byte Spill
	str	q27, [sp, #2320]                ; 16-byte Spill
	ldr	q5, [sp, #4544]                 ; 16-byte Reload
	ldr	q4, [sp, #4528]                 ; 16-byte Reload
	ldr	q6, [sp, #4512]                 ; 16-byte Reload
	ldr	q31, [sp, #3024]                ; 16-byte Reload
	ldr	q25, [sp, #2992]                ; 16-byte Reload
	ldr	q26, [sp, #2976]                ; 16-byte Reload
	ldr	q10, [sp, #2960]                ; 16-byte Reload
	ldr	q27, [sp, #2864]                ; 16-byte Reload
	ldr	q24, [sp, #1088]                ; 16-byte Reload
	b.ne	LBB0_22
; %bb.101:                              ; %direct.schedule.83.preheader
	mov	x9, #0                          ; =0x0
	ldp	q2, q4, [sp, #16]               ; 32-byte Folded Reload
	xtn.2s	v2, v2
	movi.2s	v5, #96
	umull.2d	v2, v2, v5
	ldp	q3, q6, [sp, #48]               ; 32-byte Folded Reload
	xtn.2s	v3, v3
	umull.2d	v3, v3, v5
	xtn.2s	v4, v4
	umull.2d	v4, v4, v5
	xtn.2s	v6, v6
	umull.2d	v5, v6, v5
	ldr	x12, [sp, #8]                   ; 8-byte Reload
	ldr	q19, [sp, #2496]                ; 16-byte Reload
	ldr	q20, [sp, #2480]                ; 16-byte Reload
	b	LBB0_103
LBB0_102:                               ; %else634
                                        ;   in Loop: Header=BB0_103 Depth=1
	add	x9, x9, #1
	cmp	x9, #96
	b.eq	LBB0_119
LBB0_103:                               ; %direct.true2610
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q6, [sp, #4736]                 ; 16-byte Reload
	fmov	w10, s6
	dup.2d	v6, x9
	add.2d	v7, v6, v2
	add	x11, x8, x9, lsl #5
	ldp	q17, q16, [x11]
	and.16b	v17, v1, v17
	fdiv.4s	v17, v17, v19
	shl.2d	v18, v7, #2
	dup.2d	v7, x12
	add.2d	v18, v7, v18
	tbz	w10, #0, LBB0_111
; %bb.104:                              ; %cond.store
                                        ;   in Loop: Header=BB0_103 Depth=1
	fmov	x11, d18
	str	s17, [x11]
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_112
LBB0_105:                               ; %else616
                                        ;   in Loop: Header=BB0_103 Depth=1
	add.2d	v18, v6, v3
	shl.2d	v18, v18, #2
	add.2d	v18, v7, v18
	tbz	w10, #2, LBB0_113
LBB0_106:                               ; %cond.store617
                                        ;   in Loop: Header=BB0_103 Depth=1
	fmov	x11, d18
	st1.s	{ v17 }[2], [x11]
	tbnz	w10, #3, LBB0_114
LBB0_107:                               ; %else622
                                        ;   in Loop: Header=BB0_103 Depth=1
	add.2d	v17, v6, v4
	and.16b	v16, v0, v16
	fdiv.4s	v16, v16, v20
	shl.2d	v17, v17, #2
	add.2d	v17, v7, v17
	tbz	w10, #4, LBB0_115
LBB0_108:                               ; %cond.store623
                                        ;   in Loop: Header=BB0_103 Depth=1
	fmov	x11, d17
	str	s16, [x11]
	tbnz	w10, #5, LBB0_116
LBB0_109:                               ; %else628
                                        ;   in Loop: Header=BB0_103 Depth=1
	add.2d	v6, v6, v5
	shl.2d	v6, v6, #2
	add.2d	v6, v7, v6
	tbz	w10, #6, LBB0_117
LBB0_110:                               ; %cond.store629
                                        ;   in Loop: Header=BB0_103 Depth=1
	fmov	x11, d6
	st1.s	{ v16 }[2], [x11]
	tbz	w10, #7, LBB0_102
	b	LBB0_118
LBB0_111:                               ; %else613
                                        ;   in Loop: Header=BB0_103 Depth=1
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_105
LBB0_112:                               ; %cond.store614
                                        ;   in Loop: Header=BB0_103 Depth=1
	mov.d	x11, v18[1]
	st1.s	{ v17 }[1], [x11]
	add.2d	v18, v6, v3
	shl.2d	v18, v18, #2
	add.2d	v18, v7, v18
	tbnz	w10, #2, LBB0_106
LBB0_113:                               ; %else619
                                        ;   in Loop: Header=BB0_103 Depth=1
	tbz	w10, #3, LBB0_107
LBB0_114:                               ; %cond.store620
                                        ;   in Loop: Header=BB0_103 Depth=1
	mov.d	x11, v18[1]
	st1.s	{ v17 }[3], [x11]
	add.2d	v17, v6, v4
	and.16b	v16, v0, v16
	fdiv.4s	v16, v16, v20
	shl.2d	v17, v17, #2
	add.2d	v17, v7, v17
	tbnz	w10, #4, LBB0_108
LBB0_115:                               ; %else625
                                        ;   in Loop: Header=BB0_103 Depth=1
	tbz	w10, #5, LBB0_109
LBB0_116:                               ; %cond.store626
                                        ;   in Loop: Header=BB0_103 Depth=1
	mov.d	x11, v17[1]
	st1.s	{ v16 }[1], [x11]
	add.2d	v6, v6, v5
	shl.2d	v6, v6, #2
	add.2d	v6, v7, v6
	tbnz	w10, #6, LBB0_110
LBB0_117:                               ; %else631
                                        ;   in Loop: Header=BB0_103 Depth=1
	tbz	w10, #7, LBB0_102
LBB0_118:                               ; %cond.store632
                                        ;   in Loop: Header=BB0_103 Depth=1
	mov.d	x10, v6[1]
	st1.s	{ v16 }[3], [x10]
	b	LBB0_102
LBB0_119:
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #1088
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_120:                               ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

#!/usr/bin/env python3
"""Read-only kernel inspection; produces command receipts, never loads code."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
RAW = HERE.parent
OBJDUMP = Path('/opt/homebrew/opt/llvm/bin/llvm-objdump').resolve()
NM = Path('/opt/homebrew/opt/llvm/bin/llvm-nm').resolve()
commands = []
summary = {}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(argv, directory, name):
    result = subprocess.run([str(x) for x in argv], capture_output=True, timeout=30)
    (directory / (name + '.stdout.txt')).write_bytes(result.stdout)
    (directory / (name + '.stderr.txt')).write_bytes(result.stderr)
    commands.append({'argv': [str(x) for x in argv], 'returncode': result.returncode,
                     'stdout': str((directory / (name + '.stdout.txt')).relative_to(HERE)),
                     'stderr': str((directory / (name + '.stderr.txt')).relative_to(HERE))})
    (HERE / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    assert result.returncode == 0, argv
    return result.stdout.decode()


for case in ('decode-mha-d64', 'decode-long-kv', 'prefill-q8'):
    for arm in ('off', 'on'):
        prepared = RAW / f'prepared-{case}-{arm}'
        if not prepared.exists():
            candidates = sorted(RAW.glob('prepared-*q8*'))
            raise RuntimeError(f'{prepared} missing; candidates={candidates}')
        metadata = json.loads((prepared / 'prepared.json').read_text())
        output = HERE / f'{case}-{arm}'
        output.mkdir()
        for name in ('kernel.o', 'kernel.ll', 'kernel.dylib'):
            assert sha(prepared / name) == metadata['files'][name]
        disassembly = command([OBJDUMP, '--disassemble', '--no-show-raw-insn', prepared / 'kernel.o'], output, 'object-disassembly')
        symbols = command([NM, '--numeric-sort', '--print-size', prepared / 'kernel.o'], output, 'object-symbols')
        imports = command([NM, '--undefined-only', prepared / 'kernel.o'], output, 'object-imports')
        text = (prepared / 'kernel.ll').read_text()
        realization = metadata['metadata']['realization']
        fields = {}
        for name in ('native_copy_vector_width', 'native_copies', 'native_mmas', 'native_output_mmas',
                     'native_contraction_mmas', 'private_workspace_bytes', 'static_snapshot_bytes_per_worker',
                     'static_snapshot_allocations', 'full_packet_specializations', 'full_packet_cloned_instructions'):
            found = re.search(r'\b' + name + r'=(\d+)', realization)
            fields[name] = int(found.group(1)) if found else None
        summary[f'{case}-{arm}'] = {
            'prepared_sha256': sha(prepared / 'prepared.json'),
            'artifacts': {name: {'sha256': sha(prepared / name), 'bytes': (prepared / name).stat().st_size}
                          for name in ('kernel.o', 'kernel.ll', 'kernel.dylib')},
            'realization': realization, 'fields': fields,
            'abi': {name: metadata[name] for name in ('abi', 'symbol', 'packet_width', 'block', 'dispatch', 'workspace_bytes')},
            'llvm_definitions': re.findall(r'^define .+', text, re.M),
            'llvm_body_instructions': sum(bool(re.match(r'^  (?:%[^ ]+ = |(?:br|ret|store|call|unreachable)\b)', line)) for line in text.splitlines()),
            'object_instruction_lines': sum(bool(re.match(r'^\s+[0-9a-f]+:', line)) for line in disassembly.splitlines()),
            'object_imports': imports.splitlines(),
            'object_call_instructions': [line for line in disassembly.splitlines() if re.search(r'\s(?:bl|blr)\s', line)],
        }

(HERE / 'inspection.json').write_text(json.dumps({
    'tools': {str(p): sha(p) for p in (OBJDUMP, NM)}, 'arms': summary,
    'limits': 'kernel.ll is the captured lowering dump, not independently claimed post-O2. kernel.o is the actual ORC producer object. No native execution or timing.'
}, indent=2) + '\n')
print(json.dumps({key: value['fields'] for key, value in summary.items()}, indent=2))
